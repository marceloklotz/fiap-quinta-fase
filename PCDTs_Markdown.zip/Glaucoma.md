<!-- METADADOS: doenca: Glaucoma | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 28, DE 06 DE DEZEMBRO DE 2023  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Glaucoma.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE, no uso das atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o glaucoma no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup>o</sup> 729/2022 e o Relatório de Recomendação nº 732 – Maio de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Glaucoma.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do glaucoma, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do glaucoma.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SECTICS n<sup>o</sup> 11, de 02 de abril de 2018, publicada no Diário Oficial da União nº 67, de 09 de abril de 2018, seção 1, página 100.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
HELVÉCIO MIRANDA MAGALHÃES JÚNIOR  
CARLOS AUGUSTO GRABOIS GADELHA  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DO GLAUCOMA

---

<!-- METADADOS: doenca: Glaucoma | secao: **1. INTRODUÇÃO** -->
O glaucoma é uma neuropatia óptica com repercussão característica no campo visual, cujo principal fator de risco é o aumento da pressão intraocular (PIO) e cujo desfecho principal é a cegueira irreversível. O fator de risco mais relevante e estudado para o desenvolvimento da doença é a elevação da PIO<sup>1</sup> . Os valores normais situam-se entre 10 e 21 mmHg. Quando a PIO está aumentada, mas não há dano evidente do nervo óptico nem alteração no campo visual, o paciente é caracterizado como portador de glaucoma suspeito por hipertensão ocular (HO). Quando a PIO está normal e o paciente apresenta dano no nervo óptico ou alteração no campo visual, ele é classificado como portador de glaucoma de pressão normal. Exceto no glaucoma de início súbito, chamado glaucoma agudo, a evolução é lenta e principalmente assintomática.  
Essa doença afeta mais de 67 milhões de pessoas no mundo, das quais 10% são cegas (acuidade visual corrigida no melhor olho de 0,05 ou campo visual com menos de 10 graus no melhor olho com a melhor correção óptica)<sup>2</sup> . Após a catarata, o glaucoma é a segunda causa de cegueira, além de ser a principal causa de cegueira irreversível<sup>3</sup> . No Brasil, há escassez de informações quanto à prevalência do glaucoma. A maior parte dos estudos é restrita, antiga e mostra prevalência de 2% a 3% na população acima de 40 anos, com aumento da prevalência conforme o aumento da idade<sup>4–6</sup> . O Conselho Brasileiro de Oftalmologia adota a prevalência de 2% a 3% na população brasileira acima de 40 anos, sendo que 50% a 60% destes diagnósticos são de glaucoma primário de ângulo aberto e em torno de 20% são de glaucoma primário de ângulo fechado<sup>7</sup> .  
Vários fatores de risco, além da PIO aumentada, já foram identificados: idade acima de 40 anos, escavação do nervo óptico aumentada, etnia (negra para o de ângulo aberto e amarela para o de ângulo fechado), história familiar, ametropia (miopia para o de ângulo aberto e hipermetropia para o de ângulo fechado), pressão de perfusão ocular diminuída, diabetes melito tipo 2, fatores genéticos e outros fatores especificados<sup>8</sup> . Diversos estudos demonstraram que a prevalência do glaucoma se eleva significativamente com o aumento da idade, particularmente em latinos e afrodescendentes<sup>9–15</sup> . A prevalência é três vezes maior e a chance de cegueira pela doença é seis vezes maior em indivíduos latinos e afrodescendentes em relação aos caucasianos.  
Com relação à história familiar, estudos revelaram que basta um caso familiar de glaucoma para aumentar significativamente a chance de o indivíduo desenvolver a doença. Segundo o _Rotterdam Eye Study_ , a chance de um indivíduo com irmão com glaucoma desenvolver a doença é 9,2 vezes maior do que a da população geral<sup>9,16–18</sup> . A maioria dos casos não está vinculada a fatores relacionados aos genes, o que sugere que o dano glaucomatoso é multifatorial<sup>9,19–22</sup> . Enxaqueca e vasoespasmo periférico foram consistentemente relacionados como fatores de risco, ao passo que outras doenças vasculares (por exemplo, hipertensão arterial sistêmica) não tiveram associação confirmada<sup>9,19,23–32</sup> .  
Córneas com espessura mais fina (igual ou inferior a 555 micrômetros) subestimam a PIO, ao passo que córneas espessas superestimam essa medida. Os estudos são controversos sobre se a medida da paquimetria é um fator de risco independente da PIO ou se a medida da córnea mais fina subestima uma PIO aumentada que causa um dano glaucomatoso<sup>9,33–47</sup> .  
Pressão de perfusão ocular diminuída é a diferença entre a pressão arterial e a PIO. Estudos sugeriram que uma baixa pressão sistólica (igual ou inferior a 125 mmHg) ou uma baixa pressão diastólica (inferior a 50 mmHg) estão relacionadas a uma maior prevalência de glaucoma primário de ângulo aberto<sup>9,12,23,48,49</sup> . Há evidências crescentes de que o dano microvascular no nervo óptico causado pelo diabetes melito tipo 2 aumenta significativamente a prevalência de glaucoma<sup>9,24,50–58</sup> .  
O glaucoma pode ser classificado das seguintes formas (7-9): glaucoma primário de ângulo aberto (GPAA), glaucoma de pressão normal (GPN), glaucoma primário de ângulo fechado, glaucoma congênito e glaucoma secundário.  
O GPAA, forma mais comum de glaucoma, é diagnosticado por PIO superior a 21 mmHg, associado a dano no nervo óptico ou a defeito no campo visual compatível com glaucoma e ausência de anormalidades na câmara anterior e de anormalidades sistêmicas ou oculares que possam aumentar a PIO. Segundo diversos estudos populacionais, a prevalência de  
2  
GPAA aumenta à medida que a PIO se eleva. Ademais, pesquisas demonstraram que a redução pressórica retarda a progressão do dano glaucomatoso. Diferentes estudos evidenciaram que apenas uma proporção de pacientes com PIO acima de 21 mmHg tem glaucoma, sugerindo a arbitrariedade de tal valor<sup>9,12,59–68</sup> . A prevalência de glaucoma primário de ângulo fechado é maior em indivíduos da etnia amarela, variando entre 3% a 5% nessa população acima de 40 anos<sup>9,11,12,18,69–72</sup> .  
A triagem populacional para glaucoma não se mostrou custo-efetiva nos Estados Unidos. Ela parece ser mais útil quando focada em populações de risco, como idosos, pacientes com familiares glaucomatosos e indivíduos latinos e afrodescendentes. No Brasil, há carência de estudos de custo-efetividade da triagem para glaucoma<sup>9,16,18,20–22,73–79</sup> .  
O tratamento clínico é tópico e semelhante nas diferentes formas de glaucoma. Entretanto, há particularidades inerentes a cada uma delas que exigem tratamento individualizado, como os procedimentos cirúrgicos e a laser.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do glaucoma. A metodologia de busca e avaliação das evidências está detalhada no **Apêndice 1** .

---

<!-- METADADOS: doenca: Glaucoma | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- H 40.1 Glaucoma primário de ângulo aberto;  
- H 40.2 Glaucoma primário de ângulo fechado;  
- H 40.3 Glaucoma secundário a traumatismo ocular;  
- H 40.4 Glaucoma secundário a inflamação ocular;  
- H 40.5 Glaucoma secundário a outros transtornos do olho;  
- H 40.6 Glaucoma secundário a drogas;  
- H 40.8 Outro glaucoma;  
- Q15.0 Glaucoma congênito.

---

<!-- METADADOS: doenca: Glaucoma | secao: **3. DIAGNÓSTICO** -->
A avaliação oftalmológica do paciente deve ser binocular e abordar os seguintes itens para o diagnóstico do glaucoma e para a determinação da sua gravidade<sup>8,9,80,81</sup> :  
- Anamnese;  
- Medida da acuidade visual (AV) com melhor correção;  
- Exame pupilar para avaliação de reatividade à luz e procura de defeito pupilar aferente relativo;  
- Biomicroscopia de segmento anterior para avaliação da profundidade da câmara anterior, de doenças corneanas ou de causas secundárias para o aumento da PIO;  
- Aferição da PIO, idealmente medida com tonometria de aplanação de Goldmann, em diferentes dias e horários, para reconhecimento da flutuação diária; e  
- Avaliação do nervo óptico e da camada de fibras nervosas (CFN) para o fornecimento de informações estruturais sobre o dano glaucomatoso. O nervo óptico deve ser avaliado com biomicroscopia de fundo e fundoscopia sob midríase e ser documentado, idealmente, com retinografia colorida binocular.  
As seguintes características devem ser avaliadas no exame do nervo óptico:  
3  
a) Formato e tamanho do disco óptico: a forma usual do disco óptico é oval, com grande variação de tamanho na população. Ambos os fatores influenciam outros parâmetros importantes para o diagnóstico, como a relação escavação/disco e avaliação do anel neural;  
b) Tamanho e forma da escavação do disco óptico: a escavação normal costuma ser central e arredondada ou ovalada. Uma escavação maior na vertical é fortemente indicativa de glaucoma, uma vez que menos de 7% dos olhos normais apresentam uma relação maior entre escavação e disco (E/D) no eixo vertical. Identifica-se a escavação pela deflexão dos vasos sanguíneos e pela visibilidade da lâmina cribiforme, sendo geralmente quantificada como uma fração decimal e idealmente avaliada nos sentidos vertical e horizontal. Na maior parte da população, a relação E/D é igual ou inferior a 0,4. Entretanto, em indivíduos normais, é possível encontrar uma relação E/D de até 0,8. Discos ópticos com maior diâmetro comportam uma escavação fisiológica maior. Portanto, deve-se sempre considerar o tamanho do disco para a aferição correta da escavação. A presença de assimetria de escavação é mais importante do que o tamanho da escavação, uma vez que menos de 0,5% dos indivíduos normais apresenta assimetria acima de 0,2<sup>75,77,80,81</sup> ;  
c) Área e configuração do anel neural: o anel neural é a porção do disco óptico formada pelos axônios das células ganglionares retinianas, tecido glial e vasos sanguíneos, delimitado pela deflexão dos vasos e pela distância da lâmina cribiforme. As rimas superiores e inferiores do anel neural recebem mais axônios, sendo, portanto, maiores. A rima temporal recebe axônios exclusivamente da região macular, sendo, assim, menor. Diversos estudos mostraram que, independentemente do tamanho do disco óptico, os indivíduos saudáveis apresentam a rima inferior mais espessa, seguida da superior, nasal e temporal, originando, assim, a regra ISNT. A lesão glaucomatosa manifesta-se como afinamento do anel neural, que pode ser generalizado ou localizado. A perda generalizada pode ocorrer em até 44% dos olhos glaucomatosos sem prejuízo da regra ISNT, levando à dificuldade no diagnóstico. A perda localizada aparece com a mesma frequência da generalizada, iniciando nas regiões temporal superior e temporal inferior, com o aumento da escavação vertical. A perda localizada pode se estender, comprometendo inteiramente o tecido neural até o anel escleral, com exposição da lâmina cribiforme. Esse tipo de perda localizada ou em chanfradura, também conhecido como _notch_ , está fortemente associado ao glaucoma, mas não é patognomônico dessa doença. Outros achados, como palidez do disco óptico, também podem ser vistos, devendo ser realizado o diagnóstico diferencial com neuropatias ópticas não glaucomatosas<sup>76,78–80,82</sup> ;  
d) Configuração da lâmina cribiforme: a visibilidade dessa estrutura é maior quando há perda do tecido neural que a recobre, como no glaucoma, ou quando o disco óptico é grande. A perda glaucomatosa é maior nos polos superior e inferior do disco, estando associada a poros com diâmetros maiores nessas regiões, onde haveria menos tecido conjuntivo para sustentação. Outro achado que deve ser buscado é a fosseta de nervo óptico. A fosseta adquirida representa uma ectasia da lâmina cribiforme, devendo ser diferenciada da fosseta congênita, que é uma depressão localizada do disco óptico, geralmente presente na região temporal ou temporal superior do disco. A fosseta adquirida se relacionaria a dano mais grave do nervo óptico e estaria mais presente em olhos com progressão do glaucoma<sup>80,83,84</sup> ;  
e) Região peripapilar: as atrofias retinianas peripapilares podem ocorrer em indivíduos normais, porém estão associadas ao glaucoma. A atrofia na zona beta corresponde a uma área adjacente ao disco óptico onde são visualizados os vasos coroideanos e a esclera, correspondendo à perda quase total do epitélio pigmentado da retina e dos fotorreceptores. A atrofia na zona alfa circunda a zona beta, sendo visualizada como hipo e hiperpigmentações, que correspondem a variações na quantidade de melanina no epitélio pigmentado da retina. A zona beta é mais comum e extensa em olhos com glaucoma do que em olhos normais. Alguns estudos sugerem que, em olhos pequenos e com discos ópticos pequenos, a neuropatia óptica glaucomatosa pode ser detectada de maneira mais fácil pela atrofia peripapilar do que pela relação E/D<sup>80,85–94</sup> ;  
f) Configuração dos vasos sanguíneos do disco óptico: as alterações vasculares são aquelas relacionadas à posição dos vasos no disco óptico, como desnudamento do vaso circunlinear, vaso em passarela, distância de saída do tronco vascular da retina, vaso em baioneta, vasos colaterais, além do estreitamento arteriolar difuso ou localizado. Hemorragias do  
4  
nervo óptico podem ser encontradas no glaucoma, porém sua presença não é patognomônica. As hemorragias podem ser encontradas dentro do disco óptico, sobre a lâmina cribriforme, sobre o anel neural ou na borda do disco óptico. São mais frequentes nas regiões temporal inferior ou temporal superior do disco óptico e nas regiões onde há maior perda neural, tendo sido relacionadas a defeitos de campo visual e à progressão do glaucoma. Há evidências de que as hemorragias do disco óptico são mais frequentes em pacientes com glaucoma de pressão normal do que nos pacientes com GPAA. Apesar de as hemorragias do nervo óptico estarem presentes em outras condições, como hipertensão arterial, diabetes melito ou descolamento posterior do vítreo, em ensaios clínicos randomizados a presença de hemorragias do nervo óptico foi um dos fatores de risco mais importantes para a progressão do glaucoma<sup>80,95–102</sup> .  
Se houver suspeita de glaucoma, exames devem ser realizados como forma de complementar a investigação diagnóstica (nos casos de glaucoma estabelecido, visam a auxiliar na definição etiológica e de gravidade).  
A gonioscopia avalia o ângulo iridocorneano, identificando a amplitude do ângulo da câmara anterior, o grau de pigmentação, a altura da inserção iriana e a configuração da íris. O diagnóstico de GPAA requer uma gonioscopia para excluir o fechamento angular e outras causas de aumento da PIO, como recesso angular, dispersão pigmentar, sinéquias anteriores periféricas, neovascularização de ângulo e precipitados inflamatórios<sup>80</sup> .  
A paquimetria ultrassônica avalia a espessura corneana central e influencia a estimativa da PIO. Há controvérsia se a córnea fina é um fator de risco não influenciado pela PIO ou se está relacionada à sua medida. A espessura média corneana central varia conforme a etnia, estando situada entre 534 e 556 micrômetros. Portanto, córneas com espessura menor tendem a subestimar a PIO, ao passo que as de espessura maior superestimam a medida<sup>9</sup> .  
A campimetria visual (campimetria computadorizada estática acromática) é o exame padrão-ouro para detectar o dano funcional do glaucoma e para monitorizar sua progressão. Programas que analisam os 24 a 30 graus centrais são utilizados na rotina de avaliação de danos glaucomatosos iniciais e moderados. Glaucomas com danos avançados necessitam de uma avaliação mais detalhada dos 10 graus centrais. Apesar de poder estar associado à perda difusa de sensibilidade, o glaucoma tipicamente provoca defeitos localizados de campo visual, como escotoma paracentral (superior ou inferior), aumento da mancha cega, degrau nasal (superior ou inferior) e escotoma arqueado (superior ou inferior). Vários critérios podem ser utilizados para realizar o diagnóstico de defeito de campo visual no glaucoma, não havendo consenso a respeito do melhor critério a ser adotado. Recomenda-se correlacionar as alterações anatômicas visíveis do nervo óptico e da CFN com os resultados obtidos no exame do campo visual. A identificação da progressão dos defeitos perimétricos pode ser feita pela observação de um dos seguintes eventos: surgimento de novo defeito, aumento em extensão de área já alterada e aumento em profundidade de defeito já estabelecido. Para avaliar a progressão, é fundamental escolher dois ou mais exames estáveis e confiáveis que serão considerados para compor um exame basal. Deve-se evitar a inclusão do primeiro exame devido à inconsistência de seus resultados. Não há indicação de outros exames como perimetria azul-amarelo para avaliação de progressão de dano glaucomatoso já estabelecido. Todo defeito no campo visual deve ser compatível com a doença glaucomatosa e reprodutível<sup>80,103–123</sup> .  
O exame de tomografia de coerência óptica (TCO) é uma técnica de imagem óptica que fornece imagens da espessura de camada de fibras nervosas da retina e do nervo óptico, permitindo discriminar indivíduos glaucomatosos de indivíduos saudáveis<sup>124–128</sup> . O desempenho diagnóstico da TCO para glaucoma evidencia a possibilidade de otimizar a acurácia diagnóstica do glaucoma, quando associada aos exames tradicionais<sup>129–132</sup> . Portanto, o exame de TCO é preconizado para confirmação diagnóstica de glaucoma em pacientes suspeitos pelo aspecto do disco óptico, alterações do campo visual ou pressão intraocular elevada<sup>133,134</sup> .  
Deve ser realizada documentação do nervo óptico e análise da CFN, conforme já referido, principalmente nos casos suspeitos ou confirmados de glaucoma. A retinografia colorida estereoscópica é superior à técnica simples por permitir uma melhor quantificação do anel neural. O uso do filtro aneritra contribui para uma melhor análise qualitativa da CFN. Entretanto,  
5  
a retinografia simples pode ser suficiente para o seguimento<sup>80,135–144</sup> . A TCO é preconizada neste Protocolo para confirmação diagnóstica do glaucoma<sup>134</sup> .

---

<!-- METADADOS: doenca: Glaucoma | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes com diagnóstico de glaucoma que apresentem pelo menos **dois** dos seguintes  
critérios:  
- PIO média acima de 21 mmHg, sem tratamento;  
- Dano típico ao nervo óptico com perda da rima neurorretiniana identificado por biomicroscopia de fundo (escavação igual ou acima de 0,5); **ou**  
- Campo visual compatível com o dano ao nervo óptico.

---

<!-- METADADOS: doenca: Glaucoma | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento ou procedimento preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Glaucoma | secao: **Glaucoma congênito** -->
No glaucoma congênito, ocorre obstrução da drenagem do humor aquoso causada por uma anormalidade do desenvolvimento ocular. Seu tratamento é primariamente cirúrgico<sup>8</sup> . Nos casos em que, após o procedimento cirúrgico, a PIO permanece elevada, o tratamento clínico preconizado neste Protocolo pode ser instituído.

---

<!-- METADADOS: doenca: Glaucoma | secao: **Glaucoma primário de ângulo fechado** -->
O glaucoma primário de ângulo fechado, segunda forma mais comum de glaucoma, associa-se a dano no nervo óptico ou a repercussão no campo visual secundários ao fechamento angular primário. Ocorre mais frequentemente em indivíduos hipermetropes. Ademais, especula-se que pacientes com miopia axial possam ter um menor suporte escleral no nervo óptico, o que os tornaria mais vulneráveis ao dano glaucomatoso<sup>9,25–32,145–155</sup> .  
Nesse tipo de glaucoma, há um fechamento parcial ou completo do ângulo da câmara anterior, decorrente de condições anatômicas que propiciam a aposição ou a adesão da periferia da íris à sua parede externa (goniossinéquias), com frequente elevação da PIO de forma aguda, subaguda ou crônica.  
O fechamento angular primário pode levar, em alguns casos, ao desenvolvimento de neuropatia óptica glaucomatosa. Quando não for possível identificar sem manobras de indentação o trabeculado pigmentado em 180 graus ou mais à gonioscopia, não houver vestígios de toque iridotrabecular prévio, de goniossinéquias ou de neuropatia óptica glaucomatosa e a PIO encontrarse normal, o paciente será classificado como suspeito de fechamento angular primário. Caso se evidencie toque iridotrabecular ou goniossinéquias ou aumento da PIO, sem evidência de neuropatia glaucomatosa, o paciente será classificado como tendo fechamento angular primário. Caso haja neuropatia glaucomatosa, há glaucoma primário de ângulo fechado<sup>156</sup> .  
Há quatro tipos básicos de mecanismos de fechamento angular primário: bloqueio pupilar, íris em platô, fechamento angular induzido pelo cristalino e associação de mecanismos<sup>156</sup> .  
O tratamento básico, quando há bloqueio pupilar, baseia-se na criação de um pertuito que possibilite a comunicação do humor aquoso entre as câmaras anterior e posterior do olho, geralmente por meio de iridotomia a _laser_ ou cirurgia fistulizante<sup>8</sup> . Após o procedimento, é necessário avaliar a necessidade de tratamento medicamentoso de uso contínuo, podendo o paciente ser incluído neste Protocolo<sup>156</sup> .  
A íris em platô ocorre devido a uma maior espessura de sua periferia, sua inserção mais anterior ou posicionamento mais anterior dos processos ciliares. Nessa condição, o ângulo é fechado pela periferia da íris, mesmo na presença de uma iridotomia  
6  
patente (síndrome da íris em platô). Geralmente, esses olhos apresentam câmara anterior de profundidade normal na região central em contraposição à câmara rasa na periferia e ângulo estreito. A gonioscopia de indentação pode revelar uma dupla corcova, mecanismo que pode estar associado ao bloqueio pupilar. A síndrome de íris em platô é incomum. O diagnóstico definitivo é feito quando ocorre aumento da PIO provocado pelo fechamento angular agudo em um olho com iridotomia patente. O tratamento pode requerer iridoplastia periférica a _laser_ , uso contínuo de mióticos (pilocarpina) e, caso persista o aumento pressórico, cirurgia fistulizante (trabeculectomia)<sup>156</sup> . O fechamento angular induzido pelo cristalino pode requerer facectomia associada ou não à cirurgia fistulizante, podendo o paciente necessitar de medicamentos hipotensores tópicos, de uso contínuo, conforme os critérios estabelecidos neste Protocolo<sup>156–158</sup> .

---

<!-- METADADOS: doenca: Glaucoma | secao: **Glaucoma secundário** -->
O glaucoma secundário é a forma em que há aumento da PIO e dano no nervo óptico ou no campo visual secundários a doenças oculares predisponentes, a trauma ou ao uso de medicamentos. Deve ser tratada a causa básica de aumento da PIO e, caso seja necessário, iniciado o tratamento clínico visando reduzir a PIO de acordo com os critérios terapêuticos estabelecidos neste Protocolo. Removida a causa básica, deve ser reavaliada a necessidade de manter o tratamento contínuo.

---

<!-- METADADOS: doenca: Glaucoma | secao: **Hipertensão ocular (HO)** -->
A HO é definida como uma PIO aumentada (acima de 21 mmHg) na ausência de perda de campo visual ou de dano glaucomatoso no nervo óptico. Para seu diagnóstico, são necessários todos os seguintes critérios:  
- a) PIO média acima de 21 mmHg, sem tratamento;  
- b) Ângulo aberto à gonioscopia;  
- c) Ausência de dano ao nervo óptico típico com perda da rima neurorretiniana;  
- d) Ausência de defeitos de campo visual; **e**  
- e) Ausência de causa secundária para elevação da PIO.  
A HO tem uma prevalência estimada de 2,7% a 7,5%<sup>9</sup> , sendo considerada um fator de risco para conversão para GPAA. Há evidência de que a redução da PIO em pacientes com HO diminui a progressão para a doença glaucomatosa, existindo, porém, controvérsias no que tange ao custo-efetividade do tratamento<sup>75</sup> .  
Os principais fatores associados à conversão para GPAA são idade, etnia negra, PIO aumentada, exfoliação em pacientes com mais de 65 anos de idade, miopia, diabete melito, história familiar de glaucoma e espessura corneana diminuída. Porém, como 90% dos pacientes com HO não desenvolvem glaucoma<sup>9,63,75,80,81</sup> , este Protocolo não preconiza o uso com essa finalidade.  
Caso o paciente com HO apresente dano em campo visual ou escavação de nervo óptico compatível com os critérios de inclusão deste Protocolo, ele deverá ser tratado.  
**Glaucoma de pressão normal (GPN)**  
O GPN é a forma em que há dano no nervo óptico ou no campo visual na ausência da PIO elevada e de anormalidades  
oculares ou sistêmicas que possam aumentar a PIO. Para seu diagnóstico, são necessários todos os seguintes critérios:  
- a) PIO média igual ou inferior a 21 mmHg, sem tratamento;  
- b) Ângulo aberto à gonioscopia sem achados patológicos;  
- c) Dano ao nervo óptico típico com perda da rima neurorretiniana;  
- d) Campo visual compatível com o dano ao nervo óptico; **e**  
- e) Ausência de causa secundária para elevação da PIO.  
Este Protocolo preconiza o tratamento de pacientes com GPN, desde que preenchidos os critérios de inclusão.

---

<!-- METADADOS: doenca: Glaucoma | secao: **7. TRATAMENTO** -->
O objetivo primário do tratamento de glaucoma é a redução da PIO. Nos últimos anos, diversos estudos evidenciaram a eficácia dessa conduta na redução das taxas de progressão da doença.  
7  
Antes do início do tratamento, deve ser realizado exame oftalmológico completo com a documentação do nervo óptico com retinografia binocular colorida, campimetria visual, paquimetria, avaliação do fundo de olho, tomografia de coerência óptica e medição da PIO basal, sendo preconizadas as aferições em dias diferentes e considerada a de maior valor. Os pacientes devem repetir a medição da PIO quatro semanas após o início ou a modificação do tratamento. Nesse mesmo período, é necessária a escolha da PIO alvo para o paciente, definida como uma PIO na qual não há progressão documentada da doença. Seu valor inicial geralmente é 25% a 30% inferior ao da PIO basal, porém, dependendo de alguns fatores, pode ser diferente:  
- PIO basal: quanto menor a PIO pré-tratamento, menor a PIO alvo;  
- Gravidade da doença: quanto maior o dano glaucomatoso pré-tratamento, menor a PIO alvo;  
- Taxa de progressão: quanto maior a progressão, menor a PIO alvo;  
- Idade e expectativa de vida: quanto mais jovem o paciente, menor a PIO alvo;  
- Presença de outros fatores agravantes (exfoliação, hemorragias de disco): quanto maior o número de fatores que pioram  
- o prognóstico da doença, menor a PIO alvo<sup>11,95–97</sup> .  
O efeito hipotensor ocular e o possível evento adverso do fármaco escolhido devem ser avaliados em curto prazo, em média quatro semanas após o início do uso<sup>9,75,80,81,159</sup> . Na maior parte dos estudos, a intervenção não se restringe aos medicamentos tópicos, tendo sido empregados procedimentos cirúrgicos e a _laser_ . Neste Protocolo estão preconizadas condutas medicamentosas e procedimentos cirúrgicos.

---

<!-- METADADOS: doenca: Glaucoma | secao: **7.1. Tratamento medicamentoso** -->
Os fármacos mais usados na redução da PIO são, em sua maioria, tópicos, na forma de colírio, e podem ser classificados em cinco categorias principais: betabloqueadores, parassimpaticomiméticos, agonistas alfa-adrenérgicos, inibidores da anidrase carbônica e análogos das prostaglandinas e prostamidas.

---

<!-- METADADOS: doenca: Glaucoma | secao: **Betabloqueadores** -->
Os betabloqueadores tópicos são uma das principais classes farmacológicas utilizadas no tratamento do glaucoma. Seu mecanismo de ação baseia-se na redução da produção do humor aquoso por meio da atuação nos processos ciliares, na perfusão capilar e na inibição da produção de monofosfato cíclico de adenosina (AMPc) estimulada pelas catecolaminas<sup>8</sup> .  
Os betabloqueadores não seletivos (timolol, levobunolol, metipranolol, carteolol, pindolol) são antagonista beta-1 e beta2 adrenérgico e reduzem a PIO em média em 25%, ao passo que os beta-1 seletivos (betaxolol, metoprolol) possuem ação hipotensora menos marcada<sup>11,157</sup> . Por isso, os betabloqueadores não seletivos são preferíveis, pois são mais efetivos. O timolol é o mais estudado, apresentando evidência de melhor qualidade da sua eficácia hipotensora entre os betabloqueadores não seletivos, sendo considerado a primeira escolha de tratamento em diversos países. Diversos estudos confirmaram a eficácia da monoterapia nos pacientes glaucomatosos. Por sua vez, o levobunolol e o metipranolol estão disponíveis comercialmente, porém são de custo mais elevado e evidência de eficácia hipotensora mais restrita. O carteolol não está disponível no Brasil<sup>80</sup> .  
Com o tratamento contínuo, a resposta a estes medicamentos, em muitos pacientes, pode decrescer por meio de dois fenômenos distintos. O escape em curto prazo ocorre em pacientes que obtiveram diminuição importante da PIO após o início do medicamento. Transcorridos alguns dias de uso, há elevação da PIO, que se mantém em platô. Dessa forma, convém aguardar um mês para determinar a resposta ao tratamento. O escape em longo prazo ocorre entre três meses e um ano após a introdução de timolol. A interrupção temporária e a reintrodução do medicamento podem, em alguns casos, fazer a eficácia hipotensora ser retomada<sup>8,160–165</sup> .  
O maleato de timolol é comumente agregado a outras classes de medicamentos a fim de retardar a progressão do glaucoma. Em associação aos inibidores da anidrase carbônica, aos agonistas alfa-adrenérgicos e às prostaglandinas e  
8  
prostamidas, o maleato de timolol tem efeito aditivo hipotensor, podendo ser associado a qualquer classe de medicamentos, com eficácia comprovada em diferentes estudos<sup>8,158,160–170</sup> .

---

<!-- METADADOS: doenca: Glaucoma | secao: **Parassimpaticomiméticos** -->
Os parassimpaticomiméticos, também chamados de mióticos ou colinérgicos, foram os primeiros medicamentos a serem utilizados no tratamento do glaucoma. O principal representante da classe é a pilocarpina. Seu mecanismo de ação hipotensora baseia-se no aumento do escoamento do humor aquoso por contração da musculatura ciliar e deslocamento do esporão escleral, aumentando os espaços de drenagem intertrabeculares. A pilocarpina reduz o escoamento uveoescleral, podendo aumentar a PIO em olhos dependentes dessa via para drenagem do humor aquoso. Após a instilação, a concentração máxima no humor aquoso é atingida em 20 minutos, com redução média de 20% na PIO. A pilocarpina apresenta efeito hipotensor; entretanto, o alto índice de eventos adversos limita a sua indicação<sup>8,171</sup> .

---

<!-- METADADOS: doenca: Glaucoma | secao: **Agonistas alfa-adrenérgicos** -->
Os agonistas alfa-adrenérgicos são utilizados no tratamento do glaucoma há várias décadas. A brimonidina, que apresenta seletividade para os receptores alfa-2, praticamente substituiu os fármacos não seletivos. Essa seletividade proporciona menos eventos adversos relacionados aos medicamentos mais antigos. O estímulo dos receptores alfa-adrenérgicos está associado a menor produção do humor aquoso por vasoconstrição e redução do fluxo sanguíneo do corpo ciliar. Os alfa-agonistas reduzem a PIO tanto pela diminuição da produção de humor aquoso quanto pelo aumento da drenagem pela via uveoescleral<sup>8,171,172</sup> .  
A brimonidina é um agente efetivo no tratamento crônico do glaucoma. Para a obtenção do máximo efeito hipotensor ocular, recomenda-se sua utilização três vezes ao dia. Quando comparada aos demais medicamentos utilizados no tratamento do glaucoma, apresenta efeito hipotensor médio inferior às prostaglandinas, ao maleato de timolol e aos inibidores da anidrase carbônica. Seu uso está principalmente indicado após procedimentos em que há aumento súbito da PIO, como a iridotomia a _laser_ . Pode ser associada a qualquer classe de medicamentos tópicos, com efeito aditivo hipotensor, conforme orientações de tratamento deste Protocolo<sup>158,161–165,168,173–182</sup> .  
Além da redução da PIO, a brimonidina apresenta possível efeito neuroprotetor por meio da redução de perda das células ganglionares. Entretanto, ainda não há evidências que justifiquem seu uso com esse propósito<sup>183</sup> .

---

<!-- METADADOS: doenca: Glaucoma | secao: **Inibidores da anidrase carbônica** -->
Os inibidores da anidrase carbônica são divididos em sistêmicos e tópicos e são utilizados para o tratamento do glaucoma desde a década de 1950, com o advento da acetazolamida. Posteriormente, foram pesquisadas formas tópicas do medicamento, lançadas no mercado mundial na década de 1990. A produção ativa de humor aquoso depende, em parte, da ação de enzimas que causam hidratação de dióxido de carbono, resultando em bicarbonato. Esse processo é dependente da enzima anidrase carbônica, presente nas células não pigmentadas do epitélio ciliar, o qual participa da formação do humor aquoso. Sua inibição está associada à redução da produção do humor aquoso e consequente diminuição da PIO<sup>8</sup> .  
A acetazolamida, medicamento de administração sistêmica, foi lançada como hipotensora ocular em 1954. Seu papel principal reside nas situações de emergência, quando a PIO está demasiadamente aumentada, tendo efeito mais rápido e efetivo<sup>8</sup> . Os inibidores da anidrase carbônica tópicos são a dorzolamida e a brinzolamida.  
A dorzolamida a 2% é recomendada na posologia de três vezes ao dia. A fim de aumentar a adesão ao tratamento, costuma ser prescrita na dose de duas vezes diárias. Reduz a PIO entre 14,7% a 27% após 2 horas e entre 12,9% a 17,5% após 8 horas. Em 24 horas, há redução média de 18% a 22%. Apresenta eficácia semelhante à do maleato de timolol a 0,5%, inferior à das prostaglandinas e superior à dos alfa-agonistas. Estudos mostraram que quando administrada duas vezes ao dia apresenta efeito aditivo na redução da PIO em pacientes usuários de timolol. A combinação fixa de timolol a 0,5% e dorzolamida a 2% está disponível comercialmente, com vários estudos demonstrando equivalência ao uso isolado dos fármacos e efeito hipotensor semelhante ao da monoterapia com prostaglandina<sup>8,158,162,165–169,174–176</sup> .  
9  
A brinzolamida a 1% apresenta eficácia semelhante à da dorzolamida. Em estudo comparativo entre os dois medicamentos, administrados três vezes ao dia, a média de redução da PIO foi de 20,1% para ambos<sup>8,184</sup> .  
**Análogos das prostaglandinas e prostamidas**  
Os análogos das prostaglandinas e, posteriormente, as prostamidas são os medicamentos mais recentes para o tratamento clínico do glaucoma. São derivados da prostaglandina F2alfa e atuam aumentando a atividade das metaloproteinases, o que leva a alterações na matriz extracelular, permitindo, assim, maior escoamento do humor aquoso através da via uveoescleral<sup>8</sup> . Os principais representantes dessa classe são latanoprosta, travoprosta e tafluprosta, análogos das prostaglandinas, e bimatoprosta, representante das prostamidas<sup>185–187</sup> .  
Essa classe de medicamentos é a de maior efeito hipotensor. É utilizada em dose única noturna, pois a maioria dos estudos demonstra superioridade em relação à dose única matinal. Quando associados ao maleato de timolol, são utilizadas igualmente em dose única noturna, com efeito semelhante ao do uso isolado de ambos os medicamentos. Podem ser associados a qualquer classe de medicamentos, otimizando o controle pressórico no paciente glaucomatoso dada sua significativa eficácia.  
A latanoprosta a 0,005% foi a primeira prostaglandina de uso clínico para tratamento do glaucoma. É utilizada em dose única noturna, diminuindo a PIO média em torno de 30%. Paralelamente à sua eficácia no tratamento de hipertensos oculares e de glaucomatosos, foi também analisada em pacientes pediátricos e em doentes de glaucomas primários de ângulo fechado, com resultados positivos em ambos os grupos. Apresenta eficácia hipotensora semelhante à da combinação de dorzolamida e timolol<sup>185</sup> .  
A travoprosta a 0,004% é similar à latanoprosta, com alguns estudos sugerindo maior eficácia da primeira na redução da PIO em indivíduos de pele preta, quando comparados com os de pele branca. A bimatoprosta a 0,03% é similar à latanoprosta, causando maior hiperemia conjuntival e menor incidência de cefaleia e pigmentação iriana<sup>160,166,167,169,170,174–176,181,188–201</sup> .  
A tafluprosta é inferior às demais prostaglandinas já incluídas no PCDT (bimatoprosta, latanoprosta e travoprosta) e semelhante ao timolol<sup>202</sup> .  
O tratamento do glaucoma comumente exige a associação de medicamentos, que possuem efeito aditivo no impedimento da progressão da doença<sup>9,59,75,80,81,157,158,160–169,173–178,193</sup> . No entanto, o uso das apresentações em associações em doses fixas de colírios não está previsto neste PCDT por não existirem evidências que englobem análise adequada de custo-efetividade.

---

<!-- METADADOS: doenca: Glaucoma | secao: **7.1.1. Tratamento medicamentoso por critérios de gravidade da doença** -->
Após a confirmação diagnóstica, a definição do tratamento deverá observar os critérios de gravidade da doença. **Critérios de gravidade menores**<sup>9,75,80,81</sup> **:**  
- PIO de 21 a 26 mmHg na ausência de medicamento antiglaucomatoso;  
- Alargamento da escavação (relação entre o diâmetro da escavação e o diâmetro do disco) do disco óptico entre 0,5 e

---

<!-- METADADOS: doenca: Glaucoma | secao: 0,8; **e** -->
- Alteração no campo visual compatível com glaucoma sem comprometimento dos 10 graus centrais em nenhum dos  
- olhos.

---

<!-- METADADOS: doenca: Glaucoma | secao: **Critérios de gravidade maiores**<sup>9,75,80,81</sup> **:** -->
- PIO acima de 26 mmHg na ausência de medicamento antiglaucomatoso;  
- Cegueira por dano glaucomatoso em um olho;  
- Alargamento da escavação do disco óptico acima de 0,8; **e**  
- Comprometimento em três ou mais quadrantes ou dano nos 10 graus centrais em um dos olhos.  
Como resposta ao tratamento medicamentoso, devem ser considerados:  
10  
- PIO alvo: pressão na qual não há progressão documentada do glaucoma, ou seja, não há aumento nem da escavação do  
- nervo óptico nem de dano no campo visual;  
- Falha primária: redução da PIO inferior a 10% com o uso do hipotensor ocular após 4 semanas do início do tratamento,  
**e** ;  
- Falha terapêutica: redução da PIO superior a 10% com impossibilidade de atingir a PIO alvo com o uso do hipotensor  
- ocular após 4 semanas do início do tratamento ou progressão documentada mesmo atingindo a PIO alvo inicial.  
O tratamento medicamentoso deve seguir os seguintes critérios:  
**Para monoterapia com timolol** :  
- Pacientes com dois ou mais critérios de gravidade menores; **ou**  
- Pacientes com um critério de gravidade menor e um critério de gravidade maior.  
**Para monoterapia com dorzolamida ou brinzolamida ou brimonidina (medicamentos de segunda linha):**  
- Falha primária ou contraindicação ou evento adverso ao timolol.  
**Para monoterapia com prostaglandina (ou latanoprosta ou bimatoprosta ou travoprosta):**  
- Dois ou mais critérios de gravidade maiores ou um maior e dois ou mais menores;  
- Falha primária ou terapêutica da associação de timolol e um medicamento de segunda linha (ou dorzolamida ou  
- brinzolamida ou brimonidina); **ou**  
- Falha primária ou terapêutica de medicamento de segunda linha (ou dorzolamida ou brinzolamida ou brimonidina).  
**Para uso da associação de timolol e medicamento de segunda linha (dorzolamida ou brinzolamida ou**  
**brimonidina):**  
- Falha terapêutica do timolol;  
- Falha primária com o uso de prostaglandina.  
**Para uso da associação de timolol e prostaglandina (latanoprosta ou bimatoprosta ou travoprosta):**  
- Falha terapêutica da monoterapia com prostaglandina.  
**Para uso da associação de medicamentos de segunda linha e prostaglandina:**  
- Falha terapêutica com monoterapia medicamentosa de segunda linha.  
Deve ser evitada a associação de dois medicamentos de segunda linha, independentemente do tipo de falha, substituindose a associação por monoterapia com prostaglandina. Caso o paciente tenha contraindicação ou falha primária com o uso de prostaglandina, deve-se tentar timolol com um ou mais medicamentos de segunda linha, desde que de classes diferentes. Se não for atingida a PIO alvo, deve-se considerar a intervenção cirúrgica. É possível a associação de dois ou mais fármacos, podendo o paciente utilizar as quatro classes disponíveis. Para tanto, deve-se seguir a sequência preconizada e observar a possibilidade de cirurgia.  
Pacientes com PIO elevada que aguardam a aplicação de _laser_ ou intervenção cirúrgica podem utilizar medicamentos adjuvantes, pela via oral, como acetazolamida, associada aos esquemas acima preconizados. O agente hiperosmótico manitol poderá ser utilizado, em âmbito hospitalar, em pacientes com PIO elevada (por exemplo, glaucoma de fechamento angular), pois é muito efetivo e reduz rapidamente a PIO. Por apresentar incidência elevada de eventos adversos, a pilocarpina fica reservada, da mesma forma que a acetazolamida, para pacientes com PIO elevada que aguardam a realização de procedimentos. Nos casos em que houver falha terapêutica com os medicamentos disponíveis, deve ser discutida a possibilidade de intervenção cirúrgica.  
Pacientes que já estão em tratamento e estão incluídos neste Protocolo devem seguir o esquema de tratamento proposto. Caso a doença esteja controlada (PIO alvo), o médico prescritor deve justificar o uso do medicamento de modo que o paciente  
11  
tenha passado pelas etapas previstas no Protocolo. Caso a doença não esteja controlada, o paciente deve iniciar o esquema da mesma forma que um paciente que não iniciou o uso de hipotensores.

---

<!-- METADADOS: doenca: Glaucoma | secao: **7.2. Tratamento cirúrgico** -->
A cirurgia antiglaucomatosa também pode ser considerada para controle da pressão ocular caso o tratamento clínico seja  
ineficaz ou intolerável ou caso não haja adesão do paciente ao tratamento medicamentoso.

---

<!-- METADADOS: doenca: Glaucoma | secao: **7.3. Fármacos** -->
- Acetazolamida: comprimido de 250 mg.  
- Bimatoprosta: solução oftálmica a 0,03%.  
- Brimonidina: solução oftálmica a 0,2%.  
- Brinzolamida: suspensão oftálmica a 1%.  
- Dorzolamida: solução oftálmica a 2%.  
- Latanoprosta: solução oftálmica a 0,005%.  
- <mark>Manitol: solução intravenosa a 20%.</mark>  
- Pilocarpina: solução oftálmica a 2%.  
- Timolol: solução oftálmica a 0,5%.  
- Travoprosta: solução oftálmica a 0,004%.

---

<!-- METADADOS: doenca: Glaucoma | secao: **7.4. Esquemas de administração** -->
- Acetazolamida: 1 comprimido via oral (VO) de até 6 em 6 horas.  
- Bimatoprosta a 0,03%: 1 gota no olho, 1 vez por dia (à noite).  
- Brimonidina a 0,2%: 1 gota no olho, 2 a 3 vezes ao dia (quando em monoterapia); se associada, 1 gota, 2 vezes ao  
dia.  
- Brinzolamida: 1 gota no olho, 2 a 3 vezes ao dia (quando em monoterapia); se associada, 1 gota, 2 vezes ao dia.  
- Dorzolamida: 1 gota no olho, 2 a 3 vezes ao dia (quando em monoterapia); se associada, 1 gota, 2 vezes ao dia.  
- Latanoprosta: 1 gota no olho, 1 vez por dia (à noite).  
- Manitol: 1,5 a 2 g/kg de peso por via intravenosa de 8 em 8 horas.  
- Pilocarpina: 1 gota no olho de 6 em 6 horas.  
- Timolol: 1 gota no olho, 2 vezes ao dia.  
- Travoprosta: 1 gota no olho, 1 vez por dia (à noite).

---

<!-- METADADOS: doenca: Glaucoma | secao: **7.5. Tempo de tratamento** -->
Como o glaucoma é uma doença incurável, o tratamento é contínuo, sem duração pré-determinada, o que exige um adequado acompanhamento oftalmológico. Quando o tratamento clínico é ineficaz, intolerável ou não conta com a adesão do paciente, a cirurgia antiglaucomatosa deve ser considerada para fins de controle da doença. Pode ser retirado algum hipotensor, caso seja obtido controle pressórico e estabelecida ausência de progressão da doença, ou seja, quando o dano ao nervo óptico consegue ser mantido e o campo visual permanece; porém, constatada a progressão da doença, o tratamento medicamentoso deve ser retomado<sup>9,14,75,80,81</sup> .  
12

---

<!-- METADADOS: doenca: Glaucoma | secao: **7.6. Benefícios esperados** -->
Espera-se que com o início da terapia hipotensora ou com o tratamento cirúrgico os pacientes obtenham diminuição da PIO até atingirem a PIO alvo.

---

<!-- METADADOS: doenca: Glaucoma | secao: **8. MONITORAMENTO** -->
O monitoramento do paciente é fundamental para o controle da doença. Como o glaucoma é uma afecção crônica, assintomática e com necessidade de uso de múltiplos medicamentos e, em alguns casos, de tratamento cirúrgico, a relação médico-paciente tem uma importância fundamental<sup>9,75,80,81</sup> . No **Quadro 1** estão apresentados os critérios preconizados para a peridocidade do acompanhamento dos pacientes com glaucoma.  
**Quadro 1** - Critérios preconizados para definir a periodicidade do acompanhamento<sup>9</sup> .  
|**PIO alvo**|**Progressão do**|**Duração do controle (em**|**Acompanhamento (em**|
|---|---|---|---|
|**atingida**|**dano**|**meses)**|**meses)**|
|Sim|Não|Igual ou inferior a 6|6|
|Sim|Não|Acima de 6|12|
|Sim|Sim|NA|1-2|
|Não|Sim|NA|1-2|
|Não|Não|NA|3-6|  
Legenda: NA = não se aplica; Duração do controle = tempo no qual o paciente teve a doença controlada, ou seja, sem progressão; Acompanhamento = intervalo de tempo máximo entre as avaliações.  
A avaliação consta do exame do paciente, da documentação do nervo óptico (preferencialmente com retinografia binocular colorida) e da campimetria visual. Pacientes com glaucoma avançado podem necessitar de avaliações mais frequentes. Os intervalos propostos para o acompanhamento correspondem ao tempo máximo preconizado entre as consultas oftalmológicas<sup>9,80</sup> .  
Além disso, devem ser observados os eventos adversos e contraindicações ao uso dos medicamentos preconizados neste Protocolo:  
- Timolol: os eventos adversos são divididos em oculares e sistêmicos. A toxicidade ocular manifesta-se por ceratopatia punctata, hipoestesia corneana, reações alérgicas e erosões corneanas recorrentes. A toxicidade sistêmica é mais frequente que a ocular. Com relação ao sistema cardiovascular, já foram descritos episódios de bradicardia, arritmia, infarto e síncope, todos relacionados à diminuição da contratilidade miocárdica pelo bloqueio dos receptores beta-1. Os efeitos respiratórios, como espasmos brônquicos e obstrução das vias respiratórias, estão relacionados à inibição dos receptores beta-2, que ocasiona contração da musculatura brônquica lisa. Os efeitos no sistema nervoso central também podem ocorrer, tendo sido citadas depressão, ansiedade, alucinações e sonolência. Efeitos diversos como alterações dermatológicas (alopecia e erupções maculopapulares) e gastrointestinais (náusea e vômitos) também são relatados<sup>8</sup> .  As contraindicações ao uso dos betabloqueadores são hipersensibilidade ou intolerância aos medicamentos, história de asma brônquica ou doença pulmonar obstrutiva grave, além de bradicardia sinusal, bloqueio atrioventricular de segundo e terceiro graus, choque cardiogênico e propensão a insuficiência cardíaca<sup>8</sup> .  
- Pilocarpina: os eventos adversos oculares com o uso de pilocarpina são comuns e podem interferir na qualidade de vida do paciente e na adesão ao tratamento. Espasmo no músculo ciliar pode ocasionar cefaleia frontal, que usualmente é autolimitada. Miose é um dos efeitos mais marcantes, podendo levar à formação de sinéquias posteriores e, raramente, à oclusão pupilar. A miopia é induzida pela acomodação por deslocamento anterior do cristalino, geralmente em jovens fácicos. Foi relatado um  
13  
efeito cataratogênico com o uso desse medicamento, além de descolamento de retina causado por tração vitreorretiniana. Cistos pigmentados de íris, buraco macular e toxicidade corneana também são eventos adversos descritos. Os eventos adversos sistêmicos são raros, representados pelo efeito muscarínico do fármaco em diferentes sistemas<sup>8,171</sup> . A pilocarpina é contraindicada para pacientes hipersensíveis ou intolerantes e para pacientes com uveítes anteriores ativas, _rubeosis iridis_ , bloqueio pupilar, glaucoma congênito e doença pulmonar avançada<sup>8,171</sup> .  
- Brimonidina: os eventos adversos mais comuns são alergia ocular, folículos conjuntivais e edema palpebral, os quais podem se manifestar até 18 meses após o início da terapia. Casos de uveíte anterior granulomatosa também foram descritos na literatura. Os efeitos sistêmicos incluem xerostomia, fadiga, sedação, sonolência e cefaleia, mais comuns nos extremos de idade. Por atravessar a barreira hematoencefálica e poder causar depressão pronunciada do sistema nervoso central, a brimonidina deve ser evitada em crianças com menos de 12 anos<sup>8,172</sup> . Está contraindicada para pacientes com hipersensibilidade ou intolerância ao tartarato de brimonidina ou a qualquer um dos componentes da fórmula, bem como para pacientes em tratamento com fármacos inibidores da monoamino oxidase (MAO)<sup>8,172</sup> .  
- Brinzolamida e dorzolamida: os inibidores da anidrase carbônica tópicos costumam causar poucos eventos adversos oculares, sendo o principal a blefaroconjuntivite alérgica. Sensação de gosto amargo, visão turva, dermatite periorbitária e reações de hipersensibilidade também foram descritas. Em pacientes com glaucoma primário ou hipertensão ocular, a espessura média corneana aumentou após o uso de dorzolamida, porém sem significância clínica. Em pacientes com córnea gutata, o uso de dorzolamida por pequeno período de tempo foi associado a um aumento estatisticamente significativo na espessura central corneana. Portanto, os inibidores da anidrase carbônica tópicos devem ser utilizados com cautela em pacientes com disfunção endotelial corneana<sup>8,172</sup> . Esses medicamentos estão contraindicados para pacientes com hipersensibilidade ou intolerância. Não é recomendado o uso concomitante de inibidores da anidrase carbônica tópicos com a administração por via oral.  
- Bimatoprosta, travoprosta e latanoprosta: os principais eventos adversos do uso dessa classe de medicamentos estão relacionados a efeitos locais (oculares e perioculares). Hiperemia ocular é a manifestação mais comum, sendo sua prevalência semelhante entre os análogos das prostaglandinas. É mais frequente nas prostamidas, possivelmente devido à afinidade aumentada aos receptores EP1 (hiperemia inflamatória), assim como pela maior concentração em relação aos demais medicamentos. Outros efeitos relatados são aumento da pigmentação iriana e periocular e do crescimento dos cílios. O estímulo da melanogênese é mais frequente com alguns dos medicamentos da classe e resulta em problemas mais estéticos do que desconfortáveis ou incapacitantes. Embora o aumento da pigmentação iriana seja permanente, o aumento da pigmentação periocular e o crescimento dos cílios revertem após a suspensão do medicamento. A principal preocupação quanto à toxicidade corneana, em olhos tratados com análogos de prostaglandina, relaciona-se aos pacientes com história de ceratite por herpes simples. Há relatos de casos em que houve reativação após o uso de latanoprosta e bimatoprosta. Portanto, é aconselhável iniciar tratamento hipotensor de outra classe nesses pacientes. Epiteliopatia dendrítica e erosões do epitélio corneano e sinais de toxicidade também foram descritos. Efeitos inflamatórios intraoculares também foram referidos: raros casos de uveíte anterior, responsivos à terapia esteroide, além de edema macular cistoide. Portanto, recomenda-se precaução em relação aos pacientes com glaucoma uveítico e àqueles com fatores de risco para a doença inflamatória retiniana. Os eventos adversos sistêmicos são praticamente inexistentes. Apesar disso, os medicamentos devem ser evitados em mulheres férteis que não usam contraceptivos ou em gestantes, pois não se sabe seu efeito na musculatura lisa uterina. Embora as concentrações plasmáticas sejam baixas, a possibilidade teórica de aborto não pode ser descartada. Esses medicamentos estão contraindicados para pacientes que apresentarem hipersensibilidade, contraindicação ou intolerância aos componentes da fórmula<sup>8,171,172</sup> .

---

<!-- METADADOS: doenca: Glaucoma | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso  
14  
e do acompanhamento pós-tratamento. Doentes de glaucoma devem ser atendidos em serviços especializados em oftamologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Quanto ao fornecimento dos colírios, o estabelecimento de saúde pode estar credenciado em uma das modalidades de habilitação em oftalmologia no SUS: sob o código 0506 - tratamento do glaucoma com medicamentos no âmbito da Política Nacional de Atenção Oftalmológica, no qual é o estabelecimento o responsável pelo fornecimento, ou sob o código 0508 - tratamento do glaucoma com medicamentos, cujo fornecimento se dá pelas secretarias estaduais de saúde, no âmbito do Componente Especializado da Assistência Farmacêutica (CEAF).  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo. Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Glaucoma | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.  
15

---

<!-- METADADOS: doenca: Glaucoma | secao: **11. REFERÊNCIAS** -->
1. van Buskirk EM, Cioffi GA. Glaucomatous optic neuropathy. Am J Ophthalmol. 1992;113(4):447–52.  
2. Quigley HA. Number of people with glaucoma worldwide. British journal of ophthalmology. 1996;80(5):389–93.  
3. Thylefors B, Negrel AD, Pararajasegaram R, Dadzie KY. Global data on blindness. Bulletin of the world health organization. 1995;73(1):115.  
4. Ghanem CC. Levantamento de casos de glaucoma em Joinville-Santa Catarina, 1984. Arq bras oftalmol. 1989;40–3. 5. Medina NH, Barros OM de, Muñoz E de H, Magdaleno RL, Barros AJD de, Ramos LR. Morbidade ocular em idosos da cidade de São Paulo-SP, Brasil. Arquivos Brasileiros de Oftalmologia. 1993;56:276–83.  
6. Sakata K, Sakata LM, Sakata VM, Santini C, Hopker LM, Bernardes R, et al. Prevalence of glaucoma in a South brazilian population: Projeto Glaucoma. Invest Ophthalmol Vis Sci. 2007;48(11):4974–9.  
7. Conselho Brasileiro de Oftalmologia. As Condições de Saúde Ocular no Brasil [Internet]. São Paulo: CBO. 2019 [cited 2022 Feb 22]. Available from: https://www.cbo.com.br/novo/publicacoes/condicoes_saude_ocular_brasil2019.pdf  
8. Allingham RR, Damji KF, Freedman SF, Moroi SE, Rhee DJ, Shields B. Shields Textbook of Glaucoma. 5th ed. Philadelphia: Lippincott Williams & Wilkins; 2005.  
9. American Academy of Ophthalmology. Primary Open-Angle Glaucoma Preferred Practice Pattern [Internet]. https://www.aaojournal.org/article/S0161-6420(20)31024-1/fulltext#relatedArticles; 2020 [cited 2021 Nov 6]. Available from: https://www.aaojournal.org/article/S0161-6420(20)31024-1/fulltext#relatedArticles  
10. Mitchell P, Smith W, Attebo K, Healey PR. Prevalence of open-angle glaucoma in Australia: the Blue Mountains Eye Study. Ophthalmology. 1996;103(10):1661–9.  
11. Leske MC, Connell AMS, Schachat AP, Hyman L. The Barbados Eye Study: prevalence of open angle glaucoma. Archives of ophthalmology. 1994;112(6):821–9.  
12. Quigley HA, West SK, Rodriguez J, Munoz B, Klein R, Snyder R. The prevalence of glaucoma in a population-based study of Hispanic subjects: Proyecto VER. Archives of ophthalmology. 2001;119(12):1819–26.  
13. Wensor MD, McCarty CA, Stanislavsky YL, Livingston PM, Taylor HR. The prevalence of glaucoma in the Melbourne Visual Impairment Project. Ophthalmology. 1998;105(4):733–9.  
14. Tielsch JM, Sommer A, Katz J, Royall RM, Quigley HA, Javitt J. Racial variations in the prevalence of primary openangle glaucoma: the Baltimore Eye Survey. Jama. 1991;266(3):369–74.  
15. Friedman DS, Jampel HD, Munoz B, West SK. The prevalence of open-angle glaucoma among blacks and whites 73 years and older: the Salisbury Eye Evaluation Glaucoma Study. Archives of ophthalmology. 2006;124(11):1625–30.  
16. Wolfs RCW, Klaver CCW, Ramrattan RS, van Duijn CM, Hofman A, de Jong PTVM. Genetic risk of primary openangle glaucoma: population-based familial aggregation study. Archives of ophthalmology. 1998;116(12):1640–5.  
17. Doshi V, Ying-Lai M, Azen SP, Varma R, Group LALES. Sociodemographic, family history, and lifestyle risk factors for open-angle glaucoma and ocular hypertension: the Los Angeles Latino Eye Study. Ophthalmology. 2008;115(4):639– 47.  
18. Tielsch JM, Katz J, Sommer A, Quigley HA, Javitt JC. Family history and risk of primary open angle glaucoma: the Baltimore Eye Survey. Archives of ophthalmology. 1994;112(1):69–73.  
19. Leske MC, Wu SY, Nemesure B, Hennis A, Group BES. Incident open-angle glaucoma and blood pressure. Archives of ophthalmology. 2002;120(7):954–9.  
20. Group EDPR. Prevalence of open-angle glaucoma among adults in the United States. Archives of ophthalmology. 2004;122(4):532.  
21. Hernández RA, Burr JM, Vale LD. Economic evaluation of screening for open-angle glaucoma. Int J Technol Assess Health Care. 2008;24(2):203–11.  
16  
22. Klein BEK, Klein R, Lee KE. Heritability of risk factors for primary open-angle glaucoma: the Beaver Dam Eye Study. Invest Ophthalmol Vis Sci. 2004;45(1):59–62.  
23. Bonomi L, Marchini G, Marraffa M, Bernardi P, Morbio R, Varotto A. Vascular risk factors for primary open angle glaucoma: the Egna-Neumarkt Study. Ophthalmology. 2000;107(7):1287–93.  
24. Mitchell P, Smith W, Chey T, Healey PR. Open-angle glaucoma and diabetes: the Blue Mountains eye study, Australia. Ophthalmology. 1997;104(4):712–8.  
25. Leske MC, Connell AMS, Wu SY, Hyman LG, Schachat AP. Risk factors for open-angle glaucoma: the Barbados Eye Study. Archives of ophthalmology. 1995;113(7):918–24.  
26. Mitchell P, Hourihan F, Sandbach J, Wang JJ. The relationship between glaucoma and myopia: the Blue Mountains Eye Study. Ophthalmology. 1999;106(10):2010–5.  
27. Wang JJ, Mitchell P, Smith W. Is there an association between migraine headache and open-angle glaucoma?: findings from the Blue Mountains Eye Study. Ophthalmology. 1997;104(10):1714–9.  
28. Broadway DC, Drance SM. Glaucoma and vasospasm. British Journal of Ophthalmology. 1998;82(8):862–70.  
29. Cursiefen C, Wisse M, Cursiefen S, Jünemann A, Martus P, Korth M. Migraine and tension headache in high-pressure and normal-pressure glaucoma. Am J Ophthalmol. 2000;129(1):102–4.  
30. Armaly MF, Krueger DE, Maunder L, Becker B, Hetherington J, Kolker AE, et al. Biostatistical analysis of the collaborative glaucoma study: I. Summary report of the risk factors for glaucomatous visual-field defects. Archives of ophthalmology. 1980;98(12):2163–71.  
31. Dielemans I, Vingerling JR, Algra D, Hofman A, Grobbee DE, de Jong PTVM. Primary open-angle glaucoma, intraocular pressure, and systemic blood pressure in the general elderly population: the Rotterdam Study. Ophthalmology. 1995;102(1):54–60.  
32. Mitchell P, Lee AJ, Rochtchina E, Wang JJ. Open-angle glaucoma and systemic hypertension: the blue mountains eye study. J Glaucoma. 2004;13(4):319–26.  
33. Gordon MO, Beiser JA, Brandt JD, Heuer DK, Higginbotham EJ, Johnson CA, et al. The Ocular Hypertension Treatment Study: baseline factors that predict the onset of primary open-angle glaucoma. Archives of ophthalmology. 2002;120(6):714–20.  
34. Shah S, Chatterjee A, Mathai M, Kelly SP, Kwartz J, Henson D, et al. Relationship between corneal thickness and measured intraocular pressure in a general ophthalmology clinic. Ophthalmology. 1999;106(11):2154–60.  
35. Whitacre MM, Stein RA, Hassanein K. The effect of corneal thickness on applanation tonometry. Am J Ophthalmol. 1993;115(5):592–6.  
36. Goldmann H, Schmidt TH. Applanation tonometry. Ophthalmologica. 1957;134(4):221–42.  
37. Ehlers N, Bramsen T, Sperling S. Applanation tonometry and central corneal thickness. Acta Ophthalmol. 1975;53(1):34–43.  
38. Stodtmeister R. Applanation tonometry and correction according to corneal thickness. Acta Ophthalmologica Scandinavica. 1998;76(3):319–24.  
39. Doughty MJ, Zaman ML. Human corneal thickness and its impact on intraocular pressure measures: a review and metaanalysis approach. Surv Ophthalmol. 2000;44(5):367–408.  
40. Medeiros FA, Sample PA, Zangwill LM, Bowd C, Aihara M, Weinreb RN. Corneal thickness as a risk factor for visual field loss in patients with preperimetric glaucomatous optic neuropathy. Am J Ophthalmol. 2003;136(5):805–13.  
41. Hahn S, Azen S, Ying-Lai M, Varma R, Group LALES. Central corneal thickness in Latinos. Invest Ophthalmol Vis Sci. 2003;44(4):1508–12.  
17  
42. Shimmyo M, Ross AJ, Moy A, Mostafavi R. Intraocular pressure, Goldmann applanation tension, corneal thickness, and corneal curvature in Caucasians, Asians, Hispanics, and African Americans. Am J Ophthalmol. 2003;136(4):603–13.  
43. Orssengo GJ, Pye DC. Determination of the true intraocular pressure and modulus of elasticity of the human cornea in vivo. Bull Math Biol. 1999;61(3):551–72.  
44. Dueker DK, Singh K, Lin SC, Fechtner RD, Minckler DS, Samples JR, et al. Corneal thickness measurement in the management of primary open-angle glaucoma: a report by the American Academy of Ophthalmology. Ophthalmology. 2007;114(9):1779–87.  
45. Francis BA, Varma R, Chopra V, Lai MY, Shtir C, Azen SP, et al. Intraocular pressure, central corneal thickness, and prevalence of open-angle glaucoma: the Los Angeles Latino Eye Study. Am J Ophthalmol. 2008;146(5):741–6.  
46. Liu J, Roberts CJ. Influence of corneal biomechanical properties on intraocular pressure measurement: quantitative analysis. Journal of Cataract & Refractive Surgery. 2005;31(1):146–55.  
47. Congdon NG, Broman AT, Bandeen-Roche K, Grover D, Quigley HA. Central corneal thickness and corneal hysteresis associated with glaucoma damage. Am J Ophthalmol. 2006;141(5):868–75.  
48. Tielsch JM, Katz J, Sommer A, Quigley HA, Javitt JC. Hypertension, perfusion pressure, and primary open-angle glaucoma: a population-based assessment. Archives of ophthalmology. 1995;113(2):216–21.  
49. Memarzadeh F, Ying-Lai M, Chung J, Azen SP, Varma R, Group LALES. Blood pressure, perfusion pressure, and openangle glaucoma: the Los Angeles Latino Eye Study. Invest Ophthalmol Vis Sci. 2010;51(6):2872–7.  
50. Chopra V, Varma R, Francis BA, Wu J, Torres M, Azen SP, et al. Type 2 diabetes mellitus and the risk of open-angle glaucoma: the Los Angeles Latino Eye Study. Ophthalmology. 2008;115(2):227–32.  
51. Bonovas S, Peponis V, Filioussi K. Diabetes mellitus as a risk factor for primary open‐angle glaucoma: a meta‐analysis. Diabetic medicine. 2004;21(6):609–14.  
52. Dielemans I, de Jong PTVM, Stolk R, Vingerling JR, Grobbee DE, Hofman A. Primary open-angle glaucoma, intraocular pressure, and diabetes mellitus in the general elderly population: the Rotterdam Study. Ophthalmology. 1996;103(8):1271–5.  
53. Le A, Mukesh BN, McCarty CA, Taylor HR. Risk factors associated with the incidence of open-angle glaucoma: the visual impairment project. Invest Ophthalmol Vis Sci. 2003;44(9):3783–9.  
54. Pasquale LR, Kang JH, Manson JE, Willett WC, Rosner BA, Hankinson SE. Prospective study of type 2 diabetes mellitus and risk of primary open-angle glaucoma in women. Ophthalmology. 2006;113(7):1081–6.  
55. de Voogd S, Ikram MK, Wolfs RCW, Jansonius NM, Witteman JCM, Hofman A, et al. Is diabetes mellitus a risk factor for open-angle glaucoma?: The Rotterdam Study. Ophthalmology. 2006;113(10):1827–31.  
56. Klein BEK, Klein R, Jensen SC. Open-angle glaucoma and older-onset diabetes: the Beaver Dam Eye Study. Ophthalmology. 1994;101(7):1173–7.  
57. Nakamura M, Kanamori A, Negi A. Diabetes mellitus as a risk factor for glaucomatous optic neuropathy. Ophthalmologica. 2005;219(1):1–10.  
58. Vijaya L, George R, Paul PG, Baskaran M, Arvind H, Raju P, et al. Prevalence of open-angle glaucoma in a rural south Indian population. Invest Ophthalmol Vis Sci. 2005;46(12):4461–7.  
59. Ophthalmology IC of. ICO Guidelines for Glaucoma Eye Care 2015 [Internet]. 2015. Available from: http://www.icoph.org/enhancing_eyecare/glaucoma.html  
60. Dielemans I, Vingerling JR, Wolfs RCW, Hofman A, Grobbee DE, de Jong PTVM. The prevalence of primary openangle glaucoma in a population-based study in the Netherlands: the Rotterdam Study. Ophthalmology. 1994;101(11):1851–5.  
18  
61. Sommer A, Tielsch JM, Katz J, Quigley HA, Gottsch JD, Javitt J, et al. Relationship between intraocular pressure and primary open angle glaucoma among white and black Americans: the Baltimore Eye Survey. Archives of ophthalmology. 1991;109(8):1090–5.  
62. Leibowitz HM, Krueger DE, Maunder LR, Milton RC, Kini MM, Kahn HA, et al. The Framingham Eye Study monograph: An ophthalmological and epidemiological study of cataract, glaucoma, diabetic retinopathy, macular degeneration, and visual acuity in a general population of 2631 adults, 1973-1975. Surv Ophthalmol. 1980;24(Suppl):335–610.  
63. Klein BEK, Klein R, Sponsel WE, Franke T, Cantor LB, Martone J, et al. Prevalence of glaucoma: the Beaver Dam eye study. Ophthalmology. 1992;99(10):1499–504.  
64. Weih LM, Nanjan M, McCarty CA, Taylor HR. Prevalence and predictors of open-angle glaucoma: results from the visual impairment project. Ophthalmology. 2001;108(11):1966–72.  
65. Nouri-Mahdavi K, Hoffman D, Coleman AL, Liu G, Li G, Gaasterland D, et al. Predictive factors for glaucomatous visual field progression in the Advanced Glaucoma Intervention Study. Ophthalmology. 2004;111(9):1627–35.  
66. Asrani S, Zeimer R, Wilensky J, Gieser D, Vitale S, Lindenmuth K. Large diurnal fluctuations in intraocular pressure are an independent risk factor in patients with glaucoma. J Glaucoma. 2000;9(2):134–42.  
67. Caprioli J, Coleman AL. Intraocular pressure fluctuation: a risk factor for visual field progression at low intraocular pressures in the Advanced Glaucoma Intervention Study. Ophthalmology. 2008;115(7):1123–9.  
68. Nouri-Mahdavi K, Medeiros FA, Weinreb RN. Fluctuation of intraocular pressure as a predictor of visual field progression. Archives of Ophthalmology. 2008;126(8):1168–9.  
69. Sommer A, Tielsch JM, Katz J, Quigley HA, Gottsch JD, Javitt JC, et al. Racial differences in the cause-specific prevalence of blindness in east Baltimore. New England journal of medicine. 1991;325(20):1412–7.  
70. Varma R, Ying-Lai M, Francis BA, Nguyen BBT, Deneen J, Wilson MR, et al. Prevalence of open-angle glaucoma and ocular hypertension in Latinos: the Los Angeles Latino Eye Study. Ophthalmology. 2004;111(8):1439–48.  
71. Rotchford AP, Johnson GJ. Glaucoma in Zulus: a population-based cross-sectional survey in a rural district in South Africa. Archives of ophthalmology. 2002;120(4):471–8.  
72. Rotchford AP, Kirwan JF, Muller MA, Johnson GJ, Roux P. Temba glaucoma study: a population-based cross-sectional survey in urban South Africa. Ophthalmology. 2003;110(2):376–82.  
73. Duggal P, Klein AP, Lee KE, Iyengar SK, Klein R, Bailey-Wilson JE, et al. A genetic contribution to intraocular pressure: the beaver dam eye study. Invest Ophthalmol Vis Sci. 2005;46(2):555–60.  
74. Mitchell P, Rochtchina E, Lee AJ, Wang JJ. Bias in self-reported family history and relationship to glaucoma: the Blue Mountains Eye Study. Ophthalmic Epidemiol. 2002;9(5):333–45.  
75. NICE. The National Institute for Health and Care Excellence. Glaucoma: diagnosis and management (NG81) [Internet]. 2017. Available from: https://www.nice.org.uk/guidance/ng81/resources/glaucoma-diagnosis-and-management-pdf1837689655237  
76. Jonas JB, Gusek GC, Naumann GO. Optic disc, cup and neuroretinal rim size, configuration and correlations in normal eyes. Invest Ophthalmol Vis Sci. 1988;29(7):1151–8.  
77. Kahn HA, Milton RC. Alternative definitions of open-angle glaucoma: effect on prevalence and associations in the Framingham Eye Study. Archives of Ophthalmology. 1980;98(12):2172–7.  
78. Hoffmann EM, Zangwill LM, Crowston JG, Weinreb RN. Optic disk size and glaucoma. Surv Ophthalmol. 2007;52(1):32–49.  
79. Budde WM, Jonas JB, Martus P, Gründler AE. Influence of optic disc size on neuroretinal rim shape in healthy eyes. J Glaucoma. 2000;9(5):357–62.  
19  
80. Sociedade Brasileira de Glaucoma. III Consenso Brasileiro de Glaucoma Primário de Ângulo Aberto [Internet] [Internet]. 2009 [cited 2022 Jan 31]. Available from: https://www.sbglaucoma.org.br/wpcontent/uploads/2020/06/consenso03-v2.pdf  
81. European Glaucoma Society. Terminology and Guidelines for Glaucoma [Internet] [Internet]. 2014 [cited 2022 Jan 31]. Available from: http://bjo.bmj.com/content/bjophthalmol/101/4/1.full.pdf  
82. Sihota R, Srinivasan G, Dada T, Gupta V, Ghate D, Sharma A. Is the ISNT rule violated in early primary open-angle glaucoma—a scanning laser tomography study. Eye. 2008;22(6):819–24.  
83. Miller KM, Quigley HA. The clinical appearance of the lamina cribrosa as a function of the extent of glaucomatous optic nerve damage. Ophthalmology. 1988;95(1):135–8.  
84. Susanna Jr R. The lamina cribrosa and visual field defects in open-angle glaucoma. Can J Ophthalmol. 1983;18(3):124– 6.  
85. Kubota T, Jonas JB, Naumann GO. Direct clinico-histological correlation of parapapillary chorioretinal atrophy. British journal of ophthalmology. 1993;77(2):103–6.  
86. Primrose J. Peripapillary changes in glaucoma. Am J Ophthalmol. 1977;83(6):930-.  
87. Sonas JB, Fernandez MC, Naumann COH. Glaucomatous optic nerve atrophy in small discs with low cup-to-disc ratios. Ophthalmology. 1990;97(9):1211–5.  
88. Tezel G, Kolker AE, Wax MB, Kass MA, Gordon M, Siegmund KD. Parapapillary chorioretinal atrophy in patients with ocular hypertension: II. An evaluation of progressive changes. Archives of ophthalmology. 1997;115(12):1509–14.  
89. Tezel G, Kolker AE, Kass MA, Wax MB, Gordon M, Siegmund KD. Parapapillary chorioretinal atrophy in patients with ocular hypertension: I. An evaluation as a predictive factor for the development of glaucomatous damage. Archives of ophthalmology. 1997;115(12):1503–8.  
90. Jonas JB, Naumann GO. Parapapillary chorioretinal atrophy in normal and glaucoma eyes. II. Correlations. Invest Ophthalmol Vis Sci. 1989;30(5):919–26.  
91. Jonas JB, Nguyen XN, Gusek GC, Naumann GO. Parapapillary chorioretinal atrophy in normal and glaucoma eyes. I. Morphometric data. Invest Ophthalmol Vis Sci. 1989;30(5):908–18.  
92. Drance S, Anderson DR, Schulzer M, Group CNTGS. Risk factors for progression of visual field abnormalities in normal-tension glaucoma. Am J Ophthalmol. 2001;131(6):699–708.  
93. Jonas JB. Clinical implications of peripapillary atrophy in glaucoma. Curr Opin Ophthalmol. 2005;16(2):84–8.  
94. Tezel G, Kass MA, Kolker AE, Wax MB. Comparative optic disc analysis in normal pressure glaucoma, primary openangle glaucoma, and ocular hypertension. Ophthalmology. 1996;103(12):2105–13.  
95. Sutton GE, Motolko MA, Phelps CD. Baring of a circumlinear vessel in glaucoma. Archives of Ophthalmology. 1983;101(5):739–44.  
96. Osher RH, Herschler J. The significance of baring of the circumlinear vessel: a prospective study. Archives of Ophthalmology. 1981;99(5):817–8.  
97. Jonas JB, Gusek GC, Naumann GO. Qualitative morphologic characteristics of normal and glaucomatous optic papillae. Klinische Monatsblatter fur Augenheilkunde. 1988;193(5):481–8.  
98. Hitchings RA, Spaeth GL. Chronic retinal vein occlusion in glaucoma. British Journal of Ophthalmology. 1976;60(10):694–9.  
99. Susanna R, Drance SM, Douglas GR. The visual prognosis of the fellow eye in uniocular chronic open-angle glaucoma. British Journal of Ophthalmology. 1978;62(5):327–9.  
100. Jonas JB, Nguyen XN, Naumann GO. Parapapillary retinal vessel diameter in normal and glaucoma eyes. I. Morphometric data. Invest Ophthalmol Vis Sci. 1989;30(7):1599–603.  
20  
101. Siegner SW, Netland PA. Optic disc hemorrhages and progression of glaucoma. Ophthalmology. 1996;103(7):1014–24.  
102. Jonas JB, Xu L. Optic disk hemorrhages in glaucoma. Am J Ophthalmol. 1994;118(1):1–8.  
103. Heijl A. Studies on computerized perimetry. Acta Ophthalmol Suppl. 1977;132(1-42).  
104. Anderson DR PV. Automated static perimetry. St Louis: Mosby. 1999;  
105. Lynn JR; Feltman RL; Starita RJ. Principles of perimetry. In: Rich R, Shields MB, Krupin T. The Glaucomas. St Louis: Mosby; 1996.  
106. Susanna Jr R, FA M. Perimetria computadorizada: interpretação e discussão de casos. Rio de Janeiro: Cultura Médica. 2001;  
107. Advanced Glaucoma Intervention Study. Advanced Glaucoma Intervention Study: 2. Visual field test scoring and reliability. Ophthalmology. 1994;101(8):1445–55.  
108. Schimiti RB CV. Perimetria computadorizada - um guia básico de interpretação. Rio de Janeiro: Guanabara Koogan; 2000.  
109. Anderson DR PV. Automated static perimetry. St Louis: Mosby; 1992 p 76-161.  
110. Caprioli J SM. Patterns of early visual field loss in open angle glaucoma. In: Greve EL, Heijl A. Springer Netherlands: Seventh International Visual Field Symposium - Documenta Ophthalmologica Proceedings Series 49; 1987.  
111. Katz J, Sommer A, Gaasterland DE, Anderson DR. Comparison of analytic algorithms for detecting glaucomatous visual field loss. Archives of ophthalmology. 1991;109(12):1684–9.  
112. Chauhan BC, Garway-Heath DF, Goñi FJ, Rossetti L, Bengtsson B, Viswanathan AC, et al. Practical recommendations for measuring rates of visual field change in glaucoma. British Journal of Ophthalmology. 2008;92(4):569–73.  
113. Musch DC, Lichter PR, Guire KE, Standardi CL, Group CS. The Collaborative Initial Glaucoma Treatment Study: study design, methods, and baseline characteristics of enrolled patients. Ophthalmology. 1999;106(4):653–62.  
114. Johnson CA, Adams AJ, Casson EJ, Brandt JD. Progression of early glaucomatous visual field loss as detected by blueon-yellow and standard white-on-white automated perimetry. Archives of Ophthalmology. 1993;111(5):651–6.  
115. Sample PA, Taylor JDN, Martinez GA, Lusky M, Weinreb RN. Short-wavelength color visual fields in glaucoma suspects at risk. Am J Ophthalmol. 1993;115(2):225–33.  
116. Landers JA, Goldberg I, Graham SL. Detection of early visual field loss in glaucoma using frequency-doubling perimetry and short-wavelength automated perimetry. Archives of ophthalmology. 2003;121(12):1705–10.  
117. Quigley HA. Identification of glaucoma-related visual field abnormality with the screening protocol of frequency doubling technology. Am J Ophthalmol. 1998;125(6):819–29.  
118. Maddess T, Goldberg I, Dobinson J, Wine S, Welsh AH, James AC. Testing for glaucoma with the spatial frequency doubling illusion. Vision Research. 1999;39(25):4258–73.  
119. Johnson CA, Samuels SJ. Screening for glaucomatous visual field loss with frequency-doubling perimetry. Investigative Ophthalmology & Visual Science. 1997;38(2):413–25.  
120. Giuffrè I. Frequency doubling technology vs standard automated perimetry in ocular hypertensive patients. The Open Ophthalmology Journal. 2009;3:6.  
121. Medeiros FA, Sample PA, Weinreb RN. Frequency doubling technology perimetry abnormalities as predictors of glaucomatous visual field loss. Am J Ophthalmol. 2004;137(5):863–71.  
122. Iwase A, Tomidokoro A, Araie M, Shirato S, Shimizu H, Kitazawa Y, et al. Performance of frequency-doubling technology perimetry in a population-based prevalence survey of glaucoma: the Tajimi study. Ophthalmology. 2007;114(1):27–32.  
21  
123. Mansberger SL, Edmunds B, Johnson CA, Kent KJ, Cioffi GA. Community visual field screening: prevalence of followup and factors associated with follow-up of participants with abnormal frequency doubling perimetry technology results. Ophthalmic Epidemiol. 2007;14(3):134–40.  
124. Medeiros FA, Zangwill LM, Bowd C, Vessani RM, Susanna Jr R, Weinreb RN. Evaluation of retinal nerve fiber layer, optic nerve head, and macular thickness measurements for glaucoma detection using optical coherence tomography. Am J Ophthalmol. 2005;139(1):44–55.  
125. Schuman JS, Hee MR, Puliafito CA, Wong C, Pedut-Kloizman T, Lin CP, et al. Quantification of nerve fiber layer thickness in normal and glaucomatous eyes using optical coherence tomography: a pilot study. Archives of ophthalmology. 1995;113(5):586–96.  
126. Williams ZY, Schuman JS, Gamell L, Nemi A, Hertzmark E, Fujimoto JG, et al. Optical coherence tomography measurement of nerve fiber layer thickness and the likelihood of a visual field defect. Am J Ophthalmol. 2002;134(4):538–46.  
127. Bowd C, Zangwill LM, Berry CC, Blumenthal EZ, Vasile C, Sanchez-Galeana C, et al. Detecting early glaucoma by assessment of retinal nerve fiber layer thickness and visual function. Invest Ophthalmol Vis Sci. 2001;42(9):1993–2003.  
128. Zangwill LM, Bowd C, Berry CC, Williams J, Blumenthal EZ, Sánchez-Galeana CA, et al. Discriminating between normal and glaucomatous eyes using the Heidelberg retina tomograph, GDx nerve fiber analyzer, and optical coherence tomograph. Archives of ophthalmology. 2001;119(7):985–93.  
129. Michelessi M, Lucenteforte E, Oddone F, Brazzelli M, Parravano M, Franchi S, et al. Optic nerve head and fibre layer imaging for diagnosing glaucoma. Cochrane Database of Systematic Reviews. 2015;(11).  
130. Kansal V, Armstrong JJ, Pintwala R, Hutnik C. Optical coherence tomography for glaucoma diagnosis: An evidence based meta-analysis. PLoS One. 2018;13(1):e0190621.  
131. Wu Z, Weng DSD, Rajshekhar R, Ritch R, Hood DC. Effectiveness of a qualitative approach toward evaluating OCT imaging for detecting glaucomatous damage. Transl Vis Sci Technol. 2018;7(4):7.  
132. Wan KH, Lam AKN, Leung CKS. Optical coherence tomography angiography compared with optical coherence tomography macular measurements for detection of glaucoma. JAMA Ophthalmol. 2018;136(8):866–74.  
133. BRASIL. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias e Inovação em Saúde – Conitec. Ampliação de uso do exame de Tomografia de Coerência Óptica para confirmação diagnóstica do glaucoma [Internet].  
2021 [cited 2022 Feb 9]. Available from: http://conitec.gov.br/images/Consultas/Relatorios/2020/20201113_Relatorio_de_Recomendacao_571_OCT.pdf  
134. BRASIL. Ministério da Saúde. Portaria SCTIE/MS n<sup>o</sup> 51, de 11 de novembro de 2020. Torna pública a decisão de ampliar o uso do exame de Tomografia de Coerência Óptica para confirmação diagnóstica de glaucoma, no âmbito do Sistema Único de Saúde - SUS. [Internet]. Ministério da Saúde. 2020 [cited 2022 Feb 9]. Available from: http://conitec.gov.br/images/Relatorios/Portaria/2020/20201113_Portaria_SCTIE_51.pdf  
135. Morgan JE, Sheen NJL, North RV, Choong Y, Ansari E. Digital imaging of the optic nerve head: monoscopic and stereoscopic analysis. British Journal of Ophthalmology. 2005;89(7):879–84.  
136. Sommer A, Quigley HA, Robin AL, Miller NR, Katz J, Arkell S. Evaluation of nerve fiber layer assessment. Archives of Ophthalmology. 1984;102(12):1766–71.  
137. Zelefsky JR, Harizman N, Mora R, Ilitchev E, Tello C, Ritch R, et al. Assessment of a race-specific normative HRT-III database to differentiate glaucomatous from normal eyes. Journal of Glaucoma. 2006;15(6):548–51.  
138. Toth M, Hollo G. Enhanced corneal compensation for scanning laser polarimetry on eyes with atypical polarisation pattern. British Journal of Ophthalmology. 2005;89(9):1139–42.  
22  
139. Medeiros F de AA. Comparação de métodos de imagem do disco óptico e da camada de fibras nervosas da retina para o diagnóstico do glaucoma. Universidade de São Paulo; 2005.  
140. Greaney MJ, Hoffman DC, Garway-Heath DF, Nakla M, Coleman AL, Caprioli J. Comparison of optic nerve imaging methods to distinguish normal eyes from those with glaucoma. Invest Ophthalmol Vis Sci. 2002;43(1):140–5.  
141. DeLeón-Ortega JE, Arthur SN, McGwin G, Xie A, Monheit BE, Girkin CA. Discrimination between glaucomatous and nonglaucomatous eyes using quantitative imaging devices and subjective optic nerve head assessment. Invest Ophthalmol Vis Sci. 2006;47(8):3374–80.  
142. Badalà F, Nouri-Mahdavi K, Raoof DA, Leeprechanon N, Law SK, Caprioli J. Optic disk and nerve fiber layer imaging to detect glaucoma. Am J Ophthalmol. 2007;144(5):724–32.  
143. Vessani RM, Moritz R, Batis L, Zagui RB, Bernardoni S, Susanna R. Comparison of quantitative imaging devices and subjective optic nerve head assessment by general ophthalmologists to differentiate normal from glaucomatous eyes. Journal of Glaucoma. 2009;18(3):253–61.  
144. Reus NJ, de Graaf M, Lemij HG. Accuracy of GDx VCC, HRT I, and clinical assessment of stereoscopic optic nerve head photographs for diagnosing glaucoma. British Journal of Ophthalmology. 2007;91(3):313–8.  
145. Grødum K, Heijl A, Bengtsson B. Refractive error and glaucoma. Acta Ophthalmol Scand. 2001;79(6):560–6.  
146. Xu L, Wang Y, Wang S, Wang Y, Jonas JB. High myopia and glaucoma susceptibility: the Beijing Eye Study. Ophthalmology. 2007;114(2):216–20.  
147. Wong TY, Klein BEK, Klein R, Knudtson M, Lee KE. Refractive errors, intraocular pressure, and glaucoma in a white population. Ophthalmology. 2003;110(1):211–7.  
148. Ramakrishnan R, Nirmalan PK, Krishnadas R, Thulasiraj RD, Tielsch JM, Katz J, et al. Glaucoma in a rural population of southern India: the Aravind comprehensive eye survey. Ophthalmology. 2003;110(8):1484–90.  
149. Suzuki Y, Iwase A, Araie M, Yamamoto T, Abe H, Shirato S, et al. Risk factors for open-angle glaucoma in a Japanese population: the Tajimi Study. Ophthalmology. 2006;113(9):1613–7.  
150.  
- Nemesure B, Leske MC. Glaucoma and myopia. Ophthalmology. 2000;107(6):1026–7.  
151. Kuzin AA, Varma R, Reddy HS, Torres M, Azen SP, Group LALES. Ocular biometry and open-angle glaucoma: the Los Angeles Latino Eye Study. Ophthalmology. 2010;117(9):1713–9.  
152. Fingert JH, Héon E, Liebmann JM, Yamamoto T, Craig JE, Rait J, et al. Analysis of myocilin mutations in 1703 glaucoma patients from five different populations. Hum Mol Genet. 1999;8(5):899–905.  
153. Gong G, Kosoko-Lasaki O, Haynatzki GR, Wilson MR. Genetic dissection of myocilin glaucoma. Hum Mol Genet. 2004;13(suppl_1):R91–102.  
154. Kwon YH, Fingert JH, Kuehn MH, Alward WLM. Primary open-angle glaucoma. New England Journal of Medicine. 2009;360(11):1113–24.  
155.  
- Wiggs JL. Genetic etiologies of glaucoma. Archives of ophthalmology. 2007;125(1):30–7.  
156. Sociedade Brasileira de Glaucoma. II Consenso Brasileiro de Glaucoma Primário de Ângulo Fechado [Internet] [Internet]. 2012 [cited 2022 Feb 2]. Available from: https://www.sbglaucoma.org.br/wpcontent/uploads/2020/06/consenso04-v2.pdf  
157. Chen R, Yang K, Zheng Z, Ong ML, Wang NL, Zhan SY. Meta-analysis of the efficacy and safety of latanoprost monotherapy in patients with angle-closure glaucoma. Journal of Glaucoma. 2016;25(3):e134–44.  
158. Dakin HA, Welton NJ, Ades AE, Collins S, Orme M, Kelly S. Mixed treatment comparison of repeated measurements of a continuous endpoint: an example using topical treatments for primary open‐angle glaucoma and ocular hypertension. Stat Med. 2011;30(20):2511–35.  
23  
159. Rouse B, Cipriani A, Shi Q, Coleman AL, Dickersin K, Li T. Network meta-analysis for clinical practice guidelines: a case study on first-line medical therapies for primary open-angle glaucoma. Ann Intern Med. 2016;164(10):674–82.  
160. Cox JA, Mollan SP, Bankart J, Robinson R. Efficacy of antiglaucoma fixed combination therapy versus unfixed components in reducing intraocular pressure: a systematic review. British journal of ophthalmology. 2008;92(6):729– 34.  
161. Fung AT, Reid SE, Jones MP, Healey PR, McCluskey PJ, Craig JC. Meta-analysis of randomised controlled trials comparing latanoprost with brimonidine in the treatment of open-angle glaucoma, ocular hypertension or normal-tension glaucoma. British journal of ophthalmology. 2007;91(1):62–8.  
162. Craven ER, Walters TR, Williams R, Chou C, Cheetham JK, Schiffman R, et al. Brimonidine and timolol fixedcombination therapy versus monotherapy: a 3-month randomized trial in patients with glaucoma or ocular hypertension. Journal of Ocular Pharmacology & Therapeutics. 2005;21(4):337–48.  
163. Spaeth GL, Bernstein P, Caprioli J, Schiffman RM. Control of Intraocular Pressure and Fluctuation With FixedCombination Brimonidine–Timolol Versus Brimonidine or Timolol Monotherapy. Am J Ophthalmol. 2011;151(1):93– 9.  
164. Loon SC, Liew G, Fung A, Reid SE, Craig JC. Meta‐analysis of randomized controlled trials comparing timolol with brimonidine in the treatment of glaucoma. Clinical & Experimental Ophthalmology. 2008;36(3):281–9.  
165. Cheng JW, Li Y, Wei RL. Systematic review of intraocular pressure-lowering effects of adjunctive medications added to latanoprost. Ophthalmic Research. 2009;42(2):99–105.  
166. Bron AM, Emmerich KH. Latanoprost versus combined timolol and dorzolamide. Surv Ophthalmol. 2002;47:S148–54.  
167. Cheng JW, Xi GL, Wei RL, Cai JP, Li Y. Efficacy and tolerability of latanoprost compared to dorzolamide combined with timolol in the treatment of patients with elevated intraocular pressure: a meta-analysis of randomized, controlled trials. Journal of ocular pharmacology and therapeutics. 2009;25(1):55–64.  
168. Tanna AP, Rademaker AW, Stewart WC, Feldman RM. Meta-analysis of the efficacy and safety of α2-adrenergic agonists, β-adrenergic antagonists, and topical carbonic anhydrase inhibitors with prostaglandin analogs. Archives of ophthalmology. 2010;128(7):825–33.  
169. Webers CAB, van der Valk R, Schouten JSAG, Zeegers MP, Prins MH, Hendrikse F. Intraocular Pressure–Lowering Effect of Adding Dorzolamide or Latanoprost to Timolol: A Meta-analysis of Randomized Clinical Trials. Ophthalmology. 2007;114(1):40–6.  
170. Webers CAB, Beckers HJM, Zeegers MP, Nuijts RMMA, Hendrikse F, Schouten JSAG. The intraocular pressurelowering effect of prostaglandin analogs combined with topical β-blocker therapy: a systematic review and metaanalysis. Ophthalmology. 2010;117(11):2067–74.  
171. Mello PAA, de Almeida GV de AH. Glaucoma primário de ângulo aberto. Rio de Janeiro: Guanabara Koogan. 2011;  
172. Kanski JJ; Bowling B. Clinical Ophthalmology: a systematic approach. Philadelphia: Elsevier Saunders. 2011;  
173. Vass C, Hirn C, Sycha T, Findl O, Sacu S, Bauer P, et al. Medical interventions for primary open angle glaucoma and ocular hypertension. Cochrane Database of Systematic Reviews. 2007;(4).  
174. van der Valk R, Webers CAB, Schouten JSAG, Zeegers MP, Hendrikse F, Prins MH. Intraocular pressure–lowering effects of all commonly used glaucoma drugs: a meta-analysis of randomized clinical trials. Ophthalmology. 2005;112(7):1177–85.  
175. van der Valk R, Webers CAB, Lumley T, Hendrikse F, Prins MH, Schouten JSAG. A network meta-analysis combined direct and indirect comparisons between glaucoma drugs to rank effectiveness in lowering intraocular pressure. J Clin Epidemiol. 2009;62(12):1279–83.  
24  
176. Stewart WC, Konstas AGP, Nelson LA, Kruft B. Meta-analysis of 24-hour intraocular pressure studies evaluating the efficacy of glaucoma medicines. Ophthalmology. 2008;115(7):1117–22.  
177. Cheng JW, Cai JP, Wei RL. Meta-analysis of medical intervention for normal tension glaucoma. Ophthalmology. 2009;116(7):1243–9.  
178. Hodge WG, Lachaine J, Steffensen I, Murray C, Barnes D, Foerster V, et al. The efficacy and harm of prostaglandin analogues for IOP reduction in glaucoma patients compared to dorzolamide and brimonidine: a systematic review. British Journal of Ophthalmology. 2008;92(1):7–12.  
179. Tsai JC, Chang HW. Comparison of the effects of brimonidine 0.2% and timolol 0.5% on retinal nerve fiber layer thickness in ocular hypertensive patients: a prospective, unmasked study. Journal of Ocular Pharmacology & Therapeutics. 2005;21(6):475–82.  
180. Marchetti A, Magar R, An P, Nichol M. Clinical and economic impact of new trends in glaucoma treatment. Medgenmed: Medscape General Medicine. 2001;3(4):6.  
181. Einarson TR, Kulin NA, Tingey D, Iskedjian M. Meta-analysis of the effect of latanoprost and brimonidine on intraocular pressure in the treatment of glaucoma. Clin Ther. 2000;22(12):1502–15.  
182. Sultan MB, Mansberger SL, Lee PP. Understanding the importance of IOP variables in glaucoma: a systematic review. Surv Ophthalmol. 2009;54(6):643–62.  
183. Sena DF, Lindsley K. Neuroprotection for treatment of glaucoma in adults. Cochrane Database of Systematic Reviews. 2017;(1).  
184. Rouland JF, le Pen C, Pinto CG, Berto P, Berdeaux G. Cost-minimisation study of dorzolamide versus brinzolamide in the treatment of ocular hypertension and primary open-angle glaucoma in four European countries. Pharmacoeconomics. 2003;21(3):201–13.  
185. Li SM, Chen R, Li Y, Yang ZR, Deng QJ, Zhong Z, et al. Meta-analysis of randomized controlled trials comparing latanoprost with timolol in the treatment of Asian populations with chronic angle-closure glaucoma. PLoS One. 2014;9(5):e96852.  
186. Daka Q, Trkulja V. Efficacy and tolerability of monocompound topical treatments for reduction of intraocular pressure in patients with primary open angle glaucoma or ocular hypertension: an overview of reviews. Croatian Medical Journal. 2014;55(5):468–80.  
187. Lin L, Zhao YJ, Chew PTK, Sng CCA, Wong HT, Yip LW, et al. Comparative efficacy and tolerability of topical prostaglandin analogues for primary open-angle glaucoma and ocular hypertension. Annals of Pharmacotherapy. 2014;48(12):1585–93.  
188. Aptel F, Cucherat M, Denis P. Efficacy and tolerability of prostaglandin analogs: a meta-analysis of randomized controlled clinical trials. J Glaucoma. 2008;17(8):667–73.  
189. Cheng JW, Xi GL, Wei RL, Cai JP, Li Y. Effects of travoprost in the treatment of open-angle glaucoma or ocular hypertension: A systematic review and meta-analysis. Current therapeutic research. 2009;70(4):335–50.  
190. Guedes RAP, Guedes VMP, Chaoubah A. Custo-efetividade dos análogos de prostaglandinas no Brasil. Revista Brasileira de Oftalmologia. 2008;67:281–6.  
191. Guedes RAP, Guedes VMP, Borges JL, Chaoubah A. Avaliação econômica das associações fixas de prostaglandina/prostamida e timolol no tratamento do glaucoma e da hipertensão ocular. Revista Brasileira de Oftalmologia. 2010;69:236–40.  
192. Luu KT, Raber SR, Nickens DJ, Vicini P. A model‐based meta‐analysis of the effect of latanoprost chronotherapy on the circadian intraocular pressure of patients with glaucoma or ocular hypertension. Clinical Pharmacology & Therapeutics. 2010;87(4):421–5.  
25  
193. Orme M, Collins S, Dakin H, Kelly S, Loftus J. Mixed treatment comparison and meta-regression of the efficacy and safety of prostaglandin analogues and comparators for primary open-angle glaucoma and ocular hypertension. Curr Med Res Opin. 2010;26(3):511–28.  
194. Li N, Chen X, Zhou Y, Wei M, Yao X. Travoprost compared with other prostaglandin analogues or timolol in patients with open‐angle glaucoma or ocular hypertension: meta‐analysis of randomized controlled trials. Clin Exp Ophthalmol. 2006;34(8):755–64.  
195. Goldberg LD, Walt J. Cost Considerations in the Medical Management of Glaucoma in the US. Pharmacoeconomics. 2006;24(3):251–64.  
196. Hedman K, Alm A. A pooled-data analysis of three randomized, double-masked, six-month clinical studies comparing the intraocular pressure reducing effect of latanoprost and timolol. Eur J Ophthalmol. 2000;10(2):95–104.  
197. Zhang WY, Po ALW, Dua HS, Azuara-Blanco A. Meta-analysis of randomised controlled trials comparing latanoprost with timolol in the treatment of patients with open angle glaucoma or ocular hypertension. British journal of ophthalmology. 2001;85(8):983–90.  
198. Varma R, Hwang LJ, Grunden JW, Bean GW, Sultan MB. Assessing the efficacy of latanoprost vs timolol using an alternate efficacy parameter: the intervisit intraocular pressure range. Am J Ophthalmol. 2009;148(2):221–6.  
199. Honrubia F, Garcia-Sánchez J, Polo V, de La Casa JMM, Soto J. Conjunctival hyperaemia with the use of latanoprost versus other prostaglandin analogues in patients with ocular hypertension or glaucoma: a meta-analysis of randomised clinical trials. British journal of ophthalmology. 2009;93(3):316–21.  
200. Eyawo O, Nachega J, Lefebvre P, Meyer D, Rachlis B, Lee CW, et al. Efficacy and safety of prostaglandin analogues in patients with predominantly primary open-angle glaucoma or ocular hypertension: a meta-analysis. Clinical Ophthalmology (Auckland, NZ). 2009;3:447.  
201. Eisenberg DL, Toris CB, Camras CB. Bimatoprost and travoprost: a review of recent studies of two new glaucoma drugs. Surv Ophthalmol. 2002;47:S105–15.  
202. Quaranta L, Biagioli E, Riva I, Rulli E, Poli D, Katsanos A, et al. Prostaglandin analogs and timolol-fixed versus unfixed combinations or monotherapy for open-angle glaucoma: a systematic review and meta-analysis. Journal of Ocular Pharmacology and Therapeutics. 2013;29(4):382–9.  
26

---

<!-- METADADOS: doenca: Glaucoma | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ACETAZOLAMIDA, BIMATOPROSTA, BRIMONIDINA, BRINZOLAMIDA, DORZOLAMIDA, LATANOPROSTA, PILOCARPINA, TIMOLOL, TRAVOPROSTA  
Eu,_________________________________________________________________________________________  
(nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **acetazolamida, bimatoprosta, brimonidina, brinzolamida, dorzolamida, latanoprosta,**  
**pilocarpina, timolol, travoprosta** , indicados para o tratamento de glaucoma.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a)  
(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- redução da pressão intraocular; ou  
- preservação da visão.  
Fui também informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- timolol, pilocarpina, acetazolamida, brimonidina, brinzolamida, dorzolamida, latanoprosta, bimatoprosta e travoprosta são classificados na gestação como categoria c, ou seja, as pesquisas em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos;  
- eventos adversos do timolol: irritação no olho, vermelhidão, lacrimejamento, sangramento no olho, dor ocular, erosões na córnea, reações alérgicas oculares, coceira, inchaço, conjuntivite, visão dupla ou borrada, inflamação das pálpebras, desconforto ou queimação após a aplicação do medicamento, sensação de corpo estranho, olho seco, sensibilidade à luz (fotofobia), dor de cabeça, depressão, desmaio, ansiedade, insônia, tontura, enjoos, vômitos, gosto amargo e secura na boca, coriza, pressão alta, dor, diminuição dos batimentos cardíacos (bradicardia), batimentos cardíacos descompassados (arritmia), infarto, desmaio (síncope), falta de ar (espasmos e obstrução das vias respiratórias), perda de cabelos (alopecia) e manchas pelo corpo (erupções maculopapulares);  
- eventos adversos da pilocarpina: irritação no olho, vermelhidão, lacrimejamento, sangramento no olho, dor ocular, erosões na córnea, reações alérgicas oculares, coceira, inchaço, conjuntivite, visão dupla ou borrada, inflamação das pálpebras, desconforto ou queimação após a aplicação do medicamento, sensação de corpo estranho, olho seco, sensibilidade à luz (fotofobia), dor de cabeça, pupila fechada (miose), turvamento da visão para longe (miopia), catarata, descolamento de retina e cistos oculares;  
- eventos adversos da acetazolamida: sensação de tremores (parestesias), dificuldade para ouvir (disfunção auditiva ou zumbido), perda da fome, alterações para sentir o sabor dos alimentos, enjoo, vômito e diarreia, urina em excesso (poliúria), sonolência e confusão, baixa de visão (miopia), alergia de pele (urticária), sangramento nas fezes e na urina, dificuldade na movimentação (paralisia flácida), sensibilidade à luz (fotossensibilidade) e convulsões; há também correlação com síndrome de stevens-johnson (formação de bolhas e com perda de regiões da pele e de mucosas), falta de funcionamento do fígado (insuficiência e necrose hepáticas) e diminuição das células do sangue (discrasia sanguínea);  
- eventos adversos da brimonidina: irritação no olho, vermelhidão, lacrimejamento, sangramento no olho, dor ocular, erosões na córnea, reações alérgicas oculares, coceira, inchaço, conjuntivite, visão dupla ou borrada, inflamação das pálpebras, desconforto ou queimação após a aplicação do medicamento, sensação de corpo estranho, olho seco, sensibilidade à luz  
27  
(fotofobia), dor de cabeça, depressão, desmaio, ansiedade, insônia, tontura, enjoo, vômitos, gosto amargo e secura na boca, coriza, pressão alta, dor e fraqueza muscular;  
- eventos adversos da dorzolamida: síndrome de stevens-johnson (formação de bolhas e perda de regiões da pele e de mucosas), inflamação no olho, irritação ocular, vermelhidão, lacrimejamento, dor ocular, reações alérgicas oculares, coceira, inchaço, conjuntivite, visão dupla ou borrada, inflamação das pálpebras, desconforto ou queimação após aplicação do medicamento, olho seco, sensibilidade à luz (fotofobia), dor de cabeça, tontura, necrose hepática fulminante, anemia ou outras alterações nas células sanguíneas, gosto amargo na boca e cansaço;  
- eventos adversos da brinzolamida: síndrome de stevens-johnson (formação de bolhas e perda de regiões da pele e de mucosas), dermatites, urticária, queda de cabelo (alopecia), sensação de corpo estranho no olho, vermelhidão, ceratite (vermelhidão, irritação e dor), lacrimejamento, dor ocular, reações alérgicas oculares (coceira, vermelhidão, inchaço), conjuntivite, visão dupla ou borrada, olho seco, inflamação das pálpebras, desconforto ou queimação após aplicação do medicamento, dor de cabeça, tontura, anemia ou outras alterações nas células sanguíneas, rinite, gosto amargo ou azedo na boca, dor nos rins, faringite, dor no peito e falta de ar;  
- eventos adversos da latanoprosta: aumento na pigmentação da íris e dos cílios, aumento do comprimento, da espessura e do número de cílios, visão dupla ou borrada, inflamação e inchaço no olho, olho seco, vermelhidão, dor e desconforto ocular, coceira, queimação, lacrimejamento, sensibilidade à luz (fotofobia), reações alérgicas, sensação de corpo estranho no olho, dor no peito, tosse, chiado no peito, dificuldade respiratória, infecções respiratórias, resfriado ou gripe, dor muscular, dor nas articulações e dor nas costas;  
- eventos adversos da travoprosta: dor e desconforto ocular, sensação de corpo estranho no olho, olho seco, coceira e vermelhidão, lacrimejamento, aumento da sensibilidade à luz (fotofobia), palpitações, dor no peito, tosse, dor de garganta, coriza, dor muscular, dor nas articulações, dor nas costas, indigestão, azia, sangue na urina, confusão, nervosismo, desmaios, febre, alterações de humor, dor para urinar, cansaço;  
- eventos adversos da bimatoprosta: visão borrada, diminuição da visão, diminuição das cores da visão, aumento na pigmentação da íris e da pele ao redor dos olhos, dificuldade de visão noturna, vermelhidão, dor e edema dos olhos e das pálpebras, coceira nos olhos, lacrimejamento, sensibilidade à luz (fotofobia) e sensação de corpo estranho no olho, febre, perda de força muscular, aumento do crescimento dos cabelos;  
- todos os medicamentos contraindicados em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula.  
Estou ciente de que esse(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvêlo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o(s) medicamento(s).  
Autorizo o Ministério da Saúde e as secretarias de saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (  ) sim (  ) não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
(   ) acetazolamida (   ) bimatoprosta (   ) brimonidina (   ) brinzolamida (   ) dorzolamida (   ) latanoprosta (   ) pilocarpina (   ) timolol  
(   ) travoprosta  
28  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
NOTA 1 - Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
NOTA 2 - Quanto ao fornecimento dos colírios, o estabelecimento de saúde pode estar credenciado em uma das modalidades de habilitação em oftalmologia no SUS: sob o código 0506 - tratamento do glaucoma com medicamentos no âmbito da Política Nacional de Atenção Oftalmológica, no qual é o estabelecimento o responsável pelo fornecimento, ou sob o código 0508 - tratamento do glaucoma com medicamentos, cujo fornecimento se dá pelas secretarias estaduais de saúde, no âmbito do Componente Especializado da Assistência Farmacêutica (CEAF).  
29  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Glaucoma | secao: METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA -->
**1. Atualização do Protocolo Clínico e Diretrizes Terapêuticas do Glaucoma após a ampliação de uso do exame de tomografia de coerência óptica**

---

<!-- METADADOS: doenca: Glaucoma | secao: **1.1. Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Glaucoma foi motivada pela ampliação de uso, no âmbito do SUS, do exame de tomografia de coerência óptica para confirmação diagnóstica de glaucoma por meio da Portaria SCTIE/MS nº 51, de 11 de novembro de 2020.

---

<!-- METADADOS: doenca: Glaucoma | secao: **1.2. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pela Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/CGGTS/DGITS/SECTICS/MS).

---

<!-- METADADOS: doenca: Glaucoma | secao: **1.3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT do Glaucoma foi apresentada na 96ª Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em fevereiro de 2022. A reunião teve a presença de representantes do então Departamento de Gestão, Incorporação e Inovação de Tecnologias em Saúde (DGITIS/SCTIE/MS), do então Departamento de Ciência e Tecnologia (DECIT/SCTIE/MS), do então Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS). Após a reunião da Subcomissão, o representante do DAET apontou a necessidade de alguns ajustes, os quais foram realizados antes que o documento fosse encaminhado para avaliação do Plenário da Conitec.

---

<!-- METADADOS: doenca: Glaucoma | secao: **1.4. Consulta Pública** -->
A Consulta Pública nº 09/2022, do Protocolo Clínico e Diretrizes Terapêuticas do Glaucoma, foi realizada entre os dias 28/03/2022 e 18/04/2022. Foram recebidas 60 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/assuntos/participacao-social/consultas-publicas/encerradas.</u>

---

<!-- METADADOS: doenca: Glaucoma | secao: **1.5. Busca da evidência** -->
Considerando a versão então vigente do PCDT do Glaucoma (Portaria Conjunta SAS-SCTIE/MS nº 11, de 02 de abril de  
2018), partiu-se deste documento base para a atualização do Protocolo. A estrutura metodológica da versão vigente foi mantida e acrescentados os dados referentes à atualização das tecnologias preconizadas, conforme Relatório de Recomendação nº 571, de outubro de 2020.  
**2. Atualização do Protocolo Clínico e Diretrizes Terapêuticas do Glaucoma – versão anterior (Portaria Conjunta SAS-SCTIE/MS nº 11, de 02 de abril de 2018)**  
- **2.1. Levantamento de informações para planejamento da reunião com especialistas**  
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), o sítio da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), o Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais do SUS (SIGTAP) e o Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Glaucoma então  
30  
vigente para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas. A partir das consultas realizadas, foi possível identificar:  
 O tratamento no SUS seguia o orientado no PCDT de Glaucoma, conforme Portaria SAS/MS nº 1.279, de 19 de novembro de 2013, retificada em 23 de janeiro de 2014;  
 Os medicamentos então disponíveis eram: colírios de timolol, dorzolamida, brinzolamida, brimonidina, latanoprosta, travoprosta, bimatoprosta e pilocarpina; comprimido de acetazolamida e solução intravenosa de manitol. Não havia solicitação de nenhuma nova tecnologia na Conitec.  
Na enquete pública realizada pelo Ministério da Saúde sobre o PCDT, a principal contribuição foi a necessidade de atualizar este Protocolo para guiar o tratamento dos pacientes com glaucoma.

---

<!-- METADADOS: doenca: Glaucoma | secao: **2.2. Reunião com especialistas** -->
Foi realizada reunião com o consultor especialista e metodologista do comitê elaborador, na qual foram apresentados os resultados do levantamento de informações realizado pelos metodologistas. O consultor especialista indicou a necessidade de avaliação de inclusão do medicamento tafluprosta e do método diagnóstico de tomografia de coerência óptica (TCO). Após a revisão da literatura, foi verificado que nenhum deles possui evidência suficiente para embasar o pedido de inclusão. A tafluprosta, análogo das prostaglandinas, é inferior às demais prostaglandinas já incluídas no PCDT (bimatoprosta, latanoprosta e travoprosta) e semelhante ao timolol.  
Assim, ficou estabelecido que o Protocolo se destinava a pacientes com glaucoma, ambos os sexos, sem restrição de idade, e tinha por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca do PCDT vigente.

---

<!-- METADADOS: doenca: Glaucoma | secao: **2.3. Buscas na literatura para atualização do PCDT** -->
A fim de guiar a revisão do PCDT então vigente, foram realizadas buscas na literatura sobre intervenções terapêuticas, diagnóstico e monitorização. Para a atualização do tratamento, foi estabelecida pergunta PICO ( **Quadro A** ). Posteriormente, foram elaboradas as estratégias de busca demonstradas no **Quadro B** .  
**Quadro A -** Pergunta PICO.  
|População|Pacientes com glaucoma|
|---|---|
|Intervenção|Tratamento medicamentoso|
|Comparação|Sem restrição de comparadores|
|Desfechos|Controle pressórico, preservação de campo visual, eventos adversos|
|Tipos de estudos|Meta-análises e revisões sistemáticas|  
**Quadro B** - Buscas sobre tratamento medicamentoso – Revisões sistemáticas e meta-análises.  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|MEDLINE (via|"Glaucoma"[Mesh] AND|37|1|
|PubMed)|"Therapeutics"[Mesh] AND ((Meta-||Motivo das exclusões: não abordaram|
|Data da busca:|Analysis[ptyp] OR systematic[sb]) AND||tratamento medicamentoso de glaucoma|
|27/03/2017|"2012/03/29"[PDat] : "2017/03/27"[PDat]<br>AND "humans"[MeSH Terms])|||
|EMBASE|'glaucoma'/exp AND 'therapy'/exp AND<br>([systematic review]/lim OR [meta|135|6<br>Motivos das exclusões: não abordaram<br>tratamento medicamentoso de glaucoma|  
31  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
||analysis]/lim) AND [humans]/lim AND||ou não eram revisões sistemáticas/meta-|
||[2012-2017]/py||análises|
|Cochrane Library|'glaucoma in Title, Abstract, Keywords ,|25|0|
||Publication Year from 2012 to 2017 in||Motivo das exclusões: não abordaram|
||Cochrane Reviews'||tratamento medicamentoso de glaucoma|  
<mark>Os artigos selecionados encontram-se na</mark> **<mark>Tabela A</mark>** <mark>. Foram encontradas 220 referências, das quais sete foram selecionadas conforme os critérios descritos acima. Da versão anterior do PCDT, 183 referências foram mantidas e as demais foram excluídas ou atualizadas.</mark>  
**<mark>Tabela A</mark>** <mark>– Estudos Selecionados</mark>  
32  
|**Estudo**|**Desenho**|**Amostra**|**População**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados/Conclusões**|**Limitações**|
|---|---|---|---|---|---|---|---|
|_Network Meta-_<br>_analysis for clinical_<br>_practice guidelines: A_<br>_case study on_<br>_first-line medical_<br>_therapies for primary_<br>_open-angle glaucoma_<br>Rouse et al, 2016|<br> <br>Meta-análise<br>- Período da busca:<br>1991-2014<br>- Bases consultadas:<br>MEDLINE,<br>EMBASE,<br>Cochrane<br>- Critérios de<br>elegibilidade:<br>ensaios clínicos<br>randomizados<br>(ECRs) que<br>compararam<br>tratamento para<br>glaucoma entre<br>monoterapia<br>medicamentosa e<br>placebo|- Número de<br>estudos incluídos:<br>91<br>- Número de<br>participantes:<br>34.349|Adultos com glaucoma<br>primário de ângulo<br>aberto com diferentes<br>níveis de gravidade|<br>- Intervenção:<br>betabloqueadores;<br>inibidores da<br>anidrase carbônica;<br>alfa-agonistas;<br>prostaglandinas<br>- Controle: placebo<br>- Tempo de uso: 3<br>meses<br>- Tempo de<br>seguimento pós-<br>tratamento: não há|- Primário: redução<br>da pressão<br>intraocular (PIO)|As principais reduções<br>(em IC95%) foram<br>comparadas ao placebo:<br>betabloqueadores, 4,01<br>(IC95% 0,48 a 7,43);<br>agonistas alfa-<br>adrenérgicos, 5,64<br>(IC95% 1,73 a 9,50);<br>prostaglandinas, 5,43<br>(IC95% 3,38 a 7,38);<br>prostaglandinas, 4,75<br>(IC95% 3,11 a 6,44);<br>prostaglandinas, 4,58<br>(IC95% 2,94 a 6,24).|Heterogeneidade de<br>estudos.|  
33  
|**Estudo**|**Desenho**|**Amostra**|**População**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados/Conclusões**|**Limitações**|
|---|---|---|---|---|---|---|---|
|_Meta-analysis of the_|Meta-análise|- Número de|Adultos com glaucom|a<br>- Intervenção:|Primário: medida d|a<br>Latanoprosta reduziu a|Heterogeneidade|
|_efficacy and safety of_<br>_latanoprost_<br>_monotherapy in_<br>_patients with angle-_|- Período da busca:<br>até abril de 2013|estudos incluídos:<br>17<br>- Número de|primário de<br>fechamento angular|latanoprosta: 1 gota<br>1x/dia<br>- Controle: timolol|PIO. Medidas<br>média, máxima e<br>mínima foram<br>usadas.|PIO média em 7,9<br>mmHg (32,4%), pico da<br>PIO em 7,4 mmHg<br>(29,8%) e PIO mínima|das populações.<br>Diferentes<br>comparações entre<br>latanoprosta e outro|
|_closure glaucoma_|- Bases consultadas:|participantes: 808||12/12h;||em 7,9mmHg (32,5%).|medicamento ou|
|Chen et al, 2016|EMBASE,<br>MEDLINE,<br>Cochrane Library,<br>Chinese Journal<br>Full-text Database<br>(CNKI), Chinese<br>Science and<br>Technology<br>Periodical Database<br>(VIP) e Wang Fang<br>- Critérios de<br>elegibilidade:<br>apenas estudos<br>envolvendo<br>pacientes com<br>glaucoma de<br>fechamento angular|||bimatoprosta<br>1x/dia;<br>travoprosta 1x/dia;<br>placebo 1x/dia;<br>timolol +<br>dorzolamida 12/12h<br>- Tempo de uso:<br>variável<br>- Tempo de<br>seguimento pós-<br>tratamento: não há|<br>Secundários:<br>incidência de<br>eventos adversos<br>sistêmicos e locais.|<br>O evento ocular adverso<br>mais frequente foi<br>hiperemia, seguida por<br>desconfortos e visão<br>turva<br>(9,4%, 8,7% e 5,2%,<br>respectivamente).<br>Eventos adversos<br>sistêmicos foram rinite,<br>tonturas, cefaleias e<br>pigmentação cutânea.|placebo.|  
34  
|**Estudo**|**Desenho**|**Amostra**|**População**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados/Conclusões**|**Limitações**|
|---|---|---|---|---|---|---|---|
||em monoterapia de<br>latanoprosta|||||||
|_Meta-analysis of_<br>_randomized_<br>_controlled trials_<br>_comparing_<br>_latanoprost with_<br>_timolol in the_<br>_treatment of Asian_<br>_populations with_<br>_chronic angle-_<br>_closure_<br>_Glaucoma._<br>Li et al, 2014|Meta-análise<br>- Período da busca:<br>até março de 2013<br>- Bases consultadas:<br>MEDLINE,<br>EMBASE, PubMed,<br>Cochrane Library,<br>Google Scholar e<br>diversas bases de<br>dados chinesas<br>- Critérios de<br>elegibilidade: (1)<br>estudos: ECRs;<br>(2) população:<br>pacientes com<br>glaucoma de|<br>- Número de<br>estudos incluídos:<br>7<br>- Número de<br>participantes: 685|<br>Adultos com glaucom<br>primário de<br>fechamento angular|a<br>- Intervenção:<br>latanoprosta 1x/dia<br>- Controle: timolol<br>12/12h<br>- Tempo de uso:<br>variável<br>- Tempo de<br>seguimento pós-<br>tratamento: variável|<br>Primário: redução<br>absoluta e relativa<br>da PIO partindo da<br>PIO pré-tratamento<br>e medindo mínima,<br>média e máxima.<br>Secundários:<br>eventos adversos<br>oculares e<br>sistêmicos.|Comparada ao timolol, a<br>latanoprosta teve uma<br>redução adicional na PIO<br>absoluta de 2,3 mmHg<br>(IC95% 1,8∼2,9,<br>P<0,01), 2,4 mmHg<br>(IC95% 1,9∼2,9,<br>P<0,01) e 2,5 mmHg<br>(IC95% 1,6∼3,3,<br>P<0,01) na média,<br>máxima e mínima. Para<br>a PIO relativa, os valores<br>foram de 9,0% (IC95%<br>6,6∼11,4, P<0,01), 9,7%<br>(IC95% 7,6∼11,8,<br>P<0,01) e 10,8% (IC95%<br>7,4∼14,3, P<0,01),<br>respectivamente. Mais<br>eventos oculares<br>adversos (OR = 1,49,|<br> <br> <br> <br> <br>Heterogeneidade<br>dos estudos.|  
35  
|**Estudo**|**Desenho**|**Amostra**|**População**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados/Conclusões**|**Limitações**|
|---|---|---|---|---|---|---|---|
||fechamento<br>angular;<br>(3) intervenção:<br>latanoprosta vs.<br>timolol em cada<br>grupo sem<br>combinação de<br>outros<br>medicamentos.|||||IC95% 1,05∼2,10, P =<br>0,02) e menos eventos<br>adversos sistêmicos (OR<br>= 0,46, IC95%<br>0,25∼0,84, P = 0,01)<br>foram observados na<br>latanoprosta comparada<br>ao timolol.||
|_Efficacy and_<br>_tolerability of mono -_<br>_compound topical_<br>_treatments for_<br>_reduction_<br>_of intraocular_<br>_pressure in patients_<br>_with primary open_<br>_angle glaucoma or_<br>_ocular hypertension:_<br>_An overview of_<br>_reviews_<br>Daka e Trkulja, 2014|<br>- Revisão<br>sistemática<br>- Período da busca:<br>até janeiro de 2014<br>- Bases consultadas:<br>PubMed, EMBASE<br>e Cochrane<br>- Critérios de<br>elegibilidade: (1)<br>revisões sistemáticas<br>com ou sem meta-<br>análises; (2) estudos|<br>- Número de<br>estudos incluídos:<br>16<br>- Número de<br>participantes:<br>44.338|Adultos com glaucoma<br>primário de ângulo<br>aberto ou hipertensão<br>ocular|<br>- Intervenção:<br>timolol 12/12h;<br>betaxolol 12/12h;<br>bimatoprosta 1x/dia;<br>travoprosta 1x/dia;<br>latanoprosta 1x/dia;<br>placebo 1x/dia;<br>dorzolamida<br>12/12h;<br>brimonidina 12/12h;<br>brinzolamida<br>12/12h.<br>- Tempo de uso:<br>variável|<br> <br> <br>- Primário: eficácia<br>e tolerabilidade dos<br>mais utilizados<br>hipotensores tópico<br>monocompostos em<br>pacientes com<br>glaucoma primário<br>de ângulo aberto e<br>hipertensão ocular|<br> <br>s<br> <br> <br>Não existe evidência de<br>grande qualidade sobre a<br>eficácia relativa e a<br>tolerabilidade dos<br>hipotensores usados em<br>glaucoma primário de<br>ângulo aberto e<br>hipertensão ocular.<br>Evidência de moderada<br>qualidade sugere a<br>latanoprosta como o<br>tratamento mais<br>favorável em relação aos<br>benefícios e aos riscos.|<br> <br> <br>Todas as conclusões<br>entre as<br>comparações de<br>tratamento são<br>baseadas em<br>evidências de<br>qualidade<br>moderada. Quando<br>esse nível de<br>qualidade não<br>estava disponível,<br>não foram feitas<br>conclusões.|  
36  
|**Estudo**|**Desenho**|**Amostra**|**População**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados/Conclusões**|**Limitações**|
|---|---|---|---|---|---|---|---|
||deveriam englobar<br>um mínimo de 85%<br>dos pacientes com<br>glaucoma primário<br>de ângulo aberto e<br>hipertensão ocular;<br>(3) estudos deveriam<br>avaliar eficácia e<br>segurança de<br>hipotensores tópicos<br>monocompostos.|||- Tempo de<br>seguimento pós-<br>tratamento: variável||||
|_Comparative Efficacy_<br>_and Tolerability of_<br>_Topical Prostaglandin_<br>_Analogues for_<br>_Primary Open-Angle_<br>_Glaucoma and Ocular_|<br> <br> <br>- Revisão<br>sistemática<br>- Período da busca:<br>1965-2013|- Número de<br>estudos incluídos:<br>32<br>- Número de<br>participantes:|Um total de<br>4.834 pacientes<br>recebendo PGA e<br>1.731 recebendo<br>timolol foram<br>incluídos.|- Intervenção:<br>bimatoprosta 1x/dia;<br>travoprosta 1x/dia;<br>latanoprosta 1x/dia;<br>tafluprosta 1x/dia;<br>prostaglandina|<br> <br>Primário: usando<br>timolol como<br>referência, foram<br>calculados os riscos<br>relativos (RRs) de<br>atingir o sucesso de|<br> <br>Os RRs (IC95%) foram<br>os seguintes:<br>bimatoprosta, 1,59 (1,28-<br>1,98); latanoprosta, 1,32<br>(1,00-1,74); travoprosta,<br>1,33 (1,03-1,72); e|<br>Heterogeneidade<br>dos estudos, como<br>população estudada,<br>tratamento e método<br>de medida da PIO.|
|_Hypertension_<br>Lin et al, 2014|- Bases consultadas:<br>PubMed e<br>Cochrane<br>- Critérios de<br>elegibilidade: foram<br>usadas as palavras-<br>chave hipertensão|4.834|Especificamente,1.247<br>(26%) pacientes<br>usavam bimatoprosta,<br>1.721 (36%) usavam<br>latanoprosta, 1.207<br>(25%) usavam<br>travoprosta, e 659|<br>+timolol 1x/dia.<br>- Tempo de uso: 1 a 6<br>meses<br>- Tempo de<br>seguimento pós-<br>tratamento: variável|<br> <br>tratamento, definido<br>como a proporção<br>de pacientes<br>atingindo ao menos<br>30% da redução da<br>PIO, com intervalo<br>de confiança de<br>95%.|<br> <br>tafluprosta, 1,10 (0,85-<br>1,42). A redução média<br>da PIO após um mês foi<br>de 1,98 (1,50-2,47), 1,01<br>(0,55-1,46), 1,08 (0,59-<br>1,57) e 0,46 (−0,41-1,33)<br>mmHg, respectivamente,|<br> <br>|  
37  
|**Estudo**|**Desenho**|**Amostra**|**População**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados/Conclusões**|**Limitações**|
|---|---|---|---|---|---|---|---|
||ocular, glaucoma de<br>ângulo aberto,<br>análogos de<br>prostaglandina,<br>bimatoprosta,<br>latanoprosta,<br>tafluprosta e<br>travoprosta.||(14%) usavam<br>tafluprosta.<br>A idade variou de 47 a<br>75 anos. A maioria era<br>branca (70%). Homens<br>eram 43% dos<br>participantes. A<br>maioria dos pacientes<br>apresentava glaucoma<br>de ângulo aberto<br>(53%).A PIO média<br>basal dos pacientes era<br>de 25,2 mmHg.|<br> <br> <br>|Secundários:<br>tolerabilidade aos<br>medicamentos.|e os resultados foram<br>mantidos aos 3 meses.<br>Bimatoprosta foi a mais<br>associada à hiperemia, e<br>latanoprosta foi a menos<br>relacionada, com RRs<br>(IC95%) de 4,66 (3,49-<br>6,23) e 2,30 (1,76-3,00),<br>respectivamente.|<br>|
|_Prostaglandin_<br>_analogs and timolol-_<br>_fixed versus unfixed_<br>_combinations or_|- Revisão<br>sistemática e meta-<br>análise|- Número de<br>estudos incluídos:<br>18|Homens e mulheres<br>com glaucoma de<br>ângulo aberto,<br>glaucoma crônico de|- Intervenção:<br>Travoprosta/timolol<br>1x/dia;<br>Bimatoprosta/timolol|<br>Primário: o<br>desfecho de eficácia<br>foi a diferença<br>média|<br>As formas fixas (FCs)<br>foram menos eficazes<br>que as não fixas (UCs)<br>(MeD: 0,69, IC95%:|Heterogeneidade<br>dos estudos, apesar<br>de a maioria<br>apresentar boa|
|_monotherapy for_<br>_open-angle glaucoma_<br>_A systematic review_<br>_and meta-analysis_<br>Quaranta et al, 2013|_:_<br>- Período da busca:<br>até fevereiro 2012<br>- Bases consultadas:<br>MEDLINE e<br>EMBASE|- Número de<br>participantes:<br>6.141|ângulo fechado e<br>hipertensão ocular<br>com diferentes níveis<br>de gravidade|1x/dia;<br>Latanoprosta/timolol<br>1x/dia;<br>Bimatoprosta<br>1x/dia;<br>Tavoprosta 1x/dia;<br>Latanoprosta 1x/dia;<br>Timolol 12/12h.|<br> <br>(MeD) na redução<br>da PIO basal.<br>Secundários:<br>tolerabilidade, com<br>desfecho de<br>hiperemia.|0,29 a 1,08). Comparada<br>ao timolol (Mt),<br>latanoprosta/timolol FC<br>reduziu mais a PIO<br>(MeD: -2,74, IC95%: -<br>3,24 a -2,23) do que<br>bimatoprosta/timolol FC<br>(MeD: -1,49, IC95%: -|<br> <br>qualidade<br>metodológica.|  
38  
|**Estudo**|**Desenho**|**Amostra**|**População**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados/Conclusões**|**Limitações**|
|---|---|---|---|---|---|---|---|
||- Critérios de<br>elegibilidade: (1)<br>pacientes com<br>hipertensão ocular,<br>glaucoma de ângulo<br>aberto de qualquer<br>idade, etnia ou<br>gênero; (2) aberto à<br>gonioscopia (3)<br>ausência de dano<br>glaucomatoso em<br>nervo óptico; e (4)<br>ausência de defeitos<br>de campo visual<br>compatíveis com<br>glaucoma. Pacientes<br>com glaucoma<br>crônico de ângulo<br>fechado também<br>foram incluídos.|||- Tempo de uso:<br>mínimo de 4<br>semanas<br>- Tempo de<br>seguimento pós-<br>tratamento: variável||1,86 a - 1,12) ou<br>travoprosta/timolol FC<br>(MeD: -1,93, IC95%: -<br>2,98 a -0,88). As FCs<br>tiveram menor risco de<br>hiperemia que as UCs<br>(RR: 0,70, IC95%: 0,43<br>a 1,14) e PGA Mt (RR:<br>0,61, IC95%: 0,53 a<br>0,70).||  
39

---

