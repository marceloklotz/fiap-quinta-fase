<!-- METADADOS: doenca: Retinopatia Diabética | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 17, DE 01 DE OUTUBRO DE 2021.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Retinopatia Diabética.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre a retinopatia diabética no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 613/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 618 – Maio de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Retinopatia Diabética.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da retinopatia diabética, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado</u> pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da retinopatia diabética.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
SERGIO YOSHIMASA OKANE  
HÉLIO ANGOTTI NETO  
1  
ANEXO

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1. INTRODUÇÃO** -->
A retinopatia diabética (RD) está entre as principais causas de perda de visão em pessoas entre 20 e 75 anos<sup>1</sup> . Trata-se de uma complicação microvascular na retina que afeta cerca de 1 em cada 3 pessoas  com diabete melito (DM) e que é de específica desta doença<sup>1</sup> . No Brasil, a incidência da RD é de 24% a 39% da população diabética, sendo estimado que tenha uma prevalência de 2 milhões de casos<sup>2</sup> . Após 20 anos de doença, estima-se que 90% dos diabéticos do tipo 1 (DM1) e 60% dos do tipo 2 (DM2) terão algum grau de RD<sup>3</sup> .  
Como a perda visual pode não estar presente nos estágios iniciais da retinopatia, o rastreamento oftalmológico de pessoas com diabete é essencial para permitir o diagnóstico e a intervenção precoce em caso de RD. Estudos internacionais indicam que o risco de cegueira pode ser reduzido para menos de 5%, se a RD for diagnosticada e tratada precocemente. Por outro lado, estima-se que 50% da RD proliferativa não tratada possa evoluir para cegueira em 5 anos. O tratamento com fotocoagulação a laser e, mais recentemente, a farmacoterapia intraocular podem reduzir ou mesmo prevenir a perda visual relacionada à RD<sup>4-7</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da retinopatia diabética. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E10 - Diabetes mellitus insulino-dependente  
- E11 - Diabetes mellitus não-insulino-dependente  
- E12 - Diabetes mellitus relacionado com a desnutrição  
- E13 - Outros tipos especificados de diabetes mellitus  
- E14 - Diabetes mellitus não especificado  
- H36.0 - Retinopatia diabética

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3. PREVENÇÃO E RASTREAMENTO** -->
Em pacientes com DM1 e DM2, a manutenção da hemoglobina glicada (HbA1c) a níveis < 7% é recomendada por ser capaz de reduzir o risco de progressão e incidência da RD e do edema macular diabético (EMD)<sup>8-18</sup> . É recomendada a manutenção da pressão sistólica abaixo de 130mmHg<sup>10,13-16,19</sup> , bem como a manutenção dos níveis de proteinúria < 30 mg/dL/24h, para a redução de progressão e incidência de RD e EMD<sup>13-15,20,21</sup> .  
A manutenção de um perfil lipídico dentro dos valores recomendados para os diabéticos também é recomendada com o objetivo de se reduzir o risco de desenvolvimento ou progressão do EMD<sup>22,23</sup> .  
O primeiro exame oftalmológico para o rastreamento de RD em pacientes com de DM1 deverá ser procedido em até 5 anos após a instalação da DM ou no início da puberdade. No doente de DM2, o exame oftalmológico deverá ser realizado imediatamente após o diagnóstico dessa doença. As avaliações deverão ocorrer  anualmente, ou em menor período, dependendo do estágio da retinopatia diabética. Gestantes com diabete deverão se submeter a exame oftalmológico trimestral<sup>24</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4. DIAGNÓSTICO** -->
É recomendado o uso dos métodos de oftalmoscopia binocular indireta e biomicroscopia de fundo, com a possibilidade de se  
associar a fotografia estereoscópica (retinografia), que possibilita o uso da telessaúde em locais de baixo ou nenhum acesso a oftalmologista<sup>25-71</sup> .  
**4.1 Diagnóstico Precoce**  
2  
O diagnóstico precoce da RD e seu adequado tratamento se justifica pela alta morbidade associada à doença quando diagnosticada em fases avançadas. O tratamento precoce e o acompanhamento regular podem reduzir o risco de cegueira provocado pela RD para menos de 5%<sup>4,6</sup> . Como já mencionado, cerca de 90% dos doentes de DM1 e 60% dos de DM2 terão algum grau de RD após 20 anos. Caso a RD não seja tratada, cerca de 50% dos doentes irão evoluir para cegueira em 5 anos<sup>5,7</sup> .  
Os entraves ao diagnóstico precoce da RD se iniciam pelo subdiagnóstico do DM na população geral. Além disso, há dificuldade de acesso a serviços oftalmológicos, o que dificulta o rastreamento da RD. Nesse sentido, o aumento do conhecimento geral por meio de estratégias educacionais que promovam a adoção de medidas preventivas para o DM e suas complicações podem ser capazes de melhorar tanto o diagnóstico quanto o início e a adesão ao tratamento precoce **.**

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4.2 Classificação da Retinopatia Diabética** -->
A classificação da retinopatia diabética sofreu uma contínua evolução, sendo atualmente universal e padronizada. A classificação modificada de Airlie House foi utilizada nos estudos _Diabetic Retinopathy Study_ (DRS) e _Early Treatment of Diabetic Retinopathy Study_ (ETDRS), caracterizando a retinopatia diabética não proliferativa (RDNP) e a proliferativa (RDP) em termos da ausência ou da presença de neovascularização de retina, respectivamente<sup>72-74</sup> . Buscando simplificar esta classificação, foi estabelecida a “Escala de Gravidade da Doença Retinopatia Diabética” baseada nos resultados do ETDRS e do _Wisconsin Epidemiologic Study of Diabetic Retinopathy_ (WESDR)<sup>75</sup> . Nesta escala simplificada, encontram-se cinco níveis de gravidade ( **Quadro 1** ).  
|**Quadro 1 -**Níveis degravidad|e da retinopatia e alterações observáveis ao exame de fundo de olho|
|---|---|
|**Nível de gravidade da retinopatia**|**Alterações observáveis à fundoscopia dilatada**|
|Sem retinopatia aparente|Sem alterações.|
|RDNP leve|Apenas microaneurismas.|
|RDNP moderada|Presença de microaneurismas, mas que ainda não caracterize RDNP grave.|
||Hemorragias intra-retinianas nos 4 quadrantes ou|
|RDNP grave com um dos critérios ao lado<br>RDNP muito grave com dois critérios|Alterações venosas em conta em 2 ou mais quadrantes ou|
||IRMA moderada em 1 ou mais quadrantes.|
|RDP|Neovascularização de disco ou de retina ou|
||Hemorragia vítrea ou pré-retiniana.|  
RDNP = Retinopatia Diabética não Proliferativa; IRMA = Alterações Microvasculares Intra-Retinianas; RDP = Retinopatia Diabética Proliferativa.  
O ETDRS define ainda a RDP de alto risco quando o olho apresenta neovascularização de disco (NVD) maior ou igual à fotografia padrão 10A, NVD menor associada a hemorragia vítrea ou pré-retiniana ou neovascularização fora do disco com pelo menos meia área de disco associada a hemorragia vítrea ou pré-retiniana<sup>75</sup> . Esta escala permite avaliar a história natural dos diferentes níveis de gravidade nos quais, por exemplo, metade dos olhos com RDNP grave vai progredir para RDP em 1 ano e 15%, para RDP de alto risco<sup>76</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4.2.1 Classificação do edema macular diabético** -->
_Edema Macular Clinicamente Significativo_ - A “Escala de Gravidade da Doença Retinopatia Diabética” não avalia a presença de edema macular, mas o ETDRS introduziu o conceito de edema macular clinicamente significativo (EMCS)<sup>76</sup> . O EMCS é caracterizado pela presença de:  
- (1) espessamento da retina em até 500 μm do centro da mácula;  
- (2) exsudato duro em até 500 μm do centro da mácula associado a espessamento da retina adjacente; ou  
- (3) uma zona de espessamento da retina de pelo menos 1.000 µm, qualquer parte dela dentro de 1.000 µm do centro da  
mácula.  
3  
_Edema macular focal e difuso_ – O edema macular diabético (EMD) pode também ser classificado, de acordo com a fonte de vazamento, em focal ou difuso<sup>77</sup> . Estudos clínicos com farmacoterapia não mostram diferença na resposta terapêutica entre casos de EMD focal ou difuso<sup>78</sup> .  
_Edema Macular Envolvendo o Centro_ – Com o advento da Tomografia de Coerência Óptica (TCO) e a possibilidade de medição objetiva da espessura retiniana, estudos clínicos mais recentes com farmacoterapia começaram a empregar o conceito de “Edema Macular Envolvendo o Centro”. Os estudos RIDE/RISE e MEAD utilizavam como critério de inclusão dos pacientes a presença de “Edema Macular Envolvendo o Centro”, com espessura do subcampo central foveal ≥ 275μm e ≥ 300μm, respectivamente, medido com TCO _time domain_<sup>_79,80_</sup> .  
_Edema macular com ou sem tração vítrea_ – O uso do TCO também possibilita classificar o edema macular em relação à morfologia predominante do edema e a presença de tração vítrea tangencial ou ântero-posterior<sup>81-83</sup> . Dessa forma, o edema pode ser tipo esponja, cístico ou na forma de líquido sub-retiniano com ou sem a presença de tração vítreo macular.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4.2.2 Exames complementares** -->
Os exames complementares são utilizados para auxílio ao diagnóstico e o monitoramento terapêutico da RD e suas complicações. Preconiza-se a avaliação completa da retina, incluindo a visualização estereoscópica do polo posterior e o exame da periferia da retina e do vítreo, em todas as consultas que tenham por finalidade o acompanhamento da RD<sup>84</sup> . O mapeamento da retina com pupila dilatada é preferencial para assegurar uma melhor avaliação do fundo do olho<sup>39</sup> .  
Inexistem critérios específicos, baseados em ensaios clínicos randomizados (ECR), para se determinar a frequência com que os exames complementares devem ser realizados. Preconiza-se o uso dos exames complementares quando houver suspeita de piora do quadro clínico, necessidade de planejar o tratamento ou quando julgado necessário para uma melhor compreensão do caso.  
A retinografia é um exame reprodutível que pode auxiliar na detecção e, principalmente, no monitoramento objetivo da gravidade da doença e em telemedicina. Este exame ainda é considerado o padrão ouro para documentar a gravidade da RD<sup>74</sup> .  
A angiofluoresceinografia (retinografia fluorescente binocular) não faz parte dos exames de rotina em caso de pacientes diabéticos, mas ela é eficiente e sensível para o diagnóstico de EMD e pode auxiliar no tratamento com fotocoagulação a laser<sup>51,85,86</sup> . As evidências provenientes dos estudos que avaliaram a angiofluoresceinografia não permitem definir a periodicidade de realização desse exame. Nos estudos clínicos pivotais RESTORE, VIVID e VISTA, que levaram à aprovação dos medicamentos antiangiogênicos para o tratamento do EMD, o exame de angiofluoresceinografia foi realizado semestralmente, mas não foi objetivo do estudo avaliar a periodicidade desse exame<sup>78,80,87</sup> . Portanto, ele deve ser solicitado em caráter complementar e se julgado medicamente necessário.  
Preconiza-se também o seu uso para casos em que se faz necessário avaliar o grau de isquemia central ou periférica como, por exemplo, de perda visual inexplicável, de não resposta visual ao tratamento do EMD, para auxílio na detecção de neovascularização retiniana ou de disco e de persistência de neovascularização após tratamento.  
O exame de TCO se tornou o padrão ouro complementar no diagnóstico do EMD que acomete o centro<sup>28,78-80,87-89</sup> . Preconizase o seu uso para diagnóstico do EMD que acomete o centro e como critério de tratamento ou retratamento. As evidências provenientes dos estudos disponíveis não permitem definir a periodicidade de realização desse exame. Nos estudos clínicos pivotais RESTORE, VIVID e VISTA, que levaram à aprovação dos medicamentos antiangiogênicos no tratamento do EMD, o exame de TCO era realizado mensalmente tanto em fases de esquema de tratamento fixo como em fases de esquema de tratamento quando necessário ( _as needed_ )<sup>78,80,86</sup> . A maioria dos outros ECR com esses medciamentos também estabeleceu o seguimento com exames mensais de TCO em fases desses dois esquemas terapêuticos<sup>90-94</sup> , porém outros estudos variaram essa periodicidade<sup>79,88,89,95,96</sup> . Desta forma, recomendase o uso do exame de TCO sempre que a avaliação clínica oftalmológica for insuficiente para se definir o tratamento ou retratamento ou quando for julgado necessário para uma melhor compreensão do caso.  
Indica-se a ultrassonografia ocular quando não é possível a adequada avaliação da retina devido a opacidades de meios, como catarata ou hemorragia vítrea<sup>97</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **5. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste PCDT pacientes com diabete melito tipo 1 e tipo 2.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **5.1 Critérios de inclusão para terapia anti-VEGF** -->
4  
O aflibercepte e o ranibizumabe são preconizados apenas para pacientes com edema macular diabético que envolve o centro da fóvea com qualquer grau de retinopatia diabética. O envolvimento do centro da fóvea é caracterizado por espessura do subcampo central foveal ≥ 275μm medido por tomografia de coerência óptica<sup>79,88,98</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **6. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos aqueles pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicação absoluta ao uso dos respectivos medicamentos ou procedimentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7. TRATAMENTO** -->
A conduta terapêutica depende da gravidade clínica da doença, assim classificada:  
- (a) Diabete melito sem ou com RD até grau moderado e sem EMD;  
(b) retinopatia diabética não proliferativa (RDNP) grave e muito grave sem edema macular e retinopatia diabética proliferativa (RDP) sem características de alto risco sem EMD;  
- (c) tratamento da retinopatia diabética proliferativa (RDP) de alto risco sem edema macular; e  
(d) edema macular diabético com qualquer grau de retinopatia diabética.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.1. Diabete sem ou com RD até grau moderado e sem EMD** -->
Para essa condição específica, após o primeiro exame, recomenda-se a adequação do controle glicêmico com manutenção da HbA1c < 7%, o acompanhamento a cada 12 meses ou de acordo com critérios clínicos. Para este fim, serão utilizados os métodos diagnósticos já mencionados.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.2. Retinopatia diabética não proliferativa (RDNP) grave e muito grave sem edema macular e a retinopatia diabética proliferativa (RDP) sem características de alto risco sem EMD** -->
O tratamento da RDNP grave e muito grave sem EMD e a RDP sem características de alto risco sem EMD são alocadas na mesma situação, pois elas apresentam o mesmo curso clínico, de acordo com o estudo do _Early Treatment of Diabetic Retinopathy Study_ (ETDRS). Esse estudo demonstrou que metade dos pacientes com RDNP grave vão desenvolver RDP de alto risco em um ano<sup>74</sup> . Em pacientes com RDNP muito grave, o risco de desenvolver RDP é de 75% em um ano, sendo que 45% serão de alto risco<sup>99</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.2.1. Fotocoagulação** -->
Os estudos do ETDRS mostraram que o tratamento com a fotocoagulação a laser deve ser indicado nos casos em que exista RDP de alto risco. Além disso, deve ser utilizado nos casos de RDNP grave ou muito grave em situações em que há dificuldade de acesso ao sistema de saúde, para manter o acompanhamento recomendado a cada 4 meses, e em casos de gestação (na dependência da classificação da retinopatia diabética no início da gestação) ou em situações clínicas especiais, como a iminência de cirurgia de catarata<sup>74,99,100</sup> . Este tratamento pode levar à redução em 50% do risco de perda visual grave em casos de pacientes com DM2, assim como a redução da necessidade de vitrectomia<sup>99</sup> **.** A técnica de fotocoagulação a laser a ser empregada nesses casos é a de panfotocoagulação (PFC).

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.2.2. Tratamento medicamentoso com anti-VEGF** -->
Não é possível recomendar o uso da associação da PFC com agentes antiangiogênicos (Anti _Vascular Endotelial Growth_  
_factor -_ anti-VEGF) em pacientes com RDNP grave ou muito grave sem EMD ou RDP sem características de alto risco<sup>101,102</sup> **.**

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.3. Retinopatia diabética proliferativa (RDP) de alto risco sem edema macular** -->
A melhora rápida dos níveis glicêmicos, em casos de paciente cronicamente mal controlado, pode levar à piora momentânea  
da retinopatia e do edema macular. Essa evolução foi descrita no grupo de tratamento intensivo do _Diabetes Control and Complications Trial_ (DCCT)<sup>103</sup> , em gestantes, em casos da Síndrome de Mauriac, em estudos com bomba de insulina e em pacientes  
5  
submetidos a cirurgia bariátrica e a transplante de pâncreas. Nesses casos, é recomendado o acompanhamento oftalmológico mais frequente que o habitual.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.3.1. Fotocoagulação** -->
A fotocoagulação a laser deve ser usada no início do tratamento da RDP de alto risco sem EMD<sup>104,105</sup> . Uma vez diagnosticado, recomenda-se o início do tratamento com a maior brevidade possível do paciente que se enquadra nessa classe.  
A energia do laser absorvida é convertida em energia térmica, elevando a temperatura do tecido em aproximadamente 20 ou 30 graus Celsius. As queimaduras térmicas desnaturam a proteína do tecido, o que leva à morte local da célula da retina e necrose coagulativa. Com o tempo, essas áreas de tecido danificado termicamente cicatrizam e se tornam mais fortemente pigmentadas, deixando cicatrizes visíveis no nível do pigmento da retina. Classicamente, são realizadas aproximadamente 1.000-2.000 microqueimaduras na retina. Ao destruir a retina extramacular isquêmica em grande parte não utilizada, a fotocoagulação a laser reduz a área do tecido isquêmico, que por sua vez reduz a produção total de fator de crescimento endotelial vascular (VEGF) no olho e, assim, reduz a neovascularização<sup>106-110</sup> .  
A fotocoagulação panretinal (PRP - _panretinal photocoagulation_ ) normalmente é obtida com o uso de lâmpada de fenda ( _slitlamp_ ) ou com um oftalmoscópio a laser indireto ( _headlamp_ ). No procedimento por lâmpada de fenda, a energia do laser é fornecida de maneira coaxial. O paciente é acomodado em posição sentada e com o queixo apoiado. Uma lente de contato, que focaliza o laser na retina, é colocada contra a córnea com um agente de acoplamento transparente. O laser atravessa a córnea, a câmara anterior e a lente e foca a retina pela lente de contato. No procedimento por oftalmoscopia indireta, utiliza-se um laser acoplado de maneira coaxial a um oftalmoscópio indireto. Uma lente portátil é usada para visualizar e focalizar o laser na retina. Os movimentos da cabeça do médico controlam o feixe de mira. Em ambos os casos, a anestesia é tópica, geralmente usando-se proparacaína ou tetracaína, nos dois olhos<sup>106-110</sup> .  
A fotocoagulação pode ser aplicada em vários protocolos assistenciais, os quais variam em duração e intensidade<sup>106-110</sup> :  
 A fotocogulação de longa duração está associada a um alto nível de desconforto do paciente, pois as queimaduras devem ser procedidas individualmente e a duração do procedimento é relativamente longa. A PRP convencional geralmente consiste em durações de pulso de 100 milissegundos, com pontos grandes (200-500μm), e 200-250 mW de potência aplicada;  
 O tratamento de curta  duração utiliza a varredura padrão. Esse protocolo permite várias queimaduras na mesma ou em menor quantidade de tempo que os lasers convencionais levam para produzir apenas uma queimadura. Isso reduz a duração do pulso (10 a 30 milissegundos por ponto) e mais pontos totais (geralmente 3.000-5.000). O laser de curta duração oferece aos pacientes mais conforto do que a PRP de longa duração;  
 A fotocoagulação por navegação permite que ambos, computador e laser, reajustem-se automaticamente de acordo com o movimento dos olhos. As técnicas de imagem incluem angiografias por infravermelho, cor e fluorescência do fundo, o que minimiza a quantidade de luz a que os pacientes são expostos. Pode ser realizada por matrizes de ponto único ou padronizado que chegam até a retina periférica. Pode ser de curta ou longa duração. As cicatrizes também são mais uniformes e consistentes do que as fornecidas por lasers guiados manualmente.  
Os pacientes experimentam níveis variados de desconforto com base no tipo e duração da fotocoagulação recebida. Durante o procedimento, os pacientes geralmente experimentam uma pequena sensação de "beliscão" com cada queimadura gerada no olho afetado. Por esse motivo, o procedimento pode ser dividido em várias sessões. Após o procedimento, é normal que os pacientes tenham dores de cabeça leves. Os pacientes costumam experimentar diminuição permanente na visão periférica, colorida e noturna. Pacientes que apresentam sintomas incomuns após o procedimento, como aumento de flashes, moscas volantes, dor, vermelhidão, diminuição significativa da visão ou a sensação de que seu campo de visão é obscurecido por cortina preta, devem procurar um serviço especializado imediatamente<sup>107-110</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.3.2. Tratamento medicamentoso com anti-VEGF** -->
Ensaios clínicos randomizados demonstraram que o uso da monoterapia com antiangiogênico em casos de RDP foi não inferior à monoterapia com PFC após 2 anos de estudo para desfechos de acuidade visual<sup>111,112</sup> . Apesar de os antiangiogênicos promoverem melhora nos índices que podem impactar no exercício de atividades manuais e na direção de automóveis, com menor risco de desenvolvimento de EMD e menor necessidade de vitrectomia, eles não apresentaram diferença quanto aos questionários de qualidade de vida, atividades de vida diária, alteração no desempenho das funções profissionais e atividades sob baixa luminosidade,  
6  
em relação à PFC<sup>113</sup> . Sendo assim, devido às incertezas advindas da evidência disponível, não é preconizado o emprego de antiangiogênico para casos de RDP de alto risco sem edema macular.  
Também não se preconiza a associação de PFC com antiangiogênico, pois os estudos não são conclusivos quanto à superioridade desta associação versus monoterapia com PFC no que tange à acuidade visual<sup>101,102,114,115</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.3.3. Tratamento medicamentoso com corticosteroide** -->
Não se recomenda a associação de PFC com o uso de corticoesteroide peri- ou intra-ocular nos casos de RDP sem EMD, pois os estudos não são conclusivos quanto à superioridade dessa associação _versus_ a monoterapia com PFC no que tange à acuidade visual<sup>116-118</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.3.4. Tratamento cirúrgico** -->
A vitrectomia pode ser indicada em situações especiais, quais sejam: 1) em casos de hemorragia vítrea que não se clareie espontaneamente ou que impeça a realização da PFC completa; 2) em casos de descolamento tracional de retina com acometimento da mácula ou que esteja ameaçando acometer a mácula; 3) em casos de descolamento de retina misto (tracional e regmatogênico, ou seja, o que ocorre por ruptura na retina por rasgadura); e 4) em casos de hemorragia vítrea associada a _rúbeosis iridis_<sup>_119-122_</sup> **.**

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.1.1. Fotocoagulação** -->
O tratamento com laser para doentes de RD com EMD que não acomete o centro da fóvea é uma opção terapêutica viável para a redução da piora da acuidade visual. As evidências quanto à eficácia desta intervenção provêm de fontes indiretas, em que o laser foi avaliado em casos de paciente com edema que acomete o centro da fóvea<sup>123</sup> . As evidências diretas que investigaram a eficácia do laser no tratamento de EMD, especificamente não acometendo o centro da fóvea, são escassas e limitadas a estudos observacionais que avaliaram desfechos de parâmetros de acuidade visual, espessura macular e volume<sup>124,125</sup> (Ver a Questão de pesquisa 7 no **Apêndice 1** ). Essas evidências demonstraram benefício em estabilizar a progressão da doença ou alcançar uma melhora de moderada magnitude para esses parâmetros. Apesar da limitação na qualidade da evidência, esta modalidade terapêutica é amplamente utilizada na prática médica, sendo consagrada como segura e efetiva na condução do EMD extrafoveal. Portanto, preconiza-se a terapia com laser para os pacientes com EMD que não envolve o centro da fóvea<sup>123-125</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.1.2. Tratamento medicamentoso** -->
Não há evidências que permitam recomendar o tratamento farmacológico em casos de edema que não envolvam o centro da fóvea<sup>24</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.2.1. Fotocoagulação** -->
A fotocoagulação por laser é inferior ao tratamento farmacológico no EMD que acomete o centro da fóvea. Entretanto, sua utilização é justificada na prática médica por sua maior conveniência (redução da necessidade de visitas de acompanhamento e menor número de aplicações) e evidências que demonstram seu significativo benefício na redução da perda visual<sup>87,90,126-134</sup> .  
Inexistem evidências suficientes que permitam demonstrar a superioridade de um tipo de laser em relação a outro (pulsado _versus_ não-pulsado) e, portanto, não se recomenda substituir o laser tradicional pelo pulsado, mesmo que os dois sejam utilizados na prática clínica<sup>123,135,136</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.2.2. Tratamento medicamentoso com anti-VEGF** -->
O tratamento com anti-VEGF intravítreo no EMD que acomete o centro da mácula é superior ao laser, possibilitando ganho de acuidade visual. O uso do aflibercepte ou do ranibizumabe é indicado como primeira opção de tratamento de pacientes com EMD<sup>137</sup> .  
7  
As evidências disponíveis provenientes da meta-análise de Avery<sup>126</sup> sugerem um discreto aumento do risco de eventos cardiovasculares com o uso dos anti-VEGFs em relação ao laser ou placebo, mas os dados ainda são insuficientes para uma conclusão confiável e não impactam na recomendação de uso em geral. Apesar de não haver evidências que tenham investigado o efeito dos anti-VEGFs em pacientes com evento cardiovascular prévio, sugere-se a avaliação médica de seu uso nesses casos.  
A associação do laser ao anti-VEGF não demonstrou benefício incremental em relação à monoterapia com anti-VEGF no ganho de acuidade visual. Entretanto, sua utilização é justificada na prática médica por sua maior conveniência (redução da necessidade de visitas de acompanhamento e menor número de aplicações).  
Sobre os antiangiogênicos, é oportuno mencionar que o aflibercepte e o ranibizumabe estão disponíveis no mercado, são aprovados pela Anvisa e possuem indicação em bula para o tratamento do EMD e que o bevacizumabe não traz tal indicação em sua bula no Brasil. A Conitec avaliou o medicamento aflibercepte comparado ao ranibizumabe para o tratamento de pacientes com edema macular diabético. O aflibercepte teve recomendação favorável à incorporação pois as evidências científicas indicaram resultados significativos de eficácia na reversão de perda de acuidade visual em pacientes com EMD<sup>137</sup> .  
Posteriormente, o ranibizumabe também foi avaliado pela Conitec para o tratamento de edema macular diabético e teve recomendação favorável a incorporação<sup>138</sup> . As evidências científicas que fundamentaram a recomendação indicaram que há resultados significativos de superioridade de eficácia do ranibizumabe comparado com o laser na melhora da acuidade visual em pacientes com EMD. Os estudos que compararam o ranibizumabe com o aflibercepte também demonstaram que eles têm eficácia semelhante para o tratamento do EMD. Tanto o aflibercepte como o ranibizumabe foram incorporados para o tratamento de pacientes com edema macular diabético, conforme Protocolo Clínico e Diretrizes Terapêuticas do Ministério da Saúde e ofertados via assistência oftalmológica no SUS.  
Recomenda-se o cumprimento das normas regulamentares da Anvisa para a prevenção de infecção ocular na aplicação dos anti-VEGFs<sup>139</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.2.3. Tratamento medicamentoso com corticosteroide** -->
O implante biodegradável de dexametasona não foi incorporado no SUS para o tratamento de pacientes com EMD, conforme detalhado no Relatório de Recomendação nº 575 de novembro de 2020, da Conitec, disponível em <u>http://conitec.gov.br/images/Relatorios/2020/Relatorio_Dexametasona_EMD_575_2020.pdf.</u>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.2.4. Tratamento cirúrgico** -->
Para as recomendações referentes ao tratamento cirúrgico de RD com EMD que acomete o centro, é importante subdividir os casos em condições com ou sem tração vítrea.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.2.4.1. EMD que acomete o Centro da Fóvea com tração vítreo-macular** -->
A vitrectomia via pars plana (VVPP) é o tratamento padrão para a síndrome de tração vítreo-macular apesar da paucidade de estudos randomizados<sup>140</sup> . Entretanto, em EMD que acomete o Centro da Fóvea com tração vítreo-macular **,** baseado nas evidências disponíveis não é possível recomendar em qual momento a VVPP deve ser considerada opção de tratamento. Ela é uma opção comumente utilizada após a falha do tratamento medicamentoso. Seu uso reflete a prática médica atual e foi embasada em estudos observacionais não controlados, com no máximo 12 meses de seguimento<sup>141-143</sup> .  
Evidências provenientes de ECR para esse grupo específico de pacientes são limitadas **.** Nos estudos observacionais que embasaram a prática foram evidenciadas melhora de leve a moderada magnitude na acuidade visual e redução estatisticamente significativa da espessura do EMD<sup>141-143</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7.4.2.4.2. EMD que acomete o Centro da Fóvea sem tração vítreo-macular** -->
Não é possível recomendar o tratamento com VVPP para pacientes que apresentem EMD que acomete o Centro da Fóvea sem tração vítreo-macular<sup>144-147</sup> . Apesar de os estudos mostrarem melhora anatômica, sem ganho funcional, as evidências são provenientes de estudos observacionais de baixa qualidade.  
>  Aflibercepte 40 mg/mL.  
**8. FÁRMACOS**  
8  
Cada frasco-ampola contém um volume de enchimento de 0,278 mL de solução para injeção intravítrea, que fornece aproximadamente 0,100 mL de volume extraível, acompanhado de uma agulha com filtro 18G. Cada mL de solução para injeção intravítrea contém 40 mg de aflibercepte.  
Cada frasco-ampola fornece quantidade suficiente para uma dose única de 2 mg de aflibercepte (equivalente a 0,05 mL de solução para injeção intravítrea)<sup>148</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: Ranibizumabe 10 mg/mL, frasco-ampola. -->
Embalagem com 1 frasco-ampola contendo 2,3 mg de ranibizumabe em 0,23 mL de solução e, uma agulha com filtro para retirada do conteúdo do frasco. Cada injeção fornece o volume de 0,05 mL (ou 0,5 mg de ranibizumabe).

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **8.1. Esquemas de Administração** -->
Diferentes estudos adotaram diferentes esquemas de tratamento<sup>79,88,98,130</sup> . Na prática médica, as particularidades de cada paciente, a evolução clínica e o perfil de cada serviço irão nortear a frequência de aplicação de anti-VEGF. Ademais, considerando a frequência de comparecimento ao serviço de saúde, alguns desses esquemas, os quais consideram visitas com intervalo de tempo menor, podem não ser factíveis, devido a capacidade de atendimento dos centros especializados em que a aplicação é feita. Sendo assim, os esquemas de administração descritos neste Protocolo estão adequados às diversas necessidades possíveis, conforme o perfil do paciente e a autonomia do médico.  
Ressalta-se que o esquema posológico, tanto para o uso do aflibercepte como o do ranibizumabe, irá depender das condições de estabilização do paciente, tais como acuidade visual e espessura macular.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: Aflibercepte -->
Estudos que levaram à aprovação do aflibercepte utilizaram uma frequência bimestral após uma fase de indução de 5 aplicações mensais consecutivas<sup>80,87,130</sup> . Dessa forma, o esquema inicial poderá ser de injeções mensais de 2 mg de aflibercepte por cinco meses, seguido de injeções bimestrais de 2 mg de aflibercepte<sup>137</sup> .  
Uma vez que os estudos que embasaram as orientações sobre o aflibercepte (VIVID/VISTA) não determinaram um limite do seu uso, não há base na literatura tocante a regimes fixos para determinar esse limite.  
Os estudos pivotais tiveram duração de dois anos apenas como estudos controlados. Após dois anos, o grupo controle passava a ser tratado com medicamento antiangiogênico e todos os grupos eram acompanhados até o fim do terceiro ano. Apesar de não haver estudos randomizados de maior duração, a doença continua após dois anos e estudos de extensão abertos dos estudos pivotais mostram a necessidade de se continuar tratando<sup>149</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: Ranibizumabe -->
Estudos que levaram à aprovação do ranibizumabe, nos EUA, utilizaram uma frequência mensal por 2 anos<sup>79,88</sup> . Dessa forma, o esquema inicial poderá ser de injeções mensais de 0,5 mg por dois anos ou até que a acuidade visual máxima seja atingida ou não haja sinais de atividade da doença.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **8.1.2. Esquema “Pro Re Nata” ou** **_as needed_** -->
O esquema PRN utiliza uma fase inicial de carregamento ou indução com aplicações mensais consecutivas de uma a cinco  
injeções, de acordo com o critério médico.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: Aflibercepte -->
Esse esquema se inicia como uma fase de carregamento ou indução com injeções mensais de 2 mg de aflibercepte por até cinco meses (uma injeção mensal por 1 a 5 meses). Após isso, os pacientes podem receber injeções mensais de 2 mg de aflibercepte, a menos que a acuidade visual seja 20/20 ou seja melhor com uma espessura de subcampo central foveal abaixo do limite de elegibilidade, ou sem melhora ou piora em resposta às duas últimas injeções<sup>98</sup> .  
9  
- Ranibizumabe  
Os estudos RESTORE<sup>78</sup> e sua extensão<sup>150,151</sup> , RISE e RIDE extensão<sup>152</sup> , e Protocolo T<sup>98,153</sup> mostraram que o esquema de tratamento PRN de pacientes com edema macular diabético foi eficaz para manter a estabilidade ou ganho de visão em pacientes novos ou previamente tratados.  
Para o ranibizumabe, esse esquema se inicia com uma fase de indução inicial com a aplicação de 3 injeções mensais consecutivas de 0,5 mg de ranibizumabe e, posteriormente, injeções mensais, a menos que a acuidade visual seja 20/20 ou seja melhor com uma espessura de subcampo central foveal abaixo do limite de elegibilidade, ou sem melhora ou piora em resposta às duas últimas injeções<sup>98</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **8.1.3. Esquema “Tratar e estender”** -->
- Aflibercepte  
O tratamento com aflibercepte é iniciado com uma injeção mensal de 2 mg por cinco doses consecutivas. No esquema “tratar e estender”, os intervalos de tratamento podem ser estendidos gradualmente até que os sinais de atividade da doença ou deficiência visual se repitam. O intervalo de tratamento pode ser estendido por um mês de cada vez para o EMD.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: Ranibizumabe -->
O tratamento com ranibizumabe é iniciado com uma injeção mensal de 0,5mg até que a acuidade visual máxima seja atingida ou não haja sinais de atividade da doença. Depois disso, os intervalos de monitoramento e tratamento devem ser determinados pelo médico e deverão ser baseados na atividade da doença, bem como avaliado por meio da acuidade visual ou parâmetros anatômicos.  
No esquema “tratar e estender” os intervalos de tratamento podem ser estendidos gradualmente até que os sinais de atividade da doença ou deficiência visual se repitam. O intervalo de tratamento pode ser estendido por um mês de cada vez para o EMD.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **9.1. Diabetes sem ou com RD até grau moderado e sem EMD** -->
Recomenda-se, após o primeiro exame, a reavaliação oftalmológica em 12 meses, de acordo com os critérios diagnósticos e exames complementares já definidos.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **9.2. RD grau maior ou igual a grave sem EMD (grave, muito grave e RDP)** -->
Após a conclusão do tratamento ou estabilização do quadro, recomenda-se a reavaliação oftalmológica entre 4 a 6 meses ou em intervalo de tempo a critério médico, de acordo com os critérios diagnósticos e exames complementares.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **9.3. Qualquer grau de RD com EMD** -->
De acordo com os esquemas terapêuticos:

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **9.3.1.1. Esquema fixo** -->
O tratamento com antiangiogênico intravítreo em esquema fixo é eficaz quanto ao ganho na acuidade visual e redução na espessura macular<sup>79,80,87,88,130,152</sup> . O esquema de tratamento fixo foi o escolhido pelos protocolos clínicos iniciais que testaram os medicamentos anti-VEGF.  
Estudos que levaram à aprovação do ranibizumabe, nos EUA, adotaram uma frequência mensal por 2 anos<sup>79,88,152</sup> . Estudos que levaram à aprovação do aflibercepte adotaram uma frequência bimestral após uma fase de indução de 5 aplicações mensais consecutivas<sup>80,87,130</sup> .  
10

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **9.3.1.2. Regime** **_Pro Re Nata - PRN_ (se necessário)** -->
O esquema PRN utiliza uma fase inicial de carregamento ou indução com aplicações mensais consecutivas de uma a cinco injeções, de acordo com o critério médico.  
Para o ranibizumabe, os estudos RESTORE<sup>78</sup> e sua extensão<sup>150,151</sup> , RISE e RIDE extensão<sup>152</sup> , e Protocolo T<sup>98,153</sup> mostraram que o esquema de tratamento PRN de pacientes com edema macular diabético foi eficaz para manter a estabilidade ou ganho de visão em pacientes novos ou previamente tratados. No estudo RESTORE houve uma fase de indução inicial com a aplicação de 3 injeções mensais consecutivas.  
Para o aflibercepte, os estudos VIVID e Vista<sup>134</sup> não utilizaram o esquema PRN e o estudo Protocolo T<sup>98,153</sup> mostrou eficácia no uso de esquema PRN no tratamento do EMD. No estudo Protocolo T foi utilizado regime de indução com uma injeção.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **9.3.1.3. Regime Tratar e Estender** -->
A bula do aflibercepte prevê que, em caso de estabilização monitorada por resultados visuais ou anatômicos, o tratamento possa ser estendido. O esquema “tratar e estender” permite que os intervalos sejam gradativamente aumentados para manter estáveis os resultados visuais ou anatômicos; entretanto, existem dados insuficientes para concluir sobre a duração destes intervalos. Se os resultados visuais ou anatômicos se deteriorarem, o intervalo de tratamento pode ser diminuído conforme necessário. Por ser um esquema proativo (não se espera a piora de quadro clínico), pode-se conseguir o controle do EMD com menor número de comparecimentos. Como desvantagem, pode proporcionar um tratamento além do necessário, não identificando pacientes estáveis<sup>154</sup> .  
A bula do ranibizumabe prevê que os intervalos de tratamento podem ser estendidos gradualmente até que os sinais de atividade da doença ou deficiência visual se repitam. O intervalo de tratamento deve ser estendido por um mês de cada vez para o EMD. Se a atividade da doença é recorrente, o intervalo de tratamento deve ser reduzido adequadamente.  
Sugere-se a realização de exames de monitoramento do esquema “tratar e estender”, que podem ser solicitados de acordo  
com critérios médicos:  
- Mapeamento de retina, a cada comparecimento;  
- TCO, a cada comparecimento;  
- Avaliação da acuidade visual, a cada comparecimento.  
Sugere-se o uso preferencial de esquemas terapêuticos que incluem um menor número de comparecimentos e injeções, minimizando o risco de eventos adversos e evitando o excesso de tratamentos invasivos.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação do uso do medicamento.  
Pacientes com retinopatia diabética devem ser atendidos em serviços especializados com oftalmologista, para seu adequado diagnóstico, inclusão no Protocolo de tratamento e acompanhamento.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **11. REFERÊNCIAS** -->
1. Cavallerano JD, Schlossman DK, Hamam RN, et al. 17 Ophthalmic Complications in Older Adults with Diabetes. _Geriatric Diabetes_ . 2007:221.  
2. BRM L, MC S. _Diabetic Retinopath. In: Lumbroso B. RM, Savastano M.C., editor. Diabetic Retinopathy. India: Jaypee Brothers medical Publishers; 2015_ 2015.  
3. Organization WH. Global prevalence of diabetes mellitus and its complications. _Prevention of blindness from diabetes mellitus: report of a WHO consultation Geneva: WHO_ . 2006:7-8.  
11  
4. Control D, Group CTR. The relationship of glycemic exposure (HbA1c) to the risk of development and progression of retinopathy in the diabetes control and complications trial. _Diabetes_ . 1995;44(8):968-983.  
5. Alva M, Gray A, Mihaylova B, et al. The impact of diabetes‐related complications on healthcare costs: new results from the UKPDS (UKPDS 84). _Diabetic Medicine_ . 2015;32(4):459-466.  
6. Control D, Interventions CTEoD, Group CR. Retinopathy and nephropathy in patients with type 1 diabetes four years after a trial of intensive therapy. _New England Journal of Medicine_ . 2000;342(6):381-389.  
7. Matthews DR, Stratton IM, Aldington SJ, et al. Risks of progression of retinopathy and vision loss related to tight blood pressure control in type 2 diabetes mellitus: UKPDS 69. _Archives of ophthalmology (Chicago, Ill: 1960)_ . 2004;122(11):1631.  
8. Aiello LP, Group DER. Diabetic retinopathy and other ocular findings in the diabetes control and complications trial/epidemiology of diabetes interventions and complications study. _Diabetes Care_ . 2014;37(1):17-23.  
9. Genuth S, Sun W, Cleary P, et al. Glycation and carboxymethyllysine levels in skin collagen predict the risk of future 10year progression of diabetic retinopathy and nephropathy in the diabetes control and complications trial and epidemiology of diabetes interventions and complications participants with type 1 diabetes. _Diabetes_ . 2005;54(11):3103-3111.  
10. Hletala K, Harjutsalo V, Forsblom C, et al. Age at onset and the risk of proliferative retinopathy in type 1 diabetes. _Diabetes care_ . 2010;33(6):1315-1319.  
11. Jin P, Peng J, Zou H, et al. The 5-year onset and regression of diabetic retinopathy in Chinese type 2 diabetes patients. _PLoS One_ . 2014;9(11):e113359.  
12. Jin P, Peng J, Zou H, et al. A five-year prospective study of diabetic retinopathy progression in chinese type 2 diabetes patients with "well-controlled" blood glucose. _PLoS One_ . 2015;10(4):e0123449.  
13. Klein R, Klein BE, Moss SE, et al. The Wisconsin Epidemiologic Study of Diabetic Retinopathy: XVII. The 14-year incidence and progression of diabetic retinopathy and associated risk factors in type 1 diabetes. _Ophthalmology_ . 1998;105(10):18011815.  
14. Klein R, Knudtson MD, Lee KE, et al. The Wisconsin Epidemiologic Study of Diabetic Retinopathy: XXII the twentyfive-year progression of retinopathy in persons with type 1 diabetes. _Ophthalmology_ . 2008;115(11):1859-1868.  
15. Klein R, Knudtson MD, Lee KE, et al. The Wisconsin Epidemiologic Study of Diabetic Retinopathy XXIII: the twentyfive-year incidence of macular edema in persons with type 1 diabetes. _Ophthalmology_ . 2009;116(3):497-503.  
16. Liu Y, Wang M, Morris AD, et al. Glycemic exposure and blood pressure influencing progression and remission of diabetic retinopathy: a longitudinal cohort study in GoDARTS. _Diabetes Care_ . 2013;36(12):3979-3984.  
17. Pan J, Li Q, Zhang L, et al. Serum glycated albumin predicts the progression of diabetic retinopathy--a five year retrospective longitudinal study. _J Diabetes Complications_ . 2014;28(6):772-778.  
18. Stratton IM, Kohner EM, Aldington SJ, et al. UKPDS 50: risk factors for incidence and progression of retinopathy in Type II diabetes over 6 years from diagnosis. _Diabetologia_ . 2001;44(2):156-163.  
19. Gillies MC, Lim LL, Campain A, et al. A randomized clinical trial of intravitreal bevacizumab versus intravitreal dexamethasone for diabetic macular edema: the BEVORDEX study. _Ophthalmology_ . 2014;121(12):2473-2481.  
20. Rani PK, Raman R, Gupta A, et al. Albuminuria and Diabetic Retinopathy in Type 2 Diabetes Mellitus Sankara Nethralaya Diabetic Retinopathy Epidemiology And Molecular Genetic Study (SN-DREAMS, report 12). _Diabetol Metab Syndr_ . 2011;3(1):9.  
21. Trevisan R, Vedovato M, Mazzon C, et al. Concomitance of diabetic retinopathy and proteinuria accelerates the rate of decline of kidney function in type 2 diabetic patients. _Diabetes Care_ . 2002;25(11):2026-2031.  
22. Benarous R, Sasongko MB, Qureshi S, et al. Differential association of serum lipids with diabetic retinopathy and diabetic macular edema. _Invest Ophthalmol Vis Sci_ . 2011;52(10):7464-7469.  
23. Miljanovic B, Glynn RJ, Nathan DM, et al. A prospective study of serum lipids and risk of diabetic macular edema in type 1 diabetes. _Diabetes_ . 2004;53(11):2883-2892.  
24. Wong T, Aiello L, Ferris F, et al. Updated 2017 ICO guidelines for diabetic eye care. _Int Counc Ophthalmol_ . 2017:1-33.  
25. Ahmed J, Ward TP, Bursell SE, et al. The sensitivity and specificity of nonmydriatic digital stereoscopic retinal imaging in detecting diabetic retinopathy. _Diabetes Care_ . 2006;29(10):2205-2209.  
12  
26. Ahsan S, Basit A, Ahmed KR, et al. Diagnostic accuracy of direct ophthalmoscopy for detection of diabetic retinopathy using fundus photographs as a reference standard. _Diabetes & Metabolic Syndrome: Clinical Research & Reviews_ . 2014;8(2):96101.  
27. Aptel F, Denis P, Rouberol F, et al. Screening of diabetic retinopathy: effect of field number and mydriasis on sensitivity and specificity of digital fundus photography. _Diabetes Metab_ . 2008;34(3):290-293.  
28. Boucher MC, Gresset JA, Angioi K, et al. Effectiveness and safety of screening for diabetic retinopathy with two nonmydriatic digital images compared with the seven standard stereoscopic photographic fields. _Can J Ophthalmol_ . 2003;38(7):557-568.  
29. Bursell SE, Cavallerano JD, Cavallerano AA, et al. Stereo nonmydriatic digital-video color retinal imaging compared with Early Treatment Diabetic Retinopathy Study seven standard field 35-mm stereo color photos for determining level of diabetic retinopathy. _Ophthalmology_ . 2001;108(3):572-585.  
30. Chia DS, Yap EY. Comparison of the effectiveness of detecting diabetic eye disease: diabetic retinal photography versus ophthalmic consultation. _Singapore Med J_ . 2004;45(6):276-279.  
31. Chun DW, Bauer RM, Ward TP, et al. Evaluation of digital fundus images as a diagnostic method for surveillance of diabetic retinopathy. _Military medicine_ . 2007;172(4):405-410.  
32. Emanuele N, Klein R, Moritz T, et al. Comparison of dilated fundus examinations with seven-field stereo fundus photographs in the Veterans Affairs Diabetes Trial. _J Diabetes Complications_ . 2009;23(5):323-329.  
33. Gresset J, Boucher M, Angioi-Duprez K, et al. Comparison of Two, Three and Four 45-degree Image Fields with the Topcon CRW6 Non-mydriatic Camera for the Screening of Diabetic Retinopathy. _Investigative Ophthalmology & Visual Science_ . 2003;44(13):3954-3954.  
34. Harding SP, Broadbent DM, Neoh C, et al. Sensitivity and specificity of photography and direct ophthalmoscopy in screening for sight threatening eye disease: the Liverpool Diabetic Eye Study. _BMJ_ . 1995;311(7013):1131-1135.  
35. Herbert H, Jordan K, Flanagan D. Is screening with digital imaging using one retinal view adequate? _Eye_ . 2003;17(4):497-500.  
36. Kalm H, Egertsen R, Blohme G. Non‐stereo fundus photography as a screening procedure for diabetic retinopathy among patients with type II diabetes: Compared with 60D enhanced slit‐lamp examination. _Acta ophthalmologica_ . 1989;67(5):546-553.  
37. Kerr D, Cavan DA, Jennings B, et al. Beyond retinal screening: digital imaging in the assessment and follow-up of patients with diabetic retinopathy. _Diabet Med_ . 1998;15(10):878-882.  
38. Kinyoun JL, Martin DC, Fujimoto WY, et al. Ophthalmoscopy versus fundus photographs for detecting and grading diabetic retinopathy. _Invest Ophthalmol Vis Sci_ . 1992;33(6):1888-1893.  
39. Klein R, Klein BE, Neider MW, et al. Diabetic retinopathy as detected using ophthalmoscopy, a nonmyciriatic camera and a standard fundus camera. _Ophthalmology_ . 1985;92(4):485-491.  
40. Kleinstein RN, Roseman JM, Herman WH, et al. Detection of diabetic retinopathy by optometrists. _J Am Optom Assoc_ . 1987;58(11):879-882.  
41. Kuo H-K, Hsieh H-H, Liu R-T. Screening for diabetic retinopathy by one-field, non-mydriatic, 45 digital photography is inadequate. _Ophthalmologica_ . 2005;219(5):292-296.  
42. Lawrence MG. The accuracy of digital-video retinal imaging to screen for diabetic retinopathy: an analysis of two digital-video retinal imaging systems using standard stereoscopic seven-field photography and dilated clinical examination as reference standards. _Transactions of the American Ophthalmological Society_ . 2004;102:321.  
43. Lin DY, Blumenkranz MS, Brothers RJ, et al. The sensitivity and specificity of single-field nonmydriatic monochromatic digital fundus photography with remote image interpretation for diabetic retinopathy screening: a comparison with ophthalmoscopy and standardized mydriatic color photography. _Am J Ophthalmol_ . 2002;134(2):204-213.  
44. Lopez-Bastida J, Cabrera-Lopez F, Serrano-Aguilar P. Sensitivity and specificity of digital retinal imaging for screening diabetic retinopathy. _Diabet Med_ . 2007;24(4):403-407.  
45. Maberley D, Cruess AF, Barile G, et al. Digital photographic screening for diabetic retinopathy in the James Bay Cree. _Ophthalmic Epidemiol_ . 2002;9(3):169-178.  
46. Massin P, Erginay A, Ben Mehidi A, et al. Evaluation of a new non-mydriatic digital camera for detection of diabetic retinopathy. _Diabet Med_ . 2003;20(8):635-641.  
13  
47. Møller F, Hansen M, Sjølie AK. Is one 60° fundus photograph sufficient for screening of proliferative diabetic retinopathy? _Diabetes Care_ . 2001;24(12):2083-2085.  
48. Moss SE, Klein R, Kessler SD, et al. Comparison between ophthalmoscopy and fundus photography in determining severity of diabetic retinopathy. _Ophthalmology_ . 1985;92(1):62-67.  
49. Murgatroyd H, Ellingford A, Cox A, et al. Effect of mydriasis and different field strategies on digital image screening of diabetic eye disease. _Br J Ophthalmol_ . 2004;88(7):920-924.  
50. Neubauer AS, Kernt M, Haritoglou C, et al. Nonmydriatic screening for diabetic retinopathy by ultra-widefield scanning laser ophthalmoscopy (Optomap). _Graefes Arch Clin Exp Ophthalmol_ . 2008;246(2):229-235.  
51. Newsom R, Moate B, Casswell T. Screening for diabetic retinopathy using digital colour photography and oral fluorescein angiography. _Eye_ . 2000;14(4):579-582.  
52. Olson JA, Strachan FM, Hipwell JH, et al. A comparative evaluation of digital imaging, retinal photography and optometrist examination in screening for diabetic retinopathy. _Diabet Med_ . 2003;20(7):528-534.  
53. Owens D, Gibbins R, Lewis P, et al. Screening for diabetic retinopathy by general practitioners: ophthalmoscopy or retinal photography as 35 mm colour transparencies? _Diabetic medicine_ . 1998;15(2):170-175.  
54. Penman AD, Saaddine JB, Hegazy M, et al. Screening for diabetic retinopathy: the utility of nonmydriatic retinal photography in Egyptian adults. _Diabet Med_ . 1998;15(9):783-787.  
55. Phiri R, Keeffe JE, Harper CA, et al. Comparative study of the polaroid and digital non-mydriatic cameras in the detection of referrable diabetic retinopathy in Australia. _Diabet Med_ . 2006;23(8):867-872.  
56. Pugh JA, Jacobson JM, Van Heuven WA, et al. Screening for diabetic retinopathy. The wide-angle retinal camera. _Diabetes Care_ . 1993;16(6):889-895.  
57. Ruamviboonsuk P, Wongcumchang N, Surawongsin P, et al. Screening for diabetic retinopathy in rural area using singlefield, digital fundus images. _J Med Assoc Thai_ . 2005;88(2):176-180.  
58. Rudnisky CJ, Hinz BJ, Tennant MT, et al. High-resolution stereoscopic digital fundus photography versus contact lens biomicroscopy for the detection of clinically significant macular edema. _Ophthalmology_ . 2002;109(2):267-274.  
59. Saari JM, Summanen P, Kivela T, et al. Sensitivity and specificity of digital retinal images in grading diabetic retinopathy. _Acta Ophthalmol Scand_ . 2004;82(2):126-130.  
60. Scanlon PH, Malhotra R, Greenwood R, et al. Comparison of two reference standards in validating two field mydriatic digital photography as a method of screening for diabetic retinopathy. _British journal of ophthalmology_ . 2003;87(10):1258-1263.  
61. Scanlon PH, Malhotra R, Thomas G, et al. The effectiveness of screening for diabetic retinopathy by digital imaging photography and technician ophthalmoscopy. _Diabet Med_ . 2003;20(6):467-474.  
62. Schachat AP, Hyman L, Leske MC, et al. Comparison of diabetic retinopathy detection by clinical examinations and photograph gradings. Barbados (West Indies) Eye Study Group. _Arch Ophthalmol_ . 1993;111(8):1064-1070.  
63. Sculpher MJ, Buxton MJ, Ferguson BA, et al. Screening for diabetic retinopathy: a relative cost-effectiveness analysis of alternative modalities and strategies. _Health Econ_ . 1992;1(1):39-51.  
64. Siu SC, Ko TC, Wong KW, et al. Effectiveness of non-mydriatic retinal photography and direct ophthalmoscopy in detecting diabetic retinopathy. _Hong Kong Med J_ . 1998;4(4):367-370.  
65. de Sonnaville JJ, van der Feltz van der Sloot D, Ernst L, et al. Retinopathy screening in type 2 diabetes: reliability of wide angle fundus photography. _Diabet Med_ . 1996;13(5):482-486.  
66. Stellingwerf C, Hardus PL, Hooymans JM. Two-field photography can identify patients with vision-threatening diabetic retinopathy: a screening approach in the primary care setting. _Diabetes care_ . 2001;24(12):2086-2090.  
67. Stellingwerf C, Hardus P, Hooymans J. Assessing diabetic retinopathy using two-field digital photography and the influence of JPEG-compression. _Documenta ophthalmologica_ . 2004;108(3):203-209.  
68. Tanterdtham J, Singalavanija A, Namatra C, et al. Nonmydriatic digital retinal images for determining diabetic retinopathy. _J Med Assoc Thai_ . 2007;90(3):508-512.  
69. Taylor D, Fisher J, Jacob J, et al. The use of digital cameras in a mobile retinal screening environment. _Diabetic medicine_ . 1999;16(8):680-686.  
14  
70. Williams R, Nussey S, Humphry R, et al. Assessment of non-mydriatic fundus photography in detection of diabetic retinopathy. _Br Med J (Clin Res Ed)_ . 1986;293(6555):1140-1142.  
71. Wilson PJ, Ellis JD, MacEwen CJ, et al. Screening for diabetic retinopathy: a comparative trial of photography and scanning laser ophthalmoscopy. _Ophthalmologica_ . 2010;224(4):251-257.  
72. Diabetic retinopathy study. Report Number 6. Design, methods, and baseline results. Report Number 7. A modification of the Airlie House classification of diabetic retinopathy. Prepared by the Diabetic Retinopathy. _Invest Ophthalmol Vis Sci_ . 1981;21(1 Pt 2):1-226.  
73. Goldberg MF, Jampol LM. Knowledge of diabetic retinopathy before and 18 years after the Airlie House Symposium on Treatment of Diabetic Retinopathy. _Ophthalmology_ . 1987;94(7):741-746.  
74. Group ETDRSR. Grading diabetic retinopathy from stereoscopic color fundus photographs—an extension of the modified Airlie House classification: ETDRS report number 10. _Ophthalmology_ . 1991;98(5):786-806.  
75. Wilkinson CP, Ferris FL, 3rd, Klein RE, et al. Proposed international clinical diabetic retinopathy and diabetic macular edema disease severity scales. _Ophthalmology_ . 2003;110(9):1677-1682.  
76. Group ETDRSR. Early photocoagulation for diabetic retinopathy: ETDRS report number 9. _Ophthalmology_ . 1991;98(5):766-785.  
77. Bresnick GH. Diabetic macular edema: a review. _Ophthalmology_ . 1986;93(7):989-997.  
78. Mitchell P, Bandello F, Schmidt-Erfurth U, et al. The RESTORE study: ranibizumab monotherapy or combined with laser versus laser monotherapy for diabetic macular edema. _Ophthalmology_ . 2011;118(4):615-625.  
79. Nguyen QD, Brown DM, Marcus DM, et al. Ranibizumab for diabetic macular edema: results from 2 phase III randomized trials: RISE and RIDE. _Ophthalmology_ . 2012;119(4):789-801.  
80. Korobelnik JF, Do DV, Schmidt-Erfurth U, et al. Intravitreal aflibercept for diabetic macular edema. _Ophthalmology_ . 2014;121(11):2247-2254.  
81. Otani T, Kishi S, Maruyama Y. Patterns of diabetic macular edema with optical coherence tomography. _American journal of ophthalmology_ . 1999;127(6):688-693.  
82. Kim BY, Smith SD, Kaiser PK. Optical coherence tomographic patterns of diabetic macular edema. _Am J Ophthalmol_ . 2006;142(3):405-412.  
83. Panozzo G, Mercanti A. Optical coherence tomography findings in myopic traction maculopathy. _Arch Ophthalmol_ . 2004;122(10):1455-1460.  
84. Photocoagulation for diabetic macular edema. Early Treatment Diabetic Retinopathy Study report number 1. Early Treatment Diabetic Retinopathy Study research group. _Arch Ophthalmol_ . 1985;103(12):1796-1806.  
85. Kylstra JA, Brown JC, Jaffe GJ, et al. The importance of fluorescein angiography in planning laser treatment of diabetic macular edema. _Ophthalmology_ . 1999;106(11):2068-2073.  
86. Razvi F, Kritzinger E, Tsaloumas M, et al. Use of oral fluorescein angiography in the diagnosis of macular oedema within a diabetic retinopathy screening programme. _Diabetic medicine_ . 2001;18(12):1003-1006.  
87. Brown DM, Schmidt-Erfurth U, Do DV, et al. Intravitreal Aflibercept for Diabetic Macular Edema: 100-Week Results From the VISTA and VIVID Studies. _Ophthalmology_ . 2015;122(10):2044-2052.  
88. Brown DM, Nguyen QD, Marcus DM, et al. Long-term outcomes of ranibizumab therapy for diabetic macular edema: the 36-month results from two phase III trials: RISE and RIDE. _Ophthalmology_ . 2013;120(10):2013-2022.  
89. Virgili G, Menchini F, Casazza G, et al. Optical coherence tomography (OCT) for detection of macular oedema in patients with diabetic retinopathy. _Cochrane Database Syst Rev_ . 2015;1:CD008081.  
90. Berger A, Sheidow T, Cruess AF, et al. Efficacy/safety of ranibizumab monotherapy or with laser versus laser monotherapy in DME. _Can J Ophthalmol_ . 2015;50(3):209-216.  
91. Comyn O, Sivaprasad S, Peto T, et al. A randomized trial to assess functional and structural effects of ranibizumab versus laser in diabetic macular edema (the LUCIDATE study). _Am J Ophthalmol_ . 2014;157(5):960-970.  
92. Diabetic Retinopathy Clinical Research N, Elman MJ, Aiello LP, et al. Randomized trial evaluating ranibizumab plus prompt or deferred laser or triamcinolone plus prompt laser for diabetic macular edema. _Ophthalmology_ . 2010;117(6):1064-1077 e1035.  
15  
93. Elman MJ, Ayala A, Bressler NM, et al. Intravitreal Ranibizumab for diabetic macular edema with prompt versus deferred laser treatment: 5-year randomized trial results. _Ophthalmology_ . 2015;122(2):375-381.  
94. Massin P, Bandello F, Garweg JG, et al. Safety and efficacy of ranibizumab in diabetic macular edema (RESOLVE Study): a 12-month, randomized, controlled, double-masked, multicenter phase II study. _Diabetes Care_ . 2010;33(11):2399-2405.  
95. Ahmadieh H, Ramezani A, Shoeibi N, et al. Intravitreal bevacizumab with or without triamcinolone for refractory diabetic macular edema; a placebo-controlled, randomized clinical trial. _Graefe's Archive for Clinical and Experimental Ophthalmology_ . 2008;246(4):483-489.  
96. Rajendram R, Fraser-Bell S, Kaines A, et al. A 2-year prospective randomized controlled trial of intravitreal bevacizumab or laser therapy (BOLT) in the management of diabetic macular edema: 24-month data: report 3. _Arch Ophthalmol_ . 2012;130(8):972-979.  
97. Ghasemi Falavarjani K, Wang K, Khadamy J, et al. Ultra-wide-field imaging in diabetic retinopathy; an overview. _J Curr Ophthalmol_ . 2016;28(2):57-60.  
98. Diabetic Retinopathy Clinical Research N, Wells JA, Glassman AR, et al. Aflibercept, bevacizumab, or ranibizumab for diabetic macular edema. _N Engl J Med_ . 2015;372(13):1193-1203.  
99. Ferris F. Early photocoagulation in patients with either type I or type II diabetes. _Transactions of the American Ophthalmological Society_ . 1996;94:505.  
100. Japanese Society of Ophthalmic Diabetology SotSoDRT, Sato Y, Kojimahara N, et al. Multicenter randomized clinical trial of retinal photocoagulation for preproliferative diabetic retinopathy. _Jpn J Ophthalmol_ . 2012;56(1):52-59.  
101. Martinez-Zapata MJ, Marti-Carvajal AJ, Sola I, et al. Anti-vascular endothelial growth factor for proliferative diabetic retinopathy. _Cochrane Database Syst Rev_ . 2014(11):CD008721.  
102. Simunovic MP, Maberley DA. ANTI-VASCULAR ENDOTHELIAL GROWTH FACTOR THERAPY FOR PROLIFERATIVE DIABETIC RETINOPATHY: A Systematic Review and Meta-Analysis. _Retina_ . 2015;35(10):1931-1942.  
103. Group DR. Diabetes control and complications trial (DCCT): update. _Diabetes Care_ . 1990;13(4):427-433.  
104. Group DRSR. Photocoagulation treatment of proliferative diabetic retinopathy: clinical application of Diabetic Retinopathy Study (DRS) findings, DRS Report Number 8. _Ophthalmology_ . 1981;88(7):583-600.  
105. Group DRSR. Indications for photocoagulation treatment of diabetic retinopathy: Diabetic Retinopathy Study Report no. 14. _International Ophthalmology Clinics_ . 1987;27(4):239-253.  
106. Weng CY, Lim JI, Bhagat P, et al. _Panretinal Photocoagulation_ : EyeWiki. American Academy of Ophthalmology; 2020 [cited 2020]. https://eyewiki.aao.org/Panretinal_Photocoagulation  
107. Abu El-Asrar AM. Evolving strategies in the management of diabetic retinopathy. _Middle East Afr J Ophthalmol_ . 2013;20(4):273-282.  
108. Evans JR, Michelessi M, Virgili G. Laser photocoagulation for proliferative diabetic retinopathy. _Cochrane Database Syst Rev_ . 2014(11):CD011234.  
109. Kozak I, Luttrull JK. Modern retinal laser therapy. _Saudi J Ophthalmol_ . 2015;29(2):137-146.  
110. Saxena S, Jalali S, Meredith TA, et al. Management of diabetic retinopathy. _Indian J Ophthalmol_ . 2000;48(4):321-330.  
111. Writing Committee for the Diabetic Retinopathy Clinical Research N, Gross JG, Glassman AR, et al. Panretinal Photocoagulation vs Intravitreous Ranibizumab for Proliferative Diabetic Retinopathy: A Randomized Clinical Trial. _JAMA_ . 2015;314(20):2137-2146.  
112. Sivaprasad S, Prevost AT, Vasconcelos JC, et al. Clinical efficacy of intravitreal aflibercept versus panretinal photocoagulation for best corrected visual acuity in patients with proliferative diabetic retinopathy at 52 weeks (CLARITY): a multicentre, single-blinded, randomised, controlled, phase 2b, non-inferiority trial. _The Lancet_ . 2017;389(10085):2193-2203.  
113. Desapriya E, Khoshpouri P, Al-Isa A. Panretinal Photocoagulation Versus Ranibizumab for Proliferative Diabetic Retinopathy: Patient-Centered Outcomes From a Randomized Clinical Trial. _Am J Ophthalmol_ . 2017;177:232-233.  
114. Filho JA, Messias A, Almeida FP, et al. Panretinal photocoagulation (PRP) versus PRP plus intravitreal ranibizumab for high-risk proliferative diabetic retinopathy. _Acta Ophthalmol_ . 2011;89(7):e567-572.  
115. Messias A, Ramos Filho JA, Messias K, et al. Electroretinographic findings associated with panretinal photocoagulation (PRP) versus PRP plus intravitreal ranibizumab treatment for high-risk proliferative diabetic retinopathy. _Doc Ophthalmol_ . 2012;124(3):225-236.  
16  
116. Cho WB, Moon JW, Kim HC. Intravitreal triamcinolone and bevacizumab as adjunctive treatments to panretinal photocoagulation in diabetic retinopathy. _British Journal of Ophthalmology_ . 2010;94(7):858-863.  
117. Shimura M, Yasuda K, Shiono T. Posterior sub-Tenon's capsule injection of triamcinolone acetonide prevents panretinal photocoagulation-induced visual dysfunction in patients with severe diabetic retinopathy and good vision. _Ophthalmology_ . 2006;113(3):381-387.  
118. Unoki N, Nishijima K, Kita M, et al. Randomised controlled trial of posterior sub-Tenon triamcinolone as adjunct to panretinal photocoagulation for treatment of diabetic retinopathy. _British journal of ophthalmology_ . 2009;93(6):765-770.  
119. Early vitrectomy for severe vitreous hemorrhage in diabetic retinopathy. Two-year results of a randomized trial. Diabetic Retinopathy Vitrectomy Study report 2. The Diabetic Retinopathy Vitrectomy Study Research Group. _Arch Ophthalmol_ . 1985;103(11):1644-1652.  
120. Early vitrectomy for severe proliferative diabetic retinopathy in eyes with useful vision. Results of a randomized trial-Diabetic Retinopathy Vitrectomy Study Report 3. The Diabetic Retinopathy Vitrectomy Study Research Group. _Ophthalmology_ . 1988;95(10):1307-1320.  
121. Early vitrectomy for severe proliferative diabetic retinopathy in eyes with useful vision. Clinical application of results of a randomized trial--Diabetic Retinopathy Vitrectomy Study Report 4. The Diabetic Retinopathy Vitrectomy Study Research Group. _Ophthalmology_ . 1988;95(10):1321-1334.  
122. Early vitrectomy for severe vitreous hemorrhage in diabetic retinopathy. Four-year results of a randomized trial: Diabetic Retinopathy Vitrectomy Study Report 5. _Arch Ophthalmol_ . 1990;108(7):958-964.  
123. Writing Committee for the Diabetic Retinopathy Clinical Research N, Fong DS, Strauber SF, et al. Comparison of the modified Early Treatment Diabetic Retinopathy Study and mild macular grid laser photocoagulation strategies for diabetic macular edema. _Arch Ophthalmol_ . 2007;125(4):469-480.  
124. Perente I, Alkin Z, Ozkaya A, et al. Focal laser photocoagulation in non-center involved diabetic macular edema. _Med Hypothesis Discov Innov Ophthalmol_ . 2014;3(1):9-16.  
125. Scott IU, Danis RP, Bressler SB, et al. Effect of focal/grid photocoagulation on visual acuity and retinal thickening in eyes with non-center-involved diabetic macular edema. _Retina_ . 2009;29(5):613-617.  
126. Avery RL, Gordon GM. Systemic Safety of Prolonged Monthly Anti-Vascular Endothelial Growth Factor Therapy for Diabetic Macular Edema: A Systematic Review and Meta-analysis. _JAMA Ophthalmol_ . 2016;134(1):21-29.  
127. Chen G, Li W, Tzekov R, et al. Ranibizumab monotherapy or combined with laser versus laser monotherapy for diabetic macular edema: a meta-analysis of randomized controlled trials. _PLoS One_ . 2014;9(12):e115797.  
128. Do DV, Nguyen QD, Boyer D, et al. One-year outcomes of the da Vinci Study of VEGF Trap-Eye in eyes with diabetic macular edema. _Ophthalmology_ . 2012;119(8):1658-1665.  
129. Do DV, Schmidt-Erfurth U, Gonzalez VH, et al. The DA VINCI Study: phase 2 primary results of VEGF Trap-Eye in patients with diabetic macular edema. _Ophthalmology_ . 2011;118(9):1819-1826.  
130. Heier JS, Korobelnik JF, Brown DM, et al. Intravitreal Aflibercept for Diabetic Macular Edema: 148-Week Results from the VISTA and VIVID Studies. _Ophthalmology_ . 2016;123(11):2376-2385.  
131. Régnier S, Malcolm W, Allen F, et al. Efficacy of anti-VEGF and laser photocoagulation in the treatment of visual impairment due to diabetic macular edema: a systematic review and network meta-analysis. _PloS one_ . 2014;9(7):e102309.  
132. Network DRCR. A phase II randomized clinical trial of intravitreal bevacizumab for diabetic macular edema. _Ophthalmology_ . 2007;114(10):1860-1867. e1867.  
133. Virgili G, Parravano M, Menchini F, et al. Anti-vascular endothelial growth factor for diabetic macular oedema. _Cochrane Database Syst Rev_ . 2014(10):CD007419.  
134. Yanagida Y, Ueta T. Systemic safety of ranibizumab for diabetic macular edema: meta-analysis of randomized trials. _Retina_ . 2014;34(4):629-635.  
135. Lavinsky D, Cardillo JA, Melo LA, Jr., et al. Randomized clinical trial evaluating mETDRS versus normal or highdensity micropulse photocoagulation for diabetic macular edema. _Invest Ophthalmol Vis Sci_ . 2011;52(7):4314-4323.  
136. Vujosevic S, Martini F, Longhin E, et al. SUBTHRESHOLD MICROPULSE YELLOW LASER VERSUS SUBTHRESHOLD MICROPULSE INFRARED LASER IN CENTER-INVOLVING DIABETIC MACULAR EDEMA: Morphologic and Functional Safety. _Retina_ . 2015;35(8):1594-1603.  
17  
137. BRASIL. Ministério da Saúde. Departamento de Gestão, Incorporação de tecnologias e Inovação em Saúde - DGITIS. Comissão nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec. Aflibercepte para Edema Macular Diabético. Relatório Nº478 de 2019. In: DGITIS, editor.: Ministério da Saúde; 2019.  
138. BRASIL. BRASIL. Ministério da Saúde. Departamento de Gestão, Incorporação de tecnologias e Inovação em Saúde - DGITIS. Comissão nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec. Ranibizumabe para tratamento de Edema Macular Diabético (EMD). Relatório Nº549 de 2020. In: DGITIS, editor.: Ministério da Saúde; 2020.  
139. Brasil, Agência Nacional de Vigilância Sanitária. Medidas de Prevenção de Endoftalmites e de Síndrome Tóxica do Segmento Anterior Relacionadas a Procedimentos Oftalmológicos Invasivos. Brasília: Anvisa; 2017.  
140. McDonald HR, Johnson RN, Schatz H. Surgical results in the vitreomacular traction syndrome. _Ophthalmology_ . 1994;101(8):1397-1402; discussion 1403.  
141. Bahadır M, Ertan A, Mertoğlu Ö. Visual acuity comparison of vitrectomy with and without internal limiting membrane removal in the treatment of diabetic macular edema. _International ophthalmology_ . 2005;26(1-2):3-8.  
142. Diabetic Retinopathy Clinical Research Network Writing C, Haller JA, Qin H, et al. Vitrectomy outcomes in eyes with diabetic macular edema and vitreomacular traction. _Ophthalmology_ . 2010;117(6):1087-1093 e1083.  
143. Flaxel CJ, Edwards AR, Aiello LP, et al. Factors associated with visual acuity outcomes after vitrectomy for diabetic macular edema: diabetic retinopathy clinical research network. _Retina_ . 2010;30(9):1488-1495.  
144. Simunovic MP, Hunyor AP, Ho IV. Vitrectomy for diabetic macular edema: a systematic review and meta-analysis. _Can J Ophthalmol_ . 2014;49(2):188-195.  
145. Otani T, Kishi S. A controlled study of vitrectomy for diabetic macular edema. _Am J Ophthalmol_ . 2002;134(2):214-219.  
146. Raizada S, Al Kandari J, Al Diab F, et al. Pars plana vitrectomy versus three intravitreal injections of bevacizumab for nontractional diabetic macular edema. A prospective, randomized comparative study. _Indian J Ophthalmol_ . 2015;63(6):504-510.  
147. Doi N, Sakamoto T, Sonoda Y, et al. Comparative study of vitrectomy versus intravitreous triamcinolone for diabetic macular edema on randomized paired-eyes. _Graefes Arch Clin Exp Ophthalmol_ . 2012;250(1):71-78.  
148. Eylia. Aflibercepte. Farm. Resp.: Dra. Dirce Eiko Mimura CRF-SP nº 16532. Bula de remédio; Data da última atualização: 31/08/2019.  
149. Sun JK, Wang PW, Taylor S, Haskova Z. Durability of Diabetic Retinopathy Improvement with As-Needed Ranibizumab: Open-Label Extension of RIDE and RISE Studies. Ophthalmology 2019 May;126(5):712-720.  
150. Lang GE, Berta A, Eldem BM, et al. Two-year safety and efficacy of ranibizumab 0.5 mg in diabetic macular edema: interim analysis of the RESTORE extension study. _Ophthalmology_ . 2013;120(10):2004-2012.  
151. Schmidt-Erfurth U, Lang GE, Holz FG, et al. Three-year outcomes of individualized ranibizumab treatment in patients with diabetic macular edema: the RESTORE extension study. _Ophthalmology_ . 2014;121(5):1045-1053.  
152. Boyer DS, Nguyen QD, Brown DM, et al. Outcomes with As-Needed Ranibizumab after Initial Monthly Therapy: LongTerm Outcomes of the Phase III RIDE and RISE Trials. _Ophthalmology_ . 2015;122(12):2504-2513 e2501.  
153. Wells JA, Glassman AR, Ayala AR, et al. Aflibercept, Bevacizumab, or Ranibizumab for Diabetic Macular Edema: Two-Year Results from a Comparative Effectiveness Randomized Clinical Trial. _Ophthalmology_ . 2016;123(6):1351-1359.  
154. Freund KB, Korobelnik JF, Devenyi R, et al. TREAT-AND-EXTEND REGIMENS WITH ANTI-VEGF AGENTS IN RETINAL DISEASES: A Literature Review and Consensus Recommendations. _Retina_ . 2015;35(8):1489-1506.  
18

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1. APRESENTAÇÃO** -->
Em 11 de novembro de 2016, às 9:00h, foi realizada a reunião para definição do escopo do PCDT sobre Retinopatia diabética.  
Na reunião foi apresentada uma proposta prévia de elaboração de escopo, promovida pela Subcomissão de Protocolos Clínicos e Diretrizes Terapêuticas da Conitec em janeiro de 2016, com o objetivo de identificar as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas no tema do presente PCDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO, para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2. Equipe de elaboração e partes interessadas** -->
A reunião presencial para definição do escopo do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida com a presença de membros do Grupo Elaborador. Todos os participantes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde como parte dos resultados.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Colaboração externa** -->
Esst PCDT contou com a participação da Associação Médica Brasileira, para a definição do escopo e à reunião de consenso sobre as recomendações.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas - 2020** -->
A proposta de elaboração do PCDT da Retinopatia Diabética foi apresentada na 77º Reunião da Subcomissão Técnica de PCDT, realizada em fevereiro de 2020. A reunião teve a presença de representantes do Departamento de Gestão, Incorporação e Inovação de Tecnologias em Saúde (DGITIS/SCTIE), Departamento de Ciência e Tecnologia (DECIT/SCTIE), Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE) e Secretaria de Vigilância em Saúde (SVS). Após a subcomissão, os ajustes necessários foram realizados e, em seguida, a proposta foi apresentada aos membros do Plenário da Conitec em sua 86ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas - 2021** -->
Após a incorporação do ranibizumabe a proposta de elaboração do PCDT da Retinopatia Diabética foi apresentada na 85º Reunião da Subcomissão Técnica de PCDT, realizada em janeiro de 2021. A reunião teve a presença de representantes do Departamento de Gestão, Incorporação e Inovação de Tecnologias em Saúde (DGITIS/SCTIE), Departamento de Ciência e Tecnologia (DECIT/SCTIE), Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE), Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Atenção Especializada à Saúde (SAES). Após a subcomissão, os ajustes necessários foram realizados e, em seguida, a proposta foi apresentada aos membros do Plenário da Conitec em sua 94ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Consulta pública - 2020** -->
A Consulta Pública nº 12/2020, do Protocolo Clínico e Diretrizes Terapêuticas para Retinopatia Diabética, foi realizada entre os dias 20/03/2020 a 08/04/2020. Foram recebidas 3431 contribuições, que podem ser verificadas em: <u>http://conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_12_2020_PCDT_Retinopatia.pdf.</u>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Consulta pública - 2021** -->
19  
A Consulta Pública nº 13/2021, do Protocolo Clínico e Diretrizes Terapêuticas para Retinopatia Diabética, foi realizada entre os dias 22/02/2020 a 15/03/2020. Foram recebidas 665 contribuições, que podem ser verificadas em: <u>http://conitec.gov.br/images/Consultas/Contribuicoes/2021/20210316_CP_CONITEC_13_2021_PCDT_Retinopatia.pdf</u>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3. BUSCA DA EVIDÊNCIA** -->
A busca da evidência foi realizada por pergunta de pesquisa ( **Figura 1** ).  
<!-- Start of picture text -->
•População ou condição clínica<br>P<br>•Intervenção, no caso de estudos experimentais<br>•Fator de exposição, em caso de estudos observacionais<br>I<br>•Teste índice, nos casos de estudos de acurácia<br>diagnóstica<br>C •Controle, de acordo com tratamento/níveis de exposição do fator/exames disponíveis no SUS<br>O •Desfechos: sempre que possível, definidos a priori, de  acordo  com sua importância<br><!-- End of picture text -->  
**Figura 1 –** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
Ao final dessa dinâmica, 10 questões de pesquisa foram definidas para o presente PCDT ( **Quadro A** ).  
**Quadro A –** Questões de pesquisa elencadas pelo Grupo Elaborador  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|Quais são os critérios clínicos e bioquímicos que impactam no prognóstico<br>da retinopatia diabética?|Prevenção|
|**2**|Qual a sensibilidade e a especificidade dos diversos métodos (fundoscopia<br>direta<br>e<br>indireta,<br>retinografia<br>não<br>midriática<br>e<br>midriática,<br>retinografiawidefield) para o diagnóstico de retinopatia diabética?|Diagnóstico|
|**3**|Emquais situações é indicada a angiofluoresceinografia?<br>|Diagnóstico|
|**4**|Emquais situações é indicada a Tomografia de Coerência Óptica(OCT)?|Diagnóstico|
|**5**|Qual a eficácia e segurança das terapias à laser, farmacológicas e cirúrgicas<br>(individual,comparativo e associação)?|Tratamento|
|**6**|Qual a eficácia do uso conjunto de terapia anti-VEGF e vitrectomia via<br>parsplanaposterior?|Tratamento|
|**7**|Qual a eficácia e segurança de laser e/ou tratamento farmacológico para<br>edema macularque não envolve o centro da fóvea?|Tratamento|
|**8**|Qual a eficácia e segurança dos tratamentos farmacológicos, a laser e,<br>cirúrgico (associação individual e comparativo) para edema macular<br>diabéticoque envolve o centro da fóvea?|Tratamento|
|**9**|Em quais casos se deve utilizar tratamento cirúrgico quando a condição é<br>edema macularque envolve o centro da fóvea?|Tratamento|
|**10**|Qual é a eficácia desses três esquemas terapêuticos (fixo, PRN, tratar e<br>estender)?|Tratamento|  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.  
20  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida no PCDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo.  
Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clinico-demográficas e desfechos de eficácia/segurança.  
Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão para definir a inclusão ou não ao corpo da evidência.  
Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias em formato pdf, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados do PCDT. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo deste Apêndice.  
Com o corpo das evidências identificado, procedeu-se a extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool toAssesssystematic Reviews 2_ (AMSTAR-2)<sup>155,156</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>157</sup> , os estudos observacionais pela ferramenta Newcastle-Ottawa<sup>158</sup> e os estudos de acurácia diagnóstica pelo _Quality Assessment ofDiagnosticAccuracyStudies 2_ (QUADAS-2)<sup>159</sup> . Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas a priori como alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa ao longo deste Apêndice.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _GradingofRecommendations, Assessment, Developmentand Evaluations_ )<sup>160</sup> , de forma qualitativa, durante a reunião de consenso das recomendações. Os metodologistas mediaram as discussões apresentando cada um dos critérios GRADE para os dois objetivos do sistema GRADE, e as conclusões do painel de especialistas foram apresentadas ao final do parágrafo do texto correspondente à recomendação.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3.1. QUESTÕES DE PESQUISA** -->
- **A. Questão de pesquisa 1**  
21  
**<mark>Questão de Pesquisa 1:</mark>** <mark>Quais são os critérios clínicos e bioquímicos que impactam no prognóstico da retinopatia diabética?</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
<mark>(((("Risk Factors"[Mesh] OR predict*)) AND ("Prognosis"[Mesh] OR progno*))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)</mark>  
<mark>Total: 571 referências</mark>  
<mark>Data do acesso: 2</mark> 8/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **<mark>EMBASE:</mark>** -->
'risk factor'/exp OR 'risk factor' OR 'predict*' AND ('prognosis'/exp OR 'prognosis' OR 'progno*') AND ('diabetic retinopathy'/exp OR 'diabetic retinopathy') AND [embase]/lim  
<mark>Total: 314 referências</mark>  
<mark>Data do acesso: 2</mark> 8/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca nas bases resultou em 885 referências (571 referências da MEDLINE e 314 da EMBASE). Cem referências foram excluídas por estarem em duplicata. Setecentos e oitenta e cinco artigos foram triados por meio da leitura de título e resumos. Quarenta e uma referênciastiveram sua elegibilidade confirmada por meio da leitura completa do estudo. Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, ensaios clínicos randomizados ou comparativos não randomizados ou coortes que incluíam acima de 100 participantes; que avaliaram os fatores associados à progressão ou regressão de retinopatia diabética ou incidência de edema macular diabético e fornecessem estimas de medidas de associação (OddsRatio, HazardRatio ou Risco Relativo). Nessa etapa 28 estudos foram excluídos: 22 por representarem delineamentos de estudos com maior risco de viés (sendo três estudos caso-controle, onze estudos transversais e oitocoortes com menos de 100 participantes); dois estudos foram adicionalmente excluídos por não avaliarem os desfechos de interesse e outro por não incluir a população de interesse. Um estudo não forneceu estimativas de medidas de associação e dois estudos avaliaram a associação entre desenvolvimento de retinopatia diabética e fatores de risco. No final, 17 referências</mark><sup>8-17,161-166</sup> <mark>de 14 estudos (11 estudos longitudinais prospectivos e um estudo desérie</mark>  
<mark>de casos) foram incluídos para extração de dados. Quatros estudos foram identificados por busca manual</mark><sup>13-15,18</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e resultados</mark>** -->
<mark>A descrição sumária dos estudos encontra-se na</mark> **<mark>Tabela 1</mark>** <mark>. As características dos pacientes encontram-se descritas na</mark> **<mark>Tabela 2</mark>** <mark>.</mark>  
<mark>As</mark> **<mark>tabelas 3 a 9</mark>** <mark>apresentam dados sobre os fatores clínicos e bioquímicos que impactam no prognóstico da retinopatia diabética.</mark>  
22  
**Tabela 1 –** <mark>Características dos estudos incluídos na pergunta de pesquisa 1</mark>  
|**Autor,**<br>**ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Tamanho de amostra**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Jin et al.**<br>**2015**<sup>**12**</sup>|Estudo<br>observacional<br>prospectivo|Determinar a taxa de<br>progressão e fatores de risco<br>para RD|Pacientes >18 anos com diabetes<br>mellitus tipo 2 e bom controle de<br>glicose.|453 pacientes<br>(Grupo progressão:146)<br>(Grupo estáveis: 307)|5 anos|Moderado risco: não foi informado se a<br>população estudada é representativa do país<br>estudado;não foi usado o método de Kaplan-<br>Meier/Cox.|
|**Pan et al.**<br>**2014**<sup>**17**</sup>|Estudo<br>observacional<br>retrospectivo|Avaliar o valor preditivo da<br>hemoglobina glicada e<br>outros fatores de risco, na<br>predição de progressão de<br>RD|Indivíduos >18 anos com diabetes<br>mellitus tipo 2.|359 participantes<br>(Grupo com progressão: 108)<br>(Grupo não progressão: 251)|5 anos|Moderado risco: estudo retrospectivo, não<br>descreveu o cálculo para tamanho da amostra e<br>a representatividade da amostra; não foi usado o<br>método de Kaplan-Meier/Cox.|
|**Jin et al.**<br>**2014**<sup>**11**</sup>|Estudo<br>observacional<br>prospectivo|Determinar a incidência de<br>RD em 5 anos e fatores de<br>risco para a regressão da RD|Indivíduos > 18 anos com diabetes<br>mellitus|778 participantes<br>(Grupo sem RD:322)<br>(Grupo com RD:456, sendo que 110<br>tiveram regressão de RD e 346 não<br>tiveram regressão de RD)|5 anos|Moderado risco: não foi informado se a<br>população estudada é representativa do país<br>estudado;não foi usado o método de Kaplan-<br>Meier/Cox.|
|**Channa et**<br>**al. 2014**<sup>**161**</sup>|Estudo<br>observacional –<br>série de<br>casosREAD-2<br>Study|Identificar fatores<br>associados com os<br>desfechos visuais de<br>pacientes com edema<br>macular.|Pacientes com edema macular<br>diabético tratados com<br>ranibizumabe que completaram<br>20-24 meses do estudo READ-2.|Desfechos visuais pobres*= 27<br>(Randomizados para o grupo do<br>ranibizumabe (8), grupo do laser (10) e<br>para o grupo do laser + ranibizumabe (9))<br>Desfechos visuais melhores* =74<br>(randomizados para o grupo do<br>ranibizumabe (25), grupo do laser (24) e<br>para o grupo do laser + ranibizumabe<br>(24))<br>* Após 18 meses a maioria recebeu<br>ranibizumabe|20- 24 Meses|Moderado risco (série de casos;não foi usado o<br>método de Kaplan-Meier/Cox)|
|**Aiello,**<br>**2014**<br>**(DCCT.**<br>**1996)**<sup>**8,162**</sup>|Estudo<br>observacional<br>prospectivo-<br>resultados dos<br>estudos DCCT e<br>EDIC study|Avaliar se o INT reduziu o<br>risco de surgimento e<br>progressão de RD de<br>pacientes com diabetes tipo<br>1 comparado com CON.|DCCT: População Indivíduos com<br>idade entre 13-39 anos, com<br>diabetes tipo 1.<br>EDIC: Indivíduos com diabetes<br>tipo 1 que continuaram o estudo<br>DCCT.<br>Grupo INT (tratamento intensivo=<br>3 ou mais injeções por dia ou em<br>uso de bomba de insulina com<br>doses ajustadas baseadas no auto<br>monitoração de glicose no sangue)<br>Grupo CON (uma ou duas doses<br>de insulinapor dia).|DCCT: Grupo INT = 711; Grupo CON=<br>730<br>EDIC: Grupo INT= 605; Grupo<br>CON=603<br>% de indivíduos do grupo INT vs. CON,<br>respectivamente no início do EDIC:<br>Sem RD (28,5 vs. 17.8); somente<br>microaneurisma (39.8 vs. 31.7); com<br>DRNP leve (21.5 vs. 27.7); com RDNP<br>moderada ou grave (10,2 vs. 22.8)|DCCT: 6.5<br>EDIC: 4 e 10<br>anos|Moderado risco: o modelo não foi ajustado<br>adequadamente para possíveis confundidores;<br>não foi usado o método de Kaplan-Meier/Cox.|  
23  
|**Autor,**<br>**ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Tamanho de amostra**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Liu et al,**<br>**2013**<sup>**16**</sup>|Estudo<br>observacional<br>prospectivo|Investigar a progressão e<br>regressão de RD e os fatores<br>de risco relacionados aos<br>diferentes graus de RD|Pacientes diabéticos tipo 2<br>diagnosticados com idade de 35<br>anos ou mais|4758 pacientes diabéticos<br>(Sem RD=4662;<br>Histórico de RD leve= 44<br>RD visível leve moderada=50;<br>RDNP severa ou RNP= 2)|16 anos|Alto risco: não descreveu as características de<br>base; não justificou a perda de seguimento ao<br>longo dos anos|
|**Hietala et**<br>**al. 2010**<sup>**10**</sup>|Estudo<br>observacional<br>retrospectivo|Elucidar como a idade do<br>início do diabetes tipo 1<br>influencia o risco a longo<br>prazo de RDP|Pacientes com diabetes tipo 1|1.117 pacientes (Sem RD: 258; RDNP:<br>492; RDP:367)<br>Grupos de acordo com a idade do início<br>do diabetes 0-4 anos (168); 5-14 anos<br>(546); >15 anos (403)|10.8 anos|Moderado risco: estudo retrospectivo|
|**Aiello et**<br>**al. 2010**<sup>**163**</sup>|Estudo<br>observacional<br>prospectivo|Identificar fatores<br>associados com os<br>desfechos de acuidade<br>visual após fotocoagulação<br>focal/grid.|Pacientes com edema macular<br>diabético participantes de um<br>ensaio clínico randomizado que<br>foram randomizados para receber o<br>tratamento de fotocoagulação focal<br>/ grid.|n= 330 olhos ( 1 olho de 330 indivíduos)|2 anos|Moderado risco:não descreveu as diferenças<br>entre os participantes e aqueles que não<br>completaram o seguimento; não foi usado o<br>método de Kaplan-Meier/Cox.|
|**Klein et**<br>**al. 2009**<sup>**15**</sup>|Estudo<br>observacional<br>prospectivo -<br>Wisconsin study|Examinar em 25 anos de<br>seguimento a incidência de<br>edema macular e seus<br>fatores de risco<br>relacionados.|Pacientes com diabetes tipo 1 que<br>foram diagnosticados antes dos 30<br>anos de idade e utilizavam insulina|1210 foram incluídos no<br>acompanhamento. Desses 996<br>participaram da linha de base, 903 em 4<br>anos, 816 em 10 anos e 667 em 14 anos,<br>567 em 20 anos e 520 em 25 anos de<br>seguimento.|25.1 anos (0.6)|Baixo Risco|
|**Genuth et**<br>**al. 2005**<sup>**9**</sup>|Estudo<br>observacional<br>prospectivo|Investigar se a glicação do<br>colágeno da pele e os<br>produtos terminais da<br>glicação avançada (AGEs)<br>predizem o risco de<br>progressão de RD|Participantes com diabetes tipo 1<br>do DCCT (ensaio clínico) que<br>foram acompanhados no EDIC<br>(coorte) durante 10 anos.|No total 211 participantes foram<br>acompanhados, desses 184 realizaram o<br>exame de fotografia do fundo do olho<br>(117 não tiveram RD e 67 que realizaram<br>biópsia da pele tiveram progressão da<br>RD, sendo que 28 (27%) era do grupo de<br>terapia intensiva e 39 (49%) era o grupo<br>de tratamento convencional)|10 anos|Baixo risco|  
24  
|**Autor,**<br>**ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Tamanho de amostra**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Klein et**<br>**al. 1998**<sup>**13**</sup><br>**Klein et**<br>**al. 1989**<sup>**165**</sup>|Estudo<br>observacional<br>prospectivo -<br>Wisconsin study|Examinar em 14 anos de<br>seguimento a incidência e<br>progressão de RD e edema<br>macular e seus fatores de<br>risco relacionados.|Pacientes com diabetes tipo 1 que<br>foram diagnosticados antes dos 30<br>anos de idade e utilizavam insulina|1210 foram incluídos no<br>acompanhamento. Desses 996<br>participaram da linha de base, 891 em 4<br>anos de seguimento, 765 em 10 anos e<br>634 em 14 anos de seguimento.<br>Totalizando 634 participantes, 75 não<br>participantes e 56 faleceram em 14 anos<br>de seguimento|14.4 anos (0.5)|Baixo risco|
|**Stratton**<br>**et al.**<br>**2001**<sup>**18**</sup>|Estudo<br>observacional<br>prospectivo-<br>UKPDS|Determinar os fatores de<br>risco relacionados com a<br>incidência e progressão de<br>RD em pacientes com<br>diabetes tipo 2|Pacientes recém-diagnosticados<br>com diabetes tipo 2 que haviam<br>disponível dados de fotografia de<br>fundo|1919 pacientes<br>(Grupo com RD:703)<br>(Grupo sem RD:1216)|6 anos|Baixo risco|
|**Klein et**<br>**al. 1995**<sup>**166**</sup>|Estudo<br>observacional<br>prospectivo -<br>Wisconsin study|Determinar a relação entre a<br>mudança do número de<br>microaneurismas na retina e<br>a incidência de RDNP<br>moderadamente severa,<br>RDP e edema macular<br>clinicamente significante.|Grupo de início jovem: pacientes<br>que foram diagnosticados com<br>diabetes antes dos 30 anos de idade<br>Grupo de início tardio: pacientes<br>que foram diagnosticados com<br>diabetes depois de 30 anos de<br>idade ou mais.|n=236 ( sendo que 189 concluíram o<br>seguimento e 47 não concluíram- não<br>participantes)<br>Grupo de início jovem: 129<br>Grupo de início tardio; 30 utilizavam<br>insulina e 30 não utilizavam insulina|10 anos|Baixo risco|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; n= número de pacientes.</mark>  
**Tabela 2 –** <mark>Características dos pacientes dos estudos incluídos</mark>  
|**Autor, ano**|**Idade (anos), média (DP)**|**Valor p**|**% sexo masculino**|**Valor p**|**Principais medidas clínicas e bioquímicas de base, média (DP)**|**Valor p**|
|---|---|---|---|---|---|---|
|**Autor, ano**|Grupo Progressão: 68.32 (14.86)<br>Grupo Não progressão: 65.87 (15.33)|0,02|Grupo de Progressão: 38,36<br>Grupo de Não progressão: 35,8|NS|**HbA1C basal:**<br>Grupo de Progressão: 5.99 (0.92)<br>Grupo de Não progressão: 5.43 (0.62)|<0,001|  
25  
|**Autor, ano**|**Idade (anos), média (DP)**|**Valor p**|**% sexo masculino**|**Valor p**|**Principais medidas clínicas e bioquímicas de base, média (DP)**|**Valor p**|
|---|---|---|---|---|---|---|
|**Jin et al. 2015**<sup>**12**</sup>|Grupo de Progressão: 56.15 (12.52)<br>Grupo de Não progressão: 56.86 (12.62)|NS|Grupo de Progressão: 43.52<br>Grupo não progressão: 53.4|NS|**HbA1C basal:**<br>Grupo de Progressão: 9.13 (2.71)<br>Grupo de Não progressão: 8.41 (2.32)<br>**Glicose:**<br>Grupo de Progressão: 8,71 (2,78)<br>Grupo de Não progressão: 7.94 (2.63)<br>**Taxa de filtração Glomerular:**<br>Grupo de Progressão: 114.81 (39.15)<br>Grupo de Não progressão: 103.23 (32.18)<br>**Albumina glicada:**<br>Grupo de Progressão: 22.66 (5.92)<br>Grupo de Não progressão:19.83 (5.18)|<0,05<br><0,05<br><0,01<br><0,01|
||||||**HbA1c basal:**<br>Grupo com regressão: 5.66 (1.76)<br>Grupo não regressão: 7.68 (2.18)|<0,01|
|**Pan et al. 2014**<sup>**17**</sup>|Grupo com regressão de RD: 67.15 (13.72)<br>Não regressão de RD: 69.27 (11.75)|NS|Grupo com regressão: 43 (39,09)<br>Grupo não regressão: 141(40,75)|NS|**Hiperlipidemia (%):**<br>Grupo com regressão: 35 (31.82)<br>Grupo não regressão: 147 (42.49)<br>**Duração do diabetes:**<br>Grupo com regressão:10.26 (7.53)<br>Grupo não regressão: 12.27 (8.11)|0,04<br>0,01|
|**Jin et al. 2014**<sup>**11**</sup>|Desfechos visuais pobres: 64.9<br>Desfechos visuais melhores: 62.4|0,02|Desfechos visuais pobres: 41<br>Desfechos visuais melhores: 65|0,03|**Duração do edema macular diabético (meses)**<br>Desfechos visuais pobres: 32.3<br>Desfechos visuais melhores: 23.6<br>**Melhor acuidade visual corrigida- ETDRS (Média)**<br>Desfechos visuais pobres: 16.8 (20/125)<br>Desfechos visuais melhores: 30.4 (20/63)<br>**Média da Espessura foveal**<br>Desfechos visuais pobres: 496.6<br>Desfechos visuais melhores: 427.**0**|0,29<br><0,001<br>0,06|
|**Channa et al.**<br>**2014**<sup>**161**</sup>|NR (13-39)|0,9|NR|NR|**HbA1c (%) basal:**<br>Grupo NIT 7.3 (0.9)  vs. Grupo CON: 9 (1.3)<br>**Duração do diabetes (anos)**:<br>Grupo NIT: 12.2 (4.9) vs. Grupo CON: 11.8 (4.9)|<br><0,001<br>0,14|
|**Aiello, 2014**<br>**(DCCT. 1996)**<sup>**8,162**</sup>|NR|NR|NR|NR|**IMC:**30.77 (5.43)<br>**Colesterol (mmol/l):**4.57 (1.05)<br>**Pressão Arterial Sistólica (mmHg):**139.60 (17.28)<br>**Pressão Arterial Diastólica (mmHg):**77.01 (10.41)<br>**HbA1c %:**7.2 (3.6)|NR|  
26  
|**Autor, ano**|**Idade (anos), média (DP)**|**Valor p**|**% sexo masculino**|**Valor p**|**Principais medidas clínicas e bioquímicas de base, média (DP)**|**Valor p**|
|---|---|---|---|---|---|---|
|**Liu et al, 2013**<sup>**16**</sup>|NR|NR|NR|NR|**Idade do diagnóstico do diabetes entre 0-4 anos; 5-14 anos;**<br>**>15 anos; todos os pacientes, respectivamente:**<br>**Duração do diabetes (anos)**<br>31.12 (29.5- 32.7) *; 26.1 (25.1- 27.0) *; 21.0 (19.9- 22.1) *; 25.0<br>(24.4-25.7)<br>**RDP (%)**<br>47.0 (39.5- 54.6) ¶; 38.8 (34.7- 42.9) ¶; 18.9 (15.0- 22.7) *; 32.9<br>(30.0-35.6)<br>**Duração da RDP (anos)**<br>24.3 (22.7- 25.9) ¶; 20.1 (19.2- 21.1) *;21.6 (19.8- 23.3); 21.3<br>(20.6- 22.1)<br>**HbA1c (%)**<br>8.8 (8.5- 9.0) ¶; 8.5 (8.4- 8.6); 8.3 (8.1- 8.4) *; 8.4 (8.4- 8.5)<br>**Pressão Arterial Média (mmHg)**<br>96.6 (94.9- 98.3); 97.3 (96.4- 98.2); 99.0 (97.9- 100.1); 97.8<br>(97.2- 98.5)<br>**IMC**<br>24.8 (24.3- 25.4); 24.9 (24.6- 25.2); 25.4 (25.0- 25.8); 25.0 (24.8-<br>25.3)|¶= <0,005<br>(diferença<br>entre dois<br>grupos)<br>*=<0,05<br>(diferença<br>entre três<br>grupos)|
|**Hietala et al.**<br>**2010**<sup>**10**</sup>|63|NA|50|NA|**Fotocoagulação macular anterior**: 198 (60%) olhos<br>**Pacientes que havia realizado fotocoagulação anterior ao**<br>**estudo:**2.8 (1.3)|NA<br>0,15|
||||||**Paciente que não havia realizado fotocoagulação anterior ao**<br>**estudo:**3.1 (1.6)||
|**Aiello et al.**<br>**2010**<sup>**163**</sup>|24.9 (9.3)|NA|49.8|NA|**Duração do diabetes (anos)**: 10.7 (7.1)<br>**HbA1c (%)**: 10.5 (2.0)<br>**Pressão Arterial Sistólica vs. Pressão Arterial Diastólica**<br>**(mmHg):**118.4 (14.0) vs. 77.0 (10.6)<br>**Presença de Proteinúria (%):**12.3<br>**IMC:**23.1 (3.8|NA|
|**Klein et al. 2009**<sup>**15**</sup>|24.9 (9.3)|NA|49.8|NA|**Duração do diabetes (anos):**10.7 (7.1)<br>**HbA1c (%):**10.5 (2.0)<br>**Pressão Arterial Sistólica vs. Pressão Arterial Diastólica**<br>**(mmHg):**118.4 (14.0) vs. 77.0 (10.6)<br>**Presença de Proteinúria (%):**12.3<br>**IMC:**23.1 (3.8)|NA|  
27  
|**Autor, ano**|**Idade (anos), média (DP)**|**Valor p**|**% sexo masculino**|**Valor p**|**Principais medidas clínicas e bioquímicas de base, média (DP)**|**Valor p**|
|---|---|---|---|---|---|---|
|**Genuth et al.**|||||**HbAc1-  linha de base do DCCT**<br>8.8 (1.7)||
|**2005**<sup>**9**</sup>|28 (7)|NA|48|NA|<br>**Fechamento do DCCT e linha de base do EDIC**<br>**HbAc1 média no DCCT**<br>8.0 (1.6)|NA|
|**Klein et al. 1998**<sup>**13**</sup>|||||**Duração do diabetes (anos):**12.6 (9.0)<br>**HbA1c (%):**10.6 (2.0)||
|**Klein et al.**<br>**1989**<sup>**165**</sup>|26.8 (11.2)|NA|49.2|NA|**Pressão Arterial Sistólica vs. Pressão Arterial Diastólica**<br>**(mmHg):**120 (16) vs. 77 (11)<br>**Presença de proteinúria (%):**15.5<br>**Presença de Hipertensão (%):**14.7|NA|
|**Stratton et al.**<br>**2001**<sup>**18**</sup>|Grupo com RD: 52.2 (8.6<br>Grupo sem RD: 52.2 (8.5)|0,96|Grupo com RD: 57<br>Grupo sem RD: 61.4|0,056|**HbA1c (5):**<br>Grupo com RD: 7.2 (1.7)<br>Grupo sem RD: 7.0 (1.7)<br>**% tabagismo (não/ex/atual):**<br>Grupo com RD: 36.4 vs. 35.0 vs. 28.6<br>Grupo sem RD: 33.9 vs. 35.5 vs. 30.6|0,0018<br>0,48|
|**Klein et al.**<br>**1995**<sup>**166**</sup>|37.3 (17.7)|NA|47.1|NA|**Duração do diabetes (anos):**11.7 (8.3)<br>**HbA1c:**7.3 (17.7)<br>**Número de microaneurisma:**6.2 (7.5)|NA|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; IMC: índice de massa corporal; HbA1c: hemoglobina glicada; DP: desvio padrão; NS: não significante; NA: não se aplica; NR: não reportado.</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1. Fatores de Prognóstico: Hemoglobina Glicada e Albumina Glicada** -->
**Tabela 3 –** <mark>Associação entre hemoglobina glicada, albumina glicada e progressão ou regressão de retinopatia diabética ou incidência de edema macular diabético</mark>  
|**Autor, ano**|**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**<br>**(OR, RR, HR, RRR)**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|**Jin et al. 2015**<sup>**12**</sup>|HbA1c basal|Progressão de RD|Grupo de progressão<br>(HbA1c base 5.99)|Grupo de não progressão<br>(HbA1cbase 5,43)|OR: 2.84|(2,11-3,82)|>0.05|  
28  
|**Autor, ano**|**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**<br>**(OR, RR, HR, RRR)**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|**Pan et al. 2014**<sup>**17**</sup>|HbA1c média|Progressão de RD|Grupo de progressão<br>(HbA1c média 8.31)|Grupo de não progressão<br>(HbA1c média 7.39)|OR:1.389|(1.023-1.884)|>0.05|
||Albumina glicada<br>média- AG|Progressão de RD|Grupo de progressão<br>(AG base: 22.66)|Grupo de não progressão<br>(AG base: 19.83)|OR:1.087|(1.004-1.178)|0,039|
|**Aiello, 2014**<br>**(DCCT. 1996)**<sup>**8,162**</sup>||**Progressão de RD ≥3-passos:**<br>DCCT: 6.5 anos;<br>EDIC: 4anos seguimento|||RRR: 76%<br>RRR: 74%|NR|<0,0001<br><0,0001<br>|
|||<br>EDIC:10 anos de seguimento|||RRR:57%||<0,0001|
|||**RDNP severa:**<br>DCCT: 6.5 anos;|||RRR:66%|NR|<0,0001|
|||EDIC: 4 anos de seguimento|||RRR: 68%||<0,0001|
|||EDIC: 10 anos de seguimento|Grupo de Efeito do|Grupo de Tratamento|RRR:58%||<0,0001|
||Controle<br>Glicêmico|**RDP:**<br>DCCT: 6.5 anos|tratamento intensivo de<br>insulina-INT<br>(HbA1c média de 7%)|convencional convencional-<br>CON<br>(HbA1C média de 9%)|RRR:64%|NR|<0,0001|
|||EDIC: 4 anos de seguimento|||RRR: 65%||<0,0001|
|||EDIC:10 anos de seguimento|||RRR:58%||<0,0001|
|||**Edema macular diabético**<br>**Clinicamente significante:**<br>DCCT: 6.5 anos;<br>EDIC: 4 anos de seguimento<br>|||RRR:51%<br>RRR: 62%|NR|<0,0001<br>0,009|
|||EDIC: 10 anos de seguimento|||RRR:38%||<0,0001|
|**Jin et al. 2014**<sup>**11**</sup>|HbA1c basal|Regressão de RD|Grupo não regressão da RD<br>(HbA1c base 7.68)|Grupo com regressão da RD<br>(HbA1c base 5.66)|OR: 0.53|(0.44- 0.63)|<0.05|
||HbA1c basal|Sem histórico de RD para histórico de<br>RD leve|<7.2|>7.2|HR: 1.42|(1.32- 1.52)|<0,05|
|**Liu et al, 2013**<sup>**16**</sup>|HbA1c basal|Histórico de RD leve para RD visível<br>leve|<7.2|>7.2|HR: 1.32|(1.08- 1.60)|<0,05|
||HbA1c basal|RD visível leve para RDNP severa ou<br>RDP|<7.2|>7.2|HR: 2.23|(1.16- 4.29)|<0,05|  
29  
|**Autor, ano**|**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**<br>**(OR, RR, HR, RRR)**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
||HbA1c basal|Histórico de RD leve para sem RD|<7.2|>7.2|HR: 0.76|(0.64- 0.97)|<0,05|
|**Hietala et al. 2010**<sup>**10**</sup>|HbA1c basal|Incidência de RDP|Grupo com RDP<br>(HbA1c base 8.7)|Grupo sem RD<br>(HbA1c base 8.1)|HR: 1.15|(1.07- 1.23)|<0,0001|
|**Klein et al. 2009**<sup>**15**</sup>|HbA1c basal<br>(A cada 1%)|Incidência de edema macular diabético|Acima de 9.5%|Abaixo de 9.5%|HR: 1.17|(1.10- 1.25)|<0,001|
|**Genuth et al. 2005**<sup>**9**</sup>|HbA1c média|Progressão de RD|Acima de 9%|Abaixo de 9%|OR: 4.8|(1.8- 13.2)|<0,001|
|||Progressão de RD|Acima de 9.5%|Abaixo de 9.5%|HR: 1.32|(1.26- 1.38)|<0,001|
|**Klein et al. 2008**<sup>**14**</sup>|HbA1c basal|Incidência de RDP|Acima de 9.5%|Abaixo de 9.5%|HR: 1.38|(1.31- 1.46)|<0,001|
|||Melhora de RD de dois ou mais níveis|Acima de 9.5%|Abaixo de 9.5%|HR: 0.84|(0.77- 0.91)|<0,001|
|**Stratton et al.**<br>**2001**<sup>**18**</sup>|HbA1c basal|Progressão de RD|Pacientes com faixas de<br>valores de HbA1c:<br>6.2- 7.4<br>≥ 7.5|Pacientes com faixas de<br>valores de HbA1c:<br><6.2|--<br>RR: 4.1<br>RR: 8.1|--<br>(3.1- 5.6)<br>(6.3- 10.5)|<0,001|
|**Klein et al. 1998**<sup>**13**</sup>||Progressão de RD|Pacientes com faixas de<br>valores de HbA1c:<br>9.5- 10.5<br>10.6- 12.0<br>12.1- 19.5|Pacientes com faixas de<br>valores de HbA1c:<br>5.6 - 9.4|--<br>--<br>RR:1.99<br>RR:2.64|--<br>(1.12- 1.68)<br>(1.67- 2.38)<br>(2.18- 3.20)|<0,001|
||HbA1c basal|||||||
|**Klein et al. 1989**<sup>**165**</sup>|||Pacientes com faixas de<br>valores de HbA1c:<br>9.5- 10.5|Faixas de valores de HbA1c:<br>|--<br>RR:2.81|--<br>(1.77- 4.47)||
|||Progressão para RDP|10.6- 12.0<br>12.1- 19.5|5.6- 9.4|RR:4.42<br>RR:6.23|<br>(2.90- 6.72)<br>(4.21- 9.22)|<0,001|  
30  
|**Autor, ano**|**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**<br>**(OR, RR, HR, RRR)**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|||Incidência de edema macular diabético|Pacientes com faixas de<br>valores de HbA1c:<br>9.5- 10.5<br>10.6- 12.0<br>12.1- 19.5|Pacientes com faixas de<br>valores de HbA1c:<br>5.6- 9.4|--<br>RR:1.90<br>RR:3.11<br>RR:6.23|--<br>(1.12- 3.25)<br>(1.95- 4.95)<br>(2.21- 5.34)|<0,001|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; DCCT:</mark> _<mark>estudo Diabetes ControlandComplications</mark>_ <mark>; EDIC:</mark> _<mark>estudo Epidemiologyof Diabetes InterventionsandComplications</mark>_ <mark>; INT: grupo tratamento intensivo; COM: grupo tratamento convencional; HbA1c: hemoglobina glicada; NR: não reportado; RR: risco relativo; OR: Oddsratio ou razão de chances; HR: hazardratio.</mark>  
31  
**2. Fator Prognóstico: Pressão Arterial**  
**Tabela 4 –** Associação entre pressão arterial e progressão ou regressão de retinopatia diabética ou incidência de edema macular diabético  
|**Autor, ano**|**Fatores Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|**Li  l 2013**<sup>**16**</sup>|Pressão Arterial<br>Sistólica|Sem histórico de RD<br>para Histórico de RD<br>leve|<139.60 mmHg|>139.60 mmHg|HR:1.20|(1.11- 1.30)|<0,05|
|**u et a,**|Pressão Arterial<br>Diastólica|Histórico de RD leve<br>para histórico de RD<br>visível|< 77. 01 mmHg|> 77.01 mmHg|HR:1.87|(1.46- 2.40)|<0,05|
||Pressão Arterial<br>Sistólica|Histórico de RD leve<br>para sem RD|<139.60 mmHg|>139.60 mmHg|HR:0.79|(0.64- 0.89)|<0,05|
|**Hietala et al. 2010**<sup>**10**</sup>|Pressão Arterial Média|Incidência de RDP|102.3 mmHg|93.7 mmHg|HR:1.03|(1.02- 1.04)|<0,001|
|**Klein et al. 2009**<sup>**15**</sup>|Pressão Arterial<br>Sistólica|Incidência de edema<br>macular diabético|88.3mmHg|88.0mmHg|HR:1.15|(1.04- 1.26)|0,004|
|**Klein et al. 2008**<sup>**14**</sup>|Pressão Arterial<br>Sistólica|Incidência de RDP|88.3mmHg|88.0mmHg|HR:1.14|(1.04- 1.25)|0,005|
|**Klein et al. 1998**<sup>**13**</sup>|Pressão Arterial<br>Diastólica|Progressão de RD|Pacientes com faixas de<br>pressão arterial<br>diastólica entre (mmHg):<br>72- 78<br>79- 85<br>86- 117|Pacientes com faixas de<br>pressão arterial<br>diastólica entre (mmHg):<br>42-71|--<br>RR:1.13<br>RR:1.99<br>RR:1.20|--<br>(0.96- 1.32)<br>(0.99- 1.38)<br>(1.00- 1.43)|<0,05|
|**Klein et al. 1989**<sup>**165**</sup>|Pressão Arterial<br>Sistólica|Progressão para RDP|Pacientes com faixas de<br>pressão arterial sistólica<br>entre (mmHg):<br>111- 120<br>121- 134<br>135- 221|Pacientes com faixas de<br>pressão arterial sistólica<br>entre (mmHg):<br>78- 110|--<br>RR:1.12<br>RR:1.56<br>RR:2.06|--<br>(0.80- 1.57)<br>(1.14- 2.15)<br>(1.43- 2.96)|<0,001|  
32  
|**Autor, ano**|**Fatores Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
||Pressão Arterial<br>Diastólica|Progressão para RDP|Pacientes com faixas de<br>pressão arterial<br>diastólica entre (mmHg):<br>72- 78<br>79- 85<br>86- 117|Pacientes com faixas de<br>pressão arterial<br>diastólica entre (mmHg):<br>42-71|---<br>RR:1.46<br>RR:1.69<br>RR:2.56|--<br>(1.03- 2.06)<br>(1.20- 2.39)<br>(1.82- 3.58)|<0,001|
||Hipertensão|Progressão para RDP|Presença de hipertensão|Ausência de hipertensão|--<br>RR:1.91|--<br>(1.41- 2.59)|<0,001|
||Pressão Arterial<br>Diastólica|Incidência de edema<br>macular diabético|Pacientes com faixas de<br>pressão arterial<br>diastólica entre (mmHg):<br>72- 78<br>79- 85<br>86- 117|Pacientes com faixas de<br>pressão arterial<br>diastólica entre (mmHg):<br>42-71|--<br>RR:1.30<br>RR:1.16<br>RR:1.76|--<br>(0.86- 1.93)<br>(0.75- 1.80)<br>(1.16- 2.67)|<0,05|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; IC 95%: intervalo de confiança 95%; RR: risco relativo; OR: Oddsratio; HR: hazardratio.</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3. Fatores de Prognóstico: Sexo, Idade e Idade do Diagnóstico do Diabetes** -->
**Tabela 5 –** Associação entre sexo, idade do diagnóstico do diabetes e progressão de retinopatia diabética e incidência de retinopatia diabética proliferativa.  
|**Autor, ano**|**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|**Klein et al. 2008**<sup>**14**</sup>|Sexo<br>Sexo|Progressão de RD<br>Incidência de RDP|Masculino<br>Masculino|Feminino<br>Feminino|HR:1.33<br>HR: 1.21|(1.11- 1.58)<br>(1.07- 1.36)|<0,001<br>0,002|
||Sexo|Progressão de RD|Feminino|Masculino|RR:0.54|(0.37- 0.80)|0,0016|
|**Stratton et al.**<br>**2001**<sup>**18**</sup>|Idade|Progressão de RD|50-57 anos<br>58 ou mais|<50 anos|--<br>RR:1.6<br>RR:2.1|--<br>(1.2- 2.2)<br>(1.5- 2.7)|0,0012|
|**Klein et al. 1998**<sup>**13**</sup>||||||||
|**Klein et al. 1989**<sup>**164**</sup>|Sexo|Progressão de RD|Feminino|Masculino|--<br>RR: 0.83|--<br>(0.73- 0.93)|<0,005|  
33  
|**Autor, ano**|**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
||Idade do||Grupo de pacientes com idade<br>de diagnóstico de diabetes|Grupo de idade de diagnóstico||||
|**Hietala et al. 2010**<sup>**10**</sup>|diagnóstico do<br>diabetes|Incidência de RDP|entre:<br>0-4 anos|entre:<br>15-40 anos|--<br>HR:1.61|--<br>(1.16- 2.23)|<0,001|
||||5- 14 Anos||HR: 1.90|(1.45- 2.48)|<0,001|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; IC 95%: intervalo de confiança 95%; RR: risco relativo; HR: hazardratio.</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4. Fatores de Prognóstico: Retinopatia Diabética Basal, Severidade da Retinopatia e Microaneurismas** -->
**Tabela 6 –** Associação entre retinopatia diabética basal, severidade de retinopatia diabética grau 15, diferença no número de microaneurismas na linha de base e tempo de seguimento, taxa do número total de microaneurisma basal e tempo de seguimento e progressão ou regressão de retinopatia diabética ou incidência de edema macular clinicamente significante.  
|**Autor, ano**|**Fatores Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|**Pan et al. 2014**<sup>**17**</sup>|RD basal|Progressão de RD|Grupo Sem RD basal<br>(9.96%)|Grupo com RD basal<br>(31.48%)|OR: 0.391|(0,194-0,789)|0,005|
|**Klein et al. 2008**<sup>**14**</sup>|Severidade de RD grau-<br>15 (a cada 2 níveis)|Progressão de RD|Menor severidade na linha de<br>base|Maior severidade na linha de<br>base|HR: 0.92|(0.86- 0.99)|0,03|
||Diferença do número de<br>microaneurismas basal<br>e após 4 anos|Progressão de RD<br>no grau 43 ou mais|Aumento de 1-4.<br>Aumento de 5-15<br>Aumento de ≥16|Diminuição ou não mudança|--<br>RR: 2.1<br>RR:2.7<br>RR:5.8|--<br>(0.8- 5.8)<br>(1.0- 7.0)<br>(2.5- 13.5)|<0,001|
|**Klein et al.**<br>**1995**<sup>**166**</sup>|Diferença do número de<br>microaneurismas basal<br>e após 10 anos|Incidência de RDP|Aumento de 1-4.<br>Aumento de 5-15<br>Aumento de ≥16|Diminuição ou não mudança|--<br>RR: 0.3<br>RR:1.2<br>RR: 4.6|--<br>(0- 2.5)<br>(0.3- 4.5)<br>(1.8- 12.3)|<0,001|
||Diferença do número de<br>microaneurismas basal<br>e após 10 anos|Incidência de<br>edema macular<br>clinicamente<br>significante|Aumento de 1-4.<br>Aumento de 5-15<br>Aumento de ≥16|Diminuição ou não mudança|--<br>RR: 4.7<br>RR: 0*<br>RR:9.1|--<br>(0.5- 40.6)<br>--<br>(1.2- 67.3)|0,005|
|**Klein et al.**<br>|Taxa do número total<br>de microaneurismas<br>basal e após 4 anos|Progressão de RD<br>no grau 43 ou mais|1.00- 1.99<br>2.00-2.99<br>≥3.00|<1.00|--<br>RR: 1.2<br>RR: 2.6<br>RR: 4.1|--<br>(0.4-3.9)<br>(1.0- 6.9)<br>(1.8- 9.5)|<0,001|
|**1995**<sup>**166**</sup>|Taxa do número total<br>de microaneurismas<br>basal e após 10 anos|Incidência de RDP|1.00- 1.99<br>2.00-2.99<br>≥3.00|<1.00|--<br>RR: 0.3<br>RR: 1.3<br>RR: 3.0|--<br>(0-2.6)<br>(0.4- 4.8)<br>(1.1- 7.9)|<0,001|  
34  
|**Autor, ano**|**Fatores Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|||Incidência de||||||
||Taxa do número total<br>de microaneurismas<br>basal e após 10 anos|edema macular<br>clinicamente<br>significante|1.00- 1.99<br>2.00-2.99<br>≥3.00|<1.00|--<br>RR: 1.2<br>RR: 1.3<br>RR: 6.7|--<br>(0.1-18.1)<br>(0.1- 19.4)<br>(0.9- 48.1)|0,005|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; RR: risco relativo; OR: Oddsratio ou razão de chances; HR: hazardratio;IC 95%: intervalo de confiança 95%; *número de olhos graduados de participantes sob risco insuficientes.</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **5. Fatores de Prognóstico:** **<mark>Proteinúria e Taxa de Filtração Glomerular</mark>** -->
**Tabela 7 –** <mark>Associação entre proteinúria, taxa de filtração glomerular e progressão ou regressão de retinopatia diabética ou incidência de edema macular diabético</mark>  
|**Autor, ano**|**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
|**Pan et al. 2014**<sup>**17**</sup>|Taxa de filtração<br>glomerular basal|Progressão de RD|114.81 ml/min|103.23 ml/min|OR:1.008|(1.000-1.016)|0,045|
|**Klein et al. 2008**<sup>**14**</sup>|Proteinúria|Incidência de RDP|Presença de proteinúria|Ausência de proteinúria|HR: 1.83|(1.31- 2.56)|<0,001|
|**Klein et al. 2009**<sup>**15**</sup>|Proteinúria|Incidência de edema<br>macular diabético|Presença de proteinúria|Ausência de proteinúria|--<br>RR:1.43|--<br>(0.99- 2.08)|0.056|
|**Klein et al. 1998**<sup>**13**</sup>|Proteinúria|Progressão para RDP|Presença de proteinúria|Ausência de proteinúria|--<br>RR:1.96|--<br>(1.43- 2.68)|<0,001|
|**Klein et al. 1989**<sup>**165**</sup>|Proteinúria|Incidência de edema<br>macular diabético|Presença de proteinúria|Ausência de proteinúria|--<br>RR:1.95|--<br>(1.34- 2.82)|<0,001|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; RR: risco relativo; OR: Oddsratio ou razão de chances; HR: hazardratio;IC 95%: intervalo de confiança 95%.</mark>  
**6. Fatores de Prognóstico Diversos** **<mark>: Triglicerídeos, Furosina, Tabagismo e</mark> Índice de Massa Corporal**  
**Tabela 8 –** <mark>Associação entre triglicerídeos sérico, índice de massa corporal, furosina, tabagismo e progressão ou regressão de retinopatia diabética</mark>  
|**Autor, ano**<br>**Fatores**<br>**Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|  
35  
|**Jin et al. 2014**<sup>**11**</sup>|Triglicerídeos<br>sérico|Regressão de RD|Hiperlipidemia no grupo não<br>regressão<br>(42.49%)|Hiperlipidemia no grupo com<br>regressão<br>(31.82%)|OR: 0.77|(0.60-0.99)|0,004|
|---|---|---|---|---|---|---|---|
|**Klein et al. 2008**<sup>**14**</sup>|IMC<br>(a cada 4kg/m2)|Progressão de RD|26.6 kg/m<sup>2</sup>|25.0 kg/m<sup>2</sup>|HR: 1.16|(1.07- 1.26)|<0,001|
||IMC<br>(a cada 4kg/m2)|Melhora de RD de dois<br>ou mais níveis|26.6 kg/m<sup>2</sup>|25.0 kg/m<sup>2</sup>|HR:0.84|(0.77- 0.91)|<0,001|
|**Genuth et al. 2005**<sup>**9**</sup>|Furosina<br>(produto terminal<br>da glicação<br>avançada)|Progressão de RD|Acima de 860 pmol/mg|Abaixo de 860 pmol/mg|OR: 4.8|(1.8- 13.2)|0,0014|
|**Stratton et al.**<br>**2001**<sup>**18**</sup>|Tabagismo|Progressão de RD|Não fumante|Fumante|--<br>RR: 0.50|--<br>(0.36- 0.71)|0,0045|  
<mark>RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; IMC: índice de massa corporal; NR: não reportado; RR: risco relativo; OR: Oddsratio; HR: hazardratio;IC 95%: intervalo de confiança 95%.</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **7. Fatores de Prognóstico Associados à Desfechos Visuais** -->
**Tabela 9 –** Associação entre melhor acuidade visual corrigida, espessura foveal, atrofia foveal e desfechos visuais.  
|**Autor, ano**|**Fatores Associados**|**Desfecho**|**Grupo exposto**|**Grupo não exposto**|**Medidas de associação**|**IC 95%**|**Valor de p**|
|---|---|---|---|---|---|---|---|
||Melhor acuidade<br>visual corrigida basal|Desfecho visuais|Desfechos visuais melhores<br>(>20/100)|Desfechos visuais pobres<br>(≤20/100)|OR: 0.83|(0.75- 0.93)|0,001|
|**Channa et al.**<br>**2014**<sup>**161**</sup>|Espessura Foveal aos<br>24 meses|Desfecho visuais|Desfechos visuais pobres<br>(≤20/100)|Desfechos visuais melhores<br>(>20/100)|OR: 1.008|(1.002- 1.013)|0,01|
||Atrofia Foveal|Desfecho visuais|Desfechos visuais pobres<br>(≤20/100)|Desfechos visuais melhores<br>(>20/100)|OR: 14.3|(1.8- 117.1)|0,01|
|**Aiello, 2014**|Pontuação de letras<br>de acuidade visual<br>basal|Melhora da visão<br>(Ganho de 10<br>letras)|73-60 letras<br>(20/32 para 20/63)|59- 24 Letras<br>(20/63 para 20/320)|--<br>OR:0.39|--<br>(0.24- 0.62)|<0,001|
|**(DCCT. 1996)**<sup>**8,162**</sup>|Volume retinal de<br>Tomografia de<br>Coerência Óptica|Piora da visão<br>(Perda de 10 letras)|<9.2 mm<sup>3</sup>|≥9.2 mm<sup>3</sup>|--<br>OR: 0.68|--<br>(0.38- 1.24)|0,01|  
<mark>OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança 95%.</mark>  
36

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **B. Questão de pesquisa 2** -->
**Questão de Pesquisa 2:** Qual a sensibilidade e a especificidade dos diversos métodos (fundoscopia direta e indireta, retinografia não midriática e midriática, retinografiawidefield) para o diagnóstico de retinopatia diabética?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Medline via Pubmed** -->
(((((("Sensitivity and Specificity"[Mesh] OR (Specificity and Sensitivity) OR sensitivity OR specificity OR “diagnostic accuracy”)))) AND ("Ophthalmoscopy"[Mesh] OR Retinoscopy OR retinography OR funduscopy))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)  
Resultado: 187 referências  
Data: 28/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('sensitivity'/exp OR 'sensitivity' OR 'specificity'/exp OR 'specificity' OR 'sensitivity and specificity'/exp OR 'sensitivity and specificity' OR 'diagnostic accuracy'/exp OR 'diagnostic accuracy') AND ('ophthalmoscopy'/exp OR 'ophthalmoscopy' OR 'retinography'/exp OR 'retinography' OR 'retinoscopy'/exp OR 'retinoscopy' OR 'funduscopy'/exp OR ‘funduscopy') AND [embase]/lim  
Resultado: 218 referências  
Data: 28/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Somente foram inclusos estudos de acurácia diagnóstica transversais ou de caso-controle diagnóstico, que tivessem definido medidas de sensibilidade e especificidade (ou permita o cálculo) e com padrão de referência definido. Estudos que compararam diferenças de leitura entre os tipos de profissionais, para o mesmo equipamento (ex. especialista x generalista), não foram incluídos. Foram importadas 187 referências da MEDLINE e mais 218 da EMBASE. Foram retiradas 55 duplicatas, restando 350 artigos para serem avaliados por título e resumo. Após a leitura de títulos e resumo foram selecionadas 52 referências para leitura completa.  
Dessas 52, três eram revisões sistemáticas sem meta-análise e foram excluídas pois decidimos incluir os estudos individuais contidos nelas (a nossa busca recuperou quantidade maior de referências) ou por conterem estudos que avaliavam a capacidade de leitura dos resultados entre diferentes profissionais (ex: oftalmologista vs. médico generalista). De uma dessas revisões<sup>167</sup> foram incluídas, manualmente, 17 referências.  
Da nossa estratégia de busca original, além das três revisões sistemáticas citadas acima, foram excluídas mais 14 referências, duas por se tratarem de estudo com equipamento protótipo, uma avaliou leitura de câmera de smartphone, uma revisão narrativa da literatura, oito estudos com o mesmo equipamento manuseado por profissionais de saúde diferentes, um estudo de custo efetividade sem dados de acurácia e outro estudo, antigo, sem dados de acurácia diagnóstica. Dessa forma, somando-se as 17 referências obtidas através da revisão sistemática<sup>167</sup> com as 35 obtidas pela busca temos 52 referências, sendo um caso-controle diagnóstico<sup>61</sup> e 51 estudos transversais de acurácia diagnóstica<sup>25-58,60-71,167-171</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e resultados</mark>** -->
A **Tabela 10** a seguir exibe as características dos estudos e pacientes incluídos para a resposta à questão de pesquisa 2. As **tabelas 11 a 23** exibem os principais resultados de acurácia diagnóstica dos estudos. As tabelas de resultados foram organizadas, primeiramente, de acordo com teste índice e, em seguida, pelo teste referência.  
37  
**Tabela 10 –** Características dos estudos e pacientes incluídos  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Amostra (N)**|**Idade média, anos**<br>**(DP)**|**Sexo masc. (%)**|**HbA1c (%), média**<br>**(DP)**|**Acuidade visual**<br>**(Logmar (DP)**|**Espessura central da**<br>**fóvea (µm (DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Ahsan et al. 2014**<sup>**26**</sup>|Transversal|728 olhos|48,8 (8,0)|37,4|9,73 (3,28)|NR|NR|Baixo|
|**Ibanez et al. 2013**<sup>**168**</sup>|Transversal|650 olhos|NR|NR|NR|NR|NR|Alto (não é possível ter certeza<br>se houve mascaramento dos<br>avaliadores de referência e<br>índice, aparentemente estudo<br>não single-gate)|
|**Vujosevic et al.**<br>**2012**<sup>**169**</sup>|Transversal|263 olhos|48,8 (11,5)|64|NR|NR|323,4 (125,2)|Baixo|
|**Waldstein et al.**<br>**2012**<sup>**170**</sup>|Transversal|125 olhos|63 (15)|65|NR|NR|NR|Moderado (origem dos dados<br>retrospectiva, pacientes já<br>haviam sido diagnosticados com<br>RD)|
|**Wilson et al. 2010**<sup>**71**</sup>|Transversal|380 pacientes|Mediana 67,4 (IQR<br>21-94)|60,5|NR|NR|NR|Baixo|
|**Emanuele et al.**<br>**2009**<sup>**32**</sup>|Transversal|340 pacientes|61,3 (8,8)|NR|9,3 (1,4)|NR|NR|Moderado (tempo longo entre a<br>realização dos testes (60 dias);<br>não é possível ter certeza se os<br>pesquisadores foram mascarados<br>quanto ao resultado dos testes)|
|**Aptel et al.**<br>**2008**<sup>**27**</sup>|Transversal|158 olhos|52,4 (variação 16;<br>89)|37 homens|NR|NR|NR|Baixo|
|**Neubauer et al.**<br>**2008**<sup>**50**</sup>|Transversal|51 olhos|60 (12,1)|NR|7,0 (1,3)|0,48 (0,40)|NR|Baixo|
|**Chun et al. 2007**<sup>**31**</sup>|Transversal|392 olhos|NR|50,8|NR|NR|NR|Baixo|
|**Lopez-Bastida et al.**<br>**2007**<sup>**44**</sup>|Transversal|1546 olhos|Mediana 50,8|48|NR|NR|NR|Baixo|  
38  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Amostra (N)**|**Idade média, anos**<br>**(DP)**|**Sexo masc. (%)**|**HbA1c (%), média**<br>**(DP)**|**Acuidade visual**<br>**(Logmar (DP)**|**Espessura central da**<br>**fóvea (µm (DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Tanterdthan et al.**<br>**2007**<sup>**68**</sup>|Transversal|225 olhos|57,97(11,35)|35|NR|NR|NR|Baixo|
|**Ahmed et al. 2006**<sup>**25**</sup>|Transversal|482 olhos|60 (11,3)|54|7,53 (0,78)|NR|NR|Alto (Não certeza se os<br>avaliadores eram mascarados<br>quanto aos resultados de grupo<br>padrão e índice; tempo grande<br>entre a realização dos dois<br>testes; perdas evitáveis)|
|**Goebel et al. 2006**<sup>**171**</sup>|Transversal|124 olhos|61,1 (14)|NR|NR|NR|cutoff OCT: 268<br>cutoff RTA: 231|Moderado (Os testes índice e<br>padrão não foram aplicados a<br>toda a população)|
|**Phiri et al.**<br>**2006**<sup>**55**</sup>|Transversal|196 pacientes (392<br>olhos)|68,8|57|NR|NR|NR|Baixo|
|**Kuo et al.**<br>**2005**<sup>**41**</sup>|Transversal|100 olhos|59|61|NR|NR|NR|Moderado (estudo retrospectivo<br>e não cita a diferença de tempo<br>na aplicação de testes padrão e<br>índice)|
|**Ruamviboonsuk et**<br>**al. 2005**<sup>**57**</sup>|Transversal|150 pacientes (130<br>analisados)|20-40: 9<br>41-60: 82<br>> 60: 59|25|NR|NR|NR|Baixo|
|**Chia et al.**<br>**2004**<sup>**30**</sup>|Transversal|78 olhos|Homens: 62,4 (faixa<br>43-76)<br>mulheres: 61,2<br>(faixa 37; 84)|44|NR|NR|NR|Baixo|
|**Lawrence et al.**<br>**2004**<sup>**42**</sup>|Transversal|254 pacientes|67,5|98,4|9,76 (variação 5,8;<br>18,5)|NR|NR|Baixo|
|**Murgatroyd et al.**<br>**2004**<sup>**49**</sup>|Transversal|398 pacientes|63 (IQR: 51,8; 70,3)|57|NR|NR|NR|Baixo|  
39  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Amostra (N)**|**Idade média, anos**<br>**(DP)**|**Sexo masc. (%)**|**HbA1c (%), média**<br>**(DP)**|**Acuidade visual**<br>**(Logmar (DP)**|**Espessura central da**<br>**fóvea (µm (DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Saari et al.**<br>**2004**<sup>**59**</sup>|Caso-controle|70 pacientes|41,8 (19,1)|53|NR|NR|NR|Alto (os testes não foram<br>aplicados em todos os<br>indivíduos; o teste referência<br>contém os índices)|
|**Stellingwerf et al.**<br>**2004**<sup>**67**</sup>|Transversal|282 pacientes (259<br>JPEG e 157<br>integral)|NR|NR|NR|NR|NR|Moderado (nem todos os<br>pacientes realizaram os dois<br>testes índices)|
|**Boucher et al.**<br>**2003**<sup>**28**</sup>|Transversal|98 pacientes|59,9 (12,2)|47|NR|NR|NR|Baixo|
|**Gresset et al. 2003**<sup>**33**</sup>|Transversal|NR|NR|NR|NR|NR|NR|Alto (não descreve o número de<br>participantes; não detalha<br>mascaramento; resumo de<br>congresso com pouco<br>detalhamento)|
|**Herbert et al. 2003**<sup>**35**</sup>|Transversal|145 pacientes|NR|NR|NR|NR|NR|Baixo|
|**Massin et al. 2003**<sup>**46**</sup>|Transversal|147 olhos|52 (variação 25-74)|62|NR|NR|NR|Baixo|
|**Neubauer et al.**<br>**2003**<sup>**172**</sup>|Transversal|31 olhos|64 (10)|NR|NR|NR|NR|Moderado (nem todos os<br>pacientes realizaram o teste<br>índice; poucos pacientes<br>avaliados)|
|**Olson et al.**<br>**2003**<sup>**52**</sup>|Transversal|586 pacientes|56,5 (variação 15,9;<br>85,4)|65|NR|NR|NR|Baixo|
|**Scanlon et al. 2003**<sup>**61**</sup>|Transversal|1549 pacientes|65|NR|NR|NR|NR|Alto (longo prazo de duração da<br>medida pelo teste padrão;<br>conhecimento de características<br>e prontuário pelos avaliadores<br>do teste índice)|  
40  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Amostra (N)**|**Idade média, anos**<br>**(DP)**|**Sexo masc. (%)**|**HbA1c (%), média**<br>**(DP)**|**Acuidade visual**<br>**(Logmar (DP)**|**Espessura central da**<br>**fóvea (µm (DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Scanlon et al.**<br>**2003b**<sup>**60**</sup>|Transversal|239 pacientes (405<br>olhos para oftalmo<br>vs. 7 campos; 399<br>para 45° vs. 7<br>campos; 472 para<br>45° vs. oftalmo)|NR|NR|NR|NR|NR|Baixo|
|**Lin et al.**<br>**2002**<sup>**43**</sup>|Transversal|197 pacientes|21-29: 1%<br>30-39: 5%<br>40-49: 20%<br>50-59: 29%<br>60-69: 26%<br>70-79: 16%<br>≥80: 3%|58|NR|NR|NR|Baixo|
|**Marbeley et al.**<br>**2002**<sup>**45**</sup>|Transversal|100 pacientes|54,6 (13,66)|31|NR|NR|NR|Alto (as fotos inicialmente são<br>adquiridas sem midríase, para<br>15 pacientes; posteriormente,<br>devido à baixa qualidade das<br>fotos, os demais pacientes<br>sofreram midríase)|
|**Rudnisky et al.**<br>**2002**<sup>**58**</sup>|Transversal|105 pacientes|Mediana: 60,2<br>(variando de 34 a<br>87)|60,6|NR|NR|NR|Baixo|
|**Bursell et al. 2001**<sup>**29**</sup>|Transversal|54 pacientes|48 (15,2)|57|NR|NR|NR|Baixo|
|**Moller et al. 2001**<sup>**47**</sup>|Transversal|23 pacientes|54,4 (variação 25;<br>75)|65|NR|NR|NR|Baixo|
|**Stellingwerf et al.**<br>**2001**<sup>**66**</sup>|Transversal|469 pacientes|51 (17,7)|49|NR|NR|NR|Baixo|  
41  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Amostra (N)**|**Idade média, anos**<br>**(DP)**|**Sexo masc. (%)**|**HbA1c (%), média**<br>**(DP)**|**Acuidade visual**<br>**(Logmar (DP)**|**Espessura central da**<br>**fóvea (µm (DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Newson et al. 2000**<sup>**51**</sup>|Transversal|37 pacientes|25-70|NR|NR|NR|NR|Moderado (Não é possível ter<br>certeza se os testes padrão e<br>índice foram feitos com<br>mascaramento entre os<br>avaliadores)|
|**Taylor et al. 1999**<sup>**69**</sup>|Transversal|118 pacientes|Variação (<40 a<br>>80)|44|NR|NR|NR|Baixo|
|**Owens et al. 1998**<sup>**53**</sup>|Transversal|605 pacientes|NR|56|NR|NR|NR|Baixo|
|**Siu et al.**<br>**1998**<sup>**64**</sup>|Transversal|153 pacientes|55,9 (variação 23;<br>79)|51|NR|NR|NR|Alto (pacientes que não<br>puderam ser graduados foram<br>considerados como positivos)|
|**Penman et al. 1998**<sup>**54**</sup>|Transversal|456 pacientes (427<br>realizaram os<br>testes)|53,7 (faixa 20; 85)|35|NR|NR|NR|Baixo|
|**Kerr et al.**<br>**1998**<sup>**37**</sup>|Transversal|3586 (215 para o<br>desfecho de<br>interesse)|<40: 290<br>41-64: 1079<br>65-74: 1065<br>>1098<br>desconhecido: 54|55|NR|NR|NR|Moderado (Não é possível ter<br>certeza se os testes padrão e<br>índice foram feitos com<br>mascaramento entre os<br>avaliadores)|
|**Sonnaville et al.**<br>**1996**<sup>**65**</sup>|Transversal|323 pacientes|65,3 (variação 40-<br>96)|41|HbA1c < 7%: 42%<br>HbA1c > 8,5: 23|NR|NR|Moderado (O resultado de<br>acurácia diagnóstica para RD<br>clinicamente significante não<br>considerou as fotos não<br>graduáveis)|
|**Harding,**<br>**1995**<sup>**34**</sup>|Transversal|320 pacientes|60,2|NR|NR|NR|NR|Baixo|
|**Pugh et al.**<br>**1993**<sup>**56**</sup>|Transversal|352 pacientes|59,7% <65 anos|76|NR|NR|NR|Baixo|
|**Schachat et al.**<br>**1993**<sup>**62**</sup>|Transversal|1168 pacientes|59 (11)|42|7,1 (1,5)|NR|NR|Baixo|  
42  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Amostra (N)**|**Idade média, anos**<br>**(DP)**|**Sexo masc. (%)**|**HbA1c (%), média**<br>**(DP)**|**Acuidade visual**<br>**(Logmar (DP)**|**Espessura central da**<br>**fóvea (µm (DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Kinyoun et al.**<br>**1992**<sup>**38**</sup>|Transversal|124 pacientes|62; variação (45-74)|NR|NR|NR|NR|Baixo|
|**Schulper et al.**<br>**1992**<sup>**63**</sup>|Transversal|2359 pacientes|NR|NR|NR|NR|NR|Moderado (Não é possível ter<br>certeza se os testes padrão e<br>índice foram feitos com<br>mascaramento entre os<br>avaliadores)|
|**Kalm et al.**<br>**1989**<sup>**36**</sup>|Transversal|154 pacientes|65 (variação 41-89)|NR|NR|NR|NR|Baixo|
|**Kleinstein et al.**<br>**1987**<sup>**40**</sup>|Transversal|25 olhos|NR|NR|NR|NR|NR|Baixo|
|**Wllians et al. 1986**<sup>**70**</sup>|Transversal|62 pacientes (120<br>olhos)|NR|NR|NR|NR|NR|Baixo|
|**Klein et al.**<br>**1985**<sup>**39**</sup>|Transversal|99 pacientes (63<br>midriático, 74 não<br>midriático)|54 mediana (15; 84)|55|NR|NR|NR|Baixo|
|**Moss et al.**<br>**1985**<sup>**48**</sup>|Transversal|1949 pacientes|NR|NR|NR|NR|NR|Baixo|  
DP: desvio padrão; NR: Não relatado; OCT: tomografia de coerência ótica; RTA: retinalthicknessanalyses; HbA1c: hemoglobina glicada; Masc.: masculino.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4) Resultados de acurácia diagnóstica para os estudos que consideraram a biomicroscopia como teste índice** -->
**Tabela 11 –** Resultado de acurácia para estudo comparando biomicroscopia vs. fotografia 45°  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR**<br>**diagnóstico**<br>**(IC95%)**|**Acurácia geral**<br>**(%)**|
|---|---|---|---|---|---|---|---|
|**Kalm et al. 1989**<sup>**36**</sup>|154 pacientes com diabetes<br>mellitus tipo II. Objetivo:<br>comparar o desempenho<br>diagnóstico entre<br>biomicroscopia e fotografia<br>45° não estéreo, midriática|Biomicroscopia|Fotografia 45° não<br>estereo,midriática|RD inicial (backgroung):<br>Olho direito: 69<br>Olho esquerdo: 61<br>Maculopatia:<br>Olho direito: 79<br>Olho esquerdo: 63|NR|NR|NR|  
43

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: RD: retinopatia diabética; NR: Não relatado; OR: OddsRatio ou razão de chances; IC 95%: intervalo de confiança de 95%. -->
**Tabela 12 –** Resultado de acurácia para estudo que compara exame clínico (biomicroscopia + oftalmoscopia) vs. fotografia estereoscópica 7 campos  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR**<br>**diagnóstico**<br>**(IC95%)**|**Acurácia geral**<br>**(%)**|
|---|---|---|---|---|---|---|---|
|**Scanlon et al.**<br>**2003b**<sup>**60**</sup>|239 pacientes com<br>diabetes. Objetivo:<br>comparar a avaliação<br>oftalmológica vs.<br>fotografia estereoscópica<br>(sete campos) e midriática<br>45° (2 campos)|Avaliação oftalmológica<br>(biomicroscopia +<br>oftalmoscopia)|Fotografia<br>estereoscópica 30° (7<br>campos)|87,4 (83,5; 91,5)|94,9 (91,5; 98,3)|NR|NR|  
NR: Não relatado; OR: OddsRatio ou razão de chances; IC 95%: intervalo de confiança de 95%.  
**Tabela 13 –** Resultados de acurácia para estudos que compararam, entre si, fotografias 45° vs. 30° e 45° vs. 50° midriáticas ou não.  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral**<br>**(%)**|
|---|---|---|---|---|---|---|---|
|**Stellingwerf et al.**<br>**2004**<sup>**66**</sup>|282 pacientes (560) olhos com<br>diabetes tipos I e II. Objetivo:<br>Avaliar o efeito da compressão<br>JPEG no diagnóstico de RD|Fotografia digital<br>não -estereoscópica<br>50° (integral) - 2<br>campos<br>Fotografia digital<br>não -estereoscópica<br>50° (JPEG) - 2<br>campos|Fotografia colorida<br>45° (35 mm), 2<br>campos|Média inter avaliadores:<br>JPEG: 0,73<br>Integral: 0,89|Média inter avaliadores:<br>JPEG: 0,96<br>Integral: 0,93|NR|NR|  
44  
|**Klein et al. 1985**<sup>**39**</sup>|99 pacientes, 71 com diabetes.<br>Objetivo: Comparar a<br>oftalmoscopia direta e as<br>fotografias midriática e não<br>idiái  ffi|Fotografia 45° não<br>midriática<br>Fotografia 45°|Fotografia<br>estereoscópica 30° 3<br>campos|Foto não midriática:<br>RD: 1,0 (0,91; 1,0)<br>RDP: 1,0 (0,72; 1,0)<br>Foto midriática:|Foto não midriática:<br>RD: 0,91 (0,62; 0,98)<br>RDP: 1,0 (0,72; 1,0)<br>Foto midriática:|11,33 (3,2; 39,6)<br>para<br>oftalmoscopia<br>l RD|NR|
|---|---|---|---|---|---|---|---|
||mrtca vs. otograa<br>tói 30°|midriática||RD: 0,98 (0,89; 0,99)|RD: 1,0 (0,78; 1,0)|em quaquer||
||esereoscpca|||RDP: 1,0 (0,78; 1,0)|RDP: 1,0 (0,78; 1,0)|||  
RD: retinopatia diabética; RDP: retinopatia diabéticaproliferativa; NR: Não relatado; JPEG: formato de compressão de foto;OR: OddsRatio ou razão de chances; IC 95%: intervalo de confiança de 95%.  
**Tabela 14 –** Resultados de acurácia para estudo que comparou fotografias 20°, 45° e 50° digitais vs. oftalmoscopia + fotografia.  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Saari et al.**<br>**2004**<sup>**59**</sup>|70 pacientes (sendo 42<br>diabéticos e 28 controles<br>saudáveis). Objetivo: Avaliar<br>quatro tipos de câmeras vs.<br>um padrão de referência<br>misto na detecção de RD|1) 50°, 2 campos,<br>digital, colorida<br>2) 50°, 2 campos,<br>digital (red-free)<br>3) portátil 20° digital<br>4) 45° colorida<br>digital|Oftalmoscopia<br>midriática, fotos<br>digitai coloridas e<br>red-free|Pelo menos RDNP leve:<br>50° colorida: 94<br>45° colorida: 88,9<br>portátil 20°: 6,9<br>50° redfree: 97,7|Pelo menos RDNP leve:<br>50° colorida: 99<br>45° colorida: 100<br>portátil 20°: 50<br>50° redfree: 98,9|NR|NR|  
RDNP: Retinopatia diabética não proliferativa; OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%; NR: Não relatado.  
**Tabela 15 –** Resultados de estudos que compararam fotografia de fundo vs. biomicroscopia  
45  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Wilson et al. 2010**<sup>**71**</sup>|380 pacientes com<br>diabetes. Objetivo: avaliar<br>a sensibilidade e a<br>especificidade da<br>oftalmoscopia a laser<br>(widefield) e das imagens<br>digitais de retina 45° na<br>detecção de RD|Oftalmoscopia a laser<br>(widefield) (OWF)<br>fotografia digital<br>(único e 2 campos) 45°|Biomicroscopia<br>(slitlamp)|Foto digital (1 campo): 83,3<br>(75,1; 91,6)<br>Foto digital (2 campos): 83,3<br>(75,1; 91,6)<br>OWF: 84,6 (76,6; 92,6)|Foto digital (1 campo): 85,4<br>(81,5; 89,4) p=0,04 x OWF<br>Foto digital (2 campos):<br>85,1 (81,1; 89,1)<br>OWF: 78,8 (74,2; 83,4)<br>p<0,05 x foto digital|NR|NR|
|**Kuo et al. 2005**<sup>**41**</sup>|100 pacientes diabéticos<br>(200 olhos). Objetivo:<br>comparar a fotografia de<br>fundo 45° não midriática<br>vs. biomicroscopia<br>(slitlamp) na detecção de<br>RD|Fotografia de fundo<br>45° não midriática (um<br>campo entre dico e<br>mácula)|Biomicroscopia|53,8|89|NR|NR|
|**Murgatroyd et al.**<br>**2004**<sup>**49**</sup>|398 pacientes (794 olhos)<br>com diabetes. Objetivos:<br>verificar o desempenho<br>diagnóstico das fotografias<br>45° não dilatada em único<br>campo e dilatada em um e<br>múltiplos campos vs.<br>biomicroscopia|Fotografia 45° não<br>dilatada em único<br>campo<br>fotografia 45° dilatada<br>em um e múltiplos<br>campos|Biomicroscopia<br>(slitlamp)|Fotografia 45° (qualquer RD):<br>Sem dilatação, um campo: 83<br>(78; 88)<br>Com dilatação, um campo: 86<br>(82; 90)<br>Com dilatação, múltiplos<br>campos: 90 (86; 93)|Fotografia 45° (qualquer<br>RD):<br>Sem dilatação, um campo:<br>91 (88; 94)<br>Com dilatação, um campo:<br>91 (89; 94)<br>Com dilatação, múltiplos<br>campos: 90 (88; 93)|NR|NR|
|**Herbert et al. 2003**<sup>**35**</sup>|145 pacientes (288 olhos)<br>diabéticos. Objetivo:<br>Avaliar a efetividade da<br>câmera 45° em único<br>campo na detecção de RD|Fotografia não-<br>midriática 45° (um<br>campo)|Biomicroscopia<br>(slitlamp)|38|95|NR|NR|  
46  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|||||**RD:**|**RD:**|||
||586 pacientes diabéticos.<br>Objetivo: Avaliar a<br>|1) Fotografia colorida<br>midriática 35 mm<br>(manual);<br>||Foto colorida (manual): 89 (86;<br>92)<br>Foto digital 45° (manual): 79<br>(75; 83)<br>Foto digital 45° (automática): 71<br>(66; 75)<br>**EMD:**|Foto colorida (manual): 89<br>(86; 92)<br>Foto digital 45° (manual):<br>79 (75; 83)<br>Foto digital 45°<br>(automática): 71 (66; 75)<br>**EMD:**|||
|**Olson et al. 2003¥**<sup>**52**</sup>|performance da imagem<br>digital, fotografia de fundo<br>e biomicroscopia no<br>diagnóstico e classificação<br>de RD|2) Fotografia digital<br>redfree 50°, 2 campos<br>(manual);<br>3) Fotografia digital<br>redfree 50°, 2 campos<br>(digital);|Biomicroscopia<br>(slitlamp)|Foto colorida (manual): 84 (81;<br>87)<br>Foto digital 45° (manual): 83<br>(80; 86)<br>Foto digital 45° (automática): 85<br>(82; 88)|Foto colorida (manual): 84<br>(81; 87)<br>Foto digital 45° (manual):<br>83 (80; 86)<br>Foto digital 45°<br>(automática): 85 (82; 88)|NR|NR|
|||||**RD referenciável:**|**RD referenciável:**|||
|||||Foto colorida (manual): 89 (86;<br>91)<br>Foto digital 45° (manual): 87<br>(84; 90)|Foto colorida (manual): 89<br>(86; 91)<br>Foto digital 45° (manual):<br>87 (84; 90)|||
|**Scanlon et al. 2003**<sup>**61**</sup>|1549 pacientes com<br>diabetes. Comparar<br>fotografia midriática e não-<br>midriática vs.<br>biomicroscopia na triagem<br>de RD|Fotografia digital não-<br>midriática 45° (um<br>campo)<br>Fotografia digital<br>midriática 45° (dois<br>campos)|Biomicroscopia<br>(slitlamp)|45° não midriática (1 campo): 86<br>(80,9; 90,1)<br>45° midriática (2 campos): 87,8<br>(83; 92,6)|45° não midriática (1<br>campo): 76,7 (74,5; 78,9)<br>45° midriática (2 campos):<br>86,1 (84,2; 87,8)|NR|NR|
|**Scanlon et al. 2003b**<sup>**60**</sup>|239 pacientes com<br>diabetes. Objetivo:<br>comparar a avaliação<br>oftalmológica vs. fotografia<br>estereoscópica (sete<br>campos) e midriática 45° (2<br>campos)|Foto digital midriática<br>45° (2 campos)|Biomicroscopia|Foto 2 x 45° vs. biomicroscopia<br>+ oftalmoscopia: 82,8 (78; 87,6)|Foto 2 x 45° vs.<br>biomicroscopia +<br>oftalmoscopia: 92,9 (89,6;<br>96,2)|NR|NR|  
47  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Rudnisky et al.**<br>**2002**<sup>**58**</sup>|105 pacientes (107 olhos)<br>com diabetes mellitus tipos<br>I e II. Objetivo: Comparar<br>fotografia estereoscópica<br>digital de alta resolução vs.<br>biomicroscopia por lente de<br>contato na detecção de<br>EMD|Fotografia digital 30°<br>midriática|Biomicroscopia por<br>lente de contato|EMCS geral: 90,6<br>EMCS 1 (ETDRS): 81,8<br>EMCS 2 (ETDRS): 50<br>EMCS 3 (ETDRS): 60<br>EMD: 82|EMCS geral: 92,4<br>EMCS 1 (ETDRS): 94,1<br>EMCS 2 (ETDRS): 99,0<br>EMCS 3 (ETDRS): 95,1<br>EMD: 90|NR|NR|
|**Harding et al. 1995**<sup>**34**</sup>|320 pacientes diabéticos.<br>Objetivo: comparar<br>oftalmoscopia direta e<br>fotografia 45º (35 mm),<br>com biomicroscopia no<br>diagnóstico doenças<br>oculares relacionadas ao<br>diabetes|Fotografia 45º (35 mm)|Biomicroscopia<br>(estereoscópica<br>siltlamp)|Fotografia vs. biomicroscopia:<br>RD (com risco de perda de<br>visão): 47 (21; 93)<br>Maculopatia (com risco de perda<br>de visão): 61 (44; 78)<br>Qualquer doença com risco de<br>perda de visão: 89 (80; 98)|Fotografia vs.<br>biomicroscopia:<br>RD (com risco de perda de<br>visão): 100<br>Maculopatia (com risco de<br>perda de visão): 99 (98;<br>100)<br>Qualquer doença com risco<br>de perda de visão: 86 (82;<br>90)|NR|NR|
|||||Biomicroscopia como padrão:||||
|**Kalm et al. 1989**<sup>**36**</sup>|154 pacientes com diabetes<br>mellitus tipo II. Objetivo:<br>comparar o desempenho<br>diagnóstico entre<br>biomicroscopia e fotografia<br>45° não estereo, midriática|Fotografia 45° não<br>estereo, midriática|Biomicroscopia|RD inicial (backgroung):<br>Olho direito: 87<br>Olho esquerdo: 97<br>Maculopatia:<br>Olho direito: 81<br>Olho esquerdo: 80|NR|NR|NR|  
¥Resultados que compararam a biomicroscopia quando realizada por optometrista e quando realizada por oftalmologistas foram excluídos; NR: Não relatado; EMD: Edema macular diabético; EMCS: Edema macular clinicamente significante; RD retinopatia diabética; OWF: oftalmoscopia a laser widefield;IC 95%: intervalo de confiança de 95%;OR: Oddsratio ou razão de chances.  
**Tabela 16 –** Resultados de estudos que compararam fotografia de fundo vs. fotografia estereoscópica (7 campos)  
48  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico (IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Kerr et al.**<br>**1998**<sup>**37**</sup>|3586 pacientes com<br>diabetes. Avaliar a<br>capacidade de diagnóstico<br>de RD pela fotografia<br>digital 50°, 3 campos|Fotografia digital 50°, 3<br>campos|Fotografia 35<br>mm<br>(oftalmologista) e<br>biomicroscopia|Imagem digital xfotos 35 mm:<br>0,93<br>Imagem digital x<br>biomicroscopia: 0,90|Imagem digital xfotos 35 mm:<br>0,97<br>Imagem digital x<br>biomicroscopia: 0,70|NR|NR|
|**Phiri et al.**<br>**2006**<sup>**55**</sup>|196 pacientes (392 olhos)<br>com diabetes. Objetivo:<br>Avaliar o desempenho<br>diagnóstico das fotografias<br>45° digital e polaroid|Fotografia 45° não<br>midriática polaroid<br>Fotografia 45° não<br>midriática digital|Fotografia<br>estereoscópica<br>30° (7 campos)|Fotografia digital: 86,2 (65,8;<br>95,3)<br>Fotografia polaroid: 84,1 (65,5;<br>93,7)|Fotografia digital: 71,2 (58,8;<br>81,1)<br>Fotografia polaroid: 71,2 (58,8;<br>81,1)|1,06 (0,8; 1,4) p=0,68 (sem<br>diferença entre as<br>fotografias)|NR|
|**Lawrence,**<br>**2004**<sup>**42**</sup>|254 pacientes (508 olhos)<br>com diabetes. Objetivo:<br>avaliar os resultados de<br>acurácia entre fotografias<br>digitais de alta e baixa<br>resolução, dilatada ou não,<br>tendo como referência<br>fotografia estereoscópica<br>ou oftalmoscopia|Fotografia digital não-<br>estereoscópica 45° (640-<br>480) (dilatada ou não)<br>Fotografia digital não-<br>estereoscópica 45° (800-<br>600) (dilatada -3 campos<br>ou não -1 campo)|Fotografia<br>estereoscópica<br>30°|Padrão - fotografia<br>estereoscópica 30°:<br>(640 x 480) não dilatada: 0,66<br>(640 x 480) dilatada: 0,66<br>(800 x 600) não dilatada: 0,76<br>(800 x 600) dilatada: 0,85<br>(p=0,04 vs. não dilatada)|Padrão - fotografia<br>estereoscópica 30°:<br>(640 x 480) não dilatada: 0,66<br>(640 x 480) dilatada: 0,86<br>(p<0,01 vs. não dilatada)<br>(800 x 600) não dilatada: 0,45<br>(800 x 600) dilatada: 0,81<br>(p<0,01 vs. não dilatada)|NR|NR|
|**Boucher et al.**<br>**2003***<sup>**28**</sup>|98 pacientes com diabetes<br>tipos I e II. Objetivo:<br>Avaliar a capacidade de<br>diagnóstico da fotografia<br>não-midriática 45°|Fotografia não-midriática<br>45°|Fotografia<br>estereoscópica<br>30° (7 campos)|Grau de RD (ETDRS):<br>Qualquer RD (≥20): 86,4<br>≥leve (≥35): 94,0<br>≥moderada (≥43): 48,1<br>≥grave (≥53): 14,3|Grau de RD (ETDRS):<br>Qualquer RD (≥20): 95,4<br>≥leve (≥35): 94,1<br>≥moderada (≥43): 97,9<br>≥grave (≥53): 100|NR|NR|  
49  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico (IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Gresset et al.**<br>**2003**<sup>**33**</sup>|Pacientes com diabetes.<br>Objetivo:  avaliar a<br>influência no número de<br>campos na acurácia<br>diagnóstica da fotografia<br>não midriática 45°|Fotografia não-midriática<br>45°|Fotografia<br>estereoscópica<br>30° (7 campos)|Qualquer grau de RD: **<br>foto 45° (2 campos): 95,7<br>foto 45° (3 campos): 97,6<br>foto 45° (4 campos): 97,6|Qualquer grau de RD: **<br>foto 45° (2 campos): 78,1<br>foto 45° (3 campos): 71,9<br>foto 45° (4 campos): 65,6|NR|NR|
|**Massin et al.**<br>**2003**<sup>**46**</sup>|74 pacientes (147 olhos)<br>com diabetes tipos I e II.<br>Objetivos: avaliar a<br>detecção de RD pela<br>câmera digital não<br>midriática vs. a fotografia<br>estereoscópica (7 campos)<br>ETDRS|Fotografia digital 45°<br>não-midriática (5<br>campos)|Fotografia<br>estereoscópica (7<br>campos) ETDRS|RD:<br>Avaliador 1: 92 (86; 98)<br>Avaliador 2: 100<br>Avaliador 3: 92 (86; 98)|RD:<br>Avaliador 1: 88 (81; 95)<br>Avaliador 2: 85 (77; 93)<br>Avaliador 3: 87 (79; 95)|NR|NR|
|**Scanlon et al.**<br>**2003b**<sup>**60**</sup>|239 pacientes com<br>diabetes. Objetivo:<br>comparar a avaliação<br>oftalmológica vs.<br>fotografia estereoscópica<br>(sete campos) e midriática<br>45° (2 campos)|Foto digital midriática<br>45° (2 campos)|Fotografia<br>estereoscópica<br>30° (7 campos)|Foto 2 x 45° vs. Foto<br>estereoscópica 7 campos: 80,2<br>(75,2; 85,2)<br>Foto 2 x 45° vs. biomicroscopia<br>+ oftalmoscopia: 82,8 (78;<br>87,6)|Foto 2 x 45° vs. Foto<br>estereoscópica 7 campos: 96,2<br>(93,2; 99,2)<br>Foto 2 x 45° vs. biomicroscopia<br>+ oftalmoscopia: 92,9 (89,6;<br>96,2)|NR|NR|
|**Lin et al.**<br>**2002**<sup>**43**</sup>|197 pacientes com diabetes<br>mellitus tipos I e II.<br>Objetivo: Avaliar a<br>fotografia não midriática,<br>digital, monocromática,<br>único campo (widefield)<br>como ferramenta de<br>triagem da RD.|Fotografia não midriática,<br>digital, monocromática,<br>único campo (widefield)|Fotografia<br>estereoscópica<br>30° (7 campos)|Digital 45° vs. fotografia 30°<br>(ETDRS): 78|Digital 45° vs. fotografia 30°<br>(ETDRS): 86|NR|NR|  
50  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico (IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|||||**Grau de RD:**|**Grau de RD:**|||
|||||RDNP leve: 0,59<br>RDNP moderada: 0,59<br>RDNP grave: 0,46<br>RD muito grave: 0,40<br>RDP baixo risco: 0,89<br>RDP alto risco: 0,75<br>RDNP leve ou moderada: 0,86|RDNP leve: 0,80<br>RDNP moderada: 0,89<br>RDNP grave: 0,97<br>RD muito grave: 0,99<br>RDP baixo risco: 0,97<br>RDP alto risco: 1,00<br>RDNP leve ou moderada: 0,76|||
|**Bursell et al.**<br>**2001**<sup>**29**</sup>|54 pacientes (108 olhos)<br>com diabetes tipos I e 2.<br>Objetivo:  avaliar a<br>capacidade de identificação|Fotografia 45° não<br>idiáti 3|Fotografia<br>estereoscópica|RDNP grave ou muito grave:<br>0,57<br>qualquer RDP: 0,89<br>EMD: 0,62|RDNP grave ou muito grave:<br>0,99<br>qualquer RDP: 0,97<br>EMD: 0,95|NR|NR|
||e graduação da fotografia|mrca ( campos)|30° (7 campos)|EMCS: 0,27|EMCS: 0,98|||
||não-midriática 45° em três|||||||
||campos|||**Tipo de lesão:**|**Tipo de lesão:**|||
|||||HMA: 0,86|HMA: 0,73|||
|||||IRMA: 0,67|IRMA: 0,90|||
|||||VB: 0,65|VB: 0,87|||
|||||HE: 0,78|HE: 0,91|||
|||||NVE: 0,53|NVE: 0,99|||
|||||NVD: 0,56|NVD: 0,99|||
|||||FTSZ: 0,62|FTSZ: 0,95|||
|||||CSME: 0,27|CSME: 0,98|||
||23 pacientes (44 olhos)<br>|||||||
||com retinopatia diabética|||||||
||moderada a grave, diabetes|||||||
|**Moller et al.**<br>**2001**<sup>**47**</sup>|tipos I e II. Objetivo:<br>verificar a capacidade de<br>detecção de<br>neovascularização pela|Fotografia de fundo em<br>60° focada no centro da<br>fóvea.|Fotografia<br>estereoscópica<br>30° (7 campos)|88,9|NR|NR|NR|
||fotografai de fundo em 60°<br>(um campo)|||||||  
51  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico (IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Newson et al.**<br>**2000**<sup>**51**</sup>|37 pacientes diabéticos.<br>Objetivo: verificar a<br>capacidade de diagnóstico<br>de retinopatia diabética<br>pela fotografia de fundo<br>45° e a<br>angiofluoresceinografia|Fotografia de fundo 45°<br>Angiofluoresceinografia|Fotografia<br>estereoscópica<br>30° (7 campos)|RD:<br>foto 45°: 0,87<br>angiofluor.: 0,87<br>Maculopatia:<br>foto 45°: 0,48<br>angiofluor.: 0,87|RD:<br>foto 45°: 0,83<br>angiofluor.: 0,80<br>Maculopatia:<br>foto 45°: 0,95<br>angiofluor.: 0,87|NR|NR|
|||||RD referenciável:|RD referenciável:|||
|**Taylor et al.**<br>**1999**<sup>**69**</sup>|118 pacientes diabéticos.<br>Objetivo: Avaliar o<br>desempenho diagnóstico<br>da fotografia não<br>midriática 45° (polaroid e<br>digital) vs. fotografia<br>estereoscópica 7 campos.|Fotografia de fundo não-<br>midriática 45°<br>(TopconImagenet/Canon<br>Rislite) - digital<br>fotografia de fundo não-<br>midriática 45° (Canon) -<br>polaroid<br>Oftalmoscopia|Fotografia<br>estereoscópica<br>30° (7 campos)|Polaroid: 0,90 (0,86; 0,94)<br>Digital:0,85 (0,80; 0,90)<br>Polaroid + oftalmoscopia: 0,95<br>(0,91; 0,99)<br>Qualquer RD:<br>Polaroid: 0,72 (0,66; 0,78)<br>Digital: 0,74 (0,68; 0,80)<br>Polaroid + oftalmoscopia: 0,92<br>(0,86; 0,98)|Polaroid: 0,97 (0,95; 0,99)<br>Digital: 0,98 (0,96; 1,00)<br>Polaroid + oftalmoscopia: 0,97<br>(0,95; 0,99)<br>Qualquer RD:<br>Polaroid: 0,88 (0,85; 0,91)<br>Digital: 0,96 (0,94; 0,98)<br>Polaroid + oftalmoscopia: 0,89<br>(0,87; 0,91)|NR|NR|
|**Pugh et al.**<br>**1993**<sup>**56**</sup>|352 pacientes diabéticos.<br>Objetivo: avaliar o<br>desempenho diagnóstico<br>oftalmoscopia direta e<br>indireta feita pelo<br>oftalmologista,<br>oftalmoscopia direta por<br>médico assistente,<br>fotografia 45° sem<br>dilatação e com dilatação<br>vs. fotografia<br>estereoscópica 30° (7<br>fields)|Fotografia 45° sem<br>dilatação<br>Fotografia 45° com<br>dilatação<br>Oftalmoscopia direta e<br>indireta feita pelo<br>oftalmologista,<br>Oftalmoscopia direta por<br>médico assistente,|Fotografia de<br>fundo<br>esteroscópica 30°<br>(7 field)|Oftalmoscopia:<br>Oftalmo: 0,33<br>Assistente: 0,14<br>Fotografia 45°:<br>Não-midriática: 0,61<br>Midriática: 0,81<br>p<0,0001 (oftalmo vs.<br>midriática)<br>p<0,002 (não midriática vs.<br>midriática)<br>p<0,02 (oftalmo vs. assistente)|Oftalmoscopia:<br>Oftalmo: 0,99<br>Assistente: 0,99<br>Fotografia 45°:<br>Não-midriática: 0,85<br>Midriática: 0,96<br>p=0,011 (oftalmo vs.<br>midriático)<br>p=0,0001 (midriática vs. Não<br>midriática)|NR|NR|  
*Os resultados aqui descritos contemplam apenas os critérios ETDRS, resultados avaliados de acordo com Welshcommunitydiabeticretinopathystudy (WCDRS), não foram considerados;**O estudo descreve os respectivos valores de sensibilidade e especificidade de acordo com níveis de retinopatia diabética, porém não descreve qual o tipo de fotografia 45° usado e por isso não foi descrito; OR: oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%; NR: Não relatado; RD: retinopatia diabética; RDNP: Retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; HMA: hemorragia/microaneurismas; IRMA: Anormalidade microvascular intra-retina; VB: beading venoso; HE: exsudato pesado; NVD: novos vasos no disco; NVE: novos vasos em demais locais; CSME: edema macular clinicamente significante; FTSZ: espessura do campo visual.  
52  
**Tabela 17 –** Resultados de acurácia para estudos que compararam fotografia de fundo vs. exame clínico (biomicroscopia/oftalmoscopia)  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR**<br>**diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Lopez-Bastida et**<br>**al. 2007**<sup>**44**</sup>|773 pacientes (1546 olhos) com<br>diabetes tipos I e II.|Fotografias 45° e<br>30° não midriáticas,<br>digitais|Biomicroscopia e oftalmoscopia<br>indireta dilatada|Qualquer RD: 92 (90; 94)<br>RD ameaça a visão: 100|Qualquer RD: 96 (95;<br>98)<br>RD ameaça a visão: 100|NR|NR|
|**Tanterdthan et**<br>**al. 2007**<sup>**68**</sup>|142 pacientes diabéticos (225<br>olhos). Objetivo: avaliar a<br>capacidade de diagnóstico de RD<br>por fotografia não midriática 45°<br>único campo.|Fotografias 45° não<br>midriáticas, digitais|Biomicroscopia e oftalmoscopia<br>indireta dilatada|RD: 68,57 (57; 78,20)|RD: 92,25 (87; 95,50)|NR|84,89|
|**Ahmed et al.**<br>**2006**<sup>**25**</sup>|243 (482 olhos) pacientes com<br>diabetes tipos I e II. Objetivo:<br>comparar fotografia de fundo 45°<br>não midriática (3 campos) vs.<br>biomicroscopia/oftalmoscopia|Fotografia de fundo<br>45° não midriática<br>(3 campos)|Biomicroscopia/oftalmoscopia|RD: 98|RD: 100|NR|NR|
|**Chia et al. 2004**<sup>**30**</sup>|39 pacientes diabéticos (78 olhos).<br>Objetivo: Comparar a informação<br>obtida de fotografia não midriática<br>45° polaroid vs. exame clínico|Fotografia não<br>midriática 45°<br>polaroid|Oftalmoscopia e biomicroscopia<br>dilatada|RD: 0,95<br>Préprolif: 1,0<br>RDP: 0,0<br>Edema: 1,0|RD: 0,98<br>Préprolif: 1,0<br>RDP: 1,0<br>Edema: 1,0|NR|NR|
|**Marbeley et al.**<br>**2002**<sup>**45**</sup>|100 pacientes diabéticos (200<br>olhos). Objetivo: comparar a<br>fotografia de fundo 45° não<br>midriática vs. biomicroscopia<br>(slitlamp) /oftalmoscopia indireta na<br>detecção de RD|Fotografia de fundo<br>45° não midriática<br>(um campo<br>centrado na<br>mácula)|Biomicroscopia (slitlamp)<br>/oftalmoscopia indireta|Qualquer RD: 84,4 (78,8;<br>90)<br>RDNP: 91,2 (85,9; 96,5)<br>EMCS: 90 (76,9; 100)<br>RDP: 100 (74; 100)<br>RDP ou EMCS: 93,3<br>(84,4; 100)|Qualquer RD: 79,2<br>(74,1; 84,3)<br>RDNP: 82,2 (77,7;<br>86,7)<br>EMCS: 97,1 (95,4;<br>98,8)<br>RDP: 99,7 (99,2; 100)<br>RDP ou EMCS: 96,8<br>(95; 98,6)|NR|NR|  
53  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR**<br>**diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|||||Retinopatia com ameaça à<br>visão:|Retinopatia com<br>ameaça à visão:|||
|**Stellingwerf et**<br>**al. 2001**<sup>**67**</sup>|469 pacientes com diabetes mellitus<br>tipos I e II. Objetivo: Comparar a<br>fotografai 45° dois campos vs.<br>exame oftalmológico para detecção<br>e classificação de RD|Fotografia<br>estereoscópica 45°,<br>2 campos, com<br>dilatação|Biomicroscopia/ oftalmoscopia<br>indireta com dilatação|Diabetes tipo I: 92,3<br>Diabetes tipo 2: 100<br>Geral: 95,2<br>Qualquer RD:|Diabetes tipo I: 98,6<br>Diabetes tipo 2: 99,3<br>Geral: 99,1<br>Qualquer RD:|NR|NR|
|||||Diabetes tipo I: 83,6<br>Diabetes tipo 2: 81,1<br>Geral: 82,5|Diabetes tipo I: 76,3<br>Diabetes tipo 2: 92,1<br>Geral: 87,7|||
|**Siu et al. 1998**<sup>**64**</sup>|153 pacientes diabéticos. Objetivo:<br>Avaliar a sensibilidade e<br>especificidade da fotografia não<br>midriática e da oftalmoscopia direta<br>para detecção de RD.|Fotografia não<br>midriática 45°|Oftalmoscopia indireta e<br>biomicroscopia|Foto 45°: 64 (43-85)|Foto 45°: 90 (84-96)|NR|NR|  
NR: Não relatado; Pré prof.: préproliferativa; RD: Retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa;IC 95%: intervalo de confiança de 95%; EMCS: edema macular clinicamente significante.  
**Tabela 18 –** Resultados de acurácia para estudos que compararam fotografia de fundo vs. oftalmoscopia  
54  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Aptel et al. 2008**<sup>**27**</sup>|79 pacientes (158 olhos)<br>com diabetes tipos I, II,<br>tardia e gestacional.<br>Objetivo: verificar a<br>capacidade de detecção<br>de RD entre<br>oftalmoscopia indireta<br>midriática e fotografias<br>de fundo 45° midriática<br>e não midriática (1 ou 3<br>campos)|Fotografia de fundo<br>45° midriática, 1<br>campo<br>Fotografia de fundo<br>45° midriática, 3<br>campos<br>Fotografia de fundo<br>45° não midriática,1<br>campo<br>Fotografia de fundo<br>45° não midriática, 3<br>campos|Oftalmoscopia indireta<br>dilatada|1 campo sem midríase: 76,92<br>3 campos sem midríase: 92,31<br>1 campo midriática: 89,74<br>3 campos midriática: 97,44|1 campo sem midríase: 99,16<br>3 campos sem midríase:<br>97,48<br>1 campo midriática: 98,32<br>3 campos midriática: 98,32|NR|NR|
|**Chun et al. 2007**<sup>**31**</sup>|120 pacientes (231<br>olhos) com diabetes.<br>Objetivo: comparar a<br>capacidade de<br>diagnóstico da câmera<br>não midriática 45° vs.<br>oftalmoscopia indireta<br>dilatada|Fotografia 45° não<br>midriática único<br>campo|Oftalmoscopia indireta<br>dilatada|RD: 0,60<br>Edema cistóide: 0,60|RD: 1,00<br>Edema cistóide: 0,99|NR|NR|
|**Ruamviboonsuk et**<br>**al. 2005**<sup>**57**</sup>|150 pacientes diabéticos.<br>Objetivo: avaliar o<br>desempenho da<br>fotografia de fundo não<br>midriática 45° no<br>diagnóstico de RD e<br>EMCS|Fotografia de fundo<br>45° não midriática<br>(nervo ótico e área<br>macular)|Oftalmoscopia indireta<br>dilatada|RD: 80<br>EMCS: 43|RD: 96<br>EMCS: 100|NR|NR|  
55  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|||||(640 x 480) não dilatada: 0,79||||
|**Lawrence, 2004**<sup>**42**</sup>|254 pacientes (508<br>olhos) com diabetes.<br>Objetivo: avaliar os<br>resultados de acurácia<br>entre fotografias digitais<br>de alta e baixa<br>resolução, dilatada ou<br>não, tendo como<br>referência fotografia<br>estereoscópica ou<br>oftalmoscopia|Fotografia digital não-<br>estereoscópica 45°<br>(640-480) (dilatada ou<br>não)<br>Fotografia digital não-<br>estereoscópica 45°<br>(800-600) (dilatada -3<br>campos ou não -1<br>campo)|Oftalmoscopia direta<br>dilatada|(640 x 480) dilatada: 0,80<br>(800 x 600) não dilatada: 0,81<br>(800 x 600) dilatada: 0,87<br>No grupo com olhos dilatados a<br>sensibilidade da (800 x 600) foi<br>melhor que (640 x 480),<br>p<0,01. Sem diferença<br>significante para a<br>especificidade.|(640 x 480) não dilatada: 0,68<br>(640 x 480) dilatada: 0,85<br>(p=0,001 vs. não dilatada)<br>(800 x 600) não dilatada: 0,45<br>(800 x 600) dilatada: 0,69<br>(p=0,001 vs. não dilatada)|NR|NR|
|**Lin et al. 2002**<sup>**43**</sup>|197 pacientes com<br>diabetes mellitus tipos I<br>e II. Objetivo: Avaliar a<br>fotografia não<br>midriática, digital,<br>monocromática, único<br>campo (widefield) como<br>ferramenta de triagem da<br>RD.|Fotografia não<br>midriática, digital,<br>monocromática, único<br>campo (widefield)|Oftalmoscopia|Digital 45° vs. oftalmoscopia:<br>100|Digital 45° vs. oftalmoscopia:<br>71|NR|NR|
|**Penman et al. 1998**<sup>**54**</sup>|427 pacientes com<br>diabetes. Objetivo:<br>Comparar o desempenho<br>diagnóstico da fotografia<br>não midriática vs.<br>oftalmoscopia indireta<br>dilatada|Fotografia 45° não<br>midriática|Oftalmoscopia indireta<br>dilatada|RD: 65 (56; 80)<br>RD com ameaça a visão: 60<br>(15; 95)|RD: 83 (79; 88)<br>RD com ameaça a visão: 95<br>(93; 98)|NR|NR|  
56  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Sonnaville et al.**<br>**1996**<sup>**65**</sup>|323 pacientes (646<br>olhos) com diabetes tipo<br>2. Objetivo: comparar o<br>desempenho diagnóstico<br>da fotografia não<br>midriática 60° vs.<br>oftalmoscopia|Fotografia não<br>midriática 60° (2<br>campos)|Oftalmoscopia (direta e<br>indireta) com dilatação|RD clinicamente significante:<br>89<br>RD qualquer (considerando as<br>fotos não graduáveis): 97<br>RD qualquer (não considerando<br>as fotos não graduáveis): 97|RD clinicamente significante:<br>94<br>RD qualquer (considerando<br>as fotos não graduáveis): 91<br>RD qualquer (não<br>considerando as fotos não<br>graduáveis): 97|NR|NR|
|**Schulper et al. 1992**<sup>**63**</sup>|2359 pacientes<br>diabéticos. Objetivo:<br>Avaliar, como medida<br>de efetividade, a<br>sensibilidade e<br>especificidade da<br>fotografia 45 não<br>midriática vs.<br>oftalmoscopia|Fotografia 45° não<br>midriática|Oftalmoscopia indireta<br>dilatada|RD com ameaça a visão:<br>Hospital (centro de leitura): 0,4<br>Generalista: 0,58|RD com ameaça a visão:<br>Hospital (centro de leitura):<br>0,96<br>Generalista: 0,97|NR|NR|
|**Willians et al. 1986**<sup>**70**</sup>|62 pacientes (120 olhos)<br>com diabetes. Objetivo:<br>Comparar o desempenho<br>diagnóstico da fotografia<br>não midriática vs.<br>oftalmoscopia direta<br>dilatada|Fotografia 45° não<br>midriática|Oftalmoscopia direta<br>dilatada|RD: 96<br>Maculopatia: 100<br>Neovascularização: 82|RD: 98<br>Maculopatia: 96<br>Neovascularização: 100|NR|NR|  
RD; Retinopatia diabética; NR: Não relatado; EMCS: Edema Macular Clinicamente Significante; OR: OddsRatio ou razão de chances; IC 95%: intervalo de confiança de 95%.  
**Tabela 19 –** Resultados de acurácia para estudo que comparou fotografia de fundo vs. tomografia de coerência ótica (TCO)  
|**Autor, ano**<br>**População e**<br>**objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico (IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|  
57  
|**Ibanez et al.**<br>**2013**<sup>**168**</sup>|325 pacientes (650<br>olhos) com<br>diabetes. Objetivo:<br>Determinas a<br>validade da<br>fotografia retinal<br>lid d|**Fotografias retina:**<br>colorida 45°<br>colorida 45° (2<br>campos)<br>Verde 45°<br>Verde 45° (2<br>campos)|OCT|Colorida 45°: 72,6<br>2 colorida 45°: 80,2<br>Verde 45°: 79,2<br>2 Verde 45°: 89,6<br>Colorida 30°: 77,1<br>2 colorida 30°: 87,6<br>Verde 30°: 89,5<br>2 Verde 30°: 94,3<br>Efeito da adição da AV:|Colorida 45°: 93,5<br>2 colorida 45°: 95,2<br>Verde 45°: 92,1<br>2 Verde 45°: 91,9<br>Colorida 30°: 93,3|NR|NR|
|---|---|---|---|---|---|---|---|
||(coora, vere,<br>_flat_e<br>estereoscópica) no<br>diagnóstico de<br>EMD|colorida 30°<br>colorida 30° (2<br>campos)<br>Verde 30°<br>Verde 30° (2<br>campos)||Colorida 30° + AV: 87<br>Colorida 45° + AV: 82<br>2 colorida 30° + AV: 93<br>2 colorida 45° + AV: 89<br>Verde 30° + AV: 95<br>Verde 45° + AV: 88<br>2 verde 30° + AV: 96|2 colorida 30°: 94,9<br>Verde 30°: 91,7<br>2 Verde 30°: 91,5|||
|||||2 verde 45° + AV: 93||||  
AV: Acuidade Visual; NR: não relatado; OCT: Tomografia de coerência Ótica; EMD: Edema macular diabético;OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **5) Resultados de acurácia diagnóstica para estudos que consideraram como teste índicetomografia de coerência ótica, autofluorescência e analisador da espessura da retina (RTA)** -->
**Tabela 20 –** Resultados de acurácia para estudos que avaliaram, como teste índice, tomografia de coerência ótica, autofluorescência e analisador da espessura da retina (RTA).  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Waldstein et al.**<br>**2012**<sup>**170**</sup>|71 pacientes (125 olhos)<br>com retinopatia diabética.<br>Objetivo: avaliar a<br>aplicação de<br>autofluorescência de fundo<br>em 488 e 514 nm e imagem<br>de densidade ótica de<br>pigmento macular para<br>detecção de edema macular|Autofluorescência de<br>fundo em 488 e 514 nm<br>(FAF)<br>Imagem de densidade<br>ótica de pigmento<br>macular (IDOPM)|OCT|488 nm FAF: 80,6<br>514 nm FAF: 55,2<br>IDOPM: 80,6|488 nm FAF: 89,7<br>514 nm FAF: 94,8<br>IDOPM: 91,4|NR|NR|  
58  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|||||EMCS:|EMCS:|||
|**Goebel et al.**<br>**2006**<sup>**171**</sup>|69 pacientes (124 olhos)<br>com diabetes. 13 controles<br>foram usados como padrão<br>para estabelecer o_cutoff_de<br>espessura da mácula<br>normal (acima disso era<br>considerado EMD).<br>Objetivo: comparar a<br>detecção de edema macular<br>entre OCT e RTA<br>(_RetinalTicknessAnalyzer_).|OCT<br>Analisador de espessura<br>de retina<br>(_retinalticknessanalyzer)_|Fotografia<br>estereoscópica de<br>fundo 30° centrada<br>na mácula|OCT:<br>Qualquer setor: 98,4<br>Fóvea: 91,9<br>RTA:<br>Qualquer setor: 78,3<br>Fóvea: 69,6<br>Qualquer edema:<br>OCT:<br>Qualquer setor: 97,1<br>Fóvea: 87|OCT:<br>Qualquer setor: 54,5<br>Fóvea: 72,7<br>RTA:<br>Qualquer setor: 70,6<br>Fóvea: 79,4<br>Qualquer edema:<br>OCT:<br>Qualquer setor: 62,2<br>Fóvea: 75,7|NR|NR|
|||||RTA:<br>Qualquer setor: 75<br>Fóvea: 67,3|RTA:<br>Qualquer setor: 75<br>Fóvea: 85,7|||
|**Neubauer et al.**<br>**2003**<sup>**172**</sup>|18 pacientes com diabetes<br>(36 olhos, 31 incluídos).<br>Objetivo: Avaliar a<br>acurácia diagnóstica do<br>RTA (wide-angle) para RD<br>e edema macular|Analisador de espessura<br>da retina (RTA) wide-<br>angle (80° x 60°)|Exame clínico<br>(oftalmoscopia,<br>biomicroscopia e<br>AF)|Média inter avaliadores:<br>RD:  93<br>EMD: 100|Média inter avaliadores:<br>PDR: 85,7<br>EMD: 63|NR|NR|  
FAF: Auto-fluorescência; IDOPM: Imagem de densidade ótica do pigmento macular; OCT: Tomografia de Coerência Ótica; EMCS: Edema macular clinicamente significante; RTA: analizador de espessura da retina ( _RetinalThicknessAnalizer_ ); RD: retinopatia diabética; EMD: Edema macular diabético; OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%.  
59

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **6) Resultados de acurácia diagnóstica para estudos que consideraram como teste índice a oftalmoscopia** -->
**Tabela 21 –** Resultados de acurácia para estudo que comparou Oftalmoscopia vs. Tomografia de coerência ótica, angiofluoresceinografia e autofluorescência.  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Vujosevic et al.**<br>**2012**<sup>**169**</sup>|137 pacientes (263<br>olhos) com diabetes<br>tipos I e II. Objetivo:<br>Avaliar a performance<br>da oftalmoscopia a<br>laser (retromode) na<br>detecção de EMD|Oftalmoscopia a laser<br>(retromode) (OLR)|OCT<br>AF<br>Autofluorescência de<br>fundo|OLR x OCT: 97<br>OLR x AF: 97,4<br>OLR x autofluor: 96,1|OLR x OCT: 71,9<br>OLR x AF: 68,1<br>OLR x autofluor: 73,3|NR|NR|  
EMD: edema macular diabético; OLR: Oftalmoscopia a laser (retromode); OCT: Tomografia de coerência ótica; AF: angiofluoresceinografia; Autofluor: auto-fluorescência; OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%; NR: Não relatado.  
**Tabela 22 –** Resultados de Acurácia para estudos comparando oftalmoscopia vs. biomicroscopia  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
||380 pacientes com<br>diabetes. Objetivo:<br>avaliar a sensibilidade e a|Oftalmoscopia a laser<br>(widefield) (OWF)||Foto digital (1 campo): 83,3 (75,1;<br>91,6)|Foto digital (1 campo): 85,4<br>(81,5; 89,4) p=0,04 x OWF|||
|**Wilson et al.**<br>**2010**<sup>**71**</sup>|especificidade da<br>oftalmoscopia a laser<br>(widefield) e das imagens<br>digitais de retina 45° na<br>detecção de RD|fotografia digital<br>(único e 2 campos)<br>45°|Biomicroscopia (slitlamp)|Foto digital (2 campos): 83,3<br>(75,1; 91,6)<br>OWF: 84,6 (76,6; 92,6)|Foto digital (2 campos): 85,1<br>(81,1; 89,1)<br>OWF: 78,8 (74,2; 83,4)<br>p<0,05 x foto digital|NR|NR|  
60  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Neubauer et al.**<br>**2008**<sup>**50**</sup>|51 pacientes (51 olhos)<br>diabéticos. Objetivo:<br>avaliar o desempenho<br>diagnóstico da<br>oftalmoscopia a laser<br>(ultra-widefield) 200° x<br>biomicroscopia|Oftalmoscopia a laser<br>ultra-widefield 200°,<br>não midriática<br>(OUWF)|Biomicroscopia|RD<br>RD> leve: 94<br>RD≤ leve: 94<br>qualquer RD: 94<br>EMCS:  93|RD<br>RD> leve: 100<br>RD≤ leve: 100<br>qualquer RD: 100<br>EMCS: 89|NR|NR|
|**Siu et al. 1998**<sup>**64**</sup>|153 pacientes diabéticos.<br>Objetivo: Avaliar a<br>sensibilidade e<br>especificidade da<br>fotografia não midriática<br>e da oftalmoscopia direta<br>para detecção de RD.|Oftalmoscopia direta<br>com dilatação|Oftalmoscopia indireta e<br>biomicroscopia|Oftalmoscopia direta: 41 (20-62)|Oftalmoscopia direta: 93 (88-<br>97)|NR|NR|
|**Harding et al.**<br>**1995**<sup>**34**</sup>|320 pacientes diabéticos.<br>Objetivo: comparar<br>oftalmoscopia direta e<br>fotografia 45º (35 mm),<br>com biomicroscopia no<br>diagnóstico doenças<br>oculares relacionadas ao<br>diabetes|Oftalmoscopia direta|Biomicroscopia<br>(esteoscopicsiltlamp)|Oftalmoscopia vs. biomicroscopia:<br>RD (com risco de perda de<br>visão):40 (15; 45)<br>Maculopatia (com risco de perda<br>de visão): 64 (47; 81)<br>Qualquer doença com risco de<br>perda de visão: 65 (51; 79)|Oftalmoscopia vs.<br>biomicroscopia:<br>RD (com risco de perda de<br>visão): 99 (98; 100)<br>Maculopatia (com risco de<br>perda de visão): 100<br>Qualquer doença com risco de<br>perda de visão: 97 (95; 99)|NR|NR|  
RD: retinopatia diabética; EMCS: Edema macular clinicamente significante; OWF: oftalmoscopia widefield; OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%; NR: Não relatado.  
61  
**Tabela 23 –** Resultados de acurácia para os estudos que compararam oftalmoscopia vs. fotografia estereoscópica (7 campos)  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Emanuele et**<br>**al. 2009**<sup>**32**</sup>|340 pacientes com<br>diabetes tipo II. Objetivo:<br>comparar a fotografia de<br>fundo com a<br>oftalmoscopia no<br>diagnóstico de RD|Oftalmoscopia|Fotografia<br>estereoscópica 30° (7<br>campos)|Qualquer RD: 51<br>RDNP/RDP: 49<br>RDP: 61<br>EMCS: 24|Qualquer RD: 91<br>RDNP/RDP: 96<br>RDP: 98<br>EMCS: 98|NR|NR|
|**Lawrence,**<br>**2004**<sup>**42**</sup>|254 pacientes (508 olhos)<br>com diabetes. Objetivo:<br>avaliar os resultados de<br>acurácia entre fotografias<br>digitais de alta e baixa<br>resolução, dilatada ou<br>não, tendo como<br>referência fotografia<br>estereoscópica ou<br>oftalmoscopia|Oftalmoscopia direta dilatada|Fotografia<br>estereoscópica 30°|Padrão - fotografia<br>estereoscópica 30°:<br>Oftalmoscopia: 0,73|Padrão - fotografia<br>estereoscópica 30°:<br>Oftalmoscopia: 0,91|NR|NR|
|**Lin et al.**<br>**2002**<sup>**43**</sup>|197 pacientes com<br>diabetes mellitus tipos I e<br>II. Objetivo: Avaliar a<br>fotografia não midriática,<br>digital, monocromática,<br>único campo (widefield)<br>como ferramenta de<br>triagem da RD.|Oftalmoscopia/biomicroscopia<br>(indireta)|Fotografia<br>estereoscópica 30° (7<br>campos)|Oftalmoscopia vs. fotografia<br>30° (ETDRS): 34|Oftalmoscopia vs. fotografia<br>30° (ETDRS): 100|NR|NR|  
62  
|**Autor, ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%)**<br>**(IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Pugh et al.**<br>**1993**<sup>**56**</sup>|352 pacientes diabéticos.<br>Objetivo: avaliar o<br>desempenho diagnóstico<br>oftalmoscopia direta e<br>indireta feita pelo<br>oftalmologista,<br>oftalmoscopia direta por<br>médico assistente,<br>fotografia 45° sem<br>dilatação e com dilatação<br>vs. fotografia<br>estereoscópica 30° (7<br>fields)|Oftalmoscopia direta e indireta<br>feita pelo oftalmologista,<br>Oftalmoscopia direta por médico<br>assistente,<br>Fotografia 45° sem dilatação<br>Fotografia 45° com dilatação|Fotografia de fundo<br>esteroscópica 30° (7<br>field)|Oftalmoscopia:<br>Oftalmo: 0,33<br>Assistente: 0,14<br>Fotografia 45°:<br>Não-midriática: 0,61<br>Midriática: 0,81<br>p<0,0001 (oftalmo vs.<br>midriática)<br>p<0,002 (não midriática vs.<br>midriática)<br>p<0,02 (oftalmo vs.<br>assistente)|Oftalmoscopia:<br>Oftalmo: 0,99<br>Assistente: 0,99<br>Fotografia 45°:<br>Não-midriática: 0,85<br>Midriática: 0,96<br>p=0,011 (oftalmo vs.<br>midriático)<br>p=0,0001 (midriática vs.<br>Não midriática)|NR|NR|
|**Kinyoun et al.**<br>**1992**<sup>**38**</sup>|124 pacientes com<br>diabetes mellitus tipo 2.<br>Objetivo: comparar<br>oftalmoscopia vs.<br>fotografia de fundo para<br>detecção e graduação da<br>RD|Oftalmoscopia direta e indireta|Fotografia de fundo<br>esteroscópica (7 field)|61 (42-77)|99 (95; 100)|NR|NR|
|**Kleinstein et**<br>**al. 1987**<sup>**40**</sup>|25 olhos de pacientes com<br>variados graus de RD.<br>Objetivo: Verificar o<br>desempenho da fotografia<br>estereoscópica (7 field) x<br>oftalmoscopia direta e<br>indireta realizada por<br>optometrista|Oftalmoscopia dilatada direta ou<br>indireta|Fotografia<br>estereoscópica (7<br>field)|74 (67; 81)|84 (73; 96)|NR|NR|
|**Moss et al.**<br>**1985**<sup>**48**</sup>|1949 pacientes diabéticos.<br>Objetivo:  avaliar o<br>desempenho diagnóstico<br>da oftalmoscopia vs.<br>Fotografia estereoscópica<br>na graduação da RD|Oftalmoscopia direta e indireta|Fotografia de fundo<br>estereoscópica (sete<br>campos)|RD: 0,81 (78; 83)<br>RDNP: 0,78 (0,75; 0,81)<br>RDP: 0,98 (0,93; 0,99)|RD: 0,95 (0,94; 0,96)<br>RDNP: 0,95 (0,94; 0,96)<br>RDP: 1,0 (0,99; 1,0)|82,12 (57 a 115)<br>p/ todas as RD|NR|  
63  
OR: OddsRatio; RD: retinopatia diabética; RDP: retinopatia diabética proliferativa; RDNP: retinopatia diabética não proliferativa; EMCS: edema macular clinicamente significante; NR: Não relatado;Oftalmo.: oftalmologista;OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%.  
**Tabela 24 –** Resultados de acurácia diagnóstica para estudos que avaliaram a oftalmoscopia vs. fotografias 30° e 45°  
|**Autor,**<br>**ano**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%) (IC95%)**|**Especificidade (%) (IC95%)**|**OR**<br>**diagnóstico**<br>**(IC95%)**|**Acurácia geral (%)**|
|---|---|---|---|---|---|---|---|
|**Ahsan et**<br>**al. 2014**<sup>**26**</sup>|366 (728) pacientes com<br>diabetes mellitus tipo 2.<br>Objetivo: Avaliar a acurácia<br>da oftalmoscopia direta vs.<br>fotografia retinal 45° 2<br>campos para detecção e<br>graduação de RD|Oftalmoscopia<br>direta dilatada|Fotografia de fundo<br>45° 2 campos (centro<br>da mácula e disco<br>óptico)|Qualquer RD: 55,67 (50,58; 60,78)<br>RD sem risco para visão: 37,36 (32,67;<br>42,59)<br>RD com risco para visão: 68,25 (63,48;<br>73,02)|Qualquer RD: 71,27 (66,63; 75,91)<br>RD sem risco para visão: 76,78<br>(72,45; 81,11)<br>RD com risco para visão: 90<br>(86,93; 93,07)|NR|NR|
|**Owens et**<br>**al. 1998**<sup>**53**</sup>|605 pacientes com diabetes<br>tipos I e II. Objetivo:<br>Verificar a habilidade de<br>generalistas na detecção de<br>RD com oftalmoscopia direta<br>vs. Foto retinal 45° 35 mm<br>dois campos|Oftalmoscopia<br>direta com dilatação|Foto retinal 45°, 35<br>mm, dois campos|Φ Qualquer RD: 62,6 (55,9; 69,4)<br>RD com risco à visão: 65,7 (54,4;<br>77,1)|Φ Qualquer RD: 75 (69,5; 80,5)<br>RD com risco à visão: 93,8 (91,4;<br>96,3)|NR|NR|
|**Schachat**<br>**et al.**<br>**1993**<sup>**62**</sup>|1168 pacientes com ou sem<br>diabetes. Objetivo: comparar<br>a oftalmoscopia vs. a<br>fotografia de fundo na<br>detecção de RD|Oftalmoscopia<br>direta|Fotografia de fundo<br>estereoscópica<br>bilateral 30° (2<br>campos)|77 (68; 85)|99 (98; 99)|NR|NR|
|**Klein et**<br>**al. 1985**<sup>**39**</sup>|99 pacientes, 71 com<br>diabetes. Objetivo: Comparar<br>a oftalmoscopia direta e as<br>fotografias midriática e não<br>midriática vs. fotografia<br>estereoscópica 30°|Oftalmoscopia<br>direta|Fotografia<br>estereoscópica 30° 3<br>campos|RD: 0,79 (0,65; 0,88)<br>RDNP: 0,75 (0,58; 0,87)<br>RDP: 0,91 (0,62; 0,98)|RD: 0,77 (0,53; 0,89)<br>RDNP: 0,75 (0,53; 0,89)<br>RDP: 1,0 (0,80; 1,0)|11,33 (3,2;<br>39,6) para<br>oftalmoscopia<br>em qualquer<br>RD|NR|  
64  
RD: retinopatia diabética;RDNP: retinopatia diabética não proliferativa;RDP: retinopatia diabética proliferativa; NR: Não relatado; φOs resultados só foram apresentados para a comparação Oftalmoscopia vs. fotografia 45°, a comparação entre fotografias quando realizadas por oftalmologista e generalista não foi mostrada, pois não é intenção desse estudo comparar a habilidade dos diferentes profissionais; OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%.  
65

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **C. Questão de pesquisa 3** -->
**Questão de Pesquisa 3:** Em quais situações é indicada a angiofluoresceinografia?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Medline via Pubmed** -->
(((((("Fluorescein Angiography"[Mesh] OR “fluorescein angiography” OR “Fluorescence Angiography”) AND ("therapeutic use" [Subheading] OR utilization OR indication)))) OR (( "Fluorescein Angiography/standards"[Mesh] OR "Fluorescein Angiography/therapeutic use"[Mesh] OR "Fluorescein Angiography/therapy"[Mesh] OR "Fluorescein Angiography/trends"[Mesh] OR "Fluorescein Angiography/utilization"[Mesh] )))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)  
Resultado: 769 referências  
Data:28/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('retina fluorescein angiography'/exp OR 'retina fluorescein angiography' OR 'fluorescence angiography'/exp OR 'fluorescence angiography' OR 'angiofluoresceinography') AND [embase]/lim  
Resultado: 1.670 referências  
Data:28/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Importadas 769 referências da MEDLINE e mais 1670 da EMBASE. Foram retiradas, automaticamente, 208 duplicatas. Mais 104 duplicatas foram retiradas manualmente, restando 2127 artigos para serem avaliados por título e resumo. A partir da leitura de títulos e resumos foram selecionadas 41 referências para leitura completa. Dessas, 36 foram excluídas, sendo 32 por não apresentar resultados de acurácia diagnóstica, dois por não avaliar a tecnologia considerada na questão, dois que avaliaram pacientes com outras condições que não retinopatia diabética e um por avaliar desfecho não considerado nessa pergunta. Dessa maneira, seis estudos transversais<sup>51,85,86,172-174</sup> de acurácia diagnóstica foram incluídos, sendo um recuperado através de busca manual<sup>172</sup> .  
**3)** **<mark>Descrição dos estudos e resultados</mark>**  
As características dos estudos incluídos se encontram na **Tabela 25** . A **Tabela 26** exibe os resultados de acurácia diagnóstica.  
66  
**Tabela 25 –** Características dos estudos e pacientes incluídos  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Amostra (N)**|**Idade, média (DP)**|**% sexo masc.**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(Logmar (DP)**|**Espessura central da**<br>**fóvea (µm (DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Barteselli et al.**<br>**2013**<sup>**173**</sup>|Transversal|1019 (149 com RD)|70 (faixa 11-103)|44|NR|0,29 (0,36) snellen<br>20/40|271 (127)|Alto (não single-gate, os<br>investigadores sabiam os<br>resultados dos testes índice e<br>referência)|
|**Khalaf et al.**<br>**2007**<sup>**174**</sup>|Transversal|189|54,91 (12,52)|1:1 (189<br>participantes)|NR|NR|NR|Baixo|
|**Razvi et al.**<br>**2001**<sup>**86**</sup>|Transversal|84|NR|NR|NR|NR|NR|Baixo|
|**Newsom et al.**<br>**2000**<sup>**51**</sup>|Transversal|37|Faixa: 25 a 70 anos|NR|NR|NR|NR|Moderado (não é possível saber<br>se os investigadores dos testes<br>índice e referência eram<br>mascarados)|
|**Kysltra et al.**<br>**1999**<sup>**85**</sup>|Transversal|96|NR|NR|NR|NR|NR|Alto (não single-gate, os<br>investigadores sabiam os<br>resultados dos testes índice e<br>referência)|
|**Rand et al.**<br>**1987**<sup>**175**</sup>|Transversal|267|24 (7,8)|NR|9,4 (1,6)|NR|NR|Alto (os investigadores sabiam<br>os resultados dos testes índice e<br>referência)|  
AF: angiofluoresceinografia; TCO: tomografia de coerência ótica; RD: retinopatia diabética; EMCS: edema macular clinicamente significante; EMD: edema macular diabético; Masc.: masculino; HbA1c: hemoglobina glicada; DP: desvio padrão; NR: não reportado.  
67  
**Tabela 26 –** População dos estudos, testes índice e referência e principais desfechos de acurácia diagnóstica.  
|**Autor, ano**|**Indicação**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Conclusão estudo**|
|---|---|---|---|---|---|---|---|---|
|**Barteselli**<br>**et al.**<br>**2013**<sup>**173**</sup>|Detecção de<br>edema macular<br>em diversas<br>condições|1019 pacientes com<br>edema macular (149 por<br>RD). Objetivo:<br>comparar o desempenho<br>diagnóstico entre AF e<br>TCO|AF<br>TCO|TCO<br>AF|RD:<br>AF: 1,00<br>TCO: 0,79 (0,72; 0,86)|NR|NR|FA com fluoresceína por via<br>oral se mostrou mais<br>adequada que a OCT para a<br>identificação e edema<br>macular.|
|**Khalaf et**<br>**al. 2007**<sup>**174**</sup>|Detecção de<br>retinopatia<br>diabética|189 pacientes (376<br>olhos) com diabetes.<br>Objetivo: comparar a<br>efetividade de<br>diagnóstico entre AF vs.<br>biomicroscopia|AF|Biomicroscopia|91,2|97,9|5,03|O estudo considerou a<br>biomicroscopia bastante<br>sensível para classificação de<br>RD e que a confirmação por<br>AF não é necessária.|
|**Razvi et al.**<br>**2001**<sup>**86**</sup>|Detecção de<br>EMD|84 pacientes com<br>diabetes. Objetivo:<br>verificar se a AF é uma<br>alternativa para detectar<br>EMD.|AF|Biomicroscopia|92,9 (68; 100)|81,4 (62; 100)|NR|O estudo concluiu que a AF é<br>eficiente e sensível para o<br>diagnóstico de EMD e deve<br>ser usada como ferramenta<br>adjunta.|
||||||Graduação da RD:|Graduação da RD:|||
|**Newsom et**<br>**al. 2000**<sup>**51**</sup>|Triagem de RD<br>em variados<br>graus|37 pacientes com<br>diabetes. Objetivo:<br>comparar o desempenho<br>diagnóstico entre AF vs.<br>fotografia de fundo<br>digital|AF<br>Fotografia de<br>fundo digital|Fotografia de<br>fundo colorida<br>(7SF)|Foto digital: 0,87<br>AF: 0,87<br>Edema macular:|Foto digital: 0,83<br>AF: 0,80 (p = 0,1 entre testes)<br>Edema macular:<br>Foto digital: 0,95|NR|O estudo conclui ambos os<br>métodos podem ser utilizados<br>para a triagem de retinopatia.<br>Porém, em caso de<br>maculopatia, a AF deve ter<br>seu uso mais encorajado.|
||||||Foto digital: 0,48<br>AF: 0,87|AF: 0,87 (p<0,001, favorece<br>AF)|||  
68  
|**Autor, ano**|**Indicação**|**População e objetivo**|**Índice**|**Referência**|**Sensibilidade (%)**<br>**(IC95%)**|**Especificidade (%) (IC95%)**|**OR diagnóstico**<br>**(IC95%)**|**Conclusão estudo**|
|---|---|---|---|---|---|---|---|---|
|**Kysltra et**<br>**al. 1999**<sup>**85**</sup>|Detecção de<br>isquemia|96 pacientes (100<br>olhos), com EMCS.<br>Objetivo: Testar se há<br>necessidade de uso da<br>AF para o correto<br>tratamento com laser|Fotografia<br>estereoscópica<br>colorida|AF|38,2|92,4|NR|O estudo conclui que o uso<br>de AF aumenta a acurácia do<br>tratamento com laser para<br>EMCS.|
|**Rand et al.**<br>**1987**<sup>**175**</sup>|Detecção de<br>retinopatia<br>diabética|267 pacientes<br>diabéticos. Objetivo:<br>Comparar o<br>desempenho diagnóstico<br>de fotografia de fundo<br>vs. AF, para detecção de<br>RD|AF<br>Fotografia de<br>fundo colorida<br>(7SF)|Montagens<br>adjacentes dos<br>campos 1F e 2F<br>pela fotografia de<br>fundo + os<br>negativos da AF|7SF: 84 (81; 87)<br>AF: 86 (82; 91)|NR|NR|Quando usada conjuntamente<br>com 7SF a AF promove<br>pequeno aumento na<br>sensibilidade. De acordo com<br>o estudo, apresenta pouco<br>ganho no gerenciamento do<br>paciente.|  
AF: angiofluoresceinografia; TCO: tomografia de coerência ótica; SF: _sevenfields_ ou sete campos; RD: retinopatia diabética; NR: Não reportado; EMCS: Edema macular clinicamente significante; EMD: edema macular diabético;OR: Oddsratio ou razão de chances; IC 95%: intervalo de confiança de 95%.  
69

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **D. Questão de pesquisa 4** -->
**Questão de Pesquisa 4:** Em quais situações é indicada a TCO?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **MEDLINE via Pubmed:** -->
(((((((("Tomography, Optical Coherence"[Mesh] OR Coherence Tomography, Optical OR TCO Tomography OR Tomography, TCO OR Optical Coherence Tomography OR TCO)))) AND ("therapeutic use" [Subheading] OR utilization OR indication))) OR (( "Tomography, Optical Coherence/standards"[Mesh] OR "Tomography, Optical Coherence/therapeutic use"[Mesh] OR "Tomography, Optical Coherence/therapy"[Mesh] OR "Tomography, Optical Coherence/trends"[Mesh] OR "Tomography, Optical Coherence/utilization"[Mesh] )))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: 1.257 referências -->
Data de acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'optical coherence tomography'/exp OR 'optical coherence tomography' OR 'TCO' AND ('diabetic retinopathy'/exp OR 'diabetic retinopathy') AND [embase]/lim

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: 1.948 referências -->
Data de acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Apenas foram incluídos estudos de acurácia diagnóstica transversais ou de caso-controle e os principais estudos clínicos (inclusos numa revisão sistemática recuperada pela busca) avaliando a terapia anti-VEGF, como forma de obter o regime de uso da TCO.  
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 3205 referências (1257 no MEDLINE e 1948 no Embase). Destas, 444 foram excluídas por estarem duplicadas. Duas mil setecentas e sessenta e uma referências foram triadas por meio da leitura de título e resumos, das quais 40 referências tiveram seus textos completos avaliados para confirmação da elegibilidade. Trinta e quatro estudos foram excluídos: duas revisões sistemáticas, uma por estar desatualizada<sup>176</sup> e outra por não abordar a condição avaliada<sup>167</sup> ; e 32 estudos observacionais, por estarem inclusos numa revisão sistemática incluída ou por não abordarem acurácia diagnóstica da TCO. Dessa maneira, seis estudos foram incluídos, sendo duas revisões sistemáticas<sup>89,133</sup> e 4 estudos observacionais de acurácia diagnóstica<sup>177-180</sup> . Vinte e oito ensaios clínicos randomizados, originalmente inclusos na revisão sistemática de Virgili et al. 2014<sup>133</sup> , foram recuperados manualmente, como forma de avaliar as situações de uso da TCO.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e resultados</mark>** -->
As **tabelas 27 e 28** exibem as características e resultados de acurácia diagnóstica. A **Tabela 29** exibe as principais situações de uso da TCO nos principais ensaios clínicos avaliando agentes anti-VEGF para o tratamento de edema macular diabético.  
70  
**Tabela 27 –** Características dos estudos e pacientes incluídos  
|**Autor, ano**|**Indicação**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade**<br>**intervenção,**<br>**média (DP)**|**Idade**<br>**controle,**<br>**média (DP)**|**% sexo**<br>**masc.**<br>**Intervenção**|**% sex**<br>**masc**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura**<br>**central da retina**<br>**(µm), média**<br>**(DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Virgili et al.**<br>**2015**<sup>**89**</sup>|Diagnóstico de<br>EMCS e EMD<br>(espessura da<br>retina)|NA|NA|NA|NA|NA|NA|NA|NA|NA|Baixo|
|**Salz et al.**<br>**2016**<sup>**177**</sup>|Análise da<br>microvasculatura<br>da retina em RD|30 pacientes*|6<br>pacientes|55,7 (10)|55,1 (6,4)|NR|NR|NR|NR|NR|Incerto (as análises<br>com o teste padrão não<br>foram realizadas todas<br>no mesmo dia)|
|**Azrak et al.**<br>**2015**<sup>**178**</sup>|Diagnóstico de RD<br>grave, muito<br>grave, proliferativa<br>e EMD|Padrão ouro e<br>índice: 136<br>olhos||63 (15,1)||66 (48,5)||7,7 (1,6)|BCVA: 0,7 (0,3)|268,6 (79,5)|Baixo|
|**Goebel;**<br>**Kretzchmar-**<br>**gross, 2002**<sup>**179**</sup>|Medida da<br>espessura da retina<br>(EMD) (cutoff de<br>183µm)|136|30|64 (12)|53 (20)|NR|NR|Intervenção:<br>8,4 (1,7)|NR|NR|Alto (nem todos os<br>pacientes receberam o<br>padrão de referência;<br>não há certeza de<br>cegamento quanto a<br>aplicação do teste<br>índice)|  
71  
|**Autor, ano**|**Indicação**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade**<br>**intervenção,**<br>**média (DP)**|**Idade**<br>**controle,**<br>**média (DP)**|**% sexo**<br>**masc.**<br>**Intervenção**|**% sex**<br>**masc**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura**<br>**central da retina**<br>**(µm), média**<br>**(DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||Sem RD: 56<br>(29-77)||||||||
|**Sanchez-**<br>**Tocino et al.**<br>**2002**<sup>**180**</sup>|Diagnóstico de<br>edema pela<br>espessura da fóvea<br>(cutoff de 180µm)|85|26|RDNP sem<br>edema: 60<br>(21-77)<br>RDP sem<br>edema: 56<br>(32-75)<br>EMD: 60 (29-<br>81)|52 (21-79)|NR|NR|NR|NR|NR|Alto (caso-controle<br>diagnóstico)|  
*Os resultados qualitativos de acurácia diagnóstica só foram realizados para 17 indivíduos; HbA1c: hemoglobina glicada; Masc.: masculino; DP: desvio padrão; EMD: edema macular diabético; EMCS: edema macular diabético clinicamente significante; RD: retinopatia diabética; RDP: retinopatia diabética proliferativa; RDNP: retinopatia diabética não proliferativa;BCVA: acuidade visual de melhor corrigida; NR: não reportado; NA: não se aplica.  
**Tabela 28 –** Principais resultados de acurácia diagnóstica para os estudos incluídos  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo**|**Intervenção**|**Controle**|**Risco de viés**|**Sensibilidade**<br>**(%) (IC 95%)**|**Especificidade**<br>**(%) (IC 95%)**|**OR**<br>**diagnóstico**<br>**(IC 95%)**|**AUC (IC 95%)**|
|---|---|---|---|---|---|---|---|---|---|
|**Virgili et al.**<br>**2015**<sup>**89**</sup>|Revisão<br>sistemática<br>com meta-<br>análise|EMCS: 9 estudos<br>observacionais (749<br>participantes)<br>EMD: 3 estudos<br>observacionais (180<br>participantes)|TCO|Referência: fotografia de<br>fundo ou biomicroscopia|Baixo|0,81 (0,74; 0,86)|0,85 (0,75; 0,91)|23 (13; 40)|NR|  
72  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo**|**Intervenção**|**Controle**|**Risco de viés**|**Sensibilidade**<br>**(%) (IC 95%)**|**Especificidade**<br>**(%) (IC 95%)**|**OR**<br>**diagnóstico**<br>**(IC 95%)**|**AUC (IC 95%)**|
|---|---|---|---|---|---|---|---|---|---|
|**Salz et al.**<br>**2016**<sup>**177**</sup>|Transversal<br>(acurácia<br>diagnóstica e<br>quantitativo<br>vs. controle)|30 indivíduos com diabetes<br>e 6 controles sem.<br>Objetivo: verificar a<br>utilidade clínica de OCTA<br>vs. angiofluoresceinografia<br>na análise da<br>microvasculatura da retina|OCTA (OCT<br>angiografia)|Angiofluoresceinografia|Incerto (as<br>análises com o<br>teste padrão<br>não foram<br>realizadas<br>todas no<br>mesmo dia)|85 (53; 97)|75 (21; 98)|NR|NR|
|**Azrak et al.**<br>**2015**<sup>**178**</sup>|Transversal<br>(acurácia<br>diagnóstica)|136 olhos de pacientes<br>diabéticos com suspeita de<br>retinopatia|TCO|Exame de retina<br>(oftalmoscopia indireta e<br>biomicroscopia)|Baixo|91,67 (79,13;<br>97,30)|93,18 (85,19;<br>97,20)|NR|p/ espessura central<br>da fóvea: 0,89 (0,81;<br>0,97), p<0,001|
|**Goebel;**<br>**Kretzchmar-**<br>**gross, 2002**<sup>**179**</sup>|Transversal<br>(acurácia<br>diagnóstica)|136 pacientes em diferentes<br>estágios de RD e 30<br>controles sem diabetes.|TCO (OCT 2000<br>Scanner, Zeiss-<br>Humphrey,<br>San Leandro,<br>CA),|Angiofluoresceinografia ou<br>biomicroscopia|Alto (nem<br>todos os<br>pacientes<br>receberam o<br>padrão de<br>referência; não<br>há certeza de<br>cegamento<br>quanto a<br>aplicação do<br>teste índice)|Fóvea corte <<br>183 µm: 81%<br>Média corte <<br>271 µm: 73%<br>Somente EMCS:<br>Fóvea: 89%<br>Média: 80%|Fóvea corte < 183<br>µm: 94 %<br>Média corte < 271<br>µm: 100%<br>Somente EMCS:<br>Fóvea: 96%<br>Média: 100%|NR|NR|
|**Sanchez-**<br>**Tocino et al.**<br>**2002**<sup>**180**</sup>|Caso controle<br>diagnóstico|85 pacientes com diabetes e<br>26 indivíduos saudáveis.<br>Objetivo: estimar as<br>variáveis preditivas de<br>edema macular, bem como<br>o cutoff.|TCO (Zeiss-<br>Humphrey<br>Instruments, San<br>Leandro, CA)|TCO (medidas de espessura<br>de diversas regiões da<br>retina)|Alto (caso-<br>controle<br>diagnóstico)|93 (78; 99)|75 (67; 82)|NR|0,94, p=0,001|  
TCO: tomografia de coerência ótica;RD: retinopatia diabética; RDP: retinopatia diabética proliferativa; OR: Oddsratio ou razão de chances; AUC: _areaunder curve_ ou área sobre a curva;OCTA: angiografia por tomografia de coerência ótica; IC 95%: intervalo de confiança de 95%; NR: não reportado; NA: não se aplica.  
73  
**Tabela 29 –** Situações de uso da TCO nos principais estudos clínicos avaliando edema macular diabético  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Comparação**|**Condição**|**Equipamento de TCO**|**Situações de uso da TCO**|
|---|---|---|---|---|---|
||||**Revisão s**|**istemática om meta-análise**||
|**Virgili et al. 2014**<sup>**133**</sup>|Revisão<br>sistemática com<br>meta-análise|Várias (depende dos<br>estudos inclusos)|Edema macular|Vários (depende dos estudos inclusos)|**Definição de regime de tratamento PRN**:<br>Somente TCO: estudos* BOLT e READ-2;<br>TCO + Acuidade: estudos* de**Azad et al. 2012**, DRCR,net,<br>RESOLVE|
||||**Estudos co**|**ntidos em Virgili et al. 2014**||
|**Ahmadieh et al. 2008**<sup>**95**</sup>|ECR|BIV + TRI vs. BIV|Edema macular|(Zeiss,Dublin, CA)|TCO aplicado no início do estudo e nas semanas 6, 12, 18 e 24<br>(intervalos de seis semanas)|
|**Azad et al. 2012**<sup>**181**</sup>|ECR|BIV vs. TRI vs.<br>Laser|Edema macular|Stratus TCO, Carl Zeiss Meditec Dublin, CA|TCO aplicado no início do estudo e após 1, 3 e 6 meses|
||||||Definição de envolvimento do centro da fóvea por TCO: ≥ 270 µm|
|**Michaelidis et al. 2010;**<br>**Rajendran et al. 2012;**<br>**Sivaprasad et al. 2013**<br>**96,182,183**<br>**(BOLT)**|ECR|BIV vs. Laser<br>BIV monoterapia em<br>**Sivaprasad et al.**<br>**2013**(post hoc) 24<br>meses|Edema macular|Stratus TCO 3000, Carl Zeiss Ophthalmic<br>Systems Inc., Humphrey Division, Dublin,<br>CA|Algoritmo de tratamento baseado em TCO: IVB aplicado no início<br>e após 6 e 12 semanas. Após isso, só seriam necessárias novas<br>injeções de a espessura fosse ≥ 270 µm.<br>TCO aplicado no início do estudo e após 6, 12, 18, 24, 30, 36, 42,<br>48 e 52 semanas (intervalos de 6 semanas). Em**Rajendram et al.**<br>**2012**os intervalos de 6 semanas continuaram até 102 semanas.|  
74  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Comparação**|**Condição**|**Equipamento de TCO**|**Situações de uso da TCO**|
|---|---|---|---|---|---|
|**Do et al. 2012; Do et al.**<br>**2011**<sup>**128,129**</sup><br>**(DA VINCI)**|ECR|AIV 0,5 mg a cada 4<br>sem. vs. AIV 2 mg a<br>cada 4 sem. vs. AIV<br>2 mg a cada 8 sem.<br>vs. 2 mg PRN vs.<br>Laser|Edema macular|(Stratus TCO; Carl ZeissMeditec, Jena,<br>Germany)|Definição de envolvimento do centro da fóvea por TCO: ≥ 250 µm<br>TCO aplicado no início do estudo e a cada 4 semanas até a semana<br>52 (intervalos de quatro semanas). Semana 24 no caso**de Do et al.**<br>**2011**<br>Algoritmo de tratamento baseado em TCO: Pacientes do grupo<br>PRN só receberiam AIV, após as três doses mensais, se a<br>espessura macular fosse ≥ 250 µm|
||||||Definição de envolvimento do centro da fóvea por TCO: ≥ 250 µm|
|**Bressler e al. 2012; Elman**<br>**et al. 2012**<br>**(DRCR.net)**<sup>**184,185**</sup><br>**Bressler et al. 2013; Elman**<br>**et al. 2010; Elman et al.**<br>**2011**<sup>**92,186,187**</sup><br>**(DRCR.net)**|ECR|0,5 mg RIV + prompt<br>laser vs. 0, mg RIV +<br>laser retardado<br>sham + prompt laser<br>Vs. 0,5 mg RIV +<br>prompt laser vs. 0,<br>mg RIV + laser<br>retardado Vs. TRI +<br>prompt laser|Edema macular|Zeiss Stratus TCO machine (Carl Zeiss<br>Meditec, Inc).|TCO aplicado no início do estudo e a cada 4 semanas até a semana<br>52 (intervalos de 4 semanas).**Bressler et al. 2013**: intervalos de 4<br>semanas para todos os grupos até a semana 48 e daí em diante (até<br>a semana 156) se necessário (espessura da fóvea fosse ≥ 250 µm).<br>**Elman et al. 2010, 2011**: intervalos de 4 semanas até a semana 52<br>e a cada mês desse ponto até a semana 104.**Elman et al. 2012**:<br>intervalos de 4 semanas até a semana 52 e a cada mês desse ponto<br>até a semana 156.<br>Os pacientes receberiam 4 injeções mensais a partir do basal e daí<br>a diante, apenas se houvesse falha (espessura da fóvea fosse ≥ 250<br>µm)|
|**Korobelnik et al. 2014**<sup>**80**</sup><br>**(VISTA e VIVID)**|ECR|AIV 2mg a cada 4<br>semanas vs. AIV<br>2mg a cada 8<br>semanas (após 5<br>doses mensais) vs.<br>laser|Edema macular|Não especificado|TCO aplicada no início do estudo e após a cada 4 semanas até a<br>semana 52.|  
75  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Comparação**|**Condição**|**Equipamento de TCO**|**Situações de uso da TCO**|
|---|---|---|---|---|---|
|**Comyn et al. 2014**<sup>**91**</sup><br>**(LUCIDATE)**|ECR|RIV 0,5mg vs. laser|Edema macular|Spectralis TCO (Heidelberg Engineering<br>GmbH, Heidelberg, Germany)|Definição de envolvimento do centro da fóvea por TCO: ≥ 300 µm<br>TCO aplicado a cada 4 semanas até a semana 48.<br>Tratamento aplicado nas semanas 0, 4 e 8 e depois, se necessário,<br>de acordo com resultado de espessura da mácula (≥ 300 µm)|
|**Nepomuceno et al. 2013**<sup>**188**</sup>|ECR|BIV 1,5 mg vs. RIV<br>0,5 mg|Edema macular|(SpectralisEyetrackerTomographer, HRA-<br>TCO; Heidelberg Engineering)|Definição de envolvimento do centro da fóvea por TCO: > 300 µm<br>Retratamento: foi feito mensalmente se a espessura central da<br>macula, pelo TCO, fosse > 275 µm.<br>TCO aplicada no início do estudo e, após isso, a cada 4 semanas<br>até a semana 48.|
||||||Definição de envolvimento do centro da fóvea por TCO: ≥ 250 µm|
|**Do et al. 2013; Nguyen et**<br>**al. 2010; Nguyen et al. 2009**<br>**189-191**<br>**(READ-2)**|ECR|RIV 0,5mg vs. RIV +<br>laser vs. laser|Edema macular|Time-domain TCO (modelo não especificado)|TCO aplicada nos meses 1, 3 e 5. Do mês 6 até o 24 TCO foi<br>aplicada a cada dois meses e se a espessura da macula fosse ≥ 250<br>µm, havia retratamento. Após a semana 24 até a 36, TCO foi<br>aplicada mensalmente e se a espessura da macula fosse ≥ 250 µm,<br>havia retratamento. No caso de**Nguyen et al. 2009**: limite de seis<br>meses.**Nguyen et al. 2010**: 24 meses.|
||||||Definição de envolvimento do centro da fóvea por TCO: ≥ 300 µm|
|**Massin et al. 2010**<sup>**94**</sup><br>**(RESOLVE)**|ECR|RIV 0,3 mg vs. RIV<br>0,5 mg vs. sham|Edema macular|(TCO) (Stratus TCO; Carl ZeissMeditec, Jena,<br>Germany).|TCO foi aplicada no início do estudo e, daí em diante,<br>mensalmente até o mês 12. Depois do mês 1, se os pacientes<br>estivessem com espessura da mácula > 300 µm, a dose era<br>dobrada, permanecendo assim por >45 dias e retornando a dose<br>inicial.|  
76  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Comparação**|**Condição**|**Equipamento de TCO**|**Situações de uso da TCO**|
|---|---|---|---|---|---|
|**Berger et al. 2015****<sup>**90**</sup><br>**(RESPOND)**|ECR|RIV 0,5 mg Vs. RIV<br>0,5 + laser Vs. laser|Edema macular|Não especificado|TCO foi aplicado no início do estudo e depois mensalmente até o<br>mês 12.|
|**Lang et al. 2013; Schmidt-**<br>**Erfurth et al. 2014**<sup>**150,151**</sup><br>**(RESTORE)**<br>**Mitchell et al. 2011**<sup>**78**</sup><br>**(RESTORE)**|ECR (extensão)<br>ECR|RIV 0,5 mg PRN e<br>Laser PRN<br>RIV 0,5 mg + laser<br>sham vs. RIV 0,5 mg<br>+ laser Vs.<br>injeçãosham + laser|Edema macular|Stratus [time-domain] TCO|Nesse estudo o critério de estabelecimento do regime PRN não<br>considerou os resultados de espessura da mácula e sim a acuidade<br>visual<br>TCO foi aplicado mensalmente durante o estudo original (12<br>meses;**Mitchell et al. 2011**) e a fase de extensão (24 meses;**Lang**<br>**et al. 2013**e 36 meses;**Schmidt-Erfurth et al. 2014**).|
|**Brown et al. 2013; Nguyen**<br>**et al. 2012**<sup>**79,88**</sup><br>**(RISE e RIDE)**|ECR (controlado<br>por dois anos<br>(2012) e um ano<br>crossover (2013))|RIV 0,5 mg vs. RIV<br>0,3 mg vs. sham|Edema macular|Time domain TCO (não especifica modelo)|Definição de envolvimento do centro da fóvea por TCO: ≥ 275 µm<br>TCO aplicada nos meses 0, 1, 2, 3, 6 e em intervalos de seis meses,<br>daí em diante, até o mês 36. 24 meses de estudo no caso de<br>**Nguyen et al. 2012**|
|**Soheilian et al.**<br>**2012;Soheilian at al. 2009**;<br>**Soheilian et al. 2007**<sup>**192-194**</sup>|ECR|BIV 1,25mg vs. BIV<br>1,25 + TRI 2 mg vs.<br>laser|Edema macular|Time-domain equipment (Zeiss, Dublin, CA)|TCO aplicada em intervalos de 6 meses a partir do início do estudo<br>até 24 meses. 36 meses no estudo de 2009 e 12 meses no estudo de<br>2007.|  
*Estudos descritos logo abaixo; **Na ocasião da revisão de Virgili et al, 2014, somente foram inclusos estudos não finalizados com registro no _Clinicaltrials_ , daí a inclusão deste estudo com data posterior, por ser completo; TCO: tomografia de coerência ótica; ECR: Estudo clínico randomizado; AIV: aflibercepte intravítreo;RIV: ranibizumabe intravítreo; BIV: bevacizumabe intravítreo; TRI: Triancinolona intravítreo.  
77

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **E. Questão de pesquisa 5** -->
**Questão de Pesquisa 5:** Qual a eficácia e segurança das terapias à laser, farmacológicas e cirúrgicas (individual, comparativo e associação)?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1) Estratégias de Busca** -->
As questões de pesquisa 5-10 referiram-se ao tratamento da retinopatia diabética com laser, vitrectomia ou terapia farmacológica (corticosteroides e/ou Anti-VEGFs), especificado em relação à presença ou não de edema macular, a localização do edema (centro da fóvea ou não) e extensão do tratamento (fixo, pro re nata ou tratar e extender). Dessa forma, uma única estratégia sensível de busca, descrita abaixo, foi elaborada e os resultados do processo de avaliação da elegibilidade foram estratificados de acordo com a questão de pesquisa.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **MEDLINE via pubmed:** -->
(((((((((("Light Coagulation"[Mesh] OR coagulation, light OR coagulations, light OR light coagulation OR photocoagulation OR photocoagulations OR laser photocoagulation OR laser coagulation)) OR ("Bevacizumab"[Mesh] OR avastin OR intravitreal bevacizumab)) OR ("Ranibizumab"[Mesh] OR lucentis OR intravitreal ranibizumab)) OR ("aflibercept" [Supplementary Concept] OR eylea OR intravitreal aflibercept)) OR ("Fluocinolone Acetonide"[Mesh] OR Iluvien OR intravitreal fluocinolone acetonide)) OR ("Dexamethasone"[Mesh] OR ozurdex OR intravitreal dexamethasone)) OR ("Vitrectomy"[Mesh] OR vitrectomy))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ("Treatment Outcome"[Mesh] OR efficacy OR effectiveness OR safety)

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
(("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ((((fixed regimen OR fixed scheme OR fixed)) OR (PRN OR pro re nata OR pro re nata regimen OR PRN regimen OR as needed OR PRN scheme OR pro re nata scheme)) OR (Treat and extend regimen OR treat-and-extend regimen OR treat and extend scheme OR treat-and-extend scheme OR treat and extend OR treat-and-extend))  
Total: 2.328 referências  
Data do acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('treatment outcome'/exp OR 'treatment outcome' OR 'safety'/exp OR safety OR 'efficacy'/exp OR efficacy OR effectiveness) AND ('bevacizumab'/exp OR 'bevacizumab' OR 'avastin'/exp OR 'avastin' OR 'intravitreal bevacizumabe' OR 'ranibizumab'/exp OR 'ranibizumab' OR 'lucentis'/exp OR 'lucentis' OR 'intravitreal ranibizumab' OR 'aflibercept'/exp OR 'aflibercept' OR 'eylea'/exp OR 'eylea' OR 'intravitreal aflibercept' OR 'dexamethasone'/exp OR 'dexamethasone' OR 'ozurdex'/exp OR 'ozurdex' OR 'intravitreal dexamethasone' OR 'fluocinolone acetonide'/exp OR 'fluocinolone acetonide' OR 'iluvien'/exp OR 'iluvien' OR 'intravitreal fluocinolone acetonide' OR 'laser coagulation'/exp OR 'laser coagulation' OR 'laser photocoagulation'/exp OR 'laser photocoagulation' OR 'vitrectomy'/exp OR 'vitrectomy' OR 'pars plana vitrectomy'/exp OR 'pars plana vitrectomy') AND [embase]/lim

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('fixed regimen' OR 'fixed scheme' OR 'fixed' OR 'prn'/exp OR 'prn' OR 'pro re nata' OR 'pro re nata regimen' OR 'prn regimen' OR 'as needed' OR 'prn scheme' OR 'pro re nata scheme' OR 'treat and extend regimen' OR 'treat-and-extend regimen' OR 'treat and extend scheme' OR 'treat-and-extend scheme' OR 'treat and extend' OR 'treatand-extend') AND [embase]/lim  
Total: 2.394 referências  
Data de acesso: 29/12/2016  
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 4.722 referências (2.328 no MEDLINE e 2.394 no</mark>  
<mark>Embase). Destas, 753 foram excluídas por estarem duplicadas. Três mil novecentos e sessenta e nove referências foram triadas por</mark>  
78  
meio da leitura de título e resumos, das quais 214 referências, correspondentes às 7 questões de pesquisa, tiveram seus textos completos avaliados para confirmação da elegibilidade.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Trinta e duas potenciais referências tiveram sua elegibilidade confirmada para a questão 5 por meio da leitura do texto completo. Destas, 9 foram excluídas, sendo 4 por considerarem apenas pacientes com edema macular, 1 por considerar técnica cirúrgica (cirurgia de catarata), não compreendida no escopo dessa questão e 4 por se tratar de revisões sistemáticas antigas, já contempladas nas duas revisões incluídas. Vinte e três estudos foram considerados elegíveis, sendo 2 revisões sistemáticas com meta-análise<sup>101,102</sup> , 1 revisão sistemática sem meta-análise<sup>195</sup> , 15 estudos contidos na revisão sistemática sem meta-análise e 5 ECRs, com mais de 100 participantes não contemplados nas revisões sistemáticas ou ECRs que compreendiam comparações pouco frequentes nas revisões sistemáticas<sup>111,113,196-198</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
As características dos estudos incluídos encontram-se na **Tabela 30** . As características basais estão demonstradas na **Tabela 31** . As **tabelas de 32 a 39** exibem os principais desfechos para os estudos incluídos, de acordo com as comparações entre as diferentes terapias (laser, cirurgia e farmacológica).  
79  
**Tabela 30 –** Características dos estudos incluídos para a resposta à questão 5 do PCDT de Retinopatia Diabética em Adultos  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||**R**|**evisão-sistemática com meta-análise**||||
|**Simunovic et**<br>**al. 2015**<sup>**102**</sup>|Revisão sistemática com<br>meta-análise|Avaliar a eficácia e segurança dos<br>agentes anti-VEGF x VPP e FPR na RD|22 ECR, com 1397 olhos randomizados|Anti-VEGF + VPP<br>Anti-VEGF + FPR|VPP<br>FPR|Baixo|
|**Martinez-**<br>**zapata et al.**<br>**2014**<sup>**101**</sup>|Revisão sistemática com<br>meta-análise|Avaliar a eficácia e segurança dos<br>agentes anti-VEGF x VPP e FPR na RD|18 ECR (16 incluídos nas meta-análises),<br>com 1005 participantes|Anti-VEGF + VPP<br>Anti-VEGF com ou<br>sem FPR|VPP<br>FPR|Baixo|
||||**Ensaios Clínicos Randomizados**||||
|**Beaulieu et al.**<br>**2016**<sup>**113**</sup><br>**(DRCR.net)**|ECR|Avaliar desfechos centrados nos<br>pacientes em indivíduos com RDP|305 adultos (216 olhos) com RDP e diabetes<br>mellitus tipo 1 ou 2.|Ranibizumabe 0,5-<br>mg/0,05mL|FPR|Baixo|
|**Gross et al.**<br>**2015**<sup>**111**</sup><br>**(DRCR.net)**|ECR|Avaliar a não inferioridade (limite de -5<br>letras na acuidade visual) do RIV em<br>relação a FPR em pacientes com RDP|305 participantes (394 olhos) com RDP e<br>diabetes mellitus tipo 1 ou 2|Ranibizumabe 0,5-<br>mg/0,05mL|FPR|Baixo|
|**Bhavsar et al.**<br>**2013**<sup>**197**</sup><br>**(DRCR.net)**|ECR|Avaliar a eficácia e a segurança do RIV<br>x salina em pacientes com RDP|261 participantes com RDP e diabetes<br>mellitus tipos 1 e 2|Ranibizumabe 0,5-<br>mg/0,05mL|Salina|Baixo|
|**Avitabile et al.**<br>**2011**<sup>**197**</sup>|ECR|Resultados anatômicos e visuais da<br>vitrectomiapars plana vs. FPR de<br>pacientes com RDP.|180 pacientes (180 olhos), adultos, com RDP<br>e diabetes mellitus tipo 1 ou 2|VPP + fotocoagulação|FPR|Baixo|
|**Faghihi et al.**<br>**2008**<sup>**199**</sup>|ECR|Avaliar a segurança e a eficácia da<br>triancinolona acetonida em pacientes<br>com hemorragia vítrea pós-vitrectomia|72 pacientes (72 olhos), adultos, com<br>diabetes mellitus tipos 1 e 2 e hemorragia<br>vítrea|Triancinolona<br>acetonida, 4 mg (0,1<br>cc) + VPP|VPP|Alto<br>(Randomização e<br>sigilo de alocação)|  
80  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Revisão-sistemática sem meta-análise**||||
|**Royle et al.**<br>**2015**<sup>**195**</sup>|Revisão sistemática|Avaliar a segurança e a eficácia de laser<br>e intervenções farmacológicas no<br>tratamento de RDNP.|12 ECR, com 982 pacientes;|Diversos tipos de laser|Diversos tipos de laser|Baixo|
|||**E**|**studos contidos em Royle et al. 2015**<sup>**194**</sup>||||
|**Muquit et al.**<br>**2010**<sup>**200**</sup>|ECR|Avaliar a eficácia de terapias a laser em<br>pacientes com RDP|40 olhos de 24 pacientes (2 olhos<br>descartados da análise, então 38)|Única sessão, FPR<br>multiponto (20 ms),<br>com matrizes<br>multipontos de 5,5 e<br>4,4(20 olhos)|Múltiplas sessões, FPR<br>único ponto (100 ms), três<br>sessões em 4 semanas.|Baixo|
|**Muqit et al.**<br>**2013**<sup>**201**</sup>|ECR|Avaliar os efeitos de curto prazo na<br>espessura macular usando três tipos de<br>laser.|30 olhos de 24 pacientes, maiores de 18<br>anos, com RDP recente e espessura macular<br><300 µm.|Fotocoagulaçãoretinal<br>direcionada (FRD)<br>(única sessão,<br>múltiplos pontos, 20<br>ms)|1) FPR minimamente<br>traumática (MT-FPR);<br>2) FPR de intensidade<br>padrão (SI-FPR).|Baixo|
|**Muraly et al.**<br>**2011**<sup>**202**</sup>|ECR|Comparar o efeito terapêutico entre o<br>laser PASCAL e o convencional|100 olhos de 50 pacientes adultos com RDP,<br>sem antes ter utilizado FPR|Laser PASCAL<br>(OptiMedica, Santa<br>Clara,<br>CA), única sessão, 30<br>ms, 2100–3900<br>queimaduras.|Laser convencional, três<br>sessões (532-nm<br>frequency-doubled<br>Nd:YAG; Carl<br>ZeissMeditec,<br>Dublin,California)|Alto<br>(Randomização, sigilo<br>de alocação e<br>mascaramento)|
|**Nagpal et al.**<br>**2010**<sup>**203**</sup>|ECR|Comparar a eficácia, a segurança e a<br>conveniência do laser Pascal vs. o laser<br>convencional verde GLX|60 pacientes com RDP sométrica bilateral ou<br>RDNP grave.|Laser PASCAL 20-ms<br>(OptiMedicaCorp,<br>Santa Clara, CA) 950–<br>1100 pontos|laser GLX (verde) (532<br>nm) (Iridex Corp,<br>Mountain View, CA)<br>single-spot slit-lamp<br>delivery PRP, 500–700<br>queimaduras|Alto<br>(Randomização, sigilo<br>de alocação,<br>mascaramento,<br>desfecho incompleto)|
|**Salman,**<br>**2011**<sup>**204**</sup>|ECR|Comparar a eficácia e a segurança do<br>laser Pascal vs. o laser convencional<br>verde|60 pacientes com RDNP (A2 = 30 tratados<br>com laser PASCAL e A1 = 30 com<br>Convencional) e EMD; e outros 60 pacientes<br>do RDP (B2 = 30 tratados com laser<br>PASCAL e B1 = 30 com Convencional).|PASCAL<br>(OptiMedica, Silicon<br>Valley, CA, 20 ms,<br>200 μm, 1000<br>queimaduras)|Laser Convencional (700<br>queimaduras; 532<br>nmgreen-light diode-<br>pumpedsolidstate -<br>NovusSpectra, Lumenis,<br>USA)|Alto<br>(Randomização, sigilo<br>de alocação,<br>mascaramento,<br>desfecho incompleto e<br>relato seletivo)|  
81  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Al-Hussainy et**<br>**al. 2008**<sup>**205**</sup>|ECR|Comparar a eficácia e o conforto do uso<br>do laser 532-nm, frequency-<br>doubledNd:YAG em exposição curta vs.<br>exposição convencional|20 pacientes fazendo FPR pela primeira vez.<br>17 com RDP, 2 com OVCR e 1 com<br>isquemia ocular.|FPR de exposição<br>curta (0.02 seg ou 20<br>ms) e dispersão de alta<br>energia|FPR convencional (100 ms<br>ou 0.1 seg) PRP, poder<br>sufuciente para produzir<br>uma queimadura cinza-<br>branca.|Alto<br>(Randomização e<br>sigilo de alocação)|
|**Bandello et al.**<br>**2001**<sup>**206**</sup>|ECR|Comparar os efeitos de FPR de baixa<br>energia (leve) vs. FPR convencional.|50 pacientes (65 olhos) com RDP de alto<br>risco e maiores de 18 anos|FPR leve em áreas<br>periféricas ou meso-<br>periféricas não<br>perfundidas|FPR convencional em áreas<br>periféricas ou meso-<br>periféricas não perfundidas|Baixo|
|**Sato et al.**<br>**2012**<sup>**100**</sup>|ECR|Comparar os efeitos do uso de FPR vs.<br>não uso, incluindo o desenvolvimento<br>de RDP.|69 pacientes com RD pré-proliferativa, > 18<br>anos, sem histórico de FPR. Apenas 36<br>participantes completaram os 36 meses de<br>seguimento|FPR (sem descrição<br>do laser)|Não FPR|Alto<br>(Mascaramento e<br>sigilo de alocação)|
|**Mirshahi et al.**<br>**2013**<sup>**207**</sup>|ECR|Comparar a eficácia e a segurança da<br>FPR em 20 ms e em 100 ms|33 pacientes (66 olhos), sendo todos maiores<br>de 18 anos, com RDP ou RDNP muito grave<br>e diabetes mellitus tipo 2|FPR de único ponto e<br>curta duração (20 ms)<br>(Nd:YAG 532-nm<br>Novus Varia,<br>Lumenis, USA)|FPR convencional (100<br>ms) (Nd:YAG 532-nm<br>Novus Varia, Lumenis,<br>USA)|Alto<br>(Mascaramento e<br>sigilo de alocação)|
|**Shimura et al.**<br>**2003**<sup>**208**</sup>|ECR|Investigar as alterações na espessura<br>macular em pacientes com RD grave e<br>comparar os resultados de eficácia da<br>FPR semanal e a cada duas semanas|36 pacientes (72 olhos) com RD grave e<br>diabetes mellitus tipo 2|PFR semanal (PRP<br>scatter laser in four<br>sessions. Krypton red<br>laser (Nidek,<br>Gamagori, Japan)|PFR a cada duas semanas<br>(PRP scatter laser in four<br>sessions. Krypton red laser<br>(Nidek, Gamagori, Japan)|Alto<br>(Randomização, sigilo<br>de alocação,<br>mascaramento,<br>desfecho incompleto)|  
82  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Suto et al.**<br>**2008**<sup>**209**</sup>|ECR|Avaliar os desfechos dependendo da<br>sequência dos tratamentos aplicados<br>(FPR + cirurgia de catarata vs. Cirurgia<br>de catarata + FPR), em pacientes com<br>diabetes mellitus tipo 2, RD e catarata.|29 pacientes com diabetes mellitus tipo 2,<br>além de RDNP grave ou RDP precoce e<br>catarata, simétricos bilateralmente.|FPR e depois cirurgia<br>de catarata (FPR<br>primeiro) - Laser<br>multicor (Coherent<br>Inc., Palo Alto, CA) e<br>uma lente de fundo<br>quadrasférica. Os<br>tratamentos<br>utilizaram,<br>principalmente, o laser<br>amarelo, mas também<br>o vermelho em caso<br>de catarata.|Cirurgia de catarata e<br>depois FPR (cirurgia<br>primeiro) - Laser multicor<br>(Coherent Inc., Palo Alto,<br>CA) e uma lente de fundo<br>quadrasférica. Os<br>tratamentos utilizaram,<br>principalmente, o laser<br>amarelo, mas também o<br>vermelho em caso de<br>catarata.|Baixo|
|**Tewari et al.**<br>**2000**<sup>**196**</sup>|ECR|Comparar os resultados do laser infra-<br>vermelho diodo com os do laser verde<br>de argônio em pacientes dom RDP|25 pacientes (50 olhos) com diabetes<br>mellitus tipo 2 e RDP bilateral|Laser diodo (810 nm,<br>Microlase, Keeler<br>Inc., UK)|Laser de Argônio (514 nm,<br>Novus 2000, Coherent)|Alto<br>(Mascaramento e<br>sigilo de alocação)|
|**Unoki et al.**<br>**2009**<sup>**118**</sup>|ECR|Verificar a efetividade da injeção<br>subtenoniana de Triancinolona<br>acetonida|41 pacientes (82 olhos) com RDNP grave ou<br>RDP|TRI subtenoniana,<br>20mg/0,5mL + FPR|FPR|Alto<br>(Sigilo de alocação)|
|**Cho et al.**<br>**2010**<sup>**116**</sup>|ECR|Verificar a eficácia da TRI + FPR vs.<br>BIV + FPR vs. FPR sozinha|76 pacientes (91 olhos) com RDNP grave ou<br>RDP de alto risco, com ou sem edema<br>macular|TRI 4m/0,1 mL + FPR<br>BIV1,25mg/0,05 mL<br>+ FPR|FPR|Alto<br>(Randomização, sigilo<br>de alocação e<br>mascaramento)|
|**Shimura et al.**<br>**2006**<sup>**117**</sup>|ECR|Verificar a eficácia da combinação TRI<br>+ FPR|10 pacientes (20 olhos) com RDNP grave ou<br>RDP sem alto risco e diabetes mellitus tipo 2|TRI 20 mg/0,5 mL|FPR|Alto<br>(Randomização, sigilo<br>de alocação e<br>mascaramento)|  
ECR: Ensaio Clínico Randomizado; Anti-VEGF: Agente anti-fator de crescimento do endotélio vascular; FPR: Fotocoagulaçãopan-retinal; VPP: vitrectomia via pars plana; RD: retinopatia diabética; RDP: Retinopatia diabética proliferativa; RDNP: Retinopatia diabética não proliferativa; RIV: ranibizumabe intravítreo; BIV: bevacizumabe intravítreo; TRI: triancinolonaacetonida; EMD: edema macular diabético; EMCS: edema macular clinicamente significante; OVCR: oclusão da veia central da retina.  
83  
**Tabela 31 –** Principais características basais dos ensaios clínicos randomizados incluídos para resposta da questão 5 do PCDT de Retinopatia Diabética em adultos  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**Intervenção**|**% sex masc.**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central**<br>**da retina (µm)**|**Seguimento**<br>**(meses, DP)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Beaulieu et al.**<br>**2016**<sup>**113**</sup><br>**(DRCR.net)**|102 participantes|114 participantes|Mediana de|44 anos|56%||8,50|NR|NR|24|
|**Gross et al.**<br>**2015**<sup>**111**</sup><br>**(DRCR.net)**|191 olhos (89<br>participantes com<br>dois olhos<br>envolvidos)|203 olhos (89<br>participantes com<br>dois olhos<br>envolvidos)|Mediana de 52<br>(44-59) anos|Mediana de<br>51 (44-59)<br>anos|57|55|**Mediana**<br>**(IQR):**<br>**RIV:**8,6<br>(7,5-10,4);<br>**FPR:**8,9<br>(7,5-10,4)|**Média (DP):**<br>**RIV:**75,0 (12,8);<br>Snellen aprox. 20/32<br>**FPR:**75,2 (12,5);<br>Snellen aprox. 20/32|**Média (DP):**<br>**RIV:**262 (109);<br>**FPR:**249 (86).|24|
|**Bhavsar et al.**<br>**2013**<sup>**197**</sup><br>**(DRCR.net)**|125 participantes|136 Participantes|60 (12)|57 (12)|48|49|**RIV:**7,8<br>(1,6);<br>**salina:**8,3<br>(1,7)|**RIV:**34 (29);<br>Snellen eq. 20/200;<br>**Salina:**32 (29);<br>Snellen eq. 20/250|NR|12|
|**Avitabile et al.**<br>**2011**<sup>**198**</sup>|90 participantes/<br>olhos|91 participantes<br>/olhos|54,2 (2|1-79)|97 (54%|)|NR|**Logmar Média**<br>**(DP):VPP:**1,13<br>(0,67);<br>**VPP (DRT):**1,17<br>(0,63)<br>**VPP (NDRT):**1,04<br>(0,78), p=0,42<br>**FPR:**1,14 (0,66);<br>**FPR (DRT):**1,20<br>(0,67);<br>**FPR (NDRT):**1,01<br>(0,63), p=0,21|NR|12|
|**Faghihi et al.**<br>**2008**<sup>**199**</sup>|38<br>pacientes/olhos|34 pacientes/olhos|55,2 (9,1)|54,5 (10,9)|37%|32%|NR|**TRI + VPP:**2,4<br>(0,29);<br>**VPP:**2,4 (0,24);|NR|6|  
84  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**Intervenção**|**% sex masc.**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central**<br>**da retina (µm)**|**Seguimento**<br>**(meses, DP)**|
|---|---|---|---|---|---|---|---|---|---|---|
||||<br>**Estudos inc**|<br>**luídos na revisão**|**sistemática sem m**|**eta-análise de Ro**|**yle et al. 2015**<sup>**194**</sup><br>**SS-PRP:**82|<br>**SS-PRP:**77 letras|||
|**Muquit et al.**<br>**2010**<sup>**200**</sup>|20 olhos|20 olhos|46 (29-60)|44 (29-60)|68|63|,<br>(1,2);<br>**MS-PRP:**7,6<br>(1,5). p=0,17|<br>(9,9);<br>**MS-PRP:**79 (7,9),<br>p=0,57|**SS-PRP:**240;<br>**MS-PRP:**242,<br>p=NR|3-5|
|**Muqit et al.**<br>**2013**<sup>**201**</sup>|10 olhos|20 olhos (10 para<br>cada comparador)|45 (11,2)|**MT-FPR:**47<br>(15,9);<br>**SI-FPR:**42<br>(8,8)|80|**MT-FPR:**<br>60;<br>**SI-FPR:**80.|**FRD:**8,6<br>(1,2);<br>**MT-FPR:**8,4<br>(1,1);<br>**SI-FPR:**8,6<br>(1,5).|NR|**FRD**: 264 (29,2);<br>**MT-FPR:**255<br>(35,5);<br>**SI-FPR:**267 (23,7)|3|
|**Muraly et al.**<br>**2011**<sup>**202**</sup>|50 olhos|50 olhos|Homens: 58<br>Mulheres: 55|,24 (32-68);<br>,75 (33-70).|68 (n|=34)|NR|NR|NR|6|
|**Nagpal et al.**<br>**2010**<sup>**203**</sup>|60 olhos|60 olhos|52 (4|5-61)|34 (56|,7%)|NR|**Pascal:**6/10,8<br>**GLX:**6/10,3|NR|6|
|**Salman, 2011**<sup>**204**</sup>|60 olhos|60 olhos|48,9|(9,3)|72 (6|0%)|NR|**A1:**0,30 (0,24)<br>Snellen: 6/12<br>**A2:**0,30 (0,24)<br>Snellen: 6/12<br>**B1:**0,31 (0,23)<br>Snellen: 6/12<br>**B2:**0,6 (0,61)<br>Snellen: 6/24|NR|Média 9-10,8<br>semanas|
|**Al-Hussainy et**<br>**al. 2008**<sup>**205**</sup>|20 olhos|20 olhos|62 (2|6-76)|NR|NR|NR|NR|NR|6-45|  
85  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**Intervenção**<br>|**% sex masc.**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central**<br>**da retina (µm)**|**Seguimento**<br>**(meses, DP)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Bandello et al.**<br>**2001**<sup>**206**</sup>|26 participantes|24 participantes|48 (11)|57 (13)|61|62|NR|**MAVC:**<br>**Leve:**0,12 (0,13)<br>**Conv.:**0,14 (0,15),<br>p=0,320|NR|**Leve:**22,4 (9,7)<br>**Conv.:**21,6 (9,3)|
|**Sato et al.**<br>**2012**<sup>**100**</sup>|32 participantes|37 participantes|60,8 (8,1)|59,3 (10,9)|69|81|**FPR:**7,5<br>(1,7);<br>**Sem FPR**:<br>7,7 (1,5),<br>p=0,64|**FPR:**0,03 (0,22);<br>**Sem FPR:**0,02<br>(0,12), p=0,75|NR|FPR: 6-60 média<br>34,3 (18);<br>Sem FPR: 6-58,<br>média 30,1<br>(16,3).|
|**Mirshahi et al.**<br>**2013**<sup>**207**</sup>|33 olhos|33 olhos|58,9 (7,|8)|52||8,23 (1,18)|**100 ms:**0,40<br>90,24);<br>**20 ms:**0,37 (0,27),<br>p=0,718|**100 ms:**255 (33,7);<br>**20 ms:**266 (33,8),<br>p=0,334|6|
|**Shimura et al.**<br>**2003**<sup>**208**</sup>|36 olhos|36 olhos|55,6 (7,|8)|21 (58%|)|8,72 (1,35)|**Semanal:**191 (9,9);<br>**2 semanas**: 191<br>(10,7), p=0,814|NR|4|
|**Suto et al.**<br>**2008**<sup>**209**</sup>|29 olhos|29 olhos|66 (7,5|)|9/29 (31|%)|7,4 (1,0)|NR|NR|3|
|**Tewari et al.**<br>**2000**<sup>**196**</sup>|25 olhos|25 olhos|56,25 (8|,2)|NR|NR|NR|**Diodo:**3,22 (2,05)<br>**Argônio:**4,16<br>(2,77)|NR|6|
|**Unoki et al.**<br>**2009**<sup>**118**</sup>|41 olhos|41 olhos|60,1 (11|,5)|56||8,2 (2,1)|**TRI:**0,14 (0,33);<br>**Controle:**0,13<br>(0,33); p=0,90|**TRI:**290,2 (135,7);<br>**Controle:**269,0<br>(114,9), p=0,45|6|  
86  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**Intervenção**|**% sex masc.**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central**<br>**da retina (µm)**|**Seguimento**<br>**(meses, DP)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Cho et al.**<br>**2010***<sup>**116**</sup>|**TRI+FPR**: 30<br>(14 sem edema)<br>**BIV+FPR**: 31<br>(15 sem edema)|30 (16 sem<br>edema)|**TRI+FPR**: 52,0<br>(13,2);<br>**BIV+FPR**: 50,5<br>(10,1)|50,9 (19,3)|**TRI+FPR**: NR;<br>**BIV+FPR:**<br>28,57|33,33|**TRI+FPR**:7,<br>12 (0,13);<br>**BIV+FPR**:<br>7,21 (0,23);<br>**FPR**: 7,18<br>(0,09)|**TRI+FPR**: 0,20<br>(0,15);<br>**BIV+FPR**: 0,22<br>(0,28);<br>**FPR**: 0,19 (0,21)|**TRI+FPR**: 207,20<br>(30,77);<br>**BIV+FPR**: 205,15<br>(25,30)<br>**FPR**: 209,75 (38,85)|3|
|**Shimura et al.**<br>**2006**<sup>**117**</sup>|10 olhos|10 olhos|63 (8,1|9)|50||7,34 (0,76)|**TRI+FPR**: 0,02<br>(0,042)<br>**FPR:**0,07 (0,079)|**TRI+FPR**: 204,4<br>(21,9)<br>**FPR**: 234,4 (40,2)|6|  
DRT: descolamento retinaltracional; NRDT: Ausência de DRT; *resultados descritos apenas para pacientes sem EMCS (edema macular clinicamente significante); DP: desvio padrão; IQR: intervalo inter-quartil; HbA1c: hemoglobina glicada; Masc.: masculino; Conv.: convencional; NR: Não relatado;NA: Não se aplica; RIV: ranibizumabe intravítreo; BIV: bevacizumabe intravítreo; TRI: triancinolona acetonida;FPR: Fotocoagulaçãopanretinal;SS-PRP:Fotocoagulaçãopan-retinal em única sessão; MS-PRP: fotocoagulaçãopan-retinal em Múltiplas sessões; MAVC: melhor acuidade visual ajustada.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1. Resultados de eficácia em estudos que avaliaram a comparação entre os diversos ANTI-VEGF** **_versus_ FOTOCOAGULAÇÃO PAN-RETINAL (FPR)** -->
**Tabela 32 –** Resultados de eficácia em estudos que avaliaram a comparação anti-VEGF x fotocoagulação pan-retinal  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP)**|**Espessura macular**|**Hemorragia vítrea ou**<br>**pré-retinal**|**NEI VFQ-25**|**UAB-LLQ**|**WPAIQ**|
|---|---|---|---|---|---|---|---|
|**Simunovic**<br>**et al.**<br>**2015**<sup>**102**</sup>|RIV + FPR vs.<br>FPR|**DM**= 0,1 Logmar (95% IC, 0,04-0,16),<br>p<0,002; I2=0% (favorece RIV + FPR)|**DM**= 36,86 µm (IC 95%,<br>7,85-65,86), p=0,01; I2 =<br>NR (favorece RIV + FPR)|NA|NA|NA|NA|  
87  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP)**|**Espessura macular**|**Hemorragia vítrea ou**<br>**pré-retinal**|**NEI VFQ-25**|**UAB-LLQ**|**WPAIQ**|
|---|---|---|---|---|---|---|---|
||Pegaptanibe vs.<br>FPR|**DM**: -0,06 Logmar (IC95%, -0,22; 0,10);<br>NS|NA|**RR**: 0,20 (IC95%, 0,01;<br>3,70); NS|NA|NA|NA|
||BIV vs. FPR|**DM:**-0,01 Logmar (IC95%, -0,11; 0,09);<br>NS|NA|**RR**: 0,11 (95%IC, 0,01;<br>1,92); NS|NA|NA|NA|
|**Martinez-**<br>**zapata et al.**<br>**2014**<sup>**101**</sup>|RIV vs. FPR|**DM**: -0,10 Logmar (IC95%, -0,16; -0,03);<br>p=0,026 (favorece RIV); I2=2%|NA|**RR**: 0,38 (IC95%, 0,18;<br>0,81); p=0,0013<br>(favorece RIV)|NA|NA|NA|
||Anti-VEGF vs.<br>FPR|**DM**: -0,07 Logmar (IC95% -0,12; -0,02),<br>p=0,0045 (favorece anti-VEGF); I2=0%|NA|**RR**: 0,32 (IC95%, 0,16;<br>0,65), p=0,0017<br>(favorece Anti-VEGF);<br>I2=0%|NA|NA|NA|
|**Beaulieu et**<br>**al. 2016**<sup>**113**</sup><br>**(DRCR.net)**|RIV vs. FPR|**Diferença RIV x FPR em 1 ano:**8,7<br>(IC95%, +5,3; 12,1); p= 0,001<br>**Diferença RIV x FPR em 2 anos:**+3,9<br>(IC95%, -0,0;7,9); p=0,05<br>**Diferença RIV x FPR AUC em 2 anos**<br>**(em relação a basal):**+6,2 (IC95%, 3,9;<br>8,4) p<0,001<br>**RR 20/40 único olho:**1,1 (95%IC: 1,0;<br>1,2)P=0,005.RR 20/40 binocular: 1,1<br>(95%IC: 1,0; 1,3) P=0,020.|NR|NR|**Diferença RIV x**<br>**FPR 1 ano:**(+4,0,<br>95% IC: -0,2,<br>8,3); P=0,06;<br>**Diferença RIV x**<br>**FPR 2 anos:**+2,9<br>(95%IC, -1,5;<br>+7,2); P=0,20;<br>**Diferença RIV x**<br>**FPR AUC em 2**<br>**anos (em relação**<br>**basal):**+3,1<br>(95%IC, +0,0;<br>+6,2;P=0,050.|**Diferença RIV x FPR**<br>**1 ano:**+1,8 (95%IC: -<br>3,5; +7,1); P=0,51);<br>**Diferença RIV x FPR**<br>**2 anos:**+2,3 (95%IC:<br>-2,9; +7,5, P=0,37);<br>**Diferença RIV x FPR**<br>**em 2 anos AUC (em**<br>**relação a basal)**: +1,2<br>(95%IC, -2,5; +4,9)<br>P=0,53).|**Escore de perda de**<br>**produtividade no trabalho,**<br>**RIV x FPR em 1 ano:**-15,6%<br>(99%IC: -29,8%; -1,3%),<br>P=0,005;<br>**Escore de perda de**<br>**produtividade no trabalho,**<br>**RIV x FPR em 2 anos:**-2,9%<br>(99%IC: -15,2%; +9,5%)<br>P=0,54;<br>**Escore de perda de**<br>**produtividade no trabalho,**<br>**RIV x FPR em 2 anos**|  
88  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP)**|**Espessura macular**|**Hemorragia vítrea ou**<br>**pré-retinal**|**NEI VFQ-25**|**UAB-LLQ**|**WPAIQ**|
|---|---|---|---|---|---|---|---|
||||||||**(AUC):**-10,3% (95%IC: -<br>16,6%; -4,0%) P=0,002|
||RIV (160 olhos)|**Em 2 anos**: 78,7 (16,3);<br>**Δ 2 anos-basal**: 2.8 (IC95%: 0,4; 5,2)<br>**AUC (IC95%) 2 anos**: 4,5 (3,4; 5,5)|**Média (IC95%) em 2**<br>**anos:**210 (201; 218);<br>**Δ 2 anos-basal:**−47 (−61;<br>−33)|52 (27%)|NA|NA|NA|
|**Gross et al.**<br>**2015**<sup>**111**</sup><br>**(DRCR.net)**|FPR (168<br>olhos)|**Em 2 anos:**76,2 (14,1);<br>**Δ 2 anos-basal:**0.2 (IC95%: −1,9; 2,3)<br>**AUC (IC95%) 2 anos**: −0,3 (−1,5; 1,0)|**Média (IC95%) em 2**<br>**anos:**243 (231; 255);<br>**Δ 2 anos-basal**: −3 (−15; 9)|69 (34)|NA|NA|NA|
||RIV - FPR<br>ajustada (ITT)|**Δ 2 anos**: +2,2 (IC95%−0,5; 5,0); p=0,11<br>**AUC (IC95%):**+4,2 (3,0 to 5,4), p<0,001|**Δ 2 anos:**−45 (−57; −33),<br>p<0,001|−7 (−15; 1), p=0,09|NA|NA|NA|  
RIV: Ranibizumabe intravítreo; DM: diferença de média; FPR: fotocoagulaçãopan-retinal (laser); NS: não significante; AUC: Área sob a curva; ITT: _intention-to-treat;_ NEI VFQ-25: _NationalEyeInstitute Visual Function Questionnaire-25;_ UAB-LLQ: _Universityof Alabama LowLuminanceQuestionnaire;_ WPAIQ: _Work Productivity andActivityImpairmentQuestionnaire;_ I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2. Resultados de eficácia em estudos que avaliaram a comparação entre os diversos ANTI-VEGF** **_versus_ VITRECTOMIA VIA PARS PLANA (VPP)** -->
**Tabela 33 –** Resultados de eficácia em estudos que avaliaram a comparação anti-VEGF _versus_ vitrectomia via pars plana  
|**Autor, ano**|**Grupo**|**Duração da cirurgia**|**Número de paradas**<br>**no intraoperatório**|**Sangramento**<br>**intraoperatório**<br>**(hemorragia**<br>**intravítreo)**|**Aplicação**<br>**endodiatermia**|**Hemorragia**<br>**intravítreo precoce**<br>**(pós-cirurgia)**|**Perda ≥ 3 Linhas**<br>**(ETDRS**<br>**acuidade visual)**|**Ganho ≥ 3 Linhas**<br>**(ETDRS acuidade**<br>**visual)**|**Acuidade**<br>**visual**<br>**(Logmar)**|
|---|---|---|---|---|---|---|---|---|---|  
89  
|**Simunovic et**<br>**al. 2015**<sup>**102**</sup>|BIV +<br>VPP<br>vs.<br>VPP|**DM**: -26,05 min (95% IC,<br>-33,34; -18,77), p<0,001);<br>**I2**=50% (favorece BIV +<br>VPP)|**OR:**0,35 (95%IC,<br>0,16-0,79), p=0,01;<br>**I2**= 2% (Favorece<br>BIV + VPP)|**OR:**0,06 (IC95%,<br>0,01-0,30), p=0,0007;<br>**I2**=NR (Favorece BIV<br>+ VPP)|**MD**: -2,87 (95%IC,<br>-5,42; -0,33),<br>p=0,03;**I2**= NR<br>(favorece BIV +<br>VPP)|**OR:**0,34 (IC95%<br>0,18-0,67), p=0,002;<br>**I2**= 0% (Favorece BIV<br>+ VPP)|NA|NA|NA|
|---|---|---|---|---|---|---|---|---|---|
|**Martinez-**<br>**zapata et al.**<br>**2014**<sup>**101**</sup>|BIV +<br>VPP<br>vs.<br>VPP|NA|NA|**RR:**0,30 (IC95%,<br>0,18; 0,52); p<0,001;<br>**I2**=47%(favorece BIV<br>+ VPP)|NA|NA|**RR:**0,49 (IC95%,<br>0,08; 3,14); NS;<br>**I2**=0%|**RR:**1,62 (IC95%,<br>1,20; 2,17) (favorece<br>VPP);**I2**=73%|**DM:**-0,24<br>(IC95%, -0,50;<br>0,01) NS;<br>**I2**=67%|  
BIV: bevacizumabe intravítreo; VPP: vitrectomia via pars plana; DM: diferença de média; NR: não relatado; OR: Oddsratio ou razão de chances; RR: risco relativo; NA: não se aplica; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.  
90  
**3. Resultados de eficácia em estudos que avaliaram a comparação entre RANIBIZUMABE INTRAVÍTREO** **_versus_ SALINA**  
**Tabela 34 –** Resultados de eficácia em estudos que avaliaram a comparação anti-VEGF x salina  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP),**<br>**escore de letras**|**Valor p (RIV x Salina)**|
|---|---|---|---|
|**Bhavsar et al. 2013**|IVR|**4 semanas:**45 (30), Snellen eq.<br>20/125<br>**8 semanas**: 51 (30), Snellen eq:<br>20/100;<br>**12 semanas**: 57 (27), Snellen eq.<br>20/80|0,67 (4 semanas)<br>0,14 (8 semanas)<br>0,04 (12 semanas)|
|**(DRCR.net)**<sup>**197**</sup>|Salina|**4 semanas**: 42 (31), Snellen eq.<br>20/160;<br>**8 semanas**: 47 (31), Snellen eq.<br>20/125;<br>**12 semanas**: 49 (29), Snellen eq.<br>20/100||  
IVR: ranibizumabe intravítreo; DP: desvio padrão.  
**4. Resultados de eficácia em estudos que avaliaram a comparação entre TRIANCINOLONA ACETONIDA INTRAVÍTREO (TRI) associada à FOTOCOAGULAÇÃO PAN-RETINAL** **_versus_ FOTOCOAGULAÇÃO PAN-RETINAL (FPR)**  
**Tabela 35 –** Resultados de eficácia em estudos que avaliaram a comparação TRI + FPR versus FPR  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP), Logmar**|**Espessura macular, µm (DP)**|
|---|---|---|---|
|||**Δ 6 meses - basal:**+0,072|**Δ 6 meses - basal:**-9,7 (85,6)|
|**Unoki et al.**<br>|TRI+FPR|(0,028); p=0,04 em relação ao controle.<br>**Sem EMCS:**+0,04 (0,13);<br>**Com EMCS:**+0,12 (0,22)|**Sem EMCS:**+9,7 (85,6)<br>**Com EMCS:**-42,7 (132,4)|
|**2009**<sup>**118**</sup>||**Δ 6 meses - basal:**-0,010 (0,029);|**Δ 6 meses - basal:**+32,8 (82,8);|
||FPR|**Sem EMCS**: -0,020 (0,12)|**Sem EMCS:**+34,9 (56,5)|
|||**Com EMCS**: -0,00 (0,25)|**Com EMCS:**+29,5 (114,4)|
|**Shimura et al.**<br>**2006**<sup>**117**</sup>|TRI+FPR (24<br>sem.)|0,085 (0,106) p=0,0063 em relação ao controle|235,3 (38,6), p=0,0063 em relação ao controle|
||FPR (24 sem.)|0,24 (0,133)|312 (68,2)|  
TRI: triancinolona acetonida; FPR: fotocoagulaçãopan-retinal; DP: desvio padrão; EMCS: Edema macular clinicamente significante.  
**5. Resultados de eficácia em estudos que avaliaram a comparação entre TRIANCINOLONA ACETONIDA INTRAVÍTREO (TRI) associada à VITRECTOMIA VIA PARS PLANA** **_versus_ VITRECTOMIA VIA PARS PLANA (VPP)**  
**Tabela 36 –** Resultados de eficácia em estudos que avaliaram a comparação TRI + VPP _versus_ VPP  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP), Logmar**|
|---|---|---|
||TRI+VPP (6 meses)|**Em 6 meses:**0,63 (0,23)<br>**Δ (6 me. - basal) TRI + VPP:**1,77 (0,38);|
|**Faghihi et al. 2008**<sup>**199**</sup>|VPP (6 meses)|**Em 6 meses:**0,87 (0,24)<br>**Δ (6 me. - basal) VPP**: 1,56 (0,29);|
||TRI+VPP vs. VPP (6 meses)|Sem informação de valores:<br>**Em 6 meses:**p<0,001 (em seis meses)<br>**Δ (6 me.-basal) TRI+ VPP vs. VPP**p= 0,012|  
TRI: triancinolonaacetonida; VPP: vitrectomiapars plana; Δ: diferença.  
91  
**6. Resultados de eficácia em estudos que avaliaram a comparação entre TRIANCINOLONA ACETONIDA INTRAVÍTREO (TRI) associada à FOTOCOAGULAÇÃO PAN-RETINAL (FPR)** **_versus_ BEVACIZUMABE INTRAVÍTREO (BIV) associado à FOTOCOAGULAÇÃO PAN-RETINAL versusFOTOCOAGULAÇÃO PAN-RETINAL (controle)**  
**Tabela 37 –** Resultados de eficácia em estudos que avaliaram a comparação TRI+FPR vs. BIV+FPR vs. FPR  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP), Logmar**|**Espessura macular, µm (DP)**|
|---|---|---|---|
||TRI+FPR|**Δ 3meses - basal:**NS (valor ausente)|**Δ 3meses - basal:**NS (valor ausente)|
|**Cho et al.**<br>**2010***<sup>**116**</sup>|BIV+FPR|**Δ 3meses - basal:**NS (valor ausente)|**Δ 3meses - basal:**NS (valor ausente)|
||FPR|Piora significativa (p<0,05) (valor ausente)|Aumento de 209,75 (27,47) para 259,00 (58,28) p=0,011|  
Resultados apenas para pacientes sem EMCS (edema macular clinicamente significante; BIV: bevacizumabe intravítreo; TRI: triancinolonaacetonida; FPR: fotocoagulaçãopan-retinal; DP: desvio padrão; NS; não significante.  
**7. Resultados de eficácia em estudos que avaliaram a comparação entre VITRECTOMIA VIA PARS PLANA (VPP)** **_versus_ FOTOCOAGULAÇÃO PAN-RETINAL (FPR)**  
**Tabela 38 –** Resultados de eficácia em estudos que avaliaram a comparação VPP vs. FPR  
|**Autor, ano**|**Grupo**|**Acuidade visual, média (DP),**<br>**Logmar**|**Taxa de melhora, n (%)**|
|---|---|---|---|
|||1,04 (0,59), p=0,23 (vs. Basal);||
||VPP (12 meses)|**VPP (DRT):**1,14 (0,62);<br>**VPP (NDRT):**0,80 (0,41),<br>p=0,004|30 (33%)|
|**Avitabile et al. 2011**<sup>**198**</sup>|FPR (12 meses)|0,96 (0,47), p=0,01 (vs. basal);<br>**FPR (DRT):**1,01 (0,54);<br>**FPR (NDRT)**: 0,85 (0,53), p=0,12|32 (35%)|
||VPP x FPR (12 meses)|p=0,33 (após 12 meses)|p=0,75(após 12 meses)|  
VPP: vitrectomiapars plana; FPR: fotocoagulaçãopan-retinal; DRT: Descolamento retinaltracional; NDRT: descolamento não DR; DP: desvio padrãp.  
92

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **8. Resultados de eficácia em estudos que avaliaram a comparação entre os DIFERENTES TIPOS DE TERAPIA A LASER** -->
**Tabela 39 –** Resultados de eficácia em estudos que avaliaram a comparação entre diferentes tipos de laser  
|**Autor, Ano**|**Grupo**|**Acuidade visual (AV),**<br>**média (DP)**|**Valor p**|**Espessura do centro da**<br>**retina (µm), média (DP)**<br>**IC 95%**|**Valor p**|**% de regressão da RD**|**Valor p**|**Dor, Escala**<br>**visual analógica**<br>**(DP)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|**Muquit et al.**<br>**2010**<sup>**200**</sup>|SS-PRP (4 meses)<br>MS-PRP (4<br>meses)<br>SS-PRP (12<br>meses)|+2 letras (9,3)<br>+1 letra (18,9)<br>+4 letras (6,0)|NR<br>NR<br>0,25|+2 (9,4) [-6,37; 2,68]*<br>+22 (21,6) [-32,25; -10,75]*<br>+2 (9,5) [-2,86; 6,33]*|0,4<br><0,001<br>NR|NA<br>NA<br>NA|NA|NR|NR|
||MS-PRP (12<br>meses)|NR|NR|+20 (18,6) [-28,75; -10,82]*|<0,001|NA||||
||SS-PRP (18<br>meses)|NA|NA|NA|NA|RDP leve: 75;<br>RDP moderada: 67;<br>RDP grave: 43.||||  
93  
|**Autor, Ano**|**Grupo**|**Acuidade visual (AV),**<br>**média (DP)**|**Valor p**|**Espessura do centro da**<br>**retina (µm), média (DP)**<br>**IC 95%**|**Valor p**|**% de regressão da RD**|**Valor p**|**Dor, Escala**<br>**visual analógica**<br>**(DP)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|**Muqit et al.**<br>**2013**<sup>**201**</sup>|FDR (4 semanas)<br>MT-FPR (4<br>semanas)<br>SI-FPR (4<br>semanas) **<br>FDR (12 semanas)<br>MT-FPR (12<br>semanas)<br>SI-FPR (12<br>semanas)|FDR vs. MT-FPR (12<br>semanas): 1,3 letras (11) [-<br>6,55; 9,15];<br>FDR vs. SI-FPR (12<br>semanas): 0,7 letras (8,4) [-<br>5,33; 6,73];<br>MT-FPR vs. SI-FPR (12<br>semanas): 0,6 letras (7,2) [-<br>4,53; 5,73].|0,717<br>0,799<br>0,797|Redução 10,3 (7,5) [4,97;<br>15,63]<br>Redução 16,8 (9,9) [9,74;<br>23,86]<br>Aumento 0,8 (14,3) [-9,41;<br>11]<br>Redução 9,6 (10,8) [1,84;<br>17,36]<br>Redução 17,1 (8,5) [11;<br>23,2]<br>Aumento 5,9 (17,7) [-6,75;<br>18,55]|0,02<br><0,001<br>0,86<br>0,021<br><0,001<br>0,32|FDR: 70% de resposta<br>positiva (60% regressão<br>parcial; 10% regressão<br>total e 30% sem<br>alteração);<br>MT-FPR: 70% de<br>resposta positiva (50%<br>regressão parcial; 20%<br>regressão total e 20%<br>sem alteração)<br>;<br>SI-FPR: 90% de<br>resposta positiva (70 %<br>regressão parcial; 20%<br>regressão total e 10%<br>sem alteração)|NR|1) FDR (12<br>semanas): 15,7<br>(23,7);<br>2) MT-FPR (12<br>semanas): 3,5<br>(7,8);<br>3) SI-FPR (12<br>semanas): 32,4<br>(24,2).|0,10<sup>(1x2)</sup><br>0,07<sup>(2x3)</sup><br>0,005<sup>(1x3</sup>|
|**Muraly et al.**<br>**2011**<sup>**202**</sup>|1) laser PASCAL<br>2) laser<br>convencional|NR|NR|NR|NR|1º mês:<br>Regressão NVE e NVD:<br>45 (90);<br>6º mês:<br>Regressão NVE e NVD:<br>49 (98).<br>1º mês:<br>Regressão NVE e NVD:<br>32 (64);<br>6º mês:<br>Regressão NVE e NVD:<br>44 (88).|Mês 1:<br><0,001<sup>(1x2)</sup><br>Mês 6:<br><0,001<sup>(1x2)</sup>|NR|NR|
|**Nagpal et al.**<br>**2010**<sup>**203**</sup>|1) PASCAL|6/9,3 Snellen|0,508<sup>1x2</sup>|NR|NR|NR|NR|0,33 (0-1)|0,007<sup>1x2</sup>|  
94  
|**Autor, Ano**|**Grupo**|**Acuidade visual (AV),**<br>**média (DP)**|**Valor p**|**Espessura do centro da**<br>**retina (µm), média (DP)**<br>**IC 95%**|**Valor p**|**% de regressão da RD**|**Valor p**|**Dor, Escala**<br>**visual analógica**<br>**(DP)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||2) GLX|6/9,34 Snellen||||||4,6 (3-9)||
|**Salman,**<br>**2011**<sup>**204**</sup>|1) Convencional<br>2) PASCAL|A1: 0,22 (0,24)<br>Snellen: 6/9<br>B1: 0,30 (0,27)<br>Snellen: 6/12<br>A2: 0,30 (0,24)<br>Snellen: 6/12<br>B2: 0,53 (0,61)<br>Snellen: 6/18|0,347 (pré vs.<br>pós<br>procedimento)|NR|NR|A1: 27/30 (90%)<br>B1: 20/30 (66,7%)<br>A2: 28/30 (93,3%)<br>B2: 28/30 (93,3%)|NR<sup>A1xA2</sup><br><0,05<sup>B1xB2</sup>|NR|NR|
|**Al-Hussainy**<br>**et al. 2008**<sup>**205**</sup>|1) Laser<br>exposição curta<br>2) Laser<br>convencional|NR|NR|NR|NR|Regressão de NVE ou<br>NVD: 18/20 (90%)|NR|1,405 (0,951)<br>5,11 (2,861)|<0,001<sup>1x2</sup>|
|**Bandello et**<br>**al. 2001**<sup>**206**</sup>|1) Laser leve|MAVC: 0,18 (0,25)|0,231<sup>1x2</sup>|NR|NR|91%|0,615<sup>1x2</sup>|NR|NR|
||2) Laser<br>convencional|MAVC: 0,27 (0,30)||||97%||||  
95  
|**Autor, Ano**|**Grupo**|**Acuidade visual (AV),**<br>**média (DP)**|**Valor p**|**Espessura do centro da**<br>**retina (µm), média (DP)**<br>**IC 95%**|**Valor p**|**% de regressão da RD**|**Valor p**|**Dor, Escala**<br>**visual analógica**<br>**(DP)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|**Sato et al.**<br>**2012**<sup>**100**</sup>|1) FPR<br>2) Sem FPR|**Em 36 meses:**0,14 (0,33)<br>**Δ 36 meses vs. basal:**0,11<br>(0,27)<br>**Redução ≥ 0,2**: 23%<br>**Em 36 meses:**0,12 (0,43)<br>**Δ 36 meses vs. basal:**0,11<br>(0,47)<br>**Redução ≥ 0,2:**9%|0,86<sup>1x2</sup><br>0,97<sup>1x2</sup><br>0,24<sup>1x2</sup>|NR|NR|NR|NR|NR|NR|
|**Mirshahi et**<br>**al. 2013**<sup>**207**</sup>|1) Conv (100 ms)<br>2) Curto (20 ms)|0,44 (0,28)<br>0,32 (0,22)|0,144<sup>1x2</sup>|1º semana: 293 (43);<br>1º mês: 308 (43);<br>4º mês: 306 (53);<br>Δ basal vs. 1 sem.: 37,9<br>Δ basal vs. 1 mês: 53,0<br>Δ basal vs. 4 meses: 50,8<br>1º semana: 274 (52);<br>1º mês: 279 (53);<br>4º mês: 275 (57):<br>Δ basal vs. 1 sem.: 8,7;<br>Δ basal vs. 1 mês: 13,0;<br>Δ basal vs. 4 meses: 9,1.|0,226<sup>1x2</sup><br>0,064<sup>1x2</sup><br>0,080<sup>1x2</sup><br>0,008<sup>1x2</sup><br>0,001<sup>1x2</sup><br>0,007<sup>1x2</sup>|Medido como eficácia<br>do tratamento: 89,7%<br>Medido como eficácia<br>do tratamento: 90,9%|0,66<sup>1x2</sup>|7,5 (1,14)<br>1,75 (0,87)|<0,001<sup>1x2</sup>|
||1) FPR semanal|Manutenção da AV: 89%;||220 (8,5)|16 semanas vs. basal:<br>0,012|||||
|**Shimura et**<br>**al. 2003**<sup>**208**</sup>|2) FPR 2 semanas|Manutenção da AV: 92;|NR|201 (5,7)|16 semanas vs. basal:<br>0,121<br>0,032<sup>1x2</sup>|||||  
96  
|**Autor, Ano**|**Grupo**|**Acuidade visual (AV),**<br>**média (DP)**|**Valor p**|**Espessura do centro da**<br>**retina (µm), média (DP)**<br>**IC 95%**|**Valor p**|**% de regressão da RD**|**Valor p**|**Dor, Escala**<br>**visual analógica**<br>**(DP)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||**MAVC 20/40 ou melhor**||||||||
||1) FPR 1º|**(%):**<br>20 (69)<br>**RR:**NR||NR|NR|NR|NR|NR|NR|
|**Suto et al.**<br>**2008**<sup>**209**</sup>|2) Cirurgia 1º|**MAVC 20/40 ou melhor**<br>**(%):**<br>28 (96,6);<br>**RR de melhora de 20/40**<br>**ou mais (IC 95%):**<br>5,83 (5,58-6,08)|0,012<sup>1x2</sup>|||||||
||1) Laser Diodo|**Após 6 semanas:**<br>4,56 (2,56)<br>**após 6 meses:**||NR|NR|16 (64%)||NR|NR|
|**Tewari et al.**<br>**2000**<sup>**196**</sup>|2) Laser argônio|3,62 (2,12)<br>**Após 6 semanas:**<br>5,04 (3,03)<br>**após 6 meses:**<br>4,76 (2,83)|NS<sup>1x2φ</sup>|||18 (7,2%)|NS<sup>1x2φ</sup>|||  
SS-PRP: _single sessionpan-retinalphotocoagulation_ (única sessão); MS-PRP: _Multi-sessionPan-retinalPhotocoagulation_ (Multiplas sessões); *Resultados apresentam intervalos de confiança que não compreendem a média fornecida; RDP: Retinopatia diabética proliferativa; FPR: FotocoagulaçãoPan-retinal; FRD: fotocoagulaçãoretinal direcionada; MT-FPR minimamente traumática; SI-FPR de intensidade padrão; ** Apenas houve diferença significativa em Espessura do centro da retina entre os tratamentos MT-FPR e SI-FPR em 4 semanas (p=0,012), para as demais comparações não houve diferença significativa; NVE: novos vasos em qualquer lugar; NVD: novos vasos no disco; NA: não se aplica; NR: Não relatado; IC 95%: intervalo de confiança 95%; DP: desvio padrão; RR: risco relativo; Valores p sem a indicação das comparações se referem ao valor final pós-seguimento vs. período basal do estudo;<sup>φ</sup> Reportada diferença não estatisticamente significante, porém sem o valor da estatística p.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **9. RESULTADOS DE SEGURANÇA** -->
A **Tabela 40** exibe os principais resultados eventos adversos relatados nos estudos incluídos.  
97  
**Tabela 40 –** Principais eventos adversos relatados nos estudos incluídos  
|||||||||**Autor, A**|**no**||||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**Martinez-Z**<br>**201**|**apata et al.**<br>**4**<sup>**101**</sup>|**Gr**|**oss et al.**|**2015**<sup>**111**</sup>|**Avita**|**bile et al.**|**2011**<sup>**198**</sup>|**Faghih**|**i et al. 20**|**08**<sup>**199**</sup>|**Bhavs**<br>**201**|**ar et al.**<br>**3**<sup>**197**</sup>|**C**|**ho et al. 2010***<sup>**1**</sup>|<sup>**16**</sup>|
|**Evento adverso**|**Anti-VEGF**<br>**vs. FPR**|**BIV vs. VPP**|**RIV**|**FPR**|**Δ RIV -**<br>**FPR**|**PPV**<br>**(%)**|**FPR**<br>**(%)**|**Valor p**<br>**VPP x**<br>**FPR (12**<br>**meses)**|**TRI +**<br>**VPP**|**VPP**|**Valor**<br>**p**|**RIV**|**Salina**|**TRI+FPR**|**BIV+FPR**|**FPR**|
|||||||**Eventos**|**adversos**|**Oculares**|||||||||
|**Glaucoma Neovascular,**<br>**n (%)**|RR: 1,09<br>(IC95%, 0,07;<br>17,21); NS|RR: 2,33<br>(IC95%,<br>0,28; 19,17);<br>NS|3 (2)|6 (3)|−1 (−4; 2),<br>p=0,50|10|5,6|NR|NR|NR|NA|1 (<1)|1 (<1)|NR|NR|NA|
|**Atrofia ótica, n (%)**|NR|NR|NR|NR|NA|10|1,1|0,009|NR|NR|NA|NR|NR|NR|NR|NR|
|**Síndrome fibrinóide, n**<br>**(%)**|NR|NR|NR|NR|NA|4,4|0|0,04|NR|NR|NA|NR|NR|NR|NR|NR|
|**Hemorragia vitrea, n**<br>**(%)**|NR|NR|NR|NR|NA|20|15,6|NA|5 (13)|15<br>(45,5)|0,003|8 (6)|23 (17)|NR|NR|NR|
|**Neovascularização da**<br>**Iris, n (%)**|NR|NR|2 (1)|2 (1)|0 (−2; 2),<br>p=0,96|NR|NR|NA|NR|NR|NA|1 (<1)|4 (3)|NR|NR|NR|  
98  
||**Martinez-Z**<br>**201**|**apata et al.**<br>**4**<sup>**101**</sup>|**Gr**|**oss et al.**|**2015**<sup>**111**</sup>|**Avita**|**bile et al.**|**Autor, An**<br>**2011**<sup>**198**</sup>|**o**<br>**Faghih**|**i et al. 20**|**08**<sup>**199**</sup>|**Bhavsa**<br>**201**|**r et al.**<br>**3**<sup>**197**</sup>|**C**|**ho et al. 2010***<sup>**1**</sup>|<sup>**16**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**||||||||**Valor p**|||||||||
||**Anti-VEGF**<br>**vs. FPR**|**BIV vs. VPP**|**RIV**|**FPR**|**Δ RIV -**<br>**FPR**|**PPV**<br>**(%)**|**FPR**<br>**(%)**|**VPP x**<br>**FPR (12**<br>**meses)**|**TRI +**<br>**VPP**|**VPP**|**Valor**<br>**p**|**RIV**|**Salina**|**TRI+FPR**|**BIV+FPR**|**FPR**|
|**Descolamento retina**|RR: 0,99<br>(IC95%, 0,44;<br>2,25); NS|RR: 0,56<br>(IC95%,<br>0,11; 2,86);<br>NS; I2=0%|12 (6)|21<br>(10)|−4 (−9; 1);<br>p=0,08|NR|NR|NA|NR|NR|NA|10 (8)|11 (8)|NR|NR|NR|
|**Descolamento**<br>**tracional n, (%)**|NR|NR|10 (5)|16<br>(8)|NR|5,6|5,6|NR|NR|NR|NA|NR|NR|NR|NR|NR|
|**Regmatogênico (%)**|NR|NR|1 (<1)|1<br>(<1)|NR|5,6|0|NR|NR|NR|NA|NR|NR|NR|NR|NR|
|**Não específico (%)**|NR|NR|3 (2)|4 (2)|NR|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|
|**Mudanças maculares, n**<br>**(%)**|NR|NR|NR|NR|NA|64,4|23,3|<0,001|NR|NR|NA|NR|NR|NR|NR|NR|
|**Catarata, n (%)**|RR: 0,32 (IC<br>95%, 0,01;<br>7,63); NS|RR: 0,68<br>(IC95%,<br>0,38; 1,23);<br>NS; I2=0%|4 (2)|12<br>(6)|p=0,06|34,4|5,6|p=0,004|NR|NR|NA|NR|NR|NR|NR|NR|
|**Aumento da pressão**<br>**intraocular**|RR: 0,75<br>(IC95%, 0,42;<br>1,36); NS; I2:<br>53%|RR: 0,31<br>(IC95%,<br>0,01; 7,47);<br>NS|17 (9)|27<br>(13)|p=0,16|9|0|0,01|NR|NR|NA|16<br>(13)|19 (14)|1|0|0|  
99  
||**MiZ**|**l**||||||**Autor, An**|**o**|||**Bh**|**l**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**artnez-**<br>**2014**|**pata et a.**<br><sup>**101**</sup>|**Gr**|**oss et al.**|**2015**<sup>**111**</sup>|**Avita**|**bile et al.**|**2011**<sup>**198**</sup>|**Faghi**|**hi et al. 20**|**08**<sup>**199**</sup>|**avs**<br>**201**|**r et a.**<br>**3**<sup>**197**</sup>|**C**|**ho et al. 2010***<sup>**1**</sup>|<sup>**16**</sup>|
|**Evento adverso**||||||||**Valor p**|||||||||
||**Anti-VEGF**<br>**vs. FPR**|**BIV vs. VPP**|**RIV**|**FPR**|**Δ RIV -**<br>**FPR**|**PPV**<br>**(%)**|**FPR**<br>**(%)**|**VPP x**<br>**FPR (12**<br>**meses)**|**TRI +**<br>**VPP**|**VPP**|**Valor**<br>**p**|**RIV**|**Salina**|**TRI+FPR**|**BIV+FPR**|**FPR**|
|**Endoftalmite, n (%)**|RR: 0,36<br>(IC95%, 0,01;<br>8,82); NS|Não<br>estimável|1 (0,5)|0|NA|NR|NR|NA|0|1 (2,9)|0,287|0|1 (<1)|NR|NR|NR|
|**Inflamação ocular, n**<br>**(%)**|NR|NR|2 91)|9 (4)|0,02|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|
|||||||**Eventos**|**adversos s**|**istêmicos**|||||||||
|**AVC**|RR: 3,26<br>(IC95%, 0,13;<br>79,34), NS|Não<br>estimável|2 (2)|4 (4)|p=0,63|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|
|**IM não fatal, n (%)**|NR|NR|3 (3)|2 (2)|p=0,89|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|
|**Morte por evento**<br>**cardiovascular, n (%)**|NR|NR|4 (4)|1<br>(<1)|p=0,22|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|
|**Morte, n (%)**|NR|NR|6 (6)|4 (4)|p=0,70|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|
|**Hospitalização, n (%)**|NR|NR|48<br>(47)|40<br>(75)|p=0,20|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|
|**EA grave, n (%)**|NR|NR|49<br>(48)|42<br>(37)|p=0,26|NR|NR|NA|NR|NR|NA|NR|NR|NR|NR|NR|  
100  
|||||||||**Autor, An**|**o**||||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**Martinez-Z**<br>**201**|**apata et al.**<br>**4**<sup>**101**</sup>|**Gr**|**oss et al. 2**|**015**<sup>**111**</sup>|**Avita**|**bile et al.**|**2011**<sup>**198**</sup>|**Faghih**|**i et al. 20**|**08**<sup>**199**</sup>|**Bhavs**<br>**201**|**ar et al.**<br>**3**<sup>**197**</sup>|**C**|**ho et al. 2010***<sup>**116**</sup>||
|**Evento adverso**|**Anti-VEGF**<br>**vs. FPR**|**BIV vs. VPP**|**RIV**|**FPR**|**Δ RIV -**<br>**FPR**|**PPV**<br>**(%)**|**FPR**<br>**(%)**|**Valor p**<br>**VPP x**<br>**FPR (12**<br>**meses)**|**TRI +**<br>**VPP**|**VPP**|**Valor**<br>**p**|**RIV**|**Salina**|**TRI+FPR**|**BIV+FPR**|**FPR**|
|**HAS,n (%)**|RR: 0,47<br>(IC95%, 0,12;<br>1,76); NS|Não<br>estimável|26<br>(25)|21<br>(18)|p=0,23|NR|NR|NR|NR|NR|NR|3 (2)|7 (5)|NR|NR|NR|  
Anti-VEGF: Anti-fator de crescimento do endotélio vascular; FPR: fotocoagulaçãopan-retinal; BIV: bevacizumabeintra-vítreo; RIV: ranibizumabe intravítreo; TRI: triancinolona acetonida; VPP: vitrectomia via pars plana; *resultados apenas para pacientes sem edema macular significante;RR: risco relativo; NS: Não significante; NA: não se aplica; NR: não reportado;I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.  
101

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **F. Questão de pesquisa 6** -->
**Questão de Pesquisa 6:** Qual a eficácia do uso conjunto de terapia anti-VEGF e vitrectomia via pars plana posterior?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1) Estratégias de Busca** -->
As questões de pesquisa 5-10 referiram-se ao tratamento da retinopatia diabética com laser, vitrectomia ou terapia farmacológica (corticosteroides e/ou Anti-VEGFs), especificado em relação à presença ou não de edema macular, a localização do edema (centro da fóvea ou não) e extensão do tratamento (fixo, pro re nata ou tratar e extender). Dessa forma, uma única estratégia sensível de busca, descrita abaixo, foi elaborada e os resultados do processo de avaliação da elegibilidade foram estratificados de acordo com a questão de pesquisa.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **MEDLINE via pubmed:** -->
(((((((((("Light Coagulation"[Mesh] OR coagulation, light OR coagulations, light OR light coagulation OR photocoagulation OR photocoagulations OR laser photocoagulation OR laser coagulation)) OR ("Bevacizumab"[Mesh] OR avastin OR intravitreal bevacizumab)) OR ("Ranibizumab"[Mesh] OR lucentis OR intravitreal ranibizumab)) OR ("aflibercept" [Supplementary Concept] OR eylea OR intravitreal aflibercept)) OR ("Fluocinolone Acetonide"[Mesh] OR Iluvien OR intravitreal fluocinolone acetonide)) OR ("Dexamethasone"[Mesh] OR ozurdex OR intravitreal dexamethasone)) OR ("Vitrectomy"[Mesh] OR vitrectomy))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ("Treatment Outcome"[Mesh] OR efficacy OR effectiveness OR safety)

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
(("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ((((fixed regimen OR fixed scheme OR fixed)) OR (PRN OR pro re nata OR pro re nata regimen OR PRN regimen OR as needed OR PRN scheme OR pro re nata scheme)) OR (Treat and extend regimen OR treat-and-extend regimen OR treat and extend scheme OR treat-and-extend scheme OR treat and extend OR treat-and-extend))  
Total: 2.328 referências  
Data do acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('treatment outcome'/exp OR 'treatment outcome' OR 'safety'/exp OR safety OR 'efficacy'/exp OR efficacy OR effectiveness) AND ('bevacizumab'/exp OR 'bevacizumab' OR 'avastin'/exp OR 'avastin' OR 'intravitreal bevacizumabe' OR 'ranibizumab'/exp OR 'ranibizumab' OR 'lucentis'/exp OR 'lucentis' OR 'intravitreal ranibizumab' OR 'aflibercept'/exp OR 'aflibercept' OR 'eylea'/exp OR 'eylea' OR 'intravitreal aflibercept' OR 'dexamethasone'/exp OR 'dexamethasone' OR 'ozurdex'/exp OR 'ozurdex' OR 'intravitreal dexamethasone' OR 'fluocinolone acetonide'/exp OR 'fluocinolone acetonide' OR 'iluvien'/exp OR 'iluvien' OR 'intravitreal fluocinolone acetonide' OR 'laser coagulation'/exp OR 'laser coagulation' OR 'laser photocoagulation'/exp OR 'laser photocoagulation' OR 'vitrectomy'/exp OR 'vitrectomy' OR 'pars plana vitrectomy'/exp OR 'pars plana vitrectomy') AND [embase]/lim

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('fixed regimen' OR 'fixed scheme' OR 'fixed' OR 'prn'/exp OR 'prn' OR 'pro re nata' OR 'pro re nata regimen' OR 'prn regimen' OR 'as needed' OR 'prn scheme' OR 'pro re nata scheme' OR 'treat and extend regimen' OR 'treat-and-extend regimen' OR 'treat and extend scheme' OR 'treat-and-extend scheme' OR 'treat and extend' OR 'treatand-extend') AND [embase]/lim  
Total: 2.394 referências  
Data de acesso: 29/12/2016  
102  
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 4.722 referências (2.328 no MEDLINE e 2.394 no Embase). Destas, 753 foram excluídas por estarem duplicadas. Três mil novecentos e sessenta e nove referências foram triadas por</mark> meio da leitura de título e resumos, das quais 214 referências, correspondentes às 7 questões de pesquisa, tiveram seus textos completos avaliados para confirmação da elegibilidade.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Seis potenciais referências tiveram sua elegibilidade confirmada para a questão 6 por meio da leitura do texto completo. Destas, 2 foram excluídas, sendo uma por se tratar de um ECR piloto e outra por não considerar a intervenção preconizada na pergunta 6 (AntiVEGF). Quatro estudos foram considerados elegíveis, sendo 3 revisões sistemáticas com meta-análise<sup>101,102,210</sup> e um ECR não presente no rol de estudos das revisões sistemáticas incluídas<sup>211</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
As características dos estudos incluídos encontram-se na **Tabela 41** . As características basais estão demonstradas na **Tabela 42** . A **Tabela 43** exibe os principais desfechos para os estudos incluídos. A **Tabela 44** exibe os principais desfechos de segurança (eventos adversos) apresentados nos estudos incluídos.  
103  
**Tabela 41 –** Características dos estudos incluídos para a resposta da questão 6  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||<br>**Revisões sistemática**|<br>**s com meta-análise**||||
|**Simunovic et al.**<br>**2015**<sup>**102**</sup>|Revisão sistemática com<br>meta-análise|Avaliar a eficácia e segurança dos agentes anti-VEGF x<br>VPP na RD|22 ECR, com 1397 olhos randomizados|Anti-VEGF +<br>VPP|VPP|Baixo|
|**Martinez-zapata**<br>**et al. 2014**<sup>**101**</sup>|Revisão sistemática com<br>meta-análise|Avaliar a eficácia e segurança dos agentes anti-VEGF x<br>VPP na RD|18 ECR (16 incluídos nas meta-análises), com<br>1005 participantes|Anti-VEGF +<br>VPP|VPP|Baixo|
|**Zhan et al.**<br>**2013**<sup>**210**</sup>|Revisão sistemática com<br>meta-análise|Avaliar a eficácia e segurança dos agentes anti-VEGF x<br>VPP e FPR na RD|8 ECR, com 394 pacientes (414 olhos)|Anti-VEGF +<br>VPP|VPP|Baixo|
|||**Ensaio clínico**|**randomizado**||||
|**Manabe et al.**<br>**2015**<sup>**211**</sup>|ECR|Avaliar a capacidade do BIV em associação com a VPP na<br>redução da hemorragia vítrea|62 pacientes (66 olhos) com RDP, hemorragia<br>vítrea e DRT|BIV 0,16 mg/0,05<br>mL + VPP|Injeção<br>"sham"* +<br>VPP|Baixo|
|Anti-VEGF: agente ant<br>retinaltracional; *place|i-fator de crescimento do endo<br>bo de procedimentos médicos.|télio vascular; VPP: vitrectomia via pars plana; ECR: Ensaio<br>|Clínico Randomizado; RD: retinopatia diabética; R|DP: Retinopatia Diabéti|ca Proliferativa;|DRT: descolamento|  
**Tabela 42 –** Dados basais para o estudo primário incluído para a resposta à questão 6  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção,**<br>**média (DP)**|**Idade**<br>**controle,**<br>**média (DP)**|**% sexo masc.**<br>**Intervenção**|**% sex masc**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central da**<br>**retina (µm)**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Manabe et al.**<br>**2015**<sup>**211**</sup>|32 olhos|34 olhos|59,9 (11,8)|59,2 (12,9)|69|94|8,0 (1,7)|7,6 (2,0)|NR|1 mês|  
<mark>DP: Desvio padrão; NR: Não relatado; masc.: masculino; HbA1c: hemoglobina glicada.</mark>  
104  
**Tabela 43 –** Principais desfechos para os estudos incluídos  
|**Autor, ano**|**Grupo**|**Duração da**<br>**cirurgia, min**<br>**(DP)**|**Número de**<br>**paradas no**<br>**intraoperatório, n**<br>**(%)**|**Reoperação**<br>**devido a HV**<br>**(%)**|**Sangramento**<br>**intraoperatório**<br>**(hemorragia**<br>**intravítreo)**|**Aplicação**<br>**endodiatermia,**<br>**média (DP)**|**Hemorragia**<br>**intravítreo**<br>**precoce (pós-**<br>**cirurgia), n (%)**|**Hemorragia**<br>**intravítreo**<br>**tardio (pós-**<br>**cirurgia), n**<br>**%**|**Perda ≥ 3**<br>**Linhas**<br>**(ETDRS**<br>**acuidade**<br>**il**|**Ganho ≥**<br>**3 Linhas**<br>**(ETDRS**<br>**acuidade**<br>**il**|**Acuidade**<br>**visual,**<br>**Logmar,**<br>**média (DP)**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||**()**|**vsua)**|**vsua)**||
|||||**R**|**evisões sistemáticas co**|**m meta-análise**||||||
|**Simunovic**<br>**et al.**<br>**2015**<sup>**102**</sup>|BIV + VPP<br>vs. VPP|DM: -26,05 min<br>(95% IC, -33,34; -<br>18,77), p<0,001);<br>I2=50% (Favorece<br>BIV + VPP)|OR: 0,35 (95%IC,<br>0,16-0,79), p=0,01;<br>I2= 2% (Favorece<br>BIV + VPP)||OR: 0,06 (IC95%,<br>0,01-0,30),<br>p=0,0007; I2=NR<br>(Favorece BIV +<br>VPP)|MD: -2,87<br>(95%IC, -5,42; -<br>0,33), p=0,03; I2=<br>NR (favorece BIV<br>+ VPP)|OR: 0,34 (IC95%<br>0,18-0,67),<br>p=0,002; I2= 0%<br>(Favorece BIV +<br>VPP)||NR|NR|NR|
|**Martinez-**<br>**zapata et**<br>**al. 2014**<sup>**101**</sup>|BIV + VPP<br>vs. VPP|NR|NR||RR: 0,30 (IC95%,<br>0,18; 0,52);<br>p<0,001; I2=47%|NR|NR||RR: 0,49<br>(IC95%,<br>0,08;<br>3,14); NS;<br>I2=0%|RR: 1,62<br>(IC95%,<br>1,20;<br>2,17) NS;<br>I2=73%|DM: -0,24<br>(IC95%, -0.50;<br>0,01) NS;<br>I2=67%|
|**Zhan et al.**<br>**2013**<sup>**210**</sup>|BIV + VPP<br>vs. VPP|NR|NR||NR|NR|NR|OR: 0,55<br>(IC95%,<br>0,25; 1,21),<br>NS; I2=0%|NR|NR|NR|
||||||**Ensaio clínico ran**|**domizado**||||||
||||||||||||Em 1 mês:<br>0,46 (0,54);<br>p<0,001 em<br>relação ao|
|**Manabe et**<br>**al. 2015**<sup>**211**</sup>|BIV + VPP|49 (20)|5 (15,6)|3,1|NR|0,63 (1,0)|1 (3,1|)|NR|NR|basal<br>Δ 1 mês-<br>basal: −0,63<br>(0,61) (20<br>letras -<br>ETDRS)|  
105  
|**Autor, ano**|**Grupo**|**Duração da**<br>**cirurgia, min**<br>**(DP)**|**Número de**<br>**paradas no**<br>**intraoperatório, n**<br>**(%)**|**Reoperação**<br>**devido a HV**<br>**(%)**|**Sangramento**<br>**intraoperatório**<br>**(hemorragia**<br>**intravítreo)**|**Aplicação**<br>**endodiatermia,**<br>**média (DP)**|**Hemorragia**<br>**intravítreo**<br>**precoce (pós-**<br>**cirurgia), n (%)**|**Hemorragia**<br>**intravítreo**<br>**tardio (pós-**<br>**cirurgia), n**<br>**(%)**|**Perda ≥ 3**<br>**Linhas**<br>**(ETDRS**<br>**acuidade**<br>**visual)**|**Ganho ≥**<br>**3 Linhas**<br>**(ETDRS**<br>**acuidade**<br>**visual)**|**Acuidade**<br>**visual,**<br>**Logmar,**<br>**média (DP)**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||Sham +<br>VPP|56 (27) (p = 0,298<br>entre grupos)|5 (14,7) (p = 0,593<br>entre grupos)|20,6 (p =<br>0,033 entre<br>grupos)|NR|1,3 (1,4) (p =<br>0,025 entre<br>grupos)|8 (23,5) (p = 0,017|entre grupos)|NR|NR|Em 1 mês:<br>0,43 (0,48);<br>p<0,001 em<br>relação ao<br>basalΔ 1 mês-<br>basal: −0,73<br>(0,80) (25<br>letras) (p =<br>0,445 entre<br>grupos)|  
<mark>DP: Desvio padrão; BIV: bevacizumabe intravítreo; VPP: vitrectomia via pars plana; MD: diferença de média; OR: OddsRatio ou razão de chances; RR: risco relativo; NR: não relatado; I</mark> 2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Tabela 44 –** Principais desfechos de segurança relatados nos estudos incluídos -->
||||**Autor, an**|**o**|||||
|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|**Martinez-zapata et al. 2014**<sup>**101**</sup>|**M**|**anabe et al. 2015**<sup>**21**</sup>|<sup>**1**</sup>||**Zhan**|**g et al. 2013**<sup>**210**</sup>||
||**BIV vs. VPP**|**BIV+VPP**|**Sham+VPP**|**Valor p**|**BIV+VPP**|**VPP**|**OR (IC95%)**|**Valor p**|
||**Eventos**|**adversos ocular**|**es**||||||
|**Glaucoma neovascular, n (%)**|RR: 2,33 (IC95%, 0,28; 19,17); NS|0|3 (8,8)|0,131|2 (4)|3 (6)|0,68 (0,13; 3,58)|0,65|
|**Descolamento de retina, n (%)**|RR: 0,56 (IC95%, 0,11; 2,86); NS; I2=0%|NR|NR|NA|NR|NR|NR|NA|
|**Catarata, n (%)**|RR: 0,68 (IC95%, 0,38; 1,23); NS; I2=0%|NR|NR|NA|NR|NR|NR|NA|
|**Aumento da pressão intraocular, n (%)**|RR: 0,31 (IC95%, 0,01; 7,47); NS|2 (6,3)|6 (17,6)|0,149|NR|NR|NR|NA|
|**Endoftalmite, n (%)**|Não estimável|NR|NR|NA|NR|NR|NR|NA|
||**Eventos a**|**dversos sistêmi**|**cos**||||||
|**AVC, n (%)**|Não estimável|NR|NR|NA|NR|NR|NR|NA|  
106  
|**HAS, n (%)**|Não estimável<br>NR<br>NR<br>NA<br>NR<br>NR<br>NR<br>NA|
|---|---|  
BIV: bevacizumabe intravítreo; VPP: vitrectomia via pars plana; HAS: hipertensão artéria sistêmica; AVC: acidente vascular cerebral; OR: oddsratio ou razão de chances; RR: risco relativo; IC 95%: intervalo de confiança 95%;I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.  
107

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **G. Questão de pesquisa 7** -->
**Questão de Pesquisa 7:** Qual a eficácia e segurança de laser e/ou tratamento farmacológico para edema macular que não envolve o centro da fóvea?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1) Estratégias de Busca** -->
As questões de pesquisa 5-10 referiram-se ao tratamento da retinopatia diabética com laser, vitrectomia ou terapia farmacológica (corticosteroides e/ou Anti-VEGFs), especificado em relação à presença ou não de edema macular, a localização do edema (centro da fóvea ou não) e extensão do tratamento (fixo, pro re nata ou tratar e estender). Dessa forma, uma única estratégia sensível de busca, descrita abaixo, foi elaborada e os resultados do processo de avaliação da elegibilidade foram estratificados de acordo com a questão de pesquisa.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **MEDLINE via pubmed:** -->
(((((((((("Light Coagulation"[Mesh] OR coagulation, light OR coagulations, light OR light coagulation OR photocoagulation OR photocoagulations OR laser photocoagulation OR laser coagulation)) OR ("Bevacizumab"[Mesh] OR avastin OR intravitreal bevacizumab)) OR ("Ranibizumab"[Mesh] OR lucentis OR intravitreal ranibizumab)) OR ("aflibercept" [Supplementary Concept] OR eylea OR intravitreal aflibercept)) OR ("Fluocinolone Acetonide"[Mesh] OR Iluvien OR intravitreal fluocinolone acetonide)) OR ("Dexamethasone"[Mesh] OR ozurdex OR intravitreal dexamethasone)) OR ("Vitrectomy"[Mesh] OR vitrectomy))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ("Treatment Outcome"[Mesh] OR efficacy OR effectiveness OR safety)

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
(("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ((((fixed regimen OR fixed scheme OR fixed)) OR (PRN OR pro re nata OR pro re nata regimen OR PRN regimen OR as needed OR PRN scheme OR pro re nata scheme)) OR (Treat and extend regimen OR treat-and-extend regimen OR treat and extend scheme OR treat-and-extend scheme OR treat and extend OR treat-and-extend))  
Total: 2.328 referências  
Data do acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('treatment outcome'/exp OR 'treatment outcome' OR 'safety'/exp OR safety OR 'efficacy'/exp OR efficacy OR effectiveness) AND ('bevacizumab'/exp OR 'bevacizumab' OR 'avastin'/exp OR 'avastin' OR 'intravitreal bevacizumabe' OR 'ranibizumab'/exp OR 'ranibizumab' OR 'lucentis'/exp OR 'lucentis' OR 'intravitreal ranibizumab' OR 'aflibercept'/exp OR 'aflibercept' OR 'eylea'/exp OR 'eylea' OR 'intravitreal aflibercept' OR 'dexamethasone'/exp OR 'dexamethasone' OR 'ozurdex'/exp OR 'ozurdex' OR 'intravitreal dexamethasone' OR 'fluocinolone acetonide'/exp OR 'fluocinolone acetonide' OR 'iluvien'/exp OR 'iluvien' OR 'intravitreal fluocinolone acetonide' OR 'laser coagulation'/exp OR 'laser coagulation' OR 'laser photocoagulation'/exp OR 'laser photocoagulation' OR 'vitrectomy'/exp OR 'vitrectomy' OR 'pars plana vitrectomy'/exp OR 'pars plana vitrectomy') AND [embase]/lim

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('fixed regimen' OR 'fixed scheme' OR 'fixed' OR 'prn'/exp OR 'prn' OR 'pro re nata' OR 'pro re nata regimen' OR 'prn regimen' OR 'as needed' OR 'prn scheme' OR 'pro re nata scheme' OR 'treat and extend regimen' OR 'treat-and-extend regimen' OR 'treat and extend scheme' OR 'treat-and-extend scheme' OR 'treat and extend' OR 'treatand-extend') AND [embase]/lim  
Total: 2.394 referências  
Data de acesso: 29/12/2016  
108

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1)** **<mark>Estratégia de Busca</mark>** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 4.722 referências (2.328 no MEDLINE e 2.394 no Embase). Destas, 753 foram excluídas por estarem duplicadas. Três mil novecentos e sessenta e nove referências foram triadas por</mark> meio da leitura de título e resumos, das quais 214 referências, correspondentes às 7 questões de pesquisa, tiveram seus textos completos avaliados para confirmação da elegibilidade.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Somente foram considerados elegíveis para essa questão, referências que citaram, claramente, que a população do estudo compreende pacientes sem envolvimento do centro da fóvea (“ _non-center involved_ ” ou espessura macular central <250 µm).  
Quarenta e nove referências tiveram sua elegibilidade confirmada através da leitura do texto completo. Destas, 47 foram excluídas porque não avaliaram, especificamente, pacientes com edema macular sem envolvimento do centro da fóvea. Dessa forma, um estudo observacional<sup>125</sup> foi elegível. Ademais, uma referência encontrada por meio de busca manual foi incluída<sup>124</sup> .  
- **3)** **<mark>Descrição dos estudos e seus resultados</mark>**  
As características dos estudos incluídos encontram-se na **Tabela 45** . As características basais estão demonstradas na **Tabela 46** . A  
**Tabela 47** exibe os principais desfechos para os estudos incluídos.  
109  
**Tabela 45 –** Características dos estudos incluídos para a resposta à questão 7  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Perente et**<br>**al. 2014**<sup>**124**</sup>|Coorte retrospectiva|Avaliar os desfechos visuais em<br>pacientes com diabetes mellitus tipo 2 e<br>EMD não envolvendo o centro da fóvea|43 pacientes (49 olhos) adultos<br>com EMD não envolvendo o<br>centro da fóvea|FPR (laser argônio - 532 nm) (SL-130;<br>Zeiss-Humphrey systems, Carl Zeiss,<br>Jena, Germany)|Ausência de laser|Alto (Sem<br>representatividade, sem<br>controle de<br>confundidores)|
|**Scott et al.**<br>**2009**<sup>**125**</sup>|Série de casos|Avaliar desfechos de acuidade visual e<br>espessura macular em pacientes com<br>EMD não envolvendo o centro da fóvea|24 olhos de pacientes com EMD<br>não envolvendo o centro da fóvea|FPR (ETDRS (focal/grid))|Sem comparador|Alto (série de casos)|  
EMD: edema macular diabético; FPR: fotocoagulaçãopan-retinal.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Tabela 46 –** Características basais dos estudos incluídos para responder à questão 7 -->
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção,**<br>**média (DP)**|**Idade controle,**<br>**média (DP)**|**% sexo masc.**<br>**Intervenção**|**% sex masc.**<br>**controle**|**Acuidade visual (escore**<br>**de letra), Logmar**|**Espessura central da**<br>**retina (µm), média**<br>**(DP)**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|**Perente et**<br>**al. 2014**<sup>**124**</sup>|25 pacientes/29<br>olhos|18<br>pacientes<br>20 olhos|63,2 (7,9)|60,4 (9,1)|68|78|Letras ETDRS (variação):<br>FPR: 74 (65-85);<br>Controle: 76 (65-87)|FPR: 223 (17);<br>Controle: 214 (21)|12 meses|
|**Scott et al.**<br>**2009**<sup>**125**</sup>|24 olhos|NA|NR|NR|NR|NR|Mediana (IQR): 84 (76-<br>90); Snellen eq.: 20/20<br>(20/32, 20/16)|Mediana (IQR): 225<br>(213, 236)|12 meses|  
DP: Desvio padrão; FPR: fotocoagulaçãopan-retinal; Masc.: masculino; IQR: intervalo interquartil; NA: não se aplica; NR: Não relatado; DP: desvio padrão.  
110  
**Tabela 47 –** Principais desfechos relatados pelos estudos incluídos  
|**Autor,**<br>**ano**|**Grupo**|**Acuidade visual, Logmar, média (DP)**|**Espessura central macular (µm), média (DP)**|
|---|---|---|---|
||FPR|Letras (ETDRS):<br>**3 meses:**74 (60-85); p=0,69 (em relação ao<br>basal)<br>**6 meses:**74 (57-85); p=0,86 (em relação ao<br>basal)<br>**12 meses**: 74 (55-85); p=0,72 (em relação ao<br>basal)|**3 meses:**214 (25); p=0,06 (em relação ao basal);<br>**6 meses:**207 (31); p=0,01 (em relação ao basal);<br>**12 meses:**208 (27); p=0,009 (em relação ao basal).|
|||Letras (ETDRS):||
|**Perente**<br>**et al.**<br>**2014**<sup>**124**</sup>|Controle|**3 meses:**75 (61-85); p=0,09 (em relação ao<br>basal);<br>**6 meses:**74 (53-84); p=0,04 (em relação ao<br>basal);<br>**12 meses:**72 (37-84); p=0,02.|**3 meses:**215 (18); p=0,53 (em relação ao basal);<br>**6 meses:**221 (34); p=0,21 (em relação ao basal);<br>**12 meses:**236 (29); p=0,01 (em relação ao basal).|
||||**3 meses - basal (µm):**<br>**FPR**: -9,2<br>**Controle:**+1,4; p=0,03|
||FPR x<br>controle|**12 meses - basal**:<br>**FPR:**+0,4 letras;<br>**Controle:**-3,3 letras; p=0,03. Não houve<br>diferença significante em 3 e 6 meses.|**6 meses - basal (µm):**<br>**FPR:**-15,8<br>**Controle:**+7,2; p=0,01<br>**12 meses - basal (µm):**<br>**FPR:**-15,2<br>**Controle:**+17,2; p<0,001|
|**Scott et**<br>**al.**<br>**2009**<sup>**125**</sup>|FPR|**12 meses - basal (mediana (IQR)):**-1 (-5; +2);<br>não existe indicativo de significância estatística|**12 meses - basal (mediana (IQR)):**-10 (-16; +13); não existe<br>indicativo de significância estatística|  
FPR: fotocoagulaçãopan-retinal; IQR: intervalo interquartil; DP: desvio padrão.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **H.** **<mark>Questão de pesquisa 8</mark>** -->
**<mark>Questão de Pesquisa 8:</mark>** <mark>Q</mark> ual a eficácia e segurança dos tratamentos farmacológicos, a laser e, cirúrgico (associação individual e comparativo) para edema macular diabético que envolve o centro da fóvea?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1)** **<mark>Estratégia de busca</mark>** -->
As questões de pesquisa 5-10 referiram-se ao tratamento da retinopatia diabética com laser, vitrectomia ou terapia farmacológica  
(corticosteroides e/ou Anti-VEGFs), especificado em relação à presença ou não de edema macular, a localização do edema (centro da fóvea ou não) e extensão do tratamento (fixo, pro re nata ou tratar e extender). Dessa forma, uma única estratégia sensível de busca, descrita abaixo, foi elaborada e os resultados do processo de avaliação da elegibilidade foram estratificados de acordo com a questão de pesquisa.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **MEDLINE via pubmed:** -->
(((((((((("Light Coagulation"[Mesh] OR coagulation, light OR coagulations, light OR light coagulation OR photocoagulation OR photocoagulations OR laser photocoagulation OR laser coagulation)) OR ("Bevacizumab"[Mesh] OR avastin OR intravitreal bevacizumab)) OR ("Ranibizumab"[Mesh] OR lucentis OR intravitreal ranibizumab)) OR ("aflibercept" [Supplementary Concept] OR eylea OR intravitreal aflibercept)) OR ("Fluocinolone Acetonide"[Mesh] OR Iluvien OR intravitreal fluocinolone acetonide)) OR ("Dexamethasone"[Mesh] OR ozurdex OR intravitreal dexamethasone)) OR ("Vitrectomy"[Mesh] OR vitrectomy))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ("Treatment Outcome"[Mesh] OR efficacy OR effectiveness OR safety)  
111

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
(("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ((((fixed regimen OR fixed scheme OR fixed)) OR (PRN OR pro re nata OR pro re nata regimen OR PRN regimen OR as needed OR PRN scheme OR pro re nata scheme)) OR (Treat and extend regimen OR treat-and-extend regimen OR treat and extend scheme OR treat-and-extend scheme OR treat and extend OR treat-and-extend))  
Total: 2.328 referências  
Data do acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('treatment outcome'/exp OR 'treatment outcome' OR 'safety'/exp OR safety OR 'efficacy'/exp OR efficacy OR effectiveness) AND ('bevacizumab'/exp OR 'bevacizumab' OR 'avastin'/exp OR 'avastin' OR 'intravitreal bevacizumabe' OR 'ranibizumab'/exp OR 'ranibizumab' OR 'lucentis'/exp OR 'lucentis' OR 'intravitreal ranibizumab' OR 'aflibercept'/exp OR 'aflibercept' OR 'eylea'/exp OR 'eylea' OR 'intravitreal aflibercept' OR 'dexamethasone'/exp OR 'dexamethasone' OR 'ozurdex'/exp OR 'ozurdex' OR 'intravitreal dexamethasone' OR 'fluocinolone acetonide'/exp OR 'fluocinolone acetonide' OR 'iluvien'/exp OR 'iluvien' OR 'intravitreal fluocinolone acetonide' OR 'laser coagulation'/exp OR 'laser coagulation' OR 'laser photocoagulation'/exp OR 'laser photocoagulation' OR 'vitrectomy'/exp OR 'vitrectomy' OR 'pars plana vitrectomy'/exp OR 'pars plana vitrectomy') AND [embase]/lim

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('fixed regimen' OR 'fixed scheme' OR 'fixed' OR 'prn'/exp OR 'prn' OR 'pro re nata' OR 'pro re nata regimen' OR 'prn regimen' OR 'as needed' OR 'prn scheme' OR 'pro re nata scheme' OR 'treat and extend regimen' OR 'treat-and-extend regimen' OR 'treat and extend scheme' OR 'treat-and-extend scheme' OR 'treat and extend' OR 'treatand-extend') AND [embase]/lim  
Total: 2.394 referências

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca das evidências resultou em 4.722 referências (2.328 no MEDLINE e 2.394 no EMBASE). Destas, 753 foram excluídas por estarem duplicadas. Três mil novecentos e sessenta e nove referências foram triadas por meio da leitura de título e resumos, das quais 214 referências tiveram seus textos completos avaliados para confirmação da elegibilidade. Cento e cinquenta e oito referências tiveram sua elegibilidade confirmada para a questão 8 por meio da leitura completa do estudo.</mark>  
<mark>Como critério de inclusão, foram priorizados os estudos do tipo revisões sistemáticas de ensaios clínicos randomizados, com metaanálises de comparações diretas ou indiretas e ensaios clínicos randomizados que incluíssem acima de 50 participantes eque especificassem que o estudo avaliava participantes com edema macular diabético com envolvimento do centro da fóvea. Caso não fosse especificado, foi conferido, tanto nos estudos primários das revisões sistemáticas incluídas, bem como nos ensaios clínicos randomizados, se na seleção das evidências dos participantes eram fornecidas informações que nos permitisse concluir que a condição de interesse era edema macular com envolvimento do centro da fóvea. Quando havia disponível vários artigos de um mesmo estudo, optou-se pela publicação mais nova e com maior tempo de seguimento disponível, desde que essa incluísse os desfechos de avaliações anteriores. Foram considerados como desfechos primários de eficácia a alteração de acuidade visual e da espessura da retina desde a linha de base e os principais desfechos primários de segurança fornecidos pelos estudos.</mark>  
<mark>Nessa etapa 118 estudos foram excluídos: 1) 15 por representarem delineamentos de estudos com maior risco de viés (14 observacionais e um crossover). 2) Dezesseis revisões sistemáticas foram excluídas: 2.1) cinco revisões sistemáticas não especificaram se o estudo se tratava de edema macular diabético que envolve o centro da fóvea; 2.2) duas revisões sistemáticas incluíram outros desenhos de estudos (isto é, coorte, séries de casos); 2.3) quatro revisões sistemáticas realizaram somente revisão qualitativa e não meta- análise; 2.4) quatro revisões sistemáticas foram excluídas por haver uma versão com maior número de estudos incluídos, mais atual ou com maior tempo de seguimento; 2.5) um estudo foi excluído por falta de acesso ao texto completo. 3) 81 ensaios clínicos</mark>  
112  
<mark>foram excluídos: 3.1) 26 estudos por estarem incluídos em revisões sistemáticas incluídas neste Apêndice; 3.2) 27 estudos não especificaram se o estudo se tratava de edema macular diabético que envolve o centro da fóvea; 3.3) 13 estudos foram excluídos por incluir menos de 50 participantes; 3.4) um estudo por se tratar de uma intervenção de não interesse; 3.5) seis estudos foram excluídos por não tratar de desfechos de interesse; 3.6) seis estudos por serem análise de subgrupo de estudos já incluídos; 3.7) um estudo foi excluído por falta acesso ao texto completo; 3.8) um estudo foi excluído por haver somente o protocolo de estudo e não os resultados.</mark>  
<mark>No final, seis revisões sistemáticas de ensaios clínicos randomizados com meta-análise de comparações diretas</mark><sup>126,127,133,134,212,213</sup> <mark>e três de comparações indiretas</mark><sup>131,214,215</sup> <mark>e 35 referências de 22 estudos de ensaios clínicos randomizados foram incluídos.</mark>

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A descrição sumária dos estudos que compararam mais de um inibidor do fator de crescimento endotelial vascular (anti-VEGF) encontram-se na</mark> **<mark>Tabela 48</mark>** <mark>. As características dos pacientes incluídos encontram-se na</mark> **<mark>Tabela 49</mark>** <mark>e os dados de desfechos de eficácia na</mark> **<mark>Tabela 50</mark>** <mark>e desfechos de segurança nas</mark> **<mark>tabelas 51 a 53</mark>** <mark>.</mark>  
<mark>A descrição sumária dos estudos que comparam ranibizumabe intravítreo (RANI) encontram-se na</mark> **<mark>Tabela 54</mark>** <mark>. As características dos pacientes incluídos encontram-se na</mark> **<mark>Tabela 55</mark>** <mark>e os dados de desfechos de eficácia na</mark> **<mark>Tabela 56</mark>** <mark>e desfechos de segurança nas</mark> **<mark>tabelas 57 e 58</mark>** <mark>.</mark>  
<mark>A</mark> **<mark>Tabela 59</mark>** <mark>apresenta as características dos estudos que compararam o bevacizumabe intravítreo (BEVA) enquanto a</mark> **<mark>Tabela 60</mark>**  
<mark>apresenta as características dos pacientes incluídos nesses estudos. A</mark> **<mark>Tabela 61</mark>** <mark>apresenta os desfechos de eficácia e a</mark> **<mark>Tabela 62</mark>** <mark>os</mark>  
<mark>desfechos de segurança desses estudos.</mark>  
<mark>A descrição sumária dos estudos que compararam aflibercepte intravítreo (AFLIBE) encontra-se na</mark> **<mark>Tabela 63</mark>** <mark>. As características dos</mark>  
<mark>pacientes incluídos encontram-se na</mark> **<mark>Tabela 64</mark>** <mark>e os dados de desfechos de eficácia na</mark> **<mark>Tabela 65</mark>** <mark>e desfechos de segurança na</mark> **<mark>Tabela 66</mark>** <mark>.</mark>  
<mark>A</mark> **<mark>Tabela 67</mark>** <mark>apresenta as características dos estudos comparativos avaliando mais de um esteroide intravítreo enquanto a</mark> **<mark>Tabela 68</mark>**  
<mark>apresenta as características dos pacientes incluídos nesses estudos. A</mark> **<mark>Tabela 69</mark>** <mark>apresenta os desfechos de eficácia e a</mark> **<mark>Tabela 70</mark>** <mark>os desfechos de segurança desses estudos.</mark>  
<mark>A descrição sumária dos estudos que compararam triancinolona intravítreo (TRI) encontra-se na</mark> **<mark>Tabela 71</mark>** <mark>. As características dos pacientes incluídos encontram-se na</mark> **<mark>Tabela 72</mark>** <mark>e os dados de desfechos de eficácia na</mark> **<mark>Tabela 73</mark>** <mark>e desfechos de segurança na</mark> **<mark>Tabela 74</mark>** <mark>.</mark>  
<mark>A</mark> **<mark>Tabela 75</mark>** <mark>apresenta as características dos estudos que compararam o implante de fluocinolona intravítreo (FLU) enquanto a</mark> **<mark>Tabela</mark>**  
**<mark>76</mark>** <mark>apresenta as características dos pacientes incluídos nesses estudos. A</mark> **<mark>Tabela 77</mark>** <mark>apresenta os desfechos de eficácia e a</mark> **<mark>Tabela 78</mark>** <mark>os desfechos de segurança desses estudos.</mark>  
<mark>A descrição sumária dos estudos que compararam o implante de dexametasona intravítreo (DEXA) encontra-se na</mark> **<mark>Tabela 79</mark>** <mark>. As características dos pacientes incluídos encontram-se na</mark> **<mark>Tabela 80</mark>** <mark>e os dados de desfechos de eficácia na</mark> **<mark>Tabela 81</mark>** <mark>e desfechos de segurança na</mark> **<mark>Tabela 82</mark>** <mark>.</mark>  
<mark>A</mark> **<mark>Tabela 83</mark>** <mark>apresenta as características dos estudos que compararam os diferentes tipos de laser enquanto a</mark> **<mark>Tabela 84</mark>** <mark>apresenta as características dos pacientes incluídos nesses estudos. A</mark> **<mark>Tabela 85</mark>** <mark>apresenta os desfechos de eficácia e a</mark> **<mark>Tabela 86</mark>** <mark>os desfechos de segurança desses estudos.</mark>  
113

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1.1 Grupo intervenção: Inibidores do fator de crescimento endotelial vascular (anti-VEGF): análises incluindo mais de um anti-VEGF** -->
**Tabela 48 -** Características das revisões sistemáticas com meta-análises de comparações diretas e indiretas e ensaios clínicos randomizados incluídas na pergunta de pesquisa Q8 que compararam mais de um antiVEGF  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Tipo de edema**<br>**macular diabético**|**Número de estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Avery et al. 2016**<sup>**126**</sup>|Revisão Sistemática<br>com meta-análise de<br>comparação direta<br>(Busca realizada até<br>maio de 2015)|Avaliar a segurança de<br>subpopulações de pacientes<br>com EMD com alto nível de<br>exposição (injeções mensais<br>por dois anos) aos anti-VEGF.|Envolve o centro da<br>fóvea: conferido nos<br>estudos primários|4 ECR, 1328<br>participantes com<br>exposição alta à anti-<br>VEGF|Anti-VEGF (1) RANI 0.5mg-<br>considerado de alta dosagem e/ou;<br>2) RANI 0.3 mg-considerado de baixa<br>dosagem e/ou;<br>3) AFLIBE 2mg)|Tratamento com<br>laser/ placebo|Baixo Risco de Viés|
|**Virgili et al.**<br>**2014**<sup>**133**</sup>|Revisão Sistemática<br>com meta-análise de<br>comparação direta<br>(Última atualização<br>Abril 2014)|Investigar os efeitos em<br>preservar e melhorar a visão e<br>aceitabilidade, incluindo a<br>segurança, adesão e qualidade<br>de vida com a terapia com<br>anti-VEGF para o tratamento<br>de EMD|Envolve o centro da<br>fóvea: confirmados<br>pelo OCT nos estudos<br>primários|18 ECR, 2749<br>participantes|Anti-VEGF (BEVA, RANI, AFLIBE,<br>Anti-VEGF (RANI) + laser<br>(fotocoagulação)|Laser/ Tratamento<br>placebo|Baixo Risco de Viés|
|**Ford et al. 2012**<sup>**214**</sup>|Revisão Sistemática<br>com meta-análise em<br>rede (Busca realizada<br>até setembro de 2011)|Comparar a efetividade<br>clínica do RANI e BEVA<br>mensurados pela acuidade<br>visual melhor corrigida e a<br>espessura central macular de<br>EMD|Envolve o centro da<br>fóvea: conferido nos<br>estudos primários|5 ECR, 1555 olhos|BEVA|RANI|Alto Risco de Viés<br>(comparações<br>indiretas, estudos<br>incluídos com<br>amostra pequenas)|
|**Regnier et al.**<br>**2014**<sup>**131**</sup>|Revisão Sistemática<br>com meta-análise em<br>rede (Última<br>atualização fevereiro<br>de 2014)|Compare a eficácia do RANI,<br>AFLIBE, laser e placebo no<br>tratamento de primeira linha<br>do EMD|Envolve o centro da<br>fóvea: confirmados<br>pelo OCT nos estudos<br>primários|8 ECR, 1978<br>participantes|RANI 0.5 mg_pro re nata_(PRN)<br>RANI 0.5 mg ou AFLIBE<br>2mg/bimensal<br>RANI 0.5 mg ou AFLIBE<br>2mg/bimensal|AFLIBE<br>Laser<br>Injeção de placebo|Alto Risco de<br>Viés(comparações<br>indiretas, busca por<br>evidências<br>inadequado)|  
114  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Tipo de edema**<br>**macular diabético**|**Número de estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Wells et al. 2015 e**<br>**Wells et al. 2016**<br>**(DRCRNet)**<sup>**98,153**</sup>|ECR,DRCRNet|Comparar a efetividade de<br>BEVA 1.25 mg com RANI<br>0.5 mg dado mensalmente em<br>pacientes com EMD|EMD, envolve o<br>centro da macula<br>(BVCA ≥ 24 e ≤ 78<br>letras; CST ≥ 250µm)|660 participantes|BEVA 1.25 mg<br>RANI 0.5 mg<br>AFLIBE 2 mg<br>(Eficácia comparativa dos três Anti-<br>VEGF)|NA|Alto Risco de Viés<br>(Cegamento de<br>Avaliadores (2015 e<br>2016) e participantes<br>(2016))|
|**Wells et al.**<br>**2016b**<sup>**216**</sup>|||||BEVA 1.25 mg<br>RANI 0.5 mg<br>AFLIBE 2 mg<br>(Eficácia comparativa entre<br>subgrupos)<br>BEVA 1.25 mg (CST≥400; AV<69)<br>(subgrupo1)<br>BEVA 1.25 mg (CST≥400; AV 78-<br>69) (subgrupo 2)|||
||||||BEVA 1.25 mg (CST<400; AV<69)<br>(subgrupo 3)|||
||ECR, DRCRNet<br>(análise de subgrupo<br>do estudo acima)|Prover desfechos adicionais<br>sobre agentes anti-VEGF<br>dentro de subgrupos baseados<br>na acuidade visual na linha de<br>base e espessura central de<br>subcampo|EMD, envolve o<br>centro da macula<br>(BVCA ≥ 24 e ≤ 78<br>letras; CST ≥ 250µm)|660 participantes|BEVA 1.25 mg (CST<400; AV 78-<br>69) (subgrupo 4)<br>RANI 0.5mg (CST≥400; AV<69)<br>(subgrupo 5)|NA|Alto Risco de Viés<br>Análise exploratória,<br>IC 95% largos,<br>Falta de cegamento<br>dos profissionais|
||||||RANI 0.5mg (CST≥400; AV 69-78)<br>(subgrupo 6)|||
||||||RANI 0.5mg (CST<400; AV <69)<br>(subgrupo 7)<br>RANI 0.5mg (CST<400; AV 69-78)<br>(subgrupo 8)|||
||||||AFLIBE 2mg (CST≥400; AV <69))<br>(subgrupo 9)|||  
115  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Tipo de edema**<br>**macular diabético**|**Número de estudos e**<br>**participantes**<br>**incluídos**<br>**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|
|||||AFLIBE 2mg (CST≥400; AV 69-78)<br>(subgrupo 10)|||
|||||AFLIBE 2mg (CST<400; AV<69)<br>(subgrupo 11)|||
|||||AFLIBE2mg (CST<400; AV 69-78)<br>(subgrupo 12)|||  
EMD: edema macular diabético; OCT: Tomografia de coerência óptica; ECR: ensaio clínico randomizado;AV: acuidade visual;BCVA: acuidade visual de melhor corrigida; ECR: ensaio clínico randomizado; CST: espessura do subcampo central; VEGF: fator de crescimento endotelial vascular;BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; AFLIBE: injeção de aflibercepte intravítrea; NA: não se aplica; IC 95%: intervalo de confiança 95%.  
**Tabela 49 –** Características da linha de base dos participantes dos estudos incluídos que compararam mais de um inibidor do fator de crescimento endotelial vascular (anti-VEGF)  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Acuidade visual†,**<br>**Média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Avery et**<br>**al. 2016**<sup>**126**</sup>|Anti-VEGF|Laser/ placebo|RANI 0.5mg:<br>250<br>RANI 0.3 mg:<br>250<br>AFLIBE: 291|537|Variação da<br>média<br>61.7- 62.7<br>Anos|Variação<br>da média<br>61.7- 62.7<br>Anos|NR|NR|NR|NR|2 anos|
|**Virgili et**<br>**al. 2014**<sup>**133**</sup>|Anti-VEGF|Laser/ placebo|Variável|Variável|Variação d<br>54- 67|a média:<br>Anos|Variação 32-<br>69%|NR|Entre 20/200 e 20/40|NR|24 semanas a 24<br>meses|
|**Ford et al.**<br>**2012**<sup>**214**</sup>|BEVA|RANI|NR|NR|NR|NR|NR|NR|NR|NR|6-12 meses|  
116  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Acuidade visual†,**<br>**Média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Regnier et**<br>**al. 2014**<sup>**131**</sup>|RANI 0.5 mg<br>PRN<br>RANI ou<br>AFLIBE<br>RANI ou<br>AFLIBE|AFLIBE<br>Laser<br>Injeção de<br>placebo|NR|NR|NR|NR|NR|NR|NR|NR|6-12 meses|  
|**Wells et al.**|||BEVA 1.25||||||Global: 64.8 (11.3)<br>**Escore de letras <69**<br>**(20/50 ou pior):**<br>BEVA: 56,6 (10,6)<br>AFLIBE: 562 (111)|Global: 412 (130) *<br>**Escore de letras <69**<br>**(20/50 ou pior):**<br>BEVA: 467 (155) *<br>AFLIBE: 452 (145) *||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**2015 e**|BEVA 1.25||mg: 218||||||, ,<br>RANI: 565 (99)|RANI: 431 (138) *||
|**Wells et al.**<br>**2016**|mg|NA|RANI 0.5mg:<br>218|NA|Média: 61 (10)|NA|53%|NR|, ,<br>**E d l d**|**Escore de letras de**|2 e 24 meses|
|**(DRCRNet**<br>**)**<sup>**98,153**</sup>|RANI 0.5mg||AFLIBE 2mg:<br>224||||||**score e etras e**<br>**78 a 69 (20/32 a**<br>**20/40):**|**78 a 69 (20/32 a**<br>**20/40):**||
||AFLIBE 2mg||||||||<br>BEVA: 72,8 (2,9)<br>AFLIBE: 73,5 (2,6)<br>RANI: 73,4 (2,7)|BEVA: 363 (88) *<br>AFLIBE: 373 (108) *<br>RANI: 384 (99) *||  
117  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Acuidade visual†,**<br>**Média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||BEVA 1.25<br>mg (CST≥400;<br>AV <69)<br>(subgrupo1)<br>BEVA 1.25<br>mg<br>(CST≥400; AV<br>78-69)<br>(subgrupo 2)||||||||**Subgrupo 1:**55,6<br>(10,3)<br>**Subgrupo 2:**72,4<br>(2,7)<br>**Subgrupo 3:**59,4<br>(9,7)<br>**Subgrupo 4:**73,0<br>|**Subgrupo 1:**558<br>(130) *<br>**Subgrupo 2:**471<br>(75) *<br>**Subgrupo 3:**323<br>(39) *<br>**Subgrupo 4:**318<br>(44) *||
|**Wells et al.**<br>**2016b**<br>**(DRCRNet**<br>**)216**|BEVA 1.25<br>mg<br>(CST<400;<br>acuidade<69)<br>(subgrupo 3)<br>BEVA 1.25|NA (eficácia<br>|Subgrupo 1: 61<br>Subgrupo 2: 31||||||(2,9)<br>**Subgrupo 5:**55,5<br>(10,5)<br>**Subgrupo 6:**72,8<br>(2,7)|**Subgrupo 5:**540<br>(106) *<br>**Subgrupo 6:**479<br>(68) *||
||mg<br>(CST<400; AV<br>78-69)<br>(subgrupo 4)<br>RANI 0.5mg<br>(CST≥400; AV<br><69) (subgrupo<br>5)|comparativa<br>entre<br>subgrupos)|Subgrupo 3: 39<br>Subgrupo 4: 73<br>Subgrupo 5: 50|NA|Média: 61 (10)|NA|53%|NR|**Subgrupo 7:**57,7<br>(9,1)<br>**Subgrupo 8:**73,7<br>(2,7)<br>**Subgrupo 9:**54,9<br>(11)|**Subgrupo 7:**320<br>(50) *<br>**Subgrupo 8:**314<br>(45) *<br>**Subgrupo 9:**534<br>(128) *|12 meses|
||RANI 0.5mg<br>(CST≥400; AV<br>69-78)||||||||**Subgrupo 10:**73,2<br>(2,7)|**Subgrupo 10:**499<br>(103) *||
||(subgrupo 6)<br>RANI 0.5mg<br>(CST<400; AV<br><69) (subgrupo<br>7)||||||||**Subgrupo11:**59 (10)<br>**Subgrupo 12:**73,6<br>(2,5)|**Subgrupo11:**327<br>(44) *<br>**Subgrupo 12:**317<br>(45) *||  
118  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Acuidade visual†,**<br>**Média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||RANI 0.5mg<br>(CST<400; AV<br>69-78)|||||||||||
||(subgrupo 8)|||||||||||
||AFLIBE 2mg|||||||||||
||(CST≥400;|||||||||||
||AV<69))<br>(subgrupo 9)|||||||||||
||AFLIBE 2mg<br>(CST≥400; AV|||||||||||
||69-78)|||||||||||
||(subgrupo 10)|||||||||||
||AFLIBE 2mg|||||||||||
||(CST<400;|||||||||||
||AV<69)|||||||||||
||(subgrupo 11)|||||||||||
||AFLIBE 2mg<br>(CST<400; AV<br>69-78)|||||||||||
||(subgrupo 12)|||||||||||  
AV: acuidade visual na linha de base; CST: espessura do subcampo central *; VEGF: fator de crescimento endotelial vascular; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; AFLIBE: injeção de aflibercepte intravítrea; PRN: _pro re nata_ , ou se necessário; HbA1c: hemoglobina glicada; Masc.: masculino; NR: não reportado; NA: não se aplica.  
**Tabela 50 –** Desfechos de eficácia de estudos que compararam mais de um inibidor do fator de crescimento endotelial vascular (anti-VEGF)  
119  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
||ANTI-VEGF|Laser|**Ganho de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR: 3.6 (IC 95%: 2.7, 4.8); I2= 0%; 10 ECR, 1333 pacientes<br>**Perda de >3 linhas na acuidade visual entre a linha de base e A)1 ano e B)**<br>**2 anos**<br>RR: 0.11 (IC 95%: 0.05, 0.24); I2= 0%; 7 ECR, 1086 pacientes<br>**Acuidade visual (logMAR) entre a linha de base e 1 ano**<br>DM: -0.16 (IC 95%: -0.18, -0.14); I2= 59%; 8 ECR, 1292 pacientes|<0.00001<br>< 0.00001<br><0.05|**Alteração da CMT (µm) entre a**<br>**linha de base e 1 ano**<br>DM: -78.83 (IC 95%: -94.55, -<br>63.12); I2= 68%; 7 ECR, 1215<br>pacientes|<0.05|
|**Virgili et al.**<br>**2014**<sup>**133**</sup><br>(Revisão<br>Sistemática|ANTI-VEGF|Placebo|**Ganho > 3 linhas na acuidade visual entre a linha de base e A) 1 ano e B) 2**<br>**anos**<br>A) RR: 2.19 (IC 95%: 1.36, 3.53); I2= NR; 3 ECR, 497 pacientes<br>B) RR: 2,50 (IC 95%: 2,02, 3,09); I2= 0%; 2 ECR, 1233 pacientes|A) <0.05<br>B) <0.05|||
|com meta-<br>análise)|||**Perda > 3 linhas na acuidade visual após 1 ano**<br>RR: 0,28 (IC 95%: 0.13, 0.59); I2= NR; 2 ECR, 411 pacientes|A) <0.05|||
||||**Acuidade Visual após 1 ano e B) 2 anos**<br>A) DM: -0,13 (IC 95%: -0,17, -0,08); I2= NR; 4 ECR, 575 pacientes<br>B) DM: -0,18 (IC 95%: -0,20, -0,15); I2= 0%; 2 ECR, 1233pacientes|A) <0.05<br>B) <0.05|||
||ANTI-VEGF +<br>Laser|Laser rápido|**Ganho de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR:2.37 (IC 95%:1.76, 3.21); I2= NR; 4 ECR, 919 pacientes|NR|||
||ANTI-VEGF +<br>Laser|Laser retardado|RR:1.88 (IC 95%:1.31, 2.70); I2= NR; 1 ECR, 481 pacientes|NR|||
||BEVA|Laser|**Ganho de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR:2.89 (IC 95%: 1.42, 5.91); I2= 0%; 3 ECR, 207 pacientes|0.004|**Alteração da CMT (µm) entre a**<br>**linha de base e 1 ano**<br>DM: -43.61 (IC 95%: -82.11, -<br>5.11); I2= NR; 2 ECR, 165|<0.05|
|**Virgili et al.**<br>**2014**<sup>**133**</sup>|||**Perda de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR: 0.16 (IC 95%: 0.05, 0.51); I2= 0%; 2 ECR, 167 pacientes|0.002|pacientes<br>**Alteração da CMT (µm) após 2**|>0.05|
|(Revisão<br>Sistemática<br>com meta-<br>análise)|BEVA|Placebo|**Acuidade visual (logMAR) entre a linha de base e A) 1 ano e B) 2 anos**<br>A) DM: -0.20 (IC 95%: -0.28, -0.12); I2= NR; 2 ECR, 165 pacientes<br>B) DM: -0,14 (IC 95%: -0,24, -0,05); I2= NR; 2 ECR, 142 pacientes<br>**Acuidade Visual após 1 ano**<br>DM: -0,15 (IC 95%: -0,26, -0,04); I2= NR; 1 ECR, 78 pacientes|A) <0.05<br>B) <0.05<br><0.05|**anos**<br>DM: -18,35 (IC 95%: -62,23,<br>25,52); I2= NR; 2 ECR, 142<br>pacientes||  
120  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
||||**Ganho > 3 linhas na acuidade visual após 1 ano**<br>RR: 0.81 (IC 95%: 0.44, 1.87); I2= NR; 1 ECR, 60 pacientes|<0.05|**Alteração da CMT (µm) entre a**||
||BEVA|RANI|**Perda > 3 linhas na acuidade visual após 1 ano**<br>RR: 2.64 (IC 95%: 0.11, 62.23); I2= NR; 1 ECR, 60 pacientes|<0.05|**linha de base e 1 ano**<br>DM: 27.02 (IC 95%:(-5.70,<br>59.73)); I2= NR; 2 ECR, 160<br>|NR|
||||**Acuidade visual (logMAR) entre a linha de base e 1 ano**||pacientes||
||||DM: 0.00 (IC 95%: -0.0, 0.05); I2= NR; 2 ECR, 160 pacientes|>0.05|||  
121  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
||RANI|Laser|**Ganho de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR: 3.59 (IC 95%: 2.03, 6.33); I2= 0%; 4 ECR, 465 pacientes<br>**Perda de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR:0.20 (IC 95%: 0.05, 0.91); I2= 0%; 2 ECR, 258 pacientes|< 0.00001<br>0.04|**Alteração da CMT (µm) entre a**<br>**linha de base e 1 ano**<br>DM: -47.94 (IC 95%: -73.15, -<br>22.73); I2= NR; 3 ECR, 390<br>pacientes|<0.05|
||||**Acuidade visual (logMAR) entre a linha de base e 1 ano**<br>DM: -0.12 (IC 95%: -0.15, -0.08); I2= NR; 4 ECR, 466 pacientes|<0.05|||
||RANI|Placebo|**Ganho > 3 linhas na acuidade visual após 1 ano**<br>RR: 3.17 (IC 95%: 1.32, 7.62); I2= NR; 1 ECR, 151 pacientes|<0.05|||
||||**Perda > 3 linhas na acuidade visual após 1 ano**<br>RR: 0.14 (IC 95%: 0.04, 0.50); I2= NR; 1 ECR, 151 pacientes|<0.05|||
||||**Acuidade Visual após 1 ano**<br>DM: -0.23 (IC 95%: -0.32, -0.15); I2= NR; 1 ECR, 151 pacientes|<0.05|||
|**Virgili et al.**<br>**2014**<sup>**133**</sup>|||||||
|(Revisão<br>Sistemática<br>com meta-|RANI (0.5mg)|Placebo|**Ganho > 3 linhas na acuidade visual após 1 ano**<br>RR: 2.80 (IC 95%: 2.03, 3.86); I2= NR; 1 ECR, 509 pacientes|<0.05|||
|análise)|||**Acuidade Visual após 2 anos**<br>DM: -0.19 (IC 95%: -0.23, -0.14); I2= NR; 1 ECR, 509 pacientes|<0.05|||
||RANI (0.3mg)|Placebo|**Ganho > 3 linhas na acuidade visual após 1 ano**<br>RR: 2.58 (IC 95%: 1.86, 3.58); I2= NR; 1 ECR, 507 pacientes|<0.05|||
||||**Acuidade Visual após 2 anos**<br>DM: -0.20 (IC 95%: -0,24, -0,15); I2= NR; 1 ECR, 507 pacientes|<0.05|||
||AFLIBE|Laser|**Ganho de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR: 3.81 (IC 95%: 2.61, 5.56); I2= 0%; 2 ECR, 661 pacientes<br>**Perda de >3 linhas na acuidade visual entre a linha de base e 1 ano**<br>RR: 0.06 (IC 95%: 0.01, 0.23); I2= 0%; 2 ECR, 661 pacientes|< 0.00001<br>< 0.00001|**Alteração da CMT (µm) entre a**<br>**linha de base e 1 ano**<br>DM: -119.02 (IC 95%: (-142.58, -<br>95.45); I2= NR; 2 ECR, 660<br>pacientes|<0.05|
||||**Acuidade visual (logMAR) entre a linha de base e 1 ano**<br>DM: -0.20(IC 95%: -0.24,-0.17);I2= NR;2 ECR,661pacientes|<0.05|||  
122  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Ford et al.**<br>**2012**<sup>**214**</sup><br>(Revisão<br>Sistemática<br>com meta-<br>análise em<br>|BEVA|RANI|**Porcentagem de pacientes com ganho de ≥2 linhas**<br>OR: 0.95 (IC 95% 0.23, 4.32), 4ECR<br>**Alteração média da acuidade visual de melhor corrigida (LogMar)**<br>DM: -0.08 (IC 95% −0.19, 0.04), 4ECR|> 0.05<br>> 0.05|**Redução média da CMT (µm)**<br>DM: −6.9 (IC 95%−88.5, 65.4),<br>4ECR|>0.05|
|rede)|BEVA|RANI + Laser rápido|**Porcentagem de pacientes com ganho de ≥2 linhas**<br>OR: 0.80 (IC 95% 0.19, 3.11), 5 ECR<br>**Alteração média da acuidade visual de melhor corrigida (LogMar)**<br>DM: −0.10 (IC 95% −0.22, 0.00), 5 ECR|> 0.05<br>> 0.05|**Redução média da CMT (µm)**<br>DM: 10.9 (IC 95% −62.7, 78.7), 5<br>ECR|>0.05|
||BEVA|RANI + Laser<br>retardado|**Porcentagem de pacientes com ganho de ≥2 linhas**<br>OR: 0.61 (IC 95% 0.12, 2.84), 3 ECR<br>**Alteração média da acuidade visual de melhor corrigida (LogMar)**<br>DM: −0.10 (IC 95% −0.23, 0.03), 3 ECR|> 0.05<br>> 0.05|**Redução média da CMT (µm)**<br>DM: 12.9 (IC 95% −76.0, 95.4), 3<br>ECR|>0.05|
||||**Melhora da acuidade visual melhor corrigida (ganho de mais de 10 letras)**<br>*****||||
|**Regnier et al.**<br>**2014**<sup>**131**</sup><br>(Revisão||LASER|<br>OR: 5.50 (IC 95% 2.73, 13.16)|<0.05|||
|Sistemática<br>com meta-<br>análise em|RANI 0.5 PRN|AFLIBE 2m|OR: 1.59 (IC 95% 0.61, 5.37)|>0.05|NR|NR|
|rede)||Injeção de placebo|OR: 6.50 (IC 95% 1.66, 24.99)|<0.05|||
||||**Melhora da acuidade visual melhor corrigida (ganho de mais de 10 letras)**<br>*****||||
|||Laser|OR: 3.45 (IC 95% 1.62, 6.84)|<0.05|||
||AFLIBE 2mg/<br>bimensal|RANI 0.5PRN|OR: 0.63 (IC 95% 0.19, 1.63)|>0.05|NR|NR|
|||Injeção de placebo|OR: 4.06 (IC 95% 0.60, 21.84)|>0.05|||  
123  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
||||**Melhora da acuidade visual melhor corrigida (ganho de mais de 10 letras)**<br>*****||||
|**Regnier et al.**<br>**2014**<sup>**131**</sup><br>||Laser|OR: 4.05 (IC 95% 2.16, 8.65)|<0.05|||
|(Revisão<br>Sistemática<br>com meta-|RANI/ Laser|RANI 0.5 PRN|OR: 0.74 (IC 95% 0.35, 1.46)|>0.05|NR|NR|
|análise em<br>rede)|||||||
|||AFLIBE|OR: 1.18 (IC 95% 0.45, 3.66)|>0.05|||
||||**Melhora da acuidade visual melhor corrigida (ganho de mais de 10 letras)**<br>*****||||
|||Laser|OR: 0.85 (IC 95% 0.19, 4.56)|>0.05|||
||Injeção de<br>placebo|RANI 0.5 PRN|OR: 0.15 (IC 95% 0.04, 0.60)|<0.05|NR|NR|
|||AFLIBE|OR: 0.25 (IC 95% 0.05, 1.65)|>0.05|||
|||RANI 0.5mg|OR: 0.21 (IC 95% 0.05, 1.01)|>0.05|||
||||**Probabilidade de cada tratamento ser o mais eficaz na rede**||||
||Laser||0%||||
||RANI 0.5mg<br>PRN||73%||||
||AFLIBE 2mg|NA|14%|NR|NR|NR|
||RANI 0.5mg<br>PRN/ Laser||12%||||
||Injeção de<br>placebo/<br>resquício de laser||1%||||  
124  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
||||**Melhora na acuidade visual entre a linha de base e ao final de A) 1 ano**<br>**(letras) e B) 2 anos**<br>AFLIBE DM: A) +13.3; B) +12.8<br>RANI DM: A) +11.2; B) +10<br>BEVA DM: A) +9.7; B) +12.3|**A)**<0,001 p/<br>AFLIBE vs.<br>BEVA; 0,03<br>p/AFLIBE vs.<br>RANI;<br>|**Redução média da espessura**<br>**CST (µm) entre a linha de base e**<br>**após A) 1 ano e B) 2 anos de**<br>**estudo**<br>**BVCA na linha de base < 69**<br>||
|||||**B)**0,02 p/<br>AFLIBE vs.<br>BEVA; 0,47|**(equivalente Snellen: 20/50 ou**<br>**pior)**||
|||||p/AFLIBE vs.<br>RANI; 0,11 p/|AFLIBE DM: A) −135 (152); B) -<br>185 (158)|NR|
|||||RANI vs. BEVA|RANI DM: A) −176 (151); B) -<br>174 (159)|NR|
||||**Alteração média da acuidade visual entre a linha de base e após A) 1 ano e**<br>**B) 2 anos de estudo**<br>||BEVA DM: −210 (151); B) -211<br>(155)|NR|
||||**BVCA na linha de base < 69 (equivalente Snellen: 20/50 ou pior)**<br>||||
||||AFLIBE DM: A) 11.8 (12.0); B) 13.3 (13.4)<br>|NR|∆ (IC95%) AFLIBE 2mg - BEVA<br>|A) <0001|
||||RANI DM: A) 14.2 (10.6); B) 16.1 (12.1)<br>|NR|1.25 mg: A) −86 (−122, −50); B) -<br>|.<br>B) 001|
|||NA|BEVA: A) 18.9 (11.5); B)18.1 (13.8)|NR|42.1 ( -77.2, -7.0)|.|
|**Wells et al.**|AFLIBE|(eficáciacomparativa)|||||
|**2015 e Wells**|||∆ (IC95%) AFLIBE 2mg - BEVA 1.25 mg: A) 6.5 (2.9, 10.1); B) 4.7 (0.5,8.8)|A) <0.001; B)|∆ (IC95%) AFLIBE 2mg - RANI|A) 022|
|**et al. 2016**|RANI|||0.02|0.5mg: A) −19 (−48, 11); B) - 19.3|.<br>B) 019|
|**(DRCRNet)**|||∆ (IC95%) AFLIBE 2mg - RANI 0.5mg: A) 4.7 (1.4, 8.0); B) 2.3 ( -1.1, 5.6)||( -47.8, 9.3)|.|
|**98,153 **|BEVA|||A) 0.003; B)|||
||||∆ (IC95%) RANI 0.5mg - BEVA 1.25 mg: A) 1.8 (−1.1, 4.8); B) 2.4 (-1.0,5.8)|0.18<br>|∆ (IC95%) RANI 0.5mg - BEVA<br>1.25 mg: A) −67 (−101, −33); B) -<br>|A) <0.001|
|||||A) 0.21; B) 0.18|22.8 (- 52.2, 6.6)|<br>|
||||**BVCA na linha de base entre 78 a 69 (equivalente Snellen, 20/32 a 20/40)**<br>||<br>|B) 0.19|
||||AFLIBE DM: A) 7.5 (7.4); B) 6.8 (8.8)<br>||**BVCA na linha de base entre 78**<br>||
||||RANI DM: A) 8.3 (6.8); B)8.6 (7.0)||**a 69 (equivalente Snellen, 20/32 a**||
||||BEVA: A) 8.0 (7.6); B) 7.8 (8.4)|NR<br>|**20/40)**||
|||||NR|||
||||∆ (IC95%) AFLIBE 2mg - BEVA 1.25 mg: A) 0.7 (−1.3, 2.7); B)1.1 ( -1.1,<br>3.4)|NR|AFLIBE DM: −67 (65); B) -68<br>(98)|NR|
||||∆ (IC95%) AFLIBE 2mg - RANI 0.5mg: A) −0.4 (−2.3, 1.5); B) -0.7 ( -2.9,|A) 0.69; B) 0.51|RANI DM: A) −119 (109); B) -<br>125 (118)|NR|
||||1.5)|A) 0.69; B) 0.51|BEVA DM: A) −129 (110); B) -<br>133 (115)|NR|
||||∆ (IC95%) RANI 0.5mg - BEVA 1.25 mg: A) 1.1 (−0.9, 3.1); B) -1.9 (- 0.9,|A) 0.69; B) 0.31|∆ (IC95%) AFLIBE 2mg - BEVA||
||||<br>4.7)||<br>1.25 mg: A) −56(−78, −33); B) -<br>57.3 ( -82.7, -31.9)|A) <0.001<br>B) <0.001|
||||||<br>∆ (IC95%) AFLIBE 2mg - RANI<br>0.5mg: A) −18 (−37, 1); B) - 11.8 (<br>-32.4, 8.8)|A) 0.06<br>B) 0.26|
||||||∆ (IC95%) RANI 0.5mg - BEVA|A) <0001|
||||||1.25 mg: A) −38 (−59, −16); B) -|.<br>B <0001|
||||||45.4(- 69.6,-21.3)|) .|  
125  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Wells et al.**<br>**2015 e Wells**<br>**et al. 2016**<br>**(DRCRNet)**|BEVA 1.25<br>subgrupo 1,2,3<br>e4|NA|**Ganho médio (DP) da acuidade visual entre a linha de base e após 1 ano**<br>BEVA 1.25 mg subgrupo 1 (CST≥400; AV <69): 11.3 (13.2)<br>BEVA 1.25 mg subgrupo 2 (CST≥400; AV 78-69): 11.6 (8.8)<br>BEVA 1.25 mg subgrupo 3 (CST<400; AV <69): 5.4 (8.6)<br>|NR<br>NR<br>|**Redução média da CST (µm)**<br>**(DP) entre a linha de base e após**<br>**1 ano**<br>BEVA 1.25 mg subgrupo 1: −181<br>|NR|
|<br>**98,153**|RANI 05 m||BEVA 1.25 mg subgrupo 4 (CST<400; AV 78-69): 8.4(6.6)|NR|(170)||
||. g<br>subgrupo 5,6,7,8||RANI 0.5mg subgrupo 5 (CST≥400; AV <69): 14.9 (10.0)<br>RANI 0.5mg subgrupo 6 (CST≥400; AV 69-78): 13.3 (11.3)|NR<br>NR|BEVA 1.25 mg subgrupo 2: −63<br>(77)|NR|
||||RANI 0.5mg subgrupo 7 (CST<400; AV <69): 9.5 (6.7)|NR|BEVA 1.25 mg subgrupo 3: −104|NR|
||AFLIBE 2mg<br>b 91011||RANI 0.5mg subgrupo 8 (CST<400; AV 69-78): 7.6 (6.8)<br>AFLIBE 2mg subgrupo 9 (CST≥400; AV <69): 19.7 (11.7)|NR<br>NR|(86)<br>BEVA 1.25 mg subgrupo 4: −52|NR|
||sugrupo ,,<br>12||AFLIBE 2mg subgrupo 10 (CST≥400; AV 69-78): 17.5 (11.3)|NR|(47)||
||e||AFLIBE 2mg subgrupo 11 (CST<400; AV<69): 9.5 (8.4)<br>AFLIBE 2mg subgrupo 12 (CST<400; AV 69-78): 7.2 (7.2)|NR<br>NR|RANI 0.5mg subgrupo 5: −266<br>(152)|NR|
||||∆ (IC95%) AFLIBE 2mg subgrupo 9 - BEVA 1.25 mg subgrupo 1: 8.1 (4.9,<br>11.3)<br>∆ (IC95%) AFLIBE 2mg subgrupo 10- BEVA 1.25 mg subgrupo 2:5.7 (1.8,<br>9.7)<br>∆ (IC95%) AFLIBE 2mg subgrupo 11- BEVA 1.25 mg subgrupo 3:3.7 (−0.8,<br>8.1)|NR<br><0.05<br><0.05<br>>0.05|RANI 0.5mg subgrupo 6: −85 (78)<br>RANI 0.5mg subgrupo 7: −198<br>(106)<br>RANI 0.5mg subgrupo 8: −61 (66)<br>AFLIBE 2mg subgrupo 9: −203<br>(285)<br>AFLIBE 2mg subgrupo 10: −97<br>(60)<br>AFLIBE 2mg subgrupo 11: −235<br>(134)|NR<br>NR<br>NR<br>NR<br>NR|
||||∆ (IC95%) AFLIBE 2mg subgrupo 12- BEVA 1.25 mg subgrupo 4:−1.0 (−3.9,<br>1.9)|>0.05|AFLIBE 2mg subgrupo 12: −82<br>(50)|NR<br>NR|
||||∆ (IC95%) AFLIBE 2mg subgrupo 9- RANI 0.5mg subgrupo 5:4.5 (1.2, 7.8)<br>∆ (IC95%) AFLIBE 2mg subgrupo 10- RANI 0.5mg subgrupo 6:4.7 (0.9, 8.4)|<0.05|∆ (IC95%) AFLIBE 2mg subgrupo<br>9 - BEVA 1.25 mg subgrupo 1:<br>−123 (−155, −91)|<br><0.05|
||||∆ (IC95%) AFLIBE 2mg subgrupo 11- RANI 0.5mg subgrupo 7:0.2 (−3.8,<br>4.3)<br>∆ (IC95%) AFLIBE 2mg subgrupo 12- RANI 0.5mg subgrupo 8:−0.4 (−3.5,<br>2.7)<br>∆ (IC95%) RANI 0.5mg subgrupo 5- BEVA 1.25 mg subgrupo 1:3.6 (0.3, 7.0)|<0.05<br>>0,05<br>>0.05|∆ (IC95%) AFLIBE 2mg subgrupo<br>10- BEVA 1.25 mg subgrupo<br>2:−31 (−70, 8)<br>∆ (IC95%) AFLIBE 2mg subgrupo<br>11- BEVA 1.25 mg subgrupo<br>3:−112 (−157, −68)|>0.05<br><0.05|
||||∆ (IC95%) RANI 0.5mg subgrupo 6- BEVA 1.25 mg subgrupo 2:1.1 (−2.7,<br>4.8)<br>∆ (IC95%) RANI 0.5mg subgrupo 7- BEVA 1.25 mg subgrupo 3:3.4 (−0.8,<br>7.6)|<0.05|∆ (IC95%) AFLIBE 2mg subgrupo<br>12- BEVA 1.25 mg subgrupo<br>4:−32 (−61, −3)|<0.05|
||||∆ (IC95%) RANI 0.5mg subgrupo 8- BEVA 1.25 mg subgrupo 4:−0.6 (−3.7,<br>2.4)|>0.05<br>>0.05|||  
126  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos de Acuidade Visual**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Wells et al.**<br>**2015 e Wells**<br>**et al. 2016**<br>**(DRCRNet)**<br>**98,153**|BEVA 1.25<br>subgrupo 1,2,3<br>e4<br>RANI 0.5 mg<br>subgrupo 5,6,7,8|NA||>0.05|∆ (IC95%) AFLIBE 2mg subgrupo<br>9- RANI 0.5mg subgrupo 5:−24<br>(−57, 10)<br>∆ (IC95%) AFLIBE 2mg subgrupo<br>10- RANI 0.5mg subgrupo 6:−7<br>(−45, 30)|>0.05<br>>0.05|
||AFLIBE 2mg<br>subgrupo 9,10,11<br>e 12||||∆ (IC95%) AFLIBE 2mg subgrupo<br>11- RANI 0.5mg subgrupo 7:−22<br>(−63, 19))|>0,05|
||||||∆ (IC95%) AFLIBE 2mg subgrupo<br>12- RANI 0.5mg subgrupo 8:−20<br>(−51, 11)|>0.05|
||||||∆ (IC95%) RANI 0.5mg subgrupo<br>5- BEVA 1.25 mg subgrupo 1:−99<br>(−133, −66)|<0.05|
||||||∆ (IC95%) RANI 0.5mg subgrupo<br>6- BEVA 1.25 mg subgrupo 2:−24<br>(−61, 14)|>0.05|
||||||∆ (IC95%) RANI 0.5mg subgrupo<br>7- BEVA 1.25 mg subgrupo 3: -90<br>(−132, −48)|<0.05|
||||||∆ (IC95%) RANI 0.5mg subgrupo<br>8- BEVA 1.25 mg subgrupo 4:−12<br>(−43,19)|>0.05|  
CRT: espessura central da retina; CST: espessura do subcampo central; CMT: espessura macular central; EMD: edema macular diabético; ECR: ensaio clínico randomizado; AV: acuidade visual; BCVA: acuidade visual de melhor corrigida; VEGF: fator de crescimento endotelial vascular; BEVA: injeção de bevacizumabe intravítrea RANI: injeção de ranibizumabe intravítrea; AFLIBE: injeção de aflibercepte intravítrea; RR: risco relativo; IC 95%: intervalo de confiança; _∆:_ diferença;DM: diferença de médias; NR: não reportado; NA: não se aplica;I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.  
**Tabela 51 –** <mark>Desfechos de segurança d</mark> e revisões sistemáticas com meta-análise de comparações diretas que compararam mais de um inibidor do fator de crescimento endotelial vascular (anti-VEGF)  
|**Autor, ano**|**Intervenção**|**Controle**|**Eventos Adversos sistêmicos sérios em A) 6 a 24 meses**<br>**B) 6 a 12 meses; C) 24 meses**|**Eventos tromboembólicos arteriais em A) 6 a 24**<br>**meses; B) 6 a 12 meses; C) 24 meses**|**Mortalidade geral em 6-24 meses**|
|---|---|---|---|---|---|  
127  
|**Virgili et al.**|||A) OR: 0.98 (IC 95%: 0.83, 1.17); I2= 0%; 15 ECR, 2985<br>pacientes; p: 0.86|A) OR: 0.89 (IC 95%: 0.63, 1.25); I2= 0%; 14 ECR,<br>3034 pacientes; p: 0.49||
|---|---|---|---|---|---|
|**2014**<sup>**133**</sup><br>(Revisão<br>Sistemática com<br>|ANTI-VEGF|Controle|B) OR: 1.02 (IC 95%: 0.81, 1.28); I2= 0%; 11 ECR, 1879<br>pacientes; p: 0.90|B) OR: 1.33 (IC 95%: 0.67, 2.64); I2= 0%; 10 ECR,<br>1663 pacientes; p: 0.42|OR: 0.88 (IC 95%: 0.52, 1.47); I2=<br>0%; 15 ECR, 3562 pacientes; p: NR|
|meta-análise)|||C) OR: 0.95 (IC 95%: 0.73, 1.23); I2= 0%; 4 ECR, 1106|C) OR: 0.80 (IC 95%: 0.47, 1.38); I2= 0%; 4 ECR,||
||||pacientes; p: 0.68|1371 pacientes; p: 0.43||  
VEGF: fator de crescimento endotelial vascular; ECR: ensaio clínico randomizado; p: valor de p; OR: oddsratio ou razão de chances; IC 95%: intervalo de confiança; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises; NR: não reportado.  
**Tabela 52  –** <mark>Desfechos de segurança d</mark> e revisões sistemáticas com meta-análise de comparações diretas que compararam mais de um inibidor do fator de crescimento endotelial vascular (anti-VEGF)  
128  
|**Autor, ano**|**Intervenção**|**Controle**|**Mortalidade por todas as**<br>**causas**|**Acidente vascular cerebral**|**Mortalidade Vascular**|**Eventos arteriotrombóticos**|**Infarto do Miocárdio**|
|---|---|---|---|---|---|---|---|
|**Avery et al.**<br>**2016**<sup>**126**</sup>|RANI 0.5 mg/<br>AFLIBE 2.0 mg|Placebo/ laser|OR: 2.98 (IC 95%: 1.44,<br>6.14); I2= 0%; 4 ECR, 1078|OR: 2.33 (IC 95%: 1.04, 5.22); I2=<br>0%; 4 ECR, 1078 pacientes; p: 0.04|OR: 2.51 (IC 95%: 1.08,<br>5.82); I2= 0%; 4 ECR, 1078|OR: 1.58 (IC 95%: 0.95,<br>2.62); I2= 0%; 4 ECR, 1078|OR: 1.11 (IC 95%:0.57,<br>2.16); I2= 0%; 4 ECR,|
|(Revisão|||pacientes; p: 0.003||pacientes; p: 0.03|pacientes; p:0.08|1078 pacientes; p: 0.75|
|Sistemática||||||||
|com meta-|RANI 0.3 mg/|Placebo/ laser||OR: 1.70 (IC 95%: 0.69- 4.21); I2=||||
|análise)|<br>AFLIBE 2.0 mg||OR: 2.56 (IC 95%: 1.17,<br>5.57); I2= 0%; 4 ECR, 1088<br>pacientes; p:0.02|0%; 4 ECR, 1078 pacientes; p: 0.25|OR: 2.25 (IC 95%: 0.93,<br>5.45); I2= 0%; 4 ECR, 1078<br>pacientes; p: 0.07|OR: 1.42 (IC 95%: 0.84,<br>2.39); I2= 0%; 4 ECR, 1078<br>pacientes; p: 0.19|OR: 1.24 (IC 95%: 0.64,<br>2.37); I2= 0%; 4 ECR,<br>1078 pacientes; p: 0.55|
||RANI 0.3 mg/|Placebo/ laser||OR: 1.89 (IC 95%: 0.86, 4.16); I2=||||
||RANI 0.5 mg/|||0%; 4 ECR, 1328 pacientes; p: 0.11||||
||AFLIBE 2.0 mg||OR: 2.5 (IC 95%: 1.31-5.05);||OR: 2.23 (IC 95%: 1.01,|OR: 1.45 (IC 95%: 0.91,|OR: 1.14 (IC 95%: 0.62,|
||||I2= 0%; 4 ECR, 1328||4.89); I2= 0%; 4 ECR, 1328|2.33); I2= 0%; 4 ECR, 1328|2.10); I2= 0%; 4 ECR,|
||RANI 0.5 mg|Placebo/ laser|pacientes; p: 0.006|OR: 1.97 (IC 95%: 0.63, 6.17); I2=<br>0%; 2 ECR, 500 pacientes; p: 0.25|pacientes; p: 0.05|pacientes; p: 0.12|1328 pacientes; p: 0.41|
||RANI0.3 mg|Placebo/ laser|OR: 3.24 (IC 95%: 1.12,<br>9.36); I2= 0%; 2 ECR, 500<br>pacientes; p: 0.03|OR: 0.75 (IC 95%: 0.17, 3.33); I2=<br>0%; 2 ECR, 500 pacientes; p: 0.71|OR: 2.25 (IC 95%: 0.65,<br>7.87); I2= 0%; 2 ECR, 500<br>pacientes; p: 0.20|OR: 1.41 (IC 95%: 0.68,<br>2.90); I2= 0%; 2 ECR, 500<br>pacientes; p:0.36|OR: 0.78 (IC 95%: 0.28,<br>2.10); I2= 0%; 2 ECR, 500<br>pacientes; p: 0.62|
||RANI 0.3 mg/|Placebo/ laser|OR: 2.26 (IC 95%: 0.65,<br>7.90); I2= 0%; 2 ECR, 500<br>pacientes; p: 0.20|OR: 1.36 (IC 95%: 0.46- 4.00); I2=<br>0%; 2 ECR, 750 pacientes; p: 0.58|OR: 1.68 (IC 95%: 0.41-<br>6.78); I2= 0%; 2 ECR, 500<br>pacientes; p: 0.47|OR: 1.09 (IC 95%: 0.50,<br>2.36); I2= 0%; 2 ECR, 500<br>pacientes; p: 0.83|OR: 1.01 (IC 95%: 0.39,<br>2.59); I2= 0%; 2 ECR, 500<br>pacientes; p: 0.99|
||RANI 0.5 mg|||||||
|||Placebo/ laser||OR: 2.75 (IC 95%: 0.88, 8.63); I2=||||
||||OR: 2.42 (IC 95%: 0.96-6.06);|0%; 2 ECR, 578 pacientes; p: 0.04|OR: 1.85 (IC 95%: 0.63,|OR: 1.24 (IC 95%: 0.65,|OR: 0.89 (IC 95%: 0.38,|
||||<br>I2= 0%; 2 ECR, 750||<br>5.46); I2= 0%; 2 ECR, 750|<br>2.35); I2= 0%; 2 ECR, 750|<br>2.07); I2= 0%; 2 ECR, 750|
||AFLIBE 2.0 mg||pacientes; p: 0.06||pacientes; p: 0.47|pacientes; p: 0.51|pacientes; p: 0.78|
||||OR: 2.76 (IC 95%: 1.02,||OR: 2.74 (IC 95%: 0.87-|OR: 1.76 (IC 95%: 0.87,|OR: 1.49 (IC 95%: 0.61,|
||||7.46); I2= 0%; 2 ECR, 578||8.58); I2= 0%; 2 ECR, 578|3.56); I2= 0%; 2 ECR, 578|3.64); I2= 0%; 2 ECR, 578|
||||pacientes; p: 0.05||pacientes; p: 0.08|pacientes; p: 0.11|pacientes; p: 0.38|  
BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; AFLIBE: injeção de aflibercepte intravítrea; VEGF: fator de crescimento endotelial vascular; ECR: ensaio clínico randomizado; p: valor de p; OR: oddsratio ou razão de chances; IC 95%: intervalo de confiança; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises; NR: não reportado.  
**Tabela 53 –** Desfechos de segurança de ensaios clínicos randomizados que compararam mais de um inibidor do fator de crescimento endotelial vascular (anti-VEGF)  
||**Wells et al. 2015 e Wells et al. 2016 (DRCRNet)**<sup>**98,153**</sup>||
|---|---|---|
|**Eventos Adversos**||**Valor de p**|
||**BEVA 1. 25 mg vs. RANI 0.5 mg vs. AFLIBE 2mg**||
||Eventos ocorridos pelo menos uma vez até 2 anos (olhos)||  
129  
|**Hemorragia vítrea**|n (%): 17 (8) vs. 10 (5) vs. 15 (7)|0.37 *|
|---|---|---|
|Eventos ocorri|dos pelo menos uma vez até 2 anos (participantes)||
|**Quaisquer eventos adversos sistêmicos vasculares**|n (%): 9 (4) vs. 10 (5) vs. 6 (3)|0.56*|
|Eventos ocorri|dos pelo menos uma vez até 1 ano (participantes)||
|**Quaisquer adversos eventos vasculares definidos pela Colaboração de**<br>**participantes de ensaios clínicos antiplaquetários**|n (%): 17 (8) vs. 26 (12) vs. 12 (5)|0.047*|
|**Eventos adversos sistêmicos sérios**|n (%): 81 (37) vs. 82 (38) vs.88 (39)|0.90*|  
*Valor de p para diferença entre os 3 grupos; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; AFLIBE: injeção de aflibercepte intravítrea; VEGF: fator de crescimento endotelial vascular.  
**2. Revisões Sistemáticas com meta- análises de comparações diretas e ensaios clínicos randomizados: ranibizumabe (RANI)**  
- **2.1 Grupo intervenção: Ranibizumabe (RANI) ou RANI/Laser versus Controle (laser ou placebo ou RANI ou triancinolona-TRI)**  
**Tabela 54  –** Características dos estudos incluídos na pergunta de pesquisa Q8 que analisaram o ranibizumabe (RANI)  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Chen et al.**<br>**2014**<sup>**127**</sup>|Revisão sistemática<br>com meta- análise<br>(Busca realizada até<br>junho de 2014)|Avaliar a relativa eficácia da<br>monoterapia do RANI ou em<br>combinação com laser versus<br>monoterapia de laser para o<br>tratamento de EMD|Envolve o centro da fóvea:<br>conferido nos estudos<br>primários|7 ECR, 1749 participantes|Monoterapia do RANI<br>RANI em combinação<br>com laser|Monoterapia de laser<br>Laser ou RANI|Baixo Risco de Viés|
|**Yanagida e**<br>**Ueta, 2014**<sup>**134**</sup>|Revisão sistemática<br>com meta- análise<br>(Busca realizada até<br>maio de 2013)|Avaliar a segurança de RANI<br>para EMD|Envolve o centro da fóvea:<br>conferido nos estudos<br>primários|6 ECR, 2459 participantes|RANI|Controle (placebo, laser,<br>TRI)|Baixo Risco de Viés|  
130  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Bressler et**<br>**al. 2016 e**<br>**Elman et al.**<br>**2015**<sup>**93,217**</sup>|ECR, estudo de<br>extensão, DRCRNet|Comparar desfechos visuais e<br>anatômicos a longo prazo do<br>RANI combinado com laser<br>rápido ou retardado versus<br>laser ou TRI + laser com<br>RANI tardio em pacientes<br>com EMD.|Envolve o centro da macula<br>(BCVA entre 20/32 e 20/320<br>CST>300µm)|450 participantes (558<br>olhos)|1)<br>RANI 0.5<br>mg + Laser<br>rápido<br>2)<br>RANI 0.5<br>mg tardio* +<br>laser rápido<br>3)<br>TRI + laser<br>rápido +<br>RANI 0.5<br>mg tardio*<br>* o protocolo inicial foi<br>revisado, os<br>participantesreceberam<br>RANI após 1.5 a 3 de<br>anos de seguimento.|RANI 0.5mg + laser<br>retardado (≥24 semanas)|Baixo Risco de Viés|
|**Bressler et**<br>**al. 2015**<sup>**218**</sup>|ECR, análise<br>exploratória,<br>DRCRNet|Analisar o risco de elevação<br>sustentada da PIO ou a<br>necessidade de<br>tratamentos para olhos com<br>EMD após injeções repetidas<br>de RANI|Envolve o centro da macula<br>que causa o comprometimento<br>da visão; sem glaucoma de<br>anglo aberto|486 participantes (582<br>olhos)|Laser rápido/retardado<br>+ RANI 0.5 mg|Laser rápido + injeção de<br>placebo|**Alto risco de viés**(relato<br>seletivo dos desfechos,<br>desfechos incompletos)|
|**Ishibashi et**<br>**al. 2015**<sup>**219**</sup>|ECR, the REVEAL<br>Study|Avaliar se a monoterapia de<br>RANI 0.5mg ou a combinação<br>com laser é superior a<br>monoterapia a laser para o<br>tratamento de EMD|Envolve o centro da fóvea<br>(BCVA entre 78 e 39 letras;<br>CST não especificado, mas na<br>linha de base CST ≥ 300µm);<br>Focal ou difuso|396 participantes|RANI 0.5 mg + laser<br>placebo<br>RANI 0.5 mg +laser|Laser + injeção de<br>placebo|**Baixo risco de viés**|
|**Berger et al.**<br>**2015**<sup>**90**</sup>|ECR, the RESPOND<br>Study|Comparar a eficácia e<br>segurança do RANI 0.5 mg<br>como monoterapia ou em<br>combinação com laser no<br>tratamento de pacientes com<br>alteração visual causada por<br>EMD|Envolve o centro da fóvea<br>(BCVA entre 78 e 39 letras;<br>CST não especificado, mas na<br>linha de base CRT ≥ 300µm);<br>alteração visual causada por<br>focal ou difuso DME|220 participantes|RANI 0.5 mg<br>RANI 0.5mg + laser|Laser|**Alto risco de viés**<br>(detecção, desfecho<br>incompleto)|  
131  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Googe et al.**<br>**2011**<sup>**220**</sup>|ECR, DRCRNet|Analisar o efeito do RANI ou<br>da TRI em olhos recebendo<br>laser focal/grid para EMD e<br>fotocoagulaçãopanretinal para<br>RD|Envolve o centro da fóvea<br>(CST ≥ 250µm e BCVA ≥ 24<br>letras)|319 participantes (345<br>olhos).<br>Presença de RDNP ou<br>RDP grave; participantes<br>com EMD que receberam<br>fotocoagulação grid/ focal<br>laser e pacientes com RD<br>que receberam<br>panfotocoagulação|RANI 0.5 mg (na linha<br>de base e 4 semanas) +<br>fotocoagulação<br>focal/grid a laser ou<br>panfotocoagulação<br>TRI 4 mg na linha de<br>base + placebo (na<br>semana 4) +<br>fotocoagulação<br>focal/grid a laser ou<br>panfotocoagulação|Injeção de placebo (na<br>linha de base e em 4<br>semanas) +<br>fotocoagulação focal/grid<br>a laser ou<br>panfotocoagulação|**Baixo risco de viés**|  
EMD: edema macular diabético; RD: retinopatia diabética; RDNP: retinopatia diabética não proliferativa; RDP: retinopatia diabética proliferativa; PIO: pressão intraocular; BCVA: acuidade visual de melhor corrigida; ECR: ensaio clínico randomizado; CRT: espessura central da retina; CST: espessura do subcampo central;BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; TRI: injeção de triancinolona acetonida intravítrea.  
**Tabela 55 –** Características da linha de base dos participantes dos ensaios clínicos randomizados que analisaram o ranibizumabe (RANI)  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n**<br>**olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual†,**<br>**Média ETDRS**<br>**(DP) (Intervenção**<br>**vs. Controle)**|**Pressão**<br>**Intraocular**<br>**(mmHg)**|**Espessura da**<br>**retina (µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Chen et al.**<br>**2014**<sup>**127**</sup>|RANI 0.5 mg<br>RANI 0.5mg/<br>Laser|Laser/<br>RANI|394<br>642|713|Variação da<br>média:<br>60.7-  64.9<br>anos|Variação<br>da média:<br>61.5-  67.4<br>anos|NR|NR|NR|NR|NR|12, 24 e 36<br>meses|
|**Yanagida e**<br>**Ueta,**<br>**2014**<sup>**134**</sup>|RANI|Controle<br>(placebo,<br>laser, TRI)|1561|898|Variação da<br>média:<br>61-  64 anos|Variação<br>da média:<br>62-  64<br>anos|41.1-61%|NR|NR|NR|NR|6-12 meses|
|**Bressler et**<br>**al. 2016;**<br>**Elman et al.**<br>**2015**|RANI 0.5 mg<br>+ Laser<br>RANI 0.5 mg<br>tardio* +<br>laser|RANI<br>0.5mg +<br>laser<br>retardado|124<br>198|111|Mediana (IQR):<br>63|63 (57; 69):|56%|Mediana<br>(IQR): 7.3<br>(6,5; 8,2)|Mediana (IQR): 66<br>(57; 73)|NR|Mediana (IQR):<br>395 (321; 498)<br>**|5 anos|  
132  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n**<br>**olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual†,**<br>**Média ETDRS**<br>**(DP) (Intervenção**<br>**vs. Controle)**|**Pressão**<br>**Intraocular**<br>**(mmHg)**|**Espessura da**<br>**retina (µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**(DRCRNet)**<br>**93,217**|TRI + laser +<br>RANI 0.5 mg<br>tardio||125||||||||||
|**Bressler et**<br>**al. 2015**<br>**(DRCRNet)**<br>**218**|RANI|Placebo|322|260|63 (10)|63 (10)|57 vs. 57|NR|NR|16 (3) vs. 16<br>(3)|NR|1 e 3 anos|
|**Ishibashi et**<br>**al. 2015**<br>**(REVEAL)**<br>**219**|RANI 0.5 mg<br>+ laser<br>placebo<br>RANI 0.5 mg<br>+ laser|Laser +<br>injeção de<br>placebo|133<br>132|131|60.7 (9.37)<br>61.2 (10.52)|61.5 (9.68)|60.9 vs. 57.3<br>50.8 vs. 57.3|7.5 (1,02) vs.<br>7.5 (1,10)<br>7.4 (1,05) vs.<br>7.5 (1,10)|58.8 (10.93) vs.<br>58.4 (10.56)<br>58.5 (10.50) vs.<br>58.4 (10.56)|NR<br>NR|419.2 (152.34)<br>vs. 394.7<br>(122.31) **<br>429.9 (158.25)<br>vs. 394.7<br>(122.31)**|12 meses|
|**Berger et al.**<br>**2015**<sup>**90**</sup><br>**(RESPOND**<br>**)**<sup>**90**</sup>|RANI 0.5 mg<br>RANI 0.5mg<br>+ Laser|Laser|75<br>73|72|61.5(9.9)<br>60.8(10.2)|62.8(9.4)|56.0 vs. 59.7<br>64.4 vs. 59.7|7.8 (1,3) vs.<br>7.6 (1,3)<br>7.7 (1,1(vs. 7.6<br>(1,3)|63.1(10.6) vs.<br>61.9(10.6)<br>64.8(9.3) vs.<br>61.9(10.6)|NR|448.5(136.6) vs.<br>458.0(133.1) *<br>422.1(142.3) vs.<br>458.0(133.1) *|3, 6, 9 e 12<br>meses|
|**Googe et al.**<br>**2011**<br>**(DRCRNet)**<br>**220**|RANI 0.5<br>mg+ laser<br>TRI+ injeção<br>de placebo+<br>laser|Placebo +<br>laser|113<br>109|123|Mediana<br>(IQR): 57 (48,<br>64)<br>Mediana<br>(IQR): 58 (49,<br>64)|Mediana<br>(IQR):<br>54 (45, 61)|58 vs. 64<br>60 vs. 64|Mediana<br>(IQR): 8.1<br>(7,1; 9,9) vs.<br>7.9 (7,0; 9,6)<br>8.1 (7,0; 9,7)<br>vs. 7.9 (7,0;<br>9,6)|Mediana (IQR): 68<br>(56, 75) vs. 67 (52,<br>75)<br>Mediana (IQR): 67<br>(59, 75) vs. 67 (52,<br>75)|NR<br>NR|Mediana (IQR):<br>352 (283, 476)<br>vs. 355 (285,<br>510) *<br>Mediana (IQR):<br>359 (271, 472)<br>vs. 355 (285,<br>510)*|14 (objetivo<br>primário) e 56<br>semanas|  
CRT: espessura central da retina*; CST: espessura do subcampo central**;BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; TRI: injeção de triancinolona acetonida intravítrea; HbA1c: hemoglobina glicada; ETRDS: _EarlyTreatmentDiabeticRetinopathyStudyResearchGroup_ ; DP: desvio padrão; IQR: intervalo interquartil; NR: não reportado.  
**Tabela 56** – Desfechos de eficácia de estudos que compararam ranibizumabe (RANI)  
133  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Chen et al.**<br>**2014**<br>(Revisão<br>Sistemática<br>com meta-<br>análise)<sup>**127**</sup>|RANI 0.5 mg|Laser|**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e 6 meses**<br>DM: 5.65 (IC 95%: 4.44, 6.87); I2= 0%; 5 ECR, 746 pacientes<br>**Ganho de ≥15 letras da linha de base**<br>RR: 2.94 (IC 95%: 1.82, 4.77); I2= 0%; 3 ECR, 561 pacientes<br>**Perda de ≥15 letras da linha de base**<br>RR: 0.21 (IC 95%: 0.06, 0.71); I2= 0%; 2 ECR, 486 pacientes|< 0.00001<br>< 0.00001<br>0.01|**Alteração média da CMT (µm) da linha de base**<br>DM: -57.91 (IC 95%: -77.62, -38.20); I2=10%; 4 ECR,<br>630 pacientes|< 0.00001|
||RANI 0.5 mg +<br>laser|Laser|**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e 6 meses**<br>DM: 5.02 (IC 95%: 3.83, 6.20); I2= 0%; 5 ECR, 1101 pacientes<br>**Ganho de ≥15 letras da linha de base**<br>RR: 2.04 (IC 95%: 1.5, 2.78); I2= 0%; 4 ECR, 910 pacientes|< 0.00001<br>< 0.00001|**Alteração média da CMT (µm) da linha de base**<br>DM: -56.63 (IC 95%: -104.81, -8.44); I2=85%<br>(Significante); 4 ECR, 944 pacientes|0.02|
||||**Perda de ≥15 letras da linha de base**<br>RR: 0.52 (IC 95%: 0.29, 0.95); I2= 0%; 3 ECR, 832 pacientes|0.03|||
||RANI 0.5 mg +<br>laser|RANI|**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e 6 meses**<br>DM: -0.96 (IC 95%: -2.09, 0.17); I2= 40%; 4 ECR, 729 pacientes<br>**Ganho de ≥15 letras da linha de base**<br>RR: 0.89 (IC 95%: 0.64, 1.24); I2= 0%; 3 ECR, 572 pacientes|0.10<br>0.50|**Alteração média da CMT (µm) da linha de base**<br>DM: -18.11 (IC 95%: -38.91, 2.69); I2=0%; 3 ECR, 614<br>pacientes|0.09|
||||**Perda de ≥15 letras da linha de base**<br>RR: 3.03 (IC 95%: 0.83, 11.06); I2= 0%; 2 ECR, 495 pacientes|0.09|||  
134  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Bressler et al.**<br>**2016 e Elman**<br>**et al. 2015**<br>**(DRCRNet)**<br>**93,217**|<br> <br>RANI 0.5 mg +<br>laser<br>RANI 0.5 mg<br>tardio + laser<br>TRI + laser +<br>RANI 0.5 mg<br>tardio|RANI 0.5mg +<br>laser retardado|**Alteração média da acuidade visual (letras) entre a linha de**<br>**base e 5 anos**<br>DM (D) RANI/Laser: +8 (13)<br>DM (D) RANI tardio/ Laser: DM (DP): +5 (14)<br>DM (D) TRI/Laser/RANI tardio: +7 (14)<br>DM (D) RANI/Laser retardado: 10 (13)<br>∆ (IC95%) RANI/Laser - RANI/Laser retardado: 2.0 (-1.6, 5.7)<br>∆ (IC95%) RANI tardio- Laser/Laser retardado: 4.4 (1.2, 7.6)<br>∆ (IC95%) TRI/Laser/RANI tardio- Laser/Laser retardado: 2.8 (-<br>0.9,6.5)|NR<br>NR<br>NR<br>NR<br>0.186<br>0.001<br>0.067|**Redução média da CST (µm) entre a linha de base e 5**<br>**anos**<br>DM (D) RANI/Laser: -167 (168)<br>DM (D) RANI tardio/ Laser: -208 (164)<br>DM (D) TRI/Laser/RANI tardio: -159 (154)<br>DM (D) RANI/Laser retardado: -165 (165)<br>∆ (IC95%) RANI/Laser - RANI/Laser retardado:17 (-15,<br>48)<br>∆ (IC95%) RANI tardio- Laser/Laser retardado: 32 (2,61)<br>∆ (IC95%) TRI/Laser/RANI tardio- Laser/Laser<br>retardado: 7 (-25, 39)|NR<br>NR<br>NR<br>NR<br>0.20<br>0.009<br>0.61|
||RANI 0.5 mg +<br>laser||**Risco Relativo de Ganho de ≥ 10 letras na acuidade visual**<br>**entre a linha de base e 5 anos**<br>RR (IC 95%): 0.79 (0.60, 1.05)|>0.05|||
||RANI 0.5 mg<br>tardio + laser|RANI 0.5mg +<br>laser retardado|RR (IC 95%): 0.71 (0.55, 0.91)|<0.05|NR|NR|
||TRI + laser +<br>RANI 0.5 mg<br>tardio||RR (IC 95%): 0.85 (0.65, 1.11)|>0.05|||
|**Ishibashi et**<br>**al. 2015**<br>**(REVEAL)**<br>**219**|RANI 0.5 mg +<br>laser placebo<br>RANI 0.5 mg<br>+laser|Laser + injeção<br>de placebo|**Alteração média da acuidade visual (BCVA) entre a linha de**<br>**base (letras) e A) do mês 1 ao 12; B) 12 meses**<br>DM (DP) RANI/Laser placebo: A) +5.9 (6.02); B)6,6 (7,68)<br>DM (DP) RANI/ Laser: A) +5.7 (7.20); B) 6,4 (10,67)<br>DM (DP) Laser/injeção de placebo: A) 1.4 (6.49); B) 1,8 (8,27)<br>∆ RANI/Laser placebo - Laser/injeção de placebo: A) 4.7; B)4,9|A) NR; B) NR<br>A) NR; B) NR<br>A) NR; B) NR<br>A) <0.0001*<br>B) <0.0001*|**Redução média da CST (µm) entre a linha de base e 12**<br>**meses**<br>DM (DP) RANI/Laser placebo: -134.6<br>DM (DP) RANI/ Laser: 171.8<br>DM (DP) Laser/injeção de placebo: -57.2|0.0002*<br><0.0001*|
||||∆ RANI/Laser - Laser/injeção de placebo: A) 4.4; B )4,8|A) <0.0001*<br>B)0.0001*|||  
135  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Berger et al.**<br>**2015**<br>**(RESPOND)**<br>**90**|RANI 0.5 mg<br>RANI 0.5mg +<br>Laser|Laser|**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e os meses A)3; B)6; C)9; D)12**<br>DM (IC 95%) RANI: A) 5.3 (3.5,7.0); B)7.1 (5.2,8.9); C)6.9<br>(4.0,9.8); D) 8.9 (7.0,10.7)<br>DM (IC 95%) RANI/ Laser:  A)3.7 (1.1,6.2); B) 5.6(3.6,7.6); C)<br>7.1 (5.2,9.0) D) 8.2(6.0,10.4)<br>DM (IC 95%) Laser: A) 1.4 (–0.1, 3.0); B) 0.9 (–0.9, 2.7); C) –0.2<br>(–3.0, 2.6) D)0.3 (–2.9, 3.5)<br>**Ganho ≥10 letras**<br>%: RANI:49,3; RANI/Laser: 32,9; Laser:13,9|<0.001<br><0.001<br>NR<br>NR|**Redução média da CRT (µm) entre a linha de base e os**<br>**meses A)3; B)6; C)9; D)12**<br>DM (IC 95%) RANI: A) –108.9 (–135.0, –82.9); B) -<br>129.3 (–156.7, –102.0); C) –135.9 (–169.5, –102.3); D) –<br>143.5 (–177.5, –109.4)<br>DM (IC 95%) RANI/ Laser: A) –105.7 (–135.9, –75.5);<br>B) –114.2 (–140.7, –87.8); C) –138.1 (–168.3, –107.8) D)<br>–152.2 (–185.5, –119.0)<br>DM (IC 95%) Laser: A) –32.5 (–59.9, –5.1);<br>B) –64.4 (–91.8, –36.9); C) –85.8 (–119.5, –52.2) D) –<br>107.1 (–143.9, –70.2)|NR<br>NR<br>NR|
|**Googe et al.**<br>**2011**<br>**(DRCRNet)**<br>**220**|RANI 0.5 mg +<br>laser<br>TRI+ injeção<br>de placebo+<br>laser|Laser +<br>Injeção de<br>placebo|**Alteração média (DP) da acuidade visual entre a linha de base**<br>**(letras) A) 14 semanas B) 56 semanas**<br>DM (DP) RANI/Laser: A) +1 (11); B) -4 (21)<br>DM (DP) TRI/injeção de placebo/ laser: A) +2 (11); B) -5 (16)<br>DM (DP) Laser/ Injeção de placebo:  A) -4 (14); B) -6 (17)<br>∆ (IC 95%) RANI/Laser - Laser/injeção de placebo: A) +5,6 (2.2-<br>9.0); B)1.9 (-3.7, 7.5)|A) <0.001*<br>B) 0.44*<br>A) <0.001*<br>B)0.63*<br>A) <0.001<br>B) 0.44|**Redução média (DP) da CST (µm) entre a linha de**<br>**base e A)14 semanas e B) 56 semanas**<br>DM (DP) RANI/Laser: A) -39 (127); B) -52 (227)<br>DM (DP) TRI/injeção de placebo/ laser: - 92 (115); B) -40<br>(138)<br>DM (DP) Laser/ Injeção de placebo:  A) -5 (113); B) -71<br>(156)<br>∆ (IC 95%) RANI/Laser - Laser/injeção de placebo: A) -<br>35 (-64, -26); B) +22 (-22, +66)|A) 0.01*<br>B) NR<br>A) <0.01*<br>B) NR<br>A) 0.007<br>B) 0.25|
||||∆ (IC 95%)TRI/injeção de placebo/ laser- injeção de placebo: A)<br>6.7 (3.2, 10.1); B) 1.2 (-4.4, +6.8)|A) <0.001<br>B) 0.63|∆ (IC 95%)TRI/injeção de placebo/ laser- injeção de<br>placebo: A) -100 (-128, -71); B) +15 (-30, +60)|A) <0.001<br>B) 0.45|  
*Valor de p intervenção versus controle; CRT: espessura central da retina; CST: espessura do subcampo central; CMT: espessura macular central; ECR: ensaio clínico randomizado; BCVA: acuidade visual de melhor corrigida; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; TRI: injeção de triancinolona intravítreo; ∆: diferença; DM: diferença de médias; OR: Oddsratio ou razão de chances; RR: risco relativo; IC 95%: intervalo de confiança; DP: desvio padrãoI2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises..  
**Tabela 57** **<mark>–</mark>** <mark>Desfechos de segurança</mark> de revisões sistemáticas com meta-análise de comparações direta que compararam ranibizumabe (RANI)  
136  
|**Eventos Adversos**|**Autor, ano: Yanagida e Ueta, 2014**<sup>**134**</sup><br>(Revisão Sistemática com meta-análise)<br>**RANI vs. Controle**|**Valor de p**|**Autor, ano: Chen et al. 2014**<sup>**127**</sup><br>(Revisão Sistemática com meta-análise)<br>**Monoterapia de RANI/ RANI combinado com laser vs.**<br>**Laser**|**Valor de p**|
|---|---|---|---|---|
|**Acidente vascular cerebral**|RR: 0.80 (IC 95% 0.37, 1.73); I2= 0%; 6 ECR, 2456 participantes|0.57|NR|NR|
|**Infarto do Miocárdio**|RR: 0.91 (IC 95% 0.46, 1.80); I2= 0%; 6 ECR, 2456 participantes|0.78|NR|NR|
|**Mortalidade Vascular**|RR: 1.29 (IC 95% 0.58, 2.86); I2= 0%; 4 ECR, 1718 participantes|0.53|NR|NR|
|**Mortalidade geral**|RR: 1.92 (IC 95% 0.78, 4.73); I2= 0%; 4 ECR, 1372 participantes|0.16|NR|NR|
|**Eventos**<br>**AdversosCardiovasculares**|NR|NR|RR: 0.94 (IC 95% 0.25, 3.50); I2= 58%; 6 ECR, 1530<br>participantes|0.92|  
ECR: ensaio clínico randomizado; RANI: injeção de ranibizumabe intravítrea; RR: risco relativo; IC 95%: intervalo de confiança; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas metaanálises; NR: não reportado.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Tabela 58** **<mark>–</mark>** <mark>Desfechos de segurança d</mark> e ensaios clínicos randomizados que compararam ranibizumabe (RANI) -->
|**Autor, ano:**<br>**Eventos Adversos**|**Bressler et al. 2016 e**<br>**Elman et al. 2015**<br>**(DRCRNet)**<sup>**93,217**</sup><br>**RANI/Laser vs. RANI**<br>**tardio/laser vs. TRI/**<br>**RANI tardio/Laser vs.**<br>**RANI/Laser retardado**|**Valor de**<br>**p**|**Bressler et al. 2015**<br>**(DRCRNet)**<br>**218**<br>**RANI vs. Placebo**|**Valor de**<br>**p**|**Ishibashi et al.**<br>**2015 (REVEAL)**<br>**219**<br>**RANI 0.5 mg vs.**<br>**RANI 0.5 mg/**<br>**laser vs. Laser**|**Valor de**<br>**p**|**Berger et al. 2015**<br>**(RESPOND)**<br>**90**<br>**RANI 0.5 mg vs.**<br>**RANI 0.5 mg/ laser vs.**<br>**Laser**<br>|**Valor de**<br>**p**|**Googe et al.**<br>**2011 (DRCRNet)**<br>**220**<br>**RANI/ Laser vs.**<br>**TRI/Placebo/Laser vs.**<br>**Placebo/Laser**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|---|---|
|**PIO elevada**|n (%)(≥10mmHg):26<br>(14) vs. 43 (15) vs. 83<br>(45) vs. 15 (8)<br>(≥30mmHg): 13 (4%)<br>vs.7 (4%) vs.56 (30%)<br>vs.7 (4%)||n (%)(≥10mmHg): 6<br>vs. 9|NR|NR|NR|n (%): 10(13.3) vs. 8(11.0)<br>vs.3(4.1)|<br>NR|n (%)  em A)* e B)**<br>(>10mmHg): A) 0 (0);<br>B) 6 (5) vs. A) 20 (17);<br>B) 10 (9) vs. A) 3 (2);<br>B) 6 (5)<br>(≥30mmHg): A)0 (0);<br>B)4 (4) vs. A)5 (4); B)<br>4 (4) vs. A)2 (2); B) 4<br>(3)|NR|  
137  
|**Autor, ano:**|**Bressler et al. 2016 e**<br>**Elman et al. 2015**<br>**(DRCRNet)**<sup>**93,217**</sup>||**Bressler et al. 2015**<br>||**Ishibashi et al.**<br>**2015 (REVEAL)**<br>**219**||**Berger et al. 2015**<br>**(RESPOND)**<br>**90**||**Googe et al.**<br>**2011 (DRCRNet)**<br>**220**||
|---|---|---|---|---|---|---|---|---|---|---|
||<br>**RANI/Laser vs RANI**|**Valor de**<br>|**(DRCRNet)**<br>**218**|**Valor de**<br>||**Valor de**<br>|**V**|**alor de**<br>||**Valor de p**|
|**Eventos Adversos**|**.**<br>**tardio/laser vs. TRI/**<br>**RANI tardio/Laser vs.**<br>**RANI/Laser retardado**|**p**|**RANI vs. Placebo**|**p**|**RANI 0.5 mg vs.**<br>**RANI 0.5 mg/**<br>**laser vs. Laser**|**p**|**RANI 0.5 mg vs.**<br>**RANI 0.5 mg/ laser vs.**<br>**Laser**|**p**|**RANI/ Laser vs.**<br>**TRI/Placebo/Laser vs.**<br>**Placebo/Laser**||
|**Probabilidade**<br>**cumulativa de**<br>**elevação sustentada**<br>**da PIO ou do**<br>**aumento da terapia**<br>**hipotensora ocular**<br>**aos 3 anos**|NR|NR|%: 9.5 vs. 3.4<br>HR (IC 95%): 2.9<br>(1.0- 7.9)<br>∆ RANI- Placebo:<br>6.1% (−0.2, 12.3)|NR<br>0.01<br>>0.05|NR|NR|NR|NR|NR|NR|
|**Hemorragia**<br>**conjuntival**|NR|NR|NR|NR|n (%):17 (12.8)<br>vs.12 (9.1) vs. 7<br>(5.5)|NR|n (%): 6(8.0) vs. 11(15.1)<br>vs. 2(2.7)|NR|NR|NR|
|**Hemorragia vítrea**|n (%):18 (10) vs. 44 (15)<br>vs. 22 (12) vs. 20 (11)|NR|NR|NR|NR|NR|n (%): 2(2.7%) vs. 5(6.8) vs.<br>7(9.5)|<br>NR|n (%) em A)* e B)**:<br>A) 6 (5); B) 25 (23) vs.<br>A) 7 (6); B) 20 (18) vs.<br>A) 16 (12); B) 28 (21)|NR|
|**Nasofaringite**|NR|NR|NR|NR|n (%):10 (7.5)<br>vs. 10 (7.6) vs.8<br>(6.3)|NR|n (%): 5(6.7) vs. 5(6.8) vs.<br>4(5.4)|NR|NR|NR|
|**Descolamento da**<br>**retina**|n (%): 0 vs. 2 (<1) vs. 2<br>(1) vs.1 (<1)|NR|NR|NR|NR|NR|n (%): 2(2.7) vs.1(1.4) vs.<br>1(1.4)|NR|n (%) em A)* e B)**:<br>A) 1 (1); B) 5 (5) vs. A)<br>1 (1); B)1 (1) vs. A) 4<br>(3)<br>B) 4 (3)|NR|
|**EA oculares sérios**|NR|NR|NR|NR|n (%):1 (0.8)<br>vs.6<br>(4.5) vs. 1 (0.8)|NR|NR|NR|NR|NR|
|**EA não oculares**<br>**sérios**|NR|NR|NR|NR|n (%):14 (10.5)<br>vs. 13 (9.8) vs.<br>18 (14.1)|NR|NR|NR|NR|NR|  
138  
|**Autor, ano:**|**Bressler et al. 2016 e**<br>**Elman et al. 2015**<br> <sup>**93217**</sup>||**Bressler et al. 2015**||**Ishibashi et al.**<br>**2015 (REVEAL)**||**Berger et al. 2015**<br>**(RESPOND)**||**Googe et al.**<br>**2011 (DRCRNet)**||
|---|---|---|---|---|---|---|---|---|---|---|
||**(DRCRNet)**<sup>**,**</sup>||**(DRCRNet)**||<br>**219**||<br>**90**||<br>**220**||
||**RANI/Laser vs. RANI**|**Valor de**<br>**p**|<br>**218**|**Valor de**<br>**p**||**Valor de**<br>**p**||**Valor de**<br>**p**||**Valor de p**|
|**Eventos Adversos**|**tardio/laser vs. TRI/**<br>**RANI tardio/Laser vs.**<br>**RANI/Laser retardado**||**RANI vs. Placebo**||**RANI 0.5 mg vs.**<br>**RANI 0.5 mg/**<br>**laser vs. Laser**||**RANI 0.5 mg vs.**<br>**RANI 0.5 mg/ laser vs.**<br>**Laser**||**RANI/ Laser vs.**<br>**TRI/Placebo/Laser vs.**<br>**Placebo/Laser**||
|**EA oculares**|NR|NR|NR|NR|n (%): 43 (32.3)<br>vs. 44<br>(33.3) vs. 28<br>(21.9)|NR|NR|NR|NR|NR|
|**EA não oculares**|NR|NR|NR|NR|n (%): 69 (51.9)<br>vs. 70 (53.0) vs.<br>69 (53.9)|NR|NR|NR|NR|NR|
|**Participantes com**<br>**pelo menos 1 EA**|NR|NR|NR|NR|NR|NR|n (%): 53 (70.7) vs. 49<br>(67.1) vs. 44 (59.5)|NR|NR|NR|
|**Eventos adversos**<br>**sistêmicos totais**|NR|NR|NR|NR|n (%):16 (12.0)<br>vs. 12 (9.1) vs.<br>14 (10.9)|NR|NR|NR|NR|NR|
|**Hipertensão**|NR|NR|NR|NR|n (%): 8 (6.0) vs.<br>8 (6.1) vs. 7 (5.5)|NR|n (%): 5(6.7) vs. 2(2.7) vs<br>5(6.8)|.<br>NR|NR|NR|
|**Infarto do**<br>**Miocárdio**|n (%):7 (4) vs. 8 (6)<br>vs.11 (6) vs. 8 (4)|NR|NR|NR|n (%): 4 (3.0) vs.<br>2 (1.5) vs. 5 (3.9)|NR|NR|NR|NR|NR|
|**Outros eventos**<br>**tromboembolíticos**<br>**arteriais**|NR|NR|NR|NR|n (%): 5 (3.8) vs.<br>3 (2.3) vs. 1 (0.8)|NR|NR|NR|NR|NR|
|**Proteinúria**|NR|NR|NR|NR|n (%): 1 (0.8) vs.<br>0 (0.0) vs. 2 (1.6)|NR|NR|NR|NR|NR|
|**EA**<br>**cardiovasculares/**<br>**cerebrais**|n (%): 21 (11) vs. 33 (25)<br>vs.29 (16) vs. 32 (17)|NR|NR|NR|NR|NR|NR|NR|NR|NR|  
A) *:14 semanas; B) **:14-56 semanas; EA: eventos adversos; PIO: pressão intraocular; RANI: injeção de ranibizumabe intravítrea; TRI: injeção de triancinolona intravítreo; ∆: diferença; HR: hazardratio; DP: desvio padrão; NR: não reportado.  
139

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3.1 Grupo intervenção: Bevacizumabe (BEVA) versus Controle (BEVA/ triancinolona-TRI ou fotocoagulação focal)** -->
**Tabela 59 –** Características dos estudos incluídos na pergunta de pesquisa Q8 que analisaram o bevacizumabe (BEVA)  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Tipo de edema**<br>**macular diabético**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Jin et al.**<br>**2015**<sup>**213**</sup><br>(Revisão<br>Sistemática<br>com meta-<br>análise)|Revisão sistemática com<br>meta- análise (Busca<br>realizada até agosto de<br>2014)|Avaliar a relativa eficácia<br>da monoterapia do BEVA<br>versus BEVA em<br>combinação com TRI para<br>o tratamento de EMD|Envolve o centro da<br>fóvea: conferido nos<br>estudos primários|7 ECR, 696 olhos<br>(BEVA: 252/ BEVA+<br>TRI:243)|Monoterapia do BEVA (1.25 mg/0.05<br>ml)|BEVA em combinação<br>com TRI (1.25mg/2mg)|Baixo Risco de Viés|
|**Scott et al.**<br>**2007**<sup>**125**</sup>|ECR, DRCRNet|Prover dados sobre os<br>efeitos a curto prazo do<br>BEVA para EMD.|Envolve o centro da<br>mácula (BVCA entre<br>24 e 78 e CRT ≥ 275<br>µm)|121 participantes (121<br>olhos) -sendo 109<br>elegíveis para análise|1) BEVA 1.25 mg na linha de base e<br>em 6 semanas<br>(BEVA 1.25 mg 0, 6 semanas)<br>2) BEVA 2.5 mg na linha de base e em<br>6 semanas<br>(BEVA 2.5 mg 0, 6 semanas)<br>3) BEVA 1.25 mg na linha de base +<br>injeção de placebo em 6 semanas<br>(BEVA 1.25 mg)|5) fotocoagulação focal na<br>linha de base|Risco de Viés Alto<br>(Desfecho incompleto)|
||||||4) BEVA 1.25 mg na linha de base +<br>fotocoagulação focal em 3 semanas+<br>BEVA 1.25mg em 6 semanas<br>(BEVA 1.25mg 0,6 semanas +Laser)|||  
EMD: edema macular diabético; BCVA: acuidade visual de melhor corrigida; ECR: ensaio clínico randomizado; CRT: espessura central da retina;;BEVA: injeção de bevacizumabe intravítrea; TRI: injeção de triancinolona acetonida intravítrea.  
**Tabela 60 –** Características da linha de base dos participantes dos ensaios clínicos randomizados que analisaram o bevacizumabe (BEVA)  
140  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual,**<br>**média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da**<br>**retina (µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Jin et al.**<br>**2015**<sup>**213**</sup>|BEVA|BEVA em<br>combinaçã<br>o com TRI|NR (252)|NR (243)|Variação d<br>52.11-  6|a média:<br>2.3 anos|NR|NR|NR|NR|3-6 meses|
||1) BEVA<br>1.25 mg 0, 6<br>semanas||22||Mediana<br>(IQR): 63 (54,<br>73)||73 vs. 53|Mediana<br>(IQR): 7.4<br>(5,9; 7,8) vs.<br>7.0 (6,5; 8,2)|Mediana (IQR): 65 (60,<br>70) vs. 64 (50, 70)|Mediana (IQR):<br>397 (320, 538)<br>vs. 441 (354,<br>512) *||
|**Scott et al.**<br>**2007**<br>**(DRCRNet)**<br>**125**|2) BEVA 2.5<br>mg 0, 6<br>semanas|5)<br>fotocoagul<br>ação focal|24|19|Mediana<br>(IQR): 68 (59,<br>75)|Mediana<br>(IQR): 64<br>(57, 72)|62 vs. 53|Mediana<br>(IQR): 7.3<br>(6,4; 8,4) vs.<br>7.0 (6,5; 8,2)|Mediana (IQR): 63 (57,<br>71) vs. 64 (50, 70)|Mediana (IQR):<br>446 (342, 543)<br>vs. 441 (354,<br>512) *|3, 6, 9, 12, 18 e 24<br>semanas|
||3) BEVA<br>1.25 mg||22||Mediana<br>(IQR): 60 (54,<br>75)||59 vs. 53|Mediana<br>(IQR): 6.7 vs.<br>7.0 (6,5; 8,2)|Mediana (IQR): 64 (52,<br>68) vs. 64 (50, 70)|Mediana (IQR):<br>406 (353, 520)<br>vs. 441 (354,<br>512) *||
|CST:<br>espessur<br>_EarlyTreatmentD_|a<br>do<br>subcam<br>_iabeticRetinopa_|po<br>central*<br>_thyStudyResea_|;BEVA:<br>injeç<br>_rchGroup_; DP:|ão<br>de<br>bevac<br>desvio padrão; I|izumabe<br>intrav<br>QR: intervalo int|ítrea;<br>TRI=<br>erquartil; NR: nã|injeção<br>de<br>tria<br>o reportado.|ncinolona<br>acet|onida<br>intravítrea;<br>HbA1|c:<br>hemoglobina|glicada;<br>ETRDS:|

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Tabela 61 –** Desfechos de eficácia dos estudos que compararam bevacizumabe (BEVA) -->
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Jin et al.**<br>**2015**<sup>**213**</sup>|BEVA|BEVA/TRI|**Alteração média da acuidade visual (letras)**<br>**entre a linha de base e A) 3 meses e B) 6 meses**<br>**A)**DM: 0.07 (IC 95%: 0.01, 0.13); I2= 73%<br>(Significativo); 7 ECR, 492 olhos<br>B) DM: -0.01 (IC 95%: -0.11, 0.09); I2= 78%<br>(Significativo); 4 ECR, 299 olhos|0.03<br>0.87|**Alteração da CMT (µm) entre a linha de base e A) 3 meses e B)**<br>**6 meses**<br>DM: 48.40 (IC 95%: 30.23, 66.57); I2= 27%; 7 ECR, 492 olhos<br>DM: 0.47(IC 95%: -24.11, -25.04); I2= 0%; 4 ECR, 299 olhos|<0.00001<br>0.97|  
141  
|**Scott et al.**<br>**2007**<br>**(DRCRNet)**<br>**125**|1) BEVA<br>1.25 mg 0, 6<br>semanas<br>2) BEVA 2.5<br>mg 0, 6<br>semanas<br>3) BEVA<br>1.25 mg,<br>basal<br>4) BEVA<br>1.25mg 0, 6<br>semanas +<br>Laser|5)<br>Fotocoagulaçã<br>o focal|**Ganho médio da acuidade visual de melhor**<br>**corrigida (letras) entre a linha de base e as**<br>**semanas A)3; B) 6; C) 9; D)12**<br>1)Mediana (IQR): A) 5 (-1, 8); B)5 ( -2, 12); C)7<br>(2, 10); D)5 (1, 12)<br>2)Mediana (IQR): A) 6 (1, 9); B) 6 (2, 11); C) 8<br>(3, 12); D) 7 (4, 11)<br>3)Mediana (IQR): A) 2 (0, 7); B)3 (-2, 6); C)1 (-3,<br>5); D) 4 (-3, 7)<br>4)Mediana (IQR): A) 0 (-6, 6); B) 0 (-4, 6); C) -2 (<br>-5, 11); D) 0 (-5, 8)<br>5)Mediana (IQR): A) -2 (-7, 3); B) 1 ( -6, 6); C) 3<br>(-5, 6);  D) -1 (-6, 5)|<0,05 para os<br>grupos 1 e 2<br>em relação ao<br>basal, em 3 e<br>12 semanas|**Redução média da CST (µm) entre a linha de base entre a linha**<br>**de base e as semanas A)3; B) 6; C) 9; D)12**<br>1)Mediana (IQR): A) -35 (- 155, 6); B) -35 (-112, 6); C) -74 ( -113,<br>-31); D) -56 (-120, -6)<br>2)Mediana (IQR): A) -86 ( -131, -11); B) -42 (-127, -10); C) -56 (-<br>127, -20); D) -47 (-125, -16)<br>3)Mediana (IQR): A) -3 (-49, 7); B) -17 (-58, 25); C) 5 (-34, 53); D)<br>-5 (-41, 53)<br>4)Mediana (IQR): A) -13 (-104, 26); B) -20 (-73, 35); C) -48 (-128,<br>33); D) -40 (-103, 33)<br>5)Mediana (IQR): A)  21 ( -62, 79); B) -40 ( -105, 73); C) - 53 (-<br>115, 53); D) -40 ( -146, 85)|0,009 e <0,001<br>respectivamente para<br>grupos 1 e 2 em relação<br>ao basal, em 3 semanas|
|---|---|---|---|---|---|---|  
ECR: ensaios clínicos randomizados; CST: espessura do subcampo central; CRT: espessura macular central; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; TRI: injeção de triancinolona intravítreo; DM: diferença de médias; IC 95%: intervalo de confiança; DP: desvio padrão; IQR: intervalo interquartil; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas metaanálises.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **Tabela 62 –** Desfechos de segurança dos estudos que compararam bevacizumabe (BEVA) -->
|**Autor, ano:**<br>**Eventos Adversos**|**Jin et al. 2015**<sup>**213**</sup><br>(Revisão Sistemática com meta-análise)<br>**BEVA vs. BEVA/TRI**|**Valor de p**|**Scott et al. 2007 (DRCRNet)**<sup>**125**</sup><br>**BEVA 1.25 mg 0, 6 semanas vs. BEVA 2.5 mg 0, 6 semanas vs.**<br>**BEVA 1.25 mg vs.BEVA 1.25mg 0, 6 semanas + Laser vs.**<br>**fotocoagulação focal**|**Valor de p**|
|---|---|---|---|---|
|PIO elevada|n (%) total (>21mmHg): 0 vs. 9 olhos (Máx-min:0-8.3%); 5<br>ECR; 546 olhos|NR|NR|NR|
|Elevação da pressão arterial|NR|NR|N participantes: 0 vs. 1 vs. 1 vs. 1 vs. 1 vs. 1|>0.05|  
BEVA: injeção de bevacizumabe intravítrea; TRI: injeção de triancinolona intravítreo;PIO: pressão intraocular; NR: não reportado.  
**4. Revisão Sistemática com meta-análise de comparações direta e indiretas e ensaios clínicos randomizados: aflibercepte (AFLIBE)**

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4.1 Grupo intervenção: Aflibercepte (AFLIBE) versus Controle (ranibizumabe- RANI, dexametasona (DEXA), laser)** -->
**Tabela 63 –** Características dos estudos que compararam aflibercepte (AFLIBE)  
142  
|**Autor (es)**|**Desenho de estudo**|**Objetivo**|**Tipo de edema**<br>**macular diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Korobelnik**<br>**et al. 2015**<sup>**215**</sup>|Revisão Sistemática<br>com meta-análise<br>direta e indireta<br>(Última atualização<br>outubro de 2013)|Analisar a eficácia clínica do<br>AFLIBE em relação a<br>tratamentos de comparadores de<br>interesse (DEXA, RANI ou<br>FLU) para o gerenciamento de<br>EMD|Envolve o centro da<br>fóvea: confirmados pelo<br>OCT nos estudos<br>primários|11 ECR, 3323<br>participantes|AFLIBE 2 mg 5 doses mensais<br>iniciais e depois a cada 8<br>semanas (2q8)<br>AFLIBE 2q8|RANI 0.5 mg PRN<br>DEXA 0.7mg|**Alto Risco de Viés**<br>(comparações indiretas, não foi<br>fornecido o valor de I2, métrica<br>utilizada para analisar a<br>heterogeneidade estatística)|
|**Brown et al.**<br>**2015 e**<br>**Heier et al.**<br>**2016**<sup>**87,130**</sup>|2 ECR- VISTA e<br>VIVID|Comparar a eficácia e segurança<br>da injeção de AFLIBE com<br>fotocoagulação macular a laser<br>em pacientes com EMD.|Envolve o centro da<br>fóvea (espessamento<br>retiniano envolvendo 1<br>mm da CST e BCVA<br>entre 73 e 24 letras)|872 olhos|AFLIBE 2 mg a cada 4 semanas<br>(2q4)<br>AFLIBE 2 mg 5 doses mensais<br>iniciais e depois a cada 8<br>semanas (2q8)|Fotocoagulação<br>macular a laser|Alto risco de viés (desfecho<br>incompleto|
|**DO et al.**<br>**2012 e DO**<br>**et al. 2011**<br>**(DA**<br>**VINCI)**<br>128,129|ECR- the DA VINCI<br>Study|Comparar as diferentes doses e<br>regimes de dosagens de AFLIBE<br>e fotocoagulação a laser em<br>olhos com EMD|Envolve o centro da<br>mácula (BVCA entre<br>20/40-20/320 e CRT ≥<br>250µm)|221 participantes|AFLIBE 0.5 mg a cada 4<br>semanas + laser placebo (0.5q4);<br>AFLIBE 2 mg a cada 4<br>semanas+ laser placebo +<br>injeção placebo (2q4);<br>AFLIBE 2 mg 3 doses iniciais<br>mensais e depois a cada 8<br>semanas + laser placebo +<br>injeção placebo (2q8);<br>AFLIBE 2 mg 3 doses iniciais<br>mensais e depois quando<br>necessário + laser placebo<br>(2PRN)|Fotocoagulação<br>macular a laser na<br>linha de base e se<br>necessário + injeção<br>de placebo (laser +<br>injeção placebo)|Alto Risco de Viés (desfecho<br>incompleto)|  
EMD: edema macular diabético; BCVA: acuidade visual de melhor corrigida; OCT: Tomografia de coerência óptica; ECR: ensaio clínico randomizado; CRT: espessura central da retina; CST: espessura do subcampo central; AFLIBE: injeção de aflibercepte intravítrea; 2q4: AFLIBE 2 mg a cada 4 semanas; 2q8:AFLIBE 2 mg 5 doses mensais iniciais e depois a cada 8 semanas;  0.5q4: AFLIBE 0.5 mg a cada 4 semanas + laser placebo;2q4:AFLIBE 2 mg a cada 4 semanas + laser placebo + injeção placebo;2q8:AFLIBE 2 mg 3 doses iniciais mensais  e depois a cada 8 semanas + laser placebo + injeção placebo;2PRN: AFLIBE 2 mg 3 doses iniciais mensais e depois quando necessário + laser placebo; RANI: injeção de ranibizumabe intravítrea; FLU: fluocinolona intravítreo; DEXA: dexametasona intravítrea.  
**Tabela 64 -** Características da linha de base dos participantes dos estudos que compararam aflibercepte (AFLIBE)  
143  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n**<br>**olhos)**<br>**intervenç**<br>**ão**|**N (n**<br>**olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual†, média**<br>**EDRS (DP) (Intervenção**<br>**vs. Controle)**|**Espessura da**<br>**retina (µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Korobelnik**<br>**et al. 2015**<br>**215**|AFLIBE 2q8<br>AFLIBE 2q8|RANI 0.5<br>mg PRN<br>DEXA<br>0.7mg|NR|NR|NR|NR|NR|NR|NR|NR|11-12 meses|
|||||||**1)**|**ECR: VISTA**|||||
||AFLIBE 2q4||154||62.0 (11.2)||56.5 vs. 55.2|7.9 (1,6) vs.<br>7.6 (1,7)|58.9 (10.8) vs. 59.7 (10.9)|<sup>485 (157) vs. 483</sup><br>(153) **||
|**Brown et al.**<br>**2015 e Heier**<br>**et al.**|AFLIBE 2q8|Laser|151|154|63.1 (9.4)|61.7 (8.7)|51.7 vs. 55.2|<br>7.9 (1,6) vs.<br>7.6 (1,7)|58.9 (10.8) vs. 59.7 (10.9)|<br><sup>479 (154) vs. 483</sup><br>(153) **|100 e 148 semanas|
|**2016**<sup>**87,130**</sup>||||||**2)**|**ECR: VIVID**|||||
||AFLIBE 2q4||136||62.6 (8.6)||61 vs. 59.1|7.8 (1,5) vs.<br>7.7 (1,3)|60.8 (10.7) vs. 60.8 (10.6)|<sup>502 (144) vs. 540</sup><br>(152) **||
||AFLIBE 2q8|Laser|135|132|64.2 (7.8)|63.9 (8.6)|65.2 vs. 59.1|<br>7.7 (1,4) vs.<br>7.7 (1,3)|58.8 (11.2) vs.60.8 (10.6)|<br>518 (147) vs. 540<br>(152) **|100 e 148 semanas|
||AFLIBE 0.5q4<br>+ laser placebo||44||62.3 (10.7)||54.5 vs. 61.4|8.10 (1,91)<br>vs.7.93 (1,84)|59.3 (11.2) vs. 57.6 (12.5)|426.1 (128.3) vs.<br>440.6 (145.4) *||
|**DO et al.**<br>**2012 e DO**|AFLIBE + laser<br>placebo +<br>injeção placebo|Laser +|44||62.1 (10.5)||61.4 vs. 61.4|8.08 (1,94)<br>vs.7.93 (1,84)|59.9 (10.1) vs. 57.6 (12.5)|456.6 (135.0) vs.<br>440.6 (145.4) *||
|**et al. 2011**||injeção de||44||64.0 (8.1)|||||24 e 52 semanas|
|**(DA VINCI)**<br>128,129|AFLIBE a2q8 +<br>laser placebo +<br>injeção placebo|placebo|42||62.5 (11.5)||52.4 vs. 61.4|7.85 (1,72)<br>vs.7.93 (1,84)|58.8 (12.2) vs. 57.6 (12.5)|434.8 (111.8) vs.<br>440.6 (145.4) *||
||AFLIBE<br>2PRN+ laser<br>placebo||45||60.7 (8.7)||64.4 vs. 61.4|7.97 (1,71)<br>vs.7.93 (1,84)|59.6 (11.1) vs. 57.6 (12.5)|426.6 (152.4)vs.<br>440.6 (145.4) *||  
ECR: ensaio clínico randomizado; CRT: espessura central da retina*; CST: espessura do subcampo central**;HbA1c: hemoglobina glicada; ETRDS: _EarlyTreatmentDiabeticRetinopathyStudyResearchGroup_ ; AFLIBE: injeção de aflibercepte intravítrea; 2q4: AFLIBE 2 mg a cada 4 semanas; 2q8:AFLIBE 2 mg 5 doses mensais iniciais e depois a cada 8 semanas;  0.5q4: AFLIBE 0.5 mg a cada 4 semanas + laser placebo;2q4:AFLIBE 2 mg a cada 4 semanas + laser placebo + injeção placebo;2q8:AFLIBE 2 mg 3 doses iniciais mensais  e depois a cada 8 semanas + laser placebo + injeção placebo;2PRN: AFLIBE 2 mg 3 doses iniciais mensais e depois quando necessário + laser placebo; DP: desvio padrão; NR: não reportado.  
**Tabela 65** **<mark>–</mark>** <mark>Desfechos de eficácia</mark> dos estudos que compararam aflibercepte (AFLIBE)  
144  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Korobelnik**<br>**et al. 2015**<br>**215**(Revisão|AFLIBE 2q8/<br>Laser placebo|Laser/ injeção de<br>placebo|**Meta-análise de comparação direta**<br>**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e 12 meses**<br>DM: 10.01 (IC 95% 8.32, 11.69); I2= 0%; 2 ECR|<0.05|NR|NR|
|Sistemática<br>|||||||
|com meta-<br>análise<br>direta e<br>indireta)|RANI 0.5 mg<br>PRN/ Laser<br>placebo|Laser/ injeção de<br>placebo|DM: 5.19 (IC 95% 3.63, 6.75); I2= 0%; 2 ECR|<0.05|||
||AFLIBE 2q8|RANI 0.5 mg<br>PRN|**Meta-análise de comparação indireta**<br>**1) Método de comparações de tratamentos**<br>**mistos(MTC): A) Efeito fixo; B) Efeito randômico e 2)**<br>**Método de Bucher: C) Efeito fixo; D) Efeito randômico**<br>**Alteração média da acuidade visual de melhor**corrigida<br>(letras) entre a linha de base e 12 meses<br>1) A) DM: 4.67 (IC 95% 2.45, 6.87); I2= NR; 10 ECR,<br>3060 participantes|A) <0.05|||
||||B) DM: 4.67 (IC 95% 1.85,7.52);<br>2) C) DM: 4.82 (IC 95% 2.52–7.11); I2= NR; 4 ECR, 1611<br>participantes|B) <0.05<br>C) <0.05|||
||||D) DM: 4.82 (IC 95% 2.52–7.11);<br>**Ganho ≥ 10 letras após 12 meses**<br>1) A) RR: 1.32 (IC 95% 0.98,1.78); I2= NR; 6 ECR, 2810<br>participantes<br>OR:1.64 (IC 95% 0.97, 2.78);|D) <0.05<br>A) >0.05;>0.05;|||
||||B) RR: 1.19 (IC 95% 0.90, 1.57);<br>OR:1.59 (IC 95% 0.75, 3.35);|B) >0.05;>0.05;|||
||||2) C) RR: 0.993 (IC 95% 0.65, 1.52); I2= NR; 4 ECR, 1611<br>participantes<br>OR:1.32 (IC 95% 0.74, 2.35);|C) >0.05;>0.05;|||
||||D) RR: 1.00 (IC 95% 0.6, 1.66); I2= NR; 4 ECR, 1611<br>participantes<br>OR:1.32(IC 95% 0.65,2.68);|D) >0.05;>0.05;|||  
145  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
||||**Perda ≥ 10 letras após 12 meses**<br>1) A) RR: 0.27 (IC 95% 0.07, 0.90); I2= NR; 6 ECR, 2810<br>participantes<br>OR: 0.27 (IC 95% 0.07, 0.90);|A) <0.05;<0.05;|NR|NR|
||||B) RR: 0.28 (IC 95% 0.06, 1.29);<br>OR: 0.26 (IC 95% 0.05, 1.31);|B) >0.05;>0.05;|||
||||2) C) RR: 0.31 (IC 95% 0.09; 1.04]); I2= NR; 4 ECR, 1611<br>participantes<br>OR: 0.28 (IC 95% 0.08; 0.99);|C) >0.05;<0.05;|||
||||D) RR: 0.31 (IC 95% 0.09, 1.09);<br>OR: 0.27 (IC 95% 0.08, 0.94);|D) >0.05;<0.05;|||
|**Korobelnik**<br>**et al. 2015**<br>**215**(Revisão|||**Ganho ≥ 15 letras após 12 meses**<br>1) A) RR: 1.78 (IC 95% 0.96, 3.29); I2= NR; 6 ECR, 2810<br>participantes|A) >0.05;>0.05;|||
|Sistemática|||OR: 1.90 (IC 95% 0.95, 3.75);||||
|com meta-|||||||
|análise<br>indireta)|||B) RR: 1.42 (IC 95% 0.93, 2.24]);<br>OR: 1.87 (IC 95% 0.87, 4.16);|B) >0.05;>0.05;|||
||||2) C) RR: 1.49 (IC 95% 0.78, 2.85); I2= NR; 4 ECR, 1611<br>participantes<br>OR: 1.74 (IC 95% 0.83, 3.65);|C) >0.05;>0.05;|||
||||D) RR: 1.49 (IC 95% 0.78, 2.85]);<br>OR: 1.74 (IC 95% 0.83, 3.65);|D) >0.05;>0.05;|||
||||**Perda ≥ 15 letras após 12 meses**<br>1) A) RR: 0.13 (IC 95% 0.004, 1.35); I2= NR; 6 ECR, 2810<br>participantes<br>OR: 0.13 (IC 95% 0.004, 1.35);|A) >0.05;>0.05;|||
||||B) RR: 0.14 (IC 95% 0.007–1.52);<br>OR: 0.14 (IC 95% 0.006, 1.53);|B) >0.05;>0.05;|||
||||2) C) RR: 0.24(IC 95% 0.03, 1.90]); I2= NR; 4 ECR, 1611<br>participantes<br>OR: 0.23 (IC 95% 0.03, 1.86);|C) >0.05;>0.05;|||
||||D) RR: 0.26 (IC 95% 0.03, 2.11]); I2= NR; 4 ECR,<br>OR: 0.23(IC 95% 0.03–1.86);|D) >0.05;>0.05;|||  
146  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
||||**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e as semanas A) 100 e B)**<br>**148**<br>**1) ECR: VISTA; 2) ECR: VIVID**<br>1) 2q4 DM (DP): A) 11.5 (13.8); B) 10.4 (14.2)<br>1) 2q8 DM (DP): A) 11.1 (10.7); B) 10.5 (12.7)<br>1)) Laser DM (DP): A) 0.9 (13.9); B) 1.4 (14.5)|1) A) <0.0001; B)<br><0.0001▲|**Alteração média da CST (µm) entre a**<br>**linha de base e a semana A) 100 e B)**<br>**148**<br>**1) ECR: VISTA; 2) ECR: VIVID**<br>1) 2q4: A) -191.4 (180.0); B) -200.4<br>1) 2q8: A) -191.1 (160.7); B) -190.1<br>1)) Laser: A) -83.9 (179.3); B) -109.8|1) A) <0.0001; B)<br><0.0001▲|
|**Brown et**<br>**al. 2015 e**<br>**Heier et al.**<br>**2016**<sup>**87,130**</sup><br>**(VISTA/**<br>**VIVID)**|2q4<br>2q8|Laser|2)2q4 DM (DP): A) 11.4 (11.2); B) 10.3 (12.5)<br>2) 2q8 DM (DP): A) 9.4 (10.5); B) 11.7 (10.1)<br>2) Laser DM (DP): A) 0.7 (11.8); B) 1.6 (12.7)<br>**Porcentagem de pacientes com ganho de ≥15 letras na**<br>**semana A) 100 e B) 148**<br>1) 2q4 %: A) 38.3; B) 42.9<br>1) 2q8 %: A) 33.1; B) 35.8<br>1) Laser %: A) 13.0; B) 13.6|2) A) <0.0001; B)<br><0.0001▲<br>1) A) <0,001; B)<br><0,0001▲|2)2q4: A) -211.8 (150.9); B) -215.2<br>2) 2q8: A) -195.8 141.7; B) -202.8<br>2) Laser:A) -85.7 (145.8); B) -122.6|2) A) <0.0001; B)<br><0.0001▲|
||||2) 2q4 %: A) 38.2; B) 41.2<br>2) 2q8 %: A) 31.1; B) 42.2<br>2) Laser %: A) 12.1; B) 18.9|2) A) ≤0,0001; B)<br><0,0001 ▲|||
||||**Alteração média da acuidade visual de melhor corrigida**<br>**entre a linha de base (letras) e A) 24, B) 52 semanas**<br>54 A 6 11||**Média da redução da CRT (µm) entre**<br>**a linha de base e A)24 e B)52 semanas**<br>0.5q4: A) -144.6; B) -165.4||
|**DO et al.**<br>**2012 e DO**<br>**et al. 2011**|0.5q4<br>2q4|Laser + injeção|0.q: ) 8.; B).0<br>2q4: A) 11.4; B)13.1<br>2q8: A) 8.5; B) 9.7<br>2PRN: A) 10.3; B)12.0<br>Laser/ injeção de placebo: A) 2.5; B) -1.3|A) ≤ 0.0085; B)<br>≤0.0001▲|2q4: A) -194.5.4; B) -227.4<br>2q8: A) -127.3; B) - 187.8<br>2PRN: A) -153.3; B) - 180.3<br>Laser/ injeção de placebo: A) -67.9<br>B) - 58.4|A) <0.0001; B) <0.0002▲|
|**(DA**<br>**VINCI)**<br>128,129|2q8<br>2PRN|de placebo|**Porcentagem de pacientes com ganho de ≥15 letras**<br>**entre a linha de base (letras) e A) 24, B) 52 semanas**<br>0.5q4 %: A:34; B:40.9<br>2q4 %: A:32; B: 45.5<br>2q8%: A:17; B: 23.8<br>2PRN %: A:27; B:42.2<br>Laser/ injeção de placebo %: A:21; B:11.4|A) NR; B)0.0031▲<br>A) NR; B)0.0007▲<br>A) NR; B)0.1608▲<br>A) NR; B)0.0016▲|||  
Ajustado pela acuidade visual de melhor corrigida da linha de base*; Método de comparação de tratamentos mistos (MTC) foi utilizado quando houvesse uma rede conectada com três ou mais estudos**;Método de Bucher ou método de comparação indireta ajustada foi utilizado quando pelo menos um estudo de comparação direta “headtohead” tivesse sido encontrado***; Valor de p intervenção versus controle▲; RANI:  injeção de ranibizumabe intravítrea; AFLIBE: injeção de aflibercepte intravítrea; 2q4: AFLIBE 2 mg a cada 4 semanas; 2q8:AFLIBE 2 mg 5 doses mensais iniciais e depois a cada 8 semanas;  0.5q4: AFLIBE 0.5 mg a cada 4 semanas + laser placebo;2q4:AFLIBE 2 mg a cada 4 semanas + laser placebo + injeção placebo;2q8:AFLIBE 2 mg 3 doses iniciais mensais  e depois a cada 8 semanas + laser placebo + injeção placebo;2PRN: AFLIBE 2 mg 3 doses iniciais mensais e depois quando necessário + laser placebo; DM: diferença de médias; OR: oddsratio ou razão de chances; RR: risco relativo; IC 95%: intervalo de confiança; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises; NR: não reportado; NA: não se aplica.  
147  
**Tabela 66 –** Desfechos de segurança dos estudos que compararam aflibercepte (AFLIBE)  
|**Eventos Adversos**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com meta-<br>análise indireta)<br>**AFLIBE 2q8 vs. RANI 05.mg**<br>**PRN (Método MTC) ***|**Valor de p**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com<br>meta-análise indireta)<br>**AFLIBE 2q8 vs. DEXA 0.7**<br>**mg (Método de Bucher) ****|**Valor de p**|**Brown et al. 2015 e**<br>**Heier et al. 2016**<br>**(VISTA/ VIVID)**<br>**87,130**<br>**2q4 vs. 2q8 vs. laser**|**Valor de p**|**DO et al. 2012 e**<br>**DO et al. 2011**<br>**(DA VINCI)**<br>128,129<br>**0.5q4 vs. 2q4**<br>**vs.2q8 vs. 2PRN**<br>**vs. laser**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
|**Eventos Adversos**<br>**totais**|A) RR: 0.79 (IC 95% 0.55,1.10);<br>I2= NR; 5 ECR, 1739<br>participantes; OR:0.61 (IC 95%<br>0.29,1.26);<br>B) RR: 0.88 (IC 95% 0.64,1.15);<br>OR:0.58 (IC 95% 0.18, 1.82)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|NR|NR|NR|NR|
|**Eventos Adversos**<br>**totais**|A) RR: 0.76 (IC 95% 0.47, 1.26);<br>I2= NR; 5 ECR, 1739<br>participantes; OR:0.71 (IC 95%<br>0.39,1.32);<br>B) RR: 0.82 (IC 95% 0.47, 1.42);<br>OR:0.74 (IC 95% 0.31, 1.72)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|NR|NR|NR|NR|
|**Eventos Adversos**<br>**oculares sérios totais**|A) RR: 0.28 (IC 95%0.06, 1.24);<br>I2= NR; 5 ECR, 1739<br>participantes; OR:0.27 (IC 95%<br>0.05,1.25);<br>B) RR: 0.30 (IC 95% 0.05, 2.49);<br>OR:0.28 (IC 95% 0.05, 2.58)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|A) ▲ e B) ◊ n(%):<br>(A)15 (5.2); B)25<br>(8.6) vs. A) 11 (3.8);<br>B) 18 (6.3) vs. A) 17<br>(5.9); B)18 (6.3)|>0.05|NR|NR|
|**Eventos Adversos não**<br>**oculares sérios totais**|A) RR: 0.60 (IC 95% 0.32, 1.14);<br>I2= NR; 4 ECR, 1343<br>participantes; OR:0.53 (IC 95%<br>0.24,1.17);<br>B) RR: 0.67 (IC 95% 0.29, 1.66);<br>OR:0.53(IC 95% 0.12,2.11)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|NR|NR|NR|NR|  
148  
|**Eventos Adversos**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com meta-<br>análise indireta)<br>**AFLIBE 2q8 vs. RANI 05.mg**<br>**PRN (Método MTC) ***|**Valor de p**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com<br>meta-análise indireta)<br>**AFLIBE 2q8 vs. DEXA 0.7**<br>**mg (Método de Bucher) ****|**Valor de p**|**Brown et al. 2015 e**<br>**Heier et al. 2016**<br>**(VISTA/ VIVID)**<br>**87,130**<br>**2q4 vs. 2q8 vs. laser**|**Valor de p**|**DO et al. 2012 e**<br>**DO et al. 2011**<br>**(DA VINCI)**<br>128,129<br>**0.5q4 vs. 2q4**<br>**vs.2q8 vs. 2PRN**<br>**vs. laser**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
|**Eventos Adversos**<br>**oculares totais**|A) RR: 0.75 (IC 95% 0.54,1.05);<br>I2= NR; 4 ECR, 1343<br>participantes; OR:0.60 (IC 95%<br>0.32,1.09);<br>B) RR: 0.85 (IC 95% 0.58,1.25);<br>OR:0.58 (IC 95% 0.16, 1.87)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|NR|NR|NR|NR|
|**Eventos Adversos não**<br>**oculares totais**|A) RR: 1.09 (IC 95% 0.87, 1.40);<br>I2= NR; 3 ECR, 1215<br>participantes; OR:1.27 (IC 95%<br>0.65, 2.42);<br>B) RR: 1.03 (IC 95% 0.80,1.56);<br>OR:1.22 (IC 95% 0.23, 6.18)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|NR|NR|NR|NR|
|**EA**<br>**tromboembolísticos**<br>**definidos pela**<br>**Colaboração dos**<br>**participantes de**<br>**ensaios clínicos**|NR|NR|NR|NR|A) ▲ e B) ◊ n (%):<br>A)21 (7.2); B)31<br>(10.7) vs. A) 16 (5.6);<br>B) 21 (7.3) vs. A) 12<br>(4.2)<br>B)22 (7.7)|NR|NR|NR|
|**Participantes com**<br>**pelo menos um EA**<br>**sistêmico sério**|NR|NR|NR|NR|NR|NR|Em 52 semanas: n<br>(%): 14 (31.8) vs.<br>13 (29.5) vs. 12<br>(28.6) vs. 6 (13.3)<br>vs. 10 (22.7)|NR|
|**Dor nos olhos**|A) RR: 0.98 (IC 95% 0.38, 2.70);<br>I2= NR; 4 ECR, 1343<br>participantes; OR: 0.97 (IC 95%<br>0.34, 2.94);<br>B) RR: 0.96 (IC 95% 0.23, 3.91);<br>OR:0.95 (IC 95% 0.17, 4.75)|A) >0.05; >0.05;<br>B) >0.05; >0.05|A) RR: 0.80 (IC 95% 0.29,<br>2.21); I2= NR; 3 ECR, 1123<br>participantes; OR: 0.79 (IC<br>95% 0.26,2.38);<br>B) RR: 0.78 (IC 95% 0.27,<br>2.21); OR: 0.76 (IC 95% 0.24,<br>2.38)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|n (%)●: 3 (6.8) vs.<br>4 (9.1) vs. 3 (7.1)<br>vs. 5 (11.1) vs. 2<br>(4.5)|NR|  
149  
|**Eventos Adversos**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com meta-<br>análise indireta)<br>**AFLIBE 2q8 vs. RANI 05.mg**<br>**PRN (Método MTC) ***|**Valor de p**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com<br>meta-análise indireta)<br>**AFLIBE 2q8 vs. DEXA 0.7**<br>**mg (Método de Bucher) ****|**Valor de p**|**Brown et al. 2015 e**<br>**Heier et al. 2016**<br>**(VISTA/ VIVID)**<br>**87,130**<br>**2q4 vs. 2q8 vs. laser**|**Valor de p**|**DO et al. 2012 e**<br>**DO et al. 2011**<br>**(DA VINCI)**<br>128,129<br>**0.5q4 vs. 2q4**<br>**vs.2q8 vs. 2PRN**<br>**vs. laser**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
|**Catarata**|A) RR: 3.93 (IC 95% 0.77, 32.74);<br>I2= NR; 3 ECR, 1215<br>participantes; OR: 4.09 (IC 95%<br>0.76,34.86);<br>B) RR: 3.83 (IC 95% 0.52, 43.72);<br>OR:4.16 (IC 95% 0.49, 50.98);|A) >0.05; >0.05;<br>B) >0.05; >0.05|A) RR: 0.42 (IC 95% 0.13,<br>1.39); I2= NR; 3 ECR, 1123<br>participantes; OR: 0.40 (IC<br>95% 0.11, 1.40);<br>B) RR: 0.43 (IC 95% 0.12,<br>1.63); OR: 0.41 (IC 95% 0.10,<br>1.64)|A) >0.05; >0.05;<br>B) >0.05; >0.05|A) ▲ e B) ◊ n (%): A)<br>7 (2.4); B)9 (3.1) vs. 3<br>(1.0); B) 6 (2.1) vs. A)<br>1 (0.3); B)1 (0.3)|NR|NR|NR|
|**Hipertensão**|A) RR: 0.95 (IC 95% 0.44, 2.07);<br>I2= NR; 4 ECR, 1343<br>participantes; OR: 0.95 (IC 95%<br>0.40, 2.22);<br>B) RR: 0.95 (IC 95% 0.37, 2.55);<br>OR:0.94 (IC 95% 0.28, 3.14)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|NR|NR|n (%)●:4 (9.1%)<br>vs. 7 (15.9%) vs. 2<br>(4.8%) vs. 4<br>(8.9%) vs. 3<br>(6.8%)<br>Em 52 semanas: 0<br>vs. 2 (4.5%) vs. 1<br>(2.4%) vs.  0 vs. 0|NR|
|**Mortalidade por**<br>**todas as causas**|A) RR: 2.90 (IC 95% 0.20, 50.4);<br>I2= NR;3 ECR, 1215 participantes;<br>OR: 3.06 (IC 95% 0.18, 60.01);<br>B) RR: 2.76 (IC 95% 0.13, 79.02);<br>OR:2.83 (IC 95% 0.11, 85.27)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|NR|NR|NR|NR|
|**Edema macular**|NR|NR|A) RR: 0.22 (IC 95% 0.03,<br>1.67); I2= NR; 2 ECR, 657<br>participantes; OR: 0.21 (IC<br>95% 0.03, 1.69);<br>B) RR: 0.22 (IC 95% 0.03,<br>1.64); OR: 0.21 (IC 95% 0.03,<br>1.70)|A) >0.05;<br>>0.05;<br>B) >0.05; >0.05|NR|NR|(%)●:0 vs. 0 vs. 0<br>vs. 0 vs. 1 (2.3%)|NR|  
150  
|**Eventos Adversos**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com meta-<br>análise indireta)<br>**AFLIBE 2q8 vs. RANI 05.mg**<br>**PRN (Método MTC) ***|**Valor de p**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com<br>meta-análise indireta)<br>**AFLIBE 2q8 vs. DEXA 0.7**<br>**mg (Método de Bucher) ****|**Valor de p**|**Brown et al. 2015 e**<br>**Heier et al. 2016**<br>**(VISTA/ VIVID)**<br>**87,130**<br>**2q4 vs. 2q8 vs. laser**|**Valor de p**|**DO et al. 2012 e**<br>**DO et al. 2011**<br>**(DA VINCI)**<br>128,129<br>**0.5q4 vs. 2q4**<br>**vs.2q8 vs. 2PRN**<br>**vs. laser**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
|**Acuidade visual**<br>**reduzida**|NR|NR|A) RR: 0.64 (IC 95% 0.24,<br>1.67); I2= NR; 3 ECR, 1123<br>participantes; OR: 0.61 (IC<br>95% 0.21, 1.77);<br>B) RR: 0.64 (IC 95% 0.17,<br>2.40); OR :0.61 (IC 95% 0.21,<br>1.77)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|n (%)●: 0 vs. 0 vs.<br>0 vs. 1 (2.3%)|NR|
|**Hemorragia Vítrea**|NR|NR|A) RR: 0.30 (IC 95% 0.07,<br>1.39); I2= NR;3 ECR, 1123<br>participantes; OR: 0.28 (IC<br>95% 0.06, 1.38);<br>B) RR: 0.18 (IC 95% 0.02,<br>1.65]); OR: 0.16 (IC 95%<br>0.02, 1.54)|A) >0.05; >0.05;<br>B) >0.05; >0.05|NR|NR|n(%)●: 0 vs. 0 vs.<br>0 vs. 0 vs. 1<br>(2.3%)|NR|
|**Hemorragia**<br>**Conjuntival**|NR|NR|NR|NR|NR|NR|n (%)●: 8 (18.2)<br>vs. 5 (11.4) vs. 11<br>(26.2) vs. 9 (20.0)<br>vs. 8 (18.2)|NR|
|**PIO elevada**|NR|NR|A) RR: 0.08 (IC 95% 0.02,<br>0.42); I2= NR;3 ECR, 1123<br>participantes; OR: 0.07 (IC<br>95% 0.01, 0.37);<br>B) RR: 0.13 (IC 95% 0.01,<br>1.79); OR: 0.11 (IC 95% 0.01,<br>1.54)|A) <0.05; <0.05;<br>B) >0.05; >0.05|NR|NR|n(%)●: 5 (11.4)<br>vs. 6 (13.6) vs. 4<br>(9.5) vs. 2 (4.4) vs.<br>1 (2.3)|NR|
|**Hiperemia ocular**|NR|NR|NR|NR|NR|NR|n (%)●: 4 (9.1) vs.<br>1 (2.3) vs. 3 (7.1)<br>vs. 3 (6.7) vs. 2<br>(4.5%)|NR|  
151  
|**Eventos Adversos**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com meta-<br>análise indireta)<br>**AFLIBE 2q8 vs. RANI 05.mg**<br>**PRN (Método MTC) ***|**Valor de p**|**Korobelnik et al. 2015**<sup>**215**</sup><br>(Revisão Sistemática com<br>meta-análise indireta)<br>**AFLIBE 2q8 vs. DEXA 0.7**<br>**mg (Método de Bucher) ****|**Valor de p**|**Brown et al. 2015 e**<br>**Heier et al. 2016**<br>**(VISTA/ VIVID)**<br>**87,130**<br>**2q4 vs. 2q8 vs. laser**|**Valor de p**|<br>**DO et al. 2012 e**<br>**DO et al. 2011**<br>**(DA VINCI)**<br>128,129<br>**0.5q4 vs. 2q4**<br>**vs.2q8 vs. 2PRN**<br>**vs. laser**|**Valor de p**|
|---|---|---|---|---|---|---|---|---|
|**Flocos vítreos**|NR|NR|NR|NR|NR|NR|n (%)●: 4 (9.1) vs.<br>2 (4.5) vs. 2 (4.8)<br>vs. 1 (2.2) vs. 2<br>(4.5%)|NR|  
*Método de comparação de tratamentos mistos (MTC) foi utilizado quando houvesse uma rede conectada com três ou mais estudos; ** Método de Bucher ou método de comparação indireta ajustada foi utilizado quando pelo menos um estudo de comparação direta “headtohead” tivesse sido encontrado; Em 100 semanas de seguimento▲; Em 148 semanas de seguimento ◊; Em 24 semanas de seguimento●; RANI: injeção de ranibizumabe intravítrea; AFLIBE: injeção de aflibercepte intravítrea; 2q4: AFLIBE 2 mg a cada 4 semanas; 2q8:AFLIBE 2 mg 5 doses mensais iniciais e depois a cada 8 semanas;  0.5q4: AFLIBE 0.5 mg a cada 4 semanas + laser placebo;2q4:AFLIBE 2 mg a cada 4 semanas + laser placebo + injeção placebo;2q8:AFLIBE 2 mg 3 doses iniciais mensais  e depois a cada 8 semanas + laser placebo + injeção placebo;2PRN: AFLIBE 2 mg 3 doses iniciais mensais e depois quando necessário + laser placebo; DEXA: dexametasona intravítreo; PIO: pressão intraocular; PRN: _pro re nata_ , ou se necessário; OR: _oddsratio_ ou razão de chances; RR: risco relativo; IC 95%: intervalo de confiança; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises; NR: não reportado.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **5. Revisão Sistemática com meta-análise de comparações diretas e ensaios clínicos randomizados: esteroides intravítreos** -->
**5.1 Grupo Intervenção: análises incluindo mais de um esteroide intravítreo**  
**Tabela 67 –** Características da revisão sistemática com meta-análise que comparou mais de um esteroide intravítreo  
|**Autor (es)**|**Desenho de**<br>**estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Grover e Chong,**<br>**2008**<sup>**212**</sup>|Revisão<br>Sistemática com<br>Meta-análise<br>(Última<br>atualização junho<br>de 2007)|Efetividade e segurança de<br>esteroides intravítreos no<br>tratamento EMD|Envolve o centro da fóvea:<br>confirmados pelo OCT nos<br>estudos primários|7 ECR, 632 olhos|TRI<br>FLU<br>DEXA|Outros tratamentos (sem<br>tratamento, placebo,<br>fotocoagulação laser grid macular)<br>Outros tratamentos (tratamento<br>padrão ou observação)<br>Outros tratamentos (sem<br>tratamento, placebo)|Baixo Risco de Viés|  
EMD: edema macular diabético; OCT: Tomografia de coerência óptica; ECR: ensaio clínico randomizado; ECR: ensaios clínicos randomizados; CST: espessura do subcampo central; TRI: injeção de triancinolona intravítreo; FLU: implante de acetonido de fluocinolona intravítreo; DEXA: implante de dexametasona intravítreo.  
152  
**Tabela 68 –** Características da linha de base dos participantes dos estudos incluídos na revisão sistemática com meta-análise que comparou mais de um esteroide intravítreo  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção vs.**<br>**Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Acuidade visual,**<br>**média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da**<br>**retina (µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Grover e**<br>**Chong,**<br>**2008**<sup>**212**</sup>|TRI<br>FLU<br>DEXA|Outros<br>tratamento<br>s|NR|NR|NR|NR|NR|NR|NR|NR|3,6,9,12,24 E 36<br>meses|  
TRI: injeção de triancinolona intravítreo; FLU: implante de acetonido de fluocinolona intravítreo; DEXA: implante de dexametasona intravítreo;ETRDS: EarlyTreatmentDiabeticRetinopathyStudyResearchGroup; Masc.: masculino; HbA1c: hemoglobina glicada; DP: desvio padrão; NR: não reportado.  
**Tabela 69 –** Desfechos de eficácia da revisão sistemática com meta-análise que comparou mais de um esteroide intravítreo  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor dep**|**Desfechos Anatômicos:**|**Valor dep**|
|---|---|---|---|---|---|---|
|**Grover e**<br>**Chong,**<br>**2008**<sup>**212**</sup>|TRI|Outros<br>tratamentos|**Alteração na acuidade visual (logMAR) em A) 3**<br>**meses; B) 6 meses; C) 9 meses e D) 24 meses.**<br>A) DM: -0.15 (IC 95%: -0.21, -0.09); I2= 71%|<0.00001|**Alteração na espessura da retina (µm) em A) 3 meses;**<br>**B) 6 meses; C) 9 meses e D) 24 meses**<br>A) DM: -131.97 (IC 95%: -169.08, -94.86); I2= 49%; 2|<0.00001|
|(Revisão<br>Sistemática|||(Significativo); 3 ECR, NR pacientes||ECR, NR pacientes||
|com Meta-<br>análise)|||B) DM: -0.23 (IC 95%: -0.33, -0.13); I2= 0%; 2 ECR,<br>NR pacientes|<0.00001|B) DM: -135.0 (IC 95%: -194.50, -75.50); I2= NA; 1<br>ECR, NR pacientes|<0.00001|
||||C) DM: -0.29 (IC 95%: -0.47, -0.11); I2= NA; 1 ECR,<br>NR pacientes|0.0016|C) DM: -133.0 (IC 95%: -199.86, -66.14); I2= NA; 1<br>ECR, NR pacientes|0.000097|
||||D) DM: -0.11 (IC 95%: -0.20, -0.03); I2= NA; 1 ECR,<br>NR pacientes|0.0086|D) DM: -59.0 (IC 95%: -103.50, -14.50); I2= NA; 1<br>ECR, NR pacientes|0.0094|
||||**Ganho ≥1 linhas na acuidade visual aos A) 3 meses;**<br>**B) 6 meses e C) 24 meses**||||
||||A) RR: 2.85 (IC 95%: 1.59, 5.10); I2= 0%; 2 ECR, 105<br>pacientes|0.00043|||
||||B) RR: 1.25 (IC 95%: 0.66, 2.38); I2= NA%; 1 ECR, 32<br>pacientes|0.49|||
||||C) RR: 2.17 (IC 95%: 1.15, 4.11); I2= NA; 1 ECR, 69<br>pacientes|0.017|||
||||**Ganho ≥3 linhas na acuidade visual aos A) 3 meses e**<br>**B) 24 meses**||||  
153  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor dep**|**Desfechos Anatômicos:**|**Valor dep**|
|---|---|---|---|---|---|---|
||||A) RR: 1.92 (IC 95%: 0.50, 7.40); I2= 41%; 2 ECR, 105<br>pacientes|0.34|||
||||B) RR: 4.12 (IC 95%: 0.48, 34.99); I2= NA%; 1 ECR,<br>69 pacientes|0.19|||
||FLU|Outros<br>tratamentos|**Ganho ≥3 linhas na acuidade visual aos A) 12 meses e**<br>**B) 36 meses**<br>A) RR: 2.73 (IC 95%: 0.63, 11.92); I2= NA; 1 ECR, 69<br>pacientes|>0.05|||
||||B) RR: 1.93 (IC 95%: 1.02, 3.66); I2= NA; 1 ECR, 197<br>pacientes|<0.05|||
||DEXA|Outros<br>tratamentos|**Melhoria de >2 linhas na acuidade visual aos 3 meses**<br>RR:2.75 (IC 95% 1.59, 4.76)|<0.05|||  
TRI: injeção de triancinolona intravítreo; FLU: implante de acetonido de fluocinolona intravítreo; DEXA: implante de dexametasona intravítreo; RR: risco relativo; DM: diferença de médias; IC 95%: intervalo de confiança; NR: não reportado; não se aplica; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.  
**Tabela 70 –** Desfechos de segurança dos estudos incluídos na revisão sistemática de Grover e Chong, 2008<sup>_212_</sup> que comparou mais de um esteroide intravítreo  
|**Eventos**<br>**Adversos**|**Sutter et al.**<br>**2004**<br>**TRI vs.**<br>**Placebo**|**Valor**<br>**de p**|**Avitable et al.**<br>**2005**<br>**TRI vs. Laser**|**Valor**<br>**de p**|**Jonas et**<br>**al. 2006**<br>**TRI vs.**<br>**Placebo**|**Valor**<br>**de p**|**Audren et al.**<br>**2006**<br>**TRI vs. Sem**<br>**tratamento**|**Valor**<br>**de p**|**Pearson et al. 2002**<br>**FLU vs. Tratamento**<br>**padrão (laser ou**<br>**observação)**|**Valor**<br>**de p**|**Pearson et al.**<br>**2005**<br>**FLU vs.**<br>**Tratamento**<br>**padrão (laser**<br>**ou observação)**|**Valor**<br>**de p**|**Kuppermann et**<br>**al. 2007**<br>**DEXA vs.**<br>**Observação**|**Valor de**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**EA sérios**<br>**oculares**|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total: 18<br>(43.1%)  de 41 vs. 6<br>(21%) de 28|NR|NR|NR|NR|<0.001|
|**IOP elevada**|n (%) total:<br>10 (29%) de<br>34 vs. 1(3%)<br>de 35|NR|n (%) total: 9<br>(21%) de 42<br>vs. 0 (0%)|NR|n (%)<br>total:17<br>(65%) de<br>25 vs. NR|0.003|n (%) total: 9<br>(53%)  de 17<br>vs. NR|NR|n (%) total: 5 (12%)<br>de 41 vs. 0 (0%) de<br>28|NR|n (%) total: 75<br>(59%) de 127<br>vs. 4 (6%) de 70||n (%) total: 30<br>(15%)  de 201 vs.<br>4 (4%) de 105|<0.001|  
154  
||**Sutter et al.**<br>**2004**||**Avitable et al.**||**Jonas et**<br>**al 2006**||**Audren et al.**<br>**2006**||**Pearson et al. 2002**||**Pearson et al.**<br>**2005**||**Kuppermann et**<br>**al 2007**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||**Valor**<br>|**2005**|**Valor**<br>|**.**|**Valor**<br>||**Valor**<br>|**FLU vs. Tratamento**|**Valor**<br>|**FLU vs.**|**Valor**<br>|<br>**.**|**Valor de**<br>|
|**Eventos**<br>**Adversos**|**TRI vs.**<br>**Placebo**|**de p**|**TRI vs. Laser**|**de p**|**TRI vs.**<br>**Placebo**|**de p**|**TRI vs. Sem**<br>**tratamento**|**de p**|**padrão (laser ou**<br>**observação)**|**de p**|**Tratamento**<br>**padrão (laser**<br>**ou observação)**|**de p**|**DEXA vs.**<br>**Observação**|**p**|
|**Progressão de**<br>**catarata**|n (%) total:<br>12 (43%) de<br>28 vs. 3<br>(14%) de 21|NR|n (%) total: 1<br>(2%) de 42 vs.<br>0 (0%)|NR|NR|NR|n (%) total:<br>0(0%) vs. 0<br>(0%)|NR|n (%) total: 10 (24%)<br>de 41 vs. 1 (4%) de<br>28|NR|n (%) total: 55<br>(43%) de 127<br>vs. NR||NR|NR|
|**Redução na**<br>**Acuidade**<br>**Visual**|n (%) total: 6<br>(18%) de 34<br>vs. 13 (37%)<br>de 35|NR|NR|NR|NR|NR|NR|NR|n (%) total: 6 (14%)<br>de 41 vs. 1 (4%) de<br>28|NR|n (%) total: 24<br>(19%) de 127<br>vs. 11 (16%) de<br>70||n (%) total: 4<br>(2%) de 201 vs. 4<br>(4%) de 105|NR|
|**Hemorragia**<br>**Vítrea**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total:43<br>(24%) de 201 vs.<br>0 (0%)|<0.001|
|**Hemorragia**<br>**Conjuntival**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total: 23<br>(11.4%) de 201<br>vs. 0|<0.001|
|**Flocos Vítreos**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total:<br>22(10.94%) de<br>201 vs. 2 (1.9%)<br>de 105|0.004|
|**Dor nos olhos**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total: 34<br>(16.91%) de 201<br>vs. 5(4.8)de 105|0.004|
|**Irritação nos**<br>**olhos**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total: 27<br>(13.43%) de 201<br>vs. 2 (1.9%) de<br>105|<0.001|
|**Olhos**<br>**avermelhados**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total: 15<br>(7.41%0 de 201<br>vs. 1(1%)de 105|0.01|
|**Glaucoma**|n (%) total:<br>10 (29%) de<br>34 vs. 0|NR|NR|NR|NR|NR|NR|NR|NR|NR|n (%) total: 37<br>(29%) de 127<br>vs. NR|NR|NR|NR|  
TRI: injeção de triancinolona intravítreo; FLU: implante de acetonido de fluocinolona intravítreo; DEXA: implante de dexametasona intravítreo; NR: não reportado.  
155

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **5.2 Grupo Intervenção: Injeção de triancinolona intravítrea (TRI) versus Grupo Controle: laser ou placebo** -->
**Tabela 71 –** Características dos ensaios clínicos randomizados que compararam triancinolona (TRI)  
|**Autor (es)**|**Desenho de**<br>**estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Gillies et al. 2010 e**<br>**Gillies et al. 2011**<sup>**221,222**</sup>|ECR|Determinar se o pré-tratamento<br>com TRI antes de fotocoagulação<br>a laser é efetivo para o tratamento<br>de olhos com EMD|Difuso ou focal. Envolve o<br>centro da fóvea (CMT ≥<br>250µm e BCVA entre 17 e<br>70 letras)|54 participantes<br>(84 olhos)|TRI 4 mg + laser após 6<br>meses|Injeção de placebo<br>+ laser|Baixo Risco de Viés|
|**Beck et al. 2009 e**<br>**DRCRNet, 2008**<sup>**223,224**</sup>|ECR, DRCRNet|Avaliar a eficácia e segurança do<br>TRI  1 mg e 4 mg em<br>comparação com fotocoagulação<br>focal/grid para o tratamento de<br>EMD|Envolve o centro da fóvea<br>(CST ≥ 250µm e BCVA<br>entre 73 e 24 letras)|693 participantes<br>(840 olhos)|TRI 4 mg<br>TRI 1 mg|Fotocoagulação<br>Grid/focal (laser)|Baixo Risco de Viés<br>(**DRCR.net, 2008**)<br>Alto risco de viés (**Beck at**<br>**al. 2009**) – Desfecho<br>incompleto|
|**Chew et al. 2007**<sup>**225**</sup>|ECR, DRCRNet,<br>piloto|Avaliar a segurança e eficácia das<br>injeções sub-Tenon de TRI<br>anterior e posterior isoladamente<br>ou em combinação com<br>fotocoagulação focal no<br>tratamento de EMD.|Moderado; envolve o<br>centro da fóvea (CST ≥<br>250µm e BCVA ≥ 69<br>letras)|109 pacientes (129<br>olhos)|1) sub-Tenon posterior<br>TRI  40 mg;<br>2) sub-Tenon anterior TRI<br>20 mg;<br>3) sub-Tenon posterior<br>TRI 40 mg seguido por<br>fotocoagulação focal na<br>semana 4;<br>4) sub-Tenon anterior TRI<br>20 mg seguido por<br>fotocoagulação focal na<br>semana 4;|5) Fotocoagulação<br>focal (ETDRS<br>modificado)|Alto risco de viés<br>(Cegamento dos<br>investigadores, relato<br>seletivo de desfechos)|
|**Lam et al. 2007**<sup>**226**</sup>|ECR|Avaliar a eficácia de TRI seguido<br>de fotocoagulação grid a laser,<br>monoterapia de TRI e<br>monoterapia de fotocoagulação a<br>laser no tratamento de EMD|Envolve o centro da fóvea:<br>CST ≥ 250µm (Protocolo<br>ETDRS)|111 participantes<br>(111 olhos)|TRI 4 mg<br>TRI 4 mg seguido de<br>fotocoagulação grid a laser|Fotocoagulação<br>grid a laser|Alto risco de viés<br>(cegamento dos<br>investigadores)|  
EMD: edema macular diabético; ECR: ensaio clínico randomizado; TRI: injeção de triancinolona intravítreo; CMT: espessura macular central; BVCA: acuidade visual melhor corrigida;ETRDS: _EarlyTreatmentDiabeticRetinopathyStudyResearchGroup_ .  
**Tabela 72 –** Características da linha de base dos participantes dos ensaios clínicos randomizados que analisaram injeção de triancinolona acetonida intravítrea (TRI)  
156  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Acuidade visual,**<br>**média ETDRS**<br>**(DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Gillies et al.**<br>**2010 e**<br>**Gillies et al.**<br>**2011**<sup>**221,222**</sup>|TRI + laser|Injeção de<br>placebo +<br>laser|42|42|65.4 (9.5)|66.9 (8.9)|61.9 vs. 52.4|7.81 (1,44) vs. 8.02<br>(1,63)|55.2 (12.5) vs.<br>55.5 (11.3)|482.1 (122.7) vs. 477.4<br>(155.5) *|6 e 24 meses|
|**Beck et al.**<br>**2009 e**<br>**DRCRNet,**<br>**2008**<sup>**223,224**</sup>|TRI 4 mg<br>TRI 1 mg|Laser|254<br>256|330|51<br>53|50|51 vs. 50<br>53 vs. 50|Mediana (IQR) 7.6<br>(6,8; 8,8) vs. 7.5<br>(6,6; 8,5)<br>Mediana (IQR) 7.5<br>(6,8; 8,4) vs. 7.5<br>(6,6; 8,5)|Mediana (IQR):<br>62 (52, 67) vs.62<br>(53, 67)<br>Mediana (IQR):<br>62 (54, 67) vs. 62<br>(53, 67)|Mediana (IQR):<br>396 (323, 484) vs. 398<br>(329, 505) **<br>Mediana (IQR): **<br>405 (327, 514) vs. 398<br>(329, 505) ***|2 e 3 anos|
|**Chew et al.**<br>**2007**<sup>**225**</sup>|TRI<br>TRI + laser<br>grid|Laser grid|38<br>36|37|67.2 (9.8)<br>64.7 (10.3)|66.2 (8.2)|47 vs. 41<br>58 vs. 41|NR|Logmar 0.72<br>(0.34) vs..0.64<br>(0.36)<br>Logmar 0.69<br>(0.34) vs..0.64<br>(0.36)|396 (91) vs. 385 (100)<br>**<br>424 (108) vs. 385 (100)<br>**|(2,4 ,9 ,17 e 26<br>semanas) 6<br>meses|
|**Lam et al.**<br>**2007**<sup>**226**</sup>|1) sub-Tenon<br>posterior TRI<br>40 mg||21||58 (12)||38 vs. 55|7.3 (1,6) vs. 7.9<br>(1,7)|79 (4) vs. 80 (5)|321 (53) vs. (324 70) **||
||2) sub-Tenon<br>anterior TRI||23||60 (8)||78 vs. 55|8.1 (1,7) vs. 7.9<br>(17)|81 (5) vs. 80 (5)|342 (79) vs. (324 70) **||
||20 mg<br>3) sub-Tenon<br>posterior TRI<br>40 mg + laser|Fotocoagu<br>lação focal|22|38|64 (7)|58 (11)|82 vs. 55|,<br>7.8 (1,3) vs. 7.9<br>(1,7)|79 (7) vs. 80 (5)|319 (59) vs. (324 70) **|4,8 17 e 34<br>semanas|
||4) sub-Tenon<br>anterior TRI<br>20 mg+ laser||25||63 (13)||68 vs. 55|7.5 (1,8) vs. 7.9<br>(1,7)|78 (6) vs. 80 (5)|336 (58) vs. (324 70) **||  
CRT*: espessura central da retina; CST: espessura do subcampo central**; CMT: espessura macular central***; ETRDS: _EarlyTreatmentDiabeticRetinopathyStudyResearchGroup_ ; DP: desvio padrão; IQR: intervalo interquartil; NR: não reportado.  
**Tabela 73 –** Desfechos de eficácia de ensaios clínicos randomizados que compararam injeção de triancinolona acetonida intravítrea (TRI)  
157  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Gillies et al.**<br>**2010 e**|TRI + laser|Injeção de<br>placebo +|**Ganho médio da acuidade visual (letras) aos A) 6 meses B)**<br>**24 meses**||**Redução média da CMT (µm) entre a linha de base e**<br>**A) 6 meses B) 24 meses**||
|**Gillies et al.**<br>**2011**<sup>**221,222**</sup>||laser|DM TRI/Laser: A)1.55; B) 0.76<br>DM injeção de placebo/Laser: A)1.78; B) –1.46<br>**Porcentagem de pacientes com ganho de ≥5 letras na**<br>**acuidade visual aos 6 meses (BCVA)**<br>TRI/Laser %: 43; Injeção de placebo/ Laser %:38<br>**Ganho (OddsRatio) de >10 letras na acuidade visual aos 24**<br>**meses**<br>OR (IC 95%): 2.79 (1.01–7.67)|A)0.909<br>B)0.439<br>0.807<br>0.047|DM TRI/Laser: A) 98.5; B)137.1<br>DM injeção de placebo/Laser: A) 45.8; B)109.6|A)0.016<br>B)0.349|
|**Beck et al.**<br>**2009 e**<br>**DRCRNet,**<br>**2008**<sup>**223,224**</sup>|TRI 4 mg<br>TRI 1 mg|Laser|**Alteração média da acuidade visual (letras) entre a linha de**<br>**base e A) 2 anos e B) 3 anos**<br>DM (DP) TRI 4mg: A) -3 (22); B)0 (21)|A)0.49**(TRI<br>4 vs.1mg)|**Mudança na CST (µm) entre a linha de base e A) 2**<br>**anos B) 3 anos**<br>DM (DP) TRI 4mg: A) -77 (160); B) -126 (159)|A)0,91**(TRI 4 vs.1mg)|
||||DM (DP) TRI 1mg: -2 (18); B) 0 (16)<br>DM (DP) Laser: A) 1 (17); B) 5 (17)|A)0.002*; B)<br>>0.05*<br>A) 0.02*; B)<br><0.05***|DM (DP) TRI 1mg: -86 (167); B) -124 (184)<br>DM (DP) Laser: A) -139 (148); B) -175 (149)|A) <0,001*; B) NR<br>A) <0,001*; B) NR|
||||∆ (IC 95%) TRI 4mg - Laser: A) 4.5 (1.4, 10.3); B) 4.7 (0.0,<br>9.5)|A) <0.05; B)<br>>0.05|||
||||∆ (IC 95%) TRI 1mg - Laser: A) 4.4 (0.2, 9.0); B) 5.6 (0.8,<br>10.4)|A) >0.05; B)<br>>0.05|||
||||∆ (IC 95%) TRI 4mg - TRI 1mg: B) −0.8 (−6.0,4.3)|B) >0.05|||
||||**Melhora ≥ 15 letras, em A) 2 anos e B) 3 anos (%):**<br>TRI 4 mg: A)17; B)21<br>TRI 1 mg: A)14; B)20<br>Laser: A)18; B)26|A)0,82**(TRI<br>4 vs.1mg)<br>A)0.01* B) NR<br>A)0.03*; B)<br>NR|||  
158  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Chew et al.**<br>**2007**<sup>**225**</sup><br>**(DRCRNet)**|1) sub-<br>Tenoniana<br>posterior TRI<br>40 mg<br>2) sub-<br>Tenoniana<br>anterior TRI|5)<br>Fotocoagula<br>ção focal|**Alteração média da acuidade visual (letras) entre a linha de**<br>**base e A) 4 B) 8, C) 17 e D) 34 semanas**<br>1) DM (DP):DM (DP):  A) 1 (4) ;B) 0 (7); C) -1 (6); D) -4 (11)<br>2) DM (DP):A) -1 (4); B) -1 (6); C) -2 (5); D) -1 (5)<br>3)DM (DP):  A) -2 (6); B)0 (4); C) -1 (7); D) -3 (15)|0.94<br>(comparando<br>os 5 grupos vs.<br>Fotocoagulaçã<br>o focal)|**Redução média da CST (µm) entre a linha de base e**<br>**A) 4, B) 8, C) 17 e D) 34 semanas**<br>1)DM (DP):   A) -47 (51); B) -29 (62); C) - 24 (91); D) -<br>31 (113)<br>2)DM (DP):  A) -27 (36); B) - 38 (44); C) - 50 (49); D) -<br>45 (56)|D) 0.46 (comparando os<br>5 grupos vs.<br>Fotocoagulação focal)|
||20 mg||4)DM (DP): A) -1 (5); B) 0 (6); C) -1 (7); D) -1 (7)||3)DM (DP):  A) - 16 (60); B) -25 (55); C) -52 (45); D) -<br>45 (70)||
||3) sub-<br>Tenoniana<br>posterior TRI<br>40 mg + laser<br>4) sub-<br>Tenoniana<br>anterior TRI<br>20 mg + laser||5)A)  -1 (5); B) -1 (5); C) -2 (5)  ; D)-2 (12)||4)DM (DP):  A) -37 (66); B) - 44 (64); C) - 49 (79); D) -<br>68 (60)<br>5) DM (DP):  A) -10 (53); B) - 27 (49); C)  -30 (60); D) -<br>54 (62)||
|**Lam et al.**<br>**2007**<sup>**226**</sup>|TRI<br>TRI + laser<br>grid|Laser grid|**Ganho médio da acuidade visual de melhor corrigida (letras**<br>**LogMAR) entre a linha de base e as semanas A)2; B) 4;**<br>**C)9; D)17; E)26**<br>DM (DP) TRI: A)2.1 (7.6); B)3.5 (7.9); C) 4.5 (9.5); D)0.8<br>(10.9); E) -0.7 (10.7)<br>DM (DP) TRI/Laser grid: A)2.3 (7.9); B)2.9 (8.9); C)1.6 (8.0);<br>D)1.8 (7.9); E) -1.1 (10.8)<br>DM (DP) Laser grid: A) 0.5 (6.5); B) -0.2 (6.7); C)0.4 (7.3);<br>D)1.0 (10.3); E) -1.6 (11.5)|A) 0.53<br>B)0.096<br>C)0.10<br>D)0.91<br>E) 0.93<br>(Diferença<br>entre os<br>grupos)|**Redução média da CRT (%) (DP) entre a linha de**<br>**base e as semanas A)2; B) 4; C) 9; D)17; E)26**<br>DM (DP) TRI: A) 43 (34); B) 52 (42); C) 46 (44); D) 20<br>(56); E) 22 (51)<br>DM (DP) TRI/Laser grid: A) 48 (39); B) 59 (39); C) 60<br>(30); D) 58 (39); E) 48 (51)<br>DM (DP) Laser grid: A)12 (39); B) -7 (54); C) -3 (63);<br>D) 18 (58); E)17 (78)|A)  <0.001<br>B) <0.001<br>C) <0.001<br>D) 0.001<br>E)0.070<br>(Diferença entre os<br>grupos)|  
Valor de p intervenção versus controle*; valor de p TRI 4 mg versus TRI 1mg**; Valor de p intervenção versus controle (diferença ajustada) ***; CRT: espessura central da retina; CST: espessura do subcampo central; CMT: espessura macular central; BCVA: acuidade visual de melhor corrigida; TRI: injeção de triancinolona acetonida intravítreo; ∆: diferença; DM: diferença de médias; OR: Oddsratio ou razão de chances; RR: risco relativo; IC 95%: intervalo de confiança; DP: desvio padrão.  
**Tabela 74** **<mark>–</mark>** <mark>Desfechos de segurança</mark> de ensaios clínicos randomizados que compararam injeção de triancinolona acetonida intravítrea (TRI)  
159  
|**Autor, ano:**|**Gillies et al. 2010 e Gillies**<br>**et al. 2011**||**Beck et al. 2009 e DRCRNet,**<br><sup>**223224**</sup>||**Chew et al. 2007 (DRCRNet)**<sup>**225**</sup>||**Lam et al. 2007**<sup>**226**</sup>||
|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**Adversos**|**221,222**<br>**TRI/ laser vs. Injeção de**<br>**placebo/ laser**|**Valor de**<br>**p**|**2008**<sup>**,**</sup><br>**TRI 4 mg vs. TRI 1 mg vs. Laser**|**Valor de p**|**TRI posterior vs. TRI anterior vs. Laser**|**Valor de p**|**TRI vs. TRI +**<br>**laser grid vs.**<br>**Laser grid**|**Valor de p**|
|**PIO elevada**|n (%) total (>22mmHg): 25<br>(60%) de 42 vs. 15 (36%) de<br>42 *<br>(≥5mmHg): 29 (69%) de 42<br>vs. 17 (40%) de 42 *|0.029<br>0.009|(≥10mmHg) em A) ♦ e B) ♦♦: n (%):<br>A) 85 (33); %: B) 33 vs. n (%): 41<br>(16); %: B) 18 vs. n (%): A) 12 (4); %:<br>B) 4<br>(≥ 30mmHg) em A) ♦: n (%)=53 (21)<br>vs. 22 (9) vs.  3 (1)|NR|n (%) total: (≥10mmHg):<br>5 (12%) de 43 olhos vs. 9 (19%) de 48<br>olhos vs. 2 (5%) de 38 olhos ▲<br>n olhos (≥ 30mmHg) : 1 vs. 5 vs. 0▲|NR|n (%)<br>(>22mmHg):<br>14 (37%) vs. 13<br>(36%) vs. 2 (5%)|0.002|
|**Progressão de**<br>**catarata**|n (%) total: 18 (64%) de 28<br>vs. 3 (11%) de 27 **|<0.001|NR|NR|n (%) total:10 (26%) de 39 olhos vs. 11<br>(25%) de 44 olhos vs. 6<br>(16%) de 38 olhos¥|NR|n (%): 1.0 (1.1)<br>vs. 1.3 (1.9) vs.0.5<br>(0.9)|0.10|
|**Ptose palpebral**|NR|NR|NR|NR|n (%) total: 5 (12%) de 43 olhos vs. 3 (6%)<br>de 48 olhos vs. 0 de 38 olhos ▲;|NR|NR|NR|
|**HbA1c**<br>**aumentou**<br>**0.5% ou mais**|NR|NR|NR|NR|n (%) total:10 (32%) de 31 participantes; 14<br>(37%) de 38 participantes vs. 5 (38%) de 13<br>participantes▲|NR|NR|NR|  
Aos 6 meses de seguimento*; Progressão de catarata de mais de 2 ou mais graus AREDS (olhos fácicos) aos 24 meses; aos 2 anos de seguimento♦; aos 3 anos de seguimento♦♦; 34 semanas de seguimento▲; Catarata grau 1 ou pior na semana 34 ¥; TRI: injeção de triancinolona acetonida intravítreo; NR: não reportado

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **5.3 Grupo Intervenção: Implante de Fluocinolona Intravítrea (FLU) versus Grupo Controle: injeção de placebo ou laser ou observação.** -->
**Tabela 75 –** Características dos ensaios clínicos randomizados na pergunta de pesquisa Q8 <mark>que analisaram fluocinolona (FLU)</mark>  
|**Autor (es)**|**Desenho de**<br>**estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Campochiaro et al.**<br>**2011 e Campochiaro et**<br>**al. 2012**<sup>**227,228**</sup>|2 ECR- FAME<br>study A e B|Para avaliar a eficácia e<br>segurança de implantes de FLU<br>liberando 0,2µ g/ dia (dose baixa)<br>ou 0,5<br>µG / dia (alta dose) em pacientes<br>com EMD|Envolve o centro da<br>fóvea: (FTH>250µm e<br>BCVA entre 19 e 68<br>letras)|953 participantes|FLU 0.5 µg/dia<br>FLU 0.2 µg/dia|Injeção de placebo|Risco de Viés Alto<br>(randomização, cegamento e<br>sigilo de alocação)|  
160  
|**Pearson et al. 2011**<sup>**229**</sup>|ECR|Reportar os resultados de eficácia<br>e segurança do FLU no<br>tratamento de persistente ou<br>recorrente EMD|Envolve o centro da<br>fóvea: >300 µm e BCVA<br>entre 20 e 68 letras)|196 participantes<br>com EMD<br>persistentes ou<br>recorrentes|FLU 0.59 mg|Tratamento padrão<br>(laser adicional ou<br>observação)|Risco de Viés Alto<br>(randomização, cegamento<br>dos participantes e<br>investigadores e sigilo de<br>alocação)|
|---|---|---|---|---|---|---|---|  
FTH: espessura foveal; EMD: edema macular diabético; ECR: ensaio clínico randomizado; BCVA: acuidade visual de melhor corrigida; FLU: implante de acetonido de fluocinolona intravítreo;  
**Tabela 76** **_–_** Características de linha de base dos participantes dos ensaios clínicos randomizados <mark>que analisaram fluocinolona (FLU)</mark>  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n**<br>**olhos)**<br>**interven**<br>**ção**|**N (n**<br>**olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual, média**<br>**ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**CRT (µm), média**<br>**(DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Campochiaro**<br>**et al. 2011 e**<br>**Campochiaro**<br>**et al. 2012**<br>**(FAME)**<br>**227,228**|FLU 0.5<br>µg/dia<br>FLU 0.2<br>µg/dia|Injeção de<br>placebo|393<br>375|185|62.2 (9.3)<br>63.0 (9.3)|61.9 (9.6)|61.8 vs. 58.4<br>57.3 vs. 58.4|7.8 (1,70) vs.<br>7.7 (1,56)<br>7.8 (1,70) vs.<br>7.8 (1,57)|52.9 (12.21) vs. 54.7<br>(11.27)<br>53.3 (12.69) vs. 54.7<br>(11.27)|485.1 (173.78) vs.<br>451.3 (151.97)<br>460.8 (160.00) vs.<br>451.3 (151.97)|24 e 36 meses|
|**Pearson,**<br>**2011**<sup>**229**</sup>|FLU 0.59 mg|Tratamento<br>padrão|127|69|61.4-62.|7 Anos|58.3-58|NR|NR|NR|36 meses|  
CRT: espessura central da retina; N: número de participantes; n: número de olhos; Masc.: masculino; ECR: ensaio clínico randomizado; FLU: implante de acetonido de fluocinolona intravítreo; ETRDS _: EarlyTreatmentDiabeticRetinopathyStudyResearchGroup_ ; HbA1c: hemoglobina glicada; DP: desvio padrão.  
**Tabela 77 –** <mark>Resultados de eficácia dos ensaios clínicos randomizados que analisaram fluocinolona (FLU)</mark>  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p FLU**<br>**vs. Injeção de**<br>**placebo**|**Desfechos Anatômicos:**|**Valor de p FLU**<br>**vs. Injeção de**<br>**placebo**|
|---|---|---|---|---|---|---|
|**Campochiaro et**<br>**al. 2011 e**<br>**Campochiaro et**<br>**al. 2012**<br>**227,228**<br>**(FAME)**|FLU 0.5µg/dia|Injeção de<br>placebo|**Porcentagem de pacientes com ganho de ≥15 letras aos A)**<br>**24 meses e B) 36 meses (Intervenção vs. Controle)**<br>A) %: 28.6 vs. 16.0        B) %: 27.8 vs. 18.9<br>**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e a) 24 meses e B) 36 meses**<br>**(Intervenção vs. Controle)**<br>A) FLU: DM: +5.4; Injeção de placebo: DM: +1.7<br>B) FLU: DM: +5.3; Injeção de placebo: DM: +2.0|A) 0.002*<br>B) 0.018*<br>A) 0.017*<br>B) ≤0.018*|**Espessura da fóvea (µm): valor em A) 24 meses e**<br>**(B) 36 meses (Intervenção vs. Controle)**<br>A: 308 vs.340<br>B: 300 vs.340|A) <0.001*<br>B) >0.05*|  
161  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p FLU**<br>**vs. Injeção de**<br>**placebo**|<br>**Desfechos Anatômicos:**|**Valor de p FLU**<br>**vs. Injeção de**<br>**placebo**|
|---|---|---|---|---|---|---|
||FLU 0.2µg/dia|Injeção de<br>placebo|**Porcentagem de pacientes com ganho de ≥15 letras aos A)**<br>**24 meses e B) 36 meses (Intervenção vs. Controle)**<br>A) %: 28.7 vs. 16.0        B) %: 28.7 vs. 18.9<br>**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e a) 24 meses e B) 36 meses**<br>**(Intervenção vs. Controle)**<br>A) FLU: DM: +4.4; Injeção de placebo: DM: +1.7<br>B) FLU: DM:  +5.3; Injeção de placebo: DM: +2.0|A) 0.002<br>B) 0.018<br>A)0.02<br>B) ≤0.018|**Espessura da fóvea (µm): valor em A) 24 meses e**<br>**(B) 36 meses (Intervenção vs. Controle)**<br>A: 293 vs.309<br>B: 280 vs.309|A) 0.005*<br>B) >0.05*|
|**Pearson et al.**<br>**2011**<sup>**229**</sup>|FLU 0.59 mg|Tratamento<br>padrão|**Ganho de ≥15 letras (≥3 linhas) na acuidade visual (ETDRS)**<br>**em A) 6 meses; B) 1 ano; C) 2 anos e D) 3 anos**<br>% FLU: A)16.8; B) 16.4; C) 31.8; D)31<br>% tratamento padrão: A) 1.4; B) 8.1%; C) 9.3; D) 20<br>**Perda de ≥15 letras na acuidade visual (ETDRS)**<br>% FLU: 17<br>% tratamento padrão: 14|A) 0.0012*<br>B) 0.1191*<br>C) 0.016*<br>D)0.1566*<br>>0.05*|**Mudança média da CMT (µm) entre a linha de**<br>**base e 36 meses:**<br>DM FLU: -86<br>DM tratamento padrão: -110|>0.05*|  
Valor de p intervenção versus controle*; FLU: implante de acetonido de fluocinolona intravítreo; CMT: espessura macular central; DM: diferença de médias.  
**Tabela 78 –** Resultados de segurança de ensaios clínicos randomizados <mark>que analisaram fluocinolona intravítrea (FLU)</mark>  
||**Campochiaro et al. 2011 e Campochiaro et**||**Campochiaro et al. 2011 e Campochiaro et**||**Pearson et al. 2011**<br>||
|---|---|---|---|---|---|---|
|**Eventos Adversos**|**al. 2012 (FAME)**<br>**227,228**|**Valor de p**|**al. 2012 (FAME)**<br>**227,228**|**Valor de p**|**229**<br>**FLU 0.59 mg vs.**|**Valor de p**|
||**FLU 0.5µg/dia vs. Injeção deplacebo**||**FLU 0.2µg/dia vs. Injeção deplacebo**||**Tratamentopadrão**||
|**EA oculares**|NR|NR|NR|NR|%: 100 vs. 88.4|NR|
|**Glaucoma**|n (%): 9 (2.3) vs. 1 (0.5)*|NR|n (%): 6 (1.6)vs. 1 (0.5) *|NR|%: 69.3 vs. 11.6|NR|
|**Catarata**|88.7 % de 265 vs. 50.4% de 121 ◊▲|NR|81.7% de 235 vs. vs. 50.4% de 121 ◊▲|NR|%: 55 .9 vs. 21.7|NR|
|**Progressão de catarata**|NR|NR|NR|NR|n (%): 71 (55.9) vs. 15 (21.7)|NR|
|**PIO elevada**|n (%): 13 (3.3) vs. 0 (0) *▲|NR|n (%): 12 (3.2) vs.  vs. 0 (0) *▲|NR|n (%): 88 (69.3) vs. 8 (11.6)|NR|
|**EA relacionada a PIO**<br>**elevada**|45.5% de 393 vs. 11.95% de 185 ◊▲|NR|37.1% de 375 vs. 11.95% de 185 ◊▲|NR|NR|NR|
|**Hemorragia vítrea**|NR|NR|NR|NR|n (%): 51 (40.2) vs. 13 (18.8)|NR|  
162  
|**Eventos Adversos**|**Campochiaro et al. 2011 e Campochiaro et**<br>**al. 2012 (FAME)**<br>**227,228**<br>**FLU 0.5µg/dia vs. Injeção deplacebo**|**Valor de p**|**Campochiaro et al. 2011 e Campochiaro et**<br>**al. 2012 (FAME)**<br>**227,228**<br>**FLU 0.2µg/dia vs. Injeção deplacebo**|**Valor de p**|**Pearson et al. 2011**<br>**229**<br>**FLU 0.59 mg vs.**<br>**Tratamentopadrão**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Sensação anormal no olho**|NR|NR|NR|NR|n (%): 47 (37.0) vs. 8 (11.6)|NR|
|**Edema macular**|NR|NR|NR|NR|n (%): 44 (34.6) vs. 25 (36.2)|NR|
|**Acuidade visual reduzida**|NR|NR|NR|NR|n (%): 29 (22.8) vs. 16 (23.2)|NR|
|**Irritação nos olhos**|NR|NR|NR|NR|n (%): 28 (22.0) vs. 7 (10.1)|NR|
|**Aumento da lacrimação**|NR|NR|NR|NR|n (%): 28 (22.0) vs. 6 (8.7)|NR|
|**Visão borrada**|NR|NR|NR|NR|27 (21.3) vs. 11 (15.9)|NR|
|**Flocos vítreos**|NR|NR|NR|NR|27 (21.3) vs. 6 (8.7)|NR|
|**Fotofobia**|NR|NR|NR|NR|27 (21.3) vs. 15 (21.7)|NR|
|**EA cardiovasculares sérios**|%: 13.2 vs. 10.3 *|NR|%: 12 vs. 10.3 *|NR|NR|NR|
|**Infarto do miocárdio**|%: 4 vs. 1.1 *|0.0347|%: 2.8 vs. 1.1 *|NR||NR|  
Aos 24 meses de seguimento *; aos 36 meses de seguimento ◊; olhos fácicos▲; FLU: implante de acetonido de fluocinolona intravítreo; PIO: pressão intraocular; NR: não reportado.  
- **5.4 Grupo Intervenção: Implante de Dexametasona intravítreo (DEXA) versus Grupo Controle: ranibizumabe (RANI), DEXA em diferentes dosagens, placebo, bevacizumabe (BEVA) ou laser**  
**Tabela 79 –** Características dos ensaios clínicos randomizados na pergunta de pesquisa Q8 que analisaram o implante de dexametasona (DEXA)  
|**Autor (es)**|**Desenho de**<br>**estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Callanan et al. 2016**<sup>**230**</sup>|ECR|Estudo de não inferioridade do DEXA<br>0.7 mg a cada 5 meses em relação ao<br>RANI 0.5 mg em pacientes com EMD|Envolve o centro da macula<br>(BVCA entre 34 e 70 letras<br>e CRT ≥ 300 µm<br>envolvendo 1mm)|363 participantes|DEXA 0.7 mg<br>(Deximpant)|RANI 0.5 mg|Baixo risco de viés|  
163  
|**Autor (es)**|**Desenho de**<br>**estudo**|**Objetivo**|**Tipo de edema macular**<br>**diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Danis et al. 2016;**<br>**Maturi et al. 2016;**<br>**Boyer et al. 2014**<br>**231-233**|2 ECR, - (The<br>MEAD Study)|Avaliar a segurança e a eficácia do<br>DEXA 0.7 e 0.35 mg em pacientes com<br>EMD|Envolve o centro da fóvea<br>(BCVA entre 34 e 68 letras,<br>CRT≥ 300 µm)|1048 pacientes<br>tratados<br>previamente com<br>laser ou com<br>tratamento<br>medicamentos|DEXA 0.7 mg e<br>DEXA 0.35 mg<br>(Ozurdex, DEX<br>implant)|Placebo|Alto risco de viés (viés<br>de atrito – dados<br>incompletos)|
|**Augustin et al. 2015**<br>**234**|ECR (MEAD<br>Study)|Analisar a eficácia e segurança do DEXA<br>0.7 mg no subgrupo de pacientes com<br>EMD previamente tratados|Envolve o centro da fóvea<br>(BVCA entre 34 e 68 letras<br>e CRT ≥ 300 µm)|508 participantes<br>previamente<br>tratados|DEXA 0.7 mg<br>(DEX implant)|Placebo|Alto risco de viés (viés<br>de seleção)|
|**Ramu et al. 2015**<br>**235**|ECR-– (OZDRY<br>study)|Comparar a efetividade clínica (não<br>inferioridade) e segurança do DEXA_pro-_<br>_re-nata_versus dosagens fixas mensais<br>em pacientes com EMD refratário|Refratário; envolve o centro<br>da macula (BCVA entre 73-<br>34 letras, CST>300µm)|100 participantes|DEXA 0.7 mg<br>fixas (doses fixas<br>a cada 5 meses-<br>Ozurdex)|DEXA 0.7mg_pro-re-_<br>_nata_(quando<br>necessário) (Ozurdex)|Alto risco de viés (Viés<br>de seleção, desfecho<br>incompleto)|
|**Heng et al. 2015**<br>**235**|ECR (OZLASE<br>study)|Avaliar a eficácia e a segurança do<br>DEXA combinado com terapia de laser<br>macular versus monoterapia de laser<br>macular em pacientes com prejuízo na<br>visão devido ao EMD que envolve o<br>centro da fóvea.|Envolve o centro da macula<br>(BCVA entre 54-78 letras,<br>CST>300µm)|80 participantes|DEXA 0.7 mg<br>(Ozurdex) + laser<br>macular|Monoterapia de laser<br>macular|Baixo risco de viés)|
|**Gillies et al. 2014**<br>**19**|ECR<br>(The BEVORDEX<br>Study)|Comparação direta entre DEXA versus<br>BEVA|Envolve o centro da fóvea<br>depois de no mínimo 3<br>meses depois de pelo menos<br>1 sessão de laser (BCVA:<br>20/400 e 20/40)|61 participantes (88<br>olhos)|DEXA 0.7 mg<br>(Ozurdex)|BEVA1.25mg<br>(Avastin)|Baixo risco de viés|
|**Callanan et al. 2013**<br>**237**|ECR (the Ozurdex<br>PLACID Study)|Avaliar DEXA 0.7mg combinado com<br>fotocoagulação a laser comparado com<br>monoterapia a laser para o tratamento de<br>EMD difuso|Difuso; envolve o centro da<br>fóvea (BCVA entre 34 e 70<br>letras, CRT≥ 275µm)|253 pacientes|DEXA 0.7 mg +<br>Fotocoagulação a<br>laser<br>(DEXA 0.7mg +<br>laser)<br>(Ozurdex, DEX<br>implant)|Fotocoagulação a<br>laser (laser)|Baixo risco de viés)|  
EMD: edema macular diabético; ECR: ensaio clínico randomizado; BCVA: acuidade visual de melhor corrigida; CRT: espessura central da retina; CST: espessura do subcampo central; DEXA: implante de dexametasona intravítrea; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea.  
164  
**Tabela 80** **<mark>–</mark>** <mark>Características de linha de base dos participantes dos ensaios clínicos randomizados</mark> que analisaram o implante de dexametasona (DEXA)  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n**<br>**olhos)**<br>**intervenç**<br>**ão**|**N (n**<br>**olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média (DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual,**<br>**média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm), média (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Callanan et al.**<br>**2016**<sup>**230**</sup>|DEXA|RANI|181|182|63.4 (9.39)|63.7 (10.05)|61.9 vs. 63.7|7.7 (1,4) vs.<br>7.5 (1,3)|60.2 (9.74) vs. 60.4<br>(9.34)|465 (136) vs. 471 (140)<br>*|12 meses|
|**Augustin et al.**<br>**2015**<br>**(MEAD)**<sup>**234**</sup>|DEXA|Placebo|247|261|63.0 (8.3)|63.0 (9.1)|60.7 vs. 64.4|7.5 (1,1) vs.<br>7.5 (1,0)|55.2 (9.6) vs. 56.1<br>(9.1)|478 (153) vs.472 (131)<br>*|3 anos|
|**Danis et al.**<br>**2016; Maturi et**<br>**al. 2016; Boyer**<br>**et al. 2014**<br>**231-233**|DEXA 0.7<br>mg<br>DEXA 0.35<br>mg|Placebo|351<br>347|350|62.5 (8.3)<br>62.3 (9.2)|62.5 (9.5)|60.7 vs. 62.0<br>59.4 vs. 62.0|NR|56.1 (9.9) vs. 56.9<br>(8.7)<br>55.5 (9.7) vs. 56.9<br>(8.7)|463.0 (157.1) vs. 460.9<br>(132.6) *<br>Pacientes com PIO ≥10<br>mmHg:469 (171)<br>466.8 (159.5) vs. 460.9<br>(132.6) *<br>Pacientes sem PIO ≥10<br>mmHg:462 (152)|3 anos|
|**Ramu et al.**<br>**2015**<br>**(OZDRY)**<sup>**235**</sup>|<br>DEXA doses<br>fixas|DEXA pro-<br>re-nata|50|50|63.8 (11.1)|65.4 (9.8)|80 vs.68|8.1 (1,4) vs.<br>7.7 (1,3)|57.5 (9.5) vs.61.2<br>(8.6)|479.8 (128.4) vs. 466.7<br>(144.1) **|12 meses|
|**Heng et al.**<br>**2015**<br>**(OZLASE)**<sup>**236**</sup>|DEXA + laser<br>macular|Monotera-<br>pia de laser<br>macular|40|40|65.6 (10.6)|61.1 (12.8)|85.0 vs. 80.0|7.9 (1,2) vs.<br>8.0 (1,4)|66.1 (7.3) vs. 66.6<br>(7.7)|459 vs. 452**|56 semanas|
|**Gillies et al.**<br>**2014**<br>**(BEVORDEX)**<br>**19**|DEXA|BEVA<br>1.25mg|46|42|62.2 (10.5)|61.4 (9.0)|68 vs. 65|7.8 (2,1) vs.<br>7.7 (2,5)|56.3 (11.9) vs. 55.5<br>(12.5)|503 (140.9) vs. 474.3<br>(95.9) ***|12 meses|
|**Callanan et al.**<br>**2013**<br>**(Ozurdex**<br>**PLACID)**<br>**237**|DEXA 0.7<br>mg + laser|Laser|126|127|61.8 (11.1)|61.3 (9.3)|49.2 vs. 52.0|NR|NR|438 (134) vs.430 (131)<br>*|12 meses|  
*CRT: espessura central da retina;CST: espessura do subcampo central**; CMT: espessura macular central***; EMD: edema macular diabético; ECR: ensaio clínico randomizado; Masc.: masculino; DEXA: implante de dexametasona intravítrea; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; ETRDS: _EarlyTreatmentDiabeticRetinopathyStudyResearchGroup_ ; HbA1c: hemoglobina glicada; NR: não reportado; DP: desvio padrão.  
**Tabela 81 –** <mark>Resultados de eficácia dos ensaios clínicos randomizados</mark> que analisaram o implante de dexametasona (DEXA)  
165  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|<br>**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Callanan et al.**<br>**2016**<br>**230**|DEXA|RANI|**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e aos 12 meses**<br>DM DEXA: +7.6; DM RANI: +7.6<br>* IC 95% da diferença média entre os grupos: (−4.74, −1.88)<br>(Não inferioridade comprovada, margem = 5)|<0.01*|**Redução média da CRT (µm) entre a linha de base e**<br>**aos 12 meses (Intervenção vs. Controle)**<br>DMDEXA: −173.9; DM RANI: −163.5<br>**Redução média da área total de vazamento pela**<br>**Angiografia de Fluoresceína aos 12 meses**<br>DMDEXA:  -12.0; DM RANI:  -16.1|NR<br><0.001*|
||||**Alteração média da acuidade visual de melhor corrigida**<br>**da linha de base (letras) entre a linha de base e 12 meses**<br>DMDEXA doses fixas:  0.53; DM DEXA pro-re-nata:0<br>DM ITT (IC 95%)de efeito: − 0.34 (−5.49, 4.81) PRN é<br>inferior.<br>DM ITT (casos disponíveis – enviesado) (IC 95%)de efeito: -<br>0,97 (-4,01; 5,95)<br>DM ITT (per protocol): -0,28 (-4,72; 5,27)||||
|**Ramu et al.**<br>**2015**<br>**(OZDRY)**<br>**235**|DEXA doses<br>fixas|DEXA pro-re-<br>nata|**Melhora na acuidade visual, letras (ETDRS), n (%): A)**<br>**≥10 letras; B) ≥15 letras; C) ≥5 letras<15:**<br>DEXA doses fixas: A) 12 (24); B) 7 (14); C) 14 (29)<br>DEXA pro-re-nata: A) 11 (23); B) 4 (8); C) 12 (25)<br>OR (A): 0,82 (0,3; 2,3)<br>OR (B): 1,3 (0,33; 5,40)<br>OR (C): 1,3 (0,5; 3,36)|NR|**Redução média da CST (µm) entre a linha de base e 12**<br>**meses**<br>DM (DP) DEXA doses fixas:  − 179.9 (172.4);<br>DM (DP) DEXA pro-re-nata: − 90.1 (96.2)<br>∆ (IC 95%) intervenção - controle: − 71.34 (−117.33, −<br>25.34)|NR|
||||**Piora na acuidade visual, letras (ETDRS), n (%): A) ≥5**<br>**letras<15; B) ≥15 letras:**<br>DEXA doses fixas: A) 4 (8); B) 7 (14)<br>DEXA pro-re-nata: A) 7 (15); B) 4 (8)<br>OR (A): 0,65 (0,17; 2,60)<br>OR (B): 1,76 (0,46; 6,76)||||  
166  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
||||**Porcentagem de pacientes com ganho de ≥15 letras aos 3**<br>**anos de estudo (%)**<br>**1)Pacientes com DME previamente tratados**<br>DEXA: 21.5%; Placebo: 11.1%|0.002*|||
||||**2)Pacientes com DME previamente tratados com A)**<br>**Esteroide; B) Anti-VEGF; C) LASER**||||
||||DEXA:A) 27.6% de 58; B) 28.0 % de 25; C) 21.2% de 231|NR|||
||||Placebo: A) 8.2 % de 61; B) 7.7 % de 26; C) 11.9 % de 243||**Redução média da CRT (µm) entre a linha de base e 3**||
||||||**anos**||
||||**3) Pacientes com DME previamente tratados com pelo**||**1) Pacientes com DME previamente tratados**|<0.001|
||||**menos dois tratamentos**||DM DEXA: −126 (131)||
||||DEXA:26.2%; Placebo: 8.8%||DM Placebo: −39 (121)||
||||∆ (IC 95%) DEXA - Placebo: 17.5 (4.2, 30.7)|NR||NR|
|**Augustin et al.**|||||**2) Pacientes com DME previamente tratados com A)**||
|<br>**2015**|||||**Esteroide; B) Anti-VEGF; C) LASER**||
||DEXA (n=61)|Placebo (n=57)|||DM DEXA: A) −121 (150); B) −130 (95); C) −123 (130)||
|**(MEAD)**<br>**234**|||**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e 3 anos**||DM Placebo: A) −30 (135); B) −42 (123); C) −39 (121)||
||||**1)Pacientes com DME previamente tratados**||||
||||DM DEXA:3.2 (8.7)||**3) Pacientes com DME previamente tratados com pelo**|NR|
||||DM Placebo: 1.5 (7.5)|0.024*|**menos dois tratamentos**||
||||||DM DEXA:  −108; Placebo: DM= −26||
||||**2)Pacientes com DME previamente tratados com A)**<br>**Esteroide; B) Anti-VEGF ; C) LASER**||∆ (IC 95%) DEXA - Placebo: −111 (−154, −69)||
||||DM DEXA: A) +4.9 (7.4); B) +4.2 (8.8); C) +3.1 (8.7)<br>DM Placebo:): A) −0.6 (8.6); B) +1.6 (7.6); C) +1.6 (7.5)|NR|||
||||**3)Pacientes com DME previamente tratados com pelo**||||
||||**menos dois tratamentos**||||
||||DM DEXA:  4.0; DM Placebo : −0.3|NR|||
||||∆ (IC 95%) DEXA - Placebo: 3.8 (1.1, 6.5)||||  
167  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
||||**Porcentagem de pacientes com ganho de ≥15 letras aos 3**<br>**anos, n (%):**<br>DEXA 0.7 mg: 22.2% de 351<br>DEXA 0.35 mg: 18.4% de 347|<0.001*<br>≤ 0.018*|**Redução média da CRT (µm) entre a linha de base e 3**<br>**anos, DM (DP):**<br>DEXA 0.7 mg: - 111.6 (134.1)<br>DEXA 0.35 mg: -107.9 (135.8)<br>Placebo: - 41.9 (116.0)|<0.001*<br><0.001*|
||||Placebo: 12.0% de 350||**Mudança média (DP) do volume macularmm**<sup>**3**</sup>||
|**Danis et al.**|||**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e 3 anos, DM (DP):**<br>DEXA 0.7 mg: 3.5 (8.4)|0023*|DM (DP) DEXA 0.7 mg: −1.06 (2.22)<br>DM (DP) DEXA 0.35 mg: −1.14 (1.75)<br>DM (DP) Placebo: −0.31 (1.62)|<0.001*<br><0.001*|
|**2016; Maturi**<br>**et al. 2016;**<br>**Boyer et al.**<br>**2014**<br>**(MEAD)**<br>**231-233**|DEXA 0.7 mg<br>DEXA 0.35 mg|Placebo|DEXA 0.35 mg: 3.6 (8.1)<br>Placebo: 2.0 (8.0)<br>**Ganho de≥15 letras entre a linha de base e três anos n**<br>**total (%):**<br>DEXA 0.7 mg pacientes com PIO elevada (≥10 mmHg**)**:21<br>de 96 (21.9%)<br>DEXA 0.7 mg pacientes sem PIO elevada (≥10 mmHg):57 de<br>255 (22.4%)|.<br>0.019*<br>NR<br>NR|**Mudança média (DP) do espessamento central da retina**<br>**(área do disco)**<br>DM (DP) DEXA 0.7 mg: −2.75 (4.46)<br>DM (DP) DEXA 0.35 mg: −2.93 (4.03)<br>DM (DP) Placebo: −1.49 (3.74)<br>**Redução média da CRT (µm) entre a linha de base e 3**<br>**anos, DM (DP):**<br>DEXA 0.7 mg pacientes (n=96) com PIO elevada (≥10<br>|<br><0.001*<br><0.001*<br>NR|
||||DEXA 0.35 mg pacientes com PIO elevada (≥10 mmHg**)**:22<br>de 85 (25.9%)<br>DEXA 0.35 mg pacientes sem PIO elevada (≥10 mmHg):42<br>de 262 (16.0%)|NR<br>NR|mmHg**)**:-126.7<br>DEXA 0.7 mg pacientes (n=252) sem PIO elevada (≥10<br>mmHg):-105.8<br>DEXA 0.35 mg pacientes (n=85) com PIO elevada (≥10<br>mmHg**)**:-128.4|NR<br>NR|
||||||DEXA 0.35 mg pacientes (n=259) sem PIO elevada (≥10<br>mmHg):-101.2|NR|  
168  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos:**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Heng et al.**<br>**2015**<br>**(OZLASE)**<br>**236**|DEXA/ laser<br>macular|Monoterapia de<br>laser macular|**Alteração média da acuidade visual de melhor corrigida**<br>**(letras) entre a linha de base e A) 24 semas, B) 40 semanas**<br>**e C) 56 semanas**DM (DP) DEXA/ laser: A)  1,3 (8,8); B)  -<br>1,1 (12,8); C) −0.3 (11.4)<br>DM (DP) Laser: A)  -0,7 (6,3); B) -0,1 (6,8); C) +0.4 (9.5)<br>∆ (IC 95%) DEXA/Laser - Laser: A)  1,32 (-4,42; 1,78);<br>B)1,13 (-3,37; 5,64); C)0.88 (−3.46, 5.22)|NR|**Redução média da CST (µm) entre a linha de base e 56**<br>**semanas**<br>DM (IQR)DEXA/ laser:  −113 (−218, −64)<br>DM (IQR) Laser: −17 (−128, 12)|<0,001|
||||**Melhora na acuidade visual em 56 semanas, letras**<br>**(ETDRS), n (%): A) ≥10 letras E B) ≥15 letras:**<br>DEXA/ laser: A) 7 (18.4); B) 6 (15.8)<br>Laser: A) 8 (20. 5); B) 2 (5.1)<br>∆ (IC 95%) DEXA/Laser - Laser: A)1.14 (0.37, 3.54); B)<br>0.29 (0.05, 1.53)|NR|||
||||**Perda de A) <15 e B) ≥30 letras (ETDRS) em 56 semanas,**<br>**n (%):**<br>DEXA/ laser: A) 35 (92.1); B) 1 (2.6)<br>Laser: A) 35 (89.7); B) 0|NR|||
|**Gillies et al.**<br>**2014**|DEXA|BEVA 1.25mg|**Porcentagem de pacientes com ganho de A) >10 letras e**<br>**B) ≥15 letras aos 12 meses, n (%):**<br>DEXA: A) (19) 41; B) 10 (22)|A)0.99*<br>B) NR|**Redução média da CMT (µm) entre a linha de base e 12**<br>**meses**<br>DMDEXA: -187|0.015*|
|**(BEVORDEX)**<br>**19**|||BEVA: A) (17) 40; B) 13 (31)||DM BEVA: -122||
||||**Sem mudança (ganho ou perda < 5 letras), n (%)**<br>DEXA: 13 (28); BEVA: 16 (38)|NR|||
||||**Perda ≥15 letras, n (%):**<br>DEXA: 4 (9); BEVA: 0|NR|||
||||**Ganho médio de letras em BCVA, n (DP)**<br>DEXA: 5.6(16.3);BEVA: 8.9(8.8)|0.24|||
|**Callanan et al.**<br>**2013**<br>**(Ozurdex**|DEXA 0.7 mg<br>+ laser|Sham+ Laser|**Porcentagem de pacientes com ganho de ≥10 letras entre**<br>**a linha de base e A) 6 meses B) 12 meses, %:**<br>DEXA/laser: A)22,2; B) 27.8<br>Sham/laser: A)17,3; B) 23.6|A) 0,326*<br>B) 0.453*|NR|NR|
|**PLACID)**<br>**237**|||**Máximo aumento médio de letras (BCVA), 7 meses**<br>DEXA/laser: 7,9<br>Sham/laser: 2,3|0,002*|||  
*Valor de p intervenção versus controle; CRT: espessura central da retina; CST: espessura do subcampo central; CMT: espessura macular central; EMD: edema macular diabético; ECR: ensaio clínico randomizado; DEXA: implante de dexametasona intravítrea; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; ETRDS: _EarlyTreatmentDiabeticRetinopathyStudyResearchGroup_ ; ITT: análise de intenção de tratar; OR: Oddsratio ou razão de chances; ∆: diferença; DM: diferença de médias;  NR: não reportado; IC 95%: intervalo de confiança; DP: desvio padrão.  
**Tabela 82 –** Resultados de segurança de ensaios clínicos randomizados <mark>que analisaram implante de dexametasona (DEXA)</mark>  
169  
|**Autor, ano:**|**Callanan**<br>**et al. 2016**<br>||**Augustin et al.**<br>**2015 (MEAD)**||**Ramu et al.**<br>**2015**<br>**(OZDRY)**||**Heng et al. 2015**<br>**(OZLASE)**<br>||**Gillies et al.**<br>**2014**<br>**(BEVORDEX)**<br>||**Danis et al. 2016;**<br>**Maturi et al. 2016;**<br>**Boer et al 2014**||**Callanan et al.**<br>**2013**<br>**(Ozurdex**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**230**|**Valor**|<br>**234**|**Valor**|<br>**235**|**Valor**|**236**|**Valor**|**19**|**Valor**|**y  .**<br>**MEAD**|**Valor**|<br>**PLACID)**|**Valor**|
|**Eventos**||**de p**|**DEXA**|**de p**|**DEXA d**|**de p**||**de p**||**de p**|**()**<br>**231-233**|**de p**|**237**|**de p**|
|**Adversos**|**DEXA vs.**<br>**RANI**||**vs.**<br>**Placebo**||**oses**<br>**fixas vs.**<br>**DEXA PRN**||**DEXA/ laser vs.**<br>**Laser**||**DEXA 0.7 mg**<br>**vs. BEVA**<br>**1.25mg**||**DEXA 0.7mg vs. DEXA**<br>**0.35mg vs. Placebo**||**DEXA**<br>**0.7mg/laser vs.**<br>**Laser**||
|**PIO elevada**|n (%): 62<br>(34.3) vs. 3<br>(1.6)|<0.00<br>1|NR|NR|%(>30mmHg):<br>20 vs. 34|NR|NR|NR|n (%)<br>(>5mmHg):21<br>(45.7) vs. 8 (19)<br>n (%)<br>(>10mmHg): 9<br>(19.6) vs. 0 (0)|NR|n (%) (≥10mmHg):96<br>(27.7) vs. 85 (24.8) vs. 13<br>(3.7) ◊;<br>n (%) (≥25mmHg):111<br>(32.0) vs. 94 (27.4) vs. 15<br>(4.3)♦;<br>n (%) (≥35mmHg):23<br>(6.6) vs. 18 (5.2) vs. 3<br>(0.9)♦|NR|% (n/total):<br>(≥10mmHg):15.2<br>% (19/125) vs.<br>NR<br>(≥25mmHg):<br>16.8% (21/<br>125) vs. NR<br>(≥35mmHg):<br>4.0% (5/125) vs.<br>NR|NR|
|**Catarata**|n (%): 17<br>(9.4) vs. 0<br>(0)|<0.00<br>1|NR|NR|n (%): 27<br>(79%) vs. 30<br>(77%)*|NR|NR|NR|n (%)(aumento<br>de 2 graus): 6<br>(13) vs. 2 (4.8)|NR|n (%): 8 (2.3) vs. 8 (2.3)<br>vs. 1 (0.3)|NR|NR|NR|
|**Catarata**<br>**subcapsular**|n (%): 12<br>(6.6) vs. 0<br>(0)|<0.00<br>1|NR|NR|3 de 34 vs. 3<br>de 39 olhos *|NR|NR|NR|NR|NR|n (%): 2 (0.6) vs. 2 (0.6)<br>vs. 0|NR|NR|NR|
|**Catarata**<br>**nuclear**|n (%): 8<br>(4.4) vs. 0<br>(0)|0.004|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Hipertensão**<br>**ocular**|n (%): 10<br>(5.5) vs. 2<br>(1.1)|0.018|NR|NR|NR|NR|NR|NR|n (%): 2 (10.5)<br>vs. 1 (6.7)†|NR|n (%):21 (6.1) vs. 17 (5.0)<br>vs. 5 (1.4)||NR|NR|
|**Flocos vítreos**|n (%): 9<br>(5.0) vs. 1<br>(0.5)|0.011|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Hemorragia**<br>**conjuntival**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|% (n/total):<br>28.0% (35/125)<br>vs. 15.0%<br>(19/127)|0.012|
|**Hemorragia**<br>**vítrea**|n (%): 7<br>(3.9) vs. 0<br>(0)|0.007|NR|NR|NR|NR|NR|NR|n (%): 2 (4.3) vs.<br>0 (0)|NR|NR|NR|NR|NR|
|**EA**<br>**relacionados**<br>**com PIO**|n (%): 78<br>(43.1) vs.<br>11 (6.0)|<0.00<br>1|%: 38.1 vs. 4.6|NR|NR|NR|NR|NR|NR|NR|n (%): 125 (36.0) vs.117<br>(34.1) vs. 18 (5.1)**|NR|NR|NR|  
170  
|**Autor, ano:**|**Callanan**<br>**et al. 2016**<br>**230**||**Augustin et al.**<br>**2015 (MEAD)**||**Ramu et al.**<br>**2015**<br>**(OZDRY)**||**Heng et al. 2015**<br>**(OZLASE)**<br>**236**||**Gillies et al.**<br>**2014**<br>**(BEVORDEX)**<br>**19**||**Danis et al. 2016;**<br>**Maturi et al. 2016;**<br>**Boyer et al. 2014**||**Callanan et al.**<br>**2013**<br>**(Ozurdex**<br>||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**Adversos**|**DEXA vs.**<br>**RANI**|**Valor**<br>**de p**|**234**<br>**DEXA vs.**<br>**Placebo**|**Valor**<br>**de p**|**235**<br>**DEXA doses**<br>**fixas vs.**<br>**DEXA PRN**|**Valor**<br>**de p**|**DEXA/ laser vs.**<br>**Laser**|**Valor**<br>**de p**|**DEXA 0.7 mg**<br>**vs. BEVA**<br>**1.25mg**|**Valor**<br>**de p**|<br>**(MEAD)**<br>**231-233**<br>**DEXA 0.7mg vs. DEXA**<br>**0.35mg vs. Placebo**|**Valor**<br>**de p**|**PLACID)**<br>**237**<br>**DEXA**<br>**0.7mg/laser vs.**<br>**Laser**|**Valor**<br>**de p**|
|**EA**<br>**relacionados**<br>**ao tratamento**|n (%): 119<br>(65.7) vs.<br>41(22.5)|<0.00<br>1|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**EA sérios**<br>**relacionados**<br>**ao tratamento**|n (%): 3<br>(1.7) vs. 3<br>(1.7)|>0.99<br>9|NR|NR|NR|NR|NR|NR|NR|NR|n (%): 115 (33.1) vs.  120<br>(35.0) vs. 83 (23.7)|NR|NR|NR|
|**EA Oculares**<br>**Sérios**|NR|NR|%: 6.9 vs. 0.8|NR|NR|NR|NR|NR|NR|NR|n (%): 24 (6.9) vs. 14<br>(4.1) vs. 1 (0.3)|NR|% (n/total):<br>22.2% (20/90)<br>vs.9.5%(9/95)*|0.017|
|**EA**<br>**relacionados**<br>**com cataratas**|NR|NR|%: 70.3 vs.<br>20.1*|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Progressão de**<br>**catarata**|NR|NR|NR|NR|27 (74%) de 34<br>vs.30 (77%) de<br>39|NR|21 de 27 vs. 4 de<br>27 olhos*|NR|NR|NR|NR|NR|NR|NR|  
EA: Eventos adversos; PIO: pressão intraocular; Olhos fácicos*; relacionados a PIO ou glaucoma**; piora de hipertensão†; PIO elevada durante qualquer visita no estudo♦; Aumento da PIO da linha de base◊; DEXA: implante de dexametasona intravítrea; BEVA: injeção de bevacizumabe intravítrea; RANI: injeção de ranibizumabe intravítrea; PRN: pro-re-nata, ou se necessário; NR: não reportado.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **6. Ensaios clínicos randomizados: diferentes tipos de laser** -->
**Tabela 83 –** Características dos ensaios clínicos randomizados que compararam diferentes tipos de laser  
|**Autor (es)**|**Desenho de**<br>**estudo**|<br>**Objetivo**|**Tipo de edema macular diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Vujosevic et al. 2015**<br>**136**|ECR|Avaliar e comparar as alterações<br>morfológicas da retina e da coroide e<br>função macular em doentes tratados com<br>laser micropulso amarelo sublimiar(Y-<br>MPL) ou infravermelho (IR-MPL) em<br>EMD com envolvimento da fóvea.|Não tratada; envolvendo o centro<br>da fóvea (CMT>400μm e BCVA<br>de pelo menos 35 letras).|53 pacientes (53<br>olhos)|Laser micropulso<br>amarelo sublimiar<br>(Y-MPL)|Laser micropulso<br>infravermelho sublimiar<br>(IR-MPL)|<br>Risco de Viés Alto<br>(randomização, sigilo de<br>alocação e cegamento<br>não foram descritos)|  
171  
|**Autor (es)**|**Desenho de**<br>**estudo**|**Objetivo**|**Tipo de edema macular diabético**|**Número de**<br>**participantes**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Lavinsky et al. 2011**<br>**135**|ECR|Comparar a fotocoagulação a laser<br>focal/grid<br>_modifiedEarlyTreatmentDiabeticRetinop_<br>_athy_<br>_Study_(mETDRS) VS.<br>fotocoagulaçãomicropulso laser-diode<br>com sublimiares de alta densidade (HD-<br>SDM) ou com normal densidade<br>(ND-SDM) para o tratamento de EMD.|DME recém-diagnosticado;<br>envolve o centro da macula:<br>espessamento retiniano devido ao<br>DME deve estar dentro de 500μm<br>do centro macular e CMT ≥<br>250µm e BCVA pior que 20/40 e<br>melhor que 20/400|123 pacientes|Fotocoagulaçãomicr<br>opulso laser-diode<br>com sublimiares de<br>alta densidade (HD-<br>SDM) ou com<br>normal densidade<br>(ND-SDM)|fotocoagulação a laser<br>focal/grid_modified_<br>_Early Treatment_<br>_Diabetic Retinopathy_<br>_Study_(mETDRS)|Baixo Risco de Viés|
|**Fong et al. 2007**<br>**(DRCRNet)**<br>**123**|ECR,<br>DRCRNet|Comparar duas técnicas de<br>fotocoagulação a laser para o tratamento<br>de EMD: fotocoagulação grid/ direta<br>ETDRS modificado versus moderada<br>macular (grid)|Não tratada; envolvendo o centro<br>da macula (CST≥ 300μm e BCVA<br>≥ 19 letras).|263<br>participantes<br>(323 olhos)|Fotocoagulação grid/<br>direta ETDRS<br>modificado<br>(mETDRS)|Fotocoagulação<br>moderada macular grid<br>(MMG)|Risco de viés Alto<br>(Desfecho incompleto)|  
EMD: edema macular diabético; ECR: ensaio clínico randomizado; BCVA: acuidade visual de melhor corrigida; ND-SDM: Fotocoagulaçãomicropulso laser-diode com sublimiares de normal densidade; HD-SDM: Fotocoagulaçãomicropulso laser-diode com sublimiares de alta densidade; mETDRS: fotocoagulação grid/ direta ETDRS modificado; MMG: fotocoagulação moderada macular grid; ETRDS: EarlyTreatmentDiabeticRetinopathyStudyResearchGroup; CST: espessura do subcampo central; CMT: espessura macular central; DRCRNet: DiabeticRetinopathyClinicalResearch Network.  
**Tabela 84** – <mark>Características de linha de base dos participantes dos ensaios clínicos randomizados que compararam diferentes tipos de laser</mark>  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual.**<br>**Média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Vujosevic et**<br>**al. 2015**<sup>**136**</sup>|Y-MPL|IR-MPL|26|27|61.7 (9.3)|63.3 (11.7)|92.3 vs. 66.6|NR|79.7 (6.1) vs. 78.6<br>(7.5)|357.8 (46.1) vs. 340.1<br>(35.7) **|3 e 6 meses|
|**Lavinsky et**<br>**al. 2011**<sup>**135**</sup>|HD-SDM<br>ND-SDM|mETDRS|42<br>39|42|61.9 (8.5)<br>62.0 (7.4)|61.8 (7.0)|43 vs. 45<br>46 vs. 45|8.2 (0,6) vs.<br>7.9 (0,6)<br>8.0 (0,6) vs.<br>7.9 (0,6)|LogMAR (mediana<br>(min-máx): 0.90<br>(0.30–1.30) vs. 0.80<br>(0.30–1.30)<br>LogMAR (mediana<br>(min-máx): 0.70<br>(0.40–1.30) vs. 0.80<br>(0.30–1.30)|LogMAR (mediana (min-<br>máx):371 (297–879) vs.<br>370 (269–710) **<br>LogMAR (mediana (min-<br>máx):379 (279–619) vs.<br>370 (269–710) **|3,6, 9 e 12 meses|  
172  
|**Autor (es)**|**Intervenção**|**Controle**|**N (n olhos)**<br>**intervenção**|**N (n olhos)**<br>**controle**|**Idade**<br>**intervenção**<br>**média (DP)**|**Idade**<br>**controle**<br>**média**<br>**(DP)**|**% sexo masc.**<br>**(Intervenção**<br>**vs. Controle**|**HbA1c (%),**<br>**média (DP)**<br>**(Intervenção**<br>**vs. Controle)**|**Acuidade visual.**<br>**Média ETDRS (DP)**<br>**(Intervenção vs.**<br>**Controle)**|**Espessura da retina**<br>**(µm)**<br>**(Intervenção vs.**<br>**Controle)**|**Tempo de**<br>**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Fong et al.**||||||||||||
|**2007**<br>**(DRCRNet)**<br>**123**|MMG|mETDRS|161|162|59 (11)|58 (11)|57 vs. 62|8,2 (1,9) vs.<br>8,2 (2,1)|73 (14) vs. 74 (12)|335 (128) vs. 346 (118) *|3.5, 8 e 12 meses|  
CST: espessura do subcampo central*; CMT: espessura macular central***; FTH: espessura foveal; EMD: edema macular diabético; Masc.: masculino; ECR: ensaio clínico randomizado; BCVA: acuidade visual de melhor corrigida; Min-max: mínimo e máximo; ND-SDM: Fotocoagulaçãomicropulso laser-diode com sublimiares de normal densidade; HD-SDM: Fotocoagulaçãomicropulso laser-diode com sublimiares de alta densidade; mETDRS: fotocoagulação grid/ direta ETDRS modificado; MMG: fotocoagulação moderada macular grid;ETRDS: EarlyTreatmentDiabeticRetinopathyStudyResearchGroup; DRCRNet: DiabeticRetinopathyClinicalResearch Network; HbA1c: hemoglobina glicada; NR: não reportado; DP: desvio padrão; IQR: intervalo interquartil.  
**Tabela 85 –** Desfechos de eficácia dos ensaios clínicos randomizados que compararam diferentes tipos de laser  
|**Autor, ano**|**Intervenção**|**Controle**|**Desfechos visuais**|**Valor de p**|**Desfechos Anatômicos**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Vujosevic**<br>**et al.**|Y-MPL|IR-MPL|**Alteração média da acuidade visual de melhor**<br>**corrigida (DP) entre a linha de base e aos A) 3 meses B)**||**CRT média (µm) entre a linha de base e aos B) 6**<br>**meses**||
|**2015**<sup>**136**</sup>|||**6 meses**|A) 0.87 *; B)0.96*|Média (DP) Y-MPL: 339.9 (55.7)|B)0.009 *|
||||DM (DP) Y-MPL: A) −0.3 (4.1); B) −1.0 (4.7)|A)0.2 *; B) 0.2*|Média (DP) IR-MPL: 335.3 (54.5)|B) 0.45*|
||||<br>DM (DP) IR-MPL: A) −0.1 (2.9); B) −1.3 (4.6)|A)0.3 **; B)0.62**||B) 0.16 **|
|**Lavinsky et**|HD-SDM|mETDRS|**Ganho médio da acuidade visual de melhor corrigida**|A) <0.001 ●; B) <0.001|**Redução média da CMT (µm) (DP) entre a linha de**|A) 0.001 ●; B) <0.001 ●|
|**al. 2011**|||**(LogMAR) (DP) entre a linha de base e aos A) 3 meses**|●|**base e aos A) 3 meses B) 6 meses C) 9 meses D) 12**|C) <0.001 ●; D) <0.001●|
|**135**|||**B) 6 meses C) 9 meses D) 12 meses**|C) <0.001●; D) <0.001|**meses**||
||ND-SDM||DM (DP) HD-SDM: A) -0.12 (0.18); B) -0.15 (0.21); C) -<br>0.19 (0.27); D) -0.25 (0.31)|●<br>A) 0.05**; B) 0.07**;|DM (DP) HD-SDM: A) -93 (102); B) -117 (119);<br>C) -144 (140); D) -154 (157)|A) 0.22**; B) 0.60 **;<br>C) 0.59**; D)0.75**|
||||DM (DP) ND-SDM: A)0.02 (0.14); B) 0.03 (0.18); C)0.00<br>(0.27); D)0.03 (0.22)|C) 0.02 **; D) 0.009 **<br>A) 0.009 **; B)0.002|DM (DP) ND-SDM: A) -20 (71); B) -20 (97)<br>C) -34 (106); D) -32 (107)|A) 0.01 **; B)0.001 **<br>C)0.01 **; D)0.001 **|
||||DM (DP) mETDRS: A) -0.04 (0.14); B) -0.07 (0.15); C) -|<br>**|DM (DP) mETDRS: A) -67 (78); B) -94 (86); C) -112||
||||0.07 (0.19); D) -0.08 (0.23)|C) 0.11 **; D)0.01 **|(107); D) - 126 (126)||
|**Fong et al.**<br>**2007**|MMG|mETDRS|**Alteração média da acuidade visual de melhor**<br>**corrigida (DP) entre a linha de base e aos A) 3.5 B) 8 e**||**Redução média da CST (µm) (DP) entre a linha de**<br>**base e 12 meses**||
|**(DRCRNet)**|||**C)12 meses**||DM (DP) MMG: −49 (122)|<0.02*|
|<br>**123**|||<br>DM (DP) MMG: A) −1 (12); B) −2 (10); C) −2 (11)|A) 0.10 **; B) 0.46 **;|<br>DM (DP) mETDRS: −88 (138)|<0.02*|
||||<br>DM (DP) mETDRS: A) 0 (13); B) −1 (12); C) 0 (11)|C) 0.10**||0.02**|
||||∆ (IC 95%) MMG – mETDRS: 2 (-0,5, 5)|>0.05|∆ (IC 95%) MMG – mETDRS: 33 (5, 61)|<0.05|  
Valor de p da diferença do valor do desfecho no tempo de seguimento versus na linha de base *; valor de p da diferença entre a intervenção versus o controle **; Valor p da diferença entre HD-SDM versus. ND-SDM●; CRT: espessura central da retina; CST: espessura do subcampo central; CMT: espessura macular central;ND-SDM: Fotocoagulaçãomicropulso laser-diode com sublimiares de normal densidade; HD-SDM:  
173  
Fotocoagulaçãomicropulso laser-diode com sublimiares de alta densidade; mETDRS: fotocoagulação grid/ direta ETDRS modificado; MMG: fotocoagulação moderada macular grid; DM: diferenças de médias; ∆: diferença; DP: desvio padrão; IC 95%: intervalo de confiança.  
**Tabela 86 –** Desfechos de segurança de ensaios clínicos randomizados que compararam diferentes tipos de laser  
|**Autor, ano:**<br>**Eventos Adversos**|**Vujosevic et al. 2015**<sup>**136**</sup><br>**Y-MPL vs. IR-MPL**|**Valor de p**|**Lavinsky et al. 2011**<sup>**135**</sup><br>**HD-SDM vs. ND-SDM vs.**<br>**mETDRS**|**Valor de p**|**Fong et al. 2007 (DRCRNet)**<sup>**123**</sup><br>**MMG vs. mETDRS**|**Valor de p**|
|---|---|---|---|---|---|---|
|**EA Sério relacionados ao**<br>**tratamento**|NR|NR|0 vs. 0 vs. 0|>0.05|NR|NR|
|**Lesões coroides ou da**<br>**retina visíveis**|0 vs. 0|>0.05|NR|NR|NR|NR|
|**Alteração da integridade e**|||||||
|**da refletividade na retina**|0 vs. 0|>0.05|NR|NR|NR|NR|
|**externa**|||||||
|**Deslocamento**<br>**neurossensorial**|NR|NR|NR|NR|1 vs. 0|>0.05|  
ND-SDM: Fotocoagulaçãomicropulso laser-diode com sublimiares de normal densidade; HD-SDM: Fotocoagulaçãomicropulso laser-diode com sublimiares de alta densidade; mETDRS: fotocoagulação grid/ direta ETDRS modificado; MMG: fotocoagulação moderada macular grid; EA: eventos adversos; NR: não reportado.  
174

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **I. Questão de pesquisa 9** -->
**Questão de Pesquisa 9:** Em quais casos se deve utilizar tratamento cirúrgico quando a condição é edema macular que envolve o centro da fóvea?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1) Estratégias de Busca** -->
As questões de pesquisa 5-10 referiram-se ao tratamento da retinopatia diabética com laser, vitrectomia ou terapia farmacológica (corticosteroides e/ou Anti-VEGFs), especificado em relação à presença ou não de edema macular, a localização do edema (centro da fóvea ou não) e extensão do tratamento (fixo, pro re nata ou tratar e extender). Dessa forma, uma única estratégia sensível de busca, descrita abaixo, foi elaborada e os resultados do processo de avaliação da elegibilidade foram estratificados de acordo com a questão de pesquisa.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **MEDLINE via pubmed:** -->
(((((((((("Light Coagulation"[Mesh] OR coagulation, light OR coagulations, light OR light coagulation OR photocoagulation OR photocoagulations OR laser photocoagulation OR laser coagulation)) OR ("Bevacizumab"[Mesh] OR avastin OR intravitreal bevacizumab)) OR ("Ranibizumab"[Mesh] OR lucentis OR intravitreal ranibizumab)) OR ("aflibercept" [Supplementary Concept] OR eylea OR intravitreal aflibercept)) OR ("Fluocinolone Acetonide"[Mesh] OR Iluvien OR intravitreal fluocinolone acetonide)) OR ("Dexamethasone"[Mesh] OR ozurdex OR intravitreal dexamethasone)) OR ("Vitrectomy"[Mesh] OR vitrectomy))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ("Treatment Outcome"[Mesh] OR efficacy OR effectiveness OR safety)

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
(("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ((((fixed regimen OR fixed scheme OR fixed)) OR (PRN OR pro re nata OR pro re nata regimen OR PRN regimen OR as needed OR PRN scheme OR pro re nata scheme)) OR (Treat and extend regimen OR treat-and-extend regimen OR treat and extend scheme OR treat-and-extend scheme OR treat and extend OR treat-and-extend))  
Total: 2328 referências  
Data do acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('treatment outcome'/exp OR 'treatment outcome' OR 'safety'/exp OR safety OR 'efficacy'/exp OR efficacy OR effectiveness) AND ('bevacizumab'/exp OR 'bevacizumab' OR 'avastin'/exp OR 'avastin' OR 'intravitreal bevacizumabe' OR 'ranibizumab'/exp OR 'ranibizumab' OR 'lucentis'/exp OR 'lucentis' OR 'intravitreal ranibizumab' OR 'aflibercept'/exp OR 'aflibercept' OR 'eylea'/exp OR 'eylea' OR 'intravitreal aflibercept' OR 'dexamethasone'/exp OR 'dexamethasone' OR 'ozurdex'/exp OR 'ozurdex' OR 'intravitreal dexamethasone' OR 'fluocinolone acetonide'/exp OR 'fluocinolone acetonide' OR 'iluvien'/exp OR 'iluvien' OR 'intravitreal fluocinolone acetonide' OR 'laser coagulation'/exp OR 'laser coagulation' OR 'laser photocoagulation'/exp OR 'laser photocoagulation' OR 'vitrectomy'/exp OR 'vitrectomy' OR 'pars plana vitrectomy'/exp OR 'pars plana vitrectomy') AND [embase]/lim

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('fixed regimen' OR 'fixed scheme' OR 'fixed' OR 'prn'/exp OR 'prn' OR 'pro re nata' OR 'pro re nata regimen' OR 'prn regimen' OR 'as needed' OR 'prn scheme' OR 'pro re nata scheme' OR 'treat and extend regimen' OR 'treat-and-extend regimen' OR 'treat and extend scheme' OR 'treat-and-extend scheme' OR 'treat and extend' OR 'treatand-extend') AND [embase]/lim  
Total: 2394 referências  
Data de acesso: 29/12/2016  
175  
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 4.722 referências (2.328 no MEDLINE e 2.394 no Embase). Destas, 753 foram excluídas por estarem duplicadas. Três mil novecentos e sessenta e nove referências foram triadas por</mark> meio da leitura de título e resumos, das quais 214 referências, correspondentes às 7 questões de pesquisa, tiveram seus textos completos avaliados para confirmação da elegibilidade.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Sete referências tiveram sua elegibilidade confirmada através da leitura do texto completo. Destas, 2 foram excluídas, uma por ser uma revisão sistemática que mostrou uma única medida sumária envolvendo dados de ECR e de estudos observacionais, e outra por não contemplar, majoritariamente, população com edema macular. Dessa forma, foi incluída uma revisão sistemática com metaanálise<sup>144</sup> , um ECR<sup>146</sup> e três estudos observacionais<sup>142,143,237</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
As características dos estudos incluídos encontram-se na **Tabela 87** . As características basais estão demonstradas na **Tabela 88** . A **Tabela 89** exibe os principais desfechos para os estudos incluídos. Na **Tabela 90** são exibidos os principais eventos adversos relatados.  
176  
**Tabela 87 –** Características dos estudos incluídos para a resposta à questão 9  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Revisão sistemática com meta-**|**análise**|||
|**Simunovic**<br>**et al. 2014**<br>**144**|Revisão<br>sistemática com<br>meta-análise|Levantar dados de eficácia da VPP<br>(acuidade visual e Espessura macular)<br>para pacientes com edema macular<br>diabético.|11 ECR incluídos, avaliando 376 olhos<br>com edema macular diabético|VPP com ou sem Peeling de<br>membrana interna limitante (ILM)|Observação<br>FPR<br>VPP|Baixo|
||||**Ensaios clínicos randomiza**|**dos**|||
|**Raizada et**<br>**al. 2015**<sup>**146**</sup>|ECR|Comparar a efetividade da VPP + ILM<br>vs. BIV em pacientes com EMCS|44 participantes, com diabetes mellitus e<br>edema macular diabético|VPP com três veios de calibre 23,<br>com indução de um desprendimento<br>vítreo posterior, seguido por 0,5<br>mg/ml de indocianina verde.|BIV|Baixo|
||||**Estudo de comparação não-rand**|**omizado**|||
|**Park et al.**<br>**2009**<sup>**238**</sup>|Estudo<br>observacional<br>prospectivo|Avaliar a influência da circulação<br>micromacular nos desfechos de<br>vitrectomia em pacientes com Diabetes<br>mellitus tipo dois e EMD|30 pacientes (33 olhos) com diabetes<br>mellitus e EMD; 16 controles diabéticos<br>sem edema.|Vitrectomia|Sem intervenção|Alto (sem<br>representatividade<br>demonstrada, não detalha a<br>população de onde vieram<br>os controles, não existe<br>controle por fatores de<br>confundimento|
||||**Série de casos**||||
|**Haller et**<br>**al. 2010;**<br>**Flaxel et**<br>**al. 2010**<br>**142,143**|Série de Casos|Levantar dados de eficácia da VPP<br>(acuidade visual e Espessura macular)<br>para pacientes com edema macular<br>diabético.|241 participantes (241 olhos) (87<br>pacientes no estudo de**Haller et al.**<br>**2010**) com diabetes mellitus tipo 1 ou 2,<br>edema macular envolvendo e tração<br>vitreomacular com visão comprometida|Vitrectomia|NA|Alto (série de casos para<br>desfechos de eficácia)|  
VPP: vitrectomia via pars plana; ECR: ensaio clínico randomizado; BIV: bevacizumabe intravítreo; ILM: peeling de membrana interna limitante, FPR: Fotocoagulaçãopan-retinal.  
177  
**Tabela 88 –** Características basais dos estudos primários incluídos  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**intervenção,**<br>**média (DP)**|**Idade**<br>**controle,**<br>**média (DP)**|**% sexo masc.**<br>**Intervenção**|**% sex masc**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central**<br>**da retina (µm),**<br>**média (DP)**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Raizada et al.**<br>**2015**<sup>**146**</sup>|22 olhos|22 olhos|54 (4,33)|53,8 (5,57)|NR|NR|VPP: 9,4<br>(0,97);<br>BIV: 9,9 (1,37)|MAVC:<br>VPP: 0,871 (0,273)<br>BIV: 0,894 (0,303)|VPP: 410,18<br>(127,16);<br>BIV: 432,77 (86,04)|6 meses|
|**Haller et al.**<br>**2010; Flaxel et**<br>**al. 2010**<sup>**142,143**</sup>|214 participantes<br>**e**|(87 avaliados em**Haller**<br>**t al. 2010**)|Mediana (IQR)<br>265 (2|:<sup>1</sup>66 (60;72);<br>8; 88)|155%;|250%|17,1 (6,7; 7,9);<br>27,3 (6,6; 8,1)|Letras ETDRS e<br>Snellen eq. (IQR):<br>152 (41, 58);<br>257 (45, 66).|Mediana (IQR):<br>1491 (356, 586);<br>2412 (337, 540)|12 meses|
|**Park et al.**<br>**2009**<sup>**238**</sup>|30<br>participantes<br>(33 olhos)|16 participantes/olhos|59,3 (9,8)|60,2 (9,1)|NR|NR|ng/dL:<br>VPP: 7,64<br>(1,12);<br>Controle: 7,66<br>(0,81).|VPP: 1,04 (0,52);<br>Controle: NR|VPP: 456,6 (176,1);<br>Controle: NR|12 meses|  
VPP: vitrectomia via pars plana; MAVC: melhor acuidade visual corrigida; IQR: intervalo interquartil; Hb1C: hemoglobina glicada; Masc.: masculino; DP: desvio padrão;NR: Não relatado.  
**Tabela 89 –** Principais resultados para os estudos incluídos  
178  
|**Autor, ano**|**Grupo**|**Acuidade visual, Logmar,**<br>**média (DP)**|**Espessura central macular (µm),**<br>**média (DP)**|**Fluxo sanguíneo retinal**<br>**(unidade arbitrária - não**<br>**definida)**|**Fatores associados a melhora**<br>**na acuidade visual entre 0 e 6**<br>**meses (multivariado), mediana**<br>**(IQR):**|**Fatores associados a melhora na**<br>**espessura macular (OCT) entre 0 e**<br>**6 meses (multivariado), mediana**<br>**(IQR):**|
|---|---|---|---|---|---|---|
||VPP vs.<br>observação (6<br>meses)|Probabilidade de atingir<br>melhora ≥ 2 linhas: OR = 4,44<br>(IC95%, 1,15; 17,13), p=0,03,<br>I2=26%; (favorece VPP)<br>Probabilidade de atingir perda<br>≥ 2 linhas: OR = 0,38 (IC95%,<br>0,12; 1,20), p=0,10, I2=5%|DMP:1,16 (IC95%, 0,67; 1,65);<br>p<0,001; I2=0% (Favorece VPP)|NR|NR|NR|
|**Simunovic et**<br>**al. 2014**<sup>**144**</sup>|VPP vs. laser<br>(6 meses)|Probabilidade de atingir<br>melhora ≥ 2 linhas: OR = 3,21<br>(IC85%, 0,78; 13,12), p=0,10;<br>I2=0%|DMP: 1,11 (IC95%, 0,14; 2,08),<br>p=0,02; I2=67% (favorece VPP)|NR|NR|NR|
||VPP vs. laser<br>(12 meses)|Basal-final LOGMAR, DM: -<br>0,07 (IC95%, -0,22; 0,07),<br>p=0,33, I2=0%|DM: 1,96 (IC95%, -113,08;<br>117,01), p=0,97, I2=23%|NR|NR|NR|
||VPP+ILM vs.<br>VPP (6<br>meses)|Probabilidade de atingir<br>melhora ≥ 2 linhas: OR = 1,69<br>(IC95%, 0,34; 8,49), P=0,86,<br>I2=0%||NR|NR|NR|
||VPP + ILM|Em 6 meses: 0,691 (p=0,028<br>em relação ao basal);|Em 6 meses: 324,3 (p<0,001 em<br>relação ao basal);|NR|NR|NR|
|**Raizada et al.**||6 meses-basal: -0,19 (0,32)|6 meses-basal: 161,36(105,94)||||
|<br>**2015**<sup>**146**</sup>|IVB|Em 6 meses: 0,682 (p=0,0181<br>em relação ao basal);<br>6 meses-basal: -0,20 (0,26), p<br>= 0,871 p/ VPP vs. BIV|Em 6 meses: 248,8 (p<0,001 em<br>relação ao basal);<br>6 meses-basal: 108,45 (79,64), p =<br>0,068 p/ VPP vs. BIV||||  
179  
|**Autor, ano**|**Grupo**|**Acuidade visual, Logmar,**<br>**média (DP)**|**Espessura central macular (µm),**<br>**média (DP)**|**Fluxo sanguíneo retinal**<br>**(unidade arbitrária - não**<br>**definida)**|**Fatores associados a melhora**<br>**na acuidade visual entre 0 e 6**<br>**meses (multivariado), mediana**<br>**(IQR):**|**Fatores associados a melhora na**<br>**espessura macular (OCT) entre 0 e**<br>**6 meses (multivariado), mediana**<br>**(IQR):**|
|---|---|---|---|---|---|---|
|**Haller et al.**<br>**2010**<sup>**142,143**</sup>|VPP|3 meses:<br>Melhora ≥ 10 letras: 22%;<br>Piora ≥ 10 letras: 23%;<br>6 meses:<br>Melhora ≥ 10 letras: 38%<br>(95%IC, 28%–49%);<br>Piora ≥ 10 letras: 22% (95%IC,<br>13%–31%).<br>12 meses* (mediana (IQR)):<br>20/80 (20/50 –20/160);<br>Melhora ≥ 10 letras: 30 (38%);<br>Piora ≥ 10 letras: 20 (26%)<br>(95%IC, 13%–31%).|3 meses em relação ao basal<br>(redução mediana):<br>Redução ≥50µm: 82%<br>Redução ≥100µm: 68%<br>Aumento ≥50µm: 3 (4%)<br>6 meses em relação ao basal<br>(redução mediana):<br>Redução ≥50µm: 82%<br>Redução ≥100µm: 66%<br>Redução p/<250µm: 33 (43%)<br>Olhos com maior espessura<br>macular no basal, melhoraram mais<br>(p<0,001) (dados não mostrados).<br>3 e 6 meses em relação ao basal:<br>mediana: -160µm (p<0,001);<br>12 meses*:Mediana (IQR): 256<br>(205–340);<br>Δ 12 meses basal: 153 (286–61).<br>Redução p/<250µm: 33 (47%)|NR|NR|NR|  
180  
|**Autor, ano**|**Grupo**|**Acuidade visual, Logmar,**<br>**média (DP)**|**Espessura central macular (µm),**<br>**média (DP)**|**Fluxo sanguíneo retinal**<br>**(unidade arbitrária - não**<br>**definida)**|**Fatores associados a melhora**<br>**na acuidade visual entre 0 e 6**<br>**meses (multivariado), mediana**<br>**(IQR):**|**Fatores associados a melhora na**<br>**espessura macular (OCT) entre 0 e**<br>**6 meses (multivariado), mediana**<br>**(IQR):**|
|---|---|---|---|---|---|---|
|||||||Mudança na espessura do subcampo<br>(µm) central; p=0,001:<br><300: -2 (-52 a +46);<br>300 a <400: -84 (-128 a -38);<br>≥400: -182 (-304 a -84).|
|**Flaxel et al.**<br>**2010**<sup>**143**</sup>|VPP|6 meses:<br>Mediana (IQR): 57 (44; 69);<br>Snellen eq: 20/80 (20/40 a<br>20/125)<br>Melhora ≥10 letras: 26%<br>(IC95%, 20-32%)<br>Piora ≥10 letras: 22% (IC95%,<br>17-27%);|Seis meses: Mediana (IQR): 278<br>µm (216–371)|NR|Acuidade visual basal; p<0,001;<br>≥20/40: -2 (-9 a +2);<br><20/40 a 20/80: +1 (-8 a +9);<br><20/80: +4 (-6 a 13).<br>Peeling da membrana epiretinal;<br>p=0,006:<br>Sim: -2 (-12 a +9);<br>Não: +3 (-5 a +11);|Acuidade visual basal; p<0,001:<br>≥20/40: -58 (-101 a -19;<br><20/40 a 20/80: 290 (-167 a -34);<br><20/80: -159 (-293 a -68).<br>Remoção da membrana interna<br>limitante; p=0,003:<br>Não: -88 (-167 a +2)<br>Sim: -106 (-231 a -51).|
|||||||Anormalidades vitreoretinais;<br>p=0,006:<br>Sem evidência: -85 (-167 a +1);<br>Questionável ou definido:        -104<br>(-201 a -39)|  
181  
|**Autor, ano**|**Grupo**|**Acuidade visual, Logmar,**<br>**média (DP)**|**Espessura central macular (µm),**<br>**média (DP)**|**Fluxo sanguíneo retinal**<br>**(unidade arbitrária - não**<br>**definida)**|**Fatores associados a melhora**<br>**na acuidade visual entre 0 e 6**<br>**meses (multivariado), mediana**<br>**(IQR):**|**Fatores associados a melhora na**<br>**espessura macular (OCT) entre 0 e**<br>**6 meses (multivariado), mediana**<br>**(IQR):**|
|---|---|---|---|---|---|---|
|||||1 semana: 998,6 (641,0); p=0,003<br>em relação ao basal;<br>4 semanas: 620,6 (458,1);<br>p=0,927 em relação ao basal;|||
|**Park et al.**<br>**2009**<sup>**238**</sup>|VPP|1 semana:<br>1,17 (0,51); p=0,278 em<br>relação ao basal;<br>4 semanas: 0,61 (0,36);<br>p<0,001 em relação ao basal;<br>12 semanas: 0,47 (0,34);<br>p<0,001 em relação ao basal.|1 semana:<br>375,3 (138,1); p=0,007 em relação<br>ao basal;<br>4 semanas: 365,9 (129,2); p=0,004<br>em relação ao basal;<br>12 semanas: 335,5 (125,9); p<0,001<br>em relação ao basal|12 semanas: 422,6 (247,5);<br>p=0,002 em relação ao basal;<br>p=0,47 em relação ao controle.<br>Razão Fluxo sanguíneo pós vs.<br>pré-cirurgia:<br>1 semana:<br>Com edema persistente: 2.67 ±<br>2.31;<br>Edema resolvido: 1,60 (0,96);<br>p=0,095<br>4 semanas:<br>Com edema persistente: 1,19<br>(0,58);<br>Edema resolvido: 1,18 (0,88);<br>p=0,96;<br>12 semanas:<br>Com edema persistente: 1,05<br>(0,54);<br>Edema resolvido: 0,67 (0,35);<br>p=0,02.|Análise Univariada:<br>Facoemulsificação (NS)<br>Laser periférico (NS)<br>Triancinolona intravítreo (NS)<br>Todos não significantes tanto<br>para resolução do edema, quanto<br>para melhora na acuidade visual.|NR|
||Controle|12 semanas: 0,25 (0,26);<br>p<0,001 em relação ao basal|12 semanas: 220,4 (25,4); p<0,001<br>em relação ao basal|12 semanas: 407,1 (265,9);<br>p=0,021 em relação ao basal.|NR|NR|  
*26% dos 78 pacientes que chegaram a 12 meses já haviam recebido outras intervenções como bevacizumabe, corticoides e fotocoagulação, que podem ter interferido nos resultados para a vitrectomia; BIV: Bevacizumabe Intravítreo; OCT: Tomografia de coerência ótica; VPP: vitrectomia via pars plana; DP: Desvio padrão; NR: não reportado; IQR: Intervalo interquartil; DMP: diferença de média padronizada; OR: Oddsratio ou razão de chances; DM: diferença de média; IC 95%: intervalo de confiança 95%; NS: Não significante;I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.  
182  
**Tabela 90 –** Principais resultados de segurança para o estudo incluído  
||**Autor, ano**|
|---|---|
|**Evento adverso**|**Haller et al. 2010**<sup>**142**</sup>|
||**VPP**|
|**Hemorragia vítrea, n (%)**|5 (6)|
|**Anormalidades vitreomaculares, n (%)**|2 (2)|
|**Elevação da pressão intraocular, n (%)**|7 (8)|
|**Descolamento da retina, n (%)**|3 (3)|
|**Endoftalmite, n (%)**|1 (1)|
|**Visão duplicada, n (%)**|2 (2)|
|**Buraco lamelar, n (%)**|1 (1)|
|**Efusão coroidal, n (%)**|1 (1)|
|**Outros (não especificado), n (%)**|2 (2)|  
VPP: vitrectomia via pars plana.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **J. Questão de pesquisa 10** -->
**Questão de Pesquisa 10:** Qual é a eficácia desses três esquemas terapêuticos (fixo, PRN, tratar e estender)?

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **1) Estratégias de Busca** -->
As questões de pesquisa 5-10 referiram-se ao tratamento da retinopatia diabética com laser, vitrectomia ou terapia farmacológica (corticosteroides e/ou Anti-VEGFs), especificado em relação à presença ou não de edema macular, a localização do edema (centro da fóvea ou não) e extensão do tratamento (fixo, pro re nata ou tratar e estender). Dessa forma, uma única estratégia sensível de busca, descrita abaixo, foi elaborada e os resultados do processo de avaliação da elegibilidade foram estratificados de acordo com a questão de pesquisa.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **MEDLINE via pubmed:** -->
(((((((((("Light Coagulation"[Mesh] OR coagulation, light OR coagulations, light OR light coagulation OR photocoagulation OR photocoagulations OR laser photocoagulation OR laser coagulation)) OR ("Bevacizumab"[Mesh] OR avastin OR intravitreal bevacizumab)) OR ("Ranibizumab"[Mesh] OR lucentis OR intravitreal ranibizumab)) OR ("aflibercept" [Supplementary Concept] OR eylea OR intravitreal aflibercept)) OR ("Fluocinolone Acetonide"[Mesh] OR Iluvien OR intravitreal fluocinolone acetonide)) OR ("Dexamethasone"[Mesh] OR ozurdex OR intravitreal dexamethasone)) OR ("Vitrectomy"[Mesh] OR vitrectomy))) AND ("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ("Treatment Outcome"[Mesh] OR efficacy OR effectiveness OR safety)

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
(("Diabetic Retinopathy"[Mesh] OR diabetic retinopathy)) AND ((((fixed regimen OR fixed scheme OR fixed)) OR (PRN OR pro re nata OR pro re nata regimen OR PRN regimen OR as needed OR PRN scheme OR pro re nata scheme)) OR (Treat and extend regimen OR treat-and-extend regimen OR treat and extend scheme OR treat-and-extend scheme OR treat and extend OR treat-and-extend))  
Total: 2328 referências  
Data do acesso: 29/12/2016

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **EMBASE** -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('treatment outcome'/exp OR 'treatment outcome' OR 'safety'/exp OR safety OR 'efficacy'/exp OR efficacy OR effectiveness) AND ('bevacizumab'/exp OR 'bevacizumab' OR 'avastin'/exp OR 'avastin' OR 'intravitreal bevacizumabe' OR 'ranibizumab'/exp OR 'ranibizumab' OR 'lucentis'/exp OR 'lucentis' OR 'intravitreal ranibizumab' OR  
183  
'aflibercept'/exp OR 'aflibercept' OR 'eylea'/exp OR 'eylea' OR 'intravitreal aflibercept' OR 'dexamethasone'/exp OR 'dexamethasone' OR 'ozurdex'/exp OR 'ozurdex' OR 'intravitreal dexamethasone' OR 'fluocinolone acetonide'/exp OR 'fluocinolone acetonide' OR 'iluvien'/exp OR 'iluvien' OR 'intravitreal fluocinolone acetonide' OR 'laser coagulation'/exp OR 'laser coagulation' OR 'laser photocoagulation'/exp OR 'laser photocoagulation' OR 'vitrectomy'/exp OR 'vitrectomy' OR 'pars plana vitrectomy'/exp OR 'pars plana vitrectomy') AND [embase]/lim

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: OR -->
'diabetic retinopathy'/exp OR 'diabetic retinopathy' AND ('fixed regimen' OR 'fixed scheme' OR 'fixed' OR 'prn'/exp OR 'prn' OR 'pro re nata' OR 'pro re nata regimen' OR 'prn regimen' OR 'as needed' OR 'prn scheme' OR 'pro re nata scheme' OR 'treat and extend regimen' OR 'treat-and-extend regimen' OR 'treat and extend scheme' OR 'treat-and-extend scheme' OR 'treat and extend' OR 'treatand-extend') AND [embase]/lim  
Total: 2394 referências  
Data de acesso: 29/12/2016  
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 4.722 referências (2.328 no MEDLINE e 2.394 no Embase). Destas, 753 foram excluídas por estarem duplicadas. Três mil novecentos e sessenta e nove referências foram triadas por</mark> meio da leitura de título e resumos, das quais 214 referências, correspondentes às 7 questões de pesquisa, tiveram seus textos completos avaliados para confirmação da elegibilidade.

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **2) Seleção das evidências** -->
Somente foram elegíveis estudos que consideravam pacientes com edema macular diabético e comparando esquemas de tratamento entre Anti-VEGFs (associados ou não a laser) ou entre estes e “sham”. Qualquer outra comparação não foi considerada. Estudos que não tiveram um braço específico ou majoritário com apenas um único esquema terapêutico (PRN, fixo ou tratar e estender) foram excluídos. Ensaios clínicos contidos em revisões sistemáticas, também foram excluídos. Só foram considerados ECR não contidos nas revisões e que atendessem aos critérios acima especificados.  
Quinze potenciais referências tiveram sua elegibilidade confirmada através da leitura do texto completo, sendo duas adquiridas por busca manual. Destas, 7 foram excluídas, uma por não incluir anti-VEGFs, uma por considerar pacientes sem edema macular diabético e cinco por não ter um braço específico do estudo para apenas um dos regimes terapêuticos (fixo, PRN e tratar e estender). Dessa forma, foram incluídas duas revisões sistemáticas com meta-análise<sup>134,214</sup> e seis ensaios clínicos randomizados<sup>128,129,149,238-240</sup> .

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
As características dos estudos incluídos encontram-se na **Tabela 91** abaixo. As características basais estão demonstradas na **Tabela**  
**92** . A **Tabela 93** exibe os principais desfechos para os estudos incluídos. Nas **tabelas 94 e 95** são exibidos os principais eventos adversos relatados.  
184  
**Tabela 91 –** Características dos estudos incluídos para a resposta à questão 10  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle/comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||Avaliar a eficácia e a segurança entre|**Revisões sistemáticas com me**<br>11 estudos foram incluídos|**ta-análises**|||
|**Korobelnik et al.**<br>**2015**<sup>**215**</sup>|Revisão sistemática<br>com meta-análise de<br>comparação indireta|<br>esquemas de diferentes Anti-VEGF<br>em pacientes com EMD em diferentes<br>estágios|(população de 3323<br>participantes com edema<br>macular)|AIV 2m a cada 8 semanas<br>(fixo)|RIV 0,5 mg (PRN)|Baixo|
|**Yanagida e Ueta,**<br>**2014**<sup>**134**</sup>|Revisão sistemática<br>com meta-análise|Avaliar a segurança do uso de<br>ranibizumabe em estudos que<br>avaliaram pacientes com EMD|6 estudos foram incluídos,<br>com uma população de 2459<br>participantes|RIV + laser<br>RIV|RIV ou laser<br>Sham|Baixo|
|**Payne et al.**<br>**2017**<sup>**239**</sup>**(TREX-**<br>**DME)**|ECR fase I/II|Avaliar a segurança e eficácia do RIV<br>associado ou não a laser em pacientes<br>com EMD|**Ensaios clínicos random**<br>116 pacientes (150 olhos,<br>137 completaram 1 ano de<br>seguimento) com edema<br>macular diabético<br>envolvendo o centro da fóvea|**izados**<br>RIV a cada 4 semanas<br>(mensal);<br>RIV quatro injeções<br>mensais e depois tratar e<br>estender (TREX)|RIV quatro injeções<br>mensais e depois tratar e<br>estender + laser (GILA)|Baixo|
|**Prunte et al.**<br>**2015**<sup>**240**</sup><br>**(RETAIN)**|ECR fase III|Avaliar a não inferioridade do RIV no<br>regime tratar e extender, associado ou<br>não a laser|372 participantes (332<br>finalizaram o estudo, 89,2%)<br>com diabetes melitus tipos 1<br>e 2 e edema macular<br>diabético.|RIV 0,5 mg tratar e<br>estender + laser (RIV TE<br>LA)RIV 0,5 mg tratar e<br>estender (RIV TE)|RIV 0,5 mg PRN (RIV<br>PRN)|Baixo*|
|**Gonzalez et al**<br>**2015; Do et al.**<br>**2012**<sup>**;**</sup>**Do et al.**<br>**2011**<sup>**128,129,241**</sup><br>**(DA VINCI)**|ECR fase II|Avaliar a eficácia de diferentes doses<br>e regimes de aflibercepte em<br>pacientes com edema macular<br>envolvendo o centro da fóvea|**Gonzalez et al. 2005**: 46<br>pacientes (37 completaram<br>12 meses de seguimento)<br>com diabetes mellitus tipos I<br>e II e EMCS;<br>**Do et al. 2011**e**Do et**<br>**al.2012**: 221 olhos, dos quais<br>219 foram tratados e 176<br>terminaram 12 meses de<br>seguimento. Condição:<br>diabetes mellitus tipos I e II e<br>EMCS|AIV 0,5 mg a cada 4<br>semanas (0,5q4);<br>AIV 2 mg a cada 4<br>semanas (2q4);<br>AIV 2 mg a cada 8<br>semanas, após 3 doses<br>mensais (2q8); e<br>AIV 2 mg PRN, após 3<br>doses mensais (PRN).|Laser|Alto (randomização, sigilo de alocação,<br>cegamento, relato seletivo(Do etal.<br>2012))|  
185  
|**Autor, ano**|**Desenho de estudo**|**Objetivo**|**População**|**Intervenção**|**Controle/comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Lang, 2013**<sup>**150**</sup><br>**(RESTORE)**|ECR fase III de<br>extensão|Avaliar a eficácia e a segurança do<br>ranibizumabe 0,5 mg em pacientes<br>com EMD, em 2 anos|240 participantes (dos 303<br>que completaram o estudo<br>RESTORE principal) com<br>edema macular diabético.<br>220 completaram dois anos|RIV 0,5mg PRN|Como se trata de um<br>estudo open-label, as<br>comparações foram feitas<br>de acordo com os grupos<br>do estudo principal (RIV<br>vs. RIC+ laser vs. laser)|Baixo|  
Anti-VEGF: inibidor do fator de crescimento do endotélio vascular; EMD: edema macular diabético; EMCS: Edema macular clinicamente significante; AIV: aflibercepte intravítreo; RIV: ranibizumabe intravítreo; PRN: regime Pro re nata (ou "As needed"); *Apesar do risco de viés baixo, o estudo realizou análise de não-inferioridade considerando os pacientes entre os períodos mês 1 a mês 12, sem detalhar o quantitativo de participantes a cada mês e quantos foram imputados, o que pode ter superestimado o valor de acuidade visual a favor do regime tratar e estender (análise de superioridade foi a favor do regime PRN - Tabela 3).  
**Tabela 92 –** Características basais para os estudos primários incluídos para a resposta à questão 10  
|**Autor, ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**intervenção,**<br>**média (DP)**|**Idade**<br>**controle,**<br>**média (DP)**|**% sexo**<br>**masc,**<br>**Intervenção**|**% sex**<br>**masc**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central**<br>**da retina (µm),**<br>**média (DP)**|**Sensibilidade da**<br>**retina (dB), média**<br>**(DP)**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Payne et**<br>**al. 2017**<sup>**239**</sup><br>**(TREX-**<br>**DME)**|Mensal: 3<br>TREX: 6<br>GILA: 60|0 olhos<br>0 olhos<br>olhos|Mensal:<br>TREX:<br>GILA:|58,7<br>59,4<br>59,9|Mensal:<br>TREX:<br>GILA:|47%<br>47%<br>60%|NR|**MAVC (letras**<br>**ETDRS (eq,**<br>**Snellen)):**<br>Mensal: 65,1<br>(20/60);<br>TREX: 64,1 (20/70)<br>GILA: 65,1 (20/60)|Mensal: 434<br>TREX: 475<br>GILA: 480|NR|12 meses|
|**Prunte et**<br>**al. 2015**<sup>**240**</sup><br>**(RETAIN)**|RIV TE LA:<br>117<br>RIV TE: 125|RIV PRN:<br>117|RIV TE LA:<br>63,7 (9,1)<br>RIV TE: 63,0<br>(9,8)|RIV PRN:<br>64,5 (9,7)|RIV TE<br>LA: 78<br>(64,5)<br>RIV TE: 77<br>(60,2)|RIV PRN:<br>77 (62,6)|RIV TE LA:<br>7,8 (1,4)<br>RIV TE: 7,9<br>(1,3)<br>RIV PRN: 8,0<br>(1,2)|**Escore de letras**<br>**(DP):**<br>RIV TE LA: 61,7<br>(12,2)<br>RIV TE: 63,9 (10,8)<br>RIV PRN: 64,7<br>(10,2)|RIV TE LA: 480,7<br>(165,0)<br>RIV TE: 452,4<br>(131,2)<br>RIV PRN: 432,5<br>(129,9)|NR|24 meses|  
186  
|**Autor, ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**intervenção,**<br>**média (DP)**|**Idade**<br>**controle,**<br>**média (DP)**|**% sexo**<br>**masc,**<br>**Intervenção**|**% sex**<br>**masc**<br>**controle**|**HbA1c (%),**<br>**média (DP)**|**Acuidade visual**<br>**(escore de letra),**<br>**Logmar**|**Espessura central**<br>**da retina (µm),**<br>**média (DP)**|**Sensibilidade da**<br>**retina (dB), média**<br>**(DP)**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||**Letras ETDRS**<br>**(DP):**||**OCT central:**||
||0,5q4: 10;||64,7 (7,9);||6 (60,0);|||0,5q4: 57,0 (15,1);||0,5q4: 6,14 (4,90);||
|**Gonzalez**<br>**et al.**<br>**2015**<sup>**241**</sup>|2q4: 7;<br>2q8: 8;|Laser: 11|57,7 (5,4);<br>57,5 (11,9);|65,0 (6,7)|3 (42,9);<br>3 (37,5);|9 (81,8)|NR|2q4: 60,4 (13,6);<br>2q8: 63,6 (9,8);|NR|2q4: 8,79 (5,68);<br>2q8: 4,25 (3,77);|12 meses|
||2PRN: 10||58,8 (10,2),||6 (60,0),|||2PRN: 66,3 (10,9),||2PRN: 7,93 (5,14),||
|||||||||Laser: 60,2 (7,8)||Laser: 5,65 (5,18)||
|**Lang et al.**<br>**2013**<sup>**150**</sup>|240 pacientes (8<br>0,5mg; 83 pr<br>laser; e 74 pr|3 prévio RIV<br>évio RIV +<br>évio laser)|RIV 0,5: 6<br>RIV + laser:<br>Laser: 63,|2,9 (9,29)<br>64,0 (8,15)<br>5 (8,81)|RIV 0,5: 7<br>RIV + laser:<br>Laser: 58|3 (62,9)<br>70 (59,3)<br>(52,3)|NR|**Escore de letra:**<br>RIV 0,5: 64,8<br>(10,11)<br>RIV + laser: 63,4<br>(9,99)<br>Laser: 62,4 (11,11)|RIV 0,5: 426,6<br>(118,01)<br>RIV + laser: 416,4<br>(119,91)<br>Laser: 412,4<br>(123,95)|NR|24 meses|
||0,5q4: 44;||0,5q4: 62,3<br>(10,7);<br>24: 621||0,5q4: 54,5;||0,5q4: 8,10<br>(1,91);<br>2q4: 8,08<br>(1,94);|**Letras ETDRS:**<br>0,5q4: 59,3 (11,2);|0,5q4: 426,1<br>(128,3);|||
|**Do et al.**<br>**2012; Do et**<br>**al.**<br>**2011**<sup>**128,129**</sup>|2q4: 44;<br>2q8: 42;|Laser: 44|q ,<br>(10,5);<br>2q8: 62,5<br>|64,0 (8,1)|2q4: 61,4;<br>2q8: 52,8;|61,4|2q8: 7,85<br>(1,72);|2q4: 59,9 (10,1);<br>2q8: 58,8 (12,2);|2q4: 456,6 (135,0);<br>2q8: 434,8 (111,8);|NR|6 meses e 12<br>meses|
||2PRN: 45||(11,5);<br>2PRN: 60,7<br>(8,7)||2PRN: 64,4||2PRN: 7,97<br>(1,71)<br>Laser: 7,93<br>(1,84)|2PRN: 59,6 (11,1)<br>Laser: 57,6 (12,5)|2PRN: 426,6 (152,4)<br>Laser: 440,6 (145,4)|||  
PRN: esquema Pro Re Nata ( _as needed_ ); RIV: ranibizumabe intravítreo; Observação: para melhor entendimento da codificação dos esquemas terapêuticos veja Tabela 1; RIV: ranibizumabe intravítreo; TREX: RIV quatro injeções mensais e depois tratar e estender; RIV TE LA: RIV 0,5 mg tratar e estender + laser; RIV TE: RIV 0,5 mg tratar e estender;GILA: RIV quatro injeções mensais e depois tratar e estender + laser; MAVC: melhor acuidade visual ajustada; HbA1c: hemoglobina glicada; Masc.: masculino; DP: desvio padrão; NR: não reportado.  
187  
**Tabela 93 –** Principais desfechos para os estudos incluídos para a resposta à questão 10  
|**Autor, ano**|**Grupo**|**Acuidade visual**|**Nº médio de injeções (DP)**|**Sensibilidade da retina**|**Espessura central macular (µm), média**<br>**(DP)**|
|---|---|---|---|---|---|
|||**Revisão siste**|**mática com meta-análise**|||
|||**Método MTC:**||||
|||MAVC (mudança desde o basal) [int. credibilidade<br>95%]:<br>EF: MD= 4,67 [2,45–6,87]; (favorece AIV)<br>EA: MD= 4,67 [1,85–7,52]. (Favorece AIV)||||
|||Ganho ≥ 10 letras ETDRS [int. credibilidade 95%]:<br>EF: RR = 1,32 [0,98–1,78]; OR = 1,64 [0,97–2,78]; (NS)<br>EA: RR = 1,19 [0,90–1,57]; OR = 1,59 [0,75–3,35].<br>(NS)||||
|||Perda ≥ 10 letras ETDRS [int. credibilidade 95%]:<br>EF: RR = 0,27 [0,07–0,90]; OR = 0,27 [0,07–0,90];<br>(favorece AIV)<br>EA: RR = 0,28 [0,06–1,29]; OR = 0,26 [0,05–1,31].<br>(NS)||||
|**Korobelnik et al.**<br>**2015**<sup>**215**</sup>|AIV vs. RIV (12<br>meses)|Ganho ≥ 15 letras ETDRS [int. credibilidade 95%]:<br>EF: RR = 1,78 [0,96–3,29]; OR = 1,90 [0,95–3,75]; (NS)<br>EA: RR = 1,42 [0,93–2.24]; OR = 1,87 [0,87–4,16].<br>(NS)|NR|NR|NR|
|||Perda ≥ 15 letras ETDRS [int. credibilidade 95%]:<br>EF: RR = 0,13 [0,004–1,35]; OR = 0,13 [0,004–1,35];<br>(NS)<br>EA: RR = 0,14 [0,007–1,52]; OR = 0,14 [0,006–1,53].<br>(NS)||||
|||**Método Bucher:**||||
|||MAVC (mudança desde o basal) [IC 95%]:<br>EF: DM = 4,82 [2,52–7,11]; (favorece AIV)<br>EA: DM = 4,82 [2,52–7,11]. (Favorece AIV)||||
|||Ganho ≥ 10 letras ETDRS [IC 95%]:<br>EF: RR = 0,993 [0,65–1,52]; OR = 1,32 [0,74–2,35];<br>(NS)<br>EA: RR = 1,00[0,60–1,66];OR = 1,32[0,65–2,68].||||  
188  
|**Autor, ano**|**Grupo**|**Acuidade visual**|**Nº médio de injeções (DP)**|**Sensibilidade da retina**|**Espessura central macular (µm), média**<br>**(DP)**|
|---|---|---|---|---|---|
|||(NS)<br>Perda ≥ 10 letras ETDRS [IC 95%]:<br>EF: RR = 0,31 [0,09–1,04]; (NS)<br>OR = 0,28 [0,08–0,99]; (favorece AIV limítrofe)<br>EA: RR = 0,31 [0,09–1,09]; (NS)<br>OR = 0,27 [0,08–0,94] (favorece AIV limítrofe).<br>Ganho ≥ 15 letras ETDRS [IC 95%]:<br>EF: RR = 1,49 [0,78–2,85]; OR = 1,74 [0,83–3,65]; (NS)<br>EA: RR = 1,49 [0,78–2,85]; OR = 1,74 [0,83–3,65].<br>(NS)<br>Perda ≥ 15 letras ETDRS [IC 95%]:<br>EF: RR = 0,24 [0,03–1,90]; OR = 0,23 [0,03–1,86]; (NS)<br>EA: RR = 0,26 [0,03–2,11]; OR = 0,23 [0,03–1,86].<br>(NS)||||
|||**Ensaios**|**clínicos randomizados**|||
|||**12 meses:**||||
|**Payne et al.**<br>**2017**<sup>**239**</sup>|MensalTREXGILA|Mensal: +8,6 letras;<br>TREX: +9,6 letras;<br>GILA: +9,5 letras. p=0,80 (entre grupos)<br>**Ganho ≥ 10 letras**:<br>Mensal: 12 (41%)<br>TREX: 21 (40%)<br>GILA: 25 (45%)|Mensal: 13,2<br>TREX: 10,7<br>GILA: 10,1<br>p<0,001 p/TREX vs. mensal<br>e GILA vs. mensal. P =<br>0,246 p/GILA vs.<br>TREXMáx.|NR|12 meses:<br>Mensal: -123<br>TREX: -143<br>|
|||**Ganho ≥ 15 letras**:<br>Mensal: 7 (24%)<br>TREX: 14 (27%)<br>GILA: 18 (32%)<br>**Perda ≥ 10 letras**: TREX: 1 olho (não houve perda para<br>os demais regimes)|Intervalo (sem aplicação):<br>TREX: 8,1 semanas<br>GILA: 9,2 semanas<br>p<0,001 para as duas coortes<br>se comparadas à mensal||GILA: -166; p=0,47 (entre grupos)|  
189  
|**Autor, ano**|**Grupo**|**Acuidade visual**|**Nº médio de injeções (DP)**|**Sensibilidade da retina**|**Espessura central macular (µm), média**<br>**(DP)**|
|---|---|---|---|---|---|
|||**Diferença média MAVC**|||% mudança 12 meses (DP): −27,09 (22,992)|
|**Prunte et al.**<br>**2015**<sup>**240**</sup>|RIV TE LA**|Avaliação da não inferioridade<sup>¥</sup>x RIV PRN (basal - 1 a<br>12 meses):<br>0,39 (IC95%, −1,03; 1,81) p<0,001<br>Teste de superioridade x RIV PRN (basal - 1 a 24<br>meses): -0,30 (IC95%, -1,32; 1,92), p = 0,692<br>mudança 12 meses (DP): 6,79 (6,999)<br>mudança 24 meses (DP): 8,30 (8,129)|12,4 (3,8)|NR|% mudança 24 meses (DP): −32,03 (25,628)<br>Teste de superioridade x RIV PRN (basal - 1a<br>12 meses): 0,82 (IC95%, -4,6; 8,2), p = 0,218<br>Teste de superioridade x RIV PRN (basal - 1a<br>24 meses): 3,01 (IC95%, -3,26; 9,29), p =<br>0,0467|
|||**Diferença média MAVC**|||% mudança 12 meses (DP): −24,35 (22,027)%|
||RIV TE**|Avaliação da não inferioridade<sup>¥</sup>x RIV PRN (basal - 1 a<br>12 meses): 0,19 (IC95%, −1,21; 1,59) p<0,001<br>Teste de superioridade x RIV PRN (basal - 1 a 24<br>meses): -0,54 (IC95%, -1,06; 2,13), p = 0,519|12,8 (3,7)|NR|Mudança 24 meses (DP): −24,98 (26,414)<br>Teste de superioridade x RIV PRN (basal - 1 a<br>12 meses): -0,02 (IC95%, -5,25; 5,22), p =<br>0,738|
|||Mudança 12 meses: 6,80 (8,726)<br>Mudança 24 meses: 6,49 (10,854)|||Teste de superioridade x RIV PRN (basal - 1a<br>24 meses): -1,23 (IC95%, -7,34; 4,87), p =<br>0,9360|
||RIV PRN**|Mudança 12 meses: 7,44 (8,457)<br>Mudança 24 meses: 8,06 (8,462)|10,7 (5,6)||% mudança 12 meses (DP): −23,16 (22,362)<br>% mudança 24 meses (DP): −24,97 (26,678)|
||0,5q4||11,1 (3,3)|NR|NR|
|**Gonzalez et al.**<br>**2015**<sup>**241**</sup>|2q4||12,0 (1,5)|NR|NR|
||2q8||8,0 (0,0)|Melhora sign. 52 semanas em<br>relação ao basal (valores não<br>mostrados)|NR|  
190  
|**Autor, ano**|**Grupo**|**Acuidade visual**|**Nº médio de injeções (DP)**|**Sensibilidade da retina**|**Espessura central macular (µm), média**<br>**(DP)**|
|---|---|---|---|---|---|
||2PRN||6,1 (3,9)|Melhora sign. 24 e 52 semanas em<br>relação ao basal (valores não<br>mostrados)<br>Melhora Sign. 24 semanas em<br>relação ao basal vs. laser|NR|
||AIV agregado|Semana 24: 2,5 a 13,1 letras<br>semana 52: 5,4 a 16,3 letras|NR|Melhora sign. 24 e 52 semanas em<br>relação ao basal (valores não<br>mostrados);<br>melhora Sign. 24 semanas em<br>relação ao basal vs. laser|NR|
||Laser|Semana 24: 0,9 letras;<br>semana 52: 3,3 letras.|NA|NR||
|||**MAVC letras (DP):**||||
||Prévio RIV 0,5 mg|12 meses: +7,9 (7,4)<br>24 meses: 7,9 (9,0)|Após 24 meses:  11,3 (5,6)|NR|Redução em 12 meses: -127,8;<br>Redução em 24 meses: -140,6|
|||>78 letras (24 meses): 38,6%||||
|||**MAVC letras (DP):**||||
|**Lang et al.**<br>**2013**<sup>**150**</sup>|Prévio RIV 0,5 mg<br>+ laser|12 meses: +7,1 (7,3)<br>24 meses: 6,7 (7,9)<br>>78 letras (24 meses): 21,7%|Após 24 meses: 11,0 (5,6)|NR|Redução em 12 meses: -139,7;<br>Redução em 24 meses: -133|
|||**MAVC letras:**||||
||Prévio laser|12 meses: +2,3 (9,6)<br>24 meses: 5,4 (9,0)|Após 24 meses: 4,1 (3,6)|NR|Redução em 12 meses: -63,3<br>Redução em 24 meses: -126,6|
|||>78 letras (24 meses): 18,9%||||  
191  
|**Autor, ano**|**Grupo**|**Acuidade visual**|**Nº médio de injeções (DP)**|**Sensibilidade da retina**|**Espessura central macular (µm), média**<br>**(DP)**|
|---|---|---|---|---|---|
||0,5q4|Ganho ≥ 10 letras (semana 24): 50%<br>Ganho ≥ 15 letras (semana 24): 34%<br>Ganho ≥ 0 letras (semana 24): 77%<br>Ganho ≥ 10 letras (semana 52): 57%<br>ETDRS letras 24 meses: +8,6; p = 0,0054 em relação ao<br>laser|Após 48 semanas: 11,7<br>(2,49)|NR|24 semanas: -144,6; p = 0,0002 em relação ao<br>laser|
||2q4|Ganho ≥ 10 letras (semana 24): 64%<br>Ganho ≥ 15 letras (semana 24): 32%<br>Ganho ≥ 0 letras (semana 24): 89%<br>Ganho ≥ 10 letras (semana 52): 71%|Após 48 semanas: 10,8<br>(2,87)|NR|24 semanas: -194,5; p<0,0001 em relação ao<br>laser|
|**Do et al. 2012;**<br>||ETDRS letras 24 meses: +11,4; p<0,0001 em relação ao<br>laser||||
|**Do et al.**<br>**2011***<sup>**128,129**</sup>|2q8|Ganho ≥ 10 letras (semana 24): 43%<br>Ganho ≥ 15 letras (semana 24): 17%<br>Ganho ≥ 0 letras (semana 24): 93%<br>Ganho ≥ 10 letras (semana 52): 45%|Após 48 semanas: 7,2 (1,74)|NR|24 semanas: -127,3; p = 0,0066 em relação ao<br>laser|
|||ETDRS letras 24 meses: +8,5; p = 0,0085 em relação ao<br>laser||||
||2PRN|Ganho ≥ 10 letras (semana 24): 58%<br>Ganho ≥ 15 letras (semana 24): 27%<br>Ganho ≥ 0 letras (semana 24): 93%<br>Ganho ≥ 10 letras (semana 52): 91%|Após 48 semanas: 7,4 (3,19)|NR|24 semanas: -153,3; p<0,001 em relação ao<br>laser|
|||ETDRS letras 24 meses: +10,3; p = 0,0004 em relação<br>ao laser.||||  
192  
|**Autor, ano**|**Grupo**|**Acuidade visual**|**Nº médio de injeções (DP)**|**Sensibilidade da retina**|**Espessura central macular (µm), média**<br>**(DP)**|
|---|---|---|---|---|---|
|||**Faixa de melhora BCVA:**||||
||AIV agregado|24 semanas: +8,5 a +11,4 letras; (p=0,0085 para todos os<br>grupos AIV vs. laser)<br>52 semanas: +9,7 a +13,1 letras. (p<0,001 para todos os<br>grupos AIV vs. laser);|NR|NR|Redução em 24 semanas:  variando de 127,3 a<br>194,5 µm (todos os regimes de AIV),<br>p=0,0066 em relação ao laser|
|||Ganho ≥ 10 letras (semana 24): 64%<br>Ganho ≥ 15 letras (semana 24): 34%<br>Ganho ≥ 0 letras (semana 24): 93%|||Redução em 52 semanas: p<0,0001 para todos<br>os regimes de AIV vs. laser.|
|||Ganho ≥ 15 letras (semana 52): p<0,001 para todos os<br>grupos AIV vs. laser, exceto 2q8.||||
||Laser|Ganho ≥ 10 letras (semana 24): 21%<br>Ganho ≥ 15 letras (semana 24): 32%<br>Ganho ≥ 0 letras (semana 24): 68%<br>Ganho ≥ 10 letras (semana 52): 30%<br>ETDRS letras 24 meses: +2,5|NA|NR|Redução de 67,9 µm em 24 semanas|  
*O estudo cita que não utilizou poder estatístico para detectar diferenças entre os diversos regimes de tratamento, por isso diferenças estatísticas entre os regimes de aflibercepte não foram mostrados; **o estudo realizou análise de não-inferioridade considerando os pacientes entre os períodos mês 1 a mês 12, sem detalhar o quantitativo de participantes a cada mês e quantos foram imputados, o que pode ter superestimado o valor de acuidade visual a favor do regime tratar e estender (análise de superioridade foi a favor do regime PRN), devido a isso somente foram relatados valores de diferença entre basal, 12 e 24 meses; ¥Não inferioridade assumida quando a diferença entre esquemas tratar e estender vs. PRN for <4; AIV: Aflibercepte intravítreo; RIV: ranibizumabe intravítreo; MAVC: Melhor acuidade visual corrigida; BCVA: acuidade visual melhor corrigida; DP: Desvio Padrão; EF: Efeito fixo; EA: Efeito aleatório; OR: oddsratio; RR: Risco relativo; NR: Não relatado. Obs: para melhor entendimento da codificação dos esquemas terapêuticos veja Tabela 1; O estudo de Yanagida e Ueta, 2014, não apresenta resultados de eficácia de acordo com os Seleção das evidências (desfechos de segurança na Tabela 4).  
193  
**Tabela 94 –** Eventos adversos mais frequentes relatados pelas revisões sistemáticas inclusas  
|**Evento Adverso**|**Korobelnik et al. 2015**<sup>**215**</sup>||**Autor, a**|**no**<br>**Yanagida**|**e Ueta, 2014**<sup>**134**</sup>**(Rate**|**ratio (IC95%))**|
|---|---|---|---|---|---|---|
||**AIV (fixo) vs RIV (PRN) método MTC [interv**||||||
||**.     .**<br>**Credibilidade]**|**Valor p**|**READ-2**|**RESTORE**|**RISE e RIDE**|**Total**|
|||**Eventos adve**|**rsos gerais**||||
|**Todos eventos adversos, n (%)**|EF: RR = 0,79 [0,55–1,10]; OR = 0,61 [0,29–1,26];<br>EA: RR = 0,88 [0,64–1,15]; OR = 0,58 [0,18–1,82].|NS|NR|NR|NR|NR|
|**Eventos adversos graves**|EF: RR = 0,76 [0,47–1,26]; OR = 0,71 [0,39–1,32];<br>EA: RR = 0,82 [0,47–1,42]; OR = 0,74 [0,31–1,72].|NS|NR|NR|NR|NR|
|**Eventos adversos oculares**<br>**graves**|EF: RR = 0,28 [0,06–1,24]; OR = 0,27 [0,05–1,25];<br>EA: RR = 0,30 [0,05–2,49]; OR = 0,28 [0,05–2,58].|NS|NR|NR|NR|NR|
|**Eventos adversos não oculares**<br>**graves**|EF: RR = 0,60 [0,32–1,14]; OR = 0,53 [0,24–1,17];<br>EA: RR = 0,67 [0,29–1,66]; OR = 0,53 [0,12–2,11].|NS|NR|NR|NR|NR|
|**Todos eventos oculares**|EF: RR = 0,75 [0,54–1,05]; OR = 0,60 [0,32–1,09];<br>EA: RR = 0,85 [0,58–1,25]; OR = 0,58 [0,16–1,87].|NS|NR|NR|NR|NR|
|**Todos eventos não oculares**|EF: RR = 1,09 [0,87–1.40]; OR = 1,27 [0,65–2,42];<br>EA: RR = 1,03 [0,80–1,56]; OR = 1,22 [0,23–6,18]|NS|NR|NR|NR|NR|
|||**Eventos adver**|**sos oculares**||||
|**Dor ocular, n (%)**|EF: RR = 0,98 [0,38–2,70]; OR = 0,97 [0,34–2,94];<br>EA: RR = 0,96 [0,23–3,91]; OR = 0,95 [0,17–4,75];|NS|NR|NR|NR|NR|
|**Catarata, n (%)**|EF: RR = 3,93 [0,77–32,74]; OR = 4,09 [0,76–34,86];<br>EA: RR = 3,83 [0,52–43,72]; OR = 4,16 [0,49–50,98].|NS|NR|NR|NR|NR|
||<br>|**Eventos advers**|**os sistêmicos**||||
|**HAS**|EF: RR = 0,95 [0,44–2,07]; OR = 0,95 [0,40–2,22];<br>EA: RR = 0,95[0,37–2,55];OR = 0,94[0,28–3,14].|NS|NR|NR|NR|NR|
|**Todas as causas de morte, n (%)**|EF: RR = 2,90 [0,20–50,4]; OR = 3,06 [0,18–60,01];<br>EA: RR = 2,76 [0,13–79,02]; OR = 2,83 [0,11–85,27].|NS|1,59 (0,05–<br>48,89); p=0,792|0,98 (0,60–<br>1,59); p=0,939|1,11 (1,00–1,23);<br>p=0,04|1,082 (0,997–1,175); p=0,133 (o modelo<br>final com ajuste pelos dois estudos que<br>consideraram esquema PRN, não mostrou<br>relação significativa com o risco de<br>morte)|  
NR: Não relatado; NS: Não significante; EF: efeito fixo; EA: Efeito aleatório; OR: Oddsratio; RR: Risco relativo; AIV: aflibercepte intravítreo; RIV: Ranibizumabe intravítreo; PRN (Pro re nata).  
194  
**Tabela 95  –** Eventos adversos mais frequentes relatados pelos ensaios clínicos randomizados inclusos  
||**Gonza**|**lez et al. 201**<br>**20**|**5**<sup>**;**</sup>**Do et al**<br>**11***<sup>**128,129,240**</sup>|**. 2012; Do**|**et al.**|**L**|**ang et al. 2013**|**Autor, an**<br><sup>**149**</sup>|**o**<br>**Pay**|**ne et al. 201**|**7**<sup>**238**</sup>||**Prunte et al. 2**|**015**<sup>**239**</sup>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento Adverso**||||||**Prévio**|**Prévio**||||||||
||**Laser**|**0,5q4**|**2q4**|**2q8**|**2PRN**|**RIV 0,5**<br>**mg**|**RIV 0,5**<br>**mg + laser**|**Prévio**<br>**laser**|**Mensal**|**TREX**|**GILA**|**RIV TE**<br>**LA**|**RIV TE**|**RIV PRN**|
|||||||**E**|**ventos adverso**|**s gerais**|||||||
|**Todos eventos adversos,**<br>**n (%)**|7 (63)<sup>1</sup>|9 (90)<sup>1</sup>|NR|NR|6 (60)<sup>1</sup>|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Eventos adversos graves**|1 (9)<sup>1</sup>|1 (10)<sup>1</sup>|1 (63)<sup>1</sup>|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Todos eventos oculares**|NR|NR|NR|NR|NR|45 (54.2)|47 (56.6)|39 (52.7)|NR|NR|NR|58 (46.0)|63 (50.0)|46 (39.0)|
|**Todos eventos não**<br>**oculares**|NR|NR|NR|NR|NR|58 (69.9)|61 (73.5)|59 (79.7)|NR|NR|NR|97 (77.0)|99 (78.6)|83 (70.3)|
|||||||**Ev**|**entos adversos**|**oculares**|||||||
|**Dor ocular, n (%)**|NR|NR|NR|NR|NR|14 (16.9)|9 (10.8)|12 (16.2)|NR|NR|NR|8 (6.3)|7 (5.6)|3 (2.5)|
|**Hemorragia conjuntiva,**<br>**n (%)**|NR|NR|NR|NR|NR|8 (9.6)|9 (10.8)|0 (0.0)|NR|NR|NR|5 (4.0)|11 (8.7)|6 (5.1)|
|**Olho seco, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|6 (4.8)|3 (2.4)|4 (3.4)|
|**Hemorragia retina,**<br>**n(%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|2 (1.6)|3 (2.4)|0|
|**Hemorragia vítrea, n**<br>**(%)**|NR|NR|NR|NR|NR|NR|NR|NR|0|4 (7)|1 (2)|8 (6.3)|2 (1.6)|0|
|**Hiperemia conjuntiva, n**<br>**(%)**|NR|NR|NR|NR|NR|8 (9.6)|6 (7.2)|6 (8.1)|NR|NR|NR|NR|NR|NR|
|**Conjuntivite, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|6 (4.8)|2 (1.6)|0 (0.0)|
|**Ceratite, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|1 (0.8)|3 (2.4)|0|
|**Catarata, n (%)**|NR|NR|NR|NR|NR|5 (6.0)|10 (12.0)|11 (14.9)|1 (3)|3 (5)|4 (7)|5 (4.0)|7 (5.6)|7 (5.9)|
|**Elevação pressão ocular,**<br>**n(%)**|NR|NR|NR|NR|NR|NR|NR|NR|2 (7)|1 (2)|3 (5)|2 (1.6)|7 (5.6)|5 (4.2)|
|**Hipertensão ocular, n**<br>**(%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|7 (5.6)|2 (1.6)|3 (2.5)|  
195  
|||||||||**Autor, an**|**o**||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**Gonza**|**lez et al. 20**<br>**20**|**15**<sup>**;**</sup>**Do et al.**<br>**11***<sup>**128,129,240**</sup>|**2012; Do**|**et al.**|**L**|**ang et al. 2013**|<sup>**149**</sup>|**Pay**|**ne et al. 201**|**7**<sup>**238**</sup>||**Prunte et al. 2**|**015**<sup>**239**</sup>|
|**Evento Adverso**||||||**Péi**|**Péi**||||||||
||**Laser**|**0,5q4**|**2q4**|**2q8**|**2PRN**|**rvo**<br>**RIV 0,5**<br>**mg**|**rvo**<br>**RIV 0,5**<br>**mg + laser**|**Prévio**<br>**laser**|**Mensal**|**TREX**|**GILA**|**RIV TE**<br>**LA**|**RIV TE**|**RIV PRN**|
|**Glaucoma, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|3 (2.4)|1 (0.8)|1 (0.8)|
|**Membrana epiretinal, n**<br>**(%)**|NR|NR|NR|NR|NR|NR|NR|NR|2 (7)|2 (3)|1 (2)|NR|NR|NR|
|**Edema retinal diabético,**<br>**n(%)**|NR|NR|NR|NR|NR|5 (6.0)|3 (3.6)|3 (4.1)|NR|NR|NR|4 (3.2)|2 (1.6)|1 (0.8)|
|**Edema macular, n %)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|2 (1.6)|3 (2.4)|2 (1.7)|
|**Sensação de corpo**<br>**estranho no olho, n (%)**|NR|NR|NR|NR|NR|5 (6.0)|7 (8.4)|2 (2.7)|3 (10)|10 (17)|10 (17)|0|1 (0.8)|4 (3.4)|
|**Descolamento posterior**<br>**do vítreo, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|7 (23)|5 (8)|4 (7)|NR|NR|NR|
|**Perda de visão, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|0|5 (8)|1 (2)|NR|NR|NR|
|**Secreção ocular, n (%)**|NR|NR|NR|NR|NR|2 (2.4)|5 (6.0)|2 (2.7)|NR|NR|NR|NR|NR|NR|
|**Prurido/irritação**<br>**ocular, n(%)**|NR|NR|NR|NR|NR|2 (2.4)|3 (3.6)|5 (6.8)|NR|NR|NR|2 (1.6)|4 (3.2)|2 (1.7)|
|**Fibrose macular, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|3 (2.4)|0|0|
|**Lacrimação exacerbada,**<br>**n(%)**|NR|NR|NR|NR|NR|2 (2.4)|4 (4.8)|4 (5.4)|NR|NR|NR|1 (0.8)|4 (3.2)|0|
|||||||**Ev**|**entos adversos**|**sistêmicos**|||||||
|**Nasofaringite, n (%)**|NR|NR|NR|NR|NR|13 (15.7)|13 (15.7)|19 (25.7)|NR|NR|NR|11 (8.7)|10 (7.9)|8 (6.8)|
|**Cistite, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|2 (1.6)|2 (1.6)|6 (5.1)|
|**Bronquite, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|11 (8.7)|1 (0.8)|5 (4.2)|
|**Anemia, n (%)**|0|1 (2,3)|2 (4,5)|0|0|NR|NR|NR|1 (3)|2 (3)|4 (7)|4 (3.2)|5 (4.0)|5 (4.2)|
|**Sangue na urina, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|2 (1.6)|3 (2.4)|5 (4.2)|
|**Diarreia, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|4 (3.2)|4 (3.2)|7 (5.9)|  
196  
|||||||||**Autor, an**|**o**||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**Gonza**|**lez et al. 20**<br>**20**|**15**<sup>**;**</sup>**Do et al**<br>**11***<sup>**128,129,240**</sup>|**. 2012; Do**<br>|**et al.**|**L**|**ang et al. 2013**<sup>**1**</sup>|<sup>**49**</sup>|**Pay**|**ne et al. 201**|**7**<sup>**238**</sup>||**Prunte et al. 2**|**015**<sup>**239**</sup>|
|**Evento Adverso**||||||**Péi**|**Péi**||||||||
||**Laser**|**0,5q4**|**2q4**|**2q8**|**2PRN**|**rvo**<br>**RIV 0,5**<br>**mg**|**rvo**<br>**RIV 0,5**<br>**mg + laser**|**Prévio**<br>**laser**|**Mensal**|**TREX**|**GILA**|**RIV TE**<br>**LA**|**RIV TE**|**RIV PRN**|
|**Alergia, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|3 (10)|7 (12)|3 (5)|NR|NR|NR|
|**Gastroenterite, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|2 (7)|0|2 (3)|NR|NR|NR|
|**Infec. de tecido**<br>**mole/pele, n(%)**|NR|NR|NR|NR|NR|NR|NR|NR|1 (3)|10 (17)|9 (15)|NR|NR|NR|
|**Infec. Respiratória, n**<br>**(%)**|NR|NR|NR|NR|NR|NR|NR|NR|10 (33)|18 (30)|12 (20)|NR|NR|NR|
|**Infec. Trato urinário**<br>**inferior, n(%)**|NR|NR|NR|NR|NR|NR|NR|NR|2 (7)|3 (5)|3 (5)|9 (7.1)|11 (8.7)|5 (4.2)|
|**Desidratação, n (%)**|0|0|0|2 (4,8)|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Hiper/hipoglicemia, n**<br>**(%)**|0|0|2 (4,5)|0|0|NR|NR|NR|6 (20)|8 (13)|9 (15)|NR|NR|NR|
|**Hiperlipidemia, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|3 (10)|4 (2)|1 (7)|NR|NR|NR|
|**Mal-estar, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|3 (10)|1 (2)|0|NR|NR|NR|
|**Deficiência de**<br>**testosterona, n(%)**|NR|NR|NR|NR|NR|NR|NR|NR|2 (7)|1 (2)|0|NR|NR|NR|
|**IM, n (%)**|0|3 (6,8)|0|0|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**HAS**|0|0|2 (4,5)|1 (2,4)|0|10 (12.0)|9 (10.8)|6 (8.1)|5 (17)<br>piora|16 (27)<br>piora|18 (30)<br>piora|20 (15.9)|18 (14.3)|8 (6.8)|
|**Todas as causas de**<br>**morte, n(%)**|1 (2,3)|1 (2,3)|3 (6,8)|2 (4,5)|0|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Falha cardíaca**<br>**congestiva, n (%)**|0|0|3 (6,8)|1 (2,4)|2 (4,4)|NR|NR|NR|1 (3)|6 (10)|7 (12)|NR|NR|NR|
|**Celulite, n (%)**|0|3 (6,8)|2 (4,5)|0|1 (2,2)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Dor torácica, n (%)**|0|0|2 (4,5)|0|3 (6,7)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|**Tonteira, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|4 (13)|1 (2)|1 (2)|NR|NR|NR|
|**AVC, n (%)**|1 (2,3)|1 (2,3)|2 (4,5)|0|0|NR|NR|NR|0|0|3 (5)|NR|NR|NR|
|**Artralgia, n(%)**|NR|NR|NR|NR|NR|6 (7.2)|0 (0.0)|3 (4.1)|NR|NR|NR|NR|NR|NR|
|**Influenza, n (%)**|NR|NR|NR|NR|NR|6 (7.2)|5 (6.0)|10 (13.5)|NR|NR|NR|9 (7.1)|10 (7.9)|8 (6.8)|  
197  
|||||||||**Autor, an**|**o**||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**Gonzal**|**ez et al. 201**<br>**201**|**5**<sup>**;**</sup>**Do et al.**<br>**1***<sup>**128,129,240**</sup>|**2012; Do**|**et al.**|**L**|**ang et al. 2013**<sup>**1**</sup>|<sup>**49**</sup>|**Pay**|**ne et al. 201**|**7**<sup>**238**</sup>||**Prunte et al. 2**|**015**<sup>**239**</sup>|
|**Evento Adverso**|**Laser**|**0,5q4**|**2q4**|**2q8**|**2PRN**|**Prévio**<br>**RIV 0,5**<br>**mg**|**Prévio**<br>**RIV 0,5**<br>**mg + laser**|**Prévio**<br>**laser**|**Mensal**|**TREX**|**GILA**|**RIV TE**<br>**LA**|**RIV TE**|**RIV PRN**|
|**Fratura, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|0|0|4 (7)|NR|NR|NR|
|**Paralisia nervo cranial,**<br>**n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|0|1 (2)|3 (5)|NR|NR|NR|
|**Dor lombar, n (%)**|NR|NR|NR|NR|NR|5 (6.0)|4 (4.8)|7 (9.5)|8 (27)|7 (12)|12 (20)|8 (6.3)|10 (7.9)|3 (2.5)|
|**Queda, n(%)**|NR|NR|NR|NR|NR|5(6.0)|2(2.4)|3(4.1)|NR|NR|NR|NR|NR|NR|
|**Edema periférico, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|7 (5.6)|5 (4.0)|3 (2.5)|
|**Dor nas extremidades, n**<br>**(%)**|NR|NR|NR|NR|NR|5 (6.0)|0 (0.0)|0 (0.0)|NR|NR|NR|NR|NR|NR|
|**Insuf. Renal, n (%)**|NR|NR|NR|NR|NR|NR|NR|NR|1 (3)|0|6 (10)|NR|NR|NR|
|**Cefaleia, n (%)**|NR|NR|NR|NR|NR|3 (3.6)|4 (4.8)|4 (5.4)|7 (23)|10 (17)|9 (15)|NR|NR|NR|
|**Tosse, n (%)**|NR|NR|NR|NR|NR|2 (2.4)|2 (2.4)|4 (5.4)|NR|NR|NR|NR|NR|NR|  
* Para os estudos de Do et al. 2012 e Do et al. 2011, apenas foram apresentados os resultados de segurança do seguimento mais longo (52 semanas); Inf.: Infecções; Insf.: insuficiência; NR: não relatado.  
198

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **4. RECOMENDAÇÕES** -->
A proposta de elaboração do PCDT da Retinopatia Diabética foi apresentada aos membros do Plenário da Conitec em sua 86ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Developmentand Evaluations_ )<sup>159</sup> , de forma qualitativa, durante a reunião de consenso das recomendações. Os metodologistas mediaram as discussões apresentando cada um dos critérios GRADE.  
A seguir são apresentadas as principais recomendações contidas no documento.  
|**Número**<br>**1**|**Recomendação**<br>Recomenda-se, em pacientes portadores de DM1 e DM2, o controle da hemoglobina glicada (HbA1c)<br>à níveis <7% por ser capaz de reduzir o risco de progressão e incidência da RD e edema macular<br>diabético (EMD). É recomendada a manutenção da pressão sistólica abaixo de 130mmHg, bem como a<br>manutenção dos níveis de proteinúria <30 mg/dL/24h, para a redução de progressão e incidência de RD<br>e EMD<sup>13-15,20,21</sup>.<br>A manutenção de um perfil lipídico dentro dos valores recomendados aos portadores de DM também é<br>recomendada com o objetivo de se reduzir o risco de desenvolvimento ou progressão do EMD.|
|---|---|
|**2**|Os métodos apresentam boa acurácia diagnóstica.<br>É recomendado o uso dos métodos oftalmoscopia binocular indireta e biomicroscopia de fundo, com a<br>possibilidade de se associara fotografia estereoscópica (retinografia).|
|**3**|Recomenda-se a angiofluoresceinografia, em periodicidade não menor que seis meses ou a critério<br>médico a depender da gravidade, em caráter complementar para o diagnóstico de EMD e para auxiliar<br>no tratamento com fotocoagulação a laser.|
|**4**|Recomenda-se o uso do exame de OCT para o diagnóstico de EMD e sempre que a avaliação clínica<br>oftalmológica for insuficiente para se definir o tratamento ou retratamento ou quando o oftalmologista<br>julgar necessário para melhor compreensão do caso.|
|**5**|**DM sem retinopatia ou com RD até grau moderado sem Edema:**<br>Recomenda-se adequação do controle glicêmico com manutenção da HbA1c < 7%, o acompanhamento<br>a cada 12 meses ou de acordo com critérios clínicos.<br>**Retinopatia diabética não proliferativa (RDNP) grave e muito grave sem edema macular e a**<br>**retinopatia diabética proliferativa (RDP) sem características de alto risco sem EMD:**<br>Recomenda-se a panfotocoagulação de acordo com protocolos institucionais e considerando a gravidade<br>caso a caso.<br>Não se recomenda o tratamento medicamentoso com anti-VEGF e nem corticosteroides intravítreo.<br>**Retinopatia diabética proliferativa (RDP) de alto risco sem edema macular:**<br>Recomenda-se a panfotocoagulação de acordo com protocolos institucionais e considerando a gravidade<br>caso a caso.<br>Não se recomenda o tratamento medicamentoso com anti-VEGF e nem corticosteroides intravítreo.<br>Recomenda-se vitrectomia em situações especiais descritas a seguir: 1) em casos de hemorragia vítrea<br>que não clareie espontaneamente ou que impeça a realização da PFC completa; 2) em casos de|  
199  
|**Número**|**Recomendação**|
|---|---|
||descolamento tracional de retina com comprometimento da mácula ou que esteja ameaçando acometer<br>a mácula; 3) em casos de descolamento de retina misto (tracional e regmatogênico); 4) em casos de<br>hemorragia vítrea associada a_rubeosis iridis._|
||**Edema macular diabético que não envolve o centro da fóvea:**<br>Recomenda-se a panfotocoagulação de acordo com protocolos institucionais e considerando a gravidade<br>caso a caso.<br>Não se recomenda o tratamento medicamentoso com anti-VEGF e nem corticosteroides intravítreo.<br>**Edema macular diabético que envolve o centro da fóvea:**<br>Recomenda-se a panfotocoagulação de acordo com protocolos institucionais e considerando a gravidade<br>caso a caso.<br>Recomenda-se o uso do aflibercepte ou ranibizumabe associado ou não a panfotocoagulação (avaliar<br>caso a caso a necessidade de associação) como primeira opção de tratamento para pacientes com EMD.<br>Não se recomenda o tratamento medicamentoso com corticosteroides intravítreo.<br>Recomenda-se vitrectomia via pars plana como uma opção a ser utilizada após a falha do tratamento<br>farmacológico com Anti-VEGF, exceto em caso de contraindicação.|  
200

---

<!-- METADADOS: doenca: Retinopatia Diabética | secao: **REFERÊNCIAS (APÊNDICE METODOLÓGICO)** -->
1. Cavallerano JD, Schlossman DK, Hamam RN, et al. 17 Ophthalmic Complications in Older Adults with Diabetes. _Geriatric Diabetes_ . 2007:221. 2. BRM L, MC S. _Diabetic Retinopath. In: Lumbroso B. RM, Savastano M.C., editor. Diabetic Retinopathy. India: Jaypee Brothers medical Publishers; 2015_ 2015. 3. Organization WH. Global prevalence of diabetes mellitus and its complications. _Prevention of blindness from diabetes mellitus: report of a WHO consultation Geneva: WHO_ . 2006:7-8.  
4. Control D, Group CTR. The relationship of glycemic exposure (HbA1c) to the risk of development and progression of retinopathy in the diabetes control and complications trial. _Diabetes_ . 1995;44(8):968-983. 5. Alva M, Gray A, Mihaylova B, et al. The impact of diabetes‐related complications on healthcare costs: new results from the UKPDS (UKPDS 84). _Diabetic Medicine_ . 2015;32(4):459-466. 6. Control D, Interventions CTEoD, Group CR. Retinopathy and nephropathy in patients with type 1 diabetes four years after a trial of intensive therapy. _New England Journal of Medicine_ . 2000;342(6):381-389.  
7. Matthews DR, Stratton IM, Aldington SJ, et al. Risks of progression of retinopathy and vision loss related to tight blood pressure control in type 2 diabetes mellitus: UKPDS 69. _Archives of ophthalmology (Chicago, Ill: 1960)_ . 2004;122(11):1631. 8. Aiello LP, Group DER. Diabetic retinopathy and other ocular findings in the diabetes control and complications trial/epidemiology of diabetes interventions and complications study. _Diabetes Care_ . 2014;37(1):17-23. 9. Genuth S, Sun W, Cleary P, et al. Glycation and carboxymethyllysine levels in skin collagen predict the risk of future 10year progression of diabetic retinopathy and nephropathy in the diabetes control and complications trial and epidemiology of diabetes interventions and complications participants with type 1 diabetes. _Diabetes_ . 2005;54(11):3103-3111. 10. Hletala K, Harjutsalo V, Forsblom C, et al. Age at onset and the risk of proliferative retinopathy in type 1 diabetes. _Diabetes care_ . 2010;33(6):1315-1319. 11. Jin P, Peng J, Zou H, et al. The 5-year onset and regression of diabetic retinopathy in Chinese type 2 diabetes patients. _PLoS One_ . 2014;9(11):e113359.  
12. Jin P, Peng J, Zou H, et al. A five-year prospective study of diabetic retinopathy progression in chinese type 2 diabetes patients with "well-controlled" blood glucose. _PLoS One_ . 2015;10(4):e0123449.  
13. Klein R, Klein BE, Moss SE, et al. The Wisconsin Epidemiologic Study of Diabetic Retinopathy: XVII. The 14-year incidence and progression of diabetic retinopathy and associated risk factors in type 1 diabetes. _Ophthalmology_ . 1998;105(10):18011815.  
14. Klein R, Knudtson MD, Lee KE, et al. The Wisconsin Epidemiologic Study of Diabetic Retinopathy: XXII the twentyfive-year progression of retinopathy in persons with type 1 diabetes. _Ophthalmology_ . 2008;115(11):1859-1868. 15. Klein R, Knudtson MD, Lee KE, et al. The Wisconsin Epidemiologic Study of Diabetic Retinopathy XXIII: the twentyfive-year incidence of macular edema in persons with type 1 diabetes. _Ophthalmology_ . 2009;116(3):497-503. 16. Liu Y, Wang M, Morris AD, et al. Glycemic exposure and blood pressure influencing progression and remission of diabetic retinopathy: a longitudinal cohort study in GoDARTS. _Diabetes Care_ . 2013;36(12):3979-3984. 17. Pan J, Li Q, Zhang L, et al. Serum glycated albumin predicts the progression of diabetic retinopathy--a five year retrospective longitudinal study. _J Diabetes Complications_ . 2014;28(6):772-778. 18. Stratton IM, Kohner EM, Aldington SJ, et al. UKPDS 50: risk factors for incidence and progression of retinopathy in Type II diabetes over 6 years from diagnosis. _Diabetologia_ . 2001;44(2):156-163. 19. Gillies MC, Lim LL, Campain A, et al. A randomized clinical trial of intravitreal bevacizumab versus intravitreal dexamethasone for diabetic macular edema: the BEVORDEX study. _Ophthalmology_ . 2014;121(12):2473-2481. 20. Rani PK, Raman R, Gupta A, et al. Albuminuria and Diabetic Retinopathy in Type 2 Diabetes Mellitus Sankara Nethralaya Diabetic Retinopathy Epidemiology And Molecular Genetic Study (SN-DREAMS, report 12). _Diabetol Metab Syndr_ . 2011;3(1):9. 21. Trevisan R, Vedovato M, Mazzon C, et al. Concomitance of diabetic retinopathy and proteinuria accelerates the rate of decline of kidney function in type 2 diabetic patients. _Diabetes Care_ . 2002;25(11):2026-2031. 22. Benarous R, Sasongko MB, Qureshi S, et al. Differential association of serum lipids with diabetic retinopathy and diabetic macular edema. _Invest Ophthalmol Vis Sci_ . 2011;52(10):7464-7469. 23. Miljanovic B, Glynn RJ, Nathan DM, et al. A prospective study of serum lipids and risk of diabetic macular edema in type 1 diabetes. _Diabetes_ . 2004;53(11):2883-2892. 24. Wong T, Aiello L, Ferris F, et al. Updated 2017 ICO guidelines for diabetic eye care. _Int Counc Ophthalmol_ . 2017:1-33. 25. Ahmed J, Ward TP, Bursell SE, et al. The sensitivity and specificity of nonmydriatic digital stereoscopic retinal imaging in detecting diabetic retinopathy. _Diabetes Care_ . 2006;29(10):2205-2209.  
26. Ahsan S, Basit A, Ahmed KR, et al. Diagnostic accuracy of direct ophthalmoscopy for detection of diabetic retinopathy using fundus photographs as a reference standard. _Diabetes & Metabolic Syndrome: Clinical Research & Reviews_ . 2014;8(2):96-101. 27. Aptel F, Denis P, Rouberol F, et al. Screening of diabetic retinopathy: effect of field number and mydriasis on sensitivity and specificity of digital fundus photography. _Diabetes Metab_ . 2008;34(3):290-293.  
28. Boucher MC, Gresset JA, Angioi K, et al. Effectiveness and safety of screening for diabetic retinopathy with two nonmydriatic digital images compared with the seven standard stereoscopic photographic fields. _Can J Ophthalmol_ . 2003;38(7):557568.  
29. Bursell SE, Cavallerano JD, Cavallerano AA, et al. Stereo nonmydriatic digital-video color retinal imaging compared with Early Treatment Diabetic Retinopathy Study seven standard field 35-mm stereo color photos for determining level of diabetic retinopathy. _Ophthalmology_ . 2001;108(3):572-585.  
30. Chia DS, Yap EY. Comparison of the effectiveness of detecting diabetic eye disease: diabetic retinal photography versus ophthalmic consultation. _Singapore Med J_ . 2004;45(6):276-279.  
31. Chun DW, Bauer RM, Ward TP, et al. Evaluation of digital fundus images as a diagnostic method for surveillance of diabetic retinopathy. _Military medicine_ . 2007;172(4):405-410.  
32. Emanuele N, Klein R, Moritz T, et al. Comparison of dilated fundus examinations with seven-field stereo fundus photographs in the Veterans Affairs Diabetes Trial. _J Diabetes Complications_ . 2009;23(5):323-329.  
33. Gresset J, Boucher M, Angioi-Duprez K, et al. Comparison of Two, Three and Four 45-degree Image Fields with the Topcon CRW6 Non-mydriatic Camera for the Screening of Diabetic Retinopathy. _Investigative Ophthalmology & Visual Science_ . 2003;44(13):3954-3954.  
34. Harding SP, Broadbent DM, Neoh C, et al. Sensitivity and specificity of photography and direct ophthalmoscopy in screening for sight threatening eye disease: the Liverpool Diabetic Eye Study. _BMJ_ . 1995;311(7013):1131-1135. 35. Herbert H, Jordan K, Flanagan D. Is screening with digital imaging using one retinal view adequate? _Eye_ . 2003;17(4):497500.  
201  
36. Kalm H, Egertsen R, Blohme G. Non‐stereo fundus photography as a screening procedure for diabetic retinopathy among patients with type II diabetes: Compared with 60D enhanced slit‐lamp examination. _Acta ophthalmologica_ . 1989;67(5):546-553. 37. Kerr D, Cavan DA, Jennings B, et al. Beyond retinal screening: digital imaging in the assessment and follow-up of patients with diabetic retinopathy. _Diabet Med_ . 1998;15(10):878-882.  
38. Kinyoun JL, Martin DC, Fujimoto WY, et al. Ophthalmoscopy versus fundus photographs for detecting and grading diabetic retinopathy. _Invest Ophthalmol Vis Sci_ . 1992;33(6):1888-1893. 39. Klein R, Klein BE, Neider MW, et al. Diabetic retinopathy as detected using ophthalmoscopy, a nonmyciriatic camera and a standard fundus camera. _Ophthalmology_ . 1985;92(4):485-491. 40. Kleinstein RN, Roseman JM, Herman WH, et al. Detection of diabetic retinopathy by optometrists. _J Am Optom Assoc_ . 1987;58(11):879-882. 41. Kuo H-K, Hsieh H-H, Liu R-T. Screening for diabetic retinopathy by one-field, non-mydriatic, 45 digital photography is inadequate. _Ophthalmologica_ . 2005;219(5):292-296. 42. Lawrence MG. The accuracy of digital-video retinal imaging to screen for diabetic retinopathy: an analysis of two digitalvideo retinal imaging systems using standard stereoscopic seven-field photography and dilated clinical examination as reference standards. _Transactions of the American Ophthalmological Society_ . 2004;102:321. 43. Lin DY, Blumenkranz MS, Brothers RJ, et al. The sensitivity and specificity of single-field nonmydriatic monochromatic digital fundus photography with remote image interpretation for diabetic retinopathy screening: a comparison with ophthalmoscopy and standardized mydriatic color photography. _Am J Ophthalmol_ . 2002;134(2):204-213. 44. Lopez-Bastida J, Cabrera-Lopez F, Serrano-Aguilar P. Sensitivity and specificity of digital retinal imaging for screening diabetic retinopathy. _Diabet Med_ . 2007;24(4):403-407. 45. Maberley D, Cruess AF, Barile G, et al. Digital photographic screening for diabetic retinopathy in the James Bay Cree. _Ophthalmic Epidemiol_ . 2002;9(3):169-178. 46. Massin P, Erginay A, Ben Mehidi A, et al. Evaluation of a new non-mydriatic digital camera for detection of diabetic retinopathy. _Diabet Med_ . 2003;20(8):635-641. 47. Møller F, Hansen M, Sjølie AK. Is one 60° fundus photograph sufficient for screening of proliferative diabetic retinopathy? _Diabetes Care_ . 2001;24(12):2083-2085. 48. Moss SE, Klein R, Kessler SD, et al. Comparison between ophthalmoscopy and fundus photography in determining severity of diabetic retinopathy. _Ophthalmology_ . 1985;92(1):62-67. 49. Murgatroyd H, Ellingford A, Cox A, et al. Effect of mydriasis and different field strategies on digital image screening of diabetic eye disease. _Br J Ophthalmol_ . 2004;88(7):920-924. 50. Neubauer AS, Kernt M, Haritoglou C, et al. Nonmydriatic screening for diabetic retinopathy by ultra-widefield scanning laser ophthalmoscopy (Optomap). _Graefes Arch Clin Exp Ophthalmol_ . 2008;246(2):229-235. 51. Newsom R, Moate B, Casswell T. Screening for diabetic retinopathy using digital colour photography and oral fluorescein angiography. _Eye_ . 2000;14(4):579-582. 52. Olson JA, Strachan FM, Hipwell JH, et al. A comparative evaluation of digital imaging, retinal photography and optometrist examination in screening for diabetic retinopathy. _Diabet Med_ . 2003;20(7):528-534. 53. Owens D, Gibbins R, Lewis P, et al. Screening for diabetic retinopathy by general practitioners: ophthalmoscopy or retinal photography as 35 mm colour transparencies? _Diabetic medicine_ . 1998;15(2):170-175. 54. Penman AD, Saaddine JB, Hegazy M, et al. Screening for diabetic retinopathy: the utility of nonmydriatic retinal photography in Egyptian adults. _Diabet Med_ . 1998;15(9):783-787. 55. Phiri R, Keeffe JE, Harper CA, et al. Comparative study of the polaroid and digital non-mydriatic cameras in the detection of referrable diabetic retinopathy in Australia. _Diabet Med_ . 2006;23(8):867-872. 56. Pugh JA, Jacobson JM, Van Heuven WA, et al. Screening for diabetic retinopathy. The wide-angle retinal camera. _Diabetes Care_ . 1993;16(6):889-895. 57. Ruamviboonsuk P, Wongcumchang N, Surawongsin P, et al. Screening for diabetic retinopathy in rural area using singlefield, digital fundus images. _J Med Assoc Thai_ . 2005;88(2):176-180. 58. Rudnisky CJ, Hinz BJ, Tennant MT, et al. High-resolution stereoscopic digital fundus photography versus contact lens biomicroscopy for the detection of clinically significant macular edema. _Ophthalmology_ . 2002;109(2):267-274. 59. Saari JM, Summanen P, Kivela T, et al. Sensitivity and specificity of digital retinal images in grading diabetic retinopathy. _Acta Ophthalmol Scand_ . 2004;82(2):126-130. 60. Scanlon PH, Malhotra R, Greenwood R, et al. Comparison of two reference standards in validating two field mydriatic digital photography as a method of screening for diabetic retinopathy. _British journal of ophthalmology_ . 2003;87(10):1258-1263. 61. Scanlon PH, Malhotra R, Thomas G, et al. The effectiveness of screening for diabetic retinopathy by digital imaging photography and technician ophthalmoscopy. _Diabet Med_ . 2003;20(6):467-474. 62. Schachat AP, Hyman L, Leske MC, et al. Comparison of diabetic retinopathy detection by clinical examinations and photograph gradings. Barbados (West Indies) Eye Study Group. _Arch Ophthalmol_ . 1993;111(8):1064-1070. 63. Sculpher MJ, Buxton MJ, Ferguson BA, et al. Screening for diabetic retinopathy: a relative cost-effectiveness analysis of alternative modalities and strategies. _Health Econ_ . 1992;1(1):39-51. 64. Siu SC, Ko TC, Wong KW, et al. Effectiveness of non-mydriatic retinal photography and direct ophthalmoscopy in detecting diabetic retinopathy. _Hong Kong Med J_ . 1998;4(4):367-370. 65. de Sonnaville JJ, van der Feltz van der Sloot D, Ernst L, et al. Retinopathy screening in type 2 diabetes: reliability of wide angle fundus photography. _Diabet Med_ . 1996;13(5):482-486. 66. Stellingwerf C, Hardus PL, Hooymans JM. Two-field photography can identify patients with vision-threatening diabetic retinopathy: a screening approach in the primary care setting. _Diabetes care_ . 2001;24(12):2086-2090. 67. Stellingwerf C, Hardus P, Hooymans J. Assessing diabetic retinopathy using two-field digital photography and the influence of JPEG-compression. _Documenta ophthalmologica_ . 2004;108(3):203-209.  
68. Tanterdtham J, Singalavanija A, Namatra C, et al. Nonmydriatic digital retinal images for determining diabetic retinopathy. _J Med Assoc Thai_ . 2007;90(3):508-512. 69. Taylor D, Fisher J, Jacob J, et al. The use of digital cameras in a mobile retinal screening environment. _Diabetic medicine_ . 1999;16(8):680-686.  
70. Williams R, Nussey S, Humphry R, et al. Assessment of non-mydriatic fundus photography in detection of diabetic retinopathy. _Br Med J (Clin Res Ed)_ . 1986;293(6555):1140-1142. 71. Wilson PJ, Ellis JD, MacEwen CJ, et al. Screening for diabetic retinopathy: a comparative trial of photography and scanning laser ophthalmoscopy. _Ophthalmologica_ . 2010;224(4):251-257.  
72. Diabetic retinopathy study. Report Number 6. Design, methods, and baseline results. Report Number 7. A modification of the Airlie House classification of diabetic retinopathy. Prepared by the Diabetic Retinopathy. _Invest Ophthalmol Vis Sci_ . 1981;21(1 Pt 2):1-226. 73. Goldberg MF, Jampol LM. Knowledge of diabetic retinopathy before and 18 years after the Airlie House Symposium on Treatment of Diabetic Retinopathy. _Ophthalmology_ . 1987;94(7):741-746.  
74. Group ETDRSR. Grading diabetic retinopathy from stereoscopic color fundus photographs—an extension of the modified Airlie House classification: ETDRS report number 10. _Ophthalmology_ . 1991;98(5):786-806.  
202  
75. Wilkinson CP, Ferris FL, 3rd, Klein RE, et al. Proposed international clinical diabetic retinopathy and diabetic macular edema disease severity scales. _Ophthalmology_ . 2003;110(9):1677-1682. 76. Group ETDRSR. Early photocoagulation for diabetic retinopathy: ETDRS report number 9. _Ophthalmology_ . 1991;98(5):766-785.  
77. Bresnick GH. Diabetic macular edema: a review. _Ophthalmology_ . 1986;93(7):989-997.  
78. Mitchell P, Bandello F, Schmidt-Erfurth U, et al. The RESTORE study: ranibizumab monotherapy or combined with laser versus laser monotherapy for diabetic macular edema. _Ophthalmology_ . 2011;118(4):615-625.  
79. Nguyen QD, Brown DM, Marcus DM, et al. Ranibizumab for diabetic macular edema: results from 2 phase III randomized trials: RISE and RIDE. _Ophthalmology_ . 2012;119(4):789-801. 80. Korobelnik JF, Do DV, Schmidt-Erfurth U, et al. Intravitreal aflibercept for diabetic macular edema. _Ophthalmology_ . 2014;121(11):2247-2254. 81. Otani T, Kishi S, Maruyama Y. Patterns of diabetic macular edema with optical coherence tomography. _American journal of ophthalmology_ . 1999;127(6):688-693. 82. Kim BY, Smith SD, Kaiser PK. Optical coherence tomographic patterns of diabetic macular edema. _Am J Ophthalmol_ . 2006;142(3):405-412. 83. Panozzo G, Mercanti A. Optical coherence tomography findings in myopic traction maculopathy. _Arch Ophthalmol_ . 2004;122(10):1455-1460. 84. Photocoagulation for diabetic macular edema. Early Treatment Diabetic Retinopathy Study report number 1. Early Treatment Diabetic Retinopathy Study research group. _Arch Ophthalmol_ . 1985;103(12):1796-1806. 85. Kylstra JA, Brown JC, Jaffe GJ, et al. The importance of fluorescein angiography in planning laser treatment of diabetic macular edema. _Ophthalmology_ . 1999;106(11):2068-2073. 86. Razvi F, Kritzinger E, Tsaloumas M, et al. Use of oral fluorescein angiography in the diagnosis of macular oedema within a diabetic retinopathy screening programme. _Diabetic medicine_ . 2001;18(12):1003-1006. 87. Brown DM, Schmidt-Erfurth U, Do DV, et al. Intravitreal Aflibercept for Diabetic Macular Edema: 100-Week Results From the VISTA and VIVID Studies. _Ophthalmology_ . 2015;122(10):2044-2052. 88. Brown DM, Nguyen QD, Marcus DM, et al. Long-term outcomes of ranibizumab therapy for diabetic macular edema: the 36-month results from two phase III trials: RISE and RIDE. _Ophthalmology_ . 2013;120(10):2013-2022. 89. Virgili G, Menchini F, Casazza G, et al. Optical coherence tomography (OCT) for detection of macular oedema in patients with diabetic retinopathy. _Cochrane Database Syst Rev_ . 2015;1:CD008081. 90. Berger A, Sheidow T, Cruess AF, et al. Efficacy/safety of ranibizumab monotherapy or with laser versus laser monotherapy in DME. _Can J Ophthalmol_ . 2015;50(3):209-216. 91. Comyn O, Sivaprasad S, Peto T, et al. A randomized trial to assess functional and structural effects of ranibizumab versus laser in diabetic macular edema (the LUCIDATE study). _Am J Ophthalmol_ . 2014;157(5):960-970. 92. Diabetic Retinopathy Clinical Research N, Elman MJ, Aiello LP, et al. Randomized trial evaluating ranibizumab plus prompt or deferred laser or triamcinolone plus prompt laser for diabetic macular edema. _Ophthalmology_ . 2010;117(6):1064-1077 e1035. 93. Elman MJ, Ayala A, Bressler NM, et al. Intravitreal Ranibizumab for diabetic macular edema with prompt versus deferred laser treatment: 5-year randomized trial results. _Ophthalmology_ . 2015;122(2):375-381. 94. Massin P, Bandello F, Garweg JG, et al. Safety and efficacy of ranibizumab in diabetic macular edema (RESOLVE Study): a 12-month, randomized, controlled, double-masked, multicenter phase II study. _Diabetes Care_ . 2010;33(11):2399-2405. 95. Ahmadieh H, Ramezani A, Shoeibi N, et al. Intravitreal bevacizumab with or without triamcinolone for refractory diabetic macular edema; a placebo-controlled, randomized clinical trial. _Graefe's Archive for Clinical and Experimental Ophthalmology_ . 2008;246(4):483-489. 96. Rajendram R, Fraser-Bell S, Kaines A, et al. A 2-year prospective randomized controlled trial of intravitreal bevacizumab or laser therapy (BOLT) in the management of diabetic macular edema: 24-month data: report 3. _Arch Ophthalmol_ . 2012;130(8):972979. 97. Ghasemi Falavarjani K, Wang K, Khadamy J, et al. Ultra-wide-field imaging in diabetic retinopathy; an overview. _J Curr Ophthalmol_ . 2016;28(2):57-60. 98. Diabetic Retinopathy Clinical Research N, Wells JA, Glassman AR, et al. Aflibercept, bevacizumab, or ranibizumab for diabetic macular edema. _N Engl J Med_ . 2015;372(13):1193-1203. 99. Ferris F. Early photocoagulation in patients with either type I or type II diabetes. _Transactions of the American Ophthalmological Society_ . 1996;94:505. 100. Japanese Society of Ophthalmic Diabetology SotSoDRT, Sato Y, Kojimahara N, et al. Multicenter randomized clinical trial of retinal photocoagulation for preproliferative diabetic retinopathy. _Jpn J Ophthalmol_ . 2012;56(1):52-59. 101. Martinez-Zapata MJ, Marti-Carvajal AJ, Sola I, et al. Anti-vascular endothelial growth factor for proliferative diabetic retinopathy. _Cochrane Database Syst Rev_ . 2014(11):CD008721. 102. Simunovic MP, Maberley DA. ANTI-VASCULAR ENDOTHELIAL GROWTH FACTOR THERAPY FOR PROLIFERATIVE DIABETIC RETINOPATHY: A Systematic Review and Meta-Analysis. _Retina_ . 2015;35(10):1931-1942. 103. Group DR. Diabetes control and complications trial (DCCT): update. _Diabetes Care_ . 1990;13(4):427-433. 104. Group DRSR. Photocoagulation treatment of proliferative diabetic retinopathy: clinical application of Diabetic Retinopathy Study (DRS) findings, DRS Report Number 8. _Ophthalmology_ . 1981;88(7):583-600. 105. Group DRSR. Indications for photocoagulation treatment of diabetic retinopathy: Diabetic Retinopathy Study Report no. 14. _International Ophthalmology Clinics_ . 1987;27(4):239-253. 106. Weng CY, Lim JI, Bhagat P, et al. _Panretinal Photocoagulation_ : EyeWiki. American Academy of Ophthalmology; 2020 [cited 2020]. https://eyewiki.aao.org/Panretinal_Photocoagulation 107. Abu El-Asrar AM. Evolving strategies in the management of diabetic retinopathy. _Middle East Afr J Ophthalmol_ . 2013;20(4):273-282. 108. Evans JR, Michelessi M, Virgili G. Laser photocoagulation for proliferative diabetic retinopathy. _Cochrane Database Syst Rev_ . 2014(11):CD011234. 109. Kozak I, Luttrull JK. Modern retinal laser therapy. _Saudi J Ophthalmol_ . 2015;29(2):137-146. 110. Saxena S, Jalali S, Meredith TA, et al. Management of diabetic retinopathy. _Indian J Ophthalmol_ . 2000;48(4):321-330. 111. Writing Committee for the Diabetic Retinopathy Clinical Research N, Gross JG, Glassman AR, et al. Panretinal Photocoagulation vs Intravitreous Ranibizumab for Proliferative Diabetic Retinopathy: A Randomized Clinical Trial. _JAMA_ . 2015;314(20):2137-2146.  
112. Sivaprasad S, Prevost AT, Vasconcelos JC, et al. Clinical efficacy of intravitreal aflibercept versus panretinal photocoagulation for best corrected visual acuity in patients with proliferative diabetic retinopathy at 52 weeks (CLARITY): a multicentre, single-blinded, randomised, controlled, phase 2b, non-inferiority trial. _The Lancet_ . 2017;389(10085):2193-2203. 113. Desapriya E, Khoshpouri P, Al-Isa A. Panretinal Photocoagulation Versus Ranibizumab for Proliferative Diabetic Retinopathy: Patient-Centered Outcomes From a Randomized Clinical Trial. _Am J Ophthalmol_ . 2017;177:232-233. 114. Filho JA, Messias A, Almeida FP, et al. Panretinal photocoagulation (PRP) versus PRP plus intravitreal ranibizumab for high-risk proliferative diabetic retinopathy. _Acta Ophthalmol_ . 2011;89(7):e567-572.  
203  
115. Messias A, Ramos Filho JA, Messias K, et al. Electroretinographic findings associated with panretinal photocoagulation (PRP) versus PRP plus intravitreal ranibizumab treatment for high-risk proliferative diabetic retinopathy. _Doc Ophthalmol_ . 2012;124(3):225-236.  
116. Cho WB, Moon JW, Kim HC. Intravitreal triamcinolone and bevacizumab as adjunctive treatments to panretinal photocoagulation in diabetic retinopathy. _British Journal of Ophthalmology_ . 2010;94(7):858-863. 117. Shimura M, Yasuda K, Shiono T. Posterior sub-Tenon's capsule injection of triamcinolone acetonide prevents panretinal photocoagulation-induced visual dysfunction in patients with severe diabetic retinopathy and good vision. _Ophthalmology_ . 2006;113(3):381-387. 118. Unoki N, Nishijima K, Kita M, et al. Randomised controlled trial of posterior sub-Tenon triamcinolone as adjunct to panretinal photocoagulation for treatment of diabetic retinopathy. _British journal of ophthalmology_ . 2009;93(6):765-770. 119. Early vitrectomy for severe vitreous hemorrhage in diabetic retinopathy. Two-year results of a randomized trial. Diabetic Retinopathy Vitrectomy Study report 2. The Diabetic Retinopathy Vitrectomy Study Research Group. _Arch Ophthalmol_ . 1985;103(11):1644-1652. 120. Early vitrectomy for severe proliferative diabetic retinopathy in eyes with useful vision. Results of a randomized trial-Diabetic Retinopathy Vitrectomy Study Report 3. The Diabetic Retinopathy Vitrectomy Study Research Group. _Ophthalmology_ . 1988;95(10):1307-1320. 121. Early vitrectomy for severe proliferative diabetic retinopathy in eyes with useful vision. Clinical application of results of a randomized trial--Diabetic Retinopathy Vitrectomy Study Report 4. The Diabetic Retinopathy Vitrectomy Study Research Group. _Ophthalmology_ . 1988;95(10):1321-1334. 122. Early vitrectomy for severe vitreous hemorrhage in diabetic retinopathy. Four-year results of a randomized trial: Diabetic Retinopathy Vitrectomy Study Report 5. _Arch Ophthalmol_ . 1990;108(7):958-964. 123. Writing Committee for the Diabetic Retinopathy Clinical Research N, Fong DS, Strauber SF, et al. Comparison of the modified Early Treatment Diabetic Retinopathy Study and mild macular grid laser photocoagulation strategies for diabetic macular edema. _Arch Ophthalmol_ . 2007;125(4):469-480. 124. Perente I, Alkin Z, Ozkaya A, et al. Focal laser photocoagulation in non-center involved diabetic macular edema. _Med Hypothesis Discov Innov Ophthalmol_ . 2014;3(1):9-16. 125. Scott IU, Danis RP, Bressler SB, et al. Effect of focal/grid photocoagulation on visual acuity and retinal thickening in eyes with non-center-involved diabetic macular edema. _Retina_ . 2009;29(5):613-617. 126. Avery RL, Gordon GM. Systemic Safety of Prolonged Monthly Anti-Vascular Endothelial Growth Factor Therapy for Diabetic Macular Edema: A Systematic Review and Meta-analysis. _JAMA Ophthalmol_ . 2016;134(1):21-29. 127. Chen G, Li W, Tzekov R, et al. Ranibizumab monotherapy or combined with laser versus laser monotherapy for diabetic macular edema: a meta-analysis of randomized controlled trials. _PLoS One_ . 2014;9(12):e115797. 128. Do DV, Nguyen QD, Boyer D, et al. One-year outcomes of the da Vinci Study of VEGF Trap-Eye in eyes with diabetic macular edema. _Ophthalmology_ . 2012;119(8):1658-1665. 129. Do DV, Schmidt-Erfurth U, Gonzalez VH, et al. The DA VINCI Study: phase 2 primary results of VEGF Trap-Eye in patients with diabetic macular edema. _Ophthalmology_ . 2011;118(9):1819-1826. 130. Heier JS, Korobelnik JF, Brown DM, et al. Intravitreal Aflibercept for Diabetic Macular Edema: 148-Week Results from the VISTA and VIVID Studies. _Ophthalmology_ . 2016;123(11):2376-2385. 131. Régnier S, Malcolm W, Allen F, et al. Efficacy of anti-VEGF and laser photocoagulation in the treatment of visual impairment due to diabetic macular edema: a systematic review and network meta-analysis. _PloS one_ . 2014;9(7):e102309. 132. Network DRCR. A phase II randomized clinical trial of intravitreal bevacizumab for diabetic macular edema. _Ophthalmology_ . 2007;114(10):1860-1867. e1867. 133. Virgili G, Parravano M, Menchini F, et al. Anti-vascular endothelial growth factor for diabetic macular oedema. _Cochrane Database Syst Rev_ . 2014(10):CD007419. 134. Yanagida Y, Ueta T. Systemic safety of ranibizumab for diabetic macular edema: meta-analysis of randomized trials. _Retina_ . 2014;34(4):629-635. 135. Lavinsky D, Cardillo JA, Melo LA, Jr., et al. Randomized clinical trial evaluating mETDRS versus normal or high-density micropulse photocoagulation for diabetic macular edema. _Invest Ophthalmol Vis Sci_ . 2011;52(7):4314-4323. 136. Vujosevic S, Martini F, Longhin E, et al. SUBTHRESHOLD MICROPULSE YELLOW LASER VERSUS SUBTHRESHOLD MICROPULSE INFRARED LASER IN CENTER-INVOLVING DIABETIC MACULAR EDEMA: Morphologic and Functional Safety. _Retina_ . 2015;35(8):1594-1603. 137. BRASIL. Ministério da Saúde. Departamento de Gestão, Incorporação de tecnologias e Inovação em Saúde - DGITIS. Comissão nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec. Aflibercepte para Edema Macular Diabético. Relatório Nº478 de 2019. In: DGITIS, editor.: Ministério da Saúde; 2019. 138. BRASIL. BRASIL. Ministério da Saúde. Departamento de Gestão, Incorporação de tecnologias e Inovação em Saúde - DGITIS. Comissão nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec. Ranibizumabe para tratamento de Edema Macular Diabético (EMD). Relatório Nº549 de 2020. In: DGITIS, editor.: Ministério da Saúde; 2020. 139. Brasil, Agência Nacional de Vigilância Sanitária. Medidas de Prevenção de Endoftalmites e de Síndrome Tóxica do Segmento Anterior Relacionadas a Procedimentos Oftalmológicos Invasivos. Brasília: Anvisa; 2017. 140. McDonald HR, Johnson RN, Schatz H. Surgical results in the vitreomacular traction syndrome. _Ophthalmology_ . 1994;101(8):1397-1402; discussion 1403. 141. Bahadır M, Ertan A, Mertoğlu Ö. Visual acuity comparison of vitrectomy with and without internal limiting membrane removal in the treatment of diabetic macular edema. _International ophthalmology_ . 2005;26(1-2):3-8. 142. Diabetic Retinopathy Clinical Research Network Writing C, Haller JA, Qin H, et al. Vitrectomy outcomes in eyes with diabetic macular edema and vitreomacular traction. _Ophthalmology_ . 2010;117(6):1087-1093 e1083. 143. Flaxel CJ, Edwards AR, Aiello LP, et al. Factors associated with visual acuity outcomes after vitrectomy for diabetic macular edema: diabetic retinopathy clinical research network. _Retina_ . 2010;30(9):1488-1495. 144. Simunovic MP, Hunyor AP, Ho IV. Vitrectomy for diabetic macular edema: a systematic review and meta-analysis. _Can J Ophthalmol_ . 2014;49(2):188-195. 145. Otani T, Kishi S. A controlled study of vitrectomy for diabetic macular edema. _Am J Ophthalmol_ . 2002;134(2):214-219. 146. Raizada S, Al Kandari J, Al Diab F, et al. Pars plana vitrectomy versus three intravitreal injections of bevacizumab for nontractional diabetic macular edema. A prospective, randomized comparative study. _Indian J Ophthalmol_ . 2015;63(6):504-510. 147. Doi N, Sakamoto T, Sonoda Y, et al. Comparative study of vitrectomy versus intravitreous triamcinolone for diabetic macular edema on randomized paired-eyes. _Graefes Arch Clin Exp Ophthalmol_ . 2012;250(1):71-78. 148. Eylia. Aflibercepte. Farm. Resp.: Dra. Dirce Eiko Mimura CRF-SP nº 16532. Bula de remédio; Data da última atualização: 31/08/2019. 149. Sun JK, Wang PW, Taylor S, Haskova Z. Durability of Diabetic Retinopathy Improvement with As-Needed Ranibizumab: OpenLabel Extension of RIDE and RISE Studies. Ophthalmology 2019 May;126(5):712-720.  
150. Lang GE, Berta A, Eldem BM, et al. Two-year safety and efficacy of ranibizumab 0.5 mg in diabetic macular edema: interim analysis of the RESTORE extension study. _Ophthalmology_ . 2013;120(10):2004-2012. 151. Schmidt-Erfurth U, Lang GE, Holz FG, et al. Three-year outcomes of individualized ranibizumab treatment in patients with diabetic macular edema: the RESTORE extension study. _Ophthalmology_ . 2014;121(5):1045-1053.  
204  
152. Boyer DS, Nguyen QD, Brown DM, et al. Outcomes with As-Needed Ranibizumab after Initial Monthly Therapy: LongTerm Outcomes of the Phase III RIDE and RISE Trials. _Ophthalmology_ . 2015;122(12):2504-2513 e2501. 153. Wells JA, Glassman AR, Ayala AR, et al. Aflibercept, Bevacizumab, or Ranibizumab for Diabetic Macular Edema: TwoYear Results from a Comparative Effectiveness Randomized Clinical Trial. _Ophthalmology_ . 2016;123(6):1351-1359.  
154. Freund KB, Korobelnik JF, Devenyi R, et al. TREAT-AND-EXTEND REGIMENS WITH ANTI-VEGF AGENTS IN RETINAL DISEASES: A Literature Review and Consensus Recommendations. _Retina_ . 2015;35(8):1489-1506. 155. Brasil. Ministério da Saúde. Portaria n°375, de 10 de novembro de 2009. Aprova o roteiro a ser utilizado na elaboração de Protocolos Clínicos e Diretrizes Terapêuticas no âmbito da Secretaria de Atenção à Saúde. In: Ministério da Saúde, editor. Brasília 2009. 156. Shea BJ, Reeves BC, Wells G, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. _bmj_ . 2017;358:j4008. 157. Cumpston M, Li T, Page MJ, et al. Updated guidance for trusted systematic reviews: a new edition of the Cochrane Handbook for Systematic Reviews of Interventions. _Cochrane Database Syst Rev_ . 2019;10:ED000142. 158. Wells GA, Shea B, O’Connell D, et al. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomised studies in meta-analyses. Oxford; 2000. 159. Whiting PF, Rutjes AW, Westwood ME, et al. QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. _Annals of internal medicine_ . 2011;155(8):529-536. 160. Falck-Ytter Y, Guyatt G, Vist G, et al. Rating quality of evidence and strength of recommendations GRADE: An emerging consensus on rating quality of evidence and strength of recommendations. _BMJ_ . 2008;336:924-926. 161. Channa R, Sophie R, Khwaja A, et al. Factors affecting visual outcomes in patients with diabetic macular edema treated with ranibizumab. _Eye_ . 2014;28(3):269-278. 162. Association AD. The absence of a glycemic threshold for the development of long-term complications: the perspective of the Diabetes Control and Complications Trial. _Diabetes_ . 1996;45(10):1289-1298. 163. Aiello LP, Edwards AR, Beck RW, et al. Factors associated with improvement and worsening of visual acuity 2 years after focal/grid photocoagulation for diabetic macular edema. _Ophthalmology_ . 2010;117(5):946-953. 164. Klein R, Klein BE, Moss SE, et al. Glycosylated hemoglobin predicts the incidence and progression of diabetic retinopathy. _JAMA_ . 1988;260(19):2864-2871. 165. Klein R, Klein BE, Moss SE, et al. Is blood pressure a predictor of the incidence or progression of diabetic retinopathy? _Archives of internal medicine_ . 1989;149(11):2427-2432. 166. Klein R, Meuer SM, Moss SE, et al. The relationship of retinal microaneurysm counts to the 4-year progression of diabetic retinopathy. _Arch Ophthalmol_ . 1995;107(12):1780-1785. 167. Hutchinson A, McIntosh A, Peters J, et al. Effectiveness of screening and monitoring tests for diabetic retinopathy--a systematic review. _Diabet Med_ . 2000;17(7):495-506. 168. Ibáñez J, Cristóbal J, Faure E, et al. Use of retinal photography in the diagnosis of diabetic macular edema. _Archivos de la Sociedad Española de Oftalmología (English Edition)_ . 2013;88(7):250-254. 169. Vujosevic S, Trento B, Bottega E, et al. Scanning laser ophthalmoscopy in the retromode in diabetic macular oedema. _Acta Ophthalmol_ . 2012;90(5):e374-380. 170. Waldstein SM, Hickey D, Mahmud I, et al. Two-wavelength fundus autofluorescence and macular pigment optical density imaging in diabetic macular oedema. _Eye (Lond)_ . 2012;26(8):1078-1085. 171. Goebel W, Franke R. Retinal thickness in diabetic retinopathy: comparison of optical coherence tomography, the retinal thickness analyzer, and fundus photography. _Retina_ . 2006;26(1):49-57. 172. Neubauer AS, Welge-Lussen UC, Thiel MJ, et al. Tele-screening for diabetic retinopathy with the retinal thickness analyzer. _Diabetes Care_ . 2003;26(10):2890-2897. 173. Barteselli G, Chhablani J, Lee SN, et al. Safety and efficacy of oral fluorescein angiography in detecting macular edema in comparison with spectral-domain optical coherence tomography. _Retina_ . 2013;33(8):1574-1583. 174. Khalaf SS, Al-Bdour MD, Al-Till MI. Clinical biomicroscopy versus fluorescein angiography: effectiveness and sensitivity in detecting diabetic retinopathy. _Eur J Ophthalmol_ . 2007;17(1):84-88. 175. Control D, Group CTR. Color photography vs. fluorescein angiography in the detection of diabetic retinopathy in the Diabetes Control and Complications Trial. _Arch Ophthalmol_ . 1987;105:1344-1351. 176. Virgili G, Menchini F, Murro V, et al. Optical coherence tomography (OCT) for detection of macular oedema in patients with diabetic retinopathy. _Cochrane Database Syst Rev_ . 2011(7):CD008081. 177. Salz DA, de Carlo TE, Adhi M, et al. Select Features of Diabetic Retinopathy on Swept-Source Optical Coherence Tomographic Angiography Compared With Fluorescein Angiography and Normal Eyes. _JAMA Ophthalmol_ . 2016;134(6):644-650. 178. Azrak C, Baeza-Díaz MV, Palazón-Bru A, et al. Validity of optical coherence tomography as a diagnostic method for diabetic retinopathy and diabetic macular edema. _Medicine_ . 2015;94(38). 179. Goebel W, Kretzchmar-Gross T. Retinal thickness in diabetic retinopathy: a study using optical coherence tomography (OCT). _Retina_ . 2002;22(6):759-767. 180. Sanchez-Tocino H, Alvarez-Vidal A, Maldonado MJ, et al. Retinal thickness study with optical coherence tomography in patients with diabetes. _Invest Ophthalmol Vis Sci_ . 2002;43(5):1588-1594. 181. Azad R, Sain S, Sharma YR, et al. Comparison of intravitreal bevacizumab, intravitreal triamcinolone acetonide, and macular grid augmentation in refractory diffuse diabetic macular edema: A prospective, randomized study. _Oman J Ophthalmol_ . 2012;5(3):166-170. 182. Michaelides M, Kaines A, Hamilton RD, et al. A prospective randomized trial of intravitreal bevacizumab or laser therapy in the management of diabetic macular edema (BOLT study) 12-month data: report 2. _Ophthalmology_ . 2010;117(6):1078-1086 e1072. 183. Sivaprasad S, Crosby-Nwaobi R, Esposti SD, et al. Structural and functional measures of efficacy in response to bevacizumab monotherapy in diabetic macular oedema: exploratory analyses of the BOLT study (report 4). _PLoS One_ . 2013;8(8):e72755. 184. Bressler SB, Qin H, Beck RW, et al. Factors associated with changes in visual acuity and central subfield thickness at 1 year after treatment for diabetic macular edema with ranibizumab. _Archives of Ophthalmology_ . 2012;130(9):1153-1161. 185. Diabetic Retinopathy Clinical Research N, Elman MJ, Qin H, et al. Intravitreal ranibizumab for diabetic macular edema with prompt versus deferred laser treatment: three-year randomized trial results. _Ophthalmology_ . 2012;119(11):2312-2318. 186. Bressler SB, Qin H, Melia M, et al. Exploratory analysis of the effect of intravitreal ranibizumab or triamcinolone on worsening of diabetic retinopathy in a randomized clinical trial. _JAMA Ophthalmol_ . 2013;131(8):1033-1040. 187. Elman MJ, Bressler NM, Qin H, et al. Expanded 2-year follow-up of ranibizumab plus prompt or deferred laser or triamcinolone plus prompt laser for diabetic macular edema. _Ophthalmology_ . 2011;118(4):609-614. 188. Nepomuceno AB, Takaki E, Paes de Almeida FP, et al. A prospective randomized trial of intravitreal bevacizumab versus ranibizumab for the management of diabetic macular edema. _Am J Ophthalmol_ . 2013;156(3):502-510 e502. 189. Do DV, Nguyen QD, Khwaja AA, et al. Ranibizumab for edema of the macula in diabetes study: 3-year outcomes and the need for prolonged frequent treatment. _JAMA Ophthalmol_ . 2013;131(2):139-145.  
190. Nguyen QD, Shah SM, Khwaja AA, et al. Two-year outcomes of the ranibizumab for edema of the mAcula in diabetes (READ-2) study. _Ophthalmology_ . 2010;117(11):2146-2151.  
205  
191. Nguyen QD, Shah SM, Heier JS, et al. Primary End Point (Six Months) Results of the Ranibizumab for Edema of the mAcula in diabetes (READ-2) study. _Ophthalmology_ . 2009;116(11):2175-2181 e2171. 192. Soheilian M, Garfami KH, Ramezani A, et al. Two-year results of a randomized trial of intravitreal bevacizumab alone or combined with triamcinolone versus laser in diabetic macular edema. _Retina_ . 2012;32(2):314-321.  
193. Soheilian M, Ramezani A, Obudi A, et al. Randomized trial of intravitreal bevacizumab alone or combined with triamcinolone versus macular photocoagulation in diabetic macular edema. _Ophthalmology_ . 2009;116(6):1142-1150. 194. Soheilian M, Ramezani A, Bijanzadeh B, et al. Intravitreal bevacizumab (avastin) injection alone or combined with triamcinolone versus macular photocoagulation as primary treatment of diabetic macular edema. _Retina_ . 2007;27(9):1187-1195. 195. Royle P, Mistry H, Auguste P, et al. Pan-retinal photocoagulation and other forms of laser treatment and drug therapies for non-proliferative diabetic retinopathy: systematic review and economic evaluation. _Health Technol Assess_ . 2015;19(51):v-xxviii, 1- 247. 196. Tewari H, Ravindranath H, Kumar A, et al. Diode laser scatter photocoagulation in diabetic retinopathy. _Annals of ophthalmology_ . 2000;32(2):110-112. 197. Diabetic Retinopathy Clinical Research N. Randomized clinical trial evaluating intravitreal ranibizumab or saline for vitreous hemorrhage from proliferative diabetic retinopathy. _JAMA Ophthalmol_ . 2013;131(3):283-293. 198. Avitabile T, Bonfiglio V, Castiglione F, et al. Severe proliferative diabetic retinopathy treated with vitrectomy or panretinal photocoagulation: a monocenter randomized controlled clinical trial. _Can J Ophthalmol_ . 2011;46(4):345-351. 199. Faghihi H, Taheri A, Farahvash MS, et al. Intravitreal triamcinolone acetonide injection at the end of vitrectomy for diabetic vitreous hemorrhage: a randomized, clinical trial. _Retina_ . 2008;28(9):1241-1246. 200. Muqit MM, Marcellino GR, Henson DB, et al. Single-session vs multiple-session pattern scanning laser panretinal photocoagulation in proliferative diabetic retinopathy: The Manchester Pascal Study. _Arch Ophthalmol_ . 2010;128(5):525-533. 201. Muqit MM, Young LB, McKenzie R, et al. Pilot randomised clinical trial of Pascal TargETEd Retinal versus variable fluence PANretinal 20 ms laser in diabetic retinopathy: PETER PAN study. _Br J Ophthalmol_ . 2013;97(2):220-227. 202. Muraly P, Limbad P, Srinivasan K, et al. Single session of Pascal versus multiple sessions of conventional laser for panretinal photocoagulation in proliferative diabetic retinopathy: a comparitive study. _Retina_ . 2011;31(7):1359-1365. 203. Nagpal M, Marlecha S, Nagpal K. Comparison of laser photocoagulation for diabetic retinopathy using 532-nm standard laser versus multispot pattern scan laser. _Retina_ . 2010;30(3):452-458. 204. Salman AG. Pascal laser versus conventional laser for treatment of diabetic retinopathy. _Saudi journal of ophthalmology_ . 2011;25(2):175-179. 205. Al-Hussainy S, Dodson PM, Gibson JM. Pain response and follow-up of patients undergoing panretinal laser photocoagulation with reduced exposure times. _Eye (Lond)_ . 2008;22(1):96-99. 206. Bandello F, Brancato R, Menchini U, et al. Light panretinal photocoagulation (LPRP) versus classic panretinal photocoagulation (CPRP) in proliferative diabetic retinopathy. _Semin Ophthalmol_ . 2001;16(1):12-18. 207. Mirshahi A, Lashay A, Roozbahani M, et al. Pain score of patients undergoing single spot, short pulse laser versus conventional laser for diabetic retinopathy. _Graefes Arch Clin Exp Ophthalmol_ . 2013;251(4):1103-1107. 208. Shimura M, Yasuda K, Nakazawa T, et al. Quantifying alterations of macular thickness before and after panretinal photocoagulation in patients with severe diabetic retinopathy and good vision. _Ophthalmology_ . 2003;110(12):2386-2394. 209. Suto C, Hori S, Kato S. Management of type 2 diabetics requiring panretinal photocoagulation and cataract surgery. _J Cataract Refract Surg_ . 2008;34(6):1001-1006. 210. Zhang Y, Ma J, Meng N, et al. Comparison of intravitreal triamcinolone acetonide with intravitreal bevacizumab for treatment of diabetic macular edema: a meta-analysis. _Curr Eye Res_ . 2013;38(5):578-587. 211. Manabe A, Shimada H, Hattori T, et al. Randomized controlled study of intravitreal bevacizumab 0.16 mg injected one day before surgery for proliferative diabetic retinopathy. _Retina_ . 2015;35(9):1800-1807. 212. Grover D, Li TJ, Chong CC. Intravitreal steroids for macular edema in diabetes. _Cochrane Database Syst Rev_ . 2008(1):CD005656. 213. Jin E, Luo L, Bai Y, et al. Comparative effectiveness of intravitreal bevacizumab with or without triamcinolone acetonide for treatment of diabetic macular edema. _Annals of Pharmacotherapy_ . 2015;49(4):387-397. 214. Ford JA, Elders A, Shyangdan D, et al. The relative clinical effectiveness of ranibizumab and bevacizumab in diabetic macular oedema: an indirect comparison in a systematic review. _BMJ_ . 2012;345:e5182. 215. Korobelnik JF, Kleijnen J, Lang SH, et al. Systematic review and mixed treatment comparison of intravitreal aflibercept with other therapies for diabetic macular edema (DME). _BMC Ophthalmol_ . 2015;15:52. 216. Wells JA, Glassman AR, Jampol LM, et al. Association of Baseline Visual Acuity and Retinal Thickness With 1-Year Efficacy of Aflibercept, Bevacizumab, and Ranibizumab for Diabetic Macular Edema. _JAMA Ophthalmol_ . 2016;134(2):127-134. 217. Bressler SB, Glassman AR, Almukhtar T, et al. Five-Year Outcomes of Ranibizumab With Prompt or Deferred Laser Versus Laser or Triamcinolone Plus Deferred Ranibizumab for Diabetic Macular Edema. _Am J Ophthalmol_ . 2016;164:57-68. 218. Bressler SB, Almukhtar T, Bhorade A, et al. Repeated intravitreous ranibizumab injections for diabetic macular edema and the risk of sustained elevation of intraocular pressure or the need for ocular hypotensive treatment. _JAMA Ophthalmol_ . 2015;133(5):589-597. 219. Ishibashi T, Li X, Koh A, et al. The REVEAL Study: Ranibizumab Monotherapy or Combined with Laser versus Laser Monotherapy in Asian Patients with Diabetic Macular Edema. _Ophthalmology_ . 2015;122(7):1402-1415. 220. Network DRCR. Randomized trial evaluating short-term effects of intravitreal ranibizumab or triamcinolone acetonide on macular edema following focal/grid laser for diabetic macular edema in eyes also receiving panretinal photocoagulation. _Retina (Philadelphia, Pa)_ . 2011;31(6):1009. 221. Gillies MC, McAllister IL, Zhu M, et al. Pretreatment with intravitreal triamcinolone before laser for diabetic macular edema: 6-month results of a randomized, placebo-controlled trial. _Investigative ophthalmology & visual science_ . 2010;51(5):23222328. 222. Gillies MC, McAllister IL, Zhu M, et al. Intravitreal triamcinolone prior to laser treatment of diabetic macular edema: 24month results of a randomized controlled trial. _Ophthalmology_ . 2011;118(5):866-872. 223. Diabetic Retinopathy Clinical Research N, Beck RW, Edwards AR, et al. Three-year follow-up of a randomized trial comparing focal/grid photocoagulation and intravitreal triamcinolone for diabetic macular edema. _Arch Ophthalmol_ . 2009;127(3):245-251.  
224. Diabetic Retinopathy Clinical Research N. A randomized trial comparing intravitreal triamcinolone acetonide and focal/grid photocoagulation for diabetic macular edema. _Ophthalmology_ . 2008;115(9):1447-1449, 1449 e1441-1410. 225. Network DRCR. Randomized trial of peribulbar triamcinolone acetonide with and without focal photocoagulation for mild diabetic macular edema: a pilot study. _Ophthalmology_ . 2007;114(6):1190-1196. e1193. 226. Lam DS, Chan CK, Mohamed S, et al. Intravitreal triamcinolone plus sequential grid laser versus triamcinolone or laser alone for treating diabetic macular edema: six-month outcomes. _Ophthalmology_ . 2007;114(12):2162-2167. 227. Campochiaro PA, Brown DM, Pearson A, et al. Long-term benefit of sustained-delivery fluocinolone acetonide vitreous inserts for diabetic macular edema. _Ophthalmology_ . 2011;118(4):626-635 e622. 228. Campochiaro PA, Brown DM, Pearson A, et al. Sustained delivery fluocinolone acetonide vitreous inserts provide benefit for at least 3 years in patients with diabetic macular edema. _Ophthalmology_ . 2012;119(10):2125-2132.  
206  
229. Pearson PA, Comstock TL, Ip M, et al. Fluocinolone acetonide intravitreal implant for diabetic macular edema: a 3-year multicenter, randomized, controlled clinical trial. _Ophthalmology_ . 2011;118(8):1580-1587.  
230. Callanan DG, Loewenstein A, Patel SS, et al. A multicenter, 12-month randomized study comparing dexamethasone intravitreal implant with ranibizumab in patients with diabetic macular edema. _Graefes Arch Clin Exp Ophthalmol_ . 2017;255(3):463473.  
231. Danis RP, Sadda S, Li XY, et al. Anatomical effects of dexamethasone intravitreal implant in diabetic macular oedema: a pooled analysis of 3-year phase III trials. _Br J Ophthalmol_ . 2016;100(6):796-801.  
232. Maturi RK, Pollack A, Uy HS, et al. Intraocular Pressure in Patients with Diabetic Macular Edema Treated with Dexamethasone Intravitreal Implant in the 3-Year Mead Study. _Retina_ . 2016;36(6):1143-1152.  
233. Boyer DS, Yoon YH, Belfort R, Jr., et al. Three-year, randomized, sham-controlled trial of dexamethasone intravitreal implant in patients with diabetic macular edema. _Ophthalmology_ . 2014;121(10):1904-1914.  
234. Augustin AJ, Kuppermann BD, Lanzetta P, et al. Dexamethasone intravitreal implant in previously treated patients with diabetic macular edema: subgroup analysis of the MEAD study. _BMC Ophthalmol_ . 2015;15:150.  
235. Ramu J, Yang Y, Menon G, et al. A randomized clinical trial comparing fixed vs pro-re-nata dosing of Ozurdex in refractory diabetic macular oedema (OZDRY study). _Eye (Lond)_ . 2015;29(12):1603-1612. 236. Heng LZ, Sivaprasad S, Crosby-Nwaobi R, et al. A prospective randomised controlled clinical trial comparing a combination of repeated intravitreal Ozurdex and macular laser therapy versus macular laser only in centre-involving diabetic macular oedema (OZLASE study). _Br J Ophthalmol_ . 2016;100(6):802-807.  
237. Callanan DG, Gupta S, Boyer DS, et al. Dexamethasone intravitreal implant in combination with laser photocoagulation for the treatment of diffuse diabetic macular edema. _Ophthalmology_ . 2013;120(9):1843-1851.  
238. Park JH, Woo SJ, Ha YJ, et al. Effect of vitrectomy on macular microcirculation in patients with diffuse diabetic macular edema. _Graefes Arch Clin Exp Ophthalmol_ . 2009;247(8):1009-1017.  
239. Payne JF, Wykoff CC, Clark WL, et al. Randomized trial of treat and extend ranibizumab with and without navigated laser for diabetic macular edema: TREX-DME 1 year outcomes. _Ophthalmology_ . 2017;124(1):74-81. 240. Prünte C, Fajnkuchen F, Mahmood S, et al. Ranibizumab 0.5 mg treat-and-extend regimen for diabetic macular oedema: the RETAIN study. _British Journal of Ophthalmology_ . 2016;100(6):787-795.  
241. Gonzalez VH, Boyer DS, Schmidt-Erfurth U, et al. Microperimetric assessment of retinal sensitivity in eyes with diabetic macular edema from a phase 2 study of intravitreal aflibercept. _Retina_ . 2015;35(4):687-694.  
207

---

