<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: Geral -->
**Ministério da Saúde Secretaria de Atenção à Saúde**  
PORTARIA Nº 486, DE 06 DE MARÇO DE 2017  
Estabelece Protocolo de Uso da radiação  
para cross-linking corneano no  
tratamento do ceratocone.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE, no uso de suas atribuições,  
Considerando o Relatório de Recomendação nº 225 – Setembro/2016, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC);  
Considerando a Portaria nº 30/SCTIE/MS, de20 de setembro de 2016, que torna pública a decisão de incorporar o cross-linking corneano para o tratamento do ceratocone no âmbito do Sistema Único de Saúde; e  
Considerando a avaliação técnica do Departamento de Gestão da Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Economia da Saúde, Investimentos e Desenvolvimento - DESID/SE/MS, do Departamento do Complexo Industrial e Inovação em Saúde (DECIIS/SCTIE/MS), do Departamento de Regulação, Avaliação e Controle de Sistemas (DRAC/SAS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolve:  
Art. 1º  Fica aprovado, na forma do Anexo, disponível no sítio: www.saude.gov.br/sas, o Protocolo de Uso da radiação para cross-linking corneanono tratamento do ceratocone.  
Parágrafo único. O Protocolo de Uso de que trata este artigo, que contém o conceito geral do ceratocone, sinais e sintomas, critérios de diagnóstico, tratamento, técnica utilizada, indicação e contra indicação e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Art. 2ºOs gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doençaem todas as etapas descritas no Anexo desta Portaria.  
Art. 3ºFica incluído na Tabela de Procedimentos, Medicamentos, Órteses/Próteses e Materiais Especiais do SUS o procedimento 04.05.05.040-2- Radiação para cross-linking corneano, conforme a seguir:  
|Procedimento:|04.05.05.040-2 - RADIAÇÃO PARA CROSS-LINKING CORNEANO|
|---|---|
|Descrição:|Consiste na técnica utilizada para o fortalecimento do tecido<br>corneano. É realizada pela aplicação de radiação ultravioleta à<br>superfície corneana, previamente tratada com colírio, com ou sem<br>remoção do epitélio corneano, com o objetivo de reduzir ou mesmo<br>paralisar a progressão do afinamento corneano que ocorre nos<br>casos de ceratocone. Excludente com o procedimento 04.05.05.014-<br>3-Implante<br>intraestromal.<br>Inclui<br>o<br>colírio<br>necessário<br>ao<br>procedimento.|
|Instrumento de registro:|02- BPA (individualizado)<br>03- AIH ( procedimento principal)|
|Complexidade:|MC - Média Complexidade|
|Modalidade de<br>Atendimento:|01- Ambulatorial<br>02- Hospitalar<br>03- Hospital -Dia|
|Tipo de Financiamento:|06 - Média e Alta Complexidade (MAC)|
|Média de permanência|1|
|Quantidade máxima|1|
|Pontos|150|
|Sexo|Ambos|
|Idade mínima|15 anos|
|Idade máxima|45 anos|
|Valor Ambulatorial Total:|R$ 292,72|
|Valor Hospitalar (SH):|R$ 291,08|
|Valor do Serviço profissional<br>(SP)|R$ 81,64|
|Valor Hospitalar Total:|R$ 372,72|  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
|CBO:|225265|
|---|---|
|CID:|H18.6 - Ceratocone|
|Leito:|01 -Cirúrgico<br>09 - Leito dia/cirúrgicos|
|Serviço / Classificação:|131- Serviço de Oftalmologia 033 – Tratamento cirúrgico do<br>aparelho da visão|
|Atributo complementar:|Inclui valor de anestesia|
|Renases|164 - Cirurgia do aparelho da visão|  
Art. 4º  O procedimento 04.05.05.040-2- RADIAÇÃO PARA CROSS-LINKING CORNEANO a  
ser incluído na Tabela de Procedimentos, Medicamentos, Órteses/Próteses e Materiais Especiais do SUS é excludente com o procedimento 04.05.05.014-3-Implante intraestromal.  
Art. 5º Os recursos orçamentários necessários à implementação do procedimento 04.05.05.040-2 RADIAÇÃO PARA CROSS-LINKING CORNEANO, incluído por esta Portaria, correrão por conta do orçamento do Ministério da Saúde, onerando o Programa de Trabalho 10.302.12.20.8585 Atenção à Saúde da População para Procedimentos de Média e Alta Complexidade.  
Art.6º  Esta Portaria entra em vigor na data de sua publicação, com efeitos operacionais nos sistemas de informações do SUS para a competência seguinte à da sua publicação.

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
**Ministério da Saúde Secretaria de Atenção à Saúde**  
ANEXO

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O ceratocone consiste em doença degenerativa do olho que ocasiona deformidade da córnea, levando ao seu afinamento, abaulamento e enfraquecimento. Causa piora da acuidade visual, com impacto na qualidade de vida do paciente, além de outros sintomas de menor gravidade, tais como irritação ocular, halos luminosos e fotossensibilidade. A literatura relata que a incidência do ceratocone é baixa. Um estudo de acompanhamento populacional, ao longo de 48 anos, identificou uma incidência de 2 casos por 100.000 habitantes/ano e prevalência média de 54,5 casos por 100.000 habitantes(1). Outros recentes relatam incidência de aproximadamente um caso a cada 2.000 pessoas(2).  
Frequentemente, manifesta-se de forma bilateral, porém de forma assimétrica. A faixa etária prevalente dos pacientes é a puberdade, porém o quadro pode evoluir principalmente durante a segunda e terceira décadas de vida, excepcionalmente até a quinta década. A progressão do ceratocone varia entre pacientes e também no mesmo indivíduo ao longo do tempo, tendo evolução mais agressiva em pacientes jovens(3-5).  
Inexiste alteração na incidência de ceratocone conforme gênero e raça, porém tem sido associado a doenças oculares prévias, tais como ceratoconjuntivite alérgica, retinitepigmentosa e amaurose congênita de Leber. Supõe-se também associação com doenças sistêmicas e do tecido conjuntivo. Fatores predisponentes incluem história de atopia, especialmente alergia ocular, uso de lentes de contato rígidas e fricção ocular vigorosa. Em torno de 13% dos casos têm história familiar da doença(5).

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
DIAGNÓSTICO  
<u>Sintomas:</u>  
Comprometimento unilateral da visão devido à miopia progressiva e astigmatismo; ocasionalmente, a apresentação inicial é com hidropsia aguda.

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Oftalmoscopia direta a uma distância de meio metro revela reflexo em “gota de  
óleo”.  
- Retinoscopia revela reflexo irregular “em tesoura”.  
- Biomicroscopia com lâmpada de fenda revela estrias estromais, verticais, finas e  
profundas (linhas de Vogt) que desaparecem ao se exercer pressão no globo ocular.  
- Depósitos epiteliais de ferro, visualizados com filtro azul de cobaldo, cincundando a  
- base do cone.  
- Progressiva protrusão corneana na forma de cone, com afinamento estromal máximo  
emseu ápice.  
- Abaulamento da pálpebra inferior na mirada para baixo (Sinal de Munson).  
- Hidropsia aguda é causada pela ruptura da membrana de Descemet, permitindo o  
influxo de humor aquoso para o estroma corneano. Promove uma súbita redução da acuidade visual associado a desconforto, fotofobia, dor e lacrimejamento.  
- Ceratometria: Leituras com aumento progressivo da curvatura corneana.  
- Topografia Corneana:Astigmatismoque varia de simétrico para assimétrico ínferotemporalmente (Parte abaixo da córnea (ínfero) temporalmente (que está ao lado do osso temporal) oposto do osso nasal).  
Os métodos mais frequentemente utilizados para avaliar a progressão do ceratocone  
são:  
- Acuidade visual - frequentemente analisada pela melhor acuidade visual corrigida (BCVA) e acuidade visual não corrigida (UDVA), medida por um logaritmo do ângulo mínimo de resolução (LogMAR) ou por linhas do teste de Snellen.  
- Ceratometria: medida da curvatura da córnea em dioptrias ou milímetros.  
- Topografia da córnea - medida da curvatura da córnea por três análises da  
- ceratometria - máxima (Kmax), média (Kmed) e mínima (Kmin) - em dioptria (D).

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Paquimetria - medida da espessura da córnea em micra (km).  
Os instrumentos utilizados para essas medidas são: ceratômetro, topógrafo, paquímetro e tomógrafo de córnea.  
Há vários sistemas de classificação da evolução do ceratocone. A mais aceita consiste em alterações, àreavaliação do paciente no máximo em um ano, com:  
- Aumento do astigmatismo corneal central de 1.00D ou mais;  
- Aumento da ceratometria máxima (Kmax) de 1.00D ou mais;  
- Aumento na refração subjetiva de 1.00DC ou mais(6-9).  
A estabilização do ceratocone é medida pela manutenção ou regressão dos valores de ceratometria (Kmax, Kmed) em, pelo menos, um ano. Pode haver melhora nas medidas de acuidade, entretanto esta não é o objetivo do tratamento.

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O principal objetivo do uso docross-linkingé conter a progressão do ceratocone. Logo, o melhor candidato ao tratamento é o indivíduo com sinais claros de progressão da doença. Atualmente, não existem critérios definitivos para a progressão do ceratocone, porém os parâmetros a serem considerados são a mudança do erro refrativo, piora da acuidade visual, bem como progressão nos valores encontrados nas topografias e tomografias da córnea.  
Estudos mostram que o cross-linking foi mais eficaz na faixa etária pediátrica (10 anos) e naqueles com menos de 26 anos de idade em comparação com aqueles com mais idade. Idade acima de 35 anos e acuidade visual com correção pré-operatória melhor que 20/25 foram identificados como fatores de risco para complicação (perda de duas ou mais linhas de Snellen).  
Nenhum estudo encontrado cita mais de uma aplicação por paciente.

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Espessura corneana menor que 400 micrômetros para uso do protocolo clássico;  
- Infecção herpética prévia;  
- Infecção concomitante;  
- Cicatriz corneana grave ou opacificaçãocorneana;  
- Doença de superfície ocular grave; ou

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O cross-linking consiste em procedimento terapêutico minimamente invasivo que visaa bloquear a evolução do ceratocone, por meio do aumento da força biomecânica, levando ao enrijecimento do tecido da córnea. Este fenômeno ocorre pela criação adicional de ligações químicas no estroma corneal, por meio de fotopolimerização altamente localizada que minimiza a exposição de estruturas adjacentes do olho. Esta metodologia foi desenvolvida em meados dos anos 1990, por pesquisadores da Universidade de Dresden, Alemanha, com base no observado em processo fisiológico de cross-linking no tecido conectivo em pacientes com diabete mélito e angina. Na córnea, com o avanço da idade do indivíduo, as fibras de colágeno desenvolvem naturalmente quantidade superior de ligações covalentes, o que explica a estabilização do ceratocone em paciente com maior idade(9,10). A técnica clássica do crosslinking pode ser realizada com ou sem remoção do epitélio corneal (cerca de 7mm de diâmetro), mediante anestesia tópica. Utiliza solução de riboflavina (vitamina B2) isotônica a 0,1%, com administração tópica, a cada cinco minutos, ao longo de meia hora, para saturar o estroma corneal. A riboflavina age como um fotossensibilizador que aumenta a absorção da luz ultravioleta A pela córnea. A radiação ultravioleta A é aplicada com 365nm, por 30 minutos, a 5 cm da córnea. Após a irradiação, o olho é enxaguado com solução fisiológica, aplicado colírio antibiótico e anti-inflamatório e colocada lente de contatoprotetora. Estes colírios, além de lubrificante ocular e analgésicos, são mantidos no pósoperatório por 1 semana. Neste período o paciente pode apresentar dor, lacrimejamento e embaçamento visual. Há também descrição na literatura de variações da técnica clássica, em geral, por meio de equipamentos que possibilitam a redução do tempo do procedimento(6).

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O risco per-operatório e de complicações pós-operatórias é menor que 1%, e, dos casos publicados, a infecção pós-operatória foi resolvida com tratamento clínico, sendo que nenhum paciente perdeu a visão irreversivelmente(11).

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR.  
Doentes com indicação de radiação para cross-linking corneano no tratamento do ceratocone devem ser atendidos em serviços especializados em oftalmologia, conforme definido na Portaria Nº 288/SAS/MS, de 19 de maio de 2008, e com porte tecnológico suficiente para avaliar e realizar o procedimento e o acompanhamento dos indivíduos tratados, para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos), entre outras. Ações de auditoria devem verificar in loco, por exemplo, a observância deste Protocolo; regulação do acesso assistencial; qualidade da autorização; a conformidade da indicação, do procedimento e do acompanhamento; compatibilidade do procedimento codificado com o diagnóstico; a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Constam da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS os seguintes procedimentosespecíficos para o tratamento do ceratocone, excludentes entre si:  
04.05.05.014-3-IMPLANTE INTRAESTROMAL e  
04.05.05.040-2 - RADIAÇÃO PARA CROSS-LINKING CORNEANO.  
Ressalta-se que o procedimento 04.05.05.040-2 - Radiação para crosslinkingcorneanoinclui o colírio necessário ao procedimento e que o transplante de córnea continua sendo o tratamento convencional dos casos graves, que é indicado em cerca de 10% a 20% dos casos de ceratocone.  
Relativamente ao transplante de córnea, constam da Tabela de Procedimentos, Medicamentos,Órteses, Próteses e Materiais Especiais do SUS os seguintes procedimentos:  
05.05.01.009-7 - TRANSPLANTE DE CÓRNEA,  
05.05.01.010-0 - TRANSPLANTE DE CÓRNEA (EM CIRURGIAS COMBINADAS),  
05.05.01.011-9 - TRANSPLANTE DE CÓRNEA (EM REOPERAÇÕES) e  
05.06.01.001-5 - ACOMPANHAMENTO DE PACIENTE PÓS-TRANSPLANTE DE CÓRNEA.  
Cada serviço deve coletar rotineiramente seus dados e computar os resultados, detectando possíveis nichos suspeitos de resultados piores para análise detalhada de suas causas, pois os dados negativos podem apenas sugerir um pior resultado associado, por exemplo, a um perfil assistencial a pacientes mais graves.  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE  
É obrigatória a informação ao paciente, ou a seu responsável legal, dos potenciais riscos, benefícios e eventos adversos relacionados à radiação para cross-linkingcorneano no tratamento do ceratocone, o que poderá ser formalizado por meio da assinatura de Termo de Esclarecimento e Responsabilidade.

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
1- Kennedy RH, Bourne WM, Dyer JA. A 48-year clinical and epidemiologic study ofkeratoconus.Am J Ophthalmol. 1986;101(3):267-73.  
2- Rabinowitz YS. Keratoconus.SurvOphthalmol. 1998; 42(4):297-319.  
3 - Stenevi U, Claesson M, Holmberg Y, Liljegren A, Toftgård A, Wonneberger W, et al. Corneal Crosslinking in Keratoconus. Göteborg: VästraGötalandsregionen, SahlgrenskaUniversitetssjukhuset, HTA-centrum; 2011 01 set. 2015]. Available from: https://www2.sahlgrenska.se/upload/SU/HTA-centrum/HTA-rapporter/HTArapport%20Corneal%20Cross%20linking%202011-07-  
25%20%20inkl%20bil.%20till%20publicering.pdf.  
4 - Health CAfDaTi. Corneal Cross-linking with Riboflavin for Keratoconus: A Review of the Clinical and Cost-Effectiveness 2013 01 set. 2015]. Available from: https://www.cadth.ca/corneal-cross-linking-riboflavin-keratoconus-review-clinical-and-costeffectiveness.  
5 - Sykakis E, Karim R, Evans J, Bunce C, Amissah-Arthur K, Patwary S, et al. Corneal collagen cross-linking for treating keratoconus. Cochrane Database of Systematic Reviews.2015(9).  
6 - Kanellopoulos AJ. Comparison of sequential vs same-day simultaneous collagen cross-linking and topography-guided PRK for treatment of keratoconus. J Refract Surg. 2009;25(9):S812-8.

---

<!-- METADADOS: doenca: Cross-linking corneano no tratamento do ceratone | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
7 - Wittig-Silva C, Chan E, Islam FMA, Wu T, Whiting M, Snibson GR. A randomized, controlled trial of corneal collagen cross-linking in progressive keratoconus: Three-year results. Ophthalmology. 2014;121(4):812-21.  
8 - Lang SJ, Messmer EM, Geerling G, Mackert MJ, Brunner T, Dollak S, et al. Prospective, randomized, double-blind trial to investigate the efficacy and safety of corneal cross-linking to halt the progression of keratoconus. BMC Ophthalmol. 2015;15:78.  
9 - Seyedian MA, Aliakbari S, Miraftab M, Hashemi H, Asgari S, Khabazkhoob M. Corneal Collagen Cross-Linking in the Treatment of Progressive Keratoconus: A Randomized Controlled Contralateral Eye Study. Middle East Afr J Ophthalmol. 2015;22(3):340-5.  
10 - Sharma N, Suri K, Sehra SV, Titiyal JS, Sinha R, Tandon R, et al. Collagen cross-linking in keratoconus in Asian eyes: visual, refractive and confocal microscopy outcomes in a prospective randomized controlled trial. Int Ophthalmol. 2015.  
11 – Conselho Federal de Medicina.PROCESSO-CONSULTA CFM nº 1.923/10 – PARECER CFM nº 30/10. Disponível em https://sistemas.cfm.org.br/normas/arquivos/pareceres/BR/2010/30_2010.pdf

---

