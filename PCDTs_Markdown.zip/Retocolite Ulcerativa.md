<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS  Nº  9, DE 12 DE SETEMBRO DE 2024.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Retocolite Ulcerativa.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições, -->
Considerando a necessidade de se atualizarem os parâmetros sobre a retocolite ulcerativa no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 866/2023 e o Relatório de Recomendação n<sup><u>o</u></sup> 869 – dezembro de 2023 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Retocolite Ulcerativa.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da retocolite ulcerativa, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da retocolite ulcerativa.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SCTIE/MS no 22, de 20 de dezembro de 2021, publicada no Diário Oficial da União (DOU) nº 245, de 29 de dezembro de 2021, seção 1, página 172.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
ADRIANO MASSUDA  
CARLOS AUGUSTO GRABOIS GADELHA  
**ANEXO**  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **1. INTRODUÇÃO** -->
A retocolite ulcerativa (RCU) é uma doença inflamatória intestinal crônica caracterizada por episódios recorrentes de inflamação que acomete predominantemente a camada mucosa do cólon<sup>1</sup> . A doença usualmente afeta o reto e também variáveis porções proximais do cólon, em geral de forma contínua, ou seja, sem áreas de mucosa normal entre as porções afetadas<sup>2</sup> .  
Muitos pacientes permanecem em remissão clínica da doença por longos períodos, mas a probabilidade de ausência de recidiva por dois anos é de apenas 20%. As recidivas geralmente ocorrem na mesma região do cólon afetada em outros períodos de agudização<sup>2</sup> . Entretanto, cerca de 20% a 50% dos pacientes pode apresentar extensão proximal da doença ao longo do seguimento<sup>3</sup> .  
A doença pode se iniciar em qualquer idade. O pico de incidência parece ocorrer dos 20 aos 40 anos e muitos estudos mostram um segundo pico de incidência nos idosos<sup>1</sup> . Um estudo transversal realizado na Bahia apontou para um tempo médio de diagnóstico aos 39,4 anos de idade<sup>4</sup> . A maioria dos estudos evidencia discreto predomínio no sexo masculino<sup>5</sup> , embora alguns estudos recentes tenham demonstrado o contrário<sup>4,6–8</sup> .  
A América Latina é considerada uma região de baixa prevalência da doença quando comparada com países como os Estados Unidos, o Reino Unido e a Austrália<sup>1</sup> . Dados populacionais sobre a epidemiologia das doenças inflamatórias intestinais no Brasil são escassos. Estudo nacional de base populacional identificou aumento na incidência de RCU de 5,7 para 6,9 por 100.000 habitantes/ano na última década<sup>9</sup> .  
Sendo assim, o objetivo principal do tratamento é oportunizar a remissão clínica livre do uso de corticoide e, posteriormente, a manutenção da remissão no longo prazo, evitando recidivas. O tratamento preconizado neste Protocolo está dividido em fases de indução da remissão e de manutenção da remissão, e a conduta terapêutica estabelecida em termos de extensão da doença e de gravidade da agudização, em conformidade com os principais consensos mundiais<sup>10,11</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da retocolite ulcerativa.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- K51.0 Enterocolite ulcerativa  
- K51.2 Proctite ulcerativa  
- K51.3 Retossigmoidite ulcerativa  
- K51.5 Colite esquerda  
- K51.8 Outras colites ulcerativas

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **3. DIAGNÓSTICO** -->
O diagnóstico é estabelecido pela história clínica, exame físico, exames laboratoriais, exame endoscópico e achados histopatológicos. Os exames endoscópicos (colonoscopia ou retossigmoidoscopia) são parte fundamental no diagnóstico e para a classificação da doença.  
O sintoma principal da RCU é a diarreia com sangue<sup>12</sup> . Cerca de 90% dos pacientes apresentam hematoquezia (hemorragia retal)<sup>13</sup> . Sintomas associados, como dor abdominal em cólica, tenesmo (sensação de defecação incompleta), urgência evacuatória e exsudato mucopurulento nas fezes, podem acompanhar o quadro. Os casos mais graves são acompanhados de sintomas sistêmicos como febre, anemia e emagrecimento. Os sintomas tendem a variar conforme a extensão da doença, evidenciando-se manifestações locais nos pacientes com proctite, enquanto pacientes com colite extensa apresentam usualmente febre, emagrecimento, perda sanguínea significativa e dor abdominal.  
As manifestações extraintestinais (MEI) ocorrem entre 10% a 35% dos pacientes e podem cursar com acometimento articular, cutâneo, hepatobiliar, oftalmológico e hematológico e influenciar no metabolismo ósseo<sup>13-16</sup> . Elas podem ou não estar relacionadas com a atividade inflamatória intestinal e em alguns casos apresentam sintomas mais graves do que os intestinais<sup>16</sup> . Aqueles doentes com diagnóstico de colangite esclerosante primária e RCU apresentam comportamento diferente dos demais, com maior risco de doença intestinal mais extensa e de câncer colorretal<sup>17</sup> .  
A doença pode ser estadiada, com base na Classificação de Montreal e conforme maior extensão de acometimento macroscópico à colonoscopia, como tendo: 1) proctite ou retite: com doença limitada ao reto; 2) colite esquerda: quando afeta o cólon distalmente à flexura esplênica; e 3) pancolite: acometimento de porções proximais à flexura esplênica<sup>3</sup> . A gravidade da doença é mais bem avaliada pela intensidade dos sintomas e pode ser classificada pelos critérios estabelecidos por Truelove e Witts<sup>18</sup> , úteis na definição terapêutica. As agudizações são classificadas em três categorias:  
– Leve: menos de 3 evacuações por dia, com ou sem sangue, sem comprometimento sistêmico e com velocidade de sedimentação globular (VSG) normal;  
– Moderada: mais de 4 evacuações por dia com mínimo comprometimento sistêmico; e  
– Grave: mais de 6 evacuações por dia com sangue e com evidência de comprometimentos sistêmicos, tais como febre, taquicardia, anemia e VSG acima de 30. Casos com suspeita de megacólon tóxico também devem ser considerados graves.  
O achado colonoscópico mais típico é o acometimento da mucosa desde a margem anal, estendendo-se proximalmente de uma forma contínua e simétrica, com clara demarcação entre mucosas inflamada e normal<sup>13</sup> . Inicialmente a mucosa inflamada apresenta-se com diminuição ou perda da trama vascular submucosa mais eritema e edema. Com a progressão da doença, a mucosa torna-se granular, friável, recoberta por exsudato mucopurulento e, nos casos mais graves, visualizam-se úlceras. Pacientes com RCU de longa duração podem apresentar perda das haustrações, pseudopólipos inflamatórios e encurtamento do cólon<sup>1</sup> . Há ainda descrição de acometimento periapendicular em alguns pacientes com doença distal. Esse achado não parece influenciar no índice de remissão, de recidivas ou de progressão proximal<sup>19,20</sup> .  
A avaliação histopatológica no diagnóstico da RCU baseia-se no achado de distorção arquitetural difusa de criptas e infiltrado inflamatório transmucoso com plasmocitose basal, eventualmente associado a componente de atividade evidenciado por criptites e abscessos crípticos. A depleção de mucina é menos específica, mas auxilia no diagnóstico<sup>21</sup> . Mesmo na presença de achados típicos, o aspecto histopatológico deve ser avaliado em conjunto com os demais aspectos com vistas ao diagnóstico correto<sup>1</sup> .  
A dosagem sanguínea de proteína C reativa (PCR) e a medida da velocidade de hemossedimentação (VHS) ou velocidade de sedimentação globular (VSG) auxiliam na avaliação diagnóstica, mas podem não estar alteradas na doença distal (retite)<sup>3</sup> .

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes com diagnóstico comprovado por exame endoscópico (colonoscopia ou retossigmoidoscopia) e alterações histopatológicas sugestivas de RCU, em uma das situações abaixo:  
- Com doença intestinal ativa (independentemente da extensão) **ou**  
- Em remissão clínica (pacientes com diagnóstico prévio e em tratamento, mesmo na ausência de sintomas ou alterações  
- ao exame endoscópico atual).

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes com outras doenças inflamatórias intestinais. Intolerância, hipersensibilidade ou contraindicação serão os critérios de exclusão ao uso do respectivo medicamento neste Protocolo.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6. TRATAMENTO** -->
A estratégia de tratamento da RCU é principalmente baseada na gravidade, distribuição (proctite, colite esquerda ou pancolite) e padrão da doença, que inclui frequência de recaída, curso da doença, resposta a medicamentos anteriores, efeitos colaterais de medicamentos e manifestações extraintestinais<sup>10</sup> .  
O tratamento da RCU consiste em aminossalicilatos orais e por via retal, corticoides, imunossupressores, medicamentos biológicos e inibidores da Janus Kinase (JAK), e é feito de maneira a tratar a fase aguda e, após, manter a remissão clínica, sendo o seu maior objetivo atingir a remissão livre de corticoide<sup>2</sup> . Sabe-se que aqueles pacientes que atingem a cicatrização da mucosa (CM), definida na maioria dos estudos como sub-escore endoscópico de Mayo<sup>35</sup> igual a 0 ou 1 (mucosa normal ou eritema, redução da trama vascular, friabilidade leve), apresentam melhores desfechos no longo prazo, como menor risco de colectomia e melhor evolução da doença, conforme achados de estudos de coorte e meta-análise de estudos prospectivos<sup>36–40</sup> .  
O tratamento das agudizações leves a moderadas é feito basicamente com aminossalicilatos, orais e tópicos, e com corticoides. Entre os aminossalicilatos (sulfassalazina e mesalazinas), não há diferença estatística quanto à eficácia nesse grupo de pacientes. A terapia tópica, com supositórios de mesalazina para a proctite e com enema de mesalazina para a colite esquerda, foi reavaliada em meta-análises que demonstraram que a terapia tópica é superior ao placebo na doença distal, tanto na indução quanto na manutenção<sup>41,42</sup> . Nos casos de pacientes com colite esquerda, o tratamento tópico associado ao por via oral (VO) é superior a qualquer um deles isolados<sup>10,43</sup> . Em análise entre os efeitos desejáveis e indesejáveis das diferentes apresentações de mesalazina via oral (comprimidos e sachê), não houve diferenças significativas entre a eficácia, segurança e desfechos relatados por pacientes no tratamento da RCU leve a moderada. No que se refere à aceitação do tratamento pelo paciente, a frequência de doses considerada como ótima foi maior entre os participantes com uso de sachê duas vezes ao dia, quando comparada a sachês e comprimidos ingeridos em quatro vezes ao dia. Também houve diferenças quanto à dificuldade no uso diário de medicamento, dificuldade de ingestão devido ao tamanho dos comprimidos e percepção do paciente de que são muitos os comprimidos a ingerir, com melhores resultados para o tratamento com mesalazina em sachê do que para comprimidos. Por outro lado, isto não se refletiu nos desfechos de percepção do paciente em relação ao efeito do tratamento e na adesão ao tratamento, ambos sem diferenças significativas entre sachês e comprimidos. Ademais, destaca-se o alto relato de inconvenientes na ingestão do medicamento para essas duas formas de apresentação de mesalazina. Em relação à segurança do medicamento, o tratamento da RCU com mesalazina oral foi bem tolerado. Não foram relatadas diferenças clínicas ou estatisticamente significativas entre as apresentações orais sachês e comprimidos quanto aos eventos adversos identificados, em muitos dos casos, esses incidentes foram associados ao próprio quadro clínico da doença. Conclui-se que a mesalazina em sachê é tão eficaz quanto sua apresentação em comprimido, porém, mais cômoda para o paciente. Ainda, o tratamento com mesalazina parece ser mais vantajoso se  
administrado em dose única diária em sachê, ou então com dose diária fracionada em duas administrações, ao invés de quatro, nas apresentações de sachê ou comprimido.  
Os pacientes refratários aos aminossalicilatos ou aqueles com doença moderada podem, alternativamente, usar prednisona<sup>10,44</sup> . É preconizado o tratamento empírico de Strongyloides antes do início do tratamento com prednisona. Os pacientes que não respondem completamente, que não conseguem reduzir a dose da prednisona sem recorrência da doença ou que necessitam de mais de três cursos de prednisona no ano, caracterizando-se como resistentes ou dependentes de corticoide, podem beneficiar-se do uso de azatioprina<sup>10</sup> .  
Pacientes com doença ativa classificada como moderada a grave devem ser tratados inicialmente com aminossalicilato e corticoide. Aqueles que não respondem completamente ao corticoide ou que não conseguem reduzir a dose da prednisona sem recorrência da doença podem beneficiar-se do uso de azatioprina<sup>10</sup> . Os pacientes que apresentam falha terapêutica ao uso de azatioprina, sem critério para colite aguda grave e com indicação de internação devem ser tratados com infliximabe.  
Aqueles pacientes com doença grave com sinais de comprometimento sistêmico (febre, taquicardia, anemia) devem ser tratados em ambiente hospitalar por equipe clínico-cirúrgica treinada e devem utilizar corticoide intravenoso inicialmente<sup>1,18,45</sup> . Os que tiverem piora e não melhorarem em poucos dias devem ser considerados para colectomia de urgência ou para o uso de ciclosporina intravenosa em serviço com experiência no seu emprego. Nos pacientes com colite aguda grave em uso de azatioprina ou com insuficiência renal, pode-se utilizar indução com infliximabe<sup>45–47</sup> .  
Pacientes com um episódio único de proctite não necessitam de terapia de manutenção. Nos demais casos, após a melhora da fase aguda, deve ser iniciada a prevenção de recorrências da doença. Os pacientes com proctite e colite esquerda podem ser mantidos em remissão com supositórios de mesalazina e enema de mesalazina, respectivamente, associados ou não à mesalazina por via oral<sup>48</sup> .  
Os pacientes que atingiram remissão com aminossalicilato ou terapia com imunobiológico devem passar para a terapia de manutenção com o mesmo medicamento utilizados na indução.  
Não existem evidências conclusivas de que o uso de adesivos de nicotina possa ser útil no tratamento desta doença<sup>49</sup> . Também não há evidência para o tratamento da RCU com probiótico<sup>50</sup> , metotrexato<sup>51,52</sup> , heparina não fracionada e óleo de peixe (Ômega-3)<sup>53</sup> .

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.1.1. Proctite (retite)** -->
Pacientes com proctite leve a moderada devem ser tratados com um supositório de mesalazina 1 g por dia durante a fase aguda<sup>10,41</sup> . O tratamento tópico nesses pacientes deve ser priorizado, pois garante maiores concentrações locais do medicamento e menos eventos adversos.  
A mesalazina tópica é superior ao placebo tanto para induzir remissão clínica quanto endoscópica<sup>40</sup> . Nos pacientes com doença moderada, pode ser necessário associar-se a terapia por via oral com sulfassalazina ou mesalazina, conforme utilizado para colite esquerda, como descrito no item Colite esquerda leve a moderada.  
Os pacientes intolerantes, que não aderem à terapia por via retal ou refratários ao tratamento com aminossalicilatos, podem, alternativamente, ser tratados como preconizado para a pancolite. Obtida a remissão dos sintomas, os pacientes deverão ser orientados de acordo com o item Manutenção da remissão clínica.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.1.2. Colite esquerda leve a moderada** -->
Pacientes com colite esquerda devem ser tratados com enemas de mesalazina de 1 g/dia associados à mesalazina por via oral na dose de 2,4 a 4,8 g ao dia ou sulfassalazina na dose 2 a 4 g ao dia. O tratamento tópico associado ao por via oral é superior  
a qualquer um deles isolados nesse grupo de pacientes<sup>10,43</sup> . Casos moderados podem se beneficiar das doses diárias maiores do medicamento pela via oral (mesalazina de 4 a 4,8 g ou sulfassalazina 4 g)<sup>54</sup> .  
Enemas de corticoide também são superiores ao placebo na doença leve a moderada, embora sejam menos eficazes que a terapia tópica com mesalazina<sup>55</sup> . Os pacientes intolerantes, que não aderem à terapia por via retal ou refratários ao tratamento com aminossalicilatos, podem, alternativamente, ser tratados como preconizado para a pancolite.  
Nos casos moderados, conforme a classificação de Truelove e Witts<sup>18</sup> , deve-se utilizar curso de prednisona, com redução gradual da dose até sua suspensão (ver em Esquemas de administração).  
Obtida a remissão dos sintomas, os pacientes deverão ser orientados de acordo com o item Manutenção da remissão clínica.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.1.3. Pancolite leve a moderada** -->
Inicia-se com sulfassalazina ou mesalazina por via oral, conforme o respectivo esquema de administração (ver em Esquemas de administração). Tendo em vista não haver diferença estatística quanto à eficácia entre sulfassalazina e mesalazina nesse grupo de paciente, qualquer destes dois é escolha válida para o medicamento inicial.  
Meta-análises dos ensaios clínicos que usaram mesalazina na RCU em atividade mostraram igual eficácia da sulfassalazina e da mesalazina e superioridade de ambas em relação ao placebo (ver a Tabela A do Apêndice 1) na indução de remissão clínica e endoscópica<sup>54,55</sup> . Uma revisão sistemática do grupo Cochrane, de 2016, identificou superioridade da sulfassalazina sobre a mesalazina na análise global da manutenção da remissão, entretanto, quando analisados estudos com desfecho de 12 meses ou excluídos estudos com olsalazina (indisponível no Brasil), não se evidenciou diferença estatística entre aqueles dois medicamentos<sup>56</sup> . Consideram-se, assim, ambos os medicamentos igualmente eficazes, porém dando-se preferência à sulfassalazina em função do seu baixo custo, mas sem desconsiderar o risco de infertilidade masculina associada a esse fármaco, inexistente com a mesalazina. Os pacientes que desenvolverem eventos adversos ao uso de sulfassalazina, como reações alérgicas, discrasias sanguíneas, hepatite, pancreatite, dor abdominal de forte intensidade ou algum outro evento adverso grave, devem utilizar mesalazina.  
Após melhora, as doses devem ser reduzidas: sulfassalazina, reduzir para 1 g de 12 em 12 h; mesalazina, reduzir para 2 g ou 2,4 g ao dia<sup>11,20</sup> . Em caso de falha de indução com sulfassalazina ou mesalazina, não há benefício da troca entre elas. Nestes casos, preconiza-se o uso de corticoide<sup>11</sup> .  
Nos casos moderados, alternativamente, pode ser usada prednisona na dose de 40 a 60 mg (0,75 a 1 mg/kg/dia não excedendo a dose máxima diária de 60 mg), por via oral, com redução gradual da dose (ver item Esquemas de administração)<sup>44,45,57</sup> . Em casos que responderem apenas parcialmente à prednisona ou em que não se consiga reduzir a dose do corticoide sem recaídas da doença, deve-se iniciar o uso de azatioprina 2 a 2,5 mg/kg/dia<sup>58–60</sup> . Casos refratários a este medicamento devem ser tratados como doença grave.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.1.4. Retocolite moderada a grave** -->
Os pacientes com quadro moderado a grave devem ser tratados inicialmente com corticoide por via oral e aminossalicilato. Deve-se iniciar imunossupressor naqueles com dependência de corticoide.  
Naqueles casos de falha do imunossupressor, caracterizada por dependência de corticoide apesar de dose adequada de azatioprina por um tempo mínimo de 12 semanas, deve ser considerado o uso de terapia imunobiológica com anti-TNF alfa (infliximabe) ou anti-integrina (vedolizumabe) ou inibidores da JAK (tofacitinibe).  
A Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) recomendou a incorporação do infliximabe e do vedolizumabe, limitado ao custo do tratamento com infliximabe<sup>34,61</sup> , e do tofacitinibe para tratamento da colite ulcerativa moderada a grave<sup>62</sup> .  
O infliximabe (IFX), um anti-TNF alfa, mostrou-se superior ao placebo na indução de remissão nos casos de RCU moderada a grave, refratários ou intolerantes aos demais medicamentos (ver a Tabela C do Apêndice 1), com um número necessário para tratar (NNT) para alcançar uma remissão de 5<sup>38,63</sup> e com redução no risco de colectomia<sup>64</sup> e hospitalização<sup>65,66</sup> . Um ensaio clínico randomizado (ECR) demonstrou maior taxa de remissão livre de corticoide na 16ª semana com terapia combinada de infliximabe com azatioprina, em paciente sem uso prévio de terapia biológica ou imunossupressor, quando comparada ao infliximabe ou azatioprina isolados (39,7%, 22,1%, 22,7%, respectivamente, p=0,02)<sup>67</sup> . Uma meta-análise subsequente sustenta esses melhores resultados com a associação de infliximabe com imunossupressor, quando comparado com terapia somente com infliximabe<sup>68</sup> . Um estudo observacional prospectivo e não cegado, com pacientes com RCU moderada a grave dependentes de corticoide, demonstrou taxa de remissão clínica sustentada sem corticoide em 6 meses e 12 meses com uso infliximabe de 53,1% e 46,8%, respectivamente<sup>69</sup> .  
O vedolizumabe (VDZ) é um imunobiológico anti-integrina α₄ β₇. Uma revisão sistemática do grupo Cochrane, de 2014, identificou 4 ECR controlados por placebo que avaliaram a eficácia de VDZ para indução e manutenção de remissão em RCU: 3 pequenos ECR de curta duração e 1 grande ECR com 52 semanas de seguimento<sup>70,71</sup> . Não existem estudos com comparação direta entre os biológicos em RCU moderada a grave. Meta-análises em rede que analisaram ECR com infliximabe, adalimumabe e vedolizumabe contra placebo identificaram que o infliximabe foi superior ao adalimumabe em todos os desfechos analisados na fase de indução, em pacientes não tratados com anti-TNF<sup>71-73</sup> . Segundo meta-análises em rede com comparações indiretas, o infliximabe e o vedolizumabe, para o tratamento de indução, se mostraram superiores ao adalimumabe na obtenção de resposta e remissão clínica<sup>74,75</sup> . O ensaio clínico GEMINI 1 verificou, por análise de subgrupo, que o VDZ foi mais eficaz que placebo na indução de resposta e manutenção de remissão clínica em pacientes com história de falha a anti-TNF<sup>76</sup> .  
De acordo com a recomendação da Conitec, de outubro de 2019<sup>34</sup> , há uma população que não responde ao tratamento sem agente imunobiológico e que poderia se beneficiar do uso de um deles. Os medicamentos infliximabe (IFX) e vedolizumabe (VDZ) se apresentaram como candidatos potenciais para esta lacuna, desde que atendidos os requisitos de eficácia, segurança, custo-efetividade e impacto orçamentário para o SUS. Em relação à eficácia e segurança, o Plenário da Conitec considerou válidas as evidências indiretas que mostraram superioridade de infliximabe e vedolizumabe frente aos outros biológicos, nos desfechos de saúde avaliados<sup>34</sup> .  
Assim, os medicamentos infliximabe e vedolizumabe estão indicados para o tratamento da RCU moderada a grave de paciente que apresentarem uma resposta inadequada, perda de resposta ou toxicidade (intolerância, hipersensibilidade ou outro evento adverso) aos medicamentos sintéticos convencionais. O vedolizumabe não pode ser usado para tratamento de “colite aguda grave”, pois não existe ensaio clínico que tenha avaliado a sua segurança e eficácia no tratamento da colite aguda grave.  
O citrato de tofacitinibe é um inibidor seletivo da família das JAK (Janus Kinase). Age bloqueando a sinalização de citocinas, que estão diretamente envolvidas na patogênese da doença inflamatória intestinal. Este medicamento foi avaliado pela Conitec em junho de 2021, e foi incorporado ao SUS<sup>62,77</sup> para o “tratamento de retocolite ulcerativa ativa moderada a grave em pacientes adultos com resposta inadequada, perda de resposta ou intolerantes ao tratamento prévio com corticosteroides, azatioprina e 6-mercaptopurina”. O tofacitinibe é utilizado por via oral e não necessita de refrigeração para armazenamento<sup>26</sup> .  
Foram consideradas na avaliação as evidências sistematizadas comparando a eficácia e segurança do citrato de tofacitinibe em relação ao infliximabe, vedolizumabe e placebo. Uma meta-análise em rede de Singh e colaboradores<sup>75</sup> em pacientes sem uso prévio de anti-TNFs, o tofacitinibe mostrou-se significativamente superior ao placebo, apresentando uma chance duas vezes maior de indução da remissão clínica. Na meta-análise em rede de Trigo-Vicente e colaboradores (2018)<sup>78</sup> , o tofacitinibe não diferiu estatisticamente do infliximabe e vedolizumabe na fase de indução para remissão clínica. Na comparação indireta, tanto o tofacitinibe quanto os infliximabe e vedolizumabe apresentaram resultados significativamente superiores ao placebo. Para o desfecho cura da mucosa, o tofacitinibe também se mostrou superior ao placebo nas duas meta-análises de Singh e colaboradores (2018)<sup>75</sup> , em pacientes sem uso prévio de anti-TNFs, apresentando uma chance duas vezes maior de indução da melhora  
endoscópica. Com base na comparação indireta, observou-se que o risco de infecção com o citrato de tofacitinibe foi significativamente maior apenas na comparação com placebo, não apresentando diferenças significativas em relação ao infliximabe e vedolizumabe. Assim, o citrato de tofacitinibe está indicado para o tratamento de RCU ativa moderada a grave em pacientes adultos com resposta insuficiente, perda de resposta ou toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ao tratamento prévio com medicamentos sintéticos ou agente biológico (infliximabe, vedolizumabe)<sup>62</sup> .

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.1.5. Colite aguda grave** -->
Os pacientes com doença moderada a grave que não responderem às medidas preconizadas anteriormente descritas, da mesma forma que os pacientes com doença grave com comprometimento sistêmico, devem ser tratados em ambiente hospitalar com hidrocortisona 100 mg por via intravenosa (IV) de 6 em 6 horas por 7 a 10 dias. Esses pacientes devem receber hidratação intravenosa, ter pesquisa fecal de toxina para Clostridium difficile, evitar o uso de narcótico ou de medicamento com efeito anticolinérgico e receber profilaxia para tromboembolismo venoso. Retossigmoidoscopia, sem preparo de cólon, pode ser considerada em casos selecionados para confirmar o diagnóstico e descartar, pela análise histopatológica, colite por citomegalovírus<sup>10</sup> .  
Preconiza-se a avaliação precoce e acompanhamento por equipe cirúrgica pelo risco de necessidade de colectomia em qualquer momento da evolução.  
Havendo melhora, a hidrocortisona deve ser substituída pela prednisona, sendo então seguido o tratamento preconizado para pancolite moderada a grave.  
A resposta à terapia com corticoide intravenoso deve ser avaliada, sobretudo no terceiro dia, conforme critério de Oxford<sup>79</sup> . Pacientes que no terceiro dia apresentam mais de 8 evacuações ao dia e PCR > 45 mg/dL apresentam 85% de risco de evoluírem para a necessidade de colectomia. Radiografia simples de abdômen deve ser realizada no acompanhamento para identificar dilatação do cólon > 5,5 cm, que também se associa a maior chance de colectomia<sup>10</sup> .  
Na ausência de resposta ao corticoide, em serviço com experiência nesse uso, preconiza-se o uso de ciclosporina IV, como primeira escolha. A dose preconizada é 2 mg/kg/dia em infusão contínua durante 7 dias. Após resposta clínica, inicia-se ciclosporina VO, 5 mg/kg divididos em duas administrações ao dia e mantidos por 12 semanas (ver em 7.4 Esquemas de administração)<sup>80</sup> . Deve-se fazer transição para o uso da azatioprina 2 a 2,5 mg/kg, com redução gradual do corticoide conforme descrito previamente. Caso o paciente fique com tripla imunossupressão (corticoide + ciclosporina + azatioprina), deve ser feita a profilaxia para Pneumocitis jiroveci com sulfametoxazol + trimetoprina 800 mg + 160 mg, 3 vezes por semana<sup>80</sup> .  
A ciclosporina é eficaz para atingir a melhora clínica em 43% dos pacientes com colite aguda grave refratária a corticoide, com taxa de colectomia de 26% e 34%, em 3 e 12 meses, respectivamente, conforme meta-análise recentes, não havendo diferença estatística quando comparada com infliximabe para esses desfechos<sup>81,82</sup> . Esta meta-análise incluiu recente ensaio clínico, desenhado com objetivo de comparar eficácia da ciclosporina com infliximabe<sup>81,82</sup> . A mesma meta-análise também avaliou estudos não randomizados que, quando avaliados conjuntamente, apresentaram resultado favorável ao infliximabe quanto à resposta clínica e colectomia em 12 meses 81. Um ensaio clínico mais recente, não incluído na meta-análise, também concluiu pela não inferioridade de infliximabe versus ciclosporina no tratamento da colite aguda grave<sup>80</sup> . Além disso, um estudo de vida real, publicado posteriormente a esta meta-análise, incluindo 740 pacientes, não identificou diferença estatística quando comparado a ciclosporina com o infliximabe. Identificou-se, ainda, mais ocorrência de eventos adversos graves no grupo do infliximabe (IFX 26% vs ciclosporina 15,4%)<sup>83</sup> . Portanto, a ciclosporina e o infliximabe são considerados opções com eficácia semelhante para o tratamento da colite aguda grave em pacientes refratários a corticoide intravenoso<sup>81,82</sup> .  
Pacientes que já vinham em uso de azatioprina durante o episódio de colite aguda grave tendem a apresentar pior prognóstico com a ciclosporina<sup>10</sup> . Nesse grupo e nos pacientes com perda de função renal (pelo risco de toxicidade pela ciclosporina), preconiza-se o uso de infliximabe nas mesmas doses usuais para a indução da remissão clínica. Inexiste evidência suficiente para se indicar o uso de terapia sequencial (uso de infliximabe após falha da ciclosporina ou de ciclosporina após falha do infliximabe). Nesses casos, a colectomia deve ser indicada<sup>10,84,85</sup> .  
Preconiza-se a avaliação precoce e acompanhamento por equipe cirúrgica pelo risco de necessidade de colectomia em qualquer momento da evolução. A colectomia deve ser considerada como alternativa em todos os pacientes, sendo avaliada caso a caso. O procedimento cirúrgico mais indicado nos casos graves é a colectomia subtotal com confecção de ileostomia e programação de reconstrução de trânsito intestinal (com ou sem bolsa ileal) após a recuperação do quadro agudo.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.2. Manutenção da remissão clínica** -->
Pacientes que tenham tido um episódio único de proctite não necessitam de terapia de manutenção. Os demais casos devem manter a terapia por via oral, com o medicamento utilizado na indução, sulfassalazina ou mesalazina<sup>1,45</sup> .  
Para pacientes que tiverem mais de duas agudizações em um ano ou que não consigam reduzir a dose de corticoide sem nova recidiva pode-se iniciar a azatioprina 2,0 a 2,5 mg/kg/dia.  
Em pacientes com proctite, alternativamente aos aminossalicilatos via oral, pode ser feita terapia de manutenção com um supositório de mesalazina 250 mg a 1 g, 3 vezes por semana<sup>45,48,86,87</sup> . Pacientes que tiverem agudização em uso de supositórios 3 vezes por semana devem passar a usá-los diariamente<sup>87</sup> .  
Pacientes que receberam indução com ciclosporina intravenosa devem fazer uso de período de transição de 12 semanas de ciclosporina VO e manutenção em longo prazo com azatioprina, conforme descrito em Colite aguda grave<sup>10,80</sup> . Nos casos em que a remissão clínica foi alcançada com a azatioprina (com ou sem uso de corticoide na fase de indução), seu uso deve ser mantido por tempo indeterminado.  
Há poucos dados na literatura sobre suspensão de imunossupressor em paciente com retocolite em remissão. Uma revisão sistemática recente que avaliou risco de recorrência da doença após suspensão de imunossupressor identificou apenas um ECR e 7 estudos de coorte.  
No ECR, que incluiu 79 pacientes, houve manutenção da remissão após 1 ano de suspensão em 36% dos pacientes contra 59% do grupo que manteve o imunossupressor<sup>88</sup> . Estudos de coorte demonstraram chance de reativação da doença em 5 anos após a suspensão do medicamento, variando de 43% a 65%<sup>89</sup> . Baseando-se nestes dados, não é possível preconizar a suspensão programada dos imunossupressores nos pacientes em remissão. Ela deve ser individualizada, levando-se em consideração os riscos do uso prolongado da azatioprina. Contudo, não há definição não arbitrária do que seria uso prolongado nem de qual é a duração ótima do tratamento de manutenção com azatioprina<sup>89,90</sup> . Sugerem-se os seguintes fatores favoráveis à tentativa de suspensão: doença menos extensa, ausência de reativação da doença ou necessidade de outras terapias durante a imunossupressão, remissão endoscópica, homens jovens (pelo risco de linfoma hepatoesplênico) e idosos. Esta recomendação estende-se também ao uso da azatioprina em combinação com o infliximabe.  
Pacientes que receberam indução com infliximabe ou vedolizumabe devem manter-se sob as doses de 5 mg/kg a cada 8 semanas e 300 mg a cada 8 semanas, respectivamente. Esses medicamentos devem ser suspensos em 3 meses, se não houver resposta clínica, caracterizando-se como falha primária. O tratamento deve ser reavaliado a cada 12 meses com vistas a se decidir sobre a necessidade de sua manutenção. Estudo de coorte com média de 41 meses de seguimento com infliximabe identificou 64% de manutenção de resposta clínica sustentada, entre os pacientes que responderam à indução<sup>91</sup> .  
Estudos que avaliaram taxas de reativação da doença após suspensão de anti-TNF identificaram recorrência após 1 ano de 14% a 41,8% e, após 2 anos, de 25% a 47,1%<sup>89,92</sup> . Nos estudos em que era necessária a cicatrização da mucosa antes da suspensão, houve risco de recorrência menor, 17% a 25% em um ano. Apesar do índice elevado de reativação, as taxas de sucesso da reintrodução da terapia biológica após a suspensão variam de 67% a 100%<sup>89</sup> .  
Pacientes que receberam indução com tofacitinibe (10 mg, duas vezes por dia por, pelo menos, 8 semanas) devem manterse sob as doses de 5 mg administradas oralmente duas vezes ao dia para manutenção do tratamento. Esse medicamento deve ser suspenso na semana 16, se não houver resposta clínica, caracterizando-se como falha primária. O tratamento deve ser reavaliado a cada 12 meses com vistas a se decidir sobre a necessidade de sua manutenção<sup>26,62</sup> . No tratamento de manutenção, pacientes que utilizaram tofacitinibe demonstraram maior probabilidade de apresentar remissão clínica e melhora endoscópica, comparado a infliximabe e vedolizumabe, mas não diferiu significativamente de vedolizumabe<sup>62</sup> .

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.3. Medicamentos** -->
- Ácido fólico: comprimidos de 5 mg.  
- Azatioprina: comprimidos de 50 mg.  
- Ciclosporina: cápsulas de 10, 25, 50 e 100 mg; solução oral com 100 mg/mL; ampolas com 50 e 250 mg.  
- Hidrcortisona: pó para solução injetável de 100 e 500 mg.  
- Infliximabe: pó para solução injetável com 100 mg.  
- Mesalazina: comprimidos de 400, 500 e 800 mg; sachê contendo grânulos de liberação prolongada de 2 g; supositórios de 250, 500 e 1.000 mg; enema de 1 g;  
- Prednisona: comprimidos de 5 e 20 mg.  
- Sulfassalazina: comprimidos de 500 mg.  
- Tofacitinibe: comprimidos de 5 mg  
- Vedolizumabe: pó para solução injetável com 300 mg.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.4. Esquemas de administração** -->
- Azatioprina: 2,0 a 2,5 mg/kg/dia. Iniciar com dose de 50 mg até reavaliação com exames. Em caso de ausência de  
- eventos adversos, aumentar para a dose alvo. A dose total pode ser administrar uma vez ao dia ou em doses divididas.  
- Ciclosporina: 2 mg/kg/dia em infusão contínua durante 7 dias. Após resposta clínica, inicia-se a ciclosporina 5 mg/kg/dia por via oral dividida em duas administrações ao dia e mantida por 12 semanas.  
- Hidrocortisona: Administrar 100 mg intravenoso de 6/6h ou de 8/8h.  
- Infliximabe: Infusão intravenosa de 5 mg/kg, administrada por um período mínimo de 2 horas, seguida por doses de infusões adicionais de 5 mg/kg nas semanas 2 e 6 após a primeira infusão e, depois, a cada 8 semanas. Para pacientes adultos que apresentarem resposta incompleta ou perda de resposta, deve-se considerar o ajuste da dose para até 10 mg/kg.  
- Mesalazina (via oral): comprimidos: 2 g a 4,8 g ao dia, divididas em 2 ou 3 vezes ao dia (de 12/12h ou de 8/8h).  
- Mesalazina (via oral) sachê: tratamento agudo: dose individual de até 4g por dia, a ser tomada uma vez ao dia (2 sachês de 2g) ao mesmo tempo pela manhã; ou em doses divididas, duas vezes ao dia (1 sachê de 2g), tomados pela manhã e à noite. Tratamento de manutenção: dose recomendada de 2g uma vez ao dia. A dose máxima diária é de 4 g/dia. Os grânulos não devem ser mastigados. O conteúdo do sachê deve ser esvaziado diretamente na língua e engolido com água e não deve ser misturado (suspenso) em água ou outros líquidos. Após a abertura do sachê, a administração deve ser imediata.  
- Mesalazina supositório (250, 500 ou 1.000 mg): Aplicar 1 supositório à noite, ao deitar. Pode-se utilizar 2 vezes ao dia  
- em casos selecionados.  
- Prednisona: Tomar preferencialmente pela manhã. Dose inicial de 40 a 60 mg (0,75 a 1 mg/kg/dia não excedendo 60 mg/dia), por via oral, sendo que, após a melhora, esta dose deve ser reduzida 5 a 10 mg por semana até 20 mg por dia, reduzindo-  
se então 5 mg por semana até 5 mg por dia e, após, reduzindo-se 2,5 mg por semana até a retirada completa. Evitar o uso crônico, independentemente da dose.  
- Sulfassalazina: 2 g a 4 g ao dia, divididas em 2 administrações ao dia (de 12/12h). Para reduzir os eventos adversos, pode-se iniciar com dose de 1 g ao dia, com aumento progressivo até a dose alvo. Se aparecerem sintomas gastrointestinais, reduzir em 50% a dose e, então, aumentar progressivamente até a dose alvo. Pacientes em uso de sulfassalazina devem repor ácido fólico 5 mg, 3 vezes por semana.  
- Tofacitinibe: A dose preconizada para pacientes adultos é de 10 mg via oral duas vezes por dia para indução por, pelo menos, 8 semanas e 5 mg administradas duas vezes ao dia para manutenção. Para pacientes que não alcançam benefício terapêutico adequado até a semana 8, a dose de indução de 10 mg duas vezes ao dia pode ser prolongada por mais 8 semanas (16 semanas no total), seguidas por 5 mg duas vezes ao dia para manutenção. Suspender a terapia de indução para tofacitinibe em pacientes que não apresentarem evidência de benefício terapêutico na semana 16. Os pacientes que falharam em manter o benefício terapêutico com tofacitinibe 5 mg duas vezes ao dia podem se beneficiar de um aumento para 10 mg de tofacitinibe administrado duas vezes ao dia. O uso de 10 mg duas vezes ao dia além da indução, deve ser limitado àqueles com perda de resposta e usado pelo menor tempo, com uma consideração cuidadosa dos benefícios e riscos para o paciente. Em geral, usar a menor dose efetiva para manter o benefício terapêutico.  
- Vedolizumabe: 300 mg, administrado por infusão intravenosa nas semanas 0, 2 e 6 e, depois, a cada 8 semanas. Em pacientes adultos que apresentarem redução na resposta, pode-se considerar aumento na frequência do tratamento para 300 mg de vedolizumabe a cada 4 semanas.  
O vedolizumabe e o infliximabe são contraindicados em caso de hipersensibilidade à substância ativa ou a qualquer um dos excipientes e para pacientes com infecções graves, tais como tuberculose ativa ou latente, septicemia, citomegalovirose, listeriose ou infecção oportunista, como leucoencefalopatia multifocal progressiva (LMP).  
O tofacitinibe é contraindicado em caso de hipersensibilidade conhecida ao medicamento, classe terapêutica ou componente do produto; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas. É preconizada avaliação dos pacientes quanto a fatores de risco de tromboembolismo venoso antes do início do tratamento e periodicamente durante o tratamento. O tofacitinibe deve ser usado com cautela em pacientes nos quais os fatores de risco são identificados.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.5.1 Pacientes pediátricos** -->
Deve-se evitar o uso prolongado de corticoides, devendo-se sempre tentar o seu emprego em dias alternados para minimizar o retardo de crescimento induzido por esses medicamentos. Levando-se em conta essas ressalvas e o ajuste das doses pelo peso, o tratamento deve seguir os mesmos princípios do tratamento dos adultos. As doses máximas são as mesmas para adultos em cada situação clínica<sup>22</sup> :  
- Azatioprina: 2-2,5 mg/kg por dia, dose única diária;  
- Ciclosporina: 4-6 mg/dia, infusão contínua ou em 2 administrações diárias;  
- Infliximabe: 5 mg/kg, indução nas semanas 0, 2 e 6 e manutenção a cada 8 semanas.  
- Mesalazina: 30-50 mg/kg por dia, divididas em 2 a 3 administrações;  
- Prednisona: 1-2 mg/kg por dia (dose inicial), divididas em 1 ou 2 administrações;  
- Sulfassalazina: 50-75 mg/kg por dia, divididas em 2 a 4 administrações;  
O uso de infliximabe na população pediátrica foi testado em estudo clínico randomizado (ECR) e é sugerido como  
primeira escolha para pacientes com doença refratária a corticoide e sem resposta à azatioprina<sup>23,24</sup> . O infliximabe é aprovado no Brasil pela Agência Nacional de Vigilância Sanitária (ANVISA) para uso a partir dos 6 anos de idade.  
Por sua vez, conforme consta em bula, a segurança e a eficácia do vedolizumabe<sup>25</sup> e do tofacitinibe<sup>26</sup> não foram estabelecidas em pacientes com idades de 0 a 17 anos. Logo, o infliximabe não é preconizado para pacientes menores de 6 anos e o vedolizumabe e o tofacitinibe não são preconizados para menores de 18 anos.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.5.2 Pacientes grávidas e nutrizes** -->
A sulfassalazina interfere com o metabolismo normal do ácido fólico, que deve ser suplementado no período préconcepção. A taxa de malformações congênitas com seu uso é quase igual à da população em geral<sup>27,28</sup> . É segura durante os dois primeiros trimestres da gestação e na amamentação. No último trimestre, seu uso pode aumentar o risco de _kernicterus_<sup>29</sup> .  
A mesalazina é considerada segura durante a gestação<sup>28–30</sup> . A troca de sulfassalazina por mesalazina pode ser uma alternativa em pacientes que desejam engravidar. Tanto a sulfassalazina quanto a mesalazina possuem baixo risco durante a amamentação<sup>28</sup> .  
A ciclosporina é segura na gravidez, conforme descrito em meta-análise que incluiu 410 gestantes<sup>28,31</sup> . Entretanto, seu uso não é recomendado durante a amamentação, pois, em dose terapêutica, este medicamento foi identificado em crianças lactentes de mães expostas à ciclosporina<sup>28</sup> .  
Os corticoides podem ser usados durante a gestação para controle de doença ativa, preferindo-se aqueles mais metabolizados pela placenta, como a prednisona. Baixos níveis são detectados no leite materno, sendo preconizado adiar a amamentação por 4 horas após a tomada do medicamento<sup>28</sup> .  
O uso da azatioprina parece seguro na gravidez. Conforme meta-análise recente, não há diferença de desfechos com seu uso. Entretanto, outra meta-análise sugere maior risco de parto prematuro. Seu uso deve considerar o risco e os benefícios, tendo em vista o risco de reativação da doença na gravidez, que está associada a piores desfechos. É possível a manutenção do medicamento na maioria dos casos. O uso de azatioprina apresenta baixo risco durante a amamentação<sup>28</sup> .  
O infliximabe teve sua segurança na gestação avaliada em uma meta-análise e duas revisões sistemáticas de estudos observacionais, os quais não identificaram aumento na incidência de desfechos gestacionais desfavoráveis<sup>28,32,33</sup> . Devido à detecção de infliximabe no feto até os 6 meses de vida, especialistas sugerem a suspensão dos anti-TNF na 24ª – 26ª semana de gestação, quando possível, levando em consideração a gravidade da doença<sup>28</sup> . A vacinação contra a tuberculose no neonato exposto ao anti-TNF durante a gestação deve ser postergada, devendo ocorrer após os 6 meses, pelo risco de tuberculose disseminada.  
O vedolizumabe e o tofacitinibe não são preconizados durante a gestação e o puerpério, considerando o escasso corpo de evidência e a limitada experiência de uso destes fármacos<sup>26,28,34.</sup>

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.5.3 Pacientes com manifestações extraintestinais (MEI) significativas** -->
As manifestações articulares são as MEI mais comuns, ocorrendo em até 20% dos pacientes com RCU. Deve-se fazer o diagnóstico diferencial com outras causas de artrite e artralgias. As manifestação articulares dividem-se em axial (tipo I) e periférica (tipo II)<sup>3</sup> .  
As manifestações articulares do tipo I caracterizam-se por ser pauciarticulares (menos de 5 articulações), acometer grandes articulações de forma assimétrica, e normalmente acompanham a agudização da RCU e respondem ao tratamento da doença intestinal. Pode-se utilizar sulfassalazina para tratamento sintomático da artralgia/artrite<sup>3</sup> .  
As manifestações articulares do tipo II são caracterizadas por acometer pequenas articulações (mais de 5), periféricas, simetricamente, e têm seu curso independente da doença de base. O tratamento dessas manifestações pode necessitar do uso de anti-inflamatórios não esteroidais (AINE) ou corticoide sistêmico para o controle sintomático por curto prazo<sup>3</sup> . Entretanto, o uso de AINE deve ser evitado pelo risco de reativação da RCU. Casos refratários devem ser encaminhados para serviço especializado no tratamento de RCU, com reumatologista.  
Pacientes com pioderma gangrenoso, fosfatase alcalina elevada, icterícia, qualquer outro sinal de colestase ou com suspeita de colangite esclerosante primária associada devem ser encaminhados para serviço especializado no tratamento da RCU.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **6.6. Benefícios esperados do tratamento** -->
- Em pacientes com doença ativa, os benefícios esperados são a remissão dos sinais e sintomas e a manutenção deste estado por, pelo menos, 6 meses.  
- Em pacientes em remissão, o objetivo é a prevenção de recorrências da doença. Espera-se que o(s) medicamento(s) em uso seja(m) capaz(es) de manter a remissão por, pelo menos, 6 meses, para ser(em) considerado(s) efetivo(s).

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **7. MONITORAMENTO** -->
Inexiste intervalo definido para a reavaliação endoscópica após o início do tratamento, embora haja evidência de melhores desfechos nos pacientes que atingiram a cicatrização da mucosa. Os pacientes devem evitar o uso de AINE, pois eles podem agravar as manifestações da RCU<sup>93</sup> .  
Antes do início da administração de sulfassalazina e mesalazina, deve-se realizar hemograma, exame qualitativo de urina (EQU) e dosagem de creatinina sérica. Pacientes com doença renal pré-existente ou em uso de outros fármacos nefrotóxicos devem ter a função renal monitorizada mais frequentemente durante o tratamento da RCU. Hemograma, EQU e dosagem de creatinina sérica devem ser repetidos a cada 6 meses. Os eventos adversos mais frequentes do uso de aminossalicilatos são sintomas e sinais gastrointestinais (náusea, dor abdominal e diarreia), cefaleia e piora da retocolite<sup>42</sup> .  
Para pacientes em uso de corticoide, indicam-se dosagens de potássio e sódio séricos e glicemia em jejum<sup>93</sup> . Se esse uso supera 6 semanas, impõem-se avaliação oftalmológica e densitometria óssea<sup>94</sup> .  
A azatioprina pode acarretar leucopenia ou trombocitopenia graves por supressão da medula óssea. Nesses casos, devese proceder à redução de dose ou cessação do uso de azatioprina<sup>90</sup> . Hemograma completo deve ser realizado semanalmente no primeiro mês, quinzenalmente no segundo e terceiro meses e, após, mensalmente<sup>95</sup> . Novos hemogramas devem ser solicitados se houver mudança na dose do medicamento. Aparentemente, não há relação da neutropenia com o efeito benéfico do tratamento, e a dose de azatioprina não deve ser aumentada intencionalmente para reduzir a contagem de leucócitos<sup>95,96</sup> . Também deve ser feito o controle de aminotransferases/transaminases (ALT/TGP e AST/TGO), na mesma periodicidade dos hemogramas nos primeiros 6 meses e, depois, trimestralmente.  
A ciclosporina deve ter a dose ajustada conforme seus níveis séricos, que, após, devem ser monitorizados regularmente. A ciclosporina é nefrotóxica, principalmente em idosos e em usuários de outros fármacos nefrotóxicos, e também tem efeito hipertensivo. Pacientes com função renal anormal previamente ao tratamento não devem usar ciclosporina. Dosagens séricas de creatinina e monitorização da pressão arterial devem ser feitos antes do tratamento em pelo menos duas ocasiões e, após o início do tratamento, a cada 15 dias durante os primeiros 3 meses de uso e, a seguir, mensalmente se o paciente estiver estável<sup>95</sup> . Nessas ocasiões, também devem ser realizados hemograma e dosagens séricas de ácido úrico, potássio, lipídios e magnésio. A dose de ciclosporina deve ser reduzida em 25% a 50% se houver elevação sustentada (duas dosagens de creatinina dentro de 14 dias) de ≥ 25% da creatinina sérica do paciente, e deve ser suspensa se não houver redução da creatinina após dois ajustes de dose. Se a redução não for efetiva ou a alteração for grave, a ciclosporina deve ser suspensa<sup>95</sup> .  
Durante a infusão de infliximabe, os pacientes devem ser monitorizados em ambiente equipado para tratamento de reações anafiláticas. Os sinais vitais devem ser verificados a cada 10 minutos, se os pacientes apresentarem algum sintoma, e a infusão interrompida, caso não haja melhora dos sintomas com a terapêutica instituída (corticoides e antialérgicos). Para as duas primeiras infusões por, aproximadamente, duas horas após o término da infusão devem ser observados os sinais e sintomas de reações de hipersensibilidade aguda<sup>97</sup> .  
Provas de função hepática devem ser realizadas antes de cada dose do tratamento com infliximabe ou vedolizumabe e o medicamento deve ser suspenso se as aminotransferases/transaminases (ALT/TGP e AST/TGO) estiverem mais de 5 vezes acima do limite superior da normalidade<sup>1</sup> . Os pacientes devem ser monitorizados e orientados a procurar atendimento na eventualidade de surgimento de sinais de doença infecciosa de qualquer natureza. Esses pacientes não devem receber vacinas com vírus atenuados. O infliximabe é contraindicado em paciente com insuficiência cardíaca moderada a grave (NYHA – _New York Heart Association_ II a IV).  
Alguns medicamentos recomendados para o tratamento da retocolite ulcerativa podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
Antes do início do uso de infliximabe, vedolizumabe ou tofacitinibe e com objetivo de realizar o planejamento terapêutico adequado, deve-se considerar as seguintes condutas:  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
- Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A radiografia  
- simples de tórax deve ser realizada para excluir a possibilidade de TB ativa.  
- Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD) ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
- Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
- Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil<sup>97</sup> e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de infliximabe, vedolizumabe ou tofacitinibe após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, à critério da equipe de saúde assistente, o início de uso de infliximabe, vedolizumabe ou tofacitinibe pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
- Nos casos de troca entre infliximabe, vedolizumabe ou tofacitinibe, não é necessário repetir as condutas preconizadas para início de tratamento.  
Para fins de acompanhamento, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
- Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
- Para que o uso de infliximabe, vedolizumabe ou tofacitinibe não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com infliximabe, vedolizumabe ou tofacitinibe devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com infliximabe, vedolizumabe ou tofacitinibe devem manter o monitoramento com o IGRA.  
- Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
- Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
- Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Assim, além do acompanhamento na Atenção Primária, doentes de RCU devem ser atendidos por equipe em serviço especializado, para seu adequado diagnóstico, inclusão no tratamento e acompanhamento. Como o controle dessa doença exige experiência e familiaridade com manifestações clínicas próprias, convém que o médico responsável tenha experiência e seja treinado nesse atendimento.  
Pacientes com retocolite ulcerativa devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de unidade de saúde de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da assistência farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A prescrição de biológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
Para a administração dos medicamentos biológicos intravenosos, é essencial o atendimento centralizado para maior racionalidade do uso e avaliação da efetividade dos medicamentos.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **10. REFERÊNCIAS** -->
1. Qayed E, Srinivasan S, Shahnavaz N. Sleisenger and Fordtran’s gastrointestinal and liver disease. 2017.  
2. Ghosh S, Shand A, Ferguson A. Ulcerative colitis. BMJ 2000;320(7242):1119–23.  
3. Magro F, Gionchetti P, Eliakim R, Ardizzone S, Armuzzi A, Barreiro-de Acosta M. Third European Evidence-based Consensus on Diagnosis and Management of Ulcerative Colitis. Part 1: Definitions. Disord J Crohns Colitis 2017;11(6):649–70.  
4. da Silva BC, Lyra AC, Mendes CMC, et al. The Demographic and Clinical Characteristics of Ulcerative Colitis in a Northeast Brazilian Population. BioMed Res Int 2015;2015:359130.  
5. Loftus EV. Clinical epidemiology of inflammatory bowel disease: Incidence, prevalence, and environmental influences. Gastroenterology 2004;126(6):1504–17.  
6. Inflammatory bowel disease prevalence by age, gender, race, and geographic location in the U. In: S. military. 2013.  
7. M BA, F M, D C, P L, A E, J C. Ulcerative colitis in northern Portugal and Galicia in Spain. Inflamm Bowel Dis. 2010;16(7):1227–38.  
8. da Silva BC, AC L, R R, GO S. Epidemiology, demographic characteristics and prognostic predictors of ulcerative colitis. World J Gastroenterol 2014;20(28):9458–67.  
9. Quaresma AB, Damiao AOMC, Coy CSR, Magro DO, Hino AAF, Valverde DA, Panaccione R, Coward SB, Ng SC, Kaplan GG, Kotze PG. Temporal trends in the epidemiology of inflammatory bowel diseases in the public healthcare system in Brazil: A large population-based study. Lancet Reg Health Am. 2022 Jun 9;13:100298. doi: 10.1016/j.lana.2022.100298. PMID: 36777324; PMCID: PMC9903988.  
10. Harbord M, Eliakim R, Bettenworth D, Karmiris K, Katsanos K, Kopylov U. Third European Evidence-based Consensus on Diagnosis and Management of Ulcerative Colitis. Part 2: Current Management. J Crohns Colitis 2017;  
11. Bressler B, Marshall JK, Bernstein CN, Bitton A, Jones J, Leontiadis GI. Clinical practice guidelines for the medical management of nonhospitalized ulcerative colitis: the Toronto consensus. Gastroenterology. 2015;148(5):1035–58.  
12. Mowat C, Cole A, Windsor A, Ahmad T, Arnott I, Driscoll R. Guidelines for the management of inflammatory bowel disease in adults. Gut 2011;60(5):571–607.  
13. Dignass A, Eliakim R, Magro F, Maaser C, Chowers Y, Geboes K. Second European evidence-based consensus on the diagnosis and management of ulcerative colitis part 1: definitions and diagnosis. J Crohns Colitis 2012;6(10):965–90.  
14. Dignass A, Lindsay JO, Sturm A, Windsor A, Colombel JF, Allez M. Second European evidence-based consensus on the diagnosis and management of ulcerative colitis part 2: current management. J Crohns Colitis 2012;6(10):991–1030.  
15. Ardizzone S, Puttini PS, Cassinotti A, Porro GB. Extraintestinal manifestations of inflammatory bowel disease. Dig Liver Dis. 2008;  
16. Zippi M, Corrado C, Pica R, Avallone EV, Cassieri C, De Nitto D. Extraintestinal manifestations in a large series of Italian inflammatory bowel disease patients. World J Gastroenterol 2014;20(46):17463–7.  
17. Soetikno RM, Lin OS, Heidenreich PA, Young HS, Blackstone MO. Increased risk of colorectal neoplasia in patients with primary sclerosing cholangitis and ulcerative colitis: a meta-analysis. Gastrointest Endosc. 2002;56(1):48–54.  
18. Truelove SC, Witts LJ. Cortisone in ulcerative colitis; final report on a therapeutic trial. Br Med J. 1955;2(4947):1041– 8.  
19. Byeon JS, Yang SK, Myung SJ, Pyo SI, Park HJ, Kim YM. Clinical course of distal ulcerative colitis in relation to appendiceal orifice inflammation status. Inflamm Bowel Dis 2005;11(4):366–71.  
20. Ladefoged K, Munck LK, Jorgensen F, Engel P. Skip inflammation of the appendiceal orifice: a prospective endoscopic study. Scand J Gastroenterol 2005;40(10):1192–6.  
21. Magro F, Langner C, Driessen A, Ensari A, Geboes K, Mantzaris GJ. European consensus on the histopathology of inflammatory bowel disease. J Crohns Colitis 2013;7(10):827–51.  
22. Baldassano RN, Piccoli DA. Inflammatory bowel disease in pediatric and adolescent patients. Gastroenterol Clin North Am. 1999;28(2):445–58.  
23. Turner D, Levine A, Escher JC, Griffiths AM, Russell RK, Dignass A. Management of pediatric ulcerative colitis: joint ECCO and ESPGHAN evidence-based consensus guidelines. J Pediatr Gastroenterol Nutr 2012;55(3):340–61.  
24. Tiemi J, Komati S, Sdepanian VL. Effectiveness of infliximab in Brazilian children and adolescents with Crohn disease and ulcerative colitis according to clinical manifestations, activity indices of inflammatory bowel disease, and corticosteroid use. J Pediatr Gastroenterol Nutr 2010;50(6):628–33.  
25. frmVisualizarBula.pdf [Internet]. [cited 2019 Oct 2];Available from:  
http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=25169392016&pIdAnexo=4037261  
26 Agência Nacional de Vigilância Sanitária – ANVISA. Tofacitinibe - Bula fabricante.  
27. Katz JA, Pore G. Inflammatory bowel disease and pregnancy. Inflamm Bowel Dis. 2001;7(2):146–57.  
28. Nguyen GC, Seow CH, Maxwell C, Huang V, Leung Y, Jones J. The Toronto Consensus Statements for the Management of Inflammatory Bowel Disease in Pregnancy. Gastroenterology 2016;150(3):734–57.  
29. Lacy C, Armstrong L, Goldman M, Lance L. Drug Information Handbook. 18th ed. Hudson (Cleveland: Lexi-Comp; 2009.  
30. Caprilli R, Gassull MA, Escher JC, Moser G, Munkholm P, Forbes A. European evidence based consensus on the diagnosis and management of Crohn’s disease: special situations. Gut 2006;  
31. B BO, R H, T E, G K. Pregnancy outcome after cyclosporine therapy during pregnancy: a meta-analysis. Transplantation. 2001;71(8):1051–5.  
32. Narula N, Al-Dabbagh R, Dhillon A, Sands BE, Marshall JK. Anti-TNFα therapies are safe during pregnancy in women with inflammatory bowel disease: a systematic review and meta-analysis. Inflamm Bowel Dis. 2014;20(10):1862–9.  
33. Shihab Z, Yeomans ND, De Cruz P. Anti-Tumour Necrosis Factor α Therapies and Inflammatory Bowel Disease Pregnancy Outcomes: A Meta-analysis. J Crohns Colitis 2016;10(8):979–88.  
34. Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Gestão e incorporação de Tecnologias e Inovação em Saúde, Coordenação de Monitoramento e Avaliação de Tecnologias em Saúde. Adalimumabe, golimumabe, infliximabe e vedolizumabe para tratamento da Retocolite Ulcerativa modera a agrave [Internet]. Brasília, DF: Comissão Nacional de Incorporação de Tecnologias no SUS; 2019. Available from: http://conitec.gov.br/images/Relatorios/2019/Relatorio_Biologicos_Colite_Ulcerativa.pdf  
35. Schroeder KW, Tremaine WJ, Ilstrup DM. Coated oral 5-aminosalicylic acid therapy for mildly to moderately active ulcerative colitis. A randomized study. N Engl J Med 1987;317(26):1625–9.  
36. Colombel JF, Rutgeerts P, Reinisch W, Esser D, Wang Y, Lang Y. Early mucosal healing with infliximab is associated with improved long-term clinical outcomes in ulcerative colitis. Gastroenterology. 2011;141(4):1194–201.  
37. Ordás I, Eckmann L, Talamini M, Baumgart DC, Sandborn WJ. Ulcerative colitis. Lancet 2012;380(9853):1606–19.  
38. Rutgeerts P, Sandborn WJ, Feagan BG, Reinisch W, Olson A, Johanns J. Infliximab for induction and maintenance therapy for ulcerative colitis. N Engl J Med 2005;353(23):2462–76.  
39. Shah SC, Colombel JF, Sands BE, Narula N. Mucosal Healing Is Associated With Improved Long-term Outcomes of Patients With Ulcerative Colitis: A Systematic Review and Meta-analysis. Clin Gastroenterol Hepatol. 2016;14(9):1245–55.  
40. Neurath MF, Travis SP. Mucosal healing in inflammatory bowel diseases: a systematic review. Gut 2012;61(11):1619– 35.  
41. Marshall JK, Thabane M, Steinhart AH, Newman J Anand, A I, E.J. Rectal 5-aminosalicylic acid for induction of remission in ulcerative colitis. Cochrane Database Syst Rev. 2010(1):004115.  
42. Marshall JK, Thabane M, Steinhart AH, Newman J Anand, A I, E.J. Rectal 5-aminosalicylic acid for maintenance of remission in ulcerative colitis. Cochrane Database Syst Rev. 2012;004118.  
43. Ford AC, Khan KJ, Achkar JP, Moayyedi P. Efficacy of oral vs. topical, or combined oral and topical 5-aminosalicylates, in Ulcerative Colitis: systematic review and meta-analysis. Am J Gastroenterol 2012;107(2).  
44. BSGoIB D. Consensus guidelines for the management of inflammatory bowel disease. Arq Gastroenterol. 2010;47(3):313–25.  
45. Kornbluth A, Sachar DB. Ulcerative colitis practice guidelines in adults. American College of Gastroenterology, Practice Parameters Committee. Am J Gastroenterol 1997;92(2):204–11.  
46. Lichtiger S, Present DH, Kornbluth A, Gelernt I, Bauer J, Galler G. Cyclosporine in severe ulcerative colitis refractory to steroid therapy. N Engl J Med 1994;330(26):1841–5.  
47. D’Haens G, Lemmens L, Geboes K, Vandeputte L, Van Acker F, Mortelmans L. Intravenous cyclosporine versus intravenous corticosteroids as single therapy for severe attacks of ulcerative colitis. Gastroenterology. 2001;120(6):1323–9.  
48. D’Arienzo A, Panarese A, D’Armiento FP, Lancia C, Quattrone P, Giannattasio F. 5-Aminosalicylic acid suppositories in the maintenance of remission in idiopathic proctitis or proctosigmoiditis: a double-blind placebo-controlled clinical trial. Am J Gastroenterol 1990;85(9):1079–82.  
49. McGrath J, McDonald JW, Macdonald JK. Transdermal nicotine for induction of remission in ulcerative colitis. Cochrane Database Syst Rev. 2004(4):004722.  
50. Mallon P, McKay D, Kirk S, Gardiner K. Probiotics for induction of remission in ulcerative colitis. Cochrane Database Syst Rev. 2007(4):005573.  
51. Chande N, Wang Y, MacDonald JK, McDonald JW. Methotrexate for induction of remission in ulcerative colitis. Cochrane Database Syst Rev. 2014(8):006618.  
52. Wang Y, MacDonald JK, Vandermeer B, Griffiths AM, El-Matary W. Methotrexate for maintenance of remission in ulcerative colitis. Cochrane Database Syst Rev. 2015(8):007560.  
53. M DL, de Vos R, DW H, P S. Fish oil for induction of remission in ulcerative colitis. Cochrane Database Syst Rev. 2007(4):005986.  
54. Wang Y, Parker CE, Bhanji T, Feagan BG, MacDonald JK. Oral 5-aminosalicylic acid for induction of remission in ulcerative colitis. Cochrane Database Syst Rev.  
55. Wang Y, Parker CE, Feagan BG, MacDonald JK. Oral 5-aminosalicylic acid for maintenance of remission in ulcerative colitis. Cochrane Database Syst Rev. 2016(5):000544.  
56. Feagan BG, MacDonald JK. Once daily oral mesalamine compared to conventional dosing for induction and maintenance of remission in ulcerative colitis: a systematic review and meta-analysis. Inflamm Bowel Dis. 2012;18(9):1785–94.  
57. Ford AC, Bernstein CN, Khan KJ, Abreu MT, Marshall JK, Talley NJ. Glucocorticosteroid therapy in inflammatory bowel disease: systematic review and meta-analysis. Am J Gastroenterol 2011;106(4).  
58. Gisbert JP, Linares PM, McNicholl AG, Maté J, Gomollón F. Meta-analysis: the efficacy of azathioprine and mercaptopurine in ulcerative colitis. Aliment Pharmacol Ther. 2009;30(2):126–37.  
59. Khan KJ, Dubinsky MC, Ford AC, Ullman TA, Talley NJ, Moayyedi P. Efficacy of immunosuppressive therapy for inflammatory bowel disease: a systematic review and meta-analysis. Am J Gastroenterol 2011;106(4):630–42.  
60. Timmer A, Patton PH, Chande N, McDonald JW, MacDonald JK. Azathioprine and 6-mercaptopurine for maintenance of remission in ulcerative colitis. Cochrane Database Syst Rev. 2016(5):000478.  
61. Ministério da Saúde, Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde. PORTARIA No 49, DE 22 DE OUTUBRO DE 2019. Diário Of. União. 2019;45. 62.  Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. Citrato de tofacitinibe para o tratamento de retocolite ulcerativa ativa moderada a grave em pacientes adultos com resposta inadequada, perda de resposta ou intolerantes ao tratamento prévio com medicamentos sintéticos convencionais. Relatório n° 631 junho 2021.; 2021.  
http://conitec.gov.br/images/Consultas/Relatorios/2021/Relatorios  
63. Lawson MM, Thomas AG, Akobeng AK. Tumour necrosis factor alpha blocking agents for induction of remission in ulcerative colitis. Cochrane Database Syst Rev. 2006(3):005112.  
64. Sandborn WJ, Rutgeerts P, Feagan BG, Reinisch W, Olson A, Johanns J. Colectomy rate comparison after treatment of ulcerative colitis with placebo or infliximab. Gastroenterology 2009;137(4).  
65. Mao EJ, Hazlewood GS, Kaplan GG, Peyrin-Biroulet L, Ananthakrishnan AN. Systematic review with meta-analysis: comparative efficacy of immunosuppressants and biologics for reducing hospitalisation and surgery in Crohn’s disease and ulcerative colitis. Aliment Pharmacol Ther. 2017;45(1):3–13.  
66. Lopez A, Ford AC, Colombel JF, Reinisch W, Sandborn WJ, Peyrin-Biroulet L. Efficacy of tumour necrosis factor antagonists on remission, colectomy and hospitalisations in ulcerative colitis: Meta-analysis of placebo-controlled trials. Dig Liver Dis. 2015;47(5):356–64.  
67. Panaccione R, Ghosh S, Middleton S, Márquez J Scott, BB F, L. Combination therapy with infliximab and azathioprine is superior to monotherapy with either agent in ulcerative colitis. Gastroenterology. 2014;146(2):392–400.  
68. Christophorou D, Funakoshi N, Duny Y, Valats JC, Bismuth M, Pineton De Chambrun G. Systematic review with metaanalysis: infliximab and immunosuppressant therapy vs. infliximab alone for active ulcerative colitis. Aliment Pharmacol Ther. 2015;41(7):603–12.  
69. Armuzzi A, Pugliese D, Danese S, Rizzo G, Felice C, Marzo M. Infliximab in steroid-dependent ulcerative colitis: effectiveness and predictors of clinical and endoscopic remission. Inflamm Bowel Dis. 2013;19(5):1065–72.  
70. Bickston SJ, Behm BW, Tsoulis DJ, Cheng J, MacDonald JK, Khanna R. Vedolizumab for induction and maintenance of remission in ulcerative colitis. Cochrane Database Syst Rev. 2014(8):007571.  
71. Feagan BG, Rutgeerts P, Sands BE, Hanauer S, Colombel JF, Sandborn WJ. Vedolizumab as induction and maintenance therapy for ulcerative colitis. N Engl J Med 2013;369(8):699–710.  
72. Mei WQ, Hu HZ, Liu Y, Li ZC, Wang WG. Infliximab is superior to other biological agents for treatment of active ulcerative colitis: A meta-analysis. World J Gastroenterol 2015;21(19):6044–51.  
73. Vickers AD, Ainsworth C, Mody R, Bergman A, Ling CS, Medjedovic J. Systematic Review with Network MetaAnalysis: Comparative Efficacy of Biologics in the Treatment of Moderately to Severely Active Ulcerative Colitis. PLoS One. 2016;11(10):0165435.  
74. Bonovas S, Lytras T, Nikolopoulos G, Peyrin-Biroulet L, Danese S. Systematic review with network meta-analysis: comparative assessment of tofacitinib and biological therapies for moderate-to-severe ulcerative colitis. Aliment Pharmacol Ther 2018;47(4):454–65.  
75. Singh S, Fumery M, Sandborn WJ, Murad MH. Systematic review with network meta-analysis: first- and second-line pharmacotherapy for moderate-severe ulcerative colitis. Aliment Pharmacol Ther 2018;47(2):162–75.  
76. Feagan BG, Rutgeerts P, Sands BE, Hanauer S, Colombel JF, Sandborn WJ. Supplementary Appendix to: Vedolizumab as induction and maintenance therapy for ulcerative colitis. N Engl J Med 2013;369(8):699–710.  
77. Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. Portaria SCTIE/MS nº 31, DE 28 DE JUNHO DE 2021.; 2021. http://conitec.gov.br/images/Relatorios/Portaria/2021/20210629_Portaria_31.pdf  
78. Trigo-Vicente C, Gimeno-Ballester V, García-López S, López-Del Val A. Systematic review and network metaanalysis of treatment for moderate-to-severe ulcerative colitis. Int J Clin Pharm [Internet]. 2018 Dec 26;40(6):1411–9. Available from: http://link.springer.com/10.1007/s11096-018-0743-4  
79. Travis SP, Farrant JM, Ricketts C, Nolan DJ, Mortensen NM, Kettlewell MG. Predicting outcome in severe ulcerative colitis. Gut 1996;38(6):905–10.  
80. Williams JG, Alam MF, Alrubaiy L, Arnott I, Clement C, Cohen D. Infliximab versus ciclosporin for steroid-resistant acute severe ulcerative colitis (CONSTRUCT): a mixed methods, open-label, pragmatic randomised trial. Lancet Gastroenterol Hepatol. 2016;1(1):15–24.  
81. Narula N, Marshall JK, Colombel JF, Leontiadis GI, Williams JG, Muqtadir Z. Systematic Review and Meta-Analysis: Infliximab or Cyclosporine as Rescue Therapy in Patients With Severe Ulcerative Colitis Refractory to Steroids. Am J Gastroenterol 2016;111(4):477–91.  
82. Laharie D, Bourreille A, Branche J, et al. Ciclosporin versus infliximab in patients with severe ulcerative colitis refractory to intravenous steroids: a parallel, open-label randomised controlled trial. Lancet Lond Engl 2012;380(9857):1909–15.  
83. Ordás I, Domènech E, Mañosa M, García-Sánchez V, Iglesias-Flores E, Peñalva M. Long-Term Efficacy and Safety of Cyclosporine in a Cohort of Steroid-Refractory Acute Severe Ulcerative Colitis Patients from the ENEIDA Registry ( 19892013): A Nationwide Multicenter Study. Am J Gastroenterol 2017;  
84. Feuerstein JD, Akbari M, Tapper EB, Cheifetz AS. Systematic review and meta-analysis of third-line salvage therapy with infliximab or cyclosporine in severe ulcerative colitis. Ann Gastroenterol 2016;29(3):341–7.  
85. Narula N, Fine M, Colombel JF, Marshall JK, Reinisch W. Systematic Review: Sequential Rescue Therapy in Severe Ulcerative Colitis: Do the Benefits Outweigh the Risks? Inflamm Bowel Dis. 2015;21(7):1683–94.  
86. Cohen RD, Woseth DM, Thisted RA, Hanauer SB. A meta-analysis and overview of the literature on treatment options for left-sided ulcerative colitis and ulcerative proctitis. Am J Gastroenterol 2000;95(5):1263–76.  
87. Marteau P, Crand J, Foucault M, Rambaud JC. Use of mesalazine slow release suppositories 1 g three times per week to maintain remission of ulcerative proctitis: a randomised double blind placebo controlled multicentre study. Gut 1998;42(2):195– 9.  
88. Hawthorne AB, Logan RF, Hawkey CJ, Foster PN, Axon AT, Swarbrick ET. Randomised controlled trial of azathioprine withdrawal in ulcerative colitis. BMJ 1992;305(6844):20–2.  
89. Torres J, Boyapati RK, Kennedy NA, Louis E, Colombel JF, Satsangi J. Systematic Review of Effects of Withdrawal of Immunomodulators or Biologic Agents From Patients With Inflammatory Bowel Disease. Gastroenterology 2015;149(7):1716– 30.  
90. Feldman M, Friedman LS, Brandt LJ, editors. Sleisenger and Fordtran’s gastrointestinal and liver disease: pathophysiology/diagnosis/management. Tenth edition. Philadelphia, PA: Saunders/Elsevier; 2016.  
91. Armuzzi A, Pugliese D, Danese S, Rizzo G, Felice C, Marzo M. Long-term combination therapy with infliximab plus azathioprine predicts sustained steroid-free clinical benefit in steroid-dependent ulcerative colitis. Inflamm Bowel Dis. 2014;20(8):1368–74.  
92. Gisbert JP, Marín AC, Chaparro M. The Risk of Relapse after Anti-TNF Discontinuation in Inflammatory Bowel Disease: Systematic Review and Meta-Analysis. Am J Gastroenterol 2016;111(5):632–47.  
93. Felder JB, Korelitz BI, Rajapakse R, Schwarz S, Horatagis AP, Gleim G. Effects of nonsteroidal antiinflammatory drugs on inflammatory bowel disease: a case-control study. Am J Gastroenterol 2000;95(8):1949–54.  
94. Drug Information for the Health Care ProfessionalMicromedex – Thompson Health Care. 2001;  
95. Physician’s Desk Reference. 55th ed. Medical Economics Company; 2001.  
96. Campbell S, Ghosh S. Is neutropenia required for effective maintenance of remission during azathioprine therapy in inflammatory bowel disease? Eur J Gastroenterol Hepatol 2001;13(9):1073–6.  
97. Rahier JF, Magro F, Abreu C, et al. Second European evidence-based consensus on the prevention, diagnosis and management of opportunistic infections in inflammatory bowel disease. J Crohns Colitis 2014;8(6):443–68.  
SULFASSALAZINA, MESALAZINA, AZATIOPRINA, CICLOSPORINA, INFLIXIMABE, VEDOLIZUMABE E TOFACITINIBE

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Eu, ______________________________________________________________________________________ (nome  
do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso dos medicamentos **sulfassalazina, mesalazina, azatioprina, ciclosporina, infliximabe,**  
**vedolizumabe e tofacitinibe** indicado(s) para o tratamento da Retocolite Ulcerativa.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
__________________________________________________________________ (nome do médico que prescreve).  
Assim declaro que:  
Fui claramente informado(a) de que o medicamento que passo a receber pode trazer as **seguintes melhorias** :  
- em pacientes com doença ativa: melhora dos sintomas;  
- em pacientes estáveis: a prevenção de recaídas;  
Fui também claramente informado a respeito das seguintes **contraindicações, potenciais eventos adversos e riscos:**  
- não se sabe ao certo os riscos do uso da ciclosporina na gravidez, portanto, caso engravidar, avisar imediatamente o  
- médico;  
- o risco na gravidez é improvável com o uso de sulfassalazina, mesalazina e infliximabe pois estudos em animais não  
- mostraram anormalidades nos descendentes, porém não há estudos em humanos;  
- há evidências de riscos ao feto com o uso de azatioprina, mas um benefício potencial pode ser maior que os riscos;  
- os eventos adversos mais comumente relatados para os medicamentos são:  
**- para sulfassalazina:** dores de cabeça, reações alérgicas (dores nas juntas, febre, coceira, erupção cutânea), sensibilidade aumentada aos raios solares, dores abdominais, náusea, vômitos, perda de apetite, diarreia. Mais raramente podem ocorrer diminuição do número dos glóbulos brancos no sangue, parada na produção de sangue pela medula óssea (anemia aplásica), anemia por destruição aumentada dos glóbulos vermelhos do sangue (anemia hemolítica), diminuição no número de plaquetas no sangue (aumenta os riscos de sangramento), piora nos sintomas da Retocolite Ulcerativa, problemas no fígado, falta de ar associada a tosse e febre (pneumonite intersticial), dor nas juntas, dificuldade para engolir, cansaço associado à formação de bolhas e com perda de regiões da pele e de mucosas (síndrome de Stevens-Johnson e necrólise epidérmica tóxica) e desenvolvimento de sintomas semelhantes aos do lúpus eritematoso sistêmico (ou seja, bolhas na pele, dor no peito, mal-estar, erupções cutâneas, falta de ar e coceira);  
**- para mesalazina:** dores de cabeça, reações alérgicas (dores nas juntas, febre, coceira, erupção cutânea), sensibilidade aumentada aos raios solares, perda de cabelo, dores abdominais, náusea, vômitos, perda de apetite, diarreia, diarreia com sangue, tonturas, rinite, cansaço ou fraqueza. Mais raramente podem ocorrer hepatite medicamentosa, pancreatite e pericardite.  
**- para azatioprina:** diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, problemas para o fígado e pâncreas, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos, falta de ar, pressão baixa, problemas nos pulmões e reações de hipersensibilidade, diminuição das defesas imunológicas do organismo com ocorrência de infecções. A azatioprina pode causar câncer em animais e provavelmente tenha o mesmo efeito na espécie humana;  
**- para ciclosporina** : problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, aumento do crescimento da gengiva, aumento do colesterol e triglicerídeos, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão mental, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do  
pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada a temperatura e aumento das mamas;  
**- para infliximabe** : náusea, diarreia, dor abdominal, vômito, má digestão, azia, dor de cabeça, fadiga, febre, tontura, dor, rash cutâneo, prurido, bronquite, rinite, infecção de vias aéreas superiores, tosse, sinusite, faringite, reativação de tuberculose, reação à infusão, dor no peito, infecções, reações de hipersensibilidade, dor nas juntas, dor nas costas, infecção do trato urinário; outros efeitos: abscesso, hérnia abdominal, aumento dos níveis das aminotransferase/transaminases hepáticas (ALT/TGP e AST/TGO), anemia, ansiedade, apendicite, artrite, problemas no coração, carcinoma basocelular, cólica biliar, fratura óssea, infarto cerebral, câncer de mama, celulite, colecistite, colelitíase, confusão, desidratação, delírio, depressão, hérnia diafragmática, falta de ar, disúria, inchaço, confusão mental, endometriose, endoftalmite, furúnculos, úlcera gástrica, hemorragia gastrointestinal, hepatite colestática, herpes zóster, hidronefrose, pressão alta ou baixa, hérnia de disco intervertebral, inflamação, obstrução intestinal, perfuração intestinal, estenose intestinal, cisto articular, degeneração articular, infarto renal, leucopenia, linfangite, lúpus eritematoso sistêmico, linfoma, mialgia, isquemia miocárdica, osteoartrite, osteoporose, isquemia periférica, problemas nos pulmões, nos rins e no pâncreas, adenocarcinoma de reto, sepse, câncer de pele, sonolência, tentativa de suicídio, desmaios, problemas nos tendões, diminuição de plaquetas, trombose, úlceras e perda de peso; pode facilitar o estabelecimento ou agravar infecções fúngicas e bacterianas;  
**- para vedolizumabe** : nasofaringite, cefaleia, artralgia, dor nas extremidades, bronquite, gastroenterite, infecção do trato respiratório superior, influenza, sinusite, faringite; parestesia; hipertensão; dor na orofaringe, congestão nasal, tosse; abscesso anal, fissura anal, náusea, dispepsia, prisão de ventre, distensão abdominal, flatulência, hemorroidas; erupção cutânea, prurido, eczema, eritema, suores noturnos, acne; espasmos musculares, lombalgia, fraqueza muscular, fadiga; febre.  
**- para tofacitinibe:** infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas. É recomendada avaliação dos pacientes quanto a fatores de risco para tromboembolismo venoso antes do início do tratamento e periodicamente durante o tratamento. O tofacitinibe deve ser usado com cautela em pacientes nos quais os fatores de risco são identificados  
- medicamentos estão contraindicados em casos de hipersensibilidade (alergia) aos fármacos;  
- o risco da ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
( ) Sim ( ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
( ) azatioprina ( ) ciclosporina ( ) infliximabe ( ) mesalazina ( ) sulfassalazina ( ) tofacitinibe ( ) vedolizumbe  
|Local:|Data:|
|---|---|
|Nome do paciente:||
|Cartão Nacional de Saúde:||
|Nome do responsável legal:||
|Documento de identificação do responsável legal:||  
______________________________________________________ Assinatura do paciente ou do responsável legal Médico responsável: CRM: UF: ______________________________________________________ Assinatura e carimbo do médico  
**NOTA 1** : A prescrição de biológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
**NOTA 2** : Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os  
medicamentos preconizados neste Protocolo

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **Alteração pós publicação** -->
Depois da sua publicação, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Retocolite ulcerativa, pela necessidade de atualizar o item de Monitoramento da infecção por tuberculose ativa e rastreio da infecção por tuberculose latente (ILTB), de modo a harmonizar a orientação em todos os PCDT que preconizam o uso de medicamentos modificadores do curso da doença (MMCD) biológicos ou MMCD sintéticos-alvo específico.  
O tema foi apresentado como informe à 125ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 20 de maio de 2025, e também à 141ª Reunião Ordinária da Conitec, em junho de 2025.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **1.1. Escopo e finalidade do Protocolo** -->
Este PCDT se destina a profissionais da saúde, pacientes com retocolite ulcerativa e gestores do SUS. O documento foi elaborado visando a garantir o melhor cuidado de saúde e o uso racional dos recursos disponíveis no Sistema Único de Saúde. O objetivo da atualização do PCDT da Retocolite Ulcerativa foi a ampliação de uso da mesalazina no SUS, conforme Portaria SCTIE/MS nº 15, de 10 de maio de 2023, e o Relatório de Recomendação nº 801 de 2023, da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec).  
O Comitê de Medicamentos, na 116ª Reunião Ordinária da Conitec, realizada no dia 14 de março de 2023, deliberou, por unanimidade, recomendar a incorporação da mesalazina sachê (2g) para o tratamento da retocolite ulcerativa leve a moderada em adultos, conforme Protocolo Clínico do Ministério da Saúde. Os membros consideraram os benefícios que a mesalazina sachê pode trazer aos pacientes e a estimativa de economia de recursos para o SUS com a redução no preço inicialmente proposto pelo demandante, mesmo diante da possível migração dos pacientes entre as apresentações de mesalazina.  
Desta forma, esta atualização rápida teve como foco a inclusão da nova apresentação da mesalazina (sachê) no âmbito do SUS.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **1.2. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS), com revisão de especialista da área. A atualização pontual partiu da versão aprovada pela Portaria Conjunta SAES/SCTIE/MS nº 22, de 20 de dezembro de 2021 e do Relatório de Recomendação n° 801/2023 da mesalazina sachê, razões pelas quais se mantém o registro das últimas atualizações do PCDT, no item 2, adiante.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **1.3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Retocolite Ulcerativa foi apresentada na 108ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 29 de agosto de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Vigilância em Saúde e Ambiente (SVSA). Não houve considerações adicionais ao documento. O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 122ª Reunião Ordinária, os quais recomendaram favoravelmente à atualização do texto.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **1.4. Consulta pública** -->
A Consulta Pública nº 40/2023, do Protocolo Clínico e Diretrizes Terapêuticas de Retocolite Ulcerativa, foi realizada entre os dias 10/10/2023 e 30/10/2023. Foram recebidas 365 contribuições. O resumo da análise das contribuições recebidas se encontra no quadro I do documento. O conteúdo integral das contribuições se encontra disponível na página da Conitec em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2023/contribuicoes-cp-40-protocolo-clinico-e-diretrizesterapeuticas-de-retocolite-ulcerativa</u>

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **1.5. Busca da evidência** -->
Este PCDT foi desenvolvido seguindo as orientações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ( **Figura A** ) e a pergunta estruturada para elaboração do relatório de recomendação da tecnologia pode ser verificado no **Quadro A** :  
A presente atualização teve foco específico no tratamento, visando à inclusão da mesalazina sachê, conforme a deliberação da Conitec. Partiu-se da versão do PCDT de Retocolite Ulcerativa aprovado por meio da Portaria Conjunta SAES/SCTIE/MS nº 22, de 20 de dezembro de 2021, manteve-se sua estrutura metodológica e foram acrescentadas informações referentes à tecnologia incorporada. A pergunta de pesquisa avaliada no momento da incorporação da mesalazina sachê pode ser observada abaixo.  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
<!-- Start of picture text -->
[ eo “pievomeses<br>Intervencao, no caso de estudos experimentais<br>*Fator de exposi¢ao, em caso de estudos<br>observacionais<br>Teste indice, nos casos de estudos de acuracia<br>diagnéstica<br>«Controle, de acordo com tratamento/niveis de<br>exposic¢ao do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br><!-- End of picture text -->  
**Quadro A** - Pergunta estruturada para elaboração do relatório de recomendação da tecnologia (PICO).  
|População|Pacientes adultos (≥18 anos) com RCU idiopática ativa (leve a moderada) em todas as extensões<br>em terapia de indução à remissão.|
|---|---|
|Intervenção|Mesalazina sachê (oral) – grânulos de liberação prolongada|
|(tecnologia)||
|Comparação|Mesalazina (demais apresentações orais)|
|Desfechos (_Outcomes_)|Eficácia: Remissão clínica, endoscópica e combinada<br>Segurança: Eventos adversos|
|Tipo de estudo|Ensaios clínicos randomizados, revisões sistemáticas com meta-análises e estudos observacionais.|  
Fonte: Relatório Recomendação nº 801 maio/2023. Disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2023/20230511-  
<u>relatorio_801_mesalazina_sache_2g_para_rcu.pdf</u>  
**1.6. Questão de pesquisa e recomendação final da Conitec**  
O Comitê de Medicamentos, na 116ª Reunião Ordinária da Conitec, realizada no dia 14 de março de 2023, deliberou, por unanimidade, recomendar a incorporação da mesalazina sachê (2g) para o tratamento da retocolite ulcerativa leve a moderada em adultos, conforme Protocolo Clínico do Ministério da Saúde. Considerou-se os benefícios que a mesalazina sachê pode trazer aos pacientes e a estimativa de economia de recursos para o SUS com a redução no preço inicialmente proposto pelo demandante, mesmo diante da possível migração dos pacientes entre as apresentações de mesalazina. Foi assinado o Registro de Deliberação n° 798/2023.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **2.1. Escopo e finalidade do Protocolo** -->
O objetivo da atualização do PCDT da Retocolite Ulcerativa foi a disponibilização do novo medicamento para o tratamento no SUS, o citrato de tofacitinibe, que foi incorporado ao SUS por meio da Portaria SCTIE/MS nº 31, de 28 de junho de 2021, conforme o Relatório de Recomendação nº 631 de junho de 2021, da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec).  
A deliberação da Conitec foi de recomendar a incorporação no SUS do citrato de tofacitinibe para o tratamento de retocolite ulcerativa ativa moderada a grave em pacientes adultos com resposta inadequada, perda de resposta ou intolerantes ao tratamento prévio com medicamentos sintéticos convencionais. Considerou-se que o citrato de tofacitinibe seria uma opção terapêutica na mesma linha de tratamento dos medicamentos biológicos (infliximabe e vedolizumabe), incluindo sua utilização após a falha de um destes últimos.  
No decorrer do processo de atualização do PCDT de Retocolite Ulcerativa, foi observado que o PCDT vigente não preconizava a possibilidade de ajuste da dose na fase de manutenção do tratamento com o vedolizumabe, para os casos de pacientes com RCU nos quais se observa perda de resposta. As contribuições da Consulta pública que reportaram o assunto foram provenientes de sociedades médicas, da empresa fabricante da tecnologia, associações de pacientes, profissionais de saúde e pacientes. Foram apresentados estudos que demonstram tanto a necessidade do aumento da dose desse medicamento para alguns pacientes quanto os resultados de eficácia para os pacientes que se beneficiaram com a otimização da dose. Na análise, foram avaliados a bula do fabricante, as evidências, as manifestações e o custo do tratamento. O tema foi apresentado ao Plenário da Conitec e inserido nesta versão do PCDT.  
Este PCDT se destina a profissionais da saúde, pacientes com retocolite ulcerativa e gestores do SUS. O documento foi elaborado visando a garantir o melhor cuidado de saúde e o uso racional dos recursos disponíveis no Sistema Único de Saúde.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **2.2 Alteração pós publicação** -->
Depois da publicação, em 20/12/2021, da Portaria Conjunta SAES/SCTIE/MS nº 22, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Retocolite Ulcerativa, pela necessidade de se excluir uma apresentação farmacêutica de mesalazina, devido à ausência de registros válidos na Agência Nacional de Vigilância Sanitária (Anvisa). Para tal, foi também adequado o Relatório de Recomendação n.º 684/2021 da Conitec.  
À 104ª Reunião Ordinária da Conitec, realizada no dia 09/12/2021, havia sido analisado o Relatório de Recomendação nº 694/2021, que se refere à exclusão de medicamentos cujos registros sanitários caducaram ou foram cancelados no Brasil. Àquela ocasião, foi deliberado, por unanimidade, recomendar a exclusão de mesalazina 3 g enema. A decisão de exclusão das apresentações foi publicada por meio da Portaria SCTIE/MS nº 83, de 29/12/2021. Por fim, o tema foi apresentado como informe à 96ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 22/02/2022 e também à 106ª Reunião Ordinária da Conitec, em 10/03/2022.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **2.3. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS), a partir da versão aprovada pela Portaria Conjunta no6/SAES e SCTIE, de 26/11/2020 e do Relatório de Recomendação do tofacitinibe, razões pelas quais se mantém o registro da atualização do PCDT em 2020, no item 2, adiante.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **2.4. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Retocolite Ulcerativa foi apresentada na 92ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em agosto de 2021. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). O PCDT foi aprovado para avaliação pela Conitec e a proposta foi apresentada aos membros do Plenário da Conitec em sua 94ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **2.5. Consulta pública** -->
A Consulta Pública nº 74/2021, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Retocolite Ulcerativa, foi realizada entre os dias 10/09/2021 a 29/09/2021. Foram recebidas 370 contribuições, que podem ser verificadas em: http://conitec.gov.br/images/Consultas/Contribuicoes/2021/20210930_CP_CONITEC_74_2021_PCDT_Retocolite.pdf

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **2.6 Busca da evidência e recomendações** -->
Diante da recente atualização do PCDT de Retocolite Ulcerativa, em março de 2020, a presente atualização teve foco específico no tratamento, visando à inclusão de orientações sobre o uso de tofacitinibe, conforme a deliberação do Plenário da Conitec. Partiu-se da versão do PCDT de Retocolite Ulcerativa aprovado por meio da Portaria Conjunta SAES-SCTIE/MS nº 6, de 26 de março de 2020, manteve-se sua estrutura metodológica e foram acrescentadas informações referentes à tecnologia incorporada (citrato de tofacitinibe), conforme Relatório de Recomendação da Conitec nº 631, de junho de 2021, e diretrizes internacionais. A pergunta de pesquisa avaliada no momento da incorporação do tofacitinibe pode ser observada abaixo.  
**Quadro B** - Pergunta estruturada para elaboração do relatório de recomendação da tecnologia (PICO).  
|População|Pacientes adultos com RCU ativa moderada a grave com resposta inadequada, perda de resposta<br>ou intolerância a corticosteroides, AZA e 6-MP.|
|---|---|
|Intervenção|Citrato de tofacitinibe|
|(tecnologia)||
|Comparação|Infliximabe, vedolizumabe ou placebo|
|Desfechos (Outcomes)|Eficácia: resposta clínica e remissão clínica, qualidade de vida relacionada à saúde Segurança:<br>eventos adversos|
|Tipo de estudo|Ensaios clínicos randomizados, revisões sistemáticas com meta-análises e estudos<br>observacionais.|  
Fonte: Relatório Recomendação nº 631, de junho/2021.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **3.1. Levantamento de informações para planejamento da reunião com os especialistas** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), a Tabela de Procedimentos, Medicamentos e OPM do SUS e o Protocolo  
Clínico e Diretrizes Terapêuticas (PCDT) de Retocolite Ulcerativa vigente, para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas.  
A partir das consultas realizadas foi possível identificar que:  
- o tratamento no SUS segue o preconizado no Protocolo Clínico e Diretrizes Terapêuticas - Retocolite Ulcerativa,  
conforme a Portaria SAS/MS nº 861, de 04 de novembro de 2002;  
- os medicamentos atualmente disponíveis são: sulfassalasina, mesalazina, hidrocortisona, prednisona, azatioprina, 6-  
mercaptopurina e ciclosporina; e  
- havia solicitação de avaliação infliximabe e adalimumabe pela Conitec.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **3.2. Reunião com especialistas** -->
Foi realizada reunião com os consultores especialistas e metodologistas do comitê elaborador dos PCDT, na qual foram apresentados os resultados do levantamento de informações realizados pelos metodologistas. Os consultores especialistas também apontaram a necessidade de avaliação de inclusão do infliximabe e adalimumabe.  
Sendo assim, foi estabelecido que o Protocolo se destina a pacientes com Retocolite Ulcerativa, de ambos os sexos, sem restrição de idade, e tem por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca descrita no PCDT vigente.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: **3.3. Buscas na literatura para atualização do PCDT** -->
A fim de guiar a revisão do PCDT vigente, foi realizada busca na literatura sobre **intervenções terapêuticas,** definida pela pergunta PICO estabelecida no **Quadro C** .  
**Quadro C** - Pergunta estruturada para elaboração do relatório de recomendação da tecnologia (PICO).  
|População|Pacientes com Retocolite Ulcerativa|
|---|---|
|Intervenção|Tratamento clínico|
|Comparação|Sem restrição de comparadores|
|Desfechos|Segurança e eficácia: remissão clínica, resposta clínica, cicatrização de mucosa, remissão clínica|
||sustentada e eventos adversos|
|Tipos de estudos|Meta-análises e revisões sistemáticas|  
A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Medicamentos registrados no Brasil para o tratamento da RCU;  
- Revisões sistemáticas de estudos randomizados;  
- Avaliação de eficácia ou segurança;  
- Maior pontuação pelo AMSTAR.  
O **Quadro D** apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados. Os artigos selecionados encontram-se nas **Tabelas A, B, C e D** .  
**Quadro D -** Buscas sobre intervenções terapêuticas - revisões sistemáticas e meta-análises  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via|“Colitis, Ulcerative”[Mesh]|185|23|
|PubMed)|AND “Therapeutics”[Mesh]<br>AND ((Meta-||**Motivo das exclusões:**|
|Data da busca:<br>24/03/2017|Analysis[ptyp] OR<br>systematic[sb]) AND<br>(“2002/01/01”[PDAT] :<br>“3000/12/31”[PDAT])<br>AND “humans”[MeSH<br>Terms] AND (English[lang]<br>OR Portuguese[lang] OR<br>Spanish[lang]))||- 13 revisões Cochrane já incluídas<br>- 14 sem referência à tratamento<br>- 3 referências repetidas<br>- 23 revisões não sistemáticas ou sem meta-análise<br>- 13 estudos não randomizados<br>- 18 tratamento não existentes ou não liberados no Brasil<br>para RCU<br>- 9 tratamentos cirúrgicos<br>- 33 revisões sistemáticas com versão mais recente<br>- 19_guidelines_de outros países<br>- 10 estudos de baixo grau de evidência<br>- 4 tratamentos de outras doenças ou em pediatria<br>- 1 apenas_abstract_disponível|
|Embase|‘ulcerative colitis’/exp<br>AND ‘therapy’/exp AND<br>([cochrane review]/lim OR<br>[systematic review]/lim OR<br>[meta analysis]/lim) AND<br>([english]/lim OR<br>[portuguese]/lim OR<br>[spanish]/lim) AND<br>[humans]/lim AND [2002-<br>2017]/py|648|19<br>**Motivo das exclusões:**<br>- 74 revisões sistemáticas com versões mais recentes<br>- 87 estudos sem referência à tratamento clínico<br>- 10 consensos<br>- 13 estudos de custo efetividade<br>- 99 tratamentos de outra doença ou manifestações<br>extraintestinais<br>- 55 tratamentos não liberado ou existente no Brasil<br>- 37 tratamentos cirúrgicos<br>- 8 referências repetidas<br>- 73 revisões não sistemáticas<br>- 76 revisões sistemáticas de estudo não randomizados<br>- 4 revisões sistemáticas sem meta-análise<br>- 34 apenas resumos ou editorial<br>- 16 estudos exclusivos em pediatria<br>- 29 já incluídas na revisão da Cochrane ou Pubmed<br>- 14 outros|
|Cochrane|‘”Colitis, Ulcerative” in|28|18|
|Library|Title, Abstract, Keywords ,<br>Publication Year from 2002||**Motivo das exclusões:**|
|Data da busca:<br>24/03/2017|in Cochrane Reviews’||- 5 tratamento não disponível no Brasil<br>- 2 tratamento não medicamentoso<br>- 1 outra doença|  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
||||- 1 tratamento de_pouchite_|
||||- 1 revisão desatualizada|  
A fim de guiar a revisão do PCDT vigente, foi realizada busca na literatura sobre diagnóstico nos principais consensos e _guidelines_ internacionais. O **Quadro D** apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados. Além dos _guidelines_ selecionados foram acrescentadas 2 atualizações de _guidelines_ da ECCO, publicados após a realização da pesquisa.  
**Quadro E** - Busca por consensos e _guidelines internacionais_ sobre diagnóstico  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via|“Colitis, Ulcerative/diagnosis”[Mesh] AND|18|6|
|PubMed)|((Consensus Development Conference[ptyp] OR|||
||Consensus Development Conference, NIH[ptyp] OR||**Motivo das exclusões:**|
|Data da busca:|Guideline[ptyp] OR Government Publications[ptyp])||- 12 g_uidelines_desatualizados|
|20/04/2017|AND (“2001/01/01”[PDAT] : “3000/12/31”[PDAT])<br>AND “humans”[MeSH Terms] AND (English[lang]<br>OR Portuguese[lang] OR Spanish[lang]))||ou com menor relevância<br>internacional|
|National|https://www.guideline.gov/search?q=colitis+ulcerati|10|0|
|Guideline|ve&page=1&f_Guideline_Category=Diagnosis|||
|Clearinghouse|||**Motivo das exclusões:**<br>- Nenhum relacionado a RCU|
|Data da busca:||||
|20/04/2017||||  
Para informações adicionais de **dados nacionais sobre a doença** , também foi realizada uma busca, conforme o **Quadro**  
**E** , que apresenta as estratégias de buscas feitas, bem como o número de artigos localizados e o número dos selecionados.  
A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Estudos com dados epidemiológicos nacionais;  
- Consenso nacional;  
- Estudos de coorte.  
**Quadro F** - Busca por dados nacionais sobre a doença  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline|“Colitis, Ulcerative”[Mesh] AND|27|5|
|(via PubMed)|“Brazil”[Mesh] AND|||
||((“2002/01/01”[PDAT] :||**Motivo das exclusões:**|
|Data da busca:|“3000/12/31”[PDAT]) AND||- 10 não responderam a pergunta PICO,|
|27/04/2017|“humans”[MeSH Terms] AND||- 2 tratamento de outra doença|
||(English[lang] OR Portuguese[lang]||- 3 revisões não sistemáticas|
||OR Spanish[lang]))||- 7 não apresentavam dados epidemiológicos|
||||de interesse|  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
||‘ulcerative colitis’/exp AND<br>‘brazil’/exp AND ([english]/lim OR<br>[portuguese]/lim OR [spanish]/lim)<br>AND [humans]/lim AND [2002-<br>2017]/py|64|4<br>(mesmos selecionados d medline)<br>**Motivo das exclusões:**<br>- 20 não responderam a pergunta PICO,<br>- 14 tratamento de outra doença<br>- 7 revisões não sistemáticas<br>- 04 não avaliaram desfechos de interesse<br>- 9 não apresentavam  dados epidemiológicos<br>de interesse<br>- 5 estudo pré clínico<br>- 1 estudo não randomizado|  
A versão anterior do PCDT tinha 22 referências. Nesta versão, 14 delas foram retiradas e 83 acrescentadas. Destas, 74 foram selecionadas conforme pesquisa sistematizada descrita acima. Foram também utilizados como referência 4 livros de texto (já citados na versão anterior) e 9 referências de conhecimento dos autores.  
Nas tabelas A, B e C foram resumidos os artigos de maior relevância, estudos randomizados ou meta-análises identificados na pesquisa da literatura relacionados à eficácia dos medicamentos para o tratamento da RCU. Quando identificadas múltiplas meta-análises sobre o mesmo tema, foram selecionadas as mais recentes, com maior pontuação no AMSTAR e com publicação com maior impacto.  
**Tabela A -** Artigos selecionados: intervenções terapêuticas - mesalazina  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|Marshall, 2010<br>“Rectal 5-<br>aminosalicylic<br>acid for|RS e meta-análise de<br>ECR (Cochrane)|Paciente com > 12<br>anos, com RCU<br>distal (até 60 cm)|Mesalazina<br>tópica|Placebo, enema<br>de corticoide,<br>mesalazina<br>(diferentes|**Primário:**<br>Resposta clínica<br>**Secundário:**|**Mesalazina Tópica Vs Placebo:**<br>Resposta clínica (8 ECR):<br>RR=8,87 (5,30-14,83)<br>Remissão clínica (8 ECR):|<br> <br>Heterogeneidad<br>e<br>Desfechos não|
|INDUCTION of<br>remission in<br>ulcerative<br>colitis”||||doses)|Remissão<br>clínica,<br>remissão<br>endoscópica,|RR= 8,30 (4,28-16,12)<br>Remissão endoscópica (7 ECR)<br>RR=5,31 (3,15 – 8,92)|uniformes entre<br>estudos|
|(40)|||||melhora<br>histológica|**Mesalazina Tópica VS enema**<br>**de corticoide:**Mesalazina é<br>superior em resposta e remissão<br>clínica. Sem superioridade nos<br>demais desfechos<br>Resposta clínica (6 ECR):<br>RR 1,56 (1,15-2,11)<br>Remissão clínica (6 ECR):<br>RR 1,65 (1,11-2,45)||
|||||||**Mesalazina Tópica Vs**<br>**Mesalazina VO:**Não houve<br>superioridade<br>Resposta clínica:<br>OR= 2,25 (0,53-9,54)<br>Não houve diferença de eficácia<br>entre diferentes doses do<br>medicamento tópico||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|||||||**Comentário:**mesalazina é<br>superior ao placebo em todos os<br>desfechos||
|Marshall, 2012<br>“Rectal 5-<br>aminosalicylic<br>acid for<br>MAINTENANC|RS e Meta-análise de<br>ECR (Cochrane)<br>4 ECR|Paciente com > 12<br>anos, com RCU<br>distal (até 60 cm)<br>em remissão clínica|Mesalazina<br>tópica|Placebo, enema<br>de corticoide,<br>mesalazina<br>(diferentes<br>doses) por no|**Primário:**<br>Manutenção da<br>Remissão<br>clínica,<br>endoscópica ou|**Mesalazina tópica Vs Placebo:**<br>**Remissão clínica:**<br>63% vs 30%<br>RR=2,22 (1,26-3,9)<br>N=301|Heterogeneidad<br>e<br>GRADE baixo|
|E of remission in<br>ulcerative<br>colitis”||||mínimo 6<br>meses|histológica|I²= 67%<br>**Remissão endoscópica:**75% vs<br>15%|Diferentes<br>definições de<br>atividade|
|(41)||||||RR=4,88 (1,31-18,18)|clínica|
|||||||**Mesalazina tópica Vs**<br>**Mesalazina VO**<br>**Remissão clínica:**<br>80% vs 65%<br>RR=1,24 (0,92-1,66) I²=0%<br>**Remissão endoscópica:**80% vs<br>70%<br>RR 1,14 (0,90-1,45)<br>I² = 0%<br>Não houve diferença quanto a<br>eventos adversos||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|||||||Não houve diferença estatística<br>entre diferentes doses da terapia<br>tópica||
|Wang, 2016<br>“Oral 5-<br>aminosalicylic<br>acid for<br>INDUCTION of<br>remission in<br>ulcerative<br>colitis” (53)|RS com meta-análise<br>de ECR (Cochrane)|Adultos com RCU<br>ativa leve à<br>moderada|Mesalazina|Placebo e<br>Sulfassalazina|**Primário:**falha<br>em induzir<br>remissão clínica<br>**Secundário:**<br>falha em induzir<br>remissão<br>endoscópica|**Falha em induzir Remissão**<br>**Clínica (**11 ECR)<br>5-ASA vs. Placebo<br>OR=0,86 (0,82-0,89); NNT=9<br>I²=47%<br>5-ASA vs. Sulfassalazina (9<br>ECR)<br>OR=0,9 (0,77-1,04); I²=NSA||
|||||||**Falha em induzir Remissão**<br>**Endoscópica (**4 ECR)<br>5-ASA Vs. Placebo<br>OR=0,77 (0,67-0,89)<br>I²=42%<br>**Falha em induzir Remissão ou**<br>**melhora Endoscópica (**8 ECR)||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|||||||5-ASA Vs. Sulfassalazina<br>OR=0,82 (0,65-1,02)<br>I²= NSA||
|Wang, 2016<br>“Oral 5-<br>aminosalicylic<br>acid for<br>MAINTENANC<br>E of remission in<br>ulcerative<br>colitis” (55)|RS com meta-análise<br>de ECR (Cochrane)|Adultos com RCU<br>em remissão clínica<br>(critérios de True<br>love)|Mesalazina|Placebo,<br>Sulfassalazina e<br>Outras<br>formulações de<br>5-ASA|**Primário:**falha<br>em manter<br>remissão clínica<br>(recidiva clínica<br>ou endoscópica)<br>**Secundário:**<br>Falha a adesão<br>Presença de<br>evento adverso<br>Suspensão do<br>tratamento por<br>evento adverso<br>Pacientes que<br>deixaram estudo|**Falha em manter remissão**<br>**clínica (**12 ECR)<br>**5- ASA Vs Placebo (**7 ECR)<br>41% vs 58%<br>RR=0,69 (0,62-0,77) I=15%<br>**5-ASA Vs Sulfassalazina (**8<br>ECR)<br>48% vs 43%<br>RR=1,14 (1,03-1,27) I=17%<br>**Análises secundárias:**<br>Estudo com desfecho aos 12<br>meses<br>RR=1,1 (0,98-1,23)<br>Excluídos olsalazine RR=1,08<br>(0,92-1,26)<br>5-ASA VS 5-ASA<br>Não houve diferença entre<br>diferentes apresentações<br>Não houve diferença entre dose<br>única e doses dividida||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|||||||Tendência a maior benefício<br>doses > 2g||
|||||||**Segurança:**<br>Não houve diferença estatística<br>quando a presença de eventos<br>adversos quando comparado 5-<br>ASA a placebo, sulfassalazina ou<br>outras formulações de 5-ASA.||  
**Legenda:** 5-ASA: 5-aminossalicilato (mesalazina); RS: revisão sistemática; ECR: ensaio clínico randomizado; RR: risco relativo; OR: _Odds ratio,_ IC 95%: intervalo de confiança de 95%; RCU= Retocolite Ulcerativa; VO: via oral;  
NNT: número necessário tratar; NSA: não se aplica; I²: índice de heterogeneidade; I²=NS: heterogeneidade não significativa (Q de Cochran P >0,05);  
**OBS** : Nas revisões sistemáticas da Cochrane citadas foram incluídos estudos com outras formulações 5-ASA indisponíveis no Brasil (Ex: olsalazine e balsalazide).  
**Tabela B** - Artigos selecionados: intervenções terapêuticas - azatioprina  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|Timmer, 2016<br>“Azathioprine|RS com meta-<br>análise de|Adultos com<br>RCU em|Azatioprina ou<br>6-MP|Placebo ou<br>outra terapia|**Primário:**<br>falha em|7 estudos incluídos|Foram incluídos<br>estudos não cegados.|
|and 6-|ECR|remissão||de manutenção|manter|**AZA vs Placebo (N=232)**||
|mercaptopurine<br>for maintenance|(Cochrane)|clínica e<br>endoscópica|||remissão<br>clínica ou|Eficácia:<br>44% vs 65%|Amostra pequena para<br>avaliar EA|
|of|||||endoscópica em|RR=0,68 (054-0,86)||
|remission in|||||12 meses|I²=0%|Comparação com 5-|
|ulcerative|||||(recidiva|EA: 8 % vs 3 %|ASA, ciclosporina e|
|colitis”(60)|||||clínica ou<br>endoscópica)|RR=2,5 (0,82-7,74)<br>I²= 0%|metotrexato incluiu<br>um estudo cada com<br>qualidade da<br>evidência muito baixa<br>(GRADE)|
|Khan, 2011|RS com meta-|Adultos com|Azatioprina, 6-|Placebo ou|**Indução:**|2 ECR com AZA|Um estudo avaliou|
|“Efficacy of|análise de|RCU em|MP|ausência de|Remissão|2 ECR com MTX|desfecho após 1 mês e|
|Immunosuppressi<br>ve Therapy for|ECR|atividade e<br>remissão|Metotrexato,<br>ciclosporina ou|intervenção|clínica e<br>endoscópica|**Indução**|outros 2 após 4 meses.|
|Inflammatory||clínica|tacrolimo|||AZA vs Placebo (N=130)|Heterogeneidade|
|Bowel Disease: A|||||**Manutenção:**|Eficácia:|elevada entre os dois|
|Systematic|||||Reativação|RR= 0,87 (0,71-1,01)|estudos do MTX|
|Review and|||||clinica ou|MTX por via oral vs Placebo (N=67)||
|Meta-|||||endoscópica|Eficácia:||
|Analysis”(59)||||||RR= 1,29 (0,95-1,75)<br>Ciclosporina EV vs placebo (N=19)<br>Eficácia:||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|||||||RR=0,22 (0,07- 0,67)<br>**Manutenção**<br>AZA vs Placebo (N=127)<br>Reativação:<br>39% vs 65%<br>RR=0,6 (0,37- 0,95)<br>I= 24%<br>MTX intramuscular Vs Placebo<br>Reativação:<br>32% vs 36%<br>RR=0,59 (0,04 -7,90) I²=70%<br>Dados sobre Doença de Crohn não<br>incluídos nesta Tabela||
|Gisbert 2009<br>“Meta-analysis:|RS com meta-<br>análise de|Adultos com<br>RCU em|Azatioprina ou<br>6-MP|Placebo ou 5-<br>ASA|**Indução:**<br>remissão|4 ECR:<br>**Indução:**||
|the efficacy of|ECR|atividade ou|||clínica e|AZA Vs Placebo ou 5-ASA (N=169)||
|azathioprine and<br>mercaptopurine<br>in ulcerative<br>colitis”(58)||em remissão<br>clínica|||endoscópica<br>**Manutenção:**<br>Ausência de<br>reativação<br>clinica ou<br>endoscópica|Eficácia:<br>RR=1,59 (0,59 -4,29)<br>6 ECR:<br>**Manutenção**<br>AZA vs Placebo ou 5-ASA (n=236)<br>Eficácia:<br>59% vs 37%<br>RR=2,56 (1,51 – 4,34) I²=29%<br>NNT= 5||  
|**Autor**|**Delineamento**<br>**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|
||||||30 Estudos não controlados<br>Eficácia média=65%||
||||||Eficácia em dependentes de<br>corticocoide =71%||  
**Legenda:** 5-ASA: 5-aminossalicilato; 6-MP: 6 mercaptopurina; AZA: Azatioprina RS: revisão sistemática; MTX: Metotrexato; EA: Evento adverso; ECR: ensaio clínico randomizado; RR: risco relativo; IC 95%: intervalo de confiança de 95%; RCU= Retocolite Ulcerativa; NNT: número necessário tratar; NSA: não se aplica; I²: índice de heterogeneidade; (Q de Cochrane P >0,05).  
**Tabela C** - Artigos selecionados – colite aguda grave – ciclosporina e infliximabe  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|Narula, 2016<br>“Systematic Review<br>and Meta-Analysis:|RS e meta-<br>análise de<br>ECR e ECNR.|Adultos com colite<br>aguda grave refratária a<br>corticoide.|Infliximabe|Ciclosporina|**Primário:**Melhora<br>clínica curto prazo.<br>**Secundário:**taxa|**Meta-análise dos 3 ECRs**<br>IFX vs Ciclosporina<br>Resposta: 43% vs 41%|Incluiu estudos<br>abertos, não<br>randomizados e|
|Infliximab or|||||de colectomia em 3|RR=1,08 (0,73-1,60)|de coorte|
|Cyclosporine as|||||e 12 meses.|Colectomia 3º mês: 26% vs||
|Rescue Therapy in||||||26%||
|Patients With Severe||||||RR=1 (0,64-1,59)||
|Ulcerative Colitis||||||Colectomia 12º mês: 34%||
|Refractory to||||||vs 40%||
|Steroids”(78)||||||RR=0,76 (0,51-1,14)||
|||||||**Estudos não**<br>**randomizados/**<br>**controlados**<br>IFX vs Ciclosporina<br>Resposta:<br>74% vs 55%<br>RR=2,96 (2,12-4,14)||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Limitações**|
|---|---|---|---|---|---|---|---|
|||||||Colectomia 3° mês<br>24% vs 42%<br>RR=0,53 (0,22-1,28)<br>Colectomia 12º mês 20% vs<br>36%<br>RR=0,42 (0,22-0,83)||
|Ordas, 2017<br>“Long-Term Efficacy<br>and Safety of<br>Cyclosporine in a<br>Cohort of Steroid-<br>Refractory Acute|Coorte<br>prospectiva<br>multicêntrica.|Adultos com colite<br>aguda grave refratária a<br>corticoide tratados com<br>IFX ou ciclosporina.|Ciclosporina|Infliximabe ou<br>tratamento<br>“sequencial”<br>IFX ><br>ciclosporina ou<br>ciclosporina >|**Primário:**Taxa de<br>colectomia a curto<br>(menos de 3 meses)<br>e longo prazo (mais<br>de 3 meses).|**Ciclosporina Vs IFX   Vs**<br>**“Sequencial”**<br>Coletomia 3º mês    15,6%<br>vs 13,5% (p=0,4) vs 31,7%<br>(p=0,009)|Descrito<br>resultado do<br>período de<br>coleta<br>prospectivo e<br>com uso de|
|Severe Ulcerative||||IFX.||Colectomia 12º mes19,6%|ambos|
|Colitis Patients from<br>the ENEIDA<br>Registry (1989–<br>2013): A Nationwide<br>Multicenter<br>Study”(79)||||||vs 23,6% (p=0,5) vs 41,7%<br>(p=0,001)<br>Colectomia 5 anos   25,4%<br>vs 26,2% (p=0,3) vs 45%<br>(p=0,005)<br>**Eventos adversos graves**<br>Ciclosporina 15,4% vs<br>Infliximabe 26%<br>sequencial=33% (p=0,0001)|medicamentos<br>(após o ano de<br>2005)|  
**Legenda:** RS: revisão sistemática; IFX: infliximabe; Vs: versus; EA: evento adverso; ECR: ensaio clínico randomizado; ECNR: Ensaio Clínico não-randomizado; RR: risco relativo; IC 95%: intervalo de confiança de 95; I²: índice de heterogeneidade; (Q de Cochrane P>0,05).  
**Tabela D** - Artigos selecionados – intervenção terapêutica - terapia biológica  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Observação**|
|---|---|---|---|---|---|---|---|
|Lopez, 2015|Meta-análise<br>de ECR|RCU<br>moderada a|Infliximabe,<br>adalimumabe|Placebo|Resposta clínica,<br>remissão clínica,|**Indução – Remissão clínica:**<br>ADA 160/80: RR=0,91 (0,87 - 0,96)|Dados da meta-<br>análise não|
|“Efficacy of tumour||grave.|ou||cicatrização da|IFX 5mg/kg: RR-0,71 (0,64 – 0,79)|descritos, pois,|
|necrosis factor<br>antagonists on<br>remission,<br>colectomy and|||golimumabe<br>(dados não<br>incluídos<br>nesta tabela).||mucosa nas<br>semanas 6-8 e 52-<br>54, taxa de<br>colectomia,|IFX 10mg/kg: RR= 0,78 (0,71- 0,86)<br>**Manutenção – Remissão clínica**<br>ADA : RR=0,90(0,84 – 0,97)|incluíram<br>golimumabe na<br>análise.|
|hospitalisations in<br>ulcerative colitis:<br>Meta-analysis of<br>placebo-controlled<br>trials”(64)|||||hospitalização pela<br>RCU.|IFX : RR=0,78(0,69 – 0,88)<br>**Indução cicatrização da mucosa**<br>ADA 160/80: RR 0,87 (0,78 – 0,98)<br>IFX 5 mg/kg: RR 0,57 (0,48 – 0,69)<br>IFX 10 mg/kg: RR 0,59 (0,49 – 0,70)<br>**Hospitalização**<br>ADA + IFX RR=0,71 (0,56 – 0,90)<br>**Colectomia**<br>ADA + IFX RR0,87 (0,4 – 1,81)**NS**||
|Lawson,  2006<br>“Tumour necrosis|RS com meta-<br>análise de|RCU ativa|Infliximabe|Outro<br>medicamento|Primária:<br>Remissão|**Infliximabe Vs Placebo (N=484)**<br>Remissão sem 8 RR= 3,3(2,18 -4,76)||
|factor alpha|ECR|||ou placebo|(Definida no|**NNT=5**||
|blocking agents for<br>induction of|(Cochrane)||||estudo original)|Remissão endoscópica<br>- sem 8 RR=1,88 (1,54-2,28)**NNT=4**||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Observação**|
|---|---|---|---|---|---|---|---|
|remission in<br>ulcerative colitis”|||||Secundária:<br>Melhora clínica,<br>endoscópica ou<br>histológica<br>Melhora na<br>qualidade de vida.|Resposta Clínica RR=1,99 (1,65 – 2,41)<br>Colectomia RR=0,44 (0,22-0,87)<br>Qualidade de vida: sem diferença<br>estatística no IBDQ<br>OBS: 2 estudos com N = 45 e 43 não<br>identificaram benefício do infliximabe,<br>pela heterogeneidade foram não<br>incluídos na meta-análise<br>**Infliximabe Vs Prednisolona**<br>Incluídos 2 estudos com N=13 e 20<br>Não houve diferença estatística em<br>nenhum dos desfechos estudados||
|Rutgeerts, 2005<br>“Infliximab for<br>Induction and<br>Maintenance|ECR|Retocolite<br>moderada a<br>grave (Mayo<br>6-12) apesar|Infliximabe 5<br>mg/kg ou 10<br>mg/kg|Placebo|Primário: resposta<br>clínica na semana<br>8|**ACT 1 N= 364 ACt2 N=364**<br>**(resultado abaixo do estudo ACT1)**<br>**Resposta clínica sem 8**<br>Placebo= 37,2%|31% do ACT e<br>29 % do ACT2<br>era refratários<br>ao corticoide|
|Therapy for||do uso de|||Secundários:|IFX 5 mg/kg = 69,4%   p=0,001||
|Ulcerative||corticoide|||resposta clínica ou|IFX 10 mg/kg =61,5 % p=0,001||
|Colitis”<br>(ACT 1 e<br>ACT2)(37)||com ou sem<br>imunossupress<br>or.<br>OBS: No ACT<br>2 podiam estar<br>em uso de|||remissão clínica<br>com suspensão dos<br>corticoides na<br>semana 30,<br>remissão clínica e<br>cicatrização<br>mucosa na semana|**Remissão clínica sem 8**<br>Placebo=14,9%<br>IFX 5 mg/kg = 38,8%   p=0,001<br>IFX 10 mg/kg =32,0%  p=0,001<br>**Cicatrização da mucosa sem 8**||  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Observação**|
|---|---|---|---|---|---|---|---|
|||aminossalicila<br>to<br>OBS2: 56%|||8 e 30, além de na<br>semana 54 no<br>estudo ACT-1, e,<br>resposta clínica em|Placebo= 33,9%<br>IFX 5 mg/kg = 62% p=0,001<br>IFX 10 mg/kg =59%  p=0,00||
|||estavam em<br>uso de<br>corticoide<br>46% estavam<br>em uso de<br>imunossupress<br>or.|||pacientes com<br>história de<br>refratariedade a<br>corticoides na<br>semana 8.|**Resposta clínica sustentada**<br>**(sem 8, 30 e 54)**<br>Placebo= 14%<br>IFX 5 mg/kg = 38,8% p=0,001<br>IFX 10 mg/kg =36,9% p=0,001<br>**Remissão clínica sustentada**<br>**(sem 8, 30 e 54)**<br>Placebo= 6,6%<br>IFX 5 mg/kg = 19,8% p=0,001<br>IFX 10 mg/kg =20,5% p=0,001||
|Chen, 2016<br>“Adalimumab for<br>Moderately to|Meta-análise<br>de ECR|RCU em<br>atividade|Adalimumab<br>e|Placebo|Remissão clínica,<br>resposta clínica,<br>cicatrização da|**Indução 160/80 vs Placebo**<br>Resposta clínica: RR 1,37 (1,19-1,59)<br>Remissão clínica: RR 1,62 (1,15-2,29)|3 ECR<br>N=468 nos<br>desfechos|
|Severely Active|||||mucosa, IBDQ e|CM: RR: 1,27 (1,08-1,50)|clínicos e|
|Ulcerative Colitis:|||||eventos adversos.|IBDQ: RR= 1,22 (1,05-1,43)|endoscópico|
|A Systematic||||||Evento adverso: RR1,1 (0,95-1,27)||
|Review and Meta-||||||Evento adverso grave:  0,79 (0,54-1,14|NNT não|
|Analysis”(70)|||||||calculado|  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Observação**|
|---|---|---|---|---|---|---|---|
|||||||**Manutenção (52 semanas)**<br>Resposta clínica: RR 1,69 (1,29-2,21)<br>Remissão clínica: RR 2,38 (1,57-3,59)<br>CM: RR: 1,69 (1,26-2,28)<br>IBDQ: RR= 1,73 (1,28-2,34)<br>Evento adverso: RR1,28 (1,06-1,54)<br>Evento adverso grave: RR=1,09 (0,76 -<br>1,56)|2 ECR<br>N= 425 nos<br>desfechos<br>clínicos e<br>endoscópico<br>NNT não<br>calculado|
|Zhang, 2016<br>“Efficacy and<br>Safety of<br>Adalimumab in|Meta-análise<br>de ECR|RCU<br>moderada a<br>grave com<br>mais de 15|Adalimumab<br>e|Placebo|**Primário:**<br>Remissão clínica<br>na semana 8<br>(indução)|**160/80 + 80/40**<br>**Indução:**3 ECR N= 685<br>- Remissão clínica: RR=1,5 (1,08-2,09)<br>ADA 14,45 %Vs Placebo 9,75%|Análise<br>somando-se<br>doses diferentes<br>de indução|
|Moderately to||anos (escore|||**Secundário:**|RAR=4,69**NNT= 21**|160/80 e 80|
|Severely Active<br>Cases||de Mayo 6-12<br>e|||Remissão clínica<br>semana 52|- Resposta clínica: RR= 1,33 (1,16-1,52)<br>NNT=8|/40mg|
|of Ulcerative<br>Colitis: A Meta-||subescore<br>endoscópico|||(manutenção),<br>resposta clínica,|- CM: RR=1,21 (1,04-1,41) NNT= 13<br>- IBDQ: RR=1,23 (1,06-1,43)|* NNT<br>calculados a|
|Analysis of||2-3).|||cicatrização da||partir dos RR|
|Published Placebo-|||||mucosa, IBDQ e|**Manutenção:**2ECR = N=425|descritos no|
|Controlled<br>Trials”(71)|||||remissão livre de<br>corticoide na<br>semana 52<br>**Remissão clínica**:<br>escore de Mayo ≤2|- Remissão clínica: RR=2,38 (1,57-3,59)<br>ADA= 19,7% vs Placebo 8,19%<br>RAR=11,57**NNT= 9**<br>-Resposta clínica: RR1,69 (1,29-2,21)<br>- CM: RR=1,69 (1,26-2,28) NNT=8<br>- IBDQ: RR=1,73 (1,28-2,34)<br>- Evento adverso: RR1,23 (1,06-1,43)|artigo|  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Observação**|
|---|---|---|---|---|---|---|---|
||||||com escore<br>endoscópica ≤1<br>**Resposta clínica:**<br>Queda do escore<br>de Mayo ≥3 pontos<br>ou ≥30% do valor|**160/80**<br>**Indução: 3ECR N=468**<br>Remissão clínica: RR=1,62 (1,15-2,29)<br>ADA 14,45 % vs Placebo 9,75%<br>RAR=4,69**NNT= 15**<br>- Resposta clínica: RR= 1,37 (1,19-1,59)|Análise<br>somente com<br>dose de<br>indução com<br>160/80|
||||||basal com redução|NNT=7|*NNT|
||||||subescore de<br>sangramento retal<br>≥1<br>**Cicatrização da**<br>**mucosa:**<br>Subescore<br>endoscópico de<br>Mayo ≤2|- CM: RR=1,27 (1,08-1,50) NNT= 11|calculados a<br>partir dos RR<br>descritos no<br>artigo|
|Reinisch, 2011<br>“Adalimumab for|ECR|RCU<br>moderada a|Adalimumab<br>e em duas|Placebo|**Avaliados na**<br>**semana 8**|**Remissão clínica:**<br>ADA 160/80 18,5% vs Placebo 9,2%|Obs:<br>Apresentados|
|induction of clinical||grave com|doses de||**(indução)**|P=0,031|resultados com|
|remission in||mais de 15|indução:||**Primário:**|**NNT= 11**|dose de|
|moderately to||anos (escore|160/80 mg e||Remissão Clínica||indução de|
|severely active||de Mayo 6-12|80/40 mg.||**Secundário:**|**Resposta clínica:**|160/80 mg|
|ulcerative colitis:||e subescore|||Resposta clínica,|ADA 160/80 54,6% vs Placebo 44,6%||
|results of a||endoscópico|||CM.|*Sem diferença estatística||
|randomised||2-3) apesar do||||**Cicatrização da mucosa**||
|controlled trial”||tratamento||||ADA 160/80 46,9% vs Placebo 41,5%||
|ULTRA 1(69)||com||||*Sem diferença estatística||  
|**Autor**|**Delineamento**|**População**|**Intervenção**<br>**Comparador**|**Desfechos**|**Resultados**|**Observação**|
|---|---|---|---|---|---|---|
|||corticoide ou<br>imunossupress<br>or<br>*Pacientes<br>com retite<br>foram<br>excluídos.|||||
|Sandborn, 2012<br>“Adalimumab<br>Induces and<br>Maintains Clinical<br>Remission in<br>Patients With<br>Moderate-to-Severe<br>Ulcerative Colitis”<br>ULTRA 2(68)|ECR|RCU<br>moderada a<br>grave (escore<br>de Mayo  6-12<br>e subescore<br>endoscópico<br>2-3).|Adalimumab<br>e indução<br>com 160/80<br>mg e<br>manutenção<br>de 40 mg a<br>cada 2<br>semana.<br>Placebo|**Primário**<br>Remissão clínica<br>sustentada na<br>semana 8 e 52.<br>**Secundário:**<br>Resposta clínica<br>sustentada<br>Cicatrização da<br>mucosa sustentada.|**Remissão clínica sustentada**<br>**ADA Vs Placebo**<br>Sem 8: 16,5% vs 9,3% * NNT=14<br>Sem 52: 17,3% vs 8,5% * NNT=11<br>**Resposta clínica sustentada**<br>Sem 8: 50,4% vs 34,6%* NNT=6<br>Sem 52: 30,2% vs 18,3%*NNT=8<br>**Cicatrizaçao da mucosa**<br>Sem 8: 41,1% vs 31,7% * NNT=11<br>Sem 52: 25% vs 15,4 * NNT=11<br>*p<0,05<br>Análise de subgrupo – Remissão clínica<br>nos pacientes com uso prévio de Anti-<br>TNF (40% da amostra)<br>- Sema 8: ADA 3,6% x 2,8% p=0,56|Paciente com<br>resposta<br>inadequada na<br>semana 12<br>poderiam ser<br>trocados para<br>grupo<br>Adalimumabe<br>aberto.<br>Se persistisse<br>sem resposta,<br>havia redução<br>do intervalo<br>para aplicações<br>semanais|  
|**Autor**|**Delineamento**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Resultados**|**Observação**|
|---|---|---|---|---|---|---|---|
|||||||- Semana 52 (N=13): ADA  4% x 1,2%<br>p=0,04||
|Bickston, 2014<br>“Vedolizumab for<br>induction and<br>maintenance of<br>remission in<br>ulcerative colitis”|RS com meta-<br>análise de<br>ECR<br>(Cohcrane).|RCU com<br>idade ≥18<br>anos, ativa ou<br>em remissão.|Vedolizumab<br>e|Placebo ou<br>terapia<br>controle|**Primário:**<br>Proporção de<br>pacientes que<br>falharam em<br>atingir remissão<br>clínica e proporção<br>de pacientes que<br>tiveram reativação<br>da doença.<br>**Secundário:**<br>Proporção de<br>pacientes que<br>falharam em<br>atingir melhora<br>clínica, remissão<br>endoscópica,<br>qualidade de vida,<br>eventos adverso,<br>suspensão por<br>eventos adversos e<br>eventos adversos<br>graves.|**N=606 pacientes (4 ECR0**<br>**VDZ Vs Placebo**<br>- Falha em induzir remissão clínica<br>**RR=0,86 (0,80 – 0,91)**<br>- Falha em induzir remissão<br>**RR=0,68 (0,59-0,78)**<br>- Falha em induzir remissão Endoscópica<br>**RR=0,82 (0,75-0,91)**<br>-Reativação clínica<br>**RR=0,67 (0,59-0,77)**<br>- Recidiva endoscópica<br>**RR=0,58 (0,49- 0,68)**<br>- Eventos adversos<br>RR=0,99 (0,93-1,07)<br>- Evento adverso grave<br>RR= 1,01 (0,72 – 1,42)||  
**Legenda** : RS: revisão sistemática; IFX: infliximabe; Vs: versus; VDZ= vedolizumabe; ADA= adalimumabe; EA: evento adverso; RS: Revisão sistemática; ECR: ensaio clínico randomizado; ECNR: Ensaio Clínico não-randomizado; CM: cicatrização da mucosa; NNT: número necessário tratar; RR: risco relativo; IC 95%: intervalo de confiança de 95; I²: índice de heterogeneidade; (Q de Cochrane P>0,05);  IBDQ= Questionário  de DII (avalia qualidade de vida); Anti-TNF: Anti-Fator de Necrose Tumoral; Sem = Semana.

---

<!-- METADADOS: doenca: Retocolite Ulcerativa | secao: HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO -->
|**Número do Relatório da diretriz**||**Tecnologias avaliada**|**s pela Conitec**|
|---|---|---|---|
|**clínica (Conitec) ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no SUS**|**Não incorporação ou não alteração no SUS**|
|Relatório de Recomendação nº||Inclusão de nova apresentação de mesalazina (sachê||
|869/2023|Atualização devido à ampliação|2g) para o tratamento de retocolite ulcerativa leve a||
|Portaria<br>Conjunta<br>SAES-<br>SECTICS/MS nº xxx/2024|de uso de tecnologias no SUS|moderada em adultos. Relatório Técnico nº 801/2023 e<br>Portaria SCTIE/MS nº 15/2023|-|
|||Incorporar: Tofacitinibe para o tratamento de retocolite||
|Relatório de Recomendação nº<br>684/2021<br>Portaria Conjunta SAES-SCTIE/MS<br>nº 14/2021|Atualização<br>devido<br>à<br>incorporação de tecnologias no<br>SUS|ulcerativa ativa moderada a grave em pacientes adultos<br>com resposta inadequada, perda de resposta ou<br>intolerantes ao tratamento prévio com medicamentos<br>sintéticos convencionais  -Relatório Técnico nº<br>631/2021e PortariaSCTIE/MS nº31/2021|-|
|Relatório de Recomendação nº<br>514/2020<br>Portaria Conjunta SAES-SCTIE/MS<br>nº 6, de 26 de março de 2020|Incorporação de tecnologias no<br>SUS|Infliximabe e vedolizumabe para tratamento da<br>retocolite ulcerativa moderada a grave.  Relatório<br>Técnico nº 480/ 2019 e Portaria SCTIE/MS nº 49, 22<br>de outubro de 2019.|Não incorporar:<br>Adalimumabe e golimumabe para tratamento da<br>retocolite<br>ulcerativa<br>moderada<br>a<br>grave.<br>Relatório Técnico nº 480/ 2019 e  Portaria<br>SCTIE/MS nº 49, 22 de outubro de 2019.|  
|Portaria SAS/MS nº 861, de 04 de<br>Elaboração da primeira versão|
|---|
|novembro de 2002<br>do Protocolo<br>-<br>-|

---

