<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 11, DE 16 DE SETEMBRO DE 2024.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas das Estratégias para Atenuar a Progressão da Doença Renal Crônica.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024, e  
Considerando a necessidade de se estabelecerem os parâmetros sobre a estratégias para atenuar a progressão da Doença Renal Crônica (DRC) no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os Protocolos Clínicos e Diretrizes Terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 824/2023 e o Relatório de Recomendação n<sup><u>o</u></sup> 827/2023 – de maio de 2023, da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), a atualização da busca e avaliação da literatura;  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas (PCDT) das Estratégias para Atenuar a Progressão da Doença Renal Crônica.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da Doença Renal Crônica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da doença renal crônica.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: CARLOS AUGUSTO GRABOIS GADELHA -->
**ANEXO**

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **1. INTRODUÇÃO** -->
Este Protocolo visa a estabelecer os critérios diagnósticos da doença renal crônica (DRC) e as estratégias terapêuticas para atenuar sua progressão. Ele complementa as orientações das Diretrizes Clínicas para o Cuidado ao Paciente com DRC vigente. Ainda, o cuidado de pacientes com DRC também inclui as orientações dos Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Distúrbio Mineral Ósseo na DRC e de Anemia na DRC.  
A DRC é uma condição clínica definida pela presença de anormalidade estrutural ou funcional renal, durante um período de pelo menos três meses, com a perda progressiva da função dos néfrons e consequente perda de sua capacidade de filtrar o sangue e manter a homeostase<sup>1-4</sup> . As diversas funções renais, como a excreção de produtos finais de diversos metabolismos, produção de hormônios, controle do equilíbrio hidroeletrolítico, do metabolismo ácido-básico e da pressão arterial, são gradativamente impactadas<sup>4,5</sup> .  
Sabe-se que, apesar dos néfrons suportarem aumento transitório na carga de filtração glomerular, elevações persistentes da taxa de filtração glomerular (TFG) e da pressão de filtração (hipertensão glomerular) desencadeiam processos inflamatórios deletérios e estresse oxidativo que culminam com a esclerose glomerular e a fibrose túbulo-intersticial, ou seja, com a DRC e sua progressão<sup>4,5</sup> .  
Diferentes mecanismos podem estar envolvidos na fisiopatologia e progressão da DRC, sendo múltiplas as causas e os fatores prognósticos. Além disso, muitos fatores estão associados tanto à etiologia quanto à progressão da perda de função renal, sendo considerados fatores de risco para o desenvolvimento e a progressão da doença<sup>4-6</sup> :  
a) diabetes;  
b) hipertensão;  
c) senilidade;  
- d) obesidade;  
e) antecedentes de doença do aparelho circulatório (doença coronariana, acidente vascular cerebral, doença vascular periférica, insuficiência cardíaca);  
f) histórico de DRC na família;  
g) tabagismos;  
h) uso de agentes nefrotóxicos;  
- i) doenças glomerulares;  
j) doenças genéticas (incluindo a doença renal policística autossômica dominante).  
Atualmente, a DRC se destaca como um problema de saúde pública devido à sua prevalência crescente, morbimortalidade elevada e altos custos demandados para a manutenção dos pacientes renais crônicos dialíticos nas diversas modalidades de terapia renal substitutiva (TRS) existentes (hemodiálise, diálise peritoneal e transplante renal)<sup>6-11</sup> .  
Em 2017, um total de 697,5 milhões de casos de DRC foram descritos em todo o mundo, gerando uma prevalência estimada da doença de 9,1%. Cerca de um terço de todos esses casos eram procedentes da China (132,3 milhões) e da Índia (115,1 milhões). Países como Bangladesh, Brasil, Indonésia, Japão, México, Nigéria, Paquistão, Rússia, Estados Unidos da América (EUA) e Vietnã contribuíram, cada um, com mais de 10 milhões de casos da doença<sup>7,8</sup> . No Brasil, cerca de dez milhões de pessoas têm alguma disfunção renal e a prevalência de DRC é de 50/100.000 habitantes<sup>9</sup> . Um estudo prospectivo multicêntrico  
brasileiro (2008-2010) que envolveu seis capitais (Belo Horizonte, Porto Alegre, Rio de Janeiro, Salvador, São Paulo e Vitória) e mais de 14.500 trabalhadores ativos ou aposentados com idade entre 35 e 74 anos, apontou uma prevalência geral da DRC no país de 8,9%, sendo maior em indivíduos de menor nível socioeconômico, assim como em negros e indígenas<sup>10</sup> .  
A DRC pode ser estratificada em estágios, conforme as condições clínicas do paciente. A prevalência mundial, em 2017, para cada um deles foi: estágios 1 e 2 de 5%; estágio 3 de 3,9%; estágio 4 de 0,16%; estágio 5 de 0,07%; pacientes em diálise de 0,041%; e transplantados renais de 0,011%<sup>9</sup> .  
A alta taxa de morbidade está principalmente relacionada à necessidade de TRS dos pacientes. Segundo dados da Sociedade Brasileira de Nefrologia de 2023, atualmente, 157.000 brasileiros encontram-se em TRS, ou seja, no estágio 5D da DRC<sup>11</sup> . Estudo recentemente publicado indica que os custos médios envolvidos no cuidado dos pacientes com DRC aumentam de forma substancial à medida que a doença progride. Por exemplo, no estágio G1, este valor acumulado ao longo de quatro anos está em torno de R$ 7.100, enquanto para o estágio G5, o valor ultrapassa R$ 26.800, pois o paciente apresenta maiores chances de ser encaminhado ao tratamento dialítico dentro deste período. Apesar de apresentar uma carga econômica relevante, o tratamento aplicado na etapa de pré-diálise pode reduzir em mais de R$ 33 mil o custo médio para cada ano de tratamento dialítico evitado<sup>12</sup> .  
Considerando a mortalidade por DRC, foram registrados, em 2017, cerca de 1,2 milhões de óbitos no mundo e a taxa de mortalidade pela doença aumentou 41,5% entre 1990 e 2017. Ao ser ajustada pela idade, a taxa de mortalidade por DRC aumentou em 60,9%, 60,9% e 57,3% na América Latina central, na Ásia central e na América do Norte de alta renda, respectivamente<sup>7,8</sup> .  
Prevenir a progressão da DRC, utilizando todos os esforços medicamentosos e não medicamentosos para a preservação da TFG tem impacto positivo na redução de desfechos de morbimortalidade e deve ser realizada de acordo com o estágio da DRC. Nesse contexto, a identificação de fatores de risco da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo estabelece os critérios diagnósticos da doença renal crônica (DRC) e as estratégias terapêuticas para atenuar sua progressão. O processo de desenvolvimento desse Protocolo seguiu recomendações das Diretrizes Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>13</sup> . Uma descrição mais detalhada da metodologia está disponível no **Apêndice 1** . O histórico de alterações deste Protocolo encontra-se descrito no **Apêndice 2** .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- N18.2 – Doença Renal Crônica estágio 2;  
- N18.3 – Doença Renal Crônica estágio 3;  
- N18.4 – Doença Renal Crônica estágio 4;  
- N18.5 - Doença Renal Crônica estágio 5.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **3. DIAGNÓSTICO** -->
Na maior parte do tempo, a DRC é assintomática. Desse modo, evidencia-se a relevância da realização da prevenção dos fatores de risco, do rastreamento e do diagnóstico precoce de DRC na atenção primária à saúde (APS), especialmente no que concerne às pessoas com hipertensão arterial sistêmica e diabete melito. É fundamental, ainda, que o profissional possa agregar no processo de diagnóstico a percepção de identificar e reconhecer marcadores de determinantes sociais como identidade de  
gênero, racismo, orientação sexual, etnia<sup>14</sup> e iniquidades sociais e econômicas como indicadores de saúde que podem contribuir para o desenvolvimento de situações de agravos e condições de adoecimento.  
Neste sentido, destaca-se o importante papel da APS no ordenamento do cuidado conservador da pessoa com DRC e o monitoramento para acompanhamento e tratamento de fatores de risco com vistas à prevenção de agravos, especialmente no que tange as orientações e aconselhamentos para a modificação dos modos de viver, além do estímulo ao autocuidado relativo ao tratamento não medicamentoso, bem como na detecção da DRC dos estágios 1, 2 e 3A, sendo estas as principais contribuições da APS para esta população.  
No geral, os pacientes com DRC apresentam sinais e sintomas mais evidentes nos estágios mais avançados da doença (4 e 5). Entre os sintomas destacam-se nictúria, hipertensão arterial, anemia, fraqueza, fadiga, emagrecimento, prurido, síndrome das pernas inquietas, dor crônica, sintomas gastrintestinais (inapetência, náusea, vômito, constipação), edema e dispneia e alterações urinárias (urina escura, na presença de hematúria; muito clara, se houver a diminuição da densidade urinária; espumosa, na presença de proteinúria). Nas fases mais avançadas pode haver oligúria<sup>4,5</sup> . Já as alterações laboratoriais podem estar presentes nos estágios intermediários da DRC: anemia, distúrbios do cálcio, fósforo e paratormônio, também chamado de distúrbios do metabolismo mineral e ósseo (DMO), e acidose metabólica, o principal distúrbio acidobásico na DRC<sup>1,2,4,5</sup> .  
O diagnóstico da doença ocorre pela identificação da perda da função renal, independente da causa, durante um período superior a três meses, com implicações para a saúde<sup>15</sup> . Essa identificação é feita por meio da avaliação da taxa de filtração glomerular (TFG < 60 mL/min/1,73 m²), calculada por meio de fórmulas, que serão abordadas a seguir. Nos casos de pacientes com TFG ≥ 60 mL/min/1,73 m², o diagnóstico de DRC é realizado pela identificação de pelo menos um marcador de dano renal parenquimatoso ou de alteração no exame de imagem, preferencialmente ultrassonografia dos rins e vias urinárias<sup>1</sup> .  
Uma das maiores causas de morbimortalidade em pacientes com DRC são as doenças cardiovasculares ateroscleróticas. Dessa forma, o risco cardiovascular deve ser estimado na avaliação inicial e periodicamente, pelo menos uma vez ao ano, em pacientes com DRC. Isto permite implementar intervenções preventivas necessárias para reduzir complicações cardiovasculares e aumentar a qualidade de vida desses pacientes.<sup>16-19</sup>  
Além da avaliação clínica e laboratorial, é recomendado o uso de uma ferramenta validada para estimar o risco cardiovascular dos pacientes com DRC. Embora existam várias calculadoras para avaliação do risco cardiovascular, no Brasil, para indivíduos entre 40 e 74 anos de idade é recomendada a calculadora HEARTS/OPAS/OMS, que utiliza parâmetros definidos a partir do estudo _Global Burden Disease_ (GBD), considerando os dados de estimativa populacional brasileira. Por permitir a estratificação do risco cardiovascular utilizando critérios laboratoriais e não laboratoriais, a calculadora HEARTS é considerada uma ferramenta de fácil aplicabilidade para estimar o risco cardiovascular. A calculadora é de livre acesso e está disponível em: https://www.paho.org/pt/hearts-nas-americas/calculadora-risco-cardiovascular.<sup>20-22</sup>  
**Avaliação da Taxa de Filtração Glomerular:** para a avaliação da TFG deve-se evitar o uso da depuração de creatinina medida da coleta de urina de 24 horas pelo potencial de erro de coleta, além dos inconvenientes da coleta temporal. Deve-se, portanto, utilizar fórmulas baseadas na creatinina sérica para estimar a TFG. Recomenda-se o uso da fórmula CKD-EPI ( **Quadro 1** )<sup>23,24</sup> . No passado, a fórmula de Cockcroft-Gault foi a mais utilizada para estimar a depuração de creatinina, contudo, seu uso não é recomendado porque necessita da correção para a superfície corpórea, além de apresentar vieses na correlação com a TFG. O cálculo da TFG é recomendado para todos os pacientes sob o risco de desenvolver DRC. Todos os pacientes que se encontram no grupo de risco para a DRC devem dosar a creatinina sérica e ter a sua TFG estimada<sup>1,4,5</sup> .  
**Quadro 1** - Fórmula para estimar a taxa de filtração glomerular.  
|**Fórmula**|**Cálculo da T**|**FG**||**Valores a serem considerados**|
|---|---|---|---|---|
|CKD-EPI|𝑇𝐹𝐺= 𝐴 𝑥|(~~(~~<sup>𝐶𝑟𝑒𝑎𝑡𝑖𝑛𝑖𝑛𝑎</sup><br>𝐵<br>)<br>𝐶<br>)|𝑥 𝐼𝑑𝑎𝑑𝑒<sup>0,993</sup>|A<br>Mulher = 166; Homem = 163<br>Mulher = 144; Homem = 141|  
|**Fórmula**|**Cálculo da TFG**|**Valores a serem considerados**|
|---|---|---|
|||B<br>Mulher = 0,7; Homem = 0,9|
|||C<br>Creatinina > 0,7 = -1,209<br>Creatinina ≤ 0,7: Mulher = 0,329; Homem = 0,411|  
**Legenda:** CKD-EPI: _Chronic kidney disease Epidemiology Collaboration_ ; TFG – Taxa de filtração glomerular.  
**Fonte** : adaptado de Levey AS _et al._ , Ann Intern Med. 2009; 150: 604–612.  
**Alterações parenquimatosas:** as alterações parenquimatosas devem ser pesquisadas por meio do exame sumário de urina (elementos anormais do sedimento - EAS), também conhecido como urina tipo 1; da pesquisa de albuminúria, que é a presença de albumina na urina; da análise pela biópsia renal (histologia) ou alterações eletrolíticas características de lesões tubulares renais. O EAS deve ser feito para todos os pacientes sob o risco de DRC. Deve-se considerar a hematúria de origem glomerular, definida pela presença de cilindros hemáticos ou dimorfismo eritrocitário, identificados no EAS. Nos pacientes diabéticos e hipertensos com EAS mostrando ausência de proteinúria está indicada a pesquisa de albuminúria em amostra isolada de urina corrigida pela creatinúria, a Relação Albumina Creatinina (RAC). Os valores de referência, bem como a classificação da RAC, estão apresentados no **Quadro 3** . Indivíduos com história de DRC familiar, infecção urinária de repetição e doenças urológicas devem realizar exames de imagem, preferencialmente, a ultrassonografia dos rins e vias urinárias.  
São considerados marcadores de dano renal parenquimatoso:  
- a) albuminúria ≥ 30 mg/24 horas ou RAC ≥ 30 mg/g;  
b) hematúria de origem glomerular, definida pela presença de cilindros hemáticos ou dismorfismo eritrocitário no exame de urina (EAS);  
- c) alterações eletrolíticas ou anormalidades tubulares;  
d) alterações detectadas por histologia, pela biópsia renal;  
e) alterações nos exames de imagem como rins policísticos, hidronefrose, cicatrizes corticais ou alterações da textura cortical, estenose da artéria renal.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **3.1 Classificação da doença renal crônica** -->
A DRC pode ser classificada em seis estágios ( **Quadro 2** ), a depender das alterações anatômicas ou estruturais e funcionais, sendo esta última baseada na taxa de filtração glomerular (TFG)<sup>1,2,5</sup> .  
**Quadro 2 -** Classificação da doença renal crônica de acordo com a taxa de filtração glomerular.  
|**Estágio**|**TFG**<br>**(mL/min**<br>**1,73m**<sup>**2**</sup>**)**|**por**|**Descrição**|
|---|---|---|---|
|1|≥ 90||Lesão renal com TFG normal e presença de anormalidades estruturais (albuminúria<br>≥30 mg ou alterações na imagem, histologia renal ou sedimento urinário)|
||||Lesão renal com TFG levemente diminuída e presença de anormalidades estruturais|
|2|60-89||(albuminúria ≥30 mg ou alterações na imagem, histologia renal ou sedimento<br>urinário)|
|3 A|45 a 59||TFG moderadamente diminuída|
|3 B|30 a 44||TFG moderadamente diminuída|
|4|15-29||TFG gravemente diminuída|
|5|< 15||Falência renal|  
|5D<br>< 15 em diálise|Falência renal em terapia substitutiva|
|---|---|  
**Legenda:** TFG – Taxa de filtração glomerular. **Fonte:** Adaptado do KDIGO 2012.  
A TFG e a presença de um marcador de dano renal caracterizam a evolução da DRC. A TFG é uma medida geral da função renal mais facilmente compreendida pelos profissionais de saúde, que possibilita a orientação das medidas preventivas e o encaminhamento para especialistas.  
A DRC também pode ser classificada de acordo com a presença e intensidade da RAC urinária<sup>1,2,5</sup> , conforme **Quadro 3** .  
**Quadro 3** - Classificação da doença renal crônica de acordo com a razão albumina/creatinina urinária.  
|**Estágio**|**RAC urinária (mg/g)**|**Descrição**|
|---|---|---|
|A1|<30|Normal a leve|
|A2|30- 299|Moderada|
|A3|> 300|Grave|  
**Legenda:** RAC – Relação albumina/creatinina urinária.  
**Fonte:** Adaptado do KDIGO 2012.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Pacientes adultos com diagnóstico de DRC, independente da etiologia.  
Adicionalmente, para utilizar a dapagliflozina, o paciente deve estar em uso de terapia padrão com medicamentos inibidores da enzima conversora da angiotensina (IECA) ou bloqueadores de receptores da angiotensina (BRA), e deve apresentar a TFG entre 25 e 75 mL/min, ser diabético tipo 2 ou apresentar RAC maior que 300 mg/g em não diabéticos. Vale destacar, que mesmo que o paciente apresente mudanças na TFG ou na redução da RAC com o início do tratamento com dapagliflozina, o medicamento deverá ser mantido até o início da terapia renal substitutiva.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações ao uso do respectivo medicamento ou procedimento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6. TRATAMENTO** -->
O tratamento conservador da DRC compreende o tratamento não dialítico. Seu objetivo é a manutenção da função renal e a prevenção da progressão da doença, buscando postergar a necessidade de TRS<sup>1,25-27</sup> . Quando a progressão é inexorável, o tratamento busca a atenuação na velocidade de perda da função renal. O tratamento conservador também contempla o cuidado às complicações, como anemia, hipertensão arterial, DMO, acidose e doença cardiovascular, embora essas não sejam objeto deste Protocolo<sup>28-31</sup> .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.1 Tratamento não medicamentoso** -->
O tratamento não medicamentoso consiste nas mudanças do estilo de vida, incluindo a cessação do tabagismo, a prática de exercícios físicos, no cumulativo de 150 minutos/semana e de acordo com as condições cardiovasculares, cognitivas e de tolerabilidade física individuais (2C); a redução de peso para um índice de massa corporal normal; e as orientações nutricionais,  
como restrição de sal (< 2g de sódio ao dia), exceto nas nefropatias perdedoras de sal; de fósforo na presença de hiperfosfatemia (< 800 mg/dia); de potássio na presença de hipercalemia (2-4 g ao dia) e; de proteínas na dieta<sup>1,4</sup> .  
A carga excessiva de aminoácidos oriundos da dieta causa hiperfiltração glomerular significativa e um aumento do fluxo plasmático dos rins. Dietas pobres em proteína se opõem ao aumento adaptativo da pressão capilar glomerular que ocorre nos pacientes com DRC e constituem uma medida de tratamento que pode minimizar a esclerose glomerular. Assim, a restrição de proteínas é uma intervenção nutricional cujo objetivo é retardar a progressão da DRC<sup>32-33</sup> .  
Dados experimentais e clínicos sugerem que a restrição proteica, tanto na forma de dieta hipoproteica (LPD, do inglês _Low Protein Diet_ , que consiste na ingestão diária ideal de 0,6 g de proteína/kg), quanto a dieta muito pobre em proteínas (VLPD, do inglês _Very Low-Protein Diet_ , que consiste na ingestão diária ideal de 0,3 g de proteína/kg), suplementada com cetoanálogos (CA), retarda a progressão da DRC<sup>33-36</sup> . Contudo, ainda não há evidências sobre o impacto dessas dietas na redução da necessidade da TRS e na mortalidade dos pacientes com DRC, razões pelas quais a tecnologia não foi incorporada ao SUS<sup>29</sup> .  
Diretrizes nacionais e internacionais apresentam diferentes recomendações acerca da ingestão proteica diária dos pacientes com DRC. A Sociedade Brasileira de Nutrição Parenteral e Enteral (BRASPEN) indica para pacientes adultos com DRC estágio 3 a 5 a ingestão proteica diária de 0,6 a 0,8 g/kg. Já pacientes com DRC nos estágios 4 e 5, a ingestão proteica diária de 0,3 a 0,4 g/kg, suplementada com CA, pode ser utilizada de modo a reduzir a progressão da DRC e da proteinúria, sem causar prejuízos no estado nutricional<sup>26</sup> . O recente _guideline_ proposto pela _Kidney Disease Outcomes Quality Iniciative_ (KDOQI) recomenda que pacientes adultos com DRC em estágio 3 a 5, sem diabetes melito (DM) e metabolicamente estáveis, adotem LPD ou VLPD associada à suplementação de CA para atender as necessidades requeridas de proteínas (0,55-0,60 g/kg/dia). Pacientes com DRC estágios 3 a 5 e com DM devem seguir dieta com ingestão proteica de 0,6 a 0,8 g/kg/dia, de modo a estabilizar o estado nutricional e otimizar o controle glicêmico, não sendo sugerida a VLPD associada à suplementação de CA<sup>35</sup> .  
Atualmente, segundo as Diretrizes Clínicas para o cuidado ao paciente com Doença Renal Crônica – DRC no Sistema Único de Saúde<sup>4</sup> , a recomendação do Ministério da Saúde para a DRC é de redução da ingestão de proteínas para 0,8 g/Kg/dia em adultos, acompanhado de adequada orientação nutricional, devendo-se evitar ingestão maior do que 1,3g/kg/dia nos pacientes que necessitarem, por outra indicação, ingesta acima de 0,8 g/kg/dia, para os estágios 4 e 5-ND (não dialítico). Para o estágio 5- D (em diálise), é recomendada a adequação da ingesta de proteínas de acordo com o estado nutricional.  
Destaca-se que o uso de aminoácidos, concomitante com análogos, foi avaliado pela Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) para a prevenção e tratamento de danos causados pelo metabolismo falho ou deficiente de proteínas na doença renal crônica em conjunto com uma ingestão proteica limitada, com recomendação desfavorável à sua incorporação e seguida da decisão de não incorporação pelo Ministério da Saúde (Relatório de recomendação nº 787, de novembro de 2022 - Portaria SCTIE/MS nº 169/2022)<sup>37</sup> . Para essa recomendação, a Conitec considerou que, embora haja certa evidência de que a associação do CA com a VLPD retarde a progressão da DRC quando comparada à LPD, apenas 7% dos pacientes com DRC estágios 4 e 5 seriam contemplados com a tecnologia devido à dificuldade de adesão à dieta tão restrita em proteínas. Num cenário ainda mais desfavorável, mais pacientes seriam contemplados, porém sem aderirem a VLDP, ou seja, o benefício da tecnologia não seria observado e o custo seria muito elevado.  
Os dados que justificam uma dieta baixa em proteínas foram amplamente coletados antes da adoção generalizada do bloqueio do sistema renina-angiotensina e inteiramente antes da adição de inibidores do cotransportador 2 de sódio-glicose (iSGLT2) no tratamento da DRC<sup>38</sup> .  
A diretriz atual do KDOQI preconiza a adoção de dieta individualizada para portadores de DRC estágios 3 a 5, mediante avaliação nutricional e de hábitos culturais alimentares, considerando ainda, a idade, a expectativa de vida, a presença de fragilidade e o estado nutricional do paciente. Por essas razões, este Protocolo preconiza como mais adequada a dieta com restrição proteica inferior a 0,8 g/kg/dia. Ainda, preconiza-se a redução da ingestão diária de sódio na dieta (<2 g/dia), pois amplifica o efeito nefroprotetor dos medicamentos que inibem o sistema renina angiotensina aldosterona (SRAA). Uma meta-  
análise (11 ensaios clínicos randomizados) mostra que uma dieta pobre em sódio, _per se,_ reduz a albuminúria em 32%. A diminuição da albuminúria é ainda mais significativa se o paciente estiver em uso de um dos medicamentos que inibem o SRAA (-41% vs. -17%, respectivamente), sugerindo um efeito sinérgico entre uma dieta pobre em sódio e terapia com IECA ou BRA<sup>39</sup> .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2 Tratamento medicamentoso** -->
O tratamento medicamentoso para prevenção da progressão da DRC contempla a terapia padrão com o uso de medicamentos IECA ou BRA, espironolactona e a terapia com dapagliflozina<sup>26,29</sup> .  
O estudo RENAAL mostrou que o uso do BRA reduz em 16% o risco da TRS ser necessária quando comparada ao placebo<sup>29</sup> . No entanto, pacientes com DRC em uso de IECA ou BRA frequentemente apresentam desfechos renais adversos, ou seja, declínio sustentado igual ou acima de 50% da taxa de filtração glomerular estimada (TFGe) ou necessidade de diálise crônica, transplante renal ou TFG abaixo de 15 mL/min/1,73 m<sup>2</sup> . Dados de seguimento do estudo DISCOVER CKD mostram que a taxa de incidência desses desfechos entre pacientes com DRC e TFGe abaixo de 75 mL/min/1,73 m<sup>2</sup> foi de 0,64 a 1,09 por 100 pacientes-ano<sup>40</sup> .  
O estudo CKDopps mostrou que IECA e BRA foram prescritos a apenas 67% dos pacientes brasileiros com DRC e DM, insuficiência cardíaca ou alto grau de albuminúria. Ainda, quando os episódios de hiperpotassemia ou de lesão renal aguda se tornam mais frequentes no contexto da DRC, principalmente nos estágios avançados, pode ser necessário interromper o uso ou reduzir a dose desses medicamentos<sup>41</sup> .  
O uso de IECA ou BRA deve ser indicado para os pacientes adultos diabéticos com DRC estágios 1 a 5 e RAC ≥ 30 mg/g, e para pacientes não diabéticos com DRC estágios 1 a 5 com RAC ≥ 300 mg/g, independentemente da presença ou não da hipertensão arterial<sup>42</sup> .  
O uso de espironolactona deve ser indicado para pacientes com DRC estágios 1 a 4 e RAC ≥ 300 mg/g, ou hipertrofia ventricular esquerda ou insuficiência cardíaca, independentemente da presença ou não da hipertensão arterial<sup>43</sup> .  
O medicamento dapagliflozina, um inibidor do cotransportador de sódio-glicose 2 (iSGLT-2), foi incorporado ao SUS, conforme Portaria SCTIE/MS nº 106/2022, e pode ser associado à terapia padrão (IECA ou BRA), otimizando o tratamento da prevenção da progressão da DRC em pacientes adultos<sup>44</sup> .  
Além de proporcionar controle glicêmico em pacientes diabéticos tipo 2, os iSGLT-2 mostraram atuar na proteção renal e cardiovascular adicional ao bloqueio do sistema renina-angiotensina em grandes ensaios controlados randomizados envolvendo pacientes diabéticos e não diabéticos. O estudo DAPA-CKD mostrou que o uso de dapagliflozina 10 mg associado à terapia padrão (IECA ou BRA na dose máxima tolerada e tratamento das comorbidades e complicações da DRC) em pacientes com DRC e TFG > 25 mL/min associou-se a risco significativamente menor de apresentar desfechos como redução sustentada da TFG e de pelo menos 50%, doença renal em fase terminal ou morte por causa renais ou cardiovasculares do que os pacientes que receberam placebo, independentemente de o paciente ter ou não DM2. Adicionalmente, pacientes tratados com dapagliflozina apresentaram maior sobrevida e um risco reduzido de morte por causa cardiovascular e de hospitalização por insuficiência cardíaca. Nos estudos avaliados, a utilização de dapagliflozina em associação com IECA ou BRA por dois anos foi associada à diminuição nas taxas de desfechos desfavoráveis sem causar mais eventos adversos<sup>45,46</sup> .  
Pacientes com DRC devem ser orientados a evitar o uso de substâncias com potencial nefrotóxico, tais como antiinflamatórios não-esteroidais (AINEs), contraste radiológico, antibióticos de excreção renal como os aminoglicosídeos, antipsicóticos atípicos, e preparações intestinais à base de fosfato e alumínio. Ainda, as doses dos medicamentos utilizados devem ser frequentemente ajustadas<sup>1,2,4</sup> . Ressalta-se que o sistema de saúde do Reino Unido (NHS) salienta que o uso excessivo de inibidores da bomba de prótons (IBPs) é potencialmente nefrotóxico.<sup>47</sup>

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2.1 Inibidores da enzima conversora da angiotensina: captopril e enalapril** -->
O captopril e o enalapril são utilizados para o tratamento da hipertensão e da insuficiência cardíaca, além de oferecer proteção renal para pacientes com diabetes tipo 2 e proteinúria. São inibidores competitivos específicos da enzima conversora de angiotensina I (ECA), responsável por catalisar a conversão da angiotensina I à substância pressora angiotensina II. A inibição da ECA resulta na diminuição da angiotensina II plasmática, aumentando a atividade da renina plasmática (em razão da remoção do _feedback_ negativo da liberação de renina) e diminui a secreção de aldosterona.  
Como a ECA é idêntica à cininase II, os IECA também podem bloquear a degradação de bradicinina, um potente vasopressor peptídico, provocando aumento da concentração de bradicinina ou prostaglandina E2.  
Os IECA diminuem a pressão arterial essencialmente pela supressão do sistema renina-angiotensina-aldosterona, o qual desempenha importante papel na regulação da pressão arterial. Ainda, na nefropatia diabética, os IECA previnem a progressão da doença renal e reduzem consequências clínicas associadas, tais como diálise, transplante renal e morte<sup>42</sup> .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2.2 Bloqueadores de receptores da angiotensina: losartana** -->
A losartana pertence à classe dos bloqueadores de receptores (tipo AT1) da angiotensina II e é indicada para o tratamento da hipertensão e da insuficiência cardíaca, além de reduzir o risco combinado de morte cardiovascular, acidente vascular cerebral e infarto do miocárdio em pacientes hipertensos com hipertrofia ventricular esquerda e oferecer proteção renal para pacientes com diabetes tipo 2 e proteinúria.  
A angiotensina II, um potente vasoconstritor, é o principal hormônio ativo do sistema renina-angiotensina e o maior determinante da fisiopatologia da hipertensão. A angiotensina II liga-se ao receptor AT1 encontrado no músculo liso vascular, glândulas adrenais, rins e coração e desencadeia várias ações biológicas importantes, incluindo vasoconstrição e liberação de aldosterona, e também estimula a proliferação de células musculares lisas. Ao ligar-se seletivamente ao receptor AT1, a losartana bloqueia todas as ações fisiologicamente relevantes da angiotensina II<sup>42</sup> .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2.3 Antagonistas dos receptores mineralocorticoides: espironolactona** -->
A espironolactona é um diurético poupador de potássio pertencente à classe dos antagonistas não seletivos dos receptores mineralocorticoides e é indicada para o tratamento da hipertensão e da insuficiência cardíaca, além de reduzir o risco combinado de morte cardiovascular, acidente vascular cerebral e infarto do miocárdio em pacientes hipertensos com hipertrofia ventricular esquerda e oferecer proteção renal para pacientes com diabetes tipo 2 e proteinúria<sup>43</sup> .  
A espironolactona é um antagonista da aldosterona, agindo no trocador de íons sódio-potássio, dependente de aldosterona presente no túbulo contornado distal do néfron. Isso promove o aumento das quantidades de sódio e água a serem excretados, com retenção de potássio. Por esse mecanismo, a substância age tanto como diurético, quanto como anti-hipertensivo<sup>43</sup> .  
Recentemente, os estudos FIGARO<sup>44</sup> e FIDELIO<sup>45</sup> mostraram o benefício do uso de antagonistas seletivos dos receptores mineralocorticoides (finerenone) na atenuação da progressão da DRC de etiologia diabética. Entretanto, tal tecnologia foi recentemente aprovada pela ANVISA e ainda não incorporada no SUS.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2.4 Inibidores do cotransportador de sódio-glicose 2: dapagliflozina** -->
A dapagliflozina é um inibidor do cotransportador de sódio-glicose 2 (SGLT-2), uma proteína responsável pela reabsorção da glicose no rim, levando à eliminação do excesso de glicose na urina.  
A inibição do SGLT-2 pela dapagliflozina reduz a absorção de glicose do filtrado glomerular no túbulo renal proximal, com redução concomitante da reabsorção de sódio, levando à excreção urinária da glicose e diurese osmótica. Assim, a dapagliflozina aumenta a entrega de sódio no túbulo distal, eleva a retroalimentação no túbulo glomerular e reduz a pressão  
intraglomerular. Este efeito combinado com a diurese osmótica reduz a sobrecarga de volume, a pressão sanguínea, a pré-carga e a pós-carga, o que pode ter efeito benéfico na remodelação cardíaca e preservação da função renal.  
Outros efeitos incluem aumento do hematócrito e redução de peso. Os benefícios cardiovasculares da dapagliflozina não são dependentes unicamente do efeito da diminuição da glicemia sanguínea e não são restritos aos pacientes com diabetes. Adicionalmente à osmose diurética e às ações hemodinâmicas relacionadas à inibição do SGLT-2, efeitos secundários significativos no metabolismo do miocárdio, canais iônicos, fibrose, adipocinas e ácido úrico, podem ser mecanismos subjacentes dos efeitos positivos da dapagliflozina no sistema cardio-renal<sup>46</sup> .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2.5 Medicamentos** -->
- Captopril: comprimidos de 25 mg;  
- Dapagliflozina: comprimidos de 10 mg;  
- Espironolactona: comprimidos de 25 mg;  
- Losartana potássica: comprimidos de 50 mg;  
- Maleato de enalapril: comprimidos de 5, 10 e 20 mg.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2.6 Esquemas de administração** -->
• **Captopril:** a dose recomendada é de 25 mg a cada 8 horas. Caso o paciente apresente nefropatia diabética e insuficiência renal leve a moderada, doses de 75 a 100 mg/dia são bem toleradas, devendo ser divididas três vezes ao dia. Pacientes com insuficiência renal significativa devem ter sua dose diária inicial reduzida, utilizado incrementos menores para a titulação lenta (intervalos de uma a duas semanas). Não há necessidade de ajuste de dose em pacientes idosos. O medicamento deve ser administrado uma hora antes das refeições.  
- **Maleato de enalapril:** podem ser administrados antes, durante ou após as refeições, conforme esquema a seguir:  
**Quadro 4** - Esquemas de administração do enalapril conforme disfunção renal.  
|**Disfunção renal**|**Depuração plasmática de creatinina (mL/min)**|**Dose inicial (mg/dia)**|
|---|---|---|
|Leve|Menor que 80 e maior que 30 mL/min|5 mg – 10 mg|
|Moderada|Menor ou igual a 30 e maior que 10 mL/min|2,5 mg – 5 mg|
|Grave *|Menor ou igual a 10 mL/min|2,5 mg nos dias de diálise**|  
* Normalmente esses pacientes estão sob diálise.  
**O maleato de enalapril é dialisável. Nos dias em que o paciente não for submetido à diálise, a posologia deverá ser ajustada à resposta da pressão arterial. **Fonte:** Elaboração própria.  
- **Losartana potássica:** a dose recomendada é de 50 mg uma vez ao dia, podendo ser aumentada para 100 mg uma vez  
- ao dia conforme a pressão arterial. Não há necessidade de ajuste posológico inicial para pacientes idosos ou para pacientes com insuficiência renal, inclusive para pacientes em diálise. Pode ser administrada com ou sem alimentos. A losartana e o seu metabólito ativo não podem ser removidos da circulação por hemodiálise.  
• **Espironolactona:** a dose recomendada é de 25 a 50 mg ao dia, em uma tomada diária. Não há necessidade de ajuste posológico inicial para pacientes idosos ou para pacientes com DRC. Pode ser administrada com ou sem alimentos. A espironolactona potencializa o efeito de outros diuréticos e anti-hipertensivos quando administrados concomitantemente. Há casos relatados de hiperpotassemia (aumento dos níveis sanguíneos de potássio) grave em pacientes que fazem uso de diuréticos poupadores de potássio, incluindo espironolactona e inibidores da ECA (como captopril e enalapril). Desta forma, a dose desses fármacos deverá ser reduzida quando a espironolactona for incluída ao tratamento.  
• **Dapagliflozina:** a dose recomendada é 10 mg uma vez ao dia, a qualquer hora do dia, independentemente das refeições. Não é necessário ajuste de dose com base na função renal. A dapagliflozina deve ser administrada em associação à terapia padrão (IECA ou BRA), em pacientes adultos com DRC e TFG entre 25 e 75 mL/min e com diabetes tipo 2 ou com uma RAC> 300 mg/g para pacientes com DRC e sem diabetes. Após a introdução da dapagliflozina, mesmo o paciente apresentando mudanças na TFG ou na redução da RAC, o tratamento com a dapagliflozina deverá ser mantido até o início da TRS ou transplante renal. Cabe destacar que apenas o uso da dapagliflozina deverá ser interrompido com o início da terapia renal substitutiva ou transplante.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Captopril** -->
O uso de captopril pode causar angioedema. Como o acometimento da língua, glote ou laringe pode obstruir as vias aéreas e causar morte, a terapia de emergência deve ser instituída rapidamente. O edema confinado à face, membranas mucosas da boca, lábios e extremidades, geralmente desaparece com a interrupção do medicamento, mas alguns casos necessitam de terapia médica. Foram relatados raros casos de angioedema intestinal em pacientes tratados com IECA e que apresentavam dor abdominal (com ou sem náusea ou vômitos), sem angioedema facial prévio e com níveis de esterase C-1 normais.  
Também há relatos de reações anafiláticas durante dessensibilização com veneno de _Hymenoptera_ , embora estas reações tenham sido evitadas após suspensão temporária do IECA e tenham reaparecido com o retorno do uso. Outras reações anafiláticas ocorreram durante a diálise de alto fluxo/exposição a membranas de aférese lipoprotéicas em pacientes tratados concomitantemente com um IECA. Reações anafiláticas têm sido relatadas em pacientes sob aférese de lipoproteínas de baixa densidade com absorção de sulfato de dextrano. Nestes pacientes, deve-se considerar a utilização de um tipo diferente de membrana de diálise ou uma diferente classe de medicamentos.  
A neutropenia é muito rara (< 0,02%) em pacientes hipertensos com função renal normal (creatinina sérica < 1,6 mg/dL, sem doença vascular do colágeno). Em pacientes com algum grau de insuficiência renal (creatinina sérica igual ou superior a 1,6 mg/dL), mas sem doença vascular do colágeno, o risco da neutropenia nos estudos clínicos foi de cerca de 0,2%. O uso concomitante de alopurinol e captopril foi associado à neutropenia. Em pacientes com doenças vasculares do colágeno (por exemplo lúpus eritematoso sistêmico e escleroderma) e insuficiência renal, a neutropenia ocorreu em 3,7% dos pacientes nos estudos clínicos. Relata-se neutropenia geralmente após 3 meses do início da administração do captopril. Em geral, a contagem de neutrófilos voltou ao normal em cerca de duas semanas após a descontinuação de captopril e as infecções graves se limitaram aos pacientes clinicamente complicados. Cerca de 13% dos casos de neutropenia foram fatais, mas quase todas as fatalidades ocorreram em pacientes gravemente enfermos com doenças vasculares do colágeno, insuficiência renal, insuficiência cardíaca, terapia imunossupressora, ou uma combinação destes fatores agravantes.  
Pacientes com insuficiência renal devem realizar contagem de leucócitos e contagens diferenciais antes do início do tratamento, a intervalos aproximados de duas semanas durante cerca de três meses e, após este período, periodicamente. Pacientes com doença vascular do colágeno ou que utilizem outros medicamentos que afetem os leucócitos ou a resposta imunológica, principalmente quando há insuficiência renal, devem utilizar o medicamento com cuidado e após avaliação do risco e do benefício. Em caso de neutropenia (contagem de neutrófilos abaixo 1000/mm<sup>3</sup> ), o médico deverá suspender o medicamento e acompanhar cuidadosamente o paciente.  
Proteína urinária total superior a 1 g/dia foi observada em cerca de 0,7% dos pacientes em uso de captopril. Cerca de 90% dos pacientes afetados apresentaram evidências de doença renal anterior ou receberam doses relativamente elevadas de captopril (acima de 150 mg/dia) ou ambos. Em estudo multicêntrico, duplo-cego, controlado por placebo, envolvendo 207 pacientes com nefropatia diabética e proteinúria (≥500 mg/dia) que receberam 75 mg/dia de captopril durante uma média de 3 anos, houve uma consistente redução da proteinúria. Não se sabe se o tratamento a longo prazo teria efeitos semelhantes em pacientes com outros  
tipos de doença renal. Pacientes com doença renal anterior ou aqueles recebendo captopril em doses superiores a 150 mg deverão fazer uma avaliação das proteínas urinárias antes do tratamento (feita na primeira urina da manhã) e, depois, realizar o teste periodicamente.  
A hipotensão excessiva raramente foi observada em pacientes hipertensos, mas é uma consequência possível do uso de captopril em indivíduos com sal/volume depletados (tais como aqueles tratados com diuréticos), pacientes com insuficiência cardíaca ou naqueles pacientes que estão sendo submetidos à diálise renal.  
Em raras ocasiões, os IECA têm sido associados com uma síndrome que se inicia com icterícia colestática e progride para uma necrose hepática fulminante e morte. Os mecanismos desta síndrome não são conhecidos. Assim, pacientes que apresentem icterícia ou elevações acentuadas nos níveis das enzimas hepáticas devem interromper o uso do medicamento e receber acompanhamento médico apropriado.  
Alguns pacientes com doença renal, principalmente com grave estenose de artéria renal, apresentaram aumentos nos níveis de ureia e creatinina séricas após a redução da pressão arterial com captopril, podendo ser necessário ajuste de dose ou interrupção do uso de diuréticos.  
Cerca de 20% dos pacientes em tratamento prolongado com captopril apresentam elevações estáveis dos níveis de ureia e creatinina séricas (20% acima do limite superior de normalidade ou do valor de referência). Menos de 5% dos pacientes, geralmente aqueles com graves doenças renais preexistentes, necessitam interromper o tratamento devido aos níveis progressivamente crescentes de creatinina.  
A elevação do nível sérico de potássio foi observada em alguns pacientes. Há risco de desenvolvimento de hipercalemia em pacientes com insuficiência renal, diabetes melito e naqueles usando concomitantemente diuréticos poupadores de potássio, suplementos de potássio ou substitutos do sal contendo potássio, ou outros medicamentos associados com aumentos de potássio sérico, como heparina.  
Pacientes em uso de IECA relatam tosse persistente e não produtiva, que desaparece após a interrupção do medicamento. Portanto, a tosse induzida por IECA deve ser considerada como parte do diagnóstico diferencial da tosse.  
Durante grandes procedimentos cirúrgicos ou durante a anestesia com agentes que produzem hipotensão, o captopril bloqueia a formação de angiotensina II secundária à liberação compensatória de renina. Se a hipotensão ocorrer e for considerada como sendo devido a este mecanismo, poderá ser corrigida pela expansão de volume.  
O captopril é classificado na categoria de risco na gravidez C (primeiro trimestre) e D (segundo e terceiro trimestres). Portanto, não devem ser usados na gravidez, pois podem causar morbidade e mortalidade fetal e neonatal quando administrados a mulheres no segundo e terceiro trimestres da gravidez. Ainda, devido ao potencial do captopril em causar reações adversas severas nos lactentes, deve-se interromper a amamentação ou o uso do medicamento, avaliando-se o risco-benefício para a mãe.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Maleato de enalapril** -->
O uso de enalapril em crianças entre 1 mês a 16 anos de idade é apoiado por evidências de estudos adequados e bem controlados. Não é recomendado para pacientes neonatos e pediátricos com taxa de filtração glomerular abaixo de 30 mL/min/1,73 m², já que não existem dados disponíveis para essa população de pacientes.  
Durante a gravidez, seu uso não é recomendado. Deve-se avaliar o risco-benefício para a mãe antes de suspender ou manter o tratamento. Os recém-nascidos de mães que utilizaram maleato de enalapril devem ser observados cuidadosamente, a fim de verificar a ocorrência de hipotensão, oligúria e hipercalemia. Ainda, por ser secretado no leite humano, mulheres que estejam amamentando devem ser cuidadosamente acompanhadas.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Losartana potássica** -->
Pacientes com depleção de volume intravascular (como aqueles tratados com altas doses de diuréticos) podem apresentar hipotensão sintomática. Desequilíbrios eletrolíticos são observados em pacientes com comprometimento renal, com ou sem diabetes, e devem ser corrigidos.  
Dados de farmacocinética demonstram aumentos significativos das concentrações plasmáticas de losartana em pacientes com cirrose. Assim, deve-se considerar doses mais baixas para pacientes com histórico de insuficiência hepática. Como consequência da inibição do sistema renina-angiotensina, foram relatadas alterações na função renal em indivíduos suscetíveis, inclusive insuficiência renal, as quais são reversíveis com a interrupção do tratamento.  
O uso concomitante de losartana e de inibidores da ECA não foi adequadamente estudado.  
A segurança e a eficácia em crianças ainda não foram estabelecidas. No entanto, a losartana é classificada nas categorias de risco na gravidez C (primeiro trimestre) e D (segundo e terceiro trimestres). Quando utilizado durante o segundo e o terceiro trimestres da gravidez, pode causar danos e até morte do feto em desenvolvimento. Assim, o tratamento com losartana deve ser interrompido em caso de gravidez. Inexistem informações sobre a excreção de losartana no leite humano, devendo-se suspender a amamentação ou o tratamento com losartana, conforme avaliação de risco-benefício para a mãe.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Espironolactona** -->
Os eventos adversos que podem ocorrer com o uso de espironolactona são ginecomastia, dor nas mamas, distúrbios menstruais, neoplasma benigno de mama, leucopenia (incluindo agranolocitose), trombocitopenia, distúrbios eletrolíticos e hipercalemia, alterações na libido, confusão, tontura, distúrbios gastrointestinais, náuseas, função hepática anormal, insuficiência renal aguda, alopecia, hipertricose (crescimento de cabelo anormal), prurido, rash, urticária e cãibras nas pernas. Outras reações também relatadas foram: sonolência, cansaço, dor de cabeça, confusão mental, febre, ataxia e impotência.  
O uso deste medicamento é contraindicado a pacientes com insuficiência renal aguda, diminuição significativa da função renal, anúria e hiperpotassemia, doença de Addison ou hipersensibilidade à espironolactona ou de qualquer outro componente da fórmula. A espironolactona não deve ser usada por mulheres grávidas sem orientação médica ou do cirurgião-dentista. Devido a muitos fármacos serem excretados no leite materno e devido ao desconhecido potencial para eventos adversos sobre o lactante, uma decisão deve ser tomada em relação a descontinuação do tratamento levando-se em conta a importância do fármaco para a mãe. Caso o uso de espironolactona durante o período da amamentação for considerado essencial, um método alternativo de alimentação para a criança deve ser instituído.  
O uso concomitante de espironolactona e outros diuréticos poupadores de potássio, inibidores da ECA (enzima conversora de angiotensina), antagonistas da angiotensina II, bloqueadores da aldosterona, suplementos de potássio, uma dieta rica em potássio ou substitutos do sal contendo potássio podem levar à hiperpotassemia grave. É aconselhável realizar uma avaliação periódica dos eletrólitos séricos, tendo em vista a possibilidade de hiperpotassemia, hiponatremia e uma possível elevação transitória da uréia plasmática especialmente em pacientes idosos e/ou com distúrbios preexistentes da função renal ou hepática, para os quais a relação risco/benefício deve ser considerada.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Dapagliflozina** -->
Ainda há poucos dados sobre o tratamento inicial de dapagliflozina em pacientes que apresentam TFG muito baixa (menor que 25 mL/min/1,73m<sup>2</sup> ), ou seja, com função renal gravemente diminuída.  
O estudo DAPA-CKD mostrou que o uso de dapagliflozina 10 mg associado à terapia padrão (inibidores da enzima conversora da angiotensina - IECA ou bloqueadores de receptores da angiotensina – BRA na dose máxima tolerada e tratamento das comorbidades e complicações da DRC) em pacientes adultos com DRC e TFG entre 25 e 75 mL/min, com ou sem diabetes e com RAC> 200 mg/g, associou-se a risco significativamente menor de apresentar desfechos como redução sustentada da TFGe de pelo menos 50%, doença renal em fase terminal ou morte por causa renais ou cardiovasculares, comparado a pacientes que receberam placebo, independentemente do paciente ter ou não DM2. Adicionalmente, pacientes tratados com dapagliflozina apresentaram maior sobrevida e um risco reduzido de morte por causa cardiovascular e de hospitalização por insuficiência cardíaca. Nos estudos avaliados, a utilização de dapagliflozina em associação com IECA ou BRA por dois anos foi associada à diminuição nas taxas de desfechos desfavoráveis sem causar mais eventos adversos<sup>48-50</sup> .  
A segurança e eficácia da dapagliflozina em pacientes pediátricos não foram estabelecidas. Ainda, o medicamento não  
deve ser utilizado no segundo e terceiro trimestres de gravidez ou por mulheres que estejam amamentando.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **6.2.8 Critérios de interrupção** -->
Os pacientes com diagnóstico de DRC devem continuamente adotar medidas para atenuar a progressão da doença. O tratamento pode ser interrompido em casos de eventos adversos aos medicamentos, sucesso do transplante renal ou início de terapia renal substitutiva, a menos que exista a indicação de continuidade da tecnologia por outros motivos como hipertensão arterial, diabetes ou insuficiência cardíaca. Cabe destacar que, apenas a utilização da dapagliflozina deverá ser interrompida com o início da terapia renal substitutiva ou transplante. Os pacientes em uso de IECA, BRA ou espironolactona devem ter o tratamento ajustado para menores doses ou interrompido quando apresentarem hipercalemia refratária às medidas para o controle de potássio ou injúria renal aguda. A interrupção ou a modificação do tratamento deve ser avaliada individualmente para cada paciente.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **7. FLUXO DE DIAGNÓSTICO E TRATAMENTO** -->
O fluxograma de tratamento está descrito na **Figura 1** .  
**Figura 1** - Fluxograma para diagnóstico e tratamento de pacientes com fatores de risco ou diagnóstico de DRC.  
<!-- Start of picture text -->
[rac comers op oom ealctaca |<br>Realzar exams:<br>Taxa de Filtraco Glomeruiar (TFG); Raz3o<br>Albuminiria/Creatindria (RAC) e de imagem<br>‘Se diagnéstico de DRC, classificar em estagios,<br>onfomne 1F6 e RAG<br>Estagiohematiria1: TFGou> 90proteinuriamL/min, com: Estagio3A:mUminTFG entre 45 e 60<br>Estagiomumin,comnematinaou 2: TFG entre 60 e 90 | | ‘Seguimento:Estéglo3B:TFOAPS (exceto ene 30e45se A3) | |EstagioExames304: timestalst mUminTFG entre 15¢© | EstagioExamesque5ND: tmestals15 mL/minTFG menor ©<br>‘Seguiment:protaninaAPS (exceto £0 2) seguimento:mmin AE tomestaie™ emesis"<br>Exames anuais"** Exames semestais*<br>Mudanga no esto de vida<br>- diabetesMudangaUttzarIECAno estoou BRA,de  sevide -dabeteseUitizar ECARAC>ou BRA 3099 se  €<br>“nto dabétease RAC >eRAC30 mg/g > 300e Adicionaimente, resto- nao diabéticos daingostaproeicae RAC > 300 om 06 20.8 hala<br>‘Se TFG entre 25 e 75 mLmin e for diabético tipo 2 ou apresentar<br>RAC > 300 mg/g, associar dapagiilozina ao tratamento padrao.<br><!-- End of picture text -->  
**Legenda:** DRC: Doença renal crônica; TFG: taxa de filtração glomerular; RAC: relação albuminúria/creatinúria; iECA: Inibidor da enzima conversora da angiotensina; BRA: bloqueador de receptor de angiotensina II, UBS: unidade básica de saúde, HA: hipertensão arterial; DM: diabete melito.  
> * TFG, RAC, hemoglobina, cálcio, fósforo, potássio, ureia.  
> ** Hormônio da paratireoide (PTH), proteínas totais e frações, ferritina, ferro, transferrina, bicarbonato.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **8. MONITORAMENTO** -->
Os pacientes em tratamento devem ser reavaliados semestralmente em relação à eficácia do tratamento e ao desenvolvimento de toxicidade aguda ou crônica. Caso apresentem alguma alteração clínica ou laboratorial, devem ser acompanhados com maior periodicidade.  
Os indivíduos com fatores de risco para a DRC e que ainda não apresentam diagnóstico da doença devem ter acompanhamento anual para TFG, RAC e EAS.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **8.1 DRC estágios 1 e 2 – TFG > ou igual 60 mL/min/1,73m**<sup>**2**</sup> **na presença de proteinúria ou hematúria glomerular ou alteração no exame de imagem** -->
Os pacientes podem ser acompanhados na atenção primária à saúde (APS) para tratamento dos fatores de risco modificáveis de progressão da DRC e doença cardiovascular, de acordo com as recomendações do MS: controle da glicemia, da hipertensão arterial, dislipidemia, obesidade, doenças cardiovasculares, tabagismo e adequação do estilo de vida. A TFG e o EAS devem ser avaliados anualmente.  
Caso apresentem algumas das seguintes alterações clínicas, os pacientes devem ser encaminhados à atenção especializada: paciente não diabético e RAC acima de 1 g/g; ou perda de 30% de TFG apesar do uso de IECA ou BRA.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **8.2 DRC estágio 3A – TFG entre 45 e 59 mL/min/1,73m**<sup>**2**</sup> -->
Os pacientes podem ser acompanhados na APS para tratamento dos fatores de risco modificáveis para a progressão da DRC e doença cardiovascular de acordo com as recomendações do MS: controle da glicemia, da hipertensão arterial, dislipidemia, obesidade, doenças cardiovasculares, tabagismo e adequação do estilo de vida.  
A avaliação da TFG, do EAS, RAC, da dosagem dos níveis de potássio sérico, cálcio, fósforo, hormônio da paratireoide (PTH) e hemograma deve ser realizada anualmente. A dosagem do potássio sérico é necessária porque a redução da TFG está associada à redução da capacidade da sua excreção e, quanto menor a TFG, mais frequente é a hipercalemia associada ao uso de IECA ou BRA.  
Pacientes com DRC estágio 3A com RAC acima de 30 mg/g devem ser avaliados a cada seis meses e encaminhados à atenção especializada quando apresentarem: RAC acima de 1 g/g, se o paciente não for diabético; ou perda de 30% de TFG apesar do uso de IECA ou BRA.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **8.3 DRC estágio 3B – TFG entre 30 e 44 mL/min/1,73m**<sup>**2**</sup> -->
Os pacientes devem ser acompanhados na APS, por equipe multiprofissional, para tratamento dos fatores de risco modificáveis para a progressão da DRC e doença cardiovascular de acordo com as recomendações do MS: controle da glicemia, da hipertensão arterial, dislipidemia, obesidade, doenças cardiovasculares, tabagismo e adequação do estilo de vida.  
Esses pacientes devem ser encaminhados às unidades de atenção especializada em DRC para avaliação quando apresentarem uma das seguintes alterações clínicas: RAC acima de 300 mg/g, se não for diabético; ou perda de 30% de TFG apesar do uso de IECA ou BRA. A avaliação da TFG, do EAS, RAC e da dosagem de potássio sérico deve ser realizada a cada seis meses. Os demais exames relacionados às complicações crônicas da DRC devem ser realizados anualmente. Esses pacientes podem permanecer em seguimento conjunto com o nefrologista ou serem seguidos apenas pelos profissionais da atenção primária.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **8.4 DRC estágio 4 – TFG entre 15 e 29 mL/min/1,73m**<sup>**2**</sup> -->
O acompanhamento desses indivíduos deverá ser realizado na atenção especializada pela equipe multiprofissional, incluindo médico nefrologista, enfermeiro, nutricionista, psicólogo e assistente social. O tratamento dos fatores de risco modificáveis para a progressão da DRC e doença cardiovascular deve ser mantido de acordo com as recomendações do MS: controle de glicemia, hipertensão arterial, dislipidemia, obesidade, doenças cardiovasculares, tabagismo e adequação do estilo de vida.  
A avaliação nefrológica deve ser realizada trimestralmente, incluindo TFG, EAS, RAC, dosagem de potássio, hemograma e estoques de ferro. Semestralmente, devem ser avaliados os níveis séricos de cálcio, fósforo, PTH, proteínas totais e frações e bicarbonato. Pacientes nesse estágio deverão ser esclarecidos sobre as modalidades de TRS por uma equipe multiprofissional.  
A difusão de tecnologias como matriciamento, teleconsulta ou teleassessoramento para pacientes com DRC estágios 3B e 4 é uma estratégia que pode ser utilizada para ampliar o acesso ao atendimento especializado. Os objetivos da utilização dessas tecnologias seriam melhorar a resolutividade e o atingimento de metas na APS, qualificar o acesso à atenção especializada e o processo de regulação e, reduzir o tempo de espera na rede de serviços ambulatoriais especializados. Todos os pacientes com DRC podem ser acompanhados na APS, adicionalmente, aos pacientes DRC estágio 3B, 4 e 5, é recomendado o atendimento com especialista.  
Mesmo após a entrada em diálise, recomenda-se que o paciente seja acompanhado também pela APS, garantindo a articulação entre a rede de assistência nos diferentes níveis.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **8.5 DRC estágio 5-ND (não dialítico) – TFG abaixo de 15 mL/min/1,73m**<sup>**2**</sup> -->
O acompanhamento desses indivíduos deverá ser realizado na atenção especializada pela equipe multiprofissional, incluindo médico nefrologista, enfermeiro, nutricionista, psicólogo e assistente social. O tratamento dos fatores de risco modificáveis para a progressão da DRC e doença cardiovascular devem ser mantidos. A avaliação nefrológica deve ser realizada mensalmente. A equipe multiprofissional deve treinar e preparar o paciente para a modalidade de TRS escolhida por ele.  
Dosagens de creatinina, ureia, cálcio, fósforo, hematócrito e hemoglobina, potássio e bicarbonato devem ser realizadas mensalmente, enquanto as dosagens de proteínas totais e frações, ferritina, índice de saturação de transferrina (IST), fosfatase alcalina, PTH devem ser realizadas trimestralmente. Dosagens de colesterol total, HDL e triglicérides devem ser consideradas semestralmente para os pacientes em tratamento com estatina, enquanto naqueles sem diagnóstico de dislipidemia, anualmente. Para renais crônicos diabéticos a hemoglobina glicada deve ser monitorada trimestralmente. Os pacientes com TFG < 15 mL/min devem ter exames de ECG, radiografia de tórax ou preferencialmente ecocardiograma e ultrassonografia renal e de vias urinárias anuais.  
Mesmo após a entrada em diálise, recomenda-se que o paciente seja acompanhado também pela APS, garantindo a articulação entre a rede de assistência nos diferentes níveis.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **8.6 Fluxograma para monitorização dos níveis de Creatinina e Potássio** -->
Em qualquer estágio da DRC, ao introduzir ou otimizar dose de IECA, BRA ou espironolactona, deve-se monitorizar os níveis de creatinina e potássio após 2 a 4 semanas ( **Figura 2** ):  
**Figura 2** – Fluxograma para monitorização dos níveis de creatinina e potássio após 2 a 4 semanas da introdução ou otimização da dose de iECA, BRA ou espironolactona.  
<!-- Start of picture text -->
Indicar iECA, BRA ou<br>espironolactona |<br>Monitorar creatinina e potdssio sérico (dentro de 2<br>a 4 semanas apés 0 inicio ou alteracao de dados)<br>Normocalemia: Hipercalemia: > 30%eede aumento na<br>> 30%creatininade aumento na concomitantes- _Revisar _medicamentos - Revisar causas de IRA<br>. : - Dieta com baixo potassio - Evitar desidratacao e|<br>diuréticos<br>- Considerar — diuréticos,<br>ect ei od trocadbicarb o resnato dede _ cations.—sdio, -de artériaConsiderar renal estenose|<br>ripe gastrointestinais<br>continuar com a dose -<br>maxima tolerada<br>Reduzir dose ou interromperultimaiECA,op¢ao BRAou espironolactona como<br><!-- End of picture text -->  
**Legenda:** IECA - inibidores da enzima conversora de angiotensina; BRA - bloqueadores de receptores da angiotensina; GI - gastrointestinal; IRA – injúria renal aguda. **Fonte:** KDIGO, 2020.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento (s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
A avaliação dos pacientes que se encontram no grupo de risco e ainda não apresentam diagnóstico de DRC deve ser feita no contexto do cuidado dos pacientes com fatores de risco, na unidade básica de saúde.  
É recomendado que todos os pacientes com DRC sejam acompanhados na atenção primária à saúde. Adicionalmente, para os pacientes nos estágios 3B, 4 e 5 ou A3, também é recomendado o acompanhamento por nefrologistas. A prescrição dos medicamentos, incluindo a dapagliflozina, pode ser realizada tanto no âmbito da atenção primária quanto na atenção especializada à saúde.  
Além desses cuidados, o paciente deve ser acompanhado por uma equipe multiprofissional, de modo que as decisões de tratamento sejam compartilhadas entre ele e a equipe<sup>21,22</sup> .  
A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos. É essencial verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **11. REFERÊNCIAS** -->
1. Kidney Disease: Improving Global Outcomes (KDIGO). Kidney Disease: Improving Global Outcomes (KDIGO) CKD Work Group. KDIGO 2024 clinical practice guideline for the evaluation and management of chronic kidney disease. Kidney Int Suppl. 2024;105(4s):S117–314.  
2. Chen TK, Knicely DH, Grams ME. Chronic Kidney Disease Diagnosis and Management: A Review. Jama. 2019/10/02. 2019;322(13):1294–304.  
3. Kazancioğlu R. Risk factors for chronic kidney disease: an update. Kidney Int Suppl. 2013;3(4):368–71.  
4. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Diretrizes Clínicas para o Cuidado ao Paciente com Doença Renal Crônica – DRC no Sistema Único de Saúde. 2014. Disponível em: <https://www.gov.br/conitec/pt- <u>br/midias/protocolos/diretriz-cuidados-drc.pdf>.</u>  
5. Aguiar LK . Fatores associados à doença renal crônica segundo critérios laboratoriais da Pesquisa Nacional de Saúde. Revista Brasileira de Epidemiologia, 2020, doi.org/10.1590/1980-549720200101.  
6. Marinho AWGB, Penha AP , Silva MT, Galvão TF. Prevalência de doença renal crônica em adultos no Brasil: revisão sistemática da literatura. Cad. Saúde Colet., 2017, Rio de Janeiro, 25 (3): 379-388.  
7. COLLABORATION GBDCKD. Global, regional, and national burden of chronic kidney disease, 1990-2017: a systematic analysis for the Global Burden of Disease Study 2017. Lancet. 2020/02/18. 2020;395(10225):709–33.  
8. Cockwell P, Fisher LA. The global burden of chronic kidney disease. Lancet. 2020/02/18. 2020;395(10225):662–4.  
9. Malta DC, Machado Í E, Pereira CA, Figueiredo AW, Aguiar LK, Almeida WDS, et al. Evaluation of renal function in the Brazilian adult population, according to laboratory criteria from the National Health Survey. Rev Bras Epidemiol. 2019;22Suppl 02(Suppl 02):E190010.supl.2.  
10. Barreto SM, Ladeira RM, Duncan BB, Schmidt MI, Lopes AA, Benseñor IM, et al. Chronic kidney disease among adult participants of the ELSA-Brasil cohort: association with race and socioeconomic position. J Epidemiol Community Heal. 2015/10/30. 2016;70(4):380–9.  
11. Sociedade Brasileira de Nefrologia (SBN) [homepage na internet]. Censo 2023 [acesso em 05 set 2024]. Disponível em: http://www.censo-sbn.org.br/censosAnteriores  
12. Moraes Júnior CS, Fernandes N, Colugnati FAB. Multidisciplinary treatment for patients with chronic kidney disease in pre-dialysis minimizes costs: a four-year retrospective cohort analysis. J Bras Nefrol. 2021;  
13. <u>https://www.gov.br/conitec/pt-br/midias/artigos_publicacoes/diretrizes/diretrizes-metodologicas-elaboracao-dediretrizes-clinicas-2020.pdf</u>  
14. Kidney Disease: Improving Global Outcomes (KDIGO) Blood Pressure Work Group. KDIGO 2021 Clinical Practice Guideline for the Management of Blood Pressure in Chronic Kidney Disease. Kidney Int. 2021 Mar;99(3S):S1-S87. doi: 10.1016/j.kint.2020.11.003.  
15. Cândido J, Camelo LV, Brant L, Cunha RS, Mill JG, Barreto SM. Maior Rigidez Arterial Prediz Doença Renal Crônica no Estudo de Coorte ELSA-Brasil. Arq. Bras. Cardiol. 2023;120(12):e20230409.  
16. Bruce B. Duncan, Maria Inês Schmidt, Elsa R.J. Giugliani, Michael Schmidt Duncan, Camila Giugliani. Medicina ambulatorial: Condutas de atenção primária baseadas em evidências. Artmed, organizador. 2022.  
17.ADA. American Diabetes Association Standards of Care in Diabetes. Disponível em: https://ada.silverchair cdn.com/ada/content_public/journal/care/issue/46/supplement_1/14/standards-of-care 2023-copyright-stamped-updated120622.pdf. 2023. 2023.  
18.SBD. Diretriz da Sociedade Brasileira de Diabetes - Edição 2023. . Disponível em: https://diretriz.diabetes.org.br/. 2023. 19.Blonde L, Umpierrez GE, Reddy SS, McGill JB, Berga SL, Bush M, et al. American Association of Clinical Endocrinology Clinical Practice Guideline: Developing a Diabetes Mellitus Comprehensive Care Plan—2022 Update. Endocrine Practice [Internet]. 2022;28(10):923–1049. Disponívelhttps://www.sciencedirect.com/science/article/pii/S1530891X22005766  
20.Pedroso Camargos A, Barreto S, Brant L _, et al_ Performance of contemporary cardiovascular risk stratification scores in Brazil: an evaluation in the ELSA-Brasil study _Open Heart_ 2024; **11:** e002762. doi: 10.1136/openhrt-2024-002762  
21.World Health Organization cardiovascular disease risk charts: revised models to estimate risk in 21 global regions Kaptoge, Stephen et al. The Lancet Global Health, Volume 7, Issue 10, e1332 - e1345  
22.Brasil. Ministério da Saúde., SAPS-Secretaria de Atenção Primária à Saúde. Estratégia de Saúde Cardiovascular na Atenção Primária à Saúde: instrutivo para profissionais e gestores [recurso eletrônico]. 2022;  
23.Levey AS, Bosch JP, Lewis B, Greene T, Rogers N, Roth N. A more accurate method to estimate glomerular filtration rate from serum creatinine: a new prediction equation. Ann Int Med 1999; 130: 461-410.  
24.Levey AS, Stevens LA, Schmid CH, et al. A new equation to estimate glomerular filtration rate. Ann Intern Med. 2009; 150: 604–612.  
25.Rao SR, Vallath N, Siddini V, Jamale T, Bajpai D, Sancheti NN, et al. Symptom Management among Patients with Chronic Kidney Disease. Indian J Palliat Care. 2021/07/01. 2021;27(Suppl 1):S14-s29.  
26.Romagnani P, Remuzzi G, Glassock R, Levin A, Jager KJ, Tonelli M, et al. Chronic kidney disease. Nat Rev Dis Prim. 2017/11/24. 2017;3:17088.  
27.Shabaka A, Cases-Corona C, Fernandez-Juarez G. Therapeutic Insights in Chronic Kidney Disease Progression. Front Med. 2021/03/13. 2021;8:645187.  
28.BMJ Best Practice. Chronic kidney disease. https://bestpractice.bmj.com/topics/en-us/84, 2022  
29.Johnson CA, Levey AS, Coresh J, Levin A, Lau J, Eknoyan G. Clinical practice guidelines for chronic kidney disease in adults: Part I. Definition, disease stages, evaluation, treatment, and risk factors. Am Fam Physician. 2004 Sep;70(5):869–76.  
30.Vanholder R, Van Laecke S, Glorieux G, Verbeke F, Castillo-Rodriguez E, Ortiz A. Deleting Death and Dialysis: Conservative Care of Cardio-Vascular Risk and Kidney Function Loss in Chronic Kidney Disease (CKD). Toxins (Basel). 2018;10(6).  
31.Murtagh FE, Burns A, Moranne O, Morton RL, Naicker S. Supportive Care: Comprehensive Conservative Care in End-Stage Kidney Disease. Clin J Am Soc Nephrol. 2016/08/12. 2016;11(10):1909–14.  
32.Cupisti A, Gallieni M, Avesani CM, D’Alessandro C, Carrero JJ, Piccoli GB. Medical Nutritional Therapy for Patients with Chronic Kidney Disease not on Dialysis: The Low Protein Diet as a Medication. J Clin Med. 2020;9(11).  
33.Koppe L, Cassani de Oliveira M, Fouque D. Ketoacid Analogues Supplementation in Chronic Kidney Disease and Future Perspectives. 2019;11(9).  
34.BRASPEN (SBNPE) - Brazilian Society of Parenteral and Enteral Nutrition (Sociedade Brasileira de Nutrição Parenteral e Enteral). Diretriz BRASPEN de Terapia Nutricional no Paciente com Doença Renal. 2021 [internet]. Disponível em: <https://f9fcfefb-80c1-4. BRASPEN J. 36(2° Supl 2):2–22.  
35.Ikizler TA, Burrowes JD, Byham-Gray LD, Campbell KL, Carrero JJ, Chan W, et al. KDOQI Clinical Practice Guideline for Nutrition in CKD: 2020 Update. Am J Kidney Dis. 2020/08/25. 2020;76(3 Suppl 1):S1-s107.  
36.Li, A., Lee, H. Y., & Lin, Y. C. . The Effect of Ketoanalogues on Chronic Kidney Disease Deterioration: A Meta-Analysis. Nutrients. 2019;11(5):957.  
37.Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no SUS – Conitec. Aminoácidos + análogos associados a dieta muito restritiva em proteínas para o tratamento de pacientes adultos com doença renal crônica em estágios 4 ou 5 pré-dialítico. Disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20221208_relatorio_aminoacidos_analogos_-drc_784.pdf.</u>  
38.Obeid W, Hiremath S, Topf JM. Protein Restriction for CKD: Time to Move On. Kidney360. 2022 Jun 22;3(9):1611-1615. doi: 10.34067/KID.0001002022.  
39.D’EliaL, RossiG, SchianodiColaM et al. Meta-analysis of the effect of dietary sodium restriction with or without concomitant reninangiotensin aldosterone antagonist-inhibiting treatment of albuminuria. Clin J Am Soc Nephrol 2015; 10:1542–1552.  
40.Breener BM et al. Effects of losartan on renal and cardiovascular outcomes in patients with type 2 diabetes and nephropathy. N Engl J Med 2001; 345:861-869.  
41.Abdul Sultan A, Nolan S, Carrero JJ, Jiang Z, Kumar SR, Pecoits-Filho R, et al. Defining the excess risk of adverse kidney outcomes in CKD patients with type 2 diabetes in the discover-CKD cohort. J Am Soc Nephrol [Internet]. 2020;31:183. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L633703577&from=export  
42.Stengel B, Muenz D, Tu C, Speyer E, Alencar de Pinho N, Combe C, et al. Adherence to the Kidney Disease: Improving Global Outcomes CKD Guideline in Nephrology Practice Across Countries. Kidney Int Reports [Internet]. 2021 Feb;6(2):437– 48. Available from: https://linkinghub.elsevier.com/retrieve/pii/S2468024920317964  
43.Alexandrou ME, Papagianni A, Tsapas A, Loutradis C, Boutou A, Piperidou A, Papadopoulou D, Ruilope L, Bakris G, Sarafidis P. Effects of mineralocorticoid receptor antagonists in proteinuric kidney disease: a systematic review and metaanalysis of randomized controlled trials. J Hypertens. 2019 Dec;37(12):2307-2324. doi: 10.1097/HJH.0000000000002187.  
44.Filippatos G, Anker SD, Agarwal R, et al., on behalf of the FIGARO-DKD Investigators. Finerenone Reduces Risk of Incident Heart Failure in Patients With Chronic Kidney Disease and Type 2 Diabetes: Analyses From the FIGARO-DKD Trial. Circulation 2022;145:437-47.  
45..Agarwal R, Joseph A, Anker SD, et al. Hyperkalemia Risk with Finerenone: Results from the FIDELIO-DKD Trial. J Am Soc Nephrol. 2022;33(1):225-237. doi:10.1681/ASN.2021070942  
46.https://www.gov.br/conitec/pt-br/midias/relatorios/2022/20220927_relatorio_773_  
dapagliflozina_doenca_renal_cronica_final.pdf  
47.Mello, P. A. de, Rocha, B. G., Oliveira, W. N., Mendonça, T. S., & Domingueti, C. P. (2021). Nefrotoxicidade e alterações de exames laboratoriais por fármacos: revisão da literatura. _Revista De Medicina_ , _100_ (2), 152-161. <u>https://doi.org/10.11606/issn.1679-9836.v100i2p152-161</u>  
48.Heerspink HJL, Stefánsson B V., Correa-Rotter R, Chertow GM, Greene T, Hou F-F, et al. Dapagliflozin in Patients with Chronic Kidney Disease. N Engl J Med. 2020;383(15):1436–46.  
49.Zelniker TA, Raz I, Mosenzon O, Dwyer JP, Heerspink HHJL, Cahn A, et al. Effect of Dapagliflozin on Cardiovascular Outcomes According to Baseline Kidney Function and Albuminuria Status in Patients with Type 2 Diabetes: A Prespecified Secondary Analysis of a Randomized Clinical Trial. JAMA Cardiol. 2021;6(7):801–10.  
50.Mosenzon O, Wiviott SD, Heerspink HJL, Dwyer JP, Cahn A, Goodrich EL, et al. The Effect of Dapagliflozin on Albuminuria in DECLARE-TIMI 58. Diabetes Care [Internet]. 2021 Aug;44(8):1805–15. Available from: http://care.diabetesjournals.org/lookup/doi/10.2337/dc21-0076.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
CAPTOPRIL, ENALAPRIL, LOSARTANA, ESPIRONOLACTONA E DAPAGLIFLOZINA  
Eu, __________________________________________________________________________ (nome do[a] paciente),  
declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **captopril, enalapril, espironolactona, losartana e dapagliflozina** , indicados para o tratamento da Doença Renal Crônica, segundo critérios de elegibilidade definidos neste Protocolo.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a)______________________  
_______________________________________________________________________(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- atenuar a progressão da doença renal crônica;  
- diminuir a necessidade de iniciar diálise.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Os eventos adversos mais comuns dos medicamentos captopril, enalapril, losartana são a hipercalemia e a piora aguda  
- da função renal. Consultas e exames durante o tratamento são necessários.  
- O evento adverso mais comum do medicamento espironolactona é a hiperpotassemia. Consultas e exames durante o  
- tratamento são necessários.  
- O evento adverso mais comum do medicamento dapagliflozina é a hipoglicemia. Consultas e exames durante o  
- tratamento são necessários.  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim  
- (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) captopril  
- (    ) enalapril  
- (    ) espironolactona  
- (    ) losartana  
- (    ) dapagliflozina  
|Local:                                                                                                 Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|________________________________________________________________<br>Assinatura do paciente ou do responsável legal|___________________|_|
|Médico responsável:|CRM:|UF:|
|________________________________________________________________<br>Assinatura e carimbo do médico|__________________||
|Data:______________________|||  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) das Estratégias para Atenuar a Progressão da Doença Renal Crônica, contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
Para a elaboração deste relatório foi utilizado como base as Diretrizes Clínicas para o Cuidado ao Paciente com Doença Renal Crônica – DRC no Sistema Único de Saúde (Portaria GM/MS nº 389, de 13 de março de 2014), assim como informações sobre a incorporação do medicamento dapagliflozina para pacientes adultos com DRC, detalhadas na Portaria SCTIE/MS nº 106, de 27 de setembro de 2022, e no Relatório de Recomendação nº 773/2022 da Conitec.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas e metodologistas, sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde - DGITS/SECTICS/MS.  
**Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas**  
A proposta de atualização do PCDT foi apresentada à 105ª Reunião da Subcomissão Técnica de Avaliação de PCDT, em 17 de janeiro de 2023, em que estiveram representantes da Secretaria de Atenção Especializada em Saúde (SAES), da Secretaria de Atenção Primária à Saúde (SAPS), da Secretaria de Vigilância em Saúde (SVS) e da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS). Não houve apontamentos quanto às alterações realizadas no texto.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Consulta pública** -->
A Consulta Pública nº 11/2023 para manifestação da sociedade civil a respeito da recomendação preliminar do Comitê de Protocolo Clínico e Diretrizes Terapêuticas da Conitec da proposta de publicação do PCDT das estratégias para atenuar a progressão da doença renal crônica foi realizada entre os dias 19/04/2023 e 08/05/2023. Foram recebidas 152 contribuições que podem ser verificadas em: https://www.gov.br/conitec/pt-br/assuntos/participacao-social/consultas-publicas/encerradas.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **3. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações das Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ )<sup>1</sup> , para classificar a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias ( **Quadro A** ). Devido ao prazo de disponibilização da dapagliflozina no SUS, não foram realizadas reuniões de recomendações com painel de especialistas, no desenvolvimento desse Protocolo.  
**Quadro A.** Níveis de evidências de acordo com o sistema GRADE.  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|||Trabalhos futuros poderão modificar a confiança na|
|**Moderado**|Há confiança moderada no efeito estimado.|estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|  
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante em nossa confiança na estimativa de efeito.|
|---|---|---|
||A confiança na estimativa de efeito é muito||
|**Muito baixo**|limitada. Há importante grau de incerteza<br>nos achados.|Qualquer estimativa de efeito é incerta.|  
**Fonte:** Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde  
/ Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para responder cada questão foi utilizada uma das seguintes metodologias: 1) revisões sistemáticas _de novo_ ; ou 2) adoção ou adaptação de diretrizes existentes.  
Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações de outras diretrizes, um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **QUESTÃO 1: QUAL É A EFETIVIDADE DA MUDANÇA NO ESTILO DE VIDA, INCLUINDO A CESSAÇÃO DO TABAGISMO, A PRÁTICA DE EXERCÍCIOS FÍSICOS E A REDUÇÃO DE PESO PARA ATENUAR A PROGRESSÃO DA DRC?** -->
**<u>Recomendação:</u>** Sugerimos que os pacientes com DRC estágios 1 a 5-ND (não dialítico) devem mudar o estilo de vida, incluindo a cessação do tabagismo, a prática de exercícios físicos e a redução de peso para atenuar a progressão da DRC (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Portadores de DRC estágios 1 a 5-ND (critérios diagnósticos de DRC)  
**Intervenção:** Mudança no estilo de vida (cessação do tabagismo, exercícios físicos e redução de peso) **Comparador:** Seguimento clínico sem intervenção  
**Desfechos:** Redução da filtração glomerular; necessidade de diálise; eventos cardiovasculares; mortalidade por todas as  
causas e cardiovascular  
**Métodos e resultados da busca**  
Para essa questão, foram consultadas as recomendações do _Chronic kidney disease: assessment and management NICE guideline,_ publicado em 2021<sup>2</sup> , e do _KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease_<sup>3</sup> .  
**Resumo das evidências:**  
**Recomendações do NICE**<sup>**2**</sup>  
Orientação sobre estilo de vida: Incentivar os adultos com DRC a se exercitarem, atingirem um peso saudável e pararem  
de fumar [2008].  
Intervenções dietéticas: Se for acordada uma intervenção dietética, fornecê-la juntamente com educação, avaliação dietética detalhada e supervisão para garantir que a desnutrição seja evitada. [2008]  
Autogestão: Assegurar que existam sistemas para apoiar a autogestão (isto inclui o fornecimento de informações sobre pressão arterial, cessação do fumo, exercícios, dieta e medicamentos) e permitir que os adultos com DRC façam escolhas informadas. [2014]  
Oferecer programas de educação de pacientes adequados à cultura e à idade a todos os adultos, crianças e jovens diagnosticados com anemia de DRC (e suas famílias e cuidadores). Estes devem ser repetidos conforme solicitado e de acordo com a mudança de circunstâncias da pessoa. Eles devem incluir o estilo de vida, como por exemplo: dieta, exercícios físicos, manter a normalidade ou conhecer outras pessoas com a condição.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Recomendações do KDIGO 2012**<sup>**3**</sup> -->
O exercício regular leva ao aumento da capacidade de exercício, diminuição da morbidade e melhoria da qualidade de vida. O exercício pode reduzir o risco cardiovascular por seus efeitos benéficos sobre a pressão arterial (PA), níveis de triglicerídeos, colesterol lipoproteico de alta densidade (HDL), resistência à insulina e controle glicêmico. Na doença renal terminal, o exercício tem mostrado melhorar a rigidez arterial, a PA, a função cardiorrespiratória e a qualidade de vida. Ainda há poucos dados disponíveis sobre os efeitos benéficos do exercício sobre a DRC precoce. Entretanto, à medida que o risco cardiovascular aumenta gradualmente, tanto com uma taxa de filtração glomerular mais baixa quanto com uma taxa de filtração glomerular mais alta, espera-se que o exercício também ajude a prevenir a doença cardiovascular (DCV) progressiva em DCV menos severa. De fato, em indivíduos com categorias de TFG relativas à DRC de estágios 3A a 4 (TFG entre 15 e 59 mL/min/1,73 m<sup>2</sup> ), o treinamento de exercício a longo prazo melhorou o comprometimento físico, a rigidez arterial e a qualidade de vida. Portanto, o treinamento de exercício é imperativo em pacientes com DCV e programas de apoio, incluindo automonitoramento, reforço verbal e motivação, deve ser utilizado como estratégia para prevenir o alto risco cardiovascular na DCV.  
Estudos observacionais sugerem que a obesidade é um fator de risco independente para a DRC. As evidências em estudos populacionais são conflitantes: alguns estudos não identificaram associação entre obesidade e diminuição da TFG, possivelmente porque o IMC isoladamente é uma medida ruim, enquanto outros sugerem que a DRC é associada independentemente ao IMC. Sabe-se há algum tempo que a obesidade está associada à glomeruloesclerose secundária focal e segmentar. As associações significativas entre obesidade e DRC identificadas em grandes estudos observacionais, como o _The Framingham Heart Study_ , desaparecem quando há ajuste para idade, sexo e fatores de risco cardiovascular. Entretanto, revisão sistemática com metaanálise das intervenções de perda de peso em pacientes com DRC demonstraram que a perda de peso está associada à diminuição significativa da proteinúria e da PA sistólica, sem diminuição adicional da TFG durante um acompanhamento médio de 7,4 meses. De forma semelhante, outra revisão sistemática concluiu que intervenções de perda de peso foram associadas à diminuição da proteinúria e albuminúria em 1,7 g (IC95% 0,7-2,6 g) e 14 mg (IC95% 11-17 mg), respectivamente (p < 0,05). Cada 1 kg de perda de peso foi associada à diminuição de 110 mg (IC95% 60-160 mg; p < 0,001) na proteinúria e 1,1 mg (IC95% 0,5-2,4 mg; p < 0,011) redução na albuminúria, independente da redução na PA.  
Vários estudos documentam uma clara associação entre o fumo e os danos renais na população geral, pacientes com diabetes e pacientes hipertensos. O fumo tem relação causal a eventos cardiovasculares na população geral e está associado a um risco aumentado de eventos cardiovasculares em pacientes com DRC. Todos os estudos que investigam os efeitos benéficos da cessação do fumo na função renal têm tido resultados positivos.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **QUESTÃO 2: QUAL É A EFETIVIDADE DA RESTRIÇÃO DE PROTEÍNAS DA DIETA PARA ATENUAR A PROGRESSÃO DA DRC?** -->
**<u>Recomendação:</u>** Sugerimos que os pacientes com DRC estágios 3 e 4 façam dieta restritiva em proteínas para atenuar a  
progressão da DRC (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Portadores de DRC estágios 3 e 4 (critérios diagnósticos de DRC)  
**Intervenção:** Dieta restrita em proteínas  
**Comparador:** Seguimento clínico sem intervenção  
**Desfechos:** Redução da filtração glomerular; necessidade de diálise; eventos cardiovasculares; mortalidade por todas as  
causas e cardiovascular  
**Métodos e resultados da busca:**  
Para essa questão, foram adotadas as recomendações do _Chronic kidney disease: assessment and management NICE guideline,_ publicado em 2021<sup>2</sup> , e do _KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease_<sup>3</sup> .  
**Resumo das evidências:**  
**Recomendações do NICE**<sup>**2**</sup>  
Dietas com baixo teor de proteína:  
- Não ofereça dietas com baixo teor de proteína (ingestão de proteína dietética inferior a 0,6 a 0,8 g/kg/dia) para adultos com DRC. [2014]  
**Recomendações do KDIGO 2012**<sup>**3**</sup>  
Consumo de proteína  
- Baixar a ingestão de proteína para 0,8 g/kg/dia em adultos com diabetes (2C) ou sem diabetes (2B) e TFG <30 mL/min/  
1,73 m<sup>2</sup> (categorias TFG G4-G5), com educação apropriada.  
- Evitar o consumo elevado de proteína (41,3 g/kg/dia) em adultos com DRC em risco de progressão (2C).  
O excesso de proteína dietética leva ao acúmulo de toxinas urêmicas. Ao contrário, a ingestão insuficiente de proteínas pode levar à perda de massa magra do corpo e à desnutrição, sendo esta última mais frequente em idosos. Os benefícios da restrição proteica na dieta incluem a redução do acúmulo de metabólitos e produtos residuais que podem suprimir o apetite e estimular o desperdício de proteína muscular. O papel da restrição proteica dietética no abrandamento da progressão da DRC é mais controverso e a DRC avançada está associada a uma síndrome de desperdício de proteínas que está diretamente correlacionada com a morbidez e a mortalidade. As orientações sobre redução de proteínas dietéticas não se aplicam a populações pediátricas devido às questões relacionadas com crescimento e nutrição.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **QUESTÃO 3: QUAL É A EFETIVIDADE DO USO DOS INIBIDORES DA ENZIMA CONVERSORA DA ANGIOTENSINA (IECA) OU BLOQUEADORES DE RECEPTORES DA ANGIOTENSINA (BRA) PARA ATENUAR A PROGRESSÃO DA DRC?** -->
**<u>Recomendação:</u>** Sugerimos que os pacientes com DRC estágios 1 a 5-ND utilizem inibidores da enzima conversora da angiotensina (IECA) ou bloqueadores de receptores da angiotensina (BRA) para atenuar a progressão da DRC (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Portadores de DRC estágios 1 a 5-ND (critérios diagnósticos de DRC)  
**Intervenção:** IECA ou BRA  
**Comparador:** Seguimento clínico sem uso de IECA ou BRA  
**Desfechos:** Redução da filtração glomerular; necessidade de diálise; eventos cardiovasculares; mortalidade por todas as  
causas e cardiovascular  
**Métodos e resultados da busca**  
Para essa questão, foram adotadas as recomendações do _Chronic kidney disease: assessment and management NICE guideline,_ publicado em 2021<sup>2</sup> , e do _KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease_<sup>3</sup> .  
**Resumo das evidências:**  
**Recomendações do NICE**<sup>**2**</sup>  
- Oferecer BRA ou IECA (dose mais alta que a pessoa possa tolerar) a adultos, crianças e jovens com DRC que tenham  
- hipertensão e RAC acima de 30 mg/mmol (RAC categoria A3 ou acima).  
- Para adultos com DRC e diabetes melito (tipo 1 ou tipo 2), oferecer BRA ou IECA (dose mais alta que a pessoa pode  
- tolerar) se a RAC for igual ou acima de 3 mg/mmol. [2021]  
- Na avaliação nefrológica, oferecer BRA ou IECA (dose mais alta que eles podem tolerar), se RAC for igual ou acima  
- de 70 mg/mmol.  
- Monitorar de acordo com as recomendações. Se RAC estiver acima de 30 mg/mmol, mas abaixo 70 mg/mmol; considere  
- discutir com um nefrologista se a TFG declinar ou a RAC aumentar. [2021]

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Recomendações do KDIGO 2012**<sup>**3**</sup> -->
- Recomenda que adultos diabéticos e não diabéticos com DRC e excreção de albumina acima de 30 mg/24 horas (ou equivalente, ou seja, outra apresentação da RAC que não em mg/g) cuja pressão arterial é consistentemente acima de 140 mmHg sistólica ou acima de 90 mmHg diastólica, sejam tratados com anti-hipertensivos para manter pressão arterial abaixo de 140 mmHg sistólica e abaixo de 90 mmHg diastólica.  
- Sugere que adultos diabéticos e não diabéticos com DRC e com excreção de albumina de urina acima de 30 mg/24 horas (ou equivalente) cuja pressão arterial é consistentemente acima de 130 mm Hg sistólica ou acima de 80 mm Hg diastólica sejam tratados com anti-hipertensivos para manter pressão arterial abaixo de 130 mmHg sistólica e abaixo de 80 mm Hg diastólica.  
- Sugere que BRA ou IECA sejam usados em adultos diabéticos com DRC e excreção de albumina de urina entre 30 e  
- 300 mg/24 horas (ou equivalente).  
- Recomenda que BRA ou IECA sejam usados tanto em adultos diabéticos como não diabéticos com DRC e excreção de  
- albumina de urina acima de 300 mg/24 horas (ou equivalente).  
- Não há evidências suficientes para recomendar a associação de IECA com BRA para evitar a progressão da DRC.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Qualidade das diretrizes** -->
Para as questões as quais foram utilizadas diretrizes já existentes para adotar as recomendações, a qualidade destas diretrizes incluídas foi avaliada com a ferramenta AGREE II ( _Appraisal of Guidelines for Research and Evaluation II_ )<sup>4</sup> . O  
processo de avaliação foi realizado por dois avaliadores independentes e previamente treinados. Para o _KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease_<sup>3</sup> , as pontuações obtidas foram 61%, 39%, 53%, 42%, 4% e 42%, respectivamente para os domínios 1, 2, 3, 4, 5 e 6. O domínio com a melhor pontuação foi escopo e finalidade, enquanto o domínio de maior déficit foi aplicabilidade. Apesar da alta qualidade metodológica, as diretrizes apresentaram limitações em alguns domínios como envolvimento de partes interessadas e aplicabilidade. Detalhes da avaliação metodológica da diretriz KDIGO constam no **Material Suplementar 1** .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **QUESTÃO 4. QUAL É A EFETIVIDADE DO USO DOS CETANÁLOGOS ASSOCIADOS A DIETA RESTRITA OU MUITO RESTRITA EM PROTEÍNAS PARA ATENUAR A PROGRESSÃO DA DRC?** -->
**<u>Recomendação:</u>** Estudos sugerem que uso de cetoanálogos (CA) associado à dieta com restrição proteica, tanto na forma de dieta hipoproteica (LPD, do inglês _Low Protein Diet_ , que consiste na ingestão diária ideal de 0,6 g de proteína/kg) quanto na forma de dieta muito pobre em proteínas (VLPD, do inglês _Very Low-Protein Diet_ , que consiste na ingestão diária ideal de 0,3 g de proteína/kg), retarda a progressão da DRC. No entanto, ainda não há evidências sobre o impacto dessas dietas na redução da necessidade da TRS e na mortalidade dos pacientes com DRC, por essas razões a tecnologia não foi incorporada pelo SUS (Relatório de recomendação 787, de novembro de 2022, Portaria SCTIE/MS nº 169/2022)<sup>12</sup> .  
A estrutura PICO para esta pergunta foi:  
**População:** Portadores de DRC estágios 3 e 4 (critérios diagnósticos de DRC)  
**Intervenção:** CA + restrição proteica (na forma de LPD ou VLPD)  
**Comparador:** restrição proteica ou placebo  
**Desfechos:** Redução da filtração glomerular (Taxa de filtração glomerular estimada; TFGe); níveis de Creatinina no  
sangue; níveis de ureia nitrogenada no sangue (BUN - do inglês, _blood urea nitrogen_ ).  
**Métodos e resultados da busca**  
Para responder à essa pergunta foi realizada uma busca sistematizada da literatura nas bases de dados MEDLINE via Pubmed ( _United States National Library of Medicine_ ), Biblioteca Cochrane, LILACS (Literatura Latinoamericana e do Caribe em Ciências da Saúde/BVS - Biblioteca Virtual em Saúde); Scopus (Elsevier) e Cochrane até 07/2022. As estratégias de busca para cada base estão descritas no **Quadro B** .  
**Quadro B** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e estudos clínicos.  
|**Base de dados**|**Estratégia**|
|---|---|
|**BVS**|("very low protein diets" ) AND ("chronic renal failure" OR “chronic renal disease” )|
|**SCOPUS**|( TITLE-ABS-KEY ( {very low protein diets}  OR  ketodiet  OR  {protein restricted diet}  OR  {Protein<br>Restricted Diets}  OR  {low protein diets}  OR  {protein free diet}  OR  {protein free diets}  OR  {low<br>protein diet} )  AND  TITLE-ABS-KEY ( {kidney failure, chronic}  OR  {end stage kidney disease}<br>OR  {end stage kidney disease}  OR  {chronic kidney failure}  OR  {end stage renal disease}  OR  {end<br>stage renal failure}  OR  {chronic renal failure}  OR  {chronic renal disease} OR esrd )  AND  TITLE-<br>ABS-KEY ( {amino acids}  OR  {keto acids}  OR  oxoacids  OR  {oxo acids}  OR  ketoanalogs  OR<br>ketoanalogue  OR  ketoanalogs ) )|
|**PUBMED**|Search: #1 AND #2 AND #3<br>#3 Search: ((((((("very low protein diets"[All Fields]) OR ("ketodiet"[All Fields])) OR ("protein<br>restricted diet"[All Fields])) OR (Protein Restricted Diets)) OR ("low protein diets"[All Fields])) OR<br>("protein free diet"[All Fields])) OR ("protein free diets"[All Fields])) OR ("low protein diet"[All<br>Fields])|
||#2<br>Search:<br>((((((("kidney<br>failure,<br>chronic"[MeSH<br>Terms])<br>OR<br>("end<br>stage<br>kidney<br>disease"[Title/Abstract])) OR ("end stage kidney disease"[Title/Abstract])) OR ("chronic kidney<br>failure"[Title/Abstract])) OR ("end stage renal disease"[Title/Abstract])) OR ("end stage renal<br>failure"[Title/Abstract])) OR ("chronic renal failure"[Title/Abstract])) OR (“chronic renal<br>disease”[Title/Abstract])) OR ("esrd"[Title/Abstract])|  
||#1<br>Search:<br>(((((("amino<br>acids"[Title/Abstract])<br>OR<br>("keto<br>acids"[MeSH<br>Terms]))<br>OR<br>("oxoacids"[Title/Abstract])) OR ("oxo acids"[Title/Abstract])) OR ("ketoanalogs"[Title/Abstract]))<br>OR ("ketoanalogue"[Title/Abstract])) OR (Ketoanalogs)|
|---|---|
|**COCHRANE**<br>**LIBRARY**|very low protein diets OR ketodiet OR protein restricted diet OR Protein Restricted Diets OR low<br>protein diets OR protein free diet OR protein free diets OR low protein diet<br>kidney failure chronic OR end stage kidney disease OR end stage kidney disease OR chronic kidney<br>failure OR end stage renal disease OR end stage renal failure OR chronic renal failure OR chronic renal<br>disease OR esrd<br>amino acids OR keto acids OR oxoacids OR oxo acids OR ketoanalogs OR ketoanalogue|
|**EMBASE**|#7 AND 'systematic review'/de<br>#1 AND #2<br>#2 'protein restriction'/exp OR 'oxoacid'/exp OR 'ketoanalogue'<br>#1 'chronic kidney failure'/exp|  
O processo de seleção dos estudos recuperados foi desenvolvido de acordo com as seguintes etapas: identificação e exclusão de duplicatas; primeira seleção dos estudos remanescentes, de acordo com critérios de inclusão e exclusão, por leitura de título e resumo; e segunda seleção por leitura completa. Foram considerados como critérios de elegibilidade as revisões sistemáticas, seguida por ensaios clínicos randomizados (ECR) na ausência das mesmas. A população-alvo consistiu de pacientes com DRC em estágio pré-dialítico. Foram considerados como critérios de exclusão: estudos _in vitro_ ou com modelos animais, opiniões de especialistas, resumos de congressos, revisões narrativas e estudos que não possuíam braço comparador ou que avaliaram desfechos diferentes do especificado na pergunta PICO. Foram recuperados 604 documentos dos quais 85 eram duplicatas. Foram selecionados para triagem pela leitura do título e resumo 519 documentos, dos quais 518 foram eliminados, restando 1 para etapa final de leitura completa ( **Figura A** ).  
**Figura A** - Fluxograma de identificação de estudos.  
<!-- Start of picture text -->
Estudos identificados:<br>MEDLINE (PubMed) (n = 225)<br>Scopus (n=131)  Estudos removidos antes da seleção:<br>BVS (n= 27)  Estudos duplicados (n= 85)<br>Cochrane (n= 165)<br>EMBASE (n = 56)<br>Estudos avaliados (n = 519)  Estudos excluídos (n = 518)<br>Textos  completos  avaliados  para<br>Estudos não acessados (n = 0 )<br>elegibilidade (n = 1)<br>Estudos em texto completo avaliados para<br>Estudos em texto completo excluídos:<br>elegibilidade (n = 1)<br>Publicações de resumo em evento<br>científico (n=0)<br>Estudos incluídos (n = 1)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Por fim, uma revisão sistemática (RS) foi incluída para a síntese de evidências por ser considerada a de melhor qualidade metodológica e a mais completa por atender à PICO definida. A revisão sistemática publicada por Li _et al_ ., 2019<sup>5</sup> foi publicada na _Nutrients_ e teve por objetivo avaliar o efeito do uso combinado de cetoanálogos e dieta restrita em proteínas em pacientes portadores de DRC em estágios 4 e 5 pré-dialítico, principalmente na progressão da doença. A busca realizada por Li e colaboradores foi realizada no PubMed e Embase até fevereiro de 2019. Foram incluídos dez ensaios clínicos randomizados (ECR) e dois ensaios clínicos não randomizados (ECNR) compreendendo um total de 951 pacientes.  
A qualidade metodológica dos estudos controlados não randomizados e dos randomizados incluídos na revisão sistemática de Li e colaboradores foi avaliada pela Escala de _Newcastle-Ottawa_<sup>6</sup> e _Cochrane Risk of Bias Tool_<sup>7</sup> respectivamente. A maioria dos estudos (mais de 75%) apresentou baixo risco de reporte e de atrito. No entanto, os estudos apresentaram baixo risco ou risco desconhecido de seleção, detecção e performance. Em relação ao viés de publicação, o gráfico de funil do efeito dos cetoanálogos na TFGe em pacientes com DRC demonstrou ser simétrico. A análise quantitativa do gráfico de funil pelo método de Egger<sup>8</sup> não foi realizada devido ao pequeno número de estudos incluídos. Por fim, a qualidade metodológica da RS foi realizada utilizando a ferramenta _Assessing the Methodological Quality of Systematic Reviews_ versão 2 (AMSTAR-2)<sup>9</sup> . A revisão foi associada a uma moderada qualidade devido, entre outros fatores, à ausência de informações metodológicas.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Redução da taxa de filtração glomerular estimada** -->
Os índices de função renal foram comparados entre o grupo de tratamento (LPD; dieta com baixo ou VLPD; muito baixo teor de proteína, associadas ao cetoanálogos - CA) e grupo controle (placebo) para avaliar o efeito de uma dieta restrita em  
proteína suplementada com CA na deterioração da função renal em pacientes com DRC. Para comparar o efeito do CA na prevenção da deterioração da TFGe, sete ECR e um ECNR foram alocados para conduzir uma meta-análise. Um modelo aleatório foi selecionado devido à grande heterogeneidade entre os estudos. No geral, o CA reverteu significativamente a diminuição de TFGe em pacientes com DRC (diferença de média (MD) = 2,74, IC95% 0,73 - 4,75, p = 0,008), conforme mostrado na **Figura B** .  
**Figura B** - Medida sumária para o desfecho prevenção da deterioração da taxa de filtração glomerular estimada (TFGe).  
<!-- Start of picture text -->
StudyBellizzor Subgroup Mean___SOKA Total MeancontrolSD Total_Weight_IV,Mean Random, Difference95% Cl IV,MeanRandom, Difference95% Cl<br>Foiton eo a t a l. 200 65 [1 48 ] 1 76 8 66G4 3012 17.24164 47226 8012 20.0191 %  -0.90[-4.45, 0,56(-2.02,3.14]3.85)<br>Gameate et al 2016 [7] 154 1093 104 108 828 103 197% — 4.30([1.68,6.94) =<br>Milovanova<br>Mircescu etal, 2018 [20] 29.1 988 42 2668 991 97 1.3% 250[14.72,19.74<br>PrakashQiu 201223] etal.20072004(22][21] 29.19154«27.6 913101186 2712 2977134225 1319159§1 261116 193%4.2%4.0% 5.10-0.58(-9.93, 20060.72,4.72) (3.98, 14.19)8.77]<br>Teplan 2008 [24] 298 86 66 232 84 65 183%  — 6.60(3.69,9.51) ~<br>Total (95% Cl) 3 350 100.0% — 2.74073, 4.75]<br>TestHeterogeneity:for overall effect:Tau?= 3.54;Z= 2.67Ch?iP==130 . 09 0 8), df= 7 (P = 0.05); = 50% a Favourste [eentrol] $ Favours [<A]+ ab<br><!-- End of picture text -->  
**Fonte:** Adaptado de Li _et al_ ., 2019<sup>5</sup> .  
Uma análise de subgrupo foi conduzida para investigar se o uso combinado de CA com dieta pobre em proteínas (LPD) é mais eficaz do que o uso de CA com dieta muito pobre em proteínas (VLPD) na prevenção da deterioração da função renal. Embora a diferença de média da TFGe tenha sido maior no grupo LPD (MD = 5,41, IC95% 1,74 -9,08), uma diferença significativa entre dois subgrupos não foi encontrada (p = 0,10) ( **Figura C** ).  
**Figura C** - Medida sumária do efeito do CA na taxa de filtração glomerular estimada (TFGe) em pacientes com DRC estratificados por tipo de dieta de restrição proteica.  
<!-- Start of picture text -->
‘Stuy1.2.1 eGFRof Subgroup(KAVLPv.s. LP) Mean KASD Total MeanControlSD Total Weight IV,Mean Random, Difference95% Cl IV,Mean Random, Difference95% Cl<br>Boliz otal. 2006 [14] 178 66 30 17.24 472 80 200%  0.56/2.02, 319]<br>Feiten etal. 2005 [18] 158 64 12 161 36 12 131% -0.306445,3.85]<br>Gaineats el al. 2016 [7] 151 1093 104 108 828 103 197% — 4.30/1.09,0.94) -<br>Mircescu 2007 [21] 1545 27 134 61 26 199% — 2.006072, 4.72]<br>Pravashetal.2004(22] 276 101 18 225 159 16 42% 5:10/3.98,14.13)<br>‘Subtotal (95% Cl) 191 237 76.3% 2.00.22, 3.79]<br>Hetstogeneity:Taut= 1.23; Ch?<br>Test for overal effect Z= 2.20 iP == 6.74, 0.03) df= 4 (P= 0.22); P= 30%<br>1.2.2 eGFR (KALP vs. LP)<br>Milovanova etal. 20'8 (20) 291 388 42 266 391 37 1.3% 250514.72,19.72]<br>iu 2012/23] 2019 913° 12 20.77 1319 11 4.0% — -0.58 9.93, 8.77]<br>Teplan 2008 [24] 298 86 66 232 84 65 189%  6.60(3.63,9.51] ——<br>‘Subtotal (95% Cl) 120 113° 23.7% — SAA[1.74, 9.08] ><br>Hetatogeneity:Tau*=<br>Tes{ for overall effect.Z=2.09; 2.89Ch?=#P  2.22,= 0.004)df= 2 (P= 0.33); P= 10%<br>Total (95% Cl) a 350 100.0% — 2.740.735, 4.75] ><br>Hetsrogeneity:Tau= 3.54; Ch?= 13.90, df= 7 (P = 0.05), 7= 60% tt<br>Test for overal effect Z= 2.67 P = 0008) Favours [control] Favours KA]<br>Test<br>for subaroup diferences: Chi*= 2.67, df=1 (P= 0.10), F=62.6%<br><!-- End of picture text -->  
KAVLP: dieta muito pobre em proteínas suplementada com cetoanálogos. KALP: dieta hipoprotéica suplementada com cetoanálogos. LP: dieta pobre em proteínas. **Fonte:** Adaptado de Li _et al_ ., 2019<sup>5</sup> .  
Uma vez que foi evidenciado que o uso de CA é eficiente na prevenção da deterioração de TFGe em pacientes com DRC, foi avaliado se o uso precoce de CA traz benefícios aos pacientes com DRC. No total, quatro estudos (394 pacientes) foram incluídos no subgrupo de TFGe < 18 mL/min por 1,73 m<sup>2</sup> , e quatro estudos (267 pacientes) foram incluídos no subgrupo de  
TFGe > 18 mL/min/1,73 m<sup>2</sup> . Foi constatado que a suplementação com CA beneficia pacientes com DRC com TFGe > 18 mL/min/1,73 m<sup>2</sup> (MD = 5,81, IC95% 3,19 - 8,44, p < 0,0001), mas não beneficia pacientes com TFGe < 18 mL/min/1,73 m<sup>2</sup> (MD = 1,87, IC95% -0,08 - 3,81, p = 0,06. A diferença entre os dois subgrupos também foi significativa (p = 0,02). Os resultados sugerem que o uso de CA associado à dieta restrita de proteínas preserva a função renal em pacientes com DRC. Embora o CA+VLPD não seja melhor que CA+LPD no controle da TFGe, o uso combinado de CA e dieta restrita em proteínas de forma precoce pode trazer benefícios para os pacientes portadores de DRC ( **Figura D** ).  
**Figura D** - Medida sumária do efeito do CA na prevenção da deterioração da taxa de filtração glomerular estimada (TFGe) em pacientes estratificados por TFGe menor ou maior que 18 mL/min/1,73 m<sup>2</sup> .  
<!-- Start of picture text -->
Study KA Controt Mean Difference ‘Mean Difference<br>1.3.1 GFRor Subgrou < 18 Mean SD _Total_Mean__SD_Total_Weight_1V. Random.95% Cl IV.Random,95% CL<br>GameateMircescuBolizFeiten oe tal. 2007et al 200 (21)562016 [1 45 ] [7] 151184-5 1 7@58 1083 6 64 108(272012 17.24108134161 8284723661 103122680 131197%19.3%20.0 % -2,000.72, 0.  4.30[1.85,0.98)66/-2.02,30[-4.45,3.85]4.72]2.141 -<br>Subtotal (95% Ci) 173 221 72.0% —1.871-0.08, 3.81]<br>Heterogeneity: Taut= 1.63; Ch?<br>Test = 6.29, d= 3 (P= 0.15); = 43%<br>1.32 foreGRR> overall18effect Z = 1.88 iP = 0.08)<br>Milovanova etal 2018 (20) 291 388 42 266 391 37 1.3% 260f1872.1972)<br>Praxashatal.2004(22)iu 201223) 204927.6 101913 1812 2077225 1310169 1611 4.2%40%  -0.58(-0.03,5.10(3.98,14.18}8.77)<br>Teplan 2008 [24] 298 86 66 232 84 65 183% 6.60/363,951] =<br>‘Subtotal (95% CI) 138 120° 27.9% — §.81[3.19, 8.44] a<br>Heterogeneity: Tau?= 0,09; Ch#= 2.24, di= 3 (P = 0.52); P= 0%<br>Test for werall effect. Z= 4.34 (P < 0.0001)<br>Total (95% cD an 350 100.0% — 2.7410.73,4.791<br>Heterogeneity: Tau= 3.54; Ch? = 19.90, of= 7 (P = 0.05); = 50% tos tah<br>Test for overall effect: Z= 2.67 (P = 0.008) re<br>Test for subgroup differences: Chit= 6.61, df=1 (P= 0.02), F=82.2% Favours contol] Favours FAI<br><!-- End of picture text -->  
**Fonte:** Adaptado de Li _et al_ ., 2019<sup>5</sup> .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Níveis de creatinina no sangue** -->
O efeito do CA na creatinina sérica foi analisado em seis estudos (408 pacientes). No geral, uma diferença significativa foi observada entre os grupos CA e controle (MD = 0,21, IC95% 0,01 - 0,41, p = 0,04). Pacientes do subgrupo da TFGe > 18 mL/min/1,73 m<sup>2</sup> se beneficiaram com o uso dos cetoanálogos (MD = 0,22, IC95% 0,01- 0,43, p = 0,04). No entanto, no subgrupo de TFGe < 18 mL/min/1,73 m<sup>2</sup> , não foi encontrada diferença significativa entre os grupos intervenção e controle (MD = 0,18, IC95% 0,44 - 0,80, p = 0,57) ( **Figura E** ).  
**Figura E** . Medida sumária do efeito do CA na creatinina em pacientes com DRC estratificados por eGFR menor ou maior que 18 mL/min/1,73 m<sup>2</sup> .  
<!-- Start of picture text -->
Study1-41 creatinineor Subgroup(eGFR < 19) MeancontrolSD Total__Mean KA SO_Total_Weight MeanIV, Fixed,  Difference05% Cl IV,Mem Fixed, Difference05%Cl<br>Feten<br>et al. 2005 [16] 4904512 46 18 12 23% 0301.03, 1.63]<br>Heckng<br>SubtotalMircoscu 2097et(95%al  Ch'930[21] 117] AQT7372 18089132 53$526 T29634.751131 1.967231.4705 27-54%5415 10.4%28% 0010.18[0.14,0.23 f1.24.1.19)(083, 02 1. 0 8 ]<br>TestHeterogenery:ior overall Chi*=effect 0.74,Z= 0.57c= @ =2 (P=057)0.93), = 0%<br>1.4.2 creatinine (@GFR<br>Berhaidetal 2000(15> 13) 2.864 O87! 6 27BCIEI 1.753394 8 1.6% 0.2041.38, 1.77)<br>Kishretal<br>KishretPrakash al. LEPHB? 19941994 [18][13] 3898236 09 67 3234 OS08 6165 391%470% 030/0020.106019 062)0.39<br>(05% Cl 154 150 89.6% 0.22[0.01, 0.43]<br>Subtotal etal. 2094 [22] a6] 19 «18 «207 08 18 18% 1.456002, 292]<br>Heterogenety: Cnit= 3.59, d1= 3 (P= 0.31), t= 17%<br>Test ior overall effect Z= 2.02 @ = 0.04)<br>Total (95% C1) 204 204 1000% 0.2110.01,0.44)<br>Heterogeneity: Chi= 3.75, di=6 (P= 0.71), F=0% th a<br>Test‘or overall effect 2= 2.10 @ = 0.08) Favours [control] Favours IA]<br>Test ‘orsubaroup cifferences: Chi?= 0.01, df= 1 (P = 0.91), = 0%<br><!-- End of picture text -->  
**Fonte:** Adaptado de Li _et al_ ., 2019<sup>5</sup> .  
**Níveis de ureia nitrogenada no sangue (BUN – do inglês,** **_blood urea nitrogen_ )**  
O efeito geral do CA nos níveis de BUN foi significativo (MD = 26,89, IC95% 10,66 - 43,11, p = 0,001). Análise por subgrupo mostrou uma diminuição significativa no nível de BUN no subgrupo de TFGe < 18 mL/min/1,73 m<sup>2</sup> (MD = 30,40, IC95% 8,98 - 51,83, p = 0,005) e o subgrupo de TFGe> 18 mL/min/1,73 m<sup>2</sup> (MD = 12,52, IC95% 5,56 - 19,49, p = 0,0004) ( **Figura F** ).  
**Figura F** . Medida sumária do efeito do CA nos níveis de ureia nitrogenada em pacientes com DRC estratificados por TFGe menor ou maior que 18 mL/min/1,73 m<sup>2</sup> .  
<!-- Start of picture text -->
‘Study1.5.1 BUN of Subgroup (eGFR Mean Controt‘SD _Total_Mean KA SD Total Weight IV,‘MoanRandom, Difference95% Ct 1v,‘MeanRandom, Difference95% Cl<br>Bellz < 78)<br>Feiton oe t  aa , l . 20 20 0 56 [ 6] ( 1 4) sare568 1 8221-2312 17096630436 149 12 15TF . 18 % — 41.6513.200.0 35 .1 51 ,  47.15}26.61] -<br>Garneata etal, 2016 [7] 226 197.9292 103 122 3382003 104 10.5% 104.00{7282, 135.18] _—_<br>Heckinget<br>Mircescu al.1920[17] 65.91 21.1215 «G09 = 1647-18 15.8% © $.01 2.54, 18.56]<br>Subtotal (95%2007 C1)[21] 81.26 926 17926 4308 «= 99727188 1776 .2% «© 30.408.18 183 . 0098 , 5113 . 8336 ) I".=><br>Heterogeneity.Test Tau"= 536.78, Ch = | 10.32, df=4 (F < 0.00001), "= 96%<br>for overall effact: Z= 278@ = 0,005)<br>1.5.2 BUN (eGFR > 18)<br>Milovanova<br>etal 2016 (20] 35.28 20.85 «37 2324 «= O.94 42 18.9% ©1204 (5.00, 18.08) =<br>Prakash<br>‘Subtotal et al(95% 2004(22)CI) 100.1 9511853 652 2 6018 236 . 98 % 34.9012,52513 . 5600 , 19.49]82.80) °<br>Heterageneity,<br>Test Tau?= 0.00; Chi¥= 0.88, df=1 (P= 0.35); = 0%<br>for overall effect: Z=3.52 (P = 0.0004)<br>Total (05% Cl) 232 248 100.0% — 26,89 10.66, 43.11] ><br>Heterogeneity,<br>Test Tau*= 331.93; Ch = 118.02, df= 6 (F < 0.00001),F= 95% ate de daa<br>Test forfor overallsubaroupeffect:differences:Z= 3.26  Chit=(P = 0.001)2.42, df=1(P=012), P= 58.7% Farours cortrol! Favours IKAI<br><!-- End of picture text -->  
**Fonte:** Adaptado de Li _et al_ ., 2019<sup>5</sup> .

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Perfil de evidências** -->
A **Tabela A** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos: redução da taxa filtração glomerular estimada; níveis de creatinina séricos e; níveis de ureia. A qualidade da certeza da evidência foi considerada muito baixa, conforme mostrado abaixo.  
**Tabela A -** Avaliação da certeza da evidência do uso de cetoanálogos associados à dieta restrita em proteínas em pacientes com doença renal crônica.  
|**Avaliaç**|**ão da certeza**||||||**№ de paci**|**entes**|**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Deterio**|<br> <br>**Delineamento**<br>**do estudo**<br>**ração da taxa de**|**Risco de**<br>**viés**<br>**filtração g**|**Inconsistência**<br>**lomerular (TGF**|**Evidência**<br>**indireta**<br>**)**|**Imprecisão**|**Outras**<br>**considerações**|**CA**<br> <br>**dieta**|**+**<br>**Dieta**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|5|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave<sup>b</sup>|grave<sup>c</sup>|nenhum|191|237|-|MD**2 mais alto**<br>(0.22 mais alto para<br>3.79 mais alto)|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|**Níveis**|**de ureia (BUN)**||||||||||||
||ensaios|||||||||MD<br>**26.89**<br>**mais**<br>**alto**|⨁◯◯◯||
|7<br>**Níveis**|clínicos<br>randomizados<br>**de creatinina**|grave<sup>a</sup>|muito grave<sup>d</sup>|não grave|grave<sup>e</sup>|nenhum|248|232|-|(10.66 mais alto<br>para<br>43.11<br>mais<br>alto)|Muito<br>baixa|CRÍTICO|
|6|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|grave<sup>f</sup>|nenhum|204|204|-|MD**0.21 mais alto**<br>(0.01 mais alto para<br>0.41 mais alto)|⨁⨁◯◯<br>Baixa|CRÍTICO|  
**Legenda: BUN:** níveis de ureia nitrogenada no sangue, do inglês _blood urea nitrogen_ ); **CI:** intervalo de confiança, do inglês _confidence interval_ ; **MD:** diferença de média, do inglês _mean difference_ .  
**Explicações: a.** De acordo com a ferramenta da Cochrane para ensaios clínicos randomizados, a maioria dos estudos (mais de 75%) apresentou baixo risco de reporte e de atrito. No entanto, os estudos também apresentaram baixo risco ou risco desconhecido de seleção, detecção e performance. **b.** I<sup>2</sup> = 30% **c.** Amplo IC95% em torno da estimativa do efeito (0,22, 3,79). **d.** I<sup>2</sup> = 95%. **e.** Amplo IC95% (10,66 – 43,11). **f.** Amplo IC95% em torno da estimativa do efeito (0,01 - 0,41).  
**QUESTÃO 5: Qual é a efetividade do uso dos iSGLT-2 para atenuar a progressão da DRC?** **<u>Recomendação:</u>** Sugerimos que os pacientes com DRC estágios 2 a 4 utilizem iSGLT-2 para atenuar a progressão da DRC (certeza da evidência de moderada a alta).  
A estrutura PICO para esta pergunta foi: **População:** Portadores de DRC estágios 2 a 4 (critérios diagnósticos de DRC) **Intervenção:** iSGLT-2 + (IECA ou BRA) **Comparador:** Medicamentos que bloqueiam o sistema renina angiotensina aldosterona (IECA ou BRA) **Desfechos:** Redução da filtração glomerular; eventos cardiovasculares; mortalidade por todas as causas e cardiovascular; taxa de filtração glomerular estimada; segurança  
**Métodos e resultados da busca**  
Para essa questão, foram adotadas as recomendações do _Dapagliflozin for treating chronic kidney disease Technology appraisal guidance,_ publicado em 2022 pelo NICE<sup>13</sup> (www.nice.org.uk/guidance/ta775), e do Relatório de Recomendação nº 773/2022, para avaliação da incorporação da dapagliflozina para tratamento de pacientes adultos com doença renal crônica em uso de terapia padrão pela Conitec<sup>11</sup> .  
Para a condução da revisão sistemática, foi realizada busca sistematizada da literatura nas bases de dados MEDLINE via Pubmed ( _United States National Library of Medicine_ ), EMBASE<sup>®</sup> (Elsevier<sup>®</sup> ), Biblioteca Cochrane, LILACS (Literatura Latinoamericana e do Caribe em Ciências da Saúde/BVS - Biblioteca Virtual em Saúde); ClicalTrials.gov ( _U.S. National Library of Medicine_ ) e _World Health Organization_ (WHO) _International Clinical Trials Registry Portal,_ até a data 05/04/2022. As estratégias de busca para cada base estão descritas no **Quadro C** .  
**Quadro C** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e estudos clínicos.  
|**Bases de dados**|**Estratégia de busca**|**Nº**<br>**de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|**Pubmed**|("Kidney Diseases"[MeSH Terms] OR "renal insufficiency, chronic"[MeSH Terms] OR|301|
|**(****_United_**<br>**_States_**|"kidney failure, chronic"[MeSH Terms] OR "Chronic Renal Insufficiencies"[All Fields]||
|**_National Library_**|OR "Chronic Renal Insufficiency"[All Fields] OR "kidney insufficiency chronic"[All||
|**_of_**<br>**_Medicine_) **<br>**(para ECR)**|Fields] OR "Chronic Kidney Insufficiency"[All Fields] OR "Chronic Kidney<br>Diseases"[All Fields] OR "Chronic Kidney Disease"[All Fields] OR "disease chronic<br>kidney"[All Fields] OR "diseases chronic kidney"[All Fields] OR "kidney disease<br>chronic"[All Fields] OR "kidney diseases chronic"[All Fields] OR "Chronic Renal<br>Diseases"[All Fields] OR "Chronic Renal Disease"[All Fields] OR "disease chronic<br>renal"[All Fields] OR "diseases chronic renal"[All Fields] OR "renal disease chronic"[All<br>Fields] OR "renal diseases chronic"[All Fields] OR "kidney disease*"[All Fields] OR<br>"renal disease*"[All Fields] OR "kidney failure"[All Fields] OR "renal failure"[All Fields]<br>OR "CKF"[All Fields] OR "CKD"[All Fields] OR "CRF"[All Fields] OR "CRD"[All<br>Fields] OR "renal impairment*"[All Fields] OR "end stage kidney disease"[All Fields]<br>OR "disease end stage kidney"[All Fields] OR "end stage<br>kidney disease"[All Fields] OR "kidney disease end stage"[All Fields] OR "Chronic<br>Kidney Failure"[All Fields] OR "end stage renal disease"[All Fields] OR "disease end<br>stage renal"[All Fields] OR "end stage renal disease"[All Fields] OR "renal disease end<br>stage"[All Fields] OR "renal disease end stage"[All Fields] OR "renal failure end||  
|**Bases de dados**|**Estratégia de busca**|**Nº**<br>**de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||stage"[All Fields] OR "End-Stage Renal Failure"[All Fields] OR "renal failure end<br>stage"[All Fields] OR "renal failure chronic"[All Fields] OR "Chronic Renal Failure"[All<br>Fields] OR ("kidney failure, chronic"[MeSH Terms] OR ("kidney"[All Fields] AND<br>"failure"[All Fields] AND "chronic"[All Fields]) OR "Chronic Kidney Failure"[All<br>Fields] OR "esrd"[All Fields]) OR "ESKD"[All Fields] OR "ESRF"[All Fields] OR<br>"ESKF"[All<br>Fields])<br>AND<br>("dapagliflozin"[Supplementary<br>Concept]<br>OR<br>("dapagliflozin"[Supplementary<br>Concept]<br>OR<br>"dapagliflozin"[All<br>Fields]<br>OR<br>"dapagliflozin s"[All Fields]) OR ("dapagliflozin propanediol"[All Fields] OR<br>"dapagliflozin"[Supplementary<br>Concept]<br>OR<br>"dapagliflozin"[All<br>Fields]<br>OR<br>"farxiga"[All<br>Fields]<br>OR<br>"dapagliflozin<br>s"[All<br>Fields])<br>OR<br>("dapagliflozin"[Supplementary<br>Concept]<br>OR<br>"dapagliflozin"[All<br>Fields]<br>OR<br>"forxiga"[All Fields]) OR "bms 512148"[All Fields] OR "BMS512148"[All Fields] OR<br>"bms 512148"[All Fields] OR "461432-26-8"[All Fields] OR "1ull0qj8uc"[EC/RN<br>Number] OR "s1548"[All Fields]) AND (("randomized controlled trial"[Publication<br>Type] OR "controlled clinical trial"[Publication Type] OR "randomized"[Title/Abstract]<br>OR<br>"placebo"[Title/Abstract]<br>OR<br>"drug<br>therapy"[MeSH<br>Subheading]<br>OR<br>"randomly"[Title/Abstract] OR "trial"[Title/Abstract] OR "groups"[Title/Abstract]) NOT<br>("animals"[MeSH Terms] NOT "humans"[MeSH Terms]))||
|**Pubmed**<br>**(****_United_**<br>**_States_**<br>**_National Library_**<br>**_of Medicine_) **<br>**(para RS)**|("Kidney Diseases"[MeSH Terms] OR "renal insufficiency, chronic"[MeSH Terms] OR<br>"kidney failure, chronic"[MeSH Terms] OR "Chronic Renal Insufficiencies"[All Fields]<br>OR "Chronic Renal Insufficiency"[All Fields] OR "kidney insufficiency chronic"[All<br>Fields] OR "Chronic Kidney Insufficiency"[All Fields] OR "Chronic Kidney<br>Diseases"[All Fields] OR "Chronic Kidney Disease"[All Fields] OR "disease chronic<br>kidney"[All Fields] OR "diseases chronic kidney"[All Fields] OR "kidney disease<br>chronic"[All Fields] OR "kidney diseases chronic"[All Fields] OR "Chronic Renal<br>Diseases"[All Fields] OR "Chronic Renal Disease"[All Fields] OR "disease chronic<br>renal"[All Fields] OR "diseases chronic renal"[All Fields] OR "renal disease chronic"[All<br>Fields] OR "renal diseases chronic"[All Fields] OR "kidney disease*"[All Fields] OR<br>"renal disease*"[All Fields] OR "kidney failure"[All Fields] OR "renal failure"[All Fields]<br>OR "CKF"[All Fields] OR "CKD"[All Fields] OR "CRF"[All Fields] OR "CRD"[All<br>Fields] OR "renal impairment*"[All Fields] OR "end stage kidney disease"[All Fields]<br>OR "disease end stage kidney"[All Fields] OR "end stage<br>kidney disease"[All Fields] OR "kidney disease end stage"[All Fields] OR "Chronic<br>Kidney Failure"[All Fields] OR "end stage renal disease"[All Fields] OR "disease end<br>stage renal"[All Fields] OR "end stage renal disease"[All Fields] OR "renal disease end<br>stage"[All Fields] OR "renal disease end stage"[All Fields] OR "renal failure end<br>stage"[All Fields] OR "End-Stage Renal Failure"[All Fields] OR "renal failure end<br>stage"[All Fields] OR "renal failure chronic"[All Fields] OR "Chronic Renal Failure"[All<br>Fields] OR ("kidney failure, chronic"[MeSH Terms] OR ("kidney"[All Fields] AND|147|  
|**Bases de dados**|**Estratégia de busca**|**Nº**<br>**de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||"failure"[All Fields] AND "chronic"[All Fields]) OR "Chronic Kidney Failure"[All<br>Fields] OR "esrd"[All Fields]) OR "ESKD"[All Fields] OR "ESRF"[All Fields] OR<br>"ESKF"[All<br>Fields])<br>AND<br>("dapagliflozin"[Supplementary<br>Concept]<br>OR<br>("dapagliflozin"[Supplementary<br>Concept]<br>OR<br>"dapagliflozin"[All<br>Fields]<br>OR<br>"dapagliflozin s"[All Fields]) OR ("dapagliflozin propanediol"[All Fields] OR<br>"dapagliflozin"[Supplementary<br>Concept]<br>OR<br>"dapagliflozin"[All<br>Fields]<br>OR<br>"farxiga"[All<br>Fields]<br>OR<br>"dapagliflozin<br>s"[All<br>Fields])<br>OR<br>("dapagliflozin"[Supplementary<br>Concept]<br>OR<br>"dapagliflozin"[All<br>Fields]<br>OR<br>"forxiga"[All Fields]) OR "bms 512148"[All Fields] OR "BMS512148"[All Fields] OR<br>"bms 512148"[All Fields] OR "461432-26-8"[All Fields] OR "1ull0qj8uc"[EC/RN<br>Number] OR "s1548"[All Fields]) AND (("meta-analysis"[Publication Type] OR "meta<br>analysis as topic"[MeSH Terms] OR "meta-analysis"[All Fields] OR "literature<br>review"[All Fields] OR "review literature"[All Fields] OR "meta analy*"[Text Word] OR<br>"metaanal*"[Text Word] OR ("systematic*"[All Fields] AND ("review*"[All Fields] OR<br>"overview*"[All<br>Fields]))<br>OR<br>"metaanalysis"[Publication<br>Type]<br>OR<br>"review"[Publication Type] OR "review"[Title]) NOT ("case report"[All Fields] OR<br>"letter"[Publication Type] OR "historical article"[Publication Type]))||
|**EMBASE**<sup>**®**</sup><br>**(Elsevier**<sup>**®**</sup>**)**<br>**(para ECR)**|<br>('chronic kidney failure'/exp OR 'kidney disease'/exp OR 'kidney failure'/exp OR 'renal<br>impairment'/exp OR 'end stage renal disease'/exp OR 'chronic renal<br>insufficienc*' OR 'chronic kidney insufficienc*' OR (('chronic kidney diseas*' OR<br>'chronic renal diseas*' OR 'kidney diseas*' OR 'renal diseas*' OR 'kidney failure' OR 'renal<br>failure') AND ckf) OR ckd OR crf OR crd OR 'renal impairment*' OR 'endstage kidney<br>disease' OR 'end-stage renal disease' OR 'end-stage renal failure' OR 'chronic renal failure'<br>OR esrd OR eskd) AND ('dapagliflozin'/exp OR dapagliflozin OR farxiga OR forxiga OR<br>'bms 512148' OR 'bms512148' OR 'bms-512148' OR '461432 26 8' OR 1ull0qj8uc OR<br>s1548) AND ('crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR<br>factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR<br>placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1<br>blind*):de,ab,ti) OR assign*:de,ab,ti OR<br>allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND ('article'/it OR 'article in press'/it)|308|
|**EMBASE**<sup>**®**</sup><br>**(Elsevier**<sup>**®**</sup>**)**<br>**(para RS)**|('chronic kidney failure'/exp OR 'kidney disease'/exp OR 'kidney failure'/exp OR 'renal<br>impairment'/exp OR 'end stage renal disease'/exp OR 'chronic renal<br>insufficienc*' OR 'chronic kidney insufficienc*' OR (('chronic kidney diseas*' OR<br>'chronic renal diseas*' OR 'kidney diseas*' OR 'renal diseas*' OR 'kidney failure' OR 'renal<br>failure') AND ckf) OR ckd OR crf OR crd OR 'renal impairment*' OR 'endstage kidney<br>disease' OR 'end-stage renal disease' OR 'end-stage renal failure' OR 'chronic renal failure'<br>OR esrd OR eskd) AND ('dapagliflozin'/exp OR dapagliflozin OR farxiga OR forxiga OR<br>'bms 512148' OR 'bms512148' OR 'bms-512148' OR '461432 26 8' OR 1ull0qj8uc OR|76|  
|**Bases de dados**|**Estratégia de busca**|**Nº**<br>**de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||s1548) AND ('meta analysis'/exp OR (meta AND (analy* OR metaanalys*)) OR<br>(systematic AND (review* OR overview*)) OR 'reference lists':ab OR bibliograph*:ab<br>OR 'hand search*':ab OR 'manual search*':ab OR 'relevant journals':ab OR (('data<br>extraction':ab OR 'selection criteria':ab) AND review:pt)) NOT (comment OR letter OR<br>editorial) NOT animal NOT (animal AND human)||
|**Biblioteca**<br>**Cochrane**|('chronic renal insufficienc*' OR 'chronic kidney insufficienc*' OR (('chronic kidney<br>diseas*' OR 'chronic renal diseas*' OR 'kidney diseas*' OR 'renal diseas*' OR 'kidney<br>failure' OR 'renal failure') AND ckf) OR ckd OR crf OR crd OR 'renal impairment*' OR<br>'end-stage kidney disease' OR 'end-stage renal disease' OR 'endstage renal failure' OR<br>'chronic renal failure' OR esrd OR eskd) AND dapagliflozin|0|
|**ClicalTrials.gov**<br>**(****_U.S. National_**<br>**_Library of_**<br>**_Medicine_) **|dapagliflozin | Chronic Kidney Diseases|17|
|**LILACS**|(“Insuficiência Renal Crônica” or “Doença Crónica Renal” or “Doença do Rim<br>Crônica” or “Doença Renal Crônica” or “Doenças Crônica do Rim” or “Doenças Crônicas<br>do Rim” or “Doenças Crônicas Renais” or “Doenças do Rim Crônicas” or “Doenças<br>Renais Crônicas” or “Insuficiência Crônica do Rim” or “Insuficiência Crônica Renal” or<br>“Insuficiência do Rim Crônica” or “Insuficiências Crônicas do Rim” or “Insuficiências<br>Crônicas Renais” or “Insuficiências do Rim Crônicas” or “Insuficiências Renais<br>Crônicas” or “Nefropatia Crônica” or “Nefropatias Crônicas” or “Renal Insufficiency,<br>Chronic” or “Insuficiencia Renal Crónica” or “Insuffisance rénale chronique”) AND<br>(dapagliflozina or dapagliflozin)|71|
|**WHO registry**|dapagliflozin|47|  
O processo de seleção dos estudos recuperados foi desenvolvido de acordo com as seguintes etapas: identificação e exclusão de duplicatas; primeira seleção dos estudos remanescentes, de acordo com critérios de inclusão e exclusão, por leitura de título e resumo e; segunda seleção por leitura completa.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes - Pacientes adultos com doença renal crônica (DRC) em uso de terapia padrão;  
- (b) Tipo de intervenção - Dapagliflozina + terapia padrão;  
- (c) Tipos de estudos - Revisões sistemáticas com ou sem meta-análise, ensaios clínicos randomizados e avaliações  
- econômicas.  
- (d) Desfechos - Avaliação clínica: eficácia**, segurança ou qualidade de vida relacionada à saúde; avaliação econômica:  
- razão de custo-efetividade incremental e razão de custo utilidade incremental;  
- (e) Idioma - Foram selecionados somente estudos publicados em inglês, espanhol e português.  
Foram recuperados 967 documentos dos quais 374 eram duplicatas. Foram selecionados para triagem pela leitura do título e resumo 593 documentos, dos quais 563 foram eliminados, restando então 30 para etapa final de leitura completa. Após leitura completa foram eliminados 24 estudos. Dessa forma foram incluídos 6 estudos para análise ( **Figura G** ).  
Todos os seis ECR de fase 3 foram incluídos na síntese de evidências e estão descritos no **Material Suplementar 2** . A avaliação do risco de viés dos estudos foi realizada com a ferramenta C _ochrane Risk of Bias Tool for Randomized Controlled Trials_ - versão 2.0 (RoB 2.0)<sup>10</sup> . Para os desfechos analisados, o risco de viés foi considerado baixo para todos os estudos incluídos.  
**Figura G** - Fluxograma de identificação de estudos.  
<!-- Start of picture text -->
Registros identificados*:<br>Pubmed ECR (n = 301)<br>Pubmed SR (n = 147)<br>Embase ECR (n = 308) Registros removidos apos<br>Embase SR (n = 76) selegao<br>Cochrane (n = 0) Registros duplicados (n= 374)<br>Clinicaltrial (n = 17)<br>LILACS (n = 71)<br>WHO registrer (n= 47)<br>Registro para a leitura de tituloe |————-»| Registros excluidos<br>resumo (n = 593) (n = 563)<br>Registros acessados para a Registros ndo acessados<br>etapa 2 (n = 30) |>] (n=0)<br>Registros acessados para a<br>leitura na integra (n = 30) —><br>Registros excluidos:<br>(n=24)<br>Estudos incluidos na reviséo<br>(n =6)<br><!-- End of picture text -->  
**Resumo das evidências:**

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Recomendações do NICE**<sup>**2**</sup> -->
A dapagliflozina é recomendada como opção para o tratamento de doenças renais crônicas (DRC) em adultos, somente

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: se: -->
- O medicamento for um complemento aos cuidados padrão otimizados, incluindo a dose aprovada mais tolerada de  
- IECA ou BRA, a menos que estes estejam contraindicados; e  
- Pacientes tenham taxa de filtração glomerular estimada (TGF) de 25 a 75 mL/min/1,73 m<sup>2</sup> no início do tratamento e  
- diabetes melito tipo 2 ou RAC igual ou superior a 22,6 mg/mmol.  
**Recomendações da Conitec**  
**Redução da taxa de filtração glomerular (TFG)**  
Na meta-análise do primeiro desfecho (decréscimo da TFG; necessidade de TRS, diagnóstico de doença renal em estágio final (DREF) ou morte por causas renais) foram utilizados dados provenientes de três estudos (todos análises por intenção de tratar - ITT). A utilização de dapagliflozina 10 mg uma vez ao dia, associada a IECA ou BRA, em comparação ao placebo associado a IECA ou BRA diminui a taxa de eventos em 44%, em média, com significância estatística (HR 0,56; IC95% 0,48 a 0,64; p<0,00001; I<sup>2</sup> = 0%) ( **Figura H** ).  
**Figura H** - Medida sumária para o desfecho composto decréscimo de TFG.  
<!-- Start of picture text -->
Dapagifiozina<br>Study 10 mg Placebo Hazard Ratio Hazard Ratio<br>Heerspinkof Subgrou ward Ratio) SE Total __Total_Weight_1V, Random, 95%Cl IV, Random,95% Cl<br>WitMcMurray 2019 20192020 0579803425016349 0.1116024410.1067 2152215227323718582 8578 434%47.5%91% —0.53/0.43,—0.56(0.45,070)071 10.44, 1.19]065) **<br>Total (95% Ch) 13107 13101 100.0% 0.56 0.48, 0.64) +<br>TestforHeterogeneltyoverall efectTaut= Z=0.00; Chit=7.96 @ < 1.21, 0.00001)df= 2 (P= 0.58),= 0% ootFavours (éapagiitina] i Favours [placebo]10 100<br><!-- End of picture text -->  
**Eventos cardiovasculares (hospitalização por insuficiência cardíaca ou morte por causas cardiovasculares)**  
Para este desfecho composto, foi avaliado principalmente o estudo de Heerspink _et al._ , 2020, no qual foram incluídos somente indivíduos com DRC na linha de base. O estudo do grupo de Wiviott _et al_ ., 2019 foi avaliado de forma subsidiária para coletar informações sobre desfechos cardiovasculares em subgrupos com DRC. O estudo avaliou o tempo até o primeiro de dois eventos, hospitalização por insuficiência cardíaca ou morte por causas cardiovasculares. Após o período de seguimento com mediana de 2,4 anos, o uso de dapagliflozina associada a IECA ou BRA diminuiu a taxa de hospitalização por insuficiência cardíaca ou morte por causas cardiovasculares em média por 29%, com diferença estatística significativa (HR 0,71; IC95% 0,55 - 0,92; p=0,009), comparado ao uso de IECA ou BRA isolado. No estudo de Wiviott _et al_ ., 2019, duas análises de subgrupos mostraram o efeito de dapagliflozina associada a IECA ou BRA comparada a IECA ou BRA isolado em desfecho cardiovascular composto por hospitalização por insuficiência cardíaca ou morte por causas cardiovasculares. Na primeira análise, em pacientes com TFGe entre 60 e 90 mL/min/1,73 m<sup>2</sup> , a estratégia de associação de dapagliflozina resultou em taxas de eventos menores que o uso isolado de IECA ou BRA (HR 0,79; IC95% 0,66 a 0,95). A segunda análise de subgrupo restringiu-se aos participantes com TFGe abaixo de 60mL/min/1,73 m<sup>2</sup> e não identificou diferença entre as duas estratégias (HR 0,78; IC95% 0,55 a 1,09).  
**Mortalidade por todas as causas**  
Para este desfecho foi possível realizar uma meta-análise com os três estudos (Heerspink _et al._ , 2020, McMurray _et al_ ., 2019 e Wiviott _et al_ ., 2019). A associação de dapagliflozina 10 mg uma vez ao dia ao tratamento com IECA ou BRA diminuiu a taxa de mortalidade por todas as causas em relação ao uso isolado de IECA ou BRA. A magnitude dessa diminuição é, em média, 16%, com significância estatística (HR 0,84; IC95% 0,72 a 0,97; p=0,02; I<sup>2</sup> =54%) ( **Figura I** ).  
**Figura I** - Medida sumária para o desfecho mortalidade por todas as causas.  
<!-- Start of picture text -->
Dapagiozina Placebo Hazard Ratio Hazard Ratio<br>HeerspinkStudyof Subgroup 2020 _logiHazard“03711Ratio] __0.1346 SE Total__Total_Weight_1V,21522152 206% Random,— 0.69 (053,090)95% Ci IV, Random,= 95% Cl<br>WeMurrayWot 2019 2019 010726-011863 0.0 797642 05822373-23718578 42836.6 % —0.930.83 1 .82/ 0 71 , 097]1.05] #<br>Total (95% Ci) 43107 13101 100.0% — 0.8410.72,0.97) 4<br>Heterogeneity Tau*= 0.01; Chit= 4.36, df= 2(P = 0.11); P= 54% ECL + a<br>Testfor overall effect. 2= 2.35 (P= 0.02) Favours [dapagitezina] Favours [placebo]<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Taxa de filtração glomerular estimada** -->
Para este desfecho foi possível realizar uma meta-análise com os três estudos (Heerspink _et al._ , 2020, McMurray _et al_ ., 2019 e Wiviott _et al_ ., 2019). O uso de dapagliflozina 10 mg uma vez ao dia combinado ao tratamento com IECA ou BRA, quando comparado ao tratamento com IECA ou BRA isolado, em até 24 semanas, está associado a um declínio médio de 3,01 na taxa de filtração glomerular estimada, com significância estatística **(Figura J** ).  
**Figura J** - Medida sumária para o desfecho taxa de filtração glomerular estimada em 24 semanas.  
<!-- Start of picture text -->
Study Dapagiiflozina 10mg Placebo Mean Difference Mean Difference<br>FlorettoPetrykvor Subgroup2018 Mean Difference-249 1.2602SE Total160 __Total_Weight_IV,161 309% | -249Random, 4.96, 95% 0.02)Cl IV, Random, 95%Cl<br>Pollock 201 97 “245.3 1.634809184 14817 14517 2049 . 01 % |  -$.30(8.60,-21-2.404.20,-0.6 0 )} +<br>Total (95% Cl) 325323 100.0% 3.01 [-4.56, 1.46) 1<br>Heterogenely:Tostfor verad Tau®= efect.0.43; Chit= 256, df= 2 P= 0.28);P= 22% ho 40 ry 30 700<br>Zs 2.61 = 0.0081) Favours [dapagiftozina] Favours [placebo]<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Relação albumina-creatinina após 24 semanas de tratamento** -->
A relação albumina-creatinina (RAC) é um marcador de dano renal. É utilizado para identificar doença renal crônica e acompanhar sua progressão. Para este desfecho foram incluídos dois estudos (Pollock _et al_ ., 2019 e Petrykiv _et al_ ., 2017). O estudo do grupo de Fioretto _et al._ , 2018 foi excluído da análise porque a população avaliada nesse estudo não apresentava albuminuria na linha de base, enquanto nos outros dois foram incluídos participantes com albuminuria >90%). A avalição do efeito sumário calculado pela meta-análise dos dois estudos sugere que tratamento com dapagliflozina 10 mg uma vez ao dia associada a IECA ou BRA por 24 semanas diminui a RAC por uma magnitude média de 26,10% em relação à tratamento com IECA ou BRA isolado pelo mesmo período (Dif. Méd. -26,10 (IC95% -34,53 a - 17,68); p<0,00001; I<sup>2</sup> =0%) ( **Figura K** ).  
**Figura K** - Medida sumária para o desfecho relação albumina-creatinina em 24 semanas.  
<!-- Start of picture text -->
Dapagiiiozina 10mg Placebo Mean Difference Mean Difference<br>Study or Subgroup Mean Difference _SE Total Total Weight __1V, Random, 95% CI IV, Random, 95% Cl<br>Fioretto 2018 8 11.4288 160 161 0.0% — 8.001440, 30.40)<br>Petykiv 2017 297 56123 17 17. 58.6% -23.70540.70,-18.70} ad<br>Pollock 2019 “21 6.6838 145 148 41.4% 21.00 34.10, -7.90)] +<br>Total (95%Cl) 162 165 100.0% 26.10 [-34.53, 17.68] ><br>TesHeterogenei t y. Tau*= 0.00; ChiF= 0.99, df= 1 (P= 0.32); P= 0% “00-50 0 50 100<br>for overall effectZ= 6.07 (P < 0.00001) Favours [dapaglifozina] Favours [placebo]<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Segurança** -->
Os eventos adversos foram relatados em três categorias: (1) quaisquer eventos adversos sérios; (2) eventos adversos relacionados à interrupção dos tratamentos e (3) eventos adversos de interesse.  
Para a categoria qualquer evento adverso sério, a meta-análise dos três estudos mostrou que a estratégia de associação com dapagliflozina resultou em menor risco de qualquer evento adverso sério, embora com um efeito relativo de baixa magnitude (diminuição média de 9%) e o limite superior do intervalo de confiança muito próximo da não significância estatística (RR 0,91; IC95% 0,87 a 0,96; p=0,0002; I<sup>2</sup> =41%) **(Figura L** ).  
**Figura L** - Efeito relativo sumário para o desfecho quaisquer eventos adversos sérios.  
<!-- Start of picture text -->
Dapagiifiozina 10mg —_—Placebo Risk Ratio Risk Ratio<br>HeerspinkStudy or 2020 Events633 2149°729°«2143-21.2%Total_Events Total Weight IV. Random,(0.87 (0.80,95%0.95} Cl V, Random,95% Cl<br>McMurray 2019 895 2368 «994 2368 29.0%  —0.90 (0.84, 0.97)<br>Wiviott 2019 2925 8574 3100 8569 49.8% 0.94 0.91, 0.98}<br>Total (95% Cl) 13091 13086 100.0% 0.91 {0.87, 0.96) '<br>Total events 4453 4823<br>Heterogeneity: Tau* = 0.00; Ch = 3.39, df= 2 (P = 0.18), P= 41% 0.01 O1 1 10 100<br>Test for overall effect Z= 3.70 (P = 0.0002) Favours [dapagliozina] Favours [placebo]<br><!-- End of picture text -->  
Para o desfecho eventos adversos relacionados à interrupção dos tratamentos, foram incluídos os três estudos. A metaanálise demonstrou que a associação de dapagliflozina a IECA ou BRA não é diferente do uso isolado de IECA ou BRA (RR 1,06; IC 95% 0,92 a 1,24; p=0,42; I<sup>2</sup> =45%) ( **Figura M** ).  
**Figura M -** Efeito relativo sumário para o desfecho eventos adversos relacionados à descontinuação dos tratamentos.  
<!-- Start of picture text -->
Dapagiiflozina 10 mg Placebo Risk Ratio Risk Ratio<br>Study or Subgroup Events Total Events Total Weight IV, Random, 95% Cl IV, Random, 95%Cl<br>Heerspink 2020 633 2149 729-2149 21.2% 0.87 (0.80, 0.95) ba<br>McMurray 2019 895, 2368 «= 994 2368 29.0% 0.90 (0.84, 0.97]<br>Wiwiott 2019 2925 8574 3100 8569 49.8% 0.94 0.91, 0.98]<br>Total (95%Cl) 13091 13086 100.0% 0.91 [0.87, 0.96) 4<br>Total events 4453 4823<br>TestHeterogeneity: for overall effect:Tau*= Z=0.00; 3.70Chi*= (P = 0.0002)3.39, df= 2 (P= 0.18),P= 41% DoFavours [dapagliflozina]TH t Favours [placebo]10 700<br><!-- End of picture text -->  
Os eventos adversos de interesse considerados foram os seguintes: amputação; cetoacidose diabética; fratura; eventos adversos relacionados aos rins; hipoglicemia severa e; depleção de volume. Para cada um desses eventos, foi possível realizar meta-análises para sumarizar os resultados provenientes dos três estudos já apresentados.  
Para os desfechos amputação (RR 1,04; IC95% 0,84 a 1,29; p=0,70; I<sup>2</sup> =0% - qualidade baixa) ( **Figura N** ); fratura (RR 1,06; IC95% 0,94 a 1,18; p=0,34; I<sup>2</sup> =0% - qualidade baixa) ( **Figura O** ) e depleção de volume (RR 1,13; IC95% 0,96 a 1,36; p=0,12; I<sup>2</sup> =47% - qualidade baixa) ( **Figura P** ), não houve diferença de risco relativo entre as estratégias. Já para o desfecho cetoacidose diabética, a associação de dapagliflozina 10 mg uma vez ao dia a IECA ou BRA aumentou a probabilidade de cetoacidose diabética em média por duas vezes em relação a IECA ou BRA isolados (Peto OR 2,07; IC95% 1,15 a 3,74; p=0,02; I<sup>2</sup> =60% - qualidade baixa) ( **Figura Q** ). Para os desfechos eventos adversos relacionados aos rins (RR 0,73; IC95% 0,59 a 0,92; p=0,007; I<sup>2</sup> =68% - qualidade baixa) ( **Figura R** ) e hipoglicemia severa (RR 0,66; IC95% 0,50 a 0,88; p=0,005; I<sup>2</sup> =0% - qualidade moderada) ( **Figura S** ), a associação de dapagliflozina 10 mg uma vez ao dia a IECA ou BRA diminuiu o risco dos eventos comparado ao IECA ou BRA isolado.  
**Figura N** - Efeito relativo sumário para o desfecho amputação.  
<!-- Start of picture text -->
Dapaglifiozina 10mg Placebo Risk Ratio Risk Ratio<br>Study or Subgrou Events __Total_Events Total Weight<br>HeerspinkMcMurray  2020, 352149992149 221% _IV, Random,0.90087, 95%1.41]C1 IV, Random,95% CL<br>Wiviott 20192019 123857411313 2368-«12-«2385 8 98«7.4%70.5% = — ‘1.08 /1.09 ( 0. 5084 ,  21 40) . 37]<br>Total (95% Cl) 13091 13086 100.0% 1.04 (0.84, 1.29]<br>Total events 71 164<br>Hetropenaac‘est for overall Ta someffect: Z= 0.38oar: (P= Ustad0.70) 2 REO F=0% borFavours [dapagiiflozina]ny 7 Favours [placebo]10 100<br><!-- End of picture text -->  
**Figura O** - Efeito relativo sumário para o desfecho fratura.  
<!-- Start of picture text -->
Dapagiflozina 10mg Placebo Risk Ratio Risk Ratio<br>Study or Subgrou Events __Total_Events Total Weight<br>IV, Random, 95%Cl IV, Random, 95%Cl<br>Heerspink 2020 85 2149 G9 -2149-131% 1.23 0.90, 1.68)<br>MeMurray 2019 49 2368S 50 2368 84% 0,98 (0.66, 1.45]<br>Wiviott 2019 4578574440 8569 78.5% — 1,04 (0.91, 1.18]<br>Total (95% Cl) 13091 13086 100.0% 1.06 (0.94, 1.18)<br>Total events 531 559<br>TERMHeterogeneity: aetee eeeTau*= Z0.00;oO Chi#=SEO1.15, df= 2(P = 0.56);P= 0% 001Favours [dapaglifozina]ot Favours [placebo]10 100<br><!-- End of picture text -->  
**Figura P** - Efeito relativo sumário para o desfecho depleção de volume.  
<!-- Start of picture text -->
Dapaglifiozina 10mg Placebo Risk Ratio Risk Ratio<br>Study or Subgrouy Events Total _Events Total_Weight_IV, Random, 95% Cl IV, Random, 95% Cl<br>Heerspink 2020 127-2149 90-2149 26.6% — 1.41 (1.08, 1.84) =<br>McMurray 2019 178 2368-162 «2368 35.3% 1,100.90, 1.36}<br>Wiviott 2019 213-8574 —-207 8569 38.2% — 1,030.85, 1.24]<br>Total (95% Cl) 13091 13086 100.0% 1.14 (0.96, 1.36]<br>Total events 518 459<br>Heterogeneity: Tau*= 0.01; Chi#= 3.76, df= 2 (P= 0.15); F= 47% oot ot 1 10 100<br>Testfor overall effect. 2= 1.55 (P= 0.12) Favours [dapagliflozina] Favours [placebo]<br><!-- End of picture text -->  
**Figura Q** - Efeito relativo sumário para o desfecho cetoacidose diabética.  
<!-- Start of picture text -->
Study Dapaglifiozina 10mg Placebo Peto Odds Ratio Peto Odds Ratio<br>or Subgrouj Events Total _Events Total Weight Peto, Fixed, 95% Cl Peto, Fixed, 95% Cl<br>Heerspink 2020 0 2149 2 2149) 4.6% — 0.14 [0.01, 2.16}<br>McMurray 2019 3 2368 = 02371 6.8% 7.40 (0.77, 71.22]<br>Whiott 2019 a 8574 12° 8574 88.6% 2161.15, 4.05] +<br>Total (95%<br>Total eventsCl) 30 13091 4 13094 100.0% — 2.07 (1.15, 3.74] =><br>TesHeterogeneity.Chi*= 4.96, df= 2 (P= 0.08);P= 60% 0.01 01 10 100<br>orarmn etek 224 LP" = na) Favours [dapaglifozina] Favours (placebo)<br><!-- End of picture text -->  
**Figura R** - Efeito relativo sumário para o desfecho eventos adversos relacionados aos rins.  
<!-- Start of picture text -->
st or rout DapaglifiozinaEvents  10 mgTotal_EventsPlacebo Total_Weight_IV, Random,Risk Ratio 95% Cl WV, Random,Risk Ratio 95% Cl<br>Heerspink 2020 15 2149 188 2149 33.0% 0.61 (0.49, 0.77) 7.<br>McMurray 2019. 153 2368 170 2368 34.3% 0.90 (0.73, 1.11)<br>‘Wiviott 2019 125 8574 175 8569 327% 0.71 (0.57, 0.90) *<br>Total (95% Cl) 13091 13086 100.0% 0.73 (0.59, 0.92} °<br>Total events: 393 533<br>Heterogeneity. Tau*= 0.03, Chi*= 6.18, df= 2 (P= 0.05); P= 68% 001 01 10 100<br>Testor overall ofect Z= 2.70 (P= 0.007) Favours [dapagiozina] Favours (placebo)<br><!-- End of picture text -->  
**Figura S** - Efeito relativo sumário para o desfecho hipoglicemia severa.  
<!-- Start of picture text -->
Dapaglifiozina 10mg Placebo Risk Ratio Risk Ratio<br>‘Study or Subgrou Events __Total_Events Total_Weight_IV, Random,<br>95% Cl 1V, Random, 95%<br>14-4928 -2149-205% 0,500.26, 0.95) ——<br>Heerspink 2020 Cl<br>McMurray 2019 4 23684 2368 4.4% — 1,00 (0.25, 3.99]<br>Wrviott 2019 58 857483. B5BG 75.1% 0.70 (0.50, 0.98)<br>Total (95% Cl) 13091 13086 100.0% 0.66 (0.50, 0.88) ><br>Total events 76 115<br>seatHeterogeneity. ir operas atockTau*= 270.00; 276Chi#=(2 = 1.18,6.008)df= 2(P = 0.55),P= 0% 001Favours (dapagliflozina]01 Favours [placebo]10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **Perfil de evidências** -->
A **Tabela B** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos analisados. A qualidade da certeza da evidência foi considerada baixa, conforme mostrado abaixo. Os estudos de Wiviott _et al_ ., 2019, Heerspink _et al._ , 2020 e McMurray _et al_ ., 2019 foram associados a um baixo risco de viés para os principais desfechos clínicos: declínio da função renal; mortalidade por todas as causas; eventos cardiovasculares em indivíduos com doença renal e; segurança. Para o desfecho decréscimo na taxa de filtração glomerular, diagnóstico de doença renal em estágio final ou morte por causas renais, a certeza geral sobre a evidência é alta, com uma penalização por evidência indireta já que dois dos três estudos incluídos na meta-análise não incluíam exclusivamente participantes com DRC. Entretanto os resultados dos estudos sugerem que o uso de dapagliflozina é mais benéfico em indivíduos com DRC, que é o principal fator de confusão nos estudos de Wiviott _et al_ ., 2019 e McMurray _et al_ ., 2019, nos quais há uma população mista entre indivíduos diagnosticados ou não com DRC. Dessa foram a melhoria da função renal, principal fator de confusão, provavelmente diminuiria o efeito perceptível do medicamento, como se vê, por exemplo, no estudo de McMurray _et al_ ., 2019. Para o desfecho mortalidade por todas as causas considerou-se que a certeza sobre a evidência é moderada com uma penalização por evidência indireta, pelos motivos já apresentados. Para o  
desfecho decréscimo TGF, DREF ou morte por causas renais ou cardiovasculares julgou-se que a certeza sobre a evidência é baixa com penalizações por evidência indireta e inconsistência uma vez que o efeito sumário foi associado a uma heterogeneidade estatística considerável.  
Em relação aos desfechos de segurança, dois deles (quaisquer eventos adversos sérios e hipoglicemia severa) foram associados a certeza moderada com penalização por evidência indireta. Julgou-se que os outros estariam associados a baixa certeza sobre a evidência com penalizações por evidência indireta, imprecisão ou inconsistência.  
A avaliação sumarizada da certeza da evidência do uso da dapagliflozina em pacientes com DRC para todos os desfechos analisados está apresentada na **Tabela B** .  
**Tabela B** .- Avaliação da certeza da evidência do uso da dapagliflozina em pacientes com doença renal crônica.  
|**Avaliação da ce**<br>**Participantes**|**rteza**<br>**Risco**||**Evidência**|**Viés**<br>**de**|**Certeza**<br>**geral**|**Sumário de R**<br>**Taxas de even**|**esultados**<br>**tos do estudo (%)**|**Efeito**<br>**relativo**|**Efeitos ab**<br>**Risco**|**solutos potenciais**<br>**Diferença**<br>**de**|
|---|---|---|---|---|---|---|---|---|---|---|
|**(estudos)**<br>**Seguimento**|**de**<br>**viés**|**Inconsistência**|<br>**indireta**<br>**Imprecisão**|<br> <br>**publicação**|<br>**sobre**<br>**a**<br>**evidência**|<br>**Com placebo**|**Com**<br>**dapagliflozina**|<br>**(95%**<br>**CI)**|<br>**com**<br>**placebo**|<br> <br>**risco**<br>**com**<br>**dapagliflozina**|
|**Decréscimo sus**<br>26.208<br>(3 ECRs)<br>**Decréscimo TG**|**tentado d**<br>não<br>grave<br>**F, DREF**|**e 40 a 50% na tax**<br>não grave<br>**ou morte por cau**|**a de filtração glomerular; d**<br>grave<sup>a</sup><br>não grave<br>**sas renais ou cardiovascular**|**iagnóstico de doen**<br>Todos<br>os<br>potenciais<br>fatores<br>de<br>confusão<br>reduziriam<br>o<br>efeito<br>demonstrado<br>**es**|**ça renal em**<br>⨁⨁⨁⨁<br>Alta|**estágio final ou**<br>13.101<br>participantes|**morte por causas**<br>13.107<br>participantes|**renais (aval**<br>HR 0.56<br>(0.48<br>para<br>0.64)|<br>**iado com:** <br>Baixo<br>0<br>por1.000|<br>**_Hazard Ratio_) **<br>- por 1.000 (de --<br>para --)|
|||||||||HR 0.69|Baixo||
|21464<br>(2 ECRs)<br>**Mortalidade po**|não<br>grave<br>**r todas a**|grave<sup>b</sup><br>**s causas**|grave<sup>c</sup><br>não grave|nenhum|⨁⨁◯◯<br>Baixa|10.730<br>participantes|10.734<br>participantes|(0.55<br>para<br>0.85)|0<br>por<br>1.000|-- por 1.000 (de -<br>- para --)|
|||||||||HR 0.84|Baixo||
|26208<br>(3 ECRs)|não<br>grave|não grave|grave<sup>a,d</sup><br>não grave|nenhum|⨁⨁⨁◯<br>Moderada|13.101<br>participantes|13.107<br>participantes|(0.72<br>para<br>0.97)|0<br>por<br>1.000|-- por 1.000 (de -<br>- para --)|
|**Eventos advers**|**os relacio**|**nados à descontin**|**uação dos tratamentos**||||||||  
|**Avaliação da c**|**erteza**||||||**Sumário de Re**|**sultados**||||
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||**Certeza**|**Taxas de event**|**os do estudo (%)**|**Efeito**|**Efeitos ab**|**solutos potenciais**|
|**Participantes**|**Risco**||||<br>||||||<br>|
||||**Evidência**||**Viés**<br>**de**|**geral**|||**relativo**|**Risco**|**Diferença**<br>**de**|
|**(estudos)**<br>**Seguimento**|**de**<br>**viés**|**Inconsistência**|**indireta**|**Imprecisão**|**publicação**|**sobre**<br>**a**<br>**evidência**|<br>**Com placebo**|**Com**<br>**dapagliflozina**|**(95%**<br>**CI)**|**com**<br>**placebo**|**risco**<br>**com**<br>**dapagliflozina**|
|26177<br>(3 ECRs)<br>**Amputação**|não<br>grave|não grave|grave<sup>f</sup>|graveg|nenhum|⨁⨁◯◯<br>Baixa|831/13086<br>(6.4%)|922/13091<br>(7.0%)|RR 1.06<br>(0.92<br>para<br>1.24)|64<br>por<br>1.000|4 mais por 1.000<br>(de 5 menos para<br>15 mais)|
|26177<br>(3 ECRs)|não<br>grave|não grave|grave<sup>h</sup>|gravei|nenhum|⨁⨁◯◯<br>Baixa|164/13086<br>(1.3%)|171/13091<br>(1.3%)|RR 1.04<br>(0.84<br>para<br>1.29)|13<br>por<br>1.000|1 mais por 1.000<br>(de 2 menos para<br>4 mais)|
|**Cetoacidose di**|**abética**|||||||||||
|26185<br>(3 ECRs)|não<br>grave|gravej|grave<sup>k</sup>|não grave|nenhum|⨁⨁◯◯<br>Baixa|14/13094<br>(0.1%)|30/13091<br>(0.2%)|OR 2.07<br>(1.15<br>para<br>3.74)|1<br>por<br>1.000|1 mais por 1.000<br>(de 0 menos para<br>3 mais)|
|**Fratura**||||||||||||
|26177<br>(3 ECRs)|não<br>grave|não grave|grave<sup>k</sup>|graveg|nenhum|⨁⨁◯◯<br>Baixa|164/13086<br>(1.3%)|171/13091<br>(1.3%)|RR 1.04<br>(0.84<br>para|13<br>por<br>1.000|1 mais por 1.000<br>(de 2 menos para<br>4 mais)|
||||||||||1.29)|||
|**Eventos adver**|**sos relacio**|**nados aos rins**||||||||||
|26177<br>(3 ECRs)|não<br>grave|gravel|grave<sup>k</sup>|não grave|nenhum|⨁⨁◯◯<br>Baixa|533/13086<br>(4.1%)|393/13091<br>(3.0%)|RR 0.73|41<br>por<br>1.000|11 menos por<br>1.000|  
|**Avaliação da ce**|**rteza**||||||**Sumário de Re**|**sultados**||||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Participantes**|**Risco**|||||**Certeza**|**Taxas de event**|**os do estudo (%)**|**Efeito**|**Efeitos ab**|**solutos potenciais**|
|<br>**(estudos)**<br>**Seguimento**|**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés**<br>**de**<br>**publicação**|**geral**<br>**sobre**<br>**a**<br>**evidência**|**Com placebo**|**Com**<br>**dapagliflozina**|**relativo**<br>**(95%**<br>**CI)**|**Risco**<br>**com**<br>**placebo**|**Diferença**<br>**de**<br>**risco**<br>**com**<br>**dapagliflozina**|
|**Hipoglicemia se**|**vera**||||||||(0.59<br>para<br>0.92)||(de 17 menos<br>para 3 menos)|
||||||||||RR 0.66||3<br>menos<br>por|
|26177<br>(3 ECRs)|não<br>grave|não grave|grave<sup>k</sup>|não grave|nenhum|⨁⨁⨁◯<br>Moderada|115/13086<br>(0.9%)|76/13091<br>(0.6%)|(0.50<br>para<br>0.88)|9<br>por<br>1.000|1.000<br>(de 4 menos para<br>1 menos)|
|**Depleção de vol**|**ume**|||||||||||
|26177<br>(3 ECRs)|não<br>grave|não grave|grave<sup>k</sup>|gravei|nenhum|⨁⨁◯◯<br>Baixa|459/13086<br>(3.5%)|518/13091<br>(4.0%)|RR 1.14<br>(0.96<br>para<br>1.36)|35<br>por<br>1.000|5 mais por 1.000<br>(de 1 menos para<br>13 mais)|  
**Legenda: CI:** Intervalo de confiança; **HR** : _Hazard Ratio_ ; **OR** : Razão de chances; **RR** : Risco relativo.  
**Explicações:** a. Em dois dos três estudos a maioria dos participantes não era diagnosticada com doença renal crônica  
- b. A heterogeneidade estatística associada à medida sumária de efeito foi substancial (I<sup>2</sup> =74%)  
- c. Em um dos estudos a maioria dos participantes não era diagnosticada com doença renal crônica  
- d. Em dois dos três estudos a maioria dos participantes não era diagnosticada com doença renal crônica  
- e. Em dois dos três estudos a maioria dos participantes não era diagnosticada com doença renal crônica  
- f. Em dois dos três estudos a maioria dos participantes não era diagnosticada com doença renal crônica  
- g. O intervalo de confiança abrange efeitos em sentidos opostos  
- h. Em dois dos três estudos a maioria dos participantes não era diagnosticada com doença renal crônica  
- i. O intervalo de confiança abrange efeitos em sentidos opostos  
- j. Medida de heterogeneidade estatística I<sup>2</sup> = 60%  
- k. Em dois dos três estudos a maioria dos participantes não era diagnosticada com doença renal crônica e L. Heterogeneidade estatística I<sup>2</sup> = 68%

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **4. REFERÊNCIAS** -->
1. Guyatt, G., Oxman, A. D., Akl, E. A., Kunz, R., Vist, G., Brozek, J., Norris, S., Falck-Ytter, Y., Glasziou, P., DeBeer, H., Jaeschke, R., Rind, D., Meerpohl, J., Dahm, P., & Schünemann, H. J. (2011). GRADE guidelines: 1. Introduction-GRADE evidence profiles and summary of findings tables. Journal of clinical epidemiology, 64(4), 383–394. https://doi.org/10.1016/j.jclinepi.2010.04.026  
2. NICE. National Institute for Health and Care Excellence. Chronic kidney disease: assessment and management. NICE guideline [NG203] Published: 25 August 2021 Last updated: 24 November 2021.  
3. KDIGO 2012. Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease. Kidney inter., Suppl. 2013; 3: 1–150  
4. Brouwers MC, Kho ME, Browman GP, Burgers JS, Cluzeau F, Feder G, et al. AGREE II:advancing guideline development, reporting and evaluation in health care. CMAJ. 2010;182(18):E839-42  
5. Li A, Lee HY, Lin YC. The Effect of Ketoanalogues on Chronic Kidney Disease Deterioration: A Meta-Analysis. Nutrients.2019;26;11(5):957.  
6. Stang, A. Critical evaluation of theNewcastle-Ottawa scale for the assessment of the quality of nonrandomized studies in meta-analyses. Eur. J. Epidemiol. 2010, 25, 603–605.  
7. Higgins, J.P.; Altman, D.G.; Gøtzsche, P.C.; Jüni, P.; Moher, D.; Oxman, A.D.; Savovic, J.; Schulz, K.F.; Weeks, L.; Sterne, J.A. Cochrane Bias Methods Group; Cochrane Statistical Methods Group. The Cochrane Collaboration’s tool for assessing risk of bias in randomised trials. BMJ 2011, 343, d5928.  
8. Egger, M.; Davey Smith, G.; Schneider, M.; Minder, C. Bias in meta-analysis detected by a simple, graphical test. Br. Med. J. 1997, 315, 629–634.  
9. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, Moher D, Tugwell P, Welch V, Kristjansson E, Henry DA. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017;21;358:j4008.  
10. Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: A revised tool for assessing risk of bias in randomised trials. BMJ. 2019;366:1–8.  
11. Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no SUS – Conitec. Dapagliflozina para tratamento de pacientes adultos com doença renal crônica em uso de terapia padrão. Disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20220927_relatorio_773_dapagliflozina_doenca_renal_cronica_final.pdf.</u>  
12. Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no SUS – Conitec. Aminoácidos + análogos associados a dieta muito restritiva em proteínas para o tratamento de pacientes adultos com doença renal crônica em estágios 4 ou 5 pré-dialítico. Disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20221208_relatorio_aminoacidos_analogos_-drc_784.pdf.</u>  
13. NICE. National Institute for Health and Care Excellence. Technology appraisal guidance [TA775]: Dapagliflozin for treating chronic kidney disease. Published: 09 March 2022. Disponível em: https://www.nice.org.uk/guidance/ta775.

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **MATERIAL SUPLEMENTAR 1** -->
Detalhes e comentários da avaliação da qualidade da diretriz clínica _KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease._  
|**Domínio 1. Escopo e Finalidade**|**Avaliação**|
|---|---|
|1. Os objetivos gerais da diretriz encontram-se<br>especificamente descrito(s).|Esta diretriz de prática clínica destina-se a auxiliar o profissional<br>cuidador de pacientes com DRC, prevenir mortes, problemas<br>cardiovasculares, eventos da doença e progressão para a<br>insuficiência renal, otimizando a qualidade de vida dos pacientes|
|2. As questões de saúde cobertas pela diretriz<br>encontram-se especificamente descritas.|Sim.<br>Exemplo: Algoritmo para teste de proteinúria/albuminúria no<br>Capítulo 1.|
|3. A população (pacientes, público etc.) a quem a<br>diretriz se destina encontra-se especificamente<br>descrita.|Sim. Provedores: Médicos Nefrologistas (adultos e pediátricos),<br>Provedores de diálise (incluindo enfermeiras), internistas e pediatras.<br>Pacientes: Indivíduos adultos e pediátricos em risco ou com DRC.<br>Formuladores de políticas: aqueles em áreas relacionadas à saúde.|
|**Domínio 2. Envolvimento das partes interessadas**|**Avaliação**|
|4. A equipe de desenvolvimento da diretriz inclui<br>indivíduos de todos os grupos profissionais relevantes.|Sim. Consta na página 120 da diretriz clínica.|
|5. Procurou-se conhecer as opiniões e preferências da<br>população-alvo (pacientes, público etc.).|Não.|
|6. Os usuários-alvo da diretriz estão claramente<br>definidos.|Sim. Provedores: Médicos Nefrologistas (adultos e pediátricos),<br>Provedores de diálise (incluindo enfermeiras), internistas e pediatras.<br>Pacientes: Indivíduos adultos e pediátricos em risco ou com DRC.<br>Formuladores de políticas: aqueles em áreas relacionadas à saúde|
|**Domínio 3. Rigor do desenvolvimento**|**Avaliação**|
|7. Foram utilizados métodos sistemáticos para a busca<br>de evidências|Sim.  Detalhes na página 121 da diretriz e na Tabela 38 da página<br>123.|
|8.  Os critérios de seleção de evidência estão<br>claramente descritos.|Sim.  Detalhes na página 121 da diretriz.|
|9.  Os pontos fortes e limitações do conjunto de<br>evidências estão claramente descritos.|Sim.|
|10.  Os métodos para a formulação das recomendações<br>estão claramente descritos|Sim.  Detalhes na página 121 da diretriz.|
|11.  Os benefícios, efeitos colaterais e riscos à saúde<br>foram considerados na formulação das recomendações|Sim.|
|12.<br>Existe<br>uma<br>ligação<br>explícita<br>entre<br>as<br>recomendações e a respectiva evidência de suporte|Existe uma ligação explícita entre as recomendações e a respectiva<br>evidência de suporte|
|13. A diretriz foi revisada externamente por experts<br>antes da sua publicação|Não.|
|14.  O procedimento para atualização da diretriz está|Consta que não há data definida para a atualização da diretriz. A|
|disponível|necessidade de atualização da diretriz dependerá da publicação de|  
||novas evidências que mudariam a qualidade da evidência ou a<br>estimativas de benefícios e danos. Resultados de estudos em<br>andamento e outras publicações serão revisados periodicamente para<br>avaliar seu impacto nas recomendações da atual diretriz.|
|---|---|
|**Domínio 4. Clareza da apresentação**|**Avaliação**|
|15. As recomendações são específicas e sem<br>ambiguidade.|Nenhuma alteração.|
|16. As diferentes opções de abordagem da condição ou<br>problema de saúde estão claramente apresentadas|Sim.|
|17.<br>As<br>recomendações-chave<br>são<br>facilmente<br>identificadas.|Sim. Presença de caixa em destaque, informações em negrito, além<br>de fluxogramas e algoritmos.|
|**Domínio 5. Aplicabilidade**|**Avaliação**|
|18. A diretriz descreve as facilidades e barreiras para<br>sua aplicação.|Não. Falta de materiais adicionais, os quais podem incluir, por<br>exemplo, um sumário ou um guia de referência rápida, ferramentas<br>educacionais, folhetos para os pacientes, ou um suporte informático.|
|19. A diretriz traz aconselhamento e ferramentas sobre<br>como as recomendações podem ser colocadas em<br>prática|Não.|
|20. Foram consideradas as potenciais implicações<br>quanto aos recursos decorrentes da utilização das<br>recomendações.|Não.|
|21. A diretriz apresenta critérios para o seu<br>monitoramento e auditoria.|Sim|
|**Domínio 6. Independência Editorial**|**Avaliação**|
|22. O parecer do órgão financiador não exerce<br>influência sobre o conteúdo da diretriz.|Não. Detalhes nas páginas 125 e 126.|
|23. Foram registrados e abordados os conflitos de<br>interesse dos membros da equipe que desenvolveu a<br>diretriz.|Sim|  
|**AVALIAÇÃ**|**O AGREE II d**|**o KDIGO 2012**|||||||
|---|---|---|---|---|---|---|---|---|
|**Domínio 1.**|**Escopo e finalid**<br>|**ade**<br>|||||||
||**item 1**|**item 2**||**item 3**||**TOTAL**|||
|Avaliador 1|7|7||7||21|**Pont Max:**|63|
|Avaliador 2|7|7||7||21|**Pont Min:**|9|
|Avaliador 3||||||0|**% do Dom 1:**|**61%**|
|**TOTAL**|14|14||14||42|||
|**Domínio 2.**|**Envolvimento d**|**as partes interessadas**|||||||
||**item 4**|**item 5**||**item 6**||**TOTAL**|||
|Avaliador 1|7|1||7||15|**Pont Max:**|63|
|Avaliador 2|7|1||7||15|**Pont Min:**|9|
|Avaliador 3|||||||**% do Dom 2:**|**39%**|
|**TOTAL**|14|2||14||30|||
|**Domínio 3.**|**Rigor do desenv**|**olvimento**|||||||
||**item 7**<br>**item**|**8**<br>**item 9**<br>**item 10**|**item 11**|**item 12**<br>**item 13**|**item 14**|**TOTAL**|||
|Avaliador 1|7<br>7|7<br>7|7|7<br>1|7|50|**Pont Max:**|168|
|Avaliador 2|7<br>7|7<br>7|7|7<br>1|7|50|**Pont Min:**|24|
|Avaliador 3||||||0|**% do Dom 3:**|**53%**|
|**TOTAL**|14<br>14|14<br>14|14|14<br>2|14|100|||
|**Domínio 4.**|**Clareza da apre**|**sentação**|||||||
||**item 15**|**item 16**||**item 17**||**TOTAL**|||
|Avaliador 1|7|7||7||21|**Pont Max:**|84|
|Avaliador 2|7|7||7||21|**Pont Min:**|12|
|Avaliador 3|||||||**% do Dom 4:**|**42%**|
|**TOTAL**|14|14||14||42|||
|**Domínio 5.**|**Aplicabilidade**||||||||
||**item 18**|**item 19**|**item 20**|**item 21**||**TOTAL**|||
|Avaliador 1|1|1|1|7||10|**Pont Max:**|112|
|Avaliador 2|1|1|1|7||10|**Pont Min:**|16|
|Avaliador 3|||||||**% do Domínio 5:**|**4%**|
|**TOTAL**|2|2|2|14||20|||
|**Domínio 6. I**|**ndependência e**|**ditorial**|||||||
||**item 22**||**item 23**|||**TOTAL**|||
|Avaliador 1|7||7|||14|**Pont Max:**|56|
|Avaliador 2|7||7|||14|**Pont Min:**|8|
|Avaliador 3|||||||**% do Domínio 6:**|**42%**|
|**TOTAL**|14||14|||28|||  
**AVALIAÇÃO GLOBAL DA DIRETRIZ CLÍNICA 1-** Classifique a qualidade global dessa diretriz 6  
|**2**-**EU RECOMENDARIA O USO DESTA DIRETRIZ**||
|---|---|
|a. Sim|X|
|b. Sim, com modificações||
|c. Não||  
Avaliação da qualidade da diretriz clínica _Chronic kidney disease: assessment and management NICE guideline_ utilizando o instrumento AGREE II.  
|**Domínio 1. Escopo e Finalidade**|**Avaliação**|
|---|---|
|1. Os objetivos gerais da diretriz encontram-se<br>especificamente descrito(s).|Sim.  Tradução: “Esta diretriz abrange cuidados e tratamento para<br>pessoas com ou em risco de doença renal crônica (DRC). Visa prevenir<br>ou retardar a progressão, e reduzir o risco de complicações e de<br>doenças cardiovasculares. Ele também abrange o gerenciamento de<br>anemia e hiperfosfatemia associada à DRC”.<br>Disponível em: https://www.nice.org.uk/guidance/ng203|
|2. As questões de saúde cobertas pela diretriz<br>encontram-se especificamente descritas.|Sim.<br>Disponível<br>em:<br>https://www.nice.org.uk/guidance/ng203/chapter/Rationale-and-<br>impact|
|3. A população (pacientes, público etc.) a quem a<br>diretriz se destina encontra-se especificamente<br>descrita.|Sim.<br>Tradução: “Para quem é isso?<br>- Profissionais de saúde<br>- Comissários e provedores<br>- Pessoas com doença renal crônica, seus familiares e cuidadores<br>Disponível em: https://www.nice.org.uk/guidance/ng203|
|**Domínio 2. Envolvimento das partes interessadas**|**Avaliação**|
|4. A equipe de desenvolvimento da diretriz inclui|Sim.|
|indivíduos de todos os grupos profissionais|Disponível em: https://www.nice.org.uk/guidance/ng203/history|
|relevantes.||
|5. Procurou-se conhecer as opiniões e preferências|Sim.|
|da população-alvo (pacientes, público etc.).|Disponível<br>em:<br>https://www.nice.org.uk/guidance/ng203/informationforpublic|
|6. Os usuários-alvo da diretriz estão claramente|Sim.|
|definidos.|- Profissionais de saúde<br>- Comissários e provedores<br>- Pessoas com doença renal crônica, seus familiares e cuidadores<br>Disponível em: https://www.nice.org.uk/guidance/ng203|
|**Domínio 3. Rigor do desenvolvimento**|**Avaliação**|
|7. Foram utilizados métodos sistemáticos para a|Sim.|
|busca de evidências|Disponível<br>em:<br>https://www.nice.org.uk/guidance/ng203/update/NG203/documents/s<br>earch-strategies|
|8.  Os critérios de seleção de evidência estão|Sim.  Detalhes na página 121 da diretriz.|
|claramente descritos.||
|9.  Os pontos fortes e limitações do conjunto de|Sim.|
|evidências estão claramente descritos.|Disponível em:  https://www.nice.org.uk/guidance/ng203/history|  
|10.<br>Os<br>métodos<br>para<br>a<br>formulação<br>das|Sim.|
|---|---|
|recomendações estão claramente descritos||
|11. Os benefícios, efeitos colaterais e riscos à saúde|Sim.|
|foram<br>considerados<br>na<br>formulação<br>das||
|recomendações||
|12. Existe uma ligação explícita entre as<br>recomendações e a respectiva evidência de suporte|Sim. Cada recomendação está ligada a uma lista de referências<br>bibliográficas nas quais se baseia.|
|13. A diretriz foi revisada externamente por experts<br>antes da sua publicação|Sim.|
|14.  O procedimento para atualização da diretriz está|Sim.|
|disponível|Disponível<br>em:<br>https://www.nice.org.uk/guidance/ng203/chapter/Update-<br>information.|
|**Domínio 4. Clareza da apresentação**|**Avaliação**|
|15. As recomendações são específicas e sem<br>ambiguidade.|Sim.|
|16. As diferentes opções de abordagem da condição<br>ou problema de saúde estão claramente apresentadas|Sim.|
|17. As recomendações-chave são facilmente<br>identificadas.|Sim. Presença de caixa em destaque, informações em negrito, além de<br>fluxogramas e algoritmos.|
|**Domínio 5. Aplicabilidade**|**Avaliação**|
|18. A diretriz descreve as facilidades e barreiras para<br>sua aplicação.|Sim. O NICE apresenta materiais adicionais, os quais podem incluir,<br>por exemplo, um sumário ou um guia de referência rápida, ferramentas<br>educacionais, folhetos para os pacientes, ou um suporte informático.<br>Exemplo<br>disponível<br>em:<br>https://www.nice.org.uk/guidance/ng203/resources/visual-summary-<br>identifying-chronic-kidney-disease-in-adults-pdf-9206256493.|
|19. A diretriz traz aconselhamento e ferramentas<br>sobre como as recomendações podem ser colocadas<br>em prática|Sim.<br>Disponível<br>em:<br>https://www.nice.org.uk/about/what-we-do/into-<br>practice/resources-help-put-guidance-into-practice|
|20. Foram consideradas as potenciais implicações<br>quanto aos recursos decorrentes da utilização das<br>recomendações.|Sim.<br>https://www.nice.org.uk/standards-and-indicators/how-to-use-<br>quality-standards.|
|21. A diretriz apresenta critérios para o seu<br>monitoramento e auditoria.|Sim|
|**Domínio 6. Independência Editorial**|**Avaliação**|
|22. O parecer do órgão financiador não exerce<br>influência sobre o conteúdo da diretriz.|Não. https://www.nice.org.uk/guidance/ng203/history|
|23. Foram registrados e abordados os conflitos de<br>interesse dos membros da equipe que desenvolveu a<br>diretriz.|Sim. https://www.nice.org.uk/guidance/ng203/history|  
**AVALIAÇÃO AGREE II do NICE 2021**  
**Domínio 1. Escopo e finalidade**  
||**item 1**||**item 2**||**item 3**||**TOTAL**|||
|---|---|---|---|---|---|---|---|---|---|
|Avaliador 1|7||7||7||21|**Pont Max:**|63|
|Avaliador 2|7||7||7||21|**Pont Min:**|9|
|Avaliador 3|||||||0|**% do Dom 1:**|**61%**|
|**TOTAL**|14||14||14||42|||
|**Domínio 2.**|**Envolvimento das**|**parte**|**s interessadas**|||||||
||**item 4**||**item 5**||**item 6**||**TOTAL**|||
|Avaliador 1|7||7||7||21|**Pont Max:**|63|
|Avaliador 2|7||7||7||21|**Pont Min:**|9|
|Avaliador 3|||||||0|**% do Dom 1:**|**61%**|
|**TOTAL**|14||14||14||42|||
|**Domínio 3.**|**Rigor do desenvo**<br> <br>|**lvimen**<br> <br>|**to**<br> <br>||<br>|||||
||**item 7**<br>**item 8**|<br>**item**|**9**<br>**item 10**|**item 11**|**item 12**<br>**item 13**|**item 14**|**TOTAL**|||
|Avaliador 1|7<br>7|7|7|7|7<br>7|7|56|**Pont Max:**|168|
|Avaliador 2|7<br>7|7|7|7|7<br>7|7|56|**Pont Min:**|24|
|Avaliador 3|||||||0|**% do Dom 3:**|**61%**|
|**TOTAL**|14<br>14|14|14|14|14<br>14|14|112|||
|**Domínio 4.**|**Clareza da aprese**<br>|**ntaçã**|**o**<br>|||||||
||**item 15**||**item 16**||**item 17**||**TOTAL**|||
|Avaliador 1|7||7||7||21|**Pont Max:**|84|
|Avaliador 2|7||7||7||21|**Pont Min:**|12|
|Avaliador 3||||||||**% do Dom 4:**|**42%**|
|**TOTAL**|14||14||14||42|||
|**Domínio 5.**|**Aplicabilidade**|||||||||
||**item 18**|**item**|**19**|**item 20**|**item 21**||**TOTAL**|||
|Avaliador 1|7|7||7|7||28|**Pont Max:**|112|
|Avaliador 2|7|7||7|7||28|**Pont Min:**|16|
|Avaliador 3||||||||**% do Domínio 5:**|**42%**|
|**TOTAL**|14|14||14|14||56|||
|**Domínio 6. I**|**ndependência ed**|**itorial**||||||||
||**item 22**|||**item 23**|||**TOTAL**|||
|Avaliador 1|7|||7|||14|**Pont Max:**|56|
|Avaliador 2|7|||7|||14|**Pont Min:**|8|
|Avaliador 3||||||||**% do Domínio 6:**|**42%**|
|**TOTAL**|14|||14|||28|||  
|**AVALIAÇÃO GLOBAL DA DIRETRIZ CLÍNICA**||
|---|---|
|**1-**Classifique a qualidade global dessa diretriz|7|  
|**2**-**EU RECOMENDARIA O USO DESTA DIRETRIZ**||
|---|---|
|a. Sim|X|
|b. Sim, com modificações||
|c. Não||

---

<!-- METADADOS: doenca: Estratégias para Atenuar a Progressão da Doença Renal Crônica (PCDT) | secao: **MATERIAL SUPLEMENTAR 2** -->
Detalhes dos estudos incluídos na síntese de evidência no uso da dapagliflozina.  
|**Estudo**||**População**|**Braços**<br>**(intervenções**<br>**e**<br>**comparadores)**|**Desfechos**|**Resultados**|
|---|---|---|---|---|---|
|Pollock|_et_<br>_al._,|Adultos, com média de idade de 64 anos, em sua|1. Intervenção<br>1:|1. Primário<br>(somente<br>para|Foram considerados apenas os resultados|
|2019.|Estudo|maioria caucasianos ou asiáticos, de ambos os sexos|Dapagliflozina 10 mg|dapagliflozina<br>isolada):|relacionados ao grupo intervenção 1.|
|clínico de|fases 2/3,|com doença renal crônica moderada a severa, micro|uma vez ao dia por 24|Diferença média das variações||
|multicênt<br>controlad<br>randomiz|rico,<br>o<br>ado,|ou macroalbuminúria, e diagnosticados com diabetes<br>tipo 2 por mais de 12 meses.|semanas (n=145);<br>2. Intervenção<br>2:<br>Dapagliflozina|(%) na relação albumina-<br>creatinina entre a linha de base<br>e 24 semanas entre os grupos|1. Diferença média das variações (%) na relação<br>albumina- creatinina entre a linha de base e 24<br>semanas<br>entre<br>os<br>grupos<br>placebo<br>e|
|duplo-<br>Austrália|cego.<br>, Canadá,|**Critérios de inclusão:**<br>1. Relação albumina-creatinina 30–3500 mg/g;|10 mg em associação a<br>saxagliptina 2,5 mg,|dapagliflozina<br>e<br>placebo.<br>Comparação entre os grupos|dapagliflozina: Diferença  média em relação ao<br>placebo:|
|Japão, C|oréia do|2. Taxa de filtração glomerular 25–75 mL/min por|uma vez ao dia por 24|com análise de superioridade;|−21,0% (IC 95% −34,1 a −5,2; p=0,011). Limite|
|Sul,|México,|1,73 m²;|semanas (n=155);|2. Secundário:<br>Proporção<br>de|de superioridade ≤0,025 foi atingido.|
|África|do<br>Sul,|3. HbA1cde 7,0–11,0% (53–97 mmol/mol);|3. Comparador: Placebo|pacientes que atingiram uma|2. Proporção de pacientes que atingiram uma|
|Espanha,|Taiwan e|4. Em tratamento com hipoglicemiantes e anti-|por<br>24<br>semanas|redução de mais de 30% na|redução de mais de 30% na relação albumina-|
|Estados|Unidos.|hipertensivos (IECA ou BRA) por pelo menos 12|(n=148).|relação<br>albumina-creatinina|creatinina em relação à linha de base: 31,3%|
|(2019) D|ELIGHT.|semanas antes da randomização.||em relação à linha de base;|(45/144) no grupo placebo e 45,0% (63/140) no|
|NCT025|47935.|**Critérios de exclusão:**<br>1. Diagnóstico de diabetes tipo 1;<br>2. Doença renal não relacionada à diabetes;<br>3. Doença cardiovascular severa;<br>4. Histórico de dois ou mais eventos de hipoglicemia|99% dos pacientes<br>nos<br>grupos<br>dapagliflozina<br>e<br>placebo faziam uso de<br>IECA no momento do<br>estudo.|3. Exploratório: Diferença média<br>das variações (%) da excreção<br>de albumina em 24 horas entre<br>a linha de base e 24 semanas<br>entre os grupos dapagliflozina<br>e placebo;|grupo dapagliflozina (razão de chances OR 1,9<br>(IC 95% 1,1– 3,0); p=0,013).<br>3. Diferença média das variações (%) da excreção<br>de albumina em 24 horas entre a linha de base e<br>24 semanas entre os grupos dapagliflozina e<br>placebo: placebo −0,9 (IC 95% −23,0 a 27,6);|
|||dentro<br>das<br>12<br>últimas<br>semanas<br>antes<br>da<br>randomização;||4. Segurança: Diferença média<br>das variações nas taxas de|dapagliflozina −20,6 (IC 95% −38,9 a 3,2); Dif.|  
|**Estudo**|**População**|**Braços**<br>**(intervenções**<br>**e**<br>**comparadores)**|**Desfechos**|**Resultados**|
|---|---|---|---|---|
||5. Doença hepática;<br>6. Pressão sanguínea não controlada.||filtração glomerular (eGFR)<br>entre a linha de base e 24<br>semanas<br>entre<br>os<br>grupos<br>placebo e dapagliflozina;<br>5. Os desfechos relacionados à<br>glicemia<br>não<br>foram<br>considerados de interesse para<br>esta análise.|nas variações médias −19,9% (IC 95% −35,6 a<br>−0,3); p=0,047.<br>4. Diferença média das variações  nas taxas de<br>filtração glomerular (eGFR) entre a linha de<br>base e 24 semanas entre os grupos placebo e<br>dapagliflozina: –2,4 mL/min por 1,73 m² (IC<br>95% –4,2 a – 0,5); p=0,011.|
|Heerspink_et al._,|Adultos, com média de idade de 62 anos, em sua|1. Intervenção:|1. Primário composto: Tempo até|1. Tempo até um declínio de pelo menos 50% na|
|2020.<br>Estudo<br>clínico de fase 3<br>multicêntrico,|maioria caucasianos ou asiáticos, de ambos os sexos<br>com doença renal crônica, devida, principalmente, à<br>nefropatia diabética. Foram incluídos participantes|Dapagliflozina 10 mg<br>uma vez ao dia por<br>mediana de tempo de|um evento. Os eventos poderiam<br>ser os seguintes: um declínio de<br>pelo menos 50% na taxa de|taxa<br>de<br>filtração<br>glomerular<br>estimada;<br>diagnóstico de doença renal em estágio terminal<br>ou morte por causas renais ou cardiovasculares:|
|controlado<br>randomizado,<br>quadruplo-cego. 21|com e sem diagnóstico de diabetes tipo 2.<br>**Critérios de inclusão:**|2,4 anos (n=2.152);<br>2. Comparador: Placebo<br>por mediana de tempo|filtração glomerular estimada;<br>diagnóstico de doença renal em<br>estágio terminal ou morte por|ocorreram eventos em 197 participantes (9,2%)<br>que utilizaram dapagliflozina e em 312 no<br>grupo placebo (14,5%). Hazard ratio HR 0,61;|
|países.<br>(2020)<br>DAPA-CKD;|1.<br>Taxa de filtração glomerular 25–75 mL/min<br>por 1,73 m²;|de 2,4 anos (n=2.152).|causas<br>renais<br>ou<br>cardiovasculares;|IC 95% 0,51 a 0,72; P<0,001. NNT 19 (IC 95%<br>15 a 27).|
|NCT03036150.|2.<br>Evidência de albuminuria no período de pelo<br>menos 3 meses antes do início do estudo. Relação<br>albumina- creatinina 200–5000 mg/g;<br>3.<br>Em tratamento com anti- hipertensivos<br>(IECA ou BRA) por pelo menos 4 semanas antes da<br>primeira visita.<br>|67% faziam uso de BRA<br>e 31% de IECA no<br>momento do estudo.|2. Secundário composto: Tempo<br>até um evento. Os eventos<br>poderiam ser os seguintes:<br>declínio sustentado de pelo<br>menos 50% na taxa de filtração<br>glomerular<br>estimada;<br>diagnóstico de doença renal em|2. Tempo até um declínio de pelo menos 50% na<br>taxa<br>de<br>filtração<br>glomerular<br>estimada;<br>diagnóstico de doença renal em estágio terminal<br>ou morte por causas renais: HR 0,56 (IC 95%<br>0,45 a 0,68; P<0,001);|  
|**Estudo**|**População**<br>**Braços**<br>**(intervenções**<br>**comparadores)**|**e**<br>**Desfechos**|**Resultados**|
|---|---|---|---|
||**Critérios de exclusão:**<br>1. Diagnóstico de rins policísticos de origem<br>autossômica dominante ou recessiva; nefrite lúpica;<br>vasculite<br>por<br>anticorpos<br>anti-citoplasma<br>de<br>neutrófilo (ANCA);<br>2. Em tratamento com medicamentos citotóxicos,<br>imunossupressores ou imunoterápicos para doença<br>renal no período de 6 meses antes do início do<br>estudo;<br>3. Histórico de transplante de órgãos;<br>4. Histórico de tratamento prévio com inibidores<br>SGLT2 no período de 8 semanas antes do início do<br>estudo;<br>5. Diagnóstico de diabetes tipo 1;<br>6. Insuficiência cardíaca congestiva (classe IV da<br>NYHA);<br>7. Histórico de infarto do miocárdio, angina instável,<br>Derrame ou acidente isquêmico transitório.|estágio terminal ou morte por<br>causas renais;<br>3. Secundário composto: Tempo<br>até um evento. Os eventos<br>poderiam ser os seguintes:<br>hospitalização por insuficiência<br>cardíaca ou morte<br>por<br>causas cardiovasculares;<br>6. Eventos adversos sérios, eventos<br>adversos que resultaram na<br>descontinuação do tratamento e<br>eventos adversos de interesse.|3. Tempo até hospitalização por insuficiência<br>cardíaca ou morte por causas cardiovasculares:<br>HR 0,71 (IC 95% 0,55 a 0,92; p=0,009);<br>4. Qualquer<br>evento<br>adverso<br>sério:<br>Grupo<br>dapagliflozina: 633/2149 (29,5%) e grupo<br>placebo: 729/2149 (33,9%); p=0,002.<br>Eventos<br>adversos<br>que<br>resultaram<br>na<br>descontinuação do tratamento:<br>Grupo<br>dapagliflozina: 118/2149 (5,5%) e grupo<br>placebo: 123/2149 (5,7%); p=0,79.<br>Eventos adversos de interesse: amputação:<br>dapagliflozina: 35/2149 (1,6%) e placebo<br>39/2149 (1,8%); p=0,73; Cetoacidose diabética:<br>dapagliflozina: 0/2149 e placebo: 2/2149<br>(<0.1);<br>p=0,50;<br>fraturas:<br>dapagliflozina:<br>85/2149<br>(7,2%)<br>e<br>placebo<br>69/2149<br>(8,7%)p=0,22; evento adverso relacionado aos<br>rins: dapagliflozina: 155/2149 (7,2%) e placebo<br>: 188/2149 (8,7%); p=0,07; hipoglicemia<br>dapagliflozina: 14/2149 (5,9%) e placebo:<br>28/2149 (1,3%);p=0,04; depleção de volume:<br>dapagliflozina: 127/2149 (5,9%) e placebo<br>90/2149 (4,2%); p=0,01.|  
|**Estudo**||**População**|**Braços**<br>**(intervenções**<br>**e**<br>**comparadores)**|**Desfechos**|**Resultados**|
|---|---|---|---|---|---|
|Fioretto<br>2018.|_et_<br>_al._,<br>Estudo|Adultos com média de idade de 65 anos, de ambos os<br>sexos, em sua maioria caucasianos. Diagnosticados|1. Dapagliflozina<br>10<br>mg uma vez ao dia|1.<br>Desfecho<br>exploratório:<br>Diferença média das variações da|1. Diferença média das variações da relação<br>albumina:creatinina entre dapagliflozina e|
|clínico d<br>multicênt|e fase 3,<br>rico,|com diabetes tipo 2 e doença renal crônica em estágio<br>3A.|por<br>24<br>semanas<br>(n=160);|relação<br>albumina:creatinina<br>(UACR) entre a linha de base e|placebo na semana 24: Dif. Méd. 8,0% (IC 95%<br>−14,4, 36,3]; P = 0,513).|
|controlad|o||2. Comparador:|24 semanas entre os grupos||
|randomiz|ado,|**Critérios de inclusão:**|Placebo<br>por<br>24|dapagliflozina e placebo.|Resultado no subgrupo de pacientes com UACR|
|duplo-<br>Estados|cego.<br>Unidos,|1. Histórico de diabetes tipo 2 por mais de 12 meses;<br>2. Controle glicêmico  inadequado (HbA1c ≥7,0% e|semanas (n=161).||≥30 mg/g na linha de base na semana 24: Dif.<br>Méd.−14,0% (IC 95% −42,3, 28,0); P = 0,454.|
|Bulgária,<br>República<br>Itália,<br>Espanha<br>(2018)<br>NCT0241|<br>Tcheca,<br>Polônia,<br>e Suécia.<br>DERIVE;<br>3398.|≤11%);<br>3. Em tratamento estável com hipoglicemiantes;<br>4. Doença renal crônica em estágio 3A.<br>**Critérios de exclusão:**<br>1. Histórico de cetoacidose diabética ou coma<br>hiperosmolar não cetótico;<br>2. Hipertensão severa não controlada;<br>3. Histórico de infarto do miocárdio; cirurgia cardíaca<br>ou revascularização; angina instável; insuficiência<br>cardíaca; derrame ou acidente isquêmico transitório<br>ou arritmia cardíaca.<br>4. Doença renal que não nefropatia diabética ou<br>nefropatia diabética com nefroesclerose;<br>5. Doença hepática;|82 a 85% em uso de<br>IECA ou BRA.|||  
|**Estudo**|**População**<br>6. Tratamento com inibidores SGLT2; GLP-1 ou<br>insulina de ação lenta ou rápida durante a fase de<br>recrutamento.|**Braços**<br>**(intervenções**<br>**e**<br>**comparadores)**|**Desfechos**|**Resultados**|
|---|---|---|---|---|
|Petrykiv<br>_et_<br>_al_.,<br>2018.<br>Estudo<br>clínico controlado<br>randomizado,<br>duplo-cego,<br>com<br>cruzamento (_cross-_<br>_over_).<br>Holanda.<br>NTR 4439.|Adultos com média de idade de 61 anos, de ambos os<br>sexos, em sua maioria caucasianos.<br>**Critérios de inclusão:**<br>1. Relação albumina-creatinina 100–3500 mg/g;<br>2. Taxa de filtração glomerular;<br>≥45 mL/min por 1,73 m²;<br>3. HbA1cde 55–100 mmol/mol;<br>4. Em tratamento com anti- hipertensivos (IECA ou<br>BRA) por pelo menos 4 semanas antes da<br>randomização.<br>**Critérios de exclusão:**|Dapagliflozina 10 mg<br>por dia durante 6<br>semanas<br>e<br>depois<br>_cross-over_<br>para<br>placebo por 6 semanas<br>(n=17);<br>Placebo por 6 semanas<br>e depois_cross-over_<br>para dapagliflozina 10<br>mg por dia por 6<br>semanas (n=17).|1. Primário: Variação (%) na<br>excreção de albumina em 24<br>horas<br>(24h<br>UAE)<br>após<br>6<br>semanas de tratamento;<br>2. Secundário: Variação (%) na<br>relação<br>albumina-creatinina<br>após 6 semanas;<br>3. Secundário: Taxa de filtração<br>glomerular após 6 semanas.|1. Variação (%) na excreção de albumina em 24<br>horas após 6 semanas: Diminuição de 36,2%<br>em relação ao placebo (IC 95% 22,9 a 47,2;<br>P<0,001).<br>2. Variação (%) na relação albumina-creatinina:<br>Diminuição de 29,7% em relação ao placebo<br>(IC 95% - 40,7 a -16,8; P<0,001).<br>3. Taxa de filtração glomerular: Diminuição de<br>4,8 mL/min/1,73 m<sup>2</sup>(IC 95% -6,7 a -3,0) para<br>dapagliflozina e aumento de 0,9 mL/min/1,73<br>m<sup>2</sup>(IC 95% -1,5 a 3,3) para placebo; p<0,001.|  
|**Estudo**|**População**|**Braços**<br>**(intervenções**<br>**e**<br>**comparadores)**|**Desfechos**|**Resultados**|
|---|---|---|---|---|
||1. Hipertensão arterial não controlada (>180/110<br>mmHg);<br>2. Histórico de eventos cardiovasculares nos últimos 6<br>meses antes do início do estudo;<br>3. Em uso de pioglitazona, análogos do GLP-1,<br>inibidores DDP-IV e inibidores SGLT-2.||||
|Wiviott<br>_et_<br>_al._,|Adultos com média de idade de 64 anos, de ambos os|Dapagliflozina 10 mg|1. Primário: Composto definido|1. Morte por causas cardiovasculares, infarto do|
|2019.<br>Estudo<br>clínico de fase 3<br>multicêntrico,|sexos, em sua maioria caucasianos, diagnosticados<br>com diabetes tipo 2 e_clearance_de creatinina ≥60<br>mL/min. Pacientes com múltiplos fatores de risco para|uma vez ao dia por<br>mediana de 4,2 anos<br>(n=8.582);|como<br>morte<br>por<br>causas<br>cardiovasculares,<br>infarto<br>do<br>miocárdio<br>ou<br>derrame|miocárdio ou derrame isquêmico: Não foi<br>diferente de placebo HR 0,93 (IC 95% 0,84 a<br>1,07; p= 0,17);|
|controlado<br>randomizado,|doença cardiovascular aterosclerótica ou com a<br>doença já estabelecida. A taxa de filtração glomerular|Comparador: Placebo<br>por mediana de 4,2|isquêmico;<br>2. Primário: Composto definido|2. Morte<br>por<br>causas<br>cardiovasculares<br>ou<br>hospitalização<br>por<br>insuficiência<br>cardíaca:|
|quadruplo-cego. 33|de 45% dos participantes estava entre 60 e 90|anos (n=8.578).|como<br>morte<br>por<br>causas|Favorece dapagliflozina, HR 0,83 (IC 95% 0,73|
|países.<br>(2019).<br>DECLARE–TIMI|mL/min/1,73 m<sup>2</sup>.|81,3% em uso de|cardiovasculares<br>ou<br>hospitalização por insuficiência|a   0,95; p=0,005). Diminui a taxa de<br>hospitalização por insuficiência cardíaca (HR|
|58; NCT01730534.|**Critérios de exclusão:**<br>1. Diagnóstico de diabetes tipo 1;<br>2. Histórico de câncer de bexiga;<br>3. Histórico de tratamento com radiação na região do<br>abdômen ou pélvis;<br>Cistite crônica ou infecção; recorrente do trato<br>urinário.|IECA ou BRA.|cardíaca;<br>3. Secundário: Composto definido<br>como um decréscimo sustentado<br>de 40% ou maior na taxa de<br>filtração glomerular (para <60<br>mL/min/1,73 m<sup>2</sup>) ou diagnóstico<br>de doença renal em estágio final<br>ou morte por causas renais ou|0,73 (IC 95% 0,61 a 0,88), mas não diminui a<br>taxa de mortalidade (HR 0,98 IC 95% 0,82 a<br>1,17);<br>3. Decréscimo sustentado de 40% ou maior na<br>taxa de filtração glomerular (para <60<br>mL/min/1,73 m<sup>2</sup>) ou diagnóstico de doença<br>renal em estágio final ou morte por causas<br>renais<br>ou<br>cardiovasculares:<br>Favorece|
||||cardiovasculares;|dapagliflozina HR 0,76 (IC 95% 0,67 a 0,87);|  
|**Estudo**|**População**|**Braços**<br>**(intervenções**<br>**e**<br>**comparadores)**|**Desfechos**|**Resultados**|
|---|---|---|---|---|
||||4. Secundário: Composto definido<br>como um decréscimo sustentado<br>de 40% ou maior na taxa de<br>filtração glomerular (para <60<br>mL/min/1,73 m<sup>2</sup>) ou diagnóstico<br>de doença renal em estágio final<br>ou morte por causas renais;<br>5. 5.<br>Secundário:<br>Morte<br>por<br>qualquer causa.|4. Decréscimo sustentado de 40% ou maior na<br>taxa de filtração glomerular (para <60<br>mL/min/1,73 m<sup>2</sup>) ou diagnóstico de doença<br>renal em estágio final ou morte por causas<br>renais: Favorece dapagliflozina HR 0,53 (IC<br>95% 0,43 a 0,66);<br>5. Morte por qualquer causa: Sem diferença em<br>relação ao placebo HR 0,93 (IC 95% 0,82 a<br>1,04).|
|McMurray_et al._,|Adultos com média de idade de 66 anos, de ambos os|1. Dapagliflozina 10 mg|1. Primário: Composto definido|1. Piora da insuficiência cardíaca ou morte por|
|2019.<br>Estudo|sexos em sua maioria caucasianos e asiáticos,|uma vez ao dia por|como piora da insuficiência|causas cardiovasculares: favorece dapagliflozina|
|clínico de fase 3|diagnosticados<br>com<br>insuficiência<br>cardíaca|mediana de 1,5 ano|cardíaca ou morte por causas|HR 0,74 (IC 95% 0,65 a 0,85; p<0,001).|
|multicêntrico,|(classificação funcional NYHA II, III, IV) e fração de|(n=2.373);|cardiovasculares. A piora da IC|Hospitalização<br>por<br>insuficiência<br>cardíaca,|
|controlado|ejeção do ventrículo esquerdo de 40% ou menos.|2. Comparador: Placebo|foi definida como hospitalização|favorece dapagliflozina HR 0,70 (IC 95% 0,59 a|
|randomizado,||por mediana de 1,5|não planejada ou necessidade de|0,83) e  morte por causas cardiovasculares|
|quadruplo-cego. 20|**Critérios de inclusão:**|ano (n=2.371);|tratamento intravenoso para IC;|também favorece dapagliflozina HR 0,82 (IC|
|países.<br>(2019)|1. Insuficiência cardíaca sintomática por pelo menos 2|3. 56% em uso de IECA|2. Secundário: Composto definido|95% 0,69 a 0,98). NNT para prevenir um evento|
|DAPA-HF;|meses;|e 26 a 28% em uso de|como piora na função renal|foi de 21 (IC 95% 15 a 38);|
|NCT03036124|2. Níveis de NT-proBNP elevados;<br>3. Em tratamento para insuficiência cardíaca;<br>4. Taxa de filtração glomerular ≥30 mL/min/1,73 m<sup>2</sup>.|BRA.|(declínio sustentado na taxa de<br>filtração glomerular de 50% ou<br>maior); diagnóstico de doença<br>renal em estágio terminal ou|2. Piora na função renal; diagnóstico de doença<br>renal em estágio terminal ou morte por causas<br>renais: Não foi diferente de placebo HR 0,71 (IC|
||**Critérios de exclusão:**||morte por causas renais;|95% 0,44 a 1,16);|  
|**Estudo**|**População**<br>**Braços**<br>**(intervenções**<br>**comparadores)**|**e**|**Desfechos**|**Resultados**|
|---|---|---|---|---|
||1.<br>Em tratamento prévio com inibidores SGLT2 nas<br>últimas 8 semanas anteriores ao início do estudo;<br>2.<br>Diagnóstico de diabetes tipo 1;<br>3.<br>Hipotensão sintomática;<br>4.<br>Insuficiência<br>cardíaca<br>descompensada<br>ou<br>hospitalização por IC descompensada nas últimas<br>4 semanas anteriores ao recrutamento;<br>5.<br>IM, angina instável, derrame, acidente isquêmico<br>transitório nas últimas 12 semanas anteriores ao<br>recrutamento;<br>6.<br>Revascularização coronariana ou reparo ou<br>reposição de válvulas cardíacas nas últimas;<br>7.<br>12 semanas anteriores ao recrutamento;<br>8.<br>Em terapia de ressincronização cardíaca;<br>9.<br>Histórico de transplante cardíaco;<br>10. Bradicardia sintomática;<br>11. Doença renal severa, instável ou rapidamente<br>progressiva.||3. Secundário: Morte por qualquer<br>causa.|3. Morte por qualquer causa: Favorece<br>dapagliflozina HR 0,83 (IC 95% 0,71 a 0,97).|  
**APÊNDICE 2**  
HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO  
|**Número do Relatório**||**Tecnologias ava**|**liadas pela Conitec**|
|---|---|---|---|
|**das diretrizes clínicas**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||Ajuste no item “Critérios de<br>Inclusão” para detalhar os<br>critérios de utilização da<br>dapagliflozina em pacientes<br>com diabetes melito tipo 2.|-|-|
|Portaria<br>Conjunta<br>SAES-SECTICS/MS nº<br>11/2024; Relatório de<br>Recomendação<br>~~n~~<sup>o</sup><br>827/2023|Primeira<br>versão<br>do<br>Protocolo<br>Clínico<br>e<br>Diretrizes Terapêuticas -<br>Estratégias para Atenuar a<br>Progressão da Doença Renal<br>Crônica|Dapagliflozina para tratamento<br>de pacientes adultos com doença<br>renal crônica em uso de terapia<br>padrão.<br>(Relatório de Recomendação nº<br>773/2023; Portaria SCTIE/MS<br>nº 106/2022)|Aminoácidos<br>+<br>análogos<br>associados à dieta muito restritiva<br>em proteínas para o tratamento de<br>pacientes adultos com doença renal<br>crônica em estágios 4 ou 5 pré-<br>dialítico.<br>(Relatório de Recomendação nº<br>787/2022; Portaria SCTIE/MS nº<br>169/2022)|

---

