<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: Geral -->
<!-- Start of picture text -->
og<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE -->
PORTARIA Nº 840, DE 08 DE SETEMBRO DE 2014.  
Aprova as Diretrizes Diagnósticas e Terapêuticas da Leucemia Mieloide Aguda de Crianças e Adolescentes.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a da leucemia mieloide aguda de crianças e adolescentes no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que as diretrizes diagnósticas e terapêuticas são resultado de consenso técnico-científico e são formuladas dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando as sugestões dadas à Consulta Pública SAS/MS n<sup>o</sup> 12, de 13 de julho de 2014; e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC) e da Assessoria Técnica da SAS/MS, resolve:  
Art. 1º  Ficam aprovadas, na forma do Anexo, as Diretrizes Diagnósticas e Terapêuticas - Leucemia Mieloide Aguda de Crianças e Adolescentes.  
Parágrafo único. As Diretrizes de que trata este artigo, que contêm o conceito geral da leucemia mieloide aguda de crianças e adolescentes, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da leucemia mieloide aguda de crianças e adolescentes.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
FAUSTO PEREIRA DOS SANTOS

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 1- METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA -->
Considerando a heterogeneidade das entidades patológicas que se descrevem como leucemia mieloide aguda (LMA), a vasta literatura sobre esta neoplasia maligna e seu predominante caráter de pesquisa básica, translacional e clínica, nos âmbitos diagnóstico e terapêutico; os vários esquemas quimioterápicos e protocolos terapêuticos igualmente validados; e as altas complexidade e relevância do papel dos recursos humanos, materiais e de infraestrutura para o adequado atendimento dos doentes e a obtenção de bons resultados terapêuticos, aqui se apresentam diretrizes com o objetivo basicamente orientador e baseadas na experiência de grandes serviços nacionais e internacionais e em bibliografia selecionada.  
Assim, uma busca ampla da literatura foi realizada, e o caráter de restrição à inclusão dos artigos utilizados baseou-se na experiência dos autores.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 2- INTRODUÇÃO -->
A leucemia mieloide aguda (LMA) consiste de um grupo heterogêneo de neoplasias malignas relacionado com as células hematopoéticas, representando um dos tipos mais comuns da leucemia em adultos. A incidência da LMA aumenta significativamente com o progredir da idade. Em crianças menores de 15 anos de idade, ela representa 15%-20% dos diagnósticos das leucemias agudas. Na pediatria, a incidência anual é de 0,7 caso novo por 100.000 crianças abaixo de 18 anos de idade. Há um pequeno pico durante os dois primeiros anos de vida e um acréscimo após os 13 anos de idade. A LMA é caracterizada por uma transformação clonal das células precursoras hematopoéticas, mediante processo de múltiplas etapas, por meio da aquisição de rearranjos cromossômicos ou diferentes mutações genéticas, acrescida de diminuição da velocidade de autodestruição e parada na diferenciação celular. Mais de vinte diferentes anomalias cromossômicas foram identificadas na LMA _de novo_ , em alta porcentagem de crianças (70%-85%). A medula óssea e o sangue periférico são principalmente caracterizados por leucocitose com predomínio de células imaturas, mormente os blastos. Assim que as células imaturas se acumulam na medula óssea, elas substituem as células hematopoéticas normais, resultando numa insuficiência funcional da medula óssea e, consequentemente, sangramento, anemia e infecção (1-129).  
A LMA também pode ser causada por exposição à radiação ionizante e substâncias que danificam o DNA, mas é incomum nos pacientes adultos e crianças, uma clara história de contato com carcinógenos conhecidos (29,39,67,86,121).  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para melhor resultado terapêutico e prognóstico dos casos.  
3- CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- C92.0 Leucemia mieloide aguda - Exclui: exacerbação aguda de leucemia mieloide crônica (C92.1)  
- C92.3 Sarcoma mieloide (Cloroma, Sarcoma granulocítico)  
- C92.4 Leucemia promielocítica aguda  
- C92.5 Leucemia mielomonocítica aguda - C92.7 Outras leucemias mieloides - C93.0 Leucemia monocítica aguda - Exclui: exacerbação aguda de leucemia monocítica  
- crônica (C93.1) - C93.7 Outras leucemias monocíticas  
- C94.0 Eritremia e eritroleucemia agudas (Doença de Di Guglielmo)  
- C94.2 Leucemia megacarioblástica aguda - megacarioblástica (aguda),  megacariocítica  
- (aguda) - C94.3 Leucemia de mastócitos  
- 4- CLASSIFICAÇÃO CITOPATOLÓGICA E CITOGENÉTICA  
A LMA é classificada com base na morfologia de acordo com a Classificação FAB (FrancoAmericano-Britânica), nos subtipos FAB-M0 – FAB-M7. A citoquímica, imunofenotipagem e, especialmente, métodos citogenéticos e de genética molecular são importantes para se estabelecer um diagnóstico correto (121).  
As tabelas 1 e 2 resumem, respectivamente, a classificação pela Organização Mundial da Saúde e a classificação citogenética utilizada por grupos de estudos internacionais.  
TABELA 1 - Classificação OMS da LMA modificada a partir de 2008 (121)  
LMA com anormalidades genéticas recorrentes  
- LMA com t(8;21)(q22;q22); AML 1/ETO  
- LMA com inv(16)(p13;q22) ou t(16;16)(p13;q22); CBFbeta/MYH11  
- Leucemia promielocítica aguda com t(15;17)(q22;q12); PML/RARalfa (FAB-tipo: M3 e M3v) - LMA com anomalia 11q23; rearranjos MLL/XX  
- LMA com displasia de multilinhagens  
- LMA sem mielodisplasia (MDS) anterior  
- LMA após MDS  
- LMA e MDS associada à terapia  
- LMA após terapia com alquilantes  
- LMA após terapia com inibidores da topoisomerase  
- Outros tipos  
LMA não classificável nos grupos acima  
- LMA com mínima diferenciação (FAB M0)  
- LMA sem maturação (FAB M1)  
- LMA com maturação (FAB M2)  
- Leucemia mielomonocítica aguda (LMMoA) (FAB M4)  
- LMMoA com eosinofilia anormal (FAB M4Eo)  
- Leucemia monoblástica aguda (FAM M5a)  
- Leucemia monocítica aguda (FAB M5b)  
- Leucemia eritroide aguda (FAB M6)  
- Leucemia megacarioblástica aguda (FAB M7)  
- Leucemia basofílica aguda (FAB M2 Baso)  
- Panmielose aguda com mielofibrose  
Sarcoma mieloide Proliferações mieloides relacionadas com Síndrome de Down Neoplasia de células dentríticas blástica plasmocitoide  
TABELA 2 - Classificação Citogenética <u>(12)</u>  
|PARÂMETRO|GERMAN AMLCG|SWOG/ECOG|CALGB|
|---|---|---|---|
|Favorável|t(15;17),<br>t(8;21),<br>inv(16)t(16;16)|t(15;17),<br>t(8;21) (faltando)<br>del(9q),<br>cariótipos<br>complexos (ie, 3 ou<br>mais anl não relac.)|t(15;17),<br>t(8;21),<br>inv(16)t(16;16),<br>inv(16)t(16;16)/del(16q),|
|Intermediário|cariótipo normal,<br>outro não<br>complexo|cariótipo normal,<br>+ 6, +8, -Y, del(12p)|cariótipo normal<br>outro não complexo|
|Desfavorável ou<br>adverso|inv(3)/t(3;3),<br>-5/del(5q),<br>-7/del(7q),<br>anl(11q23),<br>del(12p),<br>anl(17p),<br>cariótipos<br>complexos (3 ou<br>mais anl não relac.)|anl(3q), (9q), (11q),<br>(21q), anl(17p),<br>-5/del(5q),<br>-7/del(7q),<br>t(6;9),<br>t(9;22),<br>cariótipos<br>complexos (3 ou<br>mais anl não relac.)|inv(3)/t(3;3),<br>-7,<br>t(6;9),<br>t(6;11),<br>t(11;19),<br>+8,<br>cariótipos complexos (3<br>ou mais anl não relac.)<br>(excl. aqueles com<br>alterações favoráveis)|  
AMLCG: Acute Myeloid Leukemia Cooperative Group; SWOG: Southwest Oncology Group; ECOG: Eastern Cooperative Oncology Group; CALGB: Cancer and Leukemia Group B; não relac.: não relacionado; anl: anormalidades.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 5- CRITÉRIOS DE INCLUSÃO -->
- Doentes com até 19 incompletos; e  
- observância dos critérios mínimos para o diagnóstico de LMA.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 6 - CRITÉRIOS DE EXCLUSÃO -->
Para os doentes com 19 anos ou mais anos dever-se-ão observar as Diretrizes Diagnósticas e Terapêuticas da Leucemia Mieloide Aguda do Adulto.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 7- AVALIAÇÃO E CLASSIFICAÇÃO PROGNÓSTICA -->
O prognóstico dos pacientes com LMA é atualmente baseado na presença ou ausência de anormalidades citogenéticas e moleculares. O Sistema Europeu de Prognóstico Leukemia Net (ELN) categoriza os pacientes em um dos quatro grupos de risco, com relação ao risco de recaída, sobrevida livre de doença e sobrevida global: favorável, intermediário-1, intermediário-2 e adverso (Tabela 3). LMA com t(8;21)(q22;q22) [RUNX1-RUNX1T1], t(15;17) [PML-RARalfa], e inv(16)(p13;q22)(p13.1;q22) [CBFB-MYH11], comumente referido como fator central de ligação (CBF)-LMA, corresponde aproximadamente a 15% das LMA e cursa com um prognóstico relativamente favorável, em termos de remissão a longo prazo. Mutações no DNMT3A, TET2, e ASXL1 estão emergindo como importantes fatores de prognóstico adverso, em subgrupos de pacientes com LMA, independentes das mutações FLT3. Mutações nas vias metabólicas dos genes IDH1 e IDH2 foram identificadas em 25%-30% dos pacientes com LMA citogeneticamente normal. As mutações na posição R140 estão associadas com melhor sobrevida no subgrupo de FLT3-ITD  
não mutante, mas mutações na posição R172 conferem resultados significativamente inferiores, ilustrando a importância de mutações concomitantes e da posição de mutação em determinar o impacto prognóstico do gene mutante. Cariótipos favoráveis ocorrem em maior porcentagem nas crianças do que nos adultos, e as incidências como também as taxas de sobrevida diminuem com o avançar da idade nos adultos, indicando que a idade tem grande impacto sobre o resultado dos grupos citogenéticos definidos. (2,12,19,20,23,32,42,57,79,98,100). Portanto, os relatos com dados citogenéticos de adultos não são diretamente aplicáveis às crianças (5,12,19,42,57,74). TABELA 3 – Sistema Europeu de Prognóstico _Leukemia Net_ <u>(ELN) (98)</u>  
|GRUPO GENÉTICO|SUBGRUPOS|
|---|---|
|Favorável|t(8;21)(q22q22); RUNX1-RUNX1T1<br>inv(16)(p13;1q22) ou t(16;16)(p13.1;q22) CBFB-MYH11,<br>mutação NPM1 sem FLT3-ITD (cariótipo normal),<br>mutação CEBPA(cariótipo normal)|
|Intermediário-1 (*)|mutação NPM1 e FLT3-ITD (cariótipo normal)<br>wild-type NPM1 e FLT3-ITD (cariótipo normal)<br>wild-type NPM1 sem FLT3-ITD(cariótipo normal)|
|Intermediário-2|t(9;11)(p22q23); MLLT3-MLL<br>anorm. citogenéticas outras que não favorável ou adversa<br>(**)|
|Adverso|Inv(3)(q21q26.2) ou t(3;3)(q21;q26.2); RPN1-EV11,<br>t(6;9)(p23;q34); DEK-NUP214;<br>t(v;11)(v;q23); rearranjo MLL;<br>-5 ou del(5q);-7;anl(17p);cariótipo complexo(***)|  
(*) Inclui todas as leucemias mieloides agudas com cariótipo normal, exceto aquelas incluídas no subgrupo favorável; a maioria dos casos está associada com pobre prognóstico, mas eles devem ser relatados separadamente em virtude da potencial resposta diferente ao tratamento.  
(**) Para a maioria das anormalidades, números adequados não foram estudados para tirar conclusões com relação ao seu significado prognóstico.  
(***) Três ou mais anormalidades cromossômicas na ausência de uma das translocações recorrentes ou inversões designadas pela OMS, isto é, t(15;17), t(8;21), inv(16) ou t(16;16), t(9;11), t(v;11)(v;q23), t(6;9), inv(3) ou t(3;3); indicam quantos casos de cariótipos complexos têm envolvimento dos braços dos cromossomas 5q, 7q e 17p.  
Um dos primeiros genes identificados como sendo comumente mutante na LMA foi o receptor-3 da tirosinoquinase (FLT3, localizado no cromossoma 13q12) fms-like. Na análise multivariada, a presença da mutação da duplicação tandem interna do FLT3 (FLT3-ITD) e alta expressão do BAALC ( _Brain and Acute Leukemia, Cytoplasmic_ ) foram genes identificados como fatores independentes do prognóstico, associadas com inferior sobrevida livre de eventos nos pacientes de LMA. Uma análise recente do estado mutante dos genes FLT3 e NPM1 ao diagnóstico mostrou ser importante para a correta estratificação do prognóstico de pacientes pediátricos com LMA, e a análise do nível da expressão gênica pelo menos do BAALC pode adicionar informação importante no prognóstico (75,77).  
Adicionalmente a citogenética favorável, a resposta precoce à terapia de indução (menos de 15% de blastos na medula óssea, no dia 15), está associada com um prognóstico favorável. Como resultado da intensa colaboração da pesquisa clínica sobre o câncer pediátrico por grupos cooperativos no mundo inteiro, a taxa de cura na LMA da criança melhorou consideravelmente nas últimas três décadas. Atualmente, 90% de todos os pacientes na idade pediátrica alcançam a  
remissão completa, e aproximadamente 60%-70% se tornam sobreviventes a longo prazo. Resultados significativamente inferiores ainda são observados nos pacientes adultos.  
Recente avaliação das recomendações do ELN, em um coorte independente com 954 pacientes adultos com LMA _de novo_ , não encontrou diferenças na evolução para os subgrupos intermediário-1 versus intermediário-2. Assim, o sistema ELN foi revisado e os subgrupos foram sugeridos como: favorável (leucemia CBF, ou citogenéticas intermediárias com mutação NPM1 ou mutação CEBPA bialélica), intermediário-I (citogenéticas intermediárias), intermediário-II (citogenéticas intermediárias e pelo menos um dos seguintes: MLL-PTD, mutação RUNX1, FLT3IT/wt razão igual ou maior que 0,5) e adverso (citogenéticas adversas).  
Estudo colaborativo internacional identificou, recentemente, uma assinatura genética comum composta de 24 genes, como fator prognóstico independente da sobrevida nos pacientes com LMA. Os autores mostraram que esta classificação de risco integrada, incorporando esta assinatura gênica, poderia melhorar substancialmente a amplamente aceita classificação de risco ELN da LMA, provendo um melhor panorama para a estratificação de risco e prognóstico para os pacientes com LMA (4,62,78).

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 8- TRATAMENTO E MONITORIZAÇÃO TERAPÊUTICA -->
O tratamento da LMA tem duas fases – indução e consolidação, que poderá incluir o transplante de células-tronco hematopoéticas (TCTH). O objetivo da indução é alcançar a remissão completa (RC), definida como menos de 5% de blastos na medula óssea normocelular, ausência de leucemia extramedular, contagem de neutrófilos acima de 1.000/mm3, e contagem de plaquetas acima de 100.000/mm3. A consolidação visa a eliminar as células leucêmicas residuais que persistem após a indução.  
Os medicamentos usados no tratamento da LMA mudaram pouco, mas o aperfeiçoamento da sua administração e notáveis avanços na terapia de suporte permitiram a otimização da administração da terapia intensiva, com menores morbidade e mortalidade. Deste modo, a melhora é devida principalmente ao contínuo progresso na compreensão da biologia da doença, na identificação de fatores prognósticos associados com sua evolução e a alocação dos pacientes em esquemas de tratamento de intensidade apropriada.  
Uma melhor terapia de resgate pós-recaída e o concomitante desenvolvimento de novos agentes alvo-moleculares, para uso em combinação com outros quimioterápicos antineoplásicos, também têm contribuído para a melhoria na sobrevida global dos doentes. O tratamento da LMA em crianças consiste numa terapia de indução, que é baseada em esquema com antraciclina, citarabina e etoposido, seguido por alguns cursos de quimioterapia de consolidação. As possibilidades para a consolidação são também o TCTH, alogênico (alo-TCTH) ou autólogo (autoTCTH), este mais conhecido como quimioterapia de alta dose com resgate autólogo de célulastronco hematopoéticas.  
As indicações de TCTH devem observar os critérios do Regulamento Técnico do Sistema Nacional de Transplantes.  
Os esquemas de tratamento diferem em muitos aspectos, incluindo as doses cumulativas dos medicamentos, a escolha das antraciclinas (ou também antracenedionas), o número e a intensidade dos blocos de tratamento e a quimioterapia intratecal utilizada na terapia preventiva do acometimento do sistema nervoso central (SNC). Apesar das várias estratégias, os resultados têm se tornado relativamente semelhantes. Aqueles relatados do recente estudo LMA02 mostraram que uma sobrevida de 90% pode ser alcançada pelas crianças com LMA de baixo risco, definido por características genéticas, que se aproximam com a evolução dos doentes de leucemia linfoide aguda de baixo risco.  
A maioria dos estudos clínicos de grupos pediátricos utiliza a quimioterapia intratecal na prevenção da leucemia no SNC, empregando um ou três medicamentos e em várias doses. No entanto, nem todos os grupos pediátricos utilizam esta terapia intratecal em suas condutas rotineiras. No estudo do _Children´s Oncology Group_ , foi mostrado que não houve diferença na sobrevida global dos doentes de LMA com acometimento do SNC ao diagnóstico, em comparação com aqueles sem esse acometimento, mas eles receberam a radioterapia no SNC, pois apresentavam maior risco de recaída isolada no SNC, indicando uma necessidade de se investigar uma terapia mais agressiva dirigida ao SNC para esses pacientes (1,4,6,7,9,30,39-41,44,49,51).  
A terapia de manutenção já não é mais usada no tratamento da LMA de pacientes na faixa etária pediátrica, por ter falhado na demonstração dos benefícios, exceto nos estudos BFM. Em um estudo piloto do _Children´s Oncology Group_ (AAML03P1), o gentuzumabe ozogamicina, um agente anticorpo-alvo humanizado anti-CD33, em combinação com a quimioterapia intensiva durante a indução da remissão e intensificação pós-remissão, se mostrou viável e seguro em crianças com LMA _de novo_ com taxas de sobrevida comparáveis aos resultados recentemente publicados de estudos clínicos. Este medicamento, no entanto, foi retirado do mercado em junho de 2010 por causa de um estudo clínico realizado em pacientes adultos pelo _Southwest Oncology Group_ (SWOG S0106)(19), que demonstrou que o medicamento aumentou o óbito dos pacientes e nenhum benefício pôde ser alcançado em relação às terapias convencionais do câncer (1,6,16,18,21,35,58,66,80,90,93,102-104,120,124).  
Terapia dos pacientes pediátricos com LMA do subtipo promielocítico (LPMA)  
A leucemia promielocítica aguda (LPMA) é uma forma rara da LMA, representando apenas 5%-8% da LMA pediátrica. De acordo com a classificação FAB, a LPMA é chamada de M3 ou M3V (variante). Citogeneticamente, a LPMA é caracterizada pela aberração cromossômica específica t(15;17), que resulta na fusão entre o gene da leucemia promielocítica (PML, sigla em Inglês) no cromossoma 15 e o gene do receptor-alfa ácido retinoico (RAR-alfa) no cromossoma 17, resultando na proteína de fusão PML RAR-alfa. O gene de fusão leva a um bloqueio na diferenciação, com acúmulo de células granulocíticas em fase promielocítica na medula óssea e no sangue periférico. A desintegração destas células com a liberação de proteínas pró-coagulantes causa uma coagulopatia grave, e há risco de vida com a coagulação intravascular disseminada, bem como o risco de fibrinólise primária. Comparando com os outros tipos de LMA, na LPMA a leucopenia é significativamente mais comum, a hepatoesplenomegalia é menos comum e é raro o acometimento do sistema nervoso central pela leucemia. Nas duas últimas décadas, esta doença, antes rapidamente fatal, foi transformada na leucemia aguda mais curável. Comparativamente aos adultos, a LPMA em crianças é caracterizada por maior incidência de hiperleucocitose, maior incidência da morfologia microgranular com múltiplos bastões de Auer e pela ocorrência mais frequente das isoformas PML RAR-alfa bcr2 e bcr3 (27,117,130,131).  
A LPMA é rara em lactentes e pacientes pediátricos, de modo que os protocolos de tratamento são baseados principalmente na experiência com a LMA do adulto. A presença da proteína de fusão PML RAR-alfa fundamenta o uso do ácido transretinoico (ATRA), que ultrapassa o bloqueio de diferenciação, evitando, assim, a destruição das células e resultando em maior diferenciação das células leucêmicas em granulócitos maduros e, adicionalmente, numa rápida resolução da coagulopatia com risco de vida. O padrão atual do tratamento, tanto para adultos como crianças com LPMA, é considerado ser a indução concomitante com ATRA e quimioterapia baseada em antraciclinas (p. ex., idarrubicina/mitoxantrona ou danorrubicina). Isto é então seguido por 2 ou 3 ciclos de terapia de consolidação, baseados em antraciclinas.  
Enquanto que a maioria dos grupos não faz uso da terapia de manutenção para os outros tipos de LMA, esta manutenção com ATRA, associada ou não à quimioterapia de baixa dose (p. ex., 6-mercaptopurina e metotrexato) foi estabelecida como terapia padrão na LPMA. Esta conduta terapêutica resultou na primeira remissão completa (RC1) em mais de 90% dos casos e sobrevida livre de doença em 5 anos de aproximadamente 80%. No entanto, os sintomas de pseudotumor cerebral e outros sintomas relacionados ao ATRA (síndrome do ATRA) são mais frequentemente observados em crianças do que em adultos, e a alta dose cumulativa das antraciclinas pode resultar no aumento da cardiotoxicidade tardia em crianças. Para reduzir estes riscos com sucesso, alguns grupos usaram dose reduzida do ATRA (p. ex. 25mg/m2 ao invés de 45 mg/m2).  
Recentemente, o grupo de estudos da LMA-BFM recomendou quimioterapia baseada na combinação antraciclina-citarabina para o tratamento da LPMA pediátrica, com dose cumulativa reduzida de antraciclina (350 mg/m2) combinada com o ATRA para reduzir sequelas a longo prazo, tal como a cardiotoxicidade. Os dados atuais sugerem que a adição de alta dose de citarabina a daunorrubicina, em pacientes de alto risco, pode resultar numa tendência para melhor sobrevida (132-142).  
Ao diagnóstico, a contagem dos glóbulos brancos (GB) do sangue periférico foi identificada como o fator prognóstico mais importante do resultado terapêutico. O risco de recidiva permanece maior em crianças que inicialmente têm contagens altas dos GB (superiores a 5.000/mm3 ou 10.000/mm3) e pacientes com doença residual, no final dos cursos de consolidação. Nesses casos, a adição do trióxido de arsênio (ATO) na consolidação da indução e terapia de consolidação recentemente mostrou melhora estatística significativa na sobrevida livre de eventos e sobrevida livre de doença em crianças com LPMA. O ATO também mostrou atividade promissora no tratamento de primeira linha, como alternativa para a quimioterapia baseada na combinação do ATRA e antraciclinas. O ATO induz remissão completa sem imunossupressão e causa menos efeitos adversos. Recentemente, as indicações para a terapia com ATO têm sido feitas para o resgate de pacientes de LPMA recidivados após o tratamento de primeira linha. (143151), porém essa indicação não se inclui em bula e nem tem registro para uso pediátrico.  
O uso do ATRA fez da LPMA a leucemia mieloide aguda mais curável e, mesmo após uma recaída, a doença ainda é curável. No entanto, o ATO continua alvo de vários protocolos de pesquisa, inexistindo, até o momento, evidência da superioridade do ATO, comparado com a combinação do ATRA com antraciclina, na primeira indução de remissão, bem como na associação com citarabina e antraciclina na recaída que envolve o SNC. Em razão da sua atividade antileucêmica nos pacientes recidivados e do perfil de toxicidade relativamente favorável, o ATO pode ser uma opção de tratamento para os pacientes com recidiva da LPMA, porém, repete-se, essa indicação não se inclui em bula e nem tem registro para uso pediátrico. Dados recentes de um pequeno grupo de pacientes demonstrou que o ATO oral, particularmente na manutenção prolongada com o ATRA oral, pode evitar a necessidade do transplante de células-tronco na recaída da LPMA pediátrica. Outras condutas pesquisadas incluem os esquemas de quimioterapia (alta dose) utilizados no tratamento da LMA recidivada, usualmente combinado com ATRA, ATRA lipossomal ou retinoides sintéticos, transplante autólogo ou alogênico de células-tronco hematopoéticas e anticorpos monoclonais direcionados contra o CD33, como o gemtuzumabe ozogamicina (136,149,152-155).  
O transplante de células-tronco hematopoéticas, autólogo ou alogênico, é terapia eficaz no tratamento de crianças com LPMA recidivada ou refratária. O auto-TCTH está associado com baixa mortalidade relacionada ao tratamento, enquanto que o alo-TCTH está associado com baixa incidência de recaída, sugerindo um forte efeito enxerto-versus-leucemia contra a LPMA residual.  
Embora a maioria dos pacientes com LPMA tenha a doença _de no_ vo, um número aumentado de casos tem sido associado à exposição prévia à quimioterapia, em particular aos inibidores da topoisomerase II (tais como mitoxantrona, etoposido, doxorrubicina e epirrubicina) e outras classes de agentes citotóxicos (tais como agentes alquilantes e análogos dos nucleosídeos), bem como a radioterapia. O Grupo Europeu APL estima que 22% de todas as LPMA estejam relacionadas à terapia. A LPMA relacionada à terapia é sensível à terapia padrão, com nenhum caso visto de resistência ou recaída. A seleção com esquemas com menos quimioterapia pode ser uma maneira possível para melhorar os resultados para essa população crescente de pacientes (156-160).  
Transplante de células progenitoras hematopoéticas no tratamento da LMA da criança e do adolescente  
Desde 1985, o alo-TCTH de doador irmão compatível tem sido amplamente recomendado para os pacientes com LMA recentemente diagnosticada, após a quimioterapia de indução. Isso resultou em um risco de recaída significativamente menor do que com a quimioterapia somente, como terapia de consolidação. No entanto, menos recaídas são frequentemente contrabalanceadas com a maior mortalidade relacionada ao tratamento e mais toxicidade aguda e a longo prazo causadas pelo alo-TCTH. Além disso, os doadores irmãos compatíveis estão disponíveis em cerca de um entre cada quatro pacientes, e a taxa de salvamento para a recaída após alo-TCTH em primeira remissão (RC1) é muitas vezes menor do que se a criança tivesse sido tratada somente com a quimioterapia.  
Com base em uma revisão recente de vários estudos clínicos de fase III, o alo-TCTH não é mais recomendado para pacientes pediátricos com LMA recém-diagnosticada, e não é clara a eficácia nos pacientes de alto risco. O TCTH ainda é utilizado, no entanto, por alguns grupos, para os pacientes de risco padrão. Devido aos efeitos colaterais agudos e tardios mais graves, quando comparado com a quimioterapia, o alo-TCTH em RC1 para LMA pediátrica, em geral, não é recomendado. Subgrupos genéticos, no entanto, podem se beneficiar do alo-TCTH (21,30). O aloTCTH com condicionamento de intensidade reduzida tem mostrado diminuir a toxicidade relacionada ao transplante e emergiu como uma opção atrativa de tratamento para os pacientes de alto risco. O papel da consolidação com altas doses de quimioterapia com auto-TCTH ainda é controverso (7,24,29,36,85,88,98,105,122).  A duração da primeira remissão (RC1) tem um significante impacto na terapia de salvamento para os pacientes recidivados. Pacientes com uma duração da RC1 maior que 12 meses são mais propensos de alcançarem uma resposta à quimioterapia de resgate com base em altas doses de citarabina, enquanto que uma RC1 com duração menor que 6 meses está associada com uma probabilidade inferior a 20% de alcançar uma segunda remissão completa.  
A evolução das crianças com LMA se tornou promissora durante os últimos anos, e a relativamente alta taxa de mortalidade relacionada ao tratamento e as taxas de recaída, puderam ser nitidamente reduzidas. No entanto, as taxas de resposta e a sobrevida global ainda são inferiores às da leucemia linfoblástica aguda (LLA), e o prognóstico para os pacientes com leucemia refratária e para aqueles com primeira remissão curta, ainda é quase invariavelmente sombrio. Os pacientes com mutação ITD ( _internal tandem duplication_ ) do gene receptor 3 da tirosinoquinase (FLT3), subtipo M6 ou M7 FAB, LMA relacionada à síndrome mielodisplásica (MDS, sigla em Inglês), cariótipo com monossomia 7, ou doença persistente após 2 cursos de quimioterapia de indução convencional alcançam um resultado particularmente pobre.  
Terapia dos pacientes pediátricos com LMA recidivada/refratária  
O papel do alo-TCTH na LMA recidivada/refratária está bem estabelecido e foi recentemente confirmado como mandatório para a cura. A quimioterapia de reindução pode produzir uma segunda remissão completa (RC2), usualmente de curta duração, em 30%-60% dos pacientes recidivados. Como a maioria dos protocolos de LMA de primeira linha apresenta doses cumulativas elevadas de antraciclinas ou antracenedionas, os esquemas de tratamento para as doenças recorrentes devem limitar ou evitar o uso desta classe de agentes, particularmente se o tratamento de resgate incluir o alo-TCTH (31,69,81,97). Os pacientes com menor risco de recaída podem se beneficiar do tratamento de escalonamento, poupando-se dos efeitos colaterais adversos. O uso da irradiação craniana profilática do SNC e do tratamento de manutenção parece não ser indicado em geral e, portanto, a irradiação foi quase completamente abandonada (3,9,15,16,46,60,70,80,83,101,106,129).  
Um número de agentes quimioterápicos utilizados com menor frequência mostrou atividade na LMA recidivada, incluindo a amsacrina, mitoxantrona, fludarabina, clofarabina, cladribina, troxacitabina, cloretazina, hemoharringtonina, diaziquona, idarrubicina, topotecano e etoposido, sendo que alguns desses agentes já são componentes combinados dos esquemas atuais. Terapiasalvo que são baseadas na exploração de eventos fisiopatológicos críticos para a leucemogênese também estão sob investigação. Tais terapias incluem inibidores da via _ras_ e ativadores da tirosinoquinase, tais como a farnesiltransferase (p. ex. tipifarnibe) e FLT3 (p. ex. sorafenibe, leustaurtinibe e quizartinibe), inibidores da deacetilase-histona (p. ex. vorinostat) e inibidores de agentes DNA-hipometiladores (p. ex. decitabina, azacitidina), que promovem a transcrição de genes silenciados, inibidores da angiogênese (p. ex. bevacizumabe) e agentes anti-bcl-2, respectivamente. Os primeiros resultados com sorafenibe foram promissores em estudos realizados em adultos, mostrando posteriormente remissão prolongada também em pacientes pediátricos com LMA recidivada. É provável que a ótima aplicação destes agentes envolverá a combinação de inibidores e a quimioterapia, potencialmente com um alvo inibidor da rifampicina (m-TOR), tais como o everolimo ou temsirolimo. O gemtuzumabe ozogamicina (GO) é um novo anticorpo monoclonal anti-CD33 vinculado ao antibiótico antitumoral enedina, a caliqueamicina. De acordo com os dados do estudo de fase II de recaída da LMA 2001/02, o agente único gemtuzumabe ozogamicina serviu como tratamento de resgate favorável, para crianças com LMA refratária em primeira ou segunda recaída. No entanto, este fármaco foi retirado do mercado em junho de 2010 (22,34,44,45,50,64,69,97,99,107,125,126,128,129).  
Apesar da grande melhoria nas taxas de sobrevida global, os pacientes com LMA ainda sofrem recaídas e morrem por causa da doença. A maioria dos óbitos é decorrente da doença progressiva, mas 5%-15% dos pacientes morrem por complicações relacionadas ao tratamento, infecções ocorrentes no momento do diagnóstico e durante o tratamento e outros efeitos colaterais que se manifestam a longo prazo, devidos ao tratamento de alta intensidade. Portanto, é importante identificar a base genética subjacente à heterogeneidade clínica da doença, de modo que estratégias de tratamento alternativas possam ser desenvolvidas. Melhorias nas taxas de sobrevida da LMA provavelmente irão requerer a introdução de terapias individualizadas, em que medicamentos-alvo mais específicos para a leucemia sejam utilizados num esforço para impedir a progressão leucêmica, em combinação com o melhor tratamento de suporte, para prevenir óbitos precoces e relacionados ao tratamento (33,48,76,77,81,114).  
Uma grande preocupação com as crianças é o desenvolvimento a longo prazo da toxicidade cardíaca, após exposição a altas doses de antracíclicos. A encapsulação das antraciclinas é um método potencial do uso desses medicamentos, alternando assim, tanto a atividade anti-tumoral como o perfil dos efeitos colaterais. A daunorrubicina lipossomal demonstrou apresentar diferente farmacocinética, com um potencial para redução da dose limitante da cardiotoxicidade, em  
comparação com a daunorrubicina. Além do mais, foi relatado produzir alta área média sob os níveis da curva plasmática (AUC), devido à lenta distribuição do meio lipossomal dentro do organismo e, também, por reduzir a conversão da daunorrubicina para o tóxico, mas inativo, o daunorrubicinol (25,94,97). Recentemente, a combinação da fludarabina com citarabina e fator estimulante de colônias de granulócitos (FLAG) com doxorrubucina lipossomal não peguilada, em crianças com LMA refratária à terapia de primeira linha, ou que recaíram após a quimioterapia ajustada ao risco, mostrou ser segura em termos de cardiotoxicidade aguda e necessita ser confirmada por estudos clínicos maiores e randomizados (6).

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: Casos especiais de LMA em pacientes pediátricos -->
Crianças com Síndrome de Down (SD) têm acentuada predisposição para leucemia, com um risco de 10 a 20 vezes, quando comparadas com crianças sem SD. Aquelas com SD que desenvolvem LMA usualmente o fazem entre 1 e 4 anos de idade, em geral após terem sofrido de doença mieloproliferativa transitória (DMT, antes referida como reação leucemoide) no período neonatal. Entre as crianças com SD que desenvolvem LMA, é notável a frequência da leucemia do subtipo megacariocítica aguda, que uniformemente abriga mutações somáticas no gene do fator de transcrição GATA1. Uma série de relatos concluiu que as crianças com SD tratadas de LMA tiveram resultado melhor do que as crianças que não apresentam SD. Em geral, a taxa de remissão é de aproximadamente 90% com uma sobrevida livre de eventos de aproximadamente 70%-80% e baixas taxas de recidivas, como 3%. As crianças com SD têm maior sensibilidade à citarabina e alcançam melhor resultado com o uso de esquemas quimioterápicos menos agressivos (30,104,127). Em relatório recente do _Japanese Children´s Cancer and Leukemia Study Group_ (AML9805 Down Study), a quimioterapia contínua e combinada de alta dose de citarabina, com intensidade reduzida neste grupo, se mostrou eficaz em crianças com SD e com LMA (52,116).  
A LMA secundária se refere ao desenvolvimento da LMA, tanto após a história de doença prévia (síndrome mielodisplásica, doença mieloproliferativa crônica) ou após o tratamento com quimioterapia (incluindo agentes alquilantes, inibidores da topoisomerase II - epipodofilotoxinas e antraciclinas - ou radiação) ou a exposição a carcinógenos ambientais. A magnitude do risco associado com esses fatores depende de diversas variáveis, incluindo o esquema de administração, os medicamentos concomitantes e fatores relacionados ao hospedeiro. Os resultados para este grupo de pacientes foram relatados como pobres em comparação com as pessoas que desenvolveram LMA _de novo_ . Estes pacientes de LMA deverão ser incluídos em estudos de quimioterapia de primeira linha e deverão ser estratificados pelo _status_ da doença prétratamento e história da exposição. Estudos recentes em adultos sobreviventes de câncer sugerem que, ao contrário das crenças anteriores, o resultado da LMA secundária não é necessariamente pior do que da LMA _de novo_ , quando ajustada pelas características citogenéticas. Um sistema de classificação do prognóstico foi estabelecido para todos pacientes com LMA secundária, permitindo desenvolver futuras estratégias de tratamento (40,59,96,113,115).

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: Monitorização do tratamento dos pacientes pediátricos com LMA -->
Ao diagnóstico devem ser realizados os seguintes exames de rotina: hemograma completo, testes de coagulação (tempo de protrombina, tempo de tromplastina parcial ou tempo de trombina, fibrinogênio) e de fibrinólise (D-dímeros ou produtos de degradação da fibrina), exame do líquor, mielograma com citoquímicas (PAS, peroxidase, Sudan Black, alfa-naftil, esterase), imunofenotipagem para marcadores mieloides (CD33, CD13, CD14, CD34, HLA-DR, CD61, CD11c, CD41, CD42a, CD56, CD117, Glicoforina/Gero, NG2, CD64), para marcadores linfoides da Linhagem B (CD10, CD19, CD20, CD22, CD34, sIgM, cIgM e cCD79 alfa) e da Linhagem T (CD 2, sCD3, cCD3,  
CD5, CD7, CD34, HLA-DR, TdT, CD 1a, CD4, CD8, CD56, CD99),  citogenética (convencional, de banda ou FISH) e biologia molecular. Provas de função hepática e renal deverão ser feitas antes do tratamento. Exames de imagem são recomendados na suspeita de acometimento extramedular.  
Após o início da terapia, os controles laboratoriais das contagens do sangue periférico, perfil da coagulação/fibrinólise e função renal deverão ser realizados a cada 1-2 dias, conforme as alterações presentes ao diagnóstico. Novo mielograma deverá ser procedido no dia 15 da terapia de indução, para a quantificação dos blastos leucêmicos. Se a contagem dos blastos for inferior a 5%, avaliado pela morfologia, o tratamento pode ser adiado até a recuperação hematológica, tempo durante o qual é recomendado o controle semanal da medula óssea. Para pacientes com 5% ou mais de células blásticas, o prosseguimento da indução deve imediato. A avaliação da Doença Residual Mínima (DRM) no dia 15, por citometria de fluxo ou RQ-PCR, ainda não está definitivamente estabelecida na LMA, como já ocorre nos pacientes com LLA.  
A estratificação do risco (no dia 15 da indução) permite classificar os pacientes em três grupos: Respondedor pobre (15% ou mais de células leucêmicas no D15 ou 5% ou mais no final da indução; Respondedor intermediário (5%-14,9% de células leucêmicas no D15) e Bom respondedor (pacientes com menos de 5% de células leucêmicas no D15). Aos pobres respondedores pode ser oferecido o TCTH, caso seja identificado algum doador compatível, aparentado ou não.  
Ao final da terapia da indução, novo mielograma, exame de citogenética (no caso de se ter identificado alteração genética ao diagnóstico) e exame do líquor devem ser realizados para a definição do estado da Remissão Clínica (RC). A avaliação da DRM no final da indução da LMA ainda necessita de mais estudos, incluindo a escolha da técnica mais recomendada, prevalecendo até o momento o PCR em tempo real.  
Exames cardiológicos de rotina, além dos testes de função hepática e renal, deverão ser realizados antes de cada bloco da consolidação da terapia. Por ocasião do término do tratamento, mielograma (com ou sem estudo citogenético) e exame do líquor são recomendados.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 9- ACOMPANHAMENTO PÓS-TRATAMENTO -->
No seguimento dos pacientes fora de terapia, é recomendado monitorar possível recidiva molecular naqueles doentes de LPMA, com periodicidade variável a cada 3-6 meses nos primeiros 2 anos de acompanhamento. Exame clínico e hemograma completo devem ser mensais durante o primeiro ano fora de terapia, a seguir a cada 2 meses por um ano, espaçando-se, a seguir, para cada 3-6 meses. Exames cardiológicos de rotina deverão ser realizados anualmente.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 10- REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Doentes com menos de 19 anos e diagnóstico de Leucemia Mieloide Aguda devem ser atendidos em hospitais habilitados em oncologia com serviço de hematologia ou de oncologia pediátrica (com hematologia) e com porte tecnológico suficiente para diagnosticar, tratar e realizar seu monitoramento laboratorial.  
Além da familiaridade que esses hospitais guardam com o tratamento, o manejo das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional, de laboratórios e de apoio social necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
O hospital deve ter em suas próprias dependências o atendimento ambulatorial diário, com atendimento emergencial 24h/dia nos 7 dias da semana.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e  
avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, freqüência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos); a verificação dos percentuais das freqüências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente - primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou protocolo adotadas no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
NOTA 1 - Exceto pelo Mesilato de Imatinibe (para a quimioterapia da leucemia mieloide crônica, da leucemia linfoblástica aguda cromossoma Philadelphia positivo e do tumor do estroma gastrointestinal) e, até que se regularize o abastecimento do mercado, pela L-asparaginase (para a quimioterapia da leucemia e linfoma linfoblásticos), o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. [O Mesilato de Imatinibe e a L-asparaginase são comprados pelo Ministério da Saúde e dispensados aos hospitais habilitados em oncologia no SUS pela Assistência Farmacêutica das secretarias estaduais de saúde.] Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendolhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do(s) medicamento(s) antineoplásico(s) é desse hospital, seja ele público ou privado, com ou sem fins lucrativos.  
NOTA 2 - Os seguintes procedimentos da tabela do SUS são compatíveis com a quimioterapia de tumores de criança e adolescente, inclusive a Leucemia Mieloide Aguda:  
03.04.07.001-7– Quimioterapia de Câncer na Infância e Adolescência – 1ª linha;  
03.04.07.002-5 – Quimioterapia de Câncer na Infância e Adolescência – 2ª linha (primeira recidiva);  
03.04.07.004-1– Quimioterapia de Câncer na Infância e Adolescência – 3ª linha (segunda recidiva); e  
03.04.07.03-3 – Quimioterapia de Câncer na Infância e Adolescência – 4ª linha (terceira recidiva).

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 11- TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER -->
É obrigatória a informação ao paciente ou a seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados aos medicamentos e procedimentos utilizados para o diagnóstico e tratamento da leucemia mieloide aguda.

---

<!-- METADADOS: doenca: Leucemia Mieloide Aguda de Crianças e Adolescentes - Diretrizes Diagnósticas e Terapêuticas | secao: 12- REFERÊNCIAS -->
1- Abrahamsson J et al. Response-guided induction therapy in pediatric acute myeloid leukemia with excellent remission rate. J. Clin. Oncol. 29 (2011): 310-315.  
2- Abdel-Wahab O. Molecular genetics of acute myeloid leukemia: clinical implications and opportunities for integrating genomics into clinical practice. Hematology 17 (Suppl 1) (2012): S3942.  
3- Absalon MJ, Smith FO. Treatment strategies for pediatric acute myeloid leukemia. Expert Opin. Pharmacother. 10 (2009): 57-79.  
4- Alpermann T et al. Evaluation of the proposed reporting system of the European LeukemiaNet and recommendations for prognosis of acute myeloid leukemia. Leuk. Res. 37 (2013):197-200.  
5- Balgobind BV et al. The heterogeneity of pediatric MLL-rearranged acute myeloid leukemia. Leukemia 25 (2011): 1239-1248.  
6- Barbaric D et al. Minimally differentiated acute myeloid leukemia (FAB AML-M0) is associated with an adverse outcome in children: a report from the Children's Oncology Group, studies CCG-2891 and CCG-2961. Blood 109 (2007): 2314-2321.  
7- Baron F et al. Impact of graft-versus-host disease after reduced-intensity conditioning allogeneic stem cell transplantation for acute myeloid leukemia: a report from the Acute Leukemia Working Party of the European group for blood and marrow transplantation. Leukemia 26 (2012): 2462-2468.  
8- Becker PS et al. Clofarabine with high dose cytarabine and granulocyte colony-stimulating factor (G-CSF) priming for relapsed and refractory acute myeloid leukaemia. Br. J. Haematol. 155 (2011): 182-189.  
9- Bleakley M et al. Bone marrow transplantation for paediatric AML in first remission: a systematic review and meta-analysis. Bone Marrow Transplant. 29 (2002): 843-852.  
10- Büchner T et al. Acute Myeloid Leukemia (AML): different treatment strategies versus a commom standard arm-combined prospective analysis by the German AML Intergroup. J. Clin. Oncol. 30 (2012): 3604-3610.  
11- Burnett AK. New induction and postinduction strategies in acute myeloid leukemia. Curr. Opin. Hematol. 19 (2012): 76-81.  
12- Burnett A et al. Therapeutic advances in acute myeloid leukemia. J. Clin. Oncol. 29 (2011): 487-494.  
13- Burnett A et al. Identification of patients with acute myeloblastic leukemia who benefit from the addition of gemtuzumab ozogamicin: results of the MRC AML 15 trial. J. Clin. Oncol. 29 (2011): 369-377.  
14- Castaigne S. Why is it so difficult to use gemtuzumab ozogamicin? Blood 121 (2013): 4813-4814.  
15- Castellino SM et al. Outcomes in childhood AML in the absence of transplantation in first remission - Children's Cancer Group (CCG) studies 2891 and CCG 213. Pediatr. Blood Cancer 50 (2008): 9-16.  
16- Cooper TM et al. AAML03P1, a pilot study of the safety of gemtuzumab ozogamicin in combination with chemotherapy for newly diagnosed childhood acute myeloid leukemia. A report from the Children's Oncology Group. Cancer 118 (2012): 761-769.  
17- Craddock C et al. Factors predicting outcome after unrelated donor stem cell transplantation in primary refractory acute myeloid leukaemia. Leukemia 25 (2011): 808-813.  
18- Creutzig U et al. Treatment strategies and long-term results in paediatric patients treated in four consecutive AML-BFM trials. Leukemia 19 (2005): 2030-2042.  
19- Creutzig U et al. Significance of age in acute myeloid leukemia patients younger than 30 years. A common analysis of the pediatric trials AML-BFM 93/98 and the adult trials AMLCG 92/99 and AMLSG HD93/98A. Cancer 112 (2008): 562-571.  
20- Döhner H et al. Diagnosis and management of acute myeloid leukemia in adults: recommendations from an international expert panel, on behalf of the European LeukemiaNet. Blood 115 (2010): 453-474.  
21- Entz-Werle N et al; EORTC Children Leukemia Group. Results of 58872 and 58921 trials in acute myeloblastic leukemia and relative value of chemotherapy vs allogeneic bone marrow transplantation in first complete remission: the EORTC Children Leukemia Group report. Leukemia 19 (2005): 2072-2081.  
22- Epling-Burnette PK, Loughran TP Jr. Suppression of farnesyltransferase activity in acute myeloid leukemia and myelodysplastic syndrome: current understand¬ing and recommended use of tipifarnib. Expert Opin. Investig. Drugs 19 (2010): 689-69.  
23- Estey EH. Acute myeloid leukemia: 2013update on risk-stratification and management. Am. J. Hematol. 88 (2013): 318-327.  
24- Estey EH. How to manage high-risk acute myeloid leukemia. Leukemia 26 (2012): 861-  
869.  
25- Fassas A, Anagnostopoulos A. The use of liposomal daunorubicin (DaunoXome) in acute myeloid leukemia. Leuk. Lymphoma 46 (2005): 795-802.  
26- Feldman EJ, Gergis U. Management of refractory acute myeloid leukemia: reinduction therapy or straight to transplantation? Curr. Hematol. Malig Rep. 7 (2012): 74-77.  
- 27- Fernandez HF et al. Anthracycline dose intensification in acute myeloid leukemia. N. Engl.  
- J. Med. 361 (2009): 1249-1259.  
- 28- Fernandez HF, Rowe JM. Induction therapy in acute myeloid leukemia: intensifying and  
- targeting the approach. Curr. Opin. Hematol. 17 (2010): 79-84.  
29- Ferrara F, Schiffer CA. Acute myeloid leukaemia in adults. Lancet 381 (2013): 484-495.  
30- Gamis AS. Acute myeloid leukemia and Down syndrome evolution of modern therapy – state of the art review. Pediatr. Blood Cancer 44 (2005): 13-20.  
31- Gorman MF et al. Outcome for children treated for relapsed or refractory acute myelogenous leukemia (rAML): a Therapeutic Advances in Childhood Leukemia (TACL) Consortium study. Pediatr. Blood Cancer 55 (2010): 421-429.  
- 32- Gregory TK et al. Molecular prognostic markers for adult acute myeloid leukemia with  
- normal cytogenetics. J. Hematol. Oncol. 2 (2009): 23.  
- 33- Gupta S et al. Treatment-related mortality in children with acute myeloid leukaemia in  
- Central America: Incidence, timing and predictors. Eur. J. Cancer 48 (2012): 1363-1369.  
- 34- Harned TM, Gaynon PS. Treating refractory leukemias in childhood, role of clofarabine.  
- Ther. Clin. Risk Manag. 4 (2008): 327-336.  
35- Harrison CJ et al. Cytogenetics of childhood acute myeloid leukemia: United Kingdom Medical Research Council Treatment trials AML 10 and 12. J. Clin. Oncol. 28 (2010): 2674-2681.  
36- Hemmati PG et al. Reduced intensity conditioning prior to allogeneic stem cell transplantation in first complete remission is effective in patients with acute myeloid leukemia and an intermediate-risk karyotype. Int. J. Hematol. 91 (2010): 436-445.  
37- Henze G, Weinberger H. Esquemas Selecionados no Tratamento dos Cânceres da Criança. 1ª Ed. Baxter. 2012. 263pg. Tradução autorizada.  
- 38- Herdrich K, Weinberger H. Selected Schedules in the Therapy of Malignant Tumors. 17th  
- ed. Baxter. 2013. 229pg.  
39- Hiddemann W et al. German AML Cooperative Group. Towards a pathogenesis-oriented therapy of acute myeloid leukemia. Crit. Rev. Oncol./Hematol. 56 (2005): 235-245.  
40- Hijiya N et al. Acute leukemia as a secondary malignancy in children and adolescents. Current findings and issues. Cancer 115 (2009): 23-35.  
41- Hill BT, Copelan EA. Acute myeloid leukemia: when to transplant in first complete remission. Curr. Hematol. Malig. Rep. 5 (2010): 101-108.  
42- Hong WJ, Medeiros BC. Unfavorable-risk cytogenetics in acute myeloid leukemia. Expert Rev. Hematol. 4 (2011): 173-184.  
43- Hsieh  YY et al. Effect of allogeneic hematopoetic stem cell transplantation from matched siblings or unrelated donors during the first complete remission in patients with cytogenetically normal acute myeloid leukemia. Eur. J. Haematol. 86 (2011): 237-245.  
44- Inaba H et al. Combination of cladribine plus topotecan for recurrent or refractory pediatric acute myeloid leukemia. Cancer 116 (2010): 98-105.  
45- Inaba H et al. Phase I pharmacokinetic and pharmacodynamic study of the multikinase inhibitor sorafenib in combination with clofarabine and cytarabine in pediatric relapsed/refractory leukemia. J. Clin. Oncol. 29 (2011): 3293-3300.  
46- Ishaqi MK et al. Outcome of allogeneic hematopoetic stem cell transplantation for children with acute myelogenous leukemia in second complete remission: single center experience. Pediatr. Transplant. 13 (2009): 999-1003.  
47- Jamieson K, Odenike O. Late-phase investigational approaches for the treatment of relapsed/refractory acute myeloid leukemia. Expert Opin. Pharmacother. 13 (2012): 2171-2187.  
48- Johnston DL et al. The presence of central nervous system disease at diagnosis in pediatric acute myeloid leukemia does not affect survival: a Children's Oncology Group study. Pediatr. Blood Cancer 55 (2010): 414-420.  
49- Juliusson G et al. Age and acute myeloid leukemia: real world data on decision to treat and outcomes from the Swedish Acute Leukemia Registry. Blood 113 (2009): 4179-4187.  
50- Kang HJ et al. High transcript level of FLT3 associated with high risk of relapse in pediatric acute myeloid leukemia. J. Korean Med. Sci. 25 (2010): 841-845.  
- 51- Kaspers GJ. Pediatric acute myeloid leukemia. Expert Rev. Anticancer Ther. 12 (2012):  
- 405-413.  
52- Khan I et al. Myeloid leukemia in down syndrome. Crit. Rev. Oncog. 16 (2011): 25-36.  
53- Klusmann JH et al. The role of matched sibling donor allogeneic stem cell transplantation in pediatric high-risk acute myeloid leukemia: results from the AML-BFM 98 study. Haematologica 97 (2012): 21-29.  
54- Koh KN et al. Favorable outcomes after allogeneic hematopoetic stem cell transplantation in children with high-risk or advanced acute myeloid leukemia. J. Pediatr. Hematol. Oncol. 33 (2011): 281-288.  
55- Koreth J et al. Allogeneic stem cell transplantation for acute myeloid leukemia in first complete remission: systematic review and meta-analysis of prospective clinical trials. JAMA 301 (2009): 2349-2361.  
56- Kubal T, Lancet JE. The thorny issue of relapsed acute myeloid leukemia. Curr. Opin. Hematol. 20 (2013): 100-106.  
57- Kühn MW et al. High-resolution genomic profiling of adult and pediatric core-bindingfactor acute myeloid leukemia reveals new recurrent genomic alterations. Blood 119 (2012): 6775.  
58- Lange BJ et al. Outcomes in CCG-2961, a Children's Oncology Group phase 3 trial for untreated pediatric acute myeloid leukemia: a report from the Children's Oncology Group. Blood 111 (2008): 1044-1053.  
59- Larson RA. Is secondary leukemia an independent poor prognostic factor in acute myeloid leukemia? Best Pract. Res. Clin. Haematol. 20 (2007): 29-37.  
60- Larson SM et al. High dose cytarabine and mitoxantrone: an effective induction regimen for high-risk acute myeloid leukemia (AML). Leuk. Lymphoma 53 (2012): 445-450.  
61- Lee D-H et al. Comparable outcomes of HLA-matched unrelated and HLA-identical sibling donor bone marrow transplantation for childhood acute myeloid leukemia in first remission. Pediatr. Transplant. 13 (2009): 210-216.  
62- Li Z et al. Identification of a 24-gene prognostic signature that improves the international collaborative study. J. Clin. Oncol. 31 (2013): 1172-1181.  
63- Liesveld J. Management of AML: who do we really cure? Leuk. Res. 36 (2012): 14751480.  
64- Litzow MR. Progress and strategies for patients with relapsed and refractory acute myeloid leukemia. Curr. Opin. Hematol. 14 (2007): 130-137.  
65- Löwenberg B et al; Dutch-Belgian Cooperative Trial Group for Hemato-Oncology (HOVON); Swiss Group for Clinical Cancer Research (SAKK) Collaborative Group. Cytarabine dose for acute myeloid leukemia. N. Engl. J. Med. 364 (2011): 1027-1036.  
- 66- Manola KN. Cytogenetics of pediatric acute myeloid leukemia. Eur. J. Haematol. 83  
- (2009): 391-405.  
- 67- Marcucci G et al. Molecular genetics of adult acute myeloid leukemia: prognostic and  
- therapeutic implications. J. Clin. Oncol. 29 (2011): 475-486.  
68- Mathisen MS, Ravandi F. Efficacy of tosedostat, a novel, oral agent for elderly patients with relapsed or refractory acute myeloid leukemia: a review of phase II OPAL trial. Future Oncol. 8 (2012): 351-357.  
- 69- Mato AR et al. Novel strategies for relapsed and refractory acute myeloid leukemia. Curr.  
- Opin. Hematol. 15 (2008): 108-114.  
70- Masetti R et al. Emerging targeted therapies for pediatric acute myeloid leukemia. Recent Pat. Anticancer Drug Discov. 6 (2011): 354-366.  
71- McClune BL et al. Effect of age on outcome of reduced-intensity hematopoetic cell transplantation for older patients with acute myeloid leukemia in first complete remission or with myelodysplastic syndrome. J. Clin. Oncol. 28 (2010): 1878-1887.  
- 72- McLaughlin B et al. Fludarabine and cytarabine in patients with relapsed acute myeloid  
- leukemia refractory to initial salvage therapy. Int. J. Hematol. 96 (2012): 743-747.  
- 73- McKenzie SB. Advances in understanding the biology and genetics of acute myelocytic  
- leukemia. Clin. Lab. Sci. 18 (2005): 28-37.  
- 74- Meshinchi S, Arceci RJ. Prognostic factors and risk-based therapy in pediatric acute  
- myeloid leukemia. Oncologist 12 (2007): 341-355.  
75- Mizushima Y et al. Prognostic significance of the BAALC isoform pattern and CEBPA mutations in pediatric acute myeloid leukemia with normal karyotype: a study by the Japanese Childhood AML Cooperative Study Group. Int. J. Hematol. 91 (2010): 831-837.  
76- Molgaard-Hansen L et al; Nordic Society of Paediatric Haematology and Oncology (NOPHO). Early and treatment-related deaths in childhood acute myeloid leukaemia in the Nordic countries: 1984–2003. Br. J. Haematol. 151 (2010): 447-459.  
77- Molgaard-Hansen L et al; Nordic Society of Paediatric Haematology and Oncology (NOPHO). Treatment-related deaths in second complete remission in childhood acute myeloid leukaemia. Br. J. Haematol. 152 (2011): 623-630.  
78- Mrózek K et al. Prognostic significance of the European LeukemiaNet standardized system for reporting cytogenetic and molecular alterations in adults with acute myeloid leukemia. J. Clin. Oncol. 30 (2012): 4515-4523.  
79- Naoe T, Kiyoi H. Gene mutations of acute myeloid leukemia in the genome era. Int. J. Hematol. 97 (2013): 165-174.  
80- Niewerth D et al. A review on allogeneic stem cell transplantation for newly diagnosed pediatric acute myeloid leukemia. Blood 116 (2010): 2205-2214.  
81- Ofran Y, Rowe JM. Treatment for relapsed acute myeloid leukemia: what is new? Curr. Opin. Hematol. 19 (2012): 89-94.  
82- Ofran Y, Rowe JM. Induction and postremission strategies in acute myeloid leukemia: what is new? Curr. Opin. Hematol. 18 (2011): 83-88.  
83- Oliansky DM et al. The role of cytotoxic therapy with hematopoetic stem cell transplantation in the therapy of acute myeloid leukemia in children: an evidence-based review. Biol. Blood Marrow Transplant. 13 (2007): 1-25.  
84- Paun O, Lazarus HM. Allogeneic hematopoetic cell transplantation for acute myeloid leukemia in first complete remission: have the indications changed? Curr. Opin. Hematol. 19 (2012): 95-101.  
85- Peccatori J, Ciceri F. Allogeneic stem cell transplantation for acute myeloid leukemia. Haematologica 95 (2010): 857-859.  
86- Pedersen-Bjergaard J et al. Genetic pathways in the pathogenesis of therapy-related myelodysplasia and acute myeloid leukemia. Hematology (Am. Soc. Hema¬tol. Educ. Program) 2007 (2007): 392-397.  
87- Perel Y et al. Impact of addition of maintenance therapy to intensive induction and consolidation chemotherapy for childhood acute myeloblastic leukemia: results of a prospective randomized trial, LAME 89/91. Leucamie Aique Mye¬loide Enfant. J. Clin. Oncol. 20 (2002): 27742782.  
88- Phillips GL. Allogeneic hematopoetic stem cell transplantation (HSCT) for high-risk acute myeloid leukemia (AML)/myelodysplastic syndrome (MDS): how can we improve outcomes in the near future? Leuk. Res. 36 (2012): 1490-1495.  
89- Quarello P et al. FLAG-liposomal doxorubicin (Myocet) regimen for refractory or relapsed acute leukemia pediatric patients. J. Pediatr. Hematol. Oncol. 34 (2012): 208-216.  
- 90- Radhi M et al. Prognostic factors in pediatric acute myeloid leukemia. Curr. Hematol.  
- Malig. Rep. 5 (2010): 200-206.  
91- Rao AV et al. Age-specific differences in oncogenic pathway dysregulation and anthracycline sensitivity in patients with acute myeloid leukemia. J. Clin. Oncol. 27 (2009); 55805586.  
92- Ravandi F. Primary refractory acute myeloid leukaemia – in search of better definitions and therapies. Br. J. Haematol. 155 (2011): 413-419.  
93- Ravindranath Y et al; Pediatric Oncology Group. Pediatric Oncology Group (POG) studies of acute myeloid leukemia (AML): a review of four consecutive childhood AML trials conducted between 1981 and 2000. Leukemia 19 (2005): 2101-2116.  
94- Reinhardt D et al. Liposomal daunorubicine combined with cytarabine in the treatment of relapsed/refractory acute myeloid leukemia in children. Klin. Pädiatr. 214 (2002): 188-194.  
95- Ritchie EK et al. Decitabine in patients with newly diagnosed and relapsed acute myeloid leukemia. Leuk. Lymphoma 2013, Feb 7 [Epub ahead of print].  
96- Rizzieri DA et al. Outcomes of patients who undergo aggressive induction therapy for secondary acute myeloid leukemia. Cancer 115 (2009): 2922-2929.  
- 97- Robak T et al. Novel and emerging drugs for acute myeloid leukemia: pharmacology and  
- therapeutic activity. Curr. Med. Chem. 18 (2011): 638-666.  
98- Roboz GJ. Current treatment of acute myeloid leukemia. Curr. Opin. Oncol. 24 (2012): 711-719.  
99- Rodriguez-Ariza A et al. VEGF targeted therapy in acute myeloid leukemia. Crit. Rev. Oncol./Hematol. 80 (2011): 241-256.  
100- Röllig C et al. Long-term prognosis of acute myeloid leukemia according to the new genetic risk classification of the European LeukemiaNet recommendations: evaluation of the proposed reporting system. J. Clin. Oncol. 29 (2011): 2758-2765.  
101- Rubnitz JE. Childhood acute myeloid leukemia. Curr. Treat. Options Oncol. 9 (2008): 95105.  
102- Rubnitz JE et al. Combination of cladribine and cytarabine is effective for childhood acute myeloid leukemia: results of the St Jude AML97 trial. Leukemia 23 (2009): 1410-1416.  
103- Rubnitz JE et al. Minimal residual disease-directed therapy for childhood acute myeloid leukaemia: results of the AML02 multicentre trial. Lancet Oncol. 11 (2010): 543-552.  
104- Rubnitz JE et al. Acute myeloid leukemia. Hematol. Oncol. Clin. North Am. 24 (2010): 35-63.  
105- Sabty FA et al. Is there still a role for autologous stem cell transplantation in acute myeloid leukemia? Neoplasma 60 (2013): 167-173.  
106- Sander A et al. Consequent and intensified relapse therapy improved survival in pediatric AML: results of relapse treatment in 379 patients of three consecutive AML-BFM trials. Leukemia 24 (2010): 1422-1428.  
107- Scott E et al. Targeted signal transduction therapies in myeloid malignancies. Curr. Oncol. Rep. 12 (2010): 358-365.  
108- Smith FO et al; Children's Cancer Group. Long-term results of children with acute myeloid leukemia: a report of three consecutive Phase III trials by the Children's Cancer Group: CCG 251, CCG 213 and CCG 2891. Leukemia 19 (2005): 2054-2062.  
109- Song KW, Lipton J. Is it appropriate to offer allogeneic hematopoetic stem cell transplantation to patients with primary refractory acute myeloid leukemia? Bone Marrow Transplant. 36 (2005): 183-191.  
110- Staffas A et al; Nordic Society of Pediatric Hematology and Oncology (NOPHO). Presence of FLT3-ITD and high BAALC expression are independent prognostic markers in childhood acute myeloid leukemia. Blood 118 (2011): 5905-5913.  
111- Stasi R et al. Gemtuzumab ozogamicin in the treatment of acute myeloid leukemia. Cancer Treat. Rev. 34 (2008): 49-60.  
112- Stein EM, Tallman MS. Remission induction in acute myeloid leukemia. Int. J. Hematol. 96 (2012): 164-170.  
113- Stölzel F et al. Risk stratification using a new prognostic score for patients with secondary acute myeloid leukemia: results of the prospective AML96 trial. Leukemia 25 (2011): 420-428.  
114- Sung L et al. Life-threatening and fatal infections in children with acute myeloid leukemia: a report from the Children's Oncology Group. J. Pediatr. Hematol. Oncol. 34 (2012): e3035.  
115- Szotkowski T et al. Secondary acute myeloid leukemia - a single center experience. Neoplasma 57 (2010): 170-178.  
116- Taga T et al. Continuous and high-dose cytarabine combined chemotherapy in children with Down syndrome and acute myeloid leukemia: Report from the Japanese Children's Cancer and Leukemia Study Group (JCCLSG) AML 9805 Down study. Pediatr. Blood Cancer 57 (2011): 3640.  
117- Teuffel O et al. Anthracyclines during induction therapy in acute myeloid leukaemia: a systematic review and meta-analysis. Br. J. Haematol. 161 (2013): 192-203.  
118- Thomas X et al. Outcome of treatment after first relapse in younger adults with acute myeloid leukemia initially treated by the ALFA-9802 trial. Leuk. Res. 36 (2012): 1112-1118.  
119- Trifilio S et al. Idarubicin appears equivalent to dose-intense daunorubicin for remission induction in patients with acute myeloid leukemia. Leuk. Res. 37 (2013): 868-871.  
120- Tsukimoto I et al. Risk-stratified therapy and the intensive use of cytarabine improves the outcome in childhood acute myeloid leukemia: the AML99 trial from the Japanese Childhood AML Cooperative Study Group. J. Clin. Oncol. 27 (2009): 4007-4013.  
121- Vardiman JW et al. The 2008 revision of the World Health Organization (WHO) classification of myeloid neoplasms and acute leukemia: rationale and important changes. Blood 114 (2009): 937-951.  
122- Vellenga E et al; Dutch-Belgian Hemato-Oncology Cooperative Group (HOVON), Swiss Group for Clinical Cancer Research Collaborative Group (SAKK). Autologous peripheral blood stem cell transplantation for acute myeloid leukemia. Blood 118 (2011): 6037-6042.  
- 123- Verdeguer A et al. Genetic alterations in children and adolescents with acute myeloid  
- leukaemia. Clin. Transl. Oncol. 12 (2010): 590-596.  
124- von Neuhoff C et al. Prognostic impact of specific chromosomal aberrations in a large group of pediatric patients with acute myeloid leukemia treated uniformly according to trial AMLBFM 98. J. Clin. Oncol. 28 (2010): 2682-2689.  
- 125- Watt TC, Cooper T. Sorafenib as treatment for relapsed or refractory pediatric acute  
- myelogenous leukemia. Pediatr. Blood Cancer 2011, Nov 2 [Epub ahead of print].  
- 126- Wiernik PH. FLT3 inhibitors for the treatment of acute myeloid leukemia. Clin. Adv.  
- Hematol. Oncol. 8 (2010): 429-436.  
- 127- Xavier AC et al. Unique clinical and biological features of leukemia in Down syndrome  
- children. Expert Rev. Hematol. 3 (2010): 175-186.  
- 128- Zhu X et al. Novel agents and regimens for acute myeloid leukemia: 2009 ASH an¬nual  
- meeting highlights. J. Hematol. Oncol. 3 (2010): 17.  
129- Zwaan CM et al; International BFM Study Group on Paediatric AML. Salvage treatment for children with refractory first or second relapse of acute myeloid leukaemia with gemtuzumab ozogamicin: results of a phase II study. Br. J. Haematol. 148 (2010): 768-776.  
- <mark>130- Breen KA et al. The pathogenesis and management of the coagulopathy of acute</mark>  
- <mark>promyelocytic leukaemia. Br. J. Haematol. 156 (2012): 24-36.</mark>  
- 131- Mantadakis E et al. A comprehensive review of acute promyelocytic leukemia in  
- children. Acta Haematol. 119 (2008): 73-82.  
132- Adès L et al. Treatment of newly diagnosed acute promyelocytic leukemia (APL): a comparison of French-Belgian-Swiss and PETHEMA results. Blood 111 (2008): 1078-1084.  
133- Adès L et al. Is cytarabine useful in the treatment of acute promyelocytic    leukemia? Results of a randomized trial from the European Acute Promyelocytic Leukemia Group. J. Clin. Oncol. 24 (2006): 5703-5710.  
134- Creutzig U et al; AML-BFM Study Group. Favourable outcome of patients with childhood acute promyelocytic leukaemia after treatment with reduced cumulative anthracycline doses. Br. J. Haematol. 149 (2010): 399-409.  
135- Fenaux P et al. Treatment of acute promyelocytic leukemia by retinoids. Curr. Top. Microbiol. Immunol. 313 (2007): 101-128.  
- 136- Ferrara F. Acute promyelocytic leukemia: what are the treatment options? Expert Opin.  
- Pharmacother. 11 (2010): 587-596.  
137- Gregory J, Feusner J. Acute promyelocytic leukemia in childhood. Curr. Oncol. Rep. 11 (2009): 439-445.  
138- Kamimura T et al. Advances in therapies for acute promyelocytic leukemia. Cancer Sci. 102 (2011): 1929-1937.  
- 139- Lo-Coco F, Ammatuna E. Front line clinical trials and minimal residual disease  
- monitoring in acute promyelocytic leukemia. Curr. Top. Microbiol. Immunol. 313 (2007): 145-156. 140- Mi J. Current treatment strategy of acute promyelocytic leukemia. Front. Med. 5  
- (2011): 341-347.  
141- Sirulnik LA, Stone RM. Acute promyelocytic leukemia: current strategies for the treatment of newly diagnosed disease. Clin. Adv. Hematol./Oncol. 3 (2005): 391-397.  
- 142- Yoo ES. Recent advances in the diagnosis and management of childhood acute  
- promyelocytic leukemia. Korean J. Pediatr. 54 (2011): 95-105.  
- 143- Grimwade D et al. Acute promyelocytic leukemia: a paradigm for differentiation  
- therapy. Cancer Treat. Res. 145 (2010): 219-235.  
144- Hu J et al. Long-term efficacy and safety of all-trans retinoic acid/arsenic trioxide-based therapy in newly diagnosed acute promyelocytic leukemia. Proc. Natl. Acad. Sci. USA 106 (2009): 3342-3347.  
- 145- Hu J. Arsenic in the treatment of newly diagnosed acute promyelocytic leukemia:  
- current status and future research direction. Front. Med. 5 (2011): 45-52.  
- 146- Park JH, Tallman MS. Managing acute promyelocytic leukemia without conventional  
- chemotherapy: is it possible? Expert Rev. Hematol. 4 (2011): 427-436.  
- 147- Ravandi F et al. Effective treatment of acute promyelocytic leukemia with all-trans-  
- retinoic acid, arsenic trioxide, and gemtuzumab ozogamicin. J. Clin. Oncol. 27 (2009): 504-510.  
- 148- Sanz MA, Lo-Coco F. Modern approaches to treating acute promyelocytic leukemia. J.  
- Clin. Oncol. 29 (2011): 495-503.  
- 149- Sanz MA et al. Management of acute promyelocytic leukemia: recommendations from  
- an expert panel on behalf of the European LeukemiaNet. Blood 113 (2009): 1875-1891.  
- 150- Wang H et al. The efficacy and safety of arsenic trioxide with or without all-trans  
- retinoic acid for the treatment of acute promyelocytic leukemia: a meta-analysis. Leuk. Res. 35 (2011): 1170-1177.  
- 151- Zhou J et al. Single-agent arsenic trioxide in the treatment of children with newly  
- diagnosed acute promyelocytic leukemia. Blood 115 (2010): 1697-1702.  
<mark>152- Au WY et al.Oral arsenic  trioxide for relapsed acute promyelocytic leukemia in pediatric patients. Pediatr. Blood Cancer 58 (2012): 630-632</mark>  
<mark>153- Breccia M, Lo-Coco F. Gemtuzumab ozogamicin for the treatment of acute promyelocytic leukemia: mechanisms of action and resistance, safety and efficacy. Expert Opin. Ther. 11 (2011): 225-234</mark>  
- 154- Dvorak CC et al. Hematopoietic stem cell transplant for pediatric acute promyelocytic  
- leukemia. Biol. Blood Marrow Transplant. 14 (2008): 824-830.  
- 155- Tallman MS. Treatment of relapsed or refractory acute promyelocytic leukemia. Best  
- Pract.Res. Clin.Hematolol. 20 (2007): 57-65  
156- Dayyani F et al. Outcome of therapy-related acute promyelocytic leukemia with or without arsenic trioxide as a component of frontline therapy. Cancer 117 (2011): 110-115.  
157- Elliott MA et al. Therapy-related acute promyelocytic leukemia: observations relating to APL pathogenesis and therapy. Eur. J. Haematol. 88 (2012): 237-243.  
158- Joannides M et al. Mediterr. Molecular pathogenesis of secondary acute promyelocytic leukemia. J. Hematol. Infect. Dis. 3 (2011): e2011045.  
159- Pulsoni A et al. Clinicobiological features and outcome of acute promyelocytic leukemia occurring as a second tumor: the GIMEMA experience. Blood 100 (2002): 1972-1976. 160- Ravandi F. Therapy-related acute promyelocytic leukemia. Haematologica 96 (2011):  
493-495.

---

