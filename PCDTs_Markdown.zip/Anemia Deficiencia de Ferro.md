<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: Geral -->
Protocolo Clínico e Diretrizes Terapêuticas anemia Por DeFiciência De Ferro  
Portaria SAS/MS nº 1.247, de 10 de novembro de 2014.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **1 METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA** -->
Foram realizadas buscas nas bases de dados Medline/Pubmed, Embase e Cochrane em 18/08/2014.  
Na base de dados Medline/Pubmed foram utilizados os termos “Anemia, Iron Deficiency” [Mesh] AND “Therapeutics” [Mesh] restringindo-se a humanos e estudos de tipo meta-análise, revisão sistemática e ensaio clínico randomizado. A busca resultou em 279 artigos dos quais 23 foram selecionados. Foram excluídos 256 artigos por não serem estudos randomizados, por tratarem de suplementação de ferro, dietas ou micronutrientes, bioequivalência de produtos orais indisponíveis no Brasil, farmacocinética e efeitos antioxidantes de diferentes produtos do ferro, por tratarem de outras doenças ou deficiências (infecção por _Helycobacter pylori,_ câncer e quimioterapia, doença inflamatória intestinal, gastrectomia, cirurgias bariátrica, ortopédica e cardíaca, insuficiência cardíaca, suplementação de vitamina B12 ou vitamina A, zinco, chumbo, infestações por helmintos, fratura de fêmur, clampeamento de cordão umbilical, colite ulcerativa, nutrição parenteral, eritropoietina, anemia sideropênica), línguas inacessíveis (chinês e tcheco) ou por anemia em insuficiência renal crônica, que dispõe de protocolo específico.  
Na base de dados Embase foi realizada a busca com os termos ‘iron deficiency anaemia’/exp AND ‘therapy’/exp AND ([Cochrane review]/lim OR [metaanalysis]/lim OR [randomized controlled trial]/lim OR [systematic review]/lim) AND [humans}/lim AND [embase]/lim. A busca resultou em 487 artigos dos quais 18 foram selecionados. Foram excluídos 469 artigos por não serem estudos randomizados, por tratarem de suplementação de ferro ou de dietas e micronutrientes para a profilaxia da anemia, por tratarem de outras doenças (bócio, osteoporose, obesidade, cirurgias gástrica e ortopédica, insuficiência cardíaca, câncer, hepatite, colite ulcerativa, doença de Crohn, doença inflamatória intestinal, doença de Parkinson, doença celíaca, insuficiência renal crônica), por serem estudos governamentais sem conclusão ainda ou por tratarem de acupuntura, exames radiológicos do intestino e clampeamento do cordão umbilical.  
Na base de dados Cochrane foram encontradas 91 revisões sistemáticas sendo 65 revisões completas. Foram selecionadas 3, sendo 62 excluídas por tratarem de suplementação de ferro, zinco, folato, vitamina A, B12 e E, micronutrientes e iodo, tratamento com placebo, amamentação materna, tempo de clampeamento do cordão, hiperbilirrubinemias, fortificação de alimentos, sobrecarga de ferro, acupuntura, outras doenças e tratamentos (artrite reumatóide, câncer, insuficiência renal crônica, hepatite C, AIDS, verminoses).  
Além disso, também foram utilizados para elaboração do presente Protocolo o _Uptodate_ 2014, artigos nacionais, algumas revisões Cochrane não contempladas na busca e artigos conhecidos pelos autores.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **2 INTRODUÇÃO** -->
A anemia é definida por valores de hemoglobina (Hb) no sangue abaixo do normal para idade e gênero. É um dos principais problemas de saúde pública mundial, chegando a afetar mais de um quarto da população do planeta, ou seja, mais de 2 bilhões de pessoas em todo o mundo. (1) A metade dos casos é determinada por deficiência de ferro (DF), a deficiência nutricional mais prevalente e negligenciada no mundo, particularmente entre as mulheres e as crianças dos países em desenvolvimento. É também significativamente prevalente nos países industrializados e afeta pessoas de todas as idades em todos os países. (2-4)  
**Consultores:** Beatriz Antunes de Mattos, Lucia Mariano da Rocha Silla, Bárbara Corrêa Krug, Candice Beatriz Treter Gonçalves, Karine Medeiros Amaral, Luciana Costa Xavier, Ricardo de March Ronsoni e Roberto Eduardo Schneiders  
**Editores:** Paulo Dornelles Picon, Maria Inez Pordeus Gadelha e Rodrigo Fernandes Alexandre Os autores declaram ausência de conflito de interesses.  
27  
Protocolos Clínicos e Diretrizes Terapêuticas  
A prevalência de anemia por DF (ADF) aumenta em populações com carências nutricionais; com ingestão ou absorção inadequada de ferro; hábitos vegetarianos; dietas com muito chá ou café, que inibem a absorção de ferro, ou sem vitamina C (frutas cítricas), que favorece a sua absorção; baixo nível sócio-econômico e educacional; presença de infestações endêmicas (malária, ascaridíase, helmintoses, protozooses intestinais); estado nutricional influenciado pelo baixo peso, principalmente de mulheres em idade gestacional, associado à multiparidade e não uso de suplementação de ferro na gestação. (5-7) Além disto, a ADF pode ser causada por hemorragias diversas, como as devidas a traumas ou por melena, hematêmese, hemoptise, menstruações, partos ou por múltiplas gestações. Pode também apontar para uma doença grave subjacente com sangramento oculto, que deve ser afastada com investigação adequada em homens e mulheres na pós-menopausa, principalmente no que diz respeito ao diagnóstico precoce da doença maligna colorretal. (4,6,8-10)  
Independente da etiologia, quando o sangue tem células vermelhas insuficientes ou estas carregam hemoglobina insuficiente para entregar oxigênio adequadamente para os tecidos significa que houve falha na produção das hemácias e sobrevém anemia, muitas vezes multifatorial num mesmo indivíduo e por isto uma síndrome complexa para avaliação e estabelecimento da conduta a adotar. (11)  
A Pesquisa Nacional de Demografia e Saúde (PNDS) de 2006 mostra que a prevalência de deficiência de ferro entre crianças menores de 5 anos no Brasil é de 20,9%, com prevalência de 24,1% em menores de 2 anos e de 29,4% das mulheres férteis. (12) No entanto, outros estudos brasileiros apontam para uma mediana da prevalência de anemia em menores de 5 anos de 50%, chegando a 52% nas crianças que frequentam escolas ou creches e 60,2% nas que frequentam Unidades Básicas de Saúde. (13-15) Em estudo clínico randomizado realizado em Goiânia em 2008, crianças entre 6 e 24 meses constituem o grupo mais vulnerável, apresentando prevalência de 56,1%.(16) A prevalência geral no Brasil varia entre 30% e 69%, dependendo do tipo de comunidade estudada. (15,17,18) Estudo recente sobre a prevalência no estado do Rio Grande do Sul da anemia em crianças com idade de 18 meses a 6 anos e em mulheres jovens em idade fértil e não grávidas de 14 a 30 anos apresentou as cifras de 45,4% (IC 95% 43,3%-47,5%) e 36,4% (IC 95% 34%-38,3%), respectivamente. A prevalência para as crianças varia com a idade, sendo de 76% quando abaixo de 23 meses e de 31% quando acima de 6 anos. Nas mulheres não há correlação com a idade. Para ambos há correlação de anemia com grupo sócio-econômico mais baixo e com os negros. Mas a anemia também é identificada nas classes mais altas, chegando a afetar 34,3% das crianças e 31,4% das mulheres adultas. (20)  
A Organização Mundial da Saúde (OMS) tem uma classificação por categoria de significância para a saúde pública da anemia baseada na sua prevalência e estimada pelos níveis de Hb e hematócrito (Ht), considerando grave a prevalência igual ou maior que 40% numa população. Este seria o caso de muitas regiões do Brasil. (1)  
As gestantes têm maior risco de desenvolver DF e ADF pelas altas demandas fisiológicas próprias e da unidade feto-placentária, difíceis de serem supridas apenas pela dieta, além da perda sanguínea que pode ocorrer durante o parto. Devido à anemia, essas mulheres têm menor ganho de peso durante a gestação, maiores riscos de partos prematuros, placenta prévia, hemorragias, ruptura prematura de membranas, pré-eclâmpsia, eclâmpsia, sepsis pós-natal, maior risco de morte, menor desempenho laboral, fadiga, fraqueza e dispneia assim como maiores complicações para o feto como baixo-peso do recém-nascido (RN), prematuridade, mortalidade natal, anemia neonatal, falha do desenvolvimento pela anemia e pobre desenvolvimento intelectual. (1,2,7,10) Existe uma forte relação entre o _status_ de ferro da mãe e a depressão, o _stress_ , as funções cognitivas e as interações mãe-filho, ou seja, a deficiência de ferro afeta negativamente o seu humor e as interações com o RN, e a suplementação protege contra estes efeitos. (1,21-23)  
A ADF na gestação é frequentemente diagnosticada e tratada, mas os efeitos destes tratamentos permanecem largamente desconhecidos e mais pesquisas precisam ser realizadas para melhorar o prognóstico materno e neonatal de mulheres com anemia moderada e grave em lugares com poucos recursos. (11)  
Todos os RN têm um declínio da sua Hb ao nascer, pelo aumento da PaO2 (pressão parcial de oxigênio arterial) e da saturação da Hb após o nascimento. Para o RN de baixo peso (menos de 1.500 g) e para os prematuros, o risco é agravado pela grande freqüência de punções venosas para exames, menor sobrevida das hemácias e crescimento rápido. Eles têm também maiores riscos de desenvolver anemia por possuírem menores reservas de ferro ao nascimento e pela incapacidade de regular a absorção de ferro pelo trato gastrointestinal (TGI). O RN a termo, sem ingestão suficiente de ferro, vai apresentar anemia quando terminarem suas reservas de ferro. A alimentação prolongada apenas com leite materno está associada com DF, ADF e deficiências de micronutrientes. (24,25) Possíveis perdas de sangue contribuem para as causas de deficiência de ferro nas crianças. (26)  
28  
Anemia por deficiência de ferro  
As causas e a epidemiologia da anemia diferem nas crianças de 2 a 5 anos. Pelo 3º ano de idade, a velocidade de crescimento diminui, a necessidade de ferro diária é reduzida e as crianças autocorrigem a sua DF. Um estudo no Brasil mostra que a prevalência da anemia é de 64% em crianças de 12 a 16 meses de idade, sendo 90% por DF, enquanto crianças de 3 a 4 anos têm uma prevalência de 38%, com a DF sendo responsável em apenas 20%. Neste grupo, a má nutrição, deficiência de B12 ou folato, hemoglobinopatias, verminoses e malária podem ser as causas. A DF nesta faixa etária pode levar a conseqüências funcionais além da anemia, com prejuízos na motricidade, no crescimento físico e no desenvolvimento cognitivo. A suplementação melhoraria estes desfechos, mas algum prejuízo seria irreversível. (25) As crianças com ADF recebem escores menores em testes de desenvolvimento mental quando comparadas com seus pares com melhor _status_ de ferro e demonstram dificuldades afetivas antes do tratamento, e estudo mostra que têm também desvantagens em relação ao aleitamento materno e às experiências familiares. Não há melhora das respostas mentais mesmo após o tratamento com ferro por 6 meses, apesar de boa resposta dos testes hematológicos em estudo clínico randomizado. (27) Os médicos não podem ter certeza que tratando a ADF das crianças menores de 3 anos de idade vá resultar em alterações positivas no desenvolvimento psicomotor e na função cognitiva. (28)  
No entanto, a ADF afeta pessoas de todas as idades em todo o mundo, em países desenvolvidos ou em desenvolvimento. Dados da Terceira Pesquisa de Exames de Saúde e Nutrição Nacional americano (NHANES III; 1988 a 1994) indicou a presença de ADF em 1% a 2% dos adultos. A deficiência isolada de ferro é mais prevalente, ocorrendo em 11% das mulheres e em 4% dos homens. Nesta pesquisa, a prevalência de deficiência de ferro foi significativamente maior nos adultos mais velhos, entre 12% e 17% nas pessoas com 65 ou mais anos. (4) Alta prevalência de anemia está associada à idade avançada e a condições agudas ou crônicas, como a doença renal crônica. Em pessoas com 85 ou mais anos, a prevalência é de 26% para homens e de 20% para mulheres (NHANES III). Isto se torna mais importante com a tendência de envelhecimento da população mundial. (29)  
Nos países em desenvolvimento, como o Brasil, em torno de 20% a 35% das mulheres não gestantes têm ADF, principalmente por perdas menstruais ou inadequada ingestão ou absorção do ferro. (20)  
Além da anemia e prejuízo no desempenho físico, intelectual e de trabalho, há relatos de funções neurotransmissoras, imunológicas e inflamatórias alteradas e maior risco de infecções. São, resumindo, os mais pobres, os mais vulneráveis e os menos educados, os mais afetados pela deficiência de ferro. São eles também os mais beneficiados com a reposição. (5,6,30)  
No Brasil, a Política Nacional de Alimentação e Nutrição - PNAN apresenta-se com o propósito de melhorar as condições de alimentação, nutrição e saúde, em busca da garantia da Segurança Alimentar e Nutricional da população brasileira. (12) Considerando a magnitude da anemia no Brasil, o PNAN estabelece ações de promoção, prevenção e controle da ADF no âmbito do SUS. (31) Em virtude do exposto, a profilaxia da ADF não faz parte do escopo deste Protocolo.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **3 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- D50.0 Anemia por deficiência de ferro secundária à perda de sangue (crônica)  
- D50.8 Outras anemias por deficiência de ferro

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **4.1 DIAGNÓSTICO CLÍNICO** -->
Os sintomas usuais da ADF incluem fraqueza, cefaleia, irritabilidade, síndrome das pernas inquietas e vários graus de fadiga e intolerância aos exercícios ou pica (apetite pervertido por barro ou terra, papeis, amido). Pode ainda ocorrer pica por gelo, que é considerada bastante específica para DF. No entanto, muitos pacientes são assintomáticos, sem clínica típica e só reconhecem os  
29  
Protocolos Clínicos e Diretrizes Terapêuticas  
sintomas retrospectivamente, após o tratamento. Pacientes com ferritina baixa e sem anemia podem ter os mesmos sintomas. Idosos costumam apresentar início insidioso com sintomas relacionados à exacerbação de suas comorbidades subjacentes (piora da angina, aumento da confusão mental, dispneia). (4) Alguns pacientes com DF, com ou sem anemia, podem se queixar de dor na língua, diminuição do fluxo salivar com boca seca e atrofia das papilas linguais e, ocasionalmente, de alopecia. (4)  
Alguns pacientes com DF, com ou sem anemia, podem se queixar de dor na língua, diminuição do fluxo  
A depleção de ferro ocorre de forma progressiva, de acordo com a extensão e a rapidez da instalação. Primeiro há depleção das reservas de ferro e depois do ferro disponível para a síntese da Hb. Se a deficiência continua, pode haver suspensão da produção das células vermelhas. Portanto, o desenvolvimento da DF e depois da ADF vai depender das reservas iniciais do indivíduo que, por sua vez, vão depender da sua idade, gênero, taxa de crescimento e balanço entre a absorção e as perdas de sangue. (4)  
A ADF pós-parto se caracteriza por sintomas não específicos, como astenia, fadiga, dispneia, palpitações ou infecções e dificuldades físicas, cognitivas e depressão, que dificultam a relação mãe-filho e a nutrição do RN. (23,32)  
O diagnóstico diferencial da ADF inclui doenças parasitárias, como malária, ancilostomíase e esquistossomose; causas nutricionais como carências de ácido fólico, vitamina A e vitamina B12 e causas genéticas, como as hemoglobinopatias hereditárias tipo talassemias. (10)

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **4.2 DIAGNÓSTICO LABORATORIAL** -->
Na suspeita de ADF, deve-se solicitar um hemograma completo (com os índices hematimétricos e avaliação de esfregaço periférico) e dosagem de ferritina. Outras medidas, como ferro sérico, transferrina e a saturação da transferrina não são obrigatórios. Pacientes com ADF têm ferro sérico baixo, transferrina alta e uma saturação da transferrina baixa. (4)  
De acordo com os padrões diagnósticos da OMS, a ADF é leve a moderada, se a Hb fica entre 7 a 12 g/ dL, e grave, se a Hb for menor que 7 g/dL, com pequenas variações de acordo com a idade, gênero ou presença de gestação. (33)  
Para as crianças entre 6 e 59 meses de idade, a anemia é definida como uma Hb abaixo de 11 g/dL, entre 5 e 11 anos como uma Hb abaixo de 11,5 g/dL e entre 12 e 14 anos como uma Hb abaixo de 12 g/dL. Para estudos populacionais, considera-se anemia uma Hb abaixo de 11,5 g/dL para idade maior de 2 anos. (1,33,34) Para a população feminina adulta, considera-se anemia valores de Hb abaixo de 12 g/dL e para homens valores de Hb abaixo de 13 g/dL. (1,33,35)  
Para as gestantes, a anemia é definida por Hb abaixo de 11 g/dL. Classifica-se a anemia na gestação em leve, moderada ou grave, conforme taxas entre 9 e 11 g/dL, 7 e 9 g/dL e abaixo de 7 g/dL, respectivamente. (1,5)  
A anemia da puérpera é definida com uma taxa de Hb abaixo de 10 g/dL nas primeiras 48 horas ou abaixo de 12 g/dL nas primeiras semanas após o parto. (5)  
Para os idosos as taxas que definem anemia são de Hb abaixo de 13,2 g/dL para homens e 12,2 g/dL para mulheres brancas. Para os idosos negros, estes valores são um pouco menores, com o corte na Hb abaixo de 12,7 g/dL para os homens e de 11,5 g/dL para as mulheres. (29)  
Embora a Hb seja amplamente utilizada para a avaliação de ADF, ela tem baixas especificidade e sensibilidade, e um biomarcador do _status_ do ferro, como a ferritina sérica, deve ser solicitado em conjunto. (36)  
Inicialmente aparece anemia (Hb abaixo dos valores determinados para idade e gênero) normocítica (volume corpuscular médio - VCM – normal), com valor absoluto de reticulócitos normais e com marcadores do _status_ do ferro baixos, como ferritina abaixo de 30 mcg/L, ferro abaixo de 330 mcg/L, capacidade ferropéxica sérica acima de 4 mg/L, aumento de transferrina e diminuição da saturação da mesma (abaixo de 20%). Com a continuação da perda sanguínea, aparecerá anemia hipocrômica clássica (com hemoglobina corpuscular média - CHCM baixa) e microcitose (com VCM baixo). Com a piora da anemia e da DF, surgem a anisocitose (células de tamanhos variados) e a poiquilocitose (células de formas variadas). (4,37)  
A concentração da ferritina sérica (FS) é o mais confiável marcador das reservas de ferro do corpo, substituindo a avaliação da medula óssea realizada anteriormente. Os valores normais variam de 40 a 200 ng/mL (mcg/L), não havendo nenhuma situação clínica em que índices baixos não signifiquem deficiência de ferro. Portanto, todo indivíduo com concentração de ferritina menor do que 10 a 15 ng/mL tem deficiência de ferro, com uma sensibilidade de 59% e uma especificidade de 99%. No entanto, devido à baixa sensibilidade do nível abaixo de 15 ng/mL, um valor de corte mais alto é mais apropriado. Desde que os pacientes com ADF  
30  
Anemia por deficiência de ferro  
não tenham uma infecção ou uma doença inflamatória junto, o valor limite de 30 ou 41 ng/mL dá uma melhor eficiência diagnóstica com uma sensibilidade e especificidade de 92% e 98% ou 98% e 98%, respectivamente. Como a ferritina é um reator de fase aguda, com níveis aumentados em doenças inflamatórias, infecciosas, malignas ou hepáticas, pode haver uma ferritina falsamente elevada na presença destas doenças e ADF. O efeito da inflamação sobre a ferritina é de aumentá-la em três vezes. Portanto, nestes pacientes a regra de ouro é dividir o valor da ferritina por 3 e valores menores ou igual a 20 ng/mL sugerem ADF concomitante. (4)  
O diagnóstico de deficiência funcional de ferro ocorre em situações clínicas em que a taxa aumentada de eritropoese ocorre por perda sanguínea significativa de sangue, flebotomias terapêuticas repetitivas ou por uso de estimuladores da eritropoese, e os suprimentos de ferro, embora normais ou até aumentados, não são suficientes para fornecer ferro rapidamente, conforme exigido por esta demanda aumentada. Isto atenua a resposta eritropoética, resultando numa produção de células vermelhas insuficientes em ferro, a menos que uma fonte extra seja adicionada, como a preparação para aplicação intravenosa (IV) de ferro. Esta situação é chamada de deficiência funcional de ferro e é comumente vista, por exemplo, na anemia da insuficiência renal crônica, em que se indica o uso de estimulador da eritropoese. (4)

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **5 CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo:  
- crianças entre 6 e 59 meses com Hb abaixo de 11 g/dL;  
- crianças entre 5 e 11 anos com Hb abaixo de 11,5 g/dL;  
- crianças entre 12 e 14 anos com Hb abaixo de 12 g/dL;  
- gestantes com Hb abaixo de 11 g/dL;  
- pacientes adultos masculinos com Hb abaixo de 13 g/dL;  
- pacientes idosos masculinos brancos com Hb abaixo de 13,2 g/dL;  
- pacientes idosos masculinos negros com Hb abaixo de 12,7 g/dL;  
- pacientes adultas femininos com Hb abaixo de 12 g/dL;  
- pacientes idosas femininas brancas com Hb abaixo de 12,2 g/dL;  
- pacientes idosas femininas negras com Hb abaixo de 11,5 g/dL; e  
- ferritina abaixo de 30 ng/mL ou  
- pacientes com doenças inflamatórias, infecciosas, malignas ou hepáticas que tenham Hb baixa para sua idade e gênero, cujo valor da ferritina dividido por 3 seja abaixo ou igual a 20 ng/mL.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **6 CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos os pacientes que apresentarem hipersensibilidade a qualquer formulação de ferro preconizada neste Protocolo.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **7 CASOS ESPECIAIS** -->
Pacientes com anemia grave por DF, refratária ao tratamento após oito semanas, devem ser avaliados para o diagnóstico da infecção pelo _Helicobacter pylori._ Em países em desenvolvimento, a prevalência de _H. pylori_ é alta entre gestantes e população geral com ADF. A erradicação dessa bactéria mostrou-se efetiva e segura nestes casos, melhorando a resposta à suplementação do ferro e ácido fólico, de acordo com meta-análises de 2010. (38)  
Pacientes com doença inflamatória intestinal crônica tem prevalência de anemia tão alta quanto 75% durante o curso de sua doença, tendo como causa mais comum a DF. A anemia recorre com a suspensão do tratamento, pelo prejuízo na absorção oral do ferro e do seu aproveitamento nutricional, além das perdas crônicas de sangue características da doença. Neste grupo, o tratamento com ferro IV (sacarato hidróxido férrico) é superior ao oral na melhora dos níveis de ferritina, com menos efeitos adversos, conforme meta-análise de 2012 e diretrizes internacionais, sendo, portanto recomendado neste PCDT para este grupo. (39)  
31  
Protocolos Clínicos e Diretrizes Terapêuticas

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.1 TRATAMENTO NÃO MEDICAMENTOSO** -->
Os esforços e as estratégias gerais na prevenção da DF devem contemplar a redução da pobreza, o acesso a dietas diversificadas, a melhora nos serviços de saúde e saneamento e a promoção de melhores cuidados com as práticas de alimentação. O tratamento preventivo e sustentável da DF inclui, primordialmente, a garantia do aporte nutricional necessário de ferro para a população vulnerável. (1,34)  
Atualmente, entre os grupos de risco mais vulneráveis para a ocorrência de anemia estão as crianças com menos de 2 anos, gestantes e mulheres no pós-parto. Existem evidências crescentes que as deficiências em micronutrientes têm papel central em impedir que crianças atinjam seu pleno potencial e tenham comprometimento irreversível de seu desenvolvimento cognitivo. (20,31) Os alimentos fontes de ferro devem ser recomendados, principalmente as carnes vermelhas, vísceras (fígado e miúdos), carnes de aves, peixes e hortaliças verde-escuras, entre outros. Para melhorar a absorção do ferro, recomenda-se a ingestão de alimentos ricos em vitamina C, disponível nas frutas cítricas, como laranja, acerola e limão, evitando-se excessos de chá ou café, que dificultam esta absorção. (1,5,34)

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.2 TRATAMENTO MEDICAMENTOSO** -->
A escolha da preparação de ferro vai depender da gravidade da doença e da tolerância do paciente ao ferro oral que, por ser eficaz e barato, é considerado a primeira linha de tratamento. No entanto, existem indicações para o uso parenteral de ferro atualmente, cujas preparações se tornaram mais eficazes e seguras. (40)  
O ferro é mais bem absorvido no duodeno e no jejuno proximal, onde as proteínas carreadoras do ferro expressam-se mais fortemente. As preparações que liberam ferro adiante destas porções intestinais são, pois, ineficazes. Os sais de ferro não devem ser administrados com as refeições, porque os fosfatos, fitatos e tanatos da dieta se ligam ao ferro e dificultam a sua absorção. Assim como não devem ser ingeridos com antiácidos, bloqueadores da bomba de prótons, bebidas e suplementos com cálcio, antibióticos (quinolonas e tetraciclinas), café, chá, leite ou ovos. Deve ser administrado 2 horas antes dos antiácidos ou 4 horas após. (40) No entanto, como é fundamental melhorar a aderência do paciente e tornar eficaz o tratamento pela via oral, sugere-se muitas vezes a administração das doses junto às refeições ou até a diminuição da dose para amenizar os efeitos adversos. É essencial motivar a adesão, com mensagens educativas e informações dos benefícios do tratamento para mãe, feto e crianças, comprometendo os envolvidos com a terapia. (1,40)  
O ferro é também mais bem absorvido como sal ferroso (Fe++) num ambiente levemente ácido, daí a indicação de tomá-lo com meio copo de suco de laranja. (40) Inexiste evidência de diferença de eficácia para o tratamento de DF entre as diferentes preparações orais de ferro, tais quais fumarato, gluconato e sulfato. Existem muitas outras preparações além destas, geralmente mais caras e algumas com pior absorção. (40) Estudo randomizado comparou preparações de ferro férrico (Fe+++) com ferro ferroso (Fe++) no tratamento da ADF em mulheres em relação à eficácia e efeitos adversos e concluiu que ambos são seguros em relação aos efeitos gastrintestinais, mas o ferroso é mais eficaz e econômico. (9)  
Quanto à reposição parenteral de ferro, a via IV é melhor que a intramuscular, pois esta apresenta complicações locais (dor, abscesso, pigmentação cutânea) e sistêmicas (febre, artralgias, reações alérgicas potencialmente graves). (5) Há relutância ao uso IV pelos médicos pelos graves efeitos adversos das antigas preparações de ferro associadas com o alto peso molecular do ferro dextran (anafilaxia, choque e morte). (40) Porém, há muitas situações em que a administração IV é necessária ou preferível. Casos de anemia grave em que não há resposta ao tratamento oral (sem aumento da Hb em 8 semanas, por exemplo) ou que haja intolerância absoluta do paciente ao uso oral (náusea ou vômitos incoercíveis). Quando uma quantidade muito grande de ferro for necessária para repor as perdas sanguíneas diárias que superam a capacidade de absorção pelo TGI (estima-se que a quantidade máxima de ferro elementar que pode ser absorvida pelo TGI é de 25 mg/ dia; dependendo da preparação de ferro utilizada, até 1.000 mg de ferro elementar podem ser administrados numa única infusão IV). Na anemia da doença inflamatória intestinal, o ferro IV já é considerado uma opção precoce de tratamento, de acordo com algumas evidências, sendo já utilizada como primeira linha de tratamento, com ou sem intolerância à VO. Conforme diretrizes, para pacientes em quimioterapia ou em diálise, a IV é a via de preferência quando o ferro é necessário. Após cirurgias de _by‑pass_ gástrico, pelas dificuldades do estômago restante em oxidar o ferro para facilitar a absorção no duodeno e jejuno, a via IV é uma boa opção quando  
32  
Anemia por deficiência de ferro  
necessário. A dose é calculada de acordo com a necessidade do paciente, conforme fórmula descrita no esquema de administração dos fármacos. A transfusão de sangue é reservada para pacientes hemodinamicamente instáveis. (40)  
Para RN e crianças com anemia leve microcítica e diagnóstico presuntivo de ADF, a melhor conduta é dar ferro empiricamente e avaliar a resposta. Para as crianças com ADF confirmada, o sulfato ferroso é a melhor opção de tratamento com doses recomendadas de 3 a 6 mg/kg/dia de ferro elementar, dependendo da gravidade da anemia. Geralmente se indicam 3 mg/kg uma ou duas vezes ao dia até um máximo de 150 mg de ferro elementar por dia. Em 4 semanas, a Hb deve subir mais do que 1 g/dL. Para o sulfato ferroso, a quantidade de ferro elementar é em torno de 20% do sal. (41)  
Em crianças menores de 5 anos assistidas em centros públicos de saúde em uma cidade paulista, um estudo mostrou que tanto a administração semanal (30 mg/semana de ferro elementar – 40 doses) quanto a administração cíclica (dois ciclos de 20 dias de 30 mg de ferro elementar/dia, com intervalo de 4 meses – 40 doses) diminuíram de forma significativa a anemia no final de 10 meses de tratamento, sem diferença entre os grupos. A administração cíclica foi mais fácil de implementar e controlar, na opinião dos profissionais de saúde responsáveis. Ambas as formas de administração diminuíram os efeitos adversos no TGI, aumentando a aderência e diminuindo os abandonos. (17) Outro estudo de uso intermitente, fácil e barato de 25 mg de ferro elementar por semana administrados em centros públicos de saúde ou em casa se mostrou eficaz para diminuir a prevalência de ADF. (26) Outros estudos randomizados que compararam o uso de ferro via oral contínuo (diário) _versus_ uso intermitente (1, 2 ou 3 vezes na semana) em crianças de 1 a 6 anos com ADF, durante 2 a 3 meses, ou o uso três vezes ao dia (sulfato ferroso em gotas) _versus_ uma vez ao dia em crianças de 6 a 24 meses por 2 meses, concluíram que os esquemas foram eficientes e similares entre si. (42-44) Já um estudo randomizado comparativo de 3 esquemas de ferro 1 vez por semana _versus_ 2 vezes semana _versus_ diário concluiu que 2 vezes por semana é mais efetivo em resolver a anemia com menos custos e menos efeitos adversos. (3)  
Um estudo randomizado mostrou melhora significativa da taxa de crescimento com a terapia com ferro nas crianças com DF. No entanto, falhou em mostrar qualquer efeito benéfico nas crianças com reservas repletas de ferro. Ao contrário, houve significativa lentidão da taxa de crescimento destas crianças. Isto precisa ser confirmado em estudos multicêntricos com período maior de seguimento, mas, por ora, fica o alerta para o cuidado na suplementação de ferro em crianças com crescimento normal quando o _status_ de ferro não é conhecido. (1)  
Outro estudo clínico randomizado e cego incluindo 193 mulheres anêmicas em idade fértil, em comunidade de baixa renda de Recife, mostrou que a administração semanal de sulfato ferroso (60 mg de ferro elementar) é tão eficaz quanto a administração diária, com menos efeitos adversos e menores custos. A aderência foi maior no esquema semanal no primeiro mês e similar nos meses subseqüentes. (2)  
Poucos estudos publicados examinaram a relação da deficiência de ferro em mulheres em idade fértil nos aspectos cognitivos, saúde mental e fadiga. Uma revisão constatou pequena melhora na fadiga e melhora moderada nos escores de saúde mental em pacientes com DF tratadas com ferro. A maioria dos trabalhos mostrou alguma evidência de melhora nas funções cognitivas após o tratamento na área da aritmética, área pertencente à memória de trabalho. A maioria dos estudos era limitada pela duração curta da terapia, pela avaliação inadequada da aderência e pela heterogeneidade dos testes de avaliação, para poderem ser apropriadamente comparados. Um estudo randomizado controlado por placebo avaliou a relação da DF em mulheres em idade fértil submetidas à suplementação com ferro _versus_ placebo. Concluíram que o _status_ de ferro é um fator significativo no desempenho cognitivo destas mulheres, sendo que a gravidade da anemia afeta primariamente a rapidez do processo e a gravidade da DF afeta a acurácia da função cognitiva numa grande gama de tarefas. Portanto, os efeitos da DF nas funções cognitivas não estão restritos ao desenvolvimento cerebral. Mais e melhores estudos precisam ser realizados sobre este assunto para esclarecer a relação do _status_ de ferro e os aspectos cognitivos nestas pacientes. (30,35)  
Doses de 60 até 200 mg/dia de ferro devem ser reservadas para as mulheres grávidas com DF ou ADF comprovada, associadas com até 400 mcg/dia de ácido fólico, pois as necessidades de ferro aumentam mais ainda na segunda metade da gestação, especialmente no último trimestre. O ácido fólico  
33  
Protocolos Clínicos e Diretrizes Terapêuticas  
deve ser sempre fornecido em associação com o ferro durante a gestação, uma vez que as necessidades desse ácido aumentam e pelo fato de ambas as deficiências serem comuns na gestante. Além disto, a suplementação de ácido fólico antes da gestação vai impactar o _status_ materno de ácido fólico e reduzir riscos de defeitos do tubo neural da criança. A combinação parece ter benefício significativo em reduzir a anemia e a ADF, melhorando os índices hematológicos no final da gestação. (1,5) O tratamento padrão da DF na gestação é o mesmo que para as mulheres não gestantes, para o pós-parto, para a pré- e pós-menopausa. (1) O que deve ser levado em conta, particularmente com a gestante, é a sua tolerância gastrointestinal, muitas vezes comprometida pelas náusea e vômitos iniciais, pelo refluxo gastroesofágico, por estufamentos e constipação (causados pelos altos níveis de progesterona e pela pressão do útero grávido sobre o reto) e agravada ainda pelo uso do ferro. Os relatos de efeitos adversos no TGI pelas gestantes são em torno de 70% e podem ser amenizados com a administração do ferro durante a refeição ou com a diminuição da posologia, sabendo que isto prolongará o tempo de tratamento. (5,11,40)  
Um estudo clínico duplo-cego com 371 gestantes anêmicas randomizadas para receber 80 mg de ferro sem ou com 0,37 mg de ácido fólico diários por 60 dias mostrou que a combinação produziu melhor resposta terapêutica (a Hb aumentou 1,42 g/dL do início _versus_ 0,80 g/dL do tratamento apenas com ferro; p<0,001), independente de outros fatores. A suplementação com folato é recomendada em gestantes com ADF independente dos seus níveis de folato. (45)  
O uso de ferro IV (sacarato hidróxido férrico) na gestação pode, raramente, ser indicado, a partir do 2º trimestre, em casos especiais de anemia moderada a grave (Hb abaixo 9 g/dL) em que haja necessidade de correção rápida dos níveis de ferro, risco aumentado de hemorragia ou intolerância materna relevante e de anemia por outras comorbidades. Ou mesmo no final da gestação, quando não há mais tempo para o ferro oral resultar no efeito desejado e ainda se pode evitar uma transfusão de sangue no período antenatal. Mas é importante ressaltar que o uso do ferro IV na gestante é raro e que nenhuma preparação parenteral recebeu a categoria “A” do FDA (“estudos controlados em humanos não demonstraram risco”) para uso na gravidez. A administração, se indicada, deve ser feita em hospital, por infusão diluída e lenta por 30 minutos, 1 a 3 vezes por semana, respeitando intervalos de 48 horas entre as injeções e não passando de 300 mg de ferro por injeção, até repor as reservas em ferro (calculada por fórmula apresentada a seguir, na parte dos fármacos). A injeção parenteral pode ser responsável por reações anafilactoides raras, o que justifica seu uso em ambiente hospitalar. A infusão rápida pode desencadear uma crise hipertensiva pela liberação rápida do ferro da sua forma em complexo, assim como reações mais freqüentes como hipertermia, náusea, vômitos, hipotensão, broncoespasmo e reações cutâneas. O extravasamento de ferro na pele pode causar inflamação local, abscesso estéril e pigmentação definitiva. No entanto, o sacarato hidróxido férrico é muito bem tolerado durante a gestação e, diferentemente do ferro dextran, não requer dose teste antes da administração. As reações anafilactoides relatadas têm incidência de 0,002%. Portanto, como nem todas as gestantes respondem adequadamente ao tratamento oral com sulfato ferroso, o sacarato férrico IV trata a anemia moderada e grave da gravidez mais rápida e eficazmente, sem efeitos adversos graves e com boa tolerância. (5,6,40) Há estudos clínicos randomizados com gestantes que vêm mostrando as vantagens do sacarato férrico ou outros produtos IV (ferro polimaltose) como descrito acima, porém mais estudos são necessários para confirmar a magnitude dos benefícios. (46-49)  
Um estudo randomizado foi realizado em 2013 para comparar a eficácia do ferro oral _versus_ ferro IV em 100 gestantes anêmicas: diferenças na melhora da ADF, na restauração das reservas de ferro, nos desfechos obstétricos dos dois grupos e a segurança do sacarato férrico foram avaliados. A Hb encontrava-se entre 7-9 g/dL e a ferritina sérica, abaixo de 15 ng/mL. As gestantes foram randomizadas em dois grupos de 50 mulheres. O grupo A recebeu comprimidos de 200 mg de sulfato ferroso 3 vezes dia (cada um com 60 mg de ferro elementar) por 4 semanas. O grupo B recebeu sacarato férrico em doses divididas de 200 mg cada em dias alternados por infusão IV lenta. Houve diferença significativa entre os grupos no desfecho primário em 30 dias. A Hb aumentou 3,1 g/dL no grupo A _versus_ 5,1 g/dL no grupo B - p=0,002, e a ferritina subiu para 77,6±13,7 ng/mL _versus_ 104 ±13,4; p=0,005, respectivamente. O tratamento foi seguro e houve menos RN de baixo peso no grupo B. (50)  
Todavia, na maioria dos casos de anemia na gestação, o sal ferroso VO é suficiente e o tratamento de escolha para a correção da carência de ferro, sendo que as taxas de Hb sobem de forma progressiva. A absorção é favorecida pelo jejum e pelo uso concomitante de vitamina C, além da capacidade absortiva maior da própria gravidez. (5)  
O tratamento da anemia no puerpério é feito com sulfato ferroso como durante a gestação, nas doses terapêuticas. (5,51) Há estudo randomizado comparativo entre ferro oral e sacarato férrico IV em mulheres no puerpério com ADF grave (Hb abaixo de 8 g/dL) 24 horas após o parto, numa população rural da Índia, em que  
34  
Anemia por deficiência de ferro  
o ferro IV foi eficaz e seguro, com recuperação mais rápida da anemia. (52) Estudos comparativos de puérperas com ADF divididas em grupos para avaliar ferro oral _versus_ sacarato férrico IV também concluíram pela segurança e eficácia do tratamento IV, pois houve aumento da ferritina em período curto com poucos efeitos adversos. (53,54) No entanto, estudo randomizado duplo-cego e controlado por placebo envolvendo 2.014 puérperas com ADF grave (Hb de 6-8 g/dL) não chegaram à mesma conclusão. Todas as 72 mulheres recebiam sulfato ferroso (2 comprimidos de 525 mg) e eram randomizadas para receberem placebo IV ou sacarato férrico IV (200 mg/24horas por 2 dias consecutivos). Eram avaliados Hb, Ht, parâmetros clínicos e efeitos adversos. A Hb e o Ht foram comparáveis entre os grupos após seis semanas (12,2±1,0 _versus_ 12,2±0,9 g/dL, com uma diferença média de 0,03; 95%CI 0,6-0,6, no grupo placebo e no IV, respectivamente), assim como os outros parâmetros. A conclusão foi que o ferro IV acrescentado à terapia oral não mostrou benefício significativo sobre o placebo quanto a Hb, sintomas e nem efeitos adversos. (55) Mais estudos de qualidade são necessários para avaliar o uso do ferro oral e IV no tratamento da anemia pós-parto, focando nos desfechos clínicos relevantes maternos, na segurança e no uso de recursos da saúde. (32)  
Para os idosos, mais vulneráveis aos efeitos adversos do ferro, um estudo mostrou que doses bem menores que as preconizadas para adultos são eficazes para o tratamento da ADF. Doses de 15 mg de ferro elementar por dia foram administradas e eficazes para estes pacientes, evitando os efeitos indesejáveis, desde que, evidentemente, a causa da anemia, que mais frequentemente é por perda sanguínea, seja corrigida. (56)  
Existem várias condições que tornam o ferro via oral ineficaz e pobremente tolerado. Os efeitos adversos no TGI ocorrem em 50% a 70% dos pacientes, resultando em baixa aderência. Estes efeitos adversos (desconforto abdominal, constipação, diarreia, náusea, vômitos, gosto metálico na boca, fezes pretas) são diretamente proporcionais à quantidade de ferro elementar ingerida. O tratamento efetivo demora seis a oito semanas para melhorar a anemia e em torno de seis meses para repor as reservas de ferro. (40)  
Em revisão de 2011, o risco aumentado de malária devido à suplementação de ferro foi descartado. Pensava-se que o ferro livre circulante em crianças tratadas em áreas com alta prevalência de malária ficaria à disposição do parasita, favorecendo seu crescimento. Este estudo mostrou que o tratamento isolado com ferro (sem ácido fólico) ou combinado com antimaláricos não aumentou o risco de malária clínica ou de morte em crianças com ou sem anemia, nessas áreas endêmicas em que a vigilância da doença era regular e o tratamento fornecido, assim como não aumentou o risco de outras infecções. (57) A maior aderência ao tratamento da anemia melhora os desfechos para a saúde em crianças que vivem em áreas de malária endêmica. (58) Um estudo clínico randomizado foi realizado na Tanzânia, em região de malária endêmica, para avaliar se o tratamento da anemia com dois esquemas de ferro (dose baixa de ferro como suplemento com lactato de ferro 2,5 mg mais composto férrico-EDTA 2,5 mg) _versus_ esquema padrão (dose alta com lactato ferroso 10 mg) era tão eficaz para corrigir a anemia de crianças com idade menor que 5 anos e para determinar se o tratamento aumentava o risco de malária. A conclusão foi que o tratamento com baixas doses de ferro podem ser usados com segurança em áreas de malária endêmica para corrigir a ADF, diminuindo os efeitos adversos do ferro em dose mais alta e que a presença de parasitemia por malária permaneceu constante, sem aumento da prevalência da doença durante o tratamento da anemia. A avaliação de rotina de trofozoítas no sangue e o tratamento imediato da malária ao primeiro sinal de febre são medidas suficientes para prevenir complicações graves da doença. A OMS recomenda que programas de controle de anemia em áreas como essa, sejam concomitantemente acompanhados por programas de controle da malária. (59)  
Estudos mais antigos haviam mostrado que a suplementação de ferro melhorava de forma impactante os níveis de deficiência de ferro e de anemia sem evidência de aumento de risco de malária. (60) Um estudo randomizado com crianças de campo de refugiados na Tanzânia comparou três diferentes esquemas de tratamento para ADF em zona endêmica para malária, concluindo que o tratamento inicial para malária e helmintos seguido de ferro três vezes por semana mais ácido fólico resultou em aumento dos níveis de hemoglobina; que o uso de sulfametoxazol-pirimetamina mensal mais vitaminas A e C três vezes por semana contribui para melhorar as reservas de ferro; e que o uso de sulfametoxazol-pirimetamina mensal acelera a recuperação das reservas de ferro, presumivelmente  
35  
Protocolos Clínicos e Diretrizes Terapêuticas  
por prevenir a infecção por malária, sendo importante onde a doença assintomática é prevalente ou o acesso aos cuidados é limitado. (61)  
Para o tratamento da ADF na doença renal crônica, ver o PCDT específico.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.3 FÁRMACOS** -->
Uso interno (via oral, VO):  
- Sulfato Ferroso - 40 mg de ferro elementar por comprimido  
- Sulfato Ferroso - 25 mg/mL de ferro elementar em solução oral  
- Sulfato Ferroso - 5 mg/ mL de ferro elementar em xarope  
Uso intravenoso (IV):  
- Sacarato de hidróxido férrico 100 mg de ferro injetável, frasco-ampola de 5 mL

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.4 ESQUEMAS DE ADMINISTRAÇÃO** -->
As doses terapêuticas usuais dos medicamentos preconizados neste Protocolo são:

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.4 ESQUEMAS DE ADMINISTRAÇÃO** -->
- crianças: 3 a 6 mg/kg/dia de ferro elementar, sem ultrapassar 60 mg/dia.  
- gestantes: 60 a 200 mg/dia de ferro elementar associadas a 400 mcg/dia de ácido fólico.  
- adultos: 120 mg/dia de ferro elementar.  
- idosos: 15 mg/dia de ferro elementar.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.4 ESQUEMAS DE ADMINISTRAÇÃO** -->
Fórmula para cálculo da dose total IV de ferro a ser administrada:  
Ferro (mg) = (Hb desejada conforme sexo e idade do paciente – Hb atual em g/dL) x Peso corporal (kg) x 2,4 + 500 mg  
A dose deve ser administrada em hospital, em infusão IV lenta, por 30 minutos, de uma a três vezes na semana, com intervalos mínimos de 48 horas e não ultrapassando 300 mg em cada dose.  
Para as gestantes o peso corporal deve ser o de antes da gestação. (47)

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.5 TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO** -->
O tratamento da ADF deverá ser por 6 meses após a Hb ter normalizado, que é o tempo necessário para repor as reservas de ferro do organismo. (40)

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8.6 BENEFÍCIOS ESPERADOS** -->
O objetivo principal da terapia é melhorar os sintomas e, na sequência, melhorar os parâmetros hematológicos e os biomarcadores do ferro. O paciente notará uma sensação de bem-estar nos primeiros dias do tratamento e o desaparecimento de sintomas mais intensos como a pica ou a síndrome das pernas inquietas. Uma reticulocitose discreta pode ser vista nos primeiros dias do tratamento, e a Hb aumenta lentamente em uma a duas semanas, chegando a um aumento de 2 g/dL em três semanas. O déficit vai diminuir à metade em aproximadamente quatro semanas e normalizar em seis a oito semanas, se não houver perda sanguínea associada. Clinicamente, há reconstituição das papilas linguais ao longo do processo de cura da DF, em semanas a meses. As reservas de ferro serão repostas ao longo de seis meses do tratamento. O objetivo é manter os pacientes com uma vida produtiva, minimizando ao máximo os efeitos adversos do medicamento em uso. (40)

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **9 MONITORIZAÇÃO** -->
A monitorização deve ser feita através da vigilância dos sintomas e da hemoglobina com intervalos de  
8 semanas e da ferritina a cada 3 meses. (41)  
Para as gestantes o controle de hemograma deve ser feito a cada 4 semanas. A ferritina deve ser realizada no final do sexto mês e no final da gestação. (5)  
36  
Anemia por deficiência de ferro

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **10 ACOMPANHAMENTO PÓS-TRATAMENTO** -->
Todos os pacientes deverão passar por consultas clínicas de rotina, no mínimo a cada oito semanas, para acompanhamento da sua doença. Na gestação, o ideal são consultas com intervalo de três a quatro semanas.  
Todos deverão ser acompanhados para a verificação da aderência ao tratamento e da avaliação dos efeitos adversos do ferro de uso VO ou IV.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **11 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso dos medicamentos e do acompanhamento pós-tratamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **12 ESCLARECIMENTO E RESPONSABILIDADE** -->
É obrigatório cientificar o paciente, ou seu responsável legal, sobre potenciais riscos, benefícios e efeitos colaterais relacionados ao uso dos medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **13 REFERÊNCIAS BIBLIOGRÁFICAS** -->
1. World, Health, Organisation. Iron Deficiency Anaemia - Assessment, Prevention and Control. A guide for programme managers. World Health Organisation: WHO/NHD/01.3; 2001.  
2. Lopes MC, Ferreira LO, Batista Filho M. [Use of daily and weekly ferrous sulfate to treat anemic childbearing-age women]. Cad Saude Publica. 1999;15(4):799-808.  
3. Hawamdeh HM, Rawashdeh M, Aughsteen AA. Comparison between once weekly, twice weekly, and daily oral iron therapy in Jordanian children suffering from iron deficiency anemia. Matern Child Health J. 2013;17(2):368-73.  
4. Schrier SL. Causes and diagnosis of iron deficiency anemia in the adult. UpToDate [Internet]. 2014.  
5. Beucher G, Grossetti E, Simonet T, Leporrier M, Dreyfus M. [Iron deficiency anemia and pregnancy. Prevention and treatment]. J Gynecol Obstet Biol Reprod (Paris). 2011;40(3):185-200.  
6. Gupta A, Manaktala U, Rathore AM. A randomised controlled trial to compare intravenous iron sucrose and oral iron in treatment of iron deficiency anemia in pregnancy. Indian J Hematol Blood Transfus. 2014;30(2):120-5.  
7. Noronha JA, Al Khasawneh E, al. E. Anemia in Pregnancy - Consequences and Challenges: A Review of Literature. Journal of South Asian Federation of Obstetrics and Gynecology. 2012;4(1):64-70.  
8. Logan EC, Yates JM, Stewart RM, Fielding K, Kendrick D. Investigation and management of iron deficiency anaemia in general practice: a cluster randomised controlled trial of a simple management prompt. Postgrad Med J. 2002;78(923):533-7.  
9. Berber I, Diri H, Erkurt MA, Aydogdu I, Kaya E, Kuku I. Evaluation of ferric and ferrous iron therapies in women with iron deficiency anaemia. Adv Hematol. 2014;2014:297057.  
10. Haider BA, Olofin I, Wang M, Spiegelman D, Ezzati M, Fawzi WW, et al. Anaemia, prenatal iron use, and risk of adverse pregnancy outcomes: systematic review and meta-analysis. BMJ. 2013;346:f3443.  
11. Reveiz L, Gyte GM, Cuervo LG, Casasbuenas A. Treatments for iron-deficiency anaemia in pregnancy. Cochrane Database Syst Rev. 2011(10):CD003094.  
12. Saúde. BMdSSdAà. Política Nacional de Alimentação e Nutrição. In: Básica. DdA, editor.: Ministério da Saúde. Brasília - DF.; 2012. p. 84 p.  
13. Jordão RE, Bernardi JL, Barros Filho AdA. Prevalência de anemia ferropriva no Brasil: uma revisão sistemática. Rev Paul Pediatr. 2009;27(1):90-8.  
14. Silva RC, Ferreira HdS. Prevalência da anemia em crianças brasileiras, segundo diferentes cenários epidemiológicos. Rev NutrCampinas. 2010;23(3):433-44.  
15. Vieira ACF, Diniz AS, Cabral PC, Oliveira RS, Lola MMF, Silva SMM. Nutritional assessment of iron status and anemia in children under 5 years old at public day care centers. J Pediatric (Rio J). 2007;83(4):370-6.  
37  
Protocolos Clínicos e Diretrizes Terapêuticas  
16. Hadler MC, Sigulem DM, Alves MeF, Torres VM. Treatment and prevention of anemia with ferrous sulfate plus folic acid in children attending daycare centers in Goiânia, Goiás State, Brazil: a randomized controlled trial. Cad Saude Publica. 2008;24 Suppl 2:S259-71.  
17. Coutinho GG, Cury PM, Cordeiro JA. Cyclical iron supplementation to reduce anemia among Brazilian preschoolers: a randomized controlled trial. BMC Public Health. 2013;13:21.  
18. Ferraz IS, Daneluzzi JC, Vannucchi H, Jordão AA, Ricco RG, L.A. DC. Prevalência da carência de ferro e sua associação com a deficiência de vitamina A em pré-escolares. (Porto Alegre). J Pediatr (Rio J). 2005;81(2):169-74.  
19. Assunção MC, Santos IS, Barros AJ, Gigante DP, Vitora CG. Effect of iron fortification of flour on anemia in preschool children in Pelotas. Brazil: Rev Saude Publica. 2007;41st edition:539-48.  
20. Silla LM, Zelmanowicz A, Mito I, Michalowski M, Hellwing T, Shilling MA, et al. High prevalence of anemia in children and adult women in an urban population in southern Brazil. PLoS One. 2013;8(7):e68805.  
21. Murray-Kolb LE, Beard JL. Iron deficiency and child and maternal health. Am J Clin Nutr. 2009;89(3):946S-50S.  
22. Beard JL, Hendricks MK, Perez EM, Murray-Kolb LE, Berg A, Vernon-Feagans L, et al. Maternal iron deficiency anemia affects postpartum emotions and cognition. J Nutr. 2005;135(2):267-72.  
23. Perez EM, Hendricks MK, Beard JL, Murray-Kolb LE, Berg A, Tomlinson M, et al. Mother-infant interactions and infant development are altered by maternal iron deficiency anemia. J Nutr. 2005;135(4):850-5.  
24. Taylor TA, Kennedy KA. Randomized trial of iron supplementation versus routine iron intake in VLBW infants. Pediatrics. 2013;131(2):e433-8.  
25. Thompson J, Biggs BA, Pasricha SR. Effects of daily iron supplementation in 2- to 5-year-old children: systematic review and meta-analysis. Pediatrics. 2013;131(4):739-53.  
26. Coutinho GG, Goloni-Bertollo EM, Pavarino-Bertelli EC. Effectiveness of two programs of intermittent ferrous supplementation for treating iron-deficiency anemia in infants: randomized clinical trial. Sao Paulo Med J. 2008;126(6):314-8.  
27. Lozoff B, Wolf AW, Jimenez E. Iron-deficiency anemia and infant development: effects of extended oral iron therapy. J Pediatr. 1996;129(3):382-9.  
28. Wang B, Zhan S, Gong T, Lee L. Iron therapy for improving psychomotor development and cognitive function in children under the age of three with iron deficiency anaemia. The Cochrane Library [Internet]. 2014; (7).  
29. Price EA, Schrier SL. Anemia in the older adult. UpToDate [Internet]. 2014.  
30. Murray-Kolb LE, Beard JL. Iron treatment normalizes cognitive functioning in young women. Am J Clin Nutr. 2007;85(3):778-87.  
31. Saúde. BMdSSdAà. Programa Nacional de Suplementação de Ferro. Manual de Condutas Gerais. In: Básica. DdA, editor.: Ministério da Saúde. Brasília - DF.; 2013. p. 24 p.:il.  
32. Dodd JM, Dare MR, Middleton P. Treatment for woman with postpartum iron deficiency anaemia. The Cochrane Library [Internet]. 2014; (7).  
33. World HO. Haemoglobin concentrations for the diagnosis of anaemia and assessment of severity. Vitamin and Mineral Nutrition Information System. http://www.who.int/vmnis/indicators/haemoglobin.pdf, accessed [date]: Geneva, World Health Organization, 2011 (WHO/NMH/NHD/MNM/11.1); 2011.  
34. Mahoney DH. Iron deficiency in infants and young children: Screening, prevention, clinical manifestations, and diagnosis. UpToDate [Internet]. 2014.  
35. Greig AJ, Patterson AJ, Collins CE, Chalmers KA. Iron deficiency, cognition, mental health and fatigue in women of childbearing age: a systematic review. Journal of Nutritional Science. 2013;2(14):1-14.  
36. Casgrain A, Collings R, Harvey LJ, Hooper L, Fairweather-Tait SJ. Effect of iron intake on iron status: a systematic review and meta-analysis of randomized controlled trials. Am J Clin Nutr. 2012;96(4):768-80.  
37. Ginder GD. Microcytic and hypochromic anemias. 24th Edition ed. Goldman's Cecil medicine2012. 6 p.  
38. Wenzhen Y, Yumin L, Kehu Y, Bin M, Quanlin G, Donghai W, et al. Iron deficient anemia in Helicobacter pylori infection: meta-analysis of randomized controlled trials. Scandinavian Journal of Gastroenterology. 2010;45:665-76.  
39. Lee TW, Kolber MR, Fedorak RN, van Zanten SV. Iron replacement therapy in inflammatory bowel disease patients with iron deficiency anemia: a systematic review and meta-analysis. J Crohns Colitis. 2012;6(3):267-75.  
40. Schrier SL, Auerbach M. Treatment of the adult with iron deficiente anemia. UpToDate [Internet]. 2014.  
41. Mahoney DH. Iron deficiency anemia in infants and Young children: Treatment. UpToDate [Internet]. 2014.  
42. Hafeez A, Ahmad P. Iron deficiency anaemia: continuous versus intermittent treatment in anaemic children. J Pak Med Assoc. 1998;48(9):269-72.  
43. Zlotkin S, Arthur P, Antwi KY, Yeung G. Randomized, controlled trial of single versus 3-times-daily ferrous sulfate drops  
38  
Anemia por deficiência de ferro  
for treatment of anemia. Pediatrics. 2001;108(3):613-6.  
44. Faqih AM, Kakish SB, Izzat M. Effectiveness of intermittent iron treatment of two- to six-year-old Jordanian children with iron-deficiency anemia. Food Nutr Bull. 2006;27(3):220-7.  
45. Juarez-Vazquez J, Bonizzoni E, Scotti A. Iron plus folate is more effective than iron alone in the treatment of iron deficiency anaemia in pregnancy: a randomised, double blind clinical trial. BJOG. 2002;109(9):1009-14.  
46. Abhilashini GD, Sagili H, Reddi R. Intravenous iron sucrose and oral iron for the treatment of iron deficiency anaemia in pregnancy. J Clin Diagn Res. 2014;8(5):OC04-7.  
47. Bayoumeu F, Subiran-Buisset C, Baka NE, Legagneur H, Monnier-Barbarino P, Laxenaire MC. Iron therapy in iron deficiency anemia in pregnancy: intravenous route versus oral route. Am J Obstet Gynecol. 2002;186(3):518-22.  
48. Al RA, Unlubilgin E, Kandemir O, Yalvac S, Cakir L, Haberal A. Intravenous versus oral iron for treatment of anemia in pregnancy: a randomized trial. Obstet Gynecol. 2005;106(6):1335-40.  
49. Khalafallah A, Dennis A, Bates J, Bates G, Robertson IK, Smith L, et al. A prospective randomized, controlled trial of intravenous versus oral iron for moderate iron deficiency anaemia of pregnancy. J Intern Med. 2010;268(3):286-95.  
50. Kochhar PK, Kaundal A, Ghosh P. Intravenous iron sucrose versus oral iron in treatment of iron deficiency anemia in pregnancy: a randomized clinical trial. J Obstet Gynaecol Res. 2013;39(2):504-10.  
51. Daniilidis A, Giannoulis C, Pantelis A, Tantanasis T, Dinas K. Total infusion of low molecular weight iron-dextran for treating postpartum anemia. Clin Exp Obstet Gynecol. 2011;38(2):159-61.  
52. Verma S, Inamdar S, Malhotra N. Intravenous Iron Therapy versus Oral Iron in Postpartum Patients in Rural Area. Journal of South Asian Federation of Obstetrics and Gynaecology. 2011;3(2):67-70.  
53. Dede A, Uygur D, Yilmaz B, Mungan T, Uğur M. Intravenous iron sucrose complex vs. oral ferrous sulfate for postpartum iron deficiency anemia. Int J Gynaecol Obstet. 2005;90(3):238-9.  
54. Bhandal N, Russell R. Intravenous versus oral iron therapy for postpartum anaemia. BJOG. 2006;113(11):1248-52. 55. Perelló MF, Coloma JL, Masoller N, Esteve J, Palacio M. Intravenous ferrous sucrose versus placebo in addition to oral iron therapy for the treatment of severe postpartum anaemia: a randomised controlled trial. BJOG. 2014;121(6):706-13.  
56. Rimon E, Kagansky N, Kagansky M, Mechnick L, Mashiah T, Namir M, et al. Are we giving too much iron? Low-dose iron therapy is effective in octogenarians. Am J Med. 2005;118(10):1142-7.  
57. Okebe JU, Yahav D, Shbita R, Paul M. Oral iron supplements for children in malaria-endemic areas. Cochrane Database Syst Rev. 2011(10):CD006589.  
58. Schellenberg D, Kahigwa E, Sanz S, Aponte JJ, Mshinda H, Alonso P, et al. A randomized comparison of two anemia treatment regimens in Tanzanian children. Am J Trop Med Hyg. 2004;71(4):428-33.  
59. Mosha TCE, Laswai HH, Assey J, Bennink MR. Efficacy of low-dose ferric-EDTA in reducing iron deficiency anaemia among underfive children living in malaria-holoendemic district of Mvomero, Tanzania. Tanzania Journal of Health Research. 2014;16(2):1-10.  
60. Verhoef H, West CE, Nzyuko SM, de Vogel S, van der Valk R, Wanga MA, et al. Intermittent administration of iron and sulfadoxine-pyrimethamine to control anaemia in Kenyan children: a randomised controlled trial. Lancet. 2002;360(9337):908-14.  
61. Tomashek KM, Woodruff BA, Gotway CA, Bloland P, Mbaruku G. Randomized intervention study comparing several regimens for the treatment of moderate anemia among refugee children in Kigoma Region, Tanzania. Am J Trop Med Hyg. 2001;64(3-4):164-71.  
39  
Protocolos Clínicos e Diretrizes Terapêuticas  
**FluxogrAmA de trAtAmento AnemiA por deFiciênciA de Ferro**  
<!-- Start of picture text -->
Paciente com diagnóstico de anemia por<br>deficiência de ferro Diagnóstico : clínico + laboratorial<br>Considerar condutas não<br>Critérios de inclusão:<br>medicamentosas, conforme PCDT<br> crianças entre 6 e 59 meses<br>com Hb abaixo de 11 g/dL<br> crianças entre 5 e 11 anos<br>Possui critérios<br>com Hb abaixo de  11,5 g/dL<br>de inclusão?<br>Não Sim  crianças entre 12 e 14 anos<br>com Hb abaixo de 12 g/dL<br> gestantes com Hb abaixo de<br>11 g/dL<br>Exclusão  Sim Possui critérios   adultos masculinos com Hb<br>do PCDT de exclusão*? Não abaixo de 13 g/dL<br> idosos masculinos brancos<br>com Hb abaixo de 13,2 g/dL<br>Paciente   idosos masculinos negros com<br>Não hemodinamicamente instável? Sim  adultas femininas com Hb Hb abaixo de 12,7 g/dL<br>abaixo de 12 g/dL<br> idosas femininas brancas com<br>Hb abaixo de 12,2 g/dL<br>Sim Gestante? Transfusão de   idosas femininas negras com<br>sangue Hb abaixo de 11,5 g/dL  e<br> ferritina abaixo de 30 ng/mL<br>ou  pacientes com doenças<br>Utilizar ferro associado  inflamatórias, infecciosas,<br>ao ácido fólico malignas ou hepáticas que<br>Não tenham Hb baixa para sua<br>idade e gênero, cujo valor da<br>ferritina dividido por 3 seja<br>abaixo ou igual a 20 ng/mL<br>Dose necessária de ferro é superior a<br>25 mg/dia, caso de doença<br>inflamatória intestinal, tratamento<br>* Critérios de exclusão:<br>quimioterápico, diálise, realização de<br>Não  pacientes que apresentarem<br>cirurgia de  by-pass  gástrico ou casos<br>hipersensibilidade a qualquer<br>especiais em gestantes**?<br>Sim formulação de ferro<br>preconizada no Protocolo<br>Sulfato ferroso<br>Apresenta intolerância<br>Sacarato de<br>hidróxido férrico  Sim absoluta (náuseas e<br>vômitos incoercíveis)? Não<br>Refratário ao tratamento<br>Não<br>após 8 semanas?<br>Sim<br>Tratamento por 6 meses após<br>Sacarato de hidróxido férrico<br>normalização da Hb<br>Investigar infecção por<br>Monitorizar resposta, adesão ao<br>tratamento e efeitos adversos Helicobacter pylori<br><!-- End of picture text -->  
** Serão considerados casos especiais, a partir do 2º trimestre de gestação, casos de anemia moderada a grave (Hb abaixo de 9 g/dL) em que haja necessidade de correção rápida dos níveis de ferro, risco aumentado de hemorragia ou intolerância materna relevante e de anemia por outras comorbidades. Ou em caso de final da gestação, quando não há mais tempo para o ferro oral resultar no efeito desejado e que seja possível evitar uma transfusão de sangue no período antenatal.  
40  
Anemia por deficiência de ferro  
**FluxogrAmA de dispensAção de sulFAto Ferroso AnemiA por deFiciênciA de Ferro**  
<!-- Start of picture text -->
Paciente solicita o  CID-10:  D50.0 e D50.8<br>medicamento<br>Dose:<br>  Sulfato ferroso:<br>- Crianças: 3 - 6 mg/kg/dia de ferro<br>elementar, até o limite de 60 mg/dia, VO<br>- Gestantes: 60 - 200 mg/dia de ferro<br>elementar associado a 400 mcg/dia de ácido<br>Possui receita médica  fólico, VO<br>atual e a dose está de  - Adultos: 120 mg/dia de ferro elementar, VO<br>- Idosos: 15 mg/dia de ferro elementar, VO<br>Não acordo com o PCDT? Sim<br>Orientar o  Realizar entrevista<br>paciente farmacoterapêutica inicial<br>com o farmacêutico<br>Orientar o<br>paciente<br>Dispensação a cada mês de<br>tratamento<br>Entrevista<br>farmacoterapêutica de<br>monitorização<br>Paciente apresentou eventos<br>Sim adversos significativos? Não<br>Dispensar e solicitar<br>Dispensar<br>parecer do médico<br>assistente<br><!-- End of picture text -->  
41  
Protocolos Clínicos e Diretrizes Terapêuticas  
**FichA FArmAcoterApêuticA AnemiA por deFiciênciA de Ferro**  
|**1**<br>**DADOS DO PACIENTE**<br>Nome: _________________________________________|_______________________________________________|
|---|---|
|CNS:________________________________________|_____RG:_____________________________________|
|DN: ___/___/____  Idade: _________  Peso: ____|_________Altura: ___________ Sexo:oFoM|
|Endereço:___________________________________|_____________________________________________|
|Telefones:___________________________________|____________________________________________|
|Médico assistente: _____________________________|_______________________  CRM:________________|
|Telefones: ______________________________________|_______________________________________________|
|Nome do cuidador: __________________________|_____________________________________________|
|Cartão Nacional de Saúde: _____________________|____________ RG:_____________________________|
|**2**<br>**AVALIAÇÃO FARMACOTERAPÊUTICA**||  
|2.1 Qual o tipo de alimentação que costuma ingerir?|
|---|
|Café da manhã<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________|
|_________________________________________________________________________________________<br>Almoço<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________|
|_________________________________________________________________________________________<br>Janta<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________|
|_________________________________________________________________________________________<br>*Os alimentos fontes de ferro devem ser recomendados, principalmente as carnes vermelhas, vísceras (fígado e miúdos), carnes de aves, peixes e hortaliças<br>verde-escuras, entre outros. Para melhorar a absorção do ferro, recomenda-se a ingestão de alimentos ricos em vitamina C, disponível nas frutas cítricas, como<br>laranja, acerola e limão, evitando-se excessos de chá ou café, que dificultam esta absorção.|
|2.2 Possui outras doenças diagnosticadas?|
|osim → Quais? __________________________________________________________|
|onão|
|2.3 Faz uso de outros medicamentos?<br>|
|onão|
|osim → Preencher Tabela de Uso de Medicamentos – Anexo I|
|2.4 Já apresentou reações alérgicas a medicamentos?|
|osim → Quais? A que medicamentos?________________________________________<br>onão|  
42  
Anemia por deficiência de ferro

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **3 MONITORIZAÇÃO DO TRATAMENTO** -->
||**Inicial**|**8°sem**|**16°sem**|**24°sem**|**32°sem**|**40°sem**|**48°sem**|**56°sem**|
|---|---|---|---|---|---|---|---|---|
|Dataprevista|||||||||
|Data realizada|||||||||
|Hemoglobina|||||||||
||**Inicial**||**3°mês**|**6°m**|**ês**|**9°mês**|**1**|**2°mês**|
|Dataprevista|||||||||
|Data realizada|||||||||
|Ferritina|||||||||  
Obs.: para as gestantes o controle de hemograma deve ser feito a cada 4 semanas. A ferritina deve ser realizada no final do sexto mês e no final da gestação.  
3.1 Na segunda dispensação: anemia grave por deficiência de ferro, refratária ao tratamento após 8 semanas?  
sim → Dispensar e encaminhar o paciente ao médico assistente, pois deve ser investigado se há a infecção pelo _Helicobacter pylori_ . (utilizar Carta-Modelo – Anexo III)  
não → Dispensar  
3.2 Houve melhora nos valores de hemoglobina e ferritina? sim → Dispensar  
não → Dispensar e encaminhar o paciente ao médico assistente para revisão do plano terapêutico (utilizar Carta-Modelo – Anexo III)  
3.3 Na sétima dispensação: houve correção nos valores de hemoglobina e ferritina?  
sim → Dispensar por mais 6 meses.  
não → Dispensar e encaminhar o paciente ao médico assistente para revisão do plano terapêutico (utilizar Carta-Modelo – Anexo III)  
3.4 Apresentou sintomas que indiquem eventos adversos?  
não → Dispensar  
sim → Preencher Tabela de Eventos Adversos – Anexo II. Passar para a pergunta 3.4.1  
3.4.1 Evento adverso necessita de avaliação do médico assistente?  
não → Dispensar  
sim → Dispensar e encaminhar o paciente ao médico assistente (utilizar Carta-Modelo – Anexo III)  
3.5 Desde a última dispensação houve alteração no uso de medicamento (novos, suspensões, trocas de medicamentos/posologia)?  
não  
sim → Preencher Tabela de Uso de Medicamentos – Anexo I  
Obs.: ao final da entrevista farmacoterapêutica preencher Ficha de Registro de Evolução Farmacêutica  
– Anexo IV. Ao final da dispensação preencher Tabela de Registro da Dispensação – Anexo V  
43  
Protocolos Clínicos e Diretrizes Terapêuticas  
**guiA de orientAção Ao pAciente**  
**sulFAto Ferroso pArA AnemiA por deFiciênciA de Ferro**  
EstE é um guia quE contEm oriEntaçõEs sobrE sua doEnça E o mEdicamEnto quE você Está rEcEbEndo gratuitamEntE pElo sus.  
sEguindo as oriEntaçõEs, você tErá mais chancE dE sE bEnEficiar com o tratamEnto.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **1 DOENÇA** -->
- A anemia por deficiência de ferro é uma condição na qual o organismo não possui ferro suficiente para produzir as células vermelhas do sangue em quantidade adequada.  
- Caracteriza-se por cansaço, fraqueza, boca seca, síndrome das pernas inquietas, vontade de comer papel, terra, gelo, entre outros.  
- As causas dessa condição são muitas, desde a alimentação pobre em ferro, perdas de sangue, gravidez até outras doenças. Ela pode ser corrigida com alimentação rica em ferro, bem como, quando indicada, uso de suplementos à base de ferro.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **2 MEDICAMENTO** -->
- Este medicamento leva à cura da anemia, eliminando os sintomas associados.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **3 GUARDA DO MEDICAMENTO** -->
- Guarde o medicamento protegido do calor, ou seja, evite lugares onde exista variação da temperatura (cozinha e banheiro).  
- Conserve o medicamento na embalagem original, bem fechado.  
- Mantenha o medicamento fora do alcance das crianças.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **4 ADMINISTRAÇÃO DO MEDICAMENTO** -->
- Tome os comprimidos, com ajuda de água ou suco de frutas, de preferência 1h antes ou 2h após as refeições para um melhor efeito do medicamento. Entretanto, se não é bem tolerado, para diminuir os sintomas desagradáveis que possam ocorrer, também poderá ser tomado junto às refeições.  
- A solução oral e o xarope podem ser tomados puros, junto ou após as refeições.  
- O medicamento também não deve ser tomado com alguns medicamentos como antiácidos (sais de alumínio, magnésio), bloqueadores da bomba de prótons (omeprazol, pantoprazol), bebidas e suplementos com cálcio, alguns antibióticos, leite e ovos.  
- Tome exatamente a dose prescrita nos dias que o médico indicou, estabelecendo um mesmo horário. Em caso de esquecimento de uma dose, tome-a assim que lembrar. Não tome a dose em dobro para compensar a que foi esquecida.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **5 REAÇÕES DESAGRADÁVEIS** -->
- Apesar dos benefícios que o medicamento pode trazer, é possível que apareçam algumas reações desagradáveis, tais como náuseas, vômitos, diarreia, constipação, fezes escuras, entre outros.  
- Se houver algum destes ou outros sinais/sintomas, comunique-se com o médico ou farmacêutico.  
- Maiores informações sobre reações adversas constam no Termo de Esclarecimento e Responsabilidade, documento assinado por você ou pelo responsável legal e pelo médico.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **6 USO DE OUTROS MEDICAMENTOS** -->
- Não faça uso de outros medicamentos sem o conhecimento do médico ou orientação de um profissional de saúde.  
44  
Anemia por deficiência de ferro

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **7 REALIZAÇÃO DOS EXAMES DE LABORATÓRIO** -->
- A realização dos exames garante uma correta avaliação sobre o que o medicamento está fazendo no seu organismo. Em alguns casos pode ser necessário ajustar a dose ou até interromper o tratamento.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **8 OUTRAS INFORMAÇÕES IMPORTANTES** -->
- Devem ser ingeridos alimentos ricos em ferro, tais como carnes vermelhas, vísceras (fígado e miúdos), carnes de aves, peixes e hortaliças verde-escuras, entre outros.  
- Para melhorar a absorção do ferro, recomenda-se a ingestão de alimentos ricos em vitamina C, disponível na laranja, acerola e limão, e deve-se evitar tomar grandes quantidades de chá ou café, que dificultam sua absorção.  
- Durante o tratamento com ferro é normal ocorrer um escurecimento das fezes.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **9 EM CASO DE DÚVIDAS** -->
- Se você tiver qualquer dúvida que não esteja esclarecida neste guia, antes de tomar qualquer atitude, procure orientação com o médico ou farmacêutico do SUS.

---

<!-- METADADOS: doenca: Anemia Deficiencia de Ferro | secao: **10 OUTRAS INFORMAÇÕES** -->
_________________________________________________________________________________ _________________________________________________________________________________ _________________________________________________________________________________ _________________________________________________________________________________ _________________________________________________________________________________  
sE, por algum motivo, não usar o mEdicamEnto,  
dEvolva‑o à farmácia do sus.  
45  
Protocolos Clínicos e Diretrizes Terapêuticas  
46

---

