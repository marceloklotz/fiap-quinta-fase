<!-- METADADOS: doenca: Mesotelioma Pleural | secao: Geral -->
<!-- Start of picture text -->
ae<br>ga”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 18, DE 23 DE NOVEMBRO DE 2020.  
Aprova as Diretrizes Brasileiras para o Diagnóstico do Mesotelioma Maligno de Pleura.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem diretrizes nacionais para diagnóstico do mesotelioma maligno de pleura;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 534/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 542 – Julho de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Ficam aprovadas as Diretrizes Brasileiras para o Diagnóstico do Mesotelioma Maligno de Pleura.  
Parágrafo único.  As diretrizes objeto deste artigo, que contêm o conceito geral do mesotelioma maligno de pleura, critérios de diagnóstico, de inclusão e de exclusão e mecanismos de regulação, controle e avaliação, disponíveis no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, são de caráter nacional e devem ser</u> utilizadas pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso dos procedimentos preconizados para o diagnóstico do mesotelioma maligno de pleura.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença  
em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
LUIZ OTAVIO FRANCO DUARTE  
HÉLIO ANGOTTI NETO  
ANEXO

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **1. INTRODUÇÃO** -->
O mesotelioma maligno da pleura (MMP) é um câncer associado à exposição ocupacional e ambiental a fibras de asbesto (conhecido também como amianto) e outras fibras minerais alongadas, tais como a erionita e a fluoro-edenita<sup>1</sup> . O MMP é considerado como a “impressão digital” da utilização do asbesto numa determinada sociedade<sup>2</sup> .  
A incidência basal da doença é estimada em 1 a 2 casos/1.000.000 de habitantes em sociedades em que não há produção ou consumo de asbesto<sup>3</sup> . A mortalidade do MMP é próxima à sua incidência<sup>4</sup> . Sua maior incidência/mortalidade ocorre em países da Europa Ocidental, notadamente na Grã-Bretanha e Itália, assim como no Japão, Austrália e EUA, enquanto que países em industrialização e alto consumo da fibra os dados são escassos e inconsistentes<sup>5</sup> . Homens apresentam, em média, três vezes mais casos que mulheres<sup>6</sup> , pois, a chance de exposição ocupacional ao asbesto se dá em atividades predominantemente masculinas. Porém, há uma variação na relação de gêneros, dependendo da estrutura das atividades econômicas em diferentes países e, da chance de exposição ambiental da população<sup>7</sup> . Estima-se que as exposições ambientais, excetuandose as exposições domésticas, são responsáveis por 14% e 62% dos casos de MMP em homens e mulheres, respectivamente<sup>8</sup> .  
O Brasil é um grande produtor e consumidor da fibra. Entre 1961 e 2014 foram produzidas mais de 8.000.000 de toneladas de asbesto<sup>9,10</sup> . Neste período o consumo interno aparente foi próximo a 7.000.000 de toneladas. Pedra e colaboradores analisaram óbitos ocorridos entre 1980 e 2003 cuja causa básica foi codificada até 1995 com o código CID-9 163 e, a partir de 1996, com os códigos CID-10 C45 somado a C38.4, em todas as faixas etárias<sup>11</sup> . Neste período, a mortalidade cresceu de 0,56/1.000.000 para 1,01/1.000.000, correspondendo a um aumento de 80,4%. Algranti e colaboradores analisando óbitos ocorridos entre 2000 e 2012 em adultos de 30 anos ou mais, cuja causa básica foi codificada como C45, incluídas localizações extrapleurais, demonstraram que as taxas de mortalidade padronizada variaram de 0,7 a 1,0/1.000.000 no país, e de 1,0 a 2,1/1.000.000 no estado de São Paulo<sup>12</sup> . A relação homem/mulher foi de 1,4, e 77,1% dos  
casos eram de MMP (C45.0) e Mesotelioma não especificado (C45.9)<sup>12</sup> . Comparativamente, na Argentina, onde o uso de asbesto foi cerca de 20 vezes inferior ao do Brasil, a mortalidade por Mesotelioma variou de 3.04/1,000,000 em 1980 para 5.62/1,000,000 em 2013, em indivíduos de 15 anos ou mais<sup>13</sup> . Entretanto, mesmo com números inexpressivos, é possível detectar-se no estado de São Paulo uma tendência significativa de aumento da taxa padronizada de mortalidade, assim como _clusters_ da doença em munícipios que fizeram uso intensivo da fibra nas últimas décadas<sup>12</sup> .  
Por ser um câncer raro, o MMP tem sua identificação dificultada em serviços de saúde por falta de lembrança da doença. Pode ser confundido, principalmente, com metástases pleurais de sítios primários identificados ou não ou com câncer de pulmão.  
O peritônio (C45.1), pericárdio (C45.2) e a túnica vaginalis (C45.7) são outras possíveis localizações do tumor, uma vez que a origem do tecido é similar. O MMP é o mais frequente, sendo responsável por mais de 90% dos casos cadastrados no registro italiano (ReNaM) e na Australia, seguido da localização peritoneal<sup>14,15</sup> .  
Os registros de causa básica de óbito nacionais, compilados no período de 2000 a 2012, revelaram que 77% dos casos tinha localização pleural ou inespecífica, 16% peritoneal, 7% no pericárdio e outros locais<sup>12</sup> . Mulheres apresentam maior susceptibilidade de localização peritoneal. Em análise de 21.463 casos do ReNaM, a localização peritoneal ocorreu em 9,4% das mulheres e em 5,3% dos homens<sup>7</sup> .  
Diante do exposto, considerando que o MMP ocorre com mais frequência do que o mesotelioma em outros locais anatômicos, para fins destas Diretrizes, optou-se em dar ênfase apenas ao MMP. Dado o desconhecimento e as dificuldades no reconhecimento da doença, com a consequente subnotificação e sub-registro e, tendo em vista as crescentes demandas judiciais em matéria das doenças relacionadas ao asbesto, foi reunido um grupo de especialistas com o objetivo de elaborar diretrizes nacionais sobre o diagnóstico do MMP.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **2. METODOLOGIA** -->
Estas Diretrizes visam a estabelecer os critérios diagnósticos do mesotelioma maligno de pleura. A sua elaboração seguiu as recomendações das diretrizes metodológicas do Ministério da Saúde<sup>16</sup> , e a metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
Uma busca estruturada por revisões sistemáticas foi realizada para cada uma das nove perguntas definidas no escopo destas diretrizes, sendo selecionada a revisão mais recente para os desfechos de interesse. O risco de viés dos estudos selecionados foi avaliado pelas ferramentas ROBIS-2<sup>17</sup> ou QUADAS-2<sup>18</sup> de acordo com o desenho de estudo, respectivamente, revisão sistemática ou estudo de teste diagnóstico, para as perguntas 2, 5 e 7.  
Para a pergunta sobre a utilização de imuno-histoquímica no diagnóstico de MMP, as revisões selecionadas foram atualizadas e oito meta-análises referentes aos resultados de acurácia dos marcadores selecionados foram conduzidas. A avaliação da qualidade do corpo destas evidências foi realizada a partir do sistema GRADE ( _Grading of Recommendations, Assessment, Development and Evaluation_ )<sup>19</sup> . Tabelas com a sumarização das evidências e respectiva qualidade ou grau de certeza foram desenvolvidas na plataforma GRADEpro<sup>20</sup> e as recomendações para a utilização de marcadores de imuno-histoquímica para o diagnóstico de MMP foram elaboradas.  
A descrição detalhada sobre perguntas do escopo e todo o processo metodológico para elaboração destas diretrizes está no Anexo deste documento. Em síntese, vale ressaltar a seguir alguns parâmetros importantes para melhor compreensão do escopo dessas Diretrizes.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- C45.0   Mesotelioma da pleura  
- C45.9  Mesotelioma, não especificado

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.1. Sintomas e História Ocupacional** -->
Os sintomas de apresentação do MMP são inespecíficos e comuns às doenças pleurais. Dispneia, dor torácica, tosse, perda de peso, astenia, fadiga e, eventualmente,  
abaulamento no tórax são os sintomas mais comuns. É um câncer raríssimo antes dos 30 anos de idade, pelo longo período de latência entre a exposição ao asbesto e o desenvolvimento da doença. Deve ser suspeitado em indivíduos adultos, que apresentam RX de tórax mostrando sinais de derrame pleural, de extensão variável oue opacidades boceladas em projeção pleural. A presença de derrame pleural associado a um dos sintomas, na ausência de alteração intrapulmonar ou sinais de infecção, é um achado muitas vezes presente na apresentação inicial do mesotelioma<sup>21</sup> .  
Muito embora a maioria dos pacientes com diagnóstico de mesotelioma apresentem antecedentes de exposição ao asbesto, notadamente os homens, o diagnóstico de mesotelioma prescinde de dados da história de exposição ocupacional ou ambiental<sup>22-</sup> 24.  
É frequente que indivíduos com diagnóstico firmado de mesotelioma não refiram, não se lembrem ou mesmo neguem exposição ao asbesto. Entretanto, os dados de história de exposição podem contribuir para a avaliação diagnóstica. Embora tenha baixo nível de evidência como preditores da doença, são importantes na avaliação diagnóstica e indispensáveis para a atribuição da doença ao asbesto<sup>21</sup> . Portanto, durante a anamnese, é importante que o profissional de saúde obtenha um histórico ocupacional e ambiental detalhado em pacientes com sintomas sugestivos de MMP.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.2. Exames de Imagem** -->
Quando há suspeita clínica de lesão pleural, a investigação inicial por imagem deve ser feita com radiografias simples do tórax (RXT)<sup>24-27</sup> . Da mesma forma, deve-se proceder com as neoplasias pleurais malignas, inclusive o MMP. A tomografia computadorizada (TC) do tórax, por ter melhor resolução, é mais sensível e acurada que o RXT, contudo estes métodos são complementares e devem ser realizados em pacientes com suspeita de neoplasia pleural maligna, independentemente de histórico de exposição ao asbesto. A TC de tórax apresenta sensibilidade de 62% a 75% e especificidade de 72% a 84% na detecção de doença pleural maligna<sup>28</sup> e deve ser realizada com contraste iodado endovenoso nas suspeitas.  
A tomografia computadorizada por emissão de pósitrons (PET-TC) pode auxiliar a caracterização de lesão pleural maligna com sensibilidade de 92% a 97% e especificidade de 76% a 88%<sup>29</sup> . Falsos negativos neste método estão associados a lesões de pequeno volume e com índice proliferativo baixo, como o mesotelioma epitelioide.  
Falsos positivos estão associados a processos inflamatórios, infecções (tuberculose e derrames parapneumônicos) e pós-pleurodese com talco<sup>29-31</sup> . A PET-TC não é recomendada para o diagnóstico de pacientes com pleurodese com talco prévia e deve ser empregado com cautela em populações com alta prevalência de tuberculose. A Ressonância Magnética (RM) também tem sido estudada quanto à diferenciação entre lesões benignas e malignas, especialmente o uso de sequências ponderadas na difusão da água, contudo ainda são necessários mais dados para validar seu uso como complementar à TC<sup>32, 33</sup> .  A RM não é, contudo, recomendada para o diagnóstico de pacientes com suspeita de MMP.  
Em relação aos achados dos exames de imagem, o RXT no MMP mostra, em cerca de 80% dos casos, derrame pleural comumente unilateral. O espessamento pleural com aspecto circunferencial e nodular é característico de infiltração maligna, inclusive ao longo das fissuras interlobares. Perda de volume do hemitórax comprometido e sinais de doença pleural relacionada ao asbesto podem estar presentes<sup>25, 26</sup> . Os achados do MMP na TC do tórax são derrame e espessamento pleural nodular, que pode ser circunferencial e ter espessura > 1 cm. Infiltração mediastinal, diafragmática e da parede torácica e linfonodomegalia torácica podem ser identificadas. Placas pleurais podem estar presentes<sup>25, 27</sup> .  
Nos exames de medicina nuclear (tomografia por emissão de pósitrons-PET/TC) há intensa captação do radiofármaco pelo tumor e metástases, sendo este exame sensível para a detecção de invasão local. O MMP e a neoplasia pleural metastática são indistinguíveis pelos exames de imagem. Os tumores primários que mais comumente se apresentam com metástases pleurais são os de pulmão, mama, linfoma, ovário e estômago. Acometimento pulmonar e linfonodomegalia mediastinal e hilar sugerem neoplasia pleural metastática. Espessamento pleural circunferencial, cissural e pericárdico são mais indicativos do MMP. As placas pleurais são indicadores de exposição prévia ao asbesto, mas não são definidores de neoplasia pleural maligna<sup>34-42</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.3.1. Citologia do líquido pleural** -->
O MMP se apresenta com derrame pleural em mais de 80% dos casos, e a análise citológica do líquido, em geral, é o passo inicial para confirmar o diagnóstico. A citologia  
é útil tanto para diferenciar um processo reativo como entre uma neoplasia de pleura primária ou secundária<sup>43</sup> .  
O diagnóstico definitivo de mesotelioma maligno utilizando citologia permanece controverso, com uma sensibilidade variando entre 30% a 75%<sup>44</sup> . A baixa sensibilidade pode estar mais relacionada ao material representado do que a dificuldade de interpretação do citopatologista, levando a uma alta taxa de falsos negativos, principalmente na separação entre casos de hiperplasia mesotelial e mesotelioma maligno. As características citológicas descritas há mais de 50 anos como bordas recortadas de aglomerados de células; janelas intercelulares com bordas citoplasmáticas mais leves e densas; e relação nuclear/citoplasmática alta é compartilhada em ambas as situações<sup>45</sup> .  
Além da representatividade do material, outra situação que pode dificultar o diagnóstico ocorre nos casos de mesotelioma desmoplásico, em que as células geralmente não descamam para o interior do liquido pleural, além da incapacidade de avaliar a invasão tecidual, sendo importante a correlação com os achados clínicos e radiológicos<sup>46</sup> .  
A utilização de ferramentas como imuno-histoquímica e testes moleculares aumentam a acurácia diagnóstica do MMP. Como na histologia, a demonstração da deleção homozigota do p16 pelo método de FISH e a perda da expressão do BAP1 pela imuno-histoquímica, são exemplos de métodos que auxiliam no diagnóstico diferencial entre benigno e maligno<sup>47</sup> .  
A citologia é uma ferramenta importante na identificação de derrames pleurais suspeitos de malignidade, porém não é capaz de distinguir entre neoplasia maligna primária e metastática apenas pela morfologia, sendo recomendado que em material citológico seja feito o emblocado ( _cell-block_ ) para realização de imuno-histoquímica se necessário<sup>45</sup> .  
Em resumo, o exame de líquido pleural baseado exclusivamente em esfregaços citológicos, mesmo sendo realizado por patologistas experientes, não pode ser considerado suficiente para o diagnóstico conclusivo definitivo de Mesotelioma Maligno<sup>45</sup> . Entretanto, essa modalidade diagnóstica pode ser útil nos casos em que a capacidade funcional e status do paciente impossibilite a realização de exames invasivos para obtenção de fragmentos de tecidos maiores<sup>21</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.3.2. Técnicas de obtenção de material para exame histopatológico** -->
A sensibilidade e especificidade da histopatologia no diagnóstico de doenças malignas da pleura dependem do material que é coletado no processo de investigação e do procedimento de coleta. Abaixo são discutidos os métodos disponíveis de coleta de material pleural em casos suspeitos de MMP.  
<u>Biópsia de pleura por via transtorácica ou transparietal com agulha fina e exame histopatológico do tecido coletado</u>  
Estudos retrospectivos de série de casos mostram que a biópsia de pleura feita às cegas, em geral realizada no mesmo procedimento de toracocentese pela utilização de agulhas de Abrams ou Cope, mostram que a sensibilidade diagnóstica de malignidade aumenta em até 27%, comparado com a sensibilidade da citologia do líquido pleural<sup>48</sup> .  
Uma série de 70 casos com diagnóstico definitivo de MMP revelou positividade da histopatologia na biopsia por agulha de 50% contra 39% no estudo citológico do líquido pleural apenas. A integração dos dois métodos fez a positividade diagnóstica subir a 80%<sup>49</sup> . Apesar da sensibilidade razoável, os falsos-negativos da biópsia às cegas podem levar a atraso significativo no diagnóstico e tratamento de um processo neoplásico<sup>50</sup> .  
Em um estudo de série de 863 casos com biopsia de pleura às cegas e confirmação diagnóstica posterior<sup>51</sup> foi possível realizar análise da acurácia do procedimento para diagnóstico de processos malignos em geral e para MMP em particular. Para o diagnóstico de malignidade pleural obteve-se uma sensibilidade de 77% (IC 95%: 74-79), especificidade de 98% (IC 95%: 97-99), enquanto especificamente para MMP, a sensibilidade foi de 81% (IC 95%: 78-83) e a especificidade de 100%<sup>51</sup> . No entanto, este estudo difere de outros estudos, que mostraram sensibilidade de até 50% para diagnóstico de MMP por meio de biópsia às cegas<sup>49,52,53</sup> . As limitações desse procedimento são: o pequeno tamanho dos fragmentos coletados e a dificuldade de se tratar de material representativo do tumor.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Biópsia de pleura guiada por imagem de tomografia computadorizada ou ultrassonografia</u> -->
O procedimento utiliza imagens de tomografia computadorizada (TC) feita sob contraste visando a otimizar a coleta de material que será então realizada nas áreas consideradas mais comprometidas.  
Em estudo controlado comparando o procedimento orientado por TC com agulha de tipo thrucut (TC + Bx) e o procedimento de biópsia de agulha fina às cegas (Bx) em 50 pacientes consecutivos aleatorizados em dois grupos de 25, obteve-se uma  
sensibilidade de 87% no grupo TC + Bx, contra 47% no grupo Bx<sup>53</sup> . Outro estudo observou positividade para MMP em 13 de 14 pacientes biopsiados com auxílio da TC<sup>54</sup> .  
Resultados similares foram observados em biopsias guiadas por ultrassom. Em um estudo de 56 pacientes com diagnóstico definitivo de MMP, a biopsia guiada por ultrassom definiu 77% dos diagnósticos, com especificidade de 88%<sup>55</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Biópsias de gânglios linfáticos</u> -->
Esse tipo de biópsia não é recomendado como fonte de diagnóstico de MMP, pois ocorre sobreposição histopatológica entre alterações ganglionares secundárias à drenagem normal de células mesoteliais originadas de um derrame pleural não maligno e as células típicas do MMP<sup>56</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Biópsia de pleura sob visão direta durante toracoscopia</u> -->
A toracoscopia é comumente dividida em toracoscopia minimamente invasiva sob anestesia, e a toracoscopia cirúrgica, também chamado de "cirurgia torácica vídeo assistida” (VATS na sigla em Inglês).  
A toracoscopia pode ser realizada por meio de um instrumento rígido ou semirrígido e por um acesso único ou duplo de entrada. O diâmetro do trocater varia entre 7-11 mm, enquanto o diâmetro da óptica varia de 6-10 mm e o do fórceps de biópsia de 4-6 mm. Áreas suspeitas são biopsiadas através do toracoscópio sob visão direta usando as pinças de biópsia. Essa característica do procedimento promove um rendimento diagnóstico com cerca de 95% em derrames malignos quando comparado com biópsias de agulha fina guiada por TC cuja sensibilidade foi de 87,5%<sup>57</sup> .  
O exame ampliado do espaço pleural é possível com o uso da VATS e grandes amostras de tecido podem ser obtidas. No entanto, a VATS requer anestesia geral e pneumotórax induzido, o que pode não ser tolerado por alguns pacientes com função pulmonar prejudicada<sup>58</sup> .  
O número ideal de biópsias necessárias ainda não está definido, mas recomendase realizar entre 2 a 6 biópsias de uma lesão pleural suspeita. Quando a suspeita de malignidade é alta, mas nenhuma lesão tumoral é visualizada, é recomendado fazer as biópsias de vários locais onde a pleura tenha aspecto anormal<sup>59</sup> .  
A toracoscopia, por qualquer dos métodos exemplificados acima, tem a vantagem de obter vários fragmentos de tecido com profundidade adequada à realização de técnicas imuno-histoquímicas necessárias à diferenciação entre MMP e adenocarcinoma  
metastático, sarcoma pleural e mesmo hiperplasia mesotelial reativa<sup>60</sup> . Nesse sentido, a toracoscopia reduz a necessidade de toracotomia complementar, pois fornece quantidade de material suficiente ao diagnóstico do MMP.  
Com relação ao diagnóstico de MMP, o rendimento da biópsia por toracoscopia é superior a 90%. Em estudo prospectivo de uma série de casos sem aleatorização, comparando outras técnicas diagnósticas previamente à toracoscopia, observaram-se sensibilidade de 26% pela citologia do líquido pleural; 21% pela biópsia de pleura às cegas; 39% quando se somavam os dois métodos anteriores e 98% de sensibilidade pela toracoscopia<sup>52</sup> .  
A toracoscopia é o procedimento padrão para se obter tecido tumoral suficiente e, ao mesmo tempo, realizar o estadiamento macroscópico da extensão do tumor, podendo ainda realizar-se a pleurodese como forma de tratamento inicial da doença<sup>61</sup> .  
O pequeno número de falsos negativos presentes em todos os estudos que utilizaram toracoscopia é geralmente devido à exploração incompleta da cavidade pleural, causada por aderências que não podem ser debridadas endoscopicamente<sup>62</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.3.3. Histologia** -->
Os mesoteliomas malignos se apresentam sob as formas difusa ou localizada e são classificados em três grandes subtipos histológicos: epitelioide, sarcomatoide (incluindo o MM desmoplásico) e bifásico ou misto<sup>63-65</sup> .  
Os MM epitelioides são os mais comuns, constituindo cerca de 60% de todos os mesoteliomas. São caracterizados tipicamente pela presença de células ovaladas, poligonais ou cuboidais, que se assemelham às células mesoteliais reacionais e podem apresentar padrões de crescimento arquitetural variados como tubulopapilífero, acinar (glandular), adenomatoide (microglandular) e sólido. Corpos sarcomatosos podem estar presentes em qualquer um dos padrões arquiteturais descritos e ninhos isolados de células neoplásicas imersos em lagos translúcidos de ácido hialurônico também ocorrem eventualmente. O diagnóstico diferencial nos casos de MMP epitelioides típicos é feito com os carcinomas metastáticos, outras neoplasias epiteliais, além de hiperplasia de células mesoteliais. Por vezes, as células neoplásicas apresentam aspectos bastante diferentes como citoplasma claro, deciduoide, em anel de sinete, pequenas, rabdoide ou padrão adenoidecístico<sup>65,66</sup> .  
Os MM epitelioides de padrão tubulopapilífero devem ser distinguidos dos mesoteliomas papilíferos bem diferenciados, que são classificados como um subtipo distinto na Classificação da Organização Mundial da Saúde<sup>63</sup> , embora raramente apresentem focos de invasão<sup>64</sup> . Os MM epitelioides com pleomorfismo nuclear acentuado em mais de 10% da neoplasia tem mostrado comportamento biológico semelhante aos dos subtipos sarcomatoide e bifásico (misto)<sup>46</sup> .  
Os MM sarcomatoides são constituídos por células fusiformes malignas, que podem mimetizar neoplasias mesenquimais, como leiomiossarcomas ou sinoviossarcomas. Também podem apresentar células linfohistiocitoides ouconter elementos heterólogos rabdomiossarcomatosos, osteossarcomatosos ou condrossarcomatosos<sup>67, 68</sup> . Outros padrões de MM sarcomatoide apresentam células anaplásicas e células gigantes, áreas osteossarcomatosas ou condrossarcomatosas, sendo necessário o diagnóstico diferencial com sarcomas de alto grau, osteossarcomas e condrossarcomas, respectivamente. Os MM desmoplásicos são considerados um subtipo de MM sarcomatoide, sendo caracterizados por faixas de estroma colágeno denso com raras células fusiformes malignas entremeadas, lembrando uma placa pleural<sup>68</sup> .  
Os MM bifásicos ou mistos apresentam áreas constituídas por componentes epitelioides e sarcomatoides na mesma neoplasia. O diagnóstico diferencial é feito com sinoviossarcoma e com outras neoplasias mistas ou bifásicas<sup>64,66,69,70</sup> . Alguns MM são pouco diferenciados e constituídos por células pequenas e sem coesão sendo necessário o diagnóstico diferencial com os linfomas<sup>70</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.3.4. Imuno-histoquímica** -->
A imuno-histoquímica é uma técnica auxiliar da anatomia patológica importante no diagnóstico diferencial entre MMP e outros tipos de câncer na pleura, como o adenocarcinoma metastático. Com o uso desta técnica, a expressão de proteínas dos tecidos é detectada por meio de uma ligação entre tais proteínas (antígenos) e marcadores específicos (anticorpos). Para o diagnóstico de MMP, a combinação de diferentes marcadores de imuno-histoquímica, para tecido mesotelial e para adenocarcinoma, é utilizada com o objetivo de aumentar a acurácia diagnóstica<sup>21</sup> .  
Com base nas evidências levantadas a partir da revisão sistemática e meta-análises realizadas para a elaboração destas Diretrizes, a utilização de imuno-histoquímica em amostra de fragmento de pleura é indicada de acordo com o grau de suspeita clínico-  
radiológica de MMP. Portanto, o conhecimento sobre os achados clínico-radiológicos, eventualmente reforçados por uma história positiva de exposição ocupacional e ambiental ao asbesto, são essenciais para se alcançar maior probabilidade de diagnóstico correto com a técnica. Assim, a combinação de pelo menos 2 marcadores positivos para tecido mesotelial (entre eles, WT-1, calretinina, CK5/6 ou D2-40) e 2 marcadores de adenocarcinoma negativos (entre eles, CEA, BerEp4, TTF-1 ou MOC31) fornece maiores probabilidades de diagnóstico de MMP em cenários de maior suspeita da doença. Por exemplo, em pacientes com doença pleural maligna identificada por técnicas rotineiras de anatomia patológica e com história de exposição ao asbesto ou com suspeita clínicoradiológica da doença, a probabilidade de MMP pode chegar a 99,8% quando 2 marcadores para tecido mesotelial são positivos e 2 marcadores para adenocarcinoma são negativos. Por outro lado, em pacientes com baixa suspeita de MMP, como em casos de derrame pleural exsudativo, sem história de exposição e sem suspeita clínico-radiológica, resultados falso-positivos podem ocorrer em até 36% dos casos, se o diagnóstico de MMP for considerado para a combinação de 2 marcadores positivos e 2 marcadores negativos 71-112.  
Considerando os resultados das meta-análises, da avaliação pelo GRADE e painel de especialistas, conforme detalhes no **Apêndice 1** , as seguintes recomendações foram elaboradas:  
<u>Recomendações para a realização de exame imuno-histoquímico em fragmento de pleura</u>  
A combinação de pelo menos dois marcadores mesoteliais positivos (entre eles, WT-1, calretinina, CK5/6, D2-40) e pelo menos dois marcadores de adenocarcinoma negativos (entre eles, CEA, BerEp4, TTF-1, MOC31) deve ser utilizada para o diagnóstico de MMP, conforme as seguintes recomendações:  
**1.** A realização da técnica deve ser guiada pela história de exposição ao asbesto e pelas características clínicas, radiológicas e histopatológicas do paciente.  
<u>Justificativa</u>  
- O desempenho da técnica varia bastante de acordo com o grau de suspeita de MMP (probabilidade pré-teste do paciente)  
- <u>Considerações</u>  
- É importante avaliar e reportar ao patologista as informações sobre história ocupacional e de exposição ambiental ao asbesto e sobre a presença de características clínico-radiológicas sugestivas de MMP.  
- É importante a avaliação do patologista quanto à presença de malignidade no fragmento de pleura por técnicas de anatomia patológica antes da realização de exame de imuno-histoquímica.  
**2.** A técnica não deve ser realizada em pacientes com derrame pleural exsudativo, na ausência de características clínicas, radiológicas ou patológicas sugestivas de MMP.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Justificativa</u> -->
- A realização de rotina da técnica em pacientes com baixa suspeita clínico-radiológica e patológica de MMP aumenta muito a probabilidade de resultados falso-positivos.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Considerações</u> -->
- Caso sejam excluídas outras hipóteses diagnósticas, ou seja, identificada alguma característica que aumente a suspeita da doença, a realização de imunoistoquímica pode ser considerada para o diagnóstico diferencial.  
**3.** A técnica deve ser realizada em caso de paciente com doença pleural maligna, porém sem características clínicas, radiológicas ou patológicas sugestivas de MMP somente após a investigação de neoplasias em outros sítios primários mais comuns capazes de desenvolver metástase pleural.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Justificativa</u> -->
- Em pacientes com doença pleural maligna, porém com baixa suspeita clínicoradiológica de MMP, a etiologia mais comum é secundária a outras neoplasias pleurais.  
- <u>Considerações</u>  
- Caso sejam excluídas outras neoplasias, ou seja, identificada alguma característica que aumente a suspeita da doença, a realização de imuno-histoquímica pode ser considerada para o diagnóstico diferencial.  
**4.** A técnica deve ser realizada em pacientes com doença pleural maligna e com história de exposição ao asbesto, características clínicas, radiológicas ou patológicas sugestivas de MMP.  
- A realização da técnica em pacientes com história de exposição e alta suspeita clínicoradiológica e histopatológica de MMP aumenta muito a probabilidade de resultados verdadeiro-positivos.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Considerações</u> -->
- Uma história de exposição ocupacional ou ambiental positiva aumenta a suspeita de doença, especialmente considerando um período de latência longo (mínimo de 10 anos) entre a exposição e o desenvolvimento da doença. Entretanto, a ausência ou o desconhecimento sobre exposição não exclui a possibilidade de MMP.  
- Caso os dois marcadores mesoteliais tenham sido negativos e os dois marcadores de adenocarcinoma tenham sido positivos, investigar outras neoplasias pleurais considerando os marcadores utilizados. Em caso de outro tipo de inconsistência nos resultados, reavaliar história e quadro clínico do paciente para considerar testes adicionais para MMP ou outras neoplasias.  
A **Figura 1** resume essas indicações.  
<!-- Start of picture text -->
Avaliacao clinica, radioldgica,<br>histopatologica<br>Derrame pleural exsudativo, sem Doenga pleural maligna, sem Doenga pleural maligna, com<br>historia ocupacional/ambiental e | | historia ocupacional/ambiental e | | historia ocupacional/ambiental<br>sem suspeita clinico-radiolégica sem suspeita clinico-radioldgica | | e/ou suspeita clinico-radiolégica<br>. Fazer imunohistoquimica<br>~ ; Investigar outras<br>Nao fazer imuno- . A com pelo menos 2<br>. a a neoplasias com metastase a<br>histoquimica de rotina’ marcadores positivos e 2<br>para pleura ~<br>negativos para MMP<br>Investigagao negativa :<br>Fazer imunohistoquimica com<br>pelo menos 2 marcadores<br>positivos e 2 negativos para MMP<br><!-- End of picture text -->  
MMP: mesotelioma maligno de pleura  
- Caso haja suspeita clínico/radiológica/histopatológica, ou excluídas outras hipóteses diagnósticas, pode ser considerada a realização de exame imuno-histoquímico para diagnóstico diferencial de MMP.  
**Figura 1 -** Fluxograma com as recomendações para realização de exame imuno-histoquímico em fragmento de pleura para o diagnóstico de mesotelioma maligno de pleura.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.3.5. Microscopia eletrônica** -->
Em indivíduos com história de exposição ao asbesto ou com doenças suspeitas de relação com o asbesto, porém sem histórico de exposição conhecida, a microscopia eletrônica de transmissão oude varredura tem sido utilizada para fins de pesquisa com o objetivo de caracterizar os tipos de fibras e quantificar a sua carga no pulmão de pacientes com MMP<sup>113</sup> .  
Em um estudo de coorte com 55 pacientes com diagnóstico patológico de mesotelioma foram identificados corpos ferruginosos e fibras de asbestos no tecido pulmonar por microscopia eletrônica<sup>114</sup> . Em outro estudo com 14 casos de MMP, 12 casos de adenocarcinoma de pleura e 13 casos de doença pleural benigna conclui-se que o exame citológico do líquido pleural por microscopia eletrônica não acrescenta na acurácia diagnóstica do MMP<sup>43</sup> .  
As características do mesotelioma maligno pela técnica de microscopia eletrônica são bem conhecidas, no entanto não existe uma característica ultraestrutural única que seja diagnóstica, mas sim várias características combinadas que podem ser úteis para diagnóstico. Nesse contexto, deve-se enfatizar que o papel da microscopia eletrônica é muito restrito, porque na maioria dos casos de MMP, a microscopia óptica associada a imuno-histoquímica são muito mais rápidas, menos dispendiosas e mais acessíveis para estabelecer o diagnóstico correto<sup>113</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.3.6. Pesquisa de fibras e corpos de asbesto** -->
As fibras de asbesto após inalação e deposição nas vias aéreas terminais, ductos e sacos alveolares atraem macrófagos, que tentam fagocitá-las. Um pequeno percentual de fibras é recoberto por proteínas e ferro por meio de um processo protetivo, que determina uma diminuição de sua toxicidade e resulta nos corpos ferruginosos<sup>115</sup> .  
Corpos ferruginosos são formados por um núcleo constituído por uma fibra de asbesto e possuem uma coloração marrom clara, medindo em média 35-40 μm, podendo  
ser reconhecidos pela microscopia usual. São os chamados corpos de asbesto. Entretanto, outros materiais como o carbono, o talco, e a sílica também podem formar corpos ferruginosos<sup>115</sup> .  
Análises quantitativas por meio de métodos de digestão tecidual, extração e contagem de fibras, indicam uma concentração de 1 x 10⁶/g de peso seco na população geral. Por outro lado, pacientes com placas pleurais têm 50 vezes esse número, enquanto que nos pacientes com asbestose ou mesotelioma esse número aumenta para 100-200 x 10⁶/g de peso seco<sup>116</sup> .  
Os corpos ferruginosos refletem apenas uma parcela pequena, mas variável da quantidade total de fibras de asbesto presentes no pulmão<sup>115</sup> . As fibras que não sofreram o processo de revestimento, justamente aquelas que causam maior dano oxidativo, dificilmente são visualizadas à microscopia de contraste de fase<sup>117</sup> .  
Métodos analíticos permitem, ainda, identificar o tipo de fibra em uma determinada amostra, podendo dessa forma ser determinado um perfil epidemiológico da exposição individual.  
A caracterização da exposição é oportuna para o estabelecimento das implicações epidemiológicas e médico-legais, mas não significa a presença de doenças relacionadas ao asbesto. Não possuem, portanto, valor diagnóstico<sup>115</sup> . Saliente-se que o diagnóstico anátomo-clínico das doenças associadas ao asbesto não requer a identificação e caracterização das fibras ou corpos de asbesto.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.4. Diagnóstico presuntivo** -->
A literatura pesquisada prescinde de estudos que permitam responder à pergunta formulada e determinar o nível de evidência. Após a revisão realizada por dois pesquisadores independentes não foram encontrados estudos com desenho adequado que permitissem a avaliação da sua acurácia. Entretanto, existem situações em que podemos utilizar critérios sugeridos pelo _Registro Nazionale dei Mesoteliomi –_ ReNaM<sup>118</sup> , buscando uma combinação de positividade em história, exame físico, exames de imagem e de anatomia patológica para aumentarmos a chance de um correto diagnóstico do MMP. Reafirma-se que todo o esforço deve ser direcionado para o diagnóstico preciso, pelas implicações relacionadas ao tratamento e ao prognóstico, bem como para fins de registro e assim melhorar o conhecimento da epidemiologia da doença no Brasil.  
Devido ao longo período de latência entre a exposição ao asbesto e o desenvolvimento da doença<sup>21</sup> , sua detecção predomina nas faixas de 60 a 80 anos. Deste modo, a probabilidade da existência de co-morbidades associadas que limitem a realização de exames invasivos é maior nesta faixa etária.  
Em localidades em que haja disponibilidade de exame histológico, mas com dificuldades de realização de exames de imuno-histoquímica, os pacientes com clínica e imagem de tórax sugestivos, e com histologia compatível, deverão ser considerados com evidências importantes, ainda que não suficientes, para se concluir pelo diagnóstico de MMP (segundo o _Registro Nazionale dei Mesoteliomi - ReNaM_ )<sup>118</sup> . Notadamente em indivíduos não fumantes ou ex-fumantes que cessaram de fumar antes dos 35 anos de idade<sup>119, 120,121</sup> .  
Embora o exame histológico da pleura associado à imuno-histoquímica seja considerado o principal método para o diagnóstico conclusivo de MMP<sup>21, 46</sup> , em casos em que haja suspeita clínica sem acesso à citologia oubiópsia de pleura, o diagnóstico de MMP “provável” pode ser realizado integrando-se dados de marcadores de exposição ao asbesto com alterações tomográficas sugestivas.  
São considerados marcadores de exposição<sup>122</sup> :  
**1.** Presença de placas pleurais ouasbestose e/ou;  
**2.** História ocupacional de exposição ao asbesto há pelo menos 10 anos e/ou;  
**3.** Presença de um ou mais corpos de asbesto por mililitro de lavado broncoalveolar.  
Isoladamente, o diagnóstico de MMP baseado somente no histórico clínico e em alterações tomográficas sugestivas apresentaram uma sensibilidade de 89% e uma especificidade de 59% quando comparado à confirmação diagnóstica por autópsia<sup>123</sup> .  
Adicionalmente, a evolução clínica também auxilia no diagnóstico de provável MMP. Na presença de quadro de imagem sugestivo/característico e evolução clínica sugestiva, na ausência de marcadores de exposição evidentes, o diagnóstico de MMP deve ser considerado “possível”. Nos diagnósticos considerados “provável” e “possível” devese procurar excluir cânceres primários de mama, pulmão, ovário, estômago, adenocarcinoma de cólon, e carcinomas de rim<sup>46</sup> .  
O **Quadro 1** apresenta as possibilidades de diagnóstico de MMP pela combinação dos critérios clínicos, de história de exposição ao asbesto e de exames de imagem, histopatológico e citológico (com ou sem de imuno-histoquímica), e eventual resultado de autópsia.  
**Quadro 1 -** Possibilidades diagnósticas de mesotelioma maligno de pleura utilizando combinações de critérios (Adaptado<sup>118</sup> ).  
||**M**|**MP Definid**|**o**|**MMP**<br>**Provável**|**MMP**<br>**Possível**|
|---|---|---|---|---|---|
|**Histologia**|QMC|QMC|QMC|NR|NR|
|**Citologia**|QMC|QMC|NR|NR|NR|
|**IHQ**|Característica<br>(associado<br>aos critérios<br>precedentes*<br>)|NR|NR|NR|NR|
|**Imagem**<br>**(TC de**<br>**tórax)****|Sugestiva|Sugestiva|Sugestiva|Sugestiva|Sugestiva|
|**Marcador**<br>**es de**<br>**Exposição**|Ausentes|Ausentes|Presentes (na<br>falta dos<br>critérios<br>precedentes*)|Presentes|Ausentes|
|**Clínica**|Característica|Caracterís-<br>tica|Característica|Caracterís<br>-tica|Característica|
|**Autópsia**|QMC (na<br>falta dos<br>critérios<br>precedentes*<br>)|NR|NR|NR|NR|  
MMP: mesotelioma maligno de pleura; IHQ: imuno-histoquímica; TC: tomografia computadorizada; QMC: quadro morfológico característico; NR= não realizado  
* Critérios precedentes: observados a partir do conjunto das informações levantadas na investigação: exame de prontuários, exames de imagem e laboratoriais.  
** Espessamento pleural circunferencial, cissural e pericárdico são mais indicativos do MMP. Acometimento pulmonar e linfonodomegalia mediastinal e hilar sugerem neoplasia pleural metastática.  
**4.5. Biomarcadores**  
Estudos têm sido realizados na busca de marcadores que possam ser utilizados no rastreamento e diagnóstico de MMP em fases precoces, para monitorar evolução durante o tratamento e para o estabelecimento do diagnóstico em pacientes que não têm condições clinicas para se submeter a procedimentos invasivos para análises teciduais<sup>21,124,125</sup> . No entanto, ainda não há evidências robustas acerca do uso de biomarcadores. Dessa forma, a sua utilização não é recomendada nestas Diretrizes. Diversos marcadores testados no sangue, no líquido pleural e no ar exalado tem sido utilizado em estudos exploratórios para avaliar o seu papel no diagnóstico do MMP, entre eles a mesotelina e fator potencializador de megacariócitos<sup>126,127</sup> , a fibulina-3<sup>128,129</sup> , a osteopontina<sup>130</sup> , micro RNA, fibronectina, trombospondina, ácido hialurônico e CA125<sup>21,125,131</sup> . Dos artigos avaliados foram identificados 15 marcadores dosados no plasma ou soro<sup>126-130,132</sup> e 13 marcadores dosados no líquido pleural<sup>126,132,133</sup> . Entretanto, foi encontrada grande heterogeneidade entre as populações dos estudos, como grupos de comparação e prevalências de doença, entre os pontos de corte utilizados para positividade e, ainda, grande variabilidade nos resultados.  
<u>Peptídeos solúveis relacionados à mesotelina (peptídeos mesotelina e fator potencializador de megacariócito)</u>  
A mesotelina é uma glicoproteina da superfície celular que é altamente expressada no MMP, em cânceres pancreáticos, ovarianos, câncer de pulmão e esôfago, nestes casos pode estar presente no sangue em sua forma solúvel<sup>134</sup> . Os peptídeos solúveis relacionados à mesotelina (SMRPs) são compostos por duas proteínas, a mesotelina solúvel e fator potencializador de megacariócitos (MPF) e são detectadas no plasma ou soro e no líquido pleural<sup>124,126</sup> . Uma meta-análise envolvendo dados de 28 estudos com análises em plasma ou soro e 11 estudos com análises em líquido pleural<sup>126</sup> revelou sensibilidade para SMRPs plasmática ousérica de 61% e especificidade de 87%. Com o material do líquido pleural a sensibilidade foi de 79% e especificidade 85%. As acurácias da SMRPs sérica e no líquido pleural são similares, e MPF sérico tem um diagnóstico de acurácia superior quando comparado com a mesotelina sérica. Hollevoet e colaboradores em uma meta-análise envolvendo 16 estudos identificaram para a mesotelina uma alta especificidade (95%) e baixa sensibilidade (32%), quando não há definição de ponto de corte<sup>127</sup> . Como no estudo de Cui e colaboradores, estes estudos mostraram que, em pacientes suspeitos de mesotelioma, a positividade sérica de mesotelina tem alta  
especificidade contribuindo para o diagnóstico, mas testes negativos não excluem a possibilidade de doença<sup>126</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Fibulina - 3 (FBLN3)</u> -->
A fibulina-3 é uma glicoproteína que desempenha um importante papel na regulação da migração e proliferação de células<sup>134, 135</sup> . Durante muitos anos, vários estudos revelaram que a fibulina-3, dosada no sangue ou no líquido pleural, seria um potencial biomarcador diagnóstico de MMP<sup>136</sup> . Ren e colaboradores, em uma revisão sistemática com meta-análise de oito estudos, encontraram, no líquido pleural e no sangue, valores de sensibilidade e especificidade para a fibulina-3 de 73% e 80% e de 87% e 89%, respectivamente<sup>129</sup> . Outra meta-análise conduzida por Pei e colaboradores, envolvendo sete estudos compreendendo 468 casos de MMP para diagnóstico evidenciou uma sensibilidade inferior, de 62%, e especificidade de 82% na discriminação de pacientes com MMP, com relação a indivíduos livres de câncer<sup>128</sup> . Análise de subgrupo revelou que a análise no soro apresentou eficácia superior à do plasma (sensibilidade: 77% _versus_ 54%; especificidade: 85% _versus_ 77%).

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Osteopontina</u> -->
A osteopontina é uma glicoproteína que tem papel relevante em diferentes vias regulatórias, como a imunológica, a interação entre células e matriz extracelular, migração celular e no desenvolvimento de neoplasias<sup>131</sup> . É altamente expressa no mesotelioma, mas também em várias outras neoplasias como de pulmão, cérebro, próstata e de cólon. Recentes estudos sobre os níveis de osteopontina no sangue e plasma em pacientes com MMP mostraram valores maiores do que em indivíduos sadios, podendo a osteopontina ser utilizada como um biomarcador de pacientes com MMP, embora o exato papel desta glicoproteína no MMP ainda necessite de maiores elucidações.  
Lin e colaboradores, em uma meta-análise com sete estudos que utilizaram a osteopontina para diagnóstico de MMP, encontraram uma sensibilidade de 57% e uma especificidade de 81%<sup>130</sup> .  Hu e colaboradores, em uma revisão sistemática com metaanálise de seis estudos<sup>137</sup> , revelou sensibilidade e especificidade para o diagnóstico de mesotelioma de 65% (IC95%: 60% a 70%) e de 81% (IC95%: 78% a 85%), respectivamente.  
Em resumo, até o momento não existem marcadores com elevadas sensibilidade e especificidade para auxiliar no diagnóstico do MMP<sup>21, 122, 125,131</sup> . Entre os diversos  
marcadores que têm sido estudados a mesotelina, a osteopontina e a fibulina-3 apresentam os melhores resultados para utilização no diagnóstico. Entre esses últimos, os peptídeos solúveis relacionados à mesotelina são os mais consistentes. O uso de uma combinação ou painel de biomarcadores séricos, como o peptidio solúvel relacionada à mesotelina, micro RNA, marcadores procedidos por análises proteômicas, são potencialmente promissores para o rastreamento com fins de diagnóstico precoce, mas ainda inconclusivos<sup>122, 125,131</sup> .  
Assim, a mesotelina, a osteopontina e a fibulina-3 dispõem de um maior número de estudos e maiores valores de sensibilidade ou especificidade. Entretanto, esses biomarcadores ainda não são disponíveis como rotina em nosso meio, sendo necessária a realização de estudos locais e a padronização de valores de corte, em laboratórios de referência, para que seu uso possa ser avaliado para aplicação na prática clínica.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **5. CRITÉRIOS DE INCLUSÃO** -->
Pacientes com suspeita de MMP estão contemplados nestas diretrizes diagnósticas.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **6. CRITÉRIOS DE EXCLUSÃO** -->
As presentes diretrizes não abrangem questões relacionadas especificamente ao diagnóstico de outros tipos de câncer na pleura.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **7. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR DO SUS** -->
O diagnóstico de qualquer tipo de câncer, aqui o mesotelioma, começa na atenção primária no encaminhamento dos casos suspeitos para confirmação diagnóstica para os ambulatórios de especialidades, hospitais gerais ou hospitaos especializados que devem complementar os serviços da atenção primária na investigação diagnóstica, no diagnóstico definitivo e no tratamento do câncer e na atenção às urgências devidas às intercorrências terapêuticas e pela própria evolução da doença, garantindo-se, dessa forma, a integralidade do cuidado no âmbito da rede de atenção à saúde.  
Pelo SUS, os hospitais habilitados em ocologia como Centro de Assistência de Alta Complexidade em Oncologia (CACON) ou Unidade de Assistência de Alta Complexidade em Oncologia (UNACON) devem oferecer assistência especializada e integral ao paciente com câncer devendo observar as exigências da Portaria nº  
1.399/2019<sup>140</sup> para garantir a qualidade dos serviços de assistência oncológica e a segurança do paciente<sup>141</sup> . Nesses hospitais, deve-se dar o diagnóstico definitivo, a extensão da neoplasia maligna (estadiamento) e assegurar a continuidade do atendimento de acordo com as rotinas e as condutas estabelecidas pelo hospital, com base nas diretrizes diagnósticas e terapêuticas estabelecidas pelo Ministério da Saúde, quando existentes.  
Caberá ainda a esses hospitais oferecer serviços de cirurgia, radioterapia, quimioterapia, suporte terapêutico e cuidados paliativos, a depender da habilitação recebida. Devem ainda encaminhar, de forma regulada, os casos que necessitam de complementação terapêutica para a clínica especializada (radioterapia ou quimioterapia), além de realizar pronto-atendimento e cuidados paliativos aos respectivos pacientes matriculados.  
Os hospitais habilitados como UNACON que não proverem assistências em cirurgia de cabeça e pescoço ou em cirurgia torácica deverão formalizar junto ao respectivo gestor do SUS para qual outro hospital encaminhará os pacientes com indicação desse atendimento.  
Os cuidados paliativos, prestados por equipe multidisciplinar, para promover a qualidade de vida dos pacientes e sua família, estão estabelecidos na Resolução nº 41/CIT, de 31 de outubro de 2018<sup>142</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: <u>Rede ampliada</u> -->
Atualmente (outubro de 2020), existem no SUS 310 hospitais habilitados na alta complexidade em oncologia, integrando mais 34 estabelecimentos de saúde a essas habilitações. Todos os estados brasileiros têm pelo menos um hospital habilitado nessa modalidade assistencial<sup>141</sup> .  
As competências e responsabilidades dos hospitais e das secretarias estaduais, distrital e municipais de saúde são respetivamente definidas<sup>141</sup> .  
A Secretaria de Atenção Especializada à Saúde do Ministério da Saúde mantém atualizada a relação dos estabelecimentos de saúde habilitados na alta complexidade em oncologia no SUS, por município, estado e tipo de habilitação, no sítio eletrônico <u>https://www.saude.gov.br/atencao-especializada-e-hospitalar/especialidades/oncologia .</u>  
No **Quadro 2** , relacionam-se os procedimentos previstos nestas Diretrizes, conforme consta no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (Sigtap).  
**<mark>Quadro 2 -</mark>** <mark>Lista de Procedimentos previstos na Diretrizes</mark>  
|**Procedimento**|**Código**|
|---|---|
|Radiografia de tórax (PA)|02.04.03.017-<br>0|
|Radiografia de torax (PA e Perfil)|02.04.03.015-<br>3|
|Tomografia computadorizada de tórax|02.06.02.003-<br>1|
|Exame de citologia (exceto cervico-vaginal e de mama)|02.03.01.003-<br>5|
|Biopsia de pleura (por aspiração/agulha/pleuroscopia)|02.01.01.040-<br>2|
|Biopsia percutânea orientada por tomografia<br>computadorizada/ultrassonografia/ressonância magnética/radiografia<br>simples de tórax|02.01.01.054-<br>2|
|Videotoracoscopia|02.09.04.005-<br>0|
|Exame anatomo-patológico para congelamento/parafina por peça<br>cirúrgica ou por biópsia (exceto colo uterino e mama)|02.03.02.003-<br>0|
|Imuno-histoquímica de neoplasias malignas (por marcador)|02.03.02.004-<br>9|  
**Nota:** A ampliação do uso do procedimento 02.06.01.009-5 Tomografia por Emissão de Pósitrons para a avaliação de Mesotelioma Pleural será avaliada pela CONITEC.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **8. REFERÊNCIAS** -->
1. National Institute for Occupational Safety and Health (US). Current Intelligence Bulletin 62: Asbestos Fibers and Other Elongate Mineral Particles: State of the Science and Roadmap for Research. Washington, DC: NIOSH; 2011.  
2. Fazzo L, De Santis M, Minelli G, Bruno C, Zona A, Marinaccio A, et al. Pleural mesothelioma mortality and asbestos exposure mapping in Italy. Am J Ind Med. 2012;55(1):11-24.  
3. McDonald JC, McDonald AD. Epidemiology of mesothelioma. In: Liddell D, Miller K. Mineral fibers and health. Boca Raton, FL: CRC Press; 1991. p.147-68.  
4. Iwatsubo Y, Matrat M, Michel E, Boutin C, Galateau-Salle F, Jougla E, et al. Estimation of the incidence of pleural mesothelioma according to death certificates in France. Am J Ind Med. 2002;42(3):188-99.  
5. Odgerel CO, Takahashi K, Sorahan T, Driscoll T, Fitzmaurice C, Yoko-O M, et al. Estimation of the global burden of mesothelioma deaths from incomplete national mortality data. Occup Environ Med. 2017;74(12):851-8.  
6. Delgermaa V, Takahashi K, Park EK, Le GV, Hara T, Sorahan T. Global mesothelioma deaths reported to the World Health Organization between 1994 and 2008. Bull World Health Organ. 2011;89(10):716-24.  
7. Marinaccio A, Corfiati M, Binazzi A, Di Marzio D, Scarselli A, Ferrante P, et al. The epidemiology of malignant mesothelioma in women: gender differences and modalities of asbestos exposure. Occup Environ Med. 2018;75(4):254-62.  
8. Gilham C, Rake C, Burdett G, Nicholson AG, Davison L, Franchini A, et al. Pleural mesothelioma and lung cancer risks in relation to occupational history and asbestos lung burden. Occup Environ Med. 2016;73(5):290-9.  
9. Virta RL. Worldwide asbestos supply and consumption trends from 1900 through 2003. Reston, VA: U.S. Geological Survey; 2006. Circular 1298.  
10. Departamento Nacional de Produção Mineral. Agência Nacional de Mineração [Internet]. [2019] [Acesso 15 mai. 2019]. Disponível em: http://www.dnpm.gov.br/.  
11. Pedra F, Tambellini AT, Pereira BB, da Costa AC, de Castro HA. Mesothelioma mortality in Brazil, 1980-2003. Int J Occup Environ Health. 2008;14(3):170-5.  
12. Algranti E, Saito CA, Carneiro AP, Moreira B, Mendonça EM, Bussacos MA. The next mesothelioma wave: mortality trends and forecast to 2030 in Brazil. Cancer Epidemiol. 2015;39(5):687-92.  
13. Trotta A, Santana VS, Alazraqui M. [Mesothelioma mortality in Argentina, 19802013]. Salud Colect. 2017;13(1):35-44.  
14. Marinaccio A. [Twenty years of data in the 5th Report of the Italian National Mesothelioma Register]. Epidemiol Prev. 2016;40(1):3.  
15. Soeberg MJ, Leigh J, Driscoll T, Armstrong B, Young JM, van Zandwijk N. Incidence and survival trends for malignant pleural and peritoneal mesothelioma, Australia, 19822009. Occup Environ Med. 2016;73(3):187-94.  
16. Ministério da Saúde (BR). Diretrizes metodológicas: elaboração de diretrizes clínicas. Brasília: Ministério da Saúde; 2016.  
17. Ministério da Saúde (BR). ROBIS – Risk of Bias in Systematic Reviews: ferramenta para avaliar o risco de viés em revisões sistemáticas: orientações de uso. Brasília: Ministério da Saúde; 2017.  
18. Whiting PF, Rutjes AW, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, et al. QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. Ann Intern Med 2011;155(8):529-36.  
19. Ministério da Saúde (BR). Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. Brasília: Ministério da Saúde; 2014a.  
20. GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. Hamilton, ON: McMaster University; 2015 [Access 2019 jul 20]. Available from: https://gradepro.org.  
21. Woolhouse I, Bishop L, Darlison L, De Fonseka D, Edey A, Edwards J, et al. British Thoracic Society Guideline for the investigation and management of malignant pleural mesothelioma. Thorax. 2018;73(Suppl 1):i1-i30.  
22. Tossavainen A. Asbestos, asbestosis, and cancer: the Helsinki criteria for diagnosis and attribution. Consensus report. Scand J Work Environ Health. 1997;23(4):311-6.  
23. Carbone M, Ly BH, Dodson RF, Pagano I, Morris PT, Dogan UA, et al. Malignant mesothelioma: facts, myths, and hypotheses. J Cell Physiol. 2012;227(1):44-58.  
24. National Institute for Health and Care Excellence. Suspected cancer: recognition referral. London: NICE; 2015.  
25. Nickell LT Jr, Lichtenberger JP, Khorashadi L, Abbott GF, Carter BW. Multimodality imaging for chacterization, classification, and staging of malignant pleural mesothelioma. Radiographics. 2014;34(6):1692-706.  
26. Benamore RE, O’Doherty MJ, Entwisle JJ. Use of imaging in the menagement of malignant pleural mesothelioma. Clin Radiol. 2005;60(12):1237-47.  
27. Marom EM, Erasmus JJ, Pass HI, Patz EF Jr. The role of imaging in malignant pleural mesothelioma. Semin Oncol. 2002;29(1):26-35.  
28. Hallifax RJ, Haris M, Corcoran JP, Leyakathalikhan S, Brown E, Srikantharaja D, et al. Role of CT in assessing pleural malignancy prior to thoracoscopy. Thorax. 2015;70(2):192-3.  
29. Treglia G, Sadeghi R, Annunziata S, Lococo F, Cafarotti S, Bertagna F, et al. Diagnostic accuracy of 18F-FDG-PET and PET/CT in the differential diagnosis between malignant and benign pleural lesions: a systematic review and meta-analysis. Acad Radiol. 2014;21(1):11-20.  
30. Abe Y, Tamura K, Sakata I, Ishida J, Ozeki Y, Tamura A, et al. Clinical implications of 18F-fluorodeoxyglucose positron emission tomography/computed tomography at delayed phase for diagnosis and prognosis of malignant pleural mesothelioma. Oncol Rep. 2012;27(2):333-8.  
31. Yildirim H, Metintas M, Entok E, Ak G, Ak I, Dundar E, Erginel S. Clinical value of fluorodeoxyglucose-positron emission tomography/computed tomography in differentiation of malignant mesothelioma from asbestos-related benign pleural disease: an observational pilot study. J Thorac Oncol. 2009;4(12):1480-4.  
32. Gill RR, Umeoka S, Mamata H, Tilleman TR, Stanwell P, Woodhams R, et al. Diffusion-weighted MRI of malignant pleural mesothelioma: preliminary assessment of apparent diffusion coeffcient in histologic subtypes. AJR Am J Roentgenol. 2010;195(2):W125-30.  
33. Coolen J, De Keyzer F, Nafteux P, De Wever W, Dooms C, Vansteenkiste J, et al. Malignant pleural mesothelioma: visual assessment by using pleural pointillism at diffusion-weighted MR imaging. Radiology. 2015;274(2):576-84.  
34. Seely JM, Nguyen ET, Churg AM, Müller NL. Malignant pleural mesothelioma: computed tomography and correlation with histology. Eur J Radiol. 2009;70(3):485-91.  
35. Okten F, Köksal D, Onal M, Ozcan A, Simşek C, Ertürk H. Computed tomography fndings in 66 patients with malignant pleural mesothelioma due to environmental exposure to asbestos. Clin Imaging. 2006;30(3):177-80.  
36. Knuuttila A, Kivisaari L, Kivisaari A, Palomäki M, Tervahartiala P, Mattson K. Evaluation of pleural disease using MR and CT. With special reference to malignant pleural mesothelioma. Acta Radiol. 2001;42(5):502-7.  
37. Metintas M, Ucgun I, Elbek O, Erginel S, Metintas S, Kolsuz M, et al. Computed tomography features in malignant pleural mesothelioma and other commonly seen pleural diseases. Eur J Radiol. 2002;41(1):1-9.  
38. Hierholzer J, Luo L, Bittner RC, Stroszczynski C, Schröder RJ, Schoenfeld N, et al. MRI and CT in the differential diagnosis of pleural disease. Chest. 2000;118(3):604-9.  
39. Leung AN, Müller NL, Miller RR. CT in differential diagnosis of diffuse pleural disease. AJR Am J Roentgenol. 1990;154(3):487-92.  
40. Yilmaz U, Polat G, Sahin N, Soy O, Gülay U. CT in differential diagnosis of benign and malignant pleural disease. Monaldi Arch Chest Dis. 2005;63(1):17-22.  
41. Qureshi NR, Rahman NM, Gleeson FV. Thoracic ultrasound in the diagnosis of malignant pleural effusion. Thorax. 2009;64(2):139-43.  
42. Kim YK, Kim JS, Lee KW, Yi CA, Goo JM, Jung SH. Multidetector CT findings and differential diagnoses of malignant pleural mesothelioma and metastatic pleural disease in Korea. Korean J Radiol. 2016;17(4):545-53.  
43. Aerts JG, Delahave M, van der Kwast TH, Davidson B, Hoogsteden HC, van Meerbeeck JP. The high post-test probability of a cytological examination renders further investigations to establish a diagnosis of epithelial malignant pleural mesothelioma redundant. Diagn Cytopathol. 2006;34(8):523-7.  
44. Segal A, Sterrett GF, Frost FA, Shilkin KB, Olsen NJ, Musk AW, et al. A diagnosis of malignant pleural mesothelioma can be made by effusion cytology: results of a 20-year audit. Pathology. 2013;45(1):44-8.  
45. Fassina A, Fefeli U, Corradin M, Da Frè M, Fabbris L. Accuracy and reproducibility of pleural effusion cytology. Leg Med (Tokyo). 2008;10(1):20-5.  
46. Husain AN, Colby TV, Ordóñez NG, Allen TC, Attanoos RL, Beasley MB, et al. Guidelines for Pathologic Diagnosis of Malignant Mesothelioma 2017 Update of the Consensus Statement From the International Mesothelioma Interest Group. Arch Pathol Lab Med. 2018;142(1):89-108.  
47. Cicogonetti M, Lonardi S, Fisogni S, Balzarini P, Pellegrini V, Tironi A, et al. BAP1 (BRCA1-associated protein 1) is a highly specific marker for differentiating mesothelioma from reactive mesothelial proliferations. Mod Pathol. 2015;28(8):1043-57.  
48. Maskell NA, Butland RJ; Pleural Diseases Group, Standards of Care Committee, British Thoracic Society. BTS guidelines for the investigation of a unilateral pleural effusion in adults. Thorax. 2003;58 Suppl 2:ii8-17.  
49. Whitaker D, Shilkin KB. Diagnosis of pleural malignant mesothelioma in life: a practical approach. J Pathol. 1984;143(3):147-75.  
50. Rahman NM, Ali NJ, Brown G, Chapman SJ, Davies RJ, Downer NJ, et al. Local anaesthetic thoracoscopy: British Thoracic Society pleural disease guideline 2010. Thorax. 2010;65 Suppl 2:ii54-60.  
51. Báez-Saldaña R, Rumbo-Nava U, Escobar-Rojas A, Castillo-González P, LeónDueñas S, Aguirre-Pérez T, et al. Accuracy of closed pleural biopsy in the diagnosis of malignant pleural effusion. J Bras Pneumol. 2017;43(6):424-30.  
52. Boutin C, Rey F, Gouvernet J, Viallat JR, Astoul P, Ledoray V. Thoracoscopy in pleural malignant mesothelioma: a prospective study of 188 consecutive patients. Part 2: Prognosis and staging. Cancer. 1993;72(2):394-404.  
53. Maskell NA, Gleeson FV, Davies RJ. Standard pleural biopsy versus CT-guided cutting-needle biopsy for diagnosis of malignant disease in pleural effusions: a randomised controlled trial. Lancet. 2003;361(9366):1326-30.  
54. Adams RF, Gleeson FV. Percutaneous image-guided cutting-needle biopsy of the pleura in the presence of a suspected malignant effusion. Radiology. 2001;219(2):510-4.  
55. Heilo A, Stenwig AE, Solheim OP. Malignant pleural mesothelioma: US-guided histologic core-needle biopsy. Radiology. 1999;211(3):657-9.  
56. Scherpereel A. Guidelines of the French Speaking Society for Chest Medicine for management of malignant pleural mesothelioma. Respir Med. 2007;101(6):1265-76.  
57. Metintas M, Ak G, Dundar E, Yildirim H, Ozkan R, Kurt E, et al. Medical thoracoscopy vs CT scan-guided Abrams pleural needle biopsy for diagnosis of patients with pleural effusions: a randomized, controlled trial. Chest. 2010;137(6):1362-8.  
58. Heffner JE. Klein JS. Recent advances in the diagnosis and management of malignant pleural effusions. Mayo Clin Proc. 2008;83(2):235-50.  
59. Alraiyes AH, Dhillon SS, Harris K, Kaphle U, Kheir F. Medical thoracoscopy: Technique and application. Pleura. 2016;3:1-11.  
60. Anevlavis S, Froudarakis ME. Advances in pleuroscopy. Clin Respir J. 2018;12(3):839-847.  
61. Geltner C, Errhalt P, Baumgartner B, Ambrosch G, Machan B, Eckmayr J, et al. Management of malignant pleural mesothelioma - part 1: epidemiology, diagnosis, and  
staging: Consensus of the Austrian Mesothelioma Interest Group (AMIG). Wien Klin Wochenschr. 2016;128(17-18):611-7.  
62. Pinto C, Ardizzoni A, Betta PG, Facciolo F, Tassi G, Tonoli S, et al. Expert opinions of the first italian consensus conference on the management of malignant pleural mesothelioma. Am J Clin Oncol. 2011;34(1):99-109.  
63. Organização Mundial de Saúde. Classificação International de Doenças. Disponível em: https://icd.who.int/browse11/l-m/en  
64. Travis WD, Brambilla E, Burke AP, Marx A, Nicholson AG. WHO Classification of Tumours of the Lung, Pleura, Thymus and Heart. 4th ed. Lyon: IARC Press; 2015. World Health Organization Classification of Tumours; vol 7.  
65. Brcic L, Jakopovic M, Brcic I, et al. Reproducibility of histological subtyping of malignant pleural mesothelioma. Virchows Arch. 2014; 465 (6): 679-685.  
66. Churg A, Cagle PT, Roggli VL, eds. Tumors of Serosal Membranes. In: Armed Forces Institute of Pathology. AFIP Atlas of Tumor Pathology. Silver Spring, MD: AFIP; 2006. 4th series, fascicle 3.  
67. Kawai T, Hiroi S, Nakanishi K, Takagawa K, Haba R, Hayashi K, et al. Lymphohistiocytoid mesothelioma of the pleura. Pathol Int. 2010;60(8):566-74.  
68. Travis WD. Sarcomatoid neoplasms of the lung and pleura. Arch Pathol Lab Med. 2010;134(11):1645-58.  
69. Cagle PT. Pleural histology. In: Light RW, Lee YCG. Pleural Disease: An International Textbook. London: Arnold Publishers; 2003. p. 249-255.  
70. Allen TC. Recognition of histiopathologic patterns of diffuse malignant mesothelioma in differential diagnosis of pleural biopsies. Arch Pathol Lab Med. 2005;129(11):141520.  
71. Al-Saffar N, Hasleton PS, Vimentin HPS. Vimentin, carcinoembryonic antigen and keratin in the diagnosis of mesothelioma, adenocarcinoma and reactive pleural lesions. Eur Respir J. 1990;3(9):997-1001.  
72. Abutaily AS, Addis BJ, Roche WR. Immunohistochemistry in the distinction between malignant mesothelioma and pulmonary adenocarcinoma: a critical evaluation of new antibodies. J Clin Pathol. 2002;55(9):662-8.  
73. Bakir K, Koçer NE, Deniz H, Güldür ME. TTF-1 and surfactant-B as co-adjuvants in the diagnosis of lung adenocarcinoma and pleural mesothelioma. Ann Diagn Pathol. 2004;8(6):337-41.  
74. Brockstedt U, Gulyas M, Dobra K, Dejmek A, Hjerpe A. Optimized battery of eight antibodies that can distinguish most cases of epithelial mesothelioma from carcinoma. Am J Clin Pathol. 2000;114(2):203-9.  
75. Brown RW, Clark GM, Tandon AK, Allred DC. Multiple-marker immunohistochemical phenotypes distinguishing malignant pleural mesothelioma from pulmonary adenocarcinoma. Hum Pathol. 1993;24(4):347-54.  
76. Cagle P, Brown R, Lebovitz R. p53 immunostaining in the differentiation of reactive processes from malignancy in pleural biopsy specimens. Hum Pathol. 1994;25(5):443-8.  
77. Carella R, Deleonardi G, D'Errico A, Salerno A, Egarter-Vigl E, Seebacher C, et al. Immunohistochemical panels for differentiating epithelial malignant mesothelioma from lung adenocarcinoma: a study with logistic regression analysis. Am J Surg Pathol. 2001;25(1):43-50.  
78. Chu PG, Weiss LM. Expression of cytokeratin 5⁄6 in epithelial neoplasms: an immunohistochemical study of 509 cases. Mod Pathol. 2002;15(1):6-10.  
79. Clover J, Oates J, Edwards C. Anticytokeratin 5⁄6: a positive marker for epithelioid mesothelioma. Histopathology. 1997;31(2):140-3.  
80. Collins CL, Ordonez NG, Schaefer R, Cook CD, Xie SS, Granger J, et al. Thrombomodulin expression in malignant pleural mesothelioma and pulmonaryadenocarcinoma. Am J Pathol. 1992;141(4):827-33.  
81. Comin CE, Dini S, Novelli L, Santi R, Asirelli G, Messerini L.h-Caldesmon, a useful positive marker in the diagnosis of pleural malignant mesothelioma, epithelioid type. Am J Surg Pathol. 2006;30(4):463-9.  
82. Comin CE, Novelli L, Boddi V, Paglierani M, Dini S. Calretinin, thrombomodulin, CEA, and CD15: a useful combination of immunohistochemical markers for differentiating pleural epithelial mesothelioma from peripheral pulmonary adenocarcinoma. Hum Pathol. 2001;32(5):529-36.  
83. Cury PM, Butcher DN, Fisher C, Corrin B, Nicholson AG. Value of the mesotheliumassociated antibodies thrombomodulin, cytokeratin 5⁄6, calretinin, and CD44H in distinguishing epithelioid pleural mesothelioma from adenocarcinoma metastatic to the pleura. Mod Pathol. 2000;13(2):107-12.  
84. Dejmek A, Brockstedt U, Hjerpe A. Optimization of a battery using nine immunocytochemical variables for distinguishing between epithelial mesothelioma and adenocarcinoma. APMIS. 1997;105(11):889-94.  
85. Dejmek A, Hjerpe A. Carcinoembryonic antigen-like reactivity in malignant mesothelioma. A comparison between different commercially available antibodies. Cancer. 1994;73(2):464-9.  
86. Di Loreto C, Puglisi F, Di Lauro V, Damante G, Beltrami C. TTF- 1 protein expression in pleural malignant mesotheliomas and adenocarcinomas of the lung. Cancer Lett. 1998;124(1):73-8.  
87. Gaffey MJ, Mills SE, Swanson PE, Zarbo RJ, Shah AR, Wick MR. Immunoreactivity for Ber-EP4 in adenocarcinomas, adenomatoid tumors, and malignant mesotheliomas. Am J Surg Pathol. 1992;16(6):593-9.  
88. Garcia-Prats MD, Ballestin C, Sotelo T, Lopez-Encuentra A, Mayordomo JI. A comparative evaluation of immunohistochemical markers for the differential diagnosis of malignant pleural tumours. Histopathology. 1998;32(5):462-72.  
89. González-Lois C, Ballestín C, Sotelo MT, López-Ríos F, García-Prats MD, Villena V. Combined use of novel epithelial (MOC-31) and mesothelial (HBME-1) immunohistochemical markers for optimal first line diagnostic distinction between mesothelioma and metastatic carcinoma in pleura. Histopathology. 2001;38(6):528-34.  
90. Grove A, Paulsen S, Gregersen M. The value of immunohistochemistry of pleural biopsy specimens in the differential diagnosis between malignant mesothelioma and metastatic carcinoma. Pathol Res Pract. 1994;190(11):1044-55.  
91. Gümürdülü D, Zeren EH, Cagle PT, Kayasel uk F, Alparslan N, Kocabas A, Tuncer I. Specificity of MOC-31 and HBME-1 immunohistochemistry in the differential diagnosis of adenocarcinoma and malignant mesothelioma: a study on environmental malignant mesothelioma cases from Turkish villages. Pathol Oncol Res. 2002;8(3):18893.  
92. He C, Wang B, Wan C. Yang T, Shen Y. Diagnostic value of D2-40 immunostaining for malignant mesothelioma: a meta-analysis. Oncotarget. 2017;8(38):64407-16.  
93. Kayser K, Böhm G, Blum S, Beyer M, Zink S, André S, Gabius HJ. Glyco- and immunohistochemical refinement of the differential diagnosis between mesothelioma and metastatic carcinoma and survival analysis of patients. J Pathol. 2001;193(2):175-80.  
94. Khoor A, Whitsett J, Stahlman M, Olson S, Cagle P. Utility of surfactant protein B precursor and thyroid transcription factor 1 in differentiating adenocarcinoma of the lung from mesothelioma. Hum Pathol. 1999;30(6):695-700.  
95. Leers MP, Aarts MM, Theunissen PH. E-cadherin and calretinin: auseful combination of immunochemical markers for differentiation between mesothelioma and metastatic adenocarcinoma. Histopathology. 1998;32(3):209-16.  
96. Moch H, Oberholzer M, Dalquen P, Wegmann W, Gudat F. Diagnostic tools for differentiating between pleural mesothelioma and lung adenocarcinoma in paraffin embedded tissue. Part I. Immunohistochemical findings. Virchows Arch A Pathol Anat Histopathol. 1993;423(1):19-27.  
97. Mimura T, Ito A, Sakuma T, Ohbayashi C, Yoshimura M, Tsubota N, et al. Novel marker D2-40, combined with calretinin, CEA, and TTF-1: an optimal set of immunodiagnostic markers for pleural mesothelioma. Cancer. 2007;109(5):933-8.  
98. Oates J, Edwards C. HBME-1, MOC-31, WT-1 and calretinin: an assessment of recently described markers for mesothelioma and adenocarcinoma. Histopathology. 2000;36(4):341-7.  
99. O’Hara C, Corson J, Pinkus G, Stahel R. ME1. A monoclonal antibody that distinguishes epithelial-type malignant mesothelioma from pulmonary adenocarcinoma and extrapulmonary malignancies. Am J Pathol. 1990;136(2):421-8.  
100. Ordóñez NG. Mesothelioma with signet-ring cell features: report of 23 cases. Mod Pathol. 2013;26(3):370-84.  
101. Ordóñez NG. The immunohistochemical diagnosis of mesothelioma: a comparative study of epithelioid mesothelioma and lung adenocarcinoma. Am J Surg Pathol. 2003;27(8):1031-51.  
102. Ordóñez NG. Value of thyroid transcription factor-1, E-cadherin, BG8, WT1, and CD44S immunostaining in distinguishing epithelial pleural mesothelioma from pulmonary and nonpulmonary adenocarcinoma. Am J Surg Pathol. 2000;24(4):598-606.  
103. Ordóñez NG. The value of antibodies 44-3A6, SM3, HBME-1, and thrombomodulin in differentiating epithelial pleural mesothelioma from lung adenocarcinoma. A  
comparative study with other commonly used antibodies. Am J Surg Pathol. 1997;21(12):1399-408.  
104. Ordóñez NG. Value of cytokeratin 5 ⁄ 6 in distinguishing epithelial mesothelioma of the pleura from lung adenocarcinoma. Am J Surg Pathol. 1998;22(10):1215-21.  
105. Ordóñez NG. Value of the MOC-31 monoclonal antibody in differentiating epithelial pleural mesothelioma from lung adenocarcinoma. Hum Pathol. 1998;29(2):166-9.  
106. Roberts F, Harper C, Downie I, Burnett R. Immunohistochemical analysis still has a limited role in the diagnosis of malignant mesothelioma. A study of thirteen antibodies. Am J Clin Pathol. 2001;116(2):253-62.  
107. Sheibani K, Shin SS, Kezirian J, Weiss LM. Ber-EP4 antibody as a discriminant in the differential diagnosis of malignant mesothelioma vs adenocarcinoma. Am J Surg Pathol. 1991;15(8):779-84.  
108. Soosay GN, Griffiths M, Papadaki L, Happerfield L, Bobrow L. The differential diagnosis of epithelial-type mesothelioma from adenocarcinoma and reactive mesothelial proliferation. J Pathol. 1991;163(4):299-305.  
109. Takeshima Y, Amatya VJ, Kushitani K, Kaneko M, Inai K. Value of immunohistochemistry in the differential diagnosis of pleural sarcomatoid mesothelioma from lung sarcomatoid carcinoma. Histopathology. 2009;54(6):667-76.  
110. Tuttle SE, Lucas JG, Bucci DM, Schlom J, Primus J. Distinguishing malignant mesothelioma from pulmonary adenocarcinoma: an immuno-histochemical approach using a panel of monoclonal antibodies. J Surg Oncol. 1990;45(2):72-8.  
111. Wick MR, Loy T, Mills SE, Legier JF, Manivel JC. Malignant epithelioid pleural mesothelioma versus peripheral pulmonary adenocarcinoma: a histochemical, ultrastructural, and immunohistologic study of 103 cases. Hum Pathol. 1990;21(7):75966.  
112. Wirth P, Legier J, Wright GL Jr. Immunohistochemical evaluation of seven monoclonal antibodies for differentiation of pleural mesohelioma from lung adenocarcinoma. Cancer. 1991;67(3):655-62.  
113. Husain AN, Colby T, Ordonez N, Krausz T, Attanoos R, Beasley MB, et al. Guidelines for Pathologic Diagnosis of Malignant Mesothelioma 2012. Update of the Consensus Statement from the International Mesothelioma Interest Group. Arch Pathol Lab Med. 2013;137(5):647-67.  
<mark>114. Dodson RF, O’Sullivan M, Corn CJ, Mclarty JW, Hammar SP. Analysis of asbestos fiber burden in lung tissue from mesothelioma patients. Ultrastruct Pathol. 1997;21(4):321-36.</mark>  
115. Churg AM, Warnock ML. Asbestos and other ferruginous bodies. Am J Pathol 1981;102(3):447-55.  
116. Dail DH, Hammar SP. Pulmonary Pathology. New York: Springer Verlag; 1988. p. 619-24.  
117. Davis JM, Gylseth B, Morgan A. Assessment of mineral fibres from human lung tissue. Thorax. 1986;41(3):167-75.  
118. Istituto Nazionale per L'assicurazione contro Gli Infortuni Sul Lavoro. Registro nazionale dei mesoteliomi. Quarto rapport. Roma: INAIL; 2012.  
119. Doll R, Peto R, Borehan J, Sutherland I. Mortality in relation to smoking: 50 years’ observations on male British doctors. BMJ. 2004;328(7455):1519.  
120. Thun MJ, Carter BD, Feskanich D, Freedman ND, Prentice R, Lopez AD, et al. 50Year trends in smoking-related mortality in the United States. N Engl J Med. 2013;368(4):351-64.  
121. Pirie K, Peto R, Reeves GK, Green J, Beral V, Million Women Study Collaborator. The 21st century hazards of smoking and benefits of stopping: a prospective study of one million women in the UK. Lancet. 2013;381(9861):133-41.  
122. Wolff H, Vehmas T, Oksa P, Rantanen J, Vainio H. Asbestos, asbestosis, and cancer, the Helsinki criteria for diagnosis and attribution 2014: recommendations. Scand J Work Environ Health. 2015;41(1):5-15.  
123. Barbieri PG. On the diagnosis of malignant pleural mesothelioma: a necropsy-based study of 171 cases (1997-2016). Tumori. 2019;105(4):361-2.  
124. Robinson BW, Creaney J, Lake R, Nowak A, Musk AW, de Klerk N, et al. Mesothelin-family proteins and diagnosis of mesothelioma. Lancet. 2003;362(9396):1612-6.  
125. Carbone M, Kanodia S, Chao A, Miller A, Wali A, Weissman D, et al. Consensus Report of the 2015 Weinman International Conference on Mesothelioma. J Thorac Oncol. 2016;11(8):1246-62.  
126. Cui A, Jin XG, Zhai K, Tong ZH, Shi HZ. Diagnostic values of soluble mesothelinrelated peptides for malignant pleural mesothelioma: updated meta-analysis. BMJ Open. 2014;4(2):e004145.  
127. Hollevoet K, Reitsma JB, Creaney J, Grigoriu BD, Robinson BW, et al. Serum Mesothelin for Diagnosing Malignant Pleural Mesothelioma: An Individual Patient Data Meta-Analysis. J Clin Oncol. 2012;30(13):1541-9.  
128. Pei D, Li Y, Liu X, Yan S, Xialon G, Xu X, Guo X. Diagnostic and prognostic utilities of humoral fibulin-3 in malignant pleural mesothelioma: Evidenc from a metaanalysis. Oncotarget. 2017;8(8):13030-8.  
129. Ren R, Yin P, Zhang Y, Zhou J, Zhou Y, Xu R, Lin H, Huang C. Diagnostic value of fibulin-3 for malignant pleural mesothelioma: A systematic review and meta-analysis. Oncotarget. 2016;7(51):84851-9.  
130. Lin H, Shen YC, Long HY, Wang H, Luo ZY, Wei ZX, et al. Performance of osteopontin in the diagnosis of malignant pleural mesothelioma: A meta-analysis. Int J Clin Exp Med. 2014;7(5):1289-96.  
131. Cristaudo A, Bonotti A, Guglielmi G, Fallahi P, Foddis R. Serum mesothelin and other biomarkers: what have we learned in the last decade?  J Thorac Dis. 2018;10 Suppl 2:S353-S359.  
132. Bij S, Schaake E, Koffijberg H, Burgers JA, de Mol BAJM, Moons KGM. Markers for the non-invasive diagnosis of mesothelioma: a systematic review. Br J Cancer. 2011;104(8):1325-33.  
133. Shi HZ, Liang QL, Jiang J, Qin XJ, Yang HB. Diagnostic value of carcinoembryonic antigen in malignant pleural effusion: a meta-analysis. Respirology. 2008;13(4):518-27.  
134. Creaney J, Disk IM, Robinson BW. Comparison of mesothelin and fibulin-3 in pleural fluid and sérum as markers in malignant mesothelioma. Curr Opin Pulm Med. 2015;21(4):352-6.  
135. Creaney J, Robinson BWS. Malignant Mesothelioma Biomarkers: From Discovery to Use in Clinical Practice for Diagnosis, Monitoring, Screening, and Treatment. Chest. 2017;152(1):143-9.  
136. Panou V, Vyberg M, Weinreich UM, Meristoudis C, Falkmer UG, Roe OD. The established and future biomarkers of malignant pleural mesothelioma. Cancer Treat Rev. 2015;41(6):486-95.  
137. Hu ZD, Liu XF, Liu Xc, Ding CM, Hu CJ. Diagnostic accuracy of osteopontin for malignant pleural mesothelioma: a systematic review and meta-analysis. Clin Chim Acta. 2014;433:44-8.  
138. Ministério da Saúde (BR). Portaria nº 483/GM/MS, de 01 de abril de 2014.  Redefine a Rede de Atenção à Saúde das Pessoas com Doenças Crônicas no âmbito do Sistema Único de Saúde (SUS) e estabelece diretrizes para a organização das suas linhas de cuidado. 2014.  
139. Ministério da Saúde (BR). Portaria nº 874, de 16 de maio de 2013. Institui a Política Nacional para a Prevenção e Controle do Câncer na Rede de Atenção à Saúde das Pessoas com Doenças Crônicas no âmbito do Sistema Único de Saúde (SUS). 2013.  
140. Ministério da Saúde (BR). Portaria nº 1.399/SAES, de 17 de dezembro de 2019. Redefine os critérios e parâmetros referenciais para a habilitação de estabelecimentos de saúde na alta complexidade em oncologia no âmbito do SUS. 2019.  
141. Brasil. Ministério da Saúde. Secretaria de Atenção Especializada à Saúde. Estabelecimentos de Saúde habilitados na alta complexidade em Oncologia no SUS. <u>https://www.saude.gov.br/atencao-especializada-e-hospitalar/especialidades/oncologia .</u>  
142. Comissão Intergestores Tripartite. Resolução nº 41/CIT, de 31 de outubro de 2018. Dispõe sobre as diretrizes para a organização dos cuidados paliativos, à luz dos cuidados continuados integrados, no âmbito Sistema Único de Saúde (SUS). Diário Oficial da União; 2018.  
143. Li D, Wang B , Long H, Wen F. Diagnostic Accuracy of Calretinin for Malignant Mesothelioma in Serous Effusions: a Meta-analysis. Scientific Reports. 2015; 5: 9507.  
144. Porcel JM, Esquerda A, Vives M, Bielsa S. Etiology of Pleural Effusions: Analysis of More Than 3,000 Consecutive Thoracenteses. Arch Bronconeumol. 2014;50(5):161-5.  
145. Segal A, Sterrett GF, Frost FA, Shilkin KB, Olsen NJ, Musk AW, Nowak AK, Bruce William S. Robinson BWS, Creaney J. A diagnosis of malignant pleural mesothelioma can be made by effusion cytology: results of a 20 year audit. Pathology. 2013; 45(1): 4448.  
146. Lovrenski A, Panjkovic M, Tegeltija D, Latinovic LT, Krcedinac J. The role of cytological evaluation of pleural fluid in diagnosing malignant mesothelioma. Med Pregl. 2012;65(1-2):5-8.  
147. Davies HE, Sadler RS, Bielsa S, Maskell NA, Rahman NM, Davies RJ, et al. Clinical impact and reliability of pleural fluid mesothelin in undiagnosed pleural effusions. Am J Respir Crit Care Med. 2009;180(5):437-44.  
148. Vazquez Oliva R, Panadero FR, Diez MVS, Castro AG. [Correlation between sensitivity of the cytogenetic and cytological analysis and thoracoscopic findings in the study of malignant pleural effusions]. Arch Bronconeumol. 1995;31(9):437-42.  
149. Prakash UB, Reiman HM. Comparison of needle biopsy with cytologic analysis for the evaluation of pleural effusion: analysis of 414 cases. Mayo Clin Proc. 1985;60(3):15864.  
150. King JE, Thatcher N, Pickering CAC, Hasleton PS. Sensitivity and specificity of immunohistochemical markers used in the diagnosis of epithelioid mesothelioma: a detailed systematic analysis using published data. Histopathology. 2006, 48: 223-232.  
151. Bossuyt P, Davenport C, Deeks J, Hyde C, Leeflang M, Scholten R. Interpreting results and drawing conclusions. In: Deeks JJ, Bossuyt PM, Gatsonis C (editors). Cochrane Handbook for Systematic Reviews of Diagnostic Test Accuracy Version 0.9. London: The Cochrane Collaboration; 2013.  
152. Silva Junior CT, Cardoso GP, Souza JBS, Alencar RA, Monteiro EA, Vilella C, Pessoa CLC, Monteiro NP. Prevalência de tuberculose pleural no ambulatório de pleurologia do Hospital Unibersitário Antônio Pedro. 2003. Pulmão RJ. 2003, 4:203-207.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **APÊNDICE 1** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **1.** **<u>Escopo e finalidade das Diretrizes</u>** -->
O Instituto Nacional de Câncer do Ministério da Saúde (INCA/SAES/MS) coordenou o trabalho de elaboração destas Diretrizes, com a finalidade de atender a uma demanda do Ministério Público do Trabalho.  
A proposta inicial de escopo foi redigida abrangendo nove questões entre os aspectos clínicos, de exames de imagem e de exames de anatomia patológcia, conforme apresentado no **Quadro A** . Esta proposta seguiu para o processo de enquete em maio de 2017 no sítio eletrônico da CONITEC, obtendo 11 contribuições no total. A maioria das contribuições foi dada por profissionais de saúde (7 de 11), sem sugestões de grandes alterações no escopo.  
**Quadro A -** Perguntas utilizadas para definir o escopo das Diretrizes para o Diagnóstico  
do Mesotelioma Maligno de Pleura  
|1|Deve-se realizar a história de exposição dirigida ao asbesto (ocupacional, para-<br>ocupacional, indireta, ambiental) no diagnóstico do mesotelioma maligno de<br><br>|
|---|---|
|2|~~l~~<br>~~?~~<br>Devem-se utilizar biomarcadores no diagnóstico de mesotelioma maligno de<br>pleura?|
|3|Quais os métodos de imagem (radiografia do tórax, USG, tomografia<br>computadorizada, ressonância magnética, PET-CT) devem ser empregados para o<br>diagnóstico do mesotelioma maligno de pleura?|
|4|Deve-se realizar a identificação de corpos e fibras de asbesto por<br>citologia/histologia no diagnóstico do mesotelioma de pleura?|
|5|Deve-se fazer a citologia do líquido pleural para o diagnóstico de mesotelioma<br>maligno de pleura?|
|6|Quais as técnicas de biópsia devem ser realizadas para o diagnóstico do<br>mesotelioma maligno de pleura?|
|7|Deve-se realizar a imuno-histoquímica para o diagnóstico do mesotelioma maligno<br>de pleura?|
|8|Deve-se realizar a microscopia eletrônica para o diagnóstico do mesotelioma<br>maligno de pleura?|
|9|Na ausência de material citológico ou de biópsia pode ser feito o diagnóstico do<br>mesotelioma maligno de pleura?|  
A primeira oficina de trabalho foi realizada em agosto de 2017 com a presença de representantes do Grupo Gestor de protocolos e diretrizes e do Grupo Elaborador destas diretrizes. Nesta oficina, foram definidas as equipes de trabalho e foi realizado um treinamento contemplando as etapas metodológicas de elaboração das Diretrizes.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **2.** **<u>Equipe de elaboração e partes interessadas</u>** -->
Representantes da Unidade Técnica de Exposição Ocupacional, Ambiental e Câncer do INCA/SAES/MS, da Fundação Jorge Duprat Figueiredo de Segurança e Medicina do Trabalho (FUNDACENTRO/Ministério do Trabalho), da Escola Nacional de Saúde Pública (ENSP/FIOCRUZ/MS) e do Departamento de Gestão e Incorporação de Tecnologias em Saúde, da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS) constituíram o Comitê Gestor deste projeto.  
O Grupo Elaborador incluiu profissionais especialistas da área de diferentes instituições do País e, pelo INCA, metodologistas pesquisadores do Núcleo de Avaliação de Tecnologias em Saúde (NATS) e bibliotecários estrategistas do Sistema Integrado de Bibliotecas do INCA.  
Todos os integrantes declararam não ter conflito de interesses na elaboração deste documento.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **<u>Colaboração externa</u>** -->
Para a elaboração destas Diretrizes, o Grupo Elaborador recebeu a contribuição de instituições parceiras, dentre os quais se destacam: o Hospital Moinhos de Vento/HMV, pelo Programa para o Desenvolvimento Institucional do SUS (PROADISUS); o Departamento Intersindical Estudos e Pesquisas de Saúde e Ambiente de Trabalho – DIESAT; e o Ministério Público do Trabalho – MPT.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **<u>Terapêuticas</u>** -->
Foi apresentada a primeira versão das Diretrizes na 75ª reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 17 de dezembro de 2019, com a participação de áreas técnicas do Ministério da Saúde e, após a análise e realização dos ajustes e correções sugeridas, foi por unanimidade decidido pautar o tema à reunião da Conitec.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **<u>Consulta pública</u>** -->
Na 86.ª Reunião Ordinária da Conitec, realizada nos dias 04 e 05 de março de 2020, os membros presentes emitiram deliberação favorável à proposta de PCDT, recomendando que o texto fosse submetido à consulta pública para o recebimento de contribuições da sociedade, de cunho científico ou relato de experiência, de forma a avaliar o interesse da população pelo tema, bem como agregar informações que pudessem contribuir com o texto preliminarmente proposto.  
Após recomendação preliminar favorável às Diretrizes Brasileiras para Diagnóstico de Mesotelioma Maligno de Pleura, a Consulta Pública nº 15/2020 foi realizada entre os dias 25 de março e 14 de abril de 2020 por meio de formulário específico no sítio eletrônico da Conitec.  
Foram recebidas 13 contribuições, as quais todas foram devidamente analisadas quanto ao escopo destas Diretrizes.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **3.** **<u>Busca da evidência</u>** -->
O desenvolvimento das Diretrizes seguiu o processo preconizado pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>16</sup> .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Critérios de Elegibilidade** -->
Os critérios de elegibilidade para cada pergunta de pesquisa foram definidos conforme os elementos PICO (P: população, I: intervenção/teste índice, C: comparador/padrão de referência, O: desfecho) descritos no **Quadro B** . Além disso, foram excluídos os artigos em idiomas diferentes de inglês e espanhol e aqueles não recuperados pelo Sistema Integrado de Bibliotecas.  
**Quadro B -** Critérios de elegibilidade para a seleção dos estudos  
|**Elemento**<br>**s PICO**|**Pergunta 1**|**Pergunta 2**|**Pergunta 3**|**Pergunta 4**|**Pergunta 5**|
|---|---|---|---|---|---|
|**Populaçã**<br>**o**|Adul|tos com suspeita|de mesoteliom|a maligno de p|leura|  
|**Índice**|Anamnese<br>B<br>re|iomarcado<br>s<br>Mé<br>im<br>(R<br>TC<br>PE<br>TC|todos de<br>agem<br>XT, USG,<br>, RNM,<br>T, PET-<br>) *|Ide<br>o d<br>e fi<br>asb<br>exa<br>pat|ntificaçã<br>e corpos<br>bras de<br>esto por<br>me<br>ológico|Citologia do<br>líquido<br>pleural|
|---|---|---|---|---|---|---|
|**Referênci**<br>**a**||Histo|patologia||||
|**Desfecho**|Acurác|ia diagnóstica (s|ensibilidad|e, es|pecificida|de)|
|**Elemento**<br>**s PICOS**|**Pergunta 6**|**Pergunta 7**|**Pergunt**|**a 8**|**Pergunt**|**a 9**|
|**Populaçã**<br>**o**|Adultos c|om suspeita de|mesoteliom|a ma|ligno de p|leura|
|**Índice**|Métodos de<br>biópsia<br>(percutânea cega<br>ou guiada por<br>imagem;<br>toracoscopia ou<br>video-assistida)|Imunohistoq<br>uí-mica|Microsco<br>eletrônic|pia<br>a|Critérios<br>diagnósti<br>ausência<br>de biópsi<br>histopato|para<br>co na<br>de material<br>a para exame<br>lógico|
|**Referênci**<br>**a**||Histo|patologia||||
|**Desfecho**|Acurác|ia diagnóstica (s|ensibilidad|e, es|pecificida|de)|  
* RXT: Raixo X de tórax; USG: Ultrassonografia; TC: Tomografia computadorizada; RNM: Ressonância Nuclear Magnética; PET: Tomografia por emissão de pósitron; PETTC: Tomografia por emissão de pósitron acoplado a tomografia computadorizada.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Estratégias de Busca das Revisões Sistemáticas** -->
Uma busca estruturada por revisões sistemáticas foi realizada para cada uma das nove perguntas definidas no escopo destas Diretrizes. As bases bibliográficas consultadas foram MEDLINE (por meio do PubMED), EMBASE, The Cochrane Library e LILACS (por meio da BVS) e as estratégias utilizadas para cada base, respectivamente, são descritas a seguir.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **PUBMED** -->
(((“Medical History Taking”[mh] OR “Medical History Taking”[tiab] OR “Medical History”[tiab] OR “Health History”[tiab] OR anamnes*[tiab] OR interview*[tiab]) AND  
(Asbestos[mh] OR Asbesto*[tiab])) AND (mesothelioma[mh] OR Mesothelioma*[tiab] OR "mesothelioma, malignant"[nm])) NOT (animals[mh] NOT humans[mh]) NOT (Editorial[pt] OR Letter[pt] OR Case Reports[pt] OR Comment[pt]) AND (sensitiv*[Title/Abstract] OR sensitivity and specificity[MeSH Terms] OR diagnose[Title/Abstract] OR diagnosed[Title/Abstract] OR diagnoses[Title/Abstract] OR diagnosing[Title/Abstract] OR diagnosis[Title/Abstract] OR diagnostic[Title/Abstract] OR diagnosis[MeSH:noexp] OR diagnostic *[MeSH:noexp] OR diagnosis, differential[MeSH:noexp] OR diagnosis[Subheading:noexp])

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
(([mh mesothelioma] or Mesothelioma*:ti,ab) AND ([mh 'Medical History Taking'] or 'Medical History Taking':ti,ab or 'Medical History':ti,ab or 'Health History':ti,ab or anamnes*:ti,ab OR interview*:ti,ab OR exposure*:ti,ab) AND ([mh asbestos] OR Asbesto*:ti,ab) AND ([mh 'sensitivity and specificity'] or 'sensitivity and specificity':ti,ab or diagnose*:ti,ab or diagnosing:ti,ab or diagnosis:ti,ab or diagnostic:ti,ab or [mh diagnosis] or [mh diagnostic] or [mh 'diagnosis, differential'] or accuracy:ti,ab)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **LILACS** -->
((mh:mesotelioma OR tw:mesotel*) AND (mh:pleura OR tw:pleura*)) AND (mh:"anamnese" or OR Mh:"Medical History Taking" OR mh:anamnesis OR tw:anamneses* OR tw: "Medical History Taking" OR tw:anamnesis OR tw:interview$ OR tw:entrevista) AND (mh:"ASBESTO" OR tw:"ASBESTO" OR tw: amianto) AND (instance:"regional") AND (db:("LILACS"))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'pleura mesothelioma'/exp OR 'malignant pleura mesothelioma':ti,ab OR 'malignant pleural mesothelioma':ti,ab OR 'mesothelioma pleurae':ti,ab OR 'pleura mesothelioma':ti,ab OR 'pleural mesothelioma':ti,ab) AND ('anamnesis'/exp OR anamnesis:ti,ab OR 'history taking':ti,ab OR 'medical history taking':ti,ab OR 'medical interview':ti,ab OR 'patient history taking':ti,ab) AND ('asbestos'/exp OR asbestos:ti,ab OR asbest:ti,ab OR amianto:ti,ab) AND ('sensitivity and specificity'/exp OR 'sensitivity and specificity':ti,ab OR 'accuracy'/exp OR 'accuracy':ti,ab OR 'diagnostic accuracy'/exp OR 'accuracy, diagnostic':ti,ab OR 'diagnosis accuracy':ti,ab OR 'diagnostic accuracy':ti,ab OR 'diagnostic test accuracy':ti,ab OR diagnostic:ti,ab OR diagnosis:ti,ab OR diagnose*:ti,ab) AND [embase]/lim NOT [medline]/lim

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **PUBMED** -->
(mesothelioma[mh] OR Mesothelioma*[tiab] OR "mesothelioma, malignant"[nm]) AND (Osteopontin[mh] OR Osteopontin*[tiab] OR "Antigens, CD44"[mh] OR Hyaluronat*[tiab] OR megakaryocyte[mh] OR megakaryocyt*[tiab] OR SOMAscan[tiab] OR Proteomics[mh] OR Proteomic*[tiab] OR Cytokines[mh] OR midkine[tiab] OR microRNAs[mh] OR microRNA*[tiab] OR "Biomarkers, Tumor"[mh] OR Biomarker*[tiab] OR Biomarkers[mh] OR Serum[tiab]) AND systematic[sb]

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'neoplasms, mesothelial':ti,ab OR 'pleura mesothelioma'/exp OR 'malignant pleura mesothelioma':ti,ab OR 'malignant pleural mesothelioma':ti,ab OR 'mesothelioma pleurae':ti,ab OR 'pleura mesothelioma':ti,ab OR 'pleural mesothelioma':ti,ab) AND (‘mesothelin’/exp OR mesothelin:ti,ab OR 'osteopontin'/exp OR 'spp1 protein':ti,ab OR 'bone sialoprotein 1':ti,ab OR 'osteopontin':ti,ab OR 'protein spp1':ti,ab OR 'secreted phosphoprotein 1':ti,ab OR 'hermes antigen'/exp OR 'cd44 antigen':ti,ab OR 'h cam':ti,ab OR 'hermes antigen':ti,ab OR 'antigen cd44':ti,ab OR 'antigens, cd44':ti,ab OR 'cdw44 antigen':ti,ab OR 'fibulin 3'/exp OR 'fibulin 3':ti,ab OR 'hyaluronic acid'/exp OR hyaluronate:ti,ab OR 'megakaryocyte'/exp OR 'karyocyte, mega':ti,ab OR 'megakaryocyte':ti,ab OR 'megakaryocytes':ti,ab OR somascan:ti,ab OR 'proteomics'/exp OR proteomic*:ti,ab OR 'cytokine'/exp OR 'cytokine':ti,ab OR 'cytokines':ti,ab OR 'interleukin':ti,ab OR 'midkine'/exp OR 'midkine':ti,ab OR 'microrna'/exp OR 'mirna':ti,ab OR 'mirnas':ti,ab OR 'micro rna':ti,ab OR 'microrna':ti,ab OR 'micrornas':ti,ab OR 'tumor marker'/exp OR 'serum biomark*':ti,ab) AND ('systematic review'/exp OR 'review, systematic':ti,ab OR 'systematic review':ti,ab OR 'meta analysis'/exp OR 'analysis, meta':ti,ab OR 'meta analysis':ti,ab OR 'meta-analysis':ti,ab OR 'metaanalysis':ti,ab) AND [embase]/lim NOT [medline]/lim AND ('article'/it OR 'article in press'/it OR 'review'/it)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
([mh mesothelioma] or Mesothelioma*:ti,ab) and ([mh Osteopontin] or Osteopontin*:ti,ab or [mh "Antigens, CD44"] or Hyaluronat*:ti,ab or [mh megakaryocyte] or megakaryocyt*:ti,ab or SOMAscan:ti,ab or [mh Proteomics] or Proteomic*:ti,ab or [mh Cytokines] or midkine:ti,ab or [mh microRNAs] or microRNA*:ti,ab or [mh "Biomarkers, Tumor"] or Biomarker*:ti,ab or [mh Biomarkers] or Serum:ti,ab OR mesothelin:ti,ab)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **LILACS** -->
(mh:mesothelioma OR tw:Mesothelioma* OR tw:mesotelioma) AND (tw:"Biomarcadores séricos" OR tw:serico* OR tw:serum OR tw:"marcadores tumorais" OR tw:biomarcador* OR tw:mesotelin* OR tw:mesothelin OR mh:Osteopontin OR tw:Osteopontin* OR mh:"Antigens, CD44" OR tw:Hyaluronat* OR tw: hialunorato OR mh:megakaryocyte OR tw:megacarioc* OR tw:SOMAscan OR mh:Proteomics OR tw:Proteomic* OR mh:Cytokines OR tw:midcine OR tw:midcyn* OR mh:microRNAs OR tw:microRNA*) AND ((TA:"Cochrane Database Syst Rev" or (((PT:"review" or MH:"review literature as topic" or MH:"meta-analysis as topic" or PT:"meta analysis" or PT:"consensus development conference" or PT:"practice guideline" or MH:"evidencebased medicine") OR (TW:"revisao sistematica" or TW:"revisoes sistematicas" or TW:"revision sistematica" or TW:"revisiones sistematicas" or TW:"systematic review" or TW:"systematic reviews" OR TI:Metaanal$ or (TI:Meta TI:analysis) or (TI:Meta TI:analis$) or ((tw:systematic$ or tw:sistemati$) and ((tw:predetermin$ or tw:inclus$ or tw:exclus$) and tw:criteri$))) OR ((TI:overview or TI:estudo$ or TI:estudio$ or TI:study or TI:revis$ or TI:review or TI:handsearch or TI:metodolog$ or TI:pesquisa or TI:busqueda or TI:busca or TI:search) and (TI:systematic$ or TI:sistemati$))) AND (((TW:overview$ or TW:estudo$ or TW:estudio$ or TW:study or TW:revis$ or TW:review or TW:handsearch$ or TW:metodolog$ or TW:pesquisa$ or TW:busqueda$ or TW:search$ or TW:"base de dados" or TW:"bases de dados" or TW:"bases de datos"  
or TW:"base de datos" or TW:database$ or TW:evidenc$) and (TW:systematic$ or TW:sistemati$)) or TW:Metaanal$ or (TW:Meta TW:analysis) or (TW:Meta TW:analis$) or (TW:Meta TW:analysis)))) AND NOT ((PT:letter OR PT:"newspaper article" OR PT:comment) OR (MH:animais OR MH:coelhos OR MH:ratos OR MH:camundongos OR MH:primatas OR MH:caes OR MH:gatos OR MH:suinos OR PT:"in vitro")))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **PUBMED** -->
((mesothelioma[mh] OR Mesothelioma*[tiab] OR "mesothelioma, malignant"[nm]) AND ((Imag*[tiab] AND Diagnos*[tiab]) OR ("Diagnostic Imaging"[mh] OR Ultrasonography[mh] OR Ultrasonography[sh] OR Ultrasonograph*[tiab] OR Magnetic Resonance Imaging[mh] OR Magnetic Resonance Imaging[tiab] OR MRI[tiab] OR "Tomography, X-Ray Computed"[mh] OR "CT"[tiab] OR Tomograph*[tiab] OR "PETCT"[tiab] OR "PET"[tiab] OR X-Rays[tiab] OR Radiograph*[tiab] OR Radiography[sh] OR "Positron Emission Tomography Computed Tomography"[mh]))) AND systematic[sb]

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
(('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'neoplasms, mesothelial':ti,ab OR 'pleura mesothelioma'/exp OR 'malignant pleura mesothelioma':ti,ab OR 'malignant pleural mesothelioma':ti,ab OR 'mesothelioma pleurae':ti,ab OR 'pleura mesothelioma':ti,ab OR 'pleural mesothelioma':ti,ab) AND ('diagnostic imaging'/exp OR 'diagnostic imaging':ti,ab OR 'imaging, diagnostic':ti,ab OR 'echography'/exp OR 'doptone':ti,ab OR 'duplex echography':ti,ab OR 'echogram':ti,ab OR 'echography':ti,ab OR 'echoscopy':ti,ab OR 'echosound':ti,ab OR 'high resolution echography':ti,ab OR 'scanning, ultrasonic':ti,ab OR 'sonogram':ti,ab OR 'sonography':ti,ab OR 'ultrasonic detection':ti,ab OR 'ultrasonic diagnosis':ti,ab OR 'ultrasonic echo':ti,ab OR 'ultrasonic examination':ti,ab OR 'ultrasonic scanning':ti,ab OR 'ultrasonic scintillation':ti,ab OR 'ultrasonography':ti,ab OR 'ultrasound diagnosis':ti,ab OR 'ultrasound scanning':ti,ab OR ultrasonogr*:ti,ab OR 'nuclear magnetic resonance imaging'/exp OR 'mri':ti,ab OR 'nmr imaging':ti,ab OR 'imaging, magnetization transfer':ti,ab OR 'magnetic resonance imaging':ti,ab OR 'magnetic resonance tomography':ti,ab OR 'magnetization transfer imaging':ti,ab OR 'mr imaging':ti,ab OR 'nuclear magnetic resonance imaging':ti,ab OR 'x-ray computed tomography'/exp OR 'ct scan':ti,ab OR 'ct scanning':ti,ab OR 'tomography, x-ray computed':ti,ab OR 'x-ray computed tomography':ti,ab OR ct:ti,ab OR 'pet-ct scanner'/exp OR 'aquiduo 16':ti,ab OR 'biograph 16':ti,ab OR 'biograph 16 hirez':ti,ab OR 'biograph mct':ti,ab OR 'discovery 690':ti,ab OR 'discovery ls':ti,ab OR 'discovery ste':ti,ab OR 'discovery vct':ti,ab OR 'gemini dual':ti,ab OR 'gemini gxl':ti,ab OR 'pet-ct scanner':ti,ab OR 'philips gemini tf':ti,ab OR 'reveal rt hirez':ti,ab OR 'x ray'/exp OR 'x ray':ti,ab OR 'radiation, roentgen':ti,ab OR 'roentgen radiation':ti,ab OR 'roentgen ray':ti,ab OR 'x radiation':ti,ab OR 'x ray radiation':ti,ab OR 'x-rays':ti,ab OR 'radiography'/exp OR 'x ray imaging':ti,ab OR 'electroradiography':ti,ab OR 'pneumoradiography':ti,ab OR 'radiogram':ti,ab OR 'radiographic method':ti,ab OR 'radiography':ti,ab OR 'radiography, dual-energy scanned projection':ti,ab OR 'radioimaging':ti,ab OR 'radiophotography':ti,ab OR 'roentgen photography':ti,ab OR 'roentgenography':ti,ab OR 'roentgenoscopy':ti,ab OR 'rontgenography':ti,ab OR 'x ray photography':ti,ab) AND ('systematic review'/exp OR 'review, systematic' OR 'systematic review' OR 'meta analysis'/exp OR 'analysis, meta':ti,ab OR 'meta analysis':ti,ab OR  
'meta-analysis':ti,ab OR 'metaanalysis':ti,ab)) AND [embase]/lim NOT [medline]/lim AND ('article'/it OR 'article in press'/it OR 'review'/it)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
(([mh mesothelioma] or Mesothelioma*:ti,ab) and pleura*:ti,ab) AND ((Imag*:ti,ab and Diagnos*:ti,ab) or ([mh "Diagnostic Imaging"] or [mh Ultrasonography] or [mh /DG] or Ultrason*:ti,ab or [mh "Magnetic Resonance Imaging"] or Magnetic Resonance:ti,ab or MRI:ti,ab or [mh "Tomography, X-Ray Computed"] or [mh "Tomography, EmissionComputed"] or [mh "Positron Emission Tomography Computed Tomography"] or "CT":ti,ab or Tomograph*:ti,ab or "PET-CT":ti,ab or "PET":ti,ab or X-Rays:ti,ab or Radiograph*:ti,ab))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **LILACS** -->
(mh:mesothelioma OR tw:Mesothelioma* OR tw:mesotelioma) AND ((tw:Imag* AND tw:Diagnos*) OR (mh:"Diagnostic Imaging" OR mh:Ultrasonography OR tw:Ultrason* OR mh:"Magnetic Resonance Imaging" OR tw:Magnetic Resonance OR tw:MRI OR tw:ressonanc* OR mh:"Tomography, X-Ray Computed" OR mh:"Tomography, Emission-Computed" OR mh:"Positron Emission Tomography Computed Tomography" OR tw:"CT" OR tw:Tomogra* OR tw:"PET-CT" OR tw:"PET" OR tw:X-Rays OR tw:raio X OR tw:Radiogra*)) AND ((TA:"Cochrane Database Syst Rev" or (((PT:"review" or MH:"review literature as topic" or MH:"meta-analysis as topic" or PT:"meta analysis" or PT:"consensus development conference" or PT:"practice guideline" or MH:"evidence-based medicine") OR (TW:"revisao sistematica" or TW:"revisoes sistematicas" or TW:"revision sistematica" or TW:"revisiones sistematicas" or TW:"systematic review" or TW:"systematic reviews" OR TI:Metaanal$ or (TI:Meta TI:analysis) or (TI:Meta TI:analis$) or ((tw:systematic$ or tw:sistemati$) and ((tw:predetermin$ or tw:inclus$ or tw:exclus$) and tw:criteri$))) OR ((TI:overview or TI:estudo$ or TI:estudio$ or TI:study or TI:revis$ or TI:review or TI:handsearch or TI:metodolog$ or TI:pesquisa or TI:busqueda or TI:busca or TI:search) and (TI:systematic$ or TI:sistemati$))) AND (((TW:overview$ or TW:estudo$ or TW:estudio$ or TW:study or TW:revis$ or TW:review or TW:handsearch$ or TW:metodolog$ or TW:pesquisa$ or TW:busqueda$ or TW:search$ or TW:"base de dados" or TW:"bases de dados" or TW:"bases de datos" or TW:"base de datos" or TW:database$ or TW:evidenc$) and (TW:systematic$ or TW:sistemati$)) or TW:Metaanal$ or (TW:Meta TW:analysis) or (TW:Meta TW:analis$) or (TW:Meta TW:analysis)))) AND NOT ((PT:letter OR PT:"newspaper article" OR PT:comment) OR (MH:animais OR MH:coelhos OR MH:ratos OR MH:camundongos OR MH:primatas OR MH:caes OR MH:gatos OR MH:suinos OR PT:"in vitro")))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Pergunta 4 PUBMED** -->
((((diagnosis[mh] OR diagnos*[tiab] OR diagnosis[sh]) AND (Mesothelioma[mh] OR Mesothel*[tiab] OR "mesothelioma, malignant"[nm])) AND (asbestos bod*[tiab] OR asbestos fiber*[tiab] OR asbestos fibre*[tiab])) AND ("Sensitivity and Specificity"[mh] OR "Predictive Value of Tests"[mh] OR Accuracy[tiab] OR Sensitivit*[tiab] OR Specificit*[tiab] OR "Positive Predictive"[tiab] OR "Negative Predictive"[tiab] OR "Likelihood Ratio"[tiab)) NOT (animals[mh] NOT humans[mh]) NOT (Editorial[pt] OR Letter[pt] OR Case Reports[pt] OR Comment[pt])

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
((([mh mesothelioma] or mesothel*:ti,ab) and ([mh diagnosis] or diagnos*:ti,ab)) and (asbestos body:ti,ab or asbestos fibers:ti,ab or asbestos fibres:ti,ab))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **BVS/LILACS** -->
tw:((tw:(mh:mesothelioma OR tw:mesothel* OR tw:mesotel*)) AND (tw:(mh:diagnosis OR tw:diagnos*)) AND tw:(tw:asbestos bod* OR tw:asbestos fiber* OR tw:asbestos fibre* OR tw:fibras de asbesto* OR tw:corpos de asbesto*)) AND (instance:"regional") AND (db:("LILACS"))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
(('diagnosis'/exp OR 'diagnosis':ti,ab OR 'diagnostic screening':ti,ab OR 'diagnostic sign':ti,ab OR 'diagnostic tool':ti,ab OR 'diagnostics':ti,ab OR 'disease diagnosis':ti,ab OR 'medical diagnosis':ti,ab OR 'physical diagnosis':ti,ab OR diagnos*:ti,ab) AND ('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR mesothelioma:ti,ab OR 'mesothelioma, cystic':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'mesotheliomatosis':ti,ab OR 'neoplasms, mesothelial':ti,ab OR mesothel*:ti,ab)) AND ('asbestos fibers':ti,ab OR 'asbestos fibres':ti,ab OR 'asbestos fibre':ti,ab OR 'asbestos fiber':ti,ab OR 'asbestos body':ti,ab OR 'asbesto body':ti,ab OR 'asbestos bodies':ti,ab) AND ('sensitivity and specificity'/exp OR 'sensitivity and specificity':ti,ab OR 'specificity and sensitivity':ti,ab OR 'accuracy'/exp OR 'accuracy':ti,ab OR 'precision':ti,ab)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Pergunta 5 PUBMED** -->
((mesothelioma[mh] OR Mesothelioma*[tiab] OR "mesothelioma, malignant"[nm]) AND ((cytolog*[tiab] OR "Cell Biology"[mh] OR "Cell Biology"[tiab] OR cytology[sh]) AND ("pleural fluid"[tiab] OR "Pleural Effusion"[mh] OR "Pleural Effusion"[tiab]))) AND ("Sensitivity and Specificity"[mh] OR "Predictive Value of Tests"[mh] OR Accuracy[tiab] OR Sensitivit*[tiab] OR Specificit*[tiab] OR "Positive Predictive"[tiab] OR "Negative Predictive"[tiab] OR "Likelihood Ratio"[tiab)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **LILACS** -->
tw:(((mh:"MESOTELIOMA/DI" OR mh:mesotelioma OR tw:mesotel*) AND (mh:pleura OR tw:pleura*)) AND (mh:patologia OR tw:patologia OR tw:citopatologia OR tw:pathology OR tw:histopat* OR tw:cytopat*) AND (mh:"derrame pleural" OR tw:"derrame pleural" OR tw:"liquido pleural" OR mh:"Pleural Effusion")) AND (instance:"regional") AND ( db:("LILACS"))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'pleura mesothelioma'/exp OR 'malignant pleura mesothelioma':ti,ab OR 'malignant pleural mesothelioma':ti,ab OR 'mesothelioma pleurae':ti,ab OR 'pleura mesothelioma':ti,ab OR 'pleural mesothelioma':ti,ab) AND ('pleura fluid'/exp OR 'pleura exsudate':ti,ab OR 'pleura exudate':ti,ab OR 'pleura fluid':ti,ab OR 'pleura liquid':ti,ab OR 'pleura transudate':ti,ab OR 'pleural exudate':ti,ab OR 'pleural exudation':ti,ab OR 'pleural fluid':ti,ab OR 'pleural transudate':ti,ab 'pleura effusion'/exp OR 'effusion, pleura':ti,ab OR 'pleura effusion':ti,ab OR 'pleural effusion':ti,ab OR 'pleurorrhea':ti,ab OR 'pleurorrhoea':ti,ab) AND ('cytology'/exp OR 'automated cytological technique':ti,ab OR 'cell biology':ti,ab OR 'cytological  
techniques':ti,ab OR 'cytology':ti,ab OR 'cytotechnology':ti,ab OR 'cytotest':ti,ab) AND ('sensibility'/exp OR 'sensibility':ti,ab OR 'sensitivity and specificity'/exp OR 'sensitivity and specificity':ti,ab OR 'specificity and sensitivity':ti,ab OR 'accuracy'/exp OR 'accuracy':ti,ab OR 'precision':ti,ab OR 'diagnostic accuracy'/exp OR 'accuracy, diagnostic':ti,ab OR 'diagnosis accuracy':ti,ab OR 'diagnostic accuracy':ti,ab OR 'diagnostic test accuracy':ti,ab OR 'predictive value'/exp OR 'negative predictive value':ti,ab OR 'positive predictive value':ti,ab OR 'predictive value':ti,ab OR 'predictive value of tests':ti,ab OR 'likelihood ratio'/exp OR 'likelihood ratio':ti,ab) AND [embase]/lim NOT [medline]/lim

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
([mh mesothelioma] or Mesothelioma*:ti,ab) AND (cytolog*:ti,ab OR [mh "Cell Biology"] OR "Cell Biology":ti,ab) AND ([mh "Pleural Effusion"] OR ((pleura*:ti,ab) AND (fluid*:ti,ab OR effusion*:ti,ab OR liquid*:ti,ab))) AND ([mh “sensitivity and specificity”] OR “sensitivity and specificity”:ti,ab OR Sensitivity:ti,ab OR accuracy:ti,ab OR precision:ti,ab OR accuracy:ti,ab OR diagnosis:ti,ab OR diagnostic:ti,ab OR [mh "Predictive Value of Tests"] OR “negative predictive value”:ti,ab OR “positive predictive value”:ti,ab OR “predictive value”:ti,ab OR “predictive value of tests”:ti,ab OR “likelihood ratio”:ti,ab)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **PUBMED** -->
((Mesothelioma[mh] OR Mesothel*[tiab] OR "mesothelioma, malignant"[nm]) AND (biopsy[mh] OR biops*[tiab] OR biopsy needle*[tiab] OR Thoracoscopy[mh] OR Thoracoscop*[tiab] OR "video-assisted thoracoscopic surgery"[tiab] OR VATS[tiab])) AND systematic[sb]

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'neoplasms, mesothelial':ti,ab OR 'pleura mesothelioma'/exp OR 'malignant pleura mesothelioma':ti,ab OR 'malignant pleural mesothelioma':ti,ab OR 'mesothelioma pleurae':ti,ab OR 'pleura mesothelioma':ti,ab OR 'pleural mesothelioma':ti,ab OR mesothel*:ti,ab) AND ('biopsy'/exp OR 'biopsy':ti,ab OR 'biopsy technique'/exp OR 'biopsy method':ti,ab OR 'biopsy procedure':ti,ab OR 'biopsy technique':ti,ab OR biops*:ti,ab OR 'biopsy needle'/exp OR 'oncontrol':ti,ab OR 'biopsy needle':ti,ab OR 'thoracoscopy'/exp OR 'pleural endoscopy':ti,ab OR 'thoracoscopy':ti,ab OR thoracoscop*:ti,ab OR 'video assisted thoracoscopic surgery'/exp OR 'vats':ti,ab OR 'thoracic surgery, video-assisted':ti,ab OR 'video assisted thoracic surgery':ti,ab OR 'video assisted thoracoscopic surgery':ti,ab OR 'videothoracoscopic surgery':ti,ab) AND ('systematic review'/exp OR 'review, systematic' OR 'systematic review' OR overview*) AND [embase]/lim NOT [medline]/lim

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
([mh mesothelioma] OR Mesotheli*:ti,ab) AND ([mh biopsy] OR biops*:ti,ab OR biopsy needle*:ti,ab OR [mh thoracoscopy] OR thoracoscop*:ti,ab OR "video-assisted thoracoscopic surgery":ti,ab OR VATS:ti,ab) **LILACS**  
tw:(((mh:mesothelioma OR tw:mesotheli* OR tw:mesotelioma*) AND (mh:biopsy OR tw:biops* OR tw:"biopsy needles" OR tw:"agulhas de biopsia" OR tw:"agujas de biopsia" OR mh:thoracoscopy OR tw:thoracoscop* OR tw:toracoscopia* OR tw:"video-assisted thoracoscopic surgery" OR tw:"cirurgia toracoscópica assistida por vídeo" OR tw:"cirugía toracoscópica asistida por vídeo" OR tw:VATS))) AND ((TA:"Cochrane Database Syst Rev" or (((PT:"review" or MH:"review literature as topic" or MH:"metaanalysis as topic" or PT:"meta analysis" or PT:"consensus development conference" or PT:"practice guideline" or MH:"evidence-based medicine") OR (TW:"revisao sistematica" or TW:"revisoes sistematicas" or TW:"revision sistematica" or TW:"revisiones sistematicas" or TW:"systematic review" or TW:"systematic reviews" OR TI:Metaanal$ or (TI:Meta TI:analysis) or (TI:Meta TI:analis$) or ((tw:systematic$ or tw:sistemati$) and ((tw:predetermin$ or tw:inclus$ or tw:exclus$) and tw:criteri$))) OR ((TI:overview or TI:estudo$ or TI:estudio$ or TI:study or TI:revis$ or TI:review or TI:handsearch or TI:metodolog$ or TI:pesquisa or TI:busqueda or TI:busca or TI:search) and (TI:systematic$ or TI:sistemati$))) AND (((TW:overview$ or TW:estudo$ or TW:estudio$ or TW:study or TW:revis$ or TW:review or TW:handsearch$ or TW:metodolog$ or TW:pesquisa$ or TW:busqueda$ or TW:search$ or TW:"base de dados" or TW:"bases de dados" or TW:"bases de datos" or TW:"base de datos" or TW:database$ or TW:evidenc$) and (TW:systematic$ or TW:sistemati$)) or TW:Metaanal$ or (TW:Meta TW:analysis) or (TW:Meta TW:analis$) or (TW:Meta TW:analysis)))) AND NOT ((PT:letter OR PT:"newspaper article" OR PT:comment) OR (MH:animais OR MH:coelhos OR MH:ratos OR MH:camundongos OR MH:primatas OR MH:caes OR MH:gatos OR MH:suinos OR PT:"in vitro"))) AND <u>(instance:"regional") AND (db:("LILACS"))</u>

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Pergunta 7 PUBMED** -->
((Immunohistochemistry[mh] OR Immunohisto*[tiab] OR Immunocyto*[tiab] OR Immunolog*[tiab] OR Immunostain*[tiab] OR Immuno-Gold[tiab]) AND (mesothelioma[mh] OR Mesothelioma*[tiab] OR "mesothelioma, malignant"[nm])) AND systematic[sb]

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
(('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'neoplasms, mesothelial':ti,ab OR 'pleura mesothelioma'/exp OR 'malignant pleura mesothelioma':ti,ab OR 'malignant pleural mesothelioma':ti,ab OR 'mesothelioma pleurae':ti,ab OR 'pleura mesothelioma':ti,ab OR 'pleural mesothelioma':ti,ab OR mesothel*:ti,ab) AND ('immunohistochemistry'/exp OR 'antigen staining':ti,ab OR 'histochemistry, immuno':ti,ab OR 'immunohistochemistry':ti,ab OR 'immunostaining':ti,ab OR immunohisto*:ti,ab OR immunocyto*:ti,ab OR immunolog*:ti,ab OR immunostain*:ti,ab OR 'immuno gold':ti,ab OR 'immunocytochemistry'/exp OR 'cytochemistry, immuno':ti,ab OR 'cytoimmunochemistry':ti,ab OR 'immunocytochemical staining':ti,ab OR 'immunocytochemistry':ti,ab)) AND ('systematic review'/exp OR 'review, systematic' OR 'systematic review' OR overview*) AND [embase]/lim NOT [medline]/lim

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
([mh mesothelioma] OR Mesotheli*:ti,ab) AND ([mh Immunohistochemistry] OR Immunohisto*:ti,ab OR Immunocyto*:ti,ab OR Immunolog*:ti,ab OR  
Immunostain*:ti,ab OR Immuno-Gold:ti,ab)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **LILACS** -->
tw:(tw:((mh:mesothelioma OR tw:mesotheli* OR tw:mesotelioma*) AND (mh:immunohistochemistry OR tw:immunohisto* OR tw:imunohisto* OR tw:immunocyto* OR tw:imunocito* OR tw:immunolog* OR tw:imunolog* OR tw:immunostain* OR tw:immuno-gold))) AND ((TA:"Cochrane Database Syst Rev" or (((PT:"review" or MH:"review literature as topic" or MH:"meta-analysis as topic" or PT:"meta analysis" or PT:"consensus development conference" or PT:"practice guideline" or MH:"evidence-based medicine") OR (TW:"revisao sistematica" or TW:"revisoes sistematicas" or TW:"revision sistematica" or TW:"revisiones sistematicas" or TW:"systematic review" or TW:"systematic reviews" OR TI:Metaanal$ or (TI:Meta TI:analysis) or (TI:Meta TI:analis$) or ((tw:systematic$ or tw:sistemati$) and ((tw:predetermin$ or tw:inclus$ or tw:exclus$) and tw:criteri$))) OR ((TI:overview or TI:estudo$ or TI:estudio$ or TI:study or TI:revis$ or TI:review or TI:handsearch or TI:metodolog$ or TI:pesquisa or TI:busqueda or TI:busca or TI:search) and (TI:systematic$ or TI:sistemati$))) AND (((TW:overview$ or TW:estudo$ or TW:estudio$ or TW:study or TW:revis$ or TW:review or TW:handsearch$ or TW:metodolog$ or TW:pesquisa$ or TW:busqueda$ or TW:search$ or TW:"base de dados" or TW:"bases de dados" or TW:"bases de datos" or TW:"base de datos" or TW:database$ or TW:evidenc$) and (TW:systematic$ or TW:sistemati$)) or TW:Metaanal$ or (TW:Meta TW:analysis) or (TW:Meta TW:analis$) or (TW:Meta TW:analysis)))) AND NOT ((PT:letter OR PT:"newspaper article" OR PT:comment) OR (MH:animais OR MH:coelhos OR MH:ratos OR MH:camundongos OR MH:primatas OR MH:caes OR MH:gatos OR MH:suinos OR PT:"in vitro"))) AND <u>(instance:"regional") AND (db:("LILACS"))</u>

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **PUBMED** -->
((("Microscopy, Electron, Transmission"[mh] OR microscop*[tiab] OR ultrastruct*[tiab] OR ultrastructure[sh]) AND (mesothelioma[mh] OR Mesothelioma*[tiab] OR "mesothelioma, malignant"[nm])) AND (pathology[sh] OR pathol*[tiab] OR immunohisto*[tiab] OR biopsy[mh] OR biops*[tiab] OR Cytopat*[tiab] OR histopat*[tiab])) NOT (animals[mh] NOT humans[mh]) NOT (Editorial[pt] OR Letter[pt] OR Case Reports[pt] OR Comment[pt]) AND (sensitiv*[Title/Abstract] OR sensitivity and specificity[MeSH Terms] OR diagnose[Title/Abstract] OR diagnosed[Title/Abstract] OR diagnoses[Title/Abstract] OR diagnosing[Title/Abstract] OR diagnosis[Title/Abstract] OR diagnostic[Title/Abstract] OR diagnosis[MeSH:noexp] OR diagnostic *[MeSH:noexp] OR diagnosis, differential[MeSH:noexp] OR diagnosis[Subheading:noexp])

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
(([mh mesothelioma] or Mesothelioma*:ti,ab) and pleura*:ti,ab) and ([mh "Microscopy, Electron, Transmission"] or microscop*:ti,ab or ultrastruct*:ti,ab or [mh /UL])

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **LILACS** -->
((mh:mesothelioma OR tw:Mesothelioma* OR tw:mesotel*) AND tw:pleura*) AND  
(mh:"Microscopy, Electron, Transmission" OR tw:microscop* OR tw:ultrastruct* OR tw:ultraestrut* OR mh:/UL)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'neoplasms, mesothelial':ti,ab OR 'pleura mesothelioma'/exp OR 'malignant pleura mesothelioma':ti,ab OR 'malignant pleural mesothelioma':ti,ab OR 'mesothelioma pleurae':ti,ab OR 'pleura mesothelioma':ti,ab OR 'pleural mesothelioma':ti,ab OR mesothel*:ti,ab) AND ('transmission electron microscopy'/exp OR 'electron microscopy, transmission':ti,ab OR 'microscopy, electron, transmission':ti,ab OR 'transmission electron microscopy':ti,ab OR microscop* OR ultrastruct*:ti,ab OR 'ultrastructure analysis and electron microscopy'/exp OR 'ultrastructure analysis and electron microscopy':ti,ab OR 'electron microscopy'/exp OR 'electromicroscopy':ti,ab OR 'electron microscopy':ti,ab OR 'electronmicroscopy':ti,ab OR 'high voltage electron microscopy':ti,ab OR 'ion microscopy':ti,ab OR 'microscopy, electron':ti,ab OR 'microscopy, ion':ti,ab OR 'stereo electron microscopy':ti,ab) AND ('pathology'/exp OR 'clinical pathology':ti,ab OR 'pathology':ti,ab OR 'pathology, clinical':ti,ab OR 'pathology, surgical':ti,ab OR pathol*:ti,ab OR immunohisto*:ti,ab OR 'biopsy'/exp OR 'biopsy':ti,ab OR biops*:ti,ab OR cytopat*:ti,ab OR histopat*:ti,ab) AND ('sensibility'/exp OR 'sensibility':ti,ab OR 'sensitivity and specificity'/exp OR 'sensitivity and specificity':ti,ab OR 'specificity and sensitivity':ti,ab OR 'accuracy'/exp OR 'accuracy':ti,ab OR 'precision':ti,ab OR 'diagnostic accuracy'/exp OR 'accuracy, diagnostic':ti,ab OR 'diagnosis accuracy':ti,ab OR 'diagnostic accuracy':ti,ab OR 'diagnostic test accuracy':ti,ab OR 'predictive value'/exp OR 'negative predictive value':ti,ab OR 'positive predictive value':ti,ab OR 'predictive value':ti,ab OR 'predictive value of tests':ti,ab OR 'likelihood ratio'/exp OR 'likelihood ratio':ti,ab) AND <u>[embase]/lim NOT [medline]/lim</u>

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Pergunta 9 PUBMED** -->
(((diagnosis[mh] OR diagnos*[tiab] OR diagnosis[sh]) AND (Mesothelioma[mh] OR Mesothel*[tiab] OR "mesothelioma, malignant"[nm])) AND (Guideline[ptyp] OR Practice Guideline[ptyp] OR guideline*[tiab] OR guidance*[tiab]))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **COCHRANE** -->
((([mh mesothelioma] OR Mesothel*:ti,ab) AND ([mh diagnosis] OR diagnos*:ti,ab)) AND (guideline:pt OR [mh “Guidelines as Topic”] OR [mh guideline] OR guideline*:ti,ab OR guidance*:ti,ab))

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **BVS/LILACS** -->
tw:((tw:(mh:mesothelioma OR tw:mesothel* OR tw:mesotel*)) AND (tw:(mh:diagnosis OR tw:diagnos*)) AND (type_of_study:(guideline))) AND (instance:"regional")

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **EMBASE** -->
((('diagnosis'/exp OR 'diagnosis':ti,ab OR 'diagnostic screening':ti,ab OR 'diagnostic sign':ti,ab OR 'diagnostic tool':ti,ab OR 'diagnostics':ti,ab OR 'disease diagnosis':ti,ab OR 'medical diagnosis':ti,ab OR 'physical diagnosis':ti,ab OR diagnos*:ti,ab) AND ('mesothelioma'/exp OR 'malignant mesothelioma':ti,ab OR 'mesothelioma':ti,ab OR  
'mesothelioma, cystic':ti,ab OR 'mesothelioma, malignant':ti,ab OR 'mesotheliomatosis':ti,ab OR 'neoplasms, mesothelial':ti,ab OR mesothel*:ti,ab)) AND ('consensus development'/de OR 'practice guideline'/de OR 'practice guideline'/exp OR 'clinical practice guidelines':ti,ab OR 'guidelines':ti,ab OR 'guidelines as topic':ti,ab OR 'practice guideline':ti,ab OR 'practice guidelines':ti,ab OR 'practice guidelines as topic':ti,ab OR guidance:ti,ab)) AND [embase]/lim NOT [medline]/lim AND ('article'/it OR 'article in press'/it OR 'review'/it)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Seleção das Evidências** -->
Para cada pergunta, uma dupla de especialistas avaliou de modo independente os títulos e resumos dos estudos quanto a sua elegibilidade de acordo com os critérios prédefinidos. Um metodologista do NATS/INCA validou essa etapa de seleção inicial e realizou busca manual na lista de referências dos artigos selecionados. As etapas seguintes de leitura completa, seleção final dos estudos, extração e avaliação da qualidade da evidência foram realizadas pelos metodologistas do NATS/INCA.  
Para algumas perguntas do escopo, as evidências recuperadas não foram suficientes para fornecer uma resposta e, em fevereiro de 2019, uma reestruturação para adequação metodológica da elaboração das Diretrizes foi proposta por consultores do Hospital Moinhos de Vento/PROADI-SUS. Assim, considerando que a investigação diagnóstica para MMP faz parte do fluxo de investigação de doenças pleurais malignas, necessitando especificamente de melhor definição relacionada ao diagnóstico diferencial com outros tipos de neoplasias da pleura, a elaboração de recomendações a partir do sistema GRADE foi utilizada para a pergunta sobre imuno-histoquímica, técnica de histopatologia indicada para a diferenciação entre neoplasias (pergunta 7). As outras perguntas foram respondidas como orientações científicas de boas práticas clínicas, utilizando como fonte adicional de evidências o “ _The BTS guideline for the investigation and management of pleural mesothelioma”_ desenvolvido pela _British Thoracic Society_ , publicado em 2018<sup>21</sup> . Este _guideline_ foi elaborado com base em revisões sistemáticas da literatura científica, seguindo um processo de elaboração acreditado pelo _National Institute for Clinical Excellence_ (NICE) do Reino Unido.  
Na **Tabela A** , apresentam-se com mais detalhes os resultados da busca e seleção para cada questão específica.  
**Tabela A -** Seleção final dos estudos para as nove questões PICO  
|**Questão**<br>**Estudos**|**Estudos Selecionados**|**Desenho do estudo**|
|---|---|---|  
||**Identificados**|||
|---|---|---|---|
|1|118|0|-|
|2|66|8|Revisão sistemática<br>com e sem meta-<br>análise|
|3|46|2|Coorte|
|4|92|0|-|
|5|209|8|Estudos de teste<br>diagnóstico|
|6|60|2|Ensaio clínico<br>randomizado e série<br>de casos|
|7|78|2|Revisão sistemática<br>com meta-análise|
|8|312|1|Caso-controle|
|9|223|0|-|
|Total|1209|23|-|  
Para as perguntas cuja busca permitiu identificar estudos que atendessem aos critérios de elegibilidade pré-definidos (perguntas 2, 5 e 7), os dados dos estudos selecionados foram extraídos e sumarizados. Para a pergunta 7 sobre a utilização de imuno-histoquímica para o diagnóstico de MMP, as revisões selecionadas foram atualizadas e oito meta-análises referentes aos resultados de acurácia dos marcadores selecionados foram conduzidas. A meta-análise das medidas de acurácia (sensibilidade, especificidade, valor preditivo e razão de chance diagnóstica) foi calculada por meio do modelo bivariado de efeitos aleatórios, com pacote _mada_ , utilizando o software R (versão 3.5.3). A avaliação da heterogeneidade entre os estudos foi feita com o cálculo do teste I- quadrado. A análise de viés de publicação foi feita utilizando o pacote _midas_ com o _software_ STATA 12.1.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Avaliação do Risco de Viés dos Estudos** -->
O risco de viés foi avaliado para os estudos selecionados para as perguntas 2, 5 e 7 com as ferramentas ROBIS-2<sup>17</sup> ou QUADAS-2<sup>18</sup> de acordo com o desenho de estudo,  
respectivamente, revisão sistemática ou estudo de teste diagnóstico.  
A seguir, apresenta-se a classificação do risco de viés para as perguntas 2 e 5, nas **Tabelas B e C** , respectivamente. Entre os estudos selecionados sobre o uso de biomarcadores (pergunta 2) observa-se que existe maior risco de viés na dimensão sobre a síntese dos resultados, uma vez que existe heterogeneidade na meta-análise calculada para sensibilidade e especificidade nas revisões sistemáticas, devido principalmente aos diferentes pontos de corte que cada estudo estabeleceu no protocolo de pesquisa.  
Para a pergunta 5, sobre a citologia do líquido pleural, os estudos selecionados apresentaram maior risco de viés em relação a seleção dos pacientes e sobre o teste índice, devido principalmente, a presença de recrutamento não aleatório, desenho caso-controle, exclusões inapropriadas devido ao material e falta de cegamento do avaliador sobre o diagnóstico do paciente.  
**Tabela B** - Classificação do risco de viés para a pergunta 2 – uso de biomarcadores para diagnóstico de MMP  
||**N**|||**Risco de Vi**|**és (ROBIS-2)**|||
|---|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|<br>**de**<br>**Est**<br>**udo**<br>**s**|**Biomarcad**<br>**or**|**1. Critérios**<br>**de**<br>**elegibilidad**<br>**e dos**<br>**estudos**|**2.**<br>**Identificaçã**<br>**o e seleção**<br>**dos estudos**|<br>**3. Coleta de**<br>**dados e**<br>**avaliação do**<br>**estudo**|**4. Síntese**<br>**dos**<br>**Resultados**|**Observação da dimensão com risco ALTO**<br>|
|Pei,<br>2017<sup>128</sup>|6|humoral<br>fibulin-3|BAIXO|ALTO|BAIXO|ALTO|2. Única fonte de dados utilizada (Pubmed); 4. Os estudos<br>incluídos na meta-análise apresentaram alta<br>heterogeneidade.Exclusão de estudonão justificada.|
|Ren,<br>2016<sup>129</sup>|8|humoral<br>fibulin-3|BAIXO|BAIXO|BAIXO|ALTO|4. Os estudos incluídos na meta-análise apresentaram alta<br>heterogeneidade e potencial risco de viés na seleção de<br>pacientes e no fluxo e tempo.|
|Li,<br>2015<sup>143</sup>|18|Calretinin|BAIXO|BAIXO|BAIXO|ALTO|4. Os estudos incluídos na meta-análise apresentaram alta<br>heterogeneidade.|
|Lin,<br>2014<sup>130</sup>|7|Osteoponti<br>n|ALTO|BAIXO|BAIXO|ALTO|1. Falta de critérios de eligibilidade relacionados ao PICO;<br>4. Os estudos incluídos na meta-análise apresentaram alta<br>heterogeneidade.|
|Cui,<br>2014<sup>126</sup>|30|soluble<br>mesothelin<br>related<br>peptides|ALTO|BAIXO|BAIXO|ALTO|1. Falta de critérios de eligibilidade relacionados ao PICO;<br>4. Os estudos incluídos na meta-análise apresentaram alta<br>heterogeneidade.|
|Hollevo<br>et,<br>2012<sup>127</sup>|16|Mesotelin|INCERTO|ALTO|ALTO|ALTO|1. Critério de elegibilidade para uma marca de kit<br>diagnóstico; 2. Foram utilizadas somente duas fontes de<br>informação e o estudo não informa como foi feita a seleção<br>dos artigos; 3. Não tem informação se a seleção, extração e<br>avaliação da qualidade foi feita em pares independentes; 4.<br>Os estudos apresentam alta heterogeneidade e não informa<br>detalhes doresultado da avaliação da qualidade|
|Bij,<br>2011<sup>132</sup>|82|Vários|BAIXO|ALTO|BAIXO|ALTO|2. Uso de duas fontes de identificação e potencial risco de<br>viés de publicação devido a restrição de idioma; 4. Os<br>estudos incluídos apresentaramqualidade baixa na|  
|||||||avaliação do QUADAS e alta heterogeneidade entre os<br>estudos.|
|---|---|---|---|---|---|---|
|Shi|antígeno|||||4. Os estudos incluídos na meta-análise apresentaram alta|
|,<br>2008<sup>133</sup>|45<br>carcinoemb<br>riônico|BAIXO|BAIXO|BAIXO|ALTO|heterogeneidade e potencial risco de viés em metade dos<br>incluídos.|  
**Tabela C -** Classificação do risco de viés para a pergunta 5 – uso da citologia do líquido pleural para diagnóstico de MMP  
|||**QUADAS-2**|**(Risco de Viés)**||
|---|---|---|---|---|
|**Autor, ano**|**1. Seleção dos**<br>**pacientes**|**2. Teste**<br>**índice**|**3. Padrão de**<br>**referência**|**4. Fluxo e**<br>**tempo**|
|Porcel,2014<sup>144</sup><br>|BAIXO|INCERTO|BAIXO|BAIXO|
|Segal,2013 <sup>145</sup>|BAIXO|BAIXO|BAIXO|INCERTO|
|Lovrenski,2012<sup>146</sup><br>|ALTO|INCERTO|BAIXO|BAIXO|
|Davies,2009<sup>147</sup>|INCERTO|BAIXO|INCERTO|BAIXO|
|Fassina,2008<sup>45</sup>|ALTO|INCERTO|BAIXO|BAIXO|
|Aerts,2006<sup>43</sup>|ALTO|INCERTO|BAIXO|BAIXO|
|Vazquez Oliva,<br>1995<sup>148</sup>|ALTO|BAIXO|BAIXO|BAIXO|
|Prakash,1985<sup>149</sup>|ALTO|ALTO|INCERTO|INCERTO|

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Avaliação da Qualidade do Corpo de Evidência** -->
A avaliação da qualidade do corpo destas evidências utilizadas para a pergunta 7 sobre imuno-histoquímica foi realizada a partir do sistema GRADE<sup>19</sup> ( _Grading of Recommendations, Assessment, Development and Evaluation_ ). Tabelas com a sumarização das evidências e respectiva qualidade ou grau de certeza foram desenvolvidas na plataforma GRADEpro<sup>20</sup> e as recomendações para a utilização de marcadores de imuno-histoquímica para o diagnóstico de MMP foram elaboradas. Esta pergunta se dividiu em oito avaliações da qualidade (uma para cada marcador de imuno-histoquímica selecionado), analisando os seguintes fatores: risco de viés, inconsistência entre os estudos, presença de evidência indireta, imprecisão dos resultados e viés de publicação. As evidências e classificação gerada pelo sistema GRADE para a pergunta 7 estão apresentadas nas **Tabelas D a L** .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Tabela D -** Avaliação da qualidade da evidência para o marcador Calretinina (marcador reativo para MMP) -->
|Sens|ibilidade<br>|0,89 (95%|CI: 0,79 para 0|,94)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Espe<br>**D**|cificidade<br>**esfecho**|0,83 (95%<br>**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|CI: 0,74 para 0<br>**Delineamen**<br>**to do estudo**|,90)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br> <br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidên**<br>**cia**|
|**MMP**|**Verdadeir**<br>**os-**<br>**positivos**|14<br>estudos<br>851<br>|Estudo de<br>acurácia do<br>tipo caso-<br>|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|não grave|nenhum|27 (24<br>para 28)|177 (158<br>para 188)|9 (8<br>para 9)|⨁◯◯<br>◯<br>MUITO<br>|
||**Falsos-**<br>**negativos**|paciente<br>s|controle||||||3 (2<br>para 6)|23 (12<br>para 42)|1 (1<br>para 2)|BAIXA|
||**Verdadeir**<br>**os-**<br>|14<br>estudos<br>|Estudo de<br>acurácia do<br>|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|não grave|nenhum|809<br>(723|667 (596<br>para 721)|826<br>(738|⨁◯◯<br>◯|
||**negativos**|638|tipo caso-||||||para||para|MUITO|
|**Sem**<br>**MMP**||paciente<br>|controle||||||874)||892)|BAIXA|
|||s|||||||||||
||**Falsos-**<br>**positivos**||||||||161 (96<br>para<br>247)|133 (79<br>para 204)|164 (98<br>para<br>252)||  
**Explicações:**  
a. Risco de viés alto na seleção de pacientes na grande maioria dos estudos (recrutamento não aleatório, desenho caso-controle, alguns com exclusões inapropriadas - material inadequado, casos "questionáveis").  
b. Risco de viés incerto para o teste índice em todos os estudos (sem descrição se houve cegamento para o resultado do padrão de referência, alguns sem descrição de limiar de positividade).  
c. População difere em alguns estudos quanto à seleção de tipos histológicos específicos (epitelial, sarcomatoide, signet-ring).  
d. Teste índice realizado em tipo de material diferente em alguns estudos (amostras de pleura provenientes de resseção cirúrgica ao invés de biópsia pleural, amostras de tecido pulmonar ao invés de pleura para diagnóstico de adenocarcinoma - controle); limiares de positividade adotados variam entre os estudos.  
e. Heterogeneidade alta entre os estudos (I2=93% para sensibilidade e I2=84% para especificidade).

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Tabela E -** Avaliação da qualidade da evidência para o marcador Citokeratina 5/6 (marcador reativo para MMP) -->
|Sens|ibilidade<br>|0.89 (95%|CI: 0.77 para 0|.95)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Espe<br>**D**|cificidade<br>**esfecho**|0.91 (95%<br>**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|CI: 0.80 para 0<br>**Delineamen**<br>**to do estudo**|.96)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**<br>|
|**MMP**|**Verdadeir**<br>**os-**<br>**positivos**|10<br>estudos<br>520<br>|Estudo de<br>acurácia do<br>tipo caso-<br>|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|não grave|nenhum|27 (23<br>para 28)|177 (155<br>para 189)|9 (8<br>para 9)|⨁◯◯<br>◯<br>MUITO<br>|
||**Falsos-**<br>**negativos**|paciente<br>s|controle||||||3 (2<br>para 7)|23 (11<br>para 45)|1 (1<br>para 2)|BAIXA|
||**Verdadeir**<br>**os-**|10<br>estudos<br>|Estudo de<br>acurácia do<br>|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|não grave|nenhum|879<br>(780|725 (643<br>para 766)|897<br>(796|⨁◯◯<br>◯|
||**negativos**|469|tipo caso-||||||para||para|MUITO|
|**Sem**<br>**MMP**||paciente<br>|controle||||||928)||947)|BAIXA|
||**Falsos-**<br>**positivos**|s|||||||91 (42<br>para<br>190)|75 (34<br>para 157)|93 (43<br>para<br>194)||  
**Explicações:**  
a. Risco de viés alto na seleção de pacientes em todos os estudos (recrutamento não aleatório, desenho caso-controle, alguns com exclusões inapropriadas - material inadequado, casos "questionáveis").  
b. Risco de viés incerto para o teste índice em todos os estudos (sem descrição se houve cegamento para o resultado do padrão de referência, alguns sem descrição de limiar de positividade).  
c. População difere em alguns estudos quanto à seleção de tipos histológicos específicos (epitelial, sarcomatoide, signet-ring). d. Teste índice realizado em tipo de material diferente em alguns estudos (amostras de pleura provenientes de resseção cirúrgica ao invés de biópsia pleural, amostras de tecido pulmonar ao invés de pleura para diagnóstico de adenocarcinoma - controle); limiares de positividade adotados variam entre os estudos.  
e. A meta-análise apresentou heterogeneidade para a sensibilidade (I2=85%) e para especificidade (I2=92%).  
**Tabela F -** Avaliação da qualidade da evidência para o marcador WT-1 (marcador reativo para MMP)  
|Sensibilidade<br>|0.70 (95%|CI: 0.42 para 0|.88)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|
|Especificidade<br>**Desfecho**|0.93 (95%<br>**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|CI: 0.74 para 0<br>**Delineamen**<br>**to do estudo**|.99)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**<br>|
|**MMP**<br>**Verdadeir**<br>**os-**<br>**positivos**<br>**Falsos-**<br>**negativos**|5<br>estudos<br>198<br>paciente<br>s|Estudo de<br>acurácia do<br>tipo caso-<br>controle|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|grave<sup>f</sup>|nenhum|21 (13<br>para 27)<br>9 (3<br>para 17)|140 (84<br>para 177)<br>60 (23<br>para 116)|7 (4<br>para 9)<br>3 (1<br>para 6)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|  
|**D**|**esfecho**|**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|**Delineamen**<br>**to do estudo**|**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito p**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**or 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Sem**<br>|**Verdadeir**<br>**os-**<br>**negativos**|5<br>estudos<br>156<br>paciente|Estudo de<br>acurácia do<br>tipo caso-<br>controle|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|não grave<sup>g</sup>|nenhum|906<br>(721<br>para<br>956)|747 (594<br>para 789)|925<br>(736<br>para<br>976)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|
|**MMP**|**Falsos-**<br>**positivos**|s|||||||64 (14<br>para<br>249)|53 (11<br>para 206)|65 (14<br>para<br>254)||

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Notas:** -->
a. Risco de viés alto na seleção dos pacientes em todos os estudos (recrutamento não aleatório, desenho caso-controle, algumas exclusões inapropriadas, material inadequado como resseção cirúrgica). b. Risco de viés incerto para o teste índice em todos os estudos (sem descrição se houve cegamento para o resultado do padrão de referência, alguns sem descrição do limiar de positividade). c. População difere em alguns estudos quanto à seleção de tipos histológicos específicos (epitelial, sarcomatoide, signet-ring). d. Teste índice realizado em tipo de material diferente em alguns estudos (amostras de pleura provenientes de resseção cirúrgica ao invés de biópsia pleural, amostras de tecido pulmonar ao invés de pleura para diagnóstico de adenocarcinoma - controle); limiares de positividade adotados variam entre os estudos. e. Existe heterogeneidade entre os 5 estudos. (chi-square=47,98; df=4, logo I2=91%). f. Presença de imprecisão entre os estudos para a sensibilidade - Meta-análise com um amplo intervalo de confiança (Sens: IC 95% 0,42 a 0,88). g. Não existe imprecisão entre os estudos para a especificidade - Intervalo de confiança razoável (Espec: IC 95% 0,74 a 0,99).  
**Tabela G -** Avaliação da qualidade da evidência para o marcador D2-40 (marcador reativo para MMP)  
|Sens|ibilidade<br>|0.85 (95%|CI: 0.82 para 0|.88)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Espe<br>**D**|cificidade<br>**esfecho**|0.81 (95%<br>**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|CI: 0.78 para 0<br>**Delineamen**<br>**to do estudo**|.84)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**|
|**MMP**|**Verdadeir**<br>**os-**<br>**positivos**|13<br>estudos<br>536<br>|Estudo de<br>acurácia do<br>tipo caso-<br>|não<br>grave|grave<sup>a</sup>|grave<sup>b</sup>|não grave|nenhum|26 (25<br>para 26)|170 (164<br>para 176)|9 (8<br>para 9)|⨁⨁◯<br>◯<br>BAIXA|
||**Falsos-**<br>**negativos**|paciente<br>s|controle||||||4 (4<br>para 5)|30 (24<br>para 36)|1 (1<br>para 2)||
|**Sem**|**Verdadeir**<br>**os-**<br>**negativos**|13<br>estudos<br>707<br>paciente|Estudo de<br>acurácia do<br>tipo caso-<br>controle|não<br>grave|grave<sup>a</sup>|grave<sup>b</sup>|não grave|nenhum|786<br>(757<br>para<br>815)|648 (624<br>para 672)|802<br>(772<br>para<br>832)|⨁⨁◯<br>◯<br>BAIXA|
|**MMP**|**Falsos-**<br>**positivos**|s|||||||184<br>(155<br>para<br>213)|152 (128<br>para 176)|188<br>(158<br>para<br>218)||  
a. Os estudos incluídos na Revisão Sistemática com meta-análise de He et al 2017, apresentam diferentes materiais para diagnóstico: tecido de biópsia e resselção cirúrgica, efusão pleural e efusão peritoneal.  
b. Heterogeneidade alta entre os estudos (I2=82,8% para sensibilidade e I2=93,1%).

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Tabela H -** Avaliação da qualidade da evidência para o marcador TTF-1 (marcador não reativo para MMP) -->
|Sens|ibilidade<br>|0.99 (95%|CI: 0.97 para 0|.99)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Espe<br>**D**|cificidade<br>**esfecho**|0.71 (95%<br>**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|CI: 0.58 para 0<br>**Delineamen**<br>**to do estudo**|.81)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**|
|**MMP**|**Verdadeir**<br>**os-**<br>**positivos**|10<br>estudos<br>446<br>|Estudo de<br>acurácia do<br>tipo caso-<br>|grave<br>a,b|grave<sup>c</sup>|não grave<sup>d</sup>|não grave|viés de<br>publicaçã<br>o<br>|30 (29<br>para 30)|197 (193<br>para 199)|10 (10<br>para 10)|⨁◯◯<br>◯<br>MUITO<br>|
||**Falsos-**<br>**negativos**|paciente<br>s|controle|||||altamente<br>suspeito<sup>e</sup>|0 (0<br>para 1)|3 (1 para<br>7)|0 (0<br>para 0)|BAIXA|
||**Verdadeir**<br>**os-**|10<br>estudos|Estudo de<br>acurácia do|grave<br>a,b|grave<sup>c</sup>|grave<sup>f</sup>|grave<sup>g</sup>|viés de<br>publicaçã|686<br>(564|566 (465<br>para 646)|700<br>(575|⨁◯◯<br>◯|
|**Sem**|**negativos**|559<br>paciente|tipo caso-<br>controle|||||o<br>altamente<br>|para<br>784)||para<br>800)|MUITO<br>BAIXA|
|**MMP**|**Falsos-**<br>**positivos**|s||||||suspeito<sup>e</sup>|284<br>(186<br>para<br>406)|234 (154<br>para 335)|290<br>(190<br>para<br>415)||

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Notas:** -->
a. Risco de viés alto na seleção de pacientes na maioria dos estudos (recrutamento não aleatório, desenho caso-controle, exclusões inapropriadas - material inadequado, casos "questionáveis"). b. Risco de viés incerto para o teste índice em todos os estudos (sem descrição se houve cegamento para o resultado do padrão de referência, alguns sem descrição de limiar de positividade). c. População difere em alguns estudos quanto à seleção de tipos histológicos específicos (epitelial, sarcomatoide, signet-ring). Tipo de material: biópsia e material de ressecção.  d. A meta-análise não apresentou heterogeneidade para a sensibilidade.  e. Deeks Funnel Plot Asymmetric test p-valor=0,01  f. A meta-análise apresentou heterogeneidade alta para especificidade (I2=93,0%).  g. Presença de imprecisão entre os estudos para a especificidade - Meta-análise com um amplo intervalo de confiança (Espec: IC 95% 0,58 a 0,81).  
**Tabela I -** Avaliação da qualidade da evidência para o marcador CEA (marcador não reativo para MMP)  
|Sensibilidade<br>|0.96 (95%|CI: 0.94 para 0|.97)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|
|Especificidade<br>**Desfecho**|0.82 (95%<br>**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|CI: 0.75 para 0<br>**Delineamen**<br>**to do estudo**|.87)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**|
|**MMP**<br>**Verdadeir**<br>**os-**<br>**positivos**<br>**Falsos-**<br>**negativos**|28<br>estudos<br>1506<br>paciente<br>s|estudos de<br>coorte e<br>caso-<br>controle|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|não grave|nenhum|29 (28<br>para 29)<br>1 (1<br>para 2)|192 (188<br>para 195)<br>8 (5 para<br>12)|10 (9<br>para 10)<br>0 (0<br>para 1)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|  
|**D**|**esfecho**|**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|**Delineamen**<br>**to do estudo**|**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito p**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**or 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Sem**|**Verdadeir**<br>**os-**<br>**negativos**|28<br>estudos<br>1077<br>paciente<br>|estudos de<br>coorte e<br>caso-<br>controle|grave<br>a,b|grave<sup>c,d</sup>|grave<sup>e</sup>|não grave|nenhum|796<br>(729<br>para<br>848)|657 (602<br>para 699)|813<br>(744<br>para<br>865)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|
|**MMP**|**Falsos-**<br>**positivos**|s|||||||174<br>(122<br>para<br>241)|143 (101<br>para 198)|177<br>(125<br>para<br>246)||  
a. Risco de viés alto na seleção de pacientes na grande maioria dos estudos (recrutamento não aleatório, desenho caso-controle, alguns com exclusões inapropriadas - material inadequado, casos "questionáveis").  
b. Risco de viés incerto para o teste índice em todos os estudos (sem descrição se houve cegamento para o resultado do padrão de referência, alguns sem descrição de limiar de positividade).  
c. População difere em alguns estudos quanto ao tipo de Mesotelioma |Maligno (Pleura e Peritôneo).  
d. Teste índice realizado em tipo de material diferente em alguns estudos (amostras de pleura provenientes de resseção cirúrgica ao invés de biópsia pleural, amostras de tecido pulmonar ao invés de pleura para diagnóstico de adenocarcinoma - controle); limiares de positividade adotados variam entre os estudos.  
e. A meta-análise apresentou heterogeneidade alta para a sensibilidade (I2=71,8%) e para especificidade (I2=83,0%).  
**Tabela J -** Avaliação da qualidade da evidência para o marcador Ber-EP4 (marcador não reativo para MMP)  
|Sens|ibilidade<br>|0.87 (95%|CI: 0.83 para 0|.90)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Espe<br>**D**|cificidade<br>**esfecho**|0.85 (95%<br>**№ dos**<br>**estudos**<br>**(№ de**<br>**pacient**<br>**es)**|CI: 0.74 para 0<br>**Delineamen**<br>**to do estudo**|.93)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**|
|**MMP**|**Verdadeir**<br>**os-**<br>**positivos**|16<br>estudos<br>958<br>|Estudo de<br>acurácia do<br>tipo caso-<br>|grave<br>a,b|grave<sup>c</sup>|grave<sup>d</sup>|não grave|nenhum|26 (25<br>para 27)|174 (165<br>para 181)|9 (8<br>para 9)|⨁◯◯<br>◯<br>MUITO<br>|
||**Falsos-**<br>**negativos**|paciente<br>s|controle||||||4 (3<br>para 5)|26 (19<br>para 35)|1 (1<br>para 2)|BAIXA|
||**Verdadeir**<br>**os-**|16<br>estudos|Estudo de<br>acurácia do|grave<br>a,b|grave<sup>c</sup>|grave<sup>d</sup>|não grave|nenhum|829<br>(716|684 (590<br>para 740)|846<br>(731|⨁◯◯<br>◯|
||**negativos**|635|tipo caso-||||||para||para|MUITO|
|**Sem**<br>**MMP**||paciente|controle||||||897)||916)|BAIXA|
|||s|||||||||||
||**Falsos-**<br>**positivos**||||||||141 (73<br>para<br>254)|116 (60<br>para 210)|144 (74<br>para<br>259)||

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Explicações:** -->
a. Risco de viés alto na seleção de pacientes na grande maioria dos estudos (recrutamento não aleatório, desenho caso-controle, alguns com exclusões inapropriadas - material inadequado, casos "questionáveis").  
b. Risco de viés incerto para o teste índice em todos os estudos (sem descrição se houve cegamento para o resultado do padrão de referência, alguns sem descrição de limiar de positividade).  
c. População difere em alguns estudos quanto à seleção de tipos histológicos específicos (epitelial, sarcomatoide e outros)

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: d. Heterogeneidade alta entre os estudos (I2=68% para sensibilidade e 89% para especificidade). -->
**Tabela L -** Avaliação da qualidade da evidência para o marcador MOC31 (marcador não reativo para MMP)  
|Sens|ibilidade<br>|0.91 (95%|CI: 0.87 para 0|.94)|||Prevalências|<br>3%||20%|1%||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Espe<br>**D**|cificidade<br>**esfecho**|0.86 (95%<br>**№ dos**<br>**estudos**<br>**№ de**<br>**pacient**<br>**es**|CI: 0.57 para 0<br>**Delineamen**<br>**to do estudo**|.96)<br>**Fator**<br>**Risco**<br>**de viés**|**es que po**<br>**Evidênc**<br>**ia**<br>**indireta**|**dem diminuir**<br>**Inconsistên**<br>**cia**|**a certeza da e**<br>**Imprecisão**|**vidência**<br>**Viés de**<br>**publicaç**<br>**ão**|**Efeito**<br>**Prob**<br>**pré-**<br>**teste de**<br>**3%**|**por 1.000 p**<br>**testados**<br> <br>**Prob**<br>**pré-teste**<br>**de 20%**|**acientes**<br> <br>**Prob**<br>**pré-**<br>**teste de**<br>**1%**|**Certeza**<br>**da**<br>**Evidênc**<br>**ia**|
|**MMP**|**Verdadeir**<br>**os-**<br>**positivos**|8<br>estudos<br>322<br>|Estudo de<br>acurácia do<br>tipo caso-<br>|grave<br>a,b|grave<sup>c</sup>|não grave<sup>d</sup>|não grave|nenhum|27 (26<br>para 28)|181 (173<br>para 187)|9 (9<br>para 9)|⨁⨁◯<br>◯<br>BAIXA|
||**Falsos-**<br>**negativos**|paciente<br>s|controle||||||3 (2<br>para 4)|19 (13<br>para 27)|1 (1<br>para 1)||
||**Verdadeir**<br>**os-**|8<br>estudos|Estudo de<br>acurácia do|grave<br>a,b|grave<sup>e</sup>|grave<sup>f</sup>|grave<sup>g</sup>|nenhum|831<br>(556|686 (458<br>para 771)|848<br>(567|⨁◯◯<br>◯|
||**negativos**|209|tipo caso-||||||para||para|MUITO|
|**Sem**<br>**MMP**||paciente|controle||||||935)||954)|BAIXA|
|||s|||||||||||
||**Falsos-**<br>**positivos**||||||||139 (35<br>para<br>414)|114 (29<br>para 342)|142 (36<br>para<br>423)||

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Notas:** -->
a. Risco de viés alto na seleção de pacientes na grande maioria dos estudos (recrutamento não aleatório, desenho caso-controle, exclusões inapropriadas - material inadequado, casos "questionáveis"). Padrão de referência não incluído em alguns estudos. b. Risco de viés incerto para o teste índice em todos os estudos (sem descrição se houve cegamento para o resultado do padrão de referência, alguns sem descrição de limiar de positividade). c. População difere em alguns estudos quanto à seleção de tipos histológicos específicos (epitelial, sarcomatoide, signet-ring). d. A meta-análise não apresentou heterogeneidade para a sensibilidade. e. Teste índice realizado em tipo de material diferente em alguns estudos (amostras de pleura provenientes de resseção cirúrgica ao invés de biópsia pleural, amostras de tecido pulmonar ao invés de pleura para diagnóstico de adenocarcinoma - controle); limiares de positividade adotados variam entre os estudos. f. A meta-análise apresentou heterogeneidade alta para especificidade (I2=93,9%). g. Presença de imprecisão entre os estudos para a especificidade - Meta-análise com um amplo intervalo de confiança (Espec: IC 95% 0,57 a 0,96).

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Evidências encontradas** -->
<u>Biomarcadores identificados (pergunta 2)</u>  
As revisões sistemáticas selecionadas indicaram uma variedade de biomarcadores, tanto para análise no líquido pleural quanto no soro ou plasma, para o diagnóstico de MMP. Entre eles, os mais estudados incluem os peptídeos solúveis relacionados à mesotelina (mesotelina solúvel e fator potencializador de megacariócito – MPF)<sup>126,127</sup> , a fibulina-3<sup>128,129</sup> , o osteopontin<sup>130</sup> e o antígeno carcinoembrionário – CEA<sup>132</sup> .  
Uma importante heterogeneidade foi observada entre os estudos originais, principalmente em relação aos grupos comparadores utilizados e aos pontos de corte para definição da positividade do biomarcador. Para os peptídeos solúveis relacionados a mesotelina (SMRPs), por exemplo, tais valores chegam a variar de 0,55 a 4,29 nmol/L<sup>126</sup> .  
Nos estudos com os biomarcadores destacados acima, os resultados de sensibilidade para mesotelioma foram bastante variados (47% a 94%). Os valores de especificidade apresentaram menor variação (77% a 96%) quando o grupo comparador incluiu dados agregados de doença benigna e outros tipos de doença maligna, especialmente devido aos resultados de especificidade dos biomarcadores na diferenciação com doença pleural benigna, em que os valores chegam a 89% para o peptídeo (SMRPs). Quando o grupo comparador incluiu apenas outros tipos de doença pleural maligna para diferenciação com o mesotelioma, a especificidade do peptídeo (SMRPs), foi de 81%, enquanto para o CEA variou de 39% a 88% entre os estudos.  
Todos os biomarcadores identificados e suas medidas de sensibilidade e especificidade estão presentes nas **Tabelas M e N** .

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Tabela M1 -** Resumo das evidências para biomarcadores em soro ou plasma para o diagnóstico de MMP -->
||**Revisão**|**Estudo**<br>**s**<br>|**Ponto de**|**Ger**|**al**|**Doença**|**maligna**|**Doença**|**benigna**|
|---|---|---|---|---|---|---|---|---|---|
|**Biomarcador**|**Sistemática**|**Incluíd**<br>**os**<br>**(N)**|**Corte**<br>**(variação)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|
|Peptídeos<br>|||0,55 a 4,29<br>|0,61|0,87|0,60|0.81|0.58|0.89|
|Solúveis<br>relacionados à<br>Mesotelina|Cui, 2014<sup>126</sup>|28|nmol/L e<br>0.034 a 0.218<br>OD|(0,58 a<br>0,63)|(0,86 a<br>0,88)|(0,56 a<br>0,64)|(0,78 a<br>0,83)|(0,54 a<br>0,62)|(0,86 a<br>0,91)|
|Mesotelina|Hollevoet,<br>2012<sup>127</sup>|16|2,0 nmol/L|0,47<br>(0,26 a<br>0,70)|0,96<br>(0,85 a<br>0,99)|A<br>0,<br>(0,73|UC<br>76<br>a 0,79)|A<br>0,<br>(0,79|UC<br>82<br>a 0,86)|
||Pei 2017<sup>128</sup>|3<br>(soro)|30,10 a 51,40<br>ng/mL|0,77<br>(0,71 a<br>0,83)|0,85<br>(0,79 a<br>0,90)|NR|NR|NR|NR|
|Humoral<br>|,|3<br>(plasma<br>)|29,0 a 52,8<br>ng/mL|0,54<br>(0,50 a<br>0,58)|0,77<br>(0,74 a<br>0,80)|NR|NR|NR|NR|
|fibulin-3|Ren,<br><sup>129</sup>|3<br>(soro)|30,1 a 66,5<br>ng/mL|0,94<br>(0,80 a<br>1,00)|0,80<br>(0,58 a<br>1.00)|NR|NR|NR|NR|
||2016|6<br>(plasma<br>)|28,96 a 54,3<br>ng/mL|0,79<br>(0,52 a|0,92<br>(0,84 a|NR|NR|NR|NR|  
|||||1,00)|1,00)|||||
|---|---|---|---|---|---|---|---|---|---|
||||12,20 a|0,57|0,81|||||
|Osteopontin|Lin, 2014<sup>130</sup>|10|878,65<br>ng/mL|(0,52 a<br>0,61)|(0,79 a<br>0,84)|NR|NR|NR|NR|  
**Tabela M2 -** Resumo das evidências para biomarcadores em soro ou plasma para o diagnóstico de MMP (continuação)  
|**Biomarcador**|**Revisão**|**Estudo**<br>**s**<br>**Incluíd**|**Ponto de**<br>**Corte**|**Ge**<br>|**ral**<br>|**Doença**<br>|**maligna**<br>|**Doença**<br>|**benigna**<br>|
|---|---|---|---|---|---|---|---|---|---|
||**Sistemática**|**os**<br>**(N)**|**(variação)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|
|Antígeno<br>Carcinoembri<br>onário (CEA)|Bij, 2011<sup>132</sup>|5|NR|NR|NR|entre 0,50<br>e 1,0|entre 0,39 e<br>0,88|entre 0,88<br>e 1|entre 0 e<br>0,2|
|CYFRA21-1|Bij, 2011<sup>132</sup>|3|NR|NR|NR|entre 0,36<br>e 0,66|entre 0,33 e<br>0,57|entre 0,36<br>e 0,50|entre 0,74<br>e 0,94|
|NSE|Bij, 2011<sup>132</sup>|2|NR|NR|NR|entre 0,70<br>e 0,88|entre 0,17 e<br>0,63|0,88|0,02|
|TPS|Bij, 2011<sup>132</sup>|2|NR|NR|NR|entre 0,36<br>e 0,64|entre 0,65 e<br>0,85|entre 0,36<br>e 0,64|entre 0,91<br>e 0,94|
|p53|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,07|0,83|0,07|0,98|  
|Gene-X|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,56|1|0,56|1|
|---|---|---|---|---|---|---|---|---|---|
|HA|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,26|0,76|0,26|0,96|
|PDGF-AB|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,43|0,7|0,43|0,82|
|THBS-2|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,89|1|0,89|0,92|  
**Tabela M3 -** Resumo das evidências para biomarcadores em soro ou plasma para o diagnóstico de mesotelioma maligno de pleura

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: (continuação) -->
|**Biomarcador**|**Revisão**<br>**Sistemática**|**Estudo**<br>**s**<br>**Incluíd**<br>**os**<br>**(N)**|**Ponto de**<br>**Corte**<br>**(variação)**|**Ge**<br>**Sens**<br>**(IC 95%)**|**ral**<br>**Espec**<br>**(IC 95%)**|**Doença**<br>**Sens**<br>**(IC 95%)**|**maligna**<br>**Espec**<br>**(IC 95%)**|**Doença**<br>**Sens**<br>**(IC 95%)**|**benigna**<br>**Espec**<br>**(IC 95%)**|
|---|---|---|---|---|---|---|---|---|---|
|TPA-M|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,76|0,39|0,76|0,4|
|TSA|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,4|0,25|NR|NR|  
Legenda – NR: não reportado; NA: não aplicável; Sens: Sensibilidade; Espec: Especificidade; AUC: área sob a curva.  
**Tabela N -** Resumo das evidências para biomarcadores em líquido pleural para o diagnóstico de MMP  
||**Revisão**|**Estudos**<br>**Incluídos**|**Ponto de**<br>|**Ge**<br>|**ral**<br>|**Doença**<br>|**maligna**<br>|**Doença**<br>|**benigna**<br>|
|---|---|---|---|---|---|---|---|---|---|
|**Biomarcador**|**Sistemática**|<br>**(N)**|**Corte**<br>**(variação)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|**Sens**<br>**(IC 95%)**|**Espec**<br>**(IC 95%)**|
|Peptídeos Solúveis<br>relacionados à|Cui, 2014<sup>126</sup>|11|3,0 a<br>24,05|0,79|0,85|0,75|0,76|0,75|0,87|
|Mesotelina|||nmol/L|(0,75 a|(0,83 a|(0,69 a|(0,71 a|(0,67 a|(0,80 a|  
|||||0,83)|0,87)|0,80)|0,82)|0,82)|0,93)|
|---|---|---|---|---|---|---|---|---|---|
||Bij, 2011<sup>132</sup>|NA|NR|0,58 a 0,76|0,44 a<br>0,93|0,71 a<br>0,77|0,24 a 0,97|NR|NR|
||||150,0 a|0,73|0,80|||||
|Humoral fibulin-3|Ren, 2016<sup>129</sup>|5|520,0<br>ng/mL|(0,54 a<br>0,86)|(0,60 a<br>0,91)|NR|NR|NR|NR|
|Antígeno<br>Carcinoembrionário<br>(CEA)|Shi, 2008<sup>133</sup>|11|3,0 a 50,0<br>ng/mL|NR|NR|0,97<br>(0,93 a<br>0,99)|0,60<br>(0,55 a<br>0,65)|NR|NR|
||Bij, 2011<sup>132</sup>|10|NR|NR|NR|0,77 a 1,0|0,43 a 0,88|0,97 a 1,0|0,0 a 0,33|
|CYFRA21-1|Bij, 2011<sup>132</sup>|3|NR|NR|NR|0,55 a<br>0,88|0,33 a 0,55|0,55 a<br>0,90|0,79 a 0,99|
|CA15-3|Bij, 2011<sup>132</sup>|4|NR|NR|NR|0,30 a<br>0,70|0,35 a 0,76|0,30 a<br>0,90|0,93 a 1,0|
|HA|Bij, 2011<sup>132</sup>|2|NR|NR|NR|0,32 a<br>0,88|0,95 a 0,99|NR|NR|
|CA19-9|Bij, 2011<sup>132</sup>|3|NR|NR|NR|0,70 a 1,0|0,22 a 0,54|1,0|0,0 a 0,01|
|CA72-4|Bij, 2011<sup>132</sup>|3|NR|NR|NR|0,90 a 1,0|0,37 a 72|0,90 a 1,0|0,0 a 0,02|
|NSE|Bij, 2011<sup>132</sup>|2|NR|NR|NR|0,80 a<br>0,91|0,19 a 0,63|0,91|0,02|
|CA549|Bij, 2011<sup>132</sup>|1|NR|NR|NR|0,65|0,46|0,65|0,0|
|SCC|Bij, 2011<sup>132</sup>|1|NR|NR|NR|1,0|0,06|1,0|0,01|
|SP-A|Bij, 2011<sup>132</sup>|1|NR|NR|NR|1,0|0,47|NR|NR|  
|TSA<br>Bij, 2011<sup>132</sup><br>1|NR|NR|NR|0,9|0,5|NR|NR|
|---|---|---|---|---|---|---|---|  
Legenda – NR: não reportado; NA: não aplicável; Sens: Sensibilidade; Espec: Especificidade.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Citologia do Líquido Pleural (pergunta 5)** -->
A sensibilidade da citologia do líquido pleural para diagnosticar o MMP variou de 27,3% a 86%, conforme apresentado na **Tabela O**<sup>43, 144, 145, 147, 148,149</sup> .  
Nos estudos em que os comparadores foram outras doenças pleurais, incluindo doenças benignas observou-se maiores valores de especificidade (96,0% a 100,0%)<sup>43,</sup> 145,147. Já em estudos com comparador sendo outros tipos de câncer, a especificidade variou de 54,2% a 60,0%<sup>144, 145,147</sup> .  
No estudo de Fassina e colaboradores houve uma variação maior dessas medidas (sensibilidade: 5,9% a 64,7% e especificidade: 42,9% a 71,4%) devido à variabilidade interobservador, considerando a experiência do citologista no resultado do exame<sup>45</sup> .  
A citologia do líquido pleural permace como um método controverso para o diagnóstico do MMP, uma vez que possui uma alta variabilidade da sua acurácia com grande dependência direta da experiência do citologista<sup>21</sup> .  
73  
**Tabela O -** Resumo das evidências sobre a citologia do líquido pleural para o diagnóstico de MMP  
|Estudo|Desenho|Prevalência<br>|População<br>|VP|População controle|VN|Medidas <br>|deAcurácia<br>|
|---|---|---|---|---|---|---|---|---|
|||de MMP|MMP(N)||||Sensibilidade|Especificidade|
|Porcel, 2014<sup>144</sup>|Coorte retrospectiva<br>(pacientes com efusão<br>pleural maligna)|<br>0,03|N=22|6|Outros tipos de<br>câncer (N=809)|485|27,3%|60,0%|
|Segal, 2013<sup>145</sup>|Coorte retrospectiva<br>(amostras de origem<br>pleural)|0,06|N=517|377|Outras doenças<br>pleurais (N=4720)|4718|73,0%|99,9%|
|Lovrenski,<br>2012<sup>146</sup>|Série de casos<br>retrospectiva|NR|N=24|7|NA|NA|29,0%|NR|
|Davies, 2009<sup>147</sup>|Coorte (amostras de<br>líquido pleural)|NR|N=24|NR|Outras doenças<br>pleurais (N=67 Mal+<br>75Ben)|NR|35,0%|100,0%|
|Fassina, 2008<sup>45</sup>|Caso-controle|NR|N=17|1 a 11|Outros tipos de<br>câncer(N=14)|6 a 10|5,9% a 64,7%|<br>42,9% a<br>71,4%|
|Aerts, 2006<sup>43</sup>|Caso-controle|NR|N=14|NR|Outras doenças<br>pleurais (N=12 adeno<br>+N=13benigna)|NR|86,0%|96,0%|
|Vazquez Oliva,<br>1995<sup>148</sup>|Coorte (pacientes<br>com derramepleural)|0,11|N=12|8|Outros tipos de<br>câncer(N=72)|39|66,7%|54,2%|
|Prakash, 1985<sup>149</sup>|Coorte retrospectiva<br>(pacientes com<br>derramepleural)|0,06|N=23|11|Outros tipos de<br>câncer (N=258)|151|47,8%|58,5%|  
Legenda:  
NR: não reportado; NA: não aplicável; MMP: mesotelioma maligno de mPleura; VP: verdadeiro positivo; VN: verdadeiro negativo.  
74

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Marcadores de Imuno-histoquímica (pergunta 7)** -->
Foram identificados 22 marcadores de imuno-histoquímica na revisão sistemática da pergunta 7, sendo 14 para tecido mesotelial - reativos para MMP ( **Tabela P** ) e oito para adenocarcinoma - não reativos para MMP ( **Tabela Q** ).  
**Tabela P -** Marcadores de imuno-histoquímica reativos para mesotelioma maligno de pleura com material fragmento de pleura  
|**MARCADOR DE**<br>**IMUNO-**<br>**HISTOQUÍMICA**|**SENSIBILIDADE* (%)**<br>**Variação**|**ESPECIFICIDADE* (%)**<br>**Variação**|
|---|---|---|
|CAM5-2|97 a 100|0 a 1,5|
|D2-40|85|81|
|CK5/6|83 a 100|58 a 97|
|Calretinin|82 a 100|61 a 95|
|N-cadherin|78|84|
|EMA|74,5 a 90|7 a 87|
|CD90|73|82|
|WT-1|72 a 91|88 a 100|
|Vimentin|60 a 85|64 a 98|
|HBME-1|59 a 100|28 a 76|
|GLUT-1|58 a 100|100|
|Thrombomodulin|52 a 100|56 a 98|
|p53|45 a 95|47 a 100|
|Desmin|45 a 90|85 a 100|  
*Referências: 21,92,150.  
**Tabela Q -** Marcadores de imuno-histoquímica não reativos para mesotelioma maligno de pleura com material fragmento de pleura  
|**MARCADOR DE**<br>**IMUNO-**|**SENSIBILIDADE* (%)**|**ESPECIFICIDADE* (%)**|
|---|---|---|
|**HISTOQUÍMICA**|**Variação**|**Variação**|  
75  
|Claudin-4|100|99|
|---|---|---|
|CEA|90 a 100|53 a 97|
|Leu-M1|94 a 100|53 a 77|
|CD15|68 a 95|73 a 100|
|TTF-1|93 a 100|53 a 77|
|B72.3|90 a 100|4,2 a 100|
|E-cadherin|86|82|
|MOC31|89 a 94|86 a 90|
|BerEp4|84 a 97|65 a 100|
|BG8|83 a 94|88,5 a 98|  
* Referências: 21,150.  
Para o diagnóstico de MMP, a combinação de diferentes marcadores de imunohistoquímica, reativos e não reativos para MMP, é utilizada com o objetivo de aumentar a acurácia diagnóstica. Desta forma, um conjunto de quatro marcadores reativos (WT-1, calretinina, CK5/6, D2-40) e quatro não reativos para MMP (CEA, BerEp4, TTF-1, MOC31) foi selecionado para avaliação de um possível painel de imuno-histoquímica para o diagnóstico de MMP. A seleção dos marcadores levou em consideração os seguintes critérios: melhor acurácia diagnóstica, evidências do _guideline_ da _British Thoracic Society_ de 2018, disponibilidade no SUS e consenso dos especialistas. As meta-análises das medidas de acurácia realizadas para tais marcadores de imuno-histoquímica são apresentadas nas **tabelas R e S** .  
A quantidade de marcadores definidos no painel de imuno-histoquímica foi baseada nos resultados dos cálculos de probabilidade pós-teste positivo e negativo para os três cenários em análise com probabilidades pré-teste de 1%, 3% e 20%<sup>123, 144,152</sup> , conforme as equações 1, 2, 3 e 4<sup>151</sup> .  
|_Odd pré-teste = prevalência / (1 – prevalência)_|(1)|
|---|---|
|_Odds pós-teste (positivo) = odds pré-teste * RV (positivo)_|(2)|
|_Odds pós-teste (negativo) = odds pré-teste * RV (negativo)_|(3)|
|_Probabilidade Pós-Teste = Odds Pós-Teste /(1 + Odds Pós-Teste);_|(4)|  
76  
_positivo ou negativo_  
77

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Tabela R -** Resumo das meta-análises de acurácia dos marcadores reativos para MMP -->
|**Marcadore**<br>**s Reativos**|**Estudos**<br>**(n)**|**Sensibilidade**<br>**(IC 95%)**|**Especificidade**<br>**(IC 95%)**|<br>**Razão de**<br>**Verossimilhança**<br>**Positiva (IC 95%)**|**Razão de**<br>**Verossimilhanç**<br>**a Negativa (IC**<br>**95%)**|**Razão de Chance**<br>**Diagnóstica (IC 95%)**|**I**<sup>**2**</sup>**para Razão de**<br>**Chance**<br>**Diagnóstica (%)**|
|---|---|---|---|---|---|---|---|
|Calretinina|14|0,89 (0,79 a<br>0,94)|0,83 (0,74 a<br>0,90)|5,11 (3,20 a 8,18)|0,16 (0,09 a<br>0,29)|40,82 (15,60 a 106,88)|32,33|
|CK 5/6|10|0,88 (0,77 a<br>0,95)|0,91 (0,80 a<br>0,96)|9,22 (3,94 a 21,53)|0,17 (0,09 a<br>0,29)|84,60 (19,77 a 362,01)|5,28|
|WT-1|5|0,70 (0,42 a<br>0,88)|0,93 (0,74 a<br>0,99)|6,52 (1,63 a 25,99)|0,31 (0,15 a<br>0,68)|29,04 (2,97 a 284,27)|23,25|
|D2-40|13<br>estudos<br>de 1<br>RS/MA*|0,85 (0,82 a<br>0,88)|0,81 (0,78 a<br>0,84)|5,12 (2,94 a 8,90)|0,19 (0,11 a<br>0,33)|42,98 (15,21 a 121,39)|NI|  
*RS/MA: Revisão Sistemática com Meta-análise. NI: não informado pela RS/MA.

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Estudos incluídos na meta-análise:** -->
**Calretinina** – Abutaily _et al_ ., 2002; Brockstedt _et al_ ., 2000; Carella et al., 2001; Comin _et al_ ., 2006; Comin _et al_ ., 2001; Cury _et al_ ., 2000; Kayser _et al_ ., 2001; Leers _et al_ ., 1998; Mimura _et al_ ., 2007; Oates _et al_ ., 2000; Ordóñez _et al_ ., 2013; Ordonez _et al_ ., 2003; Roberts _et al_ ., 2001; Takeshima _et al_ ., 2009.  
**CK 5/6** – Abutaily _et al_ ., 2002; Carella et al., 2001; Comin _et al_ ., 2006; Chu _et al_ ., 2002; Clover _et al_ ., 1997; Cury _et al_ ., 2000; Kayser _et al_ ., 2001; Ordóñez _et al_ ., 2013; Ordonez _et al_ ., 2003; Ordonez _et al_ ., 1998.  
**WT-1** – Ordóñez _et al_ ., 2013; Oates _et al_ ., 2000; Ordonez _et al_ ., 2003; Ordonez _et al_ ., 2000; Takeshima _et al_ ., 2009.  
**D2-40** – He _et al_ ., 2017.  
78

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Tabela S -** Medidas de acurácia dos marcadores não reativos para MMP -->
|**Marcadore**<br>**s Não**<br>**Reativos**|**Estudos**|**Sensibilidade**<br>**(IC 95%)**|**Especificidade**<br>**(IC 95%)**|**Razão de**<br>**Verossimilhança**<br>**Positiva (IC 95%)**|**Razão de**<br>**Verossimilhanç**<br>**a Negativa (IC**<br>**95%)**|**Razão de Chance**<br>**Diagnóstica (IC 95%)**|**I**<sup>**2**</sup>**para Razão de**<br>**Chance**<br>**Diagnóstica (%)**|
|---|---|---|---|---|---|---|---|
|TTF-1|10|0,99 (0,97 a<br>0,99)|0,71 (0,58 a<br>0,81)|3,49 (2,26 a 5,38)|0,02 (0,01 a<br>0,05)|182,43 (72,11 a<br>461,54)|0,02|
|CEA|28|0,96 (0,94 a<br>0,97)|0,82 (0,75 a<br>0,87)|5,47 (3,86 a 7,74)|0,053 (0,03 a<br>0,08)|144,25 (81,09 a<br>256,62)|0,0|
|Ber-EP4|16|0,87 (0,83 a<br>0,90)|0,85 (0,74 a<br>0,92)|5,91 (3,43 a 10,15)|0,166 (0,13 a<br>0,22)|49,27 (24,97 a 97,25)|13,09|
|MOC31|8|0,91 (0,87 a<br>0,93)|0,86 (0,57 a<br>0,96)|7,03 (2,41 a 20,47)|0,11 (0,08 a<br>0,16)|84,25 (25,42 a 279,25)|25,02|

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Estudos incluídos na meta-análise:** -->
**TTF-1** – Abutaily _et al_ ., 2002; Bakir _et al_ ., 2004; Comin _et al_ ., 2006; Di Loreto _et al_ ., 1998; Khoor _et al_ ., 1999; Mimura _et al_ ., 2007; Ordóñez _et al_ ., 2013; Ordonez _et al_ ., 2003; Ordonez _et al_ ., 2000; Takeshima _et al_ ., 2009.  
**CEA** – Al-Saffar _et al_ ., 1990; Brockstedt _et al_ ., 2000; Brown _et al_ ., 1993; Cagle _et al_ ., 1994; Carella _et al_ ., 2001; Collins _et al_ ., 1992; Comin _et al_ ., 2006; Comin _et al_ ., 2001; Dejmek _et al_ ., 1997; Dejmek _et al_ ., 1994; Grove _et al_ ., 1994; Gaffey _et al_ ., 1992; Garcia-Prats _et al_ ., 1998; GonzálezLois _et al_ ., 2001; Gumurdulu _et al_ ., 2002; Leers _et al_ ., 1998; Mimura _et al_ ., 2007; Moch _et al_ ., 1993; O’Hara _et al_ ., 1990; Ordóñez _et al_ ., 2013; Ordonez _et al_ ., 2003; Ordonez _et al_ ., 1997; Roberts _et al_ ., 2001; Soosay _et al_ ., 1991; Tuttle _et al_ ., 1990; Takeshima _et al_ ., 2009; Wick _et al_ ., 1990; Wirth _et al_ ., 1991.  
79  
**Ber-EP4** – Brockstedt _et al_ ., 2000; Carella _et al_ ., 2001; Comin et al., 2006; Comin _et al_ ., 2001; Dejmek _et al_ ., 1997; Garcia-Prats _et al_ ., 1998; González-Lois _et al_ ., 2001; Grove _et al_ ., 1994; Leers _et al_ ., 1998; Moch _et al_ ., 1993; Ordonez _et al_ ., 2003; Ordonez _et al_ ., 1997; Roberts _et al_ ., 2001; Sheibani _et al_ ., 1991; Takeshima _et al_ ., 2009.  
**MOC31** – Carella _et al_ ., 2001; González-Lois _et al_ ., 2001; Gumurdulu _et al_ ., 2002; Oates _et al_ ., 2000; Ordóñez _et al_ ., 2013; Ordonez _et al_ ., 2003; Ordonez _et al_ ., 1998; Takeshima _et al_ ., 2009.  
80

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **4.** **<u>Recomendações</u>** -->
A reunião para a definição das recomendações foi realizada em 31 de julho de 2019, com participantes do comitê gestor e do grupo elaborador, especialistas e metodologistas. As recomendações para um painel de imuno-histoquímica para o diagnóstico de MMP foram elaboradas considerando os resultados de acurácia da combinação entre os marcadores reativos e não reativos para MMP em cenários de diferentes prevalências possíveis de MMP, visto que os valores preditivos dos testes diagnósticos dependem da probabilidade pré-teste da doença ( **Tabela T** ). As probabilidades pós-teste de apresentar MMP após a realização de diferentes combinações de marcadores de acordo com cada cenário de prevalência de MMP possível (probabilidade pré-teste) são decritas na **Tabela U** .  
**Tabela T -** Probabilidades pré-teste dos pacientes-alvo para o uso do exame de imunohistoquímica  
|||**Cenário**|||**Probabilidade**<br>**pré-teste (%)**|**Fonte**|
|---|---|---|---|---|---|---|
|Derrame p<br>ocupacional<br>radiológica.|leural<br>ou<br>|exsudativ<br>ambiental|o, sem<br>e sem|história<br>suspeita|1,0|Silva Junior,<br>2003<sup>152</sup>.|
|Doença<br>p<br>ocupacional<br>radiológica.|leural<br>ou<br>|maligna,<br>ambiental|<br>sem<br>e sem|história<br>suspeita|3,0|Porcel, 2014<sup>144</sup>.|
|Doença<br>p|leural|maligna,|<br>com|história|20,0|Barbieri, 2018<sup>123</sup>.|
|ocupacional<br>radiológica.|<br>ou<br>|ambiental,|<br>com|suspeita|||  
**Tabela U -** Probabilidades pós-teste de MMP com diferentes combinações entre os oito marcadores de imuno-histoquímica  
|**Cenários com todos os**|**Prevalência de MMP (probabilida**|**de pré-teste) (*)**|
|---|---|---|
|**resultados sugestivos de MMP**|**3%**<br>**20%**|**1%**|
|**Painel com 2 marcadores**<br>**testados**|**Probabilidade pós-tes**|**te**|
|1 reativo e 1 não reativo|35,6% - 66,7%<br>81,7% - 94,2%|15,3% - 39,5%|  
81  
|**Painel com 3 marcadores**<br>**testados**|**Pr**|**obabilidade pós-tes**|**te**|
|---|---|---|---|
|2 reativos e 1 não reativo<br>ou 1 reativo e 2 não reativos|73,8% - 75,1%|95,8% - 96,1%|48,0% - 49,6%|
|**Painel com 4 marcadores**<br>**testados**|**Pr**|**obabilidade pós-tes**|**te**|
|2 reativos e 2 não reativos|93,1% - 98,7%|99,2% - 99,8%|83,4% - 96,2%|  
* A variação dos resultados dentro do mesmo painel/prevalência indica o pior e o melhor cenário de combinação entre os diferentes marcadores de acordo com as suas acurácias.  
Ao analisar as probabilidades pós-teste, observa-se que os maiores valores estão presentes na combinação de marcadores de imuno-histoquímica em que haja pelo menos dois marcadores reativos e dois marcadores não reativos para MMP. Por exemplo, para pacientes com baixa probabilidade pré-teste (1%), o resultado reativo em dois marcadores para tecido mesotelial e não reativo em dois marcadores para adenocarcinoma resulta em uma probabilidade de 83,4% a 96,2% do paciente apresentar MMP após o painel de imuno-histoquímica. Portanto, com base nas evidências levantadas, a combinação de pelo menos 2 marcadores reativos (entre eles, WT1, calretinina, CK5/6, D2-40) e 2 não reativos para MMP (entre eles, CEA, BerEp4, TTF-1, MOC31) fornece maiores probabilidades de diagnóstico de MMP em cenários de maior suspeita da doença.  
Para a elaboração das recomendações foram considerados os riscos e benefícios da realização do exame de imuno-histoquímica relacionados aos seguintes domínios: importância do problema, acurácia do teste, efeitos desejáveis e indesejáveis, certeza da evidência da acurácia do teste e dos efeitos do teste, valores, recursos necessários, equidade, aceitabilidade e viabilidade. A tabela EtD ( _Evidence to Decision_ ) com a sumarização das evidências e respectiva qualidade ou grau de certeza para cada domínio foram desenvolvidas na plataforma GRADEpro, sendo apresentadas à equipe durante a reunião. Cada domínio foi debatido separadamente de forma estruturada e, por consenso, o grupo decidiu sobre a direção (a favor ou contra) e a força das recomendações quanto à realização do painel de imuno-histoquímica nos três cenários de prevalência de MMP.  
Assim, a combinação de pelo menos dois marcadores mesoteliais positivos (entre eles, WT-1, calretinina, CK5/6, D2-40) e pelo menos dois marcadores de adenocarcinoma negativos (entre eles, CEA, BerEp4, TTF-1, MOC31) deve ser utilizada para o diagnóstico de MMP, conforme as recomendações descritas na **Tabela V** .  
82  
83

---

<!-- METADADOS: doenca: Mesotelioma Pleural | secao: **Tabela V -** Recomendações para o uso de marcadores de imuno-histoquímica no diagnóstico de MMP -->
|**Recomendação**|**Justificativa**|**Considerações**|
|---|---|---|
|A realização da técnica deve ser guiada pela<br>história de exposição ao asbesto e pelas<br>características clínicas, radiológicas e<br>histopatológicas do paciente.<br>Recomendação forte.|O desempenho da técnica varia<br>bastante de acordo com o grau de<br>suspeita de MMP (probabilidade<br>pré-teste do paciente)| É importante avaliar e reportar ao patologista as<br>informações sobre história ocupacional e de exposição<br>ambiental ao asbesto e sobre a presença de características<br>clínico-radiológicas sugestivas de MMP.<br> É importante a avaliação do patologista quanto à presença<br>de malignidade no fragmento de pleura por técnicas<br>rotineiras de anatomia patológica antes da realização de<br>imuno-histoquímica.|
|A técnica não deve ser realizada em pacientes com<br>derrame pleural exsudativo, na ausência de<br>características clínicas, radiológicas ou patológicas<br>sugestivas de MMP.|A realização de rotina da técnica<br>em pacientes com baixa suspeita<br>clínico-radiológica e patológica<br>de MMP aumenta muito a| Caso sejam excluídas outras hipóteses diagnósticas, ou seja,<br>identificada alguma característica que aumente a suspeita da<br>doença, a realização de imunoistoquímica pode ser<br>consideradapara o diagnóstico diferencial.|
|A técnica deve ser realizada em pacientes com<br>doença pleural maligna, porém sem características<br>clínicas, radiológicas ou patológicas sugestivas de<br>MMP somente após a investigação de neoplasias<br>em outros sítios primários mais comuns capazes de<br>desenvolver metástase pleural.<br>Recomendação condicional (fraca).|Em pacientes com doença<br>pleural maligna, porém baixa<br>suspeita clínico-radiológica de<br>MMP, a etiologia mais comum é<br>secundária a outras neoplasias<br>pleurais.| Caso sejam excluídas outras neoplasias, ou seja, identificada<br>alguma característica que aumente a suspeita da doença, a<br>realização de imuno-histoquímica pode ser considerada para<br>o diagnóstico diferencial.|  
84  
A técnica deve ser realizada em pacientes com doença pleural maligna e com história de exposição ao asbesto, características clínicas, radiológicas ou patológicas sugestivas de MMP.  
Recomendação forte.  
A realização da técnica em pacientes com história de exposição e alta suspeita clínicoradiológica e histopatológica de MMP aumenta muito a probabilidade de resultados verdadeiro-positivos.  
- Uma história de exposição ocupacional ou ambiental positiva aumenta a suspeita de doença, especialmente considerando um período de latência longo (mínimo de 10 anos) entre a exposição e o desenvolvimento da doença. Entretanto, a ausência ou o desconhecimento sobre exposição não exclui a possibilidade de MMP.  
- Caso os dois marcadores mesoteliais tenham sido negativos e os dois marcadores de adenocarcinoma tenham sido positivos, investigar outras neoplasias pleurais considerando os marcadores utilizados. Em caso de outro  
~~i d i i ê i l d li hi ó i~~  
85  
86

---

