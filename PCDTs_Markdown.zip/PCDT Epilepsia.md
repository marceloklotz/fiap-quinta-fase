<!-- METADADOS: doenca: PCDT Epilepsia | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 17, DE 21 DE JUNHO DE 2018.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Epilepsia.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso das atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a epilepsia no Brasil e diretrizes nacionais para diagnóstico, tratamento  
e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os relatórios de recomendação n<sup>o</sup> 248 de Fevereiro de 2017, n<sup>o</sup> 281 de Julho de 2017, n<sup>o</sup> 290 de Julho de 2017 e nº 353 de Fevereiro de 2018 e o Registro de Deliberação nº 329/2018 e o Relatório de Recomendação nº 347 de Novembro de 2017 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Epilepsia.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da epilepsia, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt#e, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos</u> Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da epilepsia.  
Art. 3º Os gestores Estaduais, Distrital e Municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede  
assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria nº 1.319/SAS/MS, de 25 de novembro de 2013, publicada no Diário Oficial da União nº 230, de 27 de novembro de 2013, seção 1, páginas 138 à 149.  
FRANCISCO DE ASSIS FIGUEIREDO  
MARCO ANTÔNIO DE ARAÚJO FIREMAN  
2

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **1 INTRODUÇÃO** -->
A epilepsia é uma doença que se caracteriza por uma predisposição permanente do cérebro em originar crises epilépticas e pelas consequências neurobiológicas, cognitivas, psicológicas e sociais destas crises<sup>1</sup> . A epilepsia está associada a uma maior mortalidade (risco de acidentes e traumas, crises prolongadas e morte súbita), a um risco aumentado de comorbidades psiquiátricas (sobretudo depressão e ansiedade) e também a inúmeros problemas psicossociais (perda da carteira de habilitação, desemprego, isolamento social, efeitos adversos dos fármacos, disfunção sexual e estigma social).  
Uma crise epiléptica é a ocorrência transitória de sinais ou sintomas clínicos secundários a uma atividade neuronal anormal excessiva ou sincrônica. A definição de epilepsia requer a ocorrência de pelo menos uma crise epiléptica. do ponto de vista prático, a epilepsia pode ser definida por uma das seguintes condições:  
- Ao menos duas crises não provocadas (ou reflexas) ocorrendo com intervalo maior que 24 horas;  
- Uma crise não provocada (ou reflexa) e probabilidade de novas crises ocorrerem nos próximos 10 anos, similar ao risco  
- de recorrência geral (pelo menos 60%) após duas crises não provocadas;  
- Diagnóstico de uma síndrome epiléptica.  
Estima-se que a prevalência mundial de epilepsia ativa esteja em torno de 0,5% a 1,0% da população. A prevalência da epilepsia difere com as diferentes idades, gêneros, grupos étnicos e fatores socioeconômicos. Nos países desenvolvidos, a prevalência da epilepsia aumenta proporcionalmente com o aumento da idade, enquanto nos países em desenvolvimento geralmente atinge picos na adolescência e idade adulta<sup>2</sup> . A probabilidade geral de um indivíduo ser afetado pela epilepsia ao longo da vida é de cerca de 3%<sup>3</sup> . No Brasil, Marino e colaboradores encontraram uma prevalência da doença de 11,9/1.000 na Grande São Paulo<sup>4</sup> , enquanto Fernandes e colaboradores descreveram 16,5 indivíduos com epilepsia ativa para cada 1.000 habitantes em Porto Alegre<sup>5</sup> . Num levantamento porta-a-porta realizado em três áreas de duas cidades do Sul do Brasil, Noronha e colaboradores encontraram uma prevalência de epilepsia ativa de 5,4/1.000 habitantes. A prevalência foi maior em classes sociais menos favorecidas (7,5/1.000) e em idosos (8,5/1.000). Este estudo apurou ainda uma grande lacuna no tratamento da epilepsia nas áreas estudadas, com mais de 1/3 dos indivíduos com epilepsia em tratamento inadequado<sup>6</sup> .  
O diagnóstico de epilepsia deve ser feito seguindo níveis de classificação, iniciando pelo tipo de crise apresentada e, juntando-se a outras características clínicas e eletroencefalográficas (EEG), classifica-se o paciente dentro de uma síndrome epiléptica, conforme explanado a seguir:

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Classificação das crises epilépticas** -->
A nova classificação das crises epilépticas manteve a separação entre crises epilépticas de manifestações clínicas iniciais focais ou generalizadas<sup>7</sup> . Em geral, a Liga Internacional Contra a Epilepsia (ILAE), importante associação internacional promotora e disseminadora do conhecimento sobre esta doença, respeitou o mesmo esquema geral da classificação anterior, modificando alguns termos, por julgá-los mais adequados, flexíveis e transparentes. Assim, o termo “parcial” foi substituído por “focal”; a percepção (consciência) passou a ser utilizada como um classificador das crises focais; os termos “discognitivo”, “parcial simples”, “parcial complexa”, “psíquico” e “secundariamente generalizado”, da classificação anterior, foram eliminados; foram incluídos novos tipos de crises focais (automatismos, parada comportamental, hipercinética, autonômica, cognitiva e emocional); foi decidido que as crises atônicas, clônicas, espasmos epilépticos, mioclônicas e tônicas podem ter uma origem tanto focal como generalizada; crises secundariamente generalizadas foram substituídas por crises focais com evolução para crise tônico-clônica bilateral (ver abaixo); foram incluídos novos tipos de crises generalizadas (mioclonias palpebrais, ausência mioclônica, mioclônico-atônica, e mioclônico-tônico-clônica)<sup>7</sup> .  
3  
As crises generalizadas têm origem em algum ponto da rede neural que é capaz de recrutar rapidamente outras redes neurais bilaterais<sup>8</sup> . As crises de início generalizado são subdivididas em motoras (tônico-clônicas, clônicas, tônicas, mioclônicas, mioclônico-tônico-clônicas, mioclônico-atônicas, atônicas, espasmos epilépticos) e não motoras, as clássicas crises de ausência, que se subdividem ainda em típicas, atípicas, mioclônicas e ausências com mioclonias palpebrais.  
As crises epilépticas focais iniciam-se de forma localizada numa área específica do cérebro, e suas manifestações clínicas dependem do local de início e propagação da descarga epileptogênica para outras áreas. Dois aspectos fundamentais são considerados na subdivisão das crises de início focal: alteração ou não da consciência durante a crise (percepção dos eventos por parte do paciente) e tipo de manifestação da crise (motoras e não motoras). As crises focais motoras são representadas pelos automatismos, crises atônicas, crises clônicas, espasmos epilépticos, crises hipercinéticas, crises mioclônicas e crises tônicas; as não motoras são as crises autonômicas, parada comportamental, cognitivas, emocionais e sensoriais). Por fim, uma crise focal, quando propagada para todo o córtex cerebral, pode terminar numa crise tônico-clônica generalizada, sendo então denominada crise focal com evolução para crise tônico-clônica bilateral<sup>9</sup> .  
Nessa nova classificação das crises epilépticas<sup>7</sup> , algumas crises podem ser classificadas como “de início desconhecido”, sejam elas motoras (espasmos epilépticos, crises tônico-clônicas) ou não motoras (parada comportamental). Há ainda um lugar para classificar a crise em “inclassificável”, seja por informações inadequadas, ou por impossibilidade de colocá-la em outras categorias.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Classificação das síndromes epilépticas (Apêndice 1)** -->
Uma síndrome epiléptica é um conjunto de características clínicas e eletroencefalográficas incorporados ao tipo de crise do paciente, tais como idade de início e remissão (quando aplicável), fatores precipitantes de crises, variação ao longo do dia e prognóstico. Podem estar associadas a comorbidades específicas, intelectuais e psiquiátricas, além de achados específicos de EEG e imagem<sup>10</sup> . O EEG não é obrigatório (nem essencial) para diagnosticar epilepsia, pois o diagnóstico de epilepsia é feito com base na descrição da crise epiléptica. ( **Apêndice 2** ).  
As epilepsias podem ser causadas por lesões estruturais, alterações genéticas, erros inatos do metabolismo, doenças neurocutâneas (esclerose tuberosa, Sturge-Weber), doenças cromossômicas (Angelman, cromossomo 20 em anel, síndrome 4P), doenças mitocondriais, infecciosas, metabólicas ou autoimunes, além de condições adquiridas ao longo da vida (trauma, AVC etilismo)<sup>10</sup> . As causas lesionais mais frequentes das epilepsias focais sintomáticas são esclerose temporal mesial, neoplasias cerebrais primárias, traumatismo craniano, doenças cerebrovasculares, anomalias vasculares e malformações do desenvolvimento cerebral, incluindo hamartomas hipotalâmicos<sup>11</sup> . A etiologia da epilepsia de um determinado indivíduo pode ser “desconhecida”, devido às limitações dos métodos de investigação.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da síndrome de Turner. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 3** .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **2 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE – CID 10** -->
- G40.0 Epilepsia e síndromes epilépticas idiopáticas definidas por sua localização (focal) (parcial) com crises de início  
focal  
- G40.1 Epilepsia e síndromes epilépticas sintomáticas definidas por sua localização (focal) (parcial) com crises parciais  
- simples  
4  
 G40.2 Epilepsia e síndromes epilépticas sintomáticas definidas por sua localização (focal) (parcial) com crises parciais complexas  
- G40.3 Epilepsia e síndromes epilépticas generalizadas idiopáticas  
- G40.4 Outras epilepsias e síndromes epilépticas generalizadas  
- G40.5 Síndromes epilépticas especiais  
- G40.6 Crises de grande mal, não especificada (com ou sem pequeno mal)  
- G40.7 Pequeno mal não especificado, sem crises de grande mal  
- G40.8 Outras epilepsias  
_Nota: (1) o termo idiopático refere-se a uma etiologia possivelmente genética ou genética identificada; (2) o termo sintomático refere-se a uma etiologia identificada; (3) o termo parciais simples refere-se a crises focais sem alteração da consciência; (4) o termo parciais complexas refere-se a crises focais com alteração da consciência; (5) o termo outras epilepsias e síndromes epilépticas generalizadas refere-se às síndromes de Ohtahara, West, Lennox-Gastaut e Doose; (6) o termo síndromes epilépticas especiais refere-se a crises relacionadas ao uso de álcool ou medicamentos, modificações hormonais, privação de sono ou estresse; (7) o termo crise de grande mal refere-se a crise tônico-clônica generalizada; (8) o termo pequeno mal refere-se a crises de ausência típica._

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **3.1 Clínica** -->
Na maioria dos casos, o diagnóstico de uma crise epiléptica pode ser feito clinicamente por meio da obtenção de uma história detalhada e de um exame físico geral, com ênfase nas áreas neurológica e psiquiátrica. Muitas vezes, o auxílio de uma testemunha ocular é importante para que a crise seja descrita em detalhes. A ocorrência de uma aura (manifestação sensorial inicial de uma crise), bem como fatores precipitantes da crise, deve ser registrada. Idade de início, frequência de ocorrência das crises, e intervalos entre as crises (o mais curto e o mais longo obtido na história do paciente) devem ser caracterizados, muitas vezes com o auxílio de um diário de crises. A história deve cobrir ainda a existência de eventos pré- e perinatais, crises no período neonatal, crises febris, qualquer crise não provocada e história de epilepsia na família. Trauma craniano, infecção ou intoxicações prévias também devem ser investigados<sup>9</sup> .  
É fundamental também um diagnóstico diferencial correto com outros distúrbios paroxísticos da consciência, como síncopes e crises não epilépticas psicogênicas, bem como manifestações neurológicas focais súbitas, como isquemia cerebral aguda e enxaqueca.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **3.2 Complementar** -->
Os exames complementares devem ser orientados pelos achados da história e do exame físico. O principal exame é o eletroencefalograma (EEG), cujo papel é auxiliar o médico a estabelecer um diagnóstico acurado. O EEG é capaz de, quando alterado, identificar o tipo e a localização da atividade epileptiforme e orientar na classificação da síndrome epiléptica e na escolha do fármaco antiepiléptico (FAE)<sup>10</sup> .  
Como já mencionado, o EEG não é obrigatório (nem essencial) para diagnosticar epilepsia. O diagnóstico de epilepsia é feito com bases na descrição da crise epiléptica. É importante que, quando realizado, o tempo de registro seja de no mínimo 30 minutos e que seja utilizado o Sistema Internacional 10-20 para colocação de eletrodos ( **Apêndice 2** ).  
Exames de imagem [ressonância magnética (RM) do encéfalo e tomografia computadorizada (TC) de crânio] devem ser solicitados na suspeita de causas estruturais, que podem estar presentes nos pacientes com epilepsia focal<sup>12</sup> . O diagnóstico de uma lesão subjacente pode definir mais precocemente refratariedade ao tratamento medicamentoso e embasar a indicação de  
5  
tratamento cirúrgico para a epilepsia do paciente. Em torno de 75% dos pacientes avaliados em centros terciários, especializados em epilepsias refratárias, apresentam anormalidades à RM do encéfalo<sup>13</sup> . Metade dos pacientes com epilepsia apresenta anormalidades estruturais detectadas por exame de imagem<sup>14</sup> .  
A RM do encéfalo é auxiliar na investigação e condução dos casos de pacientes refratários a medicamentosos (persistência de crises epilépticas apesar do uso de dois FAE de primeira linha, em doses adequadas)<sup>9</sup> , sobretudo em pacientes com epilepsias focais, para os quais a presença de uma lesão cerebral é forte preditor de refratariedade a monoterapia medicamentosa<sup>15</sup> . Não há necessidade de solicitar TC de crânio previamente a uma RM de encéfalo.  
Os seguintes procedimentos também são auxiliares em casos de crises refratárias:  
- Diário de registro de crises;  
- Relatório médico, com descrição dos fármacos e doses máximas previamente utilizadas; e  
- Testes psicométricos, na suspeita de efeitos cognitivos negativos provocados pelo uso de FAE.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **4 CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes com diagnóstico estabelecido de epilepsia, segundo a Classificação Internacional das Epilepsias e Síndromes Epilépticas, ou seja, os pacientes que tenham apresentado duas crises epilépticas no intervalo mínimo de 24 horas; os que tenham apresentado uma crise e que tenham um risco de recorrência de crises acima de 60%, ou ainda pacientes que tenham um diagnóstico estabelecido de uma síndrome epiléptica específica<sup>16</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **5 CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo pacientes com diagnóstico duvidoso de epilepsia ou suspeita de eventos paroxísticos não epilépticos. Um diagnóstico duvidoso de epilepsia inclui eventos paroxísticos não completamente caracterizados e que necessitam diagnóstico diferencial com outras condições neurológicas (p.ex.: migrânea, doença cerebrovascular aguda, síncope).  
Intolerância, hipersensibilidade ou contraindicação são critérios de exclusão ao uso do respectivo medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **6 CASOS ESPECIAIS** -->
Preconiza-se individualizar o tratamento de acordo com as necessidades específicas dos grupos de pacientes com epilepsia:

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Idosos (idade acima de 60 anos)** -->
Pacientes idosos podem estar mais sujeitos a efeitos adversos em comparação com pacientes das outras faixas etárias e têm uma janela terapêutica mais estreita e um maior grau de variação interindividual dos efeitos dos fármacos antiepilépticos.  
Indica-se evitar o uso de fármacos antiepilépticos indutores enzimáticos clássicos (carbamazepina, fenitoína, fenobarbital), pelo fato de estes fármacos apresentarem um perfil farmacocinético menos favorável (interações com os outros inúmeros fármacos necessários nesta faixa etária) e também por poderem provocar mais frequentemente osteoporose<sup>17</sup> . Nesta faixa etária escalonamento de dose deve ser mais lento, e a dose máxima a ser atingida deve ser menor do que a normalmente recomendada<sup>9</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Crianças e adolescentes (até 18 anos)** -->
Crianças e adolescentes frequentemente sofrem o estresse não apenas das crises, mas, também, das limitações impostas às suas atividades de lazer, pela doença e pelos efeitos adversos dos fármacos antiepilépticos. A epilepsia mioclônica juvenil  
6  
(EMJ) inicia-se na adolescência e é relativamente fácil de controlar desde que sejam evitados fatores precipitantes de crises, como privação de sono, ingestão de álcool e má adesão ao tratamento. A EMJ requer tratamento por toda a vida, pois o índice de recorrência de crises após a retirada de fármacos é superior a 90%<sup>9</sup> .  
Nas meninas, a contracepção deve começar a ser discutida em seguida à menarca. Deve ser enfatizado que uma gestação não planejada pode ser muito problemática<sup>17</sup> . O ácido valproico é associado à síndrome de ovários policísticos. Fármacos indutores do metabolismo hepático aumentam o metabolismo dos contraceptivos orais, podendo reduzir os níveis séricos destes em até 50% e levando a potenciais falhas na contracepção, com consequentes gestações indesejadas. Outras formas de contracepção, como dispositivos intrauterinos (DIU) e diafragmas, devem ser consideradas como alternativas.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Mulheres em idade fértil** -->
Segundo recomendações da ILAE, a escolha do tratamento para as mulheres em idade fértil deve ser baseada em uma decisão compartilhada entre médico e paciente e, quando apropriado, os responsáveis pela paciente. As discussões devem incluir uma avaliação cuidadosa do risco-benefício das opções de tratamento adequadas para o tipo de crise ou da epilepsia da paciente. Sabe-se que crises tônico-clônicas generalizadas (TCG) não controladas podem ser prejudiciais ao feto. Quando o ácido valproico for a opção mais apropriada, a paciente deve estar totalmente informada dos riscos associados ao seu uso durante a gestação, bem como dos riscos e benefícios das alternativas de tratamento. Sempre que possível, o ácido valproico deve ser evitado em mulheres em idade fértil<sup>18</sup> . Existem, no entanto, epilepsias para as quais o ácido valproico é o tratamento mais eficaz, e também situações em que a gestação é extremamente improvável, sendo o ácido valproico, portanto, nestas situações, uma escolha razoável.  
Qualquer mudança do fármaco deve ser feita bem antes da concepção. Fármacos potencialmente teratogênicos devem ser evitados, e o esquema de tratamento deve ser simplificado a um mínimo de fármacos, com uma dose mínima que controle as crises da paciente que deseja engravidar. Há diversos registros de aumento dos índices de malformações congênitas maiores (espina bífida, defeitos de septo atrial, fenda palatina, craniossinostose) com o uso de ácido valproico durante a gestação, comparado com outros fármacos, como carbamazepina e lamotrigina<sup>19</sup> . Além disto, crianças com exposição pré-natal ao ácido valproico podem apresentar rebaixamento do coeficiente de inteligência (QI)<sup>20</sup> e maiores índices de incapacidades motoras e de linguagem<sup>21</sup> , além de uma maior associação com transtornos do espectro autista<sup>22</sup> .  
Além do ácido valproico, outros FAE estão implicados em malformações congênitas de bebês expostos a eles durante a gestação: são os casos do fenobarbital (malformações cardíacas), carbamazepina, fenitoína e lamotrigina, estes últimos implicados na ocorrência de fenda palatina, lábio leporino e hipospadia<sup>21</sup> . No entanto, embora a teratogenicidade dos fármacos antiepilépticos seja uma preocupação significativa durante a gestação, o impacto das crises TCG durante este período tem consequências mais sérias ainda para o feto.  
Dada a multiplicidade de alternativas de tratamento de epilepsias focais com eficácia pelo menos comparável, é preferível que o ácido valproico não seja utilizado para esta indicação. A retirada do ácido valproico ou a mudança para outras alternativas de tratamento devem ser consideradas em mulheres em idade fértil que estejam em tratamento de crises focais com ácido valproico e que consideram engravidar. Quando usado em mulheres em idade fértil, o ácido valproico deve ser prescrito na menor dose efetiva, quando possível em doses não superiores a 500-600 mg/dia.  
As mulheres em idade fértil que não estão planejando a gestação e continuam o tratamento com ácido valproico devem utilizar métodos de contracepção eficazes ou, de outra forma, garantir que uma gestação não planejada possa ser evitada. As mulheres devem ser informadas sobre as possibilidades e limitações da triagem pré-natal, que não pode identificar crianças cujo desenvolvimento neurológico será afetado.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Crises febris** -->
As crises febris (CF) são o transtorno convulsivo mais comum na infância, afetando 2% a 5% das crianças. O diagnóstico é essencialmente baseado na história clínica e no exame físico. Uma crise febril simples (CFS) é definida como uma breve (<15  
7  
min) convulsão generalizada, não recorrente dentro de 24 horas, que ocorre durante uma doença febril não resultante de uma doença aguda do sistema nervoso, em uma criança com idade entre 6 meses e 5 anos, sem déficits neurológicos e sem crises epilépticas afebris anteriores. Já uma crise febril complexa (CFC) é definida como uma crise focal ou generalizada, prolongada, com uma duração maior do que 15 minutos, recorrendo mais de uma vez em 24 horas, ou associada a anormalidades neurológicas pós-ictais, mais frequentemente uma paralisia (de Todd), ou com déficits neurológicos anteriores. Crianças com esta última condição devem ser internadas, devido à ampla variabilidade das condições subjacentes a este evento.  
Nos casos de CFS, não estão recomendados exames laboratoriais de rotina, nem EEG ou exames de imagens. Uma punção lombar só é indicada, nestes casos, na presença de sinais meníngeos, em pacientes em uso de antibióticos nos dias que antecederam a crise e em crianças com menos de 18 meses de idade com sinais de deterioração clínica<sup>23</sup> . Já nos pacientes com CFC, estão recomendados exames laboratoriais, de imagem, EEG e punção lombar, na busca de uma causa para a condição, e nestes casos, o tratamento será voltado para a causa encontrada.  
Vários estudos, incluindo meta-análises, demonstraram que a administração contínua de fenobarbital e ácido valproico é eficaz na prevenção da recorrência de crises febris simples. Há, no entanto, contraindicações para a administração desses fármacos, como potenciais efeitos adversos, que podem superar os benefícios do tratamento. Portanto, dado o prognóstico benigno das CFS, que não causam danos permanentes e tendem a entrar em remissão espontaneamente com a idade, e os efeitos adversos potenciais dos fármacos antiepilépticos, a profilaxia para recorrências de CFS não é recomendada.  
Na maioria dos casos, as CFS cessam espontaneamente (em 2 a 3 minutos) e não requerem tratamento. Os principais fatores de risco para recorrência de crises febris são primeira ocorrência de CF com menos de 1 ano de idade, história familiar (HF) de epilepsia ou CF e curta duração do episódio febril. A frequência de recorrência é de 10% em pacientes sem fatores de risco; 25% a 50% na presença de 1 a 2 fatores de risco; 50% a 100% na presença de 3 ou mais fatores de risco<sup>24</sup> . O risco de epilepsia é estimado em cerca de 1% a 1,5% em pacientes com CFS<sup>26</sup> , apenas um pouco maior que a incidência na população em geral, que é aproximadamente 0,5%. O risco de epilepsia em indivíduos com CFC é estimado entre 4 e 15%<sup>25</sup> . A indicação da profilaxia pode ser feita após o primeiro episódio caso, desde que um ou mais fatores preditivos estejam presentes.  
No entanto, dois cenários devem ser considerados: a) pacientes com um ou mais episódios de CFS e pais confiáveis; b) pacientes com CFS frequentes num curto espaço de tempo (3 ou mais em 6 meses, 4 ou mais em um ano). Nestes casos, a terapia intermitente, que é a administração retal (primeira escolha), ou oral de diazepam, pode ser considerada como uma medida de emergência e administrada, no início da febre, na dose de 0,4 a 0,5 mg/kg, para repetir uma segunda vez, se a febre persistir após 8 horas. Alternativamente, pode ser utilizado o clobazam por via oral, nas seguintes doses: crianças com até 5 kg, 5 mg/dia; de 5 a 10 kg, 10 mg/dia; de 11 a 15 kg, 15 mg/dia; e acima 15 kg, 20 mg/dia. Tipicamente, a administração de diazepam deve ser limitada a duas doses, embora condições clínicas específicas possam exigir uma terceira dose após pelo menos 24 horas da primeira administração.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Pacientes com doença psiquiátrica** -->
Depressão e ansiedade são frequentemente subdiagnosticados em pacientes com epilepsia, especialmente nos pacientes com epilepsia do lobo temporal (ELT) e nos pacientes com epilepsias refratárias<sup>26</sup> . No caso da depressão, a utilização de fármacos inibidores da recaptação sináptica seletiva da serotonina (IRSS) e de ansiolíticos é bastante segura, apenas devendo ser evitadas a maprotilina, a bupropiona em altas doses (> 450 mg/dia), a clomipramina e a amitriptilina em altas doses (> 200 mg/dia)<sup>27</sup> . A pregabalina está atualmente licenciada para o tratamento de transtorno de ansiedade generalizada, e um estudo recente sugeriu haver efeitos sinergísticos entre fármacos antidepressivos e pregabalina<sup>28</sup> .  
Além disso, nos casos de pacientes com transtornos do humor e de ansiedade, deve ser dada preferência a fármacos antiepilépticos com efeito estabilizador do humor, tais como ácido valproico, lamotrigina e carbamazepina<sup>29</sup> .  
No caso de comorbidade com transtornos psicóticos, não há evidências claras de que uma geração de fármacos antipsicóticos é mais ou menos eficaz do que a outra. Na ausência de orientação específica para tratamento, os sintomas psicóticos  
8  
no contexto de uma psicose interictal devem ser tratados de acordo com os protocolos estabelecidos de tratamento para esquizofrenia primária e psicoses relacionadas<sup>30</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Pacientes com HIV/SIDA** -->
O tratamento da epilepsia concomitante com agentes anti-retrovirais (ARV) pode requer ajustes para manter as concentrações séricas destes medicamentos. As recomendações sobre o uso dos AVR devem ser consultadas no Protocolo Clínico e Diretrizes Terapêuticas para o Manejo da Infecção pelo HIV em adultos. Neste protocolo o uso de dolutegravir não é recomendado em uso de fenitoína, fenobarbital, oxcarbamazepina, carbamazepina, devendo ser recomendado o uso do raltegravir. Os pacientes em uso desses anticonvulsivantes e raltegravir deverão passar por avaliação quanto à possibilidade de suspensão ou troca dos anticonvulsivantes, para que seja viável a troca do RAL pelo DTG.  
Segundo recomendações de um painel conjunto entre a Academia Americana de Neurologia e a ILAE<sup>31</sup> , em até 55% das pessoas que tomam agentes anti-retrovirais (ARV) e pacientes sob tratamento com fenitoína podem exigir um aumento de dose de lopinavir/ritonavir de aproximadamente 50%, para manter as concentrações séricas destes ARV.  
Pacientes que se tratam com ácido valproico podem exigir uma redução da dose de zidovudina para manter as concentrações séricas deste ARV inalteradas<sup>32</sup> . A coadministração de ácido valproico e efavirenz pode não requerer ajuste de dose do efavirenz<sup>31</sup> .  
Pacientes que se tratam com ácido valproico podem exigir uma redução da dose de zidovudina para manter as concentrações séricas deste ARV inalteradas<sup>32</sup> . A coadministração de ácido valproico e efavirenz pode não requerer ajuste de dose do efavirenz<sup>31</sup> .  
Pacientes que se tratam com ritonavir/atazanavir podem requerer um aumento da dose de lamotrigina de aproximadamente 50%, para manter concentrações séricas inalteradas da lamotrigina. A coadministração de raltegavir/atazanavir e lamotrigina pode não requerer ajuste da dose de lamotrigina<sup>32</sup> . A coadministração de raltegravir e midazolam pode não requerer o ajuste da dose do midazolam<sup>31</sup> .  
Os pacientes devem ser informados que não está claro se o ajuste de doses é necessário quando outros FAE e ARV são combinados. Pode ser importante evitar fármacos antiepilépticos indutores enzimáticos nos casos sob tratamento com ARV que incluem inibidores de protease ou inibidores da transcriptase reversa, porque as interações farmacocinéticas podem resultar em falhas virológicas, o que tem implicações clínicas para a progressão da doença e desenvolvimento de resistência a ARV. E se tais esquemas terapêuticos são necessários para controle de crises, os pacientes podem ser monitorados por meio de avaliações farmacocinéticas para garantir a eficácia do protocolo ARV<sup>31</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Condução de veículos** -->
A permissão para dirigir veículos ou a renovação da habilitação para pessoas com epilepsia é um processo que envolve médicos peritos examinadores, consultores das autoridades de trânsito e os médicos destes pacientes. Para se habilitar como motorista, o candidato deverá submeter-se ao exame de aptidão física e mental (artigo 147 da Lei nº. 9.503 de 23 de setembro de 1997). A Resolução nº 425/2012 do Conselho Nacional de Trânsito (CONTRAN), que estabeleceu normas regulamentadoras para o procedimento do exame, faz referência específica à epilepsia e ela está do ponto de vista legal incluída entre as condições que necessitam de uma avaliação médica, que pode permitir ou restringir a condução veicular.  
O candidato deverá passar pelos seguintes procedimentos:  
- O condutor ou candidato à habilitação que, no momento do exame de aptidão física e mental, por meio da anamnese ou da resposta ao questionário, declarar ser epiléptico ou fazer uso de fármacos antiepilépticos, deverá ter como primeiro resultado “necessita de exames complementares ou especializados” e ser solicitado a trazer informações do seu médico assistente, que acompanhe o candidato há, no mínimo, um ano, por meio de relatório padronizado.  
- O relatório padronizado deverá informar dados sobre o tipo de crise epiléptica, o número estimado de crises nos últimos  
- 6, 12, 18 e 24 meses, grau de confiança na informação prestada, ocorrência de crises exclusivamente no sono, fatores precipitantes  
9  
conhecidos, tipo da síndrome epiléptica, resultado do último EEG e dos exames de imagem, medicamentos em uso, duração do uso, retirada do medicamento quando for o caso, especialidade do médico assistente, início do tratamento e parecer favorável ou não à liberação para a direção de veículos automotores. O relatório deverá conter a assinatura e o carimbo do médico assistente e a assinatura de ciência do paciente (candidato).  
A resolução do CONTRAN, bem como o questionário, a ser respondido pelo candidato, e o relatório padronizado, a ser preenchido pelo médico assistente, encontram-se disponíveis para consulta no site da Associação Brasileira de Epilepsia (http://www.epilepsiabrasil.org.br/duvidas-frequentes).

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Estado de mal epiléptico** -->
A nova definição de estado de mal epiléptico (EME) proposta pela ILAE é a seguinte: condição resultante da falha dos mecanismos responsáveis pelo término das crises epilépticas ou pelo desencadeamento de mecanismos que levam ao prolongamento anormal das crises (ponto de tempo t1). A EME é uma condição que pode ter consequências em longo prazo (ponto de tempo t2), incluindo morte neuronal, lesão neuronal e alteração de redes neuronais, dependendo do tipo e duração das crises. Esta definição é conceitual, com duas dimensões operacionais: a primeira (t1) é a duração da crise além da qual ela deva ser considerada "atividade de crise contínua". É o momento de iniciar medidas terapêuticas de urgência. O segundo ponto de tempo (t2) é o tempo de duração de crise após o qual existe um risco aumentado para consequências em longo prazo. Tem, portanto, um valor prognóstico. No caso do EME convulsivo (TCG), os pontos de tempo t1 (5 min) e t2 (30 min) foram definidos, baseados em experiências com animais e pesquisas clínicas<sup>32</sup> .  
O tratamento medicamentoso precoce ideal para o EME convulsivo ainda não está totalmente esclarecido, mas, apesar da escassez de ensaios controlados randomizados bem desenhados, conclusões práticas e um algoritmo de tratamento integrado para o tratamento do EME convulsivo pode ser estabelecido<sup>33</sup> . O protocolo de tratamento do EME deve seguir uma sequência préestabelecida<sup>34</sup> , que compreende primeiro fármacos benzodiazepínicos (primeira linha), depois um agente antiepiléptico endovenoso (EV) (segunda linha), seguido, quando necessário, por anestesia geral (terceira linha). A primeira linha é o uso de diazepam EV, na dose usual de 5 a 10 mg, conforme a necessidade, até uma dose máxima de 20 mg, numa velocidade de infusão de 5 mg/min, para evitar depressão respiratória. Mesmo que a crise cesse, o índice de recorrência é alto, e a maioria dos pacientes irá precisar de fármacos antiepilépticos de segunda linha. Neste estágio, há no Brasil dois fármacos disponíveis para uso EV: a) fenitoína, na dose de 18 mg/kg (15-20), numa velocidade de infusão máxima de 50 mg/min, que deve ser administrada através de uma veia calibrosa ou central, com monitorização do ECG e da pressão arterial (PA); b) fenobarbital 15 mg/kg, infundidos a 100 mg/min<sup>35</sup> . Se as crises recorrerem, em pacientes que estão hemodinamicamente estáveis, deve-se otimizar a dose do primeiro fármaco de segunda linha e, após, considerar o uso de um segundo fármaco de segunda linha. O passo seguinte (após 30 minutos da admissão, sem resposta) é a terceira linha, que utiliza anestesia geral, com intubação e ventilação. Os medicamentos devem ser administrados em UTI. Podem ser utilizados: (1) propofol (1,5 a 3 mg/kg, em bolo – com atenção para a ocorrência de hipotensão e bradicardia) e 1 a 5 mg/kg/h, na manutenção; (2) midazolam (1 mg EV em bolo; após 0,05 a 0,20 mg/kg/hora; ou ainda (3) tiopental 3 a 5 mg/kg/h. No caso do uso de anestésicos gerais, está indicada a monitorização contínua por EEG, para avaliar o nível de sedação e abolição das descargas epileptiformes.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Convulsões em pacientes com microcefalia** -->
Diante da epidemia de microcefalia e outras anormalidades congênitas associadas com o vírus Zika no Brasil, foi ampliado o uso de levetiracetam para o tratamento de crises epilépticas em pacientes com microcefalia, como terapia adjuvante, nos casos de falha terapêutica de outros antiepilépticos preconizados neste Protocolo.  
**7 TRATAMENTO**  
10  
O objetivo do tratamento da epilepsia é propiciar a melhor qualidade de vida possível para o paciente, pelo alcance de um adequado controle de crises, com um mínimo de efeitos adversos, buscando, idealmente, uma remissão total das crises.  
Os fármacos antiepilépticos são a base do tratamento da epilepsia. Os tratamentos não medicamentosos são viáveis apenas em casos selecionados, e são indicados após a falha dos antiepilépticos<sup>36</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **7.1. Tratamento Medicamentoso** -->
Deve-se buscar um fármaco antiepiléptico com um mecanismo de ação eficaz sobre os mecanismos de geração e propagação, específicos das crises do paciente, individualmente<sup>37</sup> . Os principais mecanismos de ação dos fármacos antiepilépticos são: bloqueio dos canais de sódio, aumento da inibição GABAérgica, bloqueio dos canais de cálcio e ligação à proteína SV2A da vesícula sináptica<sup>38</sup> .  
A decisão de iniciar um tratamento antiepiléptico baseia-se fundamentalmente em três critérios: risco de recorrência de crises, consequências da continuação das crises para o paciente e eficácia e efeitos adversos do fármaco escolhido para o tratamento. O risco de recorrência de crises varia de acordo com o tipo de crise e com a síndrome epiléptica do paciente<sup>39</sup> , e é maior naqueles com descargas epileptiformes no EEG, transtornos neurológicos congênitos, crises sintomáticas agudas prévias, pacientes com lesões cerebrais e pacientes com paralisia de Todd<sup>40</sup> . Recorrência das crises epilépticas são inaceitáveis para pacientes que necessitam dirigir, continuar empregados ou são responsáveis por pessoas mais vulneráveis<sup>40</sup> , nestes indivíduos, é racional optar por tratamento mesmo após uma primeira crise. A decisão de iniciar tratamento fica bem mais fortalecida após a ocorrência de duas ou mais crises epilépticas não provocadas com mais de 24 horas de intervalo.  
Os fármacos antiepilépticos de 1ª (ditos tradicionais), 2ª (ditos recentes) e 3ª (ditos novos) linhas têm eficácia equivalente, porém o perfil de efeitos adversos e de interações medicamentosas é mais favorável aos fármacos antiepilépticos mais recentes. Por outro lado, por serem recentes, não se conhecem os eventuais efeitos adversos do uso destes fármacos por 20 a 30 anos. O estudo SANAD confirma esta afirmação e agrega que a escolha do tratamento inicial não tem impacto na qualidade de vida (QV) após 2 anos de seguimento. O que influencia significativamente a QV dos pacientes com epilepsia são a persistência de crises, os efeitos adversos do fármaco e a falha do tratamento inicial<sup>41–43</sup> .  
Com relação a ensaios clínicos randomizados (ECR), existem, até o momento, seis estudos bem delineados<sup>43–48</sup> , todos envolvendo pacientes com epilepsias focais. Em geral, a lamotrigina e gabapentina foram mais efetivas do que a carbamazepina em idosos<sup>47,49</sup> . Em adultos jovens, a carbamazepina foi mais efetiva do que o fenobarbital, primidona e a vigabatrina<sup>45,48</sup> , enquanto o ácido valproico teve eficácia comparável à da carbamazepina. Um ensaio aberto randomizado comparou carbamazepina, gabapentina, lamotrigina, oxcarbazepina e topiramato em epilepsias focais, bem como ácido valproico, lamotrigina e topiramato em epilepsias generalizadas e inclassificáveis<sup>47</sup> . O estudo concluiu que a lamotrigina é mais efetiva do que a carbamazepina, gabapentina e topiramato como monoterapia de primeira linha para epilepsia focal, e o ácido valproico é mais efetivo (eficácia + tolerabilidade) do que o topiramato e mais eficaz do que a lamotrigina nas epilepsias generalizadas e inclassificáveis. Entretanto, a revisão sistemática da Cochrane conclui pela igualdade de eficácia<sup>48</sup> .  
As recomendações da ILAE<sup>50</sup> , baseadas apenas em evidências de eficácia e efetividade para escolha de fármacos antiepilépticos, são as seguintes:  
- Adultos com epilepsia focal – carbamazepina, fenitoína e ácido valproico;  
- Crianças com epilepsia focal – carbamazepina;  
- Idosos com epilepsia focal – lamotrigina e gabapentina;  
- Adultos e crianças com crises TCG, crianças com crises de ausência, epilepsia rolândica e EMJ – nenhuma evidência  
- alcançou níveis A ou B.  
A seleção do fármaco deverá levar em consideração outros fatores além da eficácia, tais como efeitos adversos, especialmente para alguns grupos de pacientes (crianças, mulheres em idade reprodutiva, gestantes e idosos), tolerabilidade  
11  
individual e facilidade de administração. Especificamente para crises de ausência, uma análise sistemática que incluiu cinco pequenos estudos, dos quais apenas um randomizado, comparando a eficácia de etossuximida, ácido valproico, lamotrigina e placebo, não foi suficiente para levantar evidências úteis para a prática clínica<sup>51</sup> . Mais recentemente, um ECR com 453 crianças com diagnóstico recente de epilepsia do tipo ausência comparou a eficácia do ácido valproico com a da etossuximida e da lamotrigina. Os resultados mostraram eficácia semelhante para o ácido valproico e a etossuximida, e inferior para a lamotrigina<sup>52</sup> .  
Em caso de falha do primeiro fármaco, deve-se tentar sempre fazer a substituição gradual por outro, de primeira escolha, mantendo-se a monoterapia. Em caso de falha na segunda tentativa de monoterapia, pode-se tentar a combinação de dois fármacos antiepilépticos conforme evidências de benefício em estudos de nível I e como indicado neste Protocolo<sup>53,54</sup> . Poucos pacientes parecem obter benefício adicional com a associação de mais de dois fármacos, por isso, tal conduta não está preconizada neste Protocolo. Em um estudo prospectivo, 47% de 470 pacientes em tratamento inicial se beneficiaram com o primeiro fármaco em monoterapia, 13% com o segundo FAE em monoterapia e apenas 3% com associação de dois fármacos. Entretanto, outros autores relatam controle adicional de crises em 10% a 15% dos pacientes refratários a monoterapia com acréscimo de um segundo fármaco<sup>55</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Carbamazepina** -->
A carbamazepina é um iminodibenzil que inibe as descargas neuronais corticais repetitivas, sustentadas e de alta frequência pelo bloqueio dos canais de sódio dependente de voltagem. Também possui uma discreta ação anticolinérgica.  
Sua eficácia foi avaliada em duas revisões sistemáticas<sup>56,57</sup> . Tudur e colaboradores<sup>56</sup> compararam carbamazepina e fenobarbital em monoterapia. Em quatro diferentes ensaios, incluindo 684 participantes, o estudo não encontrou diferenças entre esses dois fármacos na remissão de crises por 12 meses, nem no tempo de aparecimento da primeira crise. O fenobarbital é menos tolerado do que a carbamazepina. Gamble e colaboradores<sup>57</sup> compararam a carbamazepina com a lamotrigina e encontraram maior eficácia da carbamazepina e melhor tolerância à lamotrigina em epilepsias focais e generalizadas. Esta revisão sistemática estudou cinco ensaios, com um total de 1.384 pacientes incluídos.  
Há uma carência de estudos que comparem a oxcarbazepina e carbamazepina, este último normalmente considerado de primeira linha para crises focais. A igualdade de eficácia foi demonstrada no tratamento de epilepsias focais refratárias em revisão sistemática conduzida por Castillo e colaboradores<sup>58</sup> , que avaliou dois ECR, incluindo 961 pacientes, e encontrou uma razão de chances (RC) para redução de 50% ou mais na frequência de crises de 2,96 (IC95%: 2,20-4,00). Para as crises generalizadas, o ácido valproico permanece como fármaco antiepiléptico de primeira escolha<sup>9</sup> .  
Há relatos de piora das frequências e intensidades das crises, bem como de maior ocorrência de eventos adversos, em pacientes com síndrome de Angelman que utilizam carbamazepina<sup>59–62</sup> .  
Indicações:  
- Monoterapia ou terapia adjuvante de crises focais, com ou sem generalização secundária;  
- Crises TCG em pacientes com mais de um ano de idade.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Clobazam** -->
O principal sítio de ação dos benzodiazepínicos é um receptor pós-sináptico do ácido gama-aminobutírico (GABA), o principal neurotransmissor inibitório do sistema nervoso central (SNC). Ao ligar-se aos receptores GABA-A, o clobazam, como todos os benzodiazepínicos, aumenta a frequência de aberturas destes receptores, aumentando, assim, as correntes inibitórias neuronais.  
O clobazam é rapidamente absorvido pelo trato digestivo, atingindo picos de concentração máximos no sangue em cerca de 90 minutos. A meia-vida é longa (em torno de 20 horas). Este fármaco é fortemente ligado às proteínas séricas (cerca de 85% das moléculas). Suas principais vantagens são a alta eficácia, o rápido início de ação e a boa tolerabilidade. Possíveis desvantagens são o desenvolvimento de tolerância em 40% dos casos e problemas relacionados à sua retirada (abstinência).  
12  
Revisão sistemática conduzida por Michael e Marson<sup>63</sup> , incluindo 196 pacientes, concluiu que o clobazam como adjuvante pode reduzir a frequência de crises nas epilepsias focais. No entanto, o estudo não define que tipo de paciente poderá se beneficiar mais com o fármaco, nem o período de tempo em que o benefício se manterá.  
Indicações:  
- Terapia adjuvante de crises parciais e generalizadas refratárias;  
- Terapia intermitente (por exemplo, crises catameniais).  
- **Clonazepam**  
Benzodiazepínico com larga utilização na Europa e nos EUA já há várias décadas, o clonazepam é bastante útil no tratamento de crises mioclônicas, podendo ser usado em monoterapia, mas mais frequentemente é utilizado na terapia adjuvante<sup>64</sup> . Uma dose única de 0,5 a 2 mg, tomada na hora de deitar, é frequentemente efetiva no controle de crises mioclônicas, tanto em monoterapia como na terapia adjuvante dos casos mais resistentes.  
Seu principal mecanismo de ação, a exemplo do clobazam, é sua ligação aos receptores GABA-A, como um agonista, resultando em efeito inibitório sobre o SNC, devido a promoção de influxo neuronal do íon cloreto<sup>65</sup> .  
Indicações:  
- Adultos e crianças;  
- Crises de ausência (incluindo ausências atípicas);  
- Crises TCG primárias ou secundárias;  
- Crises tônicas;  
- Crises clônicas;  
- Crises focais;  
- Crises mioclônicas;  
- Mioclonias e movimentos anormais associados.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Levetiracetam** -->
O levetiracetam é um s-enantiômero, análogo do piracetam, introduzido no mercado em 2000, e que agora é comercializado em mais de 50 países<sup>66,67</sup> . Acredita-se que o levetiracetam exerça suas propriedades antiepilépticas ligando-se especificamente à proteína 2A da vesícula sináptica<sup>68</sup> , interferindo com a exocitose e liberação de neurotransmissor na fenda sináptica<sup>69</sup> . Com base nos resultados de ensaios pivotais duplo-cegos realizados nos Estados Unidos e na Europa, seu uso como terapia adjuvante para crises focais em adultos foi aprovado, e apresenta controle eficaz de crises em adultos, tanto focais quanto generalizadas. Verificou-se que tem efeito antiepiléptico não inferior à carbamazepina<sup>70</sup> .  
O levetiracetam apresenta um perfil farmacocinético favorável, com rápido início de ação e baixa ligação a proteínas, e acredita-se que, por isso, apresente menos efeitos adversos e menor interação com outros fármacos<sup>71</sup> .  
Uma meta-análise, com 11 estudos e o total de 1.861 pacientes participantes, concluiu que, comparado a placebo, o levetiracetam como terapia adjuvante, na dose de 2 g/dia, proporcionou redução quatro vezes maior de crises focais em adultos (taxa de resposta de 30%). Em crianças, na dose de 60 mg/kg/dia, o levetiracetam apresenta o dobro de eficácia em relação a placebo, com taxa de resposta de 25%<sup>72</sup> . A eficácia e segurança do levetiracetam foram confirmadas em recente meta-análise<sup>73</sup> , na qual o fármaco utilizado como terapia adjuvante em epilepsias com múltiplos tipos de crises foi significativamente superior ao placebo na redução na frequência de crises em pelo menos 50% e no índice de pacientes com remissão de crises, além de ter demonstrado frequência muito baixa de efeitos adversos sérios (trombocitopenia, leucopenia, rash cutâneo).  
- Indicações:  
- Pacientes com epilepsia focal (crises simples ou complexas) e epilepsia primariamente generalizada em adultos e  
- crianças como terapia adjuvante em casos refratários à monoterapia com antiepiléptico de primeira linha;  
- Crises mioclônicas em pacientes com EMJ, como terapia adjuvante em casos refratários;  
13  
- Tratamento de crises epilépticas em pacientes com microcefalia, como terapia adjuvante, no caso de falha terapêutica  
- de outros antiepilépticos preconizados neste Protocolo.  
- O levetiracetam tem diferentes indicações para cada tipo de crise e respectiva faixa etária. As posologias nos esquemas  
- de administração devem ser seguidas conforme descrito na **Sessão 7.3 Fármacos e esquemas de administração** .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Etossuximida** -->
Este fármaco apresenta um espectro de ação antiepiléptico bastante restrito. Seu principal mecanismo de ação é o bloqueio  
dos canais de cálcio, com consequente inibição do circuito tálamo-cortical, que está intimamente relacionado à geração das crises de ausência.  
A etossuximida é útil no tratamento em monoterapia das crises de ausência típicas e como terapia adjuvante nas mioclonias negativas, crises atônicas e mioclonias<sup>58</sup> .  
Indicações:  
- Tratamento de crises de ausência em pacientes com ou mais de 3 anos de idade;  
- Tratamento adjuvante de mioclonias negativas, crises astáticas e certos tipos de epilepsias mioclônicas.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Fenitoína** -->
Seu principal mecanismo de ação é o bloqueio dos canais de sódio dependentes de voltagem, o que lhe confere grande eficácia contra crises epilépticas de início focal.  
Após ingestão, a fenitoína atinge picos de concentração em cerca de 6 horas, sendo fortemente ligada às proteínas plasmáticas (mais de 85%), com uma meia-vida de eliminação em torno de 20 horas. Está contraindicada nas crises de ausência e mioclônicas, podendo ser efetiva nas crises tônicas (próprias da síndrome de Lennox-Gastaut)<sup>74,75</sup> .  
Suas principais desvantagens são efeitos adversos de curto e longo prazos, limitações para uso crônico em mulheres (efeitos estéticos e propriedades teratogênicas) e janela terapêutica restrita e muito próxima dos níveis tóxicos, necessitando de frequentes monitorações dos níveis séricos. Devido à sua farmacocinética peculiar, após atingir doses em torno de 300 mg/dia, pequenos incrementos de dose podem gerar aumentos desproporcionais dos níveis séricos, o que exige cautela em sua administração.  
Numa revisão sistemática incluindo apenas dois ECR que compararam a oxcarbazepina com a fenitoína, foram estudados 480 pacientes com crises parciais ou convulsões TCG. Os resultados foram controversos: quando utilizados os desfechos “tempo para suspensão do tratamento e tempo para incidência de uma primeira crise”, houve vantagem para a oxcarbazepina. Porém, com o desfecho “remissão de crises, de 6 a 12 meses”, não houve diferença entre os fármacos. Em atualização recente, concluiuse que não é possível avaliar se a oxcarbazepina é mais eficaz em termos de controles de crises, dada a heterogeneidade dos dados e problemas metodológicos dos estudos originais<sup>49,76</sup> .  
Revisões sistemáticas não encontraram diferenças significativas de eficácia entre fenitoína e fenobarbital em monoterapia para crises focais e TCG (apesar de a fenitoína ter sido mais bem tolerada)<sup>77,78</sup> , entre fenitoína e ácido valproico em monoterapia para crises focais e TCG<sup>79</sup> e entre fenitoína e carbamazepina em monoterapia para crises epilépticas<sup>48</sup> .  
Indicações:  
- Tratamento de crises TCG, focais complexas, ou combinação de ambas, em crianças, adolescentes e adultos;  
- Prevenção e tratamento de crises epilépticas durante ou após procedimento neurocirúrgico;  
- Tratamento das crises tônicas, próprias da síndrome de Lennox-Gastaut.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Fenobarbital** -->
Este fármaco possui largo espectro de ação com efetividade similar à de outros fármacos antiepilépticos. É seguro e disponível em apresentações orais e parenterais. Seu principal mecanismo de ação é o prolongamento da abertura dos canais de cloro, dos receptores GABA-A e consequente hiperpolarização da membrana pós-sináptica. O fenobarbital também pode  
14  
bloquear os canais de sódio e potássio, reduzir o influxo de cálcio pré-sináptico e, provavelmente, reduzir as correntes mediadas pelo glutamato.  
Apresenta rápida absorção por via oral, porém uma meia-vida de eliminação longa (2 a 7 dias), apesar de ser fracamente ligado às proteínas (20% a 50%). As principais desvantagens são seus efeitos colaterais, principalmente na área cognitiva, o que limita seu uso tanto em crianças quanto em idosos. É inadequado tentar a substituição de fenobarbital em caso de pacientes bem controlados, a menos que seu uso esteja associado a efeitos adversos inaceitáveis. A retirada deve ser feita em dosagens muito pequenas e por longo período de tempo devido ao risco de crises de abstinência. Doses elevadas devem ser evitadas (em adultos, dose máxima de 300 mg/dia).  
O fenobarbital ainda é largamente utilizado na prática clínica, por apresentar eficácia equivalente à de fenitoína no tratamento em monoterapia tanto de crises focais como nas generalizadas<sup>80</sup> .  
Indicação:  
 Tratamento de crises focais e generalizadas de pacientes de qualquer idade, inclusive recém-nascidos.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Gabapentina** -->
A gabapentina apresenta estrutura semelhante à do GABA, no entanto não tem nenhuma interação com os receptores GABA-A ou GABA-B. Seu sítio de ligação é a proteína alfa2-gama, uma sub-unidade dos canais de cálcio dependentes de voltagem, embora ainda não haja uma compreensão completa do exato mecanismo antiepiléptico deste fármaco<sup>81</sup> .  
Ensaios clínicos testaram sua eficácia apenas com a dose de 2.400 mg/dia, mas, na prática, doses mais elevadas podem ser benéficas<sup>82,83</sup> . Em ECR duplo-cego, a gabapentina demonstrou eficácia e tolerabilidade semelhantes às de carbamazepina em monoterapia da epilepsia parcial com ou sem generalização secundária<sup>84,85</sup> . No entanto, num estudo aberto comparativo de efetividade (eficácia mais tolerabilidade), a gabapentina mostrou ser inferior a lamotrigina no desfecho “tempo de falha no tratamento” e inferior a carbamazepina no desfecho “tempo de remissão de crises em 12 meses”<sup>50</sup> . Em crianças, ela foi avaliada para terapia adjuvante de crises focais refratárias. Em ECR duplo-cego contra placebo, em crianças de 3-12 anos, a eficácia de gabapentina foi significativa em doses de 23-35 mg/kg/dia<sup>86</sup> . Em todos os estudos, houve boa tolerabilidade com baixa toxicidade.  
A gabapentina apresenta uma absorção saturável, dependente de dose, ou seja, em doses maiores pode haver menor absorção no duodeno, levando a uma menor eficácia<sup>87</sup> . A absorção varia de indivíduo para indivíduo. Por não ser ligada a proteínas plasmáticas, é eliminada pelos rins, não interferindo com o metabolismo de outros fármacos<sup>88</sup> , o que a torna ideal para idosos e para pacientes com doença crônica que geralmente usam outros medicamentos<sup>45</sup> .  
Estudos clínicos demonstraram boa tolerância, não tendo observado efeitos adversos significativos. Estudos em crianças indicaram a ocorrência de alguns distúrbios comportamentais, como agressividade e irritabilidade, que parecem ser mais frequentes em crianças com deficiência mental ou com problemas comportamentais prévios<sup>89,90</sup> . Sedação, ataxia e ganho de peso também foram relatados. A gabapentina tem poucos efeitos cognitivos, não tendo sido observados efeitos teratogênicos durante a gestação<sup>91,92</sup> .  
Revisão sistemática da Cochrane publicada em 2009 e atualizada em 2013, incluindo 11 ensaios clínicos randomizados e um total de 2.125 pacientes, concluiu que a gabapentina tem eficácia como agente adjuvante em pacientes com epilepsia focal refratária. No entanto, foi feita a ressalva de que os trabalhos revisados foram de relativa curta duração, deixando, portanto, de mostrar evidências de eficácia de longo prazo. Os resultados também não podem ser extrapolados para monoterapia ou para pacientes com outros tipos de epilepsia<sup>93,94</sup> . A prática clínica também mostra que o fármaco é pouco eficaz para o tratamento da epilepsia.  
Indicação:  
- Terapia adjuvante de crises focais com ou sem generalização secundária em pacientes com mais de 3 anos de idade.  
15

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Topiramato** -->
Este fármaco é bem absorvido e minimamente ligado às proteínas plasmáticas. É parcialmente metabolizado no fígado, e cerca de 60% da dose são excretados de forma inalterada na urina. Seu metabolismo sofre a influência de fármacos indutores de enzimas hepáticas, tendo a meia-vida diminuída com o uso concomitante destes fármacos.  
O topiramato apresenta um largo espectro de eficácia, e sua estrutura é distinta da dos outros antiepilépticos, tendo sido implicado em vários mecanismos de ação, incluindo o bloqueio dos canais de sódio dependentes de voltagem, modulação negativa dos canais de cálcio tipo-L, ativação da condutância do potássio, potencialização da ação inibitória GABAérgica, além de antagonismo a receptores glutamatérgicos e inibição da anidrase carbônica<sup>80</sup> .  
Revisão sistemática conduzida por Jette e colaboradores<sup>95</sup> confirmou a eficácia do topiramato como fármaco adjuvante no tratamento das epilepsias focais refratárias. Nesse estudo, foram revisados dez ECR, incluindo 1.312 pacientes. Os estudos foram relativamente de curta duração (11-19 semanas na fase duplo-cega). Comparado ao placebo, o risco relativo (RR) para 50% ou mais de redução de crises foi de 2,85 (IC95%: 2,27-3,59). Uma análise de regressão de doses revelou aumento do efeito terapêutico proporcional à dose utilizada, mas nenhuma vantagem adicional com doses acima de 300 mg/dia. Ataxia, tonturas, fadiga, náusea, sonolência e “anormalidades do pensamento” são efeitos adversos associados ao topiramato.  
Em recente revisão sistemática, Ben-Menachem e colaboradores<sup>96</sup> encontraram três estudos randomizados, controlados e duplo-cegos que demonstraram adequada efetividade do topiramato em monoterapia em pacientes com epilepsia recentemente diagnosticada. Os estudos mostraram que o uso de altas doses de topiramato (400-500 mg/dia), comparado ao de baixas doses (50 mg/dia), está associado a significativa redução do número de crises após 6 meses de tratamento (54% _versus_ 39%; p=0,02) e a maior tempo para a ocorrência de uma primeira crise (p<0,001), além de maior probabilidade de remissão de crises após 12 meses de tratamento (76% _versus_ 59%; p=0,001). Estes desfechos estiveram diretamente ligados às concentrações plasmáticas de topiramato<sup>95,96</sup> . Em estudo comparativo com carbamazepina (600 mg/dia) e com ácido valproico (1.250 mg/dia), não se observou diferença significativa na redução de crises em 6 meses de tratamento em relação a topiramato (100 mg/dia e 200 mg/dia). Os índices de redução de crises se mantiveram entre 44% e 49% com os três fármacos. Os efeitos adversos mais encontrados com o uso de topiramato durante a fase de escalonamento de doses nos três estudos foram parestesias (25%), fadiga (16%), tontura (13%), sonolência (13%) e náusea (10%). Na fase de manutenção, foram observadas cefaleia (20%), diminuição do apetite (11%) e perda de peso (11%)<sup>96–98</sup> . Arroyo e colaboradores<sup>83</sup> encontraram disfunção cognitiva em 15% dos pacientes em uso de 50 mg/dia e em 24% dos pacientes em uso de 400 mg/dia. A incidência destes efeitos adversos parece ser menor em crianças e adolescentes<sup>99</sup> .  
Em estudo comparativo entre topiramato (50-175 mg/dia) e ácido valproico (500-1.750 mg/dia), em pacientes com EMJ, Araújo Filho e colaboradores<sup>100</sup> não encontraram diferenças significativas em 11 de 13 subtestes neuropsicológicos (WISC III) entre os grupos. No entanto, o ácido valproico foi associado a escores significativamente maiores em testes de memória de curto prazo, atenção e velocidade de processamento, quando comparado com topiramato. Outro efeito adverso frequente observado com o uso de topiramato foi nefrolitíase (15%).  
Recente estudo aberto randomizado demonstrou que a eficácia do topiramato em adultos e crianças é equivalente à de carbamazepina nas epilepsias focais e à de ácido valproico nas epilepsias generalizadas recentemente diagnosticadas. No entanto, o estudo teve uma série de limitações referentes ao não cegamento, não controle de doses utilizadas e a não classificação adequada dos tipos de crises<sup>31,34</sup> . O topiramato pode ser útil como adjuvante no tratamento de pacientes com síndrome de LennoxGastaut<sup>101,102</sup> .  
Indicações:  
 Monoterapia de crises focais ou primariamente do tipo TCG em pacientes mais de 10 anos de idade com intolerância ou refratariedade a outros medicamentos de primeira linha;  
16  
 Terapia adjuvante de crises focais, primariamente generalizadas ou crises associadas com a síndrome de LennoxGastaut em pacientes mais de dois anos de idade.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Lamotrigina** -->
O principal mecanismo de ação da lamotrigina parece envolver a inibição dos canais de sódio dependentes de voltagem, resultando em inibição dos potenciais elétricos pós-sinápticos. Não parece ter efeito GABAérgico e não tem semelhança química com os antiepilépticos indutores enzimáticos<sup>103</sup> .  
Alguns autores sugerem uma associação de lamotrigina com ácido valproico para o tratamento de pacientes refratários, a fim de se obter uma eficácia maior, devido às possíveis interações farmacodinâmicas favoráveis entre os dois fármacos. Revisão sistemática da Cochrane, recentemente revisada, reafirmou a eficácia da lamotrigina como terapia adjuvante na redução da frequência de crises em pacientes com epilepsias focais refratárias. Foram revisados os casos de 1.243 pacientes em três estudos de lamotrigina como fármaco adjuvante e em oito estudos cruzados. Comparada ao placebo, a lamotrigina apresentou maior redução na frequência de crises (50% ou mais), com uma RC geral de 2,71 (IC95%: 1,87-3,91)<sup>104</sup> .  
A efetividade da lamotrigina como tratamento de adição de crises TCG refratárias foi avaliada em revisão sistemática da Cochrane, tendo sido identificados apenas dois estudos de curto prazo mostrando algum benefício. Os autores concluem que as evidências são insuficientes para resultar em recomendação, sendo necessários mais estudos de longo prazo<sup>105</sup> .  
Há estudos demonstrando que a lamotrigina é mais bem tolerada do que a carbamazepina em idosos<sup>106</sup> .  
Uma atualização dos parâmetros práticos recomendados pela ILAE no tratamento da epilepsia em mulheres, com foco na gestação, realizou uma revisão sistemática de artigos publicados entre 1985 e 2007. Conclui-se que é altamente provável que a exposição intrauterina a ácido valproico, no primeiro trimestre da gestação, tenha maior risco para malformações congênitas importantes em relação à carbamazepina, e possivelmente em comparação com a fenitoína e com a lamotrigina. No entanto, convém lembrar que o uso de anticoncepcionais orais diminui a concentração plasmática de lamotrigina, além do que, durante a gestação, o metabolismo deste fármaco encontra-se aumentado<sup>107</sup> . Recente estudo demonstrou que, com uma rigorosa monitorização do paciente, o risco de aumento da frequência de crises não foi maior do que com outros fármacos antiepilépticos<sup>108</sup> . Por conta dos menores riscos de teratogênese, e por proporcionar menor ganho de peso em relação ao ácido valproico, a lamotrigina tem sido apontada como um fármaco de escolha no tratamento da EMJ em mulheres em idade fértil<sup>109</sup> . Entretanto, nem todos os tipos de crises são tratados com a mesma eficácia pela lamotrigina, e alguns deles inclusive podem ser agravados, como determinadas crises mioclônicas<sup>110</sup> .  
Indicações:  
 Monoterapia de crises focais com ou sem generalização secundária em pacientes com mais de 12 anos de idade com intolerância ou refratariedade a FAE de primeira linha;  
- Monoterapia de crises primariamente generalizadas em pacientes com mais de 12 anos de idade com intolerância ou  
- refratariedade a FAE de primeira linha;  
- Terapia adjuvante de crises focais em pacientes mais de 2 anos de idade;  
- Terapia adjuvante de crises generalizadas da síndrome de Lennox-Gastaut em pacientes com mais de 2 anos de idade.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Vigabatrina** -->
A vigabatrina é um análogo estrutural do GABA que inibe irreversivelmente a GABA-transaminase (GABA-T), aumentando os níveis sinápticos de GABA no cérebro<sup>111,112</sup> .  
As duas maiores indicações deste fármaco são o tratamento de crises de espasmos epilépticos e de crises focais refratárias. Seu uso em adultos restringe-se a pacientes com epilepsia grave que não respondem a outros FAE, devido a seus potenciais efeitos adversos graves<sup>111</sup> . No entanto, comparada à carbamazepina, sua eficácia é inferior em pacientes com epilepsia recentemente diagnosticada<sup>113</sup> . Revisão sistemática da Cochrane comparando eficácia e segurança em relação a carbamazepina concluiu que as evidências são insuficientes para recomendar a vigabatrina como primeira escolha<sup>111,114</sup> . Ela também agrava  
17  
mioclonias<sup>115</sup> . Em crianças, no entanto, a vigabatrina é altamente efetiva na síndrome de West, especialmente quando associada a esclerose tuberosa<sup>116</sup> .  
Numa revisão sistemática, incluindo 747 pacientes em uso adjuvante de vigabatrina para tratamento de epilepsias focais, em 11 ECR, Hemming e colaboradores<sup>115</sup> concluíram que a vigabatrina é 2,5 vezes mais eficaz do que placebo. Também os pacientes tratados com vigabatrina apresentaram 2,5 vezes mais efeitos adversos quando comparados a placebo (principalmente fadiga e sonolência). A eficácia da vigabatrina é maior nas crises focais sem generalização secundária, tanto como terapia adjuvante quanto em monoterapia<sup>116</sup> .  
A vigabatrina é eficaz para tratamento da síndrome de West (espasmos epilépticos, EEG com hipsarritmia e retardo do desenvolvimento neuropsicomotor). Apesar de haver poucos estudos metodologicamente aceitáveis e, até o momento, poucos pacientes selecionados, Hancock e colaboradores<sup>117</sup> concluíram, numa revisão sistemática, que a vigabatrina deve ser considerada o fármaco de primeira escolha em espasmos epilépticos associados à esclerose tuberosa.  
A vigabatrina piora crises generalizadas primárias, provoca aumento de ausências e pode desencadear crises mioclônicas. É contraindicada para epilepsias mioclônicas e para crises TCG primárias<sup>115</sup> . Os principais efeitos adversos são irritabilidade, insônia e distúrbios psiquiátricos<sup>118</sup> . Efeitos sobre os campos visuais (retração concêntrica) foram confirmados em muitos estudos, sendo encontrados em até 40% dos pacientes tratados<sup>111</sup> . Eles são progressivos nos pacientes que continuam usando o fármaco e dependem de dose cumulativa, sendo reversíveis apenas quando suspensa precocemente. Estes efeitos são provavelmente resultantes da toxicidade da vigabatrina sobre os cones da retina periférica e devem ser ativamente buscados por meio de estudos de eletrorretinografia e potenciais evocados visuais, uma vez que a maioria dos pacientes é assintomática<sup>119,120</sup> .  
Em recente meta-análise, com 11 estudos selecionados e 747 participantes, a vigabatrina mostrou-se eficaz como adjuvante para tratamento de crises refratárias, comparado ao placebo, em doses entre 1.000 e 6.000 mg/dia (OR: 2,58). No entanto, o OR para retirada do estudo também foi elevado, sendo os principais efeitos adversos observados cansaço e confusão mental<sup>121</sup> .  
Há relatos de piora das frequências e intensidades das crises, bem como de maior ocorrência de eventos adversos, em pacientes com síndrome de Angelman que utilizam vigabatrina<sup>59–62,122</sup> .  
Indicações:  
- Monoterapia de espasmos epilépticos, particularmente nos casos de Esclerose Tuberosa;  
- Terapia adjuvante de crises focais com ou sem generalização secundária em pacientes de qualquer idade.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Precursores do íon valproato (ácido valproico, valproato de sódio)** -->
O valproato é o íon circulante no sangue responsável pelo efeito antiepiléptico das diferentes formulações farmacêuticas. Foi inicialmente comercializado sob a forma ácida e depois na de sal (de sódio ou de magnésio) e de amido. Todas essas formulações são equivalentes com relação à eficácia e segurança. Mais recentemente, foi desenvolvida a molécula de divalproato de sódio. Inexiste na literatura ECR que tenha demonstrado superioridade em eficácia antiepiléptica entre as diferentes formulações, e o divalproato não está incluído neste Protocolo.  
O ácido valproico é um dos principais antiepilépticos utilizados, com eficácia estabelecida para múltiplos tipos de crises. Picos máximos de concentração são atingidos 2 horas após a ingestão oral. É altamente ligado às proteínas (90%), e a meia-vida de eliminação é de cerca de 15 horas.  
Seu mecanismo de ação pode envolver redução na frequência de disparos dos canais de sódio, ativação da condutância do potássio e, possivelmente, ação direta sobre outros canais iônicos. É sabido que o ácido valproico tem um efeito GABAérgico por meio da elevação do GABA cerebral por diversos mecanismos: inibição da GABA-transaminase, aumento das enzimas sintetizadoras do GABA, aumento da liberação e inibição da recaptação do GABA.  
Suas principais desvantagens são maior incidência de efeitos adversos em mulheres (alterações hormonais, ganho de peso), na gestação (teratogenicidade) e em crianças com menos de 2 anos de idade, especialmente naquelas em politerapia, com  
18  
doenças metabólicas congênitas ou com retardo mental (devido a risco aumentado de desenvolvimento de hepatotoxicidade fatal). O uso de ácido valproico para casos de crises focais apresenta eficácia limitada, devido principalmente à necessidade de doses significativamente maiores do que as usadas para crises generalizadas.  
Revisão sistemática, incluindo cinco ensaios randomizados e o total de 1.265 pacientes, não encontrou evidências para apoiar o uso de carbamazepina em crises focais nem de ácido valproico em crises generalizadas<sup>123</sup> . No entanto, os intervalos de confiança obtidos foram muito amplos para confirmar equivalência entre os dois fármacos nos diferentes tipos de crises epilépticas. Assim, na ausência de evidência definitiva, continuam a ser adotados critérios tradicionais de tratamento.  
Indicação:  
- Monoterapia e terapia adjuvante de pacientes com mais de 10 anos de idade e com qualquer forma de epilepsia.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Primidona** -->
A primidona, com base em sua estrutura química, não pode ser considerada um barbitúrico; no entanto, parte do seu efeito  
clínico pode ser atribuído à biotransformação hepática de suas moléculas em fenobarbital.  
Um grande estudo multicêntrico controlado comparou 622 pacientes com epilepsia focal, não encontrando qualquer vantagem na eficácia de primidona sobre o fenobarbital, fenitoína e carbamazepina<sup>44</sup> . Além de controlar crises focais em um menor número de pacientes, houve grande exclusão de pacientes que faziam uso de primidona devido a seus efeitos sedativos. Dessa forma, a primidona tem indicação específica neste Protocolo.  
Indicação:  
- Tratamento de crises focais e generalizadas em pacientes refratários ou intolerantes aos fármacos de primeira linha.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Tratamento dos espasmos infantis** -->
As recomendações atuais para tratamento de espasmos epilépticos são<sup>119</sup> :  
- 1 Se espasmos são suspeitados, um EEG deve ser realizado dentro de poucos dias;  
- 2 Se espasmos são diagnosticados, tratamento deve ser iniciado imediatamente;  
- 3 A resposta ao tratamento de primeira linha deve ser avaliada clinicamente e com EEG em vigília e sono, após 14 dias;  
- 4 Corticosteroide ou vigabatrina devem ser os fármacos de primeira linha utilizados para tratamento de espasmos  
epilépticos;  
- 5 Em crianças portadoras do complexo Esclerose Tuberosa, a vigabatrina deve ser o fármaco de primeira escolha;  
- 6 Topiramato, ácido valproico e benzodiazepínicos podem ser utilizados, quando os fármacos de primeira linha forem  
- ineficazes. Dieta cetogênica também deve ser considerada;  
- 7 Crianças refratárias à farmacoterapia devem ser avaliadas para possível tratamento cirúrgico, especialmente se uma  
- lesão focal estiver presente.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Lacosamida** -->
A lacosamida é um aminoácido funcionalizado com um novo mecanismo de ação, desenvolvido como um fármaco antiepiléptico para uso oral e EV, e está disponível também como xarope oral (15 mg/mL) na Europa. O principal mecanismo de ação da lacosamida é um aumento seletivo da inativação lenta dos canais de sódio dependentes de voltagem, sem afetar a inativação rápida, o que pode normalizar os limiares de disparo neuronal<sup>124</sup> .  
Três estudos pivotais (um estudo de fase II e dois de fase III) foram conduzidos para estabelecer a eficácia e segurança da lacosamida<sup>125–127</sup> . No estudo de fase II, tanto as taxas de resposta de 50% (proporção de pacientes que experimentaram uma redução de crises maior que 50%) quanto a percentagem de redução na frequência de crises por 28 dias da dose diária de 400 mg em relação ao placebo foram significativas<sup>58</sup> .  
Em um ensaio de fase III a redução média no percentual de frequência de crises foi significativa nas doses de 200 mg/dia<sup>126</sup> . Nas doses de 400 e 600 mg/dia observou-se a redução média no percentual de frequência de crises além da redução  
19  
de taxas de resposta 50% significativas em relação ao placebo<sup>126,127</sup> . Os efeitos adversos mais comuns foram tontura, cefaleia, náusea e diplopia, todos relacionados à dose<sup>127</sup> .  
A análise deste medicamento pela CONITEC incluiu duas relevantes revisões sistemáticas sobre o tratamento da epilepsia em pacientes refratários. A revisão de Bodalia et al. (2013) realizou uma meta-análise em rede com o objetivo de comparar a eficácia e segurança dos medicamentos como adjuvantes no tratamento da epilepsia focal<sup>128</sup> . A meta-análise convencional com modelo de efeitos aleatórios, realizada para avaliar a eficácia e segurança dos estudos controlados por placebo, demonstrou a superioridade dos fármacos antiepilépticos (FAE) em relação ao placebo na redução das crises em pelo menos 50%, identificando que não havia evidências fortes de eficácia e segurança que favorecessem qualquer um dos FAE avaliados. A meta-análise em rede utilizando método Bayesiano de efeitos randômicos foi realizada para a avaliação da eficácia e a segurança entre os FA, permitindo estabelecer a classificação dos FAE de acordo com a eficácia e segurança. A lacosamida apresentou eficácia inferior ao levetiracetam e não apresentou diferença estatística quando comparada aos demais medicamentos.  
A Revisão sistemática de Costa et al. (2011) comparou um FAE em terapia adjuvante com placebo ou outro FAE, analisados por meio de meta-análise convencional com modelo de efeitos aleatórios e comparação indireta quanto a sua eficácia e segurança<sup>129</sup> . A meta-análise convencional demonstrou que a taxa de resposta ≥ 50% foi significativamente superior para os FAE em comparação ao placebo, independente da dose. Os resultados apresentados para os medicamentos avaliados nessa análise também não apresentaram heterogeneidade significante. As taxas de abandono do tratamento com topiramato e lacosamida, observadas no estudo, foram significativamente superiores ao placebo, mas não há diferença para os demais FAE analisados. Os autores dessa revisão sistemática relataram que não era possível estabelecer uma conclusão definitiva sobre a superioridade de qualquer um dos FAE em relação a outro. Discutiram sobre as limitações das comparações indiretas e sobre homogeneidade, similaridade e consistência dos estudos incluídos na análise.  
Inexistem estudos de comparação direta entre a lacosamida e outro antiepiléptico para o tratamento da epilepsia focal. Os resultados obtidos com as comparações indiretas sugerem similaridade de eficácia e segurança entre todos os FAE, avaliados para o tratamento aditivo de pacientes com epilepsia focal, refratários a monoterapia, não sendo possível estabelecer superioridade entre eles. A análise das evidências disponíveis e a avaliação econômica conduziram a deliberação da CONITEC, com posterior publicação da Portaria nº 20/SCTIE/MS, de 27 de abril de 2018, que aprovou a não incorporação da lacosamida no SUS<sup>130</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Oxcarbazepina** -->
A oxcarbazepina é um derivado da carbamazepina, contendo um átomo de oxigênio adicional no anel de dibenzazepina. A oxcarbazepina foi desenvolvida em um esforço para introduzir um novo fármaco antiepiléptico com eficácia similar à carbamazepina, mas sem os seus efeitos adversos indesejados<sup>131</sup> . Foi usado pela primeira vez para tratar neuralgia do trigêmeo em 1989<sup>132</sup> . Foi introduzido pela primeira vez na Dinamarca em 1990, e agora está registrado em 54 países em todo o mundo como monoterapia e terapia adjuvante para crises focais.  
Em um estudo multicêntrico, randomizado, controlado por placebo, a oxcarbazepina mostrou-se segura, eficaz e bem tolerada como terapia adjuvante em uma dose de 6-51 mg/k/dia em crianças com crises focais<sup>133</sup> . A oxcarbazepina é estabelecida como eficaz ou efetiva como monoterapia inicial para crianças com epilepsias focais recém diagnosticadas ou não tratadas. No único estudo de classe I nesta categoria, a oxcarbazepina demonstrou eficácia superior (em comparação com a fenitoína) e eficácia igual<sup>134</sup> . Em uma revisão de 2004, os subcomitês da Academia Americana de Neurologia e da _American Epilepsy Society_ concluíram que a oxcarbazepina é uma monoterapia efetiva em adolescentes recém diagnosticados e adultos com crises focais ou mistas e em adultos e crianças com crises focais refratárias<sup>82,135</sup> . Não é recomendada para crises generalizadas primárias ou sintomáticas.  
20  
O risco de hiponatremia é significativamente maior em pacientes tratados com oxcarbazepina (29,9%) do que em aqueles tratados com carbamazepina (13,5%). As reações adversas mais comuns são: em crianças - vômitos (33%), dor de cabeça (31%), sonolência (31%), tontura (28%); em adultos - tontura (22%), náusea (16%) e dor de cabeça (13%)<sup>136</sup> .  
Em recente meta-análise, que avaliou dois ensaios clínicos randomizados, com 961 participantes, entre adultos e crianças, a oxcarbazepina como terapia adjuvante em epilepsias focais foi 2 a 3 vezes superior ao placebo, tanto na redução da frequência de crises em mais de 50%, como no índice de pacientes que apresentou remissão de crises<sup>58</sup> . No entanto, deve-se lembrar que esses resultados não podem ser extrapolados para o uso da oxcarbazepina em monoterapia.  
Este medicamento não está indicado neste Protocolo, visto não possuir vantagens terapêuticas em relação aos demais agentes constantes no elenco de medicamentos disponíveis. O único estudo com evidência classe I no tratamento de crises focais em crianças, o fármaco foi comparado à fenitoína<sup>134</sup> . A literatura carece de estudos comparativos entre a oxcarbazepina e a carbamazepina, que é considerada fármaco de primeira escolha para tratamento desse nicho de pacientes.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **7.2. Tratamentos Não Medicamentosos** -->
Mesmo utilizando fármacos adequados para o tipo específico de crise, um controle insatisfatório ocorre em cerca de 15% dos pacientes com epilepsia focal<sup>36</sup> , sendo estes candidatos a tratamento cirúrgico da epilepsia, ou ainda, num segundo momento, se indicado, a tratamento de estimulação do nervo vago.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Tratamento cirúrgico** -->
As indicações de cirurgia da epilepsia são respaldadas por dois ensaios clínicos randomizados seminais<sup>137</sup> . A cirurgia é considerada em pacientes com crises epilépticas focais resistentes aos medicamentos, descontroladas e incapacitantes, e se as crises são originárias de uma região que pode ser removida com um risco inexistente ou mínimo de causar alguma disfunção neurológica ou cognitiva<sup>138</sup> .  
Existem situações específicas, nas quais claramente o prognóstico do tratamento cirúrgico é mais favorável que o prognóstico do tratamento medicamentoso, e que merecem, no mínimo, uma avaliação pré-cirúrgica em centros especializados. São elas: epilepsia do lobo temporal com esclerose hipocampal, hamartoma hipotalâmico, tumores glioneurais, displasias corticais focais, angioma cavernoso. Algumas doenças podem ser tratadas cirurgicamente, dependendo do resultado da avaliação pré-cirúrgica: esclerose tuberosa, síndrome de Sturge-Weber, lesões isquêmicas congênitas unilaterais, hemimegalencefalia e síndrome de Rasmussen<sup>139</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Estimulação do nervo vago (ENV)** -->
Trata-se de uma técnica que estimula diretamente o nervo, incluindo estimulação manual ou elétrica, aplicada de forma invasiva ou não. A forma de ENV mais bem avaliada cientificamente e com maior experiência clínica envolve a implantação de eletrodos helicoidais na região cervical esquerda, os quais disparam estímulos intermitentes oriundos de um gerador implantado na parede anterior do tórax<sup>140</sup> .  
Em 1994, a técnica foi aprovada pela Agência Europeia para uso clínico em pacientes com epilepsia, e em 1997 recebeu aprovação do FDA para a mesma indicação. A ENV é contraindicada em pacientes previamente submetidos a vagotomia cervical esquerda ou bilateral; outras contraindicações são apneia do sono e distúrbios do ritmo cardíaco<sup>141,142</sup> .  
O mecanismo exato pelo qual a estimulação vagal produz efeito antiepiléptico não é bem conhecido, mas acredita-se que seja pela ativação do sistema reticular. A estimulação do vago ativa fibras que se projetam ao núcleo do trato solitário, núcleo sensitivo que se conecta ao córtex e a outras estruturas do tronco cerebral, possivelmente modulando estímulos excitatórios sobre o sistema nervoso simpático<sup>143</sup> .  
A ENV em sua porção cervical esquerda por meio de eletrodo implantável é uma terapia aprovada pelo FDA para epilepsia refratária de início focal em indivíduos acima de 12 anos. No Brasil a ENV foi aprovada pela ANVISA em 2000 para tratamento de pacientes com diagnóstico há mais de dois anos de epilepsia refratária, focal ou generalizada<sup>144</sup> .  
21  
Cirurgias de remoção de foco epileptogênico e calosotomia são os principais tipos de procedimentos cirúrgicos, com taxas de sucesso que variam entre 40% e 70% dos casos, sendo maiores na epilepsia parcial do lobo temporal. Uma proporção significativa dos pacientes, entretanto (20% a 30%) não evoluem bem ou não são candidatos à cirurgia<sup>140,142</sup> .  
Evidências baseadas em ensaios clínicos randomizados e estudos observacionais comparativos com até um ano de acompanhamento indicam que aproximadamente 40% dos pacientes podem alcançar redução em 50% nas crises em até 1 ano. Essa taxa sobe para 42% nos estudos comparativos de médio prazo e para 59% nos estudos não comparativos com acompanhamento superior a 2 anos (registros de pacientes). Nesses estudos, as amostras estudadas tinham em média 1,6 crise por dia ou 584 crises por ano, sem alcançar melhora na redução de crises epilépticas, com tratamento medicamentoso. Com a utilização da eletroestimulação do nervo vago, esses pacientes tiveram reduzidas suas crises epilépticas de 584 para 292 crises por ano, as evidências de meta-análise dos estudos de mundo real revelam que a ENV está associada à liberdade de crises em 4,8% a 11,8% dos pacientes pediátricos<sup>140,143</sup> .

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Dieta cetogênica** -->
Criada em 1921 na Mayo Clinic em Rochester, Minnesota por Wilder<sup>145</sup> para crianças com epilepsia refratária, a dieta cetogênica (DC) é rica em gorduras, adequada em proteínas e pobre em carboidratos, foi desenvolvida para mimetizar no nosso organismo os efeitos bioquímicos do jejum, mantendo um estado de anabolismo<sup>146</sup> . A DC pode oferecer em alguns casos resultados muito satisfatórios, sendo que em torno de 10% dos pacientes podem ficar livres de crises, e cerca de 40% dos pacientes têm redução delas em 50%.  
Desde o início dos anos 1990, foi observado um aumento dramático em artigos científicos sobre DC, e atualmente a DC é bem estabelecida e comprovadamente eficaz para a epilepsia. A DC é atualmente utilizada em mais de 45 países, e novas modalidades de DC estão disponíveis como a dieta modificada de Atkins (DMA), a dieta de baixos índices glicêmicos (DBIG), além de novas fórmulas cetogênicas facilitando a introdução e manutenção da DC<sup>147</sup> . Em 2009 foi publicado na revista Epilepsia, pelo Dr. Kossoff e outros médicos e nutricionistas especialistas na dieta cetogênica em todo o mundo, o primeiro consenso internacional para implementação da dieta cetogênica<sup>148</sup> .  
Após 3 meses de tratamento, a eficácia da dieta cetogênica clássica 4:1 em reduzir as crises pode chegar a percentual tão elevado quanto 85%<sup>146</sup> . Um dos principais objetivos da DC, além do controle das crises, é a redução das doses dos fármacos antiepilépticos<sup>148</sup> . Tanto o menor número e intensidade das crises epilépticas, quanto a redução dos efeitos colaterais dos fármacos podem resultar na melhora do desenvolvimento neuropsicomotor.  
Os mecanismos de ação da DC ainda não estão completamente esclarecidos. Os estudos, na maioria experimentais em modelos animais _in vivo_ e modelos _in vitro_ , apontam para prováveis mecanismos complexos no controle das crises epilépticas, efeito neuroprotetor além de diversas alterações metabólicas ocasionadas pela DC<sup>149</sup> .  
A dieta cetogênica clássica (DCC) é a mais utilizada para epilepsia resistente a medicamentos, principalmente em lactentes, pré-escolares e nos casos de encefalopatias epilépticas<sup>148,150</sup> . É uma dieta com alto teor de gordura (90% do valor calórico total da dieta), composta principalmente por triglicérides de cadeia longa (TCL), baixo teor de carboidrato e teor adequado de proteínas, sendo o mínimo de 1 g/kg/dia. É estritamente individualizada, minimamente calculada, baseada nas necessidades energéticas de cada indivíduo. Ela é realizada na proporção 3:1 (3 g de gordura para 1 g de carboidrato e proteína) e 4:1 (4 g de gordura para 1 g de carboidrato e proteína). Esta proporção pode ser modificada de acordo com a resposta clínica e a cetose do indivíduo. A DCC é a que promove os mais altos níveis de cetose<sup>151</sup> . Em crianças que recebem a dieta por gastrostomia ou via sonda nasogástrica, como no estado de mal epiléptico, a melhor indicação é a DCC, na proporção 3:1 ou 4:1.  
A dieta com triglicerídes de cadeia média (DTCM) é uma opção mais palatável e possibilita a ingestão de maior quantidade de carboidratos, já que utiliza óleo rico em triglicérides de cadeia média (TCM)<sup>152,153</sup> que são mais bem absorvidos que os triglicérides de cadeia longa (TCL)<sup>150</sup> , sendo mais cetogênicos que os TCL. A menor quantidade de gordura necessária na DTCM permite um aumento da quantidade de proteínas e carboidratos.  
22  
A dieta modificada de Atkins (DMA) foi desenvolvida em 2003, no Hospital Johns Hopkins em Baltimore, EUA<sup>154</sup> , é uma dieta com quantidade livre de calorias, gordura e proteína, porém com restrição da quantidade de carboidratos, que pode ser aumentada progressivamente, de acordo com o controle das crises e a tolerabilidade. Cerca de 60% do valor calórico total são obtidos a partir da gordura. A DMA pode ser introduzida de forma mais rápida que a DCC, e permite uma maior flexibilidade e independência do indivíduo, pois os alimentos podem ser encontrados facilmente em restaurantes, cafeterias e lanchonetes da escola.  
A dieta de baixo índice glicêmico (DBIG) foi desenvolvida em 2002 no Hospital Geral de Massachusetts, em Boston, EUA, com o objetivo de manter os níveis de glicemia estáveis e mais baixos, por meio do consumo somente de carboidratos com índice glicêmico (IG) menor ou igual a 50<sup>150,155</sup> . Permite a ingestão de 40 a 60 g de carboidrato ao dia e incentiva o consumo de gordura, na média de 60% do valor calórico total. Também permite o consumo de alimentos por todos da família e também em restaurantes<sup>150</sup> .  
A DC está indicada para pacientes desde a infância até a fase adulta com epilepsia refratária<sup>118,148,150,156</sup> . A DC também é altamente eficaz e bem tolerada em crianças abaixo de 2 anos com epilepsia<sup>157</sup> . As condições que melhor respondem ao tratamento com a DC são<sup>158</sup> :  
- Síndrome da Deficiência da GLUT-1;  
- Deficiência da piruvato-desidrogenase;  
- Epilepsia mioclônico – atônica (Síndrome de Doose);  
- Espasmos epilépticos (Síndrome de West);  
- Síndrome de Lennox – Gastaut;  
- Síndrome de Dravet;  
- Complexo Esclerose tuberosa;  
- Síndrome de Rett;  
- Doenças mitocondriais;  
- “FIRES” - Estado de mal epiléptico induzido por febre;  
- Crianças e adultos que se alimentam somente de fórmulas (lactentes ou pacientes em alimentação enteral).  
A DC é considerada como primeira linha de tratamento, independentemente da quantidade de crises epilépticas, na síndrome da deficiência do transportador de GLUT-1 e na deficiência complexo piruvato-desidrogenase<sup>148</sup> . No consenso de DC publicado em 2009, algumas síndromes epilépticas como síndrome de Doose, síndrome de Dravet, espasmos infantis e complexo esclerose tuberosa, a DC pode ser indicada precocemente, após ausência de resposta aos fármacos de primeira linha<sup>148</sup> .  
Alguns estudos recentes têm sido publicados sobre o uso da DC no estado de mal epiléptico tanto em crianças como adultos com resultados favoráveis<sup>159</sup> . Estudos preliminares também encontraram efeitos benéficos da DC nas epilepsias sintomáticas da Doença de Lafora, Síndrome de Rett, Síndrome de Landau-Kleffner, ponta-onda contínua durante o sono, panencefalite esclerosante subaguda, deficiência da fosfofrutoquinase, glicogenose tipo V e desordens da cadeia respiratória mitocondrial<sup>160</sup> .  
Existem condições neurológicas em que a DC não pode ser procedida.  
As contraindicações absolutas são<sup>148</sup> :  
- Deficiência primária da carnitina;  
- Deficiência da carnitina palmitoiltransferase (CPT) tipo I ou II;  
- Deficiência da carnitina translocase;  
- Defeitos da beta-oxidação:  
- Deficiência da acildesidrogenasae de cadeia média (MCAD);  
23  
- Deficiência da acildesidrogenasae de cadeia longa (LCAD);  
- Deficiência da acildesidrogenase de cadeia curta (SCAD);  
- Deficiência da 3-hidroxiacil-CoA de cadeia longa;  
- Deficiência da 3-hidroxiacil-CoA de cadeia média;  
- Deficiência de piruvato carboxilase;  
- Porfiria.  
As contraindicações relativas são:  
- Inabilidade de manter nutrição adequada;  
- Possibilidade de cirurgia identificada por vídeo-EEG ou neuroimagem (a DC pode ser realizada para controle das  
- crises enquanto o paciente aguarda o agendamento do procedimento cirúrgico);  
- Inaceitação da DC pelos pais ou cuidadores.  
A DCC e DTCM podem ser iniciadas de forma ambulatorial (introduzindo a DC em domicílio) ou durante internação hospitalar; com ingestão dos alimentos cetogênicos desde o início, ou mantendo o paciente por um período de jejum, para indução do estado de cetose em menor tempo<sup>161</sup> . A cetose é um parâmetro relevante que deve ser acompanhado rigorosamente nos primeiros meses de DC. No decorrer do tratamento, pode-se medir a cetose de forma menos frequente.  
Na fase inicial do tratamento, na maioria das vezes os efeitos adversos são leves e de fácil tratamento: hipoglicemia, desidratação, acidose metabólica, alterações gastrointestinais, letargia e recusa alimentar.  
Os principais efeitos adversos observados após os três meses iniciais do tratamento são: hiperlipidemia, alterações gastrointestinais, cálculo renal, deficiência de crescimento, alterações ósseas, alterações cardíacas e deficiência de vitaminas e minerais. De uma forma geral, o risco de efeitos adversos graves é baixo, e não há necessidade de suspender a DC por esse motivo na maior parte dos pacientes<sup>148</sup> .  
A DC deve ser mantida por 3,5 meses para avaliação de sua eficácia<sup>148</sup> . Os pacientes que apresentam redução de mais de 50% das crises epilépticas têm indicação de permanecer no tratamento por um período de 2 a 3 anos<sup>162</sup> . Se se obteve um controle de > 90% das crises epilépticas, os efeitos adversos forem insignificantes e a possibilidade de recorrência de crises epilépticas for grande, como na esclerose tuberosa e na síndrome de Dravet, a DC deve ser mantida por períodos de 6 a 12 anos<sup>163</sup> . Recomenda-se que a retirada da DC seja gradual, ao longo de 2 a 3 meses<sup>148</sup> .  
Nos pacientes com a deficiência do transportador de glicose GLUT-1 e com deficiência de piruvato desidrogenase, a DC pode ser mantida por toda a vida. Nesses pacientes, é importante avaliar ao longo do tempo a possibilidade de redução da proporção da DC para 3:1, 2:1, 1:1, ou transição para DMA.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **7.3 Fármacos e Esquemas de Administração** -->
**Ácido valproico (valproato de sódio):** comprimidos ou cápsulas de 250 mg, comprimidos de 500 mg e solução e xarope  
de 50 mg/mL.  
Dose inicial: 250 mg/dia.  
Escalonamento: 250 mg/dia a cada 3 dias.  
Dose máxima: 3.000 mg/dia.  
Intervalo de dose: 2 administrações/dia.  
Intolerância gástrica significativa (menor com o uso de valproato de sódio). Tomar após alimentação  
**Carbamazepina:** comprimidos de 200 e 400 mg, suspensão oral de 20 mg/mL.  
Dose inicial:  
- Adultos: 200 mg/dia.  
- Crianças de 6 a 12 anos: 100 mg/dia.  
24  
- Crianças abaixo de 6 anos: 5-10 mg/kg/dia.  
- Escalonamento:  
- Adultos: 200 mg/dia/semana.  
- Crianças de 6 a 12 anos: 100 mg/dia/semana.  
- Crianças com menos de 6 anos: 5-10 mg/kg/dia/semana.  
- Dose máxima:  
- Adultos: 1.800 mg/dia.  
- Crianças de 6 a 12 anos: 600-1.000 mg/dia.  
- Crianças com menos de 6 anos: 35 mg/kg/dia.  
Intervalo de dose: se não for a formulação de liberação lenta, tem de ser utilizada 3 a 4 vezes ao dia, após alimentação. **Clobazam:** comprimidos de 10 e 20 mg  
Dose inicial: 5-10 mg/dia. Escalonamento: 5 mg/dia/semana. Dose máxima: 40 mg/dia. Intervalo de dose: 1 a 2x/dia  
**Clonazepam:** solução oral (2,5 mg/mL). Dose inicial: 0,25 mg/dia (crianças de 2 a 12 anos: 0,01 mg/kg/dia). Escalonamento: 0,25 mg/dia/semana (crianças: 0,1-0,2 mg/kg/dia/semana). Dose máxima: 10 mg/dia. Intervalo de dose: 1-2 administrações/dia. **Etossuximida:** xarope de 50 mg/mL. Dose inicial: 250 mg/dia. Escalonamento: 250 mg/dia/semana. Dose máxima: 1.500 mg/dia. Intervalo de dose: 2-3 administrações/dia. **Fenitoína:** comprimidos de 100 mg, suspensão oral 20 mg/mL. Dose inicial: 100 mg/dia. Escalonamento: 100 mg/dia/semana. Dose máxima: 500 mg/dia. Intervalo de dose: 1-2 administrações/dia. **Fenobarbital:** comprimidos de 100 mg e solução oral 40 mg/mL. Dose inicial: 50 mg/dia. Escalonamento: 50 mg/dia/semana. Dose máxima: 300 mg/dia. Intervalo de dose: dose única diária. **Gabapentina:** cápsulas de 300 e 400 mg. Dose inicial: 15 mg/kg/dia ou máximo de 300 mg/dia. Escalonamento: 300 mg/dia (15 mg/kg/dia). Dose máxima: 3.600 mg/dia (50-100 mg/kg/dia). Intervalo de dose: 3 administrações/dia. **Lamotrigina:** comprimidos 25, 50 e 100 mg.  
 Monoterapia:  
25  
Dose inicial: 25 mg/dia por 2 semanas; 50 mg/dia por mais 2 semanas. Escalonamento: 50-100 mg a cada 1-2 semanas. Dose máxima: 500 mg/dia (1-5 mg/kg/dia).  
Intervalo de dose: 2 a 3 tomadas reduzem efeitos adversos de pico de dose.  
- Terapia adjuvante com ácido valproico:  
Dose inicial: 25 mg a cada 2 dias por 2 semanas (0,15 mg/kg/dia); 25 mg/dia por mais 2 semanas (0,3 mg/kg/dia). Escalonamento: 25-50 mg a cada 1-2 semanas (0,3 mg/kg). Dose máxima: 500 mg/dia (1-5 mg/kg/dia).  
Intervalo de dose: 2 a 3 tomadas reduzem efeitos adversos de pico de dose.  
- Terapia adjuvante com fármacos antiepilépticos indutores enzimáticos:  
Dose inicial: 50 mg/dia por 2 semanas (0,6 mg/kg/dia); 100 mg/dia por mais 2 semanas (1,2 mg/kg/dia). Escalonamento: 100 mg a cada 1-2 semanas (1,2 mg/kg).  
Dose máxima: 700 mg/dia (5-15 mg/dia).  
Intervalo de dose: 2 a 3 tomadas reduzem efeitos adversos de pico de dose.  
**Levetiracetam:** comprimidos de 250, 500, 750 e 1.000 mg; solução oral 100 mg/mL.  
- Terapia adjuvante no tratamento de crises focais/parciais com ou sem generalização secundária em bebês a partir de  
- 1 mês de idade, crianças, adolescentes e adultos, com epilepsia:  
<u>Bebês com mais de 1 mês e menos de 6 meses de idade</u>  
Dose inicial: 14 mg/kg/dia  
Escalonamento: 14 mg/kg/dia a cada 2 semanas Dose máxima: 42 mg/kg/dia  
Intervalo de dose: 2 administrações/dia  
<u>Bebês dos 6 aos 23 meses, crianças (dos 2 aos 11 anos) e adolescentes (dos 12 aos 17 anos) com peso inferior a 50 kg</u> Dose inicial: 20 mg/kg/dia  
Escalonamento: 20 mg/kg/dia a cada duas semanas. Dose máxima: 60 mg/kg/dia  
Intervalo de dose: 2 administrações/dia.  
<u>Adolescentes (dos 12 aos 17 anos) com peso igual ou superior a 50 kg e adultos (≥ 18 anos)</u> Dose inicial: 1.000 mg/dia  
Escalonamento: 1.000 mg/dia, a cada duas a quatro semanas Dose máxima: 3.000 mg/dia  
Intervalo de dose: 2 administrações/dia  
- Terapia adjuvante de crises tônico-clônicas primárias generalizadas em crianças com mais de 6 anos de idade,  
- adolescentes e adultos, com epilepsia idiopática generalizada:  
<u>Crianças (dos 6 aos 11 anos) e adolescentes (dos 12 aos 17 anos) com peso inferior a 50 kg</u> Dose inicial: 20 mg/kg/dia Escalonamento: 20 mg/kg/dia a cada duas semanas Dose máxima: 60 mg/kg/dia Intervalo de dose: 2 administrações/dia  
<u>Crianças (dos 6 aos 11 anos), adolescentes (dos 12 aos 17 anos) com peso igual ou superior a 50 kg e adultos (≥ 18 anos)</u> Dose inicial: 1.000 mg/dia  
Escalonamento: 1.000 mg/dia, a cada duas a quatro semanas  
26  
Dose máxima: 3.000 mg/dia Intervalo de dose: 2 administrações/dia  
 Terapia adjuvante de crises mioclônicas em adolescentes (>12 anos) e adultos, com epilepsia mioclônica juvenil: <u>Adolescentes (dos 12 aos 17 anos) com peso inferior a 50 kg</u> Dose inicial: 20 mg/kg/dia Escalonamento: 20 mg/kg/dia a cada duas semanas Dose máxima: 60 mg/kg/dia Intervalo de dose: 2 administrações/dia <u>Adolescentes (dos 12 aos 17 anos) com peso igual ou superior a 50 kg e adultos (≥ 18 anos)</u> Dose inicial: 1.000 mg/dia Escalonamento: 1.000 mg/dia, a cada duas a quatro semanas Dose máxima: 3.000 mg/dia Intervalo de dose: 2 administrações/dia **Primidona:** comprimidos de 100 e 250 mg. Dose inicial: 100 mg/dia. Escalonamento: 100 mg/dia/semana. Dose máxima: 750 mg/dia. Intervalo de dose: 3 administrações/dia. **Topiramato:** comprimidos 25, 50 e 100 mg.  Terapia adjuvante em epilepsia: -Adultos: Dose inicial: 25-50 mg/dia. Escalonamento: 25-50 mg/semana ou a cada 14 dias. Dose máxima: 400 mg/dia. Intervalo de dose: 2 administrações/dia. -Crianças acima de 2 anos: Dose inicial: 1-3 mg/kg/dia. Escalonamento: 1-3 mg/kg/semana. Dose máxima: 5-9 mg/kg/dia ou até 400 mg/dia. Intervalo de dose: 2 administrações/dia.  Monoterapia em epilepsia: -Adultos: Dose inicial: 25 mg/dia. Escalonamento: 25-50 mg/semana ou a cada 14 dias. Dose máxima: 400 mg/dia. Intervalo de dose: 2 administrações/dia. -Crianças a partir de 10 anos: Dose inicial: 0,5-1 mg/kg/dia. Escalonamento: 0,5-1 mg/kg/semana ou a cada 14 dias. Dose máxima: 9 mg/kg/dia ou até 400 mg/dia. Intervalo de dose: 2 administrações/dia.  
27  
Nota: Em pacientes com insuficiência renal recomenda-se utilizar a metade da dose.  
**Vigabatrina:** comprimidos de 500 mg.  
Dose inicial: 500 mg/dia.  
Escalonamento: 500 mg/semana.  
Dose máxima: 3.000 mg/dia (150-200 mg/kg/dia) Intervalo de dose: 1 a 2 administrações/dia  
As doses máximas indicadas podem variar, pois dependem das características individuais do paciente e da interação com outros fármacos. A dosagem do nível sérico, particularmente nas suspeitas de intoxicação medicamentosa ou quando o paciente está em politerapia, pode ser útil para o ajuste de dose.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **7.4.1 Critérios para troca de fármaco (manutenção de monoterapia)** -->
Asseguradas a adesão ou nível sérico adequados (quando disponível), recomenda-se a troca de fármacos nas seguintes  
situações:  
- Intolerância à primeira monoterapia **ou**  
- Falha no controle ou exacerbação de crises.  
A troca de fármacos deve ser feita numa sequência racional, procedendo-se primeiro à introdução gradual do segundo fármaco, com dose gradativa até que as crises sejam controladas, ou que o paciente demonstre intolerância. Se ocorrer o controle de crises, o primeiro fármaco passa a ser retirado gradativamente.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **7.4.2 Critérios para o uso de associação medicamentosa** -->
Poderá ser aplicada uma associação de fármacos em caso de controle inadequado de crises com duas monoterapias sequenciais.  
Há evidências de sinergismo entre o ácido valproico e a lamotrigina, quando utilizados em combinação, no tratamento de crises focais e generalizadas. Há, também, evidências de que o uso de carbamazepina em combinação com lamotrigina pode favorecer o aparecimento de efeitos adversos neurotóxicos devido a interações farmacodinâmicas adversas.  
De forma geral, as associações devem utilizar um fármaco de espectro amplo (p.ex. ácido valproico, lamotrigina, topiramato, levetiracetam) com um de espectro restrito (p.ex. carbamazepina, fenitoína, fenobarbital). Outro aspecto a ser observado é evitar usar dois fármacos com o mesmo mecanismo de ação (p.ex: carbamazepina + fenitoína fenobarbital + ácido valproico).

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **7.5 Tempo de tratamento - Critérios de interrupção** -->
O tempo de tratamento da epilepsia, em geral, não pode ser pré-determinado. Porém, há duas situações em que ele pode ser interrompido: por falha do tratamento ou por remissão completa das crises.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Por falha de tratamento** -->
O período de avaliação da resposta será de 3 meses com o tratamento em doses máximas toleradas (com o aumento gradual da dose até o controle das crises epilépticas ou presença de efeitos adversos inaceitáveis), após o que, caso não haja resposta, um segundo fármaco será adicionado ao esquema terapêutico.  
Se o aumento gradual não produz uma redução na quantidade ou gravidade das crises epilépticas, provavelmente o paciente não terá as crises com este antiepiléptico, não sendo necessário atingir a dose máxima tolerada, e, sim, substituir por um outro antiepiléptico com um mecanismo de ação diferente.  
28  
Pacientes que permanecerem apresentando crises epilépticas apesar do uso de pelo menos dois antiepilépticos adequadamente escolhidos e utilizados em esquemas adequados de doses, tanto em monoterapia como em combinação, serão considerados refratários ao tratamento medicamentoso<sup>164</sup> . Neste momento, o paciente deverá ser avaliado para confirmação diagnóstica de epilepsia (20% a 30% dos pacientes encaminhados aos centros especializados em epilepsia não têm crises epilépticas – pseudo-refratariedade) e avaliados para eventual tratamento cirúrgico de epilepsia, ou ainda, num segundo momento, para tratamento de estimulação do nervo vago. Estima-se que 30% sejam refratários aos fármacos atuais.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **Por remissão das crises** -->
O paciente é considerado livre de crises quando elas não ocorrerem após um intervalo três vezes maior que o intervalo de crises vigente anteriormente à introdução do tratamento, ou por pelo menos 1 ano.  
Inexistem diretrizes definitivas para a interrupção do tratamento. A decisão deve ser tomada individualmente, considerando-se as consequências médicas e psicossociais da recorrência das crises e os riscos de efeitos adversos do tratamento prolongado. Nas epilepsias sintomáticas, a persistência das crises está definida pela persistência da lesão determinante. Nas epilepsias focais complexas associadas a esclerose temporal mesial, apenas 10% dos pacientes ficam livres de crises contra cerca de 60% com bons resultados cirúrgicos<sup>165</sup> .  
A presença de alteração estrutural e crises focais são provavelmente os principais fatores indutores da recidiva após a retirada do antiepiléptico (exceção é a EMJ). A presença de alentecimento da atividade de fundo (usualmente associado a lesão cortical) no EEG é o fator mais relevante na recidiva.  
Revisão sistemática, que incluiu sete ECR com 924 crianças (não houve estudo elegível com adultos), comparou os riscos de recorrência de crises epilépticas após a retirada precoce (menos de 2 anos de remissão de crises) e tardia (mais de 2 anos sem crises) dos fármacos antiepilépticos<sup>166</sup> . A retirada precoce de antiepilépticos associou-se a maiores índices de recorrência de crises em pacientes com crises focais (RR 1,52; IC (95%): 0,95-2,41) ou ao EEG anormal (RR 1,67; IC (95%): 0,93-3,00).  
Portanto, há evidências que apoiam uma espera de pelo menos 2 anos livres de crises antes da retirada do fármaco antiepiléptico em crianças, principalmente se o paciente tiver crises focais ou EEG anormal. Inexistem evidências para determinar quando suspender o tratamento em crianças e adolescentes com crises generalizadas nem em adultos livres de crises.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **8 MONITORIZAÇÃO** -->
O período de reavaliação é de 3 meses. Na reavaliação, o médico verificará a eficácia e segurança do tratamento. A resposta ao tratamento deve ser avaliada com base na redução do número de crises (diário de crises), bem como na tolerabilidade ao(s) medicamento(s), levando em consideração os efeitos adversos, especialmente os cognitivos e comportamentais. Sugere-se elaboração de um diário de crises contendo doses do fármaco em uso, descrição das crises e efeitos adversos.  
Recomenda-se a realização de exames laboratoriais numa frequência anual, realizando-se hemograma, contagem de plaquetas, avaliação das provas de função hepática (aminotrasferases/transaminases - ALT/TGP e AST/TGO), eletrólitos (sódio, potássio), perfil lipídico (colesterol total e frações, triglicerídeos), vitamina D e função tireoideana (TSH, T4 livre), com controle de eventuais alterações desses testes (com redução da dose ou troca do fármaco, reposição de carências, solicitação de avaliação por especialistas).  
A identificação de comorbidades psiquiátricas, por meio de questionários de fácil aplicação e validados para o Português (GAD-7 e NDDI-E), e suas respectivas condutas terapêuticas (conforme sessão “pacientes com doença psiquiátrica”, na sessão 6 (Casos Especiais), são fundamentais no tratamento do paciente com epilepsia.  
O objetivo do tratamento é controlar completamente as crises epilépticas, sem efeitos adversos intoleráveis, permitindo que o paciente atinja a plenitude das suas capacidades.  Para atingi-lo, vários objetivos devem ser buscados. O primeiro deles, e certamente o mais importante, é o controle completo das crises. Fármacos antiepilépticos podem produzir efeitos adversos graves,  
29  
especialmente quando utilizados em doses elevadas ou em combinação com outros fármacos. Sempre que o controle completo de crises for inalcançável, uma conduta alternativa adequada é combinar uma frequência de crises mínima desejável com efeitos adversos mantidos dentro de limites aceitáveis. Por exemplo, em pacientes com vários tipos de crise, como na síndrome de Lennox-Gastaut, é importante evitar as crises com maior impacto sobre a qualidade de vida do paciente. Assim, é muito mais importante tentar suprimir as crises de queda ( _drop attacks_ ) do que as crises focais ou de ausência atípicas que acompanham o quadro. Da mesma forma, o tratamento das crises TCG exerce maior impacto sobre a qualidade de vida do paciente do que o tratamento das crises focais simples.  
Mesmo com um tratamento medicamentoso adequado, é importante que o paciente identifique e evite situações que aumentem sua suscetibilidade a crises, como privação de sono ou abuso de bebidas alcoólicas.  
Níveis terapêuticos, medidos na corrente sanguínea, foram estabelecidos para os fármacos antiepilépticos. Embora disponíveis no SUS as dosagens de mais antiepilépticos, na maioria dos laboratórios pode-se dosar carbamazepina (níveis terapêuticos entre e 12 g/mL), fenitoína (níveis terapêuticos entre 10 e 20 g/mL), fenobarbital (níveis terapêuticos entre 10 e 30 g/mL) e ácido valproico (níveis terapêuticos entre 50 e 100 g/mL). Eles representam as faixas de concentração dentro das quais a maioria dos pacientes apresenta controle de crises sem efeitos adversos. Recomendam-se medidas da concentração sérica dos fármacos antiepilépticos, podendo ser úteis nas seguintes situações clínicas<sup>137</sup> : 1) avaliar adesão ao tratamento; 2) diagnosticar intoxicação medicamentosa; 3) estabelecer concentrações terapêuticas individuais para cada paciente; 4) orientar ajuste de doses quando houver variabilidade farmacocinética (mudança de formulação, crianças, idosos, presença de comorbidades); 5) apresentar potenciais alterações farmacocinéticas (gestação, politerapia); e 6) apresentar farmacocinética dependente de dose ou janela terapêutica restrita (p.ex., fenitoína).  
Efeitos adversos relacionados ao uso de fármacos antiepilépticos podem ser relacionados ou não à dose. Em geral, os efeitos relacionados à dose utilizada, como letargia, sonolência, ataxia e diplopia, são reversíveis, isto é, desaparecem com a redução da dose ou com a suspensão do fármaco causador dos sintomas. Reações adversas aos fármacos antiepilépticos, dependentes da dose ou não, podem, dependendo da gravidade, requerer suspensão imediata do mesmo. Para evitar quadros clínicos graves e de difícil condução, potencialmente fatais, devem ser identificados pacientes pertencentes a grupos de risco para o desenvolvimento de efeitos adversos, especialmente aqueles com história familiar de graves reações alérgicas, idosos, pacientes com massa corporal baixa e com doenças coexistentes (em uso de vários fármacos).  
Na pós-menopausa, artralgias e dores musculares podem indicar osteoporose associada ao uso de fármacos antiepilépticos, especialmente de indutores enzimáticos. Nos homens, disfunção sexual e aumento de peso durante tratamento com fármacos antiepilépticos podem ocorrer.  
Os principais efeitos adversos relatados encontram-se a seguir arrolados:  
- **Ácido valproico/valproato de sódio:** sonolência, cansaço, tremor, alterações da função do fígado, diminuição das  
- plaquetas, ganho de peso, queda de cabelos;  
- **Carbamazepina:** vermelhidão da pele, sonolência, ganho de peso, diarreia, náusea, vômitos, problemas para caminhar,  
- mudanças de humor, tremor, transtorno de memória, visão dupla e impotência;  
- **Clobazam:** sonolência, transtornos de memória e de comportamento, perda progressiva do efeito terapêutico;  
- **Clonazepam:** sonolência, hiperatividade (em crianças), transtornos cognitivos, sialorreia, diplopia, fadiga e depressão  
- (em adultos);  
- **Etossuximida:** diarreia, náusea, vômitos, sonolência, perda de peso, dor de cabeça;  
- **Fenitoína:** incoordenação, sonolência, aumento do volume e sangramento das gengivas, crescimento de pelos no corpo  
- e na face;  
- **Fenobarbital:** tontura, sonolência, depressão, mudança no comportamento, transtornos de memória e de concentração,  
- hiperatividade em crianças;  
30  
- **Gabapentina:** aumento do apetite, ganho de peso, tontura, incoordenação, dor de cabeça, tremor, cansaço, náusea,  
- comportamento agressivo (em crianças);  
- **Lamotrigina:** dor de cabeça, náusea, vômitos, visão dupla, tonturas, incoordenação e tremor;  
- **Levetiracetam:** tontura, sonolência, desânimo, cansaço e dor de cabeça;  
- **Primidona:** semelhantes aos do fenobarbital;  
- **Topiramato:** sonolência, perda do apetite, cansaço, nervosismo, pensamento lento, dificuldade de encontrar palavras,  
- dificuldade de concentração, perda de peso, cálculo renal e glaucoma;  
- **Vigabatrina:** defeitos do campo visual, sonolência, dor de cabeça, tontura, incoordenação, transtornos de memória e  
- de comportamento, ganho de peso e tremor.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **9 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do  
tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de fármaco.  
De acordo com a complexidade dos casos, os atendimentos podem dar-se da seguinte forma:  
Clínicos gerais, pediatras e médicos da família: podem controlar com monoterapia as crises epilépticas de 50% dos pacientes utilizando os antiepilépticos disponíveis nas UBS (vide o Manual do Ministério da Saúde OS - 0454/2015 - Avaliação e Manejo da Epilepsia na Atenção Básica e na Urgência e Emergência).  
Neurologistas e neurologistas pediátricos: podem controlar mais 20% dos pacientes com a utilização de mono-, duo- ou politerapia, dispondo de EEG e Ressonância Magnética e antiepilépticos da RENAME.  
Epileptologistas, neurocirurgiões e equipe: avaliação para confirmação diagnóstica e tratamento cirúrgico de epilepsia – controlam crises de metade dos pacientes com epilepsia refratários.  
Neurologista pediátrico, neurologista, pediatra, nutrólogo, nutricionista: avaliação para confirmação diagnóstica e possibilidade de tratamento com a dieta cetogênica – controlam crises de metade dos pacientes com epilepsia refratários.  
Os pacientes com epilepsia refratária devem ser atendidos por médicos especialistas em neurologia em hospitais terciários, habilitados na alta complexidade em Neurologia/Neurocirurgia.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **10 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.  
31

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **11 REFERÊNCIAS** -->
1. Fisher RS, Acevedo C, Arzimanoglou A et al. A practical clinical definition of epilepsy. ILAE official report. Epilepsia 2014; 55: 475-82.  
2. Banerjee PN, Filippi D, Hauser WA. The descriptive epidemiology of epilepsy – a review. Epilepsy Res 2009; 85: 31-  
45.  
3. Kwan P, Brodie MJ. Early identification of refractory epilepsy. N Engl J Med. 2000; 342: 314-9.  
4. Marino R Jr, Cukiert A, Pinho E. [Epidemiological aspects of epilepsy in São Paulo: a prevalence study]. Arq NeuroPsiquiatr. 1986; 44: 243-54.  
5. Fernandes JG, Schmidt MI, Monte TL et al. Prevalence of epilepsy. The Porto Alegre Study. Epilepsia 1992; 33(Suppl 3): 132.  
6. Noronha AL, Borges MA, Marques LH et al. Prevalence and pattern of epilepsy treatment in different socioeconomic classes in Brazil. Epilepsia 2007; 48: 880-5.  
7. Fisher RS, Cross JH, French JA et al. Operational classification of seizure types by the International League Against Epilepsy: Position paper of the ILAE Commission for Classification and Terminology. Epilepsia 2017: 58: 522-30.  
8. Panayiotopoulos CP. The new ILAE report on terminology and concepts for organization of epileptic seizures: a clinician’s critical view and contribution. Epilepsia. 2011; 52: 2155–60.  
9. Elger CE, Schmidt D. Modern management of epilepsy: a practical approach. Epilepsy Behav 2008; 12: 501-39.  
10. Sirven JI. Epilepsy: a spectral disorder. Cold Spring Harb Perspect Med 2015;5:a022848.  
11. Brigo, F. An evidence-based approach to proper diagnostic use of the electroencephalogram for suspected seizures. Epilepsy Behav 2011; 21: 219-22.  
12. Middlebrooks EH, Ver Hoef L, Szaflarski JP. Neuroimaging in epilepsy. Curr Neurol Neurosci Rep 2017; 17: 32-42.  
13. Li LM, Fish DR, Sisodiya SM, et al. High resolution magnetic resonance imaging in adults with partial or secondary generalised epilepsy attending a tertiary referral unit. J Neurol Neurosurg Psychiatry. 1995; 59: 384-7.  
14. Liu RS, Lemieux L, Bell GS, et al. Progressive neocortical damage in epilepsy. Ann Neurol 2003; 53: 312-24.  
15. Koepp MJ, Woermann FG. Imaging structure and function in refractory focal epilepsy. Lancet Neurol. 2005; 4: 42-53.  
16. Scheffer IE, Berkovic S, Capovilla G et al. ILAE classification of the epilepsies: Position paper of the ILAE Commission for Classification and Terminology. Epilepsia 2017; 58: 512-21.  
17. Burakgazi E, French JA. Treatment of epilepsy in adults. Epileptic Disord 2016; 18: 1-12.  
18. Tomson T, Marson A, Boon P et al. Valproate in the treatment of epilepsy in women and girls. Pre-publication summary  
- of Recommendations from a Joint Task-Force-Commission on European Affairs and European Academy of Neurololgy. Disponível em: <www.ilae.org/guidelines>.  
19. Harden CL, Meador KJ, Pennell PB, et al. Practice parameter update: management issues for women with epilepsy-focus on pregnancy (an evidence-based review): teratogenesis and perinatal outcomes. Report of the Quality Standards Subcommittee and Therapeutics and Technology Subcommittee of the American Academy of Neurology and American Epilepsy Society. Epilepsia 2009; 50: 1237-46.  
20. Meador KJ, Baker GA, Browning N, et al. Cognitive function at 3 years of age after fetal exposure to antiepileptic drugs. N Engl J Med 2009; 360: 1597-605.  
21. Baker GA, Bromley RL, Briggs M, et al. IQ at 6 years after in utero exposure to antiepileptic drugs: a controlled cohort study. Neurology 2015; 84: 382-90.  
22. Bromley RL, Mawer GE, Briggs M, et al. The prevalence of neurodevelopmental disorders in children prenatally exposed to antiepileptic drugs. J Neurol Neurosurg Psychiatry 2013; 84: 637-43.  
32  
23. Capovilla G, Mastrangelo M, Romeo A et al. Recommendations for the management of “febrile seizures”. Ad hoc Task Force for LICE Guideliness Commission. Epilepsia 2009 (Suppl1): 2-6.  
24. Knudsen FU. Febrile seizure: treatment and prognosis. Epilepsia 2000; 41: 2–9.  
25. Sapir D, Leitner Y, Harel S et al. Unprovoked seizures after complex febrile convulsions. Brain Dev 2000; 22: 484-6.  
26. Bragatti JA, Torres CM, Londero RG et al. Prevalence of psychiatric comorbidities in temporal lobe epilepsy: the value of structured psychiatric interviews. Epileptic Disord 2010; 12: 283-91.  
27. Mula M. The pharmacological management of psychiatric comorbidities in patients with epilepsy. Pharmacol Res  2016; 107: 147-53.  
28. Baldwin DS, Anderson IM, Nutt DJ et al. Evidence based pharmacological treatment of anxiety disorders, post-traumatic stress disorder and obsessive-compulsive disorder: a revision of the 2005 guidelines from the British Association for  
- Psychopharmacology. J Psychopharmacol 2014; 28: 403–39.  
29. Kanner AM. Management of psychiatric and neurological comorbidities in epilepsy.Nat Rev Neurol 2016; 12: 106-16.  
30. Adachi N, Kanemoto K, De Toffol B et al. Basic treatment principles for psychotic disorders in patients with epilepsy. Epilepsia 2013; 54(Suppl. 1): 19–33.  
31. Birbeck GL, French JA, Perucca E et al. Antiepileptic drug selection for people with HIV/AIDS: evidence-based guidelines from the ILAE and AAN. Epilepsia 2012; 53: 207-14.  
32. Trinka E, Cock H, Hesdorffer D et al. A definition and classification of status epilepticus – Report of the ILAE Task Force on Classification of Status Epilepticus. Epilepsia 2015; 56: 1515-23.  
33. Glauser T, Shinnar S, Gloss D et al. Evidence-based guideline: Treatment of convulsive status epilepticus in children and adults: Report of the Guideline Committee of the American Epilepsy Society. Epilepsy Curr 2016; 16: 48-61.  
34. Jones S, Pahl C, Trinka E et al. A protocol for the inhospital emergency drug management of convulsive status epilepticus in adults. Pract Neurol 2014; 14: 194-7.  
35. Trinka E. What is the relative value of the standard anticonvulsants: Phenytoin and fosphenytoin, phenobarbital, valproate, and levetiracetam? Epilepsia. 2009;50 Suppl 12:40-3.  
36. Duncan JS, Sander JW, Sisodiya SM et al. Adult epilepsy. Lancet. 2006; 367: 1087-100.  
37. Perucca E. An introduction to antiepileptic drugs. Epilepsia. 2005; 46 (Suppl 4): 31-7.  
38. Rogawski MA, Löscher W. The neurobiology of antiepileptic drugs. Nat Rev Neurosci 2004; 5: 553-64.  
39. Scottish Intercollegiate Guidelines Network (SIGN). Diagnosis and management of epilepsy in adults. Edinburgh: SIGN; 2015. (SIGN publication no. 143). [May 2015]. Available from URL: http://www.sign.ac.uk.  
40. Stephen LJ, Brodie MJ. Management of a first seizure. Special problems: adults and elderly. Epilepsia. 2008; 49 (Suppl 1): 45-9.  
41. Marson AG, Al-Kharusi AM, Alwaidh M et al. The SANAD study of effectiveness of valproate, lamotrigine, or topiramate for generalised and unclassifiable epilepsy: an unblinded randomised controlled trial. Lancet. 2007; 369: 1016-26.  
42. Marson AG, Al-Kharusi AM, Alwaidh M et al. The SANAD study of effectiveness of carbamazepine, gabapentin, lamotrigine, oxcarbazepine, carbamazepine, or topiramate for treatment of partial epilepsy: an unblinded randomised controlled trial. Lancet. 2007; 369: 1000-15.  
43. Jacoby A, Sudell M, Tudur Smith C et al. Quality-of-life outcomes of initiating treatment with standard and newer antiepileptic drugs in adults with new-onset epilepsy: findings from the SANAD trial. Epilepsia. 2015; 56: 460-72.  
44. Chadwick D. Safety and efficacy of vigabatrin and carbamazepine in newly diagnosed epilepsy: a multicentre randomised double-blind study. Vigabatrin European Monotherapy Study Group. Lancet. 1999; 354: 13-9.  
45. Mattson RH, Cramer JA, Collins JF et al. Comparison of carbamazepine, phenobarbital, phenytoin, and primidone in partial and secondarily generalized tonic-clonic seizures. N Engl J Med 1985; 313: 145-51.  
33  
46. Rowan AJ, Ramsay RE, Collins JF et al. New onset geriatric epilepsy: a randomized study of gabapentin, lamotrigine, and carbamazepine. Neurology. 2005; 64: 1868-73.  
47. Mattson RH, Cramer JA, Collins JF. A comparison of valproate with carbamazepine for the treatment of complex partial seizures and secondarily generalized tonic-clonic seizures in adults. The Department of Veterans Affairs Epilepsy Cooperative Study No. 264 Group. N Engl J Med 1992; 327: 765-71.  
48. Brodie MJ, Overstall PW, Giorgi L. Multicentre, double-blind, randomised comparison between lamotrigine and carbamazepine in elderly patients with newly diagnosed epilepsy. The UK Lamotrigine Elderly Study Group. Epilepsy Res 1999; 37: 81-7.  
49. Muller M, Marson AG, Williamson PR. Oxcarbazepine versus phenytoin monotherapy for epilepsy. Cochrane Database Syst Rev. 2006(2):CD003615.  
50. Glauser T, Ben-Menachem E, Bourgeois B et al. Updated ILAE evidence review of antiepileptic drug efficacy and effectiveness as initial monotherapy for epileptic seizures and syndromes. Epilepsia. 2013; 54: 551-63.  
51. Posner EB, Mohamed K, Marson AG. Ethosuximide, sodium valproate or lamotrigine for absence seizures in children and adolescents. Cochrane Database Syst Rev. 2005(4): CD003032.  
52. Glauser TA, Cnaan A, Shinnar S et al. Ethosuximide, valproic acid, and lamotrigine in childhood absence epilepsy. N Engl J Med. 2010; 362: 790-9.  
53. Kwan P, Brodie MJ. Combination therapy in epilepsy: when and what to use. Drugs. 2006; 66: 1817-29.  
54. French JA, Faught E. Rational polytherapy. Epilepsia. 2009; 50 (Suppl 8): 63-8.  
55. Elger CE, Fernandez G. Options after the first antiepileptic drug has failed. Epilepsia 1999; 40 (Suppl 6): S9-12.  
56. Tudur Smith C, Marson AG, Williamson PR. Carbamazepine versus phenobarbitone monotherapy for epilepsy. Cochrane Database Syst Rev. 2003(1):CD001904.  
57. Gamble CL, Williamson PR, Marson AG. Lamotrigine versus carbamazepine monotherapy for epilepsy. Cochrane Database Syst Rev. 2006(1):CD001031.  
58. Castillo SM, Schmidt DB, White S et al. Oxcarbazepine add-on for drug-resistant partial epilepsy. Cochrane Database Syst Rev 2016 (11): CD002028.  
59. Ruggieri M, McShane MA. Parental view of epilepsy in Angelman syndrome: A questionnaire study. Arch Dis Child 1998; 79: 423-426.  
60. Østergaard JR, Balslev T. Efficacy of different antiepileptic drugs in children with Angelman syndrome associated with 15q11-13 deletion: the Danish experience. Dev Med Child Neurol 2001; 43: 718-719.  
61. Valente KD, Koiffmann CP, Fridman C, Varella M, Kok F, Andrade JQ, et al. Epilepsy in patients with Angelman syndrome caused by deletion of the chromosome 15q11-13.  Arch Neurol 2006; 63:122-128.  
62. Darteyre S, Mazzola L, Convers P, Lebrun M, Ville D. Angelman syndrome and pseudo-hypsarrhythmia: a diagnostic pitfall. Epileptic Disord. 2011;13(3); 331-335.  
63. Michael B, Marson AG. Clobazam as an add-on in the management of refractory epilepsy. Cochrane Database Syst Rev. 2008(2):CD004154.  
64. Panayiotopoulos T. A clinical guide to epileptic syndromes and their treatment. 2nd Ed. 2007; Springer, London, pp: 156-7, 353.  
65. Chebib M., Johnston GAR. The “ABC” of Gaba receptors: a brief review. Clin Exp Pharmacol Physiol 1999; 26: 93740.  
66. Tsai JJ, Yen DJ, HsihMS et al.Efficacy and safety of levetiracetam (up to 2000 mg/day) in Taiwanese patients with refractory partial seizures: a multicenter, randomized, double-blind, placebo-controlled study. Epilepsia 2006; 47: 72–81.  
34  
67. Crepeau AZ, Treiman DM. Levetiracetam: a comprehensive review. Expert Review of Neurotherapeutics 2010; 10: 159–  
71.  
68. Lynch BA, Lambeng N, Nocka K, et al. The synaptic vesicle protein SV2A is the binding site for the antiepileptic drug levetiracetam. Proc Natl Acad Sci USA 2004; 101: 9861–6.  
69. Xu T, Bajjalieh SM. SV2 modulates the size of the readily releasable pool of secretory vesicles. Nat Cell Biol 2001; 3: 691–8.  
70. Cereghino JJ, Biton V, Abou-Khalil B et al. Levetiracetam for partial seizures: results of a double-blind, randomized clinical trial. Neurology 2000; 55: 236–42.  
71. Brodie MJ, Perucca E, Ryvlin P et al. Levetiracetam Monotherapy Study Group. Comparison of levetiracetam and controlled-release carbamazepine in newly diagnosed epilepsy. Neurology 2007; 68: 402–8.  
72. Mbizvo GK, Dixon P, Hutton JL et al. Levetiracetam add-on for drug-resistant focal epilepsy: an updated Cochrane Review. Cochrane Database of Systematic Reviews 2012 (9): CD001901.  
73. Fang Y, Wu X, Xu L et al. Randomized-controlled trials of levetiracetam as an adjunctive therapy in epilepsy of multiple seizure types. J Clin Neurosci 2014; 21: 55-62.  
74. Tudur Smith C, Marson AG, Williamson PR. Phenytoin versus valproate monotherapy for partial onset seizures and generalized onset tonic-clonic seizures. Cochrane Database Syst Rev. 2001(4):CD001769.  
75. Nevitt SJ, Marson AG, Weston J et al. Carbamazepine versus phenytoin monotherapy for epilepsy : an individual participant data review. Cochrane Database Syst Rev. 2017 Feb 27 (2) CD001911.  
76. Nolan Sarah J, Muller M, Tudur Smith C, Marson Anthony G. Oxcarbazepine versus phenytoin monotherapy for epilepsy. Cochrane Database Syst Rev 2013: CD003615.  
77. Taylor S, Tudur Smith C, Williamson PR et al. Phenobarbitone versus phenytoin monotherapy for partial onset seizures and generalized onset tonic-clonic seizures. Cochrane Database Syst Rev. 2001 (4):CD002217.  
78. Nolan Sarah J, Tudur Smith C, Pulman J et al. Phenobarbitone versus phenytoin monotherapy for partial onset seizures and generalised onset tonic-clonic seizures. Cochrane Database Syst Rev; 2013; (1): CD0022217.  
79. Nolan Sarah J, Marson Anthony G, Pulman J et al. Phenytoin versus valproate monotherapy for partial onset seizures and generalised onset tonic-clonic seizures. Cochrane Database Syst Rev; 2013;(8):CD001769.  
80. Rogawski MA, Bazil CW. New molecular targets for antiepileptic drugs: alpha(2)delta, SV2A, and K(v)7/KCNQ/M potassium channels. Curr Neurol Neurosci Rep. 2008; 8: 345-52.  
81. Fisher RS, Sachdeo RC, Pellock J et al. Rapid initiation of gabapentin: a randomized, controlled trial. Neurology. 2001; 56: 743-8.  
82. French JA, Kanner AM, Bautista J et al. Efficacy and tolerability of the new antiepileptic drugs II: treatment of refractory epilepsy: report of the Therapeutics and Technology Assessment Subcommittee and Quality Standards Subcommittee of the American Academy of Neurology and the American Epilepsy Society. Neurology. 2004; 62: 1261-73.  
83. Chadwick DW, Anhut H, Greiner MJ et al. A double-blind trial of gabapentin monotherapy for newly diagnosed partial seizures. International Gabapentin Monotherapy Study Group 945-77. Neurology. 1998; 51: 1282-8.  
84. Beydoun A. Monotherapy trials with gabapentin for partial epilepsy. Epilepsia. 1999; 40 (Suppl 6): S13-6.  
85. Appleton R, Fichtner K, LaMoreaux L et al. Gabapentin as add-on therapy in children with refractory partial seizures: a 12-week, multicentre, double-blind, placebo-controlled study. Gabapentin Paediatric Study Group. Epilepsia. 1999; 40: 114754.  
86. Gidal BE, DeCerce J, Bockbrader HN et al. Gabapentin bioácido valproicoailability: effect of dose and frequency of administration in adult patients with epilepsy. Epilepsy Res 1998; 31: 91-9.  
35  
87. Patsalos PN, Perucca E. Clinically important drug interactions in epilepsy: general features and interactions between antiepileptic drugs. Lancet Neurol 2003; 2: 347-56.  
88. Patsalos PN, Perucca E. Clinically important drug interactions in epilepsy: interactions between antiepileptic drugs and other drugs. Lancet Neurol 2003; 2: 473-81.  
89. Pellock JM, Appleton R. Use of new antiepileptic drugs in the treatment of childhood epilepsy. Epilepsia. 1999; 40 (Suppl 6): S29-38.  
90. Bourgeois B. New dosages and formulations of AEDs for use in pediatric epilepsy. Neurology. 2002; 58 (Suppl 7): S2-  
5.  
91. Loring DW, Meador KJ. Cognitive and behavioral effects of epilepsy treatment. Epilepsia. 2001; 42 (Suppl 8): 24-32.  
92. Montouris G. Gabapentin exposure in human pregnancy: results from the Gabapentin Pregnancy Registry. Epilepsy Behav 2003; 4: 310-7.  
93. Marson AG, Kadir ZA, Hutton JL et al. Gabapentin add-on for drug-resistant partial epilepsy. Cochrane Database Syst Rev. 2000(3):Cd001415.  
94. Al-Bachari S, Pulman J, Hutton Jane L et al. Gabapentin add-on for drug-resistant partial epilepsy. Cochrane Database Syst Rev; 2013;(7):CD001415.  
95. Jette N, Hemming K, Hutton JL et al. Topiramate add-on for drug-resistant partial epilepsy. Cochrane Database Syst Rev. 2008(3):Cd001417.  
96. Ben-Menachem E, Sander JW, Stefan H et al. Topiramate monotherapy in the treatment of newly or recently diagnosed epilepsy. Clin Ther. 2008; 30: 1180-95.  
97. Gilliam FG, Veloso F, Bomhof MA et al. A dose-comparison trial of topiramate as monotherapy in recently diagnosed partial epilepsy. Neurology. 2003; 60: 196-202.  
98. Arroyo S, Dodson WE, Privitera MD et al. Randomized dose-controlled study of topiramate as first-line therapy in epilepsy. Acta Neurol Scand 2005; 112: 214-22.  
99. Privitera MD, Brodie MJ, Mattson RH et al. Topiramate, carbamazepine and valproate monotherapy: double-blind comparison in newly diagnosed epilepsy. Acta Neurol Scand 2003; 107: 165-75.  
100. Glauser TA, Dlugos DJ, Dodson WE et al. Topiramate monotherapy in newly diagnosed epilepsy in children and adolescents. J Child Neurol. 2007; 22: 693-9.  
101. de Araujo Filho GM, Pascalicchio TF, Lin K et al. Neuropsychiatric profiles of patients with juvenile myoclonic epilepsy treated with valproate or topiramate. Epilepsy Behav 2006; 8: 606-9.  
102. Hancock EC, Cross JH. Treatment of Lennox-Gastaut syndrome. Cochrane Database of Systematic; 2013(2):CD003277.  
103. Landmark CJ. Targets for antiepileptic drugs in the synapse. Med Sci Monit. 2007; 13: 1-7.  
104. Ramaratnam S, Marson AG, Baker GA. Lamotrigine add-on for drug-resistant partial epilepsy. Cochrane Database Syst Rev. 2001(3):CD001909.  
105. Tjia-Leong E, Leong K, Marson AG. Lamotrigine adjunctive therapy for refractory generalized tonic-clonic seizures. Cochrane Database Syst Rev. 2010(12):CD007783. doi: 10.1002/14651858.CD007783.pub2.  
106. Saetre E, Perucca E, Isojärvi J, Gjerstad L, Group LS. An international multicenter randomized double-blind controlled trial of lamotrigine and sustained-release carbamazepine in the treatment of newly diagnosed epilepsy in the elderly. Epilepsia. 2007; 48: 1292-302.  
107. Sabers A, Tomson T. Managing antiepileptic drugs during pregnancy and lactation. Curr Opin Neurol 2009; 22: 157-61. 108. Sabers A, Petrenaite V. Seizure frequency in pregnant women treated with lamotrigine monotherapy. Epilepsia. 2009; 50: 2163-6.  
36  
109. Montouris G, Abou-Khalil B. The first line of therapy in a girl with juvenile myoclonic epilepsy: should it be valproate or a new agent? Epilepsia 2009; 50 (Suppl 8): 16-20.  
110. Sazgar M, Bourgeois BF. Aggrácido valproicoation of epilepsy by antiepileptic drugs. Pediatr Neurol 2005; 33: 227-34.  
111. Willmore LJ, Abelson MB, Ben-Menachem E et al. Vigabatrin: 2008 update. Epilepsia 2009; 50: 163-73.  
112. Banin E, Shalevetiracetam RS, Obolensky A et al. Retinal function abnormalities in patients treated with vigabatrin. Arch Ophthalmol 2003; 121: 811-6.  
113. Kälviäinen R, Aikiä M, Saukkonen AM et al. Vigabatrin vs carbamazepine monotherapy in patients with newly diagnosed epilepsy. A randomized, controlled study. Arch Neurol 1995; 52: 989-96.  
114. Xiao Y, Gan L, Wang J et al. Vigabatrin versus carbamazepine monotherapy for epilepsy. Cochrane Database Syst Rev 2012(1):CD008781.  
115. Hemming K, Maguire MJ, Hutton JL et al. Vigabatrin for refractory partial epilepsy. Cochrane Database Syst Rev 2013 (1): CD 007302.  
116. Marciani MG, Maschio M, Spanedda F, Iani C, Gigli GL, Bernardi G. Development of myoclonus in patients with partial epilepsy during treatment with vigabatrin: an electroencephalographic study. Acta Neurol Scand 1995; 91: 1-5.  
117. Hancock EC, Osborne JP, Edwards SW. Treatment of infantile spasms. Cochrane Database Syst Rev. 2013;6:Cd001770.  
118. Kwan P, Arzimanoglou A, Berg AT et al. Definition of drug resistant epilepsy: consensus proposal by the ad hoc Task Force of the ILAE Commission on Therapeutic Strategies. Epilepsia 2010: 51: 1069-77.  
119. Tibussek D, Klepper J, Korinthenberg R et al. Treatment of Infantile Spasms: Report of the Interdisciplinary Guideline Committee Coordinated by the German-Speaking Society for Neuropediatrics. Neuropediatrics. 2016; 47: 139-50.  
120. Shumiloff NA, Lam WM, Manasco KB. Adrenocorticotropic hormone for the treatment of West Syndrome in children. Ann Pharmacother 2013; 47: 744-54.  
121. Pellock JM, Hrachovy R, Shinnar S et al. Infantile spasms: a U.S. consensus report. Epilepsia 2010; 51: 2175-89. 122. Kuenzle C, Steinlin M, Wohlrab G, Boltshauser E, Schmitt B. Adverse effects of vigabatrin in Angelman syndrome. Epilepsia 1998; 39 (11):1213-1215.  
123. Brodie MJ, Mumford JP. Double-blind substitution of vigabatrin and valproate in carbamazepine-resistant partial epilepsy. 012 Study group. Epilepsy Res 1999; 34: 199-205.  
124. Beyreuther BK, Freitag J, Heers C et al. Lacosamide: a review of preclinical properties. CNS Drug Ver 2007; 13: 21-42.  
125. Ben-Menachem E, Biton V, Jatuzis D et al. Efficacy and safety of oral lacosamide as adjunctive therapy in adults with partial-onset seizures. Epilepsia 2007; 48: 1308-17.  
126. Chung S, Sperling M, Biton V et al. Lacosamide: efficacy and safety as oral adjunctive treatment for partial-onset seizures [abstract]. Epilepsia 2007; 48: 321.  
127. Halász P, Kälviaänen R, Mazurkiewicz-Beldzinska M et al. Adjunctive lacosamide for partial-onset seizures: efficacy and safety results from a randomized controlled trial. Epilepsia 2009; 50: 443-53.  
128. Bodalia, PN et al. Comparative efficacy and tolerability of anti-epileptic drugs for refractory focal epilepsy: systematic review and network meta-analysis reveals the need for long term comparator trials. Br J Clin Pharmacol, v. 76, n. 5, p. 649-67, Nov 2013.  
129. Costa, J et al. Clinical comparability of the new antiepileptic drugs in refractory partial epilepsy: a systematic review and meta-analysis. Epilepsia, v. 52, n. 7, p. 1280-1291, 2011.  
130. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos do Ministério da Saúde.  Portaria n<sup>o</sup> 20, de 27 de abril de 2018. Torna Pública a decisão de não incorporar a lacosamida como terapia alternativa aditiva em pacientes com epilepsia focal refratários ao tratamento prévio. Diário Oficial da República Federativa do Brasil, Brasília, Seção 1, p. 104, 30 de abril. 2018.  
37  
131. Houtkooper MA, Lammertsma A, Meyer JW et al. Oxcarbazepine (GP 47.680): a possible alternative to carbamazepine? Epilepsia 1987; 28: 693-8.  
132. Zakrzewska JM, Patsalos PN. Oxcarbazepine: a new drug in the management of intractable trigeminal neuralgia. J Neurol Neurosurg Psychiatry 1989; 52: 472-6.  
133. Glauser TA, Nigro M, Sachdeo R et al. Adjunctive therapy with oxcarbazepine in children with partial seizures. The oxcarbazepine pediatric study group. Neurology 2000; 54: 2237-44.  
134. Guerreiro MM, Vigonius U, Pohlmann H, et al. A double-blind controlled clinical trial of oxcarbazepine versus phenytoin in children and adolescents with epilepsy. Epilepsy Res 1997; 27:205–213.  
135. French JA, Kanner AM, Bautista J et al. Therapeutics and Technology Assessment Subcommittee of the American Academy of Neurology, Quality Standards Subcommittee of the American Academy of Neurology, American Epilepsy Society Efficacy and tolerability of the new antiepileptic drugs I: Treatment of new onset epilepsy: report of the therapeutics and technology assessment subcommittee and quality standards subcommittee of the American Academy of Neurology and the American Epilepsy Society. Neurology 2004; 62: 1252-60.  
136. Dong X, Leppik IE, White J et al. Hyponatremia from oxcarbazepine and carbamazepine. Neurology 2005; 65: 1976-8. 137. Wiebe S, Blume WT, Girvin JP et al, Group EaEoSfTLES. A randomized, controlled trial of surgery for temporal-lobe epilepsy. N Engl J Med 2001; 345: 311-8.  
138. Miller JW, Hakimian S. Surgical treatment of epilepsy. Continuum 2013; 19: 730-42.  
139. Ryvlin P, Cross JH, Rheims S. Epilepsy surgery in children and adults. Lancet Neurol 2014; 13: 1114-26.  
140. Chambers A, Bowen JM. Electrical stimulation for drug-resistant epilepsy: an evidence-based analysis. Ont Health Technol Assess Ser. 2013;13(18):1-37.  
141. Schachter S. Vagus nerve stimulation therapy for the treatment of epilepsy. 2016  [cited 25/03/2017]. In: UpToDate [Internet]. [cited 25/03/2017]. Available from: https://www.uptodate.com/contents/vagus-nerve-stimulation-therapy-for-thetreatment-of-epilepsy.  
142. Cukiert A. Vagus Nerve Stimulation for Epilepsy: An Evidence-Based Approach. Prog Neurol Surg. 2015;29:39-52. 143. Terra VC, D Andrea-Meira I, Amorim R, Arruda F, Oliveira AJd, Paola LD, et al. Neuromodulation in refractory epilepsy: Brazilian specialists consensus. Arq Neuro-Psiquiatr. 2016;74:1031-4. 144. Terra VC, Amorim R, Silvado C, Oliveira AJ, Jorge CL, Fácido valproicoeret E, et al. Vagus nerve stimulator in patients with epilepsy: indications and recommendations for use. Arq Neuropsiquiatr. 2013;71(11):902-6. 145. Wilder RM. The effect of ketonemia on the course of epilepsy. Mayo Clin Bulletin 1921; 2: 307-8. 146. Martin K, Jackson CF, Levy RG, Cooper PN. Ketogenic diet and other dietary treatments for epilepsy. Cochrane Database Syst Rev 2016; 9:2.  
147. Kossoff EH, McGrogan JR. Worldwide use of the ketogenic diet. Epilepsia 2005; 46:280-9.  
148. Kossoff EH, Zupec-Kania BA, Amark PE, Ballaban-Gil KR, Christina Bergqvist AG, Blackford R, Buchhalter JR, Caraballo RH, Helen Cross J, Dahlin MG, Donner EJ, Klepper J, Jehle RS, Kim HD, Christiana Liu YM, Nation J, Nordli DR Jr, Pfeifer HH, Rho JM, Stafstrom CE, Thiele EA, Turner Z, Wirrell EC, Wheless JW, Veggiotti P, Vining EP; Charlie Foundation, Practice Committee of the Child Neurology Society; Practice Committee of the Child Neurology Society; International Ketogenic Diet Study Group.Optimal clinical management of children receiving the ketogenic diet: recommendations of the International Ketogenic Diet Study Group. Epilepsia 2009; 50:304-17.  
149. Freeman JM, Kossoff EH, Hartman AL. The ketogenic diet: one decade later. Pediatrics 2007; 119: 535-43. 150. Kossoff EH, Turner Z, Doerrer S, Cervenka MC, Henry BJ. The ketogenic and modified Atkins diet. 6a ed. New York Demos, 2016.  
38  
151. Freeman JM, Vining EPG, Kossoff EH, Pyzik PL, Ye X, Goodman SN. A blinded, crossover study of the ketogenic diet. Epilepsia 2009; 50:322–25.  
152. Huttenlocher PR, Wilbourn AJ, Signore JM. Medium-chain triglycerides as therapy for intractable childhood epilepsy. Neurology 1971; 21: 1097-103.  
153. Liu YM. Medium-chain triglyceride (MCT) ketogenic therapy. Epilepsia 2008; 49 suppl. 8:33–36.  
154. Kossoff EH,  Dorward JL. The Modified Atkins Diet. Epilepsia 2008 49 suppl. 8:37–41.  
155. Pfeifer HH, Thiele EA. Low-glycemic-index treatment: a liberalized ketogenic diet for treatment of intractable epilepsy. Neurology 2005; 65: 1810-12.  
156. McDonald TJW, Cervenka MC. Ketogenic Diets for Adults With Highly Refractory Epilepsy. Epilepsy Curr. 2017 NovDec;17(6):346-350.  
157. Dressler A, et al. The ketogenic diet in infants e advantages of early use. Epilepsy Res 2015; 116:53-8.  
158. Cheng CM, Hicks K, Wang J, Eagles DA, Bondy CA. Caloric restriction augments brain glutamic acid decarboxylase65 and -67 expression. J Neurosci Res 2004; 77:270-6.  
159. Cervenka MC, Hocker S, Koenig M, Bar B, Henry-Barron B, Kossoff EH, Hartman AL, Probasco JC, Benavides DR, Venkatesan A, Hagen EC, Dittrich D, Stern T, Radzik B, Depew M, Caserta FM, Nyquist P, Kaplan PW, Geocadin RG. Phase I/II multicenter ketogenic diet study for adult superrefractory status epilepticus. Neurology 2017; 88:938-43.  
160. Kossoff  EH, Hartman AL. Ketogenic Diets: New Advances for Metabolism-Based Therapies. Curr Opin Neuro 2012; 25: 173–8.  
161. Van der Louw E, van den Hurk D, Neal E, Leiendecker B, Fitzsimmon G, Dority L, Thompson L, Marchió M, Dudzińska M, Dressler A, Klepper J, Auvin S, Cross JH. Ketogenic diet guidelines for infants with refractory epilepsy. Eur J Paediatr Neurol 2016; 20:798-809.  
162. Huffman J, Kossoff EH. State of the ketogenic diet(s) in epilepsy. Curr Neurol Neurosci Rep. 2006; 6:332-40.  
163. Groesbeck DK, Bluml RM, Kossoff EH. Long-term use of the ketogenic diet. Dev Med Child Neurol 2006; 48:978-81.  
164. Pack AM. Brivaracetam, a novel antiepileptic drug: is it effective and safe? Results from one phase III randomized trial. Epi Curr 2014; 14: 196-8.  
165. Hosain SA et al. Ketogenic diet in pediatric epilepsy patients with gastrostomy feeding. Pediatr Neurol. 2005;32:81-83.  
166. Sampaio LPB, Takakura C, Manreza, MLG. The use of a formula-based ketogenic diet in children with refractory epilepsy. Arq. Neuro-Psiquiatr, 2017 Apr;75(4):234-237.  
39  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**  
ÁCIDO VALPROICO/VALPROATO DE SÓDIO, CARBAMAZEPINA, CLOBAZAM, CLONAZEPAM, ETOSSUXIMIDA, FENITOÍNA,  
FENOBARBITAL, GABAPENTINA, LAMOTRIGINA, LEVETIRACETAM, PRIMIDONA, TOPIRAMATO E VIGABATRINA.  
Eu,______________________________________________________________________________________(nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **ácido valproico** / **valproato de sódio, carbamazepina, clobazam, clonazepam, etossuximida, fenitoína, fenobarbital, gabapentina, lamotrigina, levetiracetam, primidona, topiramato e vigabatrina** , indicados para o tratamento da **epilepsia** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a) __________________  
______________________________________________________________________________________________(nome  
do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- Controle completo das crises;  
- Melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso do medicamento:  
- **Gravidez:** todos os antiepilépticos tem um risco pequeno de provocar problemas para o feto se usados durante a  
- gestação.  Pacientes com vida sexual ativa, que pretendem engravidar ou que estão gestantes devem procurar o seu médico para orientações sobre o risco de malformações e os ajustes de dose dos antiepilépticos que deverão ser realizados durante a gestação; Os principais efeitos adversos dos medicamentos para epilepsia são:  
- **Ácido valproico/valproato de sódio:** sonolência, cansaço, tremor, alterações da função do fígado, diminuição das  
- plaquetas, ganho de peso, queda de cabelos;  
- **Carbamazepina:** vermelhidão da pele, sonolência, ganho de peso, diarreia, náusea, vômitos, problemas para  
- caminhar, mudanças de humor, tremor, transtorno de memória, visão dupla e impotência. Há relatos de piora das frequências e intensidades das crises, bem como de maior ocorrência de eventos adversos, em pacientes com síndrome de Angelman que utilizam carbamazepina;  
- **Clobazam:** sonolência, transtornos de memória e de comportamento, perda progressiva do efeito;  
- **Clonazepam:** sonolência, disartria, incoordenação, insônia em caso de interrupção abrupta;  
- **Etossuximida:** diarreia, náusea, vômitos, sonolência, perda de peso, dor de cabeça;  
- **Fenitoína:** incoordenação, sonolência, aumento do volume e sangramento das gengivas, crescimento de pelos no  
- corpo e na face;  
- **Fenobarbital:** tontura, sonolência, depressão, mudança no comportamento, transtornos de memória e de  
- concentração, hiperatividade em crianças;  
- **Gabapentina:** aumento do apetite, ganho de peso, tontura, incoordenação, dor de cabeça, tremor, cansaço, náusea,  
- comportamento agressivo (em crianças);  
- **Primidona:** os mesmos do fenobarbital;  
- **Lamotrigina:** dor de cabeça, náusea, vômitos, visão dupla, tonturas, incoordenação e tremor;  
- **Levetiracetam:** tontura, sonolência, desânimo, cansaço e dor de cabeça;  
40  
- **Topiramato:** sonolência, perda do apetite, cansaço, nervosismo, pensamento lento, dificuldade de encontrar palavras,  
- dificuldade de concentração, perda de peso, cálculo renal e glaucoma;  
- **Vigabatrina:** defeitos do campo visual, sonolência, dor de cabeça, tontura, incoordenação, transtornos de memória  
- e de comportamento, ganho de peso e tremor. Há relatos de piora das frequências e intensidades das crises, bem como de maior ocorrência de eventos adversos, em pacientes com síndrome de Angelman que utilizam vigabatrina,  
Usualmente estes efeitos adversos são leves e temporários, e se eles se agravarem, ou não desaparecerem, o paciente deve retornar ao médico.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  (    ) Sim        (    ) Não  
O meu tratamento constará do(s) seguinte(s) medicamento (s):  
- (    ) ácido valproico/valproato de sódio                 (    ) carbamazepina  
- (    ) clobazam                                                          (    ) clonazepam  
- (    ) etossuximida                                                     (    ) fenitoína  
- (    ) fenobarbital                                                        (    ) gabapentina  
- (    ) levetiracetam                                                      (    ) lamotrigina  
- (    ) topiramato                                                           (    ) primidona  
- (    ) vigabatrina  
|Local:                                                                    Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
41

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: CLASSIFICAÇÃO DAS SÍNDROMES EPILÉPTICAS -->
Síndromes eletroclínicas organizados por faixa etária de início

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: <u>Período neonatal</u> -->
Epilepsia familial neonatal benigna Encefalopatia mioclônica precoce Síndrome de Ohtahara

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: <u>Lactente</u> -->
Epilepsia do lactente com crises focais migratórias Síndrome de West Epilepsia mioclônica do lactente Epilepsia benigna do lactente Epilepsia familial benigna do lactente Síndrome de Dravet Encefalopatia mioclônica em distúrbios não progressivos

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: <u>Infância</u> -->
Crises febris _plus_ (pode começar no lactente) Síndrome de Panayiotopoulos Epilepsia mioclônica com crises atônicas (anteriormente astáticas) Epilepsia benigna com espiculas centrotemporais Epilepsia do lobo frontal noturna autossômica dominante Epilepsia occipital da infância de início tardio (tipo Gastaut) Epilepsia com ausências mioclônicas Síndrome de Lennox-Gastaut Encefalopatia epiléptica com espicula-onda continua durante o sono lento Síndrome de Landau-Kleffner Epilepsia ausência da infância <u>Adolescência - adulto</u> Epilepsia ausência juvenil Epilepsia mioclônica juvenil Epilepsia somente com crises generalizadas tonico-clônicas Epilepsias mioclônicas progressivas Epilepsia autossômica dominante com características auditivas Outras epilepsias familiares do lobo temporal <u>Correlação menos específica com a idade</u> Epilepsia focal familiar com focos variáveis (da infância à idade adulta) Epilepsias reflexas

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **<u>Constelações distintas</u>** -->
Epilepsia do lobo temporal mesial com esclerose do hipocampo Síndrome de Rasmussen  
Crises gelásticas com hamartoma hipotalâmico  
42

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: Epilepsia-hemiconvulsão-hemiplegia -->
Epilepsias que não se encaixam em nenhuma dessas categorias diagnósticas podem ser distinguidas primeiro com base na presença ou ausência de uma condição estrutural ou metabólica conhecidas (causa presumida) e, em seguida, com base no principal modo de início da crise (generalizada versus focal).  
43

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: O ELETROENCEFALOGRAMA (EEG) NO DIAGNÓSTICO DE EPILEPSIA -->
O sistema internacional 10-20 utiliza 21 pontos que são marcados dividindo o crânio em proporções de 10% ou 20% do comprimento das distâncias entre os pontos de referência, nasion e inion no plano medial e os pontos pré-auriculares no plano perpendicular ao crânio.  
A nomenclatura dos pontos é dada de acordo com a região em que estão localizados, Fp = frontal polar, F = frontal, T = temporal, C = central, P = parietal e O = occipital. Os pontos localizados sobre a linha média são indexados pela letra “z”, de “zero”, os pontos localizados do lado esquerdo da linha média por índices ímpares e à direita por índices pares.  
Em adultos, em torno de 50% dos EEG serão normais após a primeira crise. Mesmo após 5 exames (incluindo exames em sono), 20% dos pacientes não vão apresentar alteração no EEG convencional (11). O exame repetido e com maior duração, aumenta a chance de identificação de anormalidades. Portanto, um EEG normal não exclui o paciente deste Protocolo. Por outro lado, 2% a 3% da população terão anormalidades epileptiformes no EEG e não terão epilepsia. O EEG desempenha papel importante na classificação do tipo de crise e da síndrome epiléptica do paciente.  
44

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **ALTERAÇÃO PÓS PUBLICAÇÃO – ABRIL DE 2026** -->
Foram identificadas mudanças no esquema de administração de topiramato para crianças menores de seis anos aprovados em bula. Assim, foram alteradas as recomendações de uso do medicamento nessa população, considerando as duas indicações preconizadas neste Protocolo.  
As alterações foram apresentadas à Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas em sua 135ª Reunião Ordinária, ocorrida em abril de 2026, com a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação em Saúde (SCTIE/MS), da Secretaria de Atenção Especializada à Saúde (SAES/MS), da Secretaria de Atenção Primária à Saúde (SAPS/MS) e da Secretaria de Vigilância em Saúde e Ambiente (SVSA/MS).

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **ALTERAÇÃO PÓS PUBLICAÇÃO – JULHO DE 2025** -->
A pedido da Coordenação-Geral de Doenças Raras (CGRAR/DAET/SAES/MS), foi incluída frase acerca da existência de “relatos de piora das frequências e intensidades das crises, bem como de maior ocorrência de eventos adversos, em pacientes com síndrome de Angelman que utilizam” carbamazepina e vigabatrina.  
As alterações foram apresentadas à Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas em sua 127ª Reunião Ordinária, ocorrida em julho de 2025, com a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS/MS), da Secretaria de Atenção Especializada à Saúde (SAES/MS), da Secretaria de Atenção Primária à Saúde (SAPS/MS) e da Secretaria Especial de Saúde Indígena (SESAI/MS).

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **ALTERAÇÃO PÓS PUBLICAÇÃO – NOVEMBRO DE 2021** -->
A Portaria SCTIE/MS nº 67, de 27 de setembro de 2021, tornou pública a decisão de incorporar novas apresentações de comprimidos de levetiracetam (comprimidos de 500 mg e de 1000 mg) como tratamento adjuvante da epilepsia.  
Durante a atualização do Protocolo Clínico e Diretrizes Terapêuticas de Epilepsia, a Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/CGGTS/DGITIS/SCTIE/MS) identificou a necessidade de sua atualização no item7.3 Fármacos e esquemas de administração e deste Apêndice 3.  
As alterações foram apresentadas à Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas em sua 94ª Reunião Ordinária, ocorrida em 28 de outubro de 2021, com a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos (SCTIE/MS), da Secretaria de Atenção Especializada à Saúde (SAES/MS), da Secretaria de Atenção Primária à Saúde (SAPS/MS) e da Secretaria Especial de Saúde Indígena (SESAI/MS).  
Durante a reunião, foi acordada que a inclusão das referidas apresentações, sem alteração das indicações, não demandaria nova publicação do PCDT ficando a atualização foi aprovada, com o encaminhamento de ser apresentada ao Plenário da Conitec como informe. Conforme encaminhamento, o tema foi apresentado na 103ª Reunião Ordinária do Plenário da Conitec, que deliberou favoravelmente à proposta.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **A) Levantamento de informações para planejamento da reunião com os especialistas** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), o Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP) e o Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Epilepsia vigente, para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas.  
A partir das consultas realizadas foi possível identificar:  
45  
- O tratamento no SUS segue o orientado no PCDT de Epilepsia, conforme Portaria SAS/MS nº 1.319, de 25 de  
- novembro de 2013;  
- Os fármacos atualmente disponíveis são: ácido valproico/valproato de sódio, carbamazepina, clobazam,  
- etossuximida, fenitoína, fenobarbital, gabapentina, lamotrigina, topiramato e vigabatrina.  
Na Consulta Pública da CONITEC nº 03/2016 realizada sobre o PCDT foram levantadas as seguintes questões:  
- Incorporação da oxcarbazepina para casos de epilepsia refratária em crianças: até o momento, não há evidências de  
- superioridade desse fármaco à atual primeira escolha para crises focais, a carbamazepina;  
- Recomendações sobre o uso de levetiracetam: foi incluído o medicamento, conforme recomendação dos relatórios  
- de recomendação n<sup>o</sup> 248 – Fevereiro de 2017, n<sup>o</sup> 281 – Julho de 2017, n<sup>o</sup> 290 – Julho de 2017 e nº 665 – Setembro de 2021 da CONITEC;  
- Recomendações sobre o uso de lacosamida: não foi incluído o medicamento, conforme recomendação do Relatório  
- de Recomendação nº 353 – Fevereiro de 2018 da CONITEC;  
- Esclarecimentos sobre a obrigatoriedade do EEG em vigília e sono, incluir detalhes técnicos essenciais para a sua  
- realização (sistema 10-20, tempo de registro): o item 4.2.1 (Eletroencefalograma), foi reescrito, com adendos técnicos;  
- Atualizar a classificação das crises e síndromes epilépticas: atualização contemplada na Introdução (item 1);  
- Atualizar a epidemiologia da epilepsia no Brasil: atualização contemplada no item 1 (Introdução);  
- Frisar que a gabapentina é péssima para epilepsia: foi acrescentada uma frase no item referente ao fármaco, frisando  
- essa afirmação;  
- Fluxograma está confuso: será editado na oportunidade da nova publicação do PCDT e disponibilizado no sítio  
eletrônico da Conitec;  
- Esclarecer com termos atualizados os itens do CID-10 caídos em desuso, como Pequeno Mal e Grande mal: no item  
2, foram acrescidos comentários a esse respeito;  
- Revisão do Termo de Consentimento Livre e Esclarecido (TCLE): o Termo de Esclarecimento e Responsabilidade  
(TER), e não TCLE, foi reescrito;  
- Trocar as palavras “epilépticos” por “pacientes com epilepsia”, “psiquiátricos” por “pacientes com doença psiquiátrica”,  
- “refratários” por “pacientes com crises refratárias”, “deficiência mental” por “deficiência intelectual”: atendeu-se, porém, respeitando o idioma pátrio;  
- Atualizar a definição de epilepsia: realizada no item 1 (Introdução);  
- Incluir itens em Casos especiais (uso de valproato em mulheres em idade fértil e gestantes, pacientes com HIV, crises  
- febris, condução de veículos): itens acrescentados em Casos Especiais;  
- Comentar sobre o formulário RENACH – Registro Nacional de Carteiras de Habilitação – para epilepsia:  
- acrescentados esclarecimentos sobre o tema em Casos Especiais;  
- Descrever o uso do fármaco clonazepam: incluído;  
- Descrever um item para tratamento de estado de mal epiléptico (incluir ácido valproico endovenoso): incluído em  
Casos Especiais;  
- Incluir um item sobre fármacos órfãos (ACTH): Incluído.  
- Incluir novos fármacos que podem ser introduzidos no Brasil num futuro próximo (eslicarbazepina, brivaracetam, perampanel, estiripentol) e sobre o uso de canabinoides: “monitoramento do horizonte tecnológico” é feito pela Secretaria Executiva da CONITEC e fármacos que poderão vir a ser introduzidos não se incluem em PCDT, que trata do que é comprovado, disponível no Brasil e avaliado e recomendado por essa Comissão;  
- Atualizar a definição de refratariedade: no item 7.3, nos critérios de interrupção de tratamento por remissão de crises,  
- foi incluído um comentário sobre critérios para refratariedade;  
46  
- Recomendação clara de indicação para tratamento cirúrgico: incluídas;  
- Incluir um item sobre dieta cetogênica: incluído;  
- Incluir recomendações da ILAE não contempladas na versão anterior: incluídas.

---

<!-- METADADOS: doenca: PCDT Epilepsia | secao: **B) Reunião com especialistas** -->
Foi realizada reunião com os consultores especialistas e metodologistas do comitê elaborador dos PCDT, na qual foram apresentadas as informações levantadas pelos metodologistas. Os consultores especialistas apontaram para a necessidade de avaliação da incorporação de levetiracetam e estimulação do nervo vago no PCDT.  
Sendo assim, foi estabelecido que este Protocolo se destina a pacientes de ambos os sexos com epilepsia, sem restrição de idade e tem por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca do PCDT vigente.  
- **C) Elaboração de Parecer-técnico científico (PTC) de levetiracetam e estimulação do nervo vago**  
A fim de revisar a literatura sobre a eficácia, efetividade e segurança do levetiracetam e da estimulação do nervo vago foram elaborados os respectivos PTC. A conclusão foi pela incorporação do levetiracetam para casos específicos, enquanto o parecer para estimulação do nervo vago foi aprovado, mas pendente de critérios de uso e para inclusão como procedimento na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
- **D) Buscas na literatura para atualização do PCDT**  
A fim de guiar a revisão do PCDT vigente, foi realizada busca na literatura sobre **intervenções terapêuticas,** definidas pela pergunta PICO estabelecida no Quadro 1.  
**Quadro 1** – Pergunta PICO  
|População|Pacientes com epilepsia|
|---|---|
|Intervenção|Tratamento clínico|
|Comparação|Sem restrição de comparadores|
|Desfechos|Segurança e eficácia|
|Tipos de estudos|Meta-análises e revisões sistemáticas|  
A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Publicações de janeiro de 2013 a junho de 2017;  
- Fármacos registrados no Brasil;  
- Ensaios clínicos duplo-cegos com mais de 100 indivíduos participantes, duração mínima de 48 semanas;  
- Meta-análises ou revisões sistemáticas;  
- Desfechos para eficácia: tempo para adquirir de remissão de crises por 6/12 meses; 50% de redução na frequência de  
- crises após randomização; remissão de crises;  
- Desfechos para segurança: tempo de retirada do estudo; malformações fetais congênitas maiores (uso de fármacos  
- durante a gestação).  
O Quadro 2 apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
**Quadro 2** - Buscas sobre intervenções terapêuticas - meta-análises e revisões sistemáticas  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via PubMed)|"Epilepsy"[Majr] AND "Therapeutics"[Mesh]|159|11|
||AND<br>((systematic[sb]<br>OR<br>Meta-|||
||Analysis[ptyp]) AND ("2013/01/01"[PDAT]:||**Motivo das exclusões:**|  
47  
|**Base**||**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|---|
|Data<br>da<br>01/08/2017|busca:|"3000/12/31"[PDAT]) AND "humans"[MeSH<br>Terms]<br>AND<br>(English[lang]<br>OR<br>Portuguese[lang] OR Spanish[lang]))||**-**<br>Não<br>respondem<br>à<br>pergunta PICO: 67<br>-<br>Falta<br>de<br>evidências<br>significativas: 34<br>- Fármaco não registrado<br>no Brasil: 10<br>-<br>Tipo<br>de<br>estudo/metodologia: 27<br>- Revisões desatualizadas<br>(com<br>atualização<br>disponível): 10|
|Embase<br>Data da busca:<br>01/08/2017||'epilepsy'/exp/mj AND 'therapy'/exp/mj AND<br>([systematic<br>review]/lim<br>OR<br>[meta<br>analysis]/lim)<br>AND<br>([english]/lim<br>OR<br>[portuguese]/lim<br>OR<br>[spanish]/lim)<br>AND<br>[humans]/lim AND [2013-2017]/py|86|4<br>**Motivo das exclusões:**<br>**-**<br>Não<br>respondem<br>à<br>pergunta PICO: 37<br>-<br>Falta<br>de<br>evidências<br>significativas: 25<br>- Fármaco não registrado<br>no Brasil: 2<br>-<br>Tipo<br>de<br>estudo/metodologia: 12<br>- Revisões desatualizadas<br>(com<br>atualização<br>disponível): 4<br>- Duplicata em relação ao<br>Medline: 4|
|Cochrane Libra<br>Data<br>da<br>01/08/2017|ry<br>busca:|'"epilepsy" in Title, Abstract, Keywords,<br>Publication<br>Year<br>from<br>2013<br>to<br>2017 in Cochrane Reviews (Reviews only)|119|3<br>**Motivo das exclusões:**<br>**-**<br>Não<br>respondem<br>à<br>pergunta PICO: 73<br>-<br>Falta<br>de<br>evidências<br>significativas: 22<br>- Fármaco não registrado<br>no Brasil: 9<br>- Revisões desatualizadas<br>(com<br>atualização<br>disponível): 2<br>- Duplicata em relação ao<br>Medline: 10|  
48  
Foram localizados 14 artigos referentes ao levetiracetam e 4de estimulação do nervo vago. Tais artigos foram considerados nos relatórios da CONITEC de solicitação destas tecnologias.  
Os artigos selecionados encontram-se na tabela 1.  
A fim de guiar a revisão do PCDT vigente foi realizada busca na literatura sobre **diagnóstico** nos principais consensos e _guidelines internacionais_ . O Quadro 4 apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
**Quadro 4** - Busca por consensos _guidelines internacionais_ sobre diagnóstico  
|**Base**||**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|---|
|Medline|(via|"Epilepsy"[Mesh]<br>AND<br>((Consensus|21|4|
|PubMed)||Development<br>Conference[ptyp]<br>OR|||
|||Consensus<br>Development<br>Conference,||**Motivo das exclusões:**|
|Data<br>da<br>01/08/2017|busca:|NIH[ptyp] OR Guideline[ptyp] OR Practice<br>Guideline[ptyp]) AND ("2013/01/01"[PDAT]<br>:<br>"3000/12/31"[PDAT])<br>AND<br>"humans"[MeSH Terms] AND (English[lang]<br>OR Portuguese[lang] OR Spanish[lang]))||- Foco em outros aspectos que não o<br>controle medicamentoso de crises:<br>11<br>- Outras doenças que não epilepsia:<br>4<br>-<br>Outros<br>aspectos<br>que<br>não<br>tratamento: 2|
|National Gu|ideline|https://www.guideline.gov/search?q=Epileps|26|2|
|Clearinghou|se|y&f_Guideline_Category=Diagnosis&page=<br>1||**Motivo das exclusões:**|
|Data<br>da<br>01/08/2017|busca:|||- Uso de exame em investigação pré<br>cirúrgica: 6<br>- Outras doenças que não epilepsia:<br>17|  
As seguintes referências foram selecionadas como relevantes e acrescentadas no Protocolo:  
 Tibussek D, Klepper J, Korinthenberg R et al. Treatment of Infantile Spasms: Report of the Interdisciplinary Guideline Committee Coordinated by the German-Speaking Society for Neuropediatrics. Neuropediatrics. 2016; 47: 139-50.  
 Huff JS, Melnick ER, Tomaszewski CA et al. Clinical policy: critical issues in the evaluation and management of adult patients presenting to the emergency department with seizures. Ann Emerg Med. 2014; 63: 437-47.e15.  
 De Waele L, Boon P, Ceulemans B et al. First line management of prolonged convulsive seizures in children and adults: good practice points. Acta Neurol Belg 2013; 113: 375-80.  
 National Institute for Health and Clinical Excellence (NICE). The epilepsies: the diagnosis and management of the epilepsies in adults and children in primary and secondary care. London (UK): National Institute for Health and Clinical Excellence (NICE); 2012 Jan. 117 p. (Clinical guideline; no. 137).  
 Scottish Intercollegiate Guidelines Network (SIGN). Diagnosis and management of epilepsy in adults. A national clinical guideline. Edinburgh (Scotland): Scottish Intercollegiate Guidelines Network (SIGN); 2015 May. 94 p. (SIGN publication; no. 143).  
49  
- Para informações adicionais de **dados nacionais** sobre a doença também foi realizada uma busca, conforme o Quadro  
- 5, que apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
- A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Publicações de janeiro de 2013 a junho de 2017.  
- Estudos observacionais  
- Mais de 100 pacientes  
- Prevalência, etiologia e tratamento da epilepsia no Brasil  
Os artigos selecionados encontram-se na tabela 2.  
**Quadro 5** - Busca por dados nacionais sobre a doença  
|**Base**||**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|---|
|Medline|(via|"Epilepsy"[Mesh] AND "Brazil"[Mesh] AND|48|2|
|PubMed)||(("2013/01/01"[PDAT] : "3000/12/31"[PDAT])|||
|||AND<br>"humans"[MeSH<br>Terms]<br>AND||**Motivo das exclusões:**|
|Data<br>da<br>01/08/2017|busca:|(English[lang]<br>OR<br>Portuguese[lang]<br>OR<br>Spanish[lang]))||- Outras doenças: 10<br>-<br>Intervenções<br>não<br>medicamentosas: 17<br>- Metodologia: 6<br>- Grupos específicos: 13|
|Embase||'epilepsy'/exp<br>AND<br>'brazil'/exp<br>AND<br>([english]/lim<br>OR<br>[portuguese]/lim<br>OR|102|2|
|Data<br>da<br>01/08/2017|busca:|[spanish]/lim) AND [humans]/lim AND [2013-<br>2017]/py||**Motivo das exclusões:**<br>- Outras doenças: 47<br>- Outros países: 4<br>- Grupos específicos: 13|
|||||-<br>Intervenções<br>não<br>medicamentosas: 28<br>- Metodologia: 6<br>- Duplicação: 2|  
Foram também utilizados como referência a base de dados _UpToDate_ , versão 2017, livros texto e referências de conhecimento dos autores.  
Da versão anterior do PCDT, 67 referências foram mantidas e 74 acrescentadas. Vinte referências saíram.  
50  
**Tabela 1: Estudos selecionados - intervenções terapêuticas**  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|Strzelczyk A, Zöllner JP,<br>Willems<br>LM<br>et<br>al.<br>Lacosamide in status<br>epilepticus: Systematic<br>review<br>of<br>current<br>evidence.<br>Epilepsia<br>2017; 58: 933-50|Revisão<br>sistemática|522 episódios de SE<br>486 adultos<br>36<br>crianças<br>e<br>adolescentes|Lacosamida EV.|Resolução do SE.|Eficácia geral: 57%.<br>Maior eficácia: SE focal motor (92%;<br>34/39, p = 0,013).<br>Eficácia comparável entre SE não<br>convulsivo (57%; 82/145) e convulsivo<br>(61%; 30/49; p = 0,68).<br>Uso na fase tardia do SE: eficácia caiu<br>para 20%.<br>Principais efeitos adversos: tonturas,<br>alteração da visão, diplopia, ataxia.|Lacosamida é promissora para<br>uso em SE:<br>- sem potenciais interações<br>farmacológicas,<br>- possibilidade de uso EV,<br>ideal<br>para<br>situações<br>de<br>emergência.|
|Zhao T. Feng X. Liu J et<br>al. Evaluate the Efficacy<br>and Safety of Anti-<br>Epileptic<br>Medications<br>for Partial Seizures of<br>Epilepsy: A Network<br>Meta-Analysis. J Cell<br>Biochem 2017; 118: 9;<br>2850-64|Meta-análise|90 publicações|17<br>fármacos<br>antiepilépticos<br>x<br>placebo.|Eficácia: redução de<br>>50% de crises e<br>liberdade de crises.<br>Segurança:<br>efeitos<br>adversos.|Topiramato, levetiracetam, pregabalina<br>e oxcarbazepina foram recomendados<br>por suas relativas altas eficácias e<br>relativos baixos riscos de efeitos<br>adversos, para crises focais.||  
51  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|Nevitt S.J. Sudell M.|Meta-análise|77 publicações (36|10<br>fármacos|Segurança: tempo de|Levetiracetam teve um tempo de retirada||
|Weston<br>J<br>et<br>al.<br>Antiepileptic<br>drug||elegíveis)|antiepilépticos<br>x<br>placebo.|retirada do estudo.|do estudo maior que Carbamazepina e<br>lamotrigina, em pacientes com crises||
|monotherapy<br>for||Pelo<br>menos<br>um||Eficácia: tempo para|focais;||
|epilepsy:<br>A<br>network||desfecho de 12,391||adquirir remissão de|Valproato<br>foi<br>melhor<br>que||
|meta-analysis of||indivíduos (de um||crises por 6 e 12|carbamazepina,<br>topiramato<br>e||
|individual<br>participant<br>data. Cochrane Database<br>Syst<br>Rev<br>2017<br>(6):<br>CD011412||total<br>de<br>17,961<br>elegíveis)||meses,<br>tempo<br>de<br>primeira crise após<br>randomização.|fenobarbital, em pacientes com crises<br>generalizadas.||
|Weston J. Bromley R.<br>Jackson<br>C.F<br>et<br>al.<br>Monotherapy treatment|Meta-análise|50<br>estudos<br>(31<br>elegíveis para meta-<br>análise)|10<br>fármacos<br>antiepilépticos<br>durante a gestação|Malformações<br>fetais<br>congênitas maiores.|Levetiracetam e lamotrigina possuem os<br>menores riscos de malformações.||
|of<br>epilepsy<br>in<br>pregnancy:<br>Congenital<br>malformation<br>outcomes in the child.<br>Cochrane Database Syst<br>Rev 2016 (11): CD<br>010224||3402 indivíduos|em monoterapia.||Valproato apresenta o maior risco.||
|Chen D. Lin Y. Chen T<br>et al. Dose effects of<br>lacosamide as add-on|Meta-análise|4 ECR com 1855<br>pacientes|Lacosamida<br>adjuvante<br>em<br>adultos<br>com|Controle de crises.|400 mg/dia foi mais efetivo que 200<br>mg/dia (RR=1,23; p=0,01).||  
52  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|therapy for partial-onset<br>seizure in adult. Neurol<br>Sci 2016; 37: 6; 907-920|||epilepsia focal.<br>Doses: 200, 400 e<br>600 mg/dia.||600 mg/dia não mostrou mais benefícios<br>que 400 mg/dia (RR=1,01; p=0,90).||
|Castillo SM, Schmidt<br>DB, White S et al.<br>Oxcarbazepina<br>add-on<br>for drug-resistant partial<br>epilepsy.<br>Cochrane<br>Database Syst Rev 2016<br>(11): CD002028|Meta-análise|2 estudos<br>961<br>pacientes<br>(adultos e crianças)<br>Análise<br>primária:<br>ITT|Oxcarbazepina<br>como<br>terapia<br>adjuvante<br>em<br>pacientes com crises<br>focais refratárias x<br>placebo.|50% de redução na<br>frequência de crises.<br>Retirada do estudo.<br>Efeitos adversos.|Maior redução de crises x placebo (OR:<br>2,96).<br>Saída do estudo > placebo (OR: 2,17).<br>Efeitos<br>adversos:<br>ataxia,<br>fadiga,<br>tonturas, náusea, sonolência e diplopia.|Resultados não podem ser<br>extrapolados para o uso da<br>oxcarbazepina<br>em<br>monoterapia.|
|Ramaratnam<br>S,<br>Panebianco M, Marson<br>AG. Lamotrigine add-on<br>for drug-resistant partial<br>epilepsy.<br>Cochrane<br>Database Syst Rev 2016<br>(6): CD 001909|Meta-análise|12 estudos<br>1322<br>pacientes<br>(adultos e crianças)|Lamotrigina<br>como<br>terapia adjuvante nas<br>epilepsias<br>focais<br>refratárias x placebo.|50% de redução na<br>frequência de crises.<br>Saída do estudo.<br>Efeitos adversos.<br>Efeitos na cognição.<br>Efeitos na qualidade|O RR para 50% na redução de crises foi<br>1,80.<br>O RR retirada do estudo foi 1,11.<br>Os eventos adversos associados com<br>lamotrigina foram: náusea, tontura,<br>diplopia e ataxia.||  
53  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|||||de vida.|||
|Ghani S. Vilensky J.<br>Turner B et al. Meta-|Meta-análise|4 ECR<br>Adultos e crianças|Estimulação<br>de<br>nervo<br>vago<br>para|Redução de crises de<br>50%.|Estimulação de alta frequência é mais<br>efetiva em adultos.||
|analysis of vagus nerve|||crises<br>focais||||
|stimulation treatment for|||refratárias<br>a|Redução de crises de|Em crianças, não houve diferenças||
|epilepsy:<br>correlation<br>between device setting<br>parameters and acute<br>response. Child Nerv<br>Syst 2015; 31: 12: 2291-<br>2304|||tratamento<br>clínico<br>ou cirúrgico.|75%.<br>Efeitos adversos.|estatísticas.<br>Efeitos adversos: rouquidão e dispneia<br>(grupo<br>de<br>estimulação<br>de<br>alta<br>frequência).||
|Cukiert A. Vagus Nerve|Meta-análise|28 estudos|Estimulação<br>do|Redução de 50% na|VNS foi benéfico para pacientes > 12||
|Stimulation<br>for|||nervo<br>vago<br>em|frequência de crises.|anos.||
|Epilepsy: An Evidence-<br>Based Approach. Prog<br>Neurol Surg 2015; 29:<br>39-52|||pacientes<br>com<br>epilepsia focal.||||
|Weston J, Shukralla A,|Meta-análise|3 ECR|Lacosamida<br>como|Redução de 50% na|OR para 50% de redução: 1,70 (x||
|McKay<br>AJ<br>et<br>al.|||terapia adjuntiva em|frequência de crises.|placebo).||
|Lacosamide<br>add-on||1311 pacientes|pacientes<br>com||||
|therapy<br>for<br>partial<br>epilepsy.<br>Cochrane||Análise<br>primária:|epilepsia<br>focal<br>refratária x placebo.|Remissão de crises.|OR para remissão de crises: 2,50.||  
54  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|Database Syst Rev 2015<br>(6): CD008841||ITT|200 a 600 mg/dia|Saída do estudo.<br>Efeitos adversos.|OR para saída do estudo: 1,88.<br>Efeitos<br>adversos:<br>incoordenação,<br>diplopia, náusea, tontura e vômitos.||
|Panebianco M, Rigby A,<br>Weston J et al. Vagus<br>nerve stimulation for<br>partial<br>seizures.<br>Cochrane Database Syst|Meta-análise|4<br>estudos<br>439 participantes|VNS em pacientes<br>com epilepsia focal<br>refratária.<br>12 a 20 semanas|50% de redução na<br>frequência de crises.<br>Saída do estudo.|OR para redução de 50% na frequência<br>de crises: 1,73.<br>Saída do estudo: 2,56.||
|Rev<br>2015<br>(4):<br>CD002896||||Efeitos adversos.<br>Efeitos na cognição.<br>Efeitos na qualidade<br>de vida.<br>Efeitos no humor.|Efeitos adversos: rouquidão, tosse,<br>dispneia, parestesia, dor, cefaleia e<br>náusea.||
|Pulman<br>J,<br>Jette<br>N,<br>Dykeman<br>J<br>et<br>al.<br>Topiramate add-on for<br>drug-resistant<br>partial<br>epilepsy.<br>Cochrane|Meta-análise|11 estudos<br>1401 participantes|Topiramato<br>como<br>terapia adjuvante na<br>epilepsia<br>focal<br>refratária x placebo.<br>11 a 19 semanas|Redução de 50% na<br>frequência de crises.<br>Remissão de crises.<br>Saída do estudo.|RR para redução de 50% na frequência<br>de crises: 2,97.<br>RR para remissão de crises: 3,41.<br>RR para saída do estudo: 2,44.||  
55  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|Database Syst Rev 2014<br>(2): CD001417||||Efeitos adversos.|Efeitos adversos: ataxia, dificuldades de<br>concentração,<br>tonturas,<br>fadiga,<br>sonolência,<br>parestesias,<br>sonolência,<br>anormalidades de pensamento, perda de<br>peso.||
|Bromley R, Weston J,<br>Adab N et al. Treatment<br>for<br>epilepsy<br>in<br>pregnancy:<br>neurodevelopmental<br>outcomes in the child.<br>Cochrane Database Syst<br>Rev<br>2014<br>(10):<br>CD010236|Meta-análise|22<br>estudos<br>prospectivos|Exposição<br>à<br>fenitoína,<br>ácido<br>valproico,<br>carbamazepina<br>e<br>lamotrigina<br>na<br>gestação.|Funcionamento<br>cognitivo global.|QI mais baixo das crianças expostas à<br>CARBAMAZEPINA<br>x<br>filhos<br>de<br>mulheres sem epilepsia (- 5,58; P=0,04).<br>QI de crianças expostas ao ácido<br>valproico mais baixo que em filhos de<br>mulheres<br>sem<br>epilepsia<br>(-8,94;<br>p<0,00001).<br>- 8,94|Mulheres<br>devem<br>seguir<br>tratamento<br>antiepiléptico<br>durante a gestação, pois crises<br>não<br>controladas<br>também<br>trazem riscos maternos.|
|Trinka E, Höfler J, Zerbs<br>A et al. Efficacy and<br>safety<br>of<br>intrácido<br>valproicoenous<br>valproate<br>for<br>status<br>epilepticus: a systematic|Meta-análise|30 estudos<br>860 pacientes|Valproato EV no SE.|Supressão de crise.|Resposta foi melhor em crianças que em<br>adultos.<br>Dose mais eficaz: 15=45 mg/kg em bolo,<br>seguido por infusão de 1-3 mg/kg/h.<br><<br>10%<br>tiveram<br>efeitos<br>adversos|Boa<br>tolerabilidade<br>cardiovascular e respiratória,<br>mesmo em índices mais altos<br>de infusão.|  
56  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|review.<br>CNS<br>Drugs<br>2014;28: 623-39|||||(tonturas, trombocitopenia e hipotensão<br>leve.||
|Fang Y, Wu X, Xu L et<br>al.<br>Randomized-<br>controlled<br>trials<br>of<br>levetiracetametiracetam<br>as an adjunctive therapy<br>in epilepsy of multiple<br>seizure types. J Clin<br>Neurosci 2014; 21: 55-<br>62|Meta-análise|13 ECR|LEVETIRACETA<br>M<br>como<br>terapia<br>adjuntiva em adultos<br>e<br>crianças<br>com<br>epilepsias<br>idiopáticas<br>e<br>secundárias,<br>com<br>múltiplos tipos de<br>crises x placebo.|Redução de 50% na<br>frequência de crises.<br>Remissão de crises.<br>Efeitos adversos.|OR para 50% de redução de crises x<br>placebo: 3,36 (p<0,00001).<br>OR para remissão de crises: 4,72<br>(p<0,00001).<br>Efeitos adversos: sonolência, agitação,<br>tontura, astenia e infecção.|Efeitos<br>adversos<br>sérios<br>(leucopenia, trombocitopenia e<br>_rash_cutâneo) foram muito<br>raros.|
|Morris GL 3rd, Gloss D,<br>Buchhalter<br>J<br>et<br>al.<br>Evidence-based<br>guideline update: vagus<br>nerve stimulation for the<br>treatment of epilepsy:<br>report of the Guideline<br>Development<br>Subcommittee<br>of<br>the<br>American|Meta-análise|470 crianças com<br>epilepsia<br>focal<br>e<br>generalizada<br>113 crianças com<br>síndrome<br>de<br>Lennox-Gastaut<br>31 adultos|VNS em pacientes<br>com mais de 12 anos<br>e com crises focais.|Redução de 50% na<br>frequência de crises.<br>Melhora<br>de<br>transtornos de humor.|No geral: 55% tiveram 50% de redução<br>de crises.<br>Lennox: 55% com 50% de redução.<br>Melhora de transtornos de humor em<br>adultos com epilepsia.||  
57  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|Academy of Neurology.<br>Neurology<br>2013;<br>81:<br>1453-9|||||||
|Shumiloff<br>NA,<br>Lam<br>WM,<br>Manasco<br>KB.<br>Adrenocorticotropic<br>hormone<br>for<br>the<br>treatment<br>of<br>West|Meta-análise|14 estudos|ACTH em baixas e<br>altas<br>doses,<br>comparados<br>a<br>Corticosteroides<br>orais e vigabatrina,|Remissão<br>dos<br>espasmos.|Baixas doses são tão efetivas quanto alta<br>doses de ACTH.<br>ACTH mostrou-se mais efetivo que<br>corticosteroides<br>e<br>vigabatrina<br>no|Dados<br>pouco<br>consistentes<br>quanto a regimes de doses, e<br>Uso de ACTH natural ou<br>sintético.|
|Syndrome in children.<br>Ann Pharmacother 2013;<br>47: 744-54|||na<br>síndrome<br>de<br>West.||tratamento de espasmos.|Cursos rápidos do fármaco são<br>preconizados<br>para<br>evitar<br>efeitos<br>adversos<br>sérios<br>(hemorragia<br>intracraniana,<br>atrofia<br>cerebral,<br>infecção,<br>síndrome de Cushing, ganho de<br>peso e hipertensão).|
|Hemming K, Maguire<br>MJ, Hutton JL et al.|Meta-análise|11 estudos|Vigabatrina<br>doses<br>entre 1000 e 6000|50% redução de crises.|RR para redução de crises: 2,58.||
|Vigabatrin for refractory<br>partial<br>epilepsy.||747 pacientes|mg/dia x placebo<br>para<br>crises|Saída do estudo.|RR para saída do estudo: 2,49.||
|Cochrane Database Syst<br>Rev<br>2013<br>(1):<br>CD<br>007302|||refratárias.|Efeitos adversos.|Efeitos adversos: cansaço e confusão<br>mental.||  
58  
**Tabela 2: Estudo selecionados – dados nacionais sobre a doença**  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|Bianchin MM, Velasco<br>TR, Wichert-Ana L et al.|Caso-controle|191 pacientes|Tratamento cirúrgico de<br>pacientes com epilepsia do|Gênero.|EH mais NCC foram mais frequentes em:<br>- Mulheres (OR: 2,45; p=0,005).|NCC<br>pode<br>ser<br>um<br>biomarcador, contribuir|
|Characteristics of mesial<br>temporal lobe epilepsy<br>associated<br>with|||lobo temporal e esclerose<br>hipocampal.|História de IPI.<br>EEG interictal.|- Pacientes sem nenhuma forma clássica de<br>IPI (OR: 2,67; p=0,004).<br>- Pacientes com pontas bitemporais no EEG|para o desenvolvimento,<br>ou ainda causar a EH.|
|hippocampal<br>sclerosis<br>plus<br>neurocysticercosis.<br>Epilepsy Res 2014; 108:<br>1889-95|||Achados<br>foram<br>comparados àqueles de<br>pacientes com EH mais<br>neurocisticercose (n=71).|Hemisfério<br>de<br>localização<br>do<br>cisticerco.|(OR: 2,0; p=0,03).<br>Cisticerco<br>significativamente<br>mais<br>frequentes no hemisfério da EH||
|Ferrari CM, de Sousa<br>RM, Castro LH. Factors<br>associated<br>with<br>treatment non-adherence<br>in patients with epilepsy|Estudo<br>transversal|385<br>pacientes<br>com epilepsia ><br>18 anos.|Observacional.|Índice<br>de<br>não-<br>aderência<br>ao<br>tratamento<br>antiepiléptico.|Índice de não adesão: 66,2%.<br>Maior em homens, pacientes mais jovens e<br>com crises não controladas.|Diminuir<br>a<br>complexidade<br>dos<br>regimes terapêuticos.<br>Estratégias dirigidas a|
|in||||Gênero.|Casos mais complexos.|homens e pacientes mais|
|Brazil. Seizure 2013; 22:||||Idade.||jovens para aumentar a|
|384-9||||Controle de crises.||aderência ao tratamento.|
|Siqueira HH, Dalbem|Levantamento|30.132|Questionário de Limoges e|Identificar pacientes|241 foram identificados como portadores de|Primeiro<br>estudo<br>de|
|JS, Papais Alvarenga<br>RM et al. Prevalence of|epidemiológic<br>o|habitantes<br>de<br>Barra<br>dos|avaliação neurológica.|com epilepsia.|epilepsia.|prevalência em região<br>semiurbana do Brasil|
|epilepsy in a Brazilian||Bugres, MT.|||76 crianças||  
59  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|semiurban region: An<br>epidemiological<br>Study. African J Neurol<br>Sci 2016; 35:1|||||165 adultos<br>Prevalência: 7,8/1000 habitantes (epilepsia<br>ativa: 5,6/1000).<br>55,7% homens<br>68,7% afro-descendentes<br>24,4% analfabetos|Educação<br>e<br>boas<br>condições de saúde são<br>fundamentais.|
|Li L.M. Genari C.M.<br>Treatment<br>gap<br>in<br>epilepsy: New insight<br>from<br>analysis<br>of<br>diagnosis gap. Epi Curr<br>2014; 14 (SUPPL. 1):<br>281|Levantamento<br>epidemiológic<br>o|Consulta<br>ao<br>Censo do IBGE<br>de<br>dados<br>do<br>Ministério<br>da<br>Saúde.<br>Registro<br>de<br>pacientes<br>com<br>epilepsia<br>no<br>Brasil.|Estimativa de cobertura<br>dos<br>pacientes<br>com<br>epilepsia no Brasil pelo<br>Governo Brasileiro.|Percentagem<br>de<br>pacientes assistidos<br>pelo Governo em<br>relação<br>a<br>uma<br>estimativa de 1% da<br>população<br>(prevalência<br>estimada<br>da<br>epilepsia no Brasil).|Foi estimado um_gap_diagnóstico de 87%.<br>Região Norte: 90%<br>Nordeste: 84%<br>Centro-Oeste: 86%<br>Sudeste: 90%<br>Sul: 87%|_Gap_diagnóstico é um<br>dos maiores problemas<br>enfrentados<br>por<br>indivíduos com epilepsia<br>no Brasil.<br>A<br>população<br>de<br>pacientes com epilepsia<br>é<br>invisível<br>para<br>o<br>Governo Brasileiro.|

---

