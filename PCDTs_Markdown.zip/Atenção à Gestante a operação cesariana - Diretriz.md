<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA N<sup>o</sup> 306, DE 28 DE MARÇO DE 2016.  
Aprova as Diretrizes de Atenção à Gestante: a operação cesariana.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **O SECRETÁRIO DE ATENÇÃO À SAÚDE** , no uso de suas atribuições, -->
Considerando a necessidade de se estabelecerem parâmetros sobre a operação cesariana no Brasil e diretrizes nacionais para a sua utilização e acompanhamento das mulheres a ela submetidas;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 141, de 06 de agosto de 2015, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), que aprova as Diretrizes de Atenção à Gestante: a operação cesariana, e o respectivo Relatório de Deliberação n<sup><u>o</u></sup> 179, de outubro de 2015; e  
Considerando a avaliação técnica do Departamento de Ações Programáticas Estratégicas  
(DAPES/SAS/MS), resolve:  
Art. 1º Ficam aprovadas, na forma do Anexo, disponível no sítio: <u>www.saude.gov.br/sas, as</u> “Diretrizes de Atenção à Gestante: a operação cesariana”.  
Parágrafo único. As diretrizes de que trata este artigo, que contêm as recomendações para a operação cesariana, são de caráter nacional e devem utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação da gestante, ou de seu responsável legal, dos potenciais riscos e eventos adversos relacionados ao  procedimento cirúrgico ou uso de medicamentos  para a operação cesariana.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento das gestantes em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
ALBERTO BELTRAME

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **RESUMO EXECUTIVO** -->
O momento do nascimento suscita questões sobre o processo do parto e via de parto, autonomia da gestante na escolha do modo de nascimento do filho e estratégias de saúde aplicáveis para a redução de morbidade e mortalidade materna e infantil.  A taxa de operação cesariana no Brasil situa-se em torno de 56%, com ampla variação entre os serviços públicos e privados. Estudos recentes da Organização Mundial da Saúde (OMS) sugerem que taxas populacionais de operação cesariana superiores a 10% não contribuem para a redução da mortalidade materna, perinatal ou neonatal. Considerando as características da nossa população, que apresenta entre outros distintivos um elevado número de operações cesarianas anteriores, a taxa de referência ajustada para a população brasileira gerada a partir do instrumento desenvolvido para este fim pela OMS estaria entre 25%-30%.  
Como as indicações de operação cesariana têm despertado divergência de opiniões no País, propõem-se estas Diretrizes para orientar profissionais da saúde e a população em geral sobre as melhores práticas relacionadas ao tema baseadas nas evidências científicas existentes.  
Por iniciativa do Ministério da Saúde, e contando com a participação de um grande grupo consultivo, 72 questões sobre operação cesariana foram discutidas e elaboradas com a finalidade de nortear estas Diretrizes. Utilizando uma metodologia de adaptação de diretrizes clínicas (ADAPTE), um conjunto de diretrizes sobre a operação cesariana foi avaliado do ponto de vista metodológico (AGREE II) e duas diretrizes foram selecionadas para adaptação ao contexto brasileiro: 1) “ _Caesarean Section”_ , elaboradas pelo NICE ( _The National Institute for Health and Care Excellence/United Kingdom Department of Health_ , publicadas em 2011 e atualizadas em 2013) e 2) as diretrizes de assistência ao parto para mulheres com operações cesarianas prévias do Colégio Francês de Ginecologistas e Obstetras- CNGOF (publicadas em 2013). As evidências científicas relevantes a cada pergunta ou conjunto de perguntas foram resumidas e classificadas. As recomendações dessas diretrizes foram discutidas por especialistas e representantes da sociedade civil brasileira, além de técnicos e consultores do Ministério da Saúde. Informações adicionais sobre as evidências referidas nestas Diretrizes podem ser encontradas nas versões ampliadas das diretrizes utilizadas para a adaptação (NICE, 2013 e CNGOF, 2013).  
O Quadro 1 apresenta uma síntese das diretrizes para a operação cesariana no Brasil.  
**<u>QUADRO 1</u>** - Diretrizes para a operação cesariana no Brasil  
|RECOMENDAÇÃO||QUALIDADE DA<br>EVIDÊNCIA|
|---|---|---|
|CUIDADO CENTRA|DO NA MULHER||
|Oferta de<br>Informações|É recomendado fornecer informações para as gestantes<br>durante a atenção pré-natal, parto e puerpério<br>baseadas em evidências atualizadas, de boa qualidade,<br>apontando benefícios e riscos sobre as formas de parto<br>e nascimento, incluindo a gestante no processo de<br>decisão.|BAIXA|
|Termo de<br>Consentimento|É recomendada a obtenção de um termo de<br>consentimento informado de todas as mulheres que<br>serão submetidas à operação cesariana programada.|MUITO BAIXA|
||Quando a decisão pela operação cesariana programada<br>for tomada, é recomendado o registro dos fatores que<br>influenciaram na decisão e, quando possível, qual deles<br>é o mais influente.||
|OPERAÇÃO CESAR|IANA PROGRAMADA||  
|Apresentação|Em<br>apresentação<br>pélvica,<br>e<br>na<br>ausência<br>de|ALTA|
|---|---|---|
|Pélvica|contraindicações (*), a versão cefálica externa é<br>recomendada a partir de 36 semanas de idade<br>gestacional, mediante termo de consentimento<br>informado.<br>A versão cefálica externa deve ser ofertada às mulheres<br>e realizada por profissional experiente com esta<br>manobra, em ambiente hospitalar.<br>Em situações nas quais a versão cefálica externa estiver<br>contraindicada (*), não puder ser praticada ou não tiver<br>sucesso, a operação cesariana é recomendada para<br>gestantes com fetos em apresentação pélvica.<br>A operação cesariana programada por apresentação<br>pélvica é recomendada a partir de 39 semanas de idade<br>gestacional. Sugere-se aguardar o início do trabalho de<br>parto.<br>Na situação de a mulher decidir por um parto pélvico<br>vaginal, é recomendado que seja informada sobre o<br>maior risco de morbidade e mortalidade perinatal e<br>neonatal e que a assistência seja realizada por<br>profissionais experientes na assistência ao parto<br>pélvico, mediante termo de consentimento informado.<br>Durante a assistência pré-natal, as mulheres devem ser<br>informadas sobre as instituições e profissionais que<br>assistem o parto pélvico.<br>(*) Contraindicações para a versão cefálica externa<br>incluem o trabalho de parto, comprometimento fetal,||  
||sangramento vaginal, bolsa rota, obesidade materna,<br>operação cesariana prévia, outras complicações<br>maternas e inexperiência do profissional com o<br>procedimento.||
|---|---|---|
|Gestação<br>Múltipla|Em gestação gemelar não complicada cujo primeiro<br>feto tenha apresentação cefálica, é recomendado que<br>a decisão pelo modo de nascimento seja individualizada<br>considerando as preferências e prioridades da mulher,<br>as características da gestação gemelar (principalmente<br>corionicidade), os riscos e benefícios de operação<br>cesariana e do parto vaginal de gemelares, incluindo o|BAIXA|
||risco<br>de<br>uma<br>operação<br>cesariana<br>de<br>urgência/emergência antes ou após o nascimento do<br>primeiro gemelar.||
||No caso de gestação gemelar não complicada cujo<br>primeiro feto tenha apresentação não cefálica, a<br>operação cesariana é recomendada.||
|Nascimento Pré-<br>Termo|Na ausência de outras indicações, a operação cesariana<br>não é recomendada como forma rotineira de<br>nascimento no trabalho de parto pré-termo em<br>apresentação cefálica.|BAIXA|
|Feto pequeno<br>para a idade<br>gestacional|Na ausência de outras indicações, a operação cesariana<br>não é recomendada como forma rotineira de<br>nascimento em caso de feto pequeno para idade<br>gestacional.|BAIXA|
|Placenta prévia|A operação cesariana programada é recomendada<br>como forma de nascimento em caso de placenta prévia<br>centro-total ou centro-parcial.|BAIXA|  
|Acretismo<br>placentário|Em gestantes com placenta prévia é recomendada a<br>realização de um exame ultrassonográfico com doppler<br>entre as semanas 28 e 32 da gestação, ou antes, se<br>possível, para investigação de acretismo placentário.<br>É recomendado que as gestantes com diagnóstico<br>ultrassonográfico de acretismo placentário recebam<br>atenção especializada em serviços de referência.|BAIXA<br>BAIXA/MUITO BAIXA|
|---|---|---|
||Em<br>gestantes<br>com<br>acretismo<br>placentário,<br>é<br>recomendado programar a operação cesariana. Nas<br>situações de suspeita de placenta increta ou percreta, é<br>recomendado programar a operação cesariana para as<br>semanas 34-36 da gestação.<br>No momento da operação cesariana, é recomendada a<br>presença de dois obstetras experientes, anestesista e<br>pediatra para o procedimento, bem como equipe<br>cirúrgica de retaguarda.<br>É recomendada a tipagem sanguínea e a reserva de<br>hemocomponentes para eventual necessidade durante<br>o procedimento.<br>O serviço de referência deve assegurar condições de<br>suporte para pacientes em estado grave.||  
|Preditores da|A utilização de pelvimetria clínica não é recomendada|ALTA|
|---|---|---|
|progressão do<br>trabalho de|para predizer a ocorrência de falha de progressão do<br>trabalho de parto ou definir a forma de nascimento.|BAIXA|
|parto|||
||A utilização de dados antropométricos maternos (por<br>exemplo, a altura materna ou tamanho do pé) não são<br>recomendados para predizer a falha de progressão do<br>trabalho de parto.||  
|Infecção pelo<br>Vírus da<br>Imunodeficiência<br>Humana (HIV)|Confirmar a idade gestacional adequadamente, a fim<br>de se evitar a prematuridade iatrogênica. Utilizar<br>parâmetros obstétricos, como data correta da última<br>menstruação, altura uterina, ultrassonografia precoce<br>(preferencialmente no 1° trimestre, ou antes da 20ª<br>semana).|ALTA|
|---|---|---|
||A operação cesariana eletiva deve ser realizada na 38ª<br>semana de gestação, a fim de se evitar a prematuridade<br>ou o trabalho de parto e a ruptura prematura das<br>membranas.||
||Caso a gestante com indicação para a operação<br>cesariana eletiva inicie o trabalho de parto antes da<br>data prevista para essa intervenção cirúrgica e chegue<br>à maternidade com dilatação cervical mínima (menor<br>que 4 cm), o obstetra deve iniciar a infusão intravenosa<br>de Zidovudina (AZT) e realizar a operação cesariana, se<br>possível, após 3 horas de infusão. Sempre que possível,<br>proceder ao parto empelicado (retirada do neonato<br>mantendo as membranas corioamnióticas íntegras).<br>Não realizar ordenha do cordão umbilical, ligando-o<br>imediatamente após a retirada do RN. Realizar a<br>completa hemostasia de todos os vasos da parede<br>abdominal e a troca das compressas ou campos<br>secundários antes de se realizar a histerotomia,<br>minimizando o contato posterior do recém-nascido<br>com sangue materno.||
||Utilizar antibiótico profilático, tanto na operação<br>cesariana eletiva quanto naquela de urgência: dose||  
||única endovenosa de 2g de cefalotina ou cefazolina,<br>após o clampeamento do cordão.||
|---|---|---|
|Infecção pelo<br>Vírus da<br>Hepatite B|A operação cesariana não é recomendada como forma<br>de prevenção da transmissão vertical em gestantes com<br>infecção por vírus da hepatite B.|MODERADA|
|Infecção pelo<br>Vírus da<br>Hepatite C|A operação cesariana não é recomendada como forma<br>de prevenção da transmissão vertical em gestantes com<br>infecção por vírus da hepatite C.|MODERADA<br>BAIXA|
||A operação cesariana programada é recomendada para<br>prevenir a transmissão vertical do HIV e Hepatite C em<br>mulheres com esta co-infecção.||
|Infecção pelo<br>vírus Herpes<br>simples (HSV)|A operação cesariana é recomendada em mulheres que<br>tenham apresentado infecção primária do vírus Herpes<br>simples durante o terceiro trimestre da gestação.|MUITO BAIXA|
||A operação cesariana é recomendada em mulheres<br>com infecção ativa (primária ou recorrente) do vírus<br>Herpes simples no momento do parto.||
|Obesidade|A operação cesariana não é recomendada como forma<br>rotineira de nascimento de feto de mulheres obesas.|MODERADA|  
|Profilaxia de|É recomendado oferecer antibioticoprofilaxia antes da|BAIXA|
|---|---|---|
|infecção|incisão na pele na intenção de reduzir infecção||
|cirúrgica|materna.|ALTA|
||A escolha do antibiótico para reduzir infecção pós-<br>operatória deve considerar fármacos efetivos para<br>endometrite, infecção urinária e infecção de sítio<br>cirúrgico.||
||Durante a operação cesariana, é recomendada a<br>remoção da placenta por tração controlada do cordão<br>e não por remoção manual, para reduzir o risco de<br>endometrite.||
|PARTO VAGINA|L COM OPERAÇÃO CESARIANA PRÉVIA||  
|Assistência à<br>mulher com<br>operação<br>cesariana prévia|É recomendado um aconselhamento sobre o modo de<br>nascimento para gestantes com operação cesariana<br>prévia que considere: as preferências e prioridades da<br>mulher, os riscos e benefícios de uma nova operação<br>cesariana e os riscos e benefícios de um parto vaginal<br>após uma operação cesariana, incluindo o risco de uma<br>operação cesariana não planejada.<br>É recomendado que as mulheres com operações<br>cesarianas prévias sejam esclarecidas de que há um<br>aumento no risco de ruptura uterina com o parto<br>vaginal após operação cesariana prévia. Este risco é, a<br>princípio, baixo, porém aumenta à medida que<br>aumenta o número de operações cesarianas prévias.|BAIXA<br>BAIXA|
|---|---|---|
||Na<br>ausência<br>de<br>outras<br>contraindicações,<br>é<br>recomendado encorajar a mulher com uma operação<br>cesariana prévia a tentativa de parto vaginal, mediante<br>termo de consentimento informado.<br>É recomendado que a conduta em relação ao modo de<br>nascimento de fetos de mulheres com duas operações<br>cesarianas prévias seja individualizada e considere os<br>riscos e benefícios de uma nova operação cesariana e<br>os riscos e benefícios de um parto vaginal após duas<br>operações cesarianas, incluindo o risco aumentado de<br>ruptura uterina e de operação cesariana adicional não<br>planejada, e as preferências e prioridades da mulher,<br>mediante termo de consentimento informado.<br>Durante a assistência pré-natal, as mulheres devem ser<br>informadas sobre as instituições e profissionais que||  
|assistem o parto vaginal após duas operações<br>cesarianas.||
|---|---|
|Os profissionais e instituições de saúde devem ter<br>resguardada sua autonomia em relação à aceitação ou<br>não da assistência ao parto vaginal após duas<br>operações cesarianas.||
|A operação cesariana é recomendada para mulheres<br>com três ou mais operações cesarianas prévias.<br>O trabalho de parto e parto vaginal não é recomendado<br>para mulheres com cicatriz uterina longitudinal de<br>operação cesariana anterior.||
|A avaliação ultrassonográfica da cicatriz uterina pós-<br>cesariana<br>segmentar<br>e<br>pelvimetria<br>não<br>são<br>recomendadas como rotina em caso de mulher com<br>uma ou mais operações cesarianas prévias.|BAIXA E MODERADA|
|Em mulheres com operação cesariana prévia e intervalo<br>entre partos inferior a 15 meses (ou intergestacional<br>inferior a seis meses), é recomendado individualizar a<br>conduta relativa ao modo de nascimento.|BAIXA|
|Para as gestantes que desejam um parto vaginal<br>(espontâneo ou induzido) após operação cesariana é<br>recomendada<br>a<br>monitorização<br>materno-fetal|BAIXA|
|intermitente e assistência que possibilite acesso<br>imediato à operação cesariana.||  
|CUIDADO DO REC|Em mulheres com operação cesariana prévia e<br>indicação para indução de trabalho de parto, é<br>recomendado o uso de balão cervical ou ocitocina.<br>O uso de misoprostol para indução do parto em<br>mulheres<br>com<br>cicatriz<br>de<br>cesariana<br>prévia,<br>independentemente do número de cesáreas, não é<br>recomendado.<br>ÉM-NASCIDO(PECULIARIDADES DA OPERAÇÃO CESARIAN|MODERADA E BAIXA<br>A)|
|---|---|---|
|Cuidado do<br>recém-nascido|Quando o nascimento ocorrer por operação cesariana,<br>é recomendada a presença de um médico pediatra<br>adequadamente treinado em reanimação neonatal.<br>Em situações onde não é possível a presença de um<br>médico pediatra em nascimentos por operação<br>cesariana, é recomendada a presença de um<br>profissional<br>médico<br>ou<br>de<br>enfermagem<br>adequadamente treinado em reanimação neonatal.|Portaria SAS/MS 371, de<br>07/05/2014,<br>e<br>NT<br>16/2014<br>CGSCAM/DAPES/SAS/MS,<br>de 10/06/2014.|
||É recomendado o cuidado térmico para o recém-<br>nascido por meio de operação cesariana.|BAIXA<br>ALTA|
||O contato pele-a-pele precoce entre a mãe e o recém-<br>nascido deve ser assegurado e facilitado.||
||É recomendado o clampeamento tardio do cordão<br>umbilical para o recém-nascido (RN) a termo e pré-<br>termo com ritmo respiratório normal, tônus normal e<br>sem líquido meconial.|ALTA|
||Nos casos de mães isoimunizadas, ou portadoras de<br>vírus HIV ou HTLV(vírus linfotrópicos de células T<br>humanas), o clampeamento deve ser imediato.||  
||É recomendado suporte adicional para a mulher que foi<br>submetida à operação cesariana para ajudá-las a iniciar<br>o aleitamento materno tão logo após o parto.|ALTA|
|---|---|---|
|Ligadura Tubária|||
|Ligadura Tubária|É recomendado que o modo de nascimento não seja|Lei 9.263/1996|
||determinado em função da realização da ligadura<br>tubária.||

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **INTRODUÇÃO** -->
O Brasil vive uma epidemia de operações cesarianas, com aproximadamente 1,6 milhão de operações cesarianas realizadas a cada ano. Nas últimas décadas, a taxa nacional de operações cesarianas tem aumentado progressivamente, e a operação cesariana tornou-se o modo mais comum de nascimento noPaís. A taxa de operação cesariana no Brasil está ao redor de 56%, havendo uma diferença significativa entre os serviços públicos de saúde (40%) e os serviços privados de saúde (85%)(1).  
Em condições ideais, a operação cesariana é uma cirurgia segura e com baixa frequência de complicações graves. Além disso, quando realizada em decorrência de razões médicas, a operação cesariana é efetiva na redução da mortalidade materna e perinatal. Entretanto, é frequentemente utilizada de forma desnecessária, sem razões médicas que possam justificar as altas taxas observadas no Brasil. É importante salientar que o conjunto de evidências científicas que abordam a operação cesariana programada em relação com a tentativa de parto vaginal é de baixa qualidade, não permitindo afirmar com clareza benefícios e riscos para mulheres que não precisem daquela intervenção cirúrgica.  
Deve-se considerar que, embora as complicações maternas graves associadas à operação cesariana sejam muito pouco frequentes, quando esse procedimento é realizado centenas de milhares de vezes ao ano observa-se um número expressivo de complicações cirúrgicas graves(2,3).Juntamente com as questões sociais, estruturais e biomédicas que determinam a mortalidade materna no Brasil, acreditase que as complicações maternas graves decorrentes da operação cesariana possam ser um fator adicional que contribui para a atenuação da velocidade de redução da mortalidade materna no Brasil(25).Do ponto de vista neonatal, principalmente pela realização de operações cesarianas desnecessárias em mulheres com idade gestacional ao redor da 37ª semana (peritermo), o procedimento passa a ser um fator contribuinte para a prematuridade tardia iatrogênica, da ocorrência de desconforto respiratório neonatal e internação em unidades de terapia intensiva neonatal(4).Mas, além dos seus efeitos na morbidade e mortalidade materna e neonatal, a operação cesariana pode interferir na vinculação entre a  
mãe e o bebê, no aleitamento materno e no futuro reprodutivo da mulher, além de possíveis repercussões de longo prazo na saúde da criança(6).  
Da mesma forma que a operação cesariana possui implicações complexas, são também complexas as causas do seu uso excessivo no Brasil. Essas causas incluem a maneira como a assistência ao nascimento é organizada no País (ainda bastante centrada na atuação individual dos profissionais em contraposição à abordagem multidisciplinar e de equipe), as características socioculturais, a qualidade dos serviços que assistem os nascimentos e as características da assistência pré-natal, que comumente deixa de preparar adequadamente as mulheres para o parto e nascimento.  
Estudos recentes da Organização Mundial da Saúde (OMS) sugerem que taxas populacionais de operação cesariana superiores a 10% não contribuem para a redução da mortalidade materna, perinatal ou neonatal(7). Entretanto, em que pese o fato de que taxas tão baixas quanto 9% a 16% sejam possíveis e seguras em determinadas populações (, o mesmo pode não ser verdadeiro em populações com características diferentes. Deve-se salientar que diversos fatores podem influenciar a taxa de operações cesarianas, fazendo com que taxas mais baixas possam não ser factíveis em um prazo curto. Alguns desses fatores são individuais (por exemplo, as características demográficas, clínicas e obstétricas das mulheres), outros são de ordem estrutural ou sistêmica (por exemplo, o modelo de atenção obstétrica) e há aqueles possivelmente mais subjetivos, como as preferências dos profissionais da saúde e das mulheres. Considerando que as características individuais das mulheres e da gestação podem influenciar de maneira independente a taxa de operação cesariana (por exemplo, paridade, operação cesariana prévia, apresentação fetal e modo de início do trabalho de parto, entre outras características), a OMS desenvolveu uma ferramenta para gerar uma referência adaptada às características da população obstétrica(9). Essa ferramenta foi desenvolvida e validada com mais de 10 milhões de nascimentos em 43 países (incluindo o Brasil). A aplicação desse modelo aos dados da Pesquisa Nascer no Brasil(10)possibilita a identificação de uma taxa que poderia ser considerada como de referência para a população brasileira, situando-se entre 25% e 30%.  
Entretanto, como o perfil demográfico, obstétrico e de complicações dos serviços de saúde pode variar, é mais importante assegurar que as mulheres que realmente necessitem da operação cesariana recebam este procedimento de maneira segura e oportuna do que buscar uma taxa específica de operações cesarianas. Neste sentido, as presentes Diretrizes visam a oferecer aos profissionais da saúde e às mulheres brasileiras orientações e recomendações baseadas em evidências científicas sobre importantes questões relacionadas à operação cesariana.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **ESCOPO E OBJETIVOS** -->
Os trabalhos para elaboração destas Diretrizes iniciaram-se com a criação de um grupo consultivo e um grupo elaborador (Apêndice 1), que se reuniram em julho de 2014, em Brasília, a fim de definir o seu escopo. Participaram da oficina indivíduos e instituições convidadas pela Coordenação-Geral de Saúde das Mulheres - CGSM/DAPES/SAS, do Ministério da Saúde, no intuito de estabelecer as questões de saúde relacionadas ao tema que seriam respondidas no processo de adaptação. Após exposição da metodologia de trabalho e discussão sobre o escopo, definiu-se que as presentes diretrizes iriam buscar responder um total de 72 perguntas consideradas prioritárias pelo grupo consultivo. Questões como a técnica cirúrgica ou anestésica, ou a conduta em outras situações específicas não foram priorizadas pelo grupo consultivo e assim não foram incluídas no escopo deste documento. Durante o desenvolvimento das diretrizes e, particularmente após a consulta pública, percebeu-se que havia maior necessidade de reflexão e amadurecimento sobre possíveis recomendações relativas a realização de operação cesariana a pedido. Considerando a base de evidências disponíveis, as contribuições recebidas durante a consulta pública e as possíveis implicações para os serviços de saúde, o grupo consultivo optou por retirar das presentes Diretrizes recomendações sobre a operação cesariana a pedido. Nos meses que se seguirem à sua publicação, esforços serão realizados para aprofundar o entendimento sobre a abordagem mais apropriada para a solicitação de operações cesarianas por parte das mulheres, ao mesmo tempo em que se desenvolvem as demais recomendações que foram selecionadas no escopo mas não incluídas nas presentes Diretrizes.  
Estas Diretrizes têm como finalidades principais avaliar e sintetizar a informação científica em relação a algumas práticas comuns relativas à operação cesariana programada, de modo a fornecer subsídios e orientação a todos os envolvidos no cuidado, no intuito de promover e proteger a saúde e o bem-estar da mulher e da criança. Nelas, não estão abordadas situações em que a operação cesariana ocorre no cuidado intraparto, de urgência, ou em gestantes com comorbidades cujas indicações dessa intervenção cirúrgica podem variar de acordo com a doença ou condição específica (por exemplo, préeclâmpsia, diabetes, lúpus).  As questões propostas foram distribuídas em capítulos acerca dos cuidados à mulher e ao recém-nascido, à operação cesariana programada e o parto vaginal após uma operação cesariana prévia.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **PÚBLICO-ALVO** -->
As “Diretrizes de Atenção à Gestante: a Operação Cesariana” estão diretamente relacionadas ao modo de nascimento e fornecem informações a mulheres, gestantes ou não, seus parceiros e população em geral sobre as circunstâncias desse procedimento. Para os profissionais da saúde que assistem o nascimento (obstetras, enfermeiros (as) obstétricos(as), obstetrizes, pediatras e anestesistas, entre outros), estas Diretrizes pretendem constituir-se em referencial para as condutas relacionadas ao procedimento e os cuidados com a mulher e o recém-nascido.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **MÉTODO** -->
As presentes Diretrizes são oriundas do trabalho normativo do Ministério da Saúde do Brasil e têm a finalidade de promover o uso de políticas e práticas informadas por evidências científicas no território nacional. A tarefa de desenvolver diretrizes informadas por evidências científicas envolve a realização de diversas revisões sistemáticas, classificação e interpretação das evidências científicas e o desenvolvimento de recomendações em consenso que inclui os profissionais da saúde e os representantes da sociedade civil. Outros países e organizações já passaram por esse processo, e existe hoje uma metodologia específica para reduzir a duplicação de esforços e permitir a adaptação de diretrizes a outros países. Considerando que a base de evidências é comum, a CGSM/DAPES/SAS do Ministério da Saúde e a Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) optaram por adaptar diretrizes recentes, informadas por evidência e de boa qualidade para a realidade brasileira, utilizando para isso a metodologia ADAPTE(11). Essa metodologia consiste em um conjunto de procedimentos padronizados para adaptar à realidade nacional, de forma transparente, as melhores e mais recentes recomendações informadas por evidência.  
O processo incluiu os passos a seguir:  
1) Constituição de um grupo técnico elaborador das diretrizes que foi responsável por secretariar o grupo consultivo, redigir o documento, realizar considerações sobre a adaptação das recomendações à realidade brasileira e considerar contribuições aportadas durante a consulta pública e revisão externa do documento.  
2) Constituição de um grupo consultivo, com ampla participação de representantes de entidades da sociedade civil organizada (Apêndice 1) relacionadas ao tema e de profissionais especialistas na atenção à saúde da mulher e da criança, como médicos obstetras, enfermeiros (as) obstétricos(as), obstetrizes, pediatras   O grupo consultivo foi responsável pela avaliação do conteúdo ao longo de todo o processo de elaboração com encontros presenciais periódicos para construção de consenso.  
3) Definição do escopo das diretrizes pelos grupos elaborador e consultivo a fim de estabelecer as questões de saúde relevantes para o cenário brasileiro a serem respondidas pelas diretrizes.  
4) Busca sistemática de diretrizes recentes, informadas por evidências e relevantes ao escopo escolhido nas bases de dados Medline, Tripdatabase, US Guideline Clearning House, Google Scholar, PAHO, WHO, Embase, ACOG, RCOG, NICE, ICSI, GIN, Scottish & New Zealand Guidelines. A estratégia de busca básica utilizada nestas Diretrizes foi: ([caesarean] OR [caesarian] OR [caesarean section] OR [caesarean delivery] OR [caesarian section] OR [caesarian delivery]) AND ([guideline] OR [guidance] OR [algorithm] OR [recommendation]). Foram encontradas 29 diretrizes, das quais 19 estavam duplicadas. Um total de 10 diretrizes foram incluídas no processo de avaliação da qualidade (Apêndice 2).  
5) As diretrizes identificadas na etapa anterior foram avaliadas quanto a sua qualidade metodológica por três participantes do grupo elaborador, que, de forma independente e mascarada, aplicaram o instrumento AGREE II através do site: <u>www.agreetrust.org(12). A avaliação da qualidades das</u> diretrizes consideradas incluiu os objetivos das diretrizes, as questões clínicas abordadas, a participação do público-alvo, rigor metodológico, clareza da apresentação das evidências e recomendações, aplicabilidade das diretrizes e independência editorial. De acordo com os critérios de qualidade propostos pelo instrumento, foram selecionadas as diretrizes sobre operações cesarianas elaboradas pelo NICE _(The National Institute for Health and Care Excellence/United Kingdom Department of Health_ (publicada em 2011 e atualizada em 2013)(6)e de assistência ao parto para mulheres com operações cesarianas prévias,do Colégio Francês de Ginecologia e Obstetrícia (publicada em 2013)(13)(Apêndice 3).  
6) O processo de adaptação das recomendações iniciou-se com a busca nas diretrizes selecionadas, por respostas às questões de saúde incluídas no escopo brasileiro. Das 72 questões originalmente listadas no escopo destas Diretrizes, um total de 42 questões estavam contempladas nas diretrizes internacionais selecionadas para adaptação. A questão relativa à taxa de referência para o Brasil foi respondida por metodologia específica desenvolvida pela OMS e detalhada na parte inicial do documento. A lista de questões não respondidas pelas diretrizes identificadas encontram-se no Apêndice 4.  
7) Seguindo o escopo definido para a realidade brasileira e baseado nas recomendações das diretrizes selecionadas no processo, o grupo elaborador preparou um esboço inicial do presente documento para apreciação pelo grupo consultivo. Em situações pontuais, em que existiam evidências científicas recentes, disponibilizadas após a fase de elaboração das diretrizes internacionais selecionadas, a base de evidências foi atualizada. No processo de adaptação, como não é realizada a revisão sistemática inicial para cada questão do escopo pelo grupo elaborador, a análise crítica da evidência é baseada nas informações fornecidas pelas diretrizes-fonte. Foram incluídas informações sobre a população brasileira e referências relevantes como parte das considerações do grupo consultivo, mas evitou-se a inclusão de novas informações e referências na base de evidências para as recomendações.  
8) De maneira geral, o esboço inicial das recomendações procurou manter-se fiel às recomendações dos documentos- fonte. Em reunião em Brasília, em 23 de março de 2015, esses grupos se reuniram a fim de estabelecer consenso a respeito das recomendações, discutindo sobre o seu conteúdo, formato, aplicabilidade e adaptações para a realidade brasileira.No processo de adaptação, as recomendações das diretrizes-fonte podem ser aceitas, aceitas com modificações específicas ou recusadas.  
9) Em observação à legislação brasileira sobre a incorporação de tecnologias e de Protocolos Clínicos e Diretrizes Terapêuticas no SUS, constantes na Lei nº 12.401, de 2011, nos Decretos nº 7.508 e 7.646, de 2011, e na Portaria nº 2.009/GM/MS de 2012, o documento foi submetido à avaliação pela Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas da CONITEC, assim como ao próprio Plenário desta Comissão, em sua 34ª Reunião, em abril de 2015.  
10) Com a recomendação favorável do Plenário da CONITEC, o documento foi submetido à consulta pública.  
11) As contribuições aportadas durante o processo de consulta pública foram avaliadas e uma nova versão do documento foi produzida.  
12) O documento foi então enviado para os membros do grupo consultivo e para revisores externos (Apêndice 1). De acordo com as sugestões dos revisores externos, o documento foi apresentado novamente para o grupo consultivo, dia 21 de julho de 2015, quando foram discutidas e aprovadas as recomendações para as diretrizes brasileiras. Por meio das interações com o grupo consultivo e com os participantes da consulta pública, as recomendações foram ajustadas para a realidade nacional.  
13) Aprovação final pela CONITEC, em agosto de 2015, e pelo Ministério da Saúde e publicação das presentes Diretrizes pela Secretaria de Atenção à Saúde – SAS/MS.  
As respostas das questões de saúde foram agrupadas por temas em capítulos e respondidas de acordo com o processo de adaptação (Apêndice 5). Como as diretrizes selecionadas utilizaram metodologias diferentes para classificação das evidências científicas, seguem em tabelas, as classificações utilizadas pelo NICE (Tabela 1) e GNGOF (Tabela 2). As questões não respondidas pelas diretrizes selecionadas serão abordadas em um momento posterior a estas Diretrizes (Apêndice 4).  
_Para mais informações sobre o conjunto de evidências científicas sugere-se a consulta aos documentos originais preparados pelo NICE e pelo CNGOF, disponível em:_ <u>http://www.nice.org.uk/guidance/cg132/resources/guidance-caesarean-section-pdf</u> .  
**Tabela 1 -** Classificação de níveis de evidência utilizado pelo NICE-UK.  
|**Nível d**|**e evidência**|**Qualidade da**<br>**evidência**|
|---|---|---|
|**1a**|Revisão sistemática ou meta-análise com estudos clínicos randomizados.|ALTA|
|**1b**|Pelo menos um ensaio clínico randomizado.|ALTA|
|**2a**|Pelo menos um estudo controlado bem desenhado sem randomização.|MODERADA|
|**2b**|Pelo menos um estudo quase-experimental bem desenhado, como uma<br>coorte.|MODERADA|
|**3**|Estudos descritivos não-experimentais bem desenhado, como estudos<br>comparativos, de correlação, caso-controle e série de casos.|BAIXA|
|**4**|Opinião de comitê de expertos ou experiência clínica de autoridades<br>respeitadas.|MUITO BAIXA|  
**Tabela 2 -** Classificação de níveis de evidência utilizada pelo Colégio Francês de Ginecologia e Obstetrícia (CNGOF).  
|**Nível de evidência**|
|---|  
|**LE1**|Ensaios clínicos randomizados muito robustos, meta-análise com<br>ensaios clínicos randomizados.|ALTA|
|---|---|---|
|**LE2**|Ensaios clínicos randomizados não muito robustos, estudos<br>comparativos não randomizados bem desenhados.|MODERADA|
|**LE3**|Estudos de caso-controle.|BAIXA|
|**LE4**|Estudos comparativos não randomizados com grande viés, estudos<br>retrospectivos, estudos transversais e série de casos.|BAIXA|

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **CAPITULO 1 – CUIDADOCENTRADO NA MULHER** -->
A oferta de informação e planejamento do modo de nascimento são discutidos neste capítulo com ênfase na abordagem quanto aos riscos e benefícios relacionados à operação cesariana programada comparada ao parto vaginal. Não são abordadas nestas Diretrizes situações em que a operação cesariana ocorre no cuidado intraparto, de urgência, ou em gestantes com comorbidades cujas indicações desse procedimento cirúrgico podem variar de acordo com a doença específica.  
_As gestantes devem receber informações baseadas em evidência e apoio para que realizem decisões conscientes sobre o modo de nascimento?_

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Oferta de informações** -->
O momento do nascimento costuma trazer questões delicadas para as mulheres, muitas vezes devido à desinformação sobre o processo do parto e o modo de nascimento.  
Uma revisão sistemática com seis ensaios clínicos randomizados (ECR) que incluiu1.443 gestantes avaliou o efeito da informação educativa no pré-natal e aspectos como ansiedade, amamentação, cuidados com a criança, apoio e ajuste psicossocial da mulher. O maior ECR (n=1.275) demonstrou um aumento de parto vaginal após operação cesariana relacionado à educação no pré-natal, porém a maioria dos ECR têm difícil interpretação devido ao pequeno tamanho da amostra e à baixa qualidade metodológica(14). Um ECR que avaliou o impacto do uso de folhetos informativos para gestantes no pré-  
natal não mostrou benefícios relacionados à postura ativa da mulher quanto às decisões sobre a gravidez, comparado com aquelas que não receberam os folhetos; no entanto, as mulheres mostraram-se satisfeitas por receber o informativo(15) (qualidade de evidência 1b).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Riscos e benefícios de uma operação cesariana programada comparada ao parto vaginal planejado** -->
Nove estudos observacionais foram incluídos na revisão sistemática realizada pelo NICE-UK (6)que comparou as repercussões de uma cesariana programada e um parto vaginal planejado. Em todos os estudos, a decisão do modo de nascimento foi realizada no pré-natal e não no momento do parto. Todas as mulheres do estudo apresentavam risco habitual (baixo risco), sem complicações, e tanto a operação cesariana quando o parto vaginal foram planejados pelas gestantes. Não foram incluídas operações cesarianas de urgência após tentativa de parto vaginal. A qualidade dos estudos existentes é baixa ou muito baixa.  
As evidências dessa revisão sistemática demonstraram que não há diferença na incidência de lesão cervical e vesical, lesão iatrogênica diversa, embolia pulmonar, falência renal aguda, infecção e ruptura uterina em gestantes submetidas à operação cesariana programada. Três estudos avaliaram a taxa de mortalidade materna, e um deles mostrou maior mortalidade no grupo da operação cesariana programada (16) e dois estudos não mostraram diferença significativa quando comparada com parto vaginal (17,18). Dos três estudos que avaliaram a incidência de histerectomia pós-parto, dois evidenciaram maior risco de histerectomia em mulheres submetidas à operação cesariana programada(17,18)e um estudo mostrou maior risco de trombose venosa profunda (17), choque cardiogênico(17) e outro, maior tempo de internação hospitalar (19)quando comparada com o parto vaginal. Um estudo avaliou dor abdominal e perineal nos primeiros três dias pós-parto, evidenciando menos dor relacionada com aoperação cesariana programada (20) e um estudo mostrou maior chance de lesão vaginal quando a gestante foi submetida a parto vaginal planejado (18). Quanto às repercussões neonatais, a revisão evidenciou maior risco de admissão em unidade de terapia intensiva (UTI) neonatal nos casos dos recém-nascidos de operação cesariana programada, não havendo diferença significativa com relação à incidência de hipóxia e encefalopatia isquêmica, hemorragia intracraniana e morbidade respiratória quando comparados aos nascidos de parto vaginal (21, 22) (qualidade de evidência 3).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Apesar da baixa qualidade dos estudos existentes sobre riscos e benefícios da operação cesariana programada e do parto vaginal, os riscos e complicações dessa operação devem ser ponderados para auxiliar na tomada de decisão quanto ao modo de nascimento.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
A informação sobre indicações de operação cesariana, sobre o procedimento e seus riscos, suspeita de comprometimento fetal, apresentação anômala e repercussões para futuras gestações deve ser feita de maneira clara e acessível, respeitando influências socioculturais e individuais da gestante. Não foram encontrados muitos estudos dissertando sobre a forma de abordagem e o instrumento de oferta de informação a respeito do modo de nascimento. Porém, considera-se que a abordagem do tema pode ser individual ou em grupo de gestantes, e a discussão sobre assuntos inerentes a gestação e ao processo do nascimento pode ajudar a esclarecer dúvidas e também a fomentar questionamentos sobre os riscos e as situações em que a operação cesariana é necessária. A gestante deve receber a informação sobreriscos e benefícios de uma operação cesariana, sendo mostrados os dados atualizados de literatura disponíveis, na expectativa de que cada mulher tenha o melhor entendimento sobre o procedimento e assim possa tomar decisões a este respeito com base em informações adequadas.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **1) É recomendado fornecer informações para as gestantes durante a atenção pré-natal, parto e puerpério baseadas em evidências atualizadas, de boa qualidade, apontando os benefícios e riscos sobre as formas de parto e nascimento, incluindo a gestante no processo de decisão.**  
_Deve ser obtido um consentimento informado?_  
_Quais informações devem ser discutidas com a mulher na obtenção do consentimento informado?_

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Consentimento informado** -->
O termo de consentimento para operação cesariana deve ser obtido para todas as mulheres que serão submetidas ao procedimento. No termo de consentimento devem estar incluídas as condições  
clínicas da paciente, opções de tratamento, riscos e benefícios operação cesariana procedimento, incluindo o risco da não realização deste procedimento. A informação deve ser fornecida de forma clara e acessível e respeitando linguagem e características socioculturais (qualidade de evidência 4). Inexistem estudos que evidenciem a melhor forma de obter o consentimento informado e como devem ser fornecidas as informações.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
As evidências devem ser discutidas com a gestante, respeitando sua dignidade, privacidade, características culturais e autonomia e considerando também sua situação clínica atual. Na ausência de estudos a respeito de consentimento informado para operação cesariana e como não existe legislação sobre emissão de termo de consentimento, as recomendações foram baseadas no código de ética médica que disserta sobre termo de consentimento para procedimentos cirúrgicos (Resolução CFM1.931/2009).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **2) É recomendada a obtenção de um termo de consentimento informado de todas as mulheres que serão submetidas à operação cesariana programada.**  
- **3) Quando a decisão pela operação cesariana programada for tomada, é recomendado o registro dos fatores que influenciaram na decisão e, quando possível, qual deles é o mais influente.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **CAPÍTULO 2 – OPERAÇÃO CESARIANAPROGRAMADA** -->
Este capítulo é destinado a considerar situações em que se pretende proceder à operação cesariana de forma eletiva. Não são abordadas nestas Diretrizes: cesariana de urgência, intraparto ou em gestantes com comorbidades cujas indicações do procedimento podem variar de acordo com a doença específica.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Apresentação pélvica** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres com gestação única e feto em apresentação pélvica?_  
_O que deve preceder este oferecimento?_  
_Em que momento deve ser realizada a operação cesariana?_  
_A versão cefálica externa deve ser oferecida para mulheres com gestação única e feto em apresentação pélvica antes da operação cesariana?_  
_Em que momento deve ser a operação cesariana realizada?_  
A apresentação pélvica ocorre em 4% do total de gestações únicas. A versão cefálica externa é uma opção para fetos em apresentação pélvica(6).  
Uma revisão sistemática da Colaboração Cochrane<sup>1</sup> com 8 ECR (n=1.308 mulheres) mostrou redução de 60% dos partos não cefálicos utilizando-se versão cefálica externa em mulheres com gestação pélvica com mais de 36 semanas, comparativamente com aquelas em que essa versão não foi utilizada (n=1.305, RR=0,42, IC 95% 0,29-0,61). A versão cefálica externa também foi associada a uma redução nas taxas de operação cesariana (n=1.305; RR=0,57; IC 95% 0,40-0,82) (17, 18) (evidência 1a)(23,24). Realizar versão cefálica externa com menos de 37 semanas não diminuiu o número de partos não cefálicos (RR=1,02, IC 95% 0,89-1,17) (25) (evidência 1a). Entretanto, devem ser consideradas algumas complicações relacionadas ao procedimento: frequência cardíaca fetal não tranquilizadora (comumente bradicardia transitória, 1,1%-16%), sangramento vaginal indolor (1,1%), ruptura de placenta (0,4%-1%) e desencadeamento do trabalho de parto (3%) (24,26) (qualidade de evidência 1b).  
Avaliando o efeito do modo de nascimento em gestações a termo com apresentação pélvica, uma revisão sistemática incluindo três ECR (n=2.396) mostrou redução de mortalidade perinatal e neonatal (RR=0,33, IC 95% 0,19-0,56) assim como morbidade neonatal grave quando se realizou uma operação cesariana. O risco de mortalidade perinatal e neonatal ou morbidade neonatal grave foi de 1,6% no grupo da operação cesariana programada e de 5%, no do parto vaginal planejado (qualidade de evidência 1b). A redução do risco absoluto de morbidade e mortalidade neonatal foi de 3,4% com operação cesariana programada (evidência 1a)(27). A proporção de partos pélvicos decresce com a idade gestacional, chegando a 30% em gestações com menos de 28 semanas. A taxa de sobrevivência em partos pélvicos  
> (<sup>1</sup> ) A revisão sistemática Cochrane foi atualizada em 2015, após atualização do NICE (2013), e no processo de adaptação os dados desta revisão foram atualizados para as presentes Diretrizes.  
em fetos pré-termo é maior com cesariana programada (86,5%) quando comparada com parto vaginal planejado (77,4%)(28)(qualidade de evidência 3).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
A versão cefálica externa apresenta-se como uma alternativa efetiva em mulheres com apresentação pélvica, visando a diminuir as complicações de um parto pélvico. A operação cesariana programada também pode ser uma alternativa na assistência à mulher com feto de apresentação pélvica.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Apesar de as evidências mostrarem os benefícios da versão cefálica externa em mulheres com fetos em apresentação pélvica, o procedimento exige habilidade técnica do profissional e parece não ser efetiva em fetos pré-termo. Quando optado pela versão cefálica externa, a mulher deve ser esclarecida sobre seus riscos e benefícios, maternos e fetais, além da possibilidade de falha desse procedimento, e que o feto pode retornar à apresentação pélvica ou outra apresentação anômala após o procedimento, podendo isso ocorrer dias após sua realização, e que o procedimento não é obrigatório. Mediante um termo de consentimento informado, a versão externa deve ser realizada em ambiente hospitalar, com recursos para permitir procedimentos de urgência e emergência, caso alguma complicação ocorra.  
Considerando que a versão espontânea para apresentação cefálica pode ocorrer a qualquer momento durante a gravidez e que operações cesarianas programadas precocemente estão associadas a aumento da morbidade neonatal, além do incremento na morbidade materna, quando se oferece uma operação cesariana por apresentação pélvica recomenda-se aguardar o termo completo (pelo menos 39 semanas).  
Considerando ainda que o risco absoluto de mortalidade neonatal é baixo, apesar do aumento do risco relativo já demonstrado, e os potenciais vieses do estudo que mais influencia a revisão sistemática da Colaboração Cochrane ( _Term Breech Trial_ )(29), recomenda-se que os resultados desses estudos sejam apresentados às gestantes de forma que a decisão pelo modo de nascimento seja baseada em evidências e que o direito da mulher que pretende ter um parto pélvico vaginal seja respeitado. Entretanto, sugerese que apenas profissionais experientes na realização do parto pélvico prestem assistência ao parto nessa modalidade e que um termo de consentimento informado seja obtido das mulheres que pleiteiem um  
parto vaginal com fetos em apresentação pélvica. Caso a gestante não deseje ser submetida à versão cefálica externa ou o profissional não tenha habilidade técnica para realizar o procedimento, a operação cesariana programada surge como opção de modo de nascimento.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendações:** -->
- **4) Em apresentação pélvica, e na ausência de contraindicações, a versão cefálica externa é recomendada a partir de 36 semanas de idade gestacional, mediante termo de consentimento informado.**  
- **5) As contraindicações para a versão cefálica externa podem incluir o trabalho de parto, comprometimento fetal, sangramento vaginal, bolsa rota, obesidade materna, cesariana prévia, outras complicações maternas e inexperiência do profissional.**  
- **6) A versão cefálica externa deve ser ofertada às mulheres e realizada por profissional experiente com esta manobra, em ambiente hospitalar.**  
- **7) Em situações nas quais a versão cefálica externa estiver contraindicada, não puder ser praticada ou não tiver sucesso, a operação cesariana é recomendada para gestantes com fetos em apresentação pélvica.**  
- **8) A operação cesariana programada por apresentação pélvica é recomendada a partir de 39 semanas de idade gestacional. Sugere-se aguardar o início do trabalho de parto.**  
- **9) Na situação de a mulher decidir por um parto pélvico vaginal, é recomendado que seja informada sobre o maior risco de morbidade e mortalidade perinatal e neonatal e que a assistência seja realizada por profissionais experientes na assistência ao parto pélvico, mediante termo de consentimento informado.**  
- **10) Durante a assistência pré-natal, as mulheres devem ser informadas sobre as instituições e profissionais que assistem o parto pélvico.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Gestação múltipla** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres com gestação gemelar não complicada, cujo primeiro feto está em apresentação cefálica?_  
_Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres com gestação gemelar não complicada, cujo primeiro feto está em apresentação não cefálica?_  
Aproximadamente 15 em 1.000 gestações são gemelares. Nos últimos anos tem havido um aumento da frequência dessas devido aos procedimentos de reprodução assistida (30). As maiores morbidade e mortalidade perinatal de gestações gemelares estão associadas à prematuridade, baixo peso  
ao nascer, discordância de crescimento entre os fetos, monocorionicidade e relacionadas ao nascimento do segundo feto (31-33) (qualidade de evidência 3).  
Uma revisão sistemática incluindo um único ECR (n=60) comparou operação cesariana e parto vaginal em gestações gemelares cujo segundo feto estava em apresentação não cefálica. Não houve diferença nas repercussões neonatais como trauma de parto ou morte perinatal; no entanto, o estudo era muito pequeno para estimar com acurácia essas variáveis. Não houve diferença no tempo de internação hospitalar, e o grupo submetido a cesariana programada teve mais risco de febre puerperal quando comparado ao submetido ao parto vaginal (RR=3,67, IC 95% 1,15-11,69) (34, 35) (qualidade de evidência 1b). A revisão incluiu ainda três coortes retrospectivas, que também não mostraram diferença consistente entre os grupos quanto a mortalidade neonatal, trauma de parto, complicações neurológicas, hiperbilirrubinemia, hipoglicemia ou taquipneia transitória(34) (qualidade de evidência 1b). Operações cesarianas programadas de gemelares realizadas entre 36 semanas e 37 semanas e seisdias estão associadas a aumento de taquipneia transitória do recém-nascido (TTRN) e distúrbios respiratórios em um ou nos dois fetos quando comparadas com cesarianas realizadas entre 38 e 40 semanas (RR=5,94, IC 95% 0,78-45,01) (36) (qualidade de evidência 2b).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Poucos estudos controlados foram incluídos na revisão do NICE sobre gestações gemelares. Não foram identificados pelo NICE estudos de boa qualidade sobre gestações múltiplas com mais de dois fetos e modo de nascimento, assim como sobre os desfechos neonatais e o melhor momento para uma operação cesariana programada.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Após a atualização do NICE em 2013, um grande estudo randomizado sobre modo de nascimento em gestação gemelares comparou operação cesariana programada versus parto vaginal planejado (com cesarianas apenas se indicado) para mulheres com gestações cujo primeiro feto estava em apresentação cefálica. O _Twin Birth Study_ incluiu um total de 1.398 mulheres (2.795 fetos) e concluiu que, em gestações gemelares entre 32 semanas e 38 semanas e 6 dias de idade gestacional, a operação cesariana  
programada não diminuiu nem aumentou o risco de morte fetal ou neonatal, ou de morbidade neonatal grave(37) (qualidade de evidência 1b).  
Assim, diferentes abordagens são possíveis e podem ser necessárias de acordo com as características da gestação gemelar, principalmente a corionicidade e a presença ou não de comorbidades. A determinação do momento e modo de nascimento deve ser individualizada.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **11) Em gestação gemelar não complicada cujo primeiro feto tenha apresentação cefálica, é recomendado que a decisão pelo modo de nascimento seja individualizada considerando as preferências e prioridades da mulher, as características da gestação gemelar (principalmente corionicidade), os riscos e benefícios de operação cesariana e do parto vaginal de gemelares, incluindo o risco de uma operação cesariana de urgência/emergência antes ou após o nascimento do primeiro gêmeo.**  
- **12) No caso de gestação gemelar não complicada cujo primeiro feto tenha apresentação não cefálica, a operação cesariana é recomendada.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Nascimentos pré-termo** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres em trabalhos de parto pré-termo sem outras complicações maternas ou fetais?_  
Um grande número de estudos observacionais mostrou maior taxa de morbidade (como paralisia cerebral) e mortalidade neonatal em recém-nascidos pré-termo (38,39) (qualidade de evidência 3). A revisão sistemática realizada a respeito do tema incluiu seis ECR, três ECR com fetos cefálicos e três ECR com fetos em apresentação pélvica. Um a cada seis dos recém-nascidos alocados para operação cesariana nasceu de parto vaginal, e vice-versa. Os resultados produzidos foram inconclusivos devido à grande taxa de descontinuidade e dificuldade de recrutamento (40) (qualidade de evidência 1b).  
A melhor forma de nascimento para fetos pré-termo ainda é incerta. A operação cesariana foi proposta para melhorar as taxas de mortalidade perinatal, porém nesses casos a maior dificuldade técnica no procedimento deve ser considerada(38) (qualidade de evidência 3).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os estudos sobre modo de nascimento de fetos pré-termo são de baixa qualidade e não permitem concluir sobre os desfechos neonatais, quando comparado o parto vaginal com aoperação cesariana programada.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Existe incerteza sobre o melhor modo de nascimento de fetos pré-termo. Muitos serviços têm optado pela operação cesariana considerando outros fatores, como a apresentação pélvica, sinais de sofrimento fetal e a expectativa de sobrevida após o parto. Portanto, não se recomenda operação cesariana de rotina em função exclusiva da prematuridade e sugere-se individualizar a conduta, devendose levar em conta a idade gestacional, integridade de membranas, posição fetal e comorbidades, entre outros fatores.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
**13) Na ausência de outras indicações, a operação cesariana não é recomendada como forma rotineira de nascimento no trabalho de parto pré-termo em apresentação cefálica.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Fetos pequenos para a idade gestacional** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida para gestantes com fetos pequenos para a idade gestacional?_  
Fetos pequenos para idade gestacional (PIG) têm mais risco de hipóxia, complicações neonatais e alterações no desenvolvimento neuropsicomotor. Estudos observacionais mostram que fetos PIG têm maior risco de morte neonatal quando expostos ao trabalho de parto em comparação com aqueles que não foram expostos (RR=1,79, IC 95% 1,54-1,86) (41) (qualidade de evidência 3). A cesariana pode reduzir a necessidade de reanimação neonatal (OR= 0,20, IC 95% 0,08-0,66) (42) (qualidade de evidência 3), porém não mostrou diferença na redução de paralisia cerebral em fetos PIG (43).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os poucos estudos encontrados sobre modo de nascimento em fetos PIG são retrospectivos,com baixa validade interna. Não foi evidenciado benefício da operação cesariana na redução de desfechos neonatais negativos graves como mortalidade neonatal e paralisia cerebral.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Como não foram encontrados estudos de boa qualidade que evidenciem melhores desfechos neonatais com a operação cesariana comparado com parto vaginal, sugere-se individualizar a conduta relativa ao nascimento de fetos PIG.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
**14) Na ausência de outras indicações, a operação cesariana não é recomendada como forma rotineira de nascimento de fetos pequenos para idade gestacional**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Placenta prévia** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres cujos fetos têm placentas de localização centro-total ou centro-parcial?_  
A maior parte das placentas de inserção baixa detectadas por ultrassonografia na primeira metade da gestação costumam se resolver à medida que ocorre o crescimento uterino ao longo da gestação. Na suspeita de uma placenta de inserção baixa, deve ser realizada uma ultrassonografia no terceiro trimestre de idade gestacional **.** Um diagnóstico de placenta prévia centro-total ou centro-parcial com 36 semanas ou mais, resulta na indicação da operação cesariana a ser programada. A operação cesariana em mulheres com placenta prévia tem risco aumentado de perda sanguínea maior que 1.000mlcomparado com cesariana procedida por outras indicações (RR=3,97, IC 95% 3,24-4,85) (30) (qualidade de evidência 3).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
As evidências encontradas relacionadas às complicações da operação cesariana em mulheres com placenta prévia são provenientes de estudos observacionais de boa qualidade.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
O NICE não apresenta estudos quanto ao melhor modo de nascimento em casos de placenta prévia. Classicamente as formas de placenta prévia centro-total ou centro-parcial têm sido definidas como indicação de operação cesariana, uma vez que a placenta oclui total ou parcialmente o canal cervical no momento do parto e é evidente o risco de hemorragia e morte fetal caso o trabalho de parto progrida nessa circunstância, podendo ocorrer o óbito materno. Diante dessa situação e considerando os riscos associados, sugere-se programar a operação cesariana eletiva a partir de 37 semanas de acordo com o quadro clínico, na presença de placenta prévia centro-total ou centro-parcial. Todavia, a placentação só pode ser adequadamente avaliada no terceiro trimestre, porque antes desse período, em decorrência do crescimento uterino, pode ocorrer alteração da relação entre a placenta e o orifício cervical externo, modificando o diagnóstico. Os demais tipos de placenta prévia (inserção baixa ou marginal) não se constituem por si só indicações para realização da operação cesariana.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Acretismo placentário** -->
_Para mulheres com placenta baixa entre 32 e 34 semanas de gestação e antecedente de operação cesariana prévia, um exame ecográfico com Doppler deve ser oferecido para o diagnóstico de acretismo placentário?_  
_Em mulheres em que foi possível estabelecer o diagnóstico anteparto de acretismo placentário, deve ser oferecido encaminhamento para um centro de referência obstétrico?_  
As gestantes com operação cesariana prévia têm um risco de 0,6%-1,3% de desenvolver placenta de inserção baixa e, dessas, 11%-14% podem evoluir com acretismo placentário. Quanto maior o número de cesarianas anteriores, maior o risco de placenta prévia e, por conseguinte, maior risco de acretismo  
placentário (duas cesarianas prévias trazem um risco de 23%-40% de acretismo placentário enquanto três cesarianas ou mais, de 35-67% de acretismo em uma próxima gestação)(44).  
Em uma revisão sistemática do NICE (6)que avaliou a acurácia dos exames de imagem na investigação de acretismo placentário em gestantes com operação cesariana prévia, foram incluídos cinco estudos(45-49). Dois estudos retrospectivos(47,49)e dois prospectivos(45,46) avaliaram a acurácia do exame ultrassonográfico para diagnóstico de placenta acreta em mulheres com operação cesariana prévia e um estudos retrospectivo(47) utilizou a avaliação ultrassonográfica com Doppler colorido.  
Dois estudos avaliaram a acurácia da ressonância magnética (RM) para investigação de acretismo placentário em gestantes com operação cesariana prévia. Os estudos mostraram que a RM tem alta sensibilidade e especificidade, assim como altos valores preditivos positivos e negativos na avaliação de acretismo placentário (45,48). Considerando a prática clínica, os autores da revisão sugerem que os exames para investigação de placenta prévia sejam realizados entre 32-34 semanas de gestação (6).  
Os efeitos do diagnóstico pré-natal de acretismo placentário por meio de exames de imagem e as repercussões maternas e perinatais foram também avaliados na revisão do NICE(6). Dois estudos observacionais foram incluídos, comparando um grupo com diagnóstico pré-natal de acretismo e um segundo grupo sem diagnóstico de acretismo até o parto. Um estudo mostrou menor perda sanguínea e menor necessidade de histerectomia de emergência nas gestantes com diagnóstico pré-natal (50) enquanto o segundo estudo mostrou menor necessidade de hemotransfusão e maior número de admissões em UTI neonatal dos recém-nascidos (RR=1,57, IC 95% 1,16-2,28) no grupo com diagnóstico pré-natal de acretismo (51) (qualidade de evidência 2b).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
A maioria dos estudos avaliou as gestantes com cerca de 30 semanas de gestação, mostrando que a ultrassonografia com Doppler tem alta sensibilidade e especificidade, assim como altos valores preditivos positivos e negativos para diagnóstico de acretismo placentário. Dos três estudos que avaliaram a acurácia da ultrassonografia com Doppler, dois são de moderada qualidade e um, de baixa qualidade. Os estudos que avaliaram a acurácia da RM para investigação de invasão placentária em placenta acreta são de moderada qualidade, evidenciando também altos valores preditivos positivos e negativos e alta sensibilidade.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
A ultrassonografia é o exame inicial na investigação de acretismo placentário, especialmente em gestantes com operação cesariana prévia. Na suspeita de acretismo evidenciada por exame ultrassonográfico, a RM pode complementar a investigação e evidenciar a extensão da invasão. Nos lugares em que este exame esteja disponível, deve-se explicar o procedimento de RM para a gestante, que é um procedimento relativamente seguro, desde que seja realizado sem contraste.  
Como o procedimento cirúrgico da cesariana em uma gestante com acretismo placentário é de maior complexidade, com risco de histerectomia, entre outras complicações, a operação cesariana deve ser programada, de preferência em serviços de referência.  A operação cesariana deve ser programada com equipe médica experiente nesse tipo de procedimento, equipe cirúrgica de retaguarda (de preferência Cirurgião Geral ou Urologista), suporte hospitalar para cuidados intensivos e acesso a hemocomponentes caso haja necessidade de transfusão.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **16) Em gestantes com placenta prévia é recomendada a realização de um exame ultrassonográfico com Doppler entre 28 e 32 semanas de idade gestacional, ou antes, se possível, para investigação de acretismo placentário.**  
- **17) É recomendado que as gestantes com diagnóstico ultrassonográfico de acretismo placentário recebam atenção especializada em serviços obstétricos de referência.**  
- **18) Em gestantes com acretismo placentário, é recomendado programar a operação cesariana. Nas situações de suspeita de placenta increta ou percreta, é recomendado programar a operação cesariana para ser realizada entre 34 e 36 semanas de gestação.**  
- **19) No momento do procedimento cirúrgico, é recomendada a presença de dois obstetras experientes, anestesista e pediatra, bem como equipe cirúrgica de retaguarda.**  
- **20) É recomendada a tipagem sanguínea e a reserva de hemocomponentes para eventual necessidade durante o procedimento.**  
- **21) O serviço obstétrico de referência deve assegurar condições de suporte para pacientes em estado grave.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Preditores da progressão do trabalho de parto** -->
_A pelvimetria clínica deve ser utilizada para predizer a ocorrência de falha de progressão do trabalho de parto?_  
_A pelvimetria clínica deve ser utilizada no processo de decisão quanto à via de parto?_  
_O tamanho do pé, a altura materna e a estimativas de tamanho fetal (ecográficas ou clínicas) devem ser utilizadas para predizer a ocorrência de falha de progressão do trabalho de parto?_  
Estudos observacionais não demonstraram validade em testes para predizer falha de progressão do trabalho de parto (tamanho do pé, a altura materna e estimativa de tamanho fetal) (52,53) (qualidade de evidência 3). A pelvimetria clínica ou por radiografia simples foi utilizada como instrumento para predizer a necessidade de operação cesariana. Revisão sistemática da Colaboração Cochrane contendo quatro ECR (n=895) relacionou a pelvimetria radiológica e modo de parto. Dois desses ECR incluíram mulheres com operação cesariana prévia. As mulheres nas quais se realizou pelvimetria tiveram mais chance de evoluir para cesariana (OR=2,97, IC 95% 1,63-288), não sendo observada diferença nas repercussões neonatais (asfixia, admissão em unidade intensiva neonatal) e deiscência de sutura(54) (qualidade de evidência 1a). Inexiste evidência que apoie o uso da pelvimetria para predizer a ocorrência de falha de progressão do trabalho de parto.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os testes de pelvimetria para predizer falha de progressão do trabalho de parto foram avaliados por estudos de boa qualidade, sendo a conclusão desses estudos desfavoráveis à prática da pelvimetria.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
A ultrassonografia, a pelvimetria e outros testes apresentam limitações em sua capacidade de prever falha na progressão do trabalho de parto. Portanto, o acompanhamento do trabalho de parto ainda é a melhor forma de evidenciar desproporção céfalo-pélvica. Tendo em vista as evidências mais recentes sobre a evolução do trabalho de parto, com a curva de Zhang et al. (2010) (55), limites menos rígidos para documentar falha de progressão podem ser adotados, não havendo obrigatoriedade de intervir em um trabalho de parto que se estende além dos limites habituais se mãe e concepto se encontram bem. Por outro lado, a macrossomia fetal (que pode ser causa de desproporção céfalo-pélvica)  
consiste em um grande desafio para o profissional que assiste o parto, dada a sua associação com dificuldades no parto e resultados adversos. A confiabilidade dos métodos disponíveis para detecção da macrossomia anteparto permanece incerta e não permite definir a melhor maneira de conduzir as gestações de fetos suspeitos de macrossomia(56).Apesar dessa incerteza sobre a detecção anteparto de fetos macrossômicos, sugere-se maior atenção e conduta individualizada quando há suspeita de macrossomia fetal (por exemplo, peso fetal estimado superior a 4.500g).Entretanto, em gestações de baixo risco, o conjunto de evidências científicas não corrobora a utilização sistemática e de rotina da ultrassonografia para predição do peso fetal a termo.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **22) A utilização de pelvimetria clínica não é recomendada para predizer a ocorrência de falha de progressão do trabalho de parto ou definir a forma de nascimento.**  
- **23) A utilização de dados antropométricos maternos (por exemplo, a altura materna ou tamanho do pé) não são recomendados para predizer a falha de progressão do trabalho de parto.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Transmissão vertical de infecções e modo de nascimento** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres infectadas pelo vírus HIV para prevenir a transmissão vertical? Em que circunstâncias esta operação deve ser oferecida para evitar a transmissão vertical?_

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Indicação da via de parto em gestantes com HIV/AIDS** -->
O Brasil tem recomendações específicas do Ministério da Saúde, atualizadas em 2015, para diminuir a transmissão vertical em gestantes HIV positivas. Assim, as recomendações destas Diretrizes de operação cesariana para gestantes com HIV/AIDS seguem as orientações do Protocolo Clínico e Diretrizes Terapêuticas: Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais, disponíveis em <http://www.aids.gov.br/tags/publicacoes/protocolo-clinico-e-diretrizes-terapeuticas>.  
Em mulheres com carga viral desconhecida ou maior que 1.000 cópias/ml após 34 semanas de gestação, a operação cesariana eletiva na 38º semana de gestação diminui o risco de transmissão vertical. Para gestantes em uso de antirretroviral e com supressão da carga viral sustentada, caso não haja indicação de cesariana por outro motivo, a via de parto vaginal é indicada (qualidade de evidência 1b)(5761).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **24) Confirmar a idade gestacional adequadamente, a fim de se evitar a prematuridade iatrogênica. Utilizar parâmetros obstétricos, como data da última menstruação correta, altura uterina, ultrassonografia precoce (preferencialmente no 1° trimestre, ou antes, da 20ª semana).**  
- **25) A operação cesariana eletiva deve ser realizada na 38ª semana de gestação, a fim de se evitar a prematuridade ou o trabalho de parto e a ruptura prematura das membranas.**  
- **26) Caso a gestante com indicação de operação cesariana eletiva inicie o trabalho de parto antes da data prevista para a essa intervenção cirúrgica e chegue à maternidade comdilatação cervical mínima (menor que 4 cm), o obstetra deve iniciar a infusão intravenosa de AZT e realizar a operação cesariana, se possível após 3 horas da infusão.**  
- **27) Sempre que possível, proceder ao parto empelicado (retirada do feto mantendo as membranas corioamnióticas íntegras).**  
- **28) Não realizar ordenha do cordão umbilical, ligando-o imediatamente após a retirada do feto. Realizar a completa hemostasia de todos os vasos da parede abdominal e a troca das compressas ou campos secundários antes de se realizar a histerotomia, minimizando o contato posterior do recém-nascido com sangue materno.**  
- **29) Utilizar antibiótico profilático para a mulher, tanto em caso de operação cesariana eletiva quanto naquele de urgência: dose única endovenosa de 2g de cefalotina ou cefazolina.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Vírus da Hepatite B** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres infectadas pelo vírus da hepatite B para prevenir a transmissão vertical?_  
A soroprevalência de anticorpo anti-HBc no Brasil é de 7,4% (IC 95% 6,8%-8,0%) (62). A transmissão vertical do vírus da hepatite B para o bebê costuma ocorrer durante o parto e pós-parto através de contato com sangue, líquido amniótico e secreção vaginal. Uma coorte (n=447) comparou operação cesariana e parto vaginal quanto à taxa de transmissão vertical do vírus B. Todas as mulheres utilizaram imunoglobulina para o vírus B, e os autores sugerem que a combinação cesariana e imunoglobulina deve ser considerada em gestantes com níveis sérios elevados de HBV-DNA(63) (qualidade de evidência 2a).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Inexistem estudos clínicos randomizados que tenham avaliado o benefício da operação cesariana na redução de transmissão vertical do vírus da hepatite B. Os estudos que avaliaram operação cesariana e redução de transmissão vertical não permitem generalização.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Inexistem estudos randomizados que possam determinar os benefícios da operação cesariana e redução de transmissão vertical. Consideram-se pontos importantes para redução da transmissão vertical, a detecção e o tratamento precoce da hepatite B (antes ou durante o pré-natal), a administração de imunoglobulina para vírus B no parto e vacinação adequada do recém-nascido.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **30) A operação cesariana não é recomendada como forma de prevenção da transmissão vertical em gestantes com infecção pelo vírus da hepatite B.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Vírus da Hepatite C** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres infectadas pelo vírus da hepatite C para prevenir a transmissão vertical?_  
O risco de transmissão vertical por vírus da hepatite C é baixo, em torno de 3% a 5%, mas chega a 20% a 30% de transmissão em mulheres com coinfecção com HIV (62). Uma coorte com 441 mulheres  
portadoras de hepatite C estimou um risco de transmissão vertical de 6,7% (IC 95% 4,0-10,2), e aquelas mulheres com coinfecção para HIV tiveram 3,8 vezes mais risco de transmissão para os recém-nascidos (64) (qualidade de evidência 2b). As mulheres com infecção pelo vírus da hepatite C não apresentaram diferença quanto à transmissão vertical, quando comparados os tipos de parto (OR 1,19, IC 95% 0,642,20). A análise de subgrupo de mulheres coinfectadas com HIV (n=503, 35,4%) mostrou redução de 60% de transmissão do vírus da hepatite C quanto submetidas à operação cesariana (OR= 0,46, IC 95% 0,230,80) (qualidade de evidência 3). Não foi relatado uso de terapia antirretroviral nessas mulheres (64).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Quanto ao modo de nascimento e transmissão vertical de hepatite C, não existem ECR mas apenas estudos observacionais retrospectivos de qualidade moderada.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Considerando os poucos estudos a respeito da prevenção da transmissão vertical do vírus da hepatite C, não se pode recomendar a operação cesariana para todas as gestantes com hepatite C. No entanto, quando há coinfecção com HIV a cesariana programada é a melhor opção de modo de nascimento.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **31) A operação cesariana não é recomendada como forma de prevenção da transmissão vertical em gestantes com infecção por vírus da hepatite C.**  
- **32) A operação cesariana programada é recomendada para prevenir a transmissão vertical do HIV e Hepatite C em mulheres com esta coinfecção.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Vírus Herpes simples (HSV)** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com infecção primária ativa pelo vírus Herpes simples (HSV) durante o terceiro trimestre da gestação?_  
_A operação cesariana deve ser oferecida a mulheres com infecção ativa recorrente pelo vírus Herpes simples?_  
A infecção neonatal do HSV-2 está associada com morbidade grave ealta taxa de mortalidade, podendo ocorrer transmissão através do canal de parto durante o nascimento (65). Poucas séries de casos apoiam as evidências sobre transmissão vertical do HSV-2; no entanto, a alta mortalidade justifica as recomendações. Um estudo avaliou 101 gestantes que tiveram infecção herpética genital (primária ou recorrente) durante o terceiro trimestre de gestação. O risco de herpes neonatal foi maior nas que tiveram infecção primária (três casos de herpes neonatal em nove expostos) (66). Em estudo com 15.923 mulheres em início de trabalho de parto, 56 delas relataram infecção por HSV e 18 (35%) apresentavam infecção primária no momento do parto. Seis recém-nascidos (33%) cujas mães tinham infecção primária por ocasião do parto desenvolveram herpes neonatal (67) (qualidade de evidência 3). Nenhum estudo permitiu avaliar a associação entre o modo de nascimento e transmissão do vírus Herpes. Três ECR avaliaram o uso de aciclovir oral para prevenção de infecção herpética recorrente no parto em gestantes com 36semanas. Os estudos evidenciaram redução de operação cesariana devida a herpes genital, porém não conseguiram evidenciar benefício do aciclovir na redução de transmissão vertical do vírus (68-70) (qualidade de evidência 1b).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os estudos encontrados relacionando vírus Herpes na gestação e herpes neonatal são de casuística pequena e baixa qualidade. ECR de boa qualidade não evidenciaram redução de transmissão vertical do vírus Herpes com uso de aciclovir.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Apesar de os estudos serem de baixa qualidade, acredita-se haver plausibilidade biológica para que se considere a operação cesariana como capaz de contribuir para a redução da transmissão vertical do vírus Herpes em gestantes com infecção primária ativa no último trimestre da gestação. Acredita-se que a mesma consideração seja válida para mulheres com infecção herpética ativa (primária ou secundária) no momento do parto. O aciclovir não traz benefício na redução de transmissão vertical do vírus Herpes, seja na infecção primária ou recorrente, e não deve ser utilizado.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **33) A operação cesariana é recomendada caso de em mulheres que tenham apresentado infecção primária do vírus Herpes simples durante o terceiro trimestre da gestação.**  
- **34) A operação cesariana é recomendada em caso de mulheres com infecção ativa (primária ou recorrente) do vírus Herpes simples no momento do parto.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Obesidade** -->
_Na ausência de outras indicações, a operação cesariana deve ser oferecida para gestantes obesas? Existe algum valor de índice de massa corporal a partir do qual a operação cesariana deva ser oferecida?_  
A obesidade é uma morbidade crônica que está associada com maior necessidade de cuidados às gestantes obesas durante o pré-natal e parto, maior risco de complicações maternas e neonatais além de maior risco de operação cesariana. Uma coorte com 591 gestantes obesas extremas, ou seja, com Índice de Massa Corpórea (IMC) acima de 50kg/m<sup>2</sup> , comparou cesariana programada e parto vaginal planejado. Foram incluídas nulíparas e multíparas, com operação cesariana prévia e complicações gestacionais como diabetes e pré-eclâmpsia, e após ajuste de covariáveis não se evidenciou diferença nas complicações anestésicas, pós-natais e neonatais, exceto distocia de ombro que foi maior naquelas que tiveram partos normais (3% vs 0%, p=0,0019) (qualidade de evidência 2b). Contudo, as evidências não apoiam a indicação de cesariana para obesas extremas, decisão que deve ser individualizada(22).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
O principal estudo que analisou o modo de nascimento e obesidade é de boa qualidade e mostra que nem mesmo nos casos de obesidade extrema a operação cesariana traz melhores desfechos que o parto vaginal.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
A gestação de mulheres com IMC > 50kg/m<sup>2</sup> habitualmente está associada com outras morbidades, como hipertensão e diabetes, além de um maior risco de complicações cirúrgicas. Com base  
em estudos populacionais, considera-se que não há benefícios da operação cesariana em nenhum grau de obesidade, inclusive nas obesas extremas (IMC>50kg/m<sup>2</sup> ). A cesariana não deve ser considerada como o modo preferencial de nascimento para fetos de gestantes obesas, devendo sua indicação ser individualizada, dependendo das comorbidades associadas apresentadas pela gestante.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
**35) A operação cesariana não é recomendada como forma rotineira de nascimento de fetos de mulheres obesas.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Profilaxia de infecção em operação cesariana** -->
_Quais intervenções devem ser realizadas para reduzir a ocorrência de infecção em caso de operação cesariana?_  
Infecção pós-parto é uma relevante causa de morbidade materna e pode prolongar o tempo de internação hospitalar relacionada ao parto. Seis ECR (n=2.566) avaliaram o modo de nascimento e infecção pós-parto. A incidência de infecção em operação cesariana foi 6,4% comparado a 4,9% em parto vaginal. O maior ECR sugere o uso de antibiótico profilático durante a cesariana (71). Duas coortes conduzidas em Israel (n=75.947) (72) e nos Estados Unidos (n=33.251) (73) avaliaram o risco de infecção e tipo de parto. A primeira coorte evidenciou uma incidência de 2,6% de infecção puerperal em mulheres submetidas à operação cesariana comparada a 0,2% naquelas cujos partos foram vaginais (RR= 14,97 IC 95% 11,96-18,74) (72). No outro estudo, o risco de infecção puerperal também foi maior nas mulheres que se submeteram à cesariana (7,9%) comparadas àquelas que tiveram parto vaginal (1,8%) (RR=4,51 IC 95% 4,00-5,09) (73) (qualidade de evidência 1a).  
Uma revisão sistemática incluiu81 ECR (n=11.957) para analisar o benefício da profilaxia com antibióticos durante a operação cesariana. O uso dessa profilaxia reduziu a incidência de febre puerperal (RR=0,45 IC 95% 0,39-0,52), endometrite (RR=0,39 IC 95% 0,34-0,43), infecção do sítio operatório (RR=0,41 IC 95% 0,35-0,48), infecção urinária (RR=0,54 IC 95% 0,46-0,64) e infecção grave (RR=0,42 IC 95% 0,28-0,65)(74). Para avaliar a eficácia de diferentes esquemas de antibioticoprofilaxia, uma revisão  
sistemática incluiu cinco ECR, concluindo que tanto a ampicilina quanto as cefalosporinas de primeira geração apresentam a mesma eficácia em reduzir endometrite pós-operatória. Não foi evidenciado benefício no uso de antibióticos de maior espectro ou múltiplas doses (75) (qualidade de evidência 1a).  
Revisão sistemática contendo cinco ECR avaliou o risco de endometrite de acordo com o método de remoção da placenta durante a operação cesariana. A remoção manual da placenta durante esse procedimento cirúrgico aumentou o risco de endometrite comparativamente à remoção assistida por tração controlada do cordão  (RR=1,54 IC 95% 1,23-1,92) (76) (qualidade de evidência 1a). Quatro estudos compararam a necessidade ou não de sutura do tecido subcutâneo e o risco de infecção pós-cesariana. Não foi encontrada diferença significativa na sutura do tecido subcutâneo. No entanto, em uma metaanálise de dois ECR (n=75 e n=91) que incluíram mulheres com mais de 2cm de tecido subcutâneo, a sutura desse tecido reduziu o risco de infecção de sítio cirúrgico (RR= 0,42 IC 95% 0,22-0,81) (77, 78) (qualidade de evidência 1a).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os estudos analisados relacionando infecção, profilaxia de infecção e antibiótico profilaxia associados à operação cesariana são de boa qualidade, mas, como os esquemas de antibióticos utilizados foram diferentes, não foi possível determinar qual esquema específico para profilaxia de infecção em operação cesariana. ECR de boa qualidade avaliaram remoção placentária e necessidade de sutura do tecido subcutâneo.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Os estudos de profilaxia de infecção em operação cesariana foram realizados em diversos países (Estados Unidos, Turquia e Irã, entre outros), utilizando grandes amostras, e demonstraram boa validade externa com poder de generalização. As cefalosporinas de primeira geração parecem uma opção custoefetiva para a profilaxia antibiótica. Alguns estudos associaram aparecimento de enterocolite necrosante dos recém-nascidos à exposição de amoxicilina-clavulanato. Assim, não se considera amoxicilinaclavulanato indicado na profilaxia de infecção em operação cesariana.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **36) É recomendado oferecer antibioticoprofilaxia antes da incisão na pele na intenção de reduzir infecção materna.**  
- **37) A escolha do antibiótico para reduzir infecção pós-operatória deve considerar fármacos efetivos para endometrite, infecção urinária e infecção de sítio cirúrgico.**  
- **38) Durante a operação cesariana, é recomendada a remoção da placenta por tração controlada do cordão e não por remoção manual, para reduzir o risco de endometrite.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Assistência à mulher com operação cesariana prévia** -->
Com o crescente número de mulheres submetidas a uma operação cesariana primária nas últimas décadas, cresce proporcionalmente o número de gestantes com cesariana(s) prévia(s), sendo o modo de nascimento neste contexto motivo de pesquisa e discussão. Com base nas evidências avaliadas, este capítulo visa a nortear o aconselhamento de gestantes com cesariana(s) prévia(s).  
_A operação cesariana deve ser oferecida de rotina para mulheres com uma cesariana prévia? A operação cesariana deve ser oferecida de rotina para mulheres com duas ou mais cesarianas prévias?_  
_As mulheres com duas ou mais cesarianas prévias podem ter um parto vaginal subsequente?_  
_A operação cesariana deve ser realizada em mulheres com uma ou mais operações cesarianas prévias e que solicitem nova operação cesariana?_  
_Como proceder caso uma mulher com operação cesariana prévia solicite uma nova cesariana?_  
_Existe um número máximo de operações cesarianas prévias que seja compatível com parto vaginal seguro?_

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Riscos e benefícios de uma operação cesariana programada comparada ao trabalho de parto planejado em mulheres com cesariana prévia** -->
A morte materna de mulheres com operação cesariana prévia é um evento raro. No entanto, o risco de ruptura uterina é maior naquelas mulheres com operação cesariana prévia que entraram mas não progrediram no trabalho de parto e evoluíram para a necessidade de uma nova cesariana (risco de 0,2%-0,8% em mulheres com uma operação cesariana prévia) (qualidade de evidência LE2)(79). Em  
mulheres com operação cesariana anterior, a taxa de mortalidade materna é maior nas gestantes submetidas a uma nova cesariana programada quando comparadas àquelas que tiveram parto vaginal planejado (RR= 3,94, IC 95% 1,20-12,5)(44). Quanto à necessidade de hemotransfusão (RR= 0,76, IC 95% 0,67-0,85) e ruptura uterina (RR= 0,03, IC 95% 0,011-0,082), o risco foi menor nas gestantes submetidas a uma nova operação cesariana(44). Dois estudos observacionais estudaram mulheres com cesariana prévia que tentaram parto vaginal e observaram uma taxa de sucesso de 74%-80% (80) em um estudo e 72%-76% no outro estudo (81).  
Comparando as mulheres com uma operação cesariana prévia que tiveram parto vaginal planejado e operação cesariana programada, independente da idade gestacional, é baixa a taxa de ruptura uterina (RA= 5,1 casos a menos por 1.000 mulheres submetidas a nova cesariana, IC 95% 2,3-11,2) e de infecção pós-parto (RA= 14 casos a menos por 1.000 mulheres submetidas a nova cesariana). Nas mulheres submetidas a nova cesariana, o tempo de internação hospitalar é maior (diferença média de 1,37 dia a mais) e a necessidade de hemotransfusão é menor (RR=0,795 IC 95% 0,714-0,884) (44,79) (qualidade de evidência LE2). Não houve diferença significativa nas taxas de histerectomia, necessidade de hemotransfusão, febre puerperal, lesão vesical e trauma cirúrgico em mulheres que tiveram parto vaginal após duas ou mais operações cesarianas prévias quando comparadas com aquelas que tiveram apenas uma operação cesariana(80,81). Uma ou duas operações cesarianas prévias são situações que possibilitam o trabalho de parto e parto vaginal, porém há risco maior de ruptura uterina e necessidade de hemotransfusão(79). A revisão sistemática do CNGOF incluiu os mesmos estudos encontrados na do NICE, entre outros, mostrando resultados semelhantes quanto a risco de mortalidade materna, ruptura uterina e morbidade materna febril.  
Dekker et al. (2010) quantificaram o risco de ruptura uterina em gestantes com uma operação cesariana prévia (n = 29.008) baseados em dados de 1998-2000. A taxa global de parto vaginal após operação cesariana foi de 54%. Houve 48 casos de ruptura uterina confirmados. Destes, 37 foram rupturas completas. Nesse estudo, as mulheres com operação cesariana prévia em trabalho de parto espontâneo (sem condução ou indução) foram comparadas com mulheres divididas nos seguintes grupos: 1) cesariana sem trabalho de parto; 2) trabalho de parto espontâneo com condução de ocitocina; 3) indução do parto com apenas ocitocina; 4) indução apenas com prostaglandina; 5) indução tanto com ocitocina e prostaglandina; e 6) outras formas de indução. Quando comparados todos os subgrupos ao grupo de  
gestantes com cesariana prévia que tiveram trabalho de parto espontâneo (sem condução ou indução), o grupo de mulheres que teve cesariana sem trabalho de parto (cesariana programada) teve o menor risco de ruptura uterina (OR = 0,11, 95% IC 0,04-0,34) e ruptura uterina completa (OR ajustado = 0,04, 95% IC0,01-0,30). O risco de ruptura uterina foi 3 a 5 vezes maior quando o trabalho de parto foi induzido, por qualquer meio(82).  
As complicações neonatais em caso de mulheres com operação cesariana prévia que entraram em trabalho de parto e evoluíram para cesariana intraparto são maiores quando comparadas com aquelas que preferiram cesariana programada. Contudo, a prevalência dessas complicações é muito baixa. O risco de mortalidade perinatal para quem tentou parto vaginal e evoluiu para cesariana é de 2,9/1.000 nascidos vivos comparativamente a 1,8/1000 nascidos vivos no caso daquelas mulheres que se submeteram a novas cesarianas programadas, enquanto o risco absoluto neonatal é de 1,1/1.000 e 0,6/1.000 nascidos vivos, respectivamente. Necessidade de intubação por aspiração de líquido meconial foi maior naquelas que se submeteram a operação cesariana após tentar parto vaginal, enquanto houve mais taquipneia transitória nos recém-nascidos de cesariana programada (83) (qualidade de evidência LE2). Houve menos hipóxia isquêmica neonatal e mais admissões em UTI nos recém-nascidos de operação cesariana, em gestantes com cesariana prévia comparativamente com aquelas que tiveram parto vaginal(44).  
Um estudo de coorte prospectiva, com mulheres de 37 semanas de idade gestacional e uma cesariana prévia, teve randomização parcial durante o seguimento (n= 2.345, das quais 22 mulheres aceitaram ser randomizadas, 10 para cesariana e 12 para tentar parto vaginal): 1.098 preferiram nova cesariana e 1.225 tentaram parto vaginal. A taxa de parto vaginal foi de 43,2%, e o desfecho primário foi relacionado às repercussões neonatais. O risco de mortalidade perinatal ou morbidade grave foi significativamente menor para os recém-nascidos no grupo de operação cesariana programada em comparação com o grupo de parto vaginal planejado (0,9% versus 2,4%; RR= 0,39; IC 95% 0,19-0,80). Com relação ao desfecho materno, observaram-se menos hemorragia grave no grupo que teve nova cesariana [perda de sangue ≥1.500 ml ou transfusão de sangue - 0,8% (9/1.108)] _versus_ 2,3% (29/1.237); RR 0,37 ; 95% IC 0,17-0,80)(84).  
Outra coorte retrospectiva de 2000-2005 que classificou as mulheres de acordo com a classificação de Robson (n=21.389, com 2.092 mulheres com cesariana prévia, gestação única, apresentação cefálica a termo – categoria 5) mostrou taxa de parto vaginal de 20,2%. Ao longo dos anos do estudo, a taxa de  
parto vaginal após uma cesariana prévia variou de 28,3% a 40,7%. Hemorragia pós-parto no grupo de mulheres que teve parto vaginal com cesariana prévia foi significativamente maior em comparação com aquelas sem cesariana prévia (categorias 1 a 4 da classificação de Robson–mulheres primíparas ou multíparas, com apresentação cefálica a termo e sem cesariana prévia) (16% _versus_ 11%, p = 0,02). Para as mulheres que tiveram um parto vaginal instrumental com cesariana prévia não houve diferença significativa comparativamente às mulheres pertencentes às categorias 1-4 da classificação de Robson (30% _versus_ 29%, p = 0,84,) (85). Admissões em unidade de terapia intensiva neonatal ou berçário de cuidados especiais não tiveram diferença significativa para grupos Robson 1-4 em comparação com o grupo Robson 5 para partos vaginais (Robson 1-4 = 4% _versus_ Robson 5 = 4%,) ou partos vaginais instrumentais (Robson 1-4 = 8% _versus_ Robson 5 = 9%; p = 0,72) (85). Houve apenas cinco casos de ruptura uterina ou deiscência, sendo quatro deles no grupo de operação cesariana prévia, não sendo possível fazer análise estatística segundo os autores.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Condições que influenciam na decisão do tipo de parto em mulheres com cesariana prévia** -->
História de parto vaginal prévio (especialmente se ele ocorreu após uma cesariana prévia) e condições favoráveis do colo uterino (avaliado ou não através do escore de Bishop) são condições que estão fortemente relacionadas a um parto vaginal após operação cesariana prévia. (86) (qualidade de evidência LE2).  
Existem algumas situações que reduzem a taxa de sucesso para um parto vaginal após operação cesariana prévia: falha de progressão do trabalho de parto, parada secundária da descida, história de duas operações cesarianas (apesar de a taxa de parto vaginal após duas cesarianas ser de 70%), idade materna maior que 40 anos, IMC maior que 30Kg/m<sup>2</sup> , idade gestacional maior que 41 semanas e recém-nascido com mais de 4.000g. Além disso, a necessidade de indução de trabalho de parto diminui a taxa de parto vaginal em mulheres com cesariana prévia(86) (qualidade de evidência LE3).  
Condições maternas como diabete, obesidade, idade materna e multiparidade podem reduzir as taxas de parto vaginal em gestantes com operação cesariana prévia, no entanto não contraindicam o parto vaginal. A taxa de parto vaginal após cesariana antes de 37 semanas até o termo é semelhante, e o risco de ruptura uterina é baixo (87). As repercussões neonatais são semelhantes comparando parto vaginal planejado e operação cesariana programada em gestantes com cesariana prévia com menos de  
37 semanas (88). Em mulheres com cesariana prévia, o risco de ruptura uterina aumenta quando o intervalo entre os partos diminui (87), porém não contraindica o parto vaginal subsequente se as condições obstétricas forem favoráveis.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
A revisão sistemática do CNGOF, assim como a do NICE, incluíram grandes estudos observacionais que avaliaram as repercussões de um parto vaginal comparado à operação cesariana programada em gestantes com cesariana prévia. Os estudos incluídos têm qualidade de evidência moderada a baixa. Os dados neonatais não foram incluídos na revisão sistemática do NICE, e a qualidade de evidência dos estudos com desfechos neonatais utilizados tanto do NICE quanto do CNGOF é muito baixa.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
O aconselhamento sobre o modo de nascimento em gestantes com operação cesariana prévia deve considerar: a) as preferências e prioridades da mulher; b) os riscos e benefícios de uma nova cesariana; e c) os riscos e benefícios de um parto vaginal após uma cesariana, incluindo o risco de uma cesariana não planejada (de urgência). É importante informar às mulheres com três ou mais cesarianas prévias que o risco de infecção, lesão vesical e traumatismo cirúrgico não varia no parto vaginal, porém existe maior risco de ruptura uterina neste tipo de parto. A ruptura uterina é uma situação grave, com risco de óbito fetal e materno, requerendo intervenção cirúrgica imediata. Esse risco deve ser pesado contra os riscos de lesão vesical, hemorragia e histerectomia, entre outras morbidades, que aumentam quando se aumenta o número de cesarianas.  
Os riscos de um parto vaginal após operação cesariana em geral são baixos, com uma boa taxa de sucesso para o parto vaginal. Deve ser informado à gestante com cesariana prévia e história de um parto vaginal que existe uma maior chance de evoluir para um parto vaginal do que aquelas que não tiveram um parto vaginal prévio.  
Nas diretrizes inglesas (NICE), não há recomendação específica sobre o número total de cesarianas prévias compatíveis com uma prova de trabalho de parto, enquanto o Colégio Francês de Ginecologia e Obstetrícia (CNGOF) recomenda operação cesariana para mulheres com três ou mais cesarianas prévias. Na verdade, as mulheres com três ou mais cesarianas prévias são relativamente raras em nosso meio,  
uma vez que, no Brasil, é comumente realizada a ligadura tubária por ocasião da terceira cesariana. A opção por um parto vaginal nesses casos terá pouco impacto sobre a taxa global de cesarianas.  
Todavia, o risco aumentado de ruptura uterina quando se realiza uma prova de trabalho de parto deve ser pesado contra o risco aumentado de hemorragia, histerectomia, lesão vesical e de alças intestinais quando se repete uma operação cesariana depois de múltiplas cesarianas. Desta forma, sugere-se que as mulheres sejam devidamente esclarecidas sobre o risco de ruptura uterina (em torno de 1%) e suas consequências (inclusive histerectomia, morte fetal e encefalopatia hipóxico-isquêmica) e os riscos de uma nova operação cesariana e que a decisão em relação ao modo de nascimento considere o desejo e a autonomia feminina, obtendo-se um termo de consentimento informado.  
Entende-se que o limite de quando tornar a nova operação cesariana mandatória em relação ao número de cesarianas prévias foi determinado de forma parcialmente arbitrária pelo grupo elaborador das diretrizes francesas. As diretrizes do grupo NICE são menos prescritivas em relação a isso. Outros grupos, como o ACOG e mesmo a prática brasileira, tendem a ser mais restritivos em relação à possibilidade de parto vaginal após duas cesarianas prévias. Essa é uma questão de ponderação de riscos (particularmente relacionados à ruptura uterina). Assim, considera-se mais apropriada a individualização da decisão sobre o modo de nascimento nos casos de mulheres com duas cesarianas prévias e mais adequada a operação cesariana nos de mulheres com três cesarianas prévias.  
A investigação de acretismo placentário em gestantes com duas operações cesarianas prévias é pertinente, para mulheres que forem tentar um parto vaginal. Apesar de raros, nos casos de cesarianas cuja incisão uterina tenha sido longitudinal, aconselha-se o registro do fato no prontuário, pois essa condição contraindica uma tentativa de parto vaginal subsequente. Sugere-se a obtenção de um termo de consentimento informado quer para um parto vaginal quer para uma operação cesariana programada na presença de uma ou mais cicatrizes de cesárea anterior.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **39) É recomendado um aconselhamento sobre o modo de nascimento em gestantes com operação cesariana prévia que considere: as preferências e prioridades da mulher, os riscos e benefícios de uma nova operação cesariana e os riscos e benefícios de um parto vaginal após uma cesariana, incluindo o risco de uma operação cesariana não planejada.**  
- **40) É recomendado que as mulheres com operações cesarianas prévias sejam esclarecidas de que há um aumento no risco de ruptura uterina com o parto vaginal após cesariana prévia. Este risco é, a princípio, baixo, porém aumenta à medida que aumenta o número de cesarianas prévias.**  
- **41) Na ausência de outras contraindicações, é recomendado encorajar as mulheres com uma cesariana prévia a tentativa de parto vaginal, mediante termo de consentimento informado.**  
- **42) É recomendado que a conduta em relação ao modo de nascimento em mulheres com duas operações cesarianas prévias seja individualizada, considerando os riscos e benefícios de uma nova cesariana e os riscos e benefícios de um parto vaginal após duas cesarianas, incluindo o risco aumentado de ruptura uterina e de operação cesariana adicional não planejada, e as preferências e prioridades da mulher, mediante termo de consentimento informado.**  
- **43) Durante a assistência pré-natal, as mulheres devem ser informadas sobre as instituições e profissionais que assistem o parto vaginal após duas operações cesarianas.**  
- **44) Os profissionais e instituições de saúde devem ter resguardada sua autonomia em relação a aceitação ou não da assistência ao parto vaginal após duas operações cesarianas.**  
- **45) A operação cesariana é recomendada em mulheres com três ou mais cesarianas prévias.**  
- **46) O trabalho de parto e parto vaginal não são recomendados para mulheres com cicatriz uterina longitudinal de operação cesariana anterior.**  
_A avaliação ultrassonográfica da cicatriz uterina pós-operação cesariana segmentar é útil para informar a decisão sobre a via de parto em mulheres com uma ou mais operações cesarianas prévias? Deve-se oferecer às mulheres com operação cesariana prévia a realização de algum exame subsidiário antes da definição da via de parto?_  
A avaliação da cicatriz uterina por ultrassonografia utiliza técnicas de medição transvaginal ou abdominal, podendo ser estudada a espessura do “segmento inferior do útero” após 36 semanas e com a bexiga repleta. A mais recente revisão sistemática sobre risco de ruptura ou deiscência uterina em mulheres com operação cesariana prévia procurou encontrar um limiar ótimo para predição desse risco. Analisando a espessura do segmento entre2,0 e 3,5 mm (estudos robustos incluindo 1.834 mulheres, com 121 rupturas ou deiscências uterinas detectadas), não foi encontrada utilidade clínica da ultrassonografia para avaliação de cicatriz uterina nem foi possível determinar um ponto de corte da espessura miometrial para o risco de ruptura uterina(89) (qualidade de evidência LE2).  
Apesar de o peso do recém-nascido maior que 4.000g diminuir a taxa de sucesso de um parto vaginal após operação cesariana, a avaliação ultrassonográfica para estimar o peso fetal é muito imprecisa. A taxa de falso-positivo para peso fetal maior que 4.000g é de aproximadamente 50%. A  
pelvimetria radiológica está associada a aumento na taxa de operação cesariana programada sem reduzir o risco de ruptura uterina, portanto o método não é necessário para definir o modo de nascimento em gestantes com operação cesariana prévia (86) (qualidade de evidência LE2).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os estudos encontrados na revisão sistemática têm qualidade moderada a baixa.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Como a taxa de falso-positivo do exame ultrassonográfico é alta e não há evidência do benefício da pelvimetria para mulheres com operação cesariana prévia, esses exames não devem ser solicitados para prever falha de progressão do trabalho de parto. Entretanto, uma altura uterina elevada (40cm ou mais) associada à estimativa de peso por ultrassonografia acima de 4.000g é altamente sugestiva de feto macrossômico, e a tentativa de parto vaginal após operação cesariana pode ser não recomendada. Também não há evidência do benefício da ultrassonografia na predição de ruptura uterina com a medição do “segmento inferior do útero”. História de parto vaginal prévio, escore de Bishop favorável ou cérvice considerada favorável à admissão na sala de parto, além de trabalho de parto espontâneo, são condições que podem auxiliar na tomada de decisão quanto ao modo de nascimento em mulheres com operação cesariana prévia (86) (qualidade de evidência LE2).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **47) A avaliação ultrassonográfica da cicatriz uterina pós-operação cesariana segmentar e pelvimetria não são recomendadas como rotina em mulheres com uma ou mais operações cesarianas prévias.**  
_O intervalo entre partos é útil para informar a decisão sobre a via de parto em mulheres com uma ou mais operações cesarianas prévias?_  
Revisão sistemática do CNGOF incluindo cinco coortes retrospectivas avaliou o risco de ruptura uterina associado com um curto intervalo entre as gestações de mulheres com operação cesariana prévia (90-94)(qualidade de evidência LE3). Shipp (2001) observou que intervalos entre partos de até 18 meses após uma operação cesariana estiveram associados com um risco aumentado de ruptura uterina  
sintomática(90). Este autor encontrou um risco de 2,3% no intervalo entre partos inferior a 19 meses _versus_ 1,1% nos anos seguintes (OR= 3,0 IC 95% 1,2-7,2)(90). Huang (2002) observou que mulheres com intervalos entre partos menores que 19 meses tiveram uma menor taxa de parto vaginal(91). Bujold (2010), em um estudo com 188 mulheres, observou uma taxa de ruptura uterina de 5% quando o período intergestacional foi inferior ou igual a 9 meses, de 1,9% entre 9 a 15 meses e de 1,1% com mais de 15 meses(92). Em 2002, Bujold havia observado que mulheres com intervalos entre partos inferiores a 24mesesapresentavam um aumento de 2-3 vezes no risco de ruptura uterina(93).  Stamilio (2007), em uma coorte multicêntrica com 25.005 mulheres, incluindo 128 casos de ruptura uterina, as mulheres com intervalo intergestacional inferior a 6 meses apresentaram taxa de ruptura de 2,2%, enquanto aquelas com mais de 6 meses entre as gestações apresentaram taxa de ruptura uterina de 0,9%,(95).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os estudos encontrados na revisão sistemática têm qualidade moderada a baixa.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
O risco de ruptura uterina parece aumentar com a redução do intervalo entre os partos. Se do ponto de vista individual o risco de complicações graves pode ser considerado relativamente baixo, esse pode não ser o caso quando se considera a questão do ponto de vista populacional. Monitorização fetal intermitente, uma equipe treinada capaz de detectar a iminência de ruptura uterina e acesso imediato à operação cesariana na suspeita de ruptura uterina são condições que minimizam o risco independentemente do intervalo entre os partos.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
**48) Em mulheres com operação cesariana prévia e intervalo entre partos inferior a 15 meses (ou intergestacional inferior a seis meses), é recomendado individualizar a conduta relativa ao modo de nascimento.**  
_Qual deve ser o profissional preferencial para assistência ao trabalho de parto e parto de gestantes com uma operação cesariana prévia?_  
_Qual o local onde se deve assistir o trabalho de parto e parto de uma gestante com uma operação cesariana prévia?_  
_Existe algum cuidado adicional ou peculiaridade na assistência ao trabalho de parto e parto de mulheres com uma operação cesariana prévia?_  
As complicações relacionadas à assistência ao parto vaginal em caso de mulheres com operação cesariana prévia requerem equipe cirúrgica integrada por médico obstetra e anestesista preparados para realizar cesariana de emergência. Gestantes com placenta anterior, no local da cicatriz da cesariana, com risco de placenta de inserção baixa e suspeita de acretismo placentário devem ser assistidas em ambiente hospitalar capaz de oferecer suporte intensivo e com disponibilidade de classificação sanguínea, hematimetria e, caso necessário, uso de hemocomponentes(96).  
O trabalho de parto deve ser seguido, preferencialmente, pelo mesmo obstetra (exceto em casos de indisponibilidade ou troca de plantão). Todos os membros da equipe (enfermeiros(as), obstetrizes, obstetra e anestesista) devem estar alertas para os sinais de ruptura uterina. Durante o trabalho de parto de mulheres com operações cesarianas prévias, é recomendada a monitorização materno-fetal intermitente e condições de acesso imediato à cesariana, caso necessário. Deve ser aconselhado intervalo de um ano antes de nova gravidez (96).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os estudos incluídos na revisão do CNGOF para estabelecer local de parto e cuidados relacionados às mulheres com operação cesariana prévia são de muito baixa qualidade.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
As diretrizes francesas basearam o aconselhamento e os cuidados de gestantes com operação cesariana prévia na opinião de especialistas. Entende-se que é importante a monitorização fetal intermitente e que o acesso imediato à cesariana deve estar garantido na suspeita de ruptura uterina, com obstetra, anestesista e pediatra presentes para a assistência ao parto. Dependendo da situação obstétrica, informações adicionais devem ser fornecidas à gestante, especialmente se o parto for  
induzido. Sugere-se a obtenção de um termo de consentimento informado quer para um parto vaginal quer para uma operação cesariana programada na presença de uma ou mais cicatrizes de cesárea anterior.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação** -->
**49) Para as gestantes que desejam um parto vaginal (espontâneo ou induzido) após operação cesariana é recomendada a monitorização materno-fetal intermitente e assistência que possibilite acesso imediato à cesariana.**  
_Em mulheres com operação cesariana prévia, qual deve ser a técnica preferencial para indução do trabalho de parto?_  
Seis estudos observacionais avaliaram os riscos do parto vaginal em mulheres com operação cesariana prévia. O maior estudo incluiu 35.854 mulheres na Escócia, de 1985-98, com uma cesariana prévia que desejavam parto vaginal ou estavam com mais de 41 semanas de gestação. A taxa de parto vaginal foi de 74,2% e de 0,35% a de ruptura uterina. O risco de ruptura uterina foi maior naquelas sem parto vaginal prévio (OR ajustado=2,5 IC 95% 1,6-3,9) e submetidas à indução com prostaglandina (PGE2) (OR=2,9, IC 95% 2,0-4,3) (97). Um estudo multicêntrico prospectivo americano evidenciou que o parto vaginal era menos provável em mulheres submetidas à indução tanto naquelas com cesariana quanto nas sem cesariana prévia (65% _versus_ 51%, respectivamente) (98). A indução aumenta moderadamente o risco de operação cesariana não planejada e aumenta em duas vezes o risco de ruptura uterina quando comparada com o trabalho de parto espontâneo (99) (qualidade de evidência LE2). A indução com ocitocina está associada com risco mínimo a moderado de ruptura uterina comparativamente ao parto espontâneo (99) (qualidade de evidência LE2).  
Apenas um estudo avaliou o uso de misoprostol comparado com o de ocitocina em mulheres com operação cesariana prévia e foi interrompido prematuramente após a inclusão de 38 mulheres devido a preocupações com a sua segurança. Dezessete mulheres tinham sido incluídas no grupo que recebeu misoprostol e 21 mulheres, no grupo de ocitocina. Não houve diferença significativa nos resultados preliminares, porém ocorreram dois casos de ruptura uterina no grupo do misoprostol, o que não ocorreu no grupo da ocitocina (um estudo; 38 mulheres; RR=6,11, 95% CI 0,31-119,33)(100).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Não foi encontrado nenhum ECR de boa qualidade para determinar qual a melhor forma de indução em mulheres com operação cesariana prévia. Os estudos observacionais são de qualidade moderada. Inexistem dados suficientes para avaliar o risco de ruptura uterina e indução mecânica com balão no colo uterino.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
A indução do parto em gestantes com operação cesariana prévia aumenta moderadamente o risco de ruptura uterina durante o trabalho de parto comparada ao trabalho de parto espontâneo. A indução eletiva deve ser evitada (LE4)(13), devendo ser considerada somente com indicações médicas específicas.  
Nos casos de indução, uma história de parto vaginal prévio e exame cervical favorável são importantes fatores para influenciar na decisão de indução. As diretrizes francesas não recomendam indução do parto na presença de duas ou mais cicatrizes de operação cesariana, porém não há menção a essa restrição nas diretrizes do NICE.  
O uso de ocitocina está associado a risco mínimo a moderado de ruptura uterina, mas a ocitocina pode ser utilizada com cautela, se necessário. O trabalho de parto espontâneo com o mínimo de intervenções possível é ideal em gestantes com operação cesariana prévia. O NICE e o CNGOF também mencionam, de forma geral, que o uso de balão no colo uterino (método mecânico de indução) pode ser indicado em gestantes com operação cesariana prévia, iniciando o processo de indução naquelas mulheres com Bishop desfavorável e que desejam um parto vaginal. Nas duas diretrizes (NICE e CNGOF), o uso de misoprostol em gestantes com operação cesariana prévia não é recomendado por aumentar muito o risco de ruptura uterina.  Devido ao reduzido número de evidências sobre o assunto, sugere-se que o uso cauteloso de balão cervical ou ocitocina na indução dessas mulheres é viável para a realidade brasileira nas mulheres com indicação médica de indução do parto. Obstetras e anestesistas deverão estar sempre presentes no local de assistência ao parto.  
Dependendo situação obstétrica, informações adicionais devem ser fornecidas à paciente, especialmente se o parto for induzido, obtendo-se o termo de consentimento informado.  
**Recomendação:**  
- **50) Em mulheres com operação cesariana prévia e indicação para indução de trabalho de parto, é recomendado o uso de balão cervical ou ocitocina.**  
- 51) **O uso de misoprostol para indução do parto em mulheres com cicatriz de operação cesariana prévia, independentemente do número de cesarianas, não é recomendado.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **CAPÍTULO 4 – CUIDADO DO RECÉM-NASCIDO (PECULIARIDADES DA OPERAÇÃO CESARIANA)** -->
A taxa de mortalidade neonatal no Brasil é de 9,2 por mil nascidos vivos.  Segundo os dados do NICE, não há relação direta entre as taxas de parto cesariano e resultados neonatais. As taxas de mortalidade perinatal podem diminuir na presença de uma taxa baixa de operação cesariana ou permanecer estáveis enquanto os partos cesarianos aumentam (nível de evidência 4) (101,102). Um estudo de coorte (n = 11.702) não demonstrou diferença na mortalidade neonatal entre o nascimento vaginal e cesariano; no entanto o estudo não tinha capacidade suficiente (poder do estudo) para avaliar este desfecho (risco relativo de 1,09IC 95% 0,14-8,38) (nível de evidência 2) (101-103).  
Há necessidade de profissional de saúde treinado em reanimação neonatal na recepção de um recémnascido por operação cesariana?  
Em um estudo de coorte, os recém-nascidos de parto cesariano e com anestesia regional eram mais propensos a ter um índice de Apgar de primeiro minuto inferior a 4 (6,3%) quando comparados  com recém-nascidos de parto vaginal (1,3%; RR 3,04 IC 95% 1,80-5,13) (nível de evidência 2b)(104). Dois estudos descritivos citam que o parto cesariano é uma situação em que é necessária a presença de pediatra ao nascimento (nível de evidência 3) (105,106). Uma série de 460 partos mostrou que houve maior incidência de reanimação neonatal em partos cesarianos planejados quando comparados com partos vaginais. Resultados semelhantes foram encontrados em outros dois estudos (107,108). Da série de 59 partos cesarianos de urgência, 24 foram indicados por sofrimento fetal, dos quais 12 recémnascidos necessitaram de reanimação neonatal. Não houve nenhuma diferença na necessidade de reanimação entre recém-nascidos com apresentação cefálica em parto cesariano (1,8%) e parto vaginal (2,7%) sem evidência de sofrimento fetal(nível de evidência 3)(109).  Um grande estudo observacional  
nos EUA (n = 3.940) relatou que recém-nascidos por operação cesariana sob anestesia geral tiveram um risco aumentado de ter de Apgar de 1 e 5 minutos menores que 7 quando comparados com aqueles que nasceram por cesariana com anestesia regional (Apgar de primeiro minuto inferior a 7:  RR 3,13 IC 95% 2,5-3,88 e Apgar de 5 minutos: RR 3,6, IC 95% 1.,81 a 7,00) e necessidade de reanimação neonatal (RR 2,02,IC 95% 1,39-2,9) (nível de evidência 3)(110). Esses achados são compatíveis com aqueles encontrados no NSCSA(111).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Os estudos disponíveis considerados nas diretrizes do NICE são classificados com nível de evidência 2 e 3 e alguns apontam índices de Apgar mais baixos e maior necessidade de reanimação neonatal nos nascidos por operação cesariana. Os estudos apontam para a necessidade de um profissional da saúde capacitado no atendimento neonatal, em especial na cesariana sob anestesia geral ou quando há evidência de sofrimento fetal.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações do grupo elaborador** -->
De acordo com a Portaria SAS N<sup>o</sup> 371/2014, do Ministério da Saúde(112):  
- “O atendimento ao recém-nascido, no momento do nascimento em estabelecimentos de saúde que realizam partos, consiste na assistência por profissional capacitado, médico (preferencialmente pediatra ou neonatologista) ou profissional de enfermagem (preferencialmente enfermeiro obstetra ou neonatal)” (Parágrafo único do Artigo1º.)  
- “É capacitado em reanimação neonatal o médico ou profissional de enfermagem que tenha tido treinamento teórico-prático, conforme a Nota Técnica SAS/MS 16 de 2014.” (Artigo 3º.)

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **52) Quando o nascimento ocorrer por operação cesariana, é recomendada a presença de um médico pediatra adequadamente treinado em reanimação neonatal.**  
- **53) Em situações onde não é possível a presença de um médico pediatra em nascimentos por operação cesariana, é recomendada a presença de um profissional médico ou de enfermagem adequadamente treinado em reanimação neonatal.**  
_Algum cuidado especial é recomendado em termos de proteção térmica ao recém-nascido por operação cesariana?_  
_Contato pele-a-pele precoce deve ser instituído?_  
Dois estudos descritivos foram encontrados relacionando operação cesariana e hipotermia neonatal (qualidade de evidência 3). O ambiente aquecido costuma fazer parte da rotina padrão para cuidados com o recém-nascido, independentemente do modo de nascimento. Um ECR demonstrou que os pais também podem manter a conservação da temperatura corporal aquecido de recém-nascidos saudáveis (113) (qualidade de evidência 1b). Uma revisão sistemática contendo 16 ECR e 1 quaserandomizado (n=806), dois deles incluindo recém-nascidos por operação cesariana, avaliou as repercussões do contato pele-a-pele no cuidado neonatal de recém-nascidos saudáveis. De modo geral, houve maior taxa de duração da amamentação (OR=2,15, IC 95% 1,10-4,22), menos choro do RN (OR= 21,89, IC 95% 5,2 – 92,3) e maior índice de afetividade materna para aqueles recém-nascidos que tiveram contato pele-a-pele precoce (114) (qualidade de evidência 1a). Um ERC contendo mulheres submetidas à operação  cesariana mostrou que o contato pele-a-pele precoce (até 12 horas do parto) melhorou a percepção materna do recém-nascido, teve efeitos positivos no comportamento materno e melhorou o desempenho das habilidades para uma relação calorosa e afetiva entre a mãe e seu filho(“maternagem”)(115)(qualidade de evidência 1b).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Todos os estudos que avaliam o contato pele-a-pele e repercussões materno-fetais demonstraram os benefícios do contato precoce; no entanto 12 ECR têm uma qualidade metodológica baixa. Esses benefícios do contato precoce associados à relação de “maternagem” também são evidentes nas mulheres submetidas à operação cesariana.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Assegurar o contato pele-a-pele imediato e contínuo do recém-nascido saudável com sua mãe é uma das recomendações preconizadas pelo Ministério da Saúde do Brasil, para fortalecer os laços maternais e favorecer também o aquecimento do recém-nascido que tenha tendência a hipotermia. É  
importante verificar a temperatura do ambiente, que deverá está em torno de 26 graus Celsius, para evitar a perda de calor, e, de acordo com a vontade da mãe, colocar o recém-nascido sobre o seu abdômen ou tórax, de bruços, e cobri-lo com uma coberta seca e aquecida (112).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
**54) É recomendado o cuidado térmico para o recém-nascido por operação cesariana. 55) O contato pele-a-pele precoce entre a mãe e o recém-nascido deve ser assegurado e facilitado.**  
_Na operação cesariana o clampeamento de cordão deve ser precoce ou oportuno (i.e. após dois minutos do nascimento ou parada de pulsação do cordão)?_  
Uma revisão incluindo 531 recém-nascidos de nove diferentes ECR demonstrou que os benefícios do clampeamento tardio do cordão incluem diminuição da anemia, melhora da perfusão pulmonar e melhores taxas de amamentação. Policitemia, hiperviscosidade sanguínea, hiperbilirrubinemia, taquipneia transitória do recém-nascido e sensibilização em mãe Rh negativo são consequências desfavoráveis que podem ocorrer com o clampeamento tardio do cordão (116). Um ECR realizado no Reino Unido (n=554) comparou clampeamento tardio e precoce em partos vaginais e não observou diferença nos desfechos neonatais e maternos(117) (qualidade de evidência 1b). Dois estudos avaliaram a propensão à anemia e o clampeamento precoce ou tardio do cordão. O primeiro ECR (n=40) evidenciou que o clampeamento do cordão em 45 segundos reduziu a necessidade de transfusão sanguínea nas primeiras 6 semanas de vida do RN (RR= 3,33, IC 95% 1,07-10,03)119), enquanto o outro não mostrou diferença no hematócrito da criança nos dois grupos, tardio e precoce (120). Em resumo, o conjunto de evidências favorece a realização do clampeamento tardio do cordão em operações cesarianas.  
Em relação ao recém-nascido pré-termo, revisão sistemática da Cochrane, publicada em 2012, avaliou 15 estudos com 738 neonatos de idade gestacional entre 24 e 36 semanas, cujo cordão foi clampeado entre 30 e 180 segundos depois do nascimento. O clampeamento tardio de cordão resultou em diminuição do número de prematuros que receberam transfusões sanguíneas (OR 0,61; IC95% 0,460,81), que apresentaram hemorragia intracraniana (OR 0,62; IC95% 0,41-0,85) e enterocolite necrosante (OR 0,62; IC95% 0,43-0,90), porém houve elevação do nível de pico de hiperbilirrubinemia indireta (116).  
Tais achados parecem estar relacionados à elevação do volume de sangue circulante no recém-nascido, com estabilização mais rápida da pressão arterial em consequência da transfusão placentária. No entanto, os dados dessa revisão foram insuficientes para definir as evidências a respeito de óbito neonatal, hemorragia intraventricular ou parenquimatosa graus III/IV, segundo a classificação de Papilleet al., e leucomalácia periventricular(118). Deve-se ressaltar, ainda, que não existem evidências sobre os efeitos do clampeamento tardio do cordão em recém-nascidos pré-termo com a vitalidade comprometida ao nascer.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Estudos controlados randomizados e não randomizados foram incluídos em revisão para avaliar os benefícios do clampeamento tardio do cordão umbilical. A qualidade metodológica dos estudos é variável e pouco consistente, no entanto pode-se analisar os benefícios do clampeamento do cordão. Os estudos que avaliaram a propensão à anemia são de pouco poder metodológico não sendo possível avaliar outros desfechos. Mais ensaios clínicos randomizados precisam ser realizados para determinar o efeito do clampeamento tardio do cordão no acompanhamento neonatal, incluindo mães Rh negativo e nos casos de taquipneia transitória do recém-nascido.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Assim como o NICE, a Portaria SAS N<sup>o</sup> 371 do Ministério da Saúde recomenda o clampeamento tardio do cordão umbilical em  recém-nascido de termo (idade gestacional 37-41 semanas) que está respirando ou chorando, com tônus muscular em flexão, sem líquido amniótico meconial, ou seja, que apresenta boa vitalidade e não necessita de qualquer manobra de reanimação(112, 119).  Em relação ao recém-nascido pré-termo, segundo as evidências disponíveis atualmente, recomenda-se que, após a extração completa do concepto, os profissionais da saúde devem avaliar a pulsação do cordão umbilical, os movimentos respiratórios e a movimentação muscular. Se o recém-nascido pré-termo mostrar pulsação no cordão acima de 100 bpm, tiver iniciado a respiração e apresentar movimentação ativa, o clampeamento mais tardio do cordão umbilical, entre 30-60 segundos, pode ser benéfico para facilitar a transfusão placento-fetal. Caso a vitalidade do recém-nascido esteja comprometida ou existam dúvidas sobre a adequação da frequência cardíaca, a movimentação muscular e o início da respiração espontânea,  
indica-se clampear imediatamente o cordão para que o pediatra ou neonatologista avalie de forma imediata a necessidade dos procedimentos de reanimação. Como não há estudos consistentes com gestantes Rh negativo e casos de taquipneia transitória do recém-nascido, o clampeamento tardio só é recomendado em recém-nascido saudáveis, com tônus normal, função respiratória normal e na ausência de líquido meconial.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- **56) É recomendado clampeamento tardio do cordão umbilical em caso do recém-nascido a termo e pré-termo com ritmo respiratório normal, tônus normal e sem líquido meconial.**  
- **57) Nos casos de mães isoimunizadas, ou portadoras dos vírus HIV ou HTLV, o clampeamento deve ser imediato.**  
_Nos casos de operação cesariana, apoio adicional deve ser garantido a fim de que a amamentação precoce possa ser iniciada tão logo possível (isto é, imediatamente após o parto ou dentro da primeira hora pós-parto)?_  
A maioria das mulheres (70%) escolhem o tipo de nascimento que melhor favoreça a amamentação. Diversos estudos compararam aleitamento materno e tipo de parto. Três ECR mediram a taxa de amamentação, comparando operação cesariana e parto vaginal (40,71,120). De maneira geral, não houve diferença os grupos (RR= 0,94,IC 95% 0,89 –1,00) (qualidade de evidência 1a). Um estudo avaliou a taxa de amamentação após três meses do parto, comparando parto vaginal e operação cesariana programada, e não encontrou diferença significativa (cesariana = 68% _versus_ parto vaginal = 70%; RR=0,98 IC 95% 0,92-1,05)(71) (qualidade de evidência 1b). Um estudo no Reino Unido evidenciou diferença no aleitamento materno de mulheres que tiveram parto vaginal (76%) e submetidas operação cesariana (39%) (qualidade de evidência 2a). Seis estudos populacionais relevantes mostraram que as taxas de aleitamento materno inicial foram maiores no parto vaginal(121-125). Dois desses estudos que seguiram as mulheres entre 3 e 6 meses não mostraram diferença nas taxas de amamentação entre parto vaginal e operação cesariana (123,124) (qualidade de evidência 2a).

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Resumo das Evidências** -->
Estudos populacionais realizados em países como Inglaterra e China indicam que o parto vaginal está associado a maiores taxas de aleitamento materno. Alguns ECR e coortes não mostraram diferença na taxa de amamentação e duração do aleitamento comparando parto vaginal e operação cesariana.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Estimular o aleitamento materno na primeira hora de vida, exceto em casos de mães infectadas pelo HIV ou HTLV, seguindo as determinações da Portaria SAS N<sup>o</sup> 371 do Ministério da Saúde (112), é uma iniciativa que pode melhorar as taxas de aleitamento no Brasil. É importante postergar os procedimentos de rotina do recém-nascido nessa primeira hora de vida. Entende-se que a limitação de movimentos e os cuidados pós-operação cesariana podem retardar o contato da mãe com recém-nascido nas primeiras horas do parto, sendo necessário apoio no aleitamento materno até a apojadura e saída do ambiente hospitalar.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **CAPITULO 5 – LIGADURATUBÁRIA E OPERAÇÃO CESARIANA** -->
_<mark>Na ausência de outras indicações, a operação cesariana deve ser oferecida como método para a realização da ligadura tubária?</mark>_  
A esterilização definitiva voluntária no Brasil (ligadura tubária ou vasectomia) segue legislação específica encontrada no § 4º do Artigo 10 da Lei 9.263/1996 <mark>(que regula o § 7º do art. 226 da Constituição Federal)</mark> e Portaria SAS/MSNº 048/1999(126).  
A legislação vigente estabelece que a realização de esterilização definitiva somente pode ser realizada em pessoas maiores de 25 anos ou com mais de dois filhos vivos e período de 60 dias entre a manifestação da vontade e o ato cirúrgico.  
A mesma legislação prevê que a realização de ligadura tubária não pode ser realizada no momento do parto, exceto:  
- <mark>Nos casos de comprovada necessidade, por operações cesarianas sucessivas anteriores.</mark>  
- Risco de vida materno em uma futura gestação.  
- Risco de vida para um futuro concepto.  
O planejamento familiar deve ter acompanhamento por equipe multidisciplinar a fim de desencorajar a esterilização precoce e caso, a mulher mantenha relação conjugal, o cônjuge deve também consentir a realização do procedimento.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Considerações** -->
Existe legislação específica que regulamenta a realização de laqueadura tubária no Brasil. Portanto, estas Diretrizes seguem o disposto por essa legislação. De toda forma, um aconselhamento contraceptivo adequado e multidisciplinar para diminuir o número de gestações não planejadas, sendo a ligadura tubária uma opção definitiva de contracepção que não deve ser motivo direto para realização da operação cesariana. Recomenda-se que as gestantes com duas ou mais operações cesarianas prévias que desejam e preencham critérios legais para ligadura tenham aconselhamento contraceptivo durante o prénatal.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Recomendação:** -->
- 59) **É recomendado que o modo de nascimento não seja determinado em função da realização da ligadura tubária.**

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **ATUALIZAÇÃO DAS DIRETRIZES** -->
Estas Diretrizes serão atualizadas periodicamente, inclusive considerando atualizações dos _guidelines_ do NICE-UK e do CNGOF. No futuro, as recomendações incluídas nestas Diretrizes poderão ser  
modificadas em decorrência do surgimento de novas evidências científicas. O Ministério da Saúde poderá incluir novas perguntas a serem respondidas no período de atualização.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **CONFLITO DE INTERESSE** -->
Os membros do grupo elaborador declaram não apresentar conflitos de interesse.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **GLOSSÁRIO** -->
|**Aciclovir**|Medicamento utilizado para o tratamento de doenças causadas por<br>vírus Herpes.|
|---|---|
|**Acretismo placentário ou**<br>**placenta acreta**|Consiste na aderência anormal da placenta na parede uterina. A<br>placenta fica grudada na parede do útero.|
|**Acurácia**|Capacidade de um teste diagnóstico em identificar de forma correta<br>quando algum paciente apresenta uma doença.|
|**Amoxicilina-clavulonato**|Medicamento antibiótico.|
|**Ampicilina**|Medicamento antibiótico.|
|**Anteparto**|Período da gestação que antecede o parto.|
|**Antibioticoprofilaxia**|Administração de antibiótico para prevenir uma infecção.|
|**Anticorpo anti-HBc**|Tipo de exame para diagnosticar Hepatite C.|
|**Apojadura**|É conhecida como a “Descida do leite” e costuma ocorrer a partir do<br>terceiro dia após o parto.|
|**Apresentação cefálica**|Posição em que o bebê está “de cabeça para baixo” dentro do útero.|
|**Apresentação pélvica**|Posição em que o bebê está sentado dentro do útero.|
|**Bishop (escore)**<br>**Bolsa íntegra**|Escore de avaliação das condições do colo uterino em relação ao<br>sucesso da indução do trabalho de parto<br>Bolsa d’água quando ainda não se rompeu.|
|**Bolsa rota**|Bolsa d’água que se rompeu.|  
|**Bradicardia**|Frequência de batimento cardíaco menor que o esperado. No caso do<br>feto, menos de 100 batimentos por minuto.|
|---|---|
|**Canal cervical**|Canal do colo do útero que tem forma cilíndrica e promove a<br>comunicação entre o útero e a vagina.|
|**Canal de parto**|Espaço de saída do feto no momento do nascimento. É constituído de<br>uma parte óssea (pelve ou “bacia”) e uma parte mole (que compõe a<br>vagina e a vulva).|
|**Carga viral**|É um exame que conta a quantidade de vírus presente em uma certa<br>quantidade de sangue.|
|**Cefalosporinas**|Grupo de medicamentos antibióticos.|
|**Cesariana prévia**|Quando a mulher já foi submetida a operação cesariana<br>anteriormente.|
|**Choque cardiogênico**|Incapacidade do coração bombear uma quantidade adequada de<br>sangue para os órgãos, causando queda da pressão arterial, falta de<br>oxigênio nos tecidos e acúmulo de líquidos nos pulmões<br>(http://www.tuasaude.com/choque-cardiogenico/).|
|**Clampeamento**|Momento do pinçamento e corte do cordão umbilical.|
|**Classificação de Robson**|Classificação que categoriza as mulheres de acordo com o número de<br>partos anteriores, gemelaridade, idade gestacional (a termo ou não),<br>apresentação e modo de início do trabalho de parto.|
|**Co-infecção**|Mais de uma infecção ao mesmo tempo.|
|**Coorte**|Tipo de estudo em que o investigador acompanha um grupo de<br>indivíduos ao longo do tempo a fim de observar se há relação entre<br>algum fator de risco e o desenvolvimento de uma doença.|
|**Depressão puerperal**|Tipo de depressão que afeta mulheres após terem dado a luz a um<br>bebê.|
|**Desenvolvimento**|Desenvolvimento do sistema nervoso, psicológico e da movimentação|
|**Neuropsicomotor**|(andar, falar, sentar etc.).|
|**Desproporção céfalo-pélvica**|Ocorre quando a cabeça do feto é maior que o espaço por onde ele<br>deve passar na pelve da mãe.|
|**Distócia**|Distúrbio que impede a progressão do trabalho de parto.|  
|**Doulas**|Mulheres (mais comumente leigas) que oferecem apoio, conforto,<br>estímulo e companhia à gestante durante o parto e nos cuidados com<br>o bebê.|
|---|---|
|**Embolia pulmonar**|Obstrução de vasos nos pulmões por coágulos (trombos ou êmbolos)<br>que provocam distúrbio respiratório grave.|
|**Encefalopatia isquêmica**|Alteração neurológica, que inclui distúrbios de consciência, alterações<br>do tônus e dos reflexos e convulsões, causada por falta de fluxo<br>sanguíneo no cérebro.|
|**Endometrite**|Infecção no útero.|
|**Escore de Apgar**|Escala de avaliação do bem-estar do bebê. Índice de Apgar acima de 7<br>é o ideal.|
|**Escore de Bishop**|Sistema de avaliação das características colo uterino e da altura da<br>apresentação fetal através do toque vaginal que pode aferir a chance<br>de sucesso na indução de um parto vaginal.|
|**Esterilização**|Meio de provocar a infertilidade da mulher.|
|**Exame ecográfico com**<br>**Doppler**|Ultrassonografia obstétrica. O Doppler avalia a função da placenta.|
|**Falência renal aguda**|É a perda súbita da capacidade de os rins filtrarem resíduos, sais e<br>líquidos do sangue.|
|**Fármacos**|Medicamentos.|
|**Febre puerperal**|Ocorrência de febre maior ou igual a 38°C que aparece após 24 horas<br>do parto e nos primeiros dez dias após o parto.|
|**Fetal**|Tudo o que diz respeito ao feto.|
|**Gemelar**|Tudo o que diz respeito a gravidez de gêmeos.|
|**HBV-DNA**|Exame de DNA do vírus da hepatite B.|
|**Hematócrito**|É a percentagem de volume ocupada pelos glóbulos vermelhos ou<br>hemácias no volume total de sangue.|
|**Hematologista**|Especialidade médica que estuda e trata as doenças do sangue.|  
|**Hemocomponentes**|Componentes utilizados para transfusão de sangue (hemácias,<br>plaquetas, plasma).|
|---|---|
|**Hemorragia intracraniana**|Extravasamento de sangue no interior do crânio.|
|**Hemotransfusão**|Transfusão venosa de sangue ou hemocomponentes.|
|**Hepatite B**|Inflamação no fígado provocada por vírus B.|
|**Hepatite C**|Inflamação no fígado provocada por vírus C.|
|**Vírus Herpes**|Vírus que infecta a boca ou órgãos genitais provocando feridas.|
|**Hiperbilirrubinemia**|Concentração anormalmente alta de bilirrubina no sangue.|
|**Hiperviscosidade**|Aumento dа viscosidade dо sangue.|
|**Hipoglicemia**|Distúrbio provocado pela baixa concentração de glicose no sangue.|
|**Hipotermia neonatal**|Temperatura corporal do recém-nascido anormalmente baixa.|
|**Hipóxia**|Ocorre quando há diminuição de oxigênio nos tecidos orgânicos, sendo<br>causada por diferentes fatores.|
|**Histerectomia**|Retirada cirúrgica do útero.|
|**Infecção herpética genital**|Herpes genital.|
|**Infecção primária**|Infecção que ocorre pela primeira vez.|
|**Isoimunização**|Quando a mãe e o bebê têm sangue de tipos diferentes e estes se<br>misturam em algum momento durante a gestação e o parto, podendo<br>ocorrer a formação de anticorpos (proteínas de defesa) contra o tipo<br>de sangue diferente, afetando principalmente<br>as gestações<br>subsequentes.|
|**Isoimunizadas**|Mulheres que têm anticorpos (proteínas de defesa) contra o tipo de<br>sangue diferente do delas.|
|**Ligadura tubária**|Método de esterilização feminina caracterizado pelo corte cirúrgico e<br>laqueadura das tubas uterinas.|
|**Lesão cervical**|Trauma na região do colo do útero, na porção inferior do útero.|
|**Lesão iatrogênica**|Trauma, doença, efeito adverso ou complicação causados ou<br>resultantes de intervenção médica.|  
|**Lesão vesical**|Na operação cesariana, trauma da bexiga.|
|---|---|
|**Ligadura/hemostasia**|Maneira de interromper o fluxo ou coagular o sangue em vaso roto.|
|**Líquido meconial**|Líquido amniótico (da bolsa d’água) misturado às primeiras fezes do<br>feto ou recém-nascido.|
|**Monocorionicidade**|Diz respeito à presença de uma única placenta para os dois fetos de<br>uma gestação gemelar.|
|**Morbidade**|Doença, complicação. Em epidemiologia, significa a taxa de doentes de<br>determinada doença em relação à população total estudada, em<br>determinado local e em determinado momento.|
|**Morbidade crônica**|Doença ou complicação crônica.|
|**Morbidade respiratória**|Desconforto respiratório, “falta de ar”.|
|**Mortalidade**|Óbitos. Taxa epidemiológica para quantificar o número de óbitos<br>ocorridos em relação ao número de habitantes.|
|**Multíparas**|Mulheres que já tiveram mais de um parto.|
|**Neonatal**|Relativo ao recém-nascido (RN) ou ao período de quatro semanas que<br>se segue ao nascimento.|
|**Nulíparas**|Mulheres que nunca tiveram parto.|
|**Ocitocina**|Hormônio sintético utilizado para induzir ou aumentar contrações do<br>útero no trabalho de parto.|
|**Paralisia cerebral**|Alteração no sistema nervoso que leva à dificuldade de falar, se<br>movimentar e engolir, entre outros problemas neurológicos.|
|**Pelve ou Cavidade pélvica**|Conhecida como “bacia”, é o espaço que contém os componentes<br>abdominais, como a bexiga, ovários e útero, contornado pelos ossos do<br>quadril, sacro e cóccix. É a parte óssea do canal de parto.|
|**Pelvimetria**|Exame para medir a pelve (“bacia”) óssea; na mulher, a parte óssea do<br>canal de parto.|
|**Perfusão pulmonar**|Irrigação do sangue nos pulmões.|
|**Perineal**|Relativo ao períneo; região do corpo humano que, nas mulheres,<br>começa abaixo da vulva e se estende até o ânus.|  
|**Período Perinatal**|Compreende o período entre as 22 semanas completas de gestação (ou|
|---|---|
||peso ao nascer igual ou maior que 500g) e os 7 dias completos após o<br>nascimento|
|**Placenta anterior**|Quando a placenta está voltada para a posição à frente do útero.|
|**Placenta Prévia**|A placenta que se implanta total ou parcialmente no seguimento<br>inferior do útero. Ela pode ser baixa, margina, centro-parcial e centro<br>total.|
|**Placenta prévia centro-**<br>**parcial**|Quando a placenta recobre parcialmente o canal de parto.|
|**Placenta prévia centro-total**|Quando a placenta recobre totalmente o canal de parto.|
|**Policitemia**|Aumento de glóbulos vermelhos no sangue. Pode ser fisiológica<br>(compensatória) ou patológica.|
|**Pré-eclâmpsia**|Condição caracterizada por pressão arterial elevada, acompanhada<br>pela eliminação de proteínas pela urina (proteinúria) ou de retenção de<br>líquidos (edema), que ocorre entre a 20ª semana de gravidez e o final<br>da primeira semana depois do parto.|
|**Prematuridade**|Relativo a um recém-nascido prematuro ou pré-termo; ou seja, aquele<br>nascido antes das 37 semanas de gravidez.|
|**Pré-termo**|Parto ou nascimento que ocorre antes das 37 semanas de gravidez.|
|**Primíparas**|Mulheres quando têm seu primeiro parto.|
|**Profilático**|Preventivo.|
|**Profilaxia antibiótica**|Administração de antibótico para prevenir uma infecção.|
|**Puerperal**|O estado puerperal é o período compreendido entre a expulsão da<br>placenta até os 42 dias após o parto.|
|**Pulsação do cordão**|O cordão umbilical possui vasos sanguíneos cuja pulsação pode ser<br>sentida e contada.|
|**Reprodução assistida**|Área da ginecologia em que ajuda casais inférteis a terem filhos de<br>maneira artificial, com medicação e procedimentos como inseminação<br>e fertilização_in vitro_, vulgarmente conhecidos como “bebê de proveta”.|
|**Ruptura uterina**|Condição patológica em que o útero se rompe.|  
|**Soropositivas**|Mulheres infectadas com o vírus HIV.|
|---|---|
|**Soroprevalência**|Prevalência do teste positivo para algum vírus ou bactéria no sangue.|
|**Sutura**|Técnica utilizada para fechar uma abertura cirúrgica ou lesão, ligando<br>ou unindo pele, músculos, vasos sanguíneos e outros tecidos do corpo<br>com pontos cirúrgicos.|
|**Taquipneia transitória**|Desconforto respiratório transitório, intermitente.|
|**Tecido adiposo**|Conjunto de células que contêm gordura.|
|**Tecido subcutâneo**|Tecidos, inclusive o gorduroso, que se encontram abaixo da pele.|
|**Terapia antirretroviral**|Medicação para tratamento de vírus (no texto, o HIV).|
|**Termo**|É o período entre as 37 e 42 semanas da gestação.|
|**Tocofobia**|Aversão, medo ou ansiedade exagerada em relação ao parto vaginal.|
|**Tônus**|Tensão elástica; sente-se leve contração.|
|**Tração controlada do cordão**|Segurar o cordão umbilical com um pouco de tensão.|
|**Transmissão vertical**|Transmissão de uma doença infecciosa da mãe para o filho durante a<br>gravidez, no momento do parto ou por meio do aleitamento materno.|
|**Traumatismo cirúrgico**|Trauma físico provocado por ocasião de um procedimento cirúrgico.|
|**Trombose venosa profunda**|Obstrução de uma veia da perna ou braço que impede a circulação de<br>sangue no local.|
|**Vasectomia**|Técnica cirúrgica para esterilização dos homens.|
|**Versão cefálica externa**|Manobra realizada sobre o abdome materno para virar o feto que está<br>atravessado no útero ou sentado, de forma a posicioná-lo com a cabeça<br>para baixo, que é a posição ideal para o parto.|

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **REFERÊNCIAS** -->
1. MS/SVS/DASIS - Dados de 2012. Sistema de Informações sobre Nascidos Vivos %u2013 SINASC e SIP/ANS. 2013.  
2. Lumbiganon P, Laopaiboon M, Gulmezoglu AM, Souza JP, Taneepanichskul S, Ruyan P, et al. Method of delivery and pregnancy outcomes in Asia: the WHO global survey on maternal and perinatal health 2007-08. Lancet. 2010 Feb 6;375(9713):490-9. PubMed PMID: 20071021. Epub 2010/01/15. eng. 3. Villar J, Valladares E, Wojdyla D, Zavaleta N, Carroli G, Velazco A, et al. Caesarean delivery rates and pregnancy outcomes: the 2005 WHO global survey on maternal and perinatal health in Latin America. Lancet. 2006 Jun 3;367(9525):1819-29. PubMed PMID: 16753484. Epub 2006/06/07. eng.  
4. Souza JP, Cecatti JG, Faundes A, Morais SS, Villar J, Carroli G, et al. Maternal near miss and maternal death in the World Health Organization's 2005 global survey on maternal and perinatal health. Bulletin of the World Health Organization. 2010 Feb;88(2):113-9. PubMed PMID: 20428368. Pubmed Central PMCID: PMC2814475. Epub 2010/04/30. eng.  
5. Victora C. A operação cesariana freia a redução da mortalidade materna no Brasil. Comunicação Pessoal, 2015. <u>http://saude.estadao.com.br/noticias/geral,cesarea-freia-queda-de-mortalidadematerna-diz-especialista,1521306.</u>  
6. NICE. Caeserean section. 2011:www.nice.org.uk/guidance/CG55. London - UK.  
7. WHO Statement on Caesarean Section Rates. 2015.  
8. Betran AP, Torloni MR, Zhang J, Ye J, Mikolajczyk R, Deneux-Tharaux C, et al. What is the optimal rate of caesarean section at population level? A systematic review of ecologic studies. Reproductive health. 2015 Jun 21;12(1):57. PubMed PMID: 26093498. Epub 2015/06/22. Eng.  
9. JP Souza, AP Betran, A Dumont, B de Mucio, CM Gibbs Pickens, C Deneux-Tharaux, E Ortiz-Panozo, E Sullivan, E Ota, G Togoobaatar, G Carroli, H Knight, Jun Zhang, JG Cecatti, JP Vogel, K Jayaratne, do Carmo Leal M, Gissler M, Morisaki N, Lack N, Oladapo OT, Tuncalp O, Lumbiganon P, Mori R, Quintana S, Costa Passos AD, Marcolin AC, Zongo A, Blondel B, Herna´ndez B, Hogue CJ, Prunet C, Landman C, Ochir C, Cuesta C, Pileggi-Castro C, Walker D, Alves D, Abalos E, Moises ECD, Vieira EM, Duarte G, Perdona G, GurolUrganci I, Takahiko K, Moscovici L, Campodonico L, Oliveira-Ciabati L, Laopaiboon M, Danansuriya M, Nakamura-Pereira M, Costa ML, Torloni MR, Kramer MR, Borges P, Olkhanud PB, Perez-Cuevas R, Agampodi SB, Mittal S, Serruya S, Bataglia V, Li Z, Temmerman M, Gulmezoglu AM. C-Model global reference for caesarean section rates: a multicountry cross-sectional study. BJOG 2015; DOI: 10.1111/1471-0528.13509.  
10. Cecatti JG. Beliefs and misbeliefs about current interventions during labor and delivery in Brazil. Cadernos de saude publica. 2014 Aug;30 Suppl 1:S17-8. PubMed PMID: 25167182. Epub 2014/08/29. eng por.  
11. The ADAPTE Collaboration. The ADAPTE Process: Resource Toolkit for Guideline Adaptation. Version 2.0. Available from: http://www.g-i-n.net. 2009.  
12. Brouwers M, Kho ME, Browman GP, Burgers JS, Cluzeau F, Feder G, Fervers B, Graham ID, Grimshaw J, Hanna S, Littlejohns P, Makarski J, Zitzelsberger L for the AGREE Next Steps Consortium. AGREE II: Advancing guideline development, reporting and evaluation in healthcare.  Can Med Assoc J. Dec 2010; 182:E839-842; doi:10.1503/090449. 2010.  
13. Sentilhes L, Vayssiere C, Beucher G, Deneux-Tharaux C, Deruelle P, Diemunsch P, et al. Delivery for women with a previous cesarean: guidelines for clinical practice from the French College of Gynecologists and Obstetricians (CNGOF). European journal of obstetrics, gynecology, and reproductive biology. 2013 Sep;170(1):25-32. PubMed PMID: 23810846. Epub 2013/07/03. eng.  
14. Gagnon AJ. Individual or group antenatal education for childbirth/parenthood. The Cochrane database of systematic reviews. 2000 (4):CD002869. PubMed PMID: 11034780. Epub 2000/10/18. eng.  
15. O'Cathain A, Walters SJ, Nicholl JP, Thomas KJ, Kirkham M. Use of evidence based leaflets to promote informed choice in maternity care: randomised controlled trial in everyday practice. BMJ (Clinical research ed). 2002 Mar 16;324(7338):643. PubMed PMID: 11895822. Pubmed Central PMCID: PMC84396. Epub 2002/03/16. eng.  
16. Deneux-Tharaux C, Carmona E, Bouvier-Colle MH, Breart G. Postpartum maternal mortality and cesarean delivery. Obstetrics and gynecology. 2006 Sep;108(3 Pt 1):541-8. PubMed PMID: 16946213. Epub 2006/09/02. eng.  
17. Joseph KS, Liu S, Rouleau J, Kirby RS, Kramer MS, Sauve R, et al. Severe maternal morbidity in Canada, 2003 to 2007: surveillance using routine hospitalization data and ICD-10CA codes. Journal of obstetrics and gynaecology Canada : JOGC = Journal d'obstetrique et gynecologie du Canada : JOGC. 2010 Sep;32(9):837-46. PubMed PMID: 21050516. Epub 2010/11/06. eng.  
18. Dahlgren LS, von Dadelszen P, Christilaw J, Janssen PA, Lisonkova S, Marquette GP, et al. Caesarean section on maternal request: risks and benefits in healthy nulliparous women and their infants. Journal of obstetrics and gynaecology Canada : JOGC = Journal d'obstetrique et gynecologie du Canada : JOGC. 2009 Sep;31(9):808-17. PubMed PMID: 19941705. Epub 2009/11/28. eng.  
19. Geller EJ, Wu JM, Jannelli ML, Nguyen TV, Visco AG. Maternal outcomes associated with planned vaginal versus planned primary cesarean delivery. American journal of perinatology. 2010 Oct;27(9):67583. PubMed PMID: 20235001. Epub 2010/03/18. eng.  
20. Schindl M, Birner P, Reingrabner M, Joura E, Husslein P, Langer M. Elective cesarean section vs. spontaneous delivery: a comparative study of birth experience. Acta obstetricia et gynecologica Scandinavica. 2003 Sep;82(9):834-40. PubMed PMID: 12911445. Epub 2003/08/13. eng.  
21. Geller EJ, Wu JM, Jannelli ML, Nguyen TV, Visco AG. Neonatal outcomes associated with planned vaginal versus planned primary cesarean delivery. Journal of perinatology : official journal of the California Perinatal Association. 2010 Apr;30(4):258-64. PubMed PMID: 19812591. Epub 2009/10/09. eng.  
22. Homer CS, Kurinczuk JJ, Spark P, Brocklehurst P, Knight M. Planned vaginal delivery or planned caesarean delivery in women with extreme obesity. BJOG : an international journal of obstetrics and gynaecology. 2011 Mar;118(4):480-7. PubMed PMID: 21244616. Epub 2011/01/20. eng.  
23. Hofmeyr GJ. External cephalic version facilitation for breech presentation at term. The Cochrane database of systematic reviews. 2001 (4):CD000184. PubMed PMID: 11687071. Epub 2001/11/01. eng. 24. Van Veelen AJ, Van Cappellen AW, Flu PK, Straub MJ, Wallenburg HC. Effect of external cephalic version in late pregnancy on presentation at delivery: a randomized controlled trial. British journal of obstetrics and gynaecology. 1989 Aug;96(8):916-21. PubMed PMID: 2673337. Epub 1989/08/01. eng.  
25. Hofmeyr GJ. External cephalic version for breech presentation before term. The Cochrane database of systematic reviews. 2000 (2):CD000084. PubMed PMID: 10796123. Epub 2000/05/05. eng. 26. Lau TK, Lo KW, Rogers M. Pregnancy outcome after successful external cephalic version for breech presentation at term. American journal of obstetrics and gynecology. 1997 Jan;176(1 Pt 1):218-23. PubMed PMID: 9024118. Epub 1997/01/01. eng.  
27. Hofmeyr GJ, Hannah ME. Planned caesarean section for term breech delivery. The Cochrane database of systematic reviews. 2003 (3):CD000166. PubMed PMID: 12917886. Epub 2003/08/15. eng. 28. Confidential Enquiry into Stillbirths and Deaths in Infancy. An enquiry into the quality of care and its effect on the survival of babies born at 27-28 weeks. Project 27/28. London: TSO. 2003. 29. Hannah ME, Hannah WJ, Hewson SA, Hodnett ED, Saigal S, Willan AR. Planned caesarean section versus planned vaginal birth for breech presentation at term: a randomised multicentre trial. Term Breech  
Trial Collaborative Group. Lancet. 2000 Oct 21;356(9239):1375-83. PubMed PMID: 11052579. Epub 2000/10/29. eng.  
30. Thomas J PS. RCOG Clinical Effectiveness Support Unit. The National Sentinel Caesarean Section Audit Report. . 2001. London-UK.  
31. Rydhstrom H, Ingemarsson I. A case-control study of the effects of birth by caesarean section on intrapartum and neonatal mortality among twins weighing 1500-2499 g. British journal of obstetrics and gynaecology. 1991 Mar;98(3):249-53. PubMed PMID: 2021562. Epub 1991/03/01. eng.  
32. Sheay W, Ananth CV, Kinzler WL. Perinatal mortality in first- and second-born twins in the United States. Obstetrics and gynecology. 2004 Jan;103(1):63-70. PubMed PMID: 14704246. Epub 2004/01/06. eng.  
33. Smith GC, Pell JP, Dobbie R. Birth order, gestational age, and risk of delivery related perinatal death in twins: retrospective cohort study. BMJ (Clinical research ed). 2002 Nov 2;325(7371):1004. PubMed PMID: 12411358. Pubmed Central PMCID: PMC131015. Epub 2002/11/02. eng.  
34. Crowther CA. Caesarean delivery for the second twin. The Cochrane database of systematic reviews. 2000 (2):CD000047. PubMed PMID: 10796103. Epub 2000/05/05. eng.  
35. Rabinovici J, Barkai G, Reichman B, Serr DM, Mashiach S. Randomized management of the second nonvertex twin: vaginal delivery or cesarean section. American journal of obstetrics and gynecology. 1987 Jan;156(1):52-6. PubMed PMID: 3799768. Epub 1987/01/01. eng.  
36. Chasen ST, Madden A, Chervenak FA. Cesarean delivery of twins and neonatal respiratory disorders. American journal of obstetrics and gynecology. 1999 Nov;181(5 Pt 1):1052-6. PubMed PMID: 10561617. Epub 1999/11/16. eng.  
37. Barrett JF, Hannah ME, Hutton EK, Willan AR, Allen AC, Armson BA, et al. A randomized trial of planned cesarean or vaginal delivery for twin pregnancy. The New England journal of medicine. 2013 Oct 3;369(14):1295-305. PubMed PMID: 24088091. Pubmed Central PMCID: PMC3954096. Epub 2013/10/04. eng.  
38. Jain A, Fleming P. Project 27/28. An enquiry into the quality of care and its effect on the survival of babies born at 27-28 weeks. Archives of disease in childhood Fetal and neonatal edition. 2004 Jan;89(1):F14-6. PubMed PMID: 14711846. Pubmed Central PMCID: PMC1721629. Epub 2004/01/09. eng. 39. Murphy DJ, Sellers S, MacKenzie IZ, Yudkin PL, Johnson AM. Case-control study of antenatal and intrapartum risk factors for cerebral palsy in very preterm singleton babies. Lancet. 1995 Dec 2;346(8988):1449-54. PubMed PMID: 7490990. Epub 1995/12/02. eng.  
40. Wallace RL, Schifrin BS, Paul RH. The delivery route for very-low-birth-weight infants. A preliminary report of a randomized, prospective study. The Journal of reproductive medicine. 1984 Oct;29(10):73640. PubMed PMID: 6512783. Epub 1984/10/01. eng.  
41. Kinzler WL, Ananth CV, Smulian JC, Vintzileos AM. The effects of labor on infant mortality among small-for-gestational-age infants in the USA. The journal of maternal-fetal & neonatal medicine : the official journal of the European Association of Perinatal Medicine, the Federation of Asia and Oceania Perinatal Societies, the International Society of Perinatal Obstet. 2002 Sep;12(3):201-6. PubMed PMID: 12530619. Epub 2003/01/18. eng.  
42. Levy BT, Dawson JD, Toth PP, Bowdler N. Predictors of neonatal resuscitation, low Apgar scores, and umbilical artery pH among growth-restricted neonates. Obstetrics and gynecology. 1998 Jun;91(6):909-16. PubMed PMID: 9610995. Epub 1998/06/04. eng.  
43. Westgren M, Dolfin T, Halperin M, Milligan J, Shennan A, Svenningsen NW, et al. Mode of delivery in the low birth weight fetus. Delivery by cesarean section independent of fetal lie versus vaginal delivery in vertex presentation. A study with long-term follow-up. Acta obstetricia et gynecologica Scandinavica. 1985;64(1):51-7. PubMed PMID: 3976377. Epub 1985/01/01. eng.  
44. Guise JM, Eden K, Emeis C, Denman MA, Marshall N, Fu RR, et al. Vaginal birth after cesarean: new insights. Evidence report/technology assessment. 2010 Mar(191):1-397. PubMed PMID: 20629481. Epub 2010/07/16. eng.  
45. Warshak CR, Eskander R, Hull AD, Scioscia AL, Mattrey RF, Benirschke K, et al. Accuracy of ultrasonography and magnetic resonance imaging in the diagnosis of placenta accreta. Obstetrics and gynecology. 2006 Sep;108(3 Pt 1):573-81. PubMed PMID: 16946217. Epub 2006/09/02. eng.  
46. Twickler DM, Lucas MJ, Balis AB, Santos-Ramos R, Martin L, Malone S, et al. Color flow mapping for myometrial invasion in women with a prior cesarean delivery. The Journal of maternal-fetal medicine. 2000 Nov-Dec;9(6):330-5. PubMed PMID: 11243289. Epub 2001/03/13. eng.  
47. Shih JC, Palacios Jaraquemada JM, Su YN, Shyu MK, Lin CH, Lin SY, et al. Role of three-dimensional power Doppler in the antenatal diagnosis of placenta accreta: comparison with gray-scale and color Doppler techniques. Ultrasound in obstetrics & gynecology : the official journal of the International Society of Ultrasound in Obstetrics and Gynecology. 2009 Feb;33(2):193-203. PubMed PMID: 19173239. Epub 2009/01/29. eng.  
48. Masselli G, Brunelli R, Casciani E, Polettini E, Piccioni MG, Anceschi M, et al. Magnetic resonance imaging in the evaluation of placental adhesive disorders: correlation with color Doppler ultrasound. European radiology. 2008 Jun;18(6):1292-9. PubMed PMID: 18239921. Epub 2008/02/02. eng.  
49. Bronsteen R, Valice R, Lee W, Blackwell S, Balasubramaniam M, Comstock C. Effect of a low-lying placenta on delivery outcome. Ultrasound in obstetrics & gynecology : the official journal of the International Society of Ultrasound in Obstetrics and Gynecology. 2009 Feb;33(2):204-8. PubMed PMID: 19173234. Epub 2009/01/29. eng.  
50. Wong HS, Hutton J, Zuccollo J, Tait J, Pringle KC. The maternal outcome in placenta accreta: the significance of antenatal diagnosis and non-separation of placenta at delivery. The New Zealand medical journal. 2008 Jul 4;121(1277):30-8. PubMed PMID: 18677328. Epub 2008/08/05. eng.  
51. Warshak CR, Ramos GA, Eskander R, Benirschke K, Saenz CC, Kelly TF, et al. Effect of predelivery diagnosis in 99 consecutive cases of placenta accreta. Obstetrics and gynecology. 2010 Jan;115(1):65-9. PubMed PMID: 20027036. Epub 2009/12/23. eng.  
52. Hanzal E, Kainz C, Hoffmann G, Deutinger J. An analysis of the prediction of cephalopelvic disproportion. Archives of gynecology and obstetrics. 1993;253(4):161-6. PubMed PMID: 8161249. Epub 1993/01/01. eng.  
53. Gorman RE, Noble A, Andrews CM. The relationship between shoe size and mode of delivery. Midwifery today and childbirth education. 1997 Spring(41):70-1. PubMed PMID: 9136429. Epub 1997/04/01. eng.  
54. Pattinson RC FE-ME. Pelvimetry for fetal cephalic presentations at or near term. The Cochrane database of systematic reviews. 2001:http://cochrane.bvsalud.org/cochrane/main.php?lib=COC&searchExp=pelvimetry&lang=pt.  
55. Zhang J, Landy HJ, Branch DW, Burkman R, Haberman S, Gregory KD, et al. Contemporary patterns of spontaneous labor with normal neonatal outcomes. Obstetrics and gynecology. 2010 Dec;116(6):12817. PubMed PMID: 21099592. Pubmed Central PMCID: PMC3660040. Epub 2010/11/26. eng.  
56. Rossi AC, Mullin P, Prefumo F. Prevention, management, and outcomes of macrosomia: a systematic review of literature and meta-analysis. Obstetrical & gynecological survey. 2013 Oct;68(10):702-9. PubMed PMID: 25101904. Epub 2014/08/08. eng.  
57. Calvert C, Ronsmans C. HIV and the risk of direct obstetric complications: a systematic review and meta-analysis. PloS one. 2013;8(10):e74848. PubMed PMID: 24124458. Pubmed Central PMCID: PMC3790789. Epub 2013/10/15. eng.  
58. Elective caesarean-section versus vaginal delivery in prevention of vertical HIV-1 transmission: a randomised clinical trial. Lancet. 1999 Mar 27;353(9158):1035-9. PubMed PMID: 10199349. Epub 1999/04/13. eng.  
59. Lavender T, Hofmeyr GJ, Neilson JP, Kingdon C, Gyte GM. Caesarean section for non-medical reasons at term. The Cochrane database of systematic reviews. 2012;3:CD004660. PubMed PMID: 22419296. Pubmed Central PMCID: PMC4171389. Epub 2012/03/16. eng.  
60. The mode of delivery and the risk of vertical transmission of human immunodeficiency virus type 1--a meta-analysis of 15 prospective cohort studies. The International Perinatal HIV Group. The New England journal of medicine. 1999 Apr 1;340(13):977-87. PubMed PMID: 10099139. Epub 1999/04/01. eng.  
61. Recommendations for Use of Antiretroviral Drugs in Pregnant HIV-1-Infected Women for Maternal. Health and Interventions to Reduce Perinatal HIV Transmission in the United States. Uptodate 2015. <u>http://aidsinfo.nih.gov/guidelines. 2015.</u>  
62. Ministério da Saúde. Estudo de prevalência de base populacional das infecções pelos vírus das hepatites A, B e C nas capitais do Brasil. . 2010. p. 27-36.  
63. Lee SD TY, Wu TC, Lo KJ, Wu JC, Yang ZC. Role of caesareansection in prevention of mother-infant transmission of hepatitis B virus. Lancet. 1998:833-4.  
64. Gibb DM, Goodall RL, Dunn DT, Healy M, Neave P, Cafferkey M, et al. Mother-to-child transmission of hepatitis C virus: evidence for preventable peripartum transmission. Lancet. 2000 Sep 9;356(9233):9047. PubMed PMID: 11036896. Epub 2000/10/19. eng.  
65. Clemens SAC FC. Soroprevalência de anticorpos contra vírus herpes simples 1-2 no Brasil. Revista de Saúde Pública. 2010;44(4).  
66. Nahmias AJ, Josey WE, Naib ZM, Freeman MG, Fernandez RJ, Wheeler JH. Perinatal risk associated with maternal genital herpes simplex virus infection. American journal of obstetrics and gynecology. 1971 Jul 15;110(6):825-37. PubMed PMID: 4327295. Epub 1971/07/15. eng.  
67. Brown ZA, Benedetti J, Ashley R, Burchett S, Selke S, Berry S, et al. Neonatal herpes simplex virus infection in relation to asymptomatic maternal infection at the time of labor. The New England journal of medicine. 1991 May 2;324(18):1247-52. PubMed PMID: 1849612. Epub 1991/05/02. eng.  
68. Scott LL, Sanchez PJ, Jackson GL, Zeray F, Wendel GD, Jr. Acyclovir suppression to prevent cesarean delivery after first-episode genital herpes. Obstetrics and gynecology. 1996 Jan;87(1):69-73. PubMed PMID: 8532270. Epub 1996/01/01. eng.  
69. Brocklehurst P, Kinghorn G, Carney O, Helsen K, Ross E, Ellis E, et al. A randomised placebo controlled trial of suppressive acyclovir in late pregnancy in women with recurrent genital herpes infection. British journal of obstetrics and gynaecology. 1998 Mar;105(3):275-80. PubMed PMID: 9532986. Epub 1998/04/09. eng.  
70. Braig S, Luton D, Sibony O, Edlinger C, Boissinot C, Blot P, et al. Acyclovir prophylaxis in late pregnancy prevents recurrent genital herpes and viral shedding. European journal of obstetrics, gynecology, and reproductive biology. 2001 May;96(1):55-8. PubMed PMID: 11311761. Epub 2001/04/20. eng.  
71. Hannah ME, Hannah WJ, Hodnett ED, Chalmers B, Kung R, Willan A, et al. Outcomes at 3 months after planned cesarean vs planned vaginal delivery for breech presentation at term: the international randomized Term Breech Trial. Jama. 2002 Apr 10;287(14):1822-31. PubMed PMID: 11939868. Epub 2002/04/10. eng.  
72. Chaim W, Bashiri A, Bar-David J, Shoham-Vardi I, Mazor M. Prevalence and clinical significance of postpartum endometritis and wound infection. Infectious diseases in obstetrics and gynecology. 2000;8(2):77-82. PubMed PMID: 10805361. Pubmed Central PMCID: PMC1784665. Epub 2000/05/11. eng.  
73. Hebert PR, Reed G, Entman SS, Mitchel EF, Jr., Berg C, Griffin MR. Serious maternal morbidity after childbirth: prolonged hospital stays and readmissions. Obstetrics and gynecology. 1999 Dec;94(6):942-7. PubMed PMID: 10576180. Epub 1999/11/27. eng.  
74. Smaill F, Hofmeyr GJ. Antibiotic prophylaxis for cesarean section. The Cochrane database of systematic reviews. 2002 (3):CD000933. PubMed PMID: 12137614. Epub 2002/07/26. eng.  
75. Hopkins L SF. Antibiotic prophylaxis regimens and drugs for cesarean section. Cochrane Database of Systematic Reviews. 2001 (12).  
76. Wilkinson CS EM. Manual removal of placenta at caesarean section. Cochrane Database of Systematic Reviews. 2003 (12).  
77. Allaire AD, Fisch J, McMahon MJ. Subcutaneous drain vs. suture in obese women undergoing cesarean delivery. A prospective, randomized trial. The Journal of reproductive medicine. 2000 Apr;45(4):327-31. PubMed PMID: 10804490. Epub 2000/05/11. eng.  
78. Cetin A, Cetin M. Superficial wound disruption after cesarean delivery: effect of the depth and closure of subcutaneous tissue. International journal of gynaecology and obstetrics: the official organ of the International Federation of Gynaecology and Obstetrics. 1997 Apr;57(1):17-21. PubMed PMID: 9175664. Epub 1997/04/01. eng.  
79. Beucher G, Dolley P, Levy-Thissier S, Florian A, Dreyfus M. [Maternal benefits and risks of trial of labor versus elective repeat caesarean delivery in women with a previous caesarean delivery]. Journal de gynecologie, obstetrique et biologie de la reproduction. 2012 Dec;41(8):708-26. PubMed PMID: 23159201. Epub 2012/11/20. Benefices et risques maternels de la tentative de voie basse comparee a la cesarienne programmee en cas d'antecedent de cesarienne. fre.  
80. Cahill AG, Tuuli M, Odibo AO, Stamilio DM, Macones GA. Vaginal birth after caesarean for women with three or more prior caesareans: assessing safety and success. BJOG : an international journal of obstetrics and gynaecology. 2010 Mar;117(4):422-7. PubMed PMID: 20374579. Epub 2010/04/09. eng.  
81. Tahseen S, Griffiths M. Vaginal birth after two caesarean sections (VBAC-2)-a systematic review with meta-analysis of success rate and adverse outcomes of VBAC-2 versus VBAC-1 and repeat (third) caesarean sections. BJOG : an international journal of obstetrics and gynaecology. 2010 Jan;117(1):5-19. PubMed PMID: 19781046. Epub 2009/09/29. eng.  
82. Dekker GA, Chan A, Luke CG, Priest K, Riley M, Halliday J, et al. Risk of uterine rupture in Australian women attempting vaginal birth after one prior caesarean section: a retrospective population-based  
cohort study. BJOG : an international journal of obstetrics and gynaecology. 2010 Oct;117(11):1358-65. PubMed PMID: 20716251. Epub 2010/08/19. eng.  
83. Lopez E, Patkai J, El Ayoubi M, Jarreau PH. [Benefits and harms to the newborn of maternal attempt at trial of labor after prior caesarean versus elective repeat caesarean delivery]. Journal de gynecologie, obstetrique et biologie de la reproduction. 2012 Dec;41(8):727-34. PubMed PMID: 23141133. Epub 2012/11/13. Benefices et risques neonataux de la tentative de voie basse comparee a la cesarienne programmee en cas d'antecedent de cesarienne. fre.  
84. Crowther CA, Dodd JM, Hiller JE, Haslam RR, Robinson JS. Planned vaginal birth or elective repeat caesarean: patient preference restricted cohort with nested randomised trial. PLoS medicine. 2012;9(3):e1001192. PubMed PMID: 22427749. Pubmed Central PMCID: PMC3302845. Epub 2012/03/20. eng.  
85. Rozen G, Ugoni AM, Sheehan PM. A new perspective on VBAC: a retrospective cohort study. Women and birth : journal of the Australian College of Midwives. 2011 Mar;24(1):3-9. PubMed PMID: 20447886. Epub 2010/05/08. eng.  
86. Haumonte JB, Raylet M, Sabiani L, Franke O, Bretelle F, Boubli L, et al. [Predictive factors for vaginal birth after cesarean section]. Journal de gynecologie, obstetrique et biologie de la reproduction. 2012 Dec;41(8):735-52. PubMed PMID: 23142356. Epub 2012/11/13. Quels facteurs influencent la voie d'accouchement en cas de tentative de voie basse sur uterus cicatriciel ? fre.  
87. Kayem G, Raiffort C, Legardeur H, Gavard L, Mandelbrot L, Girard G. [Specific particularities of uterine scars and their impact on the risk of uterine rupture in case of trial of labor]. Journal de gynecologie, obstetrique et biologie de la reproduction. 2012 Dec;41(8):753-71. PubMed PMID: 23142359. Epub 2012/11/13. Criteres d'acceptation de la voie vaginale selon les caracteristiques de la cicatrice uterine. fre.  
88. Schmitz T. [Particular maternal or fetal clinical conditions influencing the choice of the mode of delivery in case of previous cesarean]. Journal de gynecologie, obstetrique et biologie de la reproduction. 2012 Dec;41(8):772-81. PubMed PMID: 23131716. Epub 2012/11/08. Situations cliniques particulieres, maternelles ou foetales, influencant le choix du mode d'accouchement en cas d'antecedent de cesarienne. fre.  
89. Jastrow N, Chaillet N, Roberge S, Morency AM, Lacasse Y, Bujold E. Sonographic lower uterine segment thickness and risk of uterine scar defect: a systematic review. Journal of obstetrics and gynaecology Canada : JOGC = Journal d'obstetrique et gynecologie du Canada : JOGC. 2010 Apr;32(4):3217. PubMed PMID: 20500938. Epub 2010/05/27. eng.  
90. Shipp TD, Zelop CM, Repke JT, Cohen A, Lieberman E. Interdelivery interval and risk of symptomatic uterine rupture. Obstetrics and gynecology. 2001 Feb;97(2):175-7. PubMed PMID: 11165577. Epub 2001/02/13. eng.  
91. Huang WH, Nakashima DK, Rumney PJ, Keegan KA, Jr., Chan K. Interdelivery interval and the success of vaginal birth after cesarean delivery. Obstetrics and gynecology. 2002 Jan;99(1):41-4. PubMed PMID: 11777508. Epub 2002/01/05. eng.  
92. Bujold E, Gauthier RJ. Risk of uterine rupture associated with an interdelivery interval between 18 and 24 months. Obstetrics and gynecology. 2010 May;115(5):1003-6. PubMed PMID: 20410775. Epub 2010/04/23. eng.  
93. Bujold E, Mehta SH, Bujold C, Gauthier RJ. Interdelivery interval and uterine rupture. American journal of obstetrics and gynecology. 2002 Nov;187(5):1199-202. PubMed PMID: 12439503. Epub 2002/11/20. eng.  
94. Rochelson B, Pagano M, Conetta L, Goldman B, Vohra N, Frey M, et al. Previous preterm cesarean delivery: identification of a new risk factor for uterine rupture in VBAC candidates. The journal of maternal-fetal & neonatal medicine : the official journal of the European Association of Perinatal Medicine, the Federation of Asia and Oceania Perinatal Societies, the International Society of Perinatal Obstet. 2005 Nov;18(5):339-42. PubMed PMID: 16390795. Epub 2006/01/05. eng.  
95. Stamilio DM, DeFranco E, Pare E, Odibo AO, Peipert JF, Allsworth JE, et al. Short interpregnancy interval: risk of uterine rupture and complications of vaginal birth after cesarean delivery. Obstetrics and gynecology. 2007 Nov;110(5):1075-82. PubMed PMID: 17978122. Epub 2007/11/06. eng.  
96. Gallot D, Delabaere A, Desvignes F, Vago C, Accoceberry M, Lemery D. [Information and facilities recommendations concerning trial of labour in the context of scarred womb]. Journal de gynecologie, obstetrique et biologie de la reproduction. 2012 Dec;41(8):782-7. PubMed PMID: 23141131. Epub 2012/11/13. Quelles sont les recommandations d'organisation et d'information en cas de proposition de tentative de voie basse pour uterus cicatriciel ? fre.  
97. Smith GC, Pell JP, Pasupathy D, Dobbie R. Factors predisposing to perinatal death related to uterine rupture during attempted vaginal birth after caesarean section: retrospective cohort study. BMJ (Clinical research ed). 2004 Aug 14;329(7462):375. PubMed PMID: 15262772. Pubmed Central PMCID: PMC509342. Epub 2004/07/21. eng.  
98. Landon MB, Hauth JC, Leveno KJ, Spong CY, Leindecker S, Varner MW, et al. Maternal and perinatal outcomes associated with a trial of labor after prior cesarean delivery. The New England journal of medicine. 2004 Dec 16;351(25):2581-9. PubMed PMID: 15598960. Epub 2004/12/16. eng.  
99. Deruelle P, Lepage J, Depret S, Clouqueur E. [Induction of labor and intrapartum management for women with uterine scar]. Journal de gynecologie, obstetrique et biologie de la reproduction. 2012 Dec;41(8):788-802. PubMed PMID: 23142358. Epub 2012/11/13. Mode de declenchement du travail et conduite du travail en cas d'uterus cicatriciel. fre.  
100. Jozwiak M, Dodd JM. Methods of term labour induction for women with a previous caesarean section. The Cochrane database of systematic reviews. 2013;3:CD009792. PubMed PMID: 23543582. Epub 2013/04/02. eng.  
101. Lidegaard O, Jensen LM, Weber T. Technology use, cesarean section rates, and perinatal mortality at Danish maternity wards. Acta obstetricia et gynecologica Scandinavica. 1994 Mar;73(3):240-5. PubMed PMID: 8122506. Epub 1994/03/01. eng. 102. O'Driscoll K, Foley M. Correlation of decrease in perinatal mortality and increase in cesarean section rates. Obstetrics and gynecology. 1983 Jan;61(1):1-5. PubMed PMID: 6823339. Epub 1983/01/01. eng.  
103. Minkoff HL, Schwarz RH. The rising cesarean section rate: can it safely be reversed? Obstetrics and gynecology. 1980 Aug;56(2):135-43. PubMed PMID: 7393501. Epub 1980/08/01. eng.  
104. Annibale DJ, Hulsey TC, Wagner CL, Southgate WM. Comparative neonatal morbidity of abdominal and vaginal deliveries after uncomplicated pregnancies. Archives of pediatrics & adolescent medicine. 1995 Aug;149(8):862-7. PubMed PMID: 7633538. Epub 1995/08/01. eng.  
105. Kroll L, Twohey L, Daubeney PE, Lynch D, Ducker DA. Risk factors at delivery and the need for skilled resuscitation. European journal of obstetrics, gynecology, and reproductive biology. 1994 Jun 30;55(3):175-7. PubMed PMID: 7958161. Epub 1994/06/30. eng.  
106. Eidelman AI, Schimmel MS, Bromiker R, Hammerman C. Pediatric coverage of the delivery room: an analysis of manpower utilization. Journal of perinatology : official journal of the California Perinatal Association. 1998 Mar-Apr;18(2):131-4. PubMed PMID: 9605304. Epub 1998/05/30. eng.  
107. Jacob J, Pfenninger J. Cesarean deliveries: when is a pediatrician necessary? Obstetrics and gynecology. 1997 Feb;89(2):217-20. PubMed PMID: 9015023. Epub 1997/02/01. eng.  
108. Gonzalez F, Juliano S. Is pediatric attendance necessary for all cesarean sections? The Journal of the American Osteopathic Association. 2002 Mar;102(3):127-9. PubMed PMID: 11926690. Epub 2002/04/03. eng.  
109. Hogston P. Is a paediatrician required at caesarean section? European journal of obstetrics, gynecology, and reproductive biology. 1987 Sep;26(1):91-3. PubMed PMID: 3666267. Epub 1987/09/01. eng.  
110. Ong BY, Cohen MM, Palahniuk RJ. Anesthesia for cesarean section--effects on neonates. Anesthesia and analgesia. 1989 Mar;68(3):270-5. PubMed PMID: 2919765. Epub 1989/03/01. eng.  
111. Thomas J, Paranjothy S, James D. National cross sectional survey to determine whether the decision to delivery interval is critical in emergency caesarean section. BMJ (Clinical research ed). 2004 Mar 20;328(7441):665. PubMed PMID: 15023829. Pubmed Central PMCID: PMC381217. Epub 2004/03/17. eng.  
112. Ministério da Saúde do Brasil, Portaria SAS/MS N<sup>o</sup> 371. 2014. <u>http://bvsms.saude.gov.br/bvs/saudelegis/sas/2014/prt0371_07_05_2014.html.</u> 113. Christensson K. Fathers can effectively achieve heat conservation in healthy newborn infants. Acta paediatrica (Oslo, Norway : 1992). 1996 Nov;85(11):1354-60. PubMed PMID: 8955466. Epub 1996/11/01. eng.  
114. Anderson GC, Moore E, Hepworth J, Bergman N. Early skin-to-skin contact for mothers and their healthy newborn infants. The Cochrane database of systematic reviews. 2003 (2):CD003519. PubMed PMID: 12804473. Epub 2003/06/14. eng.  
115. McClellan MS, Cabianca WA. Effects of early mother-infant contact following cesarean birth. Obstetrics and gynecology. 1980 Jul;56(1):52-5. PubMed PMID: 7383488. Epub 1980/07/01. eng. 116. Rabe H, Diaz-Rossello JL, Duley L, Dowswell T. Effect of timing of umbilical cord clamping and other strategies to influence placental transfusion at preterm birth on maternal and infant outcomes. The Cochrane database of systematic reviews. 2012;8:CD003248. PubMed PMID: 22895933. Epub 2012/08/17. eng.  
117. McDonnell M, Henderson-Smart DJ. Delayed umbilical cord clamping in preterm infants: a feasibility study. Journal of paediatrics and child health. 1997 Aug;33(4):308-10. PubMed PMID: 9323618. Epub 1997/08/01. eng.  
118. Papile LA, Burstein J, Burstein R, Koffler H. Incidence and evolution of subependymal and intraventricular hemorrhage: a study of infants with birth weights less than 1,500 gm. The Journal of pediatrics. 1978 Apr;92(4):529-34. PubMed PMID: 305471. Epub 1978/04/01. eng.  
119. McDonald SJ, Middleton P, Dowswell T, Morris PS. Effect of timing of umbilical cord clamping of term infants on maternal and neonatal outcomes. Evidence-based child health : a Cochrane review journal. 2014 Jun;9(2):303-97. PubMed PMID: 25404605. Epub 2014/11/19. eng.  
120. Lumley J, Lester A, Renou P, Wood C. A failed RCT to determine the best method of delivery for very low birth weight infants. Controlled clinical trials. 1985 Jun;6(2):120-7. PubMed PMID: 4006485. Epub 1985/06/01. eng.  
121. Samuels SE, Margen S, Schoen EJ. Incidence and duration of breast-feeding in a health maintenance organization population. The American journal of clinical nutrition. 1985 Sep;42(3):504-10. PubMed PMID: 4036850. Epub 1985/09/01. eng.  
122. Vestermark V, Hogdall CK, Birch M, Plenov G, Toftager-Larsen K. Influence of the mode of delivery on initiation of breast-feeding. Eur J Obstet Gynecol Reprod Biol 1990;38:33–8.  
123. Bruce NG, Khan Z, Olsen ND. Hospital and other influences on the uptake and maintenance of breast feeding: the development of infant feeding policy in a district. Public health. 1991 Sep;105(5):35768. PubMed PMID: 1754659. Epub 1991/09/01. eng.  
124. Ever-Hadani P, Seidman DS, Manor O, Harlap S. Breast feeding in Israel: maternal factors associated with choice and duration. Journal of epidemiology and community health. 1994 Jun;48(3):2815. PubMed PMID: 8051528. Pubmed Central PMCID: PMC1059960. Epub 1994/06/01. eng. 125. Leung GM, Ho LM, Lam TH. Breastfeeding rates in Hong Kong: a comparison of the 1987 and 1997 birth cohorts. Birth (Berkeley, Calif). 2002 Sep;29(3):162-8. PubMed PMID: 12153646. Epub 2002/08/03. eng.  
126. BRASIL. § 4º art. 10, Lei n. 9263, de 12 de janeiro de 1996. Constituição Federal Portaria nº 048/99. Dispõe sobre planejamento familiar e esterilização voluntária. Portal da Legislação: Leis Ordinárias. 1996. Disponível em: http://www.planalto.gov.br/ccivil_03/Leis/L9263.htm.  
APÊNDICE 1 – MEMBROS DO GRUPO CONSULTIVO, GRUPO ELABORADOR E DE REVISÃO EXTERNA.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Associação Brasileira de Obstetrizes e Enfermeiros Obstetras - ABENFO** -->
Kelly Cristina Almeida Borgonove  
Kleyde Ventura de Souza  
Virginia Leismann Moretto

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Agência Nacional de Saúde - ANS** -->
Aline Monte de Mesquita  
Karla Santa Cruz Coelho

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Agência Nacional de Vigilância Sanitária - ANVISA** -->
Maria Ângela da Paz  
Benafran J. Bezerra

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Associação ARTEMIS - Organização não governamental de direitos das mulheres** -->
Raquel Almeida Marques

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Associação Brasileira de Enfermagem - ABEn** -->
Iraci do Carmo de França

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Associação Médica Brasileira - AMB** -->
Antonio Jorge Salomão

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Cochrane Brasil** -->
Maria Regina Torloni

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Comissão Nacional de Incorporação de Tecnologias no SUS - CONITEC** -->
Clarice Alegre Petramale  
**Conselho Federal de Enfermagem – Cofen**  
Maria do Rosário de Fatima B. Sampaio  
**Conselho Federal de Medicina – CFM**  
Almerindo Brasil de Sousa  
Roberto Magliano de Morais

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Conselho Nacional de Saúde - CNS** -->
Maria do Espírito Santo dos Santos  
**Coordenação-Geral de Saúde das Crianças e Aleitamento Materno – Ministério da Saúde**  
Ana Paula da Cruz  
Paulo V. Bonilha Almeida

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Coordenação-Geral de Saúde dos Homens - Ministério da Saúde** -->
Michelle Leite da Silva

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Coordenação-Geral de Saúde das Mulheres - Ministério da Saúde** -->
Maria Esther de Albuquerque Vilela  
Sonia Lansky  
**Departamento de Ciência e Tecnologia – Ministério da Saúde**  
Nathan Mendes  
**Departamento de Gestão e Incorporação de Tecnologias no SUS – Ministério da Saúde** Ávila Teixeira Vidal  
Tacila Pires Mega  
Vânia C. Canuto Santos

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Federação Brasileira das Associações de Ginecologia e Obstetrícia - FEBRASGO** -->
Etelvino de Souza Trindade  
Sérgio Hecker Luz

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Federação Brasileira de Hospitais** -->
Eduardo de Oliveira  
João Henrique Araújo Fernandes  
Walter Lyrio do Valle  
**Escola Nacional de Saúde Pública Sérgio Arouca – Ensp/Fiocruz/Ministério da Saúde** Maria do Carmo Leal

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Instituto Fernandes Figueira** -->
Marcos Dias

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Parto do Princípio - Mulheres em Rede pela Maternidade** -->
Denise Yoshie Niy  
Deborah Rachel A. Delage Silva

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Rede de Humanização do Parto e Nascimento - REHUNA** -->
Daphne Rattner  
Ricardo H. Jones

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Secretaria Especial de Política para as Mulheres** -->
Rurany Ester Silva

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Sociedade Brasileira de Pediatria** -->
Dennis Burns

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Colaboradores convidados** -->
Amílcar José Ribeiro Carvalho  
Jeyner Valério Junior  
Luciana Rodriguez Teixeira  
Maria Elisa Cabanelas Pazos  
Mauro Blini  
Silvana Souza Lima da Silva

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **GRUPO ELABORADOR** -->
João Paulo Souza (Coordenador) - Faculdade de Medicina de Ribeirão Preto/ USP Giordana Campos Braga - Faculdade de Medicina de Ribeirão Preto/ USP  
Melânia Amorim - Universidade Federal de Campina Grande e Instituto de Medicina Integral Professor Fernando Figueira/ IMIP  
Sérgio Marba –Universidade Estadual de Campinas–UNICAMP e Coordenação-Geral de Saúde das Criança e Aleitamento Materno

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Revisores Externos** -->
Marcos Dias - Instituto Fernandes Figueiras/ Fiocruz/Ministério da Saúde Renato Passini - Universidade Estadual de Campinas - UNICAMP  
Rodolfo Pacagnella - Universidade Estadual de Campinas - UNICAMP  
APÊNDICE 2 - DIRETRIZES INCLUÍDAS E EXCLUÍDAS NA BUSCA SISTEMÁTICA.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **DIRETRIZES INCLUÍDAS** -->
NICE/Caesarean section  
<u>http://www.nice.org.uk/guidance/cg132/resources/guidance-caesarean-section-pdf</u>  
Delivery for women with a previous cesarean: guidelines for clinical practice from the French College of Gynecologists and Obstetricians (CNGOF) http://www.ncbi.nlm.nih.gov/pubmed/23810846.

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **DIRETRIZES EXCLUÍDAS** -->
Vaginal Birth After Previous Cesarean Delivery do Colégio Americano de Ginecologia e Obstetrícia (ACOG)  
<u>http://www.acog.org/Resources-And-Publications/Practice-Bulletins/Committee-on-Practice-BulletinsObstetrics/Vaginal-Birth-After-Previous-Cesarean-Delivery</u>  
Vaginal Birth After Previous Cesarean Delivery da Sociedade Canadense de Ginecologia e Obstetrícia (SOCG)  
<u>http://sogc.org/guidelines/guidelines-for-vaginal-birth-after-previous-caesarean-birth-replaces-147-july2004/</u>  
Vaginal Birth After Previous Cesarean Delivery da Sociedade Australiana de Ginecologia e Obstetrícia <u>http://www.health.qld.gov.au/qcg/documents/g_vbac5-1.pdf</u> Safe Prevention of the Primary Cesarean Delivery – ACOG <u>http://www.acog.org/Resources-And-Publications/Obstetric-Care-Consensus Series/Safe-Prevention-ofthe-Primary-Cesarean-Delivery</u>  
Caesarean delivery on maternal request- ACOG  
<u>http://www.acog.org/Resources-And-Publications/Committee-Opinions/Committee-on ObstetricPractice/Cesarean-Delivery-on-Maternal-Request</u>  
South Australian Perinatal Practice Guidelines – Caesarean section  
<u>http://www.sahealth.sa.gov.au/wps/wcm/connect/49ceed004ee1e678aeb1afd150ce4f37/Caesarean+s ection+PPG_June2014.pdf?MOD=AJPERES&CACHEID=49ceed004e1e678aeb1afd150ce4f37</u>  
Projeto Diretrizes do Brasil – 2002  
<u>http://www.projetodiretrizes.org.br/projeto_diretrizes/032.pdf</u>  
APÊNDICE 3 - RESULTADO DA AVALIAÇÃO DA QUALIDADE COM O INSTRUMENTO AGREE II  
**Diretriz avaliada Pontuação Recomenda a utilização da diretriz?** NICE -UK 83% Sim, com modificações específicas. Delivery for women with a previous cesarean: 72% Sim, com modificações guidelines for clinical practice from the French College específicas. of Gynecologists and Obstetricians (CNGOF) VBAC AGOC 44% Não  
|VBAC SOGC|44%|Não|
|---|---|---|
|VBAC Australian|39%|Não|
|Prevention of the Primary Cesarean Delivery - ACOG|33%|Não|
|Caesarean delivery on maternal request- ACOG|33%|Não|
|South Australiana guideline – Caesarean section|33%|Não|
|Projeto Diretrizes do Brasil - 2002|17%|Não|  
NICE- _The National Institute for Health and Care Excellence_ / _United Kingdom Department of Health_ (diretriz publicada em 2011 e atualizada em 2013)  
ACOG – Colégio Americano de Ginecologia e Obstetrícia  
VBAC- Parto Vaginal após Cesariana  
SOGC – Sociedade Canadense de Ginecologia e Obstetrícia  
APÊNDICE 4 – QUESTÕES INCLUÍDAS NO ESCOPO E NÃO RESPONDIDAS POR ESTAS DIRETRIZES

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capitulo 1 - Cuidado centrado na mulher** -->
- Como estas informações devem ser oferecidas? (Por exemplo: através de grupos? Individualmente?)

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capítulo 2 - Cesariana programada** -->
- Existe algum ponto de corte em termos de peso do feto estimado por ecografia para oferecer a operação cesariana à gestante?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com lesões sugestivas de infecção pelo vírus do papiloma humano (HPV)?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com infecção pelo estreptococo beta-hemolítico do grupo B?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida às mulheres em caso de circular de cordão?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com feto morto?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com oligohidrâmnio?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com polihidrâmnio?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com mais de 35 anos de idade?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com doença mental?

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capítulo 3 - Operação cesariana a pedido** -->
- Como aconselhar uma mulher que solicita a operação cesariana? Qual o conteúdo que deve ser discutido? (Utilizar o _fact-sheet_ sobre operação cesariana.)  
- Se a razão apresentada para a solicitação da operação cesariana é ansiedade em relação ao parto ou partofobia, a mulher deve ser encaminhada para avaliação e suporte psicológico?  
- Quais são os possíveis cuidados para tratamento da ansiedade relacionada ao parto e a partofobia? Os  
- grupos de gestante podem contribuir para o tratamento da ansiedade relacionada ao parto e a partofobia?  
- Se mesmo após o aconselhamento a mulher mantém a solicitação de operação cesariana para o parto, uma segunda opinião médica deve ser obtida?  
- No caso de operação cesariana a pedido, existe uma idade gestacional mínima para a sua realização?

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capítulo 6 – Estratégias para redução da taxa de operação cesariana no Brasil** -->
(Este Capítulo relaciona-se à implementação das Diretrizes.)  
- O uso de auditoria com pactuação de metas é recomendado para a redução das taxas de operação cesariana em serviços de saúde?  
- Existe alguma ferramenta que possa auxiliar gestores a determinar de forma individualizada qual seria uma taxa de operação cesariana de referência para serviços de saúde?  
- O monitoramento das taxas de operação cesariana em populações estratégicas (por exemplo, as primíparas e mulheres com cesariana prévia) é recomendado para a redução dessas taxas em serviços de saúde?  
- O uso da classificação de Robson é recomendado para a redução das taxas de operação cesariana em serviços de saúde?  
- Quais são os indicadores de processo sensíveis para monitorar a redução da taxa de operações cesarianas?  
- Quais são as práticas clínicas e não clínicas efetivas e potencialmente efetivas para reduzir as indicações de operação cesariana?  
- Acompanhante do parto  
- Versão cefálica externa  
- Segunda opinião  
- Educação continuada e simulações  
- Indução de trabalho de parto  
- Uso de protocolos clínicos para parto normal após cesariana (VBAC)  
- Mudança do modelo de assistência ao parto (público e privado)  
- Para redução das taxas de operação cesariana, deve ser estimulado o emprego de equipes transdisciplinares na assistência ao trabalho de parto e parto? (Incluindo obstetriz/enfermeiro(a) obstétrico(a), obstetra, pediatra, fisioterapeuta, doula.)  
- A realização do pré-natal e parto com o mesmo médico está associado ao aumento das taxas de operação cesariana? A utilização de plantões obstétricos, com equipes compostas por médicos e enfermeiros (as) obstétricos(a)s/obstetrizes está associado a melhores resultados maternos e neonatais, incluindo a redução da taxa de operação cesariana? A utilização de plantões obstétricos, com equipes compostas somente por médicos, está associada a melhores resultados maternos e neonatais, incluindo a redução  
da taxa de operação cesariana? O modelo de remuneração por procedimento está associado ao aumento das taxas de operação cesariana? O pagamento por desembolso direto ao profissional está associado ao aumento das taxas de operação cesariana? O modelo de pagamento por desempenho está associado a redução das taxas de operação cesariana? O modelo de pagamento por salário fixo mensal está associado a redução da taxa de operação cesariana?  
- A Agência Nacional de Saúde - ANS deve pactuar de taxas de operação cesariana de referência com os convênios e seguros de saúde?  
APÊNDICE 5 - QUESTÕES INCLUÍDAS NO ESCOPO E RESPONDIDAS POR ESTAS DIRETRIZES

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capitulo 1 - Cuidado centrado na mulher** -->
- As gestantes devem receber informações baseadas em evidência e apoio para que realizem decisões  
- informadas sobre o parto?  
- Quem deve oferecer estas informações?  
- Qual o conteúdo e formato destas informações?  
- Deve ser obtido um termo de consentimento informado? Quem deve obter o termo de consentimento  
- informado? Em que momento o consentimento informado deve ser obtido?  
- Quais informações devem ser discutidas com a mulher na obtenção do termo consentimento informado?

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capítulo 2 - Cesariana programada** -->
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres com gestação  
- única e feto em apresentação pélvica? O que deve preceder este oferecimento? Em que momento deve ser realizada a operação?  
- A versão cefálica externa deve ser oferecida para mulheres com gestação única e feto em apresentação pélvica antes da operação cesariana? Onde a versão cefálica externa deve ser realizada? Em que momento deve ser realizada?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres com gestação gemelar não complicada, cujo primeiro feto está em apresentação cefálica?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres com gestações gemelares não complicadas, cujo primeiro feto está em apresentação não cefálica?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres em trabalhos de parto pré-termo sem outras complicações maternas ou fetais?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para gestantes com fetos pequenos para a idade gestacional?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres cujos fetos têm placentas centro-total ou centro-parcial?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para mulheres cujos fetos têm placentas baixas (não centro-totais ou centro-parciais)?  
- Para mulheres com placenta baixa, gestação entre 32e 34 semanas e antecedente de cesariana prévia, um exame ecográfico com Doppler deve ser oferecido para o diagnóstico de acretismo placentário?  
- Em mulheres em que foi possível estabelecer o diagnóstico anteparto de acretismo placentário, deve ser oferecido encaminhamento para um centro de referência? Exame de ressonância magnética (RM) deve ser indicado nestes casos?  
- Quais são as intervenções disponíveis para mulheres com acretismo placentário?  
- Como fazer o diagnóstico da desproporção céfalo-pélvica? A pelvimetria clínica deve ser utilizada para predizer a ocorrência de falha de progressão de trabalho de parto? A pelvimetria clínica deve ser utilizada na decisão quanto à via de parto?  
- O tamanho do pé, a altura materna e estimativas de tamanho fetal (ecográficas ou clínicas) devem ser utilizadas para predizer a ocorrência de falha de progressão de trabalho de parto?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres vivendo infectadas pelo vírus HIV para prevenir a transmissão vertical? Em que circunstâncias esta operação deve ser oferecida para evitar essa transmissão?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres infectadas pelo vírus da hepatite B para prevenir a transmissão vertical?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres infectadas pelo vírus da hepatite C para prevenir a transmissão vertical?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida a mulheres com infecção primária ativa pelo vírus Herpes simples (HSV) durante o terceiro trimestre da gestação?  A operação cesariana deve ser oferecida a mulheres com infecção ativa recorrente pelo vírus Herpes simples?  
- Na ausência de outras indicações, a operação cesariana deve ser oferecida para gestantes obesas? Existe algum valor de índice de massa corporal a partir do qual a cesariana deva ser oferecida?  
- Quais intervenções além das de rotina devem ser realizadas para reduzir a ocorrência de infecção em caso de operação cesariana?

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capítulo 4 – Parto vaginal com cesariana prévia** -->
- A operação cesariana deve ser oferecida de rotina para mulheres com uma cesariana prévia?  
- A operação cesariana deve ser oferecida de rotina para mulheres com duas ou mais cesarianas prévias?  
- As mulheres com duas ou mais cesarianas prévias podem ter um parto vaginal subsequente?  
- A operação cesariana deve ser realizada em mulheres com uma ou mais operações cesarianas prévias e que solicitem nova operação cesariana?  
- Como proceder caso uma mulher com operação cesariana prévia solicite uma nova cesariana?  
- A avaliação ultrassonográfica da cicatriz uterina pós-cesariana segmentar é útil para informar a decisão sobre a via de parto em mulheres com uma ou mais cesarianas prévias?  
- Deve-se oferecer às mulheres com operação cesariana prévia a realização de algum exame subsidiário antes da definição da via de parto?  
- O intervalo entre partos é útil para informar a decisão sobre a via de parto em mulheres com uma ou mais operações cesarianas prévias?  
- Existe um número máximo de operações cesarianas prévias que seja compatível com parto vaginal seguro?  
- Qual deve ser o profissional preferencial para assistência ao trabalho de parto e parto de gestantes com uma operação cesariana prévia?  
- Qual o local onde se deve assistir o trabalho de parto e parto de uma gestante com uma operação cesariana prévia?  
- Existe algum cuidado adicional ou peculiaridade na assistência ao trabalho de parto e parto de gestantes com uma operação cesariana prévia?  
- Em mulheres com operação cesariana prévia, qual deve ser a técnica preferencial para indução de trabalho de parto?

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capítulo 5 – Cuidado do recém-nascido (peculiaridades da operação cesariana)** -->
- Um profissional da saúde treinado em reanimação neonatal deve estar presente na sala de parto para  
- recepcionar o recém-nascido? Precisa ser o pediatra? Tipo de anestesia influencia em qual profissional deve estar presente?  
- Algum cuidado especial em termos de proteção térmica ao recém-nascido por operação cesariana?  
- Contato pele-a-pele precoce deve ser instituído?  
- Na operação cesariana o clampeamento de cordão deve ser precoce ou oportuno (i.e., após dois minutos de nascimento ou parada de pulsação do cordão)?  
- Nas operações cesarianas, suporte adicional deve ser garantido a fim de que a amamentação precoce possa ser iniciada tão logo possível (isto é, imediatamente após o parto ou dentro da primeira hora)?

---

<!-- METADADOS: doenca: Atenção à Gestante a operação cesariana - Diretriz | secao: **Capítulo 6 - Estratégias para redução da taxa de operação cesariana no Brasil** -->
- <mark>Na ausência de outras indicações, a operação cesariana deve ser oferecida como meio para a</mark>  
- <mark>realização da ligadura tubária?</mark>

---

