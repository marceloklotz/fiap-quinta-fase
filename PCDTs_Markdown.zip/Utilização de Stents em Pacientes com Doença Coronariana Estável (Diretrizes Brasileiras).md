<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 20, DE 24 DE JULHO DE 2018.  
Aprova as Diretrizes Brasileiras para Utilização de Stents em Pacientes com Doença Coronariana Estável  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a angioplastia cronariana com stent no Brasil e diretrizes nacionais para a utilização de stents em pacientes com doença coronariana estável;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 302/2017 e o Relatório de Recomendação n<sup><u>o</u></sup> 320 – Dezembro de 2017 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º  Ficam aprovadas as “Diretrizes Brasileiras para para Utilização de Stents em Pacientes com Doença Coronariana Estável”.  
Parágrafo único. As Diretrizes de que trata este artigo, que contêm as recomendações para o uso de stent em pacientes com doença coronariana estável, disponíveis no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, são de caráter nacional e devem utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e eventos adversos relacionados ao uso de stent em pacientes com doença coronariana estável.  
Art. 3º  Esta Portaria entra em vigor na data da sua publicação.  
Art. 4º  Ficam revogadas no Anexo I - Diretrizes para o Implante  de Prótese de Sustentação Intraluminal Arterial (Stent) da Portaria n<sup>o</sup> 726/SAS/MS, de 06 de dezembro de 1999, publicada no Diário Oficial da União nº234-E, de 08 de dezembro de 1999, seção 1, páginas 24-27, as seguintes expressões/alíneas:  
1  
I - Em Indicações Classe I, A – Situações Eletivas A.1: “Pacientes com angina estável ou assintomáticos apresentando testes funcionais positivos”; A.2: “Pacientes com angina estável ou assintomáticos, com testes funcionais positivos”;  
II - Em indicações Classe II, A - Situações Eletivas ou de Emergência A.3: “e/ou isquemia miocárdica detectável pelos testes funcionais”; A.4 – “com presença de isquemia demonstrável funcionalmente” e  
III - O item A.5: “ Tronco de coronária esquerda não protegido por circulação colateral ou cirurgia de revascularização prévia, em pacientes com contraindicação operatória, desde que haja, sistema de suporte cardio-circulatório (esta indicação passará a classe III caso não haja suporte cardio-circulatório no laboratório de cateterismo cardíaco)”.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
MARCO ANTÔNIO DE ARAÚJO FIREMAN  
2

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: ANEXO -->
DIRETRIZES BRASILEIRAS PARA PARA UTILIZAÇÃO DE STENTS EM PACIENTES COM DOENÇA CORONARIANA ESTÁVEL

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **INTROITO** -->
Devido ao grande volume de informações e variabilidade na qualidade, há necessidade de elaboração de sínteses que facilitem o acesso e possibilitem conclusões baseadas em diversas fontes de evidência, fornecendo subsídio científico para a tomada de decisão, tanto para o profissional de saúde quanto para o gestor. Nesse contexto, fontes primárias e secundárias de evidência são utilizadas. As revisões sistemáticas, fontes secundárias de evidência, têm um papel de destaque no desenvolvimento de diretrizes clínicas; as recomendações devem ser idealmente baseadas na melhor evidência disponível, sendo processos sistemáticos de revisão da literatura, que se caracteriza como métodos abrangentes e transparentes, permitindo adequado embasamento para a avaliação da evidência [1].  
Como instrumento para a prática da saúde baseada em evidências, desenvolveram-se sistemas para a avaliação da qualidade da evidência e para a graduação da força da recomendação, com o objetivo de informar respectivamente a confiança nas evidências apresentadas e a ênfase para que seja adotada ou rejeitada uma determinada conduta. Frente à necessidade de uniformização desse processo destaca-se o trabalho do GRADE _working group_ , grupo colaborativo para o desenvolvimento de um sistema padronizado de classificação [1].  
O GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ) é um sistema desenvolvido por um grupo colaborativo de pesquisadores que visa à criação de um sistema universal, transparente e sensível para graduar a qualidade das evidências e a força das recomendações. Atualmente, mais de 80 instituições internacionais utilizam o GRADE, entre elas a Organização Mundial da Saúde (OMS), o _National Institute for Health and Clinical Excellence_ (NICE), a SIGN, o _Centers for Disease Controland Prevention_ (CDC) e a colaboração Cochrane [1].  
No sistema GRADE, a avaliação da qualidade da evidência é realizada para cada desfecho analisado para uma dada tecnologia, utilizando o conjunto disponível de evidência. No GRADE, a qualidade da evidência é classificada em quatro níveis: alto, moderado, baixo e muito baixo. Esses níveis representam a confiança que possuímos na estimativa dos efeitos apresentados [1].  
A classificação inicial da qualidade da evidência é definida a partir do delineamento dos estudos. O ensaio clínico randomizado é o delineamento de estudo mais adequado para questões relacionadas à intervenção, e quando esses são considerados, a qualidade da evidência pelo sistema GRADE inicia-se como alta. Quando apenas estudos observacionais são incluídos, a qualidade da evidência se inicia  
3  
como baixa. A partir da classificação inicial, critérios são definidos e o julgamento desses aspectos permitem reduzir ou elevar o nível de evidência. Os fatores responsáveis pela redução no nível de evidência são: 1) Limitações metodológicas (risco de viés); 2) Inconsistência; 3) Evidência indireta; 4) Imprecisão; 5) Viés de publicação [1].  
Dessa forma, o GRADE caracteriza-se como um instrumento abrangente no processo de avaliação das evidências, compreendendo diversos fatores em sua análise. O foco de avaliação não é apenas no delineamento, como em outros sistemas de avaliação de evidências. A força da recomendação expressa a ênfase para que seja adotada ou rejeitada uma determinada conduta, considerando potenciais vantagens e desvantagens. São consideradas vantagens os efeitos benéficos na melhoria na qualidade de vida, aumento da sobrevida e redução dos custos. São consideradas desvantagens os riscos de efeitos adversos, a carga psicológica para o paciente e seus familiares e os custos para a sociedade. O balanço na relação entre vantagens e desvantagens determina a força da recomendação [1].  
A força da recomendação (forte ou fraca) pode ser a favor ou contra a conduta proposta, representando a confiança que temos que as vantagens sobrepõem às desvantagens do curso de ação proposto. As recomendações fracas e fortes possuem diferentes interpretações e implicações para gestores, pacientes e profissionais de saúde ( **Quadro 1** ). Apesar de não ser usualmente recomendado, situações nas quais o balanço entre vantagens e desvantagens é semelhante ou então incerto, não fornecer uma recomendação é justificável. Contudo essa prática é desestimulada uma vez que essa ausência de recomendação não auxilia no processo de tomada de decisão, causando confusão ao usuário das diretrizes [1].  
**Quadro 1** – Implicação dos graus de recomendação de acordo com o sistema GRADE.  
|Público alvo|Forte|Fraca<br>|
|---|---|---|
|**Gestores**|A recomendação deve ser<br>adotada como política de saúde<br>na maioria das situações**.**|É necessário debate substancial e<br>envolvimento das partes<br>interessadas**.**|
|**Pacientes**|A maioria dos indivíduos<br>desejaria que a intervenção<br>fosse indicada e apenas um<br>pequeno número não aceitaria<br>essa recomendação**.**|Grande parte dos indivíduos<br>desejaria que a intervenção fosse<br>indicada; contudo alguns<br>indivíduos não aceitariam essa<br>recomendaçã**o.**|
|**Profissionais**<br>**de saúde**|A maioria dos pacientes deve<br>receber a intervenção<br>recomendada**.**|O profissional deve reconhecer<br>que diferentes escolhas serão<br>apropriadas para cada paciente<br>para definir uma decisão<br>consistente com os seus valores e<br>preferências**.**|  
**Extraído das** Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – 1. ed., 1. reimpr. – Brasília : Ministério da Saúde, 2015.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **ESTUDOS DE PREFÊRENCIA** -->
4  
Inexistem estudos nacionais sobre as preferências dos pacientes em relação à angioplastia versus a cirurgia de revascularização miocárdica. Estudos internacionais apresentam relevantes informações a respeito da perspectiva dos pacientes. Primeiro, pacientes e profissionais de saúde possuem perspectivas diferentes: enquanto médicos consideraram morte como o pior desfecho possível, alguns estudos demonstraram que o acidente vascular cerebral seria o pior desfecho possível para os pacientes [2, 3] e estes estão mais propensos a escolher a angioplastia do que julgam os médicos [4]. Segundo o estudo de Kipp et al., os pacientes iriam optar pela angioplastia ao detrimento de revascularização aberta mesmo com o dobro do risco de morte ou três vezes o risco de necessitar de novos procedimentos [4].  
Em relação aos desfechos, Pandit et al. observaram que o desfecho “necessitar de novo procedimento”, comumente utilizado nos ensaios clínicos e por vezes o único desfecho com diferença significativa entre angioplastia e cirurgia, quando apresentado aos pacientes entre 20 opções, foi considerado o décimo quinto desfecho em ordem decrescente de importância. Concluem os autores que, para este desfecho basear recomendações, ao menos 14 outros desfechos também precisariam ser considerados.  
Em suma, toda decisão em saúde deve ser orientada pelo melhor conjunto de evidência científica disponível e em acordo com os valores e preferências dos pacientes. Todo profissional de saúde deve considerar ainda potenciais diferenças entre os resultados apresentados na literatura científica e sua realidade local, minimizando ao máximo possíveis danos e riscos aos pacientes. As recomendações destas Diretrizes seguem as normas do sistema GRADE conforme descrito.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **INTRODUÇÃO** -->
As doenças cardiovasculares, compostas pela doença arterial coronariana (DAC) e o acidente vascular cerebral (AVC) representam a maior causa de mortalidade no mundo, responsáveis por cerca de 30% dos óbitos. Os objetivos fundamentais do tratamento da DAC incluem a prevenção, redução dos sintomas anginosos, redução da mortalidade e aumento na qualidade de vida. Atualmente, as opções de tratamento disponíveis são: orientação dietética, atividade física, terapêutica medicamentosa, intervenção coronariana percutânea (ICP) e cirurgia de revascularização miocárdica (CRM) [5].  
A ICP ou angioplastia coronariana foi desenvolvida em 1977 [6] e os stents foram posteriormente (1986) desenvolvidos para reduzir a taxa de reestenose [7]. Apesar dos stents, a taxa de reestenose permaneceu elevada, 15% a 40% em 6 meses [8], levando a introdução dos stents farmacológicos em 1999 [9]. Muitos ensaios compararam a ICP versus a CRM [10-13] e recentemente, os ensaios buscaram avaliar, comparativamente, a CRM com predomínio de enxertos arteriais versus ICP com stents farmacológicos (SF). Os enxertos arteriais estão associados a maior tempo de patência e os SF a menor taxa de reestenose em relação aos stents metálicos [14].

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **ESCOPO** -->
Este documento pretende servir de base para recomendações do Ministério da Saúde do Brasil em relação ao tratamento da **doença coronariana estável** . Apenas os aspectos relacionados à ICP com SF e CRM foram considerados.  
O escopo deste trabalho foi apresentado a especialistas e disponibilizado para consulta pública pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) para definição dos temas. Foram considerados os seguintes subgrupos de  
5  
pacientes com angina estável: 1) doença coronariana multivascular; 2) diabéticos; 3) lesão do tronco da coronária esquerda (TCE).

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **OBJETIVOS** -->
Avaliar a eficácia e segurança da ICP com SF versus CRM na mortalidade, taxa de infarto, AVC e necessidade de nova revascularização em pacientes com doença coronariana estável.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Tipos de estudos** -->
Ensaios clínicos randomizados ou revisões sistemáticas que avaliaram ICP com SF versus CRM. Sem restrições de período de publicação, áreas geográficas, idioma ou tempo de seguimento.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Tipos de participantes** -->
Homens e mulheres de todas as idades, portadores de angina estável. Estudos que incluíram tratamento para infarto agudo do miocárdio (IAM) foram excluídos.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Tipos de intervenção** -->
- 1) Angioplastia com SF, independente da geração do _stent_ .  
- 2) CRM, independentemente da utilização ou não de circulação extracorpórea ou enxertos arteriais.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Definição dos subgrupos_** -->
- 1) Multivasculares (doença que engloba as artérias descendente anterior (notadamente em sua porção proximal), circunflexas - ou seus ramos marginais - , e coronária direita, com lesões acima de 50% no estudo angiográfico, em pelo menos duas projeções)  
- 2) Diabéticos (estudos que tenham selecionado exclusivamente pacientes diabéticos ou estudos que tenham considerado na randomização a presença de diabetes).  
- 3) Lesão em tronco de coronária esquerda (estenose superior a 50% no TCE, independentemente da presença de lesão em outros vasos coronarianos, diabetes ou outras comorbidades).

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Estratégia de busca para identificação dos estudos_** -->
A estratégia de busca teve como objetivos: transparência, imparcialidade e agilidade, com uma abrangência suficiente para identificação dos ensaios randomizados. A base utilizada foi o _Medline_ , consultada até a data de 02 de janeiro de 2017. A busca foi realizada em três etapas:  
- 1) Busca de revisões sistemáticas (RS). Utilizados os termos de interesse (por exemplo, multivascular) seguido de “AND systematic [sb]”.  
6  
- 2) Extração dos estudos originais a partir das RS.  
- 3) Busca de ensaios randomizados mais atuais do que aqueles utilizados nas revisões.  
Detalhes da estratégia de busca e número de referências estão apresentados no **Apêndice 1** .

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Descrição dos estudos_** -->
Detalhes dos estudos incluídos estão apresentados no **Apêndice 2** .

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Extração e análise dos dados_** -->
Os dados foram extraídos dos estudos originais e agrupados em metanálises de acordo com os desfechos de interesse. A heterogeneidade foi avaliada pela estatística do I². Os dados de cada estudo foram agrupados usando um modelo de efeitos aleatórios. Desfechos dicotômicos foram expressos como risco relativo e pelo intervalo de confiança de 95%. Os gráficos de floresta foram realizados por meio do _Review Manager 5.3_ .  Os gráficos estão apresentados no **Apêndice 3** .

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Qualidade dos estudos_** -->
Os estudos incluídos foram analisados em relação a sua qualidade metodológica e as recomendações realizadas de acordo com o método GRADE [15]. Foram avaliados a adequação da randomização, alocação, perda de seguimento e mascaramento. A síntese das evidências está representada por meio do programa GDT [1] no **Apêndice 4** .

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **DOENÇA MULTIVASCULAR** -->
As estratégias de busca para doença multivascular estão apresentadas no **Apêndice 1** . Foram identificadas 55 revisões sistemáticas, a mais recente publicada em dezembro de 2016 [16]. O filtro para ensaios clínicos ( **Apêndice 1** ) não identificou estudos que não tenham sido incluídos nas revisões sistemáticas selecionadas.  
Em ordem cronológica, os estudos originais identificados, foram: CARDia 2010 [17], FREEDOM 2012 [18], VA CARDS 2013 [19], SYNTAX 2010/2013 [20, 21] e BEST 2015 [22]. As características destes ensaios estão resumidas no **Apêndice 2** .  
Os ensaios apresentaram algumas limitações importantes: 1) Pequeno número de participantes com falta de poder estatístico para análise de subgrupos [20] ou para os desfechos primários [17, 19, 22]; 2) Co-intervenção não padronizada [17-20]; 3) Inclusão de angina instável, dor atípica ou de pacientes assintomáticos [17, 19, 20]; 4) Tempo curto de seguimento (apenas três ensaios com resultados entre 3 e 5 anos) [18, 20, 22].  
A **Figura 1** sintetiza a qualidade dos ensaios. A discussão individual sobre a qualidade dos estudos está demonstrada no **Apêndice 3** . A cor verde sinaliza baixo risco  
7  
de viés, a cor amarela representa risco incerto e a cor vermelha ressalta alto risco de viés.  
**Figura 1 -** Síntese da qualidade dos ensaios selecionados na doença multivascular  
<!-- Start of picture text -->
Geracao da sequéncia de alocagao (viés de selegao)<br>Sigilo da sequéncia de alocagao (viés de selecao)<br>Cegamento dos participates (viés de condugao)<br>Cegamento dos avaliadores (viés de deteccao)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>0% 20% 40% 60% 80% 100%<br>= Baixo Incerto Alto<br><!-- End of picture text -->  
A síntese da evidência foi realizada de acordo com o desfecho e tempo de seguimento. Os resultados de 1 ano dos estudos CARDia e SYNTAX foram agrupados com os resultados de 2 anos dos estudos VA CARDS e FREEDOM. Estes foram considerados resultados de curto prazo.  
Os últimos resultados dos estudos FREEDOM, BEST e SYNTAX, com tempo de seguimento médio respectivamente de 3,8; 4,6 e 5 anos foram considerados resultados de médio prazo. Não foram identificados estudos com seguimento superior a 5 anos.  
As metanálises e os gráficos de floresta estão apresentados no **Apêndice 4** . A síntese dos resultados está apresentada nas **Tabela 1** (curto prazo) e **Tabela 2** (médio prazo). Os dados completos com os respectivos efeitos absolutos encontram-se no **Apêndice 5** .

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Resultados de curto prazo na doença multivascular_** -->
Para os desfechos de curto prazo, não foi observada uma diferença significativa na mortalidade, único desfecho com heterogeneidade importante. Tal fato deve-se ao ensaio VA CARDS cuja mortalidade em 2 anos no grupo da ICP foi de 21%, superior aos demais ensaios. Os autores justificam o achado devido a seleção de uma população de maior risco cardiovascular do que a de outros estudos, como por exemplo o ensaio SYNTAX, que avaliou pacientes com menores taxas de hemoglobina glicosilada, tabagismo, infarto prévio e com melhor função cardíaca.  
A ICP, em comparação à CRM, apresentou maiores taxas de infarto e necessidade de nova revascularização, porém, menor taxa de AVC ( **Tabela 1** ).  
**_Tabela 1 -_** _Meta-análises da angioplastia em relação à cirurgia na doença multivascular, estudos de curto prazo._  
|Desfecho<br>Risco Relativo|IC 95%<br>I<sup>2</sup>|
|---|---|  
8  
|Mortalidade|1,67|0,83-3,35|81%|
|---|---|---|---|
|Infarto|1,58|1,23-2,03|0%|
|AVC|0,41|0,20-0,85|30%|
|Nova revascularização|2,56|2,06-3,19|12%|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Resultados de médio prazo na doença multivascular_** -->
Para os desfechos de médio prazo, os resultados da metanálise foram homogêneos. A ICP, em comparação à CRM, apresentou aumento relativo de 43% na mortalidade, aumento da taxa de infarto e da necessidade de nova revascularização. A taxa de AVC foi limítrofe, sem diferença estatística ( **Tabela 2** ).  
**_Tabela 2 –_** _Meta-análises da angioplastia em relação à cirurgia na doença multivascular, estudos de médio prazo._  
|Desfecho|Risco Relativo|I<sup>2</sup>|Risco absoluto|
|---|---|---|---|
||IC 95%||Stent x Cirurgia|
|Mortalidade|1,43|0%|9,9% x 6,9%|
||1,18-1,74|||
|Infarto|2,22|4%|7,7% x 3,4%|
||1,69-2,91|||
|AVC|0,70|0%|2,1% x 3,1%|
||0,49-1,01|||
|Nova revascularização|2,23|0%|13% x 5,8%|
||1,83-2,72|||  
Para a recomendação final do tratamento em pacientes multivasculares foi considerado também os resultados por escore Syntax apresentados como desfechos de 5 anos [21]. Apesar da limitação do escore, cuja análise não teve como critério a randomização dos pacientes de acordo com o escore, a magnitude dos resultados para o desfecho crítico mortalidade foi significativa, com uma diferença em valores absolutos atingindo 9% no escore mais alto ( **Tabela 3** ).  
**_Tabela 3 -_** _Mortalidade de acordo com escore Syntax_  
|Morte|Cirurgia|Stent|P valor|
|---|---|---|---|
|Syntax 0-22|9,3%|10,2%|0,81|  
9  
|Syntax 23-32|9,6%|16,3%|0,047|
|---|---|---|---|
|Syntax ≥ 33|8,8%|17,8%|0,015|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Recomendação para o tratamento da doença multivascular** -->
Em pacientes com doença coronariana estável, com dor anginosa ou equivalente anginoso a despeito da terapia medicamentosa máxima otimizada, passíveis de revascularização tanto por angioplastia quanto por cirurgia e portadores de lesão trivascular, a recomendação é forte, favorável à cirurgia em pacientes com características clinicas ou angiográficas de maior gravidade. Em pacientes com características clínicas e angiográficas de menor risco, a angioplastia poderá ser oferecida como tratamento inicial considerando as preferências do paciente e após esclarecimento das opções e riscos de cada conduta, principalmente quanto a maior chance de necessidade de novo procedimento com a angioplastia.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **DIABETE MÉLITO** -->
A diabete mélito é considerada um importante fator de risco para doença coronariana e frequentemente apresentado em diretrizes de maneira individualizada. Embora alguns autores considerem que a simples presença ou não de diabetes não deveria definir uma conduta de tratamento, optamos por fazer uma metanálise específica para este subgrupo evitando assim possíveis futuros questionamentos.  
Em pacientes diabéticos, a doença coronariana geralmente é mais complexa, com lesões difusas, dificultando a revascularização e levando a maiores riscos de complicações do que em pacientes não diabéticos [17]. A prevalência de diabetes mellitus entre os pacientes encaminhados para revascularização miocárdica é de cerca de 25% [23].  
As estratégias de busca estão apresentadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Critérios de inclusão subgrupo diabéticos_** -->
Revisão sistemática ou estudos primários randomizados, que tenham utilizado stents farmacológicos versus a CRM em pacientes diabéticos, com angina estável e doença multiarterial. Para a metanálise foram utilizados os resultados dos estudos com maior tempo de seguimento.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Resultado da busca subgrupo diabéticos_** -->
Foram identificadas 110 revisões sistemáticas. Entre aquelas com critério de inclusão, a mais recente foi publicada em 2015 e a sua busca foi atualizada em março de 2015 [24]. O filtro para ensaios clínicos ( **Apêndice 1** ) não identificou estudos que não tenham sido incluídos nas revisões sistemáticas. Em ordem cronológica, os estudos originais identificados, foram: CARDia 2010 [17], FREEDOM 2012 [18], VA CARDS 2013 [19], SYNTAX 2010/2013 [20, 21] e BEST 2015 [22]. As características destes ensaios estão resumidas no **Apêndice 2** .  
10  
O risco de viés destes ensaios foi considerado baixo. Os ensaios apresentaram os seguintes vieses: 1) tratamento medicamentoso heterogêneo entre os grupos; 2) angiografia de rotina mais frequente no grupo da angioplastia. As **figuras 2 e 3** sintetizam a qualidade metodológica dos ensaios em relação aos desfechos “necessidade de nova revascularização” ( **Figura 2** ), mortalidade, infarto e AVC ( **Figura 3** ).  
**_Figura 2 -_** _Risco de viés para necessidade de nova revascularização diabéticos_  
<!-- Start of picture text -->
Geragao da sequéncia de alocagio (viés de<br>selegao)<br>Sigilo da sequéncia de alocagio (vies de<br>seleco)<br>Cegamento dos participantes (viés de<br>‘condugio)<br>Cegamento dos avaliadores (viés de detecgo)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>= Baixo Incerto Alto<br><!-- End of picture text -->  
**_Figura 3 -_** _Risco de viés para mortalidade, infarto e AVC._  
<!-- Start of picture text -->
SereeS Se<br>selegao)<br>Son eee)<br>‘selecao)<br>eae ee<br>Cegomento dos valores condugao) (is deco) |<br>Destechosincompletos (vis eat)<br>Rett ecto vsett)<br>uresvise<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Análise dos desfechos em pacientes diabéticos_** -->
Para avaliação da necessidade de nova revascularização, utilizamos os dados dos dois ensaios com resultados de médio prazo: SYNTAXe BEST. Para avaliação da mortalidade em 5 anos, foram extraídos os dados dos três ensaios com maior tempo de seguimento: SYNTAX, FREEDOM e BEST e para avaliação do risco de infarto do miocárdio e AVC em 5 anos, foram extraídos os dados dos dois ensaios com tempo de seguimento adequado e com resultados publicados para o subgrupo de diabetes: SYNTAXe FREEDOM.  
As metanálises destes estudos estão apresentadas no **Apêndice 4** e os achados resumidos na **Tabela 4** . Os dados completos com os respectivos efeitos absolutos encontram-se no **Apêndice 5** . Para a recomendação final foram consideradas as  
11  
significativas diferenças a favor da cirurgia em relação à mortalidade, infarto e necessidade de novo procedimento.  
**_Tabela 4 –_** _Meta-análises da angioplastia em relação à cirurgia em pacientes diabéticos, estudos de médio prazo._  
|Desfecho|Risco Relativo|I<sup>2</sup>|Risco Absoluto|
|---|---|---|---|
||IC 95%||Stent x Cirurgia|
|Mortalidade|1,54|0%|15,5% x 10%|
||1,25-1,89|||
|Infarto|2,36|0%|13,2% x 5,6%|
||1,77-3,14|||
|AVC|0,61|46%|2,6% x 5,0%|
||0,28-1,36|||
|Nova revascularização|2,92|0%|22% x 7%|
||1,93-4,44|||

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Recomendação para o tratamento da doença estável em diabéticos** -->
Em pacientes com doença coronariana estável, com dor anginosa ou equivalente anginoso a despeito da terapia medicamentosa máxima otimizada, passíveis de revascularização tanto por angioplastia quanto por cirurgia e portadores de diabetes, a recomendação é forte, favorável à cirurgia.  
12

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **ESTENOSE EM TRONCO DE CORONÁRIA ESQUERDA** -->
A estenose hemodinamicamente significativa do tronco da artéria coronária esquerda (TCE) é encontrada em cerca de 4% das angiografias coronárias de diagnóstico. Devido à grande área miocárdica sob risco, a lesão do TCE é considerada um caso particular na cardiologia, principalmente quando desprotegida. O termo “lesão desprotegida” aplica-se quando as artérias derivadas do TCE (artéria coronária descendente anterior e  artéria circunflexa esquerda) não possuam artérias colaterais pérvias; não tenham sido previamente revascularizados (pontes) ou caso os enxertos cirúrgicos não estejam patentes [25].  
A busca das revisões sistemáticas de acordo com a estratégia de busca apresentada no **Apêndice 1** retornou 31 revisões. A revisão sistemática mais recente encontrada foi publicada em 2014 com busca até dezembro de 2013 [26]. Os ensaios que avaliaram ICP com SF versus CRM na lesão de TCE, em ordem cronológica, foram: SYNTAX 2010, Boudriot et al 2011 e PRECOMBAT 2011.  A atualização da busca com a estratégia para ensaios clínicos randomizados (ECR) ( **Apêndice 1** ) identificou 1 estudo publicado em 2016: EXCEL [27]. Uma busca manual identificou ainda um estudo publicado em 2016, ensaio NOBLE[28]. Este estudo não foi incluído na metanálise devido a falhas metodológicas importantes: os médicos ou os pacientes, após a randomização, poderiam escolher qual tratamento iriam receber. Observou-se um número significativamente maior (p < 0,0001) de doença em múltiplos vasos no grupo cirúrgico.  
Os ensaios originais estão resumidos no **Apêndice 2** e a qualidade metodológica no **Apêndice 3** . O risco de viés global destes ensaios foi considerado baixo. Os ensaios apresentaram os seguintes vieses: 1) tratamento clínico heterogêneo entre os grupos; 2) angiografia programada no grupo da angioplastia. A **Figura 4** sintetiza a qualidade metodológica dos ensaios.  
13

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Figura 4 -_** _Qualidade da evidência ensaios sobre lesão TCE_ -->
<!-- Start of picture text -->
Geracaéo da sequéncia de alocagao (viés de selegao)<br>Sigilo da sequéncia de alocagao (viés de selegao)<br>Cegamento dos participantes (viés de condugéo)<br>Cegamento dos avaliadores (viés de deteccao)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>= Baixo Incerto BAIto<br><!-- End of picture text -->  
As meta-análises estão apresentadas no **Apêndice 4** . Os resumos das meta-análises estão apresentados nas **Tabela 5** (curto prazo) e **Tabela 6** (médio prazo). Os dados completos com os respectivos efeitos absolutos encontram-se no **Apêndice 5** .  
Considerando o intervalo de confiança, tanto no curto quanto no médio prazo, apenas a necessidade de nova revascularização demonstrou diferença significativa, favorável à cirurgia.  
**_Tabela 5 –_** _Meta-análises da angioplastia em relação à cirurgia em pacientes com estenose no tronco da coronária esquerda, estudos de curto prazo._  
|Desfecho|Risco Relativo|IC 95%|I<sup>2</sup>|
|---|---|---|---|
|Mortalidade|0,61|0,27-1,38|0%|
|Infarto|1,33|0,46-3,83|0%|
|AVC|0,35|0,05-2,3|0%|
|Nova revascularização|2,23|1,30-3,82|0%|  
**_Tabela 6 –_** _Meta-análises da angioplastia em relação à cirurgia em pacientes com estenose no tronco da coronária esquerda, estudos de médio prazo._  
14  
|Desfecho|Risco Relativo|I<sup>2</sup>|Risco Absoluto|
|---|---|---|---|
||IC 95%||Stent x Cirurgia|
|Mortalidade|1,02|48%|8,3% x 7,7%|
||0,73-1,44|||
|Infarto|1,16|34%|6,6% x 6,1%|
||0,77-1,74|||
|AVC|0,65|1%|1,7% x 2,6%|
||0,40-1,07|||
|Nova revascularização|1,76|0%|15,1% x 8,5%|
||1,45-2,14|||  
Para a lesão do TCE consideramos ainda o escore SYNTAX, apesar de suas limitações: os ensaios não apresentaram randomização pelo escore e os resultados foram apresentados de maneira que impossibilita a compilação dos dados ( **Tabela 7)** .  
**_Tabela 7 -_** _Desfechos publicados de acordo com o escore SYNTAX, em estenoses no tronco da coronária esquerda._  
|**Estudo**|**Desfecho(s)**|**ICP < 32**|**CRM <**<br>**32 **|**ICP ≥**<br>**33**|**CRM ≥**<br>**33**|
|---|---|---|---|---|---|
|SYNTAX|Mortalidade<br>(5 anos)|7,9%<br>(n=221)|15,1%<br>(n=196)|20,9%<br>(n=135)|14,1%<br>(n=149)|
|SYNTAX|Infarto<br>(5 anos)|6,1%<br>(n=221)|3,8%<br>(n=196)|11,7%<br>(n=135)|6,1%<br>(n=149)|
|SYNTAX|AVC<br>(5 anos)|1,4%<br>(n=221)|3,9%<br>(n=196)|1,6%<br>(n=135)|4,9%<br>(n=149)|
|SYNTAX|Revasc.<br>(5 anos)|22,6%<br>(n=221)|18,6%<br>(n=196)|34,1%<br>(n=135)|11,6%<br>(n=149)|
|Excel|Morte/Infarto/AVC<br>(3 anos)|13,6%<br>(n=685)|14,2%<br>(n=709)|16,2%<br>(n=229)|13,8%<br>(n=217)|
|PRECOMBAT|Morte/Infarto/AVC/<br>Revasc.(5 anos)|16,4%<br>(n=231)|12,4%<br>(n=201)|24,1%<br>(n=58)|19,1%<br>(n=68)|  
Revasc.: necessidade de nova revascularização miocárdica.  
O grupo elaborador consideroucomo de significativa relevância a diferença observada na mortalidade do estudo SYNTAXentre os grupos com escores < 33 ou ≥ 33.  
15  
Assim, optou por recomendar, para os pacientes com lesão de tronco e passíveis de tratamento por ambas as intervenções:

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Recomendação para estenose em TCE** -->
Em pacientes passíveis de revascularização tanto por angioplastia quanto por cirurgia e portadores de lesão em tronco da coronária esquerda superior a 50%, a recomendação é fraca, favorável à cirurgia. Em pacientes com características clínicas e angiográficas de menor risco, a angioplastia poderá ser oferecida como tratamento inicial considerando as preferências do paciente e após esclarecimento das opções e riscos de cada conduta, principalmente quanto à maior chance de necessidade de novo procedimento com a angioplastia.  
Para os pacientes com lesão em TCE com características clínicas e angiográficas de maior risco, a recomendação é forte, favorável à cirurgia.  
Nos casos de lesão em TCE associada a doença multivascular a recomendação a ser seguida é a recomendação para doença multivascular.  
16

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **APÊNDICE 1** - Estratégias de busca -->
|Subgrupo|Estratégiapara RS|Estratégiapara ECR|
|---|---|---|
|Multivascular|(((multiarterial[All Fields]<br>OR multivascular[All<br>Fields] OR multivessel[All<br>Fields]) AND ("drug<br>eluting"[All Fields] OR<br>drug-eluting[All Fields]))<br>AND systematic[sb])|((multiarterial[All Fields] OR<br>multivascular[All Fields] OR<br>multivessel[All Fields]) AND ("drug<br>eluting"[All Fields] OR drug-<br>eluting[All Fields])) AND<br>(Randomized Controlled Trial[ptyp]<br>AND ("2016/01/01"[PDAT] :<br>"2017/12/31"[PDAT]))|
|Diabetes|diabetes[Title/Abstract]<br>AND ("drug-eluting<br>stents"[Title/Abstract] OR<br>coated[Title/Abstract] OR<br>eluting[Title/Abstract])<br>AND systematic)|diabetes[Title/Abstract] AND<br>("drug-eluting stents"[Title/Abstract]<br>OR coated[Title/Abstract] OR<br>eluting[Title/Abstract]) AND<br>(Randomized Controlled Trial[ptyp]<br>AND ("2015/03/01"[PDAT] :<br>"2017/02/01"[PDAT]))|
|Tronco|(Left main [Title/Abstract])<br>AND ("drug-eluting<br>stents"[Title/Abstract] OR<br>coated[Title/Abstract] OR<br>eluting[Title/Abstract])<br>AND systematic|Left main[Title/Abstract] AND<br>("drug-eluting stents"[Title/Abstract]<br>OR coated[Title/Abstract] OR<br>eluting[Title/Abstract] OR bypass)<br>AND (Randomized Controlled<br>Trial[ptyp] AND<br>("2014/01/01"[PDAT] :<br>"3000/12/31"[PDAT]))|  
ECR: ensaios clínicos randomizados; RS: revisões sistemáticas  
17

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_CARDia 2010_** -->
|**Participantes**|Primeiro ensaio randomizado a comparar a eficácia e segurança<br>da angioplastia versus cirurgia de revascularização miocárdica<br>exclusivamente em pacientes diabéticos.<br>510 pacientes com doença multivascular ou univascular<br>complexa, definida como estenose em artéria descendente<br>anterior ostial ou proximal. Participaram 24 centros no Reino<br>Unido e dois na Irlanda entre 2002 e 2007.|
|---|---|
|**Intervenção**|Stents metálicos (31%) e posteriormente farmacológicos<br>(Cypher)em 69%.|
|**Seguimento**|1 ano|
|**Desfechos**|Os desfechos escolhidos foram importantes para os pacientes e<br>avaliados por um comitê independente e cego para a intervenção<br>(desfecho primário composto de morte, infarto e AVC, 1 ano<br>após a randomização).|
|**Resultados**|Sem diferença: HR 1,25; IC 95% 0,75-2,09.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Boudriot et al 2011_** -->
|**Participantes**|18 a 80 anos. Média 66 anos (62-73), 72% homens no grupo ICP e média<br>69 anos (63-73), 78% homens no grupo CRM. Lesão de TCE > 50% sem<br>proteção, com ou sem doença multivascular. Sintomáticos ou com<br>isquemia documentada.<br>100 randomizados para ICP<br>101 randomizadospara CRM|
|---|---|
|**Intervenção**|Stents com sirolimus|
|**Seguimento**|1ano|
|**Desfechos**|Mediana de 2 stentsporpaciente.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: Resultados em 1 ano Boudriot et al -->
|Desfecho|Angioplastia|Cirurgia|RR|
|---|---|---|---|
||(N=100)|(N=101)|(IC95%)|
|Morte/Infarto/Nova revascularização|19|14|1,37|
||(19%)|(13,9%)|0,73-2,58|  
18  
|Morte|2|5|0,40|
|---|---|---|---|
||(2%)|(5%)|0,08-2,03|
|Infarto|3|3|1,01|
||(3%)|(3%)|0,21-4,89|
|AVC|0|2|0,20|
||(0%)|(2%)|0,01-4,15|
|Nova revascularização|14|6|2,36|
||(14%)|(5,9%)|0,94-5,89|
|Insuficiência renal aguda|1|1|1,01|
||(1%)|(1%)|0,06-15,93|
|Fibrilação/flutter atrial|3|19|**0,16**|
||(3%)|(18,9%)|**0,05-0,52**|
|Tetraplegia|0|1|0,34|
||(0%)|(1%)|0,01-8,17|
|Reesternotomia|0|2|0,20|
||(0%)|(2%)|0,01-4,15|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_PRE COMBAT 2011_** -->
|**Participantes**|Adultos com angina estável, instável, isquemia silenciosa ou infarto sem<br>supra desnível de ST. Lesão de tronco não protegido, maior do que 50% e<br>passível de tratamento por ICP e CRM. Ensaio realizado na Coreia. 300<br>em cadagrupo. Média de idade 62 anos,76,5% sexo masculino.|
|---|---|
|**Intervenção**|Stents comsirolimus|
|**Seguimento**|Tempo médio 2 anos em ambos osgrupos.|
|**Desfechos**|Os desfechos escolhidos foram importantes para os pacientes e avaliados<br>por um comitê independente e cego para a intervenção (desfecho primário<br>composto de morte,infarto e AVC,1 ano após a randomização).|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: Resultados em 2 anos do estudo PRECOMBAT -->
|Desfecho|Angioplastia<br>(N=300)|Cirurgia<br>(N=300)|RR<br>(IC95%)|
|---|---|---|---|  
19  
|Morte/Infarto/AVC|13|14|0,93|
|---|---|---|---|
||(4,4%)|(4,7%)|(0,44-1,94)|
|Morte|7|10|0,70|
||(2,4%)|(3,4%)|(0,27-1,81)|
|Infarto|5|3|1,67|
||(1,7%)|(1,0%)|(0,40-6,91)|
|AVC|1|2|0,50|
||(0,4%)|(0,7%)|(0,05-5,48)|
|Revascularização|26|12|2,17|
||(9,0%)|(4,2%)|(1,11-4,21)|
|Trombose de stent ou de enxerto|1|4|0,25|
||(0,3%)|(1,4%)|(0,03-2,22)|  
Análises realizadas por intenção de tratar. Isquemia foi definida como nova revascularização envolvendo o vaso previamente tratado com estenose maior que 50% associada a sintomas ou sinais de isquemia ou pelo menos 70% de estenose.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: Resultados em 5 anos do estudo PRECOMBAT -->
|Desfecho|Angioplastia|Cirurgia|RR|
|---|---|---|---|
||(N=300)|(N=300)|(IC95%)|
|Morte/Infarto/AVC|25|28|0,89|
||(8,4%)|(9,6%)|(0,53-1,49)|
|Morte|17|23|0,74|
||(5,7%)|(7,9%)|(0,37-3,89)|
|Infarto|6|5|1,20|
||(2,0%)|(1,7%)|(0,37-3,89)|
|AVC|2|2|1,00|
||(0,7%)|(0,7%)|(0,14-7,05)|
|Revascularização|38|21|1,81|
||(13%)|(7,3%)|(1,09-3,01)|  
20  
|**_FREEDOM 20_**|**_12_**|
|---|---|
|**Participantes**|1900 pacientes em 140 centros internacionais. Randomizados 947 para<br>cirurgia e 953 para angioplastia.<br>Diabéticos com doença multivascular (estenose superior a 70% em pelo<br>menos dois vasos epicárdicos e sem envolvimento do tronco da coronária<br>esquerda, tratamento possível tanto por cirurgia quanto por angioplastia).<br>Média de idade: 63,1±9,1 anos<br>Percentual de mulheres: 29%.<br>Percentual de trivasculares: 83%.<br>SYNTAX escore: média 26,2±8,6.|
|**Intervenção**|Stents comsirolimus(51%)epaclitaxel(43%)foram a maioria|
|**Seguimento**|Tempo médio de acompanhamento: 3,8 anos, intervalo interquartil 2,5 a<br>4,9anos.|
|**Desfechos**|Morteporqualquer causa,infarto do miocárdio não fatal,AVC não fatal.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_VA CARDS 2013_** -->
|**Participantes**|198 pacientes diabéticos.<br>Estudo americano, realizado em 22 centros pelo_Department of_<br>_Veterans Affairs_entre 2006 e 2010, selecionando pacientes com<br>diabetes e doença multivascular ou doença proximal da artéria<br>descendente anterior. Necessária comprovação de isquemia para<br>estenoses entre 50% e 70%, sem diferenciação entre angina<br>estável ou instável. Pacientes com lesão de tronco foram<br>excluídos. Interrompidopelo recrutamento lento.|
|---|---|
|**Intervenção**|Stents Taxus (35), Cypher (20), XIENCE/PROMUS (18),<br>Endeavor (2), mixed drug-eluting stents (16), mixed bare-metal<br>stents(1).|
|**Seguimento**|2 anos|
|**Desfechos**|morte por todas as causas e infarto não fatal (desfecho primário),<br>AVC, morte cardíaca, trombose de stent, internação por causa<br>cardiológica e necessidade de nova revascularização.|
|**Notas**|Estudo interrompido precocemente, sem poder estatístico e sem<br>diferençapara desfecho combinado: HR 0,89,IC95% 0,47-1,71|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_SYNTAX 2010/2013_** -->
|**Participantes**1800 pacientes dos Estados Unidos e de 17 países europeus<br>Cirurgia 897 pacientes; Angioplastia 903 pacientes.|
|---|
|Trivasculares ou lesão de tronco não revascularizados previamente|
|passíveis de tratamento por angioplastia e cirurgia.|
|Média de idade: Cirurgia 65,2±9,7;Angioplastia 65,0±9,8|  
21  
||Sexo masculino: Cirurgia 78,9%;Angioplastia 76,4%;|
|---|---|
|**Intervenção**|Angioplastia com stent farmacológico(Placitaxel)|
|**Seguimento**|Acompanhamentopor até 5 anos.|
|**Desfechos**|Combinado de morte por qualquer causa, infarto, AVC, nova<br>revascularização.|
|**Notas**|Estudo de não inferioridade, limite superior do intervalo de confiança<br>considerado 6,6%.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Resultados de 1 ano do ensaio SYNTAX multivascular** -->
||Angioplastia<br>(n= 891)|Cirurgia<br>(n = 849)|RR<br>(IC 95%)|
|---|---|---|---|
|Morte|39|30|1,24|
||(4,4%)|(3,5%)|(0,78-1,98)|
|IAM|43|28|1,46|
||(4,8%)|(3,3%)|(0,92-2,33)|
|AVC|5|19|0,25|
||(0,6%)|(2,2%)|(0,09-0,67)|
|Revascularização|120|50|2,29|
||(13,5%)|(5,9%)|(1,67-3,14)|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Resultados estudo SYNTAX multivascular, seguimento 5 anos** -->
||Angioplastia<br>(n=546)|Cirurgia<br>(n=549)|RR<br>(IC 95%)|
|---|---|---|---|
|Desfecho combinado|123|201|1,7|
||(22,5%)|(36,6%)|(1,36-2,13)|
|Morte/AVC/IM|118|71|1,64|
||(21,6%)|(12,9%)|(1,22-2,20)|
|Morte|78|46|1,65|
||(14,3%)|(8,4%)|(1,15-2,38)|
|Morte cardiológica|48|20|2,34|
||(8,8%)|(3,6%)|(1,39-3,95)|
|IAM|55|17|3,23|
||(10,1%)|(3,1%)|(1,87-5,56)|
|AVC|16|19|0,85|
||2,9%|3,5%|(0,43-1,71)|
|Revascularização|130|61|2,24|
||(23,8%)|(11,1%)|(1,65-3,04)|  
22

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Resultados em 5 anos do estudo SYNTAX em portadores de lesão de TCE_** -->
|Evento|Angioplastia|Cirurgia|RR|
|---|---|---|---|
||(n= 357)|(n= 348)|(IC 95%)|
|Evento combinado|130|103|1,23|
||(36,4%)|(29,6%)|(1,0-1,52)|
|Morte/AVC/IM|67|69|0,95|
||(18,8%)|(19,8%)|(0,70-1,28)|
|Morte|45|48|0,91|
||(12,6%)|(13,8%)|(0,63-1,33)|
|Morte cardíaca|30|23|1,27|
||(8,4%)|(6,6%)|(0,75-2,14)|
|AVC|5|14|0,35|
||(1,4%)|(4,0%)|(0,13-0,96)|
|IM|28|16|1,71|
||(7,8%)|(4,6%)|(0,94-3,1)|
|Revascularização|90|49|1,79|
||(25,2%)|(14,1%)|(1,31-2,45)|
|Nova angioplastia|73|43|1,65|
||(20,4%)|(12,4%)|(1,17-2,34)|
|Nova cirurgia|26|6|4,22|
||(7,3%)|(1,7%)|(1,76-10,14)|
|Trombose de stent ou oclusão do<br>enxerto|17<br>(4,8%)|14<br>(4,0%)|1,18<br>(0,59-2,36)|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Estudo BEST 2015_** -->
**Participantes** 880 pacientes com estenose superior a 70% em dois ou mais vasos. Realizado em 27 centros na Ásia. Excluídos pacientes com lesão em TCE. Subgrupo de diabéticos randomizados para cirurgia: 186; subgrupo de diabéticos randomizados para angioplastia: 177 (stent de segunda geração, com everolimus).  
23  
|**Intervenção**|Stent segunda geração everolimus.|
|---|---|
|**Seguimento**|Tempo de seguimento médio 4,6 anos.|
|**Desfechos**|Primário: combinação de morte, infarto ou revascularização do<br>vaso alvo até dois anos apósprocedimento.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Resultados estudo BEST** -->
||Angioplastia<br>N = 438|Cirurgia<br>N = 442|RR|
|---|---|---|---|
|Desfecho combinado|67|47|1,44|
||(15,3%)|(10,6%)|(1,02-2,04)|
|Morte/AVC/IM|52<br>(11,9%)|42<br>(9,5%)|1,25<br>(0,85-1,84)|
|Morte|29|22|1,33|
||(6,6%)|(5,0%)|(0,78-2,28)|
|Morte cardiológica|18|16|1,14|
||(4,1%)|(3,6%)|(0,59-2,20)|
|IAM|21|12|1,77|
||(4,8%)|(2,7%)|(0,88-3,55)|
|AVC|11|13|0,85|
||2,5%|2,9%|(0,39-1,89)|
|Revascularização|48|24|2,02|
||(11%)|(5,4%)|(1,26-3,24)|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Estudo EXCEL 2016_** -->
|**Participantes**|1905 pacientes com lesão de tronco (>50%) de complexidade<br>baixa ou moderada (Escore Syntax ≤ 32. Grupo ICP 948<br>pacientes. CRM 957 pacientes.<br>ICP: 66 (±9,6) anos; 76,2% homens.<br>CRM: 65,9 (9,5)anos;77,5% homens.|
|---|---|
|**Intervenção**|Stent com everolimus. Média 2,4 stents por paciente.|
|**Seguimento**|Mediana 3 anos, mínimo de 2 anos.|
|**Desfechos**|Primário: desfecho combinado (morte, infarto e AVC). Estudo de<br>não inferioridade,margem 4,2%)em 3 anos.|  
24

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **Resultados estudo EXCEL 2016 3 anos** -->
||Angioplastia<br>N = 948|Cirurgia<br>N = 957|RR<br>(IC 95%)|
|---|---|---|---|
|Morte/AVC/IM|137|135|1,02|
||(14,5%)|(14,1%)|(0,82-1,28)|
|Morte|71|53|1,35|
||(7,5%)|(5,5%)|(0,96-1,91)|
|Morte cardiológica|39|33|1,19|
||(4,1%)|(3,4%)|(0,76-1,88)|
|IAM|72|77|0,94|
||(7,6%)|(8,0%)|(0,69-1,29)|
|AVC|20|26|0,78|
||(2,1%)|(2,7%)|(0,44-1,38)|
|Revascularização|114|67|**1,72**|
||(12,0%)|(7,0%)|**(1,29-2,29)**|  
25

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_PRE COMBAT 2011 Análise crítica_** -->
|**Randomização**|Realizadapor computador e com envelopes lacrados.|
|---|---|
|**Perdas e****_cross_**<br>**_over_**|Não significativa.|
|**Análise ITT**|Não,estudo de não inferioridade com análise_as-treated_.|
|**Cegamento**|Comitê avaliador cegopara os desfechos.|
|**Notas**|O ensaio PRECOMBAT foi considerado de baixa qualidade. Estudo<br>sem poder para avaliar diferença entre os grupos devido ao baixo<br>número de eventos e com pouco tempo de acompanhamento. Analisou<br>população com angina estável, síndrome aguda ou infarto. Grupo ICP<br>recebeu tratamento heterogêneo, maior quantidade de antiplaquetários,<br>bloqueadores do canal de cálcio e betabloqueadores. Ainda, realizou<br>angiografia de rotina, mesmo assintomáticos, o que pode ter levado a<br>um maior número de revascularizações.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_FREEDOM 2012 Análise crítica_** -->
|**Randomização**|Realizada por meio de um sistema telefônico, com balanceamento por<br>local, equilibrando o número de angioplastia e cirurgia em cada centro.<br>Dentre 32.966 pacientes selecionados para avaliação de elegibilidade,<br>3.309 foram considerados elegíveis, 1409 não deram consentimento,<br>1900 foram randomizados.|
|---|---|
|**Perdas e****_cross_**<br>**_over_**|953 foram randomizados para angioplastia, dos quais 5 realizaram<br>cirurgia, 3 desistiram antes do procedimento, 3 morreram antes do<br>procedimento e 3 não realizaram qualquer procedimento, totalizando<br>939 (98,53%) angioplastias. Para a cirurgia, foram randomizados 947<br>pacientes, 18 realizaram angioplastia, 26 desistiram antes do<br>procedimento, 3 morreram antes do procedimento e 7 não realizaram<br>qualquer procedimento, totalizando 893 (94,3%) cirurgias. No grupo<br>angioplastia, 16 pacientes saíram do estudo após o procedimento e 43<br>foram perdidos no seguimento (6,2%), enquanto na cirurgia 36<br>desistiram e 51 foramperdidos no seguimento(9,2%).|
|**Análise ITT**|sim|
|**Cegamento**|Considerado não importantepara os desfechos avaliados.|
|**Notas**|Qualidade: boa, com randomização adequada, alto percentual de<br>pacientes realizaram a intervenção proposta e desfechos importantes<br>relatados.<br>Viés de atrito com risco moderadopara os desfechos de morte,AVC e|  
26  
infarto se considerarmos a análise do pior cenário. Limitações: 1) seguimento não foi cego, os pacientes podem ter sido tratados de maneira diferente de acordo com a intervenção. Há relato de maior uso de tienopiridínicos no grupo da angioplastia. 2) A presença de sintomas anginosos ou isquemia em testes diagnósticos faziam parte dos critérios de inclusão, sem definição clara de angina estável ou instável.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Syntax Análise crítica_** -->
|**Randomização**|Sim, por meio de um sistema de resposta de voz. Não há relato sobre o<br>sigilo de alocação.|
|---|---|
|**Perdas e****_cross_**<br>**_over_**|Randomizados para cirurgia 897 pacientes, 549 com doença<br>multivascular, 143 com doença multivascular e diabetes. Randomizados<br>para angioplastia 903 pacientes, 546 com doença multivascular e 153<br>com doença multivascular e diabetes. Os grupos foram adequadamente<br>balanceados e o número de perdas de acompanhamento ou de_cross over_<br>não foram significativos. Analisados os dados de 94,6% dos pacientes<br>randomizados para cirurgia e 98,7% dos pacientes randomizados para<br>angioplastia.|
|**Análise ITT**|sim|
|**Cegamento**|Considerado não importantepara os desfechos avaliados.|
|**Notas**|Qualidade: boa, com randomização adequada, alto percentual de<br>pacientes realizaram a intervenção proposta e desfechos importantes<br>relatados.<br>Comitê independentepara avaliação dos desfechos.|
||Limitações incluem: 1) tratamento clínico heterogêneo, com o grupo da<br>angioplastia recebendo mais medicamentos cardiológicos; 2) pequeno<br>percentual de cirurgias com enxertos vasculares (mamária bilateral em<br>30,6%) e sem circulação extra-corpórea (13,9%); 3) elevado número de<br>stents por paciente (média 5,3 ±2,3 no grupo multivascular versus média<br>nos Estados Unidos 1,6 por procedimento em busca de revascularização<br>completa, sem necessidade de comprovação de isquemia no segmento<br>tratado; 4) stent de primeira geração, inferior aos novos SF segundo<br>autores; 5) falta de poder estatístico para análise de subgrupos; 6)<br>inclusão de angina instável, dor atípica ou assintomáticos com isquemia<br>demonstrada por exames complementares que limitam a validade<br>externa.|  
**_VA CARDS 2013 Análise crítica_ Randomização** Realizada <u>pelo centro coordenador de acordo com o uso de insulina e</u>  
27  
||nível de hemoglobinaglicosilada.|
|---|---|
|**Perdas e****_cross_**<br>**_over_**|5 pacientes do grupo cirúrgico e um da angioplastia abandonaram antes<br>de receberem o tratamento._Cross over_de 11 pacientes do grupo<br>cirúrgico e 6 da angioplastia.|
|**Análise ITT**|sim|
|**Cegamento**|Desfechoprimário avaliadopor comitê independente e cego|
|**Notas**|Limitações: estudo sem poder estatístico por tamanho amostral<br>inadequado, calculado 790, porém apenas participaram 97 no grupo<br>cirurgia e 101 no grupo angioplastia. Tempo médio de seguimento<br>relativamente curto para a avaliação do impacto das intervenções: 2<br>anos.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: CARDia 2010 Análise crítica -->
|**Randomização**|Randomização adequada, realizada com auxílio de um sistema<br>computacional oupor telefone.|
|---|---|
|**Perdas e****_cross_**<br>**_over_**<br>**Análise ITT**|Os grupos cirurgia e angioplastia foram adequadamente<br>balanceados e o número de perdas de acompanhamento ou de<br>_cross over_não foram significativos.<br>sim|
|**Cegamento**|Desfechos avaliados por comitê cego e independente.|
|**Notas**|A principal limitação do ensaio CARDia é sua falta de poder<br>estatístico para avaliação do desfecho primário, o tamanho<br>amostral mínimo calculado de 600 participantes não foi<br>alcançado. Outras limitações incluem a utilização de stents<br>metálicos em cerca de um terço dos pacientes. O tempo de<br>seguimento<br>de<br>1<br>ano<br>também<br>pode<br>ser<br>considerado<br>inadequadamente curto para avaliação do impacto do tratamento.<br>Por fim, não foram analisados exclusivamente pacientes com<br>angina estável ou pacientes com doença multivascular, reduzindo<br>a validade externa destes dados.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_Boudriot et al 2011 Análise crítica_** -->
|**Randomização**|Realizadapor computador,em instituição independente.|
|---|---|
|**Perdas e****_cross_**|3 randomizados para ICP foram para cirurgia.|
|**_over_**||
|**Análise ITT**|Sim.|
|**Cegamento**|Desfechos avaliadospor comitê cego e independente.|  
28  
**Notas** Tratamento clínico “de acordo com a prática” em ambos os grupos. Tamanho amostral calculado para teste de não inferioridade, considerando que 15% dos pacientes tratados com cirurgia e 12,5% daqueles tratados com ICP teriam o desfecho combinado (morte por qualquer causa, infarto, necessidade de nova revascularização em 1 ano). Sem poder estatístico para análise individual dos desfechos.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: BEST 2015 Análise crítica -->
|**Randomização**|Randomização adequada, por sistema computacional.|
|---|---|
|**Perdas e****_cross_**<br>**_over_**|Perda de seguimento pequena, 2 na cirurgia e 1 na angioplastia.|
|**Análise ITT**|Sim.|
|**Cegamento**|Desfechos avaliados por comitê cego e independente.|
|**Notas**|Limitações: estudo terminou precocemente devido a recrutamento<br>lento, sem poder estatístico para avaliação independente dos<br>desfechos. Tratamento medicamentoso diferente entre os grupos<br>no seguimento.|

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: Excel Análise crítica -->
|**Randomização**|Sim, por meio de um sistema de resposta de voz. Não há relato sobre<br>o sigilo de alocação.|
|---|---|
|**Perdas e****_cross_**<br>**_over_**|942/948 grupo ICP fizeram a revascularização.<br>940/957grupo CRM fizeram a revascularização.|
|**Análise ITT**|Sim|
|**Cegamento**|Desfechos avaliadospor comitê independente cego.|
|**Notas**|Tratamento clínico de acordo com diretrizes. Angiografia de rotina<br>nãopermitida.|  
29  
**APÊNDICE 4 –** Meta-análise dos ensaios selecionados

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.1 Mortalidade de curto prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight_M-H, RiskRandom, Ratio95%CI_ Year MH, Random,Risk Ratio95% Cl<br>SYNTAX 39 801 «30 «849 28.8% 1.24 (0.78, 1.98] 2009<br>CARDIA 8 248 8 242 20.2% 0.98 (0.37, 2.56] 2010<br>FREEDOM 62 953 87 (947 30.5% 1,08 [0.76, 1.53] 2012<br>VACARDS 2 101 5 197 20.5%  — 8.19[3.18, 21.08] 2013 ——<br>Total (95% Cl) 2193 2235 100.0% 1.67 (0.83, 3.35]<br>Total events 130 100<br>Heterogeneity: Tau®= 0.38; Chi*= 16.16, df= 3 (P = 0.001); F= 81% bor OT 7 to 100<br>Test<br>for overall effect Z= 1.44 (P = 0.15) FavoriCP Favor CRM<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.2 Infarto de curto prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight_M-H, RiskRandom, Ratio95%CI_ Year MH, Random,Risk Ratio95% Cl<br>SYNTAX 43° 801 28 849 28.2% 1.46 (0.92, 2.33] 2009<br>CARDIA 25 248 © 14 242 15.5% 1.74 (0.93, 3.27] 2010<br>FREEDOM 62 953 42 «947 42.3% 4.47 (1.00, 218] 2012<br>VACARDS 16 101 15 197 14.0% 2.08 1.07, 4.03] 2013<br>Total (95% Cl) 2193 2235 100.0% 1.58 [1.23, 2.03] °<br>Total events 146 99<br>Heterogeneity:<br>Test Tau®= 0.00; Chi*=1.01, df= 3 (P = 0.80); P= 0% bot + 1 Too!<br>for overall effect: Z= 3.62 (P = 0.0003) FavoriCP Favor CRM<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.3 AVC de curto prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight _M-H,RiskRandom, Ratio95% CI_ Year MH, Random,Risk Ratio95% Cl<br>SYNTAX 5 891 19 849 -33.2% 0.26 (0.09, 0.67] 2009 ——<br>CARDIA 1 248 7 242 10.7% 0.14 (0.02, 1.12) 2010<br>FREEDOM 14 953-24 947 49.6% 0.58 (0.30, 1.11] 2012<br>VACARDS 1 101 1 197 65% 1.95 [0.12, 30.86) 2013<br>Total (95% Cl) 2193 2235 100.0% 0.41 [0.20, 0.85] >_><br>Total events n 5<br>Heterogeneity. Tau*= 0.17; Chi*= 4.29, df= 3 (P = 0.23); P= 30%<br>Test<br>for overall effect Z= 2.40(P = 0.02) oot On yor IOP Favor CRM” 00<br><!-- End of picture text -->  
30

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.4 Revascularização de curto prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight _M-H, RiskRandom, Ratio95% CI_ Year MH, Random,Risk Ratio95% Cl<br>SYNTAX 120 891 50-849 38.8% 2.29 (1.67, 3.14) 2009 -<br>CARDIA 29 248 5 242 5.4% — §.66 (2.23, 14.38] 2010 ——<br>FREEDOM 120 953 45947 36.1% 2.65 (1.90, 3.69] 2012 7<br>VA CARDS 31 101-25 197 19.7% 2.42 (1.51, 3.87] 2013 =~<br>Total (95% Cl) 2193 2235 100.0% 2.56 [2.06, 3.19] °<br>Total events 300 125<br>Heterogeneity. Tau*= 0.01; Chi*= 3.39, df= 3 (P = 0.33); P= 12%<br>Test<br>for overall effect Z= 8.41 (P < 0.00001) oot or ICP Favor CRM” a0<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.5 Mortalidade de médio prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventsRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>FREEDOM 118 95386 947 85.7% 1,36 (1.05, 1.77] 2012<br>SYNTAX 2013 78 891 = 46-849 31.1% 1.62 (1.14, 2.30) 2013 -<br>BEST 29 4380-22, «442«13.3% 1.33 (0.78, 2.28] 2015<br>Total (95% Cl) 2282 2238 100.0% 1.43 (1.18, 1.74] o<br>Total events 226 154<br>Heterogeneity. Tau*= 0.00; Chi*= 0.66, df= 2 (P = 0.72); P= 0%<br>Test<br>for overall effect: Z= 3.59(P = 0.0003) Oot or ICP Favor CRM. ‘a0<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.6 Infarto de médio prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventsRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>FREEDOM 99 953° 48947 60.5% 2.05 (1.47, 286) 2012 ca<br>SYNTAX 2013 55 891 = 17 «B49 -24.7% 3.08 [1.80, 5.27] 2013 ><br>BEST 2 438012: «442: «14.8% 1.77 (0.88, 3.55] 2015<br>Total (95% Cl) 2282 2238 100.0% 2.22 [1.69, 2.91] a<br>Total events 175 7<br>Heterogeneity. Tau*= 0.00; Chi*= 2.09, df= 2 (P = 0.36); P= 4%<br>Test<br>for overall effect: Z= 5.76(P < 0.00001) Oot or ICP Favor CRM. ‘a0<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.7 AVC de médio prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventsRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>FREEDOM 2295337 947 48.7% 0.59 (0.35, 0.99] 2012<br>SYNTAX 2013 16 891 = 19-849. -30.4% 0.80 (0.42, 1.55] 2013<br>BEST 11 43813442 21.0% 0.85 (0.39, 1.89] 2015<br>Total (95% Cl) 2282 2238 100.0% 0.70 (0.49, 1.01]<br>Total events 49 69<br>Heterogeneity. Tau®= 0.00; Chi*= 0.82, df= 2 (P = 0.67); P= 0%<br>Test<br>for overall effect: Z= 1.92(P = 0.05) oOo yor iCP Favor CRM 00<br><!-- End of picture text -->  
31

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.8 Revascularização de médio prazo, ICP versus CRM, doença multivascular_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight _M-H,RiskRandom, Ratio95% CI_ Year MH, Random,Risk Ratio95% Cl<br>FREEDOM 120 953° «45947 35.8% 2.65 (1.90, 3.63) 2012 -<br>SYNTAX 2013 130 891 1-849 «48.7% 2.03 (1.52, 271] 2013 -<br>BEST 48 438 024-442, :17.6% 2.02 1.26, 3.24] 2015 ~_<br>Total (95% Cl) 2282 2238 100.0% 2.23 [1.83, 2.72) +<br>Total events 298 130<br>Heterogeneity. Tau®= 0.00; Chi*= 1.62, df= 2 (P = 0.44); P= 0%<br>Testfor overall effect Z= 7.96q (P < 0.00001): ' oor O4 FavorICP 1 Favor CRM10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **4.9 Meta-análise da necessidade de nova revascularização, ICP versus CRM, pacientes diabéticos, 5 anos.** -->
<!-- Start of picture text -->
Study or Subgroup EventsAngioplastiaTotal_EventscRM Total Weight_M-H, RiskRandom, Ratio95%CI_Year MH, Random,Risk Ratio95% Cl<br>Syntax 2014 St 15318 «143—«73.5% 2.65 (1.63, 4.31] 2014<br>BEST 2015 26 197 7 204 26.5% 3.85 1.71, 8.66] 2015 —<br>Total (95% CI) 350 347 100.0% 2.92 [1.93, 4.44] ad<br>Total events 7 25<br>TesttoHet vert Tau?oact= 28080.00; Chit= 0.60,<Cot00))df= 1 (P= 0.44);F= 0% 20 ortpioplasia Favercri 1<br>= Favor angioplastia Favor CRM<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.10 Meta-análise da mortalidade, ICP versus CRM, pacientes diabéticos, 5 anos_** -->
<!-- Start of picture text -->
Study or Subgroup _EventsAngioplastia_Total_EventscRM Total Weight_M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>FREEDOM 2012 155 ««953°—«103«47 | 79.1% 1.50 (1.19, 1.89] 2012<br>Syntax 2014 3115314 143 12.3% 2.07 [1.15,3.73] 2014 ——<br>BEST 2015 16 197 «= 13-204 8.6% 41.27 (0.63, 2.58] 2015<br>Total (95% Cl) 1303 1294 100.0% 1.54 [1.25, 1.89] o<br>Total events, 202 130<br>TostonHet ovora actTau? = 2-4070.00; Chit=‘P <b1.31,odot)df= 2 (P=‘ 0.62);> P= 0% 001 ores 10 100<br>= Favor angioplastia Favor cirurgia<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.11 Meta-análise infarto, ICP versus CRM, pacientes diabéticos, 5 anos_** -->
<!-- Start of picture text -->
Study or Subgroup EventsAngioplastiaTotal_EventscRM Total Weight_M-H, RiskRandom, Ratio95%CI_Year MH, Random,Risk Ratio95% Cl<br>FREEDOM 2012 132-9537 GAT | 93.0% 2.30 (1.71, 3.10) 2012<br>Syntax 2014 14 153 4143 7.0% 3.27 [1.10,9.71] 2014 -——<br>Total (95% Cl) 1106 1090 100.0% 2.36 (1.77, 3.14] °<br>Total events 146 61<br>TesttororllofctHet Tau? = =8ee@0.00; Chit= 0.37,<COc000) df= 1 (P= 0.84);F= 0% 20 ortgoplasia Faveroiuta 7<br>= Favor angioplastia Favor cirurgia<br><!-- End of picture text -->  
32

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.12 Meta-análise AVC, ICP versus CRM, pacientes diabéticos, 5 anos_** -->
<!-- Start of picture text -->
Study or Subgroup AngioplastiaEvents Total_EventscRM Total Weight M-H,Random,Risk Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>FREEDOM 2012 23 9534347 68.9% 0.47 (0.29,0.76) 2012<br>Syntax 2014 6 153 5 143 31.1%<br>1.42(0.35, 3.59) 2014<br>Total (95% Cl) 1106 1090 100.0% 0.64 [0.28, 1.36]<br>Total events 29 54<br>= = Favor angioplastia Favor cirurgia<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.13 Meta-análise mortalidade global curto prazo (1 a 2 anos), lesão de tronco_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight _M-H,RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>PRECOMBAT 2011 7 300 10 300 74.2% 0.70 (0.27, 1.81] 2011<br>Boudriot 2011 2 100 5 101 25.8% 0.40 (0.08, 2.03] 2011<br>Total (95% Cl) 400 401 100.0% 0.64 (0.27, 1.38]<br>Total events 8 15<br>Heterageneity: Tau= 0,00; " Chi*= 0.33, df= 1 (P= 0.57), P= 0%<br>Testfor overall effect Z= 1.19 (P = 0.23): ' oor O4 Favor ICP 1 Favor CRM]10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.14 Meta-análise infarto curto prazo (1 a 2 anos), lesão de tronco_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight _M-H,RiskRandom, Ratio95% CI_Year M-H, Random,Risk Ratio95% Cl<br>PRECOMEBAT 2011 5 300 3 300 55.1% 1.87 (0.40, 6.91] 2011<br>Boudriot 2011 3 100 3 101 44.9% 1.01 (0.21, 4.89) 2011<br>Total (95% Cl) 400 401 100.0% 1.33 [0.46, 3.83]<br>Total events 8 6<br>Heterageneity: Tau= 0,00; q Chi*= 0.21, df= 1 (P= 0.64), P= 0%<br>Testfor overall effect: Z= 0.53 (P = 0.60): ' oor O4 Favor ICP 1 Favor CRM]10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.15 Meta-análise AVC curto prazo (1 a 2 anos), lesão de tronco_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsicp Total EventscRM Total Weight _M-H,RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>PRECOMEBAT 2011 1 300 2 300 61.4% 0,50 (0.05, 5.48] 2011<br>Boudriot 2011 o 100 2 101 38.6% 0.20 (0.01, 4.15] 2011<br>Total (95% Cl) 400 401 100.0% 0.35 (0.05, 2.30]<br>Total events 1 4<br>Heterageneity: Tau= 0,00; " Chi*= 0.22, df= 1 (P= 0.64); P= 0%<br>Testfor overall effect: Z= 1.09 (P = 0.28): ' oor O4 Favor ICP 1 Favor CRM]10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.16 Meta-análise revascularização curto prazo (1 a 2 anos), lesão de tronco_** -->
33  
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventscRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>PRECOMBATBoudriot 2011 2011 2614 30012100 6 «300101 65.5%34.5% 2472.36 ( 01 . 9441 ,  45 . 2189 ) 2011 a<br>Total (95% Cl) 400 401 100.0% 2.23 (1.30, 3.82] ><br>Total events 40 18<br>Heterogenety Tau = 0.00, = 002, f= 1 (P= 0.88); P= 0% bot t 1b 700<br>est for overall effect. Z= 2.92 (P = 0. 0 3) Favor ICP Favor CRIM]<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.17 Meta-análise mortalidade global médio prazo (3 a 5 anos), lesão de tronco_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventsRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>PRECOMBAT 2011 17 300-23 «300 21.8% 0,74 (0.40, 1.36) 2011<br>SYNTAX 2013 45 357 «48-348 37.5% 0.91 (0.63, 1.33] 2013<br>EXCEL 2016 71 948 © 53-987 40.7% 1.35 10.96, 1.91] 2016<br>Total (95% Cl) 1605 1605 100.0% 1.02 (0.73, 1.44]<br>Total events 133 124<br>Heterogeneity. Tau*= 0.04; Chi*= 3.87, df= 2 (P = 0.14); P= 48%<br>Testfor overall effect: Z= 0.13q  (P = 0.89): ’ oor Ot FavoriCP 1 Favor CRM10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.18 Meta-análise infarto médio prazo (3 a 5 anos), lesão de tronco_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventsRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>PRECOMBAT 2011 6 300 5 300 10.5% 1.20 (0.37, 3.89] 2011<br>SYNTAX 2013 28 357 = 18-348 30.5% 1.71 (0.94, 3.10) 2013<br>EXCEL 2016 72 948 «= 77 «987 59.0% 0.94 (0.69, 1.29] 2016<br>Total (95% Cl) 1605 1605 100.0% 4.16 (0.77, 1.74]<br>Total events 106 98<br>Heterogeneity. Tau*= 0.05; Chi*= 3.02, df= 2 (P = 0.22); P= 34%<br>Testfor overall effect: Z= 0.72q  (P= 0.47): ’ oor Ot FavoriCP 1 Favor CRM10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.19 Meta-análise AVC médio prazo (3 a 5 anos), lesão de tronco_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventsRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>PRECOMBAT 2011 2 300 2 300 6.3% 1,00 (0.14, 7.05] 2011<br>SYNTAXEXCEL 20162013 205 357948 =«= 14-34826-987 23.4%70.2% 0.350.78 (0.44,(0.13, 1.38]0.96) 20132016 ——<br>Total (95% Cl) 1605 1605 100.0% 0.65 [0.40, 1.07]<br>Total events 27 42<br>Heterogeneity. Tau*= 0.00; Chi*= 2.03, df= 2 (P = 0.36); P= 1%<br>Testfor overall effect: Z= 1.69.  (P = 0.09): ’ oor Ot FavoriCP 1 Favor CRM10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_4.16 Meta-análise revascularização médio prazo (3 a 5 anos), lesão de tronco_** -->
<!-- Start of picture text -->
Study or Subgroup Eventsice Total EventsRM Total Weight _M-H, RiskRandom, Ratio95% CI_Year MH, Random,Risk Ratio95% Cl<br>PRECOMBAT 2011 38 30021300 14.9% 1.81 (1.09, 3.01] 2011 =<br>SYNTAX 2013 90 357 49-348 387% 1,791.31, 2.45) 2013 7<br>EXCEL 2016 114 948 = 67 957 46.4% 1.72 (1.29, 2.29] 2016 =<br>Total (95% Cl) 1605 1605 100.0% 1.76 (1.45, 2.14] +<br>Total events 242 137<br>Heterogeneity. Tau*= 0.00; Chi*= 0.05, df= 2 (P = 0.98); P= 0%<br>Testfor overall effect Z= 5.64q  (P < 0.00001): ’ oor Ot FavorICP 1 Favor CRM10 100<br><!-- End of picture text -->  
34  
35

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_5.1 Angioplastia versus cirurgia na doença coronariana estável multivascular_** -->
|**Desfecho**|**Risco**<br>**com**<br>**CRM**|**Risco com ICP**|**Efeito**<br>**relativo**<br>**(IC 95%)**|**N participantes**<br>**(N estudos)**|**Qualidade da**<br>**evidência**|**Importância**<br>**do desfecho**|
|---|---|---|---|---|---|---|
|Mortalidade curto prazo<br>Seguimento: média 2<br>anos|45 por<br>1.000|75 por 1.000<br>(37 a 150)|RR 1.67<br>(0.83 a 3.35)|4428<br>(4 ECRs)|⨁`◯◯◯`<br>MUITO BAIXA<sup>a,b,c</sup>|Crítico|
|Infarto, curto prazo<br>Seguimento: média 2<br>anos|44 por<br>1.000|70 por 1.000<br>(54 a 90)|RR 1.58<br>(1.23 a 2.03)|4428<br>(4 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>b,c</sup>|Crítico|
|AVC curto prazo<br>Seguimento: média 2<br>anos|23 por<br>1.000|9 por 1.000<br>(5 a 19)|RR 0.41<br>(0.20 a 0.85)|4428<br>(4 ECRs)|⨁⨁⨁⨁<br>ALTA|Crítico|
|Nova revascularização<br>curto prazo<br>Seguimento: média 2<br>anos|56 por<br>1.000|143 por 1.000<br>(115 a 178)|RR 2.56<br>(2.06 a 3.19)|4428<br>(4 ECRs)|⨁⨁⨁`◯`<br>MODERADA<sup>b,d</sup>|Importante|
|Mortalidade médio prazo<br>Seguimento: média 5<br>anos|69 por<br>1.000|98 por 1.000<br>(81 a 120)|RR 1.43<br>(1.18 a 1.74)|4520<br>(3 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>e,f</sup>|Crítico|
|Infarto, médio prazo<br>Seguimento: média 5<br>anos|34 por<br>1.000|76 por 1.000<br>(58 a 100)|RR 2.22<br>(1.69 a 2.91)|4520<br>(3 ECRs)|⨁⨁⨁`◯`<br>MODERADA<sup>e,f</sup>|Crítico|  
|AVC, médio prazo<br>Seguimento: média 5<br>anos|31 por<br>1.000|22 por 1.000<br>(15 a 31)|RR 0.70<br>(0.49 a 1.01)|4520<br>(3 ECRs)|⨁`◯◯◯`<br>MUITO BAIXA<sup>c,e,f</sup>|Crítico|
|---|---|---|---|---|---|---|
|Nova revascularização,<br>médio prazo<br>Seguimento: média 5<br>anos|58 por<br>1.000|130 por 1.000<br>(106 a 158)|RR 2.23<br>(1.83 a 2.72)|4520<br>(3 ECRs)|⨁⨁⨁`◯`<br>MODERADA<sup>d,e,f</sup>|Importante|  
a. I² 81%; b. Pacientes com angina instável ou com exames positivos incluídos; c. IC largo; d. Maior número de angiografias de rotina no grupo ICP; e. Interrupção precoce do ensaio BEST; f. Sem definição adequada entre angina estável e instável no ensaio FREEDOM.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_5.2 Angioplastia versus cirurgia em pacientes diabéticos, seguimento médio 5 anos._** -->
|**Desfecho**|**Risco**<br>**com ICP**|**Risco com**<br>**CRM**|**Efeito**<br>**relativo**<br>**(IC 95%)**|**N participantes**<br>**(N estudos)**|**Qualidade da**<br>**evidência**|**Importância**<br>**do desfecho**|
|---|---|---|---|---|---|---|
|Mortalidade|202/1303<br>(15.5%)|130/1294<br>(10.0%)|RR 1.54<br>(1.25 a 1.89)|54 eventos a mais<br>a cada 1.000<br>(de 25 a 89 a<br>mais)|⨁⨁⨁`◯`<br>MODERADA<sup>b</sup>|CRÍTICO|
|Infarto|146/1106<br>(13.2%)|61/1090<br>(5.6%)|RR 2.36<br>(1.77 a 3.14)|76 eventos a mais<br>a cada 1.000<br>(de 43 a 120 a<br>mais)|⨁⨁⨁`◯`<br>MODERADA<sup>b</sup>|CRÍTICO|  
37  
|AVC|29/1106<br>(2.6%)|54/1090<br>(5.0%)|RR 0.61<br>(0.28 a 1.36)|19 eventos a<br>menos a cada<br>1.000<br>(de 18 a mais a 36<br>a menos)|⨁`◯◯◯`<br>MUITO BAIXA<sup>b,c,d</sup>|CRÍTICO|
|---|---|---|---|---|---|---|
|Nova revascularização|77/350<br>(22.0%)|25/347<br>(7.2%)|RR 2.92<br>(1.93 a 4.44)|138 eventos a<br>mais a cada 1.000<br>(de 67 a 248 a<br>mais)|⨁⨁`◯◯`<br>BAIXA<sup>a,b</sup>|IMPORTANTE|  
a. tratamento medicamentoso heterogêneo entre os grupos. Angiografia de rotina mais frequente no grupo da angioplastia. b. _Stents_ de primeira e de segunda geração, média de _stents_ por paciente acima da média usual, inclusão de pacientes com angina instável e infarto. c. I<sup>2</sup> 46%. d. IC largo.

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **_5.3 Angioplastia versus cirurgia na doença coronariana estável, em pacientes com lesão de tronco de coronária esquerda_** -->
|**Desfecho**|**Risco**<br>**com**<br>**CRM**|**Risco com ICP**|**Efeito**<br>**relativo**<br>**(IC 95%)**|**N participantes**<br>**(N estudos)**|**Qualidade da**<br>**evidência**|**Importância**<br>**do desfecho**|
|---|---|---|---|---|---|---|
|Mortalidade curto prazo<br>Seguimento: média 2<br>anos|37 por<br>1.000|23 por 1.000<br>(10 a 52)|RR 0.61<br>(0.27 a 1.38)|801<br>(2 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>a,b</sup>|Crítico|
|Infarto, curto prazo<br>Seguimento: média 2<br>anos|15 por<br>1.000|20 por 1.000<br>(7 a 57)|RR 1.33<br>(0.46 a 3.83)|801<br>(2 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>a,b</sup>|Crítico|  
38  
|AVC curto prazo<br>Seguimento: média 2<br>anos|10 por<br>1.000|3 por 1.000<br>(0 a 23)|RR 0.35<br>(0.05 a 2.30)|801<br>(2 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>a,b</sup>|Crítico|
|---|---|---|---|---|---|---|
|Nova revascularização<br>curto prazo<br>Seguimento: média 2<br>anos|45 por<br>1.000|100 por 1.000<br>(58 a 171)|RR 2.23<br>(1.30 a 3.82)|801<br>(2 ECRs)|⨁⨁⨁`◯`<br>MODERADA<sup>a,c</sup>|Importante|
|Mortalidade médio prazo<br>Seguimento: média 5<br>anos|77 por<br>1.000|79 por 1.000<br>(56 a 111)|RR 1.02<br>(0.73 a 1.44)|3210<br>(3 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>a,b</sup>|Crítico|
|Infarto, médio prazo<br>Seguimento: média 5<br>anos|61 por<br>1.000|71 por 1.000<br>(47 a 106)|RR 1.16<br>(0.77 a 1.74)|3210<br>(3 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>a,b</sup>|Crítico|
|AVC, médio prazo<br>Seguimento: média 5<br>anos|26 por<br>1.000|17 por 1.000<br>(10 a 28)|RR 0.65<br>(0.40 a 1.07)|3210<br>(3 ECRs)|⨁⨁`◯◯`<br>BAIXA<sup>a,b</sup>|Crítico|
|Nova revascularização,<br>médio prazo<br>Seguimento: média 5<br>anos|85 por<br>1.000|150 por 1.000<br>(124 a 183)|RR 1.76<br>(1.45 a 2.14)|3210<br>(3 ECRs)|⨁⨁⨁`◯`<br>MODERADA<sup>a</sup>|Importante|  
a. Inclusão de infarto e síndrome coronariana aguda; b. Magnitude de efeito inclui ponto nulo, variando entre proteção e dano; c. Magnitude de efeito superior a 2,0  
39

---

<!-- METADADOS: doenca: Utilização de Stents em Pacientes com Doença Coronariana Estável (Diretrizes Brasileiras) | secao: **REFERÊNCIAS** -->
1. _Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – 1. ed., 1. reimpr. – Brasília : Ministério da  da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – 1. ed., 1. reimpr. – Brasília : Ministério da Saúde, 2015. ._  
2. Pandit, J., et al., _Patient and physician perspectives on outcomes weighting in revascularization. The POWR study._ Int J Cardiol, 2014. 177(2): p. 513-4.  
3. Ahmad, Y., et al., _A new method of applying randomised control study data to the individual patient: A novel quantitative patient-centred approach to interpreting composite end points._ Int J Cardiol, 2015. 195: p. 216-24.  
4. Kipp, R., et al., _Patient preferences for coronary artery bypass graft surgery or percutaneous intervention in multivessel coronary artery disease._ Catheter Cardiovasc Interv, 2013. 82(2): p. 212-8.  
5. Cesar LA, F.J., Armaganijan D,  Gowdak LH, Mansur AP, Bodanese LC, et al. , _Diretriz de Doença Coronária Estável._ Arq Bras Cardiol 2014. 103(2Supl.2): p. 1-59.  
6. Gruntzig, A., _Transluminal dilatation of coronary-artery stenosis._ Lancet, 1978. 1(8058): p. 263. 7. Sigwart, U., et al., _Intravascular stents to prevent occlusion and restenosis after transluminal angioplasty._ N Engl J Med, 1987. 316(12): p. 701-6.  
8. Farb, A., et al., _Pathology of acute and chronic coronary stenting in humans._ Circulation, 1999. 99(1): p. 44-52.  
9. Iqbal, J., J. Gunn, and P.W. Serruys, _Coronary stents: historical development, current status and future directions._ Br Med Bull, 2013. 106: p. 193-211.  
10. _Arterial Revascularization Therapies Study (ARTS)._ Indian Heart J, 2001. 53(2): p. 239.  
11. Hueb, W.A., et al., _The Medicine, Angioplasty or Surgery Study (MASS): a prospective, randomized trial of medical therapy, balloon angioplasty or bypass surgery for single proximal left anterior descending artery stenoses._ J Am Coll Cardiol, 1995. 26(7): p. 1600-5.  
12. Rodriguez, A., et al., _Argentine Randomized Study: Coronary Angioplasty with Stenting versus Coronary Bypass Surgery in patients with Multiple-Vessel Disease (ERACI II): 30-day and oneyear follow-up results. ERACI II Investigators._ J Am Coll Cardiol, 2001. 37(1): p. 51-8.  
13. Morrison, D.A., et al., _A multicenter, randomized trial of percutaneous coronary intervention versus bypass surgery in high-risk unstable angina patients. The AWESOME (Veterans Affairs Cooperative Study #385, angina with extremely serious operative mortality evaluation) investigators from the Cooperative Studies Program of the Department of Veterans Affairs._ Control Clin Trials, 1999. 20(6): p. 601-19.  
14. Stettler, C., et al., _Outcomes associated with drug-eluting and bare-metal stents: a collaborative network meta-analysis._ Lancet, 2007. 370(9591): p. 937-48.  
15. Guyatt, G.H., et al., _GRADE: an emerging consensus on rating quality of evidence and strength of recommendations._ BMJ, 2008. 336(7650): p. 924-6.  
16. Lee, C.W., et al., _Coronary Artery Bypass Surgery Versus Drug-Eluting Stent Implantation for Left Main or Multivessel Coronary Artery Disease: A Meta-Analysis of Individual Patient Data._ JACC Cardiovasc Interv, 2016. 9(24): p. 2481-2489.  
40  
17. Kapur, A., et al., _Randomized comparison of percutaneous coronary intervention with coronary artery bypass grafting in diabetic patients. 1-year results of the CARDia (Coronary Artery Revascularization in Diabetes) trial._ J Am Coll Cardiol, 2010. 55(5): p. 432-40.  
18. Farkouh, M.E., et al., _Strategies for multivessel revascularization in patients with diabetes._ N Engl J Med, 2012. 367(25): p. 2375-84.  
19. Kamalesh, M., et al., _Percutaneous coronary intervention versus coronary bypass surgery in United States veterans with diabetes._ J Am Coll Cardiol, 2013. 61(8): p. 808-16.  
20. Serruys, P.W., et al., _Percutaneous coronary intervention versus coronary-artery bypass grafting for severe coronary artery disease._ N Engl J Med, 2009. 360(10): p. 961-72.  
21. Morice, M.C., et al., _Five-year outcomes in patients with left main disease treated with either percutaneous coronary intervention or coronary artery bypass grafting in the synergy between percutaneous coronary intervention with taxus and cardiac surgery trial._ Circulation, 2014. 129(23): p. 2388-94.  
22. Park, S.J., et al., _Trial of everolimus-eluting stents or bypass surgery for coronary disease._ N Engl J Med, 2015. 372(13): p. 1204-12.  
23. Daemen, J., et al., _Multivessel coronary revascularization in patients with and without diabetes mellitus: 3-year follow-up of the ARTS-II (Arterial Revascularization Therapies Study-Part II) trial._ J Am Coll Cardiol, 2008. 52(24): p. 1957-67.  
24. Herbison, P. and C.K. Wong, _Has the difference in mortality between percutaneous coronary intervention and coronary artery bypass grafting in people with heart disease and diabetes changed over the years? A systematic review and meta-regression._ BMJ Open, 2015. 5(12): p. e010055.  
25. Park, S.J. and Y.H. Kim, _Percutaneous coronary intervention for unprotected left main coronary artery stenosis._ World J Cardiol, 2010. 2(4): p. 78-88.  
26. Huang, F., et al., _Comparison of bypass surgery and drug-eluting stenting in diabetic patients with left main and/or multivessel disease: A systematic review and meta-analysis of randomized and nonrandomized studies._ Cardiol J, 2015. 22(2): p. 123-34.  
27. Stone, G.W., et al., _Everolimus-Eluting Stents or Bypass Surgery for Left Main Coronary Artery Disease._ N Engl J Med, 2016. 375(23): p. 2223-2235.  
28. Makikallio, T., et al., _Percutaneous coronary angioplasty versus coronary artery bypass grafting in treatment of unprotected left main stenosis (NOBLE): a prospective, randomised, open-label, non-inferiority trial._ Lancet, 2016. 388(10061): p. 2743-2752.  
41  
42

---

