<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA SECTICS/MS Nº 75, DE 28 DE DEZEMBRO DE 2023.  
Torna pública a decisão de aprovar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 - Diagnóstico, Manejo e Tratamento de Crianças e Adolescentes Vivendo com HIV.  
Ref.: 25000.127354/2023-26  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.798, de 28 de novembro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º. Fica aprovado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 - Diagnóstico, Manejo e Tratamento de Crianças e Adolescentes Vivendo com HIV.  
Art. 2º. Ficam atualizados, no âmbito do SUS, os capítulos 6 a 9 e 14 do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes, conforme consta do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 - Diagnóstico, Manejo e Tratamento de Crianças e Adolescentes Vivendo com HIV.  
Art. 3º. O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/ptbr.  
Art. 4º. Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: CARLOS A. GRABOIS GADELHA -->
1  
**ANEXO**  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS PARA MANEJO DA INFECÇÃO PELO HIV EM CRIANÇAS E ADOLESCENTES – MÓDULO 2: DIAGNÓSTICO, MANEJO E TRATAMENTO DE CRIANÇAS E ADOLESCENTES VIVENDO COM HIV

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **1. INTRODUÇÃO** -->
A Política de Atenção Integral à Saúde da Criança - PNASC<sup>1</sup> inclui entre seus eixos, vigilância e prevenção da mortalidade infantil e atenção à saúde do recém-nascido. As recomendações do Ministério da Saúde (MS) contidas neste Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para o Manejo da Infecção pelo HIV em Crianças e Adolescentes buscam contribuir para a sobrevivência, qualidade de vida das crianças vivendo com HIV (CVHA), assim como, para o cumprimento dos compromissos do país diante das metas dos Objetivos de Desenvolvimento Sustentável 2015-2030 (ODS) das Nações Unidas.<sup>2</sup>  
Esta atualização amplia a indicação de inibidores da integrase (INI) na profilaxia de crianças expostas ao HIV, e no início de tratamento, incluindo, assim, todas as faixas etárias. Também altera esquemas terapêuticos, buscando tornar a terapia antirretroviral (TARV) mais tolerável, um permanente desafio para a população de CVHA, devido às limitadas apresentações de medicamentos.  
Além das indicações de medicamentos e testes laboratoriais, este Protocolo amplia os aspectos ligados ao cuidado, trazendo a abordagem da prevenção combinada como estratégia de prevenção ao HIV. Sobretudo, aborda um conjunto de intervenções biomédicas, comportamentais e estruturais propondo que sejam oferecidas aos indivíduos e suas parcerias, nos grupos sociais a que pertencem. Tratam-se de ações e informações que consideram as necessidades e especificidades de crianças e adolescentes e as variadas formas de transmissão do vírus.  
Tal abordagem é muito importante, principalmente, em relação aos adolescentes e jovens, faixa etária que apresenta aumento significativo na incidência da infecção pelo HIV. Assim, as informações sobre o início da atividade sexual, transmissibilidade do vírus, sexo seguro e prevenção da gravidez não planejada, entre outras, são imprescindíveis para fortalecer a confiança e melhorar a autoestima dos adolescentes e jovens que vivem com HIV e suas parcerias sexuais, bem como, prevenir novos casos da infecção.  
Além da abordagem para a infecção pelo HIV, é importante que os profissionais e os serviços de saúde estejam estruturados para uma atuação multidisciplinar para o cuidar de crianças e adolescentes vivendo com HIV. O olhar atento e cuidadoso de profissionais e equipes multiprofissionais deve acontecer desde o início do processo de acolhimento, investigação ou revelação diagnóstica. Deve considerar a importância da adesão, vinculação, retenção e seguimento das crianças e adolescentes. Os cuidados devem ir além do manejo do HIV para garantir que crianças e adolescentes desenvolvam todo seu potencial de crescimento, respeitando sua condição peculiar de uma pessoa em desenvolvimento.  
Assim, este PCDT estabelece diretrizes para remover barreiras do diagnóstico, contribuindo para o início precoce e oportuno do tratamento de crianças e adolescentes vivendo com HIV, com apresentações que melhoram adesão e podem aumentar a retenção no cuidado contínuo de crianças.  
O PCDT abrange a instituição do tratamento preemptivo em recém-nascidos expostos, o manejo de TARV inicial e a estruturação de esquemas de resgate quando for caracterizada falha terapêutica em crianças até 13 anos de idade. Já para maiores de 13 anos, as orientações sobre o manejo do tratamento antirretroviral na falha terapêutica podem ser encontradas no PCDT de TARV em adultos, disponível em: <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts</u>  
Considerando a importância da assistência integral a crianças e adolescentes, este Protocolo destina-se à toda a equipe multiprofissional envolvida no atendimento às pessoas vivendo com HIV (PVHA), à sociedade civil organizada e às próprias pessoas que vivem com HIV ou Aids. Cuidar de suas  
2  
crianças é um atributo de uma sociedade saudável, considerando os princípios éticos de respeito a mulheres, crianças e de valorização da vida.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **2. METODOLOGIA** -->
O processo de desenvolvimento desse PCDT envolveu a realização de avaliações de revisões sistemáticas (RS) e ensaios clínicos randomizados (ECR) para as sínteses de evidências, que foram adotadas e/ou adaptadas às recomendações de diretrizes já publicadas para as tecnologias que se encontram disponíveis no SUS para o diagnóstico e tratamento de HIV em crianças. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontrase descrito no Apêndice 2.  
**3. REVELAÇÃO DO DIAGNÓSTICO DE INFECÇÃO PELO HIV EM CRIANÇAS E ADOLESCENTES**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **3.1. Aspectos gerais** -->
A revelação diagnóstica é um momento de especial importância no cuidado das crianças e adolescentes vivendo com HIV e requer o envolvimento de todos, cuidadores e profissionais, que participam de seu cuidado.  
A comunicação do diagnóstico deve ser individualizada, considerando as particularidades de cada usuário, como também do cuidador, incluindo nível de compreensão, estágio de desenvolvimento, contexto social e familiar. Considera-se como cuidador qualquer pessoa que se responsabilize pela criança ou adolescente, acompanhando nas consultas e auxiliando na tomada de medicamentos, sendo familiar ou não, tutor, profissional de abrigo onde mora a criança, amigo, etc.  
O processo de revelação diagnóstica deve ser iniciado o mais precocemente possível e guiado a partir das primeiras manifestações de curiosidade da criança. Cada pergunta deve ser respondida de forma simples e objetiva, com emprego de vocabulário que possa ser facilmente compreendido.  
A nomeação da doença é um momento crítico, especialmente na primeira infância, quando as crianças ainda não têm discernimento para guardar segredos. Nesses casos, explicações parciais que contemplem informações sobre a importância da tomada dos medicamentos e os mecanismos de ação dos vírus no organismo também são benéficas<sup>3</sup> .  
Os cuidadores devem consentir e integrar ativamente o planejamento e construção de estratégias para a revelação diagnóstica. Muitos responsáveis evitam revelar a doença à criança por temerem que ela seja rejeitada e submetida a isolamento social, ou por receio de que a criança não consiga guardar segredo, especialmente entre os amigos e colegas da escola, ficando assim exposta a cenários de estigma e preconceito.  
No entanto, o silêncio ou a mentira dos adultos podem trazer prejuízos e enigmas ao psiquismo infantil. No caso dos adolescentes que desconhecem sua condição sorológica, a ausência de um diálogo honesto e aberto é capaz de gerar estados de depressão, retraimento e desconfiança, que podem assumir um papel patogênico na construção de sua identidade de adulto.  
Por vezes, os cuidadores solicitam que o diagnóstico seja revelado à criança pelo profissional de saúde. Dessa forma, há necessidade de abordar o conhecimento das preocupações da criança, do adolescente e do cuidador, bem como informações claras sobre os riscos da não revelação e suas consequências.  
3  
O acompanhamento pós-revelação também requer cuidado específico. Para a criança, o contato com os mecanismos de ação da infecção pelo HIV é progressivo e, portanto, seu entendimento também ocorre de forma lenta e gradual. Ressalta-se que as intervenções não devem orientar-se somente pela temática da doença, especialmente porque o segredo do diagnóstico pode envolver outros problemas familiares (adoção, morte dos pais, forma de contágio). O diálogo com os cuidadores sobre este e outros aspectos do processo de revelação torna-se essencial. É importante que os profissionais se coloquem à disposição para esclarecer dúvidas, acolher as angústias das crianças e ajudá-las a verbalizarem com espontaneidade indagações sobre sua doença e outros aspectos<sup>4</sup> .  
A revelação diagnóstica traz benefícios para a criança, o adolescente e o cuidador, bem como para o serviço de saúde e os profissionais que trabalham nele. As crianças e adolescentes que conhecem e compreendem a razão de suas visitas médicas e a necessidade de usarem os medicamentos mostram melhor adesão ao tratamento e desenvolvimento biopsicossocial, pois participam de seu próprio cuidado. Há melhora da noção de responsabilidade e da conscientização sobre a promoção da saúde. Para os cuidadores, a revelação diagnóstica fortalece o relacionamento e interação entre cuidador e criança ou adolescente, além de melhorar aspectos psicológicos, como sentimento de culpa, depressão e falta de autoconfiança. No serviço de saúde, as crianças ou adolescentes que têm seu diagnóstico revelado tendem a comparecer mais às consultas e grupos de apoio, pois se interessam mais pelo próprio cuidado e, conforme mencionado anteriormente, apresentam melhor adesão à terapia antirretroviral (TARV).  
Vale ressaltar que o processo de revelação envolve uma equipe multidisciplinar, com médicos, enfermeiros, psicólogos, agentes de saúde e quem mais estiver inserido no atendimento, como dispensadores de medicamentos, farmacêuticos e técnicos de laboratório. Caso algum profissional não se sinta apto a participar desse processo, deve identificar-se para a equipe e deixar que outros profissionais sejam incluídos. É fundamental que o profissional de saúde com o qual a criança ou adolescente mais se identifique seja envolvido no processo de revelação. O Manual para Assistência à Revelação Diagnóstica às Crianças que Vivem com o HIV/aids possui recomendações que buscam auxiliar o processo de revelação diagnóstica, com material lúdico, de fácil compreensão, adaptável a realidade local de cada serviço (http://www.saude.sp.gov.br/resources/crt/publicacoes/materiais/manualparaassistenciaarevelacaodiagnos <u>ticaascriancasquevivemcomohiv-aids.pdf).</u>  
O **Quadro 1** elenca os principais pontos a serem considerados no processo de revelação diagnóstica.  
**Quadro 1** : Sumário dos principais pontos a serem avaliados no processo de revelação diagnóstica.  
|**MOTIVOS DA REVELAÇÃO**|**AVALIAÇÃO**<br>**BIOPSICOSSOCIAL**<br>**DA**<br>**CRIANÇA**<br>**E**<br>**ADOLESCENTE**<br>**(PRÉ-**<br>**REVELAÇÃO)**|**AVALIAÇÃO**<br>**BIOPSICOSSOCIAL**<br>**DO**<br>**CUIDADOR**<br>**(PRÉ-**<br>**REVELAÇÃO)**|
|---|---|---|
|Solicitada pelo cuidador ou pela<br>criança ou adolescente.<br>Exemplos de situações que<br>podem ter despertado o interesse<br>na revelação: criança ouviu algo<br>sobre o tema em casa, na escola<br>ou no serviço de saúde; leu a|**Avaliação psicológica:**observar<br>o<br>comportamento<br>da<br>criança/adolescente diante das<br>consultas e a necessidade de<br>coletar<br>exames<br>e<br>tomar<br>medicamentos.<br>Avaliar o grau de aceitação da|**Avaliação psicológica:**observar<br>a capacidade de compreensão do<br>tema e do cuidado (horário da<br>tomada dos medicamentos, data<br>das consultas etc.).<br>Avaliar se existe sentimento de<br>culpa do cuidador em relação ao|
|bula do medicamento, leu uma<br>prescrição.<br>Criança é incapaz de guardar<br>segredo e revela o diagnóstico a<br>terceiros, o que a expõe a<br>situações<br>de<br>estigma<br>e<br>preconceito|situação,<br>se<br>há<br>rejeição,<br>fantasias,<br>agressividade,<br>depressão,<br>capacidade<br>de<br>compreensão<br>do<br>tema<br>e<br>maturidade psicológica<br>**Avaliação social:**analisar o<br>horário da escola, desempenho<br>escolar,rede de cuidadores,|_status_da criança, ou se há<br>estigma ou tabu na família<br>**Avaliação social:**analisar a<br>estrutura familiar do cuidador e<br>da criança, a relação do cuidador<br>com a criança ou adolescente, as<br>condições de moradia, renda,|  
4  
|**MOTIVOS DA REVELAÇÃO**|**AVALIAÇÃO**<br>**BIOPSICOSSOCIAL**<br>**DA**<br>**CRIANÇA**<br>**E**<br>**ADOLESCENTE**<br>**(PRÉ-**<br>**REVELAÇÃO)**|**AVALIAÇÃO**<br>**BIOPSICOSSOCIAL**<br>**DO**<br>**CUIDADOR**<br>**(PRÉ-**<br>**REVELAÇÃO)**|
|---|---|---|
|Criança<br>e<br>adolescente<br>desenvolvem<br>distúrbios<br>psicológicos<br>e<br>psiquiátricos<br>diante da incompreensão do seu<br>estado de saúde física (“Por que<br>preciso vir ao médico?” “O que<br>tenho?” “Por que preciso tomar<br>remédio?”)<br>Adolescente que inicia atividade<br>sexual ouque engravida<br>Fonte: DATHI/SVSA/MS.|apoiadores, amigos, cotidiano,<br>local de residência, adesão ao<br>tratamento<br>**Avaliação**<br>**clínica:**<br>verificar<br>distúrbio<br>neuropsiquiátrico,<br>supressão<br>viral,<br>estado<br>nutricional,<br>desenvolvimento<br>neuropsicomotor e maturação<br>sexual<br>|horário do trabalho, tempo de<br>convívio com a criança<br>**Avaliação**<br>**clínica:**<br>verificar<br>_status_sorológico para HIV. O<br>cuidador é pessoa vivendo com<br>HIV? Está em uso de terapia<br>antirretroviral? Tem carga viral<br>(CV-HIV) suprimida?<br>Avaliar o estado de saúde do<br>cuidador|  
A revelação diagnóstica deve respeitar o crescimento e desenvolvimento da criança e do adolescente. Sendo assim, as estratégias de revelação serão diferentes quanto ao conteúdo na abordagem do tema e na metodologia utilizada, de acordo com seu grau de desenvolvimento ( **Quadro 2** ).  
Em todas as etapas, o cuidador desempenha um papel fundamental, dando suporte e apoio à criança e adolescente no entendimento da sua condição de saúde, na adesão à TARV e na diminuição de estigmas e tabus.  
Vários ambientes podem ser utilizados para a revelação. Além do consultório médico, espaços diferentes podem facilitar o processo, como brinquedotecas, salas de grupo de apoio, locais lúdicos com jardins ou áreas externas. No caso dessas últimas, deve-se assegurar a proteção e preservação da exposição da criança e adolescente.  
5  
**Quadro 2** : Estratégias de revelação do diagnóstico do HIV de acordo com faixa etária.  
|**IDADE**<br>**DA**<br>**PVHIV**|**RECOMENDAÇÃO**<br>**DA**<br>**REVELAÇÃO**<br>**DO**<br>**DIAGNÓSTICO DE HIV**|**CONTEÚDO**<br>**DO**<br>**TEMA**<br>**A**<br>**SER**<br>**ABORDADO**<br>**NA**<br>**REVELAÇÃO**|**MÉTODOS**|**PAPEL DO CUIDADOR**|
|---|---|---|---|---|
|**Menores**<br>**de 6 anos**|Não recomendado|Conhecer a criança: perguntar sobre seu cotidiano, amigos, jogos<br>favoritos etc.<br>Abordar conceitos gerais de higiene e infecção (p. ex., lavar as mãos,<br>escovar os dentes)|Diálogos, brincadeiras,<br>desenhos, vídeos;|Suporte e preparo para revelação<br>no futuro;<br>Suporte para administração e<br>tomada de medicamentos;|
|**6-8 anos**|Introduzir o tema<br>Evitar nomear o HIV|Ressaltar o conceito de promoção à saúde<br>Explicar à criança que:<br>1) Ela tem um vírus que está “adormecido” ou “controlado”;<br>2) Tomar os medicamentos mantêm o vírus sob controle ou<br>adormecido para que a criança não fique doente;<br>3) Ela deve coletar sangue para verificar que o vírus está controlado<br>ou adormecido;|Diálogos, brincadeiras,<br>desenhos, vídeos;<br>Pedagogia<br>problematizadora;<br>Acompanhamento pós-<br>revelação;<br>Grupos de apoio;|Suporte e apoio, identificação de<br>barreiras<br>e<br>construção<br>de<br>estratégias<br>em<br>conjunto,<br>desconstrução de tabus;<br>Suporte para administração e<br>tomada de medicamentos;|
|**8-10 anos**|Aprofundar o tema<br>Nomear<br>o<br>HIV:<br>o<br>“vírus<br>dormente se chama HIV”|Explicar que o vírus adormecido ou controlado se chama HIV;<br>Orientar a criança quanto à revelação a outros;<br>Explicar a transmissão do HIV;<br>Reforçar a importância do uso do medicamento para a manutenção<br>da saúde<br>Incluir a criança nas discussões sobre sua saúde e resultados de<br>exames;<br>Discutir o conceito de doença crônica, processo saúde/doença;|Diálogos, brincadeiras,<br>desenhos, vídeos<br>Pedagogia;<br>problematizadora<br>Acompanhamento pós-<br>revelação;<br>Grupos de apoio;|Suporte e apoio, identificação de<br>barreiras<br>e<br>construção<br>de<br>estratégias<br>em<br>conjunto,<br>desconstrução de tabus;<br>Suporte para administração e<br>tomada de medicamentos;|
|**10-14 anos**|Acompanhamento<br>pós-<br>revelação.<br>Nomear o vírus e apresentar<br>nomenclatura inclusiva para a<br>criança vivendo com HIV/aids<br>ou adolescente, mecanismos de<br>infecção, introdução sobre saúde<br>e educação sexual, uso de<br>preservativos e práticas de sexo<br>seguro.|Nomear o HIV<br>Reforçar o conceito de promoção à saúde, incentivar o adolescente a<br>manter discussões, questionamentos;<br>Encorajar a autonomia gradual, a tomada independente de<br>medicamentos e o autocuidado;<br>Reforçar a adesão;<br>Incluir o adolescente nas discussões sobre sua saúde;<br>**Discutir sexualidade e práticas de sexo seguro.**|Diálogos, vídeos;<br>Pedagogia<br>problematizadora;<br>Acompanhamento pós-<br>revelação;<br>Grupos de apoio;|Suporte e apoio, identificação de<br>barreiras<br>e<br>construção<br>de<br>estratégias em conjunto para<br>quebra de tabus;<br>Suporte para administração e<br>tomada de medicamentos;|
|**Acima de**<br>**14 anos**|Acompanhamento<br>pós-<br>revelação.|Nomear o HIV.|Diálogos,<br>vídeos,<br>internet,aplicativos;|Suporte e apoio, identificação de<br>barreiras<br>e<br>construção<br>de|  
6  
|**IDADE**<br>**DA**<br>**PVHIV**|**RECOMENDAÇÃO**<br>**DA**<br>**REVELAÇÃO**<br>**DO**<br>**DIAGNÓSTICO DE HIV**|**CONTEÚDO**<br>**DO**<br>**TEMA**<br>**A**<br>**SER**<br>**ABORDADO**<br>**NA**<br>**REVELAÇÃO**|**MÉTODOS**|**PAPEL DO CUIDADOR**|
|---|---|---|---|---|
||Nomear o vírus e apresentar<br>nomenclatura inclusiva para a<br>criança vivendo com HIV/aids<br>ou adolescente, mecanismos de<br>infecção, introdução sobre saúde<br>e educação sexual, uso de<br>preservativos e práticas de sexo<br>seguro.<br>Preparação para suporte nos<br>relacionamentos.|Reforçar os conceitos de saúde/doença, doença crônica, hospedeiro/<br>parasita<br>Aprofundar os temas.<br>Identificar práticas sexuais e manter debate sobre sexualidade e sexo<br>seguro.|Pedagogia<br>problematizadora;<br>Acompanhamento pós-<br>revelação;<br>Grupos de apoio.|estratégias<br>em<br>conjunto,<br>desconstrução de tabus;<br>Suporte para administração e<br>tomada de medicamentos;<br>Acompanhamento,<br>escuta<br>e<br>diálogo.|  
Fonte: DATHI/SVSA/MS.  
7

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **3.2. Particularidades da revelação diagnóstica na adolescência** -->
É fundamental que os adolescentes estejam plenamente informados sobre sua condição sorológica.  
Na adolescência, as explicações devem ser mais detalhadas, abordando os conceitos de infecção, transmissão, ciclo de vida e replicação viral, mecanismos de ação dos antirretrovirais (ARV), resistência, interações medicamentosas e prevenção de infecções sexualmente transmissíveis.  
Mecanismos de negação são comumente observados. Nesses casos, a conversa deve aproximar-se gradualmente da temática da doença, em um contexto de muita confiança no relacionamento com o profissional. Oferecer uma escuta continente, que permita aos adolescentes a expressão de suas dificuldades e a atribuição de novos significados às suas crenças é estratégia imprescindível na revelação diagnóstica durante a adolescência (3,4).  
Os adolescentes que adquiriram o HIV por transmissão sexual apresentam particularidades que precisam ser reconhecidas pelos profissionais e contempladas na abordagem da revelação. É necessário avaliar os vínculos com os serviços de saúde. Muitas vezes, os adolescentes encontram-se situações de alta vulnerabilidade social.  
**Sobre a realização da testagem e revelação diagnóstica do HIV para menores de idade, o Comitê de Direitos da Criança, da Convenção Internacional dos Direitos da Criança, da qual o Brasil é signatário, afirma que devem ser garantidos os direitos ao adolescente (acima de 12 e menor de 18 anos) nos serviços de saúde independentemente da anuência de seus responsáveis.** Este é um elemento indispensável para a melhoria da qualidade da prevenção, assistência e promoção de sua saúde. Nesse sentido, o documento “Marco Legal: Saúde, um Direito de Adolescentes”, publicado pelo Ministério da Saúde<sup>5</sup> , recomenda que:  
- <mark>Quando se tratar de criança (0 a 12 anos incompletos), a testagem e a entrega dos exames anti-</mark> HIV devem ser realizadas exclusivamente com a presença dos pais ou responsáveis legais.  
- Quando se tratar de adolescente (12 a 18 anos), após uma avaliação de suas condições de discernimento, a realização do exame fica restrita à sua vontade, assim como a revelação do resultado a outras pessoas. Isso significa que, se o adolescente assim desejar, e se for constatado que ele está em condições físicas, psíquicas e emocionais de receber o resultado do exame, a testagem e a revelação diagnóstica poderão ser realizadas mesmo sem a presença dos responsáveis legais.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **3.3. Revelação diagnóstica a terceiros na adolescência** -->
Uma inquietação comum do adolescente vivendo com HIV é conseguir saber em quem pode confiar ou a quem deve revelar sua condição sorológica, decisão que envolve o medo da discriminação e da rejeição, especialmente no contexto das relações afetivas. Alguns se esquivam dos envolvimentos afetivos por temerem que uma maior aproximação possa conduzir, inevitavelmente, à revelação<sup>6,7</sup> .  
A importância do trabalho da equipe multiprofissional possibilitará a compreensão do significado e das funções do segredo para cada sujeito, incluindo a avaliação dos riscos e benefícios de sua manutenção ou divulgação.  
Compreender os sentidos da revelação, que incluem por que e o que contar e para quem revelar a infecção pelo HIV, assim como as dimensões entre o direito ao sigilo e a responsabilidade diante da exposição a terceiros, devem ser aspectos amplamente abordados junto a esses adolescentes<sup>8–13</sup> .  
Finalmente, a confidencialidade da condição de infectado pelo HIV deve ser assegurada em todas as esferas de convivência da criança e do adolescente<sup>13–16</sup> .  
8

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **4. ADESÃO AO TRATAMENTO ANTIRRETROVIRAL** -->
A adesão ao tratamento para crianças é mais complexa do que as ações destinadas a adultos. Esforços para maximizar a eficácia do tratamento nessa população devem considerar as características da criança, do cuidador, da família e do esquema terapêutico, além de aspectos socioculturais.  
Os fatores mais comumente associados à adesão insuficiente entre crianças e adolescentes são: atraso no desenvolvimento físico e cognitivo; cuidadores com dificuldade de compreensão sobre o tratamento; desafios de relacionamento e comunicação entre pais e filhos; palatabilidade e efeitos adversos dos medicamentos; preconceito nos grupos de socialização (escola, amigos); e atitudes oposicionistas e de revolta frente a uma revelação de diagnóstico inadequada ou o desconhecimento do diagnóstico<sup>17,18</sup> . Esses aspectos ilustram a dificuldade de manter níveis adequados de adesão e ressaltam a necessidade de trabalhar em parceria com os cuidadores para garantir que a educação, apoio e avaliação sejam constantes no atendimento a crianças e adolescentes<sup>19,20</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Cuidadores:** -->
São eles que administram os medicamentos às crianças mais novas. Embora esse papel diminua à medida que a criança cresce, a necessidade do cuidador e do apoio familiar permanece crítica em todas as idades.  
Para tanto, eles precisam aprender como administrar o medicamento, entender o funcionamento da terapia e assumir a responsabilidade nesse cuidado. No início da TARV, deve-se considerar, principalmente, a preparação e orientação dos cuidadores.  
Diante da relevância do papel do cuidador na adesão ao tratamento, vale a pena que a equipe de saúde olhe com bastante atenção e o auxilie no sentido de apoiá-lo e fortalecê-lo. Cuidar do cuidador é fundamental para o sucesso da adesão. É necessário sempre envolver a rede multidisciplinar nesse contexto, pois os cuidadores podem buscar apoio também nas Políticas de Assistência Social e Educação, por exemplo.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Forma farmacêutica dos medicamentos:** -->
Apesar dos avanços recentes em relação à complexidade e apresentações do tratamento ARV, muitos desafios permanecem para as crianças.  
Soluções orais permitem a dosagem adequada para crianças; no entanto, os cuidadores não familiarizados com medições líquidas podem ter dificuldade em calcular precisamente a dose.  
Outras questões relacionadas com medicamentos de uso pediátrico são apresentação e palatabilidade: alguns medicamentos são adocicados e facilmente deglutidos, outros não. Quando a não adesão está relacionada com a palatabilidade de uma formulação líquida, pode-se administrá-la simultaneamente com alimentos ou mascará-la com xarope aromatizado<sup>21–23</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Adolescência:** -->
Na adolescência, é frequente a redução da adesão ao tratamento, com menores índices de controle da replicação viral e maiores taxas de rebote virológico após a supressão inicial. Faz-se necessária a  
9  
consolidação da relação entre o profissional e o adolescente, com escuta e sugestões de soluções em conjunto para a superação das barreiras.  
A família, cuidadores e amigos possuem papel fundamental na adesão ao tratamento daqueles que vivem com HIV/aids.  
Para apoiar a adesão dos adolescentes aos ARV, os profissionais devem manter uma atitude de não julgamento, estabelecer relação de confiança com os usuários/cuidadores e identificar e pactuar objetivos mutuamente aceitáveis para o cuidado<sup>24,25</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Equipe multiprofissional:** -->
Crianças, adolescentes e seus cuidadores devem ser atendidos preferencialmente por equipe multiprofissional sensibilizada e capacitada para acolher, informar e proporcionar um atendimento integral.  
A organização do serviço pode ser um fator de promoção da adesão. A equipe deve ser constituída, preferencialmente, por profissionais das áreas médica, de enfermagem, do serviço social, psicologia, farmácia, nutrição, terapia ocupacional e saúde bucal, entre outras. A articulação e interface com outros profissionais e serviços é essencial para a garantia da qualidade do atendimento.  
A relação de confiança e o uso de linguagem acessível e individualizada facilitam uma melhor interação e comunicação. A escuta dos contextos individuais favorece uma abordagem mais resolutiva.  
A equipe envolvida no cuidado deve ter sempre em mente que a adesão é um desafio que sofre oscilações e requer atenção contínua. Não pode ser entendida como uma característica das pessoas, e sim como um processo em que a pessoa não “é aderente”, mas “está aderente”. O acompanhamento da adesão cabe a todos os envolvidos, tendo como principal ferramenta a abordagem de cada caso por meio do diálogo franco entre crianças, adolescentes, cuidadores e equipe. Valorizar suas histórias de vida e vivências, além de incluí-las no próprio cuidado, são fatores essenciais para a efetividade do tratamento<sup>26–28</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **4.2. Antes do início da TARV** -->
A adesão ao tratamento e a identificação de potenciais problemas devem ser abordadas antes do início da TARV e nas visitas subsequentes. Assim, é necessário:  
- <mark>Fornecer informações sobre HIV/aids e a importância do tratamento para a manutenção da</mark> qualidade de vida da criança/adolescente.  
- Identificar possíveis barreiras a uma boa adesão.  
- Avaliar se a criança tem capacidade para engolir o comprimido e oferecer treinamento, se necessário.  
- Adequar o esquema terapêutico à realidade do paciente, considerando os horários de escola e as atividades cotidianas da criança/adolescente.  
- Identificar o responsável pela administração e supervisão da ingestão do medicamento.  
10

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **4.3. Medidas de avaliação da adesão** -->
O acompanhamento e avaliação da adesão ao tratamento são grandes desafios para quem trabalha em saúde, uma vez que os métodos ou procedimentos disponíveis são sempre parciais e apresentam vantagens e desvantagens.  
A grande dificuldade quando se fala em adesão insuficiente é sua correta identificação. Os métodos diretos utilizam dosagem de medicamentos ativos ou de seus metabólitos no sangue, fluidos e cabelos; porém, são caros e de difícil execução em nosso meio. Os métodos indiretos são mais utilizados e incluem: informação por parte do usuário, informação por parte do cuidador, comparecimento às consultas, frequência de retirada de medicamentos na farmácia (pode ser acessada via SICLOM), contagem de pílulas dos frascos retornados à farmácia, observação direta da terapia (algumas vezes durante hospitalização), impacto da terapia na carga viral do HIV (CV-HIV) e na contagem de linfócitos T (LT)-CD4+<sup>29–34</sup> .  
Alguns métodos para avaliação da adesão estão descritos no **Quadro 3** .  
**Quadro 3:** Métodos para a avaliação da adesão.  
|**MÉTODO**||**INTERVENÇÃO**|
|---|---|---|
|Entrevistar a c<br>Reavaliar os ú|riança e o cuidador<br>ltimos dias:|Identificar os membros da família que podem<br>ajudar;|
||Quem oferece os medicamentos|Estabelecer a rotina dos medicamentos;|
||Horários fornecidos|Mostrar os medicamentos e explicar seus nomes;|
|<br>|Nomear os medicamentos<br>Onde são guardados|Contato com o usuário caso não sejam retirados os<br>medicamentos no período previsto;<br>|
|Verificar a reti<br>Observar a tom<br>Avaliação psic|rada do medicamento na farmácia;<br>ada dos medicamentos;<br>ológica;|Simplificar esquemas e horários, usar alarmes e<br>lembretes para os horários de tomada dos<br>medicamentos;<br>Avaliar as dificuldades, aceitação, revelação<br>diagnóstica.|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **4.4. Estratégias de adesão** -->
Várias estratégias de adesão são descritas, e a combinação entre elas tende a apresentar maior efeito na prática clínica<sup>34–45</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **ESTRATÉGIAS DE ADESÃO** -->
 **Esquema ARV:** escolher o esquema mais simples e palatável possível, reduzindo a frequência de uso e o número de comprimidos. Orientar a pessoa sobre formas de “mascarar” o sabor desagradável dos medicamentos, administrando-os com alimentos ou outros aromas.  
 **Plano para tomada dos medicamentos:** considerar as rotinas e as variações semanais da criança, do adolescente e de seus cuidadores. Tentar associar as tomadas com atividades diárias da criança, como escovar os dentes.  
 **Informação em saúde:** promover o acesso objetivo dos cuidadores às informações sobre a saúde da criança/adolescente e sobre o tratamento. O uso de material escrito, figuras, desenhos, gráficos e vídeos são algumas das estratégias que podem se somar às informações e explicações dadas em conversa aberta e franca. A criança/adolescente também deve receber informações sobre a sua saúde, respeitando e alinhando seu grau de maturidade com a complexidade da informação que será transmitida.  
11  
Após a revelação diagnóstica, o detalhamento das informações transmitidas poderá ser mais detalhado e adequado ao grau de maturidade.  
 **Terapia diretamente observada:** orientar que as doses dos medicamentos sejam tomadas na presença do cuidador.  
 **Lembretes:** utilizar caixas de comprimidos ( _pillbox_ ) e alarmes para ajudar a lembrar de cada tomada dos medicamentos.  
 **Técnicas motivacionais:** especialmente, a aplicação de reforços positivos e o uso de pequenos incentivos para a tomada de medicamentos podem ser instrumentos eficazes para promover a adesão, especialmente, entre os mais jovens.  
 **Grupos de adesão/apoio:** habitualmente abertos e conduzidos por profissionais da própria equipe, têm caráter informativo, reflexivo e de suporte e podem ser interessantes entre grupos de cuidadores, para que compartilhem experiências entre si.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **5. TERAPIA ANTIRRETROVIRAL EM CRIANÇAS E ADOLESCENTES VIVENDO COM HIV** -->
A introdução da TARV combinada com três medicamentos reduziu substancialmente a mortalidade e morbidade de crianças, adolescentes e adultos infectados pelo HIV. Considerando que na população pediátrica as opções de medicamentos são restritas, principalmente, pela ausência de formulações específicas, e sendo a infecção pelo HIV uma doença crônica, deve-se ponderar uma abordagem racional para a introdução da TARV, bem como para a escolha dos esquemas ARV iniciais e subsequentes<sup>46</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **5.1. Objetivos e benefícios esperados da terapia antirretroviral** -->
Os objetivos da TARV em crianças e adolescentes são:

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **OBJETIVOS DA TARV EM CRIANÇAS E ADOLESCENTES:** -->
 Reduzir a morbimortalidade e melhorar a qualidade de vida;  
 Propiciar crescimento e desenvolvimento adequados;  
 Preservar, melhorar ou reconstituir o funcionamento do sistema imunológico, reduzindo a ocorrência de complicações infecciosas e não infecciosas;  
 Proporcionar supressão máxima e prolongada da replicação do HIV, reduzindo o risco de resistência aos ARV;  
- Reduzir o processo inflamatório;  
- Diminuir o reservatório viral.  
Antes de iniciar ou trocar a TARV, a equipe de saúde deve estar atenta a fatores importantes que influenciam a adesão e tolerabilidade aos medicamentos.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **FATORES A SEREM AVALIADOS ANTES DO INÍCIO OU TROCA DE TARV:** -->
 Promover adesão satisfatória em curto e longo prazo e monitorá-la sistematicamente;  Buscar o menor impacto possível sobre o bem-estar, a rotina diária e a qualidade de vida da <u>pessoa vivendo com HIV (PVHA), com a escolha de esquemas potentes, com atividade farmacológica</u>  
12  
conhecida em crianças e adolescentes, dose adequada segundo critérios de peso corporal, superfície corpórea e idade, boa palatabilidade, boa tolerância e a menor toxicidade possível;  Avaliar o efeito do tratamento e a presença de coinfecções ou comorbidades como TB, hepatites B ou C, doenças renais ou hepáticas crônicas e interações medicamentosas;  Promover a integração dos pais, cuidadores ou demais pessoas envolvidas no tratamento.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **5.2. Quando iniciar** -->
A terapia antirretroviral deve ser indicada para todas as crianças e adolescentes vivendo com HIV, independentemente dos fatores clínicos, CV-HIV e contagem de LT-CD4+<sup>47</sup> .  
O **início da TARV, independentemente da contagem de LT–CD4+ e dos sintomas, apresenta benefícios comprovados** em relação à evolução da doença e diminuição de morbimortalidade<sup>48</sup> .  
A progressão da infecção pelo HIV é mais rápida em crianças do que em adultos e os parâmetros laboratoriais, como CV-HIV e LT-CD4+, não apresentam a mesma sensibilidade em predizer risco de progressão da doença.  
A manutenção da replicação viral pode acarretar processo inflamatório persistente e desenvolvimento de doença cardiovascular, renal e hepática, além de outras doenças, sendo necessário controlar a replicação viral precocemente<sup>49</sup> .  
O **início precoce da TARV em crianças e adolescentes está relacionado a menor risco de doenças**<sup>50</sup> , menor mortalidade<sup>51,</sup> melhora dos padrões imunológicos e regularidade do desenvolvimento puberal<sup>52</sup> . Dessa forma, o controle da replicação viral precoce favorece a preservação do sistema imune, previne a resistência viral e a progressão para imunodeficiência avançada<sup>53,54</sup> . A **genotipagem do HIV prétratamento está indicada** e a amostra deve ser coletada anteriormente à prescrição médica.  
Antes de iniciar a TARV, o(a) cuidador(a) deve estar ciente da importância de adesão e não interrupção terapêutica; além da possibilidade de surgimento de eventos adversos. Assim, o vínculo do serviço de saúde com a família e/ou responsável está relacionado a melhor adesão e sucesso terapêutico.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **5.3. Priorização de atendimento às crianças vivendo com HIV** -->
Todas as crianças e adolescentes vivendo com HIV devem ter a TARV iniciada logo após o diagnóstico. Assim, tais situações exigem dos serviços de assistência organização para priorizar o atendimento e diminuir o tempo entre o diagnóstico e o início de tratamento.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **5.3.1. Crianças com idade inferior a 12 meses** -->
A infecção pelo HIV em crianças com idade abaixo de 12 meses, devido à imaturidade imunológica, apresenta evolução mais rápida para fases avançadas da doença.  
Esse grupo tem benefício evidente do início precoce da TARV, o que é comprovado em relação aos desfechos clínicos, recuperação de sistema imune, e redução de processo inflamatório e dos reservatórios virais<sup>55,56</sup> .  
13  
Crianças expostas ao HIV durante a gestação e parto, e com carga viral detectável devem iniciar com tratamento **preemptivo** imediatamente, mantê-lo até a confirmação diagnóstica e adequá-lo de acordo com a faixa etária e informações clínicas e laboratoriais disponíveis.  
A classificação atual da doença pediátrica pelo HIV é baseada na contagem absoluta de CD4 ( **Quadro 4** ), que é o ensaio preferido para monitorar e estimar o risco de progressão da doença e infecções oportunistas.  
**Quadro 4:** Classificação imunológica do HIV com base em LT-CD4+, em números absolutos e percentuais, e de acordo com a idade.  
|||**Co**|**ntagem do LT-**|**CD4+ por i**|**dade**||
|---|---|---|---|---|---|---|
|**Classificação de**<br>**imunossupressão**|**< 1 an**<br>**células/**<br>**mm**<sup>**3**</sup>|**o**<br>**%**|**1 a 6 a**<br>**células/**<br>**mm**<sup>**3**</sup>|**nos**<br>**%**|**≥ 6 an**<br>**células/**<br>**mm**<sup>**3**</sup>|**os**<br>**%**|
|1 – Ausente|≥1.500|≥34|≥1.000|≥30|≥500|≥26|
|2 – Moderada|750-1.490|26-33|500-999|22-29|200-499|14-25|
|3 – Grave<sup>(a)</sup>|<750|<26|<500|<22|<200|<14|
|Fonte: Frieden et a|l (2014)<sup>57</sup>||||||  
(a) Independentemente do resultado da contagem de LT-CD4+, na presença de uma infecção oportunista, a classificação 3 (grave) é estabelecida.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **5.3.2. Crianças em imunodepressão** -->
As crianças vivendo com HIV apresentam maior risco de rápida evolução para imunodeficiência, com risco aumentado de infecções oportunistas e óbito.  
Crianças em imunodepressão devem iniciar a TARV de imediato. Além do benefício de supressão da CV-HIV, há melhora no crescimento e desenvolvimento infantil. O atendimento para início de TARV deve ser priorizado, especialmente quando apresentam imunodepressão grave ou doença oportunista.  
A imunossupressão é monitorada por meio da contagem de LT-CD4+ e LT-CD8+ ou do seu valor em porcentagem, conforme **Quadro 4** . A presença de doença oportunista caracteriza a imunodepressão como grave, independente da contagem de LT-CD4+.  
**O valor absoluto da contagem de LT-CD4+ é priorizado em relação ao valor percentual até os cinco anos de idade.**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **6. TUBERCULOSE** -->
Crianças e adolescentes com diagnóstico de tuberculose (TB) e que não tenham iniciado com TARV devem ser priorizados para atendimento e seguimento clínico.  
A coinfecção TB-HIV caracteriza imunossupressão, independentemente da contagem de LTCD4+. O início precoce da TARV nessa população está relacionado à diminuição de mortalidade.  
O tratamento para crianças coinfectadas deve ser avaliado com atenção devido a possíveis interações entre os medicamentos específicos de cada agravo.  
14  
As coinfecções com HIV (diagnóstico e manejo) serão contempladas em próximo módulo da atualização deste documento técnico.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7. COMO INICIAR A TARV** -->
A abordagem multidisciplinar é fundamental para o sucesso terapêutico. Antes do início ou após a troca de esquemas, a equipe de saúde deve estar atenta a fatores importantes que influenciam a adesão e a tolerabilidade aos medicamentos ( **Quadro 5** ).  
**Quadro 5:** Fatores a serem avaliados antes do início ou troca da TARV em crianças e adolescentes  
- Promover adesão satisfatória em curto e longo prazo e monitorá-la sistematicamente;  
- Buscar o menor impacto possível sobre o bem-estar, a rotina diária e a qualidade de vida, com a escolha de esquemas potentes, com atividade farmacológica conhecida em crianças e adolescentes, dose adequada segundo critérios de peso corporal, superfície corpórea e idade, menor toxicidade possível, boa palatabilidade e tolerância;  
- Orientar sobre medidas de controle de sinais/sintomas relacionados aos ARV;  
- Avaliar o efeito do tratamento e a presença de coinfecções ou comorbidades, como TB, hepatites B ou C, doenças renais ou hepáticas crônicas e interações medicamentosas;  
- Orientar sobre a importância do tratamento e seguimento aos responsáveis e cuidadores;  
- Promover a integração dos pais, cuidadores ou demais pessoas envolvidas no tratamento.  
As crianças infectadas pelo HIV, em sua maioria, possuem histórico de exposição aos ARV desde a vida intrauterina e após o nascimento. Consequentemente, podem apresentar resistência antes do início do tratamento, inclusive à nevirapina e à zidovudina, medicamentos disponíveis para essa faixa etária.  
Assim, **a coleta de genotipagem pré-tratamento está recomendada para todas as crianças e adolescentes antes do início da TARV** , a fim de guiar futuros ajustes necessários para uma terapia eficaz, objetivando a supressão viral<sup>58,59</sup> .  
Para aquelas crianças com indicação para iniciar tratamento preemptivo, a genotipagem deverá ser coletada junto da coleta do segundo exame do fluxo de diagnóstico da infecção pelo HIV com idade igual ou inferior a 18 meses (conforme Módulo 1 deste PCDT) e será executada conforme recomendações do referido fluxo.  
O início da TARV **não** deve ser adiado até o resultado da genotipagem pré-tratamento. Os ajustes de ARV podem ser feitos posteriormente, conforme resultado da genotipagem.  
Os medicamentos escolhidos para compor a TARV inicial são baseados nos seguintes critérios:  
- Dados demonstrativos de supressão viral duradoura, melhora clínica e imunológica;  
- Experiência pediátrica com os diferentes medicamentos e esquemas antirretrovirais;  
- Incidência de eventos adversos de curto e médio prazo dos diversos esquemas antirretrovirais;  
- Disponibilidade e palatabilidade das formulações pediátricas;  
15  
- Comodidade posológica, incluindo o número de doses, necessidade de jejum ou ingestão de alimentos;  
- Potencial de interação com outros medicamentos.  
O esquema terapêutico inicial deve ser estruturado com três antirretrovirais, sendo dois inibidores da transcriptase reversa (ITRN), associado a um terceiro ARV de classe terapêutica diferente: inibidores da integrase (INI) ou inibidores de protease (IP/r) ou, excepcionalmente, inibidores da transcriptase reversa não análogos de nucleosídeos (ITRNN). A escolha do medicamento deve estar relacionada à faixa etária.  
Com a incorporação do INI **dolutegravir 5 mg** comprimido dispersível, recomenda-se seu uso para crianças vivendo com HIV/aids (CVHA) com **idade igual ou superior a quatro semanas de vida ou peso maior ou igual a 3 kg** .  
Desta forma, **dolutegravir 5 mg** comprimido dispersível é o **medicamento preferencial em terapia ARV inicial,** além das indicações de profilaxia pós exposição ao HIV, para crianças entre quatro semanas (um mês) e seis anos de idade (com peso corporal de 3 kg a 19 kg), conforme **Quadro 6** .  
**Quadro 6:** Esquemas de administração de dolutegravir 5 mg comprimido dispersível.  
|**Peso**|**Dose**|**Quantidade de compr**|**imidos**||
|---|---|---|---|---|
|3 a até 6 kg|5 mg|1 comprimido 1x/dia|||
|6 a até 10 kg:<br>(pacientes até 6 meses de idade)|10 mg|2 comprimidos 1x/dia|||
|6 a até 10 kg:<br>(pacientes acima de 6 meses de idade)|15 mg|3 comprimidos 1x/dia|||
|10 a até 14 kg|20 mg|4 comprimidos 1x/dia|||
|14 a até 20 kg|25 mg|5 comprimidos 1x/dia|||
|>/= 20 kg|30 mg|6 comprimidos 1x/dia|||
|Fonte:<br>Bula<br>do<br>medicame|nto<br>Tivicay|PD<sup>®</sup><br>(ANVISA).|Disponível|em:|
|https://consultas.anvisa.gov.br/#/bulario/q/?n|omeProduto=tiv|icay%20PD|||  
Não há dados suficientes sobre a segurança e a eficácia de dolutegravir comprimidos dispersíveis em crianças com idade inferior a 4 semanas ou menos de 3 kg.  
Em **crianças com peso corporal igual ou maior que 20 kg,** pode ser utilizado o **dolutegravir de 50 mg** comprimido revestido, uma vez ao dia. O uso de dolutegravir 5 mg comprimido dispersível deve ter indicação restrita, em crianças com esse peso corporal, naquelas que não consigam deglutir comprimidos.  
Recomenda-se ainda aumentar dose de dolutegravir, administrando-o duas vezes ao dia (a cada 12 horas) se ele for usado associado ao efavirenz, carbamazepina ou rifampicina. Para demais recomendações quanto ao preparo e diluição dos comprimidos dispersíveis, recomenda-se consultar a bula do medicamento aprovada pela ANVISA.  
O **Quadro 7** apresenta os esquemas completos de TARV para crianças e adolescentes.  
**Quadro 7:** Esquema completo de TARV para crianças e adolescentes.  
|**Faixa etária**|**Preferencial**<br>|**º  **|**Alternativo**<br>|**º  **|
|---|---|---|---|---|
||**ITRN**|**3 ARV**|**ITRN**|**3 ARV**|
|**1º mês**|Zidovudina+<br>Lamivudina<br>(AZT + 3TC)|Raltegravir<br>(RAL)|Zidovudina+<br>Lamivudina<br>(AZT + 3TC)|Lopinavir/<br>ritonavir (LPV/r)<br>(a partir do 14º dia<br>de vida)|  
16  
|**Fi tái**|**Preferencial**||**Alternativo**||
|---|---|---|---|---|
|**axa era**|**ITRN**|**3º ARV**|**ITRN**|**3º ARV**|
|**2º mês a 3**<br>**anos**|Zidovudina+<br>Lamivudina<br>(AZT + 3TC)<br>**ou**<br>Abacavir<sup>a</sup>+ Lamivudina<br>(ABC<br>+<br>3TC)<br>(preferencial a partir do<br>3º mês)|Dolutegravir<sup>b</sup><br>(DTG)|Zidovudina+<br>Lamivudina<br>(AZT + 3TC)|Lopinavir/<br>ritonavir (LPV/r)|
|**3 a 6 anos**|Abacavir<sup>a</sup>+ Lamivudina<br>(ABC + 3TC)|Dolutegravir<sup>b</sup><br>(DTG)|Zidovudina+<br>Lamivudina<br>(AZT + 3TC)<br>**ou**<br>Tenofovir<sup>d</sup>+<br>Lamivudina<br>(TDF+3TC)|Lopinavir/<br>ritonavir (LPV/r)<br>**ou**<br>Darunavir<sup>c</sup>+<br>Ritonavir<br>(DRV+RTV)|
|**6 a 12 anos**|Abacavir<sup>a</sup>+ Lamivudina<br>(ABC + 3TC)|Dolutegravir<sup>b</sup><br>(DTG)<sup>b</sup>|Zidovudina+<br>Lamivudina<br>(AZT + 3TC)<br>**ou**<br>Tenofovir<sup>d</sup>+<br>Lamivudina<br>(TDF+3TC)|Darunavir<sup>c</sup>+<br>Ritonavir<br>(DRV+RTV)<br>**ou**<br>Lopinavir/<br>ritonavir (LPV/r)|
|**Acima de 12**<br>**anos**|Tenofovir<sup>d</sup>+<br>Lamivudina<br>(TDF+3TC)|Dolutegravir<sup>b</sup><br>(DTG)|Abacavir<sup>a</sup><br>+<br>Lamivudina<br>(ABC + 3TC)<br>**ou**<br>Zidovudina+<br>Lamivudina<br>(AZT + 3TC)|Darunavir<sup>c</sup>+<br>Ritonavir<br>(DRV+RTV)|  
Fonte: DATHI/SVSA/MS  
Notas:  
(a) Abacavir a partir do 3º mês de vida e com teste de HLA-B*5701 negativo. (b) Dolutegravir 5 mg a partir do 2º mês de vida e peso ≥ 3 kg. Dolutegravir 50 mg a partir de 6 anos ou 20 kg.  
(c) Darunavir para crianças maiores de 3 anos e com peso igual ou superior a 15 kg, que consigam deglutir o comprimido.  
(d) Tenofovir em crianças com peso a partir de 35 kg.  
O **Quadro 7** contempla as possíveis alternativas para compor o esquema triplo ARV, a depender de avaliação individualizada da equipe assistencial e da recomendação por faixas etárias ou peso corporal que constam em respectivas bulas. O **Apêndice E** traz informações sobre cada um dos ARV utilizados por crianças e adolescentes.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7.1.1. Dupla de ITRN** -->
Devido à ótima eficácia, barreira genética e segurança, a dupla de ITRN é escolhida para compor a “espinha dorsal” ( _backbone_ ) do esquema terapêutico.  
As associações preferenciais em pediatria são formulações contendo dois medicamentos: zidovudina com lamivudina (AZT + 3TC), tenofovir com lamivudina (TDF + 3TC) ou as terapias combinadas abacavir e lamivudina (ABC + 3TC) que devem ser prescritas conforme faixa etária permitida para cada medicamento, respeitando as contraindicações.  
17  
A associação abacavir e lamivudina tem se mostrado tão ou até mais potente do que zidovudina + lamivudina.  
Há possibilidade de administração em dose diária de abacavir e tenofovir. Em pacientes estáveis (CV indetectável e LT-CD4+ estável durante 6 meses), recomenda-se usar abacavir na dose de 16 mg/kg, uma vez ao dia (dose máxima de 600 mg 1 vez/dia); ou se paciente possuir peso acima de 25 kg, 600 mg 1x dia.  
A lamivudina, em crianças com peso acima de 25 kg deve ser usada em doses de 150 mg de 12/12h ou 300 mg em dose única diária.  
Deve-se realizar o exame HLA-B*5701 para avaliar a predisposição genética à reação de hipersensibilidade ao ABC<sup>60</sup> .  
<mark>O</mark> **<mark>abacavir</mark>** <mark>está relacionado à reação de hipersensibilidade em indivíduos com presença do</mark> antígeno HLA-B*5701. Portanto, o uso deste ARV deve ocorrer apenas por aqueles com pesquisa negativa para o antígeno.  
**Destaca-se que não se deve postergar a terapia na indisponibilidade ou atraso do resultado do exame.** Nesse caso, introduzir outro ITRN alternativo e, caso possível, fazer a troca para o ABC posteriormente.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Inibidores de Integrase (INI)** -->
Os INI são medicamentos com alta eficácia, melhor tolerabilidade e baixa interação com outros medicamentos<sup>61,62</sup> .  
O dolutegravir é a primeira opção como terceiro ARV para compor os esquemas de TARV em crianças a partir do segundo mês de vida. Este ARV possui alta barreira genética, levando rapidamente à indetecção viral. Do segundo mês de vida aos seis anos, deve ser administrado o comprimido dispersível de 5 mg, conforme o peso da criança.  
Em crianças após os seis anos de idade e com peso superior a 20 kg, deve ser administrado o comprimido de 50 mg, uma vez ao dia.<sup>63</sup>  
O raltegravir é o medicamento de escolha preferencial para início de tratamento durante o primeiro mês de vida.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Inibidor de protease com reforço de ritonavir (IP/r)** -->
Os inibidores de protease possuem eficácia clínica, virológica e imunológica. Além dessas vantagens, os IP/r têm elevada barreira genética, dificultando o desenvolvimento de resistência.  
Entre 14 dias e seis anos de idade, o lopinavir/r está disponível para uso e é indicado por sua segurança e eficácia. Este medicamento possui boa barreira genética e é recomendado para crianças com contraindicação ao uso dos esquemas preferenciais.  
18  
O darunavir (DRV) com reforço do ritonavir é o IP/r preferencial a partir dos três anos de vida e a partir de 15 kg. O uso do darunavir 800 mg é permitido para crianças acima de 12 anos.  
As principais desvantagens relacionadas ao uso de IP/r são as alterações metabólicas, como dislipidemia, lipodistrofia e resistência à insulina e a sua palatabilidade.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **ITRNN** -->
Os medicamentos disponíveis desse grupo para pediatria são nevirapina, efavirenz e etravirina. As principais vantagens dos esquemas compostos com ITRNN são: menor risco de dislipidemia e lipodistrofia em relação ao IP/r, menor número de comprimidos e meia vida longa, permitindo melhor posologia.  
As desvantagens dos esquemas compostos por ITRNN está relacionada à baixa barreira genética dos ARV desse grupo. Uma única mutação pode comprometer a TARV. A resistência cruzada entre nevirapina e efavirenz pode prejudicar a sensibilidade da etravirina.  
No grupo pediátrico, existe alta prevalência de resistência primária aos medicamentos nevirapina e efavirenz<sup>64</sup> . Dessa forma, o uso de tal classe deve ficar reservada a situações específicas, como esquemas alternativos, e com genotipagem comprovando sensibilidade à classe.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7.2. Monitoramento/Acompanhamento** -->
O acompanhamento de crianças e adolescentes vivendo com HIV deve ser realizado rotineiramente; tendo em vista que diversos fatores podem mudar ao longo do tempo e com a idade, além de estarem relacionados ao alcance do sucesso terapêutico.  
Inicialmente, de acordo com as características de cada usuário e seu cuidador, as avaliações clínicas, com equipe multidisciplinar e laboratorial, devem ser feitas com mais frequência. A principal razão dessas avaliações é identificar efeitos adversos relacionados aos ARV e erros de administração que possam causar falha virológica e consequente falha terapêutica.  
Os objetivos do monitoramento terapêutico estão descritos no **Quadro 8** .  
**Quadro 8:** Objetivos do monitoramento terapêutico.  
- Avaliar adesão à TARV  
- Identificar sinais/sintomas relacionados aos ARV e orientar medidas de controle ou troca de esquema  
- Avaliar CV-HIV e LT-CD4+  
- Identificar sinais/sintomas relacionados à Síndrome da Recuperação Imunológica  
- Manter crescimento e desenvolvimento adequado para faixa etária  
Fonte: DATHI/SVSA/MS  
No atendimento, antes de iniciar a TARV, devem ser registrados adequadamente todos os dados clínicos, antropométricos (peso, altura, IMC e perímetro cefálico em RN e lactentes) e alterações encontradas no exame físico. As informações registradas são importantes para acompanhamento e avaliação da resposta à TARV nas consultas subsequentes.  
19  
Em todos os atendimentos subsequentes ao início do tratamento, deve-se avaliar alterações em relação ao quadro basal do indivíduo, presença de eventos adversos, adesão e avaliação social para identificar possíveis dificuldades e risco de abandono de seguimento.  
A avaliação de adesão deve ser minuciosa, com detalhada investigação sobre como é realizada a administração dos medicamentos, bem como, sua frequência. As falhas de adesão precisam ser investigadas com objetivo de encontrar qual a principal causa da não administração dos medicamentos, e então, iniciar medidas para auxiliar na resolução e adesão adequada.  
A periodicidade e intervenções sugeridas no monitoramento da resposta terapêutica e segurança (efeitos adversos) do uso de ARV estão descritas no **Quadro 9** .  
**Quadro 9:** Periodicidade e intervenções sugeridas no monitoramento da resposta terapêutica e segurança do uso de antirretrovirais.  
|**Tempo de uso da terapia**|**Toxicidade**|**Adesão e resposta terapêutica**|
|---|---|---|
|**Antes do início da terapia**|História clínica e bioquímica|História clínica, antropometria e exame<br>físico.<br>Avaliação psicológica e social.<br>CV-HIVe contagem de LT-CD4+|
|**2-4 semanas**|História clínica|Avaliação da adesão|
|**8-12 semanas**|História clínica, hemograma e<br>bioquímica|História clínica, antropometria e exame<br>físico.<br>Avaliação da adesão.<br>CV-HIVe contagem de LT-CD4+|
|**A cada 3-4 meses**|História clínica, hemograma e<br>bioquímica|Avaliação da adesão.<br>CV-HIVe contagem de LT-CD4+|
|**A cada 6-12 meses**|Lipidograma completo|Avaliação da adesão|  
Fonte: DATHI/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: 7.3. Acompanhamento laboratorial -->
O seguimento do tratamento deve ser feito desde o primeiro atendimento, antes mesmo do início da TARV, para registrar os dados basais.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7.3.1. Linfócitos T CD4 +** -->
A contagem absoluta de linfócitos T-CD4+ e CD8+ é recomendada para monitorar o estado imunológico em todas as crianças, sendo os valores percentuais uma alternativa para menores de 5 anos.  
A interpretação das variações na contagem de LT-CD4+ deve ser cuidadosa, lembrando que flutuações transitórias podem ocorrer devido a doenças comuns na infância, imunizações, exercícios e métodos laboratoriais. Dessa forma, nas situações em que ocorra dúvida do resultado, recomenda-se repetir o exame de LT-CD4+ com pelo menos uma semana de intervalo para confirmação dos valores.  
Nos indivíduos com imunossupressão documentada a partir da contagem de LT-CD4+, recomenda-se sempre avaliar as indicações para profilaxia primária de infecções oportunistas.  
A frequência de realização de LT-CD4 em crianças e adolescentes está descrita no **Quadro 10** .  
20  
**Quadro 10:** Frequência recomendada para coleta de LT-CD4+ em crianças e adolescentes  
- No momento do diagnóstico  
- Antes do início da TARV;  A cada 3 a 4 meses<sup>(a)</sup> ;  Seis semanas após troca da TARV.  
(a) Crianças com adesão ao seguimento e à TARV, com supressão viral nos últimos dois anos podem ter intervalos maiores entre as coletas de LT-CD4+, como a cada 6 meses.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7.3.2. CV-HIV** -->
A criança diagnosticada com HIV apresenta comumente elevada viremia desde o início da infecção, com pico geralmente aos dois meses de vida.  
Além do valor para diagnóstico em crianças abaixo de 18 meses, a CV-HIV é utilizada para acompanhamento de resposta à TARV. Quando comparada aos adultos, a resposta à TARV até a supressão viral pode ser mais demorada em crianças, com esperada diminuição mínima de 1 log em seis meses de tratamento. O maior tempo para alcançar a indetectabilidade está relacionado à dificuldade da terapia, como: concentrações inadequadas dos ARV devido à imaturidade hepática e renal, má absorção, altos valores de CV-HIV basais e dificuldade de administração dos medicamentos<sup>65,66</sup> .  
Assim, a frequência de realização de CV-HIV em crianças e adolescentes está descrita no **Quadro**  
**11** .  
**Quadro 11:** Frequência recomendada para coleta de CV-HIV em crianças e adolescentes  
- No momento do diagnóstico;  
- Antes do início da TARV;  
- Seis semanas após início ou troca da TARV;  
- A cada 3 a 4 meses;  
- Nas situações de suspeita de falha virológica ou quando não houver queda da CV-HIV maior que 1 log da CV-HIV basal (pré-tratamento ou pós-troca da TARV), repetir em 4 semanas para confirmação de falha virológica.  
Fonte: DATHI/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7.4. Síndrome Inflamatória da Reconstituição Imune** -->
A Síndrome Inflamatória da Reconstituição Imune (SIRI) é uma manifestação que ocorre em pessoas vivendo com HIV com algum grau de imunossupressão e após a introdução de TARV. Há poucos estudos sobre a SIRI na população pediátrica, e sua ocorrência é estimada entre 10 a 38% das crianças vivendo com HIV e com início de TARV<sup>67,68</sup> .  
A sua incidência está relacionada com a exposição prévia a antígenos e doenças oportunistas. Por exemplo, a SIRI ocorreu em 37,7% das pessoas com retinite por citomegalovírus; em 19,5% das pessoas com meningite por _Criptococcus sp._ e em 15,7% das pessoas com tuberculose. Em crianças, as causas mais  
21  
comuns de SIRI são infecção por micobactérias, como tuberculose, micobacteriose atípica e vacina BCG 69,70.  
Após o início da TARV, ocorre recuperação da resposta imunológica associada à alta quantidade de antígenos expostos em período de imunossupressão, que leva a uma resposta inflamatória, causando a SIRI.  
A SIRI pode ser apresentada das seguintes formas:  
1. SIRI desmascarada: caracterizada por doença oportunista não diagnosticada ou subclínica e com patógeno identificável.  
2. SIRI paradoxal: identificada por recrudescência de infecção tratada com sucesso anteriormente e marcada pela ativação imune induzida por antígeno, com nenhum ou poucos patógenos detectáveis.  
As manifestações clínicas são linfonodomegalia, febre, perda de peso e piora de sintomas respiratórios. Pode ocorrer também piora de imagem radiológica. Não há marcadores ou exames laboratoriais para confirmação diagnóstica, sendo a SIRI de diagnóstico clínico e de exclusão.  
O tratamento da SIRI depende da forma em que ela se apresentar.  
Na forma **desmascarada** , recomenda-se diagnóstico e tratamento da infecção oportunista, que se apresenta inicialmente de forma oculta e, depois subclínica. Nas formas muito graves, ocasionalmente, o uso de medidas anti-inflamatórias e a suspensão temporária de TARV pode ser necessária.  
Na forma **paradoxal** , o tratamento deve ser baseado em medidas anti-inflamatórias e específicas. As opções terapêuticas devem levar em consideração a gravidade clínica. Os casos leves geralmente só requerem observação clínica. Nos casos moderados, podem ser usados anti-inflamatórios não hormonais. Os casos graves podem necessitar o uso de corticoides, interrupção temporária da TARV e até abordagem cirúrgica<sup>71</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7.5. Estratégia de substituição de tratamento** -->
**No Brasil a “terapia dupla” não é indicada para início de tratamento** . Sua adoção deve ser realizada de maneira criteriosa. Em 2023, foi atualizada a indicação de dolutegravir associado a lamivudina para pacientes a partir de 12 anos e de 40 kg de peso corporal, o que permite a expansão de seu uso nestas condições, como parte da estratégia de **simplificação de tratamento.**  
A estratégia de simplificação da TARV deve ser individualizada e tem como objetivos a maior comodidade posológica, redução de eventos adversos de longo prazo e manutenção da supressão viral. **Para atingir todos estes objetivos, é necessário assegurar a ausência de resistência a lamivudina e dolutegravir.**  
As condições abaixo devem ser observadas para adotar a estratégia de simplificação do tratamento, por meio da terapia dupla<sup>72–75</sup> :  
- Pessoas com CV-HIV indetectável nos últimos seis meses e  
- Boa adesão ao tratamento e  
- Ausência de manifestação clínica de falha imunológica.  
22  
As CVHA que apresentem CV-HIV detectável e estiverem em falha virológica devem realizar exame de genotipagem para escolha do melhor esquema terapêutico, não devendo ter seus esquemas substituídos sem a realização desse exame.  
A estratégia de simplificação por meio da “terapia dupla” é estruturada pela associação de lamivudina com um antirretroviral de alta barreira genética – dolutegravir ou darunavir com reforço de ritonavir – e demonstra segurança e eficácia na manutenção da supressão virológica<sup>76–81</sup> .  
Esses esquemas apresentam vantagens relacionadas à facilidade posológica, e toxicidade.  
Pessoas que mantêm CV-HIV indetectável e múltiplas comorbidades ou risco de alteração da função renal, osteopenia/osteoporose, intolerância ou evento adverso relacionado a outros ARV, podem se beneficiar da “terapia dupla”.  
Os esquemas de terapia dupla adotados no Brasil são:  
**-1ª opção:** Lamivudina 300 mg + dolutegravir 50 mg ou lamivudina/dolutegravir (300/50 mg) em dose fixa combinada.  
- **-2ª opção:** Lamivudina + darunavir 800 mg + ritonavir 100 mg.  
Para a recomendação da “terapia dupla”, devem ser observadas todas as seguintes condições:  
- Ausência de qualquer falha virológica prévia;  
- Adesão regular à TARV;  
- Carga viral indetectável nos últimos 12 meses, sendo a última CV realizada há pelo menos seis meses;  
- Exclusão de coinfecção com hepatite B ou tuberculose;  
- Idade maior ou igual a 18 anos;  
- Não estar gestante;  
- Taxa de filtração glomerular estimada que não implique em redução de dose da lamivudina (TFGe maior que 49 mL/min).  
- Para PVHA com indicação de dolutegravir: não estar em uso de medicamentos que requeiram a dose dobrada de dolutegravir ou que reduzam o nível sérico do medicamento.  
Antes da prescrição, deve-se avaliar a presença de interações medicamentosas que possam impactar na escolha. A ferramenta atualmente disponível em português pode ser encontrada no site: <u>https://interacoeshiv.huesped.org.ar/.</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **7.6. Reintrodução da terapia antirretroviral após interrupção de tratamento** -->
A adesão à terapia antirretroviral é fundamental para o sucesso no tratamento, que pode ser avaliado através de três pilares: supressão virológica (mensurada pela carga viral), recuperação imunológica (LT-CD4+) e ausência de infecções oportunistas.  
Além destes aspectos, crianças e adolescentes apresentam benefícios no crescimento e desenvolvimento, fundamentais nesta fase. Em contrapartida, CVHA com adesão irregular apresentam maior risco de falha virológica e emergência de resistência aos ARV, aumento no risco de transmissão de vírus resistentes, além da progressão do HIV<sup>82–85</sup> .  
23  
As faixas etárias da população incluída neste Protocolo possuem particularidades importantes relacionadas à adesão. Nos primeiros anos de vida, há necessidade de um cuidador para administrar os medicamentos, alguns de difícil palatabilidade ou administração. Esses são fatores que podem estar relacionados à adesão inadequada ao tratamento da criança.  
Ao atingir a adolescência, outros fatores podem levar ao abandono de tratamento. Por isso, o reconhecimento dos indivíduos em abandono de forma precoce pelos profissionais de saúde e dos fatores relacionados é essencial para o tratamento adequado do paciente.  
1. Fatores relacionados a pessoa vivendo com HIV  
- Aspectos psicológicos  
- Aceitação e reconhecimento do diagnóstico  
- Comorbidades  
- Tolerância aos medicamentos  
2. Fatores relacionados aos medicamentos:  
- Eventos adversos  
- Absorção  
- Interação medicamentosa  
- Farmacocinética  
3. Fatores relacionados ao contexto social:  
- Acesso ao serviço de saúde  
- Acesso a transporte  
- Necessidade de cuidador para administração de medicamentos  
- Disponibilidade de insumos e profissionais  
- Vinculação ao centro de tratamento  
Determinantes psicossociais, comportamentais, biológicos e estruturais interferem diretamente na adesão e devem ser contemplados na estratégia de reintrodução da TARV.  
Frente ao abandono do tratamento, uma abordagem ampla e multidisciplinar deve ser realizada na tentativa de estabelecer a sua causa. A abordagem sobre a TARV é importante para garantir que o tratamento permaneça eficaz.  
Alguns antirretrovirais apresentam maior fragilidade quando se trata de resistência, principalmente os pertencentes à classe dos ITRNN, visto que uma única mutação é capaz de gerar resistência, além de fragilizar os demais medicamentos que compõem o esquema<sup>86,87</sup> .  
Antirretrovirais com alta barreira genética (darunavir e dolutegravir) necessitam de um número maior de mutações para o desenvolvimento de resistência. A despeito de tal fato, deve-se garantir que os outros medicamentos associados, principalmente ITRN, mantenham sua atividade, evitando assim a “monoterapia funcional”<sup>87–90</sup> .  
A reintrodução da TARV deve ser uma das prioridades quando a criança vivendo com HIV retorna ao serviço. A TARV deve ser prescrita conforme os esquemas preconizados neste Protocolo. As CVHA em abandono devem ser atendidas de forma prioritária e criteriosa para a reintrodução de TARV.  
24  
A escolha dos ARV que farão parte do esquema de reintrodução deve considerar eventuais fatores relacionados ao abandono, a barreira genética e as possíveis mutações relacionadas ao esquema prévio.  
Como os ARV da classe ITRNN possuem baixa barreira genética e meia vida prolongada, o seu uso irregular está associado a pressão seletiva e surgimento de mutações relacionadas à resistência para esta classe. Desta forma, crianças em abandono de tratamento após uso de ITRNN não devem reiniciar o tratamento com medicamentos desta classe.  
Para os pacientes em abandono das classes INI e IP, pode-se retornar o esquema com IP, em especial considerando LPV/R, e genotipagem após sua introdução. Caso a criança apresente carga viral indetectável, pode-se considerar posterior troca (substituição de tratamento) para dolutegravir, com acompanhamento de CV-HIV coletada 4 a 6 semanas após a troca.  
Na suspeita de imunossupressão e presença de infecções oportunistas que possam postergar o reinício do tratamento, pode-se utilizar ferramentas auxiliares para diagnóstico rápido e efetivo.  
A genotipagem deverá ser coletada se após 4 a 6 semanas da reintrodução da TARV o paciente mantiver carga viral detectável acima de 500 cópias/mL. Nestes casos, deve-se seguir as orientações do item _falha virológica_ .  
Os esquemas para reintrodução estão descritos no **Quadro 12** .  
**Quadro 12:** Esquemas para reintrodução  
|**Abandono**|**Opções de esquema de**<br>**reintrodução**|**Comentários**|
|---|---|---|
|**2 ITRN + 1 ITRNN**|2 ITRN + 1 IP/r|O<br>IP/r<br>pode<br>ser<br>lopinavir/ritonavir, darunavir +<br>ritonavir<br>ou<br>atazanavir<br>+<br>ritonavir|
|**2 ITRN + IP/r**|2 ITRN + IP/r (outros IP/r)|-|
|**2 ITRN + INI**|2 ITRN + 1 IP/r<br>2 ITRN+ DTG 12/12h|01 comprimido de dolutegravir<br>a cada 12 horas|  
Fonte: DATHI/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8. FALHA TERAPÊUTICA EM CRIANÇAS E ADOLESCENTES** -->
A falha terapêutica é uma resposta subótima ou falta de resposta sustentada à TARV, mediante critérios **virológicos, imunológicos e/ou clínicos.** Em geral, a falha virológica pode ocorrer antes da falha clínica e imunológica.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.1. Falha virológica** -->
Falha virológica é caracterizada pela resposta virológica incompleta à TARV, caracterizada pela manutenção da carga viral detectável após pelo menos 6 meses de TARV ou pelo reaparecimento de CVHIV após um período de supressão viral ter sido alcançado.  
A supressão virológica é definida como uma CV-HIV abaixo do limite de detecção, medida por um método altamente sensível, com limites de detecção de 20 cópias/mL.  
25  
A **falha virológica é definida** por dois exames consecutivos, com intervalo de 4 semanas entre eles, de CV-HIV com resultado detectável, sendo o último exame com carga viral acima de 500 cópias/mL.  
Crianças podem levar mais tempo para alcançar CV-HIV indetectável, especialmente lactentes que apresentem elevadas cargas virais pré-tratamento. A ocorrência de infecções transitórias e/ou imunizações, eventos muito comuns na população pediátrica, podem provocar detecção temporária da CVHIV, definido como “blip” e não define falha virológica.  
A replicação transitória, caracterizada por exame de carga viral detectável em níveis baixos entre outros exames com carga viral não detectável, é definida usualmente como “ _blip_ ” e não representa falha virológica. Os “ _blips_ ”, interpretados como episódios isolados de detecção de pequenos aumentos transitórios na carga viral, com CV-HIV até 200 cópias/mL, entre duas CV-HIV indetectáveis, ao longo do tempo); em geral, não estão associados à falha subsequente. Por outro lado, uma viremia baixa persistente pode refletir emergência de resistência e prenunciar falha da TARV. A supressão viral parcial, isto é, a replicação viral na vigência da TARV, leva ao acúmulo progressivo de mutações no genoma viral, que terminam por conferir resistência não só aos medicamentos em uso, como também a outros medicamentos da mesma classe, o que resulta em perda de opções terapêuticas.  
Ao observar a ocorrência de “blips” é fundamental questionar sobre a adesão, uso de medicamentos que possam ter interações com a TARV, além de coletar amostra para repetir a dosagem da CV-HIV.  
Quanto à solicitação do exame de **genotipagem do HIV,** mantém-se a indicação de **genotipagem pré-tratamento** para todas as crianças e adolescentes.  
Além do exame de genotipagem do HIV convencional (avaliação de perfil mutacional em transcriptase reversa e protease); a genotipagem para avaliação do perfil da integrase está indicada nos casos de falha virológica, atual ou pregressa, com esquemas estruturados com raltegravir ou dolutegravir, ou uso prévio de esquema com INI pela mãe.  
Portanto, revoga-se o conteúdo da Nota Técnica nº 16/2023-CGAHV/DCCI/SVS/MS, de 11/01/23 ( _Dispõe sobre atualização nos critérios de falha terapêutica e de indicação de exame de genotipagem do HIV em crianças/adolescentes vivendo com HIV/aids até 13 anos de idade)._

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.2. Falha imunológica** -->
É definida como uma resposta imunológica incompleta à TARV ou deterioração imunológica durante a terapia. Em crianças menores de seis anos, a contagem absoluta de LT-CD4+ normalmente diminui com a idade e esse fator deve ser considerado na avaliação<sup>91,92</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.3. Falha clínica ou terapêutica** -->
É a ocorrência de infecção oportunista (IO) ou outra evidência clínica de progressão da doença após o início da TARV. Representa a categoria mais urgente e mais preocupante de falha terapêutica e necessita de uma avaliação imediata. Contudo, a ocorrência de IO ou outras afecções em pessoas em tratamento com parâmetros virológicos e imunológicos estáveis pode não refletir uma falha clínica, e sim uma disfunção imune ou síndrome da reconstituição imunológica<sup>93</sup> .  
Os eventos clínicos que sugerem falha terapêutica são descritos no **Quadro 13.**  
26  
**Quadro 13:** Eventos clínicos sugestivos de falha terapêutica  
|Deteriora|ção neurológica progressiva;|
|---|---|
|<br>Presenç|a de dois ou mais dos seguintes achados em avaliações repetidas:|
|-|Déficit do crescimento cerebral e/ou do desenvolvimento neuropsicomotor;|
|-|Falha no crescimento (declínio persistente na velocidade de ganho de peso);|
|-|Infecção ou doença grave ou recorrente (recorrência ou persistência de condições<br>definidoras de aids ou outras infecções graves).|
|Fonte: DA|THI/SVSA/MS|
|Os princip|ais fatores relacionados à falha terapêutica estão listados no**Quadro 14**.|  
**Quadro 14:** Fatores associados à falha terapêutica  
|**Baixa adesão ao tratamento**|
|---|
|Considerada uma das causas mais frequentes de falha virológica, a baixa adesão à TARV<br>relaciona-se, sobretudo, ao esquecimento ou à não tomada dos ARV, à complexidade posológica ou à<br>ocorrência de efeitos adversos, devendo ser abordada junto aos cuidadores e, quando possível, com a<br>crianças ou adolescente vivendo com HIV.|
|Destaca-se que a supressão viral pode ser obtida, mesmo sem alteração da TARV, nos casos<br>precocemente identificados de falha associada à má adesão.|
|**Potência virológica insuficiente**|
|A utilização de esquemas subótimos, tais como terapia tripla contendo apenas ITRN ou número<br>insuficiente de medicamentos ativos, pode levar à supressão viral incompleta.|
|**Fatores farmacológicos**|
|Deve-se pesquisar a possibilidade de administração incorreta dos ARV, tais como quebra ou<br>maceração de comprimidos, interações medicamentosas ou erros de prescrição, além de outros fatores<br>que resultem em má absorção ou eliminação acelerada dos medicamentos.<br>**Resistência viral**|
|A resistência genotípica do HIV aos ARV pode ser identificada no momento da falha em até<br>90% dos casos, podendo ser tanto causa como consequência daquela.|

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.4. Discordância entre respostas virológica, imunológica e clínica** -->
Em geral, a TARV que propicia supressão virológica também resulta em melhora imunológica e prevenção de doenças relacionadas à aids. O contrário também ocorre: a falha virológica é comumente acompanhada de falha imunológica e clínica. Entretanto, algumas pessoas podem apresentar discordância, com falha em apenas uma das categorias e com boa resposta nas demais. É essencial considerar causas potenciais de respostas discordantes antes de concluir que houve falha terapêutica.  
27

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.4.1. Respostas clínica e imunológica adequadas apesar de resposta virológica incompleta** -->
Algumas pessoas em TARV podem apresentar respostas clínica e imunológica (LT-CD4+ acima de 500 células/mm<sup>3</sup> ) adequadas por até três anos e manter CV-HIV persistentemente detectável. Uma possível explicação para esse tipo de resposta seria a manutenção de CV-HIV baixa ou a seleção de cepas de HIV com mutações de resistência que apresentam menor “fitness” (capacidade de replicação viral). Recomenda-se realizar exame de genotipagem nesses casos o mais brevemente possível.  
Situações com CV-HIV menor que 500 cópias são de difícil manejo devido à impossibilidade de realização da genotipagem. Contudo, devem ser seguidas as orientações do **Quadro 15** .  
**Quadro 15:** Manejo em situação de baixa viremia  
|**Valor de baixa**<br>**viremia**|**Conduta**|
|---|---|
||-<br>Confirmar com nova CV-HIV em 4 semanas para excluir_blip_;|
|CV-HIV<br>abaixo<br>de 200 cópias/mL|-<br>Reavaliar a adesão e interações farmacológicas;<br>-<br>Manter o esquema antirretroviral;<br>-<br>Realizar uma nova CV-HIV em 12 semanas, com o objetivo de avaliar a<br>permanência de baixa viremia e a necessidade de troca futura da TARV. Considerar<br>discutir caso com Médico Referência de Genotipagem (MRG).|
|CV-HIV a partir<br>de 200 e abaixo de|-<br>Confirmar nova CV-HIV em 4 semanas para excluir_blip_;<br>-<br>Reavaliar adesão e interações farmacológicas;|
|500 cópias/mL|-<br>Considerar troca do esquema antirretroviral baseado no histórico de<br>tratamento, nas genotipagens prévias e discussão do caso com MRG.|  
Fonte: DATHI/SVSA/MS  
As primeiras considerações a serem feitas nesse tipo de resposta são: excluir erro laboratorial no resultado do exame de LT-CD4+ e da CV-HIV assegurar interpretação correta dos valores de LT-CD4+ em relação à diminuição natural que ocorre nos primeiros cinco a seis anos de vida. Outra consideração laboratorial é que alguns métodos laboratoriais de CV-HIV não amplificam todos os grupos de HIV.  
Com a confirmação dos resultados laboratoriais, deve-se avaliar a possibilidade de eventos adversos dos medicamentos, afecções associadas ou outros fatores que possam resultar em menores valores de LT-CD4+.  
Alguns ARV podem estar associados a uma resposta imunológica comprometida, como a combinação de tenofovir com atazanavir.  
A zidovudina pode comprometer a elevação do valor de LT-CD4+, mas não a sua porcentagem, talvez pelo seu efeito mielotóxico.  
Alguns medicamentos (corticoides, quimioterápicos) e determinadas condições clínicas (hepatite C, tuberculose, desnutrição, síndrome de Sjögren, sarcoidose, sífilis, infecção viral aguda) estão associadas a menores valores de LT-CD4+.  
28

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.4.2. Falha clínica com resposta virológica e imunológica adequadas** -->
Pessoas que apresentam progressão da doença com resposta virológica e imunológica favoráveis devem ser avaliadas cuidadosamente, pois a maioria dos casos não representa falha aos ARV.  
Nos primeiros meses do início da TARV, uma das principais razões para ocorrência de IO nessa situação é a SIRI, o que não indica falha à TARV.  
Crianças que sofreram lesões pulmonares irreversíveis (bronquiectasias), neurológicas ou em outros órgãos, especialmente em vigência de imunossupressão grave, podem continuar apresentando infecções e sintomas recorrentes, mesmo com a recuperação imunológica. Esses casos também não representam falha terapêutica e não há indicação de mudança de TARV.  
Mais raramente, crianças com valores de LT-CD4+ normais e supressão virológica podem apresentar IO, como pneumocistose ou candidíase esofágica, não relacionada à SIRI ou lesão permanente. Esses casos indicam que, apesar da recuperação do valor do LT-CD4+, não houve normalização da função imunológica e o esquema da TARV deve ser reavaliado.  
Uma outra situação é a criança que apresenta alteração do desenvolvimento neuropsicomotor. Nesse caso, deve-se reavaliar a TARV e, se necessário, incluir medicamentos que alcancem boa penetração no SNC.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.5. Avaliação da criança e adolescente em falha terapêutica** -->
As crianças e adolescentes com resposta incompleta à TARV devem ser avaliadas individualmente para determinar a causa da falha e seu subsequente tratamento. Em muitos casos, a falha terapêutica é multifatorial e não requer uma mudança imediata da TARV.  
Deve-se primeiramente fazer uma avaliação cuidadosa para entender a causa da falha e determinar a conduta mais adequada. Essa avaliação deve incluir a pesquisa criteriosa da adesão, intolerância, farmacocinética e resistência viral ( **Quadro 16** ).  
**Quadro 16:** Avaliação e intervenção das causas da falha virológica  
|**Possível causa da falha**|**Ação**|**Intervenção**|
|---|---|---|
|Adesão|Rever a administração e tomada<br>de medicamentos|Ajustar doses, se necessário.<br>Cl lbt d td|
|Farmacocinética e dose|Ajustar doses ao peso da criança<br>Avaliar interações<br>medicamentosas<br>Rever horários de tomada e<br>posologia|oocar emrees e omaa<br>Suspender ou trocar<br>medicamentos com interações<br>medicamentosas<br>Oferecer apoio ao cuidador|
|Resistência à TARV|Solicitar teste de genotipagem<br>após duas CV-HIV acima de<br>500 cópias/mL consecutivas<br>com 4 semanas de intervalo|Na ausência de mutações de<br>resistência, avaliar interações,<br>reforçar adesão e rever<br>administração dos<br>medicamentos<br>Caso sejam detectadas mutações<br>de resistência, ajustar<br>medicamentos, de acordo com<br>orientações do médico<br>referência emgenotipagem|  
Fonte: DATHI/SVSA/MS  
29  
Muitos fatores podem estar associados à falha virológica, mas o principal deles é a falha na adesão, com subsequente emergência de mutações virais que conferem resistência parcial ou total aos ARV em uso. Dessa forma, em toda falha, deve-se reforçar a adesão e solicitar o teste de genotipagem para avaliação de resistência.  
Quando as causas da falha terapêutica forem identificadas e avaliadas, deve-se determinar se há necessidade e possibilidade de troca do esquema, se há urgência nessa troca e qual a probabilidade de a CV-HIV se tornar indetectável.  
Crianças e adolescentes vivendo com HIV e com falha virológica devem ser atendidas prioritariamente nos serviços de assistência, como consultas e coleta de exames.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.6. Teste de genotipagem** -->
Uma vez detectada e confirmada a falha virológica, recomenda-se a pesquisa de resistência viral aos ARV, cujo resultado auxilia na elaboração de um esquema de resgate com maior chance de supressão viral. Dessa forma, indica-se o exame de genotipagem para HIV disponível no SUS na Rede Nacional de Genotipagem (Renageno).  
O teste de genotipagem tem os seguintes benefícios na prática clínica:  
- Possibilita escolha de esquemas ARV com maior chance de supressão viral, com base na identificação de mutações de resistência;  
- Propicia o uso de medicamentos ativos por períodos mais prolongados;  
- Previne trocas desnecessárias de ARV;  
- Evita a manutenção da toxicidade de medicamentos inativos;  
- Melhora a relação de custo-efetividade do tratamento;  
- Otimiza a escolha do esquema de resgate, reduzindo a chance de acúmulo progressivo de mutações e de ampla resistência aos ARV.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Critérios para solicitação do teste de genotipagem em crianças e adolescentes** -->
- Para iniciar TARV (pré-tratamento): indicado para TODAS as crianças e adolescentes;  
- Para avaliar TARV de resgate em falha virológica confirmada;  
-Após dois exames consecutivos, com intervalo de 4 semanas entre eles, de CV-HIV com resultado de carga viral detectável, sendo o último exame com carga viral > 500 cópias/mL.  
Nas situações de CV-HIV inferior a 500 cópias/mL, os testes de genotipagem do HIV não estão recomendados, pois a metodologia validada e disponível no SUS atualmente exige uma CV-HIV mínima de 500 cópias/mL.  
Recomenda-se que os testes de genotipagem sejam realizados o mais precocemente possível em relação ao diagnóstico da falha virológica. A CV-HIV persistente, mesmo baixa, leva a acúmulo de mutações e resistência cruzada nas classes dos medicamentos em uso.  
30

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Considerações para uso adequado do teste de genotipagem:** -->
- A adesão deve ser sempre avaliada antes da solicitação do teste;  
- CV-HIV superiores a 100.000 cópias/mL podem indicar falta de adesão ao tratamento;  
- Após seis meses da realização **,** o teste deve ser considerado desatualizado.  
Além da Genotipagem Convencional, que avalia mutações para Transcriptase Reversa e Inibidores de Protease, para determinadas situações, podem ser solicitadas:  
- Genotipagem de integrase:  
- indicada para pacientes em falha virológica atual ou pregressa com esquemas estruturados com raltegravir e dolutegravir;  
- RN com uso de INI pela mãe (reforça-se a necessidade de assinalar estes campos na solicitação de genotipagem do HIV quando a mãe tenha utilizado INI).  
- Teste de genotropismo: indicado quando o uso do maraviroque é considerado.  
**Monitoramento da eficácia do novo esquema de TARV (após troca)**  
A reavaliação da CV-HIV dentro de seis semanas da troca é fundamental e, se não houver resposta virológica ou queda de 1 log na CV-HIV, repete-se a CV-HIV. Se a CV-HIV estiver estabilizada e sem queda e boa adesão, considerar nova genotipagem.  
O **Quadro 17** elenca orientações sobre o exame de genotipagem do HIV.  
**Quadro 17.** Considerações para otimizar o uso da genotipagem do HIV  
|**Antes de solicitar**||
|---|---|
|O exame deve ser coletado na<br>vigência de TARV|Algumas mutações ficam arquivadas rapidamente após a interrupção<br>da TARV, devido à ausência da pressão seletiva exercida pelo<br>medicamento e acabam não aparecendo no exame realizado.|
|A CV-HIV deve estar detectável|Sem viremia não é possível amplificar o genoma viral.<br>No contexto de viremia muito baixa, mutações existentes podem não<br>ser detectadas.|
|**Solicitação**||
|Genotipagem convencional<br>_(ITRN, ITRNN e IP)_|Solicitar para toda falha virológica|
|Integrase<br>_(raltegravir, dolutegravir)_|Solicitar em caso de falha atual ou prévia a INI|
|Genotropismo (alça V3 GP120)<br>_(maraviroque)_|Solicitar na suspeita de resistência a 3 classes (ITRN, ITRNN e IP).<br>Realizada automaticamente se a genotipagem convencional detectar<br>resistência às 3 classes|
|GP41<br>_(enfuvirtida)_|Solicitar em falha sob uso de enfuvirtida (ENF/T20).<br>Na ausência da pressão seletiva (falha prévia a enfuvirtida) não é<br>recomendado, pois as mutações ficam arquivadas.|
|**Interpretação e elaboração do esq**|**uema de resgate**|
|Mutações detectadas|Provável redução da susceptibilidade, entretanto a classe de ITRN<br>retém atividade residual mesmo napresença de mutações.|
|Mutações não detectadas|Não significa necessariamente medicamento ativo. Na ausência de<br>pressão seletiva (suspensão do medicamento) ou em situações de<br>CV-HIV baixa, pode não ser possível detectar as subpopulações<br>virais minoritárias com mutações de resistência.|  
31  
|Considerar<br>o<br>histórico<br>de<br>esquemas ARV, falhas e de testes<br>de genotipagem|Mutações selecionadas no passado podem não ser detectáveis na<br>ausência do medicamento, contudo, reemergem rapidamente após<br>sua reintrodução. A resistência é cumulativa: as mutações detectadas<br>em diferentes testes de um mesmopaciente devem ser somadas.|
|---|---|
|Considerar os resultados como<br>“atuais” no máximo até 6 meses<br>após a coleta de amostra|Considerando-se o ritmo médio de acúmulo de novas mutações na<br>vigência de falha, após um período de 6 meses podem surgir novas<br>mutações e ocorrerperda adicional de opções de tratamento.|
|Estruturar o esquema de resgate a<br>partir da orientação de médico<br>referência<br>em<br>genotipagem,<br>capacitados<br>e<br>atualizados<br>periodicamente pelo Ministério da<br>Saúde|A interpretação do teste e a escolha do melhor esquema de resgate<br>são complexas e demandam experiência e atualização contínua no<br>manejo da falha virológica.|
|Fonte: DATHI/SVSA/MS||

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.7. Manejo da falha virológica** -->
A escolha de um novo esquema ARV depende de resultados de exames de genotipagem do HIV e da avaliação da adesão.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.7.1. Falha virológica na ausência de resistência identificada** -->
A falha virológica na ausência de resistência do HIV aos ARV em uso sugere falta de exposição do vírus aos medicamentos. Em geral, isso é resultado da falta de adesão ou abandono do tratamento. No entanto, é importante a exclusão de outros fatores, tais como: utilização de doses insuficientes, má absorção ou interações medicamentosas. Nesse caso, não está indicada a troca da TARV, e sim o reforço da adesão.  
O teste de genotipagem deve ser realizado em vigência da TARV, uma vez que os vírus selvagens substituem rapidamente os vírus mutantes no plasma, na ausência da pressão seletiva da TARV.  
Há situações em que uma criança ou adolescente apresenta CV-HIV detectável após o abandono do tratamento. Nesses casos, deve-se reintroduzir o esquema proposto no item _Reintrodução da TARV_ após abandono de tratamento, com ênfase na adesão e a realização de CV-HIV e genotipagem após quatro a seis semanas de uso contínuo.  
Na falência virológica de esquemas contendo IP/r, frequentemente não ocorrem mutações principais para os IP. A supressão virológica pode ser atingida mantendo o mesmo IP/r, com reforço da adesão.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.7.2. Falha virológica com resistência ao esquema atual** -->
Nessas situações, o objetivo é começar um novo esquema capaz de suprimir a replicação viral e prevenir a emergência de vírus com mutações adicionais de resistência. Para isso, torna-se necessária o uso de um esquema com pelo menos dois, mas preferencialmente três, medicamentos completamente ativos e de pelo menos duas classes diferentes.  
A escolha do novo esquema terapêutico baseia-se na contagem de LT-CD4+ e CV-HIV, genotipagem atual e prévia, histórico dos ARV utilizados, toxicidade, disponibilidade de novos ARV e na avaliação da possibilidade de adesão e aceitação desse esquema.  
32  
Devido à possibilidade de resistência cruzada entre alguns ARV de uma mesma classe, a utilização de um novo medicamento de uma classe já utilizada não garante que o mesmo seja plenamente ativo, em especial para os ITRNN.  
Os tratamentos com ARV interrompidos por questões de intolerância ou baixa adesão, em algumas situações, pode ser reintroduzidos. Isso é possível quando não há resistência e as questões quanto à tolerância e adesão foram resolvidas.  
O **Quadro 18** traz orientações sobre a escolha da TARV de resgate.  
**Quadro 18:** Orientações sobre escolha de esquema ARV de resgate  
- O objetivo é sempre alcançar CV-HIV indetectável.  
- Utilizar dois medicamentos plenamente ativos e de classes diferentes. Não devem ser considerados como medicamentos ativos lamivudina, nevirapina, efavirenz e raltegravir se já houve falha virológica prévia com o uso desses ARV, mesmo que sensíveis no teste de genotipagem.  
- A escolha deve ser guiada por genotipagem (análise dos testes anteriores e atuais) e história terapêutica (esquemas prévios e atuais).  
- Considerar nível de CV-HIV e contagem de LT-CD4+ para início de novo esquema e monitoramento da eficácia.  
- A escolha da nova dupla de ITRN é particularmente importante no esquema de resgate, pois o uso de um ITRN não totalmente ativo pode resultar na seleção de mutações adicionais de resistência, comprometendo o novo esquema.  
- Não usar ITRNN caso tenha ocorrido falha prévia a esquema contendo medicamento dessa classe, mesmo que em exames antigos. Nesse caso, recomenda-se um novo esquema com IP/r. A resistência à nevirapina geralmente resulta em resistência cruzada ao efavirenz e vice-versa. A etravirina pode ser exceção, mantendo-se sensível, se a genotipagem assim o demonstrar.  
- A utilização do raltegravir em situações de falha, também deve contraindicar seu uso pela possibilidade de ocorrer mutações que levem à resistência deste medicamento e do dolutegravir.  
- Considerar o efeito residual característico dos ITRN. Mesmo havendo resistência a lamivudina (pela emergência da mutação M184V), o uso desse medicamento pode contribuir para a redução do “ _fitness viral”_ (replicação viral) e supressão do HIV, sendo capaz de reverter parcialmente o efeito de algumas outras mutações (TAM – mutações para os análogos de timidina). Essa estratégia pode não ser útil se o esquema de resgate incluir abacavir ou zidovudina.  
- Se houver evidência de baixa adesão, o foco deve ser a superação das barreiras à boa adesão.  
- Para pacientes com indicação de troca de TARV devido à ocorrência ou progressão de quadro neurológico, o novo esquema deve incluir ARV que alcancem altas concentrações no sistema nervoso central.  
- Discutir com os médicos referência em genotipagem os casos de multifalha ou resistência ampla.  
A permeabilidade dos medicamentos ARV no Sistema Nervoso Central está descritas no **Quadro**  
**19** .  
33  
**Quadro 19:** Escala de permeabilidade dos antirretrovirais no Sistema Nervoso Central  
|**Baixa permeabilidade**|**Média permeabilidade**|**Alta permeabilidade**|
|---|---|---|
|Tenofovir (TDF)<br>Ritonavir (RTV)<br>Enfuvirtida (T-20)<br>Raltegravir (RAL)|Lamivudina (3TC)<br>Efavirenz (EFZ)<br>Atazanavir (ATV)|Abacavir (ABC)<br>Zidovudina (AZT)<br>Nevirapina (NVP)<br>Atazanavir + ritonavir (ATV + RTV)<br>Lopinavir/r (LPV/r)<br>Darunavir + ritonavir (DRV + RTV)<br>Dolutegravir (DTG)|  
Fonte: DATHI/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: <u>Primeira Falha com ITRNN</u> -->
A falha de um esquema inicial com **2 ITRN + 1 ITRNN** pode ser resgatada com o esquema **2 ITRN + 1 IP/r** . Os estudos que mostraram sucesso desse resgate utilizaram o lopinavir/ritonavir (LPV/r) como IP/r. Contudo, é provável que outros IP/r, como darunavir com reforço de ritonavir (DRV + RTV) e atazanavir com reforço de ritonavir (ATV + RTV), que são mais bem tolerados, tenham eficácia semelhante.  
Estudos com adultos mostram que esquemas de resgate contendo 2 ITRN+ dolutegavir foram não inferiores a esquemas com 2 ITRN + IP/r. O estudo DAWNING, que comparou o resgate da falha de um esquema inicial com 2 ITRN + 1 ITRNN para 2 ITRN + lopinavir/ritonavir versus 2 ITRN + dolutegravir, mostrou superioridade de eficácia e perfil de segurança do esquema do dolutegravir. Nesse estudo um dos ITRN era totalmente ativo<sup>94</sup> . O raltegravir, como menor barreira genética comparado ao dolutegravir, não deve ser utilizado em esquemas de resgate.  
Além disso, é fundamental que haja pelo menos um ITRN totalmente ativo. Deve-se avaliar cuidadosamente, pois crianças com falha ao esquema com 2 ITRN + 1 ITRNN habitualmente têm resistência substancial aos ITRN.  
Uma outra opção para o resgate de um esquema inicial com 2 ITRN + 1 ITRNN é o uso de esquema com 1 IP/r + 1 INI. Alguns estudos de adultos mostraram que um esquema com lopinavir/ritonavir + raltegravir é tão efetivo quanto o esquema com 2 ITRN + lopinavir/ritonavir. É provável que esquemas semelhantes contendo darunavir/ritonavir e dolutegravir tenham a mesma eficácia. O uso de atazanavir com reforço de ritonavir como IP/r não é recomendado. Este esquema deve ser utilizado apenas nas situações em que não há ITRN ativo, e o INI escolhido para estas situações deve ser o dolutegravir.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: <u>Primeira Falha com IP/r</u> -->
Na falha de um esquema inicial com **2 ITRN + 1 IP/r** , a maioria dos pacientes não tem resistência ou a resistência será apenas para o ITRN, geralmente para lamuvidina. A falência desse esquema pode ocorrer por má adesão, interação de medicamentos e alimentos. Todos esses fatores precisam ser revistos cuidadosamente.  
Dessa forma, se não houver resistência e houver possibilidade de boa adesão, o esquema pode ser mantido, com reavaliação precoce da CV-HIV. Se não houver boa tolerabilidade ao IP/r em uso, pode-se manter 2 ITRN + 1 IP/r, com troca do IP/r que for intolerante<sup>95</sup> .  
Se houver a possibilidade de alguma interação ou resistência na genotipagem para ITRN, o esquema deve ser modificado. Nesses casos, pode-se utilizar:  
34  
- 2 ITRN + 1 INI. Nesse caso, se houver apenas um ITRN ativo, o INI de escolha é o dolutegravir.  
- 1 IP/r + 1 INI. Esse esquema deve ser utilizado apenas nas situações em que não há ITRN ativo, e o INI escolhido para estas situações deve ser o dolutegravir.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: <u>Primeira Falha com INI</u> -->
A falha de um esquema com 2 ITRN + raltegravir pode ser associada com resistência aos ITRN e ao raltegravir. Esses vírus geralmente mantêm suscetibilidade ao dolutegravir<sup>96,97</sup> , que possui maior barreira genética do que o raltegravir. Entretanto, a depender de quais e quantas mutações para integrase existem, pode ocorrer resistência parcial ou total ao dolutegravir. Indivíduos com mutação à integrase e que mantenham o dolutegravir ativo, deverão recebê-lo a cada 12 horas.  
Ainda não existem estudos clínicos que avaliaram a primeira falha com esquema com INI. O resgate deve ser feito baseado no resultado da genotipagem:  
- Ausência de resistência aos ITRN e ao INI: se não houver problemas de adesão ou possíveis interações, o esquema pode ser mantido. Caso contrário, deve-se fazer a troca do(s) medicamento(s) não tolerado(s).  
- Ausência de resistência ao INI - o esquema pode ser modificado para:  
- 2 ITRN (com pelo menos um ativo) + 1 IP/r;  
- 1 IP/r + 1 INI. Esse esquema deve ser utilizado apenas nas situações em que não há ITRN ativo,  
- e o INI escolhido para estas situações deve ser o dolutegravir;  
- 2 ITRN (com pelo menos um ativo) + dolutegravir.  
- Resistência ao raltegravir e suscetibilidade ao dolutegravir - o esquema pode ser modificado para:  
- 2 ITRN (com pelo menos um ativo) + 1 IP/r  
- 2 ITRN (com pelo menos um ativo) + dolutegravir duas vezes ao dia  
- IP/r + dolutegravir duas vezes ao dia. Esse esquema deve ser utilizado apenas nas situações em  
- que não há ITRN ativo, e o INI escolhido para estas situações deve ser o dolutegravir.  
Vale ressaltar que a opção IP/r + INI tem menos evidências na literatura até o momento.  
O **Quadro 20** traz orientações para troca de TARV após confirmação de primeira falha.  
**Quadro 20:** Orientações para troca de TARV após confirmação de primeira falha (guiada por genotipagem).  
|**Falha inicial**|||**Opç**|**ões**|**de resgate**||
|---|---|---|---|---|---|---|
||**I**|**TRN**|||**3º**|**ARV**|
|2 ITRN + INI*|Conforme|faixa|etária|e|Dolutegravir||
|2 ITRN + 1 IRTNN**|<br>peso||||IP + RTV<br>etária)|(conforme faixa|
|2 ITRN +IP + RTV|Conforme<br>peso|faixa|etária|e|IP + RTV<br>etária)|(conforme faixa|
||||||Dolutegravir||  
Fonte: DATHI/SVSA/MS  
ITRN: inibidor da transcriptase reversa análogo de núcleos(t)ídeo; ITRNN: inibidor da transcriptase reversa não análogo de nucleosídeo; IP inibidor de protease  
35  
*Nas falhas com genotipagem demonstrando sensibilidade ao dolutegravir, usá-lo como primeira opção para o resgate.  
**Caso haja falha em uso de 2 ITRN + 1 ITRNN sem evidência de resistência, sugerindo má adesão, sugere-se escolha de outro esquema.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.8.1. Falha a partir do segundo Esquema** -->
Os ARV devem ser selecionados com base na probabilidade de serem ativos, de acordo com o histórico de TARV do paciente, genotipagens atuais e prévias, teste de tropismo, além dos convencionais e da integrase. Idealmente, o novo esquema deve incluir pelo menos duas, e preferencialmente, três medicamentos totalmente ativos.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.9. Viremia persistente com multirresistência aos antirretrovirais em pacientes com poucas opções terapêuticas** -->
Na impossibilidade de compor um esquema com dois ou mais medicamentos totalmente ativos, o foco volta a ser nem tanto a indetecção da CV-HIV, mas a manutenção da função imune, com prevenção da progressão da doença e do aparecimento de IO. Esquemas não supressivos podem diminuir o “ _fitness”_ viral, diminuindo a deterioração clínica e imunológica.  
Muitas vezes, a estratégia é utilizar um esquema não supressor como “esquema de espera”, até a disponibilidade de novos medicamentos ativos para composição do novo esquema. **Essa escolha não é a ideal, sendo apenas aceitável como estratégia de curto prazo, seguida de acompanhamento mais frequente, visando a iniciar um esquema ativo na primeira oportunidade.**  
Não se deve utilizar monoterapia com ITRN, nem suspender todos os ARV, pois essas abordagens estão associadas com piora imunológica mais rápida e desfecho clínico desfavorável.  
Além disso, quando houver resistência aos ITRNN, enfuvirtida, dolutegravir ou raltegravir, não há evidência de benefícios clínicos para manutenção desses ARV, além da seleção de novas mutações de resistência que causam resistência cruzada à classe, comprometendo possíveis esquemas futuros. Nesses casos, habitualmente deve-se manter 2 ITRN + 1 IP/r.  
A viremia persistente na presença da pressão seletiva do ARV pode gerar mutações adicionais de resistência, comprometendo ARV da mesma classe que possam ser utilizados em esquemas futuros. Esses pacientes devem ser acompanhados cuidadosamente.  
Em casos de piora clínica ou imunológica, pode ser necessário o uso de novos medicamentos em investigação para crianças, já aprovados para maiores de 16 anos, como um segundo medicamento ativo no novo esquema.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **8.10. Antirretrovirais de uso restrito para falha terapêutica** -->
A indicação de medicamentos de resgate está recomendada para pacientes que preencham TODOS os critérios.  
Os ARV de uso restrito (etravirina, maraviroque e enfuvirtida) são de uso exclusivo em situações de falha virológica e necessitam de avaliação da Câmara Técnica local, após preenchimento e envio de formulário específico com o laudo do teste de genotipagem recente.  
36  
Os critérios gerais de indicação de ARV de uso restrito estão descritos no **Quadro 21** :  
**Quadro 21:** Critérios gerais de indicação de ARV de uso restrito  
- Falha virológica confirmada.  
- Teste de genotipagem realizado há menos de 12 meses.  
- • Resistência a pelo menos um ARV de cada uma das três classes (ITRN, ITRNN<sup>(a)</sup> e IP).  
Fonte: DATHI/SVSA/MS  
(a) Ressalta-se que, mesmo não tendo sido detectadas mutações para ITRNN, caso tenha havido falha prévia com medicamento dessa classe, deve-se considerar que há resistência, no mínimo, para efavirenz e nevirapina.  
Os critérios gerais de indicação dos ARV de uso restrito estão descritos no **Quadro 22** :  
**Quadro 22:** Critérios de indicação e algumas características dos ARV de uso restrito  
**Etravirina (ETR):** é recomendada para situações em que mesmo com a utilização de darunavir/ritonavir e raltegravir, a chance de obtenção de supressão viral seja considerada baixa. Além disso, só poderá ser indicada, caso se demonstre sensibilidade plena (S) à etravirina e resistência documentada ou falha prévia aos outros ITRNN (efavirenz e nevirapina).  
Ressalta-se que a genotipagem pode subestimar a resistência à etravirina e que esse ARV apresenta interações medicamentosas frequentes, sendo considerado incompatível com o atazanavir/ritonavir, baseado em perfil mutacional em genotipagem do HIV. O uso de etravirina em associação ao dolutegravir deve ser acompanhado de algum dos seguintes IP/r: atazanavir/ritonavir, darunavir/ritonavir ou lopinavir/ritonavir. No Brasil, esse medicamento só está aprovado para maiores de 18 anos e, portanto, **seu uso não é recomendado em crianças e adolescentes** .  
**Maraviroque (MVQ):** é recomendado para situações em que, mesmo com a utilização de darunavir/ritonavir e INI, a chance de obtenção de supressão viral seja considerada baixa. Além disso, só poderá ser indicado, se houver teste de tropismo viral evidenciando presença exclusiva de vírus R5, realizado no máximo seis meses antes do início do novo esquema.  
**Enfuvirtida (T-20):** deve ser utilizado apenas em indivíduos sem outras opções que permitam estruturar esquemas potentes de resgate. Não deve ser usado caso apresente resistência a enfuvirtida, uma vez que não apresenta atividade residual. A prescrição deve ser cuidadosamente avaliada devido aos efeitos adversos, dificuldade de administração e baixa barreira genética.  
Fonte: DATHI/SVSA/MS  
O **Quadro 23** elenca as indicações de substituição de enfuvirtida por INI.  
**Quadro 23:** Critérios para substituição da enfuvirtida por inibidores de integrase  
Pacientes em uso de enfuvirtida há mais de quatro meses, com sucesso virológico (CV-HIV indetectável).  Pacientes virgens de inibidores de integrase ou aqueles com uso prévio dessa classe, com teste de resistência na integrase demonstrando sensibilidade.  <u>Última CV-HIV realizada no máximo há 60 dias.</u>  
Fonte: DATHI/SVSA/MS  
37

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **9. TRA** N **SIÇÃO DO CUIDADO DA PEDIATRIA PARA A ATENÇÃO DE ADULTOS** -->
Após quatro décadas da epidemia de HIV/aids, assistimos ao “envelhecimento” da população pediátrica infectada pelo HIV por transmissão vertical, decorrente dos avanços no diagnóstico, monitoramento e tratamento da doença. Essa mudança resultou em um contingente bastante significativo de adolescentes, jovens e adultos que vivem com HIV, somado a novos jovens infectados por transmissão horizontal, que mantém sua assistência pela equipe de saúde no transcorrer dos anos, trazendo consigo demandas específicas da faixa etária. A alteração do perfil dos pacientes pediátricos impôs aos serviços a necessidade de adequação e continuidade da assistência, por meio do processo de transição do cuidado da Pediatria para a Clínica de Adultos.  
O processo de transição é envolvido em muitos serviços por dificuldades presentes em todas as esferas: pacientes, familiares/cuidadores, serviços e profissionais da saúde, tanto da Pediatria quanto da equipe que receberá o caso. Muitas vezes pode haver resistência de uma ou várias partes envolvidas por não aceitarem a transição, interpretando como uma quebra de vínculo com a equipe de origem ou mesmo a negação em estabelecer uma vinculação com a que fará a continuidade do cuidado.  
Por conta da complexidade desse momento, é fundamental haver planejamento, organização e preparo, tanto institucional quanto profissional e pessoal. O paciente deve ter suas particularidades analisadas, incluindo sua capacidade de autocuidado e gerenciamento deste, maturidade psíquica e mesmo emocional, para que um plano individual de transição seja estabelecido. O olhar deve também estar focado na família, já que durante o seguimento pediátrico, em muitos momentos, ela é a protagonista do cuidado, sendo os pais/cuidadores, os atores principais das consultas. Muitas delas vivenciam o receio de “perda de controle” dos cuidados com a saúde de seus filhos, o que traz muita insegurança.  
Tantas particularidades tornam o processo de transição um momento de fragilidade do acompanhamento, com risco de dificuldades de adesão, possibilidade de instabilidade clínica, laboratorial ou mesmo abandono de seguimento, com progressão da doença e consequente aumento de mortalidade. Portanto, é alvo de muitos estudos para determinar diretrizes e orientações de condutas que devem ser adequadas a realidade de cada serviço<sup>98</sup> .  
A Sociedade Americana de Medicina do Adolescente define a transição como um movimento intencional, planejado, voltado para adolescentes e adultos jovens, tanto saudáveis como aqueles com doenças crônicas, incluindo os que vivem com HIV, de um centro de cuidado com foco na infância, onde o paciente é pouco participativo na sua assistência, para o sistema de saúde dos adultos, com total autonomia, garantindo a continuidade do cuidado. O processo deve ser ativo, atendendo às necessidades de saúde, psicossociais, educacionais e vocacionais dos pacientes<sup>98–100</sup> .  
É muito importante diferenciar os termos “transferência” e “transição”. Transferência seria a remoção de uma pessoa de um lugar ou serviço para outro, sendo considerada um simples evento. Em contrapartida, a transição é entendida como um processo de mudança de vida a ser vivenciado pelos pacientes, familiares/cuidadores e profissionais de saúde, com elaboração de estratégias que aumentem a possibilidade de sucesso. Portanto, transição no contexto da saúde significa um processo psicológico de adaptação a uma situação de mudança ou ruptura<sup>99,101</sup> .  
Alguns serviços possuem áreas dedicadas ao cuidado pediátrico e de adultos no mesmo espaço físico, o que facilita o processo, inclusive em função do paciente estar familiarizado com o local e seus procedimentos (como fluxo de admissão, pré-consulta, coleta de exames, retirada de medicamentos na farmácia, entre outros). Outros serviços são específicos para a pediatria, fazendo com que a transição do cuidado implique numa mudança de espaço físico e no aprendizado de todos os novos passos do atendimento, gerando maior insegurança e medo do desconhecido. É importante ressaltar que os diversos tipos de serviços que acompanham CVHA, com diferentes configurações, possuem desafios quanto ao processo e aos fluxos da transição.  
Orientações referentes a esses sob a ótica dos familiares/cuidadores, pacientes e serviços são descritas a seguir.  
38

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **9.1. O Momento da Transição** -->
O programa de transição nos serviços que atendem adolescentes e jovens com HIV/aids deve considerar as necessidades de cada integrante de forma individualizada<sup>102,103</sup> . O momento da transição difere para cada paciente e família e depende muito de fatores como a “prontidão” ou preparo dos adolescentes, assim como da sua dinâmica familiar, podendo ser mais complexo naqueles com condições de saúde menos favoráveis ou instáveis<sup>104,105</sup> . Apesar de alguns serviços basearem-se na idade cronológica para a realização da transição (18 a 20 anos) ou em marcos sociais paralelos, como a saída do ensino médio, estes não devem ser considerados como parâmetros definitivos<sup>106,107</sup> .  
A transição de adolescentes e jovens para os serviços de adultos deve ser um processo gradual, não determinado apenas pela idade, mas sim pelas particularidades de cada adolescente. Caso haja um impeditivo da continuidade do cuidado em função da idade, como ocorre em alguns serviços, esforços devem ser feitos para que o processo nesse local siga as etapas necessárias para garantir, na medida do possível, a prontidão de todos os envolvidos (adolescentes, familiares e equipe dos serviços pediátricos e de adultos) até o momento da mudança.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **9.2. Transição para a família/cuidadores** -->
Familiares ou Cuidadores que acompanham jovens que nasceram com uma condição de saúde crônica criam vínculo de confiança com a equipe da Pediatria. Assim, a Transição do Cuidado pode trazer sentimento de insegurança e até mesmo resistência. Faz-se necessário que família e cuidadores sejam incluídos no processo, colaborando como agentes facilitadores. O ponto mais importante a ser trabalhado é o crescimento da criança e a passagem dela pelas fases de pré-adolescência e adolescência como um caminho natural que culmina na vida adulta. Em cada mudança de fase vivencia-se pequenos lutos e a maneira como lidamos com eles nos prepara para a vida adulta. A confiança que a equipe de pediatria demonstra no processo da transição é transmitida para o jovem e sua família/cuidadores.  
Sentimento de culpa, preocupações, ansiedade, medo de complicações ou de morte, assim como atitudes superprotetoras são muito comuns em famílias de crianças e adolescentes que vivem com HIV, exercendo impacto negativo sobre o desenvolvimento dos filhos. Isso pode desencadear comportamentos de regressão com maior insegurança e dependência, dificultando a construção da autonomia. Devem ser aspectos sempre trabalhados com a família/cuidadores pela equipe multiprofissional, desde a infância, podendo quando bem resolvidos, facilitar o processo de transição<sup>100</sup> .  
É importante que familiares e cuidadores saibam que não há uma completa ruptura nas relações, mas sim uma mudança durante a transição. O cuidado não será mais dispensado pela equipe de Pediatria, passando a ser responsabilidade do serviço de adultos, mas as relações persistem e é saudável que os vínculos se mantenham.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **9.3. Transição para o adolescente ou jovem** -->
Periodicamente a equipe de saúde que assiste ao adolescente ou jovem deve avaliar o seu preparo para transição e sua autonomia em prover os principais cuidados, assim como a possibilidade de migrar para o ambulatório dos adultos em comum acordo entre as equipes, familiares, cuidadores e pacientes<sup>100</sup> .  
O **Quadro 24** lista os pré-requisitos básicos para a Transição, assim como outros critérios importantes<sup>98,100</sup>  
39  
**Quadro 24** : Pré-requisitos e critérios importantes para transição do adolescente/jovem para o serviço de adultos.  
|**Pré-requisitos básicos para a transição**|**Outros critérios importantes**|
|---|---|
|Revelação diagnóstica completa|Consegue identificar sinais ou sintomas e<br>descrevê-los à equipe de saúde|
|Possui conhecimento e capacidade de informar<br>sobre sua situação de saúde, medicamentos<br>(preferencialmente conhecendo nomes e doses dos<br>medicamentos em uso)e exames|Sabe diferenciar quando procurar o serviço médico<br>de rotina ou emergencial<br>|
|Possui consciência das implicações a curto e longo<br>prazo da condição de viver com HIV|É capaz de marcar suas próprias consultas e<br>reagendá-lasquando necessário|
|Possui compreensão das implicações da sua<br>condição<br>da<br>saúde<br>sexual<br>e<br>reprodutiva,<br>considerando-se<br>aspectos<br>como<br>intransmissibilidade de pacientes indetectáveis,<br>possibilidade de prevenção de transmissão vertical<br>em caso de maternidade/paternidade, entre outros<br>aspectos|Comparece sozinho às consultas no horário<br>marcado|
|Demonstra senso de responsabilidade sobre sua<br>própria<br>condição<br>de<br>saúde,<br>assim<br>como|Solicita prescrições corretamente e antes do<br>término dos medicamentos|
|independência para participar junto à equipe de<br>saúde, da condução de sua saúde|Tem conhecimentos mínimos sobre o HIV e a aids<br>e estratégias deprevenção|
||Compreende a importância de uma boa adesão em<br>todas as suas dimensões, bem como dos riscos<br>relacionados à má adesão|
||Tem conhecimento sobre a vivência da sua<br>sexualidade com segurança|
||Tem planos de estudo e trabalho futuros, assim<br>comoprojetos de vida|
||Tem apoio financeiro de familiares, cuidadores ou<br>terceiros|  
Fonte: DATHI/SVSA/MS.  
Seria importante garantir, no momento de finalizar a passagem da Pediatria para o serviço de adultos, que o adolescente/jovem estivesse em situação estável com relação a seu tratamento. Contudo, na prática isso nem sempre ocorre<sup>108</sup> . Estar em uso regular de terapia antirretroviral, em boas condições imunológicas e com CV-HIV suprimida seriam condições ideais para reduzir os riscos de desfechos desfavoráveis do processo de Transição do Cuidado. Porém, estas condições são multifatoriais e de difícil controle, reforçando que cada caso deve ser avaliado individualmente com relação à sua prontidão para progredir no processo.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **9.4. Como deve ser feita a transição?** -->
Não há modelo único para o estabelecimento de um programa de transição, sendo esse um tema discutido em diversas especialidades, tanto no cuidado dos adolescentes e jovens saudáveis, visando à prevenção de várias doenças, quanto entre aqueles que cuidam de doenças crônicas<sup>109,110</sup> .  
Respeitando-se as características de cada serviço e seguindo recomendações das Sociedade Brasileira de Pediatria e Academia Americana de Pediatria, para ser efetivo, o programa de transição deve ser estruturado conforme preceitos básicos<sup>98,100</sup> :  
– ter a presença de um ou mais profissionais de saúde treinados para organizar, coordenar e gerenciar a transição de cada paciente, sendo preferencialmente, um da equipe pediátrica e um do ambulatório de adultos;  
40  
– o serviço e o profissional de saúde devem identificar os conhecimentos, características e as necessidades do paciente para a transição e promover aprendizado;  
– preparar e manter um resumo organizado de seu histórico clínico e laboratorial;  
– estruturar um plano de transição com os pais/profissionais de saúde, iniciando este precocemente;  
– garantir que os pacientes continuem a receber os mesmos cuidados primários que os adolescentes e jovens da população em geral;  
– os serviços devem ter flexibilidade e foco voltado para as necessidades dos jovens;  
– as equipes envolvidas devem discutir políticas específicas para a transição, com avaliações sistemáticas sobre as condutas e flexibilidade para mudanças;  
– os jovens não devem mudar de serviço enquanto não apresentarem condições de frequentarem o serviço de adultos e tenham passado da fase de crescimento e puberdade;  
– é necessária boa comunicação e integração entre os serviços envolvidos;  
–antes do encaminhamento definitivo do paciente, é necessário o contato prévio com a equipe que vai recebê-lo;  
– é recomendável ao serviço pediátrico manter uma ficha de avaliação da prontidão para a transição de cada adolescente, levando em consideração aspectos como: vivência da sexualidade, situação escolar e empregatícia, capacidade de autocuidado, adesão ao tratamento e acompanhamento, suporte familiar, inclusão em redes de apoio social, como a Rede Nacional de Jovens Vivendo com HIV/Aids. Essa ficha deve ser encaminhada ao serviço de adultos, assim como o resumo dos dados clínicos e laboratoriais desde o início do seguimento;  
– considerar que o planejamento da transição deve ser visto como um componente essencial de avaliação para a qualidade dos serviços de saúde na adolescência.  
O modelo da transição deve ser adaptado às condições de cada local, equipes e serviços envolvidos no processo. No entanto, de maneira geral, é possível pensar em alguns passos que deveriam ser alcançados com o processo do crescimento ( **Figura 1** ):  
<!-- Start of picture text -->
$$. SU) 15 aos '24 shoe \ ) Apos 25 anos »<br>2a0s 14 anos<br>———eEE Transferéncia progressiva do<br>cuidado para o paciente<br>Revelaco diagnéstica para<br>terceiros Finalizacao do processo de<br>Participacdo em grupos de apoio transic&o e do autocuidado<br>Cuidado e adesdo sob e pares ‘Ampliagio das possibilidades de<br>responsabilidadefamiliar/cuidadordo Conhecimentos sobre o HIV, ‘gruposmatemidade,de suporte:paternidade,adesdo,<br>aids, tratamento, sexualidade ‘grupos focais<br>Processo de revelacao prevencao<br>diagndstica Manutenc&o de redes de apoio<br>Suporte psicolégico usando ‘cuidadosPromover comdiscusséesa sade sobremental, discusses,por meio decompartilhando grupose<br>arte e jogos estigma, discriminacdo, sucessos pessoals,<br>higiene,Autocuidadonutricfiocom e puberdadefoco em | | Estabelecimentopreconceito dos proprios | | outroseventosoportunid (desderel a  quedescionados de haja interesse tr a balho,o HIV e<br>objetivos e planos de tratamento ‘do paciente).<br>e de vida (educacional<br>profissional, etc)<br>Preparacdo para o transic3o do<br>cuidado<br><!-- End of picture text -->  
**Figura 1** : Etapas a serem alcançadas durante o processo de crescimento do paciente Fonte: Adaptado de _Adolescent and Youth Transition of Care Toolkit_ SUPPORTED BY THE NEW HORIZONS COLLABORATIVE.<sup>109,111</sup>  
41

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **9.5. Possíveis barreiras no processo de transição** -->
Algumas situações são identificadas como possíveis entraves a uma transição bem sucedida<sup>112,113</sup> .  
- Transferência abrupta, com pouco ou nenhum preparo, incluindo a falta de trabalho de autonomia do adolescente/jovem;  
- Falta de planejamento da transição;  
- Resistência dos adolescentes, familiares/cuidadores ou da própria equipe pediátrica;  
- Demora na marcação de consultas nos serviços de adultos, após a mudança do serviço pediátrico;  
- Serviços de adultos ou profissionais com pouco preparo para receber jovens com condições crônicas que tiveram início na infância;  
- Diferenças de abordagens no atendimento entre os serviços pediátricos (que geralmente oferecem maior suporte e inclusão da família/cuidadores) e os serviços de adultos (maior expectativa de independência do indivíduo);  
- Horários rígidos de atendimento;  
- Falta de comunicação entre os serviços pediátricos e de adultos;  
- Falta de trabalho em equipe multiprofissional conduzindo o processo de transição;  
- Falta de apoio institucional.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **9.6. Orientações Práticas para a Transição:** -->
Uma transição bem sucedida depende muito da boa vinculação da equipe de saúde com o paciente e família/cuidador. Para que todas as partes envolvidas compreendam melhor o processo, é fundamental lembrar da transitoriedade própria da fase da adolescência.  
Todo o processo deve ser sempre registrado em prontuário, ressaltando-se as necessidades de cada  
caso.  
A estratégia, independente do modelo utilizado, deve introduzir ao adolescente/jovem, gradativamente, a ideia de que será cuidado por uma nova equipe, em um novo ambiente e durante esse período será avaliado seu amadurecimento para assumir responsabilidades e visualizar a importância de um novo papel em seu próprio cuidado<sup>98</sup> .  
Durante o processo de transição, a depender da estrutura de cada serviço, o adolescente/jovem poderá ser atendido pelo profissional da nova equipe em um mesmo ambiente físico (na Pediatria e Ambulatório de Adultos), ou em ambientes distintos, estando ou não acompanhado durante o atendimento, de um profissional da equipe da Pediatria na fase inicial da transição. Alguns locais não possuem ambos os ambulatórios de Pediatria e Adultos, de modo que o paciente necessita, nesse momento de transição de mudança total de serviço, ser encaminhado para um novo local de atendimento. Mesmo nesses casos orienta-se que as equipes dos diferentes serviços trabalhem em conjunto na transição do paciente. Quando o serviço possui ambulatório específico de adolescentes, é possível que o processo de transição também seja desenvolvido neste espaço.  
Estabelecer, por um período, consultas intercaladas entre os médicos de adultos e da pediatria ou clínica de adolescentes, é uma estratégia possível durante o processo.  
42  
O processo de transferência de equipes pode ter duração variável, não havendo um tempo fixo que seja válido para todos os casos. Esse aspecto também deve ser individualizado.  
O acompanhamento da CVHA preconiza intervalo de consultas mensais ou bimestrais, a depender da idade e das características clínicas, imunológicas e virológicas do paciente. O intervalo médio entre consultas nos serviços de adultos costuma ser maior, variando de três a seis meses para pacientes estáveis clinicamente e com CV-HIV indetectáveis. Recomenda-se, no preparo para a transição, iniciar ainda durante o acompanhamento na Pediatria, o aumento do intervalo entre as consultas, a depender das condições de cada paciente.  
Outro aspecto que diferencia o seguimento nos serviços, diz respeito a entrar no consultório com acompanhante, como ocorre na Pediatria, ou sozinho, como costumam transcorrer as consultas no ambulatório de adultos. Sugere-se que essa mudança também seja paulatina, intercalando-se consultas com e sem acompanhante, o que também possibilita ao pediatra a avaliação mais detalhada do grau de independência e autocuidado do jovem. Pode-se, inclusive, estabelecer que as consultas do jovem na Pediatria sejam sem acompanhante a partir de um determinado momento do seguimento, antes da mudança de serviços, deixando-o familiarizado com o novo modelo após a Transição.  
**A última consulta do jovem no Serviço de Pediatria deve ser realizada, preferencialmente, quando já houver um agendamento de consulta no Serviço de Adultos garantida, para evitar que o paciente fique à deriva com um relatório médico em punho e sem destino certo** . Neste processo, a comunicação entre os Serviços Sociais de ambos os serviços pode ser crucial, inclusive com um acompanhamento pós-consulta para certificar-se de que o jovem compareceu ao agendamento e como foi essa experiência.  
Recomenda-se que, após a transferência de equipes, seja realizada uma consulta na Pediatria para avaliação do andamento do processo ou essa possibilidade seja disponibilizada claramente ao adolescente/jovem, caso haja necessidade ou interesse deste, para fechamento do seguimento na Pediatria e finalização do processo de Transição.  
A fase pós-transição é considerada um momento de maior vulnerabilidade para falhas de adesão (em todas as suas dimensões), com risco de perda ou abandono de seguimento em alguns casos. A manutenção da interação entre as equipes é fundamental, podendo ser realizado um monitoramento ou supervisão dos casos através de contatos telefônicos com os jovens ou, idealmente, reuniões entre as equipes com discussão dos casos, possibilitando intervenções individualizadas junto aos pacientes que apresentem dificuldades no processo<sup>1</sup> .  
Algumas referências internacionais citam a possibilidade do uso de um “Pacote de Transição para Adolescentes”, que basicamente trata-se de um _kit_ contendo guias, livros e materiais didáticos que discorrem sobre a revelação diagnóstica e a transição, além de um questionário de avaliação de prontidão que seria aplicado nos pacientes analisando-se conhecimentos sobre HIV, autogestão, comunicação entre outros aspectos. A partir da aplicação do questionário, o adolescente/jovem seria classificado em um escore de pontuação que permitiria avaliar se ele pode já ser submetido à transição ou se esta deve ser adiada<sup>114,115</sup> . Até o momento não há questionário de avaliação de prontidão validado em território nacional.  
As organizações não governamentais ou grupos de apoio de jovens que vivem com HIV podem colaborar com as equipes no processo de transição, devendo-se sempre incentivar a inserção e participação dos pacientes em tais grupos.  
A transição de adolescentes/jovens dos cuidados pediátricos para os serviços de adultos é um processo que requer flexibilidade, trabalho multiprofissional e muita interação entre os serviços. É importante que o planejamento prévio seja realizado de forma cuidadosa entre as equipes, em conjunto com o paciente e seus familiares/cuidadores, objetivando a manutenção do cuidado integral e garantindo adesão adequada e boa qualidade de vida nessa nova fase.  
43

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **10. PREVENÇÃO COMBINADA DO HIV/IST** -->
A política brasileira de enfrentamento ao HIV/aids reconhece que nenhuma intervenção de prevenção isolada é suficiente para reduzir novas infecções, e que diferentes fatores de risco de exposição, transmissão e infecção operam, de forma dinâmica, em diferentes condições sociais, econômicas, culturais e políticas.  
Devem-se ofertar às pessoas que procuram os serviços de saúde estratégias abrangentes de prevenção, a fim de garantir a maior diversidade de opções que orientem sua decisão. A pessoa deve escolher o(s) método(s) que melhor se adeque(m) às condições e circunstâncias de sua vida, tendo como princípios norteadores a garantia dos direitos humanos e do respeito à autonomia do indivíduo.  
O termo “Prevenção Combinada do HIV” remete à ideia de conjugação de diferentes ações de prevenção, tanto em relação ao HIV quanto aos fatores associados à infecção. Assim, sua definição parte do pressuposto de que diferentes intervenções devam ser conciliadas em uma estratégia conjunta, mediante a combinação das três intervenções possíveis na formulação de estratégias de prevenção ao HIV: a biomédica, a comportamental e a estrutural. A conjugação dessas diferentes abordagens não encerra, contudo, todos os significados e possibilidades do termo “Prevenção Combinada”.  
Essa combinação de ações deve ser centrada nos indivíduos, em seus grupos sociais e na sociedade em que estão inseridos. A premissa básica estabelecida é a de que estratégias de prevenção abrangentes devem observar, de forma concomitante, esses diferentes focos, levando sempre em consideração as especificidades dos sujeitos e dos seus contextos.  
A Prevenção Combinada é um conjunto de estratégias de prevenção ao HIV que incluem intervenções biomédicas, comportamentais e estruturais, aplicando-as no nível dos indivíduos e de suas relações, dos grupos sociais a que pertencem ou na sociedade em que estão inseridos, mediante ações que levem em consideração as necessidades e especificidades desses indivíduos e as variadas formas de transmissão do vírus.  
As intervenções biomédicas são aquelas que enfocam a redução do risco à exposição dos indivíduos ao HIV, a partir de estratégias que impeçam sua transmissão pela interação entre uma ou mais pessoas que tenham o vírus e outras pessoas que não o tenham. Por sua vez, as intervenções comportamentais são aquelas cujo foco está no comportamento dos indivíduos, buscando formas de reduzir situações de risco. O objetivo dessas intervenções é oferecer um conjunto amplo de informações e conhecimentos que contemplem várias abordagens de prevenção, para que os indivíduos possam melhorar sua capacidade de gerir os diferentes graus de riscos a que estão expostos. Por fim, as intervenções estruturais são aquelas voltadas a abordar os aspectos e características sociais, culturais, políticas e econômicas que criam ou potencializam vulnerabilidades dos indivíduos ou segmentos sociais em relação ao HIV.  
O símbolo da mandala (Figura 2) representa a combinação de algumas das diferentes estratégias de prevenção (biomédicas, comportamentais e estruturais), pois confere a ideia de movimento em relação às possibilidades de prevenção, tendo as intervenções estruturais (marcos legais) como base dessa conjugação.  
44  
<!-- Start of picture text -->
SS ott<br>& eetwnWw Peg Many<br>$eff, ostt™® Pap Io 4% 4<br>osePAN epHAVE & an,<br>! oe % Se<br>& *%,<br>3 :<br>£338c.3 BEM Prevencho VE aoe== F<br>€2ht, GE comanaon Jay 23<br>gabe Fe<br>Bese &gs<br>Bg" 5 &<br>% @<br>oe, FS<br>Pea get Oe<br>Rn ee<br>4m Redusio oe<br>><br>Seo<br><!-- End of picture text -->  
**Figura 2:** Mandala de Prevenção Combinada do HIV  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **10.1. Prevenção em crianças e adolescentes** -->
O Estatuto da Criança e do Adolescente (ECA) considera criança a pessoa até 12 anos de idade incompletos e adolescente aquela entre 12 e 18 anos de idade. A transmissão vertical é a principal forma de transmissão em crianças. Os adolescentes, à medida que se tornam sexualmente ativos, podem adquirir o HIV por meio de suas práticas.  
Os(as) adolescentes podem ter acesso a várias estratégias de prevenção, incluindo serviços pediátricos e pré-natais, bem como serviços que também atendem adultos, uma vez que existem poucos serviços de saúde específicos para adolescentes e essa população demanda um trabalho singular em relação à informação, autonomia e acesso à prevenção e cuidados em saúde.  
Em geral, nesse cenário, as recomendações de estratégias de prevenção para adultos se aplicam a adolescentes. Contudo, é importante reconhecer que adolescentes necessitam de orientações específicas sobre prevenção das IST, testagem e aconselhamento. Além disso, os cuidados em saúde para adolescentes vivendo com HIV devem considerar as especificidades dessa etapa do curso da vida.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **10.2. Profilaxias Pós-Exposição (PEP) e Pré-Exposição (PrEP) de risco à infecção pelo HIV** -->
As Profilaxias Pós-Exposição (PEP) e Pré-Exposição (PrEP) de risco à infecção pelo HIV se inserem no conjunto de estratégias de Prevenção Combinada, cujo principal objetivo é ampliar as formas de intervenção para evitar novas infecções pelo HIV.  
45

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **10.2.1. Profilaxia Pós-Exposição (PEP)** -->
A PEP consiste no uso profilático de ARV para evitar o risco de infecção pelo HIV. Deve ser iniciada em até 72 horas após a exposição de risco, sendo indicada por 28 dias.  
No âmbito da Prevenção Combinada, reforça-se a indicação da PEP para além das situações indicadas, como violência sexual e acidente com material perfurocortante, com vistas a ampliar o uso dessa intervenção a todas as exposições que representem risco de infecção pelo HIV.  
Em situações de exposição ao HIV, deve-se considerar potenciais exposições a outros agentes infecciosos, como patógenos de transmissão sexual e sanguínea (vírus das hepatites B e C) e de transmissão sexual ( _Treponema pallidum, Neisseria gonorrhoeae, Chlamydiatrachomatis_ ), além do risco de gravidez indesejada.  
O abuso sexual deve ser observado em crianças e adolescentes, que possuem um risco em particular devido à possibilidade de exposições múltiplas, ectopia cervical e trauma de mucosa vaginal e anal, considerando-se a menor espessura do epitélio vaginal nas crianças.  
A incidência de infecção pelo HIV teve aumento significativo nos adolescentes e jovens acima de 15 anos, que são sexualmente ativos, mas possuem uma percepção muito baixa do risco de infecção, podendo apresentar uso irregular de proteção durante suas práticas sexuais.  
Assim, orientações sobre transmissibilidade do vírus, práticas de sexo seguro, parcerias sorodiferentes e PEP são muito importantes e devem ser abordadas em toda consulta, conforme a maturidade e compreensão de cada criança e adolescente. Para mais informações sobre conduta no manejo e prescrição da PEP, acessar o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição (PEP) de risco à infecção pelo HIV, IST e Hepatites virais”<sup>116</sup> , disponível em https://www.gov.br/aids/pt- <u>br/centrais-de-conteudo/pcdts</u>  
Com a incorporação do dolutegravir 5 mg comprimidos dispersíveis ao Sistema Único de Saúde, as atuais recomendações de esquemas ARV profiláticos preferenciais e alternativas, por faixas etárias, são descritas no **Quadro 25** .  
**Quadro 25.** Esquemas preferenciais e alternativos para PEP-HIV  
|**Faixa Etária**|**Esquemaprefere**|**ncial**||**Medicamentos al**|**ternati**|**vos**||
|---|---|---|---|---|---|---|---|
|0 a 14 dias|Zidovudina<br>+<br>raltegravir|lamivudina|+|Zidovudina<br>+<br>nevirapina.|lami|vudina|+|
|14 dias a 4 semanas de<br>vida|Zidovudina<br>+<br>raltegravir|lamivudina|+|Impossibilidade<br>raltegravir: lopina|do<br>vir/rito|uso<br>navir.|de|
|||||Impossibilidade|do|uso|de|
|Acima de 4 semanas de<br>vida até 6 anos|Zidovudina<br>+<br>dolutegravir 5 mg|lamivudina<br>*|+|dolutegravir:<br>lopinavir/ritonavir<br>ou<br>darunavir****/rito|<br>navir|||
|6 a 12 anos|Zidovudina+<br>dolutegravir 50 m<br>ou<br>Tenofovir**<br>+<br>dolutegravir 50 m|lamivudin<br>g***<br>lamivudina<br>g***|a+<br>+|Impossibilidade<br>dolutegravir:<br>darunavir/ritonavir<br>lopinavir/ritonavir|do<br>ou<br>.|uso|de|
|12 anos ou mais|Tenofovir**<br>+<br>dolutegravir 50 m<br>ou|lamivudina<br>g***|+|Impossibilidade<br>dolutegravir:<br>darunavir/ritonavir|do<br>|uso|de|  
46  
|**Faixa Etária**|**Esquemapreferencial**|**Medicamentos alternativos**|
|---|---|---|
||Zidovudina+<br>lamivudina+||
||dolutegravir 50 mg***||  
Fonte: DATHI/SVSA/MS  
*Peso ≥ 3 kg; ** Peso ≥ 35 kg; *** Peso > 20 kg Observações:  
-Dolutegravir 5 mg comprimido dispersível a partir do 2º mês de vida e peso igual ou superior a 3  
kg.  
- Dolutegravir 50 mg comprimido a partir de 6 anos ou 20 kg.  
-Darunavir para crianças maiores de 3 anos e com peso igual ou superior a 15 kg, que consigam deglutir o comprimido.  
-Tenofovir em crianças com peso peso igual ou superior a 35 kg

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **10.2.2. Profilaxia pré-exposição ao HIV (PrEP)** -->
A PrEP consiste no uso profilático de ARV em indivíduos sob alto risco de infectar-se pelo HIV (com status sorológico negativo evidenciado) e faz parte das estratégias de prevenção combinada do HIV e demais IST.  
As pessoas sob maior risco de infecção devem ser o grupo prioritário para uso dessa estratégia de prevenção, incluindo gays e homens que fazem sexo com outros homens (HSH), pessoas transexuais, trabalhadores do sexo e parcerias sorodiferentes.  
O simples pertencimento a um dos segmentos populacionais-chave – HSH cisgêneros, pessoas transexuais, trabalhadores(as) do sexo e parcerias sorodiferentes – não é suficiente para caracterizar indivíduos com exposição frequente ao HIV. Para essa definição, é necessário observar as práticas e parcerias sexuais da pessoa, a sua dinâmica social e os contextos específicos associados a um maior risco de infecção. Portanto, devem também ser considerados outros critérios indicativos, tais como:  
- Repetição de práticas sexuais anais ou vaginais com penetração sem o uso de preservativo;  
- Frequência de relações sexuais com parcerias eventuais;  
- Quantidade e diversidade de parcerias sexuais;  
- Histórico de episódios de IST;  
- Busca repetida por PEP;  
- Contextos de relações sexuais em troca de dinheiro, objetos de valor, drogas, moradia etc.;  
- Chemsex: prática sexual sob a influência de drogas psicoativas (metanfetaminas, gamahidroxibutirato – GHB, MDMA, cocaína, _poppers_ ) com a finalidade de melhorar ou facilitar as experiências sexuais.  
O SUS oferta **PrEP, a qual** deve ser considerada para pessoas **a partir de 15 anos** , com peso igual ou superior a 35 kg, sexualmente ativas e com risco aumentado de serem expostas ao HIV em relação à população geral. Alguns segmentos populacionais são prioritários para avaliação de PrEP, por apresentarem prevalência maior de infecção pelo HIV, como os já descritos.  
Em relação ao **atendimento de adolescentes,** ressalta-se que há ampla legislação e recomendações técnicas no sentido de garantir os direitos dos adolescentes (de 10 a 18 anos) nos serviços de saúde, como elemento indispensável para a melhoria da qualidade da prevenção, assistência e promoção de sua saúde. Dessa forma, qualquer exigência que possa afastar ou impedir o exercício pleno do adolescente de seu  
47  
direito fundamental à saúde e à liberdade constitui lesão ao direito maior de uma vida saudável. Assim, reforça-se que adolescentes podem ser atendidos sozinhos, inclusive, para solicitação de procedimentos como imunizações; segundo disposto<sup>117</sup> , da Coordenação de Saúde de Adolescentes e Jovens do Ministério da Saúde.  
Em relação à indicação de **PrEP,** divulgada em Nota Técnica nº 498/2022CGAHV/DCCI/SVS/MS<sup>118</sup> na qual se apresentam os subsídios legais e normativas para acesso e indicação da PrEP para adolescentes maiores de 15 anos, sem a necessidade de presença de responsáveis; destacamse:  
a) a indicação deve ser considerada a partir de 15 anos, em pessoas com peso igual ou maior a 35 kg, com vida sexual ativa e sob risco potencial de exposição à infecção pelo HIV;  
b) quando identificados os critérios clínicos e laboratoriais para indicação de PrEP, a recomendação de associação de antirretrovirais é a mesma de adultos:  
- dose de ataque de 2 (dois) comprimidos de tenofovir (300 mg) e entricitabina (200 mg), no primeiro dia de uso, seguida de 1 (um) comprimido diário nos dias subsequentes, esquema este denominado “PrEP oral diária” ou “PrEP contínua”;  
- dose diária de um comprimido da associação de tenofovir (300 mg) e entricitabina (200 mg).  
Recomenda-se que os serviços de saúde do SUS garantam o acolhimento e atendimento para análise de indicação de PrEP a adolescentes com os critérios acima mencionados, com direito à privacidade e ao sigilo, e sem a presença ou autorização de responsáveis, mães ou pais dos mesmos.  
As recomendações para o uso de PrEP podem ser acessadas no “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV”, disponível em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts; https://www.gov.br/aids/pt-br/centrais-deconteudo/pcdts/2017/hiv-aids/pcdt-prep-versao-eletronica-22_09_2022.pdf/view</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **11. REFERÊNCIAS** -->
1. Saúde M DA. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Ações Programáticas Estratégicas. Política Nacional de Atenção Integral à Saúde da Criança : orientações para implementação / Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Ações Programáticas Estratégicas. – Brasília : Ministério da Saúde, 2018. Accessed November 30, 2023. https://portaldeboaspraticas.iff.fiocruz.br/wp-content/uploads/2018/07/Pol%C3%ADtica-Nacional-deAten%C3%A7%C3%A3o-Integral-%C3%A0-Sa%C3%BAde-da-Crian%C3%A7a-PNAISCVers%C3%A3o-Eletr%C3%B4nica.pdf  
2. United Nations. OBJETIVOS DE DESENVOLVIMENTO SUSTENTÁVEL (ODS). Published 2014. Accessed August 22, 2023. https://www.pactoglobal.org.br/ods#:~:text=Os%20ODS%20buscam%20assegurar%20os,maiores%20de safios%20de%20nossos%20tempos.  
3. PEDIATRICS AAO. Disclosure of Illness Status to Children and Adolescents With HIV Infection. _Pediatrics_ . 1999;103(1):164-166. doi:10.1542/peds.103.1.164  
4. Ateka GK. HIV status disclosure and partner discordance: A public health dilemma. _Public Health_ . 2006;120(6):493-496. doi:10.1016/j.puhe.2006.01.010  
5. Ministério da Saúde do Brasil. Marco legal: saúde, um direito de adolescentes. 2007;1.  
6. Galano E, De Marco MA, Succi RC de M, Silva MH da, Machado DM. Entrevista com os familiares: um instrumento fundamental no planejamento da revelação diagnóstica do HIV/Aids para  
48  
crianças e adolescentes. _Cien Saude Colet_ . 2012;17(10):2739-2748. doi:10.1590/S141381232012001000022  
7. Hosek SG, Harper GW, Domanico R. Psychological and Social Difficulties of Adolescents Living With HIV: A Qualitative Analysis. _J Sex Educ Ther_ . 2000;25(4):269-276. doi:10.1080/01614576.2000.11074360  
8. Isaac Kadowa FN. Factors influencing disclosure of HIV positive status in Mityana district of Uganda. _Afr Health Sci_ . 2009;1(9):26-33.  
9. Marques HH de S, Silva NG da, Gutierrez PL, et al. A revelação do diagnóstico na perspectiva dos adolescentes vivendo com HIV/AIDS e seus pais e cuidadores. _Cad Saude Publica_ . 2006;22(3):619629. doi:10.1590/S0102-311X2006000300017  
10. Paiva V, Ayres JRC de M, Segurado AC, et al. A sexualidade de adolescentes vivendo com HIV: direitos e desafios para o cuidado. _Cien Saude Colet_ . 2011;16(10):4199-4210. doi:10.1590/S141381232011001100025  
11. Secretaria Estadual de Saúde de São Paulo. Programa Estadual de DST e Aids. Manual para assistência a revelação diagnóstica às crianças e jovens que vivem com o HIV/AIDS. Published online 2008.  
12. Qiao S, Li X, Stanton B. Disclosure of Parental HIV Infection to Children: A Systematic Review of Global Literature. _AIDS Behav_ . 2013;17(1):369-389. doi:10.1007/s10461-011-0069-x  
13. Seidl EMF, Rossi W dos S, Viana KF, Meneses AKF de, Meireles E. Crianças e adolescentes vivendo com HIV/Aids e suas famílias: aspectos psicossociais e enfrentamento. _Psicologia: Teoria e Pesquisa_ . 2005;21(3):279-288. doi:10.1590/S0102-37722005000300004  
14. Siu GE, Bakeera-Kitaka S, Kennedy CE, Dhabangi A, Kambugu A. HIV serostatus disclosure and lived experiences of adolescents at the Transition Clinic of the Infectious Diseases Clinic in Kampala, Uganda: A qualitative study. _AIDS Care_ . 2012;24(5):606-611. doi:10.1080/09540121.2011.630346  
15. L S Wiener , H B Battles, N Heilman, C K Sigelman PAP. Factors associated with disclosure of diagnosis to children with HIV/AIDS. _Pediatr AIDS HIV Infect_ . 1996;7(5):310-324.  
16. Balikuddembe R, Kayiwa J, Musoke D, et al. Plasma Drug Level Validates Self-Reported Adherence but Predicts Limited Specificity for Nonadherence to Antiretroviral Therapy. _ISRN Pharmacol_ . 2012;2012:1-7. doi:10.5402/2012/274978  
17. Bangsberg DR, Perry S, Charlebois ED, et al. Non-adherence to highly active antiretroviral therapy predicts progression to AIDS. _AIDS_ . 2001;15(9):1181-1183. doi:10.1097/00002030-20010615000015  
18. Ministério da Saúde do Brasil. Ministério da Saúde. Diretrizes para o fortalecimento das ações de adesão ao tratamento para pessoas que vivem com HIV e Aids. Published online 2007.  
19. Bryson Y. Taking care of the caretakers to enhance antiretroviral adherence in HIV-infected children and adolescents. _J Pediatr (Rio J)_ . 2014;90(6):533-535. doi:10.1016/j.jped.2014.08.001  
20. Chaiyachati KH, Ogbuoji O, Price M, Suthar AB, Negussie EK, Bärnighausen T. Interventions to improve adherence to antiretroviral therapy. _AIDS_ . 2014;28:S187-S204. doi:10.1097/QAD.0000000000000252  
21. Cohan D, Natureeba P, Koss CA, et al. Efficacy and safety of lopinavir/ritonavir versus efavirenzbased antiretroviral therapy in HIV-infected pregnant Ugandan women. _AIDS_ . 2015;29(2):183-191. doi:10.1097/QAD.0000000000000531  
22. Cruz MLS, Cardoso CAA, Darmont MQ, et al. Viral suppression and adherence among HIVinfected children and adolescents on antiretroviral therapy: results of a multicenter study. _J Pediatr (Rio J)_ . 2014;90(6):563-571. doi:10.1016/j.jped.2014.04.007  
49  
23. Cruz MLS, Bastos FI, Darmont M, Dickstein P, Monteiro S. The “moral career” of perinatally HIV-infected children: revisiting Goffman’s concept. _AIDS Care_ . 2015;27(1):6-9. doi:10.1080/09540121.2014.940270  
24. Cruz M, Cardoso C, Darmont M, et al. Children and Adolescents with Perinatal HIV-1 Infection: Factors Associated with Adherence to Treatment in the Brazilian Context. _Int J Environ Res Public Health_ . 2016;13(6):615. doi:10.3390/ijerph13060615  
25. Mbuagbaw L, Bonono-Momnougui, Thabane L. Considerations in using text messages to improve adherence to highly active antiretroviral therapy: a qualitative study among clients in Yaound&amp;eacute;, Cameroon. _HIV/AIDS - Research and Palliative Care_ . Published online April 2012:45. doi:10.2147/HIV.S29954  
26. Ministério da Saúde do Brasil. Secretaria de Vigilância em Saúde, Programa Nacional de DST e Aids. Manual de adesão ao tratamento para pessoas vivendo com HIV e Aids. Published online 2008.  
27. Farley J, Hines S, Musk A, Ferrus S, Tepper V. Assessment of Adherence to Antiviral Therapy in HIV-Infected Children Using the Medication Event Monitoring System, Pharmacy Refill, Provider Assessment, Caregiver Self-Report, and Appointment Keeping. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2003;33(2):211-218. doi:10.1097/00126334-200306010-00016  
28. Haberer JE, Cook A, Walker AS, et al. Excellent Adherence to Antiretrovirals in HIV+ Zambian Children Is Compromised by Disrupted Routine, HIV Nondisclosure, and Paradoxical Income Effects. Sandberg JK, ed. _PLoS One_ . 2011;6(4):e18505. doi:10.1371/journal.pone.0018505  
29. Hogg RS, Heath K, Bangsberg D, et al. Intermittent use of triple-combination therapy is predictive of mortality at baseline and after 1 year of follow-up. _AIDS_ . 2002;16(7):1051-1058. doi:10.1097/00002030200205030-00012  
30. Khan M, Song X, Williams K, Bright K, Sill A, Rakhmanina N. Evaluating adherence to medication in children and adolescents with HIV. _Arch Dis Child_ . 2009;94(12):970-973. doi:10.1136/adc.2008.156232  
31. Nachega JB, Hislop M, Dowdy DW, Chaisson RE, Regensberg L, Maartens G. Adherence to Nonnucleoside Reverse Transcriptase Inhibitor–Based HIV Therapy and Virologic Outcomes. _Ann Intern Med_ . 2007;146(8):564. doi:10.7326/0003-4819-146-8-200704170-00007  
32. Nachega JB, Hislop M, Nguyen H, et al. Antiretroviral Therapy Adherence, Virologic and Immunologic Outcomes in Adolescents Compared With Adults in Southern Africa. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2009;51(1):65-71. doi:10.1097/QAI.0b013e318199072e  
33. Nieuwkerk PT, Oort FJ. Self-Reported Adherence to Antiretroviral Therapy for HIV-1 Infection and Virologic Treatment Response. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2005;38(4):445-448. doi:10.1097/01.qai.0000147522.34369.12  
34. Olds PK, Kiwanuka JP, Nansera D, et al. Assessment of HIV antiretroviral therapy adherence by measuring drug concentrations in hair among children in rural Uganda. _AIDS Care_ . 2015;27(3):327-332. doi:10.1080/09540121.2014.983452  
35. Paterson DL, Swindells S, Mohr J, et al. Adherence to Protease Inhibitor Therapy and Outcomes in Patients with HIV Infection. _Ann Intern Med_ . 2000;133(1):21. doi:10.7326/0003-4819-133-1200007040-00004  
36. Sari L Reisner, Matthew J Mimiaga, Margie Skeer, Brandon Perkovich, Carey V Johnson SAS. A review of HIV antiretroviral adherence and intervention studies among HIV-infected youth. _Top HIV Med_ . 2009;17(1):14-25.  
37. Rocha GM, Machado CJ, Acurcio F de A, Guimarães MDC. Monitoring adherence to antiretroviral treatment in Brazil: an urgent challenge. _Cad Saude Publica_ . 2011;27(suppl 1):s67-s78. doi:10.1590/S0102-311X2011001300008  
50  
38. Sahay S, Dhayarkar S, Reddy Ks. Optimizing adherence to antiretroviral therapy. _Indian J Med Res_ . 2011;134(6):835. doi:10.4103/0971-5916.92629  
39. Simoni JM, Amico KR, Smith L, Nelson K. Antiretroviral Adherence Interventions: Translating Research Findings to the Real World Clinic. _Curr HIV/AIDS Rep_ . 2010;7(1):44-51. doi:10.1007/s11904009-0037-5  
40. Thompson MA, Mugavero MJ, Amico KR, et al. Guidelines for Improving Entry Into and Retention in Care and Antiretroviral Adherence for Persons With HIV: Evidence-Based Recommendations From an International Association of Physicians in AIDS Care Panel. _Ann Intern Med_ . 2012;156(11):817. doi:10.7326/0003-4819-156-11-201206050-00419  
41. Vitolins MZ, Rand CS, Rapp SR, Ribisl PM, Sevick MA. Measuring Adherence to Behavioral and Medical Interventions. _Control Clin Trials_ . 2000;21(5):S188-S194. doi:10.1016/S0197-2456(00)00077-5  
42. Vreeman RC, Wiehe SE, Pearce EC, Nyandiko WM. A Systematic Review of Pediatric Adherence to Antiretroviral Therapy in Low- and Middle-Income Countries. _Pediatr Infect Dis J_ . 2008;27(8):686-691. doi:10.1097/INF.0b013e31816dd325  
43. Wachholz NIR, Ferreira J. Adherence to antiretroviral therapy in children: a study of prevalence and associated factors. _Cad Saude Publica_ . 2007;23(suppl 3):S424-S434. doi:10.1590/S0102311X2007001500010  
44. Giannattasio A, Albano F, Giacomet V, Guarino A. The changing pattern of adherence to antiretroviral therapy assessed at two time points, 12 months apart, in a cohort of HIV-infected children. _Expert Opin Pharmacother_ . 2009;10(17):2773-2778. doi:10.1517/14656560903376178  
45. First-line antiretroviral therapy with a protease inhibitor versus non-nucleoside reverse transcriptase inhibitor and switch at higher versus low viral load in HIV-infected children: an open-label, randomised phase 2/3 trial. _Lancet Infect Dis_ . 2011;11(4):273-283. doi:10.1016/S1473-3099(10)70313-3  
46. Initiation of Antiretroviral Therapy in Early Asymptomatic HIV Infection. _New England Journal of Medicine_ . 2015;373(9):795-807. doi:10.1056/NEJMoa1506816  
47. World Health Organisation. The use of antiretroviral drugs for treating and preventing HIV infection. Published online 2016.  
48. Group TISS. START initiation of Antiretroviral Therapy in Early Asymptomatic HIV Infection. _NEngl J Med_ . 2015;373:795-807. doi:DOI10.1056/NEIMoa1506816  
49. Avy Violari, F.C.Paed., Mark F. Cotton, M.Med., Ph.D., Diana M. Gibb, M.D., Abdel G. Babiker, Ph.D., Jan Steyn, M.Sc., Shabir A. Madhi, F.C.Paed., Ph.D., Patrick Jean-Philippe, M.D., and James A. McIntyre FRCOG for the CST. Early Antiretroviral Therapy and Mortality among HIV-Infected Infants. _New England Journal of Medicine_ . 2008;359(21):2233-2244. doi:10.1056/NEJMoa0800971  
50. Schomaker M, Valeriane Leroy TW, Karl-Gu¨ nter Technau, Lorna Renner, Ali Judd SS, et al. Optimal timing of antiretroviral treatment initiation in HIV-positive children and adolescents: a multiregional analysis from Southern Africa, West Africa and Europe. _Int J Epidemiol_ . 2016;46(2):453465. doi:10.1093/ije/dyw097  
51. Avy Violari, F.C.Paed., Mark F. Cotton, M.Med., Ph.D., Diana M. Gibb, M.D., Abdel G. Babiker, Ph.D., Jan Steyn, M.Sc., Shabir A. Madhi, F.C.Paed., Ph.D., Patrick Jean-Philippe, M.D., and James A. McIntyre FRCOG for the CST. Early Antiretroviral Therapy and Mortality among HIV-Infected Infants. _New England Journal of Medicine_ . 2008;359(21):2233-2244. doi:10.1056/NEJMoa0800971  
52. Szubert AJ, Musiime V, Bwakura-Dangarembizi M, Nahirya-Ntege P, Kekitiinwa A, Gibb DM, Nathoo K, Prendergast AJ WAATT. Pubertal development in HIV-infected African children on first-line antiretroviral therapy. _AIDS_ . 2015;29(5):609. doi:10.1097/QAD.0000000000000590  
51  
53. Chiappini, E., Galli, L., Tovo, P. A., Gabiano, C., Lisi, C., Bernardi, S., ... & Badolato R. Fiveyear follow-up of children with perinatal HIV-1 infection receiving early highly active antiretroviral therapy. _BMC Infect Dis_ . 2009;9(1):140.  
54. Cagigi, A., Rinaldi, S., Cotugno, N., Manno, E. C., Santilli, V., Mora, N., ... & Bernardi S. Early highly active antiretroviral therapy enhances B-cell longevity: a 5 year follow up. _Pediatr Infect Dis J_ . 2014;33(5):e126-e131. doi:10.1097/INF.0000000000000144 55. Cagigi A, Rinaldi S, Cotugno N, et al. Early Highly Active Antiretroviral Therapy Enhances B- cell Longevity. _Pediatric Infectious Disease Journal_ . 2014;33(5):e126-e131. doi:10.1097/INF.0000000000000144  
56. Tobin NH, Aldrovandi GM. Immunology of pediatric HIV infection. _Immunol Rev_ . 2013;254(1):143-169. doi:10.1111/imr.12074  
57. Frieden TR, Harold Jaffe DW, Moran JS, et al. Morbidity and Mortality Weekly Report Recommendations and Reports Centers for Disease Control and Prevention MMWR Editorial and Production Staff (Serials) MMWR Editorial Board. _Recommendations and Reports_ . 2014;63(3).  
58. Lockman S, Shapiro RL, Smeaton LM, et al. Response to Antiretroviral Therapy after a Single, Peripartum Dose of Nevirapine. _New England Journal of Medicine_ . 2007;356(2):135-147. doi:10.1056/NEJMoa062876  
59. MacLeod IJ, Rowley CF, Thior I, et al. Minor resistant variants in nevirapine-exposed infants may predict virologic failure on nevirapine-containing ART. _Journal of Clinical Virology_ . 2010;48(3):162-167. doi:10.1016/j.jcv.2010.03.017  
60. Paediatric European Network for the Treatment of AIDS. Lamivudine/abacavir maintains virological superiority over zidovudine/lamivudine and zidovudine/abacavir beyond 5 years in children. _AIDS_ . 2007;21(8):947-955.  
61. Briz, V., León-Leal, J. A., Palladino, C., Moreno-Perez, D., de Ory, S. J., De José, M. I., ... & Leal M. Potent and sustained antiviral response of raltegravir-based highly active antiretroviral therapy in HIV type 1-infected children and adolescents. _Pediatr Infect Dis J_ . 2012;31(3):273-277.  
62. Nachman, S., Alvero, C., Acosta, E. P., Teppler, H., Homony, B., Graham, B., ... & Frenkel LM. Pharmacokinetics and 48-week safety and efficacy of raltegravir for oral suspension in Human Immunodeficiency Virus type-1-infected children 4 weeks to 2 years of age. _J Pediatric Infect Dis Soc_ . 2015;4(4):e76-e83.  
63. Wiznia A, Alvero C FT. IMPAACT 1093: Dolutegravir in 6- to 12-year-old HIV-infected children: 48-week results. In: _23rd Conference on Retroviruses and Opporotunistic Infections_ . 23rd Conference on Retroviruses and Opporotunistic Infections; 2016.  
64. A. Alberto Cunha Mendes Ferreira, R. Elisa Gonçalves Gonçalves Pinho, R. Castro de Albuquerque, T. Cherem Morelli, R. Vianna Brizolara, A. Francisca Kolling, M. Camelo Madeira de Moura, A. Sposito Tresse, N. Mendonça Collaço Véras, L. Martins de Aquino, A VIA. Surveillance of transmitted HIV drug resistance among treatment‐naïve children under 18 months in Brazil (2009 to 2018). _J Int AIDS Soc_ . 2020;23(S4):120. doi:10.1002/jia2.25547  
65. Cotton, M. F., Holgate, S., Nelson, A., Rabie, H., Wedderburn, C., & Mirochnick M. The last and first frontier–emerging challenges for HIV treatment and prevention in the first week of life with emphasis on premature and low birth weight infants. _J Int AIDS Soc_ . 2015;18:20271.  
66. Chadwick, E. G., Yogev, R., Alvero, C. G., Hughes, M. D., Hazra, R., Pinto, J. A. ... & International Pediatric Adolescent Clinical Trials Group. Long-term outcomes for HIV-infected infants less than 6 months of age at initiation of lopinavir/ritonavir combination antiretroviral therapy. _AIDS_ . 2011;25(5):643.  
52  
67. Orikiiriza, J., Bakeera-Kitaka, S., Musiime, V., Mworozi, E. A., Mugyenyi, P., & Boulware DR. The clinical pattern, prevalence, and factors associated with immune reconstitution inflammatory syndrome in Ugandan children. _AIDS_ . 2009;24(13):2009.  
68. Boulware, D. R., Callens, S., & Pahwa S. Pediatric hiv immune reconstitution inflammatory syndrome (iris). _Curr Opin HIV AIDS_ . 2008;3(4):461.  
69. Müller, M., Wandel, S., Colebunders, R., Attia, S., Furrer, H., & Egger M. Immune reconstitution inflammatory syndrome in patients starting antiretroviral therapy for HIV infection: a systematic review and meta-analysis. _Lancet Infect Dis_ . 2010;10(4):251-261.  
70. Murdoch, D. M., Venter, W. D., Van Rie, A., & Feldman C. Immune reconstitution inflammatory syndrome (IRIS): review of common infectious manifestations and treatment options. _AIDS Res Ther_ . 2007;4(1):9.  
71. Meintjes, G., Wilkinson, R. J., Morroni, C., Pepper, D. J., Rebe, K., Rangaka, M. X., ... & Maartens G. Randomized placebo-controlled trial of prednisone for paradoxical TB-associated immune reconstitution inflammatory syndrome. _AIDS_ . 2010;24(15).  
72. Chiappini, E., Galli, L., Tovo, P. A., Gabiano, C., Lisi, C., Bernardi, S., ... & Badolato R. Fiveyear follow-up of children with perinatal HIV-1 infection receiving early highly active antiretroviral therapy. _BMC Infect Dis_ . 2009;9(1):140.  
73. Coovadia A, Abrams EJ, Stehlau R, et al. Reuse of Nevirapine in Exposed HIV-Infected Children After Protease Inhibitor–Based Viral Suppression. _JAMA_ . 2010;304(10):1082. doi:10.1001/jama.2010.1278  
74. DeJesus E, Herrera G, Teofilo E, et al. Abacavir versus Zidovudine Combined with Lamivudine and Efavirenz, for the Treatment of Antiretroviral‐Naive HIV‐Infected Adults. _Clinical Infectious Diseases_ . 2004;39(7):1038-1046. doi:10.1086/424009  
75. Delaugerre C, Chaix ML, Blanche S, et al. Perinatal acquisition of drug-resistant HIV-1 infection: mechanisms and long-term outcome. _Retrovirology_ . 2009;6(1):85. doi:10.1186/1742-4690-6-85  
76. Pulido F, Ribera E, Lagarde M, et al. Dual Therapy with Darunavir and Ritonavir Plus Lamivudine vs Triple Therapy with Darunavir and Ritonavir Plus Tenofovir Disoproxil Fumarate and Emtricitabine or Abacavir and Lamivudine for Maintenance of Human Immunodeficiency Virus Type 1 Viral Suppression: Randomized, Open-Label, Noninferiority DUAL-GESIDA 8014-RIS-EST45 Trial. _Clinical Infectious Diseases_ . 2017;65(12). doi:10.1093/cid/cix734  
77. Llibre JM, Brites C, Cheng CY, et al. Efficacy and Safety of Switching to the 2-Drug Regimen Dolutegravir/Lamivudine Versus Continuing a 3- or 4-Drug Regimen for Maintaining Virologic Suppression in Adults Living With Human Immunodeficiency Virus 1 (HIV-1): Week 48 Results From the Phase 3, Noninferiority SALSA Randomized Trial. _Clin Infect Dis_ . 2023;76(4). doi:10.1093/cid/ciac130  
78. Cahn P, Madero JS, Arribas J, et al. Durable Efficacy of Dolutegravir (DTG) Plus Lamivudine (3TC) in Antiretroviral Treatment-Naive Adults With HIV-1 Infection: 96-Week Results From the GEMINI Studies. _J Infect Public Health_ . 2020;13(2). doi:10.1016/j.jiph.2020.01.118  
79. Erratum: Durable Efficacy of Dolutegravir Plus Lamivudine in Antiretroviral Treatment-Naive Adults With HIV-1 Infection: 96-Week Results From the GEMINI-1 and GEMINI-2 Randomized Clinical Trials: Erratum (Journal of acquired immune deficiency syndromes (1999) (2020) 83 3 (310-318)). _J Acquir Immune Defic Syndr_ . 2020;84(3). doi:10.1097/QAI.0000000000002394  
80. Cahn P, Madero JS, Arribas JR, et al. Durable Efficacy of Dolutegravir Plus Lamivudine in Antiretroviral Treatment–Naive Adults With HIV-1 Infection. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2020;83(3).  
81. Cahn P, Madero JS, Arribas JR, et al. Durable Efficacy of Dolutegravir Plus Lamivudine in Antiretroviral Treatment-Naive Adults With HIV-1 Infection: 96-Week Results From the GEMINI-1 and  
53  
GEMINI-2 Randomized Clinical Trials. In: _Journal of Acquired Immune Deficiency Syndromes_ . Vol 83. ; 2020. doi:10.1097/QAI.0000000000002275  
82. Baldé A, Lièvre L, Maiga AI, et al. Re-engagement in care of people living with HIV lost to follow-up after initiation of antiretroviral therapy in Mali: Who returns to care? _PLoS One_ . 2020;15(9):e0238687. doi:10.1371/journal.pone.0238687  
83. Benson C, Wang X, Dunn KJ, et al. Antiretroviral Adherence, Drug Resistance, and the Impact of Social Determinants of Health in HIV-1 Patients in the US. _AIDS Behav_ . 2020;24(12):3562-3573. doi:10.1007/s10461-020-02937-8  
84. Ford N, Orrell C, Shubber Z, Apollo T, Vojnov L. HIV viral resuppression following an elevated viral load: a systematic review and meta‐analysis. _J Int AIDS Soc_ . 2019;22(11). doi:10.1002/jia2.25415  
85. Ford N, Orrell C, Shubber Z, Apollo T, Vojnov L. HIV viral resuppression following an elevated viral load: a systematic review and meta-analysis. _J Int AIDS Soc_ . 2019;22(11):e25415. doi:10.1002/jia2.25415  
86. Schweighardt B, Ortiz GM, Grant RM, et al. Emergence of drug-resistant HIV-1 variants in patients undergoing structured treatment interruptions. _AIDS_ . 2002;16(17):2342-2344. doi:10.1097/00002030-200211220-00018  
87. Mouradjian MT, Heil EL, Sueng H, Pandit NS. Virologic suppression in patients with a documented M184V/I mutation based on the number of active agents in the antiretroviral regimen. _SAGE Open Med_ . 2020;8:2050312120960570. doi:10.1177/2050312120960570  
88. Hocqueloux L, Raffi F, Prazuck T, et al. Dolutegravir Monotherapy Versus Dolutegravir/Abacavir/Lamivudine for Virologically Suppressed People Living With Chronic Human Immunodeficiency Virus Infection: The Randomized Noninferiority MONotherapy of TiviCAY Trial. _Clin Infect Dis_ . 2019;69(9):1498-1505. doi:10.1093/cid/ciy1132  
89. Rolle CP, Nguyen V, Hinestrosa F, DeJesus E. Virologic outcomes of switching to dolutegravir functional mono- or dual therapy with a non-cytosine nucleoside analog: a retrospective study of treatmentexperienced, patients living with HIV. _AIDS Res Ther_ . 2021;18(1):26. doi:10.1186/s12981-021-00352-0  
90. Wijting I, Rokx C, Boucher C, et al. Dolutegravir as maintenance monotherapy for HIV (DOMONO): a phase 2, randomised non-inferiority trial. _Lancet HIV_ . 2017;4(12):e547-e554. doi:10.1016/S2352-3018(17)30152-2  
91. Müller, M., Wandel, S., Colebunders, R., Attia, S., Furrer, H., & Egger M. Immune reconstitution inflammatory syndrome in patients starting antiretroviral therapy for HIV infection: a systematic review and meta-analysis. _Lancet Infect Dis_ . 2010;10(4):251-261.  
92. Baxter JD, Mayers DL, Wentworth DN, et al. A randomized study of antiretroviral management based on plasma genotypic antiretroviral resistance testing in patients failing therapy. _AIDS_ . 2000;14(9):F83-F93. doi:10.1097/00002030-200006160-00001  
93. de Martino M, Galli L, Moriondo M, et al. Dissociation of Responses to Highly Active Antiretroviral Therapy: Notwithstanding Virologic Failure and Virus Drug Resistance, Both CD4+ and CD8+ T Lymphocytes Recover in HIV-1 Perinatally Infected Children. _J Acquir Immune Defic Syndr (1988)_ . Published online February 2001:196-197. doi:10.1097/00042560-200102010-00018  
94. Michael Aboud, Richard Kaplan, Johannes Lombaard, Fujie Zhang, Jose Hidalgo, Elmira Mamedova, Marcelo Losso, Ploenchan Chetchotisakd, Jorg Sievers, Dannae Brown, Judy Hopking, Mark Underwood, Maria Claudia Nascimento, Martin Ga KS. Superior Efficacy of Dolutegravir (DTG) Plus 2 Nucleoside Reverse Transcriptase Inhibitors (NRTIs) Compared With Lopinavir/Ritonavir (LPV/RTV) Plus 2 NRTIs in Second-Line Treatment: Interim Data From the DAWNING Study. In: _9th IAS Conference on HIV Science_ . ; 2017.  
54  
95. Paton NI, Kityo C, Hoppe A, et al. Assessment of Second-Line Antiretroviral Regimens for HIV Therapy in Africa. _New England Journal of Medicine_ . 2014;371(3):234-247. doi:10.1056/NEJMoa1311274  
96. Castagna A, Maggiolo F, Penco G, et al. Dolutegravir in Antiretroviral-Experienced Patients With Raltegravir- and/or Elvitegravir-Resistant HIV-1: 24-Week Results of the Phase III VIKING-3 Study. _Journal of Infectious Diseases_ . 2014;210(3):354-362. doi:10.1093/infdis/jiu051  
97. White K, Raffi F, Miller M. Resistance Analyses of Integrase Strand Transfer Inhibitors within Phase 3 Clinical Trials of Treatment-Naive Patients. _Viruses_ . 2014;6(7):2858-2879. doi:10.3390/v6072858  
98. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de DST A e HVirais. _Recomendações Para a Atenção Integral a Adolescentes e Jovens Vivendo Com HIV/Aids_ . (Ministério da Saúde, ed.).; 2013.  
99. Rosen DS, Blum RW, Britto M, Sawyer SM, Siegel DM. Transition to adult health care for adolescents and young adults with chronic conditions. _Journal of Adolescent Health_ . 2003;33(4):309-311. doi:10.1016/S1054-139X(03)00208-8  
100. Departamento Científico de Adolescência. Sociedade Brasileira de Pediatria. _Manual de Orientações. Adolescência: Doenças Crônicas e Ambulatórios de Transição_ .; 2020.  
101. Kralik D, Visentin K, van Loon A. Transition: a literature review. _J Adv Nurs_ . 2006;55(3):320329. doi:10.1111/j.1365-2648.2006.03899.x  
102. Machado DM, Succi RC, Turato ER. Transitioning adolescents living with HIV/AIDS to adultoriented health care: an emerging challenge. _J Pediatr (Rio J)_ . 2010;86(6):465-472. doi:10.2223/JPED.2048  
103. Machado DM, Galano E, de Menezes Succi RC, Vieira CM, Turato ER. Adolescents growing with HIV/AIDS: experiences of the transition from pediatrics to adult care. _The Brazilian Journal of Infectious Diseases_ . 2016;20(3):229-234. doi:10.1016/j.bjid.2015.12.009  
104. Blum RWM, Garell D, Hodgman CH, et al. Transition from child-centered to adult health-care systems for adolescents with chronic conditions. _Journal of Adolescent Health_ . 1993;14(7):570-576. doi:10.1016/1054-139X(93)90143-D  
105. Chakraborty R, Van Dyke RB, Flynn PM, et al. Transitioning HIV-Infected Youth Into Adult Health Care. _Pediatrics_ . 2013;132(1):192-197. doi:10.1542/peds.2013-1073  
106. Viner R. Transition from paediatric to adult care. Bridging the gaps or passing the buck? _Arch Dis Child_ . 1999;81(3):271-275. doi:10.1136/adc.81.3.271  
107. McDonagh JE, Viner RM. Lost in transition? Between paediatric and adult services. _BMJ_ . 2006;332(7539):435-437. doi:10.1136/bmj.332.7539.435  
108. Collins IJ, Foster C, Tostevin A, et al. Clinical Status of Adolescents with Perinatal HIV at Transfer to Adult Care in the UK/Ireland. _Clinical Infectious Diseases_ . 2017;64(8):1105-1112. doi:10.1093/cid/cix063  
109. Gilliam PP, Ellen JM, Leonard L, Kinsman S, Jevitt CM, Straub DM. Transition of Adolescents With HIV to Adult Care: Characteristics and Current Practices of the Adolescent Trials Network for HIV/AIDS Interventions. _Journal of the Association of Nurses in AIDS Care_ . 2011;22(4):283-294. doi:10.1016/j.jana.2010.04.003  
110. Maturo D, Powell A, Major-Wilson H, Sanchez K, De Santis JP, Friedman LB. Development of a Protocol for Transitioning Adolescents With HIV Infection to Adult Care. _Journal of Pediatric Health Care_ . 2011;25(1):16-23. doi:10.1016/j.pedhc.2009.12.005  
111. Chadwick EG, Yogev R, Alvero CG, et al. Long-term outcomes for HIV-infected infants less than 6 months of age at initiation of lopinavir/ritonavir combination antiretroviral therapy. _AIDS_ . 2011;25(5):643-649. doi:10.1097/QAD.0b013e32834403f6  
55  
112. Machado DM, Succi RC, Turato ER. Transitioning adolescents living with HIV/AIDS to adultoriented health care: an emerging challenge. _J Pediatr (Rio J)_ . 2010;86(6):465-472. doi:10.2223/JPED.2048  
113. Wiener LS, Kohrt BA, Battles HB, Pao M. The HIV Experience: Youth Identified Barriers for Transitioning from Pediatric to Adult Care. _J Pediatr Psychol_ . 2011;36(2):141-154. doi:10.1093/jpepsy/jsp129  
114. Njuguna IN, Beima-Sofie K, Mburu CW, et al. Adolescent transition to adult care for HIV-infected adolescents in Kenya (ATTACH): study protocol for a hybrid effectiveness-implementation cluster randomised trial. _BMJ Open_ . 2020;10(12):e039972. doi:10.1136/bmjopen-2020-039972  
115. Zanoni BC, Musinguzi N, Archary M, Sibaya T, Haberer JE. Development of a transition readiness score for adolescents living with perinatally-acquired HIV and transitioning to adult care. _AIDS Behav_ . 2022;26(9):3131-3138. doi:10.1007/s10461-022-03650-4  
116. Ministério da Saúde do Brasil. Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia PósExposição (PEP) de Risco à Infecção pelo HIV, IST e Hepatites Virais. Published online 2018.  
117. Ministério da Saúde. Secretaria de Atenção Primária à Saúde. Departamento de Ações Programáticas Estratégicas. Coordenação-Geral de Ciclos da Vida. Coordenação de Saúde dos Adolescentes e Jovens. _NOTA TÉCNICA N_<sup>_o_</sup> _2/2022-COSAJ/CGCIVI/DAPES/SAPS/MS_ .; 2022.  
118. Ministério da Saúde. _NOTA TÉCNICA N_<sup>_o_</sup> _498/2022-CGAHV/.DCCI/SVS/MS. Acesso à Profilaxia Pré-Exposição (PrEP) de Risco à Infecção Pelo HIV Para Adolescentes a Partir de 15 Anos, Com Peso Corporal Igual Ou Maior a 35kg, Que Apresentem Potencial Risco Para Infecção Por via Sexual Pelo HIV_ .; 2022.  
56  
**Apêndice A – FÓRMULA PARA CÁLCULO DA SUPERFÍCIE CORPÓREA EM PEDIATRIA**  
Fonte: BAILEY, B. J.; BRIARS, G. L. _Estimating the surface area of the human body_ . Statistics in Medicine, [S.l.], v. 15, n. 13, p. 1325-32, 15 jul. 1996. Disponível em: https://www.ncbi.nlm.nih.gov/pubmed/8841644. Acesso em: 15 mar. 2018.  
57  
**Apêndice B – DOENÇAS, SINAIS OU SINTOMAS INDICATIVOS DE IMUNODEFICIÊNCIA EM CRIANÇAS MENORES DE 13 ANOS DE IDADE, DIAGNOSTICADAS POR MÉTODO DEFINITIVO (D) E PRESUNTIVO**  
|**CARÁTER LEVE**<sup>**a**</sup>|**CARÁTER MODERADO**<sup>**a**</sup>|**CARÁTER GRAVE**<sup>**a**</sup>|
|---|---|---|
|Aumento crônico da<br>parótida|Anemia por mais de 30 dias (d)<br>Candidose oral (d)|Candidose do esôfago, traqueia (d),<br>brônquios (d) ou pulmão (d)|
|Dermatite persistente<br>Esplenomegalia|Diarreia recorrente ou crônica (d)<br>Febre persistente (superior a um|Citomegalovirose, exceto fígado, baço ou<br>linfonodos (em maiores que 1 mês de idade)<br>(d)|
|Hepatomegalia|mês) (d)|Coccidioidomicose,<br>disseminada<br>ou|
|Linfadenopatia (0,5 cm<br>em mais de dois sítios)|Gengivoestomatite<br>herpética<br>recorrente|extrapulmonar<br>Criptococose extrapulmonar (d)|
|Infecções persistentes<br>ou recorrentes de vias<br>aéreas superiores (otite<br>média e sinusite)|Hepatite (d)<br>Herpes simples em brônquios,<br>pulmões<br>ou<br>trato<br>gastrointestinal(antes de 1 mês de<br>idade) (d)<br>Herpes-zóster (d)<br>Infecção<br>por<br>citomegalovírus<br>(antes de 1 mês de idade) (d)|Criptosporidiose (com diarreia por um<br>período superior a um mês) (d)<br>Encefalopatia (determinada pelo HIV)<br>Herpes simples em brônquios, pulmões ou<br>trato gastrointestinal (d)<br>Herpes simples mucocutâneo (período<br>superior a um mês, em crianças com mais<br>de 1 mês de idade)|
||Leiomiossarcoma (d)|Histoplasmose disseminada (d)|
||Linfopenia (por mais de 30<br>dias)(d)<br>Meningite bacteriana, pneumonia<br>ou sepse<br>Miorcardiopatia (d)<br>Nefropatia<br>Nocardiose (d)<br>Pneumonia linfoide intersticial<br>Toxoplamose (antes de 1 mêsde<br>idade)|Infecções bacterianas graves, múltiplas ou<br>recorrentes (d)<br>Isosporidiose intestinal crônica (d)<br>Leucoencefalopatia multifocal progressiva<br>Linfoma não Hodgkin de células B e outros<br>linfomas dos tipos histológicos, linfoma<br>maligno de células grandes ou clivadas<br>(Burkitt ou não Burkitt), ou linfoma<br>malignoimunoblástico<br>sem<br>outra<br>especificação (d)<br>Linfoma primário do cérebro (d)|
||Trombocitopenia|Pneumonia por_Pneumocystis jirovecii_|
||Tuberculose pulmonar<br>Varicela disseminada|Micobacteriose<br>disseminada<br>(exceto<br>tuberculose e hanseníase – e não em<br>pulmões, pele, linfonodos cervicais/hilares)<br>Sarcoma de Kaposi|
|||Sepse recorrente por Salmonella (não<br>tifoide) (d)<br>Síndrome de emaciação|  
58  
|**CARÁTER LEVE**<sup>**a**</sup>|**CARÁTER MODERADO**<sup>**a**</sup>|**CARÁTER GRAVE**<sup>**a**</sup>|
|---|---|---|
|||Toxoplasmose cerebral (em crianças com<br>mais de 1 mês de idade)|
|||Tuberculose<br>disseminada<br>ou<br>extrapulmonar|  
Fonte: DATHI/SVSA/MS.  
a. definição da gravidade das doenças, sinais e/ou sintomas corresponde às categorias da classificação clínica do _Centers for Disease Control and Prevention_ (CDC, 1994).  
59  
**Apêndice C - CLASSIFICAÇÃO IMUNOLÓGICA DO HIV COM BASE EM LT-CD4+, EM NÚMEROS ABSOLUTOS E PERCENTUAIS, E DE ACORDO COM A IDADE**  
||||**Idade na data d**|**o LT-CD4**|**+**||
|---|---|---|---|---|---|---|
|**Classificação de**<br>**imunossupressão***|**< 1 an**|**o**|**1 a 6 an**|**os**|**≥ 6 ano**|**s**|
||**células/mm**<sup>**3**</sup>|**%**|**células/mm**<sup>**3**</sup>|**%**|**células/mm**<sup>**3**</sup>|**%**|
|1 – Ausente|≥1.500|≥34|≥1.000|≥30|≥500|≥26|
|2 – Moderada|750-1.490|26-33|500-999|22-29|200-499|14-25|
|3 – Grave<sup>(a)</sup>|<750|<26|<500|<22|<200|<14|  
Fonte: _Morbidity and Mortality Weekly Report. Recommendations and Reports_ / Vol. 63 / No. 3 April 11, 2014 _Revised Surveillance Case Definition for HIV Infection_ — United States, 2014.  
*A classificação é inicialmente realizada pela contagem de LT-CD4+, na indisponibilidade considerar a porcentagem.  
**(a) Independentemente do resultado da contagem de LT-CD4+ na presença de uma infecção oportunista, a classificação 3 (grave) é estabelecida.**  
60

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Apêndice D - POSOLOGIA PARA USO PEDIÁTRICO** -->
**Quadro D1** . Dose recomendada de ritonavir para pacientes pediátricos.  
|**Área**<br>**de**<br>|**Volume de soluçã**|**o oral de ritonavir p**|**ara crianças**||
|---|---|---|---|---|
|**suerfície**|||||
|**p**<br>**corporal (m**<sup>**2**</sup>**)***|**2 doses diárias**<br>**(250 mg/m**<sup>**2**</sup>**)**|**2 doses diárias**<br>**(300 mg/m**<sup>**2**</sup>**)**|**2 doses diárias**<br>**(350 mg/m**<sup>**2**</sup>**)**|**2 doses diárias**<br>**(400 mg/m**<sup>**2**</sup>**)**|
|0,20|0,6 mL<br>(50 mg)|0,75 mL<br>(60 mg)|0,9 mL<br>(70 mg)|1,0 mL<br>(80 mg)|
|0,25|0,8 mL<br>(62,5 mg)|0,9 mL<br>(75 mg)|1,1 mL<br>(87,5 mg)|1,25 mL<br>(100 mg,<br>1 comprimido)|
|0,50|1,6 mL<br>(125 mg)|1,9 mg<br>(150 mg)|2,2 mL<br>(175 mg)|2,5 mL<br>(200 mg,<br>2 comprimidos)|
|0,75|2,3 mL<br>(187,5 mg)|2,8 mL<br>(225 mg)|3,3 mL<br>(262,5 mg)|3,75 mL<br>(300 mg,<br>3 comprimidos)|
|1,00|3,1 mL<br>(250 mg)|3,75 mL<br>(300 mg,<br>3 comprimidos)|4,4 mL<br>(350 mg)|5 mL<br>(400 mg,<br>4 comprimidos)|
|1,25|3,9 mL<br>(312,5 mg)|4,7 mL<br>(375 mg)|5,5 mL<br>(437,5 mg)|6,25 mL<br>(500 mg,<br>5 comprimidos)|
|1,50|4,7 mL<br>(375 mg)|5,6 mL<br>(450 mg)|6,6 mL<br>(525 mg)|7,5 mL<br>(600 mg,<br>6 comprimidos)|  
* A Área da superfície corporal (ASC) pode ser calculada pela fórmual descrita no Apêndice A. Fonte: Bula do Ritonavir (ANVISA).  
**Quadro D2** . Dose recomendada de darunavir + ritonavir para pacientes pediátricos previamente expostos a tratamento antirretroviral com pelo menos uma mutação associada à resistência de darunavir<sup>a</sup> e pesando pelo menos 15 kg (3 anos até 18 anos).  
|**Peso corpóreo**|**Dose**|
|---|---|
|15 kg até 30 kg|375 mg de darunavir + 50 mg de ritonavir duas vezes ao dia<br>com alimentos|
|30 kg até 40 kg|450 mg de darunavir + 60 mg de ritonavir duas vezes ao dia<br>com alimentos|
|A partir de 40 kg|600 mg de darunavir + 100 mg de ritonavir duas vezes ao dia<br>com alimentos|  
a DRV-RAMs: V111, V321, L33F, I47V, I50V, I54M, I54L, T74P, L76V, I84V e L89V.  
Fonte: Bula do Prezista<sup>®</sup> (ANVISA).  
61  
**Quadro D3** . Dose recomendada de darunavir + ritonavir para pacientes pediátricos sem tratamento antirretroviral anterior ou previamente expostos a tratamento antirretroviral sem mutações associadas à resistência de darunavir<sup>a</sup> e pesando pelo menos 15 kg (3 anos até 18 anos).  
|**Peso corpóreo**|**Dose**|
|---|---|
|15 kg até 30 kg|600 mg de darunavir + 100 mg de ritonavir duas vezes ao dia<br>com alimentos|
|30 kg até 40 kg|675 mg de darunavir + 100 mg de ritonavir duas vezes ao dia<br>com alimentos|
|A partir de 40 kg|800 mg de darunavir + 100 mg de ritonavir duas vezes ao dia<br>com alimentos|  
a DRV-RAMs: V111, V321, L33F, I47V, I50V, I54M, I54L, T74P, L76V, I84V e L89V.  
Fonte: Bula do Prezista<sup>®</sup> (ANVISA).  
62

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Apêndice E – INFORMAÇÕES SOBRE OS ARV DISPONÍVEIS NO SUS PARA USO EM CRIANÇAS E ADOLESCENTES** -->
|||**Ã**<br>|**REAÇÕES**<br>**ADVERSAS**||
|---|---|---|---|---|
|**MEDICAMENTO**|**DOSE PADRÃO RECOMENDADA**|**APRESENTAÇO**<br>**E**<br>**COSERAÃO**|**MAIS**<br>**COMUNS**<br>**E**|**COMENTÁRIOS**|
|**INIBIDORES DA TR**|**ANSCRIPTASE REVERSA ANÁLOGOS**|**NVÇ**<br>**DE NUCLEOSÍDEO (ITRN)**|**CONTRAINDICAÇÕES**||
|**Abacavir (ABC)**|Solução:<br>A partir de 3 meses: 8 mg/kg, 2 vezes/dia<br>(dose máxima 600 mg/dia)<br>Comprimido:<br>A partir de 12 anos: 300 mg, 2 vezes/dia.|Solução oral 20 mg/mL<br>refrigerar após aberto. Após<br>aberto, válido por 2 meses.<br>Comprimido revestido de 300<br>mg<br>Armazenamento: manter entre<br>15°C-30°C|Reações de hipersensibilidade<br>Genótipo HLA-B*5701 positivo<br>contraindica o ABC|<br>Pode ser administrado com ou<br>sem alimentos<br><br>Comprimido<br>pode<br>ser<br>macerado e dissolvido com pequena<br>quantidade<br>de<br>água<br>e<br>ingerido<br>imediatamente.|
|**Lamivudina (3TC)**|Solução:<br>Abaixo de 30 dias: 2 mg/kg, 2 vezes/dia.;<br>De 30 dias a até 12 anos: 4 mg/kg 2<br>vezes/dia. (dose máxima. 300 mg/dia)<br>Comprimidos:<br>A partir de 12 anos: 150 mg, 2 vezes/dia.|Solução<br>oral<br>10<br>mg/mL.<br>Armazenamento: manter entre<br>15°C-30°C.<br>Após<br>aberto,<br>válido por 40 dias.<br>Comprimido<br>de<br>150<br>mg<br>Armazenamento:<br>manter entre 15°C-30°C.|Náusea,<br>diarreia,<br>cefaleia,<br>fadiga, exacerbação de hepatite<br>B se interrompido|<br>Pode ser administrado com ou<br>sem alimentos.<br><br>Comprimido<br>pode<br>ser<br>macerado e misturados com uma<br>pequena quantidade de água ou comida<br><br>Ajustar dose em caso de<br>insuficiência renal<br><br>Não administrar em criança<br>com idade gestacional ao nascer abaixo<br>de 34 semanas.|
|**Tenofovir (TDF)**|Acima de 12 anos ou a partir de 35 kg: 300<br>mg/dia, 1 vez/dia.|Comprimido de 300 mg<br>Armazenamento: manter entre<br>15°C-30°C.|Vômitos,<br>náusea,<br>cefaleia,<br>disfunção<br>tubular<br>renal,<br>desmineralização<br>óssea,<br>exacerbação de hepatite B se<br>interrompido<br>Monitorar função renal|<br>Pode ser administrado com ou<br>sem alimentos.<br><br>Comprimido<br>pode<br>ser<br>macerado e misturado com pequena<br>quantidade de água (gosto amargo).<br><br>Ajustar dose em caso de<br>insuficiência renal|
|**Zidovudina (AZT)**|Solução oral:<br>RN com menos de 30 semanas de idade<br>gestacional: 2 mg/kg/dose,2 vezes/dia.|Solução oral: 10<br>mg/mL.<br>Armazenamento:<br>manter entre 15°C-30°C|Anemia,<br>granulocitopenia,<br>náusea,<br>vômitos,<br>cefaléia,<br>neuropatia,miopatia,hepatite|<br>Pode ser administrado com ou<br>sem alimentos.|  
63  
|**MEDICAMENTO**|**DOSE PADRÃO RECOMENDADA**|**APRESENTAÇÃO**<br>**E**<br>**CONSERVAÇÃO**|**REAÇÕES**<br>**ADVERSAS**<br>**MAIS**<br>**COMUNS**<br>**E**<br>**CONTRAINDICAÇÕES**|**COMENTÁRIOS**|
|---|---|---|---|---|
||RN entre 30 e 35 semanas de idade<br>gestacional:<br>2 mg/kg/dose 2 vezes/dia por 14 dias e<br>3 mg/kg/dose de 2 vezes/dia a partir do 15º<br>dia.<br>RN com 35 semanas de idade gestacional<br>ou mais 4 mg/kg/dose,2 vezes/dia.<br>Injetável:<br>RN com menos de 30 semanas de idade<br>gestacional:<br>1,5<br>mg/kg/dose,<br>via<br>intravenosa, 2 vezes/dia.<br>RN entre 30 e 35 semanas de idade<br>gestacional:<br>1,5 mg/kg/dose via intravenosa, 2 vezes/dia<br>nos primeiros 14 dias de vida e<br>2,3 mg/kg/dose 2 vezes/dia a partir do 15°<br>dia.<br>RN com 35 semanas de idade gestacional<br>ou mais:<br>3 mg/kg/dose via intravenosa,2 vezes/dia.<br>Solução oral:<br>Entre 4 kg e 9 kg: 12 mg/kg/dose 2<br>vezes/dia.<br>Entre 9 kg e 30 kg: 9 mg/kg/dose, 2<br>vezes/dia.<br>Apartir de 30 kg: 300 mg,2 vezes/dia.<br>Cápsula:|Solução injetável 10 mg/mL<br>(frasco-ampola de 20mL):<br>Após a diluição, recomenda-se<br>que<br>as<br>soluções<br>sejam<br>administradas dentro de 8<br>horas se mantidas a 25ºC, ou<br>dentro<br>de<br>24<br>horas<br>se<br>refrigeradas entre 2ºC e 8ºC.<br>Cápsula gelatinosa dura de 100<br>mg.<br>Armazenamento:<br>manter entre 15°C-30°C||<br>Cápsula: não deve ser partida,<br>aberta ou mastigada.|  
64  
|||**APRESENTAÃO**<br>**E**|**REAÇÕES**<br>**ADVERSAS**||
|---|---|---|---|---|
|**MEDICAMENTO**|**DOSE PADRÃO RECOMENDADA**|**Ç**<br> <br>**CONSERVAÇÃO**|**MAIS**<br>**COMUNS**<br>**E**<br>**CONTRAINDICAÇÕES**|**COMENTÁRIOS**|
|**INIBIDORES DA TR**<br>**Nevirapina (NVP)**|135 a 270 mg/m<sup>2</sup>de superfície corporal de<br>2 vezes/dia(dose máxima: 600 mg/dia).<br>**ANSCRIPTASE REVERSA NÃO ANÁLO**<br>Solução oral:<br>RN idade gestacional igual ou maior que 34<br>e menor que 37 semanas:<br>**1ª semana**: 4 mg/kg/dose, de 12/12 horas;<br>**A partir da 2ª semana até 4ª semana**: 6<br>mg/kg/dose, de 12/12 horas<br>Como alternativa ao raltegravir 100 mg<br>granulado no alto risco:<br>37 semanas ou mais (IG): 6 mg/kg/dose, de<br>12/12 horas<br>**14 dias a 8 anos**: 200 mg/m² 1 vez/dia por<br>14 dias. Depois, 200 mg/m², 2 vezes/dia.<br>**A partir de 8 anos**: 120 a 150 mg/m² (dose<br>máxima 200 mg, 2 vezes /dia)<br>Comprimidos:<br>Adolescentes: 200 mg 1 vez/dia por 14 dias,<br>depois: 200 mg de 2 vezes/dia.<br>*A dose de 200 mg/m² de superfície<br>corporal só deve ser utilizada para lactentes<br>com infecção confirmadapelo HIV|**GOS DE NUCLEOSÍDEOS (IT**<br>Suspensão oral 10 mg/mL.<br>Armazenamento: manter entre<br>15°C-30°C.<br>Após<br>aberto,<br>válido por 20 dias.<br>Comprimido<br>de<br>200<br>mg.<br>Armazenamento:<br>manter entre 15°C-30°C.|**RNN)**<br>Erupção<br>cutânea<br>(Rash),<br>hepatite.|<br>Pode ser administrado com ou<br>sem alimentos.<br><br>Comprimido<br>pode<br>ser<br>macerado e dissolvido em água.<br><br>Suspensão oral: agite bem<br>antes de administrar.|
|**Efavirenz (EFZ)**|Solução Oral:<br>A partir de 3 anos<br>10 kg a 15 kg: 200 mg 1 vez/dia<br>15 kga 20 kg: 250 mg1 vez/dia|Solução<br>oral<br>30<br>mg/mL<br>Armazenamento: manter entre<br>15°C-30°C|Reações adversas mais comuns:|<br>Pode ser administrado com ou<br>sem alimentos.<br><br>Comprimido<br>pode<br>ser<br>macerado|  
65  
|**MEDICAMENTO**|**DOSE PADRÃO RECOMENDADA**|**APRESENTAÇÃO**<br>**E**<br>**CONSERVAÇÃO**|**REAÇÕES**<br>**ADVERSAS**<br>**MAIS**<br>**COMUNS**<br>**E**<br>**CONTRAINDICAÇÕES**|**COMENTÁRIOS**|
|---|---|---|---|---|
||20 kg a 25 kg: 300 mg 1 vez/dia<br>25 kg a 32,5 kg: 350 mg 1 vez/dia<br>32,5 kg a 40 kg: 400 mg 1 vez/dia<br>A partir de 40 kg: 600 mg 1 vez/dia|Comprimido revestido de 200<br>mg e 600 mg. Armazenamento:<br>manter entre 15°C-30°C|Alterações<br>psiquiátricas<br>e<br>neurológicas, sonhos vividos,<br>ginecomastia|<br>A administração de efavirenz<br>com<br>alimentos<br>pode<br>aumentar<br>a<br>exposição ao efavirenz e pode levar a<br>um aumento na frequência de efeitos<br>adversos. Tomar efavirenz com o<br>estômago vazio, de preferência antes de<br>se deitar.|
|**Etravirina (ETR)**|Entre 6 e 18 anos e a partir de 16 kg:<br>16kg a 20 kg: 100 mg, 2 vezes/dia.<br>20 kg a 25 kg: 125 mg, 2 vezes/dia.<br>25 kg a 30 kg: 150 mg, 2 vezes/dia.<br>A partir de 30 kg: 200 mg, 2 vezes/dia.|Comprimido 100 mg e 200 mg<br>Armazenamento: manter entre<br>15°C-30°<br>na<br>embalagem<br>original.|Reações adversas mais comuns:<br>Síndrome de Steven-Johnson,<br>náuseas, exantema, reação de<br>hipersensibilidade|<br>Administrar<br>sempre<br>com<br>refeição leve que contenha gordura.<br>Pode ser dissolvido em água.<br><br>Não pode ser coadministrado<br>com IP sem ritonavir ou com ITRNN<br><br>Cautela se for coadministrado<br>com LPV/r|
|**INIBIDORES DE PR**|**OTEASE (IP)**||||
|**Atazanavir (ATV)**|Recomendado para pacientes de 6 a 18 anos<br>e a partir de 15 kg:<br>15 kg a 20 kg: 150 mg 1 vez/dia<br>20 kg a 40 kg: 200 mg 1 vez/dia<br>A partir de 40 kg: 300 mg, 1 vez/dia.<br>**Sempre associado ao RTV, 100 mg 1**<br>**vez/dia.**|Cápsulas gelatinosa dura 300<br>mg<br>Armazenamento: manter entre<br>15°C-30°C|Reações adversas mais comuns:<br>Náusea,<br>cefaleia,<br>icterícia,<br>exantema<br>e<br>elevação<br>de<br>bilirrubina total<br>**ATV deve ser utilizado com**<br>**reforço de ritonavir (ATV +**<br>**RTV)**|<br>Administrar com alimentos.<br><br>Contraindicado<br>o<br>uso<br>de<br>inibidores de bomba de prótons.<br><br>Fabricante<br>não<br>recomenda<br>abrir cápsula.|
|**Darunavir**<br>**+**<br>**ritonavir (DRV +**<br>**RTV)**|A partir de 3 anos e a partir de 15 kg.<br>Veja posologia recomendada nos Quadros<br>D2 e D3 disponíveis no apêndice.|Comprimidos revestidos de 75<br>mg, 150 mg, 600 mg e 800 mg.<br>Armazenamento:<br>manter entre 15°C-30°C na<br>embalagem original.|Exantema, náusea, cefaleia, rash,<br>sintomas<br>gastrointestinais<br>(náusea,<br>diarreia).<br>Verificar<br>hipersensibilidade<br>às<br>sulfonamidas.|<br>Administrar com alimentos ou<br>após as refeições<br><br>Comprimido<br>de<br>darunavir<br>pode ser macerado.|  
66  
|||**APRESENTAÃO**<br>**E**|**REAÇÕE**|**S**<br>**ADVERSAS**||
|---|---|---|---|---|---|
|**MEDICAMENTO**|**DOSE PADRÃO RECOMENDADA**|**Ç**<br> <br>**CONSERVAÇÃO**|**MAIS**<br>**CONTRA**|**COMUNS**<br>**E**<br>**INDICAÇÕES**|**COMENTÁRIOS**|
||||**DRV dev**<br>**reforço d**<br>**RTV)**|**e ser utilizado com**<br>**e ritonavir (DRV +**||
|**Lopinavir/ ritonavir**<br>**(LPV/r)**|Solução Oral<br>14 dias a 12 meses: 300 mg/m² + ritonavir<br>75 mg/m², 2 vezes/dia.<br>A partir de 1 ano: 230 mg/m² + ritonavir<br>57,5 mg/m², 2 vezes/dia.<br>Comprimidos<br>Acima de 35 kg: 400 mg +  100 mg, 2<br>vezes/dia.|Solução oral 80 mg + 20<br>mg/mL<br>Deve<br>ser<br>conservada<br>sob<br>refrigeração<br>(manter<br>entre<br>2°C-8°C).<br>Comprimido revestido de 100<br>mg + 25 mg. Armazenamento:<br>manter entre 15°C-30°C.|Diarreia,<br>cefaleia.<br>hepática|náusea,<br>vômitos<br>Verificar<br>função|<br>Solução oral: Administrar com<br>alimentos ou após as refeições.<br><br>Comprimidos:<br>pode<br>ser<br>administrado com ou sem alimento.|
|**Ritonavir (RTV)**|Utilizado como “potencializador” (_booster_)<br>dos IPs<br>A partir de 15 kg: 100 mg 2 vezes/dia.,<br>administrado juntamente ao ATV ou DRV.<br>A dose recomendada de ritonavir em<br>crianças acima de 1 mês é de 350 a 400<br>mg/m<sup>2</sup>, baseando-se na Área de Superfície<br>Corporal, duas vezes ao dia, não excedendo<br>a dose de 600 mg (6 comprimidos) duas<br>vezes ao dia(anexo).|Comprimido revestido 100 mg.<br>Armazenamento: manter entre<br>15°C-30°C<br>na<br>embalagem<br>original.<br>Pó para suspensão oral 100 mg.<br>Armazenamento: manter entre<br>15°C-30°C.<br>Após<br>preparo,<br>manter<br>em<br>temperatura<br>ambiente (temperatura entre<br>15°Ce 30°C) por até 2 horas.|Náusea,<br>cutânea (r|diarreia,<br>erupção<br>ash).|<br>Administrar com alimentos.<br><br>Comprimido não pode ser<br>macerado.|
|**INIBIDORES DE INT**|**EGRASE (INI)**|||||
|**Raltegravir (RAL)**|1ª semana: 1,5 mg/kg, 1 vez por dia;<br>A partir da 2ª a 4ª semana: 3 mg/kg/dose, 2<br>vezes por dia.<br>A partir da 4ª semana: 6 mg/kg/dose, 2<br>vezes por dia.|Sachê 100 mg granulado para<br>suspensão<br>oral.<br>Armazenamento:<br>manter entre 15° a 30°C|Alterações<br>aumento<br>náusea|do sono, pancreatite,<br>enzimas<br>hepáticas,|<br>Administrar<br>com<br>ou<br>sem<br>alimentos.<br><br>Não<br>reutilizar<br>conteúdo<br>residual<br><br>Não administrar em criança<br>com idade gestacional ao nascimento<br>menorque 37 semanas|  
67  
|**MEDICAMENTO**|**DOSE PADRÃO RECOMENDADA**|**APRESENTAÇÃO**<br>**E**<br>**CONSERVAÇÃO**|**REAÇÕES**<br>**ADVERSAS**<br>**MAIS**<br>**COMUNS**<br>**E**<br>**CONTRAINDICAÇÕES**|**COMENTÁRIOS**|
|---|---|---|---|---|
|||||<br>Evitar<br>antiácidos<br>contendo<br>cátions polivalentes 4 horas antes ou<br>após a ingestão|
||14 kg a 20 kg: 100 mg, 2 vezes/dia.<br>20 kg a 28 kg: 150 mg, 2 vezes/dia.<br>28 kg a 40 kg: 200 mg, 2 vezes/dia.|Comprimido mastigável 100<br>mg. Armazenamento:<br>manter entre 15° a 30°C.||<br>Administrar<br>com<br>ou<br>sem<br>alimentos<br><br>Comprimido mastigável (100<br>mg) pode serpartido ao meio.|
||A partir de 25 kg: 400 mg, 2 vezes/dia.|Comprimido revestido 400 mg.<br>Armazenamento:<br>manter entre 15° a 30°C.||<br>Administrar<br>com<br>ou<br>sem<br>alimentos|
||3 a 6 kg: 5 mg – 1 comprimido, 1 vez/dia<br>6 a 10 kg: 15 mg – 3 comprimidos, 1<br>vez/dia.<br>10 a 14 kg: 20 mg – 4 comprimidos, 1<br>vez/dia.<br>14 a 20 kg: 25 mg – 5 comprimidos, 1<br>vez/dia.|Comprimido de 5 mg para<br>suspensão oral (dispersível).<br>Armazenamento:<br>manter entre 15°C-30°C.||<br>Administrar<br>com<br>ou<br>sem<br>alimentos<br><br>Não administrar em criança<br>com menos de 4 semanas de vida.<br><br>Não administrar em criança<br>com menos de 3kg de peso corporal.|
|**Dolutegravir (DTG)**|A partir de 6 anos e/ou com peso superior a<br>20 kg: 50 mg, 1 vez/dia.|Comprimido revestido de 50<br>mg. Armazenamento:<br>manter entre 15°C-30°C.|Alteração do sono, cefaleia, rash.|<br>Administrar<br>com<br>ou<br>sem<br>alimentos.<br><br>Evitar<br>antiácidos<br>contendo<br>cátions polivalentes 6 horas antes e 2<br>horas após a ingestão.<br><br>Comprimido<br>pode<br>ser<br>macerado e adicionado a uma pequena<br>quantidade de água, ingestão deve<br>ocorrer imediatamente.|
|**INIBIDORES DE FU**|**SÃO**||||
|**Enfuvirtida (T-20)**|6 a 16 anos: 2 mg/kg/dose, 2 vezes/dia,<br>injetadapor via subcutânea.|Pó para solução injetável 108<br>mg/1,1<br>mL<br>(90<br>mg/mL).|Reações locais são comuns,<br>pneumonia,bacteremia.||  
68  
|||**APRESENTAÇÃO**<br>**E**|**REAÇÕES**<br>**ADVERSAS**||
|---|---|---|---|---|
|**MEDICAMENTO**|**DOSE PADRÃO RECOMENDADA**|<br> <br>**CONSERVAÇÃO**|**MAIS**<br>**COMUNS**<br>**E**<br>**CONTRAINDICAÇÕES**|**COMENTÁRIOS**|
||A partir de 16 anos: 90 mg/kg/dose, 2<br>vezes/dia, injetada por via subcutânea.|Frascos não abertos, manter<br>entre<br>15°C-30°C.<br>Após<br>preparo,<br>conservar<br>sob<br>refrigeração entre 2°C-8°C e<br>utilizar<br>até<br>24<br>horas<br>da<br>preparação.|||
|**ANTAGONISTA DO**|**CCR5**||||
|**Maraviroque**<br>**(MVC)**|Quando usado com inibidores da CYP3A<br>como IP (exceto TPV):<br>10 kg a 20 kg: 50 mg, 2 vezes/dia.<br>20 kg a 30 kg: 75 mg, 2 vezes/dia.<br>30 kg a 40 kg: 100 mg, 2 vezes/dia.<br>A partir de 40 kg: 150 mg, 2 vezes/dia.<br>Quando usado com ITRN:<br>10 kg a 30 kg: não recomendado<br>30 kg a 40 kg: 300 mg, 2 vezes/dia.<br>A partir de 40 kg: 300 mg, 2 vezes/dia.<br>Quando usado com indutores da CYP3A,<br>inclusive efavirenz e etravirina (sem<br>inibidor potente do CYP3A):<br><br>não recomendado|Comprimido revestido de 150<br>mg. Armazenamento: manter<br>entre 15°C-30°C.|Dor abdominal, tosse, vertigem,<br>sintomas<br>musculoesqueléticos,<br>febre<br>exantema,<br>IVAS,<br>hepatotoxicidade e hipotensão<br>ortostática|<br>Administrar<br>com<br>ou<br>sem<br>alimentos|  
Fonte: U.S. DEPARTMENT OF HEALTH & HUMAN SERVICES. Aids Info. Drugs. Disponível em: https://clinicalinfo.hiv.gov/en/drugs; Antiretroviral / HIV Drug Dosing for Children and Adolescents 2020-21 - Imperial College Healthcare NHS Trust. Disponível em: <u>https://www.childrens.health.qld.gov.au/wpcontent/uploads/PDF/ams/2020-BHIVA-dosing-guidelines.pdf;</u> AGÊNCIA NACIONAL DE VIGILÂNCIA SANITÁRIA (ANVISA). Disponível em: <u>https://consultas.anvisa.gov.br/#/bulario/</u> Acesso em: Novembro, 2021  
69

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Apêndice F - CLASSIFICAÇÃO DE MANIFESTAÇÕES CLÍNICAS EM CRIANÇAS COM INFECÇÃO PELO HIV E IDADE MENOR DE 13 ANOS (CRITÉRIO CDC ADAPTADO)** -->
|**Condição**<br>**clínica**|**Mani**|**festações**|
|---|---|---|
||Crian<br>listad|ças com duas ou mais das condições listadas abaixo, mas nenhuma das condições<br>as como condição moderada ou doença definidora de aids:|
|||Infecções de vias aéreas superiores persistentes ou recorrentes;|
|**Leve**|<br>bilate<br>|Linfadenopatia (linfonodos ≥ 0,5cm de diâmetro em mais de uma cadeia, ou<br>ral em uma cadeia);<br>Hepatomegalia;|
|||Esplenomegalia;|
|||Aumento crônico de glândulas parótidas;|
|||Dermatite persistente.|
||Crian<br>defini|ças com sinais ou sintomas diferentes daqueles listados como condição leve ou<br>dora de aids.|
||<br>100.0|Anemia (Hb <8g/dL), neutropenia (< 1.000 células/mm<sup>3</sup>), plaquetopenia (<<br>00/mm<sup>3</sup>) por mais de 30 dias;|
|||Febre persistente por mais de um mês;|
|||Diarreia crônica ou recorrente;|
|||Meningite bacteriana, pneumonia, sepse (único episódio);|
|||Candidíase oral persistente por mais de dois meses;|
|||Miocardiopatia, nefropatia, hepatite;|
|**Moderada**||Infecção por citomegalovírus (do nascimento até o primeiro mês de vida);|
||<br><br>bronq|Herpes zoster (mais de um episódio ou de um dermátomo acometido);<br>Herpes simples: estomatite recorrente (mais de dois episódios em um ano),<br>uite, pneumonia ou esofagite;|
|||Pneumonia linfoide intersticial (LP);|
|||Toxoplasmose (começo até o primeiro mês de vida);|
|||Nocardiose;|
|||Varicela disseminada ou crônica;|
|||Tuberculose pulmonar.|
||Crian|ças com doenças definidoras de imunodeficiência:|
|**Definidora**<br>**de aids**|<br>meni<br>episó<br>|Infecções bacterianas graves, múltiplas ou recorrentes (sepse, pneumonia,<br>ngites, infecções osteoarticulares, abcessos de órgãos internos), pelo menos dois<br>dios em dois anos;<br>Candidíase de esôfago, traqueia, brônquios ou pulmão;|  
70  
|**Condição**<br>**clínica**|**Manifestações**|
|---|---|
||<br>Infecção por citomegalovírus em qualquer outro local que não seja fígado, baço<br>ou linfonodos em maiores de um ano de idade;|
||<br>Coccidioidomicose disseminada ou extrapulmonar;|
||<br>Criptococose extrapulmonar;|
||<br>Diarreia por mais de um mês por_Criptosporidium_ou_Isospora_;|
||<br>Citomegalovirose em outros sítios, além de fígado, baço e linfonodo;|
||<br>Encefalopatia pelo HIV;|
||<br>Úlceras mucocutâneas por herpes simples, persistindo por mais de um mês em<br>crianças com mais de um mês de idade;|
||<br>Herpes simples em brônquios, pulmões ou trato gastrintestinal;|
||<br>Histoplasmose disseminada (que não seja localizada apenas em pulmões e<br>linfonodos cervicais ou hilares);|
||<br>Sarcoma de Kaposi;|
||<br>Linfoma primário do cérebro, linfoma de Burkitt, linfoma imunoblástico,<br>linfoma não Hodgkin de células B;|
||<br>Tuberculose disseminada ou extrapulmonar;|
||<br>Micobacteriose atípica extrapulmonar ou disseminada;|
||<br>Pneumonia por_Pneumocystis jirovecii_;|
||<br>Leucoencefalopatia multifocal progressiva;|
||<br>Síndrome consumptiva (“wasting syndrome”) atribuída ao HIV;|
||<br>Sepse recorrente por bactérias do gênero_Salmonella_(não tifoide)|
||<br>Câncer cervical invasivo (apenas ≥ 6 anos)|  
Fonte: Centers for Disease Control and Prevention. 1994 revised classification system for human immunodeficiency virus infection in children less than 13 years of age. MMWR. 1994;43(No. RR-12). Centers for Disease Control and Prevention: Revised Surveillance Case Definition for HIV Infection— United States, 2014. MMWR. 2014;63(No. RR-3):1-10.  
71

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2: Diagnóstico, manejo e tratamento de crianças e adolescentes vivendo com HIV contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Colaboração externa** -->
O grupo elaborador deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do DATHI. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.  
**3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas**  
A proposta de atualização do PCDT de Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2: Diagnóstico, manejo e tratamento de crianças e adolescentes vivendo com HIV foi apresentada na 108ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 29 de agosto de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 123ª Reunião Ordinária, os quais recomendaram favoravelmente à atualização do texto.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **Consulta pública** -->
A Consulta Pública nº 43/2023, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2: Diagnóstico, Manejo e Tratamento de Crianças Expostas ao HIV, foi realizada entre os dias 09/10/2023 e 30/10/2023. Foram recebidas duas contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2023/contribuicoes-cp-43-pcdt-para-manejo-da-infeccao-pelo-hiv-emcriancas-e-adolescentes-modulo-2 .</u>  
72

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **4. Busca da evidência e recomendações** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2: Diagnóstico, manejo e tratamento de crianças e adolescentes vivendo com HIV contou com a participação do comitê de experts no tratamento da doença. O grupo de especialistas foi composto por representantes da comunidade científica, representante da Sociedade Brasileira de Infectologia, representantes da sociedade civil e especialistas com longa experiência no cuidado e tratamento de pessoas que vivem com HIV e Aids, oriundos de instituições envolvidas com o cuidado às pessoas vivendo com HIV.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao MS para análise prévia às reuniões de escopo e formulação de recomendações.  
Para a atualização das recomendações do novo documento, elaborou-se uma proposta inicial do escopo de atualização do PCDT, que motivou a primeira reunião on-line com o grupo técnico assessor realizada em abril de 2023. Nesta reunião, foram estabelecidos os pontos que demandavam atualização, considerando as novas tecnologias em saúde previamente incorporadas, o cenário epidemiológico e as principais estratégias de enfrentamento à epidemia de Aids.  
Diante do exposto, foram realizadas buscas na literatura científica por revisões sistemáticas, ensaios clínicos randomizados, além de protocolos e diretrizes clínicas internacionais sobre os temas específicos de cada uma das seções. Também foram utilizados os Relatórios de Recomendação referente às novas tecnologias incorporadas, como raltegravir 100 mg granulado e dolutegravir 5 mg, em apresentações mais adequadas ao uso pediátrico.  
Após a análise das evidências científicas, buscou-se identificar as necessidades de atualização do PCDT publicado em 2018, como subsídio para a nova reunião com o grupo de especialistas, que ocorreu em julho de 2023. O levantamento de evidências resultante das buscas na literatura científica, foi utilizado para elaboração da proposta preliminar.  
Previamente, os especialistas receberam a proposta elaborada pela Coordenação-Geral de Vigilância do HIV/Aids e das Hepatites Virais (CGAHV/DATHI/SVSA/MS) e que elencava os pontos chave para atualização do PCDT. Durante o encontro, foi aplicada uma adaptação do método Delphi para obter o consenso dos especialistas para a tomada de decisão sobre as novas recomendações e também em relação àquelas que apresentavam diferenças de parâmetros na literatura.  
Os principais temas atualizados foram:  
Módulo 1:  
1. Inclusão do capítulo sobre 'Diagnóstico da infecção pelo HIV em menores de 18 meses': fluxo de diagnóstico com DNA pró-viral e atualização do ponto de corte da carga viral (CV-HIV).  
2. Inclusão do medicamento raltegravir 100 mg granulado para profilaxia da transmissão vertical ao HIV em crianças com alto risco de exposição ao HIV conforme relatório técnico de recomendação da Conitec nº 831/2023.  
3. Inclusão de capítulo novo sobre ‘Manejo de crianças expostas e não infectadas’.  
- Módulo 2:  
1. Inclusão de nova formulação de ARV da classe de inibidores da integrase: dolutegravir 5 mg comprimidos dispersíveis, para tratamento do HIV e prevenção em crianças com HIV de 2 meses a 6 anos de idade em conforme relatório técnico de recomendação da Conitec nº 830/2023.  
2. Inclusão de capítulos novos sobre ‘Transição do Cuidado de Pediatria para Atenção de Adultos’; ‘Prevenção combinada e Profilaxias Pré e Pós-exposição ao HIV (PrEP e PEP-HIV)’.  
73  
Após a reunião, as decisões foram incorporadas ao texto do documento final, o qual foi compartilhado com o grupo de especialistas para a definição da versão final, sendo que as sugestões adicionais foram consolidadas pela equipe da CGAHV/DATHI/SVSA/MS.  
Na sequência, a minuta de texto atualizado foi apresentada à Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS) e, após revisão, foi avaliada pela Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas  
74

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2 | secao: **APÊNDICE 2- HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**<br>**da diretriz clínica**|**Prinii ltrõ**|**Tecnologias avaliadas**<br>|**pela Conitec**<br>|
|---|---|---|---|
|**(Conitec) ou Portaria**<br>**de Publicação**|**cpas aeaçes**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatórios de<br>Recomendação nº<br>830/2023 e 831/2023.|Desmembramento do<br>texto em módulos;<br>Atualização do texto do<br>documento e inclusão de<br>orientações referentes às<br>tecnologias<br>incorporadas<br>Inclusão de informações<br>sobre  a transição do<br>cuidado em pediatria<br>para a atenção<br>assistencial de adultos.|Raltegravir 100 mg granulado para<br>profilaxia da transmissão vertical do<br>HIV em crianças com alto risco de<br>exposição ao HIV. [Relatório de<br>Recomendação nº 831/2023; Portaria<br>SECTICS/MS nº 38/2023]<br>Dolutegravir 5 mg como tratamento<br>complementar ou substitutivo em<br>crianças de 2 meses a 6 anos de idade<br>com HIV. [Relatório de Recomendação<br>nº 830/2023; Portaria SECTICS/MS nº<br>36/2023]|-|
|Relatório de<br>Recomendação nº 283;<br>Portaria SCTIE/MS nº<br>31, de 01/09/2017|Primeira versão do<br>documento|-|-|  
75

---

