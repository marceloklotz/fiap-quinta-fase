<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS -->
PORTARIA CONJUNTA Nº 18, DE 20 DE NOVEMBRO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Hemoglobinúria Paroxística Noturna.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE - SUBSTITUTA e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a hemoglobinúria paroxística noturna no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação ~~n~~<sup><u>o</u></sup> 401/2018, 471/2019, 480/2019, 482/2019 e 484/2019 e os relatórios de recomendação ~~n~~<sup><u>o</u></sup> 413 – Dezembro de 2018, 482 – Setembro de 2019, 490 – Outubro de 2019 e 491 – Outubro de 2019, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Hemoglobinúria Paroxística Noturna. Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da hemoglobinúria paroxística noturna, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da hemoglobinúria paroxística noturna.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: DENIZAR VIANNA -->
1  
ANEXO

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS -->
HEMOGLOBINÚRIA PAROXÍSTICA NOTURNA

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **1 – INTRODUÇÃO** -->
A Hemoglobinúria Paroxística Noturna (HPN) é uma doença rara, com incidência anual estimada de 1,3 novos casos por um milhão de indivíduos. Há pouca informação epidemiológica sobre esta doença, não apenas por sua raridade, mas também pela dificuldade de seu diagnóstico. A HPN clínica pode ocorrer em qualquer idade, mas a maioria dos pacientes é diagnosticada entre a terceira e a quinta décadas de vida. Afeta homens e mulheres na mesma proporção, sem relação hereditária comprovada<sup>(1-5)</sup> .  
A HPN é causada por um defeito genético adquirido no gene da fosfatidilinositolglicana classe-A ( _phosphatidylinositol glycan-class_ A, PIG-A), localizado no braço curto do cromossomo X das células-tronco hematopoéticas (6,7). Essas mutações são responsáveis pelo bloqueio precoce da síntese do fosfolipídio glicosilfosfatidilinositol ( _glycosylphosphatidylinositol_ – GPI), responsável pela ancoragem de proteínas à membrana plasmática<sup>(8)</sup> . Na sua diminuição ou ausência, múltiplas proteínas não se expressam na superfície celular, entre essas se encontram as proteínas reguladoras do Sistema de Complemento (SC), como o CD55 e CD59. A deficiência de GPI e da expressão de proteínas ancoradas à membrana plasmática determina a fisiopatologia e as manifestações clínicas da HPN (7).  
O SC está constituído por um conjunto de proteínas séricas que interagem umas com as outras e é ativado por três vias principais: a clássica, a alternativa e a da lectina. Essas vias atuam com modelos de cascatas distintas e resultam na ativação das convertases de C3 e C5. A partir da ativação da convertase de C5, o SC atua da mesma maneira – via lítica - por meio da sua reação final, a ativação do complexo de ataque à membrana (CAM). A proteína CD55 inibe a formação e a estabilidade da convertase de C3, tanto na via clássica e na via da lectina - C4b2a, quanto na via alternativa - C3bBb. Na via alternativa, o CD55 - também chamado de _decay accelerating factor_ (DAF) - impede a formação de C3b adicional, seja pelo bloqueio da associação do fator B com C3b, impedindo a formação da convertase de C3 adicional, seja pela dissociação de Bb de C3b na convertase de C3 que foi formada, interrompendo também, dessa maneira, a produção de C3b adicional, o que realimentaria o processo. O CD59 - _membrane inhibitor of reactive lysis_ (MIRL) - é uma glicoproteína que atua diretamente sobre o CAM, impedindo a agregação de C9 e a consequente formação do poro lítico<sup>(9)</sup> . A ausência de CD59 torna os eritrócitos susceptíveis à lise intermediada pelo CAM, explicando a manifestação clínica primária da doença: a hemólise intravascular crônica, com exacerbações. A hemólise crônica na HPN é ocasionada pela ativação de baixo grau, espontânea e contínua do C3, que ocorre na via alternativa. A CD59 é a proteína mais importante na proteção da lise celular, porque atua diretamente na fase final da via lítica. Ademais, existem formas de HPN com deficiência congênita de CD55 isolada, mas com expressão normal de CD59, que não hemolisam<sup>(10,11,7)</sup> .  
Em pacientes com clones maiores de HPN, há indícios de que a hemólise contribua para os episódios tromboembólicos, devido a uma correlação temporal entre os surtos hemolíticos e a maior incidência de tromboembolismo. Embora o mecanismo não esteja completamente elucidado, a hemólise pode estar envolvida na  
2  
ativação e agregação plaquetária. Alguns estudos _in vitro_ sugerem ainda que a via lítica possa ativar diretamente as plaquetas de pacientes com HPN. O receptor do ativador de plasminogênio tipo uroquinase (u-PAR) e o inibidor da via do fator tecidual, que dependem da âncora GPI para ligação com a membrana citoplasmática também estão envolvidos no aumento do risco de trombose devido ao estímulo ao processo trombótico e redução da fibrinólise<sup>(11, 10)</sup> .  
O óxido nítrico (NO) é um relevante regulador da fisiologia vascular e é produzido normalmente pela ação da sintetase endotelial do óxido nítrico, utilizando o oxigênio e a arginina na sua formação. O NO tem como ação a manutenção do tônus muscular e o controle da ativação plaquetária. Na HPN, grandes quantidades de hemoglobina livre, que possui enorme afinidade pelo NO, e arginase são liberadas na circulação pela hemólise de eritrócitos. Assim, a depleção do NO tecidual é causada pela sua retirada de circulação pela hemoglobina livre e também pela diminuição da arginina, que é um substrato para a sua síntese. A depleção do NO se manifesta clinicamente como astenia, dor abdominal, espasmo esofagiano, disfagia, impotência sexual masculina e possivelmente trombose<sup>(12, 10, 11)</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da hemoglobinúria paroxística noturna, e sua elaboração seguiu as recomendações do Ministério da Saúde contidas em suas Diretrizes Metodológicas Elaboração de Diretrizes Clínicas<sup>13</sup> . Adotando a metodologia preconizada pelo manual de revisões sistemáticas do Ministério da Saúde<sup>(14)</sup> , foram realizadas duas novas revisões sistemáticas: segurança do uso de eculizumabe em gestantes com HPN e segurança do uso de eculizumabe para lactentes com HPN. Além disso, foi atualizada uma revisão sistemática sobre a eficácia, efetividade e segurança do eculizumabe em pacientes com HPN<sup>(15)</sup> . Para a avaliação da qualidade da evidência disponível na literatura, foi utilizado o sistema GRADE ( _Grading of Recommendations, Assessment, Development and Evaluation_ ), que classifica a qualidade da evidência ou o grau de certeza desta em quatro categorias (muito baixo, baixo, moderado e alto)<sup>(16)</sup> . Foram desenvolvidas tabelas com a sumarização das evidências na plataforma GRADEpro<sup>(17)</sup> . A partir disso, foram elaboradas as recomendações, a favor ou contra, para cada intervenção. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 3** .

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **2 – CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- D59.5   Hemoglobinúria Paroxística Noturna (Marchiafava-Micheli).

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **3 – CRITÉRIOS DE INCLUSÃO** -->
Estão contemplados neste Protocolo Clínico e Diretrizes Terapêuticas (PCDT) indivíduos maiores de 14 anos, de ambos os sexos, com diagnóstico de HPN realizado por citometria de fluxo.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **3.1 Critérios de Inclusão para o tratamento com eculizumabe** -->
O paciente elegível ao tratamento com eculizumabe deverá ter HPN na sua apresentação hemolítica e comprovação de alta atividade da doença – definida como lactato desidrogrenase (LDH) ≥ 1,5 vez o limite superior e tamanho do clone > 10%, além de pelo menos um dos critérios abaixo:  
3  
- Histórico de evento tromboembólico com necessidade de anticoagulação terapêutica (comprovado por exame de imagem), após afastadas outras causas de trombofilia adquiridas mais comuns, como síndrome de anticorpo antifosfolípide (SAAF) e neoplasia;  
- Anemia crônica demonstrada por mais de uma medida de hemoglobina ≤ 7 mg/dL ou por mais de uma medida de  
- hemoglobina ≤ 10 mg/dL com sintomas concomitantes de anemia, em que outras causas além da HPN foram excluídas;  
- Hipertensão arterial pulmonar, evidenciada por ecocardiograma com PSAP > 35, em que outras causas além da HPN  
- foram excluídas;  
- História de insuficiência renal, demonstrada por uma taxa de filtração glomerular ≤60 mL/min/1,73 m<sup>2</sup> , em que  
- outras causas além da HPN foram excluídas; ou  
- Gestação, evidenciada por beta-HCG > 6 mUI/mL, com história prévia de intercorrência gestacional.  
- **3.2 – Critérios de Inclusão para o transplante alogênico de células-tronco hematopoéticas**<sup>(18-25)</sup> :  
- Serão elegíveis para o transplante de células-tronco hematopoéticas (TCTH) alogênico (TCTH-AL) aparentado  
- (TCTH-AL-AP) ou não aparentado (TCTH-AL-NAP):  
**-** Os pacientes com diagnóstico de HPN e com fatores de risco para pior evolução da doença e morte, como nos casos de insuficiência da medula óssea com citopenias graves, evolução para mielodisplasia ou leucemia aguda, necessidade de tratamento(s) adicional(ais) ao eculizumabe, marcada necessidade de hemotransfusões ou desenvolvimento de anemia aplástica grave;  
- com doador de células-tronco hematopoéticas (CTH) identificado;  
- em condições clínicas para o transplante; **e**  
**-** em idade compatível com o TCTH-AL, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
O tipo (aparentado ou não aparentado) e subtipo (mieloablativo ou não mieloablativo) do TCTH dependerão da idade e das condições clínicas do paciente, cabendo à equipe transplantadora defini-los.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **4.1 Critérios de Exclusão para o tratamento com eculizumabe** -->
- Pacientes com diagnóstico de HPN subclínica; **ou**  
- Pacientes com diagnóstico de HPN concomitante a síndrome de falência medular grave ativa (anemia aplástica com  
- dois ou mais dos seguintes marcadores: contagem de neutrófilos abaixo de 0,5x10<sup>9</sup> /L, contagem de plaquetas abaixo de 20 x 10<sup>9</sup> /L, reticulócitos abaixo de 25 x 10<sup>9</sup> /L).  
- **4.2 Critérios de Exclusão para o transplante alogênico de células-tronco hematopoéticas**<sup>(18-25)</sup> :  
- Pacientes com diagnóstico de HPN sem condições clínicas para o TCTH-AL;  
4  
**-** Pacientes em idade incompatível para o TCTH-AL, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas as respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS; **ou**  
**-** Pacientes sem doador de células-tronco hematopéticas (CTH) identificado.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **5 – DIAGNÓSTICO DA HPN** -->
A apresentação clínica da HPN é extremamente variável, razão pela qual é conhecida como “a maior imitadora”. Todos os doentes com anemia hemolítica crônica adquirida e teste de Coombs negativo devem ser investigados quanto ao diagnóstico de HPN.<sup>(24)</sup>

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **5.1. Suspeita e condutas diagnósticas iniciais** -->
As causas mais comuns de anemias hemolíticas e tromboembolismos devem ser investigadas inicialmente, visto a baixa incidência de HPN. Na **Figura 1** , encontra-se o fluxograma de diagnóstico de HPN a partir da suspeita clínica inicial.  
Existem grupos com sintomas e sinais clínicos específicos que possuem maior probabilidade de ter HPN, sendo eles<sup>(26, 27, 28)</sup> :  
1) Pacientes com Coombs negativo e marcadores laboratoriais de hemólise, como lactato desidrogenase (LDH) elevada, reticulocitose ou outros marcadores de hemólise, pacientes com hemoglobinúria quando causas mais comuns de anemia hemolíticas e hemólises foram excluídas.  
2) Todos os pacientes com anemia aplástica ou síndrome mielodisplásica hipoplásica com evidência de  
hemólise.  
3) Pacientes com trombose em locais incomuns (como, por exemplo: cérebro, portal-hepático e veias dérmicas), em que outras causas mais comuns de tromboembolismos (hereditárias ou adquiridas) foram excluídas, especialmente quando há evidência simultânea de hemólise; ou quando os pacientes apresentam manifestações clínicas da HPN (dor abdominal, dor torácica, dispneia, disfagia, fadiga grave).  
4) Pacientes com trombose que apresentam citopenia, esta última determinada por valores de hemoglobina, contagem global de leucócitos ou contagem de plaquetas abaixo do limite inferior de referência - quando outras causas mais comuns de tromboembolismo foram excluídas.  
5) Pacientes menores de 55 anos com trombose, nos quais outras causas mais comuns de tromboembolismos foram excluídas.  
6) Pacientes em algum estágio de doença renal crônica ou com proteinúria, em que outras causas mais comuns foram excluídas.  
Para todos os pacientes com suspeita de HPN é importante realizar o teste direto de antiglobulina (teste de Coombs direto), cujo resultado será negativo em caso de HPN. Mesmo havendo a possibilidade de ser realizado concomitantemente a outros exames laboratoriais, o teste de Coombs direto está destacado na **Figura 1** , dada a sua importância no diagnóstico de HPN.  
5  
<!-- Start of picture text -->
Suspeita clinica<br>Causas adquiridas Nio Investigar anemias hemoliticas hereditérias: anemia<br>ousabidamentendo‘congénitas -»-® faleiforme,glicose-6-fosfato talassemias,desidrogenaseesferocitose (G6PD), entrehereditaria, deficiéncia outras, de<br>Sim |<br>Leet Positive Investigar anemias hemoliticas autoimunes ou reagdes<br>(aneaee) ‘ransfusionais tardias.<br>Negativo |<br>Realzarcitometria _\ Negativo Investigar doenca de Wilson (degeneracio<br>de fluxo para HPN hepatolenticular) ou infecgdes/toxinas microbianas.<br>Positivo |<br>Hemoglobincria<br>paroxistica noturna<br><!-- End of picture text -->  
**Figura 1-** Fluxograma de diagnóstico da Hemoglobinúria Paroxística Noturna Fonte: Barcellini & Fattizzo (2015) adaptado e Costa, Fertrin e Conran (2013)<sup>(29,30)</sup>

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **5.2. Citometria de fluxo** -->
A citometria de fluxo (CF) é o método utilizado para avaliar a redução de GPI na superfície das células<sup>(26, 27)</sup> . A CF de amostra de sangue periférico contribui para a determinação da ausência ou deficiência de proteínas ancoradas à GPI em células sanguíneas, após a marcação com anticorpos monoclonais com um emissor de fluorescência. Após a marcação, a emissão de cor é detectada por sensores do citômetro, tornando possível a classificação das células pela granulosidade/tamanho e pela expressão das proteínas de interesse<sup>(31)</sup> .  
A CF deve ser realizada em pelo menos duas variedades de células sanguíneas, principalmente neutrófilos e monócitos. O exame pode ser feito em células da linhagem vermelha (hemácias ou eritrócitos) nos casos em que não foi possível determinar a presença dos marcadores utilizando a linhagem branca. O tamanho do clone de HPN nas células eritrocitárias é tipicamente menor em pacientes que não trataram a hemólise ou não foram transfundidos<sup>(26, 27, 32)</sup> .

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **6 - CLASSIFICAÇÃO DA HPN** -->
6  
A HPN pode ser classificada em três subtipos<sup>(28)</sup> ( **Quadro 1** ). Apesar de essa classificação contribuir para a conduta terapêutica dos pacientes, todos os três grupos apresentam algum grau de falência medular, e a classificação de um paciente pode mudar com o tempo e, por isso, os parâmetros devem ser acompanhados continuamente.  
**Quadro 1 -** Classificação segundo a manifestação clínica da hemoglobinúria paroxística  
||**HPN Clássica**|**HPN associada a outros distúrbios**<br>**primários da medula óssea**|**HPN subclínica**|
|---|---|---|---|
|●|Evidência de clones HPN na<br>ausência de outro distúrbio de<br>falha da medula óssea.|●<br>Comumente associada à anemia<br>aplástica e mielodisplasia.<br>●<br>Pessoas com anemia aplástica podem|●<br>Pacientes<br>com<br>poucos<br>clones<br>de<br>HPN e sem evidência|
|●|Comumente<br>apresenta-se<br>grande número de clones de<br>leucócitos no momento do<br>diagnóstico.|ter pequenas populações subclínicas<br>de HPN por muitos anos, mas a<br>expansão de clones frequentemente<br>ocorre na fase de recaída da doença.<br>|clínica<br>ou<br>laboratorial<br>de<br>hemólise<br>ou<br>de<br>trombose.|
|●|Geralmente<br>manifesta<br>hemólise intensa, evidenciada<br>por alta LDH e presença de<br>reticulócitos no plasma.|●<br>É importante monitorar o percentual<br>de clones nessa população, visto que<br>o mesmo pode permanecer estável,<br>aumentar, reduzir ou desaparecer.||
|●|Tende a ter uma contagem de<br>plaquetas<br>e<br>neutrófilos<br>próximos<br>dos<br>níveis<br>fisiológicos e níveis normais<br>de células na medula óssea.|●<br>Pacientes com anemia aplástica e<br>HPN são citopênicos, tendem a ter<br>medula óssea hipocelular, contagem<br>de reticulócitos relativamente baixa e<br>menor número de granulócitos HPN.||  
Fonte: DEZERN; BOROWITZ, 2018; HILL _et al.,_ 2017.<sup>(28,31)</sup>  
Além da classificação da doença por manifestação clínica, as hemácias podem ser classificadas pelo grau de ausência de proteínas ancoradas ao GPI na membrana citoplasmática – células HPN dos tipos I, II ou III. As células do tipo I têm níveis fisiológicos de GPI, enquanto as do tipo II têm níveis reduzidos; no tipo III há ausência completa da proteína<sup>(11)</sup> . Os eritrócitos do tipo II apresentam uma sensibilidade modesta (3 a 5 vezes o valor normal) à lise pelo complemento, enquanto que os do tipo III são pronunciadamente mais sensíveis à lise mediada pelo complemento (15 a 25 vezes a normal)<sup>(28)</sup> . Em geral, o grau de hemólise na HPN se relaciona com a proporção de clones HPN e com o tipo de célula HPN<sup>(10)</sup> .

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **7 - TRATAMENTO** -->
O único tratamento curativo da HPN ainda é o TCTH-AL.  
Fora o transplante, o tratamento da HPN é principalmente sintomático, com o uso de medidas medicamentosas e não medicamentosas. Essas intervenções objetivam, principalmente, reduzir a hemólise intravascular e prevenir e tratar episódios tromboembólicos e outras complicações associadas.  
O tratamento é instituído de acordo com as manifestações clínicas da doença, e há várias alternativas terapêuticas da HPN, que não curativas, mas que podem reduzir as suas complicações: corticoides, androgênios, transfusão sanguínea, imunossupressores (globulina antilinfocitária e ciclosporina), anticoagulantes e eculizumabe.<sup>(18, 22,</sup> 24)  
7  
Transfusão de hemocomponentes e reposição de ácido fólico e ferro são frequentemente necessárias, embora a reposição aguda de ferro possa resultar em aumento da hemólise devido à formação e liberação de uma novo clone de eritrócitos sensíveis.<sup>(18,24)</sup>  
O uso de anticoncepcional oral deve ser evitado devido ao aumento do risco de trombose.<sup>(18)</sup>  
O tratamento da HPN encontra-se resumido na **Figura 2** .  
<!-- Start of picture text -->
Paciente com HPN hemolitica com alta atividade*<br>Iniciar tratamento com Eculizumabe<br>Paciente apresentou<br>hemidlise e/ou trombose?<br>Nao sim<br>Manter Eculizumabe. e Manter;  Eculizumabe<br>acompanhamento periédicowae e introduzirde suportetratamento<br>Investigar e tratar outras causas<br>de manutencao da doenca ativa.<br>Paciente ainda sintomatico?<br>Nao sim<br>Manter Eculizumabe. e InterromperpeabaieEculizumabe e Interromperie Eculizumabe| e<br>ee ener investigar outras causas Considerar Transplante<br>Cea associadas a HPN de Medula Ossea<br>* LDH 2 1,5 vezes o limite superior<br><!-- End of picture text -->  
**Figura 2** – Fluxograma de tratamento da hemoglobinúria paroxística noturna

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Transfusão Sanguínea** -->
O tratamento não medicamentoso mais usado é a transfusão de sangue que, além de aumentar a concentração de hemoglobina, pode reduzir a hemólise, a partir da supressão da eritropoese normal e clonal. As transfusões de hemocomponentes nunca foram tão seguras como na atualidade. Embora o ideal seja restringir as transfusões ao mínimo possível<sup>(2)</sup> , cerca de 50% doentes de HPN sob o uso de eculizumabe ainda necessitam de hemotransfusões<sup>(25)</sup> .  
8  
**Transplante de Células-Tronco Hematopoéticas**<sup>(2, 9, 10, 18-25, 33, 34)</sup> .  
O transplante de células-tronco hematopoéticas alogênico (TCTH-AL) ainda é o único tratamento curativo da HPN, embora esteja associado à alta morbimortalidade. Atualmente, ele é indicado nos casos com fatores de risco para pior evolução da doença e morte, especialmente falência da medula óssea com citopenias graves, evolução para mielodisplasia ou leucemia aguda, necessidade de tratamento adicional ao eculizumabe, marcada necessidade de hemotransfusões ou desenvolvimento de anemia aplástica grave. Dado o curso imprevisível da HPN, incluindo a possibilidade de sua remissão espontânea, a indicação de TCTH-AL deve ser muito bem avaliada. Entretanto, alguns autores consideram o TCTH-AL o primeiro tratamento de crianças e adolescentes com HPN e anemia aplástica, considerando-se que pacientes mais jovens apresentam melhor resposta a este tratamento.  
Os pacientes candidatos ao TCTH-AL poderão ser submetidos a transplante com uso de condicionamentos mieloablativos ou não mieloablativos, conforme a avaliação da equipe transplantadora. Caso não haja um doador aparentado, mesmo que haploidêntico, procura-se por um não aparentado compatível.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **7.2 - Tratamento medicamentoso** -->
O objetivo do uso dos medicamentos é a melhora clínica, a atenuação da anemia, a prevenção dos episódios tromboembólicos, o aumento da qualidade de vida e a redução da necessidade transfusional, podendo ser utilizados de forma combinada, quando apropriado.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Anticorpos monoclonais** -->
<mark>O eculizumabe é um anticorpo monoclonal inibidor do complemento terminal que se liga de forma específica à proteína C5 do complemento com alta afinidade, inibindo, deste modo, a sua clivagem em C5a e C5b e impedindo a geração do complexo de ataque da membrana (C5b-9). O eculizumabe preserva os componentes iniciais da ativação do complemento que são essenciais para a</mark> opsonização dos microrganismos e para a remoção dos complexos imunes. Em pacientes com HPN, a ativação não controlada do complemento terminal e a consequente hemólise intravascular mediada pelo complemento são bloqueadas com o tratamento com eculizumabe. Na maioria dos pacientes com HPN, concentrações séricas de eculizumabe correspondentes a aproximadamente 35 μg/mL são suficientes para a inibição completa da hemólise intravascular mediada pelo complemento terminal. Em casos dessa doença, a administração crônica de eculizumabe resultou em redução rápida e sustentada da atividade hemolítica mediada pelo complemento<sup>(35)</sup> .  
<mark>O eculizumabe é eficaz no tratamento paliativo de pacientes com HPN clássica, com a redução da hemólise intravascular e com a redução ou eliminação da necessidade das transfusões sanguíneas na maioria dos pacientes, repercutindo na sobrevida do paciente, na sua qualidade de vida, no risco de trombose e nas complicações relacionadas à doença, tais como hipertensão pulmonar, insuficiência cardíaca e insuficência renal.</mark>  
7.2.2.Tratamento adjuvante ao uso do eculizumabe em caso de complicações  
9

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Suplementação de ácido fólico e ferro** -->
<mark>Em função da hemoglobinúria e hemossiderinúria derivadas da HPN, os pacientes frequentemente apresentam deficiência de ferro e, por isso, sua reposição é recomendada. No entanto, há evidência de associação entre essa reposição e a exacerbação da hemólise e sua administração deve ser realizada sob vigilância. A suplementação de folato também deve ser co</mark> nsiderada, uma vez que a hemólise aumenta a eritropoese e, consequentemente, o consumo da vitamina B9 (ácido fólico).<sup>(2, 24, 36, 37)</sup> .

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Anticoagulantes** -->
Como a trombofilia é a principal causa de mortalidade na HPN, sua prevenção e tratamento devem ser levados em consideração ao se definir a conduta terapêutica. Estudos indicam que em pacientes com mais de 50% de clones HPN deficientes em GPI, o risco de trombose é quase 40% maior do que em pacientes com menos de 50%. Assim, para os pacientes com mais de 50% clones HPN, recomenda-se a tromboprofilaxia a critério do médico assistente, desde que não haja outras contraindicações<sup>(24, 38-40)</sup> . O papel dos inibidores plaquetários na profilaxia ainda não foi definido, bem como dos novos inibidores da trombina orais<sup>(9)</sup> .  
<mark>Ao se indicar a anticoagulação do paciente, deve-se levar em consideração a trombocitopenia, que é frequente na HPN. A trombocitopenia é uma contraindicação relativa, mas não absoluta, à anticoagulação; e é preferível proceder a transfusões para manter a contagem de plaquetas em um limiar seguro, em vez de suspender a terapia anticoagulante. Os pacientes com HPN que experimentam um</mark> evento tromboembólico devem ser anticoagulados indefinidamente<sup>(2, 24, 41,</sup> 42).

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Fármaco** -->
**-** Eculizumabe: 10 mg/mL solução injetável (frasco com 30 mL).

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Pososlogia e Esquema de Administração** -->
O eculizumabe deve ser administrado em centros de referência, por profissionais da saúde qualificados e sob supervisão de um médico com experiência no tratamento de pacientes com doenças de origem hematopoética ou doenças renais. Um frasco para injetáveis com 30 mL contém 300 mg de eculizumabe (10 mg/mL). Após diluição, a concentração final da solução para infusão é de 5 mg/mL. Os diluentes utilizados são solução injetável de cloreto de sódio 9 mg/mL (0,9%), solução injetável de cloreto de sódio 4,5 mg/mL (0,45%) ou dextrose a 5% em água.  
O esquema posológico consiste numa fase inicial com duração de quatro semanas, seguida por uma fase de manutenção:  
- Fase inicial: 600 mg de eculizumabe administrados por infusão intravenosa durante 25 a 45 minutos, uma vez por semana nas primeiras quatro semanas.  
- Fase de manutenção: 900 mg de eculizumabe administrado por infusão intravenosa durante de 25 a 45 minutos na quinta semana e a cada duas semanas.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Profilaxia** -->
10  
Antes do início da terapia medicamentosa, o paciente deve ser vacinado contra _Neisseria meningitidis_ , pois a inibição do complemento em C5 aumenta o risco de desenvolver infecções com organismos encapsulados. A vacinação meningocócica conjugada tetravalente (sorotipos ACWY) deve ser procedida no mínimo duas semanas antes de iniciar o tratamento com eculizumabe. A cada 5 anos deve ser realizado o reforço de dose desta vacina.  
Caso o uso do eculizumabe ocorra antes da vacinação, profilaxia antibiótica deverá ser iniciada, até pelo menos 2 semanas após vacinação. Durante o tratamento também deve-se proceder à profilaxia com antibiótico. A manutenção da antibioticoprofilaxia deve ser avaliada pelo médico assistente a fim de garantir o uso racional dos medicamentos, assim como promover a prevenção e controle da resistência aos antimicrobianos.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Eventos adversos do uso de eculizumabe** -->
1. Muito frequentes (podem afetar mais de 1 em 10 pessoas): dores de cabeça.  
2. Frequentes (podem afetar até 1 em 10 pessoas):  
a) infecção grave (sepse meningocócica), bronquite, infecção por fungos (infecção por Aspergillus), infecção nas articulações (artrite bacteriana), nasofaringite, lesões de pele (herpes simplex), infecção do trato urinário, infecção viral;  
- b) trombocitopenia, (leucopenia, hemólise, hipotensão arterial;  
- c) reação alérgica grave (reação anafilática);  
- d) perda de apetite;  
- e) tonturas, alterações do paladar (disgeusia);  
- f) infecção do trato respiratório superior, tosse, nariz entupido (congestão nasal), irritação ou dor na garganta  
(dor faringolaríngea), corrimento nasal (rinorreia), dispneia (dificuldade em respirar);  
- g) diarreia, vômitos, náusea, dor abdominal, prisão de ventre, desconforto no estômago após as refeições  
- (dispepsia);  
- h) erupção na pele, perda de cabelo (alopecia), pele com comichão (prurido);  
- i) dor nos membros ou articulações (braços e pernas), dores musculares, cãibras musculares, dor nas costas e de  
pescoço;  
- j) inchaço (edema), desconforto no peito, febre (pirexia), arrepios, sensação de cansaço (fadiga), sensação de  
- fraqueza (astenia), sintomas do tipo gripal.  
3. Pouco frequentes (podem afetar até 1 em 100 pessoas):  
- a) sepse, choque séptico, infecção nas meninges (meningite meningocócica), infecção nos pulmões (pneumonia),  
- gastroenterite (infecção gastrointestinal), cistite, infecção do trato respiratório inferior;  
- b) infecção fúngica, abscesso bacteriano, celulite (infecção), gripe, infecção das gengivas, sinusite, infecção nos  
- dentes, impetigo;  
- c) tumor de pele (melanoma), alterações da medula óssea;  
- d) distúrbio da coagulação, aglutinação de células, fator de coagulação anormal, anemia (pele pálida, fraqueza e  
- falta de ar), linfopenia e palpitações;  
- e) hipersensibilidade;  
- f) hipertiroidismo (Doença de Basedow-Graves);  
- g) anorexia (apetite reduzido);  
- h) depressão, ansiedade, insônia, alterações do sono, pesadelos, alterações bruscas de humor;  
11  
i) desmaio, tremores, formigamento em parte do corpo (parestesia);  
j) visão desfocada, irritação dos olhos;  
- k) zumbido nos ouvidos, vertigens;  
- l) hipertensão arterial, desenvolvimento súbito e rápido de pressão arterial extremamente elevada, equimose  
(manchas escuras na pele), fogacho (calores), alterações nas veias;  
- m) hemorragia nasal;  
- n) peritonite, refluxo dos alimentos do estômago, dor nas gengivas, distensão abdominal;  
- o) icterícia, pele amarelada;  
- p) urticária, inflamação da pele, vermelhidão da pele, pele seca, púrpura,  alterações da cor da pele, transpiração  
aumentada;  
- q) espasmo do músculo da boca, inchaço das articulações;  
- r) alterações renais, hematúria, disúria,  alterações menstruais, ereção espontânea;  
- s) dor no peito, dor no local da infusão, extravasamento do medicamento administrado para fora da veia, sensação  
de calor;  
- t) aumento das enzimas do fígado, hiperviscosidade sanguínea, anemia hipocrômica;  
- u) reação relacionada com a infusão.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Critérios de interrupção do eculizumabe** -->
O tempo de tratamento não pode ser pré-determinado, devendo ser mantido enquanto indicado e dele o doente se beneficie.  
A interrupção do medicamento deve-se dar nas seguintes situações:  
1. Ausência do benefício clínico associado ao tratamento, evidenciado por pelo menos um dos seguintes:  
- a) Necessidade de transfusão nos primeiros seis meses após a primeira dose do medicamento;  
- b) Necessidade de mais do que três transfusões em um ano<sup>(28)</sup> ;  
- c) Hemólise, evidenciada por LDH > 1,5 vezes o limite superior de referência 3 meses a partir da primeira dose  
do medicamento; ou;  
d) Ocorrência de evento tromboembólico 3 meses a partir da primeira dose do medicamento.  
2. Remissão espontânea da HPN, medida por citometria de fluxo, mantendo-se o acompanhamento para avaliar o comportamento do clone com o passar do tempo. [Nota: A remissão espontânea da HPN é definida como uma população indetectável de clones HPN, em pelo menos duas linhagens celulares, associada a cessação de hemólise intravascular e outras manifestações clínicas.]  
3. Desenvolvimento de síndrome de falência medular grave. Nesses casos, e na ausência de doador para transplante de células-tronco hematopoéticas alogênico (TCTH-AL), recomenda-se o tratamento da mielodisplasia ou da aplasia medular com citopenias graves para, posteriormente, reavaliar a indicação do eculizumabe.  
4. Pacientes que apresentem hipersensibilidade ou reação adversa grave ao eculizumabe.  
5. Pacientes com idade igual ou maior que 18 anos e que, após devidamente informados sobre os riscos e benefícios  
de sua adesão, optarem por não mais se submeterem ao tratamento.  
Os critérios de interrupção devem ser apresentados, de forma clara, aos pacientes, pais ou responsáveis legais.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Casos Especiais** -->
12  
<mark>Os pacientes que já se encontrarem em tratamento quando da publicação deste PCDT deverão ser reavaliados quanto aos critérios de inclusão e exclusão, a fim de ser decidida a suspensão ou a manutenção do tratamento.</mark> <u><mark>[Nota: O</mark></u> paciente que já faz uso do eculizumabe deverá apresentar a documentação que comprove a condição clínica anterior ao uso do medicamento, incluindo o laudo diagnóstico por citometria de fluxo e relatório médico com exames complementares que comprovem a alteração do quadro clínico do paciente em pelo menos um dos parâmetros descritos no critério de inclusão (histórico de trombose, anemia crônica, hipertensão arterial pulmonar ou história de insuficiência renal).]  
Uma vez que a HPN aumenta o risco de complicações durante a gestação, mulheres em idade fértil devem adotar métodos contraceptivos não hormonais. A indicação do tratamento de gestantes com eculizumabe é de responsabilidade do médico assistente, que deverá avaliar em quais situações o benefício supera o risco. Durante a gravidez e puerpério (até 3 meses após o parto), devido ao alto risco para a mãe e o feto, o aumento de dose pode ser realizado a critério médico, seguindo o seguinte esquema posológico na fase de manutenção: 900 mg semanalmente<sup>(44,45)</sup> ou 1.200 mg quinzenalmente<sup>(46,47)</sup> . A fase de indução permanece como recomendado em bula.  
<mark>Para os demais pacientes com HPN o ajuste de dose não está previsto neste PCDT, visto que não foram identificadas evidências de benefícios e riscos diferentes do esquema preconizado em bula.</mark>

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **9 – MONITORIZAÇÃO E AVALIAÇÃO DOS BENEFÍCIOS DO ECULIZUMABE** -->
O acompanhamento do uso de eculizumabe por pacientes com HPN é realizado com o objetivo de avaliar os benefícios obtidos, em vida real, para os pacientes em termos de efetividade clínica e segurança e em conformidade com as Diretrizes Nacionais para Avaliação de Desempenho de Tecnologias em Saúde do SUS. A avaliação da efetividade e segurança está vinculada ao deferimento da solicitação e autorização do fornecimento do eculizumabe no âmbito do Componente Especializado da Assistência Farmacêutica (CEAF).  
Antes do início do tratamento, serão avaliados dados sócio-demográficos do paciente e seu histórico de saúde, bem como os resultados de exames laboratoriais. A efetividade e segurança do tratamento serão avaliadas periodicamente, por meio de medidas bioquímicas e também da perspectiva do paciente em termos de qualidade de vida ( **Tabela 1** ). Estes exames e questionários deverão ser incluídos no processo do paciente, observando a periodicidade dos mesmos, quando da renovação do Laudo para Solicitação, Avaliação e Autorização de Medicamento(s) (LME) a cada 3 meses. A avaliação do paciente por citometria de fluxo deverá ser feita pelo menos uma vez ao ano.  
**Tabela 1 -** Esquema de avaliações para monitoramento clínico dos pacientes com HPN em tratamento com eculizumabe.  
|Avaliações|Avaliação|A cada 3|A cada 6|A cada 12|
|---|---|---|---|---|
||inicial|meses|meses|meses|
|Citometria de Fluxo|X|||X|  
13  
|Teste direto de antiglobulina|X||X|
|---|---|---|---|
|(Teste de Coombs direto)||||
|Lactato Desidrogenase (LDH)|X|X||
|Hemograma completo e reticulócitos|X|X||
|Exames de Ferro:||||
|Índice de Saturação de Transferrina (IST)|X||X|
|Ferritina Sérica|X||X|
|Exames de função renal:||||
|Ureia|X||X|
|Creatinina|X||X|
|Ecocardiograma com PSAP *|X|||
|História transfusional nos últimos seis meses|X||X|
|História clínica recente|X|X||
|Avaliação de Qualidade de Vida|X||X|  
* Apenas para os pacientes que possuírem hipertensão arterial pulmonar como critério de inclusão.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Benefício primário em termos de efetividade clínica a ser medido:** -->
- Independência transfusional em um período de 6 meses após a primeira dose e no máximo três transfusões  
- ao ano após esse período<sup>(28)</sup> ; e  
- Redução da hemólise, evidenciada por LDH < 1,5 vezes o limite superior de referência 3 meses a partir da primeira dose do medicamento.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Evento primário de segurança clínica a ser medido:** -->
- Ausência de evento tromboembólico 3 meses após início do tratamento.  
Além destes resultados de efetividade e segurança do eculizumabe a serem medidos para avaliar os benefícios para os pacientes, devem ser utilizados o questionário para avaliação da História Clínica Recente ( **Apêndice 1** )  e o de Avaliação de Qualidade de Vida ( **Apêndice 2** ).  
Ao médico assistente cabe definir outros exames clínicos de acompanhamento em períodos diferenciados, de acordo com a sua prática clínica, para melhor assistência  do paciente.  
14

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **10 - REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamentos.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontram os medicamentos preconizados neste Protocolo.  
Para a autorização do TCTH alogênico não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
A HPN é uma doença que necessita de cuidados especializados e, por isso, o paciente deve ser acompanhado por um corpo técnico treinado e especializado para tal, devendo haver sempre que possível participação e apoio da Rede Nacional de Serviços de Hematologia e Hemoterapia.  
O eculizumabe é um medicamento biológico de infusão intravenosa em que, de acordo com a Portaria nº 77/SCTIE/MS, de 14 de dezembro de 2018, o uso, além da negociação com o fabricante para redução significante de preço, está condicionado ao<sup>(15)</sup> :  
- 1 – Atendimento a este Protocolo;  
- 2 – Atendimento, tratamento e acompanhamento dos pacientes em hospitais de referência determinados pelo  
- Ministério da Saúde;  
- 3 – Registro dos dados clínicos e farmacêuticos em sistema nacional de informática do SUS;  
- 4 – Uso _ad experimentum_ (reavaliação em 3 anos);  
- 5 – Laudo próprio para dispensação do medicamento; e  
- 6 – Fornecimento diretamente aos respectivos hospitais.  
Dessa forma, é essencial que haja atendimento especializado e centralizado em serviços de saúde de referência para maior qualidade do uso e avaliação de desempenho do eculizumabe. A dispensação e administração intravenosa ocorrerão exclusivamente em estabelecimentos de sáude do SUS, não sendo fornecidos frascos do medicamento para os pacientes.  
A solicitação e a renovação da continuidade do tratamento podem ser deferidas, indeferidas ou devolvidas após análise.  
15  
Devem ser rigorosamente observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas de eculizumabe, a adequação de uso do medicamento, a necessidade de interrupção do uso e o acompanhamento póstratamento.  
A unidades da Atenção Primária à Saúde e a Estratégia de Saúde da Família, como pontos cruciais nas redes de atenção à saúde, e serviços de saúde do SUS mais próximos ao paciente com HPN, deverão contribuir para o acompanhamento e monitorização dos doentes, “referenciando”  e “contra-referenciando” o paciente em caso de necessidade.  
A adesão ao tratamento deverá ser monitorada e, caso sejam identificados problemas, é recomendada a avaliação e o acompanhamento do paciente por uma equipe multiprofissional, com o objetivo de promover a qualidade do uso medicamento e a efetividade clínica do tratamento com o eculizumabe.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **11 - TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao tratamento da HPM. Especificamente quanto ao uso do eculizumabe, observando-se os critérios para interrupção do tratamento e levarndo-se em consideração as informações contidas no TER.  
Para o esclarecimento sobre os riscos e benefícios do transplante de células-tronco hematopoéticas alogênico, adotam-se as normas preconizadas no âmbito do Sistema Nacional de Transplantes.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **12 – REFERÊNCIAS** -->
1-SOCIE, G et al. Paroxysmal nocturnal haemoglobinuria: long-term followup and  prognostic factors. French Society of Haematology. Lancet. 1996; 348(9027)573-7.  
2-PARKER, C. J. et al. Diagnosis and management of paroxysmal  nocturnal hemoglobinuria. Blood. 2005; 106(12):3699-709.  
3-MATHIEU, D. et al. Impact of magnetic resonance imaging on the diagnosis of abdominal complications of paroxysmal nocturnal hemoglobinuria. Blood. 1995; 85(11):3283-8.  
4-WARE, RE; HALL, SE; ROSSE, WF. Paroxysmal nocturnal hemoglobinuria with onset in childhood and adolescence. N Engl J Med. 1991; 325(14):991-6.  
5-BESA, EC. Paroxysmal nocturnal hemoglobinuria, in eMedicine. 2007, WebMD.  
6-TAKEDA et al., Deficiency of the GPI anchor caused by a somatic mutation of the PIG-A gene in paroxysmal nocturnal hemoglobinuria. Cell. 1993; 21;73(4):703-1  
**7-** ARRUDA et al., 2010. Hemoglobinúria paroxística noturna: da fisiopatologia ao tratamento. Rev Assoc Med Bras 2010; 56(2): 214-21.  
8-KINOSHITA T. Glycosylphosphatidylinositol (GPI) Anchors: Biochemistry and Cell Biology: Introduction to a Thematic Review Series. J Lipid Res. 2016 Jan;57(1):4-5  
16  
9-PARKER, C.J., Management of paroxysmal nocturnal hemoglobinuria in the era of complement inhibitory therapy. Hematology Am Soc Hematol Educ Program. 2011;2011:21-9.  
10-BRODSKY, R A. Narrative review: paroxysmal nocturnal hemoglobinuria: the physiology of complement-related hemolytic anemia. Annals of Internal Medicine. 2008a; 148 (8):587–95.  
11-DEZERN and BRODSKY,  Paroxysmal Nocturnal Hemoglobinuria: A Complement-Mediated Hemolytic Anemia. Hematol Oncol Clin North Am. 2015 Jun;29(3):479-94.  
12-ROTHER, RP et al. The clinical sequelae of intravascular hemolysis and extracelular plasma hemoglobin: a novel mechanism of human disease. JAMA. 2005; 293(13):1653-62.  
13- BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Gestão e Incorporação de Tecnologias em Saúde. – Brasília: Ministério da Saúde, 2016.  
14- BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia.  Diretrizes metodológicas: elaboração de revisão sistemática e metanálise de ensaios clínicos randomizados/ Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Editora do Ministério da Saúde, 2012. 92 p.: il. – (Série A: Normas e Manuais Técnicos).  
15- BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Relatório de Recomendação n° 413- Eculizumabe para o tratamento da Hemoglobinúria Paroxística Noturna. Brasília. 2018.  
16- SCHÜNEMANN et al. GRADE handbook for grading quality of evidence and strength of recommendations. Updated October 2013. The GRADE Working Group, 2013. Disponível em https://www.guidelinedevelopment.org/handbook  
17-GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. McMaster University, 2015 (developed by Evidence Prime, Inc.). Disponível em https://www.gradepro.org  
18- ARAÚJO et al. "Hemoglobinúria Paroxística Noturna: relato de dois casos." Rev. bras. hematol. hemoter 24.4 (2002): 286-290.  
19- OLIVEIRA MM. Transplante de medula óssea para tratamento da hemoglobinúria paroxística noturna: experiência do hospital de clínicas da universidade federal do paraná. Dissertação [Medicina Interna do Departamento de Clínica Médica] Doutorado em Biologia Parasitária] – Universidade Federal do Paraná, 2011.  
20DE LATOUR et al. "Allogeneic stem cell transplantation in paroxysmal nocturnal hemoglobinuria." Haematologica 97.11 (2012): 1666-1673.  
21- SANTARONE et al. "Hematopoietic stem cell transplantation for paroxysmal nocturnal hemoglobinuria: long-term results of a retrospective study on behalf of the Gruppo Italiano Trapianto Midollo Osseo (GITMO)." Haematologica 95.6 (2010): 983-988.  
22- RAIOLA et al. "Bone marrow transplantation for paroxysmal nocturnal hemoglobinuria." Haematologica 85.1 (2000): 59-62.  
23- ALSENHED et al. "Paroxysmal nokturn hemoglobinuri (PNH).  
24- MARIANA et al. "Paroxysmal nocturnal hemoglobinuria: from pathophysiology to treatment." Rev Assoc Med Bras 56.2 (2010): 214-20.  
25- DE LATOUR et al. "Allogeneic stem cell transplantation in paroxysmal nocturnal hemoglobinuria." Haematologica 97.11 (2012): 1666-1673.  
17  
26-KEENEY, M; ILLINGWORTH, A; SUTHERLAND, D. R. Paroxysmal Nocturnal Hemoglobinuria Assessment by Flow Cytometric Analysis. Clinics in laboratory medicine, v. 37, n. 4, p. 855-867, 2017.  
27-HILLMEN, P. et al. Long-term effect of the complement inhibitor eculizumab on kidney function in patients with paroxysmal nocturnal hemoglobinuria. American journal of hematology, v. 85, n. 8, p. 553-559, 2010.  
28-DEZERN, A E.; BOROWITZ, M J. ICCS/ESCCA Consensus Guidelines to detect GPI‐deficient cells in Paroxysmal Nocturnal Hemoglobinuria (PNH) and related Disorders Part 1–Clinical Utility. Cytometry Part B: Clinical Cytometry, v. 94, n. 1, p. 16-22, 2018.  
29- BARCELLINI, W.; FATTIZZO, B. Clinical applications of hemolytic markers in the differential diagnosis and management of hemolytic anemia. Disease markers, v. 2015, 2015.  
30- COSTA, F F; FERTRIN K Y.; CONRAN N. Síndrome Hemolítica. Fisiopatologia e Clínica. Classificação. Em: Tratado de Hematologia, ed. 1, São Paulo:  Atheneu, pp.161-167, 2013.  
31- HILL et al. Paroxysmal nocturnal haemoglobinuria. Nature Reviews | Disease Primers. Volume 3. 2017. doi:10.1038/nrdp.2017.28. Published online 18 May 2017.  
32- OLDAKER et al. ICCS/ESCCA Consensus Guidelines to detect GPI-deficient cells in Paroxysmal Nocturnal Hemoglobinuria (PNH) and related Disorders - Part 4 – Assay Validation and Quality Assurance. Cytometry Part B (Clinical Cytometry) 94B:67–81 (2018)  
33- VAN DEN HEUVEL-EIBRINK. Paroxysmal Nocturnal Hemoglobinuria in Children. Pediatr Drugs 2007; 9 (1): 11-  
16. doi: 1174-5878/07/0001-0011/$44.95/0. 2005.  
34- RÖTH et al. Chronic treatment of paroxysmal nocturnal hemoglobinuria patients with eculizumab: safety, efficacy, and unexpected laboratory phenomena. Int J Hematol (2011) 93:704–714. DOI 10.1007/s12185-011-0867-y.  
35- BRODSKY et al. Multicenter phase 3 study of the complement inhibitor eculizumab for the treatment of patients with paroxysmal nocturnal hemoglobinuria. Blood, 15 February 2008.Vvolume 111, number 4.  
36- HARTMANN et al. Paroxysmal nocturnal hemoglobinuria: clinical and laboratory studies relating to iron metabolism and therapy with androgen and iron. Medicine (Baltimore). 1966;45:331-363.  
37- ROSSE. Treatment of paroxysmal nocturnal hemoglobinuria. Blood. 1982;60:20-23.  
38- HALL et al. Primary prophylaxis with warfarin prevents thrombosis in paroxysmal nocturnal hemoglobinuria (PNH). Blood. 2003;102:35873591.  
39- MOYO et al. Natural history of paroxysmal nocturnal haemoglobinuria using modern diagnostic assays. Br J Haematol. 2004;126:133-138.  
40- NISHIMURA et al. Clinical course and flow cytometric analysis of paroxysmal nocturnal hemoglobinuria in the United States and Japan. Medicine (Baltimore). 2004; 83(3):193207.  
41- MCMULLIN et al. Tissue plasminogen activator for hepatic vein thrombosis in paroxysmal nocturnal haemoglobinuria. J Intern Med. 1994;235:85-89.  
42- SHOLAR; BELL. Thrombolytic therapy for inferior vena cava thrombosis in paroxysmal nocturnal hemoglobinuria. Ann Intern Med. 1985;103: 539-541.  
43- RAY et al. Paroxysmal nocturnal hemoglobinuria and the risk of venous thrombosis: review and recommendations for management of the pregnant and nonpregnant patient. Haemostasis. 2000;30:103-117.  
18  
44-SHARMA, Ruby et al. Successful pregnancy outcome in paroxysmal nocturnal hemoglobinuria (PNH) following escalated eculizumab dosing to control breakthrough hemolysis. Leukemia research reports, v. 4, n. 1, p. 36-38, 2015.  
45-KELLY, Richard et al. The management of pregnancy in paroxysmal nocturnal haemoglobinuria on long term eculizumab. British journal of haematology, v. 149, n. 3, p. 446-450, 2010.  
46-PATRIQUIN, Christopher; LEBER, Brian. Increased eculizumab requirements during pregnancy in a patient with paroxysmal nocturnal hemoglobinuria: case report and review of the literature. Clinical case reports, v. 3, n. 2, p. 88, 2015.  
47-FRAIRIA et al., Breakthrough hemolysis and thromboembolism controlled by eculizumab during pregnancy in paroxysmal noctural hemoglobinuria (PNH): a single institution experience. In: 23rd European Hematology Associatin  
Congress. Jun 14, 2018; 216382.  
19  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: ECULIZUMABE -->
Eu, _____________________________________________ (nome do(a) paciente), declaro ter sido informado(a)  
claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do **eculizumabe** , indicadas para o tratamento de **Hemoglobinúria Paroxística Noturna**  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico  
______________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Pode bloquear a ação do complemento, a resposta inflamatória do organismo e a sua capacidade de atacar e destruir as próprias células sanguíneas vulneráveis (células HPN).  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Frequentes: podem afetar até 1 em 10 pessoas** -->
- infecção grave (sepse meningocócica), bronquite, infecção por fungos (infecção por Aspergillus), infecção nas  
- articulações (artrite bacteriana), nasofaringite, lesões de pele (herpes simplex), infecção do trato urinário, infecção viral;  
- número relativamente pequeno de plaquetas no sangue (trombocitopenia), contagem de glóbulos brancos baixa  
(leucopenia), destruição dos glóbulos vermelhos (hemólise), pressão arterial baixa;  
- reação alérgica grave que causa dificuldade em respirar ou tonturas (reação anafilática);  
- perda do apetite;  
- tonturas, alterações do paladar (disgeusia);  
- infecção do trato respiratório superior, tosse, nariz entupido (congestão nasal), irritação ou dor na garganta (dor  
- faringolaríngea), corrimento nasal (rinorreia), dispneia (dificuldade em respirar);  
- diarreia, vómitos, náusea, dor abdominal, prisão de ventre, desconforto no estômago após as refeições (dispepsia);  
- erupção na pele, perda de cabelo (alopecia), pele com comichão (prurido);  
- dor nos membros ou articulações (braços e pernas), dores musculares, cãimbras musculares, dor nas costas e de  
pescoço;   
- inchaço (edema), desconforto no peito, febre (pirexia), arrepios, sensação de cansaço (fadiga), sensação de fraqueza (astenia), sintomas do tipo gripal.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Pouco frequentes: podem afetar até 1 em 100 pessoas:** -->
20  
- sepse, choque séptico, infecção nas meninges (meningite meningocócica), infecção nos pulmões (pneumonia),  
- gastroenterite (infecção gastrointestinal), cistite, infecção do trato respiratório inferior;  
- infeção fúngica, acúmulo de pus (abcesso), tipo de infecção da pele (celulite), gripe, infecção das gengivas,  
- sinusite, infecção nos dentes, impetigo;  
- tumor de pele (melanoma), alterações da medula óssea;  
- coagulação anormal do sangue, aglutinação de células, fator de coagulação anormal, redução nos glóbulos vermelhos (pele pálida, fraqueza e falta de ar), valor baixo de linfócitos, um tipo de glóbulos brancos (linfopenia), sentir os batimentos do coração (palpitações);  
- hipersensibilidade;  
- doença relacionada com a hiperatividade da tireoide (Doença de Basedow-Graves);  
- apetite reduzido;  
- depressão, ansiedade, incapacidade de dormir, alterações do sono, pesadelos, alterações bruscas de humor;  
- desmaio, tremores, formigamento em parte do corpo (parestesia);  
- visão desfocada, irritação dos olhos;  
- zumbido nos ouvidos, vertigens;  
- pressão arterial elevada, desenvolvimento súbito e rápido de pressão arterial extremamente elevada, equimose  
(manchas escuras na pele), fogacho (calores), alterações nas veias;  
- hemorragia nasal;  
- inflamação no peritônio (o tecido que reveste a maioria dos órgãos no abdomen), refluxo dos alimentos do  
- estômago, dor nas gengivas, distensão abdominal;  
- pele ou olhos amarelados (icterícia);  
- urticária, inflamação da pele, vermelhidão da pele, pele seca, púrpura (pequenos pontos avermelhados na pele),  
- alterações da cor da pele, transpiração aumentada;  
- espasmo do músculo da boca, inchaço das articulações;  
- alterações renais, sangue na urina, dificuldade ou dor ao urinar (disúria);  
- alterações menstruais, ereção espontânea;  
- dor no peito, dor no local da infusão, extravazamento do medicamento administrado para fora da veia, sensação  
- de calor;  
- aumento das enzimas do fígado, diminuição da proporção do volume do sangue que é ocupado pelos glóbulos  
- vermelhos, diminuição na proteína dos glóbulos vermelhos que transporta o oxigênio (hemoglobina);  
- reação relacionada com a infusão.  
21  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.   (     ) Sim            (     ) Não  
Local:                                                             Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal:  
Documento de identificação do responsável legal:  
<!-- Start of picture text -->
_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontram os medicamentos preconizados neste Protocolo.  
22  
**APÊNDICE 1**  
QUESTIONÁRIO DE AVALIAÇÃO DA HISTÓRIA CLÍNICA  
<!-- Start of picture text -->
HISTORIA CLINICA RECENTE — HPN<br>Populacao de pacientes com maior risco de HPN<br>Teste Coombs negativo, especialmente em pacientes com deficiéncia de fons, ou. ]SIM [_]NAO<br>Hemoglobintiria (ou hemattitia), OU een SIM CINAO<br>ARSMD Anemia Refrataria - Sindromes Mielodisplasicas , OU ...cc0on-m-mn-eed—1SIM [J NAO<br>Trombose nao explicada, ou an Csim CinAo<br>Citopenia nao expliCadannd SIM LINKO<br>Qualquer evidéncia de hemolise (intervalos de referéncia incluidos nos parénteses)<br>LDH > 1,5 vezes o limite superior (105-133 IU/L), ou ||| 8<br>Baixos niveis de haptoglobina (41-165 mg/dL), ou mg/dL<br>Contagem elevada de reticuldcitos (0,5-1,5%), ou snares YO<br>Bilirrubina elevada (0-0,3 mg/dL) mg/dL<br>Quaisquer sinais de disfuncao renal (intervalos de referéncia incluidos nos parénteses)<br>Proteinuria (< 30 mg albumina/g creatinina), ou mg/g<br>Baixa TFGe (90-120 mL/min/1,73 m’), ou see ML/miN/ 1,73 mM?<br>Creatinina sérica elevada (mulheres: 0,6-1,1 mg/dL; homens: 0,7-1,3 mg/dL) mg/dL<br>Evidéncia de comorbidades de HPN (intervalos de referéncia incluidos nos parénteses)<br>Baixa contagem de plaquetas (100.000-400-000/pL), ou HfL<br>Dimero D elevado (< 250 ng/mL), ou ng/mL<br>NT-proBNP elevado (valores de referéncia variam com sexo e idade), ou sens PG/ML<br>Pressao arterial pulmonar elevada (> 25 mmHg) mm/Hg<br>Outros sintomas associados com HPN que devem elevar o grau de suspeita<br>Dor abdominal Osim Cinéo<br>Dor no peito Cisim CINAo<br>Dispnéia Osim Lindo<br>Cansaco Osim CinAo<br>Qualidade de vida prejudicada Cisim Ciao<br>Anemia Qsim CinAo<br>Disfagia Cisim Ciao<br><!-- End of picture text -->  
23

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Pouco frequentes: podem afetar até 1 em 100 pessoas:** -->
<!-- Start of picture text -->
FACIT-F (Versio 4)<br>Faca um circulo ou marque um numero por linha para indicar a sua resposta no que se refere<br>aos ultimos 7 dias.<br>PREOCUPACOES ADICIONAIS. Nem Um Mais Muito Muitis-<br>um = pouco— ow simo<br>pouco menos<br>= Sinto-me fatigado/a ........ccccsesecteeseentesenesenseeeccnneseenneeees OO 1 2 3 4<br>= | Sinto fraqueza generalizada wcsccnnnnnnnninnnnnnnnnn 0 1 2 3 4<br>42 | Sinto-me sem forgas (sem vontade para nada) ccc 0 1 2 3 4<br>4a | Sinto-me cansado/a .sccsccsssseneeesesenntnstseneentneeenee — O 1 2 3 4<br>4 | Tenho dificuldade em comecar as coisas porque estou<br>CANSAMO/A ....sssssscssseesssseeesnnneesssneecssuesessnecssnnncessnanecninecssnneees 0 1 2 3 4<br>4 | Tenho dificuldade em acabar as coisas porque estou<br>CANSAMO/A ...cssecsccssecessssecsssseecsssnsesssnesssnsecsssuecsssnesssnecssnneceese 1 2 3 4<br>ea) 1 2 3 4<br>“ Sou capaz de fazer as minhas atividades habituais............ 0 1 2 3 4<br>4 | Preciso (de) dormir durante 0 diaw.csnnnnnnennnennenne 0 1 2 3 4<br>t= | Estou cansado/a demais para comet .icvccnennennnennnns 0 1 2 3 4<br>& | Preciso de ajuda para fazer as minhas atividades<br>= Estou frustrado/a por estar cansado/a demais para fazer<br>AS COISASQUE QUETO..ccssssecssssessenseseinnseeerinseeteinenneenneee 0 1 2 3 4<br>a Tenho que limitar as minhas atividades sociais por estar<br>CANSAMO/A ...essscsscssecessssecesssecsssnsesssnessssvessssnecessnesssnecsssneseese 1 2 3 4<br><!-- End of picture text -->  
24

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **1. PÚBLICO-ALVO, CENÁRIO E POPULAÇÃO-ALVO DO PROTOCOLO E DIRETRIZES TERAPÊUTICAS** -->
Este PCDT tem como público-alvo os profissionais de saúde envolvidos na atenção do paciente com hemoglobinúria paroxística noturna, em especial médicos, enfermeiros e demais profissionais que atuam desde a atenção primária até os demais níveis de atenção à saúde, nos contextos ambulatorial e hospitalar do Sistema Único de Saúde (SUS).  
Os indivíduos com HPN na sua apresentação hemolítica, com alta atividade da doença – definida como LDH ≥ 1,5 vezes o limite superior e tamanho do clone > 10% – são a sua população-alvo. O PCDT é aplicável a pacientes ambulatoriais com HPN hemolítica, conforme os critérios de inclusão e exclusão estabelecidos.  
Os pacientes com HPN subclínica não foram alvo deste PCDT.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **2. METODOLOGIA PARA ELABORAÇÃO DESTE PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS** -->
O CCATES/UFMG, de Belo Horizonte, coordenou o trabalho de elaboração desta diretriz, construída em parceria com o Departamento de Gestão e Incorporação de Tecnologias em Saúde, da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS).  
O desenvolvimento da diretriz seguiu o processo preconizado pelo Manual de Desenvolvimento de Diretrizes da Organização Mundial da Saúde (WORLD HEALTH ORGANIZATION, 2014) e pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde (BRASIL, 2016). A diretriz foi desenvolvida com base na metodologia GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), seguindo os passos descritos no GIN-McMaster _Guideline Development Checklist_ (SCHÜNEMANN _et al._ , 2014).  
O grupo elaborador incluiu representantes do Projeto de Desenvolvimento de Diretrizes Clínico-assistenciais para o SUS, do CCATES/UFMG, gestores de saúde, profissionais de saúde e representante de pacientes. Os integrantes declararam não haver qualquer conflito de interesse na elaboração desta diretriz.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **3. DEFINIÇÃO DO TÓPICO E ESTABELECIMENTO DAS QUESTÕES PICO (População, Intervenção, Comparação, Desfecho)** -->
As questões a serem tratadas foram estabelecidas em reunião em abril de 2019 entre médicos hematologistas, representantes do Ministério da Saúde e grupo elaborador das Diretrizes Brasileiras. O escopo do PCDT foi redigido abrangendo 2 questões clínicas e foi validado por painel de especialistas.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **4.1 Busca de evidências** -->
25  
Para elaborar esta diretriz, foi realizada uma revisão sistematizada sobre o uso de eculizumabe para HPN em gestantes, além da atualização de uma revisão sistemática elaborada pela Conitec (Comissão Nacional de Incorporação de Tecnologias) em dezembro de 2018, sobre o uso de eculizumabe para HPN. <mark>As revisões foram realizadas por</mark> dois revisores que avaliaram independentemente os títulos e resumos dos artigos, determinaram a elegibilidade e extraíram os dados. Os dados extraídos foram sumarizados. A evidência foi sintetizada narrativamente e resumida usando estatísticas descritivas. Quando possível, foi realizada meta-análise utilizando modelo de efeitos aleatórios, sendo realizadas análises de sensibilidade quando adequado. A heterogeneidade entre os estudos foi avaliada utilizando o teste I-quadrado.  
1. Para responder à questão sobre uso de eculizumabe para HPN, foi realizada atualização da revisão sistemática conduzida por BRASIL, 2018, por ser a mais atual, com adequada qualidade metodológica. Além disso, a revisão apresenta a estratégia de busca, tornando possível sua atualização. A busca de literatura foi realizada nas bases de dados MEDLINE (via PubMed), EMBASE, Cochrane e Lilacs a partir de junho de 2018. Em caráter complementar, foi realizada a busca manual por estudos relevantes entre as referências dos estudos inicialmente selecionados. Entre os desfechos avaliados estão sobrevivência, eventos tromboembólicos, independência transfusional, qualidade de vida, diminuição do número de transfusões, redução da hemólise e aumento do nível de hemoglobina (Quadro 01).  
2. Para responder à questão sobre uso de eculizumabe para HPN em gestantes, foi realizada uma revisão sistematizada a partir da RS de BRASIL, 2018 e sua atualização, utilizando os termos “abortion”, “miscarriage”, “embryo”, “child-bearing”, “child bearing”, “teratogens”, “teratogenic”, “prenatal”, “parturition”, “gravidness”, “parturiency”, “germination”, “impregnation”, “parturiency”, “teratogen”, “fetotoxins”, “fetotoxin”, “embryotoxins”, “embryotoxin”, “mom”, “fetotoxicity”, “fetotoxic”, “fetuses”, “nonfetotoxic”, “misbirth”, “abortice” e “feticide”. Além disso, foi realizada a busca manual de estudos relevantes entre as referências dos estudos inicialmente selecionados. Entre os desfechos avaliados estão: intercorrências e complicações durante a gestação, condições clínicas do recém nascido, presença de eculizumabe no leite materno e cordão umbilical (Quadro 02).  
**Quadro 01:** Pergunta estruturada utilizada para responder à questão sobre uso de eculizumabe para HPN  
|**P**|**População**|Pacientes com HPN|
|---|---|---|
|**I**|**Intervenção**|Tratamento com eculizumabe|
|**C**|**Comparadores**|Placebo ou não tratamento|
|**O**|**(****_Outcomes_) **<br>**Desfechos**|**De maior relevância:**sobrevivência, eventos tromboembólicos,<br>independência transfusional|
|||**De menor relevância:**qualidade de vida, diminuição do número de|
|||transfusões, redução da hemólise e aumento do nível de hemoglobina.|
|**S**|**(****_Study_) **|Revisões Sistemáticas (RS) com ou sem meta-análise, Ensaios Clínicos|
||**Tipo de estudo**|Randomizados (ECR) e estudos observacionais.|  
**Quadro 02:** Pergunta estruturada utilizada para responder à questão sobre uso de eculizumabe para HPN em gestantes e lactantes  
|**P**<br>**População**|Pacientes gestantes ou lactantes com HPN|
|---|---|  
26  
|**I**|**Intervenção**|Tratamento com eculizumabe|
|---|---|---|
|**C**|**Comparadores**|Não tratar|
|**O**|**(****_Outcomes_) **|Sem restrições|
||**Desfechos**||
|**S**|**(****_Study_) **<br>**Tipo de estudo**|Sem restrições|  
**<u>Quadro 03.</u>** Estratégias de busca de evidências nas base de dados  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|Medline (via||46|
|Pubmed)|((((((("Hemoglobinuria, Paroxysmal"[Mesh]) OR Hemoglobinuria,<br>Paroxysmal[Text Word]) OR Paroxysmal Hemoglobinuria[Text Word])<br>OR (((((Paroxysmal Nocturnal Hemoglobinuria[Text Word]) OR<br>Hemoglobinuria, Paroxysmal Nocturnal[Text Word]) OR Paroxysmal<br>Hemoglobinuria,<br>Nocturnal[Text<br>Word])<br>OR<br>Hemoglobinuria,<br>Nocturnal Paroxysmal[Text Word]) OR Nocturnal Paroxysmal<br>Hemoglobinuria[Text<br>Word]))<br>OR<br>(((Marchiafava-Micheli<br>Syndrome[Text Word]) OR Marchiafava Micheli Syndrome[Text<br>Word]) OR Syndrome, Marchiafava-Micheli[Text Word])))) AND<br>((("eculizumab" [Supplementary Concept]) OR eculizumab[Text Word])<br>OR Soliris[Text Word])||
|EMBASE|(EMB.EXACT.EXPLODE("paroxysmal nocturnal hemoglobinuria")<br>OR Paroxysmal nocturnal hemoglobinuria OR haemoglobinuria,<br>paroxysmal<br>OR<br>haemoglobinuria,<br>paroxysmal<br>nocturnal<br>OR<br>haemoglobinuria, nocturnal OR hemoglobinuria, paroxysmal OR<br>hemoglobinuria, paroxysmal nocturnal OR hemoglobinuria, nocturnal<br>OR marchiafava micheli syndrome OR marchiafava syndrome OR<br>nocturnal haemoglobinuria OR nocturnal haemoglobinuria, paroxysmal<br>OR<br>nocturnal<br>hemoglobinuria<br>OR<br>nocturnal<br>hemoglobinuria,<br>paroxysmal OR nocturnal paroxysmal haemoglobinuria OR nocturnal<br>paroxysmal hemoglobinuria OR paroxysmal haemoglobinuria OR<br>paroxysmal hemoglobinuria OR paroxysmal nocturnal haemoglobinuria<br>OR<br>paroxysmal<br>nocturnal<br>hemoglobulinuria<br>OR<br>pnh)<br>AND<br>(EMB.EXACT.EXPLODE("eculizumab") OR monoclonal antibody OR<br>5g1.1 OR soliris)|124|  
27  
|The|#1 MeSH descriptor: [Hemoglobinuria, Paroxysmal] explode all trees|63|
|---|---|---|
|Cochrane|#2 Hemoglobinuria, Paroxysmal  (Word variations have been searched)||
|Library|#3 Paroxysmal Nocturnal Hemoglobinuria  (Word variations have been<br>searched)<br>#4 Hemoglobinuria, Paroxysmal Nocturnal  (Word variations have been<br>searched)<br>#5 Paroxysmal Hemoglobinuria, Nocturnal  (Word variations have been<br>searched)<br>#6 Hemoglobinuria, Nocturnal Paroxysmal  (Word variations have been<br>searched)<br>#7 Nocturnal Paroxysmal Hemoglobinuria  (Word variations have been<br>searched)<br>#8  #1 or #2 or #3 or #4 or #5 or #6 or #7<br>#9  Eculizumab  (Word variations have been searched)<br>#10  Soliris  (Word variations have been searched)<br>#11  #9 or #10<br>#12  #8 and #11||
|LILACS|"HEMOGLOBINURIA, PAROXYSMAL" or "HEMOGLOBINURIA,<br>PAROXYSMAL NOCTURNAL" [Palavras] and "ECULIZUMAB" or<br>"ECULIZUMABE" [Palavras]|4|

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **4.2.1 Para responder à questão sobre uso de eculizumabe para HPN** -->
Após a realização da busca nas bases de dados, 237 publicações foram recuperadas, 45 tratavam-se de duplicatas e 31 foram lidos na íntegra. Dois revisores independentes selecionaram estudos para leitura na íntegra aplicando os critérios de elegibilidade e, nos casos de divergências, um terceiro revisor realizou a avaliação. Dos 31 estudos lidos na íntegra, nenhum estudo cumpriu os critérios de elegibilidade e, portanto, não houve inclusão de estudos na RS atualizada (Figura 01).  
**Figura 01:** Fluxograma de seleção dos estudos.  
28  
<!-- Start of picture text -->
PublicagBes identificadas através da pesquisa<br>8 nas bases de dados: 237<br>g<br>= PUBMED = 46<br>€ EMBASE= 124<br>3 LILACS = 04<br>~ Cochrane = 63<br>Publicagdes excluidas segundo<br>8 critérios de exclusdo: 161<br>a Publicagdes apds remocao de duplicatas:<br>3 192 Tipo de estudo: 118<br>Tipo de populacao: 11<br>Tipo de intervengao: 32<br>Publicagdes excluidas segundo<br>2 critérios de exclusao: 31<br>=3 Publicagdes selecionadas para leitura Tipo deestudde estudo: 9<br>S compreta:feta: 31 Tipo de publicagao: 10<br>2 Duplicata: 13<br>a<br>2<br>33 Estudos incluidos: 0<br>3€<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **4.2.2 Para responder à questão sobre uso de eculizumabe para HPN em gestantes e lactantes** -->
Dos 2.012 estudos recuperados na revisão sistemática de BRASIL, 2018 e sua atualização, 102 artigos foram selecionados para leitura na íntegra por dois avaliadores independentes, por meio de leitura de título e resumo. Um terceiro avaliador resolveu as divergências. Após leitura na íntegra, foram selecionados 10 relatos de caso de gestantes que fizeram uso de eculizumabe, uma série de casos e uma coorte. Foram excluídos os artigos nas quais as pacientes saíram do estudo no início da gestação ou os dados destas pacientes não foram apresentados. Os dados foram sumarizados e apresentados com as principais informações dos estudos de coorte e da série de casos identificados,  além de um _pool_ dos dados coletados individualmente nos relatos de casos.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **4.3.1 Uso de eculizumabe para HPN** -->
A atualização da revisão sistemática da literatura conduzida por BRASIL, 2018 não incluiu nenhum novo estudo. Dessa forma, as evidências encontradas sobre a eficácia, efetividade e segurança do eculizumabe para HPN foram 16 relatos, entre os quais uma revisão sistemática, dois relatos que descreviam um ECR, nove relatos de oito estudos de coorte e quatro resumos de coortes apresentados em congressos ou publicados em anais.  
29  
O ECR foi classificado com qualidade metodológica alta, tendo sido patrocinado pela indústria produtora do medicamento. Quanto às coortes, todas foram classificadas com qualidade metodológica baixa, principalmente pela ausência de braço comparador relevante para a questão de pesquisa proposta. Os resumos não foram avaliados quanto à qualidade metodológica, por não apresentarem, até o momento, estudo completo publicado, o que impossibilitou a avaliação.  
Em relação à qualidade da evidência, avaliada pela ferramenta GRADE, os desfechos avaliados pelos estudos foram considerados, em sua maioria, substitutos, sendo usados como _proxy_ dos desfechos de interesse para o paciente. Todos os desfechos avaliados foram considerados de muita baixa qualidade.  
A revisão sistemática incluída avaliou apenas um ECR (TRIUMPH) - também incluído neste relatório -, comparando o uso de eculizumabe e placebo, por 26 semanas, em 87 participantes. No grupo eculizumabe, observou-se uma redução da hemólise intravascular crônica e estabilização dos níveis de hemoglobina acima do limite superior em 49% dos pacientes, mesmo na ausência de transfusões. Além disso, houve menor necessidade de transfusão nesse grupo, e a independência transfusional foi alcançada em metade dos pacientes tratados com eculizumabe. Quanto à QV, relatouse aumento no escore no grupo eculizumabe, mas sem mostrar o escore final ou inicial, não permitindo a conclusão da significância deste aumento para a situação do paciente. Foram notificados mais EA graves no grupo placebo do que no eculizumabe.  
Em relação aos resultados de efetividade, foram avaliados oito estudos de coorte. Destes, três eram retrospectivos e os demais prospectivos. Para realização da meta-análise, os desfechos de efetividade disponíveis foram avaliados previamente. Aqueles comuns a mais de um estudo foram meta-analisados. Observou-se maior redução no nível de LDH e de transfusões no grupo de pacientes tratados com eculizumabe em relação ao controle. Quanto ao nível de hemoglobina, não foi possível observar diferença estatisticamente significante no aumento desse parâmetro entre os dois grupos. Em relação à segurança, o eculizumabe apresentou efeito protetor, reduzindo a ocorrência de eventos tromboembólicos nos pacientes tratados, em comparação ao grupo controle. No desfecho mortalidade observou-se efeito protetor, a favor do eculizumabe, com significância estatística apenas após 36 meses de tratamento. Os resultados de QV não foram meta-analisados devido à ausência de um grupo comparador de interesse nos estudos incluídos, mas observouse um maior aumento no escore EORTC QLQ C30 nos pacientes tratados com eculizumabe, exceto para aqueles com necessidades de transfusão (ALMEIDA et al, 2017).  
Levando em consideração que a maioria dos estudos foi realizada em um único centro, e alguns deles apresentaram amostras muito pequenas, a validade externa dos resultados encontrados pode estar comprometida. Além disso, vários deles foram financiados ou receberam apoio da indústria fabricante do medicamento. Apesar de não terem apresentado um grupo controle que permitisse uma comparação robusta, esses estudos apresentaram período de acompanhamento dos pacientes superior à duração dos ensaios clínicos, o que pode fornecer maior confiabilidade para os resultados encontrados, considerando que se trata de uma doença crônica.  
Uma descrição mais detalhada dos estudos e desfechos, com meta-análise, pode ser encontrada em BRASIL, 2018.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **4.3.2 Uso de eculizumabe para HPN em gestantes e lactantes** -->
**Coorte**  
30  
Por meio de questionário enviado a médicos ou membros do International PNH Interest Group, Kelly e colaboradores (2015) analisaram 75 gestações em 61 mulheres com HPN que usaram eculizumabe durante junho de 2006 a novembro de 2014. De todas a gestações, seis resultaram em aborto durante o primeiro trimestre de gravidez, três nasceram natimortos e um apresentou megacólon tóxico. Ocorreram 22 nascimentos prematuros (anteriores a 37 semanas de gravidez), sendo: a) sete por cesárea planejada; b) seis por pré-eclâmpsia; c) cinco por crescimento intrauterino retardado; d) três por decréscimo na contagem de plaquetas; e) um por redução dos movimentos fetais. Dos 69 bebês nascidos, a média de peso foi 2,692 kg (450-4,290 kg). Nove tiveram complicações neonatais, sendo elas: a) seis por estadia prolongada no hospital; b) três por deficiência do crescimento inicial e c) um por síndrome da rolha meconial. Todos os bebês com dados disponíveis obtiveram bom desenvolvimento comportamental, de linguagem, visão, audição, locomoção, movimentos motores finos e saúde física. Das 20 amostras de sangue do cordão umbilical disponíveis, sete tiveram níveis detectados de eculizumab. Essa informação sugere o cruzamento transplacentário do fármaco, mas os autores afirmaram ser em baixos níveis, sem fornecer dados quantitativos.  Um total de 25 bebês foram amamentados pelas mães. Em 10 desses casos foi analisada a presença de eculizumabe, não sendo encontrado em nenhuma das amostras.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Série de Casos** -->
Série de Casos reportada por Vinogradova et all (2016) com 14 gestações em 14 pacientes com HPN, recebendo tratamento com eculizumabe. De acordo com os autores as manifestações clínicas da hemólise regrediram significativamente durante a terapia: a normalização da LDH foi registrada em 71,4% dos pacientes antes da concepção. A HPN foi diagnosticada antes da gravidez em todos os casos, sendo que  92,9% dos pacientes estavam em uso de eculizumabe antes de engravidar. Todas  pacientes receberam e permaneceram no tratamento com eculizumabe durante a gravidez e pós-parto, sendo que, 42,9% das pacientes necessitaram de um ajuste da dose devido a hemólise invasiva. As 14 gestações resultaram em 14 recém-nascidos vivos. Não foi relatado aborto espontâneo ou natimorto. A cesárea foi realizada em 78,6% dos partos, sendo  que  em 35,7% dos casos houve antecipação cirúrgica (26-34 semanas) devido a pré-eclâmpsia, placenta prévia, hemólise invasiva ou insuficiência placentária. Não houve malformações nos recémnascidos. Peso médio ao nascer 2560 g (450-3550). Um prematuro com peso extremamente baixo e uma síndrome de retardo de crescimento devido à insuficiência placentária faleceu no segundo dia de vida devido a complicações hemorrágicas generalizadas. Um recém-nascido diagnosticado com neuroblastoma no primeiro ano de vida permanece em tratamento. A maioria dos recém-nascidos (85,7%) é saudável, 71,4% dos quais receberam aleitamento materno sem complicações.

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **Compilados dos Relatos de Caso** -->
Foram analisados 10 estudos de caso envolvendo 17 pacientes que fizeram uso do medicamento durante a gravidez. Dados destes pacientes coletados dos estudos estão apresentados na tabela 01. Apenas 8 pacientes fizeram uso de eculizumabe durante todo o período de gestação, sendo que 7 pacientes utilizaram o medicamento durante tempo médio de 14 semanas (considerando um período padrão de 40 semanas de gestação), e uma paciente descontinuou o tratamento por falta do medicamento. As complicações e intercorrências mais relatadas foram: crise hemolítica (n=5), pré-eclâmpsia (n=2) e anemia (n=2). Todos os bebês nasceram saudáveis ou prematuros saudáveis com peso de acordo com a idade. Um bebê desenvolveu neutropenia sem causa definida. A alteração na posologia deu-se por meio do aumento da concentração do eculizumabe de 900mg para 1200mg e, em outros casos, pelo aumento da frequência (semanal) de aplicação (900 mg) <mark>(BASTOS, 2018; COLUCCIO, 2009; F</mark> RAIRI <mark>A, 2018; KELLY, 2010; LAURITSCH‐ HERNANDEZ, 2018; PATRIQUIN, 2015; SARRIS, 2013; SHARMA, 2015; URABE, 2013; Y</mark> ILMA <mark>Z, 2018).</mark>  
31  
**Tabela 01:** Resultados sumarizados dos relatos de caso incluídos na revisão sistematizada.  
|**Desfecho avaliado**|**Sim**<br>**n (%)**|**Não**<br>**n (%)**|**Não**<br>**informado**<br>**n (%)**|
|---|---|---|---|
|Interrupção do tratamento devido a gravidez|4 (24)|13 (76)|0 (0)|
|Uso prévio de eculizumabe|11 (65)|6 (35)|0 (0)|
|Aumento da dose devido à gravidez|6 (35)|11 (65)|0 (0)|
|Uso do medicamento durante todo o período de gestação|9 (53)|8 (47)|0 (0)|
|37 semanas completas de gestação (não prematuros)|5 (29)|5 (29)|7 (41)|
|Presença de eculizumabe no leite|0 (0)|7 (41)|10 (59)|
|Presença de eculizumabe no cordão umbilical|4** (24)|3 (18)|10* (59)|
|Amamentação|4 (24)|1 (6)|12 (71)|
|Complicações ou intercorrências durante a gravidez|12 (71)|5|(29)|
|Cesariana***|6 (35)|7 (41)|4 (24)|  
* Dois estudos não avaliaram este desfecho  
**Quantidades insignificantes foram identificadas  
***Uma paciente realizou cesariana de emergência

---

<!-- METADADOS: doenca: Hemoglobinúria Paroxística Noturna | secao: **REFERÊNCIAS** -->
ALMEIDA, AM. et al. Clinical benefit of eculizumab in patients with no transfusion history in the International Paroxysmal Nocturnal Haemoglobinuria Registry. Intern Med J 2017;47:1026-34.  
AUSTRALIAN GOVERNMENT. Guidelines for the treatment of Paroxysmal Nocturnal Haemoglobinuria (PNH) through the Life Saving Drugs Program. 2010. Disponível em: www.health.gov.au/lsdp.  
BASTOS, Juliana Marques Coelho et al. Therapeutic challenges in pregnant women with paroxysmal nocturnal hemoglobinuria: A case report. Medicine, v. 97, n. 36, 2018.  
BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Relatório de recomendação: Eculizumabe para o tratamento da Hemoglobinúria Paroxística Noturna. Brasília, Ministério da Saúde. Dezembro de 2018.  
BRODSKY, R. A. et al. Multicenter phase 3 study of the complement inhibitor eculizumab for the treatment of patients with paroxysmal nocturnal hemoglobinuria. Blood, [s.l.], v. 111, n. 4, p.1840-1847, 30 nov. 2007. American Society of Hematology. http://dx.doi.org/10.1182/blood-2007-06-094136.  
BRODSKY, RA. How I treat paroxysmal nocturnal hemoglobinuria. Blood. 2009; 113(26):6522-7.  
CHOI, C.W. et al. Efficacy of eculizumab in paroxysmal nocturnal hemoglobinuria patients with or without aplastic anemia: prospective study of a Korean PNH cohort. Blood. 2017; 52(3):207-211.  
COLUCCIO, Valeria et al. Good Pregnancy Outcome in a Patient Affected by Paroxysmal Nocturnal Hemoglobinuria Treated with Eculizumab. 2009.  
DEZERN, A.E; DORR, D.; BRODSKY, R.A. Predictors of hemoglobin response to eculizumab therapy in paroxysmal nocturnal hemoglobinuria. Eur J Haematol, 90 (2013), p. 16-24.  
32  
FRAIRIA et al., Breakthrough hemolysis and thromboembolism controlled by eculizumab during pregnancy in paroxysmal noctural hemoglobinuria (PNH): a single institution experience. In: 23rd European Hematology Associatin Congress. Jun 14, 2018; 216382  
GRADEpro GDT. Disponível em: < https://gradepro.org/ >. Acesso em 06 mai 2019.  
HALL, C; RICHARDS, S; HILLMEN, P. Primary prophylaxis with warfarin prevents thrombosis in paroxysmal nocturnal hemoglobinuria (PNH). Blood. 2003;102:35873591.  
HARTMANN, RC et al. Paroxysmal nocturnal hemoglobinuria: clinical and laboratory studies relating to iron metabolism and therapy with androgen and iron. Medicine (Baltimore). 1966;45:331-363.  
HILL, A. et al. Effect of eculizumab on haemolysis-associated nitric oxide depletion, dyspnoea, and measures of pulmonary hypertension in patients with paroxysmal nocturnal haemoglobinuria. British Journal Of Haematology, [s.l.], v. 149, n. 3, p.414-425, maio 2010. Wiley-Blackwell.  
HILL, A. et al. Interim Analysis of Safety Outcomes during Treatment with Eculizumab: Results from the International Paroxysmal Nocturnal Hemoglobinuria Registry. Blood. 2017; 130:3486.  
HILLMEN, P. et al. The complement inhibitor eculizumab in paroxysmal nocturnal hemoglobinuria. N Engl J Med. 2006; 355(12):1233-43.  
HÖCHSMANN, B. et al. Effect of eculizumab in paroxysmal nocturnal hemoglobinuria (PNH) patients with or without high disease activity: results from the International PNH Registry. EHA Learning Center. 2017;181785.  
ISSARAGRISIL, S; PIANKIJAGUM, A; TANG-NAITRISORANA, Y. Corticosteroids therapy in paroxysmal nocturnal hemoglobinuria. Am J Hematol. 1987;25:77-83.  
KELLY, R. J. et al. Long-term treatment with eculizumab in paroxysmal nocturnal hemoglobinuria: sustained efficacy and improved survival. Blood, [s.l.], v. 117, n. 25, p.6786-6792, 1 abr. 2011. American Society of Hematology. http://dx.doi.org/10.1182/blood-2011-02-333997.  
KELLY, Richard et al. The management of pregnancy in paroxysmal nocturnal haemoglobinuria on long term eculizumab. British journal of haematology, v. 149, n. 3, p. 446-450, 2010.  
KELLY, Richard J. et al. Eculizumab in pregnant patients with paroxysmal nocturnal hemoglobinuria. New England Journal of Medicine, v. 373, n. 11, p. 1032-1039, 2015.  
LAURITSCH‐HERNANDEZ, Lisa Sophie et al. Eculizumab application during pregnancy in a patient with paroxysmal nocturnal hemoglobinuria: A case report with review of the literature. Clinical case reports, v. 6, n. 8, p. 1582, 2018.  
LEE, JW. et al. Efficacy of Eculizumab in Patients with Paroxysmal Nocturnal Hemoglobinuria (PNH) and High Disease Activity with or without History of Aplastic Anemia in the International PNH Registry. Blood. 2017;130:3487.  
LOSCHI, M.  et al. Impact of eculizumab treatment on paroxysmal nocturnal hemoglobinuria: a treatment versus notreatment study. American Journal of Hematology, 2015, v. 91, p. 366-370.  
MARTÍ-CARVAJAL, Arturo J et al. Eculizumab for treating patients with paroxysmal nocturnal hemoglobinuria. Cochrane Database Of Systematic Reviews, [s.l.], p.1-55, 30 out. 2014. Wiley-Blackwell. http://dx.doi.org/10.1002/14651858.cd010340.pub2.  
MCMULLIN, MF et al. Tissue plasminogen activator for hepatic vein thrombosis in paroxysmal nocturnal haemoglobinuria. J Intern Med. 1994;235:85-89.  
MOYO, VM; MUKINA, GL; BARRETT, ES; BRODSKY, RA. Natural history of paroxysmal nocturnal haemoglobinuria using modern diagnostic assays. Br J Haematol. 2004;126:133-138.  
MUSS, P. et al. Patient-reported outcomes and healthcare resource utilization before and during treatment with eculizumab: results from the International Paroxysmal Nocturnal Hemoglobinuria Registry. EHA Learning Center. 2017;181656.  
NINOMIYA, H. et al. Interim analysis of post-marketing surveillance of eculizumab for paroxysmal nocturnal hemoglobinuria in Japan. Int J Hematol. 2016;104(5):548–58.  
33  
NISHIMURA, J et al. Clinical course and flow cytometric analysis of paroxysmal nocturnal hemoglobinuria in the United States and Japan. Medicine (Baltimore). 2004; 83(3):193207.  
PARKER, CJ. Bone marrow failure syndromes: paroxysmal nocturnal hemoglobinuria. Hematology/Oncology Clinics of North America. 2009; 23(2):333–46.  
PARKER, CJ. et al. Diagnosis and management of paroxysmal nocturnal hemoglobinuria. Blood. 2005; 106(12):3699709.  
PATRIQUIN, Christopher; LEBER, Brian. Increased eculizumab requirements during pregnancy in a patient with paroxysmal nocturnal hemoglobinuria: case report and review of the literature. Clinical case reports, v. 3, n. 2, p. 88, 2015.  
RAY, JG et al. Paroxysmal nocturnal hemoglobinuria and the risk of venous thrombosis: review and recommendations for management of the pregnant and nonpregnant patient. Haemostasis. 2000;30:103-117.  
ROSSE, WF. Treatment of paroxysmal nocturnal hemoglobinuria. Blood. 1982;60:20-23.  
RÖTH, A; DUHRSEN, U. Treatment of paroxysmal nocturnal hemoglobinuria in the era of eculizumab. European Journal of Haematology 2011; 87(6):473–9.  
SARRIS, I. et al. Pregnancy outcome and safety of breast-feeding in two patients with paroxysmal nocturnal haemoglobinuria (PNH) treated with eculizumab. Archives of Disease in Childhood-Fetal and Neonatal Edition, v. 97, n. Suppl 1, p. A119-A119, 2012.  
SHARMA, Ruby et al. Successful pregnancy outcome in paroxysmal nocturnal hemoglobinuria (PNH) following escalated eculizumab dosing to control breakthrough hemolysis. Leukemia research reports, v. 4, n. 1, p. 36-38, 2015.  
SHOLAR, PW; BELL, WR. Thrombolytic therapy for inferior vena cava thrombosis in paroxysmal nocturnal hemoglobinuria. Ann Intern Med. 1985;103: 539-541.  
SOLIRIS: eculizumabe. Itapevi, SP:Alexion Farmacêutica Brasil Importação e Distribuição de Produtos e Serviços de Administração de Vendas Ltda. 2017. Bula de medicamento.  
UEDA, Y. et al. Effects of eculizumab treatment on quality of life in patients with paroxysmal nocturnal hemoglobinuria in Japan. International Journal of Hematology. 2018; 107:656-665.  
URABE, Akio et al. Management of pregnancy in paroxysmal nocturnal hemoglobinuria (PNH): a report of 10 cases from the working group on pregnancy of The Japan PNH Study Group. 2013.  
VAN DEN HEUVEL-EIBRINK, MM et al. Childhood paroxysmal nocturnal haemoglobinuria (PNH), a report of 11 cases in the Netherlands. British Journal of Haematology. 2005; 128(4):571–7.  
VINOGRADOVA, Maria A. et al. The Pregnancy Course and Outcomes during Targeted Therapy of Paroxysmal Nocturnal Hemoglobinuria. 2016.  
YILMAZ et al., A healthy baby born under the treatment of Eculizumab in a PNH patient after two fetal losses: Turkish Eculizumab baby.Kuwait Medical Journal 2018; 50 (4): 470 – 472  
ZHAO M, SHAO Z, LI K, et al. Clinical analysis of 78 cases of paroxysmal nocturnal hemoglobinuria diagnosed in the past ten years. Chin Med J (Engl). 2002;115:398-401.  
34

---

