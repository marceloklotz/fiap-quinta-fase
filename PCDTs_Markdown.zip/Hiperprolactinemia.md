<!-- METADADOS: doenca: Hiperprolactinemia | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 19, DE 23 DE NOVEMBRO DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Hiperprolactinemia  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a hiperprolactinemia no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 557/2020 e o Relatório de Recomendação nº 563 – Outubro de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Hiperprolactinemia.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da hiperprolactinemia, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da hiperprolactinemia.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria nº 1.160/SAS/MS, de 18 de novembro de 2015, publicada no Diário Oficial da União nº 221, de 19 de novembro de 2015, seção 1, página 46.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: HÉLIO ANGOTTI NETO -->
ANEXO

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **1. INTRODUÇÃO** -->
A hiperprolactinemia é caracterizada pelo excesso de produção da prolactina nos indivíduos. É uma das alterações hormonais mais frequentes na prática clínica e, na maioria das vezes, apresenta-se com sinais e sintomas que incluem diminuição da libido, alteração menstrual, infertilidade e galactorreia<sup>1</sup> . Um estudo escocês demonstrou, ao longo de 20 anos, uma prevalência de hiperprolactinemia na população geral de 0,1%, com taxas de incidência cinco vezes maiores nas mulheres do que nos homens, as quais se tornam aproximadamente iguais a partir dos 65 anos de idade<sup>2</sup> .  
As causas de hiperprolactinemia podem ser classificadas em fisiológicas, medicamentosas e patológicas. As fisiológicas mais importantes são gravidez e amamentação. Entre as segundas, a classe de medicamentos mais comumente associada à hiperprolactinemia é a dos antipsicóticos (fenotiazinas, butirofenonas, risperidona, sulpirida)<sup>3</sup> , entretanto, outros medicamentos como os antidepressivos tricíclicos (amitriptilina, clomipramina), inibidores da monoaminoxidase (moclobemida, tranilcipromina) alguns anti-hipertensivos (verapamil, reserpina, metildopa), medicamentos de ação gastrointestinal (domperidona, metoclopramida) e, mais raramente, os inibidores seletivos da recaptação da serotonina (fluoxetina, citalopram, sertralina) e os contraceptivos orais, também podem causar hiperprolactinemia<sup>4</sup> . Entre as causas patológicas, as mais frequentemente responsáveis pelo aumento da prolactina são os prolactinomas, os adenomas hipofisários clinicamente não funcionantes (ACNF), o hipotireoidismo primário e a acromegalia. Em um estudo multicêntrico brasileiro, envolvendo 1.234 indivíduos com hiperprolactinemia, os prolactinomas foram os responsáveis em 56,2% dos casos, seguidos pelos ACNF (6,6%), pelo hipotireoidismo primário (6,3%) e pela acromegalia (3,2%)<sup>5</sup> .  
Os prolactinomas são os tumores funcionantes mais comuns na hipófise. Representam aproximadamente 40% dos adenomas hipofisários<sup>6</sup> , com uma prevalência entre 25 e 63 por 100 mil indivíduos e uma incidência de aproximadamente 3 a 5 casos novos por 100 mil indivíduos ao ano<sup>7</sup> . São classificados de acordo com o tamanho, em microadenomas (menos de 10 mm de diâmetro) ou macroadenomas (10 mm ou mais). Nas mulheres, a proporção entre macro e microprolactinoma é de aproximadamente 1 (um) para 8 (oito). Nos homens, os macroadenomas representam 80% dos casos<sup>8</sup> .  
Em relação aos ACNF, uma revisão sistemática de estudos com indivíduos com esse tumor revelou uma prevalência geral de hiperprolactinemia de 40,2% (IC 95% 36,6% a 43,7%)<sup>9</sup> . Nesses casos, assim como na presença de qualquer outro tumor selar ou parasselar não-prolactinoma, a hiperprolactinemia decorre da diminuição do transporte de dopamina hipotalâmica para a hipófise, levando à ausência da ação inibitória da dopamina nas células lactotróficas normais. Esse processo tem sido chamado de desconexão hipotálamo-hipofisária ou compressão de haste e, classicamente, está associado a níveis séricos aumentados da prolactina, geralmente inferiores a 100 ng/mL<sup>9,10</sup> .  
A hiperprolactinemia é também um achado comum em indivíduos com cirrose hepática ou insuficiência renal. A denominação hiperprolactinemia idiopática tem sido reservada para os pacientes nos quais não se encontra uma causa óbvia para esse distúrbio hormonal após investigação, podendo ser um microadenoma não visualizado por exame de imagem<sup>11</sup> .  
As principais manifestações clínicas da hiperprolactinemia são galactorreia e sinais e sintomas de hipogonadismo (amenorreia/oligomenorreia nas mulheres, disfunção sexual nos homens, infertilidade, diminuição da libido e da densidade mineral óssea em ambos os sexos). Nos macroprolactinomas e outros tumores selares, a compressão de outras células hipofisárias, bem como da haste hipotálamo-hipofisária pode causar hipopituitarismo. Nos tumores grandes, com compressão do quiasma, manifestações neurológicas e oftalmológicas são comuns, representadas principalmente por cefaleia e alterações do campo visual (hemianopsia uni ou bilateral)<sup>12,13</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da hiperprolactinemia. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **3.1. Diagnóstico clínico** -->
A hiperprolactinemia deve ser investigada em mulheres com distúrbios menstruais, particularmente oligomenorreia e amenorreia, galactorreia ou infertilidade e, em homens, em razão de sintomas de hipogonadismo, diminuição da libido, disfunção sexual e infertilidade. A hiperprolactinemia deve ser investigada em todo paciente portador de macroadenoma, mesmo que negue queixas relacionadas a hipogonadismo. Os macroprolactinomas devem ser considerados em qualquer paciente com sinais e sintomas neurológicos ou oftalmológicos decorrentes de efeito de massa na região selar, como cefaleia ou alterações de campo visual, com hipopituitarismo associado<sup>12,13</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **3.2. Diagnóstico diferencial** -->
Durante a avaliação de um paciente com sintomas ou sinais clínicos ou exames laboratoriais de hiperprolactinemia, é fundamental que causas fisiológicas e medicamentosas sejam afastadas por meio de história clínica cuidadosa, exame físico adequado e teste de gravidez, quando necessário. Deve-se também dosar o hormônio estimulante da tiroide ( _Thyroidstimulating hormon_ e – TSH) e realizar exames bioquímicos de função renal (creatinina sérica) e hepática (AST/TGO e ALT/TGP), para que sejam afastados, respectivamente, hipotireoidismo primário, insuficiência renal e insuficiência hepática. Preconiza-se, também, que o diagnóstico de acromegalia seja afastado nos pacientes com características clínicas desta doença, bem como nos indivíduos com macroadenoma hipofisário<sup>12-14</sup> .  
O diagnóstico de macroprolactinemia deve ser considerado nos indivíduos sem sinais e sintomas relacionados à hiperprolactinemia, cuja detecção em exame laboratorial tenha sido casual<sup>13</sup> . A prolactina é um hormônio heterogêneo que possui três formas circulantes quanto ao seu tamanho molecular. Predomina a monomérica (>90%) nos pacientes normais e naqueles com prolactinoma. A dímera tem peso intermediário e a forma de alto peso molecular é conhecida como macroprolactina, ambas com concentrações séricas pouco expressivas (<10%). A macroprolactina resulta de uma ligação anômala da prolactina a imunoglobulinas circulantes, formando um complexo de alto peso molecular. Tal ligação reduz a atividade biológica da prolactina, significando que os indivíduos com macroprolactinemia têm elevadas concentrações de prolactina no soro, mas são, geralmente, assintomáticos<sup>15,16</sup> .  
Em pacientes com macroadenomas hipofisários associados à hiperprolactinemia, o diagnóstico diferencial deve ser feito entre macroprolactinoma e outros tumores selares ou parasselares, que, devido à compressão da haste hipofisária, causam hiperprolactinemia<sup>9,12,13</sup> **.**  
**3.3. Diagnóstico laboratorial**  
Os ensaios laboratoriais mais utilizados para a dosagem da prolactina são quimioluminescência e imunorradiométrico. Os valores de referência são comumente maiores nas mulheres do que nos homens e o limite superior não costuma ultrapassar 25 ng/mL, devendo-se interpretar de acordo com os valores normais indicados<sup>13</sup> .  
Geralmente, os níveis da prolactina têm relação com sua etiologia. Valores até 100 ng/mL são, na maioria das vezes, associados a medicamentos, causa idiopática, desconexão de haste ou microprolactinomas. Níveis de prolactina superiores a 250 ng/mL geralmente indicam a presença de prolactinoma<sup>12</sup> . Entretanto, medicamentos como a risperidona e metoclopramida têm sido associados a níveis de prolactina superiores a 200 ng/mL<sup>13</sup> .  
A determinação inicial da prolactina sérica pode ser verificada em qualquer período do dia, devendo-se, entretanto, evitar estresse excessivo na punção venosa. Uma única determinação é geralmente suficiente para estabelecer o diagnóstico<sup>13</sup> .  
A pesquisa da macroprolactinemia é realizada pelo teste de precipitação, que se baseia na insolubilidade das imunoglobulinas após exposição a concentrações definidas de polietilenoglicol (PEG). Após o procedimento, recuperações menores do que 30% da prolactina estabelecem diagnóstico de macroprolactinemia, enquanto recuperações maiores do que 65% afastam o diagnóstico. Valores intermediários de recuperação (entre 30%-65%) não permitem um diagnóstico preciso e, nestes casos, é necessário solicitar cromatografia líquida em coluna de filtração por gel para a definição do problema<sup>17,18</sup> .  
Além da macroprolactinemia, um outro cuidado que se deve ter na avaliação laboratorial de pacientes com hiperprolactinemia é o efeito gancho. O efeito gancho caracteriza-se pela leitura de valores pouco elevados da prolactina e deve ser considerado em todos os casos de macroadenomas da hipófise com 3 cm ou mais associados a níveis de prolactina ≤ 200 ng/mL<sup>12</sup> . Para excluí-lo, deve-se solicitar dosagem da prolactina em soro diluído<sup>19</sup> . O diagnóstico diferencial se faz com os chamados “pseudoprolactinomas”, que são lesões selares ou perisselares que provocam hiperprolactinemia por compressão da haste hipofisária e não por produção excessiva de prolactina pela lesão. Nestes últimos, o nível de prolactina após diluição será semelhante ao pré-diluição, enquanto que nos macroprolactinomas hipofisários com efeito gancho, a dosagem da prolactina após diluição da amostra indicará valores extremamente altos de prolactina sérica, compatíveis com o tamanho do tumor<sup>19</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **3.4. Diagnóstico etiológico** -->
Uma vez confirmada a hiperprolactinemia, afastadas causas medicamentosas, fisiológicas, hipotireoidismo primário e insuficiências renal e hepática, o paciente deve ser submetido à Ressonância Magnética (RM) de hipófise para a avaliação da presença de prolactinoma. A Tomografia Computadorizada (TC) é menos efetiva do que a RM para a identificação dos tumores, principalmente dos microprolactinomas, mas pode ser útil na impossibilidade ou contraindicação da realização da RM. Por outro lado, TC ou RM de hipófise normal não excluem a presença de um microprolactinoma, pois muitas dessas lesões podem ser imperceptíveis ao exame de imagem, por suas dimensões reduzidas<sup>14</sup> .  
O diagnóstico da hiperprolactinemia encontra-se resumido na **Figura 1** .  
<!-- Start of picture text -->
Hiperprolactinemia<br>Detecção ao acaso e<br>ausência de sinais e<br>Sim<br>sintomas relacionados?<br>Não<br>Pesquisa de<br>macroprolactina<br>Afastar causas fisiológicas,<br>farmacológicas,  Positiva<br>Negativa<br>hipotireoidismo primário,<br>insuficiência renal e hepática<br>Macroprolactinemia<br>Ressonância<br>Magnética  ou<br>Tomografia<br>computadorizada<br>de hipófise?<br>Lesão ≥ 1 cm<br>Lesão < 1 cm<br>Nível de prolactina<br>Microprolactinoma<br>compatível com o<br>tamanho do tumor? Sim<br>Não<br>Macroprolactinoma<br>Prolactina diluída<br>Não ≤ 200 ng/mL? Sim<br>Macroprolactinoma Compressão da haste hipofisária por<br>outros tumores não prolactinoma<br><!-- End of picture text -->  
**Figura 1 -** Fluxograma de diagnóstico da hiperprolactinemia

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que apresentarem dois dos critérios abaixo, sendo o primeiro critério obrigatório:  
- níveis de prolactina maior que o limite superior da normalidade de acordo com o método de dosagem utilizado **e**  
- TC ou RM de hipófise demonstrando macroprolactinoma **ou**  
- TC ou RM de hipófise demonstrando microprolactinoma associado à clínica de hiperprolactinemia ou hipogonadismo **ou**  
- TC ou RM de hipófise normal, mas associado à clínica de hiperprolactinemia ou hipogonadismo.  
**5. CRITÉRIOS DE EXCLUSÃO**  
Serão excluídos deste Protocolo os pacientes que apresentarem qualquer um dos critérios abaixo:  
- hipotireoidismo primário como causa da hiperprolactinemia;  
- hiperprolactinemia secundária a medicamento (exceções relatadas em casos especiais);  
- gestação e amamentação como causa da hiperprolactinemia;  
- hiperprolactinemia por compressão da haste hipofisária (pseudoprolactinomas); ou  
- intolerância, hipersensibilidade ou contraindicação ao uso do respectivo medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **6.1. Hiperprolactinemia induzida por medicamentos** -->
Para os pacientes com hiperprolactinemia induzida por medicamentos, o tratamento primário consiste em suspendêlo ou substituí-lo por outro fármaco que não cause a alteração hormonal ou suspendê-lo. Isso deve ser realizado em conjunto com o médico assistente do paciente<sup>4</sup> . Os agonistas dopaminérgicos devem ser utilizados apenas em casos bem específicos, sem alternativas, sempre com acompanhamento clínico<sup>4,13</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **6.2. Hiperprolactinemia na gestação** -->
Em mulheres que desejem gestar ou, mesmo durante a gestação em casos selecionados, o tratamento com agonistas dopaminérgicos pode ser indicado. Inexiste evidência de maior risco nessas pacientes, tanto com bromocriptina quanto com cabergolina. A segurança do uso da classe está bem estabelecida, mas há mais evidências de segurança com o uso de bromocriptina (6.000 gestações relatadas _versus_ 1.200 com cabergolina). Preconiza-se o menor tempo de uso possível nas gestantes, principalmente no primeiro trimestre. Para as mulheres com microprolactinomas ou hiperprolactinemia idiopática, preconiza-se a suspensão do agonista assim que confirmada a gravidez. Em relação aos macroprolactinomas, não existe consenso sobre a melhor maneira de acompanhá-los durante a gestação. O ideal é que a paciente seja tratada por no mínimo um ano e que seja confirmada a redução do tumor antes da gravidez. Pacientes com macroprolactinoma podem apresentar maior risco de crescimento tumoral durante a gestação e devem ser apropriadamente acompanhadas<sup>12,14,20-33</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **6.3. Hiperprolactinemia na Insuficiência Renal (IR)** -->
Pacientes com IR podem ter hiperprolactinemia moderada pelo prejuízo da degradação da prolactina e por alteração da regulação central. A hiperprolactinemia pode contribuir nos sintomas de hipogonadismo da IR,  que podem melhorar com o uso de agonistas dopaminérgicos<sup>13</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7. TRATAMENTO** -->
O objetivo primário do tratamento de pacientes com microprolactinoma ou hiperprolactinemia idiopática é tratar os sintomas decorrentes da hiperprolactinemia. Para os macroprolactinomas, além do controle hormonal e sintomático, a redução e o controle do tamanho tumoral também são objetivos do tratamento<sup>13,14,33</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7.1. Tratamento medicamentoso** -->
Os agonistas dopaminérgicos constituem a primeira opção de tratamento. Esses fármacos normalizam os níveis de prolactina, restauram a função gonadal e reduzem, significativamente, o volume tumoral dos prolactinomas na maioria dos pacientes<sup>12,34</sup> .  
A cabergolina é um agonista específico do receptor D2 da dopamina. As taxas de normalização de prolactina e de redução tumoral são de 76,5% a 93% e de 67% a 92%, respectivamente<sup>5,34-40</sup> . Pela melhor tolerância e evidências de maior efetividade, a cabergolina é considerada superior à bromocriptina no tratamento da hiperprolactinemia, sendo o medicamento de primeira escolha para a maioria dos pacientes<sup>12,13,20</sup> .  
A bromocriptina tem sido utilizada há mais de 25 anos no tratamento da hiperprolactinemia, apresentando taxas de 48%-72% de normalização da prolactina<sup>5,35-37,41,42</sup> e de aproximadamente 70% na redução dos macroprolactinomas<sup>38,43,44</sup> . Os efeitos adversos são semelhantes aos da cabergolina, porém, acontecem com uma frequência maior (acometem de 20%-78% dos usuários)<sup>5,36,37,39</sup> . O uso de bromocriptina fica reservado para mulheres com hiperprolactinemia e desejo de engravidar, pela maior segurança e experiência com o uso deste medicamento em gestantes (vide casos especiais)<sup>20</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7.1.1. Fármacos** -->
 Cabergolina: comprimidos de 0,5 mg.  
 Mesilato de bromocriptina: comprimidos de 2,5 mg.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7.1.2. Esquemas de Administração** -->
 Cabergolina: possui uma meia-vida longa e, em geral, é administrada semanalmente. Preconiza-se iniciar com 0,25 mg, por via oral, duas vezes por semana ou 0,5 mg uma vez por semana; incrementos de 0,25 mg a 1 mg duas vezes por semana podem ser realizados, a intervalos de no mínimo 4 semanas, conforme necessidade. Em geral, a dose administrada semanalmente varia de 1 a 2 mg. Em algumas situações, doses acima de 3 mg/semana são necessárias, podendo chegar até no máximo de 4,5 mg/semana<sup>48</sup> .  
 Mesilato de bromocriptina: Preconiza-se iniciar com 1,25 mg, por via oral, depois do jantar ou na hora de dormir, durante uma semana; então, aumentar para 1,25 mg duas vezes por dia (depois do café da manhã e depois do jantar ou na hora de dormir). Incrementos de dose de 2,5 mg podem ser realizados a cada três a sete dias até a dose necessária para obter o resultado de tratamento, até o limite de 20 mg<sup>49</sup> .  
O tratamento com agonistas dopaminérgicos para prolactinomas é contínuo, com tempo mínimo preconizado de dois anos. Não há tempo máximo de tratamento. Uma vez suspenso o agonista dopaminérgico, a hiperprolactinemia pode recidivar, geralmente sem novo crescimento tumoral<sup>13</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7.1.3. Efeitos adversos** -->
O perfil de segurança da cabergolina é similar ao da bromocriptina, sendo os efeitos adversos mais comuns náusea, vômitos, cefaleia, tontura e hipotensão postural. No entanto, a cabergolina apresenta esses efeitos com menor frequência, gravidade e duração, podendo haver resolução no seguimento ou com redução da dose. A suspensão do tratamento devido a efeitos adversos é mais comum com a bromocriptina do que com a cabergolina (aproximadamente 12% _vs._ 4%). Para melhorar a tolerância e aderência, preconiza-se iniciar com dose baixa e aumentar gradualmente<sup>5,13,19,34,36,37,39,40,45,46</sup> .  
Altas doses semanais de agonistas dopaminérgicos são necessárias em poucos pacientes com prolactinomas resistentes, os quais não normalizam a prolactina ou que não mostram redução significativa do tamanho tumoral. Nestes casos, o uso de cabergolina deve ser feito com cuidado pelo risco potencial de valvulopatia cardíaca e alterações psiquiátricas. Esses efeitos adversos menos frequentes devem ser observados e a realização de ecocardiograma, suspensão do medicamento e avaliações com especialistas ficam a critério do médico prescritor<sup>12,13,50-60</sup> .  
Fístula liquórica, embora rara, pode ocorrer durante o tratamento de macroadenomas com erosão do soalho selar. Pacientes com macroadenoma com essa característica devem ser alertados a procurar atendimento se apresentarem saída de líquido claro pelas narinas<sup>61,62</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7.2. Tratamento cirúrgico** -->
Até 10% dos pacientes com macroprolactinoma podem requerer cirurgia, caso não ocorra resposta aos agonistas dopaminérgicos ou, ainda, se o comprometimento visual não melhorar com o tratamento medicamentoso. Nesses casos, a retirada parcial da massa tumoral pode também proporcionar melhor resposta ao tratamento com agonista dopaminérgico. Outras possíveis indicações para o tratamento cirúrgico incluem macroprolactinomas císticos que causem sintomas neurológicos, apoplexia com comprometimento neurológico, intolerância aos agonistas dopaminérgicos e fístula liquórica<sup>12-</sup> 14,61,62. A cirurgia por via transesfenoidal é a conduta preferencial, enquanto a craniotomia deve ser a abordagem reservada para tumores inacessíveis por essa primeira via<sup>63,64</sup> .  
Os determinantes mais importantes para atingir taxas de normalização da prolactina com o tratamento cirúrgico são a experiência da equipe cirúrgica, o nível de prolactina antes da cirurgia (melhores resultados com níveis de prolactina <200 ng/mL) e tamanho/invasividade do tumor<sup>12</sup> .  A taxa de normalização da prolactina ocorre em média em 75%-80% dos pacientes com microprolactinomas e em 30%-40% dos macroprolactinomas<sup>63-66</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7.3. Radioterapia** -->
Entre os tumores hipofisários funcionantes, os prolactinomas parecem ser os menos responsivos à radioterapia. Por isso, essa modalidade de tratamento deve ser reservada para pacientes com tumores agressivos ou prolactinomas malignos, não responsivos aos agonistas dopaminérgicos e à cirurgia<sup>12</sup> . A radioterapia pode ser feita por feixe externo (radioterapia convencional) ou com técnicas estereotáxicas. A taxa de normalização da prolactina com ambas as técnicas é semelhante, na ordem de 30%<sup>63</sup> . Essa baixa efetividade e os efeitos adversos em longo prazo da radioterapia (hipopituitarismo, acidentes vasculares cerebrais, tumores de sistema nervoso central) limitam o seu uso<sup>12</sup> .

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **7.4. Benefícios esperados** -->
- Redução ou normalização dos níveis da prolactina;  
- redução do tumor (nos casos de macroprolactinoma), com alívio dos sintomas associados, tais como distúrbios visuais e alterações nos nervos cranianos; e  
- melhora ou resolução dos sintomas associados à hiperprolactinemia.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **8.1. Hiperprolactinemia idiopática ou microprolactinoma** -->
A dosagem de prolactina para ajuste de dose do agonista dopaminérgico no primeiro ano de tratamento pode ser realizada a intervalos de 3 meses ou até a normalização da mesma. Uma vez alcançado este objetivo, a dose deve ser ajustada levando-se em conta a dosagem da prolactina realizada a cada 6 a 12 meses. Se a prolactina estiver acima do valor de referência, a dose pode ser aumentada em um comprimido de 0,5 mg semanal de cabergolina ou um comprimido diário de 2,5 mg de bromocriptina, com reavaliação da prolactina após 6 meses ou a critério médico. O aumento de dose pode ser progressivo até 4,5 mg semanal de cabergolina ou 20 mg diários de bromocriptina. Caso não haja normalização com a dose máxima, deve-se avaliar troca para outro agonista ou outra opção terapêutica<sup>13</sup> .  
É desejável que haja resolução dos sintomas, seja do hipogonadismo ou da galactorreia, em paralelo à redução/normalização da prolactina. Em alguns casos, a melhora clínica ocorre mesmo com prolactina ainda elevada, podendo não ser aumentada a dose do agonista dopaminérgico<sup>14</sup> .  
A dose do agonista dopaminérgico deve ser ajustada ao longo do tratamento. Segue proposta de orientação para o ajuste: se o resultado da prolactina estiver na metade superior do normal, a dose pode ser mantida e a prolactina reavaliada em 6 meses. Se a prolactina estiver na metade inferior do normal ou abaixo do normal, a dose do agonista pode ser reduzida, com reavaliação em 6 meses. Esquemas de ajuste de doses propostos para cabergolina e bromocriptina são mostrados no Quadro 1.  
Após 24 meses de tratamento, se a prolactina estiver normal e estável com a dose mínima do agonista (0,25 mg de cabergolina/semana ou 1,25 mg de bromocriptina/dia), o medicamento pode ser suspenso e a prolactina reavaliada a cada 3 meses durante o primeiro ano da suspensão e, após, a intervalos anuais ou mais frequentes, se os sintomas retornarem. Neste caso, o medicamento pode ser reiniciado, principalmente quando os sintomas estiverem associados à elevação da prolactina 12-14,67,68.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **8.2. Macroprolactinoma** -->
A dosagem de prolactina para ajuste do agonista dopaminérgico, durante o primeiro ano de tratamento, pode ser realizada a cada 3 meses ou até a normalização da mesma. A TC ou a RM de hipófise devem ser realizadas de 3 a 6 meses do início do medicamento para confirmação da redução do tamanho do tumor, como resposta ao tratamento<sup>13</sup> . Uma vez alcançado o objetivo, a dose deve ser ajustada levando-se em conta a dosagem da prolactina realizada a cada 6 a 12 meses, com as mesmas orientações do microprolactinoma, conforme **Quadro 1** .  
Confirmadas a redução do tumor e a resolução dos efeitos compressivos sobre estruturas cerebrais, como o quiasma óptico, nova imagem por TC ou RM será indicada apenas se houver sintomas sugestivos de crescimento tumoral ou a critério médico<sup>13</sup> .  
Pacientes em tratamento clínico que não apresentam redução tumoral na primeira avaliação devem ser investigados, considerando duas possibilidades: 1- Tumor produtor de hormônio de crescimento e prolactina, sendo necessária a dosagem de IGF-1 para confirmar o diagnóstico após suspensão do agonista dopaminérgico, preferencialmente ou 2- Prolactinoma resistente, sendo indicado o aumento da dose ou tratamento cirúrgico<sup>12,13</sup> .  
O tratamento medicamentoso também poderá ser suspenso após no mínimo dois anos, desde que tenha havido redução maior de 50% do volume tumoral inicial e normalização da prolactina, com dose mínima do agonista (0,25 mg de cabergolina/semana ou 1,25 mg de bromocriptina/dia). A prolactina deve ser reavaliada a intervalos de 3 meses durante o primeiro ano da suspensão do agonista, anualmente após ou, tempestivamente, se ocorrerem sintomas relacionados à hiperprolactinemia<sup>12-14,67,68</sup> . Caso haja retorno da hiperprolactinemia, o medicamento poderá ser reintroduzido, conforme Quadro 1.  
**Quadro 1 -** Monitoramento do tratamento com agonistas dopaminérgicos<sup>12-14,64,65</sup> .  
||**Micropro**|**lactinoma**|**Macroprola**|**ctinoma**|
|---|---|---|---|---|
||**Cabergolina**|**Bromocriptina**|**Cabergolina**|**Bromocriptina**|
|1ª semana de<br>tratamento|0,25 mg 2 x semana|1,25 mg 2 x dia|0,25 mg 2 x semana|1,25 mg 2 x dia|
|Até avaliação de 3<br>meses de tratamento|0,5 mg 2 x semana|2,5 mg 2 x dia|0,5 mg 3 x semana|2,5 mg 3 x dia|
||REAVALIAR A DO|SAGEM DE PROLAC<br>SUA NORMAL<br>APÓS - PRL A CADA|TINA A CADA 3 MES<br>IZAÇÃO.<br>6 A 12 MESES.|ES OU ATÉ A|
|Se PRL acima do<br>normal|Aumentar 0,25 a 0,5<br>mg/semana*|Aumentar 1,25 a 2,5<br>mg 1 x dia*|Aumentar 0,25 a 0,5<br>mg/semana*|Aumentar 1,25<br>a 2,5 mg 1 x<br>dia*|  
|Se PRL na metade<br>superior do normal||MANTER A DOSE|DO AGONISTA||
|---|---|---|---|---|
|Se PRL normal ou|||||
|<br>na metade inferior<br>do normal|Reduzir 0,25 a 0,5<br>mg/semana*<br>APÓS 2|Reduzir 1,25 a 2,5<br>mg 1 x dia*<br>ANOS DE TRATAME|Reduzir 0,25 a 0,5<br>mg/semana<br>NTO|Reduzir 1,25 a<br>2,5 mg 1 x dia|
|Medicamento pode<br>ser suspenso SE:|PRL normal com<br>0,25 mg/semana|PRL normal com<br>1,25 mg/dia|PRL normal com<br>0,25 mg/semana e<br>redução tumoral ><br>50%|PRL normal<br>com 1,25<br>mg/dia e<br>redução<br>tumoral > 50%|
|Seguimento após a<br>suspensão do<br>medicamento|DOSAGEM DE P<br>SUSPENSÃO E DE|ROLACTINA A CADA<br>POIS ANUALMENTE<br>RETORNO DOS|3 MESES NO PRIME<br>, OU A QUALQUER<br>SINTOMAS.|IRO ANO DE<br>MOMENTO SE|
|Quando avaliar<br>imagem por TC ou<br>RM|Pré-trat<br>Depois, apenas a|amento.<br>critério médico.|Pré-tratamento; a<br>tratamento para con<br>do tumor; depois, a c<br>na ocasião de su<br>medicam|té 6 meses de<br>firmar a redução<br>ritério médico ou<br>spensão do<br>ento.|  
*Até o máximo de 4,5 mg/semana de Cabergolina ou 20 mg/dia de Bromocriptina. Legenda: PRL= Prolactina; TC= tomografia computadorizada de sela túrcica; RM= ressonância magnética da hipófise.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas, a adequação de uso do e o acompanhamento pós-tratamento.  
Doentes de hiperprolactinemia devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no Protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **10. REFERÊNCIAS** -->
1. Colao A, Lombardi G. Growth-hormone and prolactin excess. Lancet. 1998;352(9138):1455-61. 2. Soto-Pedre E, Newey P, Bevan J, Greig N, Leese G. The epidemiology of hyperprolactinemia over 20 years in the Tayside region of Scotland: the Prolactin Epidemiology, Audit and Research Study (PROLEARS). Clinical Endocrinology. 2017;86(1):60-7.  
3. Young S, Taylor M, Lawrie S. "First do no harm". A systematic review of the prevalence and management of antipsychotic adverse effects. J Psychopharmacology. 2015;29(4):353-62.  
4. Molitch ME. Medication-induced hyperprolactinemia. Mayo Clin Proc. 2005;80(8):1050-7.  
5. Vilar L, Freitas MC, Naves LA, Casulari LA, Azevedo M, Montenegro R, et al. Diagnosis and management of hyperprolactinemia: results of a Brazilian multicenter study with 1234 patients. J Endocrinol Invest. 2008;31(5):436-44.  
6. Glezer A, Bronstein MD. Prolactinomas. Endocrinol Metab Clin North Am. 2015;44(1):71-8.  
7. Chanson P, Maiter D. The epidemiology, diagnosis and treatment of Prolactinomas: The old and the new. Best Pract Res Clin Endocrinol Metab. 2019;33(2):101290.  
8. Raappana A, Koivukangas J, Ebeling T, Pirilä T. Incidence of pituitary adenomas in Northern Finland in 1992-2007. J Clin Endocrinol Metab. 2010;95(9):4268-75.  
9. Zhang F, Huang Y, Ding C, Huang G, Wang S. The prevalence of hyperprolactinemia in non-functioning pituitary macroadenomas. International Journal of Clinical and Experimental Medicine. 2015;8(10):18981-9.  
10. Duarte FH, Machado MC, Lima JR, Salgado LR. Severe hyperprolactinemia associated with internal carotid artery aneurysm: differential diagnosis between prolactinoma and hypothalamic-pituitary disconnection. Arq Bras Endocrinol Metabol. 2008;52(7):1189-93.  
11. Chahal J, Schlechte J. Hyperprolactinemia. Pituitary. 2008;11(2):141-6.  
12. Vilar L, Abucham J, Albuquerque JL, Araujo LA, Azevedo MF, Boguszewski CL, et al. Controversial issues in the management of hyperprolactinemia and prolactinomas - An overview by the Neuroendocrinology Department of the Brazilian Society of Endocrinology and Metabolism. Arch Endocrinol Metab. 2018;62(2):236-63.  
13. Melmed S, Casanueva FF, Hoffman AR, Kleinberg DL, Montori VM, Schlechte JA, et al. Diagnosis and treatment of hyperprolactinemia: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab. 2011;96(2):273-88.  
14. Casanueva FF, Molitch ME, Schlechte JA, Abs R, Bonert V, Bronstein MD, et al. Guidelines of the Pituitary Society for the diagnosis and management of prolactinomas. Clin Endocrinol (Oxf). 2006;65(2):265-73. 15. Glezer A, Soares CR, Vieira JG, Giannella-Neto D, Ribela MT, Goffin V, et al. Human macroprolactin displays low biological activity via its homologous receptor in a new sensitive bioassay. J Clin Endocrinol Metab. 2006;91(3):1048-55. 16. Vieira JGH. Macroprolactinemia. Arq Bras Endocrinol Metab. 2002;46(1). 17. Vieira JG, Tachibana TT, Obara LH, Maciel RM. Extensive experience and validation of polyethylene glycol precipitation as a screening method for macroprolactinemia. Clin Chem. 1998;44(8 Pt 1):1758-9.  
18. de Soárez PC, Souza SC, Vieira JG, Ferraz MB. The effect of identifying macroprolactinemia on health-care utilization and costs in patients with elevated serum prolactin levels. Value Health. 2009;12(6):930-4.  
19. Vilar L, Vilar CF, Lyra R, Freitas MDC. Pitfalls in the Diagnostic Evaluation of Hyperprolactinemia. Neuroendocrinology. 2019;109(1):7-19.  
20. Konopka P, Raymond JP, Merceron RE, Seneze J. Continuous administration of bromocriptine in the prevention of neurological complications in pregnant women with prolactinomas. Am J Obstet Gynecol. 1983;146(8):935-8.  
21. Krupp P, Monka C. Bromocriptine in pregnancy: safety aspects. Klin Wochenschr. 1987;65(17):823-7. 22. Ciccarelli E, Grottoli S, Razzore P, Gaia D, Bertagna A, Cirillo S, et al. Long-term treatment with cabergoline, a new long-lasting ergoline derivate, in idiopathic or tumorous hyperprolactinaemia and outcome of drug-induced pregnancy. J Endocrinol Invest. 1997;20(9):547-51.  
23. Jones J, Bashir T, Olney J, Wheatley T. Cabergoline treatment for a large macroprolactinoma throughout pregnancy. J Obstet Gynaecol. 1997;17(4):375-6.  
24. Liu C, Tyrrell JB. Successful treatment of a large macroprolactinoma with cabergoline during pregnancy. Pituitary. 2001;4(3):179-85.  
25. Ricci E, Parazzini F, Motta T, Ferrari CI, Colao A, Clavenna A, et al. Pregnancy outcome after cabergoline treatment in early weeks of gestation. Reprod Toxicol. 2002;16(6):791-3.  
26. Robert E, Musatti L, Piscitelli G, Ferrari CI. Pregnancy outcome after treatment with the ergot derivative, cabergoline. Reprod Toxicol. 1996;10(4):333-7. 27. Colao A, Abs R, Bárcena DG, Chanson P, Paulus W, Kleinberg DL. Pregnancy outcomes following cabergoline treatment: extended results from a 12-year observational study. Clin Endocrinol (Oxf). 2008;68(1):66-71. 28. Banerjee A, Wynne K, Tan T, Hatfield EC, Martin NM, Williamson C, et al. High dose cabergoline therapy for a resistant macroprolactinoma during pregnancy. Clin Endocrinol (Oxf). 2009;70(5):812-3. 29. Laloi-Michelin M, Ciraru-Vigneron N, Meas T. Cabergoline treatment of pregnant women with macroprolactinomas. Int J Gynaecol Obstet. 2007;99(1):61-2. 30. Sant' Anna BG, Musolino NRC, Gadelha MR, Marques C, Castro M, Elias PCL, et al. A Brazilian multicentre study evaluating pregnancies induced by cabergoline in patients harboring prolactinomas. Pituitary. 2019. 31. Rastogi A, Bhadada SK, Bhansali A. Pregnancy and tumor outcomes in infertile women with macroprolactinoma on cabergoline therapy. Gynecol Endocrinol. 2017;33(4):270-3.  
32. Molitch ME. Endocrinology in pregnancy: management of the pregnant patient with a prolactinoma. Eur J Endocrinol. 2015;172(5):R205-13. 33. Dabbous Z, Atkin SL. Hyperprolactinaemia in male infertility: Clinical case scenarios. Arab J Urol. 2018;16(1):4452.  
34. dos Santos Nunes V, El Dib R, Boguszewski CL, Nogueira CR. Cabergoline versus bromocriptine in the treatment of hyperprolactinemia: a systematic review of randomized controlled trials and meta-analysis. Pituitary. 2011;14(3):259-65.  
35. Sabuncu T, Arikan E, Tasan E, Hatemi H. Comparison of the effects of cabergoline and bromocriptine on prolactin levels in hyperprolactinemic patients. Intern Med. 2001;40(9):857-61.  
36. Pascal-Vigneron V, Weryha G, Bosc M, Leclere J. [Hyperprolactinemic amenorrhea:treatment with cabergoline versus bromocriptine. Results of a national multicenter randomized double-blind study]. Presse Med. 1995;24(16):753-7. 37. Webster J, Piscitelli G, Polli A, Ferrari CI, Ismail I, Scanlon MF. A comparison of cabergoline and bromocriptine in the treatment of hyperprolactinemic amenorrhea. Cabergoline Comparative Study Group. N Engl J Med. 1994;331(14):9049.  
38. Colao A, Pivonello R, Di Somma C, Savastano S, Grasso LF, Lombardi G. Medical therapy of pituitary adenomas: effects on tumor shrinkage. Rev Endocr Metab Disord. 2009;10(2):111-23.  
39. Bolko P, Jaskuła M, Waśko R, Wołuń M, Sowiński J. The assessment of cabergoline efficacy and tolerability in patients with pituitary prolactinoma type. Pol Arch Med Wewn. 2003;109(5):489-95.  
40. Di Sarno A, Landi ML, Cappabianca P, Di Salle F, Rossi FW, Pivonello R, et al. Resistance to cabergoline as compared with bromocriptine in hyperprolactinemia: prevalence, clinical definition, and therapeutic strategy. J Clin Endocrinol Metab. 2001;86(11):5256-61.  
41. Berinder K, Stackenäs I, Akre O, Hirschberg AL, Hulting AL. Hyperprolactinaemia in 271 women: up to three decades of clinical follow-up. Clin Endocrinol (Oxf). 2005;63(4):450-5. 42. Touraine P, Plu-Bureau G, Beji C, Mauvais-Jarvis P, Kuttenn F. Long-term follow-up of 246 hyperprolactinemic patients. Acta Obstet Gynecol Scand. 2001;80(2):162-8. 43. Molitch ME, Elton RL, Blackwell RE, Caldwell B, Chang RJ, Jaffe R, et al. Bromocriptine as primary therapy for prolactin-secreting macroadenomas: results of a prospective multicenter study. J Clin Endocrinol Metab. 1985;60(4):698705.  
44. Colao A, Di Sarno A, Guerra E, De Leo M, Mentone A, Lombardi G. Drug insight: Cabergoline and bromocriptine in the treatment of hyperprolactinemia in men and women. Nat Clin Pract Endocrinol Metab. 2006;2(4):200-10.  
45. Al-Husaynei AJM IS, Al-Jubori ZS. Comparasion of the effects of cabergoline and bromocriptine in women with hyperprolactinemic amenorrhea. Middle East Fertility Society Journal2008. p. 13-6.  
46. De Rosa M, Colao A, Di Sarno A, Ferone D, Landi ML, Zarrilli S, et al. Cabergoline treatment rapidly improves gonadal function in hyperprolactinemic males: a comparison with bromocriptine. Eur J Endocrinol. 1998;138(3):286-93.  
47. Serri O. Progress in the management of hyperprolactinemia. N Engl J Med. 1994;331(14):942-4. 48. Anvisa Bd. Cabergolina. 2019.  
49. Anvisa Bd. Bromocriptina. 2020.  
50. Schade R, Andersohn F, Suissa S, Haverkamp W, Garbe E. Dopamine agonists and the risk of cardiac-valve regurgitation. N Engl J Med. 2007;356(1):29-38.  
51. Zanettini R, Antonini A, Gatto G, Gentile R, Tesei S, Pezzoli G. Valvular heart disease and the use of dopamine agonists for Parkinson's disease. N Engl J Med. 2007;356(1):39-46.  
52. Kars M, Pereira AM, Bax JJ, Romijn JA. Cabergoline and cardiac valve disease in prolactinoma patients: additional studies during long-term treatment are required. Eur J Endocrinol. 2008;159(4):363-7.  
53. Drake WM, Stiles CE, Howlett TA, Toogood AA, Bevan JS, Steeds RP. A cross-sectional study of the prevalence of cardiac valvular abnormalities in hyperprolactinemic patients treated with ergot-derived dopamine agonists. J Clin Endocrinol Metab. 2014;99(1):90-6.  
54. Gamble D, Fairley R, Harvey R, Farman C, Cantley N, Leslie SJ. Screening for valve disease in patients with hyperprolactinaemia disorders prescribed cabergoline: a service evaluation and literature review. Ther Adv Drug Saf. 2017;8(7):215-29.  
55. Stiles CE, Tetteh-Wayoe ET, Bestwick J, Steeds RP, Drake WM. A meta-analysis of the prevalence of cardiac valvulopathy in hyperprolactinemic patients treated with Cabergoline. J Clin Endocrinol Metab. 2018.  
56. Ioachimescu AG, Fleseriu M, Hoffman AR, Vaughan Iii TB, Katznelson L. Psychological effects of dopamine agonist treatment in patients with hyperprolactinemia and prolactin-secreting adenomas. Eur J Endocrinol. 2019;180(1):31-40.  
57. Dogansen SC, Cikrikcili U, Oruk G, Kutbay NO, Tanrikulu S, Hekimsoy Z, et al. Dopamine Agonist-Induced Impulse Control Disorders in Patients With Prolactinoma: A Cross-Sectional Multicenter Study. J Clin Endocrinol Metab. 2019;104(7):2527-34.  
58. De Sousa SMC, Baranoff J, Rushworth RL, Butler J, Sorbello J, Vorster J, et al. Impulse control disorders in dopamine agonist-treated hyperprolactinemia: prevalence and risk factors. J Clin Endocrinol Metab. 2019.  
59. Barake M, Klibanski A, Tritos NA. MANAGEMENT OF ENDOCRINE DISEASE: Impulse control disorders in patients with hyperpolactinemia treated with dopamine agonists: how much should we worry? Eur J Endocrinol. 2018;179(6):R287-R96.  
60. Celik E, Ozkaya HM, Poyraz BC, Saglam T, Kadioglu P. Impulse control disorders in patients with prolactinoma receiving dopamine agonist therapy: a prospective study with 1 year follow-up. Endocrine. 2018;62(3):692-700.  
61. Bronstein MD, Musolino NR, Benabou S, Marino R. Cerebrospinal fluid rhinorrhea occurring in long-term bromocriptine treatment for macroprolactinomas. Surg Neurol. 1989;32(5):346-9.  
62. Lam G, Mehta V, Zada G. Spontaneous and medically induced cerebrospinal fluid leakage in the setting of pituitary adenomas: review of the literature. Neurosurg Focus. 2012;32(6):E2.  
63. Primeau V, Raftopoulos C, Maiter D. Outcomes of transsphenoidal surgery in prolactinomas: improvement of hormonal control in dopamine agonist-resistant patients. Eur J Endocrinol. 2012;166(5):779-86.  
64. Gillam MP, Molitch ME, Lombardi G, Colao A. Advances in the treatment of prolactinomas. Endocr Rev. 2006;27(5):485-534.  
65. Zamanipoor Najafabadi AH, Zandbergen IM, de Vries F, Broersen LHA, van den Akker-van Marle ME, Pereira AM, et al. Is Surgery as a viable alternative first-line treatment for prolactinoma patients? A systematic review and meta-analysis. J Clin Endocrinol Metab. 2019.  
66. Vroonen L, Jaffrain-Rea ML, Petrossians P, Tamagno G, Chanson P, Vilar L, et al. Prolactinomas resistant to standard doses of cabergoline: a multicenter study of 92 patients. Eur J Endocrinol. 2012;167(5):651-62.  
67. Xia MY, Lou XH, Lin SJ, Wu ZB. Optimal timing of dopamine agonist withdrawal in patients with hyperprolactinemia: a systematic review and meta-analysis. Endocrine. 2018;59(1):50-61.  
68. Hu J, Zheng X, Zhang W, Yang H. Current drug withdrawal strategy in prolactinoma patients treated with cabergoline: a systematic review and meta-analysis. Pituitary. 2015;18(5):745-51.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Mesilato de bromocriptina e Cabergolina.  
Eu, ___________________________________________________________ (nome do [a] paciente), abaixo identificado (a) e firmado (a), declaro ter sido informado (a) claramente sobre todas as indicações, contraindicações, principais efeitos colaterais e riscos relacionados ao uso dos medicamentos mesilato de bromocriptina e cabergolina indicados para o tratamento da hiperprolactinemia.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso o tratamento seja interrompido.  
Os termos médicos foram explicados e todas as minhas dúvidas foram esclarecidas pelo médico_______________________________________________(nome do médico que prescreve).  
Expresso também minha concordância e espontânea vontade em submeter-me ao referido tratamento, assumindo a responsabilidade e os riscos por eventuais efeitos indesejáveis.  
Assim, declaro que:  
Fui claramente informado (a) que caso os meus sintomas sejam decorrentes da hiperprolactinemia, esses medicamentos podem trazer os seguintes benefícios:  
- redução ou normalização dos níveis da prolactina;  
- redução do tumor da hipófise (adenoma), com alívio dos sintomas associados, tais como: distúrbios visuais e alterações nos nervos cranianos; e  
- melhora ou resolução dos sintomas associados à hiperprolactinemia;  
Fui também claramente informado(a) a respeito das seguintes contraindicações, e potenciais efeitos colaterais e  
riscos:  
- Estes medicamentos foram classificados na gestação como fator de risco B, ou seja, estudos em animais não mostraram anormalidades nos seus descendentes. São necessários mais estudos sobre estes medicamentos em seres humanos, porém o risco de qualquer alteração para o bebê é muito improvável.  
- O mesilato de bromocriptina pode causar náusea, vômitos, dor de cabeça, tontura, cansaço, alterações digestivas, secura da boca, perda de apetite e congestão nasal, hipotensão ortostática, alterações dos batimentos cardíacos, inchaço de pés, perda de cabelo, psicose, alucinação, insônia, pesadelos, aumento dos movimentos do corpo, fibrose pleuropulmonar e peritoneal, pressão alta (raro).  
- A cabergolina pode causar dores de cabeça, tonturas, náusea, fraqueza, cansaço, hipotensão ortostática, desmaios, sintomas gripais, mal estar, inchaço nos olhos e pernas, calorões, pressão baixa, palpitação, vertigem, depressão, sonolência, ansiedade, insônia, dificuldade de concentração, nervosismo, espinhas, coceiras, dor no peito, distúrbios na menstruação, prisão de ventre, dores abdominais, azia, dor de estômago, vômitos, boca seca, diarreia gases, irritação na garganta, dor de dente, perda de apetite, dores no corpo e alteração da visão.  
- Esses medicamentos interferem na lactação, portanto. o uso dos mesmos durante a lactação deverá ser feito de  
- acordo com avaliação risco-benefício.  
- A suspensão do tratamento sem a autorização médica poderá ocasionar recrescimento do tumor (adenoma), recidiva  
- da hiperprolactinemia e dos sintomas iniciais.  
- Esses medicamentos são contraindicados em caso de hipersensibilidade aos mesmos.  
- O risco dos efeitos adversos aumenta com a superdosagem dos medicamentos.  
Estou ciente de que posso suspender o tratamento a qualquer momento, mas me comprometo a avisar o médico responsável caso isso venha ocorrer. Sendo que este fato não implicará qualquer forma de constrangimento entre mim e meu médico, que se dispõe a continuar me tratando em quaisquer circunstâncias.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento desde que assegurado o anonimato.   (    ) Sim     (    ) Não  
Declaro, finalmente, ter compreendido e concordado com todos os termos deste Consentimento Informado. Assim, o faço por livre e espontânea vontade e por decisão conjunta, minha e de meu médico.  
O meu tratamento constará do seguinte medicamento:  
(  ) mesilato de bromocriptine              (  ) cabergolina  
|Local:                                                                                                     Data:|
|---|
|Nome do paciente:|
|Cartão Nacional de Saúde:|
|Nome do responsável legal:|  
Documento de identificação do responsável legal:  
||__________________<br>Assinatura do paci|_________________________<br>ente ou do responsável legal||
|---|---|---|---|
|Médico Responsável:||CRM:|UF:|
||_________________<br>Assinatura<br>Data:____|_______________________<br>e carimbo do médico<br>________________||  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**APÊNDICE 1**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA  
Este PCDT se destina a profissionais da saúde, pacientes com Hiperprolactinemia e gestores do SUS. O documento foi elaborado visando a garantir o melhor cuidado de saúde e o uso racional dos recursos disponíveis no Sistema Único de Saúde.  
Depois da publicação, em 23/11/2020, da Portaria Conjunta SAES/SCTIE nº 19, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Hiperprolactinemia, pela necessidade de se adequar, no Quadro 1, a dose máxima de cabergolina em diferentes trechos do Protocolo. Para tal, foi também adequado o Relatório de Recomendação nº 563/2020 da Conitec.  
Foi verificado que a dose máxima de cabergolina estabelecida em bula é de 4,5 mg por semana, enquanto os textos, no Quadro 1 - Monitoramento do tratamento com agonistas dopaminérgicos, mencionavam a dose máxima de 7 mg por semana, o que se corrige nesta reedição, conforme foi apresentado à 97ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada no dia 22/03/2022.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **1. Escopo e finalidade do Protocolo** -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Hiperprolactinemia iniciou-se com a reunião presencial para delimitação do escopo. O objetivo desta reunião foi a discussão da atualização deste PCDT.  
Essa reunião presencial contou com a presença de seis membros do Grupo Elaborador, sendo três dos quais especialistas e três metodologistas, além de um representante de sociedade médica e quatro representantes do Comitê Gestor.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria nº 1.160/SAS/MS, de 18/11/2015) e na estrutura de PCDT definida pela Portaria n° 375/SAS/MS, de 10/11/2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas diagnósticas e terapêuticas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas, por se tratarem de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **<u>Colaboração externa</u>** -->
Além dos representantes Departamento de Gestão, Inovação e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), participaram do desenvolvimento deste Protocolo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.  
Todos os presentes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **<u>Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas</u>** -->
No dia 12 de maio de 2020, o PCDT da Hiperprolactinemia foi submetido à Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas em sua 79ª Reunião. Foi realizada apresentação do PCDT, seguida de considerações dos  
participantes. Foram apontadas necessidades de formatação e padronização do texto, assim como a inserção de referências bibliográficas em parágrafos específicos do documento. Foi indicado que o critério de inclusão está muito amplo, sem o detalhamento necessário dos métodos e níveis de aceitação para a dosagem de prolactina e solicitado melhor detalhamento. Também foi indicada a necessidade de complementação da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS com diagnósticos e medicamentos do Componente Especializado da Assistência Farmacêutica (CEAF) utilizados neste PCDT. Foi solicitado rever o apêndice metodológico, detalhando melhor a estratégia de busca, com a inclusão do fluxograma do processo de busca e seleção de artigos e complementação com literatura cinzenta.  
Previamente à reunião, foi enviado para a CPCDT o documento revisado pelo Departamento de Ciência e Tecnologia (DECIT/SCTIE/MS), e outras contribuições do Departamento de Assistência Farmacêutica (DAF/SCTIE/MS) foram recebidas por e-mail, solicitando a correção gramatical de alguns itens no texto.

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **<u>Consulta pública</u>** -->
A Consulta Pública nº 41 do PCDT da Hiperprolactinemia foi realizada entre os dias 20/08/2020 a 08/09/2020. Foram recebidas 7 contribuições no total e salienta-se que todas foram analisadas. O conteúdo integral das contribuições encontrase disponível na página da Conitec em:  
<u>http://Conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_41_2020_PCDT_Hiperprolactinemia.pdf</u>

---

<!-- METADADOS: doenca: Hiperprolactinemia | secao: **3. Busca da evidência e recomendações** -->
Para auxiliar na atualização do PCDT, foram realizadas buscas na literatura nas bases de dados PUBMED e Embase,  
conforme o **Quadro A** .  
**Quadro A -** Descrição das buscas, resultados e estudos selecionados  
|**Base**|**Estratégia**|**Localizados**|**Duplicados**|**Selecionados**|
|---|---|---|---|---|
|Medline (via<br>PUBMED)<br>Data da busca:<br>08/10/2019|"Hyperprolactinemia"[Mesh]<br>AND ((Guideline[ptyp] OR<br>Meta-Analysis[ptyp] OR<br>Practice Guideline[ptyp] OR<br>systematic[sb]) AND<br>"2014/10/10"[PDat] :<br>"2019/10/08"[PDat])|17|**8**|6<br>**Motivo das**<br>**exclusões:**<br>Não relacionados ao<br>PCDT, não<br>relevantes e artigo<br>|
|Embase<br>Data da busca:<br>08/10/2019|'hyperprolactinemia'/exp AND<br>[embase]/lim AND [2014-<br>2019]/py AND ([cochrane<br>review]/lim OR [systematic<br>review]/lim OR [meta-<br>analysis]/lim)|96||em chinês.|  
Seguem os estudos selecionados a partir das buscas e a sua citação no texto do PCDT:  
1. Dabbous Z, Atkin SL. Hyperprolactinaemia in male infertility: Clinical case scenarios. Arab J Urol. 2018;16(1):4452 – referência 33  
2. Gamble D, Fairley R, Harvey R, Farman C, Cantley N, Leslie SJ. Screening for valve disease in patients with hyperprolactinaemia disorders prescribed cabergoline: a service evaluation and literature review. Ther Adv Drug Saf. 2017;8(7):215-29 – referência 54  
3. Stiles CE, Tetteh-Wayoe ET, Bestwick J, Steeds RP, Drake WM. A meta-analysis of the prevalence of cardiac valvulopathy in hyperprolactinemic patients treated with Cabergoline. J Clin Endocrinol Metab. 2018 - referência 55  
4. Zamanipoor Najafabadi AH, Zandbergen IM, de Vries F, Broersen LHA, van den Akker-van Marle ME, Pereira AM, et al. Is Surgery as a viable alternative first-line treatment for prolactinoma patients? A systematic review and metaanalysis. J Clin Endocrinol Metab. 2019 - referência 65  
5. Xia MY, Lou XH, Lin SJ, Wu ZB. Optimal timing of dopamine agonist withdrawal in patients with hyperprolactinemia: a systematic review and meta-analysis. Endocrine. 2018;59(1):50-61 – referência 67  
6. Hu J, Zheng X, Zhang W, Yang H. Current drug withdrawal strategy in prolactinoma patients treated with cabergoline: a systematic review and meta-analysis. Pituitary. 2015;18(5):745-51 - referência 68  
Outros estudos de conhecimento dos especialistas foram incluídos para a atualização do PCDT.

---

