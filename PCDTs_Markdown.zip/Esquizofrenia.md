<!-- METADADOS: doenca: Esquizofrenia | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA Nº 364, DE 9 DE ABRIL DE 2013.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas – Esquizofrenia.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a esquizofrenia no Brasil e de se estabelecerem diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os Protocolos Clínicos e Diretrizes Terapêuticas (PCDT) são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação e posologia;  
Considerando as sugestões dadas à Consulta Pública n<sup><u>o</u></sup> 5/SAS/MS, de 14 de junho de 2012; Considerando os Registros de Deliberação n<sup><u>o</u></sup> 58/2011, n<sup><u>o</u></sup> 59/2011, n<sup><u>o</u></sup> 60/2011 e n<sup><u>o</u></sup> 61/2011, da Comissão de Incorporação de Tecnologias do Ministério da Saúde (CITEC/MS); e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC), do Departamento de Assistência Farmacêutica (DAF/SCTIE/MS) e do Departamento de Atenção Especializada (DAE/SAS/MS), resolve:  
Art. 1<sup><u>o</u></sup> Fica aprovado, na forma do Anexo a esta Portaria, o Protocolo Clínico e Diretrizes Terapêuticas – Esquizofrenia.  
§ 1<sup><u>o</u></sup> O Protocolo, objeto desta Portaria, que contém o conceito geral de esquizofrenia, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
§ 2<sup><u>o</u></sup> É obrigatória a observância deste Protocolo para fins de dispensação de medicamento nele previsto.  
Art. 2<sup><u>o</u></sup> É obrigatória a cientificação ao paciente, ou a seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de medicamento preconizado para o tratamento da esquizofrenia, o que deverá ser formalizado por meio da assinatura do Termo de Esclarecimento e Responsabilidade, conforme o modelo integrante do Protocolo.  
Art. 3<sup><u>o</u></sup> Os gestores estaduais e municipais do SUS, conforme sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4<sup><u>o</u></sup>  
Esta Portaria entra em vigor na data de sua publicação.  
Art. 5<sup><u>o</u></sup> Fica revogada a Portaria n<sup><u>o</u></sup> 846/SAS/MS, de 31 de outubro de 2002, publicada no Diário Oficial da União, de 4 de novembro de 2002, Seção 1, página 80.  
HELVÉCIO MIRANDA MAGALHÃES JÚNIOR SECRETÁRIO DE ATENÇÃO À SAÚDE  
ANEXO

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 1 METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Realizada em 10 de novembro de 2010, a busca na base de dados Medline/Pubmed com os termos “ _schizophrenia_ ”[ _Mesh_ ] _AND_ “ _treatment_ ”, limitada a estudos em humanos, em meta-análises, revisões e ensaios clínicos randomizados publicados nos últimos 10 anos, listou 3.055 estudos. Em razão do grande número de artigos encontrados, foi realizada nova busca restringindo-se a meta-análises, da qual resultaram 202 artigos. Todos eles foram revisados, tendo sido excluídos 107 que não diziam respeito a tratamento medicamentoso de esquizofrenia ou não eram metaanálises, restando, portanto, 95 trabalhos. Foram ainda acrescentados mais 29 textos não indexados considerados de relevância. Em 6 de setembro de 2011, nova busca, com os mesmos termos, resultou no acréscimo de mais 4 estudos, totalizando então 128.  
A busca na base de dados Cochrane, com o uso da mesma estratégia, realizada em setembro de 2011, listou 65 revisões sistemáticas completas. Destas, 31 já haviam sido localizadas, 32 novas referências foram acrescentadas, além de 2 atualizações, totalizando 160 referências.  
Em 27 desetembro de 2012, a fim de atualizar as referências para publicação final deste Protocolo, nova busca foi realizada no Medline/Pubmed, a partir de 6 de setembro de 2011, utilizando-se os mesmos termos e limitando-se para meta-análises, o que resultou em 27 estudos. Destes, 15 foram excluídos e 12 acrescentados à revisão, sendo 9 artigos novos e 3 atualizações, totalizando 169.  
Também foram utilizados livros-texto da área, o _International Psychopharmacology Algorithm Project_ (IPAP) e _UpToDate_ , versão 19.2.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 2 INTRODUÇÃO -->
A esquizofrenia e os denominados transtornos esquizofrênicos constituem um grupo de distúrbios mentais graves, sem sintomas patognomônicos, mas caracterizados por distorções do pensamento e da percepção, por inadequação e embotamento do afeto sem prejuízo da capacidade intelectual (embora ao longo do tempo possam aparecer prejuízos cognitivos). Seu curso é variável, aproximadamente 30% dos casos apresentam recuperação completa ou quase completa, cerca de 30% com remissão incompleta e prejuízo parcial de funcionamento e cerca de 30% com deterioração importante e persistente da capacidade de funcionamento profissional, social e afetivo (1-3).  
Embora não se identifique qualquer sintoma patognomônico, existe uma hierarquia de sintomas. Para fins do diagnóstico de esquizofrenia, exige-se a presença de pelo menos uma das síndromes, sintomas ou sinais de um grupo de maior hierarquia, ou pelo menos dois dos sinais e sintomas de um grupo de menor hierarquia. Tais sintomas devem estar presentes na maior parte do tempo de um episódio de doença psicótica que dure pelo menos 1 mês (ou por algum tempo durante a maioria dos dias) e devem ter sido excluídos diagnósticos de transtornos de humor, transtornos atribuíveis à doença cerebral orgânica, intoxicação, dependência ou abstinência relacionada a álcool ou outras drogas. É de importância especial para a confirmação do diagnóstico a ocorrência de uma perturbação das funções que dão à pessoa normal um senso de individualidade, de unicidade e de direção de si mesmo (2).  
O paciente tem a sensação de que seus pensamentos, sentimentos e atos mais íntimos são sentidos ou partilhados por outros. Pode desenvolver delírios explicativos de que forças externas influenciam pensamentos e ações, de forma muitas vezes bizarras. Aspectos periféricos e irrelevantes de conceitos são conjugados com aspectos centrais. O paciente pode exibir um pensamento vago, elíptico e obscuro, acreditando que situações da vida quotidiana possuem um significado particular, em geral sinistro, relacionado unicamente com ele. Pode haver a sensação de interrupção do curso do pensamento e a sensação de que as ideias são retiradas por um agente exterior. O humor é caracteristicamente superficial ou incongruente, acompanhado, com frequência, de inércia, negativismo ou estupor (2, 4-5).  
As causas da esquizofrenia são ainda desconhecidas. O modelo de doença de maior aceitação é o da “vulnerabilidade _versus_ estresse”, conceito que propõe que a presença de vulnerabilidade aumenta o risco para o desenvolvimento de sintomas na presença de estressores ambientais e na falha dos mecanismos para lidar com eles. Os fatores de vulnerabilidade são baseados em um componente biológico, que inclui predisposição genética interagindo com fatores complexos físicos, ambientais e psicológicos (6).  
Os transtornos esquizofrênicos afetam aproximadamente 0,6% da população (com variação de 0,6%-3%, dependendo dos critérios diagnósticos utilizados), não havendo evidência de diferença entre os sexos (7). No Brasil, foram encontradas prevalências de 0,3%-2,4% da população para psicose em geral em um estudo de 1992 realizado em três capitais brasileiras (8). Em São Paulo, em 2002, um estudo encontrou uma prevalência de 0,8% em 12 meses para psicoses não afetivas (9). Em relação à carga global das doenças, esses transtornos são responsáveis por 1,1% dos AVAIs (anos de vida ajustados para incapacidade) e por 2,8% dos AVIs (anos de vida com incapacidade) (10). No Rio Grande do Sul, a esquizofrenia apareceu como o principal diagnóstico em internações hospitalares no ano de 2000, mas apresentou uma tendência a diminuição com a realização das reformas na assistência psiquiátrica realizadas na última década, chegando a cerca de 20%, em 2004 (11).  
Este Protocolo não utiliza as expressões comumente empregadas para a classificação dos antipsicóticos, como tipicidade (típicos e atípicos) ou período de síntese (primeira e segunda gerações). Essa classificação tornou-se obsoleta e incorreta na medida em que foram surgindo novas evidências de que os antipsicóticos constituem um grupo heterogêneo  
de medicamentos, com mecanismos de ação, eficácia, efeitos adversos e data de desenvolvimentos distintos entre si (12), razão pela qual os medicamentos serão citados nominalmente. Na escolha do tratamento, devem ser considerados os fármacos já utilizados, o estágio da doença, a história de resposta e adesão e o risco-benefício.  
Existe ampla evidência de que o uso de antipsicóticos é superior a seu não uso. Sabe-se também que intervenções não farmacológicas igualmente potencializam o tratamento medicamentoso - seja a eletroconvulsoterapia (ECT (13-15)) seja a estimulação magnética transcraniana (EMT), como opção de tratamento para alucinações auditivas refratárias aos medicamentos (16-19) - ou tratamentos psicossociais, que incluem terapia cognitivo-comportamental e terapia familiar sistêmica (20). Entretanto, o tratamento da esquizofrenia  neste Protocolo refere-se apenas à terapia medicamentosa. A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
- 3 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- F20.0 Esquizofrenia paranoide  
- F20.1 Esquizofrenia hebefrênica  
- F20.2 Esquizofrenia catatônica  
- F20.3 Esquizofrenia indiferenciada - F20.4 Depressão pós-esquizofrênica - F20.5 Esquizofrenia residual  
- F20.6 Esquizofrenia simples  
- F20.8  Outras esquizofrenias

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 4 DIAGNÓSTICO -->
O diagnóstico de esquizofrenia é clínico e baseado nos critérios da CID-10 (2). Essa classificação descreve critérios gerais que precisam ser atendidos, sendo o primeiro deles a presença de sintomas, e o segundo, a exclusão de determinadas condições.  
A classificação utiliza o descritor “G” para critérios gerais de cada grupo diagnóstico. O critério sintomas (“G1”) é dividido em 2 tipos: sintomas mais específicos (no qual a presença de um deles é suficiente) e outros menos específicos e que ocorrem em outros transtornos (nos quais são necessários 2 ou mais). Desta maneira, os sintomas dos critérios G1 devem ser preenchidos juntamente com a exclusão de diagnósticos de outros agravos descritos em G2.  
No G1, pelo menos uma das síndromes, sintomas e sinais listados em 1 ou pelo menos dois grupos dos sintomas e sinais listados em 2 devem estar presentes pela maior parte do tempo durante um episódio de doença psicótica que dure pelo menos 1 mês (ou por algum tempo durante a maioria dos dias).  
- 1)  Sintomas de maior hierarquia:  
- eco, inserção, roubo ou irradiação de pensamento;  
 delírios de controle, influência ou passividade, claramente relacionados ao corpo ou a movimentos dos membros ou a pensamentos, ações ou sensações específicos; percepção delirante;  
- vozes alucinatórias fazendo comentários sobre o comportamento do paciente ou discutindo entre si, ou outros  
- tipos de vozes alucinatórias advindas de alguma parte do corpo; e  
- delírios persistentes de outros tipos que sejam culturalmente inapropriados e completamente impossíveis (por  
- exemplo, ser capaz de controlar o tempo ou estar em comunicação com alienígenas).  
- 2) Sintomas de menor hierarquia:  
 alucinações persistentes, de qualquer modalidade, quando ocorrerem todos os dias, por pelo menos 1 mês, quando acompanhadas por delírios (os quais podem ser superficiais ou parciais), sem conteúdo afetivo claro ou quando acompanhadas por ideias superestimadas persistentes;  
 neologismos, interceptações ou interpolações no curso do pensamento, resultando em discurso incoerente ou irrelevante;  
 comportamento catatônico, tal como excitação, postura inadequada, flexibilidade cérea, negativismo, mutismo e estupor; e  
 sintomas "negativos", tais como apatia marcante, pobreza de discurso, embotamento ou incongruência de respostas emocionais (deve ficar claro que tais sintomas não são decorrentes de depressão ou medicamento neuroléptico). No G2, são utilizadas as cláusulas de exclusão diagnóstica mais comuns.  
Se o paciente também preenche os critérios para episódio maníaco, episódio depressivo ou misto, os critérios listados em 1 e 2 devem ter sido satisfeitos antes que a perturbação do humor se desenvolva.  
O transtorno não é atribuível a doença cerebral orgânica ou a intoxicação, dependência ou abstinência relacionada a álcool ou drogas. Na avaliação da presença dessas experiências subjetivas e comportamentos anormais, deve-se tomar especial cuidado para evitar avaliação falso-positiva, especialmente quando estão envolvidos modos de expressão e comportamento cultural ou subculturalmente influenciados ou um nível de inteligência abaixo do normal.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 5 CRITÉRIOS DE INCLUSÃO -->
Serão incluídos neste Protocolo os pacientes que satisfizerem os critérios abaixo:  
- diagnóstico de esquizofrenia; e  
- presença de um familiar ou responsável legal interessado, participativo, disponível, com funcionamento global adequado e com adesão ao serviço de atendimento psiquiátrico ambulatorial ou de internação. No caso de paciente cronicamente asilado, é requerida a presença de um funcionário da instituição disponível e capaz de manejar estressores do ambiente de forma continuada.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 6 CRITÉRIOS DE EXCLUSÃO -->
Serão excluídos deste Protocolo os pacientes com diagnóstico de esquizofrenia que apresentarem hipersensibilidade aos fármacos, psicose alcoólica ou tóxica, dependência ou abuso atual de fármacos psicoativos e impossibilidade de adesão ao tratamento e de acompanhamento contíinuo. Serão excluídos também pacientes que apresentarem apenas diagnósticos de mania ou depressão isolados, transtorno esquizoafetivo ou de transtorno bipolar.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 7 CASOS ESPECIAIS -->
Pacientes com diagnóstico de esquizofrenia com risco de suicídio atual e aqueles que desenvolverem discinesia tardia com repercussão significativa deverão ser tratados com clozapina.  
A depressão pós-esquizofrênica é um subtipo de esquizofrenia peculiar, por classificar casos em que um episódio depressivo eventualmente prolongado ocorre ao fim de uma afecção esquizofrênica. Apesar de que alguns sintomas esquizofrênicos “positivos” ou “negativos” ainda devam estar presentes, eles não dominam mais o quadro clínico. Esse tipo de estado depressivo se acompanha de um maior risco de suicídio. O diagnóstico é excluído no caso de o paciente não apresentar mais nenhum sintoma esquizofrênico, quando então se deve fazer um diagnóstico de episódio depressivo. Se os sintomas esquizofrênicos ainda são aparentes e proeminentes, deve-se manter o diagnóstico da forma clínica apropriada da esquizofrenia (2).  
Essa condição caracteriza um transtorno pouco frequente (inexistem dados acurados de sua prevalência), com características diagnósticas diferentes das dos outros subtipos de esquizofrenia, bem como com características de tratamento diferentes (com indicação de uso de antidepressivos e de antipsicóticos).

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 8 TRATAMENTO -->
Foram revisados estudos que avaliaram os seguintes medicamentos de ação não antipsicótica no tratamento da esquizofrenia: valproato (21,22), carbamazepina (23,24), lítio (25), estrogênio (26) antidepressivos inibidores da recaptação da serotonina (27), antidepressivos em geral (28,29), benzodiazepínicos (30), ácidos graxos poli-insaturados (31), L-Dopa (32), gingko biloba (33), inibidores da colinesterase (34,35), fármacos glutamatérgicos (36,37), nicotina (38), testosterone (39), ácido eicosapentaenoico (40), anti-inflamatórios não esteroides (41), antagonistas alfa-2 (42) e moduladores do receptor NMDA (43). Não foram encontradas evidências que corroborem a inclusão desses medicamentos neste Protocolo. Não foram incluídos estudos de medicamentos de ação antipsicótica não liberados para uso no Brasil (zotepina, loxapina, sertindol, iloperidona, molindona, fluspirilene, benperidol, flupentixol, perfenazina, bromperidol e perazine) (44-61).  
Na última década do século vinte e na primeira do atual século, realizou-se um debate amplo sobre a superioridade de novos componentes que culminou com um consenso de que todos os medicamentos possuem potência semelhante para a maioria dos pacientes, com exceção de clozapina (62-80). O mesmo restou evidenciado para populações especiais, como crianças e adolescentes (81-82) ou idosos (83), e para prescrições especiais, com o uso combinado de mais de um antipsicótico (84).  
Para avaliação do benefício individual de cada fármaco, foram revisadas meta-análises com comparações contra placebo ou entre si dos seguintes medicamentos: levomepromazina (85), pimozida (86), tioridazina (87), trifluoperazina (88), clorpromazina (89), flufenazina (90,91), haloperidol (92-95), aripiprazol (96,97), zuclopentixol (98-100), olanzapina (101-104), pipotiazina (105), amisulprida (106-109), quetiapina (93, 110-112), paliperidona (113), ziprasidona (114,115), risperidona (102,103,116-120), penfluridol (121), clozapina (122) e sulpirida (123-125). Apenas uma meta-análise avaliou mais de um medicamento contra placebo ou entre si (12).  
As evidências não demonstraram superioridade, no tratamento da esquizofrenia de levomepromazina, pimozida, tioridazina, trifluoperazina, zuclopentixol, amisulprida, paliperidona, penfluridol e sulpirida.  A pipotiazina pertence ao mesmo grupo farmacológico do haloperidol, não se evidenciando vantagem de sua utilização em relação ao haloperidol. Como medicamento _depot_ , a flufenazina surge apenas como alternativa à utilização do haloperidol por pertencer a um grupo farmacológico diferente. A risperidona _depot_ também não tem evidências que justifiquem sua inclusão neste Protocolo. O aripiprazol é muito semelhante em eficácia aos demais antipsicóticos em estudos de esquizofrenia em geral e, nos casos de esquizofrenia refratária, também não demonstrou superioridade em relação aos demais para justificar aqui sua inclusão (73,74,126).  
A clozapina é considerada superior para pacientes não responsivos a outros antipsicóticos (127-133)  e sua indicação permanece para esses casos, demonstrando superioridade (134). Inexiste evidência de que a adição de um segundo antipsicótico, após a indicação de clozapina, possa trazer benefícios aos pacientes (133,135-139). A lamotrigina foi recentemente avaliada em pacientes refratários a clozapina (140,141), sendo que sua inclusão ainda não pode ser recomendada neste Protocolo devido à necessidade de maiores evidências.  
Em resumo, a análise das evidências dos diferentes tratamentos para esquizofrenia demonstra não haver diferença de eficácia entre eles.  
Todos os antipsicóticos, com exceção de clozapina, podem ser utilizados no tratamento, sem ordem de preferência, dos pacientes com diagnóstico de esquizofrenia que preencham os critérios de inclusão. Os tratamentos devem ser feitos  
com um medicamento de cada vez (monoterapia), de acordo com o perfil de segurança e a tolerabilidade do paciente. Em caso de falha terapêutica (definida como o uso de qualquer desses fármacos por pelo menos 6 semanas, nas doses adequadas, sem melhora de pelo menos 30% na escala de Avaliação Psiquiátrica Breve ( _British Psychiatric Rating Scale_ - _BPRS_ ) (142-144), uma segunda tentativa com algum outro antipsicótico deverá ser feita.  
Caso haja intolerância por efeitos extrapiramidais, estarão indicados, após ajuste de dose, biperideno ou propranolol (1). No caso de persistência dos efeitos mesmo depois dessa alternativa, estará indicada a substituição por outro antipsicótico com menor perfil de efeitos extrapiramidais, como olanzapina, quetiapina ou ziprasidona. Recomendase a avaliação dos sintomas extrapiramidais pelas escalas Simpson – _Angus Rating Scale_ ( _SAS_ ), _Barnes Akathisia Rating Scale_ e _Abnormal Involuntary Movement Scale_ ( _AIMS_ ) (145-147).  Os sintomas extrapiramidais motores devem descrever a ocorrência de pelo menos um dos seguintes grupos: distonia, discinesia, acatisia e parkinsonismo (tremor, rigidez e bradicinesia). Devem também ter ocorrido nos três primeiros meses de tratamento, normalmente nas primeiras semanas.  
No caso de a intolerância a risperidona dever-se ao aumento de prolactina (nível sérico acima de 25 ng/ml nas mulheres e acima de 20 ng/ml nos homens) acompanhado ou não de galactorreia, irregularidades menstruais ou alterações da libido, já haverá indicação de uso de outro antipsicótico. O risco-benefício da troca do antipsicótico deverá ser avaliado pelo médico clínico responsável juntamente com o paciente (1).  
A clozapina poderá ser considerada em caso de refratariedade a pelo menos 2 medicamentos utilizados por pelo menos 6 semanas, nas doses adequadas, e se não houver melhora de pelo menos 30% na escala BPRS (142-144). Também pode ser utilizada em caso de risco alto de suicídio e discinesia tardia de repercussão significativa (148-149), mesmo antes de se completarem 6 semanas ou de se observar melhora de 30% nessa mesma escala.  
Caso haja intolerância a clozapina por agranulocitose, após sua indicação por refratariedade, a troca poderá ser por olanzapina, quetiapina, risperidona ou ziprasidona, preferencialmente as que não foram utilizadas nos dois tratamentos iniciais (1).  
Na impossibilidade de adequada adesão ao uso oral de qualquer dos medicamentos acima (150,151), será indicado um medicamento de depósito, o decanoato de haloperidol.  
- 8.1 FÁRMACOS  
- Risperidona: comprimidos de 1, 2 e 3 mg.  
- Quetiapina: comprimidos de 25, 100, 200 e 300 mg.  
- Ziprasidona: cápsulas de 40 e 80 mg.  
- Olanzapina: comprimidos de 5 e 10 mg.  
- Clozapina: comprimidos de 25 e 100 mg.  
- Clorpromazina: comprimidos de 25 e 100 mg; solução oral de 40 mg/ml.  
- Haloperidol: comprimido de 1 e 5 mg solução oral 2 mg/ml.  
- Decanoato de haloperidol: solução injetável 50 mg/ml.  
- 8.2 ESQUEMAS DE ADMINISTRAÇÃO (152,153)

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Risperidona</u> -->
Deve-se iniciar com 1 mg, 2 vezes ao dia, para evitar efeito de primeira dose (bloqueio alfa-adrenérgico). A dose pode ser aumentada em 1 mg, 2 vezes ao dia, até que uma dose-alvo de 6 mg/dia (3 mg, 2 vezes ao dia) seja alcançada no terceiro dia. As doses recomendadas de manutenção são de 3-6 mg/dia (154-156). Se descontinuada, a administração deve ser reiniciada conforme a primeira dose. Em pacientes com insuficiências renal ou hepática, a dose máxima recomendada é de 3 mg/dia. A administração simultânea com alimentos não interfere na biodisponibilidade do medicamento.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Quetiapina</u> -->
Deve-se iniciar com 25 mg, 2 vezes ao dia, por via oral, com aumentos de  25-50 mg por dose por dia, com o objetivo de alcançar 300-600 mg/dia (157). A dose total poderá ser dividida em 2 ou 3 vezes ao dia, devendo ser alcançada entre o quarto e o sétimo dias de tratamento. O ajuste pode ser feito com incrementos (ou diminuição) de 25-50 mg, 2 vezes ao dia, ou num intervalo de 2 dias. A dose máxima situa-se entre 750-800 mg/dia.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Ziprasidona</u> -->
Deve-se iniciar com 40 mg, 2 vezes ao dia, por via oral, sendo administrados com os alimentos. Aumentos de dose deverão ocorrer em intervalos superiores a 2 dias até a dose máxima de 160 mg/dia (80 mg, 2 vezes ao dia). A dose de manutenção ideal é de 40 mg, administrados 2 vezes ao dia.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Olanzapina</u> -->
Deve-se iniciar com 5 mg à noite. Pode-se aumentar a dose em 5 mg após pelo menos 7 dias até uma dose de 20 mg/dia. Não há evidências de que doses acima de 20 mg/dia em pacientes não refratários sejam mais eficazes (123). Não é necessário ajuste de dose em casos de insuficiências renal ou hepática. Pacientes debilitados fisicamente e emagrecidos deverão receber no máximo 5 mg/dia. Na ocorrência de efeitos adversos graves de clozapina (agranulocitose, cardiopatia e oclusão intestinal), em pacientes refratários, olanzapina poderá ser utilizada até a dose de 30 mg/dia (158-160).

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Clozapina</u> -->
Deve-se iniciar com 12,5 mg à noite. Pode-se aumentar a dose em 25 mg a cada 1 a 2 dias até 300-400 mg/dia. Após 30 dias sem melhora, pode-se  aumentar 50 mg a cada 3-4 dias até 800 mg/dia. Doses acima de 400 mg poderão ser fracionadas para aumentar a tolerância do paciente.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Clorpromazina</u> -->
Deve-se iniciar com doses pequenas, entre 50-100 mg, 2-3 vezes ao dia, para atenuar possíveis efeitos adversos, embora pela meia-vida de 24 horas possa ser administrada 1 vez ao dia. Doses médias variam entre 400-800 mg, sendo 1 g a dose máxima recomendada. Doses abaixo de 150 mg estão relacionadas a maior chance de  recidiva (161). O equilíbrio  
plasmático é alcançado em 2-5 dias de tratamento. Café, cigarro e antiácidos diminuem sua absorção, devendo-se considerar a administração de doses maiores nesses casos.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Haloperidol</u> -->
Deve-se iniciar com doses fracionadas, embora tenha meia-vida de 24 horas, para minimizar efeitos adversos, até a dose máxima de 15 mg/dia em situações agudas e de 10 mg/dia para manutenção.  Doses superiores parecem não ter benefício e aumentam a incidência de efeitos adversos.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Decanoato de haloperidol</u> -->
Deve-se indicar uma dose entre 150-200 mg/mês para a maioria dos casos, aplicada a cada 4 semanas. Sua meiavida é de cerca de 3 semanas, levando entre 3-6 meses para a estabilização da concentração plasmática. Por tal motivo, pode-se iniciar em doses superiores (até 400 mg/mês) e com maior frequência (até semanalmente) nos primeiros meses, ou iniciar com doses usuais e suplementar com haloperidol oral até a dose máxima de 15 mg/dia, conforme a tolerância, principalmente no primeiro mês.  
Para todos os medicamentos, obtida a melhora clínica, deverá ser instituída uma redução cuidadosa da dose na manutenção e acompanhamento clínico e psiquiátrico, com escores trimestrais (escala BPRS-A).  
Para o tratamento dos efeitos extrapiramidais, o biperideno poderá ser utilizado na dose de 1 a 16 mg, divididos em 1 a 4 administrações ao dia, dependendo da intensidade dos sintomas O  propranolol também poderá ser utilizado para esta finalidade, na dose de 40 a 160mg, divididos em 2 a 3 administrações ao dia.  
- 8.3 TEMPO DE TRATAMENTO - CRITÉRIOS DE INTERRUPÇÃO  
Situações especiais:  
- Discinesia tardia e tentativa de suicídio: substituir o medicamento em uso por clozapina (148,149);  
- Má adesão ao tratamento: substituir o medicamento em uso por decanoato de haloperidol (91,95,150,151); e  
- Comorbidades clínicas iniciadas após o uso: hipertensão arterial sistêmica (HAS), obesidade, diabetes melito (DM), desenvolvimento de síndrome metabólica (se em uso de olanzapina e quetiapina, considerar a substituição do medicamento em uso por ziprasidona (162-164).

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Risperidona</u> -->
Terá indicação de interrupção de tratamento o paciente que, após 6 semanas de uso de dose máxima, não mostrar melhora clínica, não aderir ao tratamento e às avaliações (preenchimento da escala BPRS-A) ou  apresentar, a qualquer tempo, efeitos adversos intoleráveis, hiperprolactinemia ou sintomas extrapiramidais resistentes ao tratamento com biperideno ou propanolol ou gravidez/lactação.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Olanzapina e quetiapina</u> -->
Terá indicação de interrupção de tratamento o paciente que, após 6 semanas de uso de até 20 mg/dia (olanzapina) ou de 800 mg/dia (quetiapina), não mostrar melhora clínica, não aderir ao tratamento e às avaliações (preenchimento da escala BPRS-A) ou apresentar, a qualquer tempo, efeitos adversos intoleráveis, ganho de peso com desenvolvimento de obesidade (IMC acima de 30 kg/m<sup>2</sup> ), cintura com mais de 94 cm, HAS, dislipidemia, DM, resistência insulínica ou gravidez/lactação.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Ziprasidona</u> -->
Terá indicação de interrupção de tratamento o paciente que, após 6 semanas de uso de até 160 mg/dia, não mostrar melhora clínica, não aderir ao tratamento e às avaliações (preenchimento da escala BPRS-A) ou apresentar, a qualquer tempo, efeitos adversos intoleráveis.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Clozapina</u> -->
Em função do mecanismo de ação diferente (mais lento) deste fármaco, terá indicação de interrupção de tratamento o paciente que, após 6 meses de uso de 300-800 mg/dia, não mostrar melhora clínica, não aderir ao tratamento e às avaliações (escalas) ou apresentar, a qualquer tempo, efeitos adversos como convulsões, citopenia (leucócitos totais abaixo de 3.000/mm3 ou neutrófilos abaixo de 1.500/mm3 ou plaquetas abaixo de 100.000/mm3) ou conforme avaliação médica especializada. O paciente que, por qualquer das razões acima, tiver de interromper o uso de clozapina, poderá iniciar tratamento com quetiapina, ziprasidona, olanzapina ou risperidona.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Haloperidol e clorpromazina</u> -->
Terá indicação de interrupção de tratamento o paciente que, após 6 semanas de uso de 300-1.000 mg/dia de clorpromazina ou 5-15 mg de haloperidol, não mostrar melhora clínica, não aderir ao tratamento e às avaliações ou apresentar distonia significativa, extrapiramidalismo ou efeitos adversos intoleráveis.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 8.4 BENEFÍCIOS ESPERADOS -->
A melhora clínica é definida como uma diminuição de pelo menos 30% nos escores da escala BPRS-A (142-144).

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 9 MONITORIZAÇÃO -->
Antes do início do tratamento com qualquer um dos medicamentos, é obrigatória a avaliação dos seguintes aspectos: idade, medidas antropométricas (peso, altura, circunferência abdominal e do quadril), três medidas de pressão arterial em datas diferentes, dosagens de colesterol total e frações, triglicerídios e glicemia de jejum. Deve-se registrar também a história familiar ou prévia de síndrome neuroléptica maligna, distonia/discinesia, tentativa de/risco de suicídio, obesidade, hipertensão arterial sistêmcia, diabete mélito e outras comorbidades clínicas.  
Para monitorização dos efeitos adversos, devem ser repetidas as medidas antropométricas e de pressão arterial em 3, 6 e 12 meses. Os exames laboratoriais (perfil lipídico e glicemia de jejum) devem ser refeitos em 3 e 12 meses. Após, a monitorização deve ser repetida anualmente (1,162,165,166).  Em caso de alteração, uma avaliação com clínico deverá ser feita e o risco-benefício discutido em conjunto com a família e o paciente.  
A dosagem do nível sérico de prolactina deverá ser solicitada sempre que houver relato de sintomas compatíveis com alterações hormonais, como diminuição da libido, alterações menstruais, impotência e galactorreia.  
Devem ser observadas as contraindicações relativas e considerado o risco-benefício de cada um dos medicamentos.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Risperidona</u> -->
Pode relacionar-se a síndrome neuroléptica maligna; discinesia tardia; prolongamento do intervalo QT ao eletrocardiograma; doença cardiovascular ou cerebrovascular que predisponha à hipotensão ortostática; hipotermia ou hipertermia; diagnóstico prévio de câncer de mama ou tumor dependente de prolactina; insuficiência renal; insuficiência hepática; doença de Parkinson; história de convulsão ou epilepsia; história de tumor cerebral; gravidez ou situação potencial de gravidez ou lactação; idade inferior a 18 anos; hiperprolactinemia.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Quetiapina</u> -->
Pode relacionar-se a doença de Alzheimer; pacientes portadores ou com história de câncer de mama; doenças cardiovasculares; doenças cerebrovasculares; condições que predisponham à hipotensão (desidratação e hipovolemia); insuficiência hepática ou renal; hipotireiodismo; história de convulsões; catarata; doença de Parkinson com falência autonômica periférica; obesidade, cintura com mais de 94 cm, HAS, dislipidemia, DM ou resistência insulínica (síndrome metabólica) que exigem consentimento, por escrito, do médico assistente, dando ciência da avaliação do risco-benefício no paciente. Mulheres em idade fértil devem ser esclarecidas quanto à necessidade do uso regular de métodos contraceptivos e, em caso de dúvida, sugere-se teste de gravidez antes do início do tratamento.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Ziprasidona</u> -->
Pode relacionar-se a história de cardiopatia, especialmente arritmias; hipertensão arterial sistêmica aumentando o efeito de anti-hipertensivos; doença de Parkinson (apesar de apresentar baixa incidência de efeitos extrapiramidais, pode antagonizar os efeitos de levodopa e de agonistas dopaminérgicos); condições que indiquem a presença de _torsade de pointes_ como tonturas, palpitações e síncope; história de uso de drogas de abuso e dependência química; hipotensão postural; uso concomitante de fármacos potencialmente capazes de produzir desequilíbrio hidroeletrolítico;  risco de convulsões em pacientes com histórico de epilepsia, traumatismo craniano, lesões cerebrais, alcoolismo ou uso concomitante de fármacos que reduzam o limiar convulsivante. Mulheres em idade fértil devem ser esclarecidas quanto à necessidade do uso regular de métodos contraceptivos e, em caso de dúvida, sugere-se teste de gravidez antes do início do tratamento. Também não se recomenda o uso de ziprasidona durante a lactação.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Olanzapina</u> -->
Pode associar-se a pacientes portadores ou com história de tumor cerebral, epilepsia ou condições que diminuam o limiar convulsivante; pacientes portadores ou com história de câncer de mama; glaucoma; íleo paralítico ou história de íleo paralítico; hiperplasia prostática significativa; doença cardíaca ou cerebrovascular ou condições que predisponham a hipotensão; risco de pneumonia de aspiração; risco de suicídio; história de síndrome neuroléptica maligna; gravidez ou situação potencial de gravidez ou lactação; idade inferior a 18 anos; obesidade, cintura com mais de 94 cm, HAS, dislipidemia, DM ou resistência insulínica (síndrome metabólica) que exigem consentimento, por escrito, do médico assistente, dando ciência da avaliação do risco-benefício no paciente.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Clozapina</u> -->
Pode associar-se a epilepsia precedendo o diagnóstico de esquizofrenia para pacientes com convulsões ou retardo mental, devendo ser incluído, obrigatoriamente, parecer de um neurologista (parecer favorável permite a entrada ou a manutenção do paciente no Protocolo). Recomenda-se a realização de hemograma completo a intervalos semanais e a cada aumento de dose nas primeiras 18 semanas de tratamento e a intervalos mensais ao longo de todo o tempo de tratamento; citopenia caracterizada por leucopenia (leucócitos totais abaixo de 3.000/mm3 ou neutrófilos abaixo de 1.500/mm3) ou por plaquetopenia (contagem de plaquetas abaixo de 100.000 /mm3) para pacientes com citopenia, casos em que o medicamento deve ser suspenso e tanto a inclusão no Protocolo quanto a continuidade do tratamento deverão ser avaliadas por hematologista; risco grave de suicídio (o medicamento somente pode ser dispensado para o responsável legal, com registro claro de alerta para a dose letal (2,5 g); durante a lactação ou em situações em que a gravidez não pode ser adequadamente prevenida, o tratamento deve ser evitado, casos em que se recomendam a avaliação do risco-benefício e a suspensão da lactação se necessário.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Haloperidol</u> -->
Pode associar-se a alergia ao fármaco; depressão grave do sistema nervoso central; coma; doença pulmonar obstrutiva crônica; síndrome de Sjögren, transtornos convulsivos; diagnóstico prévio de câncer de mama ou tumor dependente de prolactina; bexiga neurogênica; hipertrofia de próstata; gravidez e amamentação; doença de Parkinson.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: <u>Clorpromazina</u> -->
Pode associar-se a depressão grave do sistema nervoso central; estados comatosos; doença cardiovascular grave; angina _pectoris_ ; glaucoma de ângulo fechado; doença de Parkinson; úlcera péptica; retenção urinária; síndrome de Reye; síndrome neuroléptica maligna; doença cardiovascular ou cerebrovascular que predisponha a hipotensão ortostática; diagnóstico prévio de câncer de mama ou tumor dependente de prolactina; insuficiência hepática; história de convulsão ou epilepsia; história de tumor cerebral; hiperprolactinemia, antecedentes de discrasias sanguíneas.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 10 ACOMPANHAMENTO PÓS-TRATAMENTO -->
O tratamento da esquizofrenia não tem tempo determinado. O período de reavaliação é de 6 meses, ocasião em que o médico avaliará a efetividade e a segurança do tratamento. A duração indeterminada segue apoiada por um estudo de meta-análise avaliando o efeito da suspensão do uso da clorpromazina em pacientes esquizofrênicos estáveis. Estudos prévios mostravam que 25% dos pacientes com apenas um quadro psicótico não têm mais episódio depois de tratada a  
crise. Avaliados 10 estudos, com 1.042 pacientes estáveis com esquizofrenia, foi evidenciado que aqueles que permaneceram em uso de clorpromazina, em curto, médio e longo prazos, tiveram menos chance de ter uma recidiva comparados com os do grupo que suspendeu o uso (167). Uma meta-análise também avaliou o uso em geral de antipsicóticos em tratamentos de manutenção para esquizofrenia após 1 ano contra placebo. Houve evidência de benefícios em diferentes desfechos (168,169).

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 11 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
O atendimento dos pacientes deve seguir critérios, normas e diretrizes estabelecidas pelo Ministério da Saúde para a Rede de Atenção à Saúde Mental.  
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento. Devem também ser observadas as condições de boa adesão e acompanhamento contínuo apresentadas pelo paciente e seu familiar (ou responsável legal).

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 12 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER -->
É obrigatória a informação ao paciente ou a seu responsável legal dos benefícios, potenciais riscos e efeitos colaterais relacionados ao uso de medicamentos preconizados neste Protocolo. O TER é obrigatório ao se prescrever medicamento do Componente Especializado da Assistência Farmacêutica.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: 13 REFERÊNCIAS BIBLIOGRÁFICAS -->
1.The International Psychopharmacology Algorithm Project. Disponível em: www.ipap.org. Acesso em: 15 Maio  
2010.  
2.Organização Mundial de Saúde. Classificação de transtornos mentais e de comportamento da CID-10: Critérios diagnósticos para pesquisa. Porto Alegre: Artes Médicas; 1998.  
3.American Psychiatric Association. Diretrizes do tratamento da esquizofrenia. Formulação e implementação de um plano terapêutico. Porto Alegre: Artes Médica; 2000.  
4.Organização Mundial de Saúde. Classificação de transtornos mentais e de comportamento da CID-10: Descrições clínicas e diretrizes diagnósticas. Porto Alegre: Artes Médicas; 1993.  
5.Elkis, Helio. A evolução do conceito de esquizofrenia neste século.  Rev. Bras. Psiquiatr. [online]. 2000, vol.22, suppl. pp. 23-26  
6.Silva RC. Esquizofrenia: uma revisão. Psicol USP. 2006;17(4):263-85.  
7.Mari JJ, Leitão RJ. A epidemiologia da esquizofrenia. Rev Bras Psiquiatr. 2000;22(Suppl 1):15-7.  
8.Almeida Filho N, Mari JJ, Coutinho E, França J, Fernandes J, Andreoli S, et al. Estudo multicêntrico de morbidade mental psiquiátrica em áreas urbanas brasileiras (Brasília, São Paulo e Porto Alegre). Revista ABP/APAL. 1992;14:93-104.  
9.Andrade L, Walters EE, Gentil V, Laurenti R. Prevalence of ICD-10 mental disorders in a catchment area in the city of Sao Paulo, Brazil. Soc Psychiatry Psychiatr Epidemiol. 2002;37(7):316-25.  
10.World Health Organization. The world health report 2001 - Mental health: new understanding, new hope. Geneva: World Health Organization; 2001.  
11.Candiago RH, Belmonte de Abreu P. Use of Datasus to evaluate psychiatric inpatient care patterns in Southern Brazil. Rev Saude Publica. 2007;41(5):821-9.  
12.Leucht S, Komossa K, Rummel-Kluge C, Corves C, Hunger H, Schmid F, et al. A meta-analysis of head-tohead comparisons of second-generation antipsychotics in the treatment of schizophrenia. Am J Psychiatry. 2009;166(2):152-63.  
13.Painuly N, Chakrabarti S. Combined use of electroconvulsive therapy and antipsychotics in schizophrenia: the Indian evidence. A review and a meta-analysis. J ECT. 2006;22(1):59-66.  
14.Tharyan P, Adams CE. Electroconvulsive therapy for schizophrenia. Cochrane Database Syst Rev. 2005;(2):CD000076.  
15.Rabheru K. Maintenance electroconvulsive therapy (M-ECT) after acute response: examining the evidence for who, what, when, and how? J ECT. 2012;28(1):39-47.  
16.Aleman A, Sommer IE, Kahn RS. Efficacy of slow repetitive transcranial magnetic stimulation in the treatment of resistant auditory hallucinations in schizophrenia: a meta-analysis. J Clin Psychiatry. 2007;68(3):416-21.  
17.Dlabac-de Lange JJ, Knegtering R, Aleman A. Repetitive transcranial magnetic stimulation for negative symptoms of schizophrenia: review and meta-analysis. J Clin Psychiatry. 2010;71(4):411-8.  
18.Slotema CW, Blom JD, Hoek HW, Sommer IE. Should we expand the toolbox of psychiatric treatment methods to include Repetitive Transcranial Magnetic Stimulation (rTMS)? A meta-analysis of the efficacy of rTMS in psychiatric disorders. J Clin Psychiatry. 2010;71(7):873-84. 19.Blumberger DM, Fitzgerald PB, Mulsant BH, Daskalakis ZJ. Repetitive transcranial magnetic stimulation for refractory symptoms in schizophrenia. Curr Opin Psychiatry. 2010;23(2):85-90.  
20.Chisholm D, Gureje O, Saldivia S, Villalon Calderon M, Wickremasinghe R, Mendis N, et al. Schizophrenia treatment in the developing world: an interregional and multinational cost-effectiveness analysis. Bull World Health Organ. 2008;86(7):542-51.  
21.Basan A, Leucht S. Valproate for schizophrenia. Cochrane Database Syst Rev. 2004;(1):CD004028.  
22. Schwarz C, Volz A, Li C, Leucht S. Valproate for schizophrenia. Cochrane Database Syst Rev.  
2008;(3):CD004028.  
23.Leucht S, McGrath J, White P, Kissling W. Carbamazepine augmentation for schizophrenia: how good is the evidence? J Clin Psychiatry. 2002;63(3):218-24.  
24.Leucht S, Kissling W, McGrath J, White P. Carbamazepine for schizophrenia. Cochrane Database of Syst Rev. 2007; (3): CD001258.  
25.Leucht S, Kissling W, McGrath J. Lithium for schizophrenia revisited: a systematic review and meta-analysis of randomized controlled trials. J Clin Psychiatry. 2004;65(2):177-86.  
26.Chua WL, de Izquierdo SA, Kulkarni J, Mortimer A. Estrogen for schizophrenia. Cochrane Database Syst Rev. 2005;(4):CD004719.  
27.Sepehry AA, Potvin S, Elie R, Stip E. Selective serotonin reuptake inhibitor (SSRI) add-on therapy for the negative symptoms of schizophrenia: a meta-analysis. J Clin Psychiatry. 2007;68(4):604-10.  
28.Rummel C, Kissling W, Leucht S. Antidepressants for the negative symptoms of schizophrenia. Cochrane Database Syst Rev. 2006;(3):CD005581.  
29.Rummel C, Kissling W, Leucht S. Antidepressants as add-on treatment to antipsychotics for people with schizophrenia and pronounced negative symptoms: a systematic review of randomized trials. Schizophr Res. 2005;80(1):85-97.  
30.Volz A, Khorsand V, Gillies D, Leucht S. Benzodiazepines for schizophrenia. Cochrane Database Syst Rev. 2007;(1):CD006391.  
31.Irving CB, Mumby-Croft R, Joy LA. Polyunsaturated fatty acid supplementation for schizophrenia. Cochrane Database of Syst Rev. 2006;(3):CD001257.  
32.Jaskiw GE, Popli AP. A meta-analysis of the response to chronic L-dopa in patients with schizophrenia: therapeutic and heuristic implications. Psychopharmacology (Berl). 2004;171(4):365-74.  
33.Singh V, Singh SP, Chan K. Review and meta-analysis of usage of ginkgo as an adjunct therapy in chronic schizophrenia. Int J Neuropsychopharmacol. 2010;13(2):257-71.  
34.Ribeiz SR, Bassitt DP, Arrais JA, Avila R, Steffens DC, Bottino CM. Cholinesterase inhibitors as adjunctive therapy in patients with schizophrenia and schizoaffective disorder: a review and meta-analysis of the literature. CNS Drugs. 2010;24(4):303-17.  
- 35.Singh J, Kour K, Jayaram MB. Acetylcholinesterase inhibitors for schizophrenia. Cochrane Database Syst Rev.  
- 2012;1:CD007967.  
- 36.Tiihonen J, Wahlbeck K. Glutamatergic drugs for schizophrenia. Cochrane Database Syst Rev.  
- 2006;(2):CD003730.  
- 37.Carroll BT, Goforth HW, Thomas C, Ahuja N, McDaniel WW, Kraus MF, et al. Review of adjunctive glutamate  
- antagonist therapy in the treatment of catatonic syndromes. J Neuropsychiatry Clin Neurosci. 2007;19(4):406-12.  
38.Punnoose S, Belgamwar MR. Nicotine for schizophrenia. Cochrane Database Syst Rev. 2006;(1):CD004838.  
39.Elias A, Kumar A. Testosterone for schizophrenia. Cochrane Database Syst Rev. 2007;(3):CD006197.  
40.Fusar-Poli P, Berger G. Eicosapentaenoic acid interventions in schizophrenia: meta-analysis of randomized, placebo-controlled studies. J Clin Psychopharmacol. 2012;32(2):179-85.  
41.Sommer IE, de Witte L, Begemann M, Kahn RS. Nonsteroidal anti-inflammatory drugs in schizophrenia: ready for practice or a good start? A meta-analysis. J Clin Psychiatry. 2012;73(4):414-9.  
42.Hecht EM, Landy DC. Alpha-2 receptor antagonist add-on therapy in the treatment of schizophrenia; a metaanalysis. Schizophr Res. 2012;134(2-3):202-6.  
- 43.Singh SP, Singh V. Meta-analysis of the efficacy of adjunctive NMDA receptor modulators in chronic  
- schizophrenia. CNS Drugs. 2011;25(10):859-85  
44.Komossa K, Rummel-Kluge C, Hunger H, Schwarz S, Schmidt F, Lewis R, et al. Sertindole versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2009;(2):CD006752.  
45.Komossa K, Rummel-Kluge C, Hunger H, Schmid F, Schwarz S, Kissling W, et al. Zotepine versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2010;(1):CD006628.  
46.Kane JM, Lauriello J, Laska E, Di Marino M, Wolfgang CD. Long-term efficacy and safety of iloperidone: results from 3 clinical trials for the treatment of schizophrenia. J Clin Psychopharmacol. 2008;28(2 Suppl 1):S29-35.  
47.Weiden PJ, Cutler AJ, Polymeropoulos MH, Wolfgang CD. Safety profile of iloperidone: a pooled analysis of 6-week acute-phase pivotal trials. J Clin Psychopharmacol. 2008;28(2 Suppl 1):S12-9.  
48.Bagnall A, Fenton M, Kleijnen J, Lewis R. Molindone for schizophrenia and severe mental illness. Cochrane Database Syst Rev. 2007;(1):CD002083.  
- 49.Abhijnhan A, Adams CE, David A, Ozbilen M. Depot fluspirilene for schizophrenia. Cochrane Database Syst  
- Rev. 2007;(1):CD001718.  
- 50.Leucht S, Hartung B. Perazine for schizophrenia. Cochrane Database Syst Rev. 2006;(2):CD002832.  
51.Citrome L. Iloperidone for schizophrenia: a review of the efficacy and safety profile for this newly commercialised second-generation antipsychotic. Int J Clin Pract. 2009;63(8):1237-48.  
52.DeSilva P, Fenton M, Rathbone J. Zotepine for schizophrenia. Cochrane Database Syst Rev. 2006;(4):CD001948. 53.Lewis R, Bagnall AM, Leitner M. Sertindole for schizophrenia. Cochrane Database Syst Rev. 2005;(3):CD001715.  
54.Subramanian S, Rummel-Kluge C, Hunger H, Schmid F, Schwarz S, Kissling W, et al. Zotepine versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2010;(10):CD006628.  
55.Hartung B, Wada M, Laux G, Leucht S. Perphenazine for schizophrenia. Cochrane Database Syst Rev. 2005;(1):CD003443.  
56.David A, Quraishi S, Rathbone J. Depot perphenazine decanoate and enanthate for schizophrenia. Cochrane Database of Syst Rev. 2005;(3):CD001717.  
57.Quraishi S, David A. Depot flupenthixol decanoate for schizophrenia or other similar psychotic disorders. Cochrane Database of Syst Rev. 2000;(2):CD001470.  
58.Chakrabarti A, Bagnall A, Chue P, Fenton M, Palaniswamy V, Wong W, et al. Loxapine for schizophrenia. Cochrane Database Syst Rev. 2007;(4):CD001943.  
59.Leucht S, Hartung B. Benperidol for schizophrenia. Cochrane Database of Syst Rev. 2005;(2):CD003083.  
60.Purgato M, Adams CE. Bromperidol decanoate (depot) for schizophrenia. Cochrane Database Syst Rev. 2011;(9):CD001719.  
61.Klemp M, Tvete IF, Skomedal T, Gaasemyr J, Natvig B, Aursnes I. A review and Bayesian meta-analysis of clinical efficacy and adverse effects of 4 atypical neuroleptic drugs compared with haloperidol and placebo. J Clin Psychopharmacol. 2011;31(6):698-704.  
62.Geddes J, Freemantle N, Harrison P, Bebbington P. Atypical antipsychotics in the treatment of schizophrenia: systematic overview and meta-regression analysis. BMJ. 2000;321(7273):1371-6.  
63.Leucht S, Wahlbeck K, Hamann J, Kissling W. New generation antipsychotics versus low-potency conventional antipsychotics: a systematic review and meta-analysis. Lancet. 2003;361(9369):1581-9.  
64.Davis JM, Chen N, Glick ID. A meta-analysis of the efficacy of second-generation antipsychotics. Arch Gen Psychiatry. 2003;60(6):553-64.  
65.Leucht S, Barnes TR, Kissling W, Engel RR, Correll C, Kane JM. Relapse prevention in schizophrenia with new-generation antipsychotics: a systematic review and exploratory meta-analysis of randomized, controlled trials. Am J Psychiatry. 2003;160(7):1209-22.  
66.Davis JM, Chen N. Dose response and dose equivalence of antipsychotics. J Clin Psychopharmacol. 2004;24(2):192-208.  
67.Davis JM, Chen N. Old versus new: weighing the evidence between the first- and second-generation antipsychotics. Eur Psychiatry. 2005;20(1):7-14.  
68.Lieberman JA, Stroup TS, McEvoy JP, Swartz MS, Rosenheck RA, Perkins DO, et al. Effectiveness of antipsychotic drugs in patients with chronic schizophrenia. N Engl J Med. 2005;353(12):1209-23.  
69.Stroup TS, Lieberman JA, McEvoy JP, Swartz MS, Davis SM, Rosenheck RA, et al. Effectiveness of olanzapine, quetiapine, risperidone, and ziprasidone in patients with chronic schizophrenia following discontinuation of a previous atypical antipsychotic. Am J Psychiatry. 2006;163(4):611-22.  
70.Jones PB, Barnes TR, Davies L, Dunn G, Lloyd H, Hayhurst KP, et al. Randomized controlled trial of the effect on Quality of Life of second- vs first-generation antipsychotic drugs in schizophrenia: Cost Utility of the Latest Antipsychotic Drugs in Schizophrenia Study (CUtLASS 1). Arch Gen Psychiatry. 2006;63(10):1079-87.  
71.Citrome L, Stroup TS. Schizophrenia, Clinical Antipsychotic Trials of Intervention Effectiveness (CATIE) and number needed to treat: how can CATIE inform clinicians? Int J Clin Pract. 2006;60(8):933-40.  
72.Martin JL, Perez V, Sacristan M, Rodriguez-Artalejo F, Martinez C, Alvarez E. Meta-analysis of drop-out rates in randomised clinical trials, comparing typical and atypical antipsychotics in the treatment of schizophrenia. Eur Psychiatry. 2006;21(1):11-20.  
73.Kahn RS, Fleischhacker WW, Boter H, Davidson M, Vergouwe Y, Keet IP, et al. Effectiveness of antipsychotic drugs in first-episode schizophrenia and schizophreniform disorder: an open randomised clinical trial. Lancet. 2008;371(9618):1085-97.  
74.Rabinowitz J, Levine SZ, Barkai O, Davidov O. Dropout rates in randomized clinical trials of antipsychotics: a meta-analysis comparing first- and second-generation drugs and an examination of the role of trial design features. Schizophr Bull. 2009;35(4):775-88.  
75.Leucht S, Corves C, Arbter D, Engel RR, Li C, Davis JM. Second-generation versus first-generation antipsychotic drugs for schizophrenia: a meta-analysis. Lancet. 2009;373(9657):31-41.  
76.Woodward ND, Purdon SE, Meltzer HY, Zald DH. A meta-analysis of neuropsychological change to clozapine, olanzapine, quetiapine, and risperidone in schizophrenia. Int J Neuropsychopharmacol. 2005;8(3):457-72.  
77.Mishara AL, Goldberg TE. A meta-analysis and critical review of the effects of conventional neuroleptic treatment on cognition in schizophrenia: opening a closed book. Biol Psychiatry. 2004;55(10):1013-22.  
78.Keefe RS, Bilder RM, Davis SM, Harvey PD, Palmer BW, Gold JM, et al. Neurocognitive effects of antipsychotic medications in patients with chronic schizophrenia in the CATIE Trial. Arch Gen Psychiatry. 2007;64(6):633-47. 79.Marriott RG, Neil W, Waddingham S. Antipsychotic medication for elderly people with schizophrenia. Cochrane Database Syst Rev. 2006;(1):CD005580.  
80.Rummel C, Hamann J, Kissling W, Leucht S. New generation antipsychotics for first episode schizophrenia. Cochrane Database of Syst Rev. 2003;(4):CD004410.  
81.Armenteros JL, Davies M. Antipsychotics in early onset Schizophrenia: Systematic review and meta-analysis. Eur Child Adolesc Psychiatry. 2006;15(3):141-8.  
82.Kennedy E, Kumar A, Datta SS. Antipsychotic medication for childhood-onset schizophrenia. Cochrane Database Syst Rev. 2007;(3):CD004027.  
83.Arunpongpaisal S, Ahmed I, Aqeel N, Suchat P. Antipsychotic drug treatment for elderly people with lateonset schizophrenia. Cochrane Database Syst Rev. 2003;(2):CD004162.  
84.Correll CU, Rummel-Kluge C, Corves C, Kane JM, Leucht S. Antipsychotic combinations vs monotherapy in schizophrenia: a meta-analysis of randomized controlled trials. Schizophr Bull. 2009;35(2):443-57.  
85.Sivaraman P, Rattehalli RD, Jayaram MB. Levomepromazine for schizophrenia. Cochrane Database Syst Rev. 2010;(10):CD007779. 86.Rathbone J, McMonagle T. Pimozide for schizophrenia or related psychoses. Cochrane Database of Syst Rev. 2007;(3):CD001949. 87.Fenton M, Rathbone J, Reilly J, Sultana A. Thioridazine for schizophrenia. Cochrane Database Syst Rev. 2007;(3):CD001944. 88.Marques LO, Soares BG, Lima MS. Trifluoperazine for schizophrenia. Cochrane Database Syst Rev. 2004;1(1):CD003545.  
- 89.Adams CE, Awad G, Rathbone J, Thornley B. Chlorpromazine versus placebo for schizophrenia. Cochrane  
- Database Syst Rev. 2007;(2):CD000284. 90.Matar HE, Almerie MQ. Oral fluphenazine versus placebo for schizophrenia. Cochrane Database Syst Rev.  
- 2007;(1):CD006352.  
- 91.David A, Adams CE, Eisenbruch M, Quraishi S, Rathbone J. Depot fluphenazine decanoate and enanthate for  
- schizophrenia. Cochrane Database of Syst Rev. 2005;(1):CD000307.  
- 92.Irving CB, Adams CE, Lawrie S. Haloperidol versus placebo for schizophrenia. Cochrane Database Syst Rev.  
- 2006;(4):CD003082.  
93. Schulz SC, Thomson R, Brecher M. The efficacy of quetiapine vs haloperidol and placebo: a meta-analytic study of efficacy. Schizophr Res. 2003;62(1-2):1-12. 94.Leucht C, Kitzmantel M, Chua L, Kane J, Leucht S. Haloperidol versus chlorpromazine for schizophrenia. 2008;(1):CD004278. 95.Quraishi S, David A. Depot haloperidol decanoate for schizophrenia. Cochrane Database of Syst Rev. 2000;(2):CD001361.  
96.Komossa K, Rummel-Kluge C, Schmid F, Hunger H, Schwarz S, El-Sayeh HG, et al. Aripiprazole versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2009;(4):CD006569.  
97.El-Sayeh HG, Morganti C. Aripiprazole for schizophrenia. Cochrane Database Syst Rev. 2006;(2):CD004578.  
98. Kumar A, Strech D. Zuclopenthixol dihydrochloride for schizophrenia. Cochrane Database Syst Rev. 2005;(4):CD005474.  
99.Gibson RC, Fenton M, Coutinho ES, Campbell C. Zuclopenthixol acetate for acute schizophrenia and similar serious mental illnesses. Cochrane Database Syst Rev. 2004;3(3):CD000525.  
100.Coutinho E, Fenton M, Quraishi S. Zuclopenthixol decanoate for schizophrenia and other serious mental illnesses. Cochrane Database of Syst Rev. 2000;(2):CD001164.  
101.Duggan L, Fenton M, Rathbone J, Dardennes R, El-Dosoky A, Indran S. Olanzapine for schizophrenia. Cochrane Database Syst Rev. 2005;(2):CD001359.  
102. Jayaram MB, Hosalli P. Risperidone versus olanzapine for schizophrenia. Cochrane Database Syst Rev. 2005;(2):CD005237.  
103.Jayaram MB, Hosalli P, Stroup TS. Risperidone versus olanzapine for schizophrenia. Cochrane Database Syst Rev. 2006;(2):CD005237.  
104.Komossa K, Rummel-Kluge C, Hunger H, Schmid F, Schwarz S, Duggan L, et al. Olanzapine versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2010;(3):CD006654.  
105.Dinesh M, David A, Quraishi SN. Depot pipotiazine palmitate and undecylenate for schizophrenia. Cochrane Database Syst Rev. 2004;(4):CD001720.  
106. Leucht S. Amisulpride a selective dopamine antagonist and atypical antipsychotic: results of a meta-analysis of randomized controlled trials. Int J Neuropsychopharmacol. 2004;7 Suppl 1:S15-20.  
107.Leucht S, Pitschel-Walz G, Engel RR, Kissling W. Amisulpride, an unusual "atypical" antipsychotic: a metaanalysis of randomized controlled trials. Am J Psychiatry. 2002;159(2):180-90.  
108.Komossa K, Rummel-Kluge C, Hunger H, Schmid F, Schwarz S, Silveira da Mota Neto JI, et al. Amisulpride versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2010;(1):CD006624.  
109.Mota NE, Lima MS, Soares BG. Amisulpride for schizophrenia. Cochrane Database Syst Rev. 2002;(2):CD001357.  
110.Komossa K, Rummel-Kluge C, Schmid F, Hunger H, Schwarz S, Srisurapanont M, et al. Quetiapine versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2010;(1):CD006625.  
111.Buckley PF. Maintenance treatment for schizophrenia with quetiapine. Hum Psychopharmacol. 2004;19(2):121-4. 112.Srisurapanont M, Maneeton B, Maneeton N. Quetiapine for schizophrenia. Cochrane Database Syst Rev. 2004;(2):CD000967.  
113.Nussbaum AM, Stroup TS. Paliperidone palmitate for schizophrenia. Cochrane Database Syst Rev. 2012;6:CD008296.  
114.Komossa K, Rummel-Kluge C, Hunger H, Schwarz S, Bhoopathi PS, Kissling W, et al. Ziprasidone versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2009;(4):CD006627.  
115.Bagnall A, Lewis RA, Leitner ML. Ziprasidone for schizophrenia and severe mental illness. Cochrane Database Syst Rev. 2000;(4):CD001945.  
116.Rattehalli RD, Jayaram MB, Smith M. Risperidone versus placebo for schizophrenia. Schizophr Bull. 2010;36(3):448-9.  
117.Rattehalli RD, Jayaram MB, Smith M. Risperidone versus placebo for schizophrenia. Cochrane Database Syst Rev. 2010;(1):CD006918.  
118.Hosalli P, Davis JM. Depot risperidone for schizophrenia. Cochrane Database Syst Rev. 2003;(4):CD004161.  
119.Hunter RH, Joy CB, Kennedy E, Gilbody SM, Song F. Risperidone versus typical antipsychotic medication for schizophrenia. Cochrane Database Syst Rev 2003;(2):CD000440.  
120.Gilbody SM, Bagnall AM, Duggan L, Tuunainen A. Risperidone versus other atypical antipsychotic medication for schizophrenia. Cochrane Database Syst Rev. 2000;(3):CD002306.  
121.Soares BG, Lima MS. Penfluridol for schizophrenia. Cochrane Database Syst Rev. 2006;(2):CD002923.  
122.Asenjo Lobos C, Komossa K, Rummel-Kluge C, Hunger H, Schmid F, Schwarz S, et al. Clozapine versus other atypical antipsychotics for schizophrenia. Cochrane Database Syst Rev. 2010;(11):CD006633.  
123.Soares BG, Fenton M, Chue P. Sulpiride for schizophrenia. Cochrane Database Syst Rev. 2000;(2):CD001162.  
124.Wang J, Omori IM, Fenton M, Soares B. Sulpiride augmentation for schizophrenia. Cochrane Database Syst Rev. 2010;(1):CD008125.  
125.Omori IM, Wang J. Sulpiride versus placebo for schizophrenia. Cochrane Database Syst Rev. 2009;(2):CD007811.  
126. Bhattacharjee J, El-Sayeh HG. Aripiprazole versus typical antipsychotic drugs for schizophrenia. Cochrane Database Syst Rev. 2008;(3):CD006617.  
127.Essali A, Al-Haj Haasan N, Li C, Rathbone J. Clozapine versus typical neuroleptic medication for schizophrenia. Cochrane Database Syst Rev. 2009;(1):CD000059.  
128.Chakos M, Lieberman J, Hoffman E, Bradford D, Sheitman B. Effectiveness of second-generation antipsychotics in patients with treatment-resistant schizophrenia: a review and meta-analysis of randomized trials. Am J Psychiatry. 2001;158(4):518-26.  
129.Moncrieff J. Clozapine v. conventional antipsychotic drugs for treatment-resistant schizophrenia: a reexamination. Br J Psychiatry. 2003;183:161-6.  
130.McEvoy JP, Lieberman JA, Stroup TS, Davis SM, Meltzer HY, Rosenheck RA, et al. Effectiveness of clozapine versus olanzapine, quetiapine, and risperidone in patients with chronic schizophrenia who did not respond to prior atypical antipsychotic treatment. Am J Psychiatry. 2006;163(4):600-10.  
131.Lewis SW, Barnes TR, Davies L, Murray RM, Dunn G, Hayhurst KP, et al. Randomized controlled trial of effect of prescription of clozapine versus other second-generation antipsychotic drugs in resistant schizophrenia. Schizophr Bull. 2006;32(4):715-23.  
132.Tuunainen A, Wahlbeck K, Gilbody SM. Newer atypical antipsychotic medication versus clozapine for schizophrenia. Cochrane Database Syst Rev. 2000;(2):CD000966.  
133.Cipriani A, Boso M, Barbui C. Clozapine combined with different antipsychotic drugs for treatment resistant schizophrenia. Cochrane Database Syst Rev. 2009;(3):CD006324.  
134.Oh PI, Iskedjian M, Addis A, Lanctot K, Einarson TR. Pharmacoeconomic evaluation of clozapine in treatment-resistant schizophrenia: a cost-utility analysis. Can J Clin Pharmacol. 2001;8(4):199-206.  
135.Barbui C, Signoretti A, Mule S, Boso M, Cipriani A. Does the addition of a second antipsychotic drug improve clozapine treatment? Schizophr Bull. 2009;35(2):458-68.  
136.Paton C, Whittington C, Barnes TR. Augmentation with a second antipsychotic in patients with schizophrenia who partially respond to clozapine: a meta-analysis. J Clin Psychopharmacol. 2007;27(2):198-204.  
137.Kontaxakis VP, Ferentinos PP, Havaki-Kontaxaki BJ, Paplos KG, Pappa DA, Christodoulou GN. Risperidone augmentation of clozapine: a critical review. Eur Arch Psychiatry Clin Neurosci. 2006;256(6):350-5.  
138.Zink M. Augmentation of olanzapine in treatment-resistant schizophrenia. J Psychiatry Neurosci. 2005;30(6):409-15.  
139.Taylor DM, Smith L, Gee SH, Nielsen J. Augmentation of clozapine with a second antipsychotic - a metaanalysis. Acta Psychiatr Scand. 2012;125(1):15-24.  
140.Premkumar TS, Pick J. Lamotrigine for schizophrenia. Cochrane Database Syst Rev. 2006;(4):CD005962.  
141.Tiihonen J, Wahlbeck K, Kiviniemi V. The efficacy of lamotrigine in clozapine-resistant schizophrenia: a systematic review and meta-analysis. Schizophr Res. 2009;109(1-3):10-4.  
142.Elkis H, Alves T, Eizenman I. Reliability and validity of the Brazilian version of the BPRS Anchored. Schizophr Res. 1999;36:7.  
143.Romano F, Elkis H. Tradução e adaptação de um instrumento de avaliação psicopatológica das psicoses: a Escala Breve de Avaliação Psiquiátrica - versão Ancorada (BPRS-A). J Bras Psiquiatr. 1996;45:43-9.  
144.Zuardi AW, Loureiro SR, Rodrigues CR, Correa AJ, Glock SS. Estudo da estrutura fatorial, fidedignidade e validade da tradução e adaptação para o português da Escala de Avaliação Psiquiátrica Breve (BPRS) modificada. Rev ABP-APAL. 1994;16(2):63-8.  
145.Chouinard G, Ross-Chouinard A, Annable L, Jones B. Extrapyramidal Symptom Rating Scale. Can J Neurol Sci. 1980;7:233-9.  
146.Barnes TR. A rating scale for drug-induced akathisia. Br J Psychiatry. 1989;154:672-6.  
147.Guy WA. Abnormal Involuntary Movement Scale (AIMS). ECDEU assessment manual for psychopharmacology. Washington: U.S. Public Health Service; 1976:534-537.  
148.Meltzer HY, Alphs L, Green AI, Altamura AC, Anand R, Bertoldi A, et al. Clozapine treatment for suicidality in schizophrenia: International Suicide Prevention Trial (InterSePT). Arch Gen Psychiatry. 2003;60(1):82-91.  
149.Hennen J, Baldessarini RJ. Suicidal risk during treatment with clozapine: a meta-analysis. Schizophr Res. 2005;73(2-3):139-45.  
150.Adams CE, Fenton MK, Quraishi S, David AS. Systematic meta-review of depot antipsychotic drugs for people with schizophrenia. Br J Psychiatry. 2001;179:290-9.  
151.Knapp M, Ilson S, David A. Depot antipsychotic preparations in schizophrenia: the state of the economic evidence. Int Clin Psychopharmacol. 2002;17(3):135-40.  
152.DEF - Dicionário de Especialidades Farmacêuticas. São Paulo: Editora de Publicações Científicas; 2009.  
153.Cordioli AV. Psicofármacos: consulta rápida. 3º ed. Porto Alegre: Editora Artes Médicas; 2004.  
154.Li C, Xia J, Wang J. Risperidone dose for schizophrenia. Cochrane Database Syst Rev. 2009;(4):CD007474.  
155.Ezewuzie N, Taylor D. Establishing a dose-response relationship for oral risperidone in relapsed schizophrenia. J Psychopharmacol. 2006;20(1):86-90.  
156.Kim CY, Shin YW, Joo YH, Hong JP, Lee GH, Choi SK. Risperidone dosing pattern and clinical outcome in psychosis: an analysis of 1713 cases. J Clin Psychiatry. 2005;66(7):887-93.  
157.Sparshatt A, Jones S, Taylor D. Quetiapine: dose-response relationship in schizophrenia. CNS Drugs. 2008;22(1):49-68; discussion 69-72.  
158.Meltzer HY, Bobo WV, Roy A, Jayathilake K, Chen Y, Ertugrul A, et al. A randomized, double-blind comparison of clozapine and high-dose olanzapine in treatment-resistant patients with schizophrenia. J Clin Psychiatry. 2008;69(2):274-85.  
159.Kumra S, Kranzler H, Gerbino-Rosen G, Kester HM, De Thomas C, Kafantaris V, et al. Clozapine and "highdose" olanzapine in refractory early-onset schizophrenia: a 12-week randomized and double-blind comparison. Biol Psychiatry. 2008;63(5):524-9.  
160.Citrome L, Kantrowitz JT. Olanzapine dosing above the licensed range is more efficacious than lower doses: fact or fiction? Expert Rev Neurother. 2009;9(7):1045-58.  
161.Liu X, De Haan S. Chlorpromazine dose for people with schizophrenia. Cochrane Database Syst Rev. 2009;(2):CD007778.  
162.American Diabetes Association; American Psychiatric Association; American Association of Clinical Endocrinologists; North American Association for the Study of Obesity. Consensus development conference on antipsychotic drugs and obesity and diabetes. J Clin Psychiatry. 2004;65(2):267-72.  
163.Jin H, Meyer JM, Jeste DV. Atypical antipsychotics and glucose dysregulation: a systematic review. Schizophr Res. 2004;71(2-3):195-212.  
164.Mukundan A, Faulkner G, Cohn T, Remington G. Antipsychotic switching for people with schizophrenia who have neuroleptic-induced weight or metabolic problems. Cochrane Database Syst Rev. 2010;(12):CD006629.  
165.Smith M, Hopkins D, Peveler RC, Holt RI, Woodward M, Ismail K. First- v. second-generation antipsychotics and risk for diabetes in schizophrenia: systematic review and meta-analysis. Br J Psychiatry. 2008;192(6):406-11.  
166.Cavazzoni P, Mukhopadhyay N, Carlson C, Breier A, Buse J. Retrospective analysis of risk factors in patients with treatment-emergent diabetes during clinical trials of antipsychotic medications. Br J Psychiatry Suppl. 2004;47:S94101.  
167.Almerie MQ, Alkhateeb H, Essali A, Matar HE, Rezk E. Cessation of medication for people with schizophrenia already stable on chlorpromazine. Cochrane Database Syst Rev. 2007;(1):CD006329.  
168. Leucht S, Tardy M, Komossa K, Heres S, Kissling W, Salanti G, et al. Antipsychotic drugs versus placebo for relapse prevention in schizophrenia: a systematic review and meta-analysis. Lancet. 2012;379(9831):2063-71.  
169.Leucht S, Tardy M, Komossa K, Heres S, Kissling W, Davis JM. Maintenance treatment with antipsychotic drugs for schizophrenia. Cochrane Database Syst Rev. 2012;5:CD008016.

---

<!-- METADADOS: doenca: Esquizofrenia | secao: TERMO DE ESCLARECIMENTO E RESPONSABILIDADE -->
RISPERIDONA, QUETIAPINA, ZIPRASIDONA, OLANZAPINA E CLOZAPINA.  
Eu,________________ (nome do(a) paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de risperidona, quetiapina, ziprasidona, olanzapina e clozapina, indicadas para o tratamento da esquizofrenia .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico _______________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- redução dos sintomas e da frequência das crises;  
- redução das internações hospitalares.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- <u>clozapina: medicamento classificado na gestação como categoria B (pesquisas em animais não mostraram</u> anormalidades nos descendentes, porém não há estudos em humanos; risco para o bebê é muito improvável);  
- <u>risperidona, quetiapina, ziprasidona e olanzapina: medicamentos classificados na gestação como categoria C</u> (pesquisas em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- <u>clozapina: contraindicada nos casos de leucopenia (contagem de células brancas do sangue abaixo de 3.500</u> células/mm3). São necessários controles periódicos com hemograma (semanal nas primeiras 18 semanas e mensal após); - <u>efeitos adversos mais comuns da risperidona: agitação, nervosismo, alterações de visão, disfunção sexual,</u> tonturas, alterações na menstruação, tremores, movimentos involuntários, insônia, distúrbios urinários, agressividade, diminuição da concentração e da memória, vermelhidão e coceira na pele, fraqueza, cansaço, prisão de ventre, tosse, boca seca, diarreia, sonolência, dor de cabeça, má digestão, náuseas, ganho de peso;  
- <u>efeitos adversos mais comuns da quetiapina: prisão de ventre, vertigens, sonolência, boca seca, indigestão,</u> aumento de peso, tontura ao levantar;  
- efeitos adversos mais comuns da ziprasidona: sonolência, insônia, tonturas, pressão baixa, tremores, alterações cardíacas, fraqueza, dor de cabeça, prisão de ventre, boca seca, aumento da salivação, náuseas, vômitos, nervosismo, agitação;  
- efeitos adversos mais comuns da olanzapina: dor de cabeça, sonolência, insônia, agitação, nervosismo, ansiedade, boca seca, tonturas ao levantar, taquicardia, inchaço, amnésia, febre, vermelhidão na pele, inquietação, prisão de ventre, dor abdominal, ganho de peso, aumento do apetite, rigidez na nuca, dores no corpo;  
- <u>efeitos adversos mais comuns da clozapina: aumento da frequência cardíaca, palpitações, tonturas, prisão de</u> ventre, febre, dor de cabeça, cansaço, sonolência, produção aumentada ou diminuída de saliva, aumento de suor, náuseas, vômitos, enjoo, visão turva, aumento de peso, alteração das células do sangue (agranulocitose, eosinofilia, granulocitopenia, leucopenia, trombocitopenia);  
- medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.          (     ) Sim     (     ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) risperidona  
- (    ) quetiapina  
- (    ) ziprasidona  
- (    ) olanzapina  
- (    ) clozapina  
Local:                                                             Data:  
|Nome dopaciente:|
|---|
|Cartão Nacional de Saúde:|
|Nome do responsável legal:|
|Documento de identificação do responsável legal:|
|_____________________________________<br>Assinatura dopaciente ou do responsável legal|
|Médico<br>responsável:<br>CRM:<br>UF:|  
___________________________ Assinatura e carimbo do médico Data:____________________  
Observação: Este Termo é obrigatório ao se solicitar o fornecimento de medicamento do Componente Especializado da Assistência Farmacêutica e deverá ser preenchido em duas vias: uma será arquivada na farmácia, e a outra, entregue ao usuário ou a seu responsável legal.  
Escala Breve de Avaliação Psiquiátrica - BPRS Ancorada com sugestão de perguntas  
Versão Ancorada - BPRS-A (Woerner, 1998, trad. Romano e Elkis, 1996) mais Entrevista Clínica Estruturada  
|Paciente:<br>Número:<br>Data:|
|---|
|Entrevistador:<br>Fase:|
|Instruções: A Escala é composta de 18 itens a serem<br>avaliados. Os itens assinalados com OBSERVAÇÃO|
|(3, 4, 7, 13, 14, 16, 17, 18) devem ser avaliados<br>tomando por base OBSERVAÇÕES feitas durante a<br>entrevista. Os itens assinalados com RELATO DO|
|PACIENTE devem ser avaliados a partir<br>de informação RELATADA (ou seja, SUBJETIVA)<br>referente ao período escolhido (em geral 1 semana). As<br>|
|perguntas-guia em negrito devem ser formuladas<br>diretamente nos itens em que se avalia o relato do<br>paciente.<br>Início da entrevista:|
|Comece com estas perguntas e utilize as mesmas para<br>completar o item 18 (Orientação):|
|Qual seu nome completo? E sua idade? Onde você<br>mora? Está trabalhando atualmente? (Já trabalhou<br>anteriormente? Em quê?)|
|Quanto tempo faz que você está aqui? Conte-me por<br>que motivo você foi<br>internado. Quando isso começou? O que aconteceu|
|depois? Você pode me dizer que dia é hoje (semana-<br>mês-ano)?|  
|1<br>RELATO<br>DO<br>PACIENTE|PREOCUPAÇÃO<br>SOMÁTICA:<br>Grau de preocupação com a saúde<br>física. Avaliar o grau no qual a saúde<br>física é percebida como<br>um problema pelo paciente, quer as<br>queixas sejam baseadas na realidade<br>ou não. Não pontuar o simples<br>relato de sintomas físicos. Avaliar<br>apenas apreensão (ou preocupação)<br>sobre problemas físicos (reais ou<br>imaginários).|
|---|---|
||Como costuma ser sua saúde física<br>(do corpo)? Como esteve sua saúde<br>no<br>último<br>ano?<br>Você<br>está<br>|
|Pergunta-guia|preocupado com algum<br>problema de saúde agora? Você<br>sente<br>que<br>tem<br>alguma<br>coisa|
||incomum acontecendo com seu<br>corpo ou cabeça?|
|0<br>1<br>2<br>3|Não relatado.<br>Muito leve: Ocasionalmente fica<br>levemente preocupado com o corpo,<br>sintomas ou<br>|
|4|doenças físicas.<br>Leve:<br>Ocasionalmente<br>fica<br>preocupado com o corpo de<br>forma moderada ou frequentemente<br>fica levemente apreensivo.|
|5|Moderado:<br>Ocasionalmente<br>fica|
|6|muito<br>preocupado<br>ou<br>moderadamente preocupado<br>com frequência.<br>Moderadamente<br>grave:<br>Frequentemente fica muito<br>|
||preocupado.<br>Grave: Fica muito preocupado a<br>maior parte do tempo.<br>Muito grave: Fica muito preocupado<br>praticamente o tempo todo.|
||ANSIEDADE: Preocupação, medo<br>ou preocupação excessiva acerca do<br>presente ou futuro. Pontuar somente<br>|
|RELATO|a partir de relato verbal das<br>exeriências subjetivas do|
|2<br>DO<br>PACIENTE|p<br>paciente. Não inferir ansiedade a<br>partir<br>de<br>sinais<br>físicos<br>ou|
||mecanismos de defesa neuróticos.<br> <br> <br>|
||Não<br>pontuar<br>se<br>restrito<br>a|
||<br>preocupação somática.|
||Você está preocupado com alguma<br>coisa? Você tem se sentido tenso ou|
||ansioso a maior parte do tempo?<br>|
||(Quando se sente|
|Pergunta-guia|<br>assim, você consegue saber o|
||porquê?<br>De<br>que<br>forma<br>suas<br>ansiedades ou preocupações afetam<br>o seu dia a dia? Existe algo que ajuda<br>a melhorar essa sensação?)<br>|
|0|Não relatado.|
|1<br>2|Muito leve: Ocasionalmente se sente<br>levemente ansioso.|  
|3<br>4|Leve: Ocasionalmente se sente<br>moderadamente<br>ansioso<br>ou|
|---|---|
|<br>5|<br> <br> <br>frequentemente se sente levemente<br>ansioso.<br>Moderado: Ocasionalmente se sente<br>muito ansioso ou frequentemente se<br>sente moderadamente ansioso.<br>Moderadamente<br>grave:<br>Frequentemente se<br>sente muito ansioso<br>Grave: Sente-se muito ansioso a<br>maiorparte do tempo.|
||RETRAIMENTO<br>AFETIVO:<br>Deficiência no relacionamento com<br>o entrevistador e na situação da<br>entrevista. Manifestações<br>evidentes<br>dessa<br>deficiência<br>incluem: falta de contato visual<br>(troca de olhares); o paciente não se|
|OBSERVAÇ<br>Ã|aproxima<br>do<br>entrevistador;<br>|
|3<br>O|apresenta uma|
|<br>DO<br>|falta<br>de<br>envolvimento<br>e<br>|
|PACIENTE|compromisso com a entrevista.|
||<br>Diferenciar<br>de<br>AFETO|
||EMBOTADO,<br>no<br>qual<br>são<br>pontuados|
||deficiências na expressão facial,<br>gestualidade e tom de voz. Pontuar a<br>partir de observações feitas durante|
||a entrevista.|
|0|Não observado.|
|1|Muito leve: Ocasionalmente deixa|
|2<br>|de encarar o entrevistador.|
|3<br>4|Leve: Como acima, porém mais<br>freuente|
||q.<br>Moderado: Demonstra dificuldade<br>em encarar o|
||entrevistador, mas ainda parece<br>|
|5|engajado na entrevista e responde|
|6|<br>apropriadamente<br>a<br>todas<br>as<br>questões.|
||<br>Moderadamente<br>grave:<br>Olha<br>fixamente o|
||<br>chão e afasta-se do entrevistador,<br>mas ainda parece moderadamente<br>engajado na entrevista|
||.<br>Grave: Como acima, porém mais<br>persistente e disseminado.|
||Muito grave: Parece estar “aéreo”,<br>“nas|
||nuvens”<br>ou<br>“viajando”<br>(total<br>ausência de vínculo emocional) e<br>desproporcionalmente<br>não<br>envolvido ou não comprometido<br>com a situação da entrevista. (Não<br> <br> <br> <br>|
||pontuar<br>se<br>explicado<br>pela<br>desorientação)|
|OBSERVAÇ|.<br>DESORGANIZAÇÃO|
|4<br><br>ÃO|<br>CONCEITUAL:<br>Grau<br>de|
|<br>DO|incompreensibilidade da fala Incluir|
|<br>PACIENTE|.<br>qualquer tipo de desordem formal de|  
||pensamento<br>(por<br>exemplo,<br>iõ f iêi|
|---|---|
||assocaçes rouxas, ncoernca,<br>fuga de ideias, neologismos). NÃO<br>incluir mera circunstancialidade ou<br>fala maníaca, mesmo<br>que acentuada. NÃO pontuar a<br>partir de impressões subjetivas do<br>paciente<br>(por<br>exemplo,<br>“meus<br>pensamentos estão voando”, “não<br>consigo manter o pensamento”,<br>“meus|
||pensamentos se misturam todos”).<br>Pontuar SOMENTE a partir de<br>observações<br>feitas<br>durante<br>a<br>entrevista.|
|0|<br>Não observado.|
|1<br>2<br>3|Muito<br>leve:<br>Levemente<br>vago,<br>todavia<br>de<br>significação<br>clínica<br>duvidosa.|
|4|Leve: Frequentemente vago, mas é<br>possível prosseguir a<br>entrevista.|
|5|Moderado:<br>Ocasionalmente<br>faz|
|6|afirmações<br>irrelevantes,<br>uso<br>infrequente de neologismos|
||ou<br>associações<br>moderadamente<br>frouxas.<br>Moderadamente<br>grave:<br>Como<br>acima, porém mais frequente.<br>Grave:<br>Desordem<br>formal<br>do<br>pensamento presente a maior parte<br>da entrevista, tornando-a muito<br>difícil.|
||Muito<br>grave:<br>Muito<br>pouca|
||informação<br>coerente<br>pode<br>ser<br>|
||obtida.|
|RELATO|SENTIMENTOS<br>DE<br>CULPA:<br>Preocupação<br>ou<br>remorso<br>desproporcional<br>pelo<br>passado.<br>Pontuar a partir das experiências<br>subjetivas|
|5<br>DO<br>PACIENTE|<br>de culpa evidenciadas por meio de<br>relato<br>verbal.<br>Não<br>inferir<br>sentimentos de culpa a partir de<br>depressão, ansiedade ou defesas<br>neuróticas.|
|Pergunta-<br>guia|Nos últimos dias você tem se sentido<br>um peso para sua família ou<br>colegas? Você tem se sentido<br>culpado por alguma coisa feita no<br>passado? Você acha que o que está<br>passando agora é um tipo de castigo?<br>(Porque você acha isso?)|
|0<br>1<br>2|Não relatado.<br>Muito leve: Ocasionalmente se sente<br>levemente culpado.|
|3|<br>Leve: Ocasionalmente se sente|
||moderadamente<br>culpado<br>ou<br>frequentemente se sente levemente<br>culpado.|  
|4<br>5|Moderado: Ocasionalmente se sente<br>it ld  ftt|
|---|---|
|<br>6|muo cupao ou requenemene se<br>sente moderadamente culpado.<br>|
||Moderadamente<br>grave:<br>Frequentemente se sente muito<br>culpado.<br>Grave: Sente-se muito culpado a<br>maior parte do tempo ou apresenta<br>delírio de culpa encapsulado.<br>Muito grave: Apresenta sentimento<br>de culpa angustiante e constante ou<br>delírios de culpa disseminados.|
|OBSERVA<br>ÃO|TENSÃO:<br>Avaliar<br>inquietação<br>motora (agitação) observada durante<br>a entrevista. Não pontuar a partir de<br>iêi|
|6<br>Ç<br>DO<br>PACIENTE|experncas<br>subjetivas relatadas pelo paciente.<br>Desconsiderar<br>patogênese<br>presumida (por exemplo, discinesia<br>tardia).|
|0<br>1<br>2|Não observado.<br>Muito leve: Fica ocasionalmente<br>agitado.|
|3|<br>Leve: Fica frequentemente agitado.<br>Moderado: Agita-se constantemente<br>ou frequentemente;|
|4|torce as mãos e puxa a roupa.|
|5|Moderadamente<br>grave:<br>Agita-se|
|6|<br> <br>constantemente; torce as mãos e<br>puxa a roupa|
||.<br>Grave: Não consegue ficar sentado,<br>isto é, precisa andar.|
||Muito grave: Anda de maneira<br>frenética.|
||MANEIRISMOS E POSTURA:<br>Comportamento motor incomum ou<br>não<br>natural.<br>Pontuar<br>apenas|
|OBSERVA<br>|anormalidade de<br>|
|<br>ÇÃO|movimento. NÃO pontuar aqui|
|7<br> <br>DO|<br>simples<br>aumento<br>da<br>atividade|
|PACIENTE|motora.<br>Considerar<br>frequência,<br>duração e grau do caráter bizarro.<br>Desconsiderar<br>patogênese|
||presumida.|
|0|Não observado.|
|1<br>2|Muito<br>leve:<br>Comportamento<br>estranho, mas de significação clínica|
|3|<br>duvidosa (por|
|4|exemlo<br>um<br>riso<br>imotivado|
||p,<br> <br> <br> <br>ocasional, movimentos de lábio<br>ift|
||nrequenes).<br>Leve:<br>Comportamento<br>estranho,<br>mas não obviamente|
||bizarro (por exemplo, às vezes|
|5|balança a cabeça ritmadamente de|
|6|<br>um lado para outro, movimenta os<br>dedos<br>de<br>maneira<br>anormal<br>intermitentemente).|
||<br>Moderado: Adota posição de ioga<br>por um breve período, às vezes põe<br>a línguapara fora,balança o corpo.|  
||Moderadamente<br>grave:<br>Como<br>i<br>é<br>i<br>f|
|---|---|
||acma,<br>porm<br>mas<br>requente,<br>intenso ou disseminado.<br>Grave: Como acima, porém mais<br>frequente, intenso ou disseminado.<br>Muito grave: Postura bizarra durante<br>a<br>maior<br>parte<br>da<br>entrevista,<br>movimentos anormais constantes<br>em várias áreas do corpo.|
||IDEIAS<br>DE<br>GRANDEZA:<br>Autoestima<br>(autoconfiança)<br>exagerada ou apreciação desmedida<br>dos próprios talentos, poderes,<br>habilidades,<br>conquistas,<br>conhecimento,|
||importância ou identidade. NÃO<br>pontuar mera qualidade<br>grandiosa<br>de<br>alegações<br>(por<br>exemplo, “sou o pior pecador do|
|RELATO|mundo”, “todo o país está tentando<br>”|
|8<br>DO<br>PACIENTE|me matar) a menos que a<br>culpa/persecutoriedade<br>esteja<br>relacionada<br>a<br>algum<br>atributo<br>especial exagerado do indivíduo. O<br>paciente deve<br>declarar atributos exagerados; se<br>negar talentos, poderes, etc., mesmo<br>que afirme que outros digam que ele<br>possui tais|
||qualidades, este item não deve ser|
||pontuado. Pontuar a partir de<br> <br> <br> <br>|
||informação<br>relatada,<br>ou<br>seja,|
||subjetiva|
|Pergunta-guia|.<br>Nos últimos dias você tem se|
||sentido com algum talento ou<br>habilidade que a maioria das<br>|
||pessoas não tem? (Como você sabe|
||disso?) Você acha que as pessoas<br>|
||têm tido|
||inveja<br>de<br>você?<br>Você<br>tem<br>acreditado que tenha alguma coisa<br>importantepara fazer no mundo?|
|0|Não relatado.<br>|
|1|Muito leve: É mais confiante do que|
|<br>2|<br>a maioria, mas isso é apenas de|
|3|ossível|
|<br>4|p<br>significância clínica.|
||<br>Leve: Autoestima definitivamente<br>aumentada ou talentos exagerados<br>de modo levemente desproporcional<br>às|
|5|circunstâncias|
|<br>6|.<br>Moderado: Autoestima aumentada|
||de<br>modo<br>claramente|
||<br> <br> <br>desproporcional às circunstâncias,|
||<br>ou<br>suspeita-se<br>de<br>delírio<br>de|
||grandeza.|
||<br>Moderadamente grave: Um único (e|
||<br>claramente definido) delírio de|
||grandeza encasulado ou múltiplos<br>delírios degrandeza|  
|||fragmentários<br>(claramente<br>definidos)|
|---|---|---|
|||.<br>Grave: Um único e claro delírio /<br>sistema delirante ou<br>múltiplos e claros delírios de<br>grandeza com os quais o paciente<br>parece preocupado.<br>Muito grave: Como acima, mas a<br>quase totalidade da conversa é<br>dirigida aos delírios de grandeza do<br>paciente.|
|||HUMOR DEPRESSIVO: Relato<br>subjetivo<br>de<br>sentimento<br>de<br>|
|||depressão, tristeza, “estar na fossa”,|
|||etc. Pontuar apenas o grau de|
||RELATO<br>|depressão relatada. Não pontuar<br>|
|9|DO<br>PACIENTE|inferências de<br>depressão<br>feitas<br>a<br>partir<br>de<br>lentificação<br>geral<br>e<br>queixas<br>somáticas. Pontuar a partir de|
|||informação<br>relatada,<br>ou<br>seja,|
|||<br> <br>subjetiva.|
|P|ergunta-guia|Como tem estado seu humor<br>(alegre, triste, irritável)? Você<br>acredita que pode melhorar? (Como<br>esse sentimento tem afetado seu dia<br>a dia?)|
||0|Não relatado|
||<br>1<br>2|.<br>Muito leve: Ocasionalmente se sente<br>levemente deprimido.|
||3|Leve: Ocasionalmente se sente|
||4<br>5<br>6|moderadamente<br>deprimido<br>ou<br>frequentemente se sente levemente<br>deprimido.<br>Moderado: Ocasionalmente se sente<br>muito deprimido ou frequentemente<br>se sente moderadamente deprimido.<br>Moderadamente<br>grave:<br>Frequentemente se sente muito<br>deprimido.<br>Grave: Sente-se muito deprimido a<br>maior parte do tempo.<br>Muito<br>grave:<br>Sente-se<br>muito<br>|
|||deprimidoquase todo o tempo.|
|||HOSTILIDADE:<br>Animosidade,<br>desprezo, agressividade, desdém por<br>outras pessoas fora da situação da|
||RELATO|entrevista Pontuar somente a partir|
|10|<br>DO|.<br>de relato verbal de sentimentos e|
||PACIENTE|atos do paciente em relação aos|
|||outros. Não inferir hostilidade a|
|||partir<br>de<br>defesas<br>neuróticas,|
|||ansiedade ouqueixas somáticas|
|P|ergunta-guia|.<br>Nos últimos dias você tem estado<br>impaciente ou irritável com as<br>outras pessoas? (Conseguiu manter|
|||<br>o<br>controle?<br>Tolerou<br>as<br>provocações? Chegou a agredir<br>|
|||alguém ouquebrar objetos?)|
||0|Não relatado.|
||1|Muito leve: Ocasionalmente sente|
||<br>2|<br>umpouco de raiva.|  
||3<br>4<br>5<br>6|Leve: Frequentemente sente um<br>pouco de raiva ou ocasionalmente<br>sente raiva moderada.<br>Moderado: Ocasionalmente sente<br>muita raiva ou frequentemente sente<br>raiva moderada.<br>Moderadamente<br>grave:<br>Frequentemente sente muita raiva.<br>Grave:<br>Expressou<br>sua<br>raiva<br>tornando-se verbal ou fisicamente<br>agressivo em uma ou duas ocasiões.|
|---|---|---|
|||Muito grave: Expressou sua raiva<br>|
|||em várias ocasiões.|
|||DESCONFIANÇA:<br>Crença|
|||(delirante ou não) de que outros têm<br>agora ou tiveram no passado<br> <br> <br>|
|||intenções<br>discriminatórias<br>ou|
||RELATO|maldosas em relação ao paciente.<br>|
|11|DO|Pontuar apenas se o<br> <br> <br>|
||PACIENTE|paciente<br>relatar<br>verbalmente<br>desconfianças atuais, quer elas se<br>|
|||refiram a circunstâncias presentes ou|
|||<br>passadas. Pontuar a  partir da|
|||informação<br>relatada,<br>ou<br>seja,<br>|
|||subjetiva.|
|P|ergunta-guia|Você tem tido a impressão de que<br>as outras pessoas estão falando ou<br>|
|||rindo de você? (De que forma você<br>b i?   hd|
|||percee sso) Você tem acao|
|||que tem alguém com más<br>|
|||intenções contra você ou se|
|||esforçado<br>para<br>lhe<br>causar|
|||problemas? (Quem? Por quê?<br>|
|||Como você sabe disso?)|
||0|Não relatado.|
||1|Muito leve: Raras circunstâncias de|
||<br>2<br>3|<br>desconfiança que podem ou não<br>corresponder à realidade.|
||4|Leve: Situações de desconfiança<br>ocasionais que definitivamente não|
|||correspondem à realidade.|
||5|Moderado:<br>Desconfiança<br>mais|
||<br>6|<br> <br> <br>frequente ou ideias de referência<br>ir|
|||passageas.<br>Moderadamente<br>grave:|
|||<br>Desconfiança disseminada ou ideias<br>de referência<br>frequentes.|
|||<br>Grave:<br>Claros<br>delírios<br>de|
|||perseguição ou referência não<br>totalmente<br>disseminados<br>(por<br>exemplo, um delírio encapsulado).<br>Muito grave: Como acima, porém|
|||mais<br>abrangente,<br>frequente<br>ou|
|||<br> <br>intenso.|
|||COMPORTAMENTO|
||RELATO|<br>ALUCINATÓRIO|
|12|DO<br>PACIENTE|(ALUCINAÇÕES): Percepções (em<br>qualquer modalidade dos sentidos)<br>na|  
|||ausência de um estímulo externo<br>identificável. Pontuar apenas as<br>experiências que ocorreram<br>na última semana. NÃO pontuar<br>“vozes na minha cabeça” ou “visões<br>em minha mente” a menos que o<br>paciente saiba diferenciar entre essas<br>experiências e seuspensamentos.|
|---|---|---|
|P|ergunta-guia|Você<br>tem<br>tido<br>experiências<br>|
|||incomuns que a maioria das|
|||pessoas não tem? Você tem|
|||escutado coisas que as outras<br>pessoas não|
|||podem<br>ouvir?<br>(Você<br>estava<br>acordado nesse momento? O que<br>você ouvia - barulhos, cochichos,<br>vozes conversando com você ou<br>conversando entre si? Com que<br>frequência? Interferem no seu dia a<br>dia?) Você tem visto coisas que a<br>maioria das pessoas não pode ver?<br>(Você<br>estava<br>acordado<br>nesse<br>momento? O que você via -<br>luzes, formas, imagens? Com que<br>frequência? Interferem no seu dia a<br>dia?)|
||0|Não relatado.|
||1<br>2|Muito leve: Apenas se suspeita de<br>alucinação.|
||3|Leve: Alucinações definidas, porém<br>insignificantes,<br>infrequentes<br>ou<br>transitórias.|
|||Moderado: Como acima, porém<br> <br>|
||4|mais<br>frequentes (por exemplo,|
||5|<br>frequentemente vê a cara do diabo;|
||6|duas vozes travam uma longa<br>conversa).|
|||Moderadamente grave: Alucinações<br>são vividas quase todo o dia ou são<br>fontes de incômodo extremo.|
|||Grave: Como acima e exercem<br> <br>|
|||impacto<br>moderado<br>no|
|||<br>comportamento do paciente (por|
|||exemplo,<br>dificuldades<br>de|
|||concentração que levam a um<br>comprometimento no trabalho).|
|||Muito grave: Como acima com|
|||,<br>grave<br>impacto<br>(por<br>exemplo,<br>tentativas de suicídio como resposta<br>a ordens alucinatórias).|
||OBSERVA|RETARDAMENTO<br>MOTOR:|
||ÇÃO<br>DO|Redução do nível de energia<br>evidenciada por movimentos mais|
|13|PACIENTE|<br>lentos. Pontuar apenas a partir de<br>comportamento observado no|
|||<br>paciente. NÃO pontuar a partir de<br>impressões subjetivas do paciente<br>sobre seupróprio nível de energia.|
||0|Não observado.|
||1<br>2|Muito leve: Significação clínica<br>duvidosa.|  
||3<br>|Leve: Conversa um pouco mais<br>|
|---|---|---|
||4|lentamente,<br>movimentos levemente mais lentos.<br>Moderado: Conversa notavelmente<br>mais lenta, mas não<br>arrastada.|
||5<br>6|Moderadamente grave: Conversa<br>arrastada,<br>movimenta-se<br>muito<br>lentamente.<br>Grave: É difícil manter a conversa,<br>quase não se movimenta.|
|||Muito<br>grave:<br>Conversa<br>quase|
|||impossível, não se move durante<br>|
|||toda a entrevista.|
|||FALTA DE COOPERAÇÃO COM<br>A ENTREVISTA: Evidência de<br>resistência,<br>indelicadeza,<br>ressentimento e falta de|
||OBSERVA<br>ÃO|prontidão para cooperar com os<br>entrevistados.<br>Pontuar|
|14|Ç<br>DO<br>PACIENTE|exclusivamente a partir das atitudes<br>do paciente e das<br>reações ao entrevistador e à situação<br>de entrevista.  NÃO pontuar a partir<br>de relato de ressentimento e recusa à<br>cooperação fora de situação de<br>entrevista.|
||0<br>1<br>|Não observado.<br>Muito leve: Não parece motivado.<br>|
||2|Leve: Parece evasivo em certos|
||3|assuntos.<br>Moderado: Monossilábico, fracassa<br>em cooperar|
||4<br>5|espontaneamente.<br>Moderadamente grave: Expressa<br>ressentimento e é indelicado durante|
||6|a entrevista.|
|||<br>Grave: Recusa-se a responder a<br>algumas questões.<br>Muito grave: Recusa-se a responder<br>à maiorparte dasquestões.|
|||ALTERAÇÃO DE CONTEÚDO<br>DO PENSAMENTO (DELÍRIOS):|
|||<br>Gravidade de qualquer tipo de<br>delírio. Considerar|
||RELATO<br>|<br>convicção<br>e<br>seu<br>efeito<br>em|
|15|DO|<br>õP iã ttl|
||PACIENTE|açes.ressupor convcço oa se o|
|||paciente agiu baseado em suas|
|||<br>crenças.<br>Pontuar<br>a<br>partir<br>de|
|||informação<br>relatada,<br>ou<br>seja,<br>|
|||subjetiva.|
|P|ergunta-guia|Você tem acreditado que alguém ou<br>alguma coisa fora de você esteja<br>controlando seus pensamentos ou<br>suas ações contra a sua<br>vontade? Você tem a impressão de<br>que o rádio ou a televisão mandam<br>mensagens para você? Você<br>sente que alguma coisa incomum<br>|
|||esteja acontecendo ou está para<br>acontecer?|  
||0<br>1|Não relatado.<br>Muito leve: Suseita-se ou há|
|---|---|---|
||<br>2|p<br>probabilidade de delírio.|
||3|<br>Leve: Às vezes o paciente questiona<br>suas crenças (delírios parciais).<br> <br> <br>|
|||Moderado:<br>Plena<br>convicção<br>|
||4<br>5<br>|delirante, porém delírios têm pouca<br>ou nenhuma influência sobre o<br>|
||6|comportamento.|
|||Moderadamente<br>grave:<br>Plena<br> <br> <br>|
|||convicção<br>delirante,<br>porém<br>os|
|||<br> <br> <br>delírios<br>têm<br>impacto<br>apenas<br>ocasional sobre o comportamento.|
|||<br>Grave:<br>Delírios<br>têm<br>efeito|
|||significativo<br>(por<br>exemplo,<br>negligencia responsabilidades por<br>causa de preocupações com a crença<br>de que é Deus).|
|||<br>Muito grave: Delírios têm impacto<br>marcante (por exemplo, para de<br>comer porque acredita que a comida<br>está envenenada).|
|||AFETO<br>EMBOTADO:<br>Responsividade afetiva diminuída,|
|||caracterizada<br>por<br>_deficits_<br>na<br>expressão facial, gestualidade e tom<br>de|
||OBSERVA|voz.<br>Diferenciar<br>de|
||ÇÃO|<br> <br> <br>RETRAIMENTO<br>AFETIVO no|
|16|<br>DO|qual<br>o<br>foco<br>está<br>no|
||PACIENTE|comprometimento interpessoal mais<br>do|
|||que no afetivo. Considerar grau e<br>consistência no comprometimento.|
|||Pontuar a partir de observações<br>|
|||feitas durante a entrevista.|
||0|Não observado.|
||1|Muito leve: Ocasionalmente parece|
||2|<br>indiferente a assuntos que são|
||3|normalmente acompanhados por<br>|
|||demonstração de emoção.|
||4|<br>Leve: Expressão facial levemente|
||5<br>|diminuída<br>ou<br>voz<br>levemente<br> <br>|
||6|monótona<br>ou<br>gestualidade|
|||levemente limitada.<br>|
|||Moderado: Como acima, porém de|
|||<br>forma mais intensa, prolongada ou|
|||frequente.|
|||<br>Moderadamente<br>grave:|
|||Achatamento de afeto, incluindo<br> <br> <br>|
|||pelo<br>menos<br>duas<br>ou<br>três|
|||<br>características (falta acentuada de|
|||expressão facial, voz monótona ou|
|||<br>gestualidade limitada).|
|||Grave: Profundo achatamento de|
|||<br>afeto.|
|||Muito<br>grave:<br>Voz<br>totalmente|
|||monótona<br>e<br>total<br>falta<br>de|
|||gestualidade expressiva durante toda|
|||a avaliação.|
||<sup>OBSERVA</sup>|<br>EXCITAÇÃO:<br>Tom<br>emocional|
|17|ÇÃO|<br>aumentado, incluindo irritabilidade|  
||DO<br>|e<br>expansividade<br>(afeto<br>|
|---|---|---|
||PACIENTE|hipomaníaco). Não inferir afeto de|
|||afirmações a partir de delírios de<br>grandeza. Pontuar a partir de<br> <br> <br>|
|||observações<br>feitas<br>durante<br>a<br>|
|||entrevista.|
||0|Não observado.|
||1<br>|Muito leve: Significação clínica<br>|
||2|duvidosa.<br>|
|||Leve:<br>Às<br>vezes<br>irritadiço<br>ou<br>expansivo.|
||3<br>4|<br>Moderado:<br>Frequentemente<br>irritadiço ou expansivo.<br>Moderadamente<br>grave:|
||5|Constantemente<br>irritadiço<br>ou|
||6|expansivo, às vezes enfurecido ou<br>eufórico.|
|||Grave: Enfurecido ou eufórico<br>durante maior parte da<br>entrevista.<br>Muito grave: Como acima, porém de<br>tal modo que a entrevista precisa ser<br>interrompidaprematuramente.|
|18|OBSERVA<br>ÇÃO<br>DO<br>PACIENTE|DESORIENTAÇÃO: Confusão ou<br>falta de orientação adequada em<br>relação a pessoas, lugares e tempo.<br>Pontuar a partir de observações<br>feitas durante a entrevista.|
|||Qual seu nome completo? E sua<br>idade? Onde você mora? Está<br>trabalhando<br>atualmente?<br>(Já|
|||trabalhou anteriormente? Em quê?)<br>Quanto tempo faz que você está<br>aqui? Conte-me por que<br>motivo você foi internado. Quando<br>isso começou? O que aconteceu|
||Pergunta-<br>guia|depois? Você pode me dizer que dia<br>é hoje (semana-mês-<br>ano)?<br>Você tem conseguido se concentrar?<br>Como está sua<br>memória? (Caso necessário, faça<br>exame específico.)<br>Reentrevista: Você pode me dizer<br>que dia é hoje (semana-mês-ano)?<br>Você pode me dizer o que tinha<br>ontem nojantar?|
||0|Não observado.|
||1|Muito leve: Parece um pouco|
||2|<br>confuso.|
||3|Leve: Indica 2003 quando é na<br>verdade 2004.<br>Moderado: Indica 1992.|
||4<br>5|Moderadamente grave: Não sabe ao<br>certo onde está|
||<br>6|.<br>Grave: Não faz ideia de onde está.<br>Muitograve: Não sabequem é.|  
Escala Breve de Avaliação Psiquiátrica – BPRS Folha de Respostas  
<mark>Paciente Idade Sexo</mark> Escores: 0 (Não relatado), 1 (Muito leve), 2 (Leve), 3 (Moderado), 4 (Moderadamente grave), 5 (Grave), 6 <u>(Muito grave)</u>  
|Data<br>E<br>1. Preocu<br>pação<br>somática|score<br>Escore<br>Escor<br>Escor<br>Escore<br>Escore<br>Escor<br>Escor<br>Escore<br>Escore<br>Escor<br>Escore<br>Escore<br>Escore|
|---|---|
|2.<br>Ansiedade||
|3.Retrai<br>mento<br>afetivo||
|4. Desor<br>ganização<br>conceitual||
|5.Senti<br>mentos de<br>culpa||
|6. Tensão||
|7. Manei<br>rismos e<br>postura||
|8. Ideias de<br>grande za||
|9. Humor<br>depressivo||
|10. Hostili<br>dade||
|11. Descon<br>fiança||
|12. Com<br>portamento<br>alucina<br>tório(alucin<br>ações)||
|13. Retar<br>damento<br>psicomotor<br>/ motor||
|14. Falta de<br>coope<br>ração com<br>a entrevista||
|15. Altera<br>ção de con<br>teúdo do<br>pensamen<br>to(delírios)||
|16. Afeto<br>embotado||
|17. Excita<br>ção||
|18. Deso<br>rientação||
|Escore<br>Total||

---

