<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE -->
PORTARIA CONJUNTA SAES/SCTIE Nº 25, 17 DE NOVEMBRO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Adenocarcinoma de Cólon e Reto.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE,** no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 04 de junho de 2025, resolvem:  
Considerando a necessidade de se atualizarem os parâmetros sobre o Adenocarcinoma de Cólon e Reto no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 941/2024 e o Relatório de Recomendação n° 944/2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Adenocarcinoma de Cólon e Reto.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do Adenocarcinoma de Cólon e Reto, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Adenocarcinoma de Cólon e Reto.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS nº 958, de 26 de setembro de 2014, publicada no Diário Oficial da União (DOU) nº 187, em 29 de setembro de 2014, seção 1, página 59  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: FERNANDA DE NEGRI -->
1  
**ANEXO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DO ADENOCARCINOMA DE CÓLON E RETO**

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **1. INTRODUÇÃO** -->
O adenocarcinoma de cólon e reto, também conhecido como câncer de cólon e reto, abrange os tumores malignos do intestino grosso. Homens e mulheres são igualmente afetados pela doença, que é tratável e frequentemente curável quando diagnosticada precocemente, isto é, com localização limitada ao intestino, sem extensão para outros órgãos e sítios. Embora a recorrência após o tratamento cirúrgico seja um evento clínico relevante, sendo a causa primária de morte pela doença, a instituição precoce de tratamento eficaz pode resultar na cura1.  
No câncer de cólon e reto, o tipo histológico mais comum é o adenocarcinoma, correspondendo a cerca de 95% dos casos. Ainda, a caracterização molecular e análises transcriptômicas permitem a classificação em quatro subtipos moleculares, entre eles, carcinoma mucinoso e adenoescamoso2. Cerca de 75% dos casos de câncer de cólon e reto origina-se a partir de pólipos adenomatosos, pela "via adenoma-carcinoma”, com tempo de evolução que pode levar mais de 20 anos. Aproximadamente 15% dos casos são oriundos de pólipos serrilhados, pela chamada “via serrilhada”. Embora a maioria dos pólipos adenomatosos ou serrilhados não evolua para câncer, ambos estão associados a um risco aumentado de câncer de cólon ou reto, principalmente os pólipos avançados, ou seja, com 10 ou mais milímetros de diâmetro, com componente viloso ou displasia de alto grau3.  
O número estimado de casos novos de câncer de cólon e reto para o Brasil, para cada ano do triênio de 2023 a 2025, é de 45.630 casos, correspondendo a um risco estimado de 21,10 casos por 100 mil habitantes, sendo 21.970 casos entre os homens e 23.660 casos entre as mulheres. Esses valores correspondem a um risco estimado de 20,78 casos novos a cada 100 mil homens e de 21,41 a cada 100 mil mulheres4,5, sendo que o sexo masculino apresenta taxas médias de sobrevida mais baixas do que o sexo feminino2.  
O câncer de cólon e reto é o segundo mais incidente entre os homens (28,62 casos por 100 mil) no Brasil. Na Região Sudeste é o segundo câncer mais incidente entre os homens (28,62 casos por 100 mil), assim como no Centro-oeste (17,25 por 100 mil). Na Região Sul (26,89 por 100 mil), é o terceiro tumor mais frequente, ocupando a quarta posição nas Regiões Nordeste (10,99 por 100 mil) e Norte (7,05 por 100 mil). Entre as mulheres, é o segundo mais frequente nas Regiões Sudeste (28,88 por 100 mil), Sul (26,04 por 100 mil) e Centro-oeste (16,92 por 100 mil)4,5. Cabe ressaltar que todas essas análises de incidência estão desconsiderando os cânceres de pele não melanoma. O Brasil demonstra crescimento tanto de incidência quanto de mortalidade do câncer de cólon e reto nos últimos 10 anos6.  
A maioria dos casos de câncer de cólon e reto é esporádica, ou seja, ocorre em pessoas que não apresentam história familiar e que pode não ter relação com fatores de risco. Contudo, alguns grupos possuem maior risco de desenvolvimento desta neoplasia: indivíduos com predisposição hereditária para câncer de cólon e reto, incluindo síndromes de câncer familial, como polipose adenomatosa familiar e síndrome de Lynch; portadores de doenças inflamatórias do intestino (doença de Crohn ou retocolite ulcerativa) e indivíduos com pólipos intestinais adenomatosos ou serrilhados avançados 3,7.  
Outros fatores de risco importantes para o desenvolvimento do adenocarcinoma de colón e reto na população são: obesidade, sobrepeso e sedentarismo; consumo de bebidas alcoólicas com mais de 30 gramas de etanol ingeridos por dia; tabagismo; dieta com o consumo excessivo de carnes vermelhas e carnes processadas, além de baixa ingestão de frutas, legumes e verduras 3,7. A cada porção de 50 gramas de carne processada consumida diariamente, o risco de câncer de cólon e reto aumenta em 18%1. A recomendação para a prevenção do câncer de cólon e reto é evitar totalmente o consumo de carnes processadas e limitar o consumo de carne vermelha a até 500 gramas de carne cozida por semana 8.  
2  
Para reduzir a incidência do adenocarcinoma de cólon e reto é fundamental promover a conscientização da população sobre a importância da adoção de hábitos saudáveis, por meio de ações de saúde e políticas intersetoriais. Essas medidas visam não apenas promover a saúde, mas também reduzir a exposição aos fatores de risco modificáveis associados a essa doença.  
Outra importante estratégia de controle do adenocarcinoma de cólon e reto é o diagnóstico precoce por meio dos sinais e sintomas suspeitos, uma vez que o encaminhamento ágil e adequado para o atendimento especializado a partir da Atenção Primária, é estratégico para um melhor resultado terapêutico e prognóstico dos casos.  
Este PCDT visa a estabelecer os critérios diagnósticos e terapêuticos do adenocarcinoma de cólon e reto, com o objetivo de orientar, com base em evidências científicas de segurança, efetividade e reprodutibilidade, as condutas e os protocolos assistenciais mais adequados.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **2.         CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CD-10)** -->
C18 Neoplasia maligna do cólon  
C18.0 Neoplasia maligna do ceco - válvula ileocecal C18.1 Neoplasia maligna do apêndice (vermiforme) C18.2 Neoplasia maligna do cólon ascendente  
C18.3 Neoplasia maligna da flexura (ângulo) hepática(o)  
C18.4 Neoplasia maligna do cólon transverso  
C18.5 Neoplasia maligna da flexura (ângulo) esplênica(o)  
C18.6 Neoplasia maligna do cólon descendente  
C18.7 Neoplasia maligna do cólon sigmoide – exclui junção retossigmoide  
C18.8 Neoplasia maligna do cólon com lesão invasiva  
C18.9 Neoplasia maligna do cólon, não especificado  
C19 Neoplasia maligna da junção retossigmoide  
C20 Neoplasia maligna do reto

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **3.1.     Detecção precoce, rastreamento e prevenção secundária** -->
A detecção precoce é dividida em duas grandes estratégias: o diagnóstico precoce e o rastreamento. Diagnóstico precoce refere-se às estratégias para facilitar a investigação diagnóstica e posterior tratamento dos casos confirmados para os indivíduos com sinais e sintomas suspeitos 9.  
Os sinais e sintomas suspeitos de adenocarcinoma de cólon e reto são relativamente inespecíficos e incluem: mudanças de hábito intestinal, perda inexplicável de peso, anemia por deficiência de ferro, fezes escuras ou com sangue visível, massa abdominal e dor abdominal persistente 3.  
O rastreamento para o câncer de cólon e reto refere-se à realização de exames de rotina em indivíduos clinicamente assintomáticos. A estratégia mais utilizada para rastreamento é a detecção de sangue oculto nas fezes, que pode ser o sinal indicativo da presença de um pólipo, permitindo a sua remoção antes da sua transformação ou ainda, representar a detecção de um tumor maligno em uma fase muito inicial. O rastreamento de base populacional se refere a programas organizados de rastreamento, nos quais a população-alvo é convidada para realização de exames de rastreamento na periodicidade e faixa etária indicadas, além de agregar diversos outros aspectos como, por exemplo, controle de qualidade dos exames. A Organização  
3  
Mundial de Saúde recomenda que países que não possuem infraestrutura e recursos humanos suficientes para viabilizar o rastreamento populacional devem priorizar o uso desses recursos para facilitar a investigação diagnóstica de casos sintomáticos suspeitos 3. A avaliação da incorporação de um programa de rastreamento de câncer deve incluir avaliação rigorosa das evidências de efetividade, do balanço entre de riscos e benefícios, eficiência, impacto orçamentário e de diversos aspectos programáticos. A avaliação da incorporação de um programa de rastreamento do câncer colorretal está fora do escopo do presente PCDT e será tratada em documentos técnicos específicos 3.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **3.2.     Diagnóstico** -->
O diagnóstico do adenocarcinoma de cólon e reto é confirmado por meio do estudo anatomopatológico de amostra do tumor primário ou de lesão de metástase relacionada. Essas amostras podem ser obtidas através de biópsias pela via endoscópica (colonoscopia/retossigmoidoscopia) ou por agulha guiada por método de imagem, ou, ainda, análise direta do tumor após ressecção cirúrgica, nos casos sem diagnóstico prévio, submetidos a cirurgia em caráter de urgência.  
Uma vez confirmado o diagnóstico, o próximo passo é o estadiamento clínico, que tem como objetivo mapear a extensão da doença local (na topografia do tumor primário) e à distância (presença de metástase). O estadiamento clínico do câncer colorretal é realizado através de tomografia computadorizada de tórax, abdome e pelve. Estes exames devem ser feitos, sempre que possível, antes da realização de intervenções terapêuticas, seja cirurgia, quimioterapia e/ou radioterapia, pois podem alterar a conduta de tratamento. Em pacientes que não podem realizar infusão de contraste iodado ou cuja tomografia com contraste de abdome apresente achados duvidosos quanto a presenças de lesões metastáticas, recomenda-se a realização complementar de ressonância magnética de abdome superior 10,11. No adenocarcinoma de reto, a ressonância magnética de pelve permite avaliação detalhada quanto ao risco de invasão e comprometimento de fáscia mesorretal, bem como de vasos de diferentes calibres e linfonodos mesorretais, informações que impactam na definição da estratégia terapêutica subsequente.  
A realização de Tomografia por Emissão de Pósitrons associada à Tomografia Computadorizada (PET-TC) para estadiamento ou para seguimento não é recomendada de rotina, visto que não apresenta superioridade em relação aos demais métodos quanto a desfechos que podem proporcionar mudanças de conduta clínica 12–14. Porém, o PET-TC pode ser empregado em casos selecionados quando há metástase exclusivamente hepática e potencialmente ressecável de câncer colorretal 15.  
Pacientes com diagnóstico confirmado de adenocarcinoma de cólon e reto devem realizar exames laboratoriais: hemograma completo, função bioquímica, função renal, enzimas hepáticas e canaliculares, bilirrubinas totais e frações e antígeno carcinoembrionário (CEA). O CEA com valor aumentado (maior que 5 mcg/L) no pré-operatório denota pacientes que tem pior prognóstico, exceto os que, após a cirurgia, tem normalização dos seus valores. O CEA também pode ser utilizado como monitorização de eficácia de quimioterapia nos casos com doença metastática 16,17. Os demais exames têm a função de avaliar o status de saúde e funções orgânicas gerais do paciente.  
Recomenda-se a realização de teste imunohistoquímico da amostra de tecido tumoral para avaliação da proficiência de enzimas de reparo em todos os pacientes com diagnóstico de adenocarcinoma de cólon e reto 18. Caso o perfil do tumor seja instável, recomenda-se avaliação quanto a presença da síndrome de Lynch.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **3.3.     Estadiamento** -->
Compreender o estadiamento patológico juntamente aos valores prognósticos é essencial para a tomada de decisão terapêutica. O estadiamento mais utilizado é o da União Internacional Contra o Câncer (UICC), a Classificação de Tumores Malignos, que utiliza as categorias T (tamanho e extensão do tumor primário) (Quadro 1), N (acometimento linfonodal) (Quadro 2) e M (metástase a distância) (Quadro 3), chamada simplificadamente de classificação TNM (Quadro 4) 19. Também é utilizado o sistema TNM da American Joint Committee for Cancer (AJCC) 20, cuja 8ª edição expandiu a classificação e estadiamento para além dos sítios anatômicos e incluiu outros fatores prognósticos, como o grau histológico e o perfil imunohistoquímico.  
4  
**Quadro 1** - Profundidade de invasão – Tumor primário T.  
|Categoria T|Definição|
|---|---|
|TX|Não é possível avaliar o tumor primário|
|T0|Sem evidência de tumor primário|
|Tis|Carcinoma in situ, carcinoma intramucoso|
|T1|Tumor invade a submucosa|
|T2|Tumor invade a muscular própria|
|T3|Tumor invade através da muscular própria os tecidos pericólicos|
|T4|Tumor invade e/ou perfura o peritônio visceral ou órgãos/estruturas vizinhas|
|T4a|Tumor perfura peritônio visceral|
|T4b|Tumor invade diretamente órgãos/estruturas vizinhas|  
Fonte: Adaptado da União Internacional Contra o Câncer (UICC), 8ª ed.  
**Quadro 2** - Linfonodos regionais – N.  
|Categoria N|Definição|
|---|---|
|NX|Não é possível avaliar os linfonodos regionais|
|N0|Não há metástases linfonodais|
|N1|1 a 3 linfonodos acometidos (tumor em linfonodo > 0,2 mm) ou depósito tumoral descontinuo<br>com linfonodos negativos|
|N1a|1 linfonodo acometido|
|N1b|2 ou 3 linfonodos acometidos|
|N1c|Linfonodos negativos, mas depósitos tumorais presentes na subserosa, mesentério ou tecido<br>pericolico/perirretal/mesorretal não peritonealizados|
|N2|4 ou mais linfonodos acometidos|
|N2a|4-6 linfonodos acometidos|
|N2b|7 ou mais linfonodos acometidos|  
Fonte: Adaptado da União Internacional Contra o Câncer (UICC), 8ª ed.  
**Quadro 3 -** Presença de metástases - M.  
|Categoria M|Definição|
|---|---|
|M0|Sem metástases à distância|
|M1|Metástases em órgãos distantes ou peritônio|
|M1a|Metástases em 1 órgão e sem metástases peritoneais|
|M1b|Metástases em 2 ou mais órgãos e sem metástases peritoneais|
|M1c|Metástase em peritônio, com ou sem outros órgãos acometidos|  
Fonte: Adaptado da União Internacional Contra o Câncer (UICC), 8ª ed.  
**Quadro 4** - Estadiamento com base no sistema TNM.  
|T|N|M|Estadiamento|
|---|---|---|---|
|Tis|N0|M0|0|
|T1, T2|N0|M0|I|  
5  
|T|N|M|Estadiamento|
|---|---|---|---|
|T3, T4|N0|M0|II|
|T3|N0|M0|IIA|
|T4a|N0|M0|IIB|
|T4b|N0|M0|IIC|
|Qualquer T|N1, N2|M0|III|
|T1-T2|N1/N1c|M0|IIIA|
|T1|N2a|M0|IIIA|
|T3-T4a|N1/N1c|M0|IIIB|
|T2-T3|N2a|M0|IIIB|
|T1-T2|N2b|M0|IIIB|
|T4a|N2a|M0|IIIC|
|T3-T4a|N2b|M0|IIIC|
|T4b|N1-N2|M0|IIIC|
|Qualquer T|Qualquer N|M1|IV|
|Qualquer T|Qualquer N|M1a|IVA|
|Qualquer T|Qualquer N|M1b|IVB|
|Qualquer T|Qualquer N|M1c|IVC|  
Fonte: Adaptado da União Internacional Contra o Câncer (UICC), 8ª ed.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **4.        CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos pacientes com qualquer idade e suspeita ou diagnóstico de adenocarcinoma de cólon e reto, que compreende neoplasia maligna do cólon ascendente, descendente, transverso e sigmoide, além de neoplasia maligna do ceco, do apêndice, das flexuras hepática e esplênica, da junção retossigmoide e do reto.  
Nota: Não serão incluídos pacientes com carcinoma epidermoide do reto, GIST, tumor neuroendócrino, linfomas, sarcomas e outras histologias raras e o carcinoma de canal anal.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **5.        CRITÉRIO DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento ou procedimento preconizado neste Protocolo deverão ser excluídos do uso do respectivo medicamento ou procedimento preconizado.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.1.     Tratamento não medicamentoso** -->
O tratamento não medicamentoso do câncer de colón e reto inclui as seguintes abordagens: tratamento cirúrgico, radioterapia e métodos ablativos térmicos.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.1.1.  Tratamento cirúrgico** -->
6  
A cirurgia persiste ocupando o pilar central do tratamento curativo do adenocarcinoma de cólon e reto. Em associação à quimioterapia e radioterapia para o tratamento curativo do adenocarcinoma de câncer de cólon e reto, as vias de acesso minimamente invasivas têm sido associadas à menor morbidade, internação mais curta e menor taxa de conversão para a cirurgia convencional e aberta.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.1.1.1. Adenocarcinoma de cólon** -->
Na cirurgia do adenocarcinoma de cólon é fundamental garantir margens satisfatórias (aproximadamente 5 cm) na ressecção colônica, juntamente com uma linfadenectomia adequada. Esta última envolve a ligadura dos vasos nutridores em suas origens do segmento colônico correspondente, sendo essencial uma amostragem linfonodal mínima de 12 linfonodos.  
Técnicas minimamente invasivas podem ser empregadas sempre que possível, visto que demonstram possibilitar menor tempo de internação, requerem menos uso de analgésicos e menor perda sanguínea quando realizada por via laparoscópica, oferecendo resultados de sobrevida global e sobrevida livre de doença semelhantes ao da cirurgia convencional 21–23. Pacientes com adenocarcinoma de cólon estádios 0 ou I ressecados pela via endoscópica, cujo anatomopatológico após a ressecção apresente todos os critérios favoráveis, tais como: invasão de até 1.000 micra da submucosa; ausência de invasão angiolinfática; histologia bem diferenciada; ausência de tumor budding; margens livres, são considerados curados.  
Tumores com invasão de órgãos adjacentes (T4b) requerem ressecção em bloco da estrutura acometida por contiguidade a fim de garantir margens livres de ressecção 24. A presença de doença metastática não é uma contraindicação para realização de cirurgia radical com intenção curativa. A indicação de cirurgia nesse cenário dependerá da extensão e do sítio da metástase, além da ressecabilidade da doença metastática 25. Na presença de doença metastática irressecável, a ressecção do tumor primário de forma paliativa pode ser indicada para controle de sintomas (sangramento, obstrução ou perfuração).  
Paciente com doença peritoneal pode se beneficiar com a citorredução cirúrgica em casos com índice de carcinomatose baixo (ICP <10) ou possibilidade de ressecções R0.  
O objetivo da citorredução é remover o máximo possível de lesões tumorais, visto que quanto menor o volume tumoral residual após a cirurgia, melhores são os resultados. Para acessar a distribuição da doença na superfície peritoneal, a cavidade abdominal é dividida em 13 regiões, onde cada região recebe uma pontuação de 0-3 (índice de tamanho tumoral), a depender do volume de implantes tumorais encontrados em cada uma delas e, ao final, obtêm-se o Índice de Câncer Peritoneal (ICP). As regiões no abdome são divididas em: central, hipocôndrio direito, epigástrio, hipocôndrio esquerdo, flanco esquerdo, fossa ilíaca esquerda, pelve, fossa ilíaca direita, flanco direito, jejuno proximal, jejuno distal, íleo proximal, íleo distal. O índice de tamanho tumoral é classificado como LS (do inglês lesion size score) 0, quando não há lesão, LS 1, quando existe nódulos até 0,5 cm, LS 2 quando existe nódulos entre 0,5 e 5,0 cm e LS 3 na presença de nódulos maiores que 5,0 cm ou confluentes. Desta forma o índice de carcinomatose pode variar de 0-39 e é utilizado, principalmente, para quantificar o volume de doença peritoneal e estimar a possibilidade de citorredução nos pacientes com neoplasias disseminadas no peritônio 26.  
Após a análise dos resultados do estudo PRODIGE 7 27, que avaliou o benefício da HIPEC (Hipertermia Intraperitoneal Pós-Citorredutora) associada à citorredução cirúrgica no câncer colorretal com metástases peritoneais, sem evidência de benefícios em termos de sobrevida global, recomenda-se que a cirurgia citorredutora isolada seja considerada a principal estratégia terapêutica para metástases peritoneais. Dessa forma, a HIPEC não é preconizada por este Protocolo, devido às evidências disponíveis e não avaliação pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde para essa indicação específica.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.1.1.2. Adenocarcinoma de reto** -->
De forma simplificada, o reto é a parte final do intestino grosso localizada acima da linha pectínea e se estende por aproximadamente 15 cm até o ponto onde termina a tênia, integrando a musculatura longitudinal dessa região. Na prática clínica,  
7  
o reto é frequentemente dividido em três segmentos para facilitar a análise: o segmento inferior ou distal (até 5 cm da margem anal), o segmento médio (de 5 a 10 cm da margem anal) e o segmento superior ou proximal (de 10 a 15 cm da margem anal). Os tumores retais também são classificados com base em sua localização em relação à dobra peritoneal, podendo ser intraperitoneais, se localizados no reto alto, ou extraperitoneais, se encontrados no reto médio e baixo. A mensuração exata da distância entre a extremidade inferior do tumor e a margem anal é crucial, especialmente em tumores do reto inferior, pois impacta diretamente na decisão de realizar a amputação retal e a colostomia definitiva 28.  
A técnica cirúrgica preconizada no adenocarcinoma de reto é a excisão total do mesorreto (TME), que tem como fundamento a dissecção fina seguindo o plano embriológico avascular entre a fáscia mesorretal e a fáscia endopélvica, ressecando todo o estojo mesorretal de forma íntegra e sem violação do compartimento mesorretal. A TME se constitui como base fundamental do tratamento cirúrgico do câncer de reto extraperitoneal (localizado abaixo da reflexão peritoneal) 29. Para os tumores do reto intraperitoneal, recomenda-se que a excisão mesorretal seja parcial, ou seja, uma ressecção do mesorreto englobando 5 cm distais ao tumor, pois não há necessidade de ressecção de todo estojo mesorretal até o nível do diafragma pélvico, como é feito na TME.  
A disseminação da TME como técnica padrão-ouro no tratamento de câncer de reto extraperitoneal confirmou a importância da ressecção adequada do estojo mesorretal sem violação da fáscia mesorretal. A qualidade da TME produzida pelo cirurgião e o comprometimento da margem radial são fatores prognósticos decisivos relacionados à recidiva local. A violação do estojo mesorretal durante a cirurgia propicia chance significativamente maior de recidiva local 30. A avaliação da qualidade da ressecção do espécime cirúrgico (protocolo de Quirke 31) pelo patologista serve como auditoria da qualidade da técnica cirúrgica empregada e que tem correlação direta com recidiva local 32.  
Em relação à linfadenectomia a ser empregada, a TME realizada de forma adequada engloba todos os linfonodos mesorretais sob risco de metástase, sendo uma base fundamental do tratamento cirúrgico. A linfadenectomia da artéria mesentérica inferior e suas ramificações (artérias retais) é parte importante da técnica cirúrgica no câncer de reto pois engloba os linfonodos craniais que seguem os vasos retais e artéria mesentérica inferior, devendo ser realizada de forma rotineira. Quanto à linfadenectomia lateral, não há um consenso na literatura sobre utilizá-la ou não como parte da rotina cirúrgica 25.  
A preservação nervosa representa um passo fundamental no tratamento cirúrgico de câncer de reto, pois as sequelas produzidas pela lesão do plexo autonômico pélvico são responsáveis por sequelas na esfera urinária e sexual. Desta forma, o esforço em preservar a anatomia nervosa pélvica durante a cirurgia do reto é fundamental para reduzir sequelas relacionadas ao procedimento 25.  
A excisão local é indicada como tratamento de câncer de reto apenas em situações em que o paciente não tenha condição clínica para ser submetido ao tratamento radical (TME), pois foram observadas taxa de recidiva em torno de 18% e 37% para tumores T1 e T2 tratados com excisão local isoladamente 25.  
A cirurgia minimamente invasiva no câncer de reto permite uma recuperação pós-operatória mais rápida (menor tempo de internação, retorno mais precoce à dieta, menor uso de analgésicos e menos complicações relacionadas à parede abdominal), além de resultados oncológicos semelhantes quando comparada à cirurgia convencional 33,34.  
Pacientes com câncer de reto inferior, que demonstraram resposta completa ao tratamento neoadjuvante, podem ser selecionados para não realização da cirurgia, com o objetivo de preservação de órgãos e redução de complicações. Este procedimento só poderá ser adotado em casos em que o paciente tem garantia de acesso a protocolos de controle rígidos, com a realização de exames de acompanhamento frequentes.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.1.1.3. Cuidados nutricionais perioperatórios** -->
A avaliação nutricional adequada é fundamental no tratamento cirúrgico do adenocarcinoma de cólon e reto, visto que uma parcela significativa dos pacientes possui risco nutricional.  
8  
O íleo metabólico pós-operatório ocorre em cerca de 30% dos pacientes, postergando o início da dieta e aumentando a estadia hospitalar e os custos. Para minimizar a sua ocorrência, é importante reduzir o volume de hidratação venosa ofertado aos pacientes no intra e pós-operatório. Esta redução de fluidos também está associada à diminuição do uso de analgésicos opioides, os quais também potencializam o íleo metabólico e são fatores de risco para imunodeficiência.  
Ainda como parte destes cuidados, a abreviação de jejum pré e pós-operatório é um procedimento seguro, que modula a resposta inflamatória por diminuir a resistência insulínica, é mais confortável para o paciente e possui poucas contraindicações.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.1.2.  Radioterapia** -->
Para pacientes com adenocarcinoma de cólon, a radioterapia não é recomendada rotineiramente no tratamento adjuvante. Evidências limitadas sugerem que pacientes selecionados poderiam ser beneficiados pela irradiação do leito tumoral em situações clínicas específicas (lesão T4, presença de perfuração ou obstrução intestinal e doença residual pós-operatória) 35.  
Para pacientes com adenocarcinoma de reto em estágio inicial (T1-T2, N0, M0), a radioterapia neoadjuvante não é recomendada, bem como, para tumores de reto alto. Para câncer de reto T3-T4 e/ou N1-3 localmente avançado, localizado no reto baixo ou médio, independentemente do local e do estágio, o tratamento curativo consiste em radioterapia neoadjuvante, seguida de cirurgia 36.  
A radioterapia ou quimiorradioterapia neoadjuvante do câncer de reto é preferível à radioterapia adjuvante devido à melhor adesão, menor toxicidade e maior eficácia em termos de controle local 36,37.  
Quanto à indicação da radioterapia adjuvante para pacientes com adenocarcinoma de reto no estádio I (pT1, pT2, pN0, pM0), esta deve considerar a extensão da neoplasia e o grau de diferenciação histológica do tumor:  
- Tumor com margem comprometida 38;  
- Invasão linfovascular;  
- Grau III;  
- Invasão da submucosa até a o 1/3 inferior.  
Além disso, a radioterapia adjuvante deve ser considerada em casos com alto risco de recorrência local, estád     io patológico II e III, se a radioterapia pré-operatória não tiver sido administrada, também para tumores com margem circunferencial inferior a 1 mm e nos casos onde a avaliação linfonodal foi inadequada ou não realizada (pNx).  
O mais comumente utilizado para a terapia neoadjuvante é a quimiorradioterapia de “curso longo” usando doses convencionais de 1,8 a 2 Gy por fração durante 5 a 6 semanas para uma dose total de 45 a 50,4 Gy concomitante ao uso de 5- fluoruracila (5FU) em infusão contínua ou capecitabina oral 36,39–41. Em pacientes idosos ou que não toleram a cirurgia, podese usar a radioterapia definitiva, com doses maiores, como 54 Gy. O curso longo deve ser preferencial quando os tumores forem de reto baixo e há a intenção de redução tumoral para evitar colostomia definitiva.  
Para pacientes com câncer de reto recebendo radioterapia neoadjuvante de curta duração, recomenda-se a aplicação de 25 Gy em 5 frações de 5 Gy ao longo de uma semana com ou sem quimioterapia concomitante 36,40. A data da radioterapia e a de reavaliação cirúrgica devem estar sempre alinhadas para a melhor resposta ao tratamento.  
A adição de quimioterapia concomitante à radiação fornece radiossensibilização, aumenta a taxa de reposta patológica completa (RPc), mas também pode aumentar a toxicidade, a depender do esquema quimioterápico utilizado 39.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.1.3.  Métodos ablativos térmicos** -->
Os métodos ablativos térmicos utilizam calor ou frio para destruir as células cancerígenas provenientes de metástases de câncer de cólon e reto no fígado.  
A ablação por radiofrequência e por micro-ondas envolve a colocação de um ou mais eletrodos no tumor 42 usando orientação de imagem, como ultrassonografia (com ou sem contraste) ou tomografia computadorizada (com ou sem contraste).  
9  
Uma corrente alternada de alta frequência é aplicada, causando a necrose de coagulação e, consequentemente, a destruição do tecido ao redor dos eletrodos.  
A seleção do paciente que realizará o procedimento deve ser realizada por uma equipe multidisciplinar, sendo utilizada uma abordagem percutânea ou intraoperatória, com o paciente sob sedação venosa e anestesia geral 43.  
Para metástases hepáticas colorretais ressecáveis, a ablação por radiofrequência pode ser utilizada conjuntamente à ressecção cirúrgica, sendo aplicada em lesões de difícil ressecção ou que comprometeriam a remoção de uma grande área de parênquima hepático 44.  
A ablação por micro-ondas é um método ablativo que utiliza ondas eletromagnéticas que criam altas temperaturas para destruir rapidamente os tumores de até 3 cm de diâmetro. A ablação por micro-ondas é uma tecnologia mais recente que a radiofrequência no tratamento de tumores hepáticos. Ela tem a vantagem de causar ablações maiores, mais homogêneas, mais esféricas e mais previsíveis que a radiofrequência. Além disso, é uma tecnologia mais rápida e menos susceptível à perda de eficácia quando aplicada perto de grandes vasos sanguíneos. Para pacientes com metástases irressecáveis, a evidência sugerindo eficácia e segurança de ablação por micro-ondas permanece escassa 45, no entanto, esta modalidade de ablação tem se mostrado uma opção para uso conjunto à ressecção hepática 46,47.  
A evidência mostra que a eficácia dos métodos ablativos para o tratamento de tumores hepáticos aumentou de forma expressiva. A sobrevida livre de progressão local melhorou significativamente, passando de 38%, em 2013, para 69% em 2017 e, em 2021, chegando a 86%. O aumento desta eficácia tem sido atribuído à seleção adequada dos pacientes, controle adequado da área de ablação, além da incorporação de novas tecnologias, com substituição progressiva da radiofrequência pelas microondas 48.  
Após avaliação pela Conitec, a ablação térmica para o tratamento de metástase hepática irressecável ou ressecável com alto risco cirúrgico do câncer de cólon e reto foi incorporada ao SUS, conforme Portaria SECTICS/MS nº 06/2024.  
Ressalta-se que, conforme as evidências clínicas atualmente disponíveis para a ablação por radiofrequência, são elegíveis a realizar o procedimento de ablação térmica os pacientes entre 18 e 80 anos com câncer de cólon ou reto, status de desempenho da Organização Mundial da Saúde menor ou igual a 1 e medula óssea, função hepática e renal adequadas e:  
- metástase hepática não ressecáveis (nenhuma possibilidade de ressecção completa de todas as lesões tumorais) sem doença extra-hepática detectável, conforme avaliação em tomografia computadorizada abdomino-pélvica ou ressonância magnética e tomografia computadorizada de tórax, com até 10 metástases hepáticas, com diâmetro máximo de 4 cm e em que o envolvimento metastático do fígado era de até 50% e o tratamento completo de todas as lesões hepáticas era considerado possível49; ou  
- metástase hepática ressecável, mas com alto risco cirúrgico, ou seja, que não podem realizar a ressecção cirúrgica.  
Destaca-se que não são elegíveis à realização do procedimento de ablação térmica pacientes com tumor primário, qualquer outra doença maligna nos últimos 10 anos (exceto carcinoma do colo do útero in situ ou câncer de pele não melanoma), neuropatia sensorial superior a grau 1, doença cardiovascular clinicamente significativa, hipertensão não controlada, distúrbios hemorrágicos ou coagulopatia e infecção ativa.  
Ressalta-se que, devido à ausência de evidências clínicas acerca da ablação térmica por microondas, serão considerados os mesmos critérios de elegibilidade da ablação por radiofrequência.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.2.     Tratamento medicamentoso** -->
Os tratamentos preconizados neste Protocolo são baseados na literatura científica atual que demonstra impacto na história natural da doença, nas tecnologias com indicação relacionada ao adenocarcinoma de cólon e reto aprovadas pela Agência Nacional de Vigilância Sanitária (Anvisa) com o objetivo principal de reduzir a mortalidade da doença e nas recomendações da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec).  
10  
Este PCDT abordará os esquemas terapêuticos atualmente disponíveis no Sistema Único de Saúde (SUS). Alguns medicamentos citados no texto não possuem recomendação favorável de incorporação e, portanto, não estão indicados como alternativas terapêuticas no SUS. Os esquemas terapêuticos já incorporados ao SUS estão destacados nos quadros de acordo com as linhas de tratamento. As novas tecnologias em fase de avaliação ou que serão demandadas para análise pela Conitec serão incluídas nas versões subsequentes para garantir a sua atualização constante.  
O uso da terapia antineoplásica deverá fazer parte de um plano terapêutico global para pacientes clinicamente aptos ao tratamento, segundo suas finalidades 50.  
A quimioterapia infusional ambulatorial para o tratamento de adenocarcinoma de cólon e reto, utilizando uma bomba elastomérica, oferece benefícios significativos aos pacientes. Este método permite uma administração contínua e controlada do medicamento, mantendo níveis terapêuticos adequados por um período prolongado. Além disso, a utilização da bomba elastomérica reduz a necessidade de múltiplas visitas hospitalares para infusões, proporcionando maior comodidade e qualidade de vida aos pacientes. Essa abordagem deve ser instituída sempre que possível, deve ser personalizada e pode contribuir para uma melhor resposta ao tratamento e potencialmente melhorar os resultados a longo prazo no combate ao câncer colorretal.  
No adenocarcinoma de cólon e reto, a quimioterapia pode ser considerada nos seguintes pacientes:  
- Quimioterapia prévia (neoadjuvante) – realizada antes do procedimento cirúrgico em pacientes com adenocarcinoma de  
- reto no estád     io II ou III, associada ou não à radioterapia; não é preconizada para pacientes com adenocarcinoma de cólon.  
- Quimioterapia adjuvante: realizada após procedimento cirúrgico em pacientes com adenocarcinoma de cólon ou reto  
- (com adenocarcinoma no estád     io III e, excepcionalmente, no estád     io II);  
- Quimioterapia paliativa – realizada em pacientes com câncer cólon ou reto recidivado inoperável ou com doença no estád     io IV ao diagnóstico, desde que apresente capacidade funcional ECOG 0, 1 ou 2 e expectativa de vida maior que seis meses. Também contempla a quimioterapia de conversão, nos casos de metástases hepáticas potencialmente ressecável.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.2.1.1. Cólon** -->
O papel da terapia neoadjuvante no adenocarcinoma de cólon não é bem estabelecido, ao contrário do que ocorre no adenocarcinoma retal. No entanto, há um crescente interesse em seus potenciais benefícios, especialmente para casos de alto risco.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.2.1.2. Reto** -->
A terapia neoadjuvante clássica consiste em radioterapia ou quimiorradioterapia seguida de cirurgia, com quimioterapia sistêmica pós-operatória (adjuvante). A duração do tratamento em geral é de três a seis meses, determinada pelo plano terapêutico, toxicidade e resposta objetiva à quimioterapia, podendo ser empregado concomitante ou não à radioterapia 51,52,53. Já a terapia neoadjuvante total (TNT) é uma abordagem em que os pacientes concluem toda a radioterapia e quimioterapia pretendidas antes de serem submetidos à cirurgia com intenção curativa, e pode ser classificada como de indução (quimioterapia sistêmica seguida de quimiorradioterapia) ou de consolidação (quimiorradioterapia inicial seguida de quimioterapia).  
A radioterapia em contexto de TNT pode ser de intervalo curto (hipofracionada) ou de intervalo longo (fracionamento convencional). Esses esquemas de radioterapia podem ser associados tanto à TNT de indução ou consolidação.  
A TNT pode ser considerada no tratamento inicial do adenocarcinoma retal médio ou baixo em estád     io II ou III. No cenário de resposta clínica completa, a preservação do reto é viável, oncologicamente segura e associada à menor morbidade comparada aos tratamentos convencionais.  
Não há aumento na toxicidade grau 3 relacionada ao tratamento do adenocarcinoma do reto com TNT em comparação à quimioterapia e radioterapia convencionais.  
11  
Os esquemas de quimioterapia neoadjuvante estão descritos no **Quadro 5** .  
**Quadro 5** - Esquemas terapêuticos para quimioterapia neoadjuvante em pacientes com adenocarcinoma de reto.  
Possíveis esquemas Capecitabina 54; Fluorouracil55; Fluorouracil, ácido folínico 56 Fluorouracil, ácido folínico, oxaliplatina e irinotecano Oxaliplatina, ácido folínico e fluorouracil Capecitabina e oxaliplatina  
**Fonte: elaboração própria.** Nota: Os medicamentos podem ser administrados por infusão prolongada ou curta, conforme disponibilidade e organização do serviço.  
O estudo PRODIGE-23, que propõe o uso de seis ciclos do regime FOLFIRINOX seguido de quimioradioterapia de longa duração, cirurgia e seis ciclos adicionais do regime FOLFOX adjuvante, em pacientes com câncer de reto localmente avançado, demonstrou aumento das taxas de resposta patológica completa, da sobrevida livre de recidiva e da sobrevida global quando comparado ao regime neoadjuvante clássico composto por quimioradioterapia, cirurgia e quimioterapia adjuvante. O regime FOLFIRINOX no estudo PRODIGE-23 apresentou neutropenia grave em 45%, diarreia em 12%, neuropatia sensitiva em 9%, fatiga severa em 24%, náuseas e vômitos em 15%, e estomatite em 6% dos pacientes. Essas toxicidades limitantes requerem monitoramento e suporte rigorosos 57.  
O estudo OPRA oferece a oportunidade de iniciar o tratamento neoadjuvante total com quimioradioterapia de longa duração seguido de quimioterapia de consolidação com quatro meses de um regime baseado em oxaliplatina (capecitabina + oxaliplatina, ou 5-fluorouracil, ácido folínico, e oxaliplatina) e cirurgia. Este regime se associou a uma elevada taxa de preservação de órgão, com 54% dos pacientes livres da excisão total do mesorreto em um período de seguimento de três anos 58,59.  
O estudo PROSPECT propôs o uso de quimioterapia isolada com seis ciclos do regime FOLFOX seguido de cirurgia e opcionais seis ciclos de quimioterapia comparado ao regime clássico de quimioradioterapia, cirurgia e quimioterapia adjuvante. Os pacientes do braço quimioterapia isolada que apresentassem redução tumoral menor que 20% eram encaminhados para quimioradioterapia. Pacientes com tumores T4, 4 ou mais linfonodos pélvicos ou com distância menor que 3 mm da fáscia mesoretal não eram candidatos a este estudo. Os resultados demonstraram uma equivalência na sobrevida livre de recidiva entre os grupos, tornando a omissão da radioterapia uma possibilidade terapêutica em um subgrupo de pacientes com câncer de reto localmente avançado 60.  
O estudo RAPIDO, que propunha um regime de curta duração de radioterapia (5 frações de 5Gy) seguido de quimioterapia baseada em oxaliplatina e cirurgia, demonstrou viabilidade da técnica TNT com menor toxicidade aguda, porém com taxas muito elevadas de recorrência local em um seguimento clínico acima de cinco anos, em pacientes com câncer retal localmente avançado de alto risco 61.  
Como não está definida a melhor sequência de tratamento neoadjuvante, para otimizar o acesso e utilização da radioterapia, deve-se considerar o uso do protocolo RAPIDO: cinco frações de radioterapia (5 Gy) em até oito dias, seguido por seis ciclos de quimioterapia 61.  
Pacientes que alcancem resposta clínica completa após tratamento neoadjuvante, confirmada por avaliação clínica, radiológica e histológica, podem ser elegíveis para vigilância clínica ativa e resgate cirúrgico em caso de recidiva local da doença 62,63. No entanto, essa modalidade requer critérios de triagem rigorosos e acompanhamento padronizado.  
12

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.2.2.  Quimioterapia adjuvante** -->
A decisão de iniciar a quimioterapia adjuvante depende da avaliação do risco de recidiva do paciente após a ressecção do tumor. Esse risco é estimado por características clínico-patológicas do tumor e a presença ou não de instabilidade microssatélite.  
Os microssatélites são sequências de 1 a 6 bases do DNA repetidas, próximas ou não às regiões codificantes. A instabilidade de microssatélites é a presença de qualquer alteração no tamanho dessa sequência de DNA, causada por inserções ou deleções, e indica que a função de reparo do DNA não ocorre normalmente. O diagnóstico de instabilidade microssatélite é realizado pela comparação das características dos microssatélites do tecido tumoral e de um tecido normal do indivíduo e, na maioria dos casos, pode ser realizado por técnica de imuno-histoquímica.  
No adenocarcinoma de cólon e reto, estudos apontam que a presença de deficiência das enzimas de reparo/instabilidade microssatélite confere melhor prognóstico ao paciente, não sendo necessária a realização de quimioterapia adjuvante no estádio II de risco habitual, quando presente.  
Em pacientes com adenocarcinoma de cólon e reto, considera-se que a doença possui alto-risco de recidiva (fatores de mau prognóstico) nos seguintes pacientes 64:  
- Estád     io clínico III; ou  
- Estád     io clínico II, se caracterizada pelo menos uma das seguintes condições:Tumor T4;  
- Obstrução intestinal e/ou perfuração intestinal ao diagnóstico;  
- Margem cirúrgica inadequada ou indeterminada;  
- Peça cirúrgica com menos de      12 linfonodos ressecados;  
- Histologia pouco diferenciada;  
- Invasão de vasos sanguíneos ou linfáticos;  
- Invasão perineural.  
A quimioterapia adjuvante melhora a sobrevida livre de doença para o câncer do reto localmente avançado, mesmo no contexto de resposta patológica completa. No entanto, muitos pacientes não recebem terapia adjuvante devido a complicações pós-operatórias.  
A ressecção cirúrgica inicial seguida de quimioterapia adjuvante para os estád     io      II de alto risco e estádio III      do câncer de cólon é o padrão de cuidado      atual.  
Desta forma, considera-se que tumores de cólon e reto com estád     io clínico I não necessitam de tratamento adjuvante.  
Além disso, apenas os pacientes de alto risco e estáveis com estadiamento II têm indicação para tratamento com quimioterapia. Caso contrário, pacientes em estádio II também não necessitam realizar o tratamento quimioterápico adjuvante, podendo realizar apenas de acompanhamento vigilante.  
Ainda, são elegíveis para tratamento adjuvante os pacientes com tumores de cólon e reto com boa capacidade funcional (ECOG 0 ou 1), expectativa de vida maior que 24 meses e, idealmente, para início até 12 semanas após a realização do procedimento cirúrgico.  
A duração do tratamento pode variar de três a seis meses, segundo plano terapêutico inicial e tolerância clínica observada. Os esquemas de quimioterapia adjuvante estão descritos no **Quadro 6.**  
**Quadro 6** - Esquemas terapêuticos para quimioterapia adjuvante em pacientes com adenocarcinoma de cólon.  
Possíveis esquemas Oxaliplatina, ácido folínico e fluorouracil 65–67; Capecitabina e oxaliplatina 68–70; Oxaliplatina, ácido folínico e fluorouracil 71,72;  
13  
Capecitabina 73; Fluorouracil e ácido folínico 74,75  
Fonte: elaboração própria.  
Nota: Os medicamentos podem ser administrados por infusão prolongada ou curta, conforme disponibilidade e organização do serviço.  
A escolha do melhor esquema para pacientes com tumores de cólon e reto deve levar em conta o estádio, devendo preferencialmente, contemplar adição de oxaliplatina para o estádio III e estádio II com múltiplos fatores de risco. Em geral, há preferência por capecitabina e oxaliplatina como tratamento de pacientes em estádio III de baixo risco. Este esquema de tratamento deve ser administrado por, no máximo, 3 meses.  
Em pacientes idosos (acima de 70 anos) com tumores de cólon e reto com baixa capacidade funcional (ECOG maior que 2), preconiza-se prefer     encialmente o uso de capecitabina por seis meses 76,77. Fluorouracil por seis meses pode ser indicado, no entanto, devido a necessidade do uso de bomba elastomérica, não é considerado o tratamento preferencial.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.2.2.1. Quimioterapia no adenocarcinoma de cólon e reto avançado** -->
<mark>A quimioterapia paliativa pode significativamente prolongar a sobrevida global de pacientes com adenocarcinoma de cólon e reto em estágio avançado ou recidivado inoperável. Sua recomendação deve ser cuidadosamente avaliada no plano de tratamento, priorizando pacientes com capacidade funcional 0, 1 ou 2 e aptos para terapia, enquanto aqueles com capacidade funcional 3 ou 4 devem, preferencialmente, terem o suporte clínico especializado priorizado.</mark>  
A seleção do tratamento deve considerar as características fisiológicas e a capacidade funcional individuais, perfil de toxicidade, preferências do paciente e protocolos terapêuticos institucionais.  
No tratamento de primeira linha para pacientes com boa capacidade funcional (ECOG 0 ou 1), recomenda-se a terapia combinada de fluoropirimidinas em associação com oxaliplatina e/ou irinotecano: 5-fluorouracil, ácido folínico e oxaliplatina; 5-fluorouracil, ácido folínico e irinotecano, 5-fluorouracil, ácido folínico, oxaliplatina e irinotecano; capecitabina e oxaliplatina.  
Já os pacientes com capacidade funcional comprometida (ECOG 2) preferencialmente devem ser tratados com capecitabina ou 5-fluoruracil e ácido folínico no tratamento de primeira linha 78.  
Os esquemas de quimioterapia para pacientes com adenocarcinoma de cólon e reto avançado estão descritos no **Quadro**

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **7.** -->
**Quadro 7** - Esquemas terapêuticos para quimioterapia em pacientes com adenocarcinoma de cólon e reto avançado.  
Esquemas possíveis para quimioterapia de adenocarcinoma de cólon e reto avançado Fluorouracil, ácido folínico e oxaliplatina Fluorouracil, ácido folínico e irinotecano Fluorouracil e ácido folínico Irinotecano e oxaliplatinaa Fluorouracil, ácido folínico, oxaliplatina e irinotecano Capecitabina e oxaliplatina Capecitabina Irinotecano  
Fonte: elaboração própria.  
a. Preferencialmente utilizado em pacientes com suspeita de deficiência de diidropirimidina desidrogenase (DPD).  
Nota: Os medicamentos podem ser administrados por infusão prolongada ou curta, conforme disponibilidade e organização do serviço.  
14  
Não são preconizados neste Protocolo os medicamentos cetuximabe, bevacizumabe e panitumumabe porque tiveram recomendação e decisão não favorável à incorporação no SUS para o tratamento do câncer colorretal metastático, conforme Portarias SCTIE/MS nº 56/2013, SCTIE /MS nº 64/2015, SCTIE/MS nº 04/2018 e SCTIE/MS nº 68/2022 79–83. Também não é preconizado o medicamento pembrolizumabe, uma vez que não foi incorporado para o tratamento de pacientes com câncer de cólon e reto metastático com instabilidade microssatélite alta (MSI-H) ou deficiência de enzimas de reparo (dMMR), conforme Portaria SECTICS/MS nº 74/2023 84.  
Não são preconizados neste Protocolo trifluridina/tipiracil, ramucirumabe, aflibercepte e regorafenibe por não terem sido avaliados pela Conitec para tratamento de adenocarcinoma de cólon e reto.  
A quimioterapia intra-arterial hepática pode ser empregada no tratamento de metástases hepáticas irressecáveis com finalidade de conversão para cirurgia radical. O tratamento tem a vantagem de aumentar a exposição intra-hepática ao antineoplásico com toxicidade sistêmica reduzida, mas seu papel exato é controverso pela ausência de benefícios consistentes nas taxas de sobrevida. Esta modalidade terapêutica só deve ser oferecida em um programa multidisciplinar com participação de especialistas em cirurgia hepatobiliar, oncologia clínica e radiologia intervencionista 85.  
O regime quimioterápico no tratamento de 2ª linha ou 3ª linha deve ser selecionado segundo a capacidade funcional, comorbidade, esquema usado anteriormente e o perfil de segurança e eficácia então observados.  
Diretrizes internacionais recomendam que para pacientes tratados com terapia de primeira linha à base de oxaliplatina, o tratamento de segunda linha com irinotecano ou monoterapia é a opção. De forma inversa, os pacientes tratados com irinotecano em primeira linha poderiam receber um tratamento à base de oxaliplatina (FOLFOX ou CAPOX) em segunda linha se não houvesse contraindicações. A reintrodução da terapia de indução inicial pode ser considerada após a terapia de segunda linha, desde que o paciente não tenha progredido durante o curso de indução da quimioterapia de primeira linha 64.  
Recomenda-se o envolvimento precoce de especialista em cuidados paliativos no cuidado de pacientes considerados para terapia antineoplásica, particularmente no tratamento paliativo. A integração precoce dos cuidados paliativos está associada à diminuição do tempo de hospitalização, utilização racional de recursos médicos e diminuição dos custos diretos para o sistema de saúde 86–88  
As Figuras 1 a 8 descrevem o algoritmo de tratamento para pacientes com adenocarcinoma de cólon e reto, nos diferentes estádios.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **6.3.1.  Adenocarcinoma de cólon** -->
15  
**Figura 1** - Algoritmo de tratamento de adenocarcinoma de cólon, estádios 0 e I.  
<!-- Start of picture text -->
| Pacientes com adenocarcinoma de célon e estédio 0 e | |<br>Nao / Paciente sim<br>elegivel’resseccaopara endoscépicaResseccao<br>endoscopica?<br>Colectomia ResseccSosegmentar colénica+<br>linfadenectomia<br>+ Critérios favordveis para ressecco endoscopica’ invaso até 1.000 micras da submucosa;<br>fauséncia de invaso angiolintética; histologia bem diferenciada; auséncia de tumor budding:<br>Imargens livres.<br><!-- End of picture text -->  
**Figura 2** - Algoritmo de tratamento de adenocarcinoma de cólon, estádio II.  
<!-- Start of picture text -->
Pacientes com adenocarcinoma de colon, estadio II<br>Resseccao colénica<br>‘segmentar +<br>linfadenectomia<br>Presenca de fatores \\N2°<br>de mau prognéstico na<br>peca cirirgica?<br>=<br>Pacienteaciente apresentita Nee)<br>microssatélite?stabicade capoctanna 8 ocke<br>1 sim<br>Paciente apresenta \ N@°<br>miltiplos fatores<br>de risco?<br>Sim<br>Preferencialmente,<br>esquemas com<br>oxaliplatina_<br><!-- End of picture text -->  
16  
**Figura 3** - Algoritmo de tratamento de adenocarcinoma de cólon, estádio III.  
<!-- Start of picture text -->
| Pacientes com adenocarcinoma de cblon e estado Ill |<br>Sim /paciente apresenta N80<br>lesdes T4b<br>efouN2? —/<br>- Ressecco colénica<br>Resseccdo pooea ae<br>aed linfadenectomia<br>|uimioterapia Quimioterapia<br>adjuvante adjuvante<br><!-- End of picture text -->  
**Figura 4** - Fluxo de tratamento de adenocarcinoma de cólon, estádio IV  
<!-- Start of picture text -->
| Pacientes com adenocarcinoma de célon e estadio IV<br>Figado @ 0 nico sitio de bd<br>metastase?<br>- | sim<br>Sled apresentaPaciente Nao.<br>metdstase hepatica<br>ressecavel? (Quimioterapia de<br>conversio +/- ablacdo<br>térmica’<br>Colectoia +<br>metastectomiaou Reestadiamento<br>quimioterapia clinico<br>citorredutora seguida<br>de colectomia +<br>metastectomia<br>J Paciente<br>Sm apresenta<br>metdstase hepatica<br>ressecével?<br>| Nao<br>Quimioterapia<br>paliativa<br>‘valiar a necessidade de<br>cirurgia ou radioterapia<br>paliativa<br>A ablac&o térmica sO esta indicada para metastases hepaticas,<br>lconforme os critérios de elegibilidade descrites no Protocolo<br><!-- End of picture text -->  
17  
**6.3.2 Adenocarcinoma de reto**  
**Figura 5** - Fluxo de tratamento de adenocarcinoma de reto, estádio 0 e I.  
<!-- Start of picture text -->
| Pacientes com adenocarcinoma de reto, estadio 0 ou!<br>= ‘Sim Paciente elegivel’<br>Resseccdo ("para resseccdo<br>Nao<br>( Estadioo J| U Estadio!<br>Excisio local | Paciente apresenta<br>transanal ou lesdes T1 de alto<br>retossigmoidectomia risco ou T2?<br>is pcos<br>do tumor<br>{ Reto superior Reto médio | Reto inferior<br>Resseccdoreto com anterior exciso do. | Ressecco0 reto com anterior exciso sim _/ do‘comprometimentoPaciente apresenta esfincter externo Nao<br>‘mesorretal parcial ‘mesorretal total ou do plano inter-<br>—_ J esfincteriano?<br>Quimiorradioterapia Resseccdo inter-<br>neoadjuvante esfincteriana<br>Excis&o total do Naoe nenclinic a sim<br>completa?<br>E Critérios favordveis para resseccdo endoscépica: invasdo até 1.000 micras da submucosa; auséncia de invasdo angiolinfatica;<br>|histologia bem diferenciadas; auséncia de tumor budding; margens livres.<br><!-- End of picture text -->  
18  
**Figura 6 -** Fluxo de tratamento de adenocarcinoma de reto, estádio II e III, com lesões T4b.  
<!-- Start of picture text -->
Pacientes com adenocarcinoma de reto, estado Ile ll e com lesBes Tab<br>Avaliarlocalizaco do tumor<br>( Reto superior | Reto médio | _ Reto inferior<br>ft (Quimiorradioterapia e sim Doenca Nao<br>Resseccdo quimioterapia localmente<br>multiorganica neoadjuvante avancada<br>de alto risco?<br>cease Essen)<br>Neoadjuvancia Neoadjuvancia<br>sim total dlassica<br>Paciente Nao | Quimioterapia<br>presenta fatores ana<br>de mau<br>Usnastico? Exenteracao Exenteracdo<br>pelvica pélvica<br>Quimioterapia (Copurie<br>| Considerar esquemas de neoadjuvancia total nos casos de doenca localmente avancada de alto risco (tumores T4, linfonodos suspeitos. invasdi<br>enosa extramural, margem radial comprometida).<br><!-- End of picture text -->  
19  
<!-- Start of picture text -->
Pacientes com adenocarcinoma de reto, estédio Ile ll e sem lesdes T4b<br>Avaliar localizaco do tumor<br>Reto superior Reto médio Reto inferior }<br>'Ressecco anterior do ‘Sim _/Doenca locaimente Sim —_/Qoenca tocalmente, Nao<br>eto com excisdo avancada avan« Estadio I<br>mesorretal parcial de alto risco? —<br>Neoadjuvancia Nao Ressecedo inter-<br>total Estadio I Neonat esfincteriana*<br>Estadio It J Estadio it<br>‘avaliar possibilidade Estadio lh )<br>doResseogao reto com  anterior excisao (60 esseccio anteriorsai<br>sim Paciente Nao | uimioterapia cp aallctca do reto com excisao<br>presenta fatores agjuvante ERO Ee sim _/ Paciente atingiu [Giamoneactorars<br>dain<br>rognéstico? clinica‘eopocts completa?tg—________|ecetreesQuimiorradioterapia<br>= ‘Observacdo<br>in ome<br>Quimiorradioterapia Paciente apresenta<br>neoadjuvante Sim / —comprometimento Nao<br>do esfincter externo<br>ou do piano<br>inter-esfincteriano?<br>me Pans pe<br>abdominoperineal esfincteriana<br><!-- End of picture text -->  
**Figura 7** - Fluxo de tratamento de adenocarcinoma de reto, estádio II e III, sem lesões T4b. (Ficura a cima)  
20  
**Figura 8** - Fluxo de tratamento de adenocarcinoma de reto, estádio IV.  
<!-- Start of picture text -->
f Pacientes com adenocarcinoma de reto e estddio IV |<br>sim _/Paciente apresenta. Nao<br>metastase<br>ressecavel? a<br>Sim _/Paciente apresenta Nao<br>obstrutivas?<br>Quimioterapiasistemica = lesées<br>Radioterapia do Colostomia + Quimioterapia sistémica<br>tumor primario* quimioterapia | +i- ablacdo térmica<br>Avaliar a necessidade de<br>radioterapia do tumor<br>primario, conforme<br>Tesposta ao tratamento<br>Reestadiamento<br>clinico<br>Nao i<br>ected—= ; Pacientemiokastesaressecdvel?apresenta<br>‘Sim<br>Ressecc&o do tumor<br>primario +<br>metastasectomia<br>* O tratamento deve ser individualizado. A ordem e o ntimero de abordagens terapéuticas a serem<br>utilizadas podem mudar conforme os critérios clinicos.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **7.        MONITORAMENTO** -->
Pacientes em tratamento antineoplásico devem ser monitorados para possíveis toxicidades em cada ciclo, assim como para funções renal e hepática. A conduta a ser tomada de acordo com a toxicidade observada é apresentada no Quadro 8.  
**Quadro 8 -** Avaliação da toxicidade conforme terapia utilizada.  
|Tratamento|Conduta|
|---|---|
|Oxaliplatina|Caso sejam encontradas alterações no exame neurológico, a dose de oxaliplatina deve ser reduzida em<br>15 a 20% e, na persistência dos sintomas durante o ciclo seguinte, o tratamento com o medicamento<br>deve ser interrompido.|
|Irinotecano|Para reação adversa ao medicamento (RAM) grau 1, deve-se manter a dose utilizada.<br>Para RAM grau 2, deve-se reduzir a dose em 25 mg/m2 e manter a dose inicial após recuperação<br>adequada.<br>Para RAM grau 3, deve-se omitir a dose até atingir o grau 2 ou menor e, então, reduzir a dose em 25|
||mg/m2 quando ciclo semanal, e em 50 mg/m2 quando o ciclo for de 2 ou 3 semanas.<br>Para RAM grau 4, deve-se omitir a dose até atingir grau 2 ou menor e então reduzir a dose em 50<br>mg/m2.|  
21  
|Tratamento|Conduta|
|---|---|
||Um novo ciclo de tratamento não deve ser iniciado, até que o número de granulócitos aumente para<br>1.500 células/mm3 ou mais; o número de plaquetas tenha aumentado para 100.000 plaquetas/mm3 ou<br>mais e a diarreia relacionada ao tratamento tenha se resolvido completamente.<br>O tratamento deve ser adiado por 1 a 2 semanas, para permitir a recuperação dos efeitos tóxicos<br>relacionados ao tratamento. Se o paciente não tiver se recuperado após um adiamento de 2 semanas,<br>deve-se considerar a interrupção do tratamento.|
|Capecitabina|Não se recomenda mudança da dose caso surjam RAM grau 1.<br>Caso ocorram RAM grau 2 ou 3, deve-se interromper o tratamento.<br>Se o paciente deixar de apresentar RAM grau 2 ou se a intensidade da RAM for reduzida para grau 1,<br>a terapia pode ser reiniciada, com dose total. Caso ocorra nova RAM, reduzir a dose em 25%; se ocorrer<br>3ª RAM, a dose deve ser reduzida em 50%. Se ocorrer 4ª RAM, a terapia deve ser interrompida<br>definitivamente.<br>Em RAM grau 3, a terapia pode ser reiniciada com dose ajustada em 75% caso seja 1ª ocorrência; em<br>uma segunda ocorrência, ajustar a dose em 50%. Uma 3ª ocorrência de RAM justifica a interrupção<br>definitiva do uso.<br>Para as RAM grau 4, a terapia deve ser interrompida até que a RAM tenha sido solucionada ou<br>diminuída para grau 1, quando a terapia deve ser reiniciada com 50% da dose original. Após 2ª<br>ocorrência da RAM, a terapia deve ser interrompida definitivamente.|
|Fluorouracila|Quando ocorrerem sintomas de toxicidade resultantes da terapia inicial, a dose de manutenção deverá<br>ser de 10 a 15 mg/kg/semana, não devendo exceder 1 g/semana.|  
Fonte: bula dos medicamentos 89–92.  
Além disso, pacientes que fazem uso de oxaliplatina devem ser questionados ativamente sobre grau e persistência de neuropatia e submetidos a um exame neurológico sucinto, avaliando sensibilidade e propriocepção de mãos e pés, além de motricidade motora fina (abotoar camisa, amarrar cadarços, por exemplo) 93.  
Pacientes em uso de irinotecano devem ser questionados quanto à ocorrência de diarreia, principalmente após 1 semana da infusão. Recomenda-se uso de loperamida (4 a 24 mg/dia) caso a diarreia ocorra e, caso ela persista apesar do uso adequado do medicamento sintomático, deve-se reduzir a dose de irinotecano 94.  
Ainda, pacientes em uso da capecitabina podem apresentar síndrome mão pé e, nesse caso, deve-se interromper temporariamente o tratamento, além do uso de corticosteroides tópicos e emolientes até melhora. Após a melhora, deve-se reintroduzir o medicamento antineoplásico com redução de dose.  
Os pacientes em uso de tratamento adjuvante devem realizar exames de reestadiamento e monitorização tumoral, como CEA, a cada 3 meses, exceto em casos em que haja suspeita clínica para progressão de doença. Os pacientes em vigência de quimioterapia para doença metastática devem ser monitorados quanto à resposta e à eficácia da terapia antineoplásica a cada dois a três meses, com exames de imagem.  
Amostra de sangue para dosagem de CEA pode ser coletada mensalmente para monitorização em pacientes que apresentam este marcador elevado antes do início do tratamento. Quando os níveis de CEA permanecem elevados, há correlação com a progressão de doença, o que deve ser confirmado por exames de imagem.  
Para avaliação de resposta ao tratamento, utiliza-se o critério RECIST 1.1 95 (Quadro 9), comparando com os exames de imagem anteriores.  
22  
**Quadro 9** - Critério RECIST 1.1 para avaliação de resposta.  
|Critério RECIST|Interpretação|
|---|---|
|Resposta total|Denota desaparecimento das lesões|
|Resposta parcial|Redução de mais de 30% da soma dos diâmetros das lesões mensuráveis em relação ao<br>menor diâmetro nesta linha de tratamento|
|Doença estável|Redução menor que 30% ou aumento menor do que 20% da soma dos diâmetros das lesões<br>mensuráveis em relação ao menor diâmetro nesta linha de tratamento|
|Progressão da doença|Aumento de mais de 30% ou aparecimento de novas lesões em relação ao menor diâmetro<br>nesta linha de tratamento|  
Fonte: Adaptado de Eisenhauer et al, 2009 95.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: ACOMPANHAMENTO PÓS-CIRÚRGICO -->
Os pacientes que receberam tratamento cirúrgico curativo, seguido ou não de quimioterapia adjuvante, devem fazer o acompanhamento pós-cirúrgico com exames clínicos, dosagem de CEA e exames de imagem (tomografias de abdome superior e tórax e colonoscopia) periodicamente, conforme o estádio da sua doença, como apresentado no Quadro 9 e detalhadamente nos subtítulos a seguir.  
**Quadro 10 -** Acompanhamento pós-cirúrgico.  
|Acompanhamento|Elegibilidade|Tempo|
|---|---|---|
|Colonoscopia|todos os pacientes com diagnóstico de<br>adenocarcinoma de cólon e reto|um ano após o tratamento cirúrgico e repetir o<br>exame, conforme os achados da colonoscopia<br>– ver subtítulo 10.1.|
|Retosigmoidoscopia|pacientes com adenocarcinoma retal<br>submetidos à ressecção endoscópica ou<br>transanal e que não tenham realizado<br>radioterapia|cada três a seis meses, associada à ressonância<br>nuclear magnética de reto, por dois anos após<br>excisão e, após este período, a cada seis meses<br>até o quinto ano.|
||todos<br>os<br>pacientes<br>com|cada três meses durante dois anos e, entre o|
|Anamnese e exame clínico|adenocarcinoma de cólon e reto, exceto<br>adenocarcinoma de cólon estádio I|terceiro e quinto ano, acompanhamento<br>semestral.|
|Antígeno<br>carcinoembrionário<br>(CEA)|pacientes com adenocarcinoma de<br>cólon e reto estádios II a III|cada visita clínica durante cinco anos. Se o<br>nível de CEA estiver elevado, coleta nova<br>amostra em um mês.|
|Exames de imaem (tomorafia|pacientes com CEA elevado|realizar após persistência de CEA elevado,<br>para confirmar recidiva.|
|g g<br>de tórax, abdome e pelve)|pacientes com adenocarcinoma de<br>cólon e reto estádios II e III|a cada 6 a 12 meses por três anos e, após esse<br>período, anualmente até completar cinco anos<br>da cirurgia|  
Fonte: elaboração própria.  
O seguimento intensivo tem possível benefício frente ao não intensivo 96, possivelmente devido à maior detecção de doença ressecável.  
Colonoscopia / Retossigmoidoscopia  
23  
Pacientes com antecedente de adenocarcinoma de cólon e reto apresentam um risco para doença metacrônica ou recidiva local quando submetidos à ressecção endoscópica 96. Portanto, todos os pacientes com diagnóstico de adenocarcinoma de cólon e reto devem fazer a colonoscopia em um ano após o tratamento cirúrgico e repetir o exame, conforme os achados da colonoscopia.  
Caso a colonoscopia indicar a presença de pólipos adenomatosos de alto grau, deve-se repeti-la em um ano. Caso o resultado da colonoscopia indique a ausência de pólipos ou pólipos de baixo grau, deve-se repeti-la em três a cinco anos. Ainda, pacientes com adenocarcinoma retal submetidos à ressecção endoscópica ou transanal e que não tenham realizado radioterapia devem fazer retossigmoidoscopia a cada três a seis meses, associada à ressonância nuclear magnética de reto, por dois anos após excisão e, após este período, a cada seis meses até o quinto ano  97.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: Anamnese e Exame clínico -->
Pacientes com adenocarcinoma de colón estádio I devem seguir as recomendações de realização de colonoscopia descritas no item Colonoscopia / Retossigmoidoscopia.  
Todos os demais pacientes devem ser acompanhados periodicamente com exames clínicos a cada três meses durante dois anos e, entre o terceiro e quinto ano, acompanhamento semestral. As consultas de acompanhamento devem abordar possíveis sinais e sintomas relacionados à recidiva da doença, verificar exames relacionados, além de reforçar as orientações de hábito de vida saudável e monitorar possíveis eventos adversos persistentes pós-tratamento, como neuropatia pós-oxaliplatina ou alterações de evacuação secundárias à cirurgia/radioterapia.  
Antígeno carcinoembrionário (CEA)  
Pacientes com tumores estádio II e III devem realizar dosagem sérica do CEA a cada visita clínica durante cinco anos. Se o nível de CEA estiver elevado, devido à sua baixa especificidade, recomenda-se a coleta de nova amostra em um mês. Caso a elevação persista, deve-se realizar exames de imagem (tomografia de tórax, abdome e pelve, caso ainda não tenha sido realizado) para avaliação de possível recidiva.  
Exames de imagem  
Pacientes com adenocarcinoma de cólon e reto estádios II e III devem realizar exames de imagem (tomografia de tórax, abdome e pelve) a cada 6 a 12 meses por três anos e, após esse período, anualmente até completar cinco anos da cirurgia.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **8.        REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamentos.  
Casos de adenocarcinoma de cólon e reto devem ser atendidos em hospitais habilitados em oncologia e com porte tecnológico suficiente para diagnosticar, tratar e realizar o seu acompanhamento. Além da familiaridade que esses hospitais guardam com o estadiamento, o tratamento e o controle dos eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios, necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
Pacientes com diagnóstico de adenocarcinoma de cólon ou de junção retossigmoide podem ser atendidos em hospitais habilitados em oncologia com ou sem serviço de radioterapia, enquanto pacientes com adenocarcinoma de reto devem ser tratados, preferencialmente, em hospitais habilitados em oncologia com serviço de radioterapia. Ainda, no caso de pacientes idosos, a equipe multiprofissional deve contar com geriatra, a fim de possibilitar um planejamento terapêutico adequado para suas necessidades.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos pacientes, além de facilitar as ações de controle e avaliação. Estas incluem, entre outras: a manutenção  
24  
atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos); a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente - primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica), entre outras. Ações de auditoria devem verificar in loco, por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e capacidade funcional (escala ECOG); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos pacientes.  
O Ministério da Saúde não padroniza nem fornece medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. A exceção é feita ao mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia linfoblástica aguda cromossoma Philadelphia positivo; do nilotinibe e do dasatinibe para a quimioterapia da leucemia mieloide crônica; do rituximabe para a poliquimioterapia do linfoma folicular e do linfoma difuso de grandes células B; e dos trastuzumabe e pertuzumabe para a quimioterapia do carcinoma de mama, que são adquiridos pelo Ministério da Saúde e fornecidos aos hospitais habilitados em oncologia no SUS, por meio das secretarias estaduais de saúde. Os hospitais credenciados pelo SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), radioterápicos e quimioterápicos (Grupo 03, Subgrupo 01) e cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada.  
Para fins de avaliação e controle, deve ser considerada quimioterapia de 2ª linha todo tratamento antineoplásico paliativo (adenocarcinoma avançado) realizado após uma quimioterapia paliativa inicial (1ª linha), não importando em que estabelecimento ou sistema de saúde tenha sido realizada.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **9. REFERÊNCIAS** -->
1. Cordeiro F, Yamaguchi N, Habr-Gama A, Cutait R, Reinan R, Abramoff R, et al. Diagnóstico, Estadiamento e Tratamento Cirúrgico e Multidisciplinar do Câncer Colorretal. Associação Médica Brasileira e Conselho Federal de Medicina. 2001;12.  
2. Gunter MJ, Alhomoud S, Arnold M, Brenner H, Burn J, Casey G, et al. Meeting report from the joint IARC–NCI international cancer seminar series: a focus on colorectal cancer. Annals of Oncology [Internet]. 2019 Apr 1 [cited 2022 Nov 23];30(4):510–9. Available from: http://www.annalsofoncology.org/article/S0923753419311251/fulltext.  
3. Brasil. Ministério da Saúde, Instituto Nacional de Câncer José Alencar Gomes da Silva. Detecção Precoce do Câncer. Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA)  [Internet]. 2021 [cited 2022 Nov 23];72. Available from: http://controlecancer.bvs.br/.  
4. Brasil. Ministério da Saúde. Instituto Nacional de Câncer José Alencar Gomes da Silva. 2023.  
5. Brasil. Ministério da Saúde, Instituto Nacional de Câncer José Alencar Gomes da Silva. Estimativa 2020: incidência de câncer no Brasil [Internet]. Rio de Janeiro; 2019 [cited 2022 Nov 23]. Available from: https://www.inca.gov.br/sites/ufu.sti.inca.local/files/media/document/estimativa-2020-incidencia-de-cancer-no-brasil.pdf.  
25  
6. Arnold M, Sierra MS, Laversanne M, Soerjomataram I, Jemal A, Bray F. Global patterns and trends in colorectal cancer incidence and mortality. Gut [Internet]. 2017 Apr 1 [cited 2022 Nov 23];66(4):683–91. Available from: https://gut.bmj.com/content/66/4/683.  
7. World Health Organization. World Cancer Report: Cancer Research for Cancer Prevention. Wild CP, Weiderpass E, Stewart BW, editors. Vol. 199, Cancer Control. International Agency for Research on Cancer; 2020. 8. Brasil. Ministério da Saúde, Instituto Nacional de Câncer José Alencar Gomes da Silva. Dieta, nutrição, atividade física e câncer : uma perspectiva global : um resumo do terceiro relatório de especialistas com uma perspectiva brasileira [Internet]. Rio de Janeiro; 2020 [cited 2022 Nov 23]. Available from: http://controlecancer.bvs.br/. 9. Brasil. Ministério da Saúde. Caderno de atenção primária - Rastreamento [Internet]. 2010 [cited 2024 Jul 22]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/caderno_atencao_primaria_29_rastreamento.pdf.  
10. Niekel MC, Bipat S, Stoker J. Diagnostic imaging of colorectal liver metastases with CT, MR imaging, FDG PET, and/or FDG PET/CT: A meta-analysis of prospective studies including patients who have not previously undergone treatment. Radiology [Internet]. 2010 Dec 1 [cited 2022 Nov 24];257(3):674–84. Available from: https://pubs.rsna.org/doi/10.1148/radiol.10100729.  
11. Tsili AC, Alexiou G, Naka C, Argyropoulou MI. Imaging of colorectal cancer liver metastases using contrast-enhanced US, multidetector CT, MRI, and FDG PET/CT: a meta-analysis. https://doi.org/101177/0284185120925481 [Internet]. 2020 Jun 6 [cited 2022 Nov 24];62(3):302–12. Available from:  
https://journals.sagepub.com/doi/10.1177/0284185120925481?url_ver=Z39.88-  
2003&rfr_id=ori%3Arid%3Acrossref.org&rfr_dat=cr_pub++0pubmed.  
12. Daza JF, Solis NM, Parpia S, Gallinger S, Moulton CA, Belley-Cote EP, et al. A meta-analysis exploring the role of PET and PET-CT in the management of potentially resectable colorectal cancer liver metastases. European Journal of Surgical Oncology [Internet]. 2019 Aug 1 [cited 2022 Nov 24];45(8):1341–8. Available from: http://www.ejso.com/article/S0748798319303531/fulltext. 13. Taylor FGM, Quirke P, Heald RJ, Moran BJ, Blomqvist L, Swift IR, et al. Preoperative magnetic resonance imaging assessment of circumferential resection margin predicts disease-free survival and local recurrence: 5-Year follow-up results of the MERCURY Study. Journal of Clinical Oncology. 2014 Jan 1;32(1):34–43. 14. Horvat N, Rocha CCT, Oliveira BC, Petkovska I, Gollub MJ. MRI of rectal cancer: Tumor staging, imaging techniques, and management. Radiographics [Internet]. 2019 Mar 1 [cited 2022 Nov 24];39(2):367–87. Available from: https://pubs.rsna.org/doi/10.1148/rg.2019180114.  
15. Brasil. Ministério da Saúde. Relatório de recomendação: PET-CT na detecção de metástase hepática exclusiva potencialmente ressecável de câncer colorretal. 2014 [cited 2024 Feb 26]. 16. Konishi T, Shimada Y, Hsu M, Tufts L, Jimenez-Rodriguez R, Cercek A, et al. Association of Preoperative and Postoperative Serum Carcinoembryonic Antigen and Colon Cancer Outcome. JAMA Oncol [Internet]. 2018 Mar 1 [cited 2022 Nov 24];4(3):309–15. Available from: https://jamanetwork.com/journals/jamaoncology/fullarticle/2666759. 17. Liu Z, Zhang Y, Niu Y, Li K, Liu X, Chen H, et al. A Systematic Review and Meta-Analysis of Diagnostic and Prognostic Serum Biomarkers of Colorectal Cancer. PLoS One [Internet]. 2014 Aug 8 [cited 2022 Nov 24];9(8):e103910. Available from: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0103910. 18. Snowsill T, Coelho H, Huxley N, Jones-Hughes T, Briscoe S, Frayling IM, et al. Molecular testing for Lynch syndrome in people with colorectal cancer: systematic reviews and economic evaluation. Health Technol Assess (Rockv). 2017 Sep 12;21(51):1–238.  
19. Brierley J, Gospodarowicz M, Wittekind C. TNM Classification of Malignant Tumours. 8a ed. John Wiley & Sons; 2016.  
26  
20. Amin MB, Frederick ;, Greene L, Edge SB, Compton CC, Gershenwald JE, et al. The Eighth Edition AJCC Cancer Staging Manual: Continuing to build a bridge from a population-based to a more “personalized” approach to cancer staging. CA Cancer J Clin [Internet]. 2017 Mar 1 [cited 2024 Feb 22];67(2):93–9. Available from: https://onlinelibrary.wiley.com/doi/full/10.3322/caac.21388.  
21. Heikkinen T, Msika S, Desvignes G, Schwandner O, Schiedeck TH, Shekarriz H, et al. Laparoscopic surgery versus open surgery for colon cancer: Short-term outcomes of a randomised trial. Lancet Oncology [Internet]. 2005 Jul 1 [cited 2022 Nov 27];6(7):477–84. Available from: http://www.thelancet.com/article/S1470204505702217/fulltext. 22. Guillou PJ, Quirke P, Thorpe H, Walker J, Jayne DG, Smith AMH, et al. Short-term endpoints of conventional versus laparoscopic-assisted surgery in patients with colorectal cancer (MRC CLASICC trial): Multicentre, randomised controlled trial. Lancet [Internet]. 2005 May 14 [cited 2022 Nov 27];365(9472):1718–26. Available from: http://www.thelancet.com/article/S0140673605665452/fulltext.  
23. Nelson H. Laparoscopically assisted colectomy is as safe and effective as open colectomy in people with colon cancer. Cancer Treat Rev [Internet]. 2004 Dec 1 [cited 2022 Nov 27];30(8):707–9. Available from: http://www.cancertreatmentreviews.com/article/S0305737204001471/fulltext.  
24. Valadão M, Cesar D, Véo CAR, Araújo RO, do Espirito Santo GF, Oliveira de Souza R, et al. Brazilian society of surgical oncology: Guidelines for the surgical treatment of mid-low rectal cancer. J Surg Oncol [Internet]. 2022 Feb 1 [cited 2022 Nov 27];125(2):194–216. Available from: https://onlinelibrary.wiley.com/doi/full/10.1002/jso.26676.  
25. Valadão M, Araujo R, Junior M, Castro J, Silva R, Costa R, et al. Câncer colorretal. In: Valadão M, Cesar D, Gonçalves R, Linhares E, Araujo R, Sabino F, editors. Tratado de Cirurgia Oncológica Gastrointestinal. Rio de Janeiro; 2021. p. 256–319.  
26. Brasil. Ministério da Saúde. Relatório de Recomendação: Cirurgia de citorredução com hipertermoquimioterapia em pacientes com Mesotelioma Peritoneal Maligno. 2019 [cited 2024 Feb 26]; Available from: http://conitec.gov.br/. 27. Quénet F, Elias D, Roca E, Goéré D, Ghouti L, Pocard M, Facy O, Arvieux C, Lorimier G, Pezet D, Marchal F, Loi V, Meeus P, Juzyna B, de Forges H, Paineau J, Glehen O. Cytoreductive surgery plus hyperthermic intraperitoneal chemotherapy versus cytoreductive surgery alone for colorectal peritoneal metastases (PRODIGE 7): a multicentre, randomised, open-label, phase 3 trial. Lancet Volume 22, Issue 2p256-266, February 2021.  
28. Gunderson LL, Sargent DJ, Tepper JE, Wolmark N, O’Connell MJ, Begovic M, et al. Impact of T and N stage and treatment on survival and relapse in adjuvant rectal cancer: A pooled analysis. Journal of Clinical Oncology [Internet]. 2004 Sep 21 [cited 2024 May 7];22(10):1785–96. Available from: https://ascopubs.org/doi/10.1200/JCO.2004.08.173. 29. Heald RJ, Husband EM, Ryall RDH. The mesorectum in rectal cancer surgery—the clue to pelvic recurrence? British Journal of Surgery [Internet]. 2005 Dec 7 [cited 2022 Nov 27];69(10):613–6. Available from: https://academic.oup.com/bjs/article/69/10/613/6186032.  
30. Nagtegaal ID, van de Velde CJH, van der Worp E, Kapiteijn E, Quirke P, van Krieken JHJM. Macroscopic evaluation of rectal cancer resection specimen: Clinical significance of the pathologist in quality control. Journal of Clinical Oncology [Internet]. 2002 Apr 1 [cited 2022 Nov 27];20(7):1729–34. Available from: https://ascopubs.org/doi/10.1200/JCO.2002.07.010. 31. Quirke P, Durdey P, Dixon MF, Williams NS. Local recurrence of rectal adenocarcinoma due to inadequate surgical resection. Histopathological study of lateral tumour spread and surgical excision. Lancet. 1986 Nov 1;2(8514):996–9. 32. Quirke P, Steele R, Monson J, Grieve R, Khanna S, Couture J, et al. Effect of the plane of surgery achieved on local recurrence in patients with operable rectal cancer: a prospective study using data from the MRC CR07 and NCIC-CTG CO16 randomised clinical trial. The Lancet [Internet]. 2009 Mar 7 [cited 2022 Nov 27];373(9666):821–8. Available from: http://www.thelancet.com/article/S0140673609604852/fulltext.  
27  
33. van der Pas MHGM, Haglind E, Cuesta MA, Fürst A, Lacy AM, Hop WCJ, et al. Laparoscopic versus open surgery for rectal cancer (COLOR II): Short-term outcomes of a randomised, phase 3 trial. Lancet Oncol [Internet]. 2013 Mar 1 [cited 2022 Nov 27];14(3):210–8. Available from: http://www.thelancet.com/article/S1470204513700160/fulltext.  
34. Jeong SY, Park JW, Nam BH, Kim S, Kang SB, Lim SB, et al. Open versus laparoscopic surgery for mid-rectal or lowrectal cancer after neoadjuvant chemoradiotherapy (COREAN trial): Survival outcomes of an open-label, non-inferiority, randomised controlled trial. Lancet Oncol [Internet]. 2014 Jun 1 [cited 2022 Nov 27];15(7):767–74. Available from: http://www.thelancet.com/article/S1470204514702050/fulltext.  
35. Martenson JA, Willett CG, Sargent DJ, Mailliard JA, Donohue JH, Gunderson LL, et al. Phase III study of adjuvant chemotherapy and radiation therapy compared with chemotherapy alone in the surgical adjuvant treatment of colon cancer: Results of intergroup protocol 0130. Journal of Clinical Oncology. 2004 Sep 21;22(16):3277–83.  
36. Vendrely V, Rivin Del Campo E, Modesto A, Jolnerowski M, Meillan N, Chiavassa S, et al. Rectal cancer radiotherapy. Cancer/Radiothérapie. 2022 Feb 1;26(1–2):272–8.  
37. Glynne-Jones R, Wyrwicz L, Tiret E, Brown G, Rödel C, Cervantes A, et al. Rectal cancer: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up†. Annals of Oncology [Internet]. 2017 Jul 1 [cited 2022 Nov 22];28:iv22–40. Available from: http://www.annalsofoncology.org/article/S0923753419421522/fulltext.  
38. Benson AB, Venook AP, Al-Hawary MM, Azad N, Chen YJ, Ciombor KK, et al. Rectal Cancer, Version 2.2022, NCCN Clinical Practice Guidelines in Oncology. Journal of the National Comprehensive Cancer Network [Internet]. 2022 Oct 1 [cited 2024 May 7];20(10):1139–67. Available from: https://jnccn.org/view/journals/jnccn/20/10/article-p1139.xml.  
39. You YN, Hardiman KM, Bafford A, Poylin V, Francone TD, Davis K, et al. The American Society of Colon and Rectal Surgeons Clinical Practice Guidelines for the Management of Rectal Cancer. Dis Colon Rectum [Internet]. 2020 Sep 1 [cited 2022 Nov 22];63(9):1191–222. Available from: https://journals.lww.com/dcrjournal/Fulltext/2020/09000/The_American_Society_of_Colon_and_Rectal_Surgeons.6.aspx.  
40. Wo JY, Anker CJ, Ashman JB, Bhadkamkar NA, Bradfield L, Chang DT, et al. Radiation Therapy for Rectal Cancer: Executive Summary of an ASTRO Clinical Practice Guideline. Pract Radiat Oncol. 2021 Jan 1;11(1):13–25.  
41. Hashiguchi Y, Muro K, Saito Y, Ito Y, Ajioka Y, Hamaguchi T, et al. Japanese Society for Cancer of the Colon and Rectum (JSCCR) guidelines 2019 for the treatment of colorectal cancer. Int J Clin Oncol [Internet]. 2020 Jan 1 [cited 2022 Nov 22];25(1):1. Available from: /pmc/articles/PMC6946738/.  
42. Akgül Ö, Çetinkaya E, Ersöz Ş, Tez M. Role of surgery in colorectal cancer liver metastases. World J Gastroenterol [Internet]. 2014 May 28 [cited 2022 Sep 25];20(20):6113–22. Available from: https://www.wjgnet.com/10079327/full/v20/i20/6113.htm.  
43. NICE. NICE Guidance: Radiofrequency ablation for colorectal liver metastases . Interventional procedures guidance [IPG327]. 2009;  
44. NICE. NICE Guidance: Radiofrequency-assisted liver resection . Interventional procedures guidance [IPG211]. 2007;  
45. Nieuwenhuizen S, Dijkstra M, Puijk RS, Geboers B, Ruarus AH, Schouten EA, et al. Microwave Ablation, Radiofrequency Ablation, Irreversible Electroporation, and Stereotactic Ablative Body Radiotherapy for Intermediate Size (3–5 cm) Unresectable Colorectal Liver Metastases: a Systematic Review and Meta-analysis. Curr Oncol Rep [Internet]. 2022 Jun 1 [cited 2022 Nov 22];24(6):793. Available from: /pmc/articles/PMC9054902/.  
46. Meijerink MR, Puijk RS, van Tilborg AAJM, Henningsen KH, Fernandez LG, Neyt M, et al. Radiofrequency and Microwave Ablation Compared to Systemic Chemotherapy and to Partial Hepatectomy in the Treatment of Colorectal Liver Metastases: A Systematic Review and Meta-Analysis. Cardiovasc Intervent Radiol [Internet]. 2018 Aug 1 [cited 2022 Nov 22];41(8):1189. Available from: /pmc/articles/PMC6021475/.  
28  
47. Gavriilidis P, Roberts KJ, de’Angelis N, Aldrighetti L, Sutcliffe RP. Recurrence and survival following microwave, radiofrequency ablation, and hepatic resection of colorectal liver metastases: A systematic review and network meta-analysis. Hepatobiliary & Pancreatic Diseases International. 2021 Aug 1;20(4):307–14.  
48. Puijk RS, Dijkstra M, van den Bemd BAT, Ruarus AH, Nieuwenhuizen S, Geboers B, et al. Improved Outcomes of Thermal Ablation for Colorectal Liver Metastases: A 10-Year Analysis from the Prospective Amsterdam CORE Registry (AmCORE). Cardiovasc Intervent Radiol [Internet]. 2022 Aug 1 [cited 2022 Dec 1];45(8):1074. Available from: /pmc/articles/PMC9307533/.  
49. Puijk RS, Ruarus AH, Vroomen LGPH, van Tilborg AAJM, Scheffer HJ, Nielsen K, de Jong MC, de Vries JJJ, Zonderhuis BM, Eker HH, Kazemier G, Verheul H, van der Meijs BB, van Dam L, Sorgedrager N, Coupé VMH, van den Tol PMP, Meijerink MR; COLLISION Trial Group. Colorectal liver metastases: surgery versus thermal ablation (COLLISION) - a phase III single-blind prospective randomized controlled trial. BMC Cancer 2018 Aug 15;18(1):821.  
50. Brasil. Ministério da Saúde. Manual de bases técnicas da oncologia - SIA/SUS - Sistema de Informações Ambulatoriais. Brasília; 2021.  
51. Patel A, Spychalski P, Corrao G, Jereczek-Fossa BA, Glynne-Jones R, Garcia-Aguilar J, et al. Neoadjuvant short-course radiotherapy with consolidation chemotherapy for locally advanced rectal cancer: a systematic review and meta-analysis. Acta Oncol (Madr) [Internet]. 2021 [cited 2022 Nov 27];60(10):1308–16. Available from: https://www.tandfonline.com/doi/abs/10.1080/0284186X.2021.1953137.  
52. Fokas E, Schlenska-Lange A, Polat B, Klautke G, Grabenbauer GG, Fietkau R, et al. Chemoradiotherapy Plus Induction or Consolidation Chemotherapy as Total Neoadjuvant Therapy for Patients With Locally Advanced Rectal Cancer: Long-term Results of the CAO/ARO/AIO-12 Randomized Clinical Trial. JAMA Oncol [Internet]. 2022 Jan 1 [cited 2022 Nov 27];8(1):e215445–e215445. Available from: https://jamanetwork.com/journals/jamaoncology/fullarticle/2786405.  
53. Lin H, Wang L, Zhong X, Zhang X, Shao L, Wu J. Meta-analysis of neoadjuvant chemotherapy versus neoadjuvant chemoradiotherapy for locally advanced rectal cancer. World J Surg Oncol [Internet]. 2021 Dec 1 [cited 2022 Nov 27];19(1):1– 10. Available from: https://wjso.biomedcentral.com/articles/10.1186/s12957-021-02251-0.  
54. Allegra CJ, Yothers G, O’connell MJ, Beart RW, Wozniak TF, Pitot HC, et al. Neoadjuvant 5-FU or Capecitabine Plus Radiation With or Without Oxaliplatin in Rectal Cancer Patients: A Phase III Randomized Clinical Trial. JNCI: Journal of the National Cancer Institute [Internet]. 2015 Nov 1 [cited 2022 Nov 27];107(11):djv248. Available from: https://academic.oup.com/jnci/article/107/11/djv248/2457689.  
55. Gérard JP, Azria D, Gourgou-Bourgade S, Martel-Laffay I, Hennequin C, Etienne PL, et al. Comparison of two neoadjuvant chemoradiotherapy regimens for locally advanced rectal cancer: Results of the phase III trial accord 12/0405Prodige 2. Journal of Clinical Oncology. 2010 Apr 1;28(10):1638–44.  
56. Brændengen M, Tveit KM, Berglund Å, Birkemeyer E, Frykholm G, Påhlman L, et al. Randomized phase III study comparing preoperative radiotherapy with chemoradiotherapy in nonresectable rectal cancer. Journal of Clinical Oncology. 2008 Sep 21;26(22):3687–94.  
57. Conroy T, Bosset JF, Etienne PL, Rio E, François É, Mesgouez-Nebout N, et al. Neoadjuvant chemotherapy with FOLFIRINOX and preoperative chemoradiotherapy for patients with locally advanced rectal cancer (UNICANCER-PRODIGE 23): a multicentre, randomised, open-label, phase 3 trial. Lancet Oncol [Internet]. 2021 May 1 [cited 2024 Oct 22];22(5):702– 15. Available from: http://www.thelancet.com/article/S1470204521000796/fulltext.  
58. Garcia-Aguilar J, Patil S, Gollub MJ, Kim JK, Yuval JB, Thompson HM, et al. Organ Preservation in Patients with Rectal Adenocarcinoma Treated with Total Neoadjuvant Therapy. Journal of Clinical Oncology [Internet]. 2022 Apr 1 [cited 2024 Oct 22];18. Available from: https://ascopubs.org/doi/10.1200/JCO.22.00032.  
29  
59. Verheij FS, Omer DM, Williams H, Lin ST, Qin LX, Buckley JT, et al. Long-Term Results of Organ Preservation in Patients with Rectal Adenocarcinoma Treated with Total Neoadjuvant Therapy: The Randomized Phase II OPRA Trial. Journal of Clinical Oncology [Internet]. 2024 Feb 10 [cited 2024 Oct 22];42(5):500–6. Available from: https://ascopubs.org/doi/10.1200/JCO.23.01208.  
60. Schrag D, Shi Q, Weiser MR, Gollub MJ, Saltz LB, Musher BL, et al. Preoperative Treatment of Locally Advanced Rectal Cancer. New England Journal of Medicine [Internet]. 2023 Jul 27 [cited 2024 Oct 22];389(4):322–34. Available from: https://www.nejm.org/doi/full/10.1056/NEJMoa2303269.  
61. Bahadoer RR, Dijkstra EA, van Etten B, Marijnen CAM, Putter H, Kranenbarg EMK, et al. Short-course radiotherapy followed by chemotherapy before total mesorectal excision (TME) versus preoperative chemoradiotherapy, TME, and optional adjuvant chemotherapy in locally advanced rectal cancer (RAPIDO): a randomised, open-label, phase 3 trial. Lancet Oncol  
[Internet]. 2021 Jan 1 [cited 2024 Oct 22];22(1):29–42. Available from: http://www.thelancet.com/article/S1470204520305556/fulltext.  
62. Zhang X, Ding R, Li JS, Wu T, Shen ZH, Li SS, et al. Efficacy and safety of the “watch-and-wait” approach for rectal cancer with clinical complete response after neoadjuvant chemoradiotherapy: a meta-analysis. Surgical Endoscopy 2021 36:4 [Internet]. 2022 Jan 3 [cited 2022 Nov 27];36(4):2233–44. Available from: https://link.springer.com/article/10.1007/s00464021-08932-x.  
63. Yu G, Lu W, Jiao Z, Qiao J, Ma S, Liu X. A meta-analysis of the watch-and-wait strategy versus total mesorectal excision for rectal cancer exhibiting complete clinical response after neoadjuvant chemoradiotherapy. World J Surg Oncol  
[Internet]. 2021 Dec 1 [cited 2022 Nov 27];19(1):1–12. Available from: https://wjso.biomedcentral.com/articles/10.1186/s12957-021-02415-y.  
64. Cervantes A, Adam R, Roselló S, Arnold D, Normanno N, Taïeb J, et al. Metastatic colorectal cancer: ESMO Clinical Practice Guideline for diagnosis, treatment and follow-up ☆ . Annals of Oncology [Internet]. 2023 Jan 1 [cited 2024 Feb 26];34(1):10–32. Available from: http://www.annalsofoncology.org/article/S0923753422041928/fulltext.  
65. Nozawa H, Kitayama J, Sunami E, Saito S, Kanazawa T, Kazama S, et al. FOLFOX as adjuvant chemotherapy after curative resection of distant metastases in patients with colorectal cancer. Oncology [Internet]. 2011 Jun [cited 2022 Nov 27];80(1–2):84–91. Available from: https://pubmed.ncbi.nlm.nih.gov/21677451/.  
66. Andreou A, Kopetz S, Maru DM, Chen SS, Zimmitti G, Brouquet A, et al. Adjuvant chemotherapy with FOLFOX for primary colorectal cancer is associated with increased somatic gene mutations and inferior survival in patients undergoing hepatectomy for metachronous liver metastases. Ann Surg [Internet]. 2012 Oct [cited 2022 Nov 27];256(4):642–50. Available from:  
https://journals.lww.com/annalsofsurgery/Fulltext/2012/10000/Adjuvant_Chemotherapy_With_FOLFOX_for_Primary.11.asp  
x.  
67. Kwon Y, Park M, Jang M, Yun S, Kim WK, Kim S, et al. Prognosis of stage III colorectal carcinomas with FOLFOX adjuvant chemotherapy can be predicted by molecular subtype. Oncotarget [Internet]. 2017 [cited 2022 Nov 27];8(24):39367– 81. Available from: https://pubmed.ncbi.nlm.nih.gov/28455965/.  
68. Schmoll HJ, Tabernero J, Maroun J, de Braud F, Price T, van Cutsem E, et al. Capecitabine plus oxaliplatin compared with fluorouracil/folinic acid as adjuvant therapy for stage III colon cancer: Final Results of the NO16968 randomized controlled phase III trial. Journal of Clinical Oncology. 2015 Nov 10;33(32):3733–40.  
69. Pectasides D, Karavasilis V, Papaxoinis G, Gourgioti G, Makatsoris T, Raptou G, et al. Randomized phase III clinical trial comparing the combination of capecitabine and oxaliplatin (CAPOX) with the combination of 5-fluorouracil, leucovorin and oxaliplatin (modified FOLFOX6) as adjuvant therapy in patients with operated high-risk stage II or stage III colorectal  
30  
cancer. BMC Cancer [Internet]. 2015 Dec 12 [cited 2022 Nov 27];15(1):1–11. Available from: https://bmccancer.biomedcentral.com/articles/10.1186/s12885-015-1406-7.  
70. Kerr RS, Love S, Segelov E, Johnstone E, Falcon B, Hewett P, et al. Adjuvant capecitabine plus bevacizumab versus capecitabine alone in patients with colorectal cancer (QUASAR 2): an open-label, randomised phase 3 trial. Lancet Oncol [Internet]. 2016 Nov 1 [cited 2022 Nov 27];17(11):1543–57. Available from: http://www.thelancet.com/article/S1470204516301723/fulltext. 71. Sharif S, O’Connell MJ, Yothers G, Lopa S, Wolmark N. FOLFOX and FLOX Regimens for the Adjuvant Treatment of Resected Stage II and III Colon Cancer. Cancer Invest [Internet]. 2008 Nov [cited 2022 Nov 27];26(9):956. Available from: /pmc/articles/PMC2588473/.  
72. Demir L, Somali I, Oktay Tarhan M, Erten C, Ellidokuz H, Can A, et al. The toxicity and efficacy of Nordic-FLOX regimen as adjuvant treatment of stage III colon cancer. J BUON. 2011;16(4):682–8. 73. Twelves C, Wong A, Nowacki MP, Abt M, Burris III H, Carrato A, et al. Capecitabine as Adjuvant Treatment for Stage III Colon Cancer. https://doi.org/101056/NEJMoa043116 [Internet]. 2005 Jun 30 [cited 2022 Nov 27];352(26):2696–704. Available from: https://www.nejm.org/doi/full/10.1056/nejmoa043116. 74. Koca D, Oztop I, Yavuzsen T, Ellidokuz H, Yilmaz U. Evaluation of the efficacy of modified De Gramont and modified FOLFOX4 regimens for adjuvant therapy of locally advanced rectal cancer. Asian Pac J Cancer Prev. 2011;12(12):3181–6. 75. Wilkinson NW, Yothers G, Lopa S, Costantino JP, Petrelli NJ, Wolmark N. Long Term Survival Results of Surgery Alone versus Surgery plus 5-Fluorouracil and Leucovorin for Stage II and Stage III Colon Cancer: Pooled Analysis of NSABP C-01 through C-05 Baseline from Which to Compare Modern Adjuvant Trials. Ann Surg Oncol [Internet]. 2010 Apr [cited 2022 Nov 27];17(4):959. Available from: /pmc/articles/PMC2935319/. 76. Ivesono T, Boydo KA, Kerro RS, Robles-Zuritao J, Saunders MP, Briggso AH, et al. 3-month versus 6-month adjuvant chemotherapy for patients with high-risk stage II and III colorectal cancer: 3-year follow-up of the SCOT non-inferiority RCT. Health Technol Assess [Internet]. 2019 Dec 1 [cited 2022 Nov 27];23(64):1–88. Available from: https://pubmed.ncbi.nlm.nih.gov/31852579/.  
77. Rocha Filho D, Prolla G, Oliveira M, Braghiroli M, Riechelmann R. Cólon: doença localizada. Diretrizes de tratamentos oncológicos recomendados pela Sociedade Brasileira de Oncologia Clínica. 2021. 78. Wu Z, Deng Y. Capecitabine Versus Continuous Infusion Fluorouracil for the Treatment of Advanced or Metastatic Colorectal Cancer: a Meta-analysis. Current Treatment Options in Oncology 2018 19:12 [Internet]. 2018 Nov 27 [cited 2022 Nov 27];19(12):1–22. Available from: https://link.springer.com/article/10.1007/s11864-018-0597-y. 79. Brasil. Ministério da Saúde. Portaria SCTIE/MS No 68, DE 18 de julho de 2022 [Internet]. Brasília, DF; 2022 p. 128– 128. Available from: http://antigo-conitec.saude.gov.br/images/Relatorios/Portaria/2022/20220720_CPs-n.-48-e-49-e-PortariaSCTIE-n.-68.pdf.  
80. Brasil. Ministério da Saúde. Relatório de Recomendação: Cetuximabe em combinação com FOLFIRI ou FOLFOX no tratamento do câncer colorretal metastático KRAS selvagem com metástases hepáticas exclusivas [Internet]. 2013 [cited 2024 Feb 26]. Available from: http://antigo-conitec.saude.gov.br/images/Incorporados/Cetuximabe-Colorretal-final.pdf.  
81. Brasil. Ministério da Saúde. Relatório de Recomendação: Cetuximabe para o tratamento em primeira linha de pacientes com câncer colorretal metastático com expressão de EGFR, sem mutação do gene RAS [Internet]. 2015 [cited 2024 Feb 26]. Available from: http://antigo-conitec.saude.gov.br/images/Relatorios/2015/Relatorio_Cetuximabe_Colorretal_final.pdf. 82. Brasil. Ministério da Saúde. Relatório de Recomendação: Cetuximabe para o tratamento do câncer colorretal metastático RAS selvagem com doença limitada ao fígado em primeira linha [Internet]. 2018 [cited 2024 Feb 26]. Available from: http://antigo-conitec.saude.gov.br/images/Relatorios/2018/Relatorio_Cetuximabe_CAColorretal_Metastatico.pdf.  
31  
83. Brasil. Ministério da Saúde. Relatório de recomendação 863- Pembrolizumabe em primeira linha de tratamento em indivíduos com câncer de cólon ou reto metastático [Internet]. 2023 [cited 2024 Jul 21]. Available from: https://www.gov.br/conitec/pt-br/midias/relatorios/2023/20231229_relatorio_863_pembrolizumabe_cancer_colon_reto.pdf. 84. Brasil. Ministério da Saúde. Pembrolizumabe em primeira linha de tratamento em indivíduos com câncer de cólon ou reto metastático [Internet]. 2023 [cited 2024 Feb 22]. Available from: https://www.gov.br/conitec/ptbr/midias/relatorios/2023/20231229_relatorio_863_pembrolizumabe_cancer_colon_reto.pdf. 85. Chan DL, Alzahrani NA, Morris DL, Chua TC. Systematic review and meta-analysis of hepatic arterial infusion chemotherapy as bridging therapy for colorectal liver metastases. Surg Oncol. 2015 Sep 1;24(3):162–71. 86. Lee SW, Jho HJ, Baek JY, Shim EK, Kim HM, Ku JY, et al. Outpatient Palliative Care and Aggressiveness of End-ofLife Care in Patients with Metastatic Colorectal Cancer. https://doi.org/101177/1049909116689459 [Internet]. 2017 Jan 19 [cited 2022 Nov 27];35(1):166–72. Available from: https://journals.sagepub.com/doi/10.1177/1049909116689459?url_ver=Z39.882003&rfr_id=ori%3Arid%3Acrossref.org&rfr_dat=cr_pub++0pubmed.  
87. Delisle ME, Ward MAR, Helewa RM, Hochman D, Park J, McKay A. Timing of Palliative Care in Colorectal Cancer Patients: Does It Matter? Journal of Surgical Research [Internet]. 2019 Sep 1 [cited 2022 Nov 27];241:285–93. Available from: http://www.journalofsurgicalresearch.com/article/S0022480419301969/fulltext.  
88. Bischoff KE, Zapata C, Sedki S, Ursem C, O’Riordan DL, England AE, et al. Embedded palliative care for patients with metastatic colorectal cancer: a mixed-methods pilot study. Supportive Care in Cancer 2020 28:12 [Internet]. 2020 Apr 14 [cited 2022 Nov 27];28(12):5995–6010. Available from: https://link.springer.com/article/10.1007/s00520-020-05437-6.  
89. Agência Nacional de Vigilância Sanitária. Consultas - Bulário eletrônico: Eloxatin (oxaliplatina) [Internet]. [cited 2024 May 7]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?numeroRegistro=183260426.  
90. Agência Nacional de Vigilância Sanitária. Consultas - Bulário eletrônico: Camptosar (irinotecano) [Internet]. [cited 2024 May 7]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?numeroRegistro=121100434.  
91. Agência Nacional de Vigilância Sanitária. Consultas - Bulário eletrônico: Flaudfluor (fluoruracila) [Internet]. [cited 2024 May 7]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?numeroRegistro=100330139. 92. Agência Nacional de Vigilância Sanitária. Consultas - Bulário eletrônico: Xeloda (capecitabina) [Internet]. [cited 2024 May 7]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?numeroRegistro=189770004. 93. Saif MW, Reardon J. Management of oxaliplatin-induced peripheral neuropathy. Ther Clin Risk Manag [Internet]. 2005 Dec [cited 2022 Nov 24];1(4):249. Available from: /pmc/articles/PMC1661634/. 94. Maroun JA, Anthony LB, Blais N, Burkes R, Dowden SD, Dranitsaris G, et al. Prevention and management of chemotherapy-induced diarrhea in patients with colorectal cancer: a consensus statement by the Canadian Working Group on Chemotherapy-Induced Diarrhea. Current Oncology [Internet]. 2007 [cited 2022 Nov 24];14(1):13. Available from: /pmc/articles/PMC1891194/.  
95. Eisenhauer EA, Therasse P, Bogaerts J, Schwartz LH, Sargent D, Ford R, et al. New response evaluation criteria in solid tumours: Revised RECIST guideline (version 1.1). Eur J Cancer [Internet]. 2009 Jan 1 [cited 2022 Nov 24];45(2):228–47. Available from: http://www.ejcancer.com/article/S0959804908008733/fulltext.  
96. Pita-Fernández S, Alhayek-Aí M, González-Martín C, López-Calviño B, Seoane-Pillado T, Pértega-Díaz S. Intensive follow-up strategies improve outcomes in nonmetastatic colorectal cancer patients after curative surgery: A systematic review and meta-analysis. Annals of Oncology [Internet]. 2015 Apr 1 [cited 2022 Nov 24];26(4):644–56. Available from: http://www.annalsofoncology.org/article/S0923753419314449/fulltext.  
97. Benson AB, Venook AP, Al-Hawary MM, Arain MA, Chen YJ, Ciombor KK, et al. Colon Cancer, Version 2.2021, NCCN Clinical Practice Guidelines in Oncology. Journal of the National Comprehensive Cancer Network [Internet]. 2021 Mar 2 [cited 2022 Nov 27];19(3):329–59. Available from: https://jnccn.org/view/journals/jnccn/19/3/article-p329.xml.  
32

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **1.        Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Adenocarcinoma de cólon e reto, contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia em Saúde (DGITS/SCTIE/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações. Participantes que possuíssem conflito de interesse relevante associado a uma ou mais questões do documento seriam impossibilitados de participar da elaboração e redação de questões específicas, sem impedimento de participar da discussão das demais questões, incluindo votação caso não fosse obtido consenso.  
O processo de elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Adenocarcinoma de cólon e reto iniciou-se com a demanda pelo Ministério da Saúde (MS) e as reuniões de pré-escopo, de escopo e de priorização de perguntas foram realizadas entre 14/09/2021 e 15/12/2021.  
A dinâmica da reunião de escopo foi conduzida com base nas DDT publicadas por meio da Portaria SAS/MS nº 958, de 26 de setembro de 2014. Cada seção foi discutida entre o Grupo Elaborador e demais participantes da reunião de escopo, com o objetivo principal de revisar as condutas diagnósticas e identificar tecnologias em saúde que poderiam ser consideradas nas recomendações do Protocolo.  
Os trabalhos foram conduzidos considerando as Diretrizes Metodológicas para elaboração de PCDT. Definiu-se que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não demandariam questões de pesquisa definidas por serem práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Foram estabelecidas as seguintes questões de pesquisa:  
- Para pacientes com diagnóstico de câncer de cólon e reto avançado ou metastático, o tratamento com pembrolizumabe é eficaz e seguro quando comparado aos esquemas com a quimioterapia padrão (ácido folínico + fluorouracila + oxaliplatina [FOLFOX] ou ácido folínico + fluorouracila + irinotecano [FOLFIRI]) associado ou não à cetuximabe ou bevacizumabe ou placebo?  
- Para pacientes com diagnóstico de câncer de cólon e reto com metástase hepática irressecável OU ressecável com alto risco cirúrgico, o tratamento com ablação por radiofrequência ou microondas é eficaz e seguro quando comparado à quimioterapia padrão?

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **<u>Colaboração externa</u>** -->
O Protocolo foi atualizado pela equipe do Hospital Alemão Oswaldo Cruz.  
33

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **<u>Declaração e Manejo de Conflitos de Interesse</u>** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A -.** Questionário de conflitos de interesse para diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos be|nefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz<br> <br>|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino<br> <br>|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias<br> <br>|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área<br> <br>|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe<br> <br>|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro<br> <br>|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?<br> <br>|<br>(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?<br> <br>|<br>(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?<br> <br>|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetad<br>na elaboração ou revisão da diretriz?|os pela sua atividade|
|a) Instituição privada com ou sem fins lucrativos<br> <br>|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental<br> <br>|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro<br> <br>|(   ) Sim<br>(   ) Não|
|d) Partido político<br> <br>|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho<br> <br>|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse<br> <br>|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?<br> <br>|(   ) Sim<br>(   ) Não|  
34  
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|---|---|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|<br>(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar sua|<br>(   ) Sim|
|objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **3.        Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Adenocarcinoma de Cólon e Reto foi apresentada na 115ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 14 de maio de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 130ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: Consulta pública -->
A Consulta Pública nº 34/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas do Adenocarcinoma de cólon e reto, foi realizada entre os dias 18/06/2024 a 08/07/2024. Foram recebidas 33 contribuições, que podem ser verificadas em:  
https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/contribuicoes-da-cp-34-2024-pcdt-do-adenocarcinomade-colon-e-reto.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **4.        Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ou PIRO (Figura A).  
**Figura A** - Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
PP *Populacdo ou condic¢do clinica<br>*Intervengdo, no caso de estudos experimentais<br>*Fator de exposic¢do, em caso de estudos observacionais<br>*Teste indice, nos casos de estudos de acurdcia diagndstica<br>Controle, de acordo com tratamento/niveis de exposicdo do fator/exames<br>disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
35  
Ao final do processo de planejamento do PCDT, duas questões de pesquisa foram definidas. Para responder cada questão foram elaboradas revisões sistemáticas ou atualizadas revisões sistemáticas existentes, avaliações econômicas e análises de impacto orçamentário, os quais subsidiaram as recomendações finais da Conitec.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **ou reto metastático comparado às opções usuais na prática clínica?** -->
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de pembrolizumabe para o tratamento de primeira linha de câncer de cólon e reto metastático, conforme Relatório de Recomendação nº 863/2023, disponível em:  
https://www.gov.br/conitec/pt-br/midias/relatorios/2023/20231229_relatorio_863_pembrolizumabe_cancer_colon_reto.pdf  
A estrutura PICO para esta pergunta foi:  
|PICO|Pergunta|
|---|---|
|P|Adultos com câncer de cólon ou reto metastático com instabilidade de microssatélites (MSI) e deficiência de enzimas<br>de reparo (dMMR) do DNA, em primeira linha de tratamento|
|I|Pembrolizumabe|
|C|Qualquer opção usual na prática clínica, a saber: esquemas antineoplásicos a base de fluorouracila (5-FU), ácido<br>folínico, capecitabina, oxaliplatina, irinotecano, bevacizumabe, cetuximabe, encorafenibe, panitumumabe,<br>entrectinibe, trastuzumabe, ramucirumabe, aflibercepte, larotrectinibe, nivolumabe, ipilimumabe, regorafenibe,<br>lapatinibe, pertuzumabe e trifluridina/tipiracila.|
|O|Primários (críticos): sobrevida global, sobrevida livre de progressão, eventos adversos grau ≥ 3<br>Secundários (importantes): taxa de resposta objetiva (resposta completa ou parcial pelos critérios RECIST); duração<br>da resposta; qualidade de vida; eventos adversos de qualquer grau|  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 863/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **QUESTÃO 2: Para adultos com diagnóstico de câncer de cólon e reto com metástase hepática irressecável ou ressecável com alto risco cirúrgico, o tratamento com ablação térmica associado ou não à quimioterapia é eficaz, efetivo e seguro quando comparado ao tratamento com quimioterapia?** -->
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS da ablação térmica para o tratamento de metástase hepática irressecável ou ressecável com alto risco cirúrgico, do câncer de cólon e reto, conforme Relatório de Recomendação nº 881/2024, disponível em:  
https://www.gov.br/conitec/pt-br/midias/relatorios/2024/20240307_Relatrio_881_abalaao_termica_cancer_colorretal_metastase_hepatica.pdf.  
A estrutura PICO para esta pergunta foi:  
|PICO|Pergunta|
|---|---|
|P|Adultos com câncer de cólon ou reto com metástase hepática irressecável ou ressecável com alto risco cirúrgico|
|I|Método ablativo térmico: radiofrequência ou micro-ondas (combinados ou não à quimioterapia)|
|C|Quimioterapia|
|O|Primários: sobrevida global, e sobrevida livre de progressão.|  
36  
Secundários: controle local; operabilidade (ressecabilidade); taxa de resposta objetiva (RECIST ou outros); taxa de recorrência no local de ablação; qualidade de vida; pacientes com ao menos um evento adverso grave; pacientes com ao menos um evento adverso geral

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: Métodos e resultados da busca: -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 881/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório (realizada em 02 de agosto de 2023) foi considerada recente.  
Alteração do formato da diretriz  
O objetivo desta etapa foi incluir orientações sobre os esquemas quimioterápicos a serem preconizados pelo Sistema Único de Saúde. Para identificá-los, foi realizado um levantamento do tratamento medicamentoso (quimioterapia) preconizado em três diretrizes clínicas e em dois protocolos de unidades prestadoras de serviço ao SUS, quais sejam:  
- Diretrizes da Sociedade Brasileira de Oncologia Clínica (SBOC) 2023;  
- Diretrizes da European Society for Medical Oncology (ESMO) 2022;  
- Diretriz da National Comprehensive Cancer Network (NCCN) 2024;  
- Instituto do Câncer do Estado de São Paulo (ICESP) 3ª edição;  
- Instituto Nacional do Câncer (INCA) 2022.  
Após o levantamento dos medicamentos preconizados por cada diretriz e seus critérios de uso, os dados foram apresentados a um painel de especialistas convidados, a fim de auxiliar a discussão.  
A reunião para discussão ocorreu, em caráter virtual, em 06 de maio de 2024. Não foram considerados medicamentos que não possuíam registro válido pela Anvisa, que não foram avaliados pela Conitec para a indicação ou que, após avaliação pela Conitec, receberam recomendação desfavorável à sua incorporação ao SUS.  
Por fim, a proposta de PCDT foi revisada e as informações oriundas da discussão com o painel de especialistas foram incluídas.

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **PROTOCOLOS DE QUIMIOTERAPIA** -->
|Protocolo|Descrição|
|---|---|
|CALPOX|Capecitabina + oxaliplatina|
|FOLFOX|Ácido folínico + fluorouracila + oxaliplatina|
|FOLFIRI|Ácido folínico + fluorouracila + irinotecano|
|FOLFOXIRI|Ácido folínico + fluorouracila + oxaliplatina + irinotecano|
|FLOX|Oxaliplatina, ácido folínico e fluorouracil|  
37  
**APÊNDICE 3**

---

<!-- METADADOS: doenca: Adenocarcinoma de Cólon e de Reto | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|Número do Relatório da||Tecnologias avaliadas pela Co|nitec|
|---|---|---|---|
|diretriz clínica (Conitec) ou|<br>Principais alterações|Incorporação ou alteração do||
|<br>Portaria de Publicação|<br>|<br>uso no SUS|<br>Não incorporação ou não alteração no SUS|
|Relatório de Recomendação<br>nº 944/2024|<br>Atualização do texto<br>Alteração do formato<br>do documento para<br>PCDT|<br> <br>Ablação<br>térmica<br>para<br>o<br>tratamento do câncer de cólon<br>e reto com metástase hepática<br>irressecável ou ressecável com<br>alto risco cirúrgico [Portaria<br>SECTICS/MS<br>nº<br>06/2024<br>Relatório de recomendação nº<br>881/2024]|<br> <br> <br> <br> <br> <br> <br>Pembrolizumabe em primeira linha para<br>tratamento de câncer de cólon e reto<br>metastático<br>e<br>alta<br>instabilidade<br>de<br>microssatélite. [Portaria SECTICS/MS nº 74,<br>de 28/12/2023; Relatório de recomendação<br>nº863/2023]<br>Anticorpos<br>monoclonais<br>(bevacizumabe,<br>cetuximabe, panitumumabe) associados à<br>quimioterapia no tratamento de primeira<br>linha do câncer colorretal metastático<br>[Portaria SCTIE/MS nº 68, de 20/07/2022;<br>Relatório de recomendação nº 754/2022]<br>Cetuximabe para o tratamento do câncer<br>colorretal metastático RAS selvagem com<br>doença limitada ao fígado em primeira linha<br>[Portaria SCTIE /MS nº 04, de 25/01/2018;<br>Relatório de recomendação nº 324/2018]<br>Cetuximabe para o tratamento em primeira<br>linha de pacientes com câncer colorretal<br>metastático com expressão de EGFR, sem<br>mutação do gene RAS [Portaria SCTIE /MS<br>nº<br>64,<br>de<br>29/10/2015;<br>Relatório<br>de<br>recomendação nº 181/2015]|
|Portaria SAS nº 958, de<br>26/09/2014|<br>Primeira versão do<br>documento.|PET-CT<br>na<br>detecção<br>de<br>metástase de câncer colorretal,<br>exclusivamente<br>hepática<br>e<br>potencialmente<br>ressecável<br>[Portaria SCTIE/MS nº 8, de<br>23/04/2014;<br>Relatório<br>de<br>recomendação nº106/2014]|<br> <br> <br> <br> <br> <br>Cetuximabe em combinação com FOLFIRI<br>ou FOLFOX no tratamento do câncer<br>colorretal metastático KRAS selvagem com<br>metástases hepáticas exclusivas irressecáveis<br>[Portaria SCTIE/MS nº 56, de 11/12/2013;<br>Relatório de recomendação nº79/2013]|  
38

---

