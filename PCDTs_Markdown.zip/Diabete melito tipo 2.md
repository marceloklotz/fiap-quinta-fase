<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: Geral -->
Torna pública a decisão de atualizar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas do Diabete Melito Tipo 2.  
A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe confere o art. 68 do Decreto nº 11.798, de 28 de novembro de 2023, e do disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica atualizado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas do Diabete Melito Tipo 2.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/ptbr.  
Art. 3º Fica revogada a Portaria SECTICS/MS nº 7, de 28 de fevereiro de 2024, publicada no Diário Oficial da União nº 42, de 1º de março de 2024, Seção 1, pág. 85.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: Geral -->
1

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 1. INTRODUÇÃO -->
O diabete melito tipo 2 (DM2) é uma doença metabólica crônica caracterizada pela resistência à insulina, associada à deficiência progressiva de secreção de insulina pelas células beta pancreáticas, além de alterações na secreção de incretinas<sup>1,2</sup> . Na presença de resistência insulínica, há aumento da demanda por insulina, mas sua produção é insuficiente. Inicialmente, as células beta pancreáticas conseguem compensar essa demanda por meio de adaptação funcionais. Porém, a falência progressiva dessas células compromete o controle glicêmico, resultando em hiperglicemia persistente. O esforço secretor contínuo leva à exaustão funcional e à apoptose celular<sup>3,4</sup> .  
Em 2022, a prevalência global do diabetes entre adultos com 18 anos ou mais de idade atingiu 14,1% o que representa mais de 1,1 bilhão de pessoas afetadas em todo o mundo<sup>5</sup> . Destes casos, aproximadamente 95% correspondem ao DM2<sup>6</sup> . No Brasil, os dados são semelhantes, com uma taxa de prevalência estimada em 12,9%, totalizando mais de 26 milhões de indivíduos diagnosticados no país<sup>5</sup> , embora um percentual importante não seja diagnosticado. Segundo o Atlas da Federação Internacional de Diabetes (IDF) de 2025, o Brasil é o sexto país com o maior número de pessoas com a doença e o percentual de pessoas sem diagnóstico chega a 31,9%<sup>7</sup> .  
Os principais fatores de risco para desenvolvimento de DM2 incluem sobrepeso e obesidade (Índice de Massa Corporal - IMC ≥ 25 kg/m²), idade igual ou maior a 35 anos e histórico familiar de diabetes em parente de primeiro grau<sup>8</sup> . Além destes, destacam-se: histórico de doença cardiovascular; pré-diabetes em exame prévio, histórico de diabetes gestacional prévio ou parto de recém-nascido com peso > 4 kg; e modo de vida sedentário<sup>9</sup> .  
Ainda, tem-se como fatores de risco outras condições clínicas associadas ao desenvolvimento de DM2, como: síndrome metabólica, triglicerídeos elevados (≥ 150 mg/dL), colesterol HDL baixo (< 40 mg/dL em homens e < 50 mg/dL em mulheres); dislipidemia (HDLcolesterol < 35 mg/dL ou triglicerídeos > 250 mg/dL), síndrome do ovário policístico (SOP), acantose _nigricans_ , doença hepática gordurosa não alcoólica, hipertensão arterial sistêmica (HAS) e distúrbios do sono, como apneia obstrutiva do sono (AOS) e privação crônica do sono. Adicionalmente, o uso de antipsicóticos atípicos, como clozapina, olanzapina, quetiapina e risperidona, podem desencadear DM2<sup>2</sup> .  
Salienta-se o caráter multifatorial do DM2, que abrange desde predisposições genéticas até a influência significativa de hábitos de vida e fatores ambientais. Os determinantes sociais também impactam as condições de vida e saúde, como padrões alimentares, prática de atividade física, nível de escolaridade, renda, condições de trabalho, moradia, grau de urbanização, entre outros aspectos<sup>10,11</sup> .  
As complicações relacionadas ao DM2, resultantes do controle inadequado da condição, podem ser classificadas em agudas e crônicas. Dentre as complicações agudas, destacam-se a hipoglicemia ou a descompensação hiperglicêmica aguda, que pode resultar em complicações mais graves como cetoacidose diabética e síndrome hiperosmolar hiperglicêmica não cetótica. As complicações crônicas da DM2 incluem as desordens microvasculares devido a alterações patológicas nos capilares, como a doença renal do diabete (DRD), neuropatia diabética e retinopatia diabética, e as alterações macrovasculares que atingem o coração (infarto agudo do miocárdio), o cérebro (acidente vascular cerebral) e os membros inferiores (doença vascular periférica)<sup>12–15</sup> .  
2  
A Atenção Primária à Saúde (APS), como porta de entrada preferencial e ordenadora do cuidado na rede de atenção à saúde, exerce papel fundamental na promoção da saúde, na prevenção de doenças, na identificação de fatores de risco e na detecção precoce, oportunizando, desta forma, a promoção de intervenções oportunas e o encaminhamento adequado para o nível especializado de atenção à saúde quando necessário. O vínculo contínuo com os usuários e a atuação direta no território, princípios e diretrizes basilares da APS, possibilitam uma abordagem longitudinal e integral, favorecendo, por conseguinte, melhores desfechos terapêuticos e o prognóstico dos casos, além de fortalecer a coordenação do cuidado ao longo do tempo.  
O presente Protocolo visa a estabelecer os critérios de rastreamento populacional do DM2, diagnósticos, terapêuticos, exceto cirúrgico<sup>16,17</sup> , e de acompanhamento de indivíduos com idade igual ou maior a 18 anos e DM2, no âmbito do Sistema Único de Saúde (SUS). Além disso, considerando que DM2 tem sido cada vez mais prevalente em crianças e adolescentes, este protocolo aponta critérios para o diagnóstico da doença e aborda o tratamento, de forma a auxiliar o cuidado da doença. Contudo, as recomendações são pontuais, e crianças e adolescentes não estão incluídas no escopo deste Protocolo.  
O público-alvo deste Protocolo são profissionais da saúde envolvidos no cuidado integral desses indivíduos, no âmbito da atenção primária e da atenção especializada à saúde, sem contemplar serviços de urgência, emergência e hospitalares; bem como, gestores da saúde, com vistas a subsidiar as decisões clínicas e otimizar a qualidade do cuidado ofertado a esses pacientes.  
2. METODOLOGIA  
O processo de desenvolvimento desse PCDT seguiu recomendações das Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- E11 - Diabete melito não insulino-dependente  
- E11.2 - Diabete melito não insulino-dependente, com complicações renais  
- E11.3 - Diabete melito não insulino-dependente, com complicações oftálmicas  
- E11.4 - Diabete melito não insulino-dependente, com complicações neurológicas  
- E11.5 - Diabete melito não insulino-dependente, com complicações circulatórias periféricas  
- E11.6 - Diabete melito não insulino-dependente, com outras complicações especificadas  
- E11.7 - Diabete melito não insulino-dependente, com complicações múltiplas  
- E11.8 - Diabete melito não insulino-dependente, com complicações não especificadas  
- E11.9 - Diabete melito não insulino-dependente, sem complicações  
NOTA: Entende-se por diabete melito não insulino-dependente, o diabete melito tipo 2, independentemente do tratamento preconizado (com ou sem insulina exógena), como distinção  
3  
ao diabete melito insulino-dependente que na CID-10 abrange o diabete melito tipo 1, fora do escopo deste Protocolo.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 4. RASTREAMENTO -->
O rastreamento visa a detecção precoce do DM2, ainda em sua fase assintomática, permitindo que intervenções oportunas reduzam o risco de complicações e contribuam para a melhora da qualidade de vida dos indivíduos. Considerando que o DM2 surge de forma insidiosa e assintomática, a adoção de estratégias sistemáticas de rastreamento configura-se como uma importante medida de saúde pública<sup>18</sup> .  
Recomenda-se o rastreamento em todos os indivíduos a partir dos 35 anos de idade, bem como em indivíduos de qualquer idade caso apresentem sobrepeso e obesidade e um ou mais fatores de risco elencados no **Quadro 1** . Além disso, é indicada a realização do rastreamento em todas as gestantes a partir da 24ª semana de gestação, bem como indivíduos vivendo com o Vírus da Imunodeficiência Humana (HIV)/ Síndrome da Imunodeficiência Adquirida (AIDS), com fibrose cística ou submetidas a transplante de órgãos<sup>1</sup> .  
**Quadro 1.** Fatores de risco que indicam rastreamento do diabete melito tipo 2 em indivíduos assintomáticos e não gestantes.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **<u><mark>Fatores de risco</mark></u>** -->
- Parente de primeiro grau com diabetes  
- Histórico de doença cardiovascular  
- Estilo de vida sedentário  Dislipidemia (HDL-colesterol < 35 mg/dL ou triglicerídeos > 250 mg/dL)  
- Síndrome do Ovário Policístico  
- Acantose _nigricans_  
- Doença hepática esteatótica  
- Hipertensão Arterial Sistêmica  
- Pré-diabetes em exame prévio  
- Histórico de diabete melito gestacional ou parto de um bebê com peso > 4 kg  
- Terapia antipsicótica  
- Apneia obstrutiva do sono  
- Privação crônica do sono  
- Ocupação laboral em turno noturno  
- _Finnish Diabetes Risk_ _<u>Score</u>_ <u>(FINDRISC) alto ou muito alto</u>  
**Fonte:** Baseado em Blonde et al. (2022)<sup>9</sup> , Linhas de Cuidado - Diabetes Mellitus tipo 2 (DM2) no adulto (2020)<sup>19</sup> , e Diretriz da Sociedade Brasileira de Diabetes (2024)<sup>2</sup> .  
Sugere-se a utilização do questionário _Finnish Diabetes Risk Score_ (FINDRISC) como ferramenta de estratificação de risco para o desenvolvimento de DM2<sup>2,19</sup> . O escore FINDRISC atribui uma pontuação máxima de 26 pontos, distribuída com base em fatores como idade, IMC, circunferência abdominal, hábitos alimentares, nível de atividade física, histórico familiar e pressão arterial<sup>20</sup> . Os indivíduos são classificados em cinco faixas de risco: baixo (< 7 pontos), levemente elevado (7–11 pontos), moderado (12–14 pontos), alto (15–20 pontos) e muito alto (> 20 pontos)<sup>19</sup> . O escore FINDRISC pode ser encontrado na Linha de Cuidado do Diabetes Mellitus tipo 2 (DM2) no adulto<sup>19</sup> .  
4  
O rastreamento do DM2 deve ser conduzido pela equipe multiprofissional responsável pelo acompanhamento longitudinal do indivíduo, uma vez que em caso positivo são imprescindíveis confirmação diagnóstica, tratamento e acompanhamento. O método preconizado para o rastreamento é a dosagem da glicemia em jejum, podendo incluir a hemoglobina glicada (HbA1c) conforme disponibilidade local<sup>2</sup> . A glicemia de jejum deve ser realizada após um período de 8 horas a 12 horas sem ingestão calórica, sendo valores inferiores a 100 mg/dL considerados normais<sup>21</sup> . Em caso de necessidade de confirmação diagnóstica, deve ser realizado glicemia de jejum, HbA1c ou teste de tolerância à glicose oral (TTGO)<sup>22–24</sup> . O TTGO consiste na administração de 75 g de glicose por via oral com duas medidas de glicose plasmática nos tempos 0 e 120 minutos após a sobrecarga de glicose. A _International Diabetes Federation_ sugeriu a realização do  TTGO na prática clínica com 1 hora de duração<sup>10</sup> . Contudo, este teste não é utilizado como método preferencial, devido ao tempo e desconforto para sua realização, sendo reservado para situações específicas, como na presença de fibrose cística. Já a HbA1c, embora amplamente utilizada e recomendada como o método preferencial na maioria das situações, é uma técnica onerosa e que não considera a variabilidade individual de glicação proteica, o que pode comprometer sua utilização em determinados contextos<sup>23.</sup> .  
Para indivíduos com glicemia de jejum dentro dos parâmetros de normalidade, o rastreamento para DM2 deve ser realizado a cada três anos<sup>2,25</sup> . Por outro lado, aqueles com prédiabetes – glicemia de jejum entre 101 mg/dL e 125 mg/dL – devem receber orientação sobre mudanças nos modos de vida e ser reavaliados anualmente<sup>2</sup> . Além disso, indivíduos com ≥ 3 fatores de risco e que não apresentaram alterações nos exames laboratoriais devem ser submetidos à reavaliação anual<sup>2</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 5. DIAGNÓSTICO -->
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, de raça, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento<sup>26</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 5.1. Manifestações clínicas -->
O DM2 pode permanecer assintomático por longos períodos. Os sinais e sintomas surgem principalmente após os 40 anos de idade, com evolução lenta e riscos de complicações tardias, como desenvolvimento de doenças cardiovasculares, renais, oftalmológicas e neuropáticas<sup>19</sup> Os sinais, sintomas e condições clínicas relacionadas à hiperglicemia, característica da doença, são apresentados no **Quadro 2.**  
**Quadro 2.** Sinais, sintomas e condições clínicas para suspeita de hiperglicemia associados ao diabete melito tipo 2.  
|**Sinais**|**e sintomas clássicos**|
|---|---|
||Poliúria|
||Polidipsia|
||Perdaponderal não intencional|  
5  
|**Sinais**|**e sintomas clássicos**|
|---|---|
|4.1<br>|. Polifagia<br>Noctúria|
|**Sintom**|**as e condições menos específicos**|
|<br><br><br><br><br><br>|Fadiga, fraqueza e letargia<br>Visão turva<br>Prurido vulvar ou cutâneo, balanopostite<br>Doença renal crônica (albuminúria, perda de função renal e evolução para<br>insuficiência renal terminal)<br>Neuropatia (parestesias ou dor nos membros inferiores, formigamento, câimbras)<br>Retinopatia<br>Catarata|
|<br>|Doença aterosclerótica (infarto agudo do miocárdio, acidente vascular encefálico,<br>doença vascular periférica)<br>Infecções de repetição|
|**Fonte:**|Adaptado de Duncan et al., 2022<sup>27</sup>.|

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 5.2. Diagnóstico laboratorial -->
O diagnóstico laboratorial de DM2 baseia-se na detecção de hiperglicemia, por meio dos exames de glicemia plasmática de jejum, glicemia plasmática aleatória, o TTGO e a HbA1c<sup>2</sup> .  
Para o exame de **glicemia plasmática em jejum** , recomenda-se não ingerir bebidas calóricas e alimentos por um período de pelo menos 8 horas antes do teste<sup>2,25</sup> . Ainda, para a obtenção de resultados válidos para esse exame, a glicose deve ser medida na amostra plasmática imediatamente após sua coleta. Se isso não for possível, a amostra de sangue deve ser coletada em um recipiente com inibidores glicolíticos, imediatamente centrifugada para separar o plasma, e congelada até a análise laboratorial<sup>28</sup> . O diagnóstico de DM2 é considerado a partir da glicemia de jejum ≥ 126 mg/dL<sup>2</sup> .  
O exame de **glicemia plasmática aleatória** é realizado em amostra de sangue coletada a qualquer horário do dia, sem a necessidade de jejum. O exame é indicado na presença de sintomas típicos de hiperglicemia (como poliúria, polidipsia e perda de peso inexplicada), nos quais, valores ≥ 200 mg/dL são suficientes para o diagnóstico de DM2, evitando atrasos no tratamento<sup>2</sup> .  
O exame de **TTGO** consiste em uma dosagem da glicemia sanguínea, realizada após uma hora (TTGO-1h) ou duas horas (TTGO-2h) da ingestão de uma solução contento 75 gramas de glicose por via oral<sup>2</sup> . Em relação ao preparo para realização do TTGO, o indivíduo deve ingerir pelo menos 150 gramas de carboidrato por dia, nos três dias prévios ao exame, para conferir confiabilidade na interpretação do resultado desse teste<sup>25</sup> . Restrição de carboidratos pode ocasionar resposta falsamente aumentada à sobrecarga de glicose no TTGO. Para o diagnóstico do DM2 considera-se a glicemia no TTGO - 1h ≥ 209 mg/dL ou a glicemia no TTGO - 2h ≥ a 200 mg/dL<sup>2</sup> .  
Os níveis de **HbA1c** apresentam menor sensibilidade a variações alimentares, situações de estresse e doenças agudas. Por esse motivo, não são necessários preparos específicos para a coleta da amostra destinada à sua dosagem. O diagnóstico de DM2 é considerado se HbA1c ≥ 6,5%<sup>2</sup> .  
De modo geral, todos esses exames utilizados para o diagnóstico do DM2 apresentam limitações metodológicas ou inconveniências<sup>2,25</sup> . A glicemia de jejum requer um período de restrição alimentar, pode ser influenciada por situações agudas ou uso de medicamentos, e  
6  
apresenta menor reprodutibilidade em comparação à HbA1c. O TTGO pode ser considerando um exame mais desconfortável para o paciente, necessita de mais tempo de coleta e é mais oneroso. A HbA1c, apesar de prática e menos afetada por variações diárias, é menos sensível para o diagnóstico, mais onerosa e não considera a variabilidade individual de glicação proteica<sup>2</sup> . Além disso, algumas condições podem interferir na correlação entre os valores da HbA1c e os níveis reais de glicemia **(Quadro 3)** . Desta forma, esses fatores devem ser considerados na interpretação dos resultados dos exames utilizados para diagnóstico de DM2 e pré-diabetes<sup>2</sup> .  
**Quadro 3.** Situações suscetíveis à alteração da correspondência entre hemoglobina glicada e o verdadeiro valor de glicemia.  
|**Sinais **|**e sintomas clássicos**|
|---|---|
|<br>|Anemias agudas<br>Hemoglobinopatias|
|<br>|Variantes de hemoglobina<br>Transfusões sanguíneas|
|<br>|Deficiência de glicose-6-fosfato desidrogenase<br>Uso de alfaepoetina|
|<br><br>|Uso de antirretrovirais<sup>a</sup><br>Insuficiência Renal Crônica<br>Hemodiálise|
|<br>|Alterações fisiológicas referentes ao 2º e 3º trimestres gestacionais<br>Puerpério|  
**Nota:** a. Inibidores da transcriptase reversa análogos de nucleosídeos e inibidores de protease. **Fonte:** Elaboração própria com base nas recomendações da Sociedade Brasileira de Diabetes (2024)<sup>2</sup> e _American Diabetes Association_ (2025)<sup>25</sup> .  
5.3. Critérios para o diagnóstico laboratorial  
O **Quadro 4** apresenta os exames laboratoriais e critérios para a definição de pré-diabetes e o diagnóstico da DM2, em indivíduos com idade igual ou maior a 18 anos.  
**Quadro 4.** Critérios diagnósticos para diabete melito tipo 2 em indivíduos com idade igual ou maior a 18 anos.  
|**Critérios**|**Normal**|**Pré-diabetes**|**DM2**|
|---|---|---|---|
|Glicemiaplasmática dejejum(mg/dL)*|< 100|100- 125|≥126|
|Glicemiaplasmática aleatória(mg/dL)+ sintomas|-|-|≥200|
|Glicemia de 1 hora no TTGO(mg/dL)**|< 155|155 - 208|≥209|
|Glicemia de 2 horas no TTGO (mg/dL)**|< 140|140- 199|≥200|
|HbA1c(%)|< 5,7|5,7 - 6,4|≥6,5|  
**Legenda:** DM2: diabete melito tipo 2; TTGO: teste de tolerância à glicose oral; HbA1c: hemoglobina glicada.  
**Notas:** *Considera-se como jejum a cessação de ingesta calórica de 8 horas - 12 horas. **Carga oral equivalente a 75 g de glicose anidra, diluída em água.  
**Fonte** : Elaboração própria com base nas recomendações da Sociedade Brasileira de Diabetes<sup>2</sup> .  
7  
Em indivíduos assintomáticos ou sem sinais e sintomas clássicos e inequívocos de hiperglicemia, que apresentaram resultados previamente positivos no teste de rastreamento **,** o diagnóstico confirmatório de DM2 requer pelo menos dois resultados acima dos limites de referência do mesmo teste em amostras diferentes, ou dois testes diferentes com resultados acima dos limites de referência para a mesma amostra **(Figura 1)** . A estratégia de maior praticidade para confirmar o diagnóstico desses indivíduos é a solicitação de glicemia de jejum e HbA1c na mesma amostra plasmática, desde que não existam situações que possam interferir na correlação entre os níveis de HbA1c e o verdadeiro valor de glicemia **(Quadro 3)**<sup>2,25,28</sup> .  
Caso os valores de glicemia de jejum e HbA1c, obtidos na mesma amostra de sangue, estejam acima dos limites de referência **(Quadro 4),** o diagnóstico de DM2 é estabelecido. Se ambos os resultados estiverem dentro da faixa normal, o diagnóstico de DM2 é descartado. No entanto, se apenas um dos parâmetros estiver superior aos valores de referência normais, os testes devem ser repetidos. Se, na nova avaliação, os resultados permanecerem dentro da normalidade, ou seja, sem alteração laboratorial, o diagnóstico de DM2 é descartado. Contudo, o paciente deve permanecer sob acompanhamento clínico e ser submetido a novo rastreamento após um ano, conforme indicado na **Figura 1** .  
Além disso, em indivíduos que apresentam condições que possam distorcer a correlação entre os valores da HbA1c e os níveis reais de glicemia ( **Quadro 3** ), bem como em indivíduos com fibrose cística, recomenda-se a realização conjunta da glicemia em jejum e do TTGO para confirmação diagnóstica<sup>2,25</sup> .  
Em indivíduos sintomáticos — ou seja, aqueles que apresentam sinais e sintomas clássicos e inequívocos de hiperglicemia ( **Quadro 2** ), recomenda-se que o diagnóstico de DM2 seja realizado por meio de glicemia plasmática aleatória ou, glicemia de jejum e HbA1c. O diagnóstico é confirmado quando a glicemia aleatória é igual ou superior a 200 mg/dL ou a glicemia de jejum é igual ou superior a 126 mg/dL e a HbA1c é igual ou superior a 6,5%, permitindo o início oportuno do tratamento<sup>2,25</sup> . Caso o resultado apresente valores inferiores a esses limiares, um segundo teste diagnóstico (TTGO) deve ser realizado para confirmar a presença da doença<sup>2</sup> . <u>Se a glicemia no TTGO-1h for maior ou igual a 209 mg/dL ou,</u> alternativamente, no TTGO- 2h for maior ou igual a 200 mg/dL, confirma-se o diagnóstico de DM2. Caso o resultado de TTGO-1h apresente valores entre 155 mg/dL e 208 mg/dL considerase que o paciente possui pré-diabetes, condição intermediária de risco para o desenvolvimento da DM2<sup>2</sup> .  
O diagnóstico diferencial do DM2 deve basear-se na avaliação clínica, sendo os exames complementares indicados apenas em situações de dúvida diagnóstica<sup>29</sup> . Nestes casos, é importante considerar outras possibilidades, como diabete melito tipo 1 (DM1), formas monogênicas de diabetes, lipodistrofias e causas secundárias da doença, como transtorno por uso de álcool e uso de corticóides<sup>29</sup> .  
De maneira geral, recomenda-se que a interpretação dos exames laboratoriais considere os fatores clínicos e as possíveis interferências analíticas que possam afetar o diagnóstico de DM2<sup>2</sup> . A estratégia de abordagem diagnóstica para indivíduos rastreados com base na avaliação do risco de DM2, e para indivíduos sintomáticos, é apresentada na **Figura 1** . Ressalta-se que, embora o TTGO-2h possa ser utilizado, o fluxograma não apresenta os resultados para esse exame, por não ser o preferível.  
8  
<!-- Start of picture text -->
Individuos assintomaticos com 35 anos ou mais de idade ou<br>individuos com condigdes associadas & resisténcia insulinica* ou<br>individuos de qualquer idade com sobrepeso ou obesidade e pelo menos um fator de risco ® ou individuos sintomaticos<br>Co licitar<br>Nao, Apresenta sinaise \ Sim | Sojicitar gicemia plasmatica<br>;oGDCEDbyedieby) sintomasde hiperglicemia?® cléssicos aleatéria, glicemiaHbAtc de jejum ou<br>Nao Glicemia de jejum Sim sim _/Glicemia aleatéria 2 200 mgidL. Nao<br>2 126 mgidLe (u Gicomia de jeu<br>HbAtc 2 6,5%? elou HbAtc > 6.5%= 126 mot.<br>vaanésti Para confirmagao diagnéstica,<br>Diagnéstico de DM2 Ce Sanya Diagnéstico de DM2 ee Conn<br>excluido HbAtc ouTTGO-1h e's confirmado<br>oa y<br>(OE sim / Glicemia de jojum Nao ¢<br>> 126 mg/dl, TTGO-th TTGO-1hentre | TTGO-th<br>HbAtc 2 6,5% ou 2209 mga. 4185 e 209 moja. << 155 mgidl.<br>TTGO-th > 209 mala? a<br>DM2Diagnésticoconfirmado de DiagnésticoDM2 exclui; d oe Diagnésticoga de DM2 Pré-diabetes! Diagnbstiocrehiue<br>IMonttorar 0 paciente" Monitorar 0 paciente”<br>Legenda: HbA‘c: hemoglobina glicada, TTGO: teste de tolerdncia & glicose oral; DM2: diabete melit tipo 2,<br>Notas:<br>'sindromela.b. ComoFatores obesidadedodeovariorisco:  gravepolcistico;parentee acantosede acantoseprimeironigricans;graunigricans;com diabetes;doenca hepaticahistéricoesteatética;de doenga hipertensaocardiovascular;arterialestilosist8mica;de vida sedentio;pré-diabetesdislipidemiaem exame(HDL-colesterolprévio; histbrico<de35diabetemg/dLoumelitotriglicerideosgestacional> 250ou  mg/dL);parto de|<br>lum bebé com peso > 4 kg; terapia antipsicctica; apneia obstrutiva do sono; privacao crénica do sono; ocupacao laboral em tuo noturno.<br>ic. Poliiria, policipsia, perda ponderal nao intencional, noctiria e polifagia.<br>le.\d. AescolnaSe individuosdeve comser fibrosebaseada cistica,na disponibilidade0 rastreamentolocal@ confirmagaopara realizacaodiagnésticada dosagem devemde serHAtc. conduzidos com o teste de tolerdncia a glicase oral (TTGO);<br>I Os exames podem ser feitos com a mesma amostra ou com duas amostras diferentes,<br>'g. Realizar a confirmagao diagndstica de DM2 se glcemia de jejum @ HbAc estiverem ambos alterados, e caso apenas um parametro esteja acima da referéncia, repetir os testes (glicemia de<br>jejum ou HbA1c) ou complementar com outro teste (TTGO).<br>Ih. Monitorar<br>i. 0 diagnéstico0 paciente,de DM2incluindo6 confirmadoo rastreamentona presenca de pacientes assintomaticosde glicemia aleatdria elevada conformeou de periodicidadeglicemia de jejum preconizadae HbAtc noalterados. Protocolo.Na presenca de apenas um exame alterado (glicemia de jejum o<br>HbA\c), realizar TTGO para confirmagao diagnéstica<br>J. Recomendar mudanga de modos de vida e repetir exames em 1 ano; considerar uso de medicamentos para prevengao da DM2.<br><!-- End of picture text -->  
**Figura 1** . Fluxograma de rastreamento e diagnóstico do diabete melito tipo 2. **Legenda:** HbA1c: hemoglobina glicada, TTGO: teste de tolerância à glicose oral; DM2: diabete melito tipo 2.  
9

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 5.4. Diagnóstico de crianças e adolescentes -->
É importante que o profissional de saúde realize o diagnóstico correto de DM2 em pacientes jovens. A suspeita de DM2 deve ser considerada, especialmente em crianças e adolescentes com sobrepeso ou obesidade que apresentem pelo menos um dos seguintes fatores de risco para DM2: histórico de diabetes materno, histórico familiar de DM2 em parentes de primeiro ou segundo grau,  sinais clínicos de resistência à insulina (como acantose _nigricans_ ), HAS, dislipidemia, Síndrome do Ovário Policístico (SOP), baixo peso ao nascimento ou hiperglicemia detectada em exames de rotina, em especial com idade ≥ 10 anos ou após o início da puberdade, jovens com sobrepeso (IMC ≥ percentil 85) ou obesidade (IMC ≥ percentil 95)<sup>2,30,31</sup> .  
A distinção de DM2 e DM1 é essencial. Indivíduos com DM1 comumente apresentam sintomas clássicos do diabetes, como poliúria, polidipsia, polifagia, desidratação e perda de peso, especialmente aqueles indivíduos sem excesso de peso. Por outro lado, crianças com DM2 são comumente assintomáticas ou oligossintomáticas por longos períodos. Em caso de dúvida diagnóstica, especialmente em adolescentes, é indicado o encaminhamento ao endocrinologista. Os critérios laboratoriais para o diagnóstico de DM2 em crianças e adolescentes seguem os mesmos valores de referência utilizados para população adulta ( **Quadro 4).**

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 5.5. Estratificação do risco cardiovascular -->
A maior causa de morbimortalidade em pacientes com DM2 são as doenças cardiovasculares ateroscleróticas<sup>25,27</sup> . Além do próprio DM2, outras condições frequentemente associadas ao DM2, como HAS, dislipidemia, tabagismo, obesidade, apneia obstrutiva do sono, doença renal crônica e história familiar de doença coronariana precoce, são fatores de risco para desenvolvimento de doenças cardiovasculares. Diversos estudos mostraram a eficácia de controlar esses fatores para prevenir ou retardar o desenvolvimento dessas doenças em pacientes com DM2, principalmente quando tratados concomitantemente<sup>32,33</sup> .  
Dessa forma, o risco cardiovascular deve ser estimado na avaliação inicial e periodicamente, pelo menos uma vez ao ano, em pacientes com DM2. Isto permite implementar intervenções preventivas necessárias para reduzir complicações cardiovasculares e aumentar a qualidade de vida desses pacientes<sup>9,30,34</sup> .  
O **Quadro 5** apresenta os dados relevantes da anamnese, do exame físico e de exames complementares para a estimativa de risco cardiovascular. Comumente, recomenda-se a realização de exames complementares aos exames direcionados para o diagnóstico de DM2 **,** como colesterol total, lipoproteína de baixa densidade (LDL-c), lipoproteína de alta densidade (HDLc), triglicerídeos (TG), creatinina (com estimativa da taxa de filtração glomerular – TFG), relação albumina/creatinina em amostra urinária, exame comum de urina e eletrocardiograma<sup>27,30,34,35</sup> . Todavia, o(s) exame(s) complementar(es) solicitados podem variar conforme aspectos individuais.  
10  
**Quadro 5** . Avaliação clínica e laboratorial para a estimativa de risco cardiovascular.  
|**Anam**|**nese**|
|---|---|
|<br><br><br>|Sexo<br>Idade<br>Tabagismo<br>História prévia de doença cardiovascular (coronariana, cerebrovascular ou vascular<br>periférica)|
|**Sinais **|**vitais e dados antropométricos**|
|<br><br><br>|Pressão arterial<br>Peso<br>Altura<br>Circunferência abdominal|
|**Exame**|**s complementares**|
|<br><br><br><br>|Colesterol total (CT)<br>Lipoproteína de baixa densidade (LDL-c)<br>Lipoproteína de alta densidades (HDL-c)<br>Triglicerídeos (TG)<br>Creatinina<sup>a</sup>|
|<br><br>|Relação albumina/creatinina em amostra urinária<br>Exame comum de urina<br>Eletrocardiograma|  
**Notas** :<sup>a.</sup> Estimar a taxa de filtração glomerular pela equação CKD-EPI. A equação CKD-EPI é expressa como uma equação simples: TFG = 141 X min (SCR/k, 1) a X max (SCR/k, 1) -1,209 X 0,993 Idade X 1,018 [se mulher] X 1,159 [se negro]. Onde “SCR” corresponde ao valor de creatinina sérica (mg/dL), “k” equivale a 0,7 e 0,9 para mulheres e homens respectivamente, “a” representa -0,329 e -0,411 para mulheres e homens respectivamente, “min” indica o mínimo de SCR/k ou 1, e “max” indica o máximo de SCR/k ou 1<sup>36,37</sup> .  
**Fonte** : Elaboração própria com base nas recomendações da Sociedade Brasileira de Diabetes, _American Diabetes Association_ , Ministério da Saúde, Organização Pan-Americana da Saúde<sup>30,34,35,38</sup> .  
Além da avaliação clínica e laboratorial, é recomendado o uso de uma ferramenta validada para estimar o risco cardiovascular dos pacientes com DM2<sup>39</sup> . Embora existam várias calculadoras para avaliação do risco cardiovascular, no Brasil, para indivíduos entre 40 e 74 anos, é recomendada a calculadora HEARTS/OPAS/OMS, que utiliza parâmetros definidos a partir do estudo _Global Burden Disease_ (GBD), considerando os dados de estimativa populacional brasileira<sup>32,40</sup> . A calculadora HEARTS foi a ferramenta de estratificação do risco cardiovascular que demonstrou melhor calibração para a população brasileira<sup>41</sup> .  
Por permitir a estratificação do risco cardiovascular utilizando critérios laboratoriais e não laboratoriais, a calculadora HEARTS é considerada uma ferramenta de fácil aplicabilidade para estimar o risco cardiovascular<sup>35</sup> . A calculadora é de livre acesso e está disponível em: <u>https://www.paho.org/pt/hearts-nas-americas/calculadora-risco-cardiovascular.</u>  
É importante pontuar que esta ferramenta classifica os indivíduos em categorias que vão de muito baixo a alto risco. Pacientes com DM2 já são classificados como alto risco e, caso também apresentem algumas comorbidades cardiovasculares, como doença arterial coronariana, acidente vascular cerebral ou doença arterial periférica, passam a ser são classificados como muito alto risco<sup>35</sup> . Desse modo, reforça-se a recomendação da estratificação anual do risco cardiovascular para indivíduos com DM2 entre 40 e 74 anos, uma vez que, caso venham a apresentar doença cardiovascular, a sua classificação de risco é modificada.  
11  
Para indivíduos com idade menor ou igual a 39 anos e maior ou igual a 75 anos, a avaliação do risco cardiovascular deve ser individualizada com recomendação da adoção do autocuidado apoiado, da alimentação adequada e saudável, da prática regular de atividade física, da cessação do tabagismo e da redução do consumo de álcool. Em indivíduos com idade menor ou igual a 39 anos deve-se considerar de alto risco aqueles com nefropatia ou retinopatia. No caso de indivíduos que vivem com DM1, deve-se avaliar o risco cardiovascular de forma individualizada, preferencialmente, em conjunto com a atenção especializada<sup>26</sup> .  
Ressalta-se que a estratificação de risco cardiovascular não altera a conduta terapêutica para DM2. No entanto, visando à integralidade do cuidado, recomenda-se a estratificação do paciente para apoiar a tomada de decisão quanto ao tratamento de outras comorbidades associadas, como a prevenção e tratamento de dislipidemias, conforme estabelecido no respectivo Protocolo Clínico e Diretrizes Terapêuticas vigente. Essa abordagem também contribui para a adequada organização do cuidado e definição das estratégias de acompanhamento<sup>26,42,43</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 6. CRITÉRIOS DE INCLUSÃO -->
Devem ser incluídos nesse PCDT todos os indivíduos com idade igual ou superior a 18 anos e com diagnóstico confirmado de DM2, com ou sem complicações microvasculares ou macrovasculares.  
Para a realização do **rastreamento e confirmação diagnóstica** , devem ser incluídos os indivíduos que apresentarem os respectivos critérios de rastreamento e diagnóstico.  
Para que o paciente seja elegível ao tratamento com dapagliflozina, requer-se o diagnóstico de DM2, com necessidade de segunda intensificação de tratamento e um dos seguintes critérios:  
- Ter 40 anos ou mais e doença cardiovascular estabelecida (infarto agudo do miocárdio prévio, cirurgia de revascularização do miocárdio prévia, angiosplastia prévia das coronárias, angina estável ou instável, acidente vascular cerebral isquêmico prévio, ataque isquêmico transitório prévio, e insuficiência cardíaca com fração de ejeção abaixo de 40%), ou;  
- Ter 55 anos ou mais (no caso de homens) ou ter 60 anos ou mais (no caso de mulheres) e alto risco de desenvolver doença cardiovascular, definido como ao menos um dos seguintes fatores de risco cardiovascular: hipertensão arterial sistêmica, dislipidemia ou tabagismo.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: NOTAS: -->
Gestantes com DM2 pré-gestacional também são contempladas por este Protocolo. Pacientes com DM2 em cetoacidose diabética ou coma hiperosmolar não são incluídos neste Protocolo, uma vez que o cuidado destes pacientes deve ser conduzido de acordo com protocolos de urgência. Após a alta, estes pacientes poderão ser reincluídos ou permanecerão neste Protocolo.  
12

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 7. CRITÉRIOS DE EXCLUSÃO -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicações a medicamento neste Protocolo, deverão ser excluídos ao uso do respectivo medicamento preconizado. Ainda, pacientes inicialmente rastreados para DM2, que não obtiveram confirmação diagnóstica, devem ser excluídos do tratamento e monitoramento previstos neste Protocolo.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8. ABORDAGEM TERAPÊUTICA -->
O objetivo principal do tratamento do DM2 consiste em melhorar a qualidade de vida e prevenir complicações da doença. Para isso, a abordagem terapêutica dos indivíduos com DM2 baseia-se no tratamento não medicamentoso, como mudança de modos de vida, educação em saúde, cuidados psicossociais e autocuidado de DM2, e no tratamento medicamentoso<sup>44,45</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.1. Metas terapêuticas -->
Diante da complexidade da doença e visando a atingir o objetivo do tratamento do DM2, as metas terapêuticas são múltiplas e consistem não apenas em controle glicêmico, mas também em perda de peso quando indicada e controle de outros fatores de risco cardiovasculares, como HAS e dislipidemia, além do tratamento das complicações já estabelecidas<sup>32</sup> .  
O alcance e manutenção das metas glicêmicas, e início precoce do tratamento são fundamentais para garantir um bom prognóstico dos pacientes. O controle glicêmico deve ser individualizado conforme a situação clínica do paciente. Os parâmetros de avaliação indicados são a HbA1c e as glicemias capilares ou plasmáticas, medidas em jejum ou aleatoriamente durante o dia, nos períodos pré-prandiais, 2 horas após as refeições ou antes de dormir<sup>32,46</sup> .  
Os valores de HbA1c são os principais parâmetros usados para avaliação do tratamento da hiperglicemia em DM2, cujos valores esperados como meta terapêutica correspondem a ≤ 7,0%<sup>47</sup> . Existem evidências robustas de que a intensificação do controle glicêmico desde o diagnóstico do DM2, com manutenção de HbA1c ≤ 7,0% reduzem a incidência de complicações macrovasculares e, principalmente as microvasculares, como retinopatia, DRD e neuropatia<sup>48–51</sup> .  
Contudo, essa meta pode ser menos rígida para idosos (pessoas com idade ≥ 60 anos). Para estes pacientes, são aceitáveis valores de HbA1c entre 7,5% e 8,0%, de acordo com a idade ou expectativa de vida, e a presença de complicações ou comorbidades, conforme apresentado no **Quadro 6**<sup>34</sup> . Valores de HbA1c < 7,0% apresentaram maior risco de mortalidade nessa população e, por isso, a adoção de metas mais agressivas é desencorajada para idosos vulneráveis com DM2<sup>52</sup> . Tais metas podem ser reservadas a indivíduos jovens, sem doença cardiovascular significativa e com DM2 de início recente, desde que não incorra em hipoglicemias graves ou frequentes<sup>47</sup> .  
As metas glicêmicas recomendadas incluem valores entre 80 mg/dL e 130 mg/dL para o exame de glicemia de jejum, e 180 mg/dL para a glicemia aleatória ou 2 horas após a alimentação<sup>53</sup> . Valores de glicemia antes de dormir, em geral, devem variar entre 90 mg/dL e 150 mg/dL. No entanto, para pacientes idosos comprometidos ou muito comprometidos os valores podem variar entre 100 mg/dL e 180 mg/dL, e 110 mg/dL a 200 mg/dL, respectivamente. O  
13  
**Quadro 6** apresenta os valores de referência conforme metas terapêuticas nas diferentes populações.  
**Quadro 6** . Metas no tratamento do diabete melito tipo 2.  
|**Exame**|**Indivíduos**<br>**com DM2**|**Idoso**<br>**saudável**<sup>**a**</sup>|**Idoso**<br>**comprometido**<sup>**b**</sup>|**Idoso muito**<br>**comprometido**<sup>**c**</sup>|**Criança e**<br>**adolescente**|
|---|---|---|---|---|---|
|HbA1c %|< 7,0|< 7,5|< 8,0|Evitar sintomas<br>de hiperglicemia<br>ou hipoglicemia|< 7,0|
|Glicemia<br>de jejum<br>(mg/dL)|80-130|80-130|90-150|100-180|70-130|
|Glicemia<br>2h pós-<br>prandial<br>(mg/dL)|< 180|< 180|< 180|-|< 180|
|Glicemia<br>ao deitar<br>(mg/dL)|90-150|90-150|100-180|110-200|90-150|  
**Legenda:** HbA1c: hemoglobina glicada.  
**Notas** :<sup>a</sup> Idoso com poucas comorbidades crônicas, estado funcional e cognitivo preservado;<sup>b</sup> Idoso com múltiplas comorbidades crônicas, comprometimento funcional leve a moderado, comprometimento cognitivo moderado;<sup>c</sup> Idoso com doenças terminais como câncer metastático, insuficiência cardíaca ( _New York Heart Association_ - NYHA, classe IV), doença pulmonar crônica demandando oxigenioterapia, pacientes em diálise; comprometimento funcional e cognitivo grave.  
**Fonte** : Estabelecido de acordo com as recomendações da Sociedade Brasileira de Diabetes<sup>47</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.2. Tratamento não medicamentoso -->
As intervenções não medicamentosas são indispensáveis para um controle glicêmico adequado. Construir comportamentos positivos de saúde e manter o bem-estar psicológico são fundamentais para alcançar os objetivos de gerenciamento do diabetes e maximizar a qualidade de vida. A educação e apoio a autogestão do diabetes, terapia nutricional, atividade física de rotina, sono de qualidade, apoio para a cessação do tabagismo, aconselhamento comportamental de saúde e cuidados psicossociais são essenciais para alcançar esses objetivos<sup>54</sup> .  
Educação em diabetes é definida como o processo através do qual pessoas com diabetes utilizam conhecimentos e habilidades necessárias para melhorar o gerenciamento do diabetes e alcançar as suas metas de controle metabólico<sup>55</sup> .  
A adoção de hábitos de vida saudáveis, especialmente voltados à manutenção do peso corporal saudável ou à perda de peso, se indicado, é fundamental para indivíduos com DM2 e pré-diabetes. Quando recomendado, a redução de 3% a 7% do peso inicial melhora a glicemia e outros fatores de risco cardiovasculares. Uma redução de peso maior que 10%, mantida ao longo do tempo, pode levar a benefícios mais expressivos, como diminuição da progressão da doença, com possibilidade de remissão do DM2, menor incidência de eventos cardiovasculares e redução da mortalidade<sup>54</sup> . Para indivíduos com excesso de peso ou obesidade, recomenda-se uma redução de no mínimo 5% do peso corporal<sup>56</sup> .  
14

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.2.1. Alimentação e nutrição -->
A terapia nutricional representa um dos pilares mais desafiadores e decisivos para o tratamento do DM2. O cuidado deve incluir abordagens de mudanças de modo de vida, educação alimentar, e controle de peso, por meio de uma alimentação adequada e saudável, contribuindo para o alcance e manutenção do controle glicêmico em todas as fases da doença, independentemente do tempo de diagnóstico da doença<sup>54,5734,58,59</sup> .  
De uma forma geral, a orientação nutricional para o DM2 deve ter como base a alimentação variada e equilibrada. A terapia nutricional visa a atender às necessidades nutricionais, alcançar metas glicêmicas, obter e manter o peso corporal saudável, contribuir para o controle da pressão arterial e dos lipídeos séricos, atuando na prevenção das complicações microvasculares e macrovasculares associadas ao DM2<sup>60</sup> .  
O cuidado nutricional deve ser centrado no paciente, considerando a parte comportamental, suas limitações, preferências, recursos, contexto socioeconômico e cultural. A abordagem deve ser individualizada, conforme avaliação e diagnóstico nutricional, com decisões compartilhadas e estratégias adaptadas à rotina, idade, comorbidades e motivação para mudanças alimentares<sup>20</sup> . Não há um plano alimentar único para todas as pessoas e uma avaliação individualizada deve ser feita em cada caso. Além disso, desconstruir mitos e crenças sobre a alimentação auxilia na flexibilização da condução nutricional e favorece a adesão ao tratamento<sup>61–</sup> 63.  
Durante o aconselhamento nutricional, deve-se investigar se tentativas anteriores de mudança de hábitos alimentares inadequados e promover o autocuidado antes do surgimento de complicações clínicas, reforçando a responsabilidade do paciente no processo de mudança<sup>61</sup> . Diversas abordagens nutricionais podem melhorar o controle glicêmico, sendo recomendada uma dieta balanceada, com restrição de carboidratos simples ou alimentos refinados, de rápida absorção<sup>34</sup> .  
O equilíbrio entre o consumo de carboidratos, proteínas e lipídios da dieta pode variar de acordo com os objetivos e metas individualizadas, sem a exclusão de nenhum grupo alimentar. A Organização Mundial da Saúde recomenda o consumo mínimo de 130 g/dia de carboidratos, por ser uma importante fonte de substrato energético cerebral e para outros processos metabólicos<sup>55,57,64</sup> . Embora não haja consenso sobre a quantidade ideal, o monitoramento da ingestão de carboidratos é uma estratégia fundamental para atingir as metas glicêmicas<sup>54</sup> . Como o carboidrato é o nutriente que exerce maior influência na variabilidade glicêmica pós-prandial, as evidências atuais sugerem que o tipo de carboidrato, independente da proporção, tem grande relevância. Isso porque carboidratos, quando consumidos na forma de açúcares ou amido, apresentam respostas diferentes daqueles consumidos prioritariamente com fibras, compostos bioativos, vitaminas, minerais e baixo teor de gorduras. Além disso, a resposta glicêmica pode ser mais lenta e menos exacerbada, conforme a o tipo de carboidrato consumido e a composição da refeição<sup>60</sup> .  
Padrões alimentares para DM2 devem priorizar o consumo de vegetais sem amido, frutas integrais, leguminosas, proteínas magras, grãos integrais, nozes, sementes e laticínios com baixo teor de gordura ou alternativas não lácteas; e minimizar o consumo de carne vermelha, bebidas açucaradas, doces, grãos refinados, alimentos processados e ultraprocessados<sup>54</sup> .  
O fracionamento das refeições deve ser prescrito de forma individualizada, considerando a percepção de fome ou os níveis glicêmicos, devendo ser incentivada o consumo dos diferentes grupos alimentares tanto nas refeições principais, quanto nas pequenas refeições ao longo do dia<sup>65,66</sup> . No almoço e jantar, recomenda-se aumentar o consumo de verduras e legumes, e  
15  
incentivar a combinação tradicionalmente brasileira de arroz e feijão, reduzir o consumo de carne vermelha e sal, e priorizar as frutas _in natura_ em vez de sucos. A ingestão hídrica adequada também deve ser incentivada<sup>60,67</sup> .  
O Guia Alimentar para a População Brasileira incentiva práticas alimentares saudáveis, fundamentadas no consumo de alimentos _in natura_ ou minimamente processados, variados e predominantemente de origem vegetal<sup>65</sup> . Nesse sentido, ressalta-se a importância de evitar o consumo de alimentos ultraprocessados, que apresentam alto teor de açúcar livre, gorduras totais e saturadas, e baixa concentração de fibras, proteínas, vitaminas e minerais. Alimentos _in natura_ de origem vegetal possuem em sua composição fibras dietéticas que podem atenuar a resposta à insulina e, assim, auxiliar na prevenção e controle do DM2. As fibras solúveis (presentes, por exemplo, em frutas, aveia, cevada e leguminosas) apresentam efeitos benéficos na glicemia e no metabolismo dos lipídios e auxilia no retardo do esvaziamento gástrico, contribuindo positivamente para o controle glicêmico pós-prandial. As fibras insolúveis (presentes, por exemplo, em grãos de cereais e hortaliças) agem contribuindo para a saciedade e para o controle de peso corporal. Em adultos com DM2, recomenda-se a ingestão de fibras dietéticas, na quantidade 14 g/1000 kcal, com um mínimo de 25 g por dia, para melhorar o controle glicêmico e atenuar hiperglicemia pós-prandial<sup>34</sup> .  
Bebidas adoçadas com açúcar devem ser evitadas. Adoçantes não nutritivos podem ser usados por pessoas com diabetes em vez de produtos adoçados com açúcar, se consumidos com moderação, para reduzir a ingestão geral de calorias e carboidratos<sup>54</sup> . A Organização Mundial da Saúde contraindica o uso de edulcorantes não-nutritivos (ENN) para manutenção do peso corporal saudável ou redução do risco de doenças não transmissíveis, em crianças e adultos. Embora essa recomendação não seja estendida a indivíduos com DM2, estes também podem reduzir a ingestão de açúcares livres sem a necessidade de uso de ENN. Alimentos e bebidas fabricados pela indústria que contêm açucares ou adoçantes artificiais são, em geral, alimentos ultraprocessados e, por isso, devem ser evitados<sup>19,68</sup> .  
Cabe destacar que o açúcar pode se apresentar com outros nomes na lista de ingredientes de alguns produtos como sacarose, frutose, xarope de milho, xarope de malte, maltodextrina e açúcar invertido. Para que os indivíduos sejam capazes de identificar e analisar, de forma crítica e consciente, suas escolhas alimentares, os profissionais devem orientar os pacientes sobre rotulagem e publicidade de alimentos, com vistas a uma alimentação adequada e saudável<sup>65,66,69</sup> .  
O consumo de bebidas alcoólicas não é isento de risco, e pode comprometer o tratamento de doenças crônicas não transmissíveis, como o DM2. Além dos danos relacionados ao consumo, alimentação e controle glicêmico, os indivíduos podem apresentar dificuldades no uso regular dos medicamentos. O consumo de bebidas alcoólicas durante as refeições incluindo carboidratos, pode elevar inicialmente os níveis glicêmicos e insulinêmicos nas pessoas com DM2<sup>64</sup> . Além disso, a ingestão de bebida alcoólica pode aumentar o risco de hipoglicemia tardia em diabéticos. Este efeito pode ser resultado da inibição da gliconeogênese, redução da consciência da hipoglicemia devido aos efeitos cerebrais do álcool ou respostas contrarregulatórias prejudicadas à hipoglicemia<sup>19,70</sup> . Isto é particularmente relevante entre aqueles que utilizam insulina ou secretagogos de insulina (particularmente glibenclamida e gliclazida). Recomenda-se orientar as pessoas com diabetes sobre os sinais, sintomas, o monitoramento da glicose, e o cuidado com a hipoglicemia tardia, após o consumo de bebidas alcoólicas<sup>60</sup> . A ingestão excessiva de álcool (> 30 g/dia) está associada à alteração da homeostase glicêmica, elevação da resistência à insulina, hipertrigliceridemia e aumento da pressão arterial, podendo ser um fator de risco para acidente vascular cerebral<sup>55</sup> .  
Além dessas recomendações, deve-se considerar as demais publicações do Ministério da Saúde com orientações sobre alimentação e nutrição, que podem auxiliar o cuidado das pessoas  
16  
com diabetes, como o Guia Alimentar para População Brasileira; o Manual de Alimentação Cardioprotetora<sup>71</sup> ; o Manual do cuidado de pessoas com doenças crônicas na APS, no contexto da pandemia<sup>69</sup> ; as Linhas de Cuidado de DM2 no adulto<sup>19</sup> , e os Protocolos de Uso do Guia Alimentar para a População Brasileira, com orientação alimentar de pessoas adultas com obesidade, hipertensão arterial e diabetes mellitus<sup>66</sup> e para pessoas adultas com obesidade<sup>65</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.2.2. Atividade física -->
A prática regular de exercícios físicos é altamente recomendada para pessoas com DM2, especialmente em modalidades combinadas, de exercícios resistidos e aeróbicos. O protocolo indicado inclui pelo menos um ciclo de 10 a 15 repetições de cinco ou mais exercícios, realizados em duas a três sessões por semana, em dias não consecutivos. Além disso, recomenda-se realizar, no mínimo, 150 minutos semanais de caminhada com intensidade moderada ou alta, não permanecendo mais de dois dias consecutivos sem atividade física<sup>34</sup> .  
Recomenda-se evitar o comportamento sedentário. Sempre que possível, deve-se reduzir o tempo sentado ou deitado, assistindo televisão, usando o celular, computador ou _tablet_ . Pequenas atitudes como levantar-se a cada uma hora, movimentar-se por pelo menos 5 minutos, mudar de posição, ir ao banheiro, beber água e alongar o corpo, podem contribuir para a redução do comportamento sedentário, e melhorar a qualidade de vida<sup>72</sup> .  
A prática de atividade física melhora o controle glicêmico (incluindo a diminuição da HbA1c), reduz fatores de risco cardiovasculares, previne complicações do DM2, auxilia na perda e manutenção do peso corporal adequado, além de proporcionar o bem-estar biopsicossocial do indivíduo. O início das atividades físicas deve ser gradual e os exercícios físicos regulares, respeitando as condições de saúde, preferências pessoais e orientações profissionais. É importante avaliar e considerar a estratificação do risco cardiovascular, em pessoas com DM2 (item Estratificação do risco cardiovascular) que pretendam iniciar a prática de atividades físicas, visando garantir a segurança e prevenção de eventos indesejáveis.  
A recomendação de exercícios aeróbicos, resistidos ou ambos, com duração mínima de 150 minutos semanais, permite a distribuição dos exercícios conforme rotina individual (por exemplo, atividades moderadas 5 vezes na semana por 30 minutos, ou 3 vezes na semana por 50 minutos). Alternativamente, podem ser realizados 75 minutos por semana de atividades com intensidade vigorosa, quando possível<sup>27,39</sup> . Os exercícios resistidos devem envolver o maior número possível de grupos musculares, visando à melhora da circulação geral e periférica, e a ação da insulina. Para idosos, é importante incluir alongamentos e exercícios de equilíbrio. A prática de atividade física deve ser realizada, preferencialmente, com roupas leves e calçados confortáveis<sup>64</sup> .  
É importante que o profissional de saúde valorize qualquer prática de atividade física, independentemente do alcance das metas estabelecidas. Além disso, deve-se orientar os indivíduos quanto aos riscos de hipoglicemia, reforçando a importância da alimentação regular, da disponibilidade de fontes de glicose rápida (como frutas ou balas) durante o exercício, e quanto aos sinais e sintomas da hipoglicemia<sup>27,64</sup> .  
Pacientes com complicações do DM2 devem ser cuidadosamente avaliadas e requerem cuidados específicos. Por exemplo, indivíduos com retinopatia devem utilizar cargas mais baixas, evitar movimentos rápidos da cabeça, assim como aqueles que aumentam a pressão intraabdominal, devido ao risco de hemorragia vítrea ou descolamento de retina<sup>73</sup> . O exame  
17  
sistemático dos pés deve ser realizado, com incentivo ao autoexame e uso de calçados adequados, para evitar lesões e úlceras nos membros inferiores<sup>34,64,73</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.2.3. Cessação do tabagismo -->
O tabagismo é considerado fator de risco para várias doenças crônicas não transmissíveis, incluindo o DM2, e é a principal causa de morte evitável no mundo<sup>74</sup> . Intervenções realizadas por profissionais de saúde para a cessação do tabagismo têm a melhor relação custo-benefício, e abordagens rápidas em consultas clínicas, repetidamente, contribuem para a abstinência do fumo<sup>75</sup> . A cessação do tabagismo deve ser uma prioridade na abordagem das pessoas com DM2. O tratamento fundamenta-se em abordagem cognitivo-comportamental acerca dos riscos e benefícios da cessação do tabagismo, associada ou não à farmacoterapia<sup>76</sup> . Essa abordagem busca compreender e intervir na dependência psicológica e nos padrões de comportamento associados ao ato de fumar.  
O tabagismo parece estar associado a processos metabólicos relacionados com o diabetes, incluindo a homeostase da glicose, hiperinsulinemia e resistência à insulina. Estudos indicam que fumantes, mesmo com tolerância à glicose normal, apresentam níveis de HbA1c mais altos em comparação aos não fumantes<sup>64,77</sup> . Pessoas com diabetes que fumam ou são expostas ao fumo passivo têm um risco aumentado de complicações macrovasculares (por exemplo, doenças cardiovasculares e vasculares periféricas), complicações microvasculares (por exemplo, doenças renais e deficiência visual), piora dos resultados glicêmicos e morte prematura em comparação com aqueles que não fumam<sup>54</sup> .  
Para mais informações sobre estratégias para a cessação do tabagismo recomenda-se consultar o PCDT do Tabagismo vigente<sup>76</sup> , as estratégias para o cuidado da pessoa com doença crônica – O cuidado da pessoa tabagista<sup>75</sup> , e a linha de cuidado do tabagismo<sup>78</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.2.4. Autocuidado -->
É fundamental que, durante o acompanhamento da pessoa com DM2, o profissional de saúde realize uma abordagem educativa e acolhedora, individual ou coletiva, se possível, envolvendo a família. Essa abordagem deve promover o conhecimento sobre a condição clínica, e oferecer suporte ao autocuidado (autocuidado apoiado), com o objetivo de tornar o indivíduo corresponsável pelo seu cuidado e capaz de realizar melhores decisões em seu cotidiano<sup>27</sup> . Os momentos-chave em que esta abordagem se faz necessária são ao diagnóstico da doença; durante as consultas clínicas periódicas de acompanhamento; quando o paciente sinalizar dificuldades e outras necessidades específicas; e, quando há mudanças na equipe de saúde responsável pelo cuidado e tratamento<sup>79</sup> .  
Os aspectos mais importantes do autocuidado a serem observados referem-se ao grau de compreensão da pessoa sobre a sua condição clínica; a sua capacitação na automonitorização da glicemia capilar por meio dos glicosímetros ou na administração de insulina, e as possíveis complicações decorrentes; como este lida com as repercussões físicas e emocionais; se a pessoa vislumbra e realiza mudanças necessárias dos modos de vida; compreensão e uso de forma adequada do seu tratamento medicamentoso; percebe quando precisa realizar consultas e exames de acompanhamento; avaliação dos pés de forma regular; reconhecimento dos sinais e sintomas de descompensação da doença e conhecimento sobre os recursos aos quais recorrer em caso de  
18  
complicações; manutenção das atividades da vida diária<sup>46,63</sup> . Neste sentido, é importante que o profissional de saúde ofereça exemplos de comportamentos saudáveis a serem adotados e colabore com o paciente na construção de estratégias adaptadas à sua realidade.  
O automonitoramento da glicemia capilar pode ser útil na tomada de decisão e representa um dos pilares do autocuidado. Dificuldades na automonitorização, como medo de agulhas, dor ao lancetar o dedo ou falta de habilidade técnica para realizar o teste, podem ser contornadas com a capacitação para a realização adequada das medidas de glicemia, tornando o processo mais confortável e estimulando a autonomia. Além disso, é importante que o indivíduo esteja apto a identificar os valores de normalidade esperados, os fatores que interferem nos resultados e como interpretá-los. A frequência de automonitorização é prescrita de forma individualizada<sup>80</sup> .  
A entrevista motivacional é uma técnica que pode ser utilizada para aprimorar a comunicação do profissional de saúde com a pessoa com DM2. Nessa entrevista são abordados aspectos como a ambivalência, responsabilização, prevenção de recaídas e compromisso com a mudança necessária dos modos de vida<sup>81</sup> . Essa ferramenta permite ao profissional demonstrar empatia; evitar confrontos; identificar discrepâncias entre o que se quer fazer e o que é feito; gerenciar a resistência do indivíduo; apoiar à autoeficácia, auxiliando a pessoa a reconhecer sua capacidade de lidar com a mudança, influenciando positivamente em sua saúde. Com isso, fortalece-se o vínculo e a parceria do profissional de saúde e o indivíduo com DM2, com o objetivo de se alcançar melhores resultados em saúde<sup>46,63</sup> . Para mais informações sobre o autocuidado em saúde para indivíduos com DM2, recomenda-se consultar o Guia Rápido Autocuidado em Saúde: Literacia para a saúde das pessoas com Diabetes Mellitus tipo 2<sup>82</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.2.5. Redução do estresse -->
Os fatores psicossociais exercem influência significativa sobre o cuidado e o tratamento do DM<sup>34</sup> . Para muitas pessoas, lidar com o diabetes é um desafio contínuo, especialmente diante das necessidades de mudanças no modo de vida e comportamentos necessários para promover o controle eficaz da glicemia e prevenção de complicações<sup>83</sup> . A comunicação centrada na pessoa tem sido associada à melhora no conhecimento a respeito da doença<sup>84</sup> , ao autocuidado<sup>85</sup> , controle glicêmico<sup>86,87</sup> e qualidade de vida<sup>88</sup> .  
O diagnóstico de uma doença crônica, como o DM2, por si só pode ser fonte de estresse para a pessoa acometida e sua família, uma vez que é uma condição que pode ter complicações graves e requer mudanças significativas do modo de vida<sup>27</sup> . Por isso, é essencial que os profissionais de saúde identifiquem e ofereçam suporte para problemas psicossociais, investigando as principais barreiras em seu autocuidado, além de avaliar a necessidade de articulação intersetorial, principalmente com os serviços da assistência social. É fundamental que a avaliação psicossocial e os encaminhamentos necessários façam parte do atendimento de rotina, para que não haja a deterioração do estado metabólico ou psicológico do paciente<sup>63,79</sup> .  
As orientações gerais para todo indivíduo com doença crônica como a prática regular de atividade física, incluindo as Práticas Integrativas e Complementares em Saúde (PICS), alimentação adequada e saudável, cessação de tabagismo e controle do consumo de bebidas alcoólicas também colaboram com a redução do estresse.  
A equipe de saúde deve se organizar junto aos profissionais especializados, como os componentes das equipes multiprofissionais, para mapear locais no território ou desenvolver ações e programas relacionados às práticas corporais e atividades físicas dentro dos  
19  
estabelecimentos de saúde e polos do Programa Academia da Saúde na APS, além de fortalecer algumas atividades, como as PICS.  
As PICS, sempre que disponíveis nos serviços de saúde, devem compor o rol de ações e intervenções voltadas ao cuidado de indivíduos, complementando o tratamento da equipe multiprofissional. A Política Nacional de Práticas Integrativas e Complementares no SUS (PNPIC) orienta que estados, distrito federal e municípios instituam suas próprias normativas trazendo para o SUS práticas que atendam às necessidades regionais. As PICS podem ser consideradas de forma complementar ao tratamento, devido aos possíveis benefícios aos pacientes com DM2. Contudo, ressalta-se que as PICS não substituem os demais tratamentos preconizados pelo Protocolo e que o tratamento medicamentoso não pode ser interrompido sem orientação médica.  
Além disso, deve ser considerada a duração e a qualidade do sono, uma vez que há alta prevalência de distúrbios do sono em indivíduos com DM2, incluindo insônia, apneia obstrutiva do sono (AOS), distúrbios relacionados ao ciclo circadiano. Ainda, o sono inadequado e a apneia do sono podem interferir no bem-estar do indivíduo com DM2 e controle glicêmico, principalmente na resistência à insulina e no desequilíbrio hormonal<sup>46,63</sup> . A saúde do sono desempenha um papel crítico na gestão e prevenção de DM2, sendo que a promoção de hábitos de sono saudáveis pode ser essencial na abordagem integrada do cuidado desses pacientes. Recomenda-se o uso de estratégias como manter horários regulares de sono, criar um ambiente propício para o descanso, limitar a exposição à luz antes de dormir e evitar o consumo de estimulantes, como cafeína, à noite.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.2.6. Outras estratégias terapêuticas -->
Para a promoção de mudanças do modo de vida que contribuam com o controle do DM2, recomenda-se que seja estabelecido um cuidado colaborativo, multiprofissional e centrado no indivíduo. Esse cuidado deve considerar a importância que a pessoa acompanhada atribui à mudança de comportamento e quão segura e confiante se sente em conseguir realizá-la<sup>27</sup> . A partir disso, é possível evidenciar potencialidades e fragilidades, além de traçar estratégias para o cuidado. Além disso, recomenda-se a elaboração de um plano de cuidado integral, com orientações sobre autocuidado, medicamentos em uso, como reconhecer e o que fazer em situações de descompensação, e alertas quanto aos níveis glicêmicos. A descrição das metas terapêuticas discutidas conjuntamente para o tratamento e para a mudança de comportamento, se possível, deve ser entregue ao paciente<sup>64</sup> .  
Considerando a associação entre DM2 e possíveis complicações macrovasculares, recomenda-se associar medidas terapêuticas direcionadas ao controle de DM2 com medidas associadas a outros fatores de risco cardiovascular, como dislipidemia e HAS. O controle terapêutico para estes demais fatores é abordado nos Protocolos Clínicos e Diretrizes Terapêuticas da Dislipidemia: prevenção de eventos cardiovasculares e pancreatite<sup>43</sup> e da HAS vigentes.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.3. Tratamento medicamentoso -->
O tratamento do DM2 desempenha papel fundamental na prevenção de complicações microvasculares e macrovasculares. Evidências provenientes de estudos clínicos randomizados<sup>89,49</sup> demonstraram que a manutenção da HbA1c próxima aos níveis normais reduz  
20  
o risco de desfechos microvasculares, como retinopatia, doença renal e neuropatia, além de reduzir complicações macrovasculares a longo prazo. Os benefícios são maiores quando o tratamento adequado é iniciado precocemente, desde o diagnóstico.  
O tratamento medicamentoso deve ser individualizado, de acordo com as características do paciente, gravidade e evolução da doença<sup>90</sup> . Para pacientes com diagnóstico há menos de 3 meses e sem fator de risco recomenda-se iniciar o tratamento exclusivamente com mudanças de modo de vida, incluindo controle de peso, alimentação adequada e saudável e prática de atividade física, e avaliar a resposta terapêutica em 3 meses. Se não houver resposta adequada, deve-se iniciar cloridrato de metformina em monoterapia<sup>91</sup> .  
Para pacientes diagnosticados a 3 meses ou mais ou com fatores de risco, o tratamento medicamentoso associado a mudanças de modo de vida deve ser iniciado precocemente, visando a evitar a inércia terapêutica, uma vez que o atraso da introdução e intensificação da terapia medicamentosa é um fator determinante para a evolução de complicações crônicas<sup>92,93</sup> . O uso do cloridrato de metformina em pacientes do Reino Unido com sobrepeso e obesidade desde o diagnóstico da doença, comparado apenas à mudança do modo de vida, resultou em uma redução de 32% de desfechos relacionados ao DM2, 36% de mortalidade por todas as causas e 36% menos infarto do miocárdio<sup>94</sup> .  
Assim, a estratégia inicial de escolha do tratamento medicamentoso é o cloridrato de metformina em monoterapia. Este medicamento pode ser associado a outros hipoglicemiantes, no caso de falha ao atingir as metas terapêuticas (sendo avaliado o estado glicêmico após 3 meses a 6 meses no máximo)<sup>90</sup> . Em pacientes com valores de HbA1c maior do que 7,5% ao diagnóstico de DM2, pode-se considerar iniciar o tratamento com terapia de combinação, sendo sugerido como tratamento de segunda linha as sulfonilureias, os iSGLT2 ou as insulinas<sup>91</sup> . A **Figura 2** apresenta o fluxograma de tratamento para indivíduos com idade igual ou maior a 18 anos com DM2.  
Gestantes com DM2 pré-gestacional devem interromper tratamento não insulínico antes ou logo após o início da gestação, quando estiver garantida a imediata substituição pela insulinoterapia<sup>22,23</sup> . Ressalta-se a importância de alcançar e manter os níveis seguros de glicemia antes da concepção e durante a gravidez, a fim de reduzir o risco de malformações congênitas, diminuir o risco de parto prematuro e reduzir a internação do recém-nascido em unidades de terapia intensiva neonatal.  
21  
<!-- Start of picture text -->
| na omductdin nto<br>Ina rr<br>dena vaidarian,<br>ieaewow Volosetnmeee<br>Sim _/Atingiu ota Nao<br>torapéutica®# ‘Sim pingiu meta terapéuticat* NBO<br>| eSie | |barreestilode vida — BEES |<br>I —_o<br>Si (Anjum ons’ i<br>romero<br>= ee _ SS ea<br>nte Apresenta de dapagiiiozina??critérios pare<br>sim ‘Atingiu meta terapéutica®* Nao tesa tc<br>Montorar , |<br>Si ‘ating.¢ toleroumeta trapsutca®® dapaglifiozina? M0 alier<br>=<br>=e<br>— unseen ;<br>—<br>ae<br><!-- End of picture text -->  
**Figura 2** . Fluxograma de tratamento para indivíduos com idade igual ou maior a 18 anos com diabete melito tipo 2.  
**Fonte:** Elaboração própria.  
Há ainda hipoglicemiantes, como inibidores de alfa-glicosidase (acarbose), inibidores da dipeptidil peptidase 4 (DPP4), agonistas do GLP-1, meglitinidas e tiazolidinedionas, que não estão incorporados ao SUS<sup>92</sup> . As metas de controle glicêmico podem ser atingidas com o uso dos medicamentos disponíveis no SUS, associados a medidas terapêuticas não medicamentosas efetivas.  
22

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.3.1. Cloridrato de metformina -->
O cloridrato de metformina é indicado como primeira opção terapêutica no tratamento de pacientes com DM2, como forma de melhorar o controle da glicemia e prevenir complicações. Pertence à classe das biguanidas e reduz a glicose por múltiplos mecanismos, entre eles a diminuição da produção hepática de glicose e aumento da captação muscular de glicose<sup>95</sup> .  
Sugere-se iniciar o tratamento com doses baixas (500 mg ou 850 mg), em dose única diária, durante ou após as refeições (café da manhã ou jantar), para prevenir sintomas gastrointestinais. Após 5 a 7 dias, caso não surjam eventos adversos, pode-se aumentar para 500 mg ou 850 mg, duas vezes ao dia, durante ou após as refeições (café da manhã e jantar). Na presença de efeitos gastrointestinais, a dose poderá ser diminuída e, após 3 a 6 meses, conforme necessidade, uma nova tentativa de aumentá-la poderá ser realizada. A dose máxima terapêutica é de 850 mg no café, almoço e jantar, totalizando 2.550 mg por dia (dose máxima efetiva).  
Em indivíduos idosos, também é considerada o medicamento de primeira escolha, pois apresenta boa eficácia e segurança, baixo risco de hipoglicemia, além de trazer benefícios na redução do risco cardiovascular<sup>96</sup> .  
Em geral, o medicamento é seguro e bem tolerado. Contudo, é contraindicado em pacientes com insuficiência renal (TFG menor que 30 mL/min/1,73 m<sup>2</sup> )<sup>97</sup> ou qualquer situação de maior risco de hiperlactatemia, como insuficiência hepática descompensada, sepse e hipotensão. Na maioria das vezes, o uso de cloridrato de metformina deve ser suspenso em caso de internação hospitalar. O cloridrato de metformina deve ser mantida quando o paciente inicia o uso de insulina, a fim de manter seus benefícios glicêmicos e metabólicos, a não ser que tenha alguma contraindicação ou efeito adverso que não seja tolerado<sup>92,93</sup> . Nas pessoas idosas, desconforto gastrointestinal, sensação de boca metálica, náuseas, diarreia e emagrecimento progressivo podem ser efeitos adversos comuns e potencialmente severos. Nesses casos, considerar a substituição por formulações de liberação prolongada ou a desprescrição em caso de intolerância severa especialmente se associada a risco nutricional<sup>98</sup> .  
Não se deve usar mais de 1 g/dia em pessoas com TFG 30 a 45 mL/min/1.73 m² e deve ser suspensa quando TFG < 30 mL/min/1.73 m². É um medicamento altamente eficaz, reduzindo HbA1c em 1,5% a 2% e glicemia de jejum em 60 mg/dL a 70 mg/dL, com baixo risco de hipoglicemia, sem associação com ganho de peso e baixo custo<sup>99,100</sup> .  
Seus potenciais eventos adversos são<sup>99</sup> : Gastrointestinais: diarréia, náuseas, vômitos, hipermeteorismo, dor abdominal, distensão abdominal, constipação, dispepsia, alteração de paladar, flatulências; deficiência de vitamina B12; acidose láctica (rara).  
A versão de liberação estendida reduz o risco de eventos adversos gastrointestinais e geralmente é mais bem tolerada, estando disponível no programa Farmácia Popular do Brasil (PFPB). O início em dose baixa, com titulação progressiva, reduz o risco desses eventos adversos. O cloridrato de metformina é contraindicado se houver sensibilidade ao medicamento, doença renal com TFG < 30 mL/min/1,73 m², insuficiência cardíaca congestiva, alcoolismo, sepse ou outros quadros clínicos graves, doença hepática grave ou lactação<sup>99,100</sup> .  
23

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.3.2. Sulfoniluréias -->
As sulfoniluréias são secretagogos de insulina. Geralmente indicada como associação a outros agentes hipoglicemiantes, em especial ao cloridrato de metformina, quando for necessária a intensificação terapêutica para controle glicêmico. Esta classe medicamentosa promove a liberação de insulina a partir das células beta pancreáticas, o que também aumenta o risco de hipoglicemia. A glibenclamida e a gliclazida são as sulfonilureias disponíveis no SUS. A gliclazida de liberação prolongada (MR) (30 e 60 mg/dia, com uso uma vez ao dia e dose máxima de 120 mg/dia), e glibenclamida (5 mg/dia, com uso uma a duas vezes ao dia e dose máxima de 20 mg/dia) possuem eficácia similares. Contudo, a gliclazida liberação pronlongada está associada a uma menor taxa de hipoglicemia, sendo preferível em pacientes com episódios de hipoglicemia recorrente ou risco aumentado de hipoglicemia<sup>101</sup> .  
As sulfoniluréias são altamente eficazes, levando a uma redução de glicemia de jejum em 60 mg/dL a 70 mg/dL e de HbA1c em 1,5% a 2,0%. Entretanto, apresentam risco significativo de hipoglicemia (especialmente a glibenclamida), além de ganho de peso. São contraindicadas se houver TFG < 30 mL/min/1,73 m² (gliclazida Modified Realease – liberação modificada) pode ser considerada em pessoas com DM2 e DRD, com TFG menor que 30 mL/min/1,73m<sup>2</sup> desde que haja muita cautela e em doses reduzidas), insuficiência hepática, sinais de deficiência grave de insulina, infecções graves, gestação<sup>99,100</sup> . A gliclazida MR pode ser utilizada em pacientes com insuficiência renal leve a moderada, sob monitoramento cauteloso. Assim como o cloridrato de metformina, na maioria das vezes, não devem ser usadas em pacientes internados.  
Embora associadas a eventos hipoglicêmicos, são medicamentos bem tolerados, possuem baixo custo e segurança cardiovascular. Para pacientes idosos, recomenda-se utilizar preferencialmente gliclazida, visando a diminuição do risco de hipoglicemia<sup>102</sup> . Nas pessoas idosas, as sulfonilureias de ação curta devem ser evitadas, além das sulfonilureias de ação prolongada, devido ao maior risco de hipoglicemia e de mortalidade cardiovascular e por todas as causas em idosos. Nas circunstâncias em que for usada uma sulfonilureia, as formas de ação curta são preferidas às de ação prolongada, para reduzir o risco de hipoglicemia prolongada<sup>103</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.3.3. Inibidores do cotransportador sódio-glicose 2 (iSGLT2) -->
Essa classe de medicamentos está indicada em associação ao cloridrato de metformina ou a outros hipoglicemiantes. Os iSGLT2 agem principalmente diminuindo a reabsorção renal de glicose, consequentemente aumentando a excreção urinária, favorecendo a redução da glicemia independentemente da secreção endógena ou da ação da insulina, além de perda de peso<sup>104</sup> .  
Esses medicamentos inibem a absorção de glicose e sódio no túbulo proximal por meio da inibição do SGLT2, levando à glicosúria e natriurese<sup>99,100</sup> . Essa classe de medicamentos leva a uma redução de glicemia de jejum de 30 mg/dL e da HbA1c de 0,5% a 1,0%. Em pessoas com doença cardiovascular, há redução de eventos cardiovasculares e de mortalidade cardiovascular, redução de hospitalização ou descompensação da insuficiência cardíaca. Os iSGLT2 raramente causam hipoglicemia e levam a uma redução discreta de peso e da pressão arterial. Nos pacientes com DM2, têm benefícios na preservação de função renal<sup>99,100</sup> . Adultos com DM2 que apresentam diagnóstico simultâneo com doença renal crônica (DRC) crônica<sup>105</sup> ou insuficiência cardíaca<sup>106</sup> devem ser assistidos também conforme recomendação dos respectivos Protocolos vigentes.  
O medicamento da classe dos iSGLT2 disponibilizado pelo SUS para a intensificação do tratamento é a dapagliflozina. O uso da dapagliflozina é recomendado para DM2, em indivíduos  
24  
com necessidade de segunda intensificação de tratamento com idade ≥ 40 anos e doença cardiovascular estabelecida (infarto agudo do miocárdio prévio, cirurgia de revascularização do miocárdio prévia, angiosplastia prévia das coronárias, angina estável ou instável acidente vascular cerebral isquêmico prévio, ataque isquêmico transitório prévio e insuficiência cardíaca com fração de ejeção abaixo de 40%), ou; homens ≥ 55 anos ou mulheres ≥ 60 anos com alto risco de desenvolver doença cardiovascular, definido como ao menos um dos seguintes fatores de risco cardiovascular: hipertensão arterial sistêmica, dislipidemia ou tabagismo<sup>107</sup> .  
A dose recomendada da dapagliflozina é de 10 mg uma vez ao dia, não sendo indicada para pacientes com TFG abaixo de 25 mL/min/1,73 m<sup>2</sup> , destacando que a eficácia deste medicamento é menor em pacientes com insuficiência renal moderada a grave (taxa de filtração glomerular menor do que 45 mL/min/1,73m<sup>2</sup> ) ou com falência renal<sup>108</sup> . Em pessoas idosas, recomenda-se que os inibidores do cotransportador 2 de sódio-glicose, enquanto classe, sejam usados com cautela, pois os idosos correm maior risco de cetoacidose diabética euglicêmica e de infecções urogenitais, principalmente as mulheres no primeiro mês após o início do tratamento<sup>103</sup> <mark>.</mark>  
Os eventos adversos potenciais dos iSGLT2 são infecções do trato geniturinário, cetoacidose euglicêmica (embora o risco em pessoas com DM2 sem complicações agudas e sem fatores de risco para cetose seja baixo), fasciite necrotizante perineal e depleção de volume intravascular. A dapagliflozina não deve ser iniciada se a TFGe for < 25 mL/min/1,73 m<sup>2 99,100</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.3.4. Insulinas -->
A insulina é indicada para o tratamento da hiperglicemia quando houver falha no controle glicêmico com hipoglicemiantes orais disponíveis, podendo ser prescrita como parte de esquema combinado ao longo do tratamento. Os hipoglicemiantes orais podem ser mantidos, a critério médico, principalmente o cloridrato de metformina nos casos com resistência à insulina. Deve-se considerar hiperglicemia (HbA1c > 9% ou glicemia jejum ≥ 300 mg/dL), sintomas de hiperglicemia aguda (poliúria, polidipsia, perda ponderal) ou a presença de intercorrências médicas e internações hospitalares decorrentes do DM2, para a indicação de insulina basal e _bolus_<sup>100,109</sup> .  
Ressalta-se que as insulinas basais são a insulina humana NPH e as insulinas análogas de ação prolongada, administradas para manterem os níveis de glicemia adequados entre as refeições e o período do sono. Já as insulinas _bolus_ são a insulina humana regular e as insulinas análogas de ação rápida, cujo objetivo é cobrir as necessidades de insulina no período após as refeições e para corrigir hiperglicemias. Portanto, as insulinas _bolus_ não tem relação com a forma de administração, em _bolus_ , mas sim com a ação rápida.  
Neste momento terapêutico é necessário reforço na educação em diabetes, com foco na técnica de administração de insulina, automonitorização glicêmica, alimentação adequada e saudável, prática de atividade física e identificação e tratamento de hipoglicemias<sup>100,109</sup> . Os eventos hipoglicêmicos são mais frequentes quando se inicia e intensifica-se a insulinoterapia<sup>110</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.3.4.1. Insulina humana NPH -->
Em pacientes em tratamento ambulatorial, recomenda-se iniciar o tratamento com a insulina basal NPH, podendo ser adicionada ao tratamento com hipoglicemiante oral já estabelecido, se não houver contraindicação de seu uso (como em caso de falência pancreática ou uso de esquema basal/ _bolus_ ). Recomenda-se que ao início a administração da insulina humana  
25  
NPH seja realizada à noite, antes de dormir (próximo às 22 horas ou 8 horas antes do desjejum), com uma dose inicial de 10 U ou 0,1 U/kg a 0,2 U/kg, ajustando-se em 2 U, a cada 3 dias, até atingir a meta estabelecida para a glicemia em jejum (80 mg/dL a 130 mg/dL). Se o paciente apresentar uma glicemia de jejum inferior a 70 mg/dL ou hipoglicemia noturna, diminui-se 2 U a 4 U<sup>109,111,112</sup> . Quando a glicemia de jejum estiver próxima do limite superior da meta glicêmica, recomenda-se avaliar o perfil glicêmico no período do sono. Essas aferições auxiliam no ajuste da dose de insulina humana NPH administrada antes de dormir e contribuem para a prevenção da hipoglicemia noturna<sup>112</sup> . Neste caso, para os idosos comprometidos ou muito comprometidos, a meta de glicemia de jejum é de até 180 mg/dL, enquanto para os demais permanece em 130 mg/dL<sup>106,108,109</sup> .  
Aqueles pacientes com DM2 recebendo tratamento combinado com antidiabéticos orais e insulina antes de dormir, mas que não atingem as metas de HbA1c e que apresentam glicemias de jejum dentro do alvo (80 mg/dL - 130 mg/dL) poderão se beneficiar da adição da segunda dose da insulina humana NPH, a ser administrada antes do desjejum. Desta forma, 80% da dose total de insulina humana NPH administrada antes de dormir deve ser dividida para administração de 2/3 da dose pela manhã e 1/3 da dose antes de dormir. A segunda dose da insulina humana NPH deverá ser titulada de acordo com a glicemia antes do jantar, aumentando 1 U a 3 U, a cada 3 dias, até atingir o alvo da glicemia antes do jantar, entre 80 mg/dL e 130 mg/dL. Portanto, para ajustes das duas doses de insulina humana NPH, o paciente deverá mensurar a glicemia capilar em jejum e antes do jantar<sup>73</sup> .  
É importante identificar os pacientes que estão em uso de dose excessiva de insulina basal, utilizando os seguintes critérios: dose de insulina basal > 0,5 U/kg/dia; decaimento da glicemia entre a hora de dormir e o despertar > 50 mg/dL; glicemia pós-prandial > 180 mg/dL; HbA1c acima da meta terapêutica, com glicemia de jejum na meta; presença de hipoglicemia com ou sem sintomas e grande variabilidade glicêmica<sup>113</sup> .  
Quando as doses de insulina humana NPH antes de dormir e ao acordar tiverem sido tituladas, sugere-se a avaliação da automonitorização glicêmica, com medidas da glicemia antes das 3 refeições principais, e em 1 dia ou 2 dias do mês realizar o esquema de sete ou oito glicemias/dia (antes e 2 horas após o café da manhã, almoço e jantar, antes de dormir [a glicemia antes de dormir substitui a pós-jantar] e madrugada e antes do café da manhã seguinte), em dias típicos da rotina do paciente<sup>109</sup> A percepção de hiperglicemia pós-prandial (> 180 mg/dL), na presença de glicemia pré-prandial adequada, sugere a necessidade de introdução da insulina _bolus_<sup>109</sup> .  
A dose total diária de insulina para pessoas com DM2, somadas as doses de insulina basal e _bolus_ , deve variar em torno de 0,5 U/kg/dia a 1,0 U/kg/dia, chegando a 1,5 U/kg/dia naqueles mais obesos e com maior resistência à insulina<sup>109,111</sup> . Considerando que a dose total diária de insulina deve ser dividida em 50% basal e 50% _bolus_ , a dose diária máxima de insulina basal deverá ser < 0,5 U/kg/dia, em pacientes plenamente insulinizados, sendo a dose máxima de insulina basal de 0,75 U/kg/dia reservada, apenas, para aqueles com maior obesidade e resistência à insulina<sup>111,114</sup> .  
Durante a conversa com o paciente, é fundamental abordar alguns pontos importantes relacionados à insulinização: Esse processo será iniciado com doses baixas, que serão aumentadas gradativamente de acordo com os níveis de glicemia de jejum, o que contribui para a redução do risco de hipoglicemia. No entanto, será necessário ajustar essas doses ao longo do tempo, aumentando até que se alcance à glicemia de jejum adequada. Para isso, a realização de glicemias em horários previamente determinados será essencial, pois permitirá identificar a dose ideal de insulina. Além disso, deve-se considerar a possibilidade de seguir com a autotitulação da insulina basal, conforme a evolução do tratamento e a autonomia do paciente<sup>109</sup> .  
26

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.3.4.2. Insulinas análogas de ação prolongada (AIAP) -->
As insulinas análogas de ação prolongada (AIAP) atualmente disponíveis no Brasil são as insulinas glargina 100 U, degludeca 1oo U e glargina 300 U. O uso de AIAP está associado a menor risco de ocorrência de qualquer evento de hipoglicemia e hipoglicemia noturna em comparação à insulina humana NPH. No entanto, apenas a insulina degludeca demonstrou menor risco de episódios de hipoglicemia grave quando comparada à insulina humana NPH e glargina<sup>115</sup> .  
As populações mais beneficiadas com o uso dos AIAP e que, portanto, devem ser priorizadas para uso do medicamento, são:  
- a. Pacientes com maior risco de hipoglicemias noturnas e graves (degludeca);  
- b. Pacientes com IMC < 30 kg/m<sup>2116</sup> ;  
- c. Pacientes idosos<sup>116</sup> ;  
- d. Pacientes com grande variabilidade glicêmica<sup>116</sup> ;  
- e. Pacientes com redução das funções renal e hepática;  
- f. Mulheres com DM2 gestantes;  
- g. Pacientes com dificuldades para administração de múltiplas doses diárias de insulina basal.  
Sugere-se iniciar e titular os AIAP da mesma forma da insulina humana NPH. Geralmente, não há necessidade da 2ª dose diária de AIAP para pessoas com DM2. A substituição da insulina humana NPH, administrada 1 vez ao dia, por glargina pode ser realizada em esquema de 1 U:1 U. As pessoas que faziam uso prévio da insulina humana NPH, duas ou mais vezes ao dia, devem ter a dose total reduzida em 20% e administrada 1 vez ao dia, podendo ser administrada pela manhã ou à noite<sup>117</sup> . Recomenda-se o uso de glargina para indivíduos com hipoglicemias noturnas e graves, enquanto a degludeca é recomendada como uma opção terapêutica para aqueles indivíduos que continuam apresentando hipoglicemias após o uso de glargina.  
O principal evento adverso ao uso da insulina é a hipoglicemia, com risco de perda de consciência em casos graves. Portanto, a orientação do paciente sobre os sintomas e controle da hipoglicemia é imprescindível e deve ser fornecida por todos os profissionais da saúde, inclusive, envolvendo a família quando pertinente. A avaliação da excursão glicêmica noturna, antes de dormir, durante a madrugada e ao acordar, permitirá a identificação de hipoglicemia noturna ou do risco aumentado de hipoglicemia noturna, causado por um grande decaimento da glicemia (maior que 60 mg/dL) neste período.  
Há diferentes formas de proceder um adequado tratamento com insulina. A estratégia recomendada pelo presente PCDT é apresentada na **Figura 3** . Alternativas, que consideram o cálculo de insulina _bolus_ , são igualmente válidas. No Material Suplementar são apresentadas as orientações em relação à aplicação de insulina, locais para aplicação da insulina, como preparar a insulina e como aplicar a insulina, respectivamente.  
8.3.4.3. Insulina Bolus (Insulina humana regular e Insulinas Análogas de Ação Rápida - AIAR)  
Insulina humana regular  
A associação de insulina _bolus_ à insulina basal é indicada para pacientes com HbA1c acima da meta terapêutica, glicemia em jejum adequada e em uso de duas doses diárias da insulina humana NPH (ao acordar e antes de dormir). Sugere-se a realização de 6 glicemias ao dia (antes  
27  
e 2 horas após o café da manhã, o almoço, e o jantar), para identificar a maior glicemia pósprandial (2 horas após o início da refeição) do dia, na qual deverá ser adicionada a primeira dose de insulina _bolus_ , entre 3 U e 4 U. Esta dose deverá ser titulada até atingir glicemia pós-prandial entre 90 mg/dL e 180 mg/dL, com aumentos de 1 UI, duas vezes por semana<sup>109</sup> . A segunda e a terceira dose da insulina pode ser adicionada às refeições cujas glicemias pós-prandiais sejam > 180 mg/dL<sup>118</sup> . É importante observar a necessidade de reduzir a dose de insulina antes de dormir, após adequação dos níveis de glicemia após o jantar.  
Além de estabelecer as doses fixas prandiais, os pacientes em uso de insulina _bolus_ (insulina humana regular e insulina análoga de ação rápida) e que realizam automonitorização da glicemia, também, poderão se beneficiar do esquema de correção de hiperglicemia de acordo com a glicemia capilar realizada antes das refeições principais<sup>119</sup> . Pode ser utilizado inicialmente, um fator de correção (FC) de 50, ou seja, administrar 1 U de insulina humana regular para cada 50 mg/dL acima do valor máximo do objetivo glicêmico. Outra possibilidade, para determinar o FC, é utilizar a fórmula FC = 1800/DTDI, onde DTDI significa dose total diária de insulina<sup>119</sup> . O **Quadro 7** exemplifica o cálculo de dose da insulina _bolus_ (insulina humana regular) a ser administrada antes da refeição para um paciente idoso que está com a glicemia pré-prandial de 190 mg/dL, faz uso de 7 U de insulina prandial antes do almoço, tem como limite superior do objetivo glicêmico pré-prandial 130 mg/dL e utiliza fator de correção de 50<sup>119</sup> .  
**Quadro 7.** Cálculo da dose de insulina _bolus_ a ser administrada antes do almoço.  
|**Cálcul**|**o da dose* **|
|---|---|
||Glicemia atual (GA) = 190 mg/dL|
||Limite superior do objetivo glicêmico (LSOG) = 130 mg/dL|
||Fator de correção (FC) = 50|
||Bolus de correção = GA - LSOG/FC|
||Bolus de correção = 190 - 130/50 = 60/50 = 1,2 U|
||Dose de_bolus_ (prandial + correção)= 7 + 1,2 =8,2 =8,0 U.|  
**Nota** : * cálculo sugerido baseado _Diabetes Coalition of California_ (2010)<sup>119</sup> . **Legenda:** U: unidade. **Fonte** : elaboração própria.  
Para aqueles pacientes que não conseguem realizar cálculos, pode-se oferecer algoritmo de correção, como o mostrado abaixo. Deve-se reforçar com o paciente que este algoritmo define o _bolus_ de correção, que deverá ser somado ou subtraído do _bolus_ prandial<sup>26</sup> ( **Quadro 8** ).  
**Quadro 8** . Algoritmo de correção.  
|**Algoritmo de correção***<br>|
|---|
|< 50 = - 2U|
|< 70 = - 1 U|
|70 a 130 = 0|
|131 – 180 = + 1U|
|181 – 230 = + 2 U|
|231 – 280 = + 3 U|
|281 – 330 = + 4 U|
|> 330 = +5 U|  
**Nota** : * algoritmo sugerido baseado em _Diabetes Coalition of California_ (2010)<sup>119</sup> . **Legenda:** U: unidade. **Fonte** : elaboração própria.  
28  
Recentemente, as insulinas análogas de ação rápida (AIAR) e as insulinas análogas de ação prolongada (AIAP) foram incorporados ao tratamento do DM2 disponível no SUS, conforme Portaria SECTICS/MS nº 948/2025 e Portaria SECTICS/MS nº 949/2025, respectivamente.  
Insulinas análogas de ação rápida (AIAR)  
Estas insulinas permitem o controle da glicemia pós-prandial, com níveis significativamente mais baixos em todas as refeições (café, almoço e jantar)<sup>120</sup> , reduzindo a variabilidade glicêmica, o hiato entre a administração da insulina _bolus_ e o início da refeição, contribuindo para a adesão ao tratamento. A insulina humana regular deve ser administrada 30 minutos antes das refeições e as insulinas análogas de ação rápida entre 15 minutos à imediatamente antes das refeições<sup>121</sup> .  
As populações mais beneficiadas com o uso dos AIAR e que, portanto, devem ser priorizadas para uso do medicamento, são<sup>122</sup> :  
- a. Pacientes com hipoglicemias graves;  
- b. Pacientes com hipoglicemias assintomáticas<sup>122</sup> ;  
- c. Pacientes idosos<sup>116</sup> ;  
- d. Pacientes com IMC < 30 kg/m<sup>2 116</sup> ;  
- e. Pacientes com redução das funções renal e hepática;  
- f. Pessoas com diabetes com controle glicêmico pós-prandial inadequado;  
- g. Mulheres com DM2 gestantes;  
- h. Pessoas com DM2 e grande variabilidade glicêmica.  
Os AIAR devem ser iniciados e titulados da mesma forma da insulina humana regular. Todos os AIAR (asparte, lispro e glulisina) são substituíveis em esquema de 1 U:1 U. A substituição da insulina humana regular pelos AIAR, também será de 1U:1U<sup>121</sup> .  
29  
<!-- Start of picture text -->
Insiso com Momaiamaom mtucorenses Ate» 0%des lem 0 rman  oom 230 osaares  mag cents srtames de9orciOM gi" oo<br>Iniciar com*oUeu03insulina humana?°Ungo02 NPHNg & noite<br>Aare apr om 90a)<br>para<br>‘Ament2 Ua cota 3s a ang ama para leona oan!<br>Nontarar a aia<br>Na press ce poco ote olaman daw ove ae<br>2 Und Uo iattra nit humana NP po AAP eee<br>ctconsEEeign, <zo.ot.co]EE | CicaniaRecmsesverseemace <0sum ng urna die» ||| | haunatumdranr Adonarsopnda‘administrada antesdoveser ca |___| | SubstAAPontainuina o marme numaraNPHde peasola|<br><desjejurn” do “Ministériopubicagbes da Sade,complements, e titular a suadodose<br>[ner onesie ras] [Emini non rn cert<br>de2Ua4U‘wadeaté atingir a meta de 2U atéventi atingir a meta = corePaciente gtaatingiy bead<br>no sar a na wand Fomenaranea| ed[ sonar. | \ an<br>sconparnrmano crateadn meen aptconprmaraarrcua cata Smoset EEsconpamerarassmeses, [NP Mpuluemiapte-oande(>\Laas |<br>scanpatnr‘Mantes condiere; & pussTi‘errs r  aegularou clei neersRane AIAR, conforme 3<br>Mitra Sia"<br>Ascotounrita oreo ae 6Ue gosta wie8.20<br>seprandoteneeTara dose ab angSo od cara 10<br>_mgidL.,hsairgr veo com arta aumentos posal apede 1 U,<br>Legend Heat: nanogai cad ON: bee eto to 2 AAP: hana nop<br>feta do 80 oogRs AAR rainsaosdeak<br>Poniosuces incase pcan apie poli, oslo ers de as rs nono pers penee<br>|"ferecdrana[Asho Os ruirastorana tone hipoglicemiantesconpomertacrn NPMorais spodem a rananaeseruna oomrasmantides,putea ear pliesexcetogoonnos ercasossuena de eoyonesrr contraindicagaouraou auséinciaroot de indicagdedao potas clinica (porori exemplo, pacar falencia pancredticacaeou uso cic do esquemapeso basal/bolus, 8 situagbes em que nal<br>[cota ets apse crore pops<br>aint gga oma pesto J cams gave cunas wc po aoc<br>|} Paces 2%Aarau a ov om ta ou2oie d w e sberdonsiPrion nanarate NPM coniatomnt com r s. dea n tbéns do r dvnsunats er vi para fe dk;amar masghoun Geno 20aga da mna poamets mar de HOA © V2 aUe donsr e etamain akandomi jospundrt dome6 G ver h o .<br>lamonacaeta’| Soars ucotatodomoss gheanaUUs  eear pscatapa Sax sonea6(2 e asngnaosooohumananicamass GaNENeo) ae omGoso Sot da, ra.tgSor ngeed s er adeonodedonee a pmaa icra dose spedows9 oar bbs<br><!-- End of picture text -->  
**Figura 3.** Fluxograma para uso de insulina em pacientes com diabete melito tipo 2.  
**Fonte:** Elaboração própria.  
Nota: Este PCDT preconiza o uso de todas as tecnologias em saúde incorporadas ao SUS para o tratamento do DM2. No entanto, de modo complementar, o Ministério da Saúde publicará Notas Técnicas específicas para orientar a dispensação das insulinas análogas de ação rápida e de ação prolongada, conforme planejamento da Assistência Farmacêutica e considerando a inserção gradual desses medicamentos na Rede de Saúde.  
30

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.4. Tratamento de complicações agudas do diabete melito tipo 2 -->
As complicações agudas da DM2 podem ser a hipoglicemia (glicemia aleatória inferior a 70 mg/dL) ou a descompensação hiperglicêmica aguda, que pode resultar em complicações mais graves como cetoacidose diabética e síndrome hiperosmolar hiperglicêmica não cetótica. Para ambas as complicações, há necessidade de intervenção. A depender da gravidade, a pessoa deve ser encaminhada para o serviço de emergência, de acordo com a regulação local<sup>26,73</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: Hipoglicemia -->
A hipoglicemia é a complicação aguda mais frequente e uma das principais emergências médicas relacionada ao diabetes. Está associada a morbidade e mortalidade consideráveis, sendo considerado o principal fator limitante para o controle glicêmico de pessoas com DM1 e DM2. A hipoglicemia pode ocorrer em decorrência da administração excessiva de doses de insulina ou de outros hipoglicemiantes, da diminuição da ingestão alimentar ou do aumento da atividade física. O nível de glicose que produz sintomas de hipoglicemia varia de pessoa para pessoa e até para o mesmo indivíduo, em diferentes circunstâncias. Os sinais e sintomas associados à hipoglicemia estão descritos no **Quadro 9** . Quando as hipoglicemias não são identificadas e tratadas adequadamente, podem evoluir para quadros mais graves, como comprometimento cognitivo, convulsão, coma e morte<sup>123,124</sup> .  
**Quadro 9.** Sinais e sintomas de hipoglicemia.  
||**Autonômicos (adrenérgicos)**|**Neuroglicopênicos**|
|---|---|---|
|||<br>Fraquez, sonolêcia|
||Sudorese|<br>Dificuldade para pensar e falar, fala|
||Tremores ou sua sensação|arrastada|
||Palpitações, taquicardia|<br>Irritabilidade|
||Ansiedade|<br>Tontura|
||Fome|<br>Parestesia|
||Aumento da pressão arterial|<br>Déficit nerológico focal transitório|
||Palidez|<br>Confusão|
||Midríase|<br>Convulsão|
|||<br>Coma|  
**Fonte:** Adaptado de Paluchamy et al., 2019<sup>123</sup> .  
A hipoglicemia não reconhecida ou assintomática caracteriza-se pela ausência de sinais ou sintomas autonômicos que normalmente servem de alerta para a queda dos níveis de glicose. Essa condição é frequentemente relacionada ao comprometimento do sistema nervoso autônomo, devido a episódios recorrentes de hipoglicemias. Por ser uma condição funcional, é considerada reversível. A falha da resposta autonômica à hipoglicemia resulta da combinação da ineficácia dos mecanismos contrarreguladores, que pode estar relacionada à neuropatia autonômica, e do comprometimento dos sintomas de hipoglicemia, causado por episódios recentes e recorrentes de hipoglicemias<sup>125</sup> .  
No **Quadro 10** apresenta a classificação das hipoglicemias e o tratamento sugerido, de acordo com o nível de hipoglicemia.  
31  
**Quadro 10.** Classificação da gravidade das hipoglicemias no diabetes.  
|**Nível**|**Glicemia (mg/dL)**|**_Status_**|**Observações**<br>|
|---|---|---|---|
|1|≥ 54 e < 70|Alerta|É importante identificar e tratar, devido ao<br>risco de queda progressiva da glicemia,<br>especialmente<br>em<br>pacientes<br>com<br>hipoglicemias não reconhecidas.|
|2|< 54|Clinicamente<br>importante|Episódios repetitivos podem comprometer o<br>nível de consciência, aumentando o risco de<br>hipoglicemia grave e rebaixando os limites<br>de sua cognição.|
|3|Independentemente<br>do valor de glicemia|Emergência|Comprometimento grave cognição ou<br>coma,<br>requerendo<br>assistência<br>para<br>tratamento.|  
**Fonte:** _International Hypoglycaemia Study Group_ , 2017<sup>126</sup> .  
O tratamento das hipoglicemias deve ocorrer conforme seu nível:  
**- Hipoglicemia nível 1:** pode ser tratada com 15 g de carboidrato de absorção rápida que equivale a 1 colher de sopa de açúcar ou mel, 150 mL de suco de laranja, 150 mL de refrigerante comum, 1 fruta (banana/pera/maçã) ou 4 bolachas maisena. Alimentos que contêm gordura retardam a resposta glicêmica aguda. É fundamental controlar a quantidade de carboidratos ingeridos durante o tratamento da hipoglicemia, a fim de evitar picos de hiperglicemia subsequentes. Após a administração de 15 g de carboidratos, espera-se que os níveis de glicose no sangue comecem a subir dentro de 15 minutos. Se, após esse intervalo, a glicemia não estiver normalizada, recomenda-se repetir a ingestão de 15 g de carboidratos<sup>53</sup> .  
**‒ Hipoglicemias nível 2:** é caracterizada por valores de glicemia abaixo de 54 mg/dL, representando o limiar crítico para ocorrência de sintomas neuroglicopênicos, como dificuldade de concentração, confusão mental, alteração na visão e tonturas. Essa condição exige uma intervenção mais imediata. Caso o paciente esteja consciente, recomenda-se a administração de 30 g de carboidratos de absorção rápida. Entre as opções estão o mel, açúcar ou formulações de carboidrato em gel<sup>53</sup> .  
**‒ Hipoglicemias nível 3:** o evento de hipoglicemia grave é caracterizado por estados mentais ou físicos alterados, sem valores de glicemia específicos, indicando-se a intervenção da emergência médica<sup>53</sup> .  
Adultos com idade mais avançada apresentam maior risco de hipoglicemia por diversas razões, incluindo, a maior necessidade de terapia com insulina, deficiência de insulina e a insuficiência renal progressiva. Além disso, são propensos a maior deficiência cognitiva, causando dificuldade em atividades complexas de autocuidado (por exemplo, monitoramento da glicose, ajuste das doses de insulina, alimentação adequada e saudável, entre outros). Esses déficits cognitivos têm sido associados a um risco aumentado de hipoglicemia; e a hipoglicemia grave tem se associado a um risco aumentado de demência. Os eventos hipoglicêmicos devem ser cuidadosamente monitorados e evitados, enquanto os alvos glicêmicos e as intervenções medicamentosas podem precisar de ajustes<sup>64</sup> . Para a prevenção de hipoglicemia noturna, recomenda-se o consumo de um lanche antes de dormir, que contenha carboidratos, proteínas e gordura (por exemplo: copo de leite)<sup>64</sup> .  
32

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.5. Tratamento de complicações crônicas do diabete melito tipo 2 -->
Em longo prazo, o DM2 pode desencadear complicações crônicas microvasculares (DRD, neuropatia diabética e retinopatia diabética) e macrovasculares (infarto agudo do miocárdio, acidente vascular cerebral e doença vascular periférica)<sup>127</sup> .  
Entre as complicações microvasculares, o tratamento da DRD baseia-se no controle adequado dos níveis de glicose e da pressão arterial. Outras intervenções incluem o controle da dislipidemia<sup>43</sup> , da albuminúria e a recomendação de cessação do tabagismo<sup>75,76</sup> . Diabetes é a causa mais comum de DRC, responsável por aproximadamente 50% dos novos casos de terapia de substituição renal na maioria dos países desenvolvidos<sup>128</sup> . Os dados do censo da Sociedade Brasileira de Nefrologia de 2023 indicam que 32% dos pacientes em diálise devido à DRC no Brasil, apresentam diagnóstico do diabetes<sup>129</sup> . A etnia é um fator importante relevante na predisposição à DRD, sendo os indivíduos asiáticos particularmente suscetíveis, a condição afeta 60% dos hipertensos com DM2 nessa população<sup>130</sup> . Informações sobre o controle dos pacientes com DRD estão disponíveis nos PCDT relacionados à DRC vigentes<sup>112</sup> .  
O rastreamento inicial da DRD deve ser realizado por meio de uma amostra de urina aleatória para cálculo da Razão Albumina Creatinina (RAC) e estimativa da TFG, obtida a partir da creatinina sérica, utilizando a equação CKD-EPI. Esse rastreamento deve ser realizado no momento do diagnóstico de DM2 e após 5 anos do diagnóstico de DM1, devendo ser repetido de 1 a 4 vezes ao ano, conforme risco individual<sup>131</sup> . A estimativa da TFG, a CKD-EPI ( _Chronic Kidney Disease Epidemiology Collaboration_ ), é calculada a partir da creatinina sérica. As fórmulas para cálculo da CKD-EPI são acessíveis em sites como www.sbn.org.br e <u>www.kidney.org, além de aplicativos específicos.</u>  
O **Quadro 11** descreve o esquema de tratamento atualmente, o qual deve focar na prevenção e progressão da DRD além do controle da glicemia.  
**Quadro 11.** Estratégia de tratamento da hiperglicemia de acordo com a função renal.  
|**TFG > 60 com**<br>**RAC >30**|**TFG 59-45**|**TFG 44-30**|**TFG 29-20**|**TFG < 20**|
|---|---|---|---|---|
|**ISGLT2:**Rec<br>|omendados, conf<br>|orme critérios de incl<br>|usãopreconizado|spelo PCDT|
|**Cloridrato de**<br>**metformina:**<br>(meta HbA1c: 7%<br>a 7,9%).|**Cloridrato de**<br>**metformina:**<br>(meta HbA1c:<br>7%a 7,9%).|**Cloridrato de**<br>**metformina:**<br>deve ser reduzida<br>para≤1g/dia|**Cloridrato de**<br>**metformina:**<br>evitar|**Cloridrato de**<br>**metformina:**<br>evitar|
|**Controle**<br>**adicional:**<br>Insulina,<br>Gliclazida MR.|**Controle**<br>**adicional:**<br>Insulina,<br>Gliclazida MR.|**Controle adicional:**<br>Insulina, Gliclazida<br>MR podem ser<br>consideradas.|<br>**Controle**<br>**adicional:**<br>Insulina.|**Controle**<br>**adicional:**<br>Insulina.|
|-|-|-|**Cautela:**<br>Gliclazida MR.|**Evitar:**Cloridrato<br>de metformina,<br>sulfonilureias.|  
**Legenda:** RAC: Razão albumina/creatinina urinária (mg/g); TFG: Taxa de filtração glomerular (mL/min/1,73m²); ISGLT2: Inibidores do SGLT2; MR: _Modified Release_ . **Notas** : Se TFG cair > 30%, suspender e investigar estenose de artéria renal; **ISGLT2** : Limites de TFG para início (dapagliflozina > 25); **Ajuste:** Reduzir dose de gliclazida MR se TFG < 30 mL/min/1,73m².  
**Fonte** : Adaptado de Sá et al., (2024)<sup>131</sup> .  
33  
A neuropatia diabética é definida pela presença de sintomas ou sinais de disfunção dos nervos, de forma difusa ou focal, em pessoas com diabetes, após a exclusão de outras causas<sup>132</sup> . Já o conceito de neuropatia periférica diabética (NPD), a forma mais comum de neuropatia diabética, refere-se à doença como uma “lesão difusa, simétrica, distal e progressiva das fibras sensitivo-motoras e autonômicas, causadas pela hiperglicemia crônica e por fatores de risco cardiovasculares<sup>133.</sup> O **Quadro 12** mostra a classificação atual das neuropatias diabéticas.  
**Quadro 12.** Classificação das neuropatias diabéticas.  
|**Neuropatias difusas**|||
|---|---|---|
|_Polineuropatia Sensitivo_<br>_Motora_<br>- Fibras finas<br>- Fibras grossas<br>- Fibras mistas (mais<br>comuns)|_Polineuropatia_<br>_Autonômica_<br>- Cardiovascular<br>- Genitourinária<br>- Metabólica<br>- Sudomotira<br>-Gastrointestinal|_Polineuropatia Atípica_<br>- Caquexia diabética<br>- Induzida pelo tratamento|
|**Neuropatias focais**|||
|_Mononeuropatia_|_Radiculoneuropatia_||
|- Multiplex<br>-Tunel do carpo<br>- Tunel do tarso<br>- Fibular ("pé caído")<br>- Meralgia parestésica<br>- Ocular|- Torácica<br>- Lombar<br>- Amiotrofia||  
**Fonte:** Adaptado de Feldman et al. (2019)<sup>134,</sup> Pop-Busui et al. (2017)<sup>135</sup> , e Rolim et al. (2022)<sup>132</sup> .  
Em indivíduos com diabetes, o diagnóstico da NPD é essencialmente clínico e baseia-se na presença de dois ou mais testes ou sinais neurológicos alterados. Deve ser firmado após a exclusão de outras causas, independentemente dos sintomas<sup>134,135</sup> . Para melhor acurácia diagnóstica, o ideal é que a metodologia a ser utilizada tenha a capacidade de avaliar tanto as fibras nervosas finas (mais precocemente acometidas, incluindo sensibilidade térmica, dolorosa e função sudomotora) das fibras nervosas grossas (reflexos tendíneos, sensibilidade vibratória, tátil e de posição). O diagnóstico da NPD é de exclusão, e as neuropatias não diabéticas associadas à deficiência de vitamina B12, etilismo, hipotiroidismo, síndrome do túnel do carpo, excesso de vitamina B6 ou drogas, substâncias neurotóxicas e metais pesados devem ser consideradas, pois podem ocorrer concomitantemente nos indivíduos diabéticos<sup>134</sup> .  
Todos os pacientes com DM2 devem ser examinados para pesquisa da neuropatia periférica diabética no momento do diagnóstico. Pacientes cujo rastreamento foi negativo devem ser reavaliados anualmente<sup>135</sup> . Na prática clínica, os melhores testes para rastreamento são o biotesiômetro e a sensibilidade térmica. Para o diagnóstico definitivo da NPD, recomenda-se o Escore de Comprometimento Neuropático (ECN)<sup>132</sup> , esquematizado no **Quadro 13.**  
34  
**Quadro 13.** Escore de comprometimento neuropático (ECN/NDS) para diagnóstico precoce da neuropatia periférica diabética.  
|**Teste**|**Direita**|**Esquerda**|
|---|---|---|
|Sensibilidade Vibratória - 128 Hz|Preservada: 0<br>Alterada:1|Preservada: 0<br>Alterada:1|
|Sensibilidade Térmica|Preservada: 0<br>Alterada:1|Preservada: 0<br>Alterada:1|
|Dor Superficial|Ausente: 0<br>Presente:1|Ausente: 0<br>Presente:1|
|Reflexo Aquileu|Normal: 0<br>Presente com reforço: 1<br>Ausente: 2|Normal: 0<br>Presente com reforço: 1<br>Ausente: 2|
||**Interpretação**||
|**SOMA BILATERAL DOS PO**|**NTOS**<br>**GRAU  **|**DENEUROPATIA**|
|0-2||Ausente|
|3-5||Leve|
|6-8||Moderada|
|9-10||Severa|  
**Legenda:** NDS - _Neuropathy Disabilty Score;_ NPD - Neuropatia diabética. **Fonte:** Adaptado de Feldman et al. (2019)<sup>134</sup> e Rolim, et al (2022)<sup>132</sup>  
O tratamento da neuropatia diabética é na maioria das vezes sintomático, sendo fundamental o controle glicêmico para a prevenção e para evitar sua progressão. Casos que apresentam muita dor e que não respondem ao controle metabólico podem inicialmente ser tratados com analgésicos não opióides. Ainda, podem ser utilizados antidepressivos tricíclicos e anticonvulsivantes, no tratamento da dor crônica, conforme PCDT da Dor Crônica<sup>64,81</sup> .  
A retinopatia diabética (RD) é uma complicação microvascular comum e específica do diabetes<sup>136</sup> O diagnóstico e tratamento precoces melhoram o prognóstico da RD, reduzindo o risco de dano visual irreversível. O atraso no diagnóstico e o surgimento das formas graves constituem a principal causa de perda visual evitável na população economicamente ativa<sup>137</sup> .  
A classificação para RD<sup>138</sup> e as suas características estão descritas no **Quadro 14** .  
**Quadro 14.** Classificação da Retinopatia Diabética.  
|**Classificação**|**Achados retinianos**|
|---|---|
|Ausência de<br>retinopatia|Normal|
|RDNP leve|Somente microaneurismas|
|RDNP moderada|Microaneurismas e outras alterações que não caracterizam<br>retinopatiagrave|
|RDNP grave|Qualquer uma dessas três alterações:<br><br>Hemorragias nos 4 quadrantes<br><br>Dilatações venosas em ≥ 2 quadrantes<br><br>Alterações vasculares intrarretinianas em pelo menos um<br>quadrante|
|RDNP muito grave|Presença de duas das três alterações do quadro de retinopatia<br>diabética nãoproliferativagrave|  
35  
|**Classificação**|**Achados retinianos**|
|---|---|
|RDP|Presença de neovascularização: no disco óptico ou na retina;<br>hemorragia vítrea|  
**Legenda:** RDNP – Retinopatia diabética não proliferativa; RDP - Retinopatia diabética proliferativa. **Fonte** : Adaptado de Aiello (2003)<sup>139</sup> e Malerbi et al. (2021)<sup>138</sup>  
Em indivíduos com DM2, o rastreamento da RD deve ser iniciado no momento do diagnóstico do diabetes. Caso o rastreamento inicial não identifique sinais de RD ou revele caso de RD leve, recomenda-se o acompanhamento anual. Para casos de RD moderada ou grave, recomenda-se intensificar a frequência das avaliações. A avaliação oftalmológica inicial deve ser realizada com dilatação das pupilas e, no mínimo, um exame de retinografia ou mapeamento de retina e biomicroscopia de fundo. O uso de programas que utilizam a fotografia retiniana com leitura remota deve ser considerado para ampliar o acesso ao rastreamento da RD. Em mulheres com diabetes prévio à gestação que engravidam, têm planos de engravidar ou com diabetes diagnosticado na gestação, recomenda-se o aconselhamento sobre os riscos envolvendo RD e encaminhamento para exame oftalmológico<sup>139</sup> . O diagnóstico e tratamento de retinopatia diabética é abordado no PCDT da Retinopatia Diabética vigente<sup>127</sup> .  
Para o tratamento e prevenção de complicações macrovasculares, é fundamental realizar intervenções preventivas cardiovasculares. Desta forma, o principal tratamento para esses pacientes consiste em controlar os fatores de riscos associados, como tabagismo<sup>75,76</sup> , dislipidemia<sup>43</sup> , HAS, sobrepeso e obesidade<sup>140</sup> . Para a úlcera do pé diabético, recomenda-se o autocuidado com os pés, como inspeção diária dos pés e do interior dos calçados, lavagem regular, atenção especial à secagem entre os dedos, corte adequado das unhas, e uso constante de calçados, evitando andar descalço<sup>141</sup> . Além disso, pacientes com úlcera do pé devem ser encaminhados a um nível mais especializado de saúde, para avaliação complementar se a atenção primária não dispor de profissionais capacitados ou equipamentos e materiais necessários para tratamento. Pacientes com deformidades importantes do pé ou ausência de pulsos periféricos e pacientes com suspeita de isquemia dos membros inferiores deverão ser encaminhados a um maior nível de complexidade enquanto pacientes com úlcera infectada, infecção em processo de expansão, isquemia crítica do membro, gangrena, suspeita de artropatia de _Charcot_ aguda ou edema e rubor não explicados do pé devem ser encaminhados para a urgência de serviços com atenção imediata.  
A síndrome do pé diabético consiste em uma das complicações crônicas do diabetes e caracteriza-se pela presença de infecção, ferida ou destruição de tecidos profundos associados a anormalidades neurológicas e variados graus de doença vascular periférica<sup>142</sup> . As feridas nos pés estão associadas a altos níveis de morbimortalidade, e têm impacto financeiro significativo para o tratamento. Estudos apresentam que a incidência de ferida nos pés em pessoas com diabetes varia de 19% a 34% e que, mesmo após a cicatrização, as recorrências chegam a 40% no primeiro ano e a 65% em três anos<sup>143</sup> . Salienta-se que complicações do pé diabético são responsáveis por 40% a 70% do total de amputações não traumáticas de membros inferiores10. Desse modo, fazse necessária a avaliação dos pés nas consultas de acompanhamento do diabetes como boa prática na oferta do cuidado integral e qualificado às pessoas com essa condição.  
O acompanhamento da pessoa com diabetes deve compreender também a realização do exame dos pés, com uma rotina sistemática de avaliação clínica que envolve anamnese, avaliação da pele, musculoesquelética, vascular e neurológica, além das orientações para o autocuidado, visando a prevenção e o cuidado adequado de complicações como feridas e infecções, bem como evitar o agravamento que pode levar a amputação não traumática dos membros inferiores<sup>64,142–144</sup> .  
36  
A avaliação neurológica visa a identificação da perda de sensibilidade protetora e inclui testes com monofilamento de 10 g, diapasão de 128 Hz, teste de sensação tátil (percepção de picada) e reflexo Aquileu. Para tal avaliação, recomenda-se realizar ao menos dois desses testes, sendo um deles o do monofilamento e o outro à escolha do profissional e conforme disponível para a equipe de saúde, sendo preferencial como segundo o diapasão. Deve-se proceder com as devidas avaliações, a partir dos aspectos citados anteriormente e do uso de ferramentas e escalas de classificação, como de estratificação de risco do pé e intervalo de seguimento, o cálculo do Índice Tornozelo-Braquial para avaliação de doença arterial periférica, o escore _Site, Ischemia, Neuropathy, Bacterial infection, Area, Depth_ (SINBAD) para avaliar a gravidade de feridas, o sistema _Wound, Ischemia, Foot Infection_ (WIFI) para avaliar o risco de amputação em um ano 142–145.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.6. Cuidado farmacêutico -->
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Biguanidas:** -->
- Cloridrato de metformina: comprimido de 500 mg e 850 mg;

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Sulfonilureias:** -->
- Glibenclamida: comprimido de 5 mg;  
- Gliclazida: comprimido de liberação prolongada de 30 mg e 60 mg, e comprimido de  
80 mg.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Inibidores de SGLT2:** -->
- Dapagliflozina: comprimidos de 10 mg.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Insulinas:** -->
- Insulina humana NPH: suspensão injetável de 100 U/mL;  
- Insulina humana regular: solução injetável de 100 U/mL;  
37  
- Insulina análoga de ação rápida: solução injetável de 100 U/mL;  
- Insulina análoga de ação prolongada: solução injetável de 100 U/mL ou 300 U/mL.  
Nota: O medicamento cloridrato de metformina 500 mg comprimido de ação prolongada está disponível por meio do Programa Aqui tem Farmácia Popular.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.8. Esquemas de administração -->
O tratamento do DM2 requer acompanhamento contínuo pois, após a decisão terapêutica inicial, é fundamental avaliar periodicamente a necessidade de intensificação do esquema utilizado, com ajuste de dose ou adição de outros agentes. Se a HbA1c estiver dentro da meta, sua medida pode ser feita, em exame de sangue, pelo menos duas vezes por ano. Caso esse parâmetro ainda esteja fora da meta, dosagens mais frequentes são necessárias (a cada 3 meses) e o tratamento deve ser intensificado. Se houver diagnóstico de DRD ou doença cardiovascular, reavaliação do esquema terapêutico também é necessária<sup>99</sup> .  
- Caso seja necessário iniciar insulina, é recomendado iniciar com uma **insulina basal** (análogo de longa duração ou insulina humana NPH) na dose de 0,1 a 0,2 U/kg.  
- Caso opte por usar **insulina humana NPH** : a dose deve iniciada à noite, antes da ceia. Após início de insulina basal, a dose deve ser titulada de acordo com a glicemia de jejum. A titulação pode ser feita a cada 3 dias, com treinamento do paciente, até atingir o objetivo. Caso o alvo da glicose em jejum seja atingido e ainda haja hiperglicemia ao longo do dia, uma dose adicional de insulina humana NPH pela manhã deve ser adicionada. Caso a hiperglicemia seja predominantemente pós-prandial, insulina humana regular ou análogo de ação rápida deve ser adicionado, antes das refeições<sup>100</sup> .  
- Caso haja indicação e disponibilidade de uso de **insulina** análoga **de ação prolongada** , a administração pode ser pela manhã ou à noite. Para a insulina glargina 100 U, há necessidade de manter o horário da aplicação constante. Para insulina degludeca, há flexibilidade de horário de administração para 8 horas a mais ou a menos. Para insulina glargina 300 U, há flexibilidade de horário de administração para 3 horas a mais ou a menos. Após início de insulina basal, a dose deve ser titulada de acordo com a glicemia de jejum. A titulação pode ser feita a cada 3 dias, com treinamento do paciente, até atingir o objetivo, no caso da insulina glargina. Para usuários de insulina degludeca, o ajuste geralmente é feito semanalmente. Caso haja hiperglicemia pós-prandial significativa com uso de insulina basal, deve ser feita associação com insulina humana regular ou análogo de ação rápida, quando disponível, antes das refeições<sup>100</sup> .  
- Ao iniciar insulina, os outros medicamentos para diabetes tipo 2 podem ser mantidos, desde que não sejam contraindicados. As sulfoniluréias geralmente não apresentam benefícios em pessoas em uso de insulina bolus, devendo ser mantidas nos casos de uso, apenas, de insulinas basais (NPH e AIAP)<sup>100</sup> .  
Os esquemas de administração, estão descritos no **Quadro 15** .  
38  
**Quadro 15.** Esquemas de administração dos medicamentos disponíveis no Sistema Único de Saúde para tratamento do diabete melito tipo 2.  
|**Medic**|**amento**|**Dose diária**<br>**habitual **|**Dose diária**<br>**máxima**|**Frequência**<br>**diária**|
|---|---|---|---|---|
|Biguanidas|Cloridrato de<br>metformina|500 mg ou 850 mg|2550 mg|2 a 3 vezes|
|Slfili|Glibenclamida|5mg|20mg|1 a 2vezes|
|uonureas|Gliclazida|30 mgou 60 mg|120 mg|1 vez|
|iSGLT2|Dapagliflozina|10mg|10mg|1vez|
|Insulina h|umana NPH|Dose inicial 0,1-0,2<br>U/kg/dia<sup>a,b</sup><br>Em pessoas com<br>obesidade e<br>resistência à<br>insulina<br>importantes 0,5-<br>0,75 U/Kg/dia.|0,5 U/kg/dia.<br>Em pessoas com<br>obesidade e<br>resistência à<br>insulina<br>importantes<br>0,75 U/kg/dia|1 a 2 vezes<sup>c</sup>|
|Insulina Hu|mana Regular|Dose inicial de 3 U<br>a 4 U e titular de<br>acordo com a<br>glicemia pós-<br>prandial<sup>d</sup>|> 50% da DTDI|Antes das<br>refeições<br>principais|
|Insulina análog|a de ação rápida|Dose inicial de 3 U<br>a 4 U e titular de<br>acordo com a<br>glicemia pós-<br>prandial<sup>d</sup>|> 50% da DTDI|Antes das<br>refeições<br>principais|
|Insulina an<br>prolo|áloga de ação<br>ngada|Dose inicial 0,1 U-<br>0,2 U/kg/dia<sup>a,b</sup>. Em<br>pessoas com<br>obesidade e<br>resistência à<br>insulina<br>importantes 0,5-<br>0,75 U/kg/dia.|0,5 U/kg.<br>Em pessoas com<br>obesidade e<br>resistência à<br>insulina<br>importantes<br>0,75 U/kg/dia|1 vez|  
**Legenda** DTDI – dose total diária de insulina.  
**Notas:**<sup>a.</sup> ajustando em 2 U a cada 3 dias até atingir a meta estabelecida para glicemia em jejum; b. 0,3 a 0,5U/kg dose de manutenção; c. ajuste a cada 3 dias até atingir o objetivo; d. dose deverá ser titulada até atingir glicemia pré-prandial entre 90 mg/dL e 180 mg/dL, com aumento de 1 U, duas vezes por semana.  
**Fonte** : Elaboração própria.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.9. Contraindicações -->
Além de hipersensibilidade ao medicamento ou qualquer componente da fórmula, as contraindicações de uso dos medicamentos preconizados por este Protocolo são:  
- **Cloridrato de metformina:** gravidez e durante amamentação; insuficiência renal (TFG menor que 30 mL/min/1,73 m<sup>2</sup> ), insuficiência hepática descompensada, insuficiência cardíaca ou insuficiência pulmonar, e acidose grave; infecção grave; pré-operatório e pósoperatório, em pacientes submetidos a exame de imagem com contraste.  
39  
- **Sulfonilureias – glibenclamida e gliclazida:** gravidez, lactantes, insuficiência renal (TFG menor que 30 mL/min/1,73 m<sup>2</sup> ); infecção grave ou insuficiência hepática. Além disso, glibenclamida não é recomendada para pacientes com idade superior ou igual a 60 anos. **iSGLT2 - dapagliflozina:** gravidez e período de lactação; não deve ser usado em pacientes com TFG estimada persistentemente inferior a 25 mL/min/1,73 m<sup>2</sup> .  
- **Insulinas  humana NPH e insulina humana regular, AIAR e AIAP:** não há contraindicações absolutas. Deve-se observar ocorrência de hipoglicemias. Reações alérgicas são raras, usualmente cutâneas e passíveis de tratamento com dessensibilização ou troca de apresentação.  
- 8.10. Benefícios esperados  
- Melhor controle glicêmico possível.  
- Melhora dos sintomas relacionados à hiperglicemia.  
- Diminuição das complicações agudas e crônicas de DM2.  
- 8.11. Tratamento em populações específicas

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.11.1. Tratamento de crianças e adolescentes com DM2 -->
Em indivíduos com diabetes diagnosticado incidentalmente ou metabolicamente estável, HbA1c < 8,5% e assintomáticos, o cloridrato de metformina é o tratamento medicamentoso inicial de escolha, desde que a função renal esteja normal<sup>31</sup> . Jovens com hiperglicemia acentuada (glicemia ≥ 250 mg/dL e HbA1c ≥ 8,5%) sem acidose no momento do diagnóstico, mas sintomáticos com poliúria, polidipsia, noctúria ou perda de peso, devem ser tratados inicialmente com insulina de ação prolongada enquanto o cloridrato de metformina é iniciado e titulado<sup>31</sup> .  
Em indivíduos inicialmente tratados com insulina e cloridrato de metformina ou outros medicamentos para redução da glicose que estejam atingindo as metas glicêmicas com base no monitoramento da glicose, pode-se tentar reduzir a dose de insulina ao longo de 2 a 6 semanas, com reduções de dose de 10% a 30% em intervalos de alguns dias<sup>31</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 8.11.2. Tratamento de pessoas idosas com DM2 -->
Pessoas idosas que apresentam perda de capacidade funcional, comprometimento cognitivo, multimorbidades, polifarmácia, sarcopenia ou fragilidade têm maior risco de eventos adversos relacionados ao tratamento, especialmente hipoglicemia, além de uma resposta menos eficaz<sup>146,147</sup> . Nesses casos, recomenda-se individualizar o cuidado, priorizando terapias de menor risco e esquemas terapêuticos simplificados. A avaliação deve considerar a capacidade cognitiva e funcional para administrar medicamentos, a regularidade da ingestão alimentar, o uso adequado de dispositivos de monitorização e a função renal. Em situações de baixo peso e hiperglicemia que compromete o estado nutricional, a introdução cautelosa de insulina basal pode ser indicada, com monitorização próxima e ajustes graduais<sup>146,147</sup> .  
40

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 9. ADESÃO TERAPÊUTICA -->
O cuidado do DM2 compreende intervenções medicamentosas e não medicamentosas sendo estas últimas fundamentais desde o diagnóstico. No entanto, a adesão às mudanças no estilo de vida ainda representa um dos principais desafios terapêuticos. A abordagem não medicamentosa é indicada para todos os indivíduos com DM2, possuindo grande impacto comprovado na literatura, sendo as principais estratégias a intervenção nutricional, a prática de exercícios físicos, a redução do comportamento sedentário, a melhora da duração do sono, a cessação do tabagismo e as intervenções voltadas ao gerenciamento do estresse<sup>148</sup> .  
Para promover maior adesão terapêutica, é recomendada a adoção de uma abordagem colaborativa e centrada na pessoa, com tomada de decisão compartilhada, definição conjunta do plano terapêutico e escuta ativa das necessidades e expectativas do paciente. A participação ativa do indivíduo no cuidado contribui para o fortalecimento dos comportamentos de autocuidado, resultando em melhores desfechos clínicos, aprimoramento do estado geral e bem-estar<sup>149</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 10. CRITÉRIOS DE INTERRUPÇÃO -->
A interrupção planejada do uso de medicamentos, conhecida como desprescrição, é uma prática clínica que tem ganhado relevância nos últimos anos, especialmente no contexto do cuidado a pacientes idosos. No entanto, ainda existem lacunas significativas na literatura quanto aos benefícios clínicos concretos dessa abordagem em diferentes cenários terapêuticos<sup>150</sup> .  
No cuidado do DM2, o tratamento medicamentoso deve ser periodicamente reavaliado e ajustado de forma individualizada, conforme critérios clínicos e sob orientação médica. Essa revisão deve considerar a melhor relação risco-benefício, bem como as preferências, valores e objetivos do paciente. A desprescrição pode ser indicada quando os potenciais eventos adversos do fármaco superam seus benefícios, especialmente em situações de polifarmácia, mudanças no estado clínico ou fragilidade associada à idade<sup>151</sup> .

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 11. MONITORAMENTO -->
O monitoramento do indivíduo com DM2 deve ser realizado tanto pela equipe multiprofissional de saúde quanto pelo próprio paciente (automonitoramento).  
O acompanhamento com a equipe de saúde deve ocorrer a cada seis meses, incluindo solicitação dos exames de glicemia plasmática de jejum e HbA1c. Para pacientes que ainda não atingiram as metas glicêmicas estabelecidas, recomenda-se a reavaliação trimestral até a obtenção do resultado estabelecido em consulta prévia<sup>152,153</sup> .  
Durante todas as consultas clínicas, é imprescindível a avaliação do peso corporal, da pressão arterial e a estratificação do risco cardiovascular. Anualmente, devem ser solicitados os exames de colesterol total, triglicerídeos, HDL-colesterol e LDL-colesterol (para detecção de dislipidemia), creatinina sérica e dosagem de albuminúria (para avaliação de nefropatia). Recomenda-se a realização do exame neurológico dos membros inferiores – com verificação dos reflexos, pulsos periféricos, sensibilidade vibratória e tátil – ao diagnóstico e anualmente, no mínimo. Usuários que apresentem maior risco para complicações podem necessitar mais avaliações, de acordo com a estratificação de risco ou a critério da equipe de saúde<sup>143</sup> . A avaliação  
41  
oftalmológica por fundoscopia também deve ser realizada anualmente, para rastreamento de retinopatia diabética<sup>152</sup> .  
Dada a estreita associação entre DM2 e risco cardiovascular, recomenda-se a avaliação anual do risco cardiovascular do paciente, com base no histórico clínico e familiar, nos sinais e sintomas, nos achados do exame físico - incluindo a mensuração da pressão arterial - e nos resultados laboratoriais. Na suspeita de insuficiência cardíaca, é indicado dosar o peptídeo natriurético tipo B/fragmento N terminal do peptídeo natriurético tipo B (PNB/NT-proPNB)<sup>154</sup> .  
O automonitoramento, por sua vez, é realizado pelo próprio indivíduo pela medição dos níveis de glicose a partir de amostras de sangue capilar. Esse exame é recomendado para indivíduos com DM2 que usam insulina<sup>21</sup> . Porém, estudos não demonstram benefício significativo do automonitoramento em que utilizam agentes antidiabéticos orais ou não insulinotrópicos<sup>153</sup> .  
O **Quadro 16** descreve as principais ações de monitoramento dos pacientes com DM2.  
**Quadro 16** . Periodicidade de exames complementares realizados no acompanhamento de pessoas com diabete melito tipo 2.  
|**Avaliação**|**Periodicidade**<sup>**a**</sup>|
|---|---|
|Monitoramento dopeso|Em cada consulta|
|Estratificação de risco cardiovascular|Anualmente|
|Pressão arterial|Em cada consulta|
|Avaliação dopé diabético<sup>b</sup>|Ao diagnóstico e anualmente|
|Dislipidemia(colesterol total,triglicerídeos,HDL-c,LDL-c)|Ao diagnóstico e anualmente|
|Glicemia plasmática de jejum e hemoglobina glicada|Ao diagnóstico e a cada 6<br>meses|
|Avaliação de nefropatia(creatinina sérica,albuminúria)|Ao diagnóstico e anualmente|
|Avaliação de retinopatia(fundoscopia)|Ao diagnóstico e anualmente|  
**Legenda:** HDL-c: lipoproteína de alta densidade; LDL-c: lipoproteína de baixa densidade. **Nota:**<sup>a</sup> De acordo com a necessidade do paciente, avaliações anuais ou semestrais podem ser antecipadas,<sup>b.</sup> Sistema de estratificação de risco para os pés do _The International Working Group on the Diabetic Foot_ (IWGDF) e a frequência recomendada de rastreamento estão apresentados no material Suplementar E.  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 12. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento póstratamento. Pacientes com DM2 devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com DM2 devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de efeitos adversos.  
42  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A APS é a principal porta de entrada e a coordenadora do cuidado da Rede de Atenção à Saúde (RAS), atuando de forma territorializada e próxima às comunidades. Cabe a ela a detecção precoce de sinais e sintomas sugestivos de condições clínicas, relacionados aos fatores de risco e à vulnerabilidade, viabilizando intervenções oportunas e resolutivas. Além do acolhimento e atendimento clínico, a APS promove ações de educação em saúde voltadas a pacientes e familiares, abordando os riscos, a adesão ao tratamento e o reconhecimento de sinais de agravamento. É também o espaço privilegiado para o acompanhamento longitudinal, com monitoramento periódico do controle clínico, ajuste de condutas terapêuticas e identificação de comorbidades que possam impactar a evolução da saúde. Por meio de ações de promoção à saúde, tais como o incentivo à prática de atividade física segura, a alimentação saudável e o controle ambiental, a atenção primária contribui para minimizar ou eliminar fatores de risco que determinam a patogênese, prevenir o agravamento de doenças e melhorar a qualidade de vida das pessoas.  
A organização e a regulação dos fluxos de encaminhamento para a atenção especializada devem assegurar que casos de maior complexidade, suspeitas diagnósticas ou demandas por terapias específicas sejam avaliados em tempo oportuno. A articulação com os demais pontos da Rede de Atenção à Saúde fortalece a coordenação do cuidado, promove o uso racional dos recursos e contribui para melhores desfechos clínicos.  
Assim, o fortalecimento da APS no cuidado das condições de saúde amplia o acesso, qualifica a resolutividade e consolida uma abordagem integral, contínua e centrada na pessoa, em consonância com as diretrizes nacionais e a organização da rede assistencial. Como parte da rede de Atenção Primária à Saúde, o Programa Academia da Saúde é uma estratégia de promoção da saúde e produção do cuidado que funciona com a implantação de espaços públicos conhecidos como polos, voltados ao desenvolvimento de ações culturalmente inseridas e adaptadas aos territórios locais e que adotam como valores norteadores de suas atividades o desenvolvimento de autonomia, equidade, empoderamento, participação social, entre outros. Nesse sentido, deve ser observado o artigo 7° da Portaria de Consolidação nº 5, de 28 de setembro de 2017, que estabelece os seguintes eixos de ações para serem desenvolvidos nos polos do programa: Práticas corporais e Atividades físicas; produção do cuidado e de modos de vida saudáveis; promoção da alimentação saudável; PICS; práticas artísticas e culturais; educação em saúde; planejamento e gestão; e mobilização da comunidade.  
Em relação às PICS, estas práticas foram institucionalizadas pela PNPIC. Uma das ideias centrais dessa abordagem é uma visão ampliada do processo saúde e doença, assim como a promoção do cuidado integral do ser humano, especialmente do autocuidado. As indicações às práticas se baseiam no indivíduo como um todo, considerando seus aspectos físicos, emocionais, mentais e sociais. As PICS não substituem o tratamento tradicional e podem ser indicadas por profissionais específicos conforme as necessidades de cada caso. Diante dos desafios para o controle de doenças crônicas não transmissíveis e dos seus fatores de risco no País, o Ministério da Saúde instituiu a Estratégia de Saúde Cardiovascular na Atenção Primária à Saúde, por meio da Portaria GM/MS nº 3.008, de 4 de novembro de 2021. A Estratégia de Saúde Cardiovascular  
43  
conta com um Instrutivo para profissionais e gestores de saúde na Atenção Primária à Saúde para promover e qualificar ações de prevenção, controle e atenção integral às pessoas com doenças cardiovasculares e seus fatores de risco, orientada a partir de 3 objetivos: i) Qualificar a atenção integral às pessoas com condições consideradas fatores de risco para doenças cardiovasculares; ii) Dar suporte ao desenvolvimento de ações para prevenção e controle das condições consideradas fatores de risco para doenças cardiovasculares, com ênfase para os casos de Hipertensão Arterial Sistêmica e Diabete Melito; iii) Promover o controle dos níveis pressóricos e glicêmicos, a adesão ao tratamento e a redução nas taxas de complicações, internações e morbimortalidade por doenças cardiovasculares e seus fatores de risco. O sistema de assistência à saúde por meio dos gestores deve garantir a implementação de estrutura que permita identificação de pacientes com DM2 em tempo ideal, e a capacitação de profissionais da equipe multidisciplinar para o desenvolvimento das estratégias medicamentosas e não medicamentosas de controle do DM2. A assistência à saúde deverá ocorrer de acordo com as necessidades e o grau de risco da pessoa e da sua capacidade de adesão e motivação para o autocuidado, a cada consulta.  
O médico da APS pode encaminhar os pacientes à Atenção Especializada, em casos de presença de complicações, como alteração em exame de fundoscopia, amostra urinária com albuminúria ou diminuição da sensibilidade nos pés. É fundamental que seja elaborado um plano de cuidado conjunto entre a APS e a Atenção Especializada, sendo a APS responsável pela gestão de saúde destes pacientes<sup>155</sup> .  
No **Quadro 17** são detalhados os critérios de encaminhamento à atenção especializada, conforme disponibilidade nas redes de saúde<sup>19</sup> . É importante lembrar que a principal causa de descompensação do DM2 é a má adesão ao tratamento, o que reforça a importância da APS no acompanhamento do paciente.  
**Quadro 17.** Condições clínicas que indicam a necessidade de encaminhamento para atenção especializada.  
|**Especialidade**|**Condições clínicas que indicam a necessidade de encaminhamento**|
|---|---|
|Endocrinologista|Paciente sem controle glicêmico adequado em uso de dose total diária<br>insulina basal (NPH ou AIAP) igual ou maior que 0,75 U/kg/dia e com boa<br>adesão terapêutica e que apresentem hipoglicemias (por exemplo, casos<br>que requerem esquemas mais complexos), como a introdução da insulina<br>_bolus_(insulina humana regular ou AIAR).<br>Presença de complicações, como alteração em exame de fundoscopia,<br>amostra urinária com albuminúria ou diminuição da sensibilidade nospés.|
|Endocrinologista<br>e nefrologista|Doença renal crônica (taxa de filtração glomerular menor que 25<br>mL/min/1.73 m<sup>2</sup>) (estágio 4 e 5). Nesses casos, deve-se suspender o uso de<br>cloridrato de metformina, secretagogos e iSGLT2 (dapagliflozina),<br>mantendo insulinoterapia exclusiva até a consulta com endocrinologista.|
|Nefrologista|Proteinúria (macroalbuminúria);<br>Perda rápida da função renal (> 5 mL/min/1,73 m² em um período de<br>seis meses, com uma taxa de filtração glomerular menor que 60<br>mL/min/1,73 m<sup>2</sup>, confirmado em dois exames);<br> Suspeita de nefropatiapor outras causas.|
|Neurologista|Polineuropatia com etiologia definida, porém com sintomas progressivos<br>ou refratários ao tratamento clínico otimizado (tratamento da causa base e<br>uso de medicamentos como antidepressivos tricíclicos ou gabapentina);<br>Pacientes que apresentam sintomas atípicos, refratários ou sem etiologia<br>definida.|  
44  
|**Especialidade**<br>Cirurgião<br>vascular|**Condições clínicas que indicam a necessidade de encaminhamento**<br>Doença arterial periférica em quadro agudo: condições clínicas que<br>indicam a necessidade de encaminhamento para urgência/emergência:<br>Suspeita de isquemia crítica aguda do membro de início recente: dor<br>constante em repouso, palidez, ausência de pulso, membro mais frio em<br>relação ao contralateral, alteração de sensibilidade ou força, parestesia e<br>paralisia do membro, sinais de gangrena. Doença arterial periférica em<br>quadro crônico: Condições clínicas que indicam a necessidade de<br>encaminhamento para cirurgia vascular ambulatorial:<br>Doença arterial crônica avançada, com sinais que indicam ameaça ao<br>membro: dor crônica em repouso, úlcera arterial;<br>Doença arterial crônica sintomática com claudicação que limita as<br>atividades diárias, refratária ao tratamento conservador por 6 meses (uso de<br>cilostazol, exercício físico apropriado, antiagregante plaquetário, controle<br>de fatores de risco cardiovascular – cessar tabagismo, tratamento de DM,<br>hipertensão e dislipidemia).|
|---|---|
|Oftalmologista|Os critérios para encaminhamento ao oftalmologista precisam ser<br>avaliados individualmente. Casos com perda súbita de visão, hemorragia<br>pré-retiniana ou vítrea ou descolamento de retina (com percepção de luzes<br>a piscar, aparência súbita de vários corpos flutuantes ou a percepção de<br>sombra ou cortina sobre parte do campo da visão) precisam ser avaliados<br>de forma imediata. Os casos de retinopatia proliferativa ou pré-proliferativa<br>grave, suspeita de maculopatia (pela presença de exsudatos a uma distância<br>menor do que um diâmetro de disco óptico do centro da fóvea ou exsudatos<br>circinados ou em grupo dentro da mácula) também precisam ser<br>considerados.|
|Cardiologista|<br>Encaminhar para ambulatório especializado pacientes com:<br>Sintomas de angina com classe funcional CCS > 1, equivalente anginoso<br>ou eletrocardiograma com alteração sugestiva de isquemia: solicitar antes<br>do encaminhamento ecocardiograma e exame de avaliação funcional de<br>isquemia (teste ergométrico, cintilografia de esforço ou ecocardiograma de<br>estresse) – encaminhar somente pacientes com exames sugestivos de<br>isquemia ou piora de classe funcional mesmo com pressão arterial e<br>frequência cardíaca controlados com tratamento clínico otimizado;<br>Evento agudo de cardiopatia isquêmica (síndrome coronariana aguda)<br>sem realização de estratificação de risco na emergência;<br>Suspeita de insuficiência cardíaca: solicitar ecocardiograma.<br>Encaminhar para cardiologista aqueles com classe funcional NYHA III e<br>IV com tratamento otimizado ou com disfunção ventricular moderada a<br>grave;<br>Bradicardia sinusal sintomática ou se assintomática com frequência<br>cardíaca < 45 bpm;<br>Eletrocardiograma com bloqueios atrioventriculares ou bifascicular<br>(bloqueio completo de ramo esquerdo ou direito, associado a hemibloqueio<br>anterior esquerdo ou posterior esquerdo);<br>Fibrilação atrial com possibilidade de cardioversão (pacientes com idade<br>menor do que 65 anos e átrio menor do que 5 cm);<br>Pacientes com fibrilação atrial com difícil controle de resposta (FC < 100<br>bpm) ou que tenham perda em qualidade de vida ou perda de fração de<br>ejeção em ecocardiograma;<br>Taquicardia supraventricular sintomática e recorrente;<br>Pacientes com alteração na ausculta cardíaca – presença de sopros:<br>solicitar ecocardiograma, encaminhar se valvulopatias moderadas a graves<br>oupacientes sintomáticos comqualquervalvulopatia.|  
45  
|**Especialidade**|**Condições clínicas que indicam a necessidade de encaminhamento**|
|---|---|
|Geriatria|Indivíduo idoso com multimorbidades; polifarmária; iatrogenia; difícil<br>controle glicêmico associado a hipoglicemias de repetição, instabilidade<br>postural ou quedas de repetição, comprometimento cognitivo, transtorno de<br>humor associado, internações recentes, declínio funcional recente ou<br>comprometimentoprogressivo na realização de atividades devida diária.|  
**Fonte:** Adaptado de Protocolos de Encaminhamento da Atenção Básica para a Atenção Especializada, Ministério da Saúde<sup>155</sup> , Linha de cuidado do diabetes mellitus tipo 2<sup>19</sup> e caderno de atenção básica- diabetes mellitus<sup>64</sup> .  
Em situações de encaminhamento, recomenda-se descrever, minimamente, o conteúdo a seguir:  
- Sinais e sintomas;  
- Resultado de exame de HbA1c, com data (na presença dos sinais e sintomas descritos para cetoacidose diabética, dispensa-se a necessidade de exames laboratoriais recentes);  
- Avaliação da frequência e gravidade das hipoglicemias (total, noturna e grave);  
- Resultado de exame de creatinina sérica, com data, e cálculo da taxa de filtração glomerular (TFG);  
- Avaliação do lipidograma (colesterol total e frações e triglicérides);  
- Avaliação do risco cardiovascular (calculadora HEARTS);  
- Relato de uso ou não de insulina(s), com especificação de dose(s) e posologia(s);  
- Outros medicamentos em uso, com especificação de dose e posologia;  
- Peso do paciente em quilogramas (kg); e  
- Número da teleconsultoria, caso discutido com Telessaúde.  
Os procedimentos diagnósticos (Grupo 02) e terapêuticos clínicos (Grupo 03) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva condição clínica, no SIGTAP – Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
No **Quadro 18** são sumarizadas as principais recomendações para o gestor.  
46

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Quadro 18.** Recomendações para o gestor em saúde para cobertura do diabete melito tipo 2. -->
|**Recomendações para cobertura**|**Considerações**|**Tecnologias**<br>**disponíveis no SUS**|
|---|---|---|
|**I – Tratamento com agentes hipo**|**glicemiantes**||
|**Recomendação 1:**Disponibilizar<br>para o tratamento de pacientes com<br>DM2: cloridrato de metformina,<br>sulfonilureia<br>(glibenclamida,<br>gliclazida),<br>insulinas (regular, NPH e insulinas<br>análogas)<br>e<br>iSGLT2<br>(dapagliflozina).|<br> <br> <br> <br> <br> <br>‒<br>O tratamento inicial com cloridrato de metformina é o mais indicado para pacientes com<br>DM2. Adicionalmente, a oferta de cloridrato de metformina de liberação lenta (disponível no<br>Programa Aqui tem Farmácia Popular) pode ser considerada para pacientes com intolerância<br>gastrointestinal ao cloridrato de metformina de liberação imediata, evitando a necessidade do uso<br>de medicamentos de segunda linha terapêutica nesses pacientes.<br>‒<br>Aos pacientes com necessidade de intensificação da terapia, devem ser oferecidos<br>sulfonilureias e insulinas.<br>‒<br>O iSGLT2 possui potencial de redução em desfechos macrovasculares (cardíacos e<br>renais), sendo indicado para pacientes com necessidade de segunda intensificação de tratamento<br>e alto risco para desenvolver doença cardiovascular ou com doença cardiovascular já<br>estabelecida, e pelo menos 40 anos de idade<sup>107,156</sup>.|<br> <br> <br> <br>Cloridrato<br>de<br>metformina 500 mg –<br>850 mg<sup>a</sup><br>Sulfonilureias:<br>- gliclazida 30 mg e 60<br>mg<br>-glibenclamida 5 mg<br>Insulina humana: NPH<br>100 U/mL e regular 100<br>U/mL<br>iSGLT2: dapagliflozina<br>Insulina análoga de ação<br>rápida: asparte 100 U/mL<br>3 mL, lispro 100 U/mL 3<br>mL e glulisina 100 U/mL<br>3 mL<br>Insulina análoga de ação<br>prolongada: glargina e<br>degludeca|
|**II – Reutilização de agulhas e seri**|**ngaspara aplicação de insulinas**||
|**Recomendação 2:**Os gestores de<br>saúde devem disponibilizar agulhas<br>e seringas para aplicação de<br>insulina<br>conforme<br>pactuação<br>regional. A quantidade a ser<br>disponibilizada<br>considera<br>uma|<br> <br> <br> <br> <br> <br>‒<br>É preferível a aquisição de agulhas com menor diâmetro (0,2 a 0,3 mm) e mais curtas<br>(< 8 mm). A reutilização pode ser contabilizada nos cálculos do número de agulhas necessárias<br>por pacientes.<br>‒<br>O número de vezes a ser reutilizada pode variar de paciente para paciente de acordo<br>com características clínicas, devendo ser considerado pela equipe assistente.<br>‒<br>A recomendação também é aplicável a agulhas utilizadas em canetaspara injeção de|<br> <br> <br> <br>Recomendação<br>de<br>incorporação pelo SUS<br>conforme<br>Portaria<br>SCTIE/MS nº<br>11, de 13 de março de<br>2017<sup>157</sup>|  
47  
|**Recomendações para cobertura**|**Considerações**|**Tecnologias**<br>**disponíveis no SUS**|
|---|---|---|
|agulha por paciente/dia para a<br>insulina humana NPH e uma agulha<br>por paciente/dia para a insulina<br>humana regular. As canetas para<br>aplicação de insulina humana NPH<br>e<br>regular são<br>disponibilizadas<br>conforme pactuação em grupos<br>prioritários<br>definidos<br>pelo<br>Ministério da Saúde.|<br> <br> <br> <br> <br> <br> <br> <br>insulina. O uso de canetas para injeção de insulina tem sido relacionado à melhor comodidade na<br>aplicação, facilidade de transporte, armazenamento e manuseio e maior assertividade no ajuste da<br>dosagem das unidades (U), quando comparado ao uso de seringas.<br> <br>|- Caneta para injeção de<br>insulina|
|**III – Promoção de mudanças de e**|**stilo de vida**||
|**Recomendação**<br>**3:**<br>Devem-se<br>considerar<br>estratégias<br>para<br>promover o cuidado coordenado e<br>multidisciplinar.|<br> <br> <br>No âmbito populacional, podem ser ofertados programas para promoção de autocuidado, redução<br>de peso, estímulo à alimentação adequada e saudável, cessação do tabagismo, realização de<br>atividades físicas, apoio e incentivo ao desenvolvimento de ações nos polos da Academia da<br>Saúde e grupos de pacientes, além de consultas com equipes e<br>profissionais como nutricionistas,farmacêuticos,educadores físicos,entre outros.||  
**Nota** :<sup>a</sup> Como o cloridrato de metformina 500 mg liberação prolongada está disponível no Programa Aqui tem Farmácia Popular, quando disponível, pode ser uma alternativa em uma parcela de pacientes.  
**Fonte** : Elaboração própria.  
48

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 13. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 14. REFERÊNCIAS -->
1. ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Briggs Early K, et al. 2. Diagnosis and Classification of Diabetes: Standards of Care in Diabetes—2025. Diabetes Care [Internet]. 2025 Jan 1;48(Supplement_1):S27–49. Available from: https://diabetesjournals.org/care/article/48/Supplement_1/S27/157566/2-Diagnosis-andClassification-of-Diabetes  
2. Rodacki M, Cobas RA, Zajdenverg L, Silva Júnior WS da, Giacaglia L, Calliari LE, et al. Diagnóstico de diabetes mellitus. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
3. Diabetes do tipo 2 em adultos Direto ao local de atendimento. 2025.  
4. BMJ. Diabetes do tipo 2 em adultos. Direto ao local do atendimento. BMJ Best Practice. 2024;  
5. WORLD HEALTH ORGANIZATION. Prevalence of diabetes (age-standardized). Geneva: WHO, [2025?]. Disponível em: https://www.who.int/data/gho/data/indicators/indicator-details/GHO/prevalence-ofdiabetes-age-standardized. Acesso em: 8 maio 2025.  
6. WHO - World Health Organization. Diabetes [Internet]. WHO - World Health Organization. 2024 [cited 2025 Aug 31]. Available from: https://www.who.int/newsroom/fact-sheets/detail/diabetes  
7. International Diabetes Federation (IDF). Diabetes country report 2000 — 2050. Brazil. [Internet]. International Diabetes Federation (IDF). 2025 [cited 2025 Nov 23]. Available from: https://diabetesatlas.org/data-by-location/country/brazil/  
8. Klein S, Gastaldelli A, Yki-Järvinen H, Scherer PE. Why does obesity cause diabetes? Vol. 34, Cell Metabolism. Cell Press; 2022. p. 11–20.  
9. Blonde L, Umpierrez GE, Reddy SS, McGill JB, Berga SL, Bush M, et al. American Association of Clinical Endocrinology Clinical Practice Guideline: Developing a Diabetes Mellitus Comprehensive Care Plan—2022 Update. Endocrine Practice. 2022 Oct;28(10):923–1049.  
10. International Diabetes Federation (IDF). IDF Diabetes Atlas 11th Edition Committee [Internet]. 2025 [cited 2025 Sep 15]. Available from: https://diabetesatlas.org/media/uploads/sites/3/2025/04/IDF_Atlas_11th_Edition_2025.p df  
11. BRASIL. Presidência da República. Casa Civil. Lei no 8.080, de 19 de setembro de 1990. Dispõe sobre as condições para a promoção, proteção e recuperação da saúde, a organização e o funcionamento dos serviços correspondentes e dá outras providências e  
49  
dá outras providências. [Internet]. Presidência da República. Casa Civil. . 1990 [cited 2025 Sep 15]. Available from: https://www.planalto.gov.br/ccivil_03/leis/l8080.htm  
12. Chawla A, Chawla R, Jaggi S. Microvasular and macrovascular complications in diabetes mellitus: Distinct or continuum? Indian J Endocrinol Metab [Internet]. 2016;20(4). Available from: https://journals.lww.com/indjem/Fulltext/2016/20040/Microvasular_and_macrovascular _complications_in.21.aspx  
13. Tschiedel B. Complicações crônicas do diabetes. J Bras Med. 2014;102(5):1–7.  
14. Seid MA, Akalu Y, Gela YY, Belsti Y, Diress M, Fekadu SA, et al. Microvascular complications and its predictors among type 2 diabetes mellitus patients at Dessie town hospitals, Ethiopia. Diabetol Metab Syndr [Internet]. 2021;13(1):86. Available from: https://doi.org/10.1186/s13098-021-00704-w  
15. Padhi S, Nayak AK, Behera A. Type II diabetes mellitus: a review on recent drug based therapeutics. Biomedicine & Pharmacotherapy [Internet]. 2020;131:110708. Available from: https://www.sciencedirect.com/science/article/pii/S075333222030901X  
16. Brasil. Ministério da Saúde. Portaria No 62 de 6 de janeiro de 2017. 2017;  
17. Brasil. Ministério da Saúde. Portaria de consolidação no 3, de 28 de setembro de 2017. 2017;  
18. Bardenheier BH, Wu WC, Zullo AR, Gravenstein S, Gregg EW. Progression to diabetes by baseline glycemic status among middle-aged and older adults in the United States, 2006–2014. Diabetes Res Clin Pract. 2021 Apr 1;174.  
19. Brasil. Linha de cuidado - Diabetes Mellitus tipo 2 (DM2) no adulto (Primeira Versão) [Internet]. Ministério da Saúde . 2023 [cited 2025 May 13]. Available from: https://linhasdecuidado.saude.gov.br/portal/diabetes-mellitus-tipo-2-(DM2)-no-adulto/  
20. Barim EM, McLellan KCP, Ribeiro RS, Carvalho JAM de, Lindström J, Tuomilehto J, et al. Translation and cultural adaptation into Brazilian Portuguese of the Finnish Diabetes Risk Score (FINDRISC) and reliability assessment. Revista Brasileira de Epidemiologia. 2020;23.  
21. Brasil. Ministério da Saúde. Linha de Cuidado do Adulto com Diabetes Mellitus tipo 2 (DM2) [Internet]. Brasília; 2020 [cited 2024 Jul 30]. Available from: https://linhasdecuidado.saude.gov.br/portal/diabetes-mellitus-tipo-2-(DM2)-no-adulto  
22. Type 2 diabetes: prevention in people at high risk [Internet]. 2012. Available from: www.nice.org.uk/guidance/ph38  
23. SBD. Diretriz da Sociedade Brasileira de Diabetes - Edição 2023. . Disponível em: https://diretriz.diabetes.org.br/. 2023.  
24. ADA. American Diabetes Association Standards of Care in Diabetes. Disponível em: https://ada.silverchaircdn.com/ada/content_public/journal/care/issue/46/supplement_1/14/standards-of-care2023-copyright-stamped-updated-120622.pdf. 2023. 2023.  
25. USPSTF. Prediabetes and Type 2 Diabetes: Screening. Disponível em: https://www.uspreventiveservicestaskforce.org/uspstf/recommendation/screening-forprediabetes-and-type-2-diabetes. 2021.  
50  
26. ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Briggs Early K, et al. 2. Diagnosis and Classification of Diabetes: Standards of Care in Diabetes—2025. Diabetes Care. 2025 Jan 1;48(Supplement_1):S27–49.  
27. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas Diabete Melito tipo 2 [Internet]. Brasília; 2024 Feb [cited 2024 Jul 30]. Available from: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/RRPCDTDM2_Final.pdf  
28. Duncan BB, Schmidt MI,, Giugliani ER. Medicina ambulatorial: Condutas de atenção primária baseadas em evidências. Artmed; 2022.  
29. WHO. World Health Organization. HEARTS D: diagnosis and management of type 2 diabetes. Geneva; 2020.  
30. Rodacki M, Teles M, Gabbay M, Montenegro R, Bertoluci M. Classificação do diabetes. In: Diretriz Oficial da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2022.  
31. ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Briggs Early K, et al. 2. Diagnosis and Classification of Diabetes: Standards of Care in Diabetes—2025. Diabetes Care. 2025 Jan 1;48(Supplement_1):S27–49.  
32. ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Briggs Early K, et al. 14. Children and Adolescents: Standards of Care in Diabetes—2025. Diabetes Care. 2025 Jan 1;48(Supplement_1):S283–305.  
33. Quattrocchi E, Goldberg T, Marzella N. Management of type 2 diabetes: consensus of diabetes organizations. Drugs Context. 2020 Jan 27;9:1–25.  
34. Bertoluci MC, Silva Júnior WS, Valente F, Araujo LR, Lyra R, de Castro JJ, et al. 2023 UPDATE: Luso-Brazilian evidence-based guideline for the management of antidiabetic therapy in type 2 diabetes. Diabetol Metab Syndr. 2023 Jul 19;15(1):160.  
35. Rodacki M, Cobas RA, Zajdenverg L, Silva Júnior WS da, Giacaglia L, Calliari LE, et al. Diagnóstico de diabetes mellitus. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
36. OPAS. Calculadora de risco cardiovascular - HEARTS. [Internet]. Organização Mundial de Saúde. [cited 2025 May 13]. Available from: https://www.paho.org/pt/heartsnasamericas/calculadora-risco-cardiovascular  
37. de Souza Brito TN, De Araújo-Oliveira AR,, Da Silva AKC. Taxa de filtração glomerular estimada em adultos: características e limitações das equações utilizadas. RBAC. 2016;48(1):7–12.  
38. Levin A, Stevens PE, Bilous RW, Coresh J, De Francisco AL, De Jong PE, et al. Kidney disease: Improving global outcomes (KDIGO) CKD work group. KDIGO 2012 clinical practice guideline for the evaluation and management of chronic kidney disease. Kidney Int Suppl (2011). 2013 Jan;3(1):1.  
39. Brasil. Protocolo Clínico e Diretrizes Terapêuticas de Diabete Melito Tipo 2. Brasília; 2024.  
40. BMJ. BMJ Best Practice: DM tipo 2 em adultos. BMJ Best Practice [Internet]. 2022 [cited 2025 May 13]; Available from: https://bestpractice.bmj.com/info/pt/  
41. Brasil. Estratégia de Saúde Cardiovascular na Atenção Primária à Saúde: instrutivo para profissionais e gestores. Brasília; 2022.  
51  
42. Pedroso Camargos A, Barreto S, Brant L, Ribeiro ALP, Dhingra LS, Aminorroaya A, et al. Performance of contemporary cardiovascular risk stratification scores in Brazil: an evaluation in the ELSA-Brasil study. Open Heart. 2024 Jun 11;11(1):e002762.  
43. Précoma DB, Oliveira GMM de, Simão AF, Dutra OP, Coelho-Filho OR, Izar MC de O, et al. Updated Cardiovascular Prevention Guideline of the Brazilian Society of Cardiology - 2019. Arq Bras Cardiol. 2019;  
44. Brasil. Protocolo Clínico e Diretrizes Terapêuticas da Dislipidemia: prevenção eventos cardiovasculares e pancreatite. [Internet]. Brasília; 2019 [cited 2025 May 14]. Available from: https://www.gov.br/conitec/pt-br/midias/protocolos/pcdt_dislipidemia.pdf  
45. Quattrocchi E, Goldberg T, Marzella N. Management of type 2 diabetes: consensus of diabetes organizations. Drugs Context. 2020;9.  
46. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas de Sobrepeso e Obesidade em Adultos. Disponível em: https://www.gov.br/conitec/ptbr/midias/protocolos/20201113_pcdt_sobrepeso_e_obesidade_em_adultos_29_10_2020 _final.pdf. 2020.  
47. NICE. Type 2 diabetes in adults: management. NICE guideline - NG28 [Internet]. 2022 [cited 2025 May 13]. Available from: https://www.nice.org.uk/guidance/ng28/chapter/Recommendations#dietary-adviceandbariatric-surgery  
48. Pititto B, Dias M, Moura F, Lamounier R, Calliari S, Bertoluci M. Metas no tratamento do diabetes. Diretriz Oficial da Sociedade Brasileira de Diabetes. 2022.  
49. Nathan DM, Genuth S, Lachin J, Cleary P, Crofford O, Davis M. The Effect of Intensive Treatment of Diabetes on the Development and Progression of Long-Term Complications in Insulin-Dependent Diabetes Mellitus. New England Journal of Medicine. 1993 Sep 30;329(14):977–86.  
50. The ADVANCE Collaborative Group. Intensive Blood Glucose Control and Vascular Outcomes in Patients with Type 2 Diabetes. New England Journal of Medicine. 2008 Jun 12;358(24):2560–72.  
51. UK Prospective Diabetes Study (UKPDS) Group. Effect of intensive blood-glucose control with metformin on complications in overweight patients with type 2 diabetes (UKPDS 34). The Lancet. 1998 Sep;352(9131):854–65.  
52. Stratton IM, Adler AI, Neil HAW, Matthews DR, Manley SE, Cull CA. Association of glycaemia with macrovascular and microvascular complications of type 2 diabetes (UKPDS 35): prospective observational study. BMJ. 2000 Aug 12;321(7258):405–12.  
53. Currie CJ, Peters JR, Tynan A, Evans M, Heine RJ, Bracco OL, et al. Survival as a function of HbA1c in people with type 2 diabetes: a retrospective cohort study. The Lancet. 2010 Feb;375(9713):481–9.  
54. Brasil. Ministério da Saúde. Linha de cuidado - DM2. Disponível em: https://linhasdecuidado.saude.gov.br/portal/diabetes-mellitus-tipo-2-(DM2)-no-adulto/. 2023.  
55. ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Briggs Early K, et al. 5. Facilitating Positive Health Behaviors and Well-being to Improve Health Outcomes:  
52  
Standards of Care in Diabetes—2025. Diabetes Care. 2025 Jan 1;48(Supplement_1):S86– 127.  
56. Sociedade Brasileira de Diabetes. Diretrizes da Sociedade Brasileira de Diabetes 20192020 . São Paulo; 2019.  
57. Ramos S, Campos LF, Baptista DR, Strufaldi M, Gomes DL, Guimarães DB, et al. Terapia Nutricional no Pré-Diabetes e no Diabetes Mellitus Tipo 2. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2023.  
58. WHO. World Health Organization. Diet, nutrition and the prevention of chronic diseases: report of a joint WHO/FAO expert consultation. 2003.  
59. UK Prospective Diabetes Study (UKPDS) Group. Effect of intensive blood-glucose control with metformin on complications in overweight patients with type 2 diabetes (UKPDS 34). The Lancet. 1998 Sep;352(9131):854–65.  
60. Lindström J, Ilanne-Parikka P, Peltonen M, Aunola S, Eriksson JG, Hemiö K, et al. Sustained reduction in the incidence of type 2 diabetes by lifestyle intervention: followup of the Finnish Diabetes Prevention Study. The Lancet. 2006 Nov;368(9548):1673–9.  
61. Evert AB, Dennison M, Gardner CD, Garvey WT, Lau KHK, MacLeod J, et al. Nutrition Therapy for Adults With Diabetes or Prediabetes: A Consensus Report. Diabetes Care. 2019 May 1;42(5):731–54.  
62. Aas AM, Axelsen M, Churuangsuk C, Hermansen K, Kendall CWC, Kahleova H, et al. Evidence-based European recommendations for the dietary management of diabetes. Diabetologia. 2023 Jun 17;66(6):965–85.  
63. Raveendran A, Chacko EC, Pappachan JM. Non-pharmacological Treatment Options in the Management of Diabetes Mellitus. Eur Endocrinol. 2018;14(2):31.  
64. Davies MJ, Aroda VR, Collins BS, Gabbay RA, Green J, Maruthur NM, et al. Management of Hyperglycemia in Type 2 Diabetes, 2022. A Consensus Report by the American Diabetes Association (ADA) and the European Association for the Study of Diabetes (EASD). Diabetes Care. 2022 Nov 1;45(11):2753–86.  
65. Brasil. Cadernos de Atenção Básica - Estratégias para o cuidado da pessoa com doença crônica: diabetes mellitus [Internet]. Brasília; 2013 [cited 2025 May 13]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/estrategias_cuidado_doenca_cronica_diabete s_mellitus.pdf  
66. Brasil. Protocolo de uso do Guia Alimentar para a População Brasileira. Volume 2 - Orientação alimentar de pessoas adultas com obesidade [Internet]. Brasília; 2022 [cited 2025 May 13]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/volume2_protocolos_alimentar_adultas_obe sidade.pdf  
67. Brasil. Protocolos de uso do Guia Alimentar para a População Brasileira. Volume 1 - Orientação alimentar de pessoas adultas com obesidade, hipertensão arterial e diabetes mellitus: bases teóricas e metodológicas [Internet]. Brasília; 2022 [cited 2025 May 13]. Available from:  
- https://bvsms.saude.gov.br/bvs/publicacoes/fasciculo1_protocolos_alimentar_adultas_ob esidade.pdf  
53  
68. Franz MJ, Bantle JP, Beebe CA, Brunzell JD, Chiasson JL, Garg A. Evidence-Based Nutrition Principles and Recommendations for the Treatment and Prevention of Diabetes and Related Complications. Diabetes Care. 2003 Jan 1;26(suppl_1):s51–61.  
69. Khan TA, Lee JJ, Ayoub-Charette S, Noronha JC, McGlynn N, Chiavaroli L, et al. WHO guideline on the use of non-sugar sweeteners: a need for reconsideration. Eur J Clin Nutr. 2023 Nov 18;77(11):1009–13.  
70. Brasil. Manual - Como organizar o cuidado de pessoas com doenças crônicas na APS no contexto da pandemia. Brasília; 2020.  
71. Oba‐Yamamoto C, Takeuchi J, Nakamura A, Takikawa R, Ozaki A, Nomoto H, et al. Combination of alcohol and glucose consumption as a risk to induce reactive hypoglycemia. J Diabetes Investig. 2021 Apr 7;12(4):651–7.  
72. Brasil. Alimentação Cardioprotetora: manual de orientações para profissionais de saúde da Atenção Básica. Brasília; 2018.  
73.  
- Brasil. Guia de Atividade Física para a População Brasileira. Brasília; 2021.  
74. ADA. American Diabetes Association. Standards of Care in Diabetes - 2023  Abridged for Primary Care Providers. Vol. 41, Clinical Diabetes. 2023 Jan.  
75. Tobacconomics. The Tobacco Atlas. Atlanta: American Cancer Society and Vital Strategies [Internet]. The Tobacco Atlas. 2018 [cited 2025 May 14]. Available from: https://tobaccoatlas  
76. Brasil. Cadernos de Atenção Básica - Estratégias para o cuidado da pessoa com doença crônica: o cuidado da pessoa tabagista [Internet]. Brasília; 2015 [cited 2025 May 14]. Available from: https://www.as.saude.ms.gov.br/wp-  
- content/uploads/2016/06/caderno_40.pdf  
77. Brasil. Protocolo Clínico e Diretrizes Terapêuticas do Tabagismo [Internet]. Brasília; 2020 [cited 2025 May 14]. Available from: https://www.gov.br/conitec/ptbr/midias/protocolos/pcdt_tabagismo.pdf  
78. US Department of Health and Human Services. The health consequences of smoking—50 years of progress: a report of the Surgeon General. [Internet]. Atlanta, GA, US. ; 2014 [cited 2025 Jun 3]. Available from: https://cdn.wildapricot.com/55929/Resources/Pictures/Meetings/2014Charleston/PPT%20Presentations/Sunday%20Welcome/Abrams.AAHB.3.13.v1.o.pdf?v ersion=1394994006000&Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0d HBzOi8vY2RuLndpbGRhcHJpY290LmNvbS81NTkyOS9SZXNvdXJjZXMvUGljdHV yZXMvTWVldGluZ3MvMjAxNC1DaGFybGVzdG9uL1BQVCUyMFByZXNlbnRhdG lvbnMvU3VuZGF5JTIwV2VsY29tZS9BYnJhbXMuQUFIQi4zLjEzLnYxLm8ucGRmP 3ZlcnNpb249MTM5NDk5NDAwNjAwMCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1Ro YW4iOnsiQVdTOkVwb2NoVGltZSI6MTc0OTA0MjA1NX0sIklwQWRkcmVzcyI6eyJ BV1M6U291cmNlSXAiOiIwLjAuMC4wLzAifX19XX0_&Signature=sp-JsoL~mqILdsJTi7WjzIdjj6YYx3y7u2VCBmSzOQlxYc0wlpb0PkWjIuGb1xyk5ALvmkYZSQ XB1gVaID3kdCXh-  
3fMbEARUnD1YgTppOBlwHRWwMdBta8vvp9YmsNjjCHzrpctQh2sXJmc6DzKfuw MMCNZfw~Voz97B2F4~Dchlg4lf2SRnLCFHpliX8u~STmHPxJODI2djokz5LPWur51 kpCoDYlU~G8g8XkiNj5WoIR~c25cYhB2BHE4ESKRe9NAS4a7YI3c6ajdNn8uBRuQ os3z7hYyTdcLO40bsbFWyXjMUuXd6wTjBAgAyP8qGMSXbw6EibQFyhEB8EfpQ__ &Key-Pair-Id=K27MGQSHTHAGGF  
54  
79. Brasil. Linhas de cuidado - Tabagismo. [Internet]. Brasília; 2021 [cited 2025 May 14]. Available from: https://linhasdecuidado.saude.gov.br/portal/tabagismo/  
80. Rodrigues GMB, Malerbi FEK, Pecoli PFG, Forti AC e, Bertoluci M. Aspectos psicossociais do diabetes tipos 1 e 2. In: Diretriz Oficial da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2022.  
81. SUS-BH. Guia de Atuação do Farmacêutico no Cuidado à Pessoa que Vive com Diabetes [Internet]. Belo Horizonte.; 2023 [cited 2025 May 14]. Available from: https://prefeitura.pbh.gov.br/sites/default/files/estrutura-de-governo/saude/2023/guia-deatuacao-do-farmaceutico-no-diabetes-24-05-2023.pdf  
82. Brasil. Estratégias para o cuidado da pessoa com doença crônica [Internet]. Brasília; 2014 [cited 2025 May 14]. Available from: https://www.gov.br/conitec/ptbr/midias/pdf/caderno_atencaobasica35.pdf/  
83. Brasil. Guia Rápido Autocuidado em Saúde: Literacia para a saúde das pessoas com Diabetes Mellitus tipo 2 [Internet]. Brasília; 2022 [cited 2025 May 14]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/autocuidado_saude_diabetes_mellitus_tipo2. pdf  
84. Jones A, Vallis M, Pouwer F. If it does not significantly change HbA1c levels why should we waste time on it? A plea for the prioritization of psychological well‐being in people with diabetes. Diabetic Medicine. 2015 Feb 10;32(2):155–63.  
85. Skinner TC, Carey ME, Cradock S, Dallosso HM, Daly H, Davies MJ, et al. ‘Educator talk’ and patient change: some insights from the DESMOND (Diabetes Education and Self Management for Ongoing and Newly Diagnosed) randomized controlled trial. Diabetic Medicine. 2008 Sep 29;25(9):1117–20.  
86. Brenk-Franz K, Strauß B, Tiesler F, Fleischhauer C, Schneider N, Gensichen J. Patientprovider relationship as mediator between adult attachment and self-management in primary care patients with multiple chronic conditions. J Psychosom Res. 2017 Jun;97:131–5.  
87. Parker MM, Fernández A, Moffet HH, Grant RW, Torreblanca A, Karter AJ. Association of Patient-Physician Language Concordance and Glycemic Control for Limited–English Proficiency Latinos With Type 2 Diabetes. JAMA Intern Med. 2017 Mar 1;177(3):380.  
88. Hojat M, Louis DZ, Markham FW, Wender R, Rabinowitz C, Gonnella JS. Physiciansʼ Empathy and Clinical Outcomes for Diabetic Patients. Academic Medicine. 2011 Mar;86(3):359–64.  
89. Williams JS, Walker RJ, Smalls BL, Hill R, Egede LE. Patient-Centered Care, Glycemic Control, Diabetes Self-Care, and Quality of Life in Adults with Type 2 Diabetes. Diabetes Technol Ther. 2016 Oct;18(10):644–9.  
90. Intensive blood-glucose control with sulphonylureas or insulin compared with conventional treatment and risk of complications in patients with type 2 diabetes (UKPDS 33). The Lancet. 1998 Sep;352(9131):837–53.  
91. Davies MJ, Aroda VR, Collins BS, Gabbay RA, Green J, Maruthur NM, et al. Management of Hyperglycemia in Type 2 Diabetes, 2022. A Consensus Report by the American Diabetes Association (ADA) and the European Association for the Study of Diabetes (EASD). Diabetes Care [Internet]. 2022 Sep 28;45(11):2753–86. Available from: https://doi.org/10.2337/dci22-0034  
55  
92. Lyra R, Albuquerque L, Cavalcanti S, Tambascia M, Valente F, Bertoluci M. Tratamento farmacológico da hiperglicemia no DM2. Diretriz Oficial da Sociedade Brasileira de Diabetes. 2022;  
93. ADA. 9. Pharmacologic Approaches to Glycemic Treatment: Standards of Medical Care in Diabetes—2022 -Committee, American Diabetes Association Professional Practice. Diabetes Care [Internet]. 2021 Dec 16;45(Supplement_1):S125–43. Available from: https://doi.org/10.2337/dc22-S009  
94. ElSayed NA, Aleppo G, Aroda VR, Bannuru RR, Brown FM, Bruemmer D, et al. 9. Pharmacologic Approaches to Glycemic Treatment: Standards of Care in Diabetes—2023. Diabetes Care [Internet]. 2022 Dec 12;46(Supplement_1):S140–57. Available from: https://doi.org/10.2337/dc23-S009  
95. UKPDS. Group, U K Prospective Diabetes Study (UKPDS)- Effect of intensive bloodglucose control with metformin on complications in overweight patients with type 2 diabetes (UKPDS 34). The Lancet. 1998;352(9131):854–65.  
96. Foretz M, Guigas B, Viollet B. Metformin: update on mechanisms of action and repurposing potential. Nat Rev Endocrinol [Internet]. 2023;19(8):460–76. Available from: https://doi.org/10.1038/s41574-023-00833-4  
97. Moraes EM. A arte da (des) prescrição no idoso: a dualidade terapêutica, 1oed. Belo Horizonte Editora Folium. 2018;266–305.  
98. Aroda VR, Christophi CA, Edelstein SL, Zhang P, Herman WH, Barrett-Connor E, et al. The effect of lifestyle intervention and metformin on preventing or delaying diabetes among women with and without gestational diabetes: the Diabetes Prevention Program outcomes study 10-year follow-up. J Clin Endocrinol Metab. 2015;100(4):1646–53.  
99. de Moraes EN, Reis AMM, de Moraes FL. Manual de terapêutica segura no Idoso. Belo Horizonte Folium. 2019;  
100.  Lyra R, Albuquerque L, Cavalcanti S, Tambascia M, Silva Júnior WS, Bertoluci M. Manejo da terapia antidiabética no DM2. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
101.  ElSayed NA, McCoy RG, Aleppo G, Bajaj M, Balapattabi K, Beverly EA, et al. 9. Pharmacologic Approaches to Glycemic Treatment: Standards of Care in Diabetes—2025. Diabetes Care. 2025 Jan 1;48(Supplement_1):S181–206.  
102.  Brasil. Ministério da Saúde. Formulário terapêutico nacional 2010: Rename 2010. 2010;  
103.  Tessier D, Dawson K, Tétrault JP, Bravo G, Meneilly GS. Glibenclamide vs Gliclazide in Type 2 Diabetes of the Elderly. Diabetic Medicine [Internet]. 1994 Dec 1;11(10):974–80. Available from: https://doi.org/10.1111/j.1464-5491.1994.tb00256.x  
104.  American Geriatrics Society 2023 updated AGS Beers Criteria® for potentially inappropriate medication use in older adults. J Am Geriatr Soc. 2023;71(7).  
105.  Xu B, Li S, Kang B, Zhou J. The current role of sodium-glucose cotransporter 2 inhibitors in type 2 diabetes mellitus management. Cardiovasc Diabetol [Internet]. 2022;21(1):83. Available from: https://doi.org/10.1186/s12933-022-01512-w  
106.  Brasil. Ministério da Saúde. Diretrizes Clínicas para o Cuidado ao paciente com Doença Renal Crônica – DRC. Disponível em: https://www.gov.br/conitec/ptbr/midias/protocolos/diretriz-cuidados-drc.pdf. 2014.  
56  
107.  Brasil. Ministério da Saúde. Diretrizes Brasileiras para Diagnóstico e Tratamento da Insuficiência Cardíaca com Fração de Ejeção Reduzida. Disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/portaria/2020/20210825_portariaconjunta-17_diretrizes-brasileiras-icfer.pdf. 2020.  
108.  Brasil. Ministério da Saúde. Relatório 524- Empagliflozina e dapagliflozina para o tratamento de diabetes mellitus tipo 2. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2020/relatorio_524_empagliflozina_e_dapagliflozina_diabetes_mell itus_tipo_2_final.pdf. 2020.  
109.  AstraZeneca. Bula Forxiga - Dapagliflozina. Disponível em: https://www.astrazeneca.com.br/content/dam/az-br/Medicine/medicinepdf/Forxiga_Bula_Paciente_FRX015.pdf.  
110.  Bahia L, Almeida-Pititto B de, Bertoluci M. Tratamento do DM2 no SUS. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
111.  Lamounier RN, Geloneze B, Leite SO, Montenegro R, Zajdenverg L, Fernandes M, et al. Hypoglycemia incidence and awareness among insulin-treated patients with diabetes: the HAT study in Brazil. Diabetol Metab Syndr. 2018 Dec 21;10(1):83.  
112.  LaSalle JR, Berria Rachele. Insulin Therapy in Type 2 Diabetes Mellitus: A Practical Approach for Primary Care Physicians and Other Health Care Professionals. Journal of Osteopathic Medicine. 2013;113(2):152–62.  
113.  Home PD, Bolli GB, Mathieu C, Deerochanawong C, Landgraf W, Candelas C, et al. Modulation of insulin dose titration using a hypoglycaemia‐sensitive algorithm: insulin glargine versus neutral protamine Hagedorn insulin in insulin‐naïve people with type 2 diabetes. Diabetes Obes Metab. 2015 Jan 12;17(1):15–22.  
114.  Stewart-Lynch A, Meyers R, Sidig D, McConville S oh, Heiple L. Quantifying and Characterizing the Presence of Insulin Overbasalization in a Family Medicine Practice. Clinical Diabetes. 2024 Apr 1;42(2):266–73.  
115.  Mehta R, Goldenberg R, Katselnik D, Kuritzky L. Practical guidance on the initiation, titration, and switching of basal insulins: a narrative review for primary care. Ann Med. 2021 Jan 24;53(1):999–1010.  
116.  Dehghani M, Sadeghi M, Barzkar F, Maghsoomi Z, Janani L, Motevalian SA, et al. Efficacy and safety of basal insulins in people with type 2 diabetes mellitus: a systematic review and network meta-analysis of randomized clinical trials. Front Endocrinol (Lausanne). 2024 Mar 21;15.  
117.  Misra-Hebert AD, Pantalone KM, Ji X, Milinovich A, Dey T, Chagin KM, et al. Patient Characteristics Associated With Severe Hypoglycemia in a Type 2 Diabetes Cohort in a Large, Integrated Health Care System From 2006 to 2015. Diabetes Care. 2018 Jun 1;41(6):1164–71.  
118.  Dunn CJ, Plosker GL, Keating GM, McKeage K, Scott LJ. Insulin Glargine. Drugs. 2003;63(16):1743–78.  
119.  Owens DR. Stepwise intensification of insulin therapy in Type 2 diabetes management— exploring the concept of the basal‐plus approach in clinical practice. Diabetic Medicine. 2013 Mar 20;30(3):276–88.  
57  
120.  Diabetes Coalition of California. Type 2 diabetes adult outpatient insulin guidelines. [Internet]. California; 2010 [cited 2025 Jun 8]. Available from: https://med.stanford.edu/content/dam/sm/cerc/documents/DCACoalition_Insulin_Guidelines.pdf  
121.  Wojciechowski P, Niemczyk-Szechowska P, Olewińska E, Jaros P, Mierzejewska B, Skarżyńska-Duk J, et al. Clinical efficacy and safety of insulin aspart compared with regular human insulin in patients with type 1 and type 2 diabetes: a systematic review and meta-analysis. Pol Arch Intern Med. 2015 Jan 30;125(3):141–51.  
122.  Silver B, Ramaiya K, Andrew SB, Fredrick O, Bajaj S, Kalra S, et al. EADSG Guidelines: Insulin Therapy in Diabetes. Diabetes Therapy. 2018 Apr 5;9(2):449–92.  
123.  Brasil. Relatório de recomendação 949 - Insulinas análogas de ação rápida para tratamento do diabetes mellitus tipo 2 [Internet]. Brasília; 2024 [cited 2025 Sep 1]. Available from: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-949insulinas-acao-rapida/  
124.  Paluchamy T. Hypoglycemia: Essential Clinical Guidelines. In: Szablewski L, editor. Blood Glucose Levels . Londres: IntechOpen; 2019.  
125.  ElSayed NA, Aleppo G, Aroda VR, Bannuru RR, Brown FM, Bruemmer D, et al. 6. Glycemic Targets: Standards of Care in Diabetes - 2023. Diabetes Care. 2023 Jan 1;46(Supplement_1):S97–110.  
126.  Cryer PE. Iatrogenic Hypoglycemia as a Cause of Hypoglycemia-Associated Autonomic Failure in IDDM: A Vicious Cycle. Diabetes. 1992 Mar 1;41(3):255–60.  
127.  The International Hypoglycaemia Study Group. Glucose concentrations of less than 3.0 mmol/l (54 mg/dl) should be reported in clinical trials: a joint position statement of the American Diabetes Association and the Europian Association for the Study of Diabetes. Diabetologia. 2017 Jan 21;60(1):3–6.  
128.  Brasil. Protocolo Clínico e Diretrizes Terapêuticas – Retinopatia Diabética [Internet]. Brasília; 2021 [cited 2025 May 14]. Available from: https://www.gov.br/conitec/ptbr/midias/protocolos/20211220_portal_retinopatia_diabetica.pdf  
129.  Colhoun HM, Lee ET, Bennett PH, Lu M, Keen H, Wang SL, et al. Risk factors for renal failure: The WHO multinational study of vascular disease in diabetes. Diabetologia. 2001 Sep;44(S2):S46–53.  
130.  Nerbass FB, Lima H do N, Moura-Neto JA, Lugon JR, Sesso R. Censo Brasileiro de Diálise 2022. Brazilian Journal of Nephrology. 2024 Jun;46(2).  
131.  Wu AYT, Kong NCT, de Leon FA, Pan CY, Tai TY, Yeung VTF, et al. An alarmingly high prevalence of diabetic nephropathy in Asian type 2 diabetic patients: the MicroAlbuminuria Prevalence (MAP) Study. Diabetologia. 2005 Jan 23;48(1):17–26.  
132.  Sá JR, Canani LH, Rangel ÉB, Bauer AC, Escott GM, Zelmanovitz T, et al. Avaliação e tratamento da doença renal do diabetes. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
133.  Rolim LC, Thyssen PJ, Flumignan RL, Andrade DC de, Dib SA, Bertoluci M. Diagnóstico e tratamento da neuropatia periférica diabética. In: Diretriz Oficial da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2022.  
58  
134.  Rolim LC, Sá JR de, Chacra AR, Dib SA. Heterogeneidade clínica e coexistência das neuropatias diabéticas: diferenças e semelhanças entre diabetes melito tipos 1 e 2. Arquivos Brasileiros de Endocrinologia & Metabologia. 2009 Oct;53(7):818–24.  
135.  Feldman EL, Callaghan BC, Pop-Busui R, Zochodne DW, Wright DE, Bennett DL, et al. Diabetic neuropathy. Nat Rev Dis Primers. 2019 Jun 13;5(1):41.  
136.  Pop-Busui R, Boulton AJM, Feldman EL, Bril V, Freeman R, Malik RA, et al. Diabetic Neuropathy: A Position Statement by the American Diabetes Association. Diabetes Care. 2017 Jan 1;40(1):136–54.  
137.  Ting DSW, Cheung GCM, Wong TY. Diabetic retinopathy: global prevalence, major risk factors, screening practices and public health challenges: a review. Clin Exp Ophthalmol. 2016 May 17;44(4):260–77.  
138.  Willis JR, Doan Q V., Gleeson M, Haskova Z, Ramulu P, Morse L, et al. Vision-Related Functional Burden of Diabetic Retinopathy Across Severity Levels in the United States. JAMA Ophthalmol. 2017 Sep 1;135(9):926.  
139.  Malerbi F, Andrade R, Morales P, Travassos S, Rodacki M, Bertoluci M. Manejo da retinopatia diabética. In: Diretriz Oficial da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2022.  
140.  Aiello LM. Perspectives on diabetic retinopathy. Am J Ophthalmol. 2003 Jul;136(1):122– 35.  
141.  Brasil. Protocolo Clínico e Diretrizes Terapêuticas de Sobrepeso e Obesidade em Adultos [Internet]. Brasília; 2020 [cited 2025 May 14]. Available from: https://www.gov.br/saude/pt-br/composicao/saps/ecv/publicacoes/protocolo-clinico-ediretrizes-terapeuticas-pcdt-para-sobrepeso-e-obesidade-em-adultos/  
142.  Sacco ICN, Lucovéis M do LS, Thuler SR, Parisi MCR, Bertoluci M. Diagnóstico e prevenção de úlceras no pé diabético. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
143.  Brasil. Ministério da Saúde. Manual do pé diabético: estratégias para o cuidado da pessoa com doença crônica [Internet]. Brasília; 2016 [cited 2025 Sep 16]. Available from: http://189.28.128.100/dab/docs/portaldab/publicacoes/manual_do_pe_diabetico.pdf  
144.  Sacco ICN, Lucovéis M do LS, Thuler SR, Parisi MCR, Bertoluci M. Diagnóstico e prevenção de úlceras no pé diabético. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
145.  The International Working Group on the Diabetic Foot (IWGDF). Practical guidelines on the prevention and management of diabetes-related foot disease - Part of the 2023 IWGDF Guidelines on the prevention and management of diabetes-related foot disease [Internet]. 2023 [cited 2025 Sep 16]. Available from: https://iwgdfguidelines.org/wpcontent/uploads/2023/07/IWGDF-2023-01-Practical-Guidelines.pdf  
146.  Duarte Junior EG, Lopes CF, Gaio DRF, Mariúba JV de O, Cerqueira L de O, Manhanelli Filho MAB, et al. Diretrizes da Sociedade Brasileira de Angiologia e de Cirurgia Vascular sobre o pé diabético 2023. J Vasc Bras. 2024;23.  
147.  ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Briggs Early K, et al. 13. Older Adults: Standards of Care in Diabetes—2025. Diabetes Care. 2025 Jan 1;48(Supplement_1):S266–82.  
59  
148.  Moura F, Salles JEN, Valente F, Almeida-Pititto B de, Fonseca RMC, Minicucci W, et al. O paciente idoso com diabetes. In: Diretriz da Sociedade Brasileira de Diabetes - Edição 2025. Conectando Pessoas; 2025.  
149.  Lyra R, Albuquerque L, Cavalcanti S, Tambascia M, Silva Júnior WS, Bertoluci M. Manejo da terapia antidiabética no DM2. In: Diretriz da Sociedade Brasileira de Diabetes. Conectando Pessoas; 2024.  
150.  ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Briggs Early K, et al. 5. Facilitating Positive Health Behaviors and Well-being to Improve Health Outcomes: Standards of Care in Diabetes—2025. Diabetes Care [Internet]. 2025 Jan 1;48(Supplement_1):S86–127. Available from: https://diabetesjournals.org/care/article/48/Supplement_1/S86/157563/5-FacilitatingPositive-Health-Behaviors-and-Well  
151.  Linsky AM, Motala A, Lawson E, Shekelle P. Deprescribing To Reduce Medication Harms in Older Adults: Rapid Response. 2024 Feb. In: Making Healthcare Safer IV: A Continuous Updating of Patient Safety Harms and Practices [Internet]. Rockville (MD): Agency for Healthcare Research and Quality (US); 2023 Jul–. PMID: 38349984.  
152.  ElSayed NA, McCoy RG, Aleppo G, Bajaj M, Balapattabi K, Beverly EA, et al. 9. Pharmacologic Approaches to Glycemic Treatment: Standards of Care in Diabetes—2025. Diabetes Care [Internet]. 2025 Jan 1;48(Supplement_1):S181–206. Available from: https://diabetesjournals.org/care/article/48/Supplement_1/S181/157569/9Pharmacologic-Approaches-to-Glycemic-Treatment  
153.  ElSayed NA, McCoy RG, Aleppo G, Balapattabi K, Beverly EA, Early B, et al. 6. Glycemic Goals and Hypoglycemia: Standards of Care in Diabetes—2025. Diabetes Care [Internet]. 2025 Jan 1;48(Supplement_1):S128–45. Available from: https://diabetesjournals.org/care/article/48/Supplement_1/S128/157561/6-GlycemicGoals-and-Hypoglycemia-Standards-of  
154.  Blonde L, Umpierrez GE, Reddy SS, McGill JB, Berga SL, Bush M, et al. American Association of Clinical Endocrinology Clinical Practice Guideline: Developing a Diabetes Mellitus Comprehensive Care Plan—2022 Update. Endocrine Practice. 2022 Oct 1;28(10):923–1049.  
155.  Marx N, Federici M, Schütt K, Müller-Wieland D, Ajjan RA, Antunes MJ, et al. 2023 ESC Guidelines for the management of cardiovascular disease in patients with diabetes. Eur Heart J. 2023 Oct 14;44(39):4043–140.  
156.  Brasil. Protocolos de encaminhamento da atenção básica para a atenção especializada: Endocrinologia e nefrologia [Internet]. Ministério da Saúde, Universidade Federal do Rio Grande do Sul. 2015 [cited 2025 May 14]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/protocolos_atencao_basica_atencao_especial izada_endocrinologia.pdf  
157.  Brasil. Ministério da Saúde. Relatório no 773- Dapagliflozina para tratamento de pacientes adultos com doença renal crônica em uso de terapia padrão. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20220927_relatorio_773_dapagliflozina_doenca_renal_cronic a_final.pdf. 2022.  
158.  Brasil. Ministério da Saúde. PORTARIA No 11, DE 13 DE MARÇO DE 2017 Torna pública a decisão de incorporar caneta para injeção de insulina humana NPH e insulina  
60  
humana regular no âmbito do Sistema Único de Saúde - SUS. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/sctie/2017/prt0011_14_03_2017.html. 2017.  
61  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE DAPAGLIFLOZINA, GLIBENCLAMIDA, GLICLAZIDA, INSULINA HUMANA NPH, INSULINA HUMANA REGULAR, INSULINA ANÁLOGA DE AÇÃO RÁPIDA, INSULINA ANÁLOGA DE AÇÃO PROLONGADA E CLORIDRATO DE METFORMINA  
Eu,  
(nome do [a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **dapagliflozina, glibenclamida, gliclazida, insulina humana NPH, insulina humana regular, insulina análoga de ação rápida, insulina análoga de ação prolongada e cloridrato de metformina** , indicada para o tratamento do diabete melito tipo 2.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico ________________________________________________________________ (nome do  
médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Prevenção das complicações da doença;  
- Controle da atividade da doença;  
- Melhora da capacidade de realizar atividades funcionais; e  
- Melhora da qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Eventos adversos da **dapagliflozina:** gravidez e período de lactação; não deve ser usado em pacientes com TFG estimada persistentemente inferior a 25 mL/min/1,73 m<sup>2</sup> .  
- Eventos adversos da **glibenclamida e gliclazida:** apresentam risco significativo de hipoglicemia (especialmente a glibenclamida), além de ganho de peso. São contraindicadas se houver TFGe < 30 mL/min/1,73 m², insuficiência hepática, sinais de deficiência grave de insulina, infecções graves, gestação. A glibenclamida não é recomendada para pacientes com idade igual ou superior a 60 anos.  
- Eventos adversos da **insulina humana NPH, insulina humana regular, insulina análoga de ação rápida (AIAR) e de ação prolongada (AIAP):** não há contraindicações absolutas. Atentar para hipoglicemias. Reações alérgicas são raras, usualmente cutâneas e passíveis de cuidado com dessensibilização ou troca de apresentação.  
- Eventos adversos do **cloridrato de metformina:** é contraindicado se houver doença renal com TFGe < 30 mL/min/1,73 m², insuficiência cardíaca congestiva, alcoolismo, sepse ou outros quadros clínicos graves, doença hepática grave ou lactação. Ressalta-se que o risco de ocorrência de efeitos adversos aos medicamentos aumenta com  
- a superdosagem.  
Os eventos adversos mais comuns no local da aplicação de insulinas são:  
- Dor associado à administração de insulina gelada e reuso de agulhas, principalmente.  
62  
- Lipohipertrofia aumento do tecido adiposo, causado por aplicações frequentes no mesmo lugar e reuso de agulhas, orientar rodízio entre os sítios de aplicação de insulina e reduzir o número de aplicações com a mesma agulha.  
- Refluxo de insulina, orientar contar até 10 antes de retirar a agulha do subcutâneo  
- Sangramento e hematoma é raro;  
Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) dapagliflozina  
- (    ) glibenclamida  
- (    ) gliclazida  
- (    ) insulina humana NPH  
- (    ) insulina humana regular  
- (    ) insulina análoga de ação rápida  
- (  ) insulina análoga de ação prolongada  
- (    ) cloridrato de metformina  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal paciente ou do responsável legal aciente ou do responsável legal ponsável legal onsável legal vel legal el legal gal al<br><!-- End of picture text -->  
<!-- Start of picture text -->
_____________________________________<br>Assinatura do paciente ou do responsável legal paciente ou do responsável legal aciente ou do responsável legal ponsável legal onsável legal vel legal el legal gal al<br>Médico responsável: CRM: UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data: ____________________<br><!-- End of picture text -->  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
63  
MATERIAL SUPLEMENTAR A – ORIENTAÇÃO EM RELAÇÃO À APLICAÇÃO DE INSULINA  
A via de administração ambulatorial das insulinas é a subcutânea (SC). Atualmente, a administração de insulina no SUS pode ser feita por meio do uso de seringas ou canetas. A equipe de saúde responsável pelo cuidado da pessoa com DM2 deve fornecer informações quanto ao armazenamento, transporte e preparo da insulina e deve conhecer as técnicas de aplicação e ensiná-las aos pacientes e cuidadores, fazendo, periodicamente, a revisão da técnica que está sendo utilizada pelo paciente, para garantir a efetividade do tratamento.  
A aplicação SC pode ser realizada nos braços, no abdômen, nas coxas e nádegas conforme apresentado no **MATERIAL SUPLEMENTAR B** . A velocidade de absorção varia conforme o local de aplicação, sendo mais rápida no abdômen, intermediária nos braços e mais lenta nas coxas e nádegas. Há variações da cinética da insulina se injetada em segmentos envolvidos na prática de atividades físicas ou de exercícios físicos, como nos membros superiores e inferiores<sup>(1,2)</sup> .  
É necessário lavar as mãos com água e sabão antes da preparação da insulina. Para garantir a dosagem correta de insulina, deve-se homogeneizar as suspensões de insulina (humana NPH isolada ou associada a insulina humana regular) antes do uso, rolando gentilmente o frasco de insulina entre as mãos, cerca de 20 vezes, antes de aspirar seu conteúdo. Injetar ar em quantidade equivalente à da dose dentro do frasco para facilitar a aspiração da insulina. Em caso de combinação de dois tipos de insulina, deve-se aspirar antes a insulina de ação curta (insulina humana regular) para que o frasco não receba protamina, presente na insulina humana NPH, e altere sua velocidade de absorção ( **MATERIAL SUPLEMENTAR C** ).  
Antes da aplicação, o local da injeção deve ser inspecionado para garantir que se encontre livre de lipodistrofia, edema, inflamação e infecções. É importante realizar rodízio do local de aplicação sistematicamente, de modo a manter uma distância mínima de 1,5 cm entre cada injeção, para evitar desenvolvimento de lipodistrofia e o descontrole glicêmico. O esquema de administração deve ser planejado de modo que previna reaplicação no mesmo local em menos de 15 a 20 dias, para prevenção da ocorrência de lipodistrofia<sup>(3)</sup> .  
Para a aplicação da insulina, é necessário pinçar levemente o local de aplicação entre dois dedos e introduzir a agulha completamente, em ângulo de 90 graus. Entretanto, em crianças ou indivíduos muito magros, essa técnica pode resultar em aplicação intramuscular, com absorção mais rápida da insulina; nesses casos podem-se utilizar agulhas mais curtas (4 ou 5 mm) ou ângulo de 45 graus. Após a aplicação, deve-se esperar 10 segundos antes de retirar a agulha do subcutâneo para garantir injeção de toda a dose de insulina e não é necessário puxar o êmbolo para verificar a presença de sangue ( **MATERIAL SUPLEMENTAR D** ).  
O reuso de seringas e agulhas de insulina por um número limitado de vezes pode ser considerado, sendo importante orientar os pacientes quanto a isto. Além disso, as seringas e agulhas devem ser substituídas quando o paciente notar aumento na sensação de dor, o que se  
> 1 HC-UFMG. Centro de telessaúde. Hospital das Clínicas. Universidade Federal de Minas Gerais. Júnia Xavier Maia. Uso de Insulina no Diabetes Tipo 2. Disponível em: www.telessaude.hc.ufmg.br.  
> 2 ADA. 8. Pharmacologic Approaches to Glycemic Treatment: Standards of Medical Care in Diabetes— 2018 - American Diabetes Association. Diabetes Care [Internet]. 24 de novembro de 2017;41(Supplement_1):S73–85. Disponível em: https://doi.org/10.2337/dc18-S008  
> 3 Brasil. Ministério da Saúde. Cadernos de Atenção Básica no36,- Diabetes mellitus. Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/estrategias_cuidado_pessoa_diabetes_mellitus_cab36.pdf. 2013.  
64  
estima que aconteça em até oito utilizações, podendo existir variabilidade entre os pacientes devido à espessura da pele e à obesidade. A substituição também deve ser realizada quando for observada perda da escala de graduação da seringa. Para pacientes em situação de vulnerabilidade social, como aqueles que vivem em situações precárias de moradia e saneamento, não se recomenda a reutilização de agulhas, visto que nesses casos essa prática pode apresentar riscos maiores para os pacientes.  
Uma alternativa para administração de insulina é a caneta. Essa tecnologia, quando disponível, é recomendada por fornecer melhor comodidade na aplicação, facilidade de transporte e manuseio quando comparada às seringas, tendendo a reduzir o uso de frascos e seringas e, consequentemente, alterando os valores do custo do tratamento<sup>(4)</sup> . Além disso, o uso da caneta de insulina está associado a um melhor controle glicêmico e menor incidência de hipoglicemia comparando com as seringas<sup>(5)</sup> . Assim, seu uso pode ter benefício maior em idosos, iletrados (analfabetos e semianalfabetos), com dificuldade visual e com tremores essenciais. Considerando a diversidade de canetas de insulina disponíveis no mercado, que podem se diferenciar pela marca, graduação e dose máxima por aplicação, o paciente deve observar a técnica de aplicação disponibilizada pelo fabricante do produto. Orientações adicionais sobre a aplicação, o armazenamento e o transporte de insulina podem ser consultadas no Caderno de Atenção Básica - Estratégias para o cuidado da pessoa com doença crônica: diabetes mellitus, do Ministério da Saúde<sup>(6)</sup> .  
> 4 ADA. 8. Pharmacologic Approaches to Glycemic Treatment: Standards of Medical Care in Diabetes— 2018 - American Diabetes Association. Diabetes Care [Internet]. 24 de novembro de 2017;41(Supplement_1):S73–85. Disponível em: https://doi.org/10.2337/dc18-S008  
> 5 Banca R, Marroni M, Oliveria M, Sparapani V, Pascali P, Oliveira S, et al. Técnicas de aplicação de insulina. Diretriz Oficial da Sociedade Brasileira de Diabetes (2022). Diretriz Oficial da Sociedade Brasileira de Diabetes. 2022;  
> 6 Brasil. Ministério da Saúde. Cadernos de Atenção Básica no36,- Diabetes mellitus. Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/estrategias_cuidado_pessoa_diabetes_mellitus_cab36.pdf. 2013.  
65  
MATERIAL SUPLEMENTAR B – LOCAIS PARA A APLICAÇÃO DA INSULINA  
<!-- Start of picture text -->
= (amDash /y }<br>oN a, \ —~ |<br>A | Uy Ue f\ \3 |<br>a<br>A B<br><!-- End of picture text -->  
**Figura S1.** Locais para aplicação da insulina.  
**Nota:** Locais mais apropriados para a injeção de insulina (A). Detalhamento da recomendação de rodízio sequencial em diferentes quadrantes da superfície cutânea (B). **Fonte:** Sociedade Brasileira de Diabetes<sup>(7)</sup> .  
> 7 Banca R, Marroni M, Oliveria M, Sparapani V, Pascali P, Oliveira S, et al. Técnicas de aplicação de insulina. Diretriz Oficial da Sociedade Brasileira de Diabetes (2022). Diretriz Oficial da Sociedade Brasileira de Diabetes. 2022;  
66  
MATERIAL SUPLEMENTAR C – COMO PREPARAR A INSULINA  
<!-- Start of picture text -->
1 4 Retirar o protetor e<br>SERINGA DE 1 cc evitar encostar os<br>cada subdivisao = 2 unidades dedos na agulha para<br>que nao ocorra<br>contaminacdo.<br>deProtetor agulha See<br>i SE OS<br>5<br>SERINGA DE 0,5 cc<br>cada subdivisdo = 1 unidade ‘al<br>Puxar 0 émbolo<br>deagulhaProtetor — Canula daquantidade seringamarca daaté de a<br>z ee insulina que<br>am, = voce usa,<br>Bisel Corpo da seringa: Protetor<br>de émboto 6<br>Injetar o ar de<br>dentro da<br>2 | permiteinsulina, queistoa<br>Lavar bem as mos com agua e sabao. insulina seja<br>facilmente<br>retirada do<br>frasco.<br>.<br>py' 7<br>t Virar 0 frasco e a seringa<br>para baixo.<br>Puxar o émbolo lentamente,<br>para aspirar a insulina para<br>dentro da seringa.<br>3<br>Rolar 0 frasco<br>entre as maos<br>para misturar a 8 Verificar se existem<br>insulina. Nao bolhas de ar. Para tiré-<br>agitar o frasco. las, bater com 0 dedo<br>na parte da seringa<br>onde elas esto ou<br>injetar a insulina de<br>Hangertonnbea i voltaseguid p a ,raretirar o frasco. a dose Em<br>usando algodio de insulina que vocé<br>‘com alcool. vai usar.<br><!-- End of picture text -->  
**Fonte:** Caderno de Atenção Básica nº 36 do Ministério da Saúde<sup>(8)</sup>  
Técnica de preparo e aplicação de insulina com caneta  
> 8 Brasil. Ministério da Saúde. Cadernos de Atenção Básica no36,- Diabetes mellitus. Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/estrategias_cuidado_pessoa_diabetes_mellitus_cab36.pdf. 2013.  
67  
Cada caneta tem peculiaridades quanto ao manuseio, à troca do refil, ao registro da dose e à conservação. Recomenda-se a leitura do manual de instruções do fabricante para o uso correto da caneta.  
A aplicação com caneta somente deverá ser feita por profissional de saúde quando a agulha para caneta possuir dispositivo de segurança. Alguns passos comuns ao uso de todas as canetas são:  
1. Lavar e secar as mãos.  
2. Reunir o material necessário: caneta e insulina, agulha, algodão e álcool 70%.  
3. Homogeneizar a insulina, se suspensão.  
4. Realizar desinfecção com álcool 70%, no local em que será acoplada a agulha e esperar secar. Acoplar a agulha.  
5. Comprovar fluxo de insulina conforme orientação do fabricante.  
6. Selecionar a dose de insulina necessária (girando a parte de trás da caneta)  
7. Realizar antissepsia com álcool 70% no local escolhido para a aplicação e esperar secar. **Observação:** A recomendação para a limpeza do local de aplicação deve ser seguida para locais que não estejam limpos ou se a aplicação for realizada em um local com chances de contaminação (por exemplo, hospitais).  
8. Realizar prega subcutânea, se indicado.  
9. Introduzir a agulha no subcutâneo.  
10. Pressionar o botão injetor da caneta para injetar a insulina.  
11. Aguardar, no mínimo, 10 segundos para retirar a agulha.  
12. Retirar a agulha.  
13. Soltar a prega subcutânea.  
Outras instruções gerais  
- As canetas recarregáveis, assim como as descartáveis, possuem cores e ou identificações diferenciadas, para prevenir o risco de troca no tipo de insulina no momento da aplicação, assim o paciente deve ser orientado sobre estes aspectos no momento da dispersão.  
- Os fabricantes não recomendam guardar a caneta recarregável em geladeira, pois podem ocorrer danos no mecanismo interno e interferir na aplicação da dose correta.  
- Quando conservada sob refrigeração, a insulina ou a caneta descartável em uso deverá ser retirada da geladeira entre 15 a 30 minutos antes da aplicação, para prevenir dor e risco de irritação no local de aplicação.  
- Recomenda-se ângulo de 90º, quando o comprimento da agulha for 4 mm ou 5 mm. Caso a agulha seja de 6 mm ou 8 mm de comprimento, o ângulo poderá variar entre 90º (em adultos) e 45º (em crianças). Para agulhas com comprimento acima de 8 mm o ângulo de aplicação deverá ser de 45º, sempre em direção podálica.  
Fonte: Adaptado de SBD. Disponível em: https://www.diabetes.org.br/profissionais/images/pdf/diabetes-tipo1/002-Diretrizes-SBDAplicacao-Insulina-pg219.pdf. Acesso em setembro de 2020.  
68  
MATERIAL SUPLEMENTAR D – COMO APLICAR A INSULINA  
<!-- Start of picture text -->
= Escolher o local para aplicar a insulina. = Ao iniciar a aplicagao da insulina, se for<br>Limpar a pele usando algodao com alcool encontrada a presenca de sangue na<br>e deixar secar. Manter uma distancia de seringa, seguir as seguintes orientacdes:<br>mais ou menos 1,5 cm do local onde vocé 1) Sangue em pequena quantidade:<br>tomou a injegdo anterior, se a area do continuar a aplicagao;<br>corpo for a mesma. 2) Sangue em grande quantidade: parar a<br>|: aplicagdo. Jogue prpare outradose. e foraseringa coma insulina<br>Ml = Fazer uma prega na pele onde vocé vai $<br>aplicar‘se fosse a uminsulina. lapis.PegarIntroduzirna seringa a agulha como na phakic. — lhe ate<br>pele, num Angulo de 90°, soltar a prega seringa e fazer uma leve pressao no local.<br>cutaénea. Obs.: em pessoas muito magras Usando 0 aigodiio com aiicool<br>‘ou criangas menores, a injegao podera ser ig 2<br>feita num Angulo de 45° para evitar que<br>seja aplicada no musculo.<br><!-- End of picture text -->  
Cálculo da dose de insulina _bolus_ a ser administrada antes do almoço  
- 1) Estabelecer o fator de correção.  
- 2) Determinar o objetivo glicêmico.  
- 3) Determinar o limite superior da glicemia que corresponde à glicemia acima da qual devese utilizar _bolus_ de correção.  
**Nota:** consultar informações no item Tratamento medicamentoso em  Insulinas - insulina humana regular.  
69

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: MATERIAL SUPLEMENTAR E – CUIDADOS COM OS PÉS -->
**QUADRO S1** . Sistema de estratificação de risco de úlcera para os pés e a frequência recomendada de rastreamento.  
|**Categoria**|**Risco de**<br>**ulceração**|**Características**|**Frequência***|
|---|---|---|---|
|0|Muito baixo|Sem PSP e sem DAP|Uma vez ao ano|
|1|Baixo|PSP ou DAP|Uma vez a cada 6–12<br>meses|
|2|Moderado|PSP + DAP, ou<br>PSP + DEF, ou<br>DAP + DEF|Uma vez a cada 3–6<br>meses|
|3|Alto|PSP ou DAP e um ou mais dos seguintes:<br>• Histórico de úlcera no pé<br>• Uma amputação de membro inferior (menor<br>ou maior)<br>• Doença renal em estágio terminal|Uma vez a cada 1–3<br>meses|  
**Legenda:** PSP - perda da sensibilidade protetora; DAP - doença arterial periférica; DEF – deformidade do pé.  
**Notas:** * A frequência de triagem é baseada na opinião de especialistas, uma vez que não há evidências publicadas que apoiem esses intervalos de tempo.  
**Fonte:** IWGDF<sup>9</sup> .  
<!-- Start of picture text -->
gil fy Us =—<br>“> ' | rho<br>Oe<br><!-- End of picture text -->  
**Figura S2:** Áreas do pé com maior risco de ulceração.  
**Fonte:** Diretrizes sobre a prevenção e o tratamento de doenças do pé relacionadas ao diabetes. The International Working Group on the Diabetic Foot (IWGDF), 2023. Disponível em:  
> 9 The International Working Group on the Diabetic Foot (IWGDF). Practical guidelines on the prevention and management of diabetes-related foot disease - Part of the 2023 IWGDF Guidelines on the prevention and management of diabetes-related foot disease [Internet]. 2023. Available from: https://iwgdfguidelines.org/wp-content/uploads/2023/07/IWGDF-2023-01-Practical-Guidelines.pdf  
70  
APÊNDICE 1 – METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Atualização do Protocolo Clínico e Diretrizes Terapêuticas do Diabete Melito tipo 2 - 2025** -->
1. Escopo e finalidade do Protocolo  
O objetivo desta atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Diabete Melito tipo 2 foi incluir orientações sobre o uso das insulinas análogas de ação rápida, incorporados ao SUS, conforme Portaria SECTICS/MS n 58, de 28 de novembro de 2024, e das insulinas análogas de ação prolongada, incorporado ao SUS, conforme Portaria SECTICS/MS n° 59.  
Considerando a versão do PCDT do Diabete Melito tipo 2, publicada por meio da Portaria Conjunta SAES-SECTICS/MS nº 7/2024, esta atualização rápida focou na inclusão das insulinas análogas de ação rápida e das insulinas análogas de ação prolongada no âmbito do SUS.  
2. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do PCDT do Diabete Melito tipo 2 foi apresentada na 129ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 09 de setembro de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em Saúde (SCTIE); Secretaria de Atenção Especializada à Saúde (SAES); Secretaria de Vigilância em Saúde (SVS) e Secretaria de Atenção Primária à Saúde (SAPS). A proposta foi aprovada para avaliação da Conitec.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 3. Consulta pública -->
A Consulta Pública nº 82/2025, do Protocolo Clínico e Diretrizes Terapêuticas do Diabete Melito tipo 2, foi realizada entre os dias 23 de outubro de 2025 e 11 de novembro de 2025. Foram recebidas 353 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2025/contribuicao-da-cp-82_2025-pcdt-do-diabete-melitotipo-2.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 4. Busca da evidência e recomendações -->
Considerando a versão do PCDT do Diabete Melito tipo 2, publicado por meio da Portaria Conjunta SAES-SECTICS/MS nº 7/2024, esta atualização rápida focou na inclusão de insulinas análogas de ação rápida e insulinas análogas de ação prolongada no âmbito do SUS.Não foram elaboradas novas perguntas de pesquisa para essa atualização.  
As evidências e pergunta de pesquisa avaliadas no momento da incorporação de insulinas análogas de ação rápida e insulinas análogas de ação prolongada, incluídas nesta atualização, encontram-se nos Relatórios de Recomendação nº 949/2024 e nº 948/2024, disponível em:  
71  
<u>https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-949insulinas-acao-rapida;</u> https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-derecomendacao-948-insulinas-acao-prolongada.  
5. Equipe de elaboração e partes interessadas Colaboração externa  
O Protocolo foi atualizado pelo Hospital Alemão Oswaldo Cruz.  
Os membros do Grupo Elaborador e os participantes das reuniões de elaboração do referido PCDT estão descritos no Quadro A.  
Quadro A. Membros do Grupo Elaborador e participantes das reuniões de elaboração

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Participante** -->
**Especialistas*:** Débora Bohnen Guimarães, Guilherme Sampaio Souza, Karla Melo, Melanie Rodacki, Olivan Silva Queiroz **Metodologistas (HAOC)**:** Ariane Gonçalves da Silva de Araujo, Isabela Pina Meza, Mariana Millan Fachi, Layssa Andrade Oliveira. **Representantes de áreas técnicas:** Aline do Nascimento, Catarina Bernardes Pereira, Danilo de Jesus, Eduardo Freire de Oliveira, Eidy de Brito Farias, Fernanda Aparecida de Andrade, Fernando Freitas Alves, Izabella Barbosa de Brito, Klébya Hellen Dantas de Oliveira, Leonardo de Souza Lourenço Carvalho, Marta da Cunha Lobo Souto Maior, Myllena Maria Tomaz Caracas, Paula Stoll, Rafael Poloni, Rafaela de Paula Sales, Rafaela Tavares Peixoto, Valeria Slongo de Souza.  
*Membros votantes na reunião de escopo e/ou recomendação; **Metodologistas.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro B).  
Quadro B. Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar f<br>algum dos benefícios abaixo?|inanceiramente|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>( ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>( ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>( ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>( ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>( ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>( ) Não|  
72  
|2. Você possui apólices ou ações de alguma empresa que possa de alguma<br>forma ser beneficiada ouprejudicada com as recomendações da diretriz?|(   ) Sim<br>( ) Não|
|---|---|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de<br>marca,royalties)de alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>( ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>( ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cu<br>possam ser afetadospela sua atividade na elaboração ou revisão da diretriz?|jos interesses|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>( ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>( ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>( ) Não|
|d) Partido político|(   ) Sim<br>( )Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>( ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>( ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>( ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos<br>interessespossam ser afetados?|(   ) Sim<br>( ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer<br>oquevocê irá escrever eque deveria ser do conhecimentopúblico?|(   ) Sim<br>( ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja<br>relacionado acima, quepossa afetar sua objetividade ou imparcialidade?|(   ) Sim<br>( ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos<br>conflitos listados acima?|(   ) Sim<br>( ) Não|  
O resumo dos conflitos de interesse dos membros do Grupo Elaborador e participantes das reuniões de elaboração está no Quadro C.  
Quadro C. Declaração de conflitos de interesse dos membros do Grupo Elaborador e participantes das reuniões de elaboração.  
|**Participante**||**Conflitos de interesses declarados**<br>|**Decisão**<br>|
|---|---|---|---|
||**Questão**|**Descrição geral **|**tomada**|
|Ariane Gonçalves<br>da Silva de<br>Araujo|-|-|Declarar e<br>participar|
|Débora Bohnen<br>Guimarães|5e|Faz parte da equipe do Departamento de<br>Nutrição daSociedade Brasileira de Diabetes|Declarar e<br>participar|
|Guilherme<br>SampaioSouza|-|-|Declarar e<br>participar|
|Isabela Pina Meza|-|-|Declarar e<br>participar|
|Karla Melo|1a; 1b; 5e|Recebeu honorários para apresentação de<br>aulas e participação em congressos, na área de<br>diabetes;Coordenadora do Departamento de|Declarar e<br>participar|  
73  
|**Participante**||**Conflitos de interesses declarados**<br>|**Decisão**<br>|
|---|---|---|---|
||**Questão**|**Descrição geral **|**tomada**|
|Ariane Gonçalves<br>da Silva de<br>Araujo|-|-|Declarar e<br>participar|
|||Saúde Pública da Sociedade Brasileira de<br>Diabetes||
|Layssa Andrade<br>Oliveira|-|-|Declarar e<br>participar|
|Mariana Millan<br>Fachi|-|-|Declarar e<br>participar|
|Melanie Rodacki|1b|Recebeu honorários de indústrias para<br>produção de material científico sobre o uso<br>de insulina para DM1, uso de sensores de<br>glicose e insulina semanal.|Declarar e<br>participar|
|Olivan Silva<br>Queiroz|-|-|Declarar e<br>participar|
|Tassiane Cristine<br>Santos de Paula|-|-|Declarar e<br>participar|

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Alteração pós publicação** -->
Depois da publicação da Portaria SECTICS/MS nº 7/2024, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas do Diabete Melito tipo 2, pela necessidade de se substituir o termo “Cirurgia Cardiovascular” por “Cirurgia Vascular” no Quadro 17. Ainda, foi corrigido o termo “Práticas Integrativas e Complementares (PIC)” por “Práticas Integrativas e Complementares em Saúde (PICS)”. Para tal, foi também adequado o Relatório de Recomendação nº 882/2024 da Conitec.  
O tema foi apresentado como informe à 114ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 16/04/2024.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 6. Escopo e finalidade do Protocolo -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretriz de Tratamento (PCDT) do Diabete Melito tipo 2 (DM2) contendo a descrição da metodologia e as recomendações, tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (DGITS/SECTICS/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo.  
74  
A revisão do PCDT do Diabete Melito tipo 2 foi iniciada com a reunião virtual para delimitação do escopo realizada em 29 de maio de 2023, cujo objetivo foi discutir a atualização do referido PCDT. A reunião teve a participação de quatro membros do Grupo Elaborador, seis especialistas, e treze membros do Comitê Gestor.  
A dinâmica da reunião foi conduzida com base no PCDT publicado por meio da Portaria SCTIE/MS nº 54, de 11 de novembro de 2020 e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas clínicas e identificar tecnologias em saúde que poderiam ser consideradas nas recomendações.  
A elaboração desse documento foi uma demanda proveniente da decisão de ampliação de uso de dapagliflozina para pacientes com DM2 com necessidade de segunda intensificação de tratamento e alto risco para desenvolver doença cardiovascular (DCV) ou com DCV já estabelecida e idade entre 40-64 anos, por meio da Portaria SECTICS/MS nº 09, de 05 de abril de 2023.  
Foram adotadas as recomendações diagnósticas, de tratamento ou acompanhamento da versão vigente do Protocolo assim como de outros documentos publicados pelo Ministério da Saúde. Não foram estabelecidas questões de pesquisa, por se tratar de práticas clínicas estabelecidas e por se tratar de uma atualização motivada pela incorporação de tecnologia em saúde.  
7. Equipe de elaboração e partes interessadas  
Colaboração externa  
O Protocolo foi atualizado pelo Hospital Alemão Oswaldo Cruz.  
Os participantes das reuniões de elaboração do referido PCDT estão descritos no Quadro  
A.  
Quadro A. Participantes das reuniões virtuais.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Participante** -->
**Especialista*:** André Klafke de Lima (Grupo Hospitalar Conceição); Maria Edna de Melo (USP/HCFMUSP); Renata Bertazzi Levy (USP); Tarcila Beatriz Ferraz de Campos (UDE); Tarissa Beatrice Zanata Petry <u>(HAOC); Thais Alessa Leite (SAES/MS)</u> **Metodologistas (HAOC):** Rosa Camila Lucchetta, Mariana Millan Fachi, Camila Araujo da Silva, Leticia de Araujo Vitor.  
**Representantes de áreas técnicas:** Marta da Cunha Lobo Souto Maior (CGPCDT/DGITS/MS), Agnes Nogueira Gossenheimer (DAF/MS), Bábilla Nunes de Souza (DAF/MS), Eduardo Freire de Oliveira (CGATS/DGITS/MS), Emanuelle Correa Peres (DAF/MS), Gabriella Farias Gomes (CGDCRO/DEPROS/MS), Gilmara Lúcia dos Santos (CGDCRO/DEPROS/MS), Graciele Fernandes Rodrigues (DAET/MS), Hannah Carolina Tavares Domingos (CGDCRO/DEPROS/MS), Jéssica Procópio de Quadros (CGDCRO/DEPROS/MS), Klébya Hellen Dantas de Oliveira (CGPCDT/DGITS/MS) e Nicole Freitas de Mello (CGPCDT/DGITS/MS).  
*Membros votantes na reunião de escopo.  
75

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro B).  
Quadro B. Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar fi|nanceiramente|
|---|---|
|algum dos benefícios abaixo?||
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>( )Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>( )Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>( )Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>( )Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>( )Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>( )Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma<br>forma ser beneficiada ouprejudicada com as recomendações da diretriz?|(   ) Sim<br>( )Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de<br>marca,royalties)de alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>( )Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>( )Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cu<br>possam ser afetadospela sua atividade na elaboração ou revisão da diretriz?|jos interesses|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>( )Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>( )Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>( )Não|
|d) Partido político|(   ) Sim<br>( )Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>( )Não|
|f) Outro grupo de interesse|(   ) Sim<br>( )Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>( )Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos<br>interessespossam ser afetados?|(   ) Sim<br>( )Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer<br>oquevocê irá escrever eque deveria ser do conhecimentopúblico?|(   ) Sim<br>( ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja<br>relacionado acima, quepossa afetar sua objetividade ou imparcialidade?|(   ) Sim<br>( ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos<br>conflitos listados acima?|(   ) Sim<br>( )Não|  
76  
O resumo dos conflitos de interesse dos membros do Grupo Elaborador está na Quadro C.  
Quadro C. Declaração de conflitos de interesse dos membros do Grupo Elaborador do PCDT.  
|**Participante**|**Conf**<br>|**litos de interesses declarados**<br>|**Decisão**<br>|
|---|---|---|---|
||**Questão**|**Descrição geral**|**tomada**|
|André Klafke de Lima|-|-|Declarar e<br>participar|
|Maria Edna de Melo|1a|Patrocínio recebido da Novo<br>Nordisk referente a produtos para<br>tratamento da obesidade|Declarar e<br>participar|
|Mariana Millan Fachi|-|-|Declarar e<br>participar|
|Renata Bertazzi Levy|-|-|Declarar e<br>participar|
|Rosa Camila Lucchetta|-|-|Declarar e<br>participar|
|Tarcila Ferraz de Campos|-||Declarar e<br>participar|
|Tarissa Beatrice Zanata Petry|-|-|Declarar e<br>participar|  
8. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do PCDT do Diabete Melito tipo 2 foi apresentada na 109ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 21 de novembro de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES); Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Diabete melito tipo 2 | secao: 9. Consulta pública -->
A Consulta Pública nº 54/2023, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas do Diabete Melito Tipo 2, foi realizada entre os dias 21 de dezembro de 2023 e 09 de janeiro de 2024. Foram recebidas 119 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2023/CP_CONITEC_054_2023_PCDT_de_Diabete.pdf.</u>  
10. Buscas na literatura para atualização do PCDT  
Foram incluídas informações referentes ao uso da dapagliflozina em pacientes com DM2. Além disso, durante a reunião de escopo realizada no dia 29 de maio de 2023, definiu-se os  
77  
seguintes temas de perguntas de pesquisa: I) substituição do açúcar pelo adoçante na população com DM2; e II) fracionamento da dieta. Para estas perguntas foi conduzido um levantamento rápido de evidências nas bases de dados Embase e PubMed, para a reunião de priorização de perguntas, realizado no dia 17 de agosto de 2023. Entretanto, foram encontradas evidências limitadas para ambas as questões e estas não foram priorizadas.  
Assim, os documentos encontrados foram encaminhados aos especialistas, de modo a auxiliar a redação de ambos os temas.  
Também foram consideradas as evidências e a recomendação final da Conitec, dispostas no Relatório de Recomendação nº 802, de março de 2023, acerca da ampliação de uso da dapagliflozina para pacientes com diabete melito tipo 2 (DM2) com necessidade de segunda intensificação de tratamento e alto risco para desenvolver doença cardiovascular (DCV) ou com DCV já estabelecida e idade entre 40-64 anos.  
Adicionalmente, foram consideradas as orientações da Linha de Cuidado do Diabete Melito tipo 2 e os temas prioritários na perspectiva da Área Técnica do Ministério da Saúde, quais sejam:  
- recomendação da calculadora de risco cardiovascular da estratégia HEARTS, a ser adotada pelo Ministério da Saúde;  
- ênfase nas ações de autocuidado do paciente com DM2;  
- orientações sobre o diagnóstico e tratamento de crianças, e;  
- inclusão das PICS como aliadas ao tratamento.  
Uma revisão sistemática sobre o tratamento com hipoglicemiantes ( por exemplo, DPP4, GLP-1, inibidores de alfa-glicosidase, insulinas basais, meglitinidas, cloridrato de metformina, SGLT2, sulfonilureias, TZD) foi realizada durante o desenvolvimento da versão do PCDT publicada em 2020 e está disponível no Relatório de Recomendação nº 565, de outubro de 2020. Suas recomendações foram adotadas pelo documento elaborado à época e, na presenteatualização, estas mesmas recomendações foram mantidas.  
78  
APÊNDICE 2 – HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO  
|**Número do**<br>**Relatório da**<br>**diretriz clínica**|**Principais**|**Tecnologias avali**|**adaspela Conitec**|
|---|---|---|---|
|<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|<br>**alterações**|**Incorporação ou**<br>**alteração do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|<br>Portaria<br>SCTIE/MS nº<br>13/2026; Relatório<br>de Recomendação<br>nº 1075/2025|Atualização do<br>documento e<br>incorporação de<br>tecnologias em<br>saúde|Análogos de insulina de<br>ação rápida para tratamento<br>do diabetes mellitus tipo 2<br>[Portaria SECTICS/MS nº<br>58/2024; Relatório de<br>Recomendação nº<br>949/2024]<br>Análogos de insulina de<br>ação prolongada para<br>tratamento do diabetes<br>mellitus tipo 2<br>[Portaria SECTICS/MS nº<br>59/2024; Relatório de<br>Recomendação nº<br>948/2024]|Sistema de monitorização<br>contínua da glicose por<br>escaneamento intermitente<br>em pacientes com diabetes<br>mellitus tipos 1 e 2<br>[Portaria SECTICS/MS nº<br>2/2025; Relatório de<br>Recomendação nº<br>956/2025]|
||Alteração pós<br>publicação<br>(correção do<br>Quadro 17 e do<br>termo PICS)|-|-|
|Portaria<br>SECTICS/MS nº<br>7/2024; Relatório|Atualização do|Dapagliflozina para<br>pacientes com diabete<br>melito tipo 2 (DM2) com<br>necessidade de segunda<br>intensificação de|Liraglutida<br>[Processo encerrado a<br>pedido do demandante/<br>2023]|
|de Recomendação<br>nº 882/2024|<br>documento e<br>ampliação de<br>uso de<br>tecnologia em<br>saúde|<br>tratamento e alto risco para<br>desenvolver doença<br>cardiovascular (DCV) ou<br>com DCV já estabelecida e<br>idade entre 40-64 anos.<br>[Portaria SECTICS/MS nº<br>09/2023; Relatório de<br>Recomendação nº<br>802/2023]|Point-of-care testing de<br>hemoglobina glicada para<br>pacientes diabéticos<br>[Portaria SECTICS/MS nº<br>45/2023; Relatório de<br>Recomendação nº<br>834/2023]|
|Portaria<br>SCTIE/MS nº<br>54/2020; Relatório<br>de Recomendação<br>nº 565/2020|Primeira versão<br>do documento|Dapagliflozina para o<br>tratamento de diabetes<br>mellitus tipo 2<br>[Portaria SCTIE/MS nº<br>16/2020; Relatório de<br>Recomendação nº<br>524/2020]|Empagliflozina para o<br>tratamento de diabetes<br>mellitus tipo 2<br>[Portaria SCTIE/MS nº<br>16/2020; Relatório de<br>Recomendação nº<br>524/2020]|
|||Caneta para injeção de<br>insulina humanaNPH e|Insulinas análogas de ação<br>prolongadapara o|  
79  
|**Número do**<br>**Relatório da**||**Tecnologias avali**|**adaspela Conitec**|
|---|---|---|---|
|**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Incorporação ou**<br>**alteração do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|||insulina humana regular<br>[Portaria SCTIE/MS nº<br>11/2017; Relatório de<br>Recomendação nº<br>256/2017]|tratamento de diabetes<br>mellitus tipo II<br>[Portaria SCTIE/MS nº<br>11/2019; Relatório de<br>Recomendação nº<br>434/2019]|
||||Empagliflozina para o<br>tratamento de pacientes<br>com diabetes mellitus tipo<br>2 e doença cardiovascular<br>estabelecida, com objetivo<br>de prevenção de morte<br>[Portaria SCTIE/MS nº<br>70/2018; Relatório de<br>Recomendação nº<br>403/2018]<br>Insulinas análogas para<br>diabetes mellitus tipo II<br>[Portaria SCTIE/MS n º<br>30/2014; Relatório de<br>Recomendação nº<br>103/2014]|
||||Insulina detemir [Processo<br>encerrado a pedido do<br>demandante/ 2013]|  
80

---

