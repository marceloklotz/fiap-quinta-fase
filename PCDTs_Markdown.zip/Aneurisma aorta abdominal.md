<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA Nº 488, DE 06 DE MARÇO DE 2017.  
Aprova as Diretrizes Brasileiras para o Tratamento de Aneurisma da Aorta Abdominal.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre o tratamento de aneurisma da aorta abdominal e diretrizes nacionais para a sua indicação e acompanhamento dos indivíduos a ele submetidos;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 222 / 2016 e o Relatório de Recomendação nº 240 – Agosto/2016, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), que aprova a Diretriz Brasileira para o Tratamento do Aneurisma de Aorta Abdominal”; e  
Considerando a avaliação técnica do Instituto Nacional de Cardiologia (INC / SAS / MS), do Departamento de Gestão e Incorporação de Tecnologias no SUS (DGITS/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (INC / SAS / MS), resolve:  
Art. 1º  Ficam aprovadas, na forma do anexo, disponível no sítio: <u>www.saude.gov.br/sas, as</u> “Diretrizes Brasileiras para o Tratamento de Aneurisma da Aorta Abdominal”.  
Parágrafo único.  As diretrizes de que trata este artigo, que contêm as recomendações para o tratamento de aneurisma da aorta abdominal, são de caráter nacional e devem utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e eventos adversos relacionados ao  tratamento de aneurisma da aorta abdominal.  
Art. 3º  Os gestores estaduais, distritais e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos doentes em todas as etapas descritas no anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 1. APRESENTAÇÃO -->
Estas Diretrizes destinam-se aos pacientes, familiares, profissionais da saúde e gestores na área da saúde pública e envolvidos com o tema: tratamento dos pacientes com aneurismas abdominais infra-renais.  
As recomendações foram estruturadas após a avaliação da qualidade do corpo de evidências para cada desfecho e comparação entre intervenções. A direção e a força da recomendação foram consideradas segundo o método GRADE <mark>(</mark> _<mark>The Grading of Recommendations Assessment, Development and Evaluation</mark>_ <mark>)</mark> .  
O equilíbrio entre os resultados desejáveis e indesejáveis (possíveis benefícios e danos) e a aplicação de valores e preferências do paciente determinou a direção da recomendação (contra ou a favor). Tais fatores, juntamente com a qualidade das evidências, determinaram a força da recomendação (forte ou fraca) (Quadro 1).  
<u>Quadro 1 – Critérios utilizados para formulação da recomendação</u>  
|As desvantagens claramente superam as vantagens.|Recomendação forte CONTRA a adoção da<br>intervenção.|
|---|---|
|As desvantagens provavelmente superam as<br>vantagens.|Recomendação fraca CONTRA a não adoção da<br>intervenção.|
|O balanço entre vantagens e desvantagem é incerto.|Não fornecer recomendação é uma alternativa<br>justificável.|
|O balanço entre vantagens e desvantagens indica que<br>eles são semelhantes.|Não fornecer recomendação é uma alternativa<br>justificável.|
|Os benefícios provavelmente superam as<br>consequências indesejáveis.|Recomendação fraca A FAVOR da adoção da<br>intervenção.|
|As vantagens claramente superam as desvantagens.|Recomendação forte A FAVOR da adoção da<br>intervenção.|  
As presentes Diretrizes se baseiam no Relatório de Recomendação, que se encontra disponível no sítio eletrônico da Nacional de Incorporação de Tecnologias no SUS (CONITEC) e que pode ser acessado diretamente pelo _link_ : <u>http://conitec.gov.br/images/Relatorios/2017/Relatorio_Diretriz_AneurismaAortaAbdominal_Recomenda cao.pdf.</u>

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 2. INTRODUÇÃO -->
O diâmetro máximo normal da aorta abdominal é de 2,0 cm. A dilatação da aorta abdominal quando atinge um diâmetro 50% maior do que o esperado, ou 3,0 cm nos adultos, é chamada de aneurisma.  
Aneurismas da aorta abdominal (AAA) são encontrados incidentalmente com frequência, sobretudo na população idosa, sendo responsáveis por 90% a 95% de todos os casos de aneurisma de aorta. Estima-se que a prevalência dos AAA é de 2% na população com 60 anos de idade e em cerca de 5% após os 70 anos, sendo 2 a 3 vezes mais comum no sexo masculino<sup>(1)</sup> .  
O principal risco relacionado aos aneurismas é a ruptura, evento com alta letalidade. Nos  
EUA, estimam-se em 15.000 óbitos ao ano nos casos de aneurismas rotos que conseguem chegar ao hospital, e o dobro ou triplo deste número, se incluídos todos os casos de morte súbita que ocorrem fora do ambiente hospitalar<sup>(1)</sup> . No Brasil, segundo o Ministério da Saúde (quadros 2 e 3), foram registradas 8.939 internações hospitalares relacionadas com AAA entre novembro de 2014 e novembro de 2015. A maioria (57,7%) dos procedimentos foi de caráter eletivo, sendo observada alta mortalidade no grupo cirúrgico em relação ao grupo com tratamento endovascular. Como não houve randomização ou avaliação comparativa dos fatores de risco destes grupos, a avaliação direta dos resultados é sujeita a vieses importantes e deve ser evitada.  
Quadro 2 – Procedimentos eletivos, número de AIH e taxa de mortalidade por procedimento no Brasil de novembro/2014 a novembro/2015.  
|Código do Procedimento|AIH aprovadas|Taxa de mortalidade(%)|
|---|---|---|
|03.03.06.001-8|3.440|13,05|
|04.06.01.013-7|232|31,9|
|04.06.02.004-3|375|29,07|
|04.06.02.005-1|74|45,95|
|04.06.04.015-0|71|5,63|
|04.06.04.016-8|970|3,4|
|Total/(Médiaponderada)/%|5.162|(703)13,62|  
AIH: Autorização de Internação Hospitalar.  
Fonte: Ministério da Saúde - Sistema de Informações Hospitalares do SUS (SIH/SUS). Dados de novembro de 2014 até novembro de 2015 sujeitos a retificação.  
Quadro 3 – Procedimentos de urgência, número de AIH e taxa de mortalidade por procedimento no Brasil de novembro/2014 a novembro/2015.  
|Código do Procedimento|AIH aprovadas|Taxa de mortalidade(%)|
|---|---|---|
|03.03.06.001-8|2.850|14,67|
|04.06.01.013-7|136|38,97|
|04.06.02.004-3|196|38,78|
|04.06.02.005-1|50|50|
|04.06.04.015-0|42|9,52|
|04.06.04.016-8|503|5,17|
|Total/(Médiaponderada)/%|3.777|(602)15,94|  
AIH: Autorização de Internação Hospitalar.  
Fonte: Ministério da Saúde - Sistema de Informações Hospitalares do SUS (SIH/SUS). Dados de novembro de 2014 até novembro de 2015 sujeitos a retificação.  
<u>Procedimentos:</u>  
 03.03.06.001-8 - Tratamento de aneurisma da aorta.  04.06.01.013-7 - Correção de aneurisma / dissecção da aorta toracoabdominal.  04.06.02.004-3 - Aneurismectomia de aorta abdominal infra-renal.  04.06.02.005-1 - Aneurismectomia toraco-abdominal.  04.06.04.015-0 - Correção endovascular de aneurisma / dissecção da aorta  
abdominal c/ endoprótese reta / cônica.  
 04.06.04.016-8 - Correção endovascular de aneurisma / dissecção da aorta abdominal e ilíaca com endoprótese bifurcada.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 3.1. TRATAMENTO CLÍNICO -->
A avaliação crítica do tratamento clínico não foi considerada nestas Diretrizes. Portadores de AAA devem ser aconselhados a parar de fumar e encorajados a procurar tratamento apropriado para hipertensão arterial sistêmica, dislipidemia, diabete mélito e outros fatores de risco cardiovasculares.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 3.2. TRATAMENTO CIRÚRGICO -->
<mark>O reparo cirúrgico aberto consiste em uma incisão abdominal e a substituição de parte da aorta, lesada pelo aneurisma, por um tubo sintético ou enxerto aórtico, que é suturado no local. Nestas Diretrizes, os termos cirurgia, cirurgia aberta e tratamento cirúrgico são sinônimos.</mark>  
<mark>O tratamento endovascular do AAA (</mark> _<mark>Endovascular Abdominal Aortic Aneurysm Repair</mark>_ <mark>EVAR) é uma forma de tratamento do aneurisma de aorta abdominal que é menos invasiva do que a cirurgia aberta. O tratamento endovascular usa uma endoprótese para reforçar a parede da aorta e para ajudar a impedir que a área lesada se rompa. O procedimento consiste na punção da artéria femoral em região inguinal, acesso ao aneurisma através de um fio guia e liberação da endoprótese no interior da aorta, no local do aneurisma.</mark>

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 4. ESCOPO -->
O escopo destas Diretrizes é definir qual o melhor tratamento - clínico, cirúrgico ou endovascular (EVAR) - do AAA em relação a desfechos importantes para os pacientes (mortalidade cirúrgica, mortalidade global, reintervenções, infarto do miocárdio e acidente vascular cerebral).  
Nestas Diretrizes, não se incluem os aneurismas torácicos, aneurismas infecciosos e os  
casos de dissecção de aorta.  
A organização destas Diretrizes se fez em sete tópicos:  
1. AAA pequenos 2. AAA grandes 3. AAA inflamatórios  
4. AAA saculares  
5. AAA sintomáticos  
6. AAA inoperáveis  
<mark>7. AAA rotos</mark>  
Para cada tópico foi definida uma pergunta estruturada (Apêndice 1). E para cada tópico foi definida uma estratégia de busca que, junto com o resultado da busca (Apêndice 2).  
As características principais dos ensaios clínicos avaliados estão resumidas em forma de quadros individuais (Apêndice 3).  
O risco de viés dos ensaios, julgados de acordo com os critérios propostos por Higgins 201<sup>(2),</sup> estão resumidos em figuras geradas no programa RevMan 5.3 (Apêndice 4).  
As meta-análises foram realizadas com o programa RevMan 5.3, utilizando-se um modelo de efeito fixo, método de Mantel-Haenszel, com avaliação do risco relativo e com um intervalo de confiança de 95%. Os gráficos estão disponíveis no Apêndice 5.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 4.1. ANEURISMAS PEQUENOS -->
O tratamento invasivo dos AAA tem como relevante critério de indicação o diâmetro do aneurisma. Aneurismas menores do que 4,0 cm são considerados muito pequenos, sendo monitorados com exames de imagem regulares, enquanto AAA maiores do que 5,4 cm têm usualmente indicação de cirurgia aberta ou EVAR.  
Os AAA entre 4,0 e 5,5 cm são considerados pequenos, e a melhor opção de tratamento foi avaliada de acordo com as evidências atuais.  
A busca da literatura resultou em 153 referências (Quadro 1 do Apêndice 1). Selecionaram-se 4 ensaios clínicos randomizados (ECR): dois<sup>(3,4)</sup> comparando a cirurgia aberta e dois<sup>(5,6)</sup> comparando o tratamento endovascular com o tratamento clínico, e 2 revisões sistemáticas<sup>(7,8)</sup> .  
O risco de viés dos ECR foi considerado baixo (Figura 1 do Apêndice 4), pois os ensaios mostraram método de randomização adequados, grupos semelhantes e com boa aderência à intervenção. O cegamento seria difícil (cirurgia _versus_ tratamento clínico) e, apesar de não realizado, a grupo elaborador destas Diretrizes considerou não ter gerado um risco de viés relevanante devido à natureza dos desfechos avaliados (desfechos duros, mortalidade, complicações e reoperação). A perda de seguimento foi pequena. Todos os ensaios publicaram resultados relacionados a desfechos relevantes e pré-publicados em seus protocolos, com baixo risco de viés de publicação.  Os ensaios CAESAR e PIVOTAL foram financiados pela _Cook Medical e Medtronic_ vascular, respectivamente, não sendo possível afastar um risco de viés associado ao conflito de interesses.  
Não houve diferença significativa entre cirurgia aberta e o acompanhamento clínico, RR 1,03 IC95% 0,86-1,24 (Figura 1 do Apêndice 5), EVAR _versus_ acompanhamento clínico, RR 1,03 IC95% 0,59-1,80 (Figura 2 do Apêndice) ou cirurgia e EVAR combinados _versus_ o acompanhamento clínico, RR 1,01 IC95% 0,93-1,10 (Figura 3 do Apêndice 5).  
Entre as revisões sistemáticas identificadas, as conclusões dos autores estão em acordo com as evidências encontradas na busca realizada para a elaboração destas Diretrizes. Na revisão da Cochrane de 2015<sup>(7)</sup> , cuja busca resultou nas mesmas referências, os autores concluíram que “a evidência atual sustenta adiar o momento cirúrgico até que o diâmetro do AAA alcance 5,5 cm”.  
Na revisão sistemática de Bath 2015<sup>(8)</sup> , foi avaliada a associação entre a presença de AAA e o risco cardiovascular. Por meio de uma meta-regressão, com 6 estudos observacionais e os mesmos 4 ECR supracitados, os autores concluíram que a mortalidade anual cardiovascular deste grupo de pacientes com mediana de idade de 71,2 anos era de 3%. Ainda, a maioria dos aneurismas detectados é pequena e com crescimento lento, levando vários anos até que alcancem um tamanho com indicação de intervenção: “O tempo entre a detecção e a intervenção representa uma oportunidade para orientação destes pacientes quanto à prevenção cardiovascular, incluindo o controle do peso, da pressão arterial, dos níveis séricos dos lipídeos e principalmente a interrupção do tabagismo”.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: <u>AAA no sexo feminino</u> -->
Uma consideração importante é a diferença do risco de ruptura dos AAA entre homens e mulheres. Por apresentarem menor volume corporal, questiona-se a utilização do mesmo critério de tamanho do aneurisma para a indicação cirúrgica nos casos de mulheres. Ainda, deve-se considerar que as  
mulheres estão representadas em pequeno número nos ensaios clínicos.  
O aneurisma da aorta abdominal é 4 a 6 vezes mais comum em homens do que em mulheres, porém mais de um terço de todas as mortes por AAA ocorrem entre mulheres. A taxa de ruptura do aneurisma nas mulheres é de 3-4 vezes superior à observada em homens, e por isso já foi questionado se haveria diferença na conduta entre os gêneros<sup>(9)</sup> .  
Nos estudos que avaliaram possíveis benefícios na conduta em casos de aneurismas pequenos, não houve benefício de reparação precoce em mulheres, e a totalidade das evidências disponíveis no momento não fornece nenhuma boa razão para alterar o limiar de 5,5 cm para reparo eletivo<sup>(9)</sup> .  
Em 2010, foi publicada uma revisão sistemática e meta-análise das diferenças no resultado após a intervenção de aneurisma da aorta abdominal entre homens e mulheres<sup>(10)</sup> . O objetivo deste estudo foi avaliar possíveis diferenças na mortalidade entre homens e mulheres com um aneurisma da aorta abdominal tratado seja por reparo eletivo ou após ruptura. Sessenta e um estudos (516.118 pacientes) preencheram os critérios de inclusão. As taxas de mortalidade para as mulheres em comparação com os homens foram de 7,6% _versus_ 5,1% (OR 1,28, IC95% 1,09-1,49) para a cirurgia aberta eletiva, 2,9% _versus_ 1,5% (OR 2,41, IC 95% 1,14-5,15) para o reparo eletivo endovascular, e 61,8% contra 42,2% (OR 1,16, 95 por cento CI 0,97-1,37) no grupo de cirurgia para aneurisma roto. O grupo que teve o tratamento endovascular de AAA roto era pequeno para análise estatística.  
Em conclusão, as mulheres com AAA apresentam maior taxa de ruptura, mas também maior mortalidade com a cirurgia ou com o tratamento endovascular, não havendo benefício comprovado de intervenção precoce.  
Recomendação para pacientes assintomáticos com AAA < 5,5 cm.  
Recomendação forte, contrária à cirurgia ou tratamento endovascular em pacientes assintomáticos com aneurismas pequenos (< 5,5 cm).  
Os pacientes com AAA entre 4,0 e 5,5 cm devem ser acompanhados com avaliações clínicas e exames de imagem a cada 6 meses.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 4.2. ANEURISMAS MAIORES DO QUE 5,4 CM -->
A ruptura dos AAA é mais frequente em aneurismas grandes, de crescimento rapidamente progressivo ou com início recente de sintomas. O reparo eletivo é uma opção de tratamento, que, quando indicado com base no tamanho do aneurisma e de acordo com as diretrizes nacionais, é recomendado quando o AAA é maior do que 5,4 cm<sup>(1)</sup> .  
Este valor de corte foi baseado em estudos de coorte que identificaram um risco crescente de ruptura e morte com o aumento no diâmetro dos aneurismas. Na coorte de Rochester<sup>(11)</sup> , 176 pacientes com o diagnóstico de AAA foram acompanhados entre 1974 e 1988, média de acompanhamento de 4,9 anos. O risco de ruptura de acordo com o diâmetro está demonstrado na Quadro4.  
<u>Quadro 4 - Risco de ruptura de acordo com o diâmetro do aneurisma</u>  
|Diâmetro(cm)|Pesssoas-ano|Ruptura|Ruptura/pessoas-ano|IC95%|
|---|---|---|---|---|
|< 3|111|0|0|0-0,08|
|3-3,99|185|0|0|0-0,05|
|4-4,99|148|1|0,007|0-0,05|
|5-5,99|38|4|0,11|0,01-0,21|
|6-6,99|9|5|0,26|0,07-0,46|

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: Fonte: Reed et al 1997<sup>(11)</sup> . -->
Na coorte de Scott et al<sup>(12)</sup> , 218 AAA menores do que 6,0 cm detectados em pacientes assintomáticos foram acompanhados por uma média de 5,7 anos. A cirurgia era indicada caso o aneurisma ultrapassasse 6,0 cm, se os pacientes se tornassem sintomáticos ou caso o aneurisma apresentasse um crescimento superior a 1,0 cm ao ano. Os resultados estão resumidos na Quadro 5.  
<u>Quadro 5 - Risco de ruptura ou necessidade cirúrgica em relação ao diâmetro do aneurisma</u>  
|Diâmetro (cm)|Número de|Número de|Ruptura por|Número de|Cirurgia por|
|---|---|---|---|---|---|
||pacientes|rupturas|ano|cirurgias eletivas|ano|
|3-4,4|135|5|0,7|11|1,4%|
|4,5-5,9|31|3|1,7|15|8,5%|  
Fonte: Scott et al 1998<sup>(12)</sup> .  
Atualmente, a indicação de cirurgia ou EVAR para aneurismas maiores do que 5,4 cm é consenso<sup>(1)</sup> . Para avaliação da melhor conduta nos pacientes com AAA maiores do que 5,4 cm, utilizouse nestas Diretrizes como base a revisão da Cochrane de 2014<sup>(13)</sup> . Esta revisão avaliou o tratamento endovascular _versus_ o tratamento cirúrgico nos pacientes aptos à cirurgia e o tratamento endovascular _versus_ tratamento clínico nos pacientes inoperáveis.  
Esta revisão foi classificada pelo grupo elaborador como de alta qualidade, tendo como base de avaliação um escore de 10 em 11 no Sistema AMSTAR<sup>(14)</sup> . Realizou-se uma busca no Pubmed com a intenção de atualizar a revisão com publicações recentes. A busca atualizada resultou em 51 referências, todas excluídas após avaliação dos títulos e resumos.  
Nesta revisão sistemática, 4 ECR (ACE, DREAM, EVAR 1 e OVER) avaliaram comparativamente o tratamento endovascular com a cirurgia aberta em pacientes aptos à cirurgia.  
Observou-se diferença na mortalidade em 30 dias (Figura 4 do Apêndice 5) a favor do procedimento endovascular (RR 0,34, IC95% 0,21-0,57), não havendo diferença em relação à mortalidade a médio (até 4 anos) (RR 0,93, IC95% 0,79-1,10) ou a longo prazo (RR 0,99 IC95% 0,891,09), conforme se pode observar nas figuras 5 e 6 do Apêndice 5.  
A reintervenção (figuras 7 e 8 do Apêndice 5) foi mais frequente no grupo EVAR (RR 1,95, IC95% 1,56-2,43), e complicações pulmonares (Figura 12 do Apêndice 5) foram mais frequentes no grupo de cirurgia aberta (RR 0,38, IC95% 0,18-0,76). Não foram observadas diferenças em relação a infarto do miocárdio, AVC fatal ou não fatal ou complicações renais (figuras 9-11,13 do Apêndice 5).  
Os resultados desta revisão sistemática estão sintetizados de acordo com os desfechos no  
Quadro 6.  
<u>Quadro 6 - Resultados da comparação entre cirurgia aberta e EVAR</u>  
|Desfecho|Cirurgia aberta x EVAR(RR)|IC95%|
|---|---|---|
|Mortalidade em 30 dias|0,34|0,21-0,57|
|Mortalidade até 4 anos|0,93|0,79-1,10|
|Mortalidade longoprazo|0,99|0,89-1,09|
|Reintervenção até 4 anos|1,95|1,56-2,43|
|Reintervenção longoprazo|1,78|1,50-2,12|
|Infarto do miocárdio|1,13|0,87-1,46|
|AVC não fatal|0,82|0,52-1,29|  
|AVC fatal|0,81|0,43-1,53|
|---|---|---|
|Complicaçõespulmonares|0,38|0,18-0,76|
|Complicações renais|1,23|0,60-2,51|  
AVC: acidente vascular cerebral Fonte: Paravastu et al 2014.<sup>(13)</sup>  
Em suma, nos pacientes assintomáticos, com AAA > 5,4 cm, aptos aos procedimentos eletivos cirúrgico e endovascular, há uma boa qualidade de evidência a favor da EVAR em relação à _mortalidade em 30 dias_ .  
Quanto aos eventos adversos, há uma boa qualidade de evidência indicando _maior número de complicações pulmonares com o tratamento cirúrgico e maior número de reintervenções com o tratamento endovascular_ .  
Recomendação para pacientes assintomáticos com AAA > 5,4 cm, aptos aos <u>procedimentos eletivos cirúrgico e endovascular.</u>  
Recomendação forte, a favor da EVAR, nos casos de AAA > 5,4 cm.  
4.3 . AAA INFLAMATÓRIOS  
O aneurisma da aorta abdominal inflamatório (AAAI) é responsável por 5% a 10% de todos os casos de AAA. Difere do padrão comum da doença ateroesclerótica por marcado espessamento da parede do aneurisma, fibrose do retroperitônio e adesão das estruturas adjacentes. A tríade de dor abdominal ou nas costas, perda de peso e elevados marcadores inflamatórios sistêmicos em pacientes com aneurismas da aorta abdominal é altamente sugestiva de aneurisma inflamatório<sup>(15)</sup> .  
A patogênese do AAAI permanece desconhecida. Tem sido postulado que a inflamação e a fibrose periaórtica ocorrem em resposta a extravasamento subclínico de sangue e à compressão de linfonodos retroperitoneais pelo aneurisma ou pela existência de uma reação alérgica local aos componentes de placas ateroscleróticas<sup>(16)</sup> .  
A fibrose periaórtica e adesão de estruturas adjacentes (ureteres e duodeno) são os principais responsáveis para as dificuldades técnicas intraoperatórias. A mortalidade peroperatória de reparo cirúrgico convencional do aneurisma inflamatórios é três vezes maior do que a observada nos casos de aneurisma não inflamatório<sup>(17)</sup> .  
Os aneurismas de etiologia inflamatória, em teoria, têm potencial indicação de tratamento, que pode ser independente das suas dimensões devido a manifestações sistêmicas significantes, como febre e emagrecimento<sup>(1)</sup> .  
A busca resultou em 668 referências (Quadro 1 do Apêndice 2), porém de apenas relatos e séries de casos. Não foram identificados ensaios controlados que avaliassem a cirurgia ou o tratamento endovascular, o que prejudica a proposição de uma recomendação específica.  
Recomendação para pacientes assintomáticos com AAA inflamatórios, aptos aos <u>procedimentos eletivos cirúrgico e endovascular.</u>  
Considerando a falta de evidências, não há recomendação específica para aneurismas inflamatórios. Sugere-se o controle clínico e acompanhamento semelhante aos demais AAA.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 4.4. ANEURISMAS ABDOMINAIS SACULARES -->
<mark>Os aneurismas podem ser classificados de acordo com a sua configuração em fusiformes (mais comuns) ou saculares. Enquanto os aneurismas fusiformes da aorta surgem muitas vezes devido à degeneração da parede arterial secundária a doença aterosclerótica, os aneurismas saculares têm uma etiologia mais variada, que pode envolver infecções, degeneração de uma úlcera aterosclerótica penetrante, trauma ou cirurgia aórtica prévia. Não são abordados nesta análise os aneurismas infecciosos e os pseudoaneurismas.</mark>  
Os aneurismas saculares são considerados pelos cirurgiões vasculares como de um maior risco de ruptura e são frequentemente corrigidos independentemente do tamanho<sup>(18)</sup> .  
Inexistem estudos que permitam definir o limite exato a partir do qual um aneurisma sacular deva ser corrigido. A maioria dos autores defende o seu tratamento quando o maior diâmetro atinge 3 cm, dado o maior risco de ruptura a partir desta dimensão. O tamanho do aneurisma sacular deve considerar o raio e não o diâmetro, ou seja, a distância entre o saco aneurismático e o centro da aorta abdominal.  
Para estas Diretrizes, o objetivo foi buscar evidências que comprovassem a necessidade de tratamento precoce (aneurismas menores do que 5,5 cm) para os aneurismas saculares e a comparação entre a cirurgia aberta e o tratamento endovascular.  
<mark>A busca (Quadro 1 do Apêndice 2) resultou em 587 referências. Não foram encontrados ensaios controlados ou evidência para suportar a indicação de cirurgia precoce.</mark>  
De acordo com as diretrizes da Sociedade Brasileira de Angiologia e Cirurgia Vascular: “Não foram encontradas evidências científicas que embasem o tratamento cirúrgico de pacientes com aneurisma sacular menor do que 5cm, havendo apenas uma fraca recomendação sugerindo seu reparo eletivo. Na prática, recomenda-se avaliação de outras variáveis, tais como taxa de crescimento, debilidade da parede _(blebs),_ possibilidade de presença de infecção (aneurisma micótico), localização e, sobretudo, sintomas. Clinicamente e pelos métodos de imagem atuais, é impossível distinguir uma dilatação sacular de uma debilidade focal da parede, o que justifica o tratamento dos aneurismas saculares em diâmetros menores do que 5 cm”<sup>(19)</sup> . As diretrizes americanas<sup>(20)</sup> , em relação aos aneurismas saculares, declaram haver evidência de baixa qualidade e um nível fraco de recomendação para o reparo eletivo dos aneurismas saculares. As diretrizes europeias<sup>(21)</sup> não incluem os aneurismas saculares em seu escopo.  
Recomendação para pacientes assintomáticos com AAA saculares, aptos aos <u>procedimentos eletivos cirúrgico e endovascular.</u>  
Considerando a falta de evidências de boa qualidade para aneurismas saculares, sugere-se o acompanhamento e avaliação regular em relação à taxa de crescimento, possibilidade de infecção de <u>parede ou surgimento de sintomas. O reparo eletivo é uma opção, apesar do fraco nível de recomendação.</u>

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 4.5. AAA SINTOMÁTICOS SEM RUPTURA -->
A presença de AAA acompanhado de sinais ou sintomas, tais como dor lombar ou abdominal, embolização distal e manifestações de compressão de estruturas vizinhas, é um dilema clínico. Os sintomas podem representar um aneurisma roto ou uma expansão aguda e, portanto, risco de ruptura iminente<sup>(1)</sup> . Foi realizada uma busca para identificar evidências que suportassem a necessidade de cirurgia nos casos de AAA sintomáticos (Quadro 1 do Apêndice 2). Identificaram-se 24 referências com apenas uma coorte retrospectiva<sup>(22)</sup> com pacientes portadores de AAA infra-renal sintomáticos operados entre 1952 e 1977 no _North Carolina Memorial Hospital_ . A mortalidade até 30 dias da cirurgia para os  
casos de aneurismas rotos foi de 61% nos anos 1952 a 1971 e de 71% nos anos 1972 a 1977. Entre os pacientes sem ruptura e operados em caráter emergencial (n=22), a mortalidade cirúrgica foi de 18%. Já entre os pacientes sem ruptura e com cirurgia eletiva (n=105) não houve nenhuma morte. A associação entre dor abdominal ou lombar e ruptura foi fraca. Do grupo com ruptura, 59% apresentavam tais sintomas e do grupo sem ruptura, 60%. A presença de choque hemodinâmico ou pressão sistólica < 100 mmHg ou hematócrito < 37% estavam fortemente associados a presença de ruptura. Entre os 64 pacientes com ruptura, 84% apresentavam pressão sistólica < 100 mmHg ou hematócrito < 37%, enquanto apenas 27% dos pacientes sem ruptura apresentavam um ou outro destes sinais.  
Diretrizes brasileiras, europeias e americanas<sup>(19-21)</sup> referem algumas séries nas quais a mortalidade operatória foi significativamente maior nos casos dos pacientes com AAA sintomático não roto submetidos à cirurgia de emergência<sup>(23-25)</sup> . Uma possível explicação para o aumento na mortalidade dos pacientes sintomáticos operados em caráter de emergência é a realização da cirurgia em circunstâncias menos favoráveis, sem a equipe cirúrgica e de anestesia habituais. Outra consideração é que, afastada a ruptura, alguns pacientes podem se beneficiar do preparo pré-operatório.  
Recomendação para pacientes sintomáticos com AAA íntegros, aptos aos procedimentos eletivos cirúrgico e endovascular.  
Não é possível fazer uma recomendação baseada em evidências de boa qualidade para AAA sintomáticos. Cada situação deve ser abordada individualmente, sendo fundamental afastar ruptura por meio de tomografia computadorizada com contraste.  
Os pacientes com quadro agudo compatível com ruptura (dor de forte intensidade, hipotensão, queda do hematócrito) devem ser submetidos à cirurgia ou implante de endoprótese em caráter emergencial.  
Os pacientes com sintomas leves ou moderados, como apenas dor, devem ser investigados e acompanhados para afastar o diagnóstico de expansão ou ruptura. Pode ser prudente adiar a cirurgia até que as condições clínicas ideais possam ser alcançadas. Se essa abordagem for a escolhida, considerar a internação em unidade de tratamento intensivo.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 4.6. AAA EM PACIENTES COM ALTO RISCO OPERATÓRIO -->
Portadores de AAA são, em sua maioria, idosos com elevado risco cardiovascular. Cerca de 10% da população com AAA > 5,5 cm são considerados inaptos à cirurgia aberta<sup>(26)</sup> .  
No início dos anos 1990, o tratamento endovascular (“ _Endovascular Aneurysm Repair_ ” - EVAR) foi desenvolvido especificamente para o tratamento de pacientes que não eram considerados aptos para a reparação cirúrgica aberta, tendo-se posteriormente expandido sua utilização.  
Foram avaliadas as evidências (Quadro 1 do Apêndice 2) para avaliar o impacto do EVAR nos pacientes considerados inaptos para a cirurgia aberta.  Entre as 74 referências, foram identificados um ECR<sup>(27)</sup> e uma revisão sistemática<sup>(26)</sup> em relação aos pacientes inoperáveis.  
O EVAR 2, único ECR a avaliar o uso de EVAR _versus_ o tratamento clínico em pacientes inoperáveis, foi considerado de boa qualidade: randomização realizada por programa computacional, boa aderência ao protocolo, avaliadores cegos e independentes para análise dos desfechos e com perda pequena, apenas 2 pacientes, durante o seguimento; estudo patrocinado pelo centro de pesquisa governamental da Inglaterra, sem a participação deste na condução do estudo ou na análise dos dados; o cegamento dos participantes foi considerado como não importante para o desfecho de mortalidade e como alto risco para os desfechos infarto do miocárdio e AVC (figuras 5 e 6 do Apêndice 4).  
Os pacientes do ensaio EVAR 2 foram considerados inaptos para a cirurgia aberta, de  
acordo com a avaliação local da equipe médica. No protocolo do estudo, era sugerido (“normalmente os pacientes com tais condições não seriam candidatos”) que pacientes com infarto do miocárdio ou angina nos últimos 3 meses não realizassem nenhum procedimento, assim como os com angina instável em repouso ou noturna. Ainda, de acordo com as sugestões do protocolo, não seriam candidatos à cirurgia, mas candidatos à EVAR os pacientes com as seguintes condições:  
- Doença valvar grave;  
- Arritmia cardíaca significativa;  
- Insuficiência cardíaca descompensada;  
- Incapacidade de subir um lance de escadas sem angina ou dispneia;  
- FEV1 < 1,0 L;  
- PO2 < 8,0 KPa;  
- PCO2 > 6,5 KPa; ou  
- Creatinina > 2,26 mg/dl.  
Não houve benefício da EVAR nesta população em relação a infarto do miocárdio, AVC ou morte (Quadro 5 do Apêndice 3).  
Em 2015, Parkinson e colaboradores<sup>(26)</sup> publicaram uma revisão sistemática, cujo objetivo foi o de avaliar a taxa de ruptura dos AAA maiores do que 5,5 cm nos pacientes considerados inaptos para a cirurgia. Após uma revisão nas bases do Medline, EMBASE e Cochrane, com a identificação inicial de 1.892 referências, selecionaram 1 ensaio randomizado (EVAR) e 10 estudos observacionais, totalizando 1.514 pacientes e 347 rupturas.  
Nesta revisão, utilizando os critérios GRADE, observou-se moderada qualidade, com baixo risco de viés em relação à heterogeneidade, inconsistência ou evidência indireta, porém foi identificado risco de viés de publicação.  
Entre os casos de ruptura, 32% foram operados e, nestes, a mortalidade cirúrgica foi de 58%. A morte por outras causas foi maior do que a morte por ruptura (42% _versus_ 19%; p < 0,001). O risco de morte por ruptura, de acordo com o tamanho do aneurisma, está demonstrado na Quadro 7.  
Quadro 7 – Risco de morte em pacientes com AAA > 5,5 cm e inaptos para a cirurgia aberta em relação ao tamanho do aneurisma.  
|Tamanho do AAA|Mortepor ruptura|
|---|---|
|5,5 a 6,0 cm|9,9%|
|6,1 a 7,0 cm|8,9%|
|Maior doque 7,0 cm|12,3%|  
Considerando a mortalidade em 30 dias após o tratamento com EVAR, o risco de morte por ruptura do aneurisma e a expectativa de vida dos pacientes julgados com alto risco operatório, foi observada uma significativa heterogeneidade entre os resultados. Portanto, a recomendação para os pacientes inoperáveis deve ser tomada de maneira individualizada.  
Em pacientes com AAA > 5,5 cm, considerados de alto risco operatório, sugere-se que o tratamento com EVAR deva ser utilizado apenas após análise do risco individual. A redução do risco de morte por ruptura com o EVAR, respeitando a expectativa de vida e preferência do paciente, deve superar o risco do procedimento (mortalidade em 30 dias).

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 4.7. ANEURISMAS ROTOS -->
A ruptura do aneurisma é um evento com alta mortalidade. A cirurgia ou o tratamento endovascular nestes casos é uma emergência médica.  
A busca resultou em 255 referências (Quadro 1 do Apêndice 2), sendo identificados 4 ensaios clínicos randomizados<sup>(28-31)</sup> considerados de boa qualidade. As características destes ensaios estão resumidas nos Quadros 6-9 do Apêndice 3.  
O ensaio AJAX<sup>(28)</sup> foi considerado de boa qualidade, por conta da randomização realizada por computador, alocação com envelopes lacrados, opacos e em sequência. A equipe cirúrgica não teve cegamento, mas considerou-se que isso não influenciou significativamente os resultados. Houve avaliadores dos desfechos independentes e cegos, e não se identificaram outros riscos de viés (figuras 3 e 4 do Apêndice 4).  
No ensaio Hinchliffe 2006<sup>(29)</sup> , a randomização não foi explicitada, sendo considerado indeterminado o risco de viés. A alocação foi realizada adequadamente por meio de envelopes opacos selados. O cegamento dos participantes não foi realizado, mas considerou-se não ter influenciado no risco de viés. Considerou-se como incerto o critério “outros vieses”, devido à falta de poder do estudo que apresentou um número de participantes, 32, inferior ao número estimado necessário, 100.  
No ensaio IMPROVE<sup>(30)</sup> , a randomização foi gerada por meio de central telefônica e a alocação foi realizada por computador de maneira independente. Cegamento dos cirurgiões e avaliadores não foi realizado, mas considerou-se não ter influenciado o risco de viés. Houve perda de seguimento em 1 ano de 2 pacientes em 613.  
Por fim, foi considerado alto o risco de viés relacionado à randomização e alocação do ensaio ECAR<sup>(31)</sup> , que definiu o braço de tratamento, EVAR ou cirurgia, de acordo com a semana em que o paciente foi encaminhado ao estudo. Os desfechos foram avaliados por comitê independente. Não houve perda de seguimento. Todos os desfechos relevantes foram publicados.  
Não foram observadas diferenças significativas entre as intervenções de acordo com as meta-análises para morte em 30 dias (figura 14 do Apêndice 5) e morte em 6 a 12 meses (figura 15 do Apêndice 5).

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: Recomendação para pacientes com AAA rotos. -->
AAA rotos estáveis, com anatomia favorável ao tratamento por EVAR (confirmada pela tomografia computadorizada), devem ser tratados em caráter emergencial por cirurgia aberta ou EVAR de acordo com a experiência e disponibilidade da equipe cirúrgica e material.  
5. FLUXOGRAMA DO TRATAMENTO DE ANEURISMA DA AORTA ABDOMINAL  
<!-- Start of picture text -->
Sim EVAR ou cirurgia de emergência<br>AAA Roto Acompanhamento clínico/radiológico, atenção<br>≤ 5,4  cm especial para aneurismas saculares ou<br>sintomáticos<br>Aptos à  EVAR de acordo com o risco/benefício<br>Não<br>EVAR individual<br>Aptos à<br>Cirurgia<br>> 5,4 cm cirurgia<br>Inaptos à<br>EVAR<br>Inaptos à<br>Acompanhamento clínico<br>cirurgia<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 6. RESUMO DAS RECOMENDAÇÕES -->
|Tipo de AAA|Grau de<br>confiança|Recomendação|Referências|
|---|---|---|---|
|Pequenos|Alto|Forte – contrária ao tratamento cirúrgico ou por<br>EVAR.|3-8|
|Grandes|Alto|Forte – favorável ao EVAR devido a menor<br>mortalidade em 30 dias.<br>Sugere-se considerar a experiência da equipe e<br>preferência dos pacientes na escolha entre cirurgia<br>aberta versus EVAR.|11-13|
|Inflamatórios|Baixo|Fraca – contrária à indicação de cirurgia ou EVAR<br>de maneira diferente aos demais AAA.|15-17|
|Saculares|Baixo|Fraca favorável EVAR ou cirurgia –<br>acompanhamento e avaliação cuidadosa em relação<br>à taxa de crescimento, possibilidade de infecção de<br>parede ou surgimento de sintomas.  O reparo eletivo<br>é uma opção.|18-21|
|Sintomáticos|Baixo|Fraca favorável EVAR ou cirurgia – cada situação<br>clínica deve ser abordada individualmente sendo<br>fundamental afastar ruptura.<br>Os pacientes com quadro agudo compatíveis com<br>ruptura devem ser submetidos à cirurgia ou implante<br>de endoprótese em caráter emergencial. Em<br>pacientes sintomáticos, afastada a ruptura, estáveis,<br>pode ser prudente adiar a cirurgia até que as<br>condições ideais possam ser alcançadas. Considerar<br>internação em unidade de tratamento intensivo.|22-25|
|Alto risco<br>operatório|Moderada|Fraca favorável ao EVAR poderá ser indicada após<br>análise do risco individual , quando a redução do<br>risco de morte por ruptura com o EVAR,<br>respeitando a expectativa de vida do paciente;<br>superar o risco do procedimento (mortalidade em 30<br>dias).|26,27|
|Rotos|Alto|Forte favorável ao EVAR ou cirurgia – AAA rotos<br>devem ser tratados em caráter emergencial através<br>de cirurgia aberta ou endoprótese.|28-31|

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: 7. REFERÊNCIAS -->
1. Albuquerque LC PJ BD. Diretrizes para a cirurgia das doenças de aorta. Arq Bras Cardiol. 2004;82((supl V)).  
2. Higgins, 2011. The Cochrane Collaboration's tool for assessing risk of bias in randomised trials. BMJ. 343. d5928  
3. Lederle FA, Wilson SE, Johnson GR, Reinke DB, Littooy FN, Acher CW, et al. Immediate repair compared with surveillance of small abdominal aortic aneurysms. NEJM. 2002;346(19):1437-44.  
4. Powell JT, Brown LC, Forbes JF, Fowkes FG, Greenhalgh RM, Ruckley CV, et al. Final 12-year follow-up of surgery versus surveillance in the UK Small Aneurysm Trial. Br J Surg. 2007;94(6):702-8. 5. Cao P, De Rango P, Verzini F, Parlani G, Romano L, Cieri E, et al. Comparison of surveillance versus aortic endografting for small aneurysm repair (CAESAR): results from a randomised trial. Eur J Vasc Endovasc Surg. 2011;41(1):13-25.  
6. Ouriel K, Clair DG, Kent KC, Zarins CK, Positive Impact of Endovascular Options for treating Aneurysms Early I. Endovascular repair compared with surveillance for patients with small abdominal aortic aneurysms. J Vasc Surg. 2010;51(5):1081-  
7. Filardo G, Powell JT, Martinez MAM, Ballard DJ. Surgery for small asymptomatic abdominal aortic aneurysms. Cochrane Database Syst Rev. 2015;2.  
8. Bath, M. F., Gokani, V. J., Sidloff, D. A., Jones, L. R., Choke, E., Sayers, R. D. and Bown, M. J. (2015), Systematic review of cardiovascular disease and cardiovascular death in patients with a small abdominal aortic aneurysm. Br J Surg, 102: 866–872. doi: 10.1002/bjs.9837  
9. Lederle FA. Should abdominal aortic aneurysm be managed differently in women? SJS. 2008;97(2):125-7.  
10. Grootenboer N, van Sambeek MR, Arends LR, Hendriks JM, Hunink MG, Bosch JL. Systematic review and meta-analysis of sex differences in outcome after intervention for abdominal aortic aneurysm. Br J Surg. 2010;97(8):1169-79.  
11. Reed WW, Hallett JW, Jr., Damiano MA, Ballard DJ. Learning from the last ultrasound. A population-based study of patients with abdominal aortic aneurysm. Arch Intern Med. 1997;157(18):2064-8.  
12. Scott RA, Tisi PV, Ashton HA, Allen DR. Abdominal aortic aneurysm rupture rates: a 7-year followup of the entire abdominal aortic aneurysm population detected by screening. J Vasc Surg. 1998;28(1):124-8.  
13. Paravastu SC, Jayarajasingam R, Cottam R, Palfreyman SJ, Michaels JA, Thomas SM. Endovascular repair of abdominal aortic aneurysm. Cochrane Database Syst Rev. 2014;1.  
14. Shea BJ, Grimshaw JM, Wells GA, Boers M, Andersson N, Hamel C, et al. Development of AMSTAR: a measurement tool to assess the methodological quality of systematic reviews. BMC Med Res Methodol. 2007;7:10.  
15. Poredos P. Inflammatory aortic aneurysm. The ESC Council for Cardiology Practice. 2008; 7: 10 - 18. 16. Fatima J, Gota C, Clair DG, Billings SD, Gornik HL. Inflammatory abdominal aortic aneurysm with retroperitoneal fibrosis. Circ J. 2014;130(15):1300-2.  
17. Puchner S, Bucek RA, Rand T, Schoder M, Holzenbein T, Kretschmer G, et al. Endovascular therapy of inflammatory aortic aneurysms: a meta-analysis. J Endovasc Ther. 2005;12(5):560-7.  
18. Almeida-Lopes J. Tratamento endovascular de aneurismas saculares isolados da aorta abdominal e da artéria ilíaca – caso clínico. Angiol Cir Vasc. 2014;11(1): 30-34.  
19. Sociedade Brasileira de Angiologia e Cirurgia Cardiovascular. Projeto Diretrizes SBACV. Aneurismas da aorta abdominal diagnóstico e tratamento. Dezembro, 2015.  
20. Elliot L. Chaikof, David C. Brewster, MDb, Ronald L. Dalman, MDc, et al. The Care of Patients with an Abdominal Aortic Aneurysm. J Vasc Surg. 2009;S2–S49.  
21. Moll, F.L. et al. Management of Abdominal Aortic Aneurysms Clinical Practice Guidelines of the European Society for Vascular Surgery. Eur J Vasc Endovasc Surg. 2011;41, S1 - S58.  
22. Johnson G, Jr, McDevitt NB, Proctor HJ, Mandel SR, Peacock JB. Emergent or Elective Operation for Symptomatic Abdominal Aortic Aneurysm. Arch Surg. 1980;115(1):51-53.  
23. Haug ES, Romundstad P, Aadahl P, Myhre HO. Emergency nonruptured abdominal aortic aneurysm. Eur J Vasc Endovasc Surg 2004;28:612-8.  
24. Sullivan CA, Rohrer MJ, Cutler BS. Clinical management of the symptomatic but unruptured abdominal aortic aneurysm. J Vasc Surg 1990;11:799-803.  
25. Tambyraja AL, Raza Z, Stuart WP, Murie JA, Chalmers RT. Does immediate operation for symptomatic non-ruptured abdominal aortic aneurysm compromise outcome? Eur J Vasc Endovasc Surg. 2004;28: 543-6.  
26. Parkinson, F. Rupture rates of untreated large abdominal aortic aneurysms in patients unfit for elective repair. J Vasc Surg. 2015;61(6):1606 - 1612.  
27. Brown LC. Does EVAR alter the rate of cardiovascular events in patients with abdominal aortic aneurysm considered unfit for open repair? Results from the randomised EVAR trial 2. Eur J Vasc Endovasc Surg. 2010;39(4):396-402.  
28. Reimerink JJ. Endovascular repair versus open repair of ruptured abdominal aortic aneurysms: a multicenter randomized controlled trial. Ann Surg. 2013;258(2):248-56.  
29. Hinchliffe, R.J. A Randomised Trial of Endovascular and Open Surgery for Ruptured Abdominal Aortic Aneurysm – Results of a Pilot Study and Lessons Learned for Future Studies. Eur J Vasc Endovasc Surg. 2006;32(5): 506 - 513.  
30. Powell JT. The Immediate Management of the Patient with Rupture: Open Versus Endovascular repair (IMPROVE) aneurysm trial. Acta Chir Belg. 2009;109(6):678-80.  
31. Desgranges, P. ECAR (Endovasculaire ou Chirurgie dans les Anévrysmes aorto-iliaques Rompus): A French Randomized Controlled Trial of Endovascular Versus Open Surgical Repair of Ruptured Aortoiliac Aneurysms. Eur J Vasc Endovasc Surg. 2015;50(3):303 - 310.  
APÊNDICE 1 - PERGUNTAS ESTRUTURADAS  
<u>Quadro 1 - Pergunta estruturada para AAA pequenos.</u>  
|P|Pacientes assintomáticos, aptos à cirurgia para correção do AAA, portadores de AAA não rotos e<br>com diâmetro entre 4,0 e 5,4 cm.|
|---|---|
|I|Cirurgia aberta ou EVAR.|
|C|Acompanhamento clínico.|
|D|Mortalidade em 30 dias, mortalidade global, ruptura, infarto do miocárdio, acidente vascular<br>cerebral e reintervenções.|
|S|Ensaio clínico randomizado e revisão sistemática.|  
P: população; I: intervenção; C: comparador; D: desfecho; S: tipo de estudo.  
- <u>Quadro 2 - Pergunta estruturada para AAA > 5,4 cm</u>  
|P|Pacientes assintomáticos, com AAA sem ruptura e maiores do que 5,4 cm, diagnosticados pela<br>ultrassonografia ou tomografia computadorizada.|
|---|---|
|I|EVAR.|
|C|Cirurgia aberta.|
|O|Mortalidade em 30 dias, mortalidade global até 4 anos, mortalidade global a longo prazo (além de<br>4 anos),infarto do miocárdio,acidente vascular cerebral e reintervenções.|
|S|Ensaio clínico randomizado e revisão sistemática.|  
P: população; I: intervenção; C: comparador; D: desfecho; S: tipo de estudo.  
<u>Quadro 3 - Pergunta estruturada para AAA inflamatórios.</u>  
|P|Portadores de aneurismas de aorta abdominal inflamatórios.|
|---|---|
|I|Cirurgia aberta ou EVAR.|
|C|Tratamento clínico.|
|D|Mortalidade em 30 dias, mortalidade até 4 anos, mortalidade a longo prazo (além de 4 anos),<br>infarto do miocárdio,acidente vascular cerebral e reintervenções.|
|S|Ensaio clínico randomizado e revisão sistemática.|  
P: população; I: intervenção; C: comparador; D: desfecho; S: tipo de estudo.  
<u>Quadro 4 - Pergunta estruturada para AAA saculares.</u>  
|P|Portadores de aneurismas de aorta abdominal saculares|
|---|---|
|I|Cirurgia aberta|
|C|EVAR|
|D|Mortalidade em 30 dias, mortalidade até 4 anos, mortalidade a longo prazo (além de 4 anos),<br>infarto do miocárdio, acidente vascular cerebral, reintervenções, insuficiência renal e isquemia<br>intestinal.|
|S|Ensaio clínico randomizado e revisão sistemática.|  
P: população; I: intervenção; C: comparador; D: desfecho; S: tipo de estudo.  
<u>Quadro 5 - Pergunta estruturada para AAA sintomáticos.</u>  
|P|Portadores de aneurismas de aorta abdominal sintomáticos.|
|---|---|
|I|Cirurgia aberta ou EVAR.|
|C|Tratamento clínico.|
|D|Mortalidade em 30 dias, mortalidade até 4 anos, mortalidade a longo prazo (além de 4 anos),<br>infarto do miocárdio,acidente vascular cerebral e reintervenções.|
|S|Ensaio clínico randomizado e revisão sistemática.|  
P: população; I: intervenção; C: comparador; D: desfecho; S: tipo de estudo.  
<u>Quadro 6 - Pergunta estruturada para AAA em pacientes inaptos à cirurgia.</u>  
|P|Portadores de AAA≥5,5 cm,inaptos à cirurgia aberta.|
|---|---|
|I|EVAR.|
|C|Tratamento clínico.|
|D|Mortalidade em 30 dias, mortalidade global, infarto do miocárdio, acidente vascular cerebral e<br>reintervenções.|
|S|Ensaio clínico randomizado,revisões sistemáticas.|  
P: população; I: intervenção; C: comparador; D: desfecho; S: tipo de estudo.  
<u>Quadro 7 - Pergunta estruturada para AAA rotos.</u>  
|P|Pacientes com AAA rotos.|
|---|---|
|I|EVAR.|
|C|Cirurgia aberta.|
|D|Mortalidade em30dias e mortalidadeglobal.|
|S|Ensaio clínico randomizado e revisão sistemática.|  
P: população; I: intervenção; C: comparador; D: desfecho; S: tipo de estudo.

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: APÊNDICE 2 - ESTRATÉGIA DE BUSCA -->
<u>Quadro1 – Estratégia de busca base Medline via Pubmed.</u>  
|Tipo de AAA|Estratégia|Referências|
|---|---|---|
|Pequenos|"aortic aneurysm, abdominal"[MeSH Terms] OR ("aortic"[All<br>Fields] AND "aneurysm"[All Fields] AND "abdominal"[All<br>Fields]) AND "small"[All Fields] AND (Randomized Controlled<br>Trial[ptyp] OR systematic[sb])|153|
|Grandes|(unfit[Title/Abstract] OR inoperable[Title/Abstract]) AND<br>(("aortic aneurysm"[MeSH Terms] OR ("aortic"[All Fields] AND<br>"aneurysm"[All Fields]) OR "aortic aneurysm"[All Fields]) AND<br>(Randomized Controlled Trial[ptyp] OR (("classification"[MeSH<br>Terms] OR "classification"[All Fields] OR "systematic"[All<br>Fields])AND review[Publication Type])))|51|
|Inflamatórios|"inflammatory aneurysm"[Title/Abstract] OR (("aortic<br>aneurysm"[MeSH Terms] OR ("aortic"[All Fields] AND<br>"aneurysm"[All Fields]) OR "aortic aneurysm"[All Fields]) AND<br>Randomized Controlled Trial[ptyp])|668|
|Saculares|("saccular aneurysm"[Title/Abstract] AND<br>abdominal[Title/Abstract]) OR (("aortic aneurysm"[MeSH<br>Terms] OR ("aortic"[All Fields] AND "aneurysm"[All Fields])<br>OR "aortic aneurysm"[All Fields]) AND Randomized Controlled<br>Trial[ptyp])|587|
|Sintomáticos|("symptomatic aneurysm"[Title/Abstract] AND<br>abdominal[Title/Abstract]) AND ("aortic aneurysm"[MeSH<br>Terms] OR ("aortic"[All Fields] AND "aneurysm"[All Fields])<br>OR "aortic aneurysm"[All Fields])|24|
|Inoperáveis|("aortic aneurysm, abdominal"[MeSH Terms] OR ("aortic"[All<br>Fields] AND "aneurysm"[All Fields] AND "abdominal"[All<br>Fields])) AND (unfit [All Fields] OR inoperable [All Fields] OR<br>"high risk"[All Fields]) AND (Randomized Controlled<br>Trial[ptyp]OR systematic[sb])|74|
|Rotos|"aortic aneurysm, abdominal"[MeSH Terms] OR ("aortic"[All<br>Fields] AND "aneurysm"[All Fields] AND "abdominal"[All<br>Fields]) AND "rupture"[All Fields] AND (Randomized<br>Controlled Trial[ptyp]OR systematic[sb])|255|

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: APÊNDICE 3 - CARACTERÍSTICAS DOS ESTUDOS -->
Os quadros 1 a 4 referem-se aos ensaios relacionados aos AAA pequenos; o Quadro 5, aos AAA em pacientes inaptos à cirurgia aberta; e os quadros 6 a 9, aos AAA rotos.  
<u>Quadro 1 - Lederle 2002. Cirurgia aberta versus acompanhamento clínico para AAA pequenos.</u>  
|Autor e ano|Lederle 2002|
|---|---|
|Período da randomização|1992 a 1997|  
|Intervenção|Cirurgia aberta|
|---|---|
|Comparador|Acompanhamento clínico/imagem a cada 6 meses, cirurgia em caso de:<br>1) surgimento de sintomas; 2) diâmetro do aneurisma > 5,4 cm ou 3)<br>crescimento rápido do aneurisma(> 0,7 cm/6 meses ou >1 cm/ano).|
|Critério de inclusão|50-79anos,aptos à cirurgia,AAA infra-renal 4,0-5,4 cm.|
|Critério de exclusão|Aorta torácica > 4,0 cm; cirurgia aórtica prévia; aneurisma roto, justa-<br>renal ou supra-renal; crescimento > 1,0 cm ao ano ou > 0,7 cm em 6<br>meses, doença importante renal, cardíaca, hepática ou pulmonar e<br>aqueles com expectativa de vida inferior a 5 anos.|
|Seguimento(média)|4,9anos|
|Percentual de cirurgia, média<br>de idade e sexo.|Grupo intervenção: cirurgia realizada em 92,6%; Homens: 98,8%;<br>média da idade: 68,4±5,9 anos.<br>Grupo controle: cirurgia realizada em 61,6%; Homens 99,6%, média da<br>idade: 67,8±6,1 anos.|
|Morte operatória|Grupo intervenção: 14/526 (2,7%)<br>Grupo controle: 7/340 (2,1%)<br>RR 1.29 (0,53-3,17)|
|Reoperação|Grupo intervenção: 9/526 (1,7%)<br>Grupo controle: 4/340 (1,2%)<br>RR 1,45(0,45-4,69)|
|Infarto do miocárdio|Grupo intervenção: 5/526 (1,0%)<br>Grupo controle: 13/340 (3,8%)<br>RR 0,25(0,09-0,69)|
|AVC|Grupo intervenção: 3/526 (0,6%)<br>Grupo controle: 2/340 (0,6%)<br>RR 0,97(0,16-5,77)|
|Diálise|Grupo intervenção: 1/526 (0,2%)<br>Grupo controle: 2/340 (0,6%)<br>RR 0,32(0,03-3,55)|
|Morte|Grupo intervenção: 143/569 (25,1%)<br>Grupo controle: 122/567 (21,5%)<br>RR 1,17(0,95-1,44)|  
Quadro 2 - UK Small Aneurysm Trial 2007.  Cirurgia aberta versus acompanhamento clínico para AAA  
<u>pequenos.</u>  
|Autor e ano|UK Small Aneurysm Trial 2007|
|---|---|
|Período da randomização|1991 a 1995|
|Intervenção|Cirurgia aberta|
|Comparador|Acompanhamento clínico/imagem a cada 6 meses para AAA entre 4,0 e<br>4,9 cm e a cada 3 meses para AAA entre 5,0 e 5,5 cm. Cirurgia em caso<br>de: 1) surgimento de sintomas; 2) diâmetro do aneurisma > 5,4 cm ou<br>3)crescimento rápido do aneurisma(>1 cm/ano).|
|Critério de inclusão|60-76 anos,aptos à cirurgia,AAA infra-renal 4,0-5,5 cm.|
|Critério de exclusão|Aneurismas sintomáticos|
|Idade e sexo(cirurgia)|69,3(4,4)anos,17,2% mulheres|  
|Seguimento(média)|12 anos|
|---|---|
|Percentual de cirurgia|Grupo intervenção: 93,8%<br>Grupo controle: 76,1%|
|Infarto do miocárdio|Grupo intervenção: 30/150 (20%)<br>Grupo controle: 24/159 (15%)<br>RR 1,32(0,81-2,16)|
|AVC|Grupo intervenção: 7/150 (0,5%)<br>Grupo controle: 5/159 (0,35%)<br>RR 1,48(0,48-4,57)|
|Morte|Grupo intervenção: 362/563 (64,3%)<br>Grupo controle: 352/527 (66,8%)<br>RR 0,96(0,88-1,05)|  
<u>Quadro 3 - PIVOTAL 2010.  EVAR versus acompanhamento clínico para AAA pequenos.</u>  
|Autor e ano|Ouriel 2010|
|---|---|
|Período da randomização|2005-2008|
|Intervenção|EVAR|
|Comparador|Acompanhamento clínico/imagem a cada 6 meses. Cirurgia em caso de:<br>1) surgimento de sintomas; 2) diâmetro do aneurisma > 5,4 cm ou 3)<br>crescimento rápido do aneurisma(> 0,5 cm/6 meses).|
|Critério de inclusão|40-90 anos,AAA infra-renal 4,0-5,0 cm.|
|Critério de exclusão|Aneurismas sintomáticos, expectativa de vida inferior a 3 anos,<br>creatinina > 2,5 mg/dL, escore SVS > 2, com exceção da idade e<br>controlepressórico.|
|Idade e sexo(EVAR)|70,5(7,8)anos,11,2% mulheres|
|Seguimento(média)|1,7(1)anos|
|Percentual de cirurgia|Grupo intervenção: 88,9%<br>Grupo controle: 30,1%|
|Morte operatória|Grupo intervenção: 2/366 (0,6%)<br>Grupo controle: 0/362<br>RR 4,95(0,24-102,65)|
|Morte|Grupo intervenção: 15/366 (4,1%)<br>Grupo controle: 15/362 (4,1%)<br>RR 0,99 (0,49-1,99)|  
<u>Quadro 4 - CAESAR 2010.  EVAR versus acompanhamento clínico para AAA pequenos.</u>  
|Autor e ano|Cao 2010|
|---|---|
|Período da randomização|2004 a 2008|
|Intervenção|EVAR|
|Comparador|Acompanhamento clínico/imagem a cada 6 meses. Cirurgia em caso de:<br>1) surgimento de sintomas; 2) diâmetro do aneurisma > 5,4 cm ou 3)<br>crescimento rápido do aneurisma(> 1,0 cm/ano).|
|Critério de inclusão|AAA 4,1-5,4 cm;50-79anos;expectativa de vida > 5 anos.|
|Critério de exclusão|Aneurisma roto; dilatação supra-renal ou torácica > 4,0 cm; doença<br>pulmonar,cardíaca,hepática ou renal importante.|  
|Idade e sexo(EVAR)|69 (6,4);mulheres 4,9%|
|---|---|
|Seguimento(média)|2,7(1,75-3,7)anos|
|Reoperação|Grupo intervenção: 10/175 (0,6%)<br>Grupo controle: 0/85 (0%)<br>RR 10,26(0,61-173,07)|
|Morte operatória|Grupo intervenção: 1/175 (0,6%)<br>Grupo controle: 0/85 (0%)<br>RR 1,47(0,06-35,61)|
|Morte|Grupo intervenção: 9/182 (4,9%)<br>Grupo controle: 8/178 (4,5%)<br>RR 1,10(0,43-2,79)|  
Quadro 5 - EVAR-2. EVAR versus acompanhamento clínico para AAA em pacientes inaptos à cirurgia aberta.  
|Autor e ano|EVAR-2 trial 2005 e 2010|
|---|---|
|Período da<br>randomização|1999 a 2003.|
|Intervenção|EVAR.|
|Comparador|Acompanhamento clínico. Durante o seguimento, 57% receberam<br>antiagregantesplaquetários e 42% estatinas.|
|Critério de inclusão|AAA > 5,5 cm, idade > 60 anos, considerados inaptos à cirurgia pela opinião<br>do cirurgião, anestesista ou cardiologista a nível local. AAA rotos ou<br>sintomáticospoderiam ser incluídos.|
|Critério de exclusão|AAA com formato imprópriopara utilização da EVAR.|
|Seguimento (média)|2,4 anos no EVAR-2; 4,0 anos para reintervenção;<br>6,8 anospara os resultados de infarto e AVC.|
|População|Média de idade: 77 ± 6 anos;<br>Tamanho médio do aneurisma: 6,7 ± 1,0 cm;86% homens.|
|Percentual de EVAR|Grupo intervenção: 88,9%;<br>Grupo controle: 69,6%.|
|Morte em 30 dias|Grupo intervenção: 13/150(8,7%).|
|Reintervenção|Grupo intervenção: 43/166;<br>Grupo controle: 7/172;<br>RR: 6,36(2,95-13,74).|
|Infarto do miocárdio|Grupo intervenção: 24/197;<br>Grupo controle: 22/207;<br>RR: 1,15(0,66-1,98).|
|AVC|Grupo intervenção: 11/197;<br>Grupo controle: 9/207;<br>RR: 1,28(0,54-3,03).|
|Morte|Grupo intervenção: 74/166;<br>Grupo controle: 68/172;<br>RR: 1,13(0,88-1,45).|  
<u>Quadro 6 - AJAX. EVAR versus cirurgia aberta para AAA rotos.</u>  
|Autor e ano|Reimerink 2013|
|---|---|
|Período da randomização|2004 a 2011|
|Intervenção|EVAR|
|Comparador|Cirurgia aberta|
|Critério de inclusão|Maiores de 18 anos,aneurismas rotos,aptos à cirurgia ou EVAR.|
|Critério de exclusão|Extensão do aneurismaparajuxta ou suprarrenal.|
|Percentual de cirurgia, média<br>de idade e sexo.|EVAR: Homens 86%; média da idade: 74,9 anos.<br>Cirurgia: Homens 85%,média da idade: 74,5 anos.|
|Morte operatória|EVAR: 12/57<br>Cirurgia: 15/59|
|AVC|EVAR: 0/57<br>Cirurgia: 2/59|
|Morte em 6 meses|EVAR: 16/57<br>Cirurgia: 17/59|  
<u>Quadro 7 - Hinchliffe. EVAR versus cirurgia aberta para AAA rotos.</u>  
|Autor e ano|Hinchliffe 2006|
|---|---|
|Período da randomização|2002 a 2004|
|Intervenção|EVAR|
|Comparador|Cirurgia aberta|
|Critério de inclusão|Pacientes com suspeita ou confirmação radiológica de AAA roto.|
|Critério de exclusão|Menores de 50 anos, inconscientes, falta de material, limitação<br>anatômicapara a técnica endovascular.|
|Idade e sexo (cirurgia)|EVAR: 74 (68,8-79,5) anos, 100% homens.<br>Cirurgia: 80(73,8-83,8)anos,100% homens|
|Reoperação|EVAR: 4/15<br>Cirurgia: 3/17|
|Morte em 30 dias|EVAR: 8/15 (1 antes da EVAR, 3 fizeram cirurgia).<br>Cirurgia:9/17(3 antes da cirurgia).|  
<u>Quadro 8 - IMPROVE. EVAR versus cirurgia aberta para AAA rotos.</u>  
|Autor e ano|IMPROVE 2015|
|---|---|
|Período da randomização|2009a 2013.|
|Intervenção|EVAR.|
|Comparador|Cirurgia aberta.|
|Critério de inclusão|Maiores de 50 anos com diagnóstico de AAA ou aneurisma aorto-ilíaco<br>rotos.|
|Critério de exclusão|Correçãoprévia de aneurisma,ruptura isolada de artéria ilíaca.|
|Idade e sexo|EVAR: média da idade: 76,7 (7,4) anos; Homens: 78%;<br>Cirurgia: média da idade: 76,7(7,8)anos;Homens: 79%.|
|Seguimento|12 meses.|
|Reintervenção|EVAR: 61/259<br>Cirurgia: 60/243|  
|Morte em 30 dias|EVAR: 112/316 (35,4%);|
|---|---|
||Cirurgia: 111/297(37,4%).|
|Morte em 1 ano|EVAR: 130/316 (41,1%)|
||Cirurgia: 133/297(45,1%)|  
<u>Quadro 9 - ECAR. EVAR versus cirurgia aberta para AAA rotos.</u>  
|Autor e ano|Desgranges 2015|
|---|---|
|Período da randomização|2008 a 2013.|
|Intervenção|EVAR.|
|Comparador|Cirurgia aberta.|
|Critério de inclusão|Maiores de 18 anos. Aneurismas aórticos abdominais, aorto-ilíaco ou<br>ilíaco rotos candidatos à cirurgia ou EVAR. Estáveis<br>hemodinamicamente. Disponibilidade de cirurgião experiente.|
|Critério de exclusão|Assintomáticos,aneurismas micóticos, pós traumáticos.|
|Idade e sexo|EVAR: média de idade: 73,8 (52-93) anos; 90% homens.<br>Cirurgia: média de idade: 75,0(56-96)anos; 91% homens|
|Seguimento|231,8 dias(31-365).|
|Infarto do miocárdio|EVAR: 2/56 (3,6%);<br>Cirurgia: 1/51(2,0%).|
|Insuficiência renal com<br>necessidade de diálise|EVAR: 6/56 (10,7%);<br>Cirurgia: 2/51(3,9%).|
|Morte operatória|EVAR: 11/56 (19,6%);<br>Cirurgia: 12/51(24%).|
|Morte em 1 ano|EVAR: 17/56 (30,3%);<br>Cirurgia: 18/51(35%).|  
APÊNDICE 4 - RISCO DE VIÉS  
O risco de viés para o desfecho mortalidade global está resumido nas figuras 1 e 2 (aneurismas pequenos) e 3 e 4 (aneurismas rotos) .  
Figura 1 - Risco de viés (mortalidade global) para AAA pequenos.  
<!-- Start of picture text -->
Gerago da sequéncia de alocacao (viés de selegao)ee<br>Sigilo da sequéncia de alocaco (viés de sele¢ao) }<br>Cegamento dos participantes (viés de condugao) }<br>Cegamento dos avaliadores (viés de deteccao)Ci<br>Desfechos incompletos (viés de atrito) _ISITE<br>0% 20% 40% 60% 80% 100%<br>= Baixo Incerto Alto<br><!-- End of picture text -->  
Figura 2 - Risco de viés por estudo (mortalidade global) para AAA pequenos.  
<!-- Start of picture text -->
A<br>a<br>°25<br>5 @<br>a2&BS—5 =<br>S¢23e<br>Ss 3% 8<br>2se £8 5<br>35s 382 5 2<br>se£25eee 3&<br>Beezeets<br>= £68 ¢6<br>§=s 8 8 38<br>a@ 2= oS&£ ®2 | indg<br>g & sees<br>2¢ 2&6 2<br>s §2se2e<br>2 2¢ ses &$ 36<br>8 8 8 5 5 &<br>e@essges<br>§2PeP2e258<br>28S ss €&€ BS<br>§ ss € e 8S gzeE<br>ec 2# G3 G4 £ ww» 6<br>wwwwsnf@l |lelelele<br>xsnaaf@] |[elelele,<br><!-- End of picture text -->  
Figura 3 - Risco de viés (mortalidade global) nos AAA rotos.  
<!-- Start of picture text -->
Geracao da sequencia<br>de alocacao (vies de selecéo) [III |<br>Sigilo da sequencia de alocacao (viés de seleco) IIISty<br>Cegamento dos participantes (viés de condugao) |<br>Cegamento dos avaliadores (viés de deteccao) Itty<br>Desfechos incompletos (viés de atrito) |S<br>Relato seletivo (viés de relato) tn<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>= Baixo Incerto Alto<br><!-- End of picture text -->  
Figura 4 - Risco de viés por estudo (mortalidade global) nos AAA rotos.  
<!-- Start of picture text -->
oo<br>gx<br>a<br>3<br>eos<br>@ @ 3<br>& —<br>2 .—4S 5<br>< o 3<br>56 ~ $fg = «<br>= ¢ = 2 @<br>os s 2 DB S<br>$3 2S €ee<br>£2 5 @ =€s5< a8<br><¢ €@ 3 2@ € 8<br>S 3 8 &§ #3<br>os 8 & E<br>> 2 § ® gs £<br>2 SC wn # 6S<br>5 =» 8 ® B<br>a 29 € ® 5 gf<br>2 £ § @2 g &<br>eg 2£ € a<br>©£ $s 56 S £<br>9 $ € gg 2et<br>2BB€S55s €&22 €S$528 @3@ 8® ty<br>Es aa Ges<br>3s 8 € € € es<br>§ 8s €e s2e2<br>ce ££ G4 @ £F£ H 8<br><!-- End of picture text -->  
Figura 5 - Risco de viés EVAR 2 para o desfecho mortalidade. Inaptos à cirurgia.  
<!-- Start of picture text -->
‘Cegamento dos participantes (viés de condugéo) |<br>Relaslave)<br>0% 20% 40% 60% 80% 100%<br>mBaixo Incerto mAIto<br><!-- End of picture text -->  
Figura 6 - Risco de viés EVAR 2 para os desfechos infarto do miocárdio ou AVC. Inaptos à cirurgia.  
<!-- Start of picture text -->
Geragdo da sequéncia de alocagdo (viés de selecdo) ISSN<br>Sigilo da sequéncia de alocaco (viés de selecdo)|<br>Cegamento dos participantes (viés de condugdo) P|<br>‘Cegamento dos avaliadores (viés de deteccao) UNNI<br>Desfechosincompletos (vis de tric) IY<br>Relatoseletvo vies de relato)<br>Outros viesesI<br>0% 20% 40% 60% 80% 100%<br>= Baixo Incerto =Alto<br><!-- End of picture text -->  
Figura 7 - Risco de viés (mortalidade global) para AAA grandes.  
<!-- Start of picture text -->
Geragao da sequéncia de alocacdo (viés de selecao) IIIS<br>Sigilo da sequéncia de alocagdo (viés de sele¢ao)ee<br>Cegamento dos participantes (viés de condugao) |<br>Cegamento dos avaliadores (viés de deteccdo) (INNS<br>Desfechos incompletos (viés de atrito) | ISIS/INIIININNINNNNINInnnnnnnnny<br>Relatoseletivo(vés de relat)|<br>Cutros vieses_|<br>0% 20% 40% 60% 80% 100%<br>= Baixo Incerto "Alto<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: APÊNDICE 5 – META-ANÁLISES -->
As meta-análises referentes aos AAA pequenos estão apresentadas nas figuras 1-3, AAA grandes nas figuras 4-13 e AAA rotos nas figuras 14-15.  
Figura 1 – Meta-análise da mortalidade global. Cirurgia aberta versus acompanhamento clínico, AAA pequenos.  
<!-- Start of picture text -->
Study or Subgroup EventsIntervencaT o tal_EventsControleTotal Weight M.H,OddsFixed, Ratio 95% CI_ Year MH,OddsFixed, Ratio 95% Cl<br>Lederle 2002 143° 569 122 567 41.3% 1.22 (0.93, 1.61] 2002<br>UK Small 2007 362 663 352 527 58.7% 0.90 [0.70, 1.15] 2007<br>Total (95% Cl) 1132 1094 100.0% — 1.03 [0.86, 1.24]<br>Total events 505 474<br>Testorowraeterz2629e5079 7% ravoeceitevengio Favorececoniole |<br><!-- End of picture text -->  
Figura 2 – Meta-análise da mortalidade global.  EVAR versus acompanhamento clínico, AAA pequenos.  
<!-- Start of picture text -->
Study or Subgroup _EventsIntervencaoTotal _EventsControleTotal Weight M-H,RiskFixed, Ratio95%CI_Year MH,RiskFixed, Ratio95% Cl<br>PIVOTAL 2010 15 366 15 362 651% 0.99 (0.49, 1.99] 2010<br>CAESAR 2010 9 182 8 178 34.9% 1.10(0.43, 2.79) 2010<br>Total (95% Cl) 548 540 100.0% 1.03 [0.59, 1.80]<br>Total events 24 23<br>Heterogeneity: Chi*= 0.03, df= 1 (P= 0.86); F= 0% 0.01 O41 1 10 100<br>Test for overall effect Z= 0.10 (P= 0.92) Favorece intervencao Favorece controle<br><!-- End of picture text -->  
Figura 3 – Meta-análise da mortalidade global. Cirurgia aberta ou EVAR versus acompanhamento clínico, AAA pequenos.  
<!-- Start of picture text -->
Study or Subgroup _EventsExperimentalTotal EventsControleTotal Weight M-H,RiskFixed, Ratio95%CI_ Year MH,RiskFixed, Ratio95% Cl<br>1.2.1 New Subgroup<br>Lederle 2002 143 569 122 567 24.0% 1.17 (0.95, 1.44] 2002<br>UK Small 2007 362 563 352 527 71.4% 0.96 (0.88, 1.05] 2007<br>PIVOTAL 2010 15 366 «= 15 362, 3.0% 0.99 0.49, 1.99] 2010<br>CAESAR 2010 g 182 8 178 1.6% 1.10 (0.43, 2.79] 2010<br>Subtotal (95% Cl) 1680 1634 100.0% 1.01 (0.93, 1.10]<br>Total events 529 497<br>Heterogeneity: Chi?= 3.17, df= 3 (P= 0.37); P= 6%<br>Test for overall effect: Z= 0.34 (P = 0.73)<br>Total (95% Cl) 1680 1634 100.0% 1.01 (0.93, 1.10]<br>Total events 529 497<br>TestHeterogeneity: Chi*= 3.17, df= 3 (P = 0.37), F= 6% 0.01 ot 4 10 100<br>Test for for  overall subaroup effect: differences:  Z= 0.34 (P= Not  0.73) applicable Favorece intervenc3o Favorece controle<br><!-- End of picture text -->  
Figura 4 - Mortalidade em 30 dias, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study or Subgroup _EventsEVARTotal EventsCirurgiaTotal Weight M.-H,RiskFixed, Ratio95% Cl_Year MH,RiskFixed, Ratio95% Cl<br>ACE 2 150 1 148 1.7% 1,97 (0.18, 21.53]<br>DREAM 2 171 8 174 13.6% 0.26 (0.05, 1.18]<br>EVAR | 14 614 36 602 625% 0.38 [0.21, 0.70) a<br>OVER 2 427 «= 13-437 -22.1% 0.16(0.04, 0.69) —_—<br>Total (95% Cl) 1362 1361 100.0% — 0.34 [0.21, 0.57] ><br>Total events 20 58<br>Heterogeneity: ChiF= 3.38, df= 3 (P<br>Test for overall effect: Z= 4.18 (P < 0.0001)= 0.34), F= 11% oat aro EVAR Favor cinurga me<br><!-- End of picture text -->  
Figura 5 - Mortalidade geral até 4 anos, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study or Subgrouy EventsEVARTotal EventsCirurgiaTotal Weight M-H,RiskFixed, Ratio95% CI Year MH,RiskFixed, Ratio95% Cl<br>ACE 17 150 12:«149°«5.1% 1.41 (0.70, 2.84)<br>DREAM 20 173 18 178 7.5% 1.14 (0.63, 2.09}<br>EVAR | 153 626 164 626 69.2% 0.93 (0.77, 1.13]<br>OVER 31 444 43° 437) 18.3% 0.71 (0.46, 1.10]<br>Total (95% Cl) 1393 1390 100.0% 0.93 [0.79, 1.10]<br>Total events 2m 237<br>Heterogeneity. Chi*= 3.22, df= 3 (P<br>Test for overall effect: Z= 0.84 (P = 0.40)= 0.36); P= 7% on “Favor EVAR’ Favor cirurgia im<br><!-- End of picture text -->  
Figura 6 - Mortalidade geral em longo prazo, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study EVAR Cirurgia Risk Ratio Risk Ratio<br>| 260 626 264 626 561% 0.98 (0.86,1.12)<br>EVAR or Subgrouy Events Total Events Total Weight M-H, Fixed, 95% CI Year MH, Fixed, 95% Cl<br>OVER 1460 444 146 437) 31.3% 0.98 (0.82, 1.19]<br>DREAM 58 173 60 178 12.6% 0.99 (0.74, 1.33]<br>Total (95% Cl) 1243 1241 100.0% 0.99 [0.89, 1.09]<br>Total events 464 470<br>Heterogeneity: Chi*= 0.00, df= 2(P<br>Test for overall effect: Z= 0.28 (P = 0.78)= 1.00); P= 0% oat "Favor EVAR’ Favor cirurga im<br><!-- End of picture text -->  
Figura 7 - Reintervenção até 4 anos, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study or Subgrouy EventsEVARTotal EventsCirurgiaTotal Weight M-H,RiskFixed, Ratio95% CI Year MH,RiskFixed, Ratio95% Cl<br>EVAR | 121 626 46 626 43.6% 2.63 [1.91, 3.63] *<br>ACE 24 150 4 149° 3.8% 6,96 (2.12, 16.76] _—_—<br>OVER 61 444 55 437 52.6% 1.09 [0.78, 1.53]<br>Total (95% Cl) 1220 1212 100.0% 1.95 [1.56, 2.43] «<br>Total events 206 105<br>Heterogeneity: Chi?= 19.03, df= 2 (P < 0.0001); F= 99%<br>Test<br>for overall effect: Z= 5.90 (P < 0.00001) oat "FavorEVAR Favor Ciurgia im<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: Figura 8 - Reintervenção a longo prazo, EVAR versus cirurgia aberta. -->
<!-- Start of picture text -->
Study or Subgrouy EventsEVARTotal EventsCirurgiaTotal Weight M-H,RiskFixed, Ratio95% CI Year MH,RiskFixed, Ratio95% Cl<br>OVER 98 444 «= 78 «437 48.2% 1.24 (0.95, 1.61]<br>EVAR | 145 626 55 626 337% 2.64 [1.97, 3.52] *<br>DREAM 48° 173 30 178 18.1% 1.65 [1.10, 2.47] i<br>Total (95% Cl) 1243 1241 100.0% 1.78 [1.50, 2.12] +<br>Total events 231 163<br>Heterogeneity: Chi?= 14.38, df= 2 (P<br>Test = 0.0008); P= 86%<br>for overall effect: Z= 6.48 (P < 0.00001) oat "FavorEVAR Favor Ciurgia im<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Aneurisma aorta abdominal | secao: Figura 9 - Infarto do miocárdio, EVAR versus cirurgia aberta. -->
<!-- Start of picture text -->
Study EVAR Cirurgia Risk Ratio Risk Ratio<br>‘ACE or Subgroup Events Total Events Total Weight M-H, Fixed, 95% Cl MH, Fixed, 95% Cl<br>DREAM 1321721 150 141 178149° 13.9%1.0% 0.990.96 (0.06,(0.46,15.73]1.97]<br>EVAR | 59 626 55 626 55.5% 1.07 (0.76, 1.52]<br>OVER 39 444 «29437 29.5% 1.32 0.83, 2.10]<br>Total (95% Cl) 1393 1390 100.0% 1.13 (0.87, 1.46]<br>Total events 112 99<br>Heterogeneity: Chi*= 0.75, df= 3 (P = 0.86); P= 0%<br>Test for overall effect: Z= 0.92 (P= 0.36) 501 OF aor EVAR Favor Cinuigia 100<br><!-- End of picture text -->  
Figura 10 - Acidente vascular cerebral não fatal, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study or Subgroup EventsEVARTotal EventsCirurgiaTotal Weight M-H,RiskFixed, Ratio95% Cl MH,RiskFixed, Ratio95% Cl<br>ACE 1 150 1 149° 2.6% 0.99 (0.06, 15.73)<br>EVAR | 24 626 © 34 626 87.1% 0.71 (0.42, 1.18]<br>OVER 7 484 4 437 10.3% — 1.72/0.51, 5.84)<br>Total (95% Cl) 1220 1212 100.0% 0.82 (0.52, 1.29]<br>Total events 32 39<br>Heterogeneity: Chi¥= 1.77, df= 2 (P<br>Test for overall effect: Z= 0.86 (P = 0.39)= 0.41); F= 0% 5.01 Oo vor EVAR | Favor Cirursa 100<br><!-- End of picture text -->  
Figura 11 - Acidente vascular cerebral fatal, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study or Subgroup _EventsEVARTotal EventsCirurgiaTotal Weight _M-H,RiskFixed, Ratio95% Cl MH,RiskFixed, Ratio95% Cl<br>DREAM 3. 173 4178 188% 0.77 (0.18, 3.40)<br>EVAR | 14 626 © 17 626 81.2% 0,820.41, 1.66]<br>Total (95% Cl) 799 804 100.0% 0.81 [0.43, 1.53]<br>Total events 17 n<br>TestHeterogeneity:for overall effectChi¥= Z=0.01, 0.64df=1 (P =(P= 0.62)0.94); F= 0% Oot Oeorevar|Favor Cirursa 100<br><!-- End of picture text -->  
Figura 12 - Complicações pulmonares, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study EVAR Cirurgia Risk Ratio Risk Ratio<br>‘ACE or Subgroup Events Total Events Total Weight _M-H, Fixed, 95% Cl MH, Fixed, 95% Cl<br>DREAM 6 160 8 149 30.0% 0.62 (0.21,1.85)<br>5 173 19 178 70.0% 0.27 (0.10,0.71] —-—<br>Total (95% Cl) 323 327 100.0% 0.38 (0.18, 0.76] ><br>Total events 10 7<br>TestHeterogeneity:for overall ChiF=effect Z=1.25,2.70df=(P1 =(P 0.007) = 0.26), F= 20% Oot Otorevar|Favor Cirursia 100<br><!-- End of picture text -->  
Figura 13 - Complicações renais, EVAR versus cirurgia aberta.  
<!-- Start of picture text -->
Study or Subgroup EventsEVARTotal EventsCirurgiaTotal Weight M-H,RiskFixed, Ratio95% Cl MH,RiskFixed, Ratio95% Cl<br>ACE 3 150 1 149° 7.5% 2.98 (0.31, 28.32)<br>EVAR | 9 509 9 463 70.1% 0.91 (0.36, 2.27]<br>OVER 5 48d 3 437 225% 1.64 (0.39, 6.82)<br>Total (95% Cl) 1103 1049 100.0% 1.23 (0.60, 2.51]<br>Total events 7 13<br>Heterogeneity: Chi¥= 1.17, df= 2 (P = 0.56); F= 0%<br>Test for overall effect: Z= 0.56 (P= 0.57) 5.01 Oo vor EVAR | Favor Cirursa 100<br><!-- End of picture text -->  
Figura 14 – Meta-análise da mortalidade em 30 dias da EVAR versus cirurgia aberta para AAA rotos.  
<!-- Start of picture text -->
Study or Subgroup __ EventsEVARTotal EventsCirurgiaTotal Weight M-H,Risk RatioFixed, 95% CI Year MH,RiskFixed, Ratio 95% Cl<br>Hinchliffe 2006 8 15 9 17 5.6% 1.01 (0.52, 1.93] 2006<br>AJA 2013 12 7 15 59 9.8% 0.83 (0.43, 1.61] 2013<br>IMPROVE 2014 112° 316 111-297 76.2% 0.95 (0.77,1.17] 2014<br>ECAR 2015 11 561251 84% 0.83 0.40, 1.72) 2015<br>Total (95% Cl) 444 424 100.0% 0.93 (0.77, 1.12]<br>Total events 143 147<br>TestHeterogeneity:for overall ChiF=effect Z= 0.29,2 0.76 df= (P=3 &(P 0.45) = 0.96); F=0% oor AfavorOt  da EVAR. i A favor da cirurgia70 100<br><!-- End of picture text -->  
Figura 15 – Meta-análise da mortalidade entre 6 e 12 meses da EVAR versus cirurgia aberta para AAA rotos.  
<!-- Start of picture text -->
Study EVAR Cirurgia Risk Ratio Risk Ratio<br>AJA 2013or Subgroup __Events16 Total57 Events17 Total59 Weight9.7% M-H,0.97 Fixed,(0.55, 95%1.74] CI 2013Year MH, Fixed, 95% Cl<br>IMPROVE 2014 130 316 133 297 79.4% 0.92 (0.77,1.10) 2014<br>ECAR 2015 17 56 18-51 109% 0.86 (0.50, 1.48) 2015<br>Total (95% Cl) 429 407 100.0% 0.92 [0.78, 1.08]<br>Total events 163 168<br>TestHeterogeneity: for overall Chi*=effect: Z=0.10,! 1.01df=(P=2 (P& 0.31)= 0.95); F=0% oor AfavorOt da EVAR i A favor da cirurgia70 100<br><!-- End of picture text -->

---

