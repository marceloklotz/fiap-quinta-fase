<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
<!-- Start of picture text -->
:<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Torna pública a decisão de aprovar o Protocolo Clínico e Diretrizes Terapêuticas da doença de Chagas, no âmbito do Sistema Único de Saúde - SUS.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS DO MINISTÉRIO DA SAÚDE, no uso de suas atribuições legais e com base nos termos dos art. 20 e art. 23 do Decreto 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas da doença de Chagas, no âmbito do Sistema Único de Saúde - SUS.  
Art. 2º Conforme determina o art. 25 do Decreto 7.646/2011, o prazo máximo para efetivar a oferta ao SUS é de cento e oitenta dias.  
Art. 3º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico: http: //conitec.gov.br/.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
A doença de Chagas (tripanossomíase americana) é uma condição infecciosa aguda e crônica causada pelo protozoário _Trypanosoma cruzi_ . A transmissão da doença de Chagas pode ocorrer de diferentes formas (Coura, 2015; Brasil, 2017; Pinheiro et al.,2017):  
• contato com fezes/e ou urina de triatomíneos hematófagos (insetos popularmente conhecidos como barbeiro, chupão, chupança, fincão, furão, bicudo, percevejão, bicho-de-parede, bicho-de-parede-preto, percevejo-do-sertão, percevejo-francês, percevejo-gaudério, percevejogrande, procotó, porocotó, baratão, bruxa, cafote, cascudo, piolho-de-piaçava, quiche-do-sertão, rondão e vum-vum), por via direta (vetorial);  
- ingestão de alimentos contaminados com parasitos provenientes de triatomíneos infectados;  
- via materno-fetal;  
- transfusão de sangue ou transplante de órgãos;  
- acidentes laboratoriais, pelo contato da pele ferida ou de mucosas com material  
- contaminado.  
• transmissão sexual. Considerando o potencial das mucosas para a transmissão, inclui-se também a via sexual como teoricamente possível, tendo sido demostrada a transmissão em modelos animais e possibilidade de transmissão em população humana (Araújo et al., 2017; Rios et al., 2018).  
Dada a exposição e um período de incubação de 1 a 2 semanas (na transmissão oral este período varia de 3 a 22 dias), inicia-se a fase aguda, com duração em geral de 8 a 12 semanas (Brasil, 2009). A fase aguda é caracterizada clinicamente por síndrome febril prolongada relacionada à elevada parasitemia, quadros com poucos sintomas ou assintomáticos ou oligossintomáticos. Em alguns casos, pode haver comprometimento cardíaco e do sistema nervoso central. Entretanto, formas graves da doença aguda acometem menos de 1% dos pacientes (Acquatella, 2007; Bern, 2015; Dias et al., 2016).  
Na fase crônica, há anticorpos circulantes e a parasitemia não é mais detectável por microscopia direta. A fase crônica da doença de Chagas inclui a forma indeterminada (sem acometimento clínico ou sintomas) e as formas determinadas, com expressão cardíaca, digestiva, ou cardiodigestivas, além de outras menos comuns, como a neurológica. Ao longo da vida, estima-se que de 10 a 30% dos  
pacientes evoluem para a forma sintomática (Villar et al., 2014; Bern, 2015). Essas formas estão associadas à importante morbimortalidade e diminuição na qualidade de vida (Acquatella, 2007; Rassiet al., 2012).  
A doença de Chagas, antes confinada especialmente a áreas rurais das Américas do Sul e Central, apresenta-se atualmente em áreas urbanas, como consequência do êxodo rural. A doença também pode ser encontrada nos Estados Unidos, alguns países da Europa, <mark>pacientes com doença de Chagas foram diagnosticados em 17 dos 50 países da Europa,</mark> e de outros continentes, devido à migração internacional e ao maior fluxo de viajantes(Perez-Molinaet al., 2011; Rodriguez-Guardado et al., 2011). Mundialmente, estima-se que mais de 10 mil pessoas morram por ano em consequência desta doença,  e que aproximadamente 6 milhões de pessoas estejam infectadas na América Latina (América do Sul, América Central e México)(WHO, 2015).  
A situação epidemiológica desta doença no Brasil mudou substancialmente nas últimas décadas, como resultado das ações de controle, das transformações ambientais e de ordem econômica e social (Villela et al., 2009; Silveira, 2011; Dias et al., 2016). As estimativas atuais variam de 1,9 a 4,6 milhões de pessoas infectadas por _T. cruzi_ (Hotez e Fujiwara, 2014; Martins-Meloet al., 2014a), ou, mais provavelmente, de 1,0 a 2,4% da população (Dias et al., 2016). Como reflexo, permanece elevada a carga de mortalidade no país, sendo uma das quatro maiores causas de morte por doenças infecciosas e parasitárias, além da principal doença negligenciada no Brasil (Martins-Melo et al., 2016). Sua detecção e manejo continuam sendo um desafio pela ocorrência de casos relacionados à transmissão oral devido à ingesta de alimentos contaminados, à transmissão vetorial extradomiciliar, principalmente na região amazônica, e a existência de ciclos de transmissão do parasito em ambientes silvestres próximos às habitações humanas.  
Apesar da magnitude do problema, há incertezas no que tange ao manejo da doença de Chagas, em particular na atenção primária, à saúde da pessoa com a doença. Dessa forma, o objetivo deste Protocolo Clínico e Diretriz Terapêutica (PCDT) é sistematizar as condutas de diagnóstico, tratamento farmacológico e rastreamento da doença de Chagas.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
CID 10 - B57 Doença de Chagas  
CID 10 - B57.0  Forma aguda da doença de Chagas, com comprometimento cardíaco CID 10 - B57.1  Forma aguda da doença de Chagas, sem comprometimento cardíaco  
CID 10 - B57.2  Doença de Chagas (crônica) com comprometimento cardíaco CID 10 - B57.3  Doença de Chagas (crônica) com comprometimento do aparelho digestivo CID 10 - B57.4  Doença de Chagas (crônica) com comprometimento do sistema nervoso CID 10 - B57.5  Doença de Chagas (crônica) com comprometimento de outros órgãos CID 10 - K23.1  Megaesôfago na doença de Chagas CID 10 - K93.1  Megacólon na doença de Chagas

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
- Estão contempladas neste PCDT as pessoas afetadas pela doença de Chagas em sua fase crônica ou aguda (incluindo gestantes, neonatos e imunossuprimidos), bem como pessoas sob suspeita diagnóstica ou risco/vulnerabilidade para doença de Chagas. Entre elas, familiares, especialmente filhos de mães infectadas, pessoas que residiram ou residam em áreas geográficas de risco ou em determinados tipos de habitação e pessoas que receberam transfusão sanguínea antes de 1992.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
O presente PCDT não abrange questões relacionadas a:  
- gestantes com infecção pelo vírus da imunodeficiência humana (HIV);  
- questões relacionadas à doação de órgãos de pessoas afetadas pela doença de Chagas.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
A elaboração deste PCDT teve como base para sua estruturação o processo preconizado pelo Manual de Desenvolvimento de Diretrizes da Organização Mundial da Saúde (WORLDHEALTH ORGANIZATION, 2014) e pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde (MINISTÉRIO DA SAÚDE, 2016). A diretriz foi desenvolvida com base na metodologia GRADE (Grading of Recommendations Assessment, Development and Evaluation), seguindo os passos descritos no GIN-McMaster Guideline Development Checklist (SCHÜNEMANN et al., 2014). Esta metodologia envolve diversas etapas na elaboração deste documento, dentre elas a  
definição de um escopo, elaboração de perguntas de pesquisa estruturadas para busca de evidências, seleção, avaliação da qualidade e graduação das evidências pelo sistema GRADE, elaboração de recomendações por meio de um painel com especialistas e redação do texto final. Para elaborar este PCDT, foram realizadas revisões sistemáticas sobre acurácia de testes diagnósticos da doença de Chagas; tratamento etiológico (benznidazol ou nifurtimox); uso de nifedipina e dinitrato de isossorbida no tratamento de pessoas com megaesôfago chagásico sintomático; e uso de amiodarona no tratamento de pessoas com cardiopatia chagásica. Para a avaliação da qualidade da evidência disponível na literatura, foi utilizado o sistema GRADE e desenvolvidas tabelas de evidências na plataforma GRADEpro (GRADEpro GDT, 2015). A partir desse conteúdo, foram desenvolvidas recomendações a favor ou contra cada intervenção. Uma descrição detalhada do método de seleção de evidências e dos resultados obtidos encontram-se no Anexo 1 (seção “Metodologia para elaboração desta diretriz”).

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
O presente PCDT adota as orientações do Guia da Vigilância em Saúde do Ministério da Saúde, publicado em 2017 (Brasil, 2017).  
Na fase aguda, a suspeição se baseia em sinais e sintomas sugestivos da doença e/ou na presença de fatores determinantes e condicionantes epidemiológicos compatíveis (mesmo na ausência de sinais e sintomas clínicos), como a ocorrência de surtos (identificação entre familiares/contatos). Essa fase cursa com sintomatologia usualmente não específica, como febre, mal-estar e astenia, ou é simplesmente assintomática ou oligossintomática.  
O Quadro 1 apresenta os principais sinais e sintomas clínicos compatíveis com a doença de Chagas em fase aguda. Ressalta-se que, no caso da transmissão oral, têm sido relatados quadros clínicos diferenciados e com maior letalidade: _rash_ cutâneo, hemorragia digestiva, icterícia, aumento das aminotransferases e quadros mais frequentes e graves de insuficiência cardíaca (IC).  
#### **Quadro 1. Manifestações clínicas da doença de Chagas na fase aguda**  
- º  
- **• Febre (geralmente constante, não superior a 39**<sup>o</sup> **C), mal-estar, cefaleia, astenia e hiporexia; • Sinal de porta de entrada de infecção** :(casos de transmissão vetorial; menos frequentes):  
- **Sinal de Romaña: edema elástico das pálpebras unilateral, indolor, com reação de linfonodo satélite (principalmente pré-auricular), com edema frequentemente se propagando à hemiface correspondente;**  
- **Chagoma de inoculação: formação cutânea pouco saliente, endurecida, avermelhada, pouco dolorosa e circundada por edema elástico** ;.  
- **Edema (generalizado ou localizado em face ou membros inferiores)** , de consistência elástica ou  de consistência elástica ou **mole, geralmente se apresentando após a segunda semana,** não estsem rel **a** ndçã **o** com sinais de porta de relacionado a sinais de portentr **a** de entrada;da;  
- **Exantemas e chagomas hematógenos, acometendo pele e tecido celular subcutâneo, sem alteração da cor, não aderentes a planos profundos, comumente indolores e com tamanho variável;**  
- **Linfonodos com aumento** no volume discreto a moderadodiscreto a moderado no volume **;**  
- **Hepatomegalia e/ou esplenomegalia** , pequena a moderada; pequena a moderada;  
- **Mio** cardite;pericardite;  
- **• Encefalite;**  
- **Anemia, linfócitos com presença** linfócitos atípicos, plasmocitose e nde linfócitos atípicos, plasmocitose  neutropenia relativa; **e** utropenia relativa;  
- **• Alterações eletrocardiográficas: diminuição da voltagem do complexo QRS, bloqueio atrioventricular de primeiro grau, alteração primária da repolarização ventricular e aumento da sístole elétrica.**  
Fonte: Adaptado de II Consenso Brasileiro em Doença de Chagas, 2015.  
Segundo a Organização Mundial da Saúde (OMS), durante a fase aguda, a doença de Chagas pode ser diagnosticada por meio de métodos parasitológicos, dado o grande número de parasitos que circulam no sangue (WHO, 2002). Para isso, o diagnóstico fundamenta-se na busca e no reconhecimento de _T. cruzi_ em exames diretos (pesquisa direta a fresco ou testes de concentração como Strout, micro-hematócrito ou creme leucocitário). Quando os resultados do exame a fresco e de concentração forem negativos na primeira coleta, novas coletas devem ser realizadas até a confirmação da doença e/ou desaparecimento dos sintomas da fase aguda, ou confirmação de outra hipótese diagnóstica.  
O Guia de Vigilância em Saúde do Ministério da Saúde recomenda que métodos parasitológicos diretos, como pesquisa a fresco de tripanossomatídeos e métodos de concentração para o diagnóstico da fase aguda, devem ser realizados simultaneamente  (Brasil, 2017; Brasil, 2013). As técnicas de concentração disponíveis têm como objetivo ampliar a sensibilidade diagnóstica, permitindo a captação de mais casos.  
É importante salientar que exames parasitológicos indiretos, como xenodiagnóstico e hemocultura, podem ser positivos em pessoas com doença de Chagas em sua fase crônica. Portanto, os exames parasitológicos diretos são o padrão ouro para diagnóstico de fase aguda. O objetivo desses exames é identificar a presença de _T. cruzi_ no sangue periférico (Figura 1).  
As metodologias aplicáveis na pesquisa direta são:  
- i. Exame a fresco de tripanossomatídeos: de execução rápida e simples, sendo mais sensível que o esfregaço sanguíneo. A coleta deve ser realizada em pessoa com síndrome febril e até 30 dias do início de sintomas. Caso a primeira coleta seja negativa e a suspeita clínica persistir, recomenda-se nova coleta entre 12 a 24 horas da primeira.  
- ii. Métodos de concentração (Strout, micro-hematócrito ou creme leucocitário): são recomendados nos casos em que o exame a fresco for negativo. Entretanto, visando a otimização do diagnóstico, recomenda-se que sejam realizados simultaneamente ao exame a fresco. Em suspeitos com mais de 30 dias de sintomatologia, os métodos de concentração são mais sensíveis.  
- iii. Lâmina corada de gota espessa ou esfregaço sanguíneo: possui menor sensibilidade que os métodos anteriores, sendo realizados prioritariamente na região da Amazônia Legal, em virtude de aspectos operacionais pela sua utilização sistemática para o diagnóstico da malária (Brasil, 2013).  
“O Guia da Vigilância em Saúde do Ministério da Saúde, publicado em 2017, recomenda a realização simultânea de diferentes exames parasitológicos diretos. Quando os resultados do exame a fresco e de concentração forem negativos na primeira coleta, devem ser realizadas novas coletas até a confirmação do caso e/ou desaparecimento dos sintomas da fase aguda, ou confirmação de outra hipótese diagnóstica (Figura 1).  
Ainda em relação aos exames parasitológicos, os testes são operador-dependentes. Isso posto, são necessárias iniciativas de formação continuada de microscopistas integradas ao fortalecimento da vigilância, especialmente em áreas de maior prevalência e/ou com registro de surtos de transmissão oral. Nacionalmente, esses esforços podem ser articulados junto a programas de vigilância de outras doenças negligenciadas, como malária, em estratégias de abordagem integrada de síndromes febris agudas, com vistas a ampliar a capacidade diagnóstica e obter maior acurácia.  
Com relação aos exames sorológicos, apesar de não serem os mais indicados na fase aguda, podem ser realizados quando a pesquisa direta permanecer negativa e a suspeita clínica persistir.  
Recomenda-se a oferta de testagem sorológica também a familiares ou contatos assintomáticos que estiveram sob a mesma situação de risco e vulnerabilidade dos casos confirmados decorrentes de surto (Brasil, 2009). A soroconversão pode ser considerada um marcador de infecção.  
Apesar de não serem utilizados como primeira escolha, os exames sorológicos podem ser reagentes na fase aguda, ainda no primeiro mês de infecção, o que adiciona complexidade ao diagnóstico diferencial entre as fases aguda e crônica. A metodologia recomendada para confirmação de caso agudo pela pesquisa de imunoglobulina M (IgM) é a imunofluorescência indireta (IFI). Já para a pesquisa de imunoglobulina G (IgG) podem ser utilizados o ensaio de imunoabsorção enzimática (ELISA) e/ou a hemaglutinação indireta (HAI) e/ou a IFI, entre outras técnicas (Figura 1).  
Vale ressaltar que a detecção de anticorpos anti- _T. cruzi_ da classe IgM é uma técnica complexa, com resultados falso-positivos frente a várias doenças febris. A exclusão da presença de fator reumatoide responsável por falso-positivos (adsorção de fator reumatoide tipo IgM anti-IgG) não é realizada rotineiramente em laboratórios de análises clínicas. Isso limita a confirmação desse tipo de anticorpo antiparasito da classe IgM a unidades laboratoriais de referência nacional. Para realização do teste, o paciente deve obrigatoriamente apresentar alterações clínicas compatíveis com doença de Chagas aguda e história epidemiológica sugestiva, sendo mais adequado na fase aguda tardia, após pelo menos 30 dias de sintomas, quando repetidos exames de pesquisa direta forem negativos.  
O exame PCR apresenta-se como uma técnica promissora para o diagnóstico de Chagas na fase aguda, contudo os custos atuais e a não padronização em escala são uma barreira importante para justificar seu uso como rotina no momento (Ramirez et al, 2017).Para a verificação do estado geral dos casos agudos, é proposta uma relação de exames laboratoriais complementares para o seguimento dos casos e manejo clínico de eventuais complicações (Quadro 2) (Brasil, 2009). Ressaltase que exames adicionais ou modificações na rotina de exames poderão ocorrer conforme a presença de comorbidades.  
#### **Quadro 2. Exames laboratoriais complementares**  
- Urinálise (exame do sedimento urinário - EAS): útil para verificar a ocorrência de sangramento pelas vias urinárias;  
- Hemograma completo com plaquetas;  
- Eletrocardiograma (ECG);  
- Radiografia de tórax;  
- Testes de função hepática: são importantes marcadores para verificação do acometimento hepático, especialmente em casos de doença de Chagas aguda por transmissão oral. As aminotransferases (AST e ALT) frequentemente aparecem elevadas. Bilirrubinas (totais e frações) também podem estar alteradas, com ou sem icterícia visível. Tempo de protrombina (TAP ou TP) prolongado sugere dano hepático;  
- Provas de coagulação (TTPA): devem ser realizadas sempre que possível, especialmente nos casos com acometimento hepático importante ou manifestações hemorrágicas;  
- Endoscopia digestiva alta: indicada em casos de dor epigástrica intensa refratária ao tratamento específico ou na vigência dos seguintes sinais de alarme: hematêmese (vômito de sangue), melena (sangue nas fezes), vômitos persistentes, disfagia ou anemia;  
- Ecocardiograma: em casos de sintomas sugestivos de miopericardite;  
- Exame do liquor cefalorraquidiano: suspeita clínica de meningoencefalite.  
No Brasil, os casos suspeitos de doença de Chagas na fase aguda são de notificação compulsória às autoridades locais, segundo a Portaria SVS/MS nº 204, de 17 de fevereiro de 2016, sendo que a notificação em casos crônicos deve ser fortemente considerada. Informações complementares sobre o diagnóstico da fase aguda encontram-se no Anexo. A Figura 1 mostra o fluxo para diagnóstico da doença de Chagas pelos critérios laboratoriais sugeridos pelo Guia de Vigilância em Saúde (Brasil, 2017).  
Figura 1. Fluxograma para **d** iagnóstico da doença de Chagas aguda por critérios laboratoriais  
Fonte: Adaptado de Guia de **V** igilância em Saúde, 2017.<sup>a</sup> A confirmação pelo critério sorológico deve ser avaliada criteriosamente levando em consideração o intervalo entre as datas de início de sintomas e coleta da amostra de sangue, além de e **v** idências clínicas epidemiológicas.<sup>b</sup> Na detecção de **i** munoglobulina M (IgM) – descartar o caso somente após a avaliação da sorologia por imunoglobulina G (IgG) **.** Considerar soro reagente para IgM o título ≥ 1:40 e para IgG ≥ 1:80.<sup>c</sup> Para confirmação pelo marcador IgG, são necessárias duas coletas com intervalo mínimo de 15 di **a** s entre uma e outra, sendo preferencialmente execução pareada (inclusão da primeira e da segunda amostras no mesmo ensaio para efeitos comparativos).

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
A suspeita diagnóstica da do **e** nça de Chagas na fase crônica é baseada preli **m** inarmente nos achados clínicos e na história epide **m** iológica (Rassi, Rassi e Marin-Neto, 2010). C **o** ntudo, na maioria dos casos, a doença é assintom **á** tica, o que demanda clara definição de conte **x** tos epidemiológicos de risco e vulnerabilidade para **d** oença de Chagas.  
São considerados contextos **d** e risco e vulnerabilidade:  
- ter residido, ou resi **d** ir, em área com relato de presença de vetor tr **a** nsmissor da doença de Chagas ou ainda c **o** m reservatórios animais (silvestres ou domé **s** ticos) com registro de infecção por _T. cruzi_ ;  
- ter residido ou residir em habitação onde possa ter ocorrido o convívio com vetor transmissor (principalmente casas de estuque, taipa, sapê, pau-a-pique, madeira, entre outros modos de construção que permitam a colonização por triatomíneos);  
- residir ou ser procedente de área com registro de transmissão ativa de _T. cruzi_ ou com histórico epidemiológico sugestivo da ocorrência da transmissão da doença no passado;  
- ter realizado transfusão de sangue ou hemocomponentes antes de 1992;  
- ter familiares ou pessoas do convívio habitual ou rede social que tenham diagnóstico de doença de Chagas, em especial ser filho(a) de mãe com infecção comprovada por _T. cruzi_ .  
O diagnóstico é realizado pela combinação de dois testes sorológicos com métodos diferentes, visto que a parasitemia é muito baixa nessa fase da doença. Entre os testes disponíveis, os mais utilizados são ELISA, IFI e HAI. Em geral, eles apresentam altos níveis de sensibilidade e especificidade. Entretanto, pode haver discordância entre o resultado de diferentes testes, principalmente devido a diferenças na acurácia e execução do teste. Nos casos de discordância sorológica, geralmente procede-se à nova avaliação diagnóstica, podendo repetir um dos testes realizados anteriormente, realizar novo teste com outro método citado acima ou com _Western-blot_ (WB) ou quimiluminescência (CLIA) (Figura 2). O método PCR não deve ser utilizado dada a baixa sensibilidade diagnóstica nesta fase da doença (Anexo 1).  
Além dos métodos sorológicos convencionais, testes rápidos vêm sendo sugeridos como estratégia para avaliação diagnóstica.  Apesar de não substituírem o diagnóstico convencional, podem ser úteis especialmente em locais remotos sem infraestrutura laboratorial adequada, em pacientes com difícil acesso aos serviços de saúde e com possibilidade de perda de seguimento, assim como em gestantes com suspeita da doença, tanto durante o pré-natal quanto durante o trabalho de parto. Adicionalmente, essa estratégia pode ser considerada uma alternativa para busca ativa por casos em áreas remotas, por exemplo. O teste possui alta sensibilidade; portanto, resultados negativos podem ser utilizados para descartar o diagnóstico da doença.  
Contudo, nos casos de resultado positivo, é preciso realizar a confirmação sorológica, dado o elevado número de resultados falso-positivos (Anexo 1).  
Tabela 1. Orientações para o diagnóstico da doença de Chagas na fase crônica  
|**Fase da doença**|**Teste diagnóstico**|
|---|---|
|Crônica (diagnóstico|- Combinação de dois testes baseados em princípios distintos ou|
|inicial)|com diferentes preparações antigênicas, que podem ser: ELISA*,|
||IFI, HAI, WB ou CLIA.|
||- Teste rápido: caso seja negativo, o uso em testagem única,<br>descarta a doença; teste positivo demanda confirmação|
||diagnóstica com um dos testes acima.|
|Crônica (sorologias|Realizar um terceiro teste em diferente amostra de sangue, que|
|discordantes)|pode ser: ELISA, IFI, HAI, WB ou CLIA.|  
ELISA: ensaio de imunoabsorção enzimática; IFI: imunofluorescência indireta; HAI: hemaglutinação indireta; WB: _Western blot_ ; CLIA: quimiluminescência. *Pode ser utilizada a combinação de dois testes ELISA, desde que com preparações antigênicas diferentes.  
A Figura 2 mostra o fluxo para diagnóstico laboratorial da doença de Chagas na fase crônica.  
Figura 2. Fluxograma para diagnóstico da doença de Chagas na fase crônica por critérios laboratoriais  
<!-- Start of picture text -->
| teste répido pode ser<br>een nn realizado.<br>Se o resultado for negativo,<br>Coleta de amostras<br>sorologias IgG por métodosde sanguediagnésticos periférico —distintos para a realizagode duasou com diferentes Ghosineeem,Se © resultado for positivo,<br>realiza um exame sorolégico.<br>Resultado<br>dos exames<br>sorolégicos positivo?<br>|<br>Sim para os Sim para apenas Nao para os<br>dois testes um teste dois testes<br>Confirmao casoe inicia Realizar terceiro<br>tratamento conforme teste, em diferente Descarta 0 caso<br>critérios do PCDT amostra de sangue °<br><!-- End of picture text -->  
Fonte: Adaptado de Guia de Vigilância em Saúde, 2017<sup>a</sup> Cenários sem uma rede laboratorial adequada, investigação diagnóstica em pacientes com difícil acesso aos serviços de saúde e em gestantes com suspeita de doença de Chagas durante o pré-natal ou em trabalho de parto.<sup>b</sup> O terceiro teste realizado pode ser qualquer um dos seguintes: ELISA, IFI, HAI, WB ou CLIA.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Para o tratamento etiológico da doença de Chagas em qualquer fase, há dois medicamentos principais: benznidazol e nifurtimox (Sales et al, 2017). Ambos são efetivos em reduzir a duração e a gravidade clínica da doença. O benznidazol é mais utilizado no contexto brasileiro (Dias et al., 2016).A Tabela 2 apresenta as recomendações terapêuticas para o tratamento desta doença.  
Tabela 2. Recomendações terapêuticas para tratamento etiológico da doença de Chagas  
|Fase da doença de<br>Chagas|Faixa etária|Tratamento etiológico|
|---|---|---|
|Aguda|Todas as faixas<br>etárias|1ª linha: benznidazol<br>2ª linha: nifurtimox|
|Crônica indeterminada|Crianças e|1ª linha: benznidazol|
|ou digestiva|adolescentes|2ª linha: nifurtimox|
||Adultos < 50<br>anos|1ª linha: benznidazol<br>Não usar nifurtimox|
||Adultos ≥50<br>anos|Não tratar de rotina**|
|Crônica cardíaca<br>(fases iniciais*)|Todas as faixas<br>etárias|Decisão compartilhada: oferecer<br>possibilidade de tratamento, sendo tratar<br>com benznidazol ou não tratar alternativas<br>válidas<br>Não usar nifurtimox|
|Crônica cardíaca|Todas as faixas|Não tratar|
|(doença avançada)|etárias||  
*Entende-se por cardiopatia chagásica em fases iniciais: casos com alterações no eletrocardiograma (ECG), com fração de ejeção (FE) > 40%, ausência de insuficiência cardíaca (IC) e ausência de arritmias graves. **Decisão compartilhada com o paciente para o tratamento do benznidazol no caso de não haver contraindicações.  
Os principais benefícios esperados do tratamento são a redução da parasitemia e da reativação da doença, melhora dos sintomas clínicos, aumento da expectativa de vida, redução de complicações clínicas (tanto na fase aguda quanto na crônica) e aumento da qualidade de vida (Bern et al., 2011; Bern, 2015; Rassi, Rassi e Marin-Neto, 2010). Adicionalmente, por se tratar de uma doença relacionada à elevada vulnerabilidade social, a adequada abordagem da doença de Chagas potencialmente reduzirá inequidades em saúde para indivíduos, suas famílias e comunidades, superando o caráter de doença negligenciada (Dias et al., 2016).

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Com o uso de benznidazol, a frequência de eventos adversos é de cerca de 53%. Destacam-se parestesias (10,3%), artralgias (8,1%) e intolerância gastrointestinal (13,3%). Os eventos adversos dermatológicos que ocorrem com maior frequência são alopecia (0,9%), dermatites e _rash_ cutâneo (30 a 44%), geralmente sem necessidade de interromper o tratamento etiológico. Alguns sintomas, como parestesias (polineuropatia periférica), podem ter importante impacto sobre funcionalidade e qualidade de vida, com chance de persistir por alguns meses após a interrupção do tratamento (Anexo 1). Também podem ocorrer complicações mais graves, como depressão da medula óssea com neutropenia, sendo oportuna a realização de hemograma três (3) semanas após o início do tratamento (Brasil, 2013).  
O nifurtimox possui frequência de eventos adversos gerais na ordem de 85%, e os mais comuns são intolerância gastrointestinal (61%), eventos reumatológicos (artralgias) (33%) e acometimento dermatológico (15%) (Anexo).

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
O tratamento de pessoas afetadas com doença de Chagas na forma aguda deve ser imediato. Apesar dos medicamentos apresentarem eficácia semelhante, o benznidazol deve ser a primeira opção, devido à maior experiência de uso em nosso meio, maior disponibilidade, inclusive com apresentações pediátricas, e ao perfil de eventos adversos. O nifurtimox pode ser utilizado nos casos em que o benznidazol não for adequadamente tolerado (por exemplo, por eventos adversos importantes) (Rassi, Rassi e Marin-Neto, 2010; Dias et al., 2016). Em casos assintomáticos, ou na impossibilidade da confirmação diagnóstica, mas com suspeita persistente (pela avaliação clínica e vinculo epidemiológico, como por exemplo, sinais e sintomas característicos e evidência de presença  
de pessoas de convívio domiciliar/familiar com a doença ou exposição a triatomíneos ou suspeita de transmissão materno-fetal), o tratamento empírico pode ser considerado. O controle e registro do uso destes medicamentos são fundamentais, para o monitoramento de eventos adversos e tolerabilidade.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
O tratamento etiológico da pessoa afetada com a doença na fase crônica deve ser realizado de acordo com o perfil do paciente e a forma da doença (Dias et al., 2016).  Diante das atuais evidências para doença de Chagas e da relevância para a vigilância epidemiológica, a notificação compulsória de casos crônicos de doença de Chagas deve ser fortemente considerada com vistas a ampliar acesso e desenvolvimento de atenção integral, não restrita ao tratamento etiológico.  
Em crianças e adolescentes na fase crônica indeterminada, o tratamento é indicado visto que a taxa de negativação sorológica é relativamente alta e os antiparasitários geralmente são bem tolerados (Anexo 1). Devido a esses fatores, associados à maior expectativa de vida dessa população, espera-se que o tratamento evidencie efetividade superior em crianças em comparação aos adultos. Contudo, as evidências para a prevenção de manifestações clínicas da doença com uso de benznidazol são fracas, em particular devido ao curto período de seguimento dos estudos clínicos. As evidências para o uso de nifurtimox são menores, mas esse medicamento pode ser uma alternativa no caso de não tolerância ao benzonidazol.  
Para adultos na fase crônica indeterminada, o benefício do tratamento antiparasitário é incerto, a incidência de eventos adversos é em torno de 50%, com impacto funcional e na qualidade de vida, apesar de raramente conferirem gravidade (Anexo 1). A decisão quanto ao tratamento com benznidazol deve ser compartilhada entre médico e paciente, com esclarecimento sobre potenciais riscos. Em adultos menores de 50 anos, as vantagens do tratamento parecem superar as desvantagens, e a evidência de prevenção de doença cardíaca é maior; assim, o tratamento deve ser considerado (Viotti et al., 1994; Viotti et al., 2006). Em pessoas com doença de Chagas acima de 50 anos, o benefício tem maior grau de incerteza, não sendo sugerido como tratamento de rotina. Contudo, o tratamento pode ser considerado principalmente em, mas não se restringindo a, pessoas infectadas durante a vida adulta, que possuem maior expectativa de vida e ausência de comorbidades.  
Em mulheres em idade fértil com a doença na fase crônica, o tratamento antiparasitário pode trazer benefício adicional, devido à potencial diminuição no risco de transmissão congênita (Fabbro et al., 2014; Moscatelli et al., 2015). É importante orientar essas mulheres a fazerem uso de métodos anticoncepcionais durante o período de tratamento com antiparasitários.  
Pelo pequeno número de publicações avaliando o uso do nifurtimox, menor disponibilidade no país e maior ocorrência de eventos adversos, seu uso não é recomendado. Contudo, ele pode ser considerado nos casos motivados e com expectativa de maior benefício, como crianças, adolescentes e adultos jovens com infecção recente e intolerância ao benznidazol.  
Para pessoas com cardiopatia chagásica em fase inicial, por exemplo, que apresentam somente alterações no eletrocardiograma (ECG), com fração de ejeção (FE) normal, ausência de insuficiência cardíaca (IC) e ausência de arritmias graves, tanto o tratamento quanto não tratar com benznidazol são alternativas válidas. A decisão deve ser compartilhada, ou seja, é necessário envolver a pessoa afetada no processo de tomada de decisão, apresentando os potenciais benefícios e riscos, assim como as incertezas a respeito da efetividade do tratamento. Não há evidências que justifiquem o tratamento de pacientes com cardiopatia chagásica avançada, assim como não há evidência para recomendar o tratamento com nifurtimox nestes casos (Anexo).  
Na fase crônica com manifestação digestiva, a fisiopatologia da doença aponta para provável ausência de efeitos do tratamento antiparasitário na evolução natural da doença digestiva. A infecção promove destruição das células nervosas, incoordenação motora e visceromegalia, podendo resultar principalmente em megaesôfago e/ou megacólon. Não há evidências que apontem benefício com o tratamento antiparasitário para as manifestações digestivas (Bernet al., 2007; Bern et al., 2011). Assim, o tratamento deve ser realizado de forma independente da manifestação digestiva. As recomendações para o tratamento na fase crônica indeterminada se aplicam a casos na fase crônica digestiva, e as recomendações para tratamento na fase crônica cardíaca se aplicam a pessoas com doença cardiodigestiva.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
A imunossupressão associada à infecção por HIV representa um fator de risco importante para reativação da doença (Bern, 2015). A reativação caracteriza-se pelo aumento da parasitemia, semelhante ao quadro clínico da doença na fase aguda, e pela incapacidade do sistema imune de  
controlar a infecção (Sartoriet al., 2007). Nesses casos, há alta morbimortalidade decorrente da reativação da infecção no sistema nervoso central e miocardite, impactando também a qualidade de vida (Vaidianet al., 2004; Morilloet al., 2017). Os medicamentos antiparasitários podem exercer efeito no manejo, controle e prevenção da reativação, apesar das evidências limitadas. É indicado tratar pacientes infectados por HIV com doença de Chagas crônica sem reativação e sem tratamento etiológico prévio, preferencialmente com benznidazol. Deve-se considerar o _status_ imunológico do paciente, devido ao risco aumentado para síndrome inflamatória de reconstituição imunológica.  
Em pacientes transplantados e com reativação da doença, o tratamento é indicado. Esse tratamento deve ser feito com a mesma posologia indicada para casos não relacionados a transplantes, sendo o benznidazol a alternativa preferencial devido ao seu melhor perfil de eventos adversos e maior experiência com o uso no Brasil (Dias et al., 2016). Não há evidência científica para recomendar profilaxia secundária em casos submetidos a transplantes; contudo, ela pode ser considerada em casos selecionados, como aqueles com maior grau de imunossupressão conforme consenso entre especialistas.  
Para as gestantes com quadro clínico agudo e grave de doença de Chagas (por exemplo, miocardite ou meningoencefalite), o tratamento deve ser realizado independentemente da idade gestacional, devido à alta morbimortalidade materna. As evidências de malformações são fracas, uma vez que o número de casos relatados de tratamento na gestação é pequeno. Entretanto, há certeza do alto risco de transmissão congênita da doença (variação entre 22 a 71%) e do potencial impacto na saúde dos neonatos afetados, fato que reforça a importância da triagem pré-natal em contextos de maior vulnerabilidade para a doença de Chagas.  Assim, pode ser utilizado o benznidazol para o tratamento de gestantes com doença de Chagas aguda, preferencialmente a partir do segundo trimestre de gestação, quando o risco de malformações parece ser menor.  
Gestantes na fase aguda não grave da doença diagnosticadas no primeiro trimestre idealmente devem aguardar o segundo trimestre de gestação para realizar o tratamento. Apesar do benefício em redução de doença de Chagas neonatal, há incerteza sobre a ocorrência de eventos como mortalidade perinatal e malformações fetais; a mulher deve ser adequadamente informada sobre riscos e benefícios da abordagem e participar da decisão, sendo justificável o não tratamento nesses casos. O medicamento indicado é o benznidazol devido à maior experiência de uso comparado ao nifurtimox.  
Em gestantes com doença de Chagas na fase crônica, o tratamento não deve ser realizado, uma vez que o risco de transmissão congênita é baixo (Rassi, 2010). Gestantes com doença de Chagas crônica sem comprometimento cardíaco e sem comorbidades podem ser acompanhadas pelas equipes da Atenção Primária à Saúde (APS), enquanto gestantes com doença de Chagas aguda devem receber acompanhamento em serviços de atenção à saúde especializados. Apesar de não ser compulsória, é importante que a notificação de casos de doença de Chagas inclua não apenas a fase aguda como também a crônica, a fim de melhor determinar a ocorrência de eventos neonatais, seja decorrente da infecção ou do uso de antiparasitários.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
De uma a três décadas após a infecção aguda, 10 a 30% das pessoas com doença de Chagas evoluem para as formas cardíacas, digestivas e cardiodigestivas, com importante impacto na morbimortalidade e na qualidade de vida (Villaret al., 2014). Em linhas gerais, o tratamento das complicações da doença de Chagas é direcionado à condição clínica relacionada (por exemplo, IC ou megaesôfago). A seguir, é apresentado o manejo geral dessas complicações, com especial atenção a algumas questões que são específicas para a pessoa afetada pela doença de Chagas: uso de nifedipina e de isossorbida no tratamento de megaesôfago chagásico; e uso de amiodarona no tratamento de arritmias em pacientes com cardiopatia chagásica.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Pessoas com acometimento digestivo devido à doença de Chagas possuem alterações nas funções motora, secretora e absortiva devido à denervação autonômica dos órgãos (Pinazzo et al., 2010). Megaesôfago e megacólon são complicações relativamente comuns, devendo ser manejadas de forma semelhante aos casos sem doença de Chagas (Tabela 3). O manejo desses casos visa basicamente atenuar os comprometimentos clínicos, facilitando a passagem do alimento para o estômago e estimulando a evacuação (Dias et al., 2016).  
Especificamente com relação à terapêutica do megaesôfago em pessoas afetadas pela doença de Chagas, o uso de medicamentos como nifedipina e dinitrato de isossorbida pode ajudar no alívio dos sintomas (Anexo 1). O uso da nifedipina é recomendado na dose de 10 mg, por via sublingual, 30 minutos antes de cada refeição. Já o dinitrato de isossorbida é recomendado na dose de 2,5 a 5 mg,  
por via sublingual, 15 minutos antes de cada refeição (Dias et al., 2016). O efeito é essencialmente sintomático, e a alta taxa de eventos adversos prejudica a adesão, mas não confere maior risco. Em geral, pode-se tentar o seu uso em casos com sintomas de megaesôfago sem resposta adequada a medidas não farmacológicas, descontinuando a medicação caso ocorram eventos adversos. A nifedipina possui melhor tolerabilidade na população geral, mas não deve ser utilizada em casos com cardiopatia grave devido ao risco de hipotensão e retenção hidrossalina (Dias et al., 2016).  
Ressalta-se a necessidade de maior atenção ao diagnóstico diferencial da doença de Chagas na forma gastrointestinal (Pinazzo et al., 2010). Outras condições como acalasia primária idiopática, amiloidose, sarcoidose, neurofibrimatose, gastrenterite eosinofílica, coinfecção por _Helicobacter pylori_ , refluxo e tumores devem ser consideradas conforme a síndrome clínica manifesta. Em caso de constipação, esta pode estar relacionada a malignidade, distúrbios metabólicos, amiloidose e esclerose sistêmica. A investigação, além do exame clínico, consiste principalmente no uso de exames complementares de imagem como radiografia convencional ou contrastada e endoscopia, devendo ser utilizados em especial para excluir neoplasias (Dias et al., 2016). As pessoas com megaesôfago chagásico podem ser acompanhadas na APS, e os casos com maior intensidade de sintomas podem ser encaminhados a serviços especializados a fim de considerar investigação adicional ou outros tratamentos como cirurgia, dilatação pneumática ou aplicação de toxina botulínica.  
Tabela 3. Manejo de complicações digestivas da doença de Chagas  
|**Manifestação**<br>**clínica**|**Tratamento**|
|---|---|
|**Megaesôfago**|• Adequação de hábitos alimentares (mastigar bem os alimentos,<br>ingerir pequenos volumes por vez, dar preferência a alimentos<br>líquidos e pastosos, evitar a ingestão de alimentos irritantes e antes<br>de se deitar);<br>• Drogas que relaxam o esfíncter esofágico inferior: nifedipina,<br>dinitrato de isossorbida;<br>• Injeção de toxina botulínica no esfíncter esofágico inferior;<br>• Dilatação (por balão pneumático ou sonda);<br>• Tratamento cirúrgico.|
|**Megacólon**|• Instruções dietéticas: dietas com alto teor de fibras, elevada ingestão<br>de líquidos, restrição de alimentos constipantes;<br>• Atender sistematicamente ao desejo de evacuar;<br>• Evitar medicamentos constipantes (como opioides, diuréticos, anti-<br>histamínicos, anticonvulsivantes, entre outros);<br>• Laxativos emolientes ou osmóticos;<br>• Supositórios com glicerol;<br>• Enemas;<br>• Tratamento cirúrgico;<br>• Tratamento das complicações (remoção de fecaloma, redução de<br>volvo, tratamento cirúrgico de perfurações).|

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
O comprometimento cardiovascular é a manifestação clínica mais comum da doença de Chagas (Dias et al., 2016). Caracteriza-se por curso lento, sendo necessários em torno de 20 anos de infecção para o surgimento dos primeiros sintomas de IC. A patogênese das lesões cardíacas envolve destruição tissular progressiva pela presença de um processo inflamatório contínuo associado à presença de  
material genético do parasita e ativação do sistema imune humoral, provocando miocardite crônica e substituição dos miócitos lesionados por fibrose (Andrade et al., 2011). Alterações eletrocardiográficas são os primeiros indicativos do acometimento cardíaco e possibilitam avaliar evolutivamente a deterioração da função cardíaca (Andrade et al., 2011).  
A IC é uma complicação comum, devendo ser tratada de forma semelhante àquela dos casos com doença devido a outras etiologias, embora o seu prognóstico pareça ser pior em comparação ao das demais etiologias (Dias et al., 2016; Andrade et al., 2011).  A eficácia dos inibidores da enzima conversora de angiotensina (IECA), dos bloqueadores do receptor da angiotensina e dos mineralocorticoides não foi testada de forma controlada e em um número expressivo de pessoas com cardiopatia chagásica. No entanto, tais fármacos são utilizados para o tratamento da IC ao se extrapolarem os resultados dos estudos que testaram essas medicações em populações com IC de etiologia hipertensiva e isquêmica em sua maioria (Tabela 4 e Figura 3). O uso de betabloqueadores exige cautela nos casos com cardiopatia chagásica, visto que, apesar de acrescentar grande benefício ao tratamento dos casos com taquiarritmias e ectopias ventriculares, pode acentuar o grau de bradicardia ou bloqueios do sistema de condução, muito comuns nessa etiologia. Por conta disso, a dose máxima tolerada é muitas vezes inferior à dos estudos em casos com outras cardiopatias (Andrade et al., 2011; Dias et al., 2016). Os principais fármacos para o manejo da IC estão apresentados na Tabela 4.  
**Tabela 4. Tratamento de insuficiência cardíaca**  
|**Medicamento**|**Posologia usual**|**Principais cuidados**|
|---|---|---|
|**IECA**|||
|Enalapril<br>Captopril|5,0 a 20 mg, 2x ao dia<br>12,5 a 50 mg, 3x ao dia|Hipercalemia, perda de função<br>renal (piora de até 30% da<br>creatinina aceitável), tosse|
|**Betabloqueadores**|||
|Metoprolol succinato<br>Carvedilol|50 a 200 mg, 1x ao dia<br>3,125 a 50 mg, 2x ao dia|Bradicardia (bradicardia sinusal e<br>bloqueio atrioventricular),<br>hipotensão postural, fadiga, piora<br>da insuficiência cardíaca e<br>claudicação intermitente|
|**Diuréticos**|||
|Hidroclorotiazida<br>Furosemida|25 a 100 mg, 1x ao dia<br>40 a 160 mg, 1 a 3x ao dia|Hipotensão postural, hipocalemia,<br>insuficiência renal pré-renal|
|**Antagonista da aldosterona**|||
|||Hipercalemia, ginecomastia e|
|Espironolactona|25 a 50 mg, 1x ao dia|redução da excreção renal de<br>digoxina|
|**Digoxina**|||
|Digoxina|0,125 a 0,250 mg, 1x ao<br>dia ou 3x na semana.|Janela terapêutica muito próxima à<br>de toxicidade. Monitorar níveis<br>séricos ou sinais de intoxicação<br>como arritmias, distúrbios<br>gastrointestinais e visuais e<br>alterações eletrocardiográficas|  
#### **Combinação hidralazina + nitrato de isosssorbida**  
|Hidralazina|12,5 a 50 mg, 3x ao dia|Cefaleia, hipotensão, hipotensão|
|---|---|---|
|Dinitrato de isossorbida|10 a 40 mg, 3x ao dia|postural, lipotimia, síncope|
|Mononitrato de isossorbida|20 a 40 mg, 3x ao dia||  
IECA: inibidores da enzima conversora de angiotensina.  
Figura 3. Esquema para tratamento da insuficiência cardíaca  
IECA: Inibidores da enzima con **v** ersora de angiotensina. a. IECA deve ser iniciado em do **s** es baixas, gradualmente aumentadas até a dose má **x** ima tolerada. b. Em pacientes intolerantes a I **E** CA, utilizar ARAII (antagonistas dos receptores de angiotensina II) c. Beta-bloqueadores devem se **r** iniciados em pacientes compensados (não congest **o** s), em dose baixa; a dose deve ser gradualmente aumenta **d** a até a dose máxima tolerada. d. Hidralazina e nitratos são in **d** icados principalmente para hipertensos, negros e **p** acientes não tolerantes a IECA ou ARA II.  
e. Os diuréticos de alça são preferencialmente recomendados, por produzirem **d** iurese mais intensa. Em pacientes com congestão resist **e** nte, a sua combinação pode ser utilizada pois tem ef **e** itos sinérgicos.  
O transplante cardíaco é u **m** a opção no manejo dos casos com IC grave de etiologia chagásica. No Brasil, essa condição é a terceira causa de encaminhamentos para transplan **t** e cardíaco. Os registros da Sociedade Brasileira de Cardiologia mostram melhor desempenho relati **v** o no grupo de pessoas afetadas pela doença de Ch **a** gas submetidas a transplantes (Andrade et al., 2011). As arritmias são comuns, podendo causar palpitação, tontura, dispneia, lipotimia, síncope e **m** orte súbita. A principal causa de óbito nos casos co **m** cardiopatia é a morte súbita, que chega a 55 **a** 65%. O acometimento do sistema nervoso parassi **m** pático cardíaco e do sistema de condução pod **e** provocar disfunção do nó sinusal, bloqueios intrav **e** ntriculares e atrioventriculares e arritmias ventriculares. Mais de 50% dos casos infectados por _T. c_ **_r_** _uzi_ apresentarão alterações eletrocardiográfica **s** (Andrade et al., 2011).  
A amiodarona é o antiarrítmico mais comumente utilizado e de baixo custo, podendo ser útil no tratamento de pessoas com doença de Chagas (Anexo). Pessoas com arritmias graves devem ser encaminhadas a centros especializados para avaliar a necessidade ou o benefício do uso de cardiodesfibrilador implantável (CDI) ou de realização de ablação de focos arritmogênicos por cateter (Andrade et al., 2011).  
A decisão quanto ao uso de amiodarona deverá levar em conta a avaliação de riscos e benefícios. Na presença de arritmias potencialmente letais, como taquicardia ventricular sustentada, a amiodarona deverá ser utilizada de rotina em situações como antes da colocação do CDI, na impossibilidade de uso do CDI ou ainda em associação ao implante, para diminuir a ocorrência de choque elétrico. Seu uso é sugerido em casos com taquicardia ventricular não sustentada e risco alto de morte súbita. Contudo, o benefício esperado é menor e não foi documentado em estudos observacionais ou experimentais de qualidade. Assim, a utilização da amiodarona se dá por uma expectativa de benefício, que deve exceder os efeitos adversos citados abaixo (Andrade et al., 2011; Dias et al., 2016; Villelaet al., 2009). Nas outras situações, em geral, os riscos superam claramente os benefícios.  
Casos com taquicardia ventricular sustentada ou não sustentada e alto risco de morte súbita devem ser acompanhados em serviços especializados para avaliar a necessidade de colocação de CDI ou ablação de focos arritmogênicos. Os demais casos podem seguir acompanhamento na APS. De todo modo, a pessoa afetada pela doença de Chagas em uso de amiodarona necessita de avaliação clínica regular, sendo aconselhadas consultas no mínimo a cada 3 meses no primeiro ano e a cada 6 meses nos anos seguintes.  
O uso da amiodarona pode raramente levar a fibrose pulmonar e, frequentemente, a hiper ou hipotireoidismo, prolongamento do QT e taquicardia ventricular do tipo _torsades de pointes_ (Anexo). Associados a antiarrítmicos de classe IA (quinidina, procainamida, disopiramido), antidepressivos tricíclicos, diuréticos tiazídicos e sotalol predispõem a _torsades de pointes_ (Rassi; Rassi e Rassi, 2001). A associação com betabloqueadores predispõe à depressão nodal; no entanto, seu efeito é potencializado quando associado a betabloqueadores ou bloqueadores dos canais de cálcio providos de propriedades antiarrítmicas (verapamil, diltiazen). Assim, é importante que a pessoa com doença de Chagas em uso de amiodarona siga acompanhamento clínico regular em serviço especializado, sendo monitorada quanto a potenciais eventos adversos. As recomendações para o uso de amiodarona estão resumidas na Tabela 5.  
Tabela 5. Recomendações sobre o uso de amiodarona em pessoas com arritmias e doença de Chagas  
|**Condição**|**Recomendação**|
|---|---|
|Parada cardíaca prévia ou taquicardia ventricular<br>sustentada (com ou sem CDI)|Utilizar de rotina<br>Dose: 300 mg em bólus, 150 mg de<br>dose suplementar|
|Taquicardia ventricular não sustentada com alto risco|Considerar o uso|
|de morte súbita (disfunção sistólica do ventrículo|Dose: 200 a 400 mg ao dia|
|esquerdo, escore de Rassi<sup>a</sup>elevado ou áreas extensas<br>de fibrose)||
|Taquicardia ventricular não sustentada em casos com<br>baixo risco de morte súbita|Não utilizar|
|Extrassístoles ventriculares não complexas|Não utilizar|  
aEscore de Rassi: Estima a mortalidade em 10 anos com base em seis fatores: sexo masculino, classe funcional NYHA III ou IV, raio X de tórax com cardiomegalia, disfunção sistólica segmentar ou global no ecocardiograma, taquicardia ventricular não sustentada ao Holter, QRS de baixa voltagem no eletrocardiograma (ECG) de 12 derivações. Alto risco: mortalidade estimada de 84 a 85% em 10 anos. CDI: cardiodesfibrilador implantável  
Detalhes adicionais sobre as recomendações, incluindo nível de evidência, grau de recomendação e referências utilizadas, encontram-se no Anexo 1.  
Pacientes com cardiopatia chagásica possuem maior risco para desenvolvimento de embolias pulmonares ou sistêmicas comparados a pacientes sem a doença de Chagas. Isso pode ser explicado pela associação de fatores como estase venosa, baixo débito cardíaco, dilatação da câmara cardíaca e fibrilação atrial (Simões et al, 2018). Em pacientes com maior risco como, por exemplo, disfunção sistólica do VE, presença de aneurisma apical, alteração primária da repolarização ventricular no ECG e idade avançada, o uso de anticoagulante oral deve ser considerado (Sousa et al, 2008).

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Abaixo, são apresentados os fármacos e os esquemas de administração de medicamentos utilizados no tratamento etiológico, bem como complicações cardíacas e gastrointestinais.  
Em adultos, o benznidazol é usado na dose de 5 mg/kg/dia, em uma a três doses, por 60 dias (Tabela 6). Para pessoas com peso acima de 60 kg, uma alternativa é a utilização da extensão do esquema terapêutico para adequar à dosagem alvo ideal, limitando-se a dose máxima diária a 300 mg, de forma a reduzir a possibilidade de eventos adversos relacionados ao fármaco. Assim, nesses casos, pode-se usar o esquema com 300 mg de benznidazol pelo número de dias equivalente ao peso do indivíduo, limitado a 80 dias (por exemplo, uma pessoa com 70 kg poderá utilizar benznidazol 300 mg/dia por 70 dias) (Andradeet al., 2011; Diaset al., 2016).  
Em crianças, que exibem melhor tolerância, a dose utilizada é de 5 a 10 mg/kg/dia, dividida em duas tomadas diárias, por 60 dias. Há a formulação pediátrica de 12,5 mg em comprimidos solúveis, podendo ser diluída em água, suco de laranja ou leite (Dias et al., 2016).  
O nifurtimox é disponível em comprimidos de 120 mg. É utilizado na dose de 15 mg/kg/dia em crianças e na dose de 10 mg/kg/dia em adultos. O medicamento é usado em três doses diárias, por 60 dias (Tabela 6). O nifurtimox tem sido fornecido pela Secretaria de Vigilância Sanitária do Ministério da Saúde por demanda em casos específicos de resistência ou intolerância ao benzonidazol (Dias et al., 2016).  
Tabela 6. Posologia do tratamento antiparasitário na doença de Chagas  
|**Medicamento**|**Público**|**Posologia**|
|---|---|---|
|Benznidazol|Adulto|(1) 5 mg/kg/dia, 1 a 3x ao dia, por 60 dias, ou|
|Comprimidos de 12,5 mg||(2) 300 mg/dia, 2 a 3x ao dia, pelo número de|
|(pediátrico) e de 100 mg||dias equivalente ao peso do indivíduo (máximo|
|(adulto)||80 dias)|
||Pediátrico|5 a 10 mg/kg/dia, 2x ao dia, por 60 dias.<br>Esquemas sugeridos:<br>•<br>Entre 2,5 e 5 kg: 1 comprimido (12,5 mg),<br>2x ao dia|
|||•<br>Entre 5 e 10 kg: 2 comprimidos (25 mg), 2x<br>ao dia|
|||•<br>Entre 10 e 15 kg: 3 comprimidos (37,5<br>mg), 3x ao dia|
|Nifurtimox|Adulto|10 mg/kg/dia, 3x ao dia, por 60 dias|
|Comprimidos de 120 mg|Pediátrico|15 mg/kg/dia, 3x ao dia, por 60 dias|  
As tabelas 7 e 8 mostram os fármacos para tratamento de megaesôfago chagásico e de cardiopatia chagásica, assim como seu esquema de administração (Andrade et al., 2011; Dias et al., 2016).  
Tabela 7. Tratamento de megaesôfago chagásico  
|**Medicamento**|**Posologia usual**|**Principais cuidados**|
|---|---|---|
|Nifedipina|10 mg, 30 min antes da<br>refeição|Não deve ser utilizada em pacientes<br>com cardiopatia grave devido ao risco<br>de hipotensão e retenção hidrossalina|
|Dinitrato de isossorbida|5 mg, 15 min antes da<br>refeição|Pode causar cefaleia, hipotensão|  
Tabela 8. Tratamento de cardiopatia chagásica  
|**Medicamento**|**Posologia usual**|**Principais cuidados**|
|---|---|---|
|||A utilização de amiodarona pode causar|
|||alterações na função tireoidiana,|
|Amiodarona|200 mg/dia|prolongamento do QT, taquicardia|
|||ventricular do tipo_torsades de pointes_e|
|||fibrose pulmonar|

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Casos clinicamente estáveis, em uso de benznidazol, podem ser atendidos por profissionais no âmbito da APS. Os casos devem ser avaliados periodicamente durante o tratamento, com especial atenção aos eventos adversos. Em casos de eventos adversos graves e progressão da doença, pode ser considerada a referência para serviços especializados.  
O tratamento com nifurtimox, quando recomendado, deve ser realizado em serviços especializados, fora do âmbito da APS, com avaliação periódica durante o tratamento e atenção especial aos eventos adversos. Da mesma forma, a atenção às pessoas com manifestações graves da doença de Chagas (por exemplo, fase aguda apresentando miocardite ou encefalite, ou cardiopatia avançada) deve ser realizada fora do contexto da APS.  
A pessoa afetada pela doença de Chagas em uso de amiodarona necessita de avaliação clínica regular. São aconselhadas consultas no mínimo a cada três (3) meses no primeiro ano e a cada seis (6) meses nos anos seguintes.  
É importante salientar que indivíduos com doença de Chagas na forma crônica devem realizar seguimento longitudinal, com avaliações periódicas para realização de exames complementares, como ECG, independentemente do tratamento etiológico ser realizado ou não.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Não há evidências sobre a necessidade de realizar controle sorológico pós-tratamento ou retratamento após curso terapêutico completo. Alguns estudos sugerem o uso da PCR para controle  
da resposta clínica, contudo, seu uso não está disponível no SUS estando tal prática restrita a atividades de pesquisa.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
O rastreamento visa identificar, na população geral, indivíduos assintomáticos ou com síndromes clínicas inespecíficas que apresentam a condição de interesse, tomando como referência o impacto individual relativo ao tratamento etiológico da doença de Chagas. Recomenda-se o rastreamento de pessoas coma presença de fatores associados ao maior risco de exposição e infecção por _T. cruzi_ , como mostra o Quadro 3. Entre eles, destacam-se ser procedente ou residente em área endêmica (incluindo migrantes), ser habitante de áreas rurais (em especial onde o vetor já foi identificado), ser familiar de pessoas com doença de Chagas conhecida ou ter realizado transfusão de sangue ou hemocomponentes antes de 1992, momento no qual os testes de triagem foram incorporados aos serviços de hemoterapia.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: Geral -->
Rastrear:  
- Indivíduos com fatores de risco;  
- Gestantes sem sorologia prévia, com fatores de risco.  
- Fatores de risco:  
- Ter residido na infância ou residir em área com relato de presença de vetor transmissor da doença de Chagas ou ainda com reservatórios animais (silvestres ou domésticos) com registro de infecção por _T. cruzi_ ;  
- Ter residido ou residir em habitação onde possa ter ocorrido o convívio com vetor transmissor (principalmente casas de estuque, taipa, sapê, pau-a-pique, madeira, entre outros modos de construção que permitam a colonização por triatomíneos);  
- Residir ou ser procedente de área com registro de transmissão ativa de _T. cruzi_ ou com histórico epidemiológico sugestivo de ocorrência da transmissão da doença no passado;  
- Ter realizado transfusão de sangue ou hemocomponentes antes de 1992;  
- Ter familiares ou pessoas do convívio habitual ou rede social que tenham diagnóstico de doença de Chagas, em especial ser filho(a) de mãe com infecção comprovada por _T. cruzi_ .  
Devido à baixa prevalência em várias áreas do país e a necessidade de realizar um alto número de testes para detectar um caso da doença de Chagas, não deve ser realizado rastreamento em indivíduos sem a presença de fatores associados a risco clínico-epidemiológico de possuir a doença.  
As presentes recomendações se aplicam à população geral, assintomática. Deve-se ressaltar que essa recomendação não se aplica a imunodeprimidos, com potencial de aumento de parasitemia em função das comorbidades e medicações imunossupressoras em uso; por isso, o rastreamento deve ser realizado em qualquer idade em população que tenha risco de reativação por imunossupressão. Nessas situações, em que as pessoas possuem maior risco de desenvolver complicações relacionadas, o benefício do rastreamento deve ser ainda mais significativo.  
Em gestantes, sugere-se o rastreamento pré-natal em casos de alto risco de doença de Chagas. Em gestantes com baixo risco, o impacto clínico é incerto, não sendo recomendada essa prática de rotina dentro dos cenários atuais. A testagem da gestante deve, idealmente, ser associada aos exames já realizados no pré-natal, como HIV, sífilis e hepatite B, especialmente em áreas endêmicas (MINISTÉRIO DA SAÚDE, 2014), em conformidade com diretrizes internacionais da Organização PanAmericana da Saúde (OPAS) e da OMS (PAHO, 2017). Adicionalmente, a realização de teste de rastreamento para doença de Chagas em mulheres em idade fértil com sorologia prévia negativa, salvo forte suspeição de infecção adquirida no período desde a última testagem, não é necessária. Este PCDT não aborda o rastreamento da doença de Chagas em situações especiais como gestantes infectadas por HIV ou outros fatores de imunossupressão. Nessas gestações, há maior risco de transmissão congênita, e o benefício do rastreamento é potencialmente maior.  
Por sua vez, a testagem neonatal deve ser realizada de rotina em crianças com suspeita de transmissão congênita. Crianças com testagem positiva ou com sintomatologia da doença devem ser tratadas conforme as recomendações deste PCDT. Por se tratar de infecção aguda, devem ser realizados exames parasitológicos diretos; porém, como podem ocorrer testes falso-negativos, devese colher mais de uma amostra. Com relação aos testes sorológicos, testes falso-positivos podem ocorrer no período neonatal devido aos anticorpos maternos circulantes. Há dúvidas sobre como proceder com relação à retestagem nesses casos e em qual período pós-nascimento os testes devem ser repetidos. Ao se realizar testagem no neonato devido ao risco de transmissão congênita, há chance de resultado sorológico reagente (ou positivo) devido à presença de anticorpos maternos nesse período, ou seja, anticorpos passivos. Se uma titularidade alta persistir após os 9 meses de idade, isso é forte indicativo de transmissão congênita. Para proceder à investigação da transmissão  
congênita, deve-se considerar pelo menos a existência de duas reações positivas, conforme a Figura 4.  
Crianças não testadas aos 9 meses devem realizar a testagem após esse período, visto que a eficácia e a segurança do tratamento são semelhantes nos primeiros anos de vida e a negativação sorológica é superior a 95% (Chippauxet al., 2010; Carlieret al., 2011; Gonzalez-Tomeet al., 2013). Se houver dificuldade de seguimento das gestantes, como no caso das que residem em locais de difícil acesso e apresentam baixa aderência ao atendimento pós-natal, pode-se realizar a testagem mais precocemente, entre 6 e 9 meses de idade. Nesses casos, a taxa de falso-positivos é maior, visto que ainda pode haver anticorpos maternos; porém, essa estratégia pode reduzir o risco de não tratamento de crianças infectadas por perda de acompanhamento (Dias et al., 2016).  
Novos testes vêm sendo propostos a fim de detectar mais precocemente a ocorrência de transmissão congênita, como _shed acute phase antigen_ (SAPA) e PCR. Contudo, não são métodos recomendados na rotina, em função dos altos custos e dificuldades na padronização das técnicas.  
Figura 4. Fluxograma para **a** bordagem da gestante com alto risco para **i** nfecção por _T. cruzi_  
aSeguir o fluxograma de recomendação do diagnóstico da infecção por _T. cruzi_ (ver seção referente ao di **a** gnóstico laboratorial da infecção por _T. cruzi_ ). b Testes parasitológicos e **s** tão recomendados nos primeiros dias de vida da criança c Após o nono mês de vida, utilizar testes sorológicos para o diagnóstico da infecç **ã** o

---

<!-- METADADOS: doenca: Doença de Chagas | secao: **10 - GESTÃO E CONTROLE** -->
A doença de Chagas é uma situação relativamente comum no Brasil. Os casos, em sua maioria, apresentam quadro clínico n **ã** o grave, devendo ser acompanhados, majorit **a** riamente, no âmbito da APS. Entende-se que també **m** é função da equipe de APS o tratamento etiológico com benznidazol, quando indicado, para casos de doença de Chagas aguda ou crônica não gra **v** e. A atenção em serviço  
especializado deve ser realizada principalmente em casos com doença aguda grave, pessoas com cardiopatia chagásica grave, pessoas com doença digestiva candidatas a terapia específica, pessoas submetidas a transplantes ou com coinfecção pelo HIV, gestantes com cardiopatia ou com doença de Chagas aguda, ou pessoas candidatas ao tratamento com nifurtimox (Tabela 9).  
Tabela 9. Níveis de atenção à saúde para casos com doença de Chagas e referenciamento para serviço especializado  
|Atenção|• Fase aguda não grave;|
|---|---|
|primária<br>à<br>saúde (APS)|• Fase crônica indeterminada;<br>• Fase crônica cardíaca, digestiva ou cardiodigestiva, com doença estável e<br>não grave;<br>• Gestantes com doença de Chagas em fase crônica, sem comorbidades.|
|Serviço<br>especializado*|• Fase aguda, caso grave (por exemplo, suspeita de encefalite ou<br>miocardite);<br>• Gestantes com doença de Chagas em fase aguda;<br>• Gestantes com cardiopatia;<br>• Cardiopatia chagásica com:<br>o Arritmias graves (TVS, TVNS com alto risco de morte súbita);<br>o Candidatos a MP/CDI;<br>o Insuficiência cardíaca;<br>o Casos com suspeita de eventos tromboembólicos ou risco elevado para<br>os mesmos (por exemplo, AIT, AVC, tromboembolismo pulmonar);<br>• Casos com acometimento digestivo candidatos a procedimentos<br>especializados (por exemplo, toxina botulínica, dilatação pneumática ou<br>cirurgia);<br>• Casos infectados por HIV;<br>• Pessoas submetidas a transplantes;<br>• Candidatos ao tratamento com nifurtimox (independentemente da fase<br>da doença).|  
* Nesses casos, a APS é responsável pelo manejo desses casos e pela atenção a demais problemas de saúde. TVS: taquicardia ventricular sustentada; TVNS: taquicardia ventricular não sustentada; MP: marca-passo; CDI: cardiodesfibrilador implantável; AIT: acidente isquêmico transitório; AVC: acidente vascular cerebral; HIV: vírus da imunodeficiência humana.  
Na Tabela 10, são apresentadas as recomendações para o gestor em saúde no que tange à disponibilização de insumos e ações em saúde relacionadas à presente diretriz.  
Tabela 10. Recomendações para o gestor em saúde para disponibilização de tecnologias na atenção à doença de Chagas  
|**I – Diagnóstico da doença de Cha**|**gas**|
|---|---|
|**Recomendações para**<br>**disponibilização de tecnologias**|**Considerações**|
|**Recomendação 1. Deverão ser**<br>**disponibilizados pelo menos**<br>**dois testes sorológicos**<br>**baseados em princípios**<br>**distintos ou com diferentes**<br>**preparações antigênicas, como**<br>**ELISA, IFI, HAI, CLIA ou WB, para**<br>**o diagnóstico da doença de**<br>**Chagas na fase crônica.**<br>**II – Tratamento etiológico da doe**|Não é necessário ofertar os cinco testes sorológicos<br>descritos. Os testes devem ser escolhidos com base em<br>fatores como custo e capacidade instalada para a sua<br>realização. É importante informar que estão disponíveis<br>testes comerciais com diferentes padrões de qualidade,<br>devendo-se priorizar testes com maior sensibilidade e<br>especificidade. Vale ressaltar que testes como WB (TESA<br>_blot_) e CLIA possuem custos mais elevados do que os<br>demais, não sendo necessária a sua oferta caso haja<br>disponibilidade de outros dois testes com princípios<br>distintos ou com diferentes preparações antigênicas, uma<br>vez que essa conduta não implicará prejuízo potencial à<br>população.<br>**nça de Chagas**|
|**Recomendações para**<br>**disponibilização de tecnologias**|**Considerações**|
|**Recomendação 2: Deverá ser**<br>**disponibilizado benznidazol**<br>**para o tratamento da doença de**<br>**Chagas nas fases aguda e**<br>**crônica.**|O benznidazol deve estar acessível tanto na rede de<br>serviços da atenção primária à saúde quanto em serviços<br>especializados. Para a liberação do medicamento, não há<br>necessidade de comprovação sorológica em pessoas com<br>suspeita clínica de doença na fase aguda; além disso, para<br>casos com doença na fase crônica, não há necessidade de<br>apresentação de exames complementares como ECG e<br>ecocardiografia.<br>A obtenção do nifurtimox pelo governo é feita em forma de<br>doação, por meio de acordo entre OMS e fabricante. O<br>medicamento não está disponível para compra direta tanto|  
|**III – Tratamento etiológico da do**|pelas pessoas afetadas quanto pelo ente público. O<br>nifurtimox possui uso limitado, devendo ser disponibilizado<br>em centros de referência. Ressalta-se a importância de<br>desenvolvimento de ações de farmacovigilância.<br>**ença de Chagas em situações especiais**|
|---|---|
|**Recomendações para**|**Considerações**|
|**disponibilização de tecnologias**||
|**Recomendação 3: Deverá ser**<br>**disponibilizado acesso à**<br>**amiodarona para o tratamento**<br>**da doença de Chagas crônica**<br>**com cardiopatia chagásica.**<br>**IV – Rastreamento da doença de**|A<br>amiodarona<br>deve<br>estar<br>acessível<br>em<br>serviços<br>especializados, responsáveis pela atenção a casos com<br>cardiopatia chagásica.<br>**Chagas**|
|**Recomendações para**|**Considerações**|
|**disponibilização de tecnologias**||
|**Recomendação 4: Deverão ser**<br>**avaliadas estratégias de**<br>**rastreamento para doença de**|A implementação em nível populacional de programas de<br>rastreamento sorológico para infecção por_T. cruzi_deve ser<br>avaliada dentro de cada contexto clínico-epidemiológico|
|**Chagas levando em**<br>**consideração fatores como**<br>**epidemiologia local e**<br>**prioridades em saúde.**|debatido ao longo deste PCDT. Devem ser levados em<br>consideração, para o processo decisório, fatores como<br>custos, epidemiologia local e prioridades em saúde pública.|  
ELISA: ensaio de imunoabsorção enzimática; IFI: imunofluorescência indireta; HAI: hemaglutinação indireta; WB: Western blot; CLIA: quimiluminescência.; PCDT: Protocolo Clínico e Diretrizes Terapêuticas; ECG: eletrocardiograma; OMS: Organização Mundial da Saúde; TESA blot: trypomastigote excreted-secreted antigen blot

---

<!-- METADADOS: doenca: Doença de Chagas | secao: **10 - GESTÃO E CONTROLE** -->
> a Em casos de intolerância ou onde o benzonidazol não for disponível, p **o** de-se utilizar nifurtimox.

---

<!-- METADADOS: doenca: Doença de Chagas | secao: **10 - GESTÃO E CONTROLE** -->
ACQUATELLA, H. Echocardiography in Chagas heart disease. **Circulation,** v. 115, n. 9, p. 1124-31, 20070306 DCOM- 20070327 2007.  
ANDRADE, J. P. D. et al. I Diretriz Latino-Americana para o diagnóstico e tratamento da cardiopatia chagásica: resumo executivo. **Arquivos Brasileiros de Cardiologia,** v. 96, p. 434-442, 2011. ISSN 0066-782X.  
ARAUJO, P.F. et al., Sexual transmission of American trypanosomiasis in humans: a new potential pandemic route for Chagas parasites. **Mem Inst Oswaldo Cruz** . 2017 Jun;112(6):437-446.  
BERN, C. Chagas' Disease. **N Engl J Med,** v. 30, n. 373, p. 456-66, 20150730 DCOM20150814 2015.  
BERN, C. et al. Trypanosoma cruzi and Chagas' Disease in the United States. **Clin Microbiol Rev,** v. 24, n. 4, p. 655-81, Oct 2011. ISSN 0893-8512.  
BERN, Caryn. Antitrypanosomal Therapy for Chronic Chagas' Disease. New England Journal Of Medicine, [s.l.], v. 364, n. 26, p.2527-2534, 30 jun. 2011. **New England Journal of Medicine (NEJM/MMS)** . http://dx.doi.org/10.1056/nejmct1014204. (b)  
BERN, C. et al. Evaluation and treatment of chagas disease in the United States: a systematic review. **Jama,** v. 298, n. 18, p. 2171-81, Nov 14 2007. ISSN 0098-7484.  
BRASIL. **Guia para vigilância, prevenção, controle e manejo clínico da doença de Chagas aguda transmitida por alimentos** . – Rio de Janeiro: PANAFTOSA-VP/OPAS/OMS, 2009. 92 p.: il. (Serie de Manuais Técnicos, 12).  
BRASIL. **Recomendações sobre o diagnóstico parasitológico, sorológico e molecular para confirmação da doença de Chagas aguda e crônica. Informe Técnico** . <u>Rev Patol Trop Vol. 42 (4): . . 2013: Ministério da Saúde. Secretaria de Vigilância em Saúde. 42</u> **:** 475-478 p. 2013.  
BRASIL. **Guia de Vigilância em Saúde** . ecretaria de Vigilância em Saúde, CoordenaçãoGeral de Desenvolvimento da Epidemiologia em Serviços. C. G. D. D. D. E. E. Brasilia: Ministério da Saúde. **:** 773 p. p. 2016.  
BRASIL. **Guia de Vigilância em Saúde** . Brasília: MInistério da Saúde, Secretaria de Vigilância em Saúde, Coordenação-Geral de Desenvolvimento da Epidemiologia em Serviços,2017.  
CARLIER, Y. et al. Congenital Chagas disease: recommendations for diagnosis, treatment and control of newborns, siblings and pregnant women. **PLoS Negl Trop Dis,** v. 5, n. 10, p. e1250, Oct 2011. ISSN 1935-2727.  
37  
CHIPPAUX, J. P. et al. Antibody drop in newborns congenitally infected by Trypanosoma cruzi treated with benznidazole. **Trop Med Int Health,** v. 15, n. 1, p. 87-93, Jan 2010. ISSN 1360-2276.  
COURA, J. R. The main sceneries of Chagas disease transmission. The vectors, blood and oral transmissions - A comprehensive review. **Memórias do Instituto Oswaldo Cruz,** v. 110, p. 277-282, 2015. ISSN 0074-0276.  
DIAS, J. C. P. et al. II Consenso Brasileiro em Doença de Chagas, 2015. **Epidemiologia e Serviços de Saúde,** v. 25, p. 7-86, 2016. ISSN 1679-4974.  
FABBRO, D. L. et al. Trypanocide treatment of women infected with Trypanosoma cruzi and its effect on preventing congenital Chagas. **PLoS Negl Trop Dis,** v. 8, n. 11, p. e3312, Nov 2014. ISSN 1935-2727.  
GONZALEZ-TOME, M. I. et al. [Recommendations for the diagnosis, treatment and follow-up of the pregnant woman and child with Chagas disease. Sociedad Espanola de Infectologia Pediatrica. Sociedad de Enfermedades Infecciosas y Microbiologia Clinica. Sociedad Espanola de Ginecologia y Obstetricia]. **Enferm Infecc Microbiol Clin,** v. 31, n. 8, p. 535-42, Oct 2013. ISSN 0213-005x.  
<mark>GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. McMaster University, 2015 (developed by Evidence Prime, Inc.). Available from gradepro.org. Acesso em: May.</mark>  
HOTEZ, P. J.; FUJIWARA, R. T. Brazil's neglected tropical diseases: an overview and a report card. **Microbes Infect,** v. 16, n. 8, p. 601-6, Aug 2014. ISSN 1769-714X (Electronic)1286-4579 (Linking).  
MARTINS-MELO, Francisco Rogerlândio et al. Prevalence of Chagas disease in Brazil: A systematic review and meta-analysis. **Acta Tropica** , v. 130, p.167-174, fev. 2014.  
MARTINS-MELO, F. R. et al. Prevalence of Chagas disease in pregnant women and congenital transmission of Trypanosoma cruzi in Brazil: a systematic review and metaanalysis. **Trop Med Int Health,** v. 19, n. 8, p. 943-57, Aug 2014. ISSN 1365-3156 (Electronic) 1360-2276 (Linking).  
MARTINS-MELO, F. R. et al. Mortality from neglected tropical diseases in Brazil, 20002011. **Bull World Health Organ,** v. 94, n. 2, p. 103-10, Feb 01 2016. ISSN 1564-0604 (Electronic)0042-9686 (Linking).  
MINISTÉRIO DA SAÚDE. **Caderneta da Gestante** . Brasília 2014.  
MORILLO, C. A. et al. Benznidazole and Posaconazole in Eliminating Parasites in Asymptomatic T. Cruzi Carriers: The STOP-CHAGAS Trial. **J Am Coll Cardiol,** v. 69, n. 8, p. 939-947, Feb 28 2017. ISSN 1558-3597 (Electronic)0735-1097 (Linking).  
MOSCATELLI, G. et al. Prevention of congenital Chagas through treatment of girls and women of childbearing age. **Mem Inst Oswaldo Cruz,** v. 110, n. 4, p. 507-9, Jun 2015. ISSN 0074-0276.  
38  
Pan American Health Organization. EMTCT Plus. Framework for elimination of mothertochild transmission of HIV, Syphilis, Hepatitis B, and Chagas. Washington, D.C.: PAHO; 2017  
PEREZ-MOLINA, J. A. et al. Guidelines on the treatment of chronic coinfection by Trypanosoma cruzi and HIV outside endemic areas. **HIV Clin Trials,** v. 12, n. 6, p. 287-98, Nov-Dec 2011. ISSN 1528-4336 (Print)1528-4336.  
PINAZO, María Jesús et al. Diagnosis, management and treatment of chronic Chagas’ gastrointestinal disease in areas where Trypanosoma cruzi infection is not endemic. **Gastroenterología y Hepatología** , [s.l.], v. 33, n. 3, p.191-200, mar. 2010. Elsevier BV. http://dx.doi.org/10.1016/j.gastrohep.2009.07.009.  
PINHEIRO, Eloan et al . Chagas disease: review of needs, neglect, and obstacles to treatment access in Latin America. **Rev. Soc. Bras. Med. Trop** .,  Uberaba ,  v. 50, n. 3, p. 296-300,  June  2017  
RAMÍREZ J. C. et al.,. First external quality assurance program for bloodstream Real-Time PCR monitoring of treatment response in clinical trials of Chagas disease. **PLoS One.** 2017 Nov 27;12(11):e0188550. doi: 10.1371/journal.pone.0188550. eCollection 2017.  
RASSI, A; RASSI, A; MARIN-NETO, José Antonio. Chagas disease. **The Lancet** , [s.l.], v. 375, n. 9723, p.1388-1402, abr. 2010. Elsevier BV. http://dx.doi.org/10.1016/s01406736(10)60061-x.  
RASSI, A; RASSI, SG; RASSI, A. Morte Súbita na Doença de Chagas. **Arq Bras Cardio** l 2001; 76: 77-87.  
RASSI, A., JR.; RASSI, A.; MARCONDES DE REZENDE, J. American trypanosomiasis (Chagas disease). **Infect Dis Clin North Am,** v. 26, n. 2, p. 275-91, Jun 2012. ISSN 0891-5520.  
RIOS, A et al. Can sexual transmission support the enzootic cycle of Trypanosoma cruzi? **Mem Inst Oswaldo Cruz** . 2018 Jan;113(1):3-8. doi: 10.1590/0074-02760170025  
RODRIGUEZ-GUARDADO, A. et al. Screening for Chagas' disease in HIV-positive immigrants from endemic areas. **Epidemiol Infect,** v. 139, n. 4, p. 539-43, Apr 2011. ISSN 0950-2688.  
SALES JUNIOR P.A. et al. Experimental and Clinical Treatment of Chagas Disease: A Review. **Am J Trop Med Hyg.** 2017 Nov;97(5):1289-1303. doi: 10.4269/ajtmh.16-0761. Epub 2017 Oct 10.  
SARTORI, A. M. et al. Manifestations of Chagas disease (American trypanosomiasis) in patients with HIV/AIDS. **Ann Trop Med Parasitol,** v. 101, n. 1, p. 31-50, Jan 2007. ISSN 0003-4983 (Print)0003-4983 (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/17244408>.  
<mark>SCHÜNEMANN, H. J.  et al. Guidelines 2.0: systematic development of a comprehensive checklist for a successful guideline enterprise.</mark> **<mark>CMAJ : Canadian Medical Association Journal,</mark>** <mark>v. 186, n. 3, p. E123-E142,  2014. ISSN 0820-39461488-2329.</mark>  
39  
SILVEIRA, A. C. Os novos desafios e perspectivas futuras do controle. **Revista da Sociedade Brasileira de Medicina Tropical,** v. 44, p. 122-124, 2011. ISSN 0037-8682.  
SIMOES, Marcus Vinicius et al . Chagas Disease Cardiomyopathy. **Int. J. Cardiovasc. Sci** ., Rio de Janeiro,  v. 31, n. 2, p. 173-189,  Apr.  2018. ISSN 2359-4802.  
SOUSA A.S. et al Prevention strategies of cardioembolic ischemic Stroke in Chagas' disease. **Arq. Bras. Cardiol.,** São Paulo ,  v. 91, n. 5, p. 306-310,  Nov.  2008. ISSN 0066782X.  
VAIDIAN, A. K.; WEISS, L. M.; TANOWITZ, H. B. Chagas' disease and AIDS. **Kinetoplastid Biol Dis,** v. 3, n. 1, p. 2, May 13 2004. ISSN 1475-9292 (Print)1475-9292.  
VILLAR, J. C. et al. Trypanocidal drugs for chronic asymptomatic Trypanosoma cruzi infection. **Cochrane Database Syst Rev** , n. 5, p. Cd003463, May 27 2014. ISSN 13616137.  
VILLELA, M. M. et al. Avaliação do Programa de Controle da Doença de Chagas em relação à presença de Panstrongylus megistus na região centro-oeste do Estado de Minas Gerais, Brasil. **Cadernos de Saúde Pública,** v. 25, p. 907-917, 2009. ISSN 0102311X.  
VIOTTI, R et al. Treatment of chronic Chagas' disease with benznidazole: clinical and serologic evolution of patients with long-term follow-up. Am Heart J, v. 1, n. 127, p.151162, jan. 1994.  
VIOTTI, R.   et al. Long-term cardiac outcomes of treating chronic Chagas disease with benznidazole versus no treatment: a nonrandomized trial. Ann Intern Med, v. 144, n. 10, p. 724-34, May 16 2006.  
WHO. Chagas disease in Latin America: an epidemiological update based on 2010 estimates. **Wkly Epidemiol Rec,** v. 90, n. 6, p. 33-43, Feb 06 2015. ISSN 0049-8114 (Print)0049-8114 (Linking).  
WHO Expert Committee. Control of Chagas disease. World Health Organ Tech Rep Ser, v. 905, p. i-vi, 1-109, back cover, 2002. ISSN 0512-3054 (Print)0512-3054.  
WORLD HEALTH ORGANIZATION. **Handbook for Guideline development.** Disponível em: <http://apps.who.int/iris/handle/10665/145714>. 2014. Acesso em: 2017.  
40  
#### **ANEXO 1**  
#### PÚBLICO ALVO, CENÁRIO E POPULAÇÃO ALVO DA DIRETRIZ  
Esta diretriz tem como público alvo os profissionais de saúde envolvidos na atenção a pessoas com doença de Chagas, em especial médicos de família e de comunidade, internistas, cardiologistas, obstetras, infectologistas, gastroenterologistas e enfermeiros que atuam na atenção primária à saúde (APS). O cenário base para o documento é o Sistema Único de Saúde (SUS) brasileiro; contudo, as recomendações são aplicáveis à saúde suplementar e também a outros países. Servem de base também para a construção de agendas pelos movimentos sociais existentes.  
Pessoas afetadas pela doença de Chagas, em suas diferentes formas (incluindo gestantes, neonatos e imunossuprimidos), bem como familiares e outras pessoas em contexto de vulnerabilidade para a doença, são a população alvo destas recomendações. Vulnerabilidade aqui é entendida como integrando dimensões individuais, sociais e programáticas (relativa aos serviços de saúde).  
#### METODOLOGIA PARA ELABORAÇÃO DESTA DIRETRIZ  
O desenvolvimento desta diretriz seguiu o processo preconizado pelo Manual de Desenvolvimento de Diretrizes da Organização Mundial da Saúde (WHO, 2016) e pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde (Brasil, 2016). A diretriz foi desenvolvida com base na metodologia GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), seguindo os passos descritos no GIN-McMaster _Guideline Development Checklist_ (Grade, 2017; Schünemann _et al._ , 2014).  
O grupo desenvolvedor desta diretriz foi composto pelo grupo coordenador da diretriz e pelo grupo de elaboração das recomendações. O grupo coordenador foi composto por profissionais do Hospital Moinhos de Vento com experiência no desenvolvimento de diretrizes clínicoassistenciais, revisões sistemáticas e avaliações de tecnologias em saúde, sendo seu principal papel coordenar as atividades de elaboração da diretriz e desenvolver os materiais para dar subsídio ao processo de tomada de decisão. O grupo de elaboração incluiu médicos especialistas e generalistas, demais profissionais de saúde, representante de pessoas afetadas pela doença e gestores em saúde, de diferentes estados brasileiros, combinando experiência clínica, metodológica, de gestão pública e de serviços de saúde, sendo responsável pela elaboração das questões da diretriz e das suas respectivas recomendações, além de revisão e aprovação do documento final.  
#### **Obtenção de evidências para efetividade**  
Para elaborar esta diretriz foram realizadas revisões sistemáticas (registro no PROSPERO: <mark>CRD42016050608, CRD42017056765, CRD42017055143), nas quais d</mark> ois revisores avaliaram independentemente os títulos e resumos dos artigos. Dúvidas foram discutidas com um terceiro revisor. Aqueles artigos que se enquadraram nos critérios de inclusão de cada revisão foram lidos na íntegra e os artigos elegíveis foram incluídos. A extração dos artigos em cada uma das revisões realizadas foi conduzida de forma independente, utilizando, para extração dos dados, uma planilha previamente definida e validada pelo grupo coordenador. Os dados  
41  
extraídos foram sumarizados e, quando possível, foram realizadas metanálises para combinar os resultados de cada desfecho. A evidência foi sintetizada narrativamente e resumida usando estatísticas descritivas (frequências, porcentagens). Quando possível, foi realizada metanálise utilizando o software R (versão 3.2.3), pacote _meta_ . Foram aplicados os modelos de efeito fixo e efeitos randômicos, optando-se pelo modelo adequado à heterogeneidade metodológica entre os estudos. A heterogeneidade entre os estudos foi avaliada utilizando a estatística Q e o teste I-quadrado. Foram realizadas análises de subgrupos quando houve número suficiente de estudos identificados.  
1. Revisão sistemática sobre tratamento etiológico (benznidazol ou nifurtimox) da doença de Chagas. A busca pela literatura foi realizada nas bases de dados EMBASE, LILACS, <mark>MEDLINE (PubMed),</mark> CENTRAL e clinicaltrials.gov. Foram incluídas ainda, bases de dados de literatura cinza e outras fontes de literatura, como resumos de congressos. Entre os desfechos avaliados estão: mortalidade, hospitalização, desenvolvimento ou progressão de cardiopatia, desenvolvimento ou progressão de complicações gastrointestinais, reativação da doença, soronegativação, efeitos adversos, teratogenicidade dos fármacos e qualidade de vida. Não houve restrição quanto à idade dos indivíduos incluídos.  
2. Revisão sistemática sobre a acurácia de testes diagnósticos da doença de Chagas. A busca pela literatura foi realizada nas bases de dados EMBASE, LILACS, <mark>MEDLINE (PubMed),</mark> CENTRAL e clinicaltrials.gov. A revisão incluiu estudos que avaliassem os seguintes testes diagnósticos: teste imunoenzimático ( _e_ _<mark>nzyme-linked immunosorbent assay</mark>_ <mark>,</mark> ELISA), imunofluorescência indireta ( _indirect immunofluorescence,_ IFI), hemaglutinação indireta ( _indirect haemaglutination assay,_ HAI), _Western blotting_ (WB), reação em cadeia da polimerase ( _polymerase chain reaction,_ PCR), quimiluminescência ( _chemiluminescence immunoassay, CLIA), serologic test using shed acute phase antigen_ (SAPA) e testes rápidos. Entre os desfechos avaliados estão: acurácia, sensibilidade, especificidade, validade do teste. Não houve restrição quanto à idade dos indivíduos incluídos.  
3. Revisão sistemática sobre o uso de nifedipina e dinitrato de isossorbida no tratamento de pessoas com megaesôfago chagásico sintomático.A busca pela literatura foi realizada nas bases de dados <mark>MEDLINE (PubMed), EMBASE, LILACS e</mark> clinicaltrials.gov. Foram incluídos estudos avaliando adultos (>18 anos) com doença gastrointestinal devido à doença de Chagas. Entre os desfechos avaliados estão: melhora dos sintomas, incluindo avaliação da pressão esofágica, redução da disfagia, esvaziamento gastrointestinal e refluxo.  
4. Revisão sistemática sobre o uso de amiodarona no tratamento de pessoas com cardiopatia chagásica. A busca pela literatura foi realizada nas bases de dados <mark>MEDLINE (PubMed), EMBASE, LILACS e c</mark> linicaltrials.gov. Foram incluídos estudos avaliando adultos (>18 anos) com cardiomiopatia chagásica. Entre os desfechos avaliados estão: arritmia, mortalidade e efeitos adversos da medicação.  
#### **Estratégias de busca das revisões sistemáticas**  
Abaixo a estratégia de busca realizada no Pubmed (Embase). Estas buscas foram traduzidas nas demais bases de dados.  
#### **1. Revisão sistemática sobre tratamento etiológico (benznidazol ou nifurtimox) da doença de Chagas**  
1. "Trypanosoma cruzi"[Title/Abstract]  
2. trypanosoma cruzi[MeSH Terms]  
42  
3. "chagas disease"[Title/Abstract]  
4. chagas disease [MeSH Terms]  
5. #1 or #2 or #3 OR #4 OR #5  
6. Benzonidazole [Supplementary Concept]  
7. benznidazole*[Title/Abstract]  
8. Nifurtimox[Mesh]  
9. nifurtimox*[Title/Abstract]  
10. Triazoles[Mesh] 11. Triazoles*[Title/Abstract]  
12. Itraconazole*[Title/Abstract]  
13. Itraconazole[MeSH]  
14. Fluconazole*[Title/Abstract]  
15. Fluconazole [MeSH Terms]  
16. Allopurinol[Mesh]  
17. Allopurinol*[Title/Abstract]  
18. "Chagas Disease/drug therapy"[Mesh]  
19. Therapeutics[Mesh]  
20. Treatment*  
21. Therapy  
22. Therapies  
23. OR/6-22  
24. Epidemiologic studies [mesh]  
25. “Epidemiologic studies” OR “Epidemiologic study” [Title/Abstract]  
26. cohort studies [mesh]  
27. "cohort study" OR “cohort studies”  
28. "Cohort analysis”  
29. "Follow up"  
30. "observational study" OR “observational studies” [Title/Abstract]  
31. Longitudinal  
32. Retrospective  
33. Prospective 34. OR/24-33  
35. Randomized Controlled Trials[mesh]  
36. "Randomized Controlled Trials" OR "Randomized Controlled Trial"  
37. Clinical Trials as topic [mesh]  
38. "Random Allocation"  
39. Random Allocation [MeSH Terms]  
40. “Random Allocations”  
41. "randomly allocated"  
42. "Double Blind Method" OR "Double Blind Methods"  
43. Double Blind Method [MeSH Terms]  
44. "Single Blind Method" OR "Single Blind Methods"  
45. Single Blind Method [MeSH Terms]  
46. "clinical trial" OR “clinical trials”  
47. "Clinical Trial" [Publication Type]  
48. "Multicenter Study" [Publication Type]  
49. “single blind” OR “single blinded”  
50. “single mask” OR “single masked”  
51. “double blind” OR “double blinded”  
52. “double mask” OR “double masked”  
53. placebos  
43  
54. or/35-53  
55. “case report”  
56. letter  
57. “historical article”  
58. or/55-57  
59. 54 not 58  
60. 34 OR 59  
61. #5 AND #23 AND #60  
#### **2. Revisão sistemática sobre acurácia do teste diagnóstico da doença de Chagas**  
1. "Luminescent Measurements"[Mesh]  
2. "Fluorescent Antibody Technique"[Mesh]  
3. "Fluorescent Antibody Technique, Indirect"[Mesh]  
4. "CMIA"  
5. “chemiluminescent assay”  
6. "RDT"  
7. "rapid test"  
8. "Polymerase Chain Reaction"[Mesh]  
9. "PCR"  
10. "IFI"  
11. “indirect immunofluorescence assay”  
12. "Agglutination Tests"[Mesh]  
13. “HAI”  
14. "IHAI"  
15. "indirect hemagglutination assay"  
16. "ELISA"  
17. "enzyme immunoassay"  
18. "EIA"  
19. "shed acute phase antigen"  
20. "confirmatory assay"  
21. "Blotting, Western"[Mesh]  
22. "Serologic Tests"[Mesh]  
23. "High-Throughput Screening Assays"[Mesh]  
24. "Enzyme-Linked Immunosorbent Assay"[Mesh]  
25. "Chagas Disease/diagnosis"[Mesh]  
26. 1-25  
27. "Chagas Disease"[Mesh]  
28. "Trypanosoma cruzi"[Mesh]  
29. "chagas disease"  
30. 27-29  
31. Sensitivity  
32. Accuracy  
33. "Sensitivity and Specificity"[Mesh]  
34. Likelihood  
35. 31-34  
36. 26 AND 30 AND  35  
**3. Revisão sistemática sobre uso de nifedipina e isossorbida no tratamento de pacientes com megaesôfago chagásico sintomático**  
44  
1. "Chagas Disease"[Mesh]  
2. "chagas disease”  
3. "Trypanosoma cruzi"[Mesh]  
4. "Trypanosoma cruzi"  
5. 1 OR 2 OR 3 OR 4  
6. "Isosorbide"[Mesh]  
7. Isosorbide  
8. 6 OR 7  
9. 5 AND 8  
1. "Chagas Disease"[Mesh]  
2. "chagas disease”  
3. "Trypanosoma cruzi"[Mesh]  
4. "Trypanosoma cruzi"  
5. 1 OR 2 OR 3 OR 4  
6. "Nifedipine"[Mesh]  
7. "Nifedipine"  
8. 6 OR 7  
9. 5 AND 8  
#### **4. Revisão sistemática sobre uso de amiodarona no tratamento de pacientes com cardiopatia chagásica**  
1. "Chagas Disease"[Mesh]  
2. "chagas disease”  
3. "Trypanosoma cruzi"[Mesh]  
4. "Trypanosoma cruzi"  
5. 1 OR 2 OR 3 OR 4  
6. " Amiodarone"[Mesh]  
7. Amiodarone  
8. 6 OR 7  
9. 5 AND 8  
#### **Critérios de elegibilidade para as revisões sistemáticas**  
#### **1. Revisão sistemática sobre tratamento etiológico (benznidazol ou nifurtimox) da doença de Chagas**  
#### **Participantes / população**  
- Adultos (>18 anos) com a forma aguda da doença de Chagas;  
- Adultos (>18 anos) com a forma crônica cardíaca da doença de Chagas;  
- Adultos (>18 anos) com a forma crônica digestiva da doença de Chagas;  
- Adultos (>18 anos) com a forma crônica indeterminada da doença de Chagas;  
- Pacientes imunossuprimidos;  
- Crianças e adolescentes;  
- Gestantes;  
- Recém-nascidos.  
Consideramos imunossuprimidos os pacientes com infecção por HIV, receptores de transplante de órgãos ou pacientes outras causas de imunossupressão, como doenças autoimunes, tratamentos imunossupresivos e doenças linfoproliferativas. **Intervenção(s), exposição(s)**  
- Uso dos seguintes medicamentos: benznidazol, nifurtimox  
- **Comparador(s), controle(s)**  
45  
• Placebo, sem intervenção ou tratamento com outras drogas.  
#### **Desfecho(s)**  
#### **Desfechos primários**  
- Mortalidade;  
- Desenvolvimento de cardiomiopatia;  
- Progressão de cardiomiopatia. **Desfechos secundários**  
- Desenvolvimento e progressão de complicações gastrointestinais;  
- Desenvolvimento de infecções do sistema nervoso central;  
- Reativação da doença;  
- Transmissão vertical da doença;  
- Teratogenicidade;  
- Efeitos adversos e tolerância à droga;  
- Eliminação do parasita;  
- Conversão sorológica;  
- Qualidade de vida;  
• Hospitalização.  
#### **2. Revisão sistemática sobre acurácia do teste diagnóstico da doença de Chagas Participantes / população:**  
• Adultos (>18 anos) com doença de Chagas;  
- Pacientes imunossuprimidos;  
- Crianças e adolescentes;  
- Gestantes;  
- Recém-nascidos.  
Consideramos imunossuprimidos os pacientes com infecção por HIV, receptores de transplante de órgãos ou pacientes outras causas de imunossupressão, como doenças autoimunes, tratamentos imunossupresivos e doenças linfoproliferativas.  
**Intervenção(s), exposição(s)**  
- Diagnóstico de doença de Chagas utilizando alguma das seguintes metodologias:  
- <mark>Quimioluminescência (CMIA)</mark>  
- <mark>Antígenos recombinantes</mark>  
- <mark>Testes rápidos</mark>  
- <mark>PCR</mark>  
- _<mark>Western blotting</mark>_  
- <mark>Testes sorológicos (IgG, IgM)</mark>  
- <mark>Imunofluorescência indireta (IFI)</mark>  
- <mark>Ensaio de imunoaglutinação indireta (HAI)</mark>  
- <mark>Ensaio de imunoabsorção enzimática (ELISA)</mark>  
- Teste sorológico utilizando o antígeno SAPA ( _shed acute phase antigen_ <u>)</u>  
- **Comparador(s), controle(s)**  
- Algum dos testes para doença de Chagas citados acima  
**Desfecho(s)**  
- Reprodutibilidade  
- Acurácia  
- Sensibilidade  
- Especificidade  
46  
#### **3. Revisão sistemática sobre uso de nifedipina e isossorbida no tratamento de pacientes com megaesôfago chagásico sintomático**  
#### **Participantes / população:**  
- Adultos (>18 anos) com a forma crônica digestiva da doença de Chagas **Intervenção(s), exposição(s)**  
- Estudos sobre o uso de isossorbida ou nifedipina para o tratamento de sintomas gastrointestinais em pacientes com a forma crônica digestiva da doença de Chagas **Comparador(s), controle(s)**  
- Placebo, atenção usual, nenhuma intervenção ou tratamento com outras drogas **Desfecho(s)**  
#### **Desfechos primários**  
- Melhora de sintomas gastrointestinais, avaliados pela pressão do esfíncter esofágico inferior, disfagia, esvaziamento gastrointestinal e refluxo gastrointestinal.  
- **Desfechos secundários**  
- Efeitos adversos dos tratamentos.  
#### **4. Revisão sistemática sobre uso de amiodarona no tratamento de pacientes com cardiopatia chagásica**  
#### **Participantes / população:**  
- Adultos (>18 anos) com a forma crônica cardíaca da doença de Chagas; **Intervenção(s), exposição(s)**  
- Estudos avaliando o uso de amiodarona para tratar arritmia em pacientes com doença de Chagas  
#### **Comparador(s), controle(s)**  
- Placebo, atenção usual, nenhuma intervenção ou tratamento com outras drogas **Desfecho(s)**  
- Arritmia associada à doença de Chagas.  
#### **Obtenção de evidência para valores e preferências das pessoas afetadas**  
Para estimar valores e preferências de pessoas com doença de Chagas, foram aplicados instrumentos para avaliação de qualidade de vida. A coleta de dados foi realizada a partir de estudo transversal com obtenção de dados primários de casos da doença assistidos no sistema público de saúde. A amostra foi composta por adultos afetados pela doença de Chagas na fase crônica, em tratamento em unidade de atenção secundária e estratificados por tipo de comprometimento clínico da doença (crônica indiferenciada, doença cardíaca, doença digestiva e doença cardiodigestiva). Os critérios de inclusão foram: adultos (maiores de 18 anos) com diagnóstico de doença de Chagas crônica. Todos os participantes se encontravam em vigência de esquema de tratamento para algum comprometimento clínico da doença. Foram extraídos dados clínicos e demográficos de prontuários e aplicados os instrumentos de qualidade de vida _12-item Short Form Health Survey_ (SF-12) e _EuroQol-five-dimensional questionnaire-three-level version_ (EQ-5D-3L) em entrevistas presenciais. Escores de utilidade foram obtidos a partir dos dados extraídos do EQ-5D, e dados de qualidade de vida genérica descritiva foram derivados do SF-12. Os questionários são autoaplicáveis e foram respondidos pelas próprias pessoas afetadas com orientação de uma coordenadora de campo. O estudo foi aprovado pelos comitês de ética da instituição proponente e do centro coparticipante.  
47  
Adicionalmente, foi realizada busca na base de dados PubMed por estudos avaliando qualidade de vida em pessoas com doença de Chagas, utilizando os seguintes termos: _Chagas disease_ e _quality of life._  
#### **Obtenção da evidência para custos e custo-efetividade das intervenções**  
Análises econômicas permitem a comparação de custos e consequências de estratégias alternativas de intervenções em saúde, representando uma ferramenta útil para que os gestores, no processo de tomada de decisão, possam assegurar o ganho máximo em saúde em cenários de recursos limitados. As recomendações de uma diretriz devem incluir considerações a respeito do equilíbrio entre os custos estimados das intervenções e os seus benefícios esperados, comparados aos de outras intervenções ou programas alternativos.  
Para a obtenção de informação em relação a custo e custo-efetividade de estratégias de rastreamento para doença de Chagas, foram desenvolvidos modelos de árvore de decisão para avaliação das estratégias de rastreamento populacional e de rastreamento em gestantes com suspeita da doença. Os parâmetros utilizados no modelo foram: expectativa de vida geral obtida de tábuas de vida do Instituto Brasileiro de Geografia e Estatística (IBGE); estimativas de anos de vida ajustados para qualidade de vida ( _quality-adjusted life years_ QALY) geradas a partir dos dados obtidos no estudo primário de qualidade de vida; dados de acurácia dos testes para rastreamento provenientes da metanálise de acurácia de testes diagnósticos acima citada; prevalências relativas à doença de Chagas extraídas da literatura, tendo como base metanálise de estudos observacionais nacionais publicada (Martins-Melo, Ramos _, et al._ , 2014). Para a variável de custo foram utilizados dados referentes aos preços dos testes diagnósticos, pesquisados no Banco de Preços em Saúde. No caso dos testes que não estavam disponíveis nesse sistema, foi realizada pesquisa de mercado com fabricantes. Custos diretos do tratamento de pessoas com doença de Chagas crônica foram obtidos dos valores presentes em tabelas do SUS. Ambos os modelos produziram resultados em termos de razão de custoefetividade incremental. No modelo de rastreamento populacional, foram comparadas cinco estratégias: não rastrear, rastrear população maior de 18 anos de área endêmica e não endêmica, rastrear população maior de 50 anos pertencente e não pertencente a um grupo de risco para possuir diagnóstico de Chagas. Para o modelo de rastreamento de gestantes, foram comparadas as estratégias de não rastrear e rastrear gestantes (incluindo rastreamento neonatal). O desfecho de efetividade utilizado no modelo de rastreamento populacional foi o de caso corretamente diagnosticado. Os custos incluídos no modelo de rastreamento populacional foram apenas aqueles referentes ao custo do teste utilizado. Para o modelo de rastreamento de gestantes, o desfecho de efetividade foi expresso em QALYs, para um horizonte temporal de vida toda. Os custos incluídos no modelo de rastreamento gestacional incluíram custos diretos relativos ao tratamento de doença de Chagas crônica estratificados por comprometimento clínico, representando o custo relacionado à falha de diagnóstico em um neonato que poderá desenvolver a doença no futuro. A perspectiva considerada nas análises foi a do SUS.  
48  
#### **Modelo de decisão para rastreamento populacional**  
<!-- Start of picture text -->
Adultos acima<br>da pop. de areas<br>endémicas<br>Adultos acima<br>de pop. de areas<br>endémicas<br>rastreamentoEstratégins para<br>populacional anosPopulagfiode éreaacima<br>Populagao acima<br>lanos de area<br>iio rastrear<br><!-- End of picture text -->  
<!-- Start of picture text -->
Rastreamento (+)<br>de 18 anos com D. CHAGAS<br>nio- Rastreamento (-)<br>Rastreamento (+)<br>sem D. CHAGAS<br>Rastreamento (-)<br>Rastreamento (+)<br>de 18 anos com D. CHAGAS<br>Rastreamento (-)<br>Rastreamento (+)<br>sem D. CHAGAS<br>Rastreamento (-)<br>> CHAGAS Rastreamento (#)<br>nao-endémica de 50 com Rastreamento (-)<br>Rastreamento (+)<br>sem D. CHAGAS<br>Rastreamento (-)<br>Rastreamento (+)<br>com D. CHAGAS<br>de 50 Rastreamento (-)<br>endémica<br>Rastreamento (+)<br>sem D. CHAGAS<br>Rastreamento (-)<br><!-- End of picture text -->  
#### **Modelo de decisão para rastreamento de gestantes**  
<!-- Start of picture text -->
tt<br><!-- End of picture text -->  
<!-- Start of picture text -->
feat C=<br>Deena Dera<br><!-- End of picture text -->  
<!-- Start of picture text -->
ce<br>ereSpun eenee seme nelecada<br>po<br>ewe<br>Paice<br><!-- End of picture text -->  
<!-- Start of picture text -->
eee reDoes on Carta 1) 5<br>Pi te stctae<br>—<br>huapomesSpe sv vera ngs<br>a ta porte<br>aintecado+<br>stoweade —/Deen rte<br>ee ee a)<br><!-- End of picture text -->  
49  
#### **Avaliação da qualidade da evidência**  
Para a avaliação da qualidade da evidência, foi utilizado o sistema GRADE (Grade, 2017). Foram desenvolvidas tabelas de evidências na plataforma GRADEpro (GRADEpro GDT, 2015) para cada questão PICO, sendo considerados na avaliação: risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferentes dos da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de casos ou de eventos), efeito relativo e absoluto de cada questão (Quadro 1).  
#### **<u>Quadro 1. Níveis de evidências de acordo com o sistema GRADE</u>**  
|Nível|Definição|Implicações|
|---|---|---|
|Alto|Há<br>forte<br>confiança<br>de<br>que<br>o<br>verdadeiro efeito esteja próximo<br>daquele estimado|É improvável que trabalhos adicionais<br>irão<br>modificar<br>a<br>confiança<br>na<br>estimativa do efeito.|
|Moderado|Há confiança moderada no efeito<br>estimado.|Trabalhos futuros poderão modificar a<br>confiança na estimativa de efeito,<br>podendo,<br>inclusive,<br>modificar<br>a<br>estimativa.|
|Baixo|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão<br>um impacto importante em nossa<br>confiança na estimativa de efeito.|
|Muito baixo|A confiança na estimativa de efeito<br>é muito limitada.<br>Há importante grau de incerteza<br>nos achados.|Qualquer<br>estimativa<br>de<br>efeito<br>é<br>incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. Brasília: Ministério da Saúde, 2014.  
#### **_Desenvolvimento de recomendações_**  
Para cada recomendação, foram discutidos a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou fraca, de acordo com o sistema GRADE (Quadro 2).  
50  
**Quadro 2. Implicação da força da recomendação para profissionais, pacientes e gestores em saúde.**  
|**Público alvo**|**Forte**|**Fraca (condiciona**|**l)**|
|---|---|---|---|
|Gestores|A recomendação deve ser<br>adotada como política de<br>saúde<br>na<br>maioria<br>das<br>situações|É necessário deb<br>envolvimento<br>interessadas.|ate substancial e<br>das<br>partes|
|Pacientes|A<br>maioria<br>dos<br>indivíduos<br>desejaria que a intervenção<br>fosse indicada e apenas um<br>pequeno<br>número<br>não<br>aceitaria essa recomendação|Grande<br>parte<br>desejaria que a<br>indicada;<br>contu<br>número<br>não<br>recomendação.|dos<br>indivíduos<br>intervenção fosse<br>do<br>considerável<br>aceitaria<br>essa|
|Profissionais da saúde|A maioria dos pacientes deve<br>receber<br>a<br>intervenção<br>recomendada.|O profissional de<br>diferentes<br>e<br>apropriadas par<br>para<br>definir<br>consistente com<br>preferências.|ve reconhecer que<br>scolhas<br>serão<br>a cada paciente<br>uma<br>decisão<br>os seus valores e|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014  
A recomendação pode ser a favor ou contra a intervenção proposta, e ainda pode ser uma recomendação forte (o grupo está bastante confiante que os benefícios superam os riscos) ou fraca (a recomendação ainda gera dúvidas quanto ao balanço entre benefício e risco). Colocações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou esclarecimentos sobre elas, estão documentadas ao longo do texto.  
Para a elaboração das recomendações, foram considerados os riscos e os benefícios das condutas propostas, o nível de evidências para esses riscos e benefícios, além de custos, uso de recursos, valores e preferências das pessoas afetadas, aceitabilidade pelos profissionais e demais barreiras para implementação.  
A direção e a força da recomendação, assim como sua redação, foram definidas durante a reunião presencial de elaboração das recomendações. O grupo desenvolvedor da diretriz recebeu as tabelas GRADE de cada questão PICO e então iniciaram-se as discussões e apresentação das evidências, riscos e benefícios da intervenção proposta, custos e valores e preferências dos casos. O coordenador da diretriz apresentou cada um dos itens acima citados em dois encontros que ocorreram em março e abril de 2017. Os domínios foram debatidos separadamente, de forma estruturada, seguindo a metodologia preconizada pelo GRADE. Buscou-se um consenso em relação às recomendações; na impossibilidade de obtê-lo, realizou-se votação.  
51  
#### **Consenso do grupo elaborador para as recomendações da diretriz**  
|Questões|Considerações<br>sobre<br>a<br>decisão<br>/<br>Justificativas|
|---|---|
|1. Como devemos realizar o diagnóstico de doença de<br>chagas na fase crônica?|Houve consenso entre o grupo.|
|2. Devemos utilizar teste rápido como estratégia<br>diagnóstica inicial para descartar doença de chagas em<br>sua fase crônica?|Houve consenso entre o grupo.|
|3. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox) no tratamento de indivíduos com doença de<br>chagas na fase aguda?|Houve consenso entre o grupo.|
|4. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox) no tratamento de crianças e adolescentes<br>com doença de chagas na fase crônica indeterminada?|Houve consenso entre o grupo.|
|5. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox) no tratamento de adultos com doença de<br>chagas na fase crônica com forma indeterminada?|Benznidazol: Houve consenso entre o<br>grupo.<br>Nifurtimox: Não houve consenso entre<br>o grupo, dos 14 membros do painel,<br>representante 1 absteve-se da votação,<br>2 votaram recomendação fraca mas a<br>favor do uso, um recomendação fraca e<br>contra<br>o<br>uso<br>e<br>10<br>votaram<br>recomendação forte contra usar o<br>nifurtimox.|
|6. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox) no tratamento de indivíduos com doença de|Houve consenso entre o grupo.|
|chagas<br>na<br>fase<br>crônica<br>digestiva,<br>sem<br>comprometimento cardíaco?||
|7. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox)<br>no<br>tratamento<br>de<br>indivíduos<br>com<br>cardiopatia chagásica?|Benznidazol:<br>Não<br>houve<br>consenso<br>quanto a recomendação tratar ou não<br>tratar com benznidazol.<br>Nifurtimox: Não houve consenso entre<br>o grupo, dois membros do painel<br>argumentaram<br>a<br>favor<br>de<br>uma<br>recomendação fraca contra usar o<br>nifurtimox. Arguiram que em casos<br>bastante<br>selecionados,<br>em<br>que<br>pacientes<br>são<br>motivados<br>e<br>não<br>toleraram benznidazol, o tratamento<br>com nifurtimox pode ser considerado.<br>Contudo, o grupo considerou que não<br>há evidencias para benefícios e há certa<br>certeza em relação a alta frequência de<br>efeitos adversos|
|8. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox) no tratamento de pacientes hiv positivos e|Houve consenso entre o grupo.|  
52  
|com doença de chagas na fase crônica?||
|---|---|
|9. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox) no tratamento de pacientes transplantados<br>e com doença de chagas na fase crônica?|Houve consenso entre o grupo.|
|10. Devemos utilizar antiparasitários (benznidazol ou<br>nifurtimox) no tratamento de gestantes com doença de<br>chagas|Houve consenso entre o grupo.|
|11. Devemos utilizar nifedipina no tratamento de<br>pacientes com megaesôfago chagásico sintomático?|Houve consenso entre o grupo.|
|12. Devemos utilizar isossorbida no tratamento de<br>pacientes com megaesôfago chagásico sintomático?|Houve consenso entre o grupo.|
|13. Devemos utilizar amiodarona no tratamento de<br>pacientes com cardiopatia chagásica na forma crônica?|Houve consenso entre o grupo;|
|14. Devemos realizar rastreamento populacional para<br>diagnosticar doença de chagas crônica na população?|Não houve consenso entre o grupo.|
|15. Devemos realizar o rastreamento em gestantes?|Houve consenso entre o grupo.|
|16. Qual período de realização de teste diagnóstico<br>para doença de chagas em crianças com suspeita de<br>transmissão vertical cuja testagem parasitológica<br>neonatal foi negativa?|Houve consenso entre o grupo.|  
#### **Revisão interna**  
O documento foi apresentado ao Comitê Gestor do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da doença de Chagas para revisão interna. Considerações levantadas pela subcomissão técnica que influenciavam na redação, força ou direção das recomendações da diretriz foram discutidas com o grupo de trabalho da diretriz por meio eletrônico.  
#### **Revisão externa**  
O documento foi apresentado em reunião plenária da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) no dia 05/07/2018 e estará disponível para consulta pública, a fim de que se considere a visão da sociedade e se possam receber as suas valiosas contribuições. Considerações levantadas na consulta pública que possam influenciar na redação, força ou direção das recomendações da diretriz serão discutidas com o grupo de trabalho da diretriz por meio eletrônico ou em reunião presencial, se necessário.  
#### **Declaração e manejo de conflitos de interesse**  
A declaração de conflitos de interesse foi baseada nos princípios da _Guideline International Network_ e do _Institute of Medicine_ (IOM). Todos os membros do grupo declararam os seus potenciais conflitos de interesse, utilizando formulário baseado no da Organização Mundial de Saúde (OMS) (WHO, 2014). Participantes que possuíssem conflito de interesse relevante associado a uma ou mais questões do documento seriam impossibilitados de participar da discussão das questões específicas, mas poderiam participar da discussão das demais questões, incluindo votação caso não seja obtido consenso. Nenhum membro do grupo  
53  
possuía alto grau de potencial conflito de interesse financeiro. Conflitos intelectuais, como publicações na área, são considerados importantes; porém, por haverem poucos especialistas no tópico, optou-se por não os excluir da votação.  
#### **RECOMENDAÇÕES**  
As questões abordadas por esta Diretriz estão estruturadas em cinco partes:  
I – Diagnóstico da doença de Chagas  
II – Tratamento etiológico da doença de Chagas  
III – Tratamento etiológico da doença de Chagas em situações especiais  
IV – Tratamento das manifestações clínicas da doença de Chagas  
V – Rastreamento da doença de Chagas  
Os perfis de evidência para todas as questões aparecem ao final deste Anexo.  
#### PARTE I – DIAGNÓSTICO DA DOENÇA DE CHAGAS  
O diagnóstico da doença de Chagas se dá através de métodos parasitológicos diretos e/ou métodos sorológicos, a depender da fase clínica da doença.  
#### **Diagnóstico na fase aguda**  
Na fase aguda, a suspeição se baseia em sinais e sintomas sugestivos da doença e/ou da presença de fatores epidemiológicos compatíveis (mesmo na ausência de sintomas clínicos), como, por exemplo, ocorrência de surtos (identificação entre familiares). Esta fase cursa com sintomatologia usualmente não específica, como febre, mal-estar e astenia, ou é assintomática.  
O Quadro 3 apresenta os principais sinais e sintomas clínicos compatíveis com a doença de Chagas em fase aguda. Ressalta-se que, no caso da transmissão oral, têm sido relatados: rash cutâneo, hemorragia digestiva, icterícia, aumento das aminotransferases e quadros mais frequentes e graves de insuficiência cardíaca.  
#### **Quadro 3. Manifestações da doença de Chagas na fase aguda**  
54  
- Febre (geralmente constante, não superior a 39<sup>o</sup> C), mal-estar, cefaleia, astenia e hiporexia;  
- Sinal de porta de entrada de infecção:  
- Sinal de Romaña: edema elástico das pálpebras unilateral, indolor, com reação de linfonodo satélite (principalmente pré-auricular), com edema frequentemente se propagando à hemiface correspondente;  
- Chagoma de inoculação: formação cutânea pouco saliente, endurecida, avermelhada, pouco dolorosa e circundada por edema elástico;  
- Edema (generalizado ou localizado em face ou membros inferiores), de consistência elástica ou mole, geralmente se apresentando após a segunda semana, não estando relacionado a sinas de porta de entrada;  
- Exantemas e chagomas hematógenos, acometendo pele e tecido celular subcutâneo, sem alteração da cor, não aderentes a planos profundos, comumente indolores e com tamanho variável;  
- Linfonodos com aumento no volume discreto a moderado;  
- Hepatomegalia e/ou esplenomegalia, pequena a moderada;  
- Miocardite;  
- Encefalite;  
- Anemia, linfocitose com presença linfócitos atípicos, plasmocitose e neutropenia relativa;  
Fonte: Adaptado de II Consenso Brasileiro em Doença de Chagas, 2015.  
Segundo a OMS, durante a fase aguda, a doença de Chagas pode ser diagnosticada por meio de métodos parasitológicos, dado o grande número de parasitas que circulam no sangue (WHO, 2002). Para isso, o diagnóstico concentra-se na busca e no reconhecimento de _T. cruzi_ em exames diretos (pesquisa direta a fresco ou testes de concentração como Strout e microhematócrito). Quando os resultados do exame a fresco e de concentração forem negativos na primeira coleta, novas coletas devem ser realizadas até a confirmação da doença e/ou desaparecimento dos sintomas da fase aguda, ou confirmação de outra hipótese diagnóstica.  
O Guia da Vigilância em Saúde do Ministério da Saúde, publicado em 2017, recomenda a realização simultânea de diferentes exames parasitológicos diretos. Quando os resultados do exame a fresco e de concentração forem negativos na primeira coleta, devem ser realizadas novas coletas até a confirmação do caso e/ou desaparecimento dos sintomas da fase aguda, ou confirmação de outra hipótese diagnóstica  (Brasil, 2016).  
Importante salientar que exames parasitológicos indiretos podem ser positivos em pessoas com doença de Chagas em sua fase crônica. Sobre a PCR, o exame tem se mostrado uma técnica promissora para o diagnóstico de Chagas na fase aguda, contudo os custos e a não padronização são uma barreira importante e não há suficiente evidência para justificar seu uso como rotina. É digno de nota que reações sorológicas também podem ser positivas na fase aguda, com testes como IFI, HAI e ELISA, podendo apresentar reatividade no primeiro mês de infecção, o que adiciona complexidade no diagnóstico diferencial. Ainda em relação aos exames parasitológicos, os testes são operador-dependentes e é necessário treinamento continuado da equipe para obter diagnóstico acurado. Isso posto, são necessárias iniciativas de capacitação de microscopistas, especialmente em áreas de maior prevalência e/ou com registro de surtos de transmissão oral. Nacionalmente, esses esforços podem ser articulados junto a programas de vigilância de outras doenças negligenciadas, como malária.  
Em relação aos exames sorológicos, apesar de não serem os mais indicados na fase aguda, podem ser realizados quando a pesquisa direta permanece negativa e a suspeita clínica  
55  
persistir, recomendando-se a oferta de testagem sorológica também aos parentes/contatos assintomáticos que estiveram sob a mesma situação de risco e vulnerabilidade dos casos confirmados decorrentes de surto.  
Portanto, os exames parasitológicos diretos são o padrão ouro para diagnóstico de fase aguda. O objetivo desses exames é identificar o _Trypanosoma cruzi_ no sangue periférico.  
As metodologias aplicáveis na pesquisa direta são: i. Exame a fresco de tripanossomatídeos - utilizada como primeira alternativa por ser de execução rápida e simples, sendo mais sensível que o esfregaço. A coleta deve-se realizar em paciente febril e até 30 dias do início de sintomas. Em caso negativo na primeira coleta e a suspeita clínica persistir, recomenda-se nova coleta entre 12 a 24 horas após a primeira, também em paciente febril; ii. Métodos de concentração (Strout, microhematócrito ou creme leucocitário) - são recomendados principalmente quando a pesquisa a fresco for negativa e o paciente estiver com mais de 30 dias de sintomatologia iii. Lâmina corada de gota espessa ou esfregaço – possui menor sensibilidade que os métodos anteriores, sendo realizado prioritariamente na região da Amazônia Legal, em virtude da sua utilização para diagnóstico da Malária (Brasil, 2013).  
Em relação aos exames sorológicos, apesar de não serem os mais indicados na fase aguda, podem ser realizados quando a pesquisa direta permanece negativa e a suspeita clínica persiste, recomendando-se a oferta de testagem sorológica para os marcadores IgM e IgG. Esta recomendação estende-se também aos parentes/comunicantes assintomáticos que estiveram sob a mesma situação de risco dos casos confirmados. As metodologias recomendadas para confirmação de caso agudo pela pesquisa de IgM é a Imunofluorescência Indireta (RIFI) e para pesquisa de IgG pode ser utilizado o ensaio deimunoabsorção enzimática (ELISA) e/ou a hemaglutinação indireta (HAI) e/ou a imunofluorescência indireta.  
A figura 1 mostra o fluxo para diagnóstico da doença de Chagas pelos critérios laboratoriais sugerido pelo Guia de Vigilância em Saúde (Brasil, 2017).  
#### **Figura 1. Fluxograma para diagnóstico da doença de Chagas por critérios laboratoriais**  
56  
Fonte: Adaptado de Guia de Vigilâ **n** cia em Saúde, 2017. a A confirmação pelo critério soroló **g** ico deve ser avaliada criteriosamente levando em consideração o intervalo entre as datas de início de sintomas e coleta da amostra de sangue, além de evidências clínica **s** epidemiológicas. b Na detecção de imunoglobulina M (Ig **M** ) – descartar o caso somente após a avaliação da sorologia por imunoglobulina G (IgG). Considerar soro reagen **t** e para IgM o título ≥ 1:40 e para IgG ≥ 1:80. c Para conf **i** rmação pelo marcador IgG, são necessárias duas coletas **c** om intervalo mínimo de 15 dias entre uma e outra, se **n** do preferencialmente execução pareada (inclusão da p **r** imeira e da segunda amostras no mesmo ensaio para ef **e** itos comparativos).  
Vale ressaltar que a detecçã **o** de anticorpos anti- _T. cruzi_ da classe IgM é uma **t** écnica complexa, com resultados falso positi **v** os em várias doenças febris. Para realização o paciente deve obrigatoriamente apresenta **r** alterações clínicas compatíveis com doença d **e** Chagas aguda e história epidemiológica sug **e** stiva, sendo mais adequado na fase aguda **t** ardia, após pelo menos 30 dias de sintomas, **q** uando repetidos exames de pesquisa direta for **e** m negativos.  
Para a verificação do estad **o** geral dos casos agudos, é proposta uma r **e** lação de exames laboratoriais complementar **e** s para o seguimento dos casos e manejo clí **n** ico de eventuais complicações (Quadro 4) (Br **a** sil, 2009). Ressalta-se que exames adicionais o **u** modificações na rotina de exames poderão ocorrer conforme a presença de comorbidades.  
#### **Quadro 4. Exames laboratoriais complementares**  
- Urinálise (exame do s **e** dimento urinário - EAS): útil para verificar a ocorrência de sangramento pelas vias **u** rinárias;  
- • Hemograma completo c **o** m plaquetas; • Eletrocardiograma (ECG) **;**  
57  
- Radiografia de tórax;  
- Testes de função hepática: são importantes marcadores para verificação do acometimento hepático, especialmente em casos de doença de Chagas aguda por transmissão oral. As aminotransferases (AST **e** ALT) frequentemente aparecem elevadas. Bil **i** rrubinas (totais e frações) também pode **m** estar alteradas, com ou sem icterícia visí **v** el. O Tempo de Protrombina (TAP ou TP) prolongado sugere dano hepático;  
- Provas de coagulação ( **T** TPA): devem ser realizadas sempre que possível, especialmente nos casos nos quais haja acometimento hepático importante **o** u manifestações hemorrágicas;  
- Endoscopia digestiva alt **a** : indicada em casos de dor epigástrica inten **s** a e refratária ao tratamento específico, **o** u na vigência dos seguintes sinais de alar **m** e: hematêmese, melena, vômitos persistentes, disfagia ou anemia;  
<!-- Start of picture text -->
.<br><!-- End of picture text -->  
- Ecocardiograma: em cas **o** s de sintomas sugestivos de miopericardite;  
- Exame do líquor céfalo-r **a** quidiano: suspeita clínica de meningoencefalite  
#### **Diagnóstico na fase crônica**  
O diagnóstico laboratorial **n** a fase crônica é essencialmente sorológico, devido ao baixo número de parasitos ou inexistência de parasito na circulação periférica. Portanto, recomendase   utilizar um teste com elevada sensibilidade em conjunto com outro de alta especificidade, conforme abordado nas recomendações desta diretriz.  
Fonte: Adaptado de Guia de Vigilân **c** ia em Saúde, 2017. a Cenários sem uma rede laboratorial adequada, investigação diagnóstica em pacientes com difícil acesso aos serviços de saúde e em gestantes com suspeita de doença de Chagas durante o pré-natal ou **e** m trabalho de parto. b O terceiro teste realizado pode ser qualquer um dos seguintes: ELISA, IFI, HAI, WB ou CLIA.  
Abaixo seguem as recomen **d** ações, resumo das evidências encontradas e considerações do grupo elaborador.  
**QUESTÃO 1 – COMO DEVE SER REALIZADO O DIAGNÓSTICO DA DOENÇA DE CHAGAS NA FASE CRÔNICA?**  
**Recomendação 1.1 – Recomendamos a combinação de dois testes sorológicos baseados em princípios distintos ou com diferentes preparações antigênicas, podendo ser ELISA, IFI, HAI,**  
58  
**CLIA ou WB, para o diagnóstico inicial de doença de Chagas (nível de evidência baixo para ELISA e WB e muito baixo para os demais, recomendação forte). Recomendação 1.2 – Recomendamos a realização de um terceiro teste sorológico dentre os seguintes: ELISA, IFI, HAI, CLIA ou WB, em nova amostra, em indivíduos com resultados iniciais discordantes para doença de Chagas (nível de evidência baixo para ELISA e WB e muito baixo para os demais, recomendação forte).**  
**Recomendação 1.3 – Recomendamos não utilizar PCR como teste diagnóstico para a doença de Chagas na fase crônica (nível de evidência muito baixo, recomendação forte).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática, na qual foram avaliados 95 estudos (listados no final desta seção), em sua maioria com delineamento transversal.  
Em relação à acurácia diagnóstica para a doença de Chagas crônica, na Tabela 1 estão apresentados os resultados de sensibilidade e especificidade para cada teste avaliado, assim como a qualidade da evidência de acordo com o sistema GRADE. As evidências são bastante limitadas, sendo os testes usualmente avaliados isoladamente, fora do contexto sugerido da combinação de dois testes diferentes para o diagnóstico. Além disso, não foram identificadas evidências diretas para o diagnóstico no caso de dois testes sorológicos prévios discordantes, sendo os julgamentos a respeito de sensibilidade e especificidade extrapolados a partir do cenário de testagem inicial.  
**Tabela 1. Acurácia dos testes diagnósticos**  
|Teste|Estudos (n)|Sensibilidade<br>(IC95%)|Qualidade da<br>evidência|Especificidade<br>(IC95%)|Qualidade da<br>evidência|
|---|---|---|---|---|---|
|HAI|15|91 (81,2 a 96,0)|Muito baixa<br>⨁◯◯◯|98,9 (96,6 a 99,6)|Baixa<br>⨁⨁◯◯|
|ELISA|130|96,2 (94,7 a 97,3)|Baixa<br>⨁⨁◯◯|99,0 (97,0 a 100)|Baixa<br>⨁⨁◯◯|
|IFI|15|88,1 (74,0 a 95,1)|Muito baixa<br>⨁◯◯◯|98,1 (96,3 a 99,1)|Baixa<br>⨁⨁◯◯|
|WB|14|98,0 (96,0 a 99,0)|Baixa<br>⨁⨁◯◯|99,0 (97,0 a 99,0)|Baixa<br>⨁⨁◯◯|
|CLIA|3|97,8 (96,1 a 98,8)|Muito baixa<br>⨁◯◯◯|98,7 (99,5 a 96,8)|Muito baixa<br>⨁◯◯◯|
|PCR*|42|59,2 (46,4 a 71,0)|Muito baixa<br>⨁◯◯◯|96,0 (93,0 a 98,0)|Baixa<br>⨁⨁◯◯|  
HAI: hemaglutinação indireta; ELISA: teste imunoenzimático; IFI: imunofluorescência indireta; WB: _Western blot_ ; CLIA: quimiluminescência; PCR: reação em cadeia da polimerase * teste parasitológico.  
Foi realizada simulação para avaliar as taxas de verdadeiro-positivos, falso-positivos e falsonegativos no contexto de primeiro diagnóstico (utilizando teste único) e no contexto de confirmação diagnóstica no caso de duas sorologias discordantes. Esses dados são apresentados na Tabela 2.  
**TABELA 2. Confirmação diagnóstica no caso de utilização teste único para o diagnóstico e no caso de confirmação diagnóstica após duas sorologias discordantes (a cada 1.000 testes).**  
59  
|Teste|Cená<br>Probabilid|rio: testagem i<br>ade 4,2% (42|nicial<br>em 1.000)|Cenário:<br>Probabilid|testagem disc<br>ade 70% (700|ordante<br>em 1.000)|
|---|---|---|---|---|---|---|
||Verdadeiro-<br>positivos<sup>1</sup>|Falso-<br>positivos<sup>2</sup>|Falso-<br>negativos<sup>3</sup>|Verdadeiro-<br>positivos<sup>1</sup>|Falso-<br>positivos<sup>2</sup>|Falso-<br>negativos<sup>3</sup>|
|HAI|38|11|4|637|3|63|
|ELISA|40|11|2|673|3|27|
|IFI|37|18|5|617|6|83|
|WB|41|12|1|685|4|15|
|CLIA|40|17|2|663|5|37|
|PCR*|25|38|17|414|12|286|  
HAI: hemaglutinação indireta; IFI: imunofluorescência indireta; WB: Western Blot; CLIA: quimiluminescência; PCR: reação em cadeia da polimerase 1 - Verdadeiro-positivos corresponde ao número de pessoas com doença de Chagas que foram adequadamente diagnosticadas com o teste (teste positivo); 2- Falso-positivos corresponde ao número de pessoas sem a doença mas que o teste classificou como doentes (teste positivo); 3 - Falso -negativo corresponde ao número de pessoas que têm a doença mas esta não foi detectada no teste (teste negativo). * teste parasitológico.  
Para uma população com probabilidade pré-teste de 4,2% de ter a doença de Chagas (MartinsMelo, Ramos _, et al._ , 2014), o WB e o ELISA são os testes que detectam o maior número de casos positivos de forma correta (verdadeiro-positivos), seguidos pelo HAI. O HAI é o teste que melhor classifica quem não possui a doença (verdadeiro-negativos), seguido pelo IFI.  
No caso de sorologias discordantes, a probabilidade de ter a doença foi estimada em 70%. Nesse caso, o WB é o teste que detecta o maior número de casos positivos de forma correta (verdadeiro-positivos), apresentando maior sensibilidade, seguido por ELISA, CLIA e HAI. ELISA, HAI e WB são os testes que melhor classificam quem não possui a doença (verdadeironegativos).  
Em relação à PCR, caso seja utilizada, um resultado positivo indica alta probabilidade de possuir a doença. Contudo, o resultado negativo da PCR é de pouco auxílio diagnóstico, uma vez que a carga parasitária encontrada nos casos crônicos é muito baixa ou intermitente, resultando em baixos valores de sensibilidade.  
#### **<u>Custos e disponibilidade dos testes diagnósticos para a doença de Chagas:</u>**  
Em relação aos custos dos testes, a ordem de custo é: HAI (R$ 1,35), ELISA (R$ 1,79), IFI (R$ 3,00), PCR (R$ 10,30), WB (R$ 62,97) e CLIA (R$ 119,02). Esse valor corresponde ao custo por teste, considerando apenas os reagentes, não sendo considerados valores referentes à coleta, ao processamento e à leitura das amostras. Em geral, esses testes podem ser realizados na grande maioria dos laboratórios, exceto PCR. Além disso, é importante salientar que há falta de _kits_ comerciais registrados na ANVISA (Agência Nacional de Vigilância Sanitária), sendo frequente a utilização de métodos _in-house_ .  
#### **<u>Considerações</u>**  
Entende-se que a seleção dos testes para diagnóstico de Chagas no Brasil acaba sendo majoritariamente de responsabilidade do gestor de saúde e não do profissional em saúde. Para a seleção dos testes, devem ser levados em conta fatores como custos, disponibilidade, necessidade de automatização do processo devido ao volume de testes a serem realizados, e  
60  
estrutura instalada. Para mais informações sobre recomendações e considerações para disponibilização de tecnologias, _vide_ seção específica no documento: “Recomendações para disponibilização de tecnologias”.  
Esta diretriz não aborda o rastreamento de doença de Chagas em serviços de hemoterapia. Nesses cenários, conforme Portaria Nº 158, de 4 de fevereiro de 2016, o teste será realizado por método de ELISA ou CLIA.  
**QUESTÃO 2. DEVE-SE UTILIZAR O TESTE RÁPIDO COMO ESTRATÉGIA DIAGNÓSTICA INICIAL PARA DESCARTAR DOENÇA DE CHAGAS EM SUA FASE CRÔNICA? Recomendação 2. Sugerimos utilizar o teste rápido como alternativa para descartar diagnóstico de doença de Chagas crônica (evidência moderada, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática, na qual foram avaliados 48 estudos (listados no final desta seção), em sua maioria de desenho transversal.  
Em relação à acurácia diagnóstica para a doença de Chagas crônica, a sensibilidade foi de 96% (intervalo de confiança de 95% [IC95%] 94 a 97%; qualidade da evidência baixa) e especificidade foi de 98% (IC95% 97 a 99%; qualidade da evidência moderada).  
Foi realizada simulação para avaliar as taxas de verdadeiro-positivos, falso-positivos e falsonegativos no contexto de primeiro diagnóstico (utilizando teste único) e no contexto de confirmação diagnóstica no caso de duas sorologias discordantes. Para uma estimativa de 4,2% de probabilidade pré-teste, a cada 1.000 doentes, haverá 40 pessoas com a doença adequadamente diagnosticada (verdadeiro-positivos), 17 pessoas sem a doença com o teste positivo para Chagas (falso-positivos) e serão perdidas duas pessoas com doença de Chagas cujo teste será negativo (falso-negativo).  
#### **<u>Custos e disponibilidade do teste rápido para doença de Chagas</u>**  
O custo por teste unitário é de R$ 17,63 (considerando apenas os reagentes), sendo sua logística de realização relativamente simples. Tomando por base estudo de custo realizado em 2010 para testagem rápida de malária, o custo estimado da estratégia de testagem, incluindo gastos com treinamento pessoal e materiais (por exemplo, luvas e curativo), além dos reagentes para doença de Chagas, é de R$ 30,97.  
#### **<u>Considerações</u>**  
O teste rápido é uma boa alternativa como estratégia para descartar o diagnóstico de doença de Chagas, em especial em lugares com dificuldade de acesso a laboratórios de análises clínicas e em pessoas cujo retorno para conferência de resultados dos exames é incerto. Nesses casos, apenas um pequeno número de diagnósticos será perdido. Contudo, caso o teste seja positivo, há a necessidade formal de confirmação diagnóstica, como apresentado na recomendação 1.1, tendo em vista a elevada taxa de resultados falso-positivos. Adicionalmente, essa estratégia pode ser considerada como alternativa para inquéritos e busca ativa por casos em áreas remotas, por exemplo.  
Testes rápidos, apesar de não substituírem o diagnóstico convencional, também podem ser úteis em serviços com pouca demanda e em gestantes com suspeita de doença de Chagas durante o pré-natal ou em trabalho de parto, as quais podem se beneficiar do teste rápido, devido à agilidade nos resultados.  
61  
#### **Lista de estudos incluídos nas revisões sistemáticas relativas ao diagnóstico da doença de Chagas**  
1. ALMEIDA, I C et al. A highly sensitive and specific chemiluminescent enzyme-linked immunosorbent assay for diagnosis of active Trypanosoma cruzi infection. Transfusion, v. 37, n. 8, p.850-857, 1997.  
2. ALVIAREZ, Y et al. Estandarización de la técnica de agluqnación directa para el inmunodiagnósqco de la enfermedad de Chagas. Biomédica, v. 24, p.308-317, 2014.  
3. AVILA, H A et al. Detection of Trypanosoma cruzi in blood specimens of chronic chagasic patients by polymerase chain reaction amplification of kinetoplast minicircle DNA: comparison with serology and xenodiagnosis. Journal of Clinical Microbiology, v. 31, n. 9, p.2421-2426, 1993.  
4. AZNAR, C et al. A simple Trypanosoma cruzi enzyme-linked immunoassay for control of human infection in nonendemic areas. FEMS Immunology and Medical Microbiology, v. 18, n. 1, p.31-37, 1997.  
5. BARFIELD, C A et al. A highly sensitive rapid diagnostic test for Chagas disease that utilizes a recombinant Trypanosoma cruzi antigen. IEEE Transactions and Biomedical Engineering, v. 58, n. 3, p.814-817, 2011.  
6. BARROS, M N D S et al. Evaluation of oral mucosal transudate for immunodiagnosis of Chagas´ disease. Revista do Instituto de Medicina Tropical de São Paulo, v. 41, n. 4, p.265266, 1999.  
7. BASOMBRIO, M A et al. Endemic Trypanosoma cruzi infection in Indian populations of the Gran Chaco territory of South America: performance of diagnostic assays and epidemiological features. Annals of Tropical Medicine and Parasitology, v. 93, n. 1, p.41-48, 1999.  
8. BERN, C et al. Congenital Trypanosoma cruzi transmission in Santa Cruz, Bolivia. Clinical Infectious Disease, v. 49, n. 11, p. 1667-1674, 2009.  
9. BERRIZBEITIA, M et al. Development and application of an ELISA assay using excretion/secretion proteins from epimastigote forms of T. cruzi (ESEA Antigens) for the diagnosis of Chagas disease. Journal of Tropical Medicine, v. 2012, p. 875909, 2012.  
10. BERRIZBEITIA, M et al. Purified excreted-secreted antigens from Trypanosoma cruzi trypomastigotes as tools for diagnosis of Chagas' disease. Journal of Clinical Microbiology, v. 44, n. 2, p.291-296, 2006.  
11. BLEJER J. Chagas' disease in Argentina: seroprevalence in blood donors and evaluation of an Elisa assay for antibody detection [Abstract]. Var Sanguinis. 2009;96(Suppl. 1):100-1.  
12. BLEJER, J L. Tamizaje serológico de anticuerpos anti-Trypanosoma cruzi en bancos de sangre. Salud i Ciencia, v. 15, n. 1, p.470-476, 2006.  
13. BRASHEAR, R J et al. Detection of antibodies to Trypanosoma cruzi among blood donors in the southwestern and western United States. I. Evaluation of the sensitivity and specificity of an enzyme immunoassay for detecting antibodies to T. cruzi. Transfusion, v. 35, n. 3, p. 213-218, 1995.  
14. BRICEÑO, D et al. Diagnóstico inmunológico de la enfermedad de Chagas a partir de muestras colectadas en papel de filtro. Salus, v. 16, n.1, p.43-52, 2012.  
62  
15. BRICEÑO, L et al.  Un anqgeno economico para el serodiagnosqco de la enfermedad de Chagas. Invesqgación Clínica, v. 51, n. 1, p.101-113, 2010.  
16. BRITTO, C et al. Polymerase chain reaction detection of Trypanosoma cruzi in human blood samples as a tool for diagnosis and treatment evaluation. Parasitology, v. 110, n.Pt3, p.241-247, 1995.  
17. CANNOVA, D et al. Validación del inmuno ensayo enzimáqco (ELISA) y hemoagluqnación indirecta (HAI) para el serodiagnósqco de la enfermedad de Chagas. Salus, v. 6, p.4-9, 2002.  
18. CARVALHO, M R et al. Chagas' disease diagnosis: evaluation of several tests in blood bank screening. Transfusion, v. 33, n. 10, p. 830-834, 1993.  
19. CASSANDRA, D R et al. Determination of the sensitivity and specificity of three serodiagnostic assays for Chagas disease by latent class analysis [Abstract]. 2011.  
20. CERVANTES-LANDÍN, A Y et al. Estandarización de la técnica Dot-ELISA para la detección de anticuerpos anti-Trypanosoma cruzi y su comparación con ELISA y Western blot. Enfermedades Infecciosas y Microbiología Clínica, v. 32, n. 6, p.363-368, 2014.  
21. CHAPPUIS, F et al. Validation of a rapid immunochromatographic assay for diagnosis of Trypanosoma cruzi infection among Latin-American migrants in Geneva, Switzerland. Journal of Clinical Microbiology, v. 48, n. 8, pg.2948-2952, 2010.  
22. CHIPPAUX, J P et al. Sensitivity and specificity of Chagas Stat-Pak test in Bolivia. Tropical Medicine & International Health, v. 14, n. 7, p.732-735, 2009.  
23. DUARTE, A M et al. Assessment of chemiluminescence and PCR effectiveness in relation to conventional serological tests for the diagnosis of Chagas' disease. Revista da Sociedade Brasileira de Medicina Tropical, v. 39, n. 4, p.385-387, 2006.  
24. DUARTE, L F et al. Comparison of seven diagnostic tests to detect Trypanosoma cruzi infection in patients in chronic phase of Chagas disease. Colombia Médica, v. 45, n. 2, p. 61-66, 2014.  
25. ENCISO, C et al. Comparación de la prueba de inmunofluorescencia indirecta, un inmunoensayo enzimáqco y la prueba comercial Chagatek para la detección de anqcuerpos anti-Trypanosoma cruzi. Biomédica, v. 24, p.104-108, 2004.  
26. ESCALANTE, H et al. Estandarización de la técnica de western blot para el diagnóstico específico de la enfermedad de Chagas utilizando antígenos de excreción-secreción de los epimastigotes de Trypanosoma cruzi. Revista Peruana de Medicina Experimental y Salud Pública, v. 31, n. 4, p. 644-651, 2014.  
27. FERREIRA, A W et al. Enzyme-linked immunosorbent assay for serological diagnosis of Chagas' disease employing a Trypanosoma cruzi recombinant antigen that consists of four different peptides. Journal of Clinical Microbiology, v. 39, n. 12, p.4390-4395, 2001.  
28. FERRER, E et al. Comparación entre técnicas inmunológicas y moleculares para el diagnósqco de la enfermedad de Chagas. Enfermedades Infecciosas y Microbiología Clínica, v. 31, n. 5, p. 277-282, 2013.  
29. FITZWATER, S et al. Chagas Disease Working Group in Peru and Bolivia. Polymerase chain reaction for chronic Trypanosoma cruzi infection yields higher sensitivity in blood clot than buffy coat or whole blood specimens. American Journal of Tropical Medicine and Hygiene, v. 79, n. 5, p. 768-770, 2008.  
63  
30. FLORES-CHÁVEZ, M et al. Comparación de técnicas serológicas convencionales y no convencionales para el diagnóstico de la enfermedad de Chagas importada en España. Enfermedades Infecciosas y Microbiología Clínica, v. 28, n. 5, p.284-293, 2010.  
31. FRADE, A F et al. Western blotting method (TESAcruzi) as a supplemental test for confirming the presence of anti-Trypanosoma cruzi antibodies in finger prick blood samples from children aged 0-5 years in Brazil. Acta Tropica, v. 117, n. 1, p.10-13, 2011.  
32. FURUCHÓ, C R et al. Inconclusive results in conventional serological screening for Chagas' disease in blood banks: evaluation of cellular and humoral response. Tropical Medicine and International Health, v. 13, n. 12, p.1527-1533, 2008.  
33. GADELHA, A A et al. Chagas' disease diagnosis: comparative analysis of recombinant ELISA with conventional ELISA and the haemagglutination test. Vox Sanguinis, v. 85, n. 3, p165170, 2003.  
34. GARCIA E, et al. Diagnosis of American trypanosomiasis (Chagas' disease) by the new complement fixation test. Journal of Clinical Microbiology, v. 33, n. 4, p. 1034-1035, 1995.  
35. GIL, J et al. Comparación de una prueba de PCR basada en los genes codificantes para la histona H2A/SIRE con pruebas serológicas convencionales para el diagnósqco de la enfermedad de Chagas crónica en pacientes colombianos. Biomédica, v. 27, n. supl.1, p.8391, 2007.  
36. GIL, J et al. Reactividad del antígeno GST-SAPA de Trypanosoma cruzi frente a sueros de pacientes con enfermedad de Chagas y leishmaniasis. Medicina (B. Aires), v. 71, n. 2, p.113-119, 2011.  
37. GILBER, S R et al. Comparison of conventional serology and PCR methods for the routine diagnosis of Trypanosoma cruzi infection. Revista da Sociedade Brasileira de Medicina Tropical, v. 46, n. 3, p.310-315, 2013.  
38. GIRONÈS, N et al. Antibodies to an epitope from the Cha human autoantigen are markers of Chagas' disease. Clinical and Diagnostic Laboratory Immunology, v. 8, n. 6, p. 1039-1043, 2001.  
39. GOMES, M L et al. Chagas' disease diagnosis: comparative analysis of parasitologic, molecular, and serologic methods. American Journal of Tropical Medicine and Hygiene, v. 60, n. 2, p.-205-210, 1999.  
40. GOMES, Y M et al. Serodiagnosis of chronic Chagas infection by using EIE-RecombinantChagas-Biomanguinhos kit. Memórias do Instituto Oswaldo Cruz, v. 96, n. 4, p.497-501, 2001.  
41. GORLIN, J et al. Evaluation of a new Trypanosoma cruzi antibody assay for blood donor screening. Transfusion, v.48, n.3, p.531-540, 2008.  
42. GUTIERREZ, R et al. Comparison of four serological tests for the diagnosis of Chagas disease in a Colombian endemic area. Parasitology, v.129, n.(Pt 4), p.439-444, 2004.  
43. HERNÁNDEZ, C et al. Molecular diagnosis of Chagas disease in Colombia: parasitic loads and discrete typing units in patients from acute and chronic phases. PLoS Neglected Tropical Diseases, v. 10, n. 9, p.e0004997, 2016.  
44. HOUGHTON, R L et al. A multi-epitope synthetic peptide and recombinant protein for the detection of antibodies to Trypanosoma cruzi in radioimmunoprecipitation-confirmed and consensus-positive sera. Journal of Infected Diseases, v. 179, n, 5, p. 1226-1234, 1999.  
64  
45. IBORRA-BENDICHO, M A et al. ARCHITECT Chagas®: una nueva herramienta diagnósqca en la enfermedad de Chagas. Enfermedades Infecciosas y Microbiología Clínic, v. 30, n. 8, p. 463-465, 2012.  
46. JI, M J et al. Evaluation of SD BIOLINE Chagas Ab Rapid kit. Korean Journal of Laboratory Medicine journal, v. 29, n. 1, p. 48-52, 2009.  
47. KNECHER, L M et al. Chagas' disease screening in blood bank employing enzyme immunoassay. International Journal for Parasitology, v. 24, n. 2, p.207-211, 1994.  
48. KRIEGER, M A et al. Use of recombinant antigens for the accurate immunodiagnosis of Chagas' disease. American Journal of Tropical Medicine and Hygiene, v. 46, n. 4, p.427-434, 1992.  
49. LANGHI, D M et al. The application of latent class analysis for diagnostic test validation of chronic Trypanosoma cruzi infection in blood donors. Brazilian Journal of Infectious Diseases, v. 6, n. 4, p. 181-187, 2002.  
50. LONGHI, S A et al. Evaluation of in-house ELISA using Trypanosoma cruzi lysate and recombinant antigens for diagnosis of Chagas disease and discrimination of its clinical forms. American Journal of Tropical Medicine and Hygiene, v. 87, n. 2, p.267-271, 2012.  
51. LORCA, M et al. Evaluación de una prueba rápida para el diagnóstico de la infección por Trypanosoma cruzi en suero. Parasitología latinoamericana, v. 63, n. 1-4, p.29-33, 2008.  
52. LUNARDELLI, A et al. Soroprevalência da doença de Chagas em candidatos a doadores de sangue. Revista Brasileira de Análises Clínicas, v.39, n. 2, p.139-141, 2007.  
53. LUQUETTI, A O et al. Chagas' disease diagnosis: a multicentric evaluation of Chagas StatPak, a rapid immunochromatographic assay with recombinant proteins of Trypanosoma cruzi. Diagnostic Microbiology and Infectious Disease, v. 46, n. 4, p.265-271, 2003.  
54. LUZ, J G et al. Applicability of a novel immunoassay based on surface plasmon resonance for the diagnosis of Chagas disease. Clinica Chimica Acta, v. 454, p.39-45, 2016.  
55. MACHADO-DE-ASSIS, GF et al. Posttherapeutic cure criteria in Chagas' disease: conventional serology followed by supplementary serological, parasitological, and molecular tests. Clinical and Vaccine Immunology, v. 19, n.8, p.1283-1291, 2012.  
56. MAIA, Allan Rodrigo Soares. Detecção do DNA de Trypanosoma cruzi por PCR em sangue de pacientes com doença de Chagas crônica e em dejetos de triatomíneos utilizados para o xenodiagnóstico. 2012. 132 f. Dissertação (Mestrado) - Curso de Patologia, Universidade Federal do Ceará, Fortaleza, 2012.  
57. MALAN, A K et al. Serological diagnosis of Trypanosoma cruzi: evaluation of three enzyme immunoassays and an indirect immunofluorescent assay. Journal of Medical Microbiology, v.55(Pt2), p.171-178, 2006.  
58. MARCON, G E et al. Use of a nested polymerase chain reaction (N-PCR) to detect Trypanosoma cruzi in blood samples from chronic chagasic patients and patients with doubtful serologies. Diagnostic Microbiology and Infectious Disease, v. 43, n. 1, p.39-43, 2002.  
59. MATSUMOTO, T K et al. High resolution of Trypanosoma cruzi amastigote antigen in serodiagnosis of different clinical forms of Chagas' disease. Journal of Clinical Microbiology, v. 31, n. 6, pg. 1486-1492, 1993.  
65  
60. MEIRA W S, et al. Trypanosoma cruzi recombinant complement regulatory protein: a novel antigen for use in an enzyme-linked immunosorbent assay for diagnosis of Chagas' disease. Journal of Clinical Microbiology, v. 40, n, 10, p. 3735-3740, 2002.  
61. MELO, M F et al. Usefulness of real time PCR to quantify parasite load in serum samples from chronic Chagas disease patients. Parasites & Vectors, v. 8, p. 154, 2015.  
62. MENDICINO, D et al. Diagnostic reliability of an immunochromatographic test for Chagas disease screening at a primary health care centre in a rural endemic area. Memórias do Instituto Oswaldo Cruz, v. 109, n.8, p.984-988, 2014.  
63. NAGASSE-SUGAHARA, T K et al. Improvement of the slide hemagglutination test for rapid Chagas' disease screening in epidemiological surveys. Brazilian Journal of Medical and Biological Research, v. 29, n. 5, p.623-628, 1996.  
64. OELEMANN, W M et al. Evaluation of three commercial enzyme-linked immunosorbent assays for diagnosis of Chagas' disease. Journal of Clinical Microbiology, v. 36, n.9, p.24232427, 1998.  
65. PALACIOS, X; BELLI, A; ESPINO, A M. Detección de anqcuerpos contra Trypanosoma cruzi en Somoto, Nicaragua, mediante ELISA indirecto e IFI en muestras de sangre en papel de filtro. Revista Panamericana de Salud Pública, v. 8, n. 6, p.411-417, 2000.  
66. PAN, A A et al. Clinical evaluation of an EIA for the sensitive and specific detection of serum antibody to Trypanosoma cruzi (Chagas' disease). Journal of Infectious Disease, v. 165, n. 3, p.585-588, 1992.  
67. PARTEL, C D; ROSSI, C L. A rapid, quantitative enzyme-linked immunosorbent assay (ELISA) for the immunodiagnosis of Chagas' disease. Immunological Investigations, v. 27, n. 1-2, p.89-96, 1998.  
68. PASTINI, A C et al. Immunoassay with recombinant Trypanosoma cruzi antigens potentially useful for screening donated blood and diagnosing Chagas disease. Clinical Chemistry, v. 40, n. 10, p. 1893-1897, 1994.  
69. PEREIRA, V R et al. Immunodiagnosis of chronic Chagas ́ disease using the Tc 46 and Tc 58 antigens. Revista da Sociedade Brasileira de Medicina Tropical, v. 33, n. 4, p.367-370, 2000.  
70. PEREIRA-CHIOCCOLA, V L et al. Enzyme-Linked Immunoassay Using Recombinant transSialidase of Trypanosoma cruzi Can Be Employed for Monitoring of Patients with Chagas' Disease after Drug Treatment. Clinical and Diagnostic Laboratory Immunology, v. 10, n. 5, p.826-830, 2003.  
71. PETRAY, P et al. Evaluación del método de ELISA para detección de antígenos y complejos inmunes circulantes de Trypanosoma cruzi através de un estudio de campo en una zona endémica de Argentina. Revista do Instituto de Medicina Tropical de São Paulo, v. 34, n. 2, p.141-147, 1992.  
72. PIERIMARCHI, P et al. Rapid Chagas diagnosis in clinical settings using a multiparametric assay. Diagnostic Microbiology and Infectious Disease, v. 75, p.381-389, 2013.  
73. PINHO, R T et al.  ELISA: a method for the diagnosis of chronic Chagas disease in endemic areas. Acta Tropica, v. 72, n. 1, p.31-38, 1999.  
74. PIRARD, M et al. The validity of serologic tests for Trypanosoma cruzi and the effectiveness of transfusional screening strategies in a hyperendemic region. Transfusion, v. 45, n. 4, p.554-561, 2005.  
66  
75. PONCE, C et al. Validation of a rapid and reliable test for diagnosis of chagas' disease by detection of Trypanosoma cruzi-specific antibodies in blood of donors and patients in Central America. Journal of Clinical Microbiology, v. 43, n. 10, p.5065-5068, 2005.  
76. PRAAST, G et al. Evaluation of the Abbott ARCHITECT Chagas prototype assay. Diagnostic Microbiology and Infectious Disease, v. 69, n. 1, p.74-81, 2011.  
77. RAMÍREZ, J D. Evaluation of adult chronic Chagas' heart disease diagnosis by molecular and serological methods. Journal of Clinical Microbiology, v. 47, n. 12, p.3945-3951, 2009.  
78. REICHE, E M et al. Evaluation of the western blot in the confirmatory serologic diagnosis of Chagas' disease. American Journal of Tropical Medicine and Hygiene, v. 59, n. 7, p. 750756, 1998.  
79. REITHINGER, R et al. Rapid detection of Trypanosoma cruzi in human serum by use of an immunochromatographic dipstick test. Journal of Clinical Microbiology, v. 48, n. 8, p.30033007, 2010.  
80. REQUEJO, H I et al. Diffusion-in-gel enzyme-linked immunosorbent assay (DIG-ELISA) for Chagas' disease serodiagnosis. Brazilian Journal of Medical and Biological Research, v. 24, n.5, p.471-483, 1991.  
81. RIBEIRO-DOS-SANTOS, G et al. An improved, PCR-based strategy for the detection of Trypanosoma cruzi in human blood samples. Annals of Tropical Medicine and Parasitology, v. 93, n. 7, p.689-694, 1999.  
82. RODDY, P et al. Field evaluation of a rapid immunochromatographic assay for detection of Trypanosoma cruzi infection by use of whole blood. Journal of Clinical Microbiology, v. 46, n. 6, p.2022-2027, 2008.  
83. SABINO, E C et al. NHLBI Retrovirus Epidemiology Donor Study-II (REDS-II) International Program. Antibody levels correlate with detection of Trypanosoma cruzi DNA by sensitive polymerase chain reaction assays in seropositive blood donors and possible resolution of infection over time. Transfusion, v. 53, n. 6, p.1257-1265, 2013.  
84. SANTOS-COELHO, J et al. A multianalyte Dot-ELISA for simultaneous detection of malaria, Chagas disease, and syphilis-specific IgG antibodies. Diagnostic Microbiology and Infectious Disease, v. 58, n. 2, p. 223-230, 2007.  
85. SCHIJMAN, A G et al. Aetiological treatment of congenital Chagas' disease diagnosed and monitored by the polymerase chain reaction. Journal of Antimicrobial Chemotherapy, v. 52, n. 3, p. 441-449, 2003.  
86. SHAH, V et al. Field Evaluation of the InBios Chagas Detect Plus Rapid Test in Serum and Whole-Blood Specimens in Bolivia. Clinical and Vaccine Immunology, v. 21, n. 12, p. 16451649. 2014.  
87. TOBLER, L H et al. Evaluation of a new enzyme-linked immunosorbent assay for detection of Chagas antibody in US blood donors. Transfusion, v. 47, n. 1, p.90-96, 2007.  
88. UMEZAWA, E S et al. An improved serodiagnostic test for Chagas' disease employing a mixture of Trypanosoma cruzi recombinant antigens. Transfusion, v. 43, n. 1, p.91-97, 2003.  
89. UMEZAWA, E S et al. Evaluation of Recombinant Antigens for Serodiagnosis of Chagas’ Disease in South and Central America. Journal of Clinical Microbiology, v. 37, n. 5, p.15541560, 1999.  
67  
90. UMEZAWA, E S et al. Serodiagnosis of chronic and acute Chagas' disease with Trypanosoma cruzi recombinant proteins: results of a collaborative study in six Latin American countries. Journal of Clinical Microbiology, v. 42, n. 1, p.449-452, 2004.  
91. UMEZAWA, E S; NASCIMENTO, M S; STOLF, A M. Enzyme-linked immunosorbent assay with Trypanosoma cruzi excreted-secreted antigens (TESA-ELISA) for serodiagnosis of acute and chronic Chagas' disease. Diagnostic Microbiology and Infectious Disease, n. 39, v. 3, p.168-176, 2001.  
92. VERANI, J R et al. Geographic variation in the sensitivity of recombinant antigen-based rapid tests for chronic Trypanosoma cruzi infection. American Journal of Tropical Medicine and Hygiene, v. 80, n. 3, p. 410-415, 2009.  
93. VILLAGRÁN-HERRERA, M E et al. Comparative serology techniques for the diagnosis of Trypanosoma cruzi infection in a rural population from the state of Querétaro, Mexico. Memórias do Instituto Oswaldo Cruz, v. 109, n. 7, p.964-969, 2014.  
94. WINCKER, P et al. High correlation between Chagas' disease serology and PCR-based detection of Trypanosoma cruzi kinetoplast DNA in Bolivian children living in an endemic area. FEMS Microbiology Letters, v. 124, n. 3, p.419-423, 1994.  
95. WINCKER, P et al. PCR-based diagnosis for Chagas' disease in Bolivian children living in an active transmission area: comparison with conventional serological and parasitological diagnosis. Parasitology, v. 114 (Pt4), p. 367-373, 1997.  
#### **PARTE II – TRATAMENTO ETIOLÓGICO DA DOENÇA DE CHAGAS**  
Para o tratamento etiológico da doença de Chagas, há dois medicamentos principais: benznidazol e nifurtimox. Ambos os compostos são efetivos em reduzir a duração e a gravidade clínica da doença. Outros medicamentos vêm sendo avaliados em contexto de pesquisa, como o alopurinol e os antifúngicos azólicos, não fazendo parte do escopo desta diretriz.  
O benznidazol é o fármaco com maior experiência de uso em nosso meio e maior disponibilidade se comparado ao nifurtimox.  
#### **Eventos adversos associados aos antiparasitários**  
Com o uso de benznidazol, a frequência de eventos adversos é de cerca de 53%. Destacam-se parestesias (10,3%), artralgias (8,1%) e intolerância gastrointestinal (13,3%). Eventos adversos dermatológicos ocorrem com maior frequência: alopécia (0,9%), dermatites (44%) e _rash_ (30%), geralmente não levando à necessidade de descontinuação de tratamento. Alguns sintomas, como parestesias (polineuropatia periférica), podem ter importante impacto sobre funcionalidade e qualidade de vida, podendo permanecer por alguns meses após a interrupção do tratamento. Podem também ocorrer complicações mais graves, como depressão da medula óssea com neutropenia, sendo oportuna a realização de hemograma 3 semanas após o início do tratamento (Brasil, 2013).  
O nifurtimox possui frequência de eventos adversos gerais na ordem de 85%; os mais comuns são intolerância gastrointestinal (61%), eventos reumatológicos (artralgias) (33%) e acometimento dermatológico (15%).  
68  
#### **Valores e preferências dos pacientes com doença de Chagas**  
Estudos de qualidade de vida em pessoas com doença de Chagas são pouco frequentes e utilizam instrumentos variados para aferição. Quatro estudos avaliaram pessoas com doença de Chagas utilizando um instrumento de qualidade de vida genérico ( _World Health Organization. Quality of Life-Bref_ , WHOQoL-bref), embora com diferentes metodologias. Hueb e Loureiro (2005) verificaram que pessoas com doença de Chagas estavam significativamente insatisfeitos com sua qualidade de vida, sua saúde geral e seu desempenho em atividades diárias gerais (M F D Hueb, 2005). Ozaki Guariento e Almeida (2011) demonstram que os piores escores de qualidade de vida estavam relacionados à maior intensidade de sintomas depressivos (Ozaki Y, 2011). Dias (2009) encontrou escores mais baixos no domínio ambiental na doença de Chagas; além disso, observou que a pior percepção de qualidade de vida no domínio físico estava relacionada maior número de comorbidades nos casos com as formas cardíaca e digestiva (Dias, 2009). Gontijo _et al._ (2009) verificaram que a forma cardíaca da doença está associada a maior sofrimento psicológico (Gontijo, 2009). Em relação à qualidade de vida relacionada à saúde (HRQoL), os resultados de Oliveira _etal_ (2011) apontam para piores escores nos domínios de capacidade funcional do _36-Item Short Form Survey_ (SF-36) e de aspectos emocionais do _Minnesota Living With Heart Failure Questionnaire_ (MLWHFQ), em comparação com a população geral (Oliveira _et al._ , 2011).  
A fim de obter parâmetros de utilidade para os estados de saúde de doença de Chagas, foi realizada análise preliminar de estudo primário com 65 adultos com doença de Chagas em acompanhamento ambulatorial em Campinas, São Paulo. Considerando adultos com doença crônica indeterminada, a qualidade de vida, medida por meio do índice de utilidade, foi de 0,622 (IC95% 0,552 a 0,693). Em casos com comprometimento digestivo, a qualidade de vida foi de 0,719 (IC95% 0,575 a 0,863). A qualidade de vida foi baixa em pessoas com comprometimento cardíaco (0,589; IC95% 0,506 a 0,672) e com comprometimento cardíaco e digestivo (0,569; IC95% 0,344 a 0,796). O índice de utilidade médio da população adulta brasileira é de 0,85 (Santos _et al._ , 2016).  
#### **Tratamento etiológico da doença de Chagas na fase aguda**  
**QUESTÃO 3: DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE INDIVÍDUOS COM DOENÇA DE CHAGAS NA FASE AGUDA? Recomendação 3.1: Recomendamos utilizar antiparasitários (benznidazol ou nifurtimox) no tratamento de indivíduos com doença de Chagas na fase aguda (evidência moderada, recomendação forte).**  
**Recomendação 3.2: Recomendamos utilizar benznidazol como primeira opção no tratamento de indivíduos com doença de Chagas na fase aguda (evidência muito baixa, recomendação forte).**  
#### **<u>Resumo das evidências:</u>**  
Estudos observacionais avaliaram a negativação dos testes sorológicos ou parasitológicos (xenodiagnóstico) da doença de Chagas em 40 a 100% com o uso de benznidazol e nifurtimox (estudos listados abaixo).  
Entre os casos avaliados, 45 a 91,7% dos tratados com benznidazol tinham ECG normal em avaliações subsequentes, e em 75% dos casos tratados com nifurtimox as alterações eletrocardiográficas não persistiram. Contudo, o pequeno número de pessoas com doença de Chagas avaliadas e o curto período de seguimento inviabilizam conclusões sobre seu efeito em  
69  
relação aos desfechos cardiovasculares. Não foram identificados estudos comparando diretamente o benznidazol e o nifurtimox.  
#### **<u>Considerações</u>** <u>:</u>  
Benznidazol deve ser a primeira opção devido a maior experiência de uso em nosso meio, maior disponibilidade e menor perfil de eventos adversos; o Nifurtimox pode ser utilizado nos casos em que o benznidazol não seja adequadamente tolerado ou não esteja disponível. Em pacientes assintomáticos ou na impossibilidade da confirmação diagnóstica, mas com forte suspeita pela avaliação clínica e vinculo epidemiológico (por exemplo, sinais e sintomas característicos e evidência de picada pelo triatomíneo), o tratamento empírico pode ser considerado.  
Não há evidências suportando recomendação para controle sorológico pós tratamento ou retratamento após curso terapêutico completo. O controle da resposta clínica utilizando, por exemplo, PCR é restrito a atividades de pesquisa. Os casos suspeitos de doença de Chagas agudo são de notificação compulsória às autoridades locais, segundo a Portaria SVS/MS nº 104, de 25 de janeiro de 2011. Ainda, deve-se ter melhor controle e registro de uso de medicamentos antiparasitários, especialmente para o uso do nifurtimox, quanto aos efeitos adversos e tolerância da droga.  
#### **Lista de estudos incluídos nas revisões sistemáticas relativas ao tratamento com benznidazol na fase aguda:**  
1. Bastos, Claudilson J. C. et al. “Clinical Outcomes of Thirteen Patients with Acute Chagas Disease Acquired through Oral Transmission from Two Urban Outbreaks in Northeastern Brazil.” Ed. Photini Sinnis. **PLoS Neglected Tropical Diseases** 4.6 (2010): e711, July 2017.  
2. <mark>CANÇADO, J Romeu. Long Term Evaluation of Etiological Treatment of Chagas Disease with Benznidazole.</mark> **<mark>Revista do Instituto de Medicina Tropical de São Paulo</mark>** <mark>, v. 1, n. 44, p.29-37, jan./fev. 2002.</mark>  
3. <mark>CASTRO, Cleudson; EMANUEL, Antonio. COMPORTAMENTO DA PARASITEMIA AVALIADA PELO MÉTODO DE STROUT MODIFICADO EM CHAGÁSICOS AGUDOS EM TRATAMENTO.</mark> **Revista da Sociedade Brasileira de Medicina Tropical** <mark>, v. 4, n. 21, p.177180, out./dez. 1988.</mark>  
4. <mark>DE OLIVEIRA-FERREIRA, Humberto. Ensaio Terapêutico-Clínico com o Benzonidazol na Doença de Chagas.</mark> **<mark>Revista do Instituto de Medicina Tropical de São Paulo</mark>** <mark>, v. 5, n. 18, p.357-364, set./out. 1976.</mark>  
5. <mark>DIAS, Juarez Pereira et al. Acute Chagas disease outbreak associated with oral transmission.</mark> **Revista da Sociedade Brasileira de Medicina Tropical** <mark>, v. 3, n. 41, p.296-300, maio/jun. 2008.</mark>  
6. <mark>PINTO, Ana Yecê das Neves et al. Clinical Follow-Up of Responses to Treatment with Benznidazol in Amazon: A Cohort Study of Acute Chagas Disease.</mark> **<mark>Plos One</mark>** <mark>, v. 8, n. 5, p.e64450, 27 maio 2013.</mark>  
7. <mark>VALENTE, Sebastião Aldo da Silva et al. Analysis of an acute Chagas disease outbreak in the Brazilian Amazon: human cases, triatomines, reservoir mammals and parasites.</mark> **<mark>Transactions of The Royal Society of Tropical Medicine And Hygiene</mark>** <mark>, v. 103, n. 3, p.291-297, mar. 2009.</mark>  
#### **Lista de estudos incluídos nas revisões sistemáticas relativas ao tratamento com nifurtimox na fase aguda:**  
1. CASTRO, Cleudson; EMANUEL, Antonio. COMPORTAMENTO DA PARASITEMIA AVALIADA PELO MÉTODO DE STROUT MODIFICADO EM CHAGÁSICOS AGUDOS EM TRATAMENTO. Revista da Sociedade Brasileira de Medicina Tropical, v. 4, n. 21, p.177-180, out./dez. 1988.  
70  
2. <mark>CERISOLA, José Alberto. Evolución serológica de pacientes con enfermedad de Chagas aguda tratados con Bay 2502.</mark> **<mark>Boletin Chileno de Parasitologia</mark>** <mark>, v. 24, p.54-59, 1969.</mark>  
3. <mark>FERNÁNDEZ, Juan J; A CEDILLOS, Rafael; A GODOY, Gerardo. Tratamiento de la enfermedad de Chagas aguda con Bay 2502.</mark> **<mark>Boletin Chileno de Parasitologia</mark>** <mark>, v. 24, p.5153, 1969.</mark>  
4. <mark>REBOSOLÁN, Juan B. Sensibilidad de los métodos de diagnóstico parasitológico en pacientes con enfermedad de Chagas aguda tratados con Bay 2502.</mark> **<mark>Boletin Chileno de Parasitologia,</mark>** <mark>v. 24, p.49-50, 1969.</mark>  
5. <mark>RUBIO, Mafalda; DONOSO, Fernando. Enfermedad de Chagas en niños y tratamiento con Bay 2502.</mark> **<mark>Boletin Chileno de Parasitologia</mark>** <mark>, v. 24, p.43-48, 1969.</mark>  
6. <mark>SCHMUÑIS, A G et al. Immunoglobulin concentration in treated human acute Chagas' disease.</mark> **<mark>Annals Of Tropical Medicine,</mark>** <mark>v. 27, p.473-477, 1978.</mark>  
7. <mark>URRUTIA, Luis Ernesto; RAMÍREZ, Ricardo; RUIZ, Julio César. Acute Chagas' disease and chagasic myocarditis in 40 children under 12 years old controlled for up to 5 years in the hospital Benjamin Bloom.</mark> **<mark>Revista del Instituto de Investigaciones Medicas 5(2): 154-159.</mark>** <mark>, maio/jun. 1976.</mark>  
8. <mark>WEGNER, D H; ROHWEDDER, R W. The effect of nifurtimox in acute Chagas' infection.</mark> **<mark>Arzneimittelforschung,</mark>** <mark>v. 22, p.1624-1635, 1972.</mark>  
#### **Tratamento etiológico da doença de Chagas na fase crônica**  
A fase crônica da doença de Chagas inclui a forma indeterminada (sem sintomas) e as formas cardíaca, digestiva ou cardiodigestiva. Ao longo da vida, cerca de 10 a 30% das pessoas com doença de Chagas evoluem para formas com manifestações clínicas (Villar _et al._ , 2014; Bern, 2015). Há incertezas em relação ao benefício e ao risco do tratamento etiológico de casos com doença de Chagas crônica. Apesar de recomendado, é considerada incerta a eficácia do tratamento etiológico na fase crônica de longa duração, especialmente em indivíduos na faixa etária acima de 50 anos. Importante salientar que indivíduos com doença de Chagas em forma crônica devem realizar avaliações periódicas, com realização de exames complementares, como eletrocardiograma, quando adequado.  
#### **QUESTÃO 4: DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE CRIANÇAS E ADOLESCENTES COM DOENÇA DE CHAGAS NA FASE CRÔNICA INDETERMINADA?**  
**Recomendação 4.1: Recomendamos utilizar benznidazol em crianças e adolescentes com doença de Chagas em fase crônica indeterminada (evidência moderada, recomendação forte).**  
**Recomendação 4.2: Sugerimos utilizar nifurtimox no caso de intolerância ao benznidazol (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática com metanálise. Estudos mostraram maior taxa de negativação sorológica com o uso de benznidazol em relação a placebo (48,1% vs. 12,8%; risco relativo [RR] 4,0; IC95% 2,3 a 6,8); e a progressão para forma cardíaca foi inferior com o uso de benznidazol, apesar de a diferença não ser significativa (6,6% vs. 9,0%; RR 0,70; IC95% 0,32 a 1,52). Importante salientar que há uma potencial variabilidade no benefício do tratamento antiparasitário, de acordo com a região geográfica, o que pode estar associado ao genótipo do parasita. Estudo observacional, não comparativo realizado na América Latina avaliou a soroconversão após tratamento com benznidazol em 2.840 crianças e adolescentes; as taxas de soroconversão foram bastante variáveis, sendo 3,1% na Bolívia, 58% na Guatemala e 87% em Honduras (Yun _et al._ , 2009).  
71  
Em relação ao uso de nifurtimox, a progressão cardíaca foi de 6% em 3 anos e a negativação variou de 0 a 100% em diferentes estudos.  
#### **<u>Considerações</u>** <u>:</u>  
Em crianças e adolescentes, a taxa de negativação sorológica é relativamente alta e os antiparasitários geralmente são bem tolerados. Devido a esses fatores, associados à maior expectativa de vida dessa população, espera-se que o tratamento possua efetividade superior em comparação aos adultos. Contudo, as evidências para a prevenção de manifestações clínicas da doença de Chagas são fracas, em especial devido ao curto período de seguimento nos estudos clínicos.  
As evidências para o uso de nifurtimox são menores, porém esse medicamento pode ser considerado como alternativa no caso de indisponibilidade do benznidazol ou não tolerância a esse medicamento, devendo ser a decisão compartilhada com pacientes e familiares.  
#### **Lista de estudos incluídos nas revisões sistemáticas relativas ao tratamento com benzonidazol em crianças e adolescentes:**  
<mark>1. ANDRADE, Ana Lucia S S et al. Short report: benznidazole efficacy among trypanosoma cruzi−infected adolescents a|er a six-year follow-up.</mark> **<mark>American Society of Tropical Medicine And Hygiene</mark>** <mark>, v. 5, n. 71, p.594-597, 2004.</mark>  
<mark>2. COLANTONIO, Lisandro D. et al. Electrocardiographic Abnormalities and Treatment with Benznidazole among Children with Chronic Infection by Trypanosoma cruzi: A Retrospective Cohort Study.</mark> **<mark>Plos Neglected Tropical Diseases,</mark>** <mark>v. 10, n. 5, p.e0004651, 9 maio 2016.</mark>  
<mark>3. ESTANI, Sergio Sosa et al. Efficacy of chemotherapy with benznidazole in children in the indeterminate phase of Chagas’ disease.</mark> **<mark>American Society of Tropical Medicine and Hygiene</mark>** <mark>, v. 4, n. 59, p.526-529, 1998.</mark>  
<mark>4. RUMI, M M Monje et al. Benznidazole treatment in chronic children infected with Trypanosoma cruzi: Serological and molecular follow-up of patients and identification of Discrete Typing Units.</mark> **<mark>Acta Tropica</mark>** <mark>, v. 128, n. 1, p.130-136, out. 2013.</mark>  
<mark>5. SILVEIRA, Celeste A N; CASTILLO, Edwin; CASTRO, Cleudson. Avaliação do tratamento específico para o Trypanosoma cruzi em crianças, na evolução da fase indeterminada.</mark> **<mark>Revista da Sociedade Brasileira de Medicina Tropical</mark>** <mark>, v. 2, n. 33, p.191196, mar./abr. 2000.</mark>  
**<mark>6.</mark>** <mark>YUN, Oliver et al. Feasibility, drug safety, and effectiveness of etilogical treatment programs for Chagas disease in Honduras, Guatemala, and Bolivia: 10-year experience of Médecins Sans Frontières.</mark> **<mark>Plos Neglected Tropical Diseases,</mark>** <mark>v.3, p. 1-8, 2009</mark> **<mark>.</mark>**  
#### **Lista de estudos incluídos nas revisões sistemáticas relativas ao tratamento com nifurtimox em crianças e adolescentes:**  
1. <mark>BIANCHI, Fiorella et al. Follow-up of an Asymptomatic Chagas Disease Population of Children after Treatment with Nifurtimox (Lampit) in a Sylvatic Endemic Transmission Area of Colombia.</mark> **<mark>Plos Neglected Tropical Diseases</mark>** <mark>, v. 9, n. 2, p.e0003465, 27 fev. 2015.</mark>  
2. <mark>CICHERO, Julio A; SEGURA, Elsa; QUATROCHI, Juan C. Evolución clínico-parasitológica y tolerancia a la droga de 33 niños con infección chagásica crónica tratados con Bay 2502.</mark> **<mark>Boletin Chileno de Parasitologia</mark>** <mark>, v. 1, n. 24, p.59-62, jan/mar. 1969.</mark>  
3. <mark>RUBIO, Mafalda; DONOSO, Fernando. Enfermedad de Chagas en niños y tratamiento con Bay 2502.</mark> **<mark>Boletin Chileno de Parasitologia</mark>** <mark>, v. 24, p.43-48, 1969.</mark>  
72  
**Lista de estudos incluídos nas revisões comparando o tratamento com benznidazol versus nifurtimox em crianças e adolescentes:**  
1. DE OLIVERIA FERREIRA, Humberto. Tratamento da forma indeterminada da doença de chagas com nifurtimox e benzonidazol. **Revista da Sociedade Brasileira de Medicina Tropical** , v. 23, p. 209-211, 1990.  
2. LEVI, Guido C. et al. Etiological drug treatment of human infection by trypanosoma cruzi. **Revista do Instituto de Medicina Tropical de São Paulo** , v. 38, p. 35-38, 1996.  
3. SCHENONE, Hugo et al. Estudio longitudinal de la persistencia de la acción terapêutica del nifurtimox y del benznidazol em pacientes com infección chagásica crónica. **Boletin Chileno de Parisitologia** , v. 35, p. 59-62, 1981.  
4. STREIGER, Mirtha L. et al. Estudo longitudinal e quimioterapia específica em crianças, com doença de Chagas crônica, residentes em área de baixa endemicidade da República Argentina. **Revista da Sociedade Brasileira de Medicina Tropical** , v. 37, p. 365-375, 2004.  
#### **QUESTÃO 5: DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE ADULTOS COM DOENÇA DE CHAGAS NA FASE CRÔNICA COM FORMA INDETERMINADA?**  
**Recomendação 5.1: Sugerimos utilizar benznidazol em adultos com idade abaixo de 50 anos com doença de Chagas em fase crônica indeterminada (evidência baixa, recomendação fraca).**  
**Recomendação 5.2: Sugerimos não utilizar benznidazol como tratamento de rotina em adultos com idade superior a 50 anos com doença de Chagas em fase crônica indeterminada (evidência muito baixa, recomendação fraca).**  
**Recomendação 5.3. Sugerimos não utilizar nifurtimox em adultos com doença de Chagas em fase crônica indeterminada (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática, na qual foram incluídos estudos observacionais e ensaios clínicos.  
Benznidazol diminuiu a progressão cardíaca (RR 0,53; IC95% 0,21 a 1,35) e aumentou a negativação sorológica (RR 4,47; IC95% 0,59 a 33,97), sem atingir significância estatística. Houve redução de mortalidade geral entre esses casos (RR 0,28, IC95% 0,10 a 0,77), porém a probabilidade de erro nesta taxa é grande, devido ao número de eventos muito pequeno nos grupos avaliados. Ensaio clínico não randomizado avaliando 566 pessoas com idade entre 30 e 50 anos observou menor progressão da doença (RR 0,24; IC95% 0,1 a 0,59), menor desenvolvimento de anormalidades eletrocardiográficas ( _hazard ratio_ [HR] 0,27, IC95% 0,13 a 0,57) e maior taxa de negativação sorológica (15% vs. 6%; RR 2,1; IC95% 1,06 a 4,06) com o uso do benznidazol (Viotti _et al._ , 2006). Em relação ao nifurtimox, estudos observacionais não mostraram redução do risco de mortalidade (RR 1,67, IC95% 0,16 a 17,42), mas houve negativação parasitológica entre 90 a 100% dos casos que usaram medicamento. A frequência de eventos adversos foi de 53% com benznidazol e de 85% com nifurtimox.  
#### **<u>Considerações</u>**  
O benefício do tratamento antiparasitário em adultos é incerto, não sendo suficiente para recomendar fortemente o tratamento; a incidência de eventos adversos é considerável, com impacto funcional e na qualidade de vida, apesar de raramente conferirem gravidade. A  
73  
decisão quanto ao tratamento com benznidazol deve ser compartilhada entre médico e paciente, apresentando potenciais riscos, visto que o benefício pode não ser tão expressivo. Em adultos com idade inferior a 50 anos, as vantagens parecem superar as desvantagens, e a evidência de benefício na prevenção de doença cardíaca é maior; assim, o tratamento deve ser considerado. Em pessoas com doença de Chagas e mais de 50 anos, o benefício tem maior grau de incerteza, não sendo sugerido como tratamento de rotina. Contudo, o tratamento pode ser considerado, principalmente em pessoas infectadas durante a vida adulta, que possuem maior expectativa de vida e ausência de comorbidades. Não é realizada monitoração sorológica pós-tratamento ou retratamento em casos com doença de Chagas, devendo essas situações serem restritas ao contexto de pesquisa.  
Em mulheres em idade fértil com doença de Chagas na fase crônica, o tratamento antiparasitário pode trazer benefício adicional, devido à potencial diminuição no risco de transmissão congênita (Fabbro _et al._ , 2014; Moscatelli _et al._ , 2015). É importante orientar essas mulheres a fazerem uso de métodos anticoncepcionais durante o período de tratamento com antiparasitários.  
Pelo pequeno número de publicações avaliando o uso do nifurtimox, menor disponibilidade e maior ocorrência de eventos adversos, seu uso não é recomendado. Contudo, ele pode ser considerado nos casos motivados e com expectativa de maior benefício, como adultos jovens com infecção recente e que não toleraram o benznidazol.  
#### **Lista de estudos incluídos nas revisões avaliando o tratamento com benznidazol em adultos com doença de Chagas na forma crônica indeterminada:**  
1. <mark>AGUIAR, C et al. Evaluation of adverse side effects in a group of benznidazole treated patients. In: 6</mark><sup>th</sup> <mark>EUROPEAN CONGRESS ON TROPICAL MEDICINE AND INTERNATIONAL HEALTH and and 1</mark><sup>st</sup> <mark>MEDITERRANEAN CONFERENCE ON MIGRATION AND TRAVEL HEALTH, 2009.</mark> **Abtracts.** <mark>2009. v. 14 (Suppl 2), p. 180.</mark>  
2. <mark>AGUIAR, Camila et al. Serological profiles and evaluation of parasitaemia by PCR and blood culture in individuals chronically infected by Trypanosoma cruzi treated with benzonidazole.</mark> **<mark>Tropical medicine & International Health,</mark>** <mark>v. 3, n. 17, p.368-372, dez. 2012.</mark>  
3. <mark>ALDASORO, E et al. Arthritis and benznidazole: more closely related than we thought.</mark> **<mark>Antimicrobial Agents and Chemotherapy,</mark>** <mark>v. 59, n. 1, p.727-729, 10 nov. 2015.</mark>  
4. ÁLVAREZ, María Gabriela et al. New scheme of intermittent benznidazole administration in patients chronically infected with Trypanosoma cruzi: a pilot short-term follow-up study with adult patients. **Antimicrobial Agents and Chemotherapy** , v. 60, n. 2, p.833-837, 23 nov. 2016  
5. <mark>ÁLVAREZ, María Gabriela et al. Seronegative conversion after incomplete benznidazole treatment in chronic Chagas disease.</mark> **<mark>Transactions of The Royal Society of Tropical Medicine and Hygiene,</mark>** <mark>v. 106, n. 10, p.636-638, 2012.</mark>  
6. <mark>ANDRADE, Monica Coelho et al. Clinical and serological evolution in chronic Chagas disease patients in a 4-year pharmacotherapy follow-up: a preliminary study.</mark> **<mark>Revista da Sociedade Brasileira de Medicina Tropical</mark>** <mark>, v. 46, n. 6, p. 776-778, dec. 2013.</mark>  
7. <mark>BERTOCCHI, G L et al. Clinical characteristics and outcome of 107 adult patients with chronic Chagas disease and parasitological cure criteria.</mark> **<mark>Transactions of the Royal Society of Tropical Medicine and Hygiene,</mark>** <mark>v. 107, n. 6, p.372-376, 23 abr. 2013.</mark>  
74  
8. <mark>CARRILERO, Bartolomé et al. Side effects of benznidazole treatment in a cohort of patients with Chagas disease in non-endemic country.</mark> **<mark>Revista Española de Quimioterapia,</mark>** <mark>v. 3, n. 24, p.123-126, set. 2011.</mark>  
9. COURA JR et al. Estudo comparativo controlado com emprego de benznidazole, nifurtimox e placebo, na forma crônica da doença de Chagas, em uma área de campo com transmissão interrompida: I. Avaliação preliminar. Revista da Sociedade Brasileira de Medicina Tropical, v. 30, p. 139-144, mar-abr. 1997.  
10. <mark>DE PONTES, Vânia Maria Oliveira et al. Reações adversas em pacientes com doença de Chagas tratados com benzonidazol, no estado do Ceará.</mark> **<mark>Revista da Sociedade Brasileira de Medicina Tropical</mark>** <mark>, v. 43, n. 2, p. 182-187, Apr. 2010.</mark>  
11. <mark>FRAGATA-FILHO, Abilio Augusto et al. Evaluation of parasiticide treatment with benznidazol in the electrocardiographic, clinical, and serological evolution of Chagas disease.</mark> **<mark>Plos Neglected Tropical Diseases,</mark>** <mark>v. 10, n. 3, p. e0004508, 14 mar. 2016.</mark>  
12. <mark>LAUCELLA, Susana A et al. Changes in Trypanosoma cruzi–specific immune responses after treatment: surrogate markers of treatment efficacy.</mark> **Clinical Infectious Diseases** <mark>, v. 49, n. 11, p.1675-1684, dez. 2009.</mark>  
13. <mark>MACHADO-DE-ASSIS, Girley Francisco et al. A serological, parasitological and clinical evaluation of untreated Chagas disease patients and those treated with benznidazole before and thirteen years after intervention.</mark> **Memórias do Instituto Oswaldo Cruz** <mark>, v. 108, n. 7, p.873-880, nov. 2013.</mark>  
14. <mark>MILLER, D A et al. Tolerance of benznidazole in a United States Chagas disease clinic.</mark> **<mark>Clinical Infectious Diseases,</mark>** <mark>v. 60, n. 8, p.1237-1240, 18 jan. 2015.</mark>  
15. <mark>MOLINA, I et al. Toxic profile of benznidazole in patients with chronic Chagas disease: risk factors and comparison of the product from two different manufacturers.</mark> **<mark>Antimicrobial Agents and Chemotherapy</mark>** <mark>, v. 59, n. 10, p.6125-6131, 20 jul. 2015.</mark>  
16. <mark>MOLINA, Israel et al. Randomized trial of posaconazole and benznidazole for chronic Chagas' disease.</mark> **<mark>New England Journal of Medicine</mark>** <mark>, v. 370, n. 20, p.1899-1908, 15 maio 2014.</mark>  
17. <mark>MORILLO, Carlos A et al. Randomized trial of benznidazole for chronic Chagas’ cardiomyopathy.</mark> **<mark>New England Journal of Medicine</mark>** <mark>, v. 373, n. 14, p.1295-1306, out. 2015.</mark>  
18. <mark>VIOTTI R et al. Long-term cardiac outcomes of treating chronic Chagas disease with benznidazole versus no treatment.</mark> **<mark>Ann Intern Med</mark>** <mark>144: 724-734, 2006</mark>  
19. <mark>VIOTTI, Rodolfo et al. impact of aetiological treatment on conventional and multiplex serology in chronic Chagas disease.</mark> **<mark>Plos Neglected Tropical Diseases</mark>** <mark>, v. 5, n. 9, p.1314-1, 6 set. 2011.</mark>  
20. <mark>VIOTTI, Rodolfo et al. Treatment of chronic Chagas' disease with benznidazole: clinical and serologic evolution of patients with long-term follow-up.</mark> **<mark>American Heart Journal</mark>** <mark>, v. 127, n. 1, p.151-162, jan. 1994.</mark>  
#### **Lista de estudos incluídos nas revisões avaliando o tratamento com nifurtimox em adultos com doença de Chagas na forma crônica indeterminada:**  
75  
1. <mark>BOCANEGRA, C et al. Nifurtimox tolerance in Chagas patients with previous adverse effects to benznidazol. In: 9</mark><sup>th</sup> <mark>EUROPEAN CONGRESS ON TROPICAL MEDICINE AND INTERNATIONAL HEALTH, 2015.</mark> **Abstracts.** <mark>2015. v. 20, p. 332.</mark>  
2. <mark>CANÇADO, J Romeu et al. Segundo ensaio terapêutico com o nifurtimox na doença de Chagas.</mark> **<mark>Revista Goiana de Medicina</mark>** <mark>, n. 22, p.203-233, 1976.</mark>  
3. <mark>COURA JR et al. Estudo comparativo controlado com emprego de benznidazole, nifurtimox e placebo, na forma crônica da doença de Chagas, em uma área de campo com transmissão interrompida: I. Avaliação preliminar.</mark> **<mark>Revista da Sociedade Brasileira de Medicina Tropical</mark>** <mark>, v. 30, p. 139-144, mar-abr. 1997.</mark>  
4. <mark>DA SILVA, Newton Neves et al. Eficácia e tolerância do nitrofurfurilidene na fase crônica da moléstia de Chagas.</mark> **<mark>Revista da Sociedade Brasileira de Medicina Tropical</mark>** <mark>, v. VIII, n. 6, p.325-334, nov./dez. 1974.</mark>  
5. <mark>JACKSON, Yves et al. Tolerance and safety of nifurtimox in patients with chronic Chagas disease.</mark> **<mark>Clinical Infectious Diseases</mark>** <mark>, v. 51, n. 10, p.69-75, 15 nov. 2010.</mark>  
6. <mark>MUNOZ, C et al. Evaluation of nifurtimox treatment of chronic Chagas disease by means of several parasitological methods.</mark> **<mark>Antimicrobial Agents and Chemotherapy</mark>** <mark>, v. 57, n. 9, p.4518-4523, 8 jul. 2013.</mark>  
7. SCHENONE, Hugo et al. Experiencia terapéutica con el Bay 2502 en la infección chagásica crónica del adulto. **Importancia del uso adecuado del xenodiagnóstico. Boletin Chileno de Parasitologia** , n. 24, p.66-69, 1969.  
8. WEGNER, D H; ROHWEDDER, R W. The effect of nifurtimox in acute Chagas' infection. **Arzneimittelforschung** , v. 22, p.1624-1635, 1972.  
#### **QUESTÃO 6. DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE INDIVÍDUOS COM DOENÇA DE CHAGAS NA FASE CRÔNICA DIGESTIVA, SEM COMPROMETIMENTO CARDÍACO?**  
**Recomendação 6. Sugerimos que o tratamento antiparasitário de pacientes com doença de Chagas com comprometimento digestivo seja realizado de acordo com as recomendações dadas ao paciente com doença de Chagas crônica indeterminada ou com cardiopatia, de acordo com presença ou não de doença cardíaca (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Não foram encontradas evidências do uso de benznidazol e nifurtimox em indivíduos com doença de Chagas na fase crônica digestiva sem comprometimento cardíaco.  
#### **<u>Considerações</u>**  
A fisiopatologia da doença aponta para provável ausência de efeitos do tratamento antiparasitário na evolução natural da doença digestiva. A infecção promove destruição das células nervosas, incoordenação motora e dilatação das vísceras, podendo resultar principalmente em megaesôfago e/ou megacólon. Uma vez estabelecidas as complicações digestivas, não há evidências apontando para o benefício do tratamento antiparasitários (Bern _et al._ , 2007; Bern _et al._ , 2011).  
O tratamento deve ser realizado de forma independente da manifestação digestiva. Assim, as recomendações para o tratamento na fase crônica indeterminada se aplicam a casos na fase crônica digestiva, e as recomendações para tratamento na fase crônica cardíaca se aplicam a  
76  
pessoas com doença cardiodigestiva. É importante notar que os casos com megaesôfago podem não tolerar adequadamente o tratamento com benznidazol, levando ao comprometimento na ingestão ou absorção do medicamento devido à fisiopatologia da doença. Esses fatores devem ser individualizados na tomada de decisão conforme sintomatologia clínica das pessoas afetadas. Assim, o tratamento medicamentoso deve ocorrer preferencialmente após a correção do trânsito esofágico.  
**QUESTÃO 7. DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE INDIVÍDUOS COM CARDIOPATIA CHAGÁSICA? Recomendação 7.1. Sugerimos que seja oferecida a oportunidade de tratamento com benznidazol a pacientes com cardiopatia chagásica em fases iniciais, sendo tratar e não tratar alternativas válidas (evidência baixa, recomendação fraca). Recomendação 7.2. Recomendamos não tratar pacientes com cardiopatia chagásica em fase avançada (evidência moderada, recomendação forte). Recomendação 7.3. Recomendamos não utilizar nifurtimox em pacientes com cardiopatia chagásica (evidência muito fraca, recomendação forte).**  
#### **<u>Resumo das evidências</u>**  
No estudo BENEFIT, que envolveu 2.854 pacientes, em sua maioria em fases iniciais da cardiopatia chagásica, a incidência de morte e desfechos cardiovasculares (morte, parada cardíaca reanimada, acidente vascular cerebral, transplante cardíaco, insuficiência cardíaca congestiva, implante de cardiodesfribilador implantável (CDI) ou marcapasso, taquicardia ventricular sustentada) foi semelhante com o uso de benznidazol, comparado a placebo (27,5% vs. 29,1%; HR 0,93; IC95% 0,81 a 1,07). Houve maior taxa de negativação da parasitemia por PCR (55,2% vs. 35,4%; _odds ratio_ [OR] 1,78; IC95% 1,45 a 2,18) e maior incidência de eventos adversos com o uso de benznidazol (23,9% vs. 9,5%; RR 2,5; IC95% 2,1 a 3,0).  
Em análise de subgrupos, verificaram-se resultados distintos nos diversos países, podendo sugerir efeito diferencial do benznidazol de acordo com o genótipo de _T. cruzi_ . Observou-se maior taxa de negativação da PCR para o tripanossomo no Brasil, seguido de Argentina e Bolívia, com piores resultados em El Salvador e Colômbia, sendo a diferença estatisticamente significativa. Em subamostra de casos do Brasil, a incidência do desfecho combinado de morte e eventos cardiovasculares foi inferior com o tratamento (21,4% vs. 18,4%; HR 0,85; IC95% 0,71 a 1,02), havendo tendência para benefício do uso de benznidazol (p=0,06). A ausência de significância pode ser atribuída ao baixo poder estatístico devido ao menor tamanho da amostra; contudo, da mesma forma, resultado atribuível ao acaso não pode ser descartado.  
#### **<u>Considerações</u>**  
Houve entendimento por parte do painel de recomendações que as incertezas impossibilitam a recomendação do tratamento de rotina. Contudo, também há o entendimento de que o tratamento não confere maior gravidade quanto aos efeitos adversos, e o benefício esperado pode ser relevante, havendo pessoas que gostariam de se submeter à terapia, mesmo frente às incertezas.  
Para pessoas com infecção contraída no Brasil, com cardiopatia chagásica em fase inicial, por exemplo, apenas alterações no eletrocardiograma (ECG), com fração de ejeção (FE) normal ao ecocardiograma, ausência de insuficiência cardíaca (IC) e ausência de arritmias graves, entende-se que tratar e não tratar com benznidazol são ambas alternativas válidas. Assim, a sugestão é envolver a pessoa afetada no processo de tomada de decisão compartilhada,  
77  
apresentando os potenciais benefícios e riscos, assim como as incertezas a respeito da efetividade do tratamento.  
Não há subsídios justificando o tratamento de casos com suspeita de infecção contraída fora do Brasil (por exemplo, imigrantes) ou de pessoas com cardiopatia avançada. Não há evidência para recomendar o tratamento com nifurtimox em casos com cardiopatia.  
**Lista de estudos incluídos nas revisões avaliando o tratamento com benznidazol em adultos com cardiopatia chagásica:**  
1. <mark>MORILLO, Carlos A. et al. Randomized trial of benznidazole for chronic Chagas’ cardiomyopathy.</mark> **<mark>New England Journal of Medicine</mark>** <mark>, v. 373, n. 14, p.1295-1306, out. 2015.</mark>  
2. <mark>VIOTTI, Rodolfo et al. Long-term cardiac outcomes of treating chronic Chagas disease with benznidazole versus no treatment. Annals of Internal Medicine. V. 144, p. 724-734, 2006.</mark>  
#### **PARTE III- TRATAMENTO ETIOLÓGICO DA DOENÇA DE CHAGAS EM SITUAÇÕES ESPECIAIS**  
As recomendações apresentadas abaixo contemplam situações especiais, como as pessoas com doença de Chagas e imunossupressão (coinfectados por HIV e transplantados) ou gestantes.  
#### **QUESTÃO 8. DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE PACIENTES HIV POSITIVOS E COM DOENÇA DE CHAGAS NA FASE CRÔNICA?**  
A imunossupressão associada ao HIV é um fator de risco importante para reativação da doença de Chagas. A reativação caracteriza-se pelo aumento da parasitemia, semelhante ao quadro agudo, e pela incapacidade do sistema imune em controlar a infecção (Sartori _et al._ , 2007). Pessoas infectadas por HIV com doença de Chagas crônica, seja na forma indeterminada, cardíaca ou digestiva, podem reativar a doença quando imunossuprimidos. Nesses casos, há alta morbimortalidade decorrente de reativação da infecção em sistema nervoso central e miocardite, impactando também na qualidade de vida (Vaidian _et al._ , 2004; Morillo _et al._ , 2017). Os medicamentos antiparasitários podem exercer efeito no controle e na prevenção da reativação, apesar das evidências limitadas.  
**Recomendação 8.1. Recomendamos tratar com antiparasitários pacientes soropositivos para HIV com reativação da doença de Chagas (evidência muito baixa, recomendação forte). Recomendação 8.2. Sugerimos tratar com antiparasitários pacientes soropositivos para HIV com doença de Chagas crônica não tratada e sem reativação (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática na qual foi incluído um estudo observacional avaliando tratamento de pessoas com HIV e reativação da doença (Sartori _et al._ , 2007). O tratamento com benznidazol foi recomendado a 17 pessoas, nove por reativação da doença de Chagas e oito por elevada parasitemia não tratada previamente. Dos nove casos reativados, cinco (55%) vieram a óbito durante o tratamento, três deles por motivos relacionados à doença de Chagas. Os outros quatro casos sobreviveram por mais de 2 meses. Os oito casos que foram tratados pela primeira vez reduziram a parasitemia. Apesar de não terem sido identificados estudos avaliando a efetividade da profilaxia com antiparasitários em pessoas infectadas por HIV, foi identificada na literatura revisão sistemática de estudos observacionais avaliando a  
78  
epidemiologia e evolução da coinfecção _T. cruzi_ /HIV em 291 casos (Almeida _et al._ , 2011). No total, 120 (41,2%) reativaram a doença de Chagas, sendo 89 (74%) em sistema nervoso central e 20 (17%) em miocárdio. Após reativação, tratamento etiológico foi relatado em 100 (34,4%), tendo sido usado benznidazol em 87 e nifurtimox em 14 casos, com mesmo esquema terapêutico utilizado em imunocompetentes. A sobrevida média foi de 10,6 meses para os casos que reativaram e de 2,8 anos para os que não reativaram. Em 59 casos com coinfecção HIV e doença Chagas e contagem de células T CD4+ disponível, aqueles com reativação possuíam contagem média de linfócitos T CD4+ de 98 (variação 1 a 551) e os casos sem reativação possuíam contagem média de 561 (variação 44 a 1.949).  
#### **<u>Considerações</u>**  
Recomenda-se tratar com antiparasitários pessoas infectadas por HIV e doença de Chagas reativada. Esse tratamento deve ser feito na mesma posologia indicada para os casos sem infecção por HIV, sendo o benznidazol a alternativa preferencial devido ao seu melhor perfil de eventos adversos e à maior experiência com o uso.  
Para pessoas infectadas por HIV com doença de Chagas crônica sem reativação e sem tratamento específico prévio, sugere-se tratar, dando preferência ao uso de benznidazol. Para a decisão de tratamento, devem ser levados em consideração fatores como o _status_ imunológico do caso, em especial devido ao risco de síndrome de reconstituição imunológica. Na literatura, há recomendações sugerindo profilaxia secundária, em casos tratados por reativação seguida de remissão clínica e negativação parasitológica, quando os níveis de linfócitos T CD4+ forem menores que 200 células/mm<sup>3</sup> (Brasil, 2014b). Essa recomendação precisa ser validada em estudos prospectivos, uma vez que não há dados embasando seu uso; a presente diretriz não aborda a profilaxia secundária.  
Vem sendo discutida a monitorização de casos com infecção por HIV e doença de Chagas sem reativação por meio de PCR quantitativa. O teste pode detectar precocemente a reativação em sua fase assintomática, podendo ser utilizado no monitoramento clínico, uma vez que permite quantificar a carga parasitária. Contudo, tendo em vista a ausência de estudos sobre o tópico e as limitações em relação à disponibilidade dos exames e à padronização das técnicas laboratoriais, não há subsídios para a sua recomendação de rotina.Casos com infecção por HIV e doença de Chagas devem ser avaliados por especialistas, fora do contexto da APS.  
**Lista de estudos incluídos nas revisões avaliando o tratamento em casos de reativação em pacientes com HIV:**  
1. <mark>SARTORI, A. M. C. et al. Manifestations of Chagas disease (American trypanosomiasis) in patients with HIV/AIDS.</mark> **<mark>Annals Of Tropical Medicine & Parasitology</mark>** <mark>, v. 101, n. 1, p.31-50, jan. 2007.</mark>  
#### **QUESTÃO 9. DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE PACIENTES TRANSPLANTADOS E COM DOENÇA DE CHAGAS NA FASE CRÔNICA?**  
**Recomendação 9.1. Recomendamos tratar com antiparasitários pacientes transplantados com reativação da doença de Chagas em fase crônica (evidência muito baixa, recomendação forte).**  
**Recomendação 9.2. Sugerimos não tratar com antiparasitários pacientes transplantados com doença de Chagas em fase crônica, com o intuito de evitar reativação da doença (evidência muito baixa, recomendação fraca).**  
79  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática na qual foram incluídos estudos avaliando o uso de antiparasitários no tratamento etiológico em casos com doença de Chagas e submetidos a transplante, em sua maioria cardíaco.  
Houve redução de mortalidade entre os casos tratados com benznidazol após reativação. A taxa de reativação foi alta mesmo em vigência de profilaxia. Não há evidência do uso de nifurtimox em casos transplantados.  
#### **<u>Considerações</u>**  
Recomenda-se tratar com antiparasitários aqueles casos transplantados com doença de Chagas reativada. Este tratamento deve ser feito com a mesma posologia do indicada para casos não transplantados, sendo o benznidazol a alternativa preferencial devido ao seu melhor perfil de eventos adversos e maior experiência com o uso.  
Não há base para recomendar profilaxia em casos transplantados; contudo, pode ser considerada em casos selecionados, como, por exemplo, aqueles com maior grau de imunossupressão. Assim como no caso de pessoas infectadas por HIV, a PCR quantitativa pode ser útil no monitoramento clínico, contudo não há subsídio para recomendar seu uso de rotina. Para prevenção de complicações clínicas (por exemplo, cardiopatia) pode-se considerar tratamento etiológico, devendo ser consideradas as mesmas recomendações utilizadas para pessoas com doença de Chagas crônica não imunossuprimidos. Contudo, os estudos não avaliaram o efeito do tratamento, nem os eventos adversos às drogas antiparasitárias em indivíduos com imunossupressão.Casos transplantados com doença de Chagas devem ser avaliados por especialistas, fora do contexto da APS.  
**Lista de estudos incluídos nas revisões avaliando o tratamento em casos de reativação em pacientes transplantados:**  
1. ACTLAS, J et al. Chagas disease in bone marrow transplantation: an approach to preemptive therapy. **Bone Marrow Transplantation** , v. 36, p. 123-129, 2005.  
2. <mark>CAMPOS, Sílvia V. et al. Risk Factors for Chagas' Disease Reactivation After Heart Transplantation.</mark> **<mark>The Journal Of Heart And Lung Transplantation,</mark>** <mark>v. 27, n. 6, p.597-602, jun. 2008</mark>  
3. <mark>DE CARVALHO, V B et al. Heart Transplantation in Chagas' Disease: 10 Years After the Initial Experience.</mark> **<mark>Circulation</mark>** <mark>, v. 94, n. 8, p.1815-1817, 15 out. 1996.</mark>  
4. <mark>DIEZ, M et al. Cardiac Allograft Vasculopathy and Survival after Heart Transplantation for Chagas’ Heart Disease. 2012.</mark> **<mark>A</mark> bstracts.** The Journal of Heart and Lung Transplantation, <mark>2012. v. 31, p. S32 – S33.</mark>  
5. <mark>KANSDORF, E et al. High Rate of Reactivation of Chagas Disease after Heart Transplantation in the United States. 2013. Abstracts. The Journal of Heart and Lung Transplantation, 2013. v. 32, p. S130.</mark>  
6. <mark>RIARTE, A  et al. Chagas’ Disease in patients with kidney transplants: 7 years of experience, 1989-1996.</mark> **<mark>Clinical Infectious Diseases</mark>** <mark>, v. 29, p. 561-7, 1999.</mark>  
7. <mark>SALVADOR, F. et al. Immunosuppression and Chagas disease; experience from a nonendemic country.</mark> **<mark>Clinical Microbiology and Infection</mark>** <mark>, v. 21, n. 9, p.854-860, set. 2015.</mark>  
80  
**Lista de estudos incluídos nas revisões avaliando o tratamento como profilaxia em pacientes transplantados:**  
1. <mark>CAMPOS, Sílvia V. et al. Risk Factors for Chagas' Disease Reactivation After Heart Transplantation.</mark> **<mark>The Journal Of Heart And Lung Transplantation</mark>** <mark>, v. 27, n. 6, p.597-602, jun. 2008</mark>  
2. <mark>DE CARVALHO, V B et al. Heart Transplantation in Chagas' Disease: 10 Years After the Initial Experience.</mark> **<mark>Circulation</mark>** <mark>, v. 94, n. 8, p.1815-1817, 15 out. 1996.</mark>  
#### **QUESTÃO 10. DEVE-SE UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE GESTANTES COM DOENÇA DE CHAGAS?**  
A taxa de transmissão congênita na doença de Chagas aguda varia de 22 a 71%, devido à alta parasitemia (item “Resposta de consulta ao SIAT” no final deste arquivo). Em gestantes com doença de Chagas em fase crônica, a transmissão congênita é de aproximadamente 1 a 2% no Brasil (Martins-Melo, Lima Mda _, et al._ , 2014). O nível de parasitemia está associado ao risco de transmissão congênita; assim, o tratamento com antiparasitários pode reduzir o risco de infecção no recém-nascido. Contudo, há incertezas a respeito da teratogenicidade das drogas antiparasitárias.  
**Recomendação 10.1. Recomendamos tratar com benznidazol gestantes com doença de Chagas aguda grave (evidência muito baixa, recomendação forte). Recomendação 10.2. Sugerimos tratar com benznidazol gestantes com doença de Chagas aguda a partir do segundo trimestre de gestação (evidência muito baixa, recomendação fraca).**  
**Recomendação 10.3. Recomendamos não tratar com antiparasitários gestantes com doença de Chagas na fase crônica (evidência muito baixa, recomendação forte).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão da literatura na qual foram incluídos dois relatos de caso sobre o uso de benznidazol em gestantes no terceiro trimestre de gestação, não sendo descrito nenhum caso de malformações fetais (Bisio _et al._ , 2013; Corrêa _et al._ , 2014). Estudo realizados com ratas grávidas indicaram que o benznidazol é capaz de cruzar a barreira placentária e interagir com proteínas do feto (De Toranzo _et al._ , 1984). Ainda, há evidências de que fetos de ratos são capazes de bioativar (por nitrorredução) o fármaco, levando à toxicidade do medicamento (Castro _et al._ , 2006).  
Foi realizado inquérito com médicos no Brasil sobre o uso de antiparasitários em gestantes com doença de Chagas, sendo identificados 16 casos. Destes, 15 foram tratados intencionalmente entre o segundo e o terceiro trimestre de gestação e um caso foi tratado acidentalmente no primeiro trimestre de gestação, com interrupção do uso do medicamento após 10 dias. Os recém-nascidos foram acompanhados e não houve ocorrência de transmissão congênita ou malformação fetal em nenhum dos 16 casos.  
#### **<u>Considerações</u>**  
Em casos onde a mãe apresenta quadro clínico grave de doença de Chagas aguda (por exemplo, miocardite ou meningoencefalite), o tratamento deve ser realizado independentemente da idade gestacional.  
81  
As evidências para malformações são fracas, uma vez que o número de casos relatados é pequeno, entretanto não houve descrição de malformações fetais. Por outro lado, além do risco materno, há certeza do alto risco de transmissão congênita na doença de Chagas aguda e do potencial impacto em saúde de casos de doença de Chagas neonatal. Assim, os membros do painel da diretriz julgaram que os benefícios parecem superar os riscos e sugerem o uso do benznidazol para o tratamento de gestantes com doença de Chagas aguda, preferencialmente a partir do segundo trimestre de gestação, quando o risco de malformações parece ser menor. Gestantes com doença de Chagas aguda não grave diagnosticadas no primeiro trimestre idealmente devem aguardar o segundo trimestre de gestação para realizar o tratamento. Mortalidade perinatal, malformações fetais e doença de Chagas neonatal são complicações relativamente importantes, e a mulher deve ser adequadamente informada sobre riscos e benefícios da abordagem e compartilhar da decisão, sendo justificável o não tratamento nesses casos. O tratamento deve ser realizado com benznidazol devido à maior experiência de uso e menor incerteza em relação a malformações.  
Em gestantes com doença de Chagas em fase crônica, o tratamento não deve ser realizado, uma vez que o risco de transmissão congênita é baixo. Assim, entende-se que o potencial benefício do uso de antiparasitários é pequeno, não justificando os riscos.  
Gestantes com doença de Chagas crônica sem comprometimento cardíaco e sem comorbidades podem ser acompanhadas na APS, enquanto gestantes com doença de Chagas na forma aguda devem receber acompanhamento em serviço especializado. É importante que a notificação compulsória de casos de doença de Chagas integre não apenas a fase aguda como também a crônica, a fim de melhor determinar a ocorrência de eventos neonatais, seja decorrente da infecção ou do uso de antiparasitários.  
Embora o número de casos seja pequeno, há relatos sugerindo maior risco de transmissão congênita e de doença grave no concepto/recém-nascido em caso de gestante com doença de Chagas coinfectada por HIV, o que possivelmente está associado a parasitemia mais alta (Sartori _et al._ , 2007; Scapellato _et al._ , 2009; Hotez e Fujiwara, 2014; Martins-Melo _et al._ , 2016).  
**Lista de estudos incluídos nas revisões avaliando o tratamento em gestantes com doença de Chagas:**  
1. <mark>BISIO, Margarita et al. Benznidazole Treatment of Chagasic Encephalitis in Pregnant Woman with AIDS.</mark> **<mark>Emerging Infectious Diseases</mark>** <mark>, v. 19, n. 9, p.1490-1492, set. 2013.</mark>  
2. <mark>CORRÊA, Valeria Rita et al. Uneventful benznidazole treatment of acute Chagas disease during pregnancy: a case report.</mark> **<mark>Revista da Sociedade Brasileira de Medicina Tropical,</mark>** <mark>v. 47, n. 3, p.397-400, jun. 2014.</mark>  
#### **IV – TRATAMENTO DAS COMPLICAÇÕES CLÍNICAS DA DOENÇA DE CHAGAS**  
A doença de Chagas na fase aguda pode ter sintomatologia não específica como febre, malestar e astenia, ou simplesmente ser assintomática. De forma mais rara, porém com alta morbidade, manifestações como hepatoesplenomegalia, meningoencefalite e miocardite aguda podem ocorrer nessa fase. Para o diagnóstico diferencial, devem ser consideradas outras doenças infecciosas como dengue, infecção por zika vírus, chikungunya, hepatites virais, hantaviroses e leptospirose grave (Benziger _et al._ ).  
82  
Uma a três décadas após a infecção aguda, cerca de 10 a 40% das pessoas com doença de Chagas evoluem para as formas cardíacas, digestivas ou cardiodigestivas, com importante impacto na morbimortalidade (Villar _et al._ , 2014).  
#### **COMPLICAÇÕES DIGESTIVAS**  
Pessoas com acometimento digestivo devido à doença de Chagas possuem alterações nas funções motora, secretora e absortiva, devido à denervação autonômica dos órgãos. Megaesôfago e megacólon são complicações comuns, devendo ser manejados de forma semelhante aos casos sem doença de Chagas. O manejo desses casos visa basicamente atenuar os comprometimentos clínicos, facilitando a passagem do alimento para o estômago e estimulando a evacuação. Em relação ao megaesôfago, o uso de medicamentos como nifedipina e dinitrato de isossorbida podem ajudar no alívio dos sintomas e vem sendo proposto na doença de Chagas. Pessoas com sintomas graves devem ser acompanhadas por especialistas para avaliar a indicação de terapias adicionais, como dilatação pneumática ou tratamento cirúrgico, que não são abordadas nessa diretriz.  
Deve-se prestar atenção ao diagnóstico diferencial da doença de Chagas na forma gastrointestinal. Outras condições como acalasia primária idiopática, amiloidose, sarcoidose, neurofibrimatose, gastrenterite eosinofílica, coinfecção por _H. pylori_ , refluxo e tumores devem ser consideradas conforme queixa clínica. No caso de constipação, esta pode estar relacionada a malignidade, distúrbios metabólicos, amiloidose e esclerose sistêmica. A investigação, além de exame clínico, consiste principalmente no uso de exames de imagem como radiografia convencional ou contrastada e endoscopia, devendo ser utilizados em especial para excluir neoplasias.  
#### **QUESTÃO 11.DEVE-SE UTILIZAR NIFEDIPINA NO TRATAMENTO DE PACIENTES COM MEGAESÔFAGO CHAGÁSICO SINTOMÁTICO? Recomendação 11.1 Sugerimos utilizar nifedipina em pacientes com megaesôfago chagásico para alívio sintomático (evidência muito baixa, recomendação fraca). Recomendação 11.2 Sugerimos não utilizar nifedipina em pacientes com cardiopatia grave (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada uma revisão sistemática que incluiu dois estudos do tipo antes e depois (Dantas _et al._ , 1986; Figueiredo _et al._ , 1992). Estudo avaliando a pressão do esfíncter esofágico ( _lower esophageal sphincter pressure_ , LESP) de pacientes com megaesôfago chagásico mostrou diminuição da LESP em 60% comparado à de repouso em 35 min após o uso da nifedipina. Outro estudo avaliou o esvaziamento esofágico de pacientes com megaesôfago chagásico e observou que o uso da nifedipina não alterou o esvaziamento esofágico, quando comparado ao grupo não tratado.  
#### **QUESTÃO 12.DEVE-SE UTILIZAR ISOSSORBIDA NO TRATAMENTO DE PACIENTES COM MEGAESÔFAGO CHAGÁSICO SINTOMÁTICO?**  
**Recomendação 12.1 Sugerimos utilizar isossorbida em pacientes com megaesôfago chagásico para alívio sintomático (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática que incluiu seis estudos observacionais e um ensaio clinico _crossover_ .  
83  
A isossorbida reduziu a LESP em 9,65 mmHg (IC95% 7,54 a 11,76) e aumentou o esvaziamento esofágico em 22,1% (IC95% 14,41 a 29,80). Ensaio clínico _crossover_ avaliou a disfagia de pessoas com megaesôfago chagásico e concluiu que houve relato de melhora da frequência e da gravidade da disfagia quando tratadas com isossorbida.  
#### **<u>Considerações sobre uso de nifedipina e dinitrato de isossorbida</u>**  
A nifedipina deve ser usada na dose de 10 mg, por via sublingual, 30 minutos antes de cada refeição. Já o dinitrato do isossorbida deve ser usado na dose de 2,5 a 5 mg, por via sublingual, 15 minutos antes de cada refeição. O efeito é essencialmente sintomático e a alta taxa de eventos adversos prejudica a adesão, mas não confere maior risco. Em geral, pode-se tentar o seu uso em casos com sintomas de megaesôfago sem resposta adequada a medidas não farmacológicas, descontinuando a medicação caso ocorram eventos adversos. A nifedipina possui uma melhor tolerabilidade na população geral, contudo não deve ser utilizada em casos com cardiopatia grave devido ao risco de hipotensão e retenção hidrossalina.  
As pessoas com megaesôfago chagásico podem ser acompanhadas na APS, e os casos com maior intensidade de sintomas podem serem encaminhados a serviço especializado a fim de considerar investigação adicional ou outros tratamentos como cirurgia, dilatação pneumática ou aplicação de toxina botulínica.  
#### **Lista de estudos incluídos nas revisões avaliando o uso de nifedipina em pacientes com megaesôfago chagásico:**  
1. <mark>DANTAS, Roberto Oliveira et al. Effect of nifedipine on the lower esophageal sphincter pressure in Chagasic patients.</mark> **<mark>Brazilian Journal of Medical And Biological Research</mark>** <mark>, n. 19, p.205-209, 1986.</mark>  
2. <mark>FIGUEIREDO, M C A et al. Short report: comparison of the effects of sublingual nifedipine and isosorbide dinitrate on oesophageal emptying in patients with chagasic achalasia.</mark> **<mark>Alimentary Pharmacology & Therapeutics</mark>** <mark>, v. 4, n. 6, p.507-512, ago. 1992.</mark>  
#### **Lista de estudos incluídos nas revisões avaliando o uso de isossorbida em pacientes com megaesôfago chagásico:**  
1. <mark>DANTAS, Roberto Oliveira et al. Efeito do Dinitrato de Isosorbitol na Pressão do Esfíncter Inferior do Esôfago de Pacientes com Doença de Chagas.</mark> **<mark>Arquivos de Gastroenterologia</mark>** <mark>, v. 2, n. 24, p.84-87, abr./jun. 1987.</mark>  
2. <mark>DANTAS, Roberto Oliveira et al. Effect of isosorbide dinitrate and atropine on the lower esophageal sphincter pressure in chagasic patients.</mark> **<mark>Acta Physiologica Et Pharmacologica Latinoamericana</mark>** <mark>, n. 38, p.151-158, 1988.</mark>  
3. <mark>DE OLIVEIRA, Ricardo Brandt de et al. Comparison of the effects of sublingual isosorbide dinitrate and cardiomyotomy on esophageal emptying in patients with chagasic megaesophagus.</mark> **<mark>Arquivos de Gastroenterologia</mark>** <mark>, v. 2, n. 31, p.47-51, abr./jun. 1994.</mark>  
4. <mark>FERREIRA-FILHO, L P et al. Use of isosorbide dinitrate for the symptomatic treatment of patients with Chagas' disease achalasia: a double-blind, crossover trial.</mark> **<mark>Brazilian Journal of Medical And Biological Research</mark>** <mark>, v. 11, n. 24, p.1093-1098, 1991.</mark>  
5. <mark>FIGUEIREDO, M C A et al. Short report: comparison of the effects of sublingual nifedipine and isosorbide dinitrate on oesophageal emptying in patients with chagasic achalasia.</mark> **<mark>Alimentary Pharmacology & Therapeutics</mark>** <mark>, v. 4, n. 6, p.507-512, ago. 1992.</mark>  
84  
6. <mark>MATSUDA, NM et al. Effect of isosorbide dinitrate on gastroesophageal reflux in healthy volunteers and patients with Chagas' disease.</mark> **<mark>Digestive Diseases and Sciences</mark>** <mark>, v. 1, n. 40, p.177-182, jan. 1995.</mark>  
7. <mark>REZENDE-FILHO, Jofre et al. Efeito do dinitrato de isossorbitol sobre o esvaziamento esofagiano no megaesôfago chagásico.</mark> **<mark>Arquivos de Gastroenterologia</mark>** <mark>, v. 3, n. 27, p.115119, jul. 1990.</mark>  
#### **COMPLICAÇÕES CARDIOVASCULARES**  
O comprometimento cardiovascular constitui a mais comum das manifestações da doença de Chagas. Caracteriza-se por apresentar curso lento, sendo necessários em torno de 20 anos de infecção para o surgimento dos primeiros sintomas de IC. A patogênese das lesões cardíacas envolve destruição tissular progressiva pela presença de um processo inflamatório contínuo associado à presença de material genético do parasita e ativação do sistema imune humoral, provocando miocardite crônica e substituição dos miócitos lesionados por fibrose. Alterações eletrocardiográficas são os primeiros indicativos do acometimento cardíaco e possibilitam avaliar evolutivamente a deterioração da função cardíaca. A IC é complicação comum, devendo ser tratada de forma semelhante àquela dos casos com doença devido a outras etiologias (Figura 2), embora seu prognóstico pareça ser pior em comparação ao das demais etiologias.  
A eficácia dos inibidores da enzima conversora de angiotensina (IECA), dos bloqueadores do receptor da angiotensina e dos mineralocorticoides não foi testada de forma controlada e em um número expressivo de pessoas com cardiopatia chagásica. No entanto, tais fármacos são utilizados para o tratamento da IC ao se extrapolarem os resultados dos estudos que testaram essas medicações em populações com IC de etiologia hipertensiva e isquêmica em sua maioria.  
O uso de betabloqueadores exige cautela nos casos com cardiopatia chagásica, visto que, apesar de acrescentar grande benefício ao tratamento dos casos com taquiarritmias e ectopias ventriculares, pode acentuar o grau de bradicardia ou bloqueios do sistema de condução, muito comuns nessa etiologia. Por conta disso, a dose máxima tolerada é muitas vezes inferior à dos estudos em casos com outras cardiopatias.  
85  
**Figura 2. Esquema para tratamento da Insuficiência cardíaca**  
<!-- Start of picture text -->
Assintomatico<br>NYHA |<br>Rerereeeeecceen<br>Inibidor da enzima<br>RUBE4<br><!-- End of picture text -->  
<!-- Start of picture text -->
Sintomatico Refratario<br>NYHA II-III NYHA IV<br>12 droga. covsssteeeceeen ><br>conversora de angiotensina (IECA) *<br>So 28 droga<br>Betabloqueador<br><!-- End of picture text -->  
<!-- Start of picture text -->
——<br>Gee<br>Digoxina<br>Rc<br>Rr<br>(negros,<br><!-- End of picture text -->  
<!-- Start of picture text -->
32 droga<br>Diurético (sinais de congestao)<br>42 droga ee<br>(sintomaticos apesar do uso de IECA, BB e diurético)<br>Espironolactona — =<br>(com disfungao ventricular)<br>Hidralazina-isossorbida ><br>hipertensos ou com intolerancia ao IECA)<br><!-- End of picture text -->  
Fonte: Adaptado de Diretriz Brasileira de Insuficiência Cardíaca Crônica. NYHA: _N_ **_e_** _w York Health Association._ * Na intollerância ao IECA considerar utilização de Bloqueador do Receptor de Angiotensina (ex: loosartana).  
O transplante cardíaco é um **a** opção no manejo dos casos com IC grave de e **t** iologia chagásica. No Brasil, essa condição é **a** terceira causa encaminhamentos para trans **p** lante cardíaco, e registros da Sociedade Brasileira de Cardiologia mostram melhor desem **p** enho relativo no grupo de pessoas afetadas p **e** la doença de Chagas transplantadas.  
As arritmias são comuns, p **o** dendo causar palpitação, tontura, dispneia, li **p** otimia, síncope e morte súbita. A principal cau **s** a de óbito nos casos com cardiopatia é a mort **e** súbita, atingindo 55% a 65% dos casos. O a **c** ometimento do sistema nervoso parassimpático cardíaco e do sistema de condução pode **p** rovocar disfunção do nó sinusal, bloqueios in **t** raventriculares e atrioventriculares e arritmias ventriculares. Mais de 50% dos casos infectados por _T. cruzi_ apresentarão alterações elet **r** ocardiográficas.  
A amiodarona é o antiarrítmico mais comumente utilizado e de baixo custo **,** podendo ser útil no tratamento de pessoas c **o** m doença de Chagas. Contudo, precauções d **e** vem ser tomadas devido ao perfil de eventos **a** dversos, incluindo alterações de função tireoidiana. Pessoas com arritmias graves devem ser **e** ncaminhadas a centros especializados para avaliar a necessidade  
86  
de implante do desfibrilador automático ou de realização de ablação de focos arritmogênicos por cateter.  
#### **QUESTÃO 13.DEVE-SE UTILIZAR AMIODARONA NO TRATAMENTO DE PACIENTES COM CARDIOPATIA CHAGÁSICA NA FORMA CRÔNICA?**  
**Recomendação 13.1. Recomendamos utilizar amiodarona no tratamento de pacientes com cardiopatia chagásica e taquicardia ventricular sustentada ou parada cardiorrespiratória prévia (evidência muito baixa, recomendação forte).**  
**Recomendação 13.2. Sugerimos utilizar amiodarona no tratamento de pacientes com cardiopatia chagásica e taquicardia ventricular não sustentada com alto risco de morte súbita (evidência muito baixa, recomendação fraca).**  
**Recomendação 13.3. Sugerimos não utilizar amiodarona no tratamento de pacientes com cardiopatia chagásica e taquicardia ventricular não sustentada sem alto risco de morte súbita (evidência muito baixa, recomendação fraca).**  
**Recomendação 13.4. Recomendamos não utilizar amiodarona no tratamento de pacientes com cardiopatia chagásica e extra-sístoles ventriculares (evidência muito baixa, recomendação forte).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática que incluiu três estudos observacionais (Bellotti _et al._ , 1983; Chiale _et al._ , 1984; Haedo _et al._ , 1986). Estudos avaliando a taquicardia ventricular em casos com cardiopatia chagásica evidenciaram que amiodarona reduziu em 99,9% os episódios de taquicardia ventricular (IC 99,8 a 100% em Holter de 24 horas), reduziu em 93,1% os batimentos ventriculares prematuros (IC 82 a 97,4% em Holter de 24 horas) e reduziu 79% a incidência de extra-sístoles ventriculares pareadas (RR 0,21; IC95% 0,39 a 0,11). Em um estudo adicional com 14 pessoas afetadas, a amiodarona reduziu os batimentos ventriculares prematuros em 73,2%. Apesar da evidência demonstrando redução de arritmias, não há estudos clínicos adequadamente delineados avaliando a efetividade da amiodarona na prevenção de desfechos clinicamente relevantes, como morte súbita, e não há certeza de que a redução de arritmias identificada em Holter está associada a benefício clínico direto.  
#### **<u>Considerações sobre uso da amiodarona</u>**  
Em doença de Chagas, as evidências para seu uso são fracas, baseadas principalmente em desfechos substitutos e estudos em IC de outras etiologias, não havendo clara relação com eventos clinicamente relevantes. Assim, a decisão quanto ao uso de amiodarona deverá levar em conta a avaliação de riscos e benefícios.  
Na presença de arritmias potencialmente letais, como taquicardia ventricular sustentada, a amiodarona deverá ser utilizada de rotina em situações como: antecedendo a colocação do CDI, na impossibilidade do uso do CDI, ou ainda em associação ao implante, para diminuir a ocorrência de choque elétrico. Seu uso é sugerido em casos com taquicardia ventricular não sustentada e risco alto para morte súbita (por exemplo, disfunção sistólica do ventrículo esquerdo moderada a grave, escore de Rassi elevado ou áreas de fibrose). Contudo, o benefício esperado é menor e não foi documentado em estudos observacionais ou experimentais de qualidade. Assim, a utilização da amiodarona se dá por uma expectativa de benefício, que deve exceder os efeitos adversos citados abaixo (Villela _et al._ , 2009). Nas outras situações, em geral os riscos superam claramente os benefícios.  
87  
Casos com taquicardia ventricular sustentada ou taquicardia ventricular não sustentada e alto risco de morte súbita devem ser acompanhados em serviços especializados e avaliar a necessidade de colocação de CDI ou ablação de focos arritmogênicos. Os demais casos podem seguir acompanhamento na APS. De todo modo, a pessoa afetada pela doença de Chagas em uso de amiodarona necessita de avaliação clínica regular, sendo aconselhadas consultas no mínimo a cada 3 meses no primeiro ano e a cada 6 meses nos anos seguintes.  
O uso da amiodarona pode raramente levar à fibrose pulmonar e, frequentemente, a hiper ou hipotireoidismo, prolongamento do QT e taquicardia ventricular do tipo _torsades de pointes_ . Associados com antiarrítmicos de classe IA (quinidina, procainamida, disopiramido), antidepressivos tricíclicos, diuréticos tiazídicos e sotalol predispõem a _torsades de pointes_ . A associação com betabloqueadores predispõe à depressão nodal; no entanto, seu efeito é potencializado quando associado a betabloqueadores ou bloqueadores dos canais de cálcio providos de propriedades antiarrítmicas (verapamil, diltiazen). Assim, é importante que a pessoa com doença de Chagas em uso de amiodarona siga acompanhamento clínico regular em serviço especializado, sendo monitorada quanto a potenciais eventos adversos.  
**Lista de estudos incluídos nas revisões avaliando o uso de amiodarona em pacientes com arritmia:**  
1. <mark>BELLOTTI, Giovanni et al. Efeitos eletrocardiográficos e hemodinâmicos do cloridrato de amiodarona por via venosa.</mark> **<mark>Arquivos Brasileiros de Cardiologia</mark>** <mark>, v. 2, n. 40, p.141-144, fev. 1983.</mark>  
<mark>2. CARRASCO, Hugo A et al. Effect of low oral doses of disopyramide and amiodarone on ventricular and atrial arrhythmias of chagasic patients with advanced myocardial damage.</mark> **<mark>International Journal of Cardiology</mark>** <mark>, n. 9, p.425-438, 1958.</mark>  
3. <mark>CHIALE, Pablo A et al. Efficacy of amiodarone during long-term treatment of malignant ventricular arrhythmias in patients with chronic chagasic myocarditis.</mark> **<mark>American Heart Journal</mark>** <mark>, v. 4, n. 107, p.656-665, abr. 1984.</mark>  
<mark>4. GRECO, Oswaldo Tadeu et al. A amiodarona nas arritmias ventriculares da cardiopatia chagásica crônica.</mark> **<mark>Arquivos Brasileiros de Cardiologia</mark>** <mark>, v. 2, n. 35, p.177-181, ago. 1980.</mark>  
<mark>5. HAEDO, Alejandro H et al. Comparative antiarrhythmic efficacy of verapamil, 17monochloracetylajmaline, mexiletine and amiodarone in patients with severe chagasic myocarditis: relation with the underlying arrhythmogenic mechanisms.</mark> **<mark>Journal Of The American College Of Cardiology</mark>** <mark>, v. 5, n. 7, p.1114-1120, maio 1986.</mark>  
<mark>6. ROSENBAUM, Mauricio et al. Estudio clinico multicentrico comparativo de la flecainida y la amiodarona en el tratamiento de las arritmias ventriculares asociadas a la cardiopatia chagasica cronica.</mark> **<mark>Archivos del Instituto de Cardiologia de Mexico</mark>** <mark>, n. 57, p.325-330, 1987.</mark>  
<mark>7. SCANAVACCA, Maurício I et al. Terapêutica empírica com amiodarona em portadores de miocardiopatia chagásica crônica e taquicardia ventricular sustentada.</mark> **<mark>Arquivos Brasileiros de Cardiologia</mark>** <mark>, v. 6, n. 54, p.367-371, 1990.</mark>  
#### **V - RASTREAMENTO DA DOENÇA DE CHAGAS**  
Segundos dados da Organização Mundial da Saúde, há 6 a 7 milhões de pessoas infectadas por _T. cruzi_ mundialmente (WHO, 2002). No Brasil, esses dados variam de 1 a 2,4% na população geral a 17,7% nos acima de 60 anos (Martins-Melo, Ramos _, et al._ , 2014). A transmissão congênita também possui impacto na carga da doença, estando relacionada a complicações neonatais e tardias (Ostermayer _et al._ , 2011). Os inquéritos populacionais são em sua grande maioria realizados em regiões endêmicas, e processos como surtos de transmissão oral, migração e urbanização tornaram ainda mais complexo o cenário epidemiológico. Além disso,  
88  
a notificação compulsória somente está estabelecida compulsoriamente no País nos casos de doença de Chagas aguda, limitando os números reais da doença no país.  
Com base em fatores epidemiológicos e no entendimento do processo de transmissão da doença de Chagas, estão estabelecidos fatores associados a maior risco de possuir a doença. Entre eles destacam-se ser procedente ou residente em área endêmica, ser habitante de áreas rurais (em especial onde o vetor já foi identificado), ser familiar de pessoas com doença de Chagas conhecida, ou ter sido submetido à transfusão de hemocomponentes antes de 1992, momento no qual os testes de triagem foram incorporados nos serviços de hemoterapia. O Quadro 4 apresenta as principais populações com risco de doença de Chagas crônica estabelecida.  
Considerando-se o alto número de pessoas infectadas _por T. Cruzi no_ Brasil, a recente imigração de indivíduos procedentes de países latino-americanos com alta prevalência de doença de Chagas, como Bolívia, Colômbia e, mais recentemente, a Venezuela, e as taxas de morbimortalidade da doença, é importante estabelecer estratégias para definir as populações de maior risco e para o rastreamento da doença.  
#### **QUESTÃO 14. DEVE-SE REALIZAR RASTREAMENTO POPULACIONAL PARA DIAGNOSTICAR DOENÇA DE CHAGAS CRÔNICA NA POPULAÇÃO?**  
**14.1. Sugerimos realizar rastreamento para diagnosticar doença de Chagas em indivíduos que integram a população sob risco com idade inferior a 50 anos (evidência muito baixa, recomendação fraca).**  
**14.2. Sugerimos não realizar rastreamento para diagnosticar doença de Chagas em indivíduos fora da população sob risco (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizado modelo de árvore de decisão, com parâmetros obtidos de revisão sistemática da literatura e dados epidemiológicos da frequência da doença no Brasil. Considera-se como população de alto risco indivíduos residentes ou procedentes de áreas endêmicas (em especial que habitavam em regiões rurais), incluindo imigrantes e indivíduos que realizaram transfusão sanguínea antes de 1992. Para essas estimativas, considera-se a prevalência da doença de Chagas de 0,5 a 1,0% na população de baixo risco e de 5% na população de alto risco abaixo de 50 anos.  
Na população de baixo risco, a cada 1.000 indivíduos rastreados, serão identificados entre cinco e dez casos de doença de Chagas; o número necessário para rastrear ( _number needed to screen_ , NNS) para identificar um caso de doença de Chagas varia de 104 a 208. Na população de alto risco, a cada 1.000 indivíduos rastreados, serão identificados 48 casos de doença de Chagas (NNS = 21).  
#### **<u>Considerações</u>**  
O rastreamento visa a identificar na população indivíduos assintomáticos que apresentam a condição de interesse. É importante salientar que a estratégia de rastreamento consiste em identificar casos com a doença e direcioná-los ao manejo adequado. Dessa forma, o rastreamento só deve ser considerado em indivíduos cujo diagnóstico positivo leve à conduta específica, como, por exemplo, tratamento antiparasitário ou investigação diagnóstica adicional. Vale salientar que, como discutido previamente, as recomendações para tratamento em doença de Chagas são fracas e seu benefício incerto. Em população de baixo risco, a doença apresenta baixa prevalência, o que diminui ainda mais o impacto dos programas de rastreamento.  
89  
Em relação ao rastreamento de adultos com mais de 50 anos pertencentes à população de maior risco, não houve consenso para a recomendação, tendo cinco painelistas se manifestado a favor do rastreamento, seis contra e quatro abstenções. Assim, não foi possível realizar recomendação sobre rastrear ou não rastrear casos com idade igual ou superior a 50 anos em populações de maior risco, sendo a qualidade da evidência para benefícios e riscos muito baixa.Entende-se que há um equilíbrio no balanço entre vantagens e desvantagens, sendo ambas as alternativas válidas.  
A favor do rastreamento, são salientados aspectos como (a) cada indivíduo tem o direito de saber de uma condição que o coloca em risco de uma condição adversa de saúde, e frente a isso pode adotar medidas para minimizar danos e antecipar eventos adversos graves à sua saúde, mesmo que seja por meio de acompanhamento médico periódico; (b) portadores de doença de Chagas não diagnosticados consistem potencialmente em uma população desfavorecida; assim, o diagnóstico pode levar a investigações adicionais (por exemplo., investigação de cardiopatias silenciosas) e melhores cuidados médicos, o que pode colaborar para a redução de iniquidades em saúde; (c) a detecção de casos de doença de Chagas em qualquer idade pode contribuir para outros diagnósticos de doença de Chagas no contexto familiar, de contatos sociais e comunidades.  
Contra o rastreamento de adultos com mais de 50 anos pesam argumentos como: (a) o tratamento com antiparasitários não ser recomendado nessa população, podendo ocorrer sobrediagnóstico e sobretratamento se uma política de rastreamento populacional for implementada; (b) o diagnóstico de doença de Chagas pode possuir impacto negativo, causando ansiedade e até mesmo discriminação; (c) os custos potencialmente podem ser altos.  
As presentes recomendações se aplicam a população geral, não contemplando estratégias de rastreamento para populações especiais como imunossuprimidos. Nesses pacientes, por possuírem maior risco de desenvolver complicações relacionadas, o benefício do rastreamento pode ser mais significativo.  
#### **Discussão da recomendação para o PCDT de doença de Chagas:**  
Devido a contribuições levantadas na consulta pública a respeito do rastreamento de indivíduos com fatores de risco e idade acima de 50 anos, as evidências, assim como os argumentos a favor e contra o rastreamento desses indivíduos foram apresentadas à plenária da CONITEC. A mesma após ampla discussão e análise das evidências decidiu por deliberar que, no documento final, a recomendação fosse a favor do rastreamento sem delimitação da idade do paciente, mas atrelada a condição de risco de exposição dos pacientes.  
**QUESTÃO 15. DEVE-SE REALIZAR O RASTREAMENTO EM GESTANTES? 15.1. Sugerimos rastrear gestantes de população sob risco para doença de Chagas crônica (evidência muito baixa, recomendação fraca).**  
**15.2. Sugerimos não rastrear gestantes fora da população sob risco para doença de Chagas crônica (evidência muito baixa, recomendação fraca).**  
#### **<u>Resumo das evidências</u>**  
Foi realizado estudo de simulação no qual observou-se que, na população de puérperas, a probabilidade pré-teste foi de 1,1% e o risco de transmissão congênita foi de 2,6% (Martins-  
90  
Melo, Lima Mda _, et al._ , 2014). A estratégia de rastrear gestantes, diagnosticar o neonato e tratar a doença de Chagas nos casos neonatais identificados resultou em detecção de 29 casos a cada 100.000 mulheres rastreadas (NNS = 3.348). A mesma estratégia resultou em prevenção de cinco casos de cardiopatia chagásica a cada 100.000 mulheres rastreadas (NNS = 20.000).Em análise de sensibilidade, considerando grupo de alto risco, cuja prevalência de doença de Chagas seja equivalente a 5%, com a estratégia de rastreamento serão identificados 132 casos (NNS = 758) e prevenidos 23 casos de cardiopatias chagásicas.  
#### **<u>Considerações</u>**  
Apesar da baixa taxa de transmissão congênita, o tratamento da doença de Chagas em recémnascidos geralmente leva à cura. Dessa forma, a detecção precoce da doença evita a evolução para um estado de doença crônica grave, como a cardiopatia chagásica, que causa impacto negativo tanto na sobrevida quanto na qualidade de vida dos indivíduos afetados. Assim, é sugerido o rastreamento em gestantes durante pré-natal com alto risco de doença de Chagas. Em gestantes com baixo risco, o impacto clínico é muito pequeno, não sendo recomendada essa prática de rotina.  
A testagem da gestante deve idealmente ser associada aos exames já realizados no pré-natal, como HIV, sífilis e hepatite B, especialmente em áreas endêmicas (Brasil, 2014a). Além disso, exames laboratoriais combinados para diagnóstico de várias doenças facilitariam a implementação e aumentariam o número de casos diagnosticados. Estratégias já bem consolidadas, como o Programa Nacional de Triagem Neonatal (“teste do pezinho”), podem facilitar a estratégia de rastreamento e a perda de seguimento dessas crianças, sendo que a testagem sorológica para pesquisa de IgG pode ser incorporada especialmente em locais com alta prevalência de transmissão congênita.  
Importante considerar possíveis variações regionais nas taxas de transmissão congênita. Revisão sistemática avaliou nove estudos sobre transmissão congênita, a qual variou de 0 a 5,2% e foi maior na região sudeste (2,1%; IC95% 0,9 a 5,0%) (Martins-Melo, Lima Mda _, et al._ , 2014). Entre as razões para essas diferenças podem estar a migração de mulheres infectadas de áreas endêmicas e o tipo de parasita existente em determinada região. Alguns genótipos de _T. cruzi_ estão associados a casos de infecção congênita. Por exemplo, os tipos TcV estão associados com mais de 80% dos casos de transmissão congênita na Argentina, Bolívia, Chile, Paraguai e sul do Brasil, enquanto outros, como TcI e TcII, estão menos correlacionados (Coura, 2015). Não há evidências robustas que direcionem para um programa de rastreamento diferenciado em regiões com maior prevalência de diferentes tipos de parasito; contudo, essa informação pode auxiliar na tomada de decisão em regiões com alta taxa de transmissão congênita, como o Rio Grande do Sul.  
Esta diretriz não aborda o rastreamento de doença de Chagas em situações especiais como, por exemplo, gestantes infectadas por HIV ou outros fatores de imunossupressão. Nessas gestações há maior risco de transmissão congênita, sendo o benefício do rastreamento potencialmente maior.  
Por fim, não há necessidade de realizar teste de rastreamento para doença de Chagas em mulheres com sorologia prévia negativa, salvo forte suspeição de infecção adquirida no período desde a última testagem.  
#### **_Rastreamento neonatal_**  
A testagem neonatal é realizada de rotina em crianças com suspeita de transmissão congênita. Crianças com testagem positiva ou com sintomatologia da doença devem ser tratadas  
91  
conforme as recomendações desta diretriz. Por se tratar de infecção aguda, devem-se realizar exames parasitológicos diretos; porém, testes falso-negativos podem ocorrer, devendo-se colher mais de uma amostra (ver Parte I - DIAGNÓSTICO DA DOENÇA DE CHAGAS). Com relação aos testes sorológicos, testes falso-positivos podem ocorrer no período neonatal devido aos anticorpos maternos circulantes, detectados em testes. Há dúvidas sobre como proceder em relação à retestagem nesses casos, e em qual período pós-nascimento os testes devem ser repetidos.  
#### **QUESTÃO 16. EM QUE PERÍODO DEVE SER REALIZADO O TESTE DIAGNÓSTICO PARA DOENÇA DE CHAGAS EM CRIANÇAS COM SUSPEITA DE TRANSMISSÃO CONGÊNITA CUJA TESTAGEM PARASITOLÓGICA NEONATAL FOI NEGATIVA?**  
**Recomendação 16.1. Recomendamos realizar testagem sorológica aos 9 meses de idade em crianças com suspeita de transmissão congênita cuja testagem neonatal foi negativa para doença de Chagas (evidência muito baixa, recomendação forte).**  
#### **<u>Resumo das evidências</u>**  
Foi realizada revisão sistemática que incluiu quatro estudos avaliando o diagnóstico de Chagas em crianças filhas de mães com diagnóstico de Chagas (Valdez et al 2016; Bern et al 2009; Malimacci et al 2010; Gamboa-Leon et al 2011). Estudos avaliaram o desfecho entre 0 e 12 meses após nascimento; nesse período, há uma variabilidade entre as taxas de falso-negativos parasitológicos e falso-positivos sorológicos, com queda menor taxa de positividade entre 9 e 12 meses, representando uma menor taxa de falso-positivos devido à presença de anticorpos maternos.  
#### **<u>Considerações</u>**  
Ao se realizar testagem no neonato devido ao risco de transmissão congênita, há chance de resultado sorológico reagente (ou positivo) devido a presença de anticorpos maternos nesse período, ou seja, anticorpos passivos. Se uma titularidade alta persistir após os 9 meses de idade, isso é forte indicativo de transmissão congênita. Para proceder à investigação da transmissão congênita, deve-se considerar pelo menos a existência de duas reações positivas, conforme estabelecido na Recomendação 1 (Figura 3).  
Crianças não testadas aos 9 meses devem realizar a testagem após esse período, visto que a eficácia e a segurança do tratamento são semelhantes nos primeiros anos de vida, e a negativação sorológica é de >95% (Chippaux _et al._ , 2010; Carlier _et al._ , 2011; Gonzalez-Tome _et al._ , 2013).  
Se houver dificuldade de seguimento das gestantes, como no caso das que residem em locais de difícil acesso e apresentam baixa aderência ao atendimento pós-natal, pode-se realizar a testagem mais precocemente, entre 6 e 9 meses de idade. Nesses casos, a taxa de falsopositivos é maior, visto que ainda pode haver anticorpos maternos; porém, essa estratégia pode reduzir o risco de não tratamento de crianças infectadas por perda de acompanhamento.  
Novos testes vêm sendo propostos a fim de detectar mais precocemente a ocorrência de transmissão congênita, como o _Shed Acute Phase Antigen_ (SAPA) e a PCR; contudo, os custos são altos e ainda há dificuldades na padronização das técnicas para recomendar seu uso de rotina.  
92  
**Figura 3. Fluxograma para abordagem da gestante com alto risco para infecção por** **_T. cruzi_**  
> aSeguir o fluxograma de recom **e** ndação do diagnóstico da infecção por _T. cruzi_ (ver seção referente ao diagnóstico laboratorial da inf **e** cção por _T. cruzi_ ).<sup>b</sup> Testes parasitológicos estão recomendados nos primeiros dias de vida da cri **a** nça<sup>c</sup> Após o nono mês de vida, utilizar testes sorológicos para o diagnóstico da infecção  
#### **VIGILÂNCIA EM SAÚDE**  
Indivíduos suspeitos na fase **a** guda devem ser notificados pela esfera municipal a estadual em até 24 horas e registrados **n** o Sistema de Informação de Agravos de Notificação – SINAN,  
93  
incluindo os casos de transmissão materno-fetal identificados até dois anos de idade.  Em caso de confirmação de um caso agudo, deve-se sempre solicitar à vigilância epidemiológica municipal que realize as medidas de controle no local provável de infecção, de acordo com a forma de transmissão. Além da adequada condução dos casos e suas especificidades em cada modo de transmissão, recomenda-se:  
- Transmissão vetorial: realizar ações integradas de vigilância ambiental, com investigação entomológica e de reservatórios, além de desenvolver ações de educação em saúde. Deve-se solicitar sorologia dos habitantes das residências nas quais são encontrados triatomíneos intradomiciliares e peridomiciliares positivos para T. cruzi.  
- Transmissão oral: além da vigilância ambiental, com investigação entomológica e de potenciais reservatórios, faz-se necessário a inspeção sanitária para avaliação de provável(is) alimento(s) contaminado(s) por T. cruzi, a fim de desenvolver ações de vigilância sanitária. Ações de educação em saúde devem estar necessariamente associadas.  
- Transmissão vertical: quando a criança for o primeiro caso identificado, a investigação deve ser conduzida para realização de exames laboratoriais na mãe e familiares;  
Orientações sobre vigilância e ações de prevenção e controle da doença de Chagas estão disponíveis nos Guias e Manuais da Secretaria de Vigilância em Saúde (SVS): http://portalms.saude.gov.br/vigilancia-em-saude  
Apesar da difícil suspeição clínica e epidemiológica, reforça-se a importância de se reconhecer no território pessoas com infecção por T. cruzi com o propósito de proporcionar assistência e instituir medidas de prevenção ou redução de dano em relação ao desenvolvimento das formas clínicas da enfermidade. Neste intento, recomenda-se o acompanhamento anual com eletrocardiograma (ECG) convencional para todo indivíduo na forma crônica indeterminada, considerando o algoritmo abaixo para avaliação inicial naqueles com ECG alterado (Figura 4).  
94  
#### **Figura 4. Fluxograma para avaliação inicial de pacientes com ECG alterado**  
Fonte: II Consenso Brasileiro de Do **e** nça de Chagas. Brasil,2015. BIRD = bloqueio incompleto d **e** ramo direito; BDAS = Bloqueio divisional anterossuperi **o** r; BAV = bloqueio atrioventricular; ST-T = segmento S **T** -T; BCRD = bloqueio completo do ramo direito; EV = ex **t** rassístole ventricular; T = onda T; FC = frequência cardíaca; TVNS = taquicardia ventricular não sustentada; FA = fibrilação atrial; BAVT = bloqueio atrioventricular total; BR **E** = bloqueio de ramo esquerdo; FEVE = fração de eje **ç** ão de ventrículo esquerdo; ICC = insuficiência cardíaca congestiva; ECO = ecocardiograma; IC = insuficiência cardíaca.  
Em relação à farmacovigilân **c** ia, no início do tratamento com benznidazol de **v** em ser realizados exame clínico, hemograma c **o** mpleto, testes de função renal e avalição de enzimas hepáticas. Este monitoramento deve ser repetido no 30º e 60º dia de tratamento. Os e **f** eitos adversos ao benznidazol e respectivas co **n** dutas podem ser observados no Quadro 5.  
95  
#### **<u>Quadro 5: Efeitos adversos ao benznidazol e condutas recomendadas</u>**  
##### **Benzonidazol**  
|**Manifestações / efeitos**<br>**adversos**|**Aparecimento**<br>**/ período do**<br>**tratamento**|**Característic**|**as**|**Localização**|**Intensidade**|**Conduta**|**Medidas complementares**|
|---|---|---|---|---|---|---|---|
|Dermopatia<br>por<br>hipersensibilidade<br>é<br>o<br>mais frequente. NÃO é<br>dose-dependente e NÃO<br>se relaciona com o_T._<br>_cruzi_<br>Recuperação<br>sem<br>sequelas|10º<br>dia<br>de<br>tratamento,<br>podendo<br>ocorrer<br>mais<br>precocemente<br>ou<br>mais<br>tardiamente|Eritema<br> <br>não<br>pruriginoso,<br>seguindo-se<br>descamação<br>Raramente<br>onicólise|polimorfo,<br>bolhoso,<br> <br> <br>de<br>.<br>ocorre|Focal (restrita<br>a<br>parte<br>do<br>tegumento) ou<br>generalizada|Leve<br>(geralmente<br>focal)<br>Moderada (focal ou<br>generalizada)|Continuar o tratamento<br>Continuar o tratamento<br>com associação de baixa<br>dose de corticosteroide<br>(5mg de prednisona ou<br>equivalente)<br>Interromper se houver<br>piora|Tratamento específico para<br>desidratação e descamação<br>cutânea<br>orientado<br>por<br>dermatologista<br>Internação, de acordo com o<br>quadro clínico|
||||||Grave<br>(geralmente<br>acompanhada<br>de<br>febre<br>e<br>linfoadenomegalia)|Interromper o tratamento<br>Utilizar corticosteroide||
|Polineuropatia periférica.<br>Dose-dependente,<br>de<br>regressão lenta (meses)|Final<br>do<br>tratamento|Dor e parest|esia|Regiões<br>plantares (mais<br>frequentes) e<br>palmares|Leve a moderada|Interromper o tratamento|Tratamento<br>geral<br>para<br>polineuropatia<br>periférica<br>orientada por neurologista|
|Ageusia (rara)<br>Recuperação sem sequela|Final<br>do<br>tratamento|Perda total<br>do paladar|ou parcial|-|-|Interromper o tratamento|-|  
96  
|Depressão|da<br>medula|Entre o 20º e|Leucopenia<br>com<br>Interromper o tratamento|Tratamento<br>geral<br>para|
|---|---|---|---|---|
|óssea, com<br>sem sequela|recuperação<br>|30º<br>dias<br>de<br>tratamento|neutropenia<br>de<br>variados<br>graus,<br>podendo<br>chegar<br>a<br>agranulocitose<br>-<br>-|depressão da medula óssea<br>orientado por hematologista|
|A intolerânc|ia digestiva (r|ara) é controlada co|m medicação habitualmente utilizada para gastrite e úlceras pépticas. Acometimento hepátic|o grave é raramente descrito.|
|Acometimen|to renal não te|m sido observado.|||  
**Fonte** : II Consenso Brasileiro em doença de Chagas. Brasil, 2015  
97  
#### RECOMENDAÇÕES PARA PESQUISA  
Não se pode negar que ocorreu uma reversão no quadro da transmissão vetorial da doença de Chagas no Brasil, e conquistas como hemocentros com exames de triagem para _T. cruzi_ e controle do vetor não podem ser ignoradas. Mesmo assim, a comunidade científica ainda pode contribuir para o controle da doença por meio da geração de evidências científicas. O grupo de trabalho desta diretriz levantou algumas questões que merecem destaque quanto a novas pesquisas na área.  
- São necessários mais estudos avaliando a eficácia e a segurança de antiparasitários no tratamento de doença de Chagas,tanto do nifurtimox, que possui pouca experiência de uso, quanto do benznidazol. Em relação a este último, esquemas alternativos de dose e de tempo de tratamento vêm sendo propostos, sem adequada comprovação. O efeito dessa medicação deve ser estudado em populações em estádios menos avançados da doença.  
- São necessários estudos avaliando o papel da PCR em relação a: (a) avaliação da efetividade do tratamento antiparasitário; (b) identificação de casos com doença crônica e imunossupressão em risco para reativação; (c) diagnóstico de casos de transmissão materno-fetal.  
- Novos testes, como o SAPA, apesar de se mostrarem promissores na detecção de transmissão materno-fetal, necessitam ser melhor avaliados.  
- Há potenciais diferenças importantes no efeito dos antiparasitários de acordo com a região geográfica, o que pode indicar diferente sensibilidade de acordo com o tipo do parasito. É importante investigar a patogenicidade e a sensibilidade ao tratamento etiológico dos diferentes tipos do parasito.  
- O tratamento das arritmias na doença de Chagas é empírico, e informações acerca dos fatores relacionados ao risco de morte súbita e da efetividade de tratamento medicamentoso ou por cardioversor implantável são incertas, sendo necessários novos estudos para definir as indicações de cada um na cardiopatia chagásica.  
- Considerando os diferentes Kits disponíveis para diagnóstico sorológico e testes rápidos disponíveis no mercado, é importante a realização de estudos de validação, com intuito de orientar os processos de aquisição dos insumos na escolha daquele(s) com melhor acurácia.  
98  
#### CONTEXTO SOCIAL E RECOMENDAÇÕES PARA FINS PREVIDENCIÁRIOS  
A doença de Chagas é pouco conhecida pela população geral, incluindo as pessoas afetadas e seus familiares. O profissional de saúde deve estar capacitado para adequadamente informar aos casos, familiares e interessados em geral sobre as características clínico-epidemiológicas da doença de Chagas, em especial no que tange à transmissão, à terapêutica e ao seu prognóstico.  
A adequada informação a respeito dos aspectos acima mencionados pode contribuir para a diminuição da ansiedade dos casos, auxiliar na promoção do cuidado dessas pessoas s e evitar desgaste e retornos constantes ao serviço para emissão de relatórios sobre seu estado de saúde, fornecendo o maior número de subsídios do quadro de uma pessoa e que será submetido a uma perícia médica junto à Previdência Social. Nesse sentido, destaca-se não apenas a importância do CID, mas a descrição detalhada do caso, incluindo condições de saúde, limitações, riscos, prognóstico, tratamento, evolução da doença, comprometimentos, especificidades, particularidades e cópia de exames relevantes.  
Outro aspecto importante a ser considerado é o papel das associações de pessoas afetadas pela doença de Chagas, que podem também auxiliar na divulgação de informações sobre a doença junto a seus familiares e a sociedade em geral. Isso porque essas associações constituem-se em um espaço de convivência, acesso e troca de informações, apoio, promoção de atividades educativas, de conscientização, defesa de seus direitos e articulação com outros segmentos organizados da sociedade para garantia do acesso à informação, à saúde, ao diagnóstico, tratamento, medicação e defesa da vida.  
Deve-se salientar que a doença de Chagas geralmente é mais prevalente em populações vulneráveis; assim, esforços para promover educação e melhorar o acesso à saúde de casos de doença de Chagas tendem a reduzir iniquidades, devendo ser priorizados em saúde pública.  
A maioria das pessoas com doença de Chagas possui a forma indeterminada, sem a presença de sintomas associados. Essas pessoas possuem capacidade funcional semelhante à da população geral, não sendo a doença de Chagas um limitante para suas atividades. A solicitação de sorologia para doença de Chagas em exame admissional, sem forte justificativa, deve ser desestimulada. Para fins trabalhistas, o indivíduo portador de doença de Chagas crônica na forma indeterminada deve ser considerado semelhante ao caso sem a doença, sem discriminação de qualquer natureza.  
O tratamento etiológico da doença de Chagas está associado à incidência elevada de eventos adversos, os quais podem prejudicar a qualidade de vida e a capacidade funcional da população e levar ao afastamento transitório das atividades laborais. Apesar de incomum, em alguns casos eventos adversos como neuropatia podem permanecer por alguns meses após a interrupção do tratamento.  
Pessoas com doença de Chagas crônica em forma cardíaca, digestiva ou cardiodigestiva podem apresentar grau variável de comprometimento funcional, de acordo com suas manifestações clínicas, devendo cada caso ser individualizado para fins de atividades laborais. Atenção maior deve ser dada aos casos com cardiopatia chagásica grave, com risco de morte súbita, podendo esses serem desaconselhados a exercer atividades relacionadas à operação de máquinas ou veículos automotivos.  
99  
#### DISCUSSÃO  
O presente documento vem a servir como guia clínico e material orientativo para gestores no que tange à atenção ao paciente com doença de Chagas. Com a utilização de metodologia robusta e composição multidisciplinar de participantes, além de transparência no processo de síntese de evidências e de desenvolvimento de recomendações, o documento resultante pode ser considerado com adequada credibilidade, seguindo os princípios preconizados pelo _Institute of Medicine_ (IOM, 2011) e pela _Guideline International Network_ (Qaseem _et al._ , 2012)para o desenvolvimento de diretrizes. Da mesma forma, considerando a complexidade de um sistema de saúde responsável por mais de 200 milhões de indivíduos, as discussões não se limitaram a questões técnicas, mas abrangeram pontos relacionados a custos, utilização de recursos, valores e preferências dos casos, aceitabilidade e viabilidade das intervenções e o seu potencial impacto na redução de iniquidades em saúde.  
Com o presente documento, objetivou-se atender diferentes partes interessadas. Médicos especialistas e outros profissionais de APS poderão se beneficiar com as recomendações clínicas propostas e com as considerações para a sua aplicação. Da mesma forma, são fornecidas aos gestores da saúde orientações claras para disponibilização de tecnologias em saúde relacionada à doença de Chagas. As recomendações para pesquisa podem direcionar a comunidade científica rumo ao desenvolvimento de avanços no que tange a essa doença ainda bastante negligenciada. Por fim, foram realizadas considerações de cunho social e previdenciário, que podem auxiliar a esclarecer a interface dessa doença com problemas e dúvidas que as pessoas afetadas enfrentam em relação a questões práticas do cotidiano.  
Contudo, as recomendações propostas apresentam como importante limitante a baixa qualidade da evidência disponível, fator comum às diversas doenças negligenciadas. É importante destacar que a ausência de evidências robustas não implica em ausência de necessidade de tomada de decisão, mas sim repercute no aumento da complexidade dessa decisão, o que resultou em diversas recomendações de cunho condicional (fracas) no presente documento. Diante das incertezas existentes, essas recomendações condicionais, em geral, servem como guia do que se espera ser realizado na maioria das vezes, mas entende-se que podem não ser as mais adequadas em todas as situações. Assim, em nível individual, é importante que os profissionais de saúde estejam preparados para informar às pessoas afetadas, seus familiares, sua rede social e comunidade, de forma a possibilitar o compartilhamento da tomada de decisão. No nível do sistema de saúde, o gestor deverá avaliar como a doença de Chagas se insere em sua agenda de prioridades em saúde, para assim decidir sobre, por exemplo, programas que envolvam o rastreamento dessa condição. Assim, o presente documento deve ser visto orientador para a atenção relacionada à doença de Chagas, e não como um documento normativo, que visa estabelecer de forma rígida como esses cuidados devem ser prestados.  
Espera-se que a efetiva implementação do presente documento venha a promover melhor acesso e atenção à pessoa afetada por doença de Chagas, otimização de recursos, minimização de riscos e redução de iniquidades em saúde.  
100  
#### REFERÊNCIAS  
ALMEIDA, E. A. D.  et al. Co-infection Trypanosoma cruzi/HIV: systematic review (1980 - 2010). **Revista da Sociedade Brasileira de Medicina Tropical,** v. 44, p. 762-770,  2011. ISSN 0037-8682. Disponível em: <http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0037- <u>86822011000600021&nrm=iso>.</u>  
- BELLOTTI, G.  et al. [Electrocardiographic and hemodynamic effects of amiodarone hydrochloride by intravenous route]. **Arq Bras Cardiol,** v. 40, n. 2, p. 141-4, Feb 1983. ISSN 0066-782X (Print) 0066-782x.  
- BENZIGER, C. P.; DO CARMO, G. A. L.; RIBEIRO, A. L. P. Chagas Cardiomyopathy. **Cardiology Clinics,** v. 35, n. 1, p. 31-47, ISSN 0733-8651. Disponível em: <http://dx.doi.org/10.1016/j.ccl.2016.08.013>. Acesso em: 2017/09/08.  
- BERN, C. Chagas' Disease. **N Engl J Med,** v. 30, n. 373, p. 456-66, 20150730 DCOM- 20150814 2015.  
- BERN, C.  et al. Trypanosoma cruzi and Chagas' Disease in the United States. **Clin Microbiol Rev,** v. 24, n. 4, p. 655-81, Oct 2011. ISSN 0893-8512.  
- BERN, C.  et al. Evaluation and treatment of chagas disease in the United States: a systematic review. **Jama,** v. 298, n. 18, p. 2171-81, Nov 14 2007. ISSN 0098-7484.  
- BISIO, M.  et al. Benznidazole treatment of chagasic encephalitis in pregnant woman with AIDS. **Emerg Infect Dis,** v. 19, n. 9, p. 1490-2,  2013. ISSN 1080-6040.  
- BRASIL. **Recomendações sobre o diagnóstico parasitológico, sorológico e molecular para confirmação da doença de Chagas aguda e crônica. Informe Técnico** . Rev Patol Trop <u>Vol. 42 (4): . . 2013: Ministério da Saúde. Secretaria de Vigilância em Saúde. 42</u> **:** 475478 p. 2013.  
- BRASIL. Guia para vigilância, prevenção, controle e manejo clínico da doença de Chagas aguda transmitida por alimentos. . SAÚDE, O. P. A. D. Rio de Janeiro:: PANAFTOSAVP/OPAS/OMS 2009.  
- BRASIL. Caderneta da Gestante. Brasília: Ministério da Saúde, Brasília 2014a.  
- BRASIL. Guia de Vigilância em Saúde.  Brasília: Ministério da Saúde, 2014b. 812 ISBN 978-85334-2179-0.  
- BRASIL. **Guia de Vigilância em Saúde** . ecretaria de Vigilância em Saúde, Coordenação-Geral de Desenvolvimento da Epidemiologia em Serviços. C. G. D. D. D. E. E. Brasilia: Ministério da Saúde. **:** 773 p. p. 2016.  
- BRASIL. Diretrizes metodológicas: elaboração de diretrizes clínicas.  Brasília:  2016.  ISBN 97885-334-2372-5.  
- CARLIER, Y.  et al. Congenital Chagas disease: recommendations for diagnosis, treatment and control of newborns, siblings and pregnant women. **PLoS Negl Trop Dis,** v. 5, n. 10, p. e1250, Oct 2011. ISSN 1935-2727.  
- CASTRO, J. A.; DE MECCA, M. M.; BARTEL, L. C. Toxic side effects of drugs used to treat Chagas' disease (American trypanosomiasis). **Hum Exp Toxicol,** v. 25, n. 8, p. 471-9, Aug 2006. ISSN 0960-3271 (Print)0960-3271.  
- CHIALE, P. A.  et al. Efficacy of amiodarone during long-term treatment of malignant ventricular arrhythmias in patients with chronic chagasic myocarditis. **Am Heart J,** v. 107, n. 4, p. 656-65, Apr 1984. ISSN 0002-8703 (Print) 0002-8703.  
- CHIPPAUX, J. P.  et al. Antibody drop in newborns congenitally infected by Trypanosoma cruzi treated with benznidazole. **Trop Med Int Health,** v. 15, n. 1, p. 87-93, Jan 2010. ISSN 1360-2276.  
- CORRÊA, V. R.  et al. Uneventful benznidazole treatment of acute Chagas disease during pregnancy: a case report. **Revista da Sociedade Brasileira de Medicina Tropical,** v. 47, p. 397-400, 2014. ISSN 0037-8682. Disponível em:  
101  
<http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0037-  
<u>86822014000300397&nrm=iso>.</u>  
- COURA, J. R. The main sceneries of Chagas disease transmission. The vectors, blood and oral transmissions - A comprehensive review. **Memórias do Instituto Oswaldo Cruz,** v. 110, p. 277-282, 2015. ISSN 0074-0276. Disponível em: <http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0074- <u>02762015000300277&nrm=iso>.</u>  
- DANTAS, R. O.  et al. Effect of nifedipine on the lower esophageal sphincter pressure in chagasic patients. **Braz J Med Biol Res,** v. 19, n. 2, p. 205-9,  1986. ISSN 0100-879X (Print) 0100-879x.  
- DE TORANZO, E. G.; MASANA, M.; CASTRO, J. A. Administration of benznidazole, a chemotherapeutic agent against Chagas disease, to pregnant rats. Covalent binding of reactive metabolites to fetal and maternal proteins. **Arch Int Pharmacodyn Ther,** v. 272, n. 1, p. 17-23, Nov 1984. ISSN 0003-9780 (Print) 0003-9780.  
- DIAS, E. **Qualidade de vida de adultos e idosos portadores da Doença de Chagas** . 2009. 136 (Mestrado). Faculdade de Ciências Medicas, Universidade Estadual de Campinas, Campinas.  
- ELIANE DIAS GONTIJO, T. G., C MAGNANI GM PAIXÃO, S DUPIN, LM PAIXÃO Qualidade de vida dos portadores de doença de Chagas. **Rev Med Minas Gerais,** v. 19, p. 5,  2009.  
- FABBRO, D. L.  et al. Trypanocide treatment of women infected with Trypanosoma cruzi and its effect on preventing congenital Chagas. **PLoS Negl Trop Dis,** v. 8, n. 11, p. e3312, Nov 2014. ISSN 1935-2727.  
- FIGUEIREDO, M. C.  et al. Short report: comparison of the effects of sublingual nifedipine and isosorbide dinitrate on oesophageal emptying in patients with Chagasic achalasia. **Aliment Pharmacol Ther,** v. 6, n. 4, p. 507-12, Aug 1992. ISSN 0269-2813 (Print)02692813.  
- GONZALEZ-TOME, M. I.  et al. [Recommendations for the diagnosis, treatment and follow-up of the pregnant woman and child with Chagas disease. Sociedad Espanola de Infectologia Pediatrica. Sociedad de Enfermedades Infecciosas y Microbiologia Clinica. Sociedad Espanola de Ginecologia y Obstetricia]. **Enferm Infecc Microbiol Clin,** v. 31, n. 8, p. 535-42, Oct 2013. ISSN 0213-005x.  
- GRADE. Grading of Recommendations Assessment, Development, and Evaluation., Disponível em: <http://gradeworkinggroup.org/#>. Acesso em: May 2017.  
- GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. McMaster University, 2015 (developed by Evidence Prime, Inc.). Available from gradepro.org.  
- HAEDO, A. H.  et al. Comparative antiarrhythmic efficacy of verapamil, 17monochloracetylajmaline, mexiletine and amiodarone in patients with severe chagasic myocarditis: relation with the underlying arrhythmogenic mechanisms. **J Am Coll Cardiol,** v. 7, n. 5, p. 1114-20, May 1986. ISSN 0735-1097 (Print) 0735-1097.  
- HOTEZ, P. J.; FUJIWARA, R. T. Brazil's neglected tropical diseases: an overview and a report card. **Microbes Infect,** v. 16, n. 8, p. 601-6, Aug 2014. ISSN 1769-714X (Electronic)  
- 1286-4579 (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/25088506>.  
- M F D HUEB, S. R. L. Cognitive and psychosocial aspects in Chagas Disease: a review **Psicol. estud.,** v. 10, n. 1, p. 6,  2005.  
- IOM. Clinical Practice Guidelines We Can Trust.  Washington (DC): National Academies Press (US), 2011.  ISBN 978-0-309-16422-1978-0-309-16423-8.  
- MARTINS-MELO, F. R.  et al. Prevalence of Chagas disease in pregnant women and congenital transmission of Trypanosoma cruzi in Brazil: a systematic review and meta-analysis. **Trop Med Int Health,** v. 19, n. 8, p. 943-57, Aug 2014. ISSN 1365-3156 (Electronic)  
- 1360-2276 (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/24815954>.  
102  
- MARTINS-MELO, F. R.  et al. Prevalence of Chagas disease in Brazil: a systematic review and meta-analysis. **Acta Trop,** v. 130, p. 167-74, 20140127 DCOM- 20140916 2014.  
- ______. Mortality from neglected tropical diseases in Brazil, 2000-2011. **Bull World Health Organ,** v. 94, n. 2, p. 103-10, Feb 01 2016. ISSN 1564-0604 (Electronic) 0042-9686 (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/26908960>.  
- MORILLO, C. A.  et al. Randomized Trial of Benznidazole for Chronic Chagas' Cardiomyopathy. **N Engl J Med,** v. 373, n. 14, p. 1295-306, Oct 2015. ISSN 0028-4793.  
- MORILLO, C. A.  et al. Benznidazole and Posaconazole in Eliminating Parasites in Asymptomatic T. Cruzi Carriers: The STOP-CHAGAS Trial. **J Am Coll Cardiol,** v. 69, n. 8, p. 939-947, Feb 28 2017. ISSN 1558-3597 (Electronic) 0735-1097 (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/28231946>.  
- MOSCATELLI, G.  et al. Prevention of congenital Chagas through treatment of girls and women of childbearing age. **Mem Inst Oswaldo Cruz,** v. 110, n. 4, p. 507-9, Jun 2015. ISSN 0074-0276.  
- OLIVEIRA, B. G.  et al. Health-related quality of life in patients with Chagas disease. **Revista da Sociedade Brasileira de Medicina Tropical,** v. 44, p. 150-156,  2011. ISSN 0037-8682. Disponível em: <http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0037- <u>86822011000200005&nrm=iso>.</u>  
- OSTERMAYER, A. L.  et al. O inquérito nacional de soroprevalência de avaliação do controle da doença de Chagas no Brasil (2001-2008). **Revista da Sociedade Brasileira de Medicina Tropical,** v. 44, p. 108-121,  2011. ISSN 0037-8682. Disponível em: <http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0037- <u>86822011000800015&nrm=iso>.</u>  
- OZAKI Y, G. M., DE ALMEIDA EA. Quality of life and depressive symptoms in Chagas disease patients. **Qual Life Res,** v. 20, p. 6,  2011.  
- PROJECT., G. W. G. S. D. GRADEpro GDT.,    Disponível em: <https://gradepro.org/>. Acesso em: May.  
- QASEEM, A.  et al. Guidelines International Network: toward international standards for clinical practice guidelines. **Ann Intern Med,** v. 156, n. 7, p. 525-31, Apr 03 2012. ISSN 0003-4819.  
- SANTOS, M.  et al. Brazilian Valuation of EQ-5D-3L Health States: Results from a Saturation Study. **Med Decis Making,** v. 36, n. 2, p. 253-63, Feb 2016. ISSN 1552-681X (Electronic)  
- 0272-989X (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/26492896>.  
- SARTORI, A. M.  et al. Manifestations of Chagas disease (American trypanosomiasis) in patients with HIV/AIDS. **Ann Trop Med Parasitol,** v. 101, n. 1, p. 31-50, Jan 2007. ISSN 0003-4983 (Print)0003-4983 (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/17244408>.  
- SCAPELLATO, P. G.; BOTTARO, E. G.; RODRIGUEZ-BRIESCHKE, M. T. Mother-child transmission of Chagas disease: could coinfection with human immunodeficiency virus increase the risk? **Rev Soc Bras Med Trop,** v. 42, n. 2, p. 107-9, Mar-Apr 2009. ISSN 0037-8682.  
- SCHÜNEMANN, H. J.  et al. Guidelines 2.0: systematic development of a comprehensive checklist for a successful guideline enterprise. **CMAJ : Canadian Medical Association Journal,** v. 186, n. 3, p. E123-E142,  2014. ISSN 0820-39461488-2329. Disponível em: <http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3928232/>.  
- VAIDIAN, A. K.; WEISS, L. M.; TANOWITZ, H. B. Chagas' disease and AIDS. **Kinetoplastid Biol Dis,** v. 3, n. 1, p. 2, May 13 2004. ISSN 1475-9292 (Print) 1475-9292.  
- VILLAR, J. C.  et al. Trypanocidal drugs for chronic asymptomatic Trypanosoma cruzi infection. **Cochrane Database Syst Rev** , n. 5, p. Cd003463, May 27 2014. ISSN 1361-6137.  
103  
- VILLELA, M. M.  et al. Avaliação do Programa de Controle da Doença de Chagas em relação à presença de Panstrongylus megistus na região centro-oeste do Estado de Minas Gerais, Brasil. **Cadernos de Saúde Pública,** v. 25, p. 907-917,  2009. ISSN 0102-311X. Disponível em: <http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0102- <u>311X2009000400022&nrm=iso>.</u>  
- VIOTTI, R.  et al. Long-term cardiac outcomes of treating chronic Chagas disease with benznidazole versus no treatment: a nonrandomized trial. **Ann Intern Med,** v. 144, n. 10, p. 724-34, May 16 2006. ISSN 1539-3704 (Electronic)0003-4819 (Linking). Disponível em: <http://www.ncbi.nlm.nih.gov/pubmed/16702588>.  
- WHO. Handbook for Guideline development. Disponível em: <http://apps.who.int/iris/handle/10665/145714>. Acesso em: 2016.  
- WHO **Declaration of Interests for WHO Experts** . 2014  
- ______. Control of Chagas disease. **World Health Organ Tech Rep Ser,** v. 905, p. i-vi, 1-109, back cover,  2002. ISSN 0512-3054 (Print)0512-3054.  
- YUN, O.  et al. Feasibility, drug safety, and effectiveness of etiological treatment programs for Chagas disease in Honduras, Guatemala, and Bolivia: 10-year experience of Medecins Sans Frontieres. **PLoS Negl Trop Dis,** v. 3, n. 7, p. e488, Jul 07 2009. ISSN 1935-2727.  
104  
#### Resposta de consulta ao SIAT  
###### **SERVIÇO DE GENÉTICA MÉDICA**  
**SISTEMA NACIONAL DE INFORMAÇÕES SOBRE AGENTES TERATOGÊNICOS FONE/FAX:  (51) 3359.8008 E-MAIL:** **<u>siat@gravidez-segura.org http://gravidez-segura.org</u>**  
Dra. Veronica Colpani e-m ail: veronica.colpani@hmv.org.br Porto Alegre, 23 de março de 2017.  
###### Prezada Dra Veronica  
Em resposta à consulta ao SIAT **(regSIAT 10369),** sobre informações a respeito de **Doença de Chagas em gestantes** e os antiparasitários ( **benzonidazol e nifurtimox** ) **,** temos o seguinte a lhe informar:  
###### **<u>Doença de Chagas (DC) na gestação:</u>**  
A doença de Chagas pode ser transmitida para humanos por seis rotas: (1) insetos hematófagos que depositam fezes contendo tripanomastigotas (2) transfusão de sangue, (3) transferência placentária dos tripanomastigotas de uma mãe infectada (transmissão vertical) (4) transplante de órgãos (5) aleitamento materno (6) acidentes punctórios.  
Na medida em que as formas clássicas de transmissão como a vetorial e a transfusão  de sangue estão sendo controladas, outras formas como o transplante de órgãos e a transmissão congênita vêm demonstrando importância crescente. A prevalência de infecção por _T.cruzi_ entre gestantes residindo em áreas endêmicas varia de 2% a 51% nas cidades e 23% a 81% em áreas rurais. A doença pode ser comum em áreas não endêmicas por causa da migração, sendo um exemplo Buenos Aires, onde 6% a 8% das mulheres na época do parto têm testes sorológicos positivos para _T. cruzi,_ e ocorre em cerca de 3% a 4% de transmissão vertical. Na maioria dos casos, a mãe é assintomática. A passagem transplacentária pode ocorrer durante qualquer estágio da doença, mas geralmente após o sexto mês de gestação, entre 22 e 37 semanas, e parece depender de fatores ligados ao parasita e ao hospedeiro. A fase e as formas clínicas da infecção materna não parecem afetar a transmissão, embora a fase aguda, quando a parasitemia é alta e persistente apresente maior risco que a crônica. A infecção congênita pode ocorrer em 71% dos recém-nascidos de mães com infecção aguda durante a gravidez e em 1,6% na fase crônica da doença. O _T.cruzi_ atravessando o epitélio corial parasita o estroma vilositário, prolifera sob a forma amastigota e provoca  alterações, sendo que o grau de envolvimento placentário está geralmente relacionado com a intensidade das lesões fetais.  
Formas menos frequentes de transmissão materna da DC podem ocorrer pela contaminação oral através do líquido amniótico, e a transmissão hematogênica, durante o trabalho de parto. Há também a possibilidade de transmissão pelo leite materno em mulheres na fase aguda da infecção ou quando ocorre sangramento dos mamilos.  
Achados clínicos no neonato são relacionados momento da gestação que a parasitemia transplacentária ocorreu, sendo que quanto mais cedo na gestação o feto é infectado, mais comum é que ocorra evidência de infecção ao nascimento. Podem ocorrer abortamento, prematuridade, natimortalidade, retardo de crescimento intra-uterino e neonatos vivos com ou sem sintomatologia de DC aguda. Dentre a sintomatologia apresentada pelo neonato, são importantes: hepatoesplenomegalia, distúrbios neurológicos, menigoencefalites, tremores, convulsões, zonas de necrose com sequelas, anasarca, icterícia, hemorragia cutâneas,  cianose, hidrocele, pneumonite, alterações na fundoscopia como coriorretinite e opacificação do corpo vítreo, chagomas metastáticos, calcificações cerebrais e alterações gastrointestinais com intensa destruição neural originando manifestações digestivas como megacólon e megaesôfago em fase aguda.  
Os parasitas podem não estar presentes no sangue e o diagnóstico histopatológico pode ser necessário para estabelecer o diagnóstico, porém, a aglutinação direta, hemaglutinação indireta e testes de IgM por IFA podem ser úteis. A utilização de PCR apresenta uma grande sensibilidade especificidade, particularmente útil para detecção da infecção quando os agentes  
105  
infecciosos estão em títulos baixos. Através de um método simples e altamente sensível para a detecção de antígenos do T.cruzi (DOT – BLOTTING) foi possível demonstrar antigenemia em 14 (87,5%) de 16 crianças com infecção congênita.  
O prognóstico da infecção fetal é reservado, mesmo com tratamento. De 64 crianças infectadas por via congênita que foram acompanhadas, 7,8% morreram no  primeiro ano  de vida, 35,9% foram a óbito durante os primeiros quatro meses após o nascimento, 9,3% morreram entre 4 a 24 meses de idade e 42,2% sobreviveram por mais de quatro meses. Entre as crianças sobreviventes por mais de dois anos, 74% não apresentaram sintomas clínicos graves, apesar de apresentarem parasitemia contínua. Um estudo em 820 neonatos na Bolívia, com peso ao nascimento menor que 2.500g, observou 21 assintomáticos entre 78 infectados, o que pode ser devido a uma transmissão nos últimos dias de gestação. A maioria dos neonatos com infecção congênita não é prematura, apresenta peso normal, e não tem sintomas clássicos de fase aguda, sendo difícil detectar a infecção congênita clinicamente a não ser por estudos longitudinais ou prospectivos. Devido a estimativa de 1% a 4% para transmissão congênita da DC nas mulheres com reação sorológica positiva, o seguimento do neonato durante o primeiro mês de vida, pelo menos, é fundamental principalmente se for observado baixo peso e/ou hepatoesplenomegalia ao nascimento.  
No Brasil, uma metanálise de 2014 que incluiu 16 artigos encontrou uma prevalência de DC em gestantes brasileiras de 0,1% a 8,5%, e taxas de transmissão congênita de 0% a 5,2%. A prevalência combinada de DC nas gestantes foi de 1,1% (IC 95%: 0,6-2,0); a incidência combinada de transmissão congênita no estudo foi de 1,7% (IC95%: 0,9-3,1). Em 2010, estimou-se que 34.629 gestantes estavam infectadas com o _T. cruzi_ e que 312 a 1073 crianças tenham nascido com a infecção congênita.  
Em relação ao tratamento, duas drogas parecem destruir os tripanomastigostas circulantes: o **nifurtimox** e o **benznidazol** . Pelo risco da infecção materna poder levar  a infecção congênita, prematuridade, aborto e progressão para doença crônica severa, é racional considerar o tratamento materno **nos casos de doença aguda** .  
Ambos os fármacos demonstram mutagenicidade _in vitro_ e foram associados com aumento do risco de linfomas em animais de experimentação. Não se observou aumento da incidência de linfoma entre os seres humanos imunocompetentes, embora não tenham sido realizados estudos em longo prazo. Em decorrência da teratogenicidade demonstrada em animais, o tratamento específico da infecção por _T. cruzi_ , como regra geral, depende de uma razão risco/benefício. **Até o momento, relatos de exposição ao benznidazol em gestantes não indicaram efeitos adversos no recém-nascido** . Protocolos e diretrizes apontam eficácia do tratamento para evitar a transmissão materno-fetal.  
Se a gestante apresenta infecção crônica ou latente não é claro se deve ser tratada. Para esse grupo, a maior parte dos autores recomenda observação cuidadosa da atividade da infecção durante a gestação, incluindo pesquisa parasitológica e testes sorológicos séricos. Se houver parasitemia, aumento dos títulos de anticorpos, a quimioterapia deve ser considerada. Não existe consenso sobre o papel da amniocentese e do exame de parasitas no líquido amniótico no diagnóstico e manejo pré-natal.  
1. Martins-Melo FR, et al. Prevalence of Chagas disease in pregnant women and congenital transmission of Trypanosoma cruzi in Brazil: a systematic review and meta-analysis. Trop Med Int Health. 2014  
2. Chippaux, JP et al. Short Report: Detectable Trypanosoma cruzi parasitemia during pregnancy and delivery as a risck factor for congenital Chagas Disease. The American Sociaty of Tropical Medicine. Bolívia 2010.  
3. Ávila O et. el. Recomendaciones para el diagnóstico, seguimiento y tratamiento de la embarazada y del niño com enfermedad de Chagas. Enfermedades Infecciosas y Microbiología Clínica. España 2013.  
4. <u>http://conitec.gov.br/images/Relatorios/2016/PropostaEscopo_PCDT_DoencaChagas.pdf</u>  
###### <u>Atenciosamente,</u>  
|Dra.Maria Teresa V. Sanseverino<br>Coordenadora SIAT<br>CRM 13.143|Profª. Lavínia Schuler-Faccini<br>Coordenadora SIAT<br>CRM 13.269|Prof. Alberto Abeche<br>Coordenador SIAT<br>CRM 11.947|
|---|---|---|
|Dra. Fernanda Sales Luiz Vianna<br>Coordenadora SIAT|Dr. André Anjos da Silva<br>Coordenador SIAT<br>CRM 35.308|Daniela Martins<br>Plantonista SIAT|  
106

---

<!-- METADADOS: doenca: Doença de Chagas | secao: PERFIS DE EVIDÊNCIA -->
#### **QUESTÃO 1. COMO DEVEMOS REALIZAR O DIAGNÓSTICO DA DOENÇA DE CHAGAS EM SUA FASE CRÔNICA?**  
##### **Questão 1.1 Deve-se usar ELISA para diagnosticar doença de Chagas na fase crônica?**  
|**Sensibil**|**idade 0.96 (95%**|**CI: 0.95 para 0.97)**|||||**Esp**|**ecificidade 0.99 (95% CI: 0**|**.97 para 1.00)**||
|---|---|---|---|---|---|---|---|---|---|---|
|**Desfecho**|**№ dos**<br>**estudos (№**<br>**de pacientes)**|**Delineamento**<br>**do estudo**|**Fatores qu**<br>**Risco de**<br>**viés**|**e podem reduz**<br>**Evidência**<br>**indireta**|**ir a qualidade da ev**<br>**Inconsistência**|**idência**<br>**Imprecisão**|**Viés de**<br>**publicação**|**Efeito por 1000 paciente**<br>**Probabilidade pré-teste**<br>**de 4.2% para**<br>**população geral**|**s testados**<br> <br>**Probabilidade pré-teste**<br>**de 70% para testagem**<br>**discordante**|**Qualidade das**<br>**evidências de**<br>**acurácia do teste**|
|**Verdadeiros-positivos**<br>(pacientes com doença de Chagas na<br>fase crônica)|130 estudos|Estudos de<br>coorte e caso-<br>controle|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|40 (40 para 41)|673 (663 para 681)|⨁⨁◯◯<br>BAIXA|
|**Falsos-negativos**<br>(pacientes incorretamente classificados<br>como não tendo doença de Chagas na<br>fase crônica)||||||||2 (1 para 2)|27 (19 para 37)||
|**Verdadeiros-negativos**<br>(pacientes sem doença de Chagas na<br>fase crônica)|130 estudos|Estudos de<br>coorte e caso-<br>controle|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|947 (925 para 954)|297 (290 para 299)|⨁⨁◯◯<br>BAIXA|
|**Falsos-positivos**<br>(Pacientes com doença de Chagas na<br>fase crônica incorretamente<br>classificados)||||||||11 (4 para 33)|3 (1 para 10)||  
a. Estudos transversais ou de caso controle com fraco rigor metodológico.  
b. Estudos avaliando testes isoladamente, fora do contexto de combinação de dois testes ou de nova testagem.  
* Referências: Vide questão no apêndice.  
107  
**Questão 1.2 Deve-se usar IFI para diagnosticar doença de Chagas na fase crônica?**  
|||**Sensibilidade 0.88**|**(95% CI:**|**0.74 para 0.95**|**)**|**Es**|**pecificidade 0.9**|**8 (95% CI: 0.96 para 0.99)**|||
|---|---|---|---|---|---|---|---|---|---|---|
||**№ dos estudos**||**Fatores q**|**ue podem red**|**uzir a qualidade d**|**a evidência**||**Efeito por 1000 pacientes**|**testados**|**Qualidade das**|
|||**Delineamento do**|||||||||
|**Desfecho**|**(№ de**<br>**pacientes)**|<br>**estudo**|**Risco**<br>**de viés**|**Evidência**<br>**indireta**|**Inconsistência**|**Imprecisão**|**Viés de**<br>**publicação**|**Probabilidade pré-teste**<br>**de4.2% para população**<br>**geral**|**Probabilidade pré-teste de**<br>**70% para testagem**<br>**discordante**|**evidências de**<br>**acurácia do teste**|
|**Verdadeiros-positivos**<br>(pacientes com doença de<br>Chagas)|15 estudos|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|grave<sup>c</sup>|não grave<sup>d</sup>|nenhum|37 (31 para 40)|617 (518 para 666)|⨁◯◯◯<br>MUITO BAIXA|
|**Falsos-negativos**<br>(pacientes incorretamente<br>classificados como não tendo<br>doença de Chagas)||||||||5 (2 para 11)|83 (34 para 182)||
|**Verdadeiros-negativos**<br>(pacientes sem doença de<br>Chagas)|15 estudos|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|940 (923 para 949)|294 (289 para 297)|⨁⨁◯◯<br>BAIXA|
|**Falsos-positivos**<br>(Pacientes com doença de<br>Chagas incorretamente<br>classificados)||||||||18 (9 para 35)|6 (3 para 11)||  
a. Estudos transversais ou de caso controle com fraco rigor metodológico.  
b. Estudos avaliando testes isoladamente, fora do contexto de combinação de dois testes ou de nova testagem.  
c. Intervalos de confiança com pouca sobreposição entre estimativas pontuais para sensibilidade  
d. Apesar do IC amplo, o motivo pela imprecisão é a inconsistência, já penalizada anteriormente  
* Referências: Vide questão no apêndice.  
108  
**Questão 1.3 Deve-se usar HAI para diagnosticar doença de Chagas na fase crônica?**  
|||**Sensibilidade 0.9**|**1 (95% CI:**|**0.81 para 0.9**|**6)**|**Espe**|**cificidade 0.99**|**(95% CI: 0.97 para 1.00)**|||
|---|---|---|---|---|---|---|---|---|---|---|
||**№ dos estudos**<br>|**Delineamento do**|**Fatores q**|**ue podem re**|**duzir a qualidade**|**da evidência**||**Efeito por 1000 pacientes**<br>**Pbbilidd étt**|**testados**<br>**Pbbilidd étt d**|**Qualidade das**<br>|
|**Desfecho**|**(№ de**<br>**pacientes)**|**estudo**|**Risco**<br>**de viés**|**Evidência**<br>**indireta**|**Inconsistência**|**Imprecisão**|**Viés de**<br>**publicação**|**roaae pr-ese**<br>**de 4.2% para população**<br>**geral**|**roaae pr-ese e**<br>**70% para testagem**<br>**discordante**|**evidências de**<br>**acurácia do teste**|
|**Verdadeiros-positivos**<br>(pacientes com doença de<br>Chagas)|15 estudos|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|grave<sup>c</sup>|não grave|nenhum|38 (34 para 40)|637 (568 para 672)|⨁◯◯◯<br>MUITO BAIXA|
|**Falsos-negativos**<br>(pacientes incorretamente<br>classificados como não tendo<br>doença de Chagas)||||||||4 (2 para 8)|63 (28 para 132)||
|**Verdadeiros-negativos**<br>(pacientes sem doença de<br>Chagas)|15 estudos|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|947 (925 para 954)|297 (290 para 299)|⨁⨁◯◯<br>BAIXA|
|**Falsos-positivos**<br>(Pacientes com doença de<br>Chagas incorretamente<br>classificados)||||||||11 (4 para 33)|3 (1 para 10)||  
a. Estudos transversais ou de caso controle com fraco rigor metodológico.  
b. Estudos avaliando testes isoladamente, fora do contexto de combinação de dois testes ou de nova testagem.  
c. Intervalos de confiança com pouca sobreposição entre estimativas pontuais para sensibilidade.  
* Referências: Vide questão no apêndice.  
109  
**Questão 1.4 Deve-se usar PCR para diagnosticar doença de Chagas na fase crônica?**  
||**Sensibi**|**lidade  0.59 (95% IC: 0**|**.46 para 0**|**.71)**|||**Especi**|**ficidade 0.96 (95% IC: 0.93 p**|**ara 0.98)**||
|---|---|---|---|---|---|---|---|---|---|---|
||**№ dos estudos**||**Fatores q**|**ue podem red**|**uzir a qualidade d**|**a evidência**||**Efeito por 1000 pacientes t**|**estados**|**Qualidade das**|
|||**Delineamento do**|||||||||
|**Desfecho**|**(№ de**<br>**pacientes)**|<br>**estudo**|**Risco**<br>**de viés**|**Evidência**<br>**indireta**|**Inconsistência**|**Imprecisão**|**Viés de**<br>**publicação**|**Probabilidade pré-teste**<br>**de4.2% para população**<br>**geral**|**Probabilidade pré-teste de**<br>**70% para testagem**<br>**discordante**|**evidências de**<br>**acurácia do teste**|
|**Verdadeiros-positivos**<br>(pacientes com doença de<br>Chagas)|42 estudos<br>5038 pacientes|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|grave<sup>c</sup>|não grave|nenhum|25 (19 para 30)|414 (325 para 496)|⨁◯◯◯<br>MUITO BAIXA|
|**Falsos-negativos**<br>(pacientes incorretamente<br>classificados como não tendo<br>doença de Chagas)||||||||17 (12 para 23)|286 (204 para 375)||
|**Verdadeiros-negativos**<br>(pacientes sem doença de<br>Chagas)|42 estudos<br>5038 pacientes|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|920 (895 para 935)|288 (280 para 293)|⨁⨁◯◯<br>BAIXA|
|**Falsos-positivos**<br>(Pacientes com doença de<br>Chagas incorretamente<br>classificados)||||||||38 (23 para 63)|12 (7 para 20)||  
a. Estudos transversais ou de caso controle com fraco rigor metodológico.  
b. Estudos avaliando testes isoladamente, fora do contexto de combinação de dois testes ou de nova testagem.  
c. Intervalos de confiança com pouca sobreposição entre estimativas pontuais para sensibilidade  
* Referências: Vide questão no apêndice.  
110  
**Questão 1.5 Deve-se usar Western Blot para diagnosticar doença de Chagas na fase crônica?**  
||**Sensib**|**ilidade 0.98 (95% IC: 0**|**.96 para 0**|**.99)**|||**Especif**|**icidade 0.99 (95% IC: 0.97 pa**|**ra 0.99)**||
|---|---|---|---|---|---|---|---|---|---|---|
||**№ dos estudos**||**Fatores q**|**ue podem red**|**uzir a qualidade d**|**a evidência**||**Efeito por 1000 pacientes t**|**estados**|**Qualidade das**|
|||**Delineamento do**|||||||||
|**Desfecho**|**(№ de**<br>**pacientes)**|<br>**estudo**|**Risco**<br>**de viés**|**Evidência**<br>**indireta**|**Inconsistência**|**Imprecisão**|**Viés de**<br>**publicação**|**Probabilidade pré-teste**<br>**de4.2% para população**<br>**geral**|**Probabilidade pré-teste de**<br>**70% para testagem**<br>**discordante**|**evidências de**<br>**acurácia do teste**|
|**Verdadeiros-positivos**<br>(pacientes com doença de<br>Chagas)|14 estudos<br>11490 pacientes|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|41 (40 para 41)|685 (673 para 692)|⨁⨁◯◯<br>BAIXA|
|**Falsos-negativos**<br>(pacientes incorretamente<br>classificados como não tendo<br>doença de Chagas)||||||||1 (1 para 2)|15 (8 para 27)||
|**Verdadeiros-negativos**<br>(pacientes sem doença de<br>Chagas)|14 estudos<br>11490 pacientes|Estudos de coorte e<br>caso controle|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|946 (927 para 953)|296 (290 para 299)|⨁⨁◯◯<br>BAIXA|
|**Falsos-positivos**<br>(Pacientes com doença de<br>Chagas incorretamente<br>classificados)||||||||12 (5 para 31)|4 (1 para 10)||  
a. Estudos transversais ou de caso controle com fraco rigor metodológico.  
b. Estudos avaliando testes isoladamente, fora do contexto de combinação de dois testes ou de nova testagem.  
* Referências: Vide questão no apêndice.  
111  
**Questão 1.6 Deve-se usar quimiluminescência para diagnosticar doença de Chagas na fase crônica?**  
|**Sensibilidad**|**e 0.95 (95%**<br>**№ dos**<br>**estudos**|**IC: 0.28 para 1**<br>**Delineamen**|**.00)**<br>**Fatore**|<br>**s que pode**|<br>**1.00)**<br>**m reduzir a qu**|<br>**alidade da ev**|<br>**idência**|**Especificidad**<br>**Efeito por 10**<br>**testados**<br>**Probabilida**|**e 0.98 (95% IC**<br>**00 pacientes**<br>**Probabilida**|**: 0.33 para**<br>**Qualidad**<br>**e das**<br>|
|---|---|---|---|---|---|---|---|---|---|---|
|**Desfecho**|<br>**(№ de**<br>**paciente**<br>**s)**|**to do**<br>**estudo**|**Risc**<br>**o de**<br>**viés**|**Evidênci**<br>**a**<br>**indireta**|**Inconsistênc**<br>**ia**|**Imprecisã**<br>**o**|**Viés de**<br>**publicaçã**<br>**o**|**de pré-teste**<br>**de4.2% **<br>**para**<br>**população**<br>**geral**|**de pré-teste**<br>**de70% **<br>**para**<br>**testagem**<br>**discordante**|**evidência**<br>**s de**<br>**acurácia**<br>**do teste**|
|**Verdadeiros**<br>**-positivos**<br>(pacientes<br>com doença<br>de Chagas)|3 estudos<br>9939<br>pacientes|Estudos de<br>coorte e<br>caso<br>controle|grave<br>a|grave<sup>b</sup>|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|40 (12 para<br>42)|663 (197<br>para 699)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|
|**Falsos-**<br>**negativos**<br>(pacientes<br>incorretamen<br>te<br>classificados<br>como não<br>tendo<br>doença de<br>Chagas)||||||||2 (0 para 30)|37 (1 para<br>503)||
|**Verdadeiros**<br>**-negativos**<br>(pacientes<br>sem doença<br>de Chagas)|3 estudos<br>9939<br>pacientes|Estudos de<br>coorte e<br>caso<br>controle|grave<br>a|grave<sup>b</sup>|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|941 (311<br>para 958)|295 (98 para<br>300)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|
|**Falsos-**<br>**positivos**<br>(Pacientes<br>com doença<br>de Chagas<br>incorretamen<br>te<br>classificados<br>)||||||||17 (0 para<br>647)|5 (0 para<br>202)||  
a. Estudos transversais ou de caso controle com fraco rigor metodológico.  
b. b. Estudos avaliando testes isoladamente, fora do contexto de combinação de dois testes ou de nova testagem.  
c. Intervalos de confiança com pouca sobreposição entre estimativas pontuais para sensibilidade  
d. IC amplo e pequeno número de estudos  
* Referências: Vide questão no apêndice.  
112  
#### **QUESTÃO 2. DEVEMOS UTILIZAR TESTE RÁPIDO COMO ESTRATÉGIA DIAGNÓSTICA INICIAL PARA DESCARTAR DOENÇA DE CHAGAS EM SUA FASE CRÔNICA?**  
**Questão 2.1 Deve-se usar testes rápidos para o diagnóstico da doença de Chagas na fase crônica?**  
|**Sen**<br>**Dfh**|**sibilidade:**<br>**№ dos**<br>**estudos**<br>**№ d**|**0.96 (95% I**<br>**Delinea**<br>**mento**|**C: 0.94 p**<br>**Fatores**<br>**evidênc**|**ara 0.97)**<br>**que pode**<br>**ia**<br>**Evidê**|<br>**m reduzir a**|**Es**<br>**qualidade**|**pecificidade:**<br>**da**|**0.98 (95% IC: 0.97 para 0.99**<br>**Efeito por 1000 pacientes**<br>**testados**|**)**<br>**Qualidade**<br>**das**<br>**idêi**|
|---|---|---|---|---|---|---|---|---|---|
|**eseco**|**( e**<br>**paciente**<br>**s)**|**do**<br>**estudo**|**Risco**<br>**de**<br>**viés**|**ncia**<br>**indiret**<br>**a**|**Inconsist**<br>**ência**|**Imprecis**<br>**ão**|**Viés de**<br>**publicaçã**<br>**o**|**Probabilidade pré-teste**<br>**de4.2% **|**evncas**<br>**de acurácia**<br>**do teste**|
|**Verdadeiros-**<br>**positivos**<br>(pacientes com<br>doença de<br>Chagas)|48<br>estudos<br>paciente<br>s|Estudos<br>de<br>coorte e<br>caso<br>controle|grave<sup>a</sup>|não<br>grave|não grave|não grave|nenhum|40 (39 para 41)|⨁⨁⨁◯<br>MODERADA|
|**Falsos-**<br>**negativos**<br>(pacientes<br>incorretamente<br>classificados<br>como não tendo<br>doença de<br>Chagas)||||||||2 (1 para 3)||
|**Verdadeiros-**<br>**negativos**<br>(pacientes sem<br>doença de<br>Chagas)|48<br>estudos<br>paciente<br>s|Estudos<br>de<br>coorte e<br>caso<br>controle|grave<sup>a</sup>|não<br>grave|não grave|não grave|nenhum|941 (932 para 947)|⨁⨁⨁◯<br>MODERADA|
|**Falsos-**<br>**positivos**<br>(Pacientes com<br>doença de<br>Chagas<br>incorretamente<br>classificados)||||||||17 (11 para 26)||  
a. Estudos transversais ou de caso controle com fraco rigor metodológico. * Referências: Vide questão no apêndice.  
113  
#### **QUESTÃO 3. DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE INDIVÍDUOS COM DOENÇA DE CHAGAS NA FASE AGUDA?**  
**Questão 3.1. Devemos utilizar o benznidazol, em vez de não tratar, em indivíduos com Chagas agudo?**  
|||**Avali**|**ação daqual**|**idade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Qualidade**<br>**geral da**<br>**evidência**|**Impacto**|
|**Follow-up**<br>**Incidência ou pr**|**ogressã**|**o de cardiopatia (**|**seguimento**|**: média 5.6 a**|**nos)**|||
|143<br>(2 estudos<br>observacionais)<br>**Negativação da**|não<br>grave<br>**doença**|grave<sup>a</sup><br>**(seguimento: vari**|não grave<br>**ação 60 dias**|grave<sup>b</sup><br>**para 23 ano**|nenhum<br>**s)**|⨁◯◯◯<br>MUITO<br>BAIXA|Estudo de coorte avaliou indivíduos entre 2 a 72<br>anos com diagnóstico de DC agudo. Entre os<br>47/132 pacientes curados, 32 (68%) tinham ECG<br>normal em avaliações subsequentes. Entre os<br>pacientes não curados, 95/132 dos ECG eram<br>normais (Pinto 2013). Bastos, 2010: os resultados<br>do ECG foram normalizados em cinco dos 11<br>pacientes (91,7%), 180 dias após o término do<br>tratamento.|
|230<br>(6 estudos<br>observacionais)|não<br>grave|grave<sup>a</sup>|grave<sup>c</sup>|grave<sup>d</sup>|forte<br>associação|⨁◯◯◯<br>MUITO<br>BAIXA|De Oliveira-Ferreira 1976 avaliou 2 pacientes com<br>~45 anos e com diagnóstico de Chagas agudo<br>(xenodiagnóstico); estes foram tratados com bnz e<br>negativados. Cançado 2002 avaliou ao longo de<br>13 anos 21 pacientes (0.7 a 60 anos) através de<br>exames sorológicos. Entre estes tratados, 16<br>curaram a doença. Pinto 2013: Estudo de coorte<br>avaliou indivíduos entre 2 a 72 anos com<br>diagnóstico de DC agudo (transmitido<br>principalmente via oral), seguidos por ~5.6 anos.<br>Na fase aguda, entre os 172 pacientes avaliados<br>por xenodiagnóstico, 110 (61.4%) tinham testes<br>positivos na avaliação basal, após um mês, 3<br>(2.1%) e em 1 a 1.5 anos, 2 (1.3%). Entre estes<br>pacientes, quando avaliados por hemocultura, 78<br>tinham diagnóstico de DC na avaliação basal, 3<br>(2.4) em 30 dias e todos negativaram após um<br>ano. Dias 2008:7 indivíduos foram avaliados<br>(sorologia) e em 5 a sorologia foi positiva. A<br>hemocultura revelou que três dos cinco pacientes<br>foram positivos 60 dias após e permaneceram<br>positivos até 120 dias. Valente 2009: 17<br>participantes avaliados foram positivos em pelo<br>menos um teste parasitológico. Iniciou-se o<br>tratamento para todos os pacientes, levando a<br>uma diminuição da parasitemia em 16 durante o<br>período de seguimento (6 meses, 1, 5 e 7 anos).<br>Todos foram sorologicamente negativos 7 anos<br>após o tratamento. Castro et al., 1988: dos 18<br>pacientes com DC agudo, 11 foram tratados com<br>benznidazol (10 a 20mg/kg/dia) e todos<br>negativaram.|  
> a. estudo avaliando crianças e adultos  
b. 1 estudo com amostra pequena  
c. Diferentes técnicas para diagnóstico foram aplicadas.  
d. 5 estudos com amostra pequena  
*Referências: - Oliveira-Ferreira 1976, Cançado 2002, Pinto 2013, Dias 2008, Valente 2009, Castro 1988. Maiores detalhes, vide apêndice 5.  
**<u>Questão 3.2. Devemos utilizar o nifurtimox, em vez de não tratar, em indivíduos com Chagas agudo?</u>**  
|**Avaliação daqualidade**|
|---|  
|**Sumário de Resultados**|
|---|  
114  
|||**Avalia**|**ção daqual**|**idade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Qualidade**|**Impacto**|
|**participantes**<br>**(estudos)**|**de**<br>**viés**||**indireta**||**considerações**|**geral da**<br>**evidência**||
|**Follow-up**<br>**Incidência ou p**|**rogressã**|**o de cardiopatia**||||||
|40<br>(1 estudo<br>observacional)|não<br>grave|grave<sup>a</sup>|não grave|grave<sup>b</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Urrutia et al (1976) avaliou 40 crianças por<br>um período de até 5 anos, onde 32<br>receberam tratamento e 20 realizaram<br>ECG (6 sem mudanças no ECG ou ECG<br>normalizou sem medicamentos (demais<br>pacientes normalizaram ao longo do tto),<br>em 5 pacientes as alterações persistiram.|
|**Negativação da**|**doença**|||||||
|693<br>(7 estudos<br>observacionais)|não<br>grave|grave|grave<sup>a</sup>|grave<sup>c</sup>|forte<br>associação|⨁◯◯◯<br>MUITO<br>BAIXA|Cerisola, 1969, 246 pacientes com chagas<br>agudo receberam tratamento e 18<br>placebos, onde 75% dos tratados com<br>nifurtimox mostraram ausência de<br>anticorpos em 10 a 18 meses. Fernandez<br>1969 avaliou 18 pacientes entre 1 a 55<br>anos, onde 14 negativaram<br>(xenodiagnóstico) completamente após<br>tratamento. Rubio 1969 avaliou 4 casos de<br>DC aguda congênita e estes foram<br>seguidos entre 6 a 24 meses. Todos<br>negativaram os exames parasitológicos<br>após tratamento. Rebosolan 1969 avaliou<br>221 pacientes recebendo o nifurtimox ou<br>28 recebendo placebo. Os pacientes<br>tratados negativaram (xenodiagnóstico)<br>dentro de 60 dias e somente 20<br>negativaram no grupo placebo. Wegner et<br>al 1972 avaliou 139 pacientes que usaram<br>nifurtimox e observou que ao longo de 90<br>dias, todos pacientes zeraram a<br>parasitemia, versus 6 pacientes entre 21<br>do grupo placebo. Schmuñis et al., 1978,<br>em 16 pacientes com Chagas agudo as<br>concentrações de imunoglobulina IgM, IgG<br>e/ou IgA voltaram ao normal com o<br>tratamento com nifurtimox, tanto nos<br>doentes com sorologia negativa como nos<br>que permaneceram positivos. Castro et al.,<br>1988: dos 18 pacientes com Chagas<br>agudo, 7 foram tratados com nifurtimox (10<br>a 15mg/kg/dia) e todos negativaram sua<br>parasitemia.|  
a. Diferentes técnicas sorológicas foram aplicadas, em diferentes populações b. Estudos com tamanho de amostra pequenas. c. 4 estudos com amostra pequenas.  
*Referências: - Urrutia 1976, Cerisola 1969, Fernandez 1969, Rubio 1969, Rebolson 1969, Wegner 1972, Schmuñis 1979, Castro 1988. Maiores detalhes, vide apêndice 5.  
**Questão 3.3. Devemos utilizar benznidazol, em vez de nifurtimox, em indivíduos com Chagas agudo?** Não há evidências comparando estas intervenções.  
115  
#### **QUESTÃO 4. DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE CRIANÇAS E ADOLESCENTES COM DOENÇA DE CHAGAS NA FASE CRÔNICA INDETERMINADA?**  
**Questão 4.1. Devemos utilizar benznidazol, em vez de não tratar, no tratamento de crianças e adolescentes com doença de chagas na fase crônica indeterminada?**  
|**№ de**<br>**participante**|**Risc**<br>**o de**<br>|**Avali**<br>**Inconsistênc**<br>**ia**|**ação daqu **<br>**Evidênci**<br>**a**<br>|**alidade**<br>**Imprecisã**<br>**o**|**Outras**<br>**Consideraçõ**|**Qualidad**<br>**e geral**<br>|**Taxas**<br>**do es**|**Sumári**<br>**de eventos**<br>**tudo(%)**|**o de Resu**<br>**Efeito**<br>**relativ**|**ltados**<br>**Efeito**<br>**p **|<br>**s absolutos**<br>**otenciais**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**s**<br>**(estudos)**<br>**Progressão**|**viés**<br>**para for**|**ma cardíaca (se**|**indireta**<br>**guimento: v**|**ariação 48 m**|**es**<br>**eses para 72 m**|**da**<br>**evidênci**<br>**a**<br>**eses)**|**Com**<br>**não**<br>**tratar**|**Com**<br>**benznidaz**<br>**ol**|**o**<br>**(95%**<br>**IC)**|**Risc**<br>**o**<br>**com**<br>**não**<br>**trata**<br>**r**|**Diferença**<br>**de risco**<br>**com**<br>**benznidaz**<br>**ol**|
|296<br>(3 ECRs)|não<br>grave<br>|não grave|não<br>grave<sup>b</sup>|muito<br>grave<sup>c</sup>|nenhum|⨁⨁◯<br>◯|13/144<br>(9.0%)|10/152<br>(6.6%)|**RR**<br>**0.70**<br>|**Horiz**<br>**anos**|**onte 4 a 5**<br>|
||a|||||BAIXA|||(0.32<br>para<br>1.52)|90<br>por<br>1.00<br>0<br>**Horiz**<br>300<br>por<br>1.00<br>0|**27 menos**<br>**por 1.000**<br>(61 menos<br>para 47<br>mais)<br>**onte****_lifetime_**<br>**90 menos**<br>**por 1.000**<br>(204<br>menos<br>para 156|
|**Negativação**|**sorológ**|**ica (seguimento**|**: variação**|**4 anos para**|**6 anos)**||||||mais)|
|217<br>(2 ECRs)<sup>d, e</sup>|não<br>grave|não grave|não<br>grave|não grave<br>f|nenhum|⨁⨁⨁⨁<br>ALTA|14/109<br>(12.8%<br>)|52/108<br>(48.1%)|**RR 4.0**<br>(2.3<br>para<br>6.8)|128<br>por<br>1.00<br>0|**385 mais**<br>**por 1.000**<br>(167 mais<br>para 745|
||||||||||||mais)|
|**Efeitos adver**|**sos**|||||||||||
|2804<br>(1 estudo)|não<br>grave|não grave|não<br>grave|não grave|nenhum|⨁⨁◯<br>◯<br>BAIXA|Foi enco<br>avaliand<br>adolesce<br>indeterm<br>gerais fo<br>moderad<br>foram de<br>dermatol<br>23%)|ntrado um es<br>o os efeitos a<br>ntes com doe<br>inada. A prev<br>i 33.3%, send<br>o. Os efeitos<br>sordens gast<br>ógicas (13 a|tudo obse<br>dversos e<br>nça de C<br>alência de<br>o a maior<br>adversos<br>rointestina<br>68%) e ne|rvacion<br>m crian<br>hagas n<br>efeitos<br>ia (>95<br>mais fre<br>is (25%<br>uromus|al (Yun,2009)<br>ças e<br>a fase<br>adversos<br>%) leve ou<br>quentes<br>),<br>culares (10 a|
|**Mortalidade**||||||||||||
|0<br>(0 estudos)<br>**IC:**intervalo de|confianç|a;**RR:**risco relativo||||-|Não fora<br>mortalid<br>de benz<br>redução<br>paciente|m identificado<br>ade em crianç<br>nidazol. Evidê<br>da mortalidad<br>s.|s estudos<br>as e adol<br>ncias par<br>e para 35|avalian<br>escente<br>a adulto<br>menos|do<br>s com o uso<br>s mostram<br>a cada 1000|  
116  
a. Apesar de estudos pequenos, em geral possuíam adequado rigor metodológico, com randomização e alocação adequadas, sendo dois estudos cegados.  
b. Estudos Estani 1998 e Colantonio 2016 incluíam 5 a 8% de indivíduos com cardiomiopatia chagásica (anormalidades ECG), avaliando progressão da doença; o impacto tende a ser baixo, não sendo reduzido o nível de evidência nesse caso  
c. Estudos pequenos, com apenas 23 desfechos, gerando intervalo de confiança amplo  
d. Andrade et al: análise _per protocol_ (6 anos), RR 3,4 (IC95% 2,1 a 5,6; 88% vs. 26%). Em análise de 3 anos ( _intention to treat_ ), soroconversão foi de 58% vs. 5% (RR 12,5, IC95% 4 a 38)  
e. Yun 2009 avaliou soroconversão com tratamento de benznidazol entre 18 e 36 meses pós tratamento, em um estudo observacional, não-comparado, na América Latina, avaliando 2840 crianças e adolescentes. As taxas de soroconversão foram bastante variáveis, sendo 3,1% na Bolívia, 58% na Guatemala e 87% em Honduras.  
f. Estudo pequeno, contudo mostrando tamanho de efeito grande. Optado por não baixar o nível de evidência por imprecisão.  
*Referências: - Andrade 2004, Estani 2008, Colantonio 2016, Yun 2009. Maiores detalhes, vide apêndice 5.  
117  
**Questão 4.2 Devemos utilizar o nifurtimox, em vez de não tratar, no tratamento de crianças e adolescentes com doença de Chagas na fase crônica indeterminada?**  
|||**Avalia**|**ção daqualid**|**ade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|**Qualidade**<br>**geral da**<br>**evidência**|**Impacto**|
|<br>**Progressão par**|<br>**a doenç**|**a cardiovascular**|**(seguimento**|**: variação 6 m**|**eses para 3**|<br>**0 meses)**||
|69<br>(3 estudos<br>observacionais)|não<br>grave|não grave|grave<sup>a,b</sup>|muito grave<br>c|nenhum|⨁◯◯◯<br>MUITO<br>|Estudos avaliaram 69 crianças ou adolescentes<br>fazendo uso de nifurtimox. Dentre estes, 4<br>aresentaram alteraões ECG|
|<br>**Negativação so**|**rológica**|**(seguimento: va**|**riação 3 mes**|**es para 24 an**|**os)**|BAIXA|p ç .|
|69<br>(3 estudos<br>observacionais)|não<br>grave|grave<sup>d</sup>|não grave|grave<sup>e</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Foram encontrados 3 estudos observacionais<br>avaliando negativação sorológica em crianças.<br>A. Estudo de coorte com 33 crianças, onde 10<br>realizaram xenodiagnóstico após 360 dias,<br>onde no grupo tratado com Nifurtimox todas<br>crianças negativaram e no grupo placebo,<br>somente ¼ (Chicero et al., 1969).<br>B. Estudo de coorte Rubio e Donoso, 1969<br>avaliou 5 casos crônicos, seguidos de 6 a 24<br>meses após termino do tratamento. Em cinco<br>casos crônicos de crianças chagásicas a<br>hemaglutinação foi positiva em todos os casos,<br>não ocorrendo negativação sorológica.<br>C. Estudo de Bianchi et al., 2015 incluiu 62<br>crianças entre 4 e 19 anos tratadas com<br>Nifurtimox por 2 meses e seguidos por 30<br>meses após o tratamento. A negativação<br>sorológica de dois testes ocorreu em 12,5%<br>(IC95% 2.36-22.64, n=8) após 12 meses de<br>tratamento e 41,9% (IC95% 26,5-57,3, n=26)<br>após 30 meses de tratamento.|
|**Eventos advers**|**os**|||||||
|92<br>(2 estudos<br>observacionais)|grave<sup>f</sup>|não grave|não grave|grave<sup>g</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Entre os 92 pacientes analisados, 1 apresentou<br>complicações dermatológicas, 31 relataram<br>anorexia, 13 náuseas, 1 apresentou alterações<br>nas enzimas hepáticas, 10 relataram dores de|
||||||||cabeça e 9 fraqueza.|
|**Mortalidade**||||||||
|0<br>(0 estudos)|||||||Não foram identificados estudos avaliando<br>mortalidade em crianças e adolescentes com o<br>uso de nifurtimox.<br>Evidências para adultos procedentes de 2<br>estudos de coorte, com 55 pacientes e 7<br>eventos, mostram maior mortalidade com<br>nifurtimox, sem significância estatística (RR<br>1,67; IC95% 0;16-17.42). Qualidade da<br>evidência muito baixa.|  
**IC:** intervalo de confiança; **RR:** risco relativo  
a. Aproximadamente 5% dos casos eram congênitos agudos e 6% possuíam cardiopatia congênita na lista de base. b. Período de acompanhamento relativamente pequeno para o desfecho de interesse.  
c. Total de 76 crianças acompanhadas por 6 a 30 meses, com apenas 4 eventos  
d. Estudos com estimativas pontuais bastante diferentes, variando de benefício importante a efeito pequeno  
118  
e. 3 estudos pequenos e IC95% com significância borderline  
f. Estudos com duração de tratamento diferente (60 e 120 d), um estudo comparado com placebo.  
g. 2 estudos observacionais pequenos, com 92 pacientes  
*Referências: - Chicero 1969, Rubio e Donoso 1969, Bianchi 2015. Maiores detalhes, vide apêndice 5.  
119  
**Questão 4.3. Devemos utilizar o benznidazol, em vez de nifurtimox, em crianças e adolescentes com doença de Chagas na fase crônica indeterminada?**  
|||**Avaliaç**|**ão daquali**|**dade**||||**Sumár**|**io de Re**|**sultados**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**participante**|**Risc**<br>**o de**<br>|**Inconsistên**<br>**cia**|**Evidênc**<br>**ia**|**Imprecis**<br>**ão**|**Viés de**<br>**publicaç**|**Qualida**<br>**de geral**|**Taxas de**<br>**estudo(%**|**eventos do**<br>**)**|**Efeito**<br>**relativ**|**Efeitos a**<br>**potenciai**|**bsolutos**<br>**s**|
|**s**|**viés**||**indireta**||**ão**|**da**|||**o**|||
|**(estudos)**<br>**Follow-up**||||||**evidênci**<br>**a**|**Com**<br>**nifurtim**<br>**ox**|**Com**<br>**benznidaz**<br>**ol**|**(95%**<br>**IC)**|**Risco**<br>**com**<br>**nifurtim**|**Diferença**<br>**com**<br>**nifurtimox**|
|**Negativação**|**sorológ**|**ica por xenodia**|**gnóstico (**|**seguimento**|**: variação 1**|**3 semanas**|<br>**para 24 an**|<br>**os)**||**ox**||
|276<br>(3 estudos<br>observaciona<br>is)<br>**Negativação**|não<br>grav<br>e<br>**sorológ**|grave<sup>a</sup><br>**ica por sorolog**|grave<sup>b</sup><br>**ia (seguim**|grave<sup>c</sup><br>**ento: variaç**|nenhum<br>**ão 5 anos p**|⨁◯◯<br>◯<br>MUITO<br>BAIXA<br>**ara 20 anos**|39/112<br>(34.8%)<br>**)**|67/164<br>(40.9%)|**RR**<br>**0.72**<br>(0.42<br>para<br>1.22)|348 por<br>1.000|**98 mais**<br>**negativaçõ**<br>**es com**<br>**nifurtimox**<br>**por 1.000**<br>(202 mais<br>para 77<br>menos)|
|197<br>(2 estudos<br>observaciona<br>is)|não<br>grav<br>e|grave<sup>a</sup>|grave<sup>b</sup>|grave<sup>d</sup>|nenhum|⨁◯◯<br>◯<br>MUITO<br>BAIXA|9/66<br>(13.6%)|28/131<br>(21.4%)|**RR**<br>**1.21**<br>(0.26<br>para<br>5.63)|136 por<br>1.000|**29 menos**<br>**negativaçõ**<br>**es com**<br>**nifurtimox**<br>**por 1.000**<br>(101 mais<br>para 631<br>menos)|
|**Efeitos adver**|**sos**|||||||||||
|95<br>(1 estudo<br>observaciona<br>l)|grav<br>e<sup>e</sup>|não grave|grave<sup>b</sup>|grave<sup>f</sup>|nenhum|⨁◯◯<br>◯<br>MUITO<br>BAIXA|2 (3,8%) a<br>levando a<br>apresenta<br>levemente<br>maior gra<br>(vômitos,|presentaram i<br>suspensão da<br>dos pelo nifurt<br>dolorosa, tra<br>vidade do que<br>eritema com e|ntolerânc<br>medicaç<br>imox (an<br>nsaminas<br>os apres<br>dema e p|ia ao benz<br>ão. Os efei<br>orexia, hep<br>e aumenta<br>entados pe<br>rurido).|nidazol,<br>tos colaterais<br>atomegalia<br>da) foram de<br>lo benznidazol|  
**IC:** intervalo de confiança; **RR:** risco relativo  
a. Diferenças elevadas nas estimativas de efeito, I<sup>2</sup> alto (79%)  
b. População incluindo crianças, adolescentes e adultos  
c. Um estudo com pequeno N de eventos (nifurtimox = 1 e benznidazol = 26)  
d. Somente 2 estudos com pequeno N de eventos (nifurtimox = 9 e benznidazol = 28)  
e. Os efeitos adversos foram mal relatados; este desfecho foi avaliado em apenas 60 crianças (perda de seguimento de 1/3 da amostra).  
f. Um estudo com pequeno N de eventos.  
*Referências: - de Oliveira-Ferreira 1991, Levi 1996, Shenone 1981, Streiger 2004. Maiores detalhes, vide apêndice 5.  
#### **QUESTÃO 5. DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE ADULTOS COM DOENÇA DE CHAGAS NA FASE CRÔNICA INDETERMINADA?**  
**Questão 5.1. Devemos utilizar o benznidazol, em vez de não tratar, em adultos com doença de Chagas na fase crônica indeterminada?**  
**Sumário de Resultados**  
**Avaliação da qualidade**  
120  
|**№ de**<br>**tiit**|**Risco**<br>**d**|**Aval**<br>**Inconsistênci**|**iação da quali**<br>**a**<br>**Evidência**<br>**idit**|**dade**<br>**Imprecisão**|**Viés de**<br>**bliã**|**Qualidade**<br>**l d**|**Taxas de**<br>**td**|**Sum**<br>**eventos do**<br>|**ário de Resu**<br>**Efeito**<br>**lti**|**ltados**<br>**Efeitos a**<br>**ti**|**bsolutos**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**parcpanes**<br>**(estudos)**|**e**<br>**viés**||**nrea**||**pucaço**|**gera a**<br>**evidência**|**esuo (**|**)**|**reavo**<br>**(95% IC)**|**poenca**|**s**|
||||||||**Com**<br>**não**|**Com**<br>**benznidazol**||**Risco**<br>**em não**|**Diferença de**<br>**risco com**|
||||||||**tratar**|||**tratar**|**benznidazol**|
|**Progressão da**|**forma car**|**díaca (seguime**|**nto: média de 9**|**,8 anos)**||||||||
|566<br>(1RCT)|grave<sup>a</sup>|não grave|grave<sup>b</sup>|não|nenhum|⨁⨁◯◯<br>BAIXA|40/283<br>(14.1%)|12/283 (4.2%)|**RR 0.24**<br>(0.10|141 por<br>1.000|**105 menos por**<br>**1.000**<br>|
||||||||||para<br>0.59)||(55 menos para<br>126 mais)|
|**Progressão da**|**forma car**|**díaca (seguime**|**nto: variação 3**|**anos para 20**|**anos)**|||||||
|559|não|grave<sup>c</sup>|grave<sup>d</sup>|grave<sup>c e</sup>|nenhum|⨁◯◯◯|6/161|13/398 (3.3%)|**RR 0.53**|**Horizonte**|**3 a 20 anos**|
|(3 estudos|grave|||||MUITO|(3.7%)||(0.21|||
|observacionais)||||||BAIXA|||para<br>1.35)|40 por<br>1.000|**19 menos por**<br>**1.000**<br>|
|||||||||||**Horizonte**|(32 menos para<br>14 mais)<br> **_lifetime_**|
|||||||||||300 por<br>1.000|**141 menos por**<br>**1.000**<br>(237 menos|
|**Negativação so**|**rológica (**|**seguimento: m**|**édia de 9,8 ano**<br>|**s)**|||||||para 105 mais)|
|566<br>(1RCT)|grave<sup>a</sup>|não grave|grave<sup>b</sup>|não|nenhum|⨁⨁◯◯<br>BAIXA|12/212<br>(5.7%)|32/218(14.7%)|**RR 2.10**<br>(1.06<br>para|57 por<br>1.000|**59 mais por**<br>**1.000**<br>(3 mais para|
||||||||||<br>4.06)||<br>154 mais)|
|**Negativação so**|**rológica (**|**seguimento: va**|**riação 3 anos**|**para 8 anos)**||||||||
|457<br>(4 estudos<br>|<br>não<br>grave|grave<sup>f</sup>|grave|não grave|nenhum|⨁◯◯◯<br>MUITO<br>|35/260<br>(13.5%)|106/388<br>(27.3%)|**RR 4.47**<br>(0.59<br>|135 por<br>1.000|**467 mais por**<br>**1.000**<br>|
|observacionais)||||||BAIXA|||para<br>||(55 menos para<br>|
|**Negativação po**|**r PCR (se**|**guimento: varia**|**ção 5 anos pa**|**ra 13 anos)**|||||33.97)||1000 mais)|
|152<br>(2 estudos|não<br>grave|grave|grave<sup>i</sup>|grave<sup>f</sup>|nenhum|⨁◯◯◯<br>MUITO|27/66<br>(40.9%)|28/86 (32.6%)|**RR 0.99**<br>(0.29|409 por<br>1.000|**4 menos por**<br>**1.000**|
|observacionais)||||||BAIXA|||para<br>335)||(290 menos<br>para 591 mais)|
|**Mortalidade (se**|**guimento**|**: variação 8 ano**|**s para 10 anos**|**)**|||||.|||
|525<br>(2 estudos|não<br>grave|não grave<sup>g</sup>|não grave<br>d|muito grave<br>h|nenhum|⨁◯◯◯<br>MUITO|6/123<br>(4.9%)|8/402 (2.0%)|**RR 0.28**<br>(0.10|49 por<br>1.000|**35 menos por**<br>**1.000**|
|observacionais)||||||BAIXA|||para||(44 menos para|
|**Efeitos adverso**|**s**||||||||0.77)||11 menos)|  
121  
|||**Aval**|**iação da qualid**|**ade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|1299<br>(estudos<br>observacionais)|grave<sup>j</sup>|grave|não grave|não grave|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|A frequência de eventos adversos gerais foi de 53.28% (95% IC 32.18<br>- 73.27, n = 528).<br>A frequência de efeitos adversos neurológicos (não especificados) foi<br>de 7.97% (95% IC 1.03 – 41.98, n = 681) e de parestesia de 10.30%<br>(95% IC 1.93 - 40.10, n = 546). A frequência de artralgia foi de 8.14%<br>(95% IC 3.15 - 19.48, n = 709)<br>A frequência de efeitos adversos gastrointestinais foi de 13.25% (95%<br>IC 7.55 – 22.23, n = 1254). A frequência de efeitos adversos<br>dermatológicos foi: dermatite alérgica (8.51%, 95%IC 3.23 - 20.58, n=<br>47), alopecia (0.85%, 0.32 - 2.24, n = 472), reação cutânea (61.54%,<br>42.07 - 77.90, n = 26), dermatite (44.12%, 13.36 - 81.56, n = 500),<br>descamação da pele (5.66%, 0.21 - 63.57, n = 504), edema (9.38%,<br>3.06 - 25.35, n = 32), eritrema (12.50%, 4.77 - 28.94, n = 32), erupções<br>cutâneas (12.50%, 4.77 - 28.94, n = 32) e_rash_(21.95%, 7.67 - 48.77, n<br>= 709).|  
**IC:** intervalo de confiança; **RR:** risco relativo  
a. Houve perda de seguimento de >20% da amostra.  
b. Aproximadamente 36% da amostra já possuía alguma anormalidade ECG. Em pacientes tratados, o risco para desenvolver alterações no ECG foi HR=0.27 (CI 0.13-0.57) e risco de alteração na fração de ejeção foi de HR=0.97 (CI 0.94-0.99), em relação aos não tratados.  
c. Estudos com pequeno número de eventos.  
d. Dois estudos incluíram população com ECG normal ou anormal e um estudo, com N maior (Fragata Filho et al) incluiu somente pacientes com nenhuma alteração no ECG na avaliação basal.  
e. Dois estudos pequenos, sendo que um deles não apresentou nenhuma alteração ECG, gerando intervalo de confiança amplo  
f. Diferentes técnicas sorológicas foram aplicadas, em diferentes populações  
g. Dois estudos com N de eventos pequeno, sendo que um deles apresentou somente um evento em cada grupo, gerando intervalo de confiança amplo  
h. Estudos com pequeno número de eventos e IC95% amplo  
i. Um estudo apresenta população de crianças e adultos, sendo a maioria entre 22 a 37 anos  
j. Estudos não comparados  
*Referências: - Coura 1997, Bertocchi 2013, Viotti 2011, Fragata-Filho 2016, Aguiar 2012, Laucella 2009, Viotti 1994, Machado de Assis 2013. Maiores detalhes, vide apêndice 5.  
122  
**Questão 5.2. Devemos utilizar o nifurtimox, em vez de não tratar, em adultos com doença de Chagas na fase crônica indeterminada?**  
|||**Avaliaç**|**ão daqualid**|**ade**||||**Sumári**|**o de Res**|**ultados**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>|**Risco**<br>**de**<br>|**Inconsistênci**<br>**a**|**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|**Viés de**<br>**publicaçã**<br>|**Qualidad**<br>**e geral da**<br>|**Taxas**<br>**do estu**|**de eventos**<br>**do(%)**|**Efeito**<br>**relativ**<br>|**Efeito**<br>**poten**|**s absolutos**<br>**ciais**|
|**(estudos)**|**viés**||||**o**|**evidência**|||**o**|||
|**Follow-up**<br>**Mortalidade**|||||||**Com**<br>**não**<br>**tratar**|**Com**<br>**nifurtimo**<br>**x**|**(95%**<br>**CI)**|**Risc**<br>**o**<br>**com**<br>**não**<br>**tratar**|<br>**Diferença**<br>**de risco**<br>**com**<br>**nifurtimo**<br>**x**|
|55<br>(2 estudos<br>observacionais<br>)|não<br>grave|grave<sup>a</sup>|não grave|muito<br>grave<sup>b</sup>|nenhum|⨁◯◯<br>◯<br>MUITO<br>BAIXA|2/25<br>(8.0%<br>)|5/30<br>(16.7%)|**RR**<br>**1.67**<br>(0.16<br>para<br>|80<br>por<br>1.000|**54 mais**<br>**por 1.000**<br>(67 menos<br>para 920<br>|
|**Negativação pa**<br>|**rasitoló**|**gica (seguiment**<br>|**o: variação**<br>|**30 dias para**<br>|**13 meses)**<br>||||17.42)<br>||mais)<br>|
|114<br>(3 estudos<br>observacionais<br>)<br>**Efeitos adverso**|grave<br>c<br>**s (segu**|grave<sup>d</sup><br>**imento: variação**|não grave<br>**4 meses pa**|grave<sup>e</sup><br>**ra 7 meses)**|nenhum|⨁◯◯<br>◯<br>MUITO<br>BAIXA|Em um<br>(90,5%)<br>avaliad<br>Outro<br>grupo<br>pacient<br>soment<br>negativ<br>xenodia<br>No estu<br>nifurtim<br>no grup|estudo (Mun<br>negativara<br>o por xenodia<br>estudo (Sc<br>nifurtimox<br>es do gru<br>e 1 de 6<br>aram. Ambo<br>gnóstico.<br>do de Cour<br>ox e placebo<br>o tratado ver|oz 2013),<br>m com o<br>gnóstico.<br>henone<br>e place<br>po trata<br>pacientes<br>s grupos<br>a 1997, c<br>, 90% pa<br>sus 64%|19 de<br>uso d<br> <br>1969),<br>bo, 10<br>do neg<br>do gr<br>foram a<br>ompara<br>cientes<br>no grupo|21 pacientes<br>e nifurtimox<br>comparando<br>/10 (100%)<br>ativaram e<br>upo placebo<br>valiados por<br>ndo o grupo<br>negativaram<br>placebo.|
|144<br>(4 estudos<br>observacionais<br>)<br>**IC:**intervalo de co<br>a. Dois estudos co<br>b. Dois estudos pe|grave<sup>f</sup><br>nfiança;**R**<br>m N de e<br>quenos c|grave<sup>d</sup><br>**R:**risco relativo<br>ventos pequenos, I<sup>2</sup><br>om intervalo de con|não grave<br>=50%.<br>fiança amplo.|grave<sup>g</sup><br>|nenhum|⨁◯◯<br>◯<br>MUITO<br>BAIXA|A frequ<br>85.37%<br>A frequ<br>foi de 1<br>A frequ<br>foi de 6<br>A frequ<br>foi de 3|ência de eve<br>(95% IC 16.<br>ência de efeit<br>5.01% (95%<br>ência de efeit<br>1.37% (95%<br>ência de efeit<br>3.33% (95%|ntos adve<br>86 - 59.66<br>os advers<br>IC 9.98 –<br>os advers<br>IC 2.68 –<br>os advers<br>IC 14.60 -|rsos ger<br>, n = 48<br>os derm<br>21.94, n<br>os gast<br>98.92, n<br>os reum<br>59.40,|ais foi de<br>).<br>atológicos<br>= 144).<br>rointestinais<br>= 48).<br>atológicos<br>n = 15).|  
c. Um estudo não foi comparado.  
d. Não há dados suficientes para avaliar a inconsistência.  
e. Grande variação no tempo de seguimento.  
f. Dois estudos não foram comparados.  
g. Estudos com N pequeno.  
*Referências: - Munoz 2013, Schenone 1969, Wegner 1972, Coura 1997, Cançado,1976, Bocanegra,2015, Silva, 1974, Jackson, 2010. Maiores detalhes, vide apêndice 5.  
123  
**Questão 5.3. Devemos utilizar benznidazol, em vez de nifurtimox, em adultos com doença de Chagas na fase crônica indeterminada?**  
Não há evidências comparando estas intervenções.  
#### **QUESTÃO 6. DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE INDIVÍDUOS COM DOENÇA DE CHAGAS NA FASE CRÔNICA DIGESTIVA, SEM COMPROMETIMENTO CARDÍACO?**  
Não foram encontradas evidências comparando o uso de benznidazol e nifurtimox em indivíduos com doença de Chagas na fase crônica digestiva.  
124  
#### **QUESTÃO 7. DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE INDIVÍDUOS COM CARDIOPATIA CHAGÁSICA?** **<u>Questão 7.1 Devemos utilizar o benznidazol, em vez de não tratar, em indivíduos com cardiopatia chagásica?</u>**  
||||**Avaliação da quali**|**dade**|||||
|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**<br>**Desfecho co**|**Risco de viés**<br>**mposto: morte e ev**|**Inconsistênci**<br>**entos cardiovascu**|**a**<br>**Evidência indireta**<br>**lares (seguimento: média 5.**|**Imprecisão**<br>**4 anos; avaliado com:**|**Viés de**<br>**publicação**<br>**parada cardíaca re**|**Qualidade geral d**<br>**evidência**<br>**animada, AVC, trans**|**a**<br>**Taxas de eventos**<br>**Com não tratar**<br>**plante, ICC, implante**|**do estudo (%)**<br>**Com benznidazol**<br>**de CDI ou MP, taquicard**|
|2854<br>(1 ECR)<sup>a</sup>|não grave<sup>b</sup>|grave<sup>c</sup>|não grave|não grave|nenhum|⨁⨁⨁◯<br>MODERADA|414/1423<br>(29.1%)|394/1431 (27.5%)|
|**Desfecho co**|**mposto: morte e ev**|**entos cardiovascu**|**lares - dados referentes ao**|**Brasil (seguimento: mé**|**dia 5.4 anos)**||||
|1358<br>(1 ECR)|grave<sup>d,e</sup>|não grave|não grave|grave<sup>f</sup>|nenhum|⨁⨁◯◯<br>BAIXA|21.4%|18.4%|
|<br>**Insuficiência**|**cardíaca (início ou**|**piora) (seguiment**|**o: média 5.4 anos)**||||||
|2854<br>|não grave<sup>b,c</sup>|grave<sup>c</sup>|grave<sup>c g</sup>|não grave|nenhum|⨁⨁◯◯|122/1423 (8.6%)|109/1431 (7.6%)|
|(1 ECR)||||||BAIXA|||
|**Hospitalizaç**<br>|**ão (seguimento: mé**|**dia 5.4 anos)**|||||||
|2854<br>1 ECR|não grave|grave<sup>c</sup>|não grave|não grave|nenhum|⨁⨁⨁◯<br>|397/1423<br>279%|358/1431 (25.0%)|
|( )||||||MODERADA|(.)||
|**Hospitalizaç**|**ão por DCV (seguim**|**ento: média 5.4 an**|**os)**||||||
|2854<br>(1 ECR)|não grave|grave<sup>c</sup>|não grave|não grave|nenhum|⨁⨁⨁◯<br>|286/1423<br>(201%)|242/1431 (16.9%)|
|<br>**Mortalidade**|**por DCV (seguimen**|**to: média 5.4 anos**|**)**|||MODERADA|.||
|2854<br>|não grave|grave<sup>c</sup>|não grave|não grave|nenhum|⨁⨁⨁◯<br>|203/1423<br>|194/1431 (13.6%)|
|(1 ECR)||||||MODERADA|(14.3%)||
|**Qualquer efe**|**ito adverso (seguim**|**ento: média 5.4 a**|**nos)**||||||
|2851<br>|não grave|grave<sup>c</sup>|não grave|não grave|nenhum|⨁⨁⨁◯|135/1422 (9.5%)|342/1429 (23.9%)|
|(1 ECR)||||||MODERADA|||
|<br>**Negativação**|**(conversão de PCR**|**positivo para neg**|**ativo) (seguimento: média 5**|**.4 anos)**|||||
|1148<br>|não grave|grave<sup>c</sup>|não grave|Não grave|nenhum|⨁⨁⨁◯<br>|203/574 (35.4%)|317/574 (55.2%)|
|(1 ECR)<br>**Negativação**|**- dados referentes**|**ao Brasil (convers**|**ão de PCR positivo para ne**|**gativo) (seguimento: m**|**édia 5.4 anos)**|MODERADA|||
|213<br>(1 ECR)|grave<sup>d,e</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>MODERADA|--|--|  
**IC:** intervalo de confiança; **RR:** risco relativo **; OR:** razão de chances, **HR:** Hazard Ratio;  
a. Um ECR (Viotti 2006) avaliou mortalidade em pacientes sem alterações ECG (60% amostra) e com alterações (30%). Pacientes tratados morreram menos (3/283) que os não tratados (12/283). Entre os 15 óbitos, 13 ocorreram em pacientes que já possuíam alterações no ECG quando incluídos)  
b **.** Ensaio clinico prospectivo, multicêntrico, randomizado envolvendo 2854 pacientes com cardiomiopatia chagásica  
c. Em análise de subgrupos, verificou-se resultados diferentes em diferentes países, podendo sugerir efeito diferente do benznidazol de acordo com o subtipo de _T_  
_Cruzi_ , com melhores resultados no Brasil, seguido de Argentina e Bolívia, com piores resultados em El Salvador e Colômbia  
- d. Refere-se à mortalidade, parada cardíaca, taquicardia ventricular sustentada (TVS), piora da insuficiência cardíaca crônica, implantação do marcapasso ou CDI, transplante cardíaco, acidente vascular cerebral, ataque isquêmico transitório, embolia sistêmica, tromboembolismo.  
e. Análise de subgrupo, desfecho não decidido a priori  
g **.** Desfecho composto: morte e eventos cardiovasculares (PCR, AVC, transplante, ICC, implante de CDI ou MP, taquicardia ventricular sustentada)  
f. Tendência a benefício com significância _borderline_  
*Referências: Morillo 2015, Viotti 2006. Maiores detalhes, vide apêndice 5.  
125  
**QUESTÃO 8. DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE PACIENTES HIV POSITIVOS E COM DOENÇA DE CHAGAS NA FASE CRÔNICA?** **<u>Questão 8.1. Devemos utilizar tratamento etiológico em pacientes HIV positivos e com reativação da doença de Chagas?</u>**  
|||**Aval**|**iação daqu **|**alidade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**<br>**Mortalidade (s**|**Risco**<br>**de**<br>**viés**<br>**eguimen**|**Inconsistência**<br>**to: variação 1 m**|**Evidência**<br>**indireta**<br>**eses para 1**|<br>**Imprecisão**<br>**90 meses)**|**Outras**<br>**considerações**|**Qualidade**<br>**geral da**<br>**evidência**|**Impacto**|
|17<br>(1 estudo<br>observacional)<br>**Parasitemia (s**|não<br>grave<br>**eguimen**|não grave<br>**to: variação 1 m**|grave<sup>a</sup><br>**eses para 1**|grave<sup>b</sup><br>**90 meses)**|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Tratados 9 pacientes devido a reativação e 8<br>pacientes devido à alta parasitemia.<br>Dos 9 pacientes que receberam benznidazol<br>por reativação da doença de Chagas, cinco<br>(55%) vieram a óbito durante o tratamento,<br>três deles por motivos relacionados à doença<br>de Chagas e dois por outras coinfecções.<br>Todos os 8 pacientes com HIV e alta<br>parasitemia, sem reativação sobreviveram os<br>dois meses.<br>Após o termino do tratamento, os 12<br>pacientes que sobreviveram foram<br>acompanhados por entre 7 e 146 meses, e 3<br>(25%) vieram a óbito (um por morte subida 27<br>meses após o tratamento; outro por sepse<br>poucos dias após o fim do tratamento; outro<br>sem informações).|
|17<br>(1 estudo<br>observacional)<br>**Efeitos advers**|não<br>grave<br>**os (segu**|não grave<br>**imento: variaçã**|grave<sup>a</sup><br>**o 1 meses p**|grave<sup>b</sup><br>**ara 190 meses**|nenhum<br>**)**|⨁◯◯◯<br>MUITO<br>BAIXA|Os 12 pacientes que completaram o<br>tratamento com benznidazol após reativação<br>apresentaram redução da parasitemia para<br>níveis não detectáveis (100%). Após o fim do<br>tratamento, apenas 1 (8%) paciente<br>apresentou parasitemia novamente. 13<br>meses após a última dose de benznidazol.|
|17<br>(1 estudo<br>observacional)|não<br>grave|não grave|grave<sup>a</sup>|grave<sup>b</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Entre os 17 pacientes tratados com<br>benznidazol, cinco pacientes (29%)<br>reportaram efeitos adversos: 3 casos de_rash_<br>cutâneo, 1 caso de febre, 1 caso de<br>leucopenia e trombocitopenia e 1 caso de dor<br>neuropática periférica.|  
a. Pacientes com reativação e/ou alta parasitemia  
b. Um único estudo com N pequeno (17) e baixo número de eventos.  
*Referências: Sartori 2007. Maiores detalhes, vide questão no apêndice.  
#### **QUESTÃO 9.   DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE PACIENTES TRANSPLANTADOS E COM DOENÇA DE CHAGAS NA FASE CRÔNICA? Questão 9.1 Devemos utilizar tratamento etiológico em pacientes transplantados e com doença de Chagas na fase crônica em casos de reativação?**  
**Avalia** **<mark>ç</mark> ão da** **<mark>q</mark> ualidade Sumário de Resultados**  
126  
|||**Avalia**|**ção daqua**|**lidade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Qualidade**||
|<br>**participantes**<br>**(estudos)**|<br>**de**<br>**viés**||<br>**indireta**||<br>**considerações**|<br>**geral da**<br>**evidência**|**Impacto**|
|**Mortalidade (se**|**guiment**|**o: variação 1 ano**|**s para 20 an**|**os)**||||
|142<br>(7 estudos<br>observacionais)<br>**Efeitos adverso**|grave<sup>a</sup><br>**s (segui**|não grave<br>**mento: média 7 a**|não grave<br>**nos)**|grave<sup>b</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Salvador 2015 – Quatro pacientes<br>transplantados tratados com benznidazol,<br>nenhuma morte, follow-up mediano de 52<br>meses<br>De Carvalho 1996 – Morte de três de 10<br>pacientes submetidos a transplante<br>cardíaco, tempo médio de follow-up 34<br>meses.<br>Campos 2008– 64 pacientes com<br>transplante cardíaco. 17 morreram durante<br>o período de follow-up (1 ano). 17<br>reativaram, recebendo benznidazol e houve<br>uma morte atribuída a reativação da<br>doença (8 mortes no total)<br>Diez 2012 – 8 pacientes reativados,<br>tratados com benznidazol, tratamento<br>efetivo em todos, não havendo morte.<br>Kansdorf 2013 – 11 pacientes com chagas<br>realizaram transplante cardíaco. Desses, 6<br>foram tratados com Benznidazol (4) ou<br>Nifurtimox (2), com uma morte (em uso de<br>benznidazol). Dos 5 não tratados, houve 1<br>morte. Follow-up: 14 meses<br>Riarte 1999 – De 23 pacientes com doença<br>de chagas transplantados renais, houve<br>reativação em 5 casos (4 casos entre 35 e<br>97 dias pós-transplante; 1 caso 2,4 anos<br>após transplante). Desses 4 receberam<br>tratamento com benznidazol, com uma<br>morte devido a complicações cirúrgicas<br>(não associada diretamente à doença) e<br>um caso não recebeu tratamento<br>antiparasitário, obtendo melhora<br>espontânea.<br>Atclas – De 22 pacientes que realizaram<br>transplante de medula óssea (12 autólogos<br>e 10 alogêncios), 6 (4 alogênicos e 2<br>autólogos) apresentaram reativação (sendo<br>apenas 1 com sintomatologia clínica e os<br>demais com diagnóstico parasitológico). Os<br>seis receberam tratamento com<br>benznidazol, sendo negativada a<br>parasitemia em todos os pacientes.|  
127  
|||**Av**|**aliação daqu **|**alidade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|38<br>(1 estudo<br>observacional)|grave<sup>a</sup>|não grave|grave<sup>d</sup>|grave<sup>c</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Dos 31 pacientes que receberam<br>benznidazol, 17 (54,8%) apresentaram<br>efeitos adversos: 35,5% prurido, 12,9%<br>erupção cutânea, 9,7% náusea, 9,7% dor<br>de cabeça, 6,5% dor abdominal, 6,5%<br>níveis elevados de transaminases, 3,2%<br>artralgia, 3,2% neutropenia, 3,2% reação<br>anafilática.|  
a. Estudo(s) não comparado(s)  
b. Grande variação no tempo de seguimento  
c. Não foi possível verificar a precisão dos resultados, visto que apenas um estudo forneceu dados; estudo com somente um evento cardíaco  
d. O estudo avaliou qualquer condição imunossupressora, onde somente 4/38 pacientes foram submetidos a transplante de órgãos.  
*Referências: Saldador 2015, De Carvalho 1996, Campos  2008, Diez 2012, Kansdorf 2013, Riarte 1999, Atclas 2005.  Maiores detalhes, vide questão no apêndice. **Questão 9.2 Devemos utilizar tratamento etiológico em pacientes transplantados e com doença de Chagas na fase crônica como profilaxia?**  
|**№ de**<br>**participantes**<br>**(estudos)**<br>**Mortalidade (se**<br>|**Risco**<br>**de**<br>**viés**<br>**guimento**<br>|**Avalia**<br>**Inconsistência**<br>**: média 34 mese**<br>|**ção daqual**<br>**Evidência**<br>**indireta**<br>**s)**<br>|**idade**<br>**Imprecisão**<br>|**Outras**<br>**considerações**<br>|**Qualidade**<br>**geral da**<br>**evidência**<br>|**Sumário de Resultados**<br>**Impacto**<br>|
|---|---|---|---|---|---|---|---|
|10<br>(1 estudo<br>observacional)<br>**Reativação soro**<br>|grave<sup>a</sup><br>**lógica (s**<br>|não grave<br>**eguimento: varia**<br>|não grave<br>**ção 1 anos p**<br>|grave<sup>b</sup><br>**ara 20 anos)**<br>|nenhum<br>|⨁◯◯◯<br>MUITO<br>BAIXA<br>|De Carvalho 1996: 10 pacientes realizaram<br>profilaxia no período perioperatório (8<br>antes, 10 depois) – 3 mortes, todos por<br>sepse, sem relação com doença de<br>chagas.<br>|
|14<br>(2 estudos<br>observacionais)|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Campos 2008. Pacientes submetidos a<br>transplante cardíaco. Quatro pacientes<br>receberam benznidazol como profilaxia<br>durante o período perioperatório. Todos<br>eles reativaram a doença, necessitando<br>retratamento. Tempo de follow-up 1 a 20<br>anos.<br>De Carvalho 1996: 10 pacientes realizaram<br>profilaxia no período perioperatório (8<br>antes, 10 depois) – todos mantiveram<br>sorologia positiva e houve 3 episódios de<br>reativação. Esses foram tratados com<br>benznidazol com sucesso. Tempo médio<br>de follow-up 34 meses|  
a. Estudo(s) não comparado(s)  
b. Estudo com N pequeno  
*Referências: De Carvalho 1996, Campos 2008. Maiores detalhes, vide questão no apêndice.  
128  
#### **QUESTÃO 10. DEVEMOS UTILIZAR ANTIPARASITÁRIOS (BENZNIDAZOL OU NIFURTIMOX) NO TRATAMENTO DE GESTANTES COM DOENÇA DE CHAGAS?**  
**<u>Questão 10.1 Devemos utilizar tratamento etiológico em gestantes com doença de Chagas na fase aguda?</u>**  
|||**Avalia**<br>|**ção daquali**<br>|**dade**<br>|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**<br>**Transmissão ve**<br>|**Risco**<br>**de**<br>**viés**<br>**rtical**<br>|**Inconsistência**<br>|**Evidência**<br>**indireta**<br>|**Imprecisão**|**Viés de**<br>**publicação**<br>|**Qualidade**<br>**geral da**<br>**evidência**<br>|**Impacto**<br>|
|5<br>(3 estudos<br>observacionais-<br>relato de caso)<br>**Complicações g**|muito<br>grave<br>a<br>**estacio**|não grave<br>**nais e malformaç**|não grave<br>b<br>**ões**|grave<sup>c</sup>|viés de<br>publicação<br>altamente<br>suspeito|⨁◯◯◯<br>MUITO<br>BAIXA<br>|A taxa de transmissão vertical da doença de<br>Chagas na fase aguda é entre 22 e 71%.<br>Em nenhum dos 5 casos houve transmissão<br>vertical da doença de Chagas:<br>Bisio 2013 relatou o caso de uma gestante<br>que, por desconhecer a gravidez, tomou o<br>medicamento por duas semanas.<br>Correa 2014 relatou o caso de uma paciente<br>com HIV e reativação da doença de Chagas<br>(meningoencefalite) que recebeu benznidazol<br>por 84 dias a partir do oitavo mês de gravidez.<br>Por meio de formulário eletrônico, obtivemos<br>relato de um médico que acompanhou três<br>gestantes que foram tratadas com benznidazol<br>a partir do oitavo mês de gravidez.<br>|
|6<br>(3 estudos<br>observacionais<br>– relato de<br>caso)|muito<br>grave<br>a|não grave|não grave<br>b|grave<sup>c</sup>|viés de<br>publicação<br>altamente<br>suspeito|⨁◯◯◯<br>MUITO<br>BAIXA|Correa 2014 relatou que a criança nasceu com<br>36 semanas de gestação e com baixo peso, foi<br>internada por 32 dias. A grande limitação deste<br>estudo é a co-infecção por HIV e o uso de<br>outros medicamentos.<br>Nos outros relatos, não houve casos de<br>problemas gestacionais ou alterações no<br>recém-nascido.|  
a. Séries de casos não comparados  
b. Uma paciente possui co-infecção por HIV  
c. N pequeno  
*Referências: Bisio 2013, Correa 2014 e relato de casos realizado pelo grupo elaborador. Maiores detalhes, vide questão no apêndice.  
129  
**Questão 10.2. Devemos utilizar tratamento etiológico no tratamento de gestantes com doença de Chagas na fase crônica?**  
|||**Avalia**|**ção daquali**|**dade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|**Qualidade**<br>**geral da**<br>**evidência**|**Impacto**|
|**Transmissão ve**|**rtical**|||||||
|1<br>(1 estudos<br>observacionais-<br>relato de caso)|muito<br>grave<br>a|não grave|não grave|grave<sup>b</sup>|viés de<br>publicação<br>altamente<br>suspeito|⨁◯◯◯<br>MUITO<br>BAIXA|A taxa de transmissão vertical da doença de<br>Chagas na fase crônica é aproximadamente<br>2% (1 a 10%) em mulheres não tratadas.<br>Por meio de formulário eletrônico, obtemos<br>relato de um médico que acompanhou<br>gestante com doença de Chagas em fase<br>crônica que recebeu benznidazol por 10 dias<br>durante o primeiro trimestre da gravidez. A<br>paciente desconhecia estar grávida.<br>Não houve transmissão vertical da doença de<br>Chagas.|
|**Complicações g**|**estacio**|**nais e malformaç**|**ões**|||||
|6<br>(3 estudos<br>observacionais<br>– relato de<br>caso)|muito<br>grave<br>a|não grave|não grave|grave<sup>b</sup>|viés de<br>publicação<br>altamente<br>suspeito|⨁◯◯◯<br>MUITO<br>BAIXA|Não houve complicações gestacionais ou<br>malformações e outros problemas no recém-<br>nascido.|  
a. Relato de caso, não comparado  
b. N pequeno  
*Referências: Bisio 2013, Correa 2014 e relato de casos realizado pelo grupo elaborador. Maiores detalhes, vide questão no apêndice.  
#### **QUESTÃO 11. DEVEMOS UTILIZAR NIFEDIPINA NO TRATAMENTO DE PACIENTES COM MEGAESÔFAGO CHAGÁSICO SINTOMÁTICO?**  
|||**Avaliaç**|**ão daquali**|**dade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|**Qualidade**<br>**geral da**<br>**evidência**|**Impacto**|
|**Pressão do esfí**|**ncter es**|**ofágico inferior**||||||
|15<br>(1 estudo<br>observacional)|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum<sup>c</sup>|⨁◯◯◯<br>MUITO<br>BAIXA|A LESP diminuiu significativamente em até<br>60% comparado a pressão de repouso após<br>35 min (com efeito máximo em 50 min).<br>Aproximadamente 1/4 dos pacientes não<br>apresentou alteração na LESP. Foi utilizado 10<br>mg de nifedipina.|
|**Esvaziamento e**|**sofágico**|||||||
|11<br>(1 estudo<br>observacional)|não<br>grave|não grave|não grave|grave<sup>b</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|O uso de nifedipina não alterou o<br>esvaziamento gástrico, quando comparado ao<br>grupo controle (não tratado). Foi utilizado 20<br>mg de nifedipina.|  
130  
<!-- Start of picture text -->
Avalia ç ão da  q ualidade  Sumário de Resultados<br>Efeitos adversos<br>26 grave a não grave não grave grave b nenhum ⨁◯◯◯ A frequência de efeitos adversos para dor de<br>(2 estudos  MUITO  cabeça foi de 10.48% (95%IC 3.04 - 30.41),<br>observacionais)  BAIXA   n=26. Nenhum paciente reportou casos de<br>palpitação após o uso de nifedipina.<br><!-- End of picture text -->  
a. Ausência de critérios de elegibilidade, não cegamento, não reportaram poder da amostra e perda de seguimento  
b. Pequeno N de pacientes; não apresenta intervalo de confiança de 95%  
c. Nenhuma explicação fornecida  
*Referências: Dantas 1986, Figueiredo 1992. Maiores informações, vide questão no apêndice.  
#### **QUESTÃO 12. DEVEMOS UTILIZAR ISOSSORBIDA NO TRATAMENTO DE PACIENTES COM MEGAESÔFAGO CHAGÁSICO SINTOMÁTICO?**  
|||**Avalia**|**ção daqual**|**idade**|||**Sumário de Resultados**|
|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>**(estudos)**<br>**Pressão do esfí**<br>|**Risco**<br>**de**<br>**viés**<br>**ncter es**<br>|**Inconsistência**<br>**ofágico inferior (L**<br>|**Evidência**<br>**indireta**<br>**ESP)**<br>|**Imprecisão**<br>|**Viés de**<br>**publicação**<br>|**Qualidade**<br>**geral da**<br>**evidência**<br>|**Impacto**<br>|
|50<br>(3 estudos<br>observacionais)<br>**Esvaziamento e**<br>|grave<sup>a</sup><br>**sofágico**|não grave<br>|não grave<br>|grave<sup>b</sup><br>|nenhum<br>|⨁◯◯◯<br>MUITO<br>BAIXA<br>|A isossorbida reduziu a LESP em 9,65<br>mmHg (IC95% 7.54- 11.76)<br>|
|47<br>(3 estudos<br>observacionais)|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|A isossorbida aumentou o esvaziamento<br>esofágico em 22,11% (IC95% 14,41-29,80)|
|<br>**Disfagia**||||||||
|23<br>(1 ECR)|não<br>grave|não grave|não grave|grave<sup>b</sup>|nenhum|⨁⨁⨁◯<br>MODERADA|Ferreira-Filho 1991: Em entrevistas, os<br>pacientes relataram melhora na frequência e<br>severidade da disfagia quando tratados com<br>isossorbida (comparação: placebo e pré-<br>tratamento).|
|**Efeitos adverso**|**s**|||||||
|80<br>(4 estudos<br>observacionais)|não<br>grave|não grave|não grave|grave<sup>b</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|A frequência de efeitos adversos para dor de<br>cabeça foi de 31.60% (95%IC 11.65 -<br>61.82), n=80. A frequência de efeitos<br>adversos para palpitação foi de 9.50%<br>(95%IC 0.54 - 66.90), n=39. A frequência de<br>efeitos adversos para tontura foi de 7.74%<br>(95%IC 2.52 - 21.41), n=39.|  
a. Ausência de critérios de elegibilidade, não cegamento, não reportaram poder da amostra e perda de seguimento  
b. Pequeno N da amostra  
131  
*Referências: Dantas 1987, Dantas 1988, De Oliveria 1994, Ferreira-Filho 1991, Figueiredo 1992, Matsuda 1995, Resende-Filho 1990. Maiores detalhes, vide questão no apêndice.  
#### **QUESTÃO 13. DEVEMOS UTILIZAR AMIODARONA NO TRATAMENTO DE PACIENTES COM CARDIOPATIA CHAGÁSICA?**  
|||**Avali**|**ação daqua**|**lidade**||||**Sumário**|**de Resu**|**ltados**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**participantes**<br>|**Risc**<br>**o de**<br>|**Inconsistênci**<br>**a**|**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**|**Qualidad**<br>**e geral**<br>|**Taxas de**<br>**estudo(**|**eventos do**<br>**%)**|**Efeito**<br>**relativ**|**Efeito**<br>**poten**|**s absolutos**<br>**ciais**|
|**(estudos)**|**viés**||||**s**|**da**<br>|||**o**<br>|||
|**Eventos cardio**<br>|**vascula**|**res**||||**evidência**|**Com**<br>**não**<br>**tratar**<br>|**Com**<br>**amiodaron**<br>**a**<br>|**(95%**<br>**IC)**<br>|**Risc**<br>**o**<br>**com**<br>**não**<br>**tratar**<br>|**Diferença**<br>**de risco**<br>**com**<br>**amiodaron**<br>**a**<br>|
|0<br>(0 estudos<br>observacionais<br>)<br>**Taquicardia ve**|-<br>**ntricular**|-<br>|-|-|-|-|Estudos<br>Potencial<br>de arritm|não avaliaram<br>benefício pod<br>ias.|eventos ca<br>e ser inferi|rdiovas<br>do devid|culares.<br>o à redução|
|38<br>(2 estudos<br>bii|não<br>grave|não grave|não<br>grave|não grave|associação<br>forte|⨁⨁◯◯<br>BAIXA|Amiodaro<br>taquicard<br>hlt|na reduziu em<br>ia ventricular (I|99,9% os<br>C 99,8% -|episódi<br>100% e|os de<br>m 24h|
|oservaconas|||||||oer).|||||
|)<br>**Batimentos ve**<br>|**ntricular**<br>|**es prematuros**<br>||||||||||
|52<br>(3 estudos<br>observacionais<br>)<br>**Couplets ventr**|não<br>grave<br>**iculares**|não grave|não<br>grave|não grave|associação<br>forte|⨁⨁◯◯<br>BAIXA|Amiodaro<br>prematur<br>Em um e<br>reduziu o<br>73,2%.|na reduziu 93,<br>os (IC 82% - 9<br>studo adicional<br>s batimentos v|1% de bat<br>7,4% em 2<br>com 14 p<br>entriculare|imentos<br>4h holte<br>acientes<br>s prema|ventriculares<br>r).<br>, amiodarona<br>turos em|
|76<br>(2 estudos<br>observacionais<br>)|não<br>grave|não grave|não<br>grave|não grave|associação<br>forte|⨁⨁◯◯<br>BAIXA|38/38<br>(100.0%<br>)|8/38<br>(21.1%)|**RR**<br>**0.21**<br>(0.39<br>para<br>|1.000<br>por<br>1.000|**790 menos**<br>**por 1.000**<br>(890 menos<br>para 610<br>|
|**Efeitos advers**|**os**||||||||0.11)||menos)|
|215<br>(6 estudos<br>observacionais<br>)|não<br>grave|não grave|não<br>grave|não grave|nenhum|⨁◯◯<br>◯<br>MUITO<br>BAIXA|A frequê<br>14.52% (<br>efeitos a<br>IC 4.58 –<br>adversos<br>87.80, n<br>cardiológ<br>134). O tr<br>pacientes|ncia de efeitos<br>95% IC 7.41 –<br>dversos gastroi<br>33.70, n = 55)<br>oftalmológicos<br>= 201). A frequ<br>icos foi de 12.7<br>atamento foi in<br>(95%IC 2.52|adversos<br>26.51, n =<br>ntestinais<br>. A frequê<br>foi de 53.<br>ência de e<br>7% (95%<br>terrompid<br>– 17.52, n|dermatol<br>58). A f<br>foi de 13<br>ncia de e<br>81% (95<br>feitos ad<br>IC 3.08<br>o em 6.9<br>= 99)|ógicos foi de<br>requência de<br>.51% (95%<br>feitos<br>% IC 15.87 -<br>versos<br>- 40.27, n =<br>0% dos|  
**IC:** intervalo de confiança; **RR:** risco relativo  
a. Ausência de critérios de elegibilidade  
b. Não cegamento  
c. Não reportaram poder da amostra e perda de seguimento  
d. Pequeno N  
132  
*Referências: Bellotti 1983, Carrasco 1958, Chiale 1984, Greco 1980, Haedo 1986, Rosenbaum 1987, Sacanavaca 1990. Maiores detalhes, vide questão no apêndice.  
#### **QUESTÃO 14. DEVEMOS REPETIR TESTE DIAGNÓSTICO PARA DOENÇA DE CHAGAS EM CRIANÇAS COM SUSPEITA DE TRANSMISSÃO VERTICAL CUJA TESTAGEM NEONATAL FOI NEGATIVA?**  
|**№ de**<br>**participantes**<br>**(estudos)**<br>**Follow-up**<br>**Diagnóstico acu**<br>|**Risco**<br>**de**<br>**viés**<br>**rado**<br>|**Avalia**<br>**Inconsistência**<br>|**ção daqua**<br>**Evidência**<br>**indireta**<br>|**lidade**<br>**Imprecisão**<br>|**Outras**<br>**considerações**<br>|**Qualidade**<br>**geral da**<br>**evidência**<br>|**Sumário de Resultados**<br>**Impacto**<br>|
|---|---|---|---|---|---|---|---|
|198<br>(4 estudos<br>observacionais)|grave<sup>a</sup>|grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Um estudo (Valdez 2016), com 115<br>crianças, mostrou que em 6 meses, 5,8%<br>(9/115) e 4,51% (7/115) estavam positivas<br>para ELISA-WB e IFI. Em 12 meses,<br>estavam positivos respectivamente<br>9.8%(15) e 8.38% (13).<br>Bern 2009 - De 10 crianças com diagnóstico<br>por PCR em até 90 dias, apneias 4<br>receberam diagnóstico por micrométodo no<br>período neonatal (1o mês).<br>Mallimacci, 2010 - 4/68 crianças com<br>Chagas congênito de acordo com teste com<br>SAPA. Todas crianças sem infecção<br>congênita e que tiveram SAPA reativo ao<br>nascer e em 30 dias, foram não-reativas aos<br>3 meses. Anticorpos maternos foram<br>detectados em crianças sem infecção<br>congênita nos 6 m com HIA e 8 m com EAI.<br>Todas foram não-reativas aos 9 meses.<br>Gamboa Leon 2011 - 5 neonatos com 2<br>testes sorológicos comerciais positivos ao<br>nascimento (cordão umbilical). Follow-up<br>em 10 meses, todos negativos (Stat-Pak<br>and ELISA Wiener)|  
a. Estudos com limitações metodológicas como cálculo de poder de amostra e perda de seguimento.  
b. Estudos com baixo número de participantes e uso de diferentes testes diagnóstico  
c. Amostra com pequeno número de eventos. Não foi possível verificar a precisão dos resultados, uma vez que estudos não fornecem variabilidade nos resultados  
* Referências: - Valdez 2016, Bern 2009, Mallimacci 2010, Gamboa Leon 2011. Maiores detalhes, vide questão no apêndice.  
133  
#### **QUESTÃO 15. DEVEMOS REALIZAR O RASTREAMENTO EM GESTANTES DO GRUPO DE RISCO PARA DOENÇA DE CHAGAS CRÔNICA?**  
|||**Avalia**|**ção daqua**|**lidade**||||**Sumári**|**o de Res**|**ultados**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**participant**|**Risc**<br>**o de**<br>|**Inconsistênc**<br>**ia**|**Evidênci**<br>**a**<br>|**Imprecisã**<br>**o**|**Viés de**<br>**publicaçã**|**Qualidad**<br>**e geral**<br>|**Taxas d**<br>**estudo(**|**e eventos do**<br>**%)**|**Efeito**<br>**relativ**|**Efeitos**<br>**potenci**|**absolutos**<br>**ais**|
|**es**|**viés**||**indireta**||**o**|**da**|||**o**|||
|**(estudos)**<br>**Follow-up**<br>**Casos Diag**|**nosticado**|**s**||||**evidênci**<br>**a**|**Com**<br>**não-**<br>**rastrea**<br>**r**|**Com**<br>**rastreament**<br>**o para**<br>**Chagas**|**(95%**<br>**IC)**|**Risco**<br>**com**<br>**não-**<br>**rastrea**<br>**r**|**Diferença**<br>**de risco**<br>**com**<br>**rastreament**<br>**o para**<br>**Chagas**|
|100.000<br>(coorte<br>simulada)<br>**Anos de Vid**<br>|grave<br>a<br>**a Salvos**|não grave|muito<br>grave<sup>b</sup><br>|não grave|nenhum<br>|⨁◯◯<br>◯<br>MUITO<br>BAIXA<br>|Realizad<br>puérpera<br>de trans<br>rastrear<br>de Chag<br>em detec<br>rastread<br>|o estudo de sim<br>s, dada probab<br>missão vertical<br>gestantes, diag<br>as nos casos n<br>ção de 29 caso<br>as.<br>|ulação.<br>ilidade pr<br>de 0,03%<br>nosticar n<br>eonatais i<br>s a cada<br>|Para popu<br>é-teste de<br>, a estraté<br>eonato e<br>dentificad<br>100.000<br>|lação de<br>1,1% e risco<br>gia de<br>tratar doença<br>os, resultou<br>mulheres<br>|
|100.000<br>(coorte<br>simulada)|grave<br>a|não grave|muito<br>grave<sup>b</sup>|não grave|nenhum|⨁◯◯<br>◯<br>MUITO|Tendo p<br>populaçã<br>de 0,1 a|or base redução<br>o com Chagas<br>no de vida em m|de 9 an<br>, a estraté<br>édia na|os de vida<br>gia result<br>população|em<br>ou em ganho<br>rastreada|
|**Casos de C**|**ardiopati**|**a Chagásica (In**|**suficiência**|**Cardíaca) ev**|**itados**|BAIXA|(75,5 co|m rastreio e 75,|4 sem ras|treio).||
|100.000<br>(coorte|grave<br>a|não grave|muito<br>grave<sup>b</sup>|não grave|nenhum|⨁◯◯<br>◯|Estratégi<br>tratar do|a de rastrear g<br>ença de Chaga|estantes,<br>s nos cas|diagnostic<br>os neonat|ar neonato e<br>ais|
|simulada)<br>**QALYs (Ano**|**s de Vid**|**a Ajustados pa**|**ra Qualidad**|**e de Vida) g**|**anhos**|MUITO<br>BAIXA|identifica<br>cardiopa<br>rastread|dos resultou e<br>tia chagásica a<br>as.|m prevenç<br>cada 100|ão de 5 c<br>.000 mulh|asos de<br>eres|
|100.000<br>(coorte<br>simulada)|grave<br>a|não grave|muito<br>grave<sup>b</sup>|não grave|nenhum|⨁◯◯<br>◯<br>MUITO<br>BAIXA|Consider<br>de saúde<br>um perío<br>rastream<br>neonatos<br>casos ra|ando-se que te<br>que pode ser<br>do de doença d<br>ento (rastrear g<br>) resulta em u<br>streados e trata|r doença<br>represent<br>e 20 ano<br>estantes,<br>m ganho d<br>dos adeq|de Chaga<br>ado por 1<br>s, a estrat<br>diagnosti<br>e 12 QAL<br>uadamen|s é um estado<br>0 QALYs para<br>égia de<br>car e tratar<br>Ys para os<br>te.|  
a. Modelo simulado com incerteza em parâmetros  
b. Estudo de simulação (coorte hipotética de rastreamento)  
134  
#### **QUESTÃO 16. DEVE-SE USAR TESTES DE RASTREAMENTO PARA DIAGNOSTICAR**  
#### **DOENÇA DE CHAGAS EM ADULTOS COM <50 ANOS, EM GRUPO DE RISCO E EM ÁREAS DE MAIOR PREVALÊNCIA?**  
|**Desfecho**|**Sensibilidad**<br>**Delineamen**<br>**to do**<br>**estudo**|**e: 0.96 (**<br>**Fator**<br>|**95% IC: 0.9**<br>**es que pod**<br>|**5 para 0.97)**<br>**em reduzir a q**|<br>**ualidade da**|**Espe**<br>**evidência**<br>|**cificidade: 0.98**<br>**Efeito de 1**<br>|**(95% IC: 0.97**<br>**00,000 pacient**<br>|**para 0.99)**<br>**es testados**<br>|**Qualidad**<br>**e das**<br>**evidênci**<br>**as de**|
|---|---|---|---|---|---|---|---|---|---|---|
|||**Risc**<br>**o de**<br>**viés**|**Evidênc**<br>**ia**<br>**indireta**|**Inconsistên**<br>**cia**|**Imprecis**<br>**ão**|**Viés de**<br>**publicaç**<br>**ão**|**Probabilida**<br>**de pré-teste**<br>**de 0.5%**|**Probabilida**<br>**de pré-teste**<br>**de 1%**|**Probabilida**<br>**de pré-teste**<br>**de 5%**|**acurácia**<br>**do teste**|
|**Verdadeiros**<br>**-positivos**<br>(pacientes<br>com Doença<br>de Chagas)|Estudo de<br>acurácia do<br>tipo caso-<br>controle|grave<br>a|muito<br>grave<sup>b</sup>|não grave|não grave|nenhum|480 (475<br>para 485)|960 (950<br>para 970)|4800 (4750<br>para 4850)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|
|**Falsos-**<br>**negativos**<br>(pacientes<br>incorretame<br>nte<br>classificados<br>como não<br>tendo<br>Doença de<br>Chagas)|||||||20 (15 para<br>25)|40 (30 para<br>50)|200 (150<br>para 250)||
|**Verdadeiros**<br>**-negativos**<br>(pacientes<br>sem Doença<br>de Chagas)|Estudo de<br>acurácia do<br>tipo caso-<br>controle|grave<br>a|muito<br>grave<sup>b</sup>|não grave|não grave|nenhum|98505<br>(96515 para<br>99500)|98010<br>(96030 para<br>99000)|94050<br>(92150 para<br>95000)|⨁◯◯<br>◯<br>MUITO<br>BAIXA|
|**Falsos-**<br>**positivos**<br>(Pacientes<br>com Doença<br>de Chagas<br>incorretame<br>nte<br>classificados<br>)|||||||995 (0 para<br>2985)|990 (0 para<br>2970)|950 (0 para<br>2850)||  
a. Estudos de caso controle; risco de viés de espectro (amostras selecionadas)  
b. Estudos não avaliam as propriedades diagnósticas para confirmação de testes discordantes.  
135

---

