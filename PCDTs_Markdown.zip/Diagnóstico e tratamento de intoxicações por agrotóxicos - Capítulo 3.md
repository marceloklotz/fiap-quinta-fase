<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Geral -->
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
##### **PORTARIA Nº 5, DE 18 DE FEVEREIRO DE 2019**  
Torna pública a decisão de aprovar as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - Capítulo 3, no âmbito do Sistema Único de Saúde - SUS.  
A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS - SUBSTITUTA, DO MINISTÉRIO DA SAÚDE, no uso de suas atribuições legais e com base nos termos dos art. 20 e art. 23 do Decreto 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Ficam aprovadas as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - Capítulo 3, no âmbito do Sistema Único de Saúde - SUS.  
Art. 2º Conforme determina o art. 25 do Decreto 7.646/2011, o prazo máximo para efetivar a oferta ao SUS é de cento e oitenta dias.  
Art. 3º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico: http://conitec.gov.br/.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
VANIA CRISTINA CANUTO SANTOS  
1  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
Anexo

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Geral -->
#### **Considerações Iniciais**  
O glifosato (n-fosfonometilglicina) é um herbicida sistêmico, não-seletivo e de amplo espectro, utilizado em culturas alimentares e não-alimentares diversas. O Ministério da Agricultura, Pecuária e Abastecimento (MAPA) indica o uso desses produtos na agropecuária e silvicultura na pós-emergência das plantas infestantes em culturas diversas. Além disso, destaca-se a sua aplicação como maturador de cana-de-açúcar e como dessecante nas culturas de aveia preta, azevém e soja. Quando aplicado em menor quantidade, atua como um regulador de crescimento vegetal , sendo utilizado em margens de rodovias e ferrovias, áreas sob a rede de transmissão elétrica, pátios industriais, oleodutos e aceiros; e emprego na jardinagem amadora<sup>1</sup> .  
O aumento da sua utilização em diferentes culturas é um fenômeno mundial. Em 2013, os países asiáticos, principalmente Índia e China, emergiram como os maiores consumidores de produtos à base de glifosato. No mesmo período, os Estados Unidos foram responsáveis por mais de 25% do volume comercializado desses produtos. Estima-se que em 2020 a demanda global de glifosato exceda uma tonelada<sup>2</sup> .  
Segundo o MAPA, em 2014, os produtos à base de glifosato ocuparam a primeira posição em termos de volume de comercialização (488 toneladas).  Além do composto em sua forma ácida, cinco dos seus sais são disponibilizados no mercado brasileiro em uma das 112 formulações registradas. Destas, 69 são à base de e 43 à base dos seus sais monovalentes: isopropilamônio (19), amônio (12),  
potássio (6) dimetilamônio (5) e diamônio (1). (http://agrofit.agricultura.gov.br/agrofit_cons/principal_agrofit_cons).  
2

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE -->
Apesar de os íons de amônio não contribuírem para o aumento da toxicidade do composto primário, os seus respectivos sais contribuem ativamente para a toxicidade de uma formulação caso seja ingerida<sup>3</sup> .  
Com isso, tal qual outras formulações de agrotóxicos, os efeitos tóxicos observados podem ser decorrentes da presença de outros ingredientes, tais como surfactantes e adjuvantes, não sendo, portanto, exclusivamente relacionados  à substância ativa<sup>3–7</sup> .  
Cabe destacar que a lista completa dos outros ingredientes utilizados nas formulações à base de glifosato não é disponibilizada publicamente, não constando nas bulas dos produtos todos os ingredientes presentes na formulação. Somente são detalhados os que merecem atenção diferenciada, dado os potenciais efeitos tóxicos a eles associados. Destarte, o conhecimento sobre os perigos reais de diferentes misturas permanecem limitados<sup>8,9</sup> .  
No Brasil, entre 2007 a 2016, foram notificados 6.408 casos de intoxicação relacionadas ao glifosato, em sua forma isolada ou combinada no Sistema de Informação de Agravos de Notificação (Sinan), havendo um aumento progressivo dessas intoxicações durante esse período. Os dados apontam uma maior frequência de intoxicações em indivíduos jovens e adultos, do sexo masculino<sup>10</sup> .  
Após a absorção, o glifosato é distribuído no organismo, sendo encontrado principalmente nos intestinos, ossos, cólon e nos rins. Aparentemente, a sua biotransformação em animais é mínima. Portanto, quase 100% da quantidade encontrada nos tecidos corresponde ao produto original. Em torno de 1% do produto se converte em ácido aminometilfosfônico (AMPA). A maior proporção é eliminada nas fezes, e o glifosato absorvido é rapidamente eliminado sem alterações na urina<sup>2</sup> .  
**_Abordagem Inicial_**  
**O fluxograma de atendimento e de procedimentos utilizados na abordagem inicial para o atendimento nos casos onde há suspeita de intoxicação por agrotóxicos encontra-se apresentados nos anexos 2A**  
O diagnóstico de intoxicações agudas por herbicidas à base de glifosato é essencialmente clínico, sendo fundamental uma anamnese completa e, sempre que possível, a identificação de sinais e sintomas preditivos de agravamento<sup>11,12</sup> .  
3  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
##### **Anamnese**  
**Ponto de Boa Prática Durante a avaliação inicial do paciente, colete o maior número de informações no menor tempo possível**<sup>13</sup> **.**  
**São Informações essenciais na anamnese para a intoxicação por glifosato, conhecer (** ERICKSON; THOMPSON; LU, 2007) **:**  
**_Quem? O que foi utilizado e quanto?_ Qual a via de exposição?** **_Onde? Como?_ Há quanto tempo?**  
Colete informações junto aos acompanhantes ou familiares das vítimas de intoxicações por formulações à base de glifosato, especialmente quando são crianças ou pacientes com alteração da consciência<sup>14</sup> .  
##### **Ponto de Boa Prática**  
Ligue para o Centro de Informação e Assistência Toxicológica (CIATox) de sua região para orientações sobre suspeita de intoxicações com manifestações clínicas atípicas ou com quadros iniciais de difícil identificação.  
No site: <u>http://portal.anvisa.gov.br/disqueintoxicacao estão disponíveis os números de contato dos</u> diferentes centros de informação e assistência toxicológica da Rede Nacional de Centros de Informação e Assistência Toxicológica (Renaciat). O número gratuito do serviço Disqueintoxicação é **0800 722 6001.**  
No site <u>http://abracit.org.br/wp/centros/ estão disponíveis os contatos dos centros de intoxicação da</u> Associação Brasileira de Centros de Informação e Assistência Toxicológica (ABRACIT).  
Consulte também a Ficha de Segurança Química (FISQP), o rótulo, os componentes da formulação e a bula do produto para mais informações<sup>13</sup> .  
4  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
**Sinais e sintomas das intoxicações agudas por herbicidas à base de glifosato**  
##### **Ponto de Boa Prática**  
Considere a possibilidade de alguns pacientes expostos ao glifosato, no momento do atendimento, se apresentarem assintomáticos ou com sintomas leves e auto resolutivos, não sendo necessária nenhuma intervenção<sup>15</sup> .  
A toxicidade dos produtos comerciais formulados à base de glifosato se manifestam por meio de alterações fisiopatológicas diversas. Os sinais e sintomas clínicos observados nos quadros de intoxicação com esses produtos dependem dos componentes presentes nas formulações<sup>2</sup>  
##### **Ponto de Boa Prática**  
Nos casos suspeitos de intoxicação por produtos comerciais formulados à base de glifosato, não há como distinguir sinais e sintomas relacionados ao ingrediente ativo dos que resultam da toxicidade dos componentes da formulação<sup>16</sup> .  
##### **Ponto de Boa Prática**  
Na avaliação inicial de pacientes com suspeita de exposição aguda a produtos à base de glifosato, os seguintes sinais e sintomas podem ser observados, independente da formulação do produto:  
##### **Exposição Oral**  
<u>Trato Gastrointestinal: dor de garganta; lesões e ulcerações na mucosa oral  com possibilidade de</u> perfuração de esôfago (a depender da quantidade ingerida e do surfactante presente na formulação); eritema de mucosa, disfagia,  epigastralgia náuseas, vômitos, diarreia e dor abdominal, com possibilidade de evolução para um quadro de desidratação, hemorragia digestiva e íleo paralítico<sup>12,17–26</sup> ;  
<u>Sistema Cardiovascular: hipotensão transitória, disritmias, bradicardia ou taquicardia, com risco</u> de choque nos casos mais graves;  
<u>Sistema Respiratório: taquipneia, estertores difusos, pneumonite aspirativa e edema pulmonar</u>  
5

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
15,20,25,27,28;  
<u>Sistema Excretor: oligúria</u><sup>17</sup> ou Anúria<sup>21</sup> ;  
##### **Exposição Dérmica**  
- Edema periorbital, flictenas e vesículas<sup>18</sup> ;  
- Alterações sensoriais<sup>29</sup> ;  
- Eritema e irritação cutânea<sup>30</sup>  
##### **Exposição Inalatória**  
A exposição a névoas de produtos comerciais formulados à base de glifosato pode causar desconforto oral ou nasal, um gosto desagradável na boca, formigamento e irritação na garganta. Sintomas mais <u>graves podem ser observados a depender dos componentes da formulação</u><sup>20,31,32</sup> .  
Herbicidas à base de glifosato consistem de uma mistura aquosa de glifosato, surfactantes e outros adjuvantes, os quais não são, no momento, compulsoriamente descritos nas bulas disponibilizadas dos produtos comerciais<sup>8,31</sup> . Alguns dos  surfactantes utilizados são corrosivos e podem provocar lesões celulares, o que pode contribuir para as complicações cutâneas observadas nas exposições dérmicas  a esses produtos<sup>18,22,33,34</sup> .  
Assim, é consenso que os mecanismos complexos de toxicidade dessas formulações dificultam o estabelecimento de estratégias diagnósticas específicas para as intoxicações humanas com esses produtos<sup>8,16,35</sup> .  
##### **Ponto de Boa Prática**  
Nos casos de exposição oral, a natureza do surfactante, o percentual de ativo na formulação e o volume de líquido ingerido contribui diretamente com a gravidade dos sinais e sintomas observados 3,26,36–38.  
6

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE -->
##### **Avaliação da gravidade**  
##### **Ponto de Boa Prática**  
O tempo de contato com o produto influencia na gravidade dos sintomas locais observados nos casos de exposição dérmica a formulações à base de glifosato<sup>18,29</sup> .  
A presença de determinados surfactantes e adjuvantes, bem como o volume de ingestão do produto influenciam na gravidade do quadro observado nas intoxicações com produtos à base de glifosato<sup>8,12,33</sup> .  
##### **Ponto de Boa Prática**  
Nos casos mais graves de intoxicações com produtos à base de glifosato, existe a possibilidade de serem observados (as):  
- alteração do nível de consciência, convulsões, edema pulmonar<sup>15,20,36</sup> ;  
- necrose epidérmica tóxica<sup>39</sup> ;  
- meningite asséptica<sup>40</sup> ;  
- vasculite neuropática<sup>29</sup> ;  
- encefalopatia<sup>41</sup> ;  
- rabdomiólise<sup>21</sup> ;  
- ruptura de intestino grosso<sup>38</sup> .  
Formulações contendo _polioxietileno-amina_ ou _taloaminapolietoxilada_ (POEA), bem como as que contém como ingrediente ativo os sais de potássio são associadas a quadros mais graves de intoxicação<sup>3,18,32,40</sup> .  
##### **Ponto de Boa Prática**  
Considere que nas intoxicações mais graves com produtos à base de glifosato existe a possibilidade de óbito em decorrência da falência renal e, principalmente, de complicações cardiopulmonares<sup>11,15,20,36,37,42</sup> ;  
7

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
A escala de gravidade das intoxicações agudas (PSS - _Poisoning Severity Score_ ), a qual é validada pelo Programa Internacional de Segurança Química (IPCS) – ANEXO 2B, pode ser útil para avaliar a gravidade das intoxicações por glifosato.  
##### **Recomendação**  
Considere como fatores preditivos de complicações nas vítimas de intoxicação por formulações à base de glifosato:  
- idade> 50 anos,  
- quantidade ingerida igual ou superior a 200mL de produto,  
- frequência cardíaca> 100 batimentos por minuto, na admissão  
Recomendação forte a favor da intervenção  
##### **Evidências** :  
Estudo retrospectivo, com análise dos prontuários de 131 pacientes diagnosticados com intoxicação oral por produtos à base de glifosato revelou que a chance de falência respiratória e óbito aumentam consideravelmente **quando o volume ingerido é superior a 200ml (OR= 53,5; IC 95% 13,6-210,9)** 43  
Estudo conduzido por Lee e colaboradores identificou como fatores preditivos de mortalidade em pacientes intoxicados por formulações à base de glifosato: **a idade> 40 anos, a quantidade ingerida** , o desenvolvimento de choque hipotensivo e a **taquicardia (frequência cardíaca> 100 / min)**<sup>42</sup> .  
Moon e Chun sugerem, como fatores preditivos de mortalidade em vítimas de intoxicação por produtos à base de glifosato: **a idade superior a 50 anos (OR =0,27; p=0,027; IC 95% 0,08–0,86)** , a elevação dos níveis de transaminase glutâmico-pirúvica (OR= 0,094; p=0,012; IC 95% 0,015– 0,595) e a presença de infiltrados pulmonares, observada por meio de alterações radiográficas de tórax, (OR=0,278; p= 0,049; IC 95% 0,078–0,994). O quadro de hipotensão observado em alguns pacientes não era decorrente de hipovolemia, mas sim de mecanismos toxicodinâmicos de alguns componentes da formulação. 78% dos pacientes que desenvolveram acidose metabólica apresentaram um elevado ânion gap<sup>12</sup> .  
A quantidade de surfactante ingerido (mL) foi correlacionada positivamente com os dias de permanência na UTI (r=0,274, p<0,004), duração da intubação (r=0,300, p<0,002) e contagem de  
8  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
leucócitos (r=0,373, p<0,001) e correlação negativa com pH inicial (r=-0,365, p<0,001) e HCO3<sup>-</sup> (r = -0,380, p<0,001). **O volume de surfactante foi mais relevante para complicações clínicas do que para o volume de glifosato** :  
|**Desfecho**|**RR**|**IC**|**pvalue**|
|---|---|---|---|
|Hipotensão|1,047 vs. 1,017|1,017-1,077|0,002/0,003|
|Insuficiência|1,033 vs. 1,010|1,006-1,060|0,016/0,040|
|Respiratória||||
|Lesão Renal Aguda|1,042 vs. 1,013|1,012-1074|0,006/0,029|
|Deterioração Mental|1,032 vs. 1,012|1,006-1,059|0,015/0,024|  
**Não houve diferença de sintomas entre os grupos de diferentes fórmulas dos surfactantes e sim, pelo volume ingerido**<sup>32</sup> **.**  
A insuficiência renal aguda é uma complicação comum observada em pacientes intoxicados por for formulações à base de glifosato, **principalmente em indivíduos acima de 40 anos** . Os valores de creatinina sérica, muitas vezes dentro da normalidade na admissão, devem ser monitorados<sup>44</sup> .  
A comparação dos níveis de lactato sérico entre 203 sobreviventes (3,3± 2,2 mmol / L; p <0,001) e 29 não sobreviventes (6,5±3,1 mmol /L), vítimas de intoxicação por formulações à base de lactato, indicou por meio de uma análise multivariada que uma concentração superior a 4,7 mmol/ L do íon foi associada ao aumento da mortalidade (razão de risco 3,2; IC95% 1,1–8,7). Além do lactato, **idade> 59 anos** , intervalo QT corrigido> 495 ms e K<sup>+</sup> > 5,5 mmol / L foram considerados como fatores de risco independentes para mortalidade em 30 dias (KIM, YH et al., 2016).  
Nível de evidência para (Anexo III.5) **:** Idade > 50 anos (MODERADA); Volume > 125mL (MODERADA); FC> 100 bpm (MODERADA).  
##### **Provas laboratoriais auxiliares**  
Dada a diversidade de componentes utilizados nos produtos formulados com glifosato, não é possível padronizar exames diagnósticos a serem realizados em caso de intoxicação aguda por produtos comercializados à base desse composto. Entretanto, alguns exames laboratoriais podem auxiliar seguimento de pacientes intoxicados por esses agentes.  
9  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
##### **Ponto de Boa Prática**  
O diagnóstico das intoxicações por glifosato é fundamentalmente clínico. Entretanto, alguns exames auxiliam no acompanhamento dos casos. De acordo com a evolução do paciente, há necessidade de se estabelecer uma monitorização da sua evolução cardíaca, respiratória, renal, eletrolítica e do equilíbrio ácido-base no intuito de tratar precocemente quaisquer alterações desses sistemas.  
Alguns exames laboratoriais podem auxiliar na elaboração de estratégias terapêuticas reduzem o risco de complicações cardíacas, renais e respiratórias , o que contribui para uma redução na mortalidade de pacientes vítimas de intoxicação grave com formulações à base de glifosato<sup>12</sup> .Quadros de hipercalemia são normalmente associados à ingestão de produtos contendo sais de potássio<sup>16</sup> .  
##### **Recomendação**  
Na admissão e para o acompanhamento da evolução de pacientes com suspeita de exposição aguda a produtos à base de glifosato, além dos exames laboratoriais de rotina estabelecidos na unidade para os casos de intoxicações exógenas, solicite a dosagem sérica de:  
- Lactato  
- Potássio sérico (K<sup>+</sup> )  
- Creatinina  
Recomendação forte a favor da intervenção  
Solicite gasometria arterial para todo paciente admitido e classificado como grave, vítima de intoxicação com formulações à base de glifosato. Considere a possibilidade do rápido estabelecimento da acidose metabólica.  
Recomendação forte a favor da intervenção.  
##### **Evidências**  
A comparação dos **níveis de lactato sérico** entre 203 sobreviventes (3,3± 2,2 mmol / L; p <0,001) e 29 não sobreviventes (6,5±3,1 mmol /L), vítimas de intoxicação por formulações à base de glifosato, indicou por meio de uma análise multivariada que uma **concentração superior a 4,7 mmol/ L** do íon foi associada ao aumento da mortalidade (razão de risco 3,2; IC95% 1,1–8,7). Além do lactato, idade> 59 anos, intervalo QT corrigido> 495 ms e **K**<sup>**+**</sup> **> 5,5 mmol / L** foram considerados como fatores de  
10

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE -->
risco independentes para mortalidade em 30 dias (KIM, YH et al., 2016).  
A **hipercalemia** é observada nos casos de ingestão de formulações à base de potássio<sup>3,12</sup> , sendo também um preditor independente de mortalidade, quando apresenta valores acima de 4,5mmol/L 43,45.  
Estudo realizado com 58 vítimas de intoxicação por glifosato, dos quais 17 evoluíram ao óbito. Depois de análise univariada, a dificuldade respiratória (expressa pela necessidade de intubação), a acidose metabólica, a taquicardia,  níveis elevados de creatinina (Cr) e **hipercalemia** se mostraram altamente relacionadas a desfechos indesejados e à mortalidade<sup>42</sup>  
A insuficiência renal aguda é uma complicação comum observada em pacientes intoxicados por formulações à base de glifosato, principalmente em indivíduos acima de 40 anos. Os valores de **creatinina sérica** , muitas vezes dentro da normalidade na admissão, devem ser monitorados<sup>44</sup> .  
A complicação mais frequente observada em 76 vítimas de intoxicação por  herbicidas à base de glifosato foi a **acidose metabólica** (36,8%)<sup>12</sup> , sendo essa uma complicação também observada por outros estudos<sup>20,23,42,45</sup> .  
Nível de evidência (Anexo III.5): Dosagem de Lactato (MODERADA); Determinação de K sérico (BAIXA/MORTALIDADE E MUITO BAIXA/TEMPO DE INTERNAÇÃO); Dosagem de creatinina (ALTA); Gasometria arterial (MODERADA).  
Há estudos que indicam, aumento de parâmetros indicativos de inflamação e de danos musculares associados à intoxicações agudas com produtos à base de glifosato<sup>18,21</sup> .  
##### **Ponto de Boa Prática**  
Considerando a variedade de formulações disponíveis no mercado, não é possível estabelecer uma correlação entre a concentração sérica de glifosato com as manifestações clínicas observadas nos casos suspeitos de exposição aguda a produtos à base desse composto<sup>8,16,32,46,47</sup> .  
11  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
##### **Outros exames a serem considerados**  
**Recomendação**  
Na admissão de pacientes com suspeita de exposição aguda a produtos comerciais formulados à base de glifosato, solicite eletrocardiograma (ECG) e Raio X de tórax, principalmente os com suspeita de intoxicação moderada ou grave.  
Recomendação condicional a favor da intervenção  
**Evidências** :  
Em pacientes intoxicados com produtos formulados à base de glifosato contendo sal de potássio (Roundup Maxload® e Touchdown IQ®) foi observado ECG anormal, com **prolongamento dos intervalos  QRS e QT** , com pico da onda T, taquicardia ventricular e condução elétrica anormal<sup>37</sup> .  
Anormalidades do ECG observadas entre 76 pacientes vítimas de intoxicação aguda por glifosato **: prolongamento do intervalo QTc** (51.7%), taquicardia sinusal (13.8%), bloqueio AV de primeiro grau (10.3%), anormalidade ST-T (10.3%), bradicardia sinusal (5.2%) e taquicardia com alargamento QRS (1.7%). O maior prolongamento QTc foi observado entre os indivíduos agrupados como “complicados”, na admissão (complicado 470,8 ± 48,9 ms vs. não complicado 438,0 ± 37,3 ms, p = 0,010).<sup>12</sup> .  
Os achados anormais mais comuns no ECG observados em 153 vítimas de exposição aguda ao glifosato foram **prolongamento do intervalo QTc** , tendo sido também observado o atraso da condução intraventricular e bloqueio atrioventricular. Pacientes que foram a óbito apresentaram maior prolongamento do intervalo  QTc quando comparado aos sobreviventes (sobreviventes: 453,4 ± 33,6 vs não sobreviventes: 542 ± 32,0, p≤ 0,001)<sup>48</sup> .  
Alterações anormais em Raio X de Tórax observadas em pacientes com histórico de exposição aguda ao glifosato, admitidos em um serviço de emergência, **principalmente taquicardia sinusal e alterações inespecíficas de ST-T** . Dos 105 pacientes que tiveram **radiografia de tórax** realizada, em 22 foram observados **infiltrados ou manchas anormais** . Três dos 131 desenvolveram insuficiência renal e necessitaram de hemodiálise; indo todos a óbito<sup>43</sup> .  
12  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
Dentre 76 vítimas de intoxicação intencional com formulações à base de glifosato, em 17 (22.4%) foram observadas **anormalidades radiográficas** , sendo que **7 pacientes apresentaram infiltrados pulmonares e 10 foram diagnosticados com edema agudo de pulmão**<sup>12</sup> .  
As **complicações pulmonares** são associadas à mortalidade de pacientes vítimas de exposição aguda a formulações contendo glifosato<sup>21,25,42</sup>  
A **lesão pulmonar aguda** é observada em pacientes intoxicados por formulações contendo POEA<sup>37</sup> . Nível de evidência (Anexo III.5):  ECG (MUITO BAIXA) e Raio X de Tórax (MUITO BAIXA)  
##### **Ponto de Boa Prática**  
Considere que a ingestão de produtos formulados à base de glifosato contendo sais de potássio podem resultar em hipercalemia grave, o que pode levar a arritmias fatais ou parada cardíaca, e podem requerer terapia de substituição renal, como a hemodiálise<sup>3</sup>  
##### **Tratamento das Intoxicações por produtos comerciais formulados à base de glifosato**  
##### **Ponto de Boa Prática**  
Até o momento, não há antídotos que possam ser utilizados nos casos de intoxicação por glifosato e suas formulações. Considere o suporte vital adequado como sendo medida efetiva e essencial para o estabelecimento de um prognóstico favorável<sup>49</sup> .  
##### **Descontaminação de pele e mucosas**  
A exposição dérmica a formulações de glifosato pode causar irritação, dermatites de contato e queimaduras, a depender do tempo de contato. Estes efeitos locais são provavelmente relacionados aos ingredientes da formulação. Casos raros de complicações sistêmicas decorrentes de uma exposição dérmica ao glifosato são descritos na literatura<sup>18</sup> .  
13

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
##### **Ponto de Boa Prática**  
No atendimento inicial aos casos de exposição dérmica ao glifosato, remover cuidadosamente a roupa da vítima e lavar a região exposta com quantidade abundante de água e sabão.  Lave cuidadosamente atrás das orelhas, sob as unhas e nas dobras cutâneas. Use sabão e xampu para substâncias oleosas<sup>13</sup> . A lavagem  com água e sabão é mais eficiente para a remoção do produto do que a simples lavagem com água<sup>50,51</sup> .  
##### **Ponto de Boa Prática**  
Nas exposições oculares a formulações contendo glifosato, antes de iniciar a irrigação, assegure que houve a remoção das lentes de contato, quando for o caso.  
Irrigue o (s) olho (s) exposto (s) com quantidade abundante de água limpa ou soro fisiológico, durante pelo menos 15 minutos. Caso persista a irritação, referenciar o paciente para um serviço especializado<sup>13</sup> .  
Considere que determinados componentes presentes nas formulações à base de glifosato podem induzir o estabelecimento de uma conjuntivite leve ou uma lesão superficial da córnea, principalmente se a irrigação ocular for atrasada ou realizada inadequadamente<sup>49</sup> .  
##### **Descontaminação Gástrica**  
##### **Lavagem gástrica**  
Não foram encontrados estudos comparativos que permitissem uma análise da eficácia da utilização da lavagem gástrica nos casos de intoxicação aguda por produtos comerciais formulados à base de glifosato. Não foram encontradas evidências suficientes para se estabelecer a sua recomendação no atendimento a vítimas de intoxicação aguda por herbicidas à base de glifosato<sup>12,17,32,49,52</sup> .  
##### **Ponto de Boa Prática**  
14  
Não se recomenda o uso rotineiro da lavagem gástrica para intoxicação por agrotóxicos.  
Entretanto, considere a sua realização em casos de ingestão de doses potencialmente letais, em pacientes atendidos em até 60 min da exposição, com histórico de ingestão de grandes quantidades de agrotóxicos que não tenham sido diluídos em solventes orgânicos ou corrosivos.  
Deve-se avaliar se os benefícios da prática superam os danos, devendo ser priorizado o tratamento por meio de cuidados de suporte vital.  
##### **Uso de carvão ativado**  
Não foram encontrados estudos comparativos que permitissem uma análise da eficácia da utilização do carvão ativado nos casos de intoxicação aguda por produtos à base de glifosato. Não há evidências suficientes para se estabelecer a sua recomendação no atendimento a vítimas de intoxicação aguda por herbicidas à base de glifosato.  
##### **Ponto de Boa Prática**  
Não se recomenda o uso rotineiro de doses múltiplas de carvão ativado para intoxicação por agrotóxicos.  
Entretanto, considere a administração de uma única dose de carvão ativado em pacientes atendidos em até 60 min da exposição, com histórico de ingestão de grandes quantidades de agrotóxicos e que sejam adsorvidos por esse composto.  
##### **Técnicas de Eliminação Extracorpórea**  
Nas intoxicações graves com produtos comerciais à base de glifosato, a possível exposição a ingredientes mais tóxicos do que o ativo, bem como a ingestão de grande volume de herbicida favorecem o desenvolvimento de complicações clínicas e provável óbito. Esses são observados, principalmente, nos indivíduos que, na admissão, apresentam uma elevada concentração plasmática de glifosato<sup>15,32,33</sup> .  
Com isso, técnicas de eliminação se mostram bastante válidas para a remoção de alguns desses ingredientes, incluindo o próprio glifosato. Contudo, é preciso considerar que a maioria dos estudos disponíveis se restringem a alguns relatos de casos.  
##### **Ponto de Boa Prática**  
15

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE -->
As complicações hemodinâmicas e a mortalidade são reduzidas quando pacientes com histórico de ingestão de grande volume de herbicidas à base de glifosato (V≥100mL) são submetidos à Hemoperfusão Direta ou à Hemodiafiltração Venovenosa Contínua (CVVHDF)<sup>21,25,28</sup> .  
##### **Recomendação**  
Nos casos graves de intoxicação com produtos à base de glifosato, considere a utilização de métodos dialíticos no intuito de favorecer a remoção de todos os ingredientes presentes na formulação.  
Recomendação condicional a favor da intervenção  
##### **Evidências**  
O uso precoce de hemodiálise em um paciente gravemente intoxicado por herbicida à base de glifosato foi associado a um bom resultado clínico. A **hemodiálise foi realizada 16 horas** após a ingestão do produto, como tratamento para hipercalemia refratária e acidose persistente. Foi observada uma redução na concentração sérica de glifosato após o término do procedimento: Cinicial=240 mcg/mL e Cfinal= 92,6 mcg/mL<sup>36</sup> .  
Paciente em estado grave após ingestão intencional de um a formulação constituída por 41% de isopropilamina de glifosato e 15% de POEA recebeu, inicialmente, **oxigenação por membrana extracorpórea venoarterial** (VA-ECMO), iniciada 3 horas após a admissão, devido à hipotensão profunda refratária, mesmo após a administração de agente duplo inotrópico. A **hemodiálise venosa contínua** (CVVH) também foi aplicada simultaneamente com ECMO, sendo observada uma redução considerável na concentração plasmática de glifosato: C4,5h=970 ppm e C134h= 3,54 mcg/mL.<sup>28</sup> .  
Realizada **hemodiafiltração venovenosa contínua** (CVVHDF) em indivíduo de 66 anos, com comprometimento hemodinâmico devido a ingestão de 350 mL de Roundup, juntamente com 500 mL de bebida alcoólica. Na admissão apresentava um quadro de hipóxia, hipotensão (87/45 mmHg) e acidose láctica pronunciada. Recebeu terapia de suporte. Contudo, entrou em estado de choque (pressão arterial 66/43 mmHg, leucócitos e agudização da acidose láctica) juntamente com aparecimento de falência múltipla de órgãos. A CVVHDF foi iniciada 12 horas após a sua admissão  
16  
na unidade e interrompida após 60h, sendo observada visível melhora do quadro clínico do paciente após a 24ª hora<sup>53</sup> . Nível de Evidência (Anexo III.5): MUITO BAIXA  
##### **Terapia Específica**  
Não há antídotos específicos que possam ser utilizados nos casos de intoxicação por produtos comerciais formulados à base de glifosato<sup>9,17,54</sup> .  
##### **Ponto de Boa Prática**  
Os produtos comerciais formulados a base de glifosato não reagem ou inibem a atividade das colinesterases e não interferem na transmissão nervosa. Portanto, é contraindicado, nesses casos, o uso de atropina e pralidoxima.  
##### **Terapia Adjuvante**  
Após exposição acidental a uma formulação à base de glifosato, a dor provocada pelas úlceras e o edema na língua, lábios e mucosa oral foi amenizada após a limpeza com soro fisiológico e aplicação de pomada de benzocaína (20%), em ambiente hospitalar<sup>22</sup> .  
A administração parenteral de emulsão lipídica pode auxiliar na correção da hipotensão refratária observada nos casos graves de intoxicação por produtos à base de glifosato.  Os mecanismos pelos quais a emulsão lipídica reduz os efeitos tóxicos dos surfactantes não foram totalmente esclarecidos<sup>55,56</sup> .  
##### **Recomendação**  
17  
Considere a administração parenteral de emulsão lipídica* em pacientes com histórico intoxicação grave por produtos comerciais formulados à base de glifosato, que apresentem hipotensão refratária, mesmo após medidas de suporte, na seguinte posologia:  
- 1,5mL/Kg, em 3 horas (20 mL/h), aos pacientes com histórico de ingestão de um volume inferior a 100 mL;  
- Infundir 500mL, nas 3h iniciais, com uma dose de manutenção de 1.000mL nas 24h subsequentes  
Recomendação condicional a favor da intervenção  
##### **Evidências**  
Um estudo clínico aberto de grupos paralelos, no qual 64 pacientes com histórico de ingestão intencional de glifosato, que o uso da emulsão lipídica reduziu a incidência de **hipotensão** (0% vs. 40,9%, p <0,001) e de **arritmia** (0% vs. 22,7%, p <0,048), reduzindo o risco de complicações clínicas e **o período de hospitalização**<sup>55</sup> .  
Administração em bolus, 1,5 mL/kg de SMOFlipid a 20% (Fresenius Kabi, Bad Homburg, Alemanha), seguida de infusão contínua (0,25 mL/kg), por 20 min, após resposta inadequada à norepinefrina (128 μg/min) por 2 horas, em paciente de 65 anos, com comprometimento hemodinâmico (PA 90/30 mm Hg; 77 bpm; 35°C) decorrente da ingestão intencional de 150mL de uma formulação à base de glifosato. A infusão lipídica auxiliou na estabilização hemodinâmica do paciente, o qual, após ser submetido hemodiálise contínua por sete dias, recebeu alta<sup>56</sup> .  
Paciente de 52 anos de idade, após ingestão intencional de 300 mL de uma formulação contendo 41% de isopropilamina de glifosato e 15% de polioxietileno taloamina, deu entrada em serviço de emergência bradicárdico (44bpm) e eupneico (15 mrpm). Permaneceu hemodinamicamente instável (PAS 80 mmHg), mesmo após a infusão, por cerca de 2,5h, de dopamina e atropina, além de outras terapias de suporte, incluindo ventilação mecânica e reposição volêmica. Decidiu-se pela administração de 100 mL, em _bolus_ , de uma emulsão lipídica a 20%. Em seguida, 400mL da mesma solução foram infundidos a uma velocidade de 1,5mL/min. Indícios de normalização da pressão arterial foram observados após uma hora da injeção _em bolus_ (100/60 mmHg). Transcorridas cinco horas do início da terapia, as drogas vasoativas foram reduzidas, considerando a **normalização da pressão arterial** (60/100 mmHg)<sup>52</sup> .  
18  
Nível de Evidência (Anexo III.5): MUITO BAIXA (tempo de internação) e MODERADA (mortalidade)  
(*) Nos estudos avaliados as emulsões lipídicas utilizadas eram constituídas de óleo de soja (triglicerídeos de cadeia longa), fosfolipídios de gema de ovo, triglicerídeos de cadeia média e azeite. Uma formulação diferente de emulsão lipídica pode ter um efeito diferente na formação do compartimento lipídico no qual as substâncias lipofílicas são, teoricamente, divididas. Mais estudos são necessários para determinar que tipo de formulação é a melhor opção (Gil et al., 2013). No Brasil, é possível identificar na ANVISA o registro de preparações à base de óleo de soja (triglicerídeos de cadeia de longa), triglicerídeos de cadeia média, glicerol e lecitina de ovo. No Brasil, a nutrição parenteral é regulamentada pelas Portaria n°272/1998 e Portaria 120/2009, ambas do Ministério da Saúde.  
##### **Acompanhamento de pacientes expostos a produtos comerciais formulados à base de glifosato**  
A variedade de componentes utilizados nas formulações à base de glifosato aumenta não somente o risco de penetração dérmica do produto, mas favorecem o desenvolvimento de efeitos adversos tardios 8,9,16,35.  
##### **Ponto de Boa Prática**  
Estabeleça o retorno para o acompanhamento de pacientes que, no atendimento de emergência, apresentam histórico de exposição dérmica e contato prolongado com formulações concentradas de glifosato, dada a possibilidade de desenvolvimento de danos musculares e neurológicos.  
##### **Acompanhamento de pacientes vítimas de tentativas de suicídio**  
##### **Ponto de Boa Prática**  
Se identificada a circunstância de intoxicação por tentativa de suicídio, deve-se encaminhar o paciente à Rede de Atenção Psicossocial (RAPS).  
Para conhecer mais sobre a RAPS acesse o endereço eletrônico do Portal da Saúde: http://portalsaude.saude.gov.br/index.php/o-ministerio/principal/secretarias/sas/daet/saude-mental  
19  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
##### **Ações de Vigilância em Saúde**  
##### **Ponto de Boa Prática**  
Uma vez finalizada a atenção inicial e estabilizado o paciente, deve-se realizar a respectiva notificação do caso, utilizando o formato de notificação de intoxicações apropriado.  
Notifique todos os casos suspeitos de intoxicação no Sistema de Informação de Agravos de Notificação (Sinan). Ela é obrigatória a todos os profissionais de saúde (anexo D e E), e é um fator determinante para medidas de vigilância.  
Existe também a possibilidade da comunicação pelos cidadãos ou estabelecimentos educacionais por meio do Disque Notifica: 0800-644-6645 ou notifica@saude.gov.br.  
**(Verificar o Capítulo 1 das presentes diretrizes para maiores detalhes em relação à obrigatoriedade da notificação compulsória dos casos de suspeita de intoxicação exógena)**  
##### **Ponto de Boa Prática**  
Em caso de ser uma intoxicação por agrotóxicos relacionada ao trabalho, de acordo com a Lei 8.213/1991; Portaria GM/MS de Consolidação nº 2 de 2017, anexo XV (origem: PRT MS 1.823/2012); Portaria GM/MS de Consolidação nº 5 de 2017, art. 422 e Anexo LXXIX (origem: PRT MS 3.120/1998)<sup>57</sup> ; Lei 6.015/1973; Portaria GM/MS de Consolidação nº 4 de 2017, anexo V (Origem: PRT MS/GM 204/2016)<sup>58</sup> ; o médico ou profissional de saúde deve:  
- Emitir a Comunicação de Acidente de Trabalho (CAT) para os trabalhadores que contribuem com o INSS e os segurados especiais (a exemplo de agricultores e pescadores);  
- Referenciar o trabalhador, para a atenção básica, caso o primeiro atendimento seja realizado em serviços de média ou alta complexidade com o objetivo de dar continuidade ao cuidado;  
- Acionar os Centros de Referência em Saúde do Trabalhador (Cerest) ou equipe de vigilância em saúde para realizar vigilância de ambiente e processo de trabalho referente ao caso, com o objetivo de intervir, minimizando ou eliminando a exposição de trabalhadores aos agrotóxicos;  
20

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
- Notificar o caso na ficha de investigação de **Intoxicação Exógena do Sinan** e sempre preencher os campos: 32-Ocupação, 36-Atividade Econômica (CNAE), 34-Local de ocorrência da exposição como “ambiente de trabalho”, 56-A exposição/contaminação foi decorrente do trabalho/ ocupação? Como “Sim”;  
- Em caso de **óbito** , incluindo suicídio, por intoxicação por agrotóxicos relacionada ao trabalho, preencher um dos campos de causa do óbito da Declaração de Óbito (DO) com o CID-10, Y96Circunstâncias relativas às condições de trabalho. E ainda assinalar o campo acidente de trabalho como “sim” na parte de causas externas da DO.  
( **Verificar o anexo D, do Capítulo 1, o qual apresenta o fluxograma para o atendimento de trabalhadores com suspeita de intoxicação por agrotóxicos** )

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Referências bibliográficas -->
1. Brasil. Ministerio da Agricultura Pecuaria e Abastecimento. AGROFIT.  
- http://agrofit.agricultura.gov.br/primeira_pagina/extranet/AGROFIT.html. Accessed November 1, 2018.  
2. Research GV. Glyphosate Market Size To Reach USD 8.50 Billion By 2020. 2018:4.  
3. Kamijo Y, Mekari M, Yoshimura K, Kan&apos;o T, Soma K. Glyphosate-surfactant herbicide products containing glyphosate potassium salt can cause fatal hyperkalemia if ingested in massive amounts. _Clin Toxicol_ . 2012;50(2):159. doi:10.3109/15563650.2011.648747  
4. (EPA) USE and PA. _EPA-738-F93-011_ .; 1993.  
5. Bach NC, Natale GS, Somoza GM, Ronco AE. Effect on the growth and development and induction of abnormalities by a glyphosate commercial formulation and its active ingredient during two developmental stages of the South-American Creole frog, Leptodactylus latrans. _Environ Sci Pollut Res_ . 2016;23(23):23959-23971. doi:10.1007/s11356-016-7631-z  
6. Piola L, Fuchs J, Oneto ML, Basack S, Kesten E, Casabé N. Comparative toxicity of two glyphosate-based formulations to _Eisenia andrei_ under laboratory conditions. _Chemosphere_ . 2013;91(4):545-551. doi:10.1016/j.chemosphere.2012.12.036  
7. Clinical MOH, Guidelines P. _Management of Poisoning_ .; 2011.  
8. Mesnage R, Antoniou MN. Ignoring Adjuvant Toxicity Falsifies the Safety Profile of  
21

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
Commercial Pesticides. _Front Public Heal_ . 2018;5(January):1-8. doi:10.3389/fpubh.2017.00361  
9. Mesnage R, Antoniou MN. Facts and Fallacies in the Debate on Glyphosate Toxicity. _Front Public Heal_ . 2017;5(November):1-7. doi:10.3389/fpubh.2017.00316  
10. Saúde M da SS de V em. _Boletim Epidemiológico - Hepatites Virais_ . Vol 49. Brasília, DF; 2018. http://www.aids.gov.br/sites/default/files/anexos/publicacao/2016/59121/boletim_hepatites_05_0 8_2016_pdf_96185.pdf.  
11. Kim YH, Lee JH, Cho KW, et al. Prognostic Factors in Emergency Department Patients with Glyphosate Surfactant Intoxication: Point-of-Care Lactate Testing. _Basic Clin Pharmacol Toxicol_ . 2016;119(6):604-610. doi:10.1111/bcpt.12624  
12. Moon JM, Chun BJ. Predicting acute complicated glyphosate intoxication in the emergency department. _Clin Toxicol_ . 2010;48(7):718-724. doi:10.3109/15563650.2010.488640  
13. Roberts JR, Reigart JR. _Recognition and Management of Nonrelaxing_ .; 2013. doi:10.1016/j.mayocp.2011.09.004  
14. Erickson TB, Thompson TM, Lu JJ. The Approach to the Patient with an Unknown Overdose. _Emerg Med Clin North Am_ . 2007;25(2):249-281. doi:10.1016/j.emc.2007.02.004  
15. Roberts DM, Buckley NA, Mohamed F, et al. A prospective observational study of the clinical toxicology of glyphosate-containing herbicides in adults with acute self-poisoning. _Clin Toxicol_ . 2010;48(2):129-136. doi:10.3109/15563650903476491  
16. Mesnage R, Defarge N, Spiroux de Vendômois J, Séralini GE. Potential toxic effects of glyphosate and its commercial formulations below regulatory limits. _Food Chem Toxicol_ . 2015;84:133-153. doi:10.1016/j.fct.2015.08.012  
17. Roberts DM, Buckley NA, Mohamed F, Eddleston M, Daniel A. A prospective observational study of the clinical toxicology of glyphosate-containing herbicides in adults with acute selfpoisoning. _Clin Toxicol_ . 2010;48(2):129-136. doi:10.3109/15563650903476491.A  
18. Mariager TP, Madsen P V., Ebbehoj NE, Schmidt B, Juhl A. Severe adverse effects related to dermal exposure to a glyphosate- surfactant herbicide. _Clin Toxicol_ . 2013;51(2):111-113. doi:10.3109/15563650.2013.763951  
19. Zouaoui K, Dulaurent S, Gaulier JM, Moesch C, Lachâtre G. Determination of glyphosate and AMPA in blood and urine from humans: About 13 cases of acute intoxication. _Forensic Sci Int_ . 2013;226(1-3):20-25. doi:10.1016/j.forsciint.2012.12.010  
22  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
20. Khot R, Joshi P, Pandharipande M, Nagpure K, Thakur D. Glyphosate poisoning with acute pulmonary edema. _Toxicol Int_ . 2014;21(3):328. doi:10.4103/0971-6580.155389  
21. Nincevic Z, Nincevic J, Sundov Z, Puljiz Z. Severe glyphosate - surfactant herbicide poisoning ; successful treatment - case report. 2017;4(1):202-204. doi:10.15406/mojamt.2017.04.00066  
22. Deo S, Shelty P. Accidental Chemical Burns of Oral Mucosa by Herbicide. _J Nepal Med Assoc_ . 2012;52(185):40-42.  
23. HSIN-LING LEE, MD, KUAN-WEN CHEN, MD, CHIH-HSIEN CHI, MD, JENG-JONG HUANG, MD, LIANG-MIIN TSAI, MDFigure S. Clinical Presentations and Prognostic Factors of a Glyphosate–Surfactant Herbicide Intoxication: A Review of 131 cases. _Acad Emerg Med_ . 2000;7(8):906-910. doi:10.15713/ins.mmj.3  
24. Lee JW, Choi YJ, Park S, Gil HW, Song HY, Hong SY. Serum S100 protein could predict altered consciousness in glyphosate or glufosinate poisoning patients. _Clin Toxicol_ . 2017;55(5):357-359. doi:10.1080/15563650.2017.1286013  
25. Ozaki T, Sofue T, Kuroda Y. Severe Glyphosate-Surfactant Intoxication Successfully Treated With Continuous Hemodiafiltration and Direct Hemoperfusion: Case Report. _Ther Apher Dial_ . 2017;21(3):296-297. doi:10.1111/1744-9987.12565  
26. Jyoti W, Thabah M, Rajagopalan S, Hamide A. Esophageal perforation and death following glyphosate poisoning. _J Postgrad Med_ . 2014;60(3):346. doi:10.4103/0022-3859.138834  
27. Chang C-B, Chang C-C. Refractory cardiopulmonary failure after glyphosate surfactant intoxication: a case report. _J Occup Med Toxicol_ . 2009;4(1):2. doi:10.1186/1745-6673-4-2  
28. Chan C-W, Wu I-L, Lee C-H, Hsu S-C, Liao S-C. Successful Extracorporeal Life Support in a Case of Severe Glyphosate-Surfactant Intoxication. _Crit Care Med_ . 2016;44(1):e45-e47. doi:10.1097/CCM.0000000000001352  
29. Kawagashira Y, Koike H, Kawabata K, et al. Vasculitic Neuropathy Following Exposure to a Glyphosate-based Herbicide. _Intern Med_ . 2017;56(11):1431-1434. doi:10.2169/internalmedicine.56.8064  
30. Colômbia M de la PS. Guías para el manejo de Urgencias Toxicológicas. 2008:348.  
31. Myers JP, Antoniou MN, Blumberg B, et al. Concerns over use of glyphosate-based herbicides and risks associated with exposures: A consensus statement. _Environ Heal A Glob Access Sci Source_ . 2016;15(1):1-13. doi:10.1186/s12940-016-0117-0  
23  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
32. Seok SJ, Park JS, Hong JR, et al. Surfactant volume is an essential element in human toxicity in acute glyphosate herbicide intoxication. _Clin Toxicol_ . 2011;49(10):892-899. doi:10.3109/15563650.2011.626422  
33. Song HY, Kim YH, Seok SJ, et al. Cellular toxicity of surfactants used as herbicide additives. _J Korean Med Sci_ . 2012;27(1):3-9. doi:10.3346/jkms.2012.27.1.3  
34. Elie-Caille C, Heu C, Guyon C, Nicod L. Morphological damages of a glyphosate-treated human keratinocyte cell line revealed by a micro-to nanoscale microscopic investigation. _Cell Biol Toxicol_ . 2010;26(4):331-339. doi:10.1007/s10565-009-9146-6  
35. Myers JP, Antoniou MN, Blumberg B, et al. Concerns over use of glyphosate-based herbicides and risks associated with exposures: A consensus statement. _Environ Heal A Glob Access Sci Source_ . 2016;15(1):1-13. doi:10.1186/s12940-016-0117-0  
36. Garlich FM, Goldman M, Pepe J, et al. Hemodialysis clearance of glyphosate following a lifethreatening ingestion of glyphosate-surfactant herbicide. _Clin Toxicol_ . 2014;52(1):66-71. doi:10.3109/15563650.2013.870344  
37. Kamijo Y, Takai M, Sakamoto T. A multicenter retrospective survey of poisoning after ingestion of herbicides containing glyphosate potassium salt or other glyphosate salts in Japan. _Clin Toxicol_ . 2016;54(2):147-151. doi:10.3109/15563650.2015.1121271  
38. Palli E, Makris D, Diakaki C, Garoufalis G, Zakynthinos E. Rapture of the large intestine caused by severe oral glyphosate-surfactant intoxication. _Am J Emerg Med_ . 2011;29(4):459-460. doi:10.1016/j.ajem.2010.12.002  
39. Indirakshi J, Sunnesh A, Aruna M, et al. Toxic epidermal necrolysis and acute kidney injury due to glyphosate ingestion. _Indian J Crit Care Med_ . 2017;21(3):167. doi:10.4103/ijccm.IJCCM_423_16  
40. Sato C, Kamijo Y, Yoshimura K, Ide T. Aseptic meningitis in association with glyphosatesurfactant herbicide poisoning. _Clin Toxicol_ . 2011;49(2):118-120. doi:10.3109/15563650.2011.552065  
41. Malhotra RC, Ghia DK, Cordato DJ, Beran RG. Glyphosate-surfactant herbicide-induced reversible encephalopathy. _J Clin Neurosci_ . 2010;17(11):1472-1473. doi:10.1016/j.jocn.2010.02.026  
42. Lee CH, Shih CP, Hsu KH, Hung DZ, Lin CC. The early prognostic factors of glyphosate-  
24  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
surfactant intoxication. _Am J Emerg Med_ . 2008;26(3):275-281. doi:10.1016/j.ajem.2007.05.011  
43. Lee HL, Chen KW, Chi CH, Huang JJ, Tsai LM. Clinical presentations and prognostic factors of a glyphosate-surfactant herbicide intoxication: A review of 131 cases. _Acad Emerg Med_ . 2000;7(8):906-910. doi:10.1111/j.1553-2712.2000.tb02069.x  
44. Mohamed F, Endre ZH, Pickering JW, et al. Mechanism-specific injury biomarkers predict nephrotoxicity early following glyphosate surfactant herbicide (GPSH) poisoning. _Toxicol Lett_ . 2016;258:1-10. doi:10.1016/j.toxlet.2016.06.001  
45. Kim YH, Lee JH, Cho KW, et al. Prognostic factors in emergency department patients with glyphosate-surfactant intoxication: point-of-care lactate testing . _Basic Clin Pharmacol Toxicol_ . 2016;119(6):604-610. doi:10.1111/bcpt.12624  
46. Lake R. _Health Risk Assessment: Glyphosate_ .; 2014. doi:10.1002/0471752010.ch25  
47. Han J, Moon H, Hong Y, et al. Determination of glyphosate and its metabolite in emergency room in Korea. _Forensic Sci Int_ . 2016;265:41-46. doi:10.1016/j.forsciint.2015.12.049  
48. Kim YH, Lee JH, Hong CK, et al. Heart rate-corrected QT interval predicts mortality in glyphosate- surfactant herbicide-poisoned patients. _Am J Emerg Med_ . 2014;32(3):203-207. doi:10.1016/j.ajem.2013.09.025  
49. Rao SM, Mutkule D, Venkategowda P, Mahendrakar K. Glyphosate surfactant herbicide poisoning and management. _Indian J Crit Care Med_ . 2014;18(5):328. doi:10.4103/09725229.132508  
50. Rumble J. CRC Handbook of Chemistry and Physics. _CRC Press_ . 2017. doi:10.1016/B978-0-12408129-1.09982-4  
51. Wester RC, Melendres J, Sarason R, McMaster J, Maibach HI. Glyphosate Skin Binding, Absorption, Residual Tissue Distribution and Skin Decontamination. _Fundam Appl Toxicol_ . 1991;16:725-732.  
52. Han SK, Jeong J, Yeom S, Ryu J, Park S. Use of a lipid emulsion in a patient with refractory hypotension caused by glyphosate-surfactant herbicide. _Clin Toxicol_ . 2010;48(6):566-568. doi:10.3109/15563650.2010.496730  
53. Hour BT, Belen C, Zar T, Lien YHH. Herbicide roundup intoxication: Successful treatment with continuous renal replacement therapy. _Am J Med_ . 2012;125(8):e1-e2. doi:10.1016/j.amjmed.2011.11.022  
25  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
54. Kwiatkowska M, Jarosiewicz P, Michałowicz J, Koter-Michalak M, Huras B, Bukowska B. The impact of glyphosate, its metabolites and impurities on viability, ATP level and morphological changes in human peripheral blood mononuclear cells. _PLoS One_ . 2016;11(6):1-13. doi:10.1371/journal.pone.0156946  
55. Gil H-W, Park J-S, Park S-H, Hong S-Y. Effect of intravenous lipid emulsion in patients with acute glyphosate intoxication. _Clin Toxicol_ . 2013;51(8):767-771. doi:10.3109/15563650.2013.821129  
56. You Y, Jung WJ, Lee MJ. Effect of intravenous fat emulsion therapy on glyphosate-surfactantinduced cardiovascular collapse. _Am J Emerg Med_ . 2012;30(9):2097.e1-2. doi:10.1016/j.ajem.2011.06.042  
57. Brasil. Ministério da Saúde. _Portaria de Consolidação N_<sup>_o_</sup> _5/2017_ . Brasília; 2017.  
58. Brasil. Ministério da Saúde. _Portaria de Consolidação N_<sup>_o_</sup> _4/2017_ . Brasília; 2017:288p.  
59. Brasil. Ministério da Saúde. _Protocolos de Suporte Avançado de Vida_ . 2<sup>a</sup> . (Urgência. P de I para o S 192-S de AM de, ed.). Brasilia: Secretaria de Atenção à Saúde; 2016.  
60. Ministério da Saúde; Secretaria de Atenção Básica; Departamento de Atenção Básica. _Procedimentos 30 30_ .; 2011.  
26  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
ANEXOS  
27  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
28  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
**Anexo 2A: Fluxograma para o atendimento nos casos de suspeita de intoxicação por agrotóxicos.**  
29  
<!-- Start of picture text -->
ry<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
<!-- Start of picture text -->
_—— Suspeitadeintoxicag3opor SS<br>—_ agrotoxicos __<br>Sintomatolo Sim Exposi¢3o0 a<br>gia aguda aguda | ]<br>Nao [Use equipamentosde<br>| proteg3o individual |<br>AvaliacSoclinicae / (EPI) /<br>examescomplementares Avaliaco | ; |<br>eatendimentoou clinica inical Senecessario |<br>encaminhamentode / / — unidadedemaiorencaminharpare | /<br>acordo com protocolos complexidade |<br>de cadaunidade [ /<br>Manter12horas. sob observaco [  por 6 2 Estavel |<br>de descontaminacSo*Considerar medidas Suporte avancado vital bésico<br>N50 Antidoto, de acordo coma clinica do paciente<br>Estavel . Descontaminagéo mucocuténea egastrica*, Eliminac300u<br>do agentee e caracteristicas<br>da exposicSo.<br>Solicita¢do de examescomplementares,senecessario.<br>sim<br>Altaprevencoe acompanhamento ambulatorialpara | Continuidade do atendimento de acordo com evolucao:<br>sequelas. de novas intoxicacdes,tratamentode | | Se alta, acompanhamentoambulatorialpara prevencao<br>Se tentativa de suicidio,encaminharparaRAPs. | ||| deSe tentativa novas intoxicacdes, de suicidio, tratamentodeencaminharparasequelas RAPS.<br>| Priorize o suporte vital basico  proteja<br>| Ligue para o CIATox 0800 722 6001viaaéreapara emesclarecer pacientes comas indicagdes alteragdesdosdeconsciéncia.métodos de | |<br>|| descontaminacaoeeliminaco paracadasubsténcia. ||<br>| *Em pacientes atendidos em até 60 minutos apés a exposicéo, avaliando se os beneficios<br>teéricos superam os possiveis danos, garantindo a protegéo da via aérea. |<br>| 1. Considere lavagem gastrica quando houver ingest de grande quantidade de agrotéxicos<br>| altamente toxicos que no sejam diluidos em solventes organicos € corrosivos.<br>2. Considere utilizar uma dose Unica de carv8o ativedo quando houver ingestéo de grande |<br>| quantidade de agrotéxicos altamente téxicosque s80 adsorvidospelo carvao ativado. |<br>| Notifique todos os casos, suspeitos ou confirmados, na ficha de intoxicacSoexogenadoSinan; |<br>| Notifique na ficha de Violéncia, se suspeita de maltrato, tentativa de suicidioouhomicidio; |<br>| Preencha a Comunicacéo de Acidente de Trabalho, se exposic¢So ocupacional; |<br>Declara¢&o de dbito quando aplicavel. |<br>Ce<br><!-- End of picture text -->  
30

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
||**_Nenhum_**|**_Leve_**|**_Moderada_**|**_Grave_**|**_Fatal_**|
|---|---|---|---|---|---|
||**_0_**|**_1_**|**_2_**|**_3_**|**_4_**|
|**_Órgão/Sistema_**|**_Nenhum_**<br>**_sinal ou_**<br>**_sintoma_**|**_Sinais ou Sintomas leves,_**<br>**_autoresolutivos ou_**<br>**_transitórios_**|**_Sinais ou sintomas_**<br>**_pronunciados ou prolongados_**|**_Sinais e sintomas que_**<br>**_ameaçam a vida do paciente_**|**_Morte_**|
|_Gastrintestinal_||_Vômito, diarreia, dor_<br>_Irritação, queimaduras de_<br>_1º grau_<br>_Pequenas ulcerações na_<br>_boca_<br>**_Endoscopia_**_: eritema, edema_|_Vômito pronunciado ou_<br>_prolongado, diarreia, dor_<br>_Queimaduras de 1º grau de_<br>_localização crítica ou_<br>_Queimaduras de 2º e 3º_<br>_graus em  áreas retritas_<br>_Disfagia_<br>**_Endoscopia_**_: lesões_<br>_transmucosa ulcerativa_|_Hemorragia maciça,_<br>_perfuração_<br>_Queimaduras de 2º e 3º_<br>_graus mais disseminadas_<br>_Disfagia severa_<br>**_Endoscopia_**_: lesões_<br>_transmurais ulcerativas,_<br>_lesões circunferenciais,_<br>_perfurações._||
|_Respiratório_||_Irritação, tosse, falta de_<br>_ar, dispneia leve,_<br>_broncoespasmo leve_<br>**_Radiografia de tórax_**_:_<br>_anormalidades menores_<br>_ou sem sintomas._|_Tosse prolongada,_<br>_broncoespasmo, dispneia,_<br>_estridor, hipoxemia que_<br>_requer oxigenoterapia_<br>**_Radiografia de tórax_**_:_<br>_anormal com sintomas_<br>_moderados._|_Insuficiência respiratória_<br>_manifesta (devido a, por_<br>_exemplo, broncoespasmo_<br>_grave, obstrução de via_<br>_aérea, edema glótico,_<br>_SDRA, pneumonite,_<br>_pneumonia, pneumotórax)_<br>**_Radiografia de tórax_**_:_<br>_anormal com sintomas_<br>_severos_||
|_Nervoso_||_Sonolência, vertigem,_<br>_zumbido, ataxia,_<br>_inquietação_<br>_Sintomas extrapiramidais_<br>_leves_<br>_Sintomas colinérgicos /_<br>_anticolinérgicos leves_<br>_Parestesia_<br>_Distúrbios visuais ou_<br>_auditivos leves_|_Inconsciência com resposta_<br>_à dor_<br>_Apneia breve, bradipneia_<br>_Confusão, agitação,_<br>_alucinações, delírio_<br>_Convulsões infrequentes,_<br>_generalizadas ou locais_<br>_Sintomas extrapiramidais_<br>_pronunciados_<br>_Sintomas colinérgicos /_<br>_anticolinérgicos_<br>_pronunciados_<br>_Paralisia localizada que não_<br>_afeta a vitalidade funcional_<br>_Distúrbios visuais e auditivos_|_Coma profundo com_<br>_resposta inadequada a dor_<br>_ou não responder à dor_<br>_Depressão respiratória com_<br>_insuficiência, extrema_<br>_agitação_<br>_Convulsões freqüentes e_<br>_generalizadas, status_<br>_epilepticus, opistótono_<br>_Paralisia generalizada ou_<br>_paralisia afetando funções_<br>_vitais_<br>_Cegueira, surdez_||
|_Cardiovascular_||_Extrassístoles isoladas_<br>_Hipoglicemia/ hipertensão_<br>_leves e transitórias_|_Bradicardia sinusal (HR ~_<br>_40-50 em adultos, 60-80 em_<br>_bebês e crianças, 80-90_<br>_neonatos)_<br>_Taquicardia sinusal (HR ~_<br>_140-180 em adultos, 160-_<br>_190 em bebês e crianças,_<br>_160-200 em neonatos)_<br>_Extrassístoles frequentes,_<br>_fibrilação atrial/ flutter,_<br>_bloqueio AV I-II,prolongado_|_Bradicardia sinusal severa_<br>_(HR ~ <40 em adultos, <60_<br>_em lactentes e crianças,_<br>_<80 em neonatos)_<br>_Taquicardia sinusal severa_<br>_(HR ~> 180 em adultos, >_<br>_190 em bebês e crianças, >_<br>_200 em neonatos)_<br>_Disritmias ventriculares com_<br>_risco de vida, Bloqueio AV_<br>_III, assistolia_||  
31

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|||_QRS e QTc-time, anomalias_<br>_de repolarização_<br>_Isquemia miocárdica_<br>_Hipo / hipertensão mais_<br>_pronunciada_|_Infarto do miocárdio_<br>_Choque, crise hipertensiva_|
|---|---|---|---|
|_Metabolismo_|_Pequenas alterações_<br>_ácido-base (HCO3 ~ 15-_<br>_20 ou 30-40 mmol / l;pH ~_<br>_7,25-7,32 ou 7,50-7,59)_<br>_Alterações eletrolíticas_<br>_discretas (K_<sup>_+_</sup>_3.0-3.4 ou_<br>_5.2-5.9 mmol / l)_<br>_Hipoglicemia discreta (~_<br>_50-70 mg / dl ou 2,8-3,9_<br>_mmol / l em adultos)_<br>_Hipertermia de curta_<br>_duração_|_Alterações ácido-base mais_<br>_pronunciadas (HCO3 ~ 10-_<br>_14 ou> 40 mmol / l; pH ~_<br>_7,15-7,24 ou 7,60-7,69)_<br>_Alterações eletrolíticas_<br>_Eletrólito mais pronunciadas_<br>_(K_<sup>_+_</sup>_2.5-2.9 ou 6.0-6.9 mmol_<br>_/ l)_<br>_Hipoglicemia mais_<br>_pronunciada (~ 30-50 mg /_<br>_dl ou 1,7-2,8 mmol / l em_<br>_adultos)_<br>_Hipertermia de longa duração_|_Graves perturbações ácido-_<br>_base (HCO3 ~ <10 mmol / l;_<br>_pH ~ <7,15 ou> 7,7)_<br>_Distúrbios graves de_<br>_eletrólitos e fluidos (K_<sup>_+_</sup>_<2,5_<br>_ou> 7,0 mmol / l)_<br>_Hipoglicemia grave (~ <30_<br>_mg / dl ou   1,7 mmol / l em_<br>_adultos)_<br>_Hipo ou hipertermia perigosa_|
|_Fígado_|_Aumento discreto de_<br>_enzimas séricas_<br>_(ASAT, ALT ~ 2-5 x normal)_|_Aumento das enzimas_<br>_séricas (ASAT, ALT~ 5-50 x_<br>_normal) mas nenhum_<br>_diagnóstico bioquímico (por_<br>_exemplo, amônia, fatores_<br>_de coagulação) ou_<br>_evidência clínica de_<br>_disfunção_|_Aumento das enzimas_<br>_séricas (~> 50 x normal) ou_<br>_Bioquímica (por exemplo,_<br>_amônia, fatores de_<br>_coagulação) ou evidência_<br>_clínica de insuficiência_<br>_hepática_|
|_Rins_|_Discreta hematúria e_<br>_proteinúria_|_Proteinúria / hematúria_<br>_maciça_<br>_Insuficiência renal (por_<br>_exemplo, oligúria,_<br>_poliúria,creatinina sérica de ~_<br>_1,3 mg /dL)_|_Insuficiência renal (por_<br>_exemplo, anúria, creatinina_<br>_sérica> 1,6mg / dL)_|
|_Hematologia_|_Hemólise discreta_<br>_Metemoglobinemia_<br>_discreta (metHb ~ 10-_<br>_30%)_|_Hemólise_<br>_Metahemoglobinemia mais_<br>_pronunciada (metHb ~ 30-_<br>_50%)_<br>_Distúrbios de coagulação_<br>_sem sangramento_<br>_Anemia, leucopenia,_<br>_trombocitopenia_|_Hemólise maciça_<br>_Metemoglobinemia grave_<br>_(metHb> 50%)_<br>_Distúrbios de coagulação_<br>_com sangramento_<br>_Anemia grave, leucopenia,_<br>_trombocitopenia._|
|_Sistema_<br>_Muscular_|_Dor leve, sensibilidade_<br>_CPK ~ 250-1.500 iu / l_|_Dor, rigidez, cólicas e_<br>_fasciculação_<br>_Rabdomiólise, CPK ~ 1.500-_<br>_10.000 iu / l_|_Dor intensa, extrema_<br>_rigidez, cólicas e_<br>_fasciculação extensa_<br>_Rabdomiólise com_<br>_complicações, CPK~>_<br>_10.000 iu / l Síndrome_<br>_compartimental_|
|_Pele_|_Irritação, queimaduras de_<br>_1º grau(vermelhidão) ou_<br>_queimaduras de 2º grau_<br>_<10% da área da superfície_<br>_corporal_|_Queimaduras de 2º grau em_<br>_10-50% da superfície_<br>_corporal (crianças: 10-30%)_<br>_ou 3º grau em <2% da área_<br>_da superfície corporal_|_Queimaduras de 2º grau_<br>_em> 50% da superfície_<br>_corporal (crianças:> 30%)_<br>_ou queimaduras de 3º grau_<br>_> 2% da área de superfície_<br>_corporal_|
|_Olhos_|_Irritação, eritema,_<br>_lacrimejamento,_<br>_edema palpebral discreto_|_Irritação intensa, abrasão_<br>_corneana_<br>_Úlceras corneanas menores_<br>_(puntiformes)_|_Úlceras corneanas com_<br>_perfuração_<br>_Dano ocular permanente_|  
32  
|_Efeitos locais_<br>_de_<br>_picadas/ferrões_|_Prurido, ardor discreto, dor_<br>_leve_|_Edema envolvendo toda a_<br>_extremidade, necrose local_<br>_e dor moderada_|_Edema envolvendo toda a_<br>_extremidade e partes_<br>_significativas da área_<br>_adjacente ao local da_<br>_picada, necrose extensa_|
|---|---|---|---|
||||_Edema de vias aéreas_<br>_Dor extrema_|  
_Fonte:_ Traduzido de _POISONING SEVERITY SCORE (PSS) IPCS/EAPCCT._  
_http://www.who.int/ipcs/poisons/pss.pdf_

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Antes da realização dos procedimentos ora descritos, considere** :  
- a) A obrigatoriedade do uso de Equipamentos de Proteção Individual pela equipe de saúde;  
- b) O descarte adequado do material contaminado, considerando as rotinas estabelecidas na unidade e as normas de biossegurança vigentes.  
##### **Descontaminação Cutânea/Dérmica**<sup>59</sup>  
- Considerar cobrir ferimentos antes de iniciar a lavagem corporal;  
- Remover as vestes ou equipamentos contaminados, com especial cuidado para não agravar a contaminação de áreas corpóreas, em especial a face. Cortar as vestes é mais seguro;  
- Se o agente for pó ou sólido, retirar o excesso com pano seco ou compressa, antes de lavar;  
33

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
- Realizar lavagem da área afetada ou corporal com com água fria e sabão neutro, com especial atenção para cabelos, axilas, umbigo, região genital e subungueal. Não esfregar a pele com força.  
- Evitar hipotermia  
##### **Descontaminação dos Olhos**<sup>59</sup>  
- Na exposição ocular, lavar com água ou solução salina morna, com fluxo contínuo, com as pálpebras abertas, a partir do canto do olho (próximo ao nariz) para a lateral da face, por no mínimo, 20 minutos.  
- Pode ser usado colírio anestésico previamente para facilitar procedimento.  
- Se um único olho for acometido, lateralizar a cabeça mantendo para baixo o olho acometido para realizar a lavagem, evitando contaminar o olho sadio.  
- Se os dois olhos forem acometidos, lavá-los com fluxo contínuo de soro fisiológico ou água, do centro ou região entre os olhos para as laterais.  
- Proteja o restante da face com compressas.  
Uma forma improvisada que pode ser útil é a utilização de cateter para O2, tipo óculos, colocando a dupla saída sobre a parte superior do nariz, próxima ao canto dos olhos, mantendo uma saída de cada lado do nariz e direcionada para cada olho. Conecte o cateter a um frasco de SF e mantenha fluxo contínuo.  
##### **Lavagem Gástrica**<sup>60</sup>  
Colocar o paciente, preferencialmente, em decúbito lateral esquerdo com a cabeça em nível inferior ao corpo.  
Se possível, explicar ao paciente o procedimento. Pacientes comatosos devem ser intubados antes do procedimento.  
Medir o comprimento da sonda (lóbulo da orelha, ponta do nariz, apêndice xifoide) Colocar lidocaína gel na extremidade distal e na narina escolhida.  
Deve-se confirmar a presença da sonda para assegurar o posicionamento. Habitualmente, insufla-se ar por meio de uma seringa ao mesmo tempo em que se ausculta a região epigástrica.  
Em adultos, uma lavagem gástrica bem-sucedida necessita de uma média de 6 a 8 litros de líquido (soro fisiológico ou água). Administram-se pequenas quantidades (máximo 250 ml/vez), visto que volumes maiores podem “empurrar” o agente tóxico para o duodeno. Em crianças, utilizam-se 5-10 mL/kg até o máximo de 250 mL/ vez. Volume total usado em média para neonatos 500 mL; lactentes 2-3 L; escolares 4-5 L.  
Repete-se esse procedimento várias vezes (mínimo oito). O volume retornado sempre deve ser próximo ao volume ofertado e observar atentamente o conteúdo que retorna, na  
34

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
procura de restos do agente tóxico. Após cerca de 2.000 mLde líquido e esse retornando límpido, pode-se parar o procedimento  
##### **Carvão ativado**<sup>59</sup>  
- Separar a quantidade total a ser utilizada, sendo 1 g/Kg, no máximo 50 g;  
- Diluir na proporção de 8 mL de soro fisiológico ou água potável para cada grama do carvão ativado.  
- Introduzir a diluição pela SNG e anotar o horário;  
- Manter o paciente em decúbito lateral esquerdo com o objetivo de retardar o esvaziamento gástrico;  Após cerca de 30 minutos, esvaziar o estômago pela sonda nasogástrica;  
35

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Quadro III.1.1 -** Perguntas PICO relativas à intoxicação aguda por agrotóxicos a base de glifosato.  
|**Perguntas**|**População**|**Intervenção**|**Comparação**|**Desfecho**|
|---|---|---|---|---|
|1. Quais são as manifestações<br>clínicas, sinais e sintomas que<br>permitem suspeitar intoxicação<br>aguda por glifosato?|Busca sistemática sem<br>avaliação de evidência|Homens e mulheres expostos a glifosato.<br>Subgrupos específicos: Grávidas, criança e idosos|Descrição do quadro clínico<br>por sistemas  e via de<br>exposição||
|2. Como deve ser a anamnese no<br>paciente com suspeita de<br>intoxicação por glifosato?|Manter a anamnese<br>da abordagem geral||||
|3. Quais são as provas para realizar<br>diagnóstico laboratorial de<br>intoxicação aguda por glifosato?|Busca sistemática sem<br>avaliação de evidência|Homes e mulheres com suspeita de intoxicação por<br>glifosato|Determinação de AMPA<br>-Espetrometria de massa<br>-Cromatografia||
|4. Quais são os testes auxiliam na<br>avaliação clínica do paciente com<br>suspeita de intoxicação com<br>glifosato?|Busca sistemática sem<br>avaliação de evidência|Homes e mulheres com suspeita de intoxicação por<br>glifosato|||
|5. Quais são as manifestações<br>clínicas associadas ao surfactante?|Busca sistemática sem<br>avaliação de evidência|Homes e mulheres com suspeita de intoxicação por<br>glifosato|||  
36

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|6. Quais são os critérios de gravidade<br>específica para intoxicações agudas<br>por glifosato?|Busca sistemática sem<br>avaliação de evidência|Homes e mulheres com suspeita de intoxicação por<br>glifosato|Descrição dos fatores<br>associados a gravidade da<br>intoxicação||
|---|---|---|---|---|
|7. Quais são os métodos de<br>descontaminação efetivos na<br>intoxicação por glifosato?|Busca sistemática com<br>avaliação da evidência|Homes e mulheres com suspeita de intoxicação por<br>glifosato|-Descontaminação dérmica<br>e ocular<br>-Carvão ativado<br>-Outras subtâncias para<br>reduzir absorção (ex.: leite)<br>-Lavagem gástrica|Ausência da<br>intervenção|
|8. Quais são os métodos de<br>eliminação efetivos na intoxicação<br>por glifosato?|Busca sistemática com<br>avaliação da evidência|Homes e mulheres com suspeita de intoxicação por<br>glifosato|-Catárticos<br>-hemodialise<br>-Hemoperfusão<br>-Circulação extracorporea|Ausência da<br>intervenção|
|9. Qual é o tratamento inicial para o<br>paciente intoxicado com glifosato?|Para suporte<br>considerar capítulo 1|Homens e mulheres potencialmente expostos a glifosato<br>Subgrupo: trabalhadores|- Tratamento de suporte||
|10. Qual é a melhor forma de fazer<br>seguimento aos pacientes com<br>intoxicação aguda por glifostato?|Capítulo 1|Homens e mulheres  com intoxicação por glifosato|||
|11. Qual deve ser o<br>acompanhamento, segmento e|Capítulo 1|Homens e mulheres  que passaram pelo quadro de<br>intoxicação por glifosato que possuem quadro de<br>sintomatologia continuada|||  
37

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
reabilitação do paciente intoxicado por glifosato?

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Quadro III.2.1** Estratégia de busca e associação de palavras-chave, no **PubMed** , para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|**Pergunta**|**Bloco conceitual**<br>**Termos**|**Estratégia**|**Pubmed**|
|---|---|---|---|
|||("poisoning"[Subheading] OR "poisoning"[All Fields] OR||
|Perguntas de 1 a 7|Estratégia abrangente|"poisoning"[MeSH Terms] OR exposure[All Fields] OR intoxicat*<br>[All Fields] OR excret* [All Fields] OR eliminat* [All Fields] OR<br>residue* [All Fields] OR "Pesticide Residues"[Mesh] OR|130<br>(1A)|
|||metabolite*[All Fields]) AND ("glyphosate"[All Fields] OR||  
38

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
||||glyphosate[Text Word] OR "glyphosate"[Supplementary<br>Concept] OR glyphosat*[All Fields] OR “Glyphosate Residues”<br>[All Fields] OR "N-(phosphonomethyl)glycine trimethylsulfonium<br>salt"[Supplementary Concept]) AND "humans"[MeSH Terms]<br>AND (("2010/01/01"[PDAT] : "2018/03/31"[PDAT]) AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang]))||
|---|---|---|---|---|
|1. Quais são as manifestações<br>clínicas, sinais e sintomas que<br>permitem suspeitar de intoxicação<br>aguda por glifosato?|Manifestações clínicas, toxíndromes,<br>intoxicação aguda|Agrochemicals, Pesticides,<br>Poisoning, Signs and<br>symptoms, Glyphosate,<br>humans.|("poisoning"[Subheading] OR "poisoning"[All Fields] OR<br>"poisoning"[MeSH Terms] OR exposure[All Fields] OR intoxicat*<br>[All Fields] OR excret* [All Fields] OR eliminat* [All Fields] OR<br>residue* [All Fields] OR "Pesticide Residues"[Mesh] OR||
|2. Como deve ser a anamnese no<br>paciente com suspeita de<br>intoxicação por glifosato?<br>(**ABORDAGEM GERAL**)|Anamnese, questionários clínicos,<br>linguagem adequada das perguntas.|Agrochemicals, Pesticides,<br>Intoxication, Poisoning,<br>Interview, Physical<br>Examination, glyphosate,<br>humans.|metabolite*[All Fields]) AND ("glyphosate"[All Fields] OR<br>glyphosate[Text Word] OR "glyphosate"[Supplementary<br>Concept] OR glyphosat*[All Fields] OR “Glyphosate Residues”<br>[All Fields] OR "N-(phosphonomethyl)glycine trimethylsulfonium<br>salt"[Supplementary Concept]) AND ("humans"[MeSH Terms])|45|
|3. Qual o diagnóstico diferencial<br>com relação a intoxicações<br>causadas por substâncias cáusticas,<br>herbicida paraquat ou outros<br>agrotóxicos?|Homes e mulheres com suspeita de<br>intoxicação por glifosato, diagnóstico<br>diferencial|Pesticides, Agrochemicals,<br>diagnosis differential,<br>glyphosate, humans.|AND ("Injury Severity Score"[Mesh] OR "Trauma Severity<br>Indices"[Mesh] OR "interview"[Publication Type] OR "interviews<br>as topic"[MeSH Terms] OR "interview"[All Fields] OR "Severity<br>of Illness Index"[Mesh] OR "Simplified Acute Physiology<br>Score"[Mesh] OR  "Patient Acuity"[Mesh] OR ("Pulmonary|(1B)|
|4. Quais são as provas para realizar<br>diagnóstico laboratorial de<br>intoxicação aguda por glifosato?|Determinação de AMPA<br>- glifosato no plasma<br>-Espectrometria de massa<br>-Cromatografia|Pesticides, Agrochemicals,<br>diagnosis, Clinical Laboratory<br>Techniques, residues, humans,<br>glyphosate.|Surfactants"[Mesh] OR "Surface-Active Agents"[Mesh] OR<br>"Pathology, Clinical"[Mesh] OR "Decision Support Systems,<br>Clinical"[Mesh] OR Clinical examination [All fields] OR "Clinical<br>Chemistry Tests"[Mesh] OR "Chemistry, Clinical"[Mesh] OR||  
39  
|5. Quais são os testes que auxiliam<br>na avaliação clínica do paciente<br>com suspeita de intoxicação com<br>glifosato?|Hemograma<br>Bioquimica<br>Endoscopia<br>Incluir Endoscopia digestiva alta -<br>lesão corrosiva|Pesticides, Agrochemicals,<br>diagnosis, Clinical examination,<br>humans, glyphosate|"Clinical Decision-Making"[Mesh] OR "Clinical Laboratory<br>Techniques"[Mesh] OR "Nursing Diagnosis"[Mesh] OR<br>"Diagnosis, Oral"[Mesh] OR "Diagnosis"[Mesh] OR  "diagnosis"<br>[Subheading]) OR "diagnosis, differential"[MeSH Terms] OR<br>"Diagnosis"[Mesh] OR "diagnosis" [Subheading] OR "signs and|
|---|---|---|---|
|||Pesticides, Agrochemicals,|symptoms"[MeSH Terms] OR "Physical Examination"[Mesh])|
|6. Quais são as manifestações<br>clínicas associadas ao surfactante?|Homes e mulheres com suspeita de<br>intoxicação por glifosato|Surfactant, humans,<br>glyphosate|AND ("humans"[MeSH Terms]) AND ("2010/01/01"[PDAT] :<br>"2018/03/31"[PDAT]) AND (English[lang] OR Portuguese[lang]<br>OR Spanish[lang])|
|7. Quais são os critérios de<br>gravidade específica para<br>intoxicações agudas por glifosato?|Descrição dos fatores associados a<br>gravidade da intoxicação|Pesticides, Agrochemicals,<br>Injury Severity Score, severity<br>indexes||  
*Filtros aplicados: período 01/01/2010 a 31/03/2018, idiomas inglês, português e espanhol. Busca realizada no dia 14/05/2018.  
40  
**Quadro III.2.2** Estratégia de busca e associação de palavras-chave, para o **Cochrane Library** , para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|**Pergunta**|**Bloco conceitual**|**Termos**||**Estratégia**|**Cochrane**|
|---|---|---|---|---|---|
|||**Inglês**||||
|Perguntas de 1 a 7|Diagnóstico<br>Sinais e Sintomas<br>Testes Laboratoriais<br>Gravidade<br>Intoxicação<br>Glifosato|Glyphosate, Signs and symptoms,<br>Examination, Diagnosis, Clinical<br>Laboratory Techniques, human|glyphosate AND human||5 (1c)|  
*Filtros aplicados: idioma da revisão em português, inglês ou espanhol. Busca realizada no dia 14/05/2018  
**Quadro III.2.3.** Estratégia de busca e associação de palavras-chave, para **Lilacs/BVS** , para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|||**LILACS**||
|---|---|---|---|
|**Perguntas/ temas**|**Bloco conceitual e termos**|**Estratégia**|**Resultados**|
|||tw:((tw:(glifosato)) AND (tw:(diagnóstico*))) AND||
|1. Glifosato e Diagnóstico|Glifosato + diagnóstico|(instance:"regional") AND ( db:("LILACS")|2 (2a)|  
41  
|||tw:((tw:(glifosato)) AND ((tw:(sinais)) OR (tw:(clínic*)) OR||
|---|---|---|---|
|2. Glifosato e sinais e sintomas|Glifosato + sinais e sintomas|(tw:(sintomas)) OR (tw:(señales)) OR (tw:(síntomas)))) AND|3 (2b)|
|||(instance:"regional") AND ( db:("LILACS")||
|3. Glifosato e gravidade clínica|Glifosato + gravidade|tw:((tw:(glifosato)) AND ((tw:(gravidade)) OR<br>(tw:(gravedade)))) AND (instance:"regional")|1 (2c)|  
*Filtros aplicados: período 01/01/2010 a 2018, idiomas inglês, português e espanhol e que contivessem as palavras-chaves no título, resumo ou assunto (tw). Busca realizada no dia 14/05/2018.  
**Quadro III.2.4** Estratégia de busca e associação de palavras-chave, no **PubMed** , para as perguntas PICO de Tratamento do Capítulo 3 - Glifosato.  
|**Pergunta**|**Bloco conceitual**|**Termos**|**Estratégia**|**Pubmed**|
|---|---|---|---|---|
|PUBMED|||||
|1. Quais são os métodos de<br>descontaminação efetivos na<br>intoxicação por glifosato?|Decontamination, methods,<br>glyphosate|Agrochemicals, Pesticides,<br>Intoxication, Poisoning,<br>Decontamination, Glyphosate,<br>humans.|("therapy" [Subheading] OR "Emergency Treatment"[Mesh] OR<br>"Treatment Adherence and Compliance"[Mesh] OR "Involuntary<br>Treatment"[Mesh] OR "Conservative Treatment"[Mesh] OR||
|2. Quais são os métodos de<br>eliminação efetivos na intoxicação<br>por glifosato?|Decontamination, therapy, excretion,<br>methods, glyphosate|Agrochemicals, Pesticides,<br>Intoxication, Poisoning,<br>Decontamination, Excretion,<br>glyphosate, humans.|"Therapeutics"[Mesh] OR  "complications" [Subheading] OR<br>"Aftercare"[Mesh]<br>OR<br>"Retreatment"[Mesh]<br>OR<br>"Rehabilitation"[Mesh] OR Treatment* OR Decontam* [All<br>Fields]<br>OR<br>Excret*)<br>AND<br>("poisoning"[Subheading]<br>OR|42<br>(1A)|
|3. Qual é o tratamento inicial para<br>o paciente intoxicado com<br>glifosato?|Treatment, therapy, intoxication,<br>glyphosate|Pesticides, Agrochemicals,<br>treatment, therapy,<br>glyphosate, humans.|"poisoning"[All Fields] OR "poisoning"[MeSH Terms] OR<br>exposure[All Fields] OR intoxicat* [All Fields] OR residue* [All<br>Fields] OR "Pesticide Residues"[Mesh] OR metabolite*[All||  
42  
||||Fields]) AND ("glyphosate"[All Fields] OR glyphosate[Text Word]<br>OR "glyphosate"[Supplementary Concept] OR glyphosat*[All||
|---|---|---|---|---|
|4. Qual é a melhor forma de fazer<br>seguimento aos pacientes com<br>intoxicação aguda por glifosato?|Follow-up, complications, glyphosate|Pesticides, Agrochemicals,<br>Intoxication, diagnosis,<br>aftercare, humans, glyphosate.|Fields] OR “Glyphosate Residues” [All Fields] OR "N-<br>(phosphonomethyl)glycine<br>trimethylsulfonium<br>salt"[Supplementary Concept]) AND "humans"[MeSH Terms]<br> <br> <br> <br>||
|5. Qual deve ser o<br>acompanhamento, segmento e<br>reabilitação do paciente intoxicado<br>por glifosato?|Aftercare, follow-up, retreatment,<br>rehabilitation, intoxication, poisoning,<br>glyphosate|Pesticides, Agrochemicals,<br>Intoxication, rehabilitation,<br>follow-up, humans, glyphosate|AND<br>(("2010/01/01"[PDAT]<br>:<br>"2018/03/31"[PDAT])<br>AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang]))||
|||Busca adicional|human* AND (polyoxyethyleneamine OR surfactant*) AND<br>(poisoning OR intoxicat*) AND glyphosate|6 (1B)|  
*Filtros aplicados: período 01/01/2010 a 31/03/2018, idiomas inglês, português e espanhol. Busca realizada no dia 02/07/2018.  
43  
**Quadro III.2.5** Estratégia de busca e associação de palavras-chave, para o **Cochrane Library** , para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|**Pergunta**|**Bloco conceitual**|**Termos**||**Estratégia**|**Cochrane**|
|---|---|---|---|---|---|
|||**Inglês**||||
|Perguntas de 1 a 7|Diagnóstico<br>Sinais e Sintomas<br>Testes Laboratoriais<br>Gravidade<br>Intoxicação<br>Glifosato|Glyphosate, Signs and symptoms,<br>Examination, Diagnosis, Clinical<br>Laboratory Techniques, human|glyphosate||6 (2A)|  
*Filtros aplicados: período 01/01/2010 a 31/03/2018, idiomas inglês, português e espanhol. Busca realizada no dia 02/07/2018.  
**Quadro III.2.6.** Estratégia de busca e associação de palavras-chave, para **Lilacs/BVS** , para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|||**LILACS**||
|---|---|---|---|
|**Pergunta/ assunto**|**Termos**|**Estratégia**||
|Glifosato e Tratamento|Glifosato + tratamento|(tw:(tratamiento)) OR (tw:(tratamento)) AND (tw:(glifosato)) AND<br>(instance:"regional") AND ( db:("LILACS"))|10 (3A)|  
*Filtros aplicados: período 01/01/2010 a 31/03/2018, idiomas inglês, português e espanhol. Busca realizada no dia 02/07/2018.  
44

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Quadro III.3.1.** Artigos resultantes da busca sistemática no site **Pubmed,** para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|**Artigo**|**Autores**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|
|**BUSCA PUBMED 1A (130 artigos)**||||
|Occurrence of**glyphosate**and AMPA**residues**in soy-based infant formula<br>sold in Brazil.|Rodrigues NR, de Souza APF.|2018|Sim|
|**Glyphosate**has limited short-term effects on commensal bacterial<br>community composition in the gut environment due to sufficient aromatic<br>amino acid levels.|Nielsen LN, Roager HM, Casas ME, Frandsen HL,<br>Gosewinkel U, Bester K, Licht TR, Hendriksen NB, Bahl<br>MI.|2018|Não|
|**Excretion**of the Herbicide**Glyphosate**in Older Adults Between 1993 and<br>2016.|Mills PJ, Kania-Korwel I, Fagan J, McEvoy LK, Laughlin<br>GA, Barrett-Connor E.|2018|Sim|
|An assessment of the acute dietary<br>**exposure**to**glyphosate**usingdeterministic andprobabilistic methods.|Stephenson CL, Harris CA, Clarke R.|2018|Sim|
|**Exposure**assessment using human biomonitoring for**glyphosate**and<br>fluroxypyr users in amenity horticulture.|Connolly A, Jones K, Galea KS, Basinas I, Kenny L,<br>McGowan P, Coggins M.|2017|Sim|  
45

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|Severe Glyphosate-Surfactant Intoxication Successfully Treated With<br>Continuous Hemodiafiltration and Direct Hemoperfusion: Case Report.<br>~~e~~|Ozaki T, Sofue T, Kuroda Y.<br>~~e~~|2017<br>|Sim<br>|
|---|---|---|---|
|**Glyphosate Residues**in Groundwater, Drinking Water and Urine of<br>Subsistence Farmers from Intensive Agriculture Localities: A Survey in<br>Hopelchén,Campeche,Mexico.<br><br><br>|Rendon-von Osten J, Dzul-Caamal R.<br><br><br>|2017<br><br><br>|Sim<br><br><br>|
|The health consequences of aerial spraying illicit crops: The case of Colombia.<br>|Camacho A, Mejía D.<br>|2017<br>|Não<br>|
|Vasculitic Neuropathy Following Exposure to a Glyphosate-based Herbicide.<br><br>~~e~~<br>|Kawagashira Y, Koike H, Kawabata K, Takahashi M,<br>Ohyama K, Hashimoto R, Iijima M, Katsuno M, Sobue<br>G.<br><br>~~e~~<br><br>|2017<br><br><br>|Sim<br><br><br>|
|Comments on the"**Glyphosate**herbicide**residue**determination in samples<br>of environmental importance using spectrophotometric method".<br>~~—~~<br>|Gomes MP, Maccario S, Le Manac'h SG, Lucotte M,<br>Moingt M, Paquet S, Labrecque M, Juneau P.<br>~~—~~<br><br>~~—CO~~|2017<br><br>|Não<br><br>~~T~~|
|**Glyphosate**and Paraquat in Maternal and Fetal Serums in Thai Women.<br><br><br>~~e~~<br>|Kongtip P, Nankongnab N, Phupancharoensuk R,<br>Palarach C, Sujirarat D, Sangprasert S, Sermsuk M,<br>Sawattrakool N,Woskie SR.<br><br><br> <br>~~e~~<br>|2017<br><br> <br><br><br>|Sim<br><br><br><br><br>|
|AminoMethylPhosphonic acid (AMPA) in natural waters: Its sources, behavior<br>and environmental fate.<br>~~——r—CO~~|Grandcoin A, Piel S, Baurès E.<br>~~Cisd~~|2017<br><br>|Não<br>~~TC~~<br>~~ST~~|
|**Glyphosate**toxicity and carcinogenicity: a review of the scientific basis of the<br>European Union assessment and its differences with IARC.<br><br>~~———~~<br>|Tarazona JV, Court-Marques D, Tiramani M, Reich H,<br>Pfeil R, Istace F, Crivellente F.<br><br>~~———~~<br>~~|~~|2017<br><br><br>|Não<br><br><br>~~—~~|
|DNA damage and methylation induced by**glyphosate**in human peripheral<br>blood mononuclear cells (in vitro study).<br><br><br>~~———~~<br>|Kwiatkowska M, Reszka E, Woźniak K, Jabłońska E,<br>Michałowicz J, Bukowska B.<br><br><br>~~‘i~~|2017<br><br><br>|Não<br><br>~~T~~<br>|
|Is it time to reassess current safety standards for**glyphosate**-based<br>herbicides?<br><br>~~_—~~<br>~~a~~|Vandenberg LN, Blumberg B, Antoniou MN, Benbrook<br>CM,Carroll L,Colborn T,Everett LG,Hansen M,<br>|2017<br><br>|Sim<br><br>~~T~~|  
46

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|Secretaria de Ciência,<br>~~e~~|Tecnologia e Insumos Estratégicos SCTIE<br>Landrigan PJ, Lanphear BP, Mesnage R, Vom Saal FS,<br>Welshons WV, Myers JP.<br>~~e~~<br>~~ee~~|~~e~~||
|---|---|---|---|
|Serum S100 protein could predict altered consciousness in glyphosate or<br>glufosinatepoisoning patients.<br><br>~~r~~<br><br>|Lee JW, Choi YJ, Park S, Gil HW, Song HY, Hong SY.<br><br> <br>~~s~~<br><br><br>|2017<br><br> <br><br><br>|Sim<br><br><br><br><br>|
|Ustiloxin G, a New Cyclopeptide Mycotoxin from Rice False Smut Balls.<br><br>|Wang X, Wang J, Lai D, Wang W, Dai J, Zhou L, Liu Y.<br><br><br>|2017<br><br>|Não<br><br>|
|Occupational, dietary, and other risk factors for myelodysplastic syndromes<br>in Western Greece.<br><br>|Avgerinou C, Giannezi I, Theodoropoulou S, Lazaris V,<br>Kolliopoulou G, Zikos P, Alamanos Y, Leotsinidis M,<br>Symeonidis A.<br><br><br>|2017<br><br>|não<br><br>|
|Organophosphorus Xenobiotic Toxicology.<br><br>|Casida JE.<br><br><br>~~[Trie~~|2017<br><br>~~s~~|Sim<br><br>~~te~~|
|Overlooking relevant confounders in the assessment of pesticides and<br>human health: a reply to Mostafalou and Abdollahi.<br> <br>~~———~~<br><br>|Fluegge K.<br><br><br>~~——~~<br><br>|2017<br><br><br>|não<br><br>~~_~~<br>|
|Efficiency control of dietary pesticide intake reduction by human<br>biomonitoring.<br><br><br>|Göen T, Schmidt L, Lichtensteiger W, Schlumpf M.<br><br><br><br>~~e—eeeeses~~|2017<br><br><br>~~e~~|Sim<br><br><br>|
|**Glyphosate**and AMPA distribution in wind-eroded sediment derived from<br>loess soil.<br><br><br>|Bento CPM, Goossens D, Rezaei M, Riksen M, Mol<br>HGJ, Ritsema CJ, Geissen V.<br><br><br><br>|2017<br><br><br>|Não<br><br><br>|
|**Glyphosate**in German adults-Time trend (2001 to 2015) of<br>human**exposure**to a widely used herbicide.<br><br>~~——~~<br><br>|Conrad A, Schröter-Kermani C, Hoppe HW, Rüther M,<br>Pieper S, Kolossa-Gehring M.<br><br>~~——~~<br><br>|2017<br><br><br>|Sim<br><br>~~_~~<br>|
|Rheumatoid Arthritis in Agricultural Health Study Spouses: Associations with<br>Pesticides and Other Farm Exposures.<br><br><br>~~|~~<br>~~[—i—sda:C~~|Parks CG, Hoppin JA, De Roos AJ, Costenbader KH,<br>Alavanja MC,Sandler DP.<br><br><br>~~s~~<br>~~dGs—ssi~~|2016<br><br><br>~~s~~|Não<br><br>~~e~~<br>~~sE~~|  
47

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|Passive**exposure**to agricultural pesticides and risk of childhood leukemia in<br>an Italian community.|Malagoli C, Costanzini S, Heck JE, Malavolti M, De<br>Girolamo G, Oleari P, Palazzi G, Teggi S, Vinceti M.|2016|Não|
|---|---|---|---|
|Does environmental**exposure**to the greenhouse gas, N<sub>2</sub>O,<br>contribute to etiological factors in neurodevelopmental disorders? A mini-<br>review of the evidence.|Fluegge K.|2016|Não|
|SANIST: optimization of a technology for compound identification based on<br>the European Union directive with applications in forensic, pharmaceutical<br>and food analyses.|Cristoni S, Dusi G, Brambilla P, Albini A, Conti M,<br>Brambilla M, Bruno A, Di Gaudio F, Ferlin L, Tazzari V,<br>Mengozzi S, Barera S, Sialer C, Trenti T, Cantu M,<br>Rossi Bernardi L, Noonan DM.|2017|Sim|
|Australian work exposures studies: occupational exposure to pesticides.|Jomichen J, El-Zaemey S, Heyworth JS, Carey RN,<br>Darcey E, Reid A, Glass DC, Driscoll T, Peters S,<br>Abramson M, Fritschi L.|2017|Não|
|Influence of the agrochemicals used for rice and vegetable cultivation on<br>insecticide resistance in malaria vectors in southern Côte d'Ivoire.|Chouaïbou MS, Fodjo BK, Fokou G, Allassane OF,<br>Koudou BG, David JP, Antonio-Nkondjio C, Ranson H,<br>Bonfoh B.|2016|Não|
|**Glyphosate**: environmental contamination, toxicity and potential risks to<br>human health via food contamination.|Bai SH, Ogbourne SM.|2016|Não|
|Pesticides are Associated with Allergic and Non-Allergic Wheeze among Male<br>Farmers.<br>~~e~~|Hoppin JA, Umbach DM, Long S, London SJ,<br>Henneberger PK, Blair A, Alavanja M, Freeman LE,<br>Sandler DP.<br>|2017<br>|Sim<br>|
|An assessment of dietary**exposure**to**glyphosate**using refined deterministic<br>and probabilistic methods.<br><br>|Stephenson CL, Harris CA.<br><br>~~e~~|2016<br><br>|Não<br><br>~~e~~|  
48  
|Carcinogenic compounds in alcoholic beverages: an update.|Pflaum T, Hausler T, Baumung C, Ackermann S,<br>Kuballa T, Rehm J, Lachenmeier DW.|2016|Não|
|---|---|---|---|
|Mechanism-specific injury biomarkers predict nephrotoxicity early<br>following glyphosate surfactant herbicide (GPSH) poisoning.|Mohamed F, Endre ZH, Pickering JW, Jayamanne S,<br>Palangasinghe C, Shahmy S, Chathuranga U,<br>Wijerathna T, Shihana F, Gawarammana I, Buckley<br>NA.|2017|Sim|
|The Impact of**Glyphosate**, Its**Metabolites**and Impurities on Viability, ATP<br>Level and Morphological changes in Human Peripheral Blood Mononuclear<br>Cells.|Kwiatkowska M, Jarosiewicz P, Michałowicz J, Koter-<br>Michalak M, Huras B, Bukowska B.|2016|Sim|
|The characteristics of emergency department presentations related to acute<br>herbicide or insecticide**poisoning**in South Korea between 2011 and 2014.|Moon JM, Chun BJ, Cho YS.|2016|Sim|
|Glyphosate and adverse pregnancy outcomes, a systematic review of<br>observational studies.|de Araujo JS, Delgado IF, Paumgartten FJ.|2016|Não|
|Prognostic Factors in Emergency Department Patients<br>with Glyphosate Surfactant Intoxication: Point-of-Care Lactate Testing.|Kim YH, Lee JH, Cho KW, Lee DW, Kang MJ, Lee KY,<br>Lee YH,HwangSY,Lee NK.|2016|Sim|
|Organic honey supplementation reverses pesticide-induced genotoxicity by<br>modulating DNA damage response.|Alleva R, Manzella N, Gaetani S, Ciarapica V, Bracci M,<br>Caboni MF, Pasini F, Monaco F, Amati M, Borghi B,<br>Tomasetti M.|2016|Não|
|Occupational**Exposure**to Pesticides With Occupational<br>Sun**Exposure**Increases the Risk for Cutaneous Melanoma.|Fortes C, Mastroeni S, Segatto M M, Hohmann C,<br>Miligi L, Bakos L, Bonamigo R.|2016|Não|
|**Glyphosate**and aminomethylphosphonic acid are not detectable in human<br>milk.|McGuire MK, McGuire MA, Price WJ, Shafii B,<br>Carrothers JM, Lackey KA, Goldstein DA, Jensen PK,<br>Vicini JL.|2016|Sim|
|Intravenous lipid emulsion in treatment of cardiocirculatory disturbances<br>caused by glyphosate-surfactant herbicide poisoning.|Jović-Stošić J, Putić V, Perković-Vukčević N, Babić G,<br>Đorđević S,Šegrt Z.|2016|Sim|  
49  
<!-- Start of picture text -->
a<br>Systematic review and meta-analysis of  glyphosate exposure  and risk of Chang ET, Delzell E.  2016  Não<br>ei lymphohematopoietic cancers.<br>Co-Formulants in  Glyphosate -Based Herbicides Disrupt Aromatase Activity in Defarge N, Takács E, Lozano VL, Mesnage R, Spiroux  nn 2016  i Não<br>Human Cells below Toxic Levels.  de Vendômois J, Séralini GE, Székács A.<br>Concerns over use of  glyphosate -based herbicides and risks associated with  Myers JP, Antoniou MN, Blumberg B, Carroll L,  2016  Não<br>exposures: a consensus statement. Colborn T, Everett LG, Hansen M, Landrigan PJ,<br>Lanphear BP, Mesnage R, Vandenberg LN, Vom Saal<br>—— FS, Welshons WV, Benbrook CM.<br>Systematic review of the effect of intravenous lipid emulsion therapy for  Levine M, Hoffman RS, Lavergne V, Stork CM,  2016  Não<br>non-local anesthetics toxicity.  Graudins A, Chuang R, Stellpflug SJ, Morris M, Miller-<br>Nesbitt A, Gosselin S; Lipid Emulsion Workgroup.<br>Determination of glyphosate and its metabolite in emergency room in Korea. Han J, Moon H, Hong Y, Yang S, Jeong WJ, Lee KS,  2016  Sim<br>Chung H.<br>——————<br>Environmental factors in the development of autism spectrum disorders. Sealey LA, Hughes BW, Sriskanda AN, Guest JR,  2016  Não<br>el Gibson AD, Johnson-Williams L, Pace DG, Bagasra O.<br>Determination of  Glyphosate  Levels in Breast Milk Samples from Germany by  Steinborn A, Alder L, Michalski B, Zomer P, Bendig P,  A 2016  Não<br>LC-MS/MS and GC-MS/MS.  Martinez SA, Mol HG, Class TJ, Pinheiro NC.<br>—=——_<br>The role of L-type amino acid transporters in the uptake of glyphosate across  Xu J, Li G, Wang Z, Si L, He S, Cai J, Huang J, Donovan  2016  Não<br>mammalian epithelial tissues.  MD.<br>SEC<br>——— A multicenter retrospective survey of poisoning after ingestion of herbicides  Kamijo Y, Takai M, Sakamoto T.  2016  Sim<br>containing<br>Se glyphosate potassium salt or other glyphosate salts in Japan.<br>Does  exposure  to  glyphosate  lead to an increase in the micronuclei Ghisi Nde C, de Oliveira EC, Prioli AJ.  2016  Não<br>|__| frequency? A systematic and meta-analytic review.  ee<br><!-- End of picture text -->  
50  
|The Biomarkers of Exposure and Effect in Agriculture (BEEA) Study: Rationale,<br>Design, Methods, and Participant Characteristics.|Hofmann JN, Beane Freeman LE, Lynch CF, Andreotti<br>G, Thomas KW, Sandler DP, Savage SA, Alavanja MC.|2015|Não|
|---|---|---|---|
|Analysis of Moms Across America report suggesting bioaccumulation<br>of glyphosate in U.S. mother's breast milk: Implausibility based on<br>inconsistency with available body of glyphosate animal toxicokinetic, human<br>biomonitoring, and physico-chemical data.|Bus JS.|2015|Não|
|Successful Extracorporeal Life Support in a Case of Severe Glyphosate-<br>Surfactant Intoxication.<br><br>|Chan CW, Wu IL, Lee CH, Hsu SC, Liao SC.<br><br>|2016<br>|Sim<br>|
|The role of ions, heavy metals, fluoride, and agrochemicals: critical<br>evaluation of potential aetiological factors of chronic kidney disease of<br>multifactorial origin (CKDmfo/CKDu) and recommendations for its<br>eradication.<br>~~—~~<br>|Wimalawansa SJ.<br>~~—~~<br>~~|~~|2016<br>|Não<br>|
|Common Pesticides Used in Suicide Attempts Following the 2012 Paraquat<br>Ban in Korea.<br>|Lee JW, Hwang IW, Kim JW, Moon HJ, Kim KH, Park S,<br>Gil HW, Hong SY.<br>|2015|Não|
|Potential toxic effects of**glyphosate**and its commercial formulations below<br>regulatory limits.|Mesnage R, Defarge N, Spiroux de Vendômois J,<br>Séralini GE.|2015|Sim|
|Acute eosinophilic pneumonia associated with glyphosate-<br>surfactant exposure.|De Raadt WM, Wijnen PA, Bast A, Bekers O, Drent M.|2015|Sim|
|Simultaneous**exposure**to multiple heavy metals and**glyphosate**may<br>contribute to Sri Lankan agricultural nephropathy.|Jayasumana C, Gunatilake S, Siribaddana S.|2015|Não|  
51  
|Aminomethylphosphonic acid and methoxyacetic acid induce apoptosis in<br>prostate cancer cells.<br>~~=——~~|Parajuli KR, Zhang Q, Liu S, You Z.<br>~~———~~|2015<br>|Não<br>~~_~~|
|---|---|---|---|
|Development of liquid chromatography methods coupled to mass<br>spectrometry for the analysis of substances with a wide variety of polarity in<br>meconium.<br><br>~~=~~<br>|Meyer-Monath M, Chatellier C, Cabooter D, Rouget F,<br>Morel I, Lestremau F.<br><br>~~—~~<br>|2015<br><br>|Não<br><br>|
|Multiparametric characterisation of neuronal network activity for in vitro<br>agrochemical neurotoxicity assessment.<br><br>~~S~~<br>|Alloisio S, Nobile M, Novellino A.<br><br><br>|2015<br><br>|Não<br><br>|
|Review of genotoxicity biomonitoring studies of**glyphosate**-based<br>formulations.<br><br><br>~~=————~~|Kier LD.<br><br><br>~~——_~~|2015<br><br>~~—~~|Sim<br><br>~~_~~|
|Global transcriptomic profiling demonstrates induction of oxidative<br>stress and of compensatory cellular stress responses in brown trout exposed<br>to**glyphosate**and Roundup.<br><br>~~e~~|Uren Webster TM, Santos EM.<br><br>~~e~~<br>~~a~~|2015<br><br>|Não<br><br>|
|Multiple myeloma and**glyphosate**use: a re-analysis of US Agricultural Health<br>Study (AHS) data.<br><br>~~_=———~~|Sorahan T.<br><br><br>~~————~~|2015<br><br>|Não<br><br>~~—~~|
|Drinking well water and occupational**exposure**to Herbicides is associated<br>with chronic kidney disease, in Padavi-Sripura, Sri Lanka.<br><br>|Jayasumana C, Paranagama P, Agampodi S,<br>Wijewardane C, Gunatilake S, Siribaddana S.<br><br>|2015<br><br>|Não<br><br>|
|Clostridium tertium bacteremia in a patient with glyphosate ingestion.<br><br>|You MJ, Shin GW, Lee CS.<br><br>|2015<br><br>|Sim<br><br>|
|Glyphosate-based herbicides potently affect cardiovascular system in<br>mammals: review of the literature.<br><br>~~p~~|Gress S, Lemoine S, Séralini GE, Puddu PE.<br><br>~~o~~|2015<br><br>|Sim<br><br>|  
52  
|A comparison of temporal trends in United States autism prevalence to<br>trends in suspected environmental factors.|Nevison CD.|2014|Não|
|---|---|---|---|
|Glyphosate-rich air samples induce IL-33, TSLP and generate IL-13 dependent<br>airway inflammation.|Kumar S, Khodoun M, Kettleson EM, McKnight C,<br>Reponen T, Grinshpun SA, Adhikari A.|2014|Não|
|Solid-phase extraction of phosphorous-containing amino acid herbicides<br>from biological specimens with a zirconia-coated silica cartridge.|Watanabe D, Ohta H, Yamamuro T.|2014|Não|
|Esophageal perforation and death following glyphosate poisoning.|Jyoti W, Thabah MM, Rajagopalan S, Hamide A.|2014|Sim|
|The effect of**glyphosate**, its**metabolites**and impurities on erythrocyte<br>acetylcholinesterase activity.<br>|Kwiatkowska M, Nowacka-Krukowska H, Bukowska B.<br><br>|2014<br>|Sim<br>|
|Effect of glyphosate on the sperm quality of zebrafish Danio rerio.<br>|Lopes FM, Varela Junior AS, Corcini CD, da Silva AC,<br>Guazzelli VG, Tavares G, da Rosa CE.<br><br>|2014<br>~~| ~~|Não<br>~~|~~|
|Unilateral hippocampal infarction associated with an attempted suicide: a<br>case report.<br><br>|Nishiyori Y, Nishida M, Shioda K, Suda S, Kato S.<br><br><br>|2014<br> <br>|Não<br> <br>|
|Non-Hodgkin lymphoma and occupational**exposure**to agricultural pesticide<br>chemical groups and active ingredients: a systematic review and meta-<br>analysis.<br><br>~~Se~~|Schinasi L, Leon ME.<br><br>~~t~~|2014<br><sup>~~| ~~</sup>|Não<br><sup>~~|~~</sup>|
|**Glyphosate**: its effects on**humans**.<br>|Campbell AW.<br>|2014<br>|Sim<br>|
|National toxicovigilance for pesticide exposures resulting in health care<br>contact-An example from the UK's National Poisons Information Service.<br> <br>~~=~~|Perry L, Adams RD, Bennett AR, Lupton DJ, Jackson G,<br>Good AM, Thomas SH, Vale JA, Thompson JP,<br>Bateman DN, Eddleston M.<br><br>~~|~~|2014<br><br>|Não<br><br>~~|~~|  
53  
|Major pesticides are more toxic to human cells than their declared active<br>principles.<br>~~e~~<br>|Mesnage R, Defarge N, Spiroux de Vendômois J,<br>Séralini GE.<br>~~e~~<br>|2014<br><br>|Sim<br>|
|---|---|---|---|
|Chaetoglobosins from Chaetomium globosum, an endophytic fungus in<br>Ginkgo biloba, and their phytotoxic and cytotoxic activities.<br><br>~~——————~~|Li H, Xiao J, Gao YQ, Tang JJ, Zhang AL, Gao JM.<br><br>~~|r~~|2014<br><br>|Não<br>|
|Methemoglobinemia associated with metaflumizone poisoning.<br> <br>~~e~~|Oh JS, Choi KH.<br> <br>|2014<br><br>|Não<br>|
|The effect of**metabolites**and impurities of**glyphosate**on human<br>erythrocytes (in vitro).<br><br>~~—~~<br>~~d~~|Kwiatkowska M, Huras B, Bukowska B.<br><br>|2014<br>|Não<br>|
|**Glyphosate**commercial formulation causes cytotoxicity, oxidative effects,<br>and apoptosis on human cells: differences with its active ingredient.<br><br><br>~~e~~<br>|Chaufan G, Coalova I, Ríos de Molina Mdel C.<br><br>~~e~~<br>|2014<br><br>|Sim<br><br><br>|
|Hemodialysis clearance of glyphosate following a life-threatening ingestion<br>of glyphosate-surfactant herbicide.<br>~~ee~~<br><br>|Garlich FM, Goldman M, Pepe J, Nelson LS, Allan MJ,<br>Goldstein DA,Goldfarb DS,Hoffman RS.<br>~~Mn~~<br>|2014<br>~~O~~<br>|Sim<br><br>~~en~~<br>|
|Heart rate-corrected QT interval predicts mortality in glyphosate-surfactant<br>herbicide-poisoned patients.<br><br>~~—~~<br>~~C~~|Kim YH, Lee JH, Hong CK, Cho KW, Park YH, Kim YW,<br>Hwang SY.<br> <br>~~S~~|2014<br> <br>|Sim<br><br><br>|
|**Glyphosate**toxicity in animals.<br><br><br>~~a~~|Bates N, Edwards N.<br>|2013<br>|Não<br>|
|Effect of intravenous lipid emulsion in patients with<br>acute glyphosateintoxication.<br><br>~~——_~~<br>~~d~~|Gil HW, Park JS, Park SH, Hong SY.<br><br>~~CO~~|2013<br>|Sim|
|With the benefit of hindsight: trials using retrospective controls versus<br>randomized controlled trials in clinical toxicology.<br><br><br>~~e~~<br>|Dawson AH, Wilks MF.<br><br><br>~~e~~|2013<br><br>|Sim<br>|
|Procedures to evaluate the efficiency of protective clothing worn by<br>operators applying pesticide.<br>~~——~~|Espanhol-Soares M, Nociti LA, Machado-Neto JG.|2013|Não|  
54  
<!-- Start of picture text -->
6<br><!-- End of picture text -->  
|Mi<br>Secretaria de Ciência,<br> <br>|nistério da Saúde<br>Tecnologia e Insumos Estratégicos SCTIE<br> <br>|<br>|<br>|
|---|---|---|---|
|Exacerbation of symptoms in agricultural pesticide applicators with asthma.<br>~~e~~<br>|Henneberger PK, Liang X, London SJ, Umbach DM,<br>Sandler DP, Hoppin JA.<br>~~d~~<br>|2014<br><br>|Sim<br><br>|
|Specific pesticide-dependent increases in α-synuclein levels in human<br>neuroblastoma (SH-SY5Y) and melanoma (SK-MEL-2) cell lines.<br><br>|Chorfa A, Bétemps D, Morignat E, Lazizzera C,<br>Hogeveen K, Andrieu T, Baron T.<br><br><br>|2013<br><br><br>|Não<br><br><br>|
|Review of genotoxicity studies of**glyphosate**and**glyphosate**-based<br>formulations.<br> <br>~~e~~<br>|Kier LD, Kirkland DJ.<br> <br>~~e~~<br>~~A~~<br>|2013<br><br><br>~~I~~<br>|Não<br><br><br><br>|
|Severe adverse effects related to dermal exposure to a glyphosate-surfactant<br>herbicide.<br>~~e~~|Mariager TP, Madsen PV, Ebbehøj NE, Schmidt B, Juhl<br>A.<br><br>~~e~~|2013<br><br>|Sim<br><br>|
|Determination of glyphosate and AMPA in blood and urine from humans:<br>about 13 cases of acute intoxication.<br><br>~~———~~<br>|Zouaoui K, Dulaurent S, Gaulier JM, Moesch C,<br>Lachâtre G.<br><br>~~__~~<br>~~|~~<br>|2013<br><br><br>|Sim<br><br>~~_~~<br>|
|Evaluation of developmental toxicity studies of**glyphosate**with attention to<br>cardiovascular development.<br><br><br>~~—_]~~|Kimmel GL, Kimmel CA, Williams AL, DeSesso JM.<br><br><br><br>~~—S~~|2013<br><br><br><br>|Sim<br><br><br>~~C~~<br>|
|Accidental chemical burns of oral mucosa by herbicide.<br><br>~~_——~~|Deo SP, Shetty P.<br><br>~~_—~~|2012<br><br><br>|Sim<br><br>~~—~~<br>|
|Diurnal variation in probability of death following self-**poisoning**in Sri Lanka--<br>evidence for chronotoxicity in**humans**.<br><br>~~S~~|Carroll R, Metcalfe C, Gunnell D, Mohamed F,<br>Eddleston M.<br><br>~~r~~|2012<br><br><br>|Sim<br><br><br>|
|Pathological and toxicological findings in**glyphosate**-surfactant herbicide<br>fatality: a case report.<br><br>~~S~~<br>|Sribanditmongkol P, Jutavijittum P, Pongraveevongsa<br>P, Wunnapuk K, Durongkadech P.<br><br>~~r~~<br>|2012<br><br>|Sim<br><br>|
|Epidemiologic studies of**glyphosate**and cancer: a review.<br><br>~~e~~<br>|Mink PJ, Mandel JS, Sceurman BK, Lundin JI.<br><br>~~e~~<br>|2012<br><br>|Não<br><br>|
|Herbicide roundup intoxication: successful treatment with continuous renal<br>replacement therapy.<br><br><br>|Hour BT, Belen C, Zar T, Lien YH.<br><br><br>|2012<br><br>|Sim<br><br>|
|Comparison of chemical-induced changes in proliferation and apoptosis in<br>human and mouse neuroprogenitor cells.<br><br>~~SS~~|Culbreth ME, Harrill JA, Freudenrich TM, Mundy WR,<br>Shafer TJ.<br><br>~~r~~|2012<br>|Não<br>~~r~~|  
55  
|Effect of intravenous fat emulsion therapy on glyphosate-surfactant-induced<br>cardiovascular collapse.<br><br><br>|You Y, Jung WJ, Lee MJ.<br><br>|2012<br><br><br>|Sim<br><br><br>|
|---|---|---|---|
|Cytotoxicity on human cells of Cry1Ab and Cry1Ac Bt insecticidal toxins alone<br>or with a**glyphosate**-based herbicide.<br>~~—————~~<br>~~C~~|Mesnage R, Clair E, Gress S, Then C, Székács A,<br>Séralini GE.<br>~~i~~<br>|2013<br><br><br>|Não<br><br>~~T~~|
|Cytotoxic and DNA-damaging properties of**glyphosate**and Roundup in<br>human-derived buccal epithelial cells.<br><br>~~————~~<br>|Koller VJ, Fürhacker M, Nersesyan A, Mišík M,<br>Eisenbauer M, Knasmueller S<br>~~——~~<br>~~SE~~<br><br>|2012<br><br><br><br>|Não<br><br>~~d~~<br><br>|
|Glyphosate-surfactant herbicide products containing glyphosatepotassium<br>salt can cause fatal hyperkalemia if ingested in massive amounts.<br>~~e~~|Kamijo Y, Mekari M, Yoshimura K, Kan'o T, Soma K.<br><br>~~e~~<br>|2012<br><br>|Sim<br><br>|
|Estimating maternal and prenatal**exposure**to**glyphosate**in the community<br>setting.<br><br>~~e~~<br>|McQueen H, Callan AC, Hinwood AL.<br><br><br>~~e~~<br>~~ee~~<br>|2012<br><br><br>|Não<br><br><br><br>|
|Developmental and reproductive outcomes in humans and animals<br>after glyphosate exposure: a critical analysis.<br>~~_S~~|Williams AL, Watson RE, DeSesso JM.<br><br>~~S~~|2012<br>|Sim<br>|
|Surfactant volume is an essential element in human toxicity in<br>acute glyphosate herbicide intoxication.<br><br>~~e~~|Seok SJ, Park JS, Hong JR, Gil HW, Yang JO, Lee EY,<br>Song HY, Hong SY.<br><br>~~s~~|2011<br><br>|Sim<br><br>|
|Mix-mode TiO-C18 monolith spin column extraction and GC-MS for the<br>simultaneous assay of organophosphorus compounds and glufosinate,<br>and**glyphosate**in human serum and urine.<br><br>~~e~~<br>|Saito T, Aoki H, Namera A, Oikawa H, Miyazaki S,<br>Nakamoto A, Inokuchi S.<br><br>~~s~~<br><br>|2011<br><br><br>|Não<br><br><br>|
|Epidemiologic studies of**glyphosate**and non-cancer health outcomes: a<br>review.<br>|Mink PJ, Mandel JS, Lundin JI, Sceurman BK.<br><br>|2011<br>|Não<br>|
|Baseline determination in social, health, and genetic areas in communities<br>affected by glyphosate aerial spraying on the northeastern Ecuadorian<br>border.<br>~~e~~|Paz-y-Miño C, Muñoz MJ, Maldonado A, Valladares C,<br>Cumbal N, Herrera C, Robles P, Sánchez ME, López-<br>Cortés A.<br><br>|2011<br>|Não<br>|
|Effects on aquatic and human health due to large scale bioenergy crop<br>expansion.<br><br>~~[~~<br>~~d~~|Love BJ, Einheuser MD, Nejadhashemi AP.<br><br><br>~~e~~<br>~~T~~<br>~~—OS—CSsT~~|2011<br><br><br>|Não<br><br>|  
56  
|The nephrologist as a consultant for acute poisoning: epidemiology of severe<br>poisonings in the State of Rio Grande do Sul and techniques to enhance<br>renal elimination.|Pedroso JA, Silva CA.|2010|Sim|
|---|---|---|---|
|Rapid determination of**glyphosate**, glufosinate, bialaphos, and their<br>major**metabolites**in serum by liquid chromatography-tandem mass<br>spectrometry using hydrophilic interaction chromatography.|Yoshioka N, Asano M, Kuse A, Mitsuhashi T, Nagasaki<br>Y, Ueno Y.|2011|Sim|
|Aseptic meningitis in association with glyphosate-surfactant<br>herbicide poisoning.|Sato C, Kamijo Y, Yoshimura K, Ide T.|2011|Sim|
|Parkinsonism after chronic occupational**exposure**to**glyphosate**.|Wang G, Fan XN, Tan YY, Cheng Q, Chen SD.|2011|Não|
|Maternal and fetal**exposure**to pesticides associated to genetically<br>modified foods in Eastern Townships of Quebec, Canada.|Aris A, Leblanc S.|2011|Não|
|Rapture of the large intestine caused by severe oral**glyphosate**-<br>surfactant**intoxication**.|Palli E, Makris D, Diakaki C, Garoufalis G, Zakynthinos<br>E.|2011|Sim|
|Analytical method for assessing potential dermal**exposure**to pesticides of a<br>non-agricultural occupationally exposed population.|Delhomme O, Raeppel C, Teigné D, Briand O, Millet<br>M.|2011|Não|
|Predicting acute complicated**glyphosate** **intoxication**in the emergency<br>department.|Moon JM, Chun BJ.|2010|Sim|
|Rhinitis associated with pesticide use among private pesticide applicators in<br>the agricultural health study.|Slager RE, Simpson SL, Levan TD, Poole JA, Sandler<br>DP, Hoppin JA.|2010|Sim|  
57  
|Glyphosate-surfactant herbicide-induced reversible encephalopathy.|Malhotra RC, Ghia DK, Cordato DJ, Beran RG.|2010|Sim|
|---|---|---|---|
|Systematic differences between healthcare professionals and poison<br>information staff in the severity scoring of pesticide exposures.|Adams RD, Gibson AL, Good AM, Bateman DN.|2010|Sim|
|Use of a lipid emulsion in a patient with refractory hypotension caused<br>by**glyphosate**-surfactant herbicide.|Han SK, Jeong J, Yeom S, Ryu J, Park S.|2010|Sim|
|Efficacy of skin wash on dermal absorption: an in vitro study on four model<br>compounds of varying solubility.|Nielsen JB.|2010|Sim|
|The poison pen: bedside diagnosis of urinary diquat.|Vohra R, Salazar A, Cantrell FL, Fernando R, Clark RF.|2010|Não|
|A prospective observational study of the clinical toxicology of glyphosate-<br>containing herbicides in adults with acute self-poisoning.|Roberts DM, Buckley NA, Mohamed F, Eddleston M,<br>Goldstein DA, Mehrsheikh A, Bleeke MS, Dawson AH.|2010|Sim|
|Morphological damages of a**glyphosate**-treated human keratinocyte cell line<br>revealed by a micro- to nanoscale microscopic investigation.|Elie-Caille C, Heu C, Guyon C, Nicod L.|2010|Sim|
|Identifying pesticide use patterns among flower growers to assess<br>occupational**exposure**to mixtures.|Schilmann A, Lacasaña M, Blanco-Muñoz J, Aguilar-<br>Garduño C, Salinas-Rodríguez A, Flores-Aldana M,<br>Cebrián ME.|2010|Não|
|**BUSCA PUBMED 2A**||||  
58  
|Severe Glyphosate-Surfactant Intoxication Successfully Treated With<br>Continuous Hemodiafiltration and Direct Hemoperfusion: Case Report.<br>~~o~~|Ozaki T, Sofue T, Kuroda Y.<br>~~o~~|2017<br>|REPETIDO<br>|
|---|---|---|---|
|Serum S100 protein could predict altered consciousness in glyphosate or<br>glufosinatepoisoning patients.<br><br>|Lee JW, Choi YJ, Park S, Gil HW, Song HY, Hong SY.<br><br>|2017<br><br>|REPETIDO<br><br>|
|Australian work exposures studies: occupational exposure to pesticides.<br><br>|Jomichen J, El-Zaemey S, Heyworth JS, Carey RN,<br>Darcey E, Reid A, Glass DC, Driscoll T, Peters S,<br>Abramson M,Fritschi L.<br><br><br>|2017<br><br>|REPETIDO<br><br>|
|Pesticides are Associated with Allergic and Non-Allergic Wheeze among Male<br>Farmers.<br>|Hoppin JA, Umbach DM, Long S, London SJ,<br>Henneberger PK, Blair A, Alavanja M, Freeman LE,<br>Sandler DP.<br><br>|2017<br>|REPETIDO<br>|
|Mechanism-specific injury biomarkers predict nephrotoxicity early<br>following glyphosate surfactant herbicide (GPSH) poisoning.<br>~~e~~|Mohamed F, Endre ZH, Pickering JW, Jayamanne S,<br>Palangasinghe C, Shahmy S, Chathuranga U,<br>Wijerathna T, Shihana F, Gawarammana I, Buckley<br>NA.<br><br>|2017<br>|REPETIDO<br>|
|Glyphosate and adverse pregnancy outcomes, a systematic review of<br>observational studies.<br><br>~~e~~<br>|de Araujo JS, Delgado IF, Paumgartten FJ.<br><br><br>~~e~~<br><br>|2016<br><br><br><br>|REPETIDO<br><br><br><br>|
|Prognostic Factors in Emergency Department Patients<br>with Glyphosate Surfactant Intoxication: Point-of-Care Lactate Testing.<br>~~e~~|Kim YH, Lee JH, Cho KW, Lee DW, Kang MJ, Lee KY,<br>Lee YH, Hwang SY, Lee NK.<br><br>~~e~~<br>~~es~~|2016<br><br>~~e~~|REPETIDO<br><br>|
|Intravenous lipid emulsion in treatment of cardiocirculatory disturbances<br>caused by glyphosate-surfactant herbicide poisoning.<br>~~————~~|Jović-Stošić J, Putić V, Perković-Vukčević N, Babić G,<br>Đorđević S, Šegrt Z.<br><br>~~——~~|2016<br> <br>|REPETIDO<br><br>~~—~~|
|Determination of glyphosate and its metabolite in emergency room in Korea.<br><br>|Han J, Moon H, Hong Y, Yang S, Jeong WJ, Lee KS,<br>Chung H.<br><br>|2016<br><br>|REPETIDO<br><br>|  
59  
|The role of L-type amino acid transporters in the uptake of glyphosate across<br>mammalian epithelial tissues.|Xu J, Li G, Wang Z, Si L, He S, Cai J, Huang J, Donovan<br>MD.|2016|REPETIDO|
|---|---|---|---|
|A multicenter retrospective survey of poisoning after ingestion of herbicides<br>containing<br>glyphosate potassium salt or other glyphosate salts in Japan.|Kamijo Y, Takai M, Sakamoto T.|2016|REPETIDO|
|The Biomarkers of Exposure and Effect in Agriculture (BEEA) Study: Rationale,<br>Design, Methods, and Participant Characteristics.|Hofmann JN, Beane Freeman LE, Lynch CF, Andreotti<br>G, Thomas KW, Sandler DP, Savage SA, Alavanja MC.|2015|REPETIDO|
|Analysis of Moms Across America report suggesting bioaccumulation<br>of glyphosate in U.S. mother's breast milk: Implausibility based on<br>inconsistency with available body of glyphosate animal toxicokinetic, human<br>biomonitoring, and physico-chemical data.|Bus JS.|2015|REPETIDO|
|Successful Extracorporeal Life Support in a Case of Severe Glyphosate-<br>Surfactant Intoxication.|Chan CW, Wu IL, Lee CH, Hsu SC, Liao SC.|2016|REPETIDO|
|Common Pesticides Used in Suicide Attempts Following the 2012 Paraquat<br>Ban in Korea.|Lee JW, Hwang IW, Kim JW, Moon HJ, Kim KH, Park S,<br>Gil HW, Hong SY.|2015|REPETIDO|
|Acute eosinophilic pneumonia associated with glyphosate-<br>surfactant exposure.|De Raadt WM, Wijnen PA, Bast A, Bekers O, Drent M.|2015|REPETIDO|
|Development of liquid chromatography methods coupled to mass<br>spectrometry for the analysis of substances with a wide variety of polarity in<br>meconium.|Meyer-Monath M, Chatellier C, Cabooter D, Rouget F,<br>Morel I, Lestremau F.|2015|REPETIDO|  
60  
|Clostridium tertium bacteremia in a patient with glyphosate ingestion.<br>|You MJ, Shin GW, Lee CS.<br>|2015<br>|REPETIDO<br>|
|---|---|---|---|
|Glyphosate-based herbicides potently affect cardiovascular system in<br>mammals: review of the literature.<br>|Gress S, Lemoine S, Séralini GE, Puddu PE.<br>|2015<br>|REPETIDO<br>|
|Glyphosate-rich air samples induce IL-33, TSLP and generate IL-13 dependent<br>airway inflammation.<br>|Kumar S, Khodoun M, Kettleson EM, McKnight C,<br>Reponen T, Grinshpun SA, Adhikari A.<br>|2014<br>|REPETIDO<br>|
|Esophageal perforation and death following glyphosate poisoning.<br>|Jyoti W, Thabah MM, Rajagopalan S, Hamide A.<br>|2014<br>|REPETIDO<br>|
|Effect of glyphosate on the sperm quality of zebrafish Danio rerio.<br>~~e~~|Lopes FM, Varela Junior AS, Corcini CD, da Silva AC,<br>Guazzelli VG, Tavares G, da Rosa CE.<br>|2014<br>|REPETIDO<br>|
|Unilateral hippocampal infarction associated with an attempted suicide: a<br>case report.<br>|Nishiyori Y, Nishida M, Shioda K, Suda S, Kato S.<br>|2014<br>|REPETIDO<br>|
|National toxicovigilance for pesticide exposures resulting in health care<br>contact-An example from the UK's National Poisons Information Service.|Perry L, Adams RD, Bennett AR, Lupton DJ, Jackson G,<br>Good AM, Thomas SH, Vale JA, Thompson JP,<br>Bateman DN, Eddleston M.|2014|REPETIDO|
|Methemoglobinemia associated with metaflumizone poisoning.|Oh JS, Choi KH.|2014|REPETIDO|
|Hemodialysis clearance of glyphosate following a life-threatening ingestion<br>of glyphosate-surfactant herbicide.<br>|Garlich FM, Goldman M, Pepe J, Nelson LS, Allan MJ,<br>Goldstein DA, Goldfarb DS, Hoffman RS.<br>|2014<br>|REPETIDO<br>|
|Heart rate-corrected QT interval predicts mortality in glyphosate-surfactant<br>herbicide-poisoned patients.<br>|Kim YH, Lee JH, Hong CK, Cho KW, Park YH, Kim YW,<br>Hwang SY.<br>|2014<br>|REPETIDO<br>|  
61  
|Effect of intravenous lipid emulsion in patients with<br>acute glyphosateintoxication.|Gil HW, Park JS, Park SH, Hong SY.|2013|REPETIDO|
|---|---|---|---|
|Exacerbation of symptoms in agricultural pesticide applicators with asthma.|Henneberger PK, Liang X, London SJ, Umbach DM,<br>Sandler DP, Hoppin JA.|2014|REPETIDO|
|Severe adverse effects related to dermal exposure to a glyphosate-surfactant<br>herbicide.|Mariager TP, Madsen PV, Ebbehøj NE, Schmidt B, Juhl<br>A.|2013|REPETIDO|
|Determination of glyphosate and AMPA in blood and urine from humans:<br>about 13 cases of acute intoxication.|Zouaoui K, Dulaurent S, Gaulier JM, Moesch C,<br>Lachâtre G.|2013|REPETIDO|
|Herbicide roundup intoxication: successful treatment with continuous renal<br>replacement therapy.|Hour BT, Belen C, Zar T, Lien YH.|2012|REPETIDO|
|Effect of intravenous fat emulsion therapy on glyphosate-surfactant-induced<br>cardiovascular collapse.|You Y, Jung WJ, Lee MJ.|2012|REPETIDO|
|Glyphosate-surfactant herbicide products containing glyphosatepotassium<br>salt can cause fatal hyperkalemia if ingested in massive amounts.|Kamijo Y, Mekari M, Yoshimura K, Kan'o T, Soma K.|2012|REPETIDO|
|Developmental and reproductive outcomes in humans and animals<br>after glyphosate exposure: a critical analysis.|Williams AL, Watson RE, DeSesso JM.|2012|REPETIDO|  
62  
|Surfactant volume is an essential element in human toxicity in<br>acute glyphosate herbicide intoxication.|Seok SJ, Park JS, Hong JR, Gil HW, Yang JO, Lee EY,<br>Song HY, Hong SY.|2011|REPETIDO|
|---|---|---|---|
|Baseline determination in social, health, and genetic areas in communities<br>affected by glyphosate aerial spraying on the northeastern Ecuadorian<br>border.|Paz-y-Miño C, Muñoz MJ, Maldonado A, Valladares C,<br>Cumbal N, Herrera C, Robles P, Sánchez ME, López-<br>Cortés A.|2011|REPETIDO|
|The nephrologist as a consultant for acute poisoning: epidemiology of severe<br>poisonings in the State of Rio Grande do Sul and techniques to enhance<br>renal elimination.|Pedroso JA, Silva CA.|2010|REPETIDO|
|Aseptic meningitis in association with glyphosate-surfactant<br>herbicide poisoning.|Sato C, Kamijo Y, Yoshimura K, Ide T.|2011|REPETIDO|
|Glyphosate-surfactant herbicide-induced reversible encephalopathy.|Malhotra RC, Ghia DK, Cordato DJ, Beran RG.|2010|REPETIDO|
|Systematic differences between healthcare professionals and poison<br>information staff in the severity scoring of pesticide exposures.|Adams RD, Gibson AL, Good AM, Bateman DN.|2010|REPETIDO|
|Efficacy of skin wash on dermal absorption: an in vitro study on four model<br>compounds of varying solubility.|Nielsen JB.|2010|REPETIDO|
|The poison pen: bedside diagnosis of urinary diquat.|Vohra R, Salazar A, Cantrell FL, Fernando R, Clark RF.|2010|REPETIDO|  
63  
|A prospective observational study of the clinical toxicology of glyphosate-|Roberts DM, Buckley NA, Mohamed F, Eddleston M,|2010|REPETIDO|
|---|---|---|---|
|containing herbicides in adults with acute self-poisoning.|Goldstein DA, Mehrsheikh A, Bleeke MS, Dawson AH.|||
|Morphological damages of a**glyphosate**-treated human keratinocyte cell line<br>revealed by a micro- to nanoscale microscopic investigation.|Elie-Caille C, Heu C, Guyon C, Nicod L.|2010|REPETIDO|  
64  
**Quadro III.3.2.** Concordância de inserção dos Artigos resultantes da busca sistemática no site **Cochrane Library** , para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|**Cochrane**||||
|---|---|---|---|
|**BUSCA 1C (2 resultados)**||||
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|Effect of intravenous lipid emulsion inpatients with acuteglyphosate intoxication|HW Gil,JS Park,SH Park,SY Hong|2013|REPETIDO|
|Mechanism-specific injury biomarkers predict nephrotoxicity early<br>following glyphosate surfactant herbicide (GPSH) poisoning|Mohamed F1, Endre ZH2, Pickering JW3, Jayamanne<br>S4, Palangasinghe C4, Shahmy S4, Chathuranga<br>U4, Wijerathna T4, Shihana F4, Gawarammana I4, Buckley<br>NA5.|2016|REPETIDO|
|Chemical treatment at degraded sandy grassland of San Luis, Argentina: effects on<br>vegetation|ST Rosa, MJL Privitello, O Vetore, A Panza, EG Gabutti, OM<br>Ruiz, EF Bacha, GI Cozzarin, J Leporati, G Tirenti|2016|Não|
|Impact of mechanical mowing and chemical treatment on phytosociological,<br>pedochemical and biological parameters in roadside soils and vegetation|E Pellegrini, L Falcone, S Loppi, G Lorenzini, C Nali|2016|Não|
|Pesticide risk behaviors and factors influencing pesticide use amongfarmers in Kuwait|MFA Jallow,DG Awadh,MS Albaho,VY Devi,BM Thomas|2017|Não|  
65  
**Quadro III.3.3** Concordância de inserção dos Artigos resultantes da busca sistemática no site **Lilacs- BVS** , para as perguntas PICO de Diagnóstico do Capítulo 3 - Glifosato.  
|**LILACS**<br>||||
|---|---|---|---|
|**BUSCA 2a**<br><br>||||
|La vigilancia de las intoxicaciones en Argentina y en América Latina. Notificación,<br>análisis y gestión de eventos / Surveillance of poisoning in Argentina and Latin<br>America. Reporting, analysis and event management<br>~~e~~|García, Susana Isabel.<br><br>~~ee~~|2016<br>|Não<br>|
|**Pancreatitis Aguda Tóxica por Glifosato: A propósito de un caso / Glyphosate toxic**<br>**for acute pancreatitis: Report of a case**<br><br>|González, Eliana; Zuramay, Carmen; Clavo, María<br>Luisa; Arriaga, Adriana; Pérez, Honey.<br><br><br><br>~~ee~~|2014<br><br>|Sim<br><br><br>~~ee~~|
|**BUSCA 2b**<br><br><br>||||
|Behavioral effects of acute glyphosate exposure in male and female Balb/c mice /<br>Efeitos comportamentais da exposição aguda ao gliposato em camundongos Balb/c<br>machos e fêmeas<br>~~e~~<br>~~es~~<br>|Joaquim, Andréia de Oliveira; Spinosa, Helenice de<br>Souza; Macrini, Daclé Juliane; Rodrigues, Paula<br>Andreotti; Ricci, Esther Lopes; Artiolli, Thais<br>Spaggiari; Moreira, Natália; Suffredini, Ivana<br>Barbosa;Bernardi,Maria Martha.<br><br>~~ee~~<br><br>|2012<br>|Não<br>|
|Pancreatitis Aguda Tóxica por Glifosato: A propósito de un caso / Glyphosate toxic for<br>acute pancreatitis: Report of a case<br><br>|González, Eliana; Zuramay, Carmen; Clavo, María<br>Luisa; Arriaga, Adriana; Pérez, Honey.<br><br><br>|2014|REPETIDO|
|La vigilancia de las intoxicaciones en Argentina y en América Latina. Notificación,<br>análisis y gestión de eventos / Surveillance of poisoning in Argentina and Latin<br>America. Reporting,analysis and event management<br><br>~~es~~|García, Susana Isabel.<br><br>~~Gs~~<br>~~ee~~|2016|REPETIDO|  
66  
|**BUSCA 2c**||||
|---|---|---|---|
|O nefrologista como consultor ante a intoxicação aguda: epidemiologia das<br>intoxicações graves no Rio Grande do Sul e métodos de aumento da depuração renal /<br>The nephrologist as a consultant for acute poisoning: epidemiology of severe<br>poisonings in the State of Rio Grande do Sul and techniques to enhance renal<br>elimination|Pedroso, José Alberto Rodrigues; Silva, Carlos<br>Augusto Mello da.|2010|REPETIDO|  
**Quadro III.3.4.** Concordância de inserção dos Artigos resultantes da busca sistemática no portal **Pubmed,** para as perguntas PICO de Tratamento do Capítulo 3 - Glifosato.  
||**PUBMED**||||
|---|---|---|---|---|
|**Busca**<br>**1A**|**Artigo**|**Autores**|**Ano**|**Estudo**<br>**considerado**|
||Severe Glyphosate-Surfactant Intoxication Successfully<br>Treated With Continuous Hemodiafiltration and Direct<br>Hemoperfusion: Case Report.|Ozaki T, Sofue T, Kuroda Y.|2017|SIM|
||The health consequences of aerial spraying illicit crops:<br>The case of Colombia.|Camacho A, Mejía D.|2017|SIM|
||AminoMethylPhosphonic acid (AMPA) in natural waters:<br>Its sources,behavior and environmental fate.|Grandcoin A, Piel S, Baurès E.|2017|NÃO|  
67  
|Is it time to reassess current safety standards<br>for glyphosate-based herbicides?|Vandenberg LN, Blumberg B,<br>Antoniou MN, Benbrook CM, Carroll<br>L, Colborn T, Everett LG, Hansen M,<br>Landrigan PJ, Lanphear BP, Mesnage<br>R, Vom Saal FS, Welshons WV,<br>Myers JP.|2017|NÃO|
|---|---|---|---|
|Serum S100 protein could predict altered consciousness<br>in glyphosateor glufosinate poisoning patients.|Lee JW, Choi YJ, Park S, Gil HW, Song<br>HY, Hong SY.|2017|NÃO|
|Organophosphorus Xenobiotic Toxicology.|Casida JE.|2017|NÃO|
|Efficiency control of dietary pesticide intake reduction by<br>human biomonitoring.|Göen T, Schmidt L, Lichtensteiger W,<br>Schlumpf M.|2017|NÃO|
|Prognostic Factors in Emergency Department Patients<br>with Glyphosate Surfactant Intoxication: Point-of-Care<br>Lactate Testing.|Kim YH, Lee JH, Cho KW, Lee DW,<br>Kang MJ, Lee KY, Lee YH, Hwang SY,<br>Lee NK.|2016|SIM|
|Intravenous lipid emulsion in treatment of<br>cardiocirculatory disturbances caused by glyphosate-<br>surfactant herbicide poisoning.|Jović-Stošić J, Putić V, Perković-<br>Vukčević N, Babić G, Đorđević S,<br>Šegrt Z.|2016|SIM (não<br>disponí-vel)|
|Systematic review of the effect of intravenous lipid<br>emulsion therapyfor non-local anesthetics toxicity.|Levine M, Hoffman RS, Lavergne V,<br>Stork CM, Graudins A, Chuang R,<br>Stellpflug SJ, Morris M, Miller-<br>Nesbitt A, Gosselin S; Lipid Emulsion<br>Workgroup.|2016|SIM|  
68  
|Successful Extracorporeal Life Support in a Case of<br>Severe Glyphosate-Surfactant Intoxication.|Chan CW, Wu IL, Lee CH, Hsu SC,<br>Liao SC.|2016|SIM|
|---|---|---|---|
|The role of ions, heavy metals, fluoride, and<br>agrochemicals: critical evaluation of potential aetiological<br>factors of chronic kidney disease of multifactorial origin<br>(CKDmfo/CKDu)and recommendations for its eradication.|Wimalawansa SJ.|2016|SIM|
|Common Pesticides Used in Suicide Attempts Following<br>the 2012 Paraquat Ban in Korea.|Lee JW, Hwang IW, Kim JW, Moon<br>HJ, Kim KH, Park S, Gil HW, Hong SY.|2015|NÃO|
|Aminomethylphosphonic acid and methoxyacetic acid<br>induce apoptosis in prostate cancer cells.|Parajuli KR, Zhang Q, Liu S, You Z.|2015|NÃO (in vitro)|
|Development of liquid chromatography methods coupled<br>to mass spectrometry for the analysis of substances with<br>a wide variety of polarity in meconium.|Meyer-Monath M, Chatellier C,<br>Cabooter D, Rouget F, Morel I,<br>Lestremau F.|2015|NÃO|
|Global transcriptomic profiling demonstrates induction of<br>oxidative stress and of compensatory cellular stress<br>responses in brown trout exposed to glyphosate and<br>Roundup.|Uren Webster TM, Santos EM.|2015|NÃO|
|Clostridium tertium bacteremia in a patient<br>with glyphosate ingestion.|You MJ, Shin GW, Lee CS.|2015|SIM|
|Glyphosate-rich air samples induce IL-33, TSLP and<br>generate IL-13 dependent airway inflammation.|Kumar S, Khodoun M, Kettleson EM,<br>McKnight C, Reponen T, Grinshpun<br>SA,Adhikari A|2014|NÃO|  
69  
|Unilateral hippocampal infarction associated with an<br>attempted suicide: a case report.|Nishiyori Y, Nishida M, Shioda K,<br>Suda S, Kato S.|2014|NÃO|
|---|---|---|---|
|Chaetoglobosins from Chaetomium globosum, an<br>endophytic fungus in Ginkgo biloba, and their phytotoxic<br>and cytotoxic activities.|Li H, Xiao J, Gao YQ, Tang JJ, Zhang<br>AL, Gao JM.|2014|NÃO|
|Methemoglobinemia associated with<br>metaflumizone poisoning.|Oh JS, Choi KH.|2014|NÃO|
|Glyphosate commercial formulation causes cytotoxicity,<br>oxidative effects, and apoptosis on human cells:<br>differences with its active ingredient.|Chaufan G, Coalova I, Ríos de Molina<br>Mdel C.|2014|NÃO|
|Hemodialysis clearance of glyphosate following a life-<br>threatening ingestion of glyphosate-surfactant herbicide.|Garlich FM, Goldman M, Pepe J,<br>Nelson LS, Allan MJ, Goldstein DA,<br>Goldfarb DS, Hoffman RS.|2014|SIM|
|Effect of intravenous lipid emulsion in patients with<br>acute glyphosateintoxication.|Gil HW, Park JS, Park SH, Hong SY.|2013|SIM|
|Procedures to evaluate the efficiency of protective<br>clothing worn by operators applying pesticide.|Espanhol-Soares M, Nociti LA,<br>Machado-Neto JG.|2013|Não|
|Specific pesticide-dependent increases in α-synuclein<br>levels in human neuroblastoma (SH-SY5Y) and melanoma<br>(SK-MEL-2) cell lines.|Chorfa A, Bétemps D, Morignat E,<br>Lazizzera C, Hogeveen K, Andrieu T,<br>Baron T.|2013|NÃO|  
70  
|Severe adverse effects related to dermal exposure to<br>a glyphosate-surfactant herbicide.|Mariager TP, Madsen PV, Ebbehøj<br>NE, Schmidt B, Juhl A.|2013|SIM|
|---|---|---|---|
|Determination of glyphosate and AMPA in blood and<br>urine from humans: about 13 cases of acute intoxication.|Zouaoui K, Dulaurent S, Gaulier JM,<br>Moesch C, Lachâtre G.|2013|SIM|
|Evaluation of developmental toxicity studies<br>of glyphosate with attention to cardiovascular<br>development.|Kimmel GL, Kimmel CA, Williams AL,<br>DeSesso JM.|2013|SIM|
|Accidental chemical burns of oral mucosa by herbicide.|Deo SP, Shetty P.|2012|SIM|
|Diurnal variation in probability of death following self-<br>poisoning in Sri Lanka--evidence for chronotoxicity<br>in humans.|Carroll R, Metcalfe C, Gunnell D,<br>Mohamed F, Eddleston M.|2012|SIM|
|Herbicide roundup intoxication: successful treatment with<br>continuous renal replacement therapy.|Hour BT, Belen C, Zar T, Lien YH.|2012|SIM|
|Effect of intravenous fat emulsion therapy on glyphosate-<br>surfactant-induced cardiovascular collapse.|You Y, Jung WJ, Lee MJ.|2012|SIM|
|Surfactant volume is an essential element in human<br>toxicity in acute glyphosate herbicide intoxication.|Seok SJ, Park JS, Hong JR, Gil HW,<br>Yang JO, Lee EY, Song HY, Hong SY.|2011|SIM|
|The nephrologist as a consultant for acute poisoning:<br>epidemiologyof severepoisonings in the State of Rio|Pedroso JA, Silva CA.|2010|SIM|  
71  
||Grande do Sul and techniques to enhance renal<br>elimination.||||
|---|---|---|---|---|
||Aseptic meningitis in association with glyphosate-<br>surfactant herbicide poisoning.|Sato C, Kamijo Y, Yoshimura K, Ide T.|2011|SIM|
||Rapture of the large intestine caused by severe<br>oral glyphosate-surfactant intoxication.|Palli E, Makris D, Diakaki C,<br>Garoufalis G, Zakynthinos E.|2011|SIM|
||Predicting acute complicated glyphosate intoxication in<br>the emergency department.|Moon JM, Chun BJ.|2010|SIM|
||Use of a lipid emulsion in a patient with refractory<br>hypotension caused by glyphosate-surfactant herbicide.|Han SK, Jeong J, Yeom S, Ryu J, Park<br>S.|2010|Sim|
||Efficacy of skin wash on dermal absorption: an in vitro<br>study on four model compounds of varying solubility.|Nielsen JB.|2010|Sim|
||A prospective observational study of the clinical<br>toxicology of glyphosate-containing herbicides in adults<br>with acute self-poisoning.|Roberts DM, Buckley NA, Mohamed<br>F, Eddleston M, Goldstein DA,<br>Mehrsheikh A, Bleeke MS, Dawson<br>AH.|2010|Sim|
||Morphological damages of a glyphosate-treated human<br>keratinocyte cell line revealed by a micro- to nanoscale<br>microscopic investigation.|Elie-Caille C, Heu C, Guyon C, Nicod<br>L.|2010|Não|
|**BUSCA 1B**|||||  
72  
|Mechanism-specific injury biomarkers predict<br>nephrotoxicity early<br>following glyphosate surfactant herbicide<br>(GPSH) poisoning.|Mohamed F, Endre ZH, Pickering JW,<br>Jayamanne S, Palangasinghe C,<br>Shahmy S, Chathuranga U,<br>Wijerathna T, Shihana F,<br>Gawarammana I, Buckley NA.|2016|SIM|
|---|---|---|---|
|Glyphosate surfactant herbicide poisoning and<br>management.|Mahendrakar K, Venkategowda PM,<br>Rao SM,Mutkule DP.|2014|SIM|
|Heart rate-corrected QT interval predicts mortality<br>inglyphosate-surfactant herbicide-poisonedpatients.|Kim YH, Lee JH, Hong CK, Cho KW,<br>Park YH,Kim YW,HwangSY.|2014|SIM|
|Pathological and toxicological findings in glyphosate-<br>surfactant herbicide fatality: a case report.|Sribanditmongkol P, Jutavijittum P,<br>Pongraveevongsa P, Wunnapuk K,<br>Durongkadech P.|2012|SIM|
|Surfactant volume is an essential element<br>in human toxicity in<br>acuteglyphosateherbicide intoxication.|Seok SJ, Park JS, Hong JR, Gil HW,<br>Yang JO, Lee EY, Song HY, Hong SY.|2011|REPETIDO|
|Glyphosate poisoning.|Bradberry SM, Proudfoot AT, Vale<br>JA.|2004|SIM – Indispon.|  
**Quadro III.3.5.** Concordância de inserção dos Artigos resultantes da busca sistemática no portal **Cochrane Library** , para as perguntas PICO de Tratamento do Capítulo 3 - Glifosato.  
|**Busca 2A**|||||
|---|---|---|---|---|
||Effect of intravenous lipid emulsion in patients with|Gil HW , Park JS , Park SH and|2013|SIM|
||acuteglyphosate intoxication|HongSY|||  
73  
|Mechanism-specific injury biomarkers predict nephrotoxicity<br>early following glyphosate surfactant herbicide (GPSH)<br>poisoning|Toxicology letters. 258 (pp 1-10),<br>2016.|2016|SIM|
|---|---|---|---|
|Chemical treatment at degraded sandy grassland of San Luis,<br>Argentina: effects on vegetation|Rosa ST , Privitello MJL , Vetore O<br>, Panza A , Gabutti EG , Ruiz OM ,<br>Bacha EF , Cozzarin GI , Leporati J<br>and Tirenti G|2017|NÃO|
|Impact of mechanical mowing and chemical treatment on<br>phytosociological, pedochemical and biological parameters<br>in roadside soils and vegetation|Pellegrini E , Falcone L , Loppi S ,<br>Lorenzini G and Nali C|2016|NÃO|
|Complex interactive effects of water mold, herbicide, and<br>the fungus Batrachochytrium dendrobatidis on Pacific<br>treefrog Hyliola regilla hosts|Romansic JM , Johnson JE ,<br>Wagner RS , Hill RH , Gaulke CA ,<br>Vredenburg VT and Blaustein AR|2017|NÃO|
|Pesticide risk behaviors and factors influencing pesticide use<br>among farmers in Kuwait|Jallow MFA , Awadh DG , Albaho<br>MS , Devi VY and Thomas BM|2017|NÃO|  
**Quadro III.3.6** Concordância de inserção dos Artigos resultantes da busca sistemática no portal **Lilacs- BVS** , para as perguntas PICO de Tratamento do Capítulo 3 - Glifosato.  
74  
|**Busca**<br>**3A**|**Título**|**Autores**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|---|
||Efeito protetor da melatonina sobre intoxicações por herbicidas /<br>Protective effect of melatonin on poisoning by herbicides|Almeida, Lécio L. de; Teixeira, Álvaro A.<br>C.; Bezerra, Natallyanea S; Wanderley-<br>Teixeira, Valéria.|2016|SIM|
||Acute toxicity and sublethal effects of the mixture glyphosate<br>(Roundup® Active) and Cosmo-Flux®411F to anuran embryos and<br>tadpoles of four Colombian species / Toxicidad aguda y efectos<br>subletales de la mezcla glifosato (Roundup® Activo) y Cosmo-<br>Flux®411F en embriones y renacuajos de cuatro especies de<br>anuros colombianos|Henao Muñoz, Liliana Marcela; Montes<br>Rojas, Claudia Marsela; Bernal Bautista,<br>Manuel Hernando.|2014|NÃO|
||Chromatographic analysis and antiproliferative potential of<br>aqueous extracts of Punica granatum fruit peels using the Allium<br>cepa test|Kuhn, Andrielle Wouters; Tedesco,<br>Marília; Boligon, Aline Augusti; Athayde,<br>Margareth Linde; Laughinghouse IV,<br>Haywood Dail; Tedesco, Solange Bosio.|2015|NÃO|
||Efeito genotóxico e antiproliferativo de Mikania cordifolia (L. F. )<br>Willd. (Asteraceae) sobre o ciclo celular de Allium cepa L /<br>Antiproliferative and genotoxic effects of Mikania cordifolia (LF)<br>Willd. (Asteraceae) on the cell cycle of Allium cepa L|Dias, M.G.; Canto-Dorow, T.S.; Coelho,<br>A.P.D.; Tedesco, S.B..|2014|NÃO|
||Parâmetros fisiológicos e nutricionais de cultivares de soja<br>resistentes ao glifosato em comparação com cultivares isogênicas<br>próximas / Physiological and nutritional evaluation of soybean<br>resistant to glyphosate in comparison with near isogenic lines|Wagner, Juliano Fuhrmann; Merotto<br>Junior, Aldo.|2014|NÃO|  
75  
|Behavioral effects of acute glyphosate exposure in male and<br>female Balb/c mice / Efeitos comportamentais da exposição<br>aguda ao gliposato em camundongos Balb/c machos e fêmeas|Joaquim, Andréia de Oliveira; Spinosa,<br>Helenice de Souza; Macrini, Daclé<br>Juliane; Rodrigues, Paula Andreotti; Ricci,<br>Esther Lopes; Artiolli, Thais<br>Spaggiari; Moreira, Natália; Suffredini,<br>Ivana Barbosa; Bernardi, Maria Martha.|2012|NÃO|
|---|---|---|---|
|Intellectual property rights related to the genetically modified<br>glyphosate tolerant soybeans in Brazil|Rodrigues, Roberta L; Lage, Celso L.<br>S; Vasconcellos, Alexandre G.|2011|NÃO|
|O nefrologista como consultor ante a intoxicação aguda:<br>epidemiologia das intoxicações graves no Rio Grande do Sul e<br>métodos de aumento da depuração renal / The nephrologist as a<br>consultant for acute poisoning: epidemiology of severe<br>poisonings in the State of Rio Grande do Sul and techniques to<br>enhance renal elimination|Pedroso, José Alberto Rodrigues; Silva,<br>Carlos Augusto Mello da.|2010|SIM|
|Produtividade de grãos da soja em função do manejo de<br>herbicida e fungicidas / Soybean grain yield in response to<br>herbicide and fungicides|Ludwig, Marcos Paulo; Dutra, Luiz Marcelo<br>Costa; Lucca Filho, Orlando Antônio; Zabot,<br>Lucio; Uhry, Daniel; Lisboa, Juliano Irion.|2010|NÃO|
|In vitro effect of the herbicide glyphosate on human blood<br>platelet aggregation and coagulation / Efeito in vitro do herbicida<br>glifosato na agregação plaquetária e coagulação sanguínea em<br>humanos|Neiva, Teresinha de Jesus C; Moraes, Ana<br>Carolina R; Schwyzer, Rafaella; Vituri,<br>Cidônia de Lourdes; Rocha, Tania Rubia<br>F; Fries, Diana M; Silva, Márcio<br>A;Benedetti,Aloisio Luiz.|2010|NÃO|  
76

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
**ANEXO III.4**  
**Quadro III.4. 1** Síntese evidências capítulo de Prevenção – buscas sistemáticas  
77

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|**REFERÊNCIA**|**DELINEAM.**|**PICO**|**DESFECHO**|**TIPO DE**<br>**SINTOMAS/**<br>**ANÁLISES**|**EVIDÊNCIAS DO ARTIGO**|
|---|---|---|---|---|---|
|Rodrigues e Souza, 2018|Não é escopo|||Não disponível|Resíduo em alimentos feitos com base em soja – não é escopo|
|Mills et al. 2018|Estudo de coorte|-|Não avaliado<br>desfechos<br>clínicos|Análise urina –<br>glifosato e<br>AMPA –<br>população não<br>agrícola|Os pesquisadores mediram os níveis de excreção de glifosato e seu<br>metabólito ácido aminometilfosfônico (AMPA) em participantes do<br>estudo sobre envelhecimento saudável “Rancho Bernardo Study<br>(RBS)”.<br>A coorte foi estabelecida em 1972, e envolveu 6629 adultos com<br>mais de 50 anos residentes no sul da Califórnia. A partir de 2016,<br>aproximadamente 1.000 participantes estavam ativos (a principal<br>razão para a perda de seguimento foi a mortalidade). Desses 1.000<br>participantes, 112 tinham coleta de urina de rotina, obtidas em<br>cada uma das 5 consultas clínicas ocorridas de 1993 a 1996 e de<br>2014 a 2016. Cem desses 112 foram selecionados aleatoriamente<br>para este estudo. A análise de urina foi feita para glifosato e AMPA,<br>por cromatografia líquida e espectrometria de massa. Entre os 100<br>participantes deste estudo, a idade média em 2014-2016 foi de<br>77,7 anos (DP+6,6) e 60% eram mulheres.<br>Limites de detecção (LOD) foram 0,03 μg / L para o glifosato e 0,04<br>μg / L para o AMPA.|  
78  
|A concentração média de glifosato aumentou de 0,024 μg/L em<br>1993-1996 para 0,314 μg/L em 2014-2016 e atingiu 0,449 μg/L em<br>2014-2016 para os 70 participantes com níveis acima do Limite<br>detectável. Os níveis médios de AMPA aumentaram de 0,008 μg / L<br>em 1993-1996 para 0,285 μg / L em 2014-2016 e atingiram 0,401<br>μg / L em 2014-2016 para os 71 participantes com níveis acima do<br>detectável.|
|---|
|As taxas de prevalência de amostras de glifosato acima do limite<br>detectável aumentaram significativamente ao longo do tempo, de<br>0,120 (95% CI, 0,064-0,200) em 1993-1996 para 0,700 (IC 95%,<br>0,600-0,788) em 2014-2016 (estatística de Wald = 80,5; P <0,001).<br>A prevalência de amostras AMPA acima do limite detectável<br>aumentou significativamente de 0,050 (95% CI, 0,016-0,113) em<br>1993-1996 para 0,710 (IC 95%, 0,611-0,796) em 2014-2016<br>(estatística de Wald = 103; P < 0,001).|
|As limitações deste estudo incluem que a amostra da coorte viveu<br>no sul da Califórnia, que pode ter diferentes exposições do que<br>outros estados, apenas um subconjunto de participantes da coorte<br>foi estudado, os níveis urinários representam exposição recente, a<br>gravidade específica urinária é reduzida com a idade e a clínica não<br>|
|foi avaliada.**Mas esse estudo deve ser considerado para**<br>**acompanhar futuros efeitos crônicos do glifosato e AMPA.**|  
79  
|Stephenson et al, 2017|Análise de risco<br>baseada em<br>dados<br>secundários<br>(Reino Unido)|-|Não é escopo|Este documento faz uma avaliação abrangente da exposição<br>alimentar de curto prazo ao glifosato a partir de culturas<br>potencialmente tratadas cultivadas na UE e em fontes alimentares<br>importadas de outros países.<br>**Conflitos**: O trabalho foi financiado pela Força Tarefa de Glifosato<br>(www.glyphosate.eu) baseado na indústria – é um consórcio de<br>indústrias que juntam esforços para renovar o registo europeu do<br>glifosato.|
|---|---|---|---|---|
|Connolly<br>et al, 2017|Caso-controle<br>Período: Junho a<br>outubro 2015 -<br>Irlanda|5<br>Contaminação<br>urinária|Glifosato e<br>fluroxipir em<br>monitoramento<br>urinário|Um total de 80 amostras foram analisadas – 40 antes da exposição<br>e aplicação dos agrotóxicos e 40 amostras pós-exposição. Foram<br>17 participantes, 1 mulher e 17 homens, idade entre 33 a 66 anos.<br>Haviam 4 formas de aplicação similares do agrotóxico: com<br>equipamento pressurizado, com o uso de mochila de aplicação,<br>aplicador de gotas manual e bomba spray. A coleta de urina pós-<br>exposição foi feita até 1h após a tarefa ser cumprida.<br>Das pré-amostras coletadas, 58% (23 amostras) estavam abaixo do<br>limite de detecção (LOD) e das amostras de pós 43% (17 amostras)<br>estavam abaixo do LOD.<br>Quase todas as concentrações pós-exposição foram maiores do que<br>as concentrações nas amostras pré-exposição, no entanto, todos os<br>níveis pós-exposição foram baixos. Não havia dado de<br>biomonitoramento humano disponível para a população irlandesa,<br>sendo esse estudopioneiro nesse tema. A média aritméticageral|  
80  
|||||ajustada, da concentração de amostras de urina pré-tarefa para a<br>exposição por glifosato, foi de 0,71µg/L+0,92 (Desvio Padrão-DP)<br>com valor mínimo de 0,13µg/L e máximo de 3,43µg/L. Para as<br>amostras pós-exposição, a média aritmética foi de 1,35µg/L+2,18<br>(DP), com valor mínimo de 0,12µg/L e máximo de 10,66µg/L.<br>Houve uma diferença estatisticamente significante entre o log<br>ajustado pré e pós teste total (teste t pareado, p <0,001). Em relação<br>às diferenças de grupos, não houve diferença estatística entre as<br>concentrações pré testes entre os grupos, assim como pós-teste<br>(p=0,38). Todos os grupos se comportaram de forma similar.<br>As exposições pareciam ser dependentes do tempo de amostragem<br>e os níveis eram mais altos entre os trabalhadores que faziam<br>pausas ou executavam tarefas mais longas. Os autores discutem que<br>a estratégia de amostragem pontual, em até 1h da exposição,<br>provavelmente subestima o potencial de exposição. Tempos de<br>amostragem inferiores a 24h não permitem tempo suficiente para a<br>absorção e excreção de pesticidas, particularmente quando a pele é<br>a via dominante de exposição.|
|---|---|---|---|---|
|Ozaki et al, 2017|Relato de Caso|1, 2,<br>6|Tratamento|Uma mulher de 65 anos ingeriu 100 mL de glifosato-surfactante<br>(GlySH) acidentalmente e chamou uma ambulância após 5h da<br>ingestão.<br>A dopamina foi administrada para hipotensão não responsiva à<br>ressuscitação com fluidos, e o manejo da ventilação foi iniciado para|  
81  
||||||tratar hipoxemia devido a edema pulmonar. Cinquenta gramas de<br>carvão ativado e 200 mL de sorbitol foram administrados por sonda<br>nasogástrica e a hemodiafiltração contínua (CHDF) foi iniciada para<br>tratar a acidose metabólica progressiva.**Como considerou-se a**<br>**intoxicação do surfactante como a principal causa de seus**<br>**sintomas, começou-se a hemoperfusão direta (DHP),**usando<br>Medisorba DHP (Kawasumi Lab. Inc., Tóquio, Japão), em paralelo<br>com o CHDF para remover o surfactante. De fato, a hipotensão e a<br>acidose metabólica progressiva melhoraram imediatamente após o<br>início da DHP. Após 2 h de DHP, o tratamento foi interrompido<br>devido à eficácia clínica. O volume de urina aumentou no segundo<br>dia, o CHDF foi interrompido no terceiro dia. Seu curso clínico foi<br>bom e ela foi transferida para um hospital de reabilitação 28 dias<br>após a admissão.<br>Esse caso refere-se a uma paciente com intoxicação grave por GlySH<br>que foi tratada com sucesso com uma combinação de DHP e CHDF<br>para remover o surfactante e o glifosato, respectivamente.|
|---|---|---|---|---|---|
|Rendon-von Osten et al,<br>2017|Transversal<br>(México)|5|Monitoramento|Análise urinária<br>de glifosato|O objetivo deste estudo foi determinar os níveis de glifosato em<br>amostras de água subterrânea, água potável engarrafada e na<br>urina de agricultores de subsistência em diferentes comunidades<br>ao redor do município de Hopelchén, Campeche.<br>Foram coletadas no total, 81 amostras de urina de agricultores de<br>subsistência, das regiões de Ich-Ek (IE), Francisco J Mújica (FJM),|  
82  
||||||Suc-Tuc (SF-ST), San Juan Bautista Sahcabchén (SJB-S) e Crucero<br>San Luis (CSL) - México, e oito amostras de urina de pescadores da<br>cidade de Campeche, consideradas como local de referência.<br>Região de FJM apresentou as amostras com maior concentração<br>média de glifosato (análise por ELISA), de 0,47µg/L, enquanto que<br>as amostras controles (pescadores), tiveram concentração média de<br>0,22µg/L (p<0,05).|
|---|---|---|---|---|---|
|Kawagashira et al 2017<br>(Vasculitic Neuropathy<br>Following Exposure to a<br>Glyphosate-based<br>Herbicide.)|Relato de Caso<br>(Japão)|1, 2|Morbidade|Neuropatia<br>vasculítica|Um homem de 70 anos foi internado no hospital com queixas de<br>dormência moderada e leve fraqueza na porção distal de todas as<br>extremidades.<br>Ele havia pulverizado aproximadamente 2.000 mL de Roundup®<br>em seus campos de arroz por várias horas sem usar luvas de<br>proteção ou máscara facial, 4 meses antes da admissão no<br>hospital. Embora ele tenha usado anteriormente herbicidas à base<br>de glifosato várias vezes, essa foi a primeira vez que ele lidou com<br>uma quantidade tão grande sem a proteção de luvas ou de uma<br>máscara facial. No dia seguinte, a dor na sola do pé esquerdo<br>subitamente se desenvolveu, subsequentemente se espalhando<br>para o lado oposto e aumentando em gravidade. Houve dormência<br>da porção distal dos membros inferiores. A dormência nos<br>membros inferiores progrediu para áreas proximais em poucos<br>dias, e fraqueza muscular nos pés apareceu, predominantemente<br>no lado direito. Dormência bilateral das mãos apareceu cerca de|  
83  
|duas semanas a partir do início da dor na sola esquerda e<br>gradualmente subiu. Ele perdeu a capacidade de andar sozinho e<br>começou a usar uma cadeira de rodas um mês depois. Dano<br>hepático e renal foram notados em outro hospital e ele recebeu<br>tratamento sintomático.|
|---|
|O exame físico revelou livedo reticular da pele nas solas bilaterais e<br>edema dos membros inferiores. O exame neurológico revelou<br>distúrbio sensitivo grave nas mãos e porção distal dos membros<br>inferiores. Fraqueza leve nas extremidades inferiores foi<br>observada, predominantemente no lado direito, mas não foi<br>observada atrofia muscular. Os reflexos tendinosos profundos<br>estavam normais, exceto pelos reflexos bilaterais ausentes no<br>tendão de Aquiles. Não houve anormalidades nos nervos cranianos<br>ou no sistema nervoso autônomo.|
|Um exame laboratorial revelou leve elevação da contagem de<br>leucócitos (9.900 / mm3), dos quais 3% eram eosinófilos. Embora<br>as velocidades de condução nervosa motora (VCMs) nos nervos<br>mediano direito e ulnar estivessem na faixa normal de 48 e 51 m /<br>s, respectivamente, os potenciais de ação muscular composta<br>(CMAPs) no nervo mediano foram reduzidos para 2,9 mV,<br>enquanto do nervo ulnar era normal. A biópsia do nervo sural<br>revelou a infiltração de linfócitos ao redor de pequenos vasos no|  
84  
|||||epineuro com numerosos eosinófilos, deposição de<br>hemossiderinas e degeneração axonal focal, compatível com os<br>achados de neuropatia vasculítica.<br>Após a admissão, a prednisolona oral foi administrada na dose de<br>30 mg/dia por 1 mês e reduzida a 5 mg a cada 2 semanas. Após o<br>tratamento com prednisolona, a dormência e fraqueza muscular<br>do paciente melhoraram gradativamente.|
|---|---|---|---|---|
|Kongtip et al, 2017|Estudo<br>longitudinal<br>(Tailândia)<br>|-<br>Monitoramento<br>soro e níveis<br>glifosato|Monitoramento<br>níveis glifosato<br>soro materno e<br>cordão umbilical|O estudo envolveu a medição de concentrações de glifosato e<br>paraquat encontradas em soro materno e de cordão umbilical em<br>82 mulheres grávidas que deram à luz em três províncias da<br>Tailândia.<br>As concentrações de glifosato no soro da gestante no parto<br>(mediana 17,5; intervalo 0,2-189,1 ng/ml) foram significativamente<br>maiores (p <0,007) do que no soro do cordão umbilical (mediana<br>0,2, faixa 0,2-94,9 ng/ml).<br>Mulheres com níveis de glifosato><br>LOD no soro no parto teve 11,9 vezes mais chances de relatar o<br>trabalho como agricultor (p <0,001), 3,7 vezes mais chances de<br>viver perto de áreas agrícolas (p = 0,006), e 5,9 vezes mais chances<br>de ter um membro da família que trabalhou em agricultura (p<br><0,001).|  
85  
|Lee et al., 2017|Estudo<br>longitudinal<br>prospectivo<br>(República da<br>Coréia)|1,2, 4|Morbidade|Neurológico|O estudo envolveu 40 pacientes (23 intoxicações por glifosato e 17<br>intoxicações por glufosinato).<br>Dividiram os pacientes em dois grupos: (1) nenhum grupo de<br>características neurológicas e (2) grupo de características<br>neurológicas. Durante a internação, observaram de perto sintomas<br>como a consciência alterada (coma, semi coma) e convulsão como<br>características neurológicas. Para as medições da S100B, amostras<br>de sangue venoso (5cc) foram tomadas na admissão hospitalar. A<br>média de idade foi de 54,7 anos.<br>Entre os 40 pacientes, “hipotensão” foi encontrada em três casos,<br>“insuficiência respiratória” foi encontrada em 12 casos, “consciência<br>alterada” (estupor, coma semi) foi encontrada em 12 casos, e<br>“apreensão” foi relatada em 6 casos (todos os quais tinham<br>alteração da consciência). As características neurológicas foram<br>observadas em 12 pacientes. Verificaram-se mudanças da S100B em<br>três casos. Nestes três casos, a S100B pode ter atingido o pico na<br>admissão do paciente. As concentrações séricas de S100B medidas<br>na admissão foram maiores no grupo com características<br>neurológicas do que no grupo sem características neurológicas<br>[0,148 ug/L (IQR 0,128–0,248) vs. 0,072ug/L (IQR 0,047–0,084),<br>p<0,001].|
|---|---|---|---|---|---|  
86  
|||||**Para os pesquisadores, S100B foi um preditor significativo de**<br>**complicações neurológicas em pacientes com envenenamento por**<br>**glifosato e glufosinato**.|
|---|---|---|---|---|
|Casida, 2017|Revisão narrativa|||Não é escopo, faz uma revisão sobre as estruturas bioquímicas e<br>farmacologia dos organofosforados.|
|Göen et al., 2017|Estudo caso-<br>controle<br>(conduzido na<br>Suíça, 2015)<br>-|Monitoramento|Monitoramento<br>dietas –<br>dosagem<br>urinária<br>glifosato|No estudo,**dois**indivíduos adultos foram mantidos em uma dieta<br>convencional por 11 dias e coletou-se urina da manhã nos últimos<br>quatro dias do período. Posteriormente, os participantes passaram<br>a consumir exclusivamente alimentos orgânicos por 18 dias e, da<br>mesma forma, amostras de urina da manhã foram coletadas nos<br>últimos quatro dias desse período.<br>Nas amostras de urina foram quantificados seis metabólitos<br>piretróides, seis dialquilfosfatos, quatro parâmetros fenólicos para<br>agrotóxicos organofosforados e carbamatos, ácido 6-<br>cloronicotínico (ClNA) como parâmetro para inseticidas<br>neonotropóides, sete herbicidas fenoxi, glifosato e AMPA.<br>As análises comparativas revelaram níveis mais elevados dos<br>parâmetros nas amostras coletadas durante o período de dieta<br>comum em comparação com o período da dieta orgânica.|  
87  
||||||As diferenças foram estatisticamente significativas para DMP, DEP,<br>cis-Cl2 CA, trans-Cl2 CA, PBA e TCPy em ambos os indivíduos, e<br>para DMTP, DETP, ClNA, 2,4-D, 2,4,5-T, diclorprop, tricloprop e<br>glifosato em um indivíduo pelo menos.<br>O presente estudo confirmou que uma intervenção de dieta<br>orgânica resulta em menor exposição considerável a agrotóxicos<br>organofosforados e piretróides. Também verifica a experiência<br>anterior de que o monitoramento de parâmetros urinários para<br>agrotóxicos não persistentes permite um controle de eficiência<br>confiável de efeitos de curto prazo por meio de intervenções<br>dietéticas.|
|---|---|---|---|---|---|
|Vandenberg et al 2017|Revisão narrativa<br>-||Discussão de<br>efeitos crônicos<br>e laboratoriais|Não é escopo|Os herbicidas à base de glifosato (GBHs) são sempre usados como<br>uma mistura de glifosato e inúmeros outros ingredientes<br>chamados “inertes”, que são adicionados para alterar as<br>propriedades físico-químicas do herbicida e aumentar sua ação.<br>Infelizmente, a lista completa desses produtos químicos,<br>coletivamente conhecidos como adjuvantes ou coformulantes, é<br>tratada como um segredo comercial pelos fabricantes; a<br>composição dos GBHs é desconhecida e os dados disponíveis sobre<br>os perigos apresentados pelas diferentes misturas permanecem<br>limitados.|  
88  
||||Os GBHs mostraram ser mais tóxicos que o glifosato. Portanto,<br>estudos que analisam apenas o glifosato podem ter efeitos muito<br>diferentes dos estudos que analisam os GBHs.<br>A decisão do grupo de trabalho da Agência Internacional de<br>Pesquisa sobre o Câncer (IARC), em 2015, de classificar o glifosato<br>como provável carcinógeno humano de grau 2A seguiu uma<br>extensa revisão e avaliação do peso de todas as evidências<br>disponíveis.<br>A falta de dados de biomonitoramento e estudos epidemiológicos<br>permanecem como importantes lacunas nos dados.|
|---|---|---|---|
|Conrad et al, 2017|Estudo de análise<br>laboratorial<br>(Alemanha)|Monitoramen-to<br>glifosato e<br>AMPA<br>Biomonitora-<br>mento urinário|Foram analisadas amostras de urina de 24h, crio-arquivadas pelo<br>_German Environmental Specimen Bank_(ESB). Amostras foram<br>coletadas em 2001, 2003, 2005, 2007, 2009, 2011, 2012, 2013, 2014<br>e 2015 e foram escolhidas para o estudo retrospectivo. Amostra foi<br>composta por 388 amostras de urina (200 homens e 199 mulheres,<br>com idade entre 20 e 29 anos). Todas as amostras de urina foram<br>coletadas de pessoas que vivem em Greifswald, uma cidade no<br>nordeste da Alemanha, e que não possuíssem restrições<br>alimentares.<br>Das 399 amostras de urina analisadas, 127 (=31,8%) continham<br>concentrações de glifosato que atingiram ou excederam o Limite de|  
89  
|Detecção (LOQ) mínimo de 0,1 g/L. Para o AMPA, esse foi o caso<br>para 160 (= 40,1%) de todas as amostras. A fração de amostras igual<br>ou superior ao LOQ variou significativamente ao longo dos anos<br>investigados, tanto para o glifosato (p≤0,001) quanto para o AMPA<br>(p = 0,005). Os anos com as maiores taxas de quantificação foram<br>2012 (57,5%) e 2013 (56,4%), para o glifosato e em 2009 e 2012 para<br>o AMPA.|
|---|
|As concentrações de glifosato e AMPA na urina foram<br>estatisticamente correlacionadas (coeficiente de correlação de<br>spearman rS = 0,506, p ≤ 0,001). Ao calcular os coeficientes de<br>correlação separadamente para cada ano de estudo, os níveis de<br>glifosato e AMPA se correlacionaram estatisticamente de forma<br>significativa em todos os anos, exceto nos dois primeiros, 2001 e<br>2003.|
|As concentrações de glifosato e AMPA na urina foram<br>negativamente correlacionadas com o volume da amostra de urina<br>(rS = −0.278 e −0.327) e positivamente correlacionadas com os<br>níveis urinários de creatinina (rS = 0.347 e 0.373).<br>Os níveis urinários de glifosato e AMPA tenderam a ser mais altos<br>no sexo masculino. A possível redução na exposição desde 2013<br>indicada pelos dados da ESB pode ser devido a mudanças na<br>aplicação do glifosato na prática agrícola. O ESB continuará|  
90  
||||||monitorando as exposições internas ao glifosato e ao AMPA para<br>acompanhar a tendência temporal.|
|---|---|---|---|---|---|
|Cristoni et al., 2017|Não é escopo|||Análise de<br>algoritmo em<br>espectrometria<br>de massa|O grupo introduziu o estudo de um novo algoritmo na plataforma<br>SANIST para identificar com precisão os compostos que atendem<br>às regras da União Europeia (UE) (Diretiva 2002/657 / EC da UE)<br>em exemplos de estudos forenses, farmacêuticos e de análise de<br>alimentos.|
|Hoppin et al, 2017|Caso-controle<br>(EUA)|5|Detecção de<br>casos de<br>intoxicação por<br>grupos<br>toxindromes|Sintomas<br>respiratórios e<br>asma, sibilância<br>alérgica|Utilizando os dados da entrevista de 2005-2010 do Agricultural<br>Health Study (EUA), um estudo prospectivo de agricultores na<br>Carolina do Norte e Iowa. Avaliou-se a associação entre sibilos<br>alérgicos e não-alérgicos e uso autorreferido de 78 pesticidas<br>específicos, relatados por ≥ 1 % dos 22.134 homens entrevistados.<br>Houve detecção de: Sibilância alérgica (n=1,310), com OR(95%IC)=<br>1.56 (1.19, 2.03) Sibilância não alérgica (n= 3,939), com<br>OR(95%IC)= 1.24 (1.07, 1.44), o que acarreta um valor de p=0,120|
|Mohamed et al, 2016|Coorte<br>prospectiva<br>(local do estudo:<br>Sri Lanka)|5|Mortalidade|Biomarcadores<br>urinários e<br>séricos de<br>nefrotoxicidade|Os pesquisadores exploraram a utilidade de um painel de<br>biomarcadores para diagnosticar a nefrotoxicidade induzida pelo<br>herbicida glifosato com surfactante (GPSH), em humanos, em<br>estudo entre 2010 e 2014.|  
91  
|Em um estudo observacional prospectivo multicêntrico, amostras<br>seriais de sangue e urina de 90 pacientes com intoxicação por<br>GPSH, foram coletadas até a alta do paciente e durante o<br>acompanhamento.|
|---|
|A ingestão de GPSH foi confirmada com base em histórias retiradas<br>de pacientes ou familiares ou pelas embalagens/ recipientes /<br>rótulo trazidos com os pacientes ou em notas de transferência<br>médica de hospitais periféricos.|
|Seis biomarcadores de lesão renal aguda (LRA) foram quantificados<br>simultaneamente, por meio de kit de ensaio: cistatina C urinária<br>(uCysC), albumina (uAlb), fator trifólio 3 (uTFF3), osteopontina<br>(uOstP), beta-2-microglobulina (uB2M) e lipocalina associada a<br>gelatinase neutrofílica (uNGAL), além de creatinina sérica (sCr) e<br>urinária, interleucina-18 urinária, citocromoC e cistatina sérica.|
|O desempenho diagnóstico de cada biomarcador foi avaliado em<br>vários momentos. A LRA funcional foi definida e categorizada em<br>estágios de gravidade com base no aumento da creatinina sérica<br>(sCr) utilizando os critérios da Rede de Lesões Renais Agudas<br>(_Acute Kidney Injury Network_- AKIN). Eles consideraram pacientes<br>sintomáticos da intoxicação por glifosato, os pacientes que<br>desenvolveram toxicidade ao glifosato (náuseas, vômitos, ardor na<br>boca e garganta, diarreia, dor abdominal, sedação, ulceração da<br>cavidade bucal e esofagite – de acordo com Roberts et al., 2010).|  
92  
|De 90 pacientes sintomáticos, 51% desenvolveram LRA e 5<br>pacientes que desenvolveram AKIN>2, morreram.|
|---|
|Nenhum dos 10 biomarcadores urinários estudados aumentou<br>significativamente em pacientes que não desenvolveram LRA ou<br>tiveram leve score (AKIN 1); a maioria desses pacientes também<br>apresentou apenas toxicidade clínica menor. As concentrações<br>absolutas de cistatina C sérica e urinária, interleucina-18 urinária<br>(IL-18), citocromo C (CytoC) e NGAL aumentaram muitas vezes em<br>8h, em pacientes que desenvolveram AKIN>2. As concentrações<br>máximas de 8h e 16 h destes biomarcadores mostraram um<br>excelente desempenho diagnóstico (AUC-ROC>0,8) para<br>diagnosticar AKIN>2. No entanto, apenas a CytoC urinária<br>acrescentou utilidade diagnóstica à sCr às 8h e 16 h; diminuindo o<br>risco médio de diagnóstico errado em 8h por 0,14 (0,03-0,25) entre<br>aqueles que não tinham AKI>2.|
|**Os autores concluem que a creatinina sérica continua sendo um**<br>**bom marcador de nefrotoxicidade na intoxicação por GPSH.**A<br>cistatina C sérica pode ser uma alternativa útil à creatinina sérica<br>após intoxicação por GPSH. Os biomarcadores de lesões<br>estruturais, particularmente a IL-18 urinária e o uCytoC, foram<br>úteis na confirmação de possíveis vias mecanísticas de<br>nefrotoxicidade induzida por GPSH. A confirmação dos<br>biomarcadores testados será útil em futuros ensaios clínicos.|  
93  
|Kwiatkowska et al., 2016|**In vitro**<br>**Não é escopo**|||
|---|---|---|---|
|Moon et al., 2016 (The<br>characteristics of emergency<br>department presentations<br>related to acute herbicide or<br>insecticide**poisoning**in<br>South Korea between 2011<br>and 2014.)|Estudo descritivo<br>longitudinal<br>(Coréia do Sul)<br>-<br>-|Não é escopo|O objetivo deste estudo foi examinar dados epidemiológicos sobre<br>intoxicação aguda por herbicidas ou inseticidas em adultos de 2011<br>a 2014 em nível nacional na Coreia do Sul.<br>Os dados de vigilância foram obtidos do “Korea Center for Disease<br>Control and Prevention”. Todos os 20 departamentos de<br>emergência, onde os dados foram coletados, estão localizados em<br>hospitais terciários afiliados à universidade.<br>Dos 20.907 adultos (>18 anos), foram selecionadas as intoxicações<br>por herbicidas e inseticidas, representadas pelo total de 3.800<br>casos. A taxa total de casos fatais devido ao envenenamento por<br>herbicidas ou inseticidas, em adultos, na Coréia do Sul foi de 16,8%<br>durante 2011-2014. No entanto, a taxa diminuiu significativamente<br>ao longo do período de 4 anos. De 2011 a 2013, intoxicação por<br>paraquat foi a principal causa das apresentações na emergência,<br>seguida pelo glifosato e organofosforados. As apresentações em<br>pronto atendimentos por envenenamento por paraquat<br>diminuíram significativamente, enquanto o envenenamento<br>causado por glifosato, glufosinato ou herbicidas combinados|  
94  
|||||aumentou significativamente, ao longo dos 4 anos.|
|---|---|---|---|---|
|Kim et al, 2016|Coorte<br>retrospectiva|5, 6|Mortalidade<br>após ingestão<br>glifosato com<br>surfactante<br>Lactato sérico|O artigo analisou a relação entre os níveis de lactato e mortalidade<br>por envenenamento por**surfactante com glifosato**. Esta análise<br>retrospectiva envolveu 232 pacientes que foram internados no<br>departamento de emergência após intoxicação por surfactante com<br>glifosato entre janeiro de 2004 e junho de 2014 – Coreia do Sul. O<br>lactato tem sido usado para predizer a gravidade da doença e o risco<br>de mortalidade em muitos processos, incluindo intoxicações, sepse,<br>cirurgia, queimaduras e trauma. A concentração elevada de lactato<br>sérico é uma manifestação simples de disfunção orgânica. Na<br>prática, a determinação dos níveis circulantes de lactato é<br>tecnicamente viável, comumente usada e clinicamente disponível.<br>O estudo sugere que alguns fatores de risco independentes devem<br>ser avaliados assim que os pacientes chegam à emergência com a<br>ingestão de surfactante de glifosato.**A saber, lactato sanguíneo e**<br>**ECG: estes podem ajudar o médico a identificar pacientes que**<br>**provavelmente progredirão para um estado crítico durante o**<br>**tratamento inicial da intoxicação por surfactante com glifosato.**<br>Os níveis de lactato, bem como a idade, o intervalo QTc (ECG) e os<br>níveis de potássio, estão associados à mortalidade em 30 dias em<br>pacientes com intoxicação aguda por surfactante com glifosato.|  
95

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
No presente estudo, a diferença no nível de potássio entre os grupos alto e baixo-lactato não foi clinicamente significativa; no entanto, a diferença entre os casos fatais e não fatais foi significativa (fatal: 4,8 ± 1,4 mmol / L; não fatal ± 4,0 ± 0,5 mmol / L; p <0,001). Especificamente, pacientes com nível de lactato> 4,7 mmol/L apresentaram um risco três vezes maior de mortalidade em até 30 dias do que outros pacientes durante o acompanhamento. O lactato foi significativamente maior em não-sobreviventes (6,5 ± 3,1 mmol / L) do que em sobreviventes (3,3 ± 2,2 mmol / L; p <0,001), e o lactato elevado foi significativamente associado com mortalidade em 30 dias. O intervalo QTc foi significativamente maior em nãosobreviventes [529 ms (498-563 ms)] do que em sobreviventes [461 ms (437- 480 ms); p <0,001]. 50% dos pacientes que desenvolveram hipercalemia morreram, e encontraram dois pacientes nos quais o produto ingerido continha sal de potássio glifosato. Quando os pacientes ingerem uma grande quantidade de glifosato com surfactante contendo sal de potássio, os médicos devem considerar a possibilidade de hipercalemia. McGuire et al., 2016 Estudo - Monitoramento, Monitoramento Procurou-se determinar se o glifosato e seu metabólito AMPA. transversal (EUA) Morbidade Urina e leite poderiam ser detectados no leite e na urina produzidos por materno - mulheres lactantes. glifosato  
96

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|||||Foram coletadas amostras de leite (n = 41) e urina (n = 40) de<br>mulheres lactantes saudáveis que moravam em Moscou, Idaho e<br>Pullman, Washington (EUA).<br>A análise, que foi sensível a 1 mg/L para ambos os elementos, não<br>detectou nem o glifosato nem o AMPA em nenhuma amostra de<br>leite de mulheres lactantes.<br>Já o glifosato foi detectável em quase todas as amostras de urina (n<br>= 37) e quantificável em 29 delas.<br>**Conflito de interesse: alguns autores da pesquisa receberam**<br>**financiamento irrestrito de pesquisa de US$ 10.000 da Monsanto**<br>**para outros estudos.**|
|---|---|---|---|---|
|Jović-Stošić et al., 2016|Não disponível||||
|Han et al., 2016|Transversal|3|Glifosato –<br>dosagem no<br>sangue|Amostras de sangue adquiridas de cinco pacientes intoxicados com<br>glifosato foram analisadas para investigar a correlação entre a<br>concentração de glifosato e os sintomas clínicos. Esses pacientes<br>foram previamente admitidos no pronto-socorro de um hospital<br>universitário na Coréia, após a auto ingestão de glifosato em<br>tentativas de suicídio ou por acidente.|  
97  
|A quantidade estimada de glifosato ingerida foi de 300 mL no caso|
|---|
|1, 200 mL no caso 2, 180 mL no caso 3, 400 mL no caso 4 e 50 mL|
|no caso 5. A idade variou entre 47 e 82 anos e a coleta de amostras<br>de sangue foi realizada entre 2-5h após a ingestão. Esta<br>quantidade estimada de ingestão de glifosato para cada caso não|
|foi consistente com a concentração de glifosato no sangue.|
|De acordo com os resultados, as concentrações de glifosato<br>mostraram grande variação entre os casos (1,0-171,1 ug/mL),<br>enquanto a diferença na concentração de AMPA foi relativamente<br>pequena na faixa de 0,2- 2,6 ug / mL|
|**Todos os cinco casos deste estudo foram categorizados com**<br>**sintomas leves e moderados. No entanto, esta classificação**|
|**baseada na concentração de glifosato não pôde explicar**<br>**completamente os sintomas clínicos relatados pelo prontuário.**|
|Por exemplo, o paciente do caso 2 apresentou sintomas de vômito,|
|dor de garganta e acidose metabólica. Houve intubação, mas o<br>paciente morreu pelo avanço de distúrbios respiratórios|
|(respiratory distress syndrome). Além disso, o paciente do caso 4<br>apresentou sintomas de vômitos e acidose metabólica e,<br>posteriormente, foi diagnosticado com pneumonia. Este paciente|
|foi tratado com antibióticos sob os cuidados da UTI.|
|Nestes dois casos, as concentrações sanguíneas foram de 171,1 e<br>105,0 mg / mL, respectivamente, que se enquadram nos níveis|  
98  
||||||entre leve e moderado. Como conclusão, a comparação entre a<br>concentração de glifosato e a dosagem administrada não mostrou<br>a correlação, o que sugere uma investigação mais aprofundada<br>sobre os efeitos dos surfactantes no glifosato de diferentes<br>fornecedores.|
|---|---|---|---|---|---|
|Kamijo et al., 2016|Pesquisa<br>multicêntrica<br>retrospectiva|1, 2,<br>6|Morbidade por<br>intoxicação por<br>glifosato|Sinais e<br>sintomas|Pesquisa conduzida no Japão para identificar diferenças nos<br>sintomas e no resultado da intoxicação por ingestão de glifosato<br>(levantamento dos casos aconteceu entre 2006 a 2014).<br>Um dos grupos analisado ingeriu produtos com Glifosato-<br>surfactante contendo sal de potássio (grupo GlyK+) - Entre esses 55<br>pacientes, 53 ingeriram Roundup Maxload® (Nissan Chemical<br>Industries Ltd. contendo 48% de GlyK+) e dois ingeriram Touchdown<br>IQ (Syngenta Japão KK, Tóquio, Japão; contendo 43% GlyK+) .<br>O outro grupo, chamado de Grupo-O, era composto de 62<br>indivíduos, onde 56 pessoas ingeriram produtos que continham 41%<br>de sal de isopropilamina de glifosato; um deles ingeriu um produto<br>contendo sal de isopropilamina de glifosato a 10%; e cinco,<br>ingeriram produtos contendo 41% de sal de glifosato de amônio.<br>Analisou-se também a presença de lesão pulmonar aguda (ALI),<br>lesão renal aguda (AKI) e lesão hepática (LI).|  
99  
|Não houve diferenças demográficas significativas entre os dois|
|---|
|grupos. Os níveis séricos de potássio foram significativamente<br>maiores (p<0.01) e ECG anormal incluindo duração prolongada do<br>QRS, intervalo QT prolongado, pico da onda T, arritmia (por<br>exemplo, taquicardia ventricular [VT]) e condução elétrica anormal<br>(por exemplo, bloqueio atrioventricular), significativamente mais<br>comum (p<0.01) no grupo K+. O desenvolvimento de ALI (p=0.05) e<br>LI (p<0.01) foi significativamente mais comum no grupo O, e uma<br>tendência não significativa para mais casos de ALI foi observada no<br>grupo O.|
|No grupo K+, a maioria dos pacientes apresentou função renal<br>normal na admissão. Assim, os níveis de potássio sérico|
|significativamente mais elevados observados em pacientes do<br>grupo K+ em relação a pacientes do grupo O podem sugerir que a<br>causa mais provável de hipercalemia foi uma ingestão excessiva de<br>potássio de produtos contendo GlyK+. Produtos típicos de Glifosato-<br>surfactante que contêm isopropilamina de glifosato ou sais de<br>amônio também contêm POEA como surfactante, tóxico para<br>mamíferos. No presente estudo, o desenvolvimento de ALI e LI|
|durante a internação hospitalar foi muito mais comum no grupo O.<br>Houve também uma tendência não significativa de aumento da<br>incidência de AKI no grupo O. Estes resultados indicam que os|  
100  
||||||surfactantes usados em produtos contendo GlyK+ podem<br>representar um menor risco de lesão em órgãos como os pulmões,<br>fígado e rins.<br>A ingestão de produtos contendo GlyK+ e outros surfactantes além<br>do POEA pode resultar em hipercalemia grave, que pode levar a<br>arritmias fatais ou parada cardíaca, e pode exigir terapia de<br>substituição renal imediata, como a hemodiálise. Os médicos<br>também devem estar cientes de que a ingestão de produtos<br>contendo isopropilamina de glifosato ou sais de amônio e POEA<br>pode resultar em lesões graves nos órgãos.|
|---|---|---|---|---|---|
|Chan et al., 2016|Relato de Caso|1,<br>Trat.|Morbidade por<br>intoxicação<br>aguda|Sinais e<br>Sintomas,<br>Oxigenação por<br>membrana<br>extracorpórea e<br>hemodiálise|Um homem de 47 anos (Taiwan) ingeriu aproximadamente 100mL<br>de surfactante glifosato 1,5 horas antes. Inicialmente, o paciente<br>estava sonolento com escore de Glasgow de 13 (E3M6V4), vômito<br>e diaforético. Os sinais vitais na chegada do departamento de<br>emergência foram os seguintes: pressão arterial, 143 / 91mm Hg;<br>pulso, 72 batimentos / min; respiração, 20 respirações / min; e<br>temperatura, 36°C. O exame físico mostrava úlceras orais,<br>salivação excessiva, crepitações difusas na ausculta do tórax e<br>achados pouco notáveis para o coração, abdome, órgãos genitais e<br>reto. O eletrocardiograma revelou um QRS largo com duração de<br>134 ms e prolongado**QTc de 550ms**. Apresentou insuficiência|  
101  
|||respiratória, taquicardia ventricular persistente, choque profundo<br>refratário a agentes inotrópicos e acidose metabólica desenvolvida<br>no paciente em até 2 horas. A gasometria após a intubação revelou<br>acidose metabólica persistente.<br>Foi aplicada uma oxigenação por**membrana extracorpórea**<br>venoarterial (VA-ECMO) iniciada 3 horas após a admissão, porque<br>hipotensão profunda persistente foi observada após a<br>administração de agente duplo inotrópico (norepinefrina, 10<br>μg/kg/min e dopamina 8 μg/kg/min). A hemodiálise venovenosa<br>contínua também foi aplicada em simultâneo com ECMO. A<br>condição do paciente melhorou consideravelmente. Conclusões:<br>Com base nessa pesquisa, este foi o primeiro caso em que a<br>oxigenação por membrana extracorpórea foi usada para tratar a<br>intoxicação grave por glifosato-surfactante. Recomendamos o<br>início precoce da terapia de oxigenação por membrana<br>extracorpórea para mitigar o comprometimento cardiopulmonar<br>em pacientes com intoxicação por surfactante com glifosato.|
|---|---|---|
|Mesnage et al., 2015<br>(Potential toxic effects<br>of**glyphosate**and its<br>commercial formulations<br>below regulatory limits.)|Revisão narrativa<br>(França)|Uma revisão narrative bem conduzida, porém, os estudos e<br>discussões levantados são, majoritariamente, a partir de estudos<br>experimentais com ratos ou linhagens celulares.|  
102  
|De Raadt et al., 2015|Relato de Caso<br>(Holanda, Países<br>Baixos)<br>1,2|Morbidade|Pneumonia|Trata-se de um caso de uma paciente do sexo feminino, 31 anos,<br>que desenvolveu pneumonia eosinofílica aguda (PEA) após recente<br>início de tabagismo e exposição extensiva desprotegida ao<br>glifosato-surfactante.<br>Alguns dias antes do início dos sintomas a paciente havia entrado<br>em contato, sem proteção, a herbicidas contendo glifosato-<br>surfactante (Roundup, provavelmente 41% glifosato<br>isopropilamina + 15,4 % polioxietileno-neamina (POEA).|
|---|---|---|---|---|
|||||Apresentou febre (39°C), hipóxia grave e desconforto respiratório,<br>não respondendo aos antibióticos. A radiografia de tórax mostrou<br>infiltrados bilaterais mal definidos, predominantemente nas zonas<br>pulmonares média e baixa. A tomografia computadorizada de alta<br>resolução realizada posteriormente mostrou áreas foscas de vários<br>lóbulos secundários periféricos e espessamento de septos<br>interlobulares. Além disso, uma pequena quantidade de derrame<br>pleural bilateral estava presente. A análise de gasometria arterial<br>revelou uma PaO2 de 6,7 kPa em repouso.<br>Estavam aumentados: taxa de sedimentação eritrocitária de 53<br>mm/h, proteína C reativa (PCR) 230 mg/l, lactato desidrogenase<br>549 U/l (<250/L). A contagem total de glóbulos brancos e<br>eosinófilos estavam dentro dos limites normais.|  
103  
||||||A análise de diferenciação de células do líquido do lavado<br>broncoalveolar mostrou um nível aumentado de eosinófilos (45%<br>do total de células). Nenhuma bactéria foi detectada.|
|---|---|---|---|---|---|
|Kier 2015|Revisão narrative<br>Não é escopo||Revisão|Biomonitora-<br>mento – estudo<br>crônico|Revisão sobre biomonitoramento e genoticidade - estudo crônico|
|You et al., 2015|Relato de Caso  -<br>República da<br>Coreia|1, 2,<br>4|Morbidade|Sinais, sintomas,<br>anamnese, co-<br>infecçãp|Mulher em tentativa de suicídio, ingeriu 20 mL de glifosato. Doze<br>dias após a tentativa de suicídio, a paciente apresentou febre alta e<br>mialgia geral. Devido a seus sintomas, ela visitou a sala de<br>emergência. Naquela época, a pressão arterial era de 80/60 mmHg,<br>o pulso era de 70/min, a taxa de respiração era de 18/min e a<br>temperatura era de 38,0°C.<br>Estudos laboratoriais revelaram contagem leucocitária de 2010 / ml,<br>nível de hemoglobina de 14,2 g / dl, contagem plaquetária de 80 000<br>/ ml, creatinina sérica de 3,59 mg / dl, nível de aspartato<br>aminotransferase de 2428 UI/L, nível de alanina amino transferase<br>de 1213 UI / l, nível de bilirrubina total de 0,30 mg/dL, nível de hs-<br>CRP de**20,77 mg/L**, e nível de PCT de**1,08 ng/ml**.<br>A análise urinária revelou pyuria (piúria) (contagem de leucócitos><br>30/HPF). Além disso,a tomografia computadorizada(TC)de alta|  
104  
||||||resolução do tórax revelou broncopneumonia aguda no lobo<br>inferior esquerdo. A antibioticoterapia inicial incluiu cefepima e<br>azitromicina por 8 dias. No entanto, a febre persistiu, o nível de hs-<br>CRP aumentou abruptamente para**107,49 mg/L**, e o nível de PCT<br>aumentou para**3,53 ng/ml**durante o tratamento com antibióticos.<br>**_C. tertium_ foi isolada das amostras de sangue iniciais de um cateter**<br>**central.**Os antibióticos foram alterados para ertapenem e<br>metronidazol. Após 16 dias de antibioticoterapia adequada, seus<br>sintomas e sinais clínicos desapareceram completamente e ela<br>recebeu alta.<br>Não está claro se o_C. tertium_foi um contaminante ou um<br>verdadeiro patógeno. No entanto, o paciente tinha um fator de risco<br>definido para bacteremia por_C. tertium_como uma complicação da<br>ingestão de glifosato. A ingestão de glifosato pode ser um fator<br>predisponente para a patogênese da bacteremia por C. tertium.|
|---|---|---|---|---|---|
|Gress et al., 2015|Revisão<br>Narrativa|1, 2,<br>5|Morbidade|Sinais e<br>sintomas,<br>glifosato no<br>sangue|Informações relevantes: A determinação do plasma é um pré-<br>requisito essencial para a avaliação de risco na intoxicação por GBH.<br>Somente quando ECGs padrão foram realizados, pelo menos um<br>ECG anormal foi detectado na grande maioria dos casos após<br>intoxicação. Prolongamento do QTc (ECG) e arritmias junto com<br>bloqueio atrioventricular de primeiro grau foram observados após<br>intoxicação por GBH.<br>Em estudo reportado de Taiwan (1991):|  
105

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
|A exposição acidental foi assintomática após contato dérmico com<br>spray (6 casos), enquanto o desconforto oral leve ocorreu após a|
|---|
|ingestão acidental (13 casos). A ingestão intencional (80 casos)|
|resultou em erosão do trato gastrintestinal (66%), disfagia (31%) e|
|hemorragia gastrointestinal (8%). Outros órgãos foram menos|
|afetados (pulmão 23%, fígado 19%, sistema cardiovascular 18%, rim<br>14% e sistema nervoso central 12%). Houve sete mortes, todas|
|ocorridas horas após a ingestão; duas ocorreram antes do paciente<br>chegar ao hospital. As mortes após a ingestão de Roundup foram|
|devidas a uma síndrome que envolvia hipotensão, não responsiva a<br>fluidos intravenosos ou drogas vasopressoras e, às vezes, edema<br>pulmonar, na presença de pressão venosa central normal. Este foi o<br>|
|primeiro relato em que os sintomas cardiovasculares foram|
|relatados após a ingestão de Roundup. No entanto, o ECG não foi<br>realizado e as arritmias não foram documentadas.<br>|
|Os autores da revisão comentam sobre as concentrações|
|plasmáticas de Glifosato que, obviamente, pode confirmar a|
|exposição para fins forenses, mas também pode ter um papel na<br>|
|quantificação ou previsão da gravidade do envenenamento.|
|Glifosato é considerado de baixa toxicidade, portanto, a razão para<br>|
|realizar sua determinação plasmática é que é uma medida|
|<br>substituta razoável de exposição a adjuvantes não mensuráveis, que<br>são supostamente mais estáveis e lipofílicos. Concentrações entre|  
106

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
||||||734 e >1.000 ug/ml (ou ppm) foram relatadas em pacientes com<br>envenenamento grave, embora a morte possa ter ocorrido com uma<br>concentração de 734 ug/ml (Roberts, 2010 – artigo busca 1A).|
|---|---|---|---|---|---|
|Jyoti et al., 2014|Relato de Caso -<br>Índia|1, 2,<br>3|Mortalidade|Ação corrosiva<br>do glifosato,<br>exame clínico|Caso: jovem do sexo feminino teve extensa ulceração oral e<br>perfuração esofágica após a ingestão de glifosato e foi a óbito<br>posteriormente, devido a sepse e disfunção de múltiplos órgãos.<br>O exame oral revelou extensas ulcerações orais sangrando ao toque<br>com uma formação de membrana branca sobre ambas as<br>amígdalas, palato mole e parede posterior da faringe.<br>O diagnóstico diferencial inicial incluiu difteria, infecção por herpes<br>simplex, infecção pelo vírus Coxsackie e angina de Vincent. Ela foi<br>iniciada com penicilina cristalina empírica, metronidazol e aciclovir.<br>O esfregaço da garganta para a coloração, cultura e sensibilidade de<br>Gram e a coloração de Albert para Corynebacterium diphtheria e<br>anticorpos antinucleares séricos foram negativos. As funções renais<br>apresentaram uréia sanguínea de 111 mg / dL e creatinina sérica de<br>3,7 mg / dL com eletrólitos séricos normais. O restante de seus<br>parâmetros laboratoriais e da radiografia de tórax foram<br>considerados normais.<br>Uma revisão da história revelou consumo intencional de cerca de<br>100-150 mL de um composto tóxico que foi encontrado como sendo|  
107  
||||glifosato. A concentração de glifosato ingerida foi de 43,15% p/p<br>com 95% de pureza e concentração líquida de 41% de SL.<br>No dia 3, a tomografia computadorizada de tórax e pescoço<br>confirmou ar nos espaços pré-vertebrais e espaços parafaríngeos,<br>enfisema subcutâneo e pneumomediastino com extensão mínima<br>nas cavidades pleurais. O exame também mostrou perfuração<br>esofágica selada, confirmando a origem do pneumomediastino. O<br>estado da paciente se deteriorou rapidamente e precisou de<br>ventilação mecânica, inotrópicos e diálise. A intervenção cirúrgica<br>foi adiada dada a gravidade clínica; ela foi a óbito 12 dias após a<br>ingestão do composto.<br>Eles relatam que o glifosato é muito mais tóxico do que o<br>apresentado pelo FDA (2014).|
|---|---|---|---|
|Kwiatkowska et al., 2014|**In vitro**<br>**Não é escopo**|||
|Campbell 2014|**Editorial**|Não é escopo|Não se trata de artigo, é uma publicação de carta editorial. Há<br>narrativa sobre os efeitos gerais do glifosato na saúde, citando<br>alguns artigos. Alguns efeitos relatados são crônicos – pode ser útil<br>para o capítulo de efeitos crônicos.|
|Mesnage et al., 2014|**In vitro**<br>**Não é escopo**|||  
108  
|Chaufan et al., 2014|**In vitro**<br>**Não é escopo**|||||
|---|---|---|---|---|---|
|Garlich et al., 2014|Relato de Caso|Trat|Morbidade/<br>Mortalidade por<br>ingestão de<br>glifosato|Hemodiálise<br>como forma de<br>tratamento de<br>intoxicação<br>aguda|Caso: Homem de 62 anos (Canadá/EUA) foi levado ao hospital após<br>8,5h depois de beber um frasco de herbicida comercial contendo<br>uma solução a 41% de isopropilamina glifosato, em surfactante<br>POEA e água (marca Ortho TotalKill, Monsanto). Ele foi inicialmente<br>encontrado inconsciente em sua garagem após uma tentativa<br>suspeita de suicídio. Uma garrafa de etanol e um opioide<br>desconhecido também estavam presentes. Sua história médica<br>pregressa foi significativa para doença arterial coronariana, diabetes<br>mellitus tipo II, hipertensão, câncer de pulmão, trombose venosa<br>profunda e depressão.<br>**Detalhes do caso:**paciente chegou ao hospital, letárgico com<br>depressão respiratória e necessitou de intubação e ventilação<br>mecânica logo depois. Os resultados laboratoriais iniciais foram<br>significativos para pH 7,11; PCO2, 64 mmHg; PaO2, 48 mmHg;<br>potássio, 7,8 mEq / L; Cr 3,3 mg / dL (aumento de 0,95 mg / dL 3<br>meses antes); BUN, 30 mg / dL; bicarbonato, 22 mEq / L; anion gap,<br>18 mEq / L; lactato, 7,5 mmol / L; amilase, 364 U / L; hematócrito,<br>46,9%; e uma glicose de 419 mg / dL. A creatina quinase foi de 113<br>U / L, e as troponinas em série, salicilato de soro, acetaminofeno,<br>etanol, metanol e concentrações de etilenoglicol foram negativas.<br>Um exame toxicológico de urina foi positivo para os|  
109

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
|benzodiazepínicos. Um ECG mostrou um ritmo juncional a uma taxa|
|---|
|de 42 batimentos/min com uma duração de QRS de 172 ms.|
|A hipercalemia e a acidose do paciente persistiram apesar da<br>ventilação mecânica, ressuscitação endovenosa e administração de|
|bicarbonato de sódio, insulina e instilação nasogástrica de|
|poliestireno sulfonato de sódio (uma concentração repetida de|
|potássio foi de 6,7 mEq/L e pH 7,25). Ele foi submetido a|
|**hemodiálise**emergente 16 horas após a ingestão como tratamento<br>para hipercalemia refratária e acidose. A hemodiálise foi realizada<br>com uma membrana Opti ux F160NR (Fresenius) a uma vazão de<br>sangue de 200 mL/min por 2,5 h. Repetido os estudos laboratoriais<br>após hemodiálise e foram significativos para potássio, 4,4 mEq / L;<br>creatinina, 2,1 mg / dL; BUN, 23 mg / dL; bicarbonato 26 mEq / L; pH|
|7,50, PCO2 35 mmHg; PO2, 73 mmHg; e lactato, 1,6 mmol / L. O<br>paciente foi extubado e subsequentemente permaneceu alerta com<br>sinais vitais estáveis. Sua função renal continuou a melhorar e ele|
|foi transferido da UTI no dia 3. Uma semana após a apresentação,<br>as concentrações séricas de uréia e creatinina foram de 17 e 0,8 mg<br>/ dL, respectivamente. A repetição do ECG mostrou ritmo sinusal<br>normal com duração de QRS de 98 ms.|
|O artigo relata que a hemodiálise pode ser uma modalidade de<br>tratamento útil em pacientes com intoxicação por glifosato-|  
110

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|||||surfactante<br>grave,<br>complicada<br>por<br>acidose<br>metabólica,<br>anormalidades<br>eletrolíticas,<br>lesão<br>renal<br>aguda<br>ou<br>comprometimento respiratório. O glifosato foi removido com<br>sucesso por hemodiálise, com uma taxa de depuração de 97,5<br>mL/min. O uso precoce de hemodiálise em um paciente grave<br>envenenado por GlySH foi associado a um bom resultado clínico. A<br>hemodiálise pode ser considerada quando acidose grave, lesão<br>renal aguda ou outros marcadores de mau prognóstico complicam<br>a ingestão de produtos contendo glifosato.|
|---|---|---|---|---|
|Kim et al., 2014(Heart<br>rate-corrected QT interval<br>predicts mortality<br>in glyphosate-surfactant<br>herbicide-poisoned<br>patients.)|Coorte<br>retrospectiva<br>(Coréia do Sul)|4, 7|Gravidade da<br>intoxicação<br>ECG|Um total de 153 pacientes com ingestão aguda de glifosato-<br>surfactante foi estudada. Utilizou-se o sistema de prontuário<br>eletrônico hospitalar para obter os prontuários dos pacientes<br>candidatos ao estudo. O herbicida envolvido foi determinado pela<br>história, rótulo do recipiente ou informações do produto<br>fornecidas pelo paciente ou pela família do paciente.<br>Os achados anormais de ECG mais comuns foram o intervalo QTc<br>prolongado, seguido de atraso na condução intraventricular e<br>bloqueio atrioventricular de primeiro grau. Os não-sobreviventes<br>tiveram um intervalo QTc significativamente mais prolongado<br>quando comparados com os sobreviventes (sobreviventes: 453,4 ±<br>33,6 vs não sobreviventes: 542 ± 32,0, P<0,001).|  
111  
|Gil et al., 2013|Estudo Caso<br>controle<br>(República da<br>Coreia)|Tratamento?|Tratamento|O estudo objetivou analisar potenciais efeitos terapêuticos da<br>emulsão lipídica intravenosa (ILE) nos pacientes com intoxicação<br>aguda por glifosato por auto-ingestão (entre 2010 e 2012)<br>Este estudo envolveu 64 pacientes intoxicados com glifosato com<br>organização em dois grupos: tratados com ILE (grupo ILE, 22<br>pacientes) e pacientes controle tratados apenas com tratamento<br>de suporte (conservador- 22 pacientes). Os pacientes de controle<br>foram selecionados por correspondência para a quantidade<br>ingerida e tempo desde a ingestão.<br>Lavagem gástrica foi realizada no caso de todos os indivíduos que<br>se apresentaram na sala de emergência dentro de 2 horas após a<br>ingestão. Não houve diferença na modalidade de tratamento<br>(exceto para o ILE) entre o grupo ILE e o grupo controle.<br>No grupo ILE, o produto da emulsão lipídica a 20% foi injetado<br>intravenosamente, a uma velocidade de 20 mL/h para os pacientes<br>que ingeriram menos de 100 mL de glifosato. Nos casos onde<br>ocorreu a ingestão de mais de 100mL, ocorreu a administração de<br>500mL da emulsão por 2 a 3h, seguida da manutenção da dose em<br>1L, por 24h.<br>Como resultado, 13 pacientes receberam altas doses de ILE<br>porque a quantidade de ingestão foi superior a 100 ml.|
|---|---|---|---|---|  
112  
||||||A incidência de insuficiência respiratória aguda no grupo ILE foi<br>menos da metade do grupo controle (13,6% vs. 31,8%,<br>respectivamente).<br>Nenhum dos grupos ILE sofreu com a complicação da hipotensão,<br>enquanto aproximadamente 41% do grupo controle desenvolveu a<br>complicação. Não foi observada arritmia no grupo ILE.  Nenhum no<br>grupo ILE morreu ou sofreu lesão renal aguda.<br>Em conclusão, a administração de ILE foi associada com menor<br>incidência de hipotensão e arritmia em pacientes com intoxicação<br>aguda por glifosato. A administração de ILE parece ser um<br>tratamento eficaz em pacientes que ingeriram glifosato.|
|---|---|---|---|---|---|
|Dawson e Wilks 2013|Comentário ao<br>editor, publicado<br>na revista||||Não é escopo, discute sobre métodos de pesquisa clínica e suas<br>limitações.|
|Henneberger et al., 2014|Transversal<br>(EUA)|1, 2|Morbidade –<br>longo prazo,<br>monitoramento|Asma e<br>exposição ao<br>glifosato|Os participantes foram aplicadores de agrotóxicos e possuíam<br>asma ativa (sibilos e problemas respiratórios nos últimos 12 meses)<br>e preencheram questionários de inscrição para o Estudo de Saúde<br>Agrícola (nos EUA).<br>Os participantes foram questionados a respeito do uso de 36<br>agrotóxicos específicos nos últimos 12 meses e realizavam várias<br>atividades agrícolas. Foi feito o Odds ratios estimado e ajustado|  
113  
||||||por regressão logística. Os fatores de confusão também foram<br>considerados para ajuste.<br>Um total de 202 (22%) dos 926 aplicadores de pesticidas com asma<br>ativa preencheram os critérios de exacerbação nos últimos 12<br>meses. A exacerbação foi positivamente associada à residência na<br>Carolina do Norte e não a Iowa, ao tabagismo e ao início da asma<br>na vida adulta. Aqueles com exacerbação foram um pouco mais<br>velhos (p = 0,15) e menos propensos a estar no quartil mais alto do<br>número de pesticidas utilizados no ultimo ano.<br>A exacerbação da asma foi inversamente associada ao uso<br>corrente dos herbicidas glifosato (OR = 0,5; IC95% 0,3; 0,8) e<br>paraquat (OR = 0,3; IC95% 0,1; 0,9).|
|---|---|---|---|---|---|
|Mariager et al., 2013|Relato de Caso|6, 7|Morbidade<br>associada à<br>exposição ao<br>glifosato e<br>surfactante|Queimaduras e<br>dano ósseo|Este é um caso de queimaduras químicas graves após exposição<br>acidental prolongada a um herbicida glifosato- surfactante. Homem,<br>de 48 anos, tinha corrosões na pele, na mão e no braço esquerdo,<br>no lado esquerdo do peito e na perna esquerda. Dois dias antes, ele<br>usara um concentrado de glifosato-surfactante dado a ele por um<br>vizinho em uma garrafa plástica de meio litro. Ele diluiu o herbicida<br>com água, sacudiu a garrafa e acidentalmente borrifou o líquido em<br>si mesmo. No dia seguinte, as áreas afetadas começaram a inchar,|  
114  
||||||especialmente seu braço, e no segundo dia, vesículas, bolhas e<br>feridas exsudativas apareceram em seu braço e mão, e também em<br>seu peito e perna. Devido ao toque das mãos, teve também um<br>edema periorbital e vermelhidão no lado esquerdo da cabeça.<br>Sugere-se que o surfactante aumenta a penetração em casos de<br>exposição prolongada e pode resultar no dano cutâneo, de<br>músculos e revestimento nos axônios nervosos. A atrofia dos<br>músculos da mão pode ser o resultado do efeito nervoso, mas<br>também pode ser um efeito cáustico direto. Sugere-se que a<br>elevação inicial dos níveis de mioglobina e creatina quinase ilustram<br>dano muscular primário. As feridas aparentemente foram curadas<br>sem complicações, mas o paciente experimentou total falta de<br>sensibilidade em sua mão esquerda, que somente retornou após 9<br>meses de acompanhamento médico.|
|---|---|---|---|---|---|
|Zouaoui et al., 2013|Case report -<br>Estudo caso<br>clínico com<br>análise<br>laboratorial|1, 3|Mortalidade|Sinais e<br>sintomas e<br>análise<br>laboratorial|Entre os 10 pacientes analisados (França), um era assintomático,<br>cinco tinham intoxicação leve a moderada e dois tinham intoxicação<br>grave. Houve 6 óbitos, dos quais 3 eram casos forenses (post<br>mortem). Os sintomas mais comuns foram ulceração orofaríngea<br>(5/10), náuseas e vômitos (3/10). Os principais parâmetros<br>biológicos alterados foram alto lactato (3/10) e acidose (7/10).<br>Observou-se também dificuldade respiratória (3/10), arritmia<br>cardíaca<br>(4/10),<br>dor<br>de<br>garganta<br>(5/10),<br>hipercalemia,|  
115  
|||comprometimento da função renal (2/10), toxicidade hepática<br>(1/10) e alteração da consciência (3/10). Nas fatalidades, os<br>sintomas<br>comuns<br>foram<br>choque<br>cardiovascular,<br>parada<br>cardiorrespiratória,<br>distúrbio<br>hemodinâmico,<br>coagulação<br>intravascular disseminada e falência múltipla de órgãos. Encontrou-<br>se forte correlação sintomatologia-concentração de glifosato no<br>sangue. Na sintomatologia benigna ou moderada, as concentrações<br>sanguíneas de glifosato observadas e descritas na literatura não<br>excedem 150 mg/L. Na sintomatologia grave: as concentrações<br>sanguíneas de glifosato observadas e descritas na literatura são<br>geralmente superiores a 1000 mg/L. Nas 3 fatalidades (tratadas nos<br>casos de serviço/não forense), notou-se concentrações de glifosato<br>no sangue superiores a 5.000mg/L. A morte foi, na maioria das<br>vezes, associada à maior dose administrada (500 mL em um<br>paciente) e altas concentrações de glifosato no sangue. Os autores<br>também concluem que o glifosato é muito pouco metabolizado no<br>AMPA. Para prever os resultados clínicos e orientar o apoio ao<br>tratamento em pacientes que ingeriram o glifosato, as<br>concentrações sanguíneas desse composto e a dose administrada<br>seriam úteis.|
|---|---|---|
|Kimmel et al., 2013|Não é escopo|Estudo em coelhos e em ratos – não é escopo|  
116  
|Deo e Shetty 2012|Relato de Caso<br>(Nepal)|1, 2,<br>4|Morbidade|Úlcera bucal<br>após contato<br>com glifosato|Homem de 25 anos relatou dificuldade para engolir e queimação<br>na boca, por 2 dias. Relatou que teve exposição ao herbicida<br>glifosato após abrir a garrafa de Roundup, 3 dias antes, com seus<br>dentes. O herbicida espirrou na sua boca, acidentalmente. Havia<br>muitas ulcerações na boca e língua, mas nenhuma na face. A<br>endoscopia era normal e foi detectada leucocitose neutrofílica no<br>exame laboratorial, indicando infecção secundária no local<br>ulcerado. Ao se lavar a região com salina, as úlceras pioraram. Foi<br>realizada aplicação de pomada de benzocaína no local e sessões de<br>fisioterapia.|
|---|---|---|---|---|---|
|Carroll et al., 2012|Coorte<br>prospective (Sri<br>Lanka)|1, 2|Morbidade –<br>gravidade<br>intoxicação ao<br>longo do tempo|Cronotoxici-<br>dade por<br>ingestão<br>glifosato|Os pesquisadores examinaram pacientes com intoxicação aguda para<br>buscar evidências de variação diurna na probabilidade de sobrevivên<br>entre 2002 a 2009.<br>Foram investigados 14.840 pacientes internados após a auto-<br>intoxicação por semente de oleandro amarelo (_Cascabela thevetia_)<br>ou pesticida [organofosforado (OP), carbamato, paraquat,<br>glifosato] por variação na sobrevivência de acordo com o tempo de<br>ingestão.<br>Foi encontrado pouca evidência de uma relação entre o tempo de<br>ingestão e a letalidade após a auto-intoxicação por carbamida,<br>paraquat ou glifosato (P =0,221, P=0,076 e P=0,437, respectivamente|  
117  
||||||após ajuste para idade, sexo, tempo de internação, ano de internaçã<br>horário de apresentação).|
|---|---|---|---|---|---|
|Sribanditmongkol et al.,<br>2012|Relato de Caso<br>(Tailândia)|1|Mortalidade|Exame post<br>mortem –<br>órgãos após<br>intoxicação fatal<br>por glifosato.|Uma mulher de 37 anos foi encontrada morta em seu quarto.<br>Investigadores da polícia encontraram uma garrafa de Roundup,<br>rotulada como GlySH, perto do cadáver e relataram que o falecido<br>tinha bebido aproximadamente 500 mL dele.<br>A mucosa gástrica revelou hemorragia e o intestino delgado<br>apresentava dilatação acentuada e paredes finas. Usou-se<br>cromatografia líquida de alta eficiência para determinação dos<br>níveis séricos e de conteúdo gástrico do glifosato. Os níveis séricos<br>e gástricos de glifosato foram de 3,05 e 59,72 mg/mL,<br>respectivamente. Os efeitos tóxicos da polioxietileno amina e<br>Roundup foram causados pela sua capacidade de erodir tecidos,<br>incluindo membranas mucosas e revestimentos das vias<br>respiratórias e gastrointestinais.<br>O exame microscópico das secções de tecido do cérebro revelou<br>congestão e edema. Seções do coração apresentavam hipertrofia<br>leve de fibras miocárdicas e congestão vascular. Um leve grau de<br>congestão pulmonar e edema foi observado em ambos os<br>pulmões.|  
118  
|Hour et al., 2012|Relato de Caso<br>(EUA)|1, 2,<br>4|Morbidade|Sinais e<br>sintomas de<br>intoxicação por<br>glifosato,<br>exames<br>laboratoriais|Um hispânico de 66 anos com história de diabetes não insulino-<br>dependente, hipertensão e abuso de álcool foi levado ao pronto-<br>socorro inconsciente após ter ingerido aproximadamente 500 mL de<br>rum e 350 mL de Roundup. Ele estava em uma discussão com sua<br>esposa e acidentalmente misturou seu álcool com o Roundup.<br>Aproximadamente duas horas depois, ele teve status mental<br>alterado, um episódio de emese não-hemorrágica, e foi mais difícil<br>de despertar. Ao chegar ao Serviço de Emergência, ele estava<br>hipotenso (pressão arterial 87/45 mm Hg), diaforético e<br>hipoxêmico. Ele teve uma pontuação de 5 na Escala de Coma de<br>Glasgow. Seus achados laboratoriais foram notáveis por hipóxia e<br>acidose láctica profunda, com um alto anion gap e pequeno gap<br>osmolar. Ele foi intubado, ventilado e administrado em bolus com 2<br>L de solução salina normal e um L de bicarbonato de sódio. No<br>entanto, ele se deteriorou rapidamente em choque, com pressão<br>arterial de 66/43 mm Hg juntamente com lesão renal aguda,<br>hipercalemia, leucocitose e agudização da acidose láctica, exigindo<br>alta dose de Levophed e vasopressina, para suporte de pressão.<br>Devido ao seu comprometimento hemodinâmico, iniciou-se a<br>hemodiafiltração venovenosa contínua. Dentro de 24 horas, sua<br>condição melhorou.|
|---|---|---|---|---|---|  
119  
|You et al., 2012 (Effect of<br>intravenous fat emulsion<br>therapy on glyphosate-<br>surfactant-induced<br>cardiovascular collapse.)|Relato de Caso|Trat||||
|---|---|---|---|---|---|
|Kamijo et al., 2012|Relato de caso<br>(Japão)|1, 2,<br>4, 5|Intoxicação de<br>caráter suicida|Acidose,<br>hipercalemia,<br>ECG alterado e<br>funções<br>respiratórias<br>alteradas –<br>seguiu-se com<br>suporte<br>cardiopulm.,<br>carvão ativado e<br>diálise|No caso relatado, uma mulher de 69 anos ingeriu cerca de 500 mL<br>de Roundup Maxload (1L®, Nissan Chemical Industries Ltda., Tóquio,<br>Japão). Quando encontrada, estava consciente, mas vomitou várias<br>vezes e pediu uma ambulância. Ao chegar ao hospital, perdeu a<br>consciência e não tinha pulso. O ECG revelou taquicardia ventricular<br>(TV); a paciente recebeu ressuscitação cardiopulmonar com<br>intubação endotraqueal.<br>Exames laboratoriais revelaram**hipercalemia**extrema (10,7 mEq/L)<br>com função renal normal (BUN: 17,9 mg/dL, Cr: 0,51 mg/dL) e<br>**acidose metabólica**(pH: 7,005, PaCO2: 41,6 mm Hg, BE: 20,7<br>mmol/L, HCO<sup>-</sup>3: 10,1 mmol/L).<br>O**suporte cardiopulmonar**percutâneo (PCPS) e**hemodiálise**<br>contínua foram iniciados, e 50 g de**carvão ativado**foram<br>administrados por sonda nasogástrica. A radiografia de tórax|  
120  
||||||mostrou um infiltrado pulmonar difuso. O paciente foi então<br>diagnosticado com síndrome do desconforto respiratório agudo<br>(SDRA); ventilação mecânica com pressão positiva expiratória final<br>alta e foi induzido baixo volume corrente.<br>Após PCPS e a hemodiálise, a concentração sérica de potássio<br>diminuiu imediatamente para níveis normais e o ECG mostrou um<br>ritmo sinusal normal; PCPS e a hemodiálise foram encerrados 7h e<br>20h após a admissão, respectivamente. A endoscopia revelou<br>edema faríngeo, erosões esofágicas e gástricas. Tanto o SDRA como<br>o edema melhoraram gradualmente; a ventilação mecânica e<br>intubação foram retiradas no dia 20. Os níveis séricos de glifosato<br>na admissão e após 18 horas foram de 1.625,74 e 100,44 μg/mL,<br>respectivamente.|
|---|---|---|---|---|---|
|Williams et al., 2012|Não disponível|||||
|Seok et al., 2011|Transversal|1, 2,<br>6|Morbidade e<br>Mortalidade|Sintomas e<br>gravidade do<br>caso por<br>ingestão de<br>glifosato<br>surfactante|O objetivo do estudo foi determinar a toxicidade do surfactante do<br>glifosato em pacientes com intoxicação aguda por glifosato.<br>Foram levantados 107 pacientes (69 homens e 38 mulheres, com<br>idade entre 52,3 e 15,5 anos) com intoxicação aguda por glifosato<br>(Coréia). A partir de seus prontuários, identificou-se a formulação<br>de produtos de glifosato ingeridos e parâmetros clínicos derivados.<br>Na admissão, os pacientes receberam procedimentos padronizados|  
121  
de emergência médica. Lavagem gástrica foi realizada no caso de todos os indivíduos que se apresentaram na sala de emergência dentro de 2 horas após a ingestão. A hemodiálise foi iniciada precocemente se os pacientes chegassem ao hospital dentro de oito horas após a ingestão. Do total, 2 pacientes (68 e 73 anos) morreram e apresentaram **estado mental sonolento, hipotensão e insuficiência respiratória aguda com acidose metabólica grave** . A quantidade de surfactante ingerido (18,5+17,1 mL) foi estimada a partir da proporção (% volume) do excedente e volume total do herbicida ingerido. **(Tabela 1 do artigo – muito relevante* anexo abaixo) A incidência geral de complicações clínicas foi (em ordem de classificação): hipotensão, 41 casos (38,3%); deterioração mental, 33 (30,8%); insuficiência respiratória, 25 (23,4%); dano agudo renal, 15 (14,0%); e arritmia, 9 (8,4%).** Pacientes do grupo com escore de gravidade 2 ingeriram maior volume de surfactante do que aqueles com escore de gravidade 1 (O escore de gravidade do envenenamento (SSP) foi avaliado no momento da admissão: 0, sem sintomas ou sinais; 1 sintomas ou sinais leves, transitórios e de resolução espontânea; 2 sintomas ou sinais pronunciados ou prolongados; 3, sintomas ou sinais graves ou com risco de vida; 4 morte).  
122  
A quantidade de surfactante ingerido (mL) foi correlacionada positivamente com os dias de permanência na UTI (r=0,274, p<0,004), duração da intubação (r=0,300, p<0,002) e contagem de leucócitos (r=0,373, p<0,001) e correlação negativa com pH inicial (r=-0,365, p<0,001) e HCO3<sup>-</sup> (r = -0,380, p<0,001). **O volume de surfactante foi mais relevante para complicações clínicas do que para o volume de ingrediente de glifosato** : hipotensão, RR, 1,047 (IC, 1,017-1,077; p=0,002) vs. RR, 1,017 (p=0,003); insuficiência respiratória, RR, 1,033 (IC, 1,006-1,060; p=0,016) vs. RR, 1,010 (p=0,040); lesão aguda renal, RR, 1.042 (CI, 1.012–1.074; p=0,006) vs. RR, 1,013 (p=0,029); e deterioração mental, RR, 1,032 (CI, 1.006–1.059; p=0,015) vs. RR, 1.012 (p=0,024). **Não houve diferença de sintomas entre os grupos de diferentes fórmulas dos surfactantes e sim, pelo volume ingerido.** Os resultados indicam que pacientes que ingerem grandes volumes de surfactante correm maior risco de hipotensão, deterioração mental, insuficiência respiratória e arritmias, particularmente quando se ingere volumes de surfactante <u>></u> 8 mL. Diante disso, acredita-se que os toxicologistas clínicos devem estar cientes do volume de surfactantes para o tratamento de intoxicação aguda por glifosato.  
123  
|Pedroso et al., 2010|Coorte histórica|Trat|Mortalidade|Uso da Diálise e<br>consulta ao<br>nefrologista|Como objetivo, o trabalho tentou determinar a incidência de<br>emprego de métodos dialíticos no manejo de intoxicações graves, a<br>sua necessidade e eficácia. Entre 1998 e 2000, foi realizada a revisão<br>das fichas de atendimento dos casos de intoxicação aguda<br>registrados no Centro de Informação Toxicológica do Rio Grande do<br>Sul (CIT-RS) e a escolha das categorias dos agentes tóxicos (medica-<br>mentos e agrotóxicos/uso agrícola) foi feita considerando os dados<br>do Sistema Nacional de Informações (SINITOX).<br>Os critérios objetivos empregados para enquadramento na<br>categoria de gravidade consistiam em extremos etários (crianças ou<br>idosos), tipo de agente químico envolvido, sinais ou sintomas no<br>decorrer da evolução (como coma, convulsões, necessidade de<br>internação em UTI, emprego de assistência ventilatória) ou<br>desfecho do acidente. Isso resultou em 245 atendimentos. Os<br>agrotóxicos foram responsáveis por 36,3% dos casos e<br>compreenderam os organofosforados, compostos bipiridílicos<br>(paraquat e diquat) e glifosato.<br>Quanto ao emprego de lavagem gástrica ou uso de antídotos no<br>manejo da intoxicação, não foi evidenciada relação entre seu uso e<br>ocorrência (redução) de óbito (p=0,254 e 0,128, respectivamente).<br>Já para o carvão ativado, seu emprego está associado à redução de<br>óbito, para umpobtido igual a 0,01. No tocante à alcalinização|
|---|---|---|---|---|---|  
124  
|urinária, houve relação entre seu emprego e redução de óbito (p =<br>0,001). O fato de necessitar ou não de suporte ventilatório não<br>pareceu modificar o desfecho em questão (p = 0,695).|
|---|
|No grupo que dialisou, em 91%, a circunstância foi tentativa de<br>suicídio (principalmente fenobarbital e paraquat). Dois casos<br>requereram hemoperfusão (cloranfenicol e paraquat). Entre os 11<br>pacientes submetidos a Hemodiálise ou hemoperfusão houve 4<br>óbitos (36,3%), percentual maior de óbitos que entre pacientes não<br>dialisados (25,6%, n = 234), mas tal diferença não foi significativa<br>como fator de risco relativo (RR = 0,89, IC 95% = 0,54-1,35).<br>|
|185 acidentes estudados apresentaram possibilidade teórica de<br>indicação de diálise ou hemoperfusão. Haveria indicação de ambos<br>os procedimentos (hemodiálise e/ou hemoperfusão) em 102 casos;<br>|
|exclusivamente de hemodiálise em 20 casos; somente de|
|hemoperfusão em 63 casos. A incidência de óbitos entre todos os<br>casos em que haveria alguma indicação de procedimento dialítico (n<br>= 185) foi de 24,8% (46 óbitos, p < 0,05; IC 95% = 18,6%-31%). Dentre<br>os casos sem indicação teórica de procedimento dialítico (n = 60), a<br>incidência de óbitos foi de 30% (18 óbitos, p < 0,05; IC 95% = 18,5%-<br>41,5%).|
|Quanto aos casos emque houve registro emprontuário de efetiva|  
125  
||||||recomendação de prescrição dialítica pelo toxicologista (n = 30), a<br>incidência de óbitos foi de 9 casos (30%, p < 0,05; IC 95% = 13,6%-<br>46,4%).<br>A incidência de realização de procedimentos dialíticos em nosso<br>meio é similar à incidência mundial. Ainda que houvesse indicação<br>para determinada intoxicação, o método foi subutilizado ou teve<br>sua instituição protelada, o que pode ter sido responsável por<br>desfechos desfavoráveis.|
|---|---|---|---|---|---|
|Yoshioka et al., 2011|Artigo de teste<br>metodológico||||Não é escopo – artigo trata de metodologia para detecção de<br>glifosato sérico|
|Sato et al., 2011|Relato de Caso|1, 2|Morbidade|Meningite após<br>intoxicação por<br>glifosato|Uma mulher de 58 anos ingeriu aproximadamente 150 mL de<br>Glifosato -surfactante contendo 41% de glifosato e 15% de<br>polioxietileneamina. Dois dias depois, ela foi internada no Centro<br>de Emergência em estado semicomatoso. Outros sinais e sintomas<br>físicos anormais incluíam crepitações pulmonares bilaterais, anúria<br>e petéquias em todo o corpo. Exames laboratoriais revelaram<br>distúrbio de oxigenação (PaO2 94,2 mmHg inspirando 10L/min de<br>O2 com máscara facial de oxigênio), acidose metabólica e<br>respiratória (pH 7,057, PaCO2 57,0 mmHg, BE -15,1 mmol/L, HCO3<sup>-</sup><br>15,7 mmol/L), leucocitose (WBC 14400/uL), disfunção renal (BUN|  
126  
||||||88 mg/dL, Cr 8,64 mg/dL) e elevação da Proteína C reativa (10,4<br>mg/dL). Radiografia de tórax e TC mostraram infiltração difusa em<br>ambos os pulmões. TC do cérebro e ressonância magnética não<br>revelaram achados anormais.<br>Também se suspeitava de**meningite**, pois demonstrava o sinal de<br>Kernig e rigidez de nuca significativa com rigidez das extremidades,<br>bem como perturbação da consciência e febre (38,48ºC).<br>Investigações do líquido cefalorraquidiano (LCR) revelaram a<br>presença de glifosato (122,5 mg / mL), elevação significativa de IL-6<br>(394 mg / mL) e pleocitose (32 células / mL) com dominância de<br>monócitos. Todos os testes bacteriológicos e virológicos foram<br>encontrados posteriormente como negativos.<br>O presente caso sugere que a meningite asséptica pode ser<br>responsável pelos sinais e sintomas do SNC observados nos casos<br>de intoxicação por Glifosato-surfactante e, portanto, deve ser<br>considerado na avaliação de pacientes com intoxicação por<br>Glifosato-surfactante.|
|---|---|---|---|---|---|
|Palli et al., 2011|Relato de Caso|1, 2|Morbidade após<br>intoxicação por<br>glifosato|Lesão<br>gastrintestinal<br>grave|Um homem de 75 anos de idade foi admitido no serviço de<br>emergência (Grécia) após ingestão intencional de mais de 150 mL<br>de glifosato-surfactante em uma tentativa de suicídio.<br>O estado hemodinâmico do paciente piorou ainda mais nos dias<br>subsequentes,<br>sendo<br>necessário<br>suporte<br>hemodinâmico|  
127  
||||||significativo com vasopressores e inotrópicos. A função respiratória<br>também foi severamente prejudicada (PO2 / FIO2 <100) e foi<br>tratada como Síndrome da Angústia Respiratória (_Acute Respiratory_<br>_Distress)_. Sua condição melhorou gradualmente ao longo dos<br>próximos 4 dias. No entanto, no nono dia da unidade de terapia<br>intensiva, o paciente apresentava febre (39°C), distensão abdominal<br>e diarreias. O paciente foi submetido à exploração cirúrgica de<br>urgência, que revelou peritonite devido ao extenso relaxamento<br>longitudinal do cólon descendente. O exame histológico revelou<br>erosões abundantes, formação de abscesso, necrose do tecido<br>gorduroso perientérico e reação fibroblástica sem evidência de<br>isquemia da mucosa. O paciente foi submetido a ressecção colônica<br>e desvio de colostomia e recebeu alta da unidade de terapia<br>intensiva no 21º dia.<br>Esse caso pontua os efeitos gastrointestinais graves resultantes da<br>intoxicação por glifosato|
|---|---|---|---|---|---|
|Moon et al., 2010|Coorte<br>retrospectiva<br>(República<br>Coreia)|1, 2,<br>4, 7|Morbimortali-<br>dade|Manifestações<br>clínicas e testes<br>laboratoriais|Utilizaram o sistema de prontuário eletrônico hospitalar para obter<br>o prontuário de pacientes, entre 1998 e 2009 com diagnóstico de<br>intoxicação por glifosato, com idade acima de 18 anos. Foram<br>selecionados 76 pacientes, 69,7% amostra foi do sexo masculino e<br>idade média de 55.1 ± 16.3 anos.|  
128  
|**Manifestação clínica:**|
|---|
|Estado mental alterado - 25 (32.9%)|
|Dor de garganta - 25 (32.9%)|
|Náusea / vômito - 16 (21.1%)|
|Dor abdominal - 15 (19.7%)|
|Diarreia - 3 (3.9%)|
|Dor no peito - 2 (2.6%)|
|**Anormalidades radiológicas:**17 (22.4%) – houve infiltração no|
|pulmão em 7 pacientes e edema pulmonar em 10 pacientes, visto<br>em radiografia de tórax inicial.|
|**Anormalidades do ECG na entrada hospital:**|
|Prolongamento do QTc  - 30/58 (51.7%)|
|Taquicardia sinusal - 8/58 (13.8%)|
|Bloqueio AV de primeiro grau - 6/58 (10.3%)|
|Anormalidade ST-T - 6/58 (10.3%)|
|Bradicardia sinusal - 3/58 (5.2%)|
|Taquicardia de QRS larga - 1/58 (1.7%)|
|Lesão renal aguda foi detectada entre 1 e 21 h após a ingestão em<br>nove pacientes com lesão renal aguda|
|**Tratamento:**|
|Lavagem gástrica dentro de 2 h - 34 (48.6%)<br>Quantidade de lavagem gástrica (L) - 10 (1–17)|  
129  
||||||Administração de carvão vegetal - 15 (19.7%)<br>Hemodiálise - 3 (3.9%)<br>**Resultado:**<br>Duração da hospitalização (h)  - 152.8 ± 214.7<br>Morte - 2 (2.6%)<br>**Complicações dos pacientes intoxicados com glifosato:**<br>Acidose metabólica  - 28 (36.8%)<br>Insuficiência respiratória - 21 (27.6%)<br>Hipotensão - 14 (18.4%)<br>Pancreatite aguda - 9 (11.8%)<br>Lesão renal aguda - 9 (11.8%)<br>Parada cardíaca - 4 (5.3%)<br>Hipercalemia - 4 (5.3%)|
|---|---|---|---|---|---|
|Slager et al., 2010|Coorte<br>prospective/<br>análise<br>transversal|1,2|Morbidade|Rinite em<br>intoxicações por<br>glifosato|Trata-se de um estudo prospectivo de aplicadores licenciados de<br>agrotóxicos e cônjuges de Iowa e Carolina do Norte. A coorte de<br>57.310 aplicadores licenciados de agrotóxicos (52.394 aplicadores<br>privados e 4.916 comerciais) foi recrutada entre 1993 e 1997. Os<br>aplicadores de agrotóxicos foram solicitados a preencher dois<br>questionários auto-administrados. Indivíduos que tiveram um|  
130  
||||||resfriado no ano passado ou asmáticos foram excluídos. Um total de<br>14.629 agricultores (67%) relataram rinite no questionário.<br>Dos entrevistados que relataram rinite recorrente, a maioria relatou<br>3-6 episódios no último ano (35%) e 15% relataram 13 ou mais<br>episódios no último ano.<br>Os herbicidas glifosato e óleo de petróleo e os inseticidas diazinon,<br>malathion,<br>carbofuran<br>e<br>permetrina<br>nos<br>animais<br>foram<br>significativamente associados à rinite nos modelos politômicos<br>(global p<0,05). No modelo dicotômico, o glifosato (OR = 1,09;<br>IC95% = 1,05-1,13) e óleo de petróleo (OR = 1,12; IC95% = 1,05-1,19)<br>foram significativamente associados à rinite. Quando os<br>participantes com resfriados no ano anterior foram excluídos dos<br>modelos (n=17.260, 79% dos agricultores), o glifosato e o malation<br>permaneceram significativamente associados à rinite.|
|---|---|---|---|---|---|
|Malhotra et al., 2010|Relato de Caso|1, 2|Morbidade por<br>intoxicação com<br>glifosato e<br>surfactante|Sintoma -<br>encefalopatia|Um homem de 71 anos foi encontrado inconsciente em casa com<br>uma garrafa vazia de herbicida glifosato. Ele estava em choque<br>cardiogênico com acidose metabólica severa com pH 7,13, HCO3<sup>-</sup><br>de 13,2 mmol/L (normal seria 22–30 mmol/L), excesso de base -<br>15,0 (faixa normal: -2 a 2 mmol/L) e lactato sanguíneo 7,1 mmol/L<br>(faixa normal: 0,5 a 1,6 mmol/L).<br>Ele<br>necessitou<br>de<br>suporte<br>ventilatório<br>e<br>inotrópico<br>e<br>hemodiafiltração venovenosa contínua. Ele foi inicialmente tratado|  
131

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
para envenenamento por organofosforados com atropina e pralidoxima por via venosa. Investigações subsequentes revelaram um alto ânion gap de 25 mmol/L (faixa normal: 8-14 mmol/L), alta osmolaridade de 327 mmol/kg (faixa normal: 280-300 mmol/kg) e um gap osmolar de 40 mmol/L (normal: <10 mmol/L). Ele tinha um nível normal de acetilcolina esterase de 15,9 U/mL (faixa normal: 8 a 20 U/mL). Foi interrompida a adm de atropina (dose total: 239 mg) e pralidoxima (dose total: 4 g), após 48 horas, mas as medidas de suporte continuaram. A acidose metabólica e o ânion gap elevado normalizaram-se após 48h. Nas próximas 72h, sua pressão arterial melhorou, mas sua pontuação na Escala de Coma de Glasgow (GCS) permaneceu baixa (E1, V1, M4). Investigações neurológicas foram realizadas para excluir patologia estrutural. A tomografia cerebral do TC foi normal. Uma leitura de eletroencefalograma (EEG) no dia 8 demonstrou atividade de onda lenta generalizada com complexos de onda lenta e lenta trifásicos consistentes com uma encefalopatia, embora o risco de convulsões não pudesse ser excluído. Subsequentemente, sua pontuação na GCS começou a melhorar e ele teve alta após 16 dias. Em conclusão, relatou-se um paciente com encefalopatia única, prolongada e reversível, possivelmente por complicação pelo envenenamento por Glifosato-surfactante, levantando suspeita de toxicidade cerebral direta.  
132

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|Adams et al., 2010|Não é escopo|Avaliação de<br>concordância<br>clínica – não é<br>escopo<br>Não há relato<br>dos sinais e<br>sintomas que<br>levaram à<br>decisão de<br>gravidade|Inglaterra<br>Analisaram-se questionários de incidentes de exposição acidental<br>ocorridos entre 2006 a 2009. Esses retornos incluíram uma<br>classificação de gravidade pelo respondente, com base nos dados<br>inseridos no questionário. Especialistas em informações sobre<br>venenos classificaram os mesmos casos com base nos dados do<br>questionário usando o Índice de Gravidade de Envenenamento<br>(IGE). Os escores de gravidade para exposições acidentais a<br>agrotóxicos foram avaliados separadamente para adultos (> 12<br>anos) e crianças. Após triagem, 1284 questionários estavam<br>disponíveis para análise, com 745 exposições envolvendo crianças e<br>539 envolvendo adultos.<br>Crianças expostas ao glifosato (n = 27) apresentaram uma<br>classificação de gravidade estatisticamente mais alta calculada<br>pelos especialistas, do que os inquiridores tinham relatado (1,68;<br>IC95% 1,38–1,96; 1,26; IC95% 1,08-1,44, respectivamente) (p<br><0,025). Para adultos (n = 68) expostos ao glifosato, o escore de<br>gravidade avaliado pelos especialistas foi semelhante ao avaliado<br>pelos inquiridores e não significativamente diferente (1,94, IC 95%<br>1,76–2,12; 1,74, IC 95% 1,59–1,88, respectivamente) (p = 0,14).|
|---|---|---|---|  
133  
|Han et al., 2010|Relato de Caso<br>(República da<br>Coréia)|1, 2,<br>Trat.|Morbidade|Sinais e<br>sintomas<br>clínicos,<br>estabilização e<br>início do<br>tratamento|Trata-se de um caso de intoxicação por Glifosato-surfactante com<br>choque refratário aos vasopressores, mas responsivo à emulsão<br>gordurosa intravenosa. Homem de 52 anos foi encontrado<br>inconsciente juntamente com um frasco vazio de 300 mL de<br>herbicida GlySH, que continha 41% de glifosato como um sal de<br>isopropilamina, 15% de surfactante de polioxietilenamina (POEA) e<br>água.<br>Ele estava sonolento na apresentação, com uma escala de escala de<br>coma de Glasgow de 11 (E3, V4, M4). Sua frequência cardíaca era de<br>44 batimentos/min, sua pressão arterial não podia ser medida com<br>um manguito de braço, mas ele tinha um pulso femoral palpável e<br>sua frequência respiratória era de 15 respirações /min. Ele foi<br>intubado e um ventilador mecânico foi usado. Um cateter venoso<br>central foi inserido e o suporte vasopressor foi iniciado com a<br>infusão de dopamina.<br>A atropina foi administrada para tratar a bradicardia. Lavagem<br>gástrica foi realizada e 50 g de carvão ativado foi administrado por<br>sonda gástrica. Uma radiografia de tórax foi normal e um<br>eletrocardiograma revelou ritmo atrial com complexos prematuros<br>juncionais.<br>Os resultados da análise de gasometria arterial foram os seguintes:<br>**pH 7,298**; PaCO2, 26,9 mmHg; PaO2, 240,2 mmHg; e HCO3, 13,3<br>mEq / L. As concentrações de eletrólitos séricos foram as seguintes:|
|---|---|---|---|---|---|  
134  
<!-- Start of picture text -->
6<br><!-- End of picture text -->  
||||||Na, 134,4 mEq/L; K 3,79 mEq/L; e Cl, 94,6 mEq/L. A concentração<br>sérica de etanol foi de 152,8 mg / dL. Demais parâmetros no exame<br>de sangue foram normais.<br>Após cerca de 2,5h de cuidados de suporte após a admissão, ele<br>permaneceu hipotenso e sua pressão arterial sistólica foi de 80<br>mmHg.<br>Preparou-se um frasco de 500 mL de 20% de produto de emulsão<br>lipídica intravenosa. Como um bolus, 100 mL de emulsão lipídica<br>intravenosa (Intravenous Fat Emulsion - IFE) foram injetados, e os<br>400 mL restantes foram então infundidos a uma taxa de 1,5 mL/min.<br>Seu pulso radial se fortaleceu imediatamente após a injeção do<br>bolus. Sua pressão arterial foi de 100/60 mmHg 1h após a injeção e<br>ele se extubou. Após 5h da injeção de IFE, sua pressão arterial<br>atingiu 160/100 mmHg e os vasopressores foram reduzidos. Ele<br>permaneceu estável por 6 dias após a admissão hospitalar e recebeu<br>alta.|
|---|---|---|---|---|---|
|Nielsen 2010|**In vitro –**<br>**Não é escopo**|||||
|Roberts et al., 2010(A<br>prospective observational<br>study of<br>the clinical toxicology<br>~~—~~|Série de Casos|1, 2|Detecção de<br>casos de<br>intoxicação por|Desconforto<br>respiratório,<br>hipotensão,<br>nível de|Esta série de casos prospectivos observacionais foi realizada em dois<br>hospitais no Sri Lanka entre 2002 e 2007. Resultados clínicos,<br>relação com a concentração plasmática de glifosato e toxicocinética<br>do glifosato são apresentados nesse estudo.|  
135  
|of glyphosate-containing<br>herbicides in adults with<br>acute self-poisoning.)|grupos<br>toxindromes|consciência<br>alterado,<br>oligúria, náusea<br>e vômito,<br>bradicardia ou<br>taquicardia|Foram incluídos pacientes com histórico de intoxicação aguda.<br>Observações clínicas foram registradas até a alta ou morte.<br>A maioria dos pacientes (64%) desenvolveu sinais de intoxicação<br>branda, As manifestações gastrointestinais foram documentadas<br>em 83% dos pacientes com intoxicação branda, principalmente<br>nauseas, vômitos, diarréia e dor abdominal.<br>Outras toxicidades em intoxicações brandas incluíram hipotensão<br>transitória (5% dos pacientes, pressão arterial média <70mmHg),<br>bradicardia (freqüência cardíaca <60 batimentos / minuto) ou<br>taquicardias (freqüência cardíaca> 100 batimentos / minuto).<br>Sintomas gastrointestinais, dificuldade respiratória, hipotensão,<br>nível de consciência alterado e oligúria foram observados em casos<br>fatais, a maioria dos pacientes (64%) desenvolveu sinais de<br>intoxicação branda e a intoxicação moderado a grave ocorreu em<br>5,5% dos pacientes (33 pacientes), levando a internações mais<br>longas. Crepitações respiratórias bilaterais foram observados em<br>seis pacientes, quatro pacientes foram taquipnéicos (taxa<br>respiratória> 25 / minuto) e um paciente precisava de intubação e<br>ventilação para insuficiência respiratória. Hipotensão (pressão<br>arterial média <70mmHg) foi observada durante a hospitalização<br>em 48% desses 33 pacientes. Outros marcadores de intoxicação<br>moderada a grave incluíram convulsões (dois pacientes) e / ou um<br>nível de consciência deprimido (12 pacientes).|
|---|---|---|---|  
136  
|Elie-Caille et al., 2010|Estudo**in vitro**<br>com cultura de<br>células linhagem<br>HaCaT|Não é escopo – in vitro|
|---|---|---|  
137

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
**Quadro III.4.2** Síntese de evidências para diagnóstico por intoxicação por Glifosato -  capítulo 3 – buscas extras de artigos  
|**REFERÊNCIA**|**DELINEAM.**|**PICO**|**DESFECHO**|**TIPO DE**<br>**SINTOMAS/**<br>**ANÁLISES**|**EVIDÊNCIAS DO ARTIGO**|
|---|---|---|---|---|---|
|Thakur 2014 – extra|Relato de Caso|1, 2,<br>4|Morbidade|Edema<br>pulmonar<br>agudo|O paciente era do sexo masculino, 35 anos, agricultor e**alcoólatra**<br>crônico. Foi levado ao pronto-socorro após a ingestão de 75 ml de<br>herbicida Glycel junto com 120 ml de álcool, meia hora antes da<br>admissão. Esta preparação comercial contém 40,6% de Glifosato<br>surfactante, 15,0% de agente tensioativo de polioxietileno amina<br>inerte e água. Ele queixou-se de dor abdominal e teve dois<br>episódios de vômito. Não havia sangue no vômito. Na admissão, o<br>paciente estava consciente, mas irritado, agitado e suando. Os<br>sinais vitais eram estáveis e as pupilas tinham tamanho normal e<br>reagiam à luz. Ao exame bucal, a mucosa bucal e posterior da<br>faringe apresentava congestão e ulceração. Não houve<br>fasciculações. Os reflexos tendinosos profundos estavam normais e<br>os plantares eram flexores. O exame cardiovascular foi normal. O<br>paciente apresentava sensibilidade epigástrica à palpação do<br>abdome.<br>Foi realizada a lavagem gástrica e o carvão ativado não foi<br>administrado, pois o paciente apresentava úlceras orais.|  
138

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Dentro de meia hora após a admissão, o paciente desenvolveu cianose e, no exame torácico, apresentou crepitações finas inspiratórias finais bilaterais. Na meia hora seguinte, a pressão arterial sistólica do paciente caiu para 80 mmHg e ele desenvolveu desconforto respiratório com hipóxia e alteração da consciência, sendo intubado. As cordas vocais do paciente estavam congestionadas e secreções espumosas cor-de-rosa saíam da glote. Ele foi colocado em ventilação mecânica. Apresentou acidose metabólica e respiratória (pH = 6.9930, HCO3− =15.5, e pCO2 = 64.3). ECG mostrou taquicardia sinusal. Raio X sugestivo de edema agudo de pulmão.  
O paciente recebeu ciclos de diurese forçada. O bicarbonato de sódio foi administrado por infusão contínua. Ele também foi iniciado com infusão de noradrenalina. Aproximadamente 12 horas após a admissão, sua pressão arterial melhorou para 100/60 mmHg. Após 18 h, o paciente desenvolveu diarreia aquosa. Ele ficou em estado alterado de consciência por 3 dias. Ele foi suplementado com tiamina injetável e a alimentação por sonda foi iniciada no 4º dia. O paciente ficou no ventilador mecânico por 7 dias. Ele foi gradualmente extubado. Testes de função hepática seriada e testes de função renal foram normais, com exceção do aumento da aspartato transferase sérica (AST) com relação AST / alanina transferase (ALT) de 1,34, consistente com doença hepática alcoólica. Após a extubação, o paciente foi transferido para a  
139

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|||Secreta|ria de Ciência, Te|cnologia e Insu|mos Estratégicos SCTIE<br>|
|---|---|---|---|---|---|
|**Quadro III.4.3.**Síntes<br> <br>|e de evidências pa<br> <br>|ra Tratame<br> <br>|nto por intoxicação<br> <br>|por Glifosato.<br> <br>|enfermaria e teve alta no dia 15.<br> <br>|
|**REFERÊNCIA**<br>|**DELINEAM.**<br>|**PICO**<br>|**DESFECHO**<br>|**TIPO DA**<br>**INTERVENÇÃO**<br>|**EVIDÊNCIAS DO ARTIGO**<br>|
|Jović-Stošić et al., 2016<br>|Relato de Caso<br>|1-3<br>|Descontaminação<br>Morbidade<br>|140<br>Uso de emulsão<br>intravenosa<br>lipídica<br>|Um homem de 50 anos (Sérvia) ingeriu 250 mL de herbicida que continha 48%<br>de glifosato como um sal de isopropilamina dissolvido em surfactante de<br>polioxietileno e água. Eu telefonei para a ambulância pouco depois, então fui<br>levado ao hospital local. O paciente estava alerta e agitado na apresentação<br>uma hora após a ingestão.<br>Como o paciente respondeu mal à terapia convencional, cerca de 2,5 h após a<br>admissão, a administração de emulsão lipídica intravenosa (ILE) foi iniciada.<br>Recebeu 100 mL de bolus de 20% de Intralipid® (ILE), seguido de uma infusão<br>de 400 mL durante 20 minutos. No momento em que a ILE foi iniciada, a<br>pressão arterial do paciente era de 70/40 mmHg e não houve melhora no<br>ECG. A elevação da pressão arterial foi notada cerca de 15 minutos após o<br>início da infusão. Após 2 h, o ritmo sinusal foi restabelecido, a pressão arterial<br>atingiu o valor de 120/75 mm Hg e o paciente começou a responder aos<br>estímulos. Manteve-se estável, e a infusão de dopamina foi cessada. Sete<br>horas após a admissão, o paciente estava alerta, com achados clínicos<br>normais, exceto por dor de garganta e pneumonia leve e incipiente no pulmão<br>esquerdo.<br>~~L~~|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|Ozaki et al, 2017|Relato de Caso|1-3|Intoxicação grave<br>por glifosato-<br>surfactante –<br>Morbimortalida-<br>de|Hemodiafiltração<br>contínua e<br>hemoperfusão<br>direta|Uma mulher de 65 anos ingeriu, acidentalmente, 100 mL de glifosato-<br>surfactante (GlySH) e chamou uma ambulância após 5h da ingestão.<br>Ao chegar ao hospital, a paciente estava com hipoxemia, hipercalemia,<br>hipotensão, o exame de sangue mostrou hemoconcentração (hematócrito<br>50,4%, hemoglobina 17,5g/dL), lesão renal aguda (creatinina 1,9 mg/dL) e<br>acidose metabólica. A tomografia computadorizada mostrou pneumonite por<br>aspiração e íleo do intestino.|
|---|---|---|---|---|---|
||||||A dopamina foi administrada para hipotensão não responsiva à ressuscitação<br>com fluidos, e o manejo da ventilação foi iniciado para tratar hipoxemia devido<br>a edema pulmonar.  50 gramas de carvão ativado e 200 mL de sorbitol foram<br>administrados por sonda nasogástrica e a hemodiafiltração contínua (CHDF) foi<br>iniciada para tratar a acidose metabólica progressiva. Como se considerou a<br>intoxicação do surfactante como a principal causa de seus sintomas, começou-<br>se a hemoperfusão direta (DHP), usando Medisorba DHP (Kawasumi Lab. Inc.,<br>Tóquio, Japão), em paralelo com o CHDF para remover o surfactante. De fato,<br>a**hipotensão e a acidose metabólica**progressiva, melhoraram imediatamente<br>após o início da DHP. Após 2 h de DHP, o tratamento foi interrompido devido à<br>eficácia clínica. O volume de urina aumentou no segundo dia, o CHDF foi<br>interrompido no terceiro dia. Seu curso clínico foi bom e ela foi transferida para<br>um hospital de reabilitação 28 dias após a admissão.<br>Esse caso refere-se a uma paciente com intoxicação grave por GlySH que foi<br>tratada com sucesso com uma combinação de DHP e CHDF para remover o<br>surfactante e o glifosato, respectivamente.|  
141  
|Camacho e Mejia, 2017|Não é escopo||||Não aborda tratamento|
|---|---|---|---|---|---|
|Kim et al, 2016|Coorte<br>retrospectiva<br>(Coreia do Sul)|Segui-<br>mento|Mortalidade após<br>ingestão glifosato<br>com surfactante|Niveis séricos de<br>Lactato  como<br>preditor de<br>mortalidade|O artigo analisou a relação entre os níveis de**lactato**e mortalidade por<br>envenenamento por surfactante com glifosato. Esta análise retrospectiva<br>envolveu 232 pacientes que foram internados no departamento de emergência<br>após intoxicação por glifosato-surfactante entre janeiro de 2004 e junho de<br>2014 – na Coreia do Sul. O lactato tem sido usado para predizer a gravidade da<br>doença e o risco de mortalidade em muitos processos, incluindo intoxicações,<br>sepse, cirurgia, queimaduras e trauma (intro). A concentração elevada de|  
142  
|lactato sérico é uma manifestação simples de disfunção orgânica. Na prática, a|
|---|
|determinação dos níveis circulantes de lactato é tecnicamente viável,<br>comumente usada e clinicamente disponível.|
|O estudo sugere que alguns fatores de risco independentes devem ser<br>avaliados assim que os pacientes chegam à emergência, devido a ingestão de<br>glifosato-surfactante. A saber, lactato sanguíneo e ECG: estes podem ajudar o<br>médico a identificar pacientes que provavelmente progredirão para um estado<br>crítico durante o tratamento inicial da intoxicação por glifosato-surfactante.|
|Os níveis de lactato foram mensurados na chegada do paciente ao Pronto<br>Atendimento.<br>No presente estudo, a diferença no nível de potássio entre os grupos alto e<br>baixo-lactato não foi clinicamente significativa; no entanto, a diferença entre<br>os casos fatais e não fatais foi significativa (fatal: 4,8 ± 1,4 mmol / L; não fatal ±<br>4,0 ± 0,5 mmol / L; p <0,001).**Especificamente, pacientes com nível de lactato>**<br>**4,7 mmol/L apresentaram um risco três vezes maior de mortalidade em até**<br>**30 dias do que outros pacientes durante o acompanhamento. O lactato foi**<br>**significativamente maior em não-sobreviventes (6,5 ± 3,1 mmol / L) do que**<br>**em sobreviventes (3,3 ± 2,2 mmol / L; p <0,001)**, e o lactato elevado foi<br>significativamente associado com mortalidade em 30 dias.<br>O intervalo QTc foi significativamente maior em não-sobreviventes [529 ms<br>(498-563 ms)] do que em sobreviventes [461 ms (437- 480 ms); p <0,001].<br>50% dos pacientes que desenvolveram hipercalemia morreram, e encontrou-<br>se dois pacientes nos quais o produto ingerido continha sal de potássio<br>glifosato. Quando os pacientes ingerem uma grande quantidade de glifosato-|  
143  
||||||surfactante contendo sal de potássio, os médicos devem considerar a<br>possibilidade de hipercalemia.<br>Os níveis de lactato, bem como a idade, o intervalo QTc (ECG) e os níveis de<br>potássio, estão associados à mortalidade em 30 dias em pacientes com<br>intoxicação aguda por glifosato-surfactante.|
|---|---|---|---|---|---|
|Levine et al., 2016|Revisão sistemática||||O único estudo observacional que avaliou os efeitos terapêuticos potenciais<br>da adm de emulsão lipídica endovenosa ILE a 20% para ingestão aguda de<br>glifosato foi o de Gil et al., 2013 (resumo nessa tabela)|
|Chan et al., 2016|Relato de Caso<br>(Taiwan)|1 -3|Morbidade por<br>intoxicação aguda|Tratamento com<br>Oxigenação por<br>membrana<br>extracorpórea e<br>hemodiálise|Um homem de 47 anos ingeriu, aproximadamente, 100mL de glifosato-<br>surfactante 1,5 horas antes da apresentação ao Pronto Atendimento.<br>Inicialmente, o paciente estava sonolento com escore de Glasgow de 13<br>(E3M6V4), vômito e diaforético. Os sinais vitais na chegada do departamento<br>de emergência foram os seguintes: pressão arterial, 143 / 91mm Hg; pulso, 72<br>batimentos / min; respiração, 20 respirações / min; e temperatura, 36°C. O<br>exame físico mostrava úlceras orais, salivação excessiva, crepitações difusas na<br>ausculta do tórax e achados pouco notáveis para o coração, abdomen, órgãos<br>genitais e reto. O eletrocardiograma revelou um QRS largo com duração de 134<br>ms e prolongado**QTc de 550ms**. Apresentou insuficiência respiratória,<br>taquicardia ventricular persistente, choque profundo refratário a agentes<br>inotrópicos e acidose metabólica desenvolvida no paciente em até 2 horas.<br>A gasometria após a intubação revelou acidose metabólica persistente.|  
144  
|||||Foi aplicada uma oxigenação por**membrana extracorpórea**venoarterial (VA-<br>ECMO) iniciada 3 horas após a admissão, devido à hipotensão profunda<br>persistente após a administração de agente duplo inotrópico (norepinefrina, 10<br>μg/kg/min e dopamina 8 μg/kg/min). A hemodiálise veno-venosa contínua<br>(CVVH) também foi aplicada simultaneamente com ECMO. A condição do<br>paciente melhorou consideravelmente. O ECG mostrou taquicardia sinusal um<br>dia depois. Retirou-se a cânula de ECMO e CVVH após o 2<sup>o</sup>e 4<sup>o</sup>dias,<br>respectivamente. A extubação foi realizada no sétimo dia. Ele foi transferido<br>para uma enfermaria geral no oitavo dia após a observação de um estado<br>hemodinâmico estável.<br>Conclusões: Este foi o primeiro caso em que a oxigenação por membrana<br>extracorpórea foi usada para tratar a intoxicação grave por glifosato-<br>surfactante. Os autores recomendam o início precoce da terapia de oxigenação<br>por<br>membrana<br>extracorpórea<br>para<br>mitigar<br>o<br>comprometimento<br>cardiopulmonar em pacientes com intoxicação por glifosato-surfactante.|
|---|---|---|---|---|
|Wimalawansa 2016|Não é escopo|||Não relata tratamento|
|You et al., 2015|Relato de Caso  -<br>República da<br>Coreia|1 - 3|Morbidade|Mulher em tentativa de suicídio, 44 anos, ingeriu 20 mL de glifosato. Doze dias<br>após a tentativa de suicídio, a paciente apresentou febre alta e mialgia geral.<br>Devido a seus sintomas, ela foi para o Pronto Atendimento. Na admissão, a<br>pressão arterial era de 80/60 mmHg, o pulso era de 70/min, a taxa de<br>respiração era de 18/min e a temperatura era de 38,0°C.<br>Estudos laboratoriais revelaram contagem leucocitária de 2010/ml, nível de<br>hemoglobina de 14,2 g / dl, contagem plaquetária de 80 000 / ml, creatinina<br>sérica de 3,59 mg /dl,nível de aspartato aminotransferase de 2428 UI/L,nível|  
145  
||||||de alanina amino transferase de 1213 UI / l, nível de bilirrubina total de 0,30<br>mg/dL, nível de hs-CRP de**20,77 mg/L**, e nível de PCT de**1,08 ng/ml**.<br>A análise urinária revelou pyuria (piúria) (contagem de leucócitos> 30/HPF).<br>Além disso, a tomografia computadorizada (TC) de alta resolução do tórax<br>revelou<br>broncopneumonia<br>aguda<br>no<br>lobo<br>inferior<br>esquerdo.<br>A<br>antibioticoterapia inicial incluiu cefepima e azitromicina por 8 dias. No entanto,<br>a febre persistiu, o nível de hs-CRP aumentou abruptamente para**107,49 mg/L**,<br>e o nível de PCT aumentou para**3,53 ng/ml**durante o tratamento com<br>antibióticos._C. tertium_foi isolada das amostras de sangue iniciais de um cateter<br>central. Os antibióticos foram alterados para ertapenem e metronidazol. Após<br>16 dias de antibioticoterapia adequada, seus sintomas e sinais clínicos<br>desapareceram completamente e ela recebeu alta.<br>Não está claro se o_C. tertium_foi um contaminante ou um verdadeiro patógeno.<br>No entanto, o paciente tinha um fator de risco definido para bacteremia por_C._<br>_tertium_como uma complicação da ingestão de glifosato. A ingestão de glifosato<br>pode ser um fator predisponente para a patogênese da bacteremia por C.<br>tertium.|
|---|---|---|---|---|---|
|Garlich et al., 2014|Relato de Caso<br>(EUA)|1-3|Morbidade/<br>Mortalidade por<br>ingestão de<br>glifosato|Hemodiálise<br>como forma de<br>tratamento de<br>intoxicação aguda<br>grave|Caso: Homem de 62 anos (Canadá/EUA) foi levado ao hospital após 8,5 h depois<br>de beber um frasco de herbicida comercial contendo uma solução a**41% de**<br>**isopropilamina** **glifosato, em surfactante POEA e água**(marca Ortho TotalKill,<br>**Monsanto**). Ele foi inicialmente encontrado inconsciente em sua garagem após<br>uma tentativa suspeita de suicídio. Uma garrafa de etanol e um opioide<br>desconhecido também estavam presentes. Sua história médica pregressa foi|  
146  
|significativa para doença arterial coronariana, diabetes mellitus tipo II,|
|---|
|hipertensão, câncer de pulmão, trombose venosa profunda e depressão.|
|**Detalhes do caso:**paciente chegou ao hospital,**letárgico com depressão**|
|**respiratória**e necessitou de intubação e ventilação mecânica. Os resultados|
|laboratoriais iniciais foram significativos para pH 7,11; PCO2, 64 mmHg; PaO2,|
|48 mmHg; potássio, 7,8 mEq / L; Cr 3,3 mg / dL (aumento de 0,95 mg / dL 3<br>meses antes); BUN, 30 mg / dL; bicarbonato, 22 mEq / L; anion gap, 18 mEq / L;|
|lactato, 7,5 mmol / L; amilase, 364 U / L; hematócrito, 46,9%; e uma glicose de|
|419 mg / dL. A creatina quinase foi de 113 U / L, e as troponinas em série,|
|salicilato de soro, acetaminofeno, etanol, metanol e concentrações de|
|etilenoglicol foram negativas.**Um exame toxicológico de urina foi positivo**<br>**para benzodiazepínicos**. Um ECG mostrou um ritmo juncional a uma taxa de|
|42 batimentos/min com uma duração de**QRS de 172 ms.**|
|A**hipercalemia e a acidose do paciente persistiram**apesar da ventilação<br>mecânica, ressuscitação endovenosa e administração de bicarbonato de sódio,<br>insulina e instilação nasogástrica de poliestireno sulfonato de sódio (uma<br>concentração repetida de potássio foi de 6,7 mEq/L e pH 7,25). Ele foi|
|submetido a**hemodiálise**16 horas após a ingestão, como tratamento para|
|hipercalemia refratária e acidose persistente. A hemodiálise foi realizada com|
|uma membrana Opti ux F160NR (Fresenius) a uma vazão de sangue de 200|
|mL/min por 2,5 h. A concentração sérica de glifosato obtida antes da|
|hemodiálise foi de 240 mcg / mL, que diminuiu para 92,6 mcg / mL após a<br>diálise.|  
147  
||||||Repetido os estudos laboratoriais após hemodiálise e foram significativos para<br>potássio, 4,4 mEq/L; creatinina, 2,1 mg/dL; BUN, 23 mg/dL; bicarbonato 26<br>mEq/L; pH 7,50, PCO2 35 mmHg; PO2, 73 mmHg; e lactato, 1,6 mmol/L. O<br>paciente foi extubado e subsequentemente permaneceu alerta com sinais<br>vitais estáveis. Sua função renal continuou a melhorar e ele foi transferido da<br>UTI no dia 3. Uma semana após a apresentação, as concentrações séricas de<br>uréia e creatinina foram de 17 e 0,8 mg / dL, respectivamente. A repetição do<br>ECG mostrou ritmo sinusal normal com duração de QRS de 98 ms.<br>O artigo relata que a**hemodiálise**pode ser uma modalidade de tratamento útil<br>em pacientes com intoxicação por glifosato-surfactante grave, complicada por<br>acidose metabólica, anormalidades eletrolíticas, lesão renal aguda ou<br>comprometimento respiratório. O glifosato foi removido com sucesso por<br>hemodiálise, com uma taxa de depuração de 97,5 mL/min. O uso precoce de<br>hemodiálise em um paciente grave intoxicado por GlySH foi associado a um<br>bom resultado clínico. A hemodiálise pode ser considerada quando houver<br>acidose grave, lesão renal aguda ou outros marcadores de mau prognóstico.|
|---|---|---|---|---|---|
|Gil et al., 2013|Estudo<br>prospectivo de<br>Caso- controle<br>(República da<br>Coreia)|1-2|Mortalidade/<br>Morbidade|Adm de<br>emulsão lipídica<br>intravenosa|O estudo objetivou analisar potenciais efeitos terapêuticos da emulsão<br>lipídica intravenosa (ILE) nos pacientes com intoxicação aguda por glifosato<br>por auto-ingestão (entre 2010 e 2012)<br>Este estudo envolveu 64 pacientes intoxicados com glifosato organizados em<br>dois grupos: tratados com ILE (grupo ILE, 22 pacientes) e pacientes controle<br>tratados apenas com tratamento de suporte (conservador- 22 pacientes). O<br>tratamento conservador, incluindo cerca de 1 a 3 litros de injeção<br>intravenosa, foi aplicado a todos os pacientes. Vasopressor, norepinefrina|  
148  
|seguido de vasopressina, foi injetado em caso de necessidade de hipotensão.|
|---|
|Os pacientes-controle foram selecionados por correspondência para a<br>quantidade ingerida e tempo desde a ingestão. A quantidade de surfactante<br>ingerido foi estimada a partir da proporção (% volume) do surfactante e do<br>volume total do herbicida ingerido e não diferiram entre os 2 grupos.|
|A lavagem gástrica foi realizada no caso de todos os indivíduos que se<br>apresentaram na sala de emergência dentro de 2 horas após a ingestão. Não<br>houve diferença na modalidade de tratamento (exceto para o ILE) entre o<br>grupo ILE e o grupo controle. Com base na quantidade de ingestão,<br>classificou-se o grupo controle e o grupo ILE nos subgrupos com ingestão<br><100 ml e>100 ml em cada grupo, formando**4 subgrupos**. Todos os pacientes<br>foram mantidos em observação na unidade de terapia intensiva por pelo<br>menos 24 horas após a admissão.|
|Emulsão lipídica intravenosa (ILE): o produto da emulsão lipídica a 20% foi<br>injetado intravenosamente, a uma velocidade de 20 mL/h para os pacientes<br>que ingeriram menos de 100 mL de glifosato. Aqueles que haviam ingerido<br>um volume maior ou igual 100 mL de herbicida glifosato não diluído,<br>esperavam-se sinais de intoxicação grave e, para esses pacientes, a dose<br>inicial foi de 500 ml em 2 a 3h, dependendo do estado do paciente, seguida<br>por uma dose de manutenção de 1.000 ml nas próximas 24h.<br>Como resultado, 13 pacientes receberam altas doses de ILE  pois a quantidade<br>de ingestão foi superior a 100 ml.|  
149  
|A incidência de insuficiência respiratória aguda no grupo ILE foi menos da<br>metade do grupo controle (13,6% vs. 31,8%, respectivamente).<br>A incidência de hipotensão no grupo ILE (0% vs. 40,9%, respectivamente, p<br><0,001) e arritmia (0% vs. 22,7%, respectivamente, p <0,048) foi<br>significativamente menor do que no grupo controle.<br>Nenhum no grupo ILE morreu ou sofreu lesão renal aguda.|
|---|
|Não se conhece o mecanismo preciso do efeito da emulsão lipídica na<br>toxicidade dos herbicidas glifosato, em humanos. No entanto, lembrando que<br>o surfactante, e não o próprio glifosato, foi sugerido como o agente<br>responsável pelo quadro de toxicidade, acredita-se que a emulsão lipídica<br>atenue o efeito tóxico dos surfactantes, em humanos. Quatro tipos de<br>ingredientes foram detectados nas formulações dos herbicidas à base de<br>glifosato ingeridos pelos sujeitos do estudo (em ordem de frequência<br>detectada): (1) amina de polioxietileno (TN-20), (2) composto de amônio<br>quaternário (coco alquilbis [hidroxietil]), (3) alquildimetilamina betaína, (4)<br>propilenoglicol, dimetil polissiloxano, alcoxilato de álcool alquílico. A<br>frequência de detecção foi comparável entre o grupo ILE e o grupo controle.<br>O TN-20 foi o surfactante mais comumente detectado (grupo ILE: 15 de 22<br>casos, grupo controle: 19 de 22 casos).|
|Em conclusão, a administração de ILE foi associada com menor incidência de<br>hipotensão e arritmia em pacientes com intoxicação aguda por glifosato. A<br>administração de ILE parece ser um tratamento eficaz em pacientes que<br>ingeriram glifosato.|  
150  
|Mariager et al., 2013|Relato de Caso|1-3|Morbidade<br>associada à<br>exposição por via<br>dérmica ao<br>glifosato-<br>surfactante|Queimaduras e<br>dano ósseo|Este é um caso de queimaduras químicas graves após exposição acidental<br>prolongada ao glifosato-surfactante.<br>Caso: Homem, de 48 anos, tinha corrosões na pele, na mão e no braço<br>esquerdo, no lado esquerdo do peito e na perna esquerda. Dois dias antes, ele<br>usara um concentrado de glifosato-surfactante dado a ele por um vizinho em<br>uma garrafa plástica de meio litro. Ele diluiu o herbicida com água, sacudiu a<br>garrafa e acidentalmente borrifou o líquido em si mesmo. No dia seguinte, as<br>áreas afetadas começaram a inchar, especialmente seu braço, e no segundo<br>dia, vesículas, bolhas e feridas exsudativas apareceram em seu braço e mão, e<br>também em seu peito e perna. Devido ao toque das mãos, teve também um<br>edema periorbital e vermelhidão no lado esquerdo da cabeça. Sugere-se que o<br>surfactante aumenta a penetração em casos de exposição prolongada e pode<br>resultar no dano cutâneo, de músculos e revestimento nos axônios. A atrofia<br>dos músculos da mão pode ser o resultado do efeito nervoso, mas também<br>pode ser um efeito cáustico direto. Sugere-se que a elevação inicial dos níveis<br>de mioglobina e creatina quinase ilustram dano muscular primário. As feridas<br>aparentemente foram curadas sem complicações, mas o paciente passou por<br>total falta de sensibilidade em sua mão esquerda, que somente retornou após<br>9 meses de acompanhamento médico.|
|---|---|---|---|---|---|
|Zouaoui et al., 2013|Relato de Caso -<br>clínico com análise<br>laboratorial|1, 3|Mortalidade|Sinais e sintomas,<br>exames (não<br>aborda<br>tratamento)|Entre os 10 pacientes analisados (França), um era assintomático, cinco tinham<br>intoxicação leve a moderada e dois tinham intoxicação grave. Houve 6 óbitos,<br>dos quais 3 eram casos forenses (post mortem). Os sintomas mais comuns<br>foram ulceração orofaríngea (5/10), náuseas e vômitos (3/10). Os principais|  
151  
||||||parâmetros biológicos alterados foram alto lactato (3/10) e acidose (7/10).<br>Observou-se também dificuldade respiratória (3/10), arritmia cardíaca (4/10),<br>dor de garganta (5/10), hipercalemia, comprometimento da função renal<br>(2/10), toxicidade hepática (1/10) e alteração da consciência (3/10). Nas<br>fatalidades, os sintomas comuns foram choque cardiovascular, parada<br>cardiorrespiratória,<br>distúrbio<br>hemodinâmico,<br>coagulação<br>intravascular<br>disseminada e falência múltipla de órgãos.**Encontrou-se forte correlação**<br>**sintomatologia-concentração de glifosato no sangue.**Na sintomatologia<br>benigna ou moderada, as concentrações sanguíneas de glifosato observadas e<br>descritas na literatura não excedem 150 mg/L. Na sintomatologia grave: as<br>concentrações sanguíneas de glifosato observadas e descritas na literatura são<br>geralmente superiores a 1000 mg/L. Nas 3 fatalidades (tratadas nos casos de<br>serviço/não forense), notou-se concentrações de glifosato no sangue<br>superiores a 5.000mg/L. A morte foi, na maioria das vezes, associada à maior<br>dose ingerida (500 mL em um paciente) e altas concentrações de glifosato no<br>sangue. Os autores também concluem que o glifosato é muito pouco<br>metabolizado em AMPA. Para prever os resultados clínicos e orientar o apoio<br>ao tratamento em pacientes que ingeriram o glifosato, as concentrações<br>sanguíneas desse composto e a dose ingerida seriam úteis.|
|---|---|---|---|---|---|
|Kimmel et al., 2013|Não é escopo||||Estudo em coelhos e em ratos – não é escopo|
|Deo e Shetty 2012|Relato de Caso<br>(Índia)|1|Lesão oral /<br>mucosas|Pomada de<br>benzocaína e<br>fisioterapia local|Homem de 25 anos, entrou em contato com glifosato-surfactante (Roundup) na<br>mucosa oral, ao tentar abrir o frasco com a boca. Após 3 dias, foi ao Pronto<br>Atendimento com queixa de dificuldade para engolir e feridas orais, há 2 dias.|  
152  
||||||As feridas formaram úlceras, edemas e queimaduras na língua, lábios e mucosa<br>oral.<br>O local foi, cuidadosamente, limpo com soro fisiológico (pois qualquer outro<br>agente químico utilizado aumentava as feridas) e foi aplicada pomada local de<br>benzocaína (20%) e realizado sessões de fisioterapia ativa (alongamento boca,<br>cerração dos dentes, movimento de assovio, etc.). As úlceras melhoraram após<br>1 semana.|
|---|---|---|---|---|---|
|Carroll et al., 2012|Coorte<br>prospective (Sri<br>Lanka)|Segui-<br>mento|Morbidade –<br>gravidade<br>intoxicação ao<br>longo do tempo|Cronotoxici-<br>dade por<br>ingestão de<br>glifosato|Os pesquisadores examinaram pacientes com intoxicação aguda para<br>buscar evidências de variação diurna na probabilidade de sobrevivência<br>– entre 2002 a 2009.<br>Foram investigados 14.840 pacientes internados após a auto-<br>intoxicação por semente de oleandro amarelo (_Cascabela thevetia_) ou<br>agrotóxico [organofosforado (OP), carbamato, paraquat, glifosato] por<br>variação na sobrevivência de acordo com o tempo de ingestão.<br>Foi encontrado pouca evidência de uma relação entre o tempo de<br>ingestão e a letalidade após a auto-intoxicação por carbamida, paraquat<br>ou glifosato (P =0,221, P=0,076 e P=0,437, respectivamente, após ajuste<br>para idade, sexo, tempo de internação, ano de internação e horário de<br>apresentação).|  
153  
|Hour et al., 2012|Relato de Caso<br>(EUA)|1, 2|Morbidade:<br>intoxicação<br>grave|Hemodiafiltra-<br>ção venovenosa<br>contínua|Um indivíduo hispânico de 66 anos com história de diabetes não<br>insulino-dependente, hipertensão e abuso de álcool foi levado ao<br>pronto-socorro inconsciente após ter ingerido aproximadamente 500<br>mL de rum e 350 mL de Roundup. Ele estava em uma discussão com sua<br>esposa e acidentalmente misturou seu álcool com o Roundup.<br>Aproximadamente duas horas depois, ele teve status mental alterado,<br>um episódio de emese não-hemorrágica, e foi mais difícil de despertar.<br>Ao chegar ao Serviço de Emergência, ele estava hipotenso (pressão<br>arterial 87/45 mm Hg), diaforético e hipoxêmico. Ele teve uma<br>pontuação de 5 na Escala de Coma de Glasgow. Seus achados<br>laboratoriais foram notáveis por hipóxia e acidose láctica profunda, com<br>um alto anion gap e pequeno gap osmolar. Ele foi intubado, ventilado e<br>administrado em bolus com 2L de solução salina normal e 1L de<br>bicarbonato de sódio. No entanto, ele se deteriorou rapidamente em<br>choque, com pressão arterial de 66/43 mm Hg juntamente com lesão<br>renal aguda, hipercalemia, leucocitose e agudização da acidose láctica,<br>exigindo alta dose de Levophed (Hospira, Lake Forest, Ill) e vasopressina,<br>para suporte de pressão. Devido ao seu comprometimento<br>hemodinâmico, iniciou-se a hemodiafiltração venovenosa contínua.<br>Dentro de 24 horas, sua condição melhorou e interrompeu-se o método<br>após 60h.|
|---|---|---|---|---|---|  
154  
|You et al., 2012|Relato de caso|1-3|Mortalidade:<br>casos graves de<br>ingestão de<br>glifosato e<br>tratamento inicial|Uso de emulsão<br>lipídica<br>intravenosa (ILE)|Paciente do sexo masculino de 65 anos ingeriu 150 mL de glifosato-<br>surfactante em tentativa de suicídio. Ele estava sonolento na apresentação no<br>Pronto Atendimento, e sua pressão arterial sistólica, frequência cardíaca e<br>frequência respiratória eram 50 mm Hg, 84 batimentos/min (bpm) e 15<br>resp/min, respectivamente.**Foi realizada a lavagem gástrica e 50 g de carvão**<br>**ativado foram administrados**. Seus sinais vitais foram os seguintes: pressão<br>arterial, 70/40 mm Hg; frequência cardíaca de 76 bpm; e temperatura<br>corporal, 35°C. Sua respiração estava conectada a um ventilador mecânico.|
|---|---|---|---|---|---|
||||||Resultados eletrocardiográficos e ecocardiográficos mostraram que o<br>paciente acelerou o ritmo idioventricular. Estava com quadro de acidose - pH,<br>7.03.<br>Foi injetado um bolus de 1,5 mL/kg de SMOFlipid a 20% (Fresenius Kabi, Bad<br>Homburg, Alemanha). Imediatamente após a injeção, o eletrocardiograma se<br>alterou; sua pressão arterial, frequência cardíaca e temperatura corporal<br>eram 90/30 mm Hg, 77 bpm e 35°C, respectivamente. Uma dose contínua de<br>20% de SMOFlipid (0,25 mL/kg; Fresenius Kabi) foi injetada por mais de 20<br>minutos. O pH, pCO2, pO2 e HCO3do paciente foram 7,06, 52 mmHg, 144<br>mmHg e 14,7 mEq/L, respectivamente, e a SaO2foi de 98% com uma taxa de<br>fluxo de O2de 6 L/min.|
||||||Após 2 dias, o paciente apresentou anúria e foi tratada com terapia de<br>substituição renal contínua por 7 dias. Ele recebeu alta do hospital sem<br>complicações sérias.|  
155  
||||||Portanto, os autores sugerem que a terapia com**emulsão lipídica intravenosa**<br>também pode ser usada para tratar pacientes comprometidos<br>hemodinamicamente que apresentam colapso cardiovascular devido à<br>intoxicação por surfactante glifosato.|
|---|---|---|---|---|---|
|Seok et al., 2011|Transversal|1-3|Morbidade e<br>Mortalidade,<br>Seguimento|Lavagem gástrica,<br>hemodiálise e<br>prognóstico a<br>partir do volume<br>de surfactante<br>ingerido e tipo|O objetivo do estudo foi determinar a toxicidade do surfactante do glifosato<br>em pacientes com intoxicação aguda por glifosato.<br>Foram levantados 107 pacientes (69 homens e 38 mulheres, com idade entre<br>52,3 e 15,5 anos) com intoxicação aguda por glifosato (Coréia). A partir de seus<br>prontuários, identificou-se a formulação de produtos de glifosato ingeridos e<br>parâmetros clínicos derivados. Na admissão, os pacientes receberam<br>procedimentos padronizados de emergência médica.**Lavagem gástrica foi**<br>**realizada no caso de todos os indivíduos que se apresentaram na sala de**<br>**emergência dentro de 2 horas após a ingestão. A hemodiálise foi iniciada**<br>**precocemente se os pacientes chegassem ao hospital dentro de oito horas**<br>**após a ingestão.**Do total, 2 pacientes (68 e 73 anos) morreram e apresentaram<br>**estado mental sonolento, hipotensão e insuficiência respiratória aguda com**<br>**acidose metabólica grave**.<br>A quantidade de surfactante ingerido (18,5+17,1 mL) foi estimada a partir da<br>proporção (% volume) do excedente e volume total do herbicida ingerido.<br>**(Tabela 1 do artigo – muito relevante* anexo abaixo)**<br>**A incidência geral de complicações clínicas foi (em ordem de classificação):**<br>**hipotensão, 41 casos (38,3%); deterioração mental, 33 (30,8%); insuficiência**<br>**respiratória, 25 (23,4%); dano agudo renal, 15 (14,0%); e arritmia, 9 (8,4%).**<br>Pacientes do grupo com escore de gravidade 2 ingeriram maior volume de|  
156  
|surfactante do que aqueles com escore de gravidade 1 (O escore de gravidade<br>do envenenamento (SSP) foi avaliado no momento da admissão: 0, sem<br>sintomas ou sinais; 1 sintomas ou sinais leves, transitórios e de resolução<br>espontânea; 2 sintomas ou sinais pronunciados ou prolongados; 3, sintomas ou<br>sinais graves ou com risco de vida; 4 morte).|
|---|
|A quantidade de surfactante ingerido (mL) foi correlacionada  positivamente<br>com os dias de permanência na UTI (r=0,274, p<0,004), duração da intubação<br>(r=0,300, p<0,002) e contagem de leucócitos (r=0,373, p<0,001) e correlação<br>negativa com pH inicial (r=-0,365, p<0,001) e HCO3<sup>-</sup>(r = -0,380, p<0,001).<br>**O volume de surfactante foi mais relevante para complicações clínicas do que**<br>**para o volume de glifosato**: hipotensão, RR, 1,047 (IC, 1,017-1,077; p=0,002)<br>vs. RR, 1,017 (p=0,003); insuficiência respiratória, RR, 1,033 (IC, 1,006-1,060;<br>p=0,016) vs. RR, 1,010 (p=0,040); lesão aguda renal, RR, 1.042 (CI, 1.012–1.074;<br>p=0,006) vs. RR, 1,013 (p=0,029); e deterioração mental, RR, 1,032 (CI, 1.006–<br>1.059; p=0,015) vs. RR, 1.012 (p=0,024).**Não houve diferença de sintomas**<br>**entre os grupos de diferentes fórmulas dos surfactantes e sim, pelo volume**<br>**ingerido.**|
|Os resultados indicam que pacientes que ingerem grandes volumes de<br>surfactante correm maior risco de hipotensão, deterioração mental,<br>insuficiência respiratória e arritmias, particularmente quando se ingere<br>volumes de surfactante>8 mL. Diante disso, acredita-se que os toxicologistas<br>clínicos devem estar cientes do volume de surfactantes para o tratamento de<br>intoxicação aguda por glifosato.|  
157  
|Pedroso et al., 2010|Coorte histórica|1-3|Mortalidade|Uso do carvão<br>ativado, lavagem<br>gástrica e diálise|Como objetivo, o trabalho tentou determinar a incidência de emprego de<br>métodos dialíticos no manejo de intoxicações graves, a sua necessidade e<br>eficácia. Entre 1998 e 2000, foi realizada a revisão das fichas de atendimento<br>dos casos de intoxicação aguda registrados no Centro de Informação<br>Toxicológica do Rio Grande do Sul (CIT-RS) e a escolha das categorias dos<br>agentes tóxicos (medica- mentos e agrotóxicos/uso agrícola) foi feita<br>considerando os dados do Sistema Nacional de Informações (SINITOX).<br>Os critérios objetivos empregados para enquadramento na categoria de<br>gravidade consistiam em extremos etários (crianças ou idosos), tipo de agente<br>químico envolvido, sinais ou sintomas no decorrer da evolução (como coma,<br>convulsões, necessidade de internação em UTI, emprego de assistência<br>ventilatória) ou desfecho do acidente. Isso resultou em 245 atendimentos. Os<br>agrotóxicos foram responsáveis por 36,3% dos casos e compreenderam os<br>organofosforados, compostos bipiridílicos (paraquat e diquat) e glifosato.<br>Quanto ao emprego de lavagem gástrica ou uso de antídotos no manejo da<br>intoxicação, não foi evidenciada relação entre seu uso e a ocorrência (redução)<br>de óbito (p=0,254 e 0,128, respectivamente). Já para o carvão ativado, seu<br>emprego está associado à redução de óbito, para um p obtido igual a 0,01. No<br>tocante à alcalinização urinária, houve relação entre seu emprego e redução de<br>óbito (p = 0,001). O fato de necessitar ou não de suporte ventilatório não<br>pareceu modificar o desfecho em questão (p = 0,695).|
|---|---|---|---|---|---|  
158  
|No grupo que dialisou, em 91%, a circunstância foi tentativa de suicídio|
|---|
|(principalmente<br>fenobarbital<br>e<br>paraquat).<br>Dois<br>casos<br>requereram<br>hemoperfusão (cloranfenicol e paraquat). Entre os 11 pacientes submetidos à<br>hemodiálise ou hemoperfusão houve 4 óbitos (36,3%), percentual maior de<br>óbitos que entre pacientes não dialisados (25,6%, n = 234), mas tal diferença<br>não foi significativa como fator de risco relativo (RR = 0,89, IC 95% = 0,54-1,35).<br>185 acidentes estudados apresentaram possibilidade teórica de indicação de<br>diálise ou hemoperfusão. Haveria indicação de ambos os procedimentos<br>(hemodiálise e/ou hemoperfusão) em 102 casos; exclusivamente de<br>hemodiálise em 20 casos; somente de hemoperfusão em 63 casos. A incidência<br>de óbitos entre todos os casos em que haveria alguma indicação de<br>procedimento dialítico (n = 185) foi de 24,8% (46 óbitos, p < 0,05; IC 95% =<br>18,6%-31%). Dentre os casos sem indicação teórica de procedimento dialítico<br>(n = 60), a incidência de óbitos foi de 30% (18 óbitos, p < 0,05; IC 95% = 18,5%-<br>41,5%).|
|Quanto aos casos em que houve registro em prontuário de efetiva<br>recomendação de prescrição dialítica pelo toxicologista (n = 30), a incidência<br>de óbitos foi de 9 casos (30%, p < 0,05; IC 95% = 13,6%-46,4%).<br>A incidência de realização de procedimentos dialíticos em nosso meio é similar<br>à incidência mundial. Ainda que houvesse indicação para determinada<br>intoxicação, o método foi subutilizado ou teve sua instituição protelada, o que<br>pode ter sido responsável por desfechos desfavoráveis.|  
159  
|Sato et al., 2011|Relato de Caso|--<br>Seguimento/<br>Morbidade|Meningite após<br>intoxicação por<br>glifosato|Uma mulher de 58 anos ingeriu aproximadamente 150 mL de Glifosato -<br>surfactante contendo 41% de glifosato e 15% de polioxietileneamina. Dois dias<br>depois, ela foi internada no Centro de Emergência em estado semicomatoso.<br>Alguns sinais e sintomas físicos anormais incluíam crepitações pulmonares<br>bilaterais, anúria e petéquias em todo o corpo. Exames laboratoriais revelaram<br>distúrbio de oxigenação (PaO2 94,2 mmHg inspirando 10L/min de O2com<br>máscara facial de oxigênio), acidose metabólica e depressão respiratória (pH<br>7,057, PaCO257,0 mmHg, BE -15,1 mmol/L, HCO3<sup>-</sup>15,7 mmol/L), leucocitose<br>(WBC 14400/uL), disfunção renal (BUN 88 mg/dL, Cr 8,64 mg/dL) e elevação da<br>CRP (10,4 mg/dL). Radiografia de tórax e TC mostraram infiltração difusa em<br>ambos os pulmões. TC do cérebro e ressonância magnética não revelaram<br>achados anormais.<br>Também se suspeitava de**meningite**, pois demonstrava o sinal de Kernig e<br>rigidez de nuca significativa com rigidez das extremidades, bem como<br>perturbação da consciência e febre (38,48ºC). Investigações do líquido<br>cefalorraquidiano (LCR) revelaram a presença de glifosato (122,5 mg / mL),<br>elevação significativa de IL-6 (394 mg / mL) e pleocitose (32 células / mL) com<br>dominância de monócitos. Todos os testes bacteriológicos e virológicos foram<br>encontrados posteriormente como negativos.<br>O presente caso sugere que a meningite asséptica pode ser responsável pelos<br>sinais e sintomas do SNC observados nos casos de intoxicação por Glifosato-<br>surfactante e, portanto, deve ser considerado na avaliação de pacientes com<br>intoxicação por Glifosato-surfactante.|
|---|---|---|---|---|  
160  
|Palli et al., 2011|Relato de Caso|1, 2|Morbidade: lesão<br>gastrintestinal|Lesão<br>gastrintestinal<br>grave|Um homem de 75 anos de idade foi admitido no serviço de emergência<br>(Grécia) após ingestão intencional de mais de 150 mL de glifosato-surfactante<br>em uma tentativa de suicídio.<br>O estado hemodinâmico do paciente piorou ainda mais nos dias subsequentes,<br>sendo necessário suporte hemodinâmico significativo com vasopressores e<br>inotrópicos. A função respiratória também foi severamente prejudicada<br>(PO2/FIO2<100) e foi tratada como Síndrome da Angústia Respiratória (_Acute_<br>_Respiratory Distress)_. Sua condição melhorou gradualmente ao longo dos<br>próximos 4 dias. No entanto, no 9<sup>o</sup>dia da unidade de terapia intensiva, o<br>paciente apresentava febre (39°C), distensão abdominal e diarreias. O paciente<br>foi submetido à exploração cirúrgica de urgência, que revelou peritonite devido<br>ao extenso relaxamento longitudinal do cólon descendente. O exame<br>histológico revelou erosões abundantes, formação de abscesso, necrose do<br>tecido gorduroso perientérico e reação fibroblástica sem evidência de isquemia<br>da mucosa. O paciente foi submetido a ressecção colônica e desvio de<br>colostomia e recebeu alta da unidade de terapia intensiva no 21º dia.<br>Esse caso pontua os efeitos gastrointestinais graves resultantes da intoxicação<br>por glifosato|
|---|---|---|---|---|---|
|Moon et al., 2010|Coorte<br>retrospectiva<br>(República Coreia)|1-3|Morbimortali-<br>dade|Tratamentos mais<br>utilizados,<br>lavagem gástrica,<br>carvão ativado e<br>diálise|Utilizaram o sistema de prontuário eletrônico hospitalar para obter o<br>prontuário de pacientes, entre 1998 e 2009 com diagnóstico de intoxicação por<br>glifosato, com idade acima de 18 anos. Foram selecionados 76 pacientes, 69,7%<br>amostra foi do sexo masculino e idade média de 55.1 ± 16.3 anos.<br>**Manifestação clínica:**|  
161  
|Estado mental alterado - 25 (32.9%)|
|---|
|Dor de garganta - 25 (32.9%)|
|Náusea / vômito - 16 (21.1%)|
|Dor abdominal - 15 (19.7%)|
|Diarreia - 3 (3.9%)|
|Dor no peito - 2 (2.6%)|
|**Anormalidades radiológicas:**17 (22.4%) – houve infiltração no pulmão em 7<br>pacientes e edema pulmonar em 10 pacientes, visto em radiografia de tórax<br>inicial.|
|**Anormalidades do ECG na entrada hospital:**|
|Prolongamento do QTc  - 30/58 (51.7%)|
|Taquicardia sinusal - 8/58 (13.8%)|
|Bloqueio AV de primeiro grau - 6/58 (10.3%)<br>Anormalidade ST-T - 6/58 (10.3%)|
|Bradicardia sinusal - 3/58 (5.2%)|
|Taquicardia de QRS larga - 1/58 (1.7%)|
|Lesão renal aguda foi detectada entre 1 e 21 h após a ingestão em nove<br>pacientes com lesão renal aguda|
|**Tratamento inicial/ seguimento:**|
|Lavagem gástrica dentro de 2 h - 34 (48.6%)|
|(Quantidade de lavagem gástrica (L) - 10 (1–17))<br>Administração de carvão vegetal - 15 (19.7%)|
|Hemodiálise - 3 (3.9%)|  
162  
||||||**Resultado:**<br>Duração da hospitalização (h)  - 152.8 ± 214.7<br>Morte - 2 (2.6%)<br>**Complicações dos pacientes intoxicados com glifosato:**<br>Acidose metabólica  - 28 (36.8%)<br>Insuficiência respiratória - 21 (27.6%)<br>Hipotensão - 14 (18.4%)<br>Pancreatite aguda - 9 (11.8%)<br>Lesão renal aguda - 9 (11.8%)<br>Parada cardíaca - 4 (5.3%)<br>Hipercalemia - 4 (5.3%)|
|---|---|---|---|---|---|
|Han et al., 2010|Relato de Caso<br>(República da<br>Coréia)|1-3|Morbidade|Estabilização e<br>início do<br>tratamento, uso<br>de emulsão<br>lipídica<br>intravenosa|Trata-se de um caso de intoxicação por Glifosato-surfactante com choque<br>refratário aos vasopressores, mas responsivo à emulsão gordurosa<br>intravenosa. Homem de 52 anos foi encontrado inconsciente juntamente<br>com um frasco vazio de 300 mL de herbicida GlySH, que continha 41% de<br>glifosato como um sal de isopropilamina, 15% de surfactante de<br>polioxietilenamina (POEA) e água.<br>Ele estava sonolento na apresentação, com uma escala de escala de coma<br>de Glasgow de 11 (E3, V4, M4). Sua frequência cardíaca era de 44<br>batimentos/min, sua pressão arterial não podia ser medida com um<br>manguito de braço, mas ele tinha um pulso femoral palpável e sua<br>frequência respiratória era de 15 respirações /min. Ele foi intubado e um|  
163  
|ventilador mecânico foi usado. Um cateter venoso central foi inserido e o|
|---|
|suporte vasopressor foi iniciado com a infusão de dopamina.|
|A**atropina**foi administrada para tratar a bradicardia.**Lavagem gástrica**foi<br>realizada e**50 g de carvão ativado**foi administrado por sonda gástrica. Uma<br>radiografia de tórax foi normal e um eletrocardiograma revelou ritmo atrial<br>com complexos prematuros juncionais.|
|Os resultados da análise de gasometria arterial foram os seguintes:**pH**|
|**7,298**; PaCO2, 26,9 mmHg; PaO2, 240,2 mmHg; e HCO3, 13,3 mEq / L. As<br>concentrações de eletrólitos séricos foram as seguintes: Na, 134,4 mEq/L;|
|K 3,79 mEq/L; e Cl, 94,6 mEq/L. A concentração sérica de etanol foi de 152,8<br>mg / dL. Demais parâmetros no exame de sangue foram normais.<br>|
|Após cerca de 2,5h de cuidados de suporte após a admissão, ele|
|permaneceu hipotenso e sua pressão arterial sistólica foi de 80 mmHg.<br>**Preparou-se um frasco de 500 mL de 20% de produto de emulsão lipídica**<br>**intravenosa. Como um bolus, 100 mL de emulsão lipídica intravenosa**|
|(Intravenous Fat Emulsion - IFE) foram injetados, e os 400 mL restantes|
|foram então infundidos a uma taxa de 1,5 mL/min. Seu pulso radial se|
|fortaleceu imediatamente após a injeção do bolus. Sua pressão arterial foi<br>de 100/60 mmHg 1h após a injeção e ele se extubou. Após 5h da injeção de<br>IFE, sua pressão arterial atingiu 160/100 mmHg e os vasopressores foram<br>reduzidos. Ele permaneceu estável por 6 dias após a admissão hospitalar e<br>recebeu alta.|  
164  
|Nielsen 2010|In vitro|||Não é escopo -Percutaneous penetration through human skin is studied in an<br>**_in vitro_**model|
|---|---|---|---|---|
|Roberts et al., 2010 (A<br>prospective<br>observational study of<br>the clinical toxicology<br>of glyphosate-containing<br>herbicides in adults with<br>acute self-poisoning.)<br>**2A**|Série de Casos|--<br>Detecção de<br>casos de<br>intoxicação por<br>grupos<br>toxindromes|Desconforto<br>respiratório,<br>hipotensão, nível<br>de consciência<br>alterado, oligúria,<br>náusea e vômito,<br>bradicardia ou<br>taquicardia|A maioria dos pacientes intoxicados (64%) desenvolveu sinais de intoxicação<br>branda. As manifestações gastrointestinais foram documentadas em 83% dos<br>pacientes com intoxicação branda, principalmente náuseas, vômitos, diarreia e<br>dor abdominal.<br>Outras toxicidades em intoxicações brandas incluíram hipotensão transitória<br>(5% dos pacientes, pressão arterial média <70mmHg), bradicardia (frequência<br>cardíaca <60 batimentos / minuto) ou taquicardias (frequência cardíaca> 100<br>batimentos / minuto). Sintomas gastrointestinais, dificuldade respiratória,<br>hipotensão, nível de consciência alterado e oligúria foram observados em casos<br>fatais, a maioria dos pacientes (64%) desenvolveu sinais de intoxicação branda<br>e a intoxicação moderado a grave ocorreu em 5,5% dos pacientes (33<br>pacientes), levando a internações mais longas. Crepitações respiratórias<br>bilaterais foram observados em seis pacientes, quatro pacientes foram<br>taquipnéicos (taxa respiratória> 25 / minuto) e um paciente precisava de<br>intubação e ventilação para insuficiência respiratória. Hipotensão (pressão<br>arterial média <70mmHg) foi observada durante a hospitalização em 48%<br>desses 33 pacientes. Outros marcadores de intoxicação moderada a grave<br>incluíram convulsões (dois pacientes) e / ou um nível de consciência deprimido<br>(12 pacientes).|  
165  
<!-- Start of picture text -->
&<br><!-- End of picture text -->  
|Almeida et al., 2016|Revisão narrativa|||Não é escopo – todos os estudos de melatonina e proteção aos riscos<br>toxicológicos das intoxicações por agrotóxicos foram realizados em ratos ou_in_<br>_vitro_|
|---|---|---|---|---|
|**3A- extra**|||||
|Mohamed et al., 2016|REPETIDO||||
|Mahendrakar et al., 2014|Relato de Caso<br>(Índia)|||Paciente do sexo masculino, 35 anos, foi internado após ingestão intencional<br>de cerca de 200 ml de herbicida contendo glifosato. Dirigiu-se ao hospital<br>após 15 min da ingestão. Foi realizada a lavagem gástrica. Após 10 h de<br>ingestão, o paciente apresentou desconforto respiratório súbito e hipotensão,<br>sendo intubado e ventilado.|
|||||infusão de noradrenalina e vasopressina, hemodiafiltração venovenosa<br>contínua e emulsão lipídica endovenosa (ILE) (20% intralipídico 100 ml), o<br>paciente foi tratado e recebeu alta hospitalar com sucesso.<br>A lavagem gástrica ou o carvão ativado podem ser administrados em<br>pacientes que apresentam <1 h após a ingestão e que não apresentam<br>evidência de irritação bucal ou queimaduras. Não há evidências, no entanto,<br>de que qualquer uma delas reduza a absorção sistêmica de GlySH.|
|Kim et al., 2014|Coorte<br>retrospectiva<br>(Coreia do Sul)<br>-|Mortalidade -<br>seguimento|Marcadores de<br>prognóstico|Foram incluídos 153 pacientes de janeiro de 2005 a dezembro de 2012. A<br>intoxicação por glifosato foi determinada por história clínica, rótulos ou<br>informações dadas pelos familiares e que constassem no prontuário. Os|  
166  
||||achados eletrocardiográficos anormais mais comuns foram o intervalo QTc<br>prolongado, seguido de atraso na condução intraventricular e bloqueio<br>atrioventricular de primeiro grau. Os não-sobreviventes tiveram um intervalo<br>QTc significativamente mais prolongado quando comparados com os<br>sobreviventes (sobreviventes: 453,4 ± 33,6 milisegundos Vs não<br>sobreviventes: 542 ± 32,0 milissegundos, P< 0,001).<br>Na análise de regressão logística múltipla, a idade e o intervalo QTc foram<br>fatores independentes para predizer a mortalidade após o controle de<br>covariáveis.|
|---|---|---|---|
|Sribanditmongkol et al.,<br>2012|Relato de Caso|Não aborda<br>tratamento|Estudo de caso_post mortem_|
|Seok et al., 2011|REPETIDO|||
|Bradberry et al., 2008|Não disponível|||  
167

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Quadro III.5.1.** Avaliação das evidências pelo método GRADE sobre a questão: “Quais fatores são preditivos de complicações clínicas nos casos de intoxicações agudas por produtos à base de glifosato?”  
**a) Idade > 50 anos**  
||||**Avaliação de Qua**|**lidade**|||**№ de p**|**acientes**|**Efei**|**to**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**a idade**<br>**acima de**<br>**50 anos**|**a idade**<br>**abaixo de**<br>**50 anos**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalid|ade||||||||||||
|5|estudo<br>observacional|não grave|não grave|não grave|não grave|todos os<br>potenciais<br>fatores de<br>confusão<br>sugeririam um<br>efeito espúrio e,<br>mesmo assim,<br>nenhum efeito<br>foi observado.|59/566<br>(10.4%)|0/566<br>(0.0%)|não<br>estimável||⨁⨁⨁◯<br>MODERADA|CRÍTICO|  
168

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
###### **CI:** Confidence interval  
###### **Bibliografia** :  
1. MOON, Jeong Mi; CHUN, Byeong Jo. Predicting acute complicated glyphosate intoxication in the emergency department. Clinical Toxicology, v. 48, n. 7, p. 718–724, 2010.;  
2. LEE, Hsin Ling et al. Clinical presentations and prognostic factors of a glyphosate-surfactant herbicide intoxication: A review of 131 cases. Academic Emergency Medicine, v. 7, n. 8, p. 906–910, 2000;  
3. LEE, Ching Hsing et al. The early prognostic factors of glyphosate-surfactant intoxication. American Journal of Emergency Medicine, v. 26, n. 3, p. 275–281, 2008.; 4. SEOK, Su Jin et al. Surfactant volume is an essential element in human toxicity in acute glyphosate herbicide intoxication. Clinical Toxicology, v. 49, n. 10, p. 892– 899, 2011.  
5. KIM, Y H et al. Prognostic factors in emergency department patients with glyphosate-surfactant intoxication: point-of-care lactate testing . Basic and Clinical Pharmacology and Toxicology , v. 119, n. 6, p. 604–610, 2016. Disponível em:  
- <http://onlinelibrary.wiley.com/doi/10.1111/bcpt.12624/abstract%0Ahttp://dx.doi.org/10.1111/bcpt.12624%0AAdded Jun 16>.  
169  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
170  
<!-- Start of picture text -->
&<br><!-- End of picture text -->  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
###### **b) Volume > 125mL**  
||||**Avaliação de Qua**|**lidade**|||**№ de p**|**acientes**|**Efei**|**to**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>Mortalid|**Delineamento**<br>**do estudo**<br>ade|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**a ingestão**<br>**de volumes**<br>**acima de**<br>**125 mL**|**ingestão de**<br>**volumes**<br>**menores do**<br>**que 125 mL**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|5|estudo<br>observacional|não grave|não grave|não grave|grave<sup>1,2,a,b</sup>|forte associação<br>todos os<br>potenciais<br>fatores de<br>confusão<br>sugeririam um<br>efeito espúrio e,<br>mesmo assim,<br>nenhum efeito<br>foi observado.|30/694<br>(4.3%)|7/694<br>(1.0%)|**RR 4.28**<br>(-- para --)|**33 mais**<br>**por**<br>**1.000**<br>(de --<br>para --)|⨁⨁⨁◯<br>MODERADA|CRÍTICO|  
**CI:** Confidence interval; **RR:** Risk ratio  
###### <u>Justificativa</u>  
a. A estimativa do volume ingerido era baseada no relato das vítimas  
b. Volumes ingeridos entre sobreviventes e não sobreviventes apresentam interseção entre os intervalos  
171  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
###### **Bibliografia** :  
1. LEE, Ching Hsing et al. The early prognostic factors of glyphosate-surfactant intoxication. American Journal of Emergency Medicine, v. 26, n. 3, p. 275–281, 2008.  
2. LEE, Hsin Ling et al. Clinical presentations and prognostic factors of a glyphosate-surfactant herbicide intoxication: A review of 131 cases. Academic Emergency Medicine, v. 7, n. 8, p. 906–910, 2000.;  
3. MOHAMED, Fahim et al. Mechanism-specific injury biomarkers predict nephrotoxicity early following glyphosate surfactant herbicide (GPSH) poisoning. Toxicology Letters, v. 258, p. 1–10, 2016.  
4. MOON, Jeong Mi; CHUN, Byeong Jo. Predicting acute complicated glyphosate intoxication in the emergency department. Clinical Toxicology, v. 48, n. 7, p. 718–724, 2010.;  
5. SEOK, Su Jin et al. Surfactant volume is an essential element in human toxicity in acute glyphosate herbicide intoxication. Clinical Toxicology, v. 49, n. 10, p. 892– 899, 2011.  
172  
<!-- Start of picture text -->
re<br><!-- End of picture text -->  
Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE **Variáveis de Confundimento Avaliação dos resultados Seleção dos Grupos Outros vieses 0% 20% 40% 60% 80% 100% Baixo Incerto Alto** ~~<mark>Ee</mark>~~ **c) FC> 100 bpm** 173

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Pergunta** : A FC > 100 bpm comparado a FC<100 bpm em pacientes com suspeita de intoxicações por formulações à base de glifosato, como parâmetro preditivo de complicação clínica?  
**Contexto** : Pacientes que, na admissão, encontram-se taquicárdicos podem evoluir para outras complicações  
**Bibliografia** : LEE, Hsin Ling et al. Clinical presentations and prognostic factors of a glyphosate-surfactant herbicide intoxication: A review of 131 cases. Academic Emergency Medicine, v. 7, n. 8, <u>p. 906–910, 2000.</u>  
||||**Análise da evidê**|**ncia**|||**№ de pa**|**cientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**a FC >**<br>**100 bpm**|**FC<100**<br>**bpm**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalid|ade||||||||||||
|1|estudo<br>observacional|não<br>grave|não grave|não<br>grave|não grave|todos os<br>potenciais<br>fatores de<br>confusão<br>sugeririam um<br>efeito espúrio<br>e, mesmo<br>assim,<br>nenhum<br>efeito foi<br>observado.|17/58<br>(29.3%)|41/58<br>(70.7%)|**OR**<br>**11.038**<br>(1.198<br>para<br>101.672)|**257 mais**<br>**por**<br>**1.000**<br>(de 36<br>mais<br>para 289<br>mais)|⨁⨁⨁◯<br>MODERADA|<br>IMPORTANTE|  
174

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
**CI:** Confidence interval; **OR:** Odds ratio  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
- **Quadro III.5.2.** Avaliação das evidências pelo método GRADE sobre a questão: “Quais exames laboratoriais que auxiliam na avaliação e acompanhamento de pacientes que apresentam intoxicação aguda por produtos à base de glifosato? ”  
- **a) Dosagem de Lactato**  
175

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Pergunta** : [Lactato] sérico >4,7 mmol comparado a [Lactato] sérico<4,7mmol em pacientes intoxicados por produtos à base de glifosato como preditor de mortalidade  
**Contexto** : As intoxicações por produtos à base de glifosato induzem à hipoxia e estão relacionadas a alterações bioquímicas em nível celular, que promovem a síntese de ácido lático.  
**Bibliografia** : KIM, Yong Hwan et al. Prognostic Factors in Emergency Department Patients with Glyphosate Surfactant Intoxication: Point-of-Care Lactate Testing. Basic and Clinical Pharmacology and Toxicology, v. 119, n. 6, p. 604–610, 2016.  
||||**Análise da evid**|**ência**|||**№ d**|**e pacientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**[Lactato]**<br>**sérico**<br>**>4,7**<br>**mmol**|**[Lactato]**<br>**sérico<4,7mmol**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalid|ade||||||||||||
|1|estudo<br>observacional|não<br>grave|não grave|não<br>grave|não grave|gradiente de<br>dose-resposta|26/232<br>(11.2%)|3/232 (1.3%)|**RR 8.6**<br>(-- para<br>--)|**98 mais**<br>**por**<br>**1.000**<br>(de --<br>para --)|⨁⨁⨁◯<br>MODERADA|<br>CRÍTICO|  
• **CI:** Confidence interval; **RR:** Risk ratio  
176

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
#### **b) Determinação de K sérico**  
**Pergunta** : [ K+] >4,5 mmol/L comparado a [K+]<4,5 mmol/L em pacientes com suspeita de intoxição por glifosato como um preditor de complicações? **Bibliografia** : MALHOTRA et al., 2010 KIM, YH et al., 2016 GARLICH et al., 2014 OZAKI; SOFUE; KURODA, 2017 KAMIJO et al., 2012 MOON; CHUN, 2010 NINCEVIC et al., 2017 THANKUR et al., 2014 MOHAMED et al., 2016 LEE, Ching Hsing et al., 2008 PALLI et al., 2011 CHAN et al., 2016 HAN, Sang Kyoon et al., 2010  
177  
<!-- Start of picture text -->
&<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
||||**Análise de Evid**|**ência**|||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**<br>Mortalid|**Risco**<br>**de**<br>**viés**<br>ade|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**[ K+]**<br>**>4,5**<br>**mmol/L**|**[K+]<4,5**<br>**mmol/L**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|5|estudo<br>observacional<br>Tempo d|grave<br>1,a<br>e intern|não grave<br>ação (seguiment|não<br>grave<br>o: variação|grave<sup>1,a</sup><br>10 dias para|gradiente de<br>dose-resposta<br>30 dias)|38/398<br>(9.5%)|0.0%|não<br>estimável||⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|  
178  
||||**Análise de Evid**|**ência**|||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**[ K+]**<br>**>4,5**<br>**mmol/L**|**[K+]<4,5**<br>**mmol/L**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|2|estudo<br>observacional|grave<br>1,a|não grave|não<br>grave|grave<sup>1,a</sup>|todos os<br>potenciais<br>fatores de<br>confusão<br>sugeririam um<br>efeito espúrio<br>e, mesmo<br>assim,<br>nenhum<br>efeito foi<br>observado.<br>gradiente de<br>dose-resposta|29/77<br>(37.7%)|<br>0/77<br>(0.0%)|não<br>estimável||⨁⨁◯◯<br>BAIXA|IMPORTANTE|  
**CI:** Confidence interval  
###### <u>Explicações</u>  
a. Os estudos do tipo "Relato de Caso" possuem alto viés de seleção e não fornecem dados quantitativos com intervalos de confiança ou análise estatística mais robusta.  
179

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
###### <u>Referências</u>  
1. Yoshito Kamijo, Miyo Mekari,Kuniko Yoshimura,Tomomichi Kan’o,and Kazui Soma. Glyphosate-surfactant herbicide products containing glyphosate potassium salt can cause fatal hyperkalemia if ingested in massive amounts. Clinical Toxicology; 2012.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
- **c) Dosagem de creatinina**  
180

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Pergunta** : [Cr]serica.1,4 mg/dL comparado a [Cr]serica<1,4mg/dL em pacientes com suspeita de intoxicação por produtos à base de glifosato como fator preditivo de complicações  
**Contexto** : Uma das complicações apresentadas por pacientes intoxicados por formulações à base de glifosato é a falência renal. **Bibliografia** : EE, Ching Hsing et al. The early prognostic factors of glyphosate-surfactant intoxication. American Journal of Emergency Medicine, v. 26, n. 3, p. 275– 281, 2008. LEE, Hsin Ling et al. Clinical presentations and prognostic factors of a glyphosate-surfactant herbicide intoxication: A review of 131 cases. Academic Emergency Medicine, v. 7, n. 8, p. 906–910, 2000. MOHAMED, Fahim et al. Mechanism-specific injury biomarkers predict nephrotoxicity early following glyphosate surfactant herbicide (GPSH) poisoning. Toxicology Letters, v. 258, p. 1–10, 2016  
||||**Avaliação de Ev**|**idência**|||**№ d**|**e pacientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudo**<br>**s**|**Delineament**<br>**o do estudo**|**Risc**<br>**o de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**[Cr]serica.1,**<br>**4 mg/dL**|**[Cr]serica<1,4mg/d**<br>**L**|**Relativo**<br>**(95% CI)**|**Absolut**<br>**o**<br>**(95% CI)**|**Evidênci**<br>**a**|**Importância**|
|Mortalid|ade||||||||||||  
181  
<!-- Start of picture text -->
&<br><!-- End of picture text -->  
||||**Avaliação de Ev**|**idência**|||**№ d**|**e pacientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudo**<br>**s**|**Delineament**<br>**o do estudo**|**Risc**<br>**o de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**[Cr]serica.1,**<br>**4 mg/dL**|**[Cr]serica<1,4mg/d**<br>**L**|**Relativo**<br>**(95% CI)**|**Absolut**<br>**o**<br>**(95% CI)**|**Evidênci**<br>**a**|**Importância**|
|3|estudo<br>observacional|não<br>grav<br>e|não grave|não<br>grave|não grave|todos os<br>potenciais<br>fatores de<br>confusão<br>sugeririam<br>um efeito<br>espúrio e,<br>mesmo<br>assim,<br>nenhum<br>efeito foi<br>observado.<br>gradiente de<br>dose-<br>resposta|27/441<br>(6.1%)|48/441 (10.9%)|não<br>estimáve<br>l||⨁⨁⨁⨁<br>ALTA|IMPORTANT<br>E|  
**CI:** Confidence interval  
182

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
#### **d) Gasometria arterial**  
**Pergunta** : Solicitação de gasometria comparado a não solicitá-la para o acompanhamento de pacientes com suspeita de intoxicação por formulações à base de glifosato **Contexto** : A acidose metabólica é uma das complicações mais comuns observadas em pacientes com suspeita de intoxicação por formulações à base de glifosato **Bibliografia** : MOON, Jeong Mi; CHUN, Byeong Jo. Predicting acute complicated glyphosate intoxication in the emergency department. Clinical Toxicology, v. 48, n. 7, p. 718– 724, 2010; KHOT, Rajashree et al. Glyphosate poisoning with acute pulmonary edema. Toxicology International, v. 21, n. 3, p. 328, 2014..; LEE, Ching Hsing et al. The early  
183

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
prognostic factors of glyphosate-surfactant intoxication. American Journal of Emergency Medicine, v. 26, n. 3, p. 275–281, 2008. LEE, Hsin Ling et al. Clinical presentations and prognostic factors of a glyphosate-surfactant herbicide intoxication: A review of 131 cases. Academic Emergency Medicine, v. 7, n. 8, p. 906–910, 2000.; KAMIJO, Yoshito et al. Glyphosate-surfactant herbicide products containing glyphosate potassium salt can cause fatal hyperkalemia if ingested in massive amounts. Clinical Toxicology, v. 50, n. 2, <u>p. 159, 2012.</u>  
||||**Certainty assess**|**ment**|||||
|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**<br>**Outras**<br>**considerações**|**Impacto**|**Certainty**|**Importância**|
|Acidose|metabólica||||||||  
184  
|6|estudo<br>observacional|grave<br>1,2,a|não grave|não<br>grave|não grave<br>forte<br>associação<br>gradiente de<br>dose-resposta|<br>Paciente de 69 anos, com histórico de<br>intoxicação com 500mL de RoundUp. Na<br>admissão, apresnetava assistolia com ECG<br>indicativo de taquicardia ventricular (TV)<br>refratária a antiarrítmicos. Testes revelaram<br>hipercalemia extrema (10,7 mEq / L) e<br>alterações metabólicas acidose (pH: 7,005,<br>PaCO 2: 41,6 mm Hg, BE: 20,7 mmol / L, HCO-3 :<br>10,1 mmol / l), além de outras lterações (Khot,<br>2014). Coorte retrospectiva onde 76 pacientes<br>com histórico de ingestão intencional de<br>glifosato identificou como fatores preditivos de<br>complicações (idade, volume de ingestão e<br>outras) identificou acidose metabólica foi a<br>complicação médica mais comum, a qual é<br>observada nas primeiras 24 h após a ingestão<br>do produto (Moon, 2010). O surfactante<br>presente nas formulações à base de glifosato<br>podem contribuir para o estabelecimento da<br>acidose metabólica observada nas intoxicações<br>agudas por esses produtos (Kim, 2016). Em<br>estudo retrospectivo com 131 pacientes, as<br>seguintes alterações laboratoriais foram<br>observadas: leucocitose (68,0%), baixas doses|<br>⨁⨁⨁◯<br>MODERADA|<br>CRÍTICO|
|---|---|---|---|---|---|---|---|---|  
185  
||||**Certainty assess**|**ment**||||
|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**<br>**Outras**<br>**considerações**|**Impacto**<br>**Certainty**|**Importância**|
|||||||de bicarbonato (48,1%), acidose (35,8%),<br>disfunção hepática (33,6%), hipercapnia<br>(30,9%), hipoxemia (28,4%) e insuficiência renal<br>(17,1%) (Lee 2000). Lee e colaboradores (2008),<br>posteriormente estabeleceram quatro<br>preditores de complicações observadas em<br>pacientes intoxicados por formulações à base<br>de glifosato (anormalidades no RX torácico,<br>acidose metabólica, creatinina sérica e<br>taquicardia), por meio de uma modelo de<br>regressão. Todos eles, com exceção da<br>creatinina podem ser obtidos em apenas 10 a<br>20 minutos, sendo de fácil interpretação.||  
**CI:** Confidence interval  
###### <u>Justificativa</u>  
a. Os estudos do tipo "Relato de Caso" possuem alto viés de seleção e não fornecem dados quantitativos com intervalos de confiança ou análise estatística mais robusta.  
###### <u>Referências</u>  
1. KHOT, Rajashree et al.. Glyphosate Poisoning with Acute Pulmonary Edema. Toxicology International; 2014.  
186  
<!-- Start of picture text -->
tis<br><!-- End of picture text -->  
2. Yoshito Kamijo, Miyo Mekari,Kuniko Yoshimura,Tomomichi Kan’o,and Kazui Soma. Glyphosate-surfactant herbicide products containing glyphosate potassium salt can cause fatal hyperkalemia if ingested in massive amounts. Clinical Toxicology; 2012.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
187

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
**Quadro III.5.3.** Avaliação das evidências pelo método GRADE sobre a questão: “Quais exames auxiliares permitem o acompanhamento e avaliação clínica do paciente com suspeita de intoxicação por produtos à base de glifosato?”.  
**Pergunta** : Quais exames complementares devem ser solicitados para a avaliação clínica inicial e acompanhamento de pacientes com suspeita de intoxicação por produtos à base de glifosato?  
**Contexto** : Diversos estudos indicam que na maioria dos casos de intoxicação pro produtos à base de glifosato, é observado um prolongamento no intervalo QT, além de outras alterações cardíacas  
**Bibliografia** : KIM, Yong Hwan et al. Heart rate-corrected QT interval predicts mortality in glyphosate- surfactant herbicide-poisoned patients. American Journal of Emergency Medicine, v. 32, n. 3, p. 203–207, 2014. Disponível em: <http://dx.doi.org/10.1016/j.ajem.2013.09.025>. ______. Prognostic Factors in Emergency Department Patients with Glyphosate Surfactant Intoxication: Point-of-Care Lactate Testing. Basic and Clinical Pharmacology and Toxicology, v. 119, n. 6, p. 604–610, 2016; KAMIJO, Yoshito; TAKAI, Michiko; SAKAMOTO, Tetsuya. A multicenter retrospective survey of poisoning after ingestion of herbicides containing glyphosate potassium salt or other glyphosate salts in Japan. Clinical Toxicology, v. 54, n. 2, p. 147–151, 2016.; LEE, Hsin Ling et al. Clinical presentations and prognostic factors of a glyphosate-surfactant herbicide intoxication: A review of 131 cases. Academic Emergency Medicine, v. 7, n. 8, p. 906–910, 2000.; MOON, Jeong Mi; CHUN, Byeong Jo. Predicting acute complicated glyphosate intoxication in the emergency department. Clinical Toxicology, v. 48, n. 7, p. 718–724, 2010; OZAKI, Taro; SOFUE, Tadashi; KURODA, Yasuhiro. Severe Glyphosate-Surfactant Intoxication Successfully Treated With Continuous Hemodiafiltration and Direct Hemoperfusion: Case Report. Therapeutic Apheresis and Dialysis, v. 21, n. 3, p. 296–297, 2017; NINCEVIC, Zeljko et al. Severe glyphosate - surfactant herbicide poisoning ; successful treatment - case report. v. 4, n. 1, p. 202–204, 2017.  
188

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|**№ dos**<br>**estudos**<br>Eletrocar|**Delineamento**<br>**do estudo**<br>diograma|**Risco**<br>**de**<br>**viés**|**Avaliação da Evi**<br> <br>**Inconsistência**|**dência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Evidência**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|  
189  
|6|estudo<br>observacional|grave<br>1,2,a|não grave|não grave|grave<sup>1,2,a</sup>|nenhum|Observa-se que produtos contendo sal de<br>potássio (Roundup Maxload e Touchdown IQ)<br>favorecem a hipercalemia e o prolongamento<br>dos intervalos QRS e QT, com pico na onda T,.<br>(KAMIJO; TAKAI; SAKAMOTO, 2016). Relato de<br>caso no qual paciente, 47 anos, vítima de<br>intoxicação intencional com formulação à base<br>de glifosato, apresentou um ECG com<br>alargamento do QRS largo (134 ms) e<br>prolongamento no QTc (550ms) (CHAN et al.,<br>2016). Anormalidades do ECG observadas entre<br>76 pacientes vítimas de intoxicação aguda por<br>glifosato: prolongamento do intervalo QTc<br>(51.7%), taquicardia sinusal (13.8%), bloqueio<br>AV de primeiro grau (10.3%), anormalidade ST-T<br>(10.3%), bradicardia sinusal (5.2%) e taquicardia<br>com alargamento QRS (1.7%) (MOON; CHUN,<br>2010). Achados anormais mais comuns no ECG<br>observados em 153 vítimas de exposição aguda<br>ao glifosato foram prolongamento do intervalo<br>QTc, tendo sido também observado o atraso da<br>condução intraventricular e bloqueio<br>atrioventricular. (KIM et al., 2014).ECG<br>sugestivo de taquicardia ventricular (TV),|<br>⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|  
190  
||||**Avaliação da Evi**|**dência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Evidência**|**Importância**|
||||||||associado a um quadro de hipercalemia grave<br>(10,7 mEq/L), acidose metabólica (pH 7,005;<br>PaCO2 41,6 mm Hg; BE20,7 mmol/L, HCO3-;<br>10,1 mmol/L)(KAMIJO et al., 2012); Alterações<br>anormais no ECG observadas em pacientes com<br>histórico de exposição aguda ao glifosato,<br>admitidos em um serviço de emergência,<br>principalmente taquicardia sinusal e alterações<br>inespecíficas de ST-T. D(LEE, Hsin Ling et al.,<br>2000)|||
|Radiograf|ia de Tórax|||||||||  
191  
|7|estudo<br>observacional|grave<br>3,4,a<br>não grave|não grave|grave<sup>3,4,a</sup>|nenhum|Dentre 76 vítimas de intoxicação intencional<br>com formulações à base de glifosato, em 17<br>(22.4%) foram observadas anormalidades<br>radiográficas, sendo que 7 pacientes<br>apresentaram infiltrados pulmonares e 10<br>foram diagnosticados com edema agudo de<br>pulmão (MOON; CHUN, 2010).Alterações<br>anormais em Raio X de Tórax observadas em<br>pacientes com histórico de exposição aguda ao<br>glifosato, admitidos em um serviço de<br>emergência, principalmente taquicardia sinusal<br>e alterações inespecíficas de ST-T. Dos 105<br>pacientes que tiveram radiografia de tórax<br>realizada, em 22 foram observados infiltrados<br>ou manchas anormais. Três dos 131<br>desenvolveram insuficiência renal e<br>necessitaram de hemodiálise; indo todos a<br>óbito(LEE, Hsin Ling et al., 2000) As<br>complicações pulmonares são associadas à<br>mortalidade de pacientes vítimas de exposição<br>aguda a formulações contendo glifosato (LEE,<br>Ching Hsing et al., 2008; NINCEVIC et al., 2017;<br>OZAKI; SOFUE; KURODA, 2017) A lesão<br>pulmonar aguda é observada em pacientes|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|  
192  
||||**Avaliação da Evi**|**dência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Evidência**|**Importância**|
||||||||intoxicados por formulações contendo POEA<br>(KAMIJO; TAKAI; SAKAMOTO, 2016)|||  
**CI:** Confidence interval  
193  
<!-- Start of picture text -->
fin<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
194  
<!-- Start of picture text -->
ay<br><!-- End of picture text -->  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
195  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
**Quadro III.5.4. Avaliação das evidências pelo método GRADE sobre a questão: “Quais são os métodos de descontaminação e eliminação efetivos na intoxicação por glifosato?”** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
###### **Terapia Dialítica**  
**Pergunta** : Terapia dialítica comparado a não utilizá-la em casos graves de intoxicação por produtos à base de glifosato  
**Contexto** : Nas intoxicações graves com formulações à base de glifosato, a possível exposição a ingredientes mais tóxicos do que o ativo, bem como a ingestão de grande volume de herbicida favorecem o desenvolvimento de complicações clínicas e provável óbito. Esses são observados, principalmente, nos indivíduos que, na admissão, apresentam uma elevada concentração plasmática de glifosato.  
**Bibliografia** : CHAN, Cheng-Wei et al. Successful Extracorporeal Life Support in a Case of Severe Glyphosate-Surfactant Intoxication. Critical Care Medicine, v. 44, n. 1, p. e45–e47, 2016. Disponível em: <http://content.wkhealth.com/linkback/openurl?sid=WKPTLP:landingpage&an=00003246-201601000-00042>.; HOUR, Billy T. et al. Herbicide roundup intoxication: Successful treatment with continuous renal replacement therapy. American Journal of Medicine, v. 125, n. 8, p. e1–e2, 2012. Disponível em: <http://dx.doi.org/10.1016/j.amjmed.2011.11.022>. KHOT, Rajashree et al. Glyphosate poisoning with acute pulmonary edema. Toxicology International, v. 21, n. 3, p. 328, 2014. Disponível em: <http://www.toxicologyinternational.com/text.asp?2014/21/3/328/155389>. GARLICH, Fiona M. et al. Hemodialysis clearance of glyphosate following a life-threatening ingestion of glyphosate-surfactant herbicide. Clinical Toxicology, v. 52, n. 1, <u>p. 66–71, 2014.</u>  
||||**Certainty assess**|**ment**|||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**terapia**<br>**dialítica**|**não**<br>**utilizá-la**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certainty**|**Importância**|
|Mortalid|ade||||||||||||  
196  
<!-- Start of picture text -->
&<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
||||**Certainty assess**|**ment**|||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**terapia**<br>**dialítica**|**não**<br>**utilizá-la**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certainty**|**Importância**|
|3|estudo<br>observacional|grave<br>1,2,3,a|grave<sup>1,2,3,b,c</sup>|não<br>grave|grave<br>1,2,3,a,d|nenhum|0/3<br>(0.0%)|-|-|-|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|  
**CI:** Confidence interval  
###### <u>Expplicações</u>  
a. Os estudos do tipo "Relatos de Casos" possuem alto viés de seleção e não fornecem parâmetros quantitativos com análise estatística ou intervalos de confiança.  
b. Idade e tempo de atendimento após a ingestão do produto são distintos  
c. Intoxicações por formulações distintas  
d. Utilização de oxigenação por membrana extracorpórea venoarterial (VA-ECMO) associada ao método dialítico de escolha  
###### <u>Referências</u>  
1. GARLICH, Fiona M. et al.. Hemodialysis clearance of glyphosate following a life-threatening ingestion of glyphosate-surfactant herbicide. . Clinical Toxicology; 2014. 2. HOUR, Billy T. et al.. Herbicide roundup intoxication: Successful treatment with continuous renal replacement therapy. . American Journal of Medicine; 2012. 3. CHAN, Cheng-Wei et al.. Successful Extracorporeal Life Support in a Case of Severe Glyphosate-Surfactant Intoxication. . Critical Care Medicine; 2016.  
197

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
198

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**Quadro III.5.5.** Avaliação das evidências pelo método GRADE sobre a questão: “Qual é a conduta e tratamento inicial para pacientes com histórico de intoxicação de produtos à base de glifosato que desenvolvem hipotensão refratária?”  
**Pergunta** : A infusão lipídica comparado a não utiliza-la para a correção da hipotensão refratária observada em alguns pacientes intoxicados por formulações à base de glifosato  
**Contexto** : A administração parenteral de emulsão lipídica tem se mostrado efetiva para a correção da hipotensão refratária observada nos casos graves de intoxicação por produtos à base de glifosato. Os mecanismos pelos quais a emulsão lipídica reduz os efeitos tóxicos dos surfactantes não foram totalmente esclarecidos **Bibliografia** : GIL, Hyo-Wook et al. Effect of intravenous lipid emulsion in patients with acute glyphosate intoxication. Clinical Toxicology, v. 51, n. 8, p. 767–771, 2013. Disponível em: <http://www.tandfonline.com/doi/full/10.3109/15563650.2013.821129>.; HAN, Sang Kyoon et al. Use of a lipid emulsion in a patient with refractory hypotension caused by glyphosate-surfactant herbicide. Clinical Toxicology, v. 48, n. 6, p. 566–568, 2010.;YOU, Y; JUNG, W J; LEE, M J. Effect of intravenous fat emulsion therapy on glyphosate-surfactant-induced cardiovascular collapse. The American journal of emergency medicine, v. 30, n. 9, <u>p. 2097.e1-2, 2012.</u>  
||||**Certainty assess**|**ment**|||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|<br>**Imprecisão**|**Outras**<br>**considerações**|**a infusão**<br>**lipídica**|**não**<br>**utiliza-la**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certainty**|**Importância**|  
Tempo de internação (seguimento: média 10 dias; Escala de: 4,8 para 11,6)  
199  
<!-- Start of picture text -->
&<br><!-- End of picture text -->  
||||**Certainty assess**|**ment**|||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**a infusão**<br>**lipídica**|**não**<br>**utiliza-la**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certainty**|**Importância**|
|3|estudo<br>observacional|grave<br>1,2,a|grave<sup>1,2,b</sup>|não<br>grave|grave<sup>1,2,a</sup>|todos os<br>potenciais<br>fatores de<br>confusão<br>sugeririam um<br>efeito espúrio<br>e, mesmo<br>assim,<br>nenhum<br>efeito foi<br>observado.<br>gradiente de<br>dose-resposta|24|20|-|**0**<br>(0 para 0<br>)|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANTE|
|Mortalid|ade||||||||||||
|1|ensaios<br>clínicos<br>randomizados|grave<sup>3,c</sup>|não grave|não<br>grave|grave<sup>3,d</sup>|gradiente de<br>dose-resposta|0/22<br>(0.0%)|1/20<br>(5.0%)|não<br>estimável||⨁⨁⨁◯<br>MODERADA|<br>CRÍTICO|  
**CI:** Confidence interval  
200

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
###### <u>Explicações</u>  
a. Os estudos do tipo "Relatos de Casos" possuem alto viés de seleção e não fornecem parâmetros quantitativos com análise estatística ou intervalos de confiança. b. O tipo de formulação e a quantidade ingerida podem influenciar nas manifestações observadas  
c. Número de pacientes expostos à terapia é baixo  
###### <u>Referências</u>  
1. YOU, Y, JUNG, W J, LEE, M J.. Effect of intravenous fat emulsion therapy on glyphosate-surfactant-induced cardiovascular collapse.. The American journal of emergency medicine; 2012.  
2. HAN, Sang Kyoon et al.. Use of a lipid emulsion in a patient with refractory hypotension caused by glyphosate-surfactant herbicide.. Clinical Toxicology; 2010.  
3. GIL, Hyo-Wook et al.. Effect of intravenous lipid emulsion in patients with acute glyphosate intoxication.. Clinical Toxicology; 2013.  
201  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
202  
Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
**QUADRO III.6.1** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para o diagnóstico de Intoxicações por agrotóxicos a base de glifosato.  
|**PERGUNTA**|**: Quais são os critérios de gravidade específic**|**a para intoxicações agudas por glifosato?**||
|---|---|---|---|
|**P**Populaçã<br>**I/E**Sinais e<br>**C**Ausência<br>**O**Mortalid<br>**S**Clínicos e|o intoxicada por glifosato<br>sintomas<br>da intervenção<br>ade; Internação; Discapacidade<br>observacionais<br>|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☐Muito baixa<br>☐Baixa<br>☒Moderada<br>☐Alta|Estudo retrospectivo, com análise dos prontuários<br>de 131 pacientes diagnosticados com intoxicação<br>oral por produtos à base de glifosato, admitidos em<br>unidade de emergência entre 1988-1995, revelou<br>que a chance de falência respiratória e óbito<br>aumentam consideravelmente quando o volume<br>ingerido é superior a 200ml (OR= 53,5; IC 95% 13,6-<br>210,9) (LEE, Hsin Ling et al., 2000) .<br>Estudo conduzido por Lee e colaboradores<br>identificou como fatores preditivos de mortalidade<br>em pacientes intoxicados por formulações à base de||  
203

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|glifosato: a idade> 40 anos, a quantidade ingerid<br>|a, o<br>|
|---|---|
|desenvolvimento de choque hipotensivo e|a|
|taquicardia (frequência cardíaca> 100 / min) (|LEE,|
|Ching Hsing et al., 2008).||
|Moon e Chun sugerem, a partir de uma aná|lise|
|multivariada,<br>como<br>fatores<br>preditivos|de|
|mortalidade em vítimas de intoxicação por produ<br>à base de glifosato: a idade superior a 50 anos|tos<br>(OR|
|=0,267; p=0.027; IC 95% 0.083–0.861), a eleva|ção|
|dos níveis de transaminase glutâmico-pirúvica (<br>0.094; p=0.012; IC 95% 0.015–0.595) e a prese|OR=<br>nça|
|de infiltrados pulmonares, observada por meio<br>|de<br>|
|alterações radiográficas de tórax, (OR=0.278;|p=|
|0.049; IC 95% 0.078–0.994). Os autores tamb|ém|
|concluíram que o quadro de hipotensão observ<br>|ado<br>|
|em alguns pacientes não era decorrente|de|
|hipovolemia,<br>mas<br>sim<br>de<br>mecanis|mos|
|toxicodinâmicos<br>de<br>alguns<br>componentes|da|
|formulação.  78% dos pacientes que desenvolve<br>acidose metabólica apresentaram um elevado ân<br>gap (MOON; CHUN, 2010).|ram<br>ion|
|A quantidade de surfactante ingerido (mL)<br>correlacionada  positivamente com os dias|foi<br>de|  
204  
|permanência na UTI (r=0,274, p<0,004), duração da<br>|
|---|
|intubação (r=0,300, p<0,002) e contagem de|
|leucócitos (r=0,373, p<0,001) e correlação negativa<br>com pH inicial (r=-0,365, p<0,001) e HCO3<sup>-</sup>(r = -|
|0,380, p<0,001).O volume de surfactante foi mais<br>relevante para complicações clínicas do que para o<br>volume de ingrediente de glifosato: hipotensão, RR,<br>|
|1,047 (IC, 1,017-1,077; p=0,002) vs. RR, 1,017|
|(p=0,003); insuficiência respiratória, RR, 1,033 (IC,|
|1,006-1,060; p=0,016) vs. RR, 1,010 (p=0,040); lesão<br>aguda renal, RR, 1.042 (CI, 1.012–1.074; p=0,006) vs.|
|RR, 1,013 (p=0,029); e deterioração mental, RR,|
|1,032 (CI, 1.006–1.059; p=0,015) vs. RR, 1.012|
|(p=0,024). Não houve diferença de sintomas entre<br>os grupos de diferentes fórmulas dos surfactantes e<br>sim, pelo volume ingerido (SEOK et al., 2011).<br>|
|A insuficiência renal aguda é uma complicação|
|comum observada em pacientes intoxicados por for<br>formulações à base de glifosato, principalmente em<br>|
|indivíduos acima de 40 anos. Os valores de|
|creatinina<br>sérica,<br>muitas<br>vezes<br>dentro<br>da|
|normalidade na admissão, devem ser monitorados<br>(MOHAMED et al., 2016).|  
205  
||A comparação dos níveis de lactato sérico entre 203<br>sobreviventes (3,3± 2,2 mmol / L; p <0,001) e 29 não<br>sobreviventes (6,5±3,1 mmol /L), vítimas de<br>intoxicação por formulações à base de lactato,<br>indicou por meio de uma análise multivariada que<br>uma concentração superior a 4,7 mmol/ L do íon foi<br>associada ao aumento da mortalidade (razão de<br>risco 3,2; IC95% 1,1–8,7). Além do lactato, idade> 59<br>anos, intervalo QT corrigido> 495 ms e K<sup>+</sup>> 5,5 mmol<br>/ L foram considerados como fatores de risco<br>independentes para mortalidade em 30 dias (KIM,<br>YH et al., 2016).|
|---|---|
|**Há balanço entre os riscos e benefícios**||
|☐Benefícios sobrepõem os riscos<br>☐Há equilíbrio entre riscos e benefícios<br>☐Riscos sobrepõem os benefícios||  
206  
|**Valores  e**|**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|---|---|---|
|||**Os custos associados à intervenção são**<br>**pequenos?**|
|||☐Não|
|**Custos**||☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|  
207

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE -->
||**A opção é aceitável para as principais partes**<br>**interessadas?**||
|---|---|---|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||
||A opção é viável para implementar?||
||☐Não||
|**Viabilidade**|☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|**Conclusão**|  
208

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional a favor da**<br>**intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|---|---|---|---|---|
|**Recomendação**|Considere como fatores pr<br>glifosato:<br><br>idade> 50 anos,<br><br>quantidade ingerida i<br><br>frequência cardíaca>|editivos de complicações n<br>gual ou superior a 125mL de p<br>100 bpm, na admissão|as vítimas de intoxicação p<br>roduto,|or formulações à base de|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações**<br>**implementação**|||||
|**Monitoramento e avaliação**|||||  
209

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE -->
|**Prioridades**|**de pesquisa**|||
|---|---|---|---|
|**PERGUNTA**<br>**P**População|**: Quais são os testes auxiliam na avaliaç**<br>intoxicadaporglifosato|**ão clínica dopaciente com suspeita de intoxicação**|**comglifosato?**|
|**I**testes labo<br>**C**Ausência d|ratoriais(Determinação de K sérico, Dosage<br>a intervenção|m de Lactato, dosagem de creatinina)||
|**O**Mortalidad|e; Internação; Discapacidade|||
|**S**Clínicos e|observacionais<br>|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios**<br>**e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa (Det. K sérico – tempo<br>internação)<br>☒Baixa (Det. K sérico - mortalidade)<br>☒Moderada (Dosagem de lactato)<br>☒Alta (Dosagem de creatinina)|A comparação dos níveis de lactato sérico entre<br>203 sobreviventes (3,3± 2,2 mmol / L; p <0,001)<br>e 29 não sobreviventes (6,5±3,1 mmol /L),<br>vítimas de intoxicação por formulações à base<br>de lactato, indicou por meio de uma análise<br>multivariada que uma concentração superior a<br>4,7 mmol/ L do íon foi associada ao aumento da<br>mortalidade (razão de risco 3,2; IC95% 1,1–8,7).<br>Além do lactato, idade> 59 anos, intervalo QT<br>corrigido> 495 ms e K<sup>+</sup>> 5,5 mmol / L foram<br>considerados<br>como<br>fatores<br>de<br>risco||  
210

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
|independentes para mortalidade em 30 dias|
|---|
|(KIM, YH et al., 2016).|
|A hipercalemia é observada nos casos de|
|ingestão de formulações à base de K(KAMIJO<br>|
|et al., 2012; MOON; CHUN, 2010), sendo|
|também<br>um<br>preditor<br>independente<br>de|
|mortalidade, quando apresenta valores acima<br>de 4,5mmol/L (KIM, Y H et al., 2016; LEE, Hsin|
|Ling et al., 2000).|
|Estudo realizado com 58 vítimas de intoxicação<br>por glifosato, dos quais 17 evoluíram ao óbito.|
|Depois de análise univariada, a dificuldade|
|respiratória (expressa pela necessidade de|
|intubação), a acidose metabólica, a taquicardia,<br> <br> <br> <br> <br>|
|níveis<br>elevados<br>de<br>creatinina<br>(Cr)<br>e|
|hipercalemia<br>se<br>mostraram<br>altamente|
|relacionadas a desfechos indesejados e à|
|mortalidade (LEE, Ching Hsing et al., 2008)<br>A insuficiência renal aguda é uma complicação<br>comum observada em pacientes intoxicados por<br> <br> <br> <br> <br> <br>|
|for<br>formulações<br>à<br>base<br>de<br>glifosato,|
|principalmente em indivíduos acima de 40 anos.<br>Os valores de creatinina sérica, muitas vezes<br>dentro da normalidade na admissão, devem ser|  
211  
|||monitorados(MOHAMED et al., 2016).|
|---|---|---|
||**Há balanço entre os riscos e benefícios**<br>☐Benefícios sobrepõem os riscos<br>☐Há equilíbrio entre riscos e benefícios<br>☐Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito||
||Os custos associados à intervenção são<br>pequenos?||
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||  
212  
||**A opção é aceitável para as principais**<br>**partes interessadas?**||||
|---|---|---|---|---|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|**Viabilidade**|A opção é viável para implementar?<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|||**Conclusão**|||
|**Tipo de**|**recomendação**<br>**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca**<br>**contra a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|  
213  
||☐<br>☐<br>☐<br>☐|
|---|---|
|**Recomendação**|Na admissão e para o acompanhamento da evolução de pacientes com suspeita de exposição aguda a<br>produtos à base de glifosato, solicite a dosagem sérica de:<br>•<br>Lactato<br>•<br>K<sup>+</sup><br>•<br>Creatinina|
|**Justificativa**||
|**Considerações subgrupo**||
|**Considerações**<br>**implementação**||
|**Monitoramento e avaliação**||
|**Prioridades de pesquisa**||
|**PERGUNTA: Quais são os tes**|**tes auxiliam na avaliação clínica dopaciente com suspeita de intoxicação comglifosato?**|
|**P**População intoxicadaporglif|osato|  
214  
|**I** gasometria|||
|---|---|---|
|**C**Ausência|da intervenção||
|**O**Mortalidad|e; Internação; Discapacidade||
|**S**Clínicos e|observacionais||
||**Julgamento**|**Evidências**<br>**Considerações adicionais**|
|**Benefícios**<br>**e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☐Muito baixa<br>☐Baixa<br>☒Moderada<br>☐Alta|A complicação mais frequente observada em 76<br>vítimas de intoxicação por  herbicidas à base de<br>glifosato<br>foi<br>a<br>acidose<br>metabólica<br>(36,8%)(MOON; CHUN, 2010), sendo essa uma<br>complicação também observada por outros<br>estudos (HSIN-LING LEE, MD, KUAN-WEN<br>CHEN, MD, CHIH-HSIEN CHI, MD, JENG-<br>JONG<br>HUANG,<br>MD,<br>LIANG-MIIN<br>TSAI,<br>MDFIGURE, 2000; KHOT et al., 2014; KIM, Y H<br>et al., 2016; LEE, ChingHsinget al., 2008).|
||**Há balanço entre os riscos e benefícios**<br>☐Benefícios sobrepõem os riscos<br>☐Há equilíbrio entre riscos e benefícios<br>☐Riscos sobrepõem os benefícios||  
215  
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|---|---|
||**Os custos associados à intervenção são**<br>**pequenos?**|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim|
||☐Há variabilidade|  
216  
||**A opção é aceitável para as principais**<br>**partes interessadas?**||||
|---|---|---|---|---|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|**Viabilidade**|**A opção é viável para implementar?**<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|||**Conclusão**|||
|**Tipo de**|**recomendação**<br>**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|  
217  
||☐|☐<br>☐|☐|
|---|---|---|---|
|**Recomendação**|Solicite gasometria<br>formulações à base|arterial para todo paciente admitido e classificado como<br>de glifosato. Considere a possibilidade do rápido estabe|grave, vítima de intoxicação com<br>lecimento da acidose metabólica.|
|**Justificativa**||||
|**Considerações subgrupo **||||
|**Considerações**<br>**implementação**||||
|**Monitoramento e avaliação**||||
|**Prioridades de pesquisa**||||
|**PERGUNTA: Quais são os te**|**stes auxiliam na avali**|**ação clínica dopaciente com suspeita de intoxicação**|**comglifosato?**|
|**P**População intoxicadaporglif|osato|||
|**I**outros exames||||
|**C**Ausência da intervenção||||
|**O**Mortalidade; Internação; Disc|apacidade|||
|**S**Clínicos e observacionais||||
|**Julgamento**||**Evidências**|**Considerações adicionais**|
|**Benefício**<br>**s e**<br>**riscos**<br>**Qual a qualidade**<br>☐Sem estudos<br>☒Muito baixa|**da Evidência**|Em<br>pacientes<br>intoxicados<br>com<br>produtos<br>contendo sal de potássio (Roundup Maxload e<br>Touchdown IQ) foi observado ECG anormal,<br>com prolongamento dos intervalos  QRS e QT,||  
218  
|☐Baixa|com pico da onda T, taquicardia ventricular e|
|---|---|
|☐Moderada<br>☐Alta|condução elétrica anormal (KAMIJO; TAKAI;<br>SAKAMOTO, 2016).<br>Anormalidades do ECG observadas entre 76<br>pacientes vítimas de intoxicação aguda por<br>glifosato: prolongamento do intervalo QTc<br>(51.7%), taquicardia sinusal (13.8%), bloqueio<br>AV de primeiro grau (10.3%), anormalidade ST-<br>T<br>(10.3%),<br>bradicardia<br>sinusal<br>(5.2%)<br>e<br>taquicardia com alargamento QRS (1.7%). O<br>maior prolongamento QTc foi observado entre os<br>indivíduos agrupados como “complicados”, na<br>admissão (complicado 470,8 ± 48,9 ms vs. não<br>complicado 438,0 ± 37,3 ms, p = 0,010). (MOON;<br>CHUN, 2010).<br>Os achados anormais mais comuns no ECG<br>observados em 153 vítimas de exposição aguda<br>ao glifosato foram prolongamento do intervalo<br>QTc, tendo sido também observado o atraso da<br>condução<br>intraventricular<br>e<br>bloqueio<br>atrioventricular. Pacientes que foram a óbito<br>apresentaram maior prolongamento do intervalo<br>QTc quando comparado aos sobreviventes<br>(sobreviventes:<br>453,4<br>±<br>33,6<br>vs<br>não|  
219  
|sobreviventes: 542 ± 32,0, P b 0,001) (KIM, Yong|
|---|
|Hwan et al., 2014).|
|Alterações anormais em Raio X de Tórax|
|observadas em pacientes com histórico de|
|exposição aguda ao glifosato, admitidos em um|
|serviço<br>de<br>emergência,<br>principalmente|
|taquicardia sinusal e alterações inespecíficas de<br>ST-T. Dos 105 pacientes que tiveram radiografia|
|de tórax realizada, em 22 foram observados|
|infiltrados ou manchas anormais. Três dos 131|
|desenvolveram<br>insuficiência<br>renal<br>e|
|necessitaram de hemodiálise; indo todos a|
|óbito(LEE, Hsin Ling et al., 2000).|
|Alterações no intervalo QT (KIM, Yong Hwan et<br>al., 2016).|
|Dentre 76 vítimas de intoxicação intencional com|
|formulações à base de glifosato, em 17 (22.4%)|
|foram observadas anormalidades radiográficas,<br>sendo que 7 pacientes apresentaram infiltrados|
|pulmonares e 10 foram diagnosticados com|
|<br>edema agudo de pulmão (MOON; CHUN, 2010).|
|As complicações pulmonares são associadas à<br>mortalidade de pacientes vítimas de exposição<br>aguda a formulações contendoglifosato(LEE,|  
220  
||Ching Hsing et al., 2008; NINCEVIC et al., 2017;<br>OZAKI; SOFUE; KURODA, 2017)<br>A lesão pulmonar aguda é observada em<br>pacientes<br>intoxicados<br>por<br>formulações<br>contendo<br>POEA<br>(KAMIJO;<br>TAKAI;<br>SAKAMOTO, 2016).|
|---|---|
|**Qual a qualidade da Evidência**||
|☐Sem estudos<br>☐Muito baixa<br>☐Baixa<br>☐Moderada<br>☐Alta||
|**Há balanço entre os riscos e benefícios**||
|☐Benefícios sobrepõem os riscos<br>☐Há equilíbrio entre riscos e benefícios<br>☐Riscos sobrepõem os benefícios||  
221  
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|---|---|
||**Os custos associados à intervenção são**<br>**pequenos?**|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|  
222  
||**A opção é aceitável para as principais**<br>**partes interessadas?**||||
|---|---|---|---|---|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|**Viabilidade**|A opção é viável para implementar?<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|||**Conclusão**|||
|**Tipo de**|**recomendação**<br>**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|  
223  
||☐<br>☐<br>☐<br>☐|
|---|---|
|**Recomendação**|Na admissão de pacientes com suspeita de exposição aguda a produtos à base de glifosato, solicite<br>eletrocardiograma (ECG) e Raio X de tórax, principalmente os com suspeita de intoxicação moderada ou grave.|
|**Justificativa**||
|**Considerações subgrupo**||
|**Considerações**<br>**implementação**||
|**Monitoramento e avaliação**||
|**Prioridades de pesquisa**||  
224  
**QUADRO III.3.2** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para o tratamento de Intoxicações <u>por agrotóxicos a base de glifosato</u>  
|**PERGU**|**NTA: Quais são os métodos de eliminaçã**|**o efetivos na intoxicaçãoporglifosato?**||
|---|---|---|---|
|**P**Popul|ação intoxicada com agrotóxicos|||
|**I**métod|os de eliminação|||
|**C**Ausên|cia da intervenção|||
|**O**Reduç|ão da mortalidade|||
|**S**Clínico|s e observacionais|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa<br>☐Baixa<br>☐Moderada<br>☐Alta|O uso precoce de hemodiálise em um paciente<br>gravemente intoxicado por herbicida à base de<br>glifosato foi associado a um bom resultado<br>clínico. A hemodiálise foi realizada 16 horas após<br>a ingestão do produto, como tratamento para<br>hipercalemia refratária e acidose persistente. Foi<br>observada uma redução na concentração sérica<br>de glifosato após o término do procedimento:<br>Cinicial=240 mcg/mL e Cfinal= 92,6 mcg/mL<br>(GARLICH et al., 2014).<br>Paciente em estado grave após ingestão<br>intencional de um a formulação constituída por<br>41% de isopropilamina de glifosato e 15% de<br>POEA recebeu, inicialmente, oxigenação por<br>membrana<br>extracorpórea<br>venoarterial<br>(VA-||  
225  
|ECMO), iniciada 3 horas após a admissão,|
|---|
|devido à hipotensão profunda refratária, mesmo<br>após a administração de agente duplo inotrópico.<br>A hemodiálise venosa contínua (CVVH) também<br>foi aplicada simultaneamente com ECMO, sendo<br> <br> <br>|
|observada<br>uma<br>redução<br>considerável<br>na|
|concentração plasmática de glifosato: C4,5h=970|
|ppm e C134h= 3,54 mcg/mL. (CHAN et al., 2016).|
|Realizada<br>hemodiafiltração<br>venovenosa|
|contínua (CVVHDF) em indivíduo de 66 anos,|
|com comprometimento hemodinâmico devido a|
|ingestão de 350 mL de Roundup, juntamente|
|com 500 mL de bebida alcoólica. Na admissão|
|apresentava um quadro de hipóxia, hipotensão|
|(87/45 mmHg) e acidose láctica pronunciada.|
|Recebeu terapia de suporte. Contudo, entrou em<br>estado de choque (pressão arterial 66/43 mmHg,<br>|
|leucócitos e agudização da acidose láctica)|
|juntamente com aparecimento de falência|
|múltipla de órgãos. A CVVHDF foi iniciada 12|
|horas após a sua admissão na unidade e|
|interrompida após 60h, sendo observada visível<br>melhora do quadro clínico do paciente após a 24ª<br>hora.(HOUR et al., 2012)|  
226

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde Secretaria de Ciência, Tecnologia e Insumos Estratégicos SCTIE -->
||**Há balanço entre os riscos e benefícios**|
|---|---|
||☐Benefícios sobrepõem os riscos<br>☐Há equilíbrio entre riscos e benefícios<br>☐Riscos sobrepõem os benefícios|
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
||Os custos associados à intervenção são<br>pequenos?|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|  
227

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 3 | secao: Ministério da Saúde -->
<!-- Start of picture text -->
A opção é aceitável para as principais<br>partes interessadas?<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade<br>A opção é viável para implementar?<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade<br>Conclusão<br>Tipo de recomendação  Recomendação forte  Recomendação  Recomendação  Recomendação forte a<br>contra a intervenção  condicional/fraca contra  condicional a favor da  favor da intervenção<br>a intervenção  intervenção<br>Aceitabilidade<br>Viabilidade<br><!-- End of picture text -->  
228  
||☐<br>☐<br>☐<br>☐|
|---|---|
|**Recomendação**|Nos casos graves de intoxicação com produtos à base de glifosato, considere a utilização de métodos dialíticos<br>no intuito de favorecer a remoção de todos os ingredientes presentes na formulação.|
|**Justificativa**||
|**Considerações subgrupo**||
|**Considerações**<br>**implementação**||
|**Monitoramento e avaliação**||
|**Prioridades de pesquisa**||
|**PERGUNTA: Qual é o tratam**|**ento inicialpara opaciente intoxicado comglifosato?**|
|**P**População intoxicada com ag|rotóxicos inibidores de colinesterase|
|**I**administraçãoparenteral de e|mulsão lipídica|
|**C**Ausência da intervenção||
|**O**Redução da mortalidade e te|mpo de internação|  
229  
|**S**Clínic|os e observacionais<br>|||
|---|---|---|---|
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa (tempo de internação)<br>☐Baixa<br>☒Moderada (mortalidade)<br>☐Alta|Foi demonstrado por meio de um estudo clínico<br>aberto, de grupos paralelos, no qual 64<br>pacientes, com histórico de ingestão intencional<br>de formulações à base de glifosato, que o uso da<br>emulsão lipídica reduziu a incidência de<br>hipotensão (0% vs. 40,9%, p <0,001) e de<br>arritmia (0% vs. 22,7%, p <0,048), reduzindo o<br>risco de complicações clínicas e o período de<br>hospitalização (GIL et al., 2013).<br>Administração em bolus, 1,5 mL/kg de SMOFlipid<br>a<br>20%<br>(Fresenius<br>Kabi,<br>Bad<br>Homburg,<br>Alemanha), seguida de infusão contínua (0,25<br>mL/kg), por 20 min, após resposta inadequada à<br>norepinefrina (128 μg/min) por 2 horas, em<br>paciente de 65 anos, com comprometimento<br>hemodinâmico (PA 90/30 mm Hg; 77 bpm; 35°C)<br>decorrente da ingestão intencional de 150mL de<br>uma formulação à base de glifosato. A infusão<br>lipídica auxiliou na estabilização hemodinâmica<br>dopaciente, oqual, após ser submetido||  
230  
||hemodiálise contínua por sete dias, recebeu alta<br>(YOU; JUNG; LEE, 2012).<br>Paciente de 52 anos de idade, após ingestão<br>intencional de 300 mL de uma formulação<br>contendo 41% de isopropilamina de glifosato e<br>15% de POEA, deu entrada em serviço de<br>emergência bradicárdico (44bpm) e eupneico (15<br>mrpm).<br>Permaneceu<br>hemodinamicamente<br>instável (PAS 80 mmHg), mesmo após a infusão,<br>por cerca de 2,5h, de dopamina e atropina, além<br>de<br>outras<br>terapias<br>de<br>suporte,<br>incluindo<br>ventilação mecânica e reposição volêmica.<br>Decidiu-se pela administração de 100 mL, em<br>_bolus_, de uma emulsão lipídica a 20%. Em<br>seguida, 400mL da mesma solução foram<br>infundidos a uma velocidade de 1,5mL/min.<br>Indícios de normalização da pressão arterial<br>foram observados após uma hora da injeção_em_<br>_bolus_(100/60 mmHg). Transcorridas cinco horas<br>do início da terapia, as drogas vasoativas foram<br>reduzidas, considerando a normalização da<br>pressão arterial (60/100 mmHg)(HAN, Sang<br>Kyoon et al., 2010).|
|---|---|
|**Há balanço entre os riscos e benefícios**||  
231  
||☐Benefícios sobrepõem os riscos<br>☐Há equilíbrio entre riscos e benefícios<br>☐Riscos sobrepõem os benefícios|
|---|---|
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|**Custos**|**Os custos associados à intervenção são**<br>**pequenos?**<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|  
232  
||**A opção é aceitável para as principais**<br>**partes interessadas?**||||
|---|---|---|---|---|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|**Viabilidade**|A opção é viável para implementar?<br>☐Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade||||
|||**Conclusão**|||
|**Tipo d**|**e recomendação**<br>**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|  
233  
||☐<br>☐<br>☐<br>☐|
|---|---|
|**Recomendação**|Considere a administração parenteral de emulsão lipídica* em pacientes com histórico intoxicação grave por<br>produtos à base de glifosato, que apresentem hipotensão refratária, mesmo após medidas de suporte, na<br>seguinte posologia:<br><br>1,5mL/Kg, em 3 horas (20 mL/h), aos pacientes com histórico de ingestão de um volume inferior a 100 mL;<br><br>Infundir 500mL,nas 3h iniciais,com uma dose de manutenção de 1.000mL nas 24h subsequentes|
|**Justificativa**||
|**Considerações subgrupo**||
|**Considerações**<br>**implementação**||
|**Monitoramento e avaliação**||
|**Prioridades depesquisa**||  
234

---

