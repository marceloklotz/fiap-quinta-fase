<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: Geral -->
<!-- Start of picture text -->
Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA CONJUNTA Nº 13, DE 4 DE MAIO DE 2018.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Deficiência de Biotinidase.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a deficiência da biotinidase no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicas e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 276/2017, o Relatório de Recomendação nº 294 – Julho de 2017 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca de evidências e a avaliação da literatura; e,  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Deficiência de Biotinidase.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da deficiência da biotinidase, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio: http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação da paciente ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento deficiência de biotinidase.  
Art. 3º Os gestores estaduais, distritais e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais  
e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
FRANCISCO DE ASSIS FIGUEIREDO  
MARCO ANTÔNIO DE ARAÚJO FIREMAN

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 1 INTRODUÇÃO -->
A deficiência de biotinidase (DB) é um erro inato do metabolismo, de herança autossômica recessiva, no qual a biotinidase, enzima responsável pela capacidade de obtenção da vitamina biotina a partir dos alimentos, tem sua atividade catalítica diminuída ou ausente. Na DB, a biotina – ou vitamina H, pertencente ao grupo de vitaminas hidrossolúveis do complexo B – não pode ser liberada a partir de pequenos biotinilpeptídios e da biocitina, presentes em alimentos, como leite, ovos, carne, nozes e arroz integral. Essa vitamina é cofator de diversas enzimas carboxilases, envolvidas na síntese de ácidos graxos, no metabolismo da isoleucina e valina bem como na gliconeogênese. Assim, pacientes com DB são incapazes de reciclar a biotina endógena ou usar a biotina ligada às proteínas da dieta (1). Consequentemente, a biotina é perdida na urina, principalmente sob a forma de biocitina, ocorrendo o esgotamento progressivo.  
Os pacientes com DB apresentam uma grande variabilidade nas manifestações clínicas da doença bem como na idade de apresentação dos sintomas. A DB caracteriza-se principalmente pelo desenvolvimento gradual dos sintomas e pela ocorrência de episódios de remissão (que podem estar correlacionados ao aumento da ingestão de biotina livre na dieta). O quadro clínico completo já foi relatado a partir da sétima semana de vida, mas sintomas neurológicos mais discretos podem ocorrer mais cedo, ainda no período neonatal (2). No entanto, algumas crianças não desenvolvem sintomas nem na adolescência (3) e nem mesmo na idade adulta (4). Manifestações neurológicas, como hipotonia muscular, letargia, crises convulsivas mioclônicas e ataxia, são os sinais clínicos iniciais mais comuns. Além disso, anormalidades respiratórias, tais como estridor, episódios de hiperventilação e apneias, ocorrem com frequência (sendo, geralmente, de origem neurológica) (5). _Rash_ cutâneo e alopecia são achados característicos da doença, no entanto, eles podem ocorrer mais tardiamente ou até mesmo não ocorrer em alguns pacientes (6,7). As lesões de pele usualmente são desiguais, próximas dos orifícios, com características eritematosas e exsudativas. Dermatite eczematosa também tem sido observada em grandes áreas do corpo, acompanhada ou não de ceratoconjuntivite e queda de cabelo (desde pequenas a grandes quantidades, incluindo cílios e supercílios) (8).  
Devido à variabilidade e inespecificidade das manifestações clínicas, há um grande risco de atraso no diagnóstico, quando ele não é feito por meio de triagem neonatal (9). Pacientes com diagnóstico tardio têm, na maioria das vezes, retardo psicomotor e outros sintomas neurológicos, tais como leucoencefalopatia, perda auditiva e atrofia óptica, que podem ser irreversíveis e até mesmo fatais (10-12).  
O diagnóstico definitivo de DB exige confirmação laboratorial (13), a ser realizada pela medida da atividade enzimática feita em plasma por método colorimétrico (14) ou fluorimétrico (15). O diagnóstico neonatal pode ser efetuado por triagem neonatal (condição ideal) em pacientes ainda assintomáticos. Para a triagem neonatal, utilizam-se cartões de papel-filtro  
impregnados de sangue, nos quais é possível aferir a atividade de biotinidase mediante um ensaio colorimétrico qualitativo que utiliza o biotinil-p-aminobenzoato como substrato (16). Os resultados da triagem neonatal, quando indicativos de DB, devem ser posteriormente confirmados por medida em plasma (16,17).  
Em 1990, Wolf e Heard (18) publicaram um trabalho com uma amostra de doze países (Austrália, Áustria, Canadá, Itália, Japão, México, Nova Zelândia, Escócia, Espanha, Suíça, Alemanha e Estados Unidos) composta por 4.396.834 de recém-nascidos submetidos a programas de triagem neonatal, estimando dessa forma a incidência mundial de DB grave ou leve em 1 a cada 61.067 recém-nascidos (IC95% de 1/49.500 a 1/79.544). Outras pesquisas que usaram dados nacionais de sistemas públicos de triagem neonatal mostram incidências que variaram de 1 para 11.614 (Turquia) a 1 para 35.900 (Áustria) (19,20).  
Um estudo brasileiro realizado por Pinto e colaboradores (21) em 1998 no estado do Paraná, em uma amostra de 125.000 recém-nascidos submetidos à triagem neonatal em um período de 8 meses, revelou uma incidência de 1 para cada 62.500 recém-nascidos, o que parece estar de acordo com o publicado na literatura internacional. No entanto, outro trabalho brasileiro, publicado em 2004 por Neto e colaboradores (17), em uma amostra de 225.136 recém-nascidos (entre 2 e 30 dias de vida) submetidos à triagem neonatal privada em um período de 4 anos, revelou inicialmente uma atividade baixa ou ausente em 272 amostras, das quais 240 foram re-testadas em papel-filtro, sendo que em 204 delas a atividade enzimática esteve normal e nas demais 36 a atividade esteve abaixo de 30%. Vinte e dois desses casos (22/36, aproximadamente 60%) foram confirmados por análises em plasma, obtendo-se uma incidência estimada de 1 para cada 9.000 recém-nascidos (amostra total final ajustada de 198.694). No entanto, cabe ressaltar que os 22 pacientes foram testados e em apenas 15 deles (68,2%) foram detectadas mutações em homozigose (4 eram heterozigotos, e 3, normais), dos quais apenas 3 possuíam deficiência grave de biotinidase. Após as análises, a incidência reduzse significativamente para 1:15.500 recém-nascidos (quando se considera DB grave ou leve) e para 1:75.000 recém-nascidos (quando se considera somente casos de DB grave). As amostras do trabalho de Neto e colaboradores (17) eram provenientes de diversas regiões do Brasil, estando, portanto, submetidas a uma grande variação de temperatura durante seu transporte e armazenagem. Como biotinidase é uma enzima termossensível, há que se cogitar da possibilidade de aumento de falso-positivos em decorrência dessa variável.  
No Brasil, com base na incidência aproximada de 1:60.000 nascidos vivos em uma população de cerca de 207 milhões de habitantes, e extrapolando os resultados encontrados pelos pesquisadores brasileiros, estima-se que possam existir aproximadamente 3.450 pacientes com DB.  
A identificação de ocorrência familiar, de complicações e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado no âmbito do Programa Nacional de Triagem Neonatal dá à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
2 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- E88.9 Distúrbio metabólico não especificado

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 3.1 DIAGNÓSTICO CLÍNICO -->
Idealmente, o diagnóstico deve ocorrer no período pré-sintomático. No entanto, o diagnóstico em crianças que não se submeteram à triagem neonatal (diagnóstico tardio) deve ser suspeitado quando da presença de um ou mais sinais clínicos clássicos: crises convulsivas mioclônicas refratárias ao tratamento, associadas à dermatite atópica ou seborreica, alopecia, ataxia, conjuntivite e candidíase (8). Outros sintomas clínicos frequentes nesses pacientes são hipotonia, problemas respiratórios (como hiperventilação, estridor laríngeo, apneias), atraso no desenvolvimento neuropsicomotor (por comprometimento crônico), surdez e atrofia óptica. No entanto, o diagnóstico definitivo de DB deve ser estabelecido com base em anormalidades bioquímicas específicas confirmadas laboratorialmente (8, 22, 23).

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 3.2 DIAGNÓSTICO LABORATORIAL -->
Quando realizado em programas de triagem neonatal, o diagnóstico permite tratamento precoce e prevenção do desenvolvimento do quadro clínico (8). Para a triagem neonatal, o sangue é coletado e impregnado em cartões de papel-filtro, nos quais é possível aferir a atividade de biotinidase por meio de um ensaio colorimétrico qualitativo que utiliza o biotinilp-aminobenzoato como substrato (16). Os resultados da triagem neonatal, quando indicativos de DB (leve ou grave), devem ser posteriormente confirmados por medida quantitativa em plasma (16,17).  
Para o diagnóstico definitivo de DB, exige-se a confirmação laboratorial (8,13,23), que deve ser realizada por medida da atividade enzimática em plasma (24) feita por método colorimétrico ou fluorimétrico (15). Cabe ressaltar que a ingestão de biotina por um indivíduo a ser testado para DB (medida da atividade enzimática) não interfere no resultado do exame (25).  
Com base no nível da atividade de biotinidase, os pacientes são classificados em três grupos principais (23):  
- pacientes com atividade normal – pelo menos mais de 30% da média da atividade sérica normal de biotinidase (em relação ao controle do padrão laboratorial);  
- pacientes com DB leve – com 10%-30% da média da atividade sérica normal de biotinidase (em relação ao controle do padrão laboratorial);  
- pacientes com DB grave – menos de 10% da média da atividade sérica normal de biotinidase (em relação ao controle do padrão laboratorial).  
Na análise dos resultados, é importante atentar para fatores responsáveis por resultados de testes falso-positivos (como prematuridade, doença hepática, icterícia e fatores ambientais e técnicos – sendo necessários cuidados com a coleta, a conservação da amostra, o tempo de processamento, o transporte, etc.) e falso-negativos (como uso de sulfonamidas e transfusão de hemoderivados) (26).

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 4 CRITÉRIOS DE INCLUSÃO -->
Serão incluídos neste Protocolo todos os pacientes com diagnóstico de DB confirmado por medida plasmática da atividade enzimática da biotinidase (teste laboratorial) e com atividade residual inferior a 30% da atividade normal, isto é, DB leve ou grave (24). Pacientes com resultados da triagem neonatal alterados serão classificados como suspeitos e deverão ser  
incluídos neste Protocolo (entrar em tratamento) até a confirmação ou não do diagnóstico, o qual será estabelecido a partir da determinação quantitativa da atividade sérica de biotinidase, conforme já descrito.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 5 CRITÉRIOS DE EXCLUSÃO -->
Serão excluídos deste Protocolo todos os pacientes com hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 6 CASOS ESPECIAIS -->
A análise de DNA (pesquisa de mutações) não é usada rotineiramente no diagnóstico da DB pela ausência de uma clara correlação genótipo-fenótipo, não sendo, também, uma ferramenta diagnóstica útil para o estabelecimento do prognóstico desses pacientes (27, 28, 29). Esse tipo de exame fica restrito a casos especiais quando há necessidade de elucidação diagnóstica em resultados enzimáticos contraditórios ou diagnóstico pré-natail, por exemplo.  
Existem raros casos de pacientes com DB que apresentam variantes _Km_ da enzima biotinidase. Esses indivíduos apresentam atividade enzimática normal aos testes usualmente realizados, que utilizam como substrato biocitina, mas a testagem com substratos mais específicos evidenciam a diminuição de afinidade e, logo, resultado diminuído da atividade enzimática, caracterizando DB (30). Na grande maioria das vezes, são pacientes clinicamente assintomáticos, mas eventualmente podem apresentar quadros clínicos variáveis que necessitam de tratamento (31). Em virtude de sua especificidade e da restrição de uso, não se protocola este exame.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 7 COMITÊ DE ESPECIALISTAS/CENTRO DE REFERÊNCIA -->
O aconselhamento genético e o atendimento dos casos devem ser realizados conforme o estabelecido pelo Programa Nacional de Triagem Neonatal do Ministério da Saúde.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 8 TRATAMENTO -->
Todos os indivíduos com DB devem ser tratados por meio da suplementação com biotina oral em sua forma livre (não conjugada) (32), incluindo os pacientes com DB leve, pois também podem apresentar manifestações clínicas (33, 34).  
É importante frisar que o uso contínuo e diário é fundamental para o tratamento, uma vez que a depleção da biotina ocorre rapidamente (2). Após a suspeita do diagnóstico, o tratamento deve ser instituído sem demora, pois os pacientes tornam-se deficientes em biotina dentro de poucos dias após o nascimento (2). De modo geral, todos toleram biotina oral, sem efeitos colaterais. Medidas dietéticas ou restrições alimentares não são necessárias (35).  
Fica evidente na revisão da literatura científica que a maior parte do que se sabe sobre as características clínicas e a história natural de DB é proveniente de relatos ou pequenas séries de casos, em geral de pacientes que foram diagnosticados após o aparecimento dos sintomas. Nenhum ensaio clínico randomizado foi encontrado, mas todos os pacientes tratados com biotina apresentam melhora dos quadros clínico e laboratorial, que pode resultar em pouca (pacientes sintomáticos com tratamento precoce) ou nenhuma (pacientes assintomáticos tratados) sequela neurológica residual (25).  
Entre as séries de casos localizadas na literatura, havia cinco trabalhos com mais de 20 indivíduos que descrevem aspectos clínicos de pacientes com DB sintomáticos e assintomáticos  
tratados com biotina. Em 2003, Lászlo e colaboradores (34) relataram a evolução clínica de 20 pacientes húngaros com DB (55% de DB grave) diagnosticados por triagem neonatal, no período de 1989 a 2001, sendo que todos os que se encontravam em tratamento com biotina permaneceram assintomáticos, havendo períodos de piora e remissão em 3 deles por não adesão ao tratamento.  
Em 2001, Möslinger e colaboradores (20) publicaram um trabalho incluindo 30 pacientes austríacos provenientes do programa de triagem neonatal (18/30 com deficiência grave), sendo que os com atividade enzimática residual acima de 1% se mantiveram assintomáticos (n = 13) até a finalização do diagnóstico (em média 8 semanas). Os pacientes com DB grave tratados com biotina antes de 8 semanas de vida permaneceram assintomáticos até a última revisão clínica (idades entre 1,5-10 anos) e tiveram o escore de QI dentro da normalidade (variando de 85-114). Nos pacientes (n = 9) que atrasaram o início do tratamento ou o descontinuaram, foram observados QI abaixo do normal e atraso na aquisição da fala.  
Posteriormente, em 2003, Möslinger e colaboradores (28) publicaram novo trabalho descrevendo desfechos neuropsicológicos de 21 pacientes, dos quais 18 foram diagnosticados por triagem neonatal. Não há referência ao trabalho anterior (de 2001), mas há indícios claros de se tratar da mesma amostra. Os pacientes diagnosticados por triagem neonatal (n=18) tiveram o diagnóstico estabelecido entre 4-8 semanas de vida; os que iniciaram tratamento com biotina até a oitava semana de vida permaneceram clínica e neurologicamente assintomáticos até a última revisão dos autores (idades entre 2-12 anos), tendo escores de QI dentro da média (variando de 85-110,5). Em 3 (3/18) com descontinuação ou má adesão ao tratamento, houve documentação de redução do escore de QI abaixo do valor normal (66,5; 65 e 77), reforçando não só a ideia de tratamento precoce como sua manutenção.  
Weber e colaboradores (11), em 2004, descreveram os resultados do tratamento com biotina em pacientes com DB ainda assintomáticos (n=26) e sintomáticos (n=11). Nenhuma criança com deficiência grave de biotinidase detectada por triagem neonatal (n=26) e com tratamento iniciado no período pré-sintomático teve perda auditiva ou visual, atraso no desenvolvimento da fala e nas aquisições motoras. Entre as tratadas já sintomáticas, houve maior ocorrência de problemas visuais (p < 0,001), problemas auditivos (p=0,004) e atraso na aquisição da marcha (p=0,002) e da fala (p= 0,022), quando comparadas às assintomáticas que foram tratadas. Não houve diferença significativa na adaptação social ou problemas de comportamento entre crianças sintomáticas e assintomáticas. Do ponto de vista audiológico, Genc e colaboradores (36), em 2007, verificaram, em uma série de 20 pacientes com DB em tratamento com biotina (10 mg/dia), que os tempos de latência e limiares de resposta dos potenciais evocados auditivos foram significativamente maiores nos com diagnóstico tardio do que nos com diagnóstico no período pré-sintomático (p < 0,05), sendo que, em cerca de 65% dos pacientes que iniciaram o tratamento sintomáticos, já havia algum grau de perda auditiva.  
Diversos relatos de casos foram publicados ao longo dos últimos 25 anos, descrevendo o sucesso do tratamento em prevenir a ocorrência de sintomas em pacientes assintomáticos e a melhora nos sintomáticos. Em alguns desses trabalhos estão referidas a prevenção do aparecimento de alterações visuais e auditivas (37) bem como a recuperação dessas manifestações quando já instaladas, tanto do ponto de vista clínico (13,31,38-40) quanto em relação a parâmetros eletrofisiológicos (como potenciais evocados e eletroneuromiografia) (30,31), neurorradiológicos (por exemplo, ressonância magnética) (9,39,41,42) e laboratoriais (como acidose láctica) (40), levando assim à manutenção ou recuperação do desenvolvimento  
neuropsicomotor normal (41) mesmo que em alguns casos a grande demora no início do tratamento ocasione irreversibilidade das sequelas neurológicas, oftalmológicas (especialmente, atrofia óptica) e auditivas (surdez neurossensorial) (9,13).  
Gestantes com DB parecem não apresentar aumento de risco significativo de malformações fetais nem desfechos perinatais desfavoráveis (43) quando tratadas com biotina. Não foram encontrados estudos em humanos descrevendo efeitos teratogênicos da DB. No entanto, trabalhos experimentais com modelos animais evidenciaram que a deficiência de biotina está fortemente associada a uma série de malformações fetais (44), mesmo sendo a suplementação de biotina em altas doses segura (44,46). Desta forma, a recomendação atual é manter o tratamento de forma regular, buscando adesão ao tratamento de todas as gestantes com DB.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: - Biotina: cápsulas de 2,5 mg. -->
<mark>As cápsulas devem ser integralmente deglutidas por crianças maiores (escolares e adolescentes) ou ter seu conteúdo retirado e administrado a lactentes, pré-escolares ou pacientes com distúrbios de deglutição juntamente com leite materno, fórmula infantil ou leite. A seguir, sem lavar a colher ou o dispensador, deve-se adicionar nova quantidade do líquido utilizado para que seja administrado todo o conteúdo da cápsula. Apresentações</mark> líquidas não são recomendadas devido à baixa solubilidade da biotina em solução aquosa (25).

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 8.2 ESQUEMAS DE ADMINISTRAÇÃO -->
A biotina deve ser utilizada na dose inicial de 5 mg/dia (independentemente do peso corporal) por todos os pacientes com diagnóstico de DB leve e de 10 mg/dia (independentemente do peso corporal) por todos os pacientes com diagnóstico de DB grave. Casos suspeitos devem iniciar com 10mg. Para casos sem resposta com a dose-padrão ou com exacerbações da doença, o que raramente ocorre, doses maiores (até 20 mg/dia) podem ser utilizadas em serviços de referência, entre eles o de triagem neonatal.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 8.3 TEMPO DE TRATAMENTO - CRITÉRIOS DE INTERRUPÇÃO -->
O tratamento preconizado deverá ser mantido por toda a vida, já que a interrupção da medida terapêutica produz o retorno ao quadro bioquímico inicial e suas consequentes manifestações clínicas. Cabe ressaltar que, em pacientes assintomáticos ou nos com boa resposta clínica, o tratamento deve ter suas doses mantidas, não havendo indicação de redução de dose. Obviamente, pacientes suspeitos que não tiveram a confirmação do diagnóstico devem suspender o tratamento.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 8.4 BENEFÍCIOS ESPERADOS -->
Os resultados de estudos em crianças com DB tratadas com biotina indicam que esse medicamento é eficaz na prevenção de sintomas (11,20,28). Os benefícios clínicos esperados variam de acordo com o momento da instituição do tratamento, isto é, se antes (diagnóstico neonatal ou em assintomáticos) ou após as primeiras manifestações clínicas.  
Nos casos em que o diagnóstico é realizado em recém-nascidos, como nos identificados em testes de triagem neonatal, os objetivos das medidas terapêuticas são, idealmente, evitar o aparecimento de qualquer manifestação da doença bem como garantir o desenvolvimento  
intelectual normal (37). Espera-se que com o tratamento com biotina haja manutenção dos parâmetros neuropsicomotores normais nos pacientes com diagnóstico precoce e que tiveram a instituição do tratamento adequado antes dos primeiros sintomas clínicos.  
No entanto, quando o diagnóstico é tardio, muitas vezes já ocorreram complicações e os benefícios esperados do tratamento consistem na prevenção do agravamento do quadro clínico e na melhora gradual das alterações neuropsicológicas e dermatológicas. Em muitos casos, mesmo com o quadro clínico completo estabelecido, pode haver remissão importante dos sinais e sintomas clínicos, tais como convulsões (47), leucoencefalopatia (9), surdez (48) e alterações neurorradiológicas (49).

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 9 MONITORIZAÇÃO -->
Os pacientes com DB devem ser monitorizados por uma equipe multidisciplinar, de acordo com as manifestações multisistêmicas da doença (35). O aconselhamento genético deve ser sempre realizado, uma vez que a doença é autossômica recessiva. O risco de recorrência para novos filhos de casal não afetado (ambos cônjuges heterozigotos) é de 25%.  
O acompanhamento clínico ambulatorial que se segue ao diagnóstico deve ser mensal até que haja remissão completa do quadro clínico, sendo feito após o controle total dos sintomas trimestralmente durante o primeiro ano de vida, semestralmente entre 1-5 anos e anualmente após os 5 anos (26,50). Os pacientes diagnosticados ainda assintomáticos devem fazer avaliações audiológica e oftalmológica a cada 2 anos até os 16 anos de vida. Naqueles cujo diagnóstico foi estabelecido já com essas manifestações, as avaliações de monitorização devem ocorrer pelo menos anualmente até os 16 anos de vida. Após essa idade, as avaliações podem manter-se bianuais ou conforme a sintomatologia (26,50).  
Na DB com resposta clínica à reposição de biotina na dose de 10 mg/dia, as anormalidades bioquímicas e convulsões tendem a se resolver rapidamente após a instalação do tratamento, sendo posteriormente acompanhadas de melhora das manifestações cutâneas. Nas crianças com alopecia, o crescimento do cabelo tende a retornar durante um período de semanas a meses. Atrofia óptica e perda auditiva podem ser resistentes à terapia, especialmente se decorrido longo período entre seu início e o início do tratamento (11,35). Assim sendo, considera-se resposta terapêutica ao tratamento a melhora clínica da doença (dos sintomas tanto neurológicos quanto dermatológicos), não sendo necessária a realização de exames laboratoriais (22).  
Após a melhora clínica ou a remissão completa dos sintomas, a dose deve ser continuada ao longo da vida. Nos casos em que não houver resposta adequada, aumentos da dose (até 20 mg/dia) deverão ser decididos por Comitê Estadual de Especialistas designado pelo Gestor Estadual.  
Biotina na dose de até 20 mg/dia é bem tolerada, inexistindo descrição de efeitos adversos ou intolerância ao medicamento. Após revisão na literatura sobre o uso de biotina em pacientes com DB, não foram encontrados trabalhos que descrevessem complicações agudas ou tardias com o uso prolongado do medicamento (35), não sendo verificado efeito adverso algum ao longo de mais de 20 anos de experiência no tratamento de DB (32) nem havendo registro de acúmulo de biocitina (metabólito tóxico da biotina) nos fluidos corporais (51), o que anteriormente suspeitava-se ser um possível risco.  
Gestantes com DB parecem não apresentar aumento de risco significativo de malformações fetais (43). Há poucos dados a respeito dos desfechos em gestações, mas um  
trabalho publicado em 2005 por Hendriksz e colaboradores (44) descreveu uma primigesta de 20 anos com o diagnóstico desde os 7 meses de vida, cuja gestação evoluiu sem intercorrências e com controles laboratoriais normais, mantendo-se durante todo o período gestacional em uso de biotina na dose de 30 mg/dia. Estudos com animais (porcos e camundongos) também mostraram que altas doses de biotina na gestação não afetam o desenvolvimento embrionário nem aumentam o risco de malformações fetais ou desfechos perinatais desfavoráveis (45,46). De forma contrária, DB, quando não tratada na gestação (ausência de suplementação de biotina), mostrou-se teratogênica em camundongos, com alta frequência de defeitos congênitos: fenda palatina (100%), micrognatia (100%) e micromelia (91,4%) (44), reforçando a indicação de tratamento em gestantes com DB.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 10 REGULAÇÃO / CONTROLE / AVALIAÇÃO PELO GESTOR -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento. A atenção aos pacientes com DB deve estar articulada com o Programa Nacional de Triagem Neonatal.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 11 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: 12 REFERÊNCIAS -->
1. Baumgartner ER, Suormala T. Multiple carboxylase deficiency: inherited and acquired disorders of biotin metabolism. Int J Vitam Nutr Res. 1997;67(5):377-84.  
2. Baumgartner ER, Suormala TM, Wick H, Bausch J, Bonjour JP. Biotinidase deficiency associated with renal loss of biocytin and biotin. Ann NY Acad Sci. 1985;447:272-87.  
3. Wolf B, Pomponio RJ, Norrgard KJ, Lott IT, Baumgartner ER, Suormala T, et al. Delayed-onset profound biotinidase deficiency. J Pediatr. 1998;132(2):362-5.  
4. Baykal T, Gokcay G, Gokdemir Y, Demir F, Seckin Y, Demirkol M, et al. Asymptomatic adults and older siblings with biotinidase deficiency ascertained by family studies of index cases. J Inherit Metab Dis. 2005;28(6):903-12.  
5. Baumgartner ER, Suormala TM, Wick H, Probst A, Blauenstein U, Bachmann C, et al. Biotinidase deficiency: a cause of subacute necrotizing encephalomyelopathy (Leigh syndrome). Report of a case with lethal outcome. Pediatr Res. 1989;26(3):260-6.  
6. Wastell HJ, Bartlett K, Dale G, Shein A. Biotinidase deficiency: a survey of 10 cases. Arch Dis Child. 1988;63(10):1244-9.  
7. Wolf B, Heard GS, Weissbecker KA, McVoy JR, Grier RE, Leshner RT. Biotinidase deficiency: initial clinical features and rapid diagnosis. Ann Neurol. 1985;18(5):614-7.  
8. Wolf, B. Disorders of biotin metabolism. In: Scriver CR, Beaudet AL, Sly WS, Valle D editores. The metabolic and molecular bases of inherited disease. 8ª ed. New York: McGraw Hill; 2001.  
9. Grünewald S, Champion MP, Leonard JV, Schaper J, Morris AA. Biotinidase deficiency: a treatable leukoencephalopathy. Neuropediatrics 2004;35(4):211-6.  
10. Ramaekers VT, Suormala TM, Brab M, Duran R, Heimann G, Baumgartner ER. A biotinidase Km variant causing late onset bilateral optic neuropathy. Arch Dis Child. 1992;67(1):115-9.  
11. Weber P, Scholl S, Baumgartner ER. Outcome in patients with profound biotinidase deficiency: relevance of newborn screening. Dev Med Child Neurol. 2004;46(7):481-4.  
12. Wolf B, Spencer R, Gleason T. Hearing loss is a common feature of symptomatic children with profound biotinidase deficiency. J Pediatr. 2002;140:242-6.  
13. Kaye CI; Committee on Genetics, Accurso F, La Franchi S, Lane PA, Hope N, et al. Newborn screening fact sheets. Pediatrics. 2006;118(3):e934-63.  
14. Wolf B, Grier RE, Allen RJ, Goodman SI, Kien CL. Biotinidase deficiency: the enzymatic defect in late-onset multiple carboxylase deficiency. Clin Chim Acta. 1983;131(3):273-81.  
15. Wastell H, Dale G, Bartlett K. A sensitive fluorimetric rate for biotinidase using a new derivative of biotin, biotinyl-6-aminoquinoline. Anal Biochem. 1984;140(1):69-73.  
16. Heard GS, Secor McVoy JR, Wolf B. A screening method for biotinidase deficiency  
in newborns. Clin Chem. 1982;30:125-7.  
17. Neto EC, Schulte J, Rubim R, Lewis E, DeMari J, Castilhos C, et al. Newborn screening for biotinidase deficiency in Brazil: biochemical and molecular characterizations. Braz J Med Biol Res. 2004;37(3):295-9.  
18. Wolf B, Heard GS. Screening for biotinidase deficiency in newborns: worldwide  
experience. Pediatrics. 1990;85(4):512-7.  
19. Baykal T, Hüner G, Sarbat G, Demirkol M. Incidence of biotinidase deficiency in Turkish newborns. Acta Paediatr. 1998;87(10):1102-3.  
20. Möslinger D, Stöckler-Ipsiroglu S, Scheibenreiter S, Tiefenthaler M, Mühl A, Seidl R, et al. Clinical and neuropsychological outcome in 33 patients with biotinidase deficiency ascertained by nationwide newborn screening and family studies in Austria. Eur J Pediatr. 2001;160(5):277-82.  
21. Pinto AL, Raymond KM, Bruck I, Antoniuk SA. Prevalence study of biotinidase deficiency in newborns. Rev Saude Publica. 1998;32(2):148-52.  
22. Silvestre CPC, Cortés BM. Alteraciones del catabolismo de leucina y valina. Déficit múltiple de carboxilasas. In: Sanjurjo P, Baldellou A, editores. Diagnóstico y tratamiento de las enfermedades metabólicas hereditarias. 2ª ed. Madrid: Ergon, 2006. p. 393-406.  
23. Baumgartner MR, Suormala T. Biotin-responsive disorders. In: Fernandes J, Saudubray J-M, van den Berghe G, editores. Inborn metabolic diseases. Diagnsosis and treatment. 3ª ed. Heidelberg: Spring-Verlag; 2000. p. 223-31.  
24. Cowan TM, Blitzer MG, Wolf B; Working Group of the American College of Medical Genetics Laboratory Quality Assurance Committee. Technical standards and guidelines for the diagnosis of biotinidase deficiency. Genet Med. 2010;12(7):464-70.  
25. Wolf B. Clinical issues and frequent questions about biotinidase deficiency. Mol Genet Metab. 2010;100(1):6-13.  
26. Wolf B. Biotinidase deficiency: “if you have to have an inherited metabolic disease, this is the one to have”. Genet Med. 2012;14(6):565-75.  
27. Mühl A, Möslinger D, Item CB, Stöckler-Ipsiroglu S. Molecular characterisation of 34 patients with biotinidase deficiency ascertained by newborn screening and family investigation. Eur J Hum Genet. 2001;9(4):237-43.  
28. Möslinger D, Mühl A, Suormala T, Baumgartner R, Stöckler-Ipsiroglu S. Molecular characterisation and neuropsychological outcome of 21 patients with profound biotinidase deficiency detected by newborn screening and family studies. Eur J Pediatr. 2003;162 Suppl 1:S46-9.  
29. Borsatto T, Sperb-Ludwig F, Lima SE, Carvalho MRS, Fonseca PAS, Camelo JS Jr, et al. (2017) Correction: Biotinidase deficiency: Genotype-biochemical phenotype association in Brazilian patients. PLoS ONE12(6): e0180463.  
30. Suormala T, Ramaekers VT, Schweitzer S, Fowler B, Laub MC, Schwermer C, et al. Biotinidase Km-variants: detection and detailed biochemical investigations. J Inherit Metab Dis. 1995;18(6):689-700.  
31. Ramaekers VT, Brab M, Rau G, Heimann G. Recovery from neurological deficits following biotin treatment in a biotinidase Km variant. Neuropediatrics 1993;24(2):98-102.  
32. Wolf B. Biotinidase deficiency: new directions and practical concerns. Curr Treat Options Neurol. 2003;5(4):321–8.  
33. McVoy JR, Levy HL, Lawler M, Schmidt MA, Ebers DD, Hart PS. Partial biotinidase deficiency: clinical and biochemical features. J Pediatr. 1990;116(1):78-83.  
34. László A, Schuler EA, Sallay E, Endreffy E, Somogyi C, Várkonyi A, et al. Neonatal screening for biotinidase deficiency in Hungary: clinical, biochemical and molecular studies. J Inherit Metab Dis. 2003;26(7):693-8.  
35. Wolf B. Biotinidase deficiency. GeneReviews [Internet]. Seattle (WA): University of Washington; 1993-2011.  
36. Genc GA, Sivri-Kalkanoglu HS, Dursun A, Aydin HI, Tokatli A, Sennaroglu L, et al. Audiologic findings in children with biotinidase deficiency in Turkey. Int J Pediatr Otorhinolaryngol. 2007;71(2):333-9.  
37. Wallace SJ (1985) Biotinidase deficiency: presymptomatic treatment. Arch Dis Child. 1985;60(6):574-5.  
38. Tsao CY, Kien CL. Complete biotinidase deficiency presenting as reversible progressive ataxia and sensorineural deafness. J Child Neurol. 2002;17(2):146.  
39. Yang Y, Li C, Qi Z, Xiao J, Zhang Y, Yamaguchi S, et al. Spinal cord demyelination associated with biotinidase deficiency in 3 Chinese patients. J Child Neurol. 2007;22(2):15660.  
40. Bay LB, de Pinho S, Eiroa HD, Otegui I, Rodríguez R. The importance of a law on time: presentation of a girl with biotinidase deficiency who was not picked up through the neonatal screening. Arch Argent Pediatr. 2010;108(1):e13-6.  
41. Casado de Frías E, Campos-Castelló J, Careaga Maldonado J, Pérez Cerdá C. Biotinidase deficiency: result of treatment with biotin from age 12 years. Eur J Paediatr Neurol. 1997;1(5-6):173-6.  
42. Haagerup A, Andersen JB, Blichfeldt S, Christensen MF. Biotinidase deficiency: two cases of very early presentation. Dev Med Child Neurol. 1997;39(12):832-5.  
43. Hendriksz CJ, Preece MA, Chakrapani A. Successful pregnancy in a treated patient with biotinidase deficiency. J Inherit Metab Dis. 2005;28:791-792.  
44. Watanabe T, Nagai Y, Taniguchi A, Ebara S, Kimura S, Fukui T. Effects of biotin deficiency on embryonic development in mice. Nutrition. 2009;25(1):78-84.  
45. Hamilton CR, Veum TL. Response of sows and litters to added dietary biotin in environmentally regulated facilities. J Anim Sci. 1984;59(1):151-7.  
46. Watanabe T. Morphological and biochemical effects of excessive amounts of biotin on embryonic development in mice. Experientia 1996;52(2):149-54.  
47. Joshi SN, Fathalla M, Koul R, Maney MA, Bayoumi R (2010) Biotin responsive seizures and encephalopathy due to biotinidase deficiency. Neurol India. 2010;58(2):323-4.  
48. Straussberg R, Saiag E, Harel L, Korman SH, Amir J. Reversible deafness caused by biotinidase deficiency. Pediatr Neurol. 2000;23(3):269-70.  
49. Desai S, Ganesan K, Hegde A. Biotinidase deficiency: a reversible metabolic encephalopathy. Neuroimaging and MR spectroscopic findings in a series of four patients. Pediatr Radiol. 2008;38(8):848-56.  
50. Burlina A, Walter J. Various organic acidurias. In: Blau N, Hoffmann GF, Leonard J, Clarke JTR, editores. Physician’s guide to the treatment and follow-up of metabolic disease. Heidelberg: Springer-Verlag, 2006. p. 93-97.  
51. Suormala TM, Baumgartner ER, Bausch J, Holick W, Wick H. Quantitative determination of biocytin in urine of patients with biotinidase deficiency using highperformance liquid chromatography (HPLC). Clin Chim Acta. 1988;177(3):253-69.  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE BIOTINA

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: Eu, -->
(nome do(a) paciente ou seu responsável), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de biotina, indicada para o tratamento da deficiência de biotinidase.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico  
_________________(nome do médico que prescreve).  
Expresso também minha concordância e espontânea vontade em submeter-me ao referido tratamento, assumindo a responsabilidade e os riscos por eventuais efeitos indesejáveis.  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- evita o aparecimento de qualquer manifestação da doença bem como garante o  
- desenvolvimento intelectual normal;  
- melhora os sintomas da doença;  
- previne as complicações associadas à doença.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- medicamento classificado na gestação como fator de risco B (não existem estudos bem adequados em mulheres grávidas, embora estudos em animais não tenham demonstrado efeitos prejudiciais do uso do medicamento na gravidez);  
- contraindicado em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  (    ) Sim (    ) Não  
Local:                                                             Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal:  
|_________________________________<br>Assinatura do paciente ou do responsável legal|
|---|
|Médico responsável:<br>CRM:<br>UF:|
|___________________________<br>Assinatura e carimbo do médico<br>Data:____________________|  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Deficiência de Biotinidase (PCDT) | secao: METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Foi realizada revisão da literatura nas bases de dados Medline/Pubmed, Embase, Cochrane, _Center for Review and Dissemination_ , bem como _GeneReviews_ e livros-texto em 18/07/2014.  
Na base de dados Medline/Pubmed, utilizado-se os termos “ _Biotinidase deficiency_ ” _AND Therapeutics_ e restringindo-se para estudos em humanos, nos idiomas português, espanhol e inglês, sem limite de data, identificaram-se 8 estudos. Apenas 2 deles foram considerados, já que os demais tratavam de aspectos outros que não o objeto da busca, como diagnóstico diferencial da deficiência de biotinidase, triagem neonatal e aspectos clínicos sem menção à  
terapêutica. Utilizando-se os termos “ _Biotinidase deficiency_ ” _AND Treatment_ e restringindo-se para estudos em humanos, nos idiomas português, espanhol e inglês, sem limite de data, identificaram-se 124 estudos, não sendo encontrada nenhuma meta-análise nem ensaio clínico randomizado. Desses, foram incluídos 31 trabalhos, uma vez que os demais tratavam de aspectos outros que não o objeto da busca, como diagnóstico diferencial da deficiência de biotinidase, triagem neonatal e aspectos clínicos sem menção à terapêutica. Cabe ressaltar que, quando se refinou a busca para “ _Clinical trials_ ”, “ _Practice Guidelines_ ” _and_ “ _systematic reviews_ ”, o número de artigos se restringiu a 6 no total, dos quais apenas 1 foi incluído, já que, entre os demais, 2 tratavam de triagem neonatal, 1 era relato de caso e 2 diziam respeito a aspectos bioquímicos/diagnóstico.  
Na base de dados Embase, utilizado-se os termos “ _Biotinidase deficiency_ ” _AND Treatment_ e restringindo-se para estudos em humanos, nos idiomas português, espanhol e inglês, sem limite de data, foram identificados 135 estudos. Desses, foram incluídos 24 trabalhos, já que os demais tratavam de aspectos outros que não o objeto da busca, como diagnóstico diferencial da deficiência de biotinidase, triagem neonatal e aspectos clínicos sem menção à terapêutica, estudos em animais, aspectos genéticos e bioquímicos.  
Na base de dados Cochrane, foi utilizada a expressão _Biotinidase deficiency_ , sendo identificado 1 trabalho (sobre aspectos econômicos de triagem neonatal), que não foi incluído.  
Na base de dados _Center for Review and Dissemination_ – CRD, foi utilizada a expressão _Biotinidase deficiency_ , sendo identificados 4 trabalhos (sobre aspectos econômicos de triagem neonatal), que não foram incluídos.  
Em 01/11/2017 foi atualização a busca da literatura a partir da realizada em 2014. No Pubmed, utilizando os termos "Biotinidase Deficiency"[Mesh] AND "humans"[MeSH Terms]) foram localizados 30 novos artigos. Na base Cochrane library, utilizando-se o termo “Biotinidase deficiency”, nenhuma revisão foi localizada e na base Embase, utilizando os termos 'biotinidase deficiency'/exp, foram localizados 134 novos artigos. Todos os resumos foram avaliados e apenas um artigo foi incluído a mais na presente revisão deste Protocolo.

---

