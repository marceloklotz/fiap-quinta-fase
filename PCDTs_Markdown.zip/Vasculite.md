<!-- METADADOS: doenca: Vasculite | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA  
SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 5, DE 1º DE JULHO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Vasculite  
Associada aos Anticorpos Anti-citoplasma de Neutrófilos.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhe confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024 ,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 892/2024  e o Relatório de Recomendação nº 895/2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos , critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizesterapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Vasculite | secao: FERNANDA DE NEGRI -->
**ANEXO**

---

<!-- METADADOS: doenca: Vasculite | secao: **1. INTRODUÇÃO** -->
As Vasculites Associadas aos Anticorpos Anti-citoplasma de Neutrófilos (ANCA) representam um grupo de doenças sistêmicas caracterizadas por inflamação vascular e necrose que afetam primariamente vasos de pequeno calibre, frequentemente sem deposição significativa de imunocomplexos nas paredes dos vasos<sup>1</sup> . Estes distúrbios vasculares têm origens multifacetadas, que compõem predisposição genética e exposição a fatores ambientais, envolvendo geralmente processo inflamatório imunomediado que envolve o interstício extravascular e pequenos vasos sanguíneos, conduzindo a disfunção de órgãos e sistemas servidos pelos vasos comprometidos<sup>2</sup> . A classificação desse grupo de doenças é baseada na especificidade dos anticorpos ANCA, diferenciando entre os tipos que reagem contra a proteinase 3 (PR3-ANCA) e contra a mieloperoxidase (MPO-ANCA), ou de acordo com características fenotípicas, que incluem a presença ou ausência de manifestações granulomatosas e vasculíticas.  
A Conferência de Consenso de Chapel Hill de 1994, atualizada em 2013, estabeleceu subtipos, que incluem granulomatose com poliangiite (GPA, conhecida anteriormente como doença de Wegener), poliangiite microscópica (MPA), granulomatose eosinofílica com poliangiite (GEPA, previamente síndrome de Churg-Strauss) e formas de vasculite ANCAassociada que se restringem a órgãos específicos, tal como a vasculite renal limitada<sup>1,3</sup> .  
Geralmente, as vasculites ANCA-associadas se manifestam entre os 50 e 70 anos de idade e observa-se que a MPA pode surgir em uma faixa etária um pouco mais elevada que a GPA. As informações de casos na América Latina refletem uma tendência de início similar à documentada em outros países. A vasculite ANCA-associada não apresenta uma prevalência notória por sexo, mantendo uma relação aproximada de um para um entre homens e mulheres. Entretanto, estudos latino-americanos indicam uma sutil preponderância feminina, principalmente entre pacientes com MPA<sup>4</sup> .  
Há carência na literatura de investigações epidemiológicas detalhadas sobre a vasculite ANCA-associada em países em desenvolvimento, especificamente no contexto brasileiro. Até o presente momento, não há estudos abrangentes que mapeiem a incidência e prevalência desta condição no Brasil. Na América Latina, estudos realizados no Peru e na Argentina forneceram dados sobre a incidência de vasculites sistêmicas primárias, incluindo a vasculite ANCA-associada. No Peru, a incidência de vasculite foi de 5,16 por milhão, com a maior incidência para a MPA. As mulheres e indivíduos acima de 50 anos apresentaram incidências mais altas. Na Argentina, as incidências e prevalências de MPA e GPA foram de 14 e 9 por milhão, e 5,2 e 7,4 por cem mil, respectivamente, com maiores taxas entre mulheres e pessoas na sétima década de vida. Estes dados foram coletados de prontuários médicos de centros de referência e hospitais<sup>4</sup> .  
Além disso, do ponto de vista epidemiológico, observa-se heterogeneidade geográfica considerável nas taxas de incidência internacional para as vasculites ANCA-associadas, com números variando de 13,07 a 18,3 por milhão na Espanha, 19,8 por milhão no Reino Unido, 13,7 por milhão na Austrália e até 20,9 por milhão na Suécia. As estimativas de prevalência, embora escassas, sugerem uma faixa entre 200 e 400 casos por milhão de habitantes. Esses dados, extraídos de prontuários médicos de instituições hospitalares de referência internacional, sublinham a urgência de investigações mais detalhadas. Tais estudos são cruciais para elucidar a carga da vasculite ANCA-associada e para estruturar políticas de saúde pública que respondam às necessidades específicas de cada região<sup>2,5</sup> ,  
Na conduta terapêutica primária dos pacientes com vasculite ANCA-associada, sobretudo nos estágios iniciais da GPA e da MPA, é imprescindível a determinação precisa da abrangência patológica, ou seja, da extensão de acometimentos de órgãos e sistemas pela vasculite.  
A classificação delineada EUVAS ( _European Vasculitis Study_ - Estudo Europeu sobre Vasculite) fornece um esquema  
estratégico de estratificação, que distingue a doença em cinco níveis de extensão de acometimento<sup>1</sup> .  
1. **doença localizada:** esta fase é marcada pela manifestação da doença restrita aos tratos respiratórios, sem indícios de  
comprometimento sistêmico ou sintomas gerais.  
2. **doença sistêmica não-crítica:** refere-se ao comprometimento de órgãos ou sistemas sem a iminência de dano  
irreversível ou risco de morte.  
3. **doença generalizada:** quando há um risco iminente para a função renal ou outros órgãos, evidenciado por níveis de  
creatinina sérica menores que 500 μmol/L ou 5,6 mg/dL.  
4. **doença grave:** definida pela insuficiência renal aguda ou disfunção de outros órgãos, com creatinina sérica superior  
a 500 μmol/L ou 5,6 mg/dL.  
5. **doença refratária:** casos em que há uma progressão da doença apesar da intervenção com glicocorticoides e  
ciclofosfamida.  
A abordagem terapêutica em indivíduos recém-diagnosticados com vasculite ANCA-associada deve ser meticulosamente delineada, considerando o potencial de lesão orgânica irreversível, o perigo de comprometimento vital ou a possibilidade de evolução acelerada para insuficiência renal ou hemorragia alveolar grave.  
Portanto, para o planejamento da terapia de vasculites ANCA-associadas, avalia-se se o paciente apresenta manifestações com risco à função de órgãos ou à vida, tanto ao diagnóstico quanto a cada recidiva de doença. A presença desses fatores de risco exige tratamento imediato e intensivo, devendo a escolha do regime terapêutico ser personalizada, baseada no perfil de risco individual, para otimizar o prognóstico e a função orgânica a longo prazo<sup>6</sup> e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da Vasculite Associada aos Anticorpos Anticitoplasma de Neutrófilos (ANCA).

---

<!-- METADADOS: doenca: Vasculite | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- M31.3– Granulomatose de Wegener  
- M31.7– Poliangeíte Microscópica

---

<!-- METADADOS: doenca: Vasculite | secao: **3.1. Diagnóstico clínico e laboratorial** -->
Em geral, em fases de atividade de doença ou em sua apresentação, a vasculite ANCA-associada pode causar sintomas constitucionais como febre ou suores noturnos, dores no corpo, dor nas articulações e nos músculos, diminuição do apetite e perda de peso. No entanto, os sintomas clínicos das vasculites ANCA-associadas variam conforme a localização e os órgãos afetados<sup>9</sup> .  
O comprometimento renal é frequente na vasculite ANCA-associada, variando de uma progressão gradual a rápida. Mesmo com os avanços no tratamento da glomerulonefrite relacionada à ANCA, a doença renal terminal (DRT) ainda afeta cerca de 30% dos pacientes em um período de cinco anos após o diagnóstico<sup>10</sup>  
As principais características observadas nos subtipos GPA e MPA estão descritas no **Quadro 1** . De forma geral, pacientes com GPA frequentemente apresentam acometimento de vias aéreas superiores, pulmonar e renal, associado ou não a alterações neurológicas, vasculite cutânea e envolvimento ocular.  
Na MPA, o rim é o órgão mais afetado pela doença e geralmente o acometimento renal ocorre associado ao acometimento pulmonar, vasculite cutânea e neuropatia periférica. O pulmão pode ser acometido sob a forma de capilarite pulmonar com hemorragia alveolar ou na forma de doença pulmonar intersticial, com padrão mais comum de pneumonia intersticial usual. A MPA é a principal causa de síndrome pulmão-rim<sup>11</sup> .  
**Quadro 1** . Manifestações clínicas dos subtipos GPA e MPA.  
|**Subtipo**|**Acometimento**|**Descrição do sintoma**|
|---|---|---|
||Nasal|Crostas nasais<br>Rinorreia (excesso de muco) e epistaxe (sangramento nasal)<br>Perfuração de septo nasal<br>Nariz em sela<br>Anosmia (perda total do sentido do olfato) ou hiposmia (diminuição da capacidade<br>olfativa)|
||Seios da face|Sinusopatia e erosões ósseas|
||Cavidade oral|Gengivas em morango<br>Úlceras orais|
||Ouvidos|Otite média serosa ou purulenta<br>Granuloma em ouvido médio e/ou mastóide<br>Perda auditiva sensorineural|
||Região subglótica|Estenose|
|**GPA**|Ocular|Massa retro-orbitária<br>Proptose<br>Diplopia<br>Isquemia de nervo óptico<br>Esclerite necrotizante<br>Episclerite, ceratite, uveíte e conjuntivite<br>Vasculite retiniana<br>Epífora (excesso de lágrimas nos olhos)|
||Pulmonar|1/3 dos pacientes assintomáticos<br>Nódulos Múltiplos e bilaterais<br>Formam cavitações<br>Infiltrados pulmonares<br>Hemorragia alveolar|
||Renal|GN necrotizante segmentar e focal extracapilar<br>Paucimune|
||Sistema locomotor|Artralgias, artrite, mialgias|
||Sistêmico|Febre, anorexia, perda de peso|
||Neurológico|Neuropatia periférica ou craniana<br>Paquimeningite hipertrófica|  
|**Subtipo**|**Acometimento**|**Descrição do sintoma**|
|---|---|---|
|||Massas em parênquima cerebral|
||Cutâneo|Púrpura palpável, nódulos, necrose digital, úlceras|
||Cardíaco|Miocardite, pericardite|
||Renais|Glomerulonefrite necrotizante segmentar e focal|
||Pulmonares|Hemorragia alveolar a fibrose pulmonar|
|**MPA**|Gastrointestinais|Vasculite intestinal: dor, sangramento, angina mesentérica, perfuração|
||Cutâneas|Púrpura palpável, nódulos, úlceras, livedo reticular|
||Neurológicas|Mononeurite múltipla e polineuropatia periférica|  
Fonte:  adaptado de Kitching e coloaboradores, 2020<sup>11</sup> .  
A atividade de doença em vasculites ANCA-associadas é avaliada pela terceira versão do instrumento _Birmingham Vasculitis Activity Score_ (BVAS v.3). O BVAS v.3 avalia as manifestações clínicas de nove órgãos ou sistemas, com pontuação que varia de 0 a 64. A remissão é definida como pontuação zero e a atividade de doença como pontuação ≥ 1. Ao aplicar o BVAS v.3, deve-se pontuar itens que estejam presentes nas últimas 4 semanas para atividade nova ou piora de item previamente presente e 3 meses para atividade persistente. Nesse contexto, pacientes com GPA e MPA com doença em atividade necessitam receber terapia de indução de remissão para controlar as manifestações e conseguirem remissão clínica.  Nesse instrumento, só podemse pontuar os itens que sejam relacionados à vasculite ativa, excluindo-se dano permanente ou infecção ativa. O BVAS v.3 deve ser incluído na avaliação clínica de pacientes com vasculites ANCA-associadas em todas as consultas<sup>12</sup> .  
A vasculite de pequenos vasos é uma doença inflamatória que afeta principalmente os menores vasos sanguíneos, como capilares, arteríolas e vênulas. Caracteriza-se pela presença de inflamação nas paredes desses pequenos vasos, causando danos nos tecidos<sup>13</sup> . Em casos suspeitos de vasculite de pequenos vasos, a positividade da biópsia de órgão acometido é altamente indicativa do diagnóstico, sendo considerada o critério padrão-ouro. O exame histopatológico pode ser realizado tanto para estabelecer o diagnóstico inicial quanto para avaliar mais detalhadamente pacientes com suspeita de recorrência de vasculite 6,14,15. As biópsias, particularmente as renais, não apenas confirmam o diagnóstico clínico, mas também são importantes para diferenciar doença ativa e danos permanentes que podem mimetizar a atividade da vasculite, além de ajudarem na avaliação do prognóstico.  
A classificação de Berden e o escore de risco renal de biópsia para vasculites ANCA-associadas fornecem informações prognósticas valiosas em relação à progressão para doença renal em estágio terminal<sup>16,17</sup> . No entanto, os subtipos histopatológicos, embora importantes, são limitados em seu papel orientador nas decisões de tratamento. A reavaliação por meio de biópsias renais repetidas é essencial para distinguir entre atividade da doença que está recorrente ou refratária e danos ou diagnósticos alternativos<sup>6,15</sup> . No entanto, é reconhecido que, em certos casos de suspeita de vasculite ANCA-associada, pode não ser viável realizar a biópsia de órgão acometido, sendo importante ressaltar que o início do tratamento não deve ser adiado devido à espera de resultados histológicos<sup>15</sup> .  
A realização de uma biópsia pode não ser possível quando houver dificuldades no acesso ao tecido afetado, como massas retro-orbital na GPA, ou devido aos riscos associados ao procedimento, especialmente em pacientes que estejam sob terapia anticoagulante. Também deve ser considerada a baixa sensibilidade diagnóstica de certas biópsias, como as de via aérea superior e transbrônquica, que apresentam taxas positividade de apenas 30% e 12%, respectivamente<sup>15</sup> .  
Nos casos em que a vasculite ANCA-associada se manifesta com lesões pulmonares, deve-se buscar a confirmação histológica por meio de biópsias pulmonares, preferencialmente por toracoscopia ou abordagens abertas. Entretanto, quando a obtenção ou interpretação da biópsia apresenta desafios, biomarcadores podem, em situações específicas, substituir as bióspias no diagnóstico clínico de GPA ou MPA.  
A apresentação clínica típica de vasculite de pequenos vasos e sorologia positiva para proteinase 3 (PR3)-ANCA ou mieloperoxidase (MPO)-ANCA podem apoiar o diagnóstico, mesmo na ausência de exame histopatológico. No entanto, esses exames laboratoriais não estão disponíveis no Sistema Único de Saúde e não são preconizados por este Protocolo. Além disso, o acometimento específico de diferentes órgãos e sistemas deve ser confirmado por exames complementares. Por exemplo, a mononeurite múltipla deve ser confirmada por estudos eletrofisiológicos, dados laboratoriais (como hematúria dismórfica e cilindros de células vermelhas na urina) sugerindo glomerulonefrite ou achados em exames de imagem de tórax, sistema nervoso central ou vias aéreas superiores<sup>15</sup> .  
Os exames de imagem, como a ressonância magnética de tórax e a tomografia computadorizada de tórax, só avaliam a extensão da doença, não sendo capazes de confirmar ou afastar o diagnóstico.  
Assim, embora as vasculites apresentem poucos padrões histológicos de inflamação vascular, elas se caracterizam por uma ampla variedade de manifestações clínicas. O diagnóstico preciso de tipos específicos de vasculite requer a combinação de sinais clínicos com testes complementares específicos para confirmar a condição<sup>11</sup> .

---

<!-- METADADOS: doenca: Vasculite | secao: **3.2. Diagnóstico diferencial** -->
O diagnóstico diferencial de vasculites ANCA-associadas é amplo e depende dos órgãos e sistemas acometidos. Por exemplo, em pacientes que apresentam síndrome pulmão-rim, o diagnóstico diferencial pode incluir lúpus eritematoso sistêmico, doença do anticorpo antimembrana basal glomerular, síndrome antifosfolípide e até quadros infecciosos, como a leptospirose. Já o diagnóstico de diferencial de pacientes que apresentam acometimento de vias aéreas superiores inclui sinusite fúngica, leishmaniose tegumentar americana e até síndrome do granuloma letal da linha média. O acometimento orbitário, associado ou não à paquimeningite hipertrófica, requer diagnóstico diferencial com sarcoidose, doença relacionada à IgG4 e histiocitose. Na presença de nódulos pulmonares, o diagnóstico diferencial inclui metástases pulmonares, tuberculose ou infecção fúngica, principalmente se cavitados. A endocardite bacteriana subaguda também pode simular uma vasculite ANCA-associada, inclusive com resultado falso positivo do teste de ANCA<sup>18</sup> .  
Outras formas de vasculites sistêmicas, incluindo a poliarterite nodosa, a granulomatose eosinofílica com poliangiíte e a policondrite recidivante, também devem ser diferenciadas do diagnóstico de GPA e MPA. Do ponto de vista estritamente renal, é necessário diagnóstico diferencial entre GPA e MPA com outras causas de glomerulonefrite como a nefropatia por IgA, doença do anticorpo antimembrana basal glomerular, nefrite lúpica, a glomerulonefrite pós-estreptocócica<sup>19</sup> .  
Usuários de drogas ilícitas podem apresentar manifestações que se assemelham às das vasculites ANCA-associadas com lesões descritivas de linha média e até a púrpura retiforme, uma vez que esta última entidade é observada em indivíduos que utilizaram cocaína contaminada pelo levamisole. Nessas situações, pode-se encontrar resultados falso positivos de ANCA, antiPR3 e de anti-MPO<sup>20,21</sup> .

---

<!-- METADADOS: doenca: Vasculite | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos nesse PCDT todos os pacientes com diagnóstico clínico e histopatológico de vasculite ANCA-associada, notadamente GPA, MPA e vasculite renal limitada.  
Adicionalmente, **para o uso de rituximabe** , o paciente deverá possuir 18 anos ou mais de idade **e** apresentar um dos seguintes critérios:  
- diagnóstico recente de GPA ou MPA, em idade fértil **e** indicação para receber a terapia de indução de remissão; **OU**  
- diagnóstico de recidiva (refratariedade ao tratamento com ciclofosfamida) de GPA ou MPA, ativa e grave (doença em estágio avançado, em que o paciente manifeste sintomas intensos e com elevado potencial de causar danos substanciais aos órgãos).  
**Nota** : Pacientes com diagnóstico de granulomatose eosinofílica com poliangite (GEPA) não estão incluídos no Protocolo, uma vez que a fisiopatologia  
e o tratamento desta doença são distintos.

---

<!-- METADADOS: doenca: Vasculite | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento preconizado neste Protocolo deverão ser excluídos ao uso do respectivo medicamento.

---

<!-- METADADOS: doenca: Vasculite | secao: **6. TRATAMENTO** -->
O planejamento da abordagem terapêutica de pacientes com vasculites ANCA-associadas (i.e., GPA e MPA) depende da gravidade das manifestações clínicas apresentadas pelo paciente, ao diagnóstico ou em episódios de recidiva de doença. Pacientes com manifestações clínicas que trazem risco à vida ou à função de órgãos ou sistemas acometidos são candidatos à terapia mais agressiva e a um acompanhamento rigoroso, mais detalhado e frequente. Este acompanhamento visa a monitorar a atividade de doença e prevenir dano permanente<sup>15</sup> .  
Embora não sejam comuns, as apresentações iniciais da doença podem incluir acometimento ocular. Nesses cenários, observa-se inflamação orbitária, muitas vezes, originando-se no osso maxilar ou etmoide e se estendendo de maneira semelhante para os músculos extraoculares. Pode haver sintomas como dor, unilateral ou bilateral, proptose e diplopia. Nos casos mais graves, pode ocorrer compressão do componente da via óptica, resultando em perda de visão. Em termos de aspectos histopatológicos do envolvimento orbital, é importante mencionar a presença de granulomas focais, deposição coloidal, infiltrado inflamatório e necrose.  
O cuidado de pacientes com complicações oculares de vasculites ANCA-associada também deve seguir o preconizado no PCDT de Uveítes Não Infecciosas vigente.

---

<!-- METADADOS: doenca: Vasculite | secao: **6.1. Tratamento não medicamentoso** -->
O tratamento não medicamentoso desses pacientes abrange, essencialmente, os cuidados respiratórios (como acompanhamento fisioterapêutico para monitoramento e ajustes da ventilação mecânica e mobilização precoce em pacientes graves, especialmente os que evoluem para a necessidade de via aérea artificial como a intubação e a sedoanalgesia); musculares (reabilitação após o período de internação prolongada, nos pacientes que cursam com tetraparesia do doente crítico ou fraqueza muscular) e, uma abordagem multifatorial, destacando as orientações educacionais, nutricionais e psicológicas<sup>22</sup> .  
A plasmaferese, também conhecida como troca plasmática, é um procedimento médico utilizado como terapia adicional em pacientes com GPA e MPA recém-diagnosticados ou em recidiva com doença ativa e grave. Um ensaio clínico randomizado avaliando a plasmaferese como tratamento inicial _versus_ ausência de plasmaferese (com administração de ciclofosfamida ou rituximabe a todos os pacientes) demonstrou que em pacientes com vasculite ANCA-associada grave, o uso de plasmaferese não reduziu a incidência de morte ou doença renal em estágio terminal<sup>23</sup> . Uma revisão sistemática com meta-análise de sete estudos observou algum benefício da plasmaferese em pacientes com vasculite ANCA-associada com glomerulonefrite rapidamente progressiva e creatinina sérica acima de 5,8 mg/dL, uma vez que o tratamento ocasionou melhora na sobrevida renal quando associada ao uso de glicocorticoide e ciclofosfamida ou rituximabe<sup>24</sup> . Contudo, o uso de plasmaferese não é recomendado como terapia de indução de remissão em pacientes recém diagnosticados ou em recaída com GPA e MPA ativa e grave<sup>14,25</sup> .

---

<!-- METADADOS: doenca: Vasculite | secao: **6.2. Tratamento medicamentoso** -->
O medicamento rituximabe é preconizado para terapia de indução de remissão dos pacientes com diagnóstico recente em idade fértil e para casos de recidiva de vasculites associadas aos anticorpos anticitoplasma de neutrófilos, classificados como GPA ou MPA, ativa e grave. O impacto do tratamento com rituximabe na remissão completa e redução do uso de glicocorticoide nestes pacientes foi avaliado pela Conitec, conforme o Relatório de Recomendação nº 836<sup>26</sup> . Em uma análise de subgrupo para pacientes com recidiva da doença, o rituximabe intravenoso se mostrou mais eficaz, reduzindo em 67% a remissão completa e a redução de glicocorticoide (prednisona) em seis meses comparado a 42% dos pacientes tratados com a terapia padrão de ciclofosfamida oral seguida por azatioprina (P=0,01). Esse benefício do rituximabe também foi observado aos 12 meses, embora essa diferença não tenha sido alcançada após 18 meses. Em termos de segurança, não foram identificadas diferenças estatisticamente significativas entre o rituximabe intravenoso e a ciclofosfamida durante o período de acompanhamento de até 24 meses<sup>26</sup> .  
Ainda, um ensaio clínico randomizado (ECR)<sup>27,28</sup> mostrou que rituximabe é não inferior a ciclofosfamida intravenosa como terapia de indução da remissão de pacientes com GPA e MPA gravemente ativos, recém diagnosticados e recidivantes quando os desfechos remissão completa em 12 meses (definida como pontuação zero na _Birmingham Vasculitis Activity Score_ e sem uso de prednisona diário), sobrevida livre de recidiva e doença renal em estágio final foram avaliados.  
A ciclofosfamida via oral e intravenosa possuem eficácias comparáveis de acordo com três ECRs<sup>29–32</sup> e uma coorte<sup>33</sup> em relação aos desfechos remissão, recidiva, sobrevida, função renal, duração até a imunossupressão, doses cumulativas de ciclofosfamida e eventos adversos. Contudo, a via oral tende a resultar em doses cumulativas maiores e pode estar relacionada a um aumento na ocorrência de eventos adversos, incluindo infecções (como pneumonia causada por _Pneumocystis jirovecii_ ), problemas de fertilidade e risco aumentado de câncer, principalmente bexiga<sup>30</sup> . Em relação às doses, uma coorte retrospectiva avaliou o efeito de diferentes doses de ciclofosfamida (de 2,5 a 3 g) _versus_ maior que 3 g na fase de indução de remissão e observou que as doses mais baixas parecem apresentar benefícios para remissão e prevenção de recidivas com menos casos de leucopenia e episódios infecciosos durante o acompanhamento.<sup>34</sup> Ciclofosfamida é um medicamento classificado na gestação como categoria X (estudos em animais ou em humanos claramente demonstram risco para o bebê que suplantam quaisquer potenciais benefícios, sendo o medicamento contraindicado na gestação).  
O protocolo de tratamento para pacientes com vasculite ANCA-associada geralmente inclui o uso de glicocorticoides, como a prednisona e a metilprednisolona. No entanto, inexiste evidência robusta e de alta qualidade que determinem a via de administração mais eficaz e a dose inicial ótima para tratar pacientes com GPA ou MPA<sup>25</sup> . Duas coortes retrospectivas avaliaram o efeito da metilprednisolona na terapia de indução de remissão na dose média de 1,5g, em pacientes com vasculite ANCAassociada severa<sup>35</sup> e com comprometimento renal no regime terapêutico consistindo em administração pulsada de 5 a 10 mg/kg por três dias<sup>36</sup> . Os estudos avaliaram os seguintes desfechos: sobrevida, mortalidade, dependência de diálise, e eventos adversos (infecções, episódios leucopênicos, episódios de trombocitopenia e diagnóstico de diabete melito de início recente). Destaca-se que em um dos estudos<sup>36</sup> todos os pacientes receberam terapia de indução de remissão padrão, incluindo prednisona oral combinada com ciclofosfamida. As evidências relacionadas com a sobrevida demonstraram que não houve diferença com o uso de glicocorticoides. Em relação à dependência de diálise, em pacientes com vasculite ANCA-associada com comprometimento renal, as evidências da coorte incluída sugerem que o tratamento com glicocorticoide pode auxiliar na redução da dependência de diálise.  
Por outro lado, em um ECR avaliando prednisolona pulsada ou contínua associada à ciclofosfamida e uma coorte retrospectiva avaliando metilprednisolona por infusão intravenosa comparado ao grupo controle<sup>37,38</sup> demonstrou que o tratamento com glicocorticoide não apresentou diferença significativa na dependência da diálise. Em termos de segurança, duas coortes retrospectivas<sup>36,39</sup> demostraram que o uso de glicocorticoide pode aumentar o risco de eventos adversos, como diabetes e infecção durante a terapia de indução de remissão em pacientes com vasculite ANCA-associada, principalmente, no perfil de  
maior gravidade – com comprometimento renal. Por fim, diretrizes internacionais e sociedades médicas apoiam o uso de glicocorticoide, bem como seu uso em associação a um imunossupressor ou terapia biológica, nos pacientes com vasculite ANCA-associada<sup>1,25,40</sup> .  
Portanto, este Protocolo preconiza como terapia de indução de remissão dos pacientes com diagnóstico de vasculite ANCA-associada a glicocorticoides (prednisona por via oral ou metilprednisolona por via intravenosa), ciclofosfamida por via intravenosa e rituximabe por via intravenosa. Ressalta-se que este Protocolo não inclui o tratamento de manutenção.  
Pacientes com doenças reumáticas autoimunes apresentam um risco aumentado de contrair infecções parasitárias graves, devido à doença subjacente e aos regimes terapêuticos adotados. A administração de agentes imunossupressores, tais como rituximabe e ciclofosfamida, eleva a vulnerabilidade desses indivíduos a infecções oportunistas, incluindo parasitoses, como a estrongiloidíase, que podem se tornar severas e disseminar para órgãos além do trato gastrointestinal em casos de imunossupressão<sup>41</sup> . Portanto, é essencial avaliar e tratar helmintíases e protozooses com medicamentos antiparasitários antes de iniciar terapias imunossupressoras ou biológicas.

---

<!-- METADADOS: doenca: Vasculite | secao: **6.2.1. Medicamentos** -->
- Ciclofosfamida: pó para solução injetável de 200 mg ou 1.000 mg;  
- Metilprednisolona (succinato): pó para solução injetável de 500 mg;  
- Prednisona: comprimidos de 5 e 20 mg;  
- Rituximabe: solução injetável de 10 mg/mL.  
**Nota** : Os medicamentos ciclofosfamida e metilprednisolona estão contemplados em procedimentos de pulsoterapia, sendo seu fornecimento de responsabilidade do serviço, não sendo dispensados no âmbito da Assistência Farmacêutica.

---

<!-- METADADOS: doenca: Vasculite | secao: **6.2.2. Esquemas de administração** -->
<u>Ciclofosfamida: 15 mg/kg, via intravenosa, administrada três vezes no primeiro mês, com um intervalo de duas semanas</u> e, então, a cada três semanas por até três a seis meses ou até a remissão, ajustando-se a dose conforme a contagem de linfócitos (mantida em torno de 1.000 células/mm³). A duração da infusão de ciclofosfamida pode variar entre 60 e 120 minutos, dependendo da dose a ser administrada<sup>42</sup> . A ciclofosfamida pode induzir náuseas e vômitos de forma moderada a alta, conforme a dose a ser administrada. Assim, recomenda-se a administração de antiemético como medida preventiva contra esses eventos adversos. Seu uso é contraindicado em pacientes com deficiência grave da função da medula óssea, cistite, obstrução das vias urinárias e infecções graves.  
<u>Metilprednisolona: dose inicial de 1 g, por via intravenosa, em até três dias, conforme a manifestação da doença. Seu uso</u> é contraindicado em pacientes com infecções sistêmicas por fungos; glaucoma; diabete melito descompensada; doença renal; dislipidemias e hipertensão arterial sistêmica.  
<u>Prednisona: dose inicial de 1 mg/kg/dia, conforme a manifestação da doença. Seu uso é contraindicado em pacientes com</u> diabete melito descompensado; glaucoma; infecção sistêmica; úlcera péptica ativa, doença renal ou hipertensão arterial sistêmica descompensada. Poderá ser necessário monitoramento por um período de até um ano após o término de tratamento prolongado ou com doses altas de corticosteroides.  
<u>Rituximabe: para indução da remissão, a dose recomendada é de 375 mg/m</u><sup>2</sup> de superfície corpórea e deve ser administrada por infusão intravenosa, uma vez por semana durante quatro semanas. O medicamento deve ser administrado por acesso exclusivo, ou seja, a solução não deve ser misturada a outros medicamentos ou a outras soluções, em local com recursos disponíveis para ressuscitação e sob estrita supervisão de um médico experiente e não deve ser administrado por via subcutânea ou como injeção intravenosa ou em _bolus_ . Dada a especificidade do rituximabe como anticorpo monoclonal, a atenção minuciosa à segurança e ao monitoramento de eventos adversos por parte da equipe médica é imperativa durante seu uso. Para diminuir a  
ocorrência de eventos adversos associados à infusão, é aconselhável iniciar a administração do rituximabe a uma velocidade de 50 mg/hora. Na ausência de eventos adversos, deve-se aumentar a dose em 50 mg/hora a cada 30 minutos, até alcançar a velocidade máxima de 400 mg/hora<sup>43</sup> . Para prevenir eventos adversos à infusão de rituximabe, recomenda-se a administração profilática de um analgésico ou antipirético, um anti-histamínico e um glicocorticoide entre 30 a 60 minutos antes do procedimento. Em caso de eventos adversos, a infusão deve ser imediatamente interrompida e a equipe médica notificada prontamente para avaliação imediata dos sinais vitais do paciente, a verificação da oximetria de pulso e a execução de um exame físico detalhado. A intervenção subsequente será determinada com base na gravidade da reação, categorizada conforme os critérios do _National Cancer Institute Common Terminology Criteria for Adverse Events_ (NCI CTCAE)<sup>44</sup> .  
Em pacientes adultos com GPA ou MPA, a administração de metilprednisolona 1.000 mg IV por dia, por um a três dias, em combinação com rituximabe, é recomendada para tratar os sintomas da vasculite grave, seguida pela administração oral de prednisona 1 mg/kg/dia (não exceder 80 mg/dia e retirada o mais rapidamente possível por necessidade clínica) durante e após o tratamento com rituximabe. Opcionalmente, o rituximabe pode ser usado em duas infusões de 1.000 mg, no primeiro e no 15° dia. Pacientes com hipersensibilidade conhecida a rituximabe, a proteínas murinas, a hialuronidase ou a qualquer um dos seus excipientes. Seu uso é contraindicado em pacientes em estado gravemente imunocomprometido e, pacientes com hepatite C ou B.

---

<!-- METADADOS: doenca: Vasculite | secao: **6.2.3. Critérios de interrupção – tempo de tratamento** -->
<u>Rituximabe: para indução da remissão, o tempo de tratamento é de quatro semanas. Seu uso deve ser interrompido quando</u> eventos adversos graves surgirem, tais como: reações alérgicas graves, infecções oportunistas graves, citopenias, ou toxicidade hepática.  
<u>Ciclofosfamida: deve ser administrada por até 6 meses. O tratamento pode ser repetido conforme a evolução clínica (nova</u> evidência de atividade de doença que justifique os riscos inerentes ao retratamento) ou a necessidade de substituição por uma terapia de manutenção menos tóxica assim que a remissão ocorrer devido à sua dose cumulativa.  
<u>Prednisona ou Metilprednisolona: não existe um período estabelecido para a duração do tratamento com este</u> medicamento. Após a remissão clínica, a dose deve ser reduzida gradualmente, até a retirada total. Importante monitorar os seguintes sinais para verificar necessidade de suspensão do tratamento: aumento da pressão arterial e dos níveis de glicose no sangue, perda de eletrólitos; aumento de peso e elevação da pressão intraocular; diminuição da densidade mineral óssea, retardo do crescimento e desenvolvimento em crianças e, supressão do eixo hipotálamo-hipófise-adrenal.

---

<!-- METADADOS: doenca: Vasculite | secao: **6.2.4. Benefícios esperados** -->
- Promover a remissão completa da doença;  
- Reduzir as taxas de recidiva;  
- Reduzir a dose de glicocorticoide (quando a terapia com rituximabe é indicada);  
- Melhorar sintomas e qualidade de vida.

---

<!-- METADADOS: doenca: Vasculite | secao: **6.3. Fluxo de Tratamento** -->
Na Figura 1 é apresentado o fluxograma do tratamento da remissão dos pacientes com vasculite ANCA-associada do tipo GPA e MPA.  
**Figura 1** . Fluxograma de tratamento de pacientes com vasculite ANCA-associada (GPA e MPA).  
<!-- Start of picture text -->
Pacientes com GPA ou MPA em atividade e com<br>manifestacées de risco a vida ou risco a func de 6rgdos<br>Nao _/idadePacientefertile emcom sim<br>diagnéstico<br>recente?<br>Paciente com sim Terapia de indug&o com:<br>contraindicacao a.> prednisona e rituximabe com.<br>ciclofosfamida? ‘ou sem metilprednisolona<br>| Nao<br>Terapia dee inducdo com: Pr sim<br>Prednisona ciclofosfamida __»recigv a ciente(refratério em  a<br>Ha, ciclofosfamida)?<br>Nao<br>Monitorar 0 paciente<br><!-- End of picture text -->  
Fonte: Elaboração dos especialistas.

---

<!-- METADADOS: doenca: Vasculite | secao: **7. MONITORAMENTO** -->
Em fases de atividade de doença, pacientes devem ser avaliados mensalmente com consultas clínicas e exames laboratoriais. As avaliações médicas podem ser realizadas a cada 2 a 3 meses em fases iniciais de remissão de doença, e entre 3 e 6 meses, naqueles que se mantêm em remissão há mais de dois anos<sup>45</sup> .  
Exames laboratoriais são realizados a cada consulta para avaliar atividade de doença e toxidade ao medicamento. Tais exames devem incluir hemograma, creatinina, transaminase glutâmico-oxalacética (TGO), transaminase glutâmico-pirúvica (TGP), gama-glutamil transferase (gamaGT), urina I e proteinúria de 24 horas ou relação proteína/creatinina em amostra isolada de urina. Para a pontuação do BVAS v.3, deve-se ter os resultados do exame de urina I e dosagem sérica de creatinina.  
Em pacientes que utilizam rituximabe, a dosagem sérica de IgG deve ser agregada à avaliação laboratorial para se identificar hipogamaglobulinemia secundária. Em pacientes com GPA, exames de imagem, como tomografia computadorizada de tórax e de seios paranasais, devem ser realizados ao diagnóstico e podem ser repetidos a cada ano em assintomáticos ou quando há suspeita de recidiva de doença<sup>45</sup> . Na MPA, a tomografia computadorizada de tórax é útil na avaliação de doença pulmonar intersticial e de hemorragia alveolar.  
A pesquisa de ANCA por imunofluorescência indireta ou por ensaio de fase sólida para anticorpos anti-PR3 ou anti-MPO podem ser úteis para estimar o risco de recidiva de doença quando o ANCA persiste positivo ao final da terapia de indução de remissão ou quando volta a ser positivo ou quando seu título dobra em relação ao anterior<sup>46</sup> . Contudo, estes exames não estão disponíveis no Sistema Único de Saúde.  
A atividade de doença e seu tratamento podem levar ao desenvolvimento de dano irreversível. Tal acúmulo de dano em pacientes com GPA ou MPA é avaliado pelo instrumento _Vasculitis Damage Index_ (VDI). A pontuação do VDI é cumulativa e soma um ponto a cada novo item que apresentar duração igual ou superior a três meses<sup>47</sup> .  
As seguintes precauções devem ser consideradas ao monitorar o paciente em uso de rituximabe<sup>1</sup> :  
 Antes de administrar o rituximabe, é necessário realizar testes de sorologia para HIV, HBV, HBC e sífilis. Para pacientes com infecções crônicas por HBV e HIV, o tratamento com rituximabe só deve ser considerado com a prescrição simultânea de terapia antiviral e a consulta a um especialista em doenças infecciosas. Quando possível, a vacinação deve ser realizada antes da  
infusão de rituximabe, com ênfase na vacinação anual contra influenza, pneumococos e HBV. A administração de outras vacinas, como a antitetânica, difteria ou antimeningocócica, é uma alternativa, mas é fundamental manter os registros de imunização atualizados. Atualmente, também é considerada importante a vacinação para SARS COV2.  
 Recomenda-se a avaliação dos níveis iniciais de imunoglobulinas séricas e a contagem das células B no sangue periférico antes e imediatamente após a administração de rituximabe. A dosagem das imunoglobulinas séricas, especialmente da IgG, deve ser realizada antes da infusão do medicamento e novamente após 4 a 6 meses de cada dose de rituximabe. Em casos de hipogamaglobulinemia grave (IgG inferior a 500 mg/L) e complicações infecciosas, é necessário considerar estratégias para manter níveis séricos adequados de IgG. Ademais, durante o tratamento com rituximabe, a avaliação contínua dos níveis sérios de IgG é crucial, especialmente se o paciente persistir com níveis séricos de IgG inferiores a 500 mg/dL e enfrentar recorrência de infecções graves. Entretanto, é importante ponderar a relação entre os benefícios do tratamento no controle da atividade inflamatória e o potencial risco de eventos adversos graves associados à terapia com rituximabe.  
O rituximabe pode interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) previamente ao início do tratamento.  
Alguns medicamentos recomendados para o tratamento da vasculite associada aos Anticorpos Anti-citoplasma de neutrófilos podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
Antes do início do uso de rituximabe e com objetivo de realizar o planejamento terapêutico adequado, deve-se considerar  
as seguintes condutas:  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
-  Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A radiografia simples de tórax deve ser realizada para excluir a possibilidade de TB ativa, independente de sinais e sintomas.  
-    Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD) ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
-   Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
-   Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de rituximabe após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, à critério da equipe de saúde assistente, o início de uso de rituximabe pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
Durante o acompanhamento da pessoa em uso de rituximabe, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
-   Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
-    Para que o uso do rituximabe não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com rituximabe devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com rituximabe devem manter o monitoramento com o IGRA.  
-    Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
-   Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
-   Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.

---

<!-- METADADOS: doenca: Vasculite | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Doentes de vasculite ANCA-associada devem ser atendidos em serviços especializados e médicos com experiência em cuidar pacientes com a doença para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com vasculite ANCA-associada devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A prescrição de biológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva condição clínica, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras<sup>48</sup> .  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária  e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A  
Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da Atenção Primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o _locus_ da atenção à saúde dos pacientes com doenças raras  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no  
- mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS, e se houver necessidade o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade, e a linha de cuidados de pacientes com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, assim como a duração e o monitoramento dos tratamentos clínico e de reabilitação necessários.  
Pacientes com suspeita de vasculite ANCA-associada devem ser encaminhados, preferencialmente, a um serviço especializado ou de referência em doenças raras para seu adequado diagnóstico.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com vasculite ANCA-associada deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).

---

<!-- METADADOS: doenca: Vasculite | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Vasculite | secao: **10. REFERÊNCIAS** -->
1. Souza AWS de, Calich AL, Mariz H de A, Ochtrop MLG, Bacchiega ABS, Ferreira GA, et al. Recomendações da Sociedade Brasileira de Reumatologia para a terapia de indução para vasculite associada a ANCA. Rev Bras Reumatol. 2017;57:s484–96.  
2. Mohammad AJ. An update on the epidemiology of ANCA-associated vasculitis. Rheumatology. 2020;59(Supplement_3):iii42–50.  
3. Jennette JC, Falk RJ, Bacon PA, Basu N, Cid MC, Ferrario F, et al. 2012 revised International Chapel Hill Consensus Conference Nomenclature of Vasculitides. Arthritis Rheum. 2013;  
4. Pimentel-Quiroz VR, Sattui SE, Ugarte-Gil MF, Alarcón GS. ANCA-associated vasculitis in Latin America: a systematic literature review: about their epidemiology and their clinical features. JCR: Journal of Clinical Rheumatology. 2022;28(1):44–51.  
5. Almaani S, Fussner LA, Brodsky S, Meara AS, Jayne D. ANCA-associated vasculitis: an update. J Clin Med. 2021;10(7):1446.  
6. Yates M, Watts RA, Bajema IM, Cid MC, Crestani B, Hauser T, et al. EULAR/ERA-EDTA recommendations for the management of ANCA-associated vasculitis. Ann Rheum Dis. 2016;75(9):1583–94.  
7. Brasil. Ministério da Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas. 2023;  
8. Group GW. Grading quality of evidence and strength of recommendations. Bmj. 2004;328(7454):1490.  
9. Hunter RW, Welsh N, Farrah TE, Gallacher PJ, Dhaun N. ANCA associated vasculitis. Bmj. 2020;369.  
10. Boud’hors C, Copin MC, Wacrenier S, Piccoli GB, Croue A, Augusto JF, et al. Histopathological prognostic factors in ANCA-associated glomerulonephritis. Autoimmun Rev. 2022;103139.  
11. Kitching AR, Anders HJ, Basu N, Brouwer E, Gordon J, Jayne DR, et al. ANCA-associated vasculitis. Nat Rev Dis Primers. 2020;6(1):71.  
12. Score VA. Modification and validation of the Birmingham. Ann Rheum Dis. 2009;68:1827–32.  
13. Jennette JC, Falk RJ. Small-vessel vasculitis. New England Journal of Medicine. 1997;337(21):1512–23.  
14. Chung SA, Langford CA, Maz M, Abril A, Gorelik M, Guyatt G, et al. 2021 American College of Rheumatology/Vasculitis Foundation guideline for the management of antineutrophil cytoplasmic antibody–associated vasculitis. Arthritis & Rheumatology. 2021;73(8):1366–83.  
15. Hellmich B, Sanchez-Alamo B, Schirmer JH, Berti A, Blockmans D, Cid MC, et al. EULAR recommendations for the management of ANCA-associated vasculitis: 2022 update. Ann Rheum Dis. 2023;  
16. Berden AE, Ferrario F, Hagen EC, Jayne DR, Jennette JC, Joh K, et al. Histopathologic classification of ANCAassociated glomerulonephritis. Journal of the American Society of Nephrology. 2010;21(10):1628–36.  
17. Brix SR, Noriega M, Tennstedt P, Vettorazzi E, Busch M, Nitschke M, et al. Development and validation of a renal risk score in ANCA-associated glomerulonephritis. Kidney Int. 2018;94(6):1177–88.  
18. Bateman H, Rehman A, Valeriano-Marcet J. Vasculitis-like syndromes. Curr Rheumatol Rep. 2009;11(6):422–9.  
19. Zarka F, Veillette C, Makhzoum JP. A review of primary vasculitis mimickers based on the Chapel Hill Consensus classification. Int J Rheumatol. 2020;2020.  
20. Trimarchi M, Bussi M, Sinico RA, Meroni P, Specks U. Cocaine-induced midline destructive lesions—An autoimmune disease? Autoimmun Rev. 2013;12(4):496–500.  
21. Graf J, Lynch K, Yeh C, Tarter L, Richman N, Nguyen T, et al. Purpura, cutaneous necrosis, and antineutrophil cytoplasmic antibodies associated with levamisole‐adulterated cocaine. Arthritis Rheum. 2011;63(12):3998–4001.  
22. Terrier B, Darbon R, Durel CA, Hachulla E, Karras A, Maillard H, et al. French recommendations for the management of systemic necrotizing vasculitides (polyarteritis nodosa and ANCA-associated vasculitides). Orphanet J Rare Dis. 2020;15:1–44.  
23. Walsh M, Merkel PA, Peh CA, Szpirt WM, Puéchal X, Fujimoto S, et al. Plasma exchange and glucocorticoids in severe ANCA-associated vasculitis. New England Journal of Medicine. 2020;382(7):622–31.  
24. Walsh M, Collister D, Zeng L, Merkel PA, Pusey CD, Guyatt G, et al. The effects of plasma exchange in patients with ANCA-associated vasculitis: an updated systematic review and meta-analysis. bmj. 2022;376.  
25. Magri SJ, Ugarte-Gil MF, Brance ML, Flores-Suárez LF, Fernández-Ávila DG, Scolnik M, et al. Pan American League of Associations for Rheumatology Guidelines for the treatment of ANCA-associated vasculitis. Lancet Rheumatol. 2023;  
26. Conitec. Rituximabe  para terapia de indução de remissão dos pacientes com  diagnóstico recente e para casos de recidiva de  vasculites associadas aos anticorpos anticitoplasma de  neutrófilos, ativa e grave. Relatório de Recomendação N°836. 2023;  
27. Jones RB, Cohen Tervaert JW, Hauser T, Luqmani R, Morgan MD, Peh CA, et al. Rituximab versus cyclophosphamide in ANCA-associated renal vasculitis. New England Journal of Medicine. 2010;363(3):211–20.  
28. Jones RB, Furuta S, Tervaert JWC, Hauser T, Luqmani R, Morgan MD, et al. Rituximab versus cyclophosphamide in ANCA-associated renal vasculitis: 2-year results of a randomised trial. Ann Rheum Dis. 2015;74(6):1178–82.  
29. Haubitz M, Schellong S, Göbel U, Schurek HJ, Schaumann D, Koch KM, et al. Intravenous pulse administration of cyclophosphamide versus daily oral treatment in patients with antineutrophil cytoplasmic antibody‐associated vasculitis and renal involvement: a prospective, randomized study. Arthritis & Rheumatism: Official Journal of the American College of Rheumatology. 1998;41(10):1835–44.  
30. De Groot K, Harper L, Jayne DRW, Flores Suarez LF, Gregorini G, Gross WL, et al. Pulse versus daily oral cyclophosphamide for induction of remission in antineutrophil cytoplasmic antibody—associated vasculitis: a randomized trial. Ann Intern Med. 2009;150(10):670–80.  
31. Harper L, Morgan MD, Walsh M, Hoglund P, Westman K, Flossmann O, et al. Pulse versus daily oral cyclophosphamide for induction of remission in ANCA-associated vasculitis: long-term follow-up. Ann Rheum Dis. 2012;71(6):955–60.  
32. Rihova Z, Jancova E, Merta M, Zabka J, Rysava R, Bartunkova J, et al. Daily oral versus pulse intravenous cyclophosphamide in the therapy of ANCA-associated vasculitis–preliminary single center experience. Prague Med Rep. 2004;105(1):64–8.  
33. La-Crette J, Royle J, Lanyon PC, Ferraro A, Butler A, Pearce FA. Long-term outcomes of daily oral vs. pulsed intravenous cyclophosphamide in a non-trial setting in ANCA-associated vasculitis. Clin Rheumatol. 2018;37:1085–90.  
34. Speer C, Altenmüller-Walther C, Splitthoff J, Nusshag C, Kälble F, Reichel P, et al. Cyclophosphamide induction dose and outcomes in ANCA-associated vasculitis with renal involvement: a comparative cohort study. Medicine. 2021;100(29).  
35. Chanouzas D, McGregor JAG, Nightingale P, Salama AD, Szpirt WM, Basu N, et al. Intravenous pulse methylprednisolone for induction of remission in severe ANCA associated vasculitis: a multi-center retrospective cohort study. BMC Nephrol. 2019;20:1–8.  
36. Huang L, Zhong Y, Ooi JD, Zhou YO, Zuo X, Luo H, et al. The effect of pulse methylprednisolone induction therapy in Chinese patients with dialysis-dependent MPO-ANCA associated vasculitis. Int Immunopharmacol. 2019;76:105883.  
37. Adu D, Pall A, Luqmani RA, Richards NT, Howie AJ, Emery P, et al. Controlled trial of pulse versus continuous prednisolone and cyclophosphamide in the treatment of systemic vasculitis. QJM. 1997;90(6):401–9.  
38. Ma Y, Han F, Chen L, Wang H, Han H, Yu B, et al. The impact of intravenous methylprednisolone pulses on renal survival in anti-neutrophil cytoplasmic antibody associated vasculitis with severe renal injury patients: a retrospective study. BMC Nephrol. 2017;18(1):1–8.  
39. Floyd L, Morris AD, Shetty A, Brady ME, Ponnusamy A, Warwicker P, et al. Low-Dose Intravnous Methylprednisolone in Remission Induction Therapy for ANCA-Associated Vasculitis. Kidney360. 2023;4(9):e1286–92.  
40. Chanouzas D, McGregor JAG, Nightingale P, Salama AD, Szpirt WM, Basu N, et al. Intravenous pulse methylprednisolone for induction of remission in severe ANCA associated vasculitis: a multi-center retrospective cohort study. BMC Nephrol. 2019;20:1–8.  
41. Braz AS, Andrade CAF de, Mota LMH da, Lima CMBL. Recomendações da Sociedade Brasileira de Reumatologia sobre diagnóstico e tratamento das parasitoses intestinais em pacientes com doenças reumáticas autoimunes. Rev Bras Reumatol. 2015;55:368–80.  
42. Teles KA, Medeiros-Souza P, Lima FAC, Araújo BG de, Lima RAC. Rotina de administração de ciclofosfamida em doenças autoimunes reumáticas: uma revisão ☆ . Rev Bras Reumatol. 2017;57:596–604.  
43. Rodrigues CA, de Lima MTC, De Domenico EBL. Boas Práticas na Administração do Rituximab: Revisão Integrativa da Literatura. Revista Brasileira de Cancerologia. 2022;68(3).  
44. Department of Health and Human Services (US) NI of HNCI. Common Terminology Criteria for Advers Events (CTCAE). Version 4.0 [Internet]. Disponível em:https://www.eortc.be/services/doc/ctc/CTCAE_4.03_2010-0614_QuickReference_5x7.pdf. 2009.  
45. Villa-Forte A, Clark TM, Gomes M, Carey J, Mascha E, Karafa MT, et al. Substitution of methotrexate for cyclophosphamide in Wegener granulomatosis: a 12-year single-practice experience. Medicine. 2007;86(5):269–77.  
46. Bossuyt X, Cohen Tervaert JW, Arimura Y, Blockmans D, Flores-Suárez LF, Guillevin L, et al. Revised 2017 international consensus on testing of ANCAs in granulomatosis with polyangiitis and microscopic polyangiitis. Nat Rev Rheumatol. 2017;13(11):683–92.  
47. Exley AR, Bacon PA, Luqmani RA, Kitas GD, Gordon C, Savage COS, et al. Development and initial validation of the Vasculitis Damage Index for the standardized clinical assessment of damage in the systemic vasculitides. Arthritis & Rheumatism: Official Journal of the American College of Rheumatology. 1997;40(2):371–80.  
48. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 2, de 28 de setembro de 2017, e Portaria de Consolidação GM/MS n<sup>o</sup> 6, de 28 de setembro de 2017. 2017;  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE

---

<!-- METADADOS: doenca: Vasculite | secao: RITUXIMABE, CICLOFOSFAMIDA, PREDNISONA E METILPREDNISOLONA. -->
Eu, ______________________________________________________________________________________ (nome  
do(a) paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de rituximabe, ciclofosfamida, prednisona e metilprednisolona, indicada para o tratamento de vasculite ANCA-associada  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ______________________  
______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Promover a remissão completa  
- Reduzir as taxas de recidiva  
- Reduzir a dose de glicocorticoide (no caso de indicação para o tratamento com rituximabe)  
- Melhorar a qualidade de vida  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
• rituximabe e prednisona: medicamentos classificados na gestação como categoria C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior que os riscos)  
• ciclofosfamida: medicamento classificado na gestação como categoria X (estudos em animais ou em humanos claramente demonstram risco para o bebê que suplantam quaisquer potenciais benefícios, sendo o medicamento contraindicado na gestação)  
Os eventos adversos mais comuns dos medicamentos são:  
- rituximabe: febre, calafrios, tremores, dor articular, diarreia e insônia. Além disso, foram relatadas reações anafiláticas  
- e outras reações de hipersensibilidade após a administração IV de proteínas a pacientes. Reações adicionais relatadas em alguns casos foram de infarto do miocárdio, fibrilação atrial, edema pulmonar e trombocitopenia aguda reversível, além de reações cutâneas.  
•  ciclofosfamida: diminuição do número de células brancas no sangue, fraqueza, náusea, vômitos, infecções da bexiga acompanhada ou não de sangramento, problemas nos rins, no coração, pulmão, queda de cabelos, aumento do risco de desenvolver cânceres;  
• prednisona e metilprednisolona: aumento da pressão arterial, inchaços, ansiedade, insônia, tremores, palpitação, aumento dos pelos e peso, mal-estar. Osteoporose e fraqueza, aumento da pressão intraocular (glaucoma), catarata, hematomas e osteonecrose.  
Consultas e exames durante o tratamento são necessários.  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
(   ) ciclofosfamida       (   ) prednisona  (   ) metilprednisolona (   ) rituximabe  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Nota 2: A administração endovenosa de metilprednisolona e de ciclofosfamida é compatível, respectivamente, com os procedimentos 03.03.02.001-6 - Pulsoterapia I (por aplicação) e 03.03.02.002-4 - Pulsoterapia II (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS  
Nota 3: O seguinte medicamento integra procedimento hospitalar da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS: 06.03.01.001-6 Metilprednisolona 500 mg injetável (por ampola).  
Nota 4: O seguinte medicamento integra procedimento hospitalar da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS: 06.03.02.005-4 Ciclosporina 50 mg injetável (por frasco-ampola).

---

<!-- METADADOS: doenca: Vasculite | secao: **Alteração pós publicação** -->
Depois da publicação, em 14/07/2025, da Portaria Conjunta SAES-SECTICS/MS nº 5/2025, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos, pela necessidade de ajustar a Figura 1 e esclarecer que recidiva é considerada a refratariedade ao tratamento com ciclofosfamida. No tópico do tratamento medicamentoso foi adicionada a frase “Ciclofosfamida é um medicamento classificado na gestação como categoria X (estudos em animais ou em humanos claramente demonstram risco para o bebê que suplantam quaisquer potenciais benefícios, sendo o medicamento contraindicado na gestação)”. O tema foi apresentado como informe à 129ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 09/09/2025.

---

<!-- METADADOS: doenca: Vasculite | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo desenvolvedor da elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos (ANCA) contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
Este documento tem o objetivo de fomentar a transparência no processo de busca que embasou o texto normativo contido no PCDT, aumentar a sua transparência e fornece considerações adicionais para profissionais da saúde, gestores e demais interessados. O público-alvo deste PCDT é composto por profissionais da saúde envolvidos no atendimento de pacientes com vasculite ANCA-associada, como reumatologistas, nefrologistas, oftalmologistas e pneumologistas.  
O escopo do PCDT foi estabelecido em reunião que ocorreu em 29 de agosto de 2023 com representantes do Ministério da Saúde, representantes de pacientes, especialistas e com o grupo elaborador. O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos reumatologistas e nefrologistas. Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A elaboração deste Protocolo foi conduzida em caráter emergencial devido à publicação da Portaria SECTICS/MS nº 44/2023, que tornou pública a decisão de incorporar o rituximabe para o tratamento de indução de remissão dos pacientes com diagnóstico recente em idade fértil e para os casos de recidiva de vasculites ANCA-associada classificados como GPA ou MPA, ativa e grave no SUS. Desta forma, não foi possível considerar a incorporação de outras tecnologias no escopo de elaboração do Protocolo.  
Este Protocolo considera as melhores evidências advindas de diretrizes clínicas publicadas por outros órgãos ou entidades nacionais e internacionais para o diagnóstico, tratamento e monitorização desses pacientes.  
**2. Equipe de elaboração e partes interessadas**  
Além dos representantes do Ministério da Saúde do Departamento de Gestão, Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITS/MS), participaram no desenvolvimento deste protocolo, metodologistas do Nats Cochrane do Brasil, colaboradores e especialistas no tema e representante dos pacientes. Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro A).  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos ben|efícios abaixo?|
|---|---|
|Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou|(   ) Sim|
|prejudicada com as recomendações da diretriz?|(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetados<br>atividade na elaboração ou revisão da diretriz?|pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim|  
||(   ) Não|
|---|---|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e que|(   ) Sim|
|deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar sua|(   ) Sim|
|objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Vasculite | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos (ANCA) foi apresentada na 111ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em janeiro de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Saúde Indígena (SESAI). Foram solicitados ajustes na redação dos critérios de inclusão e do tempo de tratamento de rituximabe. O PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Vasculite | secao: **4. Consulta Pública** -->
A Consulta Pública nº 05/2024, para elaboração do Protocolo Clínico e Diretrizes Terapêuticas de Vasculite Associada aos Anticorpos Anti-citoplasma de Neutrófilos, foi realizada entre os dias 20/02/2024 a 11/03/2024. Foram recebidas 95 contribuições, que podem ser verificadas na página da Conitec em <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2024/cp-05-2024-contribuicoes-da-consulta-publica-pcdt-de-vasculite-associada-aosanticorpos-anti-citoplasma-de-neutrofilo.</u>

---

<!-- METADADOS: doenca: Vasculite | secao: **5. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (Quadro B)<sup>1</sup> .  
**Quadro B** . Níveis de evidências de acordo com o sistema GRADE  
|Nível|Definição|Implicações|
|---|---|---|
|Alto|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|  
|Moderado|Há<br>confiança<br>moderada<br>no<br>efeito<br>estimado.|Trabalhos<br>estimativa<br>estimativa.|futuros poderão modificar a confiança na<br>de efeito, podendo, inclusive, modificar a<br>|
|---|---|---|---|
|Baixo|A confiança no efeito é limitada.|Trabalhos<br>importante|futuros provavelmente terão um impacto<br>em nossa confiança na estimativa de efeito.|
||A confiança na estimativa de efeito é|||
|Muito baixo|muito limitada.<br>Há importante grau de incerteza nos<br>achados.|Qualquer e|stimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em  
saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para auxiliar a elaboração do conteúdo deste PCDT, foram elaboradas perguntas de pesquisa, conforme acrônimo PICO (P- Pacientes, I - intervenção, C – comparador, O – _outcome_ /desfecho) descritas no Quadro C.  
**Quadro C** . Acrônimo PICO utilizado na elaboração do conteúdo do PCDT  
|**PICO**|**Pergunta**|
|---|---|
|**Pacientes:**Pacientes com diagnóstico de vasculite ANCA-associada (GPA|Deve-se usar rituximabe para o tratamento de|
|e MPA) ativa e grave e pacientes que apresentaram recidiva da doença.|indução de remissão dos pacientes com|
|**Intervenção:**rituximabe|vasculite ANCA-associada (GPA e MPA)|
|**Comparador:**ciclofosfamida|ativa e grave e pacientes que apresentam|
|**_Outcome_/Desfecho:**Remissão completa, redução de glicocorticoide em 6<br>meses, remissão sustentada em 12 e 18 meses, recidiva em 6 meses, recidiva<br>em 12 meses, recidiva em 18 meses, mortalidade, eventos adversos e eventos|recidiva da doença?|
|adversos graves||
|**População:**Pacientes com diagnóstico de vasculite ANCA-associada (GPA<br>e MPA)|Deve-se usar ciclofosfamida intravenosa para<br>o tratamento de indução de remissão de|
|**Intervenção:**ciclofosfamida por infusão intravenosa|pacientes com vasculite ANCA associada|
|**Comparador:**glicocorticoides, rituximabe ou placebo|(GPA e MPA)?|
|**Desfechos:**remissão completa por questionários validados, taxa de recidiva,<br>eventos adversos gerais e graves, qualidade de vida, redução da dose de<br>glicocorticoides||
|**População:**Pacientes com diagnostico de vasculite ANCA-associada (GPA<br>e MPA)|Deve-se usar glicocorticoide intravenoso para<br>o tratamento de indução de remissão de|
|**Intervenção:**glicocorticoide intravenoso|pacientes com vasculite ANCA associada|
|**Comparador:**ciclofosfamida por infusão intravenosa, rituximabe ou<br>placebo|(GPA e MPA)?|
|**Desfechos:**remissão completa por questionários validados, taxa de recidiva,<br>eventos adversos gerais e graves, qualidade de vida, redução da dose de||
|glicocorticoides||  
Para auxiliar no embasamento teórico de diagnóstico e tratamento medicamentoso, foi realizada uma busca por diretrizes existentes que pudessem ser adaptadas para o contexto dos recursos disponíveis no SUS. Após o rastreio das diretrizes, estas foram avaliadas por meio da ferramenta AGREE II. Na ausência de diretrizes que incluíssem a avaliação de tecnologias em avaliação neste PCDT e que pudessem ser adotadas ou adaptadas para responder às questões clínicas, foram realizadas buscas por ensaios clínicos randomizados para elaboração da revisão sistemática realizada pelo Grupo Elaborador para responder à questão clínica.  
Por fim, foi elaborada uma tabela de evidências na plataforma GRADEpro (GRADEpro GDT), sendo considerados a avaliação do risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferente do da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos) e efeito relativo e absoluto de cada questão.  
Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou condicional, de acordo com o sistema GRADE (Quadro D).  
**Quadro D** . Implicações da força da recomendação para profissionais, pacientes e gestores em saúde.  
|**Público-alvo**|**Forte**|**Condicional**|
|---|---|---|
|Gestores|A recomendação deve ser adotada como<br>política de saúde na maioria das situações|É necessário debate substancial e envolvimento das<br>partes interessadas.|
|Pacientes|A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um<br>pequeno<br>número<br>não<br>aceitaria<br>essa<br>recomendação|Grande parte dos indivíduos desejaria que a<br>intervenção fosse indicada; contudo considerável<br>número não aceitaria essa recomendação.|
|||O profissional deve reconhecer que diferentes|
|Profissionais<br>da<br>saúde|A maioria dos pacientes deve receber a<br>intervenção recomendada.|escolhas serão apropriadas para cada paciente para<br>definir uma decisão consistente com os seus valores e<br>preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para subsidiar as recomendações sobre o tratamento e diagnóstico, foram realizadas buscas sistemáticas por diretrizes publicadas por outros órgãos ou entidades nacionais e internacionais, utilizando estratégias de busca de alta sensibilidade nas bases de dados MEDLINE via Pubmed e Tripdatabase. As buscas foram realizadas no dia 4 de dezembro de 2023 (Quadro E). Não houve limitação de data ou idioma.  
**Quadro E** . Estratégias de buscas para diretrizes clínicas.  
|**Bases de dados**|**Estratégia de b**|**usca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|---|
|MEDLINE via Pubmed|#1<br>"Anti-Neutrophil<br>Cytoplasmic|Antibody-Associated|330|
||Vasculitis"[Mesh] OR Anti Neutrophil|Cytoplasmic Antibody||
||Associated Vasculitis OR Pauci-Immune<br>Associated Vasculiti*|Vasculiti* OR ANCA||  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#2 (guidelines as topic[MeSH:noexp] OR practice guidelines as<br>topic[MeSH:noexp] OR Health Planning Guidelines[MeSH:noexp] OR<br>practice guideline[MeSH:noexp] OR clinical protocols[MeSH:noexp]||
||OR<br>Consensus[MeSH:noexp]<br>OR<br>"Consensus<br>Development<br>Conference"[PTYP]<br>OR<br>"Consensus<br>Development<br>Conference,||
||NIH"[PTYP]<br>OR<br>"Consensus<br>Development<br>Conferences<br>as<br>Topic"[MeSH:noexp] OR "Consensus Development Conferences, NIH<br>as Topic"[MeSH:noexp] OR critical pathway[MeSH:noexp] OR<br>(clinical[TIAB] AND pathway[TIAB]) OR (clinical[TIAB] AND<br>pathways[TIAB]) OR (practice[TIAB] AND parameter[TIAB]) OR||
||(practice[TIAB]<br>AND<br>parameters[TIAB])<br>OR<br>algorithms[MeSH:noexp]<br>OR<br>care<br>pathway[TIAB]<br>OR<br>care<br>pathways[TIAB] OR guidance[TIAB] OR guideline*[TI])<br>#3 #1 AND #2||
|TripDatabase|(anti-neutrophil cytoplasmic antibody-associated vasculitis) OR anca<br>[Filter: Evidence type] [Guidelines]|100|  
Após o resultado das estratégias de busca, a etapa de seleção, incluindo resolução de duplicatas e possíveis conflitos entre os metodologistas, foi realizada por meio do aplicativo Rayyan<sup>2</sup> . Essa etapa foi realizada independentemente por dois pesquisadores.  
Foram encontrados 430 registros, sendo elegíveis para inclusão três diretrizes (duas internacionais<sup>3,4</sup> e uma nacional)<sup>5</sup> que foram utilizados como base para a escrita do diagnóstico e tratamento da vasculite ANCA-associada. A avaliação da qualidade destes Protocolos foi realizada por dois pesquisadores de forma independente pela ferramenta AGREE II (Quadro F).  
**Quadro F** . Avaliação das diretrizes clínicas encontradas por meio da ferramenta AGREE-II.  
|**Domínios da**<br>**ferramenta AGREE**<br>**II**|**Diretriz EULAR**<br>**(escore de rigor**<br>**AGREE II)**|**Diretriz Pan**<br>**Americana**<br>**(escore de rigor**<br>**AGREE II)**|**Diretriz****_American_**<br>**_College of_**<br>**_Rheumatology_**<br>**vasculites (escore de**<br>**rigor AGREE II)**|**Sociedade Brasileira de**<br>**Reumatologia (escore**<br>**de rigor AGREE II)**|
|---|---|---|---|---|
|Escoo e objetivo|70% (concordo|70% (concordo|70% (concordo|70% (concordo|
|p|totalmente)|totalmente)|totalmente)|totalmente)|
|Envolvimento das<br>partes interessadas|70% (concordo<br>totalmente)|70% (concordo<br>totalmente)|60%|50%|
|Rigor do<br>desenvolvimento|60%|60%|50%|60%|
|Clareza da|70% (concordo|70% (concordo|70% (concordo|70% (concordo|
|apresentação|totalmente)|totalmente)|totalmente)|totalmente)|
|Aplicabilidade|60%|60%|50%|30%|  
|**Domínios da**<br>**ferramenta AGREE**<br>**II**|**Diretriz EULAR**<br>**(escore de rigor**<br>**AGREE II)**|**Diretriz Pan**<br>**Americana**<br>**(escore de rigor**<br>**AGREE II)**|**Diretriz****_American_**<br>**_College of_**<br>**_Rheumatology_**<br>**vasculites (escore de**<br>**rigor AGREE II)**|**Sociedade Brasileira de**<br>**Reumatologia (escore**<br>**de rigor AGREE II)**|
|---|---|---|---|---|
|Independência<br>editorial|70% (concordo<br>totalmente)|70% (concordo<br>totalmente)|50%|70% (concordo<br>totalmente)|  
Mediante as pontuações apresentadas para a avaliação global e de cada um dos domínios, considerou-se adequado, apesar de algumas limitações, o uso destas Diretrizes para subsidiar a escrita deste Protocolo, atentando-se para as adaptações necessárias ao contexto do SUS<sup>6</sup> .  
Devido à incorporação do rituximabe ao SUS<sup>26</sup> , foram elaboradas perguntas de pesquisa referentes aos demais medicamentos disponíveis no SUS para tratamento de indução de remissão em pacientes com vasculite ANCA-associada: ciclofosfamida intravenosa e glicocorticoides (prednisona e metilprednisolona). Portanto, uma busca na literatura por ECRs foi realizada para a elaboração da síntese de evidência.  
A seguir são apresentados, para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações e um resumo das evidências e as tabelas de perfil de evidências, de acordo com a metodologia GRADE.

---

<!-- METADADOS: doenca: Vasculite | secao: **QUESTÃO 1** . **Deve-se usar rituximabe para o tratamento de indução de remissão dos pacientes com vasculite ANCA-associada (GPA e MPA) ativa e grave e pacientes que apresentam recidiva da doença** ? -->
**Recomendação** : Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS do rituximabe para terapia de indução de remissão dos pacientes com diagnóstico recente em idade fértil e para casos de recidiva de vasculites ANCAassociada classificados como granulamatose com poliangeíte (GPA) ou poliangeíte microscópica (MPA), ativa e grave, conforme Relatório de Recomendação nº 836/2023 disponível em: https://www.gov.br/conitec/pt-  
br/midias/relatorios/2023/Relatorioderecomendao836Rituximabe.pdf  
A estrutura PICO para esta pergunta foi:  
**Pacientes:** Pacientes com diagnóstico de vasculite ANCA-associada (GPA e MPA) ativa e grave e pacientes que apresentaram recidiva da doença.  
**Intervenção:** rituximabe  
**Comparador:** ciclofosfamida  
**_Outcome_ /Desfecho:** Remissão completa, redução de glicocorticoide em 6 meses, remissão sustentada em 12 e 18 meses, recidiva em 6 meses, recidiva em 12 meses, recidiva em 18 meses, mortalidade, eventos adversos e eventos adversos graves Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n°836 da Conitec<sup>7</sup> . Foi realizada uma busca adicional em 04 de dezembro de 2023, para fins de atualização, contemplando as bases Central, Pubmed e Embase. Não foram utilizados limites de idioma ou qualquer restrição de tempo. As estratégias de busca e os resultados estão descritos no Quadro G.  
**Quadro G** . Estratégias de busca, de acordo com a base de dados, para identificação de ensaios clínicos randomizados.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|CENTRAL|Rituximab or CD20 Antibody or IDEC-C2B8 Antibody or GP2013 and ANCA<br>associated vasculitis|38|
|MEDLINE via<br>Pubmed|(ANCA associated vasculitis) or (Anti-neutrophil Cytoplasmic Antibody-Associated<br>Vasculitis) or (ANCA-associated vasculitis) or (Vasculitis, ANCA-associated) or<br>(Pauci-Immune Vasculitis) or (Pauci Immune Vasculitis) or (Pauci-Immune<br>Vasculitides) or (Vasculitides, Pauci-Immune) or (Vasculitis, Pauci-Immune) or<br>(ANCA-associated vasculitides) or (ANCAassociated vasculitides) or (ANCA-<br>associated vasculitide) or (Vasculitide, ANCA-Associated) or (Vasculitides, ANCA-<br>Associated) AND (Rituximab) or (CD20 Antibody, Rituximab) or (Rituximab CD20<br>Antibody) or (Mabthera) or (IDEC-C2B8 Antibody) or (IDEC C2B8 Antibody) or<br>(IDEC-C2B8) or (IDEC C2B8) or (GP2013) or (Rituxan) AND (Randomized<br>Controlled Trials as Topic) or (Clinical Trials, Randomized) or (Trials, Randomized<br>Clinical) or (Controlled Clinical Trials, Randomized) or (Randomized controlled trial)<br>or (((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])) or<br>((randomized controlled trial[Publication Type] OR (randomized[Title/Abstract] AND<br>controlled[Title/Abstract] AND trial[Title/Abstract])))|108|
|Embase|‘anca associated vasculitis’/exp OR ‘anca associated vasculitis’) AND (‘rituximab’/exp<br>OR ‘rituximab’) AND (‘randomized controlled trial’/exp OR ‘randomized controlled<br>trial’)|39|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> :  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com diagnóstico de vasculite associada ao ANCA (GPA e MPA) ativa e grave e pacientes que apresentaram recidiva da doença.  
- (b) Tipo de intervenção  
Rituximabe por infusão intravenosa comparado à ciclofosfamida por infusão intravenosa ou via oral.  
- (c) Tipos de estudos  
Foram considerados ensaios clínicos randomizados (ECRs)  
- (d) Desfechos  
Remissão completa (avaliada por questionários validados como BVAS (Birmingham Vasculitis Activity Score), redução de glicocorticoide em 6 meses, remissão sustentada em 12 e 18 meses, taxa de recidiva em 6 meses, taxa de recidiva em 12 meses, taxa de recidiva em 18 meses, mortalidade, eventos adversos e eventos adversos graves  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.  
Resultados da busca  
Para responder essa pergunta, foram utilizadas as referências e síntese de evidências apresentadas no Relatório de Recomendação n° 836 da Conitec<sup>7</sup> . Neste Relatório, foram incluídas quatro revisões sistemáticas<sup>8–11</sup> e dois ECRs: RITUXVAS 12,13 e RAVE-ITN 14,15. Adicionalmente, foi realizada uma atualização da busca, contemplando as bases Central, Pubmed e Embase. Os resultados da busca totalizaram 185 referências. Não foram localizados estudos adicionais. Todo o processo de seleção dos estudos é apresentado na Figura A.  
**Figura A.** Fluxograma de seleção dos estudos avaliando o uso do rituximabe comparado a ciclofosfamida para o tratamento da vasculite ANCA-associada  
<!-- Start of picture text -->
‘Total de referéncias<br>anteriorECRse da4 revisesrevisio (nsistematicas) = 7, sendo 3 CENTRALPUBMED:  :n= n=108 38 Referéncias duplicadas:<br>EMBASE: n= 39<br>resumo: n= 170<br>Referéncias excluidas:<br>n= 168<br>Referéncias selecionadas para<br>Novos estudos incluidos<br>leitura completa:<br>n=7;ECRsn=3;RSn=4<br><!-- End of picture text -->  
Análise e apresentação dos resultados  
O risco de viés dos estudos incluídos foi avaliado utilizando a ferramenta ROB 1.0 da Cochrane. Não foi possível realizar meta-análises dos dados devido aos estudos incluídos utilizarem esquemas terapêuticos distintos. Deste modo, os resultados foram apresentados na forma narrativa.  
Resumo das evidências:  
Como a atualização da estratégia de busca não encontrou estudo adicional que preenchesse os critérios de elegibilidade previamente descritos, foram considerados os dados disponíveis no Relatório de Recomendação n° 836 da Conitec<sup>7</sup> . As principais evidências são oriundas de dois ECRs multicêntricos que incluíram centros na Europa, Estados Unidos da América e Austrália (Quadro H).  
**Quadro H** . Principais ECRs incluídos utilizados para compor a síntese de evidência sobre o tratamento com RTX em pacientes com vasculite ANCA-associada.  
|**Autor/Ano**|**Delineamento/Local**|**Características dos**<br>**participantes**|**Descrição tecnologia/comparador**|**Dosagem/Frequência/Duração**|
|---|---|---|---|---|
|RAVE-ITN|ECR, controlado técnica "double|MPA = 75%|**TECNOLOGIA**:|RTX IV 1x/semana por 4 semanas na dose de 350 mg/m<sup>2</sup>|
|Stone et al 2010<br>(19)|<br>dummy", não inferioridade e<br>multicêntrico (EUA)|GPA = 24%|N=99<br>Grupo RTX IV|Ciclofosfamida oral 2 mg/kg/d e ajustado para<br>insuficiência|
|Specks et al||Diagnóstico recente = 50%|RTX IV + placebo-ciclofosfamida||
|2013 (18)|A randomização foi balanceada, os<br>grupos RTX e ciclofosfamida foram<br>equilibrados de acordo com: doença<br>recém diagnosticada, atividade da<br>doença, envolvimento de órgãos,<br>terapia pré-inscrição, exposição<br>passada à ciclofosfamida e<br>glicocorticoides totais administrados<br>no intervalo de 14 dias antes da<br>autorização informada ser obtido até a<br>primeira infusão investigativa|em cada grupo<br>BVAS/WG no início do<br>estudo:<br>**Grupo RTX**<br>M = 8,5; DP ± 3,2<br>**Grupo ciclofosfamida**<br>M = 8,2; DP ± 3,2|diária<br>**COMPARADOR**:<br>N=98<br>Grupo ciclofosfamida oral<br>ciclofosfamida oral + infusões de<br>placebo-rituximabe<br>Período de indução da remissão foi de 6<br>meses<br>Acompanhamento 12 e 18 meses<br>Ambos os grupos receberam o mesmo<br>regime de glicocorticoides|No grupo ciclofosfamida oral, os pacientes que tiveram<br>remissão entre 3 e 6 meses, foi retirada a ciclofosfamida,<br>utilizando o AZT 2 mg/kg/d para a manutenção<br>No grupo RTX, com a remissão no mesmo período (entre<br>3 e 6 meses), foi trocado para o placebo ciclofosfamida<br>pelo placebo AZT<br>Glicocorticoides: 1 a 3 pulsos de metilprednisolona (1000<br>mg cada), seguidos de prednisona em uma dose de 1<br>mg/kg/d. A dose foi reduzida de modo que, em 5 meses,<br>todos os pacientes que tiveram uma remissão sem surtos<br>de doença tivessem descontinuado os glicocorticoides|  
29  
|**Autor/Ano**|**Delineamento/Local**|**Características dos**<br>**participantes**|**Descrição tecnologia/comparador**|**Dosagem/Frequência/Duração**|
|---|---|---|---|---|
|RITUXVAS|ECR aberto, paralelo, multicêntrico|Paciente com VAA grave|**TECNOLOGIA**:|Grupo RTX IV + ciclofosfamida IV:|
|Jones et al 2010|(Europa e Austrália)|recentemente diagnosticada,|n=33|RTX IV 1x/semana por 4 semanas na dose de 350 mg/m<sup>2</sup>|
|(15)||com envolvimento renal,|RTX IV + ciclofosfamida IV|ciclofosfamida IV por 15 mg/kg juntamente com a 1ª e 3ª|
|Jones et al 2015|A randomização foi balanceada de|com mediana de idade de||infusões do RTX e sem o uso de AZT|
|(16)|acordo com a idade, diagnóstico e a<br>função renal basal dos pacientes, com<br>uma proporção de 3:1 para atribuição<br>aleatória. Essa diferença foi utilizada<br>a fim de identificar a segurança do<br>RTX|68 anos, 52% de homens,<br>mediana de BVAS = 19.|**COMPARADOR:**<br>N=11<br>Ciclofosfamida IV<br>Ambos os grupos receberam<br>metilprednisolona intravenosa (1 dose<br>de 1 g) e o mesmo regime de<br>glicocorticoides orais com 1 mg/kg/d;<br>com redução para 5 mg/d no final de 6<br>meses.|Grupo ciclofosfamida IV:<br>Ciclofosfamida IV<br>1 dose a cada 15 dias até completar 3 doses, seguido de 1<br>dose a cada 3 semanas até que a remissão estável fosse<br>alcançada (mínimo 6, máximo 10 doses) por 3 a 6 meses.<br>Após a retirada da ciclofosfamida, foi utilizado o AZT 2<br>mg/kg/d para a manutenção de remissão|  
<mark>ECR: ensaio clínico randomizado; MPAC poliangeíte microscópica; GPA: granulomatose com poliangeíte RTX: Rituximabe; AZA: Azatioprina; M: média; ±: desvio padrão, BVAS/WG:</mark> _<mark>Birmingham Vasculitis Activity Score for GPA</mark>_ <mark>;</mark>  
<mark>IV: intravenoso.</mark>  
30  
Os dois estudos (RITUXVAS<sup>12–15</sup> e RAVE-ITN<sup>14,15</sup> ) avaliaram diretamente a eficácia e segurança do uso do rituximabe intravenoso (RTX IV) em comparação com a ciclofosfamida intravenosa (IV) ou ciclofosfamida oral.  
A combinação de ciclofosfamida IV com RTX IV não apresentou vantagens em comparação com a ciclofosfamida IV seguida pelo uso de azatioprina em relação a eventos adversos graves, que incluem morte, recaídas e doença renal em estágio final em 24 meses. No entanto, em análises de subgrupo, os pacientes que apresentaram recidivam da doença desde o início do estudo obtiveram melhor resultados com o RTX IV em termos de remissão completa e redução de prednisona em 6 meses, com uma proporção de 67% dos pacientes utilizando RTX em comparação com 42% dos pacientes que receberam ciclofosfamida oral padrão seguida de azatioprina (P=0,01). Resultados superiores para o RTX também foram observados aos 12 meses quando comparado ao regime padrão de ciclofosfamida-azatioprina e glicocorticoides para indução de remissão em vasculite recidivante associada ao MPA e GPA, mas essa diferença não se manteve aos 18 meses. Não foram encontradas diferenças estatisticamente significativas em termos de segurança entre o RTX IV e a ciclofosfamida em um período de até 24 meses. As análises de rede de meta-análises indiretas também corroboram essas conclusões<sup>8,11</sup> .  
A avaliação completa do risco de viés é apresentada na Figura B. O estudo RITUXVAS<sup>12,13</sup> foi considerado como alto risco de viés de performance por ser baseado em um estudo aberto, no qual não houve cegamento dos participantes e tampouco dos avaliadores. O estudo RAVE-ITN<sup>14,15</sup> foi considerado como risco incerto por apresentar falhas no relato metodológico nos domínios relacionados ao processo de randomização (aleatorização e ocultação de alocação).  
**Figura B** . Avaliação do risco de viés segundo a ferramenta RoB-1 da Cochrane  
<!-- Start of picture text -->
ry<br>8<br>a<br>s 2<br>zs> —e 8<br>s s 2<br>€ 2 3<br>6,228 5<br>23328<br>23:8 25<br>2 £2 e<br>Ses 2 5B<br>£253 €5 8<br>£<s#2# 5s s<br>22§speSs3 5& 25 23fe8 B&<br>s 25 822868<br>22 88 2<br>R522: 8<br>s—€ =Es 22Bes=<br>gs $s83 #2266 8 §&€<br>= § 8338 8<br>es fea 8 y<br>—€ =5 3aa3 Bes<br>ss ££ €& £€e 2<br>$8 ss €&€ 8 5<br>5s Ss £f&322<br>«26 @ ££ & 8<br>RAVETN 2010 \@|elelelelele|<br>RITUXVAS 2010 \e\elelelelele|<br><!-- End of picture text -->  
Justificativa para a recomendação:  
O rituximabe foi recentemente incorporado ao SUS e os argumentos a favor da incorporação da tecnologia se concentraram, principalmente, nos benefícios clínicos do rituximabe, na gravidade da doença e nas limitações do tratamento atual das vasculites ANCA-associada no SUS.  
Considerações gerais e para implementação:  
O Grupo Elaborador considerou que a utilização do rituximabe é indicada em pacientes com vasculite ANCA-associada, com os seguintes critérios clínicos de elegibilidade:  
31

---

<!-- METADADOS: doenca: Vasculite | secao: **Critérios de inclusão:** -->
 terapia de indução de remissão dos pacientes com diagnóstico recente em idade fértil e para casos de recidiva de vasculites associadas aos anticorpos anticitoplasma de neutrófilos, classificados como granulamatose com poliangeíte (GPA) ou poliangeíte microscópica (MPA), ativa e grave.

---

<!-- METADADOS: doenca: Vasculite | secao: **Critérios de exclusão:** -->
- Hipersensibilidade ao rituximabe ou quaisquer excipientes da fórmula  
Para o monitoramento dos pacientes, os especialistas sugerem que devem ser monitorizados os níveis de imunoglobulinas  
e contagem de células B, antes da administração e a cada dose de rituximabe  
Perfil de evidências:  
A Tabela A apresenta a avaliação da certeza da evidência (GRADE) para os desfechos remissão completa e proporção de  
eventos adversos (qualquer gravidade), conforme avaliado no Relatório de Recomendação nº 836<sup>7</sup> .  
32  
**Tabela A** . Certeza da evidência de rituximabe comparado à ciclofosfamida para o tratamento da vasculite ANCA-associada (GPA ou MPA) ativa e grave  
|№ de<br>pacientes<br>(nº de<br>estudos)<br>Desfecho:|Delineamento<br>do estudo<br>remissão compl|<br>Risco<br>de viés<br>eta|Avaliação da cer<br>Inconsistência|teza<br>Evidência<br>indireta|Imprecisão|Outras<br>considerações|№ de pacientes<br>RTX<br>Placebo|Ef<br>Relativo<br>(IC 95%<br>)|eito<br>Absoluto<br>(IC<br>95%)|Certeza|Interpretação|
|---|---|---|---|---|---|---|---|---|---|---|---|
|241<br>(2)<br>Desfecho:|ECR<br>proporção de E|Grave<br>As (qualque|Não grave<br>r gravidade)|Não<br>grave|Grave|Não grave|No estudo RAVE,<br>completa (12 meses)<br>grupos no estudo de<br>No estudo RITUX<br>pacientes em remis<br>favorecer rituximab<br>estatística. No ent<br>estatisticamente<br>ciclofosfamida.|o tempo d<br>não foi dif<br>Jones.<br>VAS, a pr<br>são complet<br>e, sem si<br>anto, ritux<br>não-infer|e remissão<br>erente entre<br>oporção de<br>a tendeu a<br>gnificância<br>imabe foi<br>ior<br>a|⨁⨁◯◯<br>Baixa<br>a,b,c,d, e|A evidência não sugere<br>superioridade<br>clara<br>de<br>rituximabe em comparação<br>à<br>ciclofosfamida,<br>com<br>tendência a significância<br>estatística em um estudo, e<br>ausência de diferença em<br>outro estudo. A evidência<br>considerada<br>de<br>baixa<br>qualidade,<br>sugere<br>que<br>rituximabe pode ser não-<br>inferior a ciclofosfamida|
|241<br>(2)|ECR|Grave|Não grave|Não grave|Grave|Não grave|Taxa de EAs, de qua<br>idênticas entre os<br>estudos|lquer gravi<br>grupos em|dade foram<br>todos os|⨁⨁⨁◯<br>Moderada<br>a|A<br>evidência<br>sugere<br>diferença<br>clara<br>entre<br>rituximabe em comparação<br>à<br>ciclofosfamida.<br>Rituximabe<br>é<br>provavelmente comparável|  
33  
||||Avaliação da cer|teza|||№ de|pacientes|Efe|ito|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|№ de<br>pacientes<br>(nº de<br>estudos)|Delineamento<br>do estudo|Risco<br>de viés|Inconsistência|Evidência<br>indireta|Imprecisão|Outras<br>considerações|RTX|Placebo|Relativo<br>(IC 95%<br>)|Absoluto<br>(IC<br>95%)|Certeza|Interpretação|
|||||||||||||à<br>ciclofosfamida<br>em<br>termos de segurança|  
ECR: ensaio clínico randomizado, IC95%: intervalo de confiança de 95%; EA: evento adverso; RTX: Rituximabe  
Explicações:  
a: diminuído um nível devido limitações metodológicas  
b: diminuído um nível devido ao pequeno número amostral e IC amplo.  
34

---

<!-- METADADOS: doenca: Vasculite | secao: **QUESTÃO 2. Deve-se usar ciclofosfamida intravenosa para o tratamento de indução de remissão de pacientes com vasculite ANCA associada (GPA e MPA)?** -->
A ciclofosfamida intravenosa está disponível no SUS para tratamento de indução de remissão na vasculite ANCAassociada e, por se tratar de uma dúvida clínica, a busca por evidências foi realizada.  
<u>Recomendação:</u> Sugerimos utilizar a ciclofosfamida intravenosa para o tratamento de remissão dos pacientes com vasculite ANCA-associada (GPA e MPA) (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com diagnostico de vasculite ANCA-associada (GPA ou MPA)  
**Intervenção:** Ciclofosfamida por infusão intravenosa  
**Comparador:** Glicocorticoides, rituximabe ou placebo  
**Desfechos:** remissão completa por questionários validados como BVAS (Birmingham _vasculitis activity score_ ), taxa de  
recidiva , eventos adversos gerais e graves, qualidade de vida, redução da dose de glicocorticoides  
Métodos e resultados da busca  
Para a tomada de decisão, foi realizada uma busca por ensaios clínicos randomizados que compararam o uso da ciclofosfamida com os glicocorticoides, rituximabe ou placebo. Além disso, foi realizada uma busca manual das listas de referências das diretrizes clínicas identificadas. A busca foi realizada nas bases de dados CENTRAL via Cochrane Library, MEDLINE via Pubmed, Embase via Elsevier em 6 de dezembro de 2023. As estratégias de busca para cada base estão descritas no Quadro I.  
**Quadro I** . Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o uso da ciclofosfamida em pacientes com ANCA-associada.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|CENTRAL|#1 [mh "Anti-Neutrophil Cytoplasmic Antibody-Associated Vasculitis"] OR Pauci<br>NEAR/1 Vasculiti* OR "ANCA Associated" OR "Anti Neutrophil Cytoplasmic<br>Antibody Associated Vasculitis"<br>#2<br>[mh<br>Cyclophosphamide]<br>OR<br>cyclophosphamide<br>OR<br>Sendoxan<br>OR<br>"Cyclophosphamide<br>Anhydrous"<br>OR<br>"Cyclophosphamide,<br>(R)-Isomer"<br>OR<br>"Cyclophosphamide, (S)-Isomer" OR Cytophosphane OR "Cyclophosphamide<br>Monohydrate" OR Cytophosphan OR Cytoxan OR Endoxan OR Neosar OR Procytox<br>OR cyclophosphane<br>#3 [mh "Infusions, Intravenous"] OR [mh "Administration, Intravenous"] OR Infusion<br>OR Intravenous<br>#3 {AND #1-#3}|92|
|MEDLINE via<br>Pubmed|#1 "Anti-Neutrophil Cytoplasmic Antibody-Associated Vasculitis"[Mesh] OR Anti<br>Neutrophil Cytoplasmic Antibody Associated Vasculitis[tiab] OR Pauci-Immune<br>Vasculiti*[tiab] OR ANCA Associated Vasculiti*[tiab]|350|  
35  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#2 "Cyclophosphamide"[Mesh] OR Sendoxan[tiab] OR Cyclophosphamide[tiab] OR<br>Cytophosphane[tiab] OR Cytophosphan[tiab] OR Cytoxan[tiab] OR Endoxan[tiab]<br>OR Neosar[tiab] OR Procytox[tiab] OR cyclophosphane[tiab]<br>#3 "Infusions, Intravenous"[Mesh] OR "Administration, Intravenous"[Mesh] OR<br>Infusion[tiab] OR Intravenous[tiab]<br>#4 #1 AND #2 AND #3||
|Embase via<br>Elsevier|#1 'anca associated vasculitis'/exp OR 'anca associated vasculitis' OR 'anti neutrophil<br>cytoplasmic antibody associated vasculitis' OR 'pauci-immune vasculiti*' OR 'anca<br>vasculitis' OR vasculites<br>#2<br>'cyclophosphamide'/exp<br>OR<br>'cyclophosphamide'<br>OR<br>'Sendoxan'<br>OR<br>'Cyclophosphamide<br>Anhydrous'<br>OR<br>'Cyclophosphamide,<br>(R)-Isomer'<br>OR<br>'Cyclophosphamide, (S)-Isomer' OR 'Cytophosphane' OR 'Cyclophosphamide<br>Monohydrate' OR 'Cytophosphan' OR 'Cytoxan' OR 'Endoxan' OR 'Neosar' OR<br>'Procytox' OR 'cyclophosphane'<br>#3 'intravenous drug administration'/exp OR 'Infusion' OR 'Intravenous'<br>#4 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR<br>factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR<br>placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1<br>blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti<br>#5 #1 AND #2 AND #3 AND #4<br>#6 #5 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)|324|  
Foi utilizado o aplicativo Rayyan<sup>2</sup> para a avaliação de duplicatas dos registros e seleção dos estudos. A seleção dos estudos foi realizada por dois avaliadores independentes. As divergências entre os metodologistas em relação às decisões de inclusão foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com diagnostico de vasculite ANCA-associada (GPA ou MPA)  
- (b) Tipo de intervenção  
Ciclofosfamida por infusão intravenosa comparado à glicocorticoide, rituximabe ou placebo  
- (c) Tipos de estudos  
Foram considerados ensaios clínicos randomizados (ECRs)  
- (d) Desfechos  
Remissão completa por questionários validados como BVAS (Birmingham _vasculitis activity score_ ), taxa de recidiva,  
eventos adversos gerais e graves, qualidade de vida, redução da dose de glicocorticoides  
- (e) Idioma  
36  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Vasculite | secao: Resultados da busca -->
Foram recuperadas 766 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas 66 duplicatas e realizada a triagem dos títulos e resumos. Na sequência, 31 registros foram avaliados na íntegra. Entretanto, nenhum registro contemplou os critérios de elegibilidade. Além disso, 421 referências foram verificadas nas listas de referências das diretrizes identificadas, mas nenhum registro foi incluído. O processo de seleção é detalhado na Figura C.  
**Figura C.** Fluxograma de seleção de ensaios clínicos randomizados avaliando o uso da ciclofosfamida comparado ao rituximabe, glicocorticoide ou placebo para o tratamento da vasculite ANCA-associada  
<!-- Start of picture text -->
Busca em outras fontes Busca nas bases<br>Total de referéncias<br>Totalnos Guidelines de referénciasrecuperados:Psidentificadasn= 421 cenngacesPUBMED: n= urne 360 Referénciasn= 66  duplicadas:<br>EMBASE: n= 324<br>Referencias triadas por titulo e<br>resumo: n= 700<br>Referéncias excluidas<br>n= 669<br>Referéncias selecionadas para<br>leitura completa n= 31<br>Estudos incluidos<br>n=0<br>Referencias excluidas apés<br>>} leitura completa:<br>n= 31<br>Total de estudos incluidos<br>n=0<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Vasculite | secao: Análise e apresentação dos resultados -->
Foi planejada a avaliação de risco de viés por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada _Risk of Bias_ (RoB) e a avaliação seria realizada em duplicata, de forma independente. Além disso, as divergências seriam resolvidas por consenso ou através da consulta com um terceiro revisor.  
Em relação à apresentação dos dados, as variáveis contínuas dos desfechos relatados no estudo incluído seriam descritas como diferenças médias (DM) entre os grupos e as variáveis dicotômicas, como risco relativo (RR), com o respectivo Intervalo de confiança (IC) de 95%.

---

<!-- METADADOS: doenca: Vasculite | secao: Resumo das evidências: -->
A busca não retornou nenhum ECR que contemplasse os comparadores disponíveis no SUS, ou seja, nenhum registro atendeu a pergunta PICO envolvendo ciclofosfamida por infusão intravenosa comparado à glicocorticoide, rituximabe ou placebo.  
Justificativa para a recomendação:  
A ciclofosfamida intravenosa já é um medicamento disponível no SUS.  
37  
Considerações gerais e para implementação:  
Critérios de inclusão:  
- terapia de remissão dos pacientes com diagnóstico de vasculite ANCA-associada (GPA ou MPA).  
- Critérios de exclusão  
- Hipersensibilidade à ciclofosfamida ou quaisquer excipientes da fórmula;  
- Grávidas e lactantes.

---

<!-- METADADOS: doenca: Vasculite | secao: **ANCA associada?** -->
Os glicocorticoides, por via intravenosa, estão disponíveis no SUS para tratamento de indução de remissão de vasculite ANCA-associada e, por se tratar de uma dúvida clínica, a busca por evidências foi realizada.  
Recomendação: Sugerimos utilizar glicocorticoide intravenoso para o tratamento de remissão dos pacientes com vasculite ANCA-associada (GPA e MPA) (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com diagnostico de vasculite ANCA-associada  
**Intervenção:** glicocorticoide intravenoso  
**Comparador:** ciclofosfamida intravenosa, rituximabe ou placebo  
**Desfechos:** remissão completa por questionários validados como BVAS ( _birmingham vasculitis activity_ score), taxa de  
recidiva, eventos adversos gerais e graves, qualidade de vida, redução da dose de glicocorticoides.  
Métodos e resultados da busca  
Para a tomada de decisão, foi realizada uma busca por ECRs que compararam o uso de glicocorticoide intravenoso com os fármacos ciclofosfamida, rituximabe ou placebo. Além disso, foi realizada uma busca manual das listas de referências das diretrizes identificadas. A busca foi realizada nas bases de dados CENTRAL via Cochrane Library, MEDLINE via Pubmed, Embase via Elsevier em 6 de dezembro de 2023. As estratégias de busca para cada base estão descritas no Quadro J.  
**Quadro J** . Estratégias de busca, de acordo com a base de dados, para identificação de estudos sobre o uso de glicocorticoides em pacientes com vasculite ANCA-associada (GPA e MPA).  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|CENTRAL|#1 [mh "Anti-Neutrophil Cytoplasmic Antibody-Associated Vasculitis"] OR Pauci<br>NEAR/1 Vasculiti* OR "ANCA Associated" OR "Anti Neutrophil Cytoplasmic<br>Antibody Associated Vasculitis"<br>#2<br>[mh<br>Glucocorticoids]<br>OR<br>Glucocorticoid*<br>OR<br>Glycocorticoid<br>OR<br>glycocorticosteroid<br>#3 [mh Prednisone] OR prednisone OR dihydrocortisone OR delta-cortisone OR<br>rectodelt OR prednison hexal OR ultracorten OR cortancyl OR decortin OR dacortin<br>OR deltasone OR encortone OR encorton OR liquid pred OR Meticorten OR<br>prednison acsis OR pronisone OR prednison galen OR ancortone OR apo-<br>prednisone OR colisone OR cortan OR cortidelt OR dacorten OR de cortisyl OR|92|  
38  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||decortancyl OR decortin OR decortisyl OR dihydrocortisone OR dekortin OR<br>dellacort a OR delta cortelan OR delta cortisone OR delta dome OR delta e OR delta-<br>dome OR deltacorten OR deltacortene OR deltacortisone OR deltacortone OR<br>deltasone OR deltison OR deltisona OR deltra OR di adreson OR di-adreson OR<br>diadreson OR drazone OR encorton OR encortone OR enkorton OR fernisone OR<br>hostacortin OR liquid pred OR lodotra OR me-korti OR metacortandracin OR<br>Meticorten OR nisona OR Orasone OR panafcort OR paracort OR pehacort OR<br>precort OR prednicen-m OR prednicorm OR prednicot OR prednidib OR prednisone<br>OR prednitone OR pronison OR pronisone OR rayos OR rectodelt OR servisone OR<br>sterapred OR ultracorten OR winpred OR prednisone OR Dacortin OR Panasol<br>Predni Tablinen OR Sone<br>#4 [mh Methylprednisolone] OR Metipred OR "di adresone f" OR encortolon OR<br>hostacortin h OR "hostacortin h vet" OR hydeltra OR hydrocortancyl OR inflanefran<br>OR "Wegener’s granulomatosis" OR meticortelone OR "neo delta" OR nisolone OR<br>"nsc 9120" OR "predni h tablinen" OR prednis OR prednisolon OR prednisolona<br>OR predonine OR prelone OR prenin OR preventan OR prezolon OR solone OR<br>sterane OR supercortisol OR wysolone OR capsoid OR "co hydeltra" OR<br>codelcortone OR "decortin h" OR "dehydro cortex" OR "dehydro hydrocortison"<br>OR "dehydro hydrocortisone" OR dehydrocortisol OR dehydrohydrocortisone OR<br>"delcortol OR delta 1 17 hydroxycorticosterone 21 acetate" OR "delta 1<br>hydrocortisone" OR "delta cortril" OR "delta f" OR "delta hydrocortison" OR "delta<br>hydrocortisone" OR "delta ophticor" OR "delta stab" OR "delta-cortef" OR "delta1<br>dehydrocortisol" OR "delta1 dehydrohydrocortisone" OR "delta1 hydrocortisone"<br>OR deltacortil OR deltacortril OR deltahydrocortisone OR "6-methylprednisolone"<br>OR esametone OR firmacort OR medixon OR medrate OR medrol OR medrol OR<br>"medrol adt pak" OR "medrol dosepak" OR "medrol medules" OR "medrol pak" OR<br>medrone OR mesopren OR "methyl prednisolone" OR "methylpred dp" OR<br>metrisone OR metypred OR neomedrone OR prednol OR solomet OR "solu<br>decortin" OR urbason OR methylprednisolone<br>#5 [mh "Infusions, Intravenous"] OR [mh "Administration, Intravenous"] OR<br>Infusion OR Intravenous<br>#6 {OR #2-#4}<br>#7 #1 AND #5 AND #6||
|MEDLINE<br>via<br>Pubmed|#1 "Anti-Neutrophil Cytoplasmic Antibody-Associated Vasculitis"[Mesh] OR Anti<br>Neutrophil Cytoplasmic Antibody Associated Vasculitis[tiab] OR Pauci-Immune<br>Vasculiti*[tiab] OR ANCA Associated Vasculiti*[tiab]|213|  
39  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#2 "Glucocorticoids"[Mesh] OR Glucocorticoid*[tiab] OR Glycocorticoid[tiab] OR<br>glycocorticosteroid[tiab]<br>#3 "Prednisone"[Mesh] OR prednisone[tiab] OR dihydrocortisone[tiab] OR delta-<br>cortisone[tiab] OR rectodelt[tiab] OR prednison hexal[tiab] OR ultracorten[tiab] OR<br>cortancyl[tiab] OR decortin[tiab] OR dacortin[tiab] OR deltasone[tiab] OR<br>encortone[tiab] OR encorton[tiab] OR liquid pred[tiab] OR Meticorten[tiab] OR<br>prednison acsis[tiab] OR pronisone[tiab] OR prednison galen[tiab] OR<br>ancortone[tiab] OR apo-prednisone[tiab] OR colisone[tiab] OR cortan[tiab] OR<br>cortidelt[tiab] OR dacorten[tiab] OR de cortisyl[tiab] OR decortancyl[tiab] OR<br>decortin[tiab] OR decortisyl[tiab] OR dekortin[tiab] OR dellacort a[tiab] OR delta<br>cortelan[tiab] OR delta cortisone[tiab] OR delta dome[tiab] OR delta e[tiab] OR<br>delta-dome[tiab]<br>OR<br>deltacorten[tiab]<br>OR<br>deltacortene[tiab]<br>OR<br>deltacortisone[tiab] OR deltacortone[tiab] OR deltasone[tiab] OR deltison[tiab] OR<br>deltisona[tiab] OR deltra[tiab] OR di adreson[tiab] OR di-adreson[tiab] OR<br>diadreson[tiab] OR drazone[tiab] OR encorton[tiab] OR encortone[tiab] OR<br>enkorton[tiab] OR fernisone[tiab] OR hostacortin[tiab] OR liquid pred[tiab] OR<br>lodotra[tiab] OR me-korti[tiab] OR metacortandracin[tiab] OR Meticorten[tiab] OR<br>nisona[tiab] OR Orasone[tiab] OR panafcort[tiab] OR paracort[tiab] OR<br>pehacort[tiab] OR precort[tiab] OR prednicen-m[tiab] OR prednicorm[tiab] OR<br>prednicot[tiab] OR prednidib[tiab] OR prednitone[tiab] OR pronison[tiab] OR<br>pronisone[tiab] OR rayos[tiab] OR rectodelt[tiab] OR servisone[tiab] OR<br>sterapred[tiab] OR ultracorten[tiab] OR winpred[tiab] OR Dacortin[tiab] OR<br>Panasol Predni Tablinen[tiab] OR Sone[tiab]<br>#4 "Methylprednisolone"[Mesh] OR Metipred[tiab] OR di adresone f[tiab] OR<br>encortolon[tiab] OR hostacortin h[tiab] OR hostacortin h vet[tiab] OR hydeltra[tiab]<br>OR hydrocortancyl[tiab] OR inflanefran[tiab] OR meticortelone[tiab] OR neo<br>delta[tiab] OR nisolone[tiab] OR nsc 9120[tiab] OR predni h tablinen[tiab] OR<br>prednis[tiab] OR prednisolon[tiab] OR prednisolona[tiab] OR predonine[tiab] OR<br>prelone[tiab] OR prenin[tiab] OR preventan[tiab] OR prezolon[tiab] OR<br>solone[tiab] OR sterane[tiab] OR supercortisol[tiab] OR wysolone[tiab] OR<br>capsoid[tiab] OR co hydeltra[tiab] OR codelcortone[tiab] OR decortin h[tiab] OR<br>dehydro<br>cortex[tiab]<br>OR<br>dehydro<br>hydrocortison[tiab]<br>OR<br>dehydro<br>hydrocortisone[tiab] OR dehydrocortisol[tiab] OR dehydrohydrocortisone[tiab] OR<br>delcortol[tiab] OR delta 1 17 hydroxycorticosterone 21 acetate[tiab] OR delta 1<br>hydrocortisone[tiab] OR delta cortril[tiab] OR delta f[tiab] OR delta<br>hydrocortison[tiab] OR delta hydrocortisone[tiab] OR delta ophticor[tiab] OR delta<br>stab[tiab] OR delta-cortef[tiab] OR delta1 dehydrocortisol[tiab] OR delta1||  
40  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||dehydrohydrocortisone[tiab] OR delta1 hydrocortisone[tiab] OR deltacortil[tiab]<br>OR deltacortril[tiab] OR deltahydrocortisone[tiab] OR 6-methylprednisolone[tiab]<br>OR esametone[tiab] OR firmacort[tiab] OR medixon[tiab] OR medrate[tiab] OR<br>medrol[tiab] OR medrol[tiab] OR medrol adt pak[tiab] OR medrol dosepak[tiab]<br>OR medrol medules[tiab] OR medrol pak[tiab] OR medrone[tiab] OR<br>mesopren[tiab] OR methyl prednisolone[tiab] OR methylpred dp[tiab] OR<br>metrisone[tiab] OR metypred[tiab] OR neomedrone[tiab] OR prednol[tiab] OR<br>solomet[tiab] OR solu decortin[tiab] OR urbason[tiab] OR methylprednisolone[tiab]<br>#5  "Infusions, Intravenous"[Mesh] OR "Administration, Intravenous"[Mesh] OR<br>Infusion[tiab] OR Intravenous[tiab]<br>#6 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH<br>Terms]<br>OR<br>clinical<br>trial[Publication<br>Type]<br>OR<br>random*[Title/Abstract] OR random allocation[MeSH Terms] OR therapeutic<br>use[MeSH Subheading])<br>#7 #2 OR #3 OR #4<br>#8 #1 AND #7 AND #5 AND #6||
|Embase<br>via<br>Elsevier|#1 'anca associated vasculitis'/exp OR 'anca associated vasculitis' OR 'anti neutrophil<br>cytoplasmic antibody associated vasculitis' OR 'pauci-immune vasculiti*' OR 'anca<br>vasculitis' OR vasculites<br>#2 'glucocorticoid'/exp OR 'glycocorticoid' OR 'glycocorticosteroid' OR<br>'glucocorticoid'<br>#3 'prednisone'/exp OR 'prednisone' OR 'dihydrocortisone' OR 'delta-cortisone' OR<br>'rectodelt' OR 'prednison hexal' OR 'ultracorten' OR 'cortancyl' OR 'decortin' OR<br>'dacortin' OR 'deltasone' OR 'encortone' OR 'encorton' OR 'liquid pred' OR<br>'Meticorten' OR 'prednison acsis' OR 'pronisone' OR 'prednison galen' OR<br>'ancortone' OR 'apo-prednisone' OR 'colisone' OR 'cortan' OR 'cortidelt' OR<br>'dacorten' OR 'de cortisyl' OR 'decortancyl' OR 'decortin' OR 'decortisyl' OR<br>'dekortin' OR 'dellacort a' OR 'delta cortelan' OR 'delta cortisone' OR 'delta dome'<br>OR 'delta e' OR 'delta-dome' OR 'deltacorten' OR 'deltacortene' OR 'deltacortisone'<br>OR 'deltacortone' OR 'deltasone' OR 'deltison' OR 'deltisona' OR 'deltra' OR 'di<br>adreson' OR 'di-adreson' OR 'diadreson' OR 'drazone' OR 'encorton' OR 'encortone'<br>OR 'enkorton' OR 'fernisone' OR 'hostacortin' OR 'liquid pred' OR 'lodotra' OR 'me-<br>korti' OR 'metacortandracin' OR 'Meticorten' OR 'nisona' OR 'Orasone' OR<br>'panafcort' OR 'paracort' OR 'pehacort' OR 'precort' OR 'prednicen-m' OR<br>'prednicorm' OR 'prednicot' OR 'prednidib' OR 'prednitone' OR 'pronison' OR<br>'pronisone' OR 'rayos' OR 'rectodelt' OR 'servisone' OR 'sterapred' OR 'ultracorten'<br>OR 'winpred' OR 'Dacortin' OR 'Panasol Predni Tablinen' OR 'Sone'|115|  
41  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#4 'methylprednisolone'/exp OR 'Metipred' OR 'di adresone f' OR 'encortolon' OR<br>'hostacortin h' OR 'hostacortin h vet' OR 'hydeltra' OR 'hydrocortancyl' OR<br>'inflanefran' OR 'meticortelone' OR 'neo delta' OR 'nisolone' OR 'nsc 9120' OR<br>'predni h tablinen' OR 'prednis' OR 'prednisolon' OR 'prednisolona' OR 'predonine'<br>OR 'prelone' OR 'prenin' OR 'preventan' OR 'prezolon' OR 'solone' OR 'sterane' OR<br>'supercortisol' OR 'wysolone' OR 'capsoid' OR 'co hydeltra' OR 'codelcortone' OR<br>'decortin h' OR 'dehydro cortex' OR 'dehydro hydrocortison' OR 'dehydro<br>hydrocortisone' OR 'dehydrocortisol' OR 'dehydrohydrocortisone' OR 'delcortol' OR<br>'delta 1 17 hydroxycorticosterone 21 acetate' OR 'delta 1 hydrocortisone' OR 'delta<br>cortril' OR 'delta f' OR 'delta hydrocortison' OR 'delta hydrocortisone' OR 'delta<br>ophticor' OR 'delta stab' OR 'delta-cortef' OR 'delta1 dehydrocortisol' OR 'delta1<br>dehydrohydrocortisone' OR 'delta1 hydrocortisone' OR 'deltacortil' OR 'deltacortril'<br>OR 'deltahydrocortisone' OR '6-methylprednisolone' OR 'esametone' OR 'firmacort'<br>OR 'medixon' OR 'medrate' OR 'medrol' OR 'medrol' OR 'medrol adt pak' OR<br>'medrol dosepak' OR 'medrol medules' OR 'medrol pak' OR 'medrone' OR 'mesopren'<br>OR 'methyl prednisolone' OR 'methylpred dp' OR 'metrisone' OR 'metypred' OR<br>'neomedrone' OR 'prednol' OR 'solomet' OR 'solu decortin' OR 'urbason' OR<br>'methylprednisolone'<br>#5 'intravenous drug administration'/exp OR  'Infusion' OR 'Intravenous'<br>#6 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR<br>factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR<br>placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1<br>blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti<br>#7 #2 OR #3 OR #4<br>#8 #1 AND #5 AND #6 AND #7<br>#9 #8 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre  
os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com diagnóstico de vasculite associada ao ANCA (GPA e MPA)  
- (b) Tipo de intervenção  
Glicocorticoide por infusão intravenosa comparado à ciclofosfamida intravenosa, rituximabe ou placebo  
- (c) Tipos de estudos  
Foram considerados ensaios clínicos randomizados (ECRs)  
42

---

<!-- METADADOS: doenca: Vasculite | secao: (d) Desfechos -->
Remissão completa por questionários validados como BVAS (Birmingham _vasculitis activity score_ ), taxa de recidiva,  
eventos adversos gerais e graves, qualidade de vida, redução da dose de glicocorticoides  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.  
Resultados da busca  
Foram recuperadas 420 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas 57 duplicatas e realizada a triagem dos títulos e resumos. Na sequência, 6 registros foram avaliados na íntegra. Entretanto, nenhum registro contemplou os critérios de elegibilidade. Além disso, 421 referências foram verificadas nas listas de referências das diretrizes identificadas. Nenhum estudo foi incluído. O processo de seleção é detalhado na Figura D.  
**Figura D** . Fluxograma de seleção dos estudos (ensaios clínicos randomizados) avaliando o uso da glicocorticoide comparado ao rituximabe, ciclofosfamida ou placebo para o tratamento da vasculite ANCA-associada  
<!-- Start of picture text -->
Total de referéncias<br>Totalnes Guidelines de referéncias recuperados:identificadasn= 421 CENTRALPUBMED:identificadas: :n= n= 92213,n= 420 Referéncias87 duplicadas:<br>EMBASE: n= 115<br>Referéncias triadas por titulo @<br>resumo: n= 363<br>Referéncias excluidas:<br>n= 357<br>Referéncias selecionadas para<br>leitura completa n= 6<br>Novos estudos incluidos<br>n=0<br>Referincias excluidas apés<br>leitura completa:<br>n=6<br>Total de estudos incluidos<br>n= 0<br><!-- End of picture text -->  
Análise e apresentação dos resultados  
Foi planejada a avaliação de risco de viés por dois avaliadores por meio da ferramenta RoB. A avaliação seria em duplicata, de forma independente. Além disso, as divergências seriam resolvidas por consenso ou pela consulta com um terceiro revisor.  
Em relação à apresentação dos dados, as variáveis contínuas dos desfechos relatados no estudo incluído seriam descritas como DM entre os grupos e as variáveis dicotômicas, como RR com o respectivo IC de 95%.  
Resumo das evidências:  
A busca não retornou ECR que contemplasse os comparadores disponíveis no SUS, ou seja, nenhum registro atendeu à pergunta PICO envolvendo glicocorticoide por infusão intravenosa comparado à ciclofosfamida, rituximabe ou placebo.  
Justificativa para a recomendação:  
O glicocorticoide por infusão intravenosa já é um medicamento disponível no SUS.  
Considerações gerais e para implementação:  
Critérios de inclusão:  
43  
- Terapia de remissão dos pacientes com diagnóstico de vasculite ANCA-associada (GPA ou MPA).  
Critérios de exclusão:  
- Hipersensibilidade a corticosteroides ou quaisquer excipientes da fórmula;  
- Infecções sistêmicas por fungos;  
- Grávidas e lactantes.

---

<!-- METADADOS: doenca: Vasculite | secao: **6. REFERÊNCIAS** -->
1. Ministério da Saúde S de CT e IED de C e TecnologiaB. Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. 2014;  
2. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan-a web and mobile app for systematic reviews. Syst Rev. 2016 Dec;5(1):210.  
3. Magri SJ, Ugarte-Gil MF, Brance ML, Flores-Suárez LF, Fernández-Ávila DG, Scolnik M, et al. Pan American League of Associations for Rheumatology Guidelines for the treatment of ANCA-associated vasculitis. Lancet Rheumatol. 2023;  
4. Yates M, Watts RA, Bajema IM, Cid MC, Crestani B, Hauser T, et al. EULAR/ERA-EDTA recommendations for the management of ANCA-associated vasculitis. Ann Rheum Dis. 2016;75(9):1583–94.  
5. Souza AWS de, Calich AL, Mariz H de A, Ochtrop MLG, Bacchiega ABS, Ferreira GA, et al. Recomendações da Sociedade Brasileira de Reumatologia para a terapia de indução para vasculite associada a ANCA. Rev Bras Reumatol. 2017;57:s484–96.  
6. Brasil. Ministério da Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas. 2023;  
7. Conitec. Rituximabe  para terapia de indução de remissão dos pacientes com  diagnóstico recente e para casos de recidiva de  vasculites associadas aos anticorpos anticitoplasma de  neutrófilos, ativa e grave. Relatório de Recomendação N°836. 2023;  
8. Bellos I, Boletis I, Lionaki S. A meta-analysis of the safety and efficacy of maintenance therapies for antineutrophil cytoplasmic antibody small-vessel vasculitis. Kidney Int Rep. 2022;7(5):1074–83.  
9. Springer JM, Kalot MA, Husainat NM, Byram KW, Dua AB, James KE, et al. Granulomatosis With Polyangiitis and Microscopic Polyangiitis: A Systematic Review and Meta‐Analysis of Benefits and Harms of Common Treatments. ACR Open Rheumatol. 2021;3(3):196–205.  
10. Silva-Fernández L, Loza E, Martínez-Taboada VM, Blanco R, Rúa-Figueroa Í, Pego-Reigosa JM, et al. Biological therapy for systemic vasculitis: a systematic review. In: Seminars in arthritis and rheumatism. Elsevier; 2014. p. 542–57.  
11. Lee YH, Song GG. Comparative efficacy and safety of rituximab, mycophenolate, and cyclophosphamide in active antineutrophil cytoplasmic antibody-associated vasculitis: A Bayesian network meta-analysis of randomized controlled trials. Int J Clin Pharmacol Ther. 2021;59(10):645.  
12. Jones RB, Cohen Tervaert JW, Hauser T, Luqmani R, Morgan MD, Peh CA, et al. Rituximab versus cyclophosphamide in ANCA-associated renal vasculitis. New England Journal of Medicine. 2010;363(3):211–20.  
13. Jones RB, Furuta S, Tervaert JWC, Hauser T, Luqmani R, Morgan MD, et al. Rituximab versus cyclophosphamide in ANCA-associated renal vasculitis: 2-year results of a randomised trial. Ann Rheum Dis. 2015;74(6):1178–82.  
14. Stone JH, Merkel PA, Spiera R, Seo P, Langford CA, Hoffman GS, et al. Rituximab versus cyclophosphamide for ANCA-associated vasculitis. New England Journal of Medicine. 2010;363(3):221–32.  
15. Specks U, Merkel PA, Seo P, Spiera R, Langford CA, Hoffman GS, et al. Efficacy of remission-induction regimens for ANCA-associated vasculitis. New England Journal of Medicine. 2013;369(5):417–27.  
44  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Vasculite | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**||**Tecnologias avaliadas pe**|**la Conitec**|
|---|---|---|---|
|**da diretriz clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais**<br>**alterações**|**Incorporação ou alteração do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||Ajuste no critério de<br>inclusão, inserção de<br>frase sobre a<br>contraindicação da<br>ciclofosfamida em<br>gestantes e correção<br>da Figura 1.|-|-|
|Relatório de<br>Recomendação nº<br>895/2023|Primeira versão do<br>documento|Rituximabe para terapia de indução de<br>remissão dos pacientes com diagnóstico<br>recente em idade fértil e para os casos de<br>recidiva de vasculites associadas aos<br>anticorpos anti-citoplasma de neutrófilos<br>(VAA), classificados como granulomatose<br>com poliangeite (GPA) ou poliangeite<br>microscópica (MPA), ativa e grave.<br>[Relatório de Recomendação nº 836/2023;<br>Portaria SECTICS/MS nº 44/2023]||  
45

---

