<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL  
DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 7, DE JUNHO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Anemia Hemolítica Autoimune.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhe confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024, resolvem:  
Considerando a necessidade de se atualizarem os parâmetros sobre a Anemia Hemolítica Autoimune no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 938/2024 e o Relatório de Recomendação n<sup><u>o</u></sup> 941/2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Anemia Hemolítica Autoimune.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Anemia Hemolítica Autoimune, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Anemia Hemolítica Autoimune.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 27, de 26 de novembro de 2018, publicada no Diário Oficial da União (DOU) nº 236, de 10 de dezembro de 2018, seção 1, página 112.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: FERNANDA DE NEGRI -->
3

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **INTRODUÇÃO** -->
A anemia hemolítica autoimune (AHAI) é uma condição clínica rara em que autoanticorpos se ligam à superfície das hemácias ocasionando sua destruição precoce via sistema do complemento ou sistema reticuloendotelial.  A incidência global descrita da AHAI é de aproximadamente 1 a 3 casos/100.000 habitantes por ano, com aproximadamente 0,2 casos/1.000.000 indivíduos com menos de 20 anos de idade<sup>1–5</sup> .  
A hemólise desencadeada pela ligação dos autoanticorpos às hemácias pode ocorrer no meio intra ou extravascular. A AHAI pode ser classificada em **quente** ou **fria,** de acordo com a temperatura de maior reatividade dos autoanticorpos circulantes. De maneira geral, anticorpos da classe IgG reagem com maior afinidade a 37ºC e são os responsáveis pela AHAI quente. Os anticorpos quentes são responsáveis por cerca de 70% a 80% de todos os casos de AHAI, podendo ocorrer em pessoas de qualquer idade. Estes anticorpos são identificados por meio do teste de Coombs positivo para IgG ou C3d e, mais raramente, de IgA, na ausência de sintomas associados ao frio. Já os anticorpos da classe IgM reagem em temperaturas mais baixas e costumam desencadear a AHAI fria. Na forma mista, os dois tipos de autoanticorpos mais frequentes, IgG e IgM, podem coexistir<sup>1,5–8</sup> .  
A AHAI também pode ser classificada pela sua etiologia: idiopática ou primária, quando não apresenta correlação com outra doença de base; ou secundária, quando associada a outras doenças, como doenças linfoproliferativas (leucemia linfocítica crônica, linfoma não Hodgkin), doenças autoimunes (lúpus eritematoso sistêmico), infecções virais (vírus da Imunodeficiência adquirida - HIV/Vírus Epstein-Barr - EBV/vírus da Hepatite C - HCV/vírus SARS-CoV-2),  neoplasias ou uso de medicamentos, onde cefalosporinas de segunda e terceira geração, diclofenaco, rifampicina, fludarabina e oxaliplatina são os casos mais relatados. As doenças linfoproliferativas são responsáveis por mais da metade dos casos de AHAI secundária e os quadros de AHAI induzida por medicamentos são 10% dos casos<sup>9–14</sup> .  
A imunossupressão é a principal alternativa terapêutica para a AHAI e tem por objetivo diminuir os títulos de autoanticorpos circulantes, reduzindo o grau de hemólise, com consequente elevação dos níveis de hemoglobina (Hb) e melhora dos sintomas de anemia. Nos casos de AHAI secundária, é essencial tratar a doença de base, seja pela suspensão de uso de medicamentos que possam desencadear o processo, seja pelo tratamento de doenças linfoproliferativas ou autoimunes associadas. A correta identificação do tipo de AHAI é fundamental, uma vez que o curso da doença e o tratamento são distintos para quadros causados por anticorpos quentes e frios<sup>1,4,6,15</sup> .  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da AHAI. A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária à Saúde um caráter essencial para um melhor resultado terapêutico e melhor prognóstico dos casos.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- D59.0 Anemia hemolítica autoimune induzida por droga  
- D59.1 Outras anemias hemolíticas autoimunes

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **DIAGNÓSTICO** -->
4

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **3.1. Diagnóstico clínico** -->
A apresentação clínica e a história natural da AHAI quente são bastante variáveis, pois dependem da titulação e efetividade dos autoanticorpos causadores da hemólise. Nas formas mais brandas, a única manifestação da anemia hemolítica pode ser exclusivamente laboratorial, com o teste de Coombs direto positivo, porém sem hemólise significativa ou sintomas anêmicos associados. Nesses casos, os baixos títulos de anticorpos presentes não são suficientes para uma manifestação mais grave da doença<sup>17,18</sup> . Entretanto, a maioria dos pacientes apresenta anemia que tende a ser moderada a grave, com níveis de hemoglobina variando entre 6 e 10 g/dL<sup>19</sup> . O surgimento de sintomas nesses casos está relacionado diretamente à velocidade de queda da hemoglobina e à capacidade funcional e adaptativa de cada indivíduo. Os sintomas mais comumente observados são aqueles da síndrome anêmica, como dispneia, fadiga, baixa tolerância ao exercício, palpitações ou cefaleia. Ao exame físico, encontram-se variados graus de palidez e icterícia e a esplenomegalia é frequentemente observada<sup>1,20</sup> . O curso da doença é variável, tendo relação também com a faixa etária dos pacientes. Em crianças, a doença tende a ser autolimitada; porém em adultos, é usualmente crônica, podendo apresentar exacerbações e remissões ao longo do tempo<sup>1,18,21</sup> .  
Na AHAI fria, aproximadamente 15% dos casos de AHAI, o quadro clínico está relacionado à aglutinação das hemácias quando há exposição ao frio, com consequente hemólise e anemia. A maioria dos pacientes apresenta anemia leve representada clinicamente por palidez e fadiga. Nos meses de inverno, no entanto, pode haver piora do quadro e hemólise aguda mais evidente, ocasionando hemoglobinemia, hemoglobinúria e icterícia. Acrocianose e fenômeno de Raynaud podem ocorrer, pois o sangue nas extremidades é mais suscetível às temperaturas externas mais baixas. Raramente estes episódios são acompanhados de oclusões vasculares seguidas de necrose<sup>1,8</sup> .  
Formas graves de AHAI podem acontecer mais raramente, tanto na AHAI quente como na AHAI fria, com piores desfechos associados, como hospitalização, internação em UTI, necessidade de suporte transfusional mais frequente e maior mortalidade<sup>22</sup> .  
A apresentação clínica dos pacientes com formas secundárias a infecções tende a ser autolimitada. Os sintomas comumente aparecem duas a três semanas após o início da infecção e são resolvidos espontaneamente duas a três semanas mais tarde<sup>14</sup> .  
A infecção por SARS-CoV-2 e a vacinação para COVID-19 parecem estar associadas a diferentes alterações hematológicas autoimunes e a múltiplos subtipos de AHAI, começando, em média, 7 dias após a infecção sintomática e 5 dias após a vacinação. Os relatos dessa associação com AHAI ainda são escassos na literatura. Uma relação causal definitiva ainda não pode ser formalmente estabelecida, assim como o mecanismo fisiopatogênico associado. Esses achados servem para ilustrar o risco potencial dessa complicação, aumentar a vigilância pós infecção e pós vacinação e mitigar a morbimortalidade. As vantagens da imunização parecem, ainda assim, exceder esses riscos<sup>11–13</sup> .  
Em uma revisão sistemática de 33 casos, foi identificado que pacientes com diagnóstico confirmado de Covid-19 desenvolveram doença autoimune após o início dos sintomas. Seis doenças autoimunes foram relatadas, incluindo a AHAI. Estes achados podem ajudar a esclarecer a associação entre doenças autoimunes e infecções. A AHAI foi responsável por 24,2% dessas respostas autoimunes, que ocorreram entre 2 e 33 dias após a infecção<sup>23</sup> .  
<mark>Os pacientes com AHAI estão mais propensos a apresentar tromboses, além de distúrbios autoimunes. Estudos descrevem que 11 a 20% dos pacientes com AHAI podem apresentar eventos tromboembólicos concomitantes ao quadro anêmico.</mark><sup>24</sup> <mark>Estudo publicado em 2024 avaliou o risco de acidente vascular isquêmico em duas coortes nacionais, em franceses e dinamarqueses, portadores de AHAI primária. O risco foi maior nesses pacientes, principalmente no primeiro ano após o diagnóstico (HR 2,29 [IC95% -1,77-2,97], p < 10</mark><sup>-9</sup> <mark>) quando comparados com a população geral, mas ainda sem justificativa determinada</mark><sup>25</sup> <mark>.</mark>  
5

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **3.2. Diagnóstico laboratorial** -->
Pacientes com sintomas suspeitos de AHAI devem confirmar o diagnóstico através dos seguintes exames laboratoriais<sup>18,26</sup> :  
− Hemograma com contagem de plaquetas: deve evidenciar anemia caracterizada por hemoglobina abaixo de 13 g/dL em homens e abaixo de 12 g/dL em mulheres. Plaquetopenia concomitante (contagem total de plaquetas abaixo de 150.000/mm<sup>3</sup> ) associa-se à Síndrome de Evans;  
− Contagem de reticulócitos: caracteristicamente elevada (maior que 100.000 reticulócitos) na ausência de sangramento ativo, de correção recente de deficiências nutricionais ou do uso de alfapoetina<sup>27</sup> ;  
− Testes para comprovação de hemólise: aumento da desidrogenase láctica e redução dos níveis séricos de haptoglobina. A elevação das bilirrubinas total e indireta ocorre em pacientes com hemólise mais grave. Pelo menos um destes testes deve estar alterado para caracterizar hemólise, sendo a haptoglobina o mais sensível, se disponível;  
− Teste de Coombs direto (teste direto de antiglobulina): deve ser positivo, pois representa a confirmação de anticorpos ligados à superfície das hemácias. O resultado positivo indica possibilidade de mecanismo autoimune associado, diferenciado da hemólise não-imune. O teste deve ser, preferencialmente, poliespecífico para detectar os autoanticorpos da classe IgG e C3d para diferenciação do tipo de AHAI.  
Alguns autores propõem que quadros clínicos mais graves estão associados aos seguintes achados laboratoriais: hemoglobina menor que 9 g/dL, bilirrubina indireta maior que 2 mg/dl, contagem de reticulócitos maior que 2% e lactato desidrogenase maior que 500 UI/L<sup>22</sup> .  No entanto, de forma a contemplar também critérios clínicos, o Consenso Internacional em AHAI propôs como critérios de gravidade a hemoglobina inferior 8 g/dL e necessidade de suporte transfusional com concentrado de hemácias em intervalos inferiores a 7 dias. O tratamento dos casos graves inclui tratamento de suporte, semelhante aos quadros não graves<sup>22,28</sup> .  
De acordo com a faixa térmica de reatividade dos autoanticorpos, a AHAI pode ser classificada em quente, fria ou mista. Os autoanticorpos presentes devem ser adequadamente identificados por meio de exames complementares<sup>5,18</sup> :  
− O teste Coombs direto identifica qual o autoanticorpo ligado à superfície das hemácias: usualmente IgG ou C3d, por métodos com diferentes especificidades e sensibilidades. Assim, na AHAI quente, o exame usualmente revela IgG ligada às hemácias (IgG+) ou IgG+/C3d+. Nos casos de teste de Coombs direto negativo e sintomas sugestivos da doença, deve-se complementar com outro teste monoespecífico para avaliação da presença de autoanticorpos da classe IgM para caracterizar AHAI frio ou IgA para AHAI quente<sup>29</sup> ;  
- Na AHAI mista, encontra-se IgG+ ou IgG+/C3d+ ou C3d+ e IgM;  
- Pesquisa de autocrioaglutininas (crioaglutininas ou aglutinação a frio): é usualmente positiva nas AHAIs com  
- aglutininas a frio.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **3.3. Diagnóstico diferencial** -->
O diagnóstico diferencial a ser realizado compreende a AHAI e as demais causas de anemias macrocíticas hiperproliferativas que consistem em crises hemolíticas não mediadas por autoanticorpos, como acontece nas microangiopatias trombóticas, hemoglobinúria paroxística noturna ou esferocitose hereditária<sup>18</sup> .  
É necessário excluir outras causas conhecidas de hemólise, como reação transfusional, hemólise aloimune após transplante de órgão sólido ou de medula, hemólise induzida por medicamentos (com mecanismos fisiopatológicos diversos) ou doença hemolítica do recém-nascido, facilmente identificadas pela avaliação clínica. Além disso, é importante tratar comorbidades associadas, que podem cursar com algum grau de hemólise<sup>30</sup> .  
A **Figura 1** a seguir apresenta o fluxograma para investigação diagnóstica da AHAI.  
6  
**Figura 1** . Fluxograma de diagnóstico da AHAI  
<!-- Start of picture text -->
= [sintomas<br>[ Paciente com suspeita de anemia hemolitica autoimune (AHA!) } ——a de anemiaer  (dispnmo e ia, fadiga, babxatoleréncia<br>—_—_ WH _, |Exame fisico (palidez, ictericia e/ou esplenomegalia)<br>Hemoglobinaabatxo de 10. | Comprovacdo laboratorial de Teste de Coombs dato |<br>gidLe hemdlise e POSITIVO |<br>cae IgG+IC3d>IgG+ ou es)Plaquetopeniae-<br>maior<br>que 1:40?<br>sim crisesPresenca de Nae<br>de hemdlise<br>‘no fio?<br>“<br>Landsteiner= [nc|<br>Paroxistica—a fio =|<br><!-- End of picture text -->  
Legenda: *A presença de teste de Coombs com resultado NEGATIVO e com sintomas sugestivos da doença necessita investigação adicional de anticorpos IgA (AHAI quente) e IgM (AHAI fria).  
7

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: <u>Hemoglobinúria Paroxística a Frio</u> -->
A Hemoglobinúria Paroxística a Frio (HPF) é o subtipo mais raro de AHAI, com uma incidência anual estimada em 0,04 casos/100.000 pessoas<sup>3</sup> .  Historicamente, a HPF foi descrita como uma condição crônica em pacientes com sífilis terciária ou congênita que sofriam “paroxismos” de hemoglobinúria após exposição ao frio e reaquecimento posterior. Em virtude do significativo declínio da ocorrência de sífilis terciária, os raros casos relatados nos últimos anos estão mais frequentemente relacionados à hemólise intravascular e hemoglobinúria após infecções virais, especialmente em crianças. A patogênese resulta da formação do anticorpo bifásico de Donath-Landsteiner, um anticorpo IgG direcionado ao antígeno P da superfície da membrana eritrocitária. Este anticorpo ativa diretamente a cascata de complemento, causando hemólise intravascular. Os anticorpos geralmente aparecem cerca de uma semana após o início do quadro infeccioso e persistem por 1 a 3 meses. As crises são precipitadas quando há exposição ao frio e estão associadas a hemoglobinúria, calafrios, febre e dor abdominal e nos membros inferiores. A doença usualmente tem curso autolimitado<sup>3,31</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: <u>Síndrome de Evans</u> -->
A síndrome de Evans (SE) é uma doença incomum, com prevalência não bem definida, onde ocorre uma combinação de citopenias de causa autoimune, concomitantes ou consecutivas, mais frequentemente AHAI e púrpura trombocitopênica idiopática (PTI). A neutropenia é uma característica comum, presente em cerca de 55% dos pacientes na apresentação. A doença é geralmente crônica, podendo afetar adultos e crianças. A maioria dos casos é idiopática, mas vários relatos descrevem associação com imunodeficiências, doenças do colágeno, neoplasias hematológicas, após transplante alogênico de células-tronco hematopoiéticas (TCTH) e infecções. Outra causa importante de SE é a síndrome linfoproliferativa autoimune ( _Autoimmune Lymphoproliterative Syndrome_ - ALPS)<sup>1,28</sup> .  
A SE é caracterizada por períodos de remissão e exacerbação, com sintomas de letargia, icterícia, dispneia, petéquias, hematomas ou sangramento de mucosas. O exame físico pode revelar hepatoesplenomegalia e a realização de diagnóstico diferencial é essencial. Recomenda-se que os pacientes sejam avaliados para ALPS, por citometria de fluxo para avaliação das células T, sempre que disponível, e uma eventual avaliação da medula óssea pode ser necessária para excluir outras causas<sup>28</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: <u>Gravidez e Lactação:</u> -->
A AHAI é uma condição rara que pode causar complicações potencialmente graves em gestantes e recém-nascidos. As decisões médicas para essa população especial são baseadas em literatura com poucas evidências publicadas. Uma revisão com meta-análise publicada em 2021 avaliou as características clínicas e os desfechos maternos e neonatais em AHAI. Foi relatado que a AHAI é incomum em primigestas e ocorre com mais frequência em períodos posteriores da gestação. O aparecimento de sintomas no primeiro ou segundo trimestres e uma hemoglobina baixa estão associados a desfechos adversos, como parto prematuro e natimorto, em 33,3% dos casos.  Com maior frequência se observa o teste de Coombs direto com resultado negativo, associado a menor duração da hemólise no pós-parto. A incidência de hemólise nos recém-nascidos de mães com AHAI na gravidez é alta e clinicamente significativa, sendo comum a recorrência em gestações subsequentes<sup>32</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo todos os pacientes com sintomas sugestivos de AHAI e que preencherem os seguintes critérios:  
- Hemograma com anemia moderada ou grave (Hb abaixo de 10 g/dL); **e**  
- Teste de Coombs direto positivo*; **e**  
8  
- Comprovação laboratorial de hemólise demonstrada por reticulocitose (reticulócitos > 100.000) ou aumento de desidrogenase láctica ou aumento de bilirrubinas (acima dos limites superiores de normalidade) ou redução da haptoglobina (abaixo do limite inferior de normalidade).  
* A presença de testes de Coombs com resultado negativo e com sintomas sugestivos da doença necessita de investigação adicional, conforme descrito a seguir.  
Adicionalmente, para decisão terapêutica específica deve ser identificado o subtipo de AHAI. Serão considerados os critérios a seguir para definição do subtipo:  
- <u>Para AHAI quente: detecção do anticorpo ligado por anti-IgG ou IgG+/C3d+ (teste de Coombs positivo). Para casos de</u> AHAI com teste de Coombs negativo, que ocorre em até 10% dos pacientes, testes complementares são recomendados, incluindo a utilização de soro monoespecífico anti-IgA;  
- <u>Para AHAI fria</u> (doença das aglutininas a frio): detecção do complemento ligado por anti-C3d e pesquisa de crioaglutininas positiva com títulos acima de 1:40; o teste de Coombs direto pode ser negativo ou revelar C3d ligado às hemácias (IgG- ou C3d+), sugerindo a presença de anticorpo da classe IgM;  
- <u>Para hemoglobinúria paroxística a frio: apresentar anticorpo ligado por anti-IgG, com teste de Donath-Landsteiner</u> positivo.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento neste Protocolo deverão ser excluídos ao uso do respectivo medicamento preconizado.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Esplenectomia** -->
O tratamento de primeira linha da AHAI é baseado eminentemente em medicamentos. No entanto, em pacientes intolerantes ou refratários a essas terapias ou em casos mais graves (Hb menor ou igual a 7,0 mg/dL, por exemplo), a esplenectomia pode ser indicada como segunda ou terceira linhas de tratamento, ainda que sua eficácia não tenha sido comparada a outras alternativas em ensaios clínicos randomizados<sup>33</sup> . A esplenectomia potencialmente reduz o sequestro de hemácias previamente sensibilizadas e a produção de anticorpos pelo baço.  
Séries de casos de AHAI sugerem que 50% a 85% de taxa de resposta<sup>18</sup> . Entretanto, para avaliação de eficácia a longo prazo, não há evidências de boa qualidade disponíveis<sup>7</sup> . Recaídas podem ocorrer em cerca de um terço dos pacientes após a esplenectomia. Já os casos de AHAI secundária são menos responsivos à esplenectomia do que os casos idiopáticos e é fundamental tratar a doença de base associada. Embora muitos pacientes necessitem de corticoides após a realização da cirurgia, as doses são usualmente menores, com melhora clínica significativa<sup>4,28</sup> .  
A literatura em relação às crianças com AHAI que realizaram esplenectomia é mais escassa e a efetividade nesse subgrupo de pacientes não está claramente definida<sup>4</sup> .  
O risco de infecções, particularmente no primeiro ano pós-cirurgia, pode ser minimizado com o uso de antibióticos profiláticos e vacinação, tanto para adultos como para crianças<sup>28</sup> . A cirurgia deve ser evitada em crianças menores que 5 anos pelo risco aumentado de infecção potencialmente grave, não havendo consenso na preferência entre esplenectomia e o uso de  
9  
ciclofosfamida, mesmo em crianças maiores de 5 anos<sup>4,28</sup> . A esplenectomia não parece ser eficaz no tratamento da AHAI fria, já  
que a hemólise ocorre a nível intravascular e as hemácias sensibilizadas são majoritariamente removidas pelo fígado<sup>34</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Plasmaferese** -->
A plasmaferese pode ser usada como tratamento adjuvante para remover anticorpos IgM da circulação, reduzindo a gravidade da reação hemolítica em pacientes com AHAI fria aguda e grave, com indicação de nível de evidência categoria II e como segunda linha de tratamento. Para AHAI quente aguda grave, a plasmaferese é recomendada como terceira linha de tratamento, porém este tratamento ainda não está bem estabelecido e, por isso, o uso individualizado para cada paciente é recomendado. Estudos adicionais são necessários para que recomendações mais robustas possam ser realizadas. O efeito da plasmaferese tende a ser fugaz, pois o tempo médio necessário para a produção de novos anticorpos é de, aproximadamente, 3 a 5 dias, o que dificulta seu uso no tratamento crônico. Por isso, este tratamento parece ser benéfico para o controle a curto prazo da AHAI aguda grave. Além disso, este procedimento necessita de preparo especial, como ambiente aquecido e aquecimento do sangue durante a fase extracorpórea. A plasmaferese deve ser reservada para casos de hemólise e anemia grave (hemoglobina abaixo de 7 g/dL) e para pacientes com sintomas neurológicos associados<sup>1,7,27</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **6.2. Tratamento medicamentoso** -->
O tratamento medicamentoso tem por objetivo principal reduzir a hemólise e elevar os níveis de hemoglobina, com consequente alívio dos sintomas. Nos casos de AHAI secundária, é fundamental identificar e tratar a doença de base associada.  
A correta identificação do tipo de AHAI é essencial no planejamento terapêutico, uma vez que o tratamento e o curso da doença são distintos.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **AHAI quente** -->
Na AHAI quente, os glicocorticoides constituem a primeira linha de tratamento. Diversas séries de casos demonstraram que a maior parte dos pacientes apresentou melhora clínica na primeira semana de tratamento, sendo que 80% a 90% responderam à terapia nas três primeiras semanas<sup>14,17,28,35,36</sup> . Pacientes que não apresentaram resposta nesse período dificilmente obterão benefício com tempo maior de uso<sup>35</sup> . O corticoide mais empregado no tratamento da AHAI é a prednisona. Entretanto, no tratamento de pacientes com anemia mais grave (hemoglobina abaixo de 7 g/dL), pode-se optar pela pulsoterapia com metilprednisolona<sup>28</sup> .  
Iniciar o tratamento com corticoides de uso parenteral em diferentes esquemas pode proporcionar uma resposta mais rápida, sugerindo que o tratamento parenteral seja usado como terapia de resgate em casos de emergência e em pacientes mais graves ou instáveis. Em caso de refratariedade ao tratamento ou recidiva frequente, com necessidade de uso continuado de corticoides, está indicada a implementação de terapia de segunda linha, com esplenectomia ou o uso de um agente imunossupressor<sup>6,20,37</sup> .  
Os imunossupressores reduzem a produção de anticorpos, com taxas de resposta que variam entre 40% a 60%. Estão indicados em casos de refratariedade aos corticoides ou à esplenectomia, o que fica caracterizado pela persistência de hemólise e hemoglobina abaixo de 10 g/dL, na vigência do tratamento<sup>10</sup> . O início do efeito ocorre usualmente entre um e quatro meses, podendo um medicamento ser substituído por outro na ausência de resposta<sup>37</sup> .  
Vários autores indicam suplementação concomitante com ácido fólico no curso da AHAI, uma vez que o consumo medular dessa vitamina aumenta em razão da maior eritropoiese secundária às crises hemolíticas. A deficiência de ácido fólico pode desencadear alterações megaloblásticas na produção de hemácias, impedindo respostas clínica e laboratorial adequadas. Poucos estudos clínicos controlados abordam essa peculiaridade no tratamento da doença, sendo a maior parte das evidências provenientes de série de casos<sup>9,10,38–41</sup> .  
O anticorpo monoclonal anti-CD20 rituximabe tem sido usado em monoterapia ou associado com glicocorticoides e  
10  
imunossupressores no tratamento da AHAI refratária à corticoterapia<sup>34,42</sup> . As evidências sugerem que a associação de rituximabe e glicocorticoide pode aumentar a taxa de resposta hematológica completa em comparação com os glicocorticoides em monoterapia<sup>43,44</sup> . No entanto, esse medicamento não está aprovado pela ANVISA para esta indicação e não foi avaliado pela Conitec, motivo pelo qual não está recomendado neste Protocolo<sup>15</sup> .  
A ciclofosfamida é o medicamento citotóxico mais comumente utilizado nos pacientes refratários a corticoides. Inexistem estudos clínicos randomizados avaliando seu uso em pacientes com AHAI, porém sua eficácia foi documentada em séries de casos<sup>38,45–47</sup> .  
Outro imunossupressor é a ciclosporina, no entanto, os estudos sobre o uso deste medicamento na AHAI são muito escassos, predominando pequenas séries de casos. A vantagem do uso de ciclosporina é sua boa tolerabilidade e baixa toxicidade. Além disso, trata-se de um medicamento com resultados promissores no tratamento da síndrome de Evans<sup>39,40</sup> .  
A imunoglobulina humana é ocasionalmente efetiva para pacientes que não responderam ao tratamento ou para aqueles com anemia grave de rápida evolução e risco iminente de óbito. Não há estudos controlados sobre esse medicamento e, portanto, não há recomendação formal do seu uso como primeira linha de tratamento<sup>48</sup> . Uma série de casos relatada por Flores<sup>41</sup> demonstrou resposta em somente um terço dos pacientes que usaram imunoglobulina, sendo o medicamento recomendado apenas para casos graves com níveis de hemoglobina muito baixos (hemoglobina abaixo de 7 g/dL). Seu uso está recomendado para pacientes idosos sem indicação de esplenectomia, os quais não respondem aos demais medicamentos; ou ainda, para pacientes com complicações clínicas associadas e anemia grave com risco de morte<sup>49</sup> . Para os casos cuja resposta é transitória, podem ser necessários cursos de imunoglobulina a cada três semanas<sup>50</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **AHAI fria** -->
Na AHAI fria o tratamento é feito basicamente com a proteção contra o frio. Na forma primária, as taxas de resposta ao tratamento são baixas, geralmente inferiores a 20%. A indicação de tratamento medicamentoso é baseada nos casos com maior prejuízo na qualidade de vida, geralmente com imunossupressores ou agentes citotóxicos. Outra modalidade terapêutica a ser considerada em alguns cenários é a plasmaférese. Corticoides e esplenectomia não são efetivos nesse subtipo de AHAI. Nas formas secundárias, o tratamento indicado é o da doença de base<sup>42</sup> .  
Medicamentos citotóxicos como a ciclofosfamida e o clorambucil são úteis para a redução da produção de autoanticorpos, mas com papel restrito à forma primária da doença e nos casos de pacientes muito sintomáticos, nos quais a proteção ao frio não é eficaz. Ambos têm magnitude de efeito baixa. Os relatos de casos tratados com clorambucil evidenciaram uma utilização clínica prejudicada pela toxicidade associada, não sendo indicada neste Protocolo<sup>31,42,46</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **6.3. Medicamentos** -->
- Ácido fólico: comprimidos de 5 mg e solução oral de 0,2 mg/mL.  
- Ciclofosfamida: comprimidos de 50 mg; pó para solução injetável de 1.000 mg e 200 mg.  
- Ciclosporina: cápsulas de 10 mg, 25 mg, 50 mg e 100 mg; solução oral de 100 mg/mL.  
- Imunoglobulina humana: pó para solução injetável ou solução injetável de 0,5 g, 1,0 g, 2,5 g e 5,0 g.  
- Metilprednisolona: pó para solução injetável 500 mg.  
- Prednisona: comprimidos de 5 mg e 20 mg.  
Nota: Os medicamentos metilprednisolona e ciclofosfamida pó para solução injetável de 200 mg e 100 mg estão contemplados nos procedimentos de pulsoterapia, sendo seu fornecimento de responsabilidade do serviço, não sendo dispensados no âmbito da Assistência Farmacêutica.  
11

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **6.4. Esquemas de administração** -->
- Ácido Fólico: 5 a 10 mg/dia, por via oral, 1 vez ao dia.  
- Ciclofosfamida: 100 mg/dia, por via oral, ou 500 a 700 mg, por via intravenosa a cada 4 a 6 semanas. Para crianças, a  
- dose preconizada é de 2 mg/kg.  
- Ciclosporina: 5 a 10 mg/kg/dia, por via oral, divididos em 2 doses diárias.  
- Imunoglobulina humana: 400 a 1.000 mg/kg/dia, por via intravenosa, por 5 dias. A manutenção pode ser necessária e é  
- feita a cada 21 dias.  
- Metilprednisolona: 100 a 200 mg/dia por até 14 dias. Para o tratamento da síndrome de Evans, inicia-se habitualmente com 1 mg/kg com o objetivo de elevar os níveis hemoglobina acima de 10 g/dL e as plaquetas acima 50.000/mm<sup>3</sup> , realizando posteriormente redução lenta da dose.  
- Prednisona: dose inicial de 1 mg/kg/dia para adultos. Para criança, a dose pode ser superior (1 a 2 mg/kg/dia). Quando os níveis de hemoglobina se encontram acima de 10 g/dL, as doses de prednisona podem ser reduzidas para 0,5 mg/kg/dia após 2 semanas. Mantendo-se controlados os níveis de hemoglobina, a prednisona deve ser diminuída lentamente no período de 3 meses<sup>37</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **6.5.     Tempo de tratamento e critérios de interrupção** -->
Os pacientes com AHAI que evoluírem com quadro crônico apresentarão períodos de remissão e recidiva. O tratamento deve ser instituído quando os pacientes apresentarem crise hemolítica e desenvolverem anemia, conforme orientação<sup>1,37</sup> .  
A retirada dos corticoides deve ser feita de acordo com as recomendações propostas. Os pacientes refratários a estes medicamentos e à esplenectomia necessitam, normalmente, de agentes imunossupressores por longo tempo e a sua interrupção pode ser tentada após o alcance de resposta sustentada por, pelo menos, 6 meses.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: <u>Hemoglobinúria Paroxística a Frio</u> -->
O tratamento é geralmente de suporte, uma vez que a doença, na maioria das vezes, tem comportamento transitório e autolimitado. Nos últimos 20 anos, 88% dos pacientes relatados com HPF tiveram sua doença resolvida em uma média de 14 dias, sem intervenção específica. Entretanto, em alguns casos, geralmente os mais graves, o tratamento pode se mostrar benéfico. Considerando que o mecanismo autoimune básico é dependente da produção de IgG, a prednisona é a primeira linha de tratamento. A proteção contra o frio também está recomendada neste subtipo de AHAI. Caso não haja remissão com o uso de prednisona em doses de 1 mg/kg/dia, uma alternativa terapêutica para pacientes com hemólise persistente e hemoglobina abaixo de 10 g/dL é a ciclofosfamida. Embora o tratamento mais eficaz para HPF esteja em investigação, propõem-se o uso de inibidores do complemento para pacientes com doença grave e refratária. A esplenectomia não está indicada nesta situação, uma vez que a hemólise é primordialmente intravascular<sup>2,3</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: <u>Síndrome de Evans</u> -->
O melhor tratamento para SE não está estabelecido, uma vez que essa é uma condição rara e a literatura está limitada a relatos de casos e estudos retrospectivos, com número pequeno de pacientes<sup>51–53</sup> . De maneira geral, são preconizados os mesmos medicamentos utilizados para o tratamento de AHAI ou PTI, como corticoterapia ou imunoglobulina humana intravenosa como primeira linha de tratamento e rituximabe, ciclospoprina e danazol como segunda ou terceira linhas<sup>51,54–56</sup> .Contudo, considerando as esparsas evidências encontradas, que não existe essa indicação em bula e que os medicamentos não foram avaliados pela Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), os medicamentos danazol e rituximabe não estão preconizados neste Protocolo.  
12  
A revisão das evidências do medicamento danazol para SE está descrita no Apêndice 1.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: <u>Gravidez e Lactação:</u> -->
O uso de corticoides e as transfusões de concentrado de hemácias são necessários na maioria dos casos, com hemólise  
persistente por até 6 semanas após o parto.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **6.7. Benefícios esperados** -->
- Redução do grau de hemólise;  
- Elevação dos níveis de hemoglobina;  
- Melhora dos sintomas anêmicos;  
- Aumento da contagem plaquetária (nos casos de Síndrome de Evans); e  
- Melhora dos sintomas hemorrágicos (nos casos de Síndrome de Evans).

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **MONITORAMENTO** -->
O monitoramento deve ser feito a fim de estabelecer a presença e o grau de hemólise e avaliar a resposta ao tratamento, bem como monitorar manifestações de toxicidade dos medicamentos.  
Os testes laboratoriais mais úteis para verificar a presença de hemólise são hemograma com contagem de plaquetas, dosagem de desidrogenase láctica, contagem de reticulócitos, dosagem de bilirrubinas e de haptoglobina. Os níveis de hemoglobina devem ser mantidos acima de 10 g/dL para garantir melhora significativa dos sintomas anêmicos. Em pacientes idosos ou com comorbidades que diminuam sua capacidade funcional, a hemoglobina deve ser mantida em níveis que aliviem os sintomas apresentados<sup>57</sup> .  
Em relação à toxicidade dos medicamentos utilizados para o tratamento, devem ser monitorizados os seguintes parâmetros:

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Glicocorticoides (prednisona ou metilprednisolona)** -->
Antes do início do tratamento, os pacientes devem ser avaliados quanto à glicemia de jejum, potássio, colesterol total, triglicerídeos e pressão arterial. Durante o uso de corticoides, os pacientes devem ser monitorizados clínica e laboratorialmente a cada 3 meses, conforme critério médico ou sempre que houver alguma alteração dos parâmetros monitorados. Hipertensão arterial deve ser tratada com anti-hipertensivos. Hiperglicemia deve ser tratada com dieta e, se necessário, com antidiabéticos orais ou insulina; hipopotassemia, com reposição de cloreto de potássio oral (600 a 1.200 mg/dia).

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Ciclofosfamida** -->
Deve ser realizado hemograma com contagem de plaquetas semanalmente no primeiro mês, quinzenalmente no segundo e terceiro meses e, após, mensalmente ou se houver mudança nas doses do medicamento. Também deve ser realizado controle de provas hepáticas (ALT/TGP, AST/TGO, GGT e bilirrubinas), na mesma periodicidade dos hemogramas nos primeiros 6 meses e depois, trimestralmente. Em caso de surgimento de neutropenia (abaixo de 1.500 células/mm<sup>3</sup> ), a dose do medicamento deve ser reduzida em 50%.  
Caso o paciente apresente elevação das enzimas hepáticas (qualquer valor acima do limite superior da normalidade) deve interromper temporariamente o seu uso. Após a normalização das enzimas hepáticas, deve reiniciar o tratamento com redução de 50% da dose de ciclofosfamida.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Ciclosporina** -->
Os níveis séricos do medicamento devem ser monitorizados regularmente, mantendo o nadir entre 100 e 200 mg/mL. A aferição da pressão arterial sistêmica e a avaliação da função renal (creatinina) devem ser feitas antes do início do tratamento e  
13  
repetidas a cada duas semanas nos primeiros 3 meses de tratamento. Após esse período, caso o paciente esteja clinicamente estável, os exames podem ser realizados mensalmente. Se houver desenvolvimento de hipertensão, deve-se reduzir a dose de ciclosporina em 25% a 50%. Persistindo a alteração, o tratamento deve ser interrompido.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Imunoglobulina humana** -->
Os pacientes podem apresentar eventos adversos relacionados à infusão (febre, náusea, vômitos). A infusão do medicamento deve ser interrompida ou suspensa se ocorrerem quaisquer destes sintomas. Este medicamento deve ser usado com cuidado em pacientes que tenham maior risco de perda de função renal (idosos, doença renal prévia, diabete melito, sepse), por existirem relatos de casos de indução de insuficiência renal aguda. Para o monitoramento destes eventos adversos, devem ser realizados exames laboratoriais (nível sérico de creatinina, hemograma) e avaliação clínica de eventos adversos relacionados à infusão e ao débito urinário.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão descritos neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamentos prescritas e dispensadas e a adequação de uso, além do acompanhamento durante o tratamento. Pacientes com AHAI devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras. (Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS nº 2, de 28 de setembro de 2017, e Portaria de Consolidação GM/MS nº 6, de 28 de setembro de 2017.  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Básica e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Básica é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da atenção básica.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o locus da atenção à saúde dos pacientes com doenças raras.  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no  
- mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
14  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS, e se houver necessidade o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade, e a linha de cuidados de pacientes com Doenças Raras é estruturada pela Atenção Básica e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com AHAI deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Verificar, na Relação Nacional de Medicamentos Essenciais (RENAME) vigente, em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde, via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **REFERÊNCIAS** -->
1. Engelfriet CP, Overbeeke MA, von dem Borne AE. Autoimmune hemolytic anemia. Semin Hematol. 1992 Jan;29(1):3– 12.  
2. Gertz MA. Management of cold haemolytic syndrome. Br J Haematol. 2007 Aug;138(4):422–9.  
3. Jacobs JW, Villalba CAF, Booth GS, Woo JS, Stephens LD, Adkins BD. Clinical and epidemiological features of paroxysmal cold hemoglobinuria: a systematic review. Blood Adv. 2023 Jun 13;7(11):2520–7.  
4. Ladogana S, Maruzzi M, Samperi P, Condorelli A, Casale M, Giordano P, et al. Second-line therapy in paediatric warm autoimmune haemolytic anaemia. Guidelines from the Associazione Italiana Onco-Ematologia Pediatrica (AIEOP). Vol. 16, Blood Transfusion. Edizioni SIMTI; 2018. p. 352–8.  
5. Ladogana S, Maruzzi M, Samperi P, Perrotta S, Del Vecchio GC, Notarangelo LD, et al. Diagnosis & management of newly diagnosed childhood autoimmune haemolytic anaemia. Recommendations from the red cell study group of the paediatric haemato-oncology Italian association. Blood Transfusion. 2017 May 1;15(3):259–67.  
6. Abdallah GEM, Abbas WA, Elbeih EAS, Abdelmenam E, Mohammed Saleh MF. Systemic corticosteroids in the treatment of warm autoimmune hemolytic anemia: A clinical setting perspective. Blood Cells Mol Dis. 2021 Dec 1;92.  
15  
7. Deng J, Zhou F, Wong CY, Huang E, Zheng E. Efficacy of therapeutic plasma exchange for treatment of autoimmune hemolytic anemia: A systematic review and meta-analysis of randomized controlled trials. J Clin Apher. 2020 Aug;35(4):294–306.  
8. Berentsen S, Barcellini W, D’Sa S, Randen U, Tvedt THA, Fattizzo B, et al. Cold agglutinin disease revisited: a multinational, observational study of 232 patients. Blood. 2020 Jul 23;136(4):480–8.  
9. Berentsen S, Beiske K, Tjønnfjord GE. Primary chronic cold agglutinin disease: An update on pathogenesis, clinical features and therapy. Vol. 12, Hematology. 2007. p. 361–70.  
10. Packman CH. Hemolytic anemia due to warm autoantibodies: new and traditional approaches to treatment. Clin Adv Hematol Oncol. 2008 Oct;6(10):739–41.  
11. Jafarzadeh A, Jafarzadeh S, Pardehshenas M, Nemati M, Mortazavi SMJ. Development and exacerbation of autoimmune hemolytic anemia following COVID-19 vaccination: A systematic review. Vol. 45, International Journal of Laboratory Hematology. John Wiley and Sons Inc; 2023. p. 145–55.  
12. Jacobs JW, Booth GS. COVID-19 and Immune-Mediated RBC Destruction. Am J Clin Pathol [Internet]. 2022;157(6):844–51. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L2018847621&from=export  
13. Taherifard E, Taherifard E, Movahed H, Mousavi MR. Hematologic autoimmune disorders in the course of COVID-19: a systematic review of reported cases. Hematology (United Kingdom) [Internet]. 2021;26(1):225–39. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L2010524761&from=export  
14. Hill QA, Stamps R, Massey E, Grainger JD, Provan D, Hill A. Guidelines on the management of drug-induced immune and secondary autoimmune, haemolytic anaemia. Vol. 177, British Journal of Haematology. Blackwell Publishing Ltd; 2017. p. 208–20.  
15. Liu AP yin, Cheuk DKL. Disease-modifying treatments for primary autoimmune haemolytic anaemia. Vol. 2021, Cochrane Database of Systematic Reviews. John Wiley and Sons Ltd; 2021.  
16. MINISTÉRIO DA SAÚDE DIRETRIZES METODOLÓGICAS ELABORAÇÃO DE DIRETRIZES CLÍNICAS [Internet]. Available from: www.gov.br/conitec/pt-br/  
17. Pirofsky B. Immune haemolytic disease: the autoimmune haemolytic anaemias. Clin Haematol. 1975 Feb;4(1):167–80.  
18. Hill QA, Stamps R, Massey E, Grainger JD, Provan D, Hill A. The diagnosis and management of primary autoimmune haemolytic anaemia. Vol. 176, British Journal of Haematology. Blackwell Publishing Ltd; 2017. p. 395–411.  
19. Hill QA, Hill A, Berentsen S. Defining autoimmune hemolytic anemia: A systematic review of the terminology used for diagnosis and treatment. Vol. 3, Blood Advances. American Society of Hematology; 2019. p. 1897–906.  
20. Petz LD. Autoimmune hemolytic anemia. Hum Pathol. 1983 Mar;14(3):251–5.  
21. Gibson J. Autoimmune hemolytic anemia: current concepts. Aust N Z J Med. 1988 Jun;18(4):625–37.  
22. Mulder FVM, Evers D, de Haas M, Cruijsen MJ, Bernelot Moens SJ, Barcellini W, et al. Severe autoimmune hemolytic anemia; epidemiology, clinical management, outcomes and knowledge gaps. Front Immunol [Internet]. 2023;14. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L2025847825&from=export  
23. Saad MA, Alfishawy M, Nassar M, Mohamed M, Esene IN, Elbendary A. Covid-19 and autoimmune diseases: A systematic review of reported cases. Curr Rheumatol Rev [Internet]. 2021;17(2):193–204. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L2007385691&from=export  
24. Berentsen S, Barcellini W. Autoimmune Hemolytic Anemias. Longo DL, editor. New England Journal of Medicine [Internet]. 2021 Oct 7;385(15):1407–19. Available from: http://www.nejm.org/doi/10.1056/NEJMra2033982  
16  
25. Hansen DL, Maquet J, Lafaurie M, Möller S, Berentsen S, Frederiksen H, et al. Primary autoimmune haemolytic anaemia is associated with increased risk of ischaemic stroke: A binational cohort study from Denmark and France. Br J Haematol. 2024 Mar;204(3):1072–81.  
26. Michel M. Autoimmune and Intravascular Hemolytic Anemias. In: Goldman LMM, editor. Goldman-Cecil Medicine, Twenty Seventh Edition. 27th ed. Copyright © 2024 by Elsevier Inc. All rights reserved.; 2024. p. 1086–92.  
27. Brugnara C, Brodsky R. Warm autoimmune hemolytic anemia (AIHA) in adults. UpToDate®. 2024.  
28. Jäger U, Barcellini W, Broome CM, Gertz MA, Hill A, Hill QA, et al. Diagnosis and treatment of autoimmune hemolytic anemia in adults: Recommendations from the First International Consensus Meeting. Vol. 41, Blood Reviews. Churchill Livingstone; 2020.  
29. Pirofsky B, Bardana EJ. Autoimmune hemolytic anemia. II. Therapeutic aspects. Ser Haematol. 1974;7(3):376–85.  
30. Hill A, Hill QA. | HEMOLYTIC ANEMIA: A CORNUCOPIA OF CAUSES | [Internet]. Available from: http://ashpublications.org/hematology/article-pdf/2018/1/382/1253494/hem01853.pdf  
31. Rosse WF, Adams JP. The variability of hemolysis in the cold agglutinin syndrome. Blood. 1980 Sep;56(3):409–16.  
32. Murakhovskaya I, Anampa J, Nguyen H, Sadler V, Billett HH. Pregnancy-associated autoimmune hemolytic anemia: Meta-analysis of clinical characteristics, maternal and neonatal outcomes. Blood [Internet]. 2021;138(SUPPL 1):1959. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L637602036&from=export  
33. Crowther M, Chan YLT, Garbett IK, Lim W, Vickers MA, Crowther MA. Evidence-based focused review of the treatment of idiopathic warm immune hemolytic anemia in adults. Blood. 2011 Oct 13;118(15):4036–40.  
34. Crowther M, Chan YLT, Garbett IK, Lim W, Vickers MA, Crowther MA. Evidence-based focused review of the treatment of idiopathic warm immune hemolytic anemia in adults. Blood. 2011 Oct 13;118(15):4036–40.  
35.  
- Pirofsky B. Clinical aspects of autoimmune hemolytic anemia. Semin Hematol. 1976 Oct;13(4):251–65.  
36. Zupańska B, Lawkowicz W, Górska B, Kozłowska J, Ochocka M, Rokicka-Milewska R, et al. Autoimmune haemolytic anaemia in children. Br J Haematol. 1976 Nov;34(3):511–20.  
37.  
- Packman CH. Hemolytic anemia due to warm autoantibodies. Blood Rev. 2008 Jan;22(1):17–31.  
38. Ferrara F, Copia C, Annunziata M, di Noto R, Russo C, Palmieri S, et al. Complete remission of refractory anemia following a single high dose of cyclophosphamide. Ann Hematol. 1999 Feb;78(2):87–8.  
39. Emilia G, Messora C, Longo G, Bertesi M. Long-term salvage treatment by cyclosporin in refractory autoimmune haematological disorders. Br J Haematol. 1996 May;93(2):341–4.  
40. Dündar S, Ozdemir O, Ozcebe O. Cyclosporin in steroid-resistant auto-immune haemolytic anaemia. Acta Haematol. 1991;86(4):200–2.  
41. Flores G, Cunningham-Rundles C, Newland AC, Bussel JB. Efficacy of intravenous immunoglobulin in the treatment of autoimmune hemolytic anemia: results in 73 patients. Am J Hematol. 1993 Dec;44(4):237–42.  
42. Berentsen S, Tjønnfjord GE. Diagnosis and treatment of cold agglutinin mediated autoimmune hemolytic anemia. Blood Rev. 2012 May;26(3):107–15.  
43. Chao SH, Chang YL, Yen JC, Liao HT, Wu TH, Yu CL, et al. Efficacy and safety of rituximab in autoimmune and microangiopathic hemolytic anemia: A systematic review and meta-analysis. Exp Hematol Oncol [Internet]. 2020;9(1). Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L631485405&from=export  
44. Michel M, Terriou L, Roudot-Thoraval F, Hamidou M, Ebbo M, Le Guenno G, et al. A randomized and double-blind controlled trial evaluating the safety and efficacy of rituximab for warm auto-immune hemolytic anemia in adults (the RAIHA study). Am J Hematol [Internet]. 2017;92(1):23–7. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L613594282&from=export  
17  
45. Gehrs BC, Friedberg RC. Autoimmune hemolytic anemia. Am J Hematol. 2002 Apr;69(4):258–71.  
46. Moyo VM, Smith D, Brodsky I, Crilley P, Jones RJ, Brodsky RA. High-dose cyclophosphamide for refractory autoimmune hemolytic anemia. Blood. 2002 Jul 15;100(2):704–6.  
47. Panceri R, Fraschini D, Tornotti G, Masera G, Locasciulli A, Bacigalupo A. Successful use of high-dose cyclophosphamide in a child with severe autoimmune hemolytic anemia. Haematologica. 1992;77(1):76–8.  
48. Consensus statement from the U.S. National Institutes of Health (NIH). Intravenous immunoglobulin: prevention and treatment of disease. Int J Technol Assess Health Care. 1991;7(4):643.  
49. Majer R V, Hyde RD. High-dose intravenous immunoglobulin in the treatment of autoimmune haemolytic anaemia. Clin Lab Haematol. 1988;10(4):391–5.  
50. Salama A, Mahn I, Neuzner J, Graubner M, Mueller-Eckhardt C. IgG therapy in autoimmune haemolytic anaemia of warm type. Blut. 1984 Jun;48(6):391–2.  
51. Jaime-Pérez JC, Guerra-Leal LN, López-Razo ON, Méndez-Ramírez N, Gómez-Almaguer D. Experience with Evans syndrome in an academic referral center. Rev Bras Hematol Hemoter. 2015;37(4):230–5.  
52. Fattizzo B, Michel M, Giannotta JA, Hansen DL, Arguello M, Sutto E, et al. Evans syndrome in adults: an observational multicenter study. Blood Adv. 2021 Dec 28;5(24):5468–78.  
53. Michel M, Chanet V, Dechartres A, Morin AS, Piette JC, Cirasino L, et al. The spectrum of Evans syndrome in adults: new insight into the disease based on the analysis of 68 cases. Blood. 2009 Oct 8;114(15):3167–72.  
54. Michel M, Chanet V, Dechartres A, Morin AS, Piette JC, Cirasino L, et al. The spectrum of Evans syndrome in adults: new insight into the disease based on the analysis of 68 cases. Blood. 2009 Oct 8;114(15):3167–72.  
55. Chemlal K, Wyplosz B, Grange MJ, Lassoued K, Clauvel JP. Salvage therapy and long-term remission with danazol and cyclosporine in refractory Evan’s syndrome. Am J Hematol. 1999 Nov;62(3):200.  
56. Letchumanan P, Thumboo J. Danazol in the treatment of systemic lupus erythematosus: a qualitative systematic review. Semin Arthritis Rheum. 2011 Feb;40(4):298–306.  
57. Zupańska B, Sylwestrowicz T, Pawelski S. The results of prolonged treatment of autoimmune haemolytic anaemia. Haematologia (Budap). 1981 Dec;14(4):425–33.  
18  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE  
ÁCIDO FÓLICO, CICLOFOSFAMIDA, CICLOSPORINA, IMUNOGLOBULINA HUMANA, METILPREDNISOLONA E PREDNISONA  
Eu, _______________________________________________________________________________________(nome  
do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de ácido fólico, ciclofosfamida, ciclosporina, imunoglobulina humana, metilprednisolona e prednisona indicados para o tratamento da anemia hemolítica autoimune.  
|Os<br>termos|médicos|foram|explicados|e<br>todas|as<br>dúvidas|foram|esclarecidas|pelo(a)|médico(a)|
|---|---|---|---|---|---|---|---|---|---|
|_________________|_________|_______|___________|_________|_____________|_______|____________|________|___ (nome|
|do(a) médico(a) que|prescreve).|||||||||  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Redução da hemólise, com elevação dos níveis de hemoglobina e melhora dos sintomas.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Ciclosporina e imunoglobulina: medicamento classificado na gestação como fator de risco C (estudos em animais  
- mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos, portanto, caso engravide, devo avisar imediatamente o médico;  
- Prednisona: medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram  
- anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- Ciclofosfamida: medicamentos classificados na gestação como fator de risco X (seu uso é contraindicado para gestantes  
- ou para mulheres planejando engravidar);  
- Eventos adversos da ciclofosfamida: náusea, vômitos, queda de cabelo, risco aumentado de infecções, diminuição do  
- número de células brancas no sangue, anemia, infecções da bexiga acompanhada ou não de sangramento;  
- Eventos adversos da ciclosporina: problemas nos rins e no fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, crescimento da gengiva, aumento do colesterol e triglicerídeos, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas;  
- Eventos adversos da imunoglobulina humana: dor de cabeça, calafrios, febre, reações no local de aplicação da injeção (dor, coceira e vermelhidão), problemas renais (aumento dos níveis de creatinina e ureia no sangue, insuficiência renal aguda, necrose tubular aguda, nefropatia tubular proximal, nefrose osmótica);  
- Eventos adversos da prednisona: alterações nos ossos e músculos: fraqueza, perda de massa muscular, osteoporose, além de ruptura do tendão, lesões de ossos longos e vértebras; alterações hidroeletrolíticas: inchaço, aumento da pressão arterial; alterações no estômago e intestino: sangramento; alterações na pele: demora em cicatrizar machucados, suor em excesso, petéquias e equimoses, urticária e até dermatite alérgica; alterações no sistema nervoso: convulsões, tontura; dor de cabeça; alterações nas glândulas: irregularidades  
menstruais, manifestação de diabete melito; alterações nos olhos: catarata, aumento da pressão dentro dos olhos; alterações psiquiátricas: alterações do humor; depressão e dificuldade para dormir;  
19  
Estou ciente de que o(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvê-lo(s)  
caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (  ) Sim (  ) Não  
O meu tratamento constará do (s) seguinte(s) medicamento(s):  
- (  ) ácido fólico  
- (  ) ciclofosfamida  
- (  ) ciclosporina  
- (  ) imunoglobulina humana  
- (  ) prednisona  
- (  ) metilprednisolona  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_________________________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:<br>____________________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Nota 2: A administração endovenosa de metilprednisolona e de ciclofosfamida é compatível, respectivamente, com os procedimentos 03.03.02.0016 - Pulsoterapia I (por aplicação) e 03.03.02.002-4 - Pulsoterapia II (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
Nota 3: O seguinte medicamento integra procedimento hospitalar da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS: 06.03.02.005-4 Ciclosporina 50 mg injetável (por frasco-ampola).  
20

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Anemia Hemolítica Autoimune (AHAI) contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos, fundamentos para a tomada de decisão, tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por metodologistas e especialista hematologista sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia, Inovação e do Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A reunião de escopo para atualização do PCDT de AHAI foi realizada no dia 13 de outubro de 2022. Posteriormente, no dia 18 de janeiro de 2023, foi realizada reunião para análise das evidências científicas sobre o uso da azatioprina, do danazol e do rituximabe para tratamento da doença. A partir das evidências científicas avaliadas decidiu-se pela não avaliação dessas tecnologias para possível incorporação por causa da escassez de evidências para viabilizar a elaboração de relatórios de avaliação. Portanto, nesta atualização foi realizada a atualização de conteúdo.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: Colaboração externa -->
O Protocolo foi atualizado pelo NATS do Hospital das Clínicas de Porto Alegre.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a  
Declaração de Potenciais Conflitos de Interesse (Quadro A).  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeirament|e algum dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim|  
21  
||(   ) Não|
|---|---|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de<br>alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Etapas do processo de elaboração** -->
A proposta inicial de atualização do PCDT de Anemia Hemolítica Autoimune foi inicialmente discutida durante a reunião de pré-escopo, ocorrida em 29 de agosto de 2022. A reunião teve a presença de metodologistas e especialista do Grupo Elaborador, e representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS) e da Secretaria de Atenção Especializada em Saúde (SAES).  
22  
Posteriormente, o escopo do documento foi discutido em reunião, ocorrida em 13 de outubro de 2022. A reunião teve a presença de metodologistas e especialista do Grupo Elaborador e representantes da SECTICS.  
Durante a reunião de escopo, verificou-se que os medicamentos rituximabe (para o tratamento de 2ª linha para anemia a quente e 1ª linha para anemia a frio), danazol (para o tratamento da Sindrome de Evans) e azatioprina poderiam ser potenciais tecnologias a ser avaliadas para incorporação ao Sistema Único de Saúde.  
Contudo, uma vez que os medicamentos danazol e rituximabe não possuem indicação de uso aprovada pela Agência Nacional de Vigilância Sanitária, para a definição das perguntas de pesquisa, foram revisadas evidências, diretrizes internacionais e pareceres de agências de ATS para subsidiar o desenvolvimento de perguntas de pesquisa.  
Em 18 de janeiro de 2023, a síntese dessas evidências científicas foi discutida pelos metodologistas, especialista do Grupo Elaborador e representantes da SECTICS. As evidências para os medicamentos danazol e azatioprina mostraram-se escassas e frágeis. Em relação ao rituximabe, verificou-se a fragilidade das evidências para as duas questões clínicas priorizadas: para o tratamento de 2ª linha para anemia a quente e 1ª linha para anemia a frio.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Anemia Hemolítica Autoimune foi apresentada na 117ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em julho de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 19ª Reunião Extraordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Consulta pública** -->
A Consulta Pública nº 51/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Anemia Hemolítica Autoimune, foi realizada entre os dias 26/08/2024 e 16/09/2024. Foram recebidas 22 contribuições, que podem ser verificadas em:https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/contribuicao-da-cp-51-de-2024-pcdt-anemia- <u>hemolitica</u>

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>16</sup> .  
Assim, em relação às diretrizes clínicas para a doença e para as tecnologias já disponíveis no PCDT, foi realizada uma busca nas bases de dados (Pubmed e Embase), compreendendo o período de 18 de março de 2017 até 20 de março de 2024, considerando a seguinte questão:  
**Questão 1 – Quais são as evidências, na forma de estudos clínicos, revisões sistemáticas e diretrizes, protocolos ou recomendações clínicas, sobre aspectos de diagnóstico, seguimento, cuidados e tratamento dos pacientes com AHAI, produzidas a partir de 2018?**  
A pergunta PICOT elaborada para responder à Questão 1 se encontra no Quadro B:  
**Quadro B** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Pacientes com AHAI|
|---|---|
|Intervenção|Diagnóstico e tratamento com tecnologias disponíveis no PCDT|  
23  
|Comparador(es)|Ausência ou qualquer comparador|
|---|---|
||Diagnóstico|
|Desfecho(s)|Seguimento<br>Eficácia - Desfechos clínicos|
||Segurança|
|Tipos de estudo (desenhos) de interesse|Estudos clínicos fase 2 e 3, revisões sistemáticas e diretrizes, protocolos ou<br>recomendações clínicas|  
*Por se tratar de atualização de recomendação, foram incluídas publicações registradas nas bases de dados a partir da data inicial de 18/03/2017 (buscas até 20/03/2024).  
As estratégias de busca para cada base estão descritas no Quadro C.  
Por se tratar de atualização de documentos oficiais já publicados, seguindo as recomendações da Cochrane, optou-se por definir uma data de início para as buscas, baseada nas informações do PCDT publicado pelo Ministério da Saúde em 2018. Assim, em relação às diretrizes clínicas para diagnóstico e tratamento da AHAI as bases de dados foram pesquisadas de 18 de março de 2017 até a data de 20/03/2024, sendo essa a data final da busca.  
**Quadro C** . Estratégias de busca, de acordo com a base de dados.  
|**Bases de dados**|**Estratégia de busca**|**Número de resultados**<br>**encontrados**|
|---|---|---|
|Pubmed|"Anemia, Hemolytic, Autoimmune"[Mesh] Filters: Clinical Trial,<br>Guideline, Meta-Analysis, Practice Guideline, Randomized Controlled<br>Trial, Systematic Review, from 2017/3/18 - 3000/12/12|47 estudos|
|Embase|('autoimmune hemolytic anemia'/exp OR 'autoimmune hemolytic<br>anemia') AND 'autoimmune hemolytic anemia':ab,ti AND ([cochrane<br>review]/lim OR [controlled clinical trial]/lim OR [systematic<br>review]/lim OR [randomized controlled trial]/lim OR [meta<br>analysis]/lim) AND [2017-2024]/py =|105 estudos|
|Cochrane Library|'autoimmune hemolytic anemia' in Title Abstract Keyword|1 estudo|  
Adicionalmente, na busca por diretrizes clínicas, protocolos clínicos e recomendações clínicas sobre diagnóstico,  
tratamento e acompanhamento da AHAI também foram avaliados os seguintes repositórios:  
NICE _guidelines_ (http://www.nice.org.uk): nenhuma diretriz publicada;  
_National Guideline Clearinghouse_ : nenhuma diretriz publicada;  
_National Library of Australia. Department of Health and Ageing, Australian Government_ http://www.health.gov.au.  
nenhuma diretriz publicada;  
_Guideline International Network_ – http://www.g-i- n.net/library/international-guidelines- library: nenhuma diretriz localizada.  
Resultados da busca  
24  
No total foram identificadas 153 publicações nas bases de dados. Excluindo-se as duplicatas, restaram 123 títulos, dos quais 102 foram excluídos na fase de título e resumo. Vinte e um artigos foram avaliados na sua integralidade, três deles foram excluídos e 18, incluídos na revisão.  
A **Figura A** apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
**Figura A** . Fluxograma de seleção dos estudos  
<!-- Start of picture text -->
Estudos removidos antes do<br>Estudos identificados processo de Triagem<br>Bases de dados (n=253) Duplicatas removidas (n =<br>36)<br>Titulos e resumo selecionados<br>(n=a23) Estudos excluidos.  = 102<br>Estudos avaliados para<br>elegibilidade ———+| Estudos excluidos =3<br>(n= 21)<br>Estudos incluidos na reviséo<br>(n= 18)<br><!-- End of picture text -->  
Análise e apresentação dos resultados  
As publicações incluídas nesta revisão não modificaram as recomendações que já constavam no PCDT publicado pela Portaria Conjunta SAS-SCTIE/MS nº 27/2018.  
Síntese das evidências de tecnologias para tratamento da AHAI  
Considerando as dúvidas clínicas discutidas em reunião de escopo, foram realizadas sínteses de evidências científicas referentes aos medicamentos rituximabe, danazol e azatioprina.  
25

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: Danazol para Síndrome de Evans -->
Em 19/10/2022 foi realizada busca na base de dados Pubmed/Medline com o objetivo de identificar os estudos com o medicamento danazol para tratamento da Síndrome de Evans, um dos casos especiais do PCDT de AHAI. A estratégia de busca para a pergunta de pesquisa está descrita no **Quadro D** .  
**Quadro D.** Estratégia de busca  
|**Base**|**Estratégia de busca**|**Estudos encontrados**|
|---|---|---|
|MedLine<br>(via PubMed)|(("Anemia, Hemolytic, Autoimmune"[Mesh] OR Anemia, Hemolytic,<br>Autoimmune)) AND ("danazol"[Mesh] OR danazol)|55|  
A **Figura B** apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas e o **Quadro E** apresenta a descrição dos estudos selecionados.  
**Figura B** . Fluxograma de seleção dos estudos  
<!-- Start of picture text -->
Estudos identificados<br>Bases de dadosa partir de:<br>MEDLINE (n = 55)<br>Estudos de outras fontes (artigos,<br>diretrizes) (n=6)<br>Estudos triados pelo titulo e resumo<br>(n=61)<br>Estudos<br>Revisdesemsimplesanimais(n=(n=14) 4)<br>‘Outras doencas<br>Idioma (n=12) ou intervencées (n = 12)<br>Nao disponiveis (n=3)<br>Estudos aveliados na integra<br>(n= 16)<br>Revises simples (n= 1)<br>Outras doencas ou intervences (n = 5)<br>Estudos incluidos para andlise (n=<br>10), sendo:<br>- 1 RS qualitative;<br>~ Lcoorte prospectivos/séries de<br>casos;<br>~ 3 estudos retrospectivos/séries de<br>casos;<br>~ Lrelato de caso<br>~4 diretrizes<br><!-- End of picture text -->  
26  
**Quadro E** . Estudos identificados.  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|_Fattizzo et al,_|Estudo de coorte|51% mulheres, com idade mediana no|Pacientes que necessitaram apenas de 1 linha de|Análise retrospectiva|
|_2021_(1)|retrospectivo<br>N=116<br>Pacientes adultos<br>diagnosticados com SE<br>acompanhados em 13<br>centros europeus.|diagnóstico de SE de 51 anos (variação: 1,9 a<br>94,8 anos) e acompanhados por uma mediana<br>de 7,5 anos (intervalo, 2-31 anos).<br>5 pacientes fizeram uso de Danazol|terapia: 26 (23%); 2 linhas: 26 (23%); 3 linhas:<br>30 (26%); 4 linhas: 33 (28%).<br>Tratamentos prescritos: 84 pacientes receberam<br>corticoides, 46 pacientes receberam rituximabe,<br>42 pacientes receberam corticoides +<br>imunoglobulina IV, 26 pacientes receberam<br>imunossupressor (azatioprina, n = 10;<br>ciclosporina, n = 6; ciclofosfamida, n = 8; e<br>micofenolato de mofetila, n = 8), 27 pacientes<br>receberam eltrombopague ou romiplostim, 12<br>foram submetidos a esplenectomia e 5 pacientes<br>receberam danazol.<br>As taxas de resposta global foram de 80%.<br>Todos os pacientes que utilizaram danazol<br>obtiveram resposta ao tratamento.|Poucos pacientes em<br>uso de danazol|
|_Jaime-Pérez,_<br>_2015_(2)|Relato da experiência de<br>centro acadêmico com<br>pacientes com SE.<br>n = 6 (4 mulheres e 2<br>homens)<br>Idade média = 24 anos|Paciente 1:<br>-1ª linha de tratamento: dexametasona<br>Paciente 2:<br>- 1ª linha de tratamento: metiprednisolona +<br>imunoglobulina<br>Paciente 3:<br>- 1ª linha de tratamento: dexametasona +<br>prednisona|Danazol foi administrado em três dos seis<br>pacientes em combinação com corticoides e<br>rituximabe (2 pacientes).<br>Os três pacientes apresentaram boas respostas<br>iniciais; no entanto, dois recidivaram e<br>precisaram de tratamento adicional, sendo que<br>um foi esplenectomizado com sucesso (Paciente<br>4) após a primeira recidiva.|Relatos de casos<br>Número amostral<br>pequeno|  
27  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||Diagnóstico entre 2007 e<br>2012|- 2ª linha de tratamento: rituximabe<br>Paciente 4:<br>- 1ª linha de tratamento: dexametasona<br>- 2ª linha de tratamento: rituximabe + Danazol<br>Paciente 5:<br>- 1ª linha de tratamento: dexametasona<br>- 2ª linha de tratamento: danazol + rituximabe<br>Paciente 6:<br>- 1ª linha de tratamento: dexametasona<br>- 2ª linha de tratamento: danazol<br>Foram avaliados o tempo de resposta após a 1ª<br>linha (dias) através da contagem de plaquetas e<br>hemoglobina e tempo e número de recaídas,<br>bem como tratamento após a recaída|O rituximabe foi usado em três dos seis<br>pacientes, sem resposta em dois pacientes<br>(Pacientes 3 e 4), levando a esplenectomia.<br>Apenas um paciente (Paciente 5) respondeu<br>satisfatoriamente ao rituximabe em combinação<br>com danazol.<br>O paciente que recebeu danazol como 2ª linha<br>teve boa resposta sem recidiva (paciente 6).||
|_Letchumanan_<br>_P, et al. 2011_<br>(3)|Revisão sistemática<br>qualitativa<br>Revisar estudos sobre o<br>uso, a eficácia e os<br>eventos adversos do<br>danazol em pacientes com<br>LES.<br>38 artigos selecionados:<br>- 19 séries de casos/relatos<br>(n= 153)|Uso de danazol 200 a 1200 mg/dia<br>Remissão completa: resolução completa dos<br>sintomas para os quais o danazol foi iniciado.<br>Para trombocitopenia: plaquetas acima de<br>100.000/mm<sup>3</sup>(exceto em 1 estudo em que a<br>definição foi acima de 150.000/mm<sup>3</sup>).<br>Remissão parcial: plaquetas entre 50.000 e<br>99.000/mm<sup>3</sup>|Dois estudos incluídos avaliaram pacientes com<br>LES e PTI refratária e Síndrome de Evans:<br>O estudo deCervera, 1995,utilizou danazol na<br>dose de 200 a 1200 mg/dia (após a remissão, a<br>dose foi gradualmente reduzida para 200 a 400<br>mg/dia).<br>Todos os 16 pacientes obtiveram RC 2 meses<br>após o início do danazol (intervalo 6 semanas a 8<br>meses). A remissão persistiu durante a terapia de<br>danazol (seguimento médio 18,2 meses, intervalo<br>2 a 49 meses).|Relato de casos;<br>Poucos pacientes com<br>SE;<br>Autores concluíram<br>que danazol tem sido<br>usado com sucesso no<br>tratamento da<br>trombocitopenia, SE,<br>AHAI e um caso de<br>aplasia de série<br>eritroide.|  
28  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||- 2 coortes prospectivas<br>com (n= 7 e 16)<br>- 1 ECR (n = 40)<br>Cervera_et al_(1995):<br>coorte prospectiva de 16<br>pacientes com LES com<br>trombocitopenia<br>autoimune refratária ou<br>SE.<br>Aranegui_et al_(1991):<br>relato de 1 caso||Um paciente com SE interrompeu tratamento<br>devido à icterícia e necrose hepática com recidiva<br>da hemólise posteriormente.<br>O relato de caso de Aranegui (1991) é de um<br>paciente com LES e SE refratário a azatioprina e<br>prednisona e que utilizou danazol na dose de 600<br>mg/dia com RC após 4 semanas de tratamento<br>com redução da dose do corticoide.|Uma resposta completa<br>foi observada na<br>maioria dos pacientes<br>relatados, com 2 séries<br>de casos mostrando<br>uma taxa de resposta<br>de 50 e 80%,<br>respectivamente.|
|_Michel et al,_<br>_2009_(4)|Estudo de coorte<br>retrospectivo<br>n = 68 pacientes (60%<br>sexo feminino)<br>7 centros na França e<br>Itália|Para AHAI, resposta completa definida por um<br>nível de Hb maior que 12 g/dL, sem suporte<br>transfusional e sem evidências de hemólise<br>(níveis normais de bilirrubinas, LDH e de<br>haptoglobina, se realizados). Resposta parcial<br>(RP) definida por um nível de Hb de pelo<br>menos 10 g/dL com um aumento de pelo menos<br>2 g em relação ao valor basal, com persistência<br>de evidências de hemólise;<br>Para a PTI, RC foi definida por uma contagem<br>plaquetária normal (ou seja, maior que 150 x<br>10<sup>9</sup>/L) e um RP por uma contagem plaquetária<br>superior a 50 X 10<sup>9</sup>/L com pelo menos um|Primeira linha: Todos os 68 pacientes receberam<br>pelo menos um ciclo de**corticoides (prednisona**<br>**ou prednisolona)**para o manejo de AIHA e/ou<br>PTI. Para PTI, 79% utilizaram corticoide e 48%<br>dos pacientes receberam imunoglobulina IV.<br>Para AHAI: Taxa de resposta inicial de 83%<br>(50% de RC e 50% de RP; 17% foram<br>considerados não respondedores). Para PTI: taxa<br>de resposta inicial global de 82% (RC em dois<br>terços, RP em um terço dos casos). RC com<br>imunoglobulina (de curto prazo) em 60% dos<br>casos.|Análise retrospectiva|  
29  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|||aumento de 2 vezes da contagem pré-<br>tratamento.|Outras linhas de tratamento: 73% dos pacientes<br>receberam pelo menos uma terapia de "segunda<br>linha" e 28% foram submetidos a esplenectomia.<br>As terapias de segunda ou terceira linha foram:<br>danazol (n = 23), ciclofosfamida oral ou<br>intravenosa (n=10), rituximabe (n=11),<br>hidroxicloroquina (n = 8), alcaloides vinca (n =<br>7), ciclosporina (n = 4), azatioprina (n = 6),<br>micofenolato (n = 2) e dapsona (para PTI, n = 2).<br>Taxas de RC e RP:  Danazol (60%),<br>esplenectomia (52%), Rituximabe (63%),<br>Alcaloides Vinca (28%).<br>Danazol foi interrompido em 3 pacientes por<br>hepatite.||
|_Chemlal K et_<br>_al_, 1999 (5)|Relato de 1 caso|O relato de caso é de um paciente com LES e<br>SE refratário a múltiplos tratamentos<br>(imunoglobulina, prednisona, dapsona,<br>ciclofosfamida/vincristina/prednisona). Iniciou<br>ciclosporina (200 a 400 ng/mL) em janeiro<br>1997, azatioprina (100 mg/dia) + danazol (400<br>mg/dia) em fevereiro 1997.|Houve reposta (aumento das plaquetas) 21 dias<br>após início do danazol e 2 meses após início da<br>ciclosporina. Danazol foi suspenso e reiniciado<br>após recidiva da trombocitopenia. Azatioprina foi<br>suspensa em junho 1997 e corticoides em janeiro<br>1998.<br>Entre agosto 1997 e janeiro 1999 não houve<br>recidivas com uso do danazol e baixa dose de<br>ciclosporina.|Relato de caso<br>Carta para editor|  
30  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|_Pignon, 1993_<br>(6)|Séries de casos<br>retrospectiva<br>n = 17 (3 com SE)<br>Pacientes foram divididos<br>em 2 grupos|Grupo 1 (10 pacientes – 2 com SE) =<br>Prednisona 1 mg/kg/dia + Danazol (600 a 800<br>mg) como primeira linha<br>Grupo 2 (7 pacientes – 1 com SE) = Prednisona<br>1 mg/kg/dia + Danazol (600 a 800 mg) como<br>segunda ou terceira linha (refratários a<br>tratamento com corticoide e outros tratamentos)<br>Desfechos:<br>- Resposta ao tratamento:<br>1. Excelente: Hb maior que 12,5 g/dL com<br>interrupção ou redução da prednisona paraaté5<br>mg/dia.<br>2. Parcial: Hb maior que 12,5 g/dL com a<br>redução da prednisona para 5 a 10 mg/dia.<br>3. Falha: Nível de Hb igual a 12,5 g/dL não foi<br>atingido com dose de prednisonaigual ou maior<br>que 10 mg/dia ou na presença de recaída.<br>- Eventos adversos|Duração média do tratamento foi de 28 meses (9-<br>91 meses).<br>Os eventos adversos relatados foram: câimbras e<br>mialgia. Somente 1 caso de elevação moderada<br>de enzimas hepáticas.<br>Grupo 1: 8 respostas excelentes e 2 falhas foram<br>observadas (pacientes com SE). Um dos<br>pacientes com SE apresentou falha após 24 meses<br>de tratamento e outro apresentou falha após 12<br>meses de tratamento e realizou esplenectomia.<br>Grupo 2: 3 respostas excelentes, 1 resposta<br>parcial e 3 falhas foram observadas. A resposta<br>parcial foi observada no paciente com SE, que<br>manteve níveis normais de hemoglobina por 77<br>meses com tratamento de 10 mg de prednisona +<br>400 mg de danazol.<br>Melhores taxas de resposta na primeira linha de<br>tratamento em pacientes com AHAI. Em<br>pacientes com SE, houve 2 falhas e uma resposta<br>parcial.|Relato de casos<br>Poucos pacientes com<br>SE|  
Legenda: AHAI: Anemia Hemolítica Autoimune; ECR: ensaio clínico randomizado; LDH: lactato desidrogenase; LES: Lúpus Eritematoso Sistêmico; PTI: Púrpura Trombocitopênica Idiopática; SE: Síndrome de Evans.  
31  
As seguintes diretrizes e agências de ATS foram consultadas:  
● **Consenso Internacional de Jäger de 2019** , um grupo de especialistas avaliou o tratamento dos dois tipos de anemia autoimune, com anticorpos quentes (wAIHA) e com anticorpos frios (CAD). Citam o sirolimo como uma alternativa eficaz em crianças com AIHA primária ou síndrome de Evans, apesar de poucos estudos. Recomendam corticoide como primeira linha, atingindo a dose mínima eficaz o mais rápido possível e sem uso prolongado, devido ao risco de infecções. Recomendam rituximabe ou imunossupressores orais (azatioprina) para pacientes refratários ou recidivados. **Danazol não é citado**<sup>7</sup> .  
● **Consenso para diagnóstico e tratamento de crianças com AHAI** , o Grupo de Estudos de Célula Vermelha da Associação Italiana de hemato-oncologia pediátrica de Ladogana, 2017 cita o micofenolato de mofetila como estratégia cada vez mais evidente e com poucos eventos adversos para AHAI e Síndrome de Evans. Citam um relato de caso com uso da ciclosporina associada a prednisona em uma criança de 6 anos com Síndrome de Evans. **Danazol não é citado**<sup>8</sup> .  
● **Diretriz da Sociedade Britânica de Hematologia, de 2017, para AHAI de origem primária:** recomenda o danazol como terceira linha de tratamento para AHAI quente primária, junto com azatioprina, ciclosporina, micofenolato de mofetila, esplenectomia. **Não cita tratamento para síndrome de Evans**<sup>9</sup> .  
● **Diretriz da Sociedade Britânica de Hematologia, de 2017, para anemia hemolítica autoimune induzida por droga**  
**e secundária**<sup>10</sup> **:** recomendações de tratamento para Síndrome de Evans Primária  
Tratamento de primeira linha: Corticoides, imunoglobulina humana intravenosa.  
Tratamento de segunda linha: azatioprina, ciclosporina, **danazol** , micofenolato de mofetila, rituximabe, esplenectomia, vincristina.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **REFERÊNCIAS:** -->
<mark>1. Fattizzo B, Michel M, Giannotta JA, Hansen DL, Arguello M, Sutto E, Bianchetti N, Patriarca A, Cantoni S, MingotCastellano ME, McDonald V, Capecchi M, Zaninoni A, Consonni D, Vos JM, Vianelli N, Chen F, Glenthøj A, Frederiksen H, González-López TJ, Barcellini W. Evans syndrome in adults: an observational multicenter study. Blood Adv. 2021 Dec 28;5(24):5468-5478. doi: 10.1182/bloodadvances.2021005610. PMID: 34592758; PMCID: PMC8714709.</mark>  
2. <mark>Jaime-Pérez JC, Guerra-Leal LN, López-Razo ON, Méndez-Ramírez N, Gómez-Almaguer D. Experience with Evans syndrome in an academic referral center. Rev Bras Hematol Hemoter. 2015 Jul-Aug;37(4):230-5. doi: 10.1016/j.bjhh.2015.03.002. Epub 2015 Mar 28. PMID: 26190425; PMCID: PMC4519700.</mark>  
3. <mark>Letchumanan P, Thumboo J. Danazol in the treatment of systemic lupus erythematosus: a qualitative systematic review. Semin Arthritis Rheum. 2011 Feb;40(4):298-306. doi: 10.1016/j.semarthrit.2010.03.005. Epub 2010 Jun 11. PMID: 20541792.</mark>  
<mark>4. Michel M, Chanet V, Dechartres A, Morin AS, Piette JC, Cirasino L, Emilia G, Zaja F, Ruggeri M, Andrès E, Bierling P, Godeau B, Rodeghiero F. The spectrum of Evans syndrome in adults: new insight into the disease based on the analysis of 68 cases. Blood. 2009 Oct 8;114(15):3167-72. doi: 10.1182/blood-2009-04-215368. Epub 2009 Jul 28. PMID: 19638626.</mark>  
<mark>5. C</mark> hemlal K, Wyplosz B, Grange MJ, Lassoued K, Clauvel JP. Salvage therapy and long-term remission with danazol and cyclosporine in refractory Evan's syndrome. Am J Hematol. 1999 Nov;62(3):200.  
<mark>6. Pignon JM, Poirson E, Rochant H. Danazol in autoimmune haemolytic anaemia. Br J Haematol. 1993 Feb;83(2):343-5. doi: 10.1111/j.1365-2141.1993.tb08293.x. PMID: 8457484.</mark>  
<mark>7. J</mark> äger U, Barcellini W, Broome CM, Gertz MA, Hill A, Hill QA, et al. Diagnosis and treatment of autoimmune hemolytic anemia in adults: Recommendations from the First International Consensus Meeting. Blood Rev. 2020;41:100648.  
32  
8. Ladogana S, Maruzzi M, Samperi P, Condorelli A, Casale M, Giordano P, et al. Second-line therapy in paediatric warm autoimmune haemolytic anaemia. Guidelines from the Associazione Italiana Onco-Ematologia Pediatrica (AIEOP). Blood Transfus. 2018;16(4):352-7.  
9. Hill QA, Stamps R, Massey E, Grainger JD, Provan D, Hill A; British Society for Haematology. The diagnosis and management of primary autoimmune haemolytic anaemia. Br J Haematol. 2017 Feb;176(3):395-411. doi: 10.1111/bjh.14478. Epub 2016 Dec 22. PMID: 28005293.  
10. <mark>Hill QA, Stamps R, Massey E, Grainger JD, Provan D, Hill A; British Society for Haematology Guidelines. Guidelines on the management of drug-induced immune and secondary autoimmune, haemolytic anaemia. Br J Haematol. 2017 Apr;177(2):208-220. doi: 10.1111/bjh.14654. Epub 2017 Apr 3. PMID: 28369704.</mark>

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: Azatioprina para AHAI -->
Em 19/10/2022 foi realizada busca na base de dados Pubmed/Medline com o objetivo de identificar os estudos com o  
medicamento azatioprina para tratamento da Anemia Hemolítica Autoimune (AHAI). A estratégia de busca para está descrita no Quadro F.  
**Quadro F.** Estratégia de busca  
|**Base**|**Estratégia de busca**|**Estudos encontrados**|
|---|---|---|
|MedLine|(("Anemia, Hemolytic, Autoimmune"[Mesh] OR Anemia, Hemolytic,|220|
|(via PubMed)|Autoimmune)) AND ("azathioprine"[Mesh] OR azathioprine)||  
A **Figura C** apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas e o **Quadro G** apresenta a descrição dos estudos selecionados.  
33

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: Azatioprina para AHAI -->
<!-- Start of picture text -->
Estudos identificados a<br>partir de:<br>Bases de dados<br>Pubmed (n « 220)<br>Estudos triados peto titulo<br>fesumo<br>{n+ 220) Exclusées:<br>Outras populagdes ou intervengdes:n « 134<br>Tipos de publicagGes: revisdes simples/relato de<br>um caso: n= 69<br>Estudos em animais:n «14<br>Estudos avaliados na integra Artigo nao disponivel: n « 1 {artigo do ano de 1974)<br>critérios de elegibilidade<br>(n=2)<br>t<br>n<br>rfc Estudos incluidos {n « 2)<br>ra sendo:<br>t ~ 2 estudos retrospectives<br>dq<br>°<br><!-- End of picture text -->  
34  
**Quadro G.** Estudos incluídos referentes à azatioprina no tratamento da AHAI  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO EDESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|_Hantaweepant,_|Estudo retrospectivo para|N= 54|- Idade média 55,8 anos (14,5–87,4);|Estudo|
|_C.R et al, 2019_|relatar a segurança e|-<br>Incluídos somente pacientes em 2<sup>a</sup>linha|- 83,3% sexo feminino|retrospectivo N|
|_(1)_|eficácia da segunda linha de<br>tratamento de pacientes<br>tailandeses com AHAIq que<br>apresentaram falha aos<br>corticoides|-<br>Medicamentos utilizados como 2<sup>a</sup>linha:<br>-<br>azatioprina<br>-<br>ciclofosfamida<br>-<br>clorambucil<br>-<br>danazol|- Todos receberam corticoides como 1<sup>a</sup>linha,<br>- 63%, refratários a corticoides<br>- 13% PR, 24,1% RC<br>- 37% recidivaram em tempo médio de 36,3<br>meses|pequeno,<br>Tailândia|
||N= 54<br>Dados de 01/2007 a<br>12/2016 (9 anos)|-<br>rituximabe<br>-<br>Desfechos:<br>-<br>RC: Hb maior ou igual a 12 g/dL e<br>normalização dos marcadores de hemólise;<br>-<br>RP: Hb maior ou igual a 10 g/dL ou<br>aumento maior ou igual a 2 g/dL da hemoglobina<br>basal, sem suporte transfusional;<br>-<br>Resposta global: combinação da CR + PR<br>-<br>Recidiva: Hb menor ou igual a 10 g/dL ou<br>diminuição maior ou igual a 2 g/dL após CR ou PR.<br>-<br>Doença refratária: Hemoglobina menor que<br>10 g/dL ou redução maior que 2 g/dL na<br>hemoglobina desde o início do tratamento.|Segunda linha:<br>- azatioprina (61,1%), TR =78%<br>- ciclofosfamida (31,5%), TR =58,8%<br>- clorambucil (1,9%), TR =100% 1 pac<br>- danazol (3,7%), TR =100% 2 pac<br>- rituximabe (1,9%), TR =0%  1 pac<br>O teste de Coombs direto positivo forte (3+–4+)<br>foi o único fator preditivo da resposta ao<br>tratamento (p = 0,008).<br>Os homens apresentaram melhor sobrevida<br>livre de recaída do que as mulheres (não<br>atingido vs. 20,6 meses) (p = 0,023).<br>Aproximadamente 40% dos pacientes que<br>responderam ao tratamento de segunda linha<br>apresentaram recaída em uma média de 7,4<br>meses.||  
35  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO EDESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|_Prabhu, R et al,_|Estudo retrospectivo para|N= 33|Média de idade: 41 anos|Estudo|
|_2016 (2)_|relatar apresentação clínica<br>da AHAI, resposta à terapia<br>de primeira linha,<br>durabilidade da resposta,<br>tempo até o próximo|- 16 pacientes (48%) AHAIq<br>- 15 pacientes (46%) DAF<br>- 2 pacientes (6%) atípicos.<br>- 75% pacientes apresentaram anemia grave com<br>hemoglobina menor que 8 g/dL no início do|Primeira linha:100% pacientes.<br>prednisolona oral a 1,5 mg/kg/dia<br>- TR foi de 90% (62% de RC e 28% de RP);<br>- Duração mediana do corticoide: 14 meses;<br>**Segunda linha**:n=15|retrospectivo<br>Número<br>amostral<br>pequeno,<br>Índia|
||tratamento e resposta a|tratamento, hemoglobina menor em pacientes mais|50% dos pacientes||
||agentes de segunda linha.|jovens|-<br>n=14 azatioprina- Resposta global 11||
||Centro único no Sul da<br>Índia.|-<br>Segunda linha:<br>-<br>azatioprina,|(79%), RP 9 (64%) e RC 2 (15%), sendo que<br>metade deles não necessitou de um terceiro||
||N= 33|-<br>micofenolato,|medicamento.||
||Dados de 07/2009 a<br>06/2015|-<br>ciclofosfamida,<br>-<br>ciclosporina,<br>-<br>rituximabe|-<br>n=1 (CAD) rituximabe, PR<br>**Terceira linha:**n=7||
|||-<br>Definição de resposta:|- 3 rituximabe, 2 RP e 1 RC (CAD)||
|||-<br>RC: Hemoglobina maior que 12 g/dL sem<br>evidência de hemólise|- 2 micofenolato de mofetila, sem resposta<br>- 2 ciclosporina + imunoglobulina humana, PR||
|||-<br>RP: hemoglobina maior que 10 g/dL ou<br>aumento de 2 g/dL na hemoglobina basal, sem<br>suporte transfusional|**Quarta linha:**n=1<br>- ciclofosfamida, RC<br>Complicações:||
|||-<br>Recidiva: queda para hemoglobina menor<br>que 10 g/dL|-<br>4 pacientes apresentaram infecções<br>graves (pneumonia, sepse e abscesso de tecidos<br>moles)<br>-<br>2 TVP/TEP||  
Legenda: AHAIq: Anemia Hemolítica Autoimune quente; RC: Resposta completa; RP: Resposta Parcial; TR: Taxa de recidiva; DAF: doença da aglutinina fria; TVP: Trombose venosa profunda; TEP: tromboembolismo pulmonar  
36  
As seguintes diretrizes e agências de ATS foram consultadas:  
- **Consenso Internacional** de Jäger de 2019: grupo de especialistas avaliou o tratamento dos dois tipos de anemia  
- autoimune, com anticorpos quentes (AIHAq) e com anticorpos frios (CAD).<sup>3</sup>  
- Para wAIHA - **azatioprina** é citada como **quarta linha** (juntamente com ciclosporina e micofenolato), pós corticoide,  
- rituximabe e esplenectomia.  
- Para a CAD a **azatioprina não é citada.**  
● **Consenso para diagnóstico e tratamento de crianças com AIHA** , o Grupo de Estudos de Célula Vermelha da Associação Italiana de hemato-oncologia pediátrica (Ladogana, 2017) recomenda a primeira linha com corticoides, seguida de rituximabe (2º linha), ciclofosfamida (3º linha), esplenectomia (4º linha) e alentuzumabe ou transplantes como 5º linha. A associação de imunossupressores (azatioprina ou cliclosporina ou micofenolato) é indicada a partir da segunda linha de tratamento quando há resposta parcial dos tratamentos ou quando há dependência à corticoide<sup>4</sup> .  
● **Diretriz britânica** , de 2016, recomenda a primeira linha de tratamento da AIHAq com corticoides, seguida de rituximabe (2º linha) e qualquer das tecnologias a seguir como 3ª linha: azatioprina, ciclofosfamida, ciclosporina, micofenolato de mofetila, danazol ou esplenectomia<sup>5</sup> .  
- **NICE** **_–_** _National Institute for Health and Care Excellence_ da Inglaterra e País de Gales **– não cita azatioprina**<sup>6</sup> .

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: **REFERÊNCIAS:** -->
1. Hantaweepant C, Pairattanakorn P, Karaketklang K, Owattanapanich W, Chinthammitr Y. Efficacy and safety of secondline treatment in Thai patients with primary warm-type autoimmune hemolytic anemia. Hematology. 2019 Dec;24(1):720726. doi: 10.1080/16078454.2019.1671060. PMID: 31581907.  
2. Prabhu R, Bhaskaran R, Shenoy V, G R, Sidharthan N. Clinical characteristics and treatment outcomes of primary autoimmune hemolytic anemia: a single center study from South India. Blood Res. 2016;51(2):88-94.]  
3. Jäger U, et al. Diagnosis and treatment of autoimmune hemolytic anemia in adults: Recommendations from the First International Consensus Meeting. Blood Rev. 2020 May;41:100648.  
4. Ladogana S, Maruzzi M, Samperi P, Condorelli A, Casale M, Giordano P, et al. Second-line therapy in paediatric warm autoimmune haemolytic anaemia. guidelines from the associazione italiana onco-ematologia pediatrica (aieop). Blood Transfus (2018)16(4):352–57. doi: 10.2450/2018.0024-18  
5. Hill QA, Stamps R, Massey E, Grainger JD, Provan D, Hill A; British Society for Haematology. The diagnosis and management of primary autoimmune haemolytic anaemia. Br J Haematol. 2017 Feb;176(3):395-411. doi: 10.1111/bjh.14478. Epub 2016 Dec 22. PMID: 28005293.  
6. NICE Guidance. Autoimmune haemolytic anaemia: rituximab. Evidence summary [ESUOM39] Published: 10 February 2015. Disponível em: www.nice.org.uk/guidance/esuom39.

---

<!-- METADADOS: doenca: Anemia Hemolítica Autoimune Portaria Conjunta n 7 - 2025 | secao: Rituximabe para AHAI -->
Em 19/10/2022 foi realizada busca na base de dados Pubmed/Medline com o objetivo de identificar os estudos com o  
medicamento rituximabe para tratamento da Anemia Hemolítica Autoimune (AHAI).  
A estratégia de busca para está descrita no **Quadro H** .  
37  
**Quadro H.** Estratégia de busca  
|**Base**|**Estratégia de busca**|**Estudos encontrados**|
|---|---|---|
|MedLine|("Anemia, Hemolytic, Autoimmune"[Mesh] OR Anemia, Hemolytic,|636|
|(via PubMed)|Autoimmune)) AND ("rituximab"[Mesh] OR rituximab)||  
A **Figura D** apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão. O **Quadro I** apresenta a descrição dos estudos selecionados.  
**Figura D** . Fluxograma de seleção dos estudos  
<!-- Start of picture text -->
Estudospartiridentificadosde: a<br>Bases de dados<br>MEDLINE in » 636)<br>Estudos triadosresumopelo tituloe Tipos de publicagées (n= 111)<br>(n= 636) Outras doencas ou intervencdes<br>(n= 469)<br>N pequeno {n = 3)<br>Idioma {n=10}<br>Nao disponiveis nea)<br>Estudos avaliados na integra<br>critérios de elegibilidade<br>(n «110 Tipos de publicacées (n- 4)<br>Outras doencas ou intervencées<br>(ned<br>N pequeno in « 1)<br>Estudos incluidos para Nao disponiveis (net)<br>analise<br>~3RS; (n = 19). senda<br>- 5 estudos<br>prospectivos/séries de<br>casos:<br>- gestudos<br>retrospectivos/séries de<br>casne<br><!-- End of picture text -->  
38  
**Quadro I** . Estudos incluídos.  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|_Arora et_|Série de casos prospectivos|Avaliação da resposta a rituximabe em 2<sup>a</sup>|4/11 com remissão em 1ª linha;|Não tem desenho de ECR.|
|_al,_|para avaliar a resposta|linha|7 com remissão sustentada após 2ª linha,|Número amostral pequeno|
|_2021(1)_|hematológica ao tratamento da<br>anemia hemolítica autoimune<br>com anticorpos quentes<br>(AIHAq)<br>Crianças - 0 a 18 anos<br>n = 11<br>Tempo 24 meses|1ª linha: Prednisolona – 2 mg/kg/dia em 10<br>pacientes.<br>2ª linha:<br>- Ciclosporina – 5 a 6 mg/kg/dia, em 2<br>pacientes;<br>- Rituximabe (RTX) 375 mg/m<sup>2</sup>/semana por<br>4 semanas, em 3 pacientes, após recidivas.<br>Outros medicamentos incluídos<br>(micofenolato, mercaptopurina)<br>Desfechos:<br>- Melhora e estabilização da hemoglobina<br>acima de 11 g/dL para resposta completa<br>(RC)<br>- Aumento de 2 g /dL na hemoglobina para<br>resposta parcial (RP).|com recidivas iniciais;<br>3 que usaram RTX – com remissão<br>sustentada após 6, 7 e 12 meses;<br>3 mantendo doses baixas de corticoide<br>com ou sem ciclosporina.<br>1 morte nas primeiras 12h da internação<br>por Insuficiência cardíaca..||
|_Liu et al,_|Revisão sistemática e|Avaliação da resposta a rituximabe em 1<sup>a</sup>|Grupo 1 - mostra que a associação de|Avalia o tratamento em 1<sup>a</sup>linha;|
|_2021(2)_|meta=análise Cochrane de 2<br>ECR –_Birgens, 2013 e_<br>_Michel, 2017._<br>Avaliação de eficácia do|linha<br>Grupo 1 = RTX (375 mg/m<sup>2</sup>/semana por 4<br>semanas ou 1.000 mg 2 doses em intervalo|RTX e corticoide melhora a taxa de<br>resposta completa após 12 meses de<br>acompanhamento quando comparado com<br>corticoide isolado.|Faltam informações sobre os<br>desfechos de sobrevida geral,<br>tempo livre da doença, qualidade<br>de vida e eventos adversos, além|
||tratamento da AIHAq|de 15 dias) +|(n= 96, RR 2,13, 95% IC 1,34-3,40).|da resposta hematológica.|  
39  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||Adultos<br>n= 96 estudos randomizados|Corticoide (1 a 1,5 mg/kg/dia).<br>X<br>Grupo 2 = Corticoide<br>Desfechos:<br>- Melhora hematológica completa –<br>Hemoglobina maior que 11 g/dL em<br>mulheres e maior que 12 g/dL em homens;<br>- Tempo livre de doença (TLD);<br>- RP;<br>- Necessidade de suporte transfusional;<br>- Eventos adversos.||Sem outros comparadores.<br>Limita a generalização para<br>outras situações e pacientes com<br>AIHAq.<br>GRADE - baixa e muito baixa<br>evidência: 1 ECR com baixo<br>risco de viés e outro com alto<br>risco (falta de cegamento, número<br>amostral pequeno).|
|_Jia et al,_|Análise retrospectiva do|RTX com ou sem prednisona – n=6|81% pacientes responderam ao tratamento|Não é ECR e, sim, estudo|
|_2020(3)_|tratamento com RTX em<br>pacientes com anemia<br>hemolítica autoimune por|X<br>R-CHOP, R-CVP, DRC/RFC, DRC – n=<br>10.|(13/16) com, pelo menos, RP, dos quais 3<br>com RC.<br>Sem resposta – n= 3|retrospectivo de centro único;<br>Número amostral pequeno, o que<br>limita a generalização dos dados;|
||anticorpos a frio (CAD –_cold_<br>_agglutinin disease_)<br>N= 16|Desfechos:<br>- RC (resposta completa)- desaparecimento<br>dos sintomas de CAD, ausência de anemia,<br>sem hemólise ou proteína sérica monoclonal<br>ou sinal de doença linfoproliferativa.<br>- RP (resposta parcial) - aumento estável da<br>hemoglobina, redução dos anticorpos IgM<br>pelo menos em 50%, melhora clínica,<br>independência de transfusões.|Sem diferença significativa entre a<br>resposta de RTX monoterapia x RTX com<br>outros medicamentos.|A escolha do tratamento depende<br>da experiência dos clínicos;<br>Tratamento com RTX com muita<br>heterogeneidade;<br>Difícil especificar qual<br>tratamento é melhor;<br>Escassez de ECR relacionados a<br>AIHAI.|  
40  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|||R-CHOP – RTX + ciclofosfamida,<br>doxorubina, vincristina e prednisona.<br>RTX-CVP - RTX + ciclofosfamida,<br>vincristina e prednisona.<br>DRC - dexametasona, RTX e<br>ciclofosfamida.<br>RFC – RTX, fludarabina, ciclofosfamida.||Decisões baseadas em opinião de<br>especialistas.|
|_Berentsen_<br>_et al,_<br>_2020(4)_|Estudo observacional,<br>multicêntrico, multinacional<br>em pacientes com CAD.<br>Revisa aspectos gerais da<br>doença e o seguimento do<br>tratamento, por uma média de<br>8 anos.<br>n= 232<br>(56 – 24,1% pacientes não<br>receberam tratamento nenhum<br>e<br>175 – 75,9% receberam uma<br>média de 2 tratamentos).|Grupo 1: RTX + Bendamustina (n=45)<br>X<br>Grupo 2: RTX + fludarabina (n=29<br>Desfechos:<br>- Resposta hematológica completa, parcial<br>ou sem resposta, conforme definições<br>publicadas.<br>- Duração da resposta.<br>- Malignidades tardias.|Grupo 1: resposta geral em 78%, sendo<br>53% com RC e 24% com RP.<br>Duração de resposta no grupo 1 mais<br>longa (maior que 88 meses) do que o<br>grupo 2.<br>Remissão sustentada estimada de 77% em<br>5 anos.<br>Grupo 2: 62% de resposta geral, com 38%<br>de RC e 24% com RP.<br>Duração de resposta de 77 meses, com<br>remissão sustentada estimada em 71% em<br>5 anos.<br>Mais malignidades a longo prazo no grupo<br>2 em relação ao grupo 1= 31% x 9%.<br>72 (31%) pacientes morreram.|Estudo de vida real.<br>Comparação entre diferentes<br>estudos.|  
41  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|_Chao et al,_|Revisão Sistemática e meta-|RTX|Taxas de resposta geral = 0,84 (95% IC|Apenas 2 ECR encontrados.|
|_2020(5)_|análise da eficácia e segurança<br>do RTX na anemia hemolítica<br>autoimune (AHAI) e<br>microangiopática (MAHA).<br>N= 37 estudos (1057<br>pacientes).<br>AHAI: 24 estudos (746<br>pacientes).<br>MAHA: 13 estudos (311<br>pacientes).<br>10 estudos comparativos (7 de<br>AHAI e 3 de MAHA).|X<br>Tratamentos convencionais sem RTX<br>Desfechos:<br>- Taxas de resposta geral (ORRs).<br>- Taxas de resposta completa (CRRs).<br>- Taxas de eventos adversos (AEs).<br>- Taxas de recaídas (RR).|0,80-0,88).<br>Taxas de resposta completa = 0,61 (95%<br>IC 0,49-0,73).<br>Taxas de eventos adversos = 0,14 (95% IC<br>0,10-0,17).<br>Taxas de recaídas = 0,21 (95% IC 0,15-<br>0,26) (28% de recaídas para AHAI).<br>Taxas de resposta geral relativas= 1,18<br>(95% IC 1,02-1,36) e resposta completa<br>1,17 (95% IC 0,98-1,39) mais vezes do<br>que os respectivos tratamentos sem RTX.<br>Eventos adversos relativos= 0,77 (95% IC<br>0,36-1,63) e RR 0,93 (95% IC 0,56-1,55)<br>menos vezes do que os tratamentos sem<br>RTX.<br>Sem diferença entre os grupos em relação<br>às recaídas ou AE.<br>RTX monoterapia pode ser pensado no<br>tratamento da AHAI.<br>É seguro para o tratamento dessas 2<br>doenças.<br>Reações à infusão frequentes – Maior que<br>25%.|Baixo nível de evidência.<br>Grande heterogeneidade nos<br>resultados.<br>Diferentes comparadores.<br>Vieses de publicação presentes na<br>estimativa das respostas.|  
42  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|_López-_|Estudo retrospectivo de AIHA|Corticoide - 41 pacientes.|Resposta em 90% para corticoide.|Estudo retrospectivo.|
|_Vidal et al,_|no Chile.|RTX como 2ª linha em 3 pacientes|Resposta ao RTX nos 3 pacientes, com||
|_2019 (6)_|N= 43|refratários.|uma recaída.||
||AHAIq – n= 36<br>CAD – n= 7|Desfechos:<br>- Resposta ao tratamento.|Sobrevida geral= 72%||
||38 meses de<br>acompanhamento.|- Sobrevida em 5 anos.|||
|_Yilmaz et_|Estudo retrospectivo para|1ª linha – Corticoides.|Resposta completa = 54,5% e|Estudo retrospectivo.|
|_al,_|avaliar as características|Recaída em 43,3% após média de 12 meses.|Resposta parcial = 40,2% com corticoide.||
|_2019(7)_|clínicas e o tratamento de<br>pacientes com AHAIq.<br>N= 60|2ª linha após recaída – RTX e<br>esplenectomia.<br>Desfechos:<br>- Resposta completa.|Resposta geral da 2ª linha = 85%.||
||Experiência de 10 anos.|- Resposta parcial.|||
|_Jaime-_|Dados de vida real em centro|1ª linha – Corticoide.|Resposta geral= 76,7% ao corticoide|Desenho retrospectivo.|
|_Pérez et_|de referência do México com|1ª linha - RTX dose baixa 100 mg/semana|monoterapia.|Número amostral pequeno.|
|_al,_|avaliação da resposta ao|por 4 semanas + dexametasona (n=18).|Resposta geral= 100% ao RTX +|AHAIq mais ativa já que estudo|
|_2019(8)_|tratamento da AHAIq<br>N= 64|2ª linha – RTX dose baixa (n=8).<br>Desfechos:<br>- Resposta completa (RC)<br>- Resposta parcial (RP)|corticoide.<br>Tempo livre de doença com corticoide<br>monoterapia em 6, 36 e 72 meses =<br>86,3%, 65,1% e 59,7%.|ocorreu em centro terciário.|
|||- Sem resposta|Tempo livre de doença com corticoide e||
|||- Tempo livre de doença (TLD)|RTX em 6,36 e 72 meses = 92,3%, 58,7%<br>e 44,1%.||  
43  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||||8 pacientes refratários a várias linhas de<br>tratamento – administrado RTX baixas<br>doses = resposta em 100% (3 com RC e 5<br>com RP).<br>Resposta em 16 dias em média, com 75%<br>de probabilidade de remissão sustentada<br>em 103 meses.||
|_Fattizzo et_<br>_al,_<br>_2019(9)_|Estudo prospectivo para<br>avaliar a eficácia de RTX em<br>doses baixas na AHAIq e na<br>CAD, tendo como base estudo<br>anterior de 10 anos.<br>n= 54<br>(20 do primeiro estudo e 34<br>adicionais)<br>AIHA= 27|AHAIq: RTX – 100 mg/semana por 4<br>semanas com corticoide.<br>CAD: RTX – 100 mg/semana por 4<br>semanas com corticoide.<br>Recaídas tratadas com diferentes<br>medicamentos.<br>Desfechos:<br>- Resposta geral.<br>- Resposta completa.|Resposta ao tratamento em ~80% na<br>AHAIq e em ~50% na CAD no estudo<br>anterior de acompanhamento por 10 anos,<br>com 50% de redução de corticoide.<br>Mesmo resultado para o estudo atual:<br>reposta geral acima de 80%<br>Resposta completa aumenta de 46% em 2<br>meses para mais que 60% em 6 meses e<br>mais.|Não é um ECR.<br>Análise prospectiva.|
||CAD= 20<br>(Outros com AHAI mista ou<br>atípica).<br>Seguimento médio de 53<br>meses.|- Tempo livre de doença/recaída (TLD).|Tempo livre da doença dependente do tipo<br>de AHAI.<br>AHAIq – 64 meses (95% IC 26,6-102)<br>Outras AIHA – 25 meses (95% IC 9,4-<br>41,6) p= 0,004.||
|_Ducassou_<br>_et al,_|Estudo prospectivo para<br>avaliar a eficácia e a tolerância|2ª linha de tratamento:<br>RTX – 375 mg/m<sup>2</sup>/semana por 4 semanas|Resposta em 75% dos pacientes. Permite a<br>parada do corticoide.|Estudo prospectivo.|
|_2017(10)_||IV em 50 pacientes.|Resposta completa=40||  
44  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||do RTX, como segunda linha<br>de tratamento na AHAI.<br>Crianças.<br>N= 61<br>Seguimento médio de 4 anos.<br>Obs: Pacientes com AHAI<br>isolada ou Síndrome de Evans<br>.|Demais pacientes com menos ou mais<br>doses, conforme o julgamento clínico.|Resposta parcial= 6<br>Tempo livre de doença – 48% em 6 anos.<br>Recaída em 43% (tratados com diferentes<br>medicamentos).<br>No final do seguimento - 33%<br>continuavam em remissão completa.<br>AHAI isolada: Resposta completa e tempo<br>livre de doença apresentam diferença<br>significativamente maior que na Síndrome<br>de Evans (p < 0,05).<br>5 pacientes com síndrome de Evans<br>morreram.<br>1 caso provavelmente relacionado ao uso<br>de RTX.||
|_Fu et al,_|Estudo retrospectivo de centro|Grupo A: Ciclofosfamida + corticoide.|Resposta completa Grupo A = 42,1%|Estudo retrospectivo.|
|_2016(11)_|único para avaliar a eficácia e<br>tolerância da comparação<br>entre pulsoterapia com<br>ciclofosfamida x RTX em<br>dose baixa em adultos com<br>AHAI refratária.<br>N=49|X<br>Grupo B: RTX dose baixa + corticoide.<br>Desfechos:<br>- Resposta completa<br>- Tempo livre de doença<br>- Tolerância|(8/19)<br>X<br>Resposta completa Grupo B = 78,9%<br>(15/19). P= 0,04, após 6 meses de<br>tratamento.<br>Tempo livre de doença Grupo A = 87,9%<br>em 6 meses e 82,7% em 12 meses<br>X|Número amostral pequeno em<br>cada grupo.|  
45  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||||Grupo B= 92,1 em 6 meses e 86% em 12<br>meses (p=0,81 – diferença não<br>significativa).<br>Medicamentos bem tolerados.||
|_Laribi et_<br>_al,_|Série de casos para avaliar<br>eficácia e segurança do RTX|RTX – 375 mg/m<sup>2</sup>/semana por 4 semanas.<br>Pacientes haviam recebido de 1 a 5|Resposta geral após 1º curso de RTX =<br>86,9% (20/23).|Estudo retrospectivo de série de<br>pacientes.|
|_2016(12)_|em pacientes idosos com|tratamentos prévios.|RC= 39,1%|Número amostral pequeno.|
||recaída de AHAIq resistente.|Desfechos:|RP= 47,8%||
||N= 23|- Resposta geral|2 meses de seguimento.||
||Seguimento médio de 31<br>meses.|- Resposta completa<br>- Resposta parcial<br>- Sobrevida geral|Sobrevida média geral= 87 meses.<br>Sobrevida livre de progressão = 89% e<br>72% em 1 e 2 anos, respectivamente.<br>Recaída= 40% após 6 meses.<br>7 pacientes que recaíram foram tratados de<br>novo com RTX – com resposta de 57,1%.<br>Tratamento bem tolerado.||
|_Reynaud_|Meta-análise de 21 estudos|2ª linha – RTX – 375 mg/m<sup>2</sup>/semana por 4|Resposta geral= 73% (95% IC 64-81%, 20|Difícil comparar taxas de|
|_et al,_|sobre a eficácia e segurança|semanas.|estudos com 402 pacientes).|resposta de diferentes estudos.|
|_2014(13)_|do RTX na AHAI.<br>N= 21|50% tratados com corticoide concomitante.<br>Desfechos:|Resposta completa= 37% (95% IC 26-<br>49%, 20 estudos com 397 pacientes) - alta|Falta randomização e<br>concordância precisa dos|
||(409 pacientes adultos e|- Resposta geral|heterogeneidade entre estudos – I<sup>2</sup>=72%,|desfechos.|
||crianças).|- Resposta completa|p< 0,0001).|Qualidade dos estudos variam.|
||Incluídos:|- Recaídas|Resposta geral ~70 % para wAIHA - 79%|Viés de publicação.|
||n= 12 estudos prospectivos.|- Eventos adversos graves.|(95% IC 60-90%, 11 estudos, 154||  
46  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||n= 8 estudos retrospectivos.<br>n= 1 ECR<br>Mais adultos e com AHAIq<br>primária aqui representados.||pacientes); para AHAI primária= 67%<br>(95% IC 49-81%, 10 estudos, 161<br>pacientes); para AHAI secundária= 72%<br>(95% IC 60-82%,8 estudos, 66 pacientes).<br>Resposta completa= 42% para wAIHA<br>(95% IC 27-58%, 11 estudos, 154<br>pacientes); para AHAI primária= 32%<br>(95% IC 1-51, 11 estudos, 176 pacientes);<br>para AHAI secundária= 46% (95% IC 30-<br>62%, 9 estudos, 87 pacientes); para CAD=<br>apenas 21% (95% IC 6-51%, 7 estudos,<br>118 pacientes).<br>Resposta completa após RTX em 2 a 4<br>meses = 70% (57-80%); 13 estudos, 203<br>pacientes.<br>Toxicidades= 14% (95% IC 9-21%). Bem<br>tolerado.<br>Mortes 4,6% (17/364) durante<br>seguimento.|Heterogeneidade dos estudos e<br>das populações.<br>Estudos com número amostral<br>pequeno.<br>Estudos sem tempo de<br>seguimento longo.|
|_Barcellini_<br>_et al,_|Estudo retrospectivo que<br>avaliou a heterogeneidade|1ª linha para AHAIq = Corticoide|Resposta geral à 1ª linha= 75% com RC<br>nos casos leves e 50% sem necessidade de|Grande heterogeneidade clínica;|
|_2014(14)_|clínica da AHAI primária e<br>preditores de desfechos.<br>Grupo de estudos GIMEMA.|Doença mista ou atípica= 2 ou mais linhas<br>de tratamento (esplenectomia,<br>imunossupressores e RTX).|mais tratamento (n=277)<br>Rituximabe (n=74)|Estudo retrospectivo porém, com<br>número amostral considerável.|  
47  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||N= 308<br>Seguimento de 33 meses.<br>AHAIq= 60%<br>CAD= 27%<br>Mista= 8%<br>Atípica= 5|RTX em doses convencionais (n=55) e em<br>baixas doses (n=19).<br>Principalmente em pacientes com CAD ou<br>doença atípica como 2ª ou mais linhas (25%<br>dos casos).<br>- Resposta completa (RC)<br>- Resposta parcial (RP)<br>- Morte<br>- Ocorrência de infecções<br>-Falta de resposta ou recaída|-<br>Doses convencionais:<br>OR= 80% (RC= 44% e RP-=<br>36%).<br>-<br>Doses baixas: OR= 84%<br>(RC= 68% e RP= 16%), exceto<br>para CAD que apresenta maiores<br>taxas de RP.<br>CAD= resposta geral de 80%, metade com<br>resposta completa. Melhor usar doses<br>convencionais de RTX para CAD.<br>Esplenectomia (n=32), OR=75%, recidiva<br>em 33% dos casos<br>Azatioprina (n= 31), OR=71% (29% CR e<br>42% PR), ciclofosfamida (n=40) OR 72%<br>(38% CR e 38% PR), ciclosporina (n=12)<br>CR e PR em 42% e 17% dos casos,<br>micofenolato de mofetila (n=2) 2CR||
|_Roumier et_<br>_al,_<br>_2014(15)_|Estudo de coorte retrospectivo<br>de centro único para avaliar as<br>características e desfechos da<br>AHAIq em adultos.<br>N=60<br>AHAIq primária= 35%<br>AHAIq secundária= 65%|1ª linha= corticoides (n=58).<br>Corticoide dependentes= 63%<br>Necessidade de 2ª linha de tratamento= 56%<br>RTX em n=19<br>(RTX – n=15 – 375 mg/m<sup>2</sup>/semana/4<br>semanas).|Remissão e sem tratamento após<br>seguimento= 47% (n=28).<br>Mortes= 8% (n=5).<br>Resposta geral= 80%<br>Recaída em 50% (n=10) após 14 meses<br>em média.|Estudo retrospectivo.|  
48  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**<br>**DESFECHOS**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
||Seguimento de 46 meses|RTX n= 10 – 1.000 mg a cada 2 semanas de<br>intervalo).<br>RTX promissor como 2ª linha.|||
|_Barcellini_<br>_et al,_<br>_2012(16)_|Estudo retrospectivo<br>multicêntrico, de fase II, braço<br>único sobre a eficácia,<br>segurança e a duração de<br>resposta ao RTX em baixas<br>doses a AHAI.<br>N=23<br>AIHA primária.<br>Seguimento em média de 15<br>meses.|RTX – 100 mg dose fixa por semana, por 4<br>semanas + corticoide como 1ª ou 2ª linhas<br>de tratamento.<br>Desfechos:<br>-Resposta geral<br>- Sobrevida livre de recaídas.|Resposta geral= 82,6% em 2 meses e 90%<br>posteriormente.<br>Melhor resposta na AHAIq (100%) x<br>CAD (55,6%) em 2 meses.<br>Sobrevida livre de recaída:<br>Em 6 e 12 meses = 96% e 86%.<br>Em 2 anos= 68%.<br>AHAIq= 100% em 6 e 12 meses.<br>CAD= 89% e 59%, respectivamente. P=<br>0,015.<br>Em 2 anos= 81% x 40% para AHAI e<br>CAD, respectivamente.<br>Maior risco de recaída= CAD|Estudo retrospectivo.<br>Número amostral pequeno.|
|_Berentsen_<br>_et al,_<br>_2010(17)_|Estudo prospectivo<br>multicêntrico para avaliar a<br>alta taxa de resposta e a<br>duração da remissão, após a<br>combinação terapêutica de<br>fludarabina e RTX para CAD<br>crônica<br>N=29|RTX – 375 mg/m<sup>2</sup>nos dias 1, 29, 57 e 85.<br>+<br>Fludarabina – 40 mg/m<sup>2</sup>via oral nos dias 1-<br>5, 29-34, 57-61 e 85-89.|Resposta geral= 76% (n=22).<br>(RC= 21% - 6 e RP= 55% - 16).<br>Sem resposta= 24% (7).<br>Duração estimada de resposta maior que<br>66 meses.<br>Toxicidade maior da combinação x RTX<br>sozinho.|Não é ECR.<br>Difícil ter ECR em doenças raras.<br>Precaução quanto à interpretação<br>dos resultados.|  
49  
|**ESTUDO**|**DESENHO**|**INTERVENÇÃO E**|**RESULTADOS**|**LIMITAÇÕES**|
|---|---|---|---|---|
|||**DESFECHOS**|||
||Adultos idosos.||||  
Legenda: ECR: ensaio clínico randomizado; R-CHOP – RTX: ciclofosfamida, doxorrubicina, vincristina, prednisona. R-CVP – RTX, ciclofosfamida, vincristina e prednisona. DRC – dexametasona, RTX e ciclofosfamida, AHAIq:  
Anemia Hemolítica Autoimune quente; RC: Resposta completa; CAD: Anemia hemolítica autoimune por anticorpos a frio (CAD – _cold agglutinin disease_ ); RP: Resposta Parcial; RG: Resposta geral, TR: Taxa de recidiva;  
50  
O **Quadro J** descreve os estudos selecionados para a síntese de evidências de rituximabe por desenho ou tipo.  
**Quadro J** . Estudos selecionados para a síntese de evidências de rituximabe por desenho ou tipo.  
|**TIPO DE ESTUDO**|**ESTUDOS**|
|---|---|
|Revisão sistemática e meta-análise|Liu, 2021;(2) Chao, 2020;(5) Reynaud, 2014(13)<br>Três ECR com MA|
|Diretrizes e Consensos|Ladogana, 2017(18); Jäger, 2019(19);Hill, 2017 (20).<br>Três diretrizes ou consensos|
|Estudo Observacional|Berentsen, 2020(4)<br>Um estudo observacional|
|Estudo casos Prospectivo|Arora, 2021(1); Fattizzo, 2019(9); Ducassou, 2017(10); Berentsen, 2010(17)<br>Quatro estudos de caso|
|Estudo de casos Retrospectivo|Jia, 2020(3); López-Vidal, 2019(6); Yilmaz, 2019(7); Jaime-Pérez, 2019(8); Fu,<br>2016(11); Laribi, 2016(12); Barcellini, 2014(14); Roumier, 2014(15); Barcellini.<br>2012(16).<br>Nove estudos retrospectivos|  
Parecer das agências de ATS e diretrizes internacionais  
Adicionalmente, foi conduzida busca nas agências de avaliação de tecnologias em saúde, utilizando como termo para a busca “rituximab”, sendo localizado somente uma recomendação:  
**O** **_National Institute for Health and Care Excellence_ (NICE) da Inglaterra e País de Gales** avaliou que a evidência de alta qualidade para o tratamento de AIHA com rituximabe é limitada. Basearam-se na revisão com meta-análise de Reynaud de 2014 com apenas um ensaio clínico randomizado (Birgens, 2013) e 20 estudos pequenos, não controlados e heterogêneos, o que seria a melhor evidência disponível para o uso do medicamento. Esses estudos não controlados têm número amostral pequeno e tratam dois tipos diferentes de AIHA, em diferentes populações com desfechos não uniformes, tornando difíceis as comparações das respostas relatadas e a possibilidade de se chegar a conclusões firmes de evidência. O uso de rituximabe para tratamento da AIHA não é aprovado em bula nesses países<sup>21</sup> .  
Também foram encontrados 2 consensos e uma Diretriz.  
No **Consenso Internacional** de Jäger de 2019, um grupo de especialistas avaliou o tratamento dos dois tipos de anemia autoimune, com anticorpos quentes (AIHAq) e com anticorpos frios (CAD)<sup>19</sup> .  
O grupo orienta uso de prednisolona como primeira linha de tratamento para AIHAq, associando rituximabe nos casos graves e precocemente. A resposta geral ao tratamento dos ensaios clínicos randomizados foi de 75% com os dois medicamentos enquanto a monoterapia com rituximabe foi de cerca de 35%. Como segunda linha, o uso de rituximabe é recomendado, com resposta geral de 79%.  
Para a anemia hemolítica por anticorpos a frio (CAD), orientam uso de rituximabe com ou sem bendamustina, como primeira linha de tratamento, obtendo uma resposta geral de 50%. Para a segunda linha de tratamento desse tipo de anemia hemolítica, orientam repetir rituximabe ou associar bendamustina ou fludarabina.  
No **Consenso para diagnóstico e tratamento de crianças com AIHA** , o Grupo de Estudos de Célula Vermelha da Associação Italiana de hemato-oncologia pediátrica (Ladogan, 2017) recomenda o tratamento de primeira linha para wAIHA com corticoide e outras modalidades, conforme clínica apresentada (imunoglobulina, transfusão, plasmaférese). A segunda linha também é com corticoide. O rituximabe não foi utilizado para a AIHAq (18).  
51  
Para a CAD, como não há boa resposta ao corticoide, orientam uso de rituximabe como primeira linha, já que é eficaz e seguro. Há resposta em 45 a 60% dos casos, que pode aumentar com a associação com fludarabina.  
**Nas Diretrizes de Hill at al,** de 2017, do diagnóstico e tratamento da AIHA primária, há uma divisão em terapia de resgate (emergência) e cuidado sem emergência. A investigação de possível causa para ser afastada e transfusão de sangue, conforme gravidade da anemia, devem ser realizadas na emergência, enquanto o tratamento de resgate da AIHAq pode incluir imunoglobulina IV, plasmaferese, metilprednisolona e esplenectomia. Para o tratamento de resgate da CAD, sugerem plamaferese, já que não há boa resposta aos corticoides.  
Para o tratamento fora das situações de emergência, há recomendações preventivas de tromboembolismo venoso, osteoporose e proteção gástrica. Para o tratamento da AIHAq primária, a primeira linha são os corticoides e, se não houver resposta, sugerem como segunda linha de tratamento o rituximabe. Para a terceira linha de tratamento, sugerem em ordem alfabética, mostrando a não preferência por nenhuma terapia em particular: azatioprina, ciclosporina, danazol, micofenolato e esplenectomia. Para falha da terceira linha, citam alemtuzumabe, ciclofosfamida, transplante de células tronco.  
Para o tratamento da CAD, recomendam que evitar exposições ao frio é essencial, já que ela é menos responsiva ao tratamento medicamentoso do que a AIHAq. Como primeira linha de tratamento, sugerem rituximabe e associação com fludarabina, se necessário. (20)  
**REFERÊNCIAS:** 1. Arora et al. Autoimmune hemolytic anemia in children: Clinical presentation and treatment outcome. Asian Journal of transfusion Science; 2021.  
2. Liu A-yP CD. Disease‐modifying treatments for primary autoimmune haemolytic anaemia. Cochrane2021.  
3. Jia MN, Qiu Y, Wu YY, Cai H, Zhou DB, Cao XX, et al. Rituximab-containing therapy for cold agglutinin  
disease: a retrospective study of 16 patients. Sci Rep. 2020;10(1):12694.  
4. Berentsen S, Barcellini W, D'Sa S, Randen U, Tvedt THA, Fattizzo B, et al. Cold agglutinin disease revisited: a multinational, observational study of 232 patients. Blood. 2020;136(4):480-8.  
5. Chao et al. Ce. Efcacy and safety of rituximab in autoimmune and microangiopathic hemolytic anemia: a systematic review and meta-analysis. . Exp Hematol Oncol (2020) 9:6 ed2020.  
6. López-Vidal H, Peña C, Gajardo C, Valladares X, Cabrera C ME. Anemia hemolítica autoinmune en Chile:  
un análisis retrospectivo de 43 pacientes / Autoimmune hemolytic anemia: review of 43 cases. Rev. méd. Chile; 2019. p. _83641_ .  
7. Yılmaz F, Kiper D, Koç M, Karslı T, Kılınç M, Gediz F, et al. Clinical Features and Treatment Outcomes of Warm Autoimmune Hemolytic Anemia: A Retrospective Analysis of 60 Turkish Patients. Indian J Hematol Blood Transfus. 2019;35(3):523-30.  
8. Jaime-Pérez JC, Aguilar-Calderón P, Salazar-Cavazos L, Gómez-De León A, Gómez-Almaguer D. Treatment of autoimmune hemolytic anemia: real world data from a reference center in Mexico. Blood Res. 2019;54(2):131-6.  
9. Fattizzo B, Zaninoni A, Pettine L, Cavallaro F, Di Bona E, Barcellini W. Low-dose rituximab in autoimmune  
hemolytic anemia: 10 years after.  Blood. 133. United States2019. p. 996-8.  
10. Ducassou S, Leverger G, Fernandes H, Chambost H, Bertrand Y, Armari-Alla C, et al. Benefits of rituximab as a second-line treatment for autoimmune haemolytic anaemia in children: a prospective French cohort study. Br J Haematol. 2017;177(5):751-8.  
52  
11. Fu R, Yan S, Wang X, Wang G, Qu W, Wang H, et al. A monocentric retrospective study comparing pulse  
cyclophosphamide therapy versus low dose rituximab in the treatment of refractory autoimmune hemolytic anemia in adults. Int J Hematol. 2016;104(4):462-7.  
12. Laribi K, Bolle D, Ghnaya H, Sandu A, Besançon A, Denizon N, et al. Rituximab is an effective and safe  
treatment of relapse in elderly patients with resistant warm AIHA. Ann Hematol. 2016;95(5):765-9.  
13. Reynaud Q, Durieu I, Dutertre M, Ledochowski S, Durupt S, Michallet AS, et al. Efficacy and safety of  
rituximab in auto-immune hemolytic anemia: A meta-analysis of 21 studies. Autoimmun Rev. 2015;14(4):304-13.  
14. Barcellini W, Fattizzo B, Zaninoni A, Radice T, Nichele I, Di Bona E, et al. Clinical heterogeneity and  
predictors of outcome in primary autoimmune hemolytic anemia: a GIMEMA study of 308 patients. Blood. 2014;124(19):29306.  
15. Roumier M, Loustau V, Guillaud C, Languille L, Mahevas M, Khellaf M, et al. Characteristics and outcome of warm autoimmune hemolytic anemia in adults: New insights based on a single-center experience with 60 patients. Am J Hematol. 2014;89(9):E150-5.  
16. Barcellini W, Zaja F, Zaninoni A, Imperiali FG, Battista ML, Di Bona E, et al. Low-dose rituximab in adult  
patients with idiopathic autoimmune hemolytic anemia: clinical efficacy and biologic studies. Blood. 2012;119(16):3691-7.  
17. Berentsen S, Randen U, Vågan AM, Hjorth-Hansen H, Vik A, Dalgaard J, et al. High response rate and durable  
remissions following fludarabine and rituximab combination therapy for chronic cold agglutinin disease. Blood. 2010;116(17):3180-4.  
18. Ladogana S, Maruzzi M, Samperi P, Condorelli A, Casale M, Giordano P, et al. Second-line therapy in paediatric warm autoimmune haemolytic anaemia. Guidelines from the Associazione Italiana Onco-Ematologia Pediatrica (AIEOP). Blood Transfus. 2018;16(4):352-7.  
19. Jäger U, Barcellini W, Broome CM, Gertz MA, Hill A, Hill QA, et al. Diagnosis and treatment of autoimmune  
hemolytic anemia in adults: Recommendations from the First International Consensus Meeting. Blood Rev. 2020;41:100648.  
20. Hill Q.A, Stamps R, Massey E, Grainger J.D, Provan D and Hill A. The diagnosis and management of primary autoimmune haemolityc anaemia. British Journal of Haematology, 2017, 176, 395-411.  
21. NICE Guidance. Autoimmune haemolytic anaemia: rituximab. Evidence summary [ESUOM39] Published: 10 February 2015. Disponível em: www.nice.org.uk/guidance/esuom39.  
53  
**APÊNDICE 2 - HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO**  
|**Número**<br>**do**<br>**Relatório**<br>**da**||**Tecnologias avaliadas pela C**|**onitec**|
|---|---|---|---|
|**diretriz clínica (Conitec) ou**|**Principais alterações**|**Incorporação ou alteração**|<br>**Não incorporação ou não**|
|**Portaria de Publicação**||**do uso no SUS**|**alteração no SUS**|
|Relatório de Recomendação nº<br>941/2024|Atualização de Conteúdo|-|-|
|Portaria<br>Conjunta<br>SAS-||||
|SCTIE/MS nº 27, de 26 de<br>novembro de 2018|Primeira versão do documento|-|-|  
54

---

