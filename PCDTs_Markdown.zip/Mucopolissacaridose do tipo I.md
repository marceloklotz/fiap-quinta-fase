<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL  
DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 6, DE JUNHO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Mucopolissacaridose do tipo I.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhe confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Mucopolissacaridose do tipo I no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup>º</sup> 980/2025 e o Relatório de Recomendação nº 983/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Mucopolissacaridose do tipo I.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Mucopolissacaridose do tipo I, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Mucopolissacaridose do tipo I.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 12, de 11 de abril de 2018, publicada no Diário Oficial da União (DOU) nº 74, de 18 de abril de 2018, seção 1, página 95.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: MOZART JULIO TABOSA SALES -->
FERNANDA DE NEGRI

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **INTRODUÇÃO** -->
A mucopolissacaridose do tipo I (MPS I) é uma doença lisossômica de caráter progressivo e herança autossômica recessiva, causada pela atividade deficiente da alfa-L-iduronidase (IDUA), enzima codificada pelo gene _IDUA_ , localizado no cromossomo 4p16.3<sup>1</sup> . A enzima IDUA é responsável pela clivagem dos resíduos de ácido idurônico dos glicosaminoglicanos (GAGs), heparan e dermatan sulfato.  
Na MPS I ocorre o acúmulo de GAGs parcialmente degradados no interior dos lisossomos e o aumento da sua excreção na urina<sup>2</sup> . Em consequência deste acúmulo, os pacientes apresentam comprometimento multissistêmico, em particular nos sistemas respiratório, nervoso, musculoesquelético, gastrointestinal (fígado e baço) e cardiovascular, entre outros.  
A MPS I está associada a três formas clássicas, que diferem entre si pela presença de comprometimento neurológico, pela idade de apresentação do quadro clínico, pela velocidade de progressão da doença e pela gravidade do acometimento dos órgãosalvo<sup>2</sup> :  
- **Forma grave (síndrome de Hurler)** : em geral, os pacientes são diagnosticados até os 2 anos de idade, apresentam atraso de desenvolvimento cognitivo aparente entre os 14 e 24 meses e estatura geralmente inferior a 110 cm. A história clínica é dominada por problemas respiratórios, pois a maioria das crianças apresenta história de infecção de vias aéreas, otite média recorrente e rinorreia. É o fenótipo mais grave da MPS I<sup>3</sup> , envolvendo ainda características faciais, hepatoesplenomegalia, valvulopatia cardíaca, opacificação de córnea, hidrocefalia, hérnias abdominais, melanocitose e manifestações musculoesqueléticas, como rigidez, contraturas e disostose múltipla. A cifose toracolombar, chamada de giba, costuma ser uma das primeiras alterações musculoesqueléticas, surgindo em média com 1 ano de idade<sup>3,4</sup> . O óbito ocorre geralmente durante a primeira década de vida<sup>4</sup> , por insuficiência cardíaca ou respiratória;  
- **Forma intermediária ou moderada (síndrome de Hurler-Scheie)** : esses pacientes costumam apresentar evidência clínica da doença entre os 3 e 8 anos de idade. A baixa estatura final é relevante, podendo não ter déficit intelectual e sendo comum a sobrevivência até a idade adulta<sup>4</sup> ;  
- **Forma atenuada (síndrome de Scheie)** : início dos sintomas entre os 5 e 15 anos de idade e progressão lenta. O curso clínico é dominado por problemas ortopédicos e a altura final é normal ou quase normal, assim como o tempo de vida. A doença cardíaca pode reduzir a sobrevida desses pacientes<sup>4</sup> .  
Essa classificação é bastante utilizada, embora existam pacientes com apresentações clínicas mistas, ou seja, em que há sobreposição das manifestações das diferentes formas. Atualmente, cada fenótipo é considerado como parte de um espectro contínuo de uma mesma doença<sup>4</sup> . Dados mundiais sugerem que o fenótipo mais grave é o mais comum<sup>5-7</sup> . Contudo, dados latinoamericanos sugerem que, nessa região, o fenótipo atenuado é o mais prevalente e que a síndrome de Hurler corresponde a 31% dos casos diagnosticados<sup>7-9</sup> .  
A variabilidade clínica associada à MPS I é reflexo, em parte, da variação da atividade enzimática associada a diferentes genótipos. Quadros mais graves estariam associados a uma menor atividade enzimática, assim como quadros mais leves estão associados a maior atividade da enzima. Os testes clínicos e bioquímicos, apesar de serem úteis para a confirmação do diagnóstico, podem não predizer a gravidade da doença<sup>4</sup> . Fatores como a idade de início dos sintomas, a presença de duas mutações associadas à ausência de atividade enzimática (mutações nulas como p.Trp402Ter e p.Gln70Ter) e de características clínicas específicas (como giba e atraso no desenvolvimento) são utilizados para determinar com mais precisão, a doença grave ou síndrome de Hurler<sup>4</sup> .  
A incidência mundial da MPS I é bastante variável, sendo estimada entre 0,69 a 1,66 por 100.000 pessoas<sup>2, 5, 6, 10-13</sup> . Contudo, dados de triagem neonatal demonstraram que a incidência pode ser maior, variando entre 1: 7.353 (estado de Washington, EUA)<sup>14</sup> e 1:14.567 (Missouri, EUA)<sup>15</sup> . A prevalência desta doença parece ser mais elevada no Reino Unido, Holanda, Alemanha e Austrália<sup>16</sup> .  
Até 2021, um total de 223 mutações foram identificadas no Human Gene Mutation Database, a maior proporção pertencente ao grupo de mutações missense/nonsense<sup>16</sup> .  
Os alelos de significado patológico têm uma importante variabilidade de acordo com a etnicidade. As mutações mais frequentes em caucasianos são a p.W402X e p.Q70X<sup>1</sup> . O estudo de Pastores _et al_<sup>4</sup> , que avaliou dados clínicos de pacientes com MPS I a fim de caracterizar a evolução natural da doença, verificou que a distribuição entre os sexos masculino e feminino foi semelhante, como esperado para uma doença autossômica recessiva. A maioria dos pacientes avaliados era de origem caucasiana<sup>4</sup> .  
Existem poucos estudos epidemiológicos sobre a MPS I no Brasil. Segundo o registro internacional da doença (que inclui o Brasil) em 2010 foram registrados 891 pacientes com MPS I em todo o mundo, sendo 82 destes no Brasil<sup>17</sup> . Em 2020, um estudo estimou a prevalência ao nascimento (PN) de MPS I no Brasil em 0,95/100.000 nascidos vivos<sup>18</sup> . No ano seguinte, um estudo publicado estimou, entre os nascidos de 1994 a 2018, 217 casos diagnosticados, sendo a incidência de 0,29/1000.000 nascidos vivos<sup>19</sup> . Na região Sul, essa incidência era a maior do país — 0,39/100.000 nascidos vivos<sup>19</sup> .  
Inexiste tratamento curativo para a MPS I até o momento<sup>20</sup> . Este Protocolo visa a nortear o diagnóstico, tratamento e acompanhamento de pacientes com MPS I no âmbito do Sistema Único de Saúde, incluindo a terapia de reposição (TRE) intravenosa (IV) com laronidase e o transplante de células-tronco hematopoiéticas (TCTH).  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E 76.0 Mucopolissacaridose do tipo I

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **DIAGNÓSTICO** -->
O diagnóstico de MPS I é realizado pela suspeita clínica, sendo confirmado por marcadores bioquímicos e teste genético (Figura 1).  
A Figura 1 apresenta o fluxograma de diagnóstico e tratamento da MPS I.  
**Figura 1.** Fluxograma de diagnóstico e tratamento da MPS I  
<!-- Start of picture text -->
Suspeita clínica = Sinais e/ou sintomas sugestivos de MPS I<br><!-- End of picture text -->  
<!-- Start of picture text -->
Suspeita clínica = Sinais e/ou sintomas sugestivos de MPS I<br>Atividade da IDUA <10% do limite inferior de referência (em plasma, fibroblastos ou<br>leucócitos)  +  atividade normal da enzima de referência (outra sulfatase) avaliada na<br>mesma amostra e pelo mesmo método  +  níveis aumentados de GAGs totais na urina<br>ou de excreção aumentada de sulfatos de heparan e dermatan;<br>OU<br>Atividade da IDUA <10% do limite inferior (plasma, fibroblastos, leucócitos ou em<br>papel-filtro)  +  atividade normal da enzima de referência (outra sulfatase) avaliada na<br>mesma amostra e pelo mesmo método  +  presença de mutações patogênicas em<br>homozigose ou heterozigose composta no gene IDUA.<br>Diagnóstico de MPS I confirmado<br>Tratamento de TRE com<br>Tratamento sintomático/de  Laronidase (após avaliação  Realização de TCTH (após<br>avaliação  adequada,<br>manifestações clínicas  adequada,  incluindo  os  incluindo  critérios  de<br>critérios  de<br>inclusão/exclusão)<br>inclusão/exclusão)<br>Diagnóstico<br>Tratamento<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **3.1. Diagnóstico clínico** -->
Deve-se suspeitar de MPS I se o paciente apresentar pelo menos um dos seguintes sinais e sintomas a seguir,  
especialmente se dois ou mais critérios estiverem presentes, excluindo-se outras causas mais frequentes<sup>23</sup> :  
- Características faciais sugestivas de doença lisossômica (face infiltrada);  
- Otite média e infecções respiratórias superiores precoces e de repetição;  
- Hérnia inguinal ou umbilical, especialmente se ambas estiverem pacientes e em crianças;  
- Hepatoesplenomegalia;  
- Alterações esqueléticas ou articulares típicas (disostose múltipla, giba, limitação da amplitude de movimento das  
articulações);  
- Mãos em garra;  
- Alterações oculares características (opacificação bilateral da córnea);  
- Síndrome do túnel do carpo em crianças;  
- Irmão de qualquer sexo com MPS I.  
Ressalta-se que os achados clínicos variam de acordo com a gravidade da doença e, por si só, não são diagnósticos<sup>23</sup> .  
Os sinais e sintomas mais comuns na MPS I em geral e nas formas clássicas da doença são apresentados, respectivamente,  
nos Quadros 1 e 2.  
**Quadro 1** - Sinais e sintomas gerais da Mucopolissacaridose do tipo I.  
|**Órgão/sistema**|**Manifestação clínica**|**Avaliação/tratamento**|
|---|---|---|
||Hidrocefalia/hipertensão intracraniana.|Avaliação neurocirurgia.<br>Derivação ventrículo-peritoneal.|
|Sistema nervoso central|Atraso do desenvolvimento<br>neuropsicomotor.|Avaliação neurológica.<br>Psicopedagogia, fonoaudiologia, fisioterapia,<br>psicomotricidade.|
||Crises convulsivas.|Avaliação neurológica.<br>Farmacoterapia.|
||Alterações no ciclo sono-vigília, distúrbios<br>do comportamento.|Avaliação neurológica.<br>Farmacoterapia.<br>Psicologia.|
||Compressão medular.|Avaliação neurocirurgia.<br>Cirurgia.|
|Sistema nervoso periférico|Síndrome do túnel do carpo.|Avaliação traumato-ortopedia.<br>Fisioterapia.<br>Cirurgia.|
|Olh|Acuidade visual diminuída.|Avaliação oftalmológica.|
|os|Opacificação de córnea.|Avaliação oftalmológica.<br>Transplante de córnea (em casos específicos).|
||Síndrome da apnéia obstrutiva do sono.|Avaliação pneumológica,<br>Amigdalectomia, adenoidectomia,<br>Oxigenioterapia.<br>Uso de aparelhos de pressão positiva contínua<br>das vias respiratórias (em casos específicos).|
|Vias aéreas|Infecções de repetição.|Avaliação pneumológica e<br>otorrinolaringológica.<br>Farmacoterapia.<br>Fisioterapia.|
||Doença pulmonar restritiva.|Avaliação pneumológica.<br>Farmacoterapia.<br>Fisioterapia.|
|Tecido conjuntivo|Hérnias.|Avaliação cirurgião.<br>Cirurgia.|
|Articulações|Dor, contraturas.|Avaliação traumato-ortopedia.<br>Farmacoterapia.<br>Fisioterapia.|
|||Cirurgia.|
|Ossos|Giba toracolombar, genu valgo.|Avaliação traumato-ortopedia.|  
|**Órgão/sistema**|**Manifestação clínica**|**Avaliação/tratamento**|
|---|---|---|
|||Coletes.<br>Cirurgia.|
||Hipoacusia.|Avaliação otorrinolaringológica.<br>Próteses (em casos específicos).|
|Orelhas|Otites de repetição.|Avaliação otorrinolaringológica.<br>Farmacoterapia.<br>Cirurgia.|
||Diarreia.|Avaliação gastroenterologiasta.<br>Orientação nutricional.|
|Gastrointestinal|Ganho inadequado (insuficiente ou<br>excessivo) de peso.|Avaliação gastroenterologiasta.<br>Orientação nutricional.|
||Distúrbio de deglutição.|Avaliação gastroenterologista.<br>Orientação nutricional<br>Farmacoterapia.<br>Fonoaudiologia.<br>Cirurgia (gastrostomia).|
|Bucomaxilofacial|Má oclusão, dentição anômala.|Avaliação odontológica ou de cirurgia<br>bucomaxilofacial.<br>Cirurgia.<br>Aparelho ortodôntico.|
|Cardiovascular|Valvulopatia, cardiomiopatia, insuficiência<br>cardíaca.|Avaliação cardiologia.<br>Farmacoterapia.<br>Cirurgia.|  
Fonte: Elaboração com base em Clarke, 2024<sup>23</sup> e Hampe at al, 2020<sup>24</sup>  
**Quadro 2** - Características mais frequentes das formas clássicas da Mucopolissacaridose do tipo I.  
|**Nome**<br>Doença esquelética, dep|**Herança**<br>ósitos em tecido mole e|**Deficiência**<br>**Enzimática**<br>espectro de alterações de|**Gene**<br>SNC|**Substrato**<br>**acumulado**|**Idade de**<br>**diagnóstico**|**Aspectos distintos centrais**|
|---|---|---|---|---|---|---|
|Hurler<br>(forma grave)|Autossômica<br>Recessiva|Alfa-L-Iduronidase|IDUA|Sulfato de heparan,<br>sulfato de dermatan|1-2 anos|Atraso<br>no<br>desenvolvimento,<br>hepatoesplenomegalia,<br>obstrução<br>de<br>vias<br>aéreas,<br>características<br>faciais<br>infiltradas,<br>disostose multiplex.<br>Geralmente tranquilos e plácidos.<br>Óbito em torno dos 10 anos de idade|
|Hurler-Scheie<br>(forma intermediária)|||||1-5 anos|Micrognatia, faces infiltradas, marcha ‘toe<br>walker’ (na ponta dos pés), inteligência<br>possivelmente normal.<br>Óbito em torno dos 20 anos de idade.|
|Scheie<br>(forma menos severa)|||||3-15 anos|Doença valvular aórtica, doença articular,<br>opacificação corneana, fácies normal.<br>Óbito em décadas.|  
Fonte: Adaptado de Hahn S, 2022<sup>25</sup> .  
Legenda: SNC: sistema nervoso central; MPS: mucopolissacaridoses; IDUA: iduronidaseᵃ

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **3.2. Diagnóstico diferencial** -->
Os pacientes com MPS I, especialmente nos fenótipos atenuados, podem ser difíceis de serem reconhecidos por médicos não familiarizados com a doença, principalmente ao se considerar a constelação de manifestações diversas apresentadas por eles ao longo do tempo<sup>26</sup> .  
Um dos desafios no diagnóstico da MPS é que, inicialmente, as diversas características apresentadas podem ser avaliadas por diferentes especialistas, retardando o reconhecimento de que os problemas de saúde aparentemente não relacionados têm um único diagnóstico<sup>26</sup> . No paciente cuja principal manifestação é a doença do quadril, por exemplo, o diagnóstico diferencial pode incluir doença de Legg-Calvé-Perthes (LCP) e displasia espondiloepifisária (SED)<sup>26,27</sup> .  
Se o atraso no desenvolvimento e os problemas de comportamento forem as principais características apresentadas, o diagnóstico diferencial incluiria o transtorno de déficit de atenção e hiperatividade (TDAH) e o transtorno do espectro do autismo (TEA). Existem ainda outros distúrbios a serem considerados no diagnóstico diferencial, como turvação da córnea, apneia obstrutiva do sono, perda auditiva e cifoescoliose<sup>26,27,28</sup> .  
Uma vez que a constelação de achados é reconhecida como tendo uma causa subjacente comum, os principais distúrbios no diagnóstico diferencial são outras doenças de armazenamento, incluindo as oligossacaridoses (por exemplo, alfa e betamanosidose, fucosidose, aspartilglucosaminúria), esfingolipidoses (por exemplo, doença de Gaucher tipo II), doença de Niemann Pick A, mucolipidoses (por exemplo, doença das células I) e até mesmo outros tipos de MPS, como a Síndrome de Morquio (MPS IV). A análise urinária de GAGs e oligossacarídeos ajuda a diferenciar esses distúrbios<sup>23,25</sup> .  
Há relatos de pacientes com MPS I que receberam diagnósticos equivocados como raquitismo, nanismo e artropatia juvenil, a despeito de haver diferenças entre MPS I e estas doenças<sup>25-31</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **3.3. Diagnóstico laboratorial** -->
O caminho da confirmação diagnóstica de MPS I (Figura 1) envolve métodos bioquímicos ou genéticos<sup>24,25,26</sup> .  
A pesquisa de GAGs urinários, quantitativo ou qualitativo, costuma ser o primeiro exame a ser realizado na maioria dos casos suspeitos de MPS I em locais onde não se faz triagem neonatal. A alteração nesses exames não é capaz de estabelecer o diagnóstico de MPS I, mas indica a possibilidade real de algum tipo de mucopolissacaridose. O diagnóstico definitivo da MPS I requer o teste de atividade da enzima IDUA, realizado em leucócitos ou fibroblastos, por exemplo. Se demonstrada baixa atividade da enzima, tem-se o diagnóstico de MPS I.  
O teste genético molecular é frequentemente usado para confirmar o diagnóstico, detectando mutações causadoras de doenças no gene _IDUA._ Este teste, porém, está disponível apenas em serviços de diagnóstico com laboratórios especializados.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **3.3.1. Atividade da enzima IDUA** -->
A redução ou ausência de atividade da IDUA em fibroblastos, leucócitos, sangue impregnado em papel-filtro ou plasma sugere fortemente o diagnóstico de MPS I, mas não é suficiente para confirmação como teste único, pela possibilidade de ocorrência de pseudo deficiência - presença de atividade diminuída da enzima em indivíduo normal, devido ao uso de substratos artificiais da enzima no ensaio<sup>32,33</sup> .  
A medida da atividade enzimática em gotas de sangue impregnadas em papel-filtro<sup>34</sup> tem a vantagem de ser realizada em um material mais facilmente transportado e manipulado. Contudo, deve-se considerar o método de triagem, devido aos casos falso-positivos associados. No estudo de Verma et al.<sup>35</sup> , houve concordância de 88% da atividade da IDUA em pacientes com MPS I medida em papel-filtro com aquela encontrada em outros tecidos, de modo que os casos falso-positivos foram 12%. Em relação à estabilidade da IDUA em papel-filtro, outro estudo mostrou que a atividade da enzima diminui consideravelmente após 21 dias da realização da coleta<sup>36</sup> . A medida da atividade da IDUA em vilo coriônico cultivado ou amniócitos é rotineiramente utilizada no diagnóstico pré-natal de MPS I<sup>37</sup> .  
Como os resultados podem diferir entre os laboratórios, é importante que valores de referência sejam estabelecidos para cada serviço<sup>36,37,38</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **3.3.2. Análise de GAGs urinários** -->
A análise de GAGs urinários pode ser quantitativa, como pelo método espectrofotométrico<sup>39</sup> , ou permitir a identificação do tipo de GAGs que está sendo excretado em quantidade aumentada na urina, por cromatografia ou eletroforese<sup>32,39</sup> . Nem o método quantitativo nem o qualitativo são suficientes para predizer se a enzima deficiente é a lisossômica, pois não são específicos e o aumento de sulfato de heparan e de dermatan ocorre também nas MPS II e VII. No entanto, a detecção, por um ou por ambos os métodos, sugere a presença provável de algum tipo de MPS, sendo necessária a realização de testes adicionais.  
A quantificação de GAGs urinários também é utilizada para monitorização do tratamento específico da MPS I, uma vez que, durante o tratamento, ocorre diminuição da excreção dessas moléculas<sup>23,25</sup> . Salienta-se que os níveis de GAGs não podem ser considerados como marcadores de gravidade da doença<sup>32</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **3.3.3. Teste genético** -->
A análise do gene _IDUA_ permite a detecção das mutações que provocam a doença e, consequentemente, o diagnóstico genético pré e pós-natal e a detecção de heterozigotos, facilitando o aconselhamento genético individual e familiar.  
A taxa de detecção de variantes patogênicas por sequenciamento pelo método Sanger das regiões exônicas e éxon-íntron do gene _IDUA,_ em 85 indivíduos<sup>40</sup> e em 102 indivíduos<sup>41</sup> com MPS I, variou entre 95% e 97%.  Até o momento cerca de 250 diiferentes mutações já foram descritas no gene _IDUA_<sup>42</sup> , o qual possui 14 éxons.  
As duas mutações patogênicas mais comuns em pacientes brasileiros são p.Trp402Ter (éxon 9) e p.Pro533Arg (éxon 11), com frequências variando de 27,8% a 37% e de 11,6% a 33%<sup>43</sup> , respectivamente. As mutações p.Gln70Ter e p.Arg89Gln, relatadas como de alta frequência em pacientes com MPS I de outras regiões, estão presentes em frequências relativamente baixas nos pacientes brasileiros (1,6% e 3,3%, respectivamente)<sup>44</sup> . Ainda, a mutação p.Gln70Ter não foi identificada em outro estudo<sup>43</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **3.4. Associação genótipo-fenótipo clínico** -->
A maior importância dos estudos de genótipo-fenótipo é a identificação, em idade precoce, daqueles indivíduos que apresentarão a forma grave da doença. Apesar disso não estar estabelecido para todas as mutações já descritas, existe uma associação entre genótipo-fenótipo em algumas mutações<sup>23,40,41,44</sup> .  
Os pacientes recém-nascidos pré-sintomáticos ou oligossintomáticos com deficiência de IDUA e mutações graves conhecidas (p.Trp402Ter, p.Gln70Ter, p.Ala327Pro e p.Gly51Asp, por exemplo) identificadas em ambos os alelos, ou seja, homozigotos ou heterozigotos compostos, desenvolverão a MPS I grave<sup>40,41,44</sup> . As mutações p.Arg89Trp e p.Leu492Pro, por outro lado, associam-se a quadros atenuados da doença<sup>40,41,43,44</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo e para o uso de laronidase, todos os pacientes com diagnóstico confirmado de MPS I conforme um dos seguintes critérios:  
>  Atividade da enzima IDUA menor que 10% do limite inferior de referência em plasma, fibroblastos ou leucócitos, com a atividade da enzima de referência avaliada na mesma amostra e pelo mesmo método, apresentando valores normais E presença de níveis aumentados de GAGs totais na urina ou de excreção aumentada de sulfatos de heparan e dermatan;  
**OU**  
 Atividade da enzima IDUA menor que 10% do limite inferior de referência em plasma, fibroblastos, leucócitos ou em papel-filtro, com a atividade da enzima de referência avaliada na mesma amostra e pelo mesmo método, apresentando valores normais E presença de mutações patogênicas em homozigose ou heterozigose composta no gene IDUA.  
Para o TCTH, serão elegíveis ao transplante alogênico aparentado e não aparentado, mieloablativo de células-tronco hematopoiéticas os pacientes com diagnóstico de MPS I com até 3 anos de idade e desenvolvimento neuropsicomotor adequado para a idade, de acordo com avaliação realizada por neurologista. Todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoiéticos – REREME/INCA/MS. Deve-se observar as regras estabelecidas para transplantes, conforme normas técnicas e operacionais do Sistema Nacional de Transplantes 17,48,49.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos do **uso de TRE com laronidase,** os pacientes que apresentarem um dos seguintes critérios:  
- Condição médica irreversível e que implique em sobrevida provavelmente menor que 6 meses como resultado da MPS  
- I ou de outra doença associada, de acordo com a avaliação de mais de um especialista;  
- Pacientes com idade maior que 18 anos que, após serem informados sobre os potenciais riscos e benefícios associados  
- ao tratamento com laronidase, recusarem-se a serem tratados;  
- Contraindicação, hipersensibilidade ou toxicidade ao medicamento.  
Os pacientes com MPS I serão excluídos **da possibilidade de realização de TCTH alogênico, mieloablativo aparentado** com doadores homozigotos portadores de mutações patogênicas no gene _IDUA_ . Já a indicação de transplante envolvendo doadores heterozigotos portadores de mutações patogênicas no gene _IDUA_ deve ser avaliada caso a caso.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **TRATAMENTO** -->
O atendimento dos pacientes com MPS I envolve equipe multidisciplinar<sup>2,4,46-50</sup> e inclui intervenções não específicas, realizadas com vistas ao fenótipo clínico, como cirurgias para correção de hérnias, e específicas, visando ao uso da proteína mutante, como a TRE IV<sup>51,52</sup> e ao TCTH. Outras intervenções, como o uso de TRE intratecal, chaperonas, inibidores de síntese de substrato, terapia traducional e terapia gênica, encontram-se ainda em fase de pesquisa e/ou desenvolvimento<sup>20,53</sup> .  
O paciente com MPS I tem uma doença crônica, progressiva e multissistêmica e, rotineiramente, requer cuidados por equipe multiprofissional que inclua fonoaudiólogo, fisioterapeuta, terapeuta ocupacional, equipe de enfermagem e de diferentes especialidades médicas<sup>23,45</sup> . É importante que os pacientes tenham acesso a aconselhamento genético e a investigação de outros familiares, quando houver diagnóstico feito na família; além disso o acompanhamento com o geneticista é importante durante todo o curso da doença.  
É crucial que na equipe haja profissional médico cuidando continuamente do/a paciente, monitorando a evolução da doença, fornecendo orientação à família, encaminhando-o para especialistas, conforme necessário e coordenando o seu atendimento como um todo. Idealmente, o acompanhamento deve ser feito em um centro de referência. Os centros de referências devem incluir uma equipe multidisciplinar integrada de especialistas, que assegurem o gerenciamento abrangente dos pacientes com MPS I, desde o diagnóstico até o tratamento e seguimento<sup>43</sup> . Além disso, é importante que os pacientes e as famílias sejam orientados sobre a doença, possíveis complicações e riscos, além de possuírem relatório escrito do caso. Os pacientes também devem ser orientados para que, em caso de emergência, o médico que os atenda seja informado da doença e receba uma cópia desse relatório. As principais manifestações clínicas da MPS I e suas opções de tratamento de suporte/sintomáticos encontramse no quadro 1 (na seção 4.1).  
Ressalta-se que nem todos os pacientes apresentarão todas as manifestações da doença, as quais costumam ser mais frequentes e mais intensas nos pacientes com a forma grave da MPS I. Da mesma forma, nem todos os pacientes necessitarão ser submetidos a todas as formas de tratamento.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.1. Tratamento das manifestações clínicas** -->
O tratamento dos pacientes com MPS I deve ter um caráter multidisciplinar devido às suas múltiplas manifestações<sup>23</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.1.1. Tratamento das manifestações musculo-esqueléticas** -->
Pacientes com MPS I têm comprometimento ósseo significativo<sup>2</sup> e requerem fisioterapia motora dinâmica, cujo objetivo principal é a prevenção ou estabilização de deformidades osteoarticulares, mantendo a amplitude dos movimentos. A fisioterapia deve se concentrar em técnicas para ajudar o relaxamento de todos os músculos, como a massoterapia, enfatizando o antebraço e o punho, devido à síndrome do túnel do carpo, além de manobras e manipulações de todas as articulações com movimentos lentos para não causar dor, de acordo com os critérios da técnica de mobilização miofascial. Outras atividades incluem alongamentos para reduzir contraturas musculares e aumentar a flexibilidade articular, com fortalecimento da musculatura para melhorar a marcha e o equilíbrio, além de dissociação da cintura escapular e pélvica, exercícios de coordenação motora, propriocepção, jogos para melhorar movimentos usando acessórios e dança. É importante evitar a hiperextensão da cabeça, por causa do comprometimento atlanto-axial<sup>54,55</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.1.2. Tratamento das manifestações respiratórias** -->
A fisioterapia respiratória visa a melhorar a função pulmonar, ventilação e biomecânica respiratória, prejudicadas na MPS I. Estão indicadas manobras de higiene brônquica, como vibrocompressão, drenagem postural, tosse regulada por manobra de aceleração do fluxo expiratório, nebulização, limpeza das vias aéreas superiores com solução salina fisiológica e aspiração nasotraqueal com material estéril e descartável. É de vital importância orientar os cuidadores e os membros da família, pois a fisioterapia respiratória deve ser realizada diariamente<sup>54,55</sup> .  
Estudos do sono devem ser realizados rotineiramente para pacientes com MPS I grave, após a idade de 2 a 3 anos, e para pacientes com MPS I atenuada, no momento do diagnóstico. Ainda, antes de procedimentos que envolvam anestesia, podem ser necessários testes de função pulmonar e estudos de sono.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.2. Tratamento medicamentoso (sintomático e/ou para complicações da MPS I)** -->
Em relação ao tratamento medicamentoso dos pacientes com MPS I também se deve atentar para suas múltiplas manifestações<sup>23</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.2.1. Tratamento das manifestações respiratórias** -->
Entre os objetivos do tratamento clínico está o melhor controle das infecções recorrentes de via aérea<sup>23,48,49</sup> . Normalmente, solução nasal de cloreto de sódio 0,9% (9 mg/mL) é usada para eliminar crostas e secreções. Antibióticos com cursos de 10 a 15 dias são utilizados para o tratamento de exacerbações respiratórias agudas de origem bacteriana, como tonsilite, otite média aguda ou conforme indicação médica. O uso de corticoide sistêmico por breves períodos pode ajudar a reduzir o edema e facilitar a drenagem de secreções, conforme indicação médica. Pacientes com doença obstrutiva das vias aéreas devem ser avaliados por pneumologistas<sup>48,49</sup> . O uso de medicamentos para aqueles que desenvolvem asma obedece a princípios semelhantes àqueles pacientes sem concomitância de MPS I e devem ser administrados conforme o Protocolo de Asma vigente<sup>56</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.2.2. Tratamento das manifestações cardíacas** -->
O tratamento do acometimento cardíaco é, essencialmente, de suporte, envolvendo identificação e tratamento de pacientes com insuficiência cardíaca congestiva secundária à miocardiopatia, geralmente, hipertrófica ou, mais raramente, por disfunção valvular grave<sup>48,57-60</sup> . Nesse caso, o paciente deve ser tratado com betabloqueador, inibidor da enzima conversora da angiotensina (I-ECA) ou diurético, conforme a avaliação clínica<sup>48,57,58</sup> .  
No caso de valvulopatias graves, os pacientes podem necessitar se submeter à valvuloplastia com balão ou reparação/substituição valvular cirúrgica<sup>57-60</sup> . De acordo com as orientações da _American Heart Association_ , recomenda-se profilaxia de endocardite bacteriana apenas para pacientes com história de endocardite ou prótese valvar<sup>61</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.2.3. Tratamento das manifestações neurocognitivas** -->
Crianças com MPS I grave devem receber o máximo de estimulação ao desenvolvimento durante os estágios iniciais da doença. A adaptação do ambiente às necessidades da criança, como por exemplo, teclados com caracteres de grandes dimensões, pode ajudar no desenvolvimento destas<sup>48,62</sup> .  
Habilidades precocemente desenvolvidas podem ser mantidas em fases posteriores de progressão da doença. Crianças com MPS I atenuada, que tenham alterações cognitivas ou comportamentais, beneficiam-se com intervenção padrão para tais situações<sup>48</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.2.4. Tratamento das manifestações oftalmológicas** -->
O transplante de córnea não é realizado rotineiramente em pacientes com fenótipo grave para MPS I<sup>23,48</sup> . Já no fenótipo atenuado, este transplante pode melhorar notavelmente a visão, embora possa ocorrer opacificação da córnea transplantada. As lentes corretivas devem ser prescritas para corrigir erros de refração em todos os espectros da doença<sup>48</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.3. Tratamento cirúrgico** -->
Os procedimentos cirúrgicos mais frequentes incluem a adenotonsilectomia, cirurgia de cornetos nasais e traqueostomia. Como o bloqueio das vias aéreas em MPS é multifatorial, os resultados da adenotonsilectomia variam, mas a melhora em médio prazo na qualidade respiratória é percebida na maioria dos casos<sup>23,63</sup> .  
À medida que a doença progride, a traqueostomia ou o uso de pressão nasal positiva contínua nas vias aéreas (CPAP) podem ser necessários. A cirurgia das vias aéreas pode ser complicada pela macroglossia, abertura limitada da boca, margem cirúrgica restrita e instabilidade da coluna cervical, dificultando a visualização do campo cirúrgico<sup>48,63,64</sup> . Adicionalmente, a hiperextensão no pescoço nesses pacientes pode causar compressão medular aguda. Uma alternativa para a realização de adenoidectomia quando o acesso pela abertura oral está comprometido é a cirurgia endoscópica através da via nasal<sup>63</sup> .  
Caso necessário, a traqueostomia definitiva ou temporária pode ser realizada antes de outras cirurgias mandatórias, com o intuito de facilitar o controle das vias aéreas. A traqueostomia deve ser evitada sempre que possível, devido às dificuldades na técnica cirúrgica, endurecimento da traqueia, alterações anatômicas significativas, como pescoço curto e a possibilidade de complicações pós-operatórias, como traqueíte, pneumonia recorrente e bloqueio da traqueostomia por secreções espessas<sup>64</sup> . Os desafios do cuidado de uma traqueostomia nesses pacientes, associados à dificuldade de aceitação pelo paciente e pela família, também devem ser considerados<sup>37,64</sup> .  
Perda auditiva, seja de origem neurossensorial ou condutiva, ocorre em 70% a 100% dos pacientes com MPS I<sup>37</sup> . A audiometria pode ser realizada utilizando técnicas indicadas para crianças. O tratamento de perdas condutivas requer inserção de tubos de ventilação em T, embora nem sempre seja resolutivo<sup>65</sup> .  
A MPS I pode evoluir com complicações neurológicas, como hidrocefalia comunicante e compressão medular<sup>23,66,67</sup> . Os sinais clássicos de hipertensão intracraniana, geralmente, estão ausentes e evoluem de forma insidiosa com sintomas difíceis de  
distinguir de danos primários ao cérebro. Alterações comportamentais, como agitação ou hipoatividade, podem ser sinais de hipertensão intracraniana<sup>2,66,67</sup> . A melhor forma de diagnosticar hipertensão intracraniana nesses pacientes é pela raquimanometria, uma vez que, frequentemente, não é observada dilatação ventricular relevante nos exames de imagem<sup>68,69,70</sup> . A derivação ventrículo-peritoneal pode ser eficaz em reduzir a pressão do sistema nervoso central<sup>66,67</sup> , mas normalmente não reverte significativamente a manifestação clínica da doença. O procedimento também pode melhorar sintomas, como dor de cabeça ou a qualidade do sono<sup>48,67</sup> . Devido ao mecanismo particular da hipertensão intracraniana nas mucopolissacaridoses, recomenda-se utilizar válvulas de alta pressão, no intuito de evitar síndrome de hiperdrenagem.  
A maioria dos casos de compressão medular apresenta tetraparesia espástica, mas paraparesia espástica ou hemiparesia também podem ocorrer<sup>71</sup> . Cirurgia de coluna toracolombar para correção da cifose pode ser uma alternativa quando a deformidade progride<sup>71</sup> . Relatos sugerem que os pacientes com MPS I que se submetem à cirurgia da coluna vertebral têm maior risco de complicações graves, incluindo infarto da medula espinhal e instabilidade da coluna vertebral<sup>23,48,72,73</sup> . Assim, intervenções cirúrgicas na coluna devem ser periodicamente reavaliadas por monitorização com neurofisiologia<sup>68</sup> . Também se recomenda a realização de ressonância cerebral ao diagnóstico e a cada 2 a 3 anos, durante o seguimento. Exames de imagem da coluna devem ser realizados se o paciente apresentar novos sintomas<sup>68,70</sup> .  
Eventualmente, esses pacientes necessitam de cirurgias corretivas devido às diversas deformidades ósseas, incluindo a região do quadril. Apesar da cirurgia de estabilização do quadril, essa intervenção não parece impedir a deterioração radiológica e o desenvolvimento de artrite do quadril clinicamente significativa<sup>74</sup> . Recomenda-se que seja programada cirurgia pediátrica do quadril, especialmente em pacientes com a síndrome de Hurler, considerando a possibilidade de substituição precoce do quadril<sup>74</sup> .  
As hérnias inguinais e umbilicais são comuns entre os pacientes com MPS I. Alguns pacientes se submetem ao reparo de suas hérnias inguinais antes mesmo do diagnóstico da doença. As hérnias umbilicais frequentemente recidivam após o reparo inicial, talvez como resultado de elastogênese comprometida<sup>75</sup> . A protuberância abdominal causada por hepatoesplenomegalia progressiva pode também aumentar as hérnias umbilicais<sup>23</sup> .  
A descompressão cirúrgica do nervo mediano é indicada nos casos de síndrome do túnel do carpo. A liberação cirúrgica de tendões também pode melhorar a função das mãos<sup>76</sup> .  
Muitos pacientes com MPS apresentam risco anestésico elevado devido à obstrução das vias aéreas superiores. Quando possível, os procedimentos que exigem anestesia geral devem ser evitados, para minimizar os riscos. A dificuldade na intubação pode ser fatal<sup>77</sup> . Idealmente, as cirurgias devem ser realizadas em centros de referência com experiência em MPS, sendo fundamental a presença de anestesista experiente em intubação difícil para a realização desses procedimentos, pois frequentemente é necessário acompanhar a intubação com fibroscopia. As máscaras laríngeas podem ser usadas para manuseio das vias aéreas por períodos curtos ou para facilitar a intubação de fibra óptica<sup>73,74</sup> . Pode ser necessário usar tubos endotraqueais menores do que o previsto para a idade e o tamanho de um paciente com MPS I<sup>77,78</sup> .  
Esses pacientes, geralmente, apresentam obstrução pós-operatória das vias aéreas e a observação clínica noturna hospitalar é comum. A possibilidade de traqueostomia pós-operatória deve ser discutida antes de cirurgias nestes pacientes com todas as partes envolvidas.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.4. Transplante de Células Tronco-Hematopoiéticas (TCTH)** -->
O TCTH alogênico mieloablativo é eficaz em reduzir a progressão de alguns desfechos em crianças com MPS I grave<sup>79-</sup> 91. Entre os efeitos positivos dessa terapia estão a diminuição da hepatoesplenomegalia, da opacificação de córnea e das complicações cardiopulmonares. Apesar da heterogeneidade da doença tornar mais difícil a interpretação dos resultados, dados disponíveis mostram os seguintes resultados:  
 A taxa de mortalidade relatada foi sendo reduzida ao longo do tempo, de uma sobrevida de 49% em 2 anos em estudo de 1996<sup>81</sup> , a 77% em 3 anos, até 86% em 5 anos<sup>83,85</sup> . Estudo publicado em 2015 avaliou o TCTH alogênico nas  
mucopolissacaridoses, em 62 pacientes com MPS I (56 com o tipo I-Hurler). Uma sobrevida global alta (95,2%) e vida livre de eventos (90,3%) foram alcançados, com baixa toxicidade, sendo 13,3% com doença aguda do enxerto contra o hospedeiro e 14,8% com doença crônica de rejeição<sup>90</sup> .  
 Quanto à funcionalidade e à qualidade de vida, a pontuação de uma escala que avalia comportamento adaptativo foi melhor em pacientes transplantados antes dos 2 anos de idade quando comparados, transversalmente, a um grupo não transplantado<sup>91</sup> . No transplante, a capacidade cognitiva e não a idade correlacionou-se significativamente com o nível adaptativo final. Outro estudo, com 47 pacientes transplantados entre 6 e 44 meses, não apontou impacto significativo do tipo de transplante, número de transplantes, idade no transplante e tempo desde o transplante no funcionamento adaptativo; no entanto, indivíduos submetidos ao TCTH em uma idade mais avançada relataram pior qualidade de vida física<sup>92</sup> .  
 O TCTH diminui a face infiltrada característica típica e a hepatoesplenomegalia, além de melhorar a audição<sup>93</sup> .  
 As manifestações esqueléticas e a opacificação de córnea progridem na mesma velocidade em crianças submetidas ou não ao TCTH<sup>91-95</sup> .  
 O grau de melhora nas complicações neurológicas após TCTH e a interrupção do declínio neurológico não está claro<sup>84,85,90,91,92</sup> . Alguns relatos demonstram melhora, enquanto outros não<sup>90,91,92</sup> . Em crianças submetidas ao TCTH antes de apresentarem evidências relevantes de atraso do desenvolvimento (entre 12 e 18 meses de idade), parece haver lentificação do declínio cognitivo. Crianças com atraso cognitivo significativo antes da realização do TCTH não demonstram correção do atraso já estabelecido. A hidrocefalia é prevenida ou estabilizada<sup>90,91,92</sup> .  
 Em indivíduos com MPS I e presença de variantes patogênicas sabidamente graves, o TCTH estabiliza e melhora a função miocárdica, com regressão da hipertrofia e normalização das dimensões das câmaras cardíacas<sup>91-93</sup> . Por este estudo, o TCTH não parece ter efeito na presença ou progressão do envolvimento valvular<sup>91-93</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.5. Tratamento medicamentoso específico** -->
A laronidase, IDUA recombinante, é uma enzima produzida em células de ovário de hamster chinês (células _Chinese hamster ovary_ , CHO) e é o fármaco disponível para o tratamento específico da MPS I<sup>51,97,98</sup> . A laronidase foi considerada segura, nos estudos clínicos, com eventos adversos leves na maioria dos casos e facilmente tratáveis, apesar de eventos relacionados à infusão serem frequentes. Os eventos adversos relatados nos estudos foram erupção cutânea, urticária e febre. O único estudo controlado com placebo não encontrou diferença significativa na ocorrência de eventos adversos entre os grupos<sup>99</sup> .  
Os estudos sugerem que a laronidase tem um efeito benéfico na flexão do ombro, com melhora da amplitude dos movimentos variando de 17° a 33,5° e redução, estatisticamente significativa, da hepatomegalia<sup>97,98,99</sup> .  
Em todos os estudos que relataram análise de GAGs urinários, houve redução estatisticamente significativa, comparada ao placebo ou aos níveis anteriores ao uso da TRE, de pelo menos 50%, medidos a partir da quarta semana de tratamento<sup>97,98,99</sup> .  
A revisão sistemática com meta-análise da Cochrane, publicada em 2019<sup>100</sup> , comparou laronidase com placebo com acompanhamento de 26 semanas e observou redução dos GAGs urinários no grupo que usou laronidase de 54% em relação ao basal. Esse achado foi estatisticamente significativo (p<0,001).  
Estudo publicado em 2022<sup>101</sup> indica que indivíduos com formas atenuadas crescem mais durante períodos de uso regular uso da TRE.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o  
usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.5.1. Uso de laronidase em gestantes e lactantes** -->
São raros os relatos de mulheres grávidas com qualquer tipo de MPS. Os GAGs se acumulam nas gônadas, placenta e hipófise de humanos com MPS, o que pode interferir na função reprodutiva<sup>102</sup> . Ainda, as informações sobre o uso de laronidase por mulheres grávidas são muito limitadas. Assim, o uso da TRE em gestantes e lactantes deve ser realizado a critério médico.  
A laronidase é classificada como classe B para uso na gestação e aleitamento<sup>103</sup> . Há relato na literatura de manutenção de uso da laronidase durante a gestação e amamentação natural por pelo menos 3 meses, com desfechos positivos para mãe e para o recém-nascido<sup>104</sup> . Devido às limitações da evidência, recomenda-se que o tratamento com TRE não seja iniciado durante a gestação, especialmente durante o primeiro trimestre. Caso seja utilizada pré medicação, a interrupção da TRE deve ser considerada, especialmente no primeiro trimestre. Contudo, o uso da TRE com laronidase por mulheres grávidas ou que estejam amamentando é uma decisão conjunta do médico assistente e da paciente.  
Casos associados à não redução de GAGs urinários devem ser avaliados de forma individualizada, para excluir a possibilidade de ocorrência de anticorpos neutralizantes<sup>105</sup> .  
Quando houver reação à infusão mediada por IgE, deve ser discutida a possibilidade do uso de protocolos que promovam a tolerância ao medicamento.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.6. Medicamento** -->
- Laronidase: solução injetável de 0,58 mg/mL.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.7. Esquema de Administração** -->
A dose recomendada para a laronidase é de 0,58 mg/kg de peso corporal, administrada uma vez por semana por infusão intravenosa, durante três a quatro horas. Pré-tratamento com antipiréticos ou anti-histamínicos é recomendado 60 minutos antes do início da infusão em bula<sup>103</sup> , porém trata-se apenas de uma recomendação. A decisão de usar pré-medicação ou não, cabe ao médico/a assistente do paciente<sup>103</sup> . A infusão deve ser feita em ambiente hospitalar ou ambulatorial. Infusões domiciliares podem ser consideradas após 6 meses de tratamento sem intercorrências<sup>103,106</sup> .  
O volume total da infusão é determinado pelo peso corporal do paciente e deve ser infundido ao longo de 3 a 4 horas. Pacientes com 20 kg ou menos devem receber um volume total de 100 mL. Pacientes com mais de 20 kg devem receber um volume total de 250 ml. A taxa inicial de infusão é de 10 mcg/kg/hora e pode ser aumentada a cada 15 minutos durante a primeira hora, conforme a tolerância, até uma velocidade máxima de infusão de 200 mcg/kg/hora ser atingida, sendo mantida para o restante da infusão (2 a 3 horas)<sup>103</sup> .  
Alguns estudos<sup>107,103</sup> avaliaram um esquema posológico alternativo, diferente do preconizado em bula da laronidase. Pacientes em uso de 1,2 mg/kg de laronidase em semanas alternadas (15/15 dias) apresentaram bons resultados clínicos (nenhuma deterioração ou reversão dos resultados clínicos), boa tolerância e segurança, além de maior satisfação, quando comparados ao uso da dose semanal. Contudo, devido à escassez das evidências, este Protocolo não preconiza o uso de laronidase em esquemas de administração distintos.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6.8. Critérios de Interrupção** -->
Não há tempo de tratamento pré-determinado. Devido às características da doença e à ausência de tratamento específico alternativo, o uso de laronidase deve ser mantido por toda a vida do paciente.  
A TRE deve ser interrompida caso o paciente apresente, pelo menos, uma das seguintes situações<sup>49,100</sup> :  
- Adesão inadequada ao tratamento, definida por falta em mais de 50% das sessões de infusão do medicamento;  
- Redução grave na qualidade de vida e no estado funcional, apesar do tratamento específico para a doença, definidas por  
- condição clínica que se associe a uma expectativa de vida menor que 1 ano;  
 Ausência de melhora, após 6 meses de tratamento, nas manifestações clínicas que comprovadamente respondem à TRE: hepatomegalia, verificada por quaisquer métodos, como exame físico, ecografia abdominal ou ressonância abdominal; redução de pelo menos 50% dos níveis basais de GAGs urinários; redução de pelo menos 10° na restrição da amplitude dos movimentos do ombro;  
- Pacientes adultos (maiores de 18 anos) que, após serem devidamente informados sobre os riscos e benefícios de sua  
- decisão, optarem por não mais se submeterem à TRE IV com laronidase;  
- Surgimento de contraindicação ao medicamento.  
Os critérios de interrupção do tratamento devem ser apresentados, de forma clara, ao paciente ou seus responsáveis, quando a TRE estiver sendo considerada e antes de iniciá-la.  
No caso de interrupção por falha de adesão, o paciente e familiares deverão ser inseridos em programa de incentivo à adesão e poderão retornar ao tratamento, caso haja comprometimento explícito de seguimento das recomendações médicas

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **MONITORAMENTO** -->
Como mencionado anteriormente, indivíduos com MPS I devem ser acompanhados por equipe multidisciplinar, cuja composição dependerá de suas necessidades individuais. A resposta ao tratamento deve ser avaliada da mesma forma em pacientes adultos e crianças. Aspectos clínicos e parâmetros associados ao acometimento de órgãos-alvo devem ser minuciosamente investigados e acompanhados periodicamente.  
A despeito da multiplicidade de manifestações da MPS I, alguns órgãos ou sistemas são afetados mais frequentemente ou ocorre morbidade potencialmente mais grave. Além do surgimento de danos em órgãos não comprometidos anteriormente, pode haver progressão da doença, independentemente de os pacientes estarem usando ou não terapia específica. Assim, ambas as possibilidades devem fazer parte da avaliação inicial e do seguimento destes pacientes.  
O Apêndice 2 apresenta as avaliações consideradas necessárias para o acompanhamento de pacientes com MPS I, com um programa de acompanhamento mínimo, o qual pode ser modificado de acordo com julgamento clínico.  
Por sua vez, o seguimento de pacientes submetidos ao TCTH deve seguir a conduta adotada pelo centro transplantador.  
A resposta terapêutica e os eventos adversos devem ser monitorados em todos os pacientes<sup>108-116</sup> . O médico deve realizar anamnese completa em cada visita e coletar dados de altura em pé, decúbito dorsal ou por segmento, peso e perímetro cefálico usando, de preferência, o mesmo instrumento devidamente calibrado. O exame físico deve ser completo e incluir sinais vitais (temperatura, frequência cardíaca, frequência respiratória e pressão arterial), bem como medidas para quantificação do tamanho do fígado (hepatimetria) e do baço. A avaliação do desenvolvimento sexual deve ser realizada em adolescentes, de acordo com os critérios de Tanner<sup>117</sup> .  
Nas visitas, dados sobre todas as avaliações realizadas desde o último agendamento devem ser obtidos e testes necessários devem ser solicitados, incluindo avaliações com especialistas em neurologia, otorrinolaringologia, oftalmologia, cardiologia e pneumologia, estudo do sono e avaliação de volumes viscerais com ressonância magnética, tomografia computadorizada ou ecografia, conforme necessidade de cada paciente<sup>37</sup> .  
Para fins de diagnóstico e acompanhamento, devem ser realizadas radiografias do crânio em perfil, coluna vertebral em perfil, incluindo região cervical, tórax póstero-anterior, coxofemorais póstero-anterior e ambas as mãos. A superexposição à radiação deve ser evitada<sup>4</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e o monitoramento dos tratamentos clínico e de reabilitação necessários bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
O tratamento da MPS I deve ser feito por equipe em Serviços Especializados ou de Referência em Doenças Raras, para fins de diagnóstico e de acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige experiência e familiaridade com manifestações clínicas associadas, convém que o médico responsável tenha experiência e seja treinado nessa atividade. Cabe destacar que, sempre que possível, o atendimento da pessoa com MPS I deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Para a administração dos medicamentos é essencial o atendimento centralizado, para maior racionalidade do uso e avaliação da efetividade. A infusão deve ser feita em ambiente hospitalar ou ambulatorial sob vigilância de um médico ou outro profissional da saúde, devido ao risco de reações durante a infusão. Infusões domiciliares podem ser consideradas após 6 meses de tratamento sem intercorrências.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo. Estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normas vigentes.  
Para a autorização do TCTH alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras<sup>118-121</sup> .  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e possui como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno, redução de incapacidade e cuidados  
paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da Atenção Primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil e as associações beneficentes e voluntárias são o locus da atenção à saúde dos pacientes com doenças raras. Todavia, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
 Serviço de Atenção Especializada em Doenças Raras para prestar serviço de saúde para uma ou mais doenças raras; e  
 Serviço de Referência em Doenças Raras para prestar serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Pacientes com suspeita de deficiência intelectual devem ser encaminhados, preferencialmente, a um Serviço Especializado ou de Referência em Doenças Raras para seu adequado diagnóstico.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **REFERÊNCIAS** -->
1. Terlato NJ, Cox GF. Can mucopolysaccharidosis type I disease severity be predicted on basis of patient’s genotype? A comprehensive review of literature. Genetics in medicine. 2003;5(4):286-94  
2. Neufeld EF, Muenzer J. The Mucopolysaccharidoses. . In: Valle D, Beaudet AL, Vogelstein B, Kinzler KW, Antonarakis SE, Ballabio A, et al., editors. The Online Metabolic and Molecular Bases of Inherited Disease. New York, NY: McGrawHill; capítulo 136, 2014.  
3. Soliman OI, Timmermans RG, Nemes A, Vletter WB, Wilson JH, ten Cate FJ, et al. Cardiac abnormalities in adults with the attenuated form of mucopolysaccharidosis type I. J Inherit Metab Dis. 2007;30(5):750-7.  
4. Pastores GM, Arn P, Beck M, Clarke JT, Guffon N, Kaplan P, et al. The MPS I registry: design, methodology, and early findings of a global disease registry for monitoring patients with Mucopolysaccharidosis Type I. Mol Genet Metab. 2007;91(1):37-47.  
5. Moore D, Connock MJ, Wraith E, Lavery C. The prevalence of and survival in Mucopolysaccharidosis I: Hurler, HurlerScheie and Scheie syndromes in the UK. Orphanet J Rare Dis. 2008;3:24.  
6. Nelson J. Incidence of the mucopolysaccharidoses in Northern Ireland. Hum Genet. 1997;101(3):355-8.  
7. Beck M, Arn P, Giugliani R, Muenzer J, Okuyama T, Taylor J, et al. The natural history of MPS I: global perspectives from the MPS I Registry. Genet Med. 2014;16(10):759-65.  
8. Muñoz-Rojas MV, Bay L, Sanchez L, van Kuijck M, Ospina S, Cabello JF, et al. Clinical manifestations and treatment of mucopolysaccharidosis type I patients in Latin America as compared with the rest of the world. J Inherit Metab Dis. 2011;34(5):1029-37.  
9. Dornelles AD, de Camargo Pinto LL, de Paula AC, Steiner CE, Lourenço CM, Kim CA, et al. Enzyme replacement therapy for Mucopolysaccharidosis Type I among patients followed within the MPS Brazil Network. Genet Mol Biol. 2014;37(1):23-9.  
10. Lowry RB, Applegarth DA, Toone JR, MacDonald E, Thunem NY. An update on the frequency of mucopolysaccharide syndromes in British Columbia. Hum Genet. 1990;85(3):389-90.  
11. Meikle PJ, Hopwood JJ, Clague AE, Carey WF. Prevalence of lysosomal storage disorders. JAMA. 1999;281(3):249-54.  
12. Boy R, Schwartz IV, Krug BC, Santana-da-Silva LC, Steiner CE, Acosta AX, et al. Ethical issues related to the access to orphan drugs in Brazil: the case of mucopolysaccharidosis type I. J Med Ethics. 2011;37(4):233-9.  
13. Baehner F, Schmiedeskamp C, Krummenauer F, Miebach E, Bajbouj M, Whybra C, et al. Cumulative incidence rates of the mucopolysaccharidoses in Germany. J Inherit Metab Dis. 2005;28(6):1011-7.  
14. Elliott S, Buroker N, Cournoyer JJ, Potier AM, Trometer JD, Elbin C, et al. Pilot study of newborn screening for six lysosomal storage diseases using Tandem Mass Spectrometry. Mol Genet Metab. 2016;118(4):304-9.  
15. Hopkins PV, Campbell C, Klug T, Rogers S, Raburn-Miller J, Kiesling J. Lysosomal storage disorder screening implementation: findings from the first six months of full population pilot testing in Missouri. J Pediatr. 2015;166(1):1727.  
16. CELIK Çelik B, Tomatsu SC, Tomatsu S, Khan SA. Epidemiology of Mucopolysaccharidoses Update. Diagnostics (Basel). 2021; 10;11(2):273. doi: 10.3390/diagnostics11020273.  
17. D'Aco K, Underhill L, Rangachari L, Arn P, Cox GF, Giugliani R, et al. Diagnosis and treatment trends in mucopolysaccharidosis I: findings from the MPS I Registry. Eur J Pediatr. 2012;171(6):911-9.  
18. Federhen A, Pasqualin G, Freitas TF, Gonzales EA, Trapp F, Matte U, et al. Estimated birth prevalence of mucopolysaccharidoses in Brazil. Am J Med Genet. 2020;182A:469–483  
19. Josahkian JA, Trapp FB, Burin MG, Michelin-Tirelli K, Magalhães PPS, Sebastião FM et al. Updated birth prevalence and relative frequency of mucopolysaccharidoses across Brazilian region. Genetics and Molecular Biology. 2021; 44(1): e2020138 .  
20. Nan H, Park C, Maeng S. Mucopolysaccharidoses I and II: Brief Review of Therapeutic Options and Supportive/Palliative Therapies. Biomed Res Int. 2020 Dec 4;2020:2408402. doi: 10.1155/2020/2408402.  
21. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. 2016  
22. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al.. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ 2008; 336: 924. doi: https://doi.org/10.1136/bmj.39489.470347.AD  
23. Clarke LA. Mucopolysaccharidosis Type I. 2002 [atualização em 2024, Apr 11]. Em: Adam MP, Feldman J, Mirzaa GM, Pagon RA, Wallace SE, Bean LJH, Gripp KW, Amemiya A, editores. GeneReviews® [Internet]. Seattle (WA): University of Washington, Seattle; 1993–2024.  
24. Hampe CS, Eisengart JB, Lund TC, Orchard PJ, Swietlicka M, Wesley J, ey al. Mucopolysaccharidosis Type I: A Review of the Natural History and Molecular Pathology. Cells. 2020; 9(8):1838. doi: 10.3390/cells9081838  
25. Han S. Mucopolysaccharidoses: Clinical features and diagnosis. Uptodate. 2020. Em https://www.uptodate.com/contents/mucopolysaccharidoses-clinical-features-anddiagnosis?search=MPS%20I&source=search_result&selectedTitle=1%7E18&usage_type=default&display_rank=1  
26. Bruni S, Lavery C, Brummfield A. The diagnostic journey of patients with mucopolysaccharidosis I: A real-world survey of patient and physician experiences. Molecular Genetics and Metabolism Report. 2016;8:67-73  
27. Thomsen G, Vesterdal J. Atypical Hurler's syndrome; a report of 3 cases with a discussion of the differential diagnosis. Acta radiol. 1951;35(5-6):331-44. doi: 10.3109/00016925109136665.  
28. Kurniawan BD. The great masquerade: delayed diagnosis of mucopolysaccharidosis in adulthood. Can J Ophthalmol. 2013;48(6)e141-42  
29. Melikoglu MA, Kocabas H, Sezer I, Cay HF, Cassidy AG, Balci N. Legg-Perthes disease-like joint involvement and diagnosis delay in Scheie syndrome: a case report. Clin Rheumatol. 2007 Nov;26(11):1937-9. doi: 10.1007/s10067-0070549-6  
30. Gökay S, Kardaş F, Kendirci M, Sözeri B. Arthropathy-like findings and a carpal tunnel syndrome as the presenting features of Scheie syndrome: Three cases from the same family. Turk J Pediatr. 2018;60(3):344-347. doi: 10.24953/turkjped.2018.03.020.  
31. Chakraborty PP, Biswas SN, Ray S, Dey SK. Mucopolysaccharidosis type I disguised as rickets. BMJ Case Rep. 2016 May 11;2016:bcr2016215416. doi: 10.1136/bcr-2016-215416. PMID: 27170613  
32. Auray-Blais C, Lavoie P, Tomatsu S, Valayannopoulos V, Mitchell JJ, Raiman J, et al. UPLC-MS/MS detection of disaccharides derived from glycosaminoglycans as biomarkers of mucopolysaccharidoses. Anal Chim Acta. 2016;936:13948.  
33. Keating KG, Whiteaker L, Corkery J, Charrow J, Burton B. Pseudodeficiency of alpha-iduronidase is a common finding identified from newborn screening in the state of Illinois. Mol Genet Metab 2016;117(2):S66.  
34. Chamoles NA, Blanco M, Gaggioli D. Diagnosis of alpha-L-iduronidase deficiency in dried blood spots on filter paper: the possibility of newborn diagnosis. Clin Chem. 2001;47(4):780-1.  
35. Verma J, Thomas DC, Kasper DC, Sharma S, Puri RD, Bijarnia-Mahay S, et al. Inherited Metabolic Disorders: Efficacy of Enzyme Assays on Dried Blood Spots for the Diagnosis of Lysosomal Storage Disorders. JIMD Rep. 2017;31:15-27.  
36. Breier AC, Cé J, Mezzalira J, Daitx VV, Moraes VC, Goldim MPS, et al. Alpha-l-iduronidase and arylsulfatase B in dried blood spots on filter paper: Biochemical parameters and time stability. Clin Biochem. 2017;50(7-8):431-5.  
37. Martins AM, Dualibi AP, Norato D, Takata ET, Santos ES, Valadares ER, et al. Guidelines for the management of mucopolysaccharidosis type I. J Pediatr. 2009;155(4 Suppl):S32-46.  
38. Müller KB, Pereira VG, Martins AM, D'Almeida V. Evaluation of α-iduronidase in dried blood spots is an accurate tool for mucopolysaccharidosis I diagnosis. J Clin Lab Anal. 2011;25(4):251-4.  
39. de Jong JG, Hasselman JJ, van Landeghem AA, Vader HL, Wevers RA. The spot test is not a reliable screening procedure for mucopolysaccharidoses. Clin Chem. 1991;37(4):572-5.  
40. Beesley CE, Meaney CA, Greenland G, Adams V, Vellodi A, Young EP, et al. Mutational analysis of 85 mucopolysaccharidosis type I families: frequency of known mutations, identification of 17 novel mutations and in vitro expression of missense mutations. Hum Genet. 2001;109(5):503-11.  
41. Bertola F, Filocamo M, Casati G, Mort M, Rosano C, Tylki-Szymanska A, et al. IDUA mutational profiling of a cohort of 102 European patients with mucopolysaccharidosis type I: identification and characterization of 35 novel α-L-iduronidase (IDUA) alleles. Hum Mutat. 2011;32(6):E2189-210.  
42. Institute of Medical Genetics in Cardiff. The Human Gene Mutation Database. Em: http://www.hgmd.cf.ac.uk/ac/index.php.  
43. Pereira VG, Martins AM, Micheletti C, D'Almeida V. Mutational and oxidative stress analysis in patients with mucopolysaccharidosis type I undergoing enzyme replacement therapy. Clin Chim Acta. 2008;387(1-2):75-9.  
44. Matte U, Yogalingam G, Brooks D, Leistner S, Schwartz I, Lima L, et al. Identification and characterization of 13 new mutations in mucopolysaccharidosis type I patients. Mol Genet Metab. 2003;78(1):37-43.  
45. Parini R, Deodato F, Di Rocco M, Lanino E, Locatelli F, Messina C, et al. Open issues in Mucopolysaccharidosis type I- Hurler. Orphanet J Rare Dis. 2017;12(1):112.  
46. Pastores GM, Meere PA. Musculoskeletal complications associated with lysosomal storage disorders: Gaucher disease and Hurler-Scheie syndrome (mucopolysaccharidosis type I). Curr Opin Rheumatol. 2005;17(1):70-8.  
47. Pastores GM. Musculoskeletal complications encountered in the lysosomal storage disorders. Best Pract Res Clin Rheumatol. 2008;22(5):937-47.  
48. Muenzer J, Wraith JE, Clarke LA, I ICPoMaToM. Mucopolysaccharidosis I: management and treatment guidelines. Pediatrics. 2009;123(1):19-29.  
49. Bay L, Amartino H, Antacle A, Arberas C, et al. Nuevas recomendaciones para el cuidado de los pacientes con mucopolisacaridosis tipo I. Arch Argent Pediatr 2021;119(2):e121-e128.  
50. Turra GS, Schwartz IV. Evaluation of orofacial motricity in patients with mucopolysaccharidosis: a cross-sectional study. J Pediatr (Rio J). 2009;85(3):254-60.  
51. Schwartz IV, Souza CF, Giugliani R. Treatment of inborn errors of metabolism. J Pediatr (Rio J). 2008;84(4 Suppl):S8-19.  
52. Jameson E, Jones S, Remmington T. Enzyme replacement therapy with laronidase (Aldurazyme®) for treating mucopolysaccharidosis type I. Cochrane Database Syst Rev. 2019 Jun 18;6(6):CD009354. doi: 10.1002/14651858.CD009354.pub5.  
53. Penon-Portmann M, Blair DR, Harmatz P.Current and new therapies for mucopolysaccharidoses. Pediatrics & Neonatology.2023;64(1):S10-S17. https://doi.org/10.1016/j.pedneo.2022.10.001..  
54. Dusing SC, Thorpe D, Rosenberg A, Mercer V, Escolar ML. Gross motor abilities in children with Hurler syndrome. Dev Med Child Neurol. 2006;48(11):927-30.  
55. Haley SM, Fragala Pinkham MA, Dumas HM, Ni P, Skrinar AM, Cox GF. A physical performance measure for individuals with mucopolysaccharidosis type I. Dev Med Child Neurol. 2006;48(7):576-81  
56. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas Asma. Portaria Conjunta SAES/SECTICS/MS nº 32 - 20/12/2023. Disponível em:  https://www.gov.br/conitec/pt-br/midias/protocolos/portaria-conjunta-saes-sectics-no32.pdf.  
57. Pierpont MEM, Moller JH. Cardiac manifestations of genetic disease. In: Moss A, editor. Heart disease in infants, children, and adolescents. 5th ed. ed. London: Williams & Wilkins; 1995. p. 1486-520.  
58. Dangel JH. Cardiovascular changes in children with mucopolysaccharide storage diseases and related disorders--clinical and echocardiographic findings in 64 patients. Eur J Pediatr. 1998;157(7):534-8.  
59. Fischer TA, Lehr HA, Nixdorff U, Meyer J. Combined aortic and mitral stenosis in mucopolysaccharidosis type I-S (UllrichScheie syndrome). Heart. 1999;81(1):97-9.  
60. Minakata K, Konishi Y, Matsumoto M, Miwa S. Surgical treatment for Scheie's syndrome (mucopolysaccharidosis type I- S): report of two cases. Jpn Circ J. 1998;62(9):700-3.  
61. Wilson W, Taubert KA, Gewitz M, Lockhart PB, Baddour LM, Levison M, et al. Prevention of infective endocarditis: guidelines from the American Heart Association: a guideline from the American Heart Association Rheumatic Fever, Endocarditis, and Kawasaki Disease Committee, Council on Cardiovascular Disease in the Young, and the Council on Clinical Cardiology, Council on Cardiovascular Surgery and Anesthesia, and the Quality of Care and Outcomes Research Interdisciplinary Working Group. Circulation. 2007;116(15):1736-54.  
62. Shapiro EG, Eisengart JB. The natural history of neurocognition in MPS disorders: A review. Mol Genet Metab. 2021 May;133(1):8-34. doi: 10.1016/j.ymgme.2021.03.002.  
63. Nayak DR, Balakrishnan R, Murthy KD. An endoscopic approach to the deviated nasal septum--a preliminary study. J Laryngol Otol. 1998;112(10):934-9.  
64. Shapiro J, Strome M, Crocker AC. Airway obstruction and sleep apnea in Hurler and Hunter syndromes. Ann Otol Rhinol Laryngol. 1985;94(5 Pt 1):458-61.  
65. Oghan F, Harputluoglu U, Guclu E, Guvey A, Turan N, Ozturk O. Permanent t-tube insertion in two patients with Hurler's syndrome. Int J Audiol. 2007;46(2):94-6  
66. Sheridan M, Johnston I. Hydrocephalus and pseudotumour cerebri in the mucopolysaccharidoses. Childs Nerv Syst. 1994;10(3):148-50.  
67. Dalla Corte A, de Souza CFM, Anés M, Giugliani R. Hydrocephalus and mucopolysaccharidoses: what do we know and what do we not know? Childs Nerv Syst. 2017;33(7):1073-80  
68. Reichert R, Campos LG, Vairo F, de Souza CF, Pérez JA, Duarte J, et al. Neuroimaging Findings in Patients with Mucopolysaccharidosis: What You Really Need to Know. Radiographics. 2016;36(5):1448-62.  
69. Seto T, Kono K, Morimoto K, Inoue Y, Shintaku H, Hattori H, et al. Brain magnetic resonance imaging in 23 patients with mucopolysaccharidoses and the effect of bone marrow transplantation. Ann Neurol. 2001;50(1):79-92.  
70. Watts RW, Spellacy E, Kendall BE, du Boulay G, Gibbs DA. Computed tomography studies on patients with mucopolysaccharidoses. Neuroradiology. 1981;21(1):9-23.  
71. Kachur E, Del Maestro R. Mucopolysaccharidoses and spinal cord compression: case report and review of the literature with implications of bone marrow transplantation. Neurosurgery. 2000;47(1):223-8; discussion 8-9.  
72. Williams N, Cundy P, Eastwood D. Surgical Management of Thoracolumbar Kyphosis in Patients with Mucopolysaccharidosis: A Systematic Review. Spine (Phila Pa 1976). 2017.  
73. Liang J, Singhal A. Regression of ventriculomegaly following medical management of a patient with Hurler syndrome. J Neurosurg Pediatr. 2016;17(5):537-9.  
74. Kennedy J, Noel J, O'Meara A, Mulhall K, Crushell E, Fogarty E, et al. A Long-term Retrospective Evaluation of Functional and Radiographic Outcomes of Pediatric Hip Surgery in Hurler Syndrome. J Pediatr Orthop. 2016;36(1):25-8.  
75. Hinek A, Wilson SE. Impaired elastogenesis in Hurler disease: dermatan sulfate accumulation linked to deficiency in elastinbinding protein and elastic fiber assembly. Am J Pathol. 2000;156(3):925-38.  
76. Pronicka E, Tylki-Szymanska A, Kwast O, Chmielik J, Maciejko D, Cedro A. Carpal tunnel syndrome in children with mucopolysaccharidoses: needs for surgical tendons and median nerve release. J Ment Defic Res. 1988;32 ( Pt 1):79-82.  
77. Shinhar SY, Zablocki H, Madgy DN. Airway management in mucopolysaccharide storage disorders. Arch Otolaryngol Head Neck Surg. 2004;130(2):233-7.  
78. Brain AI. The laryngeal mask--a new concept in airway management. Br J Anaesth. 1983;55(8):801-5.  
79. Hampe CS, Wesley J, Lund TC, Orchard PJ, Polgreen LE, Eisengart JB, McLoon LK, Cureoglu S, Schachern P, McIvor RS. Mucopolysaccharidosis Type I: Current Treatments, Limitations, and Prospects for Improvement. Biomolecules. 2021 Jan 29;11(2):189. doi: 10.3390/biom11020189.  
80. Brasil. Ministério da Saúde. CONITEC. Relatório de Recomendação. Ampliação do Transplante de Células- Tronco Hematopoiéticas para Mucopolissacaridose Tipo I. Janeiro 2018. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2018/relatorio_transplante_celulastroncohematopoeticas_mpsi.pdf  
81. Vellodi A, Young EP, Cooper A, Wraith JE, Winchester B, Meaney C, et al. Bone marrow transplantation for mucopolysaccharidosis type I: experience of two British centres. Arch Dis Child. 1997;76: 92–99  
82. Souillet G, Guffon N, Maire I, Pujol M, Taylor P, Sevin F, et al. Outcome of 27 patients with Hurler’s syndrome transplanted from either related or unrelated haematopoietic stem cell sources. Bone Marrow Transplant. 2003;31: 1105–1117.  
83. Staba SL, Escolar ML, Poe M, Kim Y, Martin PL, Szabolcs P, et al. Cord-blood transplants from unrelated donors in patients with Hurler’s syndrome. N Engl J Med. 2004;350: 1960–1969  
84. Aldenhoven M, Wynn RF, Orchard PJ, O’Meara A, Veys P, Fischer A, et al. Long-term outcome of Hurler syndrome patients after hematopoietic cell transplantation: an international multicenter study. Blood.2015;125: 2164–2172.  
85. Guffon N, Souillet G, Maire I, Straczek J, Guibaud P. Follow-up of nine patients with Hurler syndrome after bone marrow transplantation. J Pediatr. 1998;133: 119–125.  
86. Wadhwa A, Chen Y, Holmqvist A, Wu J, Ness E,l Parman M, et al. Late Mortality after Allogeneic Blood or Marrow Transplantation for Inborn Errors of Metabolism: A Report from the Blood or Marrow Transplant Survivor Study-2 (BMTSS-2). Biol Blood Marrow Transplant. 2019; 25(2): 328–334. doi:10.1016/j.bbmt.2018.09.035.  
87. Peters C, Balthazor M, Shapiro EG, King RJ, Kollman C, Hegland JD, et al. Outcome of unrelated donor bone marrow transplantation in 40 children with Hurler syndrome. Blood. 1996;87: 4894–4902.  
88. Boelens JJ, Rocha V, Aldenhoven M, Wynn R, O’Meara A, Michel G, et al. Risk factor analysis of outcomes after unrelated cord blood transplantation in patients with hurler syndrome. Biol Blood Marrow Transplant. 2009;15: 618–625  
89. Ghosh A, Miller W, Orchard PJ, Jones SA, Mercer J, Church HJ, et al. Enzyme replacement therapy prior to haematopoietic stem cell transplantation in Mucopolysaccharidosis Type I: 10 year combined experience of 2 centres. Mol Genet Metab. 2016;117: 373–377.  
90. Aldenhoven M, Jones SA, Bonney D, Borrill RE, Coussons M, Mercer J, et al. Hematopoietic cell transplantation for mucopolysaccharidosis patients is safe and effective: results after implementation of international guidelines. Biol Blood Marrow Transplant. 2015;21: 1106–1109  
91. Bjoraker KJ, Delaney K, Peters C, Krivit W, Shapiro EG. Long-term outcomes of adaptive functions for children with mucopolysaccharidosis I (Hurler syndrome) treated with hematopoietic stem cell transplantation. J Dev Behav Pediatr. 2006;27: 290–296  
92. Kunin-Batson AS, Shapiro EG, Rudser KD, Lavery CA, Bjoraker KJ, Jones SA, et al. Long-Term Cognitive and Functional Outcomes in Children with Mucopolysaccharidosis (MPS)-IH (Hurler Syndrome) Treated with Hematopoietic Cell Transplantation. JIMD Rep. 2016;29: 95–102  
93. Gardin A , Castelle M , Pichard S , Cano A , Chabrol B , Piarroux J, et al. Long term follow-up after haematopoietic stem cell transplantation for mucopolysaccharidosis type I-H: a retrospective study of 51 patients. Bone Marrow Transplantation. 2023; 58:295–302; https://doi.org/10.1038/s41409-022-01886-1.  
94. Weisstein JS, Delgado E, Steinbach LS, Hart K, Packman S. Musculoskeletal manifestations of Hurler syndrome: long-term follow-up after bone marrow transplantation. J Pediatr Orthop. 2004;24: 97–101.  
95. Javed A, Aslam T, Jones SA, Mercer J, Tyler K, Church H, et al. The effect of haemopoietic stem cell transplantation on the ocular phenotype in mucopolysaccharidosis type I (Hurler). Acta Ophthalmol. 2018: 96: 494–498.  
96. Braunlin EA, Stauffer NR, Peters CH, Bass JL, Berry JM, Hopwood JJ, et al. Usefulness of bone marrow transplantation in the Hurler syndrome. Am J Cardiol. 2003;92: 882–886.97 Boelens JJ. Trends in haematopoietic cell transplantation for inborn errors of metabolism. J Inherit Metab Dis. 2006;29: 413–420.  
97. Kakkis ED, Muenzer J, Tiller GE, Waber L, Belmont J, Passage M, et al. Enzyme-replacement therapy in mucopolysaccharidosis I. N Engl J Med. 2001;344(3):182-8.  
98. Sifuentes M, Doroshow R, Hoft R, Mason G, Walot I, Diament M, et al. A follow-up study of MPS I patients treated with laronidase enzyme replacement therapy for 6 years. Mol Genet Metab. 2007;90(2):171-80.  
99. Wraith JE, Clarke LA, Beck M, Kolodny EH, Pastores GM, Muenzer J, et al. Enzyme replacement therapy for mucopolysaccharidosis I: a randomized, double-blinded, placebo-controlled, multinational study of recombinant human alpha-L-iduronidase (laronidase). J Pediatr. 2004;144(5):581-8.  
- 100.Jameson E, Jones S, Remmington T. Enzyme replacement therapy with laronidase (Aldurazyme<sup>®</sup> ) for treating mucopolysaccharidosis type I. Cochrane Database Syst Rev. 2019 Jun 18;6(6):CD009354. doi: 10.1002/14651858.CD009354.pub5.  
- 101.Polgreen LB, Bay L, Clarke LA, Guffon N, Jones SA, Munzer J, et al. Growth in individuals with attenuated mucopolysaccharidosis type I during untreated and treated periods: Data from the MPS I registry. Am J Med Genet. 2022;188A:2941–2951.  
- 102.Stewart F, Bentley A, Burton BK, Guffon N, Hale SL, HarmatzPR, et al. Expert Opinions on Managing Fertility and Pregnancy in Patients With Mucopolysaccharidosis. Journal of Inborn Errors of Metabolism & Screening. 2016; 4:1-11.  
- 103.Brasil. Agência Nacional de Vigilância Sanitária. Aldurazyme. 2024. Disponível em: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=ALDURAZYME..  
- 104.Castorina M, Antuzzi D, Richards SM, Cox GF, Xue Y. Successful pregnancy and breastfeeding in a woman with mucopolysaccharidosis type I while receiving laronidase enzyme replacement. therapy. Clin Exp Obstet Gynecol. 2015;42(1):108-13.  
- 105.Xue Y, Richards SM, Mahmood A, Cox GF. Effect of anti-laronidase antibodies on efficacy and safety of laronidase enzyme replacement therapy for MPS I: A comprehensive meta-analysis of pooled data from multiple studies. Mol Genet Metab. 2016;117(4):419-26.  
- 106.Toscano A, Musumeci O, Sacchini M, Ravaglia S, Siciliano G, et al. Safety outcomes and patients' preferences for homebased intravenous enzyme replacement therapy (ERT) in pompe disease and mucopolysaccharidosis type I (MPS I) disorder: COVID-19 and beyond. Orphanet J Rare Dis. 2023 Oct 27;18(1):338. doi: 10.1186/s13023-023-02919-8. PMID: 37891668; PMCID: PMC10604412.  
- 107.Horovitz DD, Acosta AX, Giugliani R, Hlavatá A, Hlavatá K, Tchan MC, et al. Alternative laronidase dose regimen for patients with mucopolysaccharidosis I: a multinational, retrospective, chart review case series. Orphanet J Rare Dis. 2016 Apr 29;11(1):51. doi: 10.1186/s13023-016-0437-8. PMID: 27129473; PMCID: PMC4850670.  
- 108.Giugliani R, Federhen A, Muñoz Rojas MV, Vieira TA, Artigalás O, Pinto LL, et al. [Enzyme replacement therapy for mucopolysaccharidoses I, II and VI: recommendations from a group of Brazilian F experts]. Rev Assoc Med Bras (1992).2010;56(3):271-7.  
- 109.Valayannopoulos V, Boddaert N, Barbier V, Le Merrer M, Caillaud C, de Lonlay P. Cognitive and neuroradiological improvement in three patients with attenuated MPS I treated by laronidase. Mol Genet Metab. 2010;100: 20–23.  
- 110.Eisengart JB, Rudser KD, Tolar J, Orchard PJ, Kivisto T, Ziegler RS, et al. Enzyme replacement is associated with better cognitive outcomes after transplant in Hurler syndrome. J Pediatr. 2013;162: 375–80.e1.  
- 111.Wraith JE, Beck M, Lane R, van der Ploeg A, Shapiro E, Xue Y, et al. Enzyme replacement therapy in patients who have mucopolysaccharidosis I and are younger than 5 years: results of a multinational study of recombinant human alpha-Liduronidase (laronidase). Pediatrics. 2007;120: e37–46.  
- 112.Clarke LA. The mucopolysaccharidoses: a success of molecular medicine. Expert Rev Mol Med. 2008;10:e1.  
- 113.1Clarke LA, Wraith JE, Beck M, Kolodny EH, Pastores GM, Muenzer J, et al. Long-term efficacy, and safety of laronidase in the treatment of mucopolysaccharidosis I. Pediatrics. 2009;123(1):229-40.  
- 114.Giugliani R, Rojas VM, Martins AM, Valadares ER, Clarke JT, Goes JE, et al. A dose-optimization trial of laronidase (Aldurazyme) in patients with mucopolysaccharidosis I. Mol Genet Metab. 2009;96(1):13-9.  
- 115.Harmatz P, Giugliani R, Schwartz I, Guffon N, Teles EL, Miranda MC, et al. Enzyme replacement therapy for mucopolysaccharidosis VI: a phase 3, randomized, double-blind, placebo-controlled, multinational study of recombinant human N-acetylgalactosamine 4-sulfatase (recombinant human arylsulfatase B or rhASB) and follow-on, open-label extension study. J Pediatr. 2006;148(4):533-9.  
- 116.Wraith JE, Beck M, Lane R, van der Ploeg A, Shapiro E, Xue Y, et al. Enzyme replacement therapy in patients who have mucopolysaccharidosis I and are younger than 5 years: results of a multinational study of recombinant human alpha-Liduronidase (laronidase). Pediatrics. 2007;120(1):e37-46 ~~.~~  
- 117.Marshall, WA, Tanner, JM. Variations in pattern of pubertal changes in girls. Arch Dis Child. 1969; 44: 291–303.  
- 118.Brasil. Ministério da Saúde. Portaria nº 199, de 30 de janeiro de 2014. Institui a Política Nacional de Atenção Integral às Pessoas com Doenças Raras, aprova as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no âmbito do Sistema Único de Saúde (SUS) e institui incentivos financeiros de custeio. Disponível em: https://bvsms.saude.gov.br/bvs/saudelgis/gm/2014/prt0199_30_01_2014.html  
- 119.Brasil. Brasil. Ministério da Saúde. Diretrizes para Atenção Integral às Pessoas com Doenças Raras. Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/diretrizes_atencao_integral_pessoa_doencas_raras_SUS.pdf  
- 120.Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS nº 2, de 28 de setembro de 2017. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html  
- 121.Brasil. Ministério da Saúde.  Portaria de Consolidação GM/MS nº 6, de 28 de setembro de 2017. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0006_03_10_2017.html

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE LARONIDASE** -->
Eu, _______________________________________________________________________________________(nome  
do(a) paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de laronidase, indicada para o tratamento de Mucopolissacaridase do tipo I.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) __________________  
_______________________________________________________________________(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes  
benefícios: melhora dos sintomas da doença, como da hepatomegalia e da rigidez articular.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Aqueles relatados em dois ou mais estudos foram erupção cutânea, urticária e febre;  
- Contraindicação em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da formula  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não  
queira ou não possa utilizá-lo ou se o tratamento for interrompido.  
Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento,  
desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
(    ) Laronidase  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Brasileiras da Mucopolissacaridose do tipo I (MPS I), contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor deste PCDT foi composto por especialistas e metodologistas sob a coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Conitec para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da MPS I. Não foram encontradas tecnologias disponíveis já incorporadas para o tratamento da MPS I, além da laronidase e do TCTH. Assim, não foram identificadas novas tecnologias diagnósticas e terapêuticas a serem priorizadas nesse PCDT.  
Na reunião de escopo para atualização do documento, ocorrida em 10 de abril de 2023, não foram identificadas novas tecnologias diagnósticas e terapêuticas a serem priorizadas para a revisão do PCDT em questão. Contudo, foram reconhecidos, na reunião de escopo que contou com a participação de especialistas na área, os pontos a terem a literatura atualizada e/ou necessidade de ajustes na redação, assim, definiu-se a necessidade de revisar e reorganizar o texto, tendo como público-alvo primário: clínicos gerais, geneticistas, neurologistas, cardiologistas, pneumologistas e traumato-ortopedistas e, como públicoalvo secundário: oftalmologistas, gastroenterologistas, patologistas e outros especialistas médicos.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: Colaboração externa -->
O Protocolo foi atualizado pelo NATS HCPA/Nuclimed.  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro A).  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente<br>a) Reembolso por comparecimento a eventos na área de interesse da diretriz|algum dos benefícios abaixo?<br>(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim|  
||(   ) Não|
|---|---|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afe|tados pela sua|
|atividade na elaboração ou revisão da diretriz?||
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e que|(   ) Sim|
|deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar sua<br>objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|  
**Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas**  
A proposta de atualização do PCDT de Mucopolissacaridose do tipo I (MPS I) foi apresentada na 118ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 27 de setembro 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial  
da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA).

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **Consulta Pública** -->
A Consulta Pública nº 82/2024, do Protocolo Clínico e Diretrizes Terapêuticas Mucopolissacaridose do tipo I (MPS I), foi realizada entre os dias 22/11/2024 e 11/12/2024 e não foram recebidas contribuições sobre o tema.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **5. Busca da evidência e recomendações** -->
O processo de atualização desse PCDT seguiu as recomendações das Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>3</sup> .  
Foram realizadas buscas sistematizadas da literatura nas bases de dados Medline, Embase, BVS (incluindo Lilacs) e Cochrane Library. Por se tratar de atualização de documentos oficiais já publicados, seguindo as recomendações da Cochrane, optou-se por definir uma data de início para as buscas.  
Considerando a versão do PCDT publicada por meio da Portaria Conjunta SAES-SCTIE/MS nº 12, de 11/04/2018, definiu-se a data inicial da busca em 01 de janeiro de 2018 e a data final em 15 de fevereiro de 2024.  
Foram realizadas buscas com três objetivos:  
a) Busca I: estudos clínicos, revisões sistemáticas e diretrizes, protocolos ou recomendações clínicas sobre aspectos de  
diagnóstico, seguimento, cuidados e tratamento daqueles com MPS I;  
b) Buscas II e III: identificação de estudos clínicos, revisões sistemáticas sobre o tratamento da MPS I em populações especiais de gestantes e lactantes, posto que algumas formas da doença ocorrem durante a idade fértil dos pacientes;  
c) Busca IV: identificação de estudos clínicos e revisões sistemáticas sobre laronidase, o medicamento de tratamento primário da MPS I disponível no SUS.  
d) Busca V: identificação de estudos clínicos e revisões sistemáticas sobre o transplante de células tronco hematopoiéticas/TCTH)  
As questões de pesquisa são apresentadas a seguir.  
Questão I – Quais são as evidências (na forma de estudos clínicos, revisões sistemáticas e diretrizes, protocolos ou recomendações clínicas) sobre aspectos de diagnóstico, seguimento, cuidados e tratamento daqueles com MPS I, produzidas a partir de 2018?  
A estrutura PICOT para esta questão se encontra no Quadro B:  
**Quadro B** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Pacientes com Mucopolissacaridose tipo I (MPS I)|
|---|---|
|Intervenção|Tratamento: não medicamentoso, sintomático/suporte, primário com Laronidase|
|Comparador(es)|Tratamento: não medicamentoso, sintomático/suporte ou transplante de células tronco<br>hematopoiéticas (TCTH)|
||Diagnóstico<br>Seguimento|
|Desfecho(s)|Eficácia (Desfechos clínicos)|
||neurológicos: atraso no desenvolvimento neuropsicomotor, hipertensão intracraniana,<br>convulsões, compressão medular;|  
||respiratórios/pulmonares: infecções respiratórias, alteração de função pulmonar, doença|
|---|---|
||obstrutiva das vias aéreas, distúrbios do sono do tipo apneia ou hipopneia, SAHOS;<br>musculoesqueléticos: redução na mobilidade articular, comprometimento atlanto-axial,<br>comprometimento da coluna, doença osteo-articular ;|
||desfechos cardíacos: valvulopatia, insuficiência cardíaca;|
||outros desfechos: visão, audição, hepatomegalia, qualidade de vida, mortalidade e excreção|
||de GAGs urinários.|
||Segurança|
|Tipos de estudo (desenhos)<br>de interesse|Estudos clínicos, revisões sistemáticas e diretrizes, protocolos ou recomendações clínicas|  
Nota: Foram incluídas publicações publicadas de 01/01/2018 a 15 de fevereiro de 2024.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **Quadro C** apresenta as estratégias de busca para esta questão. -->
**Quadro C** . Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou estudos clínicos e diretrizes clínicas ou protocolos clínicos ou recomendações clínicas sobre diagnóstico/ acompanhamento/ cuidados/ tratamento para MPS I.  
|**Bases de dados**|**Estratégia de busca**|**Número**<br>**encontrados**|**de**|**resultados**|
|---|---|---|---|---|
||(mucopolysaccharidosis type I [Title/Abstract]) AND||||
|Medline (via Pubmed)|((guidelines[Title/Abstract])<br>OR<br>recommendations[Title/Abstract]))|13|||
|Embase|(recommendations<br>OR<br>'practice<br>guideline')<br>AND<br>‘mucopolysaccharidosis type I': Broad search AND [2018-<br>2024]/py|39|||
|BVS|(mucopolysaccharidosis type I) AND (guidelines OR<br>recommendations)- Title, abstract, subject|16|||
||(mucopolysaccharidosis type I [Title/Abstract]) AND|1|||
|Cochrane library|((guidelines[Title/Abstract])<br>OR<br>recommendations[Title/Abstract]))||||  
Nota: Foram incluídas publicações publicadas de 01/01/2018 a 15 de fevereiro de 2024.  
Adicionalmente, na busca por diretrizes clínicas, protocolos clínicos e recomendações clínicas sobre diagnóstico, acompanhamento, cuidados e tratamento da MPS 1 foram também avaliados os seguintes documentos:  
- NICE _guidelines_ (http://www.nice.org.uk): Sem novas recomendações desde 2018.  
- _National Guideline Clearinghouse_ – Sem novas recomendações desde 2018.  
- _National Library of Australia. Department of Health and Ageing, Australian Government_ (http://www.health.gov.au).  
- Encontrado o ‘Guidelines for the treatment of mucopolysaccharidosis type I (MPS I) through the Life Saving Drugs Program’.  
- _Guideline International Network_ (http://www.g-i- n.net/library/international-guidelines- library): nenhuma diretriz  
- localizada.  
- Sociedade Brasileira de Genética Médica (http://www.sbgm.org.br): nenhuma diretriz localizada.  
- Diretrizes da Associação Médica Brasileira (AMB) (http://diretrizes.amb.org.br): nenhuma diretriz localizada.  
A única diretriz identificada, do governo australiano, é um guia resumido, de três folhas, sem referências ou qualquer descrição de metodologias.  
Foram encontradas 69 publicações das bases de dados PubMed, Embase, BVS e Cochrane library, além de uma diretriz encontrada por pesquisa direta em sites de agências de ATS. Excluindo-se as duplicatas, restaram 40 títulos, dos quais 36 foram excluídos na fase de título e resumo. As quatro referências restantes foram lidas integralmente, sendo três excluídas, de modo que apenas uma foi incluída (Figura A).  
**Figura A –** Seleção dos estudos para atualização sobre aspectos de diagnóstico, seguimento, cuidados e tratamento daqueles com MPS, produzidas a partir de 2018 (pesquisas em bases de dados, registros e outras fontes).  
<!-- Start of picture text -->
TitulosBasesidentificados:de dados e Registros procesoTitulos  deremovidos' screening:antes do Titulos identificados:alle Busca<br>(n=?) DDuplicatas removidas (n=30) neo) ctacses<br>Titulos selecionados Thnsios exxehuldos Titulos nao<br>(n=40) (n=36) Titulos buscados (n = 0) |—>| encontrados<br>(n=0)<br>Titulos buscados (n = 4) « Titulos avaliados para<br>Titulos no encontrados (n = 0) dlegibiidade (n= 0)<br>Titulos _avaliados. para<br>elegiiidade (n =4) Titulos exctuidos (n =3 )<br>Novos estudos inciuidos<br>(n=4)<br>Total de estudos NOVOS<br>incluidos<br>na reviso (n= 1)<br><!-- End of picture text -->  
Questão II- Quais as evidências (na forma de estudos clínicos e revisões sistemáticas) sobre o tratamento da MPS I em gestantes, produzidas a partir de 2018?  
A estrutura PICOT para esta questão se encontra no Quadro D.  
**Quadro D** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Gestantes com MPS tipo I|
|---|---|
|Intervenção|Tratamento primário para Lactantes com MPS tipo I com laronidase|
|Comparador(es)|Sem tratamento primário para MPS tipo I ou TCTH|
|Desfecho(s)|Segurança<br>Eficácia – desfechos neurológicos; respiratórios; musculo-esqueléticos:<br>cardíacos e outros desfechos (visão, audição, hepatomegalia, qualidade de|
||vida, mortalidade e excreção de GAGs urinários|
|Tipos de estudo (desenhos) de interesse|Estudos clínicos, revisões sistemáticas e coortes|  
Nota: Foram incluídas publicações publicadas de 01/01/2018 a 15 de fevereiro de 2024.  
O **Quadro E** apresenta as estratégias de busca para esta questão.  
**Quadro E** . Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre tratamento primário para MPS I e gestação/gravidez.  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||(pregnancy[Title/Abstract]) AND (laronidase[Title/Abstract])|0|
|Medline (via Pubmed)|(mucopolysaccharidosis type I [Title/Abstract]) AND<br>(pregnancy[Title/Abstract])|0|
|Embase|'pregnancy' AND ‘mucopolysaccharidosis type I’:ti,ab,kw AND [2018-<br>2024]/py<br>'pregnancy' AND ‘laronidase’:ti,ab,kw AND [2018-2024]/py|4<br>3|
||(mucopolysaccharidosis type I) AND (pregnancy)- Title, abstract,<br>subject|0|
|BVS|(laronidase) AND (pregnancy)- Title, abstract, subject|0|
||A partir de 2018||
|Cochrane Library|" mucopolysaccharidosis type I " in Title Abstract Keyword AND<br>pregnancy in Title Abstract Keyword - (Word variations have been<br>searched)<br>" laronidase" in Title Abstract Keyword AND pregnancy in Title<br>Abstract Keyword - (Word variations have been searched)|0<br>0|  
Nota: Foram incluídas publicações publicadas de 01/01/2018 a 15 de fevereiro de 2024.  
Foram identificadas 7 publicações. Excluindo-se as duplicatas, restaram 4 títulos, tendo sido 3 deles excluídos já na fase de leitura de título e resumo. Restou um único artigo que foi excluído na fase da elegibilidade. Assim, não foram incluídos títulos para análise neste tópico.  
A Figura B resume o processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
**Figura B** – Seleção de estudos para atualização sobre aspectos de tratamento de MPS I em gestantes, com laronidase, produzidas a partir de 2018 (pesquisas em bases de dados, registros e outras fontes).  
<!-- Start of picture text -->
Titulos identificados: Titulos removidos, antes do Titulos identificados: Busca<br>BasesCoaek dejy dadose istros processo de screening: referéncias/citacoe<br>(aaes © Rea Duplicatas removidas (n =3) tno) seers<br>Titulos selecionados Titulos exctuidos Titulos nao<br>(=a) (=3) Titulos buscados (n=0) | | encontrados<br>(1=0)<br>Titulos avaliados para<br>elegiolidade (n =1) Titulos excluidos (n = 1)<br>Novos estudos incluidos<br>(n=0)<br>Total de estudos NOVOS<br>incluidos<br>na revisdo (n =0)<br><!-- End of picture text -->  
Questão III- Quais as evidências (na forma de estudos clínicos e revisões sistemáticas) sobre o tratamento da MPS I em  
lactantes, produzidas a partir de 2021?  
A estrutura PICOT para esta questão se encontra no Quadro F.  
**Quadro F** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Lactantes com MPS tipo I|
|---|---|
|Intervenção|Tratamento primário para MPS tipo I com Laronidase|
|Comparador(es)|Sem tratamento primário para MPS I ou tratamento com TCTH|
||Eficácia – desfechos neurológicos; respiratórios; musculo-esqueléticos:|
|Desfecho(s)|cardíacos e outros desfechos (visão, audição, hepatomegalia, qualidade de|
||vida, mortalidade e excreção de GAGs urinários).|
|Tipos de estudo (desenhos) de interesse|Estudos clínicos, revisões sistemáticas e coortes|  
Nota: Foram incluídas publicações publicadas de 01/01/2018 a 15 de fevereiro de 2024.  
O **Quadro G** apresenta as estratégias de busca para esta questão.  
**Quadro G.** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou estudos clínicos DF sobre tratamento primário e amamentação  
|**Bases de dados**|**Estratégia de busca**|**Número de resultados**<br>**encontrados**|
|---|---|---|
||(mucopolysaccharidosis type I [Title/Abstract]) AND<br>(breastfeeding [Title/Abstract])|0|
|Medline (via Pubmed)|(laronidase [Title/Abstract]) AND (breastfeeding<br>[Title/Abstract])|1|
|Embase|'breastfeeding' AND mucopolysaccharidosis type I’:ti,ab,kw<br>AND [2018-2024]/py<br>'breastfeeding' AND laronidase’:ti,ab,kw AND [2018-<br>2024]/py|7<br>0|
|BVS|(mucopolysaccharidosis type I) AND (breastfeeding)- Title,<br>abstract, subject<br>(laronidase) AND (breastfeeding)- Title, abstract, subject|0<br>0|
|Cochrane Library|mucopolysaccharidosis type I Title Abstract Keyword AND<br>breastfeeding in Title Abstract Keyword - (Word variations<br>have been searched)<br>laronidase Title Abstract Keyword AND breastfeeding in<br>Title Abstract Keyword - (Word variations have been<br>searched)|0<br>0|  
Nota: Foram incluídas publicações publicadas de 01/01/2018 a 15 de fevereiro de 2024.  
Foram encontradas 8 publicações nas bases de dados, com uma duplicata. Todos os 7 estudos restantes foram excluídos já na fase de leitura de título e resumo. Desta forma, não foram incluídos títulos para análise neste tópico.  
A Figura C resume o processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
**Figura C** - Seleção de estudos para atualização (na forma de estudos clínicos e revisões sistemáticas) sobre o tratamento da MPS I com laronidase em lactantes, (produzidas a partir de 2018).  
<!-- Start of picture text -->
Titulos identificados: Titulos removidos, antes do Titulos identificados: Busca<br>Bases de dados e Registros processo de screening: jasicitacbes:<br>(ws) Duplicatas removidas (n =1 ) Hens lala<br>Titulos selecionados Titulos exctuidos Titulos nao<br>encontrados<br>(n=7 ) (n-7) Titulos buscados (n=0) | |<br>(n=0)<br>Titulos avaliados para<br>elegibilidade (n= 0) Titulos excluidos (n = 0)<br>Novos estudos incluidos<br>(n=0)<br>Total de estudos NOVOS<br>incluidos na revisao (n =0)<br><!-- End of picture text -->  
Questão IV Quais os dados disponíveis, advindos de estudos clínicos e revisões sistemáticas, sobre a tecnologia laronidase para o tratamento primário da MPS I, produzidas a partir de 2018?  
A estrutura PICOT para esta questão se encontra no Quadro H.  
**Quadro H** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Pacientes com MPS tipo I|
|---|---|
|Intervenção|Tratamento primário para MPS tipo I com laronidase|
|Comparador(es)|Sem tratamento primário para MPS tipo I ou tratamento com TCTH|
|Desfecho(s)|Eficácia<br>neurológicos: atraso no desenvolvimento neuropsicomotor, hipertensão<br>intracraniana, convulsões, compressão medular;<br>respiratórios/pulmonares: infecções respiratórias, alteração de função<br>pulmonar, doença obstrutiva das vias aéreas, distúrbios do sono do tipo<br>apnéia ou hiponéia, SAHOS;<br>musculo-esqueléticos: redução na mobilidade articular, comprometimento<br>atlanto-axial, comprometimento da coluna, doença osteo-articular ;<br>desfechos cardíacos: valvulopatia, insuficiência cardíaca;<br>desfechos outros: hepatomegalia, qualidade de vida, mortalidade e excreção<br>de GAGs urinários.|  
||Segurança|
|---|---|
|Tipos de estudo (desenhos) de interesse|Estudos clínicos, revisões sistemáticas e coortes|  
O **Quadro I** apresenta as estratégias de busca para esta questão.  
**Quadro I.** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre uso da laronidase em MPS I  
|**Bases de dados**|**Estratégia de busca**|**Número de resultados**<br>**encontrados**|
|---|---|---|
|Medline (via Pubmed)|(("Laronidase"[all<br>fields)<br>OR<br>("Recombinant<br>α-L-<br>iduronidase"[Text Word]) OR<br>("Aldurazyme"[Text Word]))|61|
|Embase|(‘laronidase’/exp OR ‘laronidase’:ti,ab,kw OR 'recombinant<br>α-L-iduronidase':ti,ab,kw OR 'Aldurazyme':ti,ab,kw OR)<br>AND [embase]/lim|85|
|BVS|(("laronidase") OR ("recombinant α-L-iduronidase") OR<br>("Aldurazyme"))<br>Title, abstract, subject|45|
|Cochrane Library<br>Nota: Foram incluídas publicaçõe|("laronidase") in Title Abstract Keyword OR ("Recombinant<br>α-L-iduronidase")<br>in<br>Title<br>Abstract<br>Keyword<br>OR<br>("Aldurazyme") in Title Abstract Keyword- (Word variations<br>have been searched)<br>s publicadas de 01/01/2018 a 15 de fevereiro de 2024.|2|  
Foram identificadas 193 publicações das bases de dados. Excluindo-se 77 duplicatas, restaram 154 títulos, dos quais 151 foram excluídos na fase de leitura de título e resumo. Dos 3 restantes, um foi excluído na fase final de elegibilidade. Ao final, os dois artigos avaliados na sua integralidade foram incluídos.  
A **Figura D** resume o processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
**Figura D** – Selação dos estudos para atualização sobre (na forma de estudos clínicos e revisões sistemáticas) sobre o uso da laronidase no tratamento da MPS I, (produzidas a partir de 2018).  
<!-- Start of picture text -->
Titulos identificados: Titulos removidos, antes do Titulos identificados: Busca<br>BasesBasesdede daddatos Resjstros processocess de screening.Ss (77) nasrferncanctaces: _<br>Titulos selecionados Titulos exctuidos Titulos nao<br>{n= 154) (n=151) Titulos buscados (n = 0) | >| encontrados<br>(n=0)<br>Titulos buscados (n =3)<br>‘Ties no enconados (= 0) eleaibitdade (9 = 0)<br>[meneame _ Titulos —avaliados. para<br>Titulos avaliados para<br>elegibilidade (n =3) Titulos excluidos (n =4)<br>Novos estudos incluidos<br>(n=2)<br>Totalincluidosde na revisdoestudos(n =2)NOVOS<br><!-- End of picture text -->  
Questão V Quais os dados disponíveis, advindos de estudos clínicos e revisões sistemáticas, sobre a tecnologia TCTH  
para o tratamento primário da MPS I produzidas a partir de 2018?  
A estrutura PICOT para esta questão se encontra no Quadro J.  
**Quadro J** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Pacientes com MPS tipo I|
|---|---|
|Intervenção|Tratamento primário para MPS tipo I submetidos a TCTH|
|Comparador(es)|Sem tratamento primário para MPS tipo I com laronidase ou sem tratamento|
|Desfecho(s)|Eficácia<br>neurológicos: atraso no desenvolvimento neuropsicomotor, hipertensão intracraniana,<br>convulsões, compressão medular;<br>respiratórios/pulmonares: infecções respiratórias, alteração de função pulmonar, doença<br>obstrutiva das vias aéreas, distúrbios do sono do tipo apnéia ou hiponéia, SAHOS;<br>musculo-esqueléticos: redução na mobilidade articular, comprometimento atlanto-axial,<br>comprometimento da coluna, doença osteo-articular ;<br>desfechos cardíacos: valvulopatia, insuficiência cardíaca;<br>desfechos outros: hepatomegalia, qualidade de vida, mortalidade e excreção de GAGs urinários.|
||Segurança|
|Tipos<br>de<br>estudo<br>(desenhos) de interesse|Estudos clínicos, revisões sistemáticas e coortes|

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: O **Quadro K** apresenta as estratégias de busca para esta questão. -->
**Quadro K-** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre uso do TCTH em MPS I  
|**Bases de dados**|**Estratégia de busca**|**Número de resultados**<br>**encontrados**|
|---|---|---|
|Medline (via Pubmed)|((("Bone Marrow Transplantation"[MeSH Terms] AND<br>"Mucopolysaccharidosis I"[MeSH Terms]) OR "Stem Cell<br>Transplantation"[MeSH<br>Terms])<br>AND<br>"Mucopolysaccharidosis I"[MeSH Terms])|47|
|Embase|('bone marrow transplantation'/exp OR 'bone marrow<br>transplantation') AND ('mucopolysaccharidosis type 1'/exp<br>OR 'mucopolysaccharidosis type 1')|82|
|BVS|(Bone<br>Marrow<br>Transplantation)<br>AND<br>(Mucopolysaccharidosis I)|13|
|Cochrane Library|“Bone Marrow Transplantation” in Title Abstract Keyword<br>AND "mucopolysaccharidosis type 1" in Title Abstract<br>Keyword - (Word variations have been searched)|0|  
Nota: Foram incluídas publicações publicadas de 01/01/2018 a 15 de fevereiro de 2024.  
Foram identificadas 142 publicações nas bases de dados. Excluindo-se as duplicatas, restaram 99 títulos, dos quais 95 foram excluídos na fase de leitura de título e resumo. Quatro artigos foram avaliados na sua integralidade: um deles foi excluído e 3 incluídos.  
A **Figura E** resume o processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
**Figura E** - Seleção de estudos para atualização sobre (na forma de estudos clínicos e revisões sistemáticas) sobre o uso de TCTH no tratamento da MPS I, (produzidas a partir de 2018).  
<!-- Start of picture text -->
TitulosBases identificados: de dados  Registros Titulosprocessoremowces de screening.antes do Tituloserertaciantchidentificados: Busca<br>(n=142) ‘Duplicatas removidas (n=43) tno) acbes<br>Titulos selecionados ‘Titslos exctukios Titulos nao<br>(n=99) {n=98) Titulos buscados (n = 0) || encontrados<br>(n=0)<br>Titulos buscados (n= 4) 5 Titulos avaliados para<br>[memmon | ‘Tos no encontados (= 0) ctoghidace (n = 0)<br>Titulos avaliados para<br>elegibilidade (n=4) Titulos excluidos (n=)<br>Novos estudos inciuidos<br>(n=3)<br>Total de estudos NOVOS<br>incluidos na revisdo (n=3)<br><!-- End of picture text -->  
Para responder todas as questões, foram considerados os seguintes critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com MPS I, independente da faixa etária ou da forma da doença.  
Em relação às buscas II e III, específicas para gestantes e lactantes, apenas este grupo de pacientes com MPS I foi considerado.  
- (b) Tipo de intervenção  
Tratamento primário com laronidase ou TCTH ou sintomático ou suporte.  
- (c) Tipos de estudos  
Ensaios clínicos, revisões sistemáticas e coortes.  
A primeira estratégia de busca incluiu ainda diretrizes clínicas, protocolos clínicos e recomendações clínicas sobre  
aspectos de diagnóstico, seguimento, cuidados e tratamento daqueles com MPS I.  
- (d) Desfechos  
Eficácia e Segurança (em relação à busca I, que envolveu diretrizes, os aspectos de diagnóstico e seguimento clínico  
também foram considerados).  
- (e) Idioma  
Sem restrição de idioma.  
- (f) Período temporal  
O Quadro L elenca os artigos excluídos após leitura de texto completo nas cinco buscas realizadas e a razão da exclusão.  
**Quadro L.** Estudos excluídos durante a fase de leitura do texto completo e o motivo da exclusão.  
|**Artigos excluídos na fase de elegibilidade (texto completo)**|**Razão da exclusão**|
|---|---|
|Questão 1<br>3 artigos excluídos na fase de elegibilidade||
|Stapleton M, Hoshina H, Sawamoto K, Kubaski F, Mason RW,<br>Mackenzie WG, et al. Critical review of current MPS guidelines and<br>management. Mol Genet Metab. 2019; 126 (3):238-245. doi:<br>10.1016/j.ymgme.2018.07.001.|Tipo de estudo. Não se tratam de diretrizes, mas<br>uma análise de diretrizes feitas.|
|Departmento de saúde e envelhecimento do governo Australiano,<br>(http://www.health.gov.au), o ‘Guidelines for the treatment of<br>mucopolysaccharidosis type I (MPS I) through the Life Saving Drugs<br>Program’. 2020|Texto é apenas um fluxo (flowchart) sem<br>referências e sem qualquer aspecto metodológico<br>descrito/explicitado.|
|‘Guidance for the treatment of Mucopolysaccharidosis type I (MPS I)’<br>da Lysosomal Storage Disorders Support Society (LSDSS). 2022|Texto contém tópicos numerados. Sem referências<br>e<br>sem<br>qualquer<br>aspecto<br>metodológico<br>descrito/explicitado.|
|Questão 2<br>1 artigo excluído na fase de elegibilidade||
|Anderson PO. Drug Therapy of Genetic Diseases During Breastfeeding.<br>Breastfeeding Medicine. 2020; 15(7):1-3. DOI: 10.1089/bfm.2020.0109|Revisão não sistemática.|
|Questão 3<br>Sem artigos excluídos na fase de elegibilidade||
|Questão 4<br>1 artigo excluído na fase de elegibilidade||
|Instituto Nacional de Salud Perú. Laronidasa para el tratamiento de<br>pacientes con mucopolisacaridosis tipo 1. Serie Evaluation de<br>Tecnologia Sanitaria rapida 2018. n 24|Revisão rápida de tecnologia|
|Questão 5<br>1 artigo excluído na fase de elegibilidade||
|Gentner B, Tucci F, Galimberti S, Fumagalli F, De Pellegrin M, Silvani<br>P, et al. Hematopoietic Stem- and Progenitor-Cell Gene Therapy for<br>Hurler Syndrome. N Engl J Med 2021; 385:1929-40. DOI:<br>10.1056/NEJMoa2106596|Intervenção avaliada: transplante de células<br>hematopoiéticas associado à terapia gênica|

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: Análise e apresentação dos resultados -->
Não foram encontrados estudos com atualizações consideradas relevantes.  
As recomendações para diagnóstico, seguimento e tratamento encontradas não alteraram aquelas já consideradas na elaboração do PCDT publicado por meio da Portaria Conjunta SAES-SCTIE/MS nº 12/2018.  
Uma revisão sistemática seguida de meta-análise, elaborada pela Cochrane, sobre o uso da laronidase não alterou as evidências sobre o tema. Uma coorte de pacientes tratados com TRE avaliou o seu crescimento com ou sem a reposição enzimática, em relação às curvas padrão para idade e sexo. Não foi encontrado ensaio clínico randomizado.  
Resumo das evidências:  
As recomendações sobre diagnóstico, acompanhamento e tratamento da MPS I, publicadas em 2021, por Bay et al<sup>2</sup> não alteraram as recomendações deste PCDT, provavelmente porque o trabalho foi desenvolvido para atualizar as recomendações da Argentina, as quais eram de 2008.  
A revisão seguida de meta-análise, publicada pela Cochrane em 2019, com foco na laronidase<sup>3</sup> , é a segunda atualização de uma revisão originalmente feita em 2013 e já atualizada em 2015. O estudo comparou laronidase e placebo, com tempo de acompanhamento de 26 semanas, e observou uma redução de 54% (estatisticamente significativa) nos GAGs urinários em relação ao basal naqueles que usaram laronidase. O grupo que usou laronidase obteve melhoras estatisticamente significativas na percentagem da capacidade vital forçada prevista em comparação com o placebo [média 5,60l (IC95% 1,24 a 9,96l)] e no teste de caminhada de seis minutos, havendo melhora média de 38,1 metros no grupo da laronidase (P=0,039), em análise de covariância planejada prospectivamente. Além disso, houve melhora nos desfechos relacionados a hepatomegalia, apneia do sono e hipopneia. Anticorpos contra a laronidase foram detectados em quase todos os participantes do grupo de tratamento, sem efeito clínico aparente e cujos títulos diminuíram no final do estudo. Ocorreram eventos adversos relacionados com a infusão em ambos os grupos, mas todos ligeiros e sem necessidade de intervenção médica ou interrupção do medicamento. Conforme avaliado por questionários, as alterações no “Índice de Incapacidade” após o tratamento foram pequenas e não diferiram entre os grupos. Não houve mortes em nenhum dos grupos. Todos estes achados foram categorizados como certeza da evidência baixa, com exceção do desfecho ‘anticorpos contra laronidase’, que foi categorizada como de muito baixa certeza.  
Um estudo de Polgreen et al<sup>4</sup> comparou as curvas de crescimento pré e pós terapia de reposição enzimática (TRE), em pacientes com forma atenuada de MPS I. Originalmente, 425 pacientes foram acompanhados, contudo, 26 foram excluídos por terem realizado TCTH e outros 103, por ausência de registros de altura. A população final estudada consistiu em 295 indivíduos, com 2.704 registros de altura. Desses, 142 eram homens e 153 eram mulheres, entre 2 e 18 anos de idade. Os escores z padronizados de altura/idade, ajustados para o sexo, foram comparados naqueles com e sem uso de TRE. Houve redução significativamente mais lenta nos escores z de altura/idade naqueles usando TRE em comparação com aqueles sem a TRE. Os escores z médios estimados de altura com TRE versus sem TRE, aos 10 anos de idade, foram -2,4 versus -3,3 nas mulheres e - 1,4 versus -2,9 em homens, com tempo médio pós-tratamento de 3 anos em mulheres e menor que 4,1 anos em homens. Enquanto a altura média de todos permaneceu abaixo dos padrões do CDC, a terapia com a laronidase foi associada a declínio mais lento nos escores z de altura.  
Ainda, três dos artigos encontrados diziam respeito ao TCTH, sendo todos coortes.  
O estudo de Javel et al<sup>5</sup> avaliou aspectos oculares com a realização de TCTH. Os autores utilizaram os testes visuais LogMAR (caracteres/letras em formato de tabela usados para avaliar a acuidade visual para perto) e fizeram uma análise de regressão da acuidade LogMAR com o nível de iduronidase. A análise mostrou relação negativa significativa (R2=0,15, p=0,004), indicando melhor acuidade associada com níveis elevados de iduronidase. No entanto, esse trabalho tem limitações metodológicas e não apresenta os dados de forma clara.  
Já o estudo de Wadhwa et al<sup>6</sup> acompanhou 96 pacientes com síndrome de Hurler submetidos ao TCTH alogênico que sobreviveram por 2 anos ou mais. No momento do transplante, a idade mediana era 1,5 anos (variando de 0,40 a 6 anos). Tendo sobrevivido por dois ou mais anos após o TCTH, o tempo de acompanhamento médio foi de 13,2 anos (variando de 1,6 a 31,4 anos). Nesse período, 14 pacientes (14,6%) morreram, sendo a sobrevida global de 96,6 ± 1,9% em 5 anos e 93,6 ± 2,8% em 10 anos pós-TCTH. Os pacientes dessa coorte exibiram um risco 22 vezes maior de mortalidade relativa (IC 95%, 12 a 37 vezes) em comparação com os membros de uma coorte de mesma idade e sexo, da população geral dos EUA. Quanto menor a idade da realização do TCTH, menor o risco de mortalidade tardia por todas as causas [HR, 0,20; IC 95%, 0,05 a 0,90; p=0,03] em comparação com o transplante realizado tardiamente, ou seja, aquele realizado em idade superior à mediana. Os dados da causa da morte estavam disponíveis para todosos catorze pacientes que morreram. A causa mais prevalente para o óbito foi a progressão da doença primária (n = 10; 71%), seguida de doenças cardíacas (n = 4; 29%) e doenças pulmonares (n = 4; 29%).  
Por fim, Gardin et al<sup>7</sup> acompanharam 51 pacientes com forma grave de MPS I (síndrome de Hurler) submetidos ao TCTH na França, entre 1986 e 2018. O tempo mediano de seguimento dos pacientes foi 9 anos (entre 8 e 16,5 anos). Quatro pacientes morreram por complicações do TCTH e um por progressão da doença. Quimerismo completo e atividade normal da enzima α- L-Iduronidase foram obtidos em 84% e 71% dos pacientes, respectivamente. Todos os pacientes adquiriram marcha independente, 91% adquiriram linguagem inteligível e e 78% adquiriram capacidade de leitura e escrita. A avaliação do Quociente de Inteligência (n = 23) mostrou que 69% tinham QI maior ou igual a 70 no último acompanhamento. Ainda, 58% dos pacientes tinha escolaridade normal ou “aceitável” e 62% dos 13 adultos tinham boa inserção socioprofissional. No entanto, os autores observaram que a displasia esquelética, bem como as deficiências visuais e auditivas, progrediu apesar do TCTH, levando à incapacidade significativa.  
Considerações gerais e para implementação:  
Não foram encontradas evidências sobre a disponibilização de novos tratamentos ou exames diagnósticos para a MPS I. Perfil de evidências:  
Foram incluídas novas referências acerca de todas as dúvidas clínicas elaboradas (diagnóstico, tratamento e monitorização da MPS I, tratamento com laronidase e com TCTH): uma diretriz clínica<sup>2</sup> , uma revisão sistemática com meta-análise<sup>3</sup> , e quatro coortes<sup>4-7</sup> . Não foram encontradas referências novas sobre tratamento com TRE em gestantes e lactantes que obedecessem aos critérios pré-estabelecidos nas respectivas perguntas PICO para serem incorporadas a este PCDT.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **6. REFERÊNCIAS** -->
1. Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71.  
2. Bay L, Amartino H, Antacle A, Arberas C, et al. Nuevas recomendaciones para el cuidado de los pacientes con mucopolisacaridosis tipo I. Arch Argent Pediatr 2021;119(2):e121-e128.  
3. Jameson E, Jones S, Remmington T. Enzyme replacement therapy with laronidase (Aldurazyme<sup>®</sup> ) for treating mucopolysaccharidosis type I. Cochrane Database Syst Rev. 2019 Jun 18;6(6):CD009354. doi: 10.1002/14651858.CD009354.pub5.  
4. Polgreen LB, Bay L, Clarke LA, Guffon N, Jones SA, Munzer J, et al. Growth in individuals with attenuated mucopolysaccharidosis type I during untreated and treated periods: Data from the MPS I registry. Am J Med Genet. 2022;188A:2941–2951.  
5. Javed A, Aslam T, Jones SA, Mercer J, Tyler K, Church H, et al. The effect of haemopoietic stem cell transplantation on the ocular phenotype in mucopolysaccharidosis type I (Hurler). Acta Ophthalmol. 2018: 96: 494–498.  
6. Wadhwa A, Chen Y, Holmqvist A, Wu J, Ness E,l Parman M, et al. Late Mortality after Allogeneic Blood or Marrow Transplantation for Inborn Errors of Metabolism: A Report from the Blood or Marrow Transplant Survivor Study-2 (BMTSS-2). Biol Blood Marrow Transplant. 2019; 25(2): 328–334. doi:10.1016/j.bbmt.2018.09.035.  
7. Gardin A, Castelle M , Pichard S , Cano A , Chabrol B , Piarroux J, et al. Long term follow-up after haematopoietic stem cell transplantation for mucopolysaccharidosis type I-H: a retrospective study of 51 patients. Bone Marrow Transplantation (2023) 58:295–302; https://doi.org/10.1038/s41409-022-01886-1.  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **PROGRAMA MÍNIMO DE ACOMPANHAMENTO DE PACIENTES COM MPS I (EM USO OU NÃO DE TRE)** -->
Avaliação inicial e período de acompanhamento clínico **mínimo sugerido** para pacientes com Mucopolissacaridose I.  
|**Avaliações**|**Avaliação inicial**|**A cada 6 meses***|
|---|---|---|
|Atividade enzimática|X|Realizar a cada 30 dias se paciente realizou<br>TCTH (primeiros 6 meses após transplante).<br>Depois, a cada 6 meses.|
|Genotipagem|Obrigatória se a indicação<br>de TCTH for possível||
|GAGs urinários|X|X<br>(se paciente realizouTCTH, realizar a cada mês<br>nos primeiros 6 meses após transplante)|
|História médica|X|X|
|Revisão do número de infusões realizadas<br>no período||X|
|Determinação da adesão ao<br>acompanhamento/tratamento|X|X|
|Peso/altura|X|X|
|Pressão arterial|X|X|
|Hepatimetria (exame físico)|X|X|
|Questionário de qualidade de vida<br>validado**|X||
|- Exame neurológico|X|X|
|- RNM do crânio|X||
|- RNM da coluna|X||
|- Velocidade de condução do nervo<br>mediano|X||
|- Avaliação do neurodesenvolvimento|X|Obrigatória pré-TCTH.|
|AVALIAÇÃO OFTALMOLÓGICA<br>(acuidade visual, retina, córnea)|X||
|AUDIOMETRIA|X||
|- Ecocardiograma|X||
|- Eletrocardiograma|X||
|- CVF/VEF1 (espirometria)|X||
|- Polissonografia|X||  
|**Avaliações**|**Avaliação inicial**|**A cada 6 meses***|
|---|---|---|
|AVALIAÇÃO<br>DA<br>MOBILIDADE|X|X|
|ARTICULAR|||
|RADIOGRAFIA SIMPLES DE OSSOS|X||  
Fonte: Elaborado com base em Hampe et al 2022, Han 2020, Clarke 2024  
*Para pacientes em tratamento específico. Os demais casos e as demais avaliações devem ser realizadas em períodos determinados pelo médico assistente. GAGs = glicosaminoglicanos; RNM = ressonância magnética; CVF = capacidade vital forçada; VEF1 = volume expiratório forçado no primeiro segundo. NOTA: No seguimento de pacientes submetidos ao TCTH, observar outra orientação porventura dada pelo centro transplantador.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **REFERÊNCIAS** -->
1. Hampe CS, Eisengart JB, Lund TC, Orchard PJ, Swietlicka M, Wesley J, ey al. Mucopolysaccharidosis Type I: A Review of the Natural History and Molecular Pathology. Cells. 2020; 9(8):1838. doi: 10.3390/cells9081838  
2. Han S. Mucopolysaccharidoses: Clinical features and diagnosis. Uptodate. 2020. Disponível em: https://www.uptodate.com/contents/mucopolysaccharidoses-clinical-features-and-  
- diagnosis?search=MPS%20I&source=search_result&selectedTitle=1%7E18&usage_type=default&display_rank=1  
3. Clarke LA. Mucopolysaccharidosis Type I. 2002 [atualização em 2024, Apr 11]. Em: Adam MP, Feldman J, Mirzaa GM, Pagon RA, Wallace SE, Bean LJH, Gripp KW, Amemiya A, editores. GeneReviews® [Internet]. Seattle (WA): University of Washington, Seattle; 1993–2024.

---

<!-- METADADOS: doenca: Mucopolissacaridose do tipo I | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório da**|||**Tecnol**|**ogias avalia**|**das pela Conitec**|
|---|---|---|---|---|---|
|**diretriz clínica (Conitec) ou**<br>**Portaria de Publicação**|**Principais alterações**|**Incorpora**<br>**u**|**ção ou al**<br>**so no SU**|**teração do**<br>**S**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório de Recomendação nº<br>983/2025|Atualização do conteúdo<br>do PCDT|-|||-|
|||Laronidase|como|terapia de||
|||reposição|enzim|ática<br>na||
|Portaria<br>Conjunta<br>SAES-<br>SCTIE/MS nº 12, 11 de abril<br>de 2018|Primeira versão do PCDT<br>do<br>documento<br>com<br>incorporação<br>de<br>tecnologias|mucopoliss<br>[Relatório<br>Portaria SC<br>Ampliação<br>Células|acaridose<br>Técnico<br>TIE/MS n<br>do Tra<br>-|<br>tipo<br>I<br> <br>nº<br>293;<br>º 37/2017]<br>nsplante de<br>Tronco|-|
|||Hematopoié|ticas|para||
|||Mucopoliss<br>[Relatório<br>Portaria  SC|acaridose<br>Técnico<br>TIE/MS|<br>Tipo<br>I<br> <br>nº<br>329;<br>nº 08/2018]||

---

