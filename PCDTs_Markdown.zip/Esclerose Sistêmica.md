<!-- METADADOS: doenca: Esclerose Sistêmica | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE -->
PORTARIA CONJUNTA Nº 16, de 10 de AGOSTO de 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Sistêmica.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a esclerose sistêmica no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 734/2022 - e o Relatório de Recomendação n<sup><u>o</u></sup> 737 – junho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Esclerose Sistêmica.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da esclerose sistêmica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser</u> utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da esclerose sistêmica.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS n<sup>o</sup> 9, de 28 de agosto de 2017, publicada no Diário Oficial da União nº 170, de 04 de setembro de 2017, seção 1, página 50.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: MAÍRA BATISTA BOTELHO -->
SANDRA DE CASTRO BARROS  
ANEXO

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **1. INTRODUÇÃO** -->
A Esclerose Sistêmica (ES) é uma doença rara, sistêmica, imunomediada e crônica que compromete principalmente a pele, os vasos sanguíneos, o trato gastrointestinal, o sistema musculoesquelético, os pulmões, os rins e o coração<sup>1,2</sup> . Dados internacionais indicam que ela ocorre mais em mulheres, com uma proporção de 3:1 a 8:1 com relação aos homens<sup>3</sup> e seu diagnóstico ocorre, em geral, entre os 30 e 50 anos de idade<sup>4</sup> <mark>. A incidência global da ES é de 1,4 novos casos por 100.000/ano enquanto a prevalência estimada é de 17,6 por 100.000 habitantes</mark><sup>5</sup> <mark>.</mark> No Brasil, o único estudo de prevalência e incidência disponível foi realizado no Mato Grosso do Sul e demonstrou uma taxa de prevalência estimada de 10,56 casos por 100 mil habitantes, e de incidência de 1,19 novos casos por 100 mil habitantes/ano<sup>6</sup> .  
A etiologia da ES é desconhecida e sua patogênese é complexa, desafiadora e envolve a tríade: disfunção imune, vasculopatia e fibrose<sup>2</sup> . A ativação imunológica, o dano vascular e a síntese excessiva de matriz extracelular com deposição de quantidades aumentadas de colágeno são variáveis importantes no desenvolvimento e evolução desta doença<sup>7</sup> . Assim, a heterogeneidade nas características clínicas dos pacientes com ES é provavelmente um reflexo das variáveis contribuições que resultam de interações célula-célula, célula-citocina e célula-matriz<sup>2</sup> .  
A ES inclui as seguintes manifestações clínicas:  
- Cutâneas: caracterizada por três fases - edematosa ( _puffy fingers_ ), a fase indurativa e a atrófica, na qual a pele se torna seca, descamativa e aderida a planos profundos; leucomelanodermia e calcinoses também são frequentes;  
- Vasculares: o fenômeno de Raynaud geralmente é a primeira manifestação da doença; úlceras isquêmicas digitais; telangiectasias;  
- Musculoesqueléticas: artrite, tendinite, atrito de tendão e contraturas articulares;  
- Gastrointestinais: dismotilidade esofágica e intestinal, refluxo gastroesofágico, síndrome disabsortiva, supercrescimento bacteriano;  
- Pulmonares: pneumopatia intersticial, fibrose e hipertensão pulmonar;  
- Cardíaco: todos os domínios anatômicos do coração podem ser afetados, incluindo o miocárdio, pericárdio e sistema de condução;  
- Renais: crise renal esclerodérmica;  
- Neuromuscular: atrofia muscular (sarcopenia), fraqueza muscular e miopatia, estas últimas são cada vez mais reconhecidas como os principais contribuintes para a morbidade da ES;  
- Geniturinários: comumente associada à disfunção erétil em homens, a qual pode ser uma manifestação precoce e até inicial da doença<sup>2</sup> .  
A ES é classificada com base na extensão do acometimento cutâneo, sendo os diferentes subtipos associados a manifestações clínicas e laboratoriais e a histórias naturais distintas<sup>2</sup> . Os três subtipos de ES e as principais manifestações que os pacientes geralmente apresentam em cada um deles são:  
- Esclerose sistêmica cutânea limitada: dedos edemaciados distais às articulações metacarpofalângicas, podendo desenvolver espessamento cutâneo em face e distalmente aos cotovelos e joelhos; manifestações vasculares proeminentes, incluindo fenômeno de Raynaud grave, telangiectasias, seguidos por um início tardio de hipertensão arterial pulmonar, e tipicamente associado à presença de anticorpos anticentrômero;  
- Esclerose sistêmica cutânea difusa: mãos edemaciadas e espessamento da pele que se estende proximalmente à parte superior do braço, coxas ou tronco, geralmente com evolução progressiva e rápida, associada à presença de acometimento pulmonar intersticial precoce; risco elevado de desenvolverem crise renal esclerodérmica e acometimento cardíaco; predominância de anticorpos anti-topoisomerase I (antiScl70) e anti-RNA polimerase III;  
- _Sine_ escleroderma: sem acometimento cutâneo detectável, mas com características clínicas como Raynaud grave, úlceras digitais e hipertensão arterial pulmonar, junto com a presença de autoanticorpos específicos e padrão capilaroscópico associado à ES.  
Apesar de haver estes três subtipos conhecidos de ES e de suas manifestações serem bem conhecidas, não existe um teste diagnóstico único para a doença. O diagnóstico é geralmente baseado em características clínicas, presença de autoanticorpos e nos achados da capilaroscopia periungueal.  
Mesmo não sendo tão prevalente quanto outras doenças reumatológicas, a ES, principalmente em sua forma difusa, tem a maior taxa de morbidade e mortalidade, mesmo com atendimento em centros especializados e com abordagem multidisciplinar<sup>8</sup> . Pelo acometimento cutâneo e de órgãos internos, pacientes com ES apresentam importante redução da qualidade de vida<sup>9</sup> e uma importante diminuição na expectativa média de vida<sup>10</sup> . A sobrevida cumulativa desde o diagnóstico da ES é de 74,9% em 5 anos e 62,5% em 10 anos, sendo que o acometimento pulmonar representa a principal causa de mortalidade<sup>11</sup> . A ES está associada à utilização substancial de serviços de saúde e a um importante impacto econômico. Os aspectos clínicos que geram maior custo no tratamento são o acometimento gastrointestinal e a hipertensão arterial pulmonar<sup>12</sup> .  
O tratamento de pacientes com ES visa reduzir sintomas, incapacidades e melhorar a qualidade de vida dos pacientes<sup>13</sup> e depende das características do acometimento multissistêmico<sup>14</sup> . Entretanto, a baixa prevalência e o curso clínico variável da ES dificultam a condução de ensaios clínicos, e, consequentemente, o estabelecimento de uma terapêutica padronizada<sup>14</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da Esclerose Sistêmica. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- M34.0 - Esclerose sistêmica progressiva  
- M34.1 - Síndrome CREST  
- M34.8 - Outras formas de esclerose sistêmica

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **3.1. Diagnóstico clínico e laboratorial** -->
Fenômeno de Raynaud, dedos edemaciados e sintomas de refluxo gastroesofágico geralmente estão presentes nas fases iniciais da doença. A presença de anticorpos específicos para ES ( <mark>anticentrômero, anti DNA topoisomerase I - anti-Scl70 -, antiRNA polimerase I ou III</mark> ), a capilaroscopia periungueal (CPU) com padrão SD ( _scleroderma pattern_ ) e presença de alteração arquitetural, capilares dilatados, áreas de desvascularização, micro-hemorragias e neoangiogênese podem ajudar no diagnóstico precoce quando há suspeita clínica<sup>15-17</sup> .  
O diagnóstico da ES segue as orientações dos critérios de classificação publicados em 2013 pelo _American College of Rheumatology_ (ACR) e pela _European League Against Rheumatism_ (EULAR) e que permitem classificar o paciente com ES se ele somar nove ou mais pontos entre os oito itens listados no **Quadro 1**<sup>18</sup> .  
**Quadro 1 -** Critérios de classificação da Esclerose Sistêmica publicados em 2013  
|**Item**|**Subitem**|**Valor**|
|---|---|---|
|Espessamento cutâneo dos dedos das mãos, proximal às articulações||9|
|metacarpofalangeanas.|||
|Espessamento cutâneo dos dedos (considerar apenas a maior pontuação).|Distal às articulações<br>metacarpofalangeanas<br>Edema de mãos|4<br>2|
|Lesões de polpa digital (considerar apenas a maior pontuação)|Úlceras digitais<br>Micro cicatrizes|2<br>3|
|Fenômeno de Raynaud||3|
|Autoanticorpos específicos para ES (anticentrômero, anti- RNA polimerase||3|
|III, anti topoisomerase I - anti Scl70)|||
|Telangiectasias||2|
|Capilaroscopia periungueal alterada||2|
|Hipertensão arterial pulmonar ou doença intersticial pulmonar||2|  
Fonte: Adaptado de ACR/EULAR<sup>18</sup> .  
O reconhecimento do acometimento dos diferentes órgãos é de extrema importância e os achados clínicos associados à investigação a partir de exames laboratoriais e de imagens são fundamentais para estabelecer a extensão e gravidade dos comprometimentos cutâneo e sistêmico. A avaliação do espessamento é feita pela palpação, podendo ser utilizado o escore de Rodnan modificado<sup>19</sup> . A pesquisa do acometimento intersticial pulmonar deve ser realizada precocemente por meio de provas de função pulmonar com difusão de CO2 e, caso o resultado esteja alterado, deve-se realizar tomografia pulmonar de alta resolução.  
Em relação à hipertensão arterial pulmonar (HAP), deve-se seguir as orientações de diagnóstico, tratamento e monitoramento preconizados no respectivo PCDT do Ministério da Saúde.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **3.2. Diagnóstico diferencial** -->
V <mark>árias condições clínicas cursam com espessamento cutâneo e podem mimetizar a ES, sendo importante observar cuidadosamente as características clínicas, achados laboratoriais e fatores desencadeantes que auxiliam no diagnóstico diferencial. Um dos diagnósticos diferenciais mais importantes é a morfeia, principalmente na sua forma panesclerótica, a qual compromete grande parte da superfície corporal, mas que geralmente poupa dedos da mão (quirodáctilos), dedos do pé (pododáctilos)</mark> e mamilos<sup>20</sup> .  
<mark>A fasciíte eosinofílica é outro diagnóstico diferencial importante, geralmente com início agudo e progressão rápida, com edema e esclerose da fáscia e com aspecto cutâneo de casca de laranja. Nesse caso, o padrão-ouro diagnóstico é a biópsia profunda mostrando a presença de músculos e da fáscia</mark><sup>21</sup> <mark>. Outras condições clínicas que se assemelham à ES pelo espessamento cutâneo são: doença enxerto versus hospedeiro e escleromixedema por depósito de mucina</mark><sup>20</sup> <mark>. Condiçõs epidérmicas tóxicas podem apresentar características semelhantes à esclerodermia (</mark> _<mark>scleroderma like</mark>_ <mark>), tais como a síndrome do óleo tóxico, exposição ao triptofano, ao cloreto de vinil e à cocaína, e a fibrose sistêmica nefrogênica. Aspectos clínicos como a presença do</mark> fenômeno de Raynaud <mark>, acometimento das extremidades e de órgãos internos, presença de a</mark> nticorpos específicos para ES e achados com padrão SD na capilaroscopia contribuem para diferenciar o diagnóstico da ES de outras condições clínicas<sup>22</sup> .

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
<mark>Devem ser incluídos neste Protocolo todos os pacientes que preencherem os critérios do A</mark> CR/EULAR de 2013 para <mark>doença inicial</mark><sup>15,18</sup> <mark>, conforme o item diagnóstico. O</mark> tratamento deve ser definido de acordo com o órgão comprometido, considerando as evidências de atividade de doença e seguindo as recomendações deste Protocolo.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **6. TRATAMENTO** -->
Devido ao comprometimento de diferentes sistemas, pacientes com diagnóstico de ES devem ser acompanhados por uma equipe multidisciplinar com a participação do reumatologista.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **6.1. Tratamento não medicamentoso** -->
<mark>Programas de reabilitação</mark><sup>23,24</sup> <mark>, terapia ocupacional, treinamento aeróbico e programas educacionais são capazes de reduzir as limitações físicas e melhorar a força de preensão manual</mark><sup>25</sup> <mark>, sendo uma etapa importante na otimização do cuidado desses pacientes. Fisioterapia, isolada ou em combinação com exercício físico, também pode melhorar o estado funcional e a qualidade de vida dos pacientes</mark><sup>26</sup> <mark>. Outros acometimentos, como o f</mark> enômeno de Raynaud <mark>, também devem ser controlados com medidas não medicamentosas, incluindo medidas gerais para evitar fatores precipitantes, como exposição ao frio, estresse emocion</mark> al, tabagismo e cafeína<sup>27</sup> . Pacientes com refluxo gastroesofágico devem ser orientados a realizar dieta antirrefluxo. Além disso, a ES está associada ao maior risco de desenvolvimento de depressão e desordens psicológicas. Portanto, o acompanhamento psicológico se faz necessário.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **6.2. Tratamento medicamentoso** -->
<mark>O tratamento da ES depende das características do quadro clínico e do acometimento visceral predominante, bem como da presença de doença ativa e reversível (inflamação ou vasoconstrição) ou de dano irreversível (fibrose ou necrose isquêmica)</mark><sup>1</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<mark>6.2.1 Tratamento medicamentoso das manifestações pulmonares</mark>** -->
Neste Protocolo, a ciclofosfamida é considerada a primeira linha terapêutica nas manifestações pulmonares da ES. Dois ensaios clínico randomizados (ECR) avaliaram a eficácia e segurança da ciclofosfamida no tratamento da doença pulmonar intersticial (DPI) concomitante em indivíduos com ES<sup>28,29</sup> . Os estudos demonstraram que houve um efeito benéfico da ciclofosfamida na função pulmonar, avaliada pela capacidade total forçada (CVF) e pela capacidade pulmonar total; na incapacidade funcional, e; na qualidade de vida de pacientes com ES. Quando comparada com placebo, a ciclofosfamida apresentou maior risco de leucopenia. Assim, os benefícios esperados com o uso da ciclofosfamida são a redução do declínio da função pulmonar e melhora da qualidade de vida.  
A azatioprina pode ser uma opção de tratamento para pacientes que apresentam hipersensibilidade à ciclofosfamida. Há evidências provenientes de um ECR que comparou os efeitos da azatioprina à ciclofosfamida para melhora das manifestações pulmonares<sup>28</sup> . Este estudo demonstrou que a azatioprina parece ser inferior à ciclofosfamida para redução do declínio da função pulmonar conforme avaliado pela porcentagem do valor previsto da CVF. No estudo, não houve efeitos adversos graves em ambos os grupos<sup>28</sup> . O benefício esperado com o uso da aztioprina é a possível redução do declínio da função pulmonar.  
Em relação aos derivados do ácido micofenólico, dois estudos avaliaram sua eficácia e segurança no tratamento de manifestações pulmonares em indivíduos com ES<sup>30,31</sup> . Os resultados destes estudos indicam que não há diferença significativa entre micofenolato e placebo na mudança da função pulmonar avaliada pela porcentagem do valor previsto da CVF. Para este  
mesmo desfecho, o micofenolato apresentou resultado semelhante à ciclofosfamida. Nestes estudos, não houve diferença entre os grupos com relação aos eventos adversos. O uso de micofenolato (de sódio ou mofetila) no tratamento das manifestações pulmonares da ES não consta nas indicações aprovadas em bula pela Agência Nacional de Vigilância Sanitária (Anvisa) no Brasil e, assim, estes medicamentos não são preconizados neste PCDT.  
Quatro estudos de tamanho amostral pequeno avaliaram a efetividade e segurança do rituximabe no tratamento de indivíduos com ES<sup>32–35</sup> . Dois estudos não mostraram diferença na porcentagem do valor previsto da CVF quando comparado com placebo ou outras intervenções (prednisona, micofenolato, ciclofosfamida e bosentana). Apenas um estudo demonstrou que o rituximabe foi superior à ciclofosfamida para redução do declínio da função pulmonar conforme avaliado pela porcentagem do valor previsto da CVF. Com relação aos eventos adversos, não foram observadas diferenças entre rituximabe e ciclofosfamida. O uso de rituximabe no tratamento das manifestações pulmonares da ES não consta nas indicações aprovadas em bula pela Anvisa no Brasil e, assim, este medicamento não é preconizado neste PCDT.  
Já a eficácia do nintedanibe foi avaliada em um único ECR que incluiu pacientes com DPI associada à ES<sup>36</sup> . O grupo que recebeu nintedanibe apresentou maior redução do declínio anual da CVF medida em mililitros e avaliada como porcentagem do valor previsto. Com relação à segurança do medicamento, os eventos adversos foram mais frequentes no grupo de pacientes que recebeu o nintenanibe. A diarreia foi o principal evento adverso observado. O risco de viés geral do estudo foi julgado como alto para todos os desfechos avaliados. Diante de todas essas observações, o uso do nintedanibe não é preconizado neste PCDT.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<mark>6.2.2 Tratamento medicamentoso das manifestações cutâneas</mark>** -->
O impacto do tratamento com metotrexato na progressão da fibrose cutânea foi avaliado em dois ECR em pacientes com ES inicial com resultados favoráveis ao metotrexato com relação ao espessamento cutâneo<sup>37,38</sup> . Assim, este medicamento deve ser utilizado como primeira opção de tratamento das manifestações cutâneas em pacientes com ES, esperando-se a melhora do espessamento subcutâneo.  
Outro medicamento cuja eficácia e segurança no tratamento de manifestações cutâneas em indivíduos com ES foi avaliada foi a ciclofosfamida. Dois ECR<sup>28,29</sup> demonstraram que a ciclofosfamida pode melhorar o espessamento cutâneo de pacientes com ES. Assim, de modo a melhorar o espessamento subcutâneo, recomenda-se o uso da ciclofosfamida para o tratamento de manifestações cutâneas graves em pacientes com ES.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<mark>6.2.3 Tratamento medicamentoso das manifestações vasculares</mark>** -->
O acometimento vascular, caracterizado por vasoconstrição e vasculopatia obliterativa, pode contribuir para o desenvolvimento de fenômeno de Raynaud, úlceras digitais (UD) isquêmicas, crise renal esclerodérmica (CRE) e HAP<sup>2</sup> . Bloqueadores de canais de cálcio (nifedipino e anlodipino) são a primeira linha de tratamento do fenômeno de Raynaud. Uma revisão sistemática com metanálise que incluiu oito ensaios clínicos<sup>39</sup> demonstrou que os bloqueadores de canais de cálcio podem reduzir a frequência e gravidade de ataques isquêmicos. Assim, estes medicamentos devem ser utilizados no tratamento das manifestações vasculares em pacientes com ES, de modo a reduzir a frequência e gravidade de ataques isquêmicos. Já o uso de sildenafila é preconizado para o tratamento de úlceras digitais refratárias aos bloqueadores dos canais de cálcio em indivíduos com ES, considerando os resultados de um ECR<sup>40</sup> que demonstrou que o medicamento pode diminuir a frequência média de ataques de Raynaud.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<mark>6.2.4 Tratamento medicamentoso das manifestações renais</mark>** -->
Para o tratamento da CRE, inibidores da enzima conversora da angiotensina (IECA) são os medicamentos com melhores resultados em estudos observacionais e com grande impacto na sobrevida desses pacientes, sendo captopril o agente mais  
frequentemente utilizado<sup>41-43</sup> . Há evidências provenientes de um estudo observacional que indicam que a terapia com IECA melhorou a sobrevida de pacientes com CRE<sup>41</sup> .  
Os pacientes devem ter seus níveis de pressão arterial prévios recuperados dentro de 72 horas do início do tratamento. Quando o uso de IECA em dose máxima não é capaz de otimizar o controle pressórico, terapia anti-hipertensiva adicional é necessária, utilizando vasodilatadores ou bloqueadores dos canais de cálcio<sup>44,45</sup> . A Terapia de substituição renal é necessária em cerca de 50% dos casos e uma parte significativa desses pacientes recuperará sua função renal em 12 a 18 meses<sup>42,45</sup> .  
O uso de IECA deve ser mantido indefinidamente nos pacientes que apresentaram CRE<sup>46</sup> . Não há indicação de uso de IECA na prevenção da CRE, pois tem sido associado a piores desfechos em alguns estudos observacionais<sup>43,47</sup> . Pacientes em uso de corticoide devem ser cuidadosamente monitorados com relação à função renal e pressão arterial<sup>14</sup> , com sua dose e tempo de utilização minimizados em pacientes com ES<sup>48</sup> .

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<mark>6.2.5 Tratamento medicamentoso das manifestações gastrointestinais</mark>** -->
Medicamentos pró-cinéticos, como a metoclopramida, podem melhorar sintomas relacionados aos distúrbios de motilidade gastrointestinal<sup>49</sup> . Evidências provenientes de um ECR que comparou metoclopramida versus eritromicina apontam que a metoclopramida pode reduzir o tempo médio de esvaziamento gástrico medido por cintilografia gástrica em pacientes com ES e atraso no tempo de esvaziamento gástrico<sup>50</sup> . Assim, preconiza-se o uso de metoclopramida no tratamento de sintomas relacionados aos distúrbios de motilidade gastrointestinal em pacientes com ES. Síndromes de má absorção, determinadas pelo supercrescimento bacteriano, podem ser tratadas com cursos de antibioticoterapia em rodízio<sup>1,51</sup> .  
Os bloqueadores da bomba de prótons, como o omeprazol, também são empregados na prevenção de complicações do refluxo gastroesofágico. <mark>Um estudo não controlado</mark><sup>52</sup> avaliou se o tratamento com 20 a 80 mg de omeprazol melhorou a pHmetria em pacientes com ES e doença do refluxo gastroesofágico grave. O tempo com pH menor que 4 durante a pHmetria ambulatorial de 24 horas foi de 36% no início do estudo e 13% (intervalo de confiança de 95%, de 6% a 41%) após, pelo menos, 6 meses de tratamento com omeprazol. Assim, preconiza-se o uso de omeprazol na prevenção de complicações do refluxo gastroesofágico em pacientes com ES.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **6.3. Medicamentos** -->
- Azatioprina: comprimidos de 50 mg;  
- besilato de anlodipino: comprimidos de 5 e 10 mg;  
- captopril: comprimidos de 25 mg;  
- ciclofosfamida: comprimidos de 50 mg; frasco-ampola de 1.000 mg e 200 mg;  
- metotrexato: comprimidos de 2,5 mg; solução injetável de 50 mg/2 mL;  
- metoclopramida: comprimidos de 10 mg;  
- nifedipino: comprimidos de 10 mg;  
- omeprazol: cápsulas de 10 e 20 mg;  
- prednisona: comprimidos de 5 e 20 mg;  
- sildenafila: comprimidos de 25 e 50 mg.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **6.4. Esquemas de administração** -->
- Azatioprina: dose inicial de 1 mg/kg/dia, por via oral, aumentando 0,5 mg/kg a cada 4 semanas até atingir o controle da atividade da doença. A dose máxima não deve ultrapassar 3 mg/kg/dia. As contraindicações são imunossupressão (AIDS, linfoma e outros), infecção ativa, tuberculose, neoplasia maligna em atividade.  
- Besilato de anlodipino: dose de 5 a 10 mg, 1 vez ao dia. As contraindicações <mark>infarto agudo do miocárdio, insuficiência cardíaca congestiva, angina instável ou pós-infarto, estenose da válvula aórtica grave, hipotensos, gestantes (antes da 20ª semana) ou mulheres que estejam amamentando.</mark>  
- Captopril: para pacientes hipertensos com CRE, sem evidência de envolvimento do sistema nervoso central, dose de 6,25 a 12,5 mg por via oral, com aumento de 12,5 a 25 mg em intervalos de 4 a 8 horas até que a pressão arterial esteja normalizada. A dose máxima é de 300 a 450 mg/dia. Nos pacientes em CRE normotensos, a dose inicial é de 6,25 mg e, conforme a tolerância, deve-se aumentar para 12,5 mg na segunda dose (aumentos adicionais devem ser feitos com cautela para evitar a indução de hipotensão).  
- <u>Ciclofosfamida:</u> 1 a 2 mg/kg/dia, por via oral, ou 300 a 800 mg/m<sup>2</sup> por via intravenosa a cada 4 semanas. As contraindicações ao uso são pacientes com tuberculose sem tratamento, infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zoster ativa; hepatites B ou C agudas; insuficiência cardíaca grave não controlada, concepção, gestação ou lactação, cistite hemorrágica, imunossupressão, neoplasia maligna em atividade. Em caso de pacientes com creatinina sérica acima de 2 mg/dL ou clearance de creatinina menor que 30, deve-se considerar o ajuste de dose de ciclofosfamida. Neste caso e em pacientes com leucopenia (igual ou menor a 3.000 células/mm<sup>3</sup> ), deve-se considerar a não utilização do medicamento.  
- Metoclopramida: 10 mg, 3 vezes ao dia, 10 minutos antes das refeições. As contraindicações são situações em que a estimulação da motilidade gastrintestinal seja perigosa, como por exemplo, na presença de hemorragia gastrintestinal, obstrução mecânica ou perfuração gastrintestinal; em pacientes com epilepsia ou que estejam recebendo outros medicamentos que possam causar reações extrapiramidais, uma vez que a frequência e intensidade destas reações podem ser aumentadas; em pacientes com feocromocitoma, pois pode desencadear crise hipertensiva, devido à provável liberação de catecolaminas do tumor.  
- <u>Metotrexato: dose inicial de 15 mg/semana, por via oral, intramuscular, subcutânea ou intravenosa, podendo ser</u> aumentada gradualmente até 25 mg/semana. As contraindicações são aumento das enzimas hepáticas (AST/TGO e ALT/TGP) ou nível de bilirrubinas 2 vezes acima do limite superior da normalidade; infecção ativa moderada a grave, tais como herpes zoster ativa, infecção fúngica sistêmica ou ameaçadora à vida, tuberculose sem tratamento, hepatites B ou C agudas; concepção (homens e mulheres), gestação ou lactação; hepatopatia crônica; câncer; taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica.  
- Nifedipino: dose de 10 a 20 mg, 3 vezes ao dia, por via oral, conforme a resposta terapêutica. As contraindicações são <mark>infarto agudo do miocárdio, insuficiência cardíaca congestiva, angina instável ou pós-infarto, estenose da válvula aórtica grave, hipotensos, gestantes (antes da 20ª semana) ou mulheres que estejam amamentando</mark> .  
- <u>Omeprazol: 20 mg, 1 vez ao dia, 30 minutos antes do café da manhã, podendo ser aumentado para 2 vezes ao dia</u> conforme a necessidade.  
- <u>Prednisona: dose inicial 0,125 mg/kg/dia, podendo chegar a 1 mg/kg/dia, conforme a manifestação da doença. As</u> contraindicações são diabete melito descompensado; infecção sistêmica; úlcera péptica ativa ou hipertensão arterial sistêmica (HAS) descompensada.  
- Sildenafila: 50 mg, 2 a 3 vezes ao dia, por via oral. As contraindicações são uso concomitante de nitratos (risco de hipotensão refratária); falência cardíaca grave (grau IV) ou angina instável; presença de doença degenerativa da retina, isquemia óptica ou retinopatia proliferativa diabética; alteração hepática grave; função renal alterada com creatinina maior ou igual a 2,5 mg/dL; gestação ou lactação; pacientes com alterações hemodinâmicas ou hipotensão ortostática; pacientes com doenças que predispõem ao priapismo como anemia falciforme, mieloma ou leucemia.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **6.5. Tempo de tratamento e critérios de interrupção** -->
- Ciclofosfamida: deve ser administrada por 6 meses, seguida de medicamento de manutenção. O tratamento pode ser  
- repetido conforme a evolução clínica (evidência nova de atividade de doença que justifique os riscos inerentes ao retratamento).  
- Sildenafila: o tratamento deve ser mantido até a cicatrização de úlceras digitais.  
- Captopril: o tratamento deve ser mantido até resolução da CRE.  
- Nifedipino e besilato de anlodipino: o tratamento deve ser mantido até melhora do fenômeno de Raynaud e conforme a  
gravidade da isquemia de extremidades.  
- Azatioprina: inexiste um período estabelecido para a duração do tratamento. Após atingir a remissão clínica, as doses  
dos medicamentos podem ser reduzidas gradualmente, sob monitorização sistemática da atividade de doença.  
- Metoclopramida, metotrexato e omeprazol: não existe um período estabelecido para a duração do tratamento com estes  
- medicamentos.  
- Prednisona: não existe um período estabelecido para a duração do tratamento com este medicamento, após a remissão  
- clínica a dose’ deve ser reduzida gradualmente, até a retirada total.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **6.6. Benefícios esperados** -->
- Ciclofosfamida: redução da progressão da fibrose pulmonar e cutânea.  
- Metotrexato: melhora clínica do espessamento cutâneo e dos sintomas articulares.  
- Sildenafila: melhora do fenômeno de Raynaud, cicatrização e diminuição do número de úlceras digitais isquêmicas.  
- Captopril: normalização da pressão arterial e da função renal.  
- Nifedipino: diminuição da frequência e da gravidade de ataques isquêmicos relacionados ao fenômeno de Raynaud.  
- Azatioprina: redução da progressão da fibrose pulmonar.  
- Metoclopramida: melhora da motilidade esofágica e da plenitude gástrica.  
- Omeprazol: melhora do refluxo gastroesofágico.  
- Besilato de anlodipino: diminuição da frequência e da gravidade de ataques isquêmicos relacionados ao fenômeno de Raynaud.  
- Prednisona: melhora da pneumopatia intertisticial na fase inflamatória.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **7. MONITORIZAÇÃO** -->
O seguimento dos pacientes, incluindo consultas médicas e exames complementares, deverá ser programado conforme a evolução clínica e a monitorização da toxicidade dos medicamentos. Como não existe uma duração de tratamento prédeterminada, os pacientes devem ser acompanhados periodicamente a cada 3 a 6 meses em serviço especializado em reumatologia, com o objetivo de detectar precocemente manifestações em órgãos-alvo pela doença. De acordo com o tratamento realizado pelo paciente há necessidade de seguimento específico para cada medicamento, detalhado a seguir.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Ciclofosfamida** -->
Devem ser solicitados hemograma com contagem de plaquetas e exame comum de urina com microscopia 14 dias após cada infusão e, após, conforme a necessidade. Além da imunossupressão, com consequente aumento dos riscos de infecções e de neoplasias, infertilidade, toxicidade hematológica e cistite hemorrágica são outros eventos adversos potenciais. Para prevenir esta última, recomenda-se a administração de mesna por via intravenosa ou oral (1 mg para cada 1 mg de ciclofosfamida) dividida em três vezes: 30 minutos antes da infusão, 30 minutos após a infusão e 4 horas após o término da infusão. O aparecimento de hematúria persistente e inexplicada deve ser monitorado.  
Sugere-se administração de soro fisiológico a 0,9% na dose de 1.000 mL, por via intravenosa, 1 hora antes da infusão, bem como uso de diuréticos, para estimular diurese. Hidratação oral vigorosa deve ser estimulada ao longo do tratamento com ciclofosfamida. Podem-se utilizar antieméticos antes das infusões em caso de náusea ou vômitos.  
Além disso, o uso de sulfametoxazol + trimetoprima deve ser considerado, especialmente em pacientes que estiverem utilizando ciclofosfamida e prednisona com dose acima de 20 mg e em pacientes maiores de 60 anos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Metotrexato** -->
Devem ser solicitadas enzimas hepáticas (AST/TGO e ALT/TGP), hemograma com contagem de plaquetas, ureia e creatinina antes do início do tratamento, com repetição mensal nos primeiros 3 meses e, após, a cada 3 meses durante seu uso ou conforme necessidade clínica. Sorologia para HIV e hepatites B e C também deve ser realizada antes do início do tratamento. Em caso de elevação de transaminases acima de 2 vezes do limite superior de referência, o medicamento deve ser suspenso por 2 semanas com posterior reavaliação laboratorial. Metotrexato pode ser reiniciado após a normalização das transaminases. O consumo de bebidas alcoólicas é desaconselhado ao longo do tratamento. Em caso de diminuição na contagem de leucócitos (menos de 1.500/mm<sup>3</sup> ) ou plaquetas (menos de 50.000/mm<sup>3</sup> ), há necessidade de redução na dose do medicamento. Diminuição de dose também deve ser considerada em caso de úlceras orais ou estomatite. Tosse e dispneia devem ser avaliadas com radiografia de tórax e testes de função pulmonar devido ao potencial risco de pneumonite, devendo assim ser usado com cautela em pacientes pneumopatas. Sintomas como náusea e vômitos respondem à redução da dose de metotrexato ou incremento da dose semanal de ácido fólico. A administração de antiemético ou o uso do medicamento junto às refeições pode diminuir tais sintomas. As causas mais comuns de toxicidade aguda com o medicamento são insuficiência renal aguda e administração concomitante de sulfametoxazol + trimetoprima. A associação de ácido fólico (5 a 10 mg/semana) auxilia a minimizar os eventos adversos. Pacientes em idade fértil devem realizar anticoncepção durante o uso do medicamento.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Nifedipino e anlodipino** -->
Devem ser monitorizados os eventos adversos. Os mais comuns são rubor facial, cefaleia, edema de membros inferiores, constipação, tontura, vertigem, tremores, taquicardia, hipotensão e sensação de mal-estar.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Sildenafila** -->
Devem ser monitorizados os eventos adversos, sendo os mais frequentes (acima de 10%), cefaleia, vasodilatação com rubor facial e dispepsia; e menos frequentes (até 10%), epistaxe, tonturas, congestão nasal e, raramente, distúrbios visuais<sup>53</sup> . Além disso, deve-se atentar para o histórico de acidente vascular encefálico prévio, infarto agudo do miocárdio ou arritmia grave nos seis meses anteriores ao início do tratamento.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Azatioprina** -->
Devem ser solicitados hemograma, contagem de plaquetas e dosagem de enzimas hepáticas (ALT/TGP e AST/TGO) e fosfatase alcalina quinzenalmente nos primeiros 3 meses e, após, mensalmente ou se houver mudança nas doses. O medicamento deve ser suspenso ou ter a dose reduzida em pacientes que desenvolverem leucopenia (menos de 4.000/mm<sup>3</sup> ) ou plaquetopenia (menos de 100.000/mm<sup>3</sup> ). O aumento dos níveis de enzimas hepáticas e fosfatase alcalina pode ocorrer em alguns casos e, quando acima de 2 vezes do limite superior do valor de referência, o medicamento deve ser suspenso até normalização de seus níveis.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Metoclopramida** -->
Devem ser monitorizados os eventos adversos. Os mais frequentes são inquietação, sonolência, fadiga e lassidão, que ocorrem em aproximadamente 10% dos pacientes.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Omeprazol** -->
Devem ser monitorizados os eventos adversos, embora não sejam frequentes. Quando presentes, geralmente têm intensidade leve, desaparecendo com a continuidade do tratamento ou após a suspensão do mesmo. Os mais comuns são cefaleia, astenia, diarreia, gastroenterite, dor muscular, reações alérgicas (incluindo, raramente, anafilaxia) e púrpura.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Prednisona** -->
Devem ser monitorizados os eventos adversos, sendo os mais frequentes: hipertensão arterial, hiperglicemia, hipocalemia e dislipidemia.  Devem ser realizadas dosagens de glicemia de jejum, potássio, perfil lipídico e aferição da pressão arterial no início do tratamento.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **8. REGULAÇÃO, CONTROLE, E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento (s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Doentes de esclerose sistêmica devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **10. REFERÊNCIAS BIBLIOGRÁFICAS** -->
1. Kowal-Bielecka O, Landewé R, Avouac J, Chwiesko S, Miniati I, Czirjak L, et al. EULAR recommendations for the treatment of systemic sclerosis: a report from the  EULAR Scleroderma Trials and Research group (EUSTAR). Ann Rheum Dis. 2009 May;68(5):620–8.  
2. Denton CP, Hughes M, Gak N, Vila J, Buch MH, Chakravarty K, et al. BSR and BHPR guideline for the treatment of systemic sclerosis. Rheumatology (Oxford). 2016 Oct;55(10):1906–10.  
3. Valentini G, Black C. Systemic sclerosis. Best Pract Res Clin Rheumatol. 2002 Dec;16(5):807–16.  
4. Allanore Y, Simms R, Distler O, Trojanowska M, Pope J, Denton CP, et al. Systemic sclerosis. Nat Rev Dis Prim [Internet]. 2015;1(1):15002. Available from: https://doi.org/10.1038/nrdp.2015.2  
5. Bairkdar M, Rossides M, Westerlind H, Hesselstrand R, Arkema E V, Holmqvist M. Incidence and prevalence of systemic sclerosis globally: a comprehensive systematic  review and meta-analysis. Rheumatology (Oxford). 2021 Jul;60(7):3121–33.  
6. Horimoto AMC, Matos ENN, da Costa MR, Takahashi F, Rezende MC, Kanomata LB, et al. Incidência e prevalência de esclerose sistêmica em Campo Grande, Estado de Mato Grosso do Sul, Brasil. Rev Bras Reum [Internet]. 2017;57(2). Available from: https://doi.org/10.1016/j.rbre.2016.09.005  
7. Orlandi M, Lepri G, Damiani A, Barsotti S, Di Battista M, Codullo V, et al. One year in review 2020: systemic sclerosis. Clin Exp Rheumatol. 2020;38 Suppl 1(3):3–17.  
8. Jordan S, Distler JHW, Maurer B, Huscher D, van Laar JM, Allanore Y, et al. Effects and safety of rituximab in systemic sclerosis: an analysis from the European  Scleroderma Trial and Research (EUSTAR) group. Ann Rheum Dis. 2015 Jun;74(6):1188–94.  
9. Sierakowska M, Doroszkiewicz H, Sierakowska J, Olesińska M, Grabowska-Jodkowska A, Brzosko M, et al. Factors associated with quality of life in systemic sclerosis: a cross-sectional study. Qual life Res  an Int J Qual life Asp  Treat care Rehabil. 2019 Dec;28(12):3347–54.  
10. Mok CC, Kwok CL, Ho LY, Chan PT, Yip SF. Life expectancy, standardized mortality ratios, and causes of death in six rheumatic  diseases in Hong Kong, China. Arthritis Rheum. 2011 May;63(5):1182–9.  
11. Rubio-Rivas M, Royo C, Simeón CP, Corbella X, Fonollosa V. Mortality and survival in systemic sclerosis: systematic review and meta-analysis. Semin Arthritis Rheum. 2014 Oct;44(2):208–19.  
12. Morrisroe K, Stevens W, Sahhar J, Ngian G-S, Rabusa C, Ferdowsi N, et al. Quantifying the direct public health care cost of systemic sclerosis: A  comprehensive data linkage study. Medicine (Baltimore). 2017 Dec;96(48):e8503.  
13. Zhu JL, Black SM, Chen HW, Jacobe HT. Emerging treatments for scleroderma/systemic sclerosis. Fac Rev. 2021;10:43. 14. Matucci-Cerinic M, Allanore Y, Czirják L, Tyndall A, Müller-Ladner U, Denton C, et al. The challenge of early systemic sclerosis for the EULAR Scleroderma Trial and  Research group (EUSTAR) community. It is time to cut the Gordian knot and develop a prevention or rescue strategy. Ann Rheum Dis. 2009 Sep;68(9):1377–80.  
15. LeRoy EC, Medsger TAJ. Criteria for the classification of early systemic sclerosis. J Rheumatol. 2001 Jul;28(7):1573– 6.  
16. Minier T, Guiducci S, Bellando-Randone S, Bruni C, Lepri G, Czirják L, et al. Preliminary analysis of the very early diagnosis of systemic sclerosis (VEDOSS)  EUSTAR multicentre study: evidence for puffy fingers as a pivotal sign for suspicion of systemic sclerosis. Ann Rheum Dis. 2014 Dec;73(12):2087–93.  
17. Koenig M, Joyal F, Fritzler MJ, Roussin A, Abrahamowicz M, Boire G, et al. Autoantibodies and microvascular damage are independent predictive factors for the  progression of Raynaud’s phenomenon to systemic sclerosis: a twenty-year prospective study of 586 patients, with validation of proposed criteria for early systemic scleros. Arthritis Rheum. 2008 Dec;58(12):3902–12.  
18. van den Hoogen F, Khanna D, Fransen J, Johnson SR, Baron M, Tyndall A, et al. 2013 classification criteria for systemic sclerosis: an American college of  rheumatology/European league against rheumatism collaborative initiative. Ann Rheum Dis. 2013 Nov;72(11):1747–55.  
19. Khanna D, Furst DE, Clements PJ, Allanore Y, Baron M, Czirjak L, et al. Standardization of the modified Rodnan skin score for use in clinical trials of  systemic sclerosis. J scleroderma Relat Disord. 2017;2(1):11–8.  
20. Orteu, CH; Ong, VH; Denton C. Scleroderma mimics – Clinical features and management. Best Pract Res Clin Rheumatol. 2020;34(1).  
21. Fett N. Scleroderma: nomenclature, etiology, pathogenesis, prognosis, and treatments: facts  and controversies. Clin Dermatol. 2013;31(4):432–7.  
22. Smith V, Herrick AL, Ingegnoli F, Damjanov N, De Angelis R, Denton CP, et al. Standardisation of nailfold capillaroscopy for the assessment of patients with Raynaud’s phenomenon and systemic sclerosis. Autoimmun Rev. 2020 Mar;19(3):102458.  
23. Rannou F. Effect of rehabilitation in systemic sclerosis. Ann Phys Rehabil Med. 2015;58:e128.  
24. Liem S, Vlieland T, Schoones JW, Vries-Bouwstra J. The effect and safety of exercise therapy in patients with systemic sclerosis: a systematic review. Rheumatol Adv Pract. 2019 Dec 9;3.  
25. Willems LM, Vriezekolk JE, Schouffoer AA, Poole JL, Stamm TA, Boström C, et al. Effectiveness of Nonpharmacologic Interventions in Systemic Sclerosis: A Systematic  Review. Arthritis Care Res (Hoboken). 2015 Oct;67(10):1426–39.  
26. Peddi M, Lopez-Olivo MA, Peddi P, Cuervo GE S-AM. Physical Therapy for Systemic Rheumatol, Sclerosis: Systematic Review and Meta-Analysis. Arthritis Rheumatol. 2014;  
27. Sinnathurai P, Schrieber L. Treatment of Raynaud phenomenon in systemic sclerosis. Intern Med J. 2013 May;43(5):476–83.  
28. Nadashkevich O, Davis P, Fritzler M, Kovalenko W. A randomized unblinded trial of cyclophosphamide versus azathioprine in the  treatment of systemic sclerosis. Clin Rheumatol. 2006 Mar;25(2):205–12.  
29. Tashkin DP, Elashoff R, Clements PJ, Goldin J, Roth MD, Furst DE, et al. Cyclophosphamide versus placebo in scleroderma lung disease. N Engl J Med. 2006 Jun;354(25):2655–66.  
30. Naidu GSRSNK, Sharma SK, Adarsh MB, Dhir V, Sinha A, Dhooria S, et al. Effect of mycophenolate mofetil (MMF) on systemic sclerosis-related interstitial  lung disease with mildly impaired lung function: a double-blind, placebocontrolled, randomized trial. Rheumatol Int. 2020 Feb;40(2):207–16.  
31. Tashkin DP, Roth MD, Clements PJ, Furst DE, Khanna D, Kleerup EC, et al. Mycophenolate mofetil versus oral cyclophosphamide in scleroderma-related  interstitial lung disease (SLS II): a randomised controlled, double-blind, parallel group trial. Lancet Respir Med. 2016 Sep;4(9):708–19.  
32. Daoussis D, Liossis S-NC, Tsamandas AC, Kalogeropoulou C, Kazantzi A, Sirinian C, et al. Experience with rituximab in scleroderma: results from a 1-year, proof-of-principle  study. Rheumatology (Oxford). 2010 Feb;49(2):271–80.  
33. Boonstra M, Meijs J, Dorjée AL, Marsan NA, Schouffoer A, Ninaber MK, et al. Rituximab in early systemic sclerosis. RMD open [Internet]. 2017 Jul 28;3(2):e000384–e000384. Available from: https://pubmed.ncbi.nlm.nih.gov/28879049  
34. Sircar G, Goswami RP, Sircar D, Ghosh A, Ghosh P. Intravenous cyclophosphamide vs rituximab for the treatment of early diffuse  scleroderma lung disease: open label, randomized, controlled trial. Rheumatology (Oxford). 2018 Dec;57(12):2106–13.  
35. Ebata S, Yoshizaki A, Oba K, Kashiwabara K, Ueda K, Umemura Y, Watadani T, Fukasawa T, Miura S, YoshizakiOgawa A, Asano Y, Okiyama N, Kodera M, Hasegawa M SS. Safety and Efficacy of Rituximab for Systemic Sclerosis: A Double-Blind, Parallel-Group Comparison, Investigators Initiated Confirmatory Randomized Clinical Trial  
(DESIRES Study) [abstract]. Arthritis Rheumatol. 2021;73(suppl 10).  
36. Distler O, Highland KB, Gahlemann M, Azuma A, Fischer A, Mayes MD, et al. Nintedanib for Systemic SclerosisAssociated Interstitial Lung Disease. N Engl J Med. 2019 Jun;380(26):2518–28.  
37. Van den Hoogen FHJ, Boerbooms AMT, Swaak AJG, Rasker JJ, Van Lier HJJ, Van De Putte LBA. Comparison of methotrexate with placebo in the treatment of systemic sclerosis: a 24 week randomized double-blind trial, followed by a 24 week observational trial. Rheumatology. 1996;35(4):364–72.  
38. Pope JE, Bellamy N, Seibold JR, Baron M, Ellman M, Carette S, et al. A randomized, controlled trial of methotrexate versus placebo in early diffuse  scleroderma. Arthritis Rheum. 2001 Jun;44(6):1351–8.  
39. Thompson AE, Shea B, Welch V, Fenlon D, Pope JE. Calcium-channel blockers for Raynaud’s phenomenon in systemic sclerosis. Arthritis Rheum. 2001 Aug;44(8):1841–7.  
40. Fries R, Shariat K, von Wilmowsky H, Böhm M. Sildenafil in the treatment of Raynaud’s phenomenon resistant to vasodilatory  therapy. Circulation. 2005 Nov;112(19):2980–5.  
41. Steen VD, Costantino JP, Shapiro AP, Medsger TAJ. Outcome of renal crisis in systemic sclerosis: relation to availability of  angiotensin converting enzyme (ACE) inhibitors. Ann Intern Med. 1990 Sep;113(5):352–7.  
42. Steen VD, Medsger TAJ. Long-term outcomes of scleroderma renal crisis. Ann Intern Med. 2000 Oct;133(8):600–3.  
43. Penn H, Howie AJ, Kingdon EJ, Bunn CC, Stratton RJ, Black CM, et al. Scleroderma renal crisis: patient characteristics and long-term outcomes. QJM. 2007 Aug;100(8):485–94.  
44. Ghossein C, Varga J, Fenves AZ. Recent Developments in the Classification, Evaluation, Pathophysiology, and Management of Scleroderma Renal Crisis. Curr Rheumatol Rep. 2016 Jan;18(1):5.  
45. Mouthon L, Bussone G, Berezné A, Noël L-H, Guillevin L. Scleroderma renal crisis. J Rheumatol. 2014 Jun;41(6):1040– 8.  
46. Lynch BM, Stern EP, Ong V, Harber M, Burns A, Denton CP. UK Scleroderma Study Group (UKSSG) guidelines on the diagnosis and management of  scleroderma renal crisis. Clin Exp Rheumatol. 2016;34 Suppl 1(5):106–9.  
47. Hudson M, Baron M, Tatibouet S, Furst DE, Khanna D. Exposure to ACE inhibitors prior to the onset of scleroderma renal crisis-results  from the International Scleroderma Renal Crisis Survey. Semin Arthritis Rheum. 2014 Apr;43(5):666–72.  
48. Trang G, Steele R, Baron M, Hudson M. Corticosteroids and the risk of scleroderma renal crisis: a systematic review. Rheumatol Int. 2012 Mar;32(3):645–53.  
49. Tisseverasinghe A, Kadhim A, Parmar A, Liu L JS. Impact of Prokinetic Agents on Systemic [Internet]., SclerosisAssociated Gastrointestinal Disease: A Systematic Review. Arthritis Rheumatol. 2015;67.  
50. Vera Lastra O, Rodríguez Molinar LE, Normandia Almeida A, Rodríguez Alejandre A, Lira Carreón CE, Jara LJ, et al. Utilidad de la eritromicina en la gastroparesia por esclerodermia. Estudio comparativo con metoclopramida. Rev mex Reum. 2001;361–6.  
51. Shreiner A, Limsrivilai J HP. A Systematic Review of Antibiotic Treatment of Small Intestinal Sclerosis, Bacterial Overgrowth in Patients with Systemic. Gastroenterology. 2016;  
52. Hendel L, Hage E, Hendel J, Stentoft P. Omeprazole in the long‐term treatment of severe gastro‐oesophageal reflux disease in patients with systemic sclerosis. Aliment Pharmacol Ther. 1992;6(5):565–77.  
53. Bertero EB, Montorsi F. Safety of sildenafil citrate: review of 67 double-blind placebo-controlled trials and the postmarketing safety database: F. Giuliano, G. Jackson, F. Montorsi, A. Martin-morales, and P. Raillard. J Sex Med. 2014;11 4:885–7.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
CICLOFOSFAMIDA, METOTREXATO, AZATIOPRINA, SILDENAFILA, CAPTOPRIL, NIFEDIPINO,  
METOCLOPRAMIDA, OMEPRAZOL, BESILATO DE ANLODIPINO E PREDNISONA.  
Eu,____________________________________________________________________________________________  
(nome do [a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de ciclofosfamida, metotrexato, azatioprina, sildenafila, captopril, nifedipino, metoclopramida, omeprazol, besilato de anlodipino e prednisona indicados para o tratamento de Esclerose Sistêmica.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo (a) médico (a) _________________________________________________________________________________ (nome do(a) médico(a)  
que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Diminuir a progressão do espessamento cutâneo;  
- Reduzir a frequência e gravidade de ataques isquêmicos digitais;  
- Cicatrização das úlceras digitais;  
- Controlar a pressão arterial;  
- Melhorar náusea e acelerar o esvaziamento gástrico;  
- Melhorar a capacidade pulmonar;  
- Melhorar a qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
● medicamentos classificados na gestação como categoria B (estudos em animais não mostraram anormalidades nos descendentes, porém não há estudos em humanos; risco para o bebê muito improvável): omeprazol e metoclopramida;  
● medicamentos classificados na gestação como categoria C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior que os riscos): prednisona, sildenafila, ninfedipino, besilato de anlodipino;  
- medicamento classificado na gestação como categoria D (há evidências de riscos ao feto, mas um benefício potencial  
- pode ser maior que os riscos): azatioprina;  
● medicamentos classificados na gestação como categoria X (estudos em animais ou em humanos claramente demonstram risco para o bebê que suplantam quaisquer potenciais benefícios, sendo o medicamento contraindicado na gestação): ciclofosfamida, metotrexato e captopril.  
Os eventos adversos mais comuns dos medicamentos são:  
● ciclofosfamida: diminuição do número de células brancas no sangue, fraqueza, náusea, vômitos, infecções da bexiga acompanhada ou não de sangramento, problemas nos rins, no coração, pulmão, queda de cabelos, aumento do risco de desenvolver cânceres;  
● metotrexato: convulsões, encefalopatia, febre, calafrios, sonolência, queda de cabelo, espinhas, furúnculos, alergias de pele leves a graves, sensibilidade à luz, alterações da pigmentação da pele e de mucosas, náusea, vômitos, perda de apetite, inflamação da boca, úlceras de trato gastrointestinal, hepatite, cirrose e necrose hepática, diminuição das células brancas do sangue e das plaquetas, insuficiência renal, fibrose pulmonar, diminuição das defesas imunológicas do organismo com ocorrência de infecções;  
- azatioprina: diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar, pressão baixa;  
- sildenafila: vermelhidão, dores de cabeça, dificuldade de digestão, diarreia e dor em braços e pernas, gripe, febre,  
- tosse, visão turva e dificuldade para dormir;  
- captopril: erupções cutâneas, frequentemente com coceira e febre, dores articulares, aumento dos eosinófilos,  
- diminuição da pressão arterial, dores no peito, palpitações, alteração do paladar e tosse;  
- nifedipino: alergia, vermelhidão, dores de cabeça, inchaços, constipação, ansiedade, tontura, vertigem, tremores,  
- palpitação, diminuição <mark>da pressão arterial</mark> e sensação de mal-estar;  
● metoclopramida: <mark>inquietude; ocasionalmente podem ocorrer movimentos involuntários dos membros e da face; torcicolo, protrusão rítmica da língua, perda da capacidade de articular as palavras ou contratura involuntária dos músculos mastigatórios;</mark>  
- omeprazol: dores de cabeça, diarreia; obstipação; dor abdominal; náusea, vômitos; flatulência; alergia, alterações no  
- sangue, diminuição do sódio, do magnésio, insônia, agitação; alteração no paladar, vertigem, alteração na visão, boca seca;  
- besilato de anlodipino: alergia, vermelhidão, dores de cabeça, inchaços, constipação, ansiedade, tontura, vertigem,  
- tremores, palpitação, diminuição <mark>da pressão arterial</mark> e sensação de mal-estar;  
- prednisona: aumento da pressão arterial, inchaços, ansiedade, insônia, tremores, palpitação aumento dos pêlos, mal  
- estar. Osteoporose e fraqueza, aumento da pressão intraocular (glaucoma), catarata, hematomas e osteonecrose.  
Consultas e exames durante o tratamento são necessários.  
Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) azatioprina  
- (    ) besilato de anlodipino  
- (    ) captopril  
- (    ) ciclofosfamida  
- (    ) metoclopramida  
- (    ) metotrexato  
- (    ) nifedipino  
- (    ) omeprazol  
- (    ) prednisona  
- (    ) sildenafila  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
NOTA 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
NOTA 2: A administração endovenosa de ciclofosfamida é compatível com o procedimento 03.03.02.002-4 - Pulsoterapia II (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Esclerose Sistêmica (ES) contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS). O painel de especialistas incluiu médicos reumatologistas.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A elaboração deste documento foi iniciada em 23 de abril de 2021 com a realização de uma reunião de escopo, a qual definiu as perguntas de pesquisa desse documento. Além disso, houve uma reunião de recomendação no dia 17 de dezembro de 2021, que contou com um painel de especialistas que avaliou as tecnologias priorizadas neste PDCT, incluindo a ciclofosfamida para o tratamento da doença pulmonar intersticial (DPI) concomitante à ES, o metotrexato para o tratamento do espessamento cutâneo e sintomas articulares e a sildenafila para o tratamento de úlceras digitais refratárias aos bloqueadores dos canais de cálcio.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **2. Equipe de elaboração e partes interessadas** -->
O Grupo Elaborador deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS). As reuniões de escopo e de recomendações contaram com a participação de médicos reumatologistas, representantes do Ministério da Saúde, de hospitais de excelência, de sociedades médicas, sociedades sem fins lucrativos e associação de pacientes. O painel de especialistas foi responsável pelo julgamento das evidências identificadas em resposta às questões deste Protocolo e das suas respectivas recomendações, além de revisão do documento final.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Conflito de Interesses** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesses, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A** - Questionário de conflitos de interesse diretrizes clínico-assistenciais  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente<br>a) Reembolso por comparecimento a eventos na área de interesse da diretriz|algum dos benefícios abaixo?<br>(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim|  
||(   ) Não|
|---|---|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim|
||(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim|
||(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou|(   ) Sim|
|prejudicada com as recomendações da diretriz?|(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de|(   ) Sim|
|alguma tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim|
||(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetado<br>atividade na elaboração ou revisão da diretriz?|s pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim|
||(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim|
||(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim|
||(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever|(   ) Sim|
|e que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar|(   ) Sim|
|sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Esclerose Sistêmica foi apresentada à 96ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em fevereiro de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE) e da Secretaria de Atenção Especializada em Saúde (SAES). O PCDT foi aprovado para avaliação pelo Plenário da Conitec.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **4. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias ( **Quadro B** )<sup>1</sup> .  
**Quadro B -** Níveis de evidências de acordo com o sistema GRADE  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|**Moderado**|Há confiança moderada no efeito<br>estimado.|Trabalhos futuros poderão modificar a confiança na estimativa<br>de efeito, podendo, inclusive, modificar a estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto importante<br>em nossa confiança na estimativa de efeito.|
|**Muito**<br>**baixo**|A confiança na estimativa de efeito é<br>muito limitada.<br>Há importante grau de incerteza nos<br>achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para responder a cada questão, primeiramente foram rastreadas diretrizes de qualidade metodológica adequada, conforme avaliada com a ferramenta AGREE II, que incluíssem uma das questões clínicas deste PCDT. Na ausência de diretrizes que incluíssem a avaliação de tecnologias em avaliação neste PCDT e que pudessem ser adotadas ou adaptadas para responder às questões clínicas, foram realizadas buscas por revisões sistemáticas existentes, recentes e de adequada qualidade metodológica que respondessem a cada uma das questões clínicas. Quando não foram encontradas revisões sistemáticas publicadas, uma revisão sistemática foi realizada pelo grupo elaborador para responder à questão clínica.  
Dessa forma, foram elaboradas tabelas de evidências na plataforma GRADEpro (https://gdt.gradepro.org) para cada questão PICO, sendo considerados avaliação do risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferente do da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos) e efeito relativo e absoluto de cada questão.  
Após a síntese das evidências, uma reunião de recomendações foi realizada no dia <mark>17 de dezembro de 2021</mark> com o painel de especialistas. Para a elaboração das recomendações, foram considerados os riscos e os benefícios das condutas propostas, incluindo nível de evidências, custos, uso de recursos, aceitabilidade pelos profissionais e demais barreiras para implementação. A recomendação poderia ser a favor ou contra a intervenção proposta, e ainda ser uma recomendação forte (o grupo está bastante confiante que os benefícios superam os riscos) ou fraca (a recomendação ainda gera dúvidas quanto ao balanço entre benefício e risco). Colocações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou outros esclarecimentos, foram documentadas ao longo do texto. Dessa forma, a direção e a força da recomendação, assim como sua redação, foram definidas durante a reunião. Buscou-se consenso em relação a cada recomendação.  
Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou condicional, de acordo com o sistema GRADE ( **Quadro C** ).  
**Quadro C -** Implicações da força da recomendação para profissionais, pacientes e gestores em saúde  
|**Público-alvo**|**Forte**|**Condicional**|
|---|---|---|
|**Gestores**|A recomendação deve ser adotada como<br>política de saúde na maioria das situações|É necessário debate substancial e envolvimento das<br>partes interessadas.|
|**Pacientes**|A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um<br>pequeno número não aceitaria essa<br>recomendação|Grande parte dos indivíduos desejaria que a intervenção<br>fosse indicada; contudo considerável número não<br>aceitaria essa recomendação.|
|**Profissionais da**<br>**saúde**|A maioria dos pacientes deve receber a<br>intervenção recomendada.|O profissional deve reconhecer que diferentes escolhas<br>serão apropriadas para cada paciente para definir uma<br>decisão consistente com os seus valores e preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
A seguir, são apresentados, para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel, um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE utilizados para responder às questões clínicas deste PCDT.  
**QUESTÃO 1:** Deve-se usar nintedanibe no tratamento das manifestações pulmonares em pacientes com Esclerose Sistêmica?  
Por ainda não ter sido avaliada sua incorporação no SUS, o uso do nintedanibe não é recomendado neste PCDT. No entanto, por se tratar de uma dúvida clínica, a síntese e a avaliação crítica das evidências desta tecnologia foram realizadas. A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica (ES)  
**Intervenção:** Nintedanibe  
**Comparador:** Outros fármacos ou placebo (PBO)  
**Desfechos de Eficácia:** função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial  
pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; sobrevida.  
**Desfechos de Segurança:** eventos adversos graves; eventos adversos gerais.  
**Métodos e resultados da busca**  
Foi realizada uma busca sistemática nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar Ensaios Clínicos Randomizados (ECR) que compararam o uso do nintedanibe com outros fármacos ou PBO. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro D** .  
**Quadro D -** Estratégias de busca para identificação de estudos sobre o uso do nintedanibe em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE via<br>Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "nintedanib" [Supplementary Concept] OR Nintedanib OR Ofev OR Vargatef OR<br>BIBF 1120 OR BIBF1120 OR BIBF-1120<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as topic[MeSH<br>Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract] OR random<br>allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR meta-<br>regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol Assess<br>(Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 #1AND #2 AND #5 NOT #6|51|
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR scleroderma|89|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR 'skin<br>sclerosis'<br>#2 'nintedanib'/exp OR nintedanib OR ofev OR vargatef<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover* OR<br>cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature* OR<br>research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7  #6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 #1 #OR #2 OR #3<br>#5 Nintedanib OR Ofev OR Vargatef OR  BIBF 1120 OR BIBF1120 OR BIBF-1120<br>#6 #4 AND #5|64|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Lilacs via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*) OR<br>mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>Nintedanib OR Ofev OR Vargatef OR  BIBF 1120 OR BIBF1120 OR BIBF-1120<br>Filter: Lilacs|1|
|Epistemonikos|(title:((Systemic Scleroderma) AND Nintedanib) OR abstract:((Systemic Scleroderma)<br>AND Nintedanib))|1|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipos de intervenção  
Nintedanibe em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram considerados ECR.  
(d) Desfechos: função pulmonar [ex: capacidade vital forçada (CVF), volume expiratório forçado no primeiro segundo (VEF1), capacidade de difusão de CO]; capacidade funcional (ex: distância percorrida em 6 minutos); resistência vascular pulmonar; pressão arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliada por questionários validados (ex: _Scleroderma-Health Assessment Questionnaire_ (S-HAQ)); mortalidade; sobrevida; eventos adversos graves; eventos adversos gerais.  
(e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 206 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 2 textos completos. Um estudo foi  
excluído por incluir dados de pacientes não randomizados<sup>3</sup> e um ensaio clínico randomizado (ECR) foi incluído<sup>4</sup> . O processo de seleção é detalhado na **Figura 1** .  
**Figura 1** - Fluxograma de seleção dos estudos avaliando o uso do nintedanibe comparado a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES.  
<!-- Start of picture text -->
aie age Referéncias removidas antes do<br>Referéncias identificadas por tastreamento:<br>meio de busca nas bases de Referéncias duplicadas<br>dados (n = 206) removidas (n = 3)<br>Referéncias rastreadas (n = 203) Referéncias excluidas (n = 201)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 2) ——_+> Estudo com desenho de<br>estudo inadequado (n = 1)<br>Estudos incluidos nesta revisao<br>(n=1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u><mark>Análise e apresentação dos resultados</mark></u>** -->
<mark>A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada</mark> _<mark>Risk of bias</mark>_ <mark>(ROB) 2.0</mark><sup>5</sup> <mark>. Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.</mark>  
<mark>Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de diferenças de médias (DM) entre os grupos (estimativa da mudança pós-pré) com intervalo de confiança (IC) de 95%. As variáveis dicotômicas foram sumarizadas usando risco relativo (RR) com IC de 95%. A taxa de sobrevida foi calculada por regressão de Cox e apresentada em</mark> _<mark>hazard ratio</mark>_ <mark>(HR).</mark>

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<mark>Resumo das evidências:</mark>** -->
<mark>O único estudo que avaliou a eficáci</mark> a <mark>e segurança do nintedanibe no tratamento das manifestações pulmonares em indivíduos com ES foi conduzido entre 2015 e 2017 e incluiu 576 adultos que foram randomizados para receber 150 mg de nintedanibe, administrado por via oral duas vezes ao dia ou placebo (PBO) e foram seguidos por 52 semanas</mark><sup>4</sup> <mark>. Os participantes apresentavam doença pulmonar intersticial (DPI) identificada com base em uma tomografia computadorizada de alta resolução, fibrose afetando pelo menos 10% dos pulmões, CVF de pelo menos 40% do valor predito e capacidade de difusão de monóxido de carbono (corrigida para hemoglobina) de 30 a 89% do valor predito. Neste estudo, o grupo que recebeu nintedanibe apresentou maior redução do declínio anual da CVF medida em mililitros (DM 41,00; IC95% 2,9 a 79,9) e avaliada como porcentagem do valor predito (DM 1,2; IC95% 0,1 a 2,2). No entanto, houve um grande número de participantes que suspendeu o tratamento (56</mark>  
<mark>no grupo nintedanibe e 31 no grupo PBO) e de perdas durante o acompanhamento (24 no grupo nintedanibe e 13 no PBO), o que pode limitar a análise da validade destes resultados, uma vez que, com a evolução da doença, os pacientes tendem a piorar progressivamente. Em análises de sensibilidade, quando foram considerados três cenários, em nenhum dos cenários testados foi detectada diferença entre os grupos. No cenário 1, os valores de CVF foram imputados considerando um declínio da função pulmonar igual ao grupo correspondente de tratamento em que os pacientes perdidos durante o acompanhamento evoluíram de maneira semelhante (DM 30,00; IC95% -6,22 a 66,22). No cenário 2, os valores perdidos de função pulmonar foram imputados assumindo que os pacientes tinham a mesma taxa dos pacientes do grupo placebo que suspenderam prematuramente, mas tinham um valor de CVF na semana 52 (DM 32,93 IC95% -3,19 a 69,06). No cenário 3, os valores perdidos na semana 52 de CVF foram imputados assumindo uma taxa de declínio similar aos pacientes do grupo PBO que foram incluídas na análise primária (DM 33,86; IC95% -2,03 a 69,75).</mark>  
<mark>Quanto aos demais desfechos avaliados, não foi possível detectar diferenças entre os grupos na qualidade de vida, avaliada por meio do</mark> _<mark>St. George's Respiratory Questionnaire</mark>_ <mark>(SGRQ) (DM 1,69; IC95% -0,73 a 4,12), na capacidade de difusão de monóxido de carbono (DM -0,44; IC95% -1,94 a 1,06), no estado funcional, avaliada por meio do</mark> _<mark>Health Assessment Questionnaire-Disability Index</mark>_ <mark>(HAQ-DI) (DM 0,032 IC95% -0,035 a 0,099), na dispneia, avaliado pela escala de Avaliação Funcional da Terapia para Doenças Crônicas-Dispneia (FACIT-Dyspnea) (DM 0,64; IC95% -0,51 a 1,79), na mortalidade (RR 1,11; IC95% 0,46 a 2,69) e na sobrevida (HR 1,16; IC 95% 0,47 a 2,84).</mark>  
<mark>Com relação à segurança do medicamento, os eventos adversos mais frequentes foram: diarreia [nintedanibe = 218 (75,7%) vs PBO = 91 (31,6%), (RR 2,40; IC95% 2,00 a 2,89)], náusea [nintedanibe = 91 (31,6%) vs PBO = 39 (13,5%), (RR 2,33; IC95% 1,66 a 3,27)] e vômitos [nintedanibe = 71(24,7%) vs PBO = 30 (10,4%), (RR 2,37; IC95% 1,60 a 3,51)]. Resultados extraídos da plataforma de registro Clinicaltrials.gov</mark><sup>4</sup> <mark>(não apresentados na publicação) também mostram maior incidência de infecções no grupo que recebeu nintedanibe (RR 2,43; IC95% 1,33 a 4,43). Os eventos adversos que levaram à suspensão do tratamento foram mais prevalentes no grupo que recebeu nintedanibe [nintedanibe = 46/288 (16%) vs PBO = 25/288 (9%), (RR 1,84; IC95% 1,16 a 2,91)]. Os grupos não apresentaram diferenças quanto à incidência de qualquer evento adverso (RR 1,02; IC95% 0,99 a 1,05), de eventos adversos muito graves, definidos como evento que resultou em morte, ameaça à vida ou hospitalização ou prolongamento da hospitalização, incapacidade clínica significativa ou persistente (RR 1,11; IC95% 0,82 a 1,50) e</mark> de eventos adversos graves, definidos <mark>como evento incapacitante ou que causou inabilidade para o trabalho ou para realizar atividades usuais (RR 1,44; IC95% 0,98 a 2,14).</mark>  
<mark>O risco de viés geral do estudo foi julgado como alto para todos os desfechos avaliados. Consideraram-se algumas preocupações quanto ao risco de viés devido aos desvios das intervenções pretendidas para todos os desfechos, uma vez que a maior frequência de eventos adversos no grupo nintedanibe pode ter comprometido o cegamento dos participantes e intervencionistas. Além disso, visto que houve um elevado número de pacientes que suspendeu o tratamento e que foram perdidos durante o seguimento do estudo, julgou-se como alto risco de viés devido aos dados faltantes para todos os desfechos. Para os desfechos qualidade de vida (avaliados com a SGRQ), capacidade funcional e dispneia, também foi considerado haver alto risco de viés na mensuração do desfecho, uma vez que o cegamento dos avaliadores também pode ter sido comprometido e pode ter influenciado na avaliação destes desfechos. A avaliação completa do risco de viés deste estudo é apresentada na</mark> **<mark>Figura 2</mark>** <mark>.</mark>  
**<mark>Figura 2</mark>** <mark>- Risco de viés do estudo incluído avaliando o</mark> uso do nintedanibe comparado a placebo para o tratamento de manifestações pulmonares na ES  
<!-- Start of picture text -->
Estudo Desfecho OL 02 03 D4 05 Geral<br>Distler 20198 Qualdade de vida ) u @ @ e ®@ t ) Baio Risco<br>Distler 2019) Taxa de declinio anual da CVF @ ! @ @ @ 6) 1) Algumas preocupacdes<br>Distler 2019 Capacidade de difusdo de CO + ! @ + + 16) @ Alto Risco<br>Distler 20194 Estado funcional @) ! @ r ) @ 6)<br>Distler 2019e _Dispneia @) ! @ @ + 6) o1 Processo de randomiza¢o<br>Distler 2019 — Mortalidade @) ! @ + + 6) 02 Desvios das intervenes pretendidas<br>Distler 2019 Sobrevida @) ! @ @ @ 6) 03 Dados faltantes do desfecho<br>Distler 2019h Eventos adversos graves + 1 @ + + 6) 04 Mensuragdo do desfecho<br>Distler 20191 Eventos adversos severos + ! @ + + 6) 0S Selecdo dos resultados reportados<br><!-- End of picture text -->  
O **Quadro E** apresenta os resultados do estudo incluído e da avaliação da certeza da evidência (GRADE) para os sete principais desfechos.  
**Quadro E -** Nintedanibe comparado a placebo para o tratamento de manifestações pulmonares na ES  
|**№ de**<br>**estudos**|**Delineamento**<br>**do estudo**|**Avali**<br>**Risco**<br>**de viés**|**ação da certeza**<br>**Inconsistência**|**da evidência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**№ de paci**<br>**Nintendanibe**|**entes**<br>**Placebo**|**Ef**<br>**Relativo**<br>**(IC 95%)**|**eito**<br>**Absoluto**<br>**(IC 95%)**|**Certeza**<br>**da**<br>**evidência**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|Função pu|lmonar - Medido|com a taxa|anual de declínio|em CVF (milil|itros por ano) -|Seguimento: 52 s|emanas<sup>4</sup>|||||
|1|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>c</sup>|nenhuma|288|288|DM 41|maior (2,9|⨁⨁◯◯|
|Qualidade|de vida - Medido|com a pont|uação total no S|GRQ - Seguime|nto: 52 semana|s<sup>4</sup>|||maior a 7|9,9 maior)|Baixa|
|1|ECR|grave<sup>b</sup>|não grave|não grave|grave<sup>c</sup>|nenhuma|288|288|DM 1,6 m|aior (0,73|⨁⨁◯◯|
|Função pu|lmonar - Medida|com a capac|idade de difusão|do CO - Segui|mento: 52 sem|anas<sup>4</sup>|||menor a 4|,12 maior)|Baixa|
|1|ECR|grave<sup>a</sup>|não grave|não grave|não grave|nenhuma|288|288|DM 0,44|menor (1,94|⨁⨁⨁◯|
||||||||||menor a 1|06 maior)|Moderada|
|Estado fun<br>|cional - Medido p<br>|or meio do<br>|HAQ-DI - Segui|mento: 52 sem|anas<sup>4</sup>||||<br>|,<br>|<br>|
|1|ECR|grave<sup>b</sup>|não grave|não grave|não grave|nenhuma|288|288|DM 0,03 m<br>menor a 0|aior (0,035<br>099 maior)|⨁⨁⨁◯<br>Moderada|
|Dispneia -<br>|Medido com o F<br>|ACIT-Dysp<br>|nea - Seguimento<br>|: 52 semanas<sup>4</sup><br>|||||<br>|<br>||
|1|ECR|grave<sup>b</sup>|não grave|não grave|não grave|nenhuma|288|288|DM 0,64<br>menor a 1|maior (0,51<br>79 maior)|⨁⨁⨁◯<br>Moderada|
|Mortalida|de - Seguimento:|52 semanas|<sup>4</sup>|||||||,||
|1|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>d</sup>|nenhuma|10/288 (3,5%)|9/288<br>(3,1%)|RR 1,11;<br>IC 95%<br>0,46 a<br>2,69|0 mais por<br>100<br>(2 menos<br>a 5 mais)|⨁⨁◯◯<br>Baixa|
|Eventos ad|versos graves* -|Seguimento|: 52 semanas<sup>4</sup>|||||||||  
|1<br>ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>d</sup>|nenhuma|69/288|62/288|RR 1,11;|2 mais por|⨁⨁◯◯|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||(24,0%)|(21,5%)|IC 95%|100|Baixa|
|||||||||0,82 a<br>1,50|(4 menos<br>a 11 mais)||  
ECR: Ensaio clínico randomizado; DM: Diferença média; RR: Risco relativo; IC: Intervalo de Confiança; CVF: Capacidade vital forçada; SGRQ: Questionário Respiratório de St. George; CO: monóxido de carbono; HAQ-DI:  
_Health Assessment Questionnaire-Disability Inde_ x; FACIT-Dyspnea:  Avaliação Funcional da Terapia para Doenças Crônicas-Dispneia  
*Eventos adversos graves - definido como evento que resultou em morte, ameaça à vida ou hospitalização ou prolongamento da hospitalização, incapacidade clínica significativa ou persistente  
a Diminuído um nível devido à importante limitação metodológica (algumas preocupações quanto ao desvio das intervenções pretendidas e alto risco de viés devido a dados faltantes do desfecho)  
b Diminuído um nível devido à importante limitação metodológica (algumas preocupações quanto ao desvio das intervenções pretendidas e alto risco de viés devido a dados faltantes do desfecho e mensuração do desfecho) c Diminuído um nível devido à presença de IC amplo  
dDiminuído um nível devido à presença de poucos eventos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<mark>Resumo das evidências:</mark>** -->
<mark>4. Distler O, Highland KB, Gahlemann M, Azuma A, Fischer A, Mayes MD, Raghu G, Sauter W, Girard M, Alves M, Clerisme-Beaty E, Stowasser S, Tetzlaff K, Kuwana M, Maher TM; SENSCIS Trial Investigators. Nintedanib for Systemic Sclerosis-Associated Interstitial Lung Disease. N Engl J Med. 2019 Jun 27;380(26):2518-2528. doi: 10.1056/NEJMoa1903076. Epub 2019 May 20. PMID: 31112379.</mark>  
**QUESTÃO 2:** Deve-se usar rituximabe no tratamento das manifestações pulmonares nos pacientes com Esclerose Sistêmica?  
Por não haver indicação em bula aprovada pela Agência Nacional de Vigilância Sanitária (Anvisa) para a utilização do rituximabe no tratamento das manifestações pulmonares da Esclerose Sistêmica, este medicamento não é recomendado neste PCDT. No entanto, por se tratar de uma dúvida clínica, a síntese e a avaliação crítica das evidências desta tecnologia foram realizadas.  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica  
**Intervenção:** Rituximabe  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; sobrevida.  
**Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR que compararam o uso do rituximabe com outros fármacos ou PBO. A busca foi realizada em <mark>22 de julho</mark> de 2021. As estratégias de busca para cada base estão descritas no **Quadro F** .  
**Quadro F -** Estratégias de busca para identificação de estudos sobre o uso do rituximabe em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE via<br>Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Rituximab"[Mesh] OR Rituximab OR Mabthera OR IDEC-C2B8 Antibody OR<br>IDEC C2B8 Antibody OR IDEC-C2B8 OR IDEC C2B8 OR GP2013 OR Rituxan<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR|227|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#8 - #1AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'rituximab'/exp OR rituximab OR 'abp 798' OR abp798 OR blitzima OR 'ct p10' OR<br>ctp10 OR 'gp 2013' OR gp2013 OR halpryza OR 'hlx 01' OR hlx01 OR 'ibi 301' OR<br>ibi301 OR 'idec 102' OR 'idec c2b8' OR 'dec102' OR idecc2b8 OR mabthera OR 'mk<br>8808' OR mk8808 OR 'pf 05280586' OR 'pf 5280586' OR pf05280586 OR pf5280586<br>OR 'r 105' OR r105 OR reditux OR 'rg 105' OR rg105 OR riabni OR ritemvia OR<br>ritucad OR ritumax OR rituxan OR 'rituximab abbs' OR 'rituximab arrx' OR 'rituximab<br>pvvr' OR rituxin OR rituzena OR rixathon OR riximyo OR 'ro 452294' OR ro452294<br>OR 'rtxm 83' OR rtxm83 OR ruxience OR truxima OR tuxella|151|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7 #6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 #1 #OR #2 OR #3<br>#5 MeSH descriptor: [Rituximab] explode all trees<br>#6 Mabthera OR Rituxan OR Rituximab<br>#7 #6 OR #5<br>#8 #7 AND #4|82|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Lilacs via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:Rituximab OR mh:D12.776.124.486.485.114.224.075.785$ OR<br>mh:D12.776.124.790.651.114.224.075.785$ OR<br>mh:D12.776.377.715.548.114.224.284.785$ ORRituximab OR Mabthera OR (IDEC-<br>C2B8 Antibody) OR (IDEC C2B8 Antibody) OR IDEC-C2B8 OR (IDEC C2B8) OR<br>GP2013 OR Rituxan<br>Filter: Lilacs|5|
|Epistemonikos|(title:((Systemic Scleroderma) AND (Rituximab)) OR abstract:((Systemic<br>Scleroderma) AND (Rituximab)))|5|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipo de intervenção  
Rituximabe em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
<mark>Foram considerados ECRs.</mark>  
(d) Desfechos: função pulmonar [ex: capacidade vital forçada (CVF) volume expiratório forçado no primeiro segundo (VEF1), capacidade de difusão de monóxido de carbono; capacidade funcional (ex: distância percorrida em 6 minutos]; resistência vascular pulmonar; pressão arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliada por questionários validados (ex: _Scleroderma-Health Assessment Questionnaire_ (S-HAQ)); mortalidade; sobrevida; eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas <mark>470</mark> referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 5 <mark>textos completos. Um estudo foi excluído por não se tratar de um ECR</mark><sup>6</sup> e 4 ECRs foram incluídos<sup>7–10</sup> . O processo de seleção é detalhado na **Figura 3** .  
**Figura 3** - Fluxograma de seleção dos estudos <mark>avaliando o</mark> uso do rituximabe comparado a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES.  
<!-- Start of picture text -->
a. . Referéncias removidas antes do<br>Referéncias identificadas por rastreamento:<br>meio de busca nas bases de Referéncias duplicadas<br>dados (n = 470) removidas (n = 63)<br>Referéncias rastreadas (n = 407) Referéncias excluidas (n = 402)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 5) —» Estudo com desenho de<br>estudo inadequado (n = 1)<br>Estudos incluidos nesta reviséo<br>(n= 4)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés dos estudos incluídos foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada _Risk of Bias_ (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa da mudança pós-pré ou estimativa pós-intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
<mark>Quatro estudos avaliaram a efetividade e segurança do rituximabe no trata</mark> mento de indivíduos com ES<sup>7–10</sup> . Devido à presença de diferentes intervenções no grupo comparador de cada estudo incluído, não foi possível agrupar os resultados em metanálises e, por esse motivo, os resultados dos estudos foram descritos de forma individualizada. Daoussis et al. (2010)<sup>7</sup> compararam o uso de rituximabe ao tratamento convencional que incluía o uso de prednisona, micofenolato, ciclofosfamida e bosentana em 14 pacientes com ES. Os resultados do estudo de Daoussis et al. (2010)<sup>7</sup> indicam não haver diferença estatisticamente significante na função pulmonar, conforme avaliado pela CVF medida pela porcentagem do valor predito (DM 11,83; IC95% -4,55 a 28,21) entre os grupos. No grupo rituximabe, 6/8 (75%) pacientes exibiram uma melhora clinicamente significativa do estado funcional, conforme definido por uma diminuição no escore _Health Asssessment Questionnaire_ (HAQ)  
de 0,2. No grupo de tratamento convencional, 3/6 (50%) pacientes melhoraram. Não houve diferença significativa entre os grupos com relação à capacidade funcional, avaliada pelo HAQ, após um ano (RR 1,5; IC95% 0,61 a 3,67).  
Quanto à segurança do rituximabe, no estudo de Daoussis et al. (2010)<sup>7</sup> , um paciente teve infecção do trato respiratório durante o estudo. Boonstra et al. (2017)<sup>8</sup> conduziram um ECR em 16 pacientes com ES diagnosticada há menos de 2 anos. Os pacientes receberam infusões de rituximabe ou PBO em t = 0, t = 15 dias e t = 6 meses. Não houve diferenças entre os grupos com relação à função pulmonar avaliada pela CVF medida pela porcentagem do valor predito (DM 2,8; IC95% -2,8 a 8,4), quanto à capacidade funcional avaliada por meio do HAQ (DM -0,17; IC95% -0,69 a 0,36), eventos adversos (RR 1,13; IC95% 0,81 a 1,58) e eventos adversos graves (RR 1,75; IC95% 0,83 a 3,67). Ebata et al. (2021)<sup>9</sup> também compararam rituximabe a PBO e não encontraram diferença entre os grupos quanto à incidência de eventos adversos em 56 pacientes com ES (RR 1,10; IC95% 0,56 a 2,17). No estudo de Sircar et al. (2018)<sup>10</sup> , 60 pacientes foram randomizados para receber rituximabe ou ciclofosfamida. Os resultados indicam que o rituximabe parece ser superior à ciclofosfamida para redução do declínio da função pulmonar conforme avaliado pela CVF medida pela porcentagem do valor predito (DM 9,46; IC95% 3,01 a 15,90) e capacidade funcional avaliada pelo teste de caminhada de 6 min (DM 60,46; IC95% 17 a 103,92) e de que não há diferença quanto aos eventos adversos (RR 0,5; IC95% 0,17 a 1,48).  
O risco de viés geral dos estudos foi julgado como alto. Para o desfecho função pulmonar, eventos adversos e capacidade funcional, no estudo de Daoussis et al. (2010)<sup>7</sup> , foi considerado alto risco de viés no processo de randomização e houve algumas preocupações quanto à presença de desvios das intervenções pretendidas e seleção do resultado relatado. No estudo de Boonstra et al. (2017), para os desfechos de função pulmonar, eventos adversos e capacidade funcional, houve algumas preocupações quanto ao processo de randomização e alto risco de viés devido aos dados perdidos dos desfechos. No estudo de Ebata et al. (2021)<sup>9</sup> , para o desfecho de eventos adversos, houve algumas preocupações quanto ao processo de randomização e alto risco de viés devido aos desvios das intervenções pretendidas e dados perdidos do desfecho. No estudo de Sircar et al. (2018)<sup>10</sup> , houve algumas preocupações quanto à presença de desvios das intervenções pretendidas e à seleção do resultado relatado para os desfechos função pulmonar, eventos adversos e capacidade funcional e, portanto, houve algumas preocupações quanto ao risco de viés geral. A avaliação completa do risco de viés deste estudo é apresentada na **Figura 4** .  
**Figura 4** - <mark>Risco de viés do estudo incluído avaliando</mark> o uso do rituximabe comparado a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES.  
<!-- Start of picture text -->
Estudo Desfecho D1 D2 D3 Da DS Geral<br>Daoussis 2010 Fungo pulmonar e ! e e@ ! e e@ Baixo risco<br>Daoussis 2010 Eventos adversos oe ! e e@ ! r ) 1) Algumas preocupacgées<br>Daoussis 2010 Capacidade Funcional e ! e e@ ! t ) r } Alto risco<br>Sircar 2018 Fungo pulmonar e ! e e@ ! !<br>Sircar 2018 Eventos adversos e ! e e@ ! ! D1 —_Processo de randomizag3o<br>Sircar 2018 Capacidade Funcional e ! e e ! ! D2 _Desvio das intervencées pretendidas<br>Boosntra 2017 Fungo pulmonar 1 e@ e e@ e e D3 Dados perdidos do desfecho<br>Boosntra 2017 Capacidade Funcional | ! e e e e e D4 — Mensura¢So do desfecho<br>Boosntra 2017 _—Eventos adversos 1 e@ © e@ e r ) DS _SelegSo do resultado relatado<br>Ebata 2021 Eventos adversos ! r } e e e t )<br><!-- End of picture text -->  
O **Quadro G** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.  
**Quadro G -** Ri <mark>tuximabe comparado a outros fármacos ou placebo para o tratamento de manifestações pulmonares na</mark> ES  
|**№ de**<br>**estudos**<br>**Função p**<br>|**Delineamento**<br>**do estudo**<br>**ulmonar - CVF**(<br>|**Avalia**<br>**Risco**<br>**de viés**<br>avaliado e<br>|**ção da certeza**<br>**Inconsistência**<br>m**6 meses a 24**<br>|**da evidência**<br>**Evidência**<br>**indireta**<br>**meses)**% do<br>|**Imprecisão**<br>predito <sup>7,8,10</sup><br>|**Outras**<br>**considerações**<br>|**Efeito**<br>**(Rituximabe versus outros fármacos ou placebo)**<br>|**Certeza da**<br>**evidência**<br>|
|---|---|---|---|---|---|---|---|---|
|3<br>**Capacida**<br>|ECR<br>**de funcional**(ava<br>|**grave**<sup>**a**</sup><br>liado em <br>|não grave<br>**6 meses a 24 me**<br>|não grave<br>**ses)**HAQ<sup>7,8</sup> <br>|**muito**<br>**grave**<sup>**b**</sup><br>e TC6min <sup>10</sup><br>|nenhum<br>|**Rituximabe versus Placebo**<br>A DM foi 2,8 maior (2,8 menor a 8,4 maior); 16<br>participantes; 8 participantes em cada grupo; 1 estudo<sup>8</sup><br>**Rituximabe versus Tratamento Convencional**<br>A DM foi de 11,83 maior (4,55 menor a 28,21 maior); 14<br>participantes; 1 estudo<sup>7</sup><br>**Rituximabe versus Ciclofosfamida**<br>A DM foi de 9,46 maior (3,01 maior a 15,90 maior); 60<br>participantes; 30 participantes em cada grupo; 1 estudo<sup>10</sup><br>|⨁⨁◯◯<br>Baixa<br>|
|3|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**muito**<br>**grave**<sup>**b**</sup>|nenhum|**Rituximabe versus Placebo**<br>A DM foi 0,17 menor (0,69 menor a 0,36 maior); 16<br>participantes (16 participantes; 8 participantes em cada<br>grupo); 1 estudo<sup>8</sup><br>**Rituximabe versus Tratamento Convencional**|⨁◯◯◯<br>Muito<br>Baixa|  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Rituximabe versus outros fármacos ou placebo)  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>estudos  do estudo  de viés  indireta  considerações<br>No grupo rituximabe, houve melhora clinicamente<br>significativa em 6/8 participantes (75%) (diminuição no<br>HAQ de 0,2). No grupo tratamento convencional, 3/6<br>(50%) pacientes melhoraram [RR 1,5 (IC 95% 0,61 a 3,67)]<br>(250 mais por 1,000 (195 menos a 1000 mais); 14<br>participantes; 8 participantes no grupo rituximabe e 6 no<br>grupo tratamento convencional; 1 estudo  7<br>Rituximabe versus Ciclofosfamida<br>A DM foi  60,46 maior(17 maior a 103,92 maior); 60<br>participantes; 60 participantes; 30 participantes em cada<br>grupo; 1 estudo  10<br>Eventos adversos -(seguimento: 6 meses a 12 meses; avaliado com: Infecções do Sist. respiratório  7,9  e  Infecções do Sist. respiratório ou urinário  10 )<br>3  ECR  grave c não grave  não grave  grave d  nenhum  Rituximabe versus Placebo ⨁⨁◯◯<br> Rituximabe 11/28 (39%)   Baixa<br>Placebo 10/28 (36%)<br>(RR 1,10; IC 95% 0,56 a  2,17)<br>36 mais por 1,000<br>(de 157  menos para 418 mais); 56 participantes; 28<br>participantes em cada grupo; 1 estudo  9<br>Rituximabe versus Tratamento Convencional<br><!-- End of picture text -->  
|||**Avali**|**ação da certeza**|**da evidência**|||**Efeito**<br>**(Rituximabe versus outros fármacos ou lacebo)**|**Certeza da**<br>**evidência**|
|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**p**||
|**Eventos a**|**dversos total**(av|aliado em|**24 meses)**<sup>8</sup>||||No grupo rituximabe,1/8 (12,5%) paciente teve infecção do<br>trato respiratório durante o estudo.No grupo tratamento<br>convencional, nenhum evento 0/6 (0%) foi reportado (RR<br>2,33; IC 95% 0,11 a 48,99); 250 mais por 1,000 (195 menos<br>a 1000 mais); 14 participantes; 8 participantes no grupo<br>rituximabe e 6 no grupo tratamento convencional; 1 estudo<br>7<br>**Rituximabe versus Ciclofosfamida**<br>Rituximabe 4/30 (13,3%)<br>Ciclofosfamida 8/30 (26,7%)<br>RR 0,5 (IC 95% 0,17 a 1,48)<br>133 menos por 1,000<br>(221 menos a 128 mais)<sup>10</sup>||
|1<br>**Eventos a**|ECR<br>**dversos graves**(|**grave**<sup>**e**</sup><br>avaliado e|não grave<br>m**24 meses)**<sup>8</sup>|não grave|**muito**<br>**grave**<sup>**b**</sup>|nenhum|**Rituximabe versus Placebo**<br>O número total de eventos adversos no grupo rituximabe foi<br>8 (100%) e no grupo placebo 7 (87,5%); (RR 1,13; IC95%<br>0,81 a 1,58); 114 mais por 1000 (166 menos a 508 mais);<br>16 participantes; 8 participantes em cada grupo; 1 estudo<sup>8</sup>|⨁◯◯◯<br>Muito<br>Baixa|  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Rituximabe versus outros fármacos ou placebo)  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>estudos  do estudo  de viés  indireta  considerações<br>1  ECR  grave e não grave  não grave  muito  nenhum  Rituximabe versus Placebo  ⨁◯◯◯<br>grave b O número total de eventos adversos no grupo rituximabe foi  Muito<br>7 (87,5%) e no grupo placebo 4 (50%); RR 1,75 (0,83 a  Baixa<br>3,67); [375 mais por 1000 (85 menos a 1000 mais)]; 1<br>estudo; 16 participantes; 8 participantes em cada grupo; 1<br>estudo  8<br><!-- End of picture text -->  
ECR: Ensaio clínico randomizado; DM: Diferença média; RR: Risco relativo; IC: Intervalo de Confiança; CVF: Capacidade vital forçada; HAQ: _Health Assessment Questionnaire_ ; TC6: Teste de Caminhada de 6 minutos  
a Diminuído um nível devido a importante limitação metodológica (2 estudos com alto risco de viés geral (1 estudo com algumas preocupações quanto ao desvio das intervenções pretendidas e seleção do resultado relatado e alto  
risco de viés no processo de randomização e 1 estudo com algumas preocupações quanto ao processo de randomização e alto risco de viés devido a dados perdidos do desfecho) e 1 estudo com algumas preocupações quanto ao risco de viés geral (algumas preocupações quanto ao desvio das intervenções pretendidas e seleção do resultado relatado).  
- b Diminuído dois níveis devido a presença de poucos participantes e IC amplo  
c  Diminuído um nível devido à presença de limitações metodológicas (2 estudos com alto risco de viés geral (1 estudo com algumas preocupações quanto ao processo de randomização  e alto risco quanto ao desvio das intervenções  
pretendidas e dados perdidos do desfecho e 1 estudo com algumas preocupações quanto ao desvio das intervenções pretendidas e seleção do resultado relatado e alto risco de viés no processo de randomização) e 1 estudo com algumas  
preocupações quanto ao risco de viés geral - algumas preocupações quanto ao desvio das intervenções pretendidas e seleção do resultado relatado)  
- d. <mark>Diminuído um nível devido à presença de poucos eventos ou poucos participantes</mark>  
e  Diminuído um nível devido à presença de limitações metodológicas (1 estudo com alto risco de viés geral - algumas preocupações quanto ao processo de randomização e alto risco devido a dados perdidos do desfecho)

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
<mark>7. Daoussis D, Liossis SN, Tsamandas AC, Kalogeropoulou C, Kazantzi A, Sirinian C, Karampetsou M, Yiannopoulos G, Andonopoulos AP. Experience with rituximab in scleroderma: results from a 1-year, proof-of-principle</mark>  
<mark>study. Rheumatology (Oxford). 2010 Feb;49(2):271-80. doi: 10.1093/rheumatology/kep093. Epub 2009 May 15. PMID: 19447770; PMCID: PMC2806066.</mark>  
<mark>8. Boonstra M, Meijs J, Dorjée AL, Marsan NA, Schouffoer A, Ninaber MK, Quint KD, Bonte-Mineur F, Huizinga TWJ, Scherer HU, de Vries-Bouwstra JK. Rituximab in early systemic sclerosis. RMD Open. 2017 Jul</mark>  
<mark>28;3(2):e000384. doi: 10.1136/rmdopen-2016-000384. PMID: 28879049; PMCID: PMC5574444.</mark>  
<mark>9. Ebata S, Yoshizaki A, Oba K, Kashiwabara K, Ueda K, Umemura Y, Watadani T, Fukasawa T, Miura S, Yoshizaki-Ogawa A, Asano Y, Okiyama N, Kodera M, Hasegawa M, Sato S. Safety and Efficacy of Rituximab for</mark>  
<mark>Systemic Sclerosis: A Double-Blind, Parallel-Group Comparison, Investigators Initiated Confirmatory Randomized Clinical Trial (DESIRES Study) [abstract]. Arthritis Rheumatol. 2021; 73 (suppl 10).</mark>  
<mark>10. Sircar G, Goswami RP, Sircar D, Ghosh A, Ghosh P. Intravenous cyclophosphamide vs rituximab for the treatment of early diffuse scleroderma lung disease: open label, randomized, controlled trial. Rheumatology (Oxford).</mark>  
<mark>2018 Dec 1;57(12):2106-2113. doi: 10.1093/rheumatology/key213. PMID: 30053212.</mark>  
**QUESTÃO 3.** Deve-se usar azatioprina para a redução da progressão da fibrose pulmonar em pacientes com Esclerose Sistêmica?  
**<u>Recomendação:</u>** Sugerimos utilizar azatioprina para a redução da progressão da fibrose pulmonar em pacientes com Esclerose Sistêmica (recomendação não graduada).  
A estrutura PICO para esta pergunta foi: **População:** Pacientes com Esclerose Sistêmica **Intervenção:** Azatioprina  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; sobrevida. **Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR comparando azatioprina a outros fármacos ou placebo para a redução da progressão da fibrose pulmonar em pacientes com ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro H** .  
**Quadro H -** Estratégias de busca para identificação de estudos sobre o uso da azatioprina em pacientes com ES  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE via<br>Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Azathioprine"[Mesh] OR Azothioprine OR Imurel OR Imuran OR Immuran OR<br>Azathioprine Sodium OR Sodium, Azathioprine OR Azathioprine Sodium Salt OR<br>Azathioprine Sulfate<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes|161|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab]<br>OR der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7   #1 AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia<br>OR 'skin sclerosis'<br>#2 'azathioprine'/exp OR arathioprin OR arathioprine OR aza-q OR azafalk OR<br>azahexal OR azamedac OR azamun OR azamune OR azanin OR azapin OR azapress<br>OR azaprine OR azarex OR azasan OR azathiodura OR azathiopine OR azathioprim<br>OR azathioprin OR azathioprine sodium OR azathiopurine OR azathropsin OR<br>azatioprina OR azatox OR azatrilem OR azopi OR azoran OR azothioprin OR<br>azothioprine OR colinsan OR immuran OR immurel OR immuthera OR imune OR<br>imuprin OR imuran OR imurane OR imurek OR imurel OR imuren OR<br>methylnitroimidazolylmercaptopurine OR thioazeprine OR  thioprine OR transimune<br>OR zytrim|7|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database*<br>OR computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data<br>base' OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR<br>((review* OR overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ*<br>OR research* OR literature* OR studies OR trial* OR effective*)):ab NOT<br>(((retrospective* OR record* OR case* OR patient*) NEAR/2 review*):ab,ti OR<br>((patient* OR review*) NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR<br>mouse:ab,ti OR mice:ab,ti OR hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR<br>animals:ab,ti OR dog:ab,ti OR dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti<br>OR sheep:ab,ti) NOT ('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT<br>('animal'/exp OR 'nonhuman'/exp NOT ('animal'/exp OR 'nonhuman'/exp AND<br>'human'/exp))<br>#5  #3 OR #4<br>#6  #1 AND #2 AND #5<br>#7 #6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor:[Azathioprine] explode all trees<br>#5 Imurel OR Azathioprine Sulfate OR Azathioprine Sodium OR Azathioprine<br>Sodium Salt OR Sodium, Azathioprine OR Azothioprine OR Immuran OR Imuran<br>#6 #1 OR #2 OR #3|12|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#7 #4 OR #5<br>#8 #6 AND #7||
|Lilacs via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:Azatioprina OR Azathioprine OR Azatioprina OR Azathioprine OR mh:<br>D02.886.759.111$ OR mh:D03.633.100.759.570.090$ OR D13.570.900.111$ Filter: Lilacs|6|
|Epistemonikos|title:(Systemic Scleroderma) OR abstract:(Systemic Scleroderma)) AND<br>(title:(Azathioprine) OR abstract:(Azathioprine))|1|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipo de intervenção  
Azatioprina em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram considerados ECRs.  
(d) Desfechos de eficácia: função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; sobrevida. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 187 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 2 textos completos. Um estudo foi excluído por não se tratar de um ECR<sup>11</sup> e um ECR foi incluído<sup>12</sup> . O processo de seleção é detalhado na **Figura 5** .  
**Figura 5 –** Fluxograma de seleção dos estudos avaliando o uso da azarioprina comparada a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES **.**  
<!-- Start of picture text -->
ancine identi Referéncias removidas antes do<br>Referéncias identificadas por rastreamento:<br>meio de busca nas bases de Referéncias duplicadas<br>dados (n = 187) removidas (n = 2)<br>Referéncias rastreadas (n = 185) Referéncias excluidas (n = 183)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 2) —> Estudo com desenho de<br>estudo inadequado (n = 1)<br>Estudos incluidos nesta revisao<br>(n=1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada Risk of bias (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa pós intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Um estudo avaliou a efetividade e segurança da azatioprina no tratamento de indivíduos com ES<sup>12</sup> . Neste ECR aberto, 60 pacientes foram randomizados para receber azatioprina ou ciclofosfamida. Os resultados deste estudo demonstraram que a azatioprina parece ser inferior à ciclofosfamida para redução da função pulmonar conforme avaliado pela CVF (porcentagem do valor predito) (DM -14,4; IC 95% 13,96 a -14,84) e capacidade de difusão de monóxido de carbono (DLCO) (DM -11,6; IC 95% 10,86 a -12,34). Quanto à segurança dos medicamentos, não houve diferença entre os grupos quanto à incidência de eventos adversos graves (nenhum evento adverso grave que ameaçasse a vida ou fosse irreversível foi observado em nenhum dos grupos).  
O risco de viés geral do estudo foi julgado como alto. Foi considerado haver algumas preocupações quanto ao risco de viés devido aos desvios das intervenções pretendidas e quanto à seleção dos resultados relatados e alto risco de viés no processo de randomização. A avaliação completa do risco de viés deste estudo é apresentada na **Figura 6** .  
**Figura 6** - Risco de viés do estudo incluído avaliando o uso da azatioprina comparada a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES  
<!-- Start of picture text -->
Estudo Desfecho Dl p28 gS Geral<br>Nadashkevich 2005 Fungo pulmonar @ ! e e ! e@ e Baixo risco<br>Nadashkevich 2005 Eventos adversos @ »>ee@ e@ ! ‘Algumas preocupacées<br>e@ Alto risco<br>D1 Processo de randomizag3o<br>D2 Desvios das intervengSes pretendidas<br>D3 Dados perdidos do desfecho<br>D4 Mensurag3o do desfecho<br>DS SelecSo do resultado relatado<br><!-- End of picture text -->  
O **Quadro I** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para principais desfechos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT  
publicado por meio da Portaria Conjunta SAS-SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de exclusão</u> -->
- Imunossupressão (AIDS, linfoma e outros);  
- Infecção ativa;  
- Tuberculose;  
- Gestação ou lactação;  
- Neoplasia maligna em atividade;  
- Hipersensibilidade ao medicamento ou aos componentes da fórmula.  
**Quadro I -** Azatioprina comparado à ciclofosfamida para o tratamento da ES  
|||**Avalia**|**ção da certeza**|**da evidência**|||**№ de**|**pacientes**||**Efeito**|**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Azatioprina**|**Ciclofosfamida**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(IC 95%)**|**da**<br>**evidência**|
|**Capacida**<br>1<br>**Capacida**|**de Vital Forçad**<br>ECR<br>**de de difusão de**|**a (seguim**<br>**grave**<sup>**a**</sup><br>**monóxid**|**ento: 18 meses)**<sup>1</sup><br>não grave<br>**o de carbono (se**|<sup>2</sup><br>não grave<br>**guimento: 18**|**grave**<sup>**,b**</sup><br>**meses)**<sup>12</sup>|nenhum|30|30|-|DM 14,4<br>menor<br>(13,96 menor<br>ao 14,84<br>menor)|⨁⨁◯◯<br>Baixa|
|1<br>**Eventos a**|ECR<br>**dversos graves (**|**grave**<sup>**a**</sup><br>**seguimen**|não grave<br>**to: 18 meses)**<sup>12</sup>|não grave|**grave**<sup>**b**</sup>|nenhum|30|30|-|DM 11,6 menor<br>(10,86 menor a<br>12,34 menor)|⨁⨁◯◯<br>Baixa|
|1|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**muito**<br>**grave**<sup>**c**</sup>|nenhum|0/30 (0%)|0/30 (0%)|Nenhum ev<br>grave (que<br>ou fosse irr<br>observado|ento adverso<br>ameaçasse a vida<br>eversível) foi<br>nos grupos.|⨁◯◯◯<br>Muito<br>baixa|

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Eventos adversos graves (seguimento: 18 meses)**<sup>12</sup> -->
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; ECR: Ensaio clínico randomizado</mark>  
**<mark>Explicações:</mark>** <mark>a. Diminuído um nível devido à presença de limitações metodológicas (um estudo com alto risco de viés geral - alto risco de viés no processo de randomização, algumas preocupações quanto à desvios das intervenções pretendidas e seleção do</mark>  
<mark>resultado relatado); b. Diminuído um nível devido à presença de tamanho amostral reduzido; c. Diminuído dois níveis devido devido à</mark> presença de somente um estudo, com reduzido tamanho amostral e ausência de desfechos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Eventos adversos graves (seguimento: 18 meses)**<sup>12</sup> -->
12. Nadashkevich O, Davis P, Fritzler M, Kovalenko W. A randomized unblinded trial of cyclophosphamide versus azathioprine in the treatment of systemic sclerosis. Clin Rheumatol. 2006 Mar;25(2):205-12. doi: 10.1007/s10067-005-1157-y. Epub 2005 Oct 14. PMID: 16228107  
**QUESTÃO 4.** Deve-se usar micofenolato no tratamento das manifestações pulmonares nos pacientes com Esclerose Sistêmica?  
Por não haver indicação em bula aprovada pela Anvisa para a utilização do micofenolato no tratamento das manifestações pulmonares da ES, este medicamento não é recomendado neste PCDT. No entanto, por se tratar de uma dúvida clínica, a síntese e a avaliação crítica das evidências desta tecnologia foram realizadas.  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica **Intervenção:** Micofenolato  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; sobrevida.  
**Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR comparando o rituximabe a outros fármacos ou placebo no tratamento das manifestações pulmonares em pacientes como ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro J** .  
**Quadro J -** Estratégias de busca para identificação de estudos sobre o uso do micofenolato em pacientes com ES  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE via<br>Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Mycophenolic Acid"[Mesh] OR Mycophenolate Mofetil OR<br>Mycophenolic Acid Morpholinoethyl OR Ester OR Cellcept OR Mycophenolate<br>Sodium OR Myfortic OR Mycophenolate Mofetil Hydrochloride<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR|181|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab]<br>OR quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab]<br>OR der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal]<br>OR "Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 #1AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia<br>OR 'skin sclerosis'<br>#2 'mycophenolate mofetil'/exp OR 'cell cept' OR cellcept OR cellmune OR cellsept<br>OR munoloc OR myclausen OR 'mycophenolate mofetil hydrochloride' OR<br>'mycophenolic acid 2 morpholinoethyl ester' OR 'mycophenolic acid mofetil' OR<br>myfenax<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR<br>crossover* OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR<br>singl* NEAR/1 blind* OR assign* OR allocat* OR volunteer*):de,ab,ti|175|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti<br>OR metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3<br>(literature* OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti)<br>OR ((data NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR<br>medlars:ab,ti OR embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti<br>OR psycinfo:ab,ti OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti<br>OR cochrane:ab,ti OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR<br>manual OR database* OR computer*) NEAR/2 search*):ab,ti OR (electronic<br>NEAR/2 (database* OR 'data base' OR 'data bases')):ab,ti OR bibliograph*:ab OR<br>'relevant journals':ab OR ((review* OR overview*) NEAR/10 (systematic* OR<br>methodologic* OR quantitativ* OR research* OR literature* OR studies OR trial*<br>OR effective*)):ab NOT (((retrospective* OR record* OR case* OR patient*)<br>NEAR/2 review*):ab,ti OR ((patient* OR review*) NEAR/2 chart*):ab,ti OR rat:ab,ti<br>OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR hamster:ab,ti OR hamsters:ab,ti OR<br>animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR dogs:ab,ti OR cat:ab,ti OR cats:ab,ti<br>OR bovine:ab,ti OR sheep:ab,ti) NOT ('editorial'/exp OR 'erratum'/de OR 'letter'/exp)<br>NOT ('animal'/exp OR 'nonhuman'/exp NOT ('animal'/exp OR 'nonhuman'/exp AND<br>'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7 #6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 #1 #OR #2 OR #3<br>#5 MeSH descriptor: [Mycophenolic Acid] explode all trees<br>#6 Mycophenolate, Sodium OR Sodium Mycophenolate OR Mycophenolate Sodium<br>OR Mofetil, Mycophenolate OR Mycophenolate Mofetil OR Mycophenolic Acid<br>Morpholinoethyl Ester OR Mycophenolate Mofetil Hydrochloride OR Mofetil<br>Hydrochloride, Mycophenolate OR Cellcept<br>#7  #5 OR #6<br>#8 #7 AND #4|86|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Lilacs via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh: "Ácido Micofenólico" OR (Mycophenolic Acid) OR (Ácido Micofenólico) OR<br>(Acide mycophénolique) OR (Micofenolato de Mofetil) OR<br>mh:D02.241.081.193.678$ OR mh:D10.251.618$|2|
||Filter: Lilacs||
|Epistemonikos|(title:((Systemic Scleroderma)) OR abstract:((Systemic Scleroderma))) AND<br>(title:((Mycophenolic Acid)) OR abstract:((Mycophenolic Acid)))|1|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipo de intervenção  
Micofenolato em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram considerados ECRs.  
- (d) Desfechos de eficácia: função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada  
arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; sobrevida. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 445 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 3 textos completos. Um estudo foi  
excluído por não se tratar de um ECR<sup>13</sup> . Para auxiliar na tomada de decisão, 2 estudos foram incluídos<sup>14,15</sup> . O processo de seleção é detalhado na **Figura 7** .  
**Figura 7** - Fluxograma de seleção dos estudos <mark>avaliando o</mark> uso do micofenolato comparado a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES.  
<!-- Start of picture text -->
brine ident Referéncias removidas antes do<br>Referéncias identificadas por rastreamento:<br>meio de busca nas bases de Referéncias duplicadas<br>dados (n = 445) removidas (n = 59)<br>Referéncias rastreadas (n = 386) Referéncias excluidas (n = 383)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 3) ——_> Estudo com desenho de<br>estudo inadequado (n = 1)<br>Estudos incluidos nesta revisao<br>(n=2)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada Risk of bias (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio da mediana da mudança e amplitudes e da mudança média e IC95% dos grupos. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Dois estudos avaliaram a eficácia e segurança do micofenolato no tratamento de manifestações pulmonares em indivíduos com ES<sup>14,15</sup> . Entretanto, devido à presença de diferentes intervenções no grupo comparador, não foi possível agrupar os resultados em metanálises e, por esse motivo, os resultados foram apresentados de forma descritiva.  
Naidu et al. (2019)<sup>15</sup> realizaram um ECR piloto duplo-cego e controlado por PBO. Quarenta e dois participantes com doença pulmonar intersticial (DP)I associada à ES foram randomizados para receber micofenolato ou PBO por 6 meses. A função pulmonar, avaliada pela CVF aos 6 meses (porcentagem do valor predito), não apresentou diferença entre os grupos micofenolato e PBO [mediana = -2,7 (amplitude: -21 a 9,0) vs mediana = 1 (amplitude: -6,0 a 10), respectivamente; p = 0,339)]. A capacidade de difusão do monóxido de carbono, avaliada aos 6 meses também não apresentou diferença entre os grupos micofenolato e PBO  
[mediana 1,0 (amplitude -20 a 35,0) vs mediana 1,5 (amplitude: -19,0 a 22, respectivamente; p = 0,412)]. A capacidade funcional avaliada aos 6 meses também não apresentou diferença entre os grupos micofenolato e placebo [mediana = 0,0 (amplitude -113 a 240,0) vs mediada 0 (amplitude -180 a 170); respectivamente; p = 0,522)]. A qualidade de vida foi avaliada com SF-36 (p = 0,358), também não havendo diferença entre os grupos. Igualmente, não houve diferença entre os grupos quanto ao risco de pneumonia (RR 5,24; IC 95% 0,27 a 102,81) ou eventos adversos graves (RR 3,14; IC 95% 0,14 a 72,92).  
Tashkin et al. (2016)<sup>14</sup> randomizaram 142 pacientes com DPI associada à ES para receber micofenolato (dose-alvo de 1.500 mg duas vezes ao dia) ou ciclofosfamida oral (dose-alvo 2, 0 mg/kg/dia) por 12 meses. Não houve diferença entre os grupos micofenolato e ciclofosfamida nas avaliações realizadas após 24 meses quanto à função pulmonar, avaliada pela CVF (porcentagem do valor predito) (DM 0,7; IC95% -1,7 a 3,1) ou capacidade de difusão do monóxido de carbono (porcentagem do valor predito) (DM -1,74; IC 95% -5,1 a 1,6)<sup>14</sup> . Também não houve diferença entre os grupos com relação ao número de participantes que melhorou a capacidade funcional, medida pelo HAQ (RR 0,79; IC 95% 0,44 a 1,42), qualidade de vida avaliada pelo SF-36 (RR 0,95; IC 95% 0,54 a 1,67), risco de pneumonia (RR 1,32 **;** IC 95% 0,37 a 4,72) ou eventos adversos graves (RR 1,30 **;** IC 95% 0,82 a 2,05). Entretanto, o risco de leucopenia foi menor no grupo micofenolato (RR 0,14 **;** IC 95% 0,05 a 0,38)<sup>14</sup> .  
O risco de viés geral do estudo de Tashkin et al. (2016)<sup>14</sup> foi julgado como alto, enquanto o de Naidu et al. (2019)<sup>15</sup> , como baixo. No estudo de Tashkin et al. (2016)<sup>14</sup> , foi considerado haver algumas preocupações quanto ao processo de randomização e alto risco de viés devido a dados perdidos dos desfechos. A avaliação completa do risco de viés deste estudo é apresentada na **Figura 8** .  
**Figura 8** - Risco de viés dos estudos <mark>incluídos avaliando</mark> o uso do micofenolato comparado a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES  
<!-- Start of picture text -->
fstudo —_Deslerho DL pz D8 Dh Geral] sitosisco<br>Tashkin 2016 Fungo pulmonar ! @ @ t ) ) @ ! ‘Algumas preocupacdes<br>Tastkn 2016 —Capacidede funcional ,@@ ) @@ @ vic<br>Tashkin 2016 Qualidade<br>de vida ! @ @ ) @ r<br>Tashkin 2016 Eventos adversos ! t @ @ @ ) OL Processode randomizaco<br>Naidu 2019 Fungo pulmonar )  ) @ @ @ @ 02 Desvios das intervengdes pretendidas<br>Naidu 2019 Qualidade<br>de vida - Dominio fisico e ) ) ) ) @ D3. Dados perdidosdo desfecho<br>Naidu 2019 Eventos adversos 6 @ ) ) ) @ be Mensuraco do desfecho<br>Ds Selego do resultado relatado<br><!-- End of picture text -->  
O **Quadro K** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.  
**Quadro K -** Micofenolato comparado a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES  
|||**Avali**|**ação da certeza**|**da evidência**|||**Efeito**<br>**(Micofenolato versus outros fármacos ou placebo)**|**Certeza da**<br>**evidência**|
|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**<br>**Função p**<br>|**Delineamento**<br>**do estudo**<br>**ulmonar - CVF**(a<br>|**Risco**<br>**de viés**<br>valiado e<br>|**Inconsistência**<br>m**6 meses a 24**<br>|<br>**Evidência**<br>**indireta**<br>**meses)**% do p<br>|**Imprecisão**<br>redito <sup>14,15</sup><br>|**Outras**<br>**considerações**<br>|<br>||
|2<br>**Função p**|ECR<br>**ulmonar - DLCO**|**grave**<sup>**a**</sup><br> (avaliado|não grave<br>em**6 meses)**%|não grave<br>do predito <sup>15</sup>|**grave**<sup>**b**</sup><br>|nenhum|**Micofenolato versus Placebo**<br>No grupo micofenolato a mediana da mudança (amplitude)<br>foi de -2,7 (-21 a 9,0);  No grupo placebo a mediana da<br>mudança (amplitude) foi de 1 (-6,0 a 10, p = 0,339); 41<br>participantes; 20 participantes no grupo micofenolato e 21<br>participantes no grupo placebo; 1 estudo<sup>15</sup><br>**Micofenolato versus ciclofosfamida**<br>(DM 0,7; IC95% -1,7 a 3,1); 100 participantes; 52<br>participantes no grupo micofenolato e 48 participantes no<br>grupo cilofosfamida; 1 estudo<sup>14</sup>|⨁⨁◯◯<br>Baixa<br>|
|2|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**grave**<sup>**b**</sup>|nenhum|**Micofenolato versus Placebo**<br>No grupo micofenolato a mediana da mudança (amplitude)<br>foi de 1,0 (-20 a 35,0); no grupo placebo a mediana da<br>mudança (amplitude) foi de 1,5 (-19,0 a 22) (p = 0,412) 41<br>participantes; 20 participantes no grupo micofenolato e 21<br>participantes no grupo placebo; 1 estudo<sup>15</sup>|⨁⨁◯◯<br>Baixa|  
**Função pulmonar - CVF** (avaliado em **6 meses a 24 meses)** % do predito<sup>14,15</sup>

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Função pulmonar - DLCO** (avaliado em **6 meses)** % do predito<sup>15</sup> -->
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Micofenolato versus outros fármacos ou placebo)  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>estudos  do estudo  de viés  indireta  considerações<br>Micofenolato versus ciclofosfamida<br>(DM -1,74; IC 95% -5,1 a 1,6; 100 participantes; 52<br>participantes no grupo micofenolato e 48 participantes no<br>grupo cilofosfamida; 1 estudo 14<br>Capacidade funcional  (avaliado em  6 meses)  TC6min 15 e HAQ  14<br>2  ECR  grave a não grave  não grave  grave b nenhum  Micofenolato versus Placebo  ⨁⨁◯◯<br>No grupo micofenolato a mediana da mudança (amplitude)  Baixa<br>foi de 0,0 (-113 a 240,0); no grupo placebo a mediana da<br>mudança (amplitude) foi de 0 (-180 a 170); p = 0,522; 41<br>participantes; 20 participantes no grupo micofenolato e 21<br>participantes no grupo placebo; 1 estudo 15<br>Micofenolato versus ciclofosfamida<br>Micofenolato 15/69 (21.7%)<br>Ciclofosfamida 20/73 (27.4%)<br>RR 0,79 (IC 95% 0,44 a 1,42)<br>[58 menos por 1000 (de 153 menos a 115 mais)]; 1<br>estudo 14<br>Qualidade de vida - Domínio físico  (avaliado em  6 meses)  SF-36  14,15<br><!-- End of picture text -->  
|**№ de**<br>**estudos**|**Delineamento**<br>**do estudo**|**Avali**<br>**Risco**<br>**de viés**|**ação da certeza d**<br>**Inconsistência**|**a evidência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Efeito**<br>**(Micofenolato versus outros fármacos ou placebo)**|**Certeza da**<br>**evidência**|
|---|---|---|---|---|---|---|---|---|
|2<br>**Eventos a**|ECR<br>**dversos**(avaliado|**grave**<sup>**a**</sup><br>em**24 me**|não grave<br>**ses)**Leucopenia|não grave<br><sup>14</sup>|**grave**<sup>**b**</sup>|nenhum<br>|**Micofenolato versus Placebo**<br>No grupo micofenolato a mediana da mudança (amplitude)<br>foi de 7,0 (-1,2 a 14,3); no grupo placebo a mediana da<br>mudança (amplitude) foi de 5 (-7,5 a 20,8; p = 0,358; 41<br>participantes; 20 participantes no grupo micofenolato e 21<br>participantes no grupo placebo; 1 estudo<sup>15</sup><br>**Micofenolato versus ciclofosfamida**<br>Micofenolato 17/69 (24.6%)<br>Ciclofosfamida 19/73 (26.0%)<br>RR 0,95 (0,54 a 1,67)<br>13 menos por 1000<br>(de 120 menos a 174 mais); 1 estudo<sup>14</sup>|⨁⨁◯◯<br>Baixa<br>|
|1|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**grave**<sup>**c**</sup>|nenhum|**Micofenolato versus ciclofosfamida**<br>Micofenolato 4/69 (5,8%)<br>Ciclofosfamida 30/73 (41,1%)<br>RR 0,14 (0,05 a 0,38)<br>353 menos por 1000<br>(de 390 menos a 255 menos); 1 estudo<sup>14</sup>|⨁⨁◯◯<br>Baixa|  
**Eventos adversos** (avaliado em **6 meses a 24 meses)** Pneumonia<sup>14,15</sup>  
|||**Avali**|**ação da certeza d**|**a evidência**|||**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**(Micofenolato versus outros fármacos ou placebo)**|**evidência**|
|2|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**Muito**<br>**grave**<sup>**d**</sup>|nenhum|**Micofenolato versus Placebo**<br>Micofenolato 2/20<br>Placebo 0/21<br>RR 5,24 (0,27 a 102,81); 1 estudo<sup>15</sup><br>**Micofenolato versus ciclofosfamida**<br>Micofenolato 5/69 (7,25%)<br>Ciclofosfamida 4/73 (5,48%)<br>RR 1,32 (0,37 a 4,72)<br>18 mais por 1000<br>(de 35 menos a 204 mais); 1 estudo<sup>14</sup>|⨁◯◯◯<br>Muito baixa|

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Eventos adversos graves** (avaliado em **6 meses a 24 meses)**<sup>14,15</sup> -->
|2<br>ECR|**grave**<sup>**a**</sup>|não grave|não grave|**Muito**<br>**grave**<sup>**d**</sup>|nenhum|**Micofenolato**<br>**versus**<br>Micofenolato 1/20<br>Placebo 0/21<br>RR 3,14 (0,14 a 72,92); 1 estudo<sup>15</sup><br>**Micofenolato versus Ciclofosfamida**<br>Micofenolato 27/69 (39,1%)<br>Ciclofosfamida 22/73 (30,1%)<br>RR 1,30 (0,82 a 2,05)<br>90 mais por 1000|**Placebo**|⨁◯◯◯<br>Muito baixa|
|---|---|---|---|---|---|---|---|---|  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Micofenolato versus outros fármacos ou placebo)  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>estudos  do estudo  de viés  indireta  considerações<br>(de 51 menos a 316 mais); 1 estudo 14<br><!-- End of picture text -->  
ECR: Ensaio clínico randomizado; DM: Diferença média; RR: Risco relativo; IC: Intervalo de Confiança; CVF: Capacidade vital forçada; DLCO: capacidade de difusão do monóxido de carbono; HAQ-DI: Health Assessment Questionnaire-Disability Index;  
a Diminuído um nível devido a importante limitação metodológica (1 estudo com alto risco de viés geral - algumas preocupações quanto ao processo de randomização e alto risco de viés devido a dados faltantes do desfecho) b Diminuído um nível devido à presença de reduzido tamanho amostral  
c Diminuído um nível devido à presença de poucos eventos  
d Diminuído dois níveis devido à presença de poucos eventos e IC amplo

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Eventos adversos graves** (avaliado em **6 meses a 24 meses)**<sup>14,15</sup> -->
<mark>14. Tashkin DP, Roth MD, Clements PJ, Furst DE, Khanna D, Kleerup EC, Goldin J, Arriola E, Volkmann ER, Kafaja S, Silver R, Steen V, Strange C, Wise R, Wigley F, Mayes M, Riley DJ, Hussain S, Assassi S, Hsu VM, Patel B, Phillips K, Martinez F, Golden J, Connolly MK, Varga J, Dematte J, Hinchcliff ME, Fischer A, Swigris J, Meehan R, Theodore A, Simms R, Volkov S, Schraufnagel DE, Scholand MB, Frech T, Molitor JA, Highland K, Read CA, Fritzler MJ, Kim GHJ, Tseng CH, Elashoff RM; Sclerodema Lung Study II Investigators. Mycophenolate mofetil versus oral cyclophosphamide in scleroderma-related interstitial lung disease (SLS II): a randomised controlled, doubleblind, parallel group trial. Lancet Respir Med. 2016 Sep;4(9):708-719. doi: 10.1016/S2213-2600(16)30152-7. Epub 2016 Jul 25. PMID: 27469583; PMCID: PMC5014629.</mark>  
<mark>15. Naidu GSRSNK, Sharma SK, Adarsh MB, Dhir V, Sinha A, Dhooria S, Jain S. Effect of mycophenolate mofetil (MMF) on systemic sclerosis-related interstitial lung disease with mildly impaired lung function: a doubleblind, placebo-controlled, randomized trial. Rheumatol Int. 2020 Feb;40(2):207-216. doi: 10.1007/s00296-019-04481-8. Epub 2019 Dec 7. PMID: 31813058.</mark>  
**QUESTÃO 5.** Deve-se usar ciclofosfamida em pacientes com Esclerose Sistêmica para tratamento de Doença Pulmonar Intersticial concomitante ou manifestações cutâneas graves?  
A questão sobre ciclofosfamida prevista no documento de escopo contemplava tanto as manifestações para tratamento da doença pulmonar intersticial concomitante quanto as manifestações cutâneas graves. Para responder essa questão, as evidências foram subdivididas em duas questões organizadas de acordo com o tipo de manifestação.  
**QUESTÃO 5.1.** Deve-se usar ciclofosfamida em pacientes com Esclerose Sistêmica para tratamento de Doença Pulmonar Intersticial concomitante?  
**<u>Recomendação:</u>** <mark>Sugerimos usar ciclofosfamida em pacientes com ES com doença pulmonar intersticial concomitante à atividade (recomendação condicional, certeza da evidência baixa).</mark>  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica  
**Intervenção:** Ciclofosfamida  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; sobrevida.  
**Desfechos de segurança** : eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR comparando ciclofosfamida a outros fármacos ou placebo para o tratamento da doença pulmonar intersticial (DPI) concomitante em pacientes com ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro L** .  
**Quadro L -** Estratégias de busca para identificação de estudos sobre o uso da ciclofosfamida em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*|576|
||#2 "Cyclophosphamide"[Mesh] OR Sendoxan OR Cyclophosphamide Anhydrous OR<br>Cyclophosphamide,<br>(R)-Isomer<br>OR<br>Cyclophosphamide,<br>(S)-Isomer<br>OR<br>Cytophosphane OR Cyclophosphamide Monohydrate OR Cytophosphan OR Cytoxan<br>OR Endoxan OR Neosar OR Procytox OR cyclophosphane<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met||  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 #1AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'cyclophosphamide'/exp OR cyclophosphamid* ORalkyroxan OR carloxan OR<br>ciclofosfamida OR ciclolen OR cicloxal OR clafen OR cyclo-cell OR cycloblastin OR<br>cycloblastine OR 'cyclofos amide' OR cyclofosfamid OR cyclofosfamide OR<br>cyclophar OR cyclophosphan OR cyclophosphane OR cyclostin OR cycloxan OR<br>cyphos OR cytophosphan OR cytophosphane OR cytoxan OR 'endocyclo phosphate'|334|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR endoxan OR endoxan-asta OR endoxana OR endoxon-asta OR enduxan OR<br>genoxal OR ledoxan OR ledoxina OR 'lyophilized cytoxan'OR mitoxan OR neosan<br>OR neosar OR noristan OR procytox OR procytoxide OR semdoxan OR sendoxan OR<br>syklofosfamid<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7#6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor: [Cyclophosphamide] explode all trees|53|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#5 Sendoxan OR Cytophosphane OR Cytophosphan OR Cytoxan OR Endoxan OR<br>Neosar OR Procytox OR Cyclophosphane<br>#6 #1 OR #2 OR #3<br>#7 #4 OR #5<br>#8 #6 AND #7||
|Lilacs<br>via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:Cyclophosphamide<br>OR<br>mh:D02.455.526.728.650.730.243$ OR<br>mh:D02.705.672.500.243$ ORSendoxan OR Cytophosphane OR Cytophosphan OR<br>Cytoxan OR Endoxan OR Neosar OR Procytox OR Cyclophosphane<br>Filter: Lilacs|10|
|Epistemonik<br>os|(title:((Systemic Scleroderma) AND Cyclophosphamide) OR abstract:((Systemic<br>Scleroderma) AND Cyclophosphamide))|11|  
Dois avaliadores independentes realizaram a seleção dos estudos e extração de dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
(a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipo de intervenção  
Ciclofosfamida em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
(c) Tipos de estudos  
Foram considerados ECRs.  
(d) Desfechos: Função pulmonar [ex: capacidade vital forçada (CVF) volume expiratório forçado no primeiro segundo (VEF1), capacidade de difusão de CO]; capacidade funcional (ex: distância percorrida em 6 minutos); resistência vascular pulmonar; pressão arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliada por questionários validados (ex: _Scleroderma-Health Assessment Questionnaire_ (S-HAQ)); mortalidade; sobrevida;  eventos adversos graves; eventos adversos gerais.  
(e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 984 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 3 textos completos. Um estudo foi excluído por não se tratar da intervenção adequada<sup>16</sup> . Para auxiliar na tomada de decisão, 2 estudos foram incluídos<sup>12,17</sup> . O processo de seleção é detalhado na **Figura 9** .  
**Figura 9** - Fluxograma de seleção dos estudos <mark>avaliando o</mark> uso da ciclofosfamida comparada a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES.  
<!-- Start of picture text -->
Referéncias identificadas por Referencias removidas antes do<br>meio “Galen noe de Referéncias duplicadas<br>~ removidas (n = 105)<br>Referéncias rastreadas (n = 879) Referéncias excluidas (n = 876)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 3) > Estudo com intervencao<br>inadequada (n = 1)<br>Estudos incluidos nesta revisao<br>(n=2)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada Risk of bias (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa da mudança pós-pré intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Dois ECR avaliaram a eficácia e segurança da ciclofosfamida no tratamento da DPI concomitante em indivíduos com ES. Entretanto, devido à presença de diferentes intervenções no grupo comparador, não foi possível agrupar os resultados em metanálises e, por esse motivo, os resultados foram apresentados de forma descritiva.  
Um ECR comparou o efeito da ciclofosfamida versus PBO em 162 pacientes com ES e DPI<sup>17</sup> . Após um ano de tratamento com ciclofosfamida oral, houve um efeito benéfico na função pulmonar, avaliada pela CVF, medida pela porcentagem do valor predito (DM 2,53; IC95% 0,28 a 4,79) e capacidade pulmonar total (DM 4,09; IC95% 0,49 a 7,65); incapacidade funcional, avaliado pelo HAQ (DM -0,16; IC95% -0,28 a -0,04; e qualidade de vida relacionada à saúde destes pacientes avaliada pelo SF-  
36 (DM 7,99; IC95% 2,18 a 13,8). Não houve diferença quanto à capacidade de difusão do monóxido de carbono (DM -0,7; IC95% -3,68 a 2,28), mortalidade (RR 0,66; IC95% 0,11 a 3,82), risco de infecção pulmonar (RR 4,93; IC95% 0,59 a 41,18) ou eventos adversos graves (RR 4,93; IC95% 0,24 a 100,98). Entretanto, houve maior risco de leucopenia (RR 38,47; IC95% 2,37 a 625,40). Nadashkevich et al. (2006)<sup>12</sup> compararam os efeitos da ciclofosfamida à azatioprina em 60 pacientes com ES. Os resultados deste estudo indicaram que a ciclofosfamida leva a um menor declínio da função pulmonar, conforme avaliada pela CVF (% do valor predito), em 18 meses (DM 14,4; IC95% 13,96 a 14,84) e maior capacidade de difusão do monóxido de carbono (DM 11,6; IC95% 10,86 a 12,34). Em nenhum dos grupos (ciclofosfamida ou azatioprina) houve eventos adversos graves (que ameaçassem a vida ou fossem irreversíveis).  
O risco de viés geral de ambos os estudos foi julgado como alto. No estudo de Nadashkevich et al. (2006)<sup>12</sup> , foi considerado haver algumas preocupações quanto ao risco de viés devido a desvio das intervenções pretendidas e seleção do resultado relatado e alto risco de viés no processo de randomização. No estudo de Tashkin et al. (2006)<sup>17</sup> , foi julgado haver algumas preocupações quanto à seleção dos resultados relatados e alto risco de viés devido a desvios das intervenções pretendidas e dados perdidos dos desfechos. A avaliação completa do risco de viés destes estudos é apresentada na **Figura 10** .  
**Figura 10** - Risco de viés dos estudos <mark>incluídos avaliando</mark> o uso da ciclofosfamida comparada a outros fármacos ou placebo para o tratamento de manifestações pulmonares na ES  
<!-- Start of picture text -->
fstudo Desfecho DL p28 Dk OOS Gerd<br>Nadashkevich 2005 Fungo pulmonar @° @@ @ @ iors<br>Nadashkevich 2005 Eventos adversos @* @@& @ 1) Algumas preocupagbes<br>Tashkin 2006 Fungo pulmonar @@@@ i @ @  rovric<br>Tashkin 2006 Inapacdatetnionl «6 @ @ @ & @<br>Tashkin 2006 Cualdade de vida @@@@ i @ ml Processode endomlzSo<br>Tashkin 2006 Mortalidade @@@@ @ D2 Desvos das intervenes petendidas<br>Tashkin 2006 Eventos adversos @@@@ i @ 08 Datos perdidosdo desfecho<br>be MensuragSo do destecho<br>DS Selecdo do resultado relatado<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que a ciclofosfamida já é um medicamento disponível no SUS e apresenta evidências de efetividade e segurança quando utilizada em pacientes com DPI associada à ES.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização da ciclofosfamida é indicada em pacientes com ES, com os critérios clínicos de elegibilidade que serão descritos a seguir:

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de inclusão</u> -->
- Pacientes que preencherem os critérios do EULAR/EUSTAR de 2013 ou ou os critérios de LeRoy e Medsger para doença inicial e que possuírem DPI associada à ES.  
<u>Critério de exclusão</u>  
Qualquer um dos critérios abaixo:  
- Hipersensibilidade à ciclofosfamida ou quaisquer excipientes da fórmula  
- Cistite e obstrução das vias urinárias  
- Concepção, gestação ou lactação  
- Infecção ativa  
- Imunossupressão  
- Neoplasia maligna  
- Insuficiência cardíaca grave não controlada  
Nota: A estratégia terapêutica deve ser definida de acordo com o acometimento visceral predominante, considerando as  
evidências de atividade de doença e seguindo as recomendações deste PCDT.  
Para o monitoramento dos pacientes, os especialistas sugerem que devem ser solicitados:  
- Hemograma com contagem de plaquetas  
- Exame comum de urina com microscopia 14 dias após cada infusão e, após isso, conforme a necessidade.  
- Para prevenir cistite hemorrágica, recomenda-se a administração de mesna por via intravenosa ou oral (1 mg para cada 1 mg de ciclofosfamida) dividida em três vezes.  
- Sugere-se considerar a utilização do _sulfametoxazol_ + _trimetoprima_ , especialmente em pacientes que estiverem utilizando ciclofosfamida e prednisona com dose maior ou igual a 20 mg e em pacientes acima de 60 anos.  
- Sugere-se ajustar dose ou considerar o não uso em pacientes com creatinina sérica maior ou igual 2 mg/dL ou clearance igual ou menor a 30.  
- Sugere-se monitorar o aparecimento de hematúria persistente e inexplicada.  
- Sugere-se considerar o não uso do medicamento em pacientes com leucopenia (menor ou igual 3.000/mm<sup>3</sup> ).

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Perfil de evidências:** -->
O **Quadro M** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos. O perfil de evidências conforme o sistema GRADE referente ao uso das tecnologias foi avaliado por dois pesquisadores.  
**Quadro M -** Ciclofosfamida comparada a outros fármacos ou placebo para o tratamento da doença pulmonar intersticial concomitante na ES  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Ciclofosfamida versus outros fármacos ou  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>placebo)<br>estudos  do estudo  de viés  indireta  considerações<br>Capacidade vital forçada  (seguimento:  12 meses  17 a  18 meses 12 ; avaliado com:  % do predito)<br>2  ECR  grave a  não grave  não grave  grave b  nenhum  Ciclofosfamida versus Placebo  ⨁⨁◯◯<br>DM  2,53 maior  (0,28 maior a 4,79 maior);   Baixa<br>145 participantes; 73 no grupo ciclofosfamida; 72<br>no grupo placebo; 1 estudo  17<br>Ciclofosfamida versus azatioprina<br>DM  14,4 maior  (13,96 maior a 14,84 maior);<br>60 participantes; 10 no grupo ciclofosfamida; 30<br>no grupo azatioprina; 1 estudo  12<br>Capacidade pulmonar total  (seguimento:  12 meses  17  avaliado com:  % do predito)<br>1  ECR  grave c  não grave  não grave  grave b  nenhum  Ciclofosfamida versus Placebo ⨁⨁◯◯<br>DM  4,09 maior  (0,49 maior a 7,65 maior);  Baixa<br>145 participantes; 73 no grupo ciclofosfamida; 72<br>no grupo placebo; 1 estudo  17<br>Capacidade de difusão do CO  (seguimento:  12 meses  17 a  18 meses 12 ; avaliado com:  % do predito)<br><!-- End of picture text -->  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Ciclofosfamida versus outros fármacos ou  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>placebo)<br>estudos  do estudo  de viés  indireta  considerações<br>2  ECR  grave a  não grave  não grave  grave b  nenhum  Ciclofosfamida versus Placebo  ⨁⨁◯◯<br>DM 0,7 menor (3,68 menor a 2,28 maior);  Baixa<br>145 participantes; 73 no grupo ciclofosfamida; 72<br>no grupo placebo; 1 estudo  17<br>Ciclofosfamida versus azatioprina<br>DM  11,6 maior  (10,86 maior a 12,34 maior);<br>60 participantes; 10 no grupo ciclofosfamida; 30<br>no grupo azatioprina; 1 estudo  12<br>Incapacidade funcional  (seguimento:  12 meses  17 ; avaliado com:  HAQ disability  escore de 1 a 3 (quanto maior, pior)<br>1  ECR  grave c  não grave  não grave  grave b  nenhum  Ciclofosfamida versus Placebo  ⨁⨁◯◯<br>DM  0,16 menor  (0,28 menor a 0,04 menor);  Baixa<br>145 participantes; 73 no grupo ciclofosfamida; 72<br>no grupo placebo; 1 estudo  17<br>Qualidade de vida- vitalidade  (seguimento:  12 meses  17 ; avaliado com:  SF-36)<br>1  ECR  grave c  não grave  não grave  grave b  nenhum  Ciclofosfamida versus Placebo  ⨁⨁◯◯<br>DM  7,99 maior Baixa<br>(2,18 maior a 13,8 maior);<br> 145 participantes; 73 no grupo ciclofosfamida; 72<br>no grupo placebo; 1 estudo  17<br><!-- End of picture text -->  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Ciclofosfamida versus outros fármacos ou  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>placebo)<br>estudos  do estudo  de viés  indireta  considerações<br>Mortalidade  (seguimento:  12 meses  17<br>1  ECR  grave c  não grave  não grave  grave b  nenhum  Ciclofosfamida versus Placebo  ⨁⨁◯◯<br>Ciclofosfamida 2/73 (2,74%)  Baixa<br>Placebo 3/72 (4,2%)<br>RR 0,66 (0,11 a 3,82)<br>14 menos por 1,000<br>(37 menos a 118 mais); 145 participantes; 1 estudo<br>17<br>Eventos adversos -  (seguimento:  12 meses  17 ; avaliado com:  número de eventos de leucopenia<br>1  ECR  grave c  não grave  não grave  Muito  nenhum  Ciclofosfamida versus Placebo  ⨁◯◯◯<br>grave d Ciclofosfamida 19/73 (26,03%)  Muito Baixa<br>Placebo 0/72 (0%)<br>RR  38,47<br>(2,37 a 625,40)<br>145 participantes; 1 estudo  17<br>Eventos adversos -  (seguimento:  12 meses  17 avaliado com:  número de eventos de infecção pulmonar)<br>1  ECR  grave c  não grave  não grave  muito  nenhum  Ciclofosfamida versus Placebo  ⨁◯◯◯<br>grave d  Ciclofosfamida  5/73 (6,8%)  Muito Baixa<br>Placebo 1/72 (1,4%)<br>RR 4,93 (0,59 a 41,18)<br><!-- End of picture text -->  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Efeito  Certeza da<br>(Ciclofosfamida versus outros fármacos ou  evidência<br>№ de  Delineamento  Risco  Inconsistência  Evidência  Imprecisão  Outras<br>placebo)<br>estudos  do estudo  de viés  indireta  considerações<br>55 mais por 1,000<br>(de 6 menos a 558 mais)<br>145 participantes; 1 estudo  17<br>Eventos adversos graves  (seguimento:  12 meses  17  a  18 meses 12 ;avaliado com:  N de eventos )<br>2  ECR  grave a  não grave  não grave  muito  nenhum  Ciclofosfamida versus Placebo  ⨁◯◯◯<br>grave d Ciclofosfamida 2/73 (2,7%);  Muito Baixa<br>Placebo  0/72  (0,0%)<br>RR 4,93 (0,24 a 100,98)<br>145 participantes; 1 estudo  17<br>Ciclofosfamida versus Azatioprina<br>Ciclofosfamida 0/10; Azatioprina 0/30 eventos<br>adversos graves (que ameaçassem a vida ou<br>fossem irreversíveis; 40 participantes  12<br><!-- End of picture text -->  
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; RR: Risco Relativo; ECR: Ensaio clínico randomizado; SF-36: 36-item Short-form Survey</mark>  
<mark>a. Diminuído um nível devido à presença de limitações metodológicas (dois estudos com alto risco de viés geral - um estudo com alto risco para desvios das intervenções pretendidas e dados perdidos do desfecho e algumas</mark>  
<mark>preocupações quanto à seleção do resultado relatado (Tashkin 2006) e um estudo com alto risco de viés no processo de randomização e algumas preocupações quanto à desvios das intervenções pretendidas e seleção do resultado relatado</mark> (Nadashkevich 2006))  
<mark>b. Diminuído um nível devido ao reduzido tamanho amostral</mark>  
<mark>c. Diminuído um nível devido à presença de limitações metodológicas (um estudo com alto risco de viés geral - um estudo com alto risco para desvios das intervenções pretendidas e dados perdidos do desfecho e algumas preocupações quanto à seleção do resultado relatado (Tashkin 2006))</mark>  
<mark>d. Diminuído dois níveis devido à presença de poucos eventos e IC amplo</mark>

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Perfil de evidências:** -->
12. Nadashkevich O, Davis P, Fritzler M, Kovalenko W. A randomized unblinded trial of cyclophosphamide versus azathioprine in the treatment of systemic sclerosis. Clin Rheumatol. 2006 Mar;25(2):205-12. doi: 10.1007/s10067005-1157-y. Epub 2005 Oct 14. PMID: 16228107.  
17. Tashkin DP, Elashoff R, Clements PJ, Goldin J, Roth MD, Furst DE, Arriola E, Silver R, Strange C, Bolster M, Seibold JR, Riley DJ, Hsu VM, Varga J, Schraufnagel DE, Theodore A, Simms R, Wise R, Wigley F, White B, Steen V, Read C, Mayes M, Parsley E, Mubarak K, Connolly MK, Golden J, Olman M, Fessler B, Rothfield N, Metersky M; Scleroderma Lung Study Research Group. Cyclophosphamide versus placebo in scleroderma lung disease. N Engl J Med. 2006 Jun 22;354(25):2655-66. doi: 10.1056/NEJMoa055120. PMID: 16790698.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
O **Quadro N** apresenta o processo de tomada de decisão sobre o uso da ciclofosfamida em pacientes com ES e DPI concomitante, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Quadro N -** Processo de tomada de decisão referente ao uso de ciclofosfamida para tratamento da doença pulmonar intersticial concomitante em pacientes com ES.  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Efeitos desejáveis:|Pequeno|Ciclofosfamida versus Placebo (12 meses): melhora da CVF (porcentagem<br>do valor predito) da CPT (porcentagem do valor predito), da incapacidade<br>funcional (HAQ-DI) e da qualidade de vida (SF-36).<br>Ciclofosfamida versus Azatioprina (18 meses): melhora da CVF<br>(porcentagem do valor predito e da Capacidade de difusão do CO<br>(porcentagem do valor predito).|
|Efeitos indesejáveis|Pequeno|Ciclofosfamida versus Placebo (12 meses):<br>Eventos adversos: aumento do risco de eventos de leucopenia<br>Ciclofosfamida versus Azatioprina (18 meses):<br>Nenhum evento adverso grave em nenhum dos grupos|
|Balanço entre riscos<br>e benefícios:|Favorece a<br>intervenção|O grupo entende que o balanço é favorável à intervenção com uso a curto<br>prazo.|
|Certeza da evidência:|Baixa|Julgamento da certeza baseado no método GRADE|
|Recursos requeridos:|Negligenciáveis|Ciclofosfamida<br>(Frasco com 1.000mg para infusão):<br>Valor unitário de R$ 34,66 (1.000 mg)<br>15 mg/ kgmês (67 kilos): R$ 34,66 reais por mês (R$ 415,92 por ano de<br>tratamento)|
|Viabilidade de<br>implementação:|Sim|Tecnologia já disponível no SUS|
|Outras<br>considerações:|Não informado|Não foram reportadas outras considerações.|  
**QUESTÃO 5.2. Deve-se usar ciclofosfamida em pacientes com Esclerose Sistêmica para tratamento de manifestações cutâneas graves?**  
**<u>Recomendação:</u>** Sugerimos utilizar ciclofosfamida para o tratamento de manifestações cutâneas graves em pacientes com ES (recomendação não graduada).  
A estrutura PICO para esta pergunta foi: **População:** Pacientes com Esclerose Sistêmica **Intervenção:** Ciclofosfamida **Comparador:** Outros fármacos ou placebo **Desfechos de eficácia:** fibrose cutânea; dor. **Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para atualizar as evidências acerca da questão. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro O** .  
**Quadro O -** Estratégias de busca para identificação de estudos sobre o uso da ciclofosfamida em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Cyclophosphamide"[Mesh] OR Sendoxan OR Cyclophosphamide Anhydrous OR<br>Cyclophosphamide,<br>(R)-Isomer<br>OR<br>Cyclophosphamide,<br>(S)-Isomer<br>OR<br>Cytophosphane OR Cyclophosphamide Monohydrate OR Cytophosphan OR Cytoxan<br>OR Endoxan OR Neosar OR Procytox OR cyclophosphane<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-|575|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 #1AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'cyclophosphamide'/exp OR cyclophosphamid* ORalkyroxan OR carloxan OR<br>ciclofosfamida OR ciclolen OR cicloxal OR clafen OR cyclo-cell OR cycloblastin OR<br>cycloblastine OR 'cyclofos amide' OR cyclofosfamid OR cyclofosfamide OR<br>cyclophar OR cyclophosphan OR cyclophosphane OR cyclostin OR cycloxan OR<br>cyphos OR cytophosphan OR cytophosphane OR cytoxan OR 'endocyclo phosphate'<br>OR endoxan OR endoxan-asta OR endoxana OR endoxon-asta OR enduxan OR<br>genoxal OR ledoxan OR ledoxina OR 'lyophilized cytoxan'OR mitoxan OR neosan<br>OR neosar OR noristan OR procytox OR procytoxide OR semdoxan OR sendoxan OR<br>syklofosfamid<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*|334|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7#6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor: [Cyclophosphamide] explode all trees<br>#5 Sendoxan OR Cytophosphane OR Cytophosphan OR Cytoxan OR Endoxan OR<br>Neosar OR Procytox OR Cyclophosphane<br>#6 #1 OR #2 OR #3<br>#7 #4 OR #5<br>#8 #6 AND #7|53|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Lilacs<br>via|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)|10|
|Portal BVS|OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:Cyclophosphamide<br>OR<br>mh:D02.455.526.728.650.730.243$ OR<br>mh:D02.705.672.500.243$ ORSendoxan OR Cytophosphane OR Cytophosphan OR<br>Cytoxan OR Endoxan OR Neosar OR Procytox OR Cyclophosphane<br>Filter: Lilacs||
|Epistemonik<br>os|(title:((Systemic Scleroderma) AND Cyclophosphamide) OR abstract:((Systemic<br>Scleroderma) AND Cyclophosphamide))|11|  
Dois avaliadores independentes realizaram a seleção dos estudos e extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> e que possuírem manifestações cutâneas associada à ES.  
- (b) Tipo de intervenção  
Ciclofosfamida em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram considerados ECRs.  
- (d) Desfechos: Fibrose cutânea, dor, eventos adversos graves, eventos adversos gerais.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 984 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 3 textos completos. Um estudo foi excluído por não se tratar da intervenção adequada<sup>16</sup> . Para auxiliar na tomada de decisão, 2 estudos foram incluídos<sup>12,17</sup> . O processo de seleção é detalhado na **Figura 11** .  
**Figura 11** - Fluxograma de seleção dos estudos <mark>avaliando o</mark> uso da ciclofosfamida comparada a outros fármacos ou placebo para o tratamento de manifestações cutâneas graves na ES.  
<!-- Start of picture text -->
Referéncias identificadas por Referéncias removidas antes do<br>: rastreamento:<br>meio “Sadee he 884) de Referéncias duplicadas<br>~ removidas (n = 105)<br>Referéncias rastreadas (n = 879) Referéncias excluidas (n = 876)<br>Relatos avaliados para Relatos excluidos (n = 1)-<br>elegibilidade (n = 3) > Estudo com intervencao<br>inadequada (n = 1)<br>Estudos incluidos nesta revisao<br>(n= 2)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada Risk of bias (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa da mudança pré-pós ou estimativa pós-intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RRcom IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Dois estudos avaliaram a eficácia e segurança da ciclofosfamida no tratamento de manifestações cutâneas em indivíduos com ES. Entretanto, devido à presença de diferentes intervenções no grupo comparador, não foi possível agrupar os resultados em metanálises e por esse motivo os resultados foram apresentados de forma descritiva.  
Tashkin et al. (2006)<sup>17</sup> randomizaram 162 pacientes para receber ciclofosfamida ou PBO. Neste estudo, em 85 pacientes com doença difusa, os escores para espessamento da pele (mRS) mostraram uma diferença entre os dois grupos favorecendo a ciclofosfamida (DM −3,06; IC 95%, −3,54 a −0,52; p = 0,008). Nadashkevich et al. (2006)<sup>12</sup> em seu ECR com 60 participantes encontraram diferença favorecendo o grupo que recebeu ciclofosfamida quando comparado ao grupo que recebeu azatioprina no escore modificado de Rodnan (mrSS). A média da mudança do grupo ciclofosfamida em 18 meses foi de -9,47 + 0,84 enquanto a do grupo azatioprina foi de 0,2 + 0,21 (p < 0,001).  
O risco de viés geral de ambos os estudos foi julgado como alto. No estudo de Nadashkevich et al. (2006)<sup>12</sup> , foi considerado haver algumas preocupações quanto ao risco de viés devido a desvio das intervenções pretendidas e seleção do resultado relatado e alto risco no processo de randomização. No estudo de Tashkin et al. (2006)<sup>17</sup> , foi julgado haver algumas preocupações quanto à seleção dos resultados relatados e alto risco de viés devido a desvios das intervenções pretendidas e dados perdidos dos desfechos. A avaliação completa do risco de viés deste estudo é apresentada na **Figura 12** .  
**Figura 12** - Risco de viés dos estudos <mark>incluídos avaliando</mark> o uso da ciclofosfamida comparada a outros fámacos ou placebo para o tratamento de manifestações cutâneas graves na ES.  
<!-- Start of picture text -->
Estudo Desfecho DL p28 4S Geral<br>Nadashkevich 2005 Escoreeuténeo @ ! ) ) ! @ ) Balnorsco<br>Tashkin 2006 Escore cuténeo @@@ee5@ 1) Aguas preocupacbes<br>@ Alto risco<br>int Processode randomizaco<br>D Desvios das intervengGes pretendidas<br>03 Datos pedis do desfecho<br>0 Mensuraro do desecho<br>05 Selego do resultado relatado<br><!-- End of picture text -->  
O **Quadro P** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização da ciclofosfamida é indicada em pacientes com ES,  
com os critérios clínicos de elegibilidade que serão descritos a seguir:

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de inclusão</u> -->
● Pacientes que preencherem os critérios do EULAR/EUSTAR de 2013 ou os critérios de LeRoy e Medsger para doença inicial e que possuírem manifestações cutâneas associada à ES.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de exclusão</u> -->
Os mesmos citados na questão anterior (5.1), assim como as estratégias para o monitoramento.  
**Quadro P -** Ciclofosfamida comparada a outros fármacos ou placebo para o tratamento de manifestações cutâneas graves na ES  
|||**Avali**|**ação da certeza d**|**a evidência**|||**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**(Ciclofosfamida versus outros fármacos ou placebo)**|**evidência**|
|**Escore de**<br>2|**pele modificado**<br>ECR|**de Rodna**<br>**grave**<sup>**a**</sup>|**n**(seguimento:**1**<br>não grave|**2 meses**<sup>17</sup> a <br>não grave|**18 meses** <sup>12</sup>)<br>**grave**<sup>**b**</sup>|nenhum|**Ciclofosfamida versus Placebo**<br>Em85 pacientes com doença difusa, os escores para<br>espessamento<br>da<br>pele<br>mostraram<br>uma<br>diferença<br>significativa entre os dois grupos favorecendo a<br>ciclofosfamida (DM −3,06; IC 95%, −3,54 a −0,52; p =<br>0,008); 145 participantes; 73 no grupo ciclofosfamida; 72<br>no grupo placebo; 1 estudo<sup>17</sup> <br>**Ciclofosfamida versus Azatioprina**<br>A média da mudança do grupo ciclofosfamida em 18 meses<br>foi de -9,47+0,84 enquanto que a do grupo azatioprina foi<br>de 0,2+0,21 (p < 0,001); 60 participantes; 10 no grupo<br>ciclofosfamida; 30 no grupo azatioprina; 1 estudo<sup>12</sup>|⨁⨁◯◯<br>Baixa|

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Escore de pele modificado de Rodnan** (seguimento: **12 meses**<sup>17</sup> a **18 meses**<sup>12</sup> ) -->
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; ECR: Ensaio clínico randomizado</mark>  
<mark>a. Diminuído um nível devido à presença de limitações metodológicas (dois estudos com alto risco de viés geral - um estudo com alto risco para desvios das intervenções pretendidas e dados perdidos do desfecho e algumas preocupações quanto à seleção do</mark>  
<mark>resultado relatado (Tashkin 2006) e um estudo com alto risco de viés no processo de randomização e algumas preocupações quanto à desvios das intervenções pretendidas e seleção do resultado relatado (</mark> Nadashkevich 2006))  
<mark>b. Diminuído um nível devido ao reduzido tamanho amostral</mark>

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Escore de pele modificado de Rodnan** (seguimento: **12 meses**<sup>17</sup> a **18 meses**<sup>12</sup> ) -->
12. Nadashkevich O, Davis P, Fritzler M, Kovalenko W. A randomized unblinded trial of cyclophosphamide versus azathioprine in the treatment of systemic sclerosis. Clin Rheumatol. 2006 Mar;25(2):205-12. doi: 10.1007/s10067-005-1157-y. Epub 2005 Oct 14. PMID: 16228107.  
17. Tashkin DP, Elashoff R, Clements PJ, Goldin J, Roth MD, Furst DE, Arriola E, Silver R, Strange C, Bolster M, Seibold JR, Riley DJ, Hsu VM, Varga J, Schraufnagel DE, Theodore A, Simms R, Wise R, Wigley F, White B, Steen V, Read C, Mayes M, Parsley E, Mubarak K, Connolly MK, Golden J, Olman M, Fessler B, Rothfield N, Metersky M; Scleroderma Lung Study Research Group. Cyclophosphamide versus placebo in scleroderma lung disease. N Engl J Med. 2006 Jun 22;354(25):2655-66. doi: 10.1056/NEJMoa055120. PMID: 16790698.  
**QUESTÃO 6.** Deve-se usar metotrexato para o tratamento do espessamento cutâneo e sintomas articulares em pacientes com Esclerose Sistêmica?  
**<u>Recomendação:</u>** <mark>Sugerimos usar metotrexato em pacientes com ES e espessamento cutâneo ou sintomas articulares</mark>  
<mark>(recomendação condicional, certeza de evidência baixa).</mark>  
A estrutura PICO para esta pergunta foi: **População:** Pacientes com Esclerose Sistêmica **Intervenção:** Metotrexato  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** fibrose cutânea; capacidade funcional; qualidade de vida avaliado por questionários validados;  
dor.  
**Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECRs comparando o metotrexato a outros fármacos ou placebo para o tratamento das manifestações cutâneas em pacientes com ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro Q.**  
**Quadro Q -** Estratégias de busca para identificação de estudos sobre o uso do metotrexato em pacientes com ES  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE via<br>Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Methotrexate"[Mesh] OR Methotrexat*<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as topic[MeSH<br>Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract] OR random<br>allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR|256|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR meta-<br>regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol Assess<br>(Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#8 - #1AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR 'sclerosis,<br>progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR scleroderma OR<br>dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR 'skin sclerosis'<br>#2 'methotrexate'/exp OR methotrexat* OR 'a methopterine' OR abitextrate OR<br>'abitrexate' OR 'adx 2191' OR adx2191 OR amethopterin OR amethopterine OR<br>ametopterine OR antifolan OR biotrexate OR brimexate OR canceren OR 'cl 14377' OR<br>cl14377 OR 'emt 25299' OR emt25299 OR emtexate OR emthexat OR emthexate OR<br>emtrexate OR enthexate OR farmitrexat OR farmitrexate OR farmotrex OR folex OR<br>ifamet OR imeth OR 'intradose MTX' OR jylamvo OR lantarel OR ledertrexate OR<br>lumexon OR maxtrex OR metatrexan OR metex OR methoblastin OR methohexate OR<br>methotrate OR methotrexat OR 'methotrexat ebewe' OR 'methotrexate lpf' OR<br>methylaminopterin OR methylaminopterine OR meticil OR metoject OR metotrexin<br>OR metrex OR metrotex OR mexate OR mexate-aq OR 'mexate-aq preserved' OR 'mpi<br>2505' OR 'mpi 5004' OR mpi2505 OR mpi5004 OR MTX OR neotrexate OR nordimet<br>OR novatrex OR 'nsc 740' OR 'nsc740' OR otrexup OR 'otrexup pfs' OR  'r 9985' OR<br>r9985 OR rasuvo OR reditrex OR reumatrex OR rheumatrex OR 'rheumatrex dose pack'|227|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR texate OR texate-t OR texorate OR tremetex OR trexall OR trexeron OR 'wr 19039'<br>OR wr19039 OR xaken OR xatmep OR zexate<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover* OR<br>cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature* OR<br>research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7#6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor: [Methotrexate] explode all trees<br>#5 Methotrexat*<br>#6 #1 OR #2 OR #3|98|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#7 #4 OR #5<br>#8 #6 AND #7||
|Lilacs via Portal<br>BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*) OR<br>mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:Methotrexate OR mh:D03.633.100.733.631.192.500$ OR methotrexat*<br>Filter: Lilacs|11|
|Epistemonikos|(title:((Systemic<br>Scleroderma)<br>AND<br>Methotrexate)<br>OR<br>abstract:((Systemic<br>Scleroderma) AND Methotrexate))|8|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial c</mark> om manifestações cutâneas ou articulares.  
- (b) Tipo de intervenção  
Metotrexato em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
ECR .  
(d) Desfechos de eficácia: função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial pulmonar; pressão capilar pulmonar; fibrose cutânea; qualidade de vida avaliada por instrumentos validados; mortalidade; dor; sobrevida. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 600 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 3 textos completos. Um estudo foi excluído por tratar-se de intervenção que não se encaixava nos critérios de elegibilidade da PICO<sup>18</sup> . Para auxiliar na tomada de decisão, 2 estudos foram incluídos<sup>19,20</sup> . O processo de seleção é detalhado na **Figura 13.**  
**Figura 13** - Fluxograma de seleção dos estudos avaliando o uso do metotrexato comparado a outros fármacos ou placebo para o tratamento de manifestações cutâneas na ES.  
<!-- Start of picture text -->
Referéncias identificadas por Referencias removidas antes do<br>meio aden wn 800) ge Referéncias duplicadas<br>removidas (n = 70)<br>Referéncias rastreadas (n = 530) Referéncias excluidas (n = 527)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 3) ——>| Estudos com intervencao<br>inadequada (n = 1)<br>Estudos incluidos nesta revisao<br>(n= 2)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés do estudo incluído foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada Risk of bias (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa pós-intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Dois estudos avaliaram a eficácia e segurança do metotrexato no tratamento do espessamento cutâneo e sintomas articulares e ambos compararam metotrexato à PBO em pacientes com ES. Pope (2001)<sup>19</sup> randomizou 71 pacientes com ES difusa de menos de 3 anos de duração para receber metotrexato. Van den Hoogen (1996)<sup>20</sup> randomizou 29 pacientes com ES para receber metotrexato ou placebo por 48 semanas. Os resultados dos estudos indicaram que parece haver pouca ou nenhuma diferença entre os grupos quanto ao espessamento cutâneo, avaliado pelo mRS e pelo _Total Skin Score_ (DMP -0,45 DP; IC95% -0,89 a 0,0), à incapacidade funcional avaliada pelo HAQ (DM 0,0; IC95% -0,55 a 0,55) e dor avaliada pelo HAQ (DM 0,1; IC95% -0,34 a 0,54). Quanto à segurança do medicamento, um paciente saiu do estudo devido à ocorrência de evento adverso (úlcera oral) no grupo metotrexato no estudo de Pope (2001)<sup>19</sup> . No estudo de Van den Hoogen (1996)<sup>20</sup> , 10 de 17 pacientes (58,82% no grupo metotrexato) apresentaram eventos adversos, dentre os quais, 6 eram anormalidades da função hepática. No  
grupo placebo, 2 de 12 pacientes (16,67%) apresentaram eventos adversos que incluíam sintomas relacionados à ES (RR 3,53; IC95% 0,94 a 13,29)<sup>20</sup> .  
O risco de viés geral dos dois estudos incluídos foi julgado como alto. Considerou-se alto risco de viés para dados perdidos do desfecho e algumas preocupações quanto ao processo de randomização e seleção do resultado relatado em um estudo<sup>19</sup> e algumas preocupações quanto ao processo de randomização, desvio das intervenções pretendidas e seleção do resultado relatado no outro estudo<sup>20</sup> . A avaliação completa do risco de viés destes estudos é apresentada na **Figura 14** .  
**Figura 14** - Risco de viés dos estudos <mark>incluídos avaliando</mark> o uso do metotrexato comparado a placebo para o tratamento de manifestações cutâneas na ES.  
<!-- Start of picture text -->
— — ~~ — — ~— ~~ i Baixo risco<br>Estudo. Desfecho D1 D2 D3 D4 DS Geral e@ oe,<br>Pope 2001 RSS 0@@eetv@ 1D) Algumnas preocupagées<br>Pope 2001 Incapacidade funcional { e@ @ e ! T ) (<br>Pope 2001 Dor »@@@ Et r )<br>Pope 2001 Eventos adversos ! e@ @ e ! t ) pt Processo de randomizaco<br>Van den Hoogen 1996 mRSS ! ! e@ e ! t ) D2 Desvios das intervenges pretendidas<br>Van den Hoogen 1996 Eventos adversos » @ e@ e ! r ) 03 Dados perdidos do desfecho<br>pa Mensurago do desfecho<br>ps SelegBo do resultado relatado<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que o metotrexato já é um medicamento disponível no SUS e apresenta evidências  
de efetividade e segurança quando utilizado para o tratamento do espessamento cutâneo e sintomas articulares em pacientes com ES.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização do metotrexato é indicada em pacientes com ES, com  
os critérios clínicos de elegibilidade que serão descritos a seguir:

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de inclusão:</u> -->
- Pacientes que preencherem os critérios do EULAR/EUSTAR de 2013 ou os critérios de LeRoy e Medsger para doença inicial com espessamento cutâneo ou sintomas articulares

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de exclusão:</u> -->
- Hipersensibilidade ao metotrexato ou quaisquer excipientes da fórmula  
- Aumento das enzimas hepáticas ou nível de bilirrubinas 2 vezes > o limite superior da normalidade  
- Infeção ativa moderada a grave (ex: Herpes Zoster ativa, fúngica - sistêmica ou ameaçadora à vida, tuberculose sem tratamento)  
- Concepção, gestação ou lactação  
- Hepatopatia crônica  
- Câncer  
- Taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica;  
Para o monitoramento dos pacientes, sugere-se que sejam solicitadas:  
- Enzimas hepáticas (AST/TGO e ALT/TGP), hemograma com contagem de plaquetas, ureia e creatinina antes do início do tratamento, no primeiro mês (se possível, mensalmente nos primeiros 3 meses), e após, sugere-se repetir a cada 3 meses ou conforme necessidade clínica.  
- Sorologia para HIV e Hepatite B e C antes do início do tratamento  
- Em caso de elevação de transaminases acima de 2 vezes do limite superior de referência, o medicamento deve ser  
suspenso por 2 semanas com posterior reavaliação laboratorial. O metotrexato pode ser reiniciado após a normalização das transaminases.  
- Consumo de bebidas alcoólicas é desaconselhado ao longo do tratamento.  
- Em caso de diminuição na contagem de leucócitos (menos de 1.500/mm<sup>3</sup> ) ou plaquetas (menos de 50.000/mm<sup>3</sup> ) há  
necessidade de redução na dose do medicamento.  
- Diminuição de dose também deve ser considerada em caso de úlceras orais ou estomatite.  
- Tosse e dispneia devem ser avaliadas com tomografia de tórax e testes de função pulmonar devido ao potencial risco de  
pneumonite, devendo assim ser usado com cautela em pacientes pneumopatas.  
- Sintomas como náusea e vômitos respondem à redução da dose de metotrexato ou incremento da dose semanal de ácido  
fólico. A administração de antiemético ou o uso do medicamento junto às refeições pode diminuir tais sintomas.  
- As causas mais comuns de toxicidade aguda com o medicamento são insuficiência renal aguda e administração  
concomitante de sulfametoxazol + trimetoprima. A associação de ácido fólico (5 a 10 mg/semana) auxilia a minimizar os efeitos adversos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Perfil de evidências:** -->
O **Quadro R** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.  
**Quadro R -** Metotrexato comparado a placebo para o tratamento de espessamento cutâneo e sintomas articulares na ES  
|||**Avalia**|**ção da certeza**|**da evidência**|||**№ de pacie**|**ntes**|**Efeito (Metotrexato**<br>**versus placebo)**|**Certeza da**<br>**evidência**|
|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**|**Delineamento**|**Risco**|**Inconsistência**|<br>**Evidência**|**Imprecisão**|**Outras**|**Metotrexato**|**Placebo**|**Absoluto**||
|**estudos**<br>**Espessam**|**do estudo**<br>**ento cutâneo**(se|**de viés**<br>guimento:|**6 meses**<sup>20</sup>**a 12**|**indireta**<br>**meses**<sup>19</sup>**)**; ava|liado com**mR**|**considerações**<br>**ss**e**TSS**|||**(IC 95%)**||
|2<br>**Incapacid**|ECR<br>**ade funcional**(s|**grave**<sup>**a**</sup><br>eguimento:|não grave<br> **12 meses**<sup>19</sup>**)**; a|não grave<br>valiado com**H**|**grave**<sup>**b**</sup><br>**AQ disability**|nenhuma<br>|44|36|DMP 0,45 DP menor<br>(0,89 menor a 0,00<br>maior)<sup>19,20</sup>|⨁⨁◯◯<br>Baixa|
|1|ECR|**grave**<sup>**c**</sup>|não grave|Não grave|**grave**<sup>**b**</sup>|nenhuma|26|24|DM 0,0 maior|⨁⨁◯◯|
|**Dor**(segu|imento:**12 mese**|**s**<sup>19</sup>); avalia|do com**HAQ p**|**ain**|||||(0,55 menor a 0,55 maior)<br>19|Baixa|
|1|ECR|**grave**<sup>**c**</sup>|não grave|não grave|**grave**<sup>**b**</sup>|nenhuma|24|22|DM 0,1 maior|⨁⨁◯◯|
|**Eventos a**|**dversos (**seguim|ento:**6 me**|**ses**<sup>20</sup>**a 12 mese**|**s**<sup>19</sup>)|||||(0,34 menor a 0,54 maior)<br>19|Baixa|
|2|ECR|**grave**<sup>**a**</sup>|não grave|Não grave|**grave**<sup>**b**</sup>|nenhuma|Um paciente saiu<br>adverso (úlcera or<br>participantes; 24 n<br>placebo; 1 estudo|do estudo de<br>al) no grupo<br>o grupo met<br><sup>19</sup>|vido a ocorrência de evento<br>metotrexato; 26<br>otrexato; 22 no grupo|⨁⨁◯◯<br>Baixa|  
|Metotrexato 10/17 (58,82%) (6 – anormalidades da função|
|---|
|hepática); Placebo 2/12 (Sint. Relac. à ES)(16,67%)|
|RR 3,53 0,94 a 13,29; 29 participantes; 1 estudo<sup>20</sup>|  
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; ECR: Ensaio clínico randomizado; DMP: Diferença de médias padronizada; mRss; modified Rodnan Skin Score; TSS: Total Skin Score; HAQ: Health Assessment Questionnaire</mark>  
- a. Diminuído um nível devido a limitações metodológicas (dois estudos com alto risco de viés geral - um estudo (Pope 2001) com alto risco de viés para dados perdidos do desfecho e algumas preocupações quanto ao processo de  
- randomização e seleção do resultado relatado e um estudo (Van den Hoogen 1996) com algumas preocupações quanto ao processo de randomização, desvio das intervenções pretendidas e seleção do resultado relatado).  
- b. Diminuído um nível devido à presença de tamanho amostral reduzido  
- c. Diminuído um nível devido a limitações metodológicas (um estudo com alto risco de viés geral (Pope 2001) - alto risco de viés para dados perdidos do desfecho e algumas preocupações quanto ao processo de randomização e  
- seleção do resultado relatado)

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Perfil de evidências:** -->
19. Pope JE, Bellamy N, Seibold JR, Baron M, Ellman M, Carette S, Smith CD, Chalmers IM, Hong P, O'Hanlon D, Kaminska E, Markland J, Sibley J, Catoggio L, Furst DE. A randomized, controlled trial of methotrexate versus  
placebo in early diffuse scleroderma. Arthritis Rheum. 2001 Jun;44(6):1351-8. doi: 10.1002/1529-0131(200106)44:6<1351::AID-ART227>3.0.CO;2-I. PMID: 11407694.  
20. van den Hoogen FH, Boerbooms AM, Swaak AJ, Rasker JJ, van Lier HJ, van de Putte LB. Comparison of methotrexate with placebo in the treatment of systemic sclerosis: a 24 week randomized double-blind trial, followed  
by a 24 week observational trial. Br J Rheumatol. 1996 Apr;35(4):364-72. doi: 10.1093/rheumatology/35.4.364. PMID: 8624641

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
O **Quadro S** apresenta o processo de tomada de decisão sobre o uso do metotrexato para o tratamento de espessamento cutâneo e sintomas articulares na ES, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Quadro S -** Processo de tomada de decisão referente ao uso do metotrexato para tratamento do espessamento cutâneo na ES.  
|Item da EtD|Julgamento dos<br>painelistas|Justificativa|
|---|---|---|
|Efeitos desejáveis:|Pequeno|Metotrexato versus Placebo: Pequena ou nenhuma diferença DMP 0,45<br>DP menor (0,89 menor a 0,00 maior) em 6 a 12 meses|
|Efeitos indesejáveis|Pequeno|Metotrexato versus Placebo: Eventos adversos<br>Metotrexato: 10/17(58,82%) de eventos adversos, dentre os quais 60%<br>tratava-se de anormalidades da função hepática; Placebo: 2/12 (16,67%)<br>de eventos relacionados à ES (RR 3,53 0,94 a 13,29)|
|Balanço entre riscos<br>e benefícios:|Provavelmente<br>favorece a intervenção|O grupo entende que o balanço é provavelmente favorável à intervenção.|
|Certeza da evidência:|Baixa|Julgamento da certeza baseado no método GRADE|
|Recursos requeridos:|Negligenciáveis|Metotrexato: 2,5 mg<br>R$ 0,81/comprimido;<br>10 comprimidos por semana R$ 8,00 por semana;<br>R$ 32,40 por mês (R$ 388,80 por ano de tratamento)|
|Viabilidade de<br>implementação:|Sim|Tecnologia já disponível no SUS.|
|Outras<br>considerações:|Não informado|Não foram reportadas outras considerações.|  
**QUESTÃO 7.** Deve-se usar nifedipino para vasculopatia digital em pacientes com Esclerose Sistêmica?  
**<u>Recomendação:</u>** Sugerimos utilizar nifedipino para o tratamento da vasculopatia digital em pacientes com ES (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica  
**Intervenção:** Nifedipino  
**Comparador:** Outros fármacos ou placebo  
**Desfechos** de eficácia tempo de cicatrização das úlceras, recorrência (presença de novas úlceras); _raynaud condition_  
_score_ ; dor; frequência e intensidade da crise; qualidade de vida.  
**Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca:** -->
Foi realizada busca sistematizada da literatura nas bases de dados MEDLINE via Pubmed, Embase via Elsevier, CENTRAL via Cochrane Library, LILACS via Portal BVS e Epistemonikos até 22 de julho de 2021 para localizar revisões sistemáticas avaliando a eficácia do nifedipino comparado a outros fármacos ou placebo em pacientes com vasculopatia digital associada à ES. As estratégias de busca para cada base estão descritas no **Quadro T** .  
**Quadro T -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou estudos clínicos sobre o uso do nifedipino  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR<br>Systemic Scleros* OR Systemic Scleroderma*<br>#2 "Nifedipine"[Mesh] OR Nifedipine OR Bay-1040 OR Bay 1040 OR<br>Bay1040 OR BAY-a-1040 OR BAY a 1040 OR BAYa1040 OR Cordipin<br>OR Cordipine OR Corinfar OR Korinfar OR Nifangin OR Procardia OR<br>Nifedipine-GTIS OR Vascard OR Adalat OR Fenigidin<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH<br>Terms]<br>OR<br>clinical<br>trial[Publication<br>Type]<br>OR<br>random*[Title/Abstract] OR random allocation[MeSH Terms] OR<br>therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR<br>meta-analysis[mh]<br>OR<br>meta<br>analy*[tw]<br>OR<br>metanaly*[tw]<br>OR<br>metaanaly*[tw] OR met analy*[tw] OR integrative research[tiab] OR<br>integrative review*[tiab] OR integrative overview*[tiab] OR research<br>integration*[tiab]<br>OR<br>research<br>overview*[tiab]<br>OR<br>collaborative<br>review*[tiab]<br>OR<br>collaborative<br>overview*[tiab]<br>OR<br>systematic<br>review*[tiab]<br>OR<br>technology<br>assessment*[tiab]<br>OR<br>technology<br>overview*[tiab] OR "Technology Assessment, Biomedical"[mh] OR<br>HTA[tiab] OR HTAs[tiab] OR comparative efficacy[tiab] OR comparative<br>effectiveness[tiab]<br>OR<br>outcomes<br>research[tiab]<br>OR<br>indirect<br>comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-treatment[tiab])<br>AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR<br>methodologic overview*[tiab] OR methodological review*[tiab] OR<br>methodologic review*[tiab] OR quantitative review*[tiab] OR quantitative<br>overview*[tiab] OR quantitative synthes*[tiab] OR pooled analy*[tiab] OR<br>Cochrane[tiab] OR Medline[tiab] OR Pubmed[tiab] OR Medlars[tiab] OR<br>handsearch*[tiab] OR hand search*[tiab] OR meta-regression*[tiab] OR<br>metaregression*[tiab] OR data synthes*[tiab] OR data extraction[tiab] OR<br>data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR der-<br>simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database<br>Syst<br>Rev"[Journal:__jrid21711]<br>OR<br>"health<br>technology<br>assessment winchester, england"[Journal] OR "Evid Rep Technol Assess|89|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||(Full Rep)"[Journal] OR "Evid Rep Technol Assess (Summ)"[Journal] OR<br>"Int J Technol Assess Health Care"[Journal] OR "GMS Health Technol<br>Assess"[Journal] OR "Health Technol Assess (Rockv)"[Journal] OR "Health<br>Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 - #1AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic'<br>OR 'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp<br>OR scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR<br>sclerodermia OR 'skin sclerosis'<br>#2 'nifedipine'/exp OR nifedipine OR adalat OR adalate OR adefin OR<br>adipine OR afeditab OR aldipin OR alonix-s OR alpha-nifedipine OR<br>amarkor OR angibloc OR angipec OR antiblut OR apo-nifed OR aponifed<br>OR aprical OR 'atanaal softcap' OR 'bay 1040' OR 'bay a 1040' OR 'bay<br>a1040' OR bay1040 OR calcheck OR calcibloc OR calcigard OR calcilat OR<br>calgina OR cardifen OR cardilat OR 'cardilate (nifedipine)' OR cardionorm<br>OR chronadalat OR chronadalate OR cipilat OR citilat OR coracten OR<br>cordafen OR cordaflex OR cordalat OR cordicant OR cordipen OR cordipin<br>OR corinfar OR coronpin OR corotrend OR denkifed OR depin OR<br>dignokonstant OR dilafed OR dipinkor OR duranifin OR ecodipin OR<br>emaberin OR fedcor OR fedipin OR 'fedipine 24 cr' OR fenamon  OR<br>fenigidin OR glopir OR 'hadipine s.r.' OR herlat OR hexadilat OR hypan OR<br>hypolar retard OR infedipine OR jutadilat OR kemolat OR megalat OR<br>mifedipine OR moderat OR myogard OR nadipine OR nedipin OR<br>nefedipine OR nelapine OR nifangin OR nifar OR nifdemin OR nife-par OR<br>nifebene OR nifecard OR nifecor Or nifedepat OR nifedicor OR nifedilat<br>OR nifedin OR nifedine OR nifedipat OR nifedipin OR nifedipres OR<br>'nifedirex lp' OR nifehexal OR nifelat OR nifelat-q OR nifensar OR<br>nifepidine OR nifestad OR nifical OR nificard OR nifidine OR nifipen OR<br>nipin OR nipine OR normadil OR 'novo nifedin' OR novonifedin OR nyefax<br>OR 'nyefax retard' OR nypine OR odipin OR orix OR osmo-adalat OR|3|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||phenygidine OR pidilat OR procardia OR ronian OR sepamit OR slofedipine<br>OR tibricol OR unidipine OR vascard OR vasdalat<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR  'single-blind procedure':de OR (random* OR<br>factorial* OR crossover* OR cross NEXT/1 over* OR placebo* OR doubl*<br>NEAR/1 blind* OR singl* NEAR/1 blind* OR assign* OR allocat* OR<br>volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3<br>analy*):ab,ti OR metaanaly*:ab,ti OR review*:ti OR overview*:ti OR<br>(synthes* NEAR/3 (literature* OR research* OR studies OR data)):ab,ti OR<br>(pooled AND analys*:ab,ti) OR ((data NEAR/2 pool*):ab,ti AND<br>studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR embase:ab,ti OR<br>cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti OR<br>psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR<br>cochrane:ab,ti OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR<br>manual OR database* OR computer*) NEAR/2 search*):ab,ti OR<br>(electronic NEAR/2 (database* OR 'data base' OR 'data bases')):ab,ti OR<br>bibliograph*:ab OR 'relevant journals':ab OR ((review* OR overview*)<br>NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT<br>(((retrospective* OR record* OR case* OR patient*) NEAR/2 review*):ab,ti<br>OR ((patient* OR review*) NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti<br>OR mouse:ab,ti OR mice:ab,ti OR hamster:ab,ti OR hamsters:ab,ti OR<br>animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR dogs:ab,ti OR cat:ab,ti OR<br>cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT ('editorial'/exp OR<br>'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp NOT<br>('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7#6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees|46|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor: [Nifedipine] explode all trees<br>#5 Nifedipine OR Bay-1040 OR Bay 1040 OR Bay1040 OR BAY-a-1040<br>OR BAY a 1040 OR BAYa1040 OR Cordipin OR Cordipine OR Corinfar<br>OR Korinfar OR Nifangin OR Procardia OR Nifedipine-GTIS OR Vascard<br>OR Adalat OR Fenigidin<br>#6 #1 OR #2 OR #3<br>#7 #4 OR #5<br>#8 #6 AND #7||
|Lilacs via Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic<br>Scleroderma*)<br>OR<br>mh:C17.300.799$ OR<br>mh:C17.800.784$ OR<br>mh:"Scleroderma,<br>Diffuse"<br>OR<br>mh:C17.300.799.602$ OR<br>mh:C17.800.784.602$ AND<br>mh:Nifedipine OR mh:D03.383.725.203.540$OR Nifedipine OR Bay-1040<br>OR Bay 1040 OR Bay1040 OR BAY-a-1040 OR (BAY a 1040) OR<br>BAYa1040 OR Cordipin OR Cordipine OR Corinfar OR Korinfar OR<br>Nifangin OR Procardia OR Nifedipine-GTIS OR Vascard OR Adalat OR<br>Fenigidin<br>Filter: Lilacs|1|
|Epistemonikos|(title:((Systemic Scleroderma) AND Nifedipine) OR abstract:((Systemic<br>Scleroderma) AND Nifedipine))|1|  
Dois avaliadores independentes realizaram a seleção dos estudos e extrações dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> com vasculopatia digital.  
- (b) Tipo de intervenção  
Nifedipino em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
(c) Tipos de estudos  
Revisões sistemáticas de ECR.  
(d) Desfechos de eficácia: tempo de cicatrização das úlceras, recorrência (presença de novas úlceras); _Raynaud condition score_ ; dor; frequência e intensidade da crise; qualidade de vida. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não teve restrição de linguagem e ano de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recrutados 140 estudos por meio de buscas nas bases de dados eletrônicas. Após a resolução das duplicatas, 113 estudos foram avaliados por meio de título e resumos e três estudos foram selecionados para serem lidos na íntegra. Dois estudos foram excluídos por incluírem população fora do escopo da PICO<sup>21,22</sup> . Um estudo foi incluído para auxiliar na tomada de decisão. A descrição geral dos estudos identificados é apresentada na **Figura O** .  
**Figura 15** - Fluxograma de seleção dos estudos avaliando o uso do nifedipino para o tratamento da vasculopatia digital em pacientes com ES.  
<!-- Start of picture text -->
Referéncias identificadas por Referéncias removidas antes do<br>meio de busca nas bases de rastreamento: .<br>dados (n = 140) Referéncias duplicadas<br>removidas (n = 27)<br>Referéncias rastreadas (n = 113) Referéncias excluidas (n = 110)<br>Relatos avaliados para Relatos excluidos (n = 2)<br>elegibilidade (n = 3) ——> Estudos com populacao<br>inadequada (n = 2)<br>Estudos incluidos nesta revisao<br>(n= 1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada _<mark>Risk Of Bias In Systematic Review</mark>_<sup>23</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa pós-intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Uma revisão sistemática com metanálise incluindo 8 ECR com 109 pacientes com ES verificou diminuição da frequência e gravidade de ataques isquêmicos com o uso de bloqueadores de canais de cálcio. Dentre estes, o nifedipino obteve os melhores  
resultados. A análise em separado de 5 ECRs com nifedipino na dose de 10 a 20 mg, 3 vezes/dia, demonstrou redução da frequência de ataques isquêmicos de 10,21; IC 95% 0,34-20,09 e de −0,99; IC de 95% -1,74, -0,24 para a redução da gravidade dos ataques isquêmicos em comparação com o grupo PBO<sup>24</sup> . Após a publicação desta revisão, nenhum outro ECR foi publicado sobre o assunto. O risco de viés geral do estudo foi julgado como incerto. A avaliação completa do risco de viés deste estudo é apresentada no **Quadro U** .  
**Quadro U -** Risco de viés do estudo Thompson, 2001, avaliado com a ferramenta ROBIS  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
|1.<br>Preocupação<br>em relação a<br>especificação dos<br>critérios de<br>elegibilidade|1.1 A revisão aderiu a objetivos e<br>critérios de elegibilidade pré-definidos?<br>1.2 Os critérios de elegibilidade foram<br>adequados para a pergunta da revisão?<br>1.3 Os critérios de elegibilidade eram<br>não-ambíguos?<br>1.4 Qualquer restrição nos critérios de<br>elegibilidade foram baseadas em<br>características de estudo apropriadas<br>(data, tamanho da amostra, qualidade do<br>estudo, desfechos medidos)?<br>1.5 Qualquer restrição nos critérios de<br>elegibilidade foram baseados em fontes<br>de informações apropriadas (status da<br>publicação ou formato, idioma,<br>disponibilidade de dados)?|1.1 S/PS/PN/N/**NI**<br>1.2**S**/PS/PN/N/NI<br>1.3**S**/PS/PN/N/NI<br>1.4**S**/PS/PN/N/NI<br>1.5<br>S/**PS**/PN/N/N<br>I|1. Baixa|Esforço<br>considerável<br>foi feito para<br>especificar<br>claramente a<br>questão da<br>revisão e<br>objetivo, e<br>para pré<br>especificar e<br>justificar os<br>critérios de<br>elegibilidade<br>apropriados<br>para essa<br>revisão|
|2.<br>Preocupação<br>em relação aos<br>métodos utilizados<br>para identificar ou<br>selecionar estudos|2.1 A pesquisa incluiu uma gama<br>apropriada de bases de dados / eletrônica<br>de estudos publicados e não publicados?<br>2.2 Foram utilizados métodos adicionais<br>para a pesquisa de bases de dados usada<br>para identificar estudos relevantes?|2.1 S/PS/PN/**N**/NI<br>2.2 S/PS/PN/N/**NI**|2. Baixa|Houve<br>esforço<br>substancial<br>para buscar<br>estudos<br>relevantes,<br>tanto quanto<br>possível por<br>uma|  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
||2.3 Os termos e a estrutura da estratégia<br>de busca tinham probabilidade de<br>recuperar tantos estudos elegíveis quanto<br>possível?<br>2.4 As restrições foram baseadas na data,<br>formato de publicação ou idioma<br>apropriado?<br>2.5 Foram feitos esforços para minimizar<br>o erro na seleção dos estudos?|2.3**S**/PS/PN/N/NI<br>2.4**S**/PS/PN/N/NI<br>2.5**S**/PS/PN/N/NI||variedade de<br>métodos de<br>pesquisa,<br>utilizando<br>uma<br>estratégia de<br>busca<br>sensível e<br>apropriada e<br>medidas<br>foram<br>tomadas<br>para<br>minimizar<br>erros de<br>seleção.|
|3.<br>Preocupação<br>com a coleta de dados<br>e análise crítica dos<br>estudos|3.1 Foram feitos esforços para minimizar<br>erros na coleta de dados?<br>3.2 Existiam informações disponíveis<br>suficientes sobre as características dos<br>estudos para tanto os autores da revisão<br>quanto os leitores serem capazes de<br>interpretar os resultados?<br>3.3 Todos os resultados relevantes foram<br>coletados para serem usados na síntese?<br>3.4 O risco de viés (ou qualidade<br>metodológica) foi formalmente avaliado<br>usando critérios apropriados?<br>3.5 Foram feitos esforços para minimizar<br>erros na avaliação do risco de viés?|3.1**S**/PS/PN/N/NI<br>3.2**S**/PS/PN/N/NI<br>3.3**S**/PS/PN/N/NI<br>3.4 S/PS/PN/**N**/NI<br>3.5**S**/PS/PN/N/NI|3. Incerto|Não há<br>informações<br>suficientes<br>relatadas<br>para<br>informar um<br>julgamento<br>sobre o risco<br>de viés.|
|4.<br>Preocupação<br>com relação aos|4.1 A síntese incluiu todos os estudos<br>que deveria?|4.1 S/**PS**/PN/N/NI|4. Incerto|Não há<br>informações|  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
|métodos utilizados<br>para a síntese e<br>resultados|4.2 Todas as análises predefinidas foram<br>relatadas ou os resultados explicados?<br>4.3 A síntese foi apropriada dada a<br>natureza e semelhança em questões de<br>pesquisa, desenho de estudo e resultados<br>dos estudos incluídos?<br>4.4 A variação mínima entre os estudos<br>(heterogeneidade) foi<br>abordada na síntese?<br>4.5 Os achados foram robustos i. e. como<br>demonstrado por meio do gráfico de<br>funil ou em análises de sensibilidade?<br>4.6 Os vieses nos estudos primários<br>foram mínimos ou foram abordados na<br>síntese?|4.2 S/PS/PN/N/**NI**<br>4.3**S**/PS/PN/N/NI<br>4.4 S/PS/PN/N/**NI**<br>4.5 S/PS/PN/**N**/NI<br>4.6 S/PS/**PN**/N/NI||suficientes<br>relatadas<br>para<br>informar um<br>julgamento<br>sobre o risco<br>de viés.|
|Risco de viés nas revi|sões||||
|A. A interpretação<br>domínios 1 ao 4|dos achados aborda todas as preocupações ide<br>?|ntificadas nos<br>S/**PS**|/N/PN/NI||
|B. A relevância do<br>considerada?|s estudos incluídos para a questão clínica foi a|propriadamente<br>S/**PS**/|N/PN/NI||
|C. Os revisores ev<br>estatística?|itaram enfatizar os resultados baseados na sign|ificância<br>**S**/PS/|N/PN/NI||
|Risco de viés: BAI|XO, ALTO E**INCERTO**||||  
S: Sim / PS: Provavelmente Sim/ N: Não / PN: Provavelmente Não/ NI: Não Informado.  
O **Quadro V** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os  
principais desfechos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT  
publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Inclusão</u> -->
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> com vasculopatia digital.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
- Infarto agudo do miocárdio;  
- Insuficiência cardíaca congestiva;  
- Angina instável ou pós-infarto;  
- Estenose aórtica grave;  
- Hipotensão;  
- Gestação (antes da 20ª semana) ou lactação.  
**Quadro V -** Nifedipino comparado a placebo para o tratamento de vasculopatia digital na ES  
|||**Avalia**|**ção da certeza da**|**evidência**|||**Nº de parti**|**cipantes**|**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Nifedipino**|**Placebo**|**(Nifedipino**<br>**versus Placebo)**|**evidência**|
|**Frequênci**|**a de ataques isquêm**|**icos**<sup>24</sup>|||||||||
|1|RS de ECR*|não<br>grave|não grave|não grave|**grave**<sup>**a**</sup>|nenhum|44|44|DMP -10,21;**<br>(IC 95% -20,09 a -<br>0,34);<sup>24</sup>|⨁⨁⨁◯<br>Moderada|
|**Gravidade**|**de ataques isquêmi**|**cos**<sup>24</sup>|||||||||
|1|RS de ECR*|não<br>grave|não grave|não grave|**grave**<sup>**a**</sup>|nenhum|44|44|DMP −0,99;**<br>(IC de 95% -1,74 a<br>-0,24);<sup>24</sup>|⨁⨁⨁◯<br>Moderada|  
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; DMP: Diferença de Média padronizada; RS: Revisão Sistemática; ECR: Ensaio clínico randomizado; *A revisão sistemáica incluiu 5 ECRs. **Resultados negativos indicam efeito favorável a intervenção testada.</mark>  
a. Reduzido um nível devido à presença de tamanho amostral reduzido.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
24. Thompson AE, Shea B, Welch V, Fenlon D, Pope JE. Calcium-channel blockers for Raynaud's phenomenon in systemic sclerosis. Arthritis Rheum. 2001 Aug;44(8):1841-7. doi: 10.1002/1529-0131(200108)44:8<1841::AIDART322>3.0.CO;2-8. PMID: 11508437.  
**QUESTÃO 8.** Deve-se usar anlodipino para vasculopatia digital em pacientes com Esclerose Sistêmica?  
**<u>Recomendação:</u>** Sugerimos utilizar anlodipino para o tratamento da vasculopatia digital em pacientes com ES (recomendação não graduada).  
A estrutura PICO para esta pergunta foi: **População:** Pacientes com Esclerose Sistêmica **Intervenção:** Anlodipino  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** tempo de cicatrização das úlceras, recorrência (presença de novas úlceras); _Raynaud condition_  
_score_ ; dor; frequência e intensidade da crise; qualidade de vida.  
**Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar revisões sistemáticas avaliando a eficácia do anlodipino no tratamento da vasculopatia digital em pacientes com ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro W** .  
**Quadro W -** Estratégias de busca para identificação de estudos sobre o uso do anlodipino em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Amlodipine"[Mesh] OR amlodipine OR Amlodis OR Astudal OR Norvasc OR<br>Istin OR Amlo<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR|7|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#7 (animals NOT humans)<br>#8 - #1AND #2 AND #5 NOT #7||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'amlodipine'/exp OR amlodipine OR amloc OR amlodipin OR amlodipina OR<br>amlopin OR 'uk 48340' OR uk48340<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti|16|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7 #6AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor: [Amlodipine] explode all trees<br>#5 amlodipine OR amloc OR amlodipin OR amlodipina OR amlopin OR 'uk 48340'<br>OR uk48340<br>#6 #1 OR #2 OR #3<br>#7 #4 OR #5<br>#8 #6 AND #7|7|
|Lilacs<br>via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:amlodipine OR mh:D03.383.725.203.065$ ORamlodipine OR Amlodis OR<br>Astudal OR Norvasc OR Istin OR Amlo<br>Filter: Lilacs|0|  
|**Bases de**<br>**dados**||**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|---|
|Epistemonik|(title:((Systemic<br>Scleroderma)|<br>AND<br>Amlodipine)<br>OR<br>abstract:((Systemic|1|
|os|Scleroderma) AND Amlodipine)|)||  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> com vasculopatia digital.  
- (b) Tipo de intervenção  
Anlodipino em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram consideradas revisões sistemáticas de ECRs.  
(d) Desfechos de eficácia: tempo de cicatrização das úlceras, recorrência (presença de novas úlceras); _Raynaud condition score;_ dor; frequência e intensidade da crise; qualidade de vida. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não teve restrição de linguagem e ano de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 31 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 2 textos completos. Um estudo foi excluído por incluir população que não se encaixava nos critérios de elegibilidade<sup>21</sup> . Um estudo foi incluído para auxiliar na tomada de decisão<sup>24</sup> . A descrição geral dos estudos identificados é apresentada na **Figura 16** .  
**Figura 16** - Fluxograma de seleção dos estudos avaliando o uso do anlodipino para o tratamento da vasculopatia digital em pacientes com ES.  
<!-- Start of picture text -->
Referéncias identificadas por Fee was antes do<br>melo eter de Referéncias duplicadas<br>~ removidas (n = 1)<br>Referéncias rastreadas (n = 30) Referéncias excluidas (n = 28)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 2) —* Estudos com populacao<br>inadequada (n = 1)<br>Estudos incluidos nesta revisao<br>(n= 1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés do estudo incluído foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada <mark>Risk Of Bias In Systematic Review</mark><sup>23</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa pós-intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Uma revisão sistemática com metanálise, incluindo 8 ECRs, verificou os efeitos de bloqueadores do canal de cálcio na diminuição da frequência e gravidade de ataques isquêmicos em pacientes com ES. Os resultados de 6 ECRs agrupados em metanálise nesta revisão sugeriram que os bloqueadores dos canais de cálcio, incluindo o anlodipino, são eficazes na redução da gravidade e frequência dos ataques isquêmicos no fenômeno de Raynaud secundário à ES (redução média padronizada 0,69; IC95% −1,21 a −0,17 e redução média 8,31; IC95% −15,71 a −0,91 ataques em 2 semanas, respectivamente). Após a publicação desta revisão, nenhum outro ECR foi publicado sobre o assunto. O risco de viés geral do estudo foi julgado como incerto. A avaliação completa do risco de viés deste estudo é apresentada no **Quadro X** .  
**Quadro X -** Risco de viés do estudo Thompson, 2001, avaliado com a ferramenta ROBIS  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
|1. Preocupação em<br>relação a<br>especificação dos<br>critérios de<br>elegibilidade|1.1 A revisão aderiu a objetivos e critérios<br>de elegibilidade pré-definidos?<br>1.2 Os critérios de elegibilidade foram<br>adequados para a pergunta da revisão?<br>1.3 Os critérios de elegibilidade eram não-<br>ambíguos?<br>1.4 Qualquer restrição nos critérios de<br>elegibilidade foram baseadas em<br>características de estudo apropriadas (data,<br>tamanho da amostra, qualidade do estudo,<br>desfechos medidos)?<br>1.5 Qualquer restrição nos critérios de<br>elegibilidade foram baseados em fontes de<br>informações apropriadas (status da<br>publicação ou formato, idioma,<br>disponibilidade de dados)?|1.1 S/PS/PN/N/**NI**<br>1.2**S**/PS/PN/N/NI<br>1.3**S**/PS/PN/N/NI<br>1.4**S**/PS/PN/N/NI<br>1.5 S/**PS**/PN/N/NI|1.<br>Baix<br>a|Esforço<br>considerável<br>foi feito para<br>especificar<br>claramente a<br>questão da<br>revisão e<br>objetivo, e<br>para pré<br>especificar e<br>justificar os<br>critérios de<br>elegibilidade<br>apropriados<br>para essa<br>revisão|
|2. Preocupação em<br>relação aos métodos<br>utilizados para<br>identificar ou<br>selecionar estudos|2.1 A pesquisa incluiu uma gama apropriada<br>de bases de dados / eletrônica de estudos<br>publicados e não publicados?<br>2.2 Foram utilizados métodos adicionais<br>para a pesquisa de bases de dados usada para<br>identificar estudos relevantes?<br>2.3 Os termos e a estrutura da estratégia de<br>busca tinham probabilidade de recuperar<br>tantos estudos elegíveis quanto possível?<br>2.4 As restrições foram baseadas na data,<br>formato de publicação ou idioma<br>apropriado?|2.1 S/PS/PN/**N**/NI<br>2.2 S/PS/PN/N/**NI**<br>2.3**S**/PS/PN/N/NI<br>2.4**S**/PS/PN/N/NI|2. Baixa|Houve<br>esforço<br>substancial<br>para buscar<br>estudos<br>relevantes,<br>tanto quanto<br>possível por<br>uma<br>variedade de<br>métodos de<br>pesquisa,<br>utilizando<br>uma<br>estratégia de|  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
||2.5 Foram feitos esforços para minimizar o<br>erro na seleção dos estudos?|2.5**S**/PS/PN/N/NI||busca<br>sensível e<br>apropriada e<br>medidas<br>foram<br>tomadas para<br>minimizar<br>erros de<br>seleção.|
|3. Preocupação com<br>a coleta de dados e<br>análise crítica dos<br>estudos|3.1 Foram feitos esforços para minimizar<br>erros na coleta de dados?<br>3.2 Existiam informações disponíveis<br>suficientes sobre as características dos<br>estudos para tanto os autores da revisão<br>quanto os leitores serem capazes de<br>interpretar os resultados?<br>3.3 Todos os resultados relevantes foram<br>coletados para serem usados na síntese?<br>3.4 O risco de viés (ou qualidade<br>metodológica) foi formalmente avaliado<br>usando critérios apropriados?<br>3.5 Foram feitos esforços para minimizar<br>erros na avaliação do risco de viés?|3.1**S**/PS/PN/N/NI<br>3.2**S**/PS/PN/N/NI<br>3.3**S**/PS/PN/N/NI<br>3.4 S/PS/PN/**N**/NI<br>3.5**S**/PS/PN/N/NI|3. Incerto|Não há<br>informações<br>suficientes<br>relatadas<br>para informar<br>um<br>julgamento<br>sobre o risco<br>de viés.|
|4. Preocupação com<br>relação aos métodos<br>utilizados para a<br>síntese e resultados|4.1 A síntese incluiu todos os estudos que<br>deveria?<br>4.2 Todas as análises predefinidas foram<br>relatadas ou os resultados explicados?<br>4.3 A síntese foi apropriada dada a natureza<br>e semelhança em questões de pesquisa,|4.1 S/**PS**/PN/N/NI<br>4.2 S/PS/PN/N/**NI**<br>4.3**S**/PS/PN/N/NI|4. Incerto|Não há<br>informações<br>suficientes<br>relatadas<br>para informar<br>um<br>julgamento<br>sobre o risco<br>de viés.|  
|**Domínio**|**Perguntas sinalizadoras**|**Resp**<br>**perg**<br>**sinali**|**osta às**<br>**untas**<br>**zadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|---|
||desenho de estudo e resultados dos estudos<br>incluídos?<br>4.4 A variação mínima entre os estudos<br>(heterogeneidade) foi<br>abordada na síntese?<br>4.5 Os achados foram robustos i. e. como<br>demonstrado por meio do gráfico de funil ou<br>em análises de sensibilidade?<br>4.6 Os vieses nos estudos primários foram<br>mínimos ou foram abordados na síntese?|4.4 S/PS/<br>4.5 S/PS/<br>4.6 S/PS/|PN/N/**NI**<br>PN/**N**/NI<br>**PN**/N/NI|||
|Risco de viés nas re|visões|||||
|D. A interpretaçã<br>nos domínios|o dos achados aborda todas as preocupações iden<br>1 ao 4?|tificadas|S/**PS**/N/|PN/NI||
|E. A relevância d<br>apropriadame|os estudos incluídos para a questão clínica foi<br>nte considerada?||S/**PS**/N/|PN/NI||
|F. Os revisores e<br>estatística?|vitaram enfatizar os resultados baseados na signif|icância|**S**/PS/N/|PN/NI||
|Risco de viés: B|AIXO, ALTO E**INCERTO**|||||  
S: Sim / PS: Provavelmente Sim/ N: Não / PN: Provavelmente Não/ NI: Não Informado

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT  
publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Inclusão</u> -->
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> com vasculopatia digital.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
- Infarto agudo do miocárdio;  
- Insuficiência cardíaca congestiva;  
- Angina instável ou pós-infarto;  
- Estenose aórtica grave;  
- Hipotensão;  
- Gestação (antes da 20ª semana) ou lactação.  
O **Quadro Y** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.  
**Quadro Y -** Anlodipino comparado a placebo para o tratamento da vasculopatia digital na ES  
|||**Avalia**|**ção da certeza d**|**a evidência**|||**Nº de pac**|**ientes**|**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Anlodipino**|**Placebo**|**(Anlodipino versus**<br>**placebo)**|**evidência**|
|**Frequênc**|**ia de ataques isquêmi**|**cos**<sup>24</sup>|||||||||
|1<br>**Gravidad**|RS de ECR*<br>**e de ataques isquêmi**|não<br>grave<br>**cos**<sup>24</sup>|não grave|**grave**<sup>**a**</sup>|**grave**<sup>**b**</sup>|nenhum|58|59|DM-8,31**<br>(IC 95% −15.71 a<br>−0.91);<sup>24</sup>|⨁⨁◯◯<br>Baixa|
|1|RS de ECR*|não<br>grave|não grave|**grave**<sup>**a**</sup>|**grave**<sup>**b**</sup>|nenhum|58|59|DM−0.69**<br>(IC 95% −1.21 a<br>−0.17 -35%);<sup>24</sup>|⨁⨁◯◯<br>Baixa|  
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; DMP: Diferença média padronizada;  RS: Revisão Sistemática; ECR: Ensaio clínico randomizado; ES: Esclerose Sistêmica; *A revisão sistemáica incluiu 6 ECRs. **Resultados negativos indicam efeito favorável a intervenção testada.</mark>  
a.Reduzido um nível devido à presença de estudos da classe terapêutica (bloqueadores dos canais de cálcio), porém ausência de estudos com  o anlodipino.  
b.Reduzido um nível devido à presença de tamanho amostral reduzido

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
24.Thompson AE, Shea B, Welch V, Fenlon D, Pope JE. Calcium-channel blockers for Raynaud's phenomenon in systemic sclerosis. Arthritis Rheum. 2001 Aug;44(8):1841-7. doi: 10.1002/1529-0131(200108)44:8<1841::AIDART322>3.0.CO;2-8. PMID: 11508437  
**QUESTÃO 9.** Deve-se usar sildenafila para tratamento de úlceras digitais refratárias aos bloqueadores dos canais de cálcio em pacientes com Esclerose Sistêmica?  
**<u>Recomendação:</u>** <mark>Sugerimos usar sildenafila em pacientes com Es</mark> clerose Sistêmica <mark>e úlceras digitais refratárias aos bloqueadores de canal de cálcio (recomendação condicional, certeza da evidência muito baixa).</mark>  
A estrutura PICO para esta pergunta foi: **População:** Pacientes com Esclerose Sistêmica **Intervenção:** Sildenafila **Comparador:** Outros fármacos ou placebo **Desfechos de eficácia:** tempo de cicatrização das úlceras, recorrência (presença de novas úlceras); _Raynaud condition score_ ; dor; frequência e intensidade da crise; qualidade de vida.  
**Desfechos de segurança** : eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR avaliando a eficácia da sildenafila para o tratamento de úlceras digitais refratárias aos bloqueadores de canais de cálcio em pacientes com ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro Z** .  
**Quadro Z -** Estratégias de busca para identificação de estudos sobre o uso da sildenafila em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Sildenafil Citrate"[Mesh] OR Citrate, Sildenafil OR Revatio OR<br>Sildenafil OR Homosildenafil OR Hydroxyhomosildenafil OR Viagra<br>OR Acetildenafil OR  Sildenafil Lactate OR Sildenafil Nitrate OR Desmethyl<br>Sildenafil<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR|92|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6  (animals NOT humans)<br>#7 #1 AND 2 AND #5 NOT #6||
|EMBASE|#1  'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'sildenafil'/exp OR sildenafil OR aphrodil OR edegra OR ejertol OR erectol OR erili<br>OR eroxim OR granpidam OR mysildecard OR patrex OR penegra OR revatio OR<br>rigix OR 'ripol (sildenafil)' OR sildefil OR 'sildenafil citrate' OR             'supra (drug)'<br>OR  viagra OR vigain OR vizarsin OR zwagra<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*|87|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 # 3 OR #4<br>#6 #1 AND #2 AND #5<br>#7 # 6 AND  [embase]/lim NOT ([embase]/lim AND [medline]/lim||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4  [Sildenafil Citrate] explode all trees<br>#5 sildenafil citrate OR Sildenafil Lactate OR Sildenafil Citrate OR Sildenafil Nitrate<br>OR Sildenafil OR Desmethyl Sildenafil OR  Viagra OR  Acetildenafil OR<br>Homosildenafil OR Revatio<br>#6 #1 OR #2 OR #3<br>#7 #4 OR #5<br>#8 #6 AND #7|41|
|Lilacs<br>via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND|1|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||mh:"citrato de Sildenafil" OR (Sildenafil Citrate) OR (Citrato de Sildenafil) OR viagra<br>OR mh:D02.065.884.675$ OR mh:D02.886.590.700.675$ OR  mh:D03.383.606.854$ OR mh:D03.633.100.759.824$||
||Filter: Lilacs||
|Epistemonik|(title:(Systemic<br>Scleroderma)<br>OR<br>abstract:(Systemic<br>Scleroderma))<br>AND|0|
|os|(title:(Sildenafil Citrate) OR abstract:(Sildenafil Citrate))||  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial c</mark> om úlceras digitais refratárias aos bloqueadores de canais de cálcio  
- (b) Tipo de intervenção  
Sildenafila em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram considerados ECR.  
(d) Desfechos de eficácia: tempo de cicatrização das úlceras, recorrência (presença de novas úlceras); _Raynaud condition score_ ; dor; frequência e intensidade da crise; qualidade de vida. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 221 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 2 textos completos. Um estudo foi excluído por possuir população que não se encaixava nos critérios de elegibilidade - não refratária a bloqueadores de canais de cálcio<sup>25</sup> . Para auxiliar na tomada de decisão, 1 estudo foi incluído<sup>26</sup> . O processo de seleção é detalhado na **Figura 17** .  
**Figura 17** - Fluxograma de seleção dos estudos <mark>avaliando o</mark> uso de sildenafila comparado a outros fármacos ou placebo para o tratamento de úlceras digitais refratárias aos bloqueadores de canais de cálcio na ES.  
<!-- Start of picture text -->
ee Referéncias removidas antes do<br>Referéncias identificadas por .<br>io de bi b 4 rastreamento:<br>meno « ont eraed e Referéncias duplicadas<br>jados (n = ) removidas (n = 25)<br>Referéncias rastreadas (n = 196) Referéncias excluidas (n = 194)<br>Relatos avaliados para Relatos excluidos (n = 1)<br>elegibilidade (n = 2) —> Estudos com populacao<br>inadequada (n = 1)<br>Estudos incluidos nesta revisao<br>(n=1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés do estudo incluído foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada Risk of bias (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa da mudança pré-pós) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Um ECR<sup>26</sup> do tipo _crossover_ avaliou a eficácia e segurança da sildenafila no tratamento de úlceras digitais refratárias aos bloqueadores dos canais de cálcio em indivíduos com ES. Este estudo randomizou 16 participantes para receber 50 mg de sildenafila ou PBO duas vezes ao dia durante 4 semanas. Os sintomas foram obtidos por cartões de diário, incluindo a Pontuação de Condição de Raynaud de 10 pontos. Ao usar sildenafila, a frequência média de ataques de Raynaud foi menor (35 ± 14 versus 52 ± 18, p = 0,0064) e a média do _Raynaud's Condition Score_ foi menor (2,2 ± 0,4 versus 3,0 ± 0,5, p = 0,0386). Não houve diferença entre os grupos quanto à incidência de cicatrização de úlceras digitais (RR 5,00; IC95% 0,29 a 86,43) e eventos adversos (RR 25,00; IC95% 1,59 a 392,73). Dentre os eventos adversos ocorridos no grupo que recebeu sildenafila foram relatados dor de cabeça, tontura e dor muscular nas pernas.  
O risco de viés geral do estudo foi julgado como alto. Considerou-se <mark>alto risco para medida do desfecho e algumas preocupações quanto ao processo de randomização, efeito carryover, desvios das intervenções pretendidas e seleção do resultado relatado. A</mark> avaliação completa do risco de viés deste estudo é apresentada na **Figura 18** .  
**Figura 18 -** Risco de viés dos estudos <mark>incluídos avaliando</mark> o uso da sildenafila comparado a outros fármacos ou placebo para o tratamento de úlceras digitais refratárias aos bloqueadores de canais de cálcio na ES.  
<!-- Start of picture text -->
fstudo —_Desfecho DL DS D2 DB Ds DS Gera<br>Fries 2005 Catrzacdo >00e@e000@ @ aisoriseo<br>Fries 2005 score da condicode Raynaud >oo0e68% © ! Algumas preocupacSes<br>Fries2005  Frequéndadeataquesderayrad OH OOOO ® @ terse<br>Fries 2005 Eventos adversos »90e0e020@<br>D1 Processode randomizacao<br>DS Viés proveniente do periodo e efeito carryover<br>02 _Desvios das intervengGes pretendidas<br>3 Dados perdidos do desfecho<br>D4 Mensuragdodo desfecho<br>D5 _Selego do resultado relatado<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que a sildenafila já é um medicamento disponível no SUS e apresenta evidências de efetividade e segurança quando utilizada para tratamento de úlceras digitais refratárias aos bloqueadores dos canais de cálcio em pacientes com ES.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização da sildenafila é indicada em pacientes com ES, com  
os critérios clínicos de elegibilidade que serão descritos a seguir:

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de inclusão</u> -->
- Pacientes que preencherem os critérios do EULAR/EUSTAR de 2013 ou os critérios de LeRoy e Medsger para doença inicial com úlceras digitais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de exclusão</u> -->
- Hipersensibilidade a sildenafila ou quaisquer excipientes da fórmula  
- Uso concomitante de nitratos (risco de hipotensão refratária)  
- Falência cardíaca grave (grau IV) ou angina instável  
- Presença de doença degenerativa da retina, isquemia óptica ou retinopatia proliferativa diabética  
- Alteração hepática grave  
- Função renal alterada com creatinina ≥2,5 mg/dL  
- Gestação ou lactação  
- Pacientes com alterações hemodinâmicas ou hipotensão ortostática  
- Pacientes com doenças que predispõem ao priapismo como anemia falciforme, mieloma ou leucemia  
Para o monitoramento dos pacientes, os especialistas sugerem que devem ser monitorizados os efeitos adversos, sendo os  
mais frequentes (acima de 10%):  
- cefaleia  
- vasodilatação com rubor facial  
- dispepsia  
E menos frequentes (até 10%):  
- epistaxe  
- tonturas  
- congestão nasal  
- distúrbios visuais  
- Sugere-se monitorar pacientes com história de acidente vascular encefálico prévio, infarto agudo do miocárdio ou arritmia grave nos seis meses pregressos ao início do tratamento

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Perfil de evidências:** -->
O **Quadro AA** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os  
principais desfechos.  
**Quadro AA -** Sildenafila comparada a placebo para o tratamento de úlceras digitais refratárias aos bloqueadores de canal de cálcio na ES  
|||**Avalia**|**ção da certeza d**|**a evidência**|||**№ de pac**|**ientes**|**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sildenafila**|**Placebo**|**(Sildenafila versus**<br>**Placebo)**|**evidência**|
|**Cicatriza**|**ção das Úlceras Di**|**gitais**(aval|iado em**4 seman**|**as)**<sup>26</sup>|||||||
|1|ECR do tipo<br>crossover|**grave**<sup>**a**</sup>|não grave|não grave|**muito**<br>**grave**<sup>**b**</sup>|nenhum|2/6|0/6|RR 5,00<br>(IC 95% 0,29 a 86,43)<sup>26</sup>|⨁◯◯◯<br>Muito baixa|
|**Raynaud’**|**s Condition Score**|(avaliado e|m**4 semanas)**<sup>26</sup>||||||||
|1<br>**Frequênc**|ECR do tipo<br>crossover<br>**ia do ataques de R**|**grave**<sup>**a**</sup><br>**aynauld’s**|não grave<br> (avaliado em**4 s**|não grave<br>**emanas)**<sup>26</sup>|**grave**<sup>**c**</sup>|nenhum|16|16|Sildenafil (média)2,2 ±<br>0,4 versus Placebo 3,0 ±<br>0,5, p = 0,0386 <sup>26</sup>|⨁◯◯◯<br>Baixa|
|1|ECR do tipo<br>crossover|**grave**<sup>**a**</sup>|não grave|não grave|**muito**<br>**grave**<sup>**b**</sup>|nenhum|16|16|Sildenafil (média)35 ± 14<br>versus Placebo 52 ± 18, p<br>= 0,0064<sup>26</sup>|⨁◯◯◯<br>Muito baixa|
|**Eventos a**|**dversos**(avaliado e|m**4 seman**|**as)**<sup>26</sup>||||||||
|1|ECR do tipo|**grave**<sup>**a**</sup>|não grave|não grave|**muito**|nenhum|12/18|0/18|RR 25,00|⨁◯◯◯|
||crossover||||**grave**<sup>**b**</sup>||(66,67%)|(0%)|(IC 95% 1,59 a 392,73)<sup>26</sup>|Muito baixa|  
<mark>ECR: Ensaio clínico randomizado; DM</mark> **<mark>:</mark>** <mark>Diferença de Médias</mark>  
<mark>a. Diminuído um nível devido à presença de limitações metodológicas (um estudo com alto risco de viés geral - um estudo com alto risco para medida do desfecho e algumas preocupações quanto ao processo de randomização, efeito carryover, desvios das intervenções pretendidas e seleção do resultado relatado)</mark>  
<mark>b. Diminuído dois níveis devido à presença de tamanho amostral reduzido</mark> e ampla variabilidade ou IC amplo  
c. Diminuído um nível devido à presença de tamanho amostral reduzido

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Perfil de evidências:** -->
26. Fries R, Shariat K, von Wilmowsky H, Böhm M. Sildenafil in the treatment of Raynaud's phenomenon resistant to vasodilatory therapy. Circulation. 2005 Nov 8;112(19):2980-5. doi: 10.1161/CIRCULATIONAHA.104.523324. PMID: 16275885.  
**Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):**  
O **Quadro AB** apresenta o processo de tomada de decisão sobre o uso de sildenafila para o tratamento de úlceras refratárias aos bloqueadores de canais de cálcio em pacientes com ES, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
|**Quadro AB -**Processo de<br>tomada de decisão referente<br>ao uso de sildenafila para<br>tratamento deúlceras digitais<br>refratárias aos bloqueadores<br>de canal de cálcio na<br>ES.**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Efeitos desejáveis:|Pequeno|Sildenafila versus Placebo:<br>_Raynaud's condition score_<br>Sildenafila (média) 2,2 ± 0,4 versus Placebo 3,0 ± 0,5, p = 0,0386;<br>Frequência de ataques de Raynaud:<br>Sildenafila (média) 35 ± 14 versus Placebo 52 ± 18, p = 0,0064|
|Efeitos indesejáveis|Pequeno|Sildenafila versus Placebo:<br>Efeitos Adversos:<br>Sildenafila 66,67% (ex: Dor de cabeça, tontura, dor muscular nas<br>pernas;<br>Placebo 0%|
|Balanço entre riscos e<br>benefícios:|Provavelmente<br>favorece a<br>intervenção|O grupo entende que o balanço é provavelmente favorável à<br>intervenção.|
|Certeza da evidência:|Muito baixa|Julgamento da certeza baseado no método GRADE|
|Recursos requeridos:|Moderados|Sildenafila:<br>R$ 3,94 reais/comprimido de 25 mg,<br>Posologia: 25 mg a cada 8 horas;<br>R$ 354,60 reais por mês e R$ 4.255,00 reais por ano de tratamento<br>para úlceras digitais|
|Viabilidade de<br>implementação:|Sim|Tecnologia já disponível no SUS|
|Outras considerações:|Não informado|Não foram reportadas outras considerações.|  
**QUESTÃO 10.** Deve-se usar prednisona para melhorar o acometimento visceral grave em pacientes com Esclerose Sistêmica?  
**<u>Recomendação:</u>** Sugerimos utilizar prednisona para o tratamento do acometimento visceral grave em pacientes com Esclerose Sistêmica (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica  
**Intervenção:** Prednisona  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão estimada arterial pulmonar; pressão capilar pulmonar; qualidade de vida avaliado por questionários validados; mortalidade; morbidade (crise renal esclerodérmica); sobrevida.  
**Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR avaliando a eficácia da prednisona comparada a outros fármacos ou placebo para o tratamento do acometimento visceral grave na ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro AC** .  
**Quadro AC -** Estratégias de busca para identificação de estudos sobre o uso da prednisona em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Prednisone"[Mesh] OR Prednison* OR Dehydrocortisone OR delta-Cortisone OR<br>Rectodelt OR Sterapred OR Ultracorten OR Winpred OR Apo-Prednisone OR Cortan<br>OR Cortancyl OR Panafcort OR Cutason OR Decortin OR Dacortin OR Decortisyl OR<br>Deltasone OR Encortone OR Encorton OR Enkortolon OR Kortancyl OR Liquid Pred<br>OR Meticorten OR Orasone OR Panasol OR Predni Tablinen OR Prednidib OR<br>Predniment OR Pronisone OR Sone<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-|288|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 #1AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'prednisone'/exp OR prednison* OR ancortone OR apo-prednisone OR biocortone<br>OR colisone OR cortan OR cortidelt OR cortiprex OR cutason OR dacorten OR 'de<br>cortisyl' OR decortancyl OR decortin OR 'decortin e merck' OR decortine OR<br>decortisyl OR dehydrocortisone OR dekortin OR delitisone OR 'dellacort a' OR 'delta<br>1' OR dehydrocortisone OR 'delta cortelan' OR 'delta cortisone' OR 'delta dome' OR<br>'delta e' OR 'delta prenovis' OR delta-dome OR deltacorten OR deltacortene OR<br>deltacortisone OR deltacortone OR deltasone OR deltison OR deltisona OR deltra OR<br>'di adreson' OR di-adreson OR diadreson OR drazone OR encorton OR encortone OR<br>enkorton OR fernisone OR hostacortin OR insone OR 'liquid pred' OR lodotra OR me-<br>korti OR meprison OR metacortandracin OR meticorten OR meticortine OR nisona<br>OR 'nsc 10023' OR 'nsc10023' OR orasone OR orisane OR panafcort OR paracort OR<br>pehacort OR precort OR precortal OR prednicen-m OR prednicorm OR prednicot OR|83|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||prednidib OR prednitone OR pronison OR pronisone OR pronizone OR pulmison OR<br>rayos OR rectodelt OR servisone OR steerometz OR sterapred OR 'sterapred ds' OR<br>ultracorten OR urtilone OR winpred<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7#6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 #1 #OR #2 OR #3<br>#5MeSH descriptor: [Prednisone] explode all trees|63|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#6 Prednison* OR Dehydrocortisone OR delta-Cortisone OR Rectodelt OR Sterapred<br>OR Ultracorten OR Winpred OR Apo-Prednisone OR Cortan OR Cortancyl OR<br>Panafcort OR Cutason OR Decortin OR Dacortin OR Decortisyl OR Deltasone OR<br>Encortone OR Encorton OR Enkortolon OR Kortancyl OR Liquid Pred OR Meticorten<br>OR Orasone OR Panasol OR Predni Tablinen OR Prednidib OR Predniment OR<br>Pronisone OR Sone<br>#7  #5 OR #6<br>#8 #7 AND #4||
|Lilacs<br>via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:Prednisone<br>OR<br>mh:D04.210.500.745.432.719.702$ OR<br>Prednison*<br>OR<br>Dehydrocortisone OR delta-Cortisone OR Rectodelt OR Sterapred OR Ultracorten OR<br>Winpred OR Apo-Prednisone OR Cortan OR Cortancyl OR Panafcort OR Cutason OR<br>Decortin OR Dacortin OR Decortisyl OR Deltasone OR Encortone OR Encorton OR<br>Enkortolon OR Kortancyl OR (Liquid Pred) OR Meticorten OR Orasone OR Panasol<br>OR (Predni Tablinen) OR Prednidib OR Predniment OR Pronisone OR Sone<br>Filter: Lilacs|9|
|Epistemonik<br>os|(title:((Systemic Scleroderma) AND Prednisone) OR abstract:((Systemic Scleroderma)<br>AND Prednisone))|7|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipo de intervenção  
Prednisona em qualquer dose ou forma de administração comparado a outros fármacos ou placebo.  
- (c) Tipos de estudos  
Foram considerados ECR.  
(d) Desfechos de eficácia: função pulmonar; capacidade funcional; resistência vascular pulmonar; pressão arterial pulmonar; pressão capilar pulmonar; qualidade de vida; mortalidade; sobrevida. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: (e) Idioma -->
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 450 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 2 textos completos. Um estudo foi excluído por tratar-se de comparador inadequado<sup>27</sup> . Um estudo foi incluído para auxiliar na tomada de decisão<sup>28</sup> . O processo de seleção é detalhado na **Figura 19** .  
**Figura 19** - Fluxograma de seleção dos estudos <mark>avaliando</mark> o uso da prednisona para o tratamento do acometimento visceral grave na ES.  
<!-- Start of picture text -->
Refer€ncias identificadas por Referéncias removidas antes do<br>. rastreamento:<br>meio “Saleen 480) de Referéncias duplicadas<br>~ removidas (n = 43)<br>Referéncias rastreadas (n = 407) Referéncias excluidas (n = 405)<br>Relatos avaliados para Relatos exctuidos (n = 0)<br>ne<br>elegibilidade (n -= 2) ———s inadequadoEstudos com(n comparador= 1)<br>Estudos incluidos nesta revisao<br>(n=1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés do estudo incluído foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada Risk of bias (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa pós-intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Domiciano et al. (2010)<sup>28</sup> randomizaram 18 pacientes com ES para receber prednisona associada à ciclofosfamida ou ciclofosfamida durante 12 meses. Após 1 ano de tratamento, não houve diferença entre os grupos quanto à função pulmonar avaliada pela CVF (porcentagem do valor predito) (DM -1,22; IC95% -14,33 a 11,89); FEV1 porcentagem do valor predito) (DM -0,46; IC95% -13,66 a 12,74). Entretanto, o grupo prednisona associada à ciclofosfamida apresentou maior capacidade de difusão do monóxido de carbono corrigida pela hemoglobina (DM 18,37; IC95% 4,59 a 32,15) e menor comprometimento cutâneo, conforme avaliado pelo mRSS (DM -13,39; IC95% -3 a -23,78). Com relação à mortalidade, apenas um paciente de cada grupo morreu durante o segundo ano de acompanhamento, ambos por causas não relacionadas ao tratamento: insuficiência cardíaca isquêmica, no grupo ciclofosfamida, e pneumonia aspirativa, no grupo ciclofosfamida associada à prednisona. Quanto aos eventos adversos, taxas semelhantes foram encontradas em ambos os grupos: infecção cutânea ocorreu em dois pacientes (um em cada grupo), sinusite em um paciente (grupo ciclofosfamida), infecção urinária em dois pacientes (grupo <mark>prednisona associada à ciclofosfamida)</mark> e pneumonia bacteriana em um paciente (grupo ciclofosfamida). Todas estas infecções foram leves e tratadas com sucesso por via oral com antibióticos. Dois pacientes (um em cada grupo) evoluíram com linfopenia (cerca de 800 linfócitos/mm<sup>3</sup> ), tratada com redução da dose de ciclofosfamida (0,8 g/cm<sup>2</sup> ).  
O risco de viés geral do estudo foi julgado como alto. Houve algumas preocupações quanto ao processo de randomização e relato seletivo do desfecho e alto risco de viés devido a desvios das intervenções pretendidas. A avaliação completa do risco de viés deste estudo é apresentada na **Figura 20** .  
**Figura 20** - Risco de viés do estudo <mark>incluído avaliando</mark> o uso da prednisona associada à ciclofosfamida comparada à ciclofosfamida para o tratamento do acometimento visceral grave na ES.  
<!-- Start of picture text -->
Estudo Desfecho DL D2 D3 DAS Geral<br>Domiciano 2010 Fungo pulmonar ! @ e e ! e e Baixo risco<br>Domiciano 2010 Mortalidade ! @ e@ ee:  ) ! ‘Algumas preocupagdes<br>Domiciano 2010 Eventos adversos 1@@ @& @ e@ Alto risco<br>D1 Processo de randomizacao<br>02 Desvios das intervenges pretendidas<br>D3 Dados perdidos do desfecho<br>D4 Mensurago do desfecho<br>Ds Selego do resultado relatado<br><!-- End of picture text -->  
O **Quadro AD** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Inclusão</u> -->
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> com acometimento visceral grave.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
- Diabetes mellitus descompensado;  
- Infecção sistêmica;  
- Úlcera péptica ativa;  
- Hipertensão arterial sistêmica (HAS) descompensada.  
**Quadro AD -** Prednisona associada à ciclofosfamida comparado à ciclofosfamida para o tratamento do acometimento visceral grave na ES  
|**№ de**<br>**estudos**<br>**Capacida**|**Delineamento**<br>**do estudo**<br>**de vital força**|**Avalia**<br> <br>**Risco**<br>**de viés**<br>**da**(seguime|**ção da certeza**<br>**Inconsistência**<br>nto:**12 meses**);|**da evidência**<br>**Evidência**<br>**indireta**<br> <sup>28</sup>; avaliado co|**Imprecisão**<br> <br>m: porcentage|**Outras**<br>**considerações**<br>m**do predito)**|**Nº de par**<br>**Prednisona**<br>**associada à**<br>**ciclofosfamida**|**ticipantes**<br>**Ciclofosfamida**|**Ef**<br>**Relativo**<br>**(IC**<br>**95%)**|**eito**<br>**Absoluto**<br>**(IC 95%)**|**Certeza**<br>**da**<br>**evidência**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**Muito**|nenhum|9|9|DM 1,22 m|enor|⨁⨁◯◯|
|**FEV1**(se|guimento:**12 m**|**eses;**<sup>28</sup>; av|aliado com:**%**|**do predito)**|**grave**<sup>**b**</sup>||||(14,33 men<br>maior)<sup>28</sup>|or a 11,89|Muito<br>Baixa<br>|
|1<br>**Capacida**<br>|ECR<br>**de de difusão**<br>|**grave**<sup>**a**</sup><br>**do CO**(seg<br><sup>**a**</sup>|não grave<br>uimento:**12 me**<br>|não grave<br>**ses;**<sup>28</sup>; avaliad<br>|**Muito**<br>**grave**<sup>**b**</sup><br>o com:**% do**<br>|nenhum<br>**predito)**<br>|9<br>|9<br>|DM 0,46 m<br>(13,66 men<br>maior)<sup>28</sup><br>|enor<br>or a 12,74<br>|⨁⨁◯◯<br>Muito<br>Baixa<br>|
|1<br>**Compro**<br>|ECR<br>**metimento cut**<br>|**grave** <br>**âneo**(segui<br>|não grave<br>mento: 12 meses<br>|não grave<br>;<sup>28</sup>; avaliado<br>|**Muito**<br>**grave**<sup>**b**</sup><br>com mRSS)<br>|nenhum<br>|9<br>|9<br>|DM 18,37<br>(4,59 maio<br>maior)<sup>28</sup><br>|maior<br>r a 32,15<br>|⨁⨁◯◯<br>Muito<br>Baixa<br>|
|1|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**Muito**|nenhum|9|9|DM 13,39|menor|⨁⨁◯◯|
|**Mortalid**|**ade**(seguiment|o 12 meses)|;<sup>28</sup>||**grave**<sup>**b**</sup>||||(3 menor a<br>menor)<sup>28</sup>|23,78|Muito<br>Baixa<br>|
|1|ECR|**grave**<sup>**a**</sup>|não grave|não grave|**Muito**<br>**grave**<sup>**b**</sup>|nenhum|1/9<br>(11,11%)|1/9<br>(11,11%)|RR 1,00|0 menos<br>por 1000|⨁◯◯◯<br>Muito<br>baixa|  
<!-- Start of picture text -->
Avaliação da certeza da evidência  Nº de participantes  Efeito<br>Certeza<br>Prednisona  Relativo<br>da<br>№ de  Delineamento  Risco  Evidência  Outras  Absoluto<br>Inconsistência  Imprecisão  associada à  Ciclofosfamida  (IC  evidência<br>estudos  do estudo  de viés  indireta  considerações  (IC 95%)<br>ciclofosfamida  95%)<br>(IC 95%  (103<br>0,07 a  menos a<br>13,64) 28 1000<br>mais)  28<br>Eventos adversos  (seguimento: 12 meses);  28 ; avaliado com infecções cutâneas, urinárias e do trato respiratório<br>1  ECR  grave c  não grave  não grave  Muito  nenhum  3/9  3/9  0 menos  ⨁◯◯◯<br>grave b  (33,33%)  (33,33%)  RR 1,00  por 1000  Muito<br>(IC 95%  (243  baixa<br>0,27 a  menos a<br>3,69)  28 897 mais)<br>28<br>Eventos adversos  (seguimento 12 meses); Linfopenia  28<br>1  ECR  grave c  não grave  não grave  Muito  nenhum  1/9  1/9  0 menos  ⨁◯◯◯<br>grave b  (11,11%)  (11,11%)  RR 1,00  por 1000  Muito<br>(IC 95%  (103  baixa<br>0,07 a  menos a<br>13,64) 28 1000<br>mais)  28<br><!-- End of picture text -->  
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; ECR: Ensaio clínico randomizado.</mark>  
a. Diminuído um nível devido à presença de limitações metodológicas (1 estudo com alto risco de viés geral - algumas preocupações quanto ao processo de randomização e relato seletivo do desfecho e alto risco de viés devido a  
desvios das intervenções pretendidas); b. Diminuído dois níveis devido à presença de tamanho amostral muito reduzido e IC amplo; c. Diminuído dois níveis devido à presença de poucos eventos e IC amplo.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
28. Domiciano, D. S., Bonfá, E., Borges, C. T. L., Kairalla, R. A., Capelozzi, V. L., Parra, E., & Christmann, R. B. (2010). A long-term prospective randomized controlled study of non-specific interstitial pneumonia (NSIP) treatment in scleroderma. Clinical Rheumatology, 30(2), 223–229. doi:10.1007/s10067-010-1493-4

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **QUESTÃO 11. Deve-se usar captopril para o tratamento da crise renal esclerodérmica?** -->
**<u>Recomendação:</u>** Sugerimos utilizar captopril para o tratamento da crise renal esclerodérmica em pacientes com ES (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica **Intervenção:** Captopril  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** controle da Pressão arterial sistêmica; manutenção da Função renal (uréia, creatinina, clearance  
de creatinina); mortalidade; prevenção de complicações como: encefalopatia, edema pulmonar e convulsões; qualidade de vida por questionários validados  
Segurança.  
**Desfechos de segurança:** eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR ou estudos observacionais avaliando a efetividade do captopril para o tratamento da CRE na ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro AE** .  
**Quadro AE -** Estratégias de busca para identificação de estudos sobre o uso do captopril em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*<br>#2 "Captopril"[Mesh] OR Lopirin OR Capoten<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-|63|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5  #3 OR #4<br>#6 (animals NOT humans)<br>#8 - #1 AND #2 AND #5 NOT #6||
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'captopril'/exp OR captopril OR 'ace bloc' OR acenorm OR acepress OR acepril OR<br>aceprilex OR aceril OR aceten OR adocor OR alopresin OR altran OR apuzin OR<br>asisten OR capace OR capocard OR caposan OR capoten OR capotena OR capotril OR<br>capril OR captace OR captensin OR capti OR captoflux OR captohexal OR captolane<br>OR captomax OR capton OR captopren OR captoprilan OR captoril OR captral OR<br>cardiopril OR cardipril OR catona OR catoplin OR catopril OR cesplon OR cryopril<br>OR debax OR dexacap OR ecapres OR ecaten OR epicordin OR epsitron OR farcopril<br>OR farmoten OR hiperil OR hypopress OR hypotensor OR insucar OR iopril OR<br>isopresol OR katopil OR ketanine OR keyerpril OR lapril OR locap OR lopirin OR<br>lopril OR medepres OR midrat OR minitent OR nolectin OR 'oltens ge' OR petacilon<br>OR praten OR primace OR rilcapton OR ropril OR smarten OR 'sq 14225' OR sq14225<br>OR tenofax OR tensicap OR tensiomen OR tensiomin OR tensobon OR tensoprel OR|21|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||tensoril OR tenzib OR topace OR toprilem OR 'typril ace' OR vasosta OR zapto OR<br>zorkaptil<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7#6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor: [Captopril] explode all trees<br>#5 Lopirin OR Capoten<br>#6 #1 OR #2 OR #3|2|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#7 #4 OR #5<br>#8 #6 AND #7||
|Lilacs<br>via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:captopril OR mh:D12.125.072.401.623.270$ OR Capoten OR Lopirin<br>Filter: Lilacs|3|
|Epistemonik<br>os|(title:((Systemic Scleroderma) AND Captopril) OR abstract:((Systemic Scleroderma)<br>AND Captopril))|1|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> com CRE.  
- (b) Tipo de intervenção  
Captopril em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram considerados estudos observacionais.  
- (d) Desfechos de eficácia: controle da Pressão arterial sistêmica; manutenção da Função renal (uréia, creatinina, clearance  
de creatinina); mortalidade; prevenção de complicações como: encefalopatia, edema pulmonar e convulsões; qualidade de vida por questionários validados. Desfechos de segurança: eventos adversos graves; eventos adversos gerais.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 90 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foi avaliado 1 texto completo. Para auxiliar na tomada de decisão, um estudo foi incluído<sup>29</sup> . O processo de seleção é detalhado na **Figura 21** .  
**Figura 21** - Fluxograma de seleção dos estudos <mark>avaliando o</mark> uso de IECA para o tratamento da CRE na ES  
<!-- Start of picture text -->
Referéncias identificadas por Referéncias removidas antes do<br>i tastreamento:<br>meio fades 8 de Referéncias duplicadas<br>~ removidas (n = 4)<br>Referéncias rastreadas (n = 86) Referéncias excluidas (n = 85)<br>Relatos avaliados para Relatos excluidos (n = 0)<br>elegibilidade (n = 1) ><br>Estudos incluidos nesta revisao<br>(n= 1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada _Risk of bias in non-randomised studies_ (ROBINS-I)<sup>30</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor.  
Os desfechos relatados no estudo incluído por meio de variáveis dicotômicas foram sumarizados usando frequências.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Um estudo acompanhou 108 pacientes com ES entre os anos de 1972 e 1987. Os pacientes foram divididos em dois grupos, de acordo com o uso ou não de IECA no tratamento da CRE<sup>29</sup> . Cinqüenta e três pacientes não receberam um IECA e 55 pacientes o fizeram. Quarenta e sete dos cinquenta e cinco pacientes receberam apenas captopril. Um paciente foi inicialmente tratado com enalapril e 7 pacientes apresentaram toxicidade ao captopril (geralmente, uma erupção cutânea) e seus tratamentos foram alterados com sucesso para o enalapril. Os resultados do estudo indicam que a terapia com inibidores da ECA melhorou dramaticamente a sobrevida de pacientes com CRE (sobrevida em 1 ano, 15% sem e 76% com Inibidores de ACE; P <0,001). No entanto, 24 (44%) dos 55 pacientes que foram tratados com inibidores da ECA morreram precocemente ou necessitam de diálise permanente.  
O risco de viés geral do estudo<sup>29</sup> foi julgado como grave. Foi considerado haver grave risco de viés na seleção dos participantes do estudo, desvios das intervenções pretendidas, dados perdidos de desfecho e viés na mensuração do desfecho. Os detalhes da avaliação do risco de viés encontram-se na **Figura 22** .  
**Figura 22** - Risco de viés do estudo <mark>incluído avaliando</mark> o uso de IECA comparado ao não uso para o tratamento da CRE na ES  
<!-- Start of picture text -->
Risk of bias domains<br>i<br>2)<br>se)3— @©eeee0e080<br>Domains: Judgement<br>D1:D2: BiasBias duedue to to selectionconfounding. of participants. cc) Criticalais<br>D3: Bias in classification of interventions. @ serious<br>D4: Bias due to deviations from intended interventions.<br>D5: Bias due to missing data. e@ Moderate<br>D6: Bias in measurement of outcomes. @ tow<br>D7: Bias in selection of the reported result.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Inclusão</u> -->
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial</mark> com CRE.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
- <mark>História de hipersensibilidade ao fármaco ou a qualquer outro componente da fórmula e</mark> gestação.  
O **Quadro AF** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.  
**Quadro AF -** Captopril comparado a controle para o tratamento da crise renal esclerodérmica  
|||**Avali**|**ação da certeza d**|**a evidência**|||**Nº de part**|**icipantes**|**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|---|---|
|**№ de**|**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Captopril**|**Controle**|**(Captopril versus controle )**|**evidência**|
|**estudos**|**do estudo**|**de viés**||**indireta**||**considerações**|||||
|**Sobrevid**|**a; avaliada em 1 a**|**no**<sup>29</sup>|||||||||
|1<br>IC: Intervalo|Observacional<br>de Confiança; DM**:**Di|**grave**<sup>**a**</sup><br>ferença de M|não grave<br>édia; ECR: Ensaio clí|**grave**<sup>**b**</sup><br>nico randomizado|**grave**<sup>**c**</sup><br>|**associação**<br>**forte**<sup>**d**</sup>|55|53|A terapia com inibidores da<br>ECA melhorou a sobrevida em<br>1 ano (15% sem e 76% com<br>Inibidores de ACE; P <0,001)<sup>29</sup>|⨁⨁◯◯<br>Baixa|  
**<mark>Explicações</mark>**  
a.Reduzido um nível devido à presença de limitações metodológicas (um estudo com risco de viés geral grave - grave risco de viés na seleção dos participantes do estudo,  desvios das intervenções pretendidas, dados perdidos de desfecho e viés na mensuração do desfecho).  
b.Reduzido um nível devido à presença de estudo da classe terapêutica. Porém, nem todos os participantes do estudo utilizavam o medicamento em questão  
c.Reduzido um nível devido à presença de tamanho amostral reduzido  
d.Aumentado um nível devido a presença de tamanho de efeito grande

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão</u> -->
29. Steen VD, Costantino JP, Shapiro AP, Medsger TA Jr. Outcome of renal crisis in systemic sclerosis: relation to availability of angiotensin converting enzyme (ACE) inhibitors. Ann Intern Med. 1990 Sep 1;113(5):352-7. doi: 10.7326/0003-4819-113-5-352. PMID: 2382917.  
**QUESTÃO 12.** Deve-se usar metoclopramida para melhora da motilidade esofágica e da plenitude gástrica em pacientes com Esclerose Sistêmica?  
**<u>Recomendação:</u>** Sugerimos utilizar metoclopramida para a melhora da motilidade esofágica e plenitude gástrica em pacientes com ES (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica **Intervenção:** Metoclopramida  
**Comparador:** Outros fármacos ou placebo **Desfechos de eficácia:** melhora da motilidade gastroesofágico; qualidade de vida por instrumentos validados. Desfechos de segurança: efeitos adversos graves; efeitos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para atualizar as evidências acerca da questão. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro AG** .  
**Quadro AG** - Estratégias de busca para identificação de estudos sobre o uso da metoclopramida em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*|16|
||#2 "Metoclopramide"[Mesh] OR Metaclopramide OR Maxolon OR Rimetin OR<br>Metoclopramide OR Monohydrochloride OR Primperan OR Reglan OR Cerucal<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic||  
|**Bases de**<br>**dados**|**Estratégia de busca**<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#8 - #1AND #2 AND #5 NOT #6|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'metoclopramide'/exp OR metoclopramide OR 'ahr 3070 c' OR 'ahr 3070c' OR<br>ahr3070c OR ametic OR anausin OR apo-metoclop OR aputern OR betaclopramide<br>OR bondigest OR 'carnotprim primperan' OR cerucal OR clodilion OR clopamon OR<br>clopan OR clopra OR clopra-yellow OR clopram OR degan OR 'del 1267' OR del1267<br>OR dibertil OR duraclamid OR emenil OR emetal OR emetard OR emitasol OR<br>emperal OR encil OR enzimar OR 'gastro timelets' OR gastrobi OR gastrobid OR<br>'gastrobid continus' OR gastronerton OR gastrosil OR gastrotem OR gastrotimelets OR<br>gavistal OR gensil OR gimoli OR gimoti OR hemesis OR hyrin OR imperan OR 'm<br>813' OR m813 OR 'maalox nausea' OR maril OR maxeran OR maxeron OR maxolan<br>OR maxolon OR 'mcp-beta tropfen' OR meclomid OR meclopamide OR meclopramide<br>OR meclopran OR megaldrate OR meramide OR metaclopramide OR metadrate OR<br>metagliz OR metamide OR methochlopramide OR methoclopramide OR<br>methoclopramine OR metlazel OR metochlopramide OR metoclopamide OR<br>metoclopramid OR metoclor OR metoclorpramide OR metocobil OR metocyl OR|10|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||metodopramide OR metolon OR metopram OR metox OR metozolv OR metpamid OR<br>metram OR moriperan OR mygdalon OR nausil OR neopramiel OR netaf OR 'neu<br>sensamide' OR nilatika OR normastin OR octamide OR opram OR paspertin OR<br>'paspertin retard' OR perinorm OR pharmyork OR plasil OR pramidin OR pramin OR<br>pramotel OR primperan OR primperil OR prinparl OR 'prokinyl lp' OR prowel OR<br>pulin OR reclomide OR reglan OR 'reglan injectable' OR 'reglan odt' OR reliveran OR<br>rimetin OR sensamide OR sotatic-10 OR terperan OR tomid OR vertivom OR vomitrol<br>OR zumatrol<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7 #8 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*<br>#4 MeSH descriptor: [Metoclopramide] explode all trees<br>#5 Metoclopramide OR Metaclopramide OR Maxolon OR Rimetin OR<br>Metoclopramide OR Monohydrochloride OR Primperan OR Reglan OR Cerucal<br>#6 #1 OR #2 OR #3<br>#7 #4 OR #5<br>#8 #6 AND #7|1|
|Lilacs<br>via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh:Metoclopramide<br>OR<br>mh:D02.065.277.573$ OR<br>mh:D02.241.223.100.050.500.647$ OR<br>mh:D02.241.223.100.100.510$ OR<br>mh:D02.241.223.100.200.750$ OR<br>mh:D02.241.223.100.300.350.625$ OR<br>mh:D02.241.511.390.350.625$ OR mh:D02.455.426.559.389.127.020.937.647$ OR<br>mh:D02.455.426.559.389.127.085.510$ OR mh:D02.455.426.559.389.127.250.750$ OR<br>mh:D02.455.426.559.389.127.281.350.625$ OR<br>mh:D02.455.426.559.389.657.654.638.625$ Filter: Lilacs|1|
|Epistemonik<br>os|(title:((Systemic Scleroderma) AND Metoclopramide) OR abstract:((Systemic<br>Scleroderma) AND Metoclopramide))|0|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipo de intervenção  
Metoclopramida em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
- (c) Tipos de estudos  
Foram considerados ECR.  
(d) Desfechos de eficácia: melhora da motilidade gastroesofágico; qualidade de vida. Desfechos de segurança: efeitos adversos graves; efeitos adversos gerais.  
(e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 28 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foi avaliado 1 texto completo. Para auxiliar na tomada de decisão, 1 estudo foi incluído<sup>31</sup> . O processo de seleção é detalhado na **Figura 23** .  
**Figura 23** - Fluxograma de seleção dos estudos <mark>avaliando</mark> o uso da metoclopramida comparada a eritromicina para a melhora da motilidade esofágica na ES  
<!-- Start of picture text -->
Annine j . Referéncias removidas antes do<br>Referénciasia de bi identificadasb: por‘di rastreamento::<br>meio 4 os ( a) e Referéncias duplicadas<br>lados (n = 28) removidas (n = 1)<br>Referéncias rastreadas (n = 27) Referéncias excluidas (n = 26)<br>Relatos avaliados para Relatos excluidos (n = 0)<br>elegibilidade (n = 1) »<br>Estudos incluidos nesta revisao<br>(n= 1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada _Risk of bias_ (ROB) 2.0<sup>5</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor. Os seguintes domínios foram avaliados: viés decorrente do processo de randomização, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados de desfechos, viés na mensuração do desfecho, viés na seleção do resultado relatado e viés geral do estudo. Cada domínio foi julgado como: baixo risco de viés, alto risco de viés ou alguma preocupação quanto ao risco de viés.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa pós-intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
Um estudo comparou eritromicina versus metoclopramida no tempo médio de esvaziamento gástrico em pacientes com ES e atraso no tempo de esvaziamento gástrico<sup>31</sup> . Foram estudados 27 pacientes (26 mulheres e um homem) com idade média de 46 anos. Os pacientes foram randomizados para receber, 20 minutos antes das refeições, eritromicina 250 mg ou metoclopramida 10 mg, durante um mês. O tempo de esvaziamento gástrico foi medido por cintilografia gástrica no início do  
estudo e uma semana após o tratamento. O tempo de esvaziamento gástrico basal no grupo metoclopramida vs eritromicina foi 50,18 ± 23 vs 46,66 ± 18,68, p> 0,05. Quando comparou-se os valores finais, houve diferença entre os grupos quanto ao tempo de esvaziamento gástrico para a comparação metoclopramida vs eritrocicina (42,68 ± 18,50 vs 29,58 ± 6,41 p <0,01).  
O risco de viés geral do estudo<sup>31</sup> foi julgado como alto. Foi considerado haver alto risco de viés devido a desvios das intervenções pretendidas e algumas preocupações quanto ao risco de viés no processo de randomização e na seleção do resultado relatado. Os detalhes da avaliação do risco de viés encontram-se na **Figura 24** .  
**Figura 24** - Risco de viés do estudo <mark>incluído avaliando</mark> o uso da metoclopramida comparada a eritromicina para a melhora da motilidade esofágica na ES  
<!-- Start of picture text -->
aeecEstudo aeecEstudo PD e sfechosee ~~D1 2 03 Da DS Geral e Baixo. risco<br>! Algumas preocupacées<br>DL Processo de randomizac3o<br>D2 Desvios das intervengées pretendidas<br>D3 Dados perdidos do desfecho<br>Da Mensurago do desfecho<br>DS Sele¢&o do resultado relatado<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: <u>Critérios de Exclusão:</u> -->
- História de hipersensibilidade ao fármaco ou a qualquer outro componente da fórmula;  
- Contraindicado em situações em que a estimulação da motilidade gastrintestinal seja perigosa, como por exemplo, na presença de hemorragia gastrintestinal, obstrução mecânica ou perfuração gastrintestinal; em pacientes epiléticos ou que estejam recebendo outros medicamentos que possam causar reações extrapiramidais, uma vez que a frequência e intensidade destas reações podem ser aumentadas; em pacientes com feocromocitoma, pois pode desencadear crise hipertensiva, devido à provável liberação de catecolaminas do tumor.  
O **Quadro AH** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os principais desfechos.  
**Quadro AH -** Metoclopramida comparado a controle para o tratamento da motilidade esofágica e plenitude gástrica em pacientes com ES  
|||**Avali**|**ação da certeza d**|**a evidência**|||**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|
|**№ de**|**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**(Metoclopramida versus controle)**|**evidência**|
|**estudos**|**do estudo**|**de viés**||**indireta**||**considerações**|||
|**Tempo de**<br>1<br>IC: Intervalo|**esvaziamento gá**<br>ECR<br>de Confiança; DM**:**Di|**strico; av**<br>**grave**<sup>**a**</sup><br>ferença de M|**aliado em 1 mês** <br>não grave<br>édia; ECR: Ensaio clí|<sup>31</sup><br>não grave<br>nico randomizado|**grave**<sup>**b**</sup><br>.|**nenhum**|Houve diferença entre os grupos quanto ao tempo de<br>esvaziamento gástrico avaliado no final (pós) do estudo<br>no grupo metoclopramida vs eritromicina (42,68 ± 18,50<br>vs 29,58 ± 6,41 p <0,01); 27 participantes; 1 estudo<sup>31</sup>|⨁⨁◯◯<br>Baixa|

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Tempo de esvaziamento gástrico; avaliado em 1 mês**<sup>31</sup> -->
a. Reduzido um nível devido à presença de limitações metodológicas (um estudo com risco de viés geral alto -  alto risco de viés devido a desvios das intervenções pretendidas e algumas preocupações quanto ao risco de viés no processo de randomização e na seleção do resultado relatado).  
b. Reduzido um nível devido à presença de tamanho amostral reduzido

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Tempo de esvaziamento gástrico; avaliado em 1 mês**<sup>31</sup> -->
31.Vera Lastra O, Rodríguez Molinar LE, Normandia Almeida A, Rodríguez Alejandre A, Lira Carreón CE, Jara LJ, et al. Utilidad de la eritromicina en la gastroparesia por esclerodermia. Estudio comparativo con metoclopramida. Rev mex Reum. 2001;361–6.  
**QUESTÃO 13.** Deve-se usar omeprazol para melhora do refluxo gastroesofágico em pacientes com Esclerose Sistêmica? **<u>Recomendação:</u>** <u>Sugerimos utilizar omeprazol para a melhora do refluxo gastroesofágico em pacientes com ES</u> (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Esclerose Sistêmica **Intervenção:** Omeprazol  
**Comparador:** Outros fármacos ou placebo  
**Desfechos de eficácia:** melhora da motilidade gastroesofágico; qualidade de vida por instrumentos validados. **Desfechos de segurança** : eventos adversos graves; eventos adversos gerais.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Métodos e resultados da busca** -->
Foi realizada uma busca sistematizada nas bases MEDLINE via Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) e Epistemonikos para localizar ECR ou estudos observacionais avaliando a eficácia do omeprazol para a melhora do refluxo gastroesofágico na ES. A busca foi realizada em 22 de julho de 2021. As estratégias de busca para cada base estão descritas no **Quadro AI** .  
**Quadro AI -** Estratégias de busca para identificação de estudos sobre o uso do omeprazol em pacientes com ES  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via Pubmed|#1 "Scleroderma, Systemic"[Mesh] OR "Scleroderma, Diffuse"[Mesh] OR Systemic<br>Scleros* OR Systemic Scleroderma*|23|
||#2 "Omeprazole"[Mesh] OR Prilosec OR Omeprazole Sodium OR Omeprazole<br>Magnesium<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR mixed-<br>treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR<br>systematic overview*[tiab] OR methodological overview*[tiab] OR methodologic||  
|**Bases de**<br>**dados**|**Estratégia de busca**<br>overview*[tiab] OR methodological review*[tiab] OR methodologic review*[tiab] OR<br>quantitative review*[tiab] OR quantitative overview*[tiab] OR quantitative<br>synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR<br>Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR<br>meta-regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR<br>der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 #1 AND #2 AND #5 NOT #7|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|EMBASE|#1 'systemic sclerosis'/exp OR 'systemic sclerosis' OR 'sclerosis, systemic' OR<br>'sclerosis, progressive' OR 'progressive sclerosis' OR 'scleroderma'/exp OR<br>scleroderma OR dermatosclerosis OR schleroderma OR sclerema OR sclerodermia OR<br>'skin sclerosis'<br>#2 'omeprazole'/exp OR benzimidazole OR aleprozil OR antra OR 'antra mups' OR<br>arapride OR audazol OR baromezole OR desec OR dolintol OR domer OR dudencer<br>OR duogas OR  emeproton OR epirazole OR ezipol OR gasec OR 'gasec gastrocaps'<br>OR gastec OR gastop OR gastrimut OR gastrolac OR gastroloc OR glaveral OR<br>hovizol OR hyposec OR inhibitron OR inhipump OR logastric OR lomac OR lopraz<br>OR losamel OR losec OR losec mups OR losecosan OR ludea OR madiprazole OR<br>maxor OR medoprazole OR medral OR meiceral OR mepral OR mepzol OR<br>mezzopram OR miol OR miracid OR mopral OR mopralpro OR nocid OR ocid OR<br>ogal OR olexin OR omedar OR omelon OR 'omep uno' OR omepral OR  omeprazen<br>OR omeprazol OR 'omeprazole magnesium' OR 'omeprazole sodium'  OR omeprazon<br>OR omepril OR omeraz OR omesec OR omestad OR omezin OR omezol OR omezolan<br>OR omezole OR omezzol OR omisec OR omizac OR omolin OR ompranyt OR<br>omprazole OR onexal OR oprax OR ozoken OR parizac OR penrazole OR pepticum<br>OR peptidin OR peptilcer OR peptizole OR pra-sec OR prazidec OR prazole OR|1|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||prilosec OR 'prilosec otc' OR  prisolec OR probitor OR proceptin OR protoloc OR<br>ramezol OR reglacid OR 'result (drug)'  OR risek OR romep OR roweprazol OR<br>secrepina OR severon; OR stomacer OR stomec OR stozole OR suifac OR ulceral OR<br>ulcozol OR ulnor OR ulsek OR ulsen OR ulzol OR vulcasid OR wonmp OR xoprin<br>OR zatrol OR zefxon OR zenpro OR zimor OR zoltum<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR crossover*<br>OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR singl* NEAR/1<br>blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti OR<br>metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3 (literature*<br>OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti) OR ((data<br>NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR medlars:ab,ti OR<br>embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti<br>OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti<br>OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data base'<br>OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR ((review* OR<br>overview*) NEAR/10 (systematic* OR methodologic* OR quantitativ* OR research*<br>OR literature* OR studies OR trial* OR effective*)):ab NOT (((retrospective* OR<br>record* OR case* OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*)<br>NEAR/2 chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp<br>NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7 #6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim]||
|Cochrane<br>Library|#1 MeSH descriptor: [Scleroderma, Systemic] explode all trees<br>#2 MeSH descriptor: [Scleroderma, Diffuse] explode all trees<br>#3 Systemic Scleros* OR Systemic Scleroderma*|4|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#4 #1 #OR #2 OR #3<br>#5 MeSH descriptor: [Omeprazole] explode all trees<br>#6 Omeprazole Sodium OR  Omeprazole Magnesium<br>#7  #5 OR #6<br>#8 #7 AND #4||
|Lilacs<br>via<br>Portal BVS|mh:"Scleroderma, Systemic" OR (Systemic Scleros*) OR (Systemic Scleroderma*)<br>OR mh:C17.300.799$ OR mh:C17.800.784$ OR mh:"Scleroderma, Diffuse"OR<br>mh:C17.300.799.602$ OR mh:C17.800.784.602$ AND<br>mh: Omeprazol OR Omeprazole OR Oméprazole OR mh: D02.886.640.074.500$  OR<br>D03.383.725.024.500$ OR  D03.633.100.103.034.500$ Filter: Lilacs|0|
|Epistemonik<br>os|(title:(Systemic<br>Scleroderma)<br>OR<br>abstract:(Systemic<br>Scleroderma))<br>AND<br>(title:(Omeprazole) OR abstract:(Omeprazole))|0|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
<mark>Pacientes com ES classificados por meio dos critérios de classificação do</mark> _<mark>American College of Rheumatology/European</mark>_  
_<mark>League Against Rheumatism</mark>_ <mark>de 2013 ou os critérios de LeRoy e Medsger para doença inicial.</mark>  
- (b) Tipo de intervenção  
Omeprazol em qualquer dose ou forma de administração comparado a outros fármacos ou PBO.  
(c) Tipos de estudos  
Revisões sistemáticas de ECRs (recentes e de qualidade adequada). Na ausência de revisões sistemáticas recentes e de adequada qualidade, foram considerados ECRs.  
(d) Desfechos: melhora da motilidade gastroesofágico; qualidade de vida por instrumentos validados; eventos adversos graves e eventos adversos gerais.  
(e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Resultados da busca</u>** -->
Foram recuperadas 28 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foi avaliado 1 texto completo. Um estudo foi incluído  
para auxiliar na tomada de decisão<sup>32</sup> . O processo de seleção é detalhado na **Figura 25** .  
**Figura 25** - Fluxograma de seleção dos estudos <mark>avaliando</mark> o uso do omeprazol para o tratamento do refluxo gastroesofágico na ES  
<!-- Start of picture text -->
Bone 4 . Referéncias removidas antes do<br>Referéncias identificadas por<br>A rastreamento:<br>meio de busca nas bases de Referéncias duplicadas<br>dados (n = 28) removidas (n = 1)<br>Referéncias rastreadas (n = 27) Referéncias excluidas (n = 26)<br>Relatos avaliados para ; _<br>elegibilidade (n = 1) —______»| Relatos exciuidos (n = 0)<br>Estudos incluidos nesta revisao<br>(n= 1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **<u>Análise e apresentação dos resultados</u>** -->
A avaliação do risco de viés foi realizada por dois avaliadores por meio da ferramenta elaborada pela Cochrane, denominada _Risk of bias in non-randomised studies_ (ROBINS-I)<sup>30</sup> em estudo de um único braço, como descrito por Jullien et al<sup>33</sup> . Eventuais discordâncias entre os avaliadores quanto ao julgamento do estudo foram resolvidas em consenso ou, se necessário, mediante consulta a um terceiro revisor.  
Os desfechos relatados no estudo incluído por meio de variáveis contínuas foram apresentados por meio de DM entre os grupos (estimativa do pós-pré intervenção) com IC de 95%. As variáveis dicotômicas foram sumarizadas usando RR com IC de 95%.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Resumo das evidências:** -->
<mark>Um estudo avaliou os efeitos do omeprazol no tratamento do refluxo gastroesofágico em indivíduos com ES. Neste estudo</mark><sup>32</sup> <mark>, vinte e cinco pacientes com ES e doença do refluxo gastroesofágico grave foram tratados com 20 a 80 mg de omeprazol por dia por até 5 anos. O tempo com pH abaixo de 4 durante a pHmetria ambulatorial de 24 h foi de 36% na pré-entrada (1097%, mediana e intervalo) e 13% (6-41%) após, pelo menos, 6 meses de tratamento com omeprazol. Descobriu-se que treze pacientes tinham refluxo gastroesofágico residual, apesar de estarem em tratamento.</mark>  
O risco de viés geral do estudo foi julgado como crítico. Foi considerado haver moderado risco de viés por desvio das intervenções pretendidas e mensuração do desfecho e risco crítico de viés para confundidores. A avaliação completa do risco de viés deste estudo é apresentada na **Figura 26** .  
**Figura 26** - Risco de viés do estudo <mark>incluído avaliando</mark> o uso do omeprazol para o tratamento do refluxo gastroesofágico na ES.  
<!-- Start of picture text -->
Risk of bias domains<br>><br>ro}<br>be);a © €e@20280@008@<br>Domains: Judgement<br>D1: Bias due to confounding. ae<br>D2: Bias due to selection of participants. @ Gitar<br>D3:D4: BiasBias indue classificationto deviationsof interventions.from intended interventions. e@ Moderate<br>D5: Bias due to missing data. e Low<br>D6: Bias in measurement of outcomes.<br>D7: Bias in selection of the reported result.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que esta atualização deveria manter a recomendação que já constava do PCDT  
publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 9, de 28 de agosto de 2017.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Considerações gerais e para implementação** -->
<u>Critérios de Exclusão:</u>  
- História de hipersensibilidade ao fármaco ou a qualquer outro componente da fórmula.  
O **Quadro AJ** apresenta os resultados dos estudos incluídos e da avaliação da certeza da evidência (GRADE) para os  
principais desfechos.  
**Quadro AJ -** Omeprazol para o tratamento do refluxo gastroesofágico em pacientes com ES  
|||**Avali**|**ação da certeza d**|**a evidência**|||**Efeito**|**Certeza da**|
|---|---|---|---|---|---|---|---|---|
|**№ de**|**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**(Omeprazol)**|**evidência**|
|**estudos**<br>**Phmetria;**|**do estudo**<br> <sup>32</sup>|**de viés**||**indireta**||**considerações**|||
|1|Observacional|**muito**<br>**grave**<sup>**a**</sup>|não grave|não grave|**grave**<sup>**b**</sup>|**nenhum**|O tempo com pH abaixo de 4 durante a pHmetria<br>ambulatorial de 24 h foi de 36% na pré-entrada (10-97%,<br>mediana e intervalo) e 13% (6-41%) após pelo menos 6<br>meses de tratamento com omeprazol; 25 participantes<br>(braço único); 1 estudo<sup>32</sup>|⨁⨁◯◯<br>Baixa|

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Phmetria;**<sup>32</sup> -->
<mark>IC: Intervalo de Confiança; DM</mark> **<mark>:</mark>** <mark>Diferença de Média; ECR: Ensaio clínico randomizado;</mark>  
**<mark>Explicações</mark>**  
a.Reduzido um nível devido à presença de limitações metodológicas (um estudo com risco de viés geral crítico -  moderado risco de viés por desvio das intervenções pretendidas e mensuração do desfecho e risco crítico de viés para confundidores).  
b.Reduzido um nível devido à presença de tamanho amostral reduzido

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **Phmetria;**<sup>32</sup> -->
32.Hendel L, Hage E, Hendel J, Stentoft P. Omeprazole in the long‐term treatment of severe gastro‐oesophageal reflux disease in patients with systemic sclerosis. Aliment Pharmacol Ther. 1992;6(5):565–77.

---

<!-- METADADOS: doenca: Esclerose Sistêmica | secao: **REFERÊNCIAS** -->
1. Group. GW. Grading quality of evidence and strength of recommendations. Bmj, [Internet]. 2004; 328:1490. Available from: https://www.gradeworkinggroup.org/  
2. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews. Syst Rev. 2016 Dec 5;5.  
3. Seibold JR, Maher TM, Highland KB, Assassi S, Azuma A, Hummers LK, et al. Safety and tolerability of nintedanib in patients with systemic sclerosis-associated  interstitial lung disease: data from the SENSCIS trial. Ann Rheum Dis. 2020 Nov;79(11):1478–84.  
4. Distler O, Highland KB, Gahlemann M, Azuma A, Fischer A, Mayes MD, et al. Nintedanib for Systemic SclerosisAssociated Interstitial Lung Disease. N Engl J Med. 2019 Jun;380(26):2518–28.  
5. Higgins JPT, Thomas J, Chandler J, Cumpston M, Li T, Page MJ WV (editors). Cochrane [Internet]. Cochrane Handbook for Systematic Reviews of Interventions version 6.2 (updated February 2021). 2021. Available from: Available from www.training.cochrane.org/handbook.  
6. Daoussis D, Melissaropoulos K, Sakellaropoulos G, Antonopoulos I, Markatseli TE, Simopoulou T, et al. A multicenter, open-label, comparative study of B-cell depletion therapy with  Rituximab for systemic sclerosis-associated interstitial lung disease. Semin Arthritis Rheum. 2017 Apr;46(5):625–31.  
7. Daoussis D, Liossis S-NC, Tsamandas AC, Kalogeropoulou C, Kazantzi A, Sirinian C, et al. Experience with rituximab in scleroderma: results from a 1-year, proof-of-principle  study. Rheumatology (Oxford). 2010 Feb;49(2):271–80.  
8. Boonstra M, Meijs J, Dorjée AL, Marsan NA, Schouffoer A, Ninaber MK, et al. Rituximab in early systemic sclerosis. RMD open [Internet]. 2017 Jul 28;3(2):e000384–e000384. Available from: https://pubmed.ncbi.nlm.nih.gov/28879049  
9. Ebata S, Yoshizaki A, Oba K, Kashiwabara K, Ueda K, Umemura Y, Watadani T, Fukasawa T, Miura S, YoshizakiOgawa A, Asano Y, Okiyama N, Kodera M, Hasegawa M SS. Safety and Efficacy of Rituximab for Systemic Sclerosis: A Double-Blind, Parallel-Group Comparison, Investigators Initiated Confirmatory Randomized Clinical Trial (DESIRES Study) [abstract]. Arthritis Rheumatol. 2021;73(suppl 10).  
10. Sircar G, Goswami RP, Sircar D, Ghosh A, Ghosh P. Intravenous cyclophosphamide vs rituximab for the treatment of early diffuse  scleroderma lung disease: open label, randomized, controlled trial. Rheumatology (Oxford). 2018 Dec;57(12):2106–13.  
11. Owen C, Ngian G-S, Elford K, Moore O, Stevens W, Nikpour M, et al. Mycophenolate mofetil is an effective and safe option for the management of systemic sclerosis-associated interstitial lung disease: results from the Australian Scleroderma Cohort Study. Clin Exp Rheumatol. 2016;34(5):170–6.  
12. Nadashkevich O, Davis P, Fritzler M, Kovalenko W. A randomized unblinded trial of cyclophosphamide versus azathioprine in the  treatment of systemic sclerosis. Clin Rheumatol. 2006 Mar;25(2):205–12.  
13. Derk CT, Grace E, Shenin M, Naik M, Schulz S, Xiong W. A prospective open-label study of mycophenolate mofetil for the treatment of diffuse  systemic sclerosis. Rheumatology (Oxford). 2009 Dec;48(12):1595–9.  
14. Tashkin DP, Roth MD, Clements PJ, Furst DE, Khanna D, Kleerup EC, et al. Mycophenolate mofetil versus oral cyclophosphamide in scleroderma-related  interstitial lung disease (SLS II): a randomised controlled, double-blind, parallel group trial. Lancet Respir Med. 2016 Sep;4(9):708–19.  
15. Naidu GSRSNK, Sharma SK, Adarsh MB, Dhir V, Sinha A, Dhooria S, et al. Effect of mycophenolate mofetil (MMF) on systemic sclerosis-related interstitial  lung disease with mildly impaired lung function: a double-blind, placebocontrolled, randomized trial. Rheumatol Int. 2020 Feb;40(2):207–16.  
16. Hoyles RK, Ellis RW, Wellsbury J, Lees B, Newlands P, Goh NSL, et al. A multicenter, prospective, randomized, doubleblind, placebo-controlled trial of  corticosteroids and intravenous cyclophosphamide followed by oral azathioprine for the  
treatment of pulmonary fibrosis in scleroderma. Arthritis Rheum. 2006 Dec;54(12):3962–70.  
17. Tashkin DP, Elashoff R, Clements PJ, Goldin J, Roth MD, Furst DE, et al. Cyclophosphamide versus placebo in scleroderma lung disease. N Engl J Med. 2006 Jun;354(25):2655–66.  
18. Rahman, M.N.; Islam, M.N.; Hassan, M.; Islam MA. Efficacy and safety of 25 mg methotrexate in early diffuse systemic sclerosis: A randomized controlled trial. Int J Rheum Dis. 2020;23(0):274.  
19. Pope JE, Bellamy N, Seibold JR, Baron M, Ellman M, Carette S, et al. A randomized, controlled trial of methotrexate versus placebo in early diffuse  scleroderma. Arthritis Rheum. 2001 Jun;44(6):1351–8.  
20. Van den Hoogen FHJ, Boerbooms AMT, Swaak AJG, Rasker JJ, Van Lier HJJ, Van De Putte LBA. Comparison of methotrexate with placebo in the treatment of systemic sclerosis: a 24 week randomized double-blind trial, followed by a 24 week observational trial. Rheumatology. 1996;35(4):364–72.  
21. Rirash F, Tingey PC, Harding SE, Maxwell LJ, Tanjong Ghogomu E, Wells GA, et al. Calcium channel blockers for primary and secondary Raynaud’s phenomenon. Cochrane database Syst Rev. 2017 Dec;12(12):CD000467.  
22. Kahan A, Weber S, Amor B, Menkes CJ, Hodara M, Degeorges M. Nifedipine and Raynaud’s phenomenon associated with connective tissue diseases. Int Angiol. 1985;4(2):221–3.  
23. Whiting P, Savović J, Higgins JPT, Caldwell DM, Reeves BC, Shea B, et al. ROBIS: A new tool to assess risk of bias in systematic reviews was developed. J Clin Epidemiol. 2016 Jan;69:225–34.  
24. Thompson AE, Shea B, Welch V, Fenlon D, Pope JE. Calcium-channel blockers for Raynaud’s phenomenon in systemic sclerosis. Arthritis Rheum. 2001 Aug;44(8):1841–7.  
25. Hachulla E, Hatron P, Carpentier P, Agard C, Chatelus E, Jego P, et al. OP0058 Efficacy of Sildenafil on Ischaemic Digital Ulcer Healing in Systemic Sclerosis: The Placebo-Controlled Seduce Study. Ann Rheum Dis. 2015 May 20;74.  
26. Fries R, Shariat K, von Wilmowsky H, Böhm M. Sildenafil in the treatment of Raynaud’s phenomenon resistant to vasodilatory  therapy. Circulation. 2005 Nov;112(19):2980–5.  
27. Pérez Campos D, Estévez Del Toro M, Peña Casanovas A, González Rojas PP, Morales Sánchez L, Gutiérrez Rojas AR. Are high doses of prednisone necessary for treatment of interstitial lung disease in  systemic sclerosis? Reumatol Clin. 2012;8(2):58–62.  
28. Domiciano DS, Bonfá E, Borges CTL, Kairalla RA, Capelozzi VL, Parra E, et al. A long-term prospective randomized controlled study of non-specific interstitial  pneumonia (NSIP) treatment in scleroderma. Clin Rheumatol. 2011 Feb;30(2):223–9.  
29. Steen VD, Costantino JP, Shapiro AP, Medsger TAJ. Outcome of renal crisis in systemic sclerosis: relation to availability of  angiotensin converting enzyme (ACE) inhibitors. Ann Intern Med. 1990 Sep;113(5):352–7.  
30. Sterne JA, Hernán MA, Reeves BC, Savović J, Berkman ND, Viswanathan M, et al. ROBINS-I: a tool for assessing risk of bias in non-randomised studies of  interventions. BMJ. 2016 Oct;355:i4919.  
31. Vera Lastra O, Rodríguez Molinar LE, Normandia Almeida A, Rodríguez Alejandre A, Lira Carreón CE, Jara LJ, et al. Utilidad de la eritromicina en la gastroparesia por esclerodermia. Estudio comparativo con metoclopramida. Rev mex Reum. 2001;361–6.  
32. Hendel L, Hage E, Hendel J, Stentoft P. Omeprazole in the long‐term treatment of severe gastro‐oesophageal reflux disease in patients with systemic sclerosis. Aliment Pharmacol Ther. 1992;6(5):565–77.  
33. Jullien S, Ryan H, Modi M, Bhatia R. Six months therapy for tuberculous meningitis. Cochrane Database Syst Rev. 2016;(9).

---

