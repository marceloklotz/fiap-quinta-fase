<!-- METADADOS: doenca: Miastenia Gravis | secao: Geral -->
<!-- Start of picture text -->
aE:<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 11, DE 23 DE MAIO DE 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Miastenia Gravis.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a miastenia gravis no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 575/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 580 – Dezembro de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Miastenia Gravis.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da miastenia gravis, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser</u> utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da miastenia gravis.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria SAS/MS nº 1.169, de 19 de novembro de 2015, publicada no Diário Oficial da União nº 222, de 20 de novembro de 2015, seção 1, página 82.  
Art. 5º  Esta Portaria entra em vigor na data de sua publicação.  
MAÍRA BATISTA BOTELHO  
SANDRA DE CASTRO BARROS

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **1. INTRODUÇÃO** -->
A Miastenia _Gravis_ (MG) é uma doença autoimune da junção neuromuscular, cuja principal característica é fraqueza muscular flutuante, que melhora com o repouso e piora com o exercício ou ao longo do dia. A fraqueza pode ser limitada a grupos musculares específicos (músculos oculares, faciais, bulbares) ou ser generalizada. A crise miastênica (CM) é definida por insuficiência respiratória associada à fraqueza muscular grave<sup>1</sup> .  
A incidência da MG varia de 5 a 30 casos por milhão de habitantes por ano<sup>2</sup> , e a prevalência de 100 a 200 casos por milhão de habitantes, havendo um discreto predomínio em mulheres<sup>3</sup> . A idade de início é bimodal, sendo os picos de ocorrência em torno de 20-34 anos para mulheres e 70-75 anos para homens<sup>4</sup> .  
Na maioria dos pacientes (cerca de 85%), a MG é causada por anticorpos contra receptores de acetilcolina (anti-AChR). O segundo anticorpo mais frequente é o anticorpo anti-tirosinoquinase músculo específico (anti-MuSk) (7%)<sup>1</sup> .  Pela resposta imunológica desencadeada, verificam-se alterações estruturais e funcionais da junção neuromuscular<sup>5</sup> .  
Nos casos de MG autoimune, outras afecções de mesma natureza podem coexistir em pacientes com diagnóstico de MG, devendo ser rastreadas de forma racional<sup>6</sup> , incluindo doenças do timo.  Setenta por cento dos pacientes têm hiperplasia de timo e aproximadamente 10% têm timoma – com potencial para comportamento maligno –, sendo este mais comum em pacientes entre 50 e 70 anos de idade. Entre outras doenças possivelmente concomitantes, estão a doença de Graves, artrite reumatoide, lúpus eritematoso sistêmico, síndrome de Sjögren, aplasia de células vermelhas, colite ulcerativa e doença de Addison<sup>7</sup> .  
As complicações mais relevantes da MG são tetraparesia e insuficiência respiratória, e a mortalidade dos pacientes reduziu de forma significativa nos últimos anos (0,06 a 0,89 por milhão de pessoas/ano), graças aos avanços na área da medicina intensiva<sup>1,8,9</sup> .  
O tratamento da doença objetiva o controle dos sintomas motores característicos, a diminuição das exacerbações, o aumento do período em remissão e o tratamento das crises miastênicas. O comportamento da MG frente à gestação, a cirurgias de grande porte e ao uso de anestésicos, outros medicamentos e miastenia neonatal e congênita serão abordados em casos especiais.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa estabelecer os critérios diagnósticos e terapêuticos da miastenia gravis. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- G70.0 Miastenia gravis  
- G70.2 Miastenia congênita e do desenvolvimento

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **3. DIAGNÓSTICO** -->
O diagnóstico da MG baseia-se tanto nas manifestações clínicas neuromusculares como também exames complementares (provas sorológicas e estudo eletroneuromiográfico)<sup>10</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **3.1.     Diagnóstico Clínico** -->
<mark>A doença é clinicamente caracterizada por progressiva fraqueza e fadiga da musculatura musculoesquelética, muitas vezes</mark>  
<mark>de caráter flutuante.  A sensibilidade diagnóstica também varia consideravelmente dependendo se o paciente tem apresentação ocular ou generalizada.</mark>  
<mark>Apesar de que a MG possa reproduzir fraqueza em qualquer grupo muscular, existem certas apresentações que são características da doença. A grande maioria dos pacientes apresenta manifestações oculares como ptose ou diplopia e, destes casos, cerca de metade desenvolve doença generalizada em dois anos</mark><sup>11</sup> <mark>. Em torno de 15% dos pacientes apresentam sintomas bulbares como disartria, disfagia ou fadiga ao mastigar. Uma menor porcentagem dos casos inaugura sua apresentação com sinais de fraqueza em áreas focais e isoladas como a região cervical e respiratória</mark><sup>12</sup> <mark>.</mark>  
<mark>Os pacientes com MG podem ser classificados de acordo com C</mark> lassificação clínica da _Myasthenia Gravis Foundation of America_ (MFGA) ( **Quadro 1** )<sup>13</sup> .  
**Quadro 1** - Classificação clínica da MG conforme MGFA<sup>13</sup>  
|**CLASSE I**|**Qualquer fraqueza do músculo ocular**<br>**Fraqueza ao fechamento ocular**<br>**Força normal em outros músculos**|
|---|---|
|**CLASSE II**|**Fraqueza menor em outros músculos, além do músculo ocular**<br>**Fraqueza do músculo ocular de qualquer gravidade**|
|IIa|Predominantemente, acometendo músculos dos membros, tronco ou ambos.<br>Menor acometimento dos músculos da orofaringe.|
|IIb|Predominantemente, acometendo músculos da orofaringe, respiratórios ou ambos.<br>Menor acometimento dos músculos dos membros, tronco ou ambos.|
|**CLASSE III**|**Fraqueza moderada em outros músculos, além do músculo ocular**<br>**Fraqueza do músculo ocular de qualquer gravidade**|
|IIIa|Predominantemente, acometendo músculos dos membros, tronco ou ambos.<br>Menor acometimento dos músculos da orofaringe.|
|IIIb|Predominantemente, acometendo músculos da orofaringe, respiratórios ou ambos.<br>Menor acometimento dos músculos dos membros, tronco ou ambos.|
|**CLASSE IV**|**Fraqueza acentuada, acometendo outros músculos além do músculo ocular**<br>**Fraqueza do músculo ocular de qualquer gravidade**|
|IVa|Predominantemente, acometendo músculos dos membros, tronco ou ambos.<br>Menor acometimento dos músculos da orofaringe|
|IVb|Predominantemente, acometendo músculos da orofaringe, respiratórios ou ambos.<br>Menor acometimento dos músculos dos membros, tronco ou ambos.|
|**CLASSE V**|Intubação com ou sem ventilação mecânica, exceto quando usado no cuidado rotineiro no pós-operatório.|  
O uso de sonda nasogátrica sem intubação coloca o paciente em CLASSE IVb.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **3.2 Exames complementares** -->
Os exames complementares de eletroneuromiografia ou dosagem sérica de anticorpos são confirmatórios e essenciais para o diagnóstico da doença. O exame de dosagem sérica de anticorpos de acetilcolina (anti-AChR) deve ser priorizado.  
- Eletroneuromiografia: estimulação nervosa repetitiva, realizado durante a eletroneuromiografia, é o teste de escolha para avaliação de pacientes com potencial disfunção da junção neuromuscular, variando a sensibilidade conforme o segmento anatômico. O estudo será positivo caso seja registrado um decremento do potencial de ação muscular composto maior que 10% na comparação entre o primeiro e o quarto ou quinto estímulo. Se disponível no serviço, pode ser realizada a eletromiografia de fibra única.  
- Dosagem sérica de anticorpos: o exame laboratorial mais comumente utilizado mede a quantidade de anti-AChR. Existem 3 subtipos de anticorpos: ligador, modulador e bloqueador14 e a presença de qualquer um dos três confirma o diagnóstico. O subtipo ligador é o mais importante e prevalente. Cerca de 50% e 85%-90% dos pacientes com MG ocular e generalizada, respectivamente, apresentam positividade<sup>15,16</sup> . Os valores de referência podem variar entre laboratórios<sup>17</sup> , mas para os exames com registro ativo no Brasil, valores inferiores a 0,25 nmol/L indicam negatividade; entre 0,25 e 0,40 nmol/L são inconclusivos; e superiores a 0,40 nmol/L indicam positividade<sup>18</sup> . No caso de resultados inconclusivos, o diagnóstico deve se basear em achados clínicos e eletroneuromiográficos. Ressalta-se que a dosagem desses anticorpos parece ter correlação baixa com gravidade progressão de doença, não sendo recomendado para avaliação de resposta ao tratamento<sup>1,17</sup> .  
- Outros exames: uma vez confirmado o diagnóstico, deve-se investigar a ocorrência concomitante de outras doenças frequentemente associadas com MG. Especialmente, preconiza-se investigação radiológica do mediastino, para a avaliação do timo.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **3.3.  Diagnóstico diferencial** -->
Doenças que causam fraqueza muscular sistêmica ou de nervos cranianos podem ser confundidas ou mimetizar MG. A disfunção da junção neuromuscular pode ser induzida por fármacos específicos (penicilamina, agentes curarizantes, procainamida, quininas, aminoglicosídeos, entre outros) ou intoxicações (organofosforados, botulismo, entre outros)<sup>19</sup> .  
A MG pode ser confundida com esclerose lateral amiotrófica (ELA), lesões intracranianas com efeito de massa ou lesões de tronco encefálico que podem causar achados oculares de nervos cranianos. Diagnósticos diferenciais com doenças neuromusculares incluem a síndrome de Eaton-Lambert, oftalmoplegia externa progressiva (miopatia mitocondrial), distrofia óculofaríngea, entre outros.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que apresentarem manifestações clínicas compatíveis com MG e pelo menos um exame complementar confirmatório desta doença.  
Para pacientes com diagnóstico clínico compatível com MG, mas com resultados negativos de anticorpos ant-Ach e eletroneuromiografia, preconiza-se a prova terapêutica com piridostigmina por três meses para avaliação da resposta e confirmação do diagnóstico.  
**5. CRITÉRIOS DE EXCLUSÃO**  
- Serão excluídos deste Protocolo:  
a) os pacientes que apresentarem outras formas de miastenia que não forem a MG (conforme diagnóstico diferencial); e  
b) os pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **6. CASOS ESPECIAIS** -->
O reconhecimento dos subtipos da MG, bem como de situações especiais relacionadas com a doença, é importante para justificar a decisão terapêutica diferenciada que pode ser necessária para o paciente que se encontra em alguma dessas situações.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **6.1. Gravidez** -->
A maior incidência de MG em mulheres ocorre no seu período de vida fértil<sup>20,21</sup> . Sendo assim, o uso de método anticoncepcional deve ser abordado para as mulheres com MG (conforme rotina ginecológica), especialmente nos primeiros anos após o diagnóstico e naquelas pacientes em que a doença ainda não está sob controle<sup>20,22</sup> . Embora em longo prazo a gestação não altere a evolução da doença, ela pode ser uma das causas de exacerbações (inclusive da CM) com comportamento altamente variável e imprevisível durante a gestação e no período de puerpério, bem como nas gestações subsequentes<sup>20,21,23</sup> . Contudo, embora as mulheres com MG possam planejar a gestação para o período em que a doença estiver sob controle e fazendo uso de medicamentos seguros para gestação, não é raro que a gravidez ocorra de forma inesperada<sup>21</sup> .  
A avaliação da segurança do uso de medicamentos durante a gravidez e amamentação deve ser revisada antes da mudança de prescrição do tratamento para a mulher com MG. No período da gestação, a regra geral é evitar a exposição a medicamentos considerados com potencial de risco para o feto, porém deve sempre ser considerada a relação entre risco e benefício, pois o uso de alguns medicamentos podem ser aceitáveis principalmente nas mulheres em que a doença não está controlada ( **Quadro 2** )<sup>20-</sup> 22,24. Embora utilizada para tratamento da CM, a plasmaférese costuma ser evitada nas gestantes devido a possibilidade de hipotensão durante o tratamento<sup>20</sup> .  
**Quadro 2** – Categorias de risco dos medicamentos durante a gestação<sup>20,21.</sup>  
|**Categoria de risco**|**Medicamentos**|
|---|---|
|Fator de risco B: estudos em animais não mostraram anormalidades, embora estudos|Prednisona|
|em mulheres não tenham sido realizados.||
|Fator de risco C: estudos em animais mostraram anormalidades nos descendentes,|Ciclosporina,<br>imunoglobulina<br>e|
|porém não há estudos em humanos.|piridostigmina|
|Fator de risco D: há riscos para o feto durante a gravidez.|Azatioprina e ciclofosfamida|  
Embora a fase tardia do trabalho de parto ser prolongada, a via de parto deve respeitar as indicações obstétricas<sup>20-22</sup> . O uso de anestesia (local ou regional) para realização do parto costuma ser seguro independente da via de parto, mas medicamentos contraindicados para pacientes com MG devem ser evitados<sup>20-23,25</sup> (ver seção Cuidados pré-, peri- e pós-operatórios). Com relação às complicações obstétricas, a frequência de rompimento prematuro de membranas (pré-termo) da bolsa amniótica pode estar aumentada nas gestantes com MG, principalmente naquelas em uso de corticosteroide, podendo ocasionar parto prematuro<sup>20,23</sup> . A MG foi relacionada com mortalidade materna, aborto e parto prematuro em alguns estudos<sup>20</sup> . O sulfato de magnésio deve ser evitado, mesmo na pré-eclâmpsia e eclâmpsia, em função do seu efeito bloqueador neuromuscular<sup>20</sup> .  
Como existe a possibilidade de o neonato apresentar a MG do subtipo ‘neonatal transitória’, o neonato deve ser mantido sob monitorização por pelo menos 48 horas e informar os pais sobre a possibilidade de ocorrer esse subtipo de MG no<sup>neonato20-22</sup> (conforme o item 6.2. Miastenia gravis neonatal transitória, a seguir).  
No puerpério, embora com risco ‘teórico’ da passagem desses anticorpos por meio do leite materno, não há recomendação de restrição da amamentação pela mãe<sup>20,22</sup> . O tratamento da MG no período de puerpério deve ser revisado para evitar o uso de medicamentos que possam passar para o neonato pelo leite materno<sup>23</sup> . Nesse sentido, o uso de anticolinesterásico (piridostigmina), corticosteroide (prednisona) e imunoglobulina humana pela mãe foi considerado compatível com a amamentação (seguro para o neonato)<sup>20,22,23</sup> . No entanto, o uso de imunossupressores (azatioprina e ciclosporina) deve ter seu uso criterioso (podendo ser contraindicado) durante o período de amamentação<sup>20,23</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **6.2. Miastenia gravis neonatal transitória** -->
A MG neonatal transitória resulta da transferência passiva de anticorpos maternos através da placenta da mãe, podendo ocorrer em média até 10% dos neonatos filhos de mães com MG<sup>20-23</sup> . O seu início pode não ser imediato, ocorrendo após algumas horas ou dias do nascimento, podendo durar entre duas semanas e alguns meses, mas a recuperação espontânea costuma ocorrer dentro de 4 semanas<sup>20-22</sup> . Os neonatos podem apresentar choro fraco, dificuldade de sucção, fraqueza generalizada, tônus muscular diminuído, dificuldade respiratória, ptose palpebral e diminuição da expressão facial<sup>21</sup> . O diagnóstico é feito com base na avaliação clínica, não sendo necessária a realização da dosagem do anticorpo ou de eletroneuromiografia no neonato<sup>22</sup> .  
O tratamento de suporte (internação em UTI, intubação, ventilação mecânica, sonda nasogástrica, entre outras medidas), assim como o uso de medicamentos sintomáticos (anticolinesterásicos), é preconizado até que os anticorpos maternos sejam eliminados e ocorra a recuperação espontânea da criança<sup>20-22</sup> . A possibilidade do uso de imunoglobulina humana ou exsanguíneo transfusão pode ser considerada no neonato somente nos casos graves, mas a necessidade desse tipo de tratamento costuma ser uma situação rara<sup>22</sup> .  
Em raros casos associados à produção de anticorpo contra o receptor ‘fetal’ de acetilcolina pela mãe, o feto pode apresentar diminuição dos movimentos fetais e polidrâmnio durante a gravidez, bem como artrogripose<sup>20,21</sup> . A MG neonatal transitória não pode ser confundida com o subtipo ‘miastenia congênita e do desenvolvimento’, que é doença de caráter não autoimune e com apresentação clínica distinta, na qual a mãe não tem anticorpos circulantes.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **6.3. Miastenia congênita e do desenvolvimento** -->
As miastenias congênitas e do desenvolvimento são doenças que causam alteração na margem de segurança da transmissão neuromuscular por diferentes mecanismos<sup>26,27</sup> . A mutação de genes relacionados com as estruturas do receptor de acetilcolina são a causa da disfunção da junção neuromuscular<sup>26-33</sup> . Tradicionalmente, existem diferentes subtipos, os quais costumam ser classificadas pelo local onde ocorre o defeito primário da transmissão neuromuscular (pré-sináptica, sináptica e pós-sináptica), mas a associação dessa classificação com as alterações genéticas, encontradas até o momento, pode ser utilizada para facilitar a identificação dos pacientes<sup>27,29,31,32</sup> . Embora algumas das manifestações clínicas e eletrofisiológicas dos pacientes com miastenia congênita e do desenvolvimento possam ser semelhantes às de pacientes com MG causada por anticorpos, as manifestações clínicas dependem do subtipo que o paciente apresenta, sendo que alguns apresentam aspectos clínicos típicos desde o nascimento ou período neonatal, enquanto outros permanecem sem receber diagnóstico até a adolescência ou a vida adulta, principalmente quando os sintomas são leves<sup>28-33</sup> .  
Na investigação das miastenias congênitas e do desenvolvimento, avaliações clínicas e eletrofisiológicas são fundamentais para comprovar a presença de alteração da margem de segurança da junção neuromuscular, classificar o local de alteração, auxiliar o estudo molecular e definir o tipo de tratamento<sup>29</sup> . O diagnóstico pode ser confirmado pelo conjunto:  
manifestação clínica, estudo eletrofisiológico (eletroneuromiografia/estimulação repetitiva/eletromiografia de fibra única) e estudo molecular (genética).  
Como esses pacientes não apresentam benefício com tratamento com corticosteroide, imunossupressor, plasmaférese, imunoglobulina ou timectomia, o tratamento inicial pode ser feito com anticolinesterásico (piridostigmina). No entanto, existem raros subtipos que não se beneficiam ou pioram com o uso da piridostigmina (síndrome do canal lento, deficiência de acetilcolinesterase da placa motora, deficiência da proteína DOK7, entre outros subtipos). O diagnóstico desses raros subtipos pode ser também inferido pela falta de resposta (ou piora) ao uso dos anticolinesterásicos e alterações da eletroneuromiografia (como o ‘potencial repetitivo’), sendo confirmado por análise genética. Nesses casos, a piridostigmina está contraindicada<sup>26-33</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **6.4. Miastenia gravis soronegativa** -->
Conforme mencionado previamente, os anticorpos anti-AChR ocorrem na maioria dos pacientes com MG. No entanto, em aproximadamente 15% dos pacientes esses anticorpos não são encontrados e os pacientes podem ser, inicialmente, classificados como MG do subtipo ‘Soronegativa’<sup>34</sup> . Nesses pacientes, a MG é causada por outros auto-anticorpos, como antiMuSK, anti-LRP4, entre outros.  
Nessa situação, o anticorpo anti-MuSK é o mais frequente, sendo encontrado em cerca de 50% dos pacientes com MG sem o anticorpo anti-AChR<sup>34,35</sup> . O anticorpo anti-MuSK tem características fisiopatológicas diferentes: pertence a classe IgG4, não se liga ao complemento e não tem relação com alterações do timo<sup>34-37</sup> . Embora algumas das manifestações clínicas e eletrofisiológicas dos pacientes possam ser semelhantes às de pacientes com MG pelo anticorpo anti-AChR, costumam ser mais frequentes insuficiência respiratória, fraqueza muscular e atrofia de músculos da língua, face, pescoço e cinturas escapular<sup>34,35,37</sup> .  
Com relação ao tratamento destes pacientes, a timectomia não está indicada, e os anticolinesterásicos (piridostigmina) não são efetivos (e podem até piorar a doença)<sup>34-37</sup> .  
Outros anticorpos foram associados a MG naqueles pacientes que não apresentam anticorpos anti-AChR ou anti-MuSK (MG ‘duplo soronegativa’). Os estudos que avaliam a eficácia do tratamento nestas formas estão em andamento, mas parece que esses subtipos de MG, como por exemplo o subtipo causado pelo anticorpo anti-LRP4, tem boa resposta ao mesmo tratamento específico utilizado para pacientes com MG causada por anticorpo anti-AChR, embora timectomia parece não mostrar benefício também nesses pacientes<sup>34</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **7. TRATAMENTO** -->
O objetivo do tratamento é tornar os pacientes minimamente sintomáticos ou melhores, minimizando os efeitos colaterais dos medicamentos<sup>19</sup> . É definido de acordo com a intensidade dos sintomas (leves, moderados e graves), características da doença (crise miastênica, presença de timoma, presença de anticorpos anti-ACh) e resposta aos tratamentos anteriores (casos refratários). O fluxograma de tratamento encontra-se na **Figura 1** . O tratamento sintomático é feito com inibidores da acetilcolinesterase (piridostigmina), e o tratamento modificador da doença ou de manutenção, das crises miastênicas e dos casos refratários é feito com imunossupressores, imunoglobulina, plasmaférese e timectomia. Inexiste tempo predefinido de tratamento, visto que se trata de uma doença crônica e com sintomas muitas vezes flutuantes. Assim, deve-se tentar sempre o controle da doença com a menor dose necessária com vistas à suspensão de medicamentos, se possível, conforme o alívio dos sinais e sintomas referidos<sup>38</sup> .  
A melhora da mobilidade, do bem-estar psicológico, da integração no meio social, da estabilidade da doença e da possibilidade de emprego de acordo com suas habilidades físicas possibilitam um aumento da qualidade de vida dos pacientes com MG<sup>39</sup> .  
O treinamento muscular respiratório (TMR) é uma alternativa na tentativa de minimizar ou retardar o declínio da função respiratória, presente na maioria dos pacientes miastênicos, que é associado aos índices de morbidade e mortalidade. Proporciona  
ganhos de força e resistência muscular respiratória. Porém, não há consenso sobre a melhor técnica, protocolo e eficácia do TMR em cada estágio da doença<sup>40,41</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **7.1. Tratamento sintomático** -->
Os inibidores da acetilcolinesterase, como a piridostigmina, inibem transitoriamente o catabolismo da acetilcolina (ACh) pela acetilcolinesterase aumentando a quantidade e a duração desse neurotransmissor na fenda sináptica e, consequentemente, melhorando a força muscular. A piridostigmina é indicada para o tratamento inicial da doença e também pode ser utilizada no tratamento de manutenção<sup>42,43</sup> . A dose deve ser ajustada baseada nos sintomas e efeitos adversos<sup>42</sup> .  
Para os pacientes que não respondem adequadamente a piridostigmina, a conduta é adicionar o corticosteroide para obter a remissão dos sintomas.  A prednisona é o corticosteroide mais comumente utilizado em MG. Os diferentes esquemas de administração (uso diário, uso em dias alternados ou em pulsoterapia) podem ser utilizados.  
A apresentação clínica mais frequente de MG é a forma Ocular (MGO), com comprometimento dos músculos extraoculares, elevadores palpebrais e orbiculares dos olhos, com sintomas de ptose e diplopia, merecendo atenção terapêutica especial. Os objetivos do tratamento para a MGO são retornar o indivíduo a um estado de visão clara e impedir o desenvolvimento ou limitar a gravidade da MG Generalizada (MGG). Os tratamentos incluem medicamentos sintomáticos e corticosteroides. O uso de baixa dose de prednisona com escalada gradual tem sido relacionado com maiores segurança, eficácia e tolerância no tratamento da MGO<sup>44</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **7.2.      Tratamento modificador da doença ou de manutenção** -->
No caso dos pacientes com indicação de manutenção crônica de corticosteroide, a associação com outros imunossupressores parece contribuir para redução de dose, diminuindo substancialmente os efeitos adversos. Se não for possível manter a remissão com uma dose suficientemente baixa de corticosteroide, a imunossupressão é introduzida<sup>45,46</sup> .  
O uso dos imunossupressores azatioprina, ciclosporina, ciclofosfamida são indicados de forma isolada ou em associação com prednisona para pacientes resistentes, com efeitos adversos importantes ou que precisem de redução da dose da prednisona.  
A timectomia está indicada para pacientes com timoma. Já nos pacientes com anticorpos anti-AChR, especialmente com formas generalizadas da doença, resultados de pesquisas clínicas com timectomia têm variado bastante em muitos aspectos, o que dificulta sua análise de eficácia, tais como: duração e gravidade clínica, escolha e intensidade de terapia com medicamentos imunossupressores, duração do acompanhamento pós-cirúrgico, inclusão de casos de timoma, falta de informação de novos surtos ou re-operações e diferentes técnicas cirúrgicas<sup>47-49</sup> . No entanto, pode ser considerada em pacientes com piora progressiva, especialmente em pacientes com diagnóstico mais recente<sup>43</sup> .  
O benefício da timectomia associada a prednisona em pacientes sem timoma foi demonstrado por ensaio clínico randomizado com seguimento de 5 anos e revisão sistemática com meta-análise. Esse procedimento cirúrgico proporciona chance de remissão da doença maior do que aqueles tratados clinicamente, permitindo-se inferir que a timectomia, juntamente com outras condutas, pode ser utilizada para o tratamento desses pacientes. Entretanto, em análise de subgrupo, a timectomia não esteve relacionada com melhora em alguns desfechos (melhora na Escala _Quantitative Myasthenia Gravis_ - QMG) e redução na necessidade diária de prednisona em homens com instalação da MG em idade superior a 40 anos<sup>50-52</sup> . Sendo assim, o tratamento imunossupressor em pacientes timectomizados, ou não timectomizados, com comprometimento sintomatológico progressivo pode ser considerado em pacientes selecionados.  
**Figura 1 -** Fluxograma de tratamento de pacientes com Miastenia Gravis  
<!-- Start of picture text -->
FLUXOGRAMA DE TRATAMENTO<br>MIASTENIA GRAVIS<br>Diagnóstico:  clínico e<br>laboratorial<br>Paciente com diagnóstico de  Critérios de inclusão:  manifestações clínicas<br>miastenia  gravis* compatíveis e um exame complementar<br>confirmando  a  doença<br>(eletroneuromiografia ou dosagem sérica de<br>anticorpos)<br>Possui critérios  Critérios de exclusão:<br>Não Sim<br>de inclusão? ü outras formas de miastenia que<br>não a miastenia  gravis<br>Exclusão do  Possui critérios<br>Sim<br>PCDT de exclusão?<br>Não Não<br>MG ocular, sintomas leves  Sintomas moderados a graves<br>Crise miastênica<br>(Classe I e II) (Classe III, IV e V)<br>Internação em Unidade de Tratamento<br>Piridostigmina**<br>Intensivo,<br>plasmaférese ou imunoglobulina humana<br>Houve resposta<br>Não Sim<br>terapêutica?<br>Houve melhora<br>Associar<br>da crise?<br>prednisona  Sim Não<br>Manter o<br>Tratar<br>tratamento,  Manter o<br>necessidade de corticoterapia crônica ou efeitos adversos?Houve falha terapêutica,  Não alcançar a dose considerando  conforme sintomas tratamento<br>Sim<br>mínima eficaz dos<br>medicamentos<br>Associar<br>azatioprina ou<br>ciclosporina<br>Houve remissão<br>Sim Não<br>da doença?<br>Avaliar diagnósticos diferenciais.<br>Manter o tratamento, considerando alcançar<br>Substituir por  ciclofosfamida  (em monoterapia ou<br>a dose mínima eficaz dos medicamentos.<br>associada a prednisona).<br><!-- End of picture text -->  
* Indicado timectomia na presença de timoma e de anticorpos anti-AchR. Avaliar indicação de timectomia nos casos de ausência de timoma. ** Considerar prednisona precocemente nos casos moderados a graves, se necessário Obs. a qualquer momento do tratamento se houver piora aguda, complicações respiratórias, risco de morte considerar uso de plasmaférese ou imunoglobulina humana.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **7.3. Tratamento da doença refratária** -->
Para pacientes com resposta ineficaz à terapia imunossupressora ou com efeitos adversos inaceitáveis, não há um guia terapêutico claro e de consenso. Estudos pequenos têm demonstrado efeitos benéficos com altas doses de ciclofosfamida, podendo ser utilizada como alternativa terapêutica nos casos de refratariedade aos demais imunossupressores<sup>53,54</sup> .  
Se a resposta continuar não esperada, deve-se considerar outros diagnósticos, incluindo MG congênita ou MG autoimuneadquirida com anticorpos anti-MuSK. Pacientes com MG anti-MuSK têm uma resposta variável ao anticolinesterásico, usualmente com pouca melhora, mas com efeitos adversos frequentes e limitantes (conforme casos especiais).  
A imunoglobulina ou plasmaférese são indicados como tratamentos de curto prazo em pacientes com MG com sinais de ameaça à vida, como insuficiência respiratória ou disfagia; na preparação para cirurgia em pacientes com disfunção bulbar significativa; quando é necessária uma resposta rápida ao tratamento; quando outros tratamentos são insuficientemente eficazes; e antes do início dos corticosteroides, se necessário, para prevenir ou minimizar as exacerbações<sup>42</sup> .  
A escolha entre imunoglobulina e plasmaférese depende de fatores individuais do paciente e da experiência e disponibilidade no serviço. São considerados igualmente eficazes no tratamento de MG generalizada grave, sendo a eficácia da imunoglobulina menos certa na MG mais leve ou em MG ocular e a plasmaférese pode ser mais eficaz que a imunoglobulina em pacientes com MG pelo anticorpo anti-MuSK<sup>42,55,56</sup> .  
A evidência disponível da imunoglobulina como terapia de manutenção é ainda insuficiente para preconizá-la neste  
Protocolo<sup>42,43,55,57</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **7.4. Tratamento da Crise Miastênica (CM)** -->
A Crise Miastênica (CM) é a complicação mais grave da MG, sendo definida por episódio de rápida deterioração da força muscular suficiente para causar insuficiência respiratória com necessidade de ventilação mecânica<sup>58-60</sup> . A maior incidência da CM ocorre nos primeiros anos da doença, nos pacientes com maior gravidade e naqueles com pouca resposta ao tratamento<sup>58-</sup> 60. O mecanismo da CM ocorre devido fraqueza da musculatura orofaríngea (prejudicando a proteção de vias aéreas e consequente aspiração de secreções) e fraqueza dos músculos intercostais e diafragma (causando hipoventilação)<sup>58,59</sup> .  
A mortalidade por CM foi drasticamente reduzida após a década de 1960, de 80% para menos de 5%, devido admissão do paciente em unidades de terapia intensiva (UTI), ao uso de ventilação mecânica, reconhecimento e tratamento de fatores precipitantes, uso de anticolinesterásicos, plasmaférese, imunoglobulina humana, corticoesteroides e imunossupressores<sup>58-61</sup> Apesar de a mortalidade ainda persistir elevada, quando a CM é tratada adequadamente não interfere na sobrevida do paciente<sup>58,59</sup> .  
Sendo assim, o tratamento da CM consiste em medidas de suporte, tratamento específico e controle dos fatores precipitantes, conforme detalhado no **Quadro 3**<sup>34,42,58-62</sup> .  
**Quadro 3** - Tratamento da crise miastênica (CM)  
|| Admissão do paciente em UTI.|
|---|---|
|| Monitorização rigorosa da função respiratória.|
|Medidas de suporte| Tratamento da insuficiência respiratória (intubação orotraqueal e ventilação mecânica).<br> Cuidados gerais (uso de sonda nasogástrica, sonda vesical, prevenção de trombose venosa<br>profunda, suporte nutricional, traqueostomia, entre outras medidas).|
|| Início de uso de anticolinesterásicos (fase inicial do tratamento da CM em pacientes sem<br>diagnóstico prévio de MG).|
|Tratamento específico| Avaliação da suspensão do uso de anticolinesterásicos (suspensão por 24 a 72 horas naqueles|
||pacientes que estão sob ventilação mecânica e também para diagnóstico diferencial com crise<br>colinérgica).|
|| Plasmaférese ou imunoglobulina humana.|  
|Controle dos fatores|Reconhecimento e tratamento de fatores precipitantes: infecções, distúrbios hidroeletrolíticos,|
|---|---|
|precipitantes|estresse emocional, gravidez, cirurgias, exercício extenuante, medicamentos que agem sobre|
||a transmissão neuromuscular, falta de resposta ao tratamento ou tratamento irregular.|

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **8. FÁRMACOS** -->
-  
-  
-  
-  
-  
- Piridostigmina: comprimidos de 60 mg.  
- Prednisona: comprimidos de 5 mg e 20 mg.  
- Azatioprina: comprimido de 50 mg.  
- Ciclosporina: cápsulas de 10 mg, 25 mg, 50 mg e 100 mg e solução oral 100 mg/mL – 50 mL  
- Ciclofosfamida: frascos-ampolas de 200 mg e 1.000 mg.  
- Imunoglobulina humana: frascos de 0,5 g, 1,0 g, 2,5 g, e 5,0 g.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **8.1.     Esquema de administração** -->
- Piridostigmina: Inicia-se a piridostigmina em adultos na dose de 30-60 mg via oral a cada 6 horas; em crianças a dose inicial é de 1,0 mg/kg. A dose é gradualmente ajustada, se necessário, à medida que houver o controle dos sintomas miastênicos e a redução dos eventos adversos. A maioria dos adultos requer 60-120 mg a cada 4-6 horas; dose máxima de 720 mg/dia, por risco de crise colinérgica.  
- Prednisona: Iniciar com doses baixas (15-20 mg/dia), com aumento gradual até a dose máxima de 1mg/kg/dia.  Pode-se optar por iniciar com a dose de 1 mg/kg/dia, no entanto deve-se atentar para uma possibilidade de piora clínica transitória, inclusive desencadeando Crise Miastênica.  Por esta razão, muitos neurologistas iniciam o medicamento em dias alternados, com dose inicial de 10 mg, com aumento gradual de 10 mg a cada três dias, até 0,75 mg/kg para a forma ocular, ou até 100 mg ou 1,5 mg/kg/em dias alternados, para a forma generalizada. Após melhora máxima, inicia-se tentativa de redução gradual da dose da prednisona, podendo ser necessária a associação de imunossupressores, que tem como objetivo principal a diminuição da dose de prednisona.  
- Azatioprina: em adultos, iniciar com dose de 50 mg/dia, por via oral, com aumento gradual até 2-3 mg/kg/dia.  
- Ciclosporina: iniciar com 3-4 mg/kg/dia por via oral, dividida em duas doses, com aumento gradual até 6 mg/kg/dia, conforme necessário para o controle dos sintomas. Após a obtenção da melhora máxima, diminuir a dose ao longo de meses até a mínima tolerável (3,0 mg/kg/dia).  
- Ciclofosfamida: pulsoterapia intravenosa, mensal, na dose de 500 mg/m<sup>2</sup> . A dose poderá ser ajustada gradativamente, se não houver melhora clínica ou efeitos adversos, num total de até 2000 mg/m<sup>2</sup> .  As pulsoterapias com ciclofosfamida são administrados mensalmente por seis meses, depois a cada dois meses, para um total de nove ciclos.  
- Imunoglobulina humana: dose total máxima de 2 g/kg administrada ao longo de 2 a 5 dias.  
- Plasmaférese: 5-6 trocas de 2-3 litros de plasma, em dias alternados. Usualmente a melhora funcional é detectada após 2-4 trocas.  
Uma vez que manifestações mínimas sejam alcançadas com o medicamento poupador de prednisona, recomenda-se manter a primeira opção introduzida, por pelo menos um a dois anos e, então, diminuir a sua dose, progressivamente, a cada três ou seis meses, até encontrar a mínima dose efetiva.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **8.2.     Benefícios esperados** -->
- Remissão da doença;  
- melhora da força muscular e fadiga;  
- melhora da função respiratória;  
- redução do tempo de internação;  
- prevenção de crises miastênicas.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **9. MONITORAMENTO DO TRATAMENTO** -->
Os pacientes devem ser reavaliados clínica e laboratorialmente pelo menos a cada três meses. A avaliação clínica pode  
ser realizada por intermédio da classificação MGFA e Escala composta de MG ( **Quadro  4** )<sup>63</sup> ou QMG (teste quantitativo para MG) ( **Tabela  1** )<sup>64</sup> .  
A avaliação laboratorial deve ser realizada de acordo com o medicamento, respeitando seus eventos adversos, dando ênfase para:  
- Prednisona: glicemia ao menos a cada 3 meses, avaliação oftalmológica e densitometria óssea periódica, conforme o  
- PCDT da Osteoporose, do Ministério da Saúde.  
- Azatioprina: hemograma e dosagem das transferases/transminases (AST/TGO e ALT/TGP) a cada 3 meses. A azatioprina  
- deve ser suspensa se os leucócitos diminuírem até 2.500/mm<sup>3</sup> ou se o número absoluto de neutófilos estiver abaixo de 1.000/mm<sup>3</sup> ou insuficiência hepática grave.  
- Ciclosporina: dosagem do nível sérico anual (manter entre 50-150 ng/mL). Controle da pressão arterial e avaliação da  
- função renal (creatinina) a cada 3 meses. Suspender o tratamento em caso de nível sérico tóxico ou insuficiência renal grave .  
- Ciclofosfamida: hemograma a cada 3 meses e exame qualitativo de urina. Suspender em casos de toxicidade hematológica  
- ou cistite hemorrágica grave.  
- Imunoglobulina humana: Avaliação da função renal e dosagem sérica de IgA antes da primeira administração. Suspender  
- em casos de hipersensibilidade grave.  
**Quadro 4** – Escala composta para Miastenia Grave para língua portuguesa do Brasil<sup>60.</sup>  
|Ptose (olhar para cima|> 45 segundos|11-45 segundos|1-10 segundos|Imediata|
|---|---|---|---|---|
|facilmente)|||||
|(exame médico)|0|1|2|3|  
|Visão dupla (olhar fixo<br>lateral) (esquerda ou<br>direita)|> 45 segundos|11-45 segundos|1-10 segundos|Imediata|
|---|---|---|---|---|
|(exame médico)|0|1|3|4|
||Normal|Fraqueza leve|Fraqueza moderada|Fraqueza grave|
|Fechamento dos olhos||(abertura com<br>esforço externo)|(podem ser abertos<br>facilmente)|(incapaz de manter os<br>olhos fechados)|
|(exame médico)|0|0|1|2|
||Normal|Gagueira|Gagueira constante|Dificuldade no|
|Fala||intermitente ou fala<br>nasal|ou fala nasal que<br>pode ser|entendimento da fala|
|(história do paciente)|0|2|compreendida<br>4|6|
|Mastigação|Normal|Fadiga com<br>alimentos sólidos|Fadiga com<br>alimentos moles|Tubo gástrico|
|(história do paciente)|0|2|4|6|
|Deglutição|Normal|Raros episódios de<br>engasgo ou<br>dificuldade para|Dificuldade<br>frequente na<br>deglutição com|Tubo gástrico|
|(história do paciente)|0|engolir<br>2|necessidade de<br>alteração na dieta<br>5|6|
|Respiração|Normal|Dispneia de esforço<br>2|Dispneia em<br>repouso|Ventilador dependente<br>9|
|(consequência da MG)|0||4||
|Flexão ou extensão de<br>pescoço|Normal|Fraqueza leve|Fraqueza moderada<br>(~50% fraca+15%)<br>= 3|Fraqueza grave|
|(exame médico)|0|1||4|
|Abdução de ombros|Normal|Fraqueza leve|Fraqueza moderada<br>(~50% fraca+15%)|Fraqueza grave|
|(exame médico)|0|2|= 4|5|
|Flexão do quadril|Normal|Fraqueza leve|Fraqueza moderada<br>(~50% fraca+15%)|Fraqueza grave|
|(exame médico)|0|2|= 4|5|  
Nota: “Fraqueza moderada” para os itens pescoço e membros deve ser interpretada como fraqueza equivalente a 50%±15% do esperado para uma força normal. Qualquer fraqueza mais leve do que isto seria classificada como leve e qualquer fraqueza mais grave seria classificada como grave. Total de pontos: ______________________  
**Tabela 1** - Teste Quantitativo para Miastenia Gravis adaptado para língua portuguesa do Brasil<sup>61.</sup>  
|**Comprometimento**|**Nenhum**|**Leve**|**Moderado**|**Grave**|**Pontos**|
|---|---|---|---|---|---|
|**Graduação**|**0**|**1**|**2**|**3**||
|**Visão dupla (olhar fixo lateral)**<br>**(segundos)**|60|11-59|1-10|Espontâneo||
|**Ptose (olhar fixo para cima)**<br>**(segundos)**|60|11-59|1-10|Espontâneo||
|**Músculos faciais**|Fechamento<br>normal das<br>pálpebras|Fechamento<br>completo.<br>Resistência<br>fraca|Fechamento<br>completo. Sem<br>resistência|Fechamento<br>incompleto||
|**Deglutição (120mL água)**|Normal|Tosse mínima<br>ou limpar a<br>garganta|Tosse intensa,<br>engasga ou<br>regurgitação<br>nasal|Não consegue<br>engolir. Teste<br>não realizado||
|**Contar em voz alta de 1 a 50**|Nenhum sinal|Disartria entre|Disartria entre|Disartria até 9||
|**(início da disartria)**|até 50|30-49|10-29|||
|**Braço direito estendido (90°**<br>**sentado) (segundos)**|240|90-239|10-89|0-9||
|**Braço esquerdo estendido (90°**<br>**sentado) (segundos)**|240|90-239|10-89|0-9||
|**Capacidade vital forçada (% do**<br>**predito)**|>80%|65%-79%|50%-64%|<50%||
|**Preensão palmar direita (kg)**||||||
|**Homem**|>45|15-44|5-14|0-4||
|**Mulher**|>30|10-29|5-9|0-4||
|**Preensão palmar esquerda (kg)**||||||
|**Homem**|>35|15-34|5-14|0-4||
|**Mulher**|>25|10-24|5-9|0-4||
|**Em supino, manter a cabeça**|120|30-119|1-29|0||
|**erguida em 45 graus (segundos)**||||||
|**Perna direita estendida 45 a 50°**<br>**(supino)**|100|31-99|1-30|0||
|**Perna esquerda estendida 45 a**|100|31-99|1-30|0||
|**50° (supino)**||||||  
**9.1.     Cuidados pré-, peri- e pós-operatórios.**  
Vários cuidados especiais são necessários ao paciente com MG submetido a procedimento cirúrgico, em razão dos riscos envolvidos na anestesia e cirurgia. Como a timectomia é um dos procedimentos cirúrgicos mais citados em pacientes com MG, a maior parte dos protocolos realizados antes, durante e após cirurgias são baseados nos procedimentos adotados em pacientes submetidos a timectomia. Outro procedimento cirúrgico em que a anestesia (e analgesia) é muito citada em pacientes com MG é o parto, principalmente em procedimentos baseados em anestesia regional.  
No período pré-operatório, fatores preditivos de complicação pela MG devem ser avaliados. A avaliação anestésica deve ser feita conforme rotina anestésica e cirúrgica. No entanto, além da realização de exames laboratoriais de rotina, eletrocardiograma e radiografia de tórax, é indicada adicionalmente a avaliação da função cardíaca e pulmonar bem como o estudo estrutural do tórax (presença de timoma e possível compressão traqueal) por tomografia computadorizada<sup>65-67</sup> .  
Com relação ao tratamento da MG no período pré-operatório, deve-se garantir a estabilidade clínica do paciente com a menor dose possível dos medicamentos<sup>25</sup> . A maior parte dos imunossupressores não interfere na anestesia, exceto a azatioprina (interferindo no efeito da succinilcolina) e dos agentes bloqueadores neuromusculares não despolarizantes<sup>25,68</sup> .  
A imunoglobulina humana ou a plasmaférese devem ser consideradas no período pré-operatório somente para pacientes sem controle adequado da doença<sup>25,42,66,67</sup> . A suspensão do corticosteroide (ou sua redução), se possível, pode diminuir o risco de problemas de cicatrização e infecção<sup>66</sup> . O uso de ‘pré-medicamentos’ com sedativos e opioides devem ser evitados devido efeito depressor da função respiratória<sup>25,69</sup> .  
Para a intervenção cirúrgica, a escolha da anestesia geral envolve o uso de agentes inalantes ou de agentes intravenosos<sup>66</sup> . Entre os primeiros, sevoflurano, isoflorano e halotano, apesar de diminuírem a transmissão neuromuscular em 50% dos casos, proporcionam boas condições operatórias sem o uso de medicamentos paralisantes (principalmente com sevoflurano)<sup>25,66</sup> . O propofol é o agente intravenoso de eleição, por não alterar a transmissão neuromuscular<sup>66</sup> . Relaxantes musculares (principalmente os agentes bloqueadores neuromusculares do tipo não despolarizantes) devem ser evitados, mesmo em menores doses, mas naqueles pacientes em que o uso é necessário, rocurônio e vecurônio têm se mostrados seguros, além do sugamadex (reversor do efeito do bloqueador neuromuscular)<sup>25,68,69</sup> .  
Existem casos raros de complicações neuromusculares em pacientes com MG durante a cirurgia pela aplicação de anestésicos regionais, mas anestesia (e analgesia) epidural tem se mostrado segura (principalmente durante anestesia/analgesia no parto)<sup>25,66</sup> .  
Se possível, a extubação deve ser realizada no centro cirúrgico, sendo que os pacientes sem condições de extubação podem ser admitidos em UTI para tentativa de extubação antes do período de 24 horas após a cirurgia (no entanto, admissão na UTI para extubação após cirurgia não deve ser realizada como rotina)<sup>25,65,69</sup> .  
No pós-operatório, a necessidade de medidas de suporte intensivo parece estar associada a pacientes que antes da cirurgia apresentam doença não controlada, CM, necessidade de dose elevada de piridostigmina, sintomas de acometimento bulbar, elevado índice de massa corpórea, alteração prévia da função pulmonar, doença cardíaca, tempo prolongado de cirurgia e complexidade da cirurgia<sup>25,65,66,70</sup> . A insuficiência respiratória (persistência de intubação orotraqueal por período maior que 24 horas) costuma ser a complicação pós-operatória mais relatada em pacientes com MG, sendo seu tratamento no período pósoperatório semelhante ao tratamento da CM não relacionada com cirurgia ou anestesia. Recomenda-se a analgesia no período pós-operatório<sup>25</sup> .

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **9.2.     Cuidados com medicamentos em pacientes com Miastenia Gravis** -->
Para pacientes com MG preconiza-se a vacinação anual contra influenza sazonal<sup>58</sup> . A vacina pneumocócica é indicada para todos os indivíduos com doenças pulmonares crônicas e para aqueles que recebem terapia imunossupressora. A maioria das vacinas vivas atenuadas deve ser evitada em pacientes com MG em uso medicamentos imunossupressores.  
No **Quadro 5** estão descritos alguns medicamentos que podem desencadear ou piorar a doença.  
**Quadro 5 -** Medicamentos que podem desencadear ou piorar a miastenia gravis  
|**Agentes anestésicos**|Agentes bloqueadores neuromusculares.||
|---|---|---|
|**Antibióticos**|Aminoglicosídeos (gentamicina, neomicina|, tobramicina),|
||fluoroquinolonas<br>(ciprofloxacina,<br>norfloxacina), macrolídeos (azitromicina,<br>eritromicina).|levofloxacina,<br>claritromicina,|
|**Medicamentos cardiovasculares**|Β-bloqueadores<br>(atenolol,<br>labetalol,<br>propranolol), procainamida e quinidina.|<br>metoprolol,|
|**Outros medicamentos**|Anticorpos<br>monoclonais<br>anti-PD1<br>(|nivolumabe<br>e|
||pembrolizumabe),<br>toxina<br>botulínica,|<br>cloroquina,|
||hidroxicloroquina,<br>magnésio,<br>penicilam|ina,<br>quinina,|
||fenitoína, morfina, barbitúricos.||

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e adequação de uso do(s) medicamento(s).  
Doentes de miastenia gravis devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no Protocolo e acompanhamento. Após o diagnóstico, recomenda-se o acompanhamento por equipe multidisciplinar, conforme  
necessidades (médico, fisioterapeuta, educador físico, fonoaudiólogo, nutricionista, psicólogo, farmacêutico). Deve-se atentar para os pacientes com dificuldades diagnósticas, refratários ao tratamento clínico ou com intolerância medicamentosa.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Alerta-se o gestor local para evitar o fornecimento concomitante da imunoglobulina humana pela Autorização de Internação Hospitalar (AIH/SIH-SUS) e Solicitação/Autorização de Medicamentos (APAC/SIA-SUS).

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **11.     REFERÊNCIAS** -->
- 1 Hehir, M. K. & Silvestri, N. J. Generalized Myasthenia Gravis: Classification, Clinical Presentation, Natural History, and Epidemiology. _Neurol Clin_ **36** , 253-260, doi:10.1016/j.ncl.2018.01.002 (2018).  
- 2 (!!! INVALID CITATION !!! 2,3).  
- 3 Phillips, L. H., 2nd. The epidemiology of myasthenia gravis. _Ann N Y Acad Sci_ **998** , 407-412, doi:10.1196/annals.1254.053 (2003).  
- 4 Grob, D., Brunner, N., Namba, T. & Pagala, M. Lifetime course of myasthenia gravis. _Muscle Nerve_ **37** , 141-149, doi:10.1002/mus.20950 (2008).  
- 5 Vincent, A., Palace, J. & Hilton-Jones, D. Myasthenia gravis. _Lancet_ **357** , 2122-2128, doi:10.1016/s01406736(00)05186-2 (2001).  
- 6 Literature review of the usefulness of repetitive nerve stimulation and single fiber EMG in the electrodiagnostic evaluation of patients with suspected myasthenia gravis or Lambert-Eaton myasthenic syndrome. _Muscle Nerve_ **24** , 1239-1247 (2001).  
- 7 AA, A. & JA, R. in _Neuromuscular disorders_ (eds Amato AA & Russell JA)  457-528 (McGraw Hill, 2008).  
- 8 Drachman, D. B. Myasthenia gravis. _N Engl J Med_ **330** , 1797-1810, doi:10.1056/nejm199406233302507 (1994).  
- 9 Carr, A. S., Cardwell, C. R., McCarron, P. O. & McConville, J. A systematic review of population based epidemiological studies in Myasthenia Gravis. _BMC Neurol_ **10** , 46, doi:10.1186/1471-2377-10-46 (2010).  
- 10 Martinez Torre, S., Gomez Molinero, I. & Martinez Giron, R. [An update on myasthenia gravis]. _Semergen_ **44** , 351354, doi:10.1016/j.semerg.2018.01.003 (2018).  
- 11 Grob, D., Arsura, E. L., Brunner, N. G. & Namba, T. The course of myasthenia gravis and therapies affecting outcome. _Ann N Y Acad Sci_ **505** , 472-499, doi:10.1111/j.1749-6632.1987.tb51317.x (1987).  
- 12 Sih, M., Soliven, B., Mathenia, N., Jacobsen, J. & Rezania, K. Head-drop: A frequent feature of late-onset myasthenia gravis. _Muscle Nerve_ **56** , 441-444, doi:10.1002/mus.25526 (2017).  
- 13 Jaretzki, A., 3rd _et al._ Myasthenia gravis: recommendations for clinical research standards. Task Force of the Medical Scientific Advisory Board of the Myasthenia Gravis Foundation of America. _Ann Thorac Surg_ **70** , 327-334, doi:10.1016/s0003-4975(00)01595-2 (2000).  
- 14 Drachman, D. B. Myasthenia Gravis. _Semin Neurol_ **36** , 419-424, doi:10.1055/s-0036-1586265 (2016).  
- 15 Bourque, P. R. & Breiner, A. Myasthenia gravis. _CMAJ_ **190** , E1141-E1141, doi:10.1503/cmaj.180656 (2018).  
- 16 Sieb, J. P. Myasthenia gravis: an update for the clinician. _Clin Exp Immunol_ **175** , 408-418, doi:10.1111/cei.12217 [doi] (2014).  
- 17 Fortin, E., Cestari, D. M. & Weinberg, D. H. Ocular myasthenia gravis: an update on diagnosis and treatment. _Curr Opin Ophthalmol_ **29** , 477-484, doi:00055735-201811000-00002 [pii] 10.1097/ICU.0000000000000526 [doi] (2018).  
- 18 BRASIL. Ministério da Saúde. Departamento de Gestão, Incorporação de tecnologias e Inovação em Saúde - DGITIS. Comissão nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec. Exame de dosagem de anticorpo anti-receptor de acetilcolina para diagnóstico da Miastenia Gravis Relatório Nº598 de 2021. In: DGITIS, (eds Ministério da Saúde); (2021).  
- 19 Bird, S. J. in _UpToDate_ (eds Jeremy M & Shefner) (2019).  
- 20 Waters, J. Management of Myasthenia Gravis in Pregnancy. _Neurol Clin_ **37** , 113-120, doi:10.1016/j.ncl.2018.09.003 (2019).  
- 21 Hamel, J. & Ciafaloni, E. An Update: Myasthenia Gravis and Pregnancy. _Neurol Clin_ **36** , 355-365, doi:10.1016/j.ncl.2018.01.005 (2018).  
- 22 Norwood, F. _et al._ Myasthenia in pregnancy: best practice guidelines from a U.K. multispecialty working group. _J Neurol Neurosurg Psychiatry_ **85** , 538-543, doi:10.1136/jnnp-2013-305572 (2014).  
- 23 Ducci, R. D., Lorenzoni, P. J., Kay, C. S., Werneck, L. C. & Scola, R. H. Clinical follow-up of pregnancy in myasthenia gravis patients. _Neuromuscul Disord_ **27** , 352-357, doi:10.1016/j.nmd.2017.01.021 (2017).  
- 24 Ferrero, S., Pretta, S., Nicoletti, A., Petrera, P. & Ragni, N. Myasthenia gravis: management issues during pregnancy. _Eur J Obstet Gynecol Reprod Biol_ **121** , 129-138, doi:10.1016/j.ejogrb.2005.01.002 (2005).  
- 25 Blichfeldt-Lauridsen, L. & Hansen, B. D. Anesthesia and myasthenia gravis. _Acta Anaesthesiol Scand_ **56** , 17-22, doi:10.1111/j.1399-6576.2011.02558.x (2012).  
- 26 Lorenzoni, P. J., Scola, R. H., Kay, C. S. & Werneck, L. C. Congenital myasthenic syndrome: a brief review. _Pediatr Neurol_ **46** , 141-148, doi:10.1016/j.pediatrneurol.2011.12.001 (2012).  
- 27 Souza, P. V. _et al._ Clinical and genetic basis of congenital myasthenic syndromes. _Arq Neuropsiquiatr_ **74** , 750-760, doi:10.1590/0004-282x20160106 (2016).  
- 28 Lorenzoni, PJ & RH, S. in _Tratado de Neurologia da Academia Brasileira de Neurologia_ (eds Joaquim & Osvaldo M. Takayanagui Pereira Brasil Neto)  631-637 (Elsevier, 2013).  
- 29 Lorenzoni, P. & Scola, R. in _Neurogenética na Prática Clínica._ (eds Pedroso & França Jr MC JL, Camargos ST, Barsottini OGP, Kok F)  (Atheneu Ltda, 2019).  
- 30 Vanhaesebrouck, A. E. & Beeson, D. The congenital myasthenic syndromes: expanding genetic and phenotypic spectrums and refining treatment strategies. _Curr Opin Neurol_ , doi:10.1097/wco.0000000000000736 (2019).  
- 31 Finsterer, J. Congenital myasthenic syndromes. _Orphanet J Rare Dis_ **14** , 57, doi:10.1186/s13023-019-1025-5 (2019).  
- 32 Engel, A. G. Congenital Myasthenic Syndromes in 2018. _Curr Neurol Neurosci Rep_ **18** , 46, doi:10.1007/s11910-0180852-4 (2018).  
- 33 McMacken, G., Abicht, A., Evangelista, T., Spendiff, S. & Lochmuller, H. The Increasing Genetic and Phenotypical Diversity of Congenital Myasthenic Syndromes. _Neuropediatrics_ **48** , 294-308, doi:10.1055/s-0037-1602832 (2017).  
- 34 Dalakas, M. C. Immunotherapy in myasthenia gravis in the era of biologics. _Nat Rev Neurol_ **15** , 113-124, doi:10.1038/s41582-018-0110-z (2019).  
- 35 Evoli, A. _et al._ Myasthenia gravis with antibodies to MuSK: an update. _Ann N Y Acad Sci_ **1412** , 82-89, doi:10.1111/nyas.13518 (2018).  
- 36 Clifford, K. M. _et al._ Thymectomy may not be associated with clinical improvement in MuSK myasthenia gravis. _Muscle Nerve_ **59** , 404-410, doi:10.1002/mus.26404 (2019).  
- 37 Pasnoor, M. _et al._ Clinical findings in MuSK-antibody positive myasthenia gravis: a U.S. experience. _Muscle Nerve_ **41** , 370-374, doi:10.1002/mus.21533 (2010).  
- 38 Farmakidis, C., Pasnoor, M., Dimachkie, M. M. & Barohn, R. J. Treatment of Myasthenia Gravis. _Neurol Clin_ **36** , 311337, doi:10.1016/j.ncl.2018.01.011 (2018).  
- 39 Twork, S., Wiesmeth, S., Klewer, J., Pöhlau, D. & Kugler, J. Quality of life and life circumstances in German myasthenia gravis patients. _Health Qual Life Outcomes_ **8** , 129, doi:10.1186/1477-7525-8-129 (2010).  
- 40 Fregonezi, G. A., Resqueti, V. R., Güell, R., Pradas, J. & Casan, P. Effects of 8-week, interval-based inspiratory muscle training and breathing retraining in patients with generalized myasthenia gravis. _Chest_ **128** , 1524-1530, doi:10.1378/chest.128.3.1524 (2005).  
- 41 Juliana Luri, N. _et al._ O efeito do treinamento muscular respiratório na miastenia grave. _Revista Neurociências_ **17** , doi:10.34024/rnc.2009.v17.8602 (2009).  
- 42 Sanders, D. B. _et al._ International consensus guidance for management of myasthenia gravis: Executive summary. _Neurology_ **87** , 419-425, doi:10.1212/wnl.0000000000002790 (2016).  
- 43 Sussman, J. _et al._ The Association of British Neurologists' myasthenia gravis guidelines. _Ann N Y Acad Sci_ **1412** , 166169, doi:10.1111/nyas.13503 (2018).  
- 44 Benatar, M. _et al._ Efficacy of prednisone for the treatment of ocular myasthenia (EPITOME): A randomized, controlled trial. _Muscle and Nerve_ **53** , 363-369, doi:10.1002/mus.24769 (2016).  
- 45 Sieb, J. P. Myasthenia gravis: emerging new therapy options. _Curr Opin Pharmacol_ **5** , 303-307, doi:10.1016/j.coph.2005.01.010 (2005).  
- 46 Hart, I. K., Sathasivam, S. & Sharshar, T. Immunosuppressive agents for myasthenia gravis. _Cochrane Database Syst Rev_ , Cd005224, doi:10.1002/14651858.CD005224.pub2 (2007).  
- 47 Gronseth, G. S. & Barohn, R. J. Practice parameter: thymectomy for autoimmune myasthenia gravis (an evidence-based review): report of the Quality Standards Subcommittee of the American Academy of Neurology. _Neurology_ **55** , 7-15, doi:10.1212/wnl.55.1.7 (2000).  
- 48 Barohn, R. J. Treatment and clinical research in myasthenia gravis: how far have we come? _Ann N Y Acad Sci_ **1132** , 225-232, doi:10.1196/annals.1405.036 (2008).  
- 49 Ropper, A. H. RetroSternal--Looking Back at Thymectomy for Myasthenia Gravis. _N Engl J Med_ **375** , 576-577, doi:10.1056/NEJMe1607953 (2016).  
- 50 Wolfe, G. I. _et al._ Randomized trial of thymectomy in myasthenia gravis. _New England Journal of Medicine_ **375** , 511522, doi:10.1056/NEJMoa1602489 (2016).  
- 51 Wolfe, G. I. _et al._ Long-term effect of thymectomy plus prednisone versus prednisone alone in patients with nonthymomatous myasthenia gravis: 2-year extension of the MGTX randomised trial. _The Lancet Neurology_ **18** , 259-268, doi:10.1016/S1474-4422(18)30392-2 (2019).  
- 52 Cataneo, A. J. M., Felisberto, G., Jr. & Cataneo, D. C. Thymectomy in nonthymomatous myasthenia gravis - systematic review and meta-analysis. _Orphanet J Rare Dis_ **13** , 99, doi:10.1186/s13023-018-0837-z (2018).  
- 53 Silvestri, N. J. & Wolfe, G. I. Treatment-refractory myasthenia gravis. _J Clin Neuromuscul Dis_ **15** , 167-178, doi:10.1097/cnd.0000000000000034 (2014).  
- 54 Mantegazza, R. & Antozzi, C. When myasthenia gravis is deemed refractory: clinical signposts and treatment strategies. _Ther Adv Neurol Disord_ **11** , 1756285617749134, doi:10.1177/1756285617749134 (2018).  
- 55 Gajdos, P., Chevret, S. & Toyka, K. V. Intravenous immunoglobulin for myasthenia gravis. _Cochrane Database Syst Rev_ **12** , Cd002277, doi:10.1002/14651858.CD002277.pub4 (2012).  
- 56 Barth, D., Nabavi Nouri, M., Ng, E., Nwe, P. & Bril, V. Comparison of IVIg and PLEX in patients with myasthenia gravis. _Neurology_ **76** , 2017-2023, doi:10.1212/WNL.0b013e31821e5505 (2011).  
- 57 Achiron, A., Barak, Y., Miron, S. & Sarova-Pinhas, I. Immunoglobulin treatment in refractory Myasthenia gravis. _Muscle Nerve_ **23** , 551-555, doi:10.1002/(sici)1097-4598(200004)23:4<551::aid-mus14>3.0.co;2-o (2000).  
- 58 Godoy, D. A., Mello, L. J., Masotti, L. & Di Napoli, M. The myasthenic patient in crisis: an update of the management in Neurointensive Care Unit. _Arq Neuropsiquiatr_ **71** , 627-639, doi:10.1590/0004-282x20130108 (2013).  
- 59 Lorenzoni, P. & Scola, R. in _Condutas em Emergências Neurológicas: diagnóstico e tratamento_ (eds HAG Teive, EM Novak, & MC Lange)  (Segmento Farma, 2011).  
- 60 Thomas, C. E. _et al._ Myasthenic crisis: clinical features, mortality, complications, and risk factors for prolonged intubation. _Neurology_ **48** , 1253-1260, doi:10.1212/wnl.48.5.1253 (1997).  
- 61 Keesey, J. C. "Crisis" in myasthenia gravis: an historical perspective. _Muscle Nerve_ **26** , 1-3, doi:10.1002/mus.10095 (2002).  
- 62 Ortiz-Salas, P., Velez-Van-Meerbeke, A., Galvis-Gomez, C. A. & Rodriguez, Q. J. Human Immunoglobulin Versus Plasmapheresis in Guillain-Barre Syndrome and Myasthenia Gravis: A Meta-Analysis. _J Clin Neuromuscul Dis_ **18** , 1- 11, doi:10.1097/cnd.0000000000000119 (2016).  
- 63 Oliveira, E. F. _et al._ Brazilian-Portuguese translation, cross-cultural adaptation and validation of the Myasthenia Gravis Composite scale. A multicentric study. _Arq Neuropsiquiatr_ **74** , 914-920, doi:10.1590/0004-282x20160129 (2016).  
- 64 Oliveira, E. F. _et al._ Quantitative Myasthenia Gravis Score: a Brazilian multicenter study for translation, cultural adaptation and validation. _Arq Neuropsiquiatr_ **75** , 457-463, doi:10.1590/0004-282x20170075 (2017).  
- 65 Leuzzi, G. _et al._ Thymectomy in myasthenia gravis: proposal for a predictive score of postoperative myasthenic crisis. _Eur J Cardiothorac Surg_ **45** , e76-88; discussion e88, doi:10.1093/ejcts/ezt641 (2014).  
- 66 Krucylak, P. E. & Naunheim, K. S. Preoperative preparation and anesthetic management of patients with myasthenia gravis. _Semin Thorac Cardiovasc Surg_ **11** , 47-53 (1999).  
- 67 d'Empaire, G., Hoaglin, D. C., Perlo, V. P. & Pontoppidan, H. Effect of prethymectomy plasma exchange on postoperative respiratory function in myasthenia gravis. _J Thorac Cardiovasc Surg_ **89** , 592-596 (1985).  
- 68 de Boer, H. D., Shields, M. O. & Booij, L. H. Reversal of neuromuscular blockade with sugammadex in patients with myasthenia gravis: a case series of 21 patients and review of the literature. _Eur J Anaesthesiol_ **31** , 715-721, doi:10.1097/eja.0000000000000153 (2014).  
- 69 Sungur, Z. & Senturk, M. Anaesthesia for thymectomy in adult and juvenile myasthenic patients. _Curr Opin Anaesthesiol_ **29** , 14-19, doi:10.1097/aco.0000000000000272 (2016).  
- 70 Leventhal, S. R., Orkin, F. K. & Hirsh, R. A. Prediction of the need for postoperative mechanical ventilation in myasthenia gravis. _Anesthesiology_ **53** , 26-30, doi:10.1097/00000542-198007000-00006 (1980).

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
AZATIOPRINA,  CICLOFOSFAMIDA,  CICLOSPORINA, IMUNOGLOBULINA, PIRIDOSTIGMINA E PREDNISONA.  
Eu,_______________________________________________________________________ (nome do(a) paciente),  
declaro ter sido informado(a) sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **azatioprina,  ciclofosfamida,  ciclosporina, imunoglobulina, piridostigmina e prednisona** indicados para o tratamento da **Miastenia Gravis** .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico  
___________________________________________________________________________  (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Remissão da doença;  
- melhora da força muscular e fadiga;  
- melhora da função respiratória;  
- redução do tempo de internação; e  
- prevenção de crises miastênicas.  
Fui também informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
<u>Azatioprina e ciclofosfamida: medicamentos classificados como fator de risco D para gestantes (há riscos para o feto</u> durante a gravidez, porém o benefício pode ser maior que o risco). O uso deve ser discutido com seu médico;  
<u>Ciclosporina, imunoglobulina e piridostigmina: medicamentos classificados como fator de risco C para gestantes (estudos</u> em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o feto não pode ser descartado, mas um benefício potencial pode ser maior que os riscos). Caso engravide, devo avisar imediatamente ao meu médico.  
<u>Prednisona: medicamento classificado como fator de risco B para gestantes (estudos em animais não mostraram</u> anormalidades, embora estudos em mulheres não tenham sido realizados ou não foram adequados; o medicamento deve ser prescrito com cautela). Caso engravide, devo avisar imediatamente ao meu médico.  
<u>Efeitos adversos da</u> **<u>azatioprina</u>** : diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, queda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar, pressão baixa;  
<u>Efeitos adversos de</u> **<u>ciclosporina:</u>** problemas nos rins e no fígado, tremores, aumento da quantidade de pelos no corpo, hipertensão, crescimento da gengiva, aumento dos níveis de colesterol e triglicerídios, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas;  
<u>Efeitos adversos da</u> **<u>imunoglobulina humana</u>** : dor de cabeça, calafrios, febre, reações no local de aplicação da injeção que incluem dor, coceira e vermelhidão, aumento de creatinina e ureia no sangue e problemas graves nos rins.  
<u>Efeitos adversos da</u> **<u>piridostigmina</u>** : náusea, vômitos, diarreia, cólicas abdominais, aumento do peristaltismo e das ecreções brônquicas, diminuição dos batimentos cardíacos, bradicardia e miose, fraqueza muscular, entre outros;  
<u>Efeitos adversos da</u> **<u>prednisona</u>** : retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose, problemas de estômago (úlceras estomacais), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabetes melito;  
Medicamentos podem ser contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (   ) Sim   (   ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (   ) Azatioprina  
- (   ) Ciclofosfamida  
- (   ) Ciclosporina  
- (   ) Imunoglobulina  
- (   ) Piridostigmina  
- (   ) Prednisona  
|Local:|Data:||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do re|sponsável legal:||
||_____________________________________<br>Assinatura do paciente ou do responsável legal||
|Médico responsável:|CRM:|UF:|  
Assinatura e carimbo do médico Data:____________________  
NOTA 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da  
Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
NOTA 2: Alerta-se o gestor local para evitar o fornecimento concomitante da imunoglobulina humana pela Autorização  
de Internação Hospitalar (AIH/SIH-SUS) e Solicitação/Autorização de Medicamentos (APAC/SIA-SUS).

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **1. Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Miastenia Gravis iniciou-se com reunião presencial, realizada dia 23 de maio de 2019 em Brasília/Distrito Federal, para delimitação do escopo. O objetivo desta reunião foi a discussão da atualização do referido PCDT.  
Essa reunião presencial contou com a presença de sete membros do Grupo Elaborador, sendo quatro dos quais especialistas e três metodologistas, além de um representante de associação de pacientes e três representantes do Comitê Gestor.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria SAS/MS nº 1.169, de 19 de novembro de 2015) e na estrutura de PCDT definida pela Portaria SAS/ MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas diagnósticas e terapêuticas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **2. Equipe de elaboração e partes interessadas** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), outros técnicos participaram do desenvolvimento deste Protocolo, sendo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.  
Todos os presentes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **<u>Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas</u>** -->
A minuta do Protocolo foi apresentado à 75ª reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas realizada dia 17 de dezembro de 2019, com a participação de representantes de áreas técnicas do Ministério da Saúde e, após a análise e realização dos ajustes e correções apontadas, foi por unanimidade decidido pautar o tema na reunião da Conitec.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **<u>Consulta pública</u>** -->
Foram apresentados os resultados da Consulta Pública nº 27 à 93ª reunião do Plenário da Conitec, realizada dias 08 e 09 de dezembro, e, após a análise e discussão de todos presentes, foi deliberado, por unanimidade, recomendar a aprovação do Protocolo Clínico e Diretrizes Terapêuticas da Miastenia Gravis apresentado no Relatório de Recomendação n° 580. Foi assinado o Registro de Deliberação n° 575/2020.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **3. Busca da evidência** -->
Para auxiliar na atualização do PCDT, foram realizadas buscas na literatura nas bases de dados Pubmed e Embase, conforme a seguinte pergunta PICO ( **Quadro A** ):  
**Quadro A –** Pergunta PICO  
|População|Pacientes com Miastenia Gravis.|
|---|---|
|Intervenção|Tratamentos medicamentosos com indicação aprovada para MG no Brasil e timectomia.|
|Comparação|Sem restrição de comparadores.|
|Desfechos|Melhora dos sintomas, eventos adversos.|
|Tipos de estudos|Meta-análises, ECR e_guidelines_.|  
O **Quadro B** apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de artigos selecionados.  
**Quadro B -** Descrição das buscas  
|**Base**|**Estratégia**|**Localizados**|**Duplicados**|**Selecionados**|
|---|---|---|---|---|
|Medline (via<br>PubMed)|"Myasthenia Gravis"[Mesh]<br>OR "Myasthenia Gravis"[All<br>Fields] AND|41|**21**|**6**<br>**Motivo das exclusões:**|
|Data da busca:<br>29/08/2019|"2014/08/21"[PDAT] :<br>"2019/08/19"[PDAT] AND<br>(Meta-Analysis[ptyp] OR<br>Randomized Controlled<br>Trial[ptyp])|||- não respondiam a<br>pergunta PICO: 72|
|Medline (via<br>PubMed)|"Myasthenia Gravis"[Mesh]<br>OR "Myasthenia Gravis"[All<br>Fields] AND|3|||
|Data da busca:<br>29/08/2019|"2014/08/21"[PDAT] :<br>"2019/08/19"[PDAT] AND<br>Guideline[ptyp]||||
|Embase|('myasthenia gravis'/exp OR<br>'myasthenia gravis') AND|55|||
|Data da busca:<br>18/10/2018|([meta analysis]/lim OR<br>[randomized controlled<br>trial]/lim) AND<br>([english]/lim OR<br>[portuguese]/lim OR<br>[spanish]/lim) AND||||  
|[embase]/lim AND [2014-|
|---|
|2019]/py AND [article]/lim|  
Outros estudos de conhecimento dos especialistas foram incluídos para a atualização da seção de casos especiais do PCDT.

---

<!-- METADADOS: doenca: Miastenia Gravis | secao: **4. Exclusão de Medicamentos Sem Registro Sanitário Vigente no Brasil** -->
À 104ª Reunião Ordinária do Plenário da Conitec, realizada dia 09 de dezembro de 2021, foi analisado o Relatório de Recomendação nº 694/2021, que se refere à exclusão de medicamentos cujos registros sanitários estariam caducados ou cancelados no Brasil. Nessa ocasião, foi deliberado, por unanimidade, recomendar a exclusão de imunoglobulina humana 3 g pó liofilizado para solução injetável ou solução injetável e imunoglobulina humana 6 g em pó para solução injetável, devido à ausência de registros válidos na Agência Nacional de Vigilância Sanitária (Anvisa). A decisão de exclusão das apresentações foi publicada por meio da Portaria SCTIE/MS nº 83, de 29 de dezembro de 2021.  
Como essas apresentações de imunoglobulina humana estavam contempladas no Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Miastenia Gravis, fez-se necessário excluí-las da presente versão desse Protocolo. Para tal, foi adequado o Relatório de Recomendação nº 580/2021 da Conitec.  
Essa necessidade foi informada à 96ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 22 de fevereiro de 2022. e também à 106ª Reunião Ordinária da Conitec, realizada dias 09 e 10 de março de 2022.

---

