<!-- METADADOS: doenca: Insuficiência Adrenal | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 20, DE 24 DE NOVEMBRO DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Adrenal.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a insuficiência adrenal no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 556/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 562 – Outubro de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Insuficiência Adrenal.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da insuficiência adrenal, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da insuficiência adrenal.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 1.170/SAS/MS, de 19 de novembro de 2015, publicada no Diário Oficial da União nº 222, de 20 de novembro de 2015, seção 1, página 83.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: HÉLIO ANGOTTI NETO -->
ANEXO

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **1. INTRODUÇÃO** -->
A Insuficiência Adrenal (IA) é caracterizada pela falência da glândula adrenal na produção do hormônio cortisol (um glicocorticoide), podendo também afetar a produção de aldosterona (um mineralocorticoide). É uma condição grave e potencialmente fatal devido ao papel central desses hormônios na regulação do metabolismo e da homeostase hidroeletrolítica<sup>1</sup> .  
A IA pode ser dividida em primária (também chamada de doença de Addison, quando o defeito da produção está localizado na própria glândula adrenal), secundária (quando o defeito está localizado na hipófise) ou terciária (quando o defeito está localizado no hipotálamo). Essas duas últimas também podem ser agrupadas e chamadas de Insuficiência Adrenal Central (IAC)<sup>1,2</sup> . Cabe ressaltar que somente na IA primária haverá deficiência de mineralocorticoide, hormônio essencial para o equilíbrio hidroeletrolítico.  
A IA Primária (IAP) é considerada uma doença rara, com prevalência crescente na Europa: de 39 a 221 casos por 1.000.000 habitantes<sup>3-5</sup> . Dados de seguros de saúde da Alemanha também relatam uma prevalência crescente, principalmente no sexo feminino<sup>6</sup> . Em outras partes do mundo, os dados são escassos e parecem indicar uma prevalência menor. Inexistem dados epidemiológicos disponíveis no Brasil.  
Após a introdução de terapia antituberculosa eficaz, a autoimunidade tornou-se a principal causa de IAP em países desenvolvidos. Nos Estados Unidos e na Europa, a adrenalite autoimune é responsável por cerca de 70% a 90% dos casos<sup>7,8</sup> , seguida por doenças infecciosas (como tuberculose), adrenalectomia, neoplasia e várias doenças genéticas<sup>9</sup> . No Brasil, um estudo realizado em São Paulo demonstrou que a etiologia autoimune é a mais prevalente (39%), seguida de paracoccidioidomicose (28%), tuberculose (11%) e adrenoleucodistrofia (7,3%)<sup>10</sup> . Outra etiologia importante e crescente de IAP é a relacionada ao uso de medicamentos, como hemorragia adrenal relacionada à anticoagulação; inibição da síntese de cortisol por etomidato; e aumento do catabolismo do glicocorticoide por anticonvulsivantes – como fenitoína ou fenobarbital – ou por antibióticos, como rifampicina<sup>9</sup> .  
Uma forma específica de IAP é a Hiperplasia Adrenal Congênita (HAC), que é decorrente de defeitos enzimáticos na síntese de hormônios adrenais. Pelas especificidades na sua investigação e tratamento, esta doença é abordada em PCDT específico.  
Na IA secundária, qualquer doença que envolva a hipófise e interfira na secreção de corticotrofina (ACTH) pode estar envolvida na sua etiologia. A deficiência de ACTH pode ser isolada ou ocorrer em conjunto com outras deficiências hormonais hipofisárias (pan-hipopituitarismo). Geralmente, o ACTH é o último hormônio a ser perdido e isso, possivelmente, está relacionado à importância do eixo do cortisol para a sobrevivência. No entanto, deve-se lembrar que, em certas lesões da hipófise, como na hipofisite linfocítica, a deficiência de ACTH pode ocorrer isoladamente<sup>2</sup> . Mais recentemente, essa condição tem sido descrita com o uso de novos antineoplásicos que atuam no sistema imune (imunoterapia)<sup>11</sup> .  
A IA terciária refere-se a causas relacionadas a anormalidades hipotalâmicas que reduzem a secreção do hormônio liberador de corticotrofina (CRH). As causas mais comuns são aquelas relacionadas a diminuição abrupta de quadro de excesso de cortisol, seja ele exógeno, com interrupção de glicocorticoides em altas doses, ou endógeno, com a correção de hipercortisolismo na síndrome de Cushing<sup>12,13</sup> . Além disso, qualquer processo que envolva o hipotálamo e interfira na secreção de CRH poderá causar IA terciária: tumores, doenças infiltrativas (como sarcoidose) e radiação craniana<sup>2,14</sup> .  
A manifestação da IA pode ocorrer de forma aguda ou crônica, dependendo da velocidade com que a perda da produção hormonal ocorre. As manifestações da forma crônica podem ser inespecíficas, ocasionando o retardo no diagnóstico da doença. Frequentemente, o diagnóstico da IA é realizado durante uma crise de IA aguda, chamada crise addisoniana.  A crise addisoniana é ocasionada pela repentina falha na produção de esteroides adrenais (cortisol e aldosterona), que podem ser decorrentes de algum fator de estresse, como infecções, traumas, cirurgias ou outros fatores<sup>1</sup> . A crise pode resultar em uma situação de risco de vida, quando não tratada. Além disso, o diagnóstico tardio parece ser o principal determinante da qualidade de vida desses pacientes<sup>15</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da insuficiência adrenal. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E23.0 - Hipopituitarismo  
- E23.3 - Disfunção hipotalâmica não classificada em outra parte  
- E27.1 - Insuficiência adrenocortical primária  
- E27.2 - Crise addisoniana  
- E27.3 - Insuficiência adrenocortical induzida por drogas  
- E27.4 - Outras insuficiências adrenocorticais e as não especificadas

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **3.1. Diagnóstico clínico** -->
O diagnóstico clínico da IA pode ser desafiador, em especial fora da crise addisoniana, porque as manifestações clínicas mais frequentes são inespecíficas, como fadiga, perda de peso, náusea, vômitos, dor abdominal, dores articulares e musculares. Os sinais e sintomas mais específicos associados à IAP são hiperpigmentação cutânea – por elevação da proopiomelanocortina que é clivada em ACTH e no hormônio estimulador de melanócitos (MSH) –, hipotensão postural e avidez por sal, causadas pela deficiência de mineralocorticoide ou hipoaldosteronismo. Hiponatremia pode ocorrer na IAP e IAC, mas hipercalemia só ocorre na IAP por deficiência de mineralocorticoide<sup>1</sup> .  
Alguns antecedentes clínicos podem contribuir para o diagnóstico:  
- IAP: doenças autoimunes estão associadas à IAP nas síndromes poliglandulares autoimunes tipo 1 (candidíase mucocutânea, hipoparatireoidismo e diabete melito tipo 1) e tipo 2 (doenças autoimunes da tireoide, diabete melito tipo 1 e hipogonadismo hipergonadotrófico)<sup>16</sup> . Adicionalmente, história prévia de tuberculose, paracoccidioidomicose ou HIV em pacientes com manifestações clínicas compatíveis com IA indicam a necessidade de investigação laboratorial.  
- IAC: o uso prolongado de corticoide é a causa mais comum de IA, por supressão do eixo hipotálamo-hipófise-adrenal e consequente deficiência de ACTH<sup>1</sup> . Assim, uma anamnese detalhada para afastar uso prévio de corticoide é essencial. De forma geral, doses equivalentes a mais de 5 mg de prednisona por mais de 30 dias ou 20 mg de prednisona por mais de 2 semanas são capazes de suprimir o eixo hipotálamo-hipófise-adrenal e causar IAC<sup>17</sup> . Outros aspectos que devem ser investigados são antecedentes de cirurgia hipofisária, radioterapia de sistema nervoso central e a associação com outras deficiências hormonais hipofisárias (hipopituitarismo). A presença de hipoglicemia pode ocorrer em crianças com hipopituitarismo em virtude da deficiência concomitante do cortisol e hormônio do crescimento (GH).

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **3.2. Diagnóstico laboratorial** -->
Para o diagnóstico hormonal da IA, é necessário confirmar a baixa secreção de cortisol sérico e determinar a etiologia da IA a partir dos níveis de ACTH plasmático.  
O primeiro passo para a investigação hormonal da IA é a dosagem do cortisol sérico basal (dosado pela manhã entre 6 e 9h). Os valores de cortisol sérico são diretamente influenciados pelo nível da proteína ligadora do cortisol (do inglês _cortisol binding globulin_ , CBG). Pacientes em uso de estradiol (por exemplo, contraceptivos orais) podem apresentar valores falsamente elevados de cortisol. Dessa forma, é necessária a suspensão da reposição de estradiol para investigar o eixo hipotálamo-hipófise-adrenal<sup>1</sup> .  
O diagnóstico da IA é altamente provável se o cortisol sérico basal pela manhã for ≤ 3-5 mcg/dL. Já um cortisol sérico basal  15 mcg/dL tem um alto valor preditivo para uma resposta normal em testes de estímulo (teste da cortrosina, teste de hipoglicemia insulínica ou teste com hormônio estimulador de ACTH)<sup>18</sup> . Vale ressaltar que cortisol salivar e cortisol urinário de 24h não tem valor no diagnóstico da IA. Dehidroepiandrosterona sulfato (DHEAS) baixo para sexo e faixa etária pode contribuir para o diagnóstico de IA, principalmente em mulheres pré-menopausa, mas é pouco específico acima dos 50 anos em virtude do declínio fisiológico dos seus níveis<sup>19</sup> .

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **3.2.1. Insuficiência Adrenal Primária (IAP)** -->
Pacientes com IAP apresentam hipocortisolismo na vigência de valores elevados de ACTH plasmático. Valores de cortisol sérico basal < 5 mcg/dL associados a ACTH plasmático elevado em pelo menos 2 vezes acima do limite superior da normalidade, geralmente excedendo 100 pg/mL, são altamente sugestivos de IAP (Figura 1)<sup>1</sup> . Já cortisol sérico basal > 15 mcg/dL e ACTH plasmático dentro do limite de normalidade para o método de dosagem tornam o diagnóstico de IA pouco provável<sup>17,20</sup> .  
Pacientes com cortisol sérico basal entre 5 e 15 mcg/dL têm indicação de realizar teste de estímulo da função adrenal<sup>17,20</sup> . Vale ressaltar que a dosagem de cortisol reflete o cortisol total (90% ligado a proteínas plasmáticas, principalmente a CBG). Dessa forma, situações que aumentam CBG, como gestação e uso de anticoncepcional oral, podem elevar falsamente o cortisol basal. Em indivíduos saudáveis, o teste de tolerância à insulina ( _insulin tolerance test_ – ITT) elevou o ACTH a níveis médios de 110 pg/mL<sup>21</sup> . Baseado nesses dados, níveis de ACTH >100 pg/mL fornecem um estímulo máximo para a síntese de cortisol e são muito sugestivos de IAP mesmo com níveis de cortisol 5-15 mcg/dL (principalmente se associados à hiperpigmentação, hipercalemia e hiponatremia).  
Em função de <mark>a cortrosina não possuir registro pela Agência Nacional de Vigilância Sanitária (Anvisa) no Brasil,</mark> a alternativa para confirmar o diagnóstico é realizar o ITT ou teste de hipoglicemia insulínica, que consiste em induzir hipoglicemia (potente estímulo para liberação de CRH e ACTH) e avaliar a resposta do cortisol sérico. Insulina (na dose de 0,1 UI/Kg a 0,05 UI/Kg na suspeita de hipopituitarismo) é administrada com o objetivo de atingir uma glicemia de 40 mg/dL. O cortisol sérico deve ser dosado nos tempos 0, 30’, 60’e 90’, mesmo que o paciente tenha recebido glicose endovenosa para corrigir a hipoglicemia antes do término do teste. Este teste deve ser realizado sob supervisão médica em ambiente com recursos para atendimento de intercorrências. Está contraindicado em pacientes com histórico de convulsão, cardiopatia, doença vascular cerebral e em crianças com < 20Kg<sup>1</sup> . Uma dosagem de cortisol sérico  18 mcg/dL em qualquer um dos tempos dos testes afasta o diagnóstico de IA.  
Adicionalmente, pacientes com diagnóstico de IAP precisam ser avaliados para deficiência de mineralocorticoide por meio da dosagem de aldosterona e renina plasmáticas. Valores de aldosterona <3 ng/dL com renina elevada para o método de dosagem são diagnósticos de hipoaldosteronismo e os pacientes podem apresentar hiponatremia e hipercalcemia. Nesses pacientes, o tratamento deve incluir reposição de mineralocorticoide (vide item tratamento)<sup>1,2</sup> .  
O diagnóstico da insuficiência adrenal primária (IAP) encontra-se resumido na **Figura 1** .  
<!-- Start of picture text -->
Suspeita clínica de IAP<br>Coletar cortisol e ACTH entre 6-9h da manhã. O ACTH deve ser coletado em tubo<br>com EDTA no gelo (centrifugar em centrífuga refrigerada)<br>Cortisol entre 5 e 15  Cortisol ≥ 15<br>Cortisol ≤ 5 mcg/dL e<br>mcg/dL e DHEAS  mcg/dL e ACTH<br>ACTH > 100 pg/mL ? baixo. normal ?<br>Diagnóstico muito   Diagnóstico pouco<br>Realizar teste de estímulo<br>provável de IAP provável de IAP<br><!-- End of picture text -->  
**Figura 1-** Fluxograma de diagnóstico de Insuficiência Adrenal Primária (IAP)

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **3.2.2. Insuficiência Adrenal Central (IAC)** -->
O diagnóstico da IAC é confirmado pela presença de baixos níveis de cortisol sérico basal (≤ 3 mcg/dL) com ACTH plasmático baixo ou normal para o método de dosagem. Como comentado anteriormente, um cortisol sérico basal >15 mcg/dL torna muito pouco provável o diagnóstico de IAC<sup>18</sup> .  
A maior dificuldade diagnóstica ocorre nos pacientes com cortisol sério basal entre 3 e 15 mcg/dL e ACTH plasmático normal. Nessa situação, preconiza-se a realização de um teste de estímulo, já descrito no item anterior. Nos casos de valores de cortisol entre 3 e 15 mcg/dL, alguns antecedentes, como o uso prolongado de corticoterapia ou realização prévia de radioterapia ou cirurgia hipofisária, aumentam a probabilidade do diagnóstico de IAC.  
Pacientes com diagnóstico de IAC sem antecedente de hipopituitarismo têm indicação de avaliar a função hipofisária por meio da dosagem dos hormônios a seguir: hormônio de crescimento (GH), fator de crescimento semelhante à insulina tipo 1 (IGF1) ou  somatomedina C, gonadotrofinas (LH e FSH), estradiol (mulheres) e testosterona total ou testosterona livre (homens), hormônio tireoestimulante (TSH), T4 livre, e prolactina (PRL)<sup>20</sup> .  
O diagnóstico da insuficiência adrenal central (IAC) encontra-se resumido na **Figura 2** .  
<!-- Start of picture text -->
Suspeita clínica de IAC<br>Coletar cortisol e ACTH entre 6-9h da manhã. O ACTH deve ser coletado em tubo<br>com EDTA no gelo (centrifugar em centrífuga refrigerada)<br>Cortisol ≤ 3 mcg/dL e  Cortisol entre 3 e 15  Cortisol ≥ 15<br>ACTH normal ou  mcg/dL e ACTH<br>mcg/dL?<br>baixo? normal?<br>Diagnóstico de IAC<br>Diagnóstico de IAC Realizar teste de estímulo<br>pouco provável<br><!-- End of picture text -->  
**Figura 2 -** Fluxograma de diagnóstico de Insuficiência Adrenal Central (IAC)

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **3.3. Exames de imagem** -->
Pacientes com diagnóstico de IAP devem realizar uma tomografia computadorizada de abdômen superior com cortes finos para investigar a presença de calcificações ou massas adrenais, que possam sugerir uma etiologia infecciosa ou lesões secundárias metastáticas<sup>1</sup> . Na presença de lesões adrenais uni ou bilaterais (sólidas ou císticas) em pacientes com IAP, está indicada biópsia da lesão adrenal guiada por tomografia para determinar a etiologia e orientar o tratamento. Pacientes com IAP e diagnóstico de síndrome poliglandular autoimune ou adrenoleucodistrofia não necessitam de investigação por imagem.  
Pacientes com diagnóstico de IAC precisam realizar ressonância magnética da hipófise e hipotálamo para avaliar a presença ou progressão de lesões ou haste<sup>1</sup> .  
Quando for realizado o diagnóstico etiológico da causa da IA para o qual houver tratamento, este deve ser realizado de acordo com as recomendações específicas.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes com quadro clínico sugestivo e que apresentarem diagnóstico laboratorial confirmado ou provável de IAP ou IAC, conforme o item 3. Diagnóstico.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes com intolerância, hipersensibilidade ou contraindicação ao uso do respectivo medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **6. TRATAMENTO** -->
O tratamento dos pacientes com IA, de uma maneira geral, tem como principal objetivo suprir a deficiência de glicocorticoides na IAP e IAC, além de suprir a deficiência mineralocorticoide, na IAP. Visando a descrever melhor as diferenças terapêuticas, conforme a origem da doença, será apresentado o tratamento em três subdivisões: IAP, IAC e crise addisoniana.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **6.1. Insuficiência Adrenal Primária (IAP)** -->
Atualmente, ainda são escassos ensaios clínicos randomizados com desfechos clínicos, que estudem a IA e, dessa forma, a prescrição de glicocorticoide e mineralocorticoide é baseada em estudos observacionais, bem como em consensos das sociedades especializadas<sup>1,22</sup> .  
A reposição de glicocorticoide é a medida de maior importância para o tratamento da doença e melhoria da qualidade de vida do paciente<sup>23</sup> . Essa reposição deve ser prática, mimetizando o ritmo circadiano de secreção do cortisol, com o objetivo de diminuir o aparecimento de efeitos adversos. A reposição de glicocorticoide deve ainda ser feita utilizando-se a menor dose possível para o controle de sintomas<sup>24</sup> .  
No tratamento crônico, a preferência é pelo uso da hidrocortisona oral, mas que não é disponível no Brasil. Dessa forma, utiliza-se prednisona ou do fosfato sódico de prednisolona, glicocorticoides com pequeno efeito mineralocorticoide e menor incidência de miopatia do que os glicocorticoides fluorados (como a dexametasona, que não é preconizada). A dose habitual de prednisona ou prednisolona para tratamento da IAP é de 5,0-7,5 mg/dia<sup>1</sup> .  Pacientes com IAC podem necessitar de doses menores de reposição de corticoide (2,5 a 5,0 mg/dia)<sup>20,23</sup> .  
O ajuste da dose do glicocorticoide deve considerar situações de estresse, quando se deve pelo menos dobrar a dose habitual. São consideradas situações de estresse a síndrome febril (≥ 38,5 °C), gastroenterite com desidratação, partos normais ou por cesariana, cirurgia com anestesia geral e grandes traumas. Não se preconiza o uso de doses maiores de glicocorticoide exclusivamente por estresse emocional e antes de exercício físico habitual. No entanto, a dose de glicocorticoide pode ser fracionada em duas tomadas de acordo com o horário da atividade física para melhor controle de sintomas<sup>25</sup> .  
O uso da fludrocortisona em associação ao glicocorticoide é de extrema importância na IAP, devido à incapacidade adrenal de produção mineralocorticoide. Estudos demonstraram a efetividade do medicamento em salvar a vida dos pacientes com IAP<sup>26</sup> .

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **6.2. Insuficiência Adrenal Central (IAC)** -->
A principal diferença entre o tratamento da IAP e a IAC é a ausência de necessidade da reposição mineralocorticoide nesta última<sup>27</sup> . Da mesma forma que na IAP, pacientes com IAC necessitam de terapia de reposição glicocorticoide ao longo da vida. Considerações quanto ao tipo e a dose de glicocorticoide a ser usado são as mesmas aplicadas na IAP. A dose média de prednisona ou prednisolona para tratamento da IA central é de 5,0 mg/dia. Uma vez que é possível haver secreção residual de ACTH em pacientes com IA central, alguns pacientes apresentam controle clínico com a dose de 2,5 mg/dia de prednisona<sup>27,28</sup> .

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **6.3. Crise addisoniana** -->
A IA aguda ou crise addisoniana é uma condição relativamente rara em urgências, mas se não for diagnosticada e tratada adequadamente, pode evoluir para o óbito. É um diagnóstico difícil, devido à falta de sinais e sintomas específicos<sup>29</sup> . Em pacientes que buscam serviços de urgência com queixas de dor abdominal, hipotensão que não responde a volume ou vasopressores, essa condição deve ser investigada. Pacientes hemodinamicamente estáveis podem ser submetidos a métodos diagnósticos mais precisos para confirmar ou descartar uma crise addisoniana. Pacientes instáveis devem ser imediatamente tratados com glicocorticoide intravenoso (succinato sódico de hidrocortisona), pelo risco de vida, mesmo antes de testes de confirmação<sup>30</sup> .  
Após melhora clínica, com adequada hidratação e boa perfusão periférica, a reposição de glicocorticoide deverá ser administrada por via oral e a reposição de mineralocorticoide iniciada. Como a hidrocortisona apresenta atividade glicocorticoide e mineralocorticoide na dose preconizada para situações de crise adrenal, não é necessária manutenção do uso de fludrocortisona concomitante à hidrocortisona intravenosa (IV) ou intramuscular (IM)<sup>1,2</sup> .

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: <u>Glicocorticoides:</u> -->
- Prednisona: comprimidos de 5 e 20 mg.  
- Fosfato sódico de prednisolona: solução oral de 1 mg/mL (equivalente a 1,34 mg/mL de fosfato sódico de prednisolona e 1 mg de prednisolona base) e 3 mg/mL (equivalente a 4,02 mg/mL de fosfato sódico de prednisolona e 3 mg de prednisolona base).  
- Succinato sódico de hidrocortisona: pó para solução injetável de 100 e 500 mg.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: <u>Mineralocorticoide</u> -->
- Acetato de fludrocortisona: comprimido de 0,1 mg.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **6.5. Esquema de administração** -->
- Prednisona: administrada por via oral (VO), em dose única diária, ou duas vezes ao dia. Dose inicial em crianças: 2,5-4 mg/m<sup>2</sup> /dia Dose inicial em adultos: 2,5-7,5 mg/dia  
- Fosfato sódico de prednisolona: administrada por VO, em dose única diária, ou duas vezes ao dia. Dose inicial em crianças: 2-3 mg/m<sup>2</sup> /dia Dose inicial em adultos: 2,5-7,5 mg/dia  
- Succinato sódico de hidrocortisona: administrada por via IM ou IV  
Dose inicial em crianças: 12-18 mg/m<sup>2</sup> /dia divididas entre duas e quatro aplicações. Em estresse ou crise adrenal: 60100 mg/m<sup>2</sup> /dia.  
Dose inicial em adultos: 20-30 mg/dia divididas entre duas e quatro aplicações. Em estresse ou crise adrenal: 200 mg/dia (50 mg IV 6/6h)<sup>27</sup> .  
<u>Crise adissoniana:</u>  
*Dose de ataque: 20 mg IV para recém-nascidos; 50 mg IV para lactentes e pré-escolares; 100 mg IV para escolares, adolescentes e adultos.  
*Dose de manutenção após a dose de ataque: 50 mg IV 6/6h<sup>27</sup> .  
 Acetato de fludrocortisona: administrada por VO, em dose única diária. Crianças: 0,1 mg/dia (podendo variar de 0,05-0,3 mg/dia) Adultos: 0,1 mg/dia (podendo variar de 0,05-0,4 mg/dia)  
A dose de manutenção é normalmente de 0,1 mg/dia.  
Em gestantes, para evitar a exposição fetal excessiva aos glicocorticoides, o tratamento é realizado preferencialmente com medicamento metabolizável pela placenta, como prednisona, prednisolona ou hidrocortisona. Devido ao aumento da necessidade de corticoide na gravidez, preconiza-se que nesse período sejam utilizadas doses mais elevadas, cerca de 7,5  
mg/dia de prednisona ou prednisolona. A utilização de hidrocortisona como tratamento de manutenção é uma exceção, sendo usada apenas para pacientes sem condições de via oral. A dose IV ou IM de manutenção é de aproximadamente 20 mg/dia. Na indução do parto, o uso de hidrocortisona em dose de estresse deve ser considerado (200-300 mg/dia em duas a quatro aplicações ao dia)<sup>31,32</sup> .

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **6.6. Benefícios esperados** -->
- Resolução dos sintomas de deficiência hormonal;  
- melhora da qualidade de vida;  
- prevenção de crises addisonianas; e  
- diminuição da mortalidade.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **7. MONITORAMENTO** -->
A reposição glicocorticoide deve ser feita por toda a vida, tanto na IAP, quanto na IAC. Para IAP, além da reposição glicocorticoide, a reposição mineralocorticoide também deve ser feita. A reposição hormonal na IA apresenta benefícios importantes no controle da doença e na melhora da qualidade de vida<sup>26</sup> .  
O acompanhamento dos pacientes com IA deve ser feito, <mark>preferencialmente,</mark> por endocrinologista, <mark>com intervalo de 2 a 6 meses entre as consultas.</mark> Em todas as consultas, os dados clínicos e laboratoriais devem ser levados em consideração. Na prática clínica, alcançar a dose de reposição correta é um grande desafio, especialmente na identificação da menor dose de glicocorticoide capaz de aliviar os sintomas de insuficiência, evitando o excesso de cortisol<sup>1,2</sup> .  
A reposição glicocorticoide não deve ser monitorada por meio de exames laboratoriais como ACTH e cortisol sérico, sendo mais importante a monitorização pela avaliação clínica<sup>28,29</sup> . É fundamental a avaliação clínica do excesso de glicocorticoide pela fragilidade capilar, presença de giba, estrias violáceas, fácies de lua cheia, fraqueza muscular proximal e hipertensão ou da falta de cortisol por hipotensão arterial, hipotensão ortostática ou sonolência. O excesso de glicocorticoide tem impacto negativo, podendo levar à osteoporose, miopatia, hipertensão arterial, dislipidemia, diabete melito, esteatohepatite, infecções oportunistas, catarata e, em crianças, deficiência de crescimento<sup>28,29</sup> . Preconizam--se a pesquisa da presença de hipotensão postural e a realização de exames de sódio, potássio e creatinina a cada 6 meses no primeiro ano e, após, anualmente com ajuste de dose, se necessário<sup>1,22</sup> .  
Para o acompanhamento da reposição de mineralocorticoide, deve-se dosar a atividade da renina ou a renina plasmática, sódio e potássio, além da pesquisa de presença de hipotensão postural. O objetivo do tratamento é normalizar os níveis de sódio (135-145 mEq/L) e potássio (3,5-5,5 mEq/L), não suprimir a renina e manter a pressão arterial normal. Supressão de renina ou hipertensão podem indicar excesso de mineralocorticoide, sendo necessária revisão da dose de fludrocortisona<sup>26</sup> .  
Preconiza-se ainda, para o caso de necessidade de atendimento emergencial nas crises addisonianas, que todo paciente com insuficiência adrenal porte consigo identificação (pulseira, corrente ou cartão) informando sua condição, com contatos de emergência<sup>1,22</sup> . É de extrema relevância a necessidade de educação do paciente, do conhecimento dos sintomas de descompensação aguda e da maior adesão ao tratamento, visando a diminuir a ocorrência de crises addisonianas<sup>30</sup>

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas, a adequação de uso do e o acompanhamento pós-tratamento.  
Doentes de insuficiência adrenal devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no Protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **9. REFERÊNCIAS** -->
1. Bornstein SR, Allolio B, Arlt W, et al. Diagnosis and Treatment of Primary Adrenal Insufficiency: An Endocrine Society Clinical Practice Guideline. _The Journal of clinical endocrinology and metabolism._ 2016;101(2):364-389.  
2. Grossman AB. Clinical Review#: The diagnosis and management of central hypoadrenalism. _J Clin Endocrinol Metab._ 2010;95(11):4855-4863.  
3. Betterle C, Presotto F, Furmaniak J. Epidemiology, pathogenesis, and diagnosis of Addison's disease in adults. _J Endocrinol Invest._ 2019;42(12):1407-1433.  
4. Willis AC, Vince FP. The prevalence of Addison's disease in Coventry, UK. _Postgrad Med J._ 1997;73(859):286288.  
5. Laureti S, Vecchi L, Santeusanio F, Falorni A. Is the prevalence of Addison's disease underestimated? _J Clin Endocrinol Metab._ 1999;84(5):1762.  
6. Meyer G, Neumann K, Badenhoop K, Linder R. Increasing prevalence of Addison's disease in German females: health insurance data 2008-2012. _Eur J Endocrinol._ 2014;170(3):367-373.  
7. Falorni A, Laureti S, De Bellis A, et al. Italian addison network study: update of diagnostic criteria for the etiological classification of primary adrenal insufficiency. _J Clin Endocrinol Metab._ 2004;89(4):1598-1604.  
8. Nerup J. Addison's disease--clinical studies. A report fo 108 cases. _Acta Endocrinol (Copenh)._ 1974;76(1):127-141.  
9. Bornstein SR. Predisposing factors for adrenal insufficiency. _N Engl J Med._ 2009;360(22):2328-2339.  
10. Silva Rdo C, Castro M, Kater CE, et al. [Primary adrenal insufficiency in adults: 150 years after Addison]. _Arq Bras Endocrinol Metabol._ 2004;48(5):724-738.  
11. de Filette J, Andreescu CE, Cools F, Bravenboer B, Velkeniers B. A Systematic Review and Meta-Analysis of Endocrine-Related Adverse Events Associated with Immune Checkpoint Inhibitors. _Horm Metab Res._ 2019;51(3):145-156.  
12. Broersen LHA, Pereira AM, Jørgensen JOL, Dekkers OM. Adrenal insufficiency in corticosteroids use: Systematic review and metaanalysis. _Nederlands Tijdschrift voor Geneeskunde._ 2015;159(38).  
13. Di Dalmazi G, Reincke M. Adrenal function after adrenalectomy for subclinical and overt Cushing's syndrome: A systematic review of the literature. _Experimental and Clinical Endocrinology and Diabetes._ 2014;122(3).  
14. Schmiegelow M, Feldt-Rasmussen U, Rasmussen AK, Lange M, Poulsen HS, Muller J. Assessment of the hypothalamo-pituitary-adrenal axis in patients treated with radiotherapy and chemotherapy for childhood brain tumor. _J Clin Endocrinol Metab._ 2003;88(7):3149-3154.  
15. Meyer G, Hackemann A, Penna-Martinez M, Badenhoop K. What affects the quality of life in autoimmune Addison's disease? _Horm Metab Res._ 2013;45(2):92-95.  
16. Husebye ES, Anderson MS, Kampe O. Autoimmune Polyendocrine Syndromes. _N Engl J Med._ 2018;378(12):11321141.  
17. Broersen LH, Pereira AM, Jorgensen JO, Dekkers OM. Adrenal Insufficiency in Corticosteroids Use: Systematic Review and Meta-Analysis. _The Journal of clinical endocrinology and metabolism._ 2015;100(6):2171-2180.  
18. Schmidt IL, Lahner H, Mann K, Petersenn S. Diagnosis of adrenal insufficiency: Evaluation of the corticotropinreleasing hormone test and Basal serum cortisol in comparison to the insulin tolerance test in patients with hypothalamic-pituitary-adrenal disease. _The Journal of clinical endocrinology and metabolism._ 2003;88(9):41934198.  
19. Orentreich N, Brind JL, Rizer RL, Vogelman JH. Age changes and sex differences in serum dehydroepiandrosterone sulfate concentrations throughout adulthood. _The Journal of clinical endocrinology and metabolism._ 1984;59(3):551-555.  
20. Fleseriu M, Hashim IA, Karavitaki N, et al. Hormonal Replacement in Hypopituitarism in Adults: An Endocrine Society Clinical Practice Guideline. _The Journal of clinical endocrinology and metabolism._ 2016;101(11):38883921.  
21. Borm K, Slawik M, Seiler L, et al. Is the plasma ACTH concentration a reliable parameter in the insulin tolerance test? _European journal of endocrinology / European Federation of Endocrine Societies._ 2003;149(6):535-541.  
22. Reznik Y, Barat P, Bertherat J, et al. SFE/SFEDP adrenal insufficiency French consensus: Introduction and handbook. _Ann Endocrinol (Paris)._ 2018;79(1):1-22.  
23. Al Nofal A, Bancos I, Benkhadra K, et al. Glucocorticoid replacement regimens in chronic adrenal insufficiency: A systematic review and meta-analysis. _Endocrine Practice._ 2017;23(1):17-31.  
24. Esposito D, Pasquali D, Johannsson G. Primary Adrenal Insufficiency: Managing Mineralocorticoid Replacement Therapy. _J Clin Endocrinol Metab._ 2018;103(2):376-387.  
25. Ceccato F, Scaroni C. Central adrenal insufficiency: open issues regarding diagnosis and glucocorticoid treatment. _Clin Chem Lab Med._ 2019;57(8):1125-1135.  
26. Dineen R, Thompson CJ, Sherlock M. Adrenal crisis: prevention and management in adult patients. _Therapeutic advances in endocrinology and metabolism._ 2019;10:2042018819848218-2042018819848218.  
27. Prete A, Taylor AE, Bancos I, et al. Prevention of adrenal crisis: cortisol responses to major stress compared to stress dose hydrocortisone delivery. _The Journal of clinical endocrinology and metabolism._ 2020.  
28. Guignat L, Proust-Lemoine E, Reznik Y, Zenaty D. Group 6. Modalities and frequency of monitoring of patients with adrenal insufficiency. Patient education. _Annales d'endocrinologie._ 2017;78(6):544-558.  
29. Murray RD, Ekman B, Uddin S, Marelli C, Quinkler M, Zelissen PM. Management of glucocorticoid replacement in adrenal insufficiency shows notable heterogeneity - data from the EU-AIR. _Clin Endocrinol (Oxf)._ 2017;86(3):340-346.  
30. Hahner S, Spinnler C, Fassnacht M, et al. High Incidence of Adrenal Crisis in Educated Patients With Chronic Adrenal Insufficiency: A Prospective Study. _The Journal of Clinical Endocrinology & Metabolism._ 2015;100(2):407-416.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Fludrocortisona, hidrocortisona, prednisona e prednisolona.  
Eu, ____________________________________________________ (nome do [a] paciente), declaro ter sido  
informado (a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso dos medicamentos **fludrocortisona, hidrocortisona, prednisona e prednisolona** , indicados para o tratamento da **insuficiência adrenal** .  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _______________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- resolução dos sintomas de deficiência hormonal;  
- melhora da qualidade de vida;  
- prevenção de crises addisonianas; e  
- diminuição da mortalidade.  
- Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Prednisona: medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela).  
- Fludrocortisona, hidrocortisona e prednisolona: medicamentos classificados na gestação como fator de risco C (não se sabe ao certo os riscos do uso deste medicamento na gravidez, portanto, caso engravide, o médico deverá ser avisado imediatamente). Pequenas quantidades do medicamento podem passar para o leite materno, portanto o uso da fludrocortisona durante a amamentação não é indicado.  
- Efeitos adversos da **prednisona, prednisolona, hidrocortisona** : retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, osteoporose, problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabetes melito.  
- Efeitos adversos da **fludrocortisona** :  náusea, vômitos, diarreia, dores de cabeça, nervosismo, desorientação, fraqueza, convulsões, ganho de peso, inchaço, alterações do paladar, aumento da pressão arterial, perda de potássio e insuficiência cardíaca congestiva.  
- Medicamento está contraindicado em casos de hipersensibilidade (alergia) conhecida ao fármaco.  
- O risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este (s) medicamento (s) somente pode (m) ser utilizado (s) por mim, comprometendo-me a devolvê-  
lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.      (    ) Sim      (  ) Não  
Meu tratamento constará do (s) seguinte (s) medicamento (s):  
- (   ) Fludrocortisona  
- (   ) Hidrocortisona  
- (   ) Prednisona  
- (   ) Prednisolona  
<!-- Start of picture text -->
Local:                                                                Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico Responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da  
Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**APÊNDICE 1**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **1. Escopo e finalidade do Protocolo** -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Insuficiência Adrenal Primária (Doença de Addison) iniciou-se com a reunião presencial para delimitação do escopo. O objetivo desta reunião foi a discussão da atualização do referido PCDT.  
Essa reunião presencial contou com a presença de seis membros do Grupo Elaborador –  três dos quais especialistas e representantes da sociedade médica e três metodologistas – e quatro representantes do Comitê Gestor. Uma reunião presencial para revisão do escopo do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria nº 1.170/SAS/MS, de 19/11/2015) e na estrutura de PCDT definida pela Portaria n° 375/SAS/MS, de 10/11/2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador, com o objetivo de revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi definido que o escopo do PCDT deveria englobar também a insuficiência adrenal central, alterando-se o título para insuficiência adrenal. Também foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente, além de incluir em todas as seções do PCDT a insuficiência adrenal central.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **<u>Colaboração externa</u>** -->
Além dos representantes do Departamento de Gestão, Inovação e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), participaram do desenvolvimento deste Protocolo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.  
Todos os presentes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **<u>Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas</u>** -->
No dia 12 de maio de 2020, o PCDT da Insuficiência Adrenal foi submetido à Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas em sua 79ª Reunião. Foi realizada apresentação do PCDT, seguida de considerações dos participantes.  
Foram apontadas necessidades de formatação e padronização do texto, assim como a inserção de referências bibliográficas em parágrafos específicos do documento. Também foi indicada a necessidade de complementação da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS com diagnósticos e medicamentos do Componente Especializado da Assistência Farmacêutica (CEAF) utilizados neste PCDT. Foi solicitado rever o apêndice metodológico, detalhando melhor a estratégia de busca, com a inclusão do fluxograma do processo de busca e seleção de artigos e complementação com literatura cinzenta e atualizar a busca.  
Previamente à reunião, foi enviado para a CPCDT o documento revisado pelo Departamento de Ciência e Tecnologia (DECIT/SCTIE/MS), e outras contribuições do DAF (Departamento de Assistência Farmacêutica) foram recebidas por e- mail, solicitando a correção gramatical de alguns itens no texto.

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **<u>Consulta pública</u>** -->
A Consulta Pública nº 39 do PCDT da Insuficiência adrenal foi realizada entre os dias 20/08/2020 a 08/09/2020.  
Foram recebidas 269 contribuições no total e salienta-se que todas foram analisadas. O conteúdo integral das contribuições  
|encontra-se<br>disponível<br>na<br>página<br>da<br>Conitec|em:|
|---|---|
|http://Conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_39_2020_PCDT_Insuficincia.pdf.||

---

<!-- METADADOS: doenca: Insuficiência Adrenal | secao: **3. Busca da evidência e recomendações** -->
Para auxiliar na atualização do PCDT, foram realizadas buscas na literatura nas bases de dados Pubmed e Embase,  
conforme o **Quadro A** .  
**Quadro A -** Descrição das buscas, resultados e estudos selecionados.  
|**Base**|**Estratégia**|**Localizados**|**Duplicados**|**Selecionados**|
|---|---|---|---|---|
|Medline (via<br>PubMed)<br>Data da<br>busca:<br>11/05/2020|("Addison Disease"[Mesh]<br>OR "Addison Disease"[All<br>Fields] OR "Primary adrenal<br>insufficiency"[All Fields] OR<br>"adrenal insufficiency"[All<br>Fields]) AND<br>(Guideline[ptyp] OR Practice<br>Guideline[ptyp] OR Meta-<br>Analysis[ptyp] OR<br>systematic[sb]) AND<br>("2014/10/10"[PDAT] :<br>"2020/05/11"[PDAT])|56|**36**|**09**<br>**Motivo das**<br>**exclusões:**<br>temas não<br>relacionados ao<br>PCDT, medicamentos<br>sem registro no Brasil,<br>estudo pouco<br>relevante para o<br>PCDT, estudos<br>incluídos em meta-<br>|
|Embase<br>Data da<br>busca:<br>11/05/2019|('addison disease'/exp OR<br>'adrenal insufficiency'/exp)<br>AND ([cochrane review]/lim<br>OR [systematic review]/lim<br>OR [meta analysis]/lim)<br>AND [embase]/lim AND<br>[2014-2020]/py|143||análise de melhor<br>qualidade e mais<br>recente sobre o tema e<br>relatos de caso.|  
Seguem os estudos selecionados a partir das buscas e a sua citação no texto do PCDT:  
1. Bornstein SR, Allolio B, Arlt W, Barthel A, Don-Wauchope A, Hammer GD, et al. Diagnosis and Treatment of Primary Adrenal Insufficiency: An Endocrine Society Clinical Practice Guideline. J Clin Endocrinol Metab. 2016;101(2):364-89 - referência 1  
2. de Filette J, Andreescu CE, Cools F, Bravenboer B, Velkeniers B. A Systematic Review and Meta-Analysis of Endocrine-Related Adverse Events Associated with Immune Checkpoint Inhibitors. Horm Metab Res. 2019;51(3):145-56 – referência  11  
3. Di Dalmazi G, Reincke M. Adrenal function after adrenalectomy for subclinical and overt Cushing's syndrome: A systematic review of the literature. Experimental and Clinical Endocrinology and Diabetes. 2014;122(3) – referência 13  
4. Broersen LH, Pereira AM, Jorgensen JO, Dekkers OM. Adrenal Insufficiency in Corticosteroids Use: Systematic Review and Meta-Analysis. The Journal of clinical endocrinology and metabolism. 2015;100(6):2171-80 – referência 17  
5. Ospina NS, Al Nofal A, Bancos I, Javed A, Benkhadra K, Kapoor E, et al. ACTH Stimulation Tests for the Diagnosis of Adrenal Insufficiency: Systematic Review and Meta-Analysis. The Journal of clinical endocrinology and metabolism. 2016;101(2):427-34 – referência 20  
6. Al Nofal A, Bancos I, Benkhadra K, Ospina NMS, Javed A, Kapoor E, et al. Glucocorticoid replacement regimens in chronic adrenal insufficiency: A systematic review and meta-analysis. Endocrine Practice. 2017;23(1):17-31 - referência 23  
7. Prete A, Yan Q, Al-Tarrah K, et al. The cortisol stress response induced by surgery: A systematic review and metaanalysis. Clin Endocrinol (Oxf). 2018;89(5):554‐567 – referência 25  
8. Esposito D, Pasquali D, Johannsson G. Primary Adrenal Insufficiency: Managing Mineralocorticoid Replacement Therapy. J Clin Endocrinol Metab. 2018;103(2):376-87 – referência 26  
9. Ceccato F, Scaroni C. Central adrenal insufficiency: open issues regarding diagnosis and glucocorticoid treatment. Clin Chem Lab Med. 2019;57(8):1125-35 - referência 27  
Outros estudos de conhecimento dos especialistas foram incluídos para a atualização do PCDT.

---

