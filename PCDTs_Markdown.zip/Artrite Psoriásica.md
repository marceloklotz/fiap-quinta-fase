<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA CONJUNTA Nº 37, DE 21 DE JANEIRO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Artrite Psoriásica.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E**  
**INOVAÇÃO EM SAÚDE,** o uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023; e  
Considerando a necessidade de se atualizarem os parâmetros sobre a Artrite Psoriásica no Brasil e as diretrizes nacionais para  
diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Relatório de Recomendação nº 1023/2025 e o Registro de Deliberação nº 1021/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Artrite Psoriásica.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da Artrite Psoriásica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Artrite Psoriásica.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede  
assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SCTIE nº 9, de 21 de maio de 2021, publicada no Diário Oficial da União nº 100, de 28 de maio de 2021, Seção 1, pág. 227.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES  
FERNANDA DE NEGRI  
**PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS ARTRITE PSORIÁSICA**

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
A artrite psoriásica (AP), também dita psoriática ou psoríaca<sup>1–3</sup> , é uma doença sistêmica inflamatória associada à psoríase. A AP integra o grupo das espondiloartrites, caracterizada por apresentar sorologia do fator reumatoide geralmente negativa, acometimento da pele (psoríase), unhas (ungueal), articulações periféricas, do esqueleto axial (espondilite ou sacroiliíte), entesites (inflamação da inserção de tendões, ligamentos e cápsula articular às superfícies ósseas) e dactilites (“dedo em salsicha”)<sup>4–6</sup> . São doenças que também compõem o grupo das espondiloartrites: espondilite anquilosante, espondiloartrite enteropática, artrite relacionada à entesite (forma juvenil) e a espondiloartrite indiferenciada<sup>4</sup> .  
A AP é uma doença imunomediada poligênica, de etiologia indefinida, na qual as citocinas relacionadas aos linfócitos T têm papel central, como ocorre na psoríase. Níveis elevados de citocinas pró-inflamatórias (TNF, IL-1 e IL-6) podem ser encontrados na pele e na sinóvia de pacientes com AP com envolvimento das articulações periféricas, sendo aquelas responsáveis pela elevação de fatores de crescimento celular, espessamento de capilares e pequenas artérias, assim como infiltrados inflamatórios peri-articulares<sup>4,5</sup> .  
Em mais de 40% dos casos existe familiar de primeiro grau com psoríase ou AP, mas evidências recentes<sup>6,7</sup> sugerem que a herdabilidade da AP seja mais forte e distinta da psoríase cutânea. Fatores ambientais, infecciosos e imunogênicos podem favorecer a manifestação da AP<sup>4–9</sup> . Trata-se de uma doença que aumenta o risco para o desenvolvimento de doenças cardiovasculares, obesidade, síndrome metabólica, diabete melito, hipercolesterolemia, doenças oftálmicas autoimunes, osteoporose, doenças inflamatórias do intestino (doença de Crohn e colite ulcerativa), problemas renais, transtornos psiquiátricos e distúrbios neurológicos e pulmonares<sup>8,10,11</sup> .  
A prevalência global da AP pode atingir de 0,3% a 1,0% da população com uma incidência que varia de 0,01 a 5,0 a cada 100.000 casos ao ano<sup>12</sup> . Já em pacientes com psoríase, a prevalência aumenta, variando de 6% a 41%<sup>13–17</sup> . Essa variabilidade é decorrente dos diferentes critérios diagnósticos utilizados e no tempo de evolução da psoríase cutânea<sup>5,14</sup> . Estudos epidemiológicos brasileiros apontam que a AP é a segunda espondiloartrite mais frequente no País, com uma prevalência de 13,7%<sup>18</sup> , sendo superior a 33% na população previamente acometida com psoríase<sup>19</sup> . Em 75% dos casos, a AP se manifesta após o aparecimento das lesões cutâneas, havendo início simultâneo em 10% dos pacientes e podendo, em 15%, preceder a psoríase<sup>5</sup> .  
A apresentação clínica da AP é heterogênea e varia desde manifestações articulares e dermatológicas a complicações articulares com erosão óssea, que ocorrem em até 40% a 60% dos casos<sup>10,20</sup> . Os sintomas como fadiga, dor e comorbidades associadas podem ter grande impacto psicológico. Isto leva a comprometimento das atividades diárias e da qualidade de vida dos pacientes<sup>10,20,21</sup> .  
O prognóstico da doença é pior na presença de dano articular e acometimento de articulações como quadril, punho, tornozelo, coluna cervical e articulação sacroilíaca, elevação das provas de reação inflamatórias e manifestações extra-articulares 22–25. Estudos sugerem que aproximadamente 20% dos pacientes desenvolvem uma forma destrutiva da AP e que 50% apresentam erosões articulares após o segundo ano de doença<sup>22–25</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
- M070 Artropatia psoriática interfalangiana distal  
- M072 Espondilite psoriásica  
- M073 Outras artropatias psoriáticas.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, racismo, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.  
A artrite psoriásica é uma doença heterogênea, sendo possível o envolvimento de pelo menos cinco manifestações, que incluem psoríase (acometimento cutâneo), doença articular periférica, doença axial (coluna vertebral e sacroilíaca), entesite e dactilite.  
O diagnóstico da AP é baseado no reconhecimento de características clínicas e de imagem. Inexistem exames específicos, e quase 10% dos pacientes com AP têm fator reumatóide positivo em baixos títulos.  
A erosão óssea e cartilaginosa com formação de pontes ósseas é característica da AP, sendo mais frequente nas articulações interfalângicas, calcificações paravertebrais, formação óssea justa-articular e deformidades do tipo lápis-naxícara<sup>26,27</sup> .  
Neste sentido, radiografia simples (RX), ultrassonografia (USG), ressonância magnética (RM), tomografia computadorizada (TC) ou cintilografia óssea podem auxiliar no diagnóstico de anomalias características da AP, como alterações do esqueleto axial, entesites, dactilites e sinovites<sup>20,26</sup> .  
O acometimento articular da AP pode ocorrer isoladamente ou em associação<sup>4–9,21,26</sup> :  
- **Artrite periférica** : dor e aumento de partes moles ou derrame articular em articulações periféricas ou alterações radiológicas, independentemente do método utilizado (RX, USG, TC ou RM). Cinco subtipos clássicos de acometimento articular são descritos: oligoarticular (quatro ou menos articulações e geralmente em distribuição assimétrica); poliarticular (cinco ou mais articulações, podendo ser simétrico e semelhante à artrite reumatoide); distal (articulações interfalângicas distais das mãos, pés ou ambos, que geralmente ocorrem com outros subtipos); artrite mutilante (artrite destrutiva com reabsorção óssea acentuada ou osteólise); e acometimento axial<sup>27</sup> .  
- **Artrite axial** : 20% a 70% dos pacientes com AP desenvolvem acometimento axial<sup>28</sup> . A inflamação da coluna vertebral pode levar à fusão completa, como na espondilite anquilosante (EA), ou afetar apenas certas áreas, como a região lombar ou o pescoço. O envolvimento axial na AP pode ainda incluir lesões vertebrais nos cantos vertebrais, quadratura das vértebras, esclerose, sindesmófitos (marginais e paramarginais), discite, artrite interfacetária, subluxação atlanto-axial e ossificação paravertebral.  
O acometimento axial se manifesta clinicamente por dor em qualquer região vertebral ou pela presença de alteração em exame de imagem: sacroiliíte bilateral de graus 2 a 4 ou unilateral de graus 3 a 4 à radiografia simples, ou pelo menos um sindesmófito marginal/paramarginal em coluna lombar ou cervical<sup>29</sup> , ou ressonância magnética com edema de medula óssea. Até 25% dos pacientes com AP têm doença axial assintomática<sup>30</sup> .  
- **Entesite** : dor e presença de edema em enteses (locais de inserção óssea de tendões, ligamentos ou cápsula articular) ou alterações em exames de imagem (RX, US, TC ou RM). A entesite é observada em 30% a 50% dos pacientes com AP, e os  
locais mais acometidos são a fáscia plantar e o tendão calcâneo, inserção da patela, crista ilíaca, epicôndilos e inserção supraespinhal<sup>27</sup> .  
- **Dactilite** : edema uniforme com ou sem dor e eritema dos tecidos moles dos dedos das mãos ou dos pés. Relatada em 40% a 50% dos pacientes, é mais prevalente no terceiro e quarto dedo dos pés. A dactilite é frequentemente associada a uma doença grave caracterizada por poliartrite, erosão óssea e nova formação óssea<sup>27</sup> .  
Diversos critérios de classificação da AP foram elaborados nas últimas décadas<sup>6</sup> . Todavia, a _Classification Criteria for Psoriatic Arthritis_ (CASPAR) apresenta maior acurácia diagnóstica (sensibilidade de 98,2% a 99,7% e especificidade de 99,1%) e facilidade de utilização na prática clínica<sup>31,32</sup> . Aplicando estes critérios, o paciente será considerado com AP quando apresentar doença inflamatória articular (periférica, axial ou entesítica) adicionado de três ou mais pontos das categorias apresentadas no **Quadro 1** .  
**Quadro 1 – Critérios de classificação da artrite psoriásica (CASPAR).**  
|**_Classification Criteria for Psoriatic Arthritis_(CASPAR)**||
|---|---|
|**Categoria**|**Pontuação**|
|Psoríase atual (avaliada por reumatologista ou dermatologista)|2|
|História pessoal de psoríase|1|
|História familiar de psoríase (familiar de primeiro ou segundo grau)|1|
|Distrofia ungueal Psoriásica típica (observada no exame físico atual)|1|
|Fator reumatoide negativo|1|
|História de dactilite ou dactilite atual (registrado por reumatologista)|1|
|Formação óssea justa-articular à radiografia simples de mãos ou pés|1|  
Fonte: Adaptado de Taylor W. et al., 2006<sup>31</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Após o diagnóstico, procede-se à avaliação da atividade da doença segundo o componente predominante. De acordo com as recomendações internacionais, este Protocolo preconiza o uso das seguintes ferramentas: _Disease Activity in PSoriatic Arthritis_ (DAPSA) para a avaliação da artrite periférica; _Ankylosing Spondylitis Disease Activity Score_ (ASDAS) para a avaliação da artrite axial; e _Leeds Enthesitis Index_ (LEI) para a avaliação de entesites. Para o componente de pele, recomenda-se o uso da ferramenta _Psoriasis Area Severity Index_ (PASI), conforme o Protocolo Clínico e Diretrizes Terapêuticas da Psoríase, do Ministério da Saúde. O alvo terapêutico a ser atingido deve ser avaliado pelo _Minimal Disease Activity_ (MDA)<sup>33–37</sup> . ( **Apêndice 1** ).

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Serão incluídos neste Protocolo pacientes com diagnóstico de artrite psoriásica estabelecido por meio da utilização dos critérios CASPAR<sup>31</sup> ( **Quadro 1** ).

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento neste Protocolo deverão ser excluídos ao uso do respectivo medicamento preconizado.  
**6 TRATAMENTO**  
O tratamento da AP objetiva a redução dos sintomas, a remissão ou o controle da atividade da doença (para mínima ou baixa atividade), oferecendo melhor qualidade de vida e evitando perda da capacidade funcional dos pacientes<sup>38,39</sup> .  
Embora existam diversas terapias não medicamentosas disponíveis, quatro delas são abordadas neste Protocolo. As terapias anti-sintomáticas incluem medicamentos anti-inflamatórios não esteroides, glicocorticoides sistêmicos e injeções locais de glicocorticoide. O tratamento medicamentoso inclui produtos sintéticos, biológicos inibidores de fator de necrose tumoral (anti-TNF) e inibidores de interleucina-17 (anti-IL17) e inibidor da _Janus Kinases_ (JAK)<sup>38,39</sup> . **(Quadro 2)**  
**Quadro 2 - Terapias medicamentosa e não medicamentosas da artrite psoriásica.**  
||Abandono do tabagismo, controle do consumo de álcool, prática de exercícios|
|---|---|
|**Tratamento não medicamentoso**|físicos supervisionada e perda de peso.<br>Acompanhamento multidisciplinar.|
|**Tratamentos sintomáticos**|Anti-inflamatórios não esteroides (AINE); glicocorticoides; injeções de<br>glicocorticoides locais.|
|**Imunossupressores**|Ciclosporina.|
|**MMCDs**|Metotrexato, sulfassalazina, leflunomida.|
|**MMCDbio**||
|Inibidores do fator de necrose tumoral<br>(anti-TNF)|Adalimumabe, etanercepte, golimumabe, infliximabe e certolizumabe pegol.|
|**MMCDbio**<br>Inibidor da IL-17|Secuquinumabe, ixequizumabe|
|**MMCDsae**<br>Inibidor da_Janus Kinases_(JAK)|Tofacitinibe.|  
Legenda: MMCDs: medicamentos modificadores do curso da doença sintéticos; MMCDbio: medicamentos modificadores do curso da doença biológicos;  
MMCDsae: medicamentos modificadores do curso da doença alvo específico.  
Para fins de decisão terapêutica, os fatores de pior prognóstico são<sup>38</sup> :  
- Muitas (cinco ou mais) articulações edemaciadas.  
- Dano estrutural.  
- Velocidade de hemossedimentação (VHS) ou dosagem da proteína C reativa (PCR) elevadas.  
- Manifestações extra-articulares clinicamente relevantes (por exemplo, dactilite e acometimento ungueal).  
- Para fins de avaliação da resposta terapêutica, considera-se neste Protocolo:  
- **Resposta suficiente:**  
- Em três meses do tratamento: A melhora deve exceder 50% conforme o índice de resposta;  
- Em seis meses do tratamento: atingir a meta terapêutica.  
- **Resposta insuficiente** : Há melhora, mas ela não atinge a meta terapêutica.  
- **Falha terapêutica ou sem resposta** : Ausência (falha primária) ou perda (falha secundária) de resposta definida por  
- índice próprio para a doença.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
O paciente deve, preferencialmente, ser acompanhado por equipe multidisciplinar (educador físico, enfermeiro, farmacêutico, fisioterapeuta, terapeuta ocupacional, psicólogo e nutricionista), com suporte de médico reumatologista, se disponível, em qualquer das etapas discriminadas a seguir, independentemente da fase da doença. O paciente deve receber orientações para melhorar seus hábitos de vida. Tratar e monitorar as comorbidades (hipertensão arterial sistêmica, diabete melito, dislipidemia e osteoporose) são medidas essenciais. A cobertura vacinal deve ser atualizada. Por fim, o uso de meios contraceptivos deve ser orientado nos casos de pacientes em fase reprodutiva e candidatos ao uso de medicamento modificador do curso da doença (MMCD).  
Devido ao risco aumentado de doenças cardiovasculares, obesidade, síndromes metabólicas, hipertensão arterial sistêmica, diabete melito, hiperdislipidemia e distúrbios pulmonares<sup>8,10,11</sup> , é indicada a adoção de medidas não medicamentosas para o controle desses fatores, entre elas: abandono do tabagismo, controle do consumo de álcool, prática de exercícios físicos supervisionada e perda de peso<sup>39–41</sup> .  
A educação do paciente, a promoção do autocuidado e a realização de atividade física supervisionada, visando à proteção articular, são apontados por alguns estudos<sup>41,42</sup> como os tratamentos não medicamentosos indicados nos casos das artrites inflamatórias.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
O tratamento medicamentoso de AP inclui o uso de anti-inflamatórios não esteroidais (AINE), glicocorticoides, medicamentos modificadores do curso da doença (MMCD) – sintéticos, biológicos e alvo específico - e imunossupressores ( **Quadro 2** ). O uso seguro desses medicamentos exige o conhecimento de suas contraindicações.  
São preconizados por este Protocolo os seguintes medicamentos: metotrexato, sulfassalazina e leflunomida (MMCD sintéticos), adalimumabe, certolizumabe pegol, etanercepte, golimumabe, infliximabe, secuquinumabe e ixequizumabe (MMCD biológicos - MMCDbio) e tofacitinibe (MCDsae)<sup>21,43–47</sup> . Os MMCDbio podem ser divididos em primeira linha de tratamento (adalimumabe, etanercepte, golimumabe e infliximabe) e MMCDbio de segunda linha (certolizumabe pegol, secuquinumabe e ixequizumabe).  
O ustequinumabe foi avaliado e não recomendado pela Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), conforme o Relatório de Recomendação nº 337, de janeiro de 2018<sup>48</sup> , portanto não é preconizado neste Protocolo.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Em qualquer das etapas e linhas discriminadas para o tratamento dos pacientes com AP, anti-inflamatórios não esteroidais (AINE) ou glicocorticoides podem ser prescritos para o controle sintomático, considerando sempre o uso da menor dose pelo menor tempo possível.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Ibuprofeno e naproxeno são os AINE preconizados neste Protocolo no tratamento da AP com manifestações articulares com o intuito de promover o alívio de sinais e sintomas musculoesqueléticos. Esses medicamentos estão associados a sintomas do trato gastrointestinal, incluindo náusea, gastrite e dispepsia, podendo-se também observar hemorragia digestiva com seu uso prolongado. Seu uso deve ser reservado para o alívio sintomático enquanto são aguardados os efeitos dos MMCD. Esses dois AINE possuem perfis de eficácia e segurança semelhantes, e o naproxeno apresenta meia vida mais longa, permitindo uma posologia mais conveniente<sup>38,39,49–51</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Injeções intra-articulares de corticoide podem ser utilizadas como terapia adjuvante nas manifestações localizadas da AP. Os glicocorticoides sistêmicos, em baixas doses e por curto período de tempo (até três meses), podem ser uma opção de tratamento; entretanto, precauções com relação à possibilidade de eventos adversos devem ser consideradas antes da sua indicação<sup>5,38,50–52</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Os imunossupressores, como a ciclosporina, são historicamente usados no tratamento da AP. A ciclosporina é efetiva na modificação do curso natural da doença, mas está associada a significante incidência de eventos adversos, em especial devidos à imunossupressão<sup>5</sup> .  
O tratamento da AP deve considerar a manifestação musculoesquelética predominante:

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
O metotrexato (MTX) deve ser a primeira escolha terapêutica<sup>38</sup> . Em casos de intolerância ao MTX oral, deve-se tentar dividir a administração por via oral em duas doses com intervalos de até 12 horas ou em três doses dentro de um período de 24 horas ou empregar o MTX injetável. Na impossibilidade de uso do MTX por toxicidade (intolerância, hipersensibilidade ou outro evento adverso), recomenda-se utilizar outro MMCDs, a leflunomida (LEF) ou a sulfassalazina (SSZ)<sup>38,49</sup> . O tratamento com MMCDs não impede o uso concomitante de AINE, todavia o risco de hepatotoxicidade deve ser avaliado<sup>5</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Em caso de falha da monoterapia inicial (MTX, LEF ou SSZ), isto é, de persistência da atividade de doença após três meses de tratamento otimizado (dose máxima tolerada e adesão adequada) do medicamento usado na primeira linha, recomendase a terapia com a combinação dupla ou tripla de MMCDs. As associações de medicamentos (MMCDs) mais comumente recomendadas são a associação do MTX ou LEF com a SSZ.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
**Medicamentos Modificadores do Curso da Doença Biológicos (MMCDbio):** Adalimumabe, etanercepte, golimumabe  
e infliximabe.  
Após o uso de pelo menos dois esquemas terapêuticos na primeira etapa por, no mínimo, três meses cada um (seis meses no total) e havendo persistência da atividade da doença, utiliza-se um MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe).  
O MMCDbio de primeira linha pode ser usado em associação com o MTX ou em monoterapia. Nos casos de contraindicação ao MTX e quando houver indicação do medicamento, pode ser considerada a associação do MMCbio com outro MMCDs (LEF ou SSZ). O adalimumabe tem indicação de associação com a LEF, além do MTX<sup>53</sup> .  
Esses medicamentos apresentam perfis de eficácia e segurança semelhantes, não havendo, em geral, predileção por uma alternativa frente às demais. Nos pacientes em tratamento com MMCDbio e com resposta suficiente, o uso do mesmo fármaco deve ser mantido, não sendo recomendada sua troca por outro MMCDbio.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
**Medicamentos Modificadores do Curso da Doença Biológicos (MMCDbio):** Adalimumabe, etanercepte, golimumabe, infliximabe, certolizumabe pegol, secuquinumabe e ixequizumabe.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Após pelo menos três meses de tratamento da segunda etapa terapêutica, e havendo persistência da atividade da doença, falha terapêutica ou toxicidade inaceitável ao medicamento utilizado na segunda etapa, recomenda-se a substituição por outro MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe e infliximabe, conforme uso anteriormente)<sup>5,38</sup> ou por um dos MMCDbio de segunda linha (certolizumabe pegol, secuquinumabe e ixequizumabe)<sup>21,43,44,47</sup> ou pelo tofacitinibe<sup>46</sup> . Sempre que possível, o medicamento selecionado deve ser associado a um MMCDs. O MMCDs de escolha é o MTX. Nos casos de contraindicação ao MTX e quando houver indicação do medicamento, pode ser considerada a associação com outro MMCDs (LEF ou SSZ). O adalimumabe tem indicação de associação com a LEF, além do MTX<sup>53</sup> e o tofacitinibe tem indicação de associação com outros MMCDs, além do MTX<sup>54</sup> .  
Nos casos de pacientes com AP periférica (artrite ou dactilite), só devem ser indicados o MMCDbio de segunda linha (certolizumabe pegol, secuquinumabe ou ixequizumabe) ou o tofacitinibe, para o tratamento de pacientes com AP após falha terapêutica com o uso, na etapa anterior, de pelo menos um MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe) e  dos dois MMCDs da primeira etapa de tratamento; ou seja, o uso do MMCDbio de segunda linha (certolizumabe pegol, secuquinumabe, ixequizumabe) ou tofacitinibe é indicado somente se a pessoa já passou pela primeira etapa de tratamento (dois MMCDs) e usou pelo menos um MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe), mas sua doença continua ativa após as primeiras 12 semanas de tratamento, ou se houve perda de resposta ao tratamento com MMCDbio primeira linha nesse período (três meses de tratamento)<sup>21,43,44,46</sup> . O tofacitinibe é utilizado por via oral e não necessita de refrigeração para armazenamento<sup>54</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
Nos casos de paciente com AP axial ou entesite, o tratamento é iniciado com AINE e, se necessário, após o seu uso por pelo menos 4 semanas, o tratamento com MMCDbio de primeira linha é preconizado<sup>22,38,55</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
e infliximabe.  
Um MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe) deve ser usado inicialmente. Esses medicamentos apresentam perfis de eficácia e segurança semelhantes, não havendo, em geral, predileção por uma alternativa frente às demais. Nos pacientes já em tratamento com MMCDbio e com resposta suficiente, o uso do mesmo fármaco deve ser mantido, não sendo recomendada sua troca por outro MMCDbio.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
**Medicamentos Modificadores do Curso da Doença Biológicos (MMCDbio):** Adalimumabe, etanercepte, golimumabe, infliximabe, certolizumabe pegol, secuquinumabe e ixequizumabe.  
**Medicamento Modificador do Curso da Doença Sintético Alvo Específico (MMCDsae):** Tofacitinibe.  
Após pelo menos três meses de tratamento da primeira etapa terapêutica, e havendo persistência da atividade da doença, falha terapêutica ou toxicidade inaceitável ao medicamento utilizado na primeira etapa, recomenda-se a substituição por outro  
MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe)<sup>5,38</sup> ou por um dos MMCDbio de segunda linha (secuquinumabe, certolizumabe pegol, ixequizumabe)<sup>43,44,47</sup> ou pelo tofacitinibe<sup>46</sup> .  
Nos casos de pacientes com AP axial ou entesite, um dos MMCDbio de segunda linha (certolizumabe pegol, secuquinumabe, ixequizumabe) ou o tofacitinibe só deve ser indicado após falha terapêutica com uso, na primeira etapa, de pelo menos um MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe); ou seja, o uso do certolizumabe pegol, secuquinumabe, ixequizumabe ou tofacitinibe é preconizado somente se o paciente utilizou pelo menos um MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe), mas sua doença continua ativa após as primeiras 12 semanas de tratamento, ou se houve perda de resposta ao tratamento nesse período (mínimo de três meses de tratamento)<sup>21,43,44,46</sup> . Ressalta-se que ainda há poucas evidências do benefício do tofacitinibe para os pacientes com AP axial<sup>56–59</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
a) Tratamento sintomático.  
b) Preconiza-se o uso de um MMCDs, sendo o MTX a primeira escolha. Nos casos de persistência de atividade de doença, deve ser considerada a associação do MTX a um segundo MMCDs (LEF ou SSZ)<sup>38</sup> .  
c) Em caso de persistência de atividade de doença, após o uso de dois esquemas com MMCDs, isolados ou em combinação, e considerando o período total de seis meses (6 meses) de tratamento, pode ser considerado o uso de MMCDbio de primeira linha associado ou não ao MTX.  
d) Nos casos de toxicidade (hipersensibilidade, intolerância ou outro evento adverso) ou falha terapêutica após o tratamento com dose suficiente por três meses com MMCDbio de primeira linha (adalimumabe, etanercepte, golimumabe ou infliximabe), este pode ser substituído por outro do mesmo grupo (MMCDbio de primeira linha) ou por certolizumabe pegol, secuquinumabe, ixequizumabe ou tofacitinibe.  
e) Para pacientes com AP periférica grave e pior prognóstico, que não atingiram a meta de tratamento com o uso de um MMCDs, pode ser considerado o uso do MMCDbio de primeira linha, não sendo necessária a utilização de um segundo MMCDs. Nesses casos o período mínimo de uso de MMCDs deve ser de pelo menos três meses<sup>38</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: Geral -->
- a) Tratamento sintomático.  
b) Devem ser implementadas medidas não farmacológicas e iniciado o uso de um dos AINE preconizados neste Protocolo.  
c) Em caso de persistência, após uso de AINE em dose tolerável, este deve ser substituído por outro AINE.  
d) Em caso de persistência da atividade da doença, após o uso de AINE por pelo menos quatro (4) semanas, e o paciente apresentar ASDAS > 2,1, BASDAI igual ou maior que 4 (≥ 4), deve ser iniciado o tratamento com MMCDbio de primeira linha (adalimumabe, etanercepte, infliximabe ou golimumabe).  
e) Nos casos de toxicidade (hipersensibilidade, intolerância ou outro evento adverso) ou falha terapêutica com dose adequada de um MMCDbio de primeira linha, pode ser considerada a substituição por outro MMCDbio deste mesmo grupo ou por certolizumabe pegol, secuquinumabe, ixequizumabe ou tofacitinibe (segunda etapa de tratamento).  
f) Para pacientes com AP Axial, ainda há poucas evidências do benefício do tofacitinibe<sup>56-59</sup> .  
- O fluxograma do tratamento dos pacientes com artrite psoriásica é apresentado na **Figura 1** .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
- Adalimumabe: solução injetável de 40 mg;  
- Certolizumabe Pegol: solução injetável de 200 mg/mL;  
- Ciclosporina: cápsulas de 10 mg, 25 mg, 50 mg e 100 mg; solução oral 100 mg/mL;  
- Etanercepte: solução injetável de 25 mg e 50 mg.  
- Golimumabe: solução injetável de 50 mg.  
- Ibuprofeno: comprimidos revestidos de 200 mg, 300 mg e 600 mg; suspensão oral de 50 mg/mL.  
- Infliximabe: pó para solução injetável de 100 mg/10 mL;  
- Ixequizumabe: solução injetável de 80 mg;  
- Leflunomida: comprimidos de 20 mg;  
- Metilprednisolona: frasco de 40 mg/2 mL;  
- Metotrexato: comprimidos de 2,5 mg; solução injetável (frasco com 2 mL);  
- Naproxeno: comprimidos de 250 mg e 500 mg;  
- Prednisona: comprimidos de 5 mg e 20 mg;  
- Secuquinumabe: solução injetável com 150 mg/mL;  
- Sulfassalazina: comprimidos de 500 mg;  
- Tofacitinibe: comprimidos de 5 mg.  
Nota: O medicamento metilprednisolona está contemplado em procedimentos de infiltração, sendo seu fornecimento de  
responsabilidade do serviço, não sendo dispensados no âmbito da Assistência Farmacêutica.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
- Adalimumabe: 40 mg, por via subcutânea, a cada duas semanas.  
- Certolizumabe pegol: 400 mg (duas injeções de 200 mg cada), por via subcutânea, nas semanas 0, 2 e 4; posteriormente,  
200 mg a cada duas semanas ou 400 mg a cada quatro semanas. Aprovado apenas para pacientes adultos.  
- Ciclosporina: 3 a 5 mg/kg/dia, por via oral, divididos em duas administrações (12/12 horas).  
- Etanercepte: 50 mg, por via subcutânea, a cada semana.  
- Golimumabe: 50 mg, por via subcutânea, a cada 4 semanas. Aprovado apenas para pacientes adultos.  
- Ibuprofeno: 600 a 3.200 mg/dia, por via oral, divididos em três administrações (8/8 horas).  
- Infliximabe: 5 mg/kg, por via intravenosa, nas semanas 0, 2 e 6, e, posteriormente, a cada 8 semanas.  
- Ixequizumabe: 160 mg por injeção subcutânea (duas injeções de 80 mg) na semana 0, seguida de 80 mg a cada 4  
semanas. Aprovado apenas para pacientes adultos.  
- Leflunomida: 20 mg, por via oral, uma vez por dia.  
- Metilprednisolona: 4 a 80 mg a cada 3 a 4 meses, por via intra- ou periarticular, a depender do tamanho da articulação:  
Grande: 20 a 80 mg; média: 10 a 40 mg; pequena: 4 a 10 mg.  
- Metotrexato: 7,5 a 25 mg, por via oral, subcutânea ou intramuscular, a cada semana.  
- Naproxeno: 500 a 1.500 mg/dia, por via oral, divididos em três administrações (8/8 horas).  
- Prednisona: 5 a 20 mg/dia, por via oral, divididos em até três administrações (8/8 horas).  
- Secuquinumabe: Para a indicação incorporada ao SUS<sup>44</sup> (pacientes com artrite psoriásica com resposta inadequada a  
anti‐TNFα), a dose é de 300 mg, nas semanas 0, 1, 2, 3 e 4; posteriormente, uma vez a cada quatro semanas. Cada dose de 300 mg é administrada em duas injeções subcutâneas de 150 mg. Aprovado apenas para pacientes adultos.  
- Sulfassalazina: 500 a 3.000 mg/dia, por via oral, divididos em até três administrações (8/8 horas).  
- Tofacitinibe: 5 mg, por via oral, administrada duas vezes ao dia. Aprovado apenas para pacientes adultos.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
- Adalimumabe, certolizumabe pegol, etanercepte, infliximabe e golimumabe: hipersensibilidade a algum dos medicamentos ou de seus componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica com risco de vida; infecção por herpes zóster ativa; hepatite B ou C aguda; doença linfoproliferativa nos últimos cinco anos; insuficiência cardíaca congestiva classe III ou IV; doença neurológica desmielinizante.  
- Ciclosporina: hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; hipertensão arterial sistêmica grave não controlada.  
- Ixequizumabe: hipersensibilidade conhecida ao medicamento, classe terapêutica ou componente do produto; tuberculose sem tratamento.  
- Leflunomida (LF): hipersensibilidade conhecida ao medicamento, classe farmacêutica ou componente do produto; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; gestação, amamentação e concepção (homens e mulheres); elevação de aminotransferases/transaminases igual ou três vezes acima do limite superior da normalidade; taxa de depuração de creatinina inferior a 30 mL/min/1,73 m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica.  
- Metotrexato (MTX): hipersensibilidade conhecida ao medicamento, classe farmacêutica ou componente do produto; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas; gestação, amamentação e concepção (homens e mulheres); elevação de aminotransferases/transaminases igual ou três vezes acima do limite superior da normalidade; taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica.  
- Naproxeno e ibuprofeno: hipersensibilidade conhecida ao medicamento, classe farmacêutica ou componente do produto; sangramento gastrointestinal não controlado, úlcera gastroduodenal, elevação de aminotransferases/transaminases (AST/TGO e ALT/TGP) igual ou três vezes acima do limite superior da normalidade (LSN) ou taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica.  
- Prednisona e metilprednisolona: hipersensibilidade conhecida ao medicamento, classe farmacêutica ou componente do produto; tuberculose sem tratamento.  
- Secuquinumabe: hipersensibilidade ao princípio ativo ou componente do produto; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatite B ou C aguda.  
- Sulfassalazina (SSZ): hipersensibilidade conhecida ao medicamento, classe farmacêutica ou componente do produto; porfiria; tuberculose sem tratamento; hepatites B ou C aguda; forma sistêmica de artrite idiopática juvenil; elevação de aminotransferases/transaminases igual ou três vezes acima do limite superior da normalidade.  
- Tofacitinibe: hipersensibilidade conhecida ao medicamento, classe terapêutica ou componente do produto; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas. É recomendada avaliação dos pacientes quanto a fatores de risco de tromboembolismo venoso antes do início do tratamento e periodicamente durante o tratamento. O tofacinibe deve ser usado com cautela em pacientes nos quais os fatores de risco são identificados.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
O uso dos medicamentos preconizados neste Protocolo deve ser considerado individualmente, com uma rigorosa avaliação do risco-benefício em gestantes, lactantes, crianças e adolescentes.  
Os MMCDs metotrexato e leflunomida são contraindicados na gravidez e lactação. O MMCDs sulfassalazina; o imunossupressor ciclosporina; os glicocorticoides, prednisona e prednisolona; os AINEs naproxeno e ibuprofeno; os MMCDbio anti-TNF (adalimumabe, certolizumabe pegol, etanercepte, golimumabe e infliximabe); o MMCDbio inibidor de citocinas antiIL-17 (secuquinumabe e ixequizumabe); e o tofacitinibe não devem ser usados durante a gravidez e a lactação, exceto sob estritas orientação e acompanhamento médicos.  
Mulheres em idade fértil em uso de medicamentos modificadores do curso da doença devem adotar métodos contraceptivos seguros para evitar a gestação, uma vez que a maioria dos medicamentos dessa categoria é contraindicado durante a gravidez e a amamentação<sup>55,60,61</sup> .  
Mulheres que desejam engravidar devem discutir as opções de tratamento da AP com o seu médico assistente, para que o esquema terapêutico seja capaz de estabilizar a doença e oferecer à mulher o menor risco de complicações durante a gravidez. Idealmente, o quadro da paciente deve ser estabilizado antes de se iniciarem as tentativas de concepção<sup>55,60</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
O tempo de tratamento não pode ser pré-determinado e o tratamento dos MMCDs, MMCDbio ou MMCDsae deverá ser mantido enquanto houver benefício terapêutico. Na teoria, o tratamento medicamentoso deverá ser mantido até que a remissão da doença seja alcançada. Entretanto, dados da literatura apontam que entre 45% e 77% dos pacientes que suspenderam totalmente o tratamento com MMCD após remissão apresentaram recidiva da doença em até 12 meses. Já aqueles pacientes que tiveram a dose reduzida após a remissão da doença mantiveram o estado remissivo por pelo menos um ano e o controle da atividade da doença por até dois anos<sup>62</sup> .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
Espera-se que o tratamento adequado proporcione melhora dos sintomas, da capacidade funcional e da qualidade de vida dos pacientes.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
**Figura 1. Algoritmo de tratamento da Artrite Psoriásica.**  
<!-- Start of picture text -->
Paciente com diagnéstico de Artrite Psoridsica<br>| Tratamento de acordo com a manifestac3o |<br>AP Periférica | i<br>(Atte, Dactiite) | AP Axial e Enteste<br>oats AINE: (Ibuprofeno,<br>a ‘naproxeno)<br>Falna do 2 Manter z ASDAS > 2,1 ou be Manter<br>| sm<br>Trocar por outro MMCDs sim<br>(eflunomida,<br>sulfassalazina) ou<br>utilizar dois MMCDs* MMCDbio primeira linha<br>(adalimumabe, etanercepte,<br>I golimumabe, infiximabe)<br>Faina do Manter<br>tratamento?! tratamento” i<br>J Nao<br>ra y sima tratamento?Faina do ‘ratamento’Manter 7<br>{adaimumabe*, etanercepte,<br>‘golimumabe, infiximabe) sim<br>‘associado ou nao a metotrexato<br>| . ‘Substituir por outro<br>Fama do Nao Manter ‘MMCDbio primeiraoa  linha<br>‘ratamento?* ‘ratamento” ‘MMCDbio segunda ina<br>(Secuquinumabe,<br>sim certolizumabe pegol, ixequizumabe)<br>ou<br>‘Substituir por outro MMCDsae (tofacitinibe)®<br>MMCDbio primeira linha<br>ou<br>MMCDbio segunda linha<br>(secuquinumabe, certolizumabe pegol,<br>‘ixequizumabe)<br>ou<br>MMCDsae (tofacitinibe®)<br>{associado ou ndo a metotrexato)<br>Em qualquer das etapas e linhas disciminadas, antFinflamatonos no esteroidais (AINE) ou glicocorlicoides podem<br>ser prescritos para o controle sintomatico. AINE em monoterapia deve ser utilzado, no maximo, por trés meses.<br>1 A suspensdo do tratamento pode ocorrer por eventos adversos intolerdveis ou por falha do tratamento (nfo atingimento de<br>meta terapéutica). Deve-se aguardar pelo menos 3 meses de tratamento vigente, nao devendo haver troca de linha ou etapa<br>terapSutica em intervalo de tempo inferior.<br>Em pacientes com AP periérica grave e pior prognéstico que no atingiram a meta de tratamento com 0 uso de um MMCDs, 0<br>usosos,doo MMCDbioperiodo minimo deprimeira  usolinha depode MMCDsser podeconsiderado, ser trés meses.ndo sendo necesséria a utlizaco de um segundo MMCDs. Nesses<br>3 Considerar a substituico do uso de metotrexato injetdvel ou outras combinacées de terapias duplas ou triplas. Considerar<br>metotrexato injetdvel,leflunomida, terapia dupla ou tripla, sem metotrexato oral<br>Tem indicago de associac3o com a leflunomida, além do metotrexato.<br>5 Tem indicago de associac3o com outros MMCDs, além do metotrexato<br>° Ainda hd poucas evidéncias do beneficio do tofacitinibe em pacientes com manifestaco axial,<br>7 Manter 0 tratamento e reavaliar periodicamente, monitorando resposta, eventos adversos e critérios de interrupcao do<br>tratamento.<br><!-- End of picture text -->  
**7 MONITORAMENTO**  
Os instrumentos utilizados para a avaliação da atividade da doença e a resposta terapêutica como o _Disease Activity Score_ em 28 articulações (DAS28), a resposta EULAR e o _American College of Rheumatology_ (ACR) _Response Criteria_ são, na sua maioria, adaptações de instrumentos utilizados para casos de artrite reumatoide e, portanto, consideram apenas o acometimento articular. Já o _Minimal Disease Activity_ (MDA) é um instrumento específico para a AP, o qual considera o acometimento articular, o acometimento cutâneo, entesite, dactilite, dor, avaliação global do paciente, inclusive a sua capacidade funcional, e qualidade de vida<sup>37,63–65</sup> . ( **Apêndice 1** )  
Um paciente atinge a MDA ao atender a cinco dos sete critérios a seguir<sup>37</sup> :  
- contagem articular sensível <ou = 1;  
- contagem de articulações inchada <ou = 1;  
- Índice de Atividade e Gravidade da Psoríase <ou = 1 ou área de superfície corporal < ou = 3;  
- escore visual analógico (EVA) da dor do paciente <ou = 15;  
- atividade global da doença do paciente EVA <ou = 20;  
- questionário de avaliação de saúde <ou = 0,5;  
- pontos entésicos sensíveis <ou = 1.  
Neste Protocolo, o alvo terapêutico a ser atingido deve ser avaliado pelo MDA, e preconiza-se a monitorização da resposta terapêutica por meio da avaliação clínica, utilizando as ferramentas específicas como índice de resposta para cada componente predominante, conforme descrito para a avaliação da atividade da doença, assim como dos potenciais eventos adversos e risco cardiovascular. As avaliações clínicas devem ser realizadas a cada três meses ou menos, em caso de doença ativa, e a cada seis meses, em caso de doença estável e sem indicação de mudança na terapêutica instituída.  
Exames laboratoriais devem incluir a determinação da VHS e da PCR, antes e durante o tratamento (nos períodos de maior atividade, a cada 1-3 meses). Hemograma, contagem de plaquetas e dosagens séricas de creatinina, AST/TGO e ALT/TGP devem ser realizados no início do tratamento e representam o painel laboratorial de monitorização trimestral dos principais eventos adversos ocasionados pelo tratamento medicamentoso. Assim, em caso de alteração nos resultados dos exames laboratoriais ou insuficiência renal, elevação dos níveis pressóricos ou sintomas e sinais de infecção, durante a monitorização do paciente, o prescritor pode reduzir as doses ou espaçar o período entre as doses do medicamento ou até interrompê-lo.  
A avaliação articular com radiografia simples ou ressonância magnética deve ser realizada no início do tratamento e, se necessário, durante o acompanhamento com o objetivo de detectar possíveis danos estruturais, como erosão articular periférica ou sinais de sacroiliíte ativa, que podem indicar a necessidade de mudança do tratamento.  
Vacinas vivas devem ser aplicadas antes do início do tratamento com imunossupressor e medicamento modificadores da doença<sup>66</sup> .  
Alguns medicamentos recomendados para o tratamento da artrite psoriásica (MMCD) podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) previamente ao início do tratamento.  
Antes do início do uso de MMCDb ou MMCDsae e com objetivo de realizar o planejamento terapêutico adequado, devese considerar as seguintes condutas:  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
- Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A radiografia  
simples de tórax deve ser realizada para excluir a possibilidade de TB ativa, independente de sinais e sintomas.  
- Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD) ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
- Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
- Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de MMCDb ou MMCDsae após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, à critério da equipe de saúde assistente, o início de uso de MMCDb ou MMCDsae pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
- Nos casos de troca do MMCDb ou MMCDsae, não é necessário repetir as condutas preconizadas para início de tratamento.  
Durante o acompanhamento da pessoa em uso de MMCDb ou MMCDsae, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
- Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
- Para que o uso dos MMCDb e MMCDsae não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com MMCDb ou MMCDsae devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com MMCDb ou MMCDsae devem manter o monitoramento com o IGRA.  
- Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
- Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
- Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.  
Com relação aos efeitos adversos relacionados aos MMCD, destacam-se reações de hipersensibilidade, elevação dos níveis das enzimas hepáticas, descompensação de insuficiência cardíaca e infecções graves, infestações, cefaleia e reações hematológicas<sup>68,69</sup> e doença neurológica desmielinizante (leucoencefalopatia multifocal progressiva - LEMP).

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Pacientes com AP devem ser atendidos, preferencialmente, em serviços especializados em que conte com reumatologista ou médico com experiência e familiaridade com manifestações clínicas próprias desta doença, para seu adequado diagnóstico, inclusão no tratamento e acompanhamento.  
Pacientes com AP devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A prescrição de biológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
**9 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER**  
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
1. Bacelar S. _Expressoes medicas: glossario de dificuldades em terminologia medica_ . Conselho Federal de Medicina (CFM); 2018.  
2. Arend CF. Linguagem médica voltada para o reumatologista: armadilhas e erros comuns. _Rev Bras Reumatol_ . 2014;54(1):79–82.  
3. de Rezende JM. PSORÍASE. PSORÍACO, PSÓRICO, PSORIÁTICO, PSORIÁSICO. _Rev Patol Trop Trop Pathol_ . 2014;43(1):105–108.  
4. Raychaudhuri SP, Wilken R, Sukhov AC, Raychaudhuri SK, Maverakis E. Management of psoriatic arthritis: early diagnosis, monitoring of disease severity and cutting edge therapies. _J Autoimmun_ . 2017;76:21–37.  
5. Carneiro S, Azevedo VF, Ranza R, et al. Recomendações sobre diagnóstico e tratamento da artrite psoriásica. _Rev Bras Reumatol_ . 2013;53(3):227–241.  
6. McAllister K, Goodson N, Warburton L, Rogers G. Spondyloarthritis: diagnosis and management: summary of NICE guidance. _Bmj_ . 2017;356.  
7. Ruiz DG, Azevedo MNL de, Santos OL da R. Artrite psoriásica: entidade clínica distinta da psoríase? _Rev bras Reum_ . Published online 2012:630–638.  
8. Terenzi R, Monti S, Tesei G, Carli L. One year in review 2017: spondyloarthritis. _Clin Exp Rheumatol_ . 2018;36(1):1– 14.  
9. Hile G, Kahlenberg JM, Gudjonsson JE. Recent genetic advances in innate immunity of psoriatic arthritis. _Clin Immunol_ . 2020;214:108405.  
10. D’Angiolella LS, Cortesi PA, Lafranconi A, et al. Cost and Cost Effectiveness of Treatments for Psoriatic Arthritis: A Systematic  Literature Review. _Pharmacoeconomics_ . 2018;36(5):567–589. doi:10.1007/s40273-018-0618-5  
11. Ogdie A, Schwartzman S, Eder L, et al. Comprehensive treatment of psoriatic arthritis: managing comorbidities and extraarticular manifestations. _J Rheumatol_ . 2014;41(11):2315–2322.  
12. Catanoso M, Pipitone N, Salvarani C. Epidemiology of psoriatic arthritis. _Reumatismo_ . Published online 2012:66–70.  
13. Ogdie A, Langan S, Love T, et al. Prevalence and treatment patterns of psoriatic arthritis in the UK. _Rheumatology_ . 2013;52(3):568–575.  
14. Li R, Sun J, Ren L-M, et al. Epidemiology of eight common rheumatic diseases in China: a large-scale cross-sectional survey in Beijing. _Rheumatology_ . 2012;51(4):721–729.  
15. Yang Q, Qu L, Tian H, et al. Prevalence and characteristics of psoriatic arthritis in Chinese patients with psoriasis. _J Eur Acad Dermatology Venereol_ . 2011;25(12):1409–1414.  
16. Carneiro JN, Paula AP de, Martins GA. Psoriatic arthritis in patients with psoriasis: evaluation of clinical and epidemiological features in 133 patients followed at the University Hospital of Brasília. _An Bras Dermatol_ . 2012;87(4):539–544.  
17. Reich K, Krüger K, Mössner R, Augustin M. Epidemiology and clinical pattern of psoriatic arthritis in Germany: a prospective interdisciplinary epidemiological study of 1511 patients with plaque‐type psoriasis. _Br J Dermatol_ .  
2009;160(5):1040–1047.  
18. Sampaio-Barros PD. Epidemiology of spondyloarthritis in Brazil. _Am J Med Sci_ . 2011;341(4):287–288.  
19. Ranza R, Carneiro S, Qureshi AA, et al. Prevalence of psoriatic arthritis in a large cohort of Brazilian patients with psoriasis. _J Rheumatol_ . 2015;42(5):829–834.  
20. Liu J-T, Yeh H-M, Liu S-Y, Chen K-T. Psoriatic arthritis: epidemiology, diagnosis, and treatment. _World J Orthop_ . 2014;5(4):537.  
21. National Institute of Health and Care Excellence (NICE). _Final Appraisal Determination: Certolizumab pegol and secukinumab for treating active psoriatic arthritis after inadequate response to DMARDs._ ; 2017.  
https://www.nice.org.uk/guidance/ta445/chapter/1-Recommendations  
22. Elmamoun M, Eraso M, Anderson M, et al. International league of associations for rheumatology recommendations for the management of psoriatic arthritis in resource-poor settings. _Clin Rheumatol_ . Published online 2020:1–12.  
23. Marsal S, Armadans-Gil L, Martinez M, Gallardo D, Ribera A, Lience E. Clinical, radiographic and HLA associations as markers for different patterns of psoriatic arthritis. _Rheumatology (Oxford)_ . 1999;38(4):332–337.  
24. Pedersen OB, Svendsen AJ, Ejstrup L, Skytthe A, Junker P. On the heritability of psoriatic arthritis. Disease concordance among monozygotic and dizygotic twins. _Ann Rheum Dis_ . 2008;67(10):1417–1421.  
25. Wang Q, Vasey FB, Mahfood JP, et al. V2 regions of 16S ribosomal RNA used as a molecular marker for the species identification of streptococci in peripheral blood and synovial fluid from patients with psoriatic arthritis. _Arthritis Rheum Off J Am Coll Rheumatol_ . 1999;42(10):2055–2059.  
26. Cantini F, Niccoli L, Nannini C, Kaloudi O, Bertoni M, Cassara E. Psoriatic arthritis: a systematic review. _Int J Rheum Dis_ . 2010;13(4):300–317.  
27. Ritchlin CT, Colbert RA, Gladman DD. Psoriatic arthritis. _N Engl J Med_ . 2017;376(10):957–970.  
28.  
- Feld J, Chandran V, Gladman DD. What is axial psoriatic arthritis? Published online 2018.  
29. Chandran V, Barrett J, Schentag CT, Farewell VT, Gladman DD. Axial psoriatic arthritis: update on a longterm prospective study. _J Rheumatol_ . 2009;36(12):2744–2750.  
30. Jadon DR, Sengupta R, Nightingale A, et al. Axial Disease in Psoriatic Arthritis study: defining the clinical and radiographic phenotype of psoriatic spondyloarthritis. _Ann Rheum Dis_ . 2017;76(4):701–707.  
31. Taylor W, Gladman D, Helliwell P, Marchesoni A, Mease P, Mielants H. Classification criteria for psoriatic arthritis: development of new criteria from a large international study. _Arthritis Rheum Off J Am Coll Rheumatol_ . 2006;54(8):2665–2673.  
32. Tillett W, Costa L, Jadon D, et al. The ClASsification for Psoriatic ARthritis (CASPAR) criteria–a retrospective feasibility, sensitivity, and specificity study. _J Rheumatol_ . 2012;39(1):154–156.  
33. Smolen JS, Schoels M, Aletaha D. Disease activity and response assessment in psoriatic arthritis using the Disease Activity index for PSoriatic Arthritis (DAPSA). A brief review. _Clin Exp Rheumatol_ . 2015;33(5 Suppl 93):S48-50.  
34. Healy PJ, Helliwell PS. Measuring clinical enthesitis in psoriatic arthritis: assessment of existing measures and development of an instrument specific to psoriatic arthritis. _Arthritis Care Res Off J Am Coll Rheumatol_ . 2008;59(5):686–691.  
35. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. _Protocolo Clínico e Diretrizes Terapêuticas Psoríase_ .; 2019. http://conitec.gov.br/index.php/protocolos-e-diretrizes#P  
36. Mease PJ. Measures of psoriatic arthritis: Tender and Swollen Joint Assessment, Psoriasis Area and Severity Index (PASI), Nail Psoriasis Severity Index (NAPSI), Modified Nail Psoriasis Severity Index (mNAPSI), Mander/Newcastle Enthesitis Index (MEI), Leeds Enthesit. _Arthritis Care Res (Hoboken)_ . 2011;63(S11):S64–S85.  
37. Coates LC, Helliwell PS. Validation of minimal disease activity criteria for psoriatic arthritis using interventional trial  
data. _Arthritis Care Res (Hoboken)_ . 2010;62(7):965–969.  
38. Gossec L, Baraliakos X, Kerschbaumer A, et al. EULAR recommendations for the management of psoriatic arthritis with pharmacological therapies: 2019 update. _Ann Rheum Dis_ . 2020;79(6):700–712.  
39. Singh JA, Guyatt G, Ogdie A, et al. 2018 American College of Rheumatology/National Psoriasis Foundation guideline for the treatment of psoriatic arthritis. _Arthritis Rheumatol_ . 2019;71(1):5–32.  
40. Hoving JL, Lacaille D, Urquhart DM, Hannu TJ, Sluiter JK, Frings‐Dresen MHW. Non‐pharmacological interventions for preventing job loss in workers with inflammatory arthritis. _Cochrane Database Syst Rev_ . 2014;(11).  
41. Daien CI, Charlotte HUA, Combe B, Landewe R. Non-pharmacological and pharmacological interventions in patients with early arthritis: a systematic literature review informing the 2016 update of EULAR recommendations for the management of early arthritis. _RMD open_ . 2017;3(1):e000404.  
42. Vlak T. Spondyloarthritides: principles of rehabilitation. _Reumatizam_ . 2010;57(2):31–38.  
43. Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. _Certolizumabe pegol para o tratamento de artrite psoríaca em pacientes adultos com resposta inadequada amedicamentos modificadores do curso da doença. Relatório n. 446 novembro 2019_ .; 2019. http://conitec.gov.br/images/Relatorios/2019/  
44. Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. _Secuquinumabe para o tratamento de artrite psoríaca em pacientes adultos com resposta inadequada a medicamentos modificadores do curso da doença sintéticos ou biológicos da classe anti-TNF. Relatório n. 336 janeiro 2019_ .; 2019. http://conitec.gov.br/images/Relatorios/2019/Relatorio  
45. Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. _Portaria n_<sup>_o_</sup> _1. 2019 de 21 de janeiro de 2019_ .; 2019. http://conitec.gov.br/images/Relatorios/2019/Relatorio_Secuquinumabe_Artrite_Psoriasica.pdf  
46. Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. _Citrato de tofacitinibe para o tratamento de pacientes adultos com artrite Psoríaca ativa moderada a grave intolerantes ou com falha terapêutica aos medicamentos modificadores do curso da doença sintéticos ou biológicos. Relatorio n° 537 julho 2020_ .; 2020. http://conitec.gov.br/images/Consultas/Relatorios/2020/Relatorios  
47. Brasil. Ministério da Saúde.Secretaria de Ciência T e I e do CE-I da S-S. Relatório de Recomendação Ixequizumabe no tratamento de pacientes adultos com artrite psoriásica ativa com falha ou intolerantes ao tratamento a um medicamento modificador do curso da doença biológico em primeira linha. Relatório de Recomendação n<sup>o</sup> 951. Published online 2024.  
48. Brasil. Ministério da Saúde S de C Tecno1. Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. Ustequinumabe para o tratamento de pacientes adultos com artrite psoriásica ativa que apresentaram resposta inadequada aos medicamentos modifi. _Ustequinumabe para o tratamento de pacientes adultos com artrite psoriásica ativa que apresentaram resposta inadequada aos medicamentos modificadores do curso da doença. Relatório n°337 de 2018_ .; 2018. http://conitec.gov.br/  
49. Dhaon P, Das SK, Srivastava R, Agarwal G, Asthana A. Oral Methotrexate in split dose weekly versus oral or parenteral Methotrexate once weekly in Rheumatoid Arthritis: a short‐term study. _Int J Rheum Dis_ . 2018;21(5):1010–1017.  
50. Coates LC, Kavanaugh A, Mease PJ, et al. Group for research and assessment of psoriasis and psoriatic arthritis 2015 treatment recommendations for psoriatic arthritis. _Arthritis Rheumatol_ . 2016;68(5):1060–1071.  
51. Nissen SE. Cardiovascular Safety of Celecoxib, Naproxen, or Ibuprofen for Arthritis. _N Engl J Med_ . 2017;376(14):1390.  
52. Paccou J, Wendling D. Current treatment of psoriatic arthritis: update based on a systematic literature review to establish French Society for Rheumatology (SFR) recommendations for managing spondyloarthritis. _Jt Bone Spine_ . 2015;82(2):80–85.  
53. Agência Nacional de Vigilância Sanitária – ANVISA. _Adalimumabe – Bula do fabricante_ . http://www.anvisa.gov.br/  
54. Agência Nacional de Vigilância Sanitária – ANVISA. _Tofacitinibe - Bula fabricante_ .  
55. MOTA LMH da et al. 2017 recommendations of the Brazilian Society of Rheumatology for the pharmacological treatment of rheumatoid arthritis. _Adv Rheumatol_ . 2019;58(2). doi:http://dx.doi.org/10.1186/s42358-018-0005-0  
56. Hammitzsch A; Lorenz G; Moog P. Impact of Janus Kinase Inhibition on the Treatment of Axial Spondyloarthropathies. _Immunol_ . Published online 2020. doi:https://doi.org/10.3389/fimmu.2020.591176  
57. Masmitja JG; Gonzalez CMF; Gomez CS et al. Efficacy of Tofacitinib in the Treatment of Psoriatic Arthritis: A Systematic Review. _Adv Ther_ . Published online 2020. doi:https://doi.org/10.1007/s12325-020-01585-7  
58. Gladman D; Rigby W; Azeved F. Tofacitinib for Psoriatic Arthritis in Patients with an Inadequate Response to TNF Inhibitors. _Engl J Med_ . 2017;377:1525–1536. doi:10.1056/NEJMoa1615977  
59. Mease P, Hall S, FitzGerald O, et al. Tofacitinib or Adalimumab versus Placebo for Psoriatic Arthritis. _N Engl J Med_ . 2017;377(16):1537–1550. doi:10.1056/nejmoa1615975  
60. Partlett R, Roussou E. The treatment of rheumatoid arthritis during pregnancy. _Rheumatol Int_ . 2011;31(4):445–449.  
61. Mota LMH da, Cruz BA, Brenol CV, et al. Consenso 2012 da Sociedade Brasileira de Reumatologia para o tratamento da artrite reumatoide. _Rev Bras Reumatol_ . 2012;52(2):152–174.  
62. Van den Bosch F, Coates L. Clinical management of psoriatic arthritis. _Lancet_ . 2018;391(10136):2285–2294.  
63. HELLIWELL PSOF and PJM. Development of Composite Measures for Psoriatic Arthritis: A Report from the GRAPPA 2010 Annual Meeting. _J Rheumatol_ . 2012;39(2):398–403. doi:https://doi.org/10.3899/jrheum.111233  
64. Gladman DD, Ritchlin C., MD M. Treatment of psoriatic arthritis. https://www.uptodate.com/contents/treatment-ofpsoriatic-arthritis  
65. HELLIWELL AC and PS. Remission in Psoriatic Arthritis. _J Rheumatol_ . 2012;Supplement(89):19–21.  
66. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. _MANUAL DE RECOMENDAÇÕES PARA O CONTROLE DA TUBERCULOSE NO BRASIL_ .; 2020. http://bvsms.saude.gov.br/bvs/publicacoes/manual_recomendacoes_controle_tuberculose_brasil_2_ed.pdf  
67. Menter, Alan  et al. Guidelines of care for the management of psoriasis and psoriatic arthritis: Section 1. Overview of psoriasis and guidelines of care for the treatment of psoriasis with biologics. _J Am Acad Dermatol_ . 2008;58(5):826–850.  
68. Martins Gomes C, Vicente Cesetti M, Sevilha‐Santos L, et al. The risk of leprosy in patients using immunobiologics and conventional immunosuppressants for the treatment of dermatological and rheumatological diseases: a cohort study. _J Eur Acad Dermatology Venereol_ . 2021;35(1).  
69. Barroso DH, Brandão JG, Andrade ESN, et al. Leprosy detection rate in patients under immunosuppression for the treatment of dermatological, rheumatological, and gastroenterological diseases: a systematic review of the literature and meta-analysis. _BMC Infect Dis_ . 2021;21:1–9.  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**  
IBUPROFENO, NAPROXENO, PREDNISONA, CICLOSPORINA, SULFASSALAZINA, METOTREXATO, LEFLUNOMIDA, ADALIMUMABE, ETANERCEPTE, INFLIXIMABE, GOLIMUMABE, SECUQUINUMABE, CERTOLIZUMABE PEGOL, TOFACITINIBE e IXEQUIZUMABE  
Eu,______________________________________________________________________________________ (nome  
do [a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **ibuprofeno, naproxeno, prednisona, sulfassalazina, metotrexato, leflunomida, ciclosporina, adalimumabe, etanercepte, infliximabe, golimumabe,  secuquinumabe, certolizumabe pegol, tofacitinibe e ixequizumabe** indicados para o tratamento da **Artrite Psoriásica** .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ______________________  
_______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas da doença, como dor e rigidez;  
- melhora da qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- os riscos na gestação e na amamentação já são conhecidos; portanto, caso engravide, devo avisar imediatamente o médico  
- prednisona, sulfassalazina, adalimumabe, etanercepte, infliximabe, golimumabe, secuquinumabe e certolizumabe pegol: medicamentos classificados na gestação como fator de risco B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- ibuprofeno, naproxeno tofacitinibe: medicamento classificado na gestação como categoria C quando utilizado no primeiro e segundo trimestres de gestação (estudos em animais mostraram anormalidades nos descendentes, mas não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- ibuprofeno e naproxeno: medicamento classificado na gestação como categoria D quando utilizado no terceiro trimestre de gestação ou próximo ao parto (há evidências de risco ao feto, mas um benefício potencial pode ser maior do que os riscos);  
- ciclosporina: medicamento classificado na gestação como fator de risco C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- metotrexato e leflunomida: medicamentos classificados na gestação como fator de risco X (seu uso é contraindicado para gestantes ou para mulheres planejando engravidar);  
- eventos adversos do ibuprofeno: tontura, urticária na pele, reações de alergia, dor de estômago, náusea, má digestão, prisão de ventre, perda de apetite, vômitos, diarreia, gases, dor de cabeça, irritabilidade, zumbido, inchaço e retenção de líquidos;  
- eventos adversos do naproxeno: dor abdominal, sede, constipação, diarreia, dispneia, náusea, estomatite, azia, sonolência, vertigens, enxaqueca, tontura, erupções cutâneas, prurido, sudorese, distúrbios auditivos e visuais, palpitações, edemas, dispepsia e púrpura;  
- eventos adversos da sulfassalazina: dores de cabeça, reações alérgicas (dores nas juntas, febre, coceira, erupção cutânea), sensibilidade aumentada aos raios solares, dores abdominais, náusea, vômitos, perda de apetite, diarreia; eventos adversos mais raros: diminuição do número de glóbulos brancos no sangue, parada na produção de sangue pela medula óssea (anemia aplásica), anemia por destruição aumentada dos glóbulos vermelhos no sangue (anemia hemolítica), diminuição do número de plaquetas  
no sangue (aumenta os riscos de sangramento), piora dos sintomas de retocolite ulcerativa, problemas no fígado, falta de ar associada a tosse e febre (pneumonite intersticial), dor nas juntas, dificuldade para engolir, cansaço associado à formação de bolhas e perda de regiões da pele e de mucosas (síndrome de  Stevens-Johnson e necrólise epidérmica tóxica) e desenvolvimento de sintomas semelhantes aos do lúpus eritematoso sistêmico (ou seja, bolhas na pele, dor no peito, mal- estar, erupções cutâneas, falta de ar e coceira);  
- eventos adversos da prednisona: alterações nos ossos e músculos: fraqueza, perda de massa muscular, osteoporose, além de ruptura do tendão, lesões de ossos longos e vértebras e piora dos sintomas de miastenia gravis; alterações hidroeletrolíticas: inchaço, aumento da pressão arterial; alterações no estômago e intestino: sangramento; alterações na pele: demora em cicatrizar machucados, suor em excesso, petéquias e equimoses, urticária e até dermatite alérgica; alterações no sistema nervoso: convulsões, tontura; dor de cabeça; alterações nas glândulas: irregularidades menstruais, manifestação de diabetes mellitus; alterações nos olhos: catarata, aumento da pressão dentro dos olhos; alterações psiquiátricas: alterações do humor; depressão e dificuldade para dormir;  
- eventos adversos do metotrexato: problemas gastrointestinais com ou sem sangramento, diminuição do número de glóbulos brancos no sangue, diminuição do número de plaquetas, aumento da sensibilidade da pele aos raios ultravioleta, feridas na boca, inflamação nas gengivas, inflamação na garganta, espinhas, perda de apetite, náusea, palidez, coceira e vômitos; efeitos adversos mais raros, dependendo da dose utilizada: cansaço associado à formação de bolhas e perda de regiões da pele e de mucosas (síndrome de Stevens-Johnson e necrólise epidérmica tóxica) e problemas graves de pele; também pode facilitar o estabelecimento de infecções ou agravá-las;  
- eventos adversos da leflunomida: pressão alta, dor no peito, palpitações, aumento do número de batimentos do coração, vasculite, varizes, edema, infecções respiratórias, sangramento nasal, diarreia, hepatite, náusea, vômitos, perda de apetite, gastrite, gastroenterite, dor abdominal, azia, gazes, ulcerações na boca, pedra na vesícula, prisão de ventre, desconforto abdominal, sangramento nas fezes, de cabelo, alergias de pele, coceira, pele seca, espinhas, hematomas, alterações das unhas, alterações da cor da pele, úlceras de pele, hipopotassemia, diabete mélito, hiperlipidemia, hipertireoidismo, desordens menstruais, dores pelo corpo, alteração da visão, anemia, infecções e alteração da voz;  
- eventos adversos da ciclosporina: disfunção renal, tremores, aumento da quantidade de pelos no corpo, pressão alta, hipertrofia gengival, aumento dos níveis de colesterol e triglicerídios, formigamentos, dor no peito, infarto do miocárdio, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, gastrite, úlcera péptica, soluços, inflamação na boca, dificuldade para engolir, hemorragias, inflamação do pâncreas, prisão de ventre, desconforto abdominal, síndrome hemolíticourêmica, diminuição das células brancas do sangue, linfoma, calorões, hiperpotassemia, hipomagnesemia, hiperuricemia, toxicidade para os músculos, disfunção respiratória, sensibilidade aumentada a temperatura e reações alérgicas, toxicidade renal e hepática e ginecomastia;  
- eventos adversos de adalimumabe, etanercepte, infliximabe, golimumabe, secuquinumabe certolizumabe pegol: reações no local da aplicação, como dor e coceiras, dor de cabeça, tosse, náusea, vômitos, febre, cansaço, alteração na pressão arterial; reações mais graves: infecções oportunísticas fúngicas e bacterianas, podendo, em casos raros, ser fatal;  
- contraindicação de adalimumabe, etanercepte, infliximabe, golimumabe e certolizumabe pegol em casos de hipersensibilidade (alergia) ao(s) fármaco(s) ou aos componentes da fórmula, tuberculose sem tratamento, infecção bacteriana com indicação de uso de antibiótico, infecção fúngica com risco de vida, infecção por herpes zóster ativa, hepatite B ou C aguda, doença linfoproliferativa nos últimos cinco anos, insuficiência cardíaca congestiva classe III ou IV, doença neurológica desmielinizante.  
- contraindicação do secuquinumabe: hipersensibilidade ao princípio ativo ou qualquer um dos componentes, tuberculose sem tratamento, infecção bacteriana com indicação de uso de antibiótico, infecção fúngica com risco de vida, infecção por herpes zóster ativa, hepatite B ou C aguda.  
- contraindicação do tofacitinibe: Hipersensibilidade conhecida ao medicamento, classe ou componentes; tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes zóster ativa; hepatites B ou C agudas. É recomendada avaliação dos pacientes quanto a fatores de risco para tromboembolismo venoso antes do início do tratamento e periodicamente durante o tratamento. O tofacinibe deve ser usado com cautela em pacientes nos quais os fatores de risco são identificados  
- contraindicação do ixequizumabe: pacientes com hipersensibilidade grave conhecida ao ixequizumabe ou a qualquer um dos excipientes. Principais eventos adversos: medicamentos classificados na gestação como fator de risco B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela); infecções (está associado a um aumento da taxa de infecções, como infecção do trato respiratório superior, candidíase oral, conjuntivite e infecções por tínea); turbeculose (não deve ser administrado a pacientes com tuberculose ativa (TB). Deve ser avaliar os pacientes quanto a infecção por tuberculose e iniciar o tratamento da TB latente antes da administração de ixequizumabe); Doença inflamatória intestinal (recomenda-se precaução em pacientes com doença inflamatória intestinal, incluindo doença de Crohn e colite ulcerativa, e os pacientes devem ser cuidadosamente monitorados)• Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) Adalimumabe (    ) Leflunomida (    ) Certolizumabe pegol (    ) Metotrexato  
- (    ) Ciclosporina (    ) Naproxeno  
- (    ) Etanercepte (    ) Prednisona  
- (    ) Golimumabe  
- (    ) Ibuprofeno  
- (    ) Infliximabe  
- (    ) Secuquinumabe  
- (    ) Sulfassalazina  
- (    ) Tofacitinibe  
- (    ) Ixequizumabe  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|  
___________________________ Assinatura e carimbo do médico Data:____________________  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Nota 2: A administração intra-articular de metilprednisolona é compatível com o procedimento 03.03.09.003-0 - Infiltração de substâncias em cavidade sinovial, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
Ankylosing Spondylitis Disease Activity Score– ASDAS  
Fórmulas para cálculo do escore ASDAS por proteína C reativa (PCR) e por velocidade de hemossedimentação (VHS) em calculadora específica:  
|ASDAS – PCR|0.12 x Dor axial + 0.06 x Duração da rigidez matinal + 0.11 x Avaliação Global do Paciente + 0.07 x<br>ricos + 0.58 x Ln (PCR+1)|
|---|---|
|ASDAS - VHS|0.08 x Dor axial + 0.07 x Duração da rigidez matinal + 0.11 x Avaliação Global do Paciente + 0.09 x<br>ricos + 0.29 x √(VHS)|  
√(VHS), raiz quadrada da velocidade de hemossedimentação (mm/h); Ln (PCR+1), logaritmo natural da proteína C reativa mg/L) +1.  
Dor axial, avaliação global do paciente, duração da rigidez matinal e dor/edema periféricos são avaliados em escala analógica (de 0 a 10 cm) ou em uma escala numérica (de 0 a 10).  
Dor axial (questão 2 do BASDAI): "Como você descreveria o grau total de dor no pescoço, nas costas e no quadril relacionada à sua doença?"  
Duração da rigidez matinal (questão 6 do BASDAI): “Quanto tempo dura a rigidez matinal a partir do momento em que você acorda?"  
Avaliação do paciente: "Quão ativa esteve a sua espondilite em média na última semana*?”  
Dor/edema periférico (questão 3 do BASDAI): "Como você descreveria o grau total de dor e edema (inchaço) nas  
outras articulações sem contar com pescoço, costas, região lombar e quadril?"  
|Doença inativa|< 1,3|
|---|---|
|Atividade de doença moderada|1,4 -2,0|
|Atividade de doença alta|2,1 – 3,5|
|Atividade de doença muito alta|>3,5|  
**Fonte** : Machado P., Landewé R., Lie E, Kvien TK, Braun J, Baker D, et al. Ankylosing Spondylitis Disease Activity Score (ASDAS): defining cutoff values for disease activity states and improvement scores. Ann Rheum Dis. 2011;70(1):47–53.  
*Tradução literal para o português validada pela Sociedade Brasileira de Reumatologia.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
<!-- Start of picture text -->
Articulacées dolorosas Articulagdes edemaciadas<br>fe.&0O &£%COO<br>8 0 bY 0<br>ree 0 0<br>o0 @1e fe ere IQ<br>YOR OO o0) O<br>9 0 Us ? LAK ) e' O<br>a<br>te @ the @<br>ROO HY Oo oH<br>SSO e| On Cy<br>45Pe sire seas<br>1, Contagem de articulagdes dolorosas (0- 68):(T)_) 2. Contagem de articulagdesedemaciadas (0- 6¢<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
**4. Percepção do paciente com relação à atividade da doença e a dor:**  
- 4.a. Como você descreveria a atividade da sua doença na última semana?  
**0** – 1 – 2 – 3 – 4 – 5 – 6 – 7 – 8 – 9 – **10**  
**Sem atividade Muito ativa**  
- 4.b. Como você descreveria o grau total de dor na última semana?  
**0** – 1 – 2 – 3 – 4 – 5 – 6 – 7 – 8 – 9 – **10**

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
**Cálculo: DAPSA = TJ + SJ + PCR + Atividade + Dor**  
|**Níveis de atividade da doença**|**Pontos de corte**|
|---|---|
|Remissão|0 a 4|
|Baixa|5 a 14|
|Moderada|15 a 28|
|Alta|>28|  
Fonte: Smolen JS, Schoels M, Aletaha D. Disease activity and response assessment in psoriatic arthritis using the Disease Activity index for PSoriatic Arthritis (DAPSA). A brief review. Clin Exp Rheumatol. 2015;33(Suppl. 93):S45–50.  
**_Leeds Enthesitis Index (LEI)_**  
<!-- Start of picture text -->
a<br>pveral | en |<br>wy @)<br>|<br>| ']<br><!-- End of picture text -->  
- **1** . Epicôndilo lateral esquerdo e direito.  
- **2** . Côndilo femoral medial, esquerdo e direito.  
**3.** Inserção do tendão de Aquiles, esquerdo e direito.  
Fonte: Mease P. Tender and Swollen Joint Assessment, Psoriasis Area and Severity Index (PASI). Arthritis Care & Research.  
2011;63(S11):S64–85.  
- *Tradução literal para o português validada pela Sociedade Brasileira de Reumatologia.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
Os pacientes são considerados com atividade mínima da doença quando satisfazem 5 dos seguintes 7  
critérios. Ou seja, ao atender pelo menos 5 dos 7 critérios a seguir, o paciente é classificado como atingindo o alvo terapêutico (MDA):  
|**Critério**|**Ponto de corte**|
|---|---|
|contagem articular sensível|≤ 1|
|contagem de articulações inchada|≤ 1|
|índice de Atividade e Gravidade da Psoríase|≤ 1|
|área de superfície corporal|≤ 3|
|escore visual analógico (EVA) da dor do paciente|≤ 15|
|atividade global da doença do paciente EVA|≤ 20|
|questionário de avaliação de saúde|≤ 0,5|
|pontos enteses sensível|≤ 1|  
Fonte: LC Coates, P Helliwell. Validation of minimal disease activity criteria for psoriatic arthritis using  
interventional trial data. Arthritis Care Res (Hoboken). 2010;62(7):965–9.  
*Tradução literal para o português validada pela Sociedade Brasileira de Reumatologia.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
ATUALIZAÇÃO DO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DA ARTRITE PSORIÁSICA APÓS A INCORPORAÇÃO DO IXEQUIZUMABE - VERSÃO 2025

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
O presente apêndice consiste no documento de trabalho do Grupo Elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Artrite Psoriásica contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
Este PCDT destina-se aos gestores e profissionais da saúde envolvidos na atenção ao paciente com artrite psoriásica, que atuam nos diferentes níveis de atenção à saúde, ambulatorial e hospitalar, do Sistema Único de Saúde (SUS). Sua população-alvo são os pacientes com artrite psoriásica.  
A demanda para a atualização do PCDT da Artrite Psoriásica foi devido à incorporação do ixequizumabe ao SUS, conforme Portaria SCTIE/MS nº 1, de 15 de janeiro de 2025.  
Conforme o Relatório de Recomendação nº 951/2025, o Comitê de Medicamentos, na 135ª Reunião Ordinária da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), realizada no dia 08 de novembro de 2024, recomendou a incorporação do ixequizumabe para tratamento de pacientes adultos com artrite psoriásica ativa com falha ou intolerantes ao tratamento a um medicamento modificador do curso da doença biológico em primeira linha, conforme Protocolo Clínico do Ministério da Saúde. O Comitê considerou que ixequizumabe demonstrou eficácia semelhante, com custo de tratamento inferior a algumas alternativas disponíveis no SUS, dentre eles o secuquinumabe, comparador que apresenta a mesma classe terapêutica.  
Considerando a versão do PCDT da Artrite Psoríaca, publicado por meio da Portaria Conjunta SAES/SCITE/MS nº 09 de 21 de maio de 2021, esta atualização rápida focou na inclusão de ixequizumabe para tratamento de pacientes adultos com artrite psoríaca ativa com falha ou intolerantes ao tratamento a um medicamento modificador do curso da doença biológico em primeira linha no âmbito do SUS. Também foi considerado a alteração do título do PCDT para artrite psoriásica, por ser o nome mais utilizado para descrever a doença.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS) com a revisão externa de especialista da área.  
- **3       Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas**  
A proposta de atualização do PCDT da Artrite Psoriásica foi apresentada na 124ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 15 de abril de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES); Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Vigilância em Saúde e Ambiente (SVSA), Secretaria de Saúde Indígena (SESAI). <mark>O PCDT foi aprovado para avaliação da Conitec e a proposta será apresentada aos membros do Comitê de PCDT da C</mark> onitec em sua 140ª Reunião Ordinária.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
A Consulta Pública nº 36/2025, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Psoriásica, ficou disponível no período de 30 de maio de 2025 a 18 de junho de 2025. Foram recebidas 12 contribuições que podem ser verificadas em: https <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2025/contribuicao-da-cp-36_2025-pcdt-da-artrite-psoriasica</u>

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
A presente atualização teve foco específico no tratamento, visando à inclusão do ixequizumabe conforme a deliberação da Conitec. A pergunta de pesquisa avaliada no momento da incorporação do ixequizumabe, sob acrônimo PICO ( **Figura A** ), pode ser observada no **Quadro A** .  
**Figura A - Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO**  
<!-- Start of picture text -->
eIntervencdo, no caso de estudos experimentais<br>*Fatorde exposicao, em caso de estudos<br>observacionais<br>Teste indice, nos casos de estudos de acuracia<br>diagnéstica<br>«Controle,exposic¢ao dedo acordofator/examescom tratamento/niveisdisponiveis no SUSde<br>*Desfechos: sempre que possivel, definidos a<br>priori, deacordocom sua importancia<br><!-- End of picture text -->  
**Quadro A - Pergunta estruturada para elaboração do relatório de recomendação da tecnologia (PICO).**  
|População|Pacientes adultos com artrite psoriásica, com falha ou intolerantes ao tratamento a um MMCD<br>biológico em primeira linha|
|---|---|
|Intervenção|Ixequizumbe|
|(tecnologia)||
|Comparação|Adalimumabe, etanercepte, golimumabe, infliximabe, secuquinumabe, certolizumabe pegol e<br>tofacitinibe|
|Desfechos (Outcomes)|Medidas de PASI, ACR, DAS-28, segurança e qualidade de vida relacionada à saúde|
|Tipo de estudo|Medidas de PASI, ACR, DAS-28, segurança e qualidade de vida relacionada à saúde|  
Fonte: Relatório Recomendação nº 951 de 2025. Disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio- <u>de-recomendacao-no-951-ixequizumabe</u>

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
O Comitê de Medicamentos da Conitec, na 135ª Reunião Ordinária, realizada no dia 08 de novembro de 2024, deliberaram, por unanimidade, recomendar a incorporação de ixequizumabe para tratamento de pacientes adultos com artrite psoríaca ativa com falha ou intolerantes ao tratamento a um medicamento modificador do curso da doença biológico em primeira linha, conforme Protocolo Clínico do Ministério da Saúde. Considerou que ixequizumabe demonstrou eficácia semelhante, com custo de tratamento inferior a algumas alternativas disponíveis no SUS, dentre eles o secuquinumabe, comparador que apresenta a mesma classe terapêutica. Foi assinado o registro de deliberação nº 948/2024.  
Não foram realizadas buscas adicionais de evidências na literatura, uma vez que as buscas foram consideradas recentes, utilizando as sínteses de evidências disponíveis no Relatório de Recomendação nº 951, de janeiro de 2025.  
Atualização do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Psoríaca após a incorporação do tofacitinibe - Versão 2021

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
O objetivo da atualização do PCDT foi a disponibilização de novo medicamento para o tratamento no SUS, o tofacitinibe, o qual não constava no momento de elaboração da versão anterior do PCDT de AP (Portaria Conjunta Nº 16/SAES-SCTIE/MS, de 17 de novembro de 2020), conforme o Relatório de Recomendação nº 550 - PCDT – Artrite Psoríaca – agosto de 2020, da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), que passou a incluir também o certolizumabe pegol.  
A deliberação da Conitec, conforme o Relatório de Recomendação nº 537 de julho de 2020, aprovada pela Portaria Nº 28/SCTIE/MS, de 20 de agosto de 2020, foi de “recomendar a incorporação do citrato de tofacitinibe para o tratamento de pacientes adultos com artrite psoríaca ativa moderada a grave intolerantes ou com falha terapêutica aos medicamentos modificadores do curso da doença sintéticos ou biológicos. Considerou-se que as evidências apresentadas demonstram que o tofacitinibe possui eficácia semelhante aos medicamentos já disponíveis no SUS, além de ser um medicamento oral, o que poderia favorecer a adesão ao tratamento. Além disso a sua incorporação tem potencial de gerar economia de  
recursos em cenários que contemplam os demais medicamentos biológicos atualmente incorporados ao SUS para a mesma condição clínica”.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS) com a revisão externa de especialista da área.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
A proposta de atualização do PCDT de Artrite Psoríaca foi apresentada na 85ª Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em janeiro de 2021. A reunião teve a presença de representantes do Departamento de Gestão, Incorporação e Inovação de Tecnologias em Saúde (DGITIS/SCTIE/MS), do Departamento de Ciência e Tecnologia (DECIT/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS), do Departamento de Atenção e Temática (DAET/SAES/MS) e da Secretaria de Atenção Primária à Saúde (SAPS/MS).  
Após a reunião da Subcomissão, os ajustes necessários foram realizados e, em seguida, a proposta foi apresentada aos membros do Plenário da Conitec em sua 94ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **6.5     Medicamentos** -->
A Consulta Pública nº 05/2021, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Psoríaca, foi realizada entre os dias 18/02/2021 a 03/03/2021. Foram recebidas 176 contribuições, que podem ser verificadas em:  
http://conitec.gov.br/images/Consultas/Contribuicoes/2021/CP_CONITEC_05_2021_PCDT_Artrite.pdf

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
Diante da atualização do PCDT, em novembro/2020, a atual atualização teve foco específico no tratamento, visando à inclusão do tofacitinibe, conforme a deliberação da Plenária da Conitec. Considerando a versão vigente do PCDT de Artrite Psoríaca (Portaria Conjunta SAES-SCTIE/MS nº 16, de 17 de novembro de 2020), partiu-se deste documento de 2020, o qual manteve a estrutura de metodologia, acrescentando dados referentes à atualização da tecnologia recomendada, conforme o relatório da Conitec e diretrizes internacionais.  
Atualização do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Psoríaca após a incorporação do certolizumabe pegol - Versão 2020

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Atrite Psoríaca foi motivada pela inclusão do medicamento certolizumabe pegol, por meio da Portaria Nº 59/SCTIE/MS, de 18 de novembro de 2019. Pelo Relatório de Recomendação Nº 486, de novembro de 2019, a Conitec recomendou a incorporação do certolizumabe pegol para o tratamento de pacientes adultos com AP ativa, moderada a grave, que tiveram resposta inadequada prévia aos anti-inflamatórios não esteroides, medicamentos modificadores do curso da doença sintéticos, e aos medicamentos modificadores do curso da doença biológicos, anti-TNF, disponíveis no SUS.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS) com a revisão externa de especialista da área.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
O texto do PCDT foi avaliado pela Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas em 29 de maio de 2020. Estiveram presentes, além da equipe da CPCDT/DGITIS, membros das seguintes áreas: Departamento de Assistência Farmacêutica (DAF), Departamento de Ciência e Tecnologia (DECIT), Secretaria de Atenção Especializada (SAES) e Secretaria de Vigilância em Saúde (SVS). O texto foi aprovado pela subcomissão técnica para avaliação da Conitec.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
A Consulta Pública nº 22/2020 do PDCT da foi realizada entre os dias 16 de junho a 06 de julho de 2020. Foram recebidas novecentos e dezessete contribuições, que podem ser verificadas em: http://conitec.gov.br/images/Consultas/Relatorios/2020/Relatorio_PCDT_Artrite_Psoriaca_CP_22_2020. pdf .

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
Considerando a versão então vigente do PCDT de Artrite Psoríaca (Portaria Conjunta Nº 26/SAESSCTIE/MS, de 24 de outubro de 2018), partiu-se deste documento de 2018, o qual manteve a mesma estrutura de metodologia, acrescentando dados referentes a atualização da tecnologia recomendada, conforme relatório da Conitec e diretrizes internacionais.  
Para auxiliar a atualização dos dados epidemiológicos e esclarecimentos sobre alguns tópicos do PCDT, foram realizadas buscas manuais no período de atualização do texto desta versão do PCDT.  
Apresenta-se a busca na literatura realizada em 23/04/2018, referente à última atualização completa do documento, incluindo publicações entre 2010 e 2018, em inglês, português ou espanhol, referentes às tecnologias incluídas neste Protocolo.  
Identificação de diretrizes nacionais e internacionais nas seguintes bases:  
- _European League Against Rheumatism_ (EULAR);  
- _British Society for Rheumatology Guidelines;_  
- _National Institute for Health and Care Excellence_ (NICE);  
- Revista Brasileira de Reumatologia: uma diretriz.  
Atualização do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Psoríaca após a incorporação  
do Secuquinumabe - Versão 2018

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
Com o intuito de identificar as tecnologias disponíveis e aquelas demandadas ou recentemente incorporadas no Sistema Único de Saúde (SUS), foi consultado o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a Relação Nacional de Medicamentos Essenciais (RENAME-2017) e o Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP).  
Os medicamentos disponíveis no então Protocolo vigente eram: ibuprofeno, naproxeno, prednisona, ciclosporina, leflunomida, sulfassalazina, metilprednisolona, metotrexato, adalimumabe, etanercepte, infliximabe e golimumabe.  
O secuquinumabe, incorporado pela Portaria Nº 1, de 18 de janeiro de 2019 (Vigente) a qual revogou a Portaria nº 3, de 24 de janeiro de 2018, e o Relatório de Recomendação no 336 de janeiro de 2019, da Conitec, no qual esse medicamento ficou preconizado “para o tratamento de pacientes adultos com artrite psoríaca ativa, moderada a grave, que tiveram resposta inadequada prévia aos anti-inflamatórios não esteroides, medicamentos modificadores do curso da doença sintéticos, e aos medicamentos modificadores do curso da doença biológicos, anti-TNF, disponíveis no SUS”.  
**Identificação de Diretrizes nacionais e internacionais nas seguintes bases:**  
- _European League Against Rheumatism_ (EULAR)  
- Revista Brasileira de Reumatologia: uma diretriz.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
Busca na literatura realizada em 23/04/2018 ( **Quadro A** ), referente à última atualização completa  
do documento, incluindo publicações entre 2010 e 2018, em inglês, português ou espanhol, referentes às tecnologias incluídas neste Protocolo, por meio da seguinte pergunta de pesquisa estruturada seguindo o acrônimo PICO:  
- POPULAÇÃO: Pacientes com artrite Psoríaca.  
- INTERVENÇÃO: Medicamentos incluídos neste protocolo.  
- COMPARAÇÃO: Sem restrição de comparadores.  
- DESFECHOS: Eficácia e segurança.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
A partir dos estudos identificados, foi realizada a extração dos dados destes em uma planilha de Excel com informações sobre as caraterísticas dos estudos e os resultados segundo os desfechos: ACR20, ACR50, ACR70, níveis de PCR, HAQ-DI e eventos adversos. O risco de viés dos estudos foi avaliado pela ferramenta de risco de viés da Cochrane para ensaios clínicos randomizados e a seguir, os dados sumarizados por desfecho foram apresentados em tabelas do sistema GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ ), para avaliação da qualidade das evidências e determinar a força de cada recomendação. Por último, as recomendações foram apresentadas a especialistas com o intuito de avaliar a implementação das recomendações no contexto do Sistema Único de Saúde.  
**Quadro A – Estratégias de busca de literatura realizadas**  
|**Base de**<br>**dados**|**Tecnologia**|**Estratégia de busca**|
|---|---|---|
||AINE|((((arthritis, psoriatic[MeSH Terms]) AND placebos[MeSH Terms])) AND (((((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract] OR random allocation[MeSH Terms] OR therapeutic use[MeSH<br>Subheading]))) OR ((randomized controlled trial[Publication Type] OR (randomized[Title/Abstract] AND controlled[Title/Abstract] AND<br>trial[Title/Abstract]))))) AND Anti-Inflammatory Agents, Non-Steroidal[MeSH Terms]|
|Medline|Glicocorticoide<br>s|((((Glucocorticoids[MeSH Terms]) AND placebos[MeSH Terms])) AND arthritis, psoriatic[MeSH Terms]) AND (((((clinical[Title/Abstract] AND<br>trial[Title/Abstract]) OR clinical trials as topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract] OR random<br>allocation[MeSH Terms] OR therapeutic use[MeSH Subheading]))) OR ((randomized controlled trial[Publication Type] OR (randomized[Title/Abstract]<br>AND controlled[Title/Abstract] AND trial[Title/Abstract]))))|
|<br>via<br>Pubmed|MMCDs|((((((((Cyclosporine[MeSH Terms]) OR leflunomide[Supplementary Concept]) OR methotrexate[MeSH Terms]) OR sulfasalazin[MeSH Terms])) AND<br>placebos[MeSH Terms])) AND arthritis, psoriatic[MeSH Terms]) AND (((((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract] OR random allocation[MeSH Terms] OR therapeutic use[MeSH<br>Subheading]))) OR ((randomized controlled trial[Publication Type] OR (randomized[Title/Abstract] AND controlled[Title/Abstract] AND<br>trial[Title/Abstract]))))|
||MMCDbio|((((((((adalimumab[MeSH Terms]) OR etanercept[MeSH Terms]) OR infliximab[MeSH Terms]) OR golimumab[Supplementary Concept])) AND<br>placebos[MeSH Terms])) AND arthritis, psoriatic[MeSH Terms]) AND (((((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract] OR random allocation[MeSH Terms] OR therapeutic use[MeSH<br>Subheading]))) OR ((randomized controlled trial[Publication Type] OR (randomized[Title/Abstract] AND controlled[Title/Abstract] AND<br>trial[Title/Abstract]))))|
|||('psoriatic arthritis'/exp OR 'arthritis psoriatica' OR 'arthritis, psoriasis' OR 'arthritis, psoriatic' OR 'arthropathic psoriasis' OR 'arthropathy, psoriatic' OR|
|Embase|AINE|'polyarthritis, psoriatic' OR 'psoriasis arthropathica' OR 'psoriasis, arthritis' OR 'psoriatic arthritis' OR 'psoriatic arthropathy' OR 'psoriatic polyarthritis' OR<br>'psoriatic rheumatism' OR 'psoriatic rheumatoid arthritis' OR 'rheumatoid arthritis, psoriatic') AND ('nonsteroid antiinflammatory agent'/exp OR 'nsaid' OR|  
|**Base de**<br>**dados**|**Tecnologia**|**Estratégia de busca**|
|---|---|---|
|||'anti inflammatory agents, non steroidal' OR 'anti-inflammatory agents, non-steroidal' OR 'antiinflammatory agent, nonsteroid' OR 'non steroid<br>antiinflammatory agent' OR 'non steroid antiinflammatory drug' OR 'non steroidal anti inflammatory agent' OR 'non steroidal anti inflammatory drug' OR<br>'non steroidal antiinflammatory agent' OR 'non steroidal antiinflammatory drug' OR 'nonsteroid antiinflammatory agent' OR 'nonsteroid antiinflammatory<br>drug' OR 'nonsteroid antirheumatic agent' OR 'nonsteroidal anti inflammatory drug' OR 'nonsteroidal anti inflammatory drugs' OR 'nonsteroidal anti-<br>inflammatory drugs' OR 'nonsteroidal antiinflammatory agent' OR 'nonsteroidal antiinflammatory drug') AND ('placebo'/exp OR 'placebo') AND<br>('randomized controlled trial'/exp OR 'controlled trial, randomized' OR 'randomised controlled study' OR 'randomised controlled trial' OR 'randomized<br>controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled') AND [randomized controlled trial]/lim AND [article]/lim AND<br>([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [embase]/lim AND [2010-2018]/py|
||Glicocorticoide<br>s|('psoriatic arthritis'/exp OR 'arthritis psoriatica' OR 'arthritis, psoriasis' OR 'arthritis, psoriatic' OR 'arthropathic psoriasis' OR 'arthropathy, psoriatic' OR<br>'polyarthritis, psoriatic' OR 'psoriasis arthropathica' OR 'psoriasis, arthritis' OR 'psoriatic arthritis' OR 'psoriatic arthropathy' OR 'psoriatic polyarthritis' OR<br>'psoriatic rheumatism' OR 'psoriatic rheumatoid arthritis' OR 'rheumatoid arthritis, psoriatic') AND ('glucocorticoid'/exp OR 'prednisone'/exp) AND<br>('placebo'/exp OR 'placebo') AND ('randomized controlled trial'/exp OR 'controlled trial, randomized' OR 'randomised controlled study' OR 'randomised<br>controlled trial' OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled') AND [randomized controlled<br>trial]/lim AND [article]/lim AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [embase]/lim AND [2010-2018]/py|
||MMCDs|('psoriatic arthritis'/exp OR 'arthritis psoriatica' OR 'arthritis, psoriasis' OR 'arthritis, psoriatic' OR 'arthropathic psoriasis' OR 'arthropathy, psoriatic' OR<br>'polyarthritis, psoriatic' OR 'psoriasis arthropathica' OR 'psoriasis, arthritis' OR 'psoriatic arthritis' OR 'psoriatic arthropathy' OR 'psoriatic polyarthritis' OR<br>'psoriatic rheumatism' OR 'psoriatic rheumatoid arthritis' OR 'rheumatoid arthritis, psoriatic') AND ('cyclosporine'/exp OR 'adi 628' OR 'adi628' OR<br>'cicloral' OR 'ciclosporin' OR 'ciclosporin a' OR 'ciclosporine' OR 'cipol' OR 'cipol-n' OR 'consupren' OR 'cyclokat' OR 'cyclosporin' OR 'cyclosporin a' OR<br>'cyclosporin neoral' OR 'cyclosporine' OR 'cyclosporine a' OR 'deximune' OR 'equoral' OR 'gengraf' OR 'ikervis' OR 'iminoral' OR 'implanta' OR<br>'imusporin' OR 'neoral' OR 'neoral-sandimmun' OR 'nova 22007' OR 'nova22007' OR 'ol 27400' OR 'ol27400' OR 'pulminiq' OR 'restasis' OR 'sandimmun'<br>OR 'sandimmun neoral' OR 'sandimmune' OR 'sandimmune neoral' OR 'sandimun' OR 'sandimun neoral' OR 'sandimune' OR 'sang 35' OR 'sang35' OR<br>'sangcya' OR 'vekacia' OR 'leflunomide'/exp OR '5 methyl 4` trifluoromethyl 4 isoxazolecarboxanilide' OR '5 methyl n [4 (trifluoromethyl) phenyl] 4|  
|**Base de**<br>**dados**|**Tecnologia**|**Estratégia de busca**|
|---|---|---|
|||isoxazolecarboxamide' OR '5 methyl n [4 (trifluoromethyl) phenyl] isoxazole 4 carboxamide' OR '5 methyl n [para (trifluoromethyl) phenyl] 4<br>isoxazolecarboxamide' OR 'alpha, alpha, alpha trifluoro 5 methyl 4 isoxazolecarboxy para toluidide' OR 'arabloc' OR 'arava' OR 'hwa 486' OR 'hwa486' OR<br>'leflunomide' OR 'leflunomide winthrop' OR 'n (4 trifluoromethylphenyl) 5 methylisoxazole 4 carboxamide' OR 'repso' OR 'rs 34821' OR 'rs34821' OR 'su<br>101' OR 'su101' OR 'methotrexate'/exp OR sulfasalazine) AND ('placebo'/exp OR 'placebo') AND ('randomized controlled trial'/exp OR 'controlled trial,<br>randomized' OR 'randomised controlled study' OR 'randomised controlled trial' OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial,<br>randomized controlled') AND [randomized controlled trial]/lim AND [article]/lim AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND<br>[humans]/lim AND [embase]/lim AND [2010-2018]/py|
||MMCDbio|('psoriatic arthritis'/exp OR 'arthritis psoriatica' OR 'arthritis, psoriasis' OR 'arthritis, psoriatic' OR 'arthropathic psoriasis' OR 'arthropathy, psoriatic' OR<br>'polyarthritis, psoriatic' OR 'psoriasis arthropathica' OR 'psoriasis, arthritis' OR 'psoriatic arthritis' OR 'psoriatic arthropathy' OR 'psoriatic polyarthritis' OR<br>'psoriatic rheumatism' OR 'psoriatic rheumatoid arthritis' OR 'rheumatoid arthritis, psoriatic') AND ('adalimumab'/exp OR 'abp 501' OR 'abp501' OR<br>'adalimumab' OR 'adalimumab adbm' OR 'adalimumab atto' OR 'adalimumab-adbm' OR 'adalimumab-atto' OR 'amgevita' OR 'amjevita' OR 'cyltezo' OR<br>'humira' OR 'imraldi' OR 'monoclonal antibody d2e7' OR 'solymbic' OR 'trudexa' OR 'etanercept'/exp OR 'benepali' OR 'embrel' OR 'enbrel' OR 'erelzi' OR<br>'etanercept' OR 'etanercept szzs' OR 'etanercept-szzs' OR 'lifmior' OR 'recombinant tumor necrosis factor receptor fc fusion protein' OR 'recombinant<br>tumour necrosis factor receptor fc fusion protein' OR 'tnr 001' OR 'tnr001' OR 'tumor necrosis factor receptor fc fusion protein' OR 'tumour necrosis factor<br>receptor fc fusion protein' OR 'infliximab'/exp OR 'avakine' OR 'flixabi' OR 'inflectra' OR 'infliximab' OR 'infliximab dyyb' OR 'infliximab-dyyb' OR<br>'remicade' OR 'remsima' OR 'revellex' OR 'golimumab'/exp OR 'cnto 148' OR 'cnto148' OR 'golimumab' OR 'simponi' OR 'simponi aria') AND<br>('placebo'/exp OR 'placebo') AND ('randomized controlled trial'/exp OR 'controlled trial, randomized' OR 'randomised controlled study' OR 'randomised<br>controlled trial' OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled') AND [randomized controlled<br>trial]/lim AND [article]/lim AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [embase]/lim AND [2010-2018]/py|
||Secuquinumab<br>e|('psoriatic arthritis'/exp OR 'alibert bazin disease' OR 'arthritis psoriatica' OR 'arthritis, psoriasis' OR 'arthritis, psoriatic' OR 'arthropathic psoriasis' OR<br>'arthropathy, psoriatic' OR 'disease, alibert bazin' OR 'polyarthritis, psoriatic' OR 'psoriasis arthropathica'OR 'psoriasis pustulosa arthropathica' OR<br>'psoriasis, arthritis' OR 'psoriatic arthritis' OR 'psoriatic arthropathy' OR 'psoriatic polyarthritis' OR 'psoriatic rheumatism' OR 'psoriatic rheumatoid|  
|**Base de**<br>**dados**|**Tecnologia**|**Estratégia de busca**|
|---|---|---|
|||arthritis' OR 'rheumatoid arthritis, psoriatic') AND ('secukinumab'/exp OR 'ain 457' OR 'ain457' OR 'cosentyx' OR 'secukinumab') AND 'placebo'/exp<br>AND ('randomized controlled trial'/exp OR 'controlled trial, randomized' OR 'randomised controlled study' OR 'randomised controlled trial' OR<br>'randomized controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled') AND [randomized controlled trial]/lim AND<br>[article]/lim AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [embase]/lim AND [2010-2018]/py|
|Embase e<br>Pubmed|MMCDbiovs<br>MMCDbio|('psoriatic arthritis'/exp OR 'alibert bazin disease' OR 'arthritis psoriatica' OR 'arthritis, psoriasis' OR 'arthritis, psoriatic' OR 'arthropathic psoriasis' OR<br>'arthropathy, psoriatic' OR 'disease, alibert bazin' OR 'polyarthritis, psoriatic' OR 'psoriasis arthropathica' OR 'psoriasis pustulosa arthropathica' OR<br>'psoriasis, arthritis' OR 'psoriatic arthritis' OR 'psoriatic arthropathy' OR 'psoriatic polyarthritis' OR 'psoriatic rheumatism' OR 'psoriatic rheumatoid arthritis'<br>OR 'rheumatoid arthritis, psoriatic') AND ('adalimumab'/exp OR 'etanercept'/exp OR 'golimumab'/exp OR 'infliximab'/exp) AND ('adalimumab'/exp OR<br>'infliximab'/exp OR 'golimumab'/exp OR 'etanercept'/exp) AND ('safety'/exp OR 'safety' OR 'safety management' OR 'safety precaution' OR 'safety<br>protection' OR 'safety regulation' OR 'efficacy'/exp) AND ([controlled clinical trial]/lim OR [randomized controlled trial]/lim) AND [article]/lim AND<br>([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [2014-2018]/py|  
O fluxograma de seleção dos estudos é representado na **Figura A** e a avaliação dos estudos incluídos pelo Sistema GRADE encontra-se no **Quadro B** .  
**Figura A – Fluxograma de seleção dos estudos**  
<!-- Start of picture text -->
Estudos identificados nas bases de<br>dados<br>(n= 89)<br>Duplicatas<br>{n= 0)<br>Resumos selecionados Resumos excluidos<br>(n= 27) (n= 62)<br>Artigos selecionados para leitura na<br>Artigos selecionados para leitura na sxduidosipteaia  e motivos de<br>integra exclusdo: (n= 10)<br>(n=17) (08) Falta de dados para avaliaco da<br>eficacia/seguranca por grupo de<br>comparacao;<br>(01) A amostra apresenta apenas 3,<br>casos de artrite psoriatica;<br>Estudos incluidos para andlise (01) Os grupos comparadores utilizam<br>quantitativa amesma medicacao em dosagens<br>(n=5) diferentes<br><!-- End of picture text -->  
**Quadro B – Avaliação dos estudos incluídos pelo Sistema GRADE**  
|||<br>**Risco**|**Avaliação da evid**|**ência**<br>**Evidênci**|||**№ de pacientes**||**Efeito**|**Qualidade**<br>**d**|**Iâi**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**<br>ensaios clínicos|**de**<br>**viés**<br>grave|**Inconsistência**|**a**<br>**indireta**<br>|**Imprecisã**<br>**o**|**Outras**<br>**considerações**<br>ProtCR - utilizan|**DMCD-b**<br>**Placebo**<br>do MMCDbio|**Relativo**<br>**(95% IC)**|**Absoluto**<br>**(95% IC)**|**a**<br>**evidência**<br>⨁⨁◯◯|**mportnca**<br>IMPORTANT|
|2|randomizados<br>1,2<br>ensaios clínicos|<br>a,b<br>grave|não grave|grave<sup>1,3</sup>|não grave<br>P|nenhum<br>rotCR - utilizando|Diferen<br>Secuquinumabe|cia de médias =|-7,25|BAIXA<br>⨁⨁◯◯|E<br>IMPORTANT|
|1|<br>randomizados<sup>1</sup>|<br>a|não grave|grave<sup>3</sup>|não grave|nenhum|Difere|nça de médias =|2,03|BAIXA|E|
|4|<br>ensaios clínicos<br>randomizados<br>1,2,3,4|grave<br>a,b|não grave|grave<br>1,2,3,4|não grave<br>H|HAQ-DI - utiliza<br>nenhum<br>AQ-DI - utilizand|ndo MMCDbio<br>Diferen<br>o Secuquinumabe|ça de médias =|-0,20|<br>⨁⨁◯◯<br>BAIXA|<br>IMPORTANT<br>E|  
|2<br>ensaios clínicos<br>randomizados<br>1,5<br>2<br>ensaios<br>clínicos<br>randomizados<br>2,4<br>2<br>ensaios<br>clínicos<br>randomizados<br>2,4<br>2<br>ensaios<br>clínicos<br>randomizados<br>2,4|grave<br>a,c<br>grave<br>b<br>grave<br>b<br>grave<br>b|grave<sup>c</sup><br>não grave<br>não grave<br>não grave|grave<sup>d</sup><br>grave<sup>1,4,e</sup><br>grave<sup>1,4,e</sup><br>grave<sup>1,4,e</sup>|não grave<br>grave<sup>f</sup><br>não grave<br>grave<sup>f</sup><br>Qualquer|viés de<br>publicação<br>altamente<br>suspeito<sup>c</sup><br>ACR20 - utiliza<br>nenhum<br>ACR50 utiliza<br>nenhum<br>ACR70 utiliza<br>nenhum<br>evento adverso|ndo MMCDb<br>236/347<br>(68.0%)<br>ndo MMCDb<br>140/347<br>(40.3%)<br>ndo MMCDbi<br>79/347<br>(22.8%)<br>utilizando sec|Diferen<br>io<br>87/344<br>(25.3%)<br>io<br>25/344<br>(7.3%)<br>o<br>10/341<br>(2.9%)<br>uquinumabe|ça de médias<br>OR 2.00<br>(1.15 para<br>3.48)<br>OR 3.47<br>(1.64 para<br>7.34)<br>OR 3.77<br>(1.37 para<br>10.39)<br>|= -6,93<br>151 mais por 1.000<br>(de 27 mais para 288<br>mais)<br>141 mais por 1.000<br>(de 41 mais para 292<br>mais)<br>73 mais por 1.000<br>(de 10 mais para 210<br>mais)|⨁◯◯◯<br>MUITO<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>⨁⨁◯◯<br>BAIXA<br>⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANT<br>E<br>IMPORTANT<br>E<br>CRÍTICO<br>CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|  
|2<br>ensaios<br>clínicos<br>randomizados<br>1,5|grave<br>c|não grave|não<br>grave|não grave<br>Qualqu|viés de<br>publicação<br>altamente<br>suspeito<sup>c</sup><br>er evento adver|182/305<br>(59.7%)<br>so utilizando|88/151<br>(58.3%)<br>MMCDbio|OR 1.06<br>(0.71 para<br>1.57)|14 mais por 1.000<br>(de 85 menos para 104<br>mais)|⨁⨁◯◯<br>BAIXA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1<br>ensaios<br>clínicos<br>randomizados<sup>4</sup>|grave<br>b|não grave|grave<sup>4</sup>|não grave|nenhum|49/106<br>(46.2%)|37/105<br>(35.2%)|OR 1.03<br>(0.61 para<br>1.72)|7 mais por 1.000<br>(de 103 menos para 131<br>mais)|⨁⨁◯◯<br>BAIXA|CRÍTICO|  
**IC:** Intervalo de confiança; **OR:** Odds ratio.

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
a. Não é possível garantir o cegamento dos avaliadores, assim como método de randomização e manutenção do sigilo da alocação; b. Não é possível garantir o cegamento dos avaliadores; c. Possível relato de viés seletivo; d. Instrumento de avaliação da qualidade de vida; e. Desfecho intermediário; f. IC 95% amplo

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
1. Gottieb, et.al. Secukinumab improves physical function in subjects with plaque psoriasis and psoriatic arthritis: Results from two randomized, phase 3 trials. J Drugs Dermatol; 2015.  
2. Kavanaugh, et.al. Safety and Efficacy of Intravenous Golimumab in Patients With Active Psoriatic Arthritis: Results Through Week Twenty-Four of the GO-VIBRANT Study. Arthritis Rheumatol; 2017.  
3. Kavanaugh,et. al. Patient-reported outcomes and the association with clinical response in patients with active psoriatic arthritis treated with golimumab: Findings through 2 years of a phase III, multicenter, randomized, double-blind, placebo-controlled trial.. Arthritis Care Res (Hoboken); 2013.  
4. Mease, et.al. Tofacitinib or Adalimumab versus Placebo for Psoriatic Arthritis. N Engl J Med; 2017.  
5. McInnes, et.al. Efficacy and safety of secukinumab, a fully human anti-interleukin-17A monoclonal antibody, in patients with moderate-to-severe psoriatic arthritis: a 24-week, randomised, double-blind, placebo-controlled, phase II proof-of-concept trial..Ann Rheum Dis; 2014.  
**APÊNDICE 3**

---

<!-- METADADOS: doenca: Artrite Psoriásica | secao: **10      Busca da evidência** -->
|**Número do Relatório de**<br>**Recomendação da**||**Tecnologias avaliadas**|**pela Conitec**|
|---|---|---|---|
|**diretriz clínica (Conitec)**<br>**ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|<br>Relatório de<br>Recomendação nº<br>1023/2025|Atualização devido à<br>incorporação de<br>tecnologias no SUS.<br>Proposta de alteração do<br>título do documento.|Ixequizumabe para tratamento de<br>pacientes adultos com artrite psoríaca<br>ativa com falha ou intolerantes ao<br>tratamento a um medicamento<br>modificador do curso da doença<br>biológico em primeira linha, conforme<br>Protocolo Clínico do Ministério da<br>Saúde. [Relatório de Recomendação n°<br>951/2025; Portaria SECTICS/MS n°<br>01/2025].|-|
|||Citrato de tofacitinibe para o tratamento<br>de pacientes adultos com artrite|Certolizumabe pegol para o<br>tratamento de artrite<br>psoríaca em primeira linha<br>de tratamento biológico<br>(MMCD-b).<br>[Relatório de<br>Recomendação n°<br>626/2021. Portaria<br>SCTIE/MS nº 39/2021].|
|<br>Portaria Conjunta<br>SAES/SCTIE/MS nº<br>16/2021 [Relatório de<br>Recomendação n°<br>602/2021]|Atualização devido à<br>incorporação de<br>tecnologias no SUS|psoríaca ativa moderada a grave<br>intolerantes ou com falha terapêutica<br>aos medicamentos modificadores do<br>curso da doença sintéticos ou biológico.<br>[Relatório de Recomendação nº<br>537/2020; Portaria SCTIE/MS nº<br>28/2020].|Secuquinumabe para<br>tratamento da artrite<br>psoriásica ativa em<br>pacientes adultos na<br>primeira etapa de terapia<br>biológica. [Relatório de<br>Recomendação n°<br>620/2021. Portaria<br>SCTIE/MS nº 37/2021].<br>Ixequizumabe para<br>tratamento de pacientes<br>adultos com artrite psoríaca|  
|**Número do Relatório de**<br>**Recomendação da**||**Tecnologias avaliadas**|**pela Conitec**|
|---|---|---|---|
|**diretriz clínica (Conitec)**<br>**ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||||ativa com resposta<br>insuficiente ou intolerante<br>ao tratamento com um ou<br>mais medicamentos<br>modificadores do curso da<br>doença. [Relatório de<br>Recomendação n°<br>536/2020; Portaria<br>SCTIE/MS nº 31/2020].|
|<br>Relatório de<br>Recomendação n°<br>550/2020. Portaria<br>conjunta (SAES/SCITE)<br>nº 16, de 17 de novembro<br>de 2020|Atualização devido à<br>incorporação de<br>tecnologias no SUS|Certolizumabe pegol para o tratamento<br>de pacientes adultos com AP ativa,<br>moderada a grave, que tiveram resposta<br>inadequada prévia aos anti-<br>inflamatórios não esteroides,<br>medicamentos modificadores do curso<br>da doença sintéticos, e aos<br>medicamentos modificadores do curso<br>da doença biológicos, anti-TNF,<br>disponíveis no SUS. [Relatório de<br>Recomendação nº 486/2019; Portaria<br>SCTIE/MS Nº 59/2019].<br>|Secuquinumabe para o<br>tratamento da artrite<br>psoríaca ativa em pacientes<br>adultos na primeira etapa de<br>terapia biológica. [Relatório<br>de Recomendação n°<br>485/2019; Portaria<br>SCTIE/MS nº 52/2019].|
|<br>Portaria Conjunta<br>SAS/SCTIE/MS nº<br>26/2018 [Relatório<br>Recomendação nº<br>388/2018].|Atualização devido à<br>incorporação de<br>tecnologias no SUS|Secuquinumabe para o tratamento de<br>artrite psoriásica em pacientes adultos<br>com resposta inadequada a<br>medicamentos modificadores do curso<br>da doença sintéticos e biológicos da<br>classe anti-TNF. [Relatório de<br>Recomendação nº 336/ 2019].|Certolizumabe pegol para o<br>tratamento de artrite<br>psoriásica em pacientes<br>adultos com resposta<br>inadequada a medicamentos<br>modificadores do curso da<br>doença. [Relatório de<br>Recomendação nº 338/2018;<br>Portaria SCTIE/MS nº<br>07/2018].<br>Ustequinumabe para o<br>tratamento de pacientes<br>adultos com artrite<br>psoriásica ativa que|  
|**Número do Relatório de**||**Tecnologias avaliadas**|**pela Conitec**|
|---|---|---|---|
|**Recomendação da**||||
|**diretriz clínica (Conitec)**<br>**ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||||apresentaram resposta<br>inadequada aos<br>medicamentos<br>modificadores do curso da<br>doença. [Relatório de<br>Recomendação nº 337/2018;<br>Portaria SCTIE/MS nº<br>06/2018].|
|<br>Portaria Conjunta<br>SAES/SCTIE/MS nº<br>6/2017 [Relatório de<br>Recomendação nº<br>277/2017]|Atualização devido à<br>incorporação de<br>tecnologias no SUS|Golimumabe para o tratamento da<br>artrite psoriásica; [Relatório de<br>Recomendação nº 209/2016. Portaria<br>SCTIE/MS nº 14/2016].|-|
|Portaria SAS/MS n°<br>1.204/2014|Elaboração da primeira<br>versão do Protocolo|Naproxeno para o tratamento da Artrite<br>Psoriásica. [Relatório de<br>Recomendação nº 135/2014. Portaria<br>SCTIE/MS nº 44/2014].|Golimumabe para o<br>tratamento da artrite<br>psoriásica. [Relatório de<br>Recomendação nº 43/2013;<br>Portaria SCTIE/MS nº<br>06/2013].|

---

