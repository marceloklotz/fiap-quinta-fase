<!-- METADADOS: doenca: Doença de Gaucher | secao: Geral -->
PORTARIA CONJUNTA SAES/SECTICS Nº 10, DE 02 DE JULHO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Gaucher.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 4 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Doença de Gaucher no Brasil e as diretrizes nacionais para  
diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 942 e o Relatório de Recomendação nº 945 de novembro de 2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença de Gaucher.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Doença de Gaucher, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Doença de Gaucher.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede  
assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 04, de 22 de junho de 2017, publicada no Diário Oficial da União nº 120, de 26 de junho de 2017, seção 1, pág. 45.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES  
FERNANDA DE NEGRI  
1  
**ANEXO**

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **1. INTRODUÇÃO** -->
A doença de Gaucher (DG) é uma doença rara, autossômica recessiva, causada por mutações no gene _GBA1_ , o que gera atividade deficiente da enzima beta-glicocerebrosidase, compromentendo o metabolismo de lipídeos complexos derivados da membrana plasmática<sup>1</sup> . Como consequência há um acúmulo de glicocerebrosídeo ou “glicosilceramida” nos macrófagos<sup>2–4</sup> . Esses agregados fibrilares dentro dos macrófagos mudam a aparência do citoplasma dessas células, que então são chamadas de células de Gaucher<sup>1</sup> . Outros estudos indicaram que estas não resultam somente da transformação de macrófagos, mas são também uma subpopulação de macrófagos M2, resultado de uma via de diferenciação alternativa<sup>1</sup> . Essas células infiltram vários órgãos e são responsáveis pelos sinais e sintomas da DG<sup>1</sup> .  
A beta-glicocerebrosidase é codificada pelo gene _GBA1_ , localizado no cromossomo 1p21<sup>5</sup> . Apesar de <mark>estar relacionada a apenas um gene, a DG se caracteriza por grande variabilidade clínica</mark><sup>6</sup> <mark>, podendo também ser influenciada por variantes no gene PSAP1, que codifica proteínas de 4 SAPs (</mark> _<mark>Sphyngolipid Activator Protein</mark>_ <mark>), como a saposina C. A DG é um erro inato do metabolismo, cujo prognóstico pode variar de benigno a extremamente grave de acordo com o subtipo de apresentação e</mark> ao grau de deficiência da enzima<sup>7</sup> <mark>. Suas três formas clínicas de apresentação, denominadas DG tipo 1, 2 e 3, se distinguem conforme idade de manifestação da doença e presença de doença neurodegenerativa progressiva</mark><sup>7</sup> <mark>.</mark>  
<mark>A DG é</mark> uma das glicoesfingolipidoses mais comuns. A <mark>prevalência mundial pode variar de 0,70 a 1,75 por 100.000 habitantes e possui proporção similar entre homens e mulheres</mark><sup>8</sup> <mark>. A DG do tipo 1 é mais prevalente na Europa, Israel, Estados Unidos e em populações caucasianas derivadas da Europa</mark><sup>3,4</sup> <mark>. Os tipos 2 e 3 da DG ocorrem principalmente em países não ocidentais, incluindo o Oriente Médio não israelense, subcontinente indiano, China, Japão e Coréia</mark><sup>6,9</sup> <mark>.</mark><sup>.</sup> <mark>A incidência padronizada na população geral varia de 0,39 a 5,80 por 100.000 indivíduos</mark><sup>8</sup> <mark>. Os dados de incidência e prevalência no Brasil são escassos. Se</mark> gundo dados do Ministério da Saúde, há 825 pacientes com DG em tratamento no Brasil<sup>10</sup> .  
<mark>Como mencionado, a DG tem grande variedade de manifestações clínicas. Antes do advento da terapia de reposição enzimática (TRE), manifestações de longo termo incluíam cirrose, deterioração óssea e hipertensão pulmonar</mark><sup>7</sup> <mark>. Ademais, pacientes com DG podem ter risco aumentado de neoplasia de células B, mieloma múltiplo, gamopatia monoclonal e doença de Parkinson</mark><sup>7</sup> <mark>. Assim, a assistência integral à pessoa com DG requer que toda decisão terapêutica em um caso específico seja preferencialmente parte de um plano de cuidado de longo prazo, definido após análise de todas as evidências clínicas, laboratoriais, radiológicas e patológicas da doença.</mark>  
<mark>A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dá à Atenção Primária à Saúde (APS) um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.</mark> Os objetivos deste PCDT são prover recomendações a respeito do diagnóstico, tratamento e acompanhamento das pessoas com DG, tanto no âmbito da Atenção Primária à Saúde, como em Serviços Especializados do SUS.  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- E75.2 – Outras esfingolipidoses  
2

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **3.1. Manifestações clínicas** -->
A apresentação clínica da DG tem grande variedade, isto é, um “contínuo de fenótipos”, mas pode se distinguir em três formas mais relevantes: DG tipo 1, ou não neuronopática; e os tipos 2 e 3, neuronopáticos<sup>1</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **DG tipo 1** -->
A apresentação clínica da DG tipo 1 tem esplenomegalia em mais de 90% dos pacientes, podendo ser o único sinal clínico<sup>1</sup> . Pode ocorrer também hepatomegalia (60% a 80% de casos), lesões focais no fígado e/ou baço (40% dos pacientes) e fadiga (50%), que pode afetar atividades escolares e laborais<sup>1</sup> . Ademais, pacientes com DG tipo 1 estão mais sujeitos a cálculos biliares do que a população geral<sup>1</sup> . Em crianças, é possível e comum haver retardo de crescimento e puberdade<sup>1</sup> . Outros sinais compreendem a trombocitopenia (60% a 90% dos casos), a qual pode ocasionar sangramentos e condições de coagulação, e a anemia (20% a 50% dos casos)<sup>1</sup> . Além disso, pode ocorrer acometimento ósseo, o que causa dor aguda e/ou crônica, predominantemente na pelve e membros inferiores<sup>1</sup> . Crises de dor óssea aguda são mais comuns em crianças, associadas a inflamação local, febre moderada (38 °C) e leucocitose, com duração de 7 a 10 dias<sup>1</sup> . O acometimento ósseo pode se manifestar em remodelamento, a exemplo do aumento das regiões metafisária / diafisária na parte posterior do fêmur, conhecida como deformidade óssea em frasco de Erlenmeyer<sup>1</sup> .  
É possível também envolvimento pulmonar devido à infiltração por células de Gaucher, com desenvolvimento de doença intersticial e até fibrose, doença restritiva do pulmão secundária a deformação espinhal, ou hipertensão arterial pulmonar<sup>1</sup> . Apesar de o conceito convencional de DG tipo 1 não ter envolvimento neurológico, foi descrito que pacientes com DG tipo 1 podem ter risco aumentado de desenvolver doença de Parkinson (até 20 vezes maior)<sup>1</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **DG tipo 2** -->
A apresentação clínica de DG tipo 2 ocorre com comprometimento neurológico precoce e grave com início aos 3 a 6 meses de idade e envolvimento sistêmico (hepatoesplenomegalia)<sup>1</sup> . A seguinte tríade pode ser sugestiva da doença: (a) rigidez de pescoço e tronco (opistótono), (b) sinais bulbares (distúrbios de deglutição), (c) paralisia oculomotora (com estrabismo bilateral fixo temporário, que evolui rapidamente para paralisia do olhar horizontal)<sup>1, 13</sup> . É possível observar também apneia associada a espasmos da laringe, que podem se tornar mais frequentes e longos com o tempo<sup>1</sup> . O desenvolvimento psicomotor da criança pode ser alterado, com ocorrência de convulsões, as quais não são resolvidas por medicamentos antiepilépticos<sup>1</sup> . Outros sinais são a presença de esplenomegalia, trombocitopenia, retardo no crescimento (30% de casos), e até caquexia<sup>1</sup> . Na DG tipo 2, não há acometimento ósseo, sendo que o paciente pode vir a óbito antes do terceiro ano de vida, sendo a idade média de sobrevida de 11,7 meses (variação de 2 a 25 meses)<sup>1</sup> . As principais causas de morte estão relacionadas aos sintomas pulmonares (DG-pneumopatia) e a aspiração causada pela DG ou o agravamento de condições respiratórias, como apneia central<sup>1</sup> .  
A DG fetal é a forma mais rara (<1%) e mais grave da DG tipo 2. Geralmente se manifesta com hidropisia fetal, hepatoesplenomegalia, ictiose, artrogripose, dismorfia facial e trombocitopenia fetal. Além disso, a morte ocorre frequentemente no útero ou logo após o nascimento<sup>1</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **DG tipo 3** -->
A apresentação clínica da DG tipo 3, assim como a DG tipo 1, se caracteriza por manifestações viscerais, além de envolvimento neurológico oculomotor, geralmente antes dos 20 anos<sup>1</sup> . É possível que o único sintoma neurológico seja a oftalmoplegia horizontal. Por outro lado, é também possível que ocorram vários sinais neurológicos, incluindo epilepsia mioclônica progressiva (16% dos pacientes), ataxia cerebelar ou espasticidade (20% a 50% dos pacientes) e até demência<sup>1</sup> .  
3  
Pode ocorrer cifose grave e progressiva, além de envolvimento cardíaco (calcificação de válvula), envolvimento da córnea e hidrocefalia (pacientes com genótipo c.1342G>C/ D409H)<sup>1</sup> .  
Em pacientes sem diagnóstico específico da DG, este Protocolo assume o diagnóstico de DG tipo 3, bem como os tratamentos e critérios de elegibilidade especificados para este subtipo.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **3.2. Diagnóstico clínico** -->
O diagnóstico precoce da DG depende de um alto grau de suspeição, por parte de médicos generalistas, diante de casos de atraso de crescimento e desenvolvimento de hepatoesplenomegalia, por exemplo<sup>5</sup> .  
Para o diagnóstico clínico e para a determinação do tipo de DG, o paciente deve apresentar manifestações clínicas associadas à doença. Ainda, na DG tipo 3, a possibilidade de os sinais neurológicos serem secundários a outra doença (por exemplo, paralisia cerebral por hipóxia perinatal) deve ser excluída por especialista<sup>5</sup> .  
A avaliação do paciente inicia no exame físico, exames de sangue e avaliação sistêmica<sup>14</sup> . Os exames incluem hematócrito, funções renal e hepática, coagulação, ferro e ferritina<sup>14</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Avaliação do fígado e do baço** -->
A correta aferição do tamanho do fígado e do baço é fundamental tanto para o diagnóstico quanto para o monitoramento do tratamento dos pacientes com DG<sup>5</sup> . O diagnóstico de hepatomegalia pode ser feito por meio de exame físico (uso das técnicas de palpação e percussão associadas à fita métrica) ou de exame de imagem de abdômen<sup>5</sup> . Neste último caso, o ideal é realizar a aferição do volume hepático por ressonância magnética de abdômen<sup>5</sup> .  
Contudo, inexiste consenso na literatura sobre o tamanho normal do fígado, uma vez que ele depende da idade do paciente e do eixo ou local do órgão utilizado para aferição, entre outras características<sup>5</sup> . Ainda, o fato de o fígado ser palpável, não implica necessariamente, em presença de hepatomegalia. Para fins deste PCDT, e considerando, também, os exames de imagem disponíveis nos centros de atendimento, serão indicativos de hepatomegalia qualquer um dos seguintes critérios:  
1) tamanho do eixo longitudinal do fígado, medido por meio de exame físico ou exame de imagem de abdômen (ultrassonografia ou ressonância magnética), tomando como base a linha hemiclavicular direita e de acordo com a idade do paciente entre 0 a 2 meses: acima de 5 cm; 3 meses a 12 meses: acima de 6 cm; 1 ano a 2 anos: acima de 6,5 cm; 3 anos: acima de 7 cm; 4 anos: acima de 7,5 cm; 5 anos: acima de 8 cm; 6 anos a 12 anos: acima de 9 cm; maior de 12 anos: acima de 13 cm; OU  
2) volume hepático determinado por ressonância magnética acima de 3,5% do peso corporal, para indivíduos até 12 anos; acima de 2,2%, para indivíduos entre 13 anos a 17 anos, e; acima de 2,6% para indivíduos com idade igual ou superior a 18 anos; OU  
3) presença de hepatomegalia atestada por laudo do radiologista que realizou o exame de imagem do abdômen.  
Em relação ao tamanho esplênico, um baço palpável ao exame físico é na grande maioria das vezes indicativo de esplenomegalia, sendo este o critério utilizado por este PCDT para confirmar a presença dessa alteração<sup>5</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Sistemas de escore para quantificar carga de doença** -->
A gravidade da DG pode variar, mesmo em pacientes que apresentam a mesma forma clínica da doença. Vários escores foram desenvolvidos para determinar a gravidade dos pacientes, mas nenhum foi validado para a população brasileira<sup>15–20</sup> . Os escores de Di Rocco et al<sup>17</sup> e Weinreb et al<sup>18</sup> dependem da realização de ressonância magnética de osso. Existe um escore específico para crianças<sup>19</sup> que também considera a variável “crescimento”, enquanto o escore de Davies et al<sup>20</sup> é utilizado para aferir a gravidade das manifestações neurológicas dos pacientes com DG tipo 3.  
Embora a definição da gravidade da hepatomegalia e esplenomegalia associada à doença seja classicamente baseada na determinação dos volumes de fígado e baço por ressonância magnética de abdômen, este PCDT define hepatomegalia e esplenomegalia graves de acordo com o critério utilizado por Zimran et al<sup>15,16</sup> em seu escore. Os critérios de Zimran et al  
4  
15,16 são mais simples e determináveis por exame físico ou ultrassonografia abdominal, não consistem em medidas de volume e podem ser utilizados em todas as faixas etárias.  
O cálculo do escore de Zimran considera: presença de citopenias; hepatoesplenomegalia; esplenectomia; acometimento dos sistemas nervoso central, esquelético (determinado por achados clínicos, radiológicos ou cintilográficos) e de outros órgãos; além do funcionamento hepático determinado por achados clínicos e provas de função e dano hepáticos<sup>21</sup> .  
Na ausência de escores validados para o Brasil, este Protocolo considera como paciente com DG grave aquele que apresentar pelo menos uma das manifestações clínicas ou laboratoriais descritas no **Quadro 1** – desde que secundárias à DG – e que sejam reversíveis ou passíveis de melhora com o tratamento<sup>5</sup> .  
**Quadro 1** . Manifestações clínicas ou laboratoriais de DG grave.  
|**Manifestações clínicas ou**<br>**laboratoriais de DG grave**|**Definição**|
|---|---|
|Sintomas gerais incapacitantes|Dores ósseas não decorrentes de lesão óssea irreversível (tais como<br>osteonecrose, osteoesclerose e compressão vertebral), dor abdominal,<br>fadiga, limitação funcional aeróbica caracterizada por dispneia aos médios<br>ou grandes esforços, ou caquexia|
|Hepatomegalia maciça|Extensão do fígado até a fossa ilíaca, podendo ocupar todo o abdômen. Na<br>hepatomegalia leve, o fígado não ultrapassa a linha umbilical e, na<br>hepatomegalia moderada, é palpável entre a linha umbilical e a pelve|
|Esplenomegalia maciça|Extensão do baço até a fossa ilíaca, podendo ocupar todo o abdômen. Na<br>esplenomegalia leve, o baço não ultrapassa a linha umbilical e, na<br>esplenomegalia moderada, é palpável entre a linha umbilical e a pelve e não<br>atinge o lado direito do abdômen|
|Plaquetopenia grave|Contagem de plaquetas abaixo de 20.000/mm<sup>3</sup>, pois tais valores podem estar<br>associados a episódios mais graves de sangramento|
|Plaquetopenia associada a episódios<br>recorrentes de sangramento<br>clinicamente significativos,<br>secundários à DG e comprovados por<br>laudo médico.|Contagem de plaquetas entre 20.000/mm<sup>3</sup>e 50.000/mm<sup>3.</sup>Ressalta-se que a<br>contagem de plaquetas acima de 50.000/mm<sup>3</sup>usualmente não se associa a<br>sangramento espontâneo e, portanto, não se constitui em critério de<br>gravidade|
|Anemia grave|Hemoglobina abaixo de 8 g/dL|
|Acometimento hepático ou<br>prolongamento do tempo de<br>protrombina, tendo sido descartadas<br>outras possíveis causas, como<br>hepatites infecciosas e uso de<br>substâncias hepatotóxicas|Acometimento hepático: aumento de, no mínimo, duas vezes o limite<br>superior da normalidade dos níveis de aminotransferases/transaminases<br>(AST/TGO ou ALT/TGP);<br>Prolongamento do tempo da protrombina (maior que 130% em relação ao<br>valor de referência)|
|Osteoporose|Deve ser confirmada por densitometria óssea e que não tenha apresentado<br>resolução após no mínimo dois anos de tratamento com bisfosfonatos,<br>associada à ocorrência de fraturas espontâneas ou causadas por trauma<br>mínimo|  
5  
|**Manifestações clínicas ou**<br>**laboratoriais de DG grave**|**Definição**|
|---|---|
|Mieloma múltiplo||
|Necessidade de transfusão sanguínea||
|DG tipo 3||  
**Fonte** : Adaptado de Zimran et al. (1989), Zimran et al. (1992) e Wallach (2007)<sup>15,16,22</sup> .  
Adicionalmente, no caso de crianças e adolescentes com idade inferior a 19 anos, também serão considerados qualquer  
uma das seguintes medidas de crescimento inapropriado como critérios de gravidade:  
- altura inferior a 2 desvios-padrões em relação à altura alvo;  
- velocidade de crescimento abaixo do percentil 10 de acordo com a curva de Tanner e Whitehouse<sup>23</sup> ; OU  
- estatura inferior a dois desvios padrão para idade e sexo, por pelo menos 6 meses e desde que excluídas outras causas  
- para estes achados<sup>5</sup> .  
Para aferição da estatura, deverão ser utilizadas as seguintes curvas de crescimento da Organização Mundial da Saúde (OMS): curva de evolução da estatura de acordo com o sexo e a idade de zero a 5 anos<sup>24</sup> e curva de evolução da estatura de acordo com o sexo e a idade de 5 a 19 anos<sup>25</sup> .  
O cálculo da altura alvo<sup>26</sup> considera as seguintes fórmulas em centímetro:  
𝐶á𝑙𝑐𝑢𝑙𝑜 𝑑𝑎 𝑎𝑙𝑡𝑢𝑟𝑎 𝑎𝑙𝑣𝑜 𝑛𝑜 𝑠𝑒𝑥𝑜 𝑚𝑎𝑠𝑐𝑢𝑙𝑖𝑛𝑜=<sup>𝑎𝑙𝑡𝑢𝑟𝑎 𝑚𝑎𝑡𝑒𝑟𝑛𝑎+ 𝑎𝑙𝑡𝑢𝑟𝑎 𝑝𝑎𝑟𝑡𝑒𝑟𝑛𝑎+ 13</sup> 2 𝐶á𝑙𝑐𝑢𝑙𝑜 𝑑𝑎 𝑎𝑙𝑡𝑢𝑟𝑎 𝑎𝑙𝑣𝑜 𝑛𝑜 𝑠𝑒𝑥𝑜 𝑓𝑒𝑚𝑖𝑛𝑖𝑛𝑜=<sup>𝑎𝑙𝑡𝑢𝑟𝑎 𝑚𝑎𝑡𝑒𝑟𝑛𝑎+ 𝑎𝑙𝑡𝑢𝑟𝑎 𝑝𝑎𝑟𝑡𝑒𝑟𝑛𝑎−13</sup> 2  
A este resultado adicionam-se mais ou menos 10 cm (aproximadamente dois desvios-padrões)<sup>5</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **3.3. Diagnóstico Laboratorial** -->
O padrão-ouro para o diagnóstico da DG é a medida da atividade da enzima beta-glicocerebrosidase, por ensaio fluorométrico, em leucócitos do sangue periférico. Em indivíduos com a doença, a atividade da enzima betaglicocerebrosidase em leucócitos costuma ser 0% a 15% da atividade normal, mas os valores de referência variam de acordo com o laboratório<sup>27–35</sup> .  
Em caso de dúvida, está indicada a realização de medida da atividade da beta-glicocerebrosidase em fibroblastos<sup>5</sup> . Em caso de valores duvidosos também neste método, recomenda-se a análise do gene _GBA1_ (presente em cerca de 95% dos pacientes)<sup>5</sup> , ou de _PSAP_ (5% dos pacientes).  
A análise genética (sequenciamento) completa do gene GBA está indicada em todos os casos de suspeita diagnóstica de DG, para fins de confirmação diagnóstica, aconselhamento genético, e para contribuição prognóstica em algumas variantes mais conhecidas, onde a correlação genótipo-fenótipo já está bem estabelecida. As variantes (previamente chamadas “mutações") encontradas deverão ser classificadas de acordo com os critérios estabelecidos pelo _American College of Medical Genetics and Genomics_ (ACMG)<sup>36</sup> . Em estudo brasileiro, que descreveu as frequências das variantes de _GBA1_ de uma coorte de pacientes com DG, o genótipo N370S/RecNciI foi o mais frequente (23,6%), seguido dos alelos RecNcil e L444P<sup>37</sup> . N370S está localizado no exon 9 e L444P está no exon 10 de _GBA1_<sup>37</sup> . O alelo recombinante mais frequente foi RecNcil, abrangendo as variantes L444P, A456P e V460V<sup>37</sup> . A presença desses genótipos confirma o diagnóstico de DG, no entanto, a ausência deles não exclui o diagnóstico, já que o paciente pode apresentar outras mutações<sup>5</sup> .  
A medida da atividade de beta-glicocerebrosidase em papel-filtro não é aceita como um critério isolado de diagnóstico de DG, sendo necessária também confirmação do diagnóstico pela presença de genótipo compatível (análise molecular do  
6  
gene _GBA1_ ), ou de identificação de variantes patogenéticas bialélicas ou de elevação significativa do biomarcador quitotriosidase<sup>5,38</sup> .  
Destaca-se que existem diversos biomarcadores de DG, dentre eles: quitotriosidase, TRAP (fosfatase ácida resistente a tartrato), ECA (enzima conversora de angiotensina) e o lysoGB1<sup>38</sup> . Dentre esses, a quitriosidase é a mais acessível para o contexto do SUS, sendo realizada por ensaio enzimático. A quitriosidase é o biomarcador mais empregado, tanto para avaliar a progressão da doença, quanto para verificar resposta à terapia<sup>14</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **3.4. Diagnóstico Radiológico** -->
Alguns procedimentos radiológicos são apresentados no **Quadro 2** , segundo a avaliação.  
**Quadro 2** . Diagnóstico radiológico.  
|**Avaliação**|**Procedimentos diagnósticos**|
|---|---|
|-<br>Volume e anormalidades estruturais do fígado e|-<br>Ultrassom|
|do baço|-<br>Tomografia computadorizada<br>-<br>Ressonância magnética|
|-<br>Anormalidades miocárdicas e valvulares|-<br>Exame ecocardiográfico com doppler|
|-<br>Detecção de sinais de hipertensão pulmonar|-<br>Raio X de tórax|
|-<br>Infiltração de medula óssea (i.e., evidência de<br>infartos ósseos, áreas de fibrose e necrose da cabeça<br>femoral)|-<br>Ressonância magnética|
|-<br>Densidade mineral óssea|-<br>Densitometria óssea duo-energética de coluna<br>lombar e/ou fêmur.<br>-<br>T escore: normal (>-1 dp), osteopenia (-1 > -2,5<br>dp) e osteoporose (<=-2,5 dp)<sup>39</sup>.<br>-<br>Z escore: normal (> -1), próximo ao risco (-1 e -<br>2,5) e risco (<-2,5)<sup>40</sup>.|
|-<br>Acometimento neurológico em pacientes com<br>DG tipo 3|-<br>Ressonância magnética cerebral|  
**Fonte** : Elaboração própria com base em recomendações de Cassinerio et al. (2014)<sup>14</sup>

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **3.5. Diagnóstico Patológico** -->
Na prática médica, o diagnóstico de DG pode ocorrer em casos de biópsia de medula óssea ou de biópsia de fígado, ao investigar hepatoesplenomegalia não explicada, com presença de transaminases anormais e/ou trombocitopenia<sup>14</sup> . Nesses casos, é possível detectar células de Gaucher nas amostras dos órgãos<sup>14</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Estão incluídas neste PCDT todas as pessoas com suspeita ou diagnóstico confirmado, seja clínico, laboratorial, radiológico e/ou genético de DG. Os tratamentos incluídos têm recomendação em bula para deficiência de betaglicocerebrosidase, porém não apresentam recomendação para deficiência de saposina C.  
Serão incluídos no tratamento medicamentoso pacientes que apresentarem os seguintes critérios maiores:  
7  
a) diagnóstico clínico de DG tipo 1 ou tipo 3 com manifestações clínicas associadas à doença. Para pacientes com DG tipo 3, a avaliação clínica com especialista deve descartar a possibilidade de os sinais neurológicos serem secundários a outra doença (por exemplo, paralisia cerebral por hipóxia perinatal); e  
b) diagnóstico genético ou bioquímico de DG, realizado mediante a demonstração de redução significativa (0% a 15% da atividade normal)<sup>41,42</sup> da atividade da enzima beta-glicocerebrosidase em leucócitos ou fibroblastos. A redução significativa da atividade da beta-glicocerebrosidase em papel filtro somente será considerada diagnóstica de DG se estiver acompanhada de diagnóstico molecular ou de aumento significativo da quitotriosidase (atividade plasmática elevada de 600  
a 1000 vezes acima dos valores médios normais – de aproximadamente 20 nmol/mL)<sup>43,44</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Adicionalmente, para uso de Terapia de Reposição Enzimática (TRE), o paciente deve apresentar pelo menos um dos seguintes critérios menores descritos no Quadro 3.** -->
**Quadro 3** . Critérios menores para uso de terapia de reposição enzimática.  
|**Critérios**|**Definição**|
|---|---|
|Anemia|Anemia, de acordo com o nível de hemoglobina, sexo e faixa etária do paciente,<br>desde que excluídas outras causas:<br>-<br>Hemoglobina abaixo de 12 g/dL para indivíduos do sexo masculino com<br>idade superior a 12 anos;<br>-<br>Hemoglobina abaixo de 11 g/dL para indivíduos do sexo feminino com<br>idade superior a 12 anos;<br>-<br>Hemoglobina abaixo de 10,5 g/dL para indivíduos entre 2 anos e 12 anos;<br>-<br>Hemoglobina abaixo de 9,5 g/dL para crianças com idade entre 6 meses e<br>2 anos;<br>-<br>Hemoglobina abaixo de 10,1 g/dL para crianças com idade inferior a 6<br>meses|
|Plaquetopenia|Contagem de plaquetas abaixo de 50.000/mm<sup>3</sup>, desde que excluídas outras causas.|
|Sangramento espontâneo ou decor|rente de trauma mínimo, desde que excluídas outras causas-|
|Hepatomegalia ou<br>esplenomegalia moderada ou<br>maciça, de acordo com os<br>critérios de Zimran et al.<sup>15,16</sup>|Moderadas: quando o fígado e baço forem palpáveis entre o umbigo e a pelve<br>Maciças: quando o fígado e baço atingirem a fossa ilíaca|
|Sinais radiológicos de<br>acometimento esquelético<br>reversível com TRE ou ISS|Exemplo: osteopenia e osteoporose, confirmadas por densitometria óssea,<br>infiltração da medula óssea confirmada por ressonância magnética de osso e<br>deformidade em frasco de Erlenmeyer evidenciada em exame de imagem|
|Sintomas gerais incapacitantes|Dores ósseas não decorrentes de lesão óssea irreversível (tais como osteonecrose,<br>osteoesclerose e compressão vertebral), dor abdominal, fadiga, limitação funcional<br>aeróbica caracterizada por dispneia aos médios ou grandes esforços, ou caquexia;|
|Crescimento inapropriado|Pacientes com menos de 19 anos com algumas das medidas de crescimento<br>inapropriado, conforme descrito no item Diagnóstico.|
|Acometimento de coração ou<br>pulmão, desde que atribuível à<br>DG|Coração: alterações evidenciadas por ecocardiografia;<br>Pulmão: alterações evidenciadas por radiografia simples ou espirometria|  
8  
|**Critérios**|**Definição**|
|---|---|
|Mieloma múltiplo||
|Esplenectomia||
|DG tipo 3||
|Acometimento hepático ou|Acometimento hepático: aumento de, no mínimo, duas vezes os valores|
|prolongamento do tempo de|sanguíneos de AST/TGO ou ALT/TGP, em relação ao limite superior de|
|protrombina, tendo sido|normalidade,|
|descartadas outras possíveis|Prolongamento do tempo da protrombina: menor de 70% em relação ao valor de|
|causas.|referência.|  
**Fonte** : Adaptado de Zimran et al. (1989), Zimran et al. (1992) e Wallach (2007)<sup>15,16,22</sup> .  
**Para uso de Inibidores da Síntese do Substrato (ISS), o paciente deve apresentar idade igual ou superior a 18**  
**anos, todos os critérios maiores, e pelo menos um dos seguintes critérios menores:**  
a) indicação de uso da TRE conforme **Quadro 3** e presença de condição médica que contraindique o uso de TRE, tais como reação de hipersensibilidade mediada por IgE ou efeito adverso grave à TRE de acordo com critérios adotados no glossário da Anvisa dos Guias de Farmacovigilância para Detentores de Registro de Medicamentos<sup>45</sup> . A ocorrência dessas condições deve estar documentada em laudo médico; OU  
b) presença de quadro clínico instável apesar de uso de TRE.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Indivíduos com suspeita, para os quais o diagnóstico para DG não é confirmado devem ser excluídos deste Protocolo. Além disso, serão excluídos deste Protocolo pacientes que apresentem:  
- DG assintomática<sup>23–25,35</sup> ;  
- DG oligossintomática, ou seja, pacientes que não apresentem quaisquer dos critérios menores;  
Ainda, pacientes que apresentarem hipersensibilidade, intolerância ou contraindicação a qualquer um dos  
medicamentos preconizados serão excluídos do uso do respectivo medicamento.  
Adicionalmente, serão excluídos do uso de **alfataliglicerase,** pacientes com idade inferior a 4 anos.  
Serão excluídos do uso de **miglustate** , os seguintes pacientes:  
- Gestantes;  
- Lactantes;  
- Com pouca possibilidade de aderir às modificações dietéticas necessárias para o início do tratamento, de acordo  
- com a avaliação médica; OU  
- A critério médico, quando houver alteração de hábito intestinal devido a diversas condições, tais como parasitoses,  
- doença celíaca e hipolactasia.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **6. CASOS ESPECIAIS** -->
Pacientes com DG tipo 1 e 3 estão incluídos no tratamento medicamentoso, apesar de os ensaios clínicos envolverem somente pacientes com DG tipo 1, uma vez que não há evidências sobre diferenças de efeito da TRE ou da ISS na evolução da doença somática destes pacientes.  
9

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7. TRATAMENTO** -->
O tratamento da DG envolve medidas de suporte e a terapia específica (TRE ou ISS), a fim de prevenir o desenvolvimento de novas manifestações clínicas, principalmente as irreversíveis, e a piora de lesões preexistentes, reversíveis, além de melhorar a qualidade de vida aos pacientes.  
A reversão de sinais e sintomas pode ser entendida como um retorno ao estado de doença anterior, antes da progressão, logo, essa reversão pode ser associada a melhoria de qualidade de vida<sup>46</sup> . De acordo com a literatura, a TRE pode reverter a síndrome hepatopulmonar e amenizar a dependência de oxigênio suplementar<sup>47</sup> , normalizar a curva de crescimento de pacientes com atraso<sup>47</sup> , reverter a citopenia e reduzir organomegalias<sup>47,48</sup> . Além disso, em coorte simulada, uma grande proporção de pacientes tratados com TRE se recuperou de seus sinais e sintomas até um estado assintomático<sup>46</sup> . Estima-se que o uso de TRE em longo termo pode diminuir a incidência de esplenectomia e reduzir a frequência de complicações ósseas (mas não as prevenir)<sup>46</sup> .  
Os alvos terapêuticos que se para alcançar com o tratamento medicamentoso da DG estão dispostos no **Quadro 4** .  
**Quadro 4** . Alvos terapêuticos do tratamento da doença de Gaucher.  
|**Parâmetro**|**Alvo**|
|---|---|
|**Anemia**|•<br>Normalizar os níveis de hemoglobina, após 12 a 24 meses de tratamento.<br>•<br>Eliminar dependência de transfusão sanguínea.<br>•<br>Reduzir fadiga, dispneia, angina.|
|**Trombocitopenia**|•<br>Aumentar o número de plaquetas em níveis suficientes para prevenir<br>sangramento espontâneo ou associado a procedimentos, após 1 ano de tratamento.<br>•<br>Normalizar a contagem de plaquetas em pacientes esplenectomizados.<br>•<br>Normalizar os níveis de plaquetas em pacientes não esplenectomizados, após 2<br>anos de tratamento, se os níveis pré-tratamento estavam acima de 60.000/mm<sup>3</sup>; nos<br>demais casos, dobrar os valores iniciais.|
|**Hepatomegalia**|•<br>Reduzir o volume esplênico em 20% a 30% no primeiro ano e em 30% a 45%<br>até o quinto ano de tratamento.<br>•<br>Aliviar distensão abdominal.|
|**Hepatopatia**|•<br>Prevenir a ocorrência de fibrose hepática avançada ou cirrose.<br>•<br>Prevenir complicações da doença hepática crônica, como hipertensão portal.|
|**Esplenomegalia**|•<br>Reduzir o volume hepático em 30% a 50% no primeiro ano e em 50% a 60% até<br>o quinto ano de tratamento.|
||•<br>Aliviar a distensão abdominal e a saciedade precoce.<br>•<br>Prevenir a ocorrência de infartos esplênicos.<br>•<br>Eliminar hiperesplenismo.|
|**Acometimento**<br>**esquelético**|•<br>Diminuir a dor óssea, após 2 anos de tratamento.<br>•<br>Prevenir a ocorrência de crises ósseas, osteonecrose e colapso articular<br>subcondral.|
||•<br>Aumentar a densidade mineral óssea, após 5 anos de tratamento.|
|**Acometimento**|•<br>Reverter a síndrome hepatorrenal e a dependência de oxigênio.|
|**pulmonar**|•<br>Diminuir hipertensão pulmonar.|  
10  
|**Parâmetro**|**Alvo**|
|---|---|
||•<br>Melhorar a funcionalidade e a qualidade de vida.|
||•<br>Evitar a deterioração rápida da doença pulmonar e a morte súbita.|
||•<br>Evitar a doença pulmonar.|
|**Crescimento**|•<br>Normalizar o crescimento, após 3 anos de tratamento.|
||•<br>Promover o início normal da puberdade.|
|**Neoplasias**|•<br>Diminuir a incidência de mieloma múltiplo e carcinoma hepatocelular.|
|**Qualidade de vida**|•<br>Melhorar a funcionalidade e a qualidade de vida aferida por questionários<br>validados.|  
**Fonte:** Pastores et al<sup>49</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.1. Medidas de suporte** -->
As medidas de suporte incluem:  
- Realização de aconselhamento genético ao paciente e aos familiares;  
- Acompanhamento médico e laboratorial periódicos a fim de identificar e tratar, de forma precoce, as complicações  
associadas;  
- Tratamento sintomático (por exemplo, uso de analgésicos para controle da dor óssea);  
- Uso de bisfosfonatos para controle da osteoporose (conforme PCDT de Osteoporose vigente do Ministério da  
Saúde);  
- Colocação de próteses ósseas em pacientes com osteonecrose ou com deformidades ósseas incapacitantes);  
- Uso de anticonvulsivantes e outros medicamentos para pacientes com DG tipo 3, caso necessário;  
- Reabilitação para pacientes com DG tipo 3;  
- Acompanhamento nutricional e estímulo à realização de atividade física, conforme as condições de saúde de cada  
paciente, para prevenção da osteoporose, do aumento de peso e da síndrome metabólica associados à TRE;  
- Vacinação de acordo com o calendário preconizado pelo Ministério da Saúde<sup>50</sup> ;  
- Cuidados básicos de saúde, inclusive para prevenção de neoplasias evitáveis, conforme preconizado pelo Ministério  
da Saúde;  
- Cuidados paliativos aos pacientes com DG tipos 2 e 3 e aos pacientes com DG tipo 1 que não fizeram o tratamento  
- específico na janela de tempo oportuna e apropriada ou que sofreram complicações que prejudiquem sua qualidade de vida;  
- Orientação aos pacientes com doença DG sobre o risco aumentado para o desenvolvimento da doença de Parkinson  
em pacientes e aqueles com a doença já estabelecida;  
- Acompanhamento odontológico;  
- Fisioterapia para pacientes com DG tipo 1.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2. Tratamento medicamentoso** -->
Os tratamentos atualmente utilizados para a terapia específica da DG são a TRE e a ISS.  
Inexistem evidências que justifiquem o uso concomitante de TRE e ISS, em qualquer forma da DG<sup>51,52</sup> . Desse modo, o uso concomitante desses tratamentos é contraindicado, devido à falta de eficácia comprovada e à escassez de estudos sobre interações medicamentosas.  
11

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.1. Terapia de Reposição Enzimática** -->
Para pacientes com idade igual ou superior a 4 anos de idade, desde que respeitados os demais critérios de inclusão e exclusão deste PCDT, o tratamento com a TRE poderá ser iniciado com qualquer um dos medicamentos preconizados por este Protocolo (alfataliglicerase, imiglucerase e alfavelaglicerase). Para crianças com idade inferior a 4 anos, o tratamento poderá ser feito, a critério médico e de acordo com a disponibilidade, com imiglucerase ou alfavelaglicerase.  
Ainda, inexistem evidências na literatura sobre os critérios para troca entre enzimas. Portanto, cabe ao médico assistente definir a necessidade de troca da enzima, quando o paciente apresentar evento adverso ou na ausência de resposta.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Vantagens da terapia** -->
Alfataliglicerase, imiglucerase e alfavelaglicerase são enzimas recombinantes utilizadas para a TRE na DG, que diferem entre si principalmente em relação à forma de produção, à sequência de aminoácidos e ao padrão de glicosilação.  
Desde que a TRE se tornou disponível no início dos anos 1990, o benefício significativo observado nos sintomas viscerais e hematológicos foi tão evidente, que, desde então, nenhum ensaio clínico usou controle por placebo em pacientes com DG<sup>53</sup> .  
Uma revisão sistemática Cochrane publicada em 2015 reuniu oito estudos, sendo seis comparando diferentes TRE e dois, comparando a adição de ISS a TRE comparado a TRE somente, totalizando 300 adultos e crianças de vários países<sup>53</sup> . Pacientes virgens de tratamento e com anemia tiveram aumento de hemoglobina, seja recebendo imiglucerase, alfavelaglicerase ou alfataliglicerase<sup>53</sup> . Para contagem de plaquetas, foi observado um benefício de imiglucerase sobre alfavelaglicerase em 45 U/kg no subgrupo de pacientes sem esplenectomia, com diferença média de -79,87 (IC 95%: -137,57 a -22,17)<sup>53</sup> . Uma possível explicação para esse efeito foi a maior prevalência de lesões esplênicas no grupo tratado com alfavelaglicerase, variável que não foi controlada no estudo<sup>53</sup> . Quanto à redução do volume do fígado, não houve resposta clara entre as TRE em pacientes virgens de tratamento<sup>53</sup> . Quanto à redução do volume do baço, os resultados não foram significativamente diferentes em qualquer TRE, nem na comparação entre doses. Nota-se que esse resultado parece ser discrepante com o desfecho de contagem de plaquetas, sugerindo um impacto na formação e longevidade das plaquetas, não só na função esplênica<sup>53</sup> . Quanto aos biomarcadores, não houve diferença nas concentrações séricas de quitriosidase, CCL18 e ECA após 9 meses, e então houve grande redução depois de 12 meses com dose mais alta de alfavelaglicerase, diferença média de 16,70 (IC 95%: 1,51 a 31,89)<sup>53</sup> . No que se refere aos desfechos esqueléticos, a variedade de relatos e a falta de dados numéricos disponíveis limitaram essa análise<sup>53</sup> .  
Em suma, no que se refere a sintomas reversíveis, a maioria dos pacientes responde bem ao tratamento, com redução de volume do fígado e do baço, aumento de hemoglobina e da contagem de plaquetas. Além disso, dor óssea e sintomas episódicos de acometimento ósseo também podem se resolver. Esses benefícios podem aparecer em seis meses, mas alguns pacientes precisam de mais tempo. Biomarcadores mostram redução marcada com o tratamento<sup>53</sup> .  
Para fins deste PCDT, se considera a equivalência de dose entre essas enzimas recombinantes, ou seja, poderão ser utilizadas doses entre 15 U/kg/infusão e 60 U/kg/infusão, a cada 2 semanas, para qualquer uma delas.  
Dois estudos de manutenção de TRE compararam infusões a cada duas semanas e a cada quatro semanas, e não houve diferenças significantes nos desfechos de hemoglobina, contagem de plaquetas, volumes de baço e fígado em um período de 12 meses<sup>53</sup> . Entretanto, ressalta-se que o regime de infusão a cada 4 semanas pode não ser adequado para todos os pacientes, sendo necessário um monitoramento cuidadoso, especialmente em relação aos parâmetros ósseos<sup>54</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Limitações da terapia** -->
Cabe destacar que as enzimas de TRE não atravessam a barreira hematoencefálica, e, portanto, não atuam sobre as manifestações neurológicas de DG tipo 2 e 3<sup>53</sup> .  
No que se refere aos sintomas irreversíveis, pacientes com DG tipo 1 que usam imiglucerase continuam a ter episódios de necrose avascular esquelética, particularmente se fizeram esplenectomia<sup>53</sup> . Os sintomas de osteopenia e osteoporose  
12  
associados a DG podem ter resposta insatisfatória com TRE (imiglucerase), especialmente se o tratamento somente for iniciado na fase adulta<sup>53</sup> .  
Inexistem evidências de que a imiglucerase previna o parkinsonismo e a neuropatia periférica, os quais afetam de forma limitante pacientes com DG tipo 1 de meia-idade e idosos<sup>53</sup> .  
Com base nessa revisão sistemática Cochrane, a alfavelaglicerase e a alfataliglicerase parecem ser não inferiores a imiglucerase. Ademais, não há evidência de superioridade, uma vez que os estudos não tinham delineamento nem poder estatístico para prová-la<sup>53</sup> . Os autores citam como limitações (a) a possibilidade de que os pacientes dos ensaios clínicos não representem a população global de DG, a qual é fenotípica e genotipicamente diversa<sup>53</sup> ; (b) os desfechos usados nos estudos, apesar de tradicionais, podem não refletir todo o espectro de patofisiologia de DG<sup>53</sup> . Ademais, os estudos dessa revisão não abordaram a troca de pacientes de um TRE para outro, mas a literatura sugere que tal troca pode ser feita de forma segura e sem perda de controle sobre a doença<sup>53,55</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.1.1. Imiglucerase** -->
Em revisão sistemática que incluiu estudos longitudinais, de observação ou de intervenção, para observar os efeitos de longo prazo dessas terapias, observou-se os seguintes resultados com imiglucerase<sup>55</sup> .  
Para pacientes virgens de tratamento, a meta-análise mostrou aumento na hemoglobina, com resultado mantido por até 5 anos de seguimento. Da mesma forma, houve aumento da contagem de plaquetas<sup>55</sup> . Foi observada redução do baço em até 4 anos de seguimento, assim como, redução do volume do fígado<sup>55</sup> .  
Já para pacientes previamente tratados, os valores de hemoglobina permaneceram estáveis com imiglucerase, com seguimento de até 3 anos<sup>55</sup> . Assim como a contagem de plaquetas ficou estável com os anos<sup>55</sup> . Não foi possível realizar meta-análise com resultados de tamanho de fígado e baço em pacientes previamente tratados.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.1.2. Alfavelaglicerase** -->
Em revisão sistemática que incluiu estudos longitudinais, de observação ou de intervenção, para observar os efeitos de longo prazo dessas terapias, observou-se os seguintes resultados com alfavelaglicerase<sup>55</sup> .  
Para pacientes virgens de tratamento, houve aumento de hemoglobina com o tratamento de alfavelaglicerase até os 7 anos de seguimento (evidência de 2 estudos)<sup>55</sup> . Da mesma forma, a contagem de plaquetas aumentou ao longo dos anos de tratamento<sup>55</sup> .  
Já em paciente previamente tratados, os valores de hemoglobina permaneceram estáveis com seguimento até 5 anos, assim como, a contagem de plaquetas permaneceu estável em seguimento até 2 anos<sup>55</sup> . Não foi possível conduzir meta-análise para mudança de volume de baço e fígado para pacientes previamente tratados em uso de alfavelaglicerase<sup>55</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.1.3. Alfataliglicerase** -->
Em revisão sistemática que incluiu estudos longitudinais, de observação ou de intervenção, para observar os efeitos de longo prazo dessas terapias, observou-se que em pacientes virgens de tratamento em uso de alfataliglicerase houve aumento das concentrações de hemoglobina e na contagem de plaquetas, e esses resultados foram mantidos até 5 anos, que foi o tempo de seguimento<sup>55</sup> . Observou-se também uma redução do volume do baço até os 3 anos de tratamento<sup>55</sup> .Entretanto, não foi observada diferença estatisticamente significante no tamanho o fígado em relação aos valores antes do início do tratamento<sup>55</sup> .  
Já para a população previamente tratada e com doença controlada, a concentração de hemoglobina permaneceu estável com alfataliglicerase (seguimento até 3 anos, somente 1 estudo)<sup>55</sup> . Da mesma forma, a contagem de plaquetas permaneceu  
13  
estável ao longo dos anos de acompanhamento (somente 2 estudos)<sup>55</sup> . Não houve variação significativa do volume do fígado com o tratamento, indicando, a manutenção do tamanho do órgão<sup>55</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.1.4. Inibição de Síntese de Substrato (ISS)** -->
O miglustate está aprovado pela Anvisa para tratamento dos pacientes com DG tipo 1 com sintomas leves a moderados para os quais a TRE é considerada inadequada. Outro medicamento da classe é o eliglustate, o qual não é recomendado neste PCDT, devido ao cancelamento do seu registro na Anvisa em novembro de 2023, bem como à ausência de evidências de benefícios clínicos incrementais na comparação com as alternativas terapêuticas disponíveis no SUS, aliado ao seu elevado custo (Apêndice 1).  
Não há estudos randomizados de ISS em pacientes virgens de tratamento. A monoterapia com miglustate parece ser tão efetiva quanto TRE para manutenção de respostas hematológicas, de órgãos e de biomarcadores em pessoas com DG tipo 1 previamente tratadas com imiglucerase por pelo menos 2 anos<sup>53</sup> . As desvantagens do miglustate estão relacionadas à presença de eventos adversos, como diarreia, perda de peso, tremores e neuropatia periférica<sup>55</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.1.5. Miglustate** -->
Em revisão sistemática que incluiu estudos longitudinais, de observação ou de intervenção, para observar os efeitos de longo prazo dessas terapias, observou-se os seguintes resultados com miglustate<sup>55</sup> .  
Para pacientes virgens de tratamento, as meta-análises não mostraram aumento de hemoglobina a partir do baseline com miglustate (até 2 anos de seguimento)<sup>55</sup> . Da mesma forma as mudanças na contagem de plaquetas não foram estatisticamente significativas (seguimento de até 3 anos)<sup>55</sup> .  
Na população previamente tratada, os resultados sugerem que miglustate pode manter os valores da linha de base<sup>55</sup> . Já para contagem de plaquetas, o tratamento com miglustate resultou em uma diminuição significante comparado com a linha de base<sup>55</sup> .  
Os autores discutem que há incerteza nos resultados, pois os valores de linha de base dos estudos não eram baixos. Os pacientes já poderiam ter a hemoglobina estabilizada no início do estudo, por exemplo<sup>55</sup> . Para os pacientes previamente tratados, os valores de hemoglobina permaneceram estáveis e os níveis plaquetários diminuíram em comparação com o baseline<sup>55</sup> . Não foi possível conduzir meta-análise para mudança dos tamanhos do fígado e baço com miglustate<sup>55</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: <u>Gestação e lactação</u> -->
Em caso de gestação e lactação, a indicação de TRE deverá ser considerada mediante análise de risco-benefício, uma vez que existe pouca experiência com TRE nestas condições. No entanto, as evidências sugerem o uso da TRE, uma vez que a gestação poderia agravar algumas das manifestações clínicas da DG, como a anemia<sup>56</sup> . Durante a gestação, a quantidade de enzima a ser utilizada deve ter como base o peso pré-concepcional, não sendo necessário o seu ajuste em relação ao peso. A classificação de risco no uso durante a gravidez, conforme terapia indicada, é:  
- Indicação de imiglucerase: há relatos de casos, mas não há estudos controlados a respeito do seu uso em gestantes.  
- Este produto é categoria de risco C na gravidez<sup>57</sup> .  
- Indicação de alfataliglicerase: estudos foram realizados em ratos e coelhos, com doses de até cinco vezes a dose humana máxima em mg/m<sup>2</sup> , não revelando evidências de comprometimento da fertilidade ou dano ao feto. Este produto é categoria de risco B na gravidez<sup>58</sup> .  
- Indicação de alfavelaglicerase: estudos em animais<sup>59</sup> não indicam efeitos nefastos. A análise de 25 gestações de 21  
- mulheres com DG expostas à alfavelaglicerase<sup>60</sup> evidenciou a ocorrência de abortamentos espontâneos no primeiro trimestre  
14  
em 16% dos casos (no período pré-TRE, esta taxa era de 25%) e de somente um caso associado a sangramento pós-parto. Achados que sugerem que o uso de alfavelaglicerase é seguro durante a gestação.  
- Miglustate é contraindicado tanto durante a gestação como na lactação, sendo classificado como categoria X.  
No período de lactação, deve ser verificada a necessidade de suplementação de cálcio na lactante. As enzimas recombinantes são moléculas grandes, que provavelmente não atravessam a barreira placentária, e pelo menos dois estudos demonstraram que a excreção de imiglucerase no leite materno é baixa<sup>61,62</sup> .  
Embora a maioria dos relatos disponíveis na literatura sobre gestação e lactação em vigência de TRE refira-se à imiglucerase e apontem para a ausência de efeitos teratogênicos associados, é possível generalizar esse achado para as duas outras enzimas, haja vista o efeito de classe. Apesar disso, recomenda-se que a TRE não seja iniciada em gestantes que não estavam previamente em tratamento, durante os três meses iniciais de gestação, nem que haja substituição do medicamento que vinha sendo recebido, pela possibilidade de ocorrência de reações à infusão<sup>63</sup> .  
<u>Pacientes com idade inferior, igual ou superior a 4 anos</u>  
Considerando os dados de eficácia e segurança<sup>64,65</sup> , a alfataliglicerase é indicada para os pacientes com idade igual ou superior a 4 anos<sup>65</sup> . Para crianças com idade inferior a 4 anos, o tratamento poderá ser feito, a critério médico e de acordo com a disponibilidade, com imiglucerase ou alfavelaglicerase.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.3. Medicamentos** -->
- Alfataliglicerase: pó para solução injetável de 200 U;  
- Alfavelaglicerase: pó para solução injetável de 400 U;  
- Imiglucerase: pó para solução injetável de 400 U;  
- Miglustate: cápsulas de 100 mg.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Terapia de reposição enzimática (TRE)** -->
Neste Protocolo, a TRE, independentemente da forma recombinante da enzima a ser utilizada, deve ser feita em pacientes adultos sem doença grave com a menor dose eficaz (15 U/kg/infusão, com infusões a cada 2 semanas)<sup>66–71</sup> . Ajustes de doses para 30 U/kg/infusão a cada 2 semanas serão permitidos nos casos em que nenhuma resposta seja observada, conforme item ‘Monitoramento’. Lesões irreversíveis presentes já ao início do tratamento, como osteonecrose, compressão vertebral e fibrose avançada do fígado e do baço, não poderão ser utilizadas como parâmetros ou desfechos para cálculo das doses de início, de manutenção ou dos reajustes.  
Doses iniciais de 30 U/kg/infusão a cada 2 semanas são preconizadas para crianças com menos de 12 anos ou para adolescentes com idade inferior a 19 anos e que não tenham completado crescimento ósseo, conforme radiografia para determinação da idade óssea<sup>72,73</sup> .  
A utilização de doses iniciais de 60 U/kg/infusão a cada 2 semanas fica recomendada somente aos casos de doença grave, independentemente da faixa etária. Os pacientes que estiverem em uso de 60 U/kg/infusão a cada 2 semanas deverão ser reavaliados a cada 6 meses em centro de referência em doenças raras com vistas à otimização da dose. Nos pacientes com DG tipo 3, a melhora neurológica é improvável e de difícil aferição, e não pode ser considerada como critério para ajuste de dose.  
Recomenda-se que as infusões sejam feitas com filtro 0,2 micra, inicialmente em um período de 2 horas, em serviço de atenção especializada. O esquema de ajuste posológico da TRE preconizado considera as evidências disponíveis e os dados de efetividade. A dose de início e a dose mínima de manutenção de tratamento preconizada neste Protocolo encontramse descritas no **Quadro 5.**  
15  
**Quadro 5.** Dose de início e de manutenção de tratamento com terapia de reposição enzimática.  
||**Presença de**|**Dose de início da**|**Dose mínima de**|
|---|---|---|---|
|**Características do Paciente**|**doença grave**|**enzima**<sup>**b**</sup>**(U/kg/infusão**|**manutenção**|
||**a**|**a cada 2 semanas)**|**(U/kg/Infusão)**<sup>**c**</sup>|
|**Adultos (18 anos ou mais) ou**|Não|15|15|
|**adolescentes que já**||||
|**ultrapassaram a fase de**|Sim|60|15|
|**crescimento**<sup>**d**</sup>**.**||||
|**Crianças e adolescentes (menores**|Não|30|30|
|**de 18 anos) em fase de**<br>**crescimento**<sup>**d**</sup>**.**|Sim|60|30|  
**Fonte** : Elaboração própria.  
**Notas** : a - conforme definido no item Diagnóstico; b - A dose de início é a dose máxima que pode ser reduzida de acordo com a resposta clínica do paciente; c. Os critérios para ajuste de dose estão descritos no item Monitoramento; d – considerar os Padrões de Crescimento da criança da Organização Mundial da Saúde<sup>74</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Inibição de síntese do substrato (ISS)** -->
A dose de miglustate utilizada para tratamento da DG é de 100 mg, por via oral, três vezes/dia<sup>75,76</sup> . O medicamento pode causar má digestão de carboidratos no lúmen intestinal, especialmente pela inibição da atividade alfaglicosídica das dissacaridases intestinais (principalmente sacarase, maltase e isomaltase). A lactase é apenas parcialmente afetada e em doses não fisiológicas (muito altas) de miglustate. O acúmulo de carboidratos mal digeridos no lúmen do intestino está relacionado ao influxo osmótico de água, aumento da atividade de fermentação das bactérias comensais e produção de metabólitos irritantes que levam ao aparecimento de intolerâncias gastrointestinais.  
Para evitar a concomitância do miglustate e do carboidrato no lúmen intestinal, recomenda-se, portanto, que o medicamento seja ingerido com algumas horas de intervalo de refeições com carboidratos e que, com orientação de nutricionista, o paciente inicie uma dieta pobre em carboidratos na semana anterior ao início do tratamento, que deve ser mantida nos primeiros meses de tratamento<sup>77</sup> . Assim, uma semana após iniciar a dieta, o paciente deve iniciar o uso de uma cápsula/dia de miglustate e aumentar gradativamente para três, em 2 semanas.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **7.2.5. Critérios de interrupção** -->
O tratamento da DG é contínuo e a interrupção deve ser considerada se ocorrer piora do quadro clínico após 24 meses de tratamento regular e com todos os ajustes possíveis de dose e de substituição de medicamentos e se houver baixa adesão ao tratamento.  
A baixa adesão ao tratamento é entendida como:  
- Realização de menos de 50% das infusões previstas para o período de 6 meses, nos pacientes em uso de TRE; ou  
- Ingestão de menos de 50% das cápsulas previstos para o período de 6 meses, em pacientes em uso de miglustate: ou  
- Frequência em menos de 50% das consultas previstas no período de um ano; ou  
- Não-realização dos exames solicitados para monitorização da evolução da doença.  
Nos casos de baixa adesão, o paciente deverá ser inserido em programa educativo, de forma a garantir seu retorno imediato ao tratamento quando houver garantia de melhora da adesão. A literatura brasileira já explorou algumas estratégias, tais como seguimento por telefone<sup>78</sup> , grupo educativo com dispensação de medicamentos<sup>79</sup> , cartilha educativa para promover adesão<sup>80</sup> e mapa de conversação em grupo<sup>81</sup> .  
16

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **8.1. Monitoramento mínimo recomendado para pacientes em terapia específica** -->
O monitoramento dos pacientes deve ser baseado principalmente em anamnese e exame físico. As manifestações clínicas são os principais parâmetros para determinar a necessidade de exames laboratoriais ou de imagem adicionais. A equipe de saúde deve estar atenta para a possibilidade de desenvolvimento de complicações como parkinsonismo ou neoplasias de origem hematopoiética (principalmente mieloma múltiplo) ou hepática (principalmente carcinoma hepatocelular) nesses pacientes.  
O **Quadro 6** apresenta a avaliação mínima necessária antes do início do tratamento e para monitoramento do tratamento. Avaliações adicionais podem ser necessárias, a depender das manifestações clínicas apresentadas pelos pacientes e da estrutura e condições de cada centro de atendimento, embora não devam ser consideradas obrigatórias para todos os pacientes.  
Recomenda-se também a realização de ressonância magnética de coluna lombar e de fêmur bilateral, para cálculo do _Bone Marrow Burden (_ BMB)<sup>82</sup> antes do início do tratamento e pelo menos a cada 5 meses, quando o exame e o profissional habilitado a fazer o cálculo estiverem disponíveis. O BMB não deve ser utilizado como medida da gravidade da doença óssea do paciente, uma vez que não está demonstrada a sua correlação com desfechos clínicos, como dor. Portanto, o exame deve ser realizado, de forma prospectiva, como marcador da evolução do quadro clínico do paciente e da eficácia do tratamento.  
**Quadro 6.** Resumo da avaliação mínima recomendada.  
|**Avaliação**|**Antes do início do**<br>**tratamento**|**Monitorização e periodicidade**|
|---|---|---|
|Anamnese.|Sim|Sim|
|Exame físico, incluindo medida do|||
|tamanho do fígado e do baço com fita<br>métrica.|Sim|Sim, a cada 6 meses|
|Medida da atividade da Beta-<br>glicocerebrosidase.|Sim|Não|
|Hemograma, plaquetas.|Sim|Sim, a cada 6 meses<sup>a</sup>|
|Ferritina, AST/TGO, ALT/TGP, GGT,<br>tempo de protrombina.|Sim|Sim, a cada 12 meses|
|Ultrassonografia ou ressonância<br>magnética de abdômen.|Sim|Sim, a cada 12 meses|
|Radiografia de tórax, espirometria e<br>ecocardiografia|Sim|Sim, na presença de sintomas ou<br>alterações clínicas<sup>b</sup>|
|Densitometria óssea (a partir dos 19<br>anos).|Sim|Sim, a cada 12 meses|
|Radiografia de coluna vertebral em<br>perfil, quadril em anteroposterior e de<br>ossos longos.|Sim|Realizar somente se houver piora de<br>sintomatologia óssea.|
|Radiografia para determinação da idade<br>óssea.|Sim|Apenas em crianças e adolescentes com<br>atraso ou parada de crescimento, ou|  
17  
|**Avaliação**|**Antes do início do**<br>**tratamento**|**Monitorização e periodicidade**|
|---|---|---|
|||com desenvolvimento puberal atrasado,<br>ou para confirmar que adolescente está|
|||em fase de crescimento.|
|Dosagem de vitamina B12.|Sim, na presença de<br>qualquer tipo de anemia ou<br>de manifestações clínicas<br>sugestivas de deficiência.|Sim, na presença de qualquer tipo de<br>anemia ou de manifestações clínicas<br>sugestivas de deficiência.|
|Eletroforese de proteínas<sup>c</sup>|Sim|Sim, a cada 3 anos a 5 anos em<br>pacientes acima dos 40 anos|
|Quitotriosidade|Sim|Sim, a cada 12 meses|  
**Fonte** : Elaboração própria.  
**Notas** : a. quando atingidas as metas do tratamento, o número e a frequência das avaliações laboratoriais podem ser diminuídos (Kaplan, 2013). b. necessárias para definir a presença de critérios de gravidade (acometimento cardíaco ou pulmonar). Para detecção de gamopatia policlonal, gamopatia monoclonal e mieloma múltiplo. c - Para detecção de gamopatia policlonal, gamopatia monoclonal e mieloma múltiplo. **Legenda:** ALT: alanina aminotransferase; AST: aspartato aminotransferase; GGT: gama glutamil transferase; TGO: transaminase oxalacética; TGP: transaminase glutâmico pirúvica.  
O tipo e a periodicidade das avaliações recomendadas serão determinados conforme a ausência ou ocorrência de intercorrências no intervalo de tempo. Em caso de intercorrências, devem ser realizadas as intervenções cabíveis, a critério do médico assistente. Este Protocolo preconiza os seguintes critérios para uma avaliação mínima:  
- <u>Avaliação clínica (anamnese e exame físico): nos primeiros 6 meses de tratamento, deve ser realizada a cada 3</u> meses, em serviços de referência, com questionamento direto sobre o estado geral de saúde e da qualidade de vida e sobre a ocorrência de dor, fadiga, fraturas, sangramentos e sintomas sugestivos de deficiência de vitamina B12 (tais como fraqueza, perda de apetite, perda de peso, dificuldade em manter o equilíbrio, depressão e perda de memória). Após esse período, a avaliação clínica deve ser realizada pelo menos uma vez a cada 6 meses. Em pacientes em uso de miglustate, deve-se verificar a ocorrência de diarreia, dor abdominal, neuropatia, tremores e perda de memória. Devem ser obrigatoriamente aferidos peso, altura, pressão arterial e medida do tamanho do fígado e do baço com fita métrica. Em crianças e adolescentes, também deve ser aferido o estágio puberal. No caso de pacientes em uso de miglustate e de pacientes com DG tipo 3, o exame neurológico deve ser incluído no exame físico.  
- <u>Hemograma com contagem de plaquetas: deve ser realizado a cada 6 meses, enquanto persistir alteração. Se houver</u> persistência ou piora da anemia, devem ser excluídas outras causas para este achado (incluindo anemia ferropriva, verminose, hemoglobinopatia e deficiência de vitamina B12, esta última por meio da dosagem dessa vitamina). Após normalização dos níveis de hemoglobina, o hemograma poderá ser realizado anualmente. A contagem de plaquetas também poderá ser avaliada anualmente após a normalização dos seus valores.  
- <u>Ferritina, AST/TGO, ALT/TGP, gama glutamil transferase (GGT) e tempo de protrombina: devem ser realizados a</u> cada 12 meses. Se houver piora destes parâmetros, devem ser excluídos potenciais fatores causadores, como uso de medicamentos (por exemplo, anticoncepcionais orais) e outras doenças hepáticas. Hemocromatose hereditária deve ser excluída nos pacientes que permanecerem com ferritina acima de 1.000 ng/mL após 1 ano de tratamento específico.  
- <u>Ultrassonografia ou ressonância magnética do abdômen com medida do tamanho ou do volume do fígado e do baço:</u>  
medida necessária para o início do tratamento e idealmente para o seguimento clínico de resposta ao tratamento a cada doze meses. Caso não estejam disponíveis de forma rotineira para o seguimento, esses exames devem ser realizados ao menos para o ajuste de dose da enzima por piora da hepatoesplenomegalia.  
18  
- <u>Radiografia de tórax, espirometria e ecocardiografia: medidas necessárias para avaliar a gravidade da doença,</u> particularmente no que se refere ao comprometimento cardíaco ou pulmonar. Em pacientes adultos, esses exames devem ser realizados antes do início do tratamento para avaliar manifestações clínicas de doença pulmonar e identificar possíveis aumentos da pressão arterial pulmonar. Esses exames devem ser repetidos conforme necessário, especialmente na presença de sintomas respiratórios ou cardíacos, e outras alterações clínicas relacionadas.  
- <u>Densitometria óssea: deve ser realizada somente em pacientes adultos, acima de 19 anos, antes do início do</u> tratamento e repetida durante o tratamento. Recomenda-se idealmente a cada 5 anos em pacientes do sexo masculino ou pacientes do sexo feminino em estágio pré-menopausa, e a cada 3 anos em pacientes do sexo feminino em estágio pósmenopausa, ou mais frequentemente se houver suspeita ou necessidade de monitorização de osteoporose preexistente. Em caso de osteoporose, deverão ser seguidas as medidas preconizadas pelo PCDT de Osteoporose vigente, do Ministério da Saúde.  
- <u>Radiografia de coluna vertebral em perfil, quadril em anteroposterior e de ossos longos: a radiografia de coluna</u> vertebral, quadril e ossos longos deverá ser realizada antes do início do tratamento e repetida somente se surgirem manifestações clínicas sugestivas de doença óssea ou piora de sintomatologia pré-existente, na indisponibilidade de ressonância magnética.  
- <u>Radiografia para determinação de idade óssea: deve ser realizada em caso de atraso ou parada de crescimento, ou</u> de desenvolvimento puberal atrasado, e sempre que for necessário determinar, para ajuste de dose, se o paciente adolescente estiver em fase de crescimento. Se a idade óssea for inferior em ao menos 2 desvios-padrão à idade cronológica, o paciente deverá ser encaminhado para avaliação endocrinológica.  
- <u>Medida de vitamina B12 no plasma: deve ser realizada na presença de qualquer tipo de anemia ou de manifestações</u> clínicas sugestivas de deficiência dessa vitamina. Se os níveis estiverem diminuídos, recomenda-se suplementar vitamina B12 na dieta.  
- <u>Eletroforese de proteínas: deve ser realizada a cada 3 anos a 5 anos em pacientes com pelo menos 40 anos de idade,</u> para detecção e acompanhamento de gamopatia policlonal, gamopatia monoclonal e mieloma múltiplo, situações que ocorrem mais frequentemente na DG e que são de difícil suspeição diagnóstica com base apenas em achados de história e exame físico.  
- <u>Medida de quitotriosidase no plasma: deve ser realizada antes do início do tratamento e repetida a cada 12 meses</u> para monitoração da resposta ao tratamento.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **8.2. Monitoramento mínimo recomendado para pacientes assintomáticos ou oligossintomáticos que não preenchem critérios para início de terapia específica.** -->
O tipo e a periodicidade das avaliações a seguir recomendadas pressupõem a ausência de intercorrências no intervalo de tempo a que se referem. Em caso de intercorrências, devem ser realizadas as intervenções cabíveis, a critério do médico assistente. Para o monitoramento destes pacientes, os seguintes parâmetros para avaliação são preconizados neste Protocolo:  
- <u>Avaliação clínica (anamnese e exame físico): deve ser realizada a cada 6 meses, com questionamento direto sobre o</u> estado geral de saúde e da qualidade de vida e sobre a ocorrência de dor, fadiga, fraturas, sangramentos e sintomas sugestivos de deficiência de vitamina B12. Devem ser obrigatoriamente aferidos peso, altura, pressão arterial e medida do tamanho do fígado e do baço com fita métrica. Em crianças e adolescentes, também deve ser aferido o estágio puberal.  
- <u>Hemograma com contagem de plaquetas: deve ser realizado a cada 6 meses.</u>  
- <u>Ferritina, AST/TGO, ALT/TGP, GGT e tempo de protrombina. Os exames devem ser feitos a cada 12 meses. Se</u> houver piora destes parâmetros, devem ser excluídos potenciais fatores causadores, como uso de medicamentos (por exemplo, anticoncepcionais orais) e outras doenças hepáticas.  
19  
- <u>Densitometria óssea: deve ser realizada somente em pacientes adultos (acima de 18 anos) e repetida somente no</u>  
- caso de surgimento de manifestações clínicas ou de piora de sintomatologia pré-existente.  
- <u>Radiografia de coluna vertebral em perfil, quadril em anteroposterior e de ossos longos: deve ser realizada somente</u>  
- se surgirem manifestações clínicas sugestivas de doença óssea ou piora de sintomatologia pré-existente.  
- <u>Radiografia para determinação de idade óssea: deve ser realizada no caso de atraso ou parada de crescimento, ou de</u> desenvolvimento puberal atrasado. Se a idade óssea for inferior à idade cronológica, deve-se encaminhar o paciente para avaliação endocrinológica.  
- <u>Medida de vitamina B12 no plasma: deve ser realizada na presença de qualquer tipo de anemia ou de manifestações</u> clínicas sugestivas de deficiência de vitamina. Se os níveis estiverem diminuídos, recomenda-se suplementar vitamina B12 na dieta.  
- <u>Eletroforese de proteínas: deve ser realizada a cada 3 anos a 5 anos em pacientes com pelo menos 40 anos de idade,</u> para detecção e acompanhamento de gamopatiapoliclonal, gamopatia monoclonal e mieloma múltiplo, situações que ocorrem mais frequentemente na DG e que são de difícil suspeição diagnóstica com base apenas em achados de história e exame físico  
- <u>Quitotriosidase: deve ser realizada a cada 12 meses.</u>

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **8.2.1. Resposta Terapêutica** -->
A avaliação da resposta terapêutica também faz parte do monitoramento dos pacientes com DG e o ajuste de dose deverá ser feito até ser determinada a dose mínima de manutenção eficaz para cada indivíduo. Esta verificação ocorre conforme a melhora ou piora clínica.  
A resposta terapêutica dos índices hematológicos deverá ser avaliada por meio dos níveis de hemoglobina e contagem de plaquetas.  
Em relação ao fígado e ao baço, poderão ser utilizados os seguintes parâmetros:  
a) Tamanho de ambos os órgãos aferido por exame físico ou por exame de imagem de abdome, conforme descrito no item diagnóstico; OU  
b) volume de ambos os órgãos aferido por tomografia computadorizada, ultrassonografia de abdome, ou por ressonância magnética de abdome; OU  
c) impressão de piora, estabilização ou melhora, atestada por laudo de radiologista experiente, do tamanho ou volume de ambos os órgãos.  
Recomenda-se que o método utilizado para aferição no período basal, antes do início do tratamento, seja o mesmo a ser utilizado na monitorização.  
Considerando-se a variabilidade dos métodos de aferição empregados para avaliação dos nível de hemoglobina, contagem de plaquetas e tamanho e volume do fígado e baço, a melhora ou piora de tais parâmetros é definida como uma variação, respectivamente, igual ou superior a 20%, para melhora do nível de hemoglobina e contagem de plaquetas, ou redução igual ou superior 20%, para melhora da hepatoesplenomegalia, em relação aos valores basais do início do tratamento ou em relação ao reajuste de dose. Se a variação for mantida entre menos 20% e mais 20% respectivamente, o parâmetro será considerado estável.  
A piora do nível de hemoglobina e da contagem de plaquetas é definida como uma redução de mais de 20% em relação aos valores basais do início do tratamento ou em relação ao ajuste de dose. A piora da hepatoesplenomegalia, por sua vez, é definida como um aumento superior a 20% do tamanho ou volume do fígado ou baço. Em relação à hepatoesplenomegalia, também será aceita, desde que atestada por laudo, a impressão de radiologista experiente acerca da piora, estabilização ou  
20  
melhora do tamanho ou volume desses órgãos. Os demais parâmetros serão avaliados de forma subjetiva, devendo sua melhora, piora ou estabilidade ser documentada em laudo médico.  
A definição de alvo terapêutico da TRE tem sido classicamente feita de modo retrospectivo, com base em opiniões de especialistas e na evolução dos pacientes tratados com imiglucerase e que estão incluídos no banco de dados do ICGGR 19,49,83. Além de o nível de evidência ser baixo, os alvos descritos são parâmetros sabidamente afetados pela TRE e não obrigatoriamente desfechos clinicamente significativos (por exemplo, melhora da sobrevida ou melhora neurológica não se encontram entre os alvos). Assim, devem ser usados de forma cautelosa, não se constituindo em parâmetros validados para ajuste de dose. Os alvos terapêuticos para TRE estabelecidos por Pastores et al<sup>49</sup> encontram-se no **Quadro 4** .  
Resposta e alvo terapêuticos não são sinônimos. A definição de uma resposta terapêutica possibilita determinar, em um período relativamente menor de tempo, a dose mínima clinicamente eficaz para o paciente. Já o alvo terapêutico é um objetivo que pode ser atingido em um período relativamente longo de tratamento. É possível que a resposta e o alvo sejam alcançados em um dos parâmetros (nível de hemoglobina, por exemplo), mas não em outro (tamanho do fígado, por exemplo).  
Weinreb et al<sup>18</sup> analisaram o tratamento com imiglucerase após 4 anos e Pastores et al.<sup>110</sup> mostraram que 100% dos pacientes atingem pelo menos um dos alvos estabelecidos, 99% atingem pelo menos três e 41,5% atingem os seis alvos.  
A resposta clínica ao tratamento deve ser avaliada conforme a gravidade da doença, conforme abordado a seguir.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **8.2.2. Pacientes sem doença grave** -->
A resposta clínica ao tratamento é definida como a presença de, no mínimo, um dos critérios a seguir, desde que transcorridos pelo menos 6 meses do início do tratamento ou do aumento da dose da enzima e que não tenha havido piora de qualquer um destes critérios:  
- Qualquer aumento dos níveis de hemoglobina, de acordo com os critérios de monitoramento;  
- Qualquer aumento da contagem de plaquetas, de acordo com os critérios de monitoramento;  
- Qualquer redução do tamanho do fígado, de acordo com os critérios de monitoramento;  
- Qualquer redução do tamanho do baço, de acordo com os critérios de monitoramento;  
- Redução da dor óssea;  
- Redução do sangramento;  
- Aumento da capacidade funcional;  
- Melhora da qualidade de vida.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **8.2.3. Pacientes com doença grave** -->
A resposta clínica ao tratamento é definida como o desaparecimento de todos os seguintes critérios de gravidade presentes no paciente:  
- Ausência de sintomas gerais incapacitantes - dor óssea não decorrente de lesão óssea irreversível (tais como osteonecrose, osteoesclerose e compressão vertebral), dor abdominal, fadiga, limitação funcional aeróbica caracterizada por dispneia aos médios ou grandes esforços, ou caquexia;  
- Normalização da contagem de plaquetas;  
- Normalização da hemoglobina abaixo de 8 g/dL;  
- Ausência de necessidade de transfusão sanguínea;  
- Normalização dos níveis de AST/TGP e ALT/ TGO ou prolongamento do tempo de protrombina;  
- Ausência de acometimento cardiopulmonar clinicamente significativo e ausência de novas fraturas ósseas  
espontâneas ou associadas a trauma mínimo.  
21

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **8.3. Ajuste de dose** -->
Nos pacientes em TRE, assim que a resposta clínica for atingida a dose da enzima deverá ser gradualmente diminuída. Caso ocorra piora clínica em um intervalo mínimo de 6 meses após o início do tratamento ou ajuste da dose, a dose da enzima poderá ser gradualmente aumentada, até um máximo de 60 U/kg/infusão. Se os parâmetros forem mantidos estáveis após 6 meses do ajuste da dose que sucedeu a resposta clínica, a dose da enzima poderá ser novamente diminuída. Os ajustes deverão ser feitos até ser determinada a dose mínima de manutenção eficaz para cada indivíduo. Não havendo resposta adequada, desde que excluídas outras causas, ajustes até a dose limite superior (60 U/kg/infusão) deverão ser decididos no centro de referência.  
A redução de dose pode ser individualizada e imediata para a dose que o médico assistente considerar adequada, uma vez que não existem justificativas que embasem uma redução lenta e gradual. O aumento da dose deverá ocorrer nesta sequência: de 15 U/kg/infusão para 30 U/kg/infusão a cada 2 semanas durante um intervalo mínimo de 6 meses; depois, para 45 U/kg/infusão a cada 2 semanas durante um intervalo mínimo de 6 meses; e, posteriormente, para 60 U/kg/infusão a cada 2 semanas durante um intervalo mínimo de 6 meses. Cada ajuste, portanto, deve ter um intervalo mínimo de 6 meses. A dose máxima de TRE preconizada é de 60 U/kg/infusão a cada 2 semanas.  
Portanto, hemograma, plaquetas, transaminases hepáticas, quitotriosidase, estimativa do tamanho do fígado e do baço e questionamento sobre dor óssea, sangramento, capacidade funcional e qualidade de vida deverão ser realizados no período basal, antes do reajuste de doses e anualmente durante o tratamento até a sua normalização.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Terapia de reposição enzimática (TRE)** -->
Os principais eventos adversos associados à TRE são as reações à infusão (hiperemia, prurido, febre), geralmente de leve intensidade e reversíveis com a redução da velocidade de infusão ou com o uso de anti-histamínico, corticoide e antitérmico. É possível que haja variação em relação à taxa de efeitos adversos entre as três enzimas recombinantes disponíveis. A causa dessa variação é alvo de debate, podendo ser os diferentes padrões de glicosilação das enzimas existentes ou os diferentes graus de tendência à floculação. Entretanto, isto é difícil de ser aferido na literatura existente, seja pela falta de estudos, seja pela heterogeneidade na captura, e na definição e descrição dos efeitos. Mesmo em relação aos dados de soroconversão, que são apresentados de maneira mais uniforme, deve haver certa cautela na interpretação, uma vez que os ensaios utilizados nos estudos são diferentes e não são comercialmente disponíveis. A imiglucerase é a enzima mais estudada em relação a este tópico, e 1,5% dos pacientes apresentam reações à infusão<sup>84</sup> .  
Dessa forma, frisa-se que qualquer uma das enzimas pode estar associada à ocorrência de reações à infusão, especialmente no início do tratamento. A realização de infusões em locais distintos de hospitais ou ambulatórios deve ser discutida caso a caso, ter o aval do médico assistente e estar condicionada à presença de profissional treinado no preparo do medicamento, na sua administração e no tratamento imediato de reações que porventura possam ocorrer.  
É obrigatória a comunicação de ocorrência de eventos adversos à Anvisa (por meio do Vigimed) e ao respectivo detentor do registro do medicamento. Se houver evento adverso associado à TRE, deve ser discutida a possibilidade de uso de pré- medicação ou diminuição da velocidade nas próximas infusões, ou mesmo troca da enzima. Inexiste um regime padrão de pré-medicação, podendo ser utilizados corticoide, anti-histamínico e antitérmico. Além disso, existem protocolos de dessensibilização que podem ser empregados para promover a imunotolerância, especialmente quando a mudança de terapia não é uma opção viável<sup>85</sup> .  
A ocorrência de hipersensibilidade mediada por IgE a uma das enzimas indica a necessidade de suspensão do tratamento com o medicamento desencadeador. Neste caso, o paciente, a critério médico, pode reiniciar o tratamento com outra enzima preconizada por este Protocolo ou iniciar a ISS.  
22

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Inibição da síntese de substrato (ISS) - miglustate** -->
Os eventos adversos mais comumente associados ao uso de miglustate são perda de peso (60%), eventos gastrointestinais (acima de 80%) e tremores (30%). Tais efeitos provocam a suspensão do medicamento em 20% a 30% dos casos<sup>76,77,86,87</sup> . Dor abdominal, diarreia e flatulência podem ser controladas por meio de dieta específica e de uso concomitante de agente antidiarreico. Neuropatia periférica e disfunção cognitiva são também relatadas, mas a associação causal com o uso de miglustate ainda não está estabelecida.  
Estudos pré-clínicos demonstram que o miglustate predispõe à catarata e ao desenvolvimento de tumores (pelo menos de testículo e de intestino), assim como prejudica a espermatogênese e os parâmetros espermáticos, reduzindo a fertilidade. Inexistem dados em gestantes, mas em animais parece haver toxicidade reprodutiva, incluindo distocia. O miglustate não mostrou potencial mutagênico ou clastogênico nos testes-padrão de genotoxicidade<sup>88</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **9. REGULAÇÃO / CONTROLE / AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pessoas com DG devem ser acompanhadas em serviços de referência, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento. A continuidade do atendimento, como a infusão dos medicamentos, poderá ocorrer em outros serviços de atenção especializada, mantendo-se o centro de referência para definição dos esquemas de administração e a monitorização preconizados neste Protocolo.  
O aumento da dose administrada ou a troca entre as TRE deverá ser avaliados pelo centro de referência, seguindo os critérios contidos neste Protocolo.  
Em função da possibilidade de ocorrência de reações alérgicas, pacientes com DG em tratamento com TRE devem receber o medicamento em ambiente hospitalar, com uso de bombas de infusão e de filtros, sob supervisão médica. Após 6 meses de tratamento, a critério do médico do centro de Referência, as infusões dos pacientes que não apresentaram reações à infusão e que não façam uso de pré-medicação poderão ser realizadas, de forma supervisionada e após treinamento da equipe envolvida, em local mais próximo da residência do paciente ou mesmo, na impossibilidade total do seu comparecimento, na sua residência<sup>89–91</sup> . Para tanto, o paciente poderá ser assistido pela Estratégia de Saúde da Família (ESF).  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras.  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de  
23  
ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da atenção primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o _locus_ da atenção à saúde dos pacientes com doenças raras  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Adicionalmente, verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Recomenda-se que o serviço de referência disponha de equipe multidisciplinar da qual façam parte hematologistas, geneticistas, gastroenterologistas, pediatras e neurologistas, entre outros profissionais da área da saúde, e que esteja capacitada para desempenhar as seguintes funções:  
- Avaliar todas as solicitações de início de tratamento;  
- Administrar os medicamentos de TRE, pelo menos durante os primeiros 6 meses de tratamento - após esse período, pode ser considerada a possibilidade de transferência das infusões para um local mais próximo da residência do paciente e que apresente as condições mínimas necessárias para o armazenamento do medicamento, realização de infusões e atendimento de intercorrências;  
- Avaliar todos os casos de mudanças de doses, de estratégia de tratamento (TRE ou ISS) e de tipo de enzima;  
- Realizar a monitorização e o acompanhamento dos pacientes; e  
- Avaliar todos os casos especiais.  
24

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **11. REFERÊNCIAS** -->
1. Stirnemann J, Belmatoug N, Camou F, Serratrice C, Froissart R, Caillaud C, et al. A Review of Gaucher Disease Pathophysiology, Clinical Presentation and Treatments. Int J Mol Sci. 2017 Feb 17;18(2):441.  
2. de Souza F, Guidoni R, de Toledo S, Nascimento D. Doença de Gaucher e gravidez: um prognóstico favorável . Diagn tratamento. 2016;21(4):153–7.  
3. Zimran A, Belmatoug N, Bembi B, Deegan P, Elstein D, Fernandez‐Sasso D, et al. Demographics and patient characteristics of 1209 patients with Gaucher disease: Descriptive analysis from the Gaucher Outcome Survey (GOS). Am J Hematol. 2018 Feb 12;93(2):205–12.  
4. Charrow J, Andersson HC, Kaplan P, Kolodny EH, Mistry P, Pastores G, et al. The Gaucher Registry. Arch Intern Med. 2000 Oct 9;160(18):2835.  
5. Brasil. PORTARIA CONJUNTA N<sup>o</sup> 4, DE 22 DE JUNHO DE 2017: Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Gaucher/ MINISTÉRIO DA SAÚDE/ SECRETARIA DE ATENÇÃO À SAÚDE/ SECRETARIA DE CIÊNCIA E TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE. Brasil; 2017.  
6. Ida H, Rennert OM, Iwasawa K, Kobayashi M, Eto Y. Clinical and genetic studies of Japanese homozygotes for the Gaucher disease L444P mutation. Hum Genet. 1999 Aug 1;105(1–2):120–6.  
7. Kishnani PS, Al-Hertani W, Balwani M, Göker-Alpan Ö, Lau HA, Wasserstein M, et al. Screening, patient identification, evaluation, and treatment in patients with Gaucher disease: Results from a Delphi consensus. Mol Genet Metab. 2022 Feb;135(2):154–62.  
8. Nalysnyk L, Rotella P, Simeone JC, Hamed A, Weinreb N. Gaucher disease epidemiology and natural history: a comprehensive review of the literature. Hematology. 2017 Feb 7;22(2):65–73.  
9. Grabowski G, Barnes, Burrow. Prevalence and management of Gaucher disease. Pediatric Health Med Ther. 2011 Jun;59.  
10. Brasil. Sistema de Informações Ambulatoriais do SUS (SIA/SUS) [Internet]. . http://sia.datasus.gov.br/principal/index.php. 2023.  
11. BRASIL. Diretrizes metodológicas : elaboração de diretrizes clínicas [recurso eletrônico] / Ministério da Saúde, Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde, Departamento de Gestão e Incorporação de Tecnologias em Saúde. 1st ed. Brasília: Ministério da Saúde; 2023.  
12. Brasil.Ministério da Saúde. Diretrizes Metodológicas: Sistema GRADE - manual de graduaçãp da qualidade da evidência e força de recomendação para tomada de decisão em saúde. 1a ed. Brasília: Editora Ministério da Saúde; 2014. 72p p.  
13. Rimoin DL, Connor JM, Pyeritz RE, Korf BR. Emery and Rimoin’s Principles and Practice of Medical Genetics . Edinburgh, UK.: Churchill Livingstone Elsevier; 2007.  
14. Cassinerio E, Graziadei G, Poggiali E. Gaucher disease: A diagnostic challenge for internists. Eur J Intern Med. 2014 Feb;25(2):117–24.  
25  
15. Zimran A, Gross E, West C, Sorge J, Kubitz M, Beutler E. Prediction of severity of Gaucher’s disease by identification of mutations at DNA level. The Lancet. 1989;334(8659):349–52.  
16. Zimran A, Kay A, Gelbart T, Garver P, Thurston D, Saven A, et al. Gaucher disease. Clinical, laboratory, radiologic, and genetic features of 53 patients. Medicine. 1992;71(6):337–53.  
17. Di Rocco M, Giona F, Carubbi F, Linari S, Minichilli F, Brady RO, et al. A new severity score index for phenotypic classification and evaluation of responses to treatment in type I Gaucher disease. Haematologica. 2008;93(8):1211–8.  
18. Weinreb NJ, Cappellini MD, Cox TM, Giannini EH, Grabowski GA, Hwu WL, et al. A validated disease severity scoring system for adults with type 1 Gaucher disease. Genetics in Medicine. 2010;12(1):44–51.  
19. Kallish S, Kaplan P. A disease severity scoring system for children with type 1 Gaucher disease. Eur J Pediatr. 2013;172:39–43.  
20. Davies EH, Surtees R, DeVile C, Schoon I, Vellodi A. A severity scoring tool to assess the neurological features of neuronopathic Gaucher disease. Journal of Inherited Metabolic Disease: Official Journal of the Society for the Study of Inborn Errors of Metabolism. 2007;30(5):768–82.  
21. Zimran A, Kay A, Gelbart T, Garver P, Thurston D, Saven A, et al. Gaucher disease. Clinical, laboratory, radiologic, and genetic features of 53 patients. Medicine. 1992 Nov;71(6):337–53.  
22. Wallach JB. Interpretation of diagnostic tests. Lippincott Williams & Wilkins; 2007.  
23. Tanner JM, Whitehouse RH. Clinical longitudinal standards for height, weight, height velocity, weight velocity, and stages of puberty. Arch Dis Child. 1976;51(3):170–9.  
24. OMS. http://www.abeso.org.br/pagina/393/curvas-de-crescimento-da-oms-de-2006-e-2007%C2%A0.shtml.  
25. WHO child growth standards 2007.  
26. Setian N, Kuperman H, Della Manna T, Damiani D, Dichtchekenian V. Análise crítica da previsão da altura final. Arquivos Brasileiros de Endocrinologia & Metabologia [Internet]. 2003 Dec [cited 2023 Jun 8];47(6):695–700. Available from: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0004-27302003000600011&lng=pt&tlng=pt  
27. Beutler E. Modern diagnosis and treatment of Gaucher’s disease. American Journal of Diseases of Children. 1993;147(11):1175–83.  
28. Scriver CR. The metabolic & molecular bases of inherited disease. Vol. 4. McGraw-Hill; 2001.  
29. The Merck. Manual of Diagnosis and Therapy. Section 2: Endocrine and Metabolic Disorders. chap.16: Hypolipidemia and Lipidoses. 1999;  
30. Moscicki RA, Taunton-Rigby A. Treatment of Gaucher’s disease. N Engl J Med. 1993;328(21):1564-author.  
31. Mistry P AZ. Type 1 Gaucher Disease. In: Futerman AH, Zimran A. 2007;155–73.  
32. Beutler E, Kuhl W, Matsumoto F, Pangalis G. Acid hydrolases in leukocytes and platelets of normal subjects and in patients with Gaucher’s and Fabry’s disease. J Exp Med. 1976;143(4):975–80.  
33. Beutler E, Kuhl W, Trinidad F, Teplitz R, Nadler H. Beta-glucosidase activity in fibroblasts from homozygotes and heterozygotes for  Gaucher’s disease. Am J Hum Genet. 1971 Jan;23(1):62–6.  
34. Pastores GM. Velaglucerase alfa, a human recombinant glucocerebrosidase enzyme replacement therapy for type 1 Gaucher disease. Curr Opin Investig Drugs. 2010;11(4):472–8.  
35. Pastores GM DAH. Gaucher Disease .  
36. Masson E, Zou WB, Génin E, Cooper DN, Le Gac G, Fichou Y, et al. Expanding ACMG variant classification guidelines into a general framework. Hum Genomics. 2022;16(1):1–15.  
37. Basgalupp SP, Altmann V, Vairo FP e, Schwartz IVD, Siebert M, Cravo R, et al. GBA1 variants in Brazilian Gaucher disease patients. Mol Genet Metab Rep. 2023 Dec;37:101006.  
26  
38. Dardis A, Michelakakis H, Rozenfeld P, Fumic K, Wagner J, Pavan E, et al. Patient centered guidelines for the laboratory diagnosis of Gaucher disease type 1. Orphanet J Rare Dis. 2022 Dec 21;17(1):442.  
39. Kanis JA, Study Group HO. Osteoporosis International WHO Study Document Assessment of Fracture Risk and its Application to Screening for Postmenopausal Osteoporosis: Synopsis of a WHO Report. Vol. 4, Osteoporosis Int. 1994. 40. Baskin E, Dinur T, Lebel E, Tiomkin M, Elstein D, Zimran A. Comparison of Bone Mineral Density by Dual-Energy X-Ray Absorptiometry and Bone Strength by Speed-of-Sound Ultrasonography in Adults With Gaucher Disease. Journal of Clinical Densitometry. 2016 Oct;19(4):465–70.  
41. AERTS JMFG, DONKER‐KOOPMAN WE, VAN DER VLIET MK, JONSSON LMV, GINNS EI, MURRAY GJ, et al. The occurrence of two immunologically distinguishable β‐glucocerebrosidases in human spleen. Eur J Biochem. 1985;150(3):565–74.  
42. Hughes DA PGM. Gaucher Disease [Internet]. GeneReviews® [Internet]. Seattle (WA): University of Washington, Seattle. 2000 [cited 2024 Jun 30]. Available from: https://www.ncbi.nlm.nih.gov/books/NBK1269/ Tell us what you think!Feche  
43. Aerts JMFG, Kallemeijn WW, Wegdam W, Joao Ferraz M, Van Breemen MJ, Dekker N, et al. Biomarkers in the diagnosis of lysosomal storage disorders: Proteins, lipids, and inhibodies. In: Journal of Inherited Metabolic Disease. 2011. p. 605–19.  
44. Hollak CEM, Van Weely S, Van Oers MHJ, Aerts JMFG. Marked elevation of plasma chitotriosidase activity: A novel hallmark of Gaucher disease. Journal of Clinical Investigation. 1994;93(3):1288–92.  
45. Agência Nacional de Vigilância Sanitária A. Guias de Farmacovigilância para Detentores de Registro de Medicamentos. 2010;  
46. van Dussen L, Biegstraaten M, Dijkgraaf MG, Hollak CE. Modelling Gaucher disease progression: long-term enzyme replacement therapy reduces the incidence of splenectomy and bone complications. Orphanet J Rare Dis. 2014 Dec 24;9(1):112.  
47. Pastores GM, Weinreb NJ, Aerts H, Andria G, Cox TM, Giralt M, et al. Therapeutic goals in the treatment of Gaucher disease. Semin Hematol. 2004 Oct;41:4–14.  
48. Weinreb NJ, Cappellini MD, Cox TM, Giannini EH, Grabowski GA, Hwu WL, et al. A validated disease severity scoring system for adults with type 1 Gaucher disease. Genetics in Medicine. 2010 Jan;12(1):44–51.  
49. Pastores GM, Weinreb NJ, Aerts H, Andria G, Cox TM, Giralt M, et al. Therapeutic goals in the treatment of Gaucher disease. In: Seminars in hematology. Elsevier; 2004. p. 4–14.  
50. Brasil. Calendário Nacional de Vacinação [Internet]. 2023 [cited 2023 Jun 23]. Available from: https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/c/calendario-nacional-de-vacinacao  
51. Schiffmann R, FitzGibbon EJ, Harris C, DeVile C, Davies EH, Abel L, et al. Randomized, controlled trial of miglustat in Gaucher’s disease type 3. Annals of Neurology: Official Journal of the American Neurological Association and the Child Neurology Society. 2008;64(5):514–22.  
52. Elstein D, Hadas-Halpern I, Itzchaki M, Lahad A, Abrahamov A. Effect of low-dose enzyme replacement therapy on bones in Gaucher disease patients with severe skeletal involvement. Blood Cells Mol Dis. 1996;22(2):104–11.  
53. Shemesh E, Deroma L, Bembi B, Deegan P, Hollak C, Weinreb NJ, et al. Enzyme replacement and substrate reduction therapy for Gaucher disease. Cochrane Database of Systematic Reviews. 2015 Mar 27;2015(4).  
54. Kishnani PS, DiRocco M, Kaplan P, Mehta A, Pastores GM, Smith SE, et al. A randomized trial comparing the efficacy and safety of imiglucerase (Cerezyme) infusions every 4 weeks versus every 2 weeks in the maintenance therapy of adult patients with Gaucher disease type 1. Mol Genet Metab. 2009 Apr;96(4):164–70.  
27  
55. Leonart LP, Fachi MM, Böger B, Silva MR da, Szpak R, Lombardi NF, et al. A Systematic Review and Metaanalyses of Longitudinal Studies on Drug Treatments for Gaucher Disease. Annals of Pharmacotherapy. 2023 Mar 11;57(3):267–82.  
56. Granovsky-Grisaru S, Belmatoug N, vom Dahl S, Mengel E, Morris E, Zimran A. The management of pregnancy in Gaucher disease. European Journal of Obstetrics & Gynecology and Reproductive Biology. 2011;156(1):3–8.  
57. CERAZYME: imiglucerase. Cambridge (MA-EUA): Genzyme Corporation [bula de medicamento].  
58. UPLYSO: alfataliglicerase. Karmiel (ISR): Protalix Biotherapeutics [bula de medicamento].  
59. VPRIV: alfavelaglicerase. Cambridge (MA-EUA): Shire Human Genetics Therapies Inc. [bula de medicamento].  
60. Elstein D, Hughes D, Goker‐Alpan O, Stivel M, Baris HN, Cohen IJ, et al. Outcome of pregnancies in women receiving velaglucerase alfa for G aucher disease. Journal of Obstetrics and Gynaecology Research. 2014;40(4):968–75.  
61. Sekijima Y, Ohashi T, Ohira S, Kosho T, Fukushima Y. Successful pregnancy and lactation outcome in a patient with Gaucher disease receiving enzyme replacement therapy, and the subsequent distribution and excretion of imiglucerase in human breast milk. Clin Ther. 2010;32(12):2048–52.  
62. Dornelles AD, de Oliveira Netto CB, Vairo F, De Mari JF, Tirelli KM, Schwartz IVD. Breastfeeding in Gaucher disease: is enzyme replacement therapy safe? Clin Ther. 2014;36(6):990–1.  
63. Sanchez-Olle G, Duque J, Egido-Gabas M, Casas J, Lluch M, Chabas A, et al. Promising results of the chaperone effect caused by iminosugars and aminocyclitol derivatives on mutant glucocerebrosidases causing Gaucher disease. Blood Cells Mol Dis. 2009;42(2):159–66.  
64. Zimran A, Brill-Almon E, Chertkoff R, Petakov M, Blanco-Favela F, Muñoz ET, et al. Pivotal trial with plant cell– expressed recombinant glucocerebrosidase, taliglucerase alfa, a novel enzyme replacement therapy for Gaucher disease. Blood. 2011 Nov 24;118(22):5767–73.  
65. “INSTITUTO DE TECNOLOGIA EM IMUNOBIOLÓGICOS  BIO-MANGUINHOS / FIOCRUZ.” BIOMANGUINHOS ALFATALIGLICERASE  (alfataliglicerase). Rio de Janeiro; 2014.  
66. Krug BC, Schwartz I V, Lopes de Oliveira F, Alegra T, Campos Martins NL, Todeschini LA, et al. The management of Gaucher disease in developing countries: A successful experience in Southern Brazil. Public Health Genomics. 2009;13(1):27–33.  
67. Rosenthal DI, Doppelt SH, Mankin HJ, Dambrosia JM, Xavier RJ, McKusick KA, et al. Enzyme replacement therapy for Gaucher disease: skeletal responses to macrophage-targeted glucocerebrosidase. Pediatrics. 1995;96(4):629–37.  
68. Charrow J, Andersson HC, Kaplan P, Kolodny EH, Mistry P, Pastores G, et al. Enzyme replacement therapy and monitoring for children with type 1 Gaucher disease: consensus recommendations. J Pediatr. 2004;144(1):112–20.  
69. Eng CM FHMMT. Genetics; clinical manifestations; and diagnosis of Gaucher disease .  
70. MR R. Drugs facts and comparisons.Comparisons tESLFa, editor 2001. In 2001.  
71. P W. Montvale. Medical Economics Company. 55th Edition . In.  
72. Brunel-Guitton C, Rivard GÉ, Galipeau J, Alos N, Miron MC, Therrien R, et al. Enzyme replacement therapy in pediatric patients with Gaucher disease: What should we use as maintenance dosage? Mol Genet Metab. 2009;96(2):73–6.  
73. Fraile PQ, Hernández EM, García-Silva MT. Clinical outcomes of 2 pediatric patients with Gaucher’s disease in enzyme replacement therapy for 9 years. Med Clin (Barc). 2011;137:43–5.  
74. WHO. Growth reference data for 5-19 years. https://www.who.int/tools/growth-reference-data-for-5to19-years. 2024.  
75. Cox T, Lachmann R, Hollak C, Aerts J, Van Weely S, Hrebícek M, et al. Novel oral treatment of Gaucher’s disease  
- with N-butyldeoxynojirimycin (OGT 918) to decrease substrate biosynthesis. The Lancet. 2000;355(9214):1481–5.  
28  
76. Heitner R, Elstein D, Aerts J, van Weely S, Zimran A. Low-dose N-butyldeoxynojirimycin (OGT 918) for type I Gaucher disease. Blood Cells Mol Dis. 2002;28(2):127–33.  
77. Elstein D, Hollak C, Aerts J, Van Weely S, Maas M, Cox TM, et al. Sustained therapeutic effects of oral miglustat (Zavesca, N‐butyldeoxynojirimycin, OGT 918) in type I Gaucher disease. J Inherit Metab Dis. 2004;27(6):757–66.  
78. Furuya RK, Rossi LA. Programa Educativo com Seguimento por Telefone para pacientes submetidos à intervenção coronária percutânea: ensaio clínico controlado e aleatorizado. Universidade de São Paulo; 2013.  
79. Menezes TM de O, Peixinho Guimarães E, Paulino dos Santos EM, Vasconcelos Nascimento M, Dantas de Araújo P. GRUPO EDUCATIVO COM DISPENSAÇÃO DE MEDICAMENTOS: UMA ESTRATÉGIA DE ADESÃO AO TRATAMENTO DA HIPERTENSÃO ARTERIAL E DO DIABETES MELLITUS. Revista Baiana de Saúde Pública. 2012 Aug 25;36(1):148.  
80. Roquini GR, Avelar NRN, Santos TR, Oliveira MRA de C, Galindo Neto NM, Sousa MRMGC de, et al. CONSTRUÇÃO E VALIDAÇÃO DE CARTILHA EDUCATIVA PARA PROMOÇÃO DA ADESÃO A ANTIDIABÉTICOS ORAIS. Cogitare Enfermagem. 2021 Oct 21;26.  
81. Santos WP dos. Abordagens metodológicas utilizadas em intervenções educativas voltadas a indivíduos com diabetes mellitus. Enfermería actual en Costa Rica. 2020 Jan 14;(38).  
82. Maas M, van Kuijk C, Stoker J, Hollak CEM, Akkerman EM, Aerts JFMG, et al. Quantification of Bone Involvement in Gaucher Disease: MR Imaging Bone Marrow Burden Score as an Alternative to Dixon Quantitative Chemical Shift MR Imaging—Initial Experience. Radiology. 2003 Nov;229(2):554–61.  
83. Di Rocco M, Andria G, Bembi B, Carubbi F, Giona F, Giuffrida G, et al. Minimal disease activity in Gaucher disease: criteria for definition. Mol Genet Metab. 2012;107(3):521–5.  
84. Starzyk K, Richards S, Yee J, Smith SE, Kingma W. The long-term international safety experience of imiglucerase therapy for Gaucher disease. Mol Genet Metab. 2007;90(2):157–63.  
85. Aranda CS, Aun MV, Souza CFM de, Pinto LL de C, Porras-Hurtado GL, Salgado OFS, et al. Hypersensitivity reactions and enzyme replacement therapy: Outcomes and safety of rapid desensitization in 1,008 infusions. J Allergy Clin Immunol Pract. 2022 Mar;10(3):870-873.e1.  
86. Pastores GM, Barnett NL, Kolodny EH. An open-label, noncomparative study of miglustat in type I Gaucher disease: efficacy and tolerability over 24 months of treatment. Clin Ther. 2005;27(8):1215–27.  
87. Giraldo P, Latre P, Alfonso P, Acedo A, Alonso D, Barez A, et al. Short-term effect of miglustat in every day clinical use in treatment-naive or previously treated patients with type 1 Gaucher’s disease. Haematologica. 2006;91(5):703–6.  
88. Janssen-Cilag Farmacêutica Ltda. Bula: Zavesca®. 2022.  
89. Zimran A, Hollak CE, Abrahamov A, Van Oers MH, Kelly M, Beutler E. Home treatment with intravenous enzyme replacement therapy for Gaucher disease: an international collaborative study of 33 patients. 1993;  
90. Hughes DA, Milligan A, Mehta A. Home therapy for lysosomal storage disorders. British Journal of Nursing. 2007;16(22):1384–9.  
91. Milligan A, Hughes D, Goodwin S, Richfield L, Mehta A. Intravenous enzyme replacement therapy: better in home or hospital? British journal of nursing. 2006;15(6):330–3.  
29

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **ALFATALIGLICERASE, IMIGLUCERASE, ALFAVELAGLICERASE E MIGLUSTATE** -->
Eu,___________________________________________________________________________________ (nome  
do paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de alfataliglicerase, imiglucerase, alfavelaglicerase ou miglustate, indicados para o tratamento da Doença de Gaucher.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a)____________________  
____________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora do cansaço (melhora dos quadros de anemia), e dos sangramentos (pela melhora do quadro de  
- trombocitopenia);  
- diminuição do tamanho do fígado e do baço;  
- prevenção de fraturas;  
- melhora da qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
• medicamento imiglucerase: medicamento classificado na gestação como categoria “C”. Isso quer dizer que estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos. Assim, o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos. Portanto, o medicamento não deve ser utilizado por mulheres grávidas sem orientação médica.  
- medicamento alfataliglicerase: medicamento classificado na gestação como categoria “B”. Dados sobre seu uso  
- durante a gravidez são insuficientes e, como regra geral, não devem ser utilizados durante o primeiro trimestre de gravidez. As indicações clínicas devem ser cuidadosamente avaliadas, considerando-se os riscos e benefícios para a gestante.  
- medicamento miglustate: medicamento classificado na gestação como categoria “X”, ou seja, seu uso é altamente  
- inseguro durante a gestação, com risco superando qualquer benefício.  
- os achados sugerem que o uso da alfavelaglicerase é seguro durante a gestação;  
- na amamentação: não se sabe se os medicamentos são excretados no leite materno; portanto, durante a amamentação,  
- o médico deve avaliar se os benefícios são maiores do que os riscos;  
• **eventos adversos mais comuns para imiglucerase e alfavelaglicerase:** dor de cabeça e reações alérgicas (que incluem vermelhidão, coceira, tosse, sensação de formigamento, dor no peito, falta de ar e diminuição da pressão arterial); outros eventos já relatados incluem dor abdominal, sensação de calor, dores nas articulações, tonturas e irritação da pele;  
- **eventos adversos mais comuns para miglustate:** perda de peso, diminuição do apetite, tremores, tonturas, dor de  
- cabeça, cãibras nas pernas, náuseas, vômitos, diarreia, prisão de ventre e gases;  
- **eventos adversos mais comuns para alfataliglicerase:** hipersensibilidade, dor de cabeça e coceira;  
- todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
30  
(    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
(    ) alfataliglicerase   (    ) imiglucerase   (    ) alfavelaglicerase  (    ) miglustate  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
31

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Doença de Gaucher contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos especialistas em Genética e Biologia molecular.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A atualização desse documento foi iniciada em 10 de junho de 2022, com a realização de reuniões de pré-escopo, escopo e priorização das perguntas de pesquisa desse documento.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Colaboração externa -->
O Protocolo foi atualizado pela equipe do Hospital Alemão Oswaldo Cruz.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando  
a Declaração de Potenciais Conflitos de Interesse (Quadro A).  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente|algum dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim|  
32  
||(   ) Não|
|---|---|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de|(   ) Sim|
|alguma tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser<br>afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever<br>e que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa<br>afetar sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados<br>acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Etapas do processo de elaboração -->
A proposta inicial de atualização do PCDT da Doença de Gaucher foi inicialmente discutida durante a reunião de préescopo, ocorrida em 13 de maio de 2022. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS) e Secretaria de Atenção Especializada em Saúde (SAES).  
Posteriormente, o escopo do documento foi discutido na reunião de escopo, ocorrida em 10 de junho de 2022. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da SECTICS e SAES, representantes de pacientes, de sociedades médicas e especialistas convidados.  
33  
Foram elaboradas perguntas PICO para as dúvidas clínicas e tecnologias que necessitariam de avaliação pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Após levantamento inicial das evidências pelo Grupo Elaborador, elas foram apresentadas em reunião ocorrida em 12 de agosto de 2022, com a presença de metodologistas e especialistas do Grupo Elaborador e representantes da SECTICS. A partir das evidências encontradas, as perguntas de pesquisa a serem respondidas foram priorizadas e validadas.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Doença de Gaucher foi apresentada na 116ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em junho de 2024.  A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). A Subcomissão recomendou ajustes no texto do documento.  
Após os ajustes solicitados, a nova proposta de atualização do PCDT da Doença de Gaucher foi apresentada na 117ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em julho de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 19ª Reunião Extraordinária, os quais recomendaram favoravelmente ao texto. Após fase de consulta pública, a deliberação final ocorreu durante a 135ª Reunião Ordinária da Conitec realizada em 06/11/2024.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Consulta pública -->
A Consulta Pública nº 54/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas Para Doença de Gaucher, foi realizada entre os dias 09/09/2024 a 30/09/2024. Foram recebidas 29 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/contribuicao-da-cp-54-de-2024-pcdt-paradoenca-de-gaucher.</u>

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **4. Busca da evidência e recomendações** -->
O processo de atualização desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO **(Figura A)** .  
**Figura A.** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO / PIRO.  
<!-- Start of picture text -->
FP | «Popa ou condi clic<br>‘intervencio, no casode estudos experimentais<br>‘*Fator de exposigio, em caso de estudos observacionais<br>‘Teste indice, nos casos de estudos de acurdcia diagnéstica<br>*Controle, de acordo com tratamento/niveis de exposico do fator/exames<br>disponiveis no SUS<br>‘*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
34  
Durante a reunião de escopo deste PCDT foram definidas duas questões de pesquisa relacionadas ao medicamento eliglustate. Contudo, após a conclusão da síntese de evidências para responder essas perguntas, o medicamento teve seu registro cancelado no Brasil. A seguir, são apresentados os métodos e resultados das buscas para cada uma das questões clínicas.  
**QUESTÃO 1. Qual a relação de eficácia, efetividade e segurança de eliglustate comparado a imiglucerase, alfataliglicerase, alfavelaglicerase, miglustate ou placebo no tratamento de indivíduos adultos com doença de Gaucher**

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **tipo 1 não tratados previamente?** -->
A pergunta foi elaborada segundo o acrônimo PICOS, conforme descrito no **Quadro B** .  
**Quadro B.** Pergunta PICOS (população, intervenção, comparador, “outcomes” [desfechos], “study type” [tipo de estudo]).  
|**População**|Pacientes com diagnóstico de doença de Gaucher tipo 1, não tratados|
|---|---|
|**Intervenção**|Eliglustate|
|**Comparador**|Imiglucerase, alfataliglicerase, alfavelaglicerase, miglustate ou placebo|
|**_Outcomes_**|Primários (críticos):|
|**(desfechos)**|Qualidade de vida|
||Dor|
||Fadiga|
||Eventos adversos graves|
||Secundários (importantes):|
||Densidade mineral óssea (medular, fêmur e coluna lombar)|
||% dos pacientes com estabilidade das variáveis hematológicas (concentração de hemoglobina;<br>contagem de plaquetas)|
||% dos pacientes com estabilidade do volume do fígado e baço (avaliada por RM)<br>Eventos Adversos|
|**Study type (tipo**<br>**de estudo)**|Revisões sistemáticas, Ensaios clínicos randomizados e estudos observacionais comparativos|  
Critérios de elegibilidade

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **População** -->
Foi priorizada a avaliação de estudos envolvendo indivíduos com DG1 não tratados previamente.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Intervenção** -->
A intervenção de interesse foi o eliglustate cápsula que possui registro ativo na Agência Nacional de Vigilância Sanitária (Anvisa)<sup>1</sup> . O Cerdelga® (eliglustate) é um inibidor específico da glicosilceramida sintetase e age como uma terapia de redução do substrato para DG1. O medicamento é indicado para tratamento de longo prazo de pacientes adultos com doença de Gaucher tipo 1. A posologia varia conforme diagnóstico: a posologia para pacientes metabolizadores extensos e intermediários da CYP2D6 é de 100 mg duas vezes ao dia. Já para pacientes metabolizadores pobres, a dose é de 100 mg uma vez ao dia<sup>1</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Comparador** -->
Os comparadores selecionados foram outros medicamentos utilizados como terapia de reposição enzimática (imiglucerase, alfataliglicerase ou alfavelaglicerase) ou inibidores da síntese do substrato (miglustate). Na ausência de estudos contemplando estes comparadores, também foram considerados estudos que compararam o eliglustate com placebo.  
35

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Desfechos** -->
Foram elencados sete desfechos de interesse, conforme definições a seguir:  
Primários (críticos):  
 <u>Qualidade de vida: avaliada pelo questionário SF-36. Para este desfecho foi estabelecida diferença mínima</u>  
<u>clinicamente importante de 2 pontos para o componente físico e 3 pontos para o componente mental</u><sup>2</sup> <u>;</u>  
 <u>Dor: avaliada por meio de escala numérica de 0 (nenhuma dor) a 10 (pior dor). Não foi estabelecida diferença mínima clinicamente importante para este desfecho;</u>  
 <u>Fadiga: avaliada através da escala Fatigue Severity Scale (FSS – escala de gravidade da fadiga) com pontuação que varia de 1 a 7, sendo 1 a pontuação menos grave. Não foi estabelecida diferença mínima clinicamente importante para este desfecho;</u>  
 <u>Eventos adversos (EA) graves: avaliada pelo número de pacientes com eventos adversos graves. Também foi considerada nesta análise a descontinuação do tratamento por evento adverso.</u>  
Secundários (importantes):  
 <u>Densidade mineral óssea (medular, fêmur e coluna lombar): avaliada por densitometria óssea;</u>  
 <u>Porcentagem de pacientes com estabilidade das variáveis hematológicas: avaliada pela concentração de hemoglobina e contagem de plaquetas. Foram considerados estáveis os pacientes que não tiveram queda de hemoglobina maior de 1,5 g/dL ou redução o número de plaquetas maior que 25%</u><sup>3</sup> <u>. Nos estudos em que não foi possível obter o número de pacientes com estabilidade das variáveis hematológicas, foram obtidos os valores de concentração de hemoglobina e contagem de plaquetas.</u>  
 <u>Porcentagem de pacientes com estabilidade do volume do fígado e baço: avaliada por exame de ressonância magnética. Foram considerados estáveis os pacientes com aumento do volume do baço em até 25% e do fígado em até 20%</u> 3. Nos estudos em que não foi possível obter o número de pacientes com estabilidade do volume do fígado e baço, foram <u>coletados os dados referentes aos volumes dos órgãos, conforme relatado nos estudos.</u>  
 <u>Eventos adversos gerais: avaliada pelo número de pacientes com eventos adversos.</u>

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Tipos de estudos** -->
Foram considerados para inclusão revisões sistemáticas, com ou sem meta-análises, ensaios clínicos randomizados (ECR) ou quasi-randomizados. Também foram considerados estudos observacionais comparativos. Não foi feita restrição para data de publicação, idioma, fase do ensaio clínico, para número mínimo de participantes por grupo ou tempo de acompanhamento. Foram excluídas as revisões sistemáticas desatualizadas ou que excluíram estudos relevantes para a presente pergunta devido à restrição do ano de publicação. Adicionalmente, foram excluídos estudos relatados apenas em resumo de congresso.  
Fontes de informações e estratégias de busca

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Termos de busca e bases de dados** -->
Com base na pergunta PICO estruturada acima, foram construídas estratégias de busca utilizando os sinônimos dos termos que englobam a população, intervenção e comparadores. A busca nas bases de dados foi realizada no dia 11 de maio de 2023 por meio do PubMed (Medline), EMBASE e Cochrane Library. Os termos e resultados dessa busca encontram-se no **Quadro C** .  
36  
**Quadro C.** Estratégias de busca de evidências em base de dados  
|**Bases de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|
|MEDLINE<br>via<br>pubmed|**#1**(((((((((((((((((((((((((((((((((((((((((("Gaucher Disease"[MeSH Terms]) OR<br>("Gaucher Disease"[Title/Abstract])) OR ("Disease, Gaucher"[Title/Abstract]))<br>OR ("Glucocerebrosidase Deficiency"[Title/Abstract])) OR ("Glucocerebrosidase<br>Deficiencies"[Title/Abstract])) OR ("Gauchers Disease"[Title/Abstract])) OR<br>("Lipidoses, Glucosyl Cerebroside"[Title/Abstract])) OR ("Lipidosis, Glucosyl<br>Cerebroside"[Title/Abstract])) OR ("Glucosylceramidase<br>Deficiency"[Title/Abstract])) OR ("Glucosylceramide Beta-Glucosidase<br>Deficiency"[Title/Abstract])) OR ("Glucosylceramide Lipidosis"[Title/Abstract]))<br>OR ("Glucosylceramide Lipidoses"[Title/Abstract])) OR ("Lipidoses,<br>Glucosylceramide"[Title/Abstract])) OR ("Lipidosis,<br>Glucosylceramide"[Title/Abstract])) OR ("Kerasin<br>Histiocytosis"[Title/Abstract])) OR ("Gaucher's Disease"[Title/Abstract])) OR<br>("Disease, Gaucher's"[Title/Abstract])) OR ("Disease, Glucocerebrosidase<br>Deficiency"[Title/Abstract])) OR ("Acid beta-Glucosidase<br>Deficiency"[Title/Abstract])) OR ("Gaucher Splenomegaly"[Title/Abstract])) OR<br>("Splenomegaly, Gaucher"[Title/Abstract])) OR ("Gaucher<br>Syndrome"[Title/Abstract])) OR ("Syndrome, Gaucher"[Title/Abstract])) OR<br>("Neuronopathic Gaucher Disease"[Title/Abstract])) OR ("Gaucher Disease,<br>Juvenile"[Title/Abstract])) OR ("Juvenile Gaucher Disease"[Title/Abstract])) OR<br>("Disease, Neuronopathic Gaucher"[Title/Abstract])) OR ("Gaucher Disease,<br>Subacute Neuronopathic Form"[Title/Abstract])) OR ("Gaucher Disease,<br>Subacute Neuronopathic Type"[Title/Abstract])) OR ("Gaucher Disease, Chronic<br>Neuronopathic Type"[Title/Abstract])) OR ("Subacute Neuronopathic Gaucher<br>Disease"[Title/Abstract])) OR ("Gaucher Disease, Type 1"[Title/Abstract])) OR<br>("Gaucher Disease, Chronic"[Title/Abstract])) OR ("GBA<br>Deficiency"[Title/Abstract])) OR ("Type 1 Gaucher Disease"[Title/Abstract])) OR<br>("Gaucher Disease Type 1"[Title/Abstract])) OR ("Gaucher Disease, Type<br>I"[Title/Abstract])) OR ("Chronic Gaucher Disease"[Title/Abstract])) OR ("Non-<br>Neuronopathic Gaucher Disease"[Title/Abstract])) OR ("Non Neuronopathic<br>Gaucher Disease"[Title/Abstract])) OR ("Acute Neuronopathic Gaucher<br>Disease"[Title/Abstract])) OR ("Disease, Infantile Gaucher"[Title/Abstract])) OR<br>("Infantile Gaucher Disease"[Title/Abstract]) (6.307)<br>**#2**((("ELIGLUSTAT"[Supplementary Concept]) OR<br>("ELIGLUSTAT"[Title/Abstract])) OR ("Cerdelga"[Title/Abstract])) OR<br>("eliglustat tartrate"[Title/Abstract]) (130)<br>#3 (("imiglucerase"[Supplementary Concept]) OR<br>("imiglucerase"[Title/Abstract])) OR ("Cerezyme"[Title/Abstract]) (440)|635|  
37  
|**Bases de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|
||#4 (("taliglucerase alfa"[Supplementary Concept]) OR ("taliglucerase<br>alfa"[Title/Abstract])) OR ("elelyso"[Title/Abstract]) (53)<br>#5 ("Velaglucerase alfa, human"[Supplementary Concept]) OR ("Velaglucerase<br>alfa, human"[Title/Abstract]) 59<br>#6 ((((((((((("miglustat"[Supplementary Concept]) OR<br>("miglustat"[Title/Abstract])) OR ("N-(n-butyl)deoxy-<br>nojirimycin"[Title/Abstract])) OR ("n-butyl deoxynojirimycin"[Title/Abstract]))<br>OR ("n-butyldeoxynojirimycin"[Title/Abstract])) OR<br>("butyldeoxynojirimycin"[Title/Abstract])) OR ("N-(n-<br>butyl)deoxynojirimycin"[Title/Abstract])) OR ("SC 48334"[Title/Abstract])) OR<br>("SC-48334"[Title/Abstract])) OR ("Zavesca"[Title/Abstract])) OR ("OGT<br>918"[Title/Abstract])) OR ("OGT-918"[Title/Abstract]) (564)<br>**#7**#2 OR #3 OR #4 OR #5 OR #6 (1094)<br>#1 AND #7 (635)||
|EMBASE|**#1**('gaucher disease'/exp OR 'gaucher disease' OR 'gaucher`s disease' OR<br>'gauchers disease' OR 'cerebral gaucher disease' OR 'cerebroside storage disease'<br>OR 'cerebrosidosis' OR 'glucosylceramidase deficiency syndrome' OR<br>'glucosylceramide lipidosis' OR 'infantile gaucher disease' OR 'juvenile gaucher<br>disease' OR 'kerasinosis' OR 'malignant gaucher disease' OR 'morbus gaucher')<br>AND ('eliglustat'/exp OR 'cerdelga' OR 'eliglustat' OR 'eliglustat hemitartrate' OR<br>'eliglustat tartrate' OR 'genz 112638' OR 'genz 99067' OR 'genz112638' OR<br>'genz99067' OR 'gz 385660' OR 'gz385660' OR 'n [1 (2, 3 dihydro 1, 4<br>benzodioxin 6 yl) 1 hydroxy 3 (pyrrolidin 1 yl) propan 2 yl] octanamide' OR 'n [2<br>(1, 4 benzodioxan 6 yl) 2 hydroxy 1 (1 pyrrolidinylmethyl) ethyl] octanamide' OR<br>'n [2 (2, 3 dihydro 1, 4 benzodioxin 6 yl) 2 hydroxy 1 (1 pyrrolidinylmethyl)<br>ethyl] octanamide' OR 'octanoic acid [2 (2`, 3` dihydrobenzo [1, 4] dioxin 6` yl) 2<br>hydroxy 1 (pyrrolidin 1 ylmethyl) ethyl] amide tartaric acid salt' OR<br>'imiglucerase'/exp OR 'abcertin' OR 'cerezym' OR 'cerezyme' OR 'gnr 008' OR<br>'gnr008' OR 'gz 437843' OR 'gz437843' OR 'imiglucerase' OR 'isu 302' OR<br>'isu302' OR 'recombinant imiglucerase' OR 'taliglucerase alfa'/exp OR<br>'alfataliglicerase' OR 'elelyso' OR 'prx 112' OR 'prx112' OR 'taliglucerase alfa' OR<br>'taliglucerase alpha' OR 'uplyso' OR 'velaglucerase alfa'/exp OR 'human<br>glucosylceramidase glycoform alpha' OR 'human velaglucerase alfa' OR<br>'velaglucerase alfa' OR 'velaglucerase alfa, human' OR 'velaglucerase alpha' OR<br>'vpriv' OR 'miglustat'/exp OR '1 butyl 2 (hydroxymethyl) piperidine 3, 4, 5 triol'<br>OR '1 butyl 2 hydroxymethyl 3, 4, 5 piperidinetriol' OR '1 butylmoranoline' OR<br>'1, 5 dideoxy 1, 5 n butylimino dextro glucitol' OR 'at 2221' OR 'at2221' OR|281|  
38  
|**Bases de**<br>**dados**||**Estratégia de Busca**|**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|---|
||'brazav<br>OR 'sc<br>**#2**#1|es' OR 'miglustat' OR 'n butyldeoxynojirimycin' OR 'ogt 918' OR 'ogt918'<br>48334' OR 'sc48334' OR 'vevesca' OR 'yargesa' OR 'zavesca') (2025)<br>AND [embase]/lim NOT ([embase]/lim AND [medline]/lim) (865)||
||#3 #2|AND ('article'/it OR 'article in press'/it OR 'review'/it) (281)||
|Cochrane|#1|MeSH descriptor: [Gaucher Disease] explode all trees<br>104|10 (Cochrane|
|Library|#2|Disease, Gaucher 228|Reviews)|
||#3|Glucocerebrosidase Deficiency<br>14||
||#4|Deficiencies, Glucocerebrosidase 3||
||#5|Deficiency, Glucocerebrosidase<br>14||
||#6|Glucocerebrosidase Deficiencies 3||
||#7|Gauchers Disease<br>2||
||#8|Disease, Gauchers<br>2||
||#9|Diseases, Gauchers<br>1||
||#10|Gauchers Diseases<br>1||
||#11|Glucosylceramidase Deficiency<br>9||
||#12|Glucosylceramide Beta-Glucosidase Deficiency<br>1||
||#13|Gaucher's Disease<br>228||
||#14|Disease, Gaucher's<br>228||
||#15|Glucocerebrosidase Deficiency Disease<br>14||
||#16|Deficiency Disease, Glucocerebrosidase<br>14||
||#17|Deficiency Diseases, Glucocerebrosidase<br>5||
||#18|Disease, Glucocerebrosidase Deficiency<br>14||
||#19|Diseases, Glucocerebrosidase Deficiency<br>5||
||#20|Glucocerebrosidase Deficiency Diseases<br>5||
||#21|Glucosylceramide Beta-Glucosidase Deficiency Disease<br>1||
||#22|Acid beta-Glucosidase Deficiency Disease 5||
||#23|Acid beta-Glucosidase Deficiency 5||
||#24|Gaucher Splenomegaly<br>26||
||#25|Splenomegaly, Gaucher 26||
||#26|Gaucher Syndrome<br>11||
||#27|Syndrome, Gaucher<br>11||
||#28|Neuronopathic Gaucher Disease<br>5||
||#29|Gaucher Disease, Juvenile 1||
||#30|Disease, Juvenile Gaucher 1||
||#31|Juvenile Gaucher Disease 1||
||#32|Gaucher Disease, Neuronopathic 5||
||#33|Disease, Neuronopathic Gaucher 5||
||#34|Gaucher Disease, Subacute Neuronopathic Form<br>1||  
39  
|**Bases de**<br>**dados**||**Estratégia de Busca**||**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|---|---|
||#35|Gaucher Disease, Subacute Neuronopathic Type|1||
||#36|Gaucher Disease, Chronic Neuronopathic Type|1||
||#37|Subacute Neuronopathic Gaucher Disease 1|||
||#38|Gaucher Disease, Type 1 200|||
||#39|Gaucher Disease, Chronic 9|||
||#40|Gaucher Disease, Non-Neuronopathic Form 2|||
||#41|Gaucher Disease, Non Neuronopathic Form 2|||
||#42|GBA Deficiency 5|||
||#43|Deficiencies, GBA<br>2|||
||#44|Deficiency, GBA 5|||
||#45|GBA Deficiencies<br>2|||
||#46|Type 1 Gaucher Disease 200|||
||#47|Gaucher Disease Type 1 200|||
||#48|Gaucher Disease, Type I 65|||
||#49|Chronic Gaucher Disease 9|||
||#50|Disease, Chronic Gaucher 9|||
||#51|Non-Neuronopathic Gaucher Disease<br>3|||
||#52|Disease, Non-Neuronopathic Gaucher<br>3|||
||#53|Gaucher Disease, Non-Neuronopathic<br>3|||
||#54|Non Neuronopathic Gaucher Disease<br>3|||
||#55|Acute Neuronopathic Gaucher Disease<br>1|||
||#56|Gaucher Disease, Acute Neuronopathic<br>1|||
||#57|Gaucher Disease, Acute Neuronopathic Type|1||
||#58|{OR #1-#57}<br>231|||
||#59|eliglustat<br>68|||
||#60|Cerdelga<br>0|||
||#61|eliglustat tartrate 12|||
||#62|Genz-112638<br>13|||
||#63|{OR #58-#62}<br>233|||
||#64|imiglucerase<br>60|||
||#65|Cerezyme<br>21|||
||#66|{OR #64-#65}<br>67|||
||#67|taliglucerase alfa 31|||
||#68|elelyso 1|||
||#69|{OR #67-#68}<br>31|||
||#70|Velaglucerase alfa, human<br>14|||
||#71|miglustat<br>58|||
||#72|N-(n-butyl)deoxy-nojirimycin<br>2|||  
40  
|**Bases de**<br>**dados**|||**Estratégia de Busca**|**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|---|---|
||#73|n-butyl deoxyn|ojirimycin 2||
||#74|n-butyldeoxyno|jirimycin 1||
||#75|butyldeoxynoji|rimycin<br>1||
||#76|N-(n-butyl)deo|xynojirimycin<br>145||
||#77|SC 48334|3||
||#78|SC-48334|2||
||#79|Zavesca 10|||
||#80|OGT 918|8||
||#81|OGT-918|8||
||#82|{OR #71-#81}|<br>188||
||#83|#63 OR #66 O|R #69 OR #70 OR #82<br>407||
||#84|#58 AND #83|231||
|**Total**||||**926**|  
Fonte: Elaboração própria.  
Foi realizada uma busca no clinicaltrials.gov no dia 23 de maio de 2023 utilizando os termos “Gaucher disease” e “eliglustat” com o intuito de identificar os estudos em andamento sobre eliglustate. Também foi realizada busca manual das referências dos artigos identificados.  
Seleção dos estudos e extração dos dados  
A seleção dos estudos elegíveis, compreendendo as etapas de leitura de título e resumo (triagem) e leitura por texto completo (elegibilidade), foi realizada por um avaliador. Foi utilizado o aplicativo Rayyan para realizar a exclusão das referências duplicadas e a triagem dos estudos em avaliação<sup>4</sup> . A extração dos dados foi realizada por um único avaliador por meio de uma planilha no Microsoft Office Excel® pré-estruturada. Os seguintes dados foram extraídos:  
I. Características dos estudos, intervenções e participantes: autor, ano; país; desenho do estudo; características gerais da população; número de participantes; sexo; alternativas comparadas; duração do tratamento; financiamento.  
II. Desfechos e resultados: na extração dos dados dos desfechos, coletou-se as pontuações médias (média final  
ou média da variação), os desvios-padrão e os tamanhos das amostras dos estudos.  
Avaliação da qualidade metodológica ou risco de viés dos estudos  
A avaliação da qualidade metodológica dos estudos foi realizada por um único avaliador utilizando ferramentas adequadas ao delineamento dos estudos. As revisões sistemáticas foram avaliadas pela ferramenta AMSTAR-2<sup>5</sup> . Já os ensaios clínicos randomizados foram avaliados por meio da ferramenta _Cochrane Risk of Bias Tool – ROB 2.0_<sup>6</sup> . Para estudos observacionais comparativos, a ferramenta ROBINS-I da colaboração Cochrane seria utilizada<sup>7</sup> .  
Síntese e análise dos dados  
As características e resultados dos estudos foram apresentados individualmente de forma narrativa e os resultados foram agrupados por desfecho. Para cada desfecho foi avaliada a homogeneidade entre estudos para considerar a possibilidade de realização de meta-análise direta e indireta.  
As variáveis dicotômicas foram avaliadas pelo número de eventos e de participantes em cada grupo. Foi realizada análise do risco relativo com descrição dos intervalos de confiança (IC). As variáveis contínuas foram analisadas pela média e desvio padrão. Quando possível, a análise comparativa entre os grupos foi realizada pela diferença de média (DM) e IC.  
41  
Apesar de terem sido planejadas meta-análises indiretas ou em rede, nenhuma foi possível, de forma que os métodos destas análises não são apresentados.  
Avaliação da qualidade da evidência  
A certeza no conjunto final da evidência foi avaliada utilizando a ferramenta _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE), sendo classificada como alta, moderada, baixa e muito baixa<sup>8</sup> . A avaliação foi realizada para os desfechos considerados críticos pelos especialistas.  
Resultados  
Foram recuperadas 926 publicações nas bases de dados consultadas, restando 857 após remoção de duplicatas. Após a leitura dos títulos e resumos, 27 registros foram selecionados para leitura na íntegra **(Figura B** ). A busca por ensaios clínicos em andamento não apontou nenhum registro adicional.  
Três revisões sistemáticas foram inicialmente incluídas por atenderem aos critérios de elegibilidade<sup>9-11</sup> . No entanto, uma das revisões foi publicada antes dos estudos sobre eliglustate<sup>11</sup> , outra agrupou dados sobre pacientes previamente tratados e não tratados<sup>10</sup> e outra avaliou os medicamentos de maneira isolada<sup>9</sup> . Por estes motivos, foi feita a opção pela avaliação de estudos individualmente. As revisões foram utilizadas para busca adicional de referências. Nenhum estudo adicional foi incluído por este método.  
Um ensaio clínico e dois estudos de extensão deste estudo foram incluídos. A lista de estudos excluídos e os motivos de exclusão estão detalhados no **Quadro D.**  
42  
**Figura B.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
°<br>Registros identificados: Registros removidos antes da<br>Bases de dados (n =3) selecao:<br>Registros (n = 926 ) Duplicidades removidas (n =69)<br>Registros avaliados Registros excluidos<br>(n = 857) (n =830)<br>Registros para leitura completa Registros nao recuperados<br>(n =27) > (n =0)<br>Registros selecionados para Registros excluidos<br>avaliagdo de elegibilidade ——+| Tipo de estudo inelegivel (n =<br>(n= 27) 13)<br>Comparacao de<br>dose/posologia do mesmo<br>medicamento (n =3 )<br>Populacao inelegivel (n =1)<br>Sem comparacao entre os<br>medicamentos de interesse<br>Estudos ; = (n=5)<br>(n=1) incluidos na revisao. Comparador inelegivel (n=1)<br>Registros dos estudos incluidos Desfecho inelegivel (n=1)<br>(n=3)<br><!-- End of picture text -->  
Fonte: Traduzido e preenchido de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. Mais informações em: http://www.prisma-statement.org/  
43  
**Quadro D.** Estudos excluídos na elegibilidade com os motivos  
|**Autor, ano**|**Motivo**|
|---|---|
|Ben Turkia, 2013<sup>17</sup>|Não houve comparação entre os medicamentos de interesse|
|Connock, 2006<sup>18</sup>|Não houve comparação entre os medicamentos de interesse|
|de Fost, 2007<sup>19</sup>|Comparação de doses diferentes do mesmo medicamento|
|Elstein, 2013<sup>20</sup>|Tipo de estudo inelegível|
|Gonzalez, 2013<sup>21</sup>|Comparação de doses diferentes do mesmo medicamento|
|Grabowski, 1995<sup>22</sup>|Comparador inelegível|
|Ibrahim, 2016<sup>23</sup>|Tipo de estudo inelegível|
|Kuter, 2020<sup>24</sup>|Tipo de estudo inelegível|
|Leonart, 2023<sup>9</sup>|Não houve comparação entre os medicamentos de interesse|
|Lukina, 2010<sup>25</sup>|Tipo de estudo inelegível|
|Morris, 2012<sup>26</sup>|Tipo de estudo inelegível|
|Nabizadeh, 2018<sup>10</sup>|População inelegível (dados dos pacientes não tratados e previamente tratados agrupados)|
|Pastores, 2014<sup>27</sup>|Não houve comparação entre os medicamentos de interesse|
|Peterschmitt, 2018<sup>28</sup>|Tipo de estudo inelegível|
|Peterschmitt, 2019<sup>29</sup>|Tipo de estudo inelegível|
|Rossum, 2016<sup>30</sup>|Tipo de estudo inelegível|
|Shemesh, 2015<sup>11</sup>|Não houve comparação entre os medicamentos de interesse|
|Smid, 2014<sup>31</sup>|Tipo de estudo inelegível|
|Smith, 2016<sup>32</sup>|Tipo de estudo inelegível|
|van Dussen, 2013<sup>33</sup>|Desfecho inelegível|
|Zimran, 2011<sup>34</sup>|Comparação de doses diferentes do mesmo medicamento|
|Zimran, 2016<sup>35</sup>|Tipo de estudo inelegível|
|Zimran, 2018<sup>36</sup>|Tipo de estudo inelegível|
|Zimran, 2018a<sup>38</sup>|Tipo de estudo inelegível|

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Caracterização dos estudos incluídos -->
O estudo ENGAGE incluiu participantes com DG1 sem tratamento com terapia de reposição enzimática ou inibidores da síntese do substrato por 9 e 6 meses antes da randomização, respectivamente. O estudo comparou pacientes que receberam eliglustate na dose de 50 a 100 mg com pacientes que receberam placebo<sup>13</sup> . Após 9 meses, o estudo inicial foi encerrado e os participantes do grupo placebo puderam receber o medicamento. Duas publicações avaliaram os dados do tratamento com eliglustate por até 6 anos<sup>14,15</sup> . As características do estudo estão descritas no **Quadro E** .  
44  
**Quadro E.** Característica dos estudos incluídos.  
|**Autor, ano**<br>**Desenho do**<br>**estudo (NCT)**|**Características gerais da**<br>**população**|**Tempo de**<br>**acompanhamento**|**Alternativas**<br>**comparadas**|**Participantes**|**Financiamento**|**Países**|
|---|---|---|---|---|---|---|
|Mistry, 2015<br>ECR fase III<br>ENGAGE<br>(NCT00891202)|N= 40<br>Pacientes com DG1 não<br>tratados previamente com<br>manifestações clínicas da<br>doença<br>Sexo feminino 50%|9 meses|Eliglustate 50 ou 100mg<br>VO 2 x dia<br>Placebo|eligustate (20)<br>placebo (20)||Bulgária, Canadá,<br>Í|
|Mistry, 2017<br>Extensão de ECR<br>fase III<br>ENGAGE<br>(NCT00891202)|N= 38|18 meses|Eliglustate 50 ou 100mg<br>VO 2 x dia|eliglustate (38)|Genzyme|Colômbia, ndia,<br>Israel, Líbano,<br>México, Rússia,<br>Sérvia, Tunísia,<br>Reino Unido,<br>Estados Unidos|
|Mistry, 2021<br>Extensão de ECR<br>fase III<br>ENGAGE<br>(NCT00891202)|N=34|2, 3 a 6 anos|Eliglustate 50 ou 100mg<br>VO 2 x dia|eliglustate (34)|||  
Fonte: Elaboração própria. Legenda: DG1: doença de Gaucher tipo 1; ECR: ensaio clínico randomizado; VO: via oral.  
45  
Não foram identificados estudos que comparassem as alternativas terapêuticas para tratamento de DG1 com placebo. Desta forma, não foi possível estabelecer comparações diretas ou indiretas entre eliglustate e os demais medicamentos utilizados para DG1.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Avaliação dos estudos incluídos -->
Foi realizada avaliação do risco de viés do estudo ENGAGE para os desfechos considerados críticos<sup>13</sup> . O estudo foi considerado com baixo risco de viés, uma vez que se trata de estudo randomizado duplo-cego ( **Figura C** ).  
**Figura C.** Risco de viés dos estudos incluídos para os desfechos críticos, avaliados pela ferramenta RoB 2.0.  
<!-- Start of picture text -->
Desfechos Weight D1 2 D3 D4 =DS_— Geral.<br>cusicacecevies 1 = @ @ @ @ @ @  @ siiwsxco<br>ber 1 @ OQ @ O© @© SV}_ GB isms preceupacses<br>Fades 1 SOOSVS CO BG eviso<br>D1 Processode randomizacao,<br>D3 Desfecho incompleto<br>Da Mensuracaodo desfecho<br>DS ‘Selec3o de resultados reportados<br><!-- End of picture text -->  
**Fonte:** Elaboração própria. **Legenda** : D: Domínio.  
Síntese dos resultados dos desfechos avaliados  
O **Quadro F** e o **Quadro G** descrevem os resultados obtidos nos estudos quanto aos desfechos críticos e importantes planejados.  
46  
**Quadro F** . Descrição dos desfechos críticos relatados nos estudos incluídos.  
|**Autor,**<br>**ano**|**Qualidade de vida**<br>**(componente físico)**<br>**diferença absoluta (IC)**|**Qualidade de vida**<br>**(componente mental)**<br>**Média (Desvio padrão)**|**Dor (BPI)**<br>**diferença absoluta (IC)**|**Fadiga (FSS)**<br>**diferença absoluta (IC)**|**Número de pacientes com**<br>**eventos adversos graves**|
|---|---|---|---|---|---|
|Mistry,<br>2015|Eliglustate = 0,8 (-1,95 a 3,55)<br>Placebo = -2,5 (-5,19 a 0,16)<br>Diferença = 3,3 (-0,67 a 7,29;<br>p=0,12)|Eliglustate = 1,6 (-1,79 a 5,01)<br>Placebo = 3,8 (0,51 a 7,13)<br>Diferença = -2,2 (-0,71 a 2,59;<br>p=0,36)|Eliglustate = -0,4 (-0,86 a -<br>0,04)<br>Placebo = -0,2 (-0,63 a 0,18)<br>Diferença = -0,2 (-0,81 a 0,36;<br>p=0,52)|Eliglustate = 0,1 (-0,4 a 0,5)<br>Placebo = -0,6 (-1,1 a -0,2)<br>Diferença = 0,7 (0,02 a 1,33;<br>p=0,04)|Eliglustate = 0/20<br>Placebo = 0/20|
|Mistry,<br>2017|NR|NR|NR|NR|Eliglustate = 2/19 (11%)<br>Placebo-eliglustate = 0/20|
|Mistry,<br>2021|NR|NR|NR|NR|5/40 (13%)|  
Fonte: Elaboração própria. Legenda: BPI: Inventário Breve de Dor; EA: evento adverso; FSS: escala de gravidade da fadiga; IC: intervalo de confiança; NR: não relatado.  
47  
**Quadro G** . Descrição dos desfechos importantes relatados nos estudos incluídos.  
|**Autor,**<br>**ano**|**T score (coluna**<br>**lombar)**<br>**Média (desvio**<br>**padrão)**|**T score (fêmur)**<br>**Média (desvio**<br>**padrão)**|**Variação na**<br>**concentração de**<br>**Hemoglobina**<br>**diferença absoluta**<br>**(IC 95%)**|**Variação na**<br>**contagem**<br>**plaquetária**<br>**diferença**<br>**percentual**<br>**(IC 95%)**|**Variação do**<br>**volume do baço**<br>**Diferença**<br>**percentual**<br>**(IC 95%)**|**Variação do**<br>**volume do fígado**<br>**Diferença**<br>**percentual**<br>**(IC 95%)**|**Número de**<br>**pacientes com**<br>**eventos adversos**|
|---|---|---|---|---|---|---|---|
|Mistry,<br>2015|Eliglustate = -1,1<br>(0,8) para -1,0 (0,8)<br>Placebo = -1,1 (1,2)<br>para -1,2 (1,1)<br>DM =1,2 (-0,97 a<br>3,47)|Eliglustate = -0,3<br>(0,8) para -0,3 (0,8)<br>Placebo = -0,5 (1,2)<br>para -0,4 (1,2)<br>DM =-0,1 (-0,3 a<br>0,04)|Eliglustate =<br>0,69g/dL (0,23 a<br>1,14)<br>Placebo = -0,54g/dL<br>(-1 a -0,08)<br>Diferença = 1,22<br>(0,57 a 1,88;<br>p<0,001)|Eliglustate =<br>32%(19,94% a<br>44,06%)<br>Placebo = -9,06% (-<br>21,12% a 3 58,17%)<br>Diferença = 41,06%<br>(23,9%5 a 58,17%;<br>p<0,001)|Eliglustate = -<br>27,77% (-32,57% a<br>-22,97%)<br>Placebo = 2,26% (-<br>2,54% a 7,06%)<br>Diferença = -<br>30,03% (-36,82 a -<br>23,24; p<0,001)|Eliglustate = -5,2%<br>(-8,53% a -1,87%)<br>Placebo = 1,44% (-<br>1,89% a 4,78%)<br>Diferença = -6,64%<br>(-11,37% a -1,91%;<br>p=0,007)|Eliglustate = 18/20<br>(90%), com 137<br>relatos de EA<br>Placebo = 14/20<br>(70%), com 95<br>relatos de EA|
|Mistry,<br>2017|NR|NR|+1,02 g/dL em<br>relação ao basal<br>(NR)|+58% em relação ao<br>basal (NR)|-45% em relação ao<br>basal (NR)|-11% em relação ao<br>basal (NR)|Eliglustate = 15/19<br>(79%)<br>Placebo-eliglustate<br>= 15/20 (75%)|
|Mistry,<br>2021|0,53 (NR)|NR|+1,4g/dL (NR)|+87% (NR)|-66% (NR)|-23% (NR)|90%|  
Fonte: Elaboração própria. Legenda: EA: evento adverso; IC: intervalo de confiança; NR: não relatado; RR: risco relativo.  
48

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Qualidade de vida -->
O estudo ENGAGE avaliou a qualidade de vida dos participantes após 9 meses de tratamento utilizando o questionário SF-36. Não houve diferença entre a qualidade de vida dos pacientes que receberam eliglustate ou placebo, tanto no componente físico (DM 3,3; IC 95% -0,67 a 7,29; p=0,12), quanto no mental (DM -2,2; IC 95% -0,71 a 2,59; p=0,36)<sup>13</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Dor e fadiga -->
Quanto ao desfecho de dor, não houve diferença entre os grupos após 9 meses de tratamento (DM: -0,2; IC 95% -0,81 a 0,36; p=0,52). Já em relação à fadiga, houve benefício estatisticamente significativo no grupo que recebeu eliglustate (DM 0,7; IC 95% 0,02 a 1,33; p=0,04)<sup>13</sup> . No entanto, não foi possível definir _a priori_ qual seria a diferença clinicamente significativa para este desfecho.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Eventos adversos graves -->
Não foram identificados eventos adversos graves durante a fase cega do estudo ENGAGE<sup>13</sup> . Dois eventos adversos graves foram relatados no seguimento de 18 meses<sup>14</sup> . Após 6 anos de acompanhamento, houve um total de cinco eventos adversos graves entre os pacientes que receberam eliglustate<sup>15</sup> . Durante todo o seguimento, não houve descontinuação do tratamento em decorrência de evento adverso.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Alterações hematológicas -->
O desfecho inicialmente previsto era o percentual de pacientes com estabilidade dos parâmetros hematológicos ao final do período do estudo. No entanto, o estudo ENGAGE apresentou os resultados deste desfecho como variável contínua e descrição da alteração média ao longo do tempo. Somente o estudo de extensão descreve o percentual de participantes que atingiram as metas terapêuticas para DG1 ao final do acompanhamento ( **Figura D** )<sup>15</sup> .  
Durante a condução da etapa duplo-cega do estudo houve aumento de 0,69 g/dL na concentração de hemoglobina e de 32% no número de plaquetas entre os pacientes que receberam eliglustate. Já no grupo placebo houve queda de 0,54 g/dL e de 9% na concentração de hemoglobina e contagem de plaquetas, respectivamente (DM <mark>1,22 g/dL; IC 95% 0,57 a 1,88; p<0,001; DM 41,06%; IC 95% 23,9%5 a 58,17%; p<0,001)</mark><sup>13</sup> .  
A **Figura E** apresenta os resultados durante a fase de extensão do estudo, com manutenção do aumento da concentração de hemoglobina e contagem de plaquetas ao longo do tempo.  
**Figura D.** Percentual de pacientes que atingiram as metas terapêuticas para Doença de Gaucher ao final do tratamento com eliglustate.  
<!-- Start of picture text -->
120 Baseline m After 2.5-4.5 years<br>100 100<br>100 1<br>80 10 i 74<br>8 60<br>e<br>40<br>ms 18<br>3<br>Spleen Volume (n= 33) Liver Volume (n=33) Hemoglobin (n=35) Platelets(n =35)<br><!-- End of picture text -->  
Fonte: Mistry, 2021<sup>15</sup> .  
49  
**Figura E.** Alteração na concentração de hemoglobina, no percentual de plaquetas e no percentual dos volumes do baço e fígado durante o tratamento com eliglustate.  
<!-- Start of picture text -->
(A) 28 | 100<br>_ 2 | 80<br>315 L6o<br>£4 Hemoglobin (g/dL) 40 3<br>32 os _‘Spleen volume (MN)ul Loo 2?<br>5 —=—Liver volume (MIN) &<br>zo Platelets x1 07 pos<br>305 | 203<br>5 2<br>6-1 | 403<br>48 608<br>0 06 1 #15 2 25 3 35 4 45 5<br>Years on Eliglustat<br>Patelets n = 40 29 29 8 2 12<br>Hemoglobin n = 40 39 9 8 28 2<br>SpleenLivervolumevolume nn== 4040 3929 828 2 212 8<br><!-- End of picture text -->  
Fonte: Mistry, 2021<sup>15</sup> .  
Alterações do volume do fígado e baço  
O grupo de pacientes que recebeu eliglustate teve redução de 27,7% no volume do baço e de 5,2% no volume do fígado. Já os participantes que receberam placebo, tiveram aumento de 2,26 a 1,44%, respectivamente. As reduções obtidas com uso de eliglustate por 9 meses foram estatisticamente significativas, porém ainda inferiores àquelas consideradas como metas terapêuticas para a DG1<sup>13,16</sup> .  
Segundo a **Figura E** , apenas ao final do tratamento todos os pacientes que permaneceram em seguimento atingiram as metas de redução do tamanho do baço e fígado<sup>15</sup> .  
Alterações ósseas  
Após 9 meses de acompanhamento, não houve diferença entre os participantes que receberam eliglustate ou placebo quanto ao T-escore da coluna lombar ou femoral (DM lombar =1,2; IC 95% -0,97 a 3,47); DM femoral =-0,1; IC 95% -0,3 a 0,04)<sup>13</sup> .  
Durante o período de extensão, houve aumento médio do T-escore ao longo do tratamento com eliglustate ( **Erro! Fonte de referência não encontrada.** F). Houve aumento do T-escore lombar em 27 pacientes (79%); estabilidade em 1 paciente (3%) e diminuição em 6 pacientes (18%)<sup>15</sup> .  
50  
**Figura F.** Alteração das medidas de densidade mineral óssea avaliadas pelo T-escore e Z-escore durante o tratamento com eliglustate.  
<!-- Start of picture text -->
06 —*— Spine T-Score —*— Spine Z-Score<br>04 =-m--FemurT-Score ~-m-- Femur Z-Score T<br>02 .<br>g j. a<br>8 0 . ae eee<br>& 02 j H ee, a ae a<br>é + 04 Bccie ecae ae ‘ Se *-<br>06 : H<br>= 08<br>4 Osteopenic Range<br>12 forT-Score (<-1)<br>14<br>16<br>0 075 15 25 35 45<br>Time on Eliglustat in Years<br>Femur T-Scoren = 24 x 2 a 16 8<br>Femur Z-Scoren= 37 7 3 20 19 8<br>Spine T-Scoren<br>Spine Z-Scoren= = 37 24 7x 353 220 1918 99<br><!-- End of picture text -->  
**Fonte** : Mistry, 2021<sup>15</sup> .  
Incidência de eventos adversos gerais  
Durante a etapa do estudo duplo-cego, 18 (90%) pacientes que receberam eliglustate e 14 (70%) dos pacientes que receberam placebo relataram algum EA. Não houve diferença na ocorrência de EA entre os grupos (RR 1,29; IC 95% 0,93 a 1,77). Os EA mais comuns foram dor de cabeça, artralgia e infecção do trato respiratório superior<sup>13</sup> .  
Avaliação da qualidade da evidência  
A certeza no conjunto final da evidência foi considerada moderada para os desfechos críticos: qualidade de vida, fadiga e dor. A avaliação está descrita no **Quadro H** e o principal motivo de rebaixamento foi a imprecisão.  
51  
**Quadro H.** Avaliação da certeza do conjunto final da evidência pela ferramenta GRADE.  
|||**Avaliação**|**da certeza**|||**№ de pacient**|**es**|**Efeito**||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos estudos/**<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Eliglustate**|**placebo**|**Absoluto**<br>**(IC 95%)**|**Certeza**|
|1 ECR|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|20|20|DM**3,3 mais alto**<br>(0,67 menor para<br>7,29 mais alto)|⨁⨁⨁◯<br>Moderada|
|1 ECR|não<br>grave|não grave|não grave|grave<sup>b</sup>|nenhum|20|20|DM**2,2 menor**<br>(0,71 menor para<br>2,59 mais alto)|⨁⨁⨁◯<br>Moderada|
|1 ECR|não<br>grave|não grave|não grave|grave<sup>c</sup>|nenhum|20|20|DM**0,2 menor**<br>(0,81 menor para<br>0,36 mais alto)|⨁⨁⨁◯<br>Moderada|
|1 ECR|não<br>grave|não grave|grave<sup>c</sup>|nenhum|nenhum|A fadiga foi avalia<br>_Scale_(FSS – escal<br>diferença estatístic<br>que a diferença de<br>clinicamente signif<br>p=0,04).|da pelo questioná<br>a de gravidade da<br>a entre os grupos<br>0,7 favorável ao<br>icativa (DM = 0,|rio_Fatigue Severity_<br>fadiga). Apesar da<br>, não é possível definir<br>eliglustate seja<br>7; IC 95% 0,02 a 1,33;|⨁⨁⨁◯<br>Moderada|  
**Legenda:** ECR: ensaio clínico randomizado; IC: intervalo de confiança.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Alterações hematológicas -->
> a. A diferença no componente físico de qualidade de vida após 12 meses de tratamento e entre o grupo que recebeu eliglustate e placebo não supera os dois pontos para ser considerada diferença mínima clinicamente importante. b. A diferença no componente mental de qualidade de vida após 12 meses de tratamento e entre o grupo que recebeu eliglustate e placebo não supera os três pontos para ser considerada diferença mínima clinicamente importante.  
c. Não é possível avaliar diferença entre os grupos.  
52

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Considerações finais -->
A avaliação da eficácia e segurança do eliglustate em pacientes com DG1 sem tratamento prévio considerou o estudo ENGAGE. Neste estudo, o eliglustate foi comparado a placebo<sup>13</sup> .  
Não foi possível demonstrar superioridade do eliglustate em relação ao placebo na avaliação dos componentes físicos e mentais de qualidade de vida ou no relato de dor. Para a avaliação de fadiga, houve diferença estatisticamente significativa, mas há incerteza em relação ao significado clínico desta diferença. Os benefícios do eliglustate foram demonstrados para os desfechos considerados importantes, com aumento da concentração de hemoglobina, contagem de plaquetas e diminuição do volume do fígado e baço<sup>13</sup> .  
Não foi possível obter comparações indiretas entre o eliglustate e alternativas terapêuticas para DG1 ( <mark>alfataliglicerase, alfavelaglicerase, miglustate), uma vez que somente o estudo ENGAGE possui placebo como controle.</mark> Leonart e colaboradores<sup>9</sup> publicaram recentemente revisão sistemática que aborda a mesma limitação.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **5. REFERÊNCIAS** -->
1.  Sanofi Genzyme. Bula do produto Cerdelga. Waterford, Irlanda; 2021.  
2.  CADTH. CADTH Common Drug Review. Clinical Review Report. Eliglustat [Internet]. 2017 [cited 2023 Jun 4].  
Available from: https://www.cadth.ca/sites/default/files/cdr/clinical/SR0511_Cerdelga_CL_Report_e.pdf  
3.  Cox TM, Drelichman G, Cravo R, Balwani M, Burrow TA, Martins AM, et al. Eliglustat compared with  
imiglucerase in patients with Gaucher’s disease type 1 stabilised on enzyme replacement therapy: a phase 3, randomised, open-label, non-inferiority trial. Lancet [Internet]. 2015 Jun;385(9985):2355–62. Available from:  
https://linkinghub.elsevier.com/retrieve/pii/S0140673614618419  
4.  Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews. Syst Rev [Internet]. 2016 Dec 5;5(1):210. Available from: http://systematicreviewsjournal.biomedcentral.com/articles/10.1186/s13643-016-0384-4  
5.  Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ [Internet]. 2017 Sep 21;j4008. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.j4008  
6.  Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: a revised tool for assessing  
risk of bias in randomised trials. BMJ [Internet]. 2019 Aug 28;l4898. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.l4898  
7.  Sterne JA, Hernán MA, Reeves BC, Savović J, Berkman ND, Viswanathan M, et al. ROBINS-I: a tool for assessing risk of bias in non-randomised studies of interventions. BMJ [Internet]. 2016 Oct 12;i4919. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.i4919  
8.  Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ [Internet]. 2008 Apr 26;336(7650):924–6. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.39489.470347.AD  
9.  Leonart LP, Fachi MM, Böger B, Silva MR da, Szpak R, Lombardi NF, et al. A Systematic Review and Metaanalyses of Longitudinal Studies on Drug Treatments for Gaucher Disease. Ann Pharmacother [Internet]. 2023 Mar 11;57(3):267–82. Available from: http://journals.sagepub.com/doi/10.1177/10600280221108443  
10.  Nabizadeh A, Amani B, Kadivar M, Toroski M, Asl A, Bayazidi Y, et al. The clinical efficacy of imiglucerase versus eliglustat in patients with Gaucher’s disease Type 1: A systematic review. J Res Pharm Pract [Internet]. 2018;7(4):171. Available from: http://www.jrpp.net/text.asp?2018/7/4/171/246986  
53  
11.  Shemesh E, Deroma L, Bembi B, Deegan P, Hollak C, Weinreb NJ, et al. Enzyme replacement and substrate reduction therapy for Gaucher disease. Cochrane Database Syst Rev [Internet]. 2015 Mar 27;2015(4). Available from: http://doi.wiley.com/10.1002/14651858.CD010324.pub2  
12.  Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: An updated guideline for reporting systematic reviews. BMJ. 2021;372.  
13.  Mistry PK, Lukina E, Ben Turkia H, Amato D, Baris H, Dasouki M, et al. Effect of Oral Eliglustat on Splenomegaly in Patients With Gaucher Disease Type 1. JAMA [Internet]. 2015 Feb 17;313(7):695. Available from: http://jama.jamanetwork.com/article.aspx?doi=10.1001/jama.2015.459  
14.  Mistry PK, Lukina E, Ben Turkia H, Shankar SP, Baris H, Ghosn M, et al. Outcomes after 18 months of eliglustat therapy in treatment-naïve adults with Gaucher disease type 1: The phase 3 ENGAGE trial. Am J Hematol [Internet]. 2017 Nov;92(11):1170–6. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.24877  
15.  Mistry PK, Lukina E, Ben Turkia H, Shankar SP, Feldman H, Ghosn M, et al. Clinical outcomes after 4.5 years of eliglustat therapy for <scp>Gaucher</scp> disease type 1: Phase 3 <scp>ENGAGE</scp> trial final results. Am J Hematol [Internet]. 2021 Sep 11;96(9):1156–65. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.26276  
16.  Pastores GM, Weinreb NJ, Aerts H, Andria G, Cox TM, Giralt M, et al. Therapeutic goals in the treatment of Gaucher disease. Semin Hematol [Internet]. 2004 Oct;41:4–14. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0037196304001325  
17.  Turkia H Ben, Gonzalez DE, Barton NW, Zimran A, Kabra M, Lukina EA, et al. Velaglucerase alfa enzyme replacement therapy compared with imiglucerase in patients with Gaucher disease. Am J Hematol [Internet]. 2013 Mar;88(3):179–84. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.23382  
18.  Connock M, Burls A, Frew E, Fry-Smith A, Juarez-Garcia A, McCabe C, et al. The clinical effectiveness and cost-effectiveness of enzyme replacement therapy for Gaucher’s disease: a systematic review. Health Technol Assess (Rockv) [Internet]. 2006 Jul;10(24). Available from: https://www.journalslibrary.nihr.ac.uk/hta/hta10240/  
19.  de Fost M, Aerts JMFG, Groener JEM, Maas M, Akkerman EM, Wiersma MG, et al. Low frequency maintenance therapy with imiglucerase in adult type I Gaucher disease: a prospective randomized controlled trial. Haematologica [Internet]. 2007 Feb 1;92(2):215–21. Available from: http://www.haematologica.org/cgi/doi/10.3324/haematol.10635  
20.  Elstein D, Zimran A. Safety and efficacy of velaglucerase alfa replacement therapy for patients with type 1 Gaucher disease. Expert Rev Endocrinol Metab [Internet]. 2013 Jul 10;8(4):333–9. Available from: http://www.tandfonline.com/doi/full/10.1586/17446651.2013.811871  
21.  Gonzalez DE, Turkia H Ben, Lukina EA, Kisinovsky I, Dridi M-F Ben, Elstein D, et al. Enzyme replacement therapy with velaglucerase alfa in Gaucher disease: Results from a randomized, double-blind, multinational, Phase 3 study. Am J Hematol [Internet]. 2013 Mar;88(3):166–71. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.23381  
22.  Grabowski GA. Enzyme Therapy in Type 1 Gaucher Disease: Comparative Efficacy of Mannose-Terminated Glucocerebrosidase from Natural and Recombinant Sources. Ann Intern Med [Internet]. 1995 Jan 1;122(1):33. Available from: http://annals.org/article.aspx?doi=10.7326/0003-4819-122-1-199501010-00005  
23.  Ibrahim J, Underhill LH, Taylor JS, Angell J, Peterschmitt MJ. Clinical response to eliglustat in treatment-naïve patients with Gaucher disease type 1: Post-hoc comparison to imiglucerase-treated patients enrolled in the International Collaborative Gaucher Group Gaucher Registry. Mol Genet Metab Reports [Internet]. 2016 Sep;8:17–9. Available from: https://linkinghub.elsevier.com/retrieve/pii/S2214426916300428  
24.  Kuter DJ, Wajnrajch M, Hernandez B, Wang R, Chertkoff R, Zimran A. Open-label, expanded access study of taliglucerase alfa in patients with Gaucher disease requiring enzyme replacement therapy. Blood Cells, Mol Dis [Internet].  
54  
2020 May;82:102418. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979620300668  
25.  Lukina E, Watman N, Arreguin EA, Banikazemi M, Dragosky M, Iastrebner M, et al. A phase 2 study of eliglustat tartrate (Genz-112638), an oral substrate reduction therapy for Gaucher disease type 1. Blood [Internet]. 2010 Aug 12;116(6):893–9. Available from: https://ashpublications.org/blood/article/116/6/893/27645/A-phase-2-study-of-eliglustattartrate-Genz112638  
26.  Morris JL. Velaglucerase Alfa for the Management of Type 1 Gaucher Disease. Clin Ther [Internet]. 2012 Feb;34(2):259–71. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0149291811008873  
27.  Pastores GM, Rosenbloom B, Weinreb N, Goker-Alpan O, Grabowski G, Cohn GM, et al. A multicenter openlabel treatment protocol (HGT-GCB-058) of velaglucerase alfa enzyme replacement therapy in patients with Gaucher disease type 1: safety and tolerability. Genet Med [Internet]. 2014 May;16(5):359–66. Available from: https://linkinghub.elsevier.com/retrieve/pii/S109836002104822X  
28.  Peterschmitt MJ, Cox GF, Ibrahim J, MacDougall J, Underhill LH, Patel P, et al. A pooled analysis of adverse events in 393 adults with Gaucher disease type 1 from four clinical trials of oral eliglustat: Evaluation of frequency, timing, and duration. Blood Cells, Mol Dis [Internet]. 2018 Feb;68:185–91. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979617300256  
29.  Peterschmitt MJ, Freisens S, Underhill LH, Foster MC, Lewis G, Gaemers SJM. Long-term adverse event profile from four completed trials of oral eliglustat in adults with Gaucher disease type 1. Orphanet J Rare Dis [Internet]. 2019 Dec 7;14(1):128. Available from: https://ojrd.biomedcentral.com/articles/10.1186/s13023-019-1085-6  
30.  Van Rossum A, Holsopple M. Enzyme Replacement or Substrate Reduction? A Review of Gaucher Disease Treatment Options. Hosp Pharm [Internet]. 2016 Jul 1;51(7):553–63. Available from: http://journals.sagepub.com/doi/10.1310/hpj5107-553  
31.  Smid BE, Hollak CE. A systematic review on effectiveness and safety of eliglustat for type 1 Gaucher disease. Expert Opin Orphan Drugs [Internet]. 2014 May 24;2(5):523–9. Available from: http://www.tandfonline.com/doi/full/10.1517/21678707.2014.899148  
32.  Smith L, Rhead W, Charrow J, Shankar SP, Bavdekar A, Longo N, et al. Long-term velaglucerase alfa treatment in children with Gaucher disease type 1 naïve to enzyme replacement therapy or previously treated with imiglucerase. Mol Genet Metab [Internet]. 2016 Feb;117(2):164–71. Available from:  
https://linkinghub.elsevier.com/retrieve/pii/S1096719215300172  
33.  van Dussen L, Zimran A, Akkerman EM, Aerts JMFG, Petakov M, Elstein D, et al. Taliglucerase alfa leads to favorable bone marrow responses in patients with type I Gaucher disease. Blood Cells, Mol Dis [Internet]. 2013 Mar;50(3):206–11. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979612001970  
34.  Zimran A, Brill-Almon E, Chertkoff R, Petakov M, Blanco-Favela F, Muñoz ET, et al. Pivotal trial with plant cell–expressed recombinant glucocerebrosidase, taliglucerase alfa, a novel enzyme replacement therapy for Gaucher disease. Blood [Internet]. 2011 Nov 24;118(22):5767–73. Available from: https://ashpublications.org/blood/article/118/22/5767/29159/Pivotal-trial-with-plant-cellexpressed-recombinant  
35.  Zimran A, Gonzalez-Rodriguez DE, Abrahamov A, Cooper PA, Varughese S, Giraldo P, et al. Long-term safety and efficacy of taliglucerase alfa in pediatric Gaucher disease patients who were treatment-naïve or previously treated with imiglucerase. Blood Cells, Mol Dis [Internet]. 2018 Feb;68:163–72. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979616302212  
36.  Zimran A, Dinur T, Revel-Vilk S, Akkerman EM, van Dussen L, Hollak CEM, et al. Improvement in bone marrow infiltration in patients with type I Gaucher disease treated with taliglucerase alfa. J Inherit Metab Dis [Internet]. 2018 Dec;41(6):1259–65. Available from: http://doi.wiley.com/10.1007/s10545-018-0195-y  
55  
37.  Zimran A, Elstein D, Gonzalez DE, Lukina EA, Qin Y, Dinh Q, et al. Treatment-naïve Gaucher disease patients achieve therapeutic goals and normalization with velaglucerase alfa by 4 years in phase 3 trials. Blood Cells, Mol Dis [Internet]. 2018 Feb;68:153–9. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979616301905  
**Qual a relação de eficácia, efetividade e segurança de eliglustate comparado a imiglucerase, alfataliglicerase, alfavelaglicerase, miglustate ou placebo no tratamento de indivíduos adultos com doença de Gaucher tipo 1**

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **previamente tratados?** -->
A pergunta foi elaborada segundo o acrônimo PICOS, conforme descrito no **Quadro I.**  
**Quadro I.** Pergunta PICOS (população, intervenção, comparador, “outcomes” [desfechos], “study type” [tipo de estudo]).  
|**População**|Indivíduos com diagnóstico de doença de Gaucher tipo 1 previamente tratados|
|---|---|
|**Intervenção**|Eliglustate|
|**Comparador**|Imiglucerase, alfataliglicerase, alfavelaglicerase, miglustate ou placebo|
|**_Outcomes_ (desfechos)**|Primários (críticos):|
||Qualidade de vida|
||Dor|
||Fadiga|
||Eventos adversos graves|
||Secundários (importantes):|
||Densidade mineral óssea (medular, fêmur e coluna lombar)<br>% dos pacientes com estabilidade das variáveis hematológicas (concentração de<br>hemoglobina; contagem de plaquetas)<br>% dos pacientes com estabilidade do volume do fígado e baço (avaliada por RM)<br>Eventos Adversos|
|**_Study type_**<br>**(tipo de estudo)**|Revisões sistemáticas, Ensaios clínicos randomizados e estudos observacionais<br>comparativos|  
Critérios de elegibilidade

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **População** -->
Foi priorizada a avaliação de estudos envolvendo indivíduos com DG1 previamente tratados.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Intervenção** -->
A intervenção de interesse foi o eliglustate cápsula que possui registro ativo na Agência Nacional de Vigilância Sanitária (Anvisa)<sup>1</sup> e é um inibidor específico da glicosilceramida sintetase e age como uma terapia de redução do substrato para DG1. O medicamento é indicado para tratamento de longo prazo de pacientes adultos com DG1. A posologia varia conforme a capacidade de metabolização da CYP2D6: a posologia para pacientes metabolizadores extensos e intermediários da CYP2D6 é de 100 mg duas vezes ao dia. Já para pacientes metabolizadores pobres, a dose é de 100 mg uma vez ao dia<sup>1</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Comparador** -->
Os comparadores selecionados foram outros medicamentos utilizados como terapia de reposição enzimática (imiglucerase, alfataliglicerase ou alfavelaglicerase) ou inibidores da síntese do substrato (miglustate). Na ausência de estudos contemplando estes comparadores, também foram considerados estudos que compararam o eliglustate com placebo.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Desfechos** -->
Foram elencados oito desfechos de interesse:  
56  
_Primários (críticos):_  
 <u>Qualidade de vida:</u> avaliada pelo questionário SF-36. Para este desfecho foi estabelecida diferença mínima clinicamente importante de 2 pontos para o componente físico e 3 pontos para o componente mental<sup>2</sup> ;  
 <u>Dor: avaliada por meio de escala numérica de 0 (nenhuma dor) a 10 (pior dor). Não foi estabelecida diferença</u> mínima clinicamente importante para este desfecho;  
 <u>Fadiga: avaliada através da escala</u> _Fatigue Severity Scale_ (FSS – escala de gravidade da fadiga) com pontuação que varia de 1 a 7, sendo 1 a pontuação menos grave. Não foi estabelecida diferença mínima clinicamente importante para este desfecho;  
 <u>Eventos adversos (EA) graves: avaliada pelo número de pacientes com eventos adversos graves. Também foi</u> considerada nesta análise a descontinuação do tratamento por evento adverso.  
_Secundários (importantes):_  
 <u>Densidade mineral óssea (medular, fêmur e coluna lombar): avaliada pela densitometria óssea;</u>  
 <u>Porcentagem de pacientes com estabilidade das variáveis hematológicas:</u> avaliada pela concentração de hemoglobina e contagem de plaquetas. Foram considerados estáveis os pacientes que não tiveram queda de hemoglobina maior de 1,5 g/dL ou redução o número de plaquetas maior que 25%<sup>3</sup> . Nos estudos em que não foi possível obter o número de pacientes com estabilidade das variáveis hematológicas, foram obtidos os valores de concentração de hemoglobina e contagem de plaquetas.  
 <u>Porcentagem de pacientes com estabilidade do volume do fígado e baço:</u> avaliada por exame de ressonância magnética. Foram considerados estáveis os pacientes com aumento do volume do baço em até 25% e do fígado em até 20% 3. Nos estudos em que não foi possível obter o número de pacientes com estabilidade do volume do fígado e baço, foram coletados os dados referentes aos volumes dos órgãos, conforme relatado nos estudos.  
 <u>Eventos adversos gerais: avaliada pelo número de pacientes com eventos adversos.</u>

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Tipos de estudos** -->
Foram considerados para inclusão revisões sistemáticas, com ou sem meta-análises, ensaios clínicos randomizados (ECR) ou quasi-randomizados. Também foram considerados estudos observacionais comparativos. Não foi feita restrição para data de publicação, idioma, fase do ensaio clínico, para número de participantes por grupo ou tempo de acompanhamento. Foram excluídas as revisões sistemáticas desatualizadas ou que excluíram estudos relevantes para a presente pergunta devido à restrição do ano de publicação. Adicionalmente, foram excluídos estudos relatados apenas em resumo de congresso.  
Fontes de informações e estratégias de busca

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Termos de busca e bases de dados** -->
Com base na pergunta PICO estruturada acima, foram construídas estratégias de busca utilizando os sinônimos dos termos que englobam a população, intervenção e comparadores. A busca nas bases de dados foi realizada no dia 11 de maio de 2023 por meio do PubMed (Medline), EMBASE e Cochrane Library. Os termos e resultados dessa busca encontram-se no **Quadro J** .  
57  
**Quadro J.** Estratégias de busca de evidências em bases de dados  
|**Bases de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|
|MEDLINE<br>via<br>pubmed|**#1**(((((((((((((((((((((((((((((((((((((((((("Gaucher Disease"[MeSH Terms]) OR<br>("Gaucher Disease"[Title/Abstract])) OR ("Disease, Gaucher"[Title/Abstract]))<br>OR ("Glucocerebrosidase Deficiency"[Title/Abstract])) OR ("Glucocerebrosidase<br>Deficiencies"[Title/Abstract])) OR ("Gauchers Disease"[Title/Abstract])) OR<br>("Lipidoses, Glucosyl Cerebroside"[Title/Abstract])) OR ("Lipidosis, Glucosyl<br>Cerebroside"[Title/Abstract])) OR ("Glucosylceramidase<br>Deficiency"[Title/Abstract])) OR ("Glucosylceramide Beta-Glucosidase<br>Deficiency"[Title/Abstract])) OR ("Glucosylceramide Lipidosis"[Title/Abstract]))<br>OR ("Glucosylceramide Lipidoses"[Title/Abstract])) OR ("Lipidoses,<br>Glucosylceramide"[Title/Abstract])) OR ("Lipidosis,<br>Glucosylceramide"[Title/Abstract])) OR ("Kerasin<br>Histiocytosis"[Title/Abstract])) OR ("Gaucher's Disease"[Title/Abstract])) OR<br>("Disease, Gaucher's"[Title/Abstract])) OR ("Disease, Glucocerebrosidase<br>Deficiency"[Title/Abstract])) OR ("Acid beta-Glucosidase<br>Deficiency"[Title/Abstract])) OR ("Gaucher Splenomegaly"[Title/Abstract])) OR<br>("Splenomegaly, Gaucher"[Title/Abstract])) OR ("Gaucher<br>Syndrome"[Title/Abstract])) OR ("Syndrome, Gaucher"[Title/Abstract])) OR<br>("Neuronopathic Gaucher Disease"[Title/Abstract])) OR ("Gaucher Disease,<br>Juvenile"[Title/Abstract])) OR ("Juvenile Gaucher Disease"[Title/Abstract])) OR<br>("Disease, Neuronopathic Gaucher"[Title/Abstract])) OR ("Gaucher Disease,<br>Subacute Neuronopathic Form"[Title/Abstract])) OR ("Gaucher Disease,<br>Subacute Neuronopathic Type"[Title/Abstract])) OR ("Gaucher Disease, Chronic<br>Neuronopathic Type"[Title/Abstract])) OR ("Subacute Neuronopathic Gaucher<br>Disease"[Title/Abstract])) OR ("Gaucher Disease, Type 1"[Title/Abstract])) OR<br>("Gaucher Disease, Chronic"[Title/Abstract])) OR ("GBA<br>Deficiency"[Title/Abstract])) OR ("Type 1 Gaucher Disease"[Title/Abstract])) OR<br>("Gaucher Disease Type 1"[Title/Abstract])) OR ("Gaucher Disease, Type<br>I"[Title/Abstract])) OR ("Chronic Gaucher Disease"[Title/Abstract])) OR ("Non-<br>Neuronopathic Gaucher Disease"[Title/Abstract])) OR ("Non Neuronopathic<br>Gaucher Disease"[Title/Abstract])) OR ("Acute Neuronopathic Gaucher<br>Disease"[Title/Abstract])) OR ("Disease, Infantile Gaucher"[Title/Abstract])) OR<br>("Infantile Gaucher Disease"[Title/Abstract]) (6.307)<br>**#2**((("ELIGLUSTAT"[Supplementary Concept]) OR<br>("ELIGLUSTAT"[Title/Abstract])) OR ("Cerdelga"[Title/Abstract])) OR<br>("eliglustat tartrate"[Title/Abstract]) (130)<br>#3 (("imiglucerase"[Supplementary Concept]) OR<br>("imiglucerase"[Title/Abstract])) OR ("Cerezyme"[Title/Abstract]) (440)|635|  
58  
|**Bases de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|
||#4 (("taliglucerase alfa"[Supplementary Concept]) OR ("taliglucerase<br>alfa"[Title/Abstract])) OR ("elelyso"[Title/Abstract]) (53)<br>#5 ("Velaglucerase alfa, human"[Supplementary Concept]) OR ("Velaglucerase<br>alfa, human"[Title/Abstract]) 59<br>#6 ((((((((((("miglustat"[Supplementary Concept]) OR<br>("miglustat"[Title/Abstract])) OR ("N-(n-butyl)deoxy-<br>nojirimycin"[Title/Abstract])) OR ("n-butyl deoxynojirimycin"[Title/Abstract]))<br>OR ("n-butyldeoxynojirimycin"[Title/Abstract])) OR<br>("butyldeoxynojirimycin"[Title/Abstract])) OR ("N-(n-<br>butyl)deoxynojirimycin"[Title/Abstract])) OR ("SC 48334"[Title/Abstract])) OR<br>("SC-48334"[Title/Abstract])) OR ("Zavesca"[Title/Abstract])) OR ("OGT<br>918"[Title/Abstract])) OR ("OGT-918"[Title/Abstract]) (564)<br>**#7**#2 OR #3 OR #4 OR #5 OR #6 (1094)<br>#1 AND #7 (635)||
|EMBASE|**#1**('gaucher disease'/exp OR 'gaucher disease' OR 'gaucher`s disease' OR<br>'gauchers disease' OR 'cerebral gaucher disease' OR 'cerebroside storage disease'<br>OR 'cerebrosidosis' OR 'glucosylceramidase deficiency syndrome' OR<br>'glucosylceramide lipidosis' OR 'infantile gaucher disease' OR 'juvenile gaucher<br>disease' OR 'kerasinosis' OR 'malignant gaucher disease' OR 'morbus gaucher')<br>AND ('eliglustat'/exp OR 'cerdelga' OR 'eliglustat' OR 'eliglustat hemitartrate' OR<br>'eliglustat tartrate' OR 'genz 112638' OR 'genz 99067' OR 'genz112638' OR<br>'genz99067' OR 'gz 385660' OR 'gz385660' OR 'n [1 (2, 3 dihydro 1, 4<br>benzodioxin 6 yl) 1 hydroxy 3 (pyrrolidin 1 yl) propan 2 yl] octanamide' OR 'n [2<br>(1, 4 benzodioxan 6 yl) 2 hydroxy 1 (1 pyrrolidinylmethyl) ethyl] octanamide' OR<br>'n [2 (2, 3 dihydro 1, 4 benzodioxin 6 yl) 2 hydroxy 1 (1 pyrrolidinylmethyl)<br>ethyl] octanamide' OR 'octanoic acid [2 (2`, 3` dihydrobenzo [1, 4] dioxin 6` yl) 2<br>hydroxy 1 (pyrrolidin 1 ylmethyl) ethyl] amide tartaric acid salt' OR<br>'imiglucerase'/exp OR 'abcertin' OR 'cerezym' OR 'cerezyme' OR 'gnr 008' OR<br>'gnr008' OR 'gz 437843' OR 'gz437843' OR 'imiglucerase' OR 'isu 302' OR<br>'isu302' OR 'recombinant imiglucerase' OR 'taliglucerase alfa'/exp OR<br>'alfataliglicerase' OR 'elelyso' OR 'prx 112' OR 'prx112' OR 'taliglucerase alfa' OR<br>'taliglucerase alpha' OR 'uplyso' OR 'velaglucerase alfa'/exp OR 'human<br>glucosylceramidase glycoform alpha' OR 'human velaglucerase alfa' OR<br>'velaglucerase alfa' OR 'velaglucerase alfa, human' OR 'velaglucerase alpha' OR<br>'vpriv' OR 'miglustat'/exp OR '1 butyl 2 (hydroxymethyl) piperidine 3, 4, 5 triol'<br>OR '1 butyl 2 hydroxymethyl 3, 4, 5 piperidinetriol' OR '1 butylmoranoline' OR<br>'1, 5 dideoxy 1, 5 n butylimino dextro glucitol' OR 'at 2221' OR 'at2221' OR<br>'brazaves' OR 'miglustat' OR 'n butyldeoxynojirimycin' OR 'ogt 918' OR 'ogt918'<br>OR 'sc 48334' OR 'sc48334' OR 'vevesca' OR 'yargesa' OR 'zavesca') (2025)|281|  
59  
|**Bases de**<br>**dados**||**Estratégia de Busca**||**Número de**<br>**Artigos**<br>**Recuperados**|
|---|---|---|---|---|
||**#2**#1|AND [embase]/lim NOT ([embase]/lim AND [medline]/lim) (|865)||
||#3 #2|AND ('article'/it OR 'article in press'/it OR 'review'/it) (281)|||
|Cochrane|#1|MeSH descriptor: [Gaucher Disease] explode all trees|104|10 (Cochrane|
|Library|#2|Disease, Gaucher 228||Reviews)|
||#3|Glucocerebrosidase Deficiency<br>14|||
||#4|Deficiencies, Glucocerebrosidase 3|||
||#5|Deficiency, Glucocerebrosidase<br>14|||
||#6|Glucocerebrosidase Deficiencies 3|||
||#7|Gauchers Disease<br>2|||
||#8|Disease, Gauchers<br>2|||
||#9|Diseases, Gauchers<br>1|||
||#10|Gauchers Diseases<br>1|||
||#11|Glucosylceramidase Deficiency<br>9|||
||#12|Glucosylceramide Beta-Glucosidase Deficiency<br>1|||
||#13|Gaucher's Disease<br>228|||
||#14|Disease, Gaucher's<br>228|||
||#15|Glucocerebrosidase Deficiency Disease<br>14|||
||#16|Deficiency Disease, Glucocerebrosidase<br>14|||
||#17|Deficiency Diseases, Glucocerebrosidase<br>5|||
||#18|Disease, Glucocerebrosidase Deficiency<br>14|||
||#19|Diseases, Glucocerebrosidase Deficiency<br>5|||
||#20|Glucocerebrosidase Deficiency Diseases<br>5|||
||#21|Glucosylceramide Beta-Glucosidase Deficiency Disease|1||
||#22|Acid beta-Glucosidase Deficiency Disease 5|||
||#23|Acid beta-Glucosidase Deficiency 5|||
||#24|Gaucher Splenomegaly<br>26|||
||#25|Splenomegaly, Gaucher 26|||
||#26|Gaucher Syndrome<br>11|||
||#27|Syndrome, Gaucher<br>11|||
||#28|Neuronopathic Gaucher Disease<br>5|||
||#29|Gaucher Disease, Juvenile 1|||
||#30|Disease, Juvenile Gaucher 1|||
||#31|Juvenile Gaucher Disease 1|||
||#32|Gaucher Disease, Neuronopathic 5|||
||#33|Disease, Neuronopathic Gaucher 5|||
||#34|Gaucher Disease, Subacute Neuronopathic Form<br>1|||
||#35|Gaucher Disease, Subacute Neuronopathic Type<br>1|||
||#36|Gaucher Disease, Chronic Neuronopathic Type<br>1|||
||#37|Subacute Neuronopathic Gaucher Disease 1|||  
60  
|**Bases de**<br>**dd**||**Estratégia de Busca**|**Número de**<br>**Artigos**|
|---|---|---|---|
|**aos**|||**Recuperados**|
||#38|Gaucher Disease, Type 1 200||
||#39|Gaucher Disease, Chronic 9||
||#40|Gaucher Disease, Non-Neuronopathic Form 2||
||#41|Gaucher Disease, Non Neuronopathic Form 2||
||#42|GBA Deficiency 5||
||#43|Deficiencies, GBA<br>2||
||#44|Deficiency, GBA 5||
||#45|GBA Deficiencies<br>2||
||#46|Type 1 Gaucher Disease 200||
||#47|Gaucher Disease Type 1 200||
||#48|Gaucher Disease, Type I 65||
||#49|Chronic Gaucher Disease 9||
||#50|Disease, Chronic Gaucher 9||
||#51|Non-Neuronopathic Gaucher Disease<br>3||
||#52|Disease, Non-Neuronopathic Gaucher<br>3||
||#53|Gaucher Disease, Non-Neuronopathic<br>3||
||#54|Non Neuronopathic Gaucher Disease<br>3||
||#55|Acute Neuronopathic Gaucher Disease<br>1||
||#56|Gaucher Disease, Acute Neuronopathic<br>1||
||#57|Gaucher Disease, Acute Neuronopathic Type<br>1||
||#58|{OR #1-#57}<br>231||
||#59|eliglustat<br>68||
||#60|Cerdelga<br>0||
||#61|eliglustat tartrate 12||
||#62|Genz-112638<br>13||
||#63|{OR #58-#62}<br>233||
||#64|imiglucerase<br>60||
||#65|Cerezyme<br>21||
||#66|{OR #64-#65}<br>67||
||#67|taliglucerase alfa 31||
||#68|elelyso 1||
||#69|{OR #67-#68}<br>31||
||#70|Velaglucerase alfa, human<br>14||
||#71|miglustat<br>58||
||#72|N-(n-butyl)deoxy-nojirimycin<br>2||
||#73|n-butyl deoxynojirimycin 2||
||#74|n-butyldeoxynojirimycin 1||
||#75|butyldeoxynojirimycin<br>1||
||#76|N-(n-butyl)deoxynojirimycin<br>145||  
61  
|**Bases de**||||**Número de**<br>|
|---|---|---|---|---|
|**dados**|||**Estratégia de Busca**|**Artigos**|
|||||**Recuperados**|
||#77|SC 48334|3||
||#78|SC-48334|2||
||#79|Zavesca 10|||
||#80|OGT 918|8||
||#81|OGT-918|8||
||#82|{OR #71-#81}|188||
||#83|#63 OR #66 OR|#69 OR #70 OR #82<br>407||
||#84|#58 AND #83|231||
|**Total**||||**926**|  
Fonte: Elaboração própria.  
Foi realizada busca no clinicaltrials.gov no dia 23 de maio de 2023 utilizando os termos “Gaucher disease” e “eliglustat” com o intuito de identificar os estudos em andamento sobre eliglustate. Também foi realizada busca manual das referências dos artigos identificados.  
Seleção dos estudos e extração dos dados  
A seleção dos estudos elegíveis, compreendendo as etapas de leitura de título e resumo (triagem) e leitura por texto completo (elegibilidade) foi realizada por um avaliador. Foi utilizado o aplicativo web Rayyan para realizar a exclusão das referências duplicadas e a triagem dos estudos em avaliação<sup>4</sup> . A extração dos dados foi realizada por um único avaliador por meio de uma planilha do Microsoft Office Excel® pré-estruturada. Os seguintes dados foram extraídos:  
I. Características dos estudos, intervenções e participantes: autor, ano; país; desenho do estudo; características gerais da população; número de participantes; sexo; alternativas comparadas; duração do tratamento; e critérios de inclusão.  
II. Desfechos e resultados: na extração dos dados dos desfechos, coletou-se as pontuações médias (média final ou média da variação), os desvios-padrão e os tamanhos das amostras dos estudos.  
Avaliação da qualidade metodológica ou risco de viés dos estudos  
A avaliação da qualidade metodológica dos estudos foi realizada por um único avaliador utilizando ferramentas adequadas ao delineamento dos estudos. As revisões sistemáticas foram avaliadas pela ferramenta AMSTAR-2<sup>5</sup> . Já os ensaios clínicos randomizados foram avaliados por meio da ferramenta _Cochrane Risk of Bias Tool – ROB 2.0_<sup>6</sup> . Para estudos observacionais comparativos, a ferramenta ROBINS-I da colaboração Cochrane seria utilizada<sup>7</sup> .  
Síntese e análise dos dados  
As características e resultados dos estudos foram apresentados individualmente de forma narrativa e os resultados foram agrupados por desfecho. Para cada desfecho foi avaliada a homogeneidade entre estudos para considerar a possibilidade de realização de meta-análise direta e indireta.  
As variáveis dicotômicas foram avaliadas pelo número de eventos e de participantes em cada grupo. Foi realizada análise do risco relativo com descrição dos intervalos de confiança (IC). As variáveis contínuas foram analisadas pela média e desvio padrão. Quando possível, a análise comparativa entre os grupos foi realizada pela diferença de média e IC.  
Apesar de ter sido prevista a realização de meta-análises indiretas ou em rede, elas não foram viáveis, de forma que os métodos planejados não são descritos.  
Avaliação da qualidade da evidência  
62  
A certeza no conjunto final da evidência foi avaliada utilizando a ferramenta _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE), sendo classificada como alta, moderada, baixa e muito baixa<sup>8</sup> . A avaliação foi realizada para os desfechos considerados críticos pelos especialistas.  
Resultados  
Foram recuperadas 926 publicações nas bases de dados consultadas, restando 857 após remoção de duplicatas. Após a leitura dos títulos e resumos, 28 registros foram selecionados para leitura na íntegra ( **Figura G** ). A busca por ensaios clínicos em andamento não apontou nenhum registro adicional.  
Três revisões sistemáticas foram incialmente incluídas por atenderem aos critérios de elegibilidade<sup>9-11</sup> . No entanto, uma das revisões foi publicada antes dos estudos sobre eliglustate<sup>11</sup> , outra agrupou dados sobre pacientes previamente tratados e não tratados<sup>10</sup> e outra avaliou os medicamentos de maneira isolada<sup>9</sup> . Por estes motivos, foi feita a opção pela avaliação de estudos individualmente. As revisões foram utilizadas para busca adicional de referências. Nenhum estudo adicional foi incluído por este método.  
Ao final da avaliação de elegibilidade, dois ensaios clínicos foram incluídos<sup>3,12,13</sup> . A lista de estudos excluídos e os motivos estão detalhados no **Quadro K** .  
63  
**Figura G.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
2 Registros identificados: Registros removidos antes da<br>Bases de dados (n =3) selecdo:<br>Registros (n = 926 ) Duplicidades removidas (n =69)<br>Registros avaliados Registros excluidos<br>(n = 857) (n =830)<br>Registros para leitura completa Registros nao recuperados<br>(n=27) *! (n=0)<br>Registros selecionados para Registros excluidos .<br>avaliacao de elegibilidade |__ Ss de estudo inelegivel (n =<br>(n=27) Comparacao de<br>dose/posologia do mesmo<br>medicamento (n =3 )<br>Populacdo inelegivel (n =2)<br>Sem comparacdo entre os<br>medicamentos de interesse<br>(n=1)<br>Estudos incluidos na reviséo Revisdo desatualizada (n=2)<br>(n=2) Subandlise depacientes ja<br>Registros dos estudos incluidos incluidos na avaliagao (n=1)<br>(n =3)<br><!-- End of picture text -->  
Fonte: Traduzido e preenchido de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. Mais informações em: http://www.prisma-statement.org/  
64  
**Quadro K:** Estudos excluídos na elegibilidade com os motivos  
|**Autor, ano**|**Motivo**|
|---|---|
|Connock, 2006<sup>14</sup>|Revisão desatualizada|
|Cox, 2012<sup>15</sup>|Tipo de estudo inelegível|
|Elstein, 2013<sup>16</sup>|Tipo de estudo inelegível|
|Elstein, 2015<sup>17</sup>|Tipo de estudo inelegível|
|Fost, 2007<sup>18</sup>|Comparação de doses/posologias diferentes do mesmo medicamento|
|Gonzalez, 2013<sup>19</sup>|Comparação de doses/posologias diferentes do mesmo medicamento|
|Kishnani, 2009<sup>20</sup>|Comparação de doses/posologias diferentes do mesmo medicamento|
|Kuter, 2020<sup>21</sup>|Tipo de estudo inelegível|
|Leonart, 2023<sup>9</sup>|Não houve comparação entre os medicamentos de interesse|
|Morris, 2012<sup>22</sup>|Tipo de estudo inelegível|
|Nabizadeh, 2018<sup>10</sup>|População inelegível|
|Paskulin, 2022<sup>23</sup>|Tipo de estudo inelegível|
|Pastores, 2014<sup>24</sup>|Tipo de estudo inelegível|
|Pastores, 2014a<sup>25</sup>|Tipo de estudo inelegível|
|Peterschmitt, 2018<sup>26</sup>|Tipo de estudo inelegível|
|Peterschmitt, 2019<sup>27</sup>|Tipo de estudo inelegível|
|Pleat, 2016<sup>28</sup>|Subanálise dos pacientes já incluídos no estudo de Cox e colaboradores (2015)|
|Rossum, 2016<sup>29</sup>|Tipo de estudo inelegível|
|Schiffmann, 2008<sup>30</sup>|População inelegível|
|Shemesh, 2015<sup>11</sup>|Revisão desatualizada|
|Smid, 2014<sup>31</sup>|Tipo de estudo inelegível|
|Smith, 2016<sup>32</sup>|Tipo de estudo inelegível|
|Zimran, 2013<sup>33</sup>|Tipo de estudo inelegível|
|Zimran, 2016<sup>34</sup>|Tipo de estudo inelegível|  
Caracterização dos estudos incluídos  
O estudo ENCORE é um ensaio clínico randomizado (ECR) aberto de não inferioridade que comparou o eliglustate a imiglucerase em pacientes previamente tratados com terapia de reposição enzimática por pelo menos três anos<sup>3</sup> . Além do estudo pivotal, foi incluída a análise do período de extensão do mesmo estudo<sup>12</sup> .  
Também foi incluído o estudo publicado por Elstein e colaboradores, que avaliou o uso de miglustate e imiglucerase 13. O objetivo da inclusão foi avaliar a possibilidade de análise indireta dos desfechos entre eliglustate e imiglucerase a partir de comparador comum.  
As características dos estudos estão descritas no **Quadro L** .  
65  
**Quadro L.** Caracterização dos estudos incluídos  
|**Autor, ano**|**Características gerais**<br>**da população**|**País**|**Tempo de**<br>**acompanhamento**|**Alternativas**<br>**comparadas**|**Financiamento**|**Participantes**|
|---|---|---|---|---|---|---|
|Cox, 2015<br>ECR fase III de não<br>inferioridade<br>ENCORE<br>(NCT00943111)|N = 159<br>DG1 previamente<br>tratados por pelo menos 3<br>anos<br>45,2% sexo feminino|Espanha, Reino Unido,<br>França, Alemanha, Itália,<br>Argentina, Austrália,<br>Brasil, Canada, Egito,<br>Rússia, Estados Unidos|12 meses|Eliglustate 50-<br>150mg 2x dia<br>Imiglucerase 30–130<br>U/kg/mês|Genzyme|Eliglustate = 106<br>Imiglucerase = 53|
|Cox, 2017<br>Extensão de ECR<br>fase III<br>ENCORE<br>(NCT00943111)|N =157<br>DG1 previamente<br>tratados por pelo menos 3<br>anos<br>54,1% sexo feminino|Espanha, Reino Unido,<br>França, Alemanha, Itália,<br>Argentina, Australia,<br>Brasil, Canada, Egito,<br>Rússia, Estados Unidos|48 meses|Eliglustate 50-<br>150mg 2x dia|Genzyme|Eliglustate = 157|
|Elstein, 2007<br>ECR fase II|N=36<br>DG1 previamente<br>tratados por pelo menos 2<br>anos<br>56% sexo feminino|Israel|6 meses|Miglustate 100mg<br>3x dia<br>Imiglucerase 30 a<br>60UI/Kg/mês|Oxford<br>GlycoSciences|Miglustate = 12<br>Imiglucerase = 12<br>Miglustate +<br>Imiglucerase = 12|  
Fonte: Elaboração própria. Legenda: DG1: doença de Gaucher tipo 1; ECR: ensaio clínico randomizado.  
66

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Avaliação dos estudos incluídos -->
Foi realizada avaliação do risco de viés dos ensaios clínicos incluídos para os desfechos considerados críticos. Apenas o estudo ENCORE relatou os desfechos considerados críticos. Para todos os desfechos avaliados, o estudo foi considerado como alto risco de viés ( **Figura H** ). Por se tratar de um estudo aberto em que tanto pacientes quanto profissionais conheciam a intervenção recebida, há possibilidade de viés na mensuração dos desfechos. Qualidade de vida, dor, fadiga e o relato de eventos adversos pelo paciente são desfechos subjetivos potencialmente influenciados pelo conhecimento do medicamento recebido.  
**Figura H.** Risco de viés dos estudos incluídos para os desfechos críticos, avaliados pela ferramenta RoB 2.0.  
<!-- Start of picture text -->
Estudo Desfechos D1 D2 03 Ds DS Geral<br>ENCORE cusidade devito @ @ @ OO @  @ iwi<br>ENCORE bor S © @ @ @ @ aD weas preccspacses<br>ENconE Fadiea SOOO S CO @ Pix.<br>ENCORE on/ © w i<br>D1 Processo de randomizac3o<br>D2 Desvio da intervenco pretendida<br>D3 Desfecho incompleto<br>D4 Mensurac3odo desfecho<br>DS Seles de restadosreportados<br><!-- End of picture text -->  
Fonte: Elaboração própria. Legenda: D: Domínio.  
Síntese dos resultados dos desfechos avaliados  
Devido à heterogeneidade entre os estudos quanto aos tempos de seguimento e a forma como os desfechos foram coletados, não foi possível elaborar meta-análise indireta entre os estudos incluídos. Desta forma, os dados foram relatados por desfecho de forma narrativa. Os dados coletados foram sumarizados no **Quadro M** e no **Quadro N** , contemplando os desfechos críticos e importantes, respectivamente.  
67  
**Quadro M.** Descrição dos desfechos críticos relatados nos estudos incluídos.  
|**Autor, ano**|**Qualidade de vida**<br>**(componente físico)**<br>**Média (Desvio-padrão)**|**Qualidade de vida**<br>**(componente mental)**<br>**Média (Desvio -**<br>**padrão)**|**Dor (BPI)**<br>**Média (Desvio-padrão)**|**Fadiga (FSS)**<br>**Média (Desvio-padrão)**|**Número de pacientes com EA**<br>**graves**|
|---|---|---|---|---|---|
|Cox, 2015|eliglustate: 49,59 (9,158)<br>para 51,22 (8,368); N=95<br>Imiglucerase: 53,38<br>(7,174) para 55,07<br>(5,201); N=46|eliglustate: 51,97<br>(9,849) para 50,97<br>(10,298); N=95<br>Imiglucerase: 51,34<br>(10,085) para 51,34<br>(10,085); N=46|eliglustate: 1,67 (2,045) para<br>1,55 (1,972); N=95<br>Imiglucerase:1,17 (1,435)<br>para 0,85 (1,192); N=46|eliglustate: 3,06 (1,553) para<br>3,13 (1,626); N=97<br>Imiglucerase: 3,01 (1,544)<br>para 2,92 (1,535); N=45|**Graves e gravíssimos:**<br>Eliglustate: 24/106<br>Imiglucerase: 4/53<br>RR 3,00 (IC 95% 1,10; 8,20)<br>**Descontinuação por EA:**<br>Eliglustate: 2/106<br>Imiglucerase: 1/53<br>RR 1,00 (IC 95% 0,09; 10,78)|
|Cox, 2017|NR|NR|NR|NR|**Graves:**24/157 (17,1%)<br>**Descontinuação por EA:**<br>Eliglustate:12/157 (7,6%)|
|Elstein, 2007|NR*|NR*|NR|NR|NR|  
Fonte: Elaboração própria. Legenda: BPI: Inventário Breve de Dor; EA: evento adverso; FSS: escala de gravidade da fadiga; IC: intervalo de confiança; N: número de participantes; NR: não relatado. *O estudo não relatou os dados de qualidade de vida de maneira confiável e, por este motivo, os valores não foram incluídos na tabela.  
68  
**Quadro N.** Descrição dos desfechos importantes relatados nos estudos incluídos.  
|**Autor, ano**|**T score (coluna**<br>**lombar)**<br>**Média (desvio-**<br>**padrão)**|**T score (fêmur)**<br>**Média (desvio-**<br>**padrão)**|**% dos pacientes**<br>**com estabilidade**<br>**das variáveis**<br>**hematológicas**<br>**(concentração de**<br>**hemoglobina)**|**% dos pacientes**<br>**com estabilidade**<br>**das variáveis**<br>**hematológicas**<br>**(contagem de**<br>**plaquetas)**|**% dos pacientes**<br>**com estabilidade**<br>**do volume do**<br>**fígado (avaliada**<br>**por RM)**|**% dos pacientes**<br>**com estabilidade**<br>**do volume do baço**<br>**(avaliada por RM)**|**Número de**<br>**pacientes com EA**|
|---|---|---|---|---|---|---|---|
|Cox, 2015|eliglustate: -0,52<br>(1,28); N=81<br>Imiglucerase: -0,31<br>(1,19); N=38|eliglustate: -0,10<br>(0,156); N=80<br>Imiglucerase: -<br>0,98(0,184); N=37|Eliglustate: 99/106<br>(93%)<br>Imiglucerase: 52/<br>54 (96%)<br>RR 0,97 (IC 95%<br>0,90 a 1,04)|Eliglustate: 96/106<br>(91%)<br>Imiglucerase: 53/<br>54 (98%)<br>RR 0,92 (IC 95%<br>0,86 a 0,99)|Eliglustate:<br>100/106 (94%)<br>Imiglucerase: 50/<br>54 (93%)<br>RR 1,02 (IC 95%<br>0,93 a 1,11)|Eliglustate:<br>100/106 (94%)<br>Imiglucerase: 53/<br>54 (98%)<br>RR 0,96 (IC 0,91 a<br>1,02)|Eliglustate: 97/106<br>(91,5%)<br>Imiglucerase: 42/53<br>(79,2%)|
|Cox, 2017|NR|NR|46/46 (100%)|44/46 (96%)|44/46 (96%)|43/46 (94%)|84/ 157 (53,5%)|
|Elstein, 2007|NR|NR|alteração em<br>relação ao basal:<br>Miglustate: -2.2%<br>(2.5); N=10<br>Imiglucerase:<br>+1,0% (1,8%);<br>N=12|alteração em<br>relação ao basal:<br>Miglustate: -9.5%<br>(9.4); N=10<br>Imiglucerase:<br>+10.4% (9); N=12|alteração em<br>relação ao basal:<br>Miglustate: -4.0%<br>(4.8); N=10<br>Imiglucerase:<br>+3.8% (5.0); N=11|alteração em<br>relação ao basal:<br>Miglustate: -4.6%<br>(5.9); N=7<br>Imiglucerase: -<br>2.0% (3.3); N=8|34/34 (100%)|  
Fonte: Elaboração própria. Legenda: EA: evento adverso; IC: intervalo de confiança; N: número de participantes; NR: não relatado; RM: ressonância magnética; RR: risco relativo.  
69

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Qualidade de vida -->
O estudo ENCORE avaliou a qualidade de vida dos participantes após 12 meses de tratamento utilizando o questionário SF-36. Os dados foram apresentados para os componentes físico e mental, somente. Ao final de 12 meses de tratamento, a média do valor do componente físico dos participantes que receberam eliglustate variou de 49,59 para 51,22 e de 53,38 para 55,07 no grupo que recebeu imiglucerase. Não é possível definir qualquer diferença estatística entre os grupos 3.  
Já para o componente mental, o valor médio após 12 meses de tratamento foi de 51,97 para 50,97 no grupo que recebeu eliglustate e de 51,99 para 51,34 no grupo do imiglucerase. Da mesma forma como relatado para o componente físico, não é possível definir qualquer diferença estatística entre os grupos<sup>3</sup> .  
O estudo de Elstein e colaboradores<sup>13</sup> relatou o desfecho de qualidade de vida de modo incorreto, com descrição somente do porcentual de alteração do componente mental da qualidade de vida, sem apresentar os dados completos para avaliação. Foi identificado viés no relato deste desfecho e optou-se por não apresentar os dados deste artigo para evitar conclusões indevidas sobre o tratamento.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Dor e fadiga -->
Cox e colaboradores relatam que a avaliação da dor realizada com o questionário _Brief Pain Inventory_ (Inventário Breve de Dor). Não houve diferença entre os participantes que receberam eliglustate (diferença de média -0,12; IC 95% - 0,69 a 0,45) e imiglucerase após 12 meses de tratamento (diferença de média -0,32; IC 95% -0,86 a 0,22)<sup>3</sup> .  
Já a fadiga foi avaliada no mesmo estudo pelo questionário _Fatigue Severity Scale_ (FSS – escala de gravidade da fadiga). Assim como no desfecho de dor, não houve diferença entre os participantes que receberam eliglustate (diferença de média 0,07; IC 95% -0,38 a 0,52) e imiglucerase (diferença de média -0,09; IC 95% -0,73 a 0,55)<sup>3</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Eventos adversos graves -->
O estudo ENCORE apresentou os dados de EA graves e gravíssimos comparando os pacientes tratados com eliglustate e imiglucerase. Ao final de 12 meses, 24 (22,6%) participantes no grupo eliglustate e 4 (7,5%) do grupo imiglucerase sofreram EA graves ou gravíssimos. Houve maior risco destes EA no grupo que recebeu eliglustate (RR 3,0; IC 95% 1,10 a 8,20)<sup>3</sup> .  
Cox e colaboradores publicaram os dados do estudo de extensão do ENCORE, com dados dos participantes tratados com eliglustate. Após 4 anos de tratamento, 27 (17%) participantes tiveram algum evento adverso grave e 12 (8%) participantes descontinuaram o tratamento devido à ocorrência de eventos adversos<sup>12</sup> .

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: Alterações hematológicas -->
O estudo ENCORE apresentou o número de pacientes com estabilidade hematológica após 12 meses de tratamento. A concentração de hemoglobina permaneceu estável em 99 (93%) dos pacientes que receberam eliglustate e em 52 (96%) dos pacientes que receberam imiglucerase. Dessa forma, não houve diferença entre os grupos (RR 0,97; IC 95% 0,90 a 1,04) 3.  
Quanto à contagem de plaquetas, 96 (91%) dos pacientes que receberam eliglustate e 53 (98%) dos que receberam imiglucerase mantiveram estabilidade após 12 meses de tratamento (RR 0,92; IC 95% 0,86 a 0,99)<sup>3</sup> . A **Figura I** mostra os dados apresentados no material suplementar do artigo publicado por Cox e colaboradores<sup>3</sup> .  
70  
**Figura I:** Proporção de pacientes com estabilidade nos desfechos de concentração de hemoglobina, contagem de plaquetas, volume do fígado e baço.  
<!-- Start of picture text -->
© 96% 98% 94% 98% 94% 91%<br>£ 100% 93% 91% 93% 83%<br>6<br>2 80%<br>5©<br>i)<br>3B 60%<br>2<br>2<br>5<br>2 40%<br>=<br>2<br>é<br>20%<br>S<br>=<br>3<br>ge % Stable Stable Stable Spleen Stable Liver Composite<br>Hemoglobin Platelets Volume Volume<br>mEliglustat = Imiglucerase Error bars reflect exact 95% Cl around the proportion.<br><!-- End of picture text -->  
**Fonte** : Cox, 2015  
O estudo publicado por Elstein e colaboradores não descreve o número de participantes que mantiveram estabilidade das variáveis hematológicas, mas descreve a diferença percentual das medidas antes e após os 6 meses de tratamento<sup>13</sup> .  
Os participantes que receberam miglustate tiveram queda da concentração de hemoglobina (-2,2%; desvio padrão 2,5) e contagem de plaquetas (-9,5%; desvio padrão 9,4). Já aqueles que receberam imiglucerase tiveram aumento das mesmas variáveis (hemoglobina: 1,0%; desvio padrão 1,8; plaquetas: 10,4%; desvio padrão 9,4)<sup>13</sup> .  
Alterações do baço e fígado  
O **Quadro O** também apresenta a porcentagem de pacientes que mantiveram estabilidade no volume do fígado e baço no estudo ENCORE. Entre os pacientes que receberam eliglustate, 100 (94%) mantiveram estabilidade no volume dos órgãos. Já no grupo que recebeu imiglucerase 50 (93%) e 53 (98%) participantes mantiveram estabilidade do volume do fígado e  
baço, respectivamente<sup>3</sup> .  
Alterações ósseas  
A variação do T-escore foi avaliada apenas no estudo ENCORE<sup>3</sup> . Houve redução do T-score da coluna lombar e femural tanto nos pacientes que receberam eliglustate quanto nos pacientes que receberam imiglucerase ( **Quadro O** ).  
Eventos adversos  
O estudo ENCORE descreveu como EA mais comuns a artralgia, dor nas costas, diarreia, fadiga, cefaleia e náusea. Entre os participantes que receberam eliglustate, 97 (91,5%) tiveram algum evento adverso. Já no grupo que recebeu imiglucerase, 42 (79,2%) participantes tiveram EA. Não houve diferença no risco de eventos adversos entre os grupos (RR 1,15; IC 95% 0,99 a 1,34)<sup>3</sup> .  
Já no estudo publicado por Elstein e colaboradores<sup>13</sup> , os EA mais comuns estavam relacionados ao trato gastrointestinal (diarreia e flatulência), sistema nervoso (tremor e tontura) e perda de peso. Todos os pacientes do estudo tiveram algum evento adverso.  
Avaliação da qualidade da evidência  
A certeza no conjunto final da evidência foi considerada baixa para os desfechos: qualidade de vida, fadiga, dor e descontinuação do tratamento por eventos adversos. A certeza no conjunto final da evidência foi moderada para o desfecho eventos adversos graves ( **Quadro O** ).  
Os principais motivos para rebaixamento da evidência foram risco de viés e imprecisão.  
71  
**Quadro O.** Avaliação da certeza do conjunto final da evidência pela ferramenta GRADE  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Certe**<br>**Risco**<br>**de**<br>**viés**|**za do conjunto d**<br>**Inconsistência**|**a evidência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**№ de p**<br>**eliglustate**|**acientes**<br>**imiglucerase**|**Efe**<br>**Relativo**<br>**(IC**<br>**95%)**|**ito**<br>**Absoluto**<br>**(IC**<br>**95%)**|**Certez**<br>**a**|**Importân**<br>**cia**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Qualidade de vida (componente físico) (seguimento: 12 meses)** -->
|1<br>ensaios<br>clínicos<br>randomizad<br>os|grav<br>e<sup>a</sup>|não grave<br>não<br>grave|grave<sup>b</sup>|nenhum|A avaliação do componente físico de qualidade de<br>vida pelo questionário SF 36 teve resultado de<br>49,59 (DP 9,158) antes do tratamento com<br>eliglustate e de 51,22 (DP 8,368). A alteração antes<br>e após o tratamento foi de 1,63 (IC 95% -1,41 a<br>4,67).<br>No grupo que recebeu imiglucerase, houve variação<br>de 53,38 (DP 7,174) para 55,07 (DP 5,201), com<br>alteração de 1,69 (-0,39 a 3,77). Não houve<br>diferença entre os valores antes e após ao<br>tratamento e não é possível comparar as<br>intervenções, devido às limitações do estudo.|⨁⨁◯<br>◯<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|  
**Qualidade de vida (componente mental) (seguimento: 12 meses)**  
72  
|||**Certe**|**za do conjunto d**|**a evidência**|||**№ de pacientes**<br>**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**eliglustate**<br>**imiglucerase**<br>**Relativo**<br>**(IC**<br>**95%)**<br>**Absoluto**<br>**(IC**<br>**95%)**|**Certez**<br>**a**|**Importân**<br>**cia**|
|1|ensaios<br>clínicos<br>randomizad<br>os|grav<br>e<sup>a</sup>|não grave|não<br>grave|grave<sup>c</sup>|nenhum|A avaliação do componente mental da qualidade de<br>vida pelo questionário SF 36 teve resultado de<br>51,97 (DP 9,849) antes do tratamento com<br>eliglustate e de 50,97 (DP 10,298). A alteração da<br>qualidade de vida antes e após o tratamento foi de -<br>1,0 (IC 95% -4,57 a 2,57).<br>No grupo que recebeu imiglucerase, houve variação<br>de 51,99 (DP 8,871) para 51,34 (DP 10,085), com<br>alteração de -0,65 (IC 95% -4,07 a 2,77). Não houve<br>diferença entre os valores antes e após ao<br>tratamento e não é possível comparar as<br>intervenções, devido às limitações do estudo.|⨁⨁◯<br>◯<br>Baixa|CRÍTICO|

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Dor (seguimento: 12 meses)** -->
|1|ensaios<br>clínicos<br>randomizad<br>os|grav<br>e<sup>a</sup>|não grave<br>não<br>grave|grave<sup>d</sup>|nenhum|A avaliação da dor foi realizada por meio do<br>questionário_Brief Pain Inventory_(Inventário Breve<br>de Dor). Não houve diferença entre os participantes<br>que receberam eliglustate (diferença de média -<br>0,12; IC 95% -0,69 a 0,45) e imiglucerase após 12<br>meses de tratamento (diferença de média -0,32; IC<br>95% -0,86 a 0,22).|⨁⨁◯<br>◯<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|  
**Fadiga (seguimento: 12 meses)**  
73  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Certe**<br>**Risco**<br>**de**<br>**viés**|**za do conjunto d**<br>**Inconsistência**|**a evidência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**№ de pacientes**<br>**Efeito**<br>**eliglustate**<br>**imiglucerase**<br>**Relativo**<br>**(IC**<br>**95%)**<br>**Absoluto**<br>**(IC**<br>**95%)**|**Certez**<br>**a**|**Importân**<br>**cia**|
|---|---|---|---|---|---|---|---|---|---|
|1|ensaios<br>clínicos<br>randomizad<br>os|grav<br>e<sup>a</sup>|não grave|não<br>grave|grave<sup>d</sup>|nenhum|A fadiga foi avaliada pelo questionário_Fatigue_<br>_Severity Scale_(FSS – escala de gravidade da<br>fadiga). Assim como no desfecho de dor, não houve<br>diferença entre os participantes que receberam<br>eliglustate (diferença de média 0,07; IC 95% -0,38<br>a 0,52) e imiglucerase (diferença de média -0,09; IC<br>95% -0,73 a 0,55) após 12 meses de tratamento.|⨁⨁◯<br>◯<br>Baixa|CRÍTICO|

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Eventos adversos graves (seguimento: 12 meses)** -->
|1<br>ensaios|grav|não grave<br>não|não grave|nenhum|24/106|4/53|**RR**|**151**|⨁⨁⨁|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|
|clínicos<br>randomizad<br>os|e<sup>a</sup>|grave|||(22.6%)|(7.5%)|**3.0**<br>(1.1<br>para<br>8.2)|**mais**<br>**por**<br>**1.000**<br>(de<br>8<br>mais<br>para<br>543<br>mais)|◯<br>Modera<br>da||

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Descontinuação por evento adverso (seguimento: 12 meses)** -->
74  
|||**Certe**|**za do conjunto d**|**a evidência**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**eliglustate**|**imiglucerase**|**Relativo**<br>**(IC**<br>**95%)**|**Absoluto**<br>**(IC**<br>**95%)**|**Certez**<br>**a**|**Importân**<br>**cia**|
|1|ensaios<br>clínicos<br>randomizad<br>os|grav<br>e<sup>a</sup>|não grave|não<br>grave|grave<sup>e</sup>|nenhum|2/106<br>(1.9%)|1/53<br>(1.9%)|**RR**<br>**1.00**<br>(0.09<br>para<br>10.78)|**0**<br>**menos**<br>**por**<br>**1.000**<br>(de 17<br>menos<br>para<br>185<br>mais)|⨁⨁◯<br>◯<br>Baixa|CRÍTICO|  
DP: desvio-padrão; IC: intervalo de confiança; RR: risco relativo.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **Descontinuação por evento adverso (seguimento: 12 meses)** -->
a. O risco de viés foi considerado alto por se tratar de desfecho subjetivo relatado em estudo não-cego.  
b. A diferença no componente físico de qualidade de vida após 12 meses de tratamento e entre o grupo que recebeu eliglustate e imiglucerase não supera os dois pontos para ser considerada diferença mínima clinicamente importante.  
c. A diferença no componente mental de qualidade de vida após 12 meses de tratamento e entre o grupo que recebeu eliglustate e imiglucerase não supera os três pontos para ser considerada diferença mínima clinicamente importante.  
d. Não é possível avaliar diferença entre os grupos.  
e. O intervalo de confiança passa pelo efeito nulo.  
75  
Considerações finais  
A avaliação da eficácia e segurança do eliglustate em pacientes com DG1 previamente tratados considerou o estudo ENCORE. O estudo foi desenhado para demonstrar não inferioridade do eliglustate em relação à imiglucerase na manutenção das estabilidades das variáveis hematológicas e volume do fígado e baço. Como o estudo não foi desenhado para avaliar a superioridade de um tratamento sobre o outro, não é possível fazer tal afirmação.  
Os desfechos considerados críticos foram avaliados de forma secundária no estudo ENCORE, mas não foi possível verificar alterações significativas nos componentes físicos e mentais ou no relato de dor e fadiga, tanto entre os participantes que receberam eliglustate quanto nos que receberam imiglucerase.  
A evidência identificada apresenta algumas limitações, pois as evidências relacionadas aos desfechos críticos elegidos são escassas. Além disso, não foi possível obter comparações indiretas entre o eliglustate e alternativas terapêuticas para DG1 ( <mark>alfataliglicerase, alfavelaglicerase, miglustate)</mark> . Leonart e colaboradores<sup>9</sup> publicaram recentemente revisão sistemática que aborda a mesma limitação.

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **REFERÊNCIAS** -->
1.  Sanofi Genzyme. Bula do produto Cerdelga. Waterford, Irlanda; 2021.  
2.  CADTH. CADTH Common Drug Review. Clinical Review Report. Eliglustat [Internet]. 2017 [cited 2023 Jun 4].  
Available from: https://www.cadth.ca/sites/default/files/cdr/clinical/SR0511_Cerdelga_CL_Report_e.pdf  
3.  Cox TM, Drelichman G, Cravo R, Balwani M, Burrow TA, Martins AM, et al. Eliglustat compared with imiglucerase in patients with Gaucher’s disease type 1 stabilised on enzyme replacement therapy: a phase 3, randomised, open-label, non-inferiority trial. Lancet [Internet]. 2015 Jun;385(9985):2355–62. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0140673614618419  
4.  Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews. Syst Rev [Internet]. 2016 Dec 5;5(1):210. Available from: http://systematicreviewsjournal.biomedcentral.com/articles/10.1186/s13643-016-0384-4  
5.  Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ [Internet]. 2017 Sep 21;j4008. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.j4008  
6.  Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: a revised tool for assessing  
risk of bias in randomised trials. BMJ [Internet]. 2019 Aug 28;l4898. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.l4898  
7.  Sterne JA, Hernán MA, Reeves BC, Savović J, Berkman ND, Viswanathan M, et al. ROBINS-I: a tool for assessing risk of bias in non-randomised studies of interventions. BMJ [Internet]. 2016 Oct 12;i4919. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.i4919  
8.  Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ [Internet]. 2008 Apr 26;336(7650):924–6. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.39489.470347.AD  
9.  Leonart LP, Fachi MM, Böger B, Silva MR da, Szpak R, Lombardi NF, et al. A Systematic Review and Metaanalyses of Longitudinal Studies on Drug Treatments for Gaucher Disease. Ann Pharmacother [Internet]. 2023 Mar 11;57(3):267–82. Available from: http://journals.sagepub.com/doi/10.1177/10600280221108443  
10. Nabizadeh A, Amani B, Kadivar M, Toroski M, Asl A, Bayazidi Y, et al. The clinical efficacy of imiglucerase versus eliglustat in patients with Gaucher’s disease Type 1: A systematic review. J Res Pharm Pract [Internet]. 2018;7(4):171.  
76  
Available from: http://www.jrpp.net/text.asp?2018/7/4/171/246986  
11. Shemesh E, Deroma L, Bembi B, Deegan P, Hollak C, Weinreb NJ, et al. Enzyme replacement and substrate reduction therapy for Gaucher disease. Cochrane Database Syst Rev [Internet]. 2015 Mar 27;2015(4). Available from: http://doi.wiley.com/10.1002/14651858.CD010324.pub2  
12. Cox TM, Drelichman G, Cravo R, Balwani M, Burrow TA, Martins AM, et al. Eliglustat maintains long-term clinical stability in patients with Gaucher disease type 1 stabilized on enzyme therapy. Blood [Internet]. 2017 Apr 27;129(17):2375–83. Available from: https://ashpublications.org/blood/article/129/17/2375/35964/Eliglustat-maintainslongterm-clinical-stability  
13. Elstein D, Dweck A, Attias D, Hadas-Halpern I, Zevin S, Altarescu G, et al. Oral maintenance clinical trial with miglustat for type I Gaucher disease: switch from or combination with intravenous enzyme replacement. Blood [Internet]. 2007 Oct 1;110(7):2296–301. Available from: https://ashpublications.org/blood/article/110/7/2296/103619/Oralmaintenance-clinical-trial-with-miglustat-for  
14. Connock M, Burls A, Frew E, Fry-Smith A, Juarez-Garcia A, McCabe C, et al. The clinical effectiveness and cost-effectiveness of enzyme replacement therapy for Gaucher’s disease: a systematic review. Health Technol Assess (Rockv) [Internet]. 2006 Jul;10(24). Available from: https://www.journalslibrary.nihr.ac.uk/hta/hta10240/  
15. Cox TM, Amato D, Hollak CE, Luzy C, Silkey M, Giorgino R, et al. Evaluation of miglustat as maintenance therapy after enzyme therapy in adults with stable type 1 Gaucher disease: a prospective, open-label non-inferiority study. Orphanet J Rare Dis [Internet]. 2012;7(1):102. Available from: http://ojrd.biomedcentral.com/articles/10.1186/1750-11727-102  
16. Elstein D, Zimran A. Safety and efficacy of velaglucerase alfa replacement therapy for patients with type 1 Gaucher disease. Expert Rev Endocrinol Metab [Internet]. 2013 Jul 10;8(4):333–9. Available from: http://www.tandfonline.com/doi/full/10.1586/17446651.2013.811871  
17. Elstein D, Mehta A, Hughes DA, Giraldo P, Charrow J, Smith L, et al. Safety and efficacy results of switch from imiglucerase to velaglucerase alfa treatment in patients with type 1 Gaucher disease. Am J Hematol [Internet]. 2015 Jul 22;90(7):592–7. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.24007  
18. de Fost M, Aerts JMFG, Groener JEM, Maas M, Akkerman EM, Wiersma MG, et al. Low frequency maintenance therapy with imiglucerase in adult type I Gaucher disease: a prospective randomized controlled trial. Haematologica [Internet]. 2007 Feb 1;92(2):215–21. Available from: http://www.haematologica.org/cgi/doi/10.3324/haematol.10635  
19. Gonzalez DE, Turkia H Ben, Lukina EA, Kisinovsky I, Dridi M-F Ben, Elstein D, et al. Enzyme replacement therapy with velaglucerase alfa in Gaucher disease: Results from a randomized, double-blind, multinational, Phase 3 study. Am J Hematol [Internet]. 2013 Mar;88(3):166–71. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.23381  
20. Kishnani PS, DiRocco M, Kaplan P, Mehta A, Pastores GM, Smith SE, et al. A randomized trial comparing the efficacy and safety of imiglucerase (Cerezyme) infusions every 4 weeks versus every 2 weeks in the maintenance therapy of adult patients with Gaucher disease type 1. Mol Genet Metab [Internet]. 2009 Apr;96(4):164–70. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1096719208004988  
21. Kuter DJ, Wajnrajch M, Hernandez B, Wang R, Chertkoff R, Zimran A. Open-label, expanded access study of taliglucerase alfa in patients with Gaucher disease requiring enzyme replacement therapy. Blood Cells, Mol Dis [Internet]. 2020 May;82:102418. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979620300668  
22. Morris JL. Velaglucerase Alfa for the Management of Type 1 Gaucher Disease. Clin Ther [Internet]. 2012 Feb;34(2):259–71. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0149291811008873  
23. Paskulin L d’Avila, Starosta RT, Vairo FP e, Krug BC, Picon P, Schwartz IVD. Efficacy and Safety of  
77  
Taliglucerase Alfa for the Treatment of Gaucher Disease: A 9-Year Experience. J Inborn Errors Metab Screen [Internet]. 2022;10. Available from: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S2326-45942022000100303&tlng=en  
24. Pastores GM, Rosenbloom B, Weinreb N, Goker-Alpan O, Grabowski G, Cohn GM, et al. A multicenter openlabel treatment protocol (HGT-GCB-058) of velaglucerase alfa enzyme replacement therapy in patients with Gaucher disease type 1: safety and tolerability. Genet Med [Internet]. 2014 May;16(5):359–66. Available from: https://linkinghub.elsevier.com/retrieve/pii/S109836002104822X  
25. Pastores GM, Petakov M, Giraldo P, Rosenbaum H, Szer J, Deegan PB, et al. A Phase 3, multicenter, openlabel, switchover trial to assess the safety and efficacy of taliglucerase alfa, a plant cell-expressed recombinant human glucocerebrosidase, in adult and pediatric patients with Gaucher disease previously treated with imigluc. Blood Cells, Mol Dis [Internet]. 2014 Dec;53(4):253–60. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979614000552  
26. Peterschmitt MJ, Cox GF, Ibrahim J, MacDougall J, Underhill LH, Patel P, et al. A pooled analysis of adverse events in 393 adults with Gaucher disease type 1 from four clinical trials of oral eliglustat: Evaluation of frequency, timing, and duration. Blood Cells, Mol Dis [Internet]. 2018 Feb;68:185–91. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979617300256  
27. Peterschmitt MJ, Freisens S, Underhill LH, Foster MC, Lewis G, Gaemers SJM. Long-term adverse event profile from four completed trials of oral eliglustat in adults with Gaucher disease type 1. Orphanet J Rare Dis [Internet]. 2019 Dec 7;14(1):128. Available from: https://ojrd.biomedcentral.com/articles/10.1186/s13023-019-1085-6  
28. Pleat R, Cox TM, Burrow TA, Giraldo P, Goker-Alpan O, Rosenbloom BE, et al. Stability is maintained in adults with Gaucher disease type 1 switched from velaglucerase alfa to eliglustat or imiglucerase: A sub-analysis of the eliglustat ENCORE trial. Mol Genet Metab Reports [Internet]. 2016 Dec;9:25–8. Available from: https://linkinghub.elsevier.com/retrieve/pii/S2214426916300659  
29. Van Rossum A, Holsopple M. Enzyme Replacement or Substrate Reduction? A Review of Gaucher Disease Treatment Options. Hosp Pharm [Internet]. 2016 Jul 1;51(7):553–63. Available from: http://journals.sagepub.com/doi/10.1310/hpj5107-553  
30. Schiffmann R, FitzGibbon EJ, Harris C, DeVile C, Davies EH, Abel L, et al. Randomized, controlled trial of miglustat in Gaucher’s disease type 3. Ann Neurol [Internet]. 2008 Nov;64(5):514–22. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ana.21491  
31. Smid BE, Hollak CE. A systematic review on effectiveness and safety of eliglustat for type 1 Gaucher disease. Expert Opin Orphan Drugs [Internet]. 2014 May 24;2(5):523–9. Available from: http://www.tandfonline.com/doi/full/10.1517/21678707.2014.899148  
32. Smith L, Rhead W, Charrow J, Shankar SP, Bavdekar A, Longo N, et al. Long-term velaglucerase alfa treatment in children with Gaucher disease type 1 naïve to enzyme replacement therapy or previously treated with imiglucerase. Mol Genet Metab [Internet]. 2016 Feb;117(2):164–71. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1096719215300172  
33. Zimran A, Pastores GM, Tylki-Szymanska A, Hughes DA, Elstein D, Mardach R, et al. Safety and efficacy of velaglucerase alfa in Gaucher disease type 1 patients previously treated with imiglucerase. Am J Hematol [Internet]. 2013 Mar;88(3):172–8. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.23383  
34. Zimran A, Gonzalez-Rodriguez DE, Abrahamov A, Cooper PA, Varughese S, Giraldo P, et al. Long-term safety and efficacy of taliglucerase alfa in pediatric Gaucher disease patients who were treatment-naïve or previously treated with imiglucerase. Blood Cells, Mol Dis [Internet]. 2018 Feb;68:163–72. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1079979616302212  
78

---

<!-- METADADOS: doenca: Doença de Gaucher | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**||**Tecnologias a**|**valiadas pela Conitec**|
|---|---|---|---|
|**da diretriz clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais**<br>**alterações**|**Incorporação ou**<br>**alteração do uso no**<br>**SUS**|**Não incorporação, exclusão ou**<br>**não alteração no SUS**|
|Relatório<br>de<br>Recomendação nº 945/<br>2024|Atualização<br>do<br>conteúdo|-|Excluir, no âmbito do Sistema<br>Único<br>de<br>Saúde<br>–<br>SUS<br>imiglucerase como pó liofilizado<br>injetável em frasco-ampola na<br>concentração<br>de<br>200<br>U;<br>alfavelaglicerase<br>como<br>pó<br>liofilizado para injetável em<br>frasco-ampola na concentração<br>de 200 U [Portaria SCTIE/MS nº<br>83/2021]|
|Portaria Conjunta SAS-<br>SCTIE/MS nº 4, de 22<br>de junho de 2017|Atualização<br>do<br>conteúdo|Ampliar<br>o<br>uso<br>da<br>alfataliglicerase para uso<br>pediátrico na Doença de<br>Gaucher<br>[Portaria<br>SCTIE/MS nº 25/2017]|-|
|Portaria SAS/MS nº<br>1.266,<br>de<br>14<br>de<br>novembro de 2014|Atualização<br>do<br>conteúdo|Alfataliglicerase para o<br>tratamento da doença de<br>Gaucher<br>[Portaria<br>SCTIE/MS nº 37/2014]|-|
|Portaria SAS/MS nº<br>708, de 25 de outubro<br>de 2011|Inclusão de outras<br>alternativas<br>terapêuticas|||
|Portaria<br>SAS/MS<br>nº449, de 08 de julho de<br>2002|Primeira versão do<br>PCDT|||  
79

---

