<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Aprova as Diretrizes Diagnósticas e Terapêuticas do Câncer de Cabeça e Pescoço.  
A Secretária de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre o câncer de cabeça e pescoço no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que as diretrizes diagnósticas e terapêuticas são resultado de consenso técnico-científico e são formuladas dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando as portarias SCTIE/MS nº 57, de 10 de dezembro de 2013, e nº 23, de 8 de junho de 2015, que tornam públicas as decisões de não incorporar o cetuximabe para tratamento do carcinoma de células escamosas de cabeça e pescoço localmente avançado e metastático no Sistema Único de Saúde - SUS, e nº 20, de 27 de maio de 2015, que torna pública a decisão de excluir a quimioterapia adjuvante do carcinoma epidermoide de cabeça e pescoço da Tabela do SUS, todas ratificando as recomendações da Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC);  
Considerando as sugestões dadas à Consulta Pública n<sup>o</sup> 23/SAS/MS, de 2 de dezembro de 2014; e  
Considerando a avaliação técnica da CONITEC e da Assessoria Técnica da SAS/MS, resolve:  
Art. 1º Ficam aprovadas, na forma do Anexo a esta Portaria, disponível no sitio: www.saude.gov.br/sas, as Diretrizes Diagnósticas e Terapêuticas – Câncer de Cabeça e Pescoço.  
Parágrafo único. As Diretrizes de que trata este artigo, que contêm o conceito geral do câncer de cabeça e pescoço, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento câncer de cabeça e pescoço.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde** -->
Art. 4º Fica excluído da Tabela de Procedimentos, Medicamentos, Órteses / Próteses e Materiais Especiais do SUS o procedimento 03.04.05.016-4 Quimioterapia do carcinoma epidermoide de cabeça e pescoço.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
LUMENA ALMEIDA CASTRO FURTADO

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
DIRETRIZES DIAGNÓSTICAS E TERAPÊUTICAS NO CÂNCER DE CABEÇA E PESCOÇO  
1. METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA  
Foi realizada em 30/08/2014 uma busca na base eletrônica Medline, acessada via PubMed, utilizando os descritores de interesse para câncer de cabeça e pescoço, buscando publicações relevantes nos últimos 15 anos ("head and neck neoplasms"[MeSH Terms] OR ("head"[All Fields] AND "neck"[All Fields] AND "neoplasms"[All Fields]) OR "head and neck neoplasms"[All Fields] OR ("head"[All Fields] AND "neck"[All Fields] AND "cancer"[All Fields]) OR "head neck cancer"[All Fields]) AND ((systematic[sb] OR Meta-Analysis[ptyp] OR Clinical Trial, Phase III[ptyp] OR Randomized Controlled Trial[ptyp]) AND "1999/08/30"[PDat] : "2014/08/30"[PDat]). Busca adicional de informações clínico-epidemiológicas relevantes sobre a doença em nosso meio foi feita na base de dados LILACS. Foram selecionadas para estas Diretrizes meta-análises, revisões sistemáticas e ensaios clínicos de fase III relativos à cirurgia, radioterapia e quimioterapia dos cânceres de cavidade oral, orofaringe, nasofaringe, hipofaringe e laringe. Além disso, foram consultados normas do Instituto Nacional de Câncer, do Ministério da Saúde, para o diagnóstico e tratamento do câncer de cabeça e pescoço, artigos sobre epidemiologia dessa neoplasia maligna no Brasil e o Manual de Bases Técnicas da Oncologia, do Ministério da Saúde. No total, 147 publicações foram utilizadas devidamente referidas nestas Diretrizes.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O carcinoma epidermoide de cabeça e pescoço (CECP) é um conjunto de neoplasias malignas de diferentes localizações nessa área do corpo humano e se configura como uma das principais causas de morbidade e mortalidade por neoplasia maligna no Brasil, pois a maioria dos casos é diagnosticada em fases tardias[1,2]. O tabagismo é o mais importante fator de risco para esse grupo de doenças, com risco atribuível de 50% em estudos prospectivos longitudinais[3]. Embora as taxas de fumantes estejam diminuindo no País, elas permanecem elevadas entre indivíduos que são também os mais afetados pelo CECP – os estratos menos educados e mais pobres da população em geral[4,5].  
Depois do tabagismo, o consumo de bebidas alcoólicas é o comportamento mais associado ao risco para CECP, quer em termos de quantidade quer em termos de duração. Importa notar que a magnitude do risco devido à interação entre o consumo de álcool e o tabagismo sugere efeito supra-aditivo, sendo os riscos maiores observados entre indivíduos com alto consumo simultâneo de álcool e de tabaco[6,7].  
Informações de Registros de Câncer de Base Populacional e de Registros Hospitalares de Câncer dão conta que o CECP no Brasil é mais comum entre homens, com idade entre 40 e 69 anos, tabagistas ou etilistas. No período de 2000 a 2008, os sítios de doença mais comuns foram a cavidade oral (46,9%), laringe (23,3%) e

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
orofaringe (18,5%), com doença diagnosticada predominantemente em estágios avançados[8].  
Um estudo observacional transversal sobre as características demográficas, clínicas e patológicas de pacientes com CECP em São Paulo (projeto GENCAPO) revelou que essa doença apresentava com maior frequência invasão linfonodal ao diagnóstico entre tabagistas e etilistas do que naqueles que não referiam um destes vícios, sendo essa diferença mais preponderante entre usuários e não usuários de bebida alcoólica. Os fumantes e não etilistas foram os mais afetados por câncer de laringe do que os outros grupos, enquanto entre não fumantes e não etilistas a doença acometia mais comumente mulheres idosas de etnia caucasiana[9].  
Além do tabagismo e etilismo, outros fatores de risco para o CECP incluem:  
a) dieta alimentar pobre em frutas cítricas, vegetais, tomates, ácidos graxos poliinsaturados N3 (peixes marinhos e azeite de oliva) e ingesta excessiva de carnes vermelhas, carnes processadas e frituras [10-12];  
b) má saúde bucal e doença periodontal, com perda de elementos dentários [13,14];  
c) doença do refluxo gastroesofágico, fator de risco para os cânceres de faringe e laringe[15];  
d) comportamento sexual, havendo evidência de relação direta entre o risco para CECP e coitarca precoce, multiplicidade de parceiros e prática de sexo oral[16]; e  
e) infecções por variantes oncogênicas do papilomavírus humano (HPV tipos 16 e 18), asssociadas a ocorrência dos cânceres de cavidade oral, orofaringe e laringe[17-19].  
Há evidências preliminares de suscetibilidade genética aos CECP, mas nenhum método de rastreamento citogenético ou molecular encontra-se validado para uso clínico[20, 21].  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E  
PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- C00 Neoplasia maligna do lábio;  
- C01 Neoplasia maligna da base da língua;  
- C02 Neoplasia maligna de outras partes e de partes não especificadas da língua; C03 Neoplasia maligna da gengiva;  
- C04 Neoplasia maligna do assoalho da boca;  
- C05 Neoplasia maligna do palato;  
C06 Neoplasia maligna de outras partes e de partes não especificadas da boca;  
- C09 Neoplasia maligna da amígdala;  
- C10 Neoplasia maligna da orofaringe;  
- C11 Neoplasia maligna da nasofaringe;  
- C12 Neoplasia maligna do seio piriforme;  
- C13 Neoplasia maligna da hipofaringe;  
C14 Neoplasia maligna de outras localizações e de localizações mal definida, do lábio, cavidade oral e faringe;  
C32 Neoplasia maligna da laringe.  
4. DIAGNÓSTICO E CLASSIFICAÇÃO  
Na fase inicial a doença é geralmente oligossintomática, o que dificulta o diagnóstico precoce, sendo de extrema importância um alto índice de suspeição por parte de odontologistas e médicos, especialmente no exame clínico da cavidade oral em pacientes tabagistas, etilistas ou com má saúde bucal[22].  
A sintomatologia depende da localização do tumor primário e do estágio da doença. Na fase inicial dos tumores de cavidade oral, sintomas incluem dor, úlceras que não cicatrizam e mudanças na dentição. Carcinomas da orofaringe, hipofaringe e laringe não costumam produzir sintomas iniciais e são usualmente diagnosticados em estágios avançados. Sintomas podem incluir dor de garganta e otalgia unilateral[22-24].  
Tumores da cavidade nasal e seios paranasais causam sinusites e obstrução unilateral das narinas. Em fases mais avançadas, provocam epistaxe, edema facial, dor, exoftalmo ou perda dos molares. Câncer da laringe pode ocasionar rouquidão. Os estágios avançados dos CECP cursam com dor, otalgia, obstrução de via aérea, neuropatia, trismo, disfagia, odinofagia, mobilidade da língua reduzida, fistulas, sintomas oculares e linfonodomegalia cervical[22-24].  
O diagnóstico do CECP se faz pelo exame clínico com nasoscopia e laringoscopia e biópsia tumoral. Na ausência de tumor primário visível, indica-se punção aspirativa por agulha fina ou biópsia de quaisquer massas cervicais, seguido de novo exame locorregional sob anestesia e biópsias adicionais, se necessário[25,26].  
Pacientes com neoplasia maligna confirmada devem ser submetidos à avaliação da extensão da doença por meio de tomografia computadorizada (TC) ou ressonância magnética (RM) de pescoço, com uso de contraste, e radiografia de tórax[25].  
A tomografia com emissão de pósitrons (PET-CT) não é essencial na avaliação inicial de doentes com suspeita de CECP primário na prática clínica, mesmo considerando-se meta-análise dos resultados de seis estudos que comparam o desempenho diagnóstico do PET-CT e os outros métodos de estadiamento com boa sensibilidade (83%-89%) e especificidade (89%-96%) para esse exame[27, 28]. O uso do PET-CT com 18F-fluoro-desoxi-2-glicose (FDG) não é recomendado nestas Diretrizes, pela dificuldade de interpretação dos resultados quando positivos (alta absorção de FDG por causas fisiológicas, nódulos benignos da tireoide, paralisia de nervo craniano unilateral, inflamação, irradiação e procedimentos cirúrgicos recentes) ou negativos (falso-negativo por lesão na vizinhança de estruturas com alto metabolismo de glicose, obscurecimento da FDG por artefatos dentais e baixa avidez por FDG de alguns tumores)[29,30]. A presença de áreas hipermetabólicas após a irradiação confere pior prognóstico ao doente[31], mas não há demonstração que intervenções baseadas no resultado desse exame concorram para um maior controle da doença ou maior benefício clínico do que com outros métodos de imagem[32]. Ressaltese que o uso da PET-CT no câncer da cabeça e pescoço foi analisado pela Comissão Nacional de Incorporação de Tecnologias no SUS, com deliberação negativa, estando o  
relatório disponível em <u>http://conitec.gov.br/, assim como aqueles outros relatórios</u> relativos a esse uso em outras neoplasias malignas,.  
A indicação de exames endoscópicos adicionais (endoscopia digestiva alta e broncoscopia) deve ser reservada para doentes com sintomas sugestivos de acometimento adicional do trato aerodigestivo[33,34].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Em caso de CECP, a TC é método mais sensível do que o exame físico ou os métodos endoscópicos para definir o tamanho do tumor e sua relação com estruturas críticas profundas. A RM é mais precisa do que a TC na detecção de lesões superficiais e não é prejudicada pela presença de amálgama dental, sendo o método de eleição para avaliação de tumores da orofaringe e cavidade oral. Este exame é superior à TC na avaliação de extensão perineural ou perivascular da doença, invasão das cartilagens da laringe ou no tumor suspeito de acometer a mandíbula, base do crânio, coluna cervical ou órbita (tumores mais suprahioídeos)[35-37].  
A radiografia de tórax é indicada na avaliação inicial de todos os doentes com CECP; recomenda-se TC de tórax com contraste nos casos de doença avançada (estágio III ou IV) ao diagnóstico pelo maior risco de metástases e de outro tumor sincrônico do trato aerodigestivo; cintilografia óssea está indicada para doentes com suspeita clínica de acometimento ósseo pela doença; ultrassonografia ou TC abdominal está indicada no caso de icterícia, alterações de enzimas hepáticas, visceromegalia ou dor abdominal[35,36].  
Doentes com tumores de nasofaringe localmente avançados cursam com maior chance de metástase sistêmica e necessitam estadiamento mais detalhado.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O carcinoma epidermoide, também denominado escamocelular ou espinocelular, é o tipo histológico mais comum de câncer de cabeça e pescoço e inclui variantes queratinizantes (carcinomas bem diferenciados) e não queratinizantes, estas por vezes distinguíveis apenas por exame imuno-histoquímico de outras neoplasias malignas que podem acometer de modo primário ou secundário as estruturas da região: adenocarcinoma, melanoma, linfoma e sarcoma. O planejamento terapêutico deve ser feito baseado principalmente na histopatologia do tumor, não apenas em resultados de exame citopatológico.  
Na ausência de diferenciação escamosa, o diagnóstico de carcinoma epidermoide pode ser inferido por[38-40]:  
a) coexpressão de antígeno epitelial de membrana, proteína p63 e citoqueratinas 5-6 (qualquer intensidade) em tumor TTF-1-negativo; ou  
b) coexpressão de antíigeno epitelial de membrana e expressão difusa da proteína p63 e das citoqueratinas 5-6, independente do status TTF-1.  
Os tumores que acometem com maior frequência a cavidade nasal e seios paranasais são o estesioneuroblastoma (47%), adenocarcinoma (24%) e carcinoma indiferenciado (22%) e apresentam um prognóstico ruim mesmo com os melhores tratamentos disponíveis (ressecção cirúrgica por via endoscópica ou cranofacial, seguida

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
por irradiação isolada ou radioquimioterapia pós-operatória)[41,42]. Assim como as neoplasias malignas de glândulas salivares, raramente se tratam de carcinoma espinocelular, de forma que estão fora do escopo destas Diretrizes.  
4.3. Estadiamento  
O estadiamento dos tumores de cabeça e pescoço se faz pelos critérios do sistema TNM, da União Internacional Contra o Câncer (UICC). Os critérios variam a depender do tumor primário, sendo obtidos a partir de informações clínicas, endoscópicas e de métodos de imagem[43].  
4.3.1. Câncer de cavidade oral - mucosa bucal, trígono retromolar, alvéolo, palato duro, dois terços anteriores da língua, assoalho bucal e mucosa labial:  
a) Tumor primário (T):  
TX – tumor primário não avaliado; T0 - tumor primário não encontrado; Tis - Carcinoma in situ; T1 – Tumor de até 2 cm no maior diâmetro;  
T2 - Tumor maior que 2 cm mas de com até 4 cm no maior diâmetro; T3 - Tumor acima de 4 cm no maior diâmetro;  
T4a - Tumor que invade estruturas adjacentes: região cortical óssea (mandibular ou maxilar), musculatura extrínseca da língua (genioglosso, hioglosso, palatoglosso e estiloglosso), seio maxilar ou pele da face.  
T4b - Tumor que invade espaço mastigatório, placa pterigoide ou base do crânio ou lesão encarcerando a artéria carótida interna.  
b) Linfonodos (N): NX – linfonodos regionais não avaliados; N0 – ausência de metástases linfonodais; N1 – metástase linfonodal única, ipsilateral, com até 3 cm no maior diâmetro; N2 - metástase linfonodal única, ipsilateral, maior que 3 cm e com até 6 cm no maior diâmetro; metástase contralateral com até 6 cm no maior diâmetro ou metastases em múltiplos linfonodos com até 6 cm no maior diâmetro.  
N3 – metástase linfonodal acima de 6 cm no maior diâmetro. c) Metástase à distância (M): M0 – Ausência de metástase à distância; M1 – Presença de metástase à distância. d) Agrupamento: Estágio 0: Tis, N0, M0. Estágio I: T1, N0, M0. Estágio II: T2, N0, M0. Estágio III: T3, N0, M0; T1 a T3, N1, M0. Estágio IVA: T4A, N0 a N1, M0; T1 a T4A, N2, M0. Estágio IVB: T4B, N0 a N3, M0; T1 a T4A, N3, M0. Estágio IVC: T1 a T4A, N0 a N3, M1.  
4.3.2. Câncer de orofaringe - base da língua, amígdalas e palato mole:  
a) Tumor primário (T):  
TX – tumor primário não avaliado;  
T0 - tumor primário não encontrado;  
Tis - Carcinoma in situ;  
T1 – Tumor de até 2 cm no maior diâmetro;  
T2 - Tumor maior que 2 cm mas de com até 4 cm no maior diâmetro;  
T3 - Tumor acima de 4 cm no maior diâmetro ou acometendo face lingual da epiglote;  
T4a - Tumor que invade estruturas adjacentes: laringe, musculatura extrínseca da língua (genioglosso, hioglosso, palatoglosso e estiloglosso), músculo pterigoide medial, palato duro ou mandíbula.  
T4b - Tumor que invade músculo pterigoide lateral, placa pterigoide, porção lateral da nasofaringe, ou base do crânio ou lesão encarcerando a artéria carótida interna.  
b) Linfonodos (N):  
NX – linfonodos regionais não avaliados;  
N0 – ausência de metástases linfonodais;  
N1 – metástase linfonodal única, ipsilateral, com até 3 cm no maior diâmetro;  
N2 - metástase linfonodal única, ipsilateral, maior que 3 cm e com até 6 cm no maior diâmetro; metástase contralateral com até 6 cm no maior diâmetro ou metastases em múltiplos linfonodos com até 6 cm no maior diâmetro;  
N3 – metástase linfonodal acima de 6 cm no maior diâmetro.  
c) Metástase à distância (M): M0 – Ausência de metástase à distância; M1 – Presença de metástase à distância. d) Agrupamento: Estágio 0: Tis, N0, M0. Estágio I: T1, N0, M0. Estágio II: T2, N0, M0. Estágio III: T3, N0, M0; T1 a T3, N1, M0. Estágio IVA: T4A, N0 a N1, M0; T1 a T4A, N2, M0. Estágio IVB: T4B, N0 a N3, M0; T1 a T4A, N3, M0. Estágio IVC: T1 a T4A, N0 a N3, M1.  
4.3.3. Câncer de nasofaringe - rinofaringe, cavidade posterior das fossas nasais e cavum:  
a) Tumor primário (T): TX – tumor primário não avaliado; T0 - tumor primário não encontrado; Tis - Carcinoma in situ;  
T1 – Tumor restrito à nasofaringe ou se extendendo à ourofaringe ou cavidade nasal, mas sem envolvimento parafaríngeo;  
T2 - Tumor com acometimento parafaríngeo;  
T3 - Tumor acometimento de estruturas ósseas, base do crânio ou seio paranasal;  
T4 - Tumor com extensão intracraniana, ou acometendo nervos cranianos, hipofaringe, órbita, espaço mastigatório ou fossa infratemporal.  
b) Linfonodos (N):  
NX – linfonodos regionais não avaliados;  
N0 – ausência de metástases linfonodais;  
N1 – metástase linfonodal unilateral, com até 6 cm no maior diâmetro, acima da fossa supraclavicular;  
N2 - metástase linfonodal bilateral, com até 6 cm no maior diâmetro, acima da fossa supraclavicular;  
N3 - metástase linfonodal acima de 6 cm no maior diâmetro (N3a), ou em linfonodo da fossa supraclavicular (N3b).  
c) Metástase à distância (M): M0 – Ausência de metástase à distância; M1 – Presença de metástase à distância. d) Agrupamento: Estágio 0: Tis, N0, M0. Estágio I: T1, N0, M0. Estágio II: T1, N1, M0; T2, N0 ou N1, M0. Estágio III: T3, N0, M0; T1 a T3, N2, M0. Estágio IVA: T4, N0 a N2, M0; Estágio IVB: T1 a T4, N3, M0. Estágio IVC: T1 a T4, N0 a N3, M1.  
4.3.4. Câncer de hipofaringe - área pós-cricoide, seio piriforme e parede posterior da faringe:  
a) Tumor primário (T):  
TX – tumor primário não avaliado;  
T0 - tumor primário não encontrado;  
Tis - Carcinoma in situ;  
T1 – Tumor limitado a uma região anatômica da hipofaringe ou com até 2 cm no maior diâmetro;  
T2 - Tumor que acomete mais de uma região anatômica da hipofaringe ou estrutura contígua, ou com tamanho maior que 2 cm e até 4 cm no maior diâmetro sem fixação da hemilaringe;  
T3 - Tumor acima de 4 cm no maior diâmetro; lesão com fixação da hemilaringe; ou invasão do esôfago;  
T4a - Tumor que invade cartilagem cricoide ou tiroidea; osso hioide; glândula tireoide; ou partes moles centrais;  
T4b - Tumor que invade fascia pré-vertebral; estruturas mediastinais; ou encarcerando a artéria carótida interna.  
b) Linfonodos (N):  
NX – linfonodos regionais não avaliados;  
N0 – ausência de metástases linfonodais;  
N1 – metástase linfonodal única, ipsilateral, com até 3 cm no maior diâmetro;  
N2 - metástase linfonodal única, ipsilateral, maior que 3 cm e com até 6 cm no maior diâmetro; metástase contralateral com até 6 cm no maior diâmetro ou metastases em múltiplos linfonodos com até 6 cm no maior diâmetro.  
N3 – metástase linfonodal acima de 6 cm no maior diâmetro.  
c) Metástase à distância (M): M0 – Ausência de metástase à distância; M1 – Presença de metástase à distância. d) Agrupamento: Estágio 0: Tis, N0, M0. Estágio I: T1, N0, M0. Estágio II: T2, N0, M0. Estágio III: T3, N0, M0; T1 a T3, N1, M0. Estágio IVA: T4A, N0 a N1, M0; T1 a T4A, N2, M0. Estágio IVB: T4B, N0 a N3, M0; T1 a T4A, N3, M0. Estágio IVC: T1 a T4A, N0 a N3, M1.  
4.3.5. Câncer de laringe - supraglote, glote e subglote: a) Tumor primário (T): TX – tumor primário não avaliado; T0 - tumor primário não encontrado; Tis - Carcinoma in situ; Região supraglótica: T1 – Tumor limitado a uma região anatômica da supraglote, com mobilidade normal da corda vocal;  
T2 - Tumor que acomete mais de uma região anatômica da supraglote, gloteou estruturas adjascentes (mucosa da base da língua, valécula, parede medial do seio piriforme), mas sem fixação da laringe;  
T3 - Tumor limitado à laringe com fixação da corda vocal, ou invadindo área poscricoide, espaço pré-epiglote, espaço paraglótico ou cartilagem tiroidea.  
T4a - Tumor que ultrapassa cartilagem tiroidea ou invadindo estruturas além da laringe: traqueia, partes moles do pescoço, musculatura profunda da língua, musculatura infrahioide, glândula tireoide ou esôfago.  
T4b - Tumor que invade espaço pré-vertebral; estruturas mediastinais; ou encarcera a artéria carótida interna.  
Região glótica:  
T1 – Tumor limitado a uma (T1a) ou ambas cordas vocais (T1b), com mobilidade normal;  
T2 - Tumor que acomete supraglote ou subglote, com mobilidade reduzida da corda vocal;  
T3 - Tumor limitado à laringe com fixação da corda vocal, ou que invade o espaço paraglótico ou cartilagem tiroidea.  
T4a - Tumor que ultrapassa a cartilagem tiroidea ou invadindo estruturas além da laringe: traqueia, partes moles do pescoço, musculatura profunda da língua, musculatura infrahioide, glândula tireoide ou esôfago.  
T4b - Tumor que invade o espaço pré-vertebral; estruturas mediastinais; ou encarcera a artéria carótida interna.  
Região subglótica:  
T1 – Tumor limitado à subglote;  
T2 - Tumor que invade corda vocal;  
T3 - Tumor limitado à laringe com fixação da corda vocal;  
T4a - Tumor que invade cartilagem cricoide ou tiroidea ou invade estruturas além da laringe: traqueia, partes moles do pescoço, musculatura profunda da língua, musculatura infrahioide, glândula tireoide ou esôfago.  
T4b - Tumor que invade o espaço pré-vertebral; estruturas mediastinais; ou encarcera a artéria carótida interna.  
b) Linfonodos (N):  
NX – linfonodos regionais não avaliados;  
N0 – ausência de metástases linfonodais;  
N1 – metástase linfonodal única, ipsilateral, com até 3 cm no maior diâmetro;  
N2 - metástase linfonodal única, ipsilateral, maior que 3 cm e com até 6 cm no maior diâmetro; metástase contralateral com até 6 cm no maior diâmetro ou metastases em múltiplos linfonodos com até 6 cm no maior diâmetro.  
- N3 – metástase linfonodal acima de 6 cm no maior diâmetro.  
c) Metástase à distância (M):  
M0 – Ausência de metástase à distância;  
M1 – Presença de metástase à distância.  
d) Agrupamento por Estágios:  
|Estág<br>io|Tumor (T)|Invasão<br>Linfática<br>(N)|Metástase à<br>distância<br>(M)|
|---|---|---|---|
|0|Tis|N0|M0|
|I|T1|N0|M0|
|II|T2|N0|M0|
|III|T3|N0|M0|
||T1 a T3|N1|M0|
|IVA|T4A|N0 a N1|M0|
||T1 a T4A|N2|M0|
|IVB|T4B|N0 a N3|M0|
||T1 a T4A|N3|M0|
|IVC|T1 a T4A|N0 a N3|M1|

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Recomenda-se registrar as seguintes características clínicas de importância prognóstica no CECP: capacidade funcional e estado nutricional do doente, acometimento linfonodal, margens cirúrgicas e presença de extravasamento capsular [1,22,44].  
Estudos retrospectivos identificaram características clínicas e tumorais associadas ao prognóstico de doentes com CECP, estando em avaliação o uso de painéis de

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
expressão multigênica[44-46], mas nenhuma recomendação para uso na prática clínica pode ser feita pela ausência de estudos de validação externa empregando métodos diagnósticos disponíveis no Brasil.  
O CECP de orofaringe associado ao HPV parece estar associado com menor extensão do tumor e maior acometimento nodal ao diagnóstico[47]. Em países desenvolvidos, o histórico de tabagismo não é tão comum nestes casos, e os doentes se apresentam inicialmente com capacidade funcional preservada e cursam com melhor prognóstico[17].  
Não se recomenda a pesquisa rotineira de evidência molecular de infecção por HPV no CECP, uma vez que não se indica mudança de conduta terapêutica com base nesta informação[48].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Hospitais gerais com serviço de cirurgia de cabeça e pescoço, otorrinolaringologia ou cirurgia oncológica podem realizar o diagnóstico, estadiamento e tratamento cirúrgico do CECP, devendo atuar em cooperação técnica, referência e contra-referência com hospitais habilitados como UNACON com serviço de radioterapia ou CACON, instituições que realizam o tratamento cirúrgico e clínico de doentes com CECP em todos os estágios da doença.  
Recomenda-se o encaminhamento urgente para tais hospitais dos pacientes que apresentem um dos seguintes critérios[22,49]:  
a) placas ou manchas brancacentas ou eritematosas na mucosa oral que persistam por mais de três semanas, em qualquer localização, particularmente se indolores;  
b) ulceração da mucosa oral ou orofaringe que persista por mais de três semanas;  
c) edemas da mucosa oral que persistam por mais de três semanas;  
d) mobilidade dentária inexplicada, não associada com doença periodontal;  
e) dor ou desconforto persistente na garganta, particularmente se unilateral ou há mais de quatro semanas;  
f) disfagia que persista por mais de três semanas;  
g) rouquidão que persista por mais de três semanas;  
h) estridor laríngeo, condição que requer encaminhamento imediato;  
i) linfadenomegalia cervical que persista por mais de três semanas;  
j) secreção nasal serosanguinolenta unilateral que persista por mais de três  
semanas;  
k) paralisia facial, hipoestesia ou dor facial grave;  
l) tumorações orbitais; ou  
m) otalgia sem evidências de anormalidades ao exame físico e otoscopia.  
A detecção e o tratamento precoce do CECP melhoram o prognóstico da doença. O atraso mais comum costuma ser no acesso ao serviço especializado em otorrinolaringologia ou cabeça e pescoço, o que se dá por atraso do paciente em procurar atendimento médico ou odontológico após início dos sintomas, e retardo no encaminhamento ao serviço especializado[49,50].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
As principais modalidades terapêuticas do CECP são a cirurgia e a radioterapia, visando à erradicação da doença no sítio primário e na rede de drenagem linfática próxima ao tumor. A cirurgia tem a vantagem de permitir o estadiamento patológico do pescoço, evitando o tratamento desnecessário com radiação e indicando os casos em que a radioterapia adjuvante deve ser empregada. A ressecção cirúrgica de linfonodos cervicais observa os seguintes conceitos[51,52]:  
a) esvaziamento cervical radical (ECR): ressecção dos linfonodos cervicais de todos os cinco níveis, juntamente com o músculo esternocleidomastoideo (ECM), veia jugular interna (VJI) e nervo acessório espinhal (NAS);  
b) esvaziamento cervical radical modificado (ECRm): modificação do ECR com a preservação de uma ou mais estruturas não linfáticas. Há três variantes do procedimento, segundo a preservação do NAS (ECRm tipo I), preservação do SAN e da VJI (ECMr tipo II), ou preservação das três estruturas não linfáticas (ECRm tipo III);  
c) esvaziamento cervical seletivo (ECS): modificação do ECR com preservação de um ou mais grupos de linfonodos, que seriam removidos no ECR. Há três variantes do procedimento: esvaziamento cervical supra-omo-hioideo (ECSsoh), com ressecção dos linfonodos nos níveis I a III; esvaziamento cervical lateral (ECSl), com remoção dos linfonodos de nível II a IV; e esvaziamento cervical posterior (ECSp), com ressecção dos níveis linfáticos de II a V; e  
d) esvaziamento cervical radical estendido (ECRe): remoção de linfonodos adicionais (gânglios occipitais ou parotídeos) ou estruturas não-linfáticas não incluídas no ECR. A radioterapia confere chance de controle locorregional do CECP. O principal desafio para esse tratamento é a necessidade de aplicação de doses de radiação relativamente altas em tumores (ou áreas de risco) de localizações muito próximas a estruturas críticas, como a base do crânio, medula espinhal, tronco cerebral e aparato óptico. O planejamento ou a técnica de radioterapia utilizados podem impactar na qualidade de vida, dado o potencial de lesão de estruturas responsáveis pela produção de saliva, paladar, função oral, audição, fala e deglutição.  
Em tese, a técnica de radioterapia de intensidade modulada (IMRT) parece particular e idealmente moldada para o tratamento do CECP, porque permitiria um escalonamento de dose em regiões de interesse, além de poupar áreas de risco, se comparada com a técnica de radioterapia conformacional tridimensional (RT3D), uma vez que há a possibilidade de aplicação de grandes gradientes de dose e concavidades na região de aplicação da radiação. No entanto, a superioridade da técnica IMRT fica restrita à toxicidade (principalmente xerostomia), não havendo diferenças claramente demonstradas, até o momento, no tocante ao controle local, sobrevida livre de doença ou sobrevida global dos pacientes[53-62]. Em contrapartida, os pacientes submetidos à IMRT apresentam níveis superiores de fadiga aguda, provavelmente relacionada a maior dose de radiação em tecidos não tumorais, que pode teoricamente aumentar o risco para neoplasias secundárias[63]. A experiência clínica com IMRT é recente, e não há informações confiáveis sobre a segurança e eficácia de longo prazo desta técnica para que possa ser recomendada no contexto destas Diretrizes.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Na presença de acometimento linfonodal, podem ser usados fracionamentos de dose alternativos, como esquemas acelerados ou hiperfracionados. O benefício de sobrevida destas estratégias de tratamento, em comparação ao tratamento padrão, está restrito àqueles pacientes que toleram o tratamento sem redução da dose total de radiação aplicada. Como se espera nestes casos um aumento considerável da toxicidade aguda associada ao tratamento, são necessários uma criteriosa seleção de doentes para sua indicação e o acompanhamento multiprofissional intensivo do paciente[64,65].  
A braquiterapia de alta taxa de dose tem sido utilizada, isoladamente ou como reforço (“boost”) associada à teleterapia, no tratamento pós-operatório em pacientes considerados de alto risco para recidiva, particularmente se houve margens cirúrgicas positivas. No entanto, seu uso como tratamento adjuvante não é recomendado uma vez que sua eficácia e segurança de longo prazo não foram avaliadas em estudos prospectivos de radioquimioterapia pós-operatória[66]. Seu uso tem sido no tratamento da recidiva tumoral no sítio primário, em áreas previamente irradiadas, isoladamente ou em associação à teleterapia, quando são limitadas as opções de tratamento[66-68].  
As orientações a seguir aplicam-se ao tratamento do CECP que acomete a cavidade oral, orofaringe, laringe, hipofaringe e nasofaringe.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Conduta terapêutica do tumor primário [67, 69-74]:  
a) CECP de cavidade oral: recomenda-se a ressecção cirúrgica da região acometida com margem de segurança de pelo menos 1 cm.  
b) CECP de orofaringe: recomenda-se cirurgia ou radioterapia, pois o controle locorregional da doença é similar. Enfatiza-se que tal informação é baseada apenas em estudos retrospectivos, pois não há estudos comparativos randomizados entre cirurgia e radioterapia nesta indicação, sendo importante considerar em cada caso as sequelas prováveis do tratamento.  
c) CECP de nasofaringe: a irradiação do sítio primário e drenagem linfática é o tratamento de eleição, sendo a cirurgia empregada excepcionalmente para remover doença residual.  
d) CECP de hipofaringe: a irradiação do sítio primário e drenagem linfática é o tratamento de eleição, sendo a cirurgia empregada excepcionalmente para remover doença residual.  
e) CECP de laringe: recomenda-se a irradiação do sítio primário para preservação do órgão, nos doentes em estágio I ou no estágio II não elegíveís para procedimento cirúrgico, ou a cirurgia. A ressecção pode ser conservadora (cordectomia, laringectomia frontal, laringectomia lateral, laringectomia frontolateral, epiglotectomia e laringectomia parcial supraglótica) ou radical (laringectomia supracricoide com cricohioide-epiglotepexia, laringectomia quase total e laringectomia total), segundo apresentação clínica do tumor, condições clínicas e preferência do doente. Nos casos de tumor da glote e supraglote, pode ser indicada a ressecção endoscópica por laser de CO2.  
f) Recomenda-se radioterapia isolada no tratamento definitivo do CECP localizado, podendo ser considerado o seu uso com quimioterapia sensibilizante no pós-

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
operatório se houver margem cirúrgica acometida ou extravasamento capsular linfonodal.  
Abordagem do pescoço[51,52,74-77]:  
A incidência de invasão linfonodal é alta nos CECP de cavidade oral, orofaringe e hipofaringe, mesmo no estágio inicial da doença, sendo recomendável realizar minimamente ECSsoh em todos os casos cirúrgicos. Pacientes com tumor primário de língua podem apresentar metástase isolada para o nível IV (“skip metastases”), devendo-se considerar também a ressecção dos linfonodos deste nível.  
Como a técnica de pesquisa de linfonodo sentinela requer análise de cortes seriados do linfonodo por métodos morfológicos convencionais e de imunohistoquímica, não sendo suficiente a análise transoperatória de espécimes por congelação ou “imprint”, não é recomendada nestas Diretrizes.  
O esvaziamento bilateral deve ser considerado no tratamento eletivo de tumores que acometem estruturas da linha média, e em pacientes com metástase cervical ipsilateral clinicamente manifesta.  
No CECP de laringe com doença clinicamente N0, recomenda-se o ECS lateral ou posterior nos casos com doença T2 supraglótica com acometimento epilaringeal, T3-4 supraglótica e tumores T4 glóticos; pode-se considerar a omissão da dissecção linfonodal do nível IV, pelo maior risco de fístula quilosa e paralisia do nervo frênico com o procedimento, pelo baixo risco de metástase oculta nestes linfonodos. A ressecção eletiva dos linfonodos do nível I deve ser reservada aos casos clinicamente suspeitos de acometimento secundário[78-81].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tratamento do câncer de cavidade oral é geralmente cirúrgico, seguido ou não por radioterapia adjuvante, enquanto o câncer de orofaringe, mais propenso a ser avançado no momento do diagnóstico, em geral é tratado por irradiação isolada ou radioquimioterapia. A cirurgia para o câncer da cavidade oral pode ser desfigurante, mas tanto a cirurgia quanto a radioterapia podem resultar em comprometimento funcional significativo, com prejuízo da capacidade para comer, beber e conversar.  
A radioquimioterapia é o tratamento recomendável para CECP de nasofaringe, com irradiação do sítio primário e drenagem linfática.  
A cirugia é a modalidade de tratamento principal para doentes com câncer de hipofaringe (laringectomia total com faringectomia parcial ou faringolaringectomia) e laringe (laringectomia quase total ou laringectomia total), mas cirurgias com preservação do órgão da fonação podem ser oferecidas ao doente, desde que ele conte com acompanhamento multiprofissional.  
As seguintes orientações devem ser observadas:  
a) Nos casos em que o tumor for ressecável, cirurgia com finalidade radical e radioterapia ou radioquimioterapia pós-operatória. A radioquimioterapia pós-operatória se comparada à radioterapia isolada está associada a maior controle da doença locorregional e menor risco de morte (razão de risco = 0,77; intervalo de confiança de 95%: 0,66 a 0,80, p = 0,0008), sendo em particular preferível se os resultados da

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
cirurgia forem de alto risco para recidiva: presença de extensão tumoral extracapsular nodal ou ressecção R1[70,82].  
b) Nos casos em que o tumor for irressecável, houver intenção de preservação de órgão ou quando o resultado funcional previsto ou o prognóstico for tão pobre que uma cirurgia mutilante não seja justificável, recomenda-se radioquimioterapia.  
c) A radioquimioterapia, sempre que indicada, deve empregar preferencialmente esquema quimioterápico baseado em platina, em monoterapia ou associada com fluoropirimimidina. Nos doentes clinicamente incapazes para tratamento com derivados da platina, há a alternativa da radioterapia isolada ou associada com agente  único sensibilizante à radiação: fluoruracila, paclitaxel, mitomicina C, gemcitabina ou cetuximabe[83-88]. Ressalte-se que o uso do cetuximabe no câncer da cabeça e pescoço foi analisado pela Comissão Nacional de Incorporação de Tecnologias no SUS, com deliberação negativa, estando os relatórios disponíveis em http://conitec.gov.br/.  
d) Após a radioquimioterapia, havendo suspeita clínica ou radiológica de doença residual linfonodal, recomenda-se a dissecção por ECR, ECRm ou ECS[89]. Nos pacientes que atingiram resposta clínica completa, deve-se optar pela conduta expectante, mesmo na doença clínica inicial N2 ou N3; havendo indicação de linfadenetomia, deve-se realizar o procedimento entre 4 e 12 semanas após a radioquimioterapia, intervalo entre os efeitos adversos agudos e crônicos da irradiação, para minimizar o risco de complicações cirúrgicas[90-93].  
e) O procedimento cirúrgico para linfadenectomia acrescenta morbidade ao tratamento, dificultando o retorno à alimentação oral[94]. Deve-se ter em conta que a ressecção de estruturas não linfáticas, notadamente SCM e NAS, aumenta o risco de queda de ombro, limitação da abdução do braço e queixas cervicais como rigidez, dor e parestesia; mesmo o ECRm ou ECSsoh aumenta a morbidade tardia do tratamento, com limitação da mobilidade cervical e da função do ombro[95, 96].  
A quimioterapia prévia não é recomendada como tratamento inicial padrão para a maioria dos doentes com CECP avançado, pois sua morbidade é elevada e não está associada a benefício clínico inequívoco em termos de melhora estatisticamente significativa na sobrevida global, recidiva locorregional ou na sobrevida livre de doença[97, 98].  
A quimioterapia prévia pode ser considerada nas seguintes situações[99-103]:  
a) nos casos de câncer de laringe ou de hipofaringe, na intenção de preservação de órgão em pacientes que de outra forma seriam candidatos a laringectomia total, sem invasão extensa da cartilagem laríngea, quando o doente for considerado inapto para radioquimioterapia ou se o tratamento combinado não for imediatamente disponível;  
b) nos casos de câncer de cavidade oral ou de orofaringe em estágio clínico IV, em pacientes com boa capacidade funcional (ECOG 0 ou 1) que de outra forma seriam candidatos à radioquimioterapia, quando a radioterapia não for imediatamente disponível;  
c) nos casos de câncer de nasofaringe, em que o tratamento está associado a redução do risco de metástase à distância e ganho de sobrevida, apesar de não reduzir a taxa de recidiva local.  
Quando for indicada a quimioterapia prévia, a escolha do esquema terapêutico deve observar o protocolo local multiprofissional de preservação de órgão, visto que as falhas de tratamento requerem quase sempre resgate cirúrgico oportuno.  
Recomenda-se avaliação endoscópica após cada ciclo de quimioterapia, prosseguindo-se após dois ciclos apenas se houver atingido resposta parcial ou completa. Os seguintes cuidados devem ser observados:  
a) Os pacientes que apresentarem progressão local de doença a qualquer tempo ou doença estável após dois ciclos de quimioterapia devem ser preferencialmente submetidos à cirurgia com radioterapia pós-operatória (50-70 Gy).  
b) Os pacientes com uma resposta parcial após três ou quatro ciclos de quimioterapia podem ser encaminhados para tratamento cirúrgico com radioterapia pósoperatória (50-70 Gy) ou para radioquimioterapia.  
c) Os pacientes com uma resposta completa após três ou quatro ciclos de quimioterapia devem receber irradiação com finalidade radical (70 Gy).  
A quimioterapia prévia deve empregar esquema quimioterápico baseado em platina (cisplatina ou carboplatina), contendo dois ou três medicamentos (ácido folínico, bleomicina, capecitabina, ciclofosfamida, docetaxel, doxorubicina, epirrubicina, fluoruracila, gencitabina, metotrexato, paclitaxel, vincristina ou vinorrelbina), por 3-4 ciclos, sendo seguida por radioterapia isolada ou radioquimioterapia no doente responsivo ao tratamento sistêmico[86,97,101,104-107].  
O uso de combinações contendo taxano (docetaxel ou paclitaxel) na quimioterapia prévia, se comparado ao tratamento com cisplatina e fluoropirimidina (fluoruracila ou capecitabina), resulta em maior toxicidade clínica, notadamente neutropenia febril, com taxa equivalente de presevação de laringe, mas está associado a maior sobrevida global[108,109]. Meta-análise com dados individuais de 1.772 pacientes incluídos em cinco ensaios clínicos randomizados que avaliaram a adição de taxano à associação de cisplatina e fluoruracila identificou um benefício de sobrevida global absoluta de 7,4% em 5 anos para esquemas com taxano (35,0% versus 42,4%)[110].  
A quimioterapia adjuvante não é recomendada após tratamento locorregional definitivo com cirurgia ou radioquimioterapia, pois, a despeito de sua morbidade, não reduz a chance de recidiva a distância ou morte pela doença[100,101,104,111,112].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A ressecção cirúrgica sempre que tecnicamente possível e aceita pelo paciente é o tratamento de eleição para doentes com recidiva locorregional, cursando com taxa de sobrevida em 5 anos de 39% [113].  
Casos de recidiva nodal cervical mesmo com linfadenectomia prévia podem se beneficiar de um segundo esvaziamento cervical. Irradiação pós-operatória pode ser indicada se houver vários linfonodos positivos ou extensão perinodal da doença. A experiência na literatura é limitada, mas sugere que até um terço dos pacientes logram sobrevida prolongada com retratamento radical [114].  
A ressecção de metástase pulmonar no CECP pode beneficiar alguns doentes, notadamente quando possível realizar uma ressecção R0. A medida é de indicação

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
questionável nos casos que haviam sido diagnosticados em estágio III ou IV, no CECP de cavidade oral e na presença de múltiplas lesões metastática [115].  
O CECP é uma doença pouco sensível à terapia antineoplásica sistêmica, o que limita a utilidade da quimioterapia paliativa. Estudos clínicos com monoterapia na doença recidivada ou metastática indicam que os medicamentos mais ativos são o metotrexato, cisplatina, fluorouracila, bleomicina, paclitaxel e docetaxel. Estes medicamentos produziram taxas de resposta da ordem de 20%-30%, de curta duração (3-5 meses) e apenas raramente respostas completas. Nenhum desses medicamentos resultou em vantagem clínica sobre o tratamento com metotrexato como agente único, que continua a ser o medicamento de escolha para a maioria dos pacientes com doença recidivada ou metastática [116, 117].  
Na doença metastática, emprega-se quimioterapia paliativa com esquema terapêutico adequado à condição clínica, capacidade funcional e preferência do doente, podendo ser utilizada monoterapia (metotrexato, derivado de platina ou taxano) ou poliquimioterapia baseada em platina [116, 118].  
A quimioterapia paliativa empregando dois ou mais medicamentos deve ser reservada aos pacientes sem limitação clínica para receber esquemas com derivados da platina, capacidade funcional preservada (escala Zubrod 0 ou 1), preferencialmente nas apresentações clínicas em que a obtenção de resposta objetiva tumoral concorra para a paliação de sintomas [119].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A radioterapia é a principal modalidade terapêutica para o carcinoma da nasofaringe, que historicamente resulta no controle da doença para 50%-70% dos casos [120]. Séries de casos empregando técnicas de irradiação - RT3D e IMRT - registram maiores taxas de controle locorregional da doença, com preservação significativa das glândulas salivares e outros tecidos normais críticos nas proximidades, sem vantagem de uma técnica sobre a outra em termos de ganho de sobrevida global ou sobrevida livre de metástases [53, 62].  
O uso de quimioterapia radiosensibilizante se comparado à radioterapia isolada resulta em maior controle locorregional, com impacto controverso para a sobrevida global. Meta-análises não identificaram, porém, benefício em termos de redução do risco de recorrência à distância ou morte com a radioquimioterapia [120-122]. Estes resultados podem não refletir os obtidos com a substituição da técnica de radioterapia convencional pela RT3D ou IMRT e usando-se quimioterapia concomitante. O tratamento combinado pode ser indicado para doentes com boa capacidade funcional (escala Zubrod 0 ou 1) e clinicamente capazes de receber quimioterapia baseada em cisplatina.  
A quimioterapia prévia à radioquimioterapia no carcinoma de nasofaringe empregando esquemas baseados em platina está associada com um ganho absoluto de 5% na sobrevida global em 3 anos [100, 121]. Tal benefício parece ser restrito ao tratamento com esquemas contendo taxano [123], visto que houve redução do risco de recidiva, mas não de morte, quando analisados os estudos que empregaram apenas cisplatina e fluoruracila [124].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A quimioterapia adjuvante à radioquimioterapia não confere benefícios clínicos relevantes e não deve ser indicada para doentes com carcinoma de nasofaringe [100, 125, 126].  
A ressecção cirúrgica seguida ou não de irradiação é a modalidade terapêutica de escolha para a recidiva locorregional do CECP de nasofaringe, estando associada a taxa de sobrevida em 5 anos de 51% [127].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A mucosite é a complicação mais clínica mais frequente do tratamento clínico do CECP. Aparece tipicamente 10 a 14 dias após o início da terapia antineoplásica sistêmica contendo fluoropirimidina (fluoruracila ou capecitabina) e após dose cumulativa de 30-45 Gy de radiação, comprometendo a qualidade de vida e podendo motivar a interrupção do tratamento [128]. A mucosite é auto-limitada, quando não complicada por infecção secundária, e geralmente cicatriza em 2 a 4 semanas após a interrupção do tratamento [128, 129].  
Recomenda-se avaliação odontológica, tratamento imediato de condições clínicas odontológicas de risco antes do tratamento com quimioterapia ou radioterapia, e adoção de medidas profiláticas para minimizar o risco e a gravidade da lesão, que incluem [129-131]:  
a) orientação para uma boa higiene oral;  
b) evitar alimentos e bebidas quentes, picantes, com acidez pronunciada, e de consistência dura.  
c) utilizar cremes dentais insípidos ou com sabor suave;  
d) utilizar de solução salina ou com bicarbonato de sódio em colutórios, 3 ou 4 vezes por dia;  
e) aplicação tópica de agentes anestésicos (lidocaína a 2% ou solução de difenidramina), devendo-se preferir a administração focal ao uso tópico oral generalizado;  
e) tratamento precoce da mucosite com laser de baixa intensidade.  
As seguintes intervenções são de utilidade clínica controversa e não são recomendadas [132]:  
a) crioterapia;  
b) uso de suplementos com glutamina;  
c) uso de sucralfato ou pastilhas de antibióticos;  
d) uso tópico de fatores de crescimento de granulócitos-macrófagos.  
Analgésicos sistêmicos devem ser administrados quando o uso tópico não for suficiente para o alívio dos sintomas. Deve-se preferir o uso de opioides em detrimento aos anti-inflamatórios não esteroidais (AINE) no controle da dor relacionada à mucosite, pois AINE podem afetar adversamente a adesão plaquetária a produzir lesões da mucosa gástrica, particularmente se houver plaquetopenia, sem melhorar o controle dos sintomas [133].  
Embora não haja evidência de que a analgesia controlada pelo paciente com mucosite seja mais benéfica do que outro método de infusão contínua de opioide para o

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
controle da dor, nestes casos os pacientes utilizam doses menores de opioide por hora, têm duração mais curta dos episódios de dor e apresentam menos efeitos colaterais relacionados aos opioides [129]. Pode-se considerar o uso de medicamentos adjuvantes, tais como antidepressivos tricíclicos e gabapentina, no controle da dor pela mucosite induzida por radiação [134-136].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Doentes com CECP muitas vezes apresentam-se ao diagnóstico com estado nutricional comprometido, como descrito por perda de peso, medidas de composição corporal, inquérito alimentar, presença de sintomas que afetam a ingesta oral, marcadores de inflamação sistêmica e alterações do metabolismo. Há poucos estudos clínicos avaliando o papel de intervenções profiláticas no estado nutricional destes pacientes [137], insuficientes para recomendação conclusiva a respeito.  
A literatura disponível demonstra que o suporte nutricional está associado com melhor tolerância ao tratamento e melhoria da qualidade de vida. Uma análise não planejada de 1.073 pacientes tratados com radioterapia definitiva no protocolo 90-03 do _Radiation Therapy Oncology Group_ (RTOG) mostrou que a terapia nutricional iniciada antes da irradiação resultou em menor perda de peso, maior taxa de conclusão do tratamento e uma menor incidência de mucosite grave após a conclusão da terapia [138]. No entanto, no mesmo estudo verificou-se maior probabilidade de recidiva locorregional e morte entre os doentes que receberam terapia nutricional precoce, sugerindo que esta intervenção possa ter um impacto negativo nos resultados da terapia contra o câncer. Recomenda-se que o suporte nutricional enteral para doentes com CECP seja indicado com cautela, com finalidade terapêutica.  
Quando indicada a suplementação nutricional, a gastrostomia endoscópica percutânea (GEP) ou a gastrostomia cirúrgica percutânea (GCP), por via aberta ou laparoscópica, devem reservadas para os casos em que se antecipa a necessidade de suporte nutricional enteral por período maior que seis semanas [139]. A inserção de sonda nasoenteral (SNE) para alimentação pode ser indicada para períodos mais curtos de terapia nutricional enteral [140]. O uso da SNE está associado a um maior desconforto do paciente e um maior risco de broncoaspiração da dieta; no entanto, uma revisão Cochrane não encontrou evidências suficientes para determinar superioridade entre GEP, GCP ou SNE [141]. A instalação profilática de GEP em comparação com sua indicação terapêutica, restrita aos casos que apresentam disfagia, odinofagia, trismo ou desnutrição, parece resultar em maior custo pelo uso precoce de dietas enterais e em menor taxa de ingestão oral durante o primeiro ano [142, 143].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O exame clínico assistido por métodos endoscópicos é necessário durante a quimioterapia prévia e após a radioterapia do CECP.  
O método de imagem considerado mais útil no estadiamento inicial, TC ou RM, deve ser o usado para avaliar a resposta da doença ao término da quimioterapia prévia e durante o tratamento sistêmico paliativo, bem como no seguimento após cirurgia, irradiação ou radioquimioterapia.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Após radioquimioterapia, em 8 a 12 semanas, deve-se realizar biópsia endoscópica do sítio primário da doença e exame clínico e radiológico (ultrasonografia, TC ou RM) do pescoço; na suspeita de acometimento nodal residual, está indicado o exame citológico de punção por agulha fina ou esvaziamento cervical.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O plano de acompanhamento por exames de imagem com exposição à radiação deve ser definido em base individual e sempre ser justificado em termos de benefício clínico provável, para se evitar riscos desnecessários por exposição à radiação ionizante. Recomenda-se a realização periódica de nasofibroscopia, laringoscopia e radiografia de tórax no seguimento após cirurgia ou radioquimioterapia, com frequência mínima trimestral nos primeiros dois anos e semestral no 3º, 4º e 5º anos. Esofagoscopia, esofagograma e broncoscopia podem ser reservados para pacientes com sintomas novos associados ao trato aerodigestivo [33, 34].  
No estudo mais amplo publicado, com 40.287 pacientes, a prevalência de segundo tumor maligno primário (STP) foi de 14,2%, em 40.287 pacientes, a maioria sendo metacrônica e detectada nos primeiros dois anos de seguimento. STP de cabeça e pescoço foi a ocorrência mais comum, acometendo principalmente doentes com CECP primário de cavidade oral, orofaringe e hipofaringe [144]. Recomenda-se vigilância clínica permanente para STP do trato aerodigestivo após tratamento do CECP de cavidade oral, orofaringe e hipofaringe, bem como para câncer de pulmão e STP do trato aerodigestivo no câncer de laringe.  
Todos os doentes com CECP tabagistas ou etilistas devem ser esclarecidos sobre a importância da mudança de estilo de vida, com cessação destes hábitos, para reduzir o risco de desenvolver STP [145, 146].

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Doentes com diagnóstico de CECP devem ser preferencialmente atendidos em hospitais habilitados como CACON ou UNACON com radioterapia, com porte tecnológico suficiente para diagnosticar, tratar e realizar o seu acompanhamento. Se atendidos em hospitais gerais, estes devem atuar em cooperação técnica, referência e contra-referência com hospitais habilitados em oncologia e radioterapia.  
Além da familiaridade que esses hospitais guardam com o estadiamento, o tratamento, o manejo das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
Os procedimentos radioterápicos e quimioterápicos (Grupo 03, Subgrupo 04) e cirúrgicos (Grupo 04 e os vários subgrupos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e OPM do SUS podem ser acessados, por código do procedimento e por código da CID – Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde – para a respectiva neoplasia maligna, no SIGTAP-Sistema de Gerenciamento dessa Tabela

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
(http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), mensalmente disponibilizada.  
com versão  
Os seguintes procedimentos da tabela do SUS estão disponíveis para a quimioterapia de adultos com CECP, sendo que os procedimentos de quimioterapia prévia são também compatíveis com a quimioterapia concomitante à radioterapia[147]:  
− 03.04.04.006-1 – Quimioterapia (prévia) do carcinoma epidermoide de seio paranasal, laringe, hipofaringe, orofaringe e cavidade oral;  
− 03.04.04.008-8 - Quimioterapia (prévia) do carcinoma de nasofaringe;  
− 03.04.02.015-0 - Quimioterapia (paliativa) do carcinoma de nasofaringe avançado;  
− 03.04.02.020-6 – Quimioterapia (paliativa) do carcinoma epidermoide de cabeça e pescoço avançado(doença locorregionalmente avançada, metastática ou recidivada).  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e avaliação.  
Ações de controle e avaliação incluem, entre outras: a manutenção atualizada no Sistema do Cadastro Nacional dos Estabelecimentos de Saúde (SCNES), a autorização prévia dos procedimentos e o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos).  
Ações de auditoria devem verificar in loco, por exemplo, a existência e observância da regulação do acesso assistencial; a qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); a compatibilidade do procedimento codificado com o diagnóstico de câncer renal e perfil clínico do doente (classificação UISS, capacidade funcional, estadiamento, indicação clínica para tratamento), o esquema terapêutico e as doses diárias prescritas e fornecidas; a compatibilidade do registro dos procedimentos com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Exceto pela Talidomida para o tratamento do Mieloma Múltiplo, pelo Mesilato de Imatinibe para a quimioterapia do Tumor do Estroma Gastrointestinal (GIST), da Leucemia Mieloide Crônica e da Leucemia Linfoblástica Aguda cromossoma Philadelphia positivo, pelo Trastuzumabe para a quimioterapia do carcinoma de mama inicial e locorregionalmente avançado, pelo Rituximabe para a quimioterapia do Linfoma Difuso de Grandes Células-B e do Linfoma Folicular e dos Dasatinibe e Nilotinibe para a quimioterapia da Leucemia Mieloide Crônica de adultos, o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar  
conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do medicamento antineoplásico é desse hospital, seja ele público ou privado, com ou sem fins lucrativos [147].  
10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)  
É obrigatória a informação ao paciente ou ao seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao tratamento do CECP, notadamente quanto aos riscos imediatos e sequelas de procedimentos cirúrgicos e da radioterapia, assim como quanto ao uso de medicamentos antineoplásicos isoladamente ou em associação com irradiação.

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
[1] Bergamasco V, Marta GN, Kowalski LP, Carvalho AL. Epidemiological profile of the head and neck cancer in the State of São Paulo. Rev Bras Cir Cabeça Pescoço, 2008; 37(1):15-9.  
[2] Carvalho AL, Ikeda MK, Magrin J, Kowalski LP. Trends of oral and oropharyngeal cancer survival over five decades in 3267 patients treated in a single institution. Oral Oncol, 2004; 40(1):71-6.  
[3] Hashibe M, Hunt J, Wei M, Buys S, Gren L, Lee YC. Tobacco, alcohol, body mass index, physical activity, and the risk of head and neck cancer in the prostate, lung, colorectal, and ovarian (PLCO) cohort. Head Neck, 2013; 35(7):914-22.  
[4] Moura MA, Bergmann A, Aguiar SS, Thuler LC. The magnitude of the association between smoking and the risk of developing cancer in Brazil: a multicenter study. BMJ Open, 2014; 4(2):e003736.  
[5] Tejada CA, Ewerling F, Santos AM, Bertoldi AD, Menezes AM. Factors associated with smoking cessation in Brazil. Cad Saude Publica, 2013; 29(8):1555-64.  
[6] Hashibe M, Brennan P, Benhamou S, Castellsague X, Chen C, Curado MP, et al. Alcohol drinking in never users of tobacco, cigarette smoking in never drinkers, and the risk of head and neck cancer: pooled analysis in the International Head and Neck Cancer Epidemiology Consortium. J Natl Cancer Inst, 2007; 99(10):777-89.  
[7] Szymanska K, Hung RJ, Wunsch-Filho V, Eluf-Neto J, Curado MP, Koifman S, et al. Alcohol and tobacco, and the risk of cancers of the upper aerodigestive tract in Latin America: a case-control study. Cancer Causes Control, 2011; 22(7):1037-46.  
[8] Ferreira Antunes JL, Toporcov TN, Biazevic MG, Boing AF, Scully C, Petti S. Joint and independent effects of alcohol drinking and tobacco smoking on oral cancer: a large case-control study. PLoS One, 2013; 8(7):e68132.  
[9] Moyses RA, López RVM, Cury PM, Siqueira SAC, Curioni OA, Gois Filho JF. Significant differences in demographic, clinical, and pathological features in relation to smoking and alcohol consumption among 1,633 head and neck cancer patients.Clinics, 2014; 68(6):738-44.  
[10] Edefonti V, Hashibe M, Ambrogi F, Parpinel M, Bravi F, Talamini R, et al. Nutrient-based dietary patterns and the risk of head and neck cancer: a pooled analysis

---

<!-- METADADOS: doenca: Câncer de Cabeça e Pescoço - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
in the International Head and Neck Cancer Epidemiology consortium. Ann Oncol, 2012; 23(7):1869-80.  
[11] Bosetti C, La Vecchia C, Talamini R, Negri E, Levi F, Dal Maso L, et al. Food groups and laryngeal cancer risk: a case-control study from Italy and Switzerland. Int J Cancer, 2002; 100(3):355-60.  
[12] Galeone C, Pelucchi C, Talamini R, Levi F, Bosetti C, Negri E, et al. Role of fried foods and oral/pharyngeal and oesophageal cancers. Br J Cancer, 2005; 92(11):2065-9.  
[13] Zeng XT, Luo W, Huang W, Wang Q, Guo Y, Leng WD. Tooth loss and head and neck cancer: a meta-analysis of observational studies. PLoS One, 2013; 8(11):e79074.  
[14] Zeng XT, Deng AP, Li C, Xia LY, Niu YM, Leng WD. Periodontal disease and risk of head and neck cancer: a meta-analysis of observational studies. PLoS One, 2013; 8(10):e79017.  
[15] Copper MP, Smit CF, Stanojcic LD, Devriese PP, Schouwenburg PF, Mathus-Vliegen LM. High incidence of laryngopharyngeal reflux in patients with head and neck cancer. Laryngoscope, 2000; 110(6):1007-11.  
[16] Heck JE, Berthiller J, Vaccarella S, Winn DM, Smith EM, Shan'gina O, et al. Sexual behaviours and the risk of head and neck cancers: a pooled analysis in the International Head and Neck Cancer Epidemiology (INHANCE) consortium. Int J Epidemiol, 2010; 39(1):166-81.  
[17] Liu H, Li J, Diao M, Cai Z, Yang J, Zeng Y. Statistical analysis of human papillomavirus in a subset of upper aerodigestive tract tumors. J Med Virol, 2013; 85(10):1775-85.  
[18] Termine N, Panzarella V, Falaschini S, Russo A, Matranga D, Lo Muzio L, et al. HPV in oral squamous cell carcinoma vs head and neck squamous cell carcinoma biopsies: a meta-analysis (1988-2007). Ann Oncol, 2008; 19(10):1681-90.  
[19] Li X, Gao L, Li H, Gao J, Yang Y, Zhou F, et al. Human papillomavirus infection and laryngeal cancer risk: a systematic review and meta-analysis. J Infect Dis, 2013; 207(3):479-88.  
[20] Hopkins J, Cescon DW, Tse D, Bradbury P, Xu W, Ma C, et al. Genetic polymorphisms and head and neck cancer outcomes: a review. Cancer Epidemiol Biomarkers Prev, 2008; 17(3):490-9.  
[21] Warner GC, Reis PP, Makitie AA, Sukhai MA, Arora S, Jurisica I, et al. Current applications of microarrays in head and neck cancer research. Laryngoscope, 2004; 114(2):241-8.  
[22] Alho OP, Teppo H, Mantyselka P, Kantola S. Head and neck cancer in primary care: presenting symptoms and the effect of delayed diagnosis of cancer cases. CMAJ, 2006; 174(6):779-84.  
[23] Lokker ME, Offerman MP, van der Velden LA, de Boer MF, Pruyn JF, Teunissen SC. Symptoms of patients with incurable head and neck cancer: prevalence and impact on daily functioning. Head Neck, 2013; 35(6):868-76.  
[24] McGuff HS, Otto RA, Aufdemorte TB. Clinical warning signs and symptoms of head and neck cancer. Tex Dent J, 2000; 117(6):14-9.  
[25] de Bondt RB, Nelemans PJ, Hofman PA, Casselman JW, Kremer B, van Engelshoven JM, et al. Detection of lymph node metastases in head and neck cancer: a meta-analysis comparing US, USgFNAC, CT and MR imaging. Eur J Radiol, 2007; 64(2):266-72.  
[26] Vergez S, Moriniere S, Dubrulle F, Salaun PY, De Mones E, Bertolus C, et al. Initial staging of squamous cell carcinoma of the oral cavity, larynx and pharynx (excluding nasopharynx). Part I: Locoregional extension assessment: 2012 SFORL guidelines. Eur Ann Otorhinolaryngol Head Neck Dis, 2013; 130(1):39-45.  
[27] Xu G, Li J, Zuo X, Li C. Comparison of whole body positron emission tomography (PET)/PET-computed tomography and conventional anatomic imaging for detecting distant malignancies in patients with head and neck cancer: a meta-analysis. Laryngoscope, 2012; 122(9):1974-8.  
[28] Rohde M, Dyrvig AK, Johansen J, Sorensen JA, Gerke O, Nielsen AL, et al. 18F-fluoro-deoxy-glucose-positron emission tomography/computed tomography in diagnosis of head and neck squamous cell carcinoma: a systematic review and metaanalysis. Eur J Cancer, 2014; 50(13):2271-9.  
[29] Blodgett TM, Fukui MB, Snyderman CH, Branstetter BFt, McCook BM, Townsend DW, et al. Combined PET-CT in the head and neck: part 1. Physiologic, altered physiologic, and artifactual FDG uptake. Radiographics, 2005; 25(4):897-912.  
[30] Fukui MB, Blodgett TM, Snyderman CH, Johnson JJ, Myers EN, Townsend DW, et al. Combined PET-CT in the head and neck: part 2. Diagnostic uses and pitfalls of oncologic imaging. Radiographics, 2005; 25(4):913-30.  
[31] Xie P, Li M, Zhao H, Sun X, Fu Z, Yu J. 18F-FDG PET or PET-CT to evaluate prognosis for head and neck cancer: a meta-analysis. J Cancer Res Clin Oncol, 2011; 137(7):1085-93.  
[32] Patel K, Hadar N, Lee J, Siegel BA, Hillner BE, Lau J. The lack of evidence for PET or PET/CT surveillance of patients with treated lymphoma, colorectal cancer, and head and neck cancer: a systematic review. J Nucl Med, 2013; 54(9):1518-27.  
[33] Benninger MS, Enrique RR, Nichols RD. Symptom-directed selective endoscopy and cost containment for evaluation of head and neck cancer. Head Neck, 1993; 15(6):532-6. [34] Benninger MS, Shariff A, Blazoff K. Symptom-directed selective endoscopy: long-term efficacy. Arch Otolaryngol Head Neck Surg, 2001; 127(7):770-3.  
[35] Kaanders JH, Hordijk GJ. Carcinoma of the larynx: the Dutch national guideline for diagnostics, treatment, supportive care and rehabilitation. Radiother Oncol, 2002; 63(3):299-307.  
[36] Leslie A, Fyfe E, Guest P, Goddard P, Kabala JE. Staging of squamous cell carcinoma of the oral cavity and oropharynx: a comparison of MRI and CT in T- and N- staging. J Comput Assist Tomogr, 1999; 23(1):43-9.  
[37] Li C, Yang W, Men Y, Wu F, Pan J, Li L. Magnetic Resonance Imaging for Diagnosis of Mandibular Involvement from Head and Neck Cancers: A Systematic Review and Meta-Analysis. PLoS One, 2014; 9(11):e112267.  
[38] Fernandez B, Lund J, Meyers F. Epithelial membrane antigen expression in benign and malignant squamous epithelium of the head and neck. Otolaryngol Head Neck Surg, 1987; 97(3):288-93.  
[39] Pereira TC, Share SM, Magalhaes AV, Silverman JF. Can we tell the site of origin of metastatic squamous cell carcinoma? An immunohistochemical tissue microarray study of 194 cases. Appl Immunohistochem Mol Morphol, 2011; 19(1):104.  
[40] Matoso A, Singh K, Jacob R, Greaves WO, Tavares R, Noble L, et al. Comparison of thyroid transcription factor-1 expression by 2 monoclonal antibodies in pulmonary and nonpulmonary primary tumors. Appl Immunohistochem Mol Morphol, 2010; 18(2):142-9.  
[41] Reiersen DA, Pahilan ME, Devaiah AK. Meta-analysis of treatment outcomes for sinonasal undifferentiated carcinoma. Otolaryngol Head Neck Surg, 2012; 147(1):7-14.  
[42] Higgins TS, Thorp B, Rawlings BA, Han JK. Outcome results of endoscopic vs craniofacial resection of sinonasal malignancies: a systematic review and pooled-data analysis. Int Forum Allergy Rhinol, 2011; 1(4):255-61.  
[43] União Internacional Contra o Câncer. TNM: classificação de tumores malignos. Ministério da Saúde. Instituto Nacional de Câncer. 7a Edição. Rio de Janeiro, Inca2012. xxv, 325p.  
[44] Homma A, Furuta Y, Oridate N, Nakano Y, Kohashi G, Yagi K, et al. Prognostic significance of clinical parameters and biological markers in patients with squamous cell carcinoma of the head and neck treated with concurrent chemoradiotherapy. Clin Cancer Res, 1999; 5(4):801-6.  
[45] De Cecco L, Bossi P, Locati L, Canevari S, Licitra L. Comprehensive gene expression meta-analysis of head and neck squamous cell carcinoma microarray data defines a robust survival predictor. Ann Oncol, 2014; 25(8):1628-35.  
[46] Gasparini G, Bevilacqua P, Bonoldi E, Testolin A, Galassi A, Verderio P, et al. Predictive and prognostic markers in a series of patients with head and neck squamous cell invasive carcinoma treated with concurrent chemoradiation therapy. Clin Cancer Res, 1995; 1(11):1375-83.  
[47] Rischin D, Young RJ, Fisher R, Fox SB, Le QT, Peters LJ, et al. Prognostic significance of p16INK4A and human papillomavirus in patients with oropharyngeal cancer treated on TROG 02.02 phase III trial. J Clin Oncol, 2010; 28(27):4142-8.  
[48] Masterson L, Moualed D, Liu ZW, Howard JE, Dwivedi RC, Tysome JR, et al. De-escalation treatment protocols for human papillomavirus-associated oropharyngeal squamous cell carcinoma: a systematic review and meta-analysis of current clinical trials. Eur J Cancer, 2014; 50(15):2636-48.  
[49] Hollows P, McAndrew PG, Perini MG. Delays in the referral and treatment of oral squamous cell carcinoma. Br Dent J, 2000; 188(5):262-5.  
[50] Jones TM, Hargrove O, Lancaster J, Fenton J, Shenoy A, Roland NJ. Waiting times during the management of head and neck tumours. J Laryngol Otol, 2002; 116(4):275-9.  
[51] Ferlito A, Robbins KT, Silver CE, Hasegawa Y, Rinaldo A. Classification of neck dissections: an evolving system. Auris Nasus Larynx, 2009; 36(2):127-34.  
[52] Ferlito A, Silver CE, Rinaldo A. Elective management of the neck in oral cavity squamous carcinoma: current concepts supported by prospective studies. Br J Oral Maxillofac Surg, 2009; 47(1):5-9.  
[53] Fang FM, Tsai WL, Chen HC, Hsu HC, Hsiung CY, Chien CY, et al. Intensity-modulated or conformal radiotherapy improves the quality of life of patients with nasopharyngeal carcinoma: comparisons of four radiotherapy techniques. Cancer, 2007; 109(2):313-21.  
[54] Hodge CW, Bentzen SM, Wong G, Palazzi-Churas KL, Wiederholt PA, Gondi V, et al. Are we influencing outcome in oropharynx cancer with intensitymodulated radiotherapy? An inter-era comparison. Int J Radiat Oncol Biol Phys, 2007; 69(4):1032-41.  
[55] Lee NY, de Arruda FF, Puri DR, Wolden SL, Narayana A, Mechalakos J, et al. A comparison of intensity-modulated radiation therapy and concomitant boost radiotherapy in the setting of concurrent chemotherapy for locally advanced oropharyngeal carcinoma. Int J Radiat Oncol Biol Phys, 2006; 66(4):966-74.  
[56] Rades D, Fehlauer F, Wroblesky J, Albers D, Schild SE, Schmidt R. Prognostic factors in head-and-neck cancer patients treated with surgery followed by intensity-modulated radiotherapy (IMRT), 3D-conformal radiotherapy, or conventional radiotherapy. Oral Oncol, 2007; 43(6):535-43.  
[57] van Rij CM, Oughlane-Heemsbergen WD, Ackerstaff AH, Lamers EA, Balm AJ, Rasch CR. Parotid gland sparing IMRT for head and neck cancer improves xerostomia related quality of life. Radiat Oncol, 2008; 3:41.  
[58] Yao M, Karnell LH, Funk GF, Lu H, Dornfeld K, Buatti JM. Health-related quality-of-life outcomes following IMRT versus conventional radiotherapy for oropharyngeal squamous cell carcinoma. Int J Radiat Oncol Biol Phys, 2007; 69(5):1354-60.  
[59] Kam MK, Leung SF, Zee B, Chau RM, Suen JJ, Mo F, et al. Prospective randomized study of intensity-modulated radiotherapy on salivary gland function in early-stage nasopharyngeal carcinoma patients. J Clin Oncol, 2007; 25(31):4873-9.  
[60] Nutting CM, Morden JP, Harrington KJ, Urbano TG, Bhide SA, Clark C, et al. Parotid-sparing intensity modulated versus conventional radiotherapy in head and neck cancer (PARSPORT): a phase 3 multicentre randomised controlled trial. Lancet Oncol, 2011; 12(2):127-36.  
[61] Pow EH, Kwong DL, McMillan AS, Wong MC, Sham JS, Leung LH, et al. Xerostomia and quality of life after intensity-modulated radiotherapy vs. conventional radiotherapy for early-stage nasopharyngeal carcinoma: initial report on a randomized controlled clinical trial. Int J Radiat Oncol Biol Phys, 2006; 66(4):981-91.  
[62] Marta GN, Silva V, de Andrade Carvalho H, de Arruda FF, Hanna SA, Gadia R, et al. Intensity-modulated radiation therapy for head and neck cancer: systematic review and meta-analysis. Radiother Oncol, 2014; 110(1):9-15.  
[63] Hall EJ, Wuu CS. Radiation-induced second cancers: the impact of 3D-CRT and IMRT. Int J Radiat Oncol Biol Phys, 2003; 56(1):83-8.  
[64] Budach W, Hehr T, Budach V, Belka C, Dietz K. A meta-analysis of hyperfractionated and accelerated radiotherapy and combined chemotherapy and radiotherapy regimens in unresected locally advanced squamous cell carcinoma of the head and neck.BMC Cancer, 2006; 6:28.  
[65] Bourhis J, Overgaard J, Audry H, Ang KK, Saunders M, Bernier J, et al. Hyperfractionated or accelerated radiotherapy in head and neck cancer: a meta-analysis. Lancet, 2006; 368(9538):843-54.  
[66] Mazeron JJ, Ardiet JM, Haie-Meder C, Kovacs G, Levendag P, Peiffert D, et al. GEC-ESTRO recommendations for brachytherapy for head and neck squamous cell carcinomas. Radiother Oncol, 2009; 91(2):150-6.  
[67] Stoker SD, van Diessen JN, de Boer JP, Karakullukcu B, Leemans CR, Tan IB. Current treatment options for local residual nasopharyngeal carcinoma. Curr Treat Options Oncol, 2013; 14(4):475-91.  
[68] Nieder C, Andratschke NH, Grosu AL. Increasing frequency of reirradiation studies in radiation oncology: systematic review of highly cited articles. Am J Cancer Res, 2013; 3(2):152-8.  
[69] Chan JY, Wei WI.Current management strategy of hypopharyngeal carcinoma. Auris Nasus Larynx, 2013; 40(1):2-6.  
[70] Shang J, Gu J, Han Q, Xu Y, Yu X, Wang K. Chemoradiotherapy is superior to radiotherapy alone after surgery in advanced squamous cell carcinoma of the head and neck: a systematic review and meta-analysis. Int J Clin Exp Med, 2014; 7(9):247887.  
[71] O'Hara J, Markey A, Homer JJ. Transoral laser surgery versus radiotherapy for tumour stage 1a or 1b glottic squamous cell carcinoma: systematic review of local control outcomes. J Laryngol Otol, 2013; 127(8):732-8.  
[72] Pham TA, De Freitas R, Sigston E, Vallance N. Factors leading to the use of alternate treatment modalities following transoral laser excision of T1 and T2 glottic squamous cell carcinoma. ANZ J Surg, 2012; 82(10):720-3.  
[73] Monroe MM, Gross ND. Evidence-based practice: management of the clinical node-negative neck in early-stage oral cavity squamous cell carcinoma. Otolaryngol Clin North Am, 2012; 45(5):1181-93.  
[74] INCA. Condutas do INCA/MS: carcinoma epidermoide de cabeça e pescoço. Rev Bras Cancerologia, 2001; 47(4):361-76.  
[75] Olzowy B, Tsalemchuk Y, Schotten KJ, Reichel O, Harreus U. Frequency of bilateral cervical metastases in oropharyngeal squamous cell carcinoma: a retrospective analysis of 352 cases after bilateral neck dissection. Head Neck, 2011; 33(2):239-43.  
[76] Kuriakose MA, Trivedi NP. Sentinel node biopsy in head and neck squamous cell carcinoma. Curr Opin Otolaryngol Head Neck Surg, 2009; 17(2):100-10.  
[77] Thompson CF, St John MA, Lawson G, Grogan T, Elashoff D, Mendelsohn AH. Diagnostic value of sentinel lymph node biopsy in head and neck cancer: a metaanalysis. Eur Arch Otorhinolaryngol, 2013; 270(7):2115-22.  
[78] Allegra E, Franco T, Domanico R, La Boria A, Trapasso S, Garozzo A. Effectiveness of therapeutic selective neck dissection in laryngeal cancer. ORL J Otorhinolaryngol Relat Spec, 2014; 76(2):89-97.  
[79] Deganello A, Gitti G, Meccariello G, Parrinello G, Mannelli G, Gallo O. Effectiveness and pitfalls of elective neck dissection in N0 laryngeal cancer. Acta Otorhinolaryngol Ital, 2011; 31(4):216-21.  
[80] Lim YC, Choi EC, Lee JS, Koo BS, Song MH, Shin HA. Is dissection of level IV absolutely necessary in elective lateral neck dissection for clinically N0 laryngeal carcinoma? Oral Oncol, 2006; 42(1):102-7.  
[81] Wiegand S, Esters J, Muller HH, Jacker T, Roessler M, Fasunla JA, et al. Relevance of level I and IIB neck dissection in laryngeal cancer. J Laryngol Otol, 2012; 126(8):795-9.  
[82] Cooper JS, Zhang Q, Pajak TF, Forastiere AA, Jacobs J, Saxman SB, et al. Long-term follow-up of the RTOG 9501/intergroup phase III trial: postoperative concurrent radiation therapy and chemotherapy in high-risk squamous cell carcinoma of the head and neck. Int J Radiat Oncol Biol Phys, 2012; 84(5):1198-205.  
[83] Rich TA, Shepard RC, Mosley ST. Four decades of continuing innovation with fluorouracil: current and future approaches to fluorouracil chemoradiation therapy. J Clin Oncol, 2004; 22(11):2214-32.  
[84] Petrelli F, Coinu A, Riboldi V, Borgonovo K, Ghilardi M, Cabiddu M, et al. Concomitant platinum-based chemotherapy or cetuximab with radiotherapy for locally advanced head and neck cancer: A systematic review and meta-analysis of published studies. Oral Oncol, 2014.  
[85] Halim AA, Wahba HA, El-Hadaad HA, Abo-Elyazeed A. Concomitant chemoradiotherapy using low-dose weekly gemcitabine versus low-dose weekly paclitaxel in locally advanced head and neck squamous cell carcinoma: a phase III study. Med Oncol, 2012; 29(1):279-84.  
[86] Gupta S, Khan H, Barik S, Negi MP. Clinical benefits of concurrent capecitabine and cisplatin versus concurrent cisplatin and 5-flurouracil in locally advanced squamous cell head and neck cancer. Drug Discov Ther, 2013; 7(1):36-42.  
[87] Rewari AN, Haffty BG, Wilson LD, Son YH, Joe JK, Ross DA, et al. Postoperative concurrent chemoradiotherapy with mitomycin in advanced squamous cell carcinoma of the head and neck: results from three prospective randomized trials. Cancer J, 2006; 12(2):123-9.  
[88] Ley J, Mehan P, Wildes TM, Thorstad W, Gay HA, Michel L, et al. Cisplatin versus cetuximab given concurrently with definitive radiation therapy for locally advanced head and neck squamous cell carcinoma. Oncology, 2013; 85(5):290-6.  
[89] Mukhija V, Gupta S, Jacobson AS, Eloy JA, Genden EM. Selective neck dissection following adjuvant therapy for advanced head and neck cancer. Head Neck, 2009; 31(2):183-8.  
[90] Goguen LA, Posner MR, Tishler RB, Wirth LJ, Norris CM, Annino DJ, et al. Examining the need for neck dissection in the era of chemoradiation therapy for advanced head and neck cancer. Arch Otolaryngol Head Neck Surg, 2006; 132(5):52631.  
[91] Greven KM, Williams DW, 3rd, Browne JD, McGuirt WF, Sr., White DR, D'Agostino RB, Jr. Radiographic complete response on post treatment CT imaging  
eliminates the need for adjuvant neck dissection after treatment for node positive head and neck cancer. Am J Clin Oncol, 2008; 31(2):169-72.  
[92] Lopez Rodriguez M, Cerezo Padellano L, Martin Martin M, Counago Lorenzo F. Neck dissection after radiochemotherapy in patients with locoregionally advanced head and neck cancer. Clin Transl Oncol, 2008; 10(12):812-6.  
[93] Robbins KT, Doweck I, Samant S, Vieira F. Effectiveness of superselective and selective neck dissection for advanced nodal metastases after chemoradiation. Arch Otolaryngol Head Neck Surg, 2005; 131(11):965-9.  
[94] Lango MN, Egleston B, Ende K, Feigenberg S, D'Ambrosio DJ, Cohen RB, et al. Impact of neck dissection on long-term feeding tube dependence in patients with head and neck cancer treated with primary radiation or chemoradiation. Head Neck, 2010; 32(3):341-7.  
[95] Nibu K, Ebihara Y, Ebihara M, Kawabata K, Onitsuka T, Fujii T, et al. Quality of life after neck dissection: a multicenter longitudinal study by the Japanese Clinical Study Group on Standardization of Treatment for Lymph Node Metastasis of Head and Neck Cancer. Int J Clin Oncol, 2010; 15(1):33-8.  
[96] Ahlberg A, Nikolaidis P, Engstrom T, Gunnarsson K, Johansson H, Sharp L, et al. Morbidity of supraomohyoidal and modified radical neck dissection combined with radiotherapy for head and neck cancer: a prospective longitudinal study. Head Neck, 2012; 34(1):66-72.  
[97] Chen H, Zhou L, Chen D, Luo J. Clinical efficacy of neoadjuvant chemotherapy with platinum-based regimen for patients with locoregionally advanced head and neck squamous cell carcinoma: an evidence-based meta-analysis. Ann Saudi Med, 2011; 31(5):502-12.  
[98] Su YX, Zheng JW, Zheng GS, Liao GQ, Zhang ZY. Neoadjuvant chemotherapy of cisplatin and fluorouracil regimen in head and neck squamous cell carcinoma: a meta-analysis. Chin Med J (Engl), 2008; 121(19):1939-44.  
[99] Lefebvre JL, Chevalier D, Luboinski B, Kirkpatrick A, Collette L, Sahmoud T. Larynx preservation in pyriform sinus cancer: preliminary results of a European Organization for Research and Treatment of Cancer phase III trial. EORTC Head and Neck Cancer Cooperative Group. J Natl Cancer Inst, 1996; 88(13):890-9.  
[100] OuYang PY, Xie C, Mao YP, Zhang Y, Liang XX, Su Z, et al. Significant efficacies of neoadjuvant and adjuvant chemotherapy for nasopharyngeal carcinoma by meta-analysis of published literature-based randomized, controlled trials. Ann Oncol, 2013; 24(8):2136-46.  
[101] Pignon JP, Bourhis J, Domenge C, Designe L. Chemotherapy added to locoregional treatment for head and neck squamous-cell carcinoma: three meta-analyses of updated individual data. MACH-NC Collaborative Group.Meta-Analysis of Chemotherapy on Head and Neck Cancer. Lancet, 2000; 355(9208):949-55.  
[102] Domenge C, Hill C, Lefebvre JL, De Raucourt D, Rhein B, Wibault P, et al. Randomized trial of neoadjuvant chemotherapy in oropharyngeal carcinoma. French Groupe d'Etude des Tumeurs de la Tete et du Cou (GETTEC). Br J Cancer, 2000; 83(12):1594-8.  
[103] Ma J, Liu Y, Yang X, Zhang CP, Zhang ZY, Zhong LP. Induction chemotherapy in patients with resectable head and neck squamous cell carcinoma: a meta-analysis. World J Surg Oncol, 2013; 11:67.  
[104] Munro AJ.An overview of randomised controlled trials of adjuvant chemotherapy in head and neck cancer. Br J Cancer, 1995; 71(1):83-91.  
[105] Furness S, Glenny AM, Worthington HV, Pavitt S, Oliver R, Clarkson JE, et al. Interventions for the treatment of oral cavity and oropharyngeal cancer: chemotherapy. Cochrane Database Syst Rev, 2011; (4):CD006386.  
[106] Prevost A, Merol JC, Aime P, Moutel K, Roger-Liautaud F, Nasca S, et al. A randomized trial between two neoadjuvant chemotherapy protocols: CDDP + 5-FU versus CDDP + VP16 in advanced cancer of the head and neck. Oncol Rep, 2005; 14(3):771-6.  
[107] Zorat PL, Paccagnella A, Cavaniglia G, Loreggian L, Gava A, Mione CA, et al. Randomized phase III trial of neoadjuvant chemotherapy in head and neck cancer: 10-year follow-up. J Natl Cancer Inst, 2004; 96(22):1714-7.  
[108] Perl G, Ben-Aharon I, Popovtzer A, Stemmer SM, Vidal L. Addition of taxane to induction therapy in head and neck malignancies: a systematic review and meta-analysis of randomized controlled trials. Chemotherapy, 2013; 59(6):435-40.  
[109] Posner MR, Hershock DM, Blajman CR, Mickiewicz E, Winquist E, Gorbounova V, et al. Cisplatin and fluorouracil alone or with docetaxel in head and neck cancer. N Engl J Med, 2007; 357(17):1705-15.  
[110] Blanchard P, Bourhis J, Lacas B, Posner MR, Vermorken JB, Hernandez JJ, et al. Taxane-cisplatin-fluorouracil as induction chemotherapy in locally advanced head and neck cancers: an individual patient data meta-analysis of the meta-analysis of chemotherapy in head and neck cancer group. J Clin Oncol, 2013; 31(23):2854-60.  
[111] Liang Z, Zhu X, Li L, Qu S, Liang X, Liang Z, et al. Concurrent chemoradiotherapy followed by adjuvant chemotherapy compared with concurrent chemoradiotherapy alone for the treatment of locally advanced nasopharyngeal carcinoma: a retrospective controlled study. Curr Oncol, 2014; 21(3):e408-17.  
[112] Chen YP, Wang ZX, Chen L, Liu X, Tang LL, Mao YP, et al. A Bayesian network meta-analysis comparing concurrent chemoradiotherapy followed by adjuvant chemotherapy, concurrent chemoradiotherapy alone and radiotherapy alone in patients with locoregionally advanced nasopharyngeal carcinoma. Ann Oncol, 2014.  
[113] Goodwin WJ, Jr. Salvage surgery for patients with recurrent squamous cell carcinoma of the upper aerodigestive tract: when do the ends justify the means? Laryngoscope, 2000; 110(3 Pt 2 Suppl 93):1-18.  
[114] Jones AS, Tandon S, Helliwell TR, Husband DJ, Jones TM. Survival of patients with neck recurrence following radical neck dissection: utility of a second neck dissection? Head Neck, 2008; 30(11):1514-22.  
[115] Young ER, Diakos E, Khalid-Raja M, Mehanna H. Resection of subsequent pulmonary metastases from treated head and neck squamous cell carcinoma; systematic review and meta-analysis. Clin Otolaryngol, 2014.  
[116] Winquist E, Al-Rasheedy I, Nichols AC, Palma DA, Stitt L. Temporal changes in the efficacy of chemotherapy for recurrent or metastatic squamous cell  
carcinoma of the head and neck: a systematic review and meta-analysis. Cancer Treat Rev, 2014; 40(9):1073-9.  
[117] Price KA, Cohen EE. Current treatment options for metastatic head and neck cancer. Curr Treat Options Oncol, 2012; 13(1):35-46.  
[118] Petrelli F, Barni S. Anti-EGFR-targeting agents in recurrent or metastatic head and neck carcinoma: a meta-analysis. Head Neck, 2012; 34(11):1657-64.  
[119] Molin Y, Fayette J. Current chemotherapies for recurrent/metastatic head and neck cancer. Anticancer Drugs, 2011; 22(7):621-5.  
[120] Chua DT, Sham JS, Wei WI, Ho WK, Au GK. The predictive value of the 1997 American Joint Committee on Cancer stage classification in determining failure patterns in nasopharyngeal carcinoma. Cancer, 2001; 92(11):2845-55.  
[121] Langendijk JA, Leemans CR, Buter J, Berkhof J, Slotman BJ. The additional value of chemotherapy to radiotherapy in locally advanced nasopharyngeal carcinoma: a meta-analysis of the published literature. J Clin Oncol, 2004; 22(22):460412.  
[122] Baujat B, Audry H, Bourhis J, Chan AT, Onat H, Chua DT, et al. Chemotherapy in locally advanced nasopharyngeal carcinoma: an individual patient data meta-analysis of eight randomized trials and 1753 patients. Int J Radiat Oncol Biol Phys, 2006; 64(1):47-56.  
[123] Hui EP, Ma BB, Leung SF, King AD, Mo F, Kam MK, et al. Randomized phase II trial of concurrent cisplatin-radiotherapy with or without neoadjuvant docetaxel and cisplatin in advanced nasopharyngeal carcinoma. J Clin Oncol, 2009; 27(2):242-9. [124] Liang ZG, Zhu XD, Tan AH, Jiang YM, Qu S, Su F, et al. Induction chemotherapy followed by concurrent chemoradiotherapy versus concurrent chemoradiotherapy with or without adjuvant chemotherapy for locoregionally advanced nasopharyngeal carcinoma: meta-analysis of 1,096 patients from 11 randomized controlled trials. Asian Pac J Cancer Prev, 2013; 14(1):515-21. [125] Perri F, Della Vittoria Scarpati G, Buonerba C, Di Lorenzo G, Longo F, Muto P, et al. Combined chemo-radiotherapy in locally advanced nasopharyngeal carcinomas. World J Clin Oncol, 2013; 4(2):47-51.  
[126] Chen L, Hu CS, Chen XZ, Hu GQ, Cheng ZB, Sun Y, et al. Concurrent chemoradiotherapy plus adjuvant chemotherapy versus concurrent chemoradiotherapy alone in patients with locoregionally advanced nasopharyngeal carcinoma: a phase 3 multicentre randomised controlled trial. Lancet Oncol, 2012; 13(2):163-71.  
[127] Na'ara S, Amit M, Billan S, Cohen JT, Gil Z. Outcome of patients undergoing salvage surgery for recurrent nasopharyngeal carcinoma: a meta-analysis. Ann Surg Oncol, 2014; 21(9):3056-62.  
[128] Elting LS, Keefe DM, Sonis ST, Garden AS, Spijkervet FK, Barasch A, et al. Patient-reported measurements of oral mucositis in head and neck cancer patients treated with radiotherapy with or without chemotherapy: demonstration of increased frequency, severity, resistance to palliation, and impact on quality of life. Cancer, 2008; 113(10):2704-13.  
[129] Clarkson JE, Worthington HV, Furness S, McCabe M, Khalid T, Meyer S. Interventions for treating oral mucositis for patients with cancer receiving treatment. Cochrane Database Syst Rev, 2010; (8):CD001973.  
[130] Bjordal JM, Bensadoun RJ, Tuner J, Frigo L, Gjerde K, Lopes-Martins RA. A systematic review with meta-analysis of the effect of low-level laser therapy (LLLT) in cancer therapy-induced oral mucositis. Support Care Cancer, 2011; 19(8):1069-77.  
[131] Gautam AP, Fernandes DJ, Vidyasagar MS, Maiya AG, Nigudgi S. Effect of low-level laser therapy on patient reported measures of oral mucositis and quality of life in head and neck cancer patients receiving chemoradiotherapy--a randomized controlled trial. Support Care Cancer, 2013; 21(5):1421-8.  
[132] Oral mucositis due to cancer treatments.Orodental hygiene and ice cubes. Prescrire Int, 2008; 17(93):33-5.  
[133] Lalla RV, Choquette LE, Curley KF, Dowsett RJ, Feinn RS, Hegde UP, et al. Randomized double-blind placebo-controlled trial of celecoxib for oral mucositis in patients receiving radiation therapy for head and neck cancer. Oral Oncol, 2014.  
[134] Bar Ad V, Weinstein G, Dutta PR, Chalian A, Both S, Quon H. Gabapentin for the treatment of pain related to radiation-induced mucositis in patients with head and neck tumors treated with intensity-modulated radiation therapy. Head Neck, 2010; 32(2):173-7.  
[135] Bar Ad V, Weinstein G, Dutta PR, Dosoretz A, Chalian A, Both S, et al. Gabapentin for the treatment of pain syndrome related to radiation-induced mucositis in patients with head and neck cancer treated with concurrent chemoradiotherapy. Cancer, 2010; 116(17):4206-13.  
[136] Ehrnrooth E, Grau C, Zachariae R, Andersen J. Randomized trial of opioids versus tricyclic antidepressants for radiation-induced mucositis pain in head and neck cancer. Acta Oncol, 2001; 40(6):745-50.  
[137] Garg S, Yoo J, Winquist E. Nutritional support for head and neck cancer patients receiving radiotherapy: a systematic review. Support Care Cancer, 2010; 18(6):667-77.  
[138] Rabinovitch R, Grant B, Berkey BA, Raben D, Ang KK, Fu KK, et al. Impact of nutrition support on treatment outcome in patients with locally advanced head and neck squamous cell cancer treated with definitive radiotherapy: a secondary analysis of RTOG trial 90-03. Head Neck, 2006; 28(4):287-96.  
[139] Burkitt P, Carter LM, Smith AB, Kanatas A. Outcomes of percutaneous endoscopic gastrostomy and radiologically inserted gastrostomy in patients with head and neck cancer: a systematic review. Br J Oral Maxillofac Surg, 2011; 49(7):516-20.  
[140] Magne N, Marcy PY, Foa C, Falewee MN, Schneider M, Demard F, et al. Comparison between nasogastric tube feeding and percutaneous fluoroscopic gastrostomy in advanced head and neck cancer patients. Eur Arch Otorhinolaryngol, 2001; 258(2):89-92.  
[141] Nugent B, Lewis S, O'Sullivan JM.Enteral feeding methods for nutritional management in patients with head and neck cancers being treated with radiotherapy and/or chemotherapy.Cochrane Database Syst Rev, 2013; 1:CD007904.  
[142] Lees J. Nasogastric and percutaneous endoscopic gastrostomy feeding in head and neck cancer patients receiving radiotherapy treatment at a regional oncology unit: a two year study. Eur J Cancer Care (Engl), 1997; 6(1):45-9.  
[143] Silander E, Nyman J, Bove M, Johansson L, Larsson S, Hammerlid E. Impact of prophylactic percutaneous endoscopic gastrostomy on malnutrition and quality of life in patients with head and neck cancer: a randomized study. Head Neck, 2012; 34(1):1-9.  
[144] Haughey BH, Gates GA, Arfken CL, Harvey J. Meta-analysis of second malignant tumors in head and neck cancer: the case for an endoscopic screening protocol. Ann Otol Rhinol Laryngol, 1992; 101(2 Pt 1):105-12.  
[145] Jegu J, Binder-Foucard F, Borel C, Velten M. Trends over three decades of the risk of second primary cancer among patients with head and neck cancer. Oral Oncol, 2013; 49(1):9-14.  
[146] Travis LB, Demark Wahnefried W, Allan JM, Wood ME, Ng AK. Aetiology, genetics and prevention of secondary neoplasms in adult cancer survivors.Nat Rev Clin Oncol, 2013; 10(5):289-301.  
[147] Brasil. Ministério da Saúde. Manual de Bases Técnicas da Oncologia – SIA/SUS - Sistema de Informações Ambulatoriais. Brasília: MS/SAS/DRAC/CGSI. Março de 2015. 20ª ed. 129p.

---

