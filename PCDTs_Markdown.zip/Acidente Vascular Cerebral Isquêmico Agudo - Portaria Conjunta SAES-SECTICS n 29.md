<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE  
PORTARIA CONJUNTASAES/SECTICS Nº 29, DE 12 DE DEZEMBRO DE 2023.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Acidente Vascular Cerebral Isquêmico Agudo.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Acidente Vascular Cerebral Isquêmico Agudo no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os Registros de Deliberação n<sup><u>o</u></sup> 590/2021 e nº 673/2021 e os Relatórios de Recomendação n<sup><u>o</u></sup> 589 – Fevereiro de 2021 e nº 677 – Novembro de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Acidente Vascular Cerebral Isquêmico Agudo. Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do acidente vascular cerebral isquêmico agudo, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do acidente vascular cerebral isquêmico agudo.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: ANEXO -->
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DO ACIDENTE VASCULAR CEREBRAL ISQUÊMICO AGUDO

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **1. INTRODUÇÃO** -->
O acidente vascular cerebral (AVC) é uma das principais causas de incapacidade e morte no mundo<sup>1,2</sup> . Em todo o mundo, 15 milhões de pessoas sofrem um AVC todos os anos, cinco milhões e meio de pessoas morrem e outros cinco milhões ficam permanentemente incapacitadas, representando importante impacto à saúde pública e à família dos pacientes<sup>3</sup> . O AVC ocorre predominantemente em adultos de meia-idade e idosos<sup>4</sup> . Dados de um estudo prospectivo nacional indicaram uma incidência anual de 108 casos por 100 mil habitantes<sup>5</sup> .  
Conforme definição recente, o AVC é um episódio agudo caracterizado por sinais clínicos de perturbação focal ou global da função neurológica causada por infarto ou hemorragia espontânea na parte acometida do encéfalo, retina ou medula espinhal, durando mais de 24 horas, ou de qualquer duração, se constatada por imagem - tomografia computadorizada (TC) ou ressonância magnética (RM) -, ou, ainda, por autópsia que identifique infarto focal ou hemorragia relevante para os sintomas<sup>6</sup> . O AVC é classificado em isquêmico (obstrução arterial com consequente alteração do fluxo sanguíneo cerebral), hemorragia intracerebral (coleção focal de sangue dentro do parênquima cerebral ou sistema ventricular que não é causada por trauma) e hemorragia subaracnóidea<sup>7</sup> . O AVC isquêmico (AVCi) é o mais prevalente, sendo responsável por 75% a 85% de todos os AVC<sup>8</sup> .  
A principal causa modificável de AVC é a aterosclerose de artérias pequenas intracranianas e grandes artérias do pescoço e cerebrais. O restante dos AVC (aproximadamente 20%) é causado por êmbolos cardiogênicos, mais comumente associados à fibrilação atrial, e cerca de 30% permanecem idiopáticos, mesmo após extensa investigação etiológica<sup>9</sup> . Cerca de 90% dos AVC podem ser associados a fatores de risco, sendo os mais frequentes: hipertensão arterial sistêmica, tabagismo, obesidade, dieta inadequada, sedentarismo, diabete melito, consumo de álcool, sofrimento mental, doenças cardíacas e dislipidemia<sup>10–12</sup> . Assim, intervenções sobre os fatores de risco modificáveis, que podem ser feitas na atenção primária, podem contribuir para a prevenção de grande parte dos AVC. Também, o atendimento imediato e efetivo dos pacientes com quadros agudos pode prevenir sequelas e morte.  
O aparecimento súbito de déficits neurológicos caracteriza clinicamente o AVC hemorrágico e o AVC isquêmico, de acordo com a região cerebral envolvida, que, por sua vez, dependerá da circulação afetada<sup>13</sup> Em 80% dos casos, a circulação mais comumente afetada é a anterior ou a carotídea. Nestes casos, os pacientes geralmente apresentam déficit motor contralateral - com comprometimento predominante de membros superiores e inferiores, alteração de linguagem, perda sensitiva contralateral e hemianopsia homônima com desvio conjugado do olhar para o lado da lesão. Os AVC da circulação posterior (ou vertebrobasilar) são menos frequentes e de pior prognóstico e os pacientes comumente apresentam como sinais e sintomas: estado de coma, tetraparesia, alterações de nervos cranianos, diplopia, vertigem ou ataxia<sup>13,14</sup> . Alguns fatores podem levar a uma maior complexidade dos casos, como o tromboembolismo pulmonar<sup>15</sup> . As maiores causas de morte precoce são a deterioração neurológica e a contribuição de outras causas, tais como infecção secundária por aspiração e infarto agudo do miocárdio<sup>16</sup> .  
Devido à sua prevalência, quadro clínico e impacto na qualidade de vida e capacidade funcional do paciente, o AVC representa um enorme impacto financeiro para o sistema de saúde e para as famílias dos pacientes acometidos<sup>17</sup> . O impacto global do AVC aumentou nas últimas duas décadas<sup>18</sup> . Em 2015, a doença isquêmica do coração e o AVC foram as duas principais causas de mortalidade prematura em todo o mundo e as principais causas de anos de vida perdidos (DALYs) em 119 países e territórios<sup>19</sup> . Assim, identificar terapias seguras e custo-efetivas para prevenir e tratar o AVC é de grande interesse para a saúde pública<sup>6</sup> .  
Atualmente, no Brasil, o tratamento especializado do AVCi é realizado em pontos diversificados da rede de atenção especializada à saúde, com ênfase nos Centros de Atendimento de Urgência, que são hospitais de referência para atendimento aos pacientes com AVC. Nesses centros, é administrado trombolítico intravenoso (ativador de plasminogênio tecidual recombinante - rtPA) nas primeiras horas após o início do AVCi naqueles pacientes elegíveis. Além disso, é realizado o controle da pressão arterial sistêmica antes, durante e após o uso de trombolítico com o emprego de anti-hipertensivos<sup>20</sup> . Uma medida não medicamentosa é a extração mecânica do trombo (trombectomia) para restauração do fluxo sanguíneo na área afetada<sup>8</sup> . Deste modo, a atualização deste PCDT objetiva definir um modelo de cuidado em saúde mais assertivo e multidisciplinar, com destaques para a atenção secundária e terciária quanto ao diagnóstico e ao tratamento medicamentoso e não medicamentoso do AVCi agudo.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do acidente vascular cerebral isquêmico agudo. A metodologia de busca e avaliação das evidências está detalhada no Apêndice 1. Destaca-se, ainda, a importância do seguimento de outros documentos que norteiam o cuidado do paciente com AVC no SUS, como a “Linha de cuidados em Acidente Vascular Cerebral (AVC) na rede de atenção às urgências e emergências” e a “Linha de Cuidado do Acidente Vascular Cerebral (AVC) no adulto”.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- I63.0 Infarto cerebral devido a trombose de artérias pré-cerebrais  
- I63.1 Infarto cerebral devido a embolia de artérias pré-cerebrais  
- I63.2 Infarto cerebral devido a oclusão ou estenose não especificadas de artérias pré-cerebrais  
- I63.3 Infarto cerebral devido a trombose de artérias cerebrais  
- I63.4 Infarto cerebral devido a embolia de artérias cerebrais  
- I63.5 Infarto cerebral devido a oclusão ou estenose não especificadas de artérias cerebrais  
- I63.6 Infarto cerebral devido a trombose venosa cerebral não piogênica  
- I63.8 Outros infartos cerebrais  
- I63.9 Infarto cerebral não especificado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **3.1. Diagnóstico clínico** -->
Durante o atendimento do paciente, deve-se avaliar o início preciso das manifestações neurológicas e seu curso (quadro estável versus instável). O déficit neurológico focal de instalação súbita indica a possibilidade de AVC. Dor de cabeça e crises epilépticas são sintomas mais comuns em AVC hemorrágicos do que em AVC isquêmicos agudos. A presença de fatores de risco para doenças vasculares deve sempre ser investigada, sendo a hipertensão arterial sistêmica aquele mais importante para as lesões isquêmicas e hemorrágicas<sup>16</sup> .  
No exame físico, a escala de avaliação pré-hospitalar de Cincinatti<sup>21,22</sup> pode ser utilizada como método de triagem porque possui boa acurácia. Caso o paciente apresente qualquer uma das seguintes características, seu resultado é positivo:  
- Queda facial: quando o paciente é solicitado a mostrar os dentes ou sorrir, verifica-se assimetria;  
● Fraqueza nos braços: quando o paciente é solicitado a estender os braços para a frente em um ângulo de 90% com o tronco e mantê-los na posição por 10 segundos, um dos braços não se move ou não fica mantido na posição em relação ao contralateral;  
● Fala anormal: quando o paciente é solicitado a pronunciar a frase “ _na casa do padeiro nem sempre tem trigo”,_ o paciente pronuncia palavras incompreensíveis, usa palavras incorretas ou é incapaz de pronunciar.  
Considerando que alguns pacientes apresentam sinais focais que não estão representados na escala de Cincinatti, a equipe de atendimento pré-hospitalar deve estar treinada para reconhecer outros sinais de início súbito como vertigem associada à falta de equilíbrio, adormecimento ou formigamento de um hemicorpo, dificuldade de enxergar em um ou ambos os olhos e cefaleia súbita, intensa e sem causa aparente.  
Já a equipe responsável pelo atendimento hospitalar deve priorizar o uso da _National Institute of Health and Stroke Scale_ (NIHSS), escala que tem grande utilidade diagnóstica, prognóstica e na avaliação sequencial do paciente.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **3.2. Diagnóstico por exames de imagem** -->
O método de imagem mais utilizado, mais disponível e de menor custo para a avaliação inicial do AVC isquêmico agudo é a tomografia computadorizada (TC) de crânio, que pode demonstrar sinais precoces de isquemia em até 67% dos casos nas primeiras 3 horas do início dos sintomas<sup>23</sup> e em até 82% dos casos nas primeiras 6 horas do icto (última hora em que a pessoa foi vista assintomática)<sup>24</sup> A detecção aumenta para aproximadamente 90% após 1 semana<sup>13,14</sup> . Além disso, a TC de crânio tem boa capacidade para identificar sangramentos associados. A lesão isquêmica aparece como uma hipodensidade que não se impregna pelo contraste, geralmente no território suprido pela artéria cerebral média.  
A ressonância magnética (RM) é bem mais sensível e precisa na identificação e localização da lesão vascular, especialmente quando são utilizadas técnicas de difusão/perfusão<sup>23</sup> , no entanto, consome um tempo de realização maior que pode ser decisivo para a indicação do tratamento com trombolítico.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **3.3. Outros exames complementares** -->
Frente à suspeita clínica de AVC, os seguintes exames devem ser solicitados: eletrocardiografia de repouso; glicemia capilar; hemograma completo (com contagem de plaquetas); tempo de protrombina com medida do RNI (razão internacional normalizada); tempo parcial de tromboplastina ativada (TTPA); e níveis séricos de potássio, sódio, ureia e creatinina, e troponina.  
A eletrocardiografia visa a identificar arritmias que aumentem o risco de AVC, sinais de infarto do miocárdio ou dissecção de aorta associada, enquanto os exames laboratoriais avaliam o grau de coagulabilidade e situações que possam mimetizar ou agravar um AVC em curso (como, por exemplo, hipoglicemia, infecção ou distúrbios hidroeletrolíticos)<sup>5</sup> .

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **3.4. Diagnóstico diferencial** -->
O conhecimento do médico sobre as principais formas de instalação das desordens cerebrais é fundamental para o diagnóstico clínico de AVC hemorrágico ou isquêmico. Por exemplo, um déficit que se desenvolve durante semanas é usualmente decorrente de lesão cerebral com efeito de massa, p. ex., neoplasia ou abscesso cerebrais. Já um hematoma subdural deve ser distinguido de um AVC por seu curso mais prolongado e pela combinação de disfunções focais e difusas. Os ataques isquêmicos transitórios (AIT) podem ser confundidos com migrânea com aura, caracterizada por sinais ou sintomas focais, usualmente visuais como os escotomas cintilantes, hemiparesia ou outros déficits focais<sup>25</sup> . Convulsões podem ser confundidas com AIT. A maioria das convulsões produz atividade motora ou sensitiva positivas, enquanto a maioria dos AVC ou AIT produz sintomas negativos. O estado pós-ictal observado após uma convulsão pode também ocorrer em algumas síndromes isquêmicas.  
Uma pequena proporção de AVC (10%), especialmente os embólicos, é associada a convulsões concomitantes. Outras doenças que podem mimetizar um AVC são: hipoglicemia, doença de Ménière ou outras vestibulopatias periféricas.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes adultos (idade igual ou maior do que 18 anos) com diagnóstico de AVCi agudo.  
A depender do tratamento a ser disponibilizado, o paciente deve apresentar adicionalmente os critérios de inclusão a seguir.  
Para realização de trombólise, serão incluídos pacientes com todos os critérios a seguir:  
- Avaliação de médico neurologista que confirme AVCi agudo;  
- Quadro clínico de AVC com início há menos de 4,5 horas desde o início dos sintomas até a infusão do medicamento;  
- Tomografia computadorizada ou ressonância magnética sem sinais de hemorragia intracraniana.  
Para realização de trombectomia mecânica em indivíduos <u>cujo início dos sintomas tenha ocorrido em até 8 horas ou que tenham sido vistos bem (sem déficit neurológico) pela última vez em até 8 horas, os pacientes deverão apresentar todos os</u> critérios a seguir:  
● Oclusão envolvendo a artéria carótida interna intracraniana, o primeiro segmento da artéria cerebral média (M1) ou ambos, e viabilidade de tratamento em até 8 horas após o início dos sintomas (definido como o momento em que o paciente foi visto pela última vez em um estado normal de saúde);  
- Pontuação de pré-ataque de 0 ou 2 na escala de Rankin modificada (variação de 0 [sem sintomas] a 6 [morte]);  
- Pontuação de 6 ou mais na NIHSS (intervalo de 0 a 42, com valores mais altos indicando déficit mais grave) na  
- apresentação.  
Para realização de trombectomia mecânica em indivíduos <u>cujo início dos sintomas tenha ocorrido entre 8 e 24 horas ou que tenham sido vistos bem (sem déficit neurológico) pela última vez entre 8 e 24 horas, os pacientes deverão apresentar todos</u> os critérios a seguir:  
- Sinais e sintomas consistentes com o diagnóstico de um AVCi de circulação anterior agudo;  
- pontuação de 6 ou mais na NIHSS;  
- pontuação na escala de Rankin modificada menor ou igual a 2 antes do curso de qualificação (funcionalmente independente para todas as atividades da vida diária - AVD);  
- volume do infarto (avaliado por perfusão ou difusão), considerando os seguintes pontos de corte:  
- Menor que 21 cm³, em pacientes com idade maior ou igual a 80 anos e com NIHSS acima de 10;  
- Menor que 31 cm³, em pacientes com idade menor que 80 anos e com NIHSS entre 10 e 19;  
- Menor que 51 cm³, em pacientes com idade menor que 80 anos e com NIHSS acima de 20;  
- Menor que 70 cm³, em pacientes com _mismatch_ maior que 1,8, penumbra maior que 15 mL e que apresentem janela de sintomas entre 8 e 16 horas.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento ou procedimento preconizados neste Protocolo. A depender do tratamento a ser disponibilizado, o paciente pode apresentar adicionalmente os critérios de exclusão a seguir.  
Para realização de <u>trombólise, serão excluídos pacientes que apresentem uma das contraindicações ao procedimento,</u> quais sejam:  
- Resolução completa espontânea imediata ou área de hipodensidade precoce à tomografia computadorizada (sugestiva  
- de área isquêmica aguda) com acometimento maior do que um terço do território da artéria cerebral média;  
- Realização de cirurgia de grande porte nos últimos 14 dias;  
- Histórico de hemorragia intracraniana;  
- Malformações arteriovenosas ou tumores intracranianos;  
- Pressão arterial sistólica maior que 185 mmHg após tratamento anti-hipertensivo (não responsiva à correção  
adequada);  
- Pressão arterial diastólica maior que 110 mmHg após tratamento anti-hipertensivo (não responsiva à correção  
- adequada);  
- Suspeita de hemorragia subaracnóide;  
- Hemorragia gastrointestinal ou genitourinária nos últimos 21 dias;  
● Contagem de plaquetas menor que 100.000/μL; RNI acima de 1,7; TTPA acima de 40s (sem necessidade de esperar resultados para iniciar a trombólise na maioria dos casos; aguardar sempre RNI em pacientes em uso de antagonistas da vitamina K - varfarina, femprocumona; aguardar TTPA em pacientes hospitalizados que estejam usando heparina não fracionada endovenosa; aguardar contagem de plaquetas nos pacientes com histórico ou suspeita de plaquetopenia;  aguardar todos os exames de coagulação em pacientes com histórico de coagulopatia ou hepatopatia ou hemorragia);  
- Defeito na coagulação (RNI maior que 1,7);  
● Uso de anticoagulantes orais diretos (ACOD - inibidores diretos de trombina ou de fator Xa) nas últimas 48 horas, se a função renal estiver normal. Caso o paciente apresente testes de coagulação (TTPA, RNI, contagem de plaquetas, tempo de trombina, tempo de ecarina, atividade de Xa) normais, a trombólise pode ser realizada, se não apresentar outras contraindicações. Em pacientes em uso de dabigatrana, se houver o agente reversor disponível (idarucizumabe), ele pode ser utilizado e a trombólise realizada logo após;  
- Suspeita de hemorragia subaracnóide, mesmo com tomografia normal;  
- Em uso de dose terapêutica de heparina de baixo peso molecular nas últimas 24 horas;  
- Endocardite bacteriana;  
- Dissecção de arco aórtico; e  
- Hemorragia interna ativa, evidência de sangramento ativo em sítio não passível de compressão mecânica.  
NOTA 1: O uso de antiagregante plaquetário e crise convulsiva não são contraindicações para a realização de trombólise. Alguns fatores determinados interferem no risco-benefício da terapia trombolítica, não sendo, contudo, contraindicação absoluta de seu uso: NIHSS maior que 22, idade acima de 80 anos e a combinação de AVC prévio e diabete melito. A presença de aneurisma conhecido não roto não é um fator de exclusão para o tratamento do AVCi, porém deve-se individualizar, principalmente em aneurismas de maiores tamanhos.  
NOTA 2: O paciente ou responsável legal devem ser esclarecidos quanto aos riscos e benefícios do tratamento trombolítico e deve ficar registrado em prontuário a realização deste esclarecimento, assim como a concordância em utilizá-lo.  
Ainda, pacientes com uma das seguintes contraindicações relativas devem ter a relação entre o risco e o benefício do tratamento avaliados individualmente:  
- Sinais e sintomas leves (com comprometimento funcional discreto);  
- Realização de qualquer cirurgia intracraniana, trauma craniano ou histórico de AVC grave nos 3 meses anteriores ao  
- tratamento trombolítico;  
- Realização de punção lombar nos últimos 7 dias (executada de forma tecnicamente correta);  
- Histórico de infarto agudo do miocárdio nos últimos 3 meses;  
- Realização de punção arterial, em sítio não compressível, nos últimos 7 dias; e  
● Glicemia abaixo de 50 mg/dL, quando houver recuperação completa do déficit focal e o mesmo for atribuído à hipoglicemia e não a um AVC.  
Para realização de trombectomia mecânica em indivíduos <u>cujo início dos sintomas tenha ocorrido em até 8 horas ou que tenham sido vistos bem (sem déficit neurológico) pela última vez em até 8 horas, serão excluídos os pacientes cujos exames de</u> imagem apontem evidência de hemorragia intracraniana recente ou grande infarto, definido por um escore de tomografia computadorizada precoce do _Alberta Stroke Program_ (ASPECTS) inferior a 6 (faixa de 0 a 10, com valores mais altos indicando menor carga de infarto) ou inferior a 5 na difusão por imagem de ressonância magnética ponderada (MRI).  
Para realização de trombectomia mecânica em indivíduos <u>cujo início dos sintomas tenha ocorrido entre 8 e 24 horas ou</u>  
<u>que tenham sido vistos bem (sem déficit neurológico) pela última vez entre 8 e 24 horas, serão excluídos os pacientes que</u> apresentem um dos critérios a seguir:  
- Idade superior a 90 anos;  
- Alergia conhecida ao iodo que impeça um procedimento endovascular;  
● Diátese hemorrágica hereditária ou adquirida conhecida; deficiência do fator de coagulação; terapia anticoagulante oral recente com RNI maior que 3 (o uso recente de um dos novos anticoagulantes orais não é uma exclusão se a taxa de filtração glomerular [TFG] estiver estimada acima de 30 mL/min);  
- Convulsões no início do AVC, se isso impedir a utilização da NIHSS;  
- Contagem basal de plaquetas menor que 50.000/μL;  
- Hipertensão arterial grave sustentada (pressão arterial sistólica acima de 185 mmHg ou pressão arterial diastólica  
- acima de 110 mmHg);  
- Embolia séptica presumida;  
- Suspeita de endocardite bacteriana; ou  
- Histórico de hemorragia nos últimos 30 dias.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **6. TRATAMENTO** -->
O paciente com suspeita de AVCi agudo deve ser encaminhado, preferencialmente, a um hospital habilitado como Centro de Atendimento de Urgência aos Pacientes com Acidente Vascular Cerebral que possua recursos apropriados para atendimento adequado de AVC. Para que se considere um centro apto ao recebimento destes pacientes e à infusão de trombolítico, os seguintes recursos devem estar disponíveis:  
- Equipe organizada, definida e capacitada, coordenada por neurologista clínico (conforme art. 128 a 137 da Portaria  
- de Consolidação nº 3, de 28 de setembro de 2017), disponível durante 24 horas, e que tenha recebido treinamento adequado;  
- Capacidade para monitorização contínua cardiovascular e respiratória;  
- Unidade de terapia intensiva;  
- Laboratório de patologia clínica em funcionamento durante 24 horas;  
- Aparelho de tomografia computadorizada disponível durante 24 horas;  
- Disponibilidade neurocirúrgica durante 24 horas; e  
- Serviço de hemoterapia ou agência transfusional durante 24 horas, incluindo a disponibilidade de crioprecipitado.  
A **Figura 1** detalha os procedimentos de tratamento de um paciente com suspeita de AVCi agudo até 24 horas de evolução.  
**Figura 1** - Fluxograma de tratamento do paciente com suspeita de AVCi agudo.  
<!-- Start of picture text -->
"AVALIAGAO MULTIPROFISSIONAL NA SALA VERMELHA<br>NEUROMAGEM<br>Cocos somes co tenes<br>Ceti Gre Uaetes « Havoc<br>‘Tempo de sintomas entre 8 e 24 horas: TC + Angio TC de vasos intra e extracranianos + TC Perfusao (se disponivel) ou RM + ARM<br>Avaliar TC de cranio<br>ane<br>Tipotesate<br>tee tristemen doncae\ Nap ere,=<br>Déficit neurologico com (antiagregante)<br>eae,<br>| sm<br>os ‘Sim Tempo de sintomas<br>ie pee ant<br>salarSaRE Ange TO ae<br>ee<br>véocusioce “| Tatanert<br>tran as! 4 ne,<br>| on<br>ee,<br>eens am ‘Tempo de<br>io<br>ose<br>lar Opes figsRaziioTompoSeri dede verPrancale  mismatchcesnaeae inaigualouou Thar maiorre eve 24que 1,8ors<br><!-- End of picture text -->  
Fonte: baseado no AHA/ASA Guideline<sup>1</sup> e adaptado dos Protocolos de AVC do Hospital de Clínicas de Porto Alegre e do Hospital Moinhos de Vento.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **6.1. Tratamento não medicamentoso** -->
A trombectomia mecânica é o procedimento de remoção endovascular de um coágulo obstrutivo de um vaso sanguíneo realizada durante o exame de angiografia com o uso de cateteres para conduzir um dispositivo até a obstrução em uma artéria cerebral. Há 2 tipos de dispositivos: um _stent_ autoexpansível removível ( _stent-retriever_ ), que se integra ao trombo e depois é retirado e extrai o trombo da circulação, e um sistema de aspiração que aspira o trombo e desobstrui a artéria<sup>26</sup>  
Os procedimentos para realização da trombectomia mecânica consistem na utilização de um cateter guia, idealmente cateter-balão, colocado proximalmente na artéria cervical de acesso ao vaso ocluído. Posteriormente, um conjunto consistindo de um microcateter e um micro-guia é navegado até o vaso ocluído. No caso da técnica de _stent-retriever_ , esse conjunto ultrapassa o trombo. A seguir, o microguia é retirado e o _stent retriever_ é passado através do microcateter para posicionar sua extremidade distal após o trombo. O microcateter é então retirado enquanto o dispositivo é mantido no lugar e o _stent retriever_ se abre dentro do trombo, permitindo sua integração ao coágulo. O dispositivo permanece implantado no coágulo por 3 a 5 minutos. Por fim, o  
cateter guia-balão é inflado para obstruir o fluxo na artéria carótida interna e sob aspiração contínua com seringa, o _stent-retriever_ e o microcateter são lentamente retirados para o cateter guia de balão, sendo assim avaliada a recanalização<sup>27,28</sup> .  
Já a estratégia de aspiração utiliza um sistema tri-axial, consistindo de um cateter guia (com ou sem balão) em que se coloca um conjunto de microcateter e microguia. O microguia é navegado até o contato do trombo, idealmente sem ultrapassálo. Em seguida, um sistema de aspiração deve ser engajado no coágulo à medida em que se retira o conjunto do microcateter e microguia, ligando-se à bomba de aspiração por 3 a 5 minutos. Após, retira-se o cateter de aspiração para o cateter guia e então se avalia a reperfusão arterial.  
Preconiza-se a realização de trombectomia mecânica em pacientes com lesões de grandes vasos e com janela do início de sintomas menor que 8 horas ou entre 8 a 24 horas, de acordo com os critérios de inclusão e exclusão deste Protocolo. Por vezes é comum o paciente apresentar os sintomas de AVC ao acordar, não sendo possível determinar com precisão o tempo transcorrido desde o início dos sintomas. Nestes casos, considera-se o último momento em que foi visto bem (sem déficit neurológico). Uma vez calculado esse tempo, o paciente deverá ser tratado de acordo com janela do início de sintomas supracitadas. Por exemplo, se o paciente foi visto bem há 6 horas, este deve ser avaliado quanto aos critérios de elegibilidade para a realização de trombectomia com janela de sintomas de até 8 horas; se o paciente foi visto bem há 12 horas, este deve ser avaliado quanto aos critérios de elegibilidade para a realização de trombectomia com janela de sintomas entre 8 a 24 horas. Os casos em que os pacientes foram vistos bem há mais de 24 horas não são elegíveis para trombectomia mecânica neste Protocolo.  
Para a realização da trombectomia mecânica, pode-se utilizar anestesia geral ou sedação consciente. A escolha da modalidade anestésica deve considerar aspectos individuais (jejum, agitação e nível de consciência), vômitos, complexidade e tempo do procedimento, dentre outros. Sugere-se o rigoroso monitoramento da pressão arterial sistêmica, com intervalos pressóricos estreitos, sobretudo durante a indução anestésica em caso de anestesia geral e no momento da abertura do vaso. Devese evitar episódios de hipotensão e hipertensão, principalmente após a obtenção de recanalização efetiva (mTICI > 2b) quando o alvo pressórico deve ser ajustado para níveis abaixo de 160/100 mm Hg. A equipe deve decidir conjuntamente os níveis pressóricos a serem alcançados ou mantidos durante o procedimento.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **6.2. Tratamento medicamentoso** -->
A trombólise é um tratamento recomendado no AVCi agudo que envolve o uso de medicamentos trombolíticos para a destruição do coágulo, como alteplase, estreptoquinase e tenecteplase. Dentre os medicamentos, a alteplase é o mais utilizado e o único preconizado neste Protocolo. Sobre a tecnecteplase, estudos recentes indicam um potencial efeito benéfico de seu uso em pacientes com AVCi agudo. No entanto, no Brasil, não há indicação aprovada em bula para tratamento de AVCi. Quanto ao uso da estreptoquinase, estudos avaliando sua eficácia e segurança não demonstraram bons resultados, tendo sido suspensos prematuramente<sup>29</sup> e não há evidências para substanciar o tratamento de AVC isquêmico com este medicamento.  
A eficácia da terapia em pacientes com AVCi agudo é dependente do tempo decorrente entre o início dos sintomas e a instituição de tratamento. Devido à estreita janela terapêutica, o número de pacientes que recebe tratamento é pequeno e é possível prevenir desfechos adversos como a incapacidade em somente 6 a cada 1.000 pacientes com AVC<sup>30</sup>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **7. FÁRMACO** -->
- Alteplase: frascos-ampola de 50 mL de diluente com 50 mg de alteplase; frascos-ampola de 20 mL de diluente com 20 mg de alteplase; frascos-ampola de 10 mL de diluente com 10 mg de alteplase.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **7.1. Esquema de administração** -->
**-** Alteplase: 0,9 mg/kg (máximo de 90 mg), por via intravenosa, com 10% da dose aplicada em bolus e o restante, continuamente, ao longo de 60 minutos. A administração da alteplase deve ocorrer em até 4 horas e 30 minutos do início dos sintomas de AVCi.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **8. MONITORIZAÇÃO** -->
Pacientes que receberam terapia trombolítica devem manter restrição alimentar (sem quaisquer alimentos ou líquidos, incluindo medicamentos administrados por via oral) durante 24 horas. Antes da primeira alimentação, todos os pacientes com AVC (tratamento conservador, trombólise ou trombectomia) devem ser rastreados para disfagia a fim de prevenir a pneumonia pós-AVC e diminuir risco de mortalidade precoce. Testes de deglutição de água ou testes de consistência múltipla são preconizados durante a pesquisa da disfagia.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **8.1. Monitorização pós trombólise** -->
Deve-se monitorar continuamente, por pelo menos 24 horas, a pressão arterial, oximetria de pulso e eletrocardiografia. A glicemia também deve ser monitorizada e mantida em níveis inferiores a 200 mg/dL. A temperatura axilar também deve ser foco de monitorização, devendo ser tratada se maior ou igual a 37,5°C. Além de sangramento, outros eventos adversos, tais como mal-estar, vômitos, calafrios, elevação de temperatura, urticária, dor de cabeça, convulsões, estados de perturbação da consciência devem ser prontamente detectados. O Doppler transcraniano é um método auxiliar promissor no seguimento da trombólise intravenosa<sup>31</sup> , e seu uso é encorajado, mas não obrigatório, nos centros com equipamento disponível e profissionais devidamente habilitados.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **8.2. Monitorização pós trombectomia mecânica** -->
Deve-se avaliar clinicamente e registrar a evolução neurológica e funcional dos pacientes, aplicando a NIHSS<sup>21,32</sup> antes do tratamento e após 24 horas da ocorrência do AVCi agudo, e o escore de Rankin modificado<sup>21,32</sup> após 3 meses da ocorrência do AVCi agudo.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Os pacientes com suspeita de AVCi agudo devem ser atendidos em hospitais com os recursos físicos e humanos especificados anteriormente, preferencialmente habilitados como Centro de Atendimento de Urgência aos Pacientes com Acidente Vascular Cerebral I, II ou III, para seu adequado diagnóstico, tratamento e acompanhamento, devendo-se observar os critérios de inclusão e exclusão estabelecidos neste Protocolo.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **10. REFERÊNCIAS** -->
1. Powers WJ, Rabinstein AA, Ackerson T, Adeoye OM, Bambakidis NC, Becker K, et al. Guidelines for the early  
management of patients with acute ischemic stroke: 2019 update to the 2018 guidelines for the early management of acute ischemic stroke: a guideline for healthcare professionals from the American Heart Association/American Stroke Association. Stroke. 2019;  
2. Roth GA, Mensah GA, Johnson CO, Addolorato G, Ammirati E, Baddour LM, et al. Global burden of cardiovascular  
diseases and risk factors, 1990–2019: update from the GBD 2019 study. J Am Coll Cardiol. 2020;76(25):2982–3021.  
3. WHO. World Health Organization. Stroke, Cerebrovascular accident [Internet]. [cited 2023 Dec 6]. Available from:  
WHO EMRO | Stroke, Cerebrovascular accident | Health topics  
4. Naghavi M, Abajobir AA, Abbafati C, Abbas KM, Abd-Allah F, Abera SF, et al. Global, regional, and national age-  
sex specific mortality for 264 causes of death, 1980–2016: a systematic analysis for the Global Burden of Disease Study 2016. The lancet. 2017;390(10100):1151–210.  
5. Estratégicas. M da SaúdeS de A à SaúdeD de AP. Diretrizes de atenção à reabilitação da pessoa com acidente  
vascular cerebral. Brasília; 2013.  
6. Martí-Carvajal AJ, Valli C, Martí-Amarista CE, Solà I, Martí-Fàbregas J, Bonfill Cosp X. Citicoline for treating  
people with acute ischemic stroke. Cochrane Database Syst Rev. 2020;8(8):CD013066.  
7. Cassella CR, Jagoda A. Ischemic Stroke: Advances in Diagnosis and Management. Emerg Med Clin North Am.  
2017 Nov;35(4):911–30.  
8. Martynov MY, Gusev EI. Current knowledge on the neuroprotective and neuroregenerative properties of citicoline  
in acute ischemic stroke. J Exp Pharmacol. 2015;7:17–28.  
9. Albers GW, Amarenco P, Easton JD, Sacco RL, Teal P. Antithrombotic and thrombolytic therapy for ischemic  
stroke. Chest. 2001;119(1):300S-320S.  
10.  O’Donnell MJ, Chin SL, Rangarajan S, Xavier D, Liu L, Zhang H, et al. Global and regional effects of potentially  
modifiable risk factors associated with acute stroke in 32 countries (INTERSTROKE): a case-control study. Lancet. 2016;388(10046):761–75.  
11.  O’Donnell MJ, Xavier D, Liu L, Zhang H, Chin SL, Rao-Melacini P, et al. Risk factors for ischaemic and  
intracerebral haemorrhagic stroke in 22 countries (the INTERSTROKE study): a case-control study. Lancet. 2010 Jul;376(9735):112–23.  
12.  Mallmann AB, Fuchs SC, Gus M, Fuchs FD, Moreira LB. Population-attributable risks for ischemic stroke in a  
community in South Brazil: a case-control study. PLoS One. 2012;7(4):e35680.  
13.  Donnan GA, Fisher M, Macleod M, Davis SM. Stroke. Lancet. 2008;371(9624):1612–23.  
14.  Yew KS, Cheng E. Acute stroke diagnosis. Am Fam Physician. 2009 Jul;80(1):33–40.  
15.  Eswaradass PV, Dey S, Singh D, Hill MD. Pulmonary Embolism in Ischemic Stroke. Can J Neurol Sci.  
2018;45(3):343–5.  
16.  Hankey GJ, Jamrozik K, Broadhurst RJ, Forbes S, Burvill PW, Anderson CS, et al. Five-year survival after first-  
ever stroke and related prognostic factors in the Perth Community Stroke Study. Stroke. 2000;31(9):2080–6.  
17.  Martynchik S. A.; Sokolova O V. Medical and economic assessment and rationale for improving organization of  
inpatient care for cerebral stroke. Sotsial’nyye aspekty zdorov’ya naseleniya [Social Aspects of Population Health]. 2013;30(2). 18.  Hankey GJ. Stroke. Lancet. 2017;389(10069):641–54.  
19.  Wang H, Naghavi M, Allen C, Barber RM, Bhutta ZA, Carter A, et al. Global, regional, and national life expectancy, all-cause mortality, and cause-specific mortality for 249 causes of death, 1980–2015: a systematic analysis for the Global Burden of Disease Study 2015. The lancet. 2016;388(10053):1459–544.  
20.  Wardlaw JM, Murray V, Berge E, del Zoppo GJ. Thrombolysis for acute ischaemic stroke. Cochrane Database Syst  
Rev. 2014 Jul;2014(7):CD000213.  
21.  de et al. Caneda MAG. Confiabilidade de escalas de comprometimento neurológico em pacientes com acidente  
vascular cerebral. Arq Neuropsiquiatr. 2006;64(3):690–7.  
22.  Kothari R, Hall K, Brott T, Broderick J. Early stroke recognition: developing an out-of-hospital NIH Stroke Scale.  
Acad Emerg Med. 1997;4(10):986–90.  
23.  Roberts HC, Dillon WP, Furlan AJ, Wechsler LR, Rowley HA, Fischbein NJ, et al. Computed tomographic findings  
in patients undergoing intra-arterial thrombolysis for acute ischemic stroke due to middle cerebral artery occlusion: results from the PROACT II trial. Stroke. 2002 Jun;33(6):1557–65.  
24.  Patel SC, Levine SR, Tilley BC, Grotta JC, Lu M, Frankel M, et al. Lack of clinical significance of early ischemic  
changes on computed tomography in acute stroke. JAMA. 2001;286(22):2830–8.  
25.  Comitê de Classificação das Cefaleias da Sociedade Internacional de Cefaleia. Kowacs F (coordenador); tradução  
Fernando Kowacs; Djacir Dantas Pereira de Macedo, Raimundo Pereira da Silva-Néto. The International Classification of Headache Disorders [Internet]. 3a ed. São Paulo : Omnifarma; 2018. Available from: <u>https://ihs-headache.org/wpcontent/uploads/2021/03/ICHD-3-Brazilian-Portuguese.pdf</u>  
26.  Munich SA, Vakharia K, Levy EI. Overview of Mechanical Thrombectomy Techniques. Neurosurgery. 2019  
Jul;85(suppl_1):S60--S67.  
27.  Beadell NC, Lutsep H. New stent retriever devices. Curr Atheroscler Rep. 2013 Jun;15(6):333.  
28.  Leung V, Sastry A, Srivastava S, Wilcock D, Parrott A, Nayak S. Mechanical thrombectomy in acute ischaemic  
stroke: a review of the different techniques. Clin Radiol. 2018;73(5):428–38.  
29.  Adams HPJ, Adams RJ, Brott T, del Zoppo GJ, Furlan A, Goldstein LB, et al. Guidelines for the early management  
of patients with ischemic stroke: A scientific statement from the Stroke Council of the American Stroke Association. Stroke. 2003;34(4):1056–83.  
30.  Gilligan AK, Thrift AG, Sturm JW, Dewey HM, Macdonell RAL, Donnan GA. Stroke units, tissue plasminogen  
activator, aspirin and neuroprotection: which stroke intervention could provide the greatest community benefit? Cerebrovasc Dis. 2005;20(4):239–44.  
31.  Alexandrov A V, Molina CA, Grotta JC, Garami Z, Ford SR, Alvarez-Sabin J, et al. Ultrasound-enhanced systemic  
thrombolysis for acute ischemic stroke. N Engl J Med. 2004 Nov;351(21):2170–8.  
32.  Cincura C, Pontes-Neto OM, Neville IS, Mendes HF, Menezes DF, Mariano DC, et al. Validation of the National  
Institutes of Health Stroke Scale, modified Rankin Scale and Barthel Index in Brazil: the role of cultural adaptation and structured interviewing. Cerebrovasc Dis. 2009;27(2):119–22.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **APÊNDICE 1** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **1. Escopo e finalidade** -->
O presente Apêndice contém o documento de trabalho do grupo desenvolvedor do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do AVCi agudo, apresentando a descrição da metodologia, as recomendações e o racional para tomada de decisão. Este documento de trabalho tem o objetivo de embasar o texto normativo contido no PCDT, aumentar a sua transparência e fornecer considerações adicionais para profissionais da saúde, gestores e demais interessados.  
O público-alvo deste PCDT é composto por profissionais de saúde envolvidos no atendimento de pacientes com AVCi agudo, em especial neurologistas, neurorradiologistas, neurointensivistas e profissionais da <mark>medicina de urgência e emergência e cirurgia vascular.</mark> Os pacientes com mais de 18 anos com diagnóstico de AVCi agudo são a população-alvo destas recomendações.  
A atualização desse documento foi iniciada em 30 de março de 2021, com a realização de uma reunião de escopo, a qual definiu as perguntas de pesquisa desse documento. As reuniões de recomendação, com a presença de especialistas, ocorreram em 29 de outubro e em 5 de novembro de 2021.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **2. Equipe de elaboração e partes interessadas** -->
O Grupo Elaborador deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (DGITS/SECTICS/MS).  
As reuniões de escopo e de recomendações contaram com a participação de médicos das seguintes especialidades: medicina de urgência e emergência, cirurgia vascular, neurologia, neurointensivismo e neurorradiologia, além de representantes do Ministério da Saúde, hospitais de excelência, sociedades médicas, sociedades sem fins lucrativos e associação de pacientes. O painel de especialistas foi responsável pelo julgamento das evidências identificadas em resposta às questões deste Protocolo e das suas respectivas recomendações, além de revisão do documento final. Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ). Os participantes que possuíssem conflito de interesse relevante associado a uma ou mais questões do documento seriam impossibilitados de participar da discussão das questões específicas, sem impedimento de participar da discussão das demais questões, incluindo votação caso não fosse obtido consenso. O principal conflito de interesse citado pelos participantes do painel foi o recebimento de honorários por atividade prestada a instituições com interesse no escopo da diretriz (item 1b).  
**Quadro A** - Questionário de conflitos de interesse em diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeirament|e algum dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|  
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|---|---|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma|(   ) Sim|
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta do PCDT do Acidente Vascular Cerebral Isquêmico (AVCi) agudo foi apresentada na 95ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em novembro de 2021. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Vigilância Sanitária (SVS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria Especial de Saúde Indígena (SESAI). O PCDT foi aprovado para avaliação pelo Plenário da Conitec.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **4. Busca da evidência** -->
O processo de desenvolvimento desse Protocolo seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), o qual classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto)<sup>1</sup> .  
<mark>Para cada dúvida clínica, foi elaborada uma pergunta de pesquisa, conforme acrônimo PICO. Para cada uma destas questões, p</mark> rocedeu-se com busca estruturada nas seguintes bases de dados: _<mark>Medical Literature Analysis and Retrieval System Online</mark>_ <mark>(MEDLINE) via Pubmed,</mark> _<mark>Excerpta medica database</mark>_ <mark>(EMBASE) via Elsevier,</mark> _<mark>Cochrane Central Register of Controlled Trials</mark>_ <mark>via Cochrane Library (CENTRAL), Literatura latino-americana em ciências da saúde (LILACS) via Biblioteca Virtual de Saúde e</mark> Epistemonikos. Ta <mark>mbém foram realizadas buscas em repositórios de diretrizes clínicas para identificar possíveis atualizações no que diz respeito a</mark> o cuidado <mark>de pacientes com AVCi.</mark>  
<mark>A seleção dos artigos foi realizada conforme critérios de elegibilidade pré-estabelecidos para cada uma das perguntas. De forma geral, foram selecionadas as revisões sistemáticas com meta-análise (RSMA) e, na ausência de RSMA de qualidade, os ensaios clínicos randomizados.</mark>  
<mark>As revisões sistemáticas foram avaliadas por meio da ferramenta Robis</mark><sup>2</sup> <mark>. Os ensaios clínicos randomizados foram avaliados por meio da ferramenta</mark> _<mark>Risk of Bias</mark>_ <mark>, proposta pela Cochrane (ROB 2.0)</mark><sup>3</sup> <mark>. Para a extração de dados, foi utilizada uma ficha de extração padronizada e desenvolvida pelo grupo elaborador. Os resultados foram apresentados em risco relativo (RR) ou diferença de médias (DM), com seus respectivos intervalos de confiança (IC) de 95%. O modelo de efeitos aleatórios foi utilizado nas meta-análises.</mark>  
<mark>Os achados foram resumidos levando em consideração os seguintes aspectos: benefícios, riscos, certeza da evidência, custos, viabilidade e outras considerações (equidade, aceitabilidade e preferência dos pacientes).</mark>  
<mark>Por fim, foi utilizado o sistema GRADE para a avaliação da certeza da evidência</mark><sup>4</sup> <mark>. Todas as avaliações foram realizadas por dois pesquisadores de forma independente, com eventuais discordâncias sendo resolvidas mediante consulta a um terceiro avaliador. A interpretação dos níveis de evidência de acordo com o GRADE é apresentada no</mark> **<mark>Quadro B</mark>** <mark>.</mark>  
**Quadro B** - Níveis de evidências de acordo com o sistema GRADE.  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a confiança<br>na estimativa do efeito.|
|**Moderado**|Há confiança moderada no efeito<br>estimado.|Trabalhos futuros poderão modificar a confiança na estimativa de<br>efeito, podendo, inclusive, modificar a estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto importante<br>em nossa confiança na estimativa de efeito.|
|**Muito baixo**|A confiança na estimativa de efeito é<br>muito limitada.|Qualquer estimativa de efeito é incerta.|  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
||Há um importante grau de incerteza nos||
||achados.||  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014<sup>4</sup>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **5. Desenvolvimento das recomendações** -->
Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou condicional, de acordo com o sistema GRADE ( **Quadro C** ).  
**Quadro C** - Implicações da força da recomendação para profissionais, pacientes e gestores em saúde.  
|**Público-alvo**|**Forte**|**Condicional**|
|---|---|---|
|**Gestores**|A recomendação deve ser adotada como<br>política de saúde na maioria das situações|É necessário debate substancial e envolvimento das partes<br>interessadas.|
|**Pacientes**|A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um<br>pequeno número não aceitaria essa<br>recomendação|Grande parte dos indivíduos desejaria que a intervenção<br>fosse indicada; contudo considerável número não aceitaria<br>essa recomendação.|
|**Profissionais da**<br>**saúde**|A maioria dos pacientes deve receber a<br>intervenção recomendada.|O profissional deve reconhecer que diferentes escolhas<br>serão apropriadas para cada paciente para definir uma<br>decisão consistente com os seus valores e preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014<sup>4</sup> .  
Conforme o sistema GRADE, a recomendação pode ser a favor ou contra a intervenção proposta. Além disso, a recomendação pode ser forte (o grupo está bastante confiante que os benefícios superam os riscos) ou condicional/fraca (a recomendação ainda gera dúvidas quanto ao balanço entre benefício e risco). Colocações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou esclarecimentos sobre as mesmas estão documentadas ao longo do texto. A direção e a força da recomendação, assim como sua redação, foram definidas durante as reuniões de recomendação.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **6. Recomendações** -->
Conforme pré-definido, para identificar se há tecnologias que já estão bem conceituadas em diretrizes com qualidade metodológica adequada, inicialmente foram realizadas buscas sistemáticas por diretrizes internacionais nas bases de dados MEDLINE via Pubmed e Tripdatabase, além de repositórios específicos de diretrizes clínicas. As buscas foram realizadas no dia 29 de julho de 2021 ( **Quadro D** ).  
**Quadro D** - Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes sobre o uso das tecnologias avaliadas neste PCDT.  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via<br>Pubmed<br>29/07/2021|#1 "Ischemic Stroke"[Mesh] OR Ischemic Stroke* OR Cryptogenic Ischemic<br>Stroke* OR Cryptogenic Stroke* OR Cryptogenic Embolism Stroke* OR Acute<br>Ischemic Stroke*<br>#2 "Guidelines as Topic"[Mesh] OR "Practice Guideline" [Publication Type]<br>OR "Health Planning Guidelines"[Mesh]OR Guidelines as Topics OR Clinical<br>Practice Guideline OR "Clinical Protocols"[Mesh] OR Protocol, Clinical OR<br>Clinical Protocol OR Protocols, Clinical OR Treatment Protocols OR Treatment<br>Protocol OR Protocols, Treatment OR Clinical Research Protocol OR Research<br>Protocols, Clinical OR Protocols, Clinical Research OR Research Protocol,<br>Clinical OR Clinical Research Protocols OR Protocol, Clinical Research OR<br>"Consensus"[Mesh] OR "Consensus Development Conference, NIH"<br>[Publication Type] OR "Consensus Development Conference" [Publication<br>Type] OR "Consensus Development Conferences, NIH as Topic"[Mesh] OR<br>"Consensus Development Conferences as Topic"[Mesh] OR "Standard of<br>Care"[Mesh] OR Care Standard OR Care Standards OR Standards of Care)<br>#3 #1 AND #2<br>Filters applied: from 2012/4/12 - 2021/7/29.|4.306|
|TripDatabase<br>–<br>29/07/2021|“Ischemic Stroke”[Filters: Evidence type] [Guidelines]|476|  
Nenhuma diretriz que respondesse a uma das questões clínicas deste PCDT foi encontrada. Portanto, foram realizadas buscas com estratégias estruturadas nas bases de dados eletrônicas para identificar revisões sistemáticas de adequada qualidade metodológica e recentes ou estudos primários adequados para responder a cada questão clínica. Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel e um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **QUESTÃO 1. Deve-se administrar alteplase em pacientes com ou sem lesão dos grandes vasos e com sintomas de AVCi há menos de 4,5 horas?** -->
**<u>Recomendação 1:</u>** Recomendamos utilizar a alteplase nos pacientes com AVCi em qualquer território vascular com início dos sintomas até 4,5 horas (qualidade de evidência moderada; recomendação forte).  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : pacientes adultos (>18 anos) diagnosticados com AVCi agudo com ou sem lesão dos grandes vasos e com sintomas de AVC há menos de 4,5 horas  
**Intervenção** : alteplase  
**Comparador** : outros trombolíticos ou placebo  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Métodos e resultados da busca:** -->
Para a tomada de decisão, foram consideradas as evidências incluídas no PCDT de Trombólise no AVCi (Portaria GM/MS nº 664, de 12 de abril de 2012), e, adicionalmente, foi estruturada e realizada uma busca para localizar as novas evidências acerca da questão. Com base na pergunta PICO estruturada, foi realizada busca sistematizada da literatura por revisões sistemáticas recentes de adequada qualidade metodológica ou estudos primários para responder a cada questão clínica nas bases de dados Pubmed, Lilacs, Embase, Cochrane, e Epistemonikos até o dia 29 de julho de 2021. Foi utilizada uma estratégia de busca para selecionar as referências para responder às três questões sobre alteplase (Questões 1, 2 e 3). As estratégias estão descritas no **Quadro E** .  
**Quadro E** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso da alteplase  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via<br>Pubmed<br>29/07/2021|#1 "Ischemic Stroke"[Mesh] OR Ischemic Stroke* OR Cryptogenic Ischemic<br>Stroke* OR Cryptogenic Stroke* OR Cryptogenic Embolism Stroke* OR Acute<br>Ischemic Stroke*|6.010|
||#2 "Urokinase-Type Plasminogen Activator"[Mesh] OR Urokinase Type<br>Plasminogen Activator OR U-Plasminogen Activator OR U Plasminogen Activator<br>OR U-PA OR Urinary Plasminogen Activator OR Urokinase OR Renokinase OR<br>Abbokinase OR Single-Chain Urokinase-Type Plasminogen Activator OR Single<br>Chain Urokinase Type Plasminogen Activator OR "lumbrokinase" [Supplementary<br>Concept] OR "duteplase" [Supplementary Concept] OR desmoteplase OR "Tissue<br>Plasminogen Activator"[Mesh] OR Plasminogen Activator, Tissue OR Tissue<br>Activator D-44 OR Tissue Activator D 44 OR Tisokinase OR Tissue-Type||  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||Plasminogen Activator OR Tissue Type Plasminogen Activator OR TTPA OR T-<br>Plasminogen Activator OR T Plasminogen Activator OR Alteplase OR Actilyse OR<br>Plasminogen Activator, Tissue-Type OR Plasminogen Activator, Tissue Type OR<br>Activase OR Actilyse OR Lysatec rt-PA OR Lysatec rt PA OR Lysatec rtPA OR<br>"Streptokinase"[Mesh] OR Streptase OR Streptodecase OR Kabikinase OR Awelysin<br>OR Celiase OR Distreptase OR Kabivitrum OR Avelizin OR "Tenecteplase"[Mesh]<br>OR Metalyse OR TNKase OR retevase OR "saruplase" [Supplementary Concept] OR<br>recombinant unglycosylated single-chain urokinase-type plasminogen activator OR<br>pro-urokinase OR prourokinase OR Rescupase<br>#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR random*[Title/Abstract]<br>OR random allocation[MeSH Terms] OR therapeutic use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR integrative<br>overview*[tiab] OR research integration*[tiab] OR research overview*[tiab] OR<br>collaborative review*[tiab] OR collaborative overview*[tiab] OR systematic<br>review*[tiab] OR technology assessment*[tiab] OR technology overview*[tiab] OR<br>"Technology Assessment, Biomedical"[mh] OR HTA[tiab] OR HTAs[tiab] OR<br>comparative efficacy[tiab] OR comparative effectiveness[tiab] OR outcomes<br>research[tiab] OR indirect comparison*[tiab] OR ((indirect treatment[tiab] OR<br>mixed-treatment[tiab]) AND comparison*[tiab]) OR Embase*[tiab] OR<br>Cinahl*[tiab] OR systematic overview*[tiab] OR methodological overview*[tiab]<br>OR methodologic overview*[tiab] OR methodological review*[tiab] OR<br>methodologic review*[tiab] OR quantitative review*[tiab] OR quantitative<br>overview*[tiab] OR quantitative synthes*[tiab] OR pooled analy*[tiab] OR<br>Cochrane[tiab] OR Medline[tiab] OR Pubmed[tiab] OR Medlars[tiab] OR<br>handsearch*[tiab] OR hand search*[tiab] OR meta-regression*[tiab] OR<br>metaregression*[tiab] OR data synthes*[tiab] OR data extraction[tiab] OR data<br>abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab] OR der-simonian[tiab] OR<br>dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane Database Syst<br>Rev"[Journal:__jrid21711] OR "health technology assessment winchester,<br>england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR "Evid Rep<br>Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health Care"[Journal]||  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR "GMS Health Technol Assess"[Journal] OR "Health Technol Assess<br>(Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#6 - #1AND #2 AND #5 NOT #6||
|Cochrane<br>29/07/2021|#1 MeSH descriptor: [Ischemic Stroke] explode all trees<br>#2 Ischemic Stroke* OR Cryptogenic Ischemic Stroke* OR Cryptogenic Stroke* OR<br>Cryptogenic Embolism Stroke* OR Acute Ischemic Stroke*<br>#3 MeSH descriptor: [Urokinase-Type Plasminogen Activator] explode all trees<br>#4 Urokinase Type Plasminogen Activator OR U-Plasminogen Activator OR U<br>Plasminogen Activator OR U-PA OR Urinary Plasminogen Activator OR Urokinase<br>OR Renokinase OR Abbokinase OR Single-Chain Urokinase-Type Plasminogen<br>Activator OR Single Chain Urokinase Type Plasminogen Activator OR lumbrokinase<br>OR duteplase OR<br>#5 MeSH descriptor: [Tissue Plasminogen Activator] explode all trees<br>#6 Plasminogen Activator, Tissue OR Tissue Activator D-44 OR Tissue Activator D<br>44 OR Tisokinase OR Tissue-Type Plasminogen Activator OR Tissue Type<br>Plasminogen Activator OR TTPA OR T-Plasminogen Activator OR T Plasminogen<br>Activator OR Alteplase OR Actilyse OR Plasminogen Activator, Tissue-Type OR<br>Plasminogen Activator, Tissue Type OR Activase OR Actilyse OR Lysatec rt-PA<br>OR Lysatec rt PA OR Lysatec rtPA<br>#7 MeSH descriptor: [Streptokinase] explode all trees<br>#8 Streptase OR Streptodecase OR Kabikinase OR Awelysin OR Celiase OR<br>Distreptase OR Kabivitrum OR Avelizin OR Streptase OR Streptodecase OR<br>Kabikinase OR Awelysin OR Celiase OR Distreptase OR Kabivitrum OR Avelizin<br>OR Metalyse OR TNKase OR retevase OR saruplase OR recombinant<br>unglycosylated single-chain urokinase-type plasminogen activator OR pro-urokinase<br>OR prourokinase OR Rescupase<br>#9 #1 OR #2<br>#10 #3 OR #4 OR #5 OR #6 OR #7 OR #8<br>#11 #9 AND #10|1.385|
|EMBASE<br>-<br>29/07/2021|#1 'brain ischemia'/exp OR 'brain ischemia' OR 'acute ischaemic stroke' OR 'acute<br>ischemic stroke' OR 'brain arterial insufficiency' OR 'brain circulation disorder' OR<br>'brain ischaemia' OR 'cerebral blood circulation disorder' OR 'cerebral blood flow|858|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||disorder' OR 'cerebral circulation disorder' OR 'cerebral circulatory disorder' OR<br>'cerebral ischaemia' OR 'cerebral ischemia' OR 'cerebrovascular circulation disorder'<br>OR 'cerebrovascular ischaemia' OR 'cerebrovascular ischemia' OR 'chronic ischemic<br>stroke' OR 'ischaemia cerebri' OR 'ischaemic brain disease' OR 'ischaemic<br>encephalopathy' OR 'ischaemic stroke' OR 'ischemia cerebri' OR 'ischemic brain<br>disease' OR 'ischemic encephalopathy' OR 'ischemic stroke' OR 'neural ischaemia'<br>OR 'neural ischemia'<br>#2 'alteplase'/exp OR alteplase OR 'actilyse; activacin' OR 'activase; altepase' OR<br>'cathflo activase' OR grtpa OR 'recombinant tissue plasminogen activator' OR<br>'recombinant tissue type plasminogen activator' OR 'tissue plasminogen activator,<br>recombinant'<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR  'single-blind procedure':de OR (random* OR  factorial* OR<br>crossover* OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind* OR<br>singl* NEAR/1 blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti<br>OR metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3<br>(literature* OR research* OR studies OR data)):ab,ti OR (pooled AND analys*:ab,ti)<br>OR ((data NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti OR<br>medlars:ab,ti OR embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR psychinfo:ab,ti<br>OR psycinfo:ab,ti OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti OR<br>cancerlit:ab,ti OR cochrane:ab,ti OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti OR<br>((hand OR manual OR database* OR computer*) NEAR/2 search*):ab,ti OR<br>(electronic NEAR/2 (database* OR 'data base' OR 'data bases')):ab,ti OR<br>bibliograph*:ab OR 'relevant journals':ab OR ((review* OR overview*) NEAR/10<br>(systematic* OR methodologic* OR quantitativ* OR research* OR literature* OR<br>studies OR trial* OR effective*)):ab NOT (((retrospective* OR record* OR case*<br>OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*) NEAR/2<br>chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR<br>'nonhuman'/exp NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))||  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7#6 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Lilacs via Portal<br>BVS - 29/07/2021|mh:"Brain Ischemia" OR (Brain Ischemias) OR (Cerebral Ischemia) OR (Cerebral<br>Ischemias) OR (Encephalopathy, Ischemic) OR (Ischemia, Brain) OR (Ischemia,<br>Cerebral) OR (Ischemias, Cerebral) OR (Ischemic Encephalopathies) OR (Ischemic<br>Encephalopathy) OR(Ischemic Stroke*) OR (Cryptogenic Ischemic Stroke*) OR<br>(Cryptogenic Stroke*) OR (Cryptogenic Embolism Stroke*) OR (Acute Ischemic<br>Stroke*) OR mh:C10.228.140.300.150$ OR mh:C14.907.253.092$ mh:"Urokinase-Type Plasminogen Activator" OR (Urokinase Type Plasminogen<br>Activator) OR (U-Plasminogen Activator) OR (U Plasminogen Activator) OR (U-<br>PA) OR (Urinary Plasminogen Activator) OR Urokinase OR Renokinase OR<br>Abbokinase OR (Single-Chain Urokinase-Type Plasminogen Activator) OR (Single<br>Chain Urokinase Type Plasminogen Activator) OR lumbrokinase OR duteplase OR<br>desmoteplase OR mh:D08.811.277.656.300.760.910$ OR<br>mh:D08.811.277.656.959.350.910$ OR mh:D12.776.124.125.662.884$ OR<br>mh:"Tissue Plasminogen Activator" OR (Plasminogen Activator, Tissue) OR (Tissue<br>Activator D-44) OR (Tissue Activator D 44 OR Tisokinase) OR (Tissue-Type<br>Plasminogen Activator) OR (Tissue Type Plasminogen Activator) OR TTPA OR (T-<br>Plasminogen Activator) OR (T Plasminogen Activator) OR Alteplase OR Actilyse<br>OR (Plasminogen Activator, Tissue-Type) OR (Plasminogen Activator, Tissue Type)<br>OR Activase OR Actilyse OR Lysatec rt-PA OR Lysatec rt PA OR Lysatec rtPA OR<br>mh:D08.811.277.656.300.760.875$ OR mh:D08.811.277.656.959.350.875$ OR<br>mh:D12.776.124.125.662.768$ OR mh:D23.119.970$ OR mh:"Streptokinase" OR<br>Streptase OR Streptodecase OR Kabikinase OR Awelysin OR Celiase OR<br>Distreptase OR Kabivitrum OR Avelizin OR mh:D08.811.277.656.300.775$ OR<br>mh:D12.776.124.125.662.537$ OR mh:"Tenecteplase" OR Metalyse OR TNKase<br>OR retevase OR "saruplase" OR (recombinant unglycosylated single-chain<br>urokinase-type plasminogen activator) OR pro-urokinase OR prourokinase OR<br>Rescupase mh:D08.811.277.656.300.760.875.500$ OR<br>mh:D08.811.277.656.959.350.875.500$ OR mh:D12.776.124.125.662.768.500$ Filter: Lilacs|1.280|  
|||**Número de**|
|---|---|---|
|**Bases de dados**|**Estratégia de busca**|**resultados**|
|||**encontrados**|
|Epistemonikos<br>-|(title:(“Ischemic Stroke”) OR abstract:(“Ischemic Stroke”)) AND (title:(Alteplase)|102|
|29/07/2021|OR abstract:(Alteplase))||  
Após o resultado das estratégias de busca, a etapa de seleção, incluindo resolução de duplicatas e possíveis conflitos entre os metodologistas, foi realizada por meio do _software_ Rayyan<sup>5</sup> . Essa etapa foi realizada de forma independente por dois pesquisadores. <mark>Foram considerados como critérios de elegibilidade:</mark>  
- <mark>(a) Tipos de participantes: p</mark> acientes adultos (>18 anos) diagnosticados com AVCi agudo com ou sem lesão dos grandes  
- vasos e com sintomas de AVC há menos de 4,5 horas;  
- <mark>(b) Tipo de intervenção: a</mark> lteplase;  
- <mark>(c) Tipos de estudos: revisão sistemática ou ensaio clínico randomizado;</mark>  
<mark>(d) Desfechos: s</mark> obrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais;  
- <mark>(e) Idioma: não foi utilizada restrição em relação à linguagem e data de publicação.</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Resultados da busca:** -->
Para responder à pergunta clínica, foram considerados dois ECRs<sup>6,7</sup> citados no PCDT de Trombólise no AVCi (Portaria GM/MS nº 664, de 12 de abril de 2012), sendo que não foram localizados estudos adicionais nas buscas realizadas. O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 1** .  
**Figura 1** - Fluxograma de seleção dos estudos incluídos.  
<!-- Start of picture text -->
Referéncias rastreadas por meio 5<br>da busca nas bases de dados Referéncias rastreadasfontes (n=por0)meio de outras<br>(n = 9635)<br>Referéncias duplicadas<br>(n = 740)<br>Referéncias avaliadas por meio Refer Iuidas (n=8795<br>de titulos e resumos (n = 8895) ‘eferéncias excluidas (n= 8795)<br>Textos completos avaliados Estudos excluidos, com razBes (n = 94)<br>ara ~ 94 estudos no preencheram os critérios de<br>ibilidade ( ) elegibilidade, como desenhos de estudo n5o<br>Ps elegibilidade (n= 100}<br>aplicéveis<br>Questosintomas1 - Janelade Questosintomas2 - Janelade sintomasQuestoindetermin3 - Janel ad ea ou<br><4,5h >4,5h wake up stroke<br>(n=2) (n=2) (n=2)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Análise e apresentação dos resultados:** -->
Como os estudos apresentaram critérios de inclusão diferentes (especificamente no que diz respeito a janela de sintomas em até 3 horas para o estudo NINDS<sup>7</sup> e entre 3 e 4,5 horas para o estudo de Hacke, 2008<sup>6</sup> ), não foram realizadas meta-análises. Assim, os resultados foram descritos narrativamente e as medidas de efeitos foram calculadas individualmente.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Resumo das evidências:** -->
O principal estudo que avaliou o papel dos trombolíticos no AVC foi organizado pelo grupo americano _The National Institute of Neurological Disorders and Stroke rt-PA Stroke Study Group_ (NINDS) e publicado em 1995<sup>7</sup> . Foram randomizados 624 pacientes para o tratamento com alteplase ou placebo dentro das 3 horas do início dos sintomas do AVC. No estudo NINDS (1995), foi avaliado o uso de alteplase administrada em até 3 horas em pacientes com AVCi e observada uma maior proporção de pacientes que obtiveram independência funcional (mRS 0-1) no grupo que recebeu alteplase 27,2% (85/312) quando comparado ao que recebeu placebo 17% (53/312) (RR 1,60; IC95% 1,18 a 2,18). <mark>Também foi observado em pacientes com sintomas de AVCi uma maior proporção de pacientes com eventos de hemorragia intracraniana sintomática no grupo que recebeu alteplase 6% (20/312) quando comparado a 1% (2/312), no grupo que recebeu placebo (RR 10,00; IC95% 2,36 a 42,42). Vale ressaltar que neste estudo houve maior presença de co-intervenção com ácido acetilsalicílico e de infartos lacunares no grupo tratado com trombolítico, fatores estes potencialmente contribuidores para um melhor desfecho no grupo da alteplase. Além disso, o estudo possui diversos critérios de inclusão e exclusão, o que limita a capacidade de generalização dos resultados.</mark>  
Mais recentemente, Hacke e colaboradores<sup>6</sup> avaliaram o impacto da alteplase no AVCi agudo utilizada na janela de sintomas entre 3 e 4,5 horas após o início dos sintomas em ensaio clínico randomizado duplo-cego. Para tanto, foram randomizados 418 pacientes para o grupo da alteplase e 403 para o grupo placebo. A média de tempo entre o início dos sintomas e do tratamento foi de 3h59min. Observou-se uma proporção de pacientes que obtiveram independência funcional (mRS 0-1) no grupo que recebeu alteplase (52%; 219/418) quando comparado ao grupo controle (45%; 182/403) (RR:1,16; IC95% 1,01 a 1,34). Em relação ao perfil de segurança da alteplase, observou-se uma maior proporção de pacientes com eventos de hemorragia intracraniana sintomática no grupo que recebeu alteplase (8%; 33/418) quando comparado ao grupo controle (3%; 14/403) (RR 2,27; IC95% 1,23 a 4,18). Também foi observado o aumento do risco de qualquer hemorragia no seguimento de 90 dias (RR 1,53; IC95% 1,18 a 2,0). Entretanto, não foi possível detectar diferença nos desfechos mortalidade (RR 0,91; IC95% 0,66 a 1,44) e outros EAs (RR 1,02; IC95% 0,81 a 1,30).  
Para os desfechos independência funcional, qualquer hemorragia intracraniana e mortalidade, foi julgado que há algumas preocupações quanto ao risco de viés geral para o estudo de Hacke (2008)<sup>6</sup> , devido à presença de algumas preocupações quanto ao processo de randomização. Para os desfechos independência funcional e hemorragia intracraniana sintomática, também foi julgado que há algumas preocupações quanto ao risco de viés geral no estudo de NINDS (1995)<sup>7</sup> , devido à presença de algumas preocupações quanto ao processo de randomização e quanto à seleção dos resultados relatados. A avaliação completa do risco de viés destes estudos é apresentada na **Figura 2** .  
**Figura 2** - Risco de viés dos estudos Hacke<sup>6</sup> e NINDS<sup>7</sup> avaliado por meio da ferramenta ROB 2.0 da Cochrane.  
<!-- Start of picture text -->
10 Desfecho D1 02 03 Ds D5 Geral @ sairorisco<br>Hacke 20083 Independéncia funcional 1 @ e + e @ 1) Alguma preocupagio<br>vacte2mse auaigerhenomgainncanims © @ OOO @ @ ren<br>me 900000 8 msm...<br>NINDS 19958 Independéncia funcional ! @ e@ + ! @ 03 Dadosperdido d esfechoos<br>Nnosisne Henompainvacoonsiconis @ @ OO @® @ = %~ Metessoeatare<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que a alteplase já é um medicamento disponível no SUS e apresenta evidências de efetividade e segurança quando utilizada em pacientes com janela de sintomas menor que 4,5h.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Considerações gerais e para implementação:</mark>** -->
O grupo elaborador das recomendações considerou que a utilização de alteplase é indicada em pacientes diagnosticados com AVCi em qualquer território vascular com início dos sintomas até 4,5 horas, de acordo com os critérios clínicos de elegibilidade que serão descritos a seguir:

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: <u>Inclusão:</u> -->
- Idade superior a 18 anos;  
- Avaliação de médico neurologista que confirme AVC isquêmico;  
- Quadro clínico de AVC com início há menos de 4,5 horas desde o início dos sintomas até a infusão do medicamento;  
- e  
- Tomografia computadorizada ou ressonância magnética sem sinais de hemorragia intracraniana.  
Os critérios de contraindicação foram agrupados em duas categorias, sendo critérios absolutos (os quais devem ser seguidos pelas equipes) ou relativos (em que a relação entre o risco e o benefício do tratamento deve ser avaliada individualmente pelas equipes):  
<u>Contraindicações absolutas:</u>  
● Pacientes com resolução completa espontânea imediata ou área de hipodensidade precoce à tomografia computadorizada (sugestiva de área isquêmica aguda) com acometimento maior do que um terço do território da artéria cerebral média;  
- Pacientes com malformações arteriovenosas ou tumores intracranianos;  
- Pacientes com cirurgia de grande porte nos últimos 14 dias;  
- Histórico de hemorragia intracraniana;  
- Pacientes com pressão arterial sistólica após tratamento anti-hipertensivo > 185 mmHg (não responsiva a correção  
- adequada);  
- Pacientes com pressão arterial diastólica após tratamento anti-hipertensivo > 110 mmHg (não responsiva a correção  
- adequada);  
- Pacientes com suspeita de hemorragia subaracnóide;  
- Pacientes com hemorragia gastrointestinal ou genitourinária nos últimos 21 dias;  
- Pacientes com contagem de plaquetas < 100.000/μL; RNI > 1,7; TTPA > 40s (sem necessidade de espera resultados  
- para iniciar a trombólise na maioria dos casos - aguardar sempre RNI em pacientes em uso de antagonistas da vitamina K - varfarina, femprocumona - aguardar TTPA em pacientes hospitalizados que usando heparina não fracionada endovenosa, aguardar plaquetas nos pacientes com histórico/suspeita de plaquetopenia, aguardar todos os exames de coagulação em pacientes com histórico de coagulopatia ou hemorragia);  
- Pacientes com defeito na coagulação (RNI maior que 1,7);  
● Pacientes em uso de anticoagulantes orais diretos (DOACs - inibidores diretos da trombina ou de fator Xa) nas últimas 48h, sem função renal normal. Caso apresente testes de coagulação (TTPa, RNI, contagem de plaquetas, tempo de trombina, tempo de ecarina, atividade de Xa) normais, a trombólise pode ser realizada; se não apresentar outras contraindicações. Em pacientes em uso de dabigatrana, se houver o agente reversor disponível (idarucizumab), ele pode ser utilizado e a trombólise realizada logo após.  
- Pacientes com suspeita de hemorragia subaracnóide, mesmo com tomografia normal;  
- Pacientes com dose terapêutica de heparina de baixo peso molecular nas últimas 24 horas;  
- Pacientes com endocardite bacteriana;  
- Pacientes com dissecção de arco aórtico; e  
- Pacientes com hemorragia interna ativa, evidência de sangramento ativo em sítio não passível de compressão  
mecânica.  
<u>Contraindicações relativas:</u>  
- Pacientes com sinais e sintomas leves (com comprometimento funcional discreto);  
- Pacientes com qualquer cirurgia intracraniana, trauma craniano ou histórico de AVC nos 3 meses anteriores ao  
tratamento trombolítico;  
- Pacientes com punção lombar nos últimos 7 dias (executada de forma tecnicamente correta);  
- Pacientes que tiveram infarto agudo do miocárdio nos últimos 3 meses;  
- Pacientes que realizaram punção arterial, em sítio não compressível, nos últimos 7 dias;  
- Pacientes com glicemia < 50 mg/dL (quando houver recuperação completa do déficit focal e o mesmo for atribuído à  
- hipoglicemia e não a um AVC).  
A alteplase é um medicamento já incorporado ao SUS e, portanto, não há considerações a respeito de potencial dificuldade de implementação.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
O perfil de evidências conforme o sistema GRADE referente ao uso das tecnologias foi avaliado por dois pesquisadores. Os resultados a respeito do perfil de evidências da alteplase para o tratamento de pacientes com AVCi com ou sem lesão de grandes vasos e janela de sintomas de até 4,5 horas são apresentados no **Quadro F** .  
**<mark>Quadro F</mark>** <mark>-</mark> Avaliação da certeza da evidência do uso da alteplase em pacientes com AVCi com ou sem lesão de grandes vasos, janela de sintomas há menos de 4,5 horas.  
|**Certeza**|**da evidência**||||||**№ de pacientes**<br>**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento**|**Risco**|**Inconsistênci**|**a**<br>**Evidência**|**Imprecisão**|<br>**Outras**|**Alteplase**<br>**Placebo**<br>**Relativo**|**Absoluto**||
|**estudos**<br>**Indepen**|**do estudo**<br>**dência funcional**|**de**<br>**viés**<br>**avaliada**|**pela escala de**|**indireta**<br>**Rankin 0-1 (s**|**eguimento: m**|**considerações**<br>**édia 90 dias)**|**(IC 95%)**|**(IC 95%)**||
|2<br>**Hemorr**|ECR<br>**agia intracranian**|grave<br>a<br>**a sintom**|não grave<br>**ática (seguime**|não grave<br>**nto: média 90**|não grave<br>**dias)**<br>|nenhuma|No estudo NINDS,1995, foi avaliado o uso d<br>até 3h em pacientes com AVCi e observad<br>pacientes que obtiveram independência funcio<br>recebeu alteplase (28%; 86/312) quando com<br>placebo (17%; 53/312);<br>O estudo de Hacke,2008 avaliou a alteplase<br>após o início dos sintomas do AVCi. Obs<br>pacientes que obtiveram independência funcio<br>recebeu alteplase (52%; 219/418) quando co<br>(45%; 182/403)|e alteplase administrada em<br>o uma maior proporção de<br>nal (mRS 0-1) no grupo que<br>prado aqueles que receberam<br>administrada entre 3 e 4,5h<br>ervou-se uma proporção de<br>nal (mRS 0-1) no grupo que<br>mparado ao grupo controle|<br> <br> <br> <br>⨁ ⨁ ⨁<br>◯<br>Moderada<br>|
|2|ECR|grave<br>a|não grave|não grave|grave<sup>b</sup>|nenhuma|O estudo NINDS, 1995, foi observado em paci<br>uma maior proporção de pacientes co<br>intracraniana sintomática no grupo que rece<br>quando comparado a 1% (2/312) no grupo qu|entes com sintomas de AVCi<br>m eventos de hemorragia<br>beu alteplase (6%; 20/312)<br>e recebeu placebo|⨁ ⨁ ◯<br>◯<br>Baixa|  
|**Certeza**|**da evidência**||||||**№ de pacien**|**tes**|**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**<br>**estudos**<br>**Qualque**|<br>**Delineamento**<br>**do estudo**<br>**r hemorragia (se**|**Risco**<br>**de**<br>**viés**<br>**guiment**|**Inconsistênci**<br>**o: média 90 di**|**a**<br>**Evidência**<br>**indireta**<br>**as)**|**Imprecisão**|**Outras**<br>**consideraçõ**|**es**<br>**Alteplase**<br>No estudo Ha<br>de AVCi um<br>intracraniana<br>quando comp|**Placebo**<br>cke,2008 també<br>a maior proporç<br>sintomática no<br>arado ao grupo|**Relativo**<br>**(IC 95%)**<br>m foi observado e<br>ão de pacientes co<br>grupo que receb<br>controle (3%; 14/4|**Absoluto**<br>**(IC 95%)**<br>m pacientes com sintomas<br>m eventos de hemorragia<br>eu alteplase (8%; 33/418)<br>03)|<br> <br>|
|1<br>**Mortalid**|ECR<br>**ade (seguimento**|grave<br>c<br>**: média**|não grave<br>**90 dias)**|não grave|grave<sup>b</sup>|nenhum|113/418<br>(27.0%)|71/403<br>(17.6%)|**RR 1,53**<br>(1,18<br>para<br>2,00)|**93 mais por 1000**<br>(de 32 mais para 176<br>mais)|<br>⨁ ⨁ ◯ <br>◯<br>Baixa|
|1<br>**Outros e**|ECR<br>**ventos adversos**|grave<br>c<br>**( p.e. inf**|não grave<br>**ecção, evento p**|não grave<br>**siquiátrico, ne**|muito grave<br>d<br>**urológico, ent**|nenhum<br>**re outros) (se**|32/418 (7.7%<br>**guimento: média**|)<br>34/403<br>(8.4%)<br>**90 dias)**|**RR 0,91**<br>(0,66<br>para<br>1,44)|**8 menos por 1.000**(de 36<br>menos para 37 mais)|<br>⨁ ◯ ◯ <br>◯<br>Muito<br>baixa|
|1|ECR|grave<br>c|não grave|não grave|grave<sup>b</sup>|nenhum|105/418<br>(25.1%)|99/403<br>(24.6%)|**RR 1,02**<br>(0,81<br>para<br>1,30)|**5 mais por 1.000**<br>(de 47 menos para 74<br>mais)|<br>⨁ ⨁ ◯ <br>◯<br>Baixa|  
<mark>IC: Intervalo de Confiança; RR</mark> **<mark>:</mark>** <mark>Risco Relativo; ECR: Ensaio clínico randomizado</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
<mark>a. Diminuído um nível devido a limitação metodológica (risco incerto para processo de randomização e seleção do resultado relatado)</mark>  
<mark>b. Diminuído um nível devido à presença de poucos eventos</mark>  
<mark>c. Diminuído um nível devido a limitação metodológica (risco incerto para processo de randomização)</mark>  
<mark>d. Diminuído dois níveis devido ao baixo número de eventos e IC amplo</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Tabela para tomada de decisão (</mark>** **_<mark>Evidence to Decision table</mark>_** **<mark>- EtD):</mark>** -->
A **Tabela 1** apresenta o processo de tomada de decisão sobre o uso da alteplase para o tratamento de pacientes com AVCi com janela de sintomas < 4,5 horas baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Tabela 1** - Processo de tomada de decisão referente ao uso de alteplase no tratamento de pacientes com AVCi e janela de sintomas de até 4,5 horas.  
|Item da EtD|Julgamento dos painelistas|Justificativa|
|---|---|---|
|Efeitos desejáveis:|Grande|A maioria dos painelistas julgou que os efeitos desejáveis são<br>substanciais, incluindo aumento do número de pacientes com<br>independência funcional (mRS 0-1) em 90 dias.|
|Efeitos indesejáveis|Pequeno|A maioria dos painelistas considera os efeitos indesejáveis pequenos,<br>com os riscos de hemorragia intracraniana. Julgamento baseado em<br>consenso clínico.|
|Balanço entre riscos<br>e benefícios:|Favorece a intervenção|O grupo entende que o balanço é favorável à intervenção.|
|Certeza da<br>evidência:|Moderada|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|Recursos<br>requeridos:|Negligenciáveis|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|Viabilidade de<br>implementação:|Sim|Tecnologia já disponível no SUS|
|Outras<br>considerações:|Não informado|Não foram reportadas outras considerações.|

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **QUESTÃO 2.  Deve-se administrar alteplase a pacientes com tempo de sintomas > 4,5 horas?** -->
Por não haver indicação em bula aprovada pela ANVISA para a indicação de janela de sintomas > 4,5 horas, este medicamento não é preconizado neste PCDT com este tempo de sintomas. No entanto, por se tratar de uma dúvida clínica, a síntese e a avaliação crítica das evidências desta tecnologia foram realizadas.  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : pacientes adultos (>18 anos) diagnosticados com AVCi agudo e com tempo de sintomas > 4,5 horas. **Intervenção** : alteplase.  
**Comparador** : outros trombolíticos ou placebo.  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Métodos e resultados da busca:</mark>** -->
Para a tomada de decisão, foram utilizadas as estratégias de busca apresentadas no **Quadro E** para localizar as novas evidências acerca da questão. Para responder a cada pergunta clínica foram consideradas revisões sistemáticas de adequada qualidade metodológica e recentes ou ensaios clínicos randomizados. Para a seleção dos estudos, resolução das duplicatas e possíveis conflitos foi utilizado o aplicativo Rayyan.  Essa etapa foi realizada de forma independente por dois pesquisadores. Os resultados foram extraídos em um formulário padronizado e foram analisados utilizando o software Revman 5.4.  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
- <mark>(a) Tipos de participantes: P</mark> acientes adultos (>18 anos) diagnosticados com AVCi agudo e com tempo de sintomas > 4,5  
horas.  
- <mark>(b) Tipo de intervenção: A</mark> lteplase.  
- <mark>(c) Tipos de estudos: Revisão sistemática ou ensaio clínico randomizado.</mark>  
<mark>(d) Desfechos: S</mark> obrevida; dependência física ou funcionalidade avaliado por escalas validadas como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.  
- <mark>(e) Idioma: Não foi utilizada restrição em relação à linguagem e data de publicação.</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Resultados da busca:** -->
Na tomada de decisão, foram considerados os resultados de dois estudos avaliando o uso de alteplase em pacientes com AVCi e tempo de início dos sintomas > 4,5 horas<sup>8,9</sup> .

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Análise e apresentação dos resultados:** -->
O risco de viés dos estudos incluídos foi avaliado utilizando a ferramenta ROB 2.0 da Cochrane por dois autores. Os dados dos dois estudos incluídos foram apresentados por meio de gráficos de floresta. O agrupamento dos dados foi realizado utilizando o modelo de efeitos aleatórios e as medidas sumárias dos dados dicotômicos foram apresentadas utilizando RR com IC95%.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Resumo das evidências:</mark>** -->
Não houve diferenças no desfecho mortalidade (RR 1,39; IC95% 0,72 a 2,66; **Figura 3** ), independência funcional (mRS 0-2) (RR 1,13; IC95% 0,90 a 1,42; **Figura 4** ), independência funcional (mRS 0-1) (RR 1,21; IC95% 0,89 a 1,65; **Figura 5** ); hemorragia intracraniana sintomática (RR 5,29; IC95% 0,93 a 30,14; **Figura 6** ). Em relação ao perfil de segurança da alteplase, não foi possível detectar diferença na incidência de EAs sérios entre usar alteplase quando comparado ao placebo (RR 1,09; IC95% 0,68 a 1,82). Entretanto, foi possível verificar um sucesso da realização maior em pacientes que utilizaram alteplase quando comparado ao placebo (RR 1,71; IC% 95% 1,31 a 2,23).  
**<mark>Figura 3</mark>** <mark>- Forest plot da comparação da Alteplase vs. Placebo para mortalidade em 90 dias.</mark>  
<!-- Start of picture text -->
Alteplase Placebo Risk Ratio Risk Ratio<br>Study or Subgroup Events Total Events Total Weight_M-H, Random, 95% Cl M-H, Random, 95% Cl<br>MA 2018 1311310 «112 «69.2% 1.29 (0.59, 2.82]<br>Ringleb 2019 7 60 4 56 30.8%<br>1.63(0.51, 5.28]<br>Total (95% Ci) 173 168 100.0% 1.39 (0.72, 2.66]<br>TotalHeterogeneiyest foreventsoverall effect:Taut= 2000;= 0.9820ChP=(P= 0.11, 0. 3 )¢= 141 (= 0.79, P= 0% bor Favoursoh (Alteplase] { Favours [Placebo]70 700<br><!-- End of picture text -->  
**<mark>Figura 4</mark>** <mark>- Forest plot da comparação da Alteplase vs. Placebo para o desfecho independência funcional (mRS 0-2).</mark>  
<!-- Start of picture text -->
Alteplase Placebo Risk Ratio Risk Ratio<br>Study or Subgroup _Events Total _Events Total Weight_M-H, Random, 95% Cl M.H, Random, 95% Cl<br>MA 2019 56 113 48«112:«65.6% 1.16 (0.87, 1.54]<br>Ringleb 2019 29° 6025 56 34.4% 1.08 (0.73, 1.60]<br>Total (95% Cl) 173 168 100.0% 1.13 (0.90, 1.42]<br>Total events 86 73<br>Heterogeneity: Tau?<br>Favours [placebo] Favours [Alteplasel]<br>Test for overall effect: = 0.00; Z= 1.05  Chi#= (P =  0.07, 0.30)  df= 1 (P= 0.79); P= 0% 001 at 1 10 100<br><!-- End of picture text -->  
**<mark>Figura 5</mark>** <mark>- Forest plot da comparação da Alteplase vs. Placebo para o desfecho independência funcional (mRS 0-1).</mark>  
<!-- Start of picture text -->
Alteplase Placebo Risk Ratio Risk Ratio<br>Study or Subgroup Events Total Events Total Weight M-H, Random, 95% Cl M.H, Random, 95% Cl<br>MA 2019 40 113 <33°«112:«66.8% 4.20 (0.82, 1.76)<br>Ringleb 2019 mM 60 16 56 33.2% 4.23 (0.71, 2.10)<br>Total (95% Cl) 173 168 100.0% 1.21 [0.89, 1.65]<br>Total events et 49<br>Heterogeneity Tauest  = 0.00; Ch = 0.0, df= 1 (P= 0.95); P= 0% obs oD + $ b<br>for overall effect: Z= 1.20 (P = 0.23) Favours [placebo] Favours [alteplasel]<br><!-- End of picture text -->  
**<mark>Figura 6</mark>** <mark>- Forest plot da comparação da Alteplase vs. Placebo para Hemorragia Intracraniana Sintomática até 36h.</mark>  
<!-- Start of picture text -->
Alteplase Placebo Risk Ratio Risk Ratio<br>Study or Subgroup _Events Total Events Total Weight M-H, Random, 95% Cl MH, Random, 95% CL<br>MA 2019 7 113 1 112 701% 6.94 (0.87, $5.48]<br>Ringleb 2019 1 60 0 56 299% 2.80 (0.12, 67.42)<br>Total (95% Cl) 173 168 100.0% 5.29 [0.93, 30.14]<br>Total events 8 1<br>Heterogenet, Tay = 0.00, che= 0.22. a= 1 (P= 0.64), F=0% ba ni] 1 th 100<br>est foroverall effect: Z= 1.88 (P = 0.06) Favours [Alteplase] Favours [Placebo]<br><!-- End of picture text -->  
Para os desfechos independência funcional (avaliados com a mrS 0-1 e mRS 0-2), foi julgado que há algumas preocupações quanto ao risco de viés geral para os estudos de Ma e Ringleb<sup>8,9</sup> , devido à presença de algumas preocupações quanto ao processo de randomização, desvio da intervenção pretendida e medida do desfecho. Para os desfechos mortalidade e hemorragia intracraniana sintomática, também foi julgado que há algumas preocupações quanto ao risco de viés geral nos estudos de Ma e Ringleb<sup>8,9</sup> , devido à presença de algumas preocupações quanto ao processo de randomização e desvio das intervenções pretendidas. Para o desfecho recanalização, o risco de viés foi considerado baixo. Já para o desfecho eventos adversos sérios, foi julgado que há algumas preocupações quanto ao risco de viés geral nos estudos de Ma e Ringleb<sup>8,9</sup> , devido à presença de algumas preocupações quanto ao processo de randomização e desvio das intervenções pretendidas. A avaliação completa do risco de viés destes estudos é apresentada na **Figura 7** .  
**<mark>Figura 7 -</mark>** <mark>Risco de viés dos estudos Ma</mark><sup>8</sup> <mark>e Ringleb</mark><sup>9</sup> <mark>avaliado por meio da ferramenta ROB 2.0 da Cochrane.</mark>  
<!-- Start of picture text -->
ir Desfecho DI o2 «D3. DS ODS Geral<br>Ma20194 Independencia runcionaic1 @ @ @ @ @ ® @ ex0r820<br>Ma 20198 —_ Independencia Funcional 0-2 + @ e@ & & @ (D) Alguma preocupasio<br>Ma2019C —Mortalidade<br>Ma 20190 HISintomiticaem 90 dias @ @e@e@@ee e 90e @ @ 210080<br>Ma2019€ —_—Recanalizag3o<br>Ringled 20194 Independenciaem Funcionalo-1 24hr @(> riP ese e@ + ©® Ri TPcnetanba cease<br>Ringleb 20198 Independencia Funcionalo-2 (i) r @ @ (0) 02 Desvio das intervensbes pretendidas<br>Ringleb 2019¢ Mortalidade em 90 dias 6oee@e0e0e (0) 03 Datos perdidosdo desfecho<br>Ringleb 2019CHI Sintomstica o@e@e<e0e ® DS Medidado desfecho<br>Ringleb 2019€ Eventos Adversos sérios o © se +. oe (0) DS SelecSodo resultado relatado<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
O **Quadro G** apresenta o perfil de evidências, com os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos mortalidade, independência funcional (mRS 0-1; mR 0-2), EAs sérios, hemorragia intracraniana sintomática e sucesso de recanalização.  
**Quadro G** - Avaliação da certeza da evidência do uso da alteplase em pacientes com AVCi em pacientes com tempo de sintomas maior que 4,5 horas.  
|**Certeza da evidência**||||||**№ de pacie**|**ntes**|**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**<br>**estudos**<br>**Delineamento do**<br>**estudo**|<br>**Risco de**<br>**viés**|<br>**Inconsistênci**|**a**<br>**Evidência**<br>**indireta**|**Imprecisão**|<br>**Outras**<br>**considerações**|**Alteplase**|**Placebo**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(IC 95%)**||
|**Mortalidade (seguimento: 9**|**0 dias)**||||||||||
|2<br>ECR|grave<sup>d</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|20/173<br>(11,6%)|14/168<br>(8,3%)|RR 1,39<br>(0,72 para<br>2,66)|32 mais por 1.000 (de<br>23 menos para 138<br>mais)|⨁⨁◯◯<br>Baixa|
|**Independência funcional (se**|**guimento:**|**90 dias; avalia**|**do com: mRS 0-**|**2)**|||||||
|2<br>ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|85/173<br>(49,1%)|73/168<br>(43,5%)|RR 1,13<br>(0,90 para<br>1,42)|56 mais por 1.000 (de<br>43 menos para 182<br>mais)|⨁⨁◯◯<br>Baixa|
|**Independência funcional (se**|**guimento:**|**90 dias; avalia**|**do com: mRS 0-**|**1)**|||||||
|2<br>ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|61/173<br>(35,3%)|49/168<br>(29,2%)|RR 1,21<br>(0,89 para<br>1,65)|61 mais por 1.000 (de<br>32 menos para 190<br>mais)|⨁⨁◯◯<br>Baixa|
|**Eventos adversos sérios**|||||||||||
|1<br>ECR|grave<sup>d</sup>|não grave|não grave|grave<sup>c</sup>|nenhum|21/60<br>(35,0%)|18/56<br>(32,1%)|RR 1,90<br>(0,65 para<br>1,82)|289 mais por 1.000 (de<br>113 menos para 264<br>mais)|⨁⨁◯◯<br>Baixa|  
|**Certeza d**|**a evidência**||||||**№ de pacie**|**ntes**|**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento do**|**Risco de**|**Inconsistência**|<br>**Evidência**|**Imprecisão**|<br>**Outras**|**Alteplase**|**Placebo**|**Relativo**|**Absoluto**||
|**estudos**|**estudo**|**viés**||**indireta**||**considerações**|||**(IC 95%)**|**(IC 95%)**||
|**Hemorra**|**gia Intracraniana Si**|**ntomática**|**(seguimento: 36**|**horas)**||||||||
|2<br>**Recanaliz**|ECR<br>**ação (seguimento: 2**|grave<sup>d</sup><br>**4 horas)**|não grave|não grave|muito<br>grave<sup>e</sup>|nenhum|8/173<br>(4,6%)|1/169<br>(0,6%)|RR 5,29<br>(0,93 para<br>30,14)|25 mais por 1.000 (de 0<br>menos para 172 mais)|⨁◯◯◯<br>Muito<br>baixa|
|1|ECR|não<br>grave|não grave|não grave|grave<sup>c</sup>|nenhum|72/107<br>(67,3%)|43/109<br>(39,4%)|RR 1,71<br>(1,31 para<br>2,23)|280 mais por 1.000 (de<br>122 mais para 485<br>mais)|⨁⨁⨁◯<br>Moderada|  
IC: Intervalo de Confiança; RR: Risco Relativo; ECR: Ensaio Clínico Randomizado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
<mark>a.Diminuído um nível devido a limitação metodológica (incerteza quanto ao cegamento dos avaliadores em dois estudos e um estudo com incerteza quanto ao processo de randomização e quanto a desvios da intervenção pretendida) b.Diminuído um nível devido a presença de  poucos eventos e intervalo de confiança amplo</mark>  
<mark>c.Diminuído um nível devido a presença de poucos eventos</mark>  
<mark>d.Diminuído um nível devido a limitações metodológicas (um estudo com incerteza quanto ao processo de randomização e desvios da intervenção pretendida)</mark>  
<mark>e.Diminuído dois níveis devido a presença de poucos eventos e intervalo de confiança muito amplo</mark>  
**QUESTÃO 3. Deve-se administrar alteplase a pacientes com tempo de sintomas indeterminado ou** **_wake-up stroke_ ?**  
Questão removida do painel, uma vez que o tempo indeterminado e _wake-up_ está incluído nas Questões 1 e 2, sendo considerado o último momento em que o paciente foi visto bem para determinar a terapia. Entretanto, por se tratar de uma dúvida clínica foi realizada a síntese e a avaliação crítica das evidências desta tecnologia.  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : pacientes adultos (>18 anos) diagnosticados com AVCi agudo com tempo de sintomas indeterminado ou _wakeup stroke._  
**Intervenção** : alteplase.  
**Comparador** : outros trombolíticos ou placebo.  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Métodos e resultados da busca:</mark>** -->
Foram utilizadas as mesmas estratégias de busca apresentadas no quadro 4. Para a seleção e resolução das duplicatas e possíveis conflitos foi utilizado o aplicativo Rayyan.  Essa etapa foi realizada de forma independente por dois pesquisadores. Os resultados foram extraídos em um formulário padronizado e foram analisados utilizando o software Revman 5.4.  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
<mark>(a) Tipos de participantes:</mark> pacientes adultos (>18 anos) diagnosticados com AVCi agudo com tempo de sintomas indeterminado ou _wake-up stroke_ .  
<mark>(b) Tipo de intervenção: a</mark> lteplase.  
<mark>(c) Tipos de estudos: revisão sistemática ou ensaio clínico randomizado.</mark>  
<mark>(d) Desfechos: s</mark> obrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.  
<mark>(e) Idioma: não foi utilizada restrição em relação à linguagem e data de publicação.</mark>  
**Resultados da busca:**  
Na tomada de decisão, foram considerados os resultados de dois estudos avaliando o uso de alteplase em pacientes com  
AVCi e tempo de início dos sintomas > 4,5 horas<sup>10,11</sup> . O processo de seleção já foi detalhado na **Figura 1** .

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Análise e apresentação dos resultados:** -->
Devido aos estudos apresentarem desfechos clínicos diferentes, não foi possível realizar meta-análises. Assim, os resultados foram descritos narrativamente e as medidas de efeitos foram calculadas individualmente.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Resumo das evidências:</mark>** -->
Para responder a esta pergunta, foram utilizados <mark>dois ECRs</mark><sup>10,11</sup> <mark>. D</mark> evido aos estudos não apresentarem desfechos clínicos semelhantes, não foi possível realizar meta-análises.  
<mark>Um ECR</mark><sup>10</sup> <mark>objetivando avaliar a alteplase versus placebo na independência funcional apresentou uma maior proporção de pacientes no grupo alteplase (131/246; 53%) com independência funcional (c</mark> onforme avaliado pela Escala modificada de Rankin 0-1) <mark>quando comparado com os pacientes que utilizaram placebo (102/244; 48%) em um tempo de seguimento de 90 dias (RR 1,27; IC95% 1,05 a 1,54). O mesmo efeito positivo foi verificado quando a qualidade de vida foi avaliada pela escala EQ-5D</mark>  
<mark>(quanto maior o score, melhor). Observou-se uma ligeira melhora na qualidade de vida em 90 dias dos pacientes que receberam alteplase quando comparado ao grupo placebo (Diferença de média (DM) 0,5 pontos; IC95% 0,90 a 0,10). Em relação ao perfil de segurança, não foi possível detectar diferença para os desfechos mortalidade (RR 3,24; IC95%0,90 a 11,63), h</mark> emorragia intracraniana sintomática (RR 1,62; IC95% 0,81 a 3,24); hemorragia parenquimatosa tipo 2 (RR 1,62; IC95% 0,81 a 3,24). Um outro estudo (Michel,2012<sup>11</sup> ) também avaliando alteplase versus placebo em pacientes com tempo de sintomas indeterminado ou _wake-up_ e evidenciou que mais pacientes no grupo alteplase obteve escala funcional de Rankin 0-2 (4/6;66,7%) quando comparado ao placebo (1/ 6; 16,7%). Foi observado também, que o número de pacientes que alcançaram o sucesso de recanalização foi maior no grupo que recebeu alteplase (3/4;75%) quando comparado ao grupo placebo (1/5; 20%), entretanto não foi observada diferença estatisticamente significante para ambos os desfechos clínicos com considerável imprecisão em relação a magnitude do efeito.  
A análise do risco de viés desses estudos está descrita na figura 9. Para os desfechos independência funcional (avaliados com a mrS 0-1 e mRS 0-2), o risco de viés geral variou entre baixo risco e algumas preocupações para os estudos de Michel<sup>11</sup> e Thomalla<sup>10</sup> , devido a presença de algumas preocupações quanto à medida do desfecho. Para os desfechos mortalidade, hemorragia intracraniana sintomática, hemorragia parenquimatosa tipo 2 e recanalização, o risco de viés foi considerado baixo. Para qualidade de vida, foi julgado que há algumas preocupações quanto ao risco de viés geral nos estudos de Thomalla<sup>10</sup> , devido a presença de algumas preocupações quanto à medida do desfecho. A avaliação completa do risco de viés destes estudos é apresentada na **Figura 8** .  
**Figura 8** –  Risco de viés do estudo Thomalla<sup>10</sup> e Michel<sup>11</sup> avaliado por meio da ferramenta ROB 2.0 da Cochrane.  
<!-- Start of picture text -->
Tema" 08avnsenenc fon e e e at e ©ral @ ssx0r1c0<br>TomallaTomalla 20188 Qualidadede vida por EQ-SD @@e@e0@ ® D) riguma preocupasso<br>TomallaTomalla 2018 0C MorteHISintomsticaem 90 dias eeec<ae50aeeeeee @@ @ 2:08:%0<br>Michel 2018 HemorradiaParenquimatosatico? @ @ @ OO @ Ba Proceseo derendonsteeto<br>lucaMichel 2011 8A IndependencMortal i ema funcionaldade90 dias  0-2 @e e eeee@ e e e@@ D 23 _ D esvioados perdidos das intervenges pretendidasdo destecho<br>Miche! 2 maSc0110 HIpacenatnapo Sintomética e nsuem 28he ©@e@@ee@ee@ee@ OO OO Oe@ &05  tetiatiosSelado r es unedo reletedote c o Bo<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
O **Quadro H** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos mortalidade, independência funcional (mRS 0-1; mR 0-2); hemorragia intracraniana sintomática, hemorragia parenquimatosa tipo 2, sucesso recanalização e qualidade de vida.  
**Quadro H** - Avaliação da certeza da evidência do uso da alteplase em pacientes com AVCi em pacientes com tempo de sintomas indeterminado ou _wake-up stroke._  
|**Certeza d**|**a evidência**||||||**№ de pacien**|**tes**|**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento**|**do**<br>**Risco**|**Inconsistênci**|**a**<br>**Evidência**|**Imprecisã**|**o**<br>**Outras**|**Alteplase**|**Placebo**|**Relativo**|**Absoluto**||
|**estudos**<br>**Mortalid**<br>|**estudo**<br>**ade (seguimento**<br>|**de viés**<br>**: 90 dias)**||**indireta**||**considerações**<br>|||**(IC 95%)**<br>|**(IC 95%)**<br>||
|1<br>**Independ**<br>|ECR<br>**ência Funciona**<br>|não<br>grave<br>**l (seguimento:**<br>|não grave<br>**90 dias; avalia**<br>|não grave<br>**do com: mRS 0**<br>|muito<br>grave<sup>a</sup><br>**-2)**<br>|nenhum<br>|10/251<br>(4,0%)<br>|3/244<br>(1,2%)<br>|RR 3,24<br>(0,90 para<br>11,63)<br>|28 mais por 1.000 (de 1<br>menos para 131 mais)<br>|⨁ ⨁ ◯<br>◯<br>Baixa<br>|
|1<br>**Independ**|ECR<br>**ência funcional**|não<br>grave<br>**(seguimento:**|não grave<br>**90 dias; avalia**|não grave<br>**do com: mRS 0**|muito<br>grave<sup>a</sup><br>**-1)**<br>|nenhum|4/6 (66,7%)|1/6<br>(16,7%)|RR 4,00<br>(0,61 para<br>26,12)|500 mais por 1.000 (de<br>65 menos para 1.000<br>mais)|⨁ ⨁ ◯<br>◯<br>Baixa<br>|
|1|ECR|não|não grave|não grave|grave<sup>b</sup>|nenhum|131/246|102/244|RR 1,27|113 mais por 1.000 (de|⨁ ⨁ ◯|
|||grave|||||(53,3%)|(4,8%)|(1,05 para|21 mais para 226 mais)|◯|
|**Hemorra**|**gia intracranian**|**a sintomática**|**(avaliado com**|**: Critério NIN**|**DS)**||||1,54)||Moderada|
|1|ECR|não<br>grave|não grave|não grave|muito<br>grave<sup>a</sup>|nenhum|20/251<br>(8,0%)|12/244<br>(4,9%)|RR 1,62<br>(0,81 para<br>3,24)|30 mais por 1.000 (de 9<br>menos para 110 mais)|⨁ ⨁ ◯<br>◯<br>Baixa|  
|**Certeza d**|**a evidência**||||||**№ de pacien**|**tes**|**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento**|**do**<br>**Risco**|**Inconsistência**|**Evidência**|**Imprecisã**|**o**<br>**Outras**|**Alteplase**|**Placebo**|**Relativo**|**Absoluto**||
|**estudos**<br>**Hemorra**|**estudo**<br>**gia parenquima**|**de viés**<br>**tosa tipo 2 (se**|**guimento: 36h)**|**indireta**||**considerações**|||**(IC 95%)**|**(IC 95%)**||
|1<br>**Recanali**|ECR<br>**zação (seguimen**|não<br>grave<br>**to: 24 horas)**|não grave|não grave|muito<br>grave<sup>a</sup>|nenhum|10/251<br>(4,0%)|1/244<br>(2,3%)|RR 9,72<br>(1,25 para<br>75,37)|198 mais por 1.000 (de<br>6 mais para 1.000 mais)|⨁ ⨁ ◯<br>◯<br>Baixa|
|1|ECR|não<br>grave|não grave|não grave|muito<br>grave<sup>a</sup>|não grave|3/4  (75%)|1/5(20%)|RR 3,75<br>(0,59 para<br>23,66)|550 mais por 1.000 ( de<br>82 menos para 1.000<br>mais)|⨁ ⨁ ◯<br>◯<br>Baixa|
|**Qualidad**<br>1|**e de vida (segui**<br>ECR|**mento: 90 dias**<br>não<br>grave|**; avaliado com:**<br>não grave|**EQ-5D) - 0-1**<br>não grave|**0, quanto me**<br>grave<sup>c</sup>|**nor, melhor.**<br>nenhum|246|244|-|DM 0,5 menor<br>(0,9 menor para 0,1<br>menor)|⨁ ⨁ ⨁ ◯<br>Moderada|  
<mark>IC: Intervalo de Confiança; RR: Risco relativo; ECR: Ensaio Clínico Randomizado; DM: Diferença de média</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
<mark>a. Diminuído dois níveis devido a pouquíssimos eventos e amplo IC</mark>  
<mark>b. Diminuído um nível devido a presença de poucos eventos</mark>  
c. Diminuído um nível devido a presença de poucos eventos ou o tamanho amostral pequeno

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **QUESTÃO 4. Deve-se usar tenecteplase como alternativa para a trombólise?** -->
Por não apresentar indicação aprovada pela ANVISA em bula para o tratamento de AVCi, este Protocolo não recomenda  
o uso de tenecteplase. Entretanto, por se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências desta tecnologia.  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : pacientes adultos (>18 anos) diagnosticados com AVCi agudo.  
**Intervenção** : tenecteplase.  
**Comparador** : alteplase ou outros trombolíticos ou placebo.  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Métodos e resultados da busca:</mark>** -->
Para responder a esta pergunta, foi realizada busca sistematizada da literatura nas bases de dados Pubmed, Lilacs, Embase, Cochrane, e Epistemonikos até o dia 29 de julho de 2021. As estratégias estão descritas no **Quadro I** . Para a seleção e resolução das duplicatas e possíveis conflitos foi utilizado o aplicativo Rayyan. Essa etapa foi realizada de forma independente por dois pesquisadores. Os resultados foram extraídos em um formulário padronizado e foram analisados utilizando o software Revman 5.4.  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
- <mark>(a) Tipos de participantes: p</mark> acientes adultos (>18 anos) diagnosticados com AVCi agudo.  
- <mark>(b) Tipo de intervenção: t</mark> enecteplase.  
- <mark>(c) Tipos de estudos: revisão sistemática ou ensaio clínico randomizado.</mark>  
<mark>(d) Desfechos: s</mark> obrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.  
- <mark>(e) Idioma: não foi utilizada restrição em relação à linguagem e data de publicação.</mark>  
**Quadro I** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso da tenecteplase.  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via|#1 "Ischemic Stroke"[Mesh] OR Ischemic Stroke* OR Cryptogenic Ischemic|162|
|Pubmed<br>-|Stroke* OR Cryptogenic Stroke* OR Cryptogenic Embolism Stroke* OR Acute||
|29/07/21|Ischemic Stroke*||
||#2 "Tenecteplase"[Mesh] OR Metalyse OR TNKase||
||#3 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as||
||topic[MeSH Terms] OR clinical trial[Publication Type] OR||  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||random*[Title/Abstract] OR random allocation[MeSH Terms] OR therapeutic<br>use[MeSH Subheading])<br>#4 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR meta-<br>analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw] OR met<br>analy*[tw] OR integrative research[tiab] OR integrative review*[tiab] OR<br>integrative overview*[tiab] OR research integration*[tiab] OR research<br>overview*[tiab] OR collaborative review*[tiab] OR collaborative overview*[tiab]<br>OR systematic review*[tiab] OR technology assessment*[tiab] OR technology<br>overview*[tiab] OR "Technology Assessment, Biomedical"[mh] OR HTA[tiab]<br>OR HTAs[tiab] OR comparative efficacy[tiab] OR comparative effectiveness[tiab]<br>OR outcomes research[tiab] OR indirect comparison*[tiab] OR ((indirect<br>treatment[tiab] OR mixed-treatment[tiab]) AND comparison*[tiab]) OR<br>Embase*[tiab] OR Cinahl*[tiab] OR systematic overview*[tiab] OR<br>methodological overview*[tiab] OR methodologic overview*[tiab] OR<br>methodological review*[tiab] OR methodologic review*[tiab] OR quantitative<br>review*[tiab] OR quantitative overview*[tiab] OR quantitative synthes*[tiab] OR<br>pooled analy*[tiab] OR Cochrane[tiab] OR Medline[tiab] OR Pubmed[tiab] OR<br>Medlars[tiab] OR handsearch*[tiab] OR hand search*[tiab] OR meta-<br>regression*[tiab] OR metaregression*[tiab] OR data synthes*[tiab] OR data<br>extraction[tiab] OR data abstraction*[tiab] OR mantel haenszel[tiab] OR peto[tiab]<br>OR der-simonian[tiab] OR dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane<br>Database Syst Rev"[Journal:__jrid21711] OR "health technology assessment<br>winchester, england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal]<br>OR "Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#5 #3 OR #4<br>#6 (animals NOT humans)<br>#7 - #1AND #2 AND #5 AND #6 NOT #7||
|EMBASE<br>-<br>29/07/21|#1 'brain ischemia'/exp OR 'brain ischemia' OR 'acute ischaemic stroke' OR 'acute<br>ischemic stroke' OR 'brain arterial insufficiency' OR 'brain circulation disorder' OR<br>'brain ischaemia' OR 'cerebral blood circulation disorder' OR 'cerebral blood flow<br>disorder' OR 'cerebral circulation disorder' OR 'cerebral circulatory disorder' OR<br>'cerebral ischaemia' OR 'cerebral ischemia' OR 'cerebrovascular circulation<br>disorder' OR 'cerebrovascular ischaemia' OR 'cerebrovascular ischemia' OR<br>'chronic ischaemic stroke' OR 'chronic ischemic stroke' OR 'ischaemia cerebri' OR|122|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||'ischaemic brain disease' OR 'ischaemic encephalopathy' OR 'ischaemic stroke' OR<br>'ischemia cerebri' OR 'ischemic brain disease' OR 'ischemic encephalopathy' OR<br>'ischemic stroke' OR 'neural ischaemia' OR 'neural ischemia'<br>#2 'tenecteplase'/exp OR tenecteplase OR metalyse OR 'TNK tPA' OR TNKase<br>#3 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR  'single-blind procedure':de OR (random* OR  factorial*<br>OR crossover* OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1 blind*<br>OR singl* NEAR/1 blind* OR assign* OR allocat* OR volunteer*):de,ab,ti<br>#4 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3 analy*):ab,ti<br>OR metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes* NEAR/3<br>(literature* OR research* OR studies OR data)):ab,ti OR (pooled AND<br>analys*:ab,ti) OR ((data NEAR/2 pool*):ab,ti AND studies:ab,ti) OR medline:ab,ti<br>OR medlars:ab,ti OR embase:ab,ti OR cinahl:ab,ti OR scisearch:ab,ti OR<br>psychinfo:ab,ti OR psycinfo:ab,ti OR psychlit:ab,ti OR psyclit:ab,ti OR cinhal:ab,ti<br>OR cancerlit:ab,ti OR cochrane:ab,ti OR bids:ab,ti OR pubmed:ab,ti OR ovid:ab,ti<br>OR ((hand OR manual OR database* OR computer*) NEAR/2 search*):ab,ti OR<br>(electronic NEAR/2 (database* OR 'data base' OR 'data bases')):ab,ti OR<br>bibliograph*:ab OR 'relevant journals':ab OR ((review* OR overview*) NEAR/10<br>(systematic* OR methodologic* OR quantitativ* OR research* OR literature* OR<br>studies OR trial* OR effective*)):ab NOT (((retrospective* OR record* OR case*<br>OR patient*) NEAR/2 review*):ab,ti OR ((patient* OR review*) NEAR/2<br>chart*):ab,ti OR rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR<br>hamster:ab,ti OR hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR<br>dogs:ab,ti OR cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT<br>('editorial'/exp OR 'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR<br>'nonhuman'/exp NOT ('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #3 OR #4<br>#6 #1 AND #2 AND #5<br>#7 #6AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane Library<br>- 29/07/21|#1 MeSH descriptor: [Ischemic Stroke] explode all trees<br>#2 Ischemic Stroke* OR Cryptogenic Ischemic Stroke* OR Cryptogenic Stroke*<br>OR Cryptogenic Embolism Stroke* OR Acute Ischemic Stroke*<br>#3 MeSH descriptor: [Tenecteplase] explode all trees<br>#4 Metalyse OR TNKase<br>#5 #1 OR #2<br>#6 #3 OR #4|56|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#7 #5 AND #6||
|Lilacs via Portal<br>BVS - 29/07/21|mh:"Brain Ischemia" OR (Brain Ischemias) OR (Cerebral Ischemia) OR (Cerebral<br>Ischemias) OR (Encephalopathy, Ischemic) OR (Ischemia, Brain) OR (Ischemia,<br>Cerebral) OR (Ischemias, Cerebral) OR (Ischemic Encephalopathies) OR<br>(Ischemic Encephalopathy) OR(Ischemic Stroke*) OR (Cryptogenic Ischemic<br>Stroke*) OR (Cryptogenic Stroke*) OR (Cryptogenic Embolism Stroke*) OR<br>(Acute Ischemic Stroke*) OR mh:C10.228.140.300.150$ OR<br>mh:C14.907.253.092$ AND<br>mh:"Tenecteplase" OR  Metalyse OR TNKase OR<br>mh:D08.811.277.656.300.760.875.500$ OR<br>mh:D08.811.277.656.959.350.875.500$ OR mh:D12.776.124.125.662.768.500$ Filter: Lilacs|1|
|Epistemonikos -<br>29/07/21|(title:(“Ischemic Stroke”) OR abstract:(“Ischemic Stroke”)) AND<br>(title:(tenecteplase) OR abstract:(tenecteplase))|15|

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Resultados da busca:** -->
Para responder a esta pergunta, foram incluídos seis ensaios clínicos randomizados, dos quais dois foram encontrados por meio de buscas manuais por meio de listas de referências dos artigos incluídos. O processo de seleção é detalhado na **Figura 9** .  
**Figura 9** - Fluxograma de seleção dos estudos incluídos.  
<!-- Start of picture text -->
Referéncias rastreadas por meio 3<br>da busca nas bases de dados Referéncias rastreadas por meio de outras<br>(n = 356) fontes (n °= 2)<br>Referéncias duplicadas<br>(n = 129)<br>deReferénciastitulos e avaliadasresumos  por(n = 229) meio Referéncias " exclufdas"  (n=221)=<br>Textos completosavaliados<br>para elegibilidade (n= 8) Estudos excluidos, com razdes<br>(n=2)<br>- Estudos ndo preencheram os critérios de<br>elegibilidade (PICO) (n= 2)<br>Ensaios clinicos randomizados<br>incluidos para sintese<br>quantitativa<br>(n=6)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Análise e apresentação dos resultados:** -->
Dentre os estudos incluídos, quatro avaliaram pacientes com lesão de grandes vasos<sup>12–15</sup> e dois avaliaram pacientes com ou sem lesão de grandes vasos<sup>16,17</sup> . Os dados de todos os estudos foram agrupados em meta-análise, apresentando subgrupos considerando o tipo de lesão, no intuito de verificar se o tipo de lesão impacta nas estimativas finais de efeito.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Resumo das evidências:</mark>** -->
Seis ensaios clínicos randomizados avaliaram a tenecteplase quando comparado a alteplase para independência funcional (mRS 0-1). Observou-se uma proporção maior de pacientes no grupo tenecteplase (45,2%) com independência funcional mRS 0-1 quando comparado a alteplase (34,2%); (RR 1,30; IC95% 1,04 a 1,62; **Figura 10** ). Em relação ao perfil de segurança da tecnologia, não foi possível detectar diferença entre usar tenecteplase ou alteplase para os desfechos mortalidade (RR 0,97; IC95% 0,57 a 1,64; **Figura 11** ), hemorragia intracraniana sintomática (RR 0,79; IC 95% 0,34 a 1,84; **Figura 12** ) e qualquer hemorragia (RR: 0,62; IC95%: 0,32 a 1,20; **Figura 13** ).  
**<mark>Figura 10</mark>** <mark>- Forest plot da comparação da tenecteplase vs. alteplase para independência funcional mRS 0-1).</mark>  
<!-- Start of picture text -->
Study or Subgroup EventsTNK Total EventsAlteplaseTotal Weight M-H, RiskRandom,Ratio95% Cl MH, Random,Risk Ratio95% Cl<br>2.1.1 Com lesao de grandes vasos<br>ATTEST + Australian TNK 28 «60 14 63 17.9% 1.77 (1.05, 2.98] —_—_—_————<br>EXTEND-IA TNK 62 101 43° 101 56.5% 1.21 (0.90, 1.62]<br>Subtotal (95% Cl) 161 154 74.3% 1.37 (0.96, 1.95]<br>Total events 80 57<br>TestHeterogeneity:for averall Tau®=effect: Z=0.03;1.76Chi*= (P=1.58, 0.08)df=1 (P= 0.21); P= 35%<br>2.1.2 Com ou sem lesao de grandes vasos<br>Haley 2010 1631 13° 31 16.2% 1.15 (0.66, 2.00]<br>Huang 2015 13 47 10 49 9.5% 1.36 (0.66, 2.79]<br>Subtotal (95% C1) 78 80 25.7% 1.22 [0.79, 1.90]<br>Total events 28 23<br>TestHeterogeneity:for averall Tau*effect:= Z=0.00;0.91Chi?=(P=0.12,0.36) df=1 (P= 0.72); F= 0%<br>Total (95% Cl) 239 234 100.0% 1.30 [1.04, 1.62] =><br>Total events 108 80<br>TestTestHeterogeneity:forfor averallsubaroupTau*effect:differences:= 0.00;Z= 2.31 Chi*=(PChi?==1.76,0.02)0.16, df=df= 3 (P1 =(P 0.62);= 0.69), F= F= 0% 0% Favorece0s  Alteplase07 Favorece15  TNK<br><!-- End of picture text -->  
**<mark>Figura 11</mark>** <mark>- Forest plot da comparação da tenecteplase vs. alteplase para mortalidade</mark> .  
<!-- Start of picture text -->
Study or Subgroup _EventsINK Total EventsAlteplaseTotal Weight M-H, RiskRandom, Ratio95% Cl M-H, Random,Risk Ratio95% Cl<br>3.1.1 Com lesao de grandes vasos<br>Australian TNK 4 60 3 25 11.4% 0.67 (0.16, 2.75]<br>EXTEND-IA TNK 10 101 18 101 29.4% 0.56 (0.27, 1.14]<br>NOR-TEST 8 52 4 66 16.1% 2.54 (0.81, 7.97]<br>Subtotal (95% Cl) 203 192 56.9% 0.94 [0.36, 2.48]<br>Total events 22 25<br>TestHeterogeneity:for overall Tau?effect:= Z=0.44;0.12 Chi*=(P= 0.90)4.96, df= 2 (P= 0.08); F= 60%<br>3.1.2 Com ou sem lesao de grandes vasos<br>Haley 2010 7 OH 8 31 231% 0.88 (0.36, 2.12]<br>Huang 2015 8 47 6 49 201% 1.39 [0.52, 3.70]<br>Subtotal (95% Cl) 78 80 43.1% 1.08 [0.56, 2.08]<br>Total events 16 14<br>Heterogeneity: Tau?<br>Test for overall effect:= Z=0.00;0.22 Chi?=(P= 0.47, 0.82) df= 1 (P= 0.49), F= 0%<br>Total (95% Cl) 281 272 100.0% 0.97 (0.57, 1.64]<br>Total events 3 39<br>Heterogeneity: Taut= 0.11; Chit= 6.79, df= 4 (P = 0.22), F= 31% obs on | t 4<br>TestTest forfor overallsubaroupeffect:differences:Z= 0.13 (PChi?== 0.90)0.05, df= 1 (P = 0.82), F= 0% Favorece Alteplase Favorece TNK<br><!-- End of picture text -->  
**<mark>Figura 12</mark>** <mark>- Forest plot da comparação da tenecteplase vs. alteplase para hemorragia intracraniana sintomática.</mark>  
<!-- Start of picture text -->
Study or Subgroup EventsINK Total EventsAlteplaseTotal Weight M-H, RiskRandom, Ratio95% Cl M.H, Random,Risk Ratio95% Cl<br>4.1.1 Com lesao de grandes vasos<br>Australian TNK 2 60 3 25 241% 0.33 (0.06, 1.87]<br>EXTEND-IA TNK 1 4101 1 101 94% 1,00 (0.06, 15.77]<br>NOR-TEST 2 62 2 66 19.3% 4.27 (0.18, 8.71]<br>Subtotal (95% Cl) 203 192 52.8% 0.66 (0.21, 2.12]<br>Total events 6 6<br>TestHeterogeneity:for overall Tau?effect:= 0.00;Z= 0.70 Ch#=(P =1.13,0.49) df= 2 (P= 0.57); F= 0%<br>4.1.2 Com ou sem lesdo de grandes vasos<br>Haley 2010 24 1 31 13.0% 2.00 (0.19, 20.93]<br>Huang 2015 3 62 4 61 34.2% 0.74 (0.17, 3.12]<br>Subtotal (95% Cl) 83 82 47.2% 0.97 (0.28, 3.32]<br>Total events 5 5<br>Heterogeneity: Tau?= 0.00; Chi¥= 0.51, df= 1 (P= 0.48), P= 0%<br>Test for overall effect Z= 0.05 (P= 0.96)<br>Total (95% Cl) 286 274 100.0% 0.79 [0.34, 1.84]<br>Total events 10 4<br>Heterogeneity: Tau?<br>Test = 0.00; Ch=1.84, df= 4 (P= 0.77),F= 0% tor of + 1b ado<br>Test for  over a ll effect: Z= 0.54 (P = 0.59) Favorece Alteplase Favorece TNK<br>sub roup differences: Chi?= 0.20, df= 1 (P= 0.66), F= 0%<br><!-- End of picture text -->  
**<mark>Figura 13</mark>** <mark>- Forest plot da comparação da tenecteplase vs. alteplase para qualquer hemorragia.</mark>  
<!-- Start of picture text -->
Study Tenecteplase Alteplase Risk Ratio Risk Ratio<br>HuangHaley 2010or2015 Subgroup Events84 Total623 _Events145 Total53 1 Weight2971 .0% IV, Random, 0. 8056 ( 0.24,0.26, 95%2.70)1.22] Cl IV, Random, 95% Cl<br>Total (95% Cl) 83 82 100.0% 0.62 [0.32, 1.20]<br>Total events 12 19<br>TestHeterogeneity:for overall effect:Tau*= Z=0.00; 1.42Chi*= (P = 0.15)0,23, df= 1 (P= 0.63); P= 0% oot Favorecs Tenecteplase Favorece Ateptase won<br><!-- End of picture text -->  
Para os desfechos independência funcional (avaliados com a mrS 0-1), mortalidade, hemorragia sintomática, o risco de viés geral variou entre algumas preocupações e alto risco, devido a presença de algumas preocupações quanto ao processo de randomização e desvio da intervenção pretendida. Para os desfechos qualquer hemorragia e recanalização, o risco de viés geral foi julgado como algumas preocupações, devido a presença de algumas preocupações quanto ao processo de randomização e desvio da intervenção pretendida. A avaliação completa do risco de viés destes estudos é apresentada na **Figura 14** .  
**Figura 14** - Risco de viés dos estudos Haley<sup>16,</sup> Australian TNK<sup>13</sup> , EXTEND -IA TNK<sup>14</sup> , ATTEST + Australian TNK<sup>12</sup> , NOR-TEST<sup>15</sup> , Huang<sup>17</sup> avaliado por  
meio da ferramenta ROB 2.0 da Cochrane.  
<!-- Start of picture text -->
roy Desfecho D1 D2 D3 DA DS Geral<br>Haley 20103 Independéncia funcional »@e0e0e0<br>Haley 20100 Hemorragiaintracranianasintométics «=< ® @ @ @ @ @<br>saiey2010¢ uslqverhemorasi )@0000 @ sino sco<br>Haley 20104 Mortalidade »@e0e0e0 DA -upagdes<br>Huang2015a Independénciafuncionsl @e0@000 mimeserees<br>Huang 20356 Hemorrayiaintracranianasintomstics = @ @ @ @ @ @ @ Beorisc0<br>Huang2015¢ Qualquer hemorragia @020@000<br>Huang 2018d Mortalidade @eeee0<br>Huang 201Se Recanalizac3o @e@ee0e0 D1 ProcessoderandomizagSo<br>EXTENDAEXTENDA TNKaTNKb IndependéncisMortalidade  funcional »>®e0e0e0»>®e0e0e0 02 Desviedes intervenespretendidss<br>EXTEND-IATNKe Hemorragia intracraniana sintomatica »>®e@ee0 D3 Dados perdidosdo desfecho<br>Australian TNKa Mortalidade e@e@ee0e 8 Dé Medidado desfecho<br>Australian TNKb Hemorragia intracranianasintomatics «6 @ ® @ @ @ DS Selegdodo. resultadorelatado<br>ATTEST<br>+ Australian NK Independéncia funcional »>e@0e0e@ .<br>NOR-TESTa Mortalidade @»7eeee<br>NORTESTS Hemorragiaintracranianasintomética YO @@OO®@®<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
O **Quadro J** apresenta o perfil de evidências, com os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos independência funcional, mortalidade, hemorragia intracraniana sintomática.  
**Quadro J** - Avaliação da certeza da evidência do uso de tenecteplase versus alteplase em pacientes com AVCi.  
|**Avaliação**|**da certeza**||||||**№ de pacientes**||**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento**|**do**<br>**Risco de**|<br>**Inconsistência**|**Evidência**|**Imprecisão**|<br>**Outras**|**Tenecteplase**|**Alteplase**|**Relativo**|**Absoluto**||
|**estudos**|**estudo**|**viés**||**indireta**||**considerações**|||**(95% CI)**|**(95% CI)**||
|**Independê**|**ncia Funcional (se**|**guimento: 9**|**0 dias; avaliado c**|**om: mRS 0-1)**||||||||
|4|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|108/239<br>(45,2%)|80/234<br>(34,2%)|RR 1,30<br>(1,04 para<br>1,62)|<br>10 mais por 100<br>(de 1 mais para<br>21 mais)|⨁⨁◯◯<br>Baixa|
|**Mortalida**|**de (seguimento: 9**|**0 dias)**||||||||||
|5|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|37/281<br>(13,2%)|39/272<br>(14,3%)|RR 0,97<br>(0,57 para<br>1,64)|<br>0 a cada 100<br>(de<br>6<br>menos<br>para 9 mais)|⨁⨁◯◯<br>Baixa|
|**Hemorrag**|**ia Intracraniana S**|**intomática (**|**seguimento: 90 d**|**ias)**||||||||
|5|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|10/286 (3,5%)|11/274<br>(4,0%)|RR 0,79<br>(0,34 para<br>1,84)|<br>1 menos por 100<br>(de<br>3<br>menos<br>para 3 mais)|⨁⨁◯◯<br>Baixa|  
IC: Intervalo de Confiança; RR: Risk ratio; ECR: Ensaio Clínico Randomizado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
a. Diminuído um nível devido a limitação metodológica - dois estudos com risco incerto para sigilo de alocação e cegamento de participantes; 1 estudo apresentou desbalanço entre os grupos quanto às características basais e 1 estudo apresentou risco incerto para desvio das intervenções pretendidas.  
b. Diminuído um nível devido a poucos eventos.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **QUESTÃO 5. Deve-se realizar trombectomia mecânica em pacientes com lesões dos grandes vasos e com janela de sintomas menor do que 8h?** -->
**<u>Recomendação 2:</u>** Recomendamos utilizar trombectomia mecânica em pacientes com oclusão envolvendo a artéria carótida interna intracraniana, o primeiro segmento da artéria cerebral média (M1) ou ambos com início de sintomas até 8 horas (qualidade de evidência moderada, recomendação forte).  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : adultos (>18 anos) diagnosticados com AVCi agudo com lesões dos grandes vasos e com janela de sintomas menor do que 8h.  
**Intervenção** : trombectomia mecânica associada ao melhor tratamento clínico otimizado.  
**Comparador** : melhor tratamento clínico otimizado.  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Métodos e resultados da busca:</mark>** -->
Para responder essa pergunta, foram utilizadas as referências e síntese de evidências apresentadas no Relatório de Recomendação n° 589 da Conitec. Adicionalmente, foi realizada no dia 29 de julho de 2021, uma atualização da busca descrita no relatório, contemplando as bases Central, Pubmed, Embase Lilacs e Epistemonikos. Foram consideradas revisões sistemáticas de adequada qualidade metodológica e recentes e, na ausência destas, ensaios clínicos randomizados.  Foi utilizada uma única estratégia de busca para as questões sobre trombectomia mecânica (Questões 5, 6 e 7). As estratégias estão descritas no **Quadro K** .  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
- <mark>(a) Tipos de participantes: p</mark> acientes adultos (>18 anos) diagnosticados com AVCi agudo com tempo de sintomas < 8h.  
- <mark>(b) Tipo de intervenção: t</mark> rombectomia mecânica.  
- <mark>(c) Tipos de estudos: revisão sistemática ou ensaio clínico randomizado.</mark>  
<mark>(d) Desfechos: s</mark> obrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.  
- <mark>(e) Idioma: não foi utilizada restrição em relação à linguagem e data de publicação.</mark>  
**Quadro K** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso da trombectomia.  
|**Bases de dados**|**Estratégia de busca**|**Número de**|
|---|---|---|
|||**resultados**<br>**encontrados**|
|MEDLINE<br>via|#1 (endovascular[All Fields] AND ("thrombectomy"[Mesh Terms] OR|81|
|Pubmed|"thrombectomy"[All Fields]) AND acute[All Fields] AND ("ischemia"[Mesh||
|29/07/21|||  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||Terms] OR "ischemia"[All Fields] OR "ischemic"[All Fields]) AND<br>("stroke"[Mesh Terms] OR "stroke"[All Fields])) AND Meta-Analysis[ptyp]||
|EMBASE<br>29/07/21|#1 'brain ischemia'/exp OR 'brain ischemia' OR 'acute ischaemic stroke' OR 'acute<br>ischemic stroke' OR 'brain arterial insufficiency' OR 'brain circulation disorder'<br>OR 'brain ischaemia' OR 'cerebral blood circulation disorder' OR 'cerebral blood<br>flow disorder' OR 'cerebral circulation disorder' OR 'cerebral circulatory disorder'<br>OR 'cerebral ischaemia' OR 'cerebral ischemia' OR 'cerebrovascular circulation<br>disorder' OR 'cerebrovascular ischaemia' OR 'cerebrovascular ischemia' OR<br>'chronic ischaemic stroke' OR 'chronic ischemic stroke' OR 'ischaemia cerebri'<br>OR 'ischaemic brain disease' OR 'ischaemic encephalopathy' OR 'ischaemic<br>stroke' OR 'ischemia cerebri' OR 'ischemic brain disease' OR 'ischemic<br>encephalopathy' OR 'ischemic stroke' OR 'neural ischaemia' OR 'neural ischemia'<br>#2 'mechanical thrombectomy'/exp OR 'mechanical thrombectomy' OR<br>'mechanical<br>embolectomy'<br>OR<br>'mechanical<br>thrombolysis'<br>OR<br>'pharmacomechanical thrombectomy'<br>#3 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3<br>analy*):ab,ti OR metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes*<br>NEAR/3 (literature* OR research* OR studies OR data)):ab,ti OR (pooled AND<br>analys*:ab,ti) OR ((data NEAR/2 pool*):ab,ti AND studies:ab,ti) OR<br>medline:ab,ti OR medlars:ab,ti OR embase:ab,ti OR cinahl:ab,ti OR<br>scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti OR psychlit:ab,ti OR<br>psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti OR bids:ab,ti<br>OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data<br>base' OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR<br>((review* OR overview*) NEAR/10 (systematic* OR methodologic* OR<br>quantitativ* OR research* OR literature* OR studies OR trial* OR<br>effective*)):ab NOT (((retrospective* OR record* OR case* OR patient*)<br>NEAR/2 review*):ab,ti OR ((patient* OR review*) NEAR/2 chart*):ab,ti OR<br>rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR hamster:ab,ti OR<br>hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR dogs:ab,ti OR<br>cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT ('editorial'/exp OR<br>'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp NOT<br>('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#5 #1 AND #2 AND #3<br>#7#5  AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)|259|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Cochrane Library|endovascular thrombectomy|140|
|29/07/21|||
|Lilacs via Portal|endovascular thrombectomy AND metanalysis|0|
|BVS|Filter: Lilacs||
|29/07/21|||
|Epistemonikos|(title:(“Ischemic Stroke”) OR abstract:(“Ischemic Stroke”)) AND|380|
|29/07/21|(title:(Thrombectomy) OR abstract:(Thrombectomy))||

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<u>Resultados da busca:</u>** -->
Para responder essa pergunta, foram utilizadas as referências e síntese de evidências apresentadas no Relatório de Recomendação n° 589 da CONITEC<sup>18</sup> . Neste relatório, foram incluídos 9 artigos<sup>19–27</sup> . Adicionalmente foi realizada uma atualização da busca descrita no relatório, contemplando as bases Central, Pubmed, Embase, Lilacs e Epistemonikos. Os resultados da busca totalizaram 790 referências. Não foram localizados estudos adicionais. Todo o processo de seleção dos estudos é apresentado na **Figura 15** .  
**Figura 15** - Fluxograma de seleção dos estudos incluídos.  
<!-- Start of picture text -->
Referéncias rastreadas por meio 3<br>da Referéncias rastreadas por meio de outras<br>(n =busca860) nas bases de dados fontes (n= 0)<br>Referéncias duplicadas<br>(n = 265)<br>Referéncias avaliadas por meio Referéncias excluidas(n=592)<br>de titulos e resumos (n = 595) " " -<br>Textos completosavaliados<br>para elegibilidade(n= 3) Estudos excluidos, com razdes<br>(n=1)<br>- Analise descritivade protocolode estudo<br>(sem dados extraiveis) (n= 1)<br>Questo5 -<8h(n=1) Janela de sintomas Questo5 6 - Janelade sintomas., Questo7 - Janela de sintomas<br>Relatériode Recomendacdo n. 8 he22)c oth (n=indeterminada2) (mesmos estudosou wake upda stroke janela<br>589 de 8a 24h)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Análise e apresentação dos resultados:** -->
O risco de viés dos estudos incluídos foi avaliado utilizando a ferramenta ROB 1.0 da Cochrane. Os dados dos estudos incluídos foram apresentados por meio de gráficos de floresta. O agrupamento dos dados foi realizado utilizando o modelo de efeitos aleatórios e as medidas sumárias dos dados dicotômicos foram apresentadas utilizando OR com IC95%.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Resumo das evidências:</mark>** -->
Para responder a esta pergunta, foram utilizadas as referências e síntese de evidências apresentadas no Relatório de Recomendação n° 589 da Conitec<sup>18</sup> . Neste Relatório, foram consideradas para as sínteses da evidência, três revisões sistemáticas com meta-análises e o estudo brasileiro RESILIENT<sup>27</sup> . Deste modo, foram encontradas evidências mostrando uma diferença significativa na independência funcional (conforme avaliado pela escala modificada de Rankin 0-2) entre pacientes com AVCi que receberam trombectomia mecânica em 90 dias (OR 2,06; IC95% 1,71 a 2,49; 9 estudos; 2072 participantes; **Figura 16** ) quando comparado aos que receberam o melhor tratamento clínico. Não foi possível detectar diferença entre os grupos quanto ao risco de morte em 90 dias (OR: 0,85; IC95% 0,69 a 1,05; **Figura 17** ). Também não foi possível detectar diferenças entre os grupos quanto ao risco de hemorragia intracraniana sintomática (OR: 1,20; IC95% 0,78 a 1,84; **Figura 18** ).  
**<mark>Figura 16</mark>** <mark>- Forest plot da comparação da trombectomia vs. melhor tratamento clínico para independência funcional (mRS 0-2). F</mark> onte: Relatório de Recomendação N°589 da CONITEC de novembro de 2020.  
<!-- Start of picture text -->
Berkhemeror 2015 (MR CLEAN) TrombectomiaEvents76 Total_Events«6233—2Cts«SSTSs28T_—Conduta clinicaTotal 20.5% MH,‘Odds2.05 Ratio(1.36,95%3.09} C1 mu Odds Ratio—95%C1<br>Bracard 2016 (THRACE) 106 200 85 202 22.3% 1.55 [1.05, 2.30)<br>Campbell 2015 (EXTEND IA) 25 36 “4 35 35% 3.75 (1.38, 10.17] e—<br>JovinGoyalEstudo20152015RESILIENT(REVASCAT)(ESCAPE) ce]a745° 1 wt03291036443472 110 18.7%:10.3%9.3% 2.172.73/1.71,(1.18, 4.37]3.98) eo_<br>Mocco 1.98[1.11, 3.53] na<br>Muir 20172016(PISTE) (THERAPY) 719 50«33138“4 4632 3.48% 1 .40 .55 (0.60(0.58 ,  34 . 14)27)<br>‘Saver 2015 (SWIFT PRIME) 59 98 3 93 10.0% 2.75 (1.53, 4.94) —_—<br>Total (95% Ch 1027 1035 100.0% 2.06 [1.71,2.49} ¢<br>Total events 473 304<br>Heterogeneity. Tau" = 0.00; Chi*= 6.85, af= 8 P = 0.55); P= 0% bor OF 70 700<br>Test for overall effect: Z = 7.64 (P « 0.00001) Atavor do controle A favor da trombectomia<br><!-- End of picture text -->  
**<mark>Figura 17</mark>** <mark>- Forest plot da comparação da trombectomia vs. melhor tratamento clínico para mortalidade em 90 dias. F</mark> onte:  
Relatório de Recomendação N°589 da CONITEC de novembro de 2020.  
<!-- Start of picture text -->
or Trombectomia Conduta clinica Risk Ratio Risk Ratio<br>BracardBerkherner 20162015THRACE) (MR CLEAN) Events24-202,423349287Total EventsF208Total 25.1146 % = 0.911,03 0 54,152).71,95% C11.49) 95601<br>‘Campbell 2015 (EXTEND lA) 3 co] 7 3% 2T% 0.43 0.12, 1.52)<br>Estudo RESIUENT ria mm 3 110 193% 0.81 (0.52, 1.25)<br>Goyal 2015 (ESCAPE) 17) 164 28147 126% = 0.54 10.31, 0.95)<br>Jowin 2015 (REVASCAT) 19° 103 = 16 = 103 109% = 1,19 70.65, 219),<br>Mocco 2016 (THERAPY) 6 80 11 4B «$.1% = 0.60 J0.20, 1.25}<br>SaverMuir 20172015(PISTE)(SWIFT PRIME) 97 398 «12,4-33OF 34%63% ~—— 0.741,800.58, 40:33, 1.65 5 8)<br>Total (95% Ch 1028 1044 100.0% 0.85 0.69, 1.05}<br>Total events 156 187<br>Heterogeneity: Tau*= 0.01; Chit = 8.97, of 8 (P = 0.34); "= 11% Tr 01 1 10 100<br>Te hr overs MRE Z= 140 P= 01D Atavordo controle A favor da tombectomia<br><!-- End of picture text -->  
**<mark>Figura 18</mark>** <mark>- Forest plot da comparação da trombectomia vs. melhor tratamento clínico para hemorragia intracraniana sintomática. F</mark> onte: Relatório de Recomendação N°589 da CONITEC de novembro de 2020.  
<!-- Start of picture text -->
BerkhemerBracardor 20162015 (THRACE) (MR CLEAN) TrombectomiaEvents184 Total_Events233185 Conduta173 clinicTot267192 a l 39.181 % mit‘Odds 1. 2339(0 (0Ratio . 62,31,6.31]95% 2.45}Cl MAH,OddsRandom,Ratio95% Ch<br>JovinCampbellEstudoGoyal  RESILIENT2015 (ESCAPE)2015 (EXTEND1A) 086 ot1653 624 11015038 155%11.2%20% 0.19 (001,1.351.38 (0.45, (0.38, 4.99} 4.08]4.02}<br>MoccoMuit 201720152016 (PISTE) (REVASCAT) (THERAPY) 740 10383 o46 103622 11.6%-105% 0.961.80Not (0.51,(0.25, 3.62) estimable6.36)<br>Saver 2015 (SWIFT PRIME) 0 98 3 8F 21% 0.14 (0.01, 2.69)<br>Total (95% Cl) 1006 1048 100.0% 1.20 (0.78, 1.84)<br>Total events 47 45<br>Heterogenetty. Tau" = 0.00; Chit = 4.13, df= 7 (P= 0.77), P= 0% bor mn 1 to 700<br>Testtor overall eteet Z= 0.82 0P = 0.41) Atavor da trombectomia A tavor do controle<br><!-- End of picture text -->  
Foram utilizadas as análises do risco de viés dos estudos incluídos no Relatório de Recomendação nº 589. O risco de viés nos estudos incluídos foi considerado não grave para os estudos que avaliaram o desfecho hemorragia intracraniana sintomática. Para todos os demais desfechos, existiu uma grave limitação metodológica, devido ao risco de viés alto nos estudos incluídos.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Justificativa para a recomendação:</mark>** -->
A trombectomia mecânica para janela de sintomas de até 8 horas foi recentemente incorporada no SUS e apresenta evidências científicas importantes de sua efetividade e segurança.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Considerações gerais para implementação:</mark>** -->
Sua utilização é indicada em pacientes adultos diagnosticados com AVCi, com início dos sintomas de até 8h (definido  
como o momento em que o paciente foi visto pela última vez em um estado normal de saúde), seguindo os demais critérios de elegibilidade que serão descritos a seguir.  
Critérios de inclusão:  
- Adultos com 18 anos de idade ou mais;  
- Casos com uma oclusão envolvendo a artéria carótida interna intracraniana, o primeiro segmento da artéria cerebral  
- média (M1) ou ambos que puderam ser tratados dentro de 8 horas após o início dos sintomas;  
- Casos com uma pontuação de pré-ataque de 0 ou 2 na escala modificada de Rankin (variação de 0 [sem sintomas] a 6  
- [morte]); e  
- Casos com uma pontuação de 6 ou mais no _National Institutes of Health Stroke Scale_ (NIHSS; intervalo de 0 a 42,  
- com valores mais altos indicando déficit mais grave) na apresentação.  
Critérios de exclusão baseados nos exames de imagem:  
- Evidência de hemorragia intracraniana recente; e  
● Presença de um grande infarto, conforme definido por um escore de tomografia computadorizada precoce do _Alberta Stroke Program_ (ASPECTS) inferior a 6 (faixa de 0 a 10, com valores mais altos indicando menor carga de infarto) na TC ou inferior a 5 na difusão- imagem de ressonância magnética ponderada (MRI).  
O painel de especialistas considerou importante ressaltar os seguintes aspectos para a implementação da trombectomia mecânica:  
● A criação de Centro de Atendimento de Urgência aos Pacientes com AVC Tipo IV, que compreenderia os centros habilitados para realização da trombectomia, tendo nestes locais estrutura física, recursos humanos e materiais específicos do procedimento; e  
- Atualização do documento do Ministério da Saúde que descreve a linha de cuidados em AVC na rede de atenção às  
- urgências e emergências.  
A trombectomia mecânica é uma tecnologia já incorporada no SUS e, portanto, não há considerações a respeito de  
potencial dificuldade de implementação.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Perfil de evidências:</mark>** -->
O **Quadro L** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos  
mortalidade, independência funcional (mRS 0-1) e hemorragia intracraniana sintomática.  
**Quadro L** - Avaliação da certeza da evidência do uso de trombectomia mecânica em pacientes com lesões de grandes vasos e com janela de sintomas menor do que 8 horas.  
|**Avaliaçã**|**o da certeza**||||||**№ de pacientes**||**Efeito**|||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento**|**Risco**|**Inconsistênci**|**a**<br>**Evidência**|**Imprecisão**|<br>**Outras**|**Trombectomia**|**Conduta**|**Relati**|**vo (IC**|**Absoluto**||
|**estudos**|**do estudo**|**de viés**||**indireta**||**considerações**||**clínica**|**95%)**||**(IC 95%)**||
|**Independ**|**ência Funcional (**|**seguimento**|**: 90 dias; aval**|**iado com: mRS**|**0-1)**||||||||
|6|ECR|grave<sup>a</sup>|não grave|não grave|não grave|Nenhum|240/833<br>(28,8%)|141/847<br>(16,6%)|OR<br>(1,58<br>2,64)|2,05<br>para|124 mais por 1.000<br>(de 73 mais para<br>179 mais)|⨁⨁⨁◯<br>Moderada|
|**Escala de**|**Rankin modifica**|**da (0 - 2) e**|**m 90 dias (segu**|**imento: média**|**90 dias)**||||||||
|2062<br>(9<br>ECRs)<br>**Mortalid**|<br>grave<sup>a</sup><br>**ade (seguimento:**|não<br>grave<br>**90 dias)**|não grave|não grave|não grave|nenhum|473/1027<br>(46.1%)|304/1035<br>(29.4%)|OR<br>(1.71<br>2.49)|2.06<br>para|168 mais por 1.000<br>(de 122 mais para<br>215 mais)|⨁⨁⨁◯<br>Moderada|
|9<br>**Hemorra**|ECR<br>**gia intracraniana**|não<br>grave<br>**sintomátic**|não grave<br>**a (seguimento:**|não grave<br>**90 dias)**|grave<sup>b</sup>|Nenhum|187/1028<br>(18,2%)|156/1044<br>(14,9%)|OR<br>(0,69<br>1,05)|0,85<br>para|20 menos por 1.000<br>(de 41 menos para 6<br>mais)|⨁⨁⨁◯<br>Moderada|
|9|ECR|não<br>grave|não grave|não grave|grave<sup>b</sup>|nenhum|47/1006 (4,7%)|45/1048<br>(4,3%)|OR<br>(0,78<br>1,84)|1,20<br>para|8 mais por 1.000 (de<br>9 menos para 33<br>mais)|⨁⨁⨁◯<br>Moderada|  
IC: Intervalo de Confiança; OR: Odds ratio; ECR: Ensaio Clínico Randomizado  
**Legenda:** a. Diminuído um nível devido a limitações metodológicas - estudos com alto risco viés.  b. Diminuído em 1 nível por poucos eventos e IC amplo.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
A **Tabela 2** apresenta o processo de tomada de decisão sobre o uso da trombectomia mecânica para o tratamento de pacientes com AVCi com janela de sintomas de até 8h, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Tabela 2** - Processo de tomada de decisão referente ao uso da trombectomia mecânica no tratamento de pacientes com AVCi e janela de sintomas de até 8 horas.  
|Item da EtD|Julgamento dos<br>painelistas|Justificativa|
|---|---|---|
|Efeitos desejáveis|Grande|A maioria dos painelistas julgou que os efeitos desejáveis são<br>substanciais, incluindo aumento do número de pacientes com<br>independência funcional (mRS 0-1 e mRS 0-2) em 90 dias|
|Efeitos indesejáveis|Trivial|A maioria dos painelistas considera os efeitos indesejáveis<br>triviais, sem diferença entre grupos para os efeitos indesejáveis.<br>Julgamento baseado em consenso clínico|
|Balanço entre riscos e<br>benefícios|Favorece a intervenção|O grupo entende que o balanço é favorável à intervenção|
|Certeza da evidência|Moderada|Nenhuma justificativa foi apontada. Julgamento baseado em<br>consenso clínico|
|Custo-efetividade|A favor da intervenção|Uma análise de custo-efetividade foi apresentada no Relatório nº<br>589, indicando que a trombectomia mecânica é custo-efetiva|
|Viabilidade de<br>implementação|Sim|Tecnologia já disponível no SUS|
|Outras considerações|Não informado|Não foram reportadas outras considerações|  
**QUESTÃO 6. Deve-se realizar trombectomia mecânica em pacientes com lesões dos grandes vasos e com janela de sintomas maior do que 8h e menor que 24h?**  
**<u>Recomendação 3:</u>** Recomendamos a trombectomia mecânica em pacientes com janela de sintomas entre 8 e 24 horas (qualidade de evidência moderada, recomendação forte).  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : adultos diagnosticados com AVCi agudo com lesões dos grandes vasos e com janela de sintomas maior do que 8h e menor do que 24h.  
**Intervenção** : trombectomia mecânica associada ao melhor tratamento clínico otimizado.  
**Comparador** : melhor tratamento clínico otimizado.  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários  
validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Métodos e resultados da busca:</mark>** -->
Para responder essa pergunta, foram utilizadas as referências dos dois ensaios clínicos randomizados e síntese de evidências apresentadas no Relatório de Recomendação nº 677/2021, relativo à proposta de incorporação da trombectomia mecânica para AVCi com janela de sintomas maior do que 8h e menor que 24h. Foi realizada busca sistematizada da literatura nas bases de dados Pubmed, Lilacs, Embase, Cochrane, e Epistemonikos até o dia 29 de julho de 2021. Foi utilizada uma única estratégia de busca para as questões sobre trombectomia mecânica (Questões 5, 6 e 7). As estratégias estão descritas no **Quadro K** .  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
- <mark>(a) Tipos de participantes: p</mark> acientes adultos (>18 anos) diagnosticados com AVCi agudo com tempo de sintomas maior  
- que 8 e menor que 24h.  
- <mark>(b) Tipo de intervenção: trombectomia mecânica.</mark>  
- <mark>(c) Tipos de estudos: revisão sistemática ou ensaio clínico randomizado.</mark>  
<mark>(d) Desfechos: s</mark> obrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.  
- <mark>(e) Idioma: não foi utilizada restrição em relação à linguagem e data de publicação.</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Resultados da busca:** -->
Na tomada de decisão, foram considerados os resultados de dois estudos avaliando o uso de trombectomia mecânica em pacientes com AVCi e tempo de início dos sintomas 6 e 16 horas e entre 6 e 24h<sup>28,29</sup> . Todo o processo de seleção é detalhado na **Figura 15** . A recomendação da Conitec foi favorável à ampliação da trombectomia com janela estendida de 8 até 24 hrs para pacientes com AVCi agudo.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Análise e apresentação dos resultados:** -->
O risco de viés dos estudos incluídos foi avaliado utilizando a ferramenta ROB 2.0 da Cochrane por dois autores. Os dados dos dois estudos incluídos foram apresentados por meio de gráficos de floresta. O agrupamento dos dados foi realizado utilizando o modelo de efeitos aleatórios e as medidas sumárias dos dados dicotômicos foram apresentadas utilizando RR com IC95%.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<mark>Resumo das Evidências:</mark>** -->
Para responder essa pergunta, foram incluídos dois ECR<sup>28,29</sup> que avaliaram a efetividade e segurança da trombectomia em pacientes com AVCi e janela de sintomas. Observou-se uma maior incidência de pacientes com escala de Rankin modificada mRS 0-2 quando comparado a melhor conduta clínica (RR 3,00; IC95%2,06 a 4,37, **Figura 19** ). Também se observou uma menor incidência de pacientes com deterioração neurológica no grupo que realizou trombectomia mecânica versus placebo (RR 0,58; IC95% 0,36 a 0,94; **Figura 20** ). Entretanto, não foi possível detectar diferença entre os grupos para os desfechos: mortalidade (RR 0,76; IC95% 0,41 a 1,4; **Figura 21** ); hemorragia intracraniana sintomática (RR 1,63; IC95% 0,65 a 4,06; **Figura 22** ); EAs agrupados (RR 0,89; IC95% 0,74 a 1,07); hemorragia parenquimatosa tipo 2 (RR 2,61; IC95% 0,71 a 9,52) e para o sucesso da recanalização RR: 1,95; IC95% 1,49 a 2,54).  
**<mark>Figura 19</mark>** <mark>- Forest plot da comparação da trombectomia mecânica vs. melhor tratamento clínico em pacientes com janela de sintomas entre 6h e 24h para o desfecho independência funcional (mRS 0-2) em 90 dias.</mark>  
<!-- Start of picture text -->
Study or Subgroup __Trombectomia Events Total EventsControleTotal Weight IV, Random,Risk Ratio 95% Cl IV, Random,Risk Ratio 95% Cl<br>Albers 2018 a 92 15 90 53.1% 2.67 (1.60, 4.48) —i—<br>Nogueira 2018 48 107 13° 99 46.9% 3.42 (1.97, 5.91] —_—_<br>Total (95% Cl) 199 189 100.0% 3.00 [2.06, 4.37] <=—_>-<br>Total events 89 28<br>Heterogeneity: Tau?<br>= 0.00; Ch¥= 0.41, df= 1 (P= 0.52); P= 0% to na | $ $<br>Test foroverall effect: Z= 5.73 (P < 0.00001) Favorece Controle Favorece Trombectomia<br><!-- End of picture text -->  
**<mark>Figura 20</mark>** <mark>- Forest plot da comparação da trombectomia mecânica vs. melhor tratamento clínico em pacientes com janela de sintomas entre 6h e 24h para o desfecho da deterioração neurológica.</mark>  
<!-- Start of picture text -->
Study or Subgroup TrombectomiaEvents __Total_EvenCon t roles Total Weight_M-H,RiskRandom, Ratio95% Cl MH, Random,Risk Ratio95% Cl<br>Albers 2018 8 92 11 90 30.6% 0.74 (0.30, 1.69]<br>Nogueira 2018 15 107 «©2686 «99 69.4% 0.53 (0.30, 0.95] oH<br>Total (95% Cl) 199 189 100.0% 0.58 (0.36, 0.94] ><br>Total events 23 37<br>Heterogenciy Tayr= 0.0; Chis 0.20, df=1 (P= 0.59); F=0% bar th : mH 70d<br>est for overall effect: Z= 2.21 (P = 0.03) Favorece Trombectomia Favorece controle<br><!-- End of picture text -->  
**<mark>Figura 21</mark>** <mark>- Forest plot da comparação da trombectomia mecânica vs. melhor tratamento clínico em pacientes com janela de sintomas entre 6h e 24h para o desfecho mortalidade.</mark>  
<!-- Start of picture text -->
Trombectomia —_Controle Risk Ratio Risk Ratio<br>Study or Subgroup Events Total Events Total Weight M-H, Random, 95% Cl MH, Random, 95% Cl<br>Albers 2018 13 92 23° 90 48.4% 0.55 (0.30, 1.02]<br>Nogueira 2018 20 107 18 99 51.6% 1.03 (0.58, 1.83]<br>Total (95% Cl) 199 189 100.0% 0.76 (0.41, 1.40]<br>Total events 33 41<br>TestHeterogeneity: Tau?= 0.10; Chi#= 2.09, df=1 (P= 0.15); F= 52% 2 15 7 $ 5<br>for overall effect Z= 0.88 (P= 0.36) Favorece Trombectomia Favorece Controle<br><!-- End of picture text -->  
**<mark>Figura 22</mark>** <mark>- Forest plot da comparação da trombectomia mecânica vs. melhor tratamento clínico em pacientes com janela de sintomas entre 6h e 24h para o</mark>  
<mark>desfecho da hemorragia intracraniana sintomática.</mark>  
<!-- Start of picture text -->
Study or Subgroup TrombectomiaEvents Total —_Events ControleTotal Weight M-H, RiskRandom, Ratio95% Cl MH, Random,Risk Ratio95% CI<br>Albers 2018 6 92 4 90 54.9% 1.47 (0.43, 6.03]<br>Nogueira 2018 6 107 3 99 45.1% 1.85 (0.48, 7.20]<br>Total (95% Cl) 199 189 100.0% 1.63 (0.65, 4.06]<br>Total events 12 7<br>= 0.00; Ch2= =1 (P= P=<br>HeterogenetyTau'= 000 Chi'= 008, df=1 (P= 0.90), F=0% ba th } b 70d<br>stor overall effect Z= 1.05 (P= 0.28) Favorece Trombectomia Favorece Controle<br><!-- End of picture text -->  
A análise do risco de viés desses estudos está descrita na **Figura 23** . Para todos os desfechos analisados foi julgado que o risco de viés foi baixo.  
**Figura 23** - Risco de viés do estudo de Albers<sup>28</sup> e Nogueira<sup>29</sup> avaliado por meio da ferramenta ROB 2.0 da Cochrane.  
<!-- Start of picture text -->
iD Desfecho Dl D2 D3 D4 DS Geral<br>Weems 208 cspaiade 9060s @eee0e ©<br>santhepsi 2 ene ©0000@ @--...<br>Mopars 2018 Independencia con ©@OCCC®@ 5...<br>Hogue 20184 Sucemoda recanatzaco @e@eeee @ @ Pouce<br>Noprira 20 the181  vemcagaeterivinagoeversonnewoldgicaatombice @eee@e@ e eee8@ @<br>serie emda rae<br>Aven 2030 Adena dedanniiodorredtaininconss @ @OSS O<br>‘Avers 20185 Memowragia intracranione sintomitica S @ @ @ SO @ & rvosiaravesdodestecho<br>pce noo AM pace ce ape cggerncedotece @ @ OO @ @ iw iesissoseitecre<br>Avers 20181 ——_DeteriorizarSo newrotigica precoce @@eeese @ os: Sousasdsicusistlsis<br>‘Aeers2018¢ —_Eventon adverson sévion @@eeese @<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Justificativa para a recomendação:** -->
A trombectomia mecânica é uma tecnologia incorporada no SUS e apresenta evidências científicas de efetividade e  
segurança quando utilizada em pacientes adultos com AVCi agudo e janela de sintomas maior do que 8h e menor que 24h.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Considerações gerais para implementação:** -->
A utilização da trombectomia mecânica é indicada em pacientes adultos diagnosticados com AVCi, com início dos  
sintomas maior do que 8h e menor que 24h, de acordo com os critérios de elegibilidade descritos a seguir.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: <u>Critérios de inclusão:</u> -->
- Idade entre 18 e 90 anos;  
- Sinais e sintomas consistentes com o diagnóstico de um AVC isquêmico de circulação anterior agudo;  
- NIHSS ≥ 6;  
- Escala de Rankin modificada menor ou igual a 2 antes do curso de qualificação (funcionalmente independente para  
todas as AVDs);  
- Volume da área isquêmica (<50 mL);  
- Área pequena de infarto e uma área grande de penumbra;  
- Volume do infarto (avaliado por perfusão ou difusão), sendo considerados os seguintes pontos de corte para pacientes  
de acordo com idade e NIHSS:  
- Idade (anos) ≥ 80 e NIHSS >10: volume do infarto <21 cm³;  
- Idade (anos) < 80 e NIHSS 10-19: volume do infarto < 31 cm³;  
- Idade (anos) < 80 e NIHSS >20: volume do infarto < 51 cm³;  
- Critérios entre 8-16h:  
- Volume do infarto < 70mL;  
- Mismatch > 1.8;  
- Penumbra > 15mL.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: <u>Critérios de exclusão:</u> -->
- Alergia conhecida ao iodo que impede um procedimento endovascular;  
- Diátese hemorrágica hereditária ou adquirida conhecida, deficiência do fator de coagulação; Terapia anticoagulante  
oral recente com RNI > 3 (o uso recente de um dos novos anticoagulantes orais não é uma exclusão se a TFG estimada> 30 ml/min);  
- Convulsões no início do AVC, se isso impedir a obtenção do NIHSS;  
- Contagem basal de plaquetas <50.000/μL;  
- Hipertensão grave sustentada (pressão arterial sistólica> 185 mmHg ou pressão arterial diastólica> 110 mmHg);  
- Embolia séptica presumida;  
- Suspeita de endocardite bacteriana;  
- Histórico de hemorragia nos últimos 30 dias.  
O painel de especialistas considerou importante ressaltar os seguintes aspectos para a implementação da trombectomia mecânica:  
● A criação de Centro de Atendimento de Urgência aos Pacientes com AVC Tipo IV, que compreenderia os Centros habilitados para realização da trombectomia, tendo nestes locais estrutura física, recursos humanos e materiais específicos do procedimento;  
● Atualização do documento do Ministério da Saúde que descreve a linha de cuidados em AVC na rede de atenção às urgências e emergências.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Perfil de evidências:** -->
Os resultados a respeito do perfil de evidências da trombectomia mecânica para o tratamento de pacientes com AVCi com  
janela de sintomas entre 8 e 24 horas estão apresentados no **Quadro M** .  
**Quadro M** - Avaliação da qualidade da evidência (GRADE) dos desfechos analisados.  
|**Certeza**|**da Evidência**||||||**№ de pacientes**||**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**do**<br>**estudos**|**s**<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistênci**|**a**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Trombectomia**<br>**mecânica**|**Conduta**<br>**clínica**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**||
|**Independ**|**ência funcional (a**|**valiado co**|**m: Escala de R**|**ankin modifica**|**da - mRS 0-2)**|**em um seguimen**|**to de 90 dias**|||||
|2|ECR|não<br>grave|não grave|não grave|grave a|nenhum|89/199 (44,7%)|28/189<br>(14,8%)|RR 3,00<br>(2,06 para<br>4,37)|<br>30 mais por 100 (de<br>16 mais para 50<br>mais)|<br> <br>⨁⨁⨁◯<br>Moderada|
|**Mortalid**|**ade**|||||||||||
|2<br>**Hemorra**|ECR<br>**gia intracraniana**|não<br>grave<br>**sintomátic**|não grave<br>**a em um segui**|não grave<br>**mento de 90 dia**|grave<sup>a</sup><br>**s**|nenhum|33/199 (16,6%)|41/189<br>(21,7%)|RR 0,76<br>(0,41 para<br>1,40)|<br>5 menos por 100<br>(de 13 menos para<br>9 mais)|<br> <br>⨁⨁⨁◯<br>Moderada|
|2<br>**Eventos**<br>1|ECR<br>**adversos sérios - a**<br>ECR|não<br>grave<br>**grupado (a**<br>não<br>grave|não grave<br>**valiado com: T**<br>não grave|não grave<br>**odos os evento**<br>não grave|muito grave<br>b<br>**s adversos séri**<br>grave<sup>a</sup>|<br>nenhum<br>**os) em um seguim**<br>nenhum|12/199 (6,0%)<br>**ento de 90 dias**<br>62/92 (67,4%)|7/189<br>(3,7%)<br>68/90<br>(75,6%)|RR 1,63<br>(0,65 para<br>4,06)<br>RR 0,89<br>(0,74 para<br>1,07)|<br>2 mais por 100<br>(de 1 menos para<br>11 mais)<br> <br>8 menos por 100<br>(de 20 menos para<br>5 mais)|<br>⨁⨁◯◯<br>Baixa<br> <br>⨁⨁⨁◯<br>Moderada|  
|**Certeza d**|**a Evidência**||||||**№ de pacientes**||**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**|<br>**Delineamento**|**Risco**|**Inconsistência**|<br>**Evidência**|**Imprecisão**|**Outras**|**Trombectomia**|**Conduta**|**Relativo**|**Absoluto**||
|**estudos**|**do estudo**|**de viés**||**indireta**||**considerações**|**mecânica**|**clínica**|**(95% CI)**|**(95% CI)**||
|**Eventos a**<br>2<br>**Eventos a**|**dversos sérios - av**<br>ECR<br>**dversos sérios - av**|**aliado indi**<br>não<br>grave<br>**aliado indi**|**vidualmente: D**<br>não grave<br>**vidualmente: H**|**eterioração ne**<br>não grave<br>**emorragia pa**|**urológica em**<br>grave<sup>a</sup><br>**renquimatosa**|**um seguimento d**<br>nenhum<br>**tipo 2 em um seg**|**e 90 dias**<br>23/199 (11,6%)<br>**uimento de 90 dias**|37/189<br>(19,6%)|RR 0,58<br>(0,36 para<br>0,94)|<br>8 menos por 100<br>(de 13 menos para<br>1 menos)|<br>⨁⨁⨁◯<br>Moderada|
|1|ECR|não<br>grave|não grave|não grave|muito grave<br>b|nenhum|8/92 (8,7%)|3/90 (3,3%)|<br>RR 2,61<br>(0,71 para<br>9,52)|<br>5 mais por 100<br>(de 1 menos para<br>28 mais)|<br>⨁⨁◯◯<br>Baixa|
|**Sucesso d**|**a recanalização em**|**24 horas**||||||||||
|1|ECR|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|82/107 (76,6%)|39/99<br>(39,4%)|RR 1,95<br>(1,49 para<br>2,54)|<br>37 mais por 100<br>(de 19 mais para 61<br>mais)|<br>⨁⨁⨁◯<br>Moderada|  
IC: Intervalo de Confiança/ RR: Risco Relativo/ ECR: Ensaio Clínico Randomizado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Perfil de evidências:** -->
a. Diminuído um nível devido poucos eventos.  
b. Diminuído dois níveis devido a pouquíssimos eventos e IC amplo

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
A Tabela 3 apresenta o processo de tomada de decisão sobre o uso da trombectomia no tratamento de pacientes com AVCi e janela de sintomas entre 8 e 24h baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Tabela 3** - Processo de tomada de decisão referente ao uso da trombectomia mecânica no tratamento de pacientes com AVCi e janela de sintomas entre 8 e 24 horas.  
|Item da EtD|Julgamento dos<br>painelistas|Justificativa|
|---|---|---|
|Efeitos desejáveis:|Grande|A maioria dos painelistas julgou que os efeitos desejáveis são substanciais,<br>incluindo aumento do número de pacientes com independência funcional<br>(mRS 0-2), recanalização e redução de deterioração neurológica em 90 dias.|
|Efeitos indesejáveis|Pequeno|A maioria dos painelistas considera os efeitos indesejáveis pequenos, sem<br>diferença entre grupos para os efeitos indesejáveis. Julgamento baseado em<br>consenso clínico.|
|Balanço entre riscos e<br>benefícios:|Favorece a<br>intervenção|O grupo entende que o balanço é favorável à intervenção.|
|Certeza da evidência:|Moderada|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|Recurso Requerido|Moderado|Mesmo considerando que a trombectomia é custo-efetiva, a sua<br>implementação demandaria custos moderados.|
|Viabilidade de<br>implementação:|Sim|Tecnologia já disponível no SUS.|
|Outras considerações:|Não informado|Não foram reportadas outras considerações.|  
**QUESTÃO 7. Deve-se realizar trombectomia mecânica em pacientes com lesões de grandes vasos e com tempo de sintomas indeterminado ou** **_<mark>wake-up stroke</mark>_** **<mark>?</mark>**  
Questão removida do painel, uma vez que o tempo indeterminado e _wake-up stroke_ entram dentro das Questões 5 e 6, sendo considerado o último momento em que o paciente foi visto bem (sem sintomas neurológicos) para determinar a terapia. Uma vez calculado esse período, deverá ser tratado de acordo com as respectivas recomendações deste Protocolo. Entretanto, por se tratar de uma dúvida clínica foi realizada a síntese e a avaliação crítica das evidências desta tecnologia.  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : adultos (>18 anos) diagnosticados com AVCi agudo com lesões dos grandes vasos e com tempo de sintomas indeterminado ou _wake-up stroke_ .  
**Intervenção** : trombectomia mecânica associada ao melhor tratamento clínico.  
**Comparador** : melhor tratamento clínico.  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Métodos e resultados da busca:** -->
Foi realizada busca sistematizada da literatura nas bases de dados Pubmed, Lilacs, Embase, Cochrane, e Epistemonikos até o dia 29 de julho de 2021. Foi utilizada uma única estratégia de busca para as questões sobre trombectomia mecânica (Questões 5,6 e 7). As estratégias estão descritas no **Quadro K** .  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
<mark>(a) Tipos de participantes:</mark> pacientes adultos (>18 anos) diagnosticados com AVCi agudo com tempo de sintomas indeterminado ou _wake-up stroke_ .  
- <mark>(b) Tipo de intervenção: trombectomia mecânica.</mark>  
<mark>(c) Tipos de estudos: revisão sistemática ou ensaio clínico randomizado.</mark>  
<mark>(d) Desfechos: s</mark> obrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.  
<mark>(e) Idioma: não foi utilizada restrição em relação à linguagem e data de publicação.</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<u>Resultados da busca:</u>** -->
Na tomada de decisão, foram considerados os resultados de dois estudos avaliando o uso de trombectomia mecânica em pacientes com AVCi e tempo de início dos sintomas 6 e 16 horas e entre 6 e 24h<sup>28,29</sup> . Todo o processo de seleção foi detalhado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<u>Análise e apresentação dos resultados:</u>** -->
O risco de viés dos estudos incluídos foi avaliado utilizando a ferramenta ROB 2.0 da Cochrane por dois autores. Os dados foram retirados de dois estudos com pacientes com janela de sintomas entre 6-24h. Para o desfecho independência funcional, os dados dos pacientes com janela de sintoma indeterminado ou _wake-up stroke_ foram retirados de análises de subgrupo dos dois estudos incluídos e foram agrupados em meta-análises. Para os demais desfechos, os dados dos pacientes com janela de sintomas entre 6-24h foram agrupados, porém a evidência foi penalizada devido à indireção dos resultados. O agrupamento dos dados foi realizado utilizando o modelo de efeitos aleatórios e as medidas sumárias dos dados dicotômicos foram apresentadas utilizando RR com IC95%.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Resumo das evidências:** -->
Para avaliar o desfecho da independência funcional foram incluídos dois ECRs (Nogueira<sup>29</sup> e Albers, 2018<sup>28</sup> ). Para a obtenção dos dados, foram calculadas as frequências percentuais dos pacientes distribuídos em cada um dos escores de mRS (dados apresentados em materiais suplementares) em número absoluto de pacientes. <mark>Para os demais desfechos (mortalidade, hemorragia intracraniana sintomática, eventos adversos sérios - avaliado individualmente - deterioração neurológica, hemorragia parenquimatosa do tipo 2, sucesso da recanalização e eventos adversos sérios agrupados), devido à escassez de estudos incluindo pacientes com janela de sintomas indeterminado ou</mark> _<mark>wake-up stroke</mark>_ <mark>, foram consideradas as evidências indiretas obtidas por meio das análises dos estudos de Albers</mark><sup>28</sup> <mark>e Nogueira</mark><sup>29</sup> <mark>. Entretanto o nível da evidência foi penalizado no domínio da evidência indireta</mark>  
<mark>para os desfechos supracitados devido a amostra proveniente de estudo com pacientes com AVCi e janela de sintomas entre 8- 24h.</mark>  
Por fim, os resultados dos dois estudos agrupados indicam uma maior proporção absoluta de pacientes com independência funcional (conforme avaliado pela Escala modificada de Rankin 0-2) <mark>versus</mark> melhor conduta clínica (RR 3,29; IC95% 1,87 a 5,78; **Figura 24** ).  
**<mark>Figura 24</mark>** <mark>- Forest plot da comparação da trombectomia mecânica vs melhor tratamento clínico em pacientes com</mark> _<mark>wake-up stroke</mark>_ <mark>para o desfecho independência funcional (mRS 0-2).</mark>  
<!-- Start of picture text -->
Trombectomia Mecanica Controle Risk Ratio Risk Ratio<br>Study or Subgroup Events Total_Events Total Weight IV, Random, 95% Cl IV, Random, 95% Cl<br>Albers 2018 24 42 7 42 60.6%  — 3.43(1.66, 7.08] +<br>Nogueira 2018 2 ar 5 47 395% 3.091.26, 7.57] —<br>Total (95% Cl) 109 89 100.0% — 3.29[1.87, 5.78] ><br>Total events 46 12<br>TestHeterogeneity. for overall Tau?effect= 0.00;Z= 4.14 Chi?=(P < 0.03, 0.0001) df=1 (P = 0.86); F= 0% 1M yorece Controle Favorece Tit<br><!-- End of picture text -->  
O risco de viés destes dois estudos<sup>27,28</sup> . Os detalhes do julgamento estão apresentados na **Figura 25** .  
**Figura 25** - Risco de viés dos estudos Albers<sup>28</sup> e Nogueira<sup>29</sup> avaliado por meio da ferramenta ROB 2.0 da Cochrane.  
<!-- Start of picture text -->
1D Desfecho D1 D2 D3 D4 DS Geral<br>Noga 2480 ncpecdnde-$0 des @e@ee0@ @<br>Nagata 2018 Montaede @e@ee0@ @ ;<br>Veagnie 20182 independence cond @eeee@ @ @ riverine<br>Nogetira 20184 sucesso<br>Ieagsae do recanslizasbo eeeee @ 1) Algumas preocupacies<br>Ngee 36180 Waranglrecseiece stories COO CG @ @ whe<br>AtversAes 20182018s20181— independ neia funcionalMutmrarcininirtodorremssiinionsOetviei e agbo neo eeeee@e@eeee@ @OOSSCOSO @ »» DesviosProceso dasde intervengBes randomizagso pretendidas<br>‘eons Moin © © OOO @ is ascstahantesdo destecho<br>do desfecho<br>Abersun 20 0k184 W ea m oraganomaPoracrarian a  stoma @e e ee50dee0@ @ 04 MensuragSo<br>Abe 20181 Oeterlorizbo newoldgice recoce ee2eeeoe * Seleciio dos resultados reportados<br>Aiea 20184 ventonadverionsvon e@e@eeee @<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Perfil de evidências:** -->
O perfil de evidências conforme o sistema GRADE referente ao uso de trombectomia mecânica para o tratamento de pacientes com AVC <mark>i com lesões de grandes vasos e com tempo de sintomas indeterminado ou</mark> _<mark>wake-up stroke</mark>_ é apresentado no  
**Quadro N** . Já na **Tabela 4** são apresentadas as considerações para cada item do processo de evidência para recomendação.  
**Quadro N** - Avaliação da certeza da evidência do uso de trombectomia mecânica em pacientes com lesões de grandes vasos e com tempo de sintomas indeterminado ou _wake-up stroke._  
|**Avaliação**|**da certeza**||||||**№ de pacientes**||**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|**Delineamento**|**do**<br>**Risco**|**Inconsistênci**|**a**<br>**Evidência**|**Imprecisão**|<br>**Outras**|**Trombectomia**|**Conduta**|**Relativo**|**Absoluto**||
|**estudos**|**estudo**|**de viés**||**indireta**||**considerações**||**clínica**|**(IC 95%)**|**(IC 95%)**||
|**Independ**<br>2|**ência funcional**<br>ECR|**avaliado pel**<br>não<br>grave|**a escala de Ran**<br>não grave|**kin modificada**<br>não grave|**0-2 (seguimen**<br>grave<sup>a</sup>|**to: média 90 dias**<br>nenhum|**)**<br>46/109<br>(42,2%)|12/89<br>(13,59%)|RR 3,29<br>(1,87 para<br>5,78)|31 mais por 100 (de<br>12 mais para 64<br>mais)|<br> <br>⨁⨁⨁◯<br>Moderada|
|**Mortalida**|**de**|||||||||||
|2|ECR|não<br>grave|não grave|grave<sup>b</sup>|grave<sup>a</sup>|nenhum|33/199 (16.6%)|41/189<br>(21,7%)|RR 0,76<br>(0,41 para<br>1,40)|5 menos por 100 (de<br>13 menos para 9<br>mais)|<br> <br>⨁⨁◯◯<br>Baixa|
|**Hemorrag**|**ia intracranian**|**a sintomátic**|**a em um segui**|**mento de 90 dia**|**s**|||||||
|2|ECR|não<br>grave|não grave|grave<sup>b</sup>|muito grave<br>c|<br>nenhum|12/199 (6,0%)|7/189<br>(3,7%)|RR 1,63<br>(0,65 para<br>4,06)|2 mais por 100 (de 1<br>menos para 11 mais)|<br>⨁◯◯◯<br>Muito<br>Baixa|
|**Eventos a**|**dversos sérios -**|**avaliado ind**|**ividualmente:**|**Deterioração ne**|**urológica em**|**um seguimento d**|**e 90 dias**|||||
|2|ECR|não<br>grave|não grave|grave<sup>a</sup>|grave<sup>b</sup>|nenhum|23/199 (11,6%)|37/189<br>(19,6%)|RR 0,58<br>(0,36 para<br>0,94)|8 menos por 100 (de<br>13 menos para 1<br>menos)|<br> <br>⨁⨁◯◯<br>Baixa|  
|**Avaliaçã**|**o da certeza**||||||**№ de pacientes**||**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento do**|<br>**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Trombectomia**|**Conduta**|**Relativo**|**Absoluto**||
|**estudos**|**estudo**|**de viés**||**indireta**||**considerações**||**clínica**|**(IC 95%)**|**(IC 95%)**||
|**Eventos a**<br>1<br>**Sucesso d**|**dversos sérios - av**<br>ECR<br>**a recanalização em**|**aliado indi**<br>não<br>grave<br>**24 horas**|**vidualmente: He**<br>não grave|**morragia par**<br>grave<sup>a</sup>|**enquimatosa t**<br>muito grave<br>c|**ipo 2 em um segu**<br> <br>nenhum|**imento de 90 dias**<br>8/92 (8,7%)|<br>3/90 (3,3%)|<br>RR 2,61<br>(0,71 para<br>9,52)|<br>5 mais por 100<br>(de 1 menos para 28<br>mais)|<br>⨁◯◯◯<br>Muito<br>Baixa|
|1<br>**Eventos a**|ECR<br>**dversos sérios - ag**|não<br>grave<br>**rupado (av**|não grave<br>**aliado com: Tod**|grave<sup>a</sup><br>**os os eventos**|grave<sup>b</sup><br>**adversos sério**|nenhum<br>**s) em um seguime**|82/107 (76,6%)<br>**nto de 90 dias**|39/99<br>(39,4%)|RR 1,95<br>(1,49 para<br>2,54)|<br>37 mais por 100<br>(de 19 mais para 61<br>mais)|<br>⨁⨁◯◯<br>Baixa|
|1|ECR|não<br>grave|não grave|grave<sup>a</sup>|grave<sup>b</sup>|nenhum|62/92 (67.4%)|68/90<br>(75,6%)|RR 0,89<br>(0,74 para<br>1,07)|<br>8 menos por 100 (de<br>20 menos para 5<br>mais)|<br> <br>⨁⨁◯◯<br>Baixa|  
IC: Intervalo de Confiança/ RR: Risco Relativo/ ECR: Ensaio Clínico Randomizado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Perfil de evidências:** -->
a. Diminuído um nível devido poucos eventos.  
b. Diminuído um nível devido a presença de evidência indireta  
c. Diminuído dois níveis devido a poucos eventos e IC amplo

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
A **Tabela 4** apresenta o processo de tomada de decisão sobre o uso trombectomia mecânica para o tratamento do AVCi em pacientes com janela de sintomas indeterminada ou _wake-up stroke_ , baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Tabela 4** - Processo de tomada de decisão referente ao uso da trombectomia mecânica no tratamento de pacientes com AVCi e janela de sintomas indeterminado ou _wake-up stroke._  
|Item da EtD|Julgamento dos<br>painelistas|Justificativa|
|---|---|---|
|Efeitos desejáveis:|Grande|A maioria dos painelistas julgou que os efeitos desejáveis são substanciais,<br>incluindo aumento do número de pacientes com independência funcional<br>(mRS 0-2), recanalização e redução deterioração neurológica em 90 dias.|
|Efeitos indesejáveis|Trivial|A maioria dos painelistas considera os efeitos indesejáveis trivial, sem<br>diferença entre grupos para os efeitos indesejáveis. Julgamento baseado em<br>consenso clínico.|
|Balanço entre riscos e<br>benefícios:|Favorece a<br>intervenção|O grupo entende que o balanço é favorável à intervenção.|
|Certeza da evidência:|Moderada|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|Recurso Requerido|Moderado|Mesmo considerando que a trombectomia é custo-efetiva, a sua<br>implementação demandaria custos moderados.|
|Viabilidade de<br>implementação:|Sim|Tecnologia já disponível no SUS.|
|Outras considerações:|Não informado|Não foram reportadas outras considerações.|  
**QUESTÃO 8. Deve-se realizar anestesia geral ou sedação consciente no paciente que será submetido à trombectomia mecânica?**  
**<u>Recomendação 4:</u>** Sugerimos utilizar anestesia geral ou sedação consciente em pacientes elegíveis para TM a critério da equipe responsável (certeza de evidência baixa, recomendação condicional).  
A estrutura PICO para esta pergunta foi:  
**Pacientes** : pacientes adultos (>18 anos) diagnosticados com AVCi agudo que serão submetidos a trombectomia mecânica.  
**Intervenção** : anestesia geral.  
**Comparador** : sedação consciente.  
**Desfechos** : sobrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Métodos e resultados da busca:** -->
A seleção dos estudos considerou as revisões sistemáticas (RS) com meta-análises e, na ausência destas, ensaios clínicos randomizados (ECR) que apresentassem resultados comparativos entre anestesia geral e sedação consciente no paciente submetido à trombectomia mecânica. Com base na pergunta PICO estruturada foi realizada uma busca ( **Quadro O** ) em 29 de julho de 2021. As seguintes plataformas de busca foram utilizadas: Pubmed, EMBASE, Cochrane Library, LILACS e Epistemonikos.  
**Quadro O** - Estratégia de busca da questão sobre anestesia geral versus sedação consciente.  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>via<br>Pubmed<br>-<br>29/07/21|#1 "Thrombectomy"[Mesh] OR Thrombectom* OR "Endovascular<br>Procedures"[Mesh] OR Endovascular Procedure* OR Intravascular Procedure*<br>OR Intravascular Technique* OR endovascular therap*<br>#2 "Conscious Sedation"[Mesh] OR Moderate Sedation OR Conscious Sedation<br>#3 "Anesthesia, General"[Mesh] OR General Anesthesia*<br>#4 ((clinical[Title/Abstract] AND trial[Title/Abstract]) OR clinical trials as<br>topic[MeSH Terms] OR clinical trial[Publication Type] OR<br>random*[Title/Abstract] OR random allocation[MeSH Terms] OR therapeutic<br>use[MeSH Subheading])<br>#5 systematic[sb] OR meta-analysis[pt] OR meta-analysis as topic[mh] OR<br>meta-analysis[mh] OR meta analy*[tw] OR metanaly*[tw] OR metaanaly*[tw]<br>OR met analy*[tw] OR integrative research[tiab] OR integrative review*[tiab]<br>OR integrative overview*[tiab] OR research integration*[tiab] OR research<br>overview*[tiab] OR collaborative review*[tiab] OR collaborative<br>overview*[tiab] OR systematic review*[tiab] OR technology assessment*[tiab]<br>OR technology overview*[tiab] OR "Technology Assessment, Biomedical"[mh]<br>OR HTA[tiab] OR HTAs[tiab] OR comparative efficacy[tiab] OR comparative<br>effectiveness[tiab] OR outcomes research[tiab] OR indirect comparison*[tiab]<br>OR ((indirect treatment[tiab] OR mixed-treatment[tiab]) AND<br>comparison*[tiab]) OR Embase*[tiab] OR Cinahl*[tiab] OR systematic<br>overview*[tiab] OR methodological overview*[tiab] OR methodologic<br>overview*[tiab] OR methodological review*[tiab] OR methodologic<br>review*[tiab] OR quantitative review*[tiab] OR quantitative overview*[tiab]<br>OR quantitative synthes*[tiab] OR pooled analy*[tiab] OR Cochrane[tiab] OR|110|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||Medline[tiab] OR Pubmed[tiab] OR Medlars[tiab] OR handsearch*[tiab] OR<br>hand search*[tiab] OR meta-regression*[tiab] OR metaregression*[tiab] OR<br>data synthes*[tiab] OR data extraction[tiab] OR data abstraction*[tiab] OR<br>mantel haenszel[tiab] OR peto[tiab] OR der-simonian[tiab] OR<br>dersimonian[tiab] OR fixed effect*[tiab] OR "Cochrane Database Syst<br>Rev"[Journal:__jrid21711] OR "health technology assessment winchester,<br>england"[Journal] OR "Evid Rep Technol Assess (Full Rep)"[Journal] OR<br>"Evid Rep Technol Assess (Summ)"[Journal] OR "Int J Technol Assess Health<br>Care"[Journal] OR "GMS Health Technol Assess"[Journal] OR "Health Technol<br>Assess (Rockv)"[Journal] OR "Health Technol Assess Rep"[Journal]<br>#6 #4 OR #5<br>#7 #1 AND #2 AND #3 AND #6<br>#8 (animals NOT humans)<br>#10 #7 NOT #8||
|EMBASE<br>-<br>29/07/21|#1 'thrombectomy'/exp OR thrombectom* OR 'percutaneous thrombectomy'/exp<br>OR 'endovascular embolectomy' OR 'endovascular thrombectomy'<br>#2 'conscious sedation'/exp OR 'moderate sedation' OR 'sedation, conscious'<br>#3'general anesthesia'/exp OR 'anaesthesia, general' OR 'anesthesia, general'<br>OR 'general anaesthesia'<br>#4 'crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR  'single-blind procedure':de OR (random* OR  factorial*<br>OR crossover* OR cross NEXT/1 over* OR placebo* OR doubl* NEAR/1<br>blind* OR singl* NEAR/1 blind* OR assign* OR allocat* OR<br>volunteer*):de,ab,ti<br>#5 'meta analysis'/exp OR 'systematic review'/exp OR (meta NEAR/3<br>analy*):ab,ti OR metaanaly*:ab,ti OR review*:ti OR overview*:ti OR (synthes*<br>NEAR/3 (literature* OR research* OR studies OR data)):ab,ti OR (pooled AND<br>analys*:ab,ti) OR ((data NEAR/2 pool*):ab,ti AND studies:ab,ti) OR<br>medline:ab,ti OR medlars:ab,ti OR embase:ab,ti OR cinahl:ab,ti OR<br>scisearch:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti OR psychlit:ab,ti OR<br>psyclit:ab,ti OR cinhal:ab,ti OR cancerlit:ab,ti OR cochrane:ab,ti OR bids:ab,ti<br>OR pubmed:ab,ti OR ovid:ab,ti OR ((hand OR manual OR database* OR<br>computer*) NEAR/2 search*):ab,ti OR (electronic NEAR/2 (database* OR 'data<br>base' OR 'data bases')):ab,ti OR bibliograph*:ab OR 'relevant journals':ab OR<br>((review* OR overview*) NEAR/10 (systematic* OR methodologic* OR<br>quantitativ* OR research* OR literature* OR studies OR trial* OR|25|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||effective*)):ab NOT (((retrospective* OR record* OR case* OR patient*)<br>NEAR/2 review*):ab,ti OR ((patient* OR review*) NEAR/2 chart*):ab,ti OR<br>rat:ab,ti OR rats:ab,ti OR mouse:ab,ti OR mice:ab,ti OR hamster:ab,ti OR<br>hamsters:ab,ti OR animal:ab,ti OR animals:ab,ti OR dog:ab,ti OR dogs:ab,ti OR<br>cat:ab,ti OR cats:ab,ti OR bovine:ab,ti OR sheep:ab,ti) NOT ('editorial'/exp OR<br>'erratum'/de OR 'letter'/exp) NOT ('animal'/exp OR 'nonhuman'/exp NOT<br>('animal'/exp OR 'nonhuman'/exp AND 'human'/exp))<br>#6 #4 OR #5<br>#7 #1 AND #2 AND #3 AND #6<br>#8#7 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane Library<br>- 29/07/21|#1 MeSH descriptor: [Thrombectomy] explode all trees<br>#2 Thrombectom* OR Endovascular Procedure* OR Intravascular Procedure*<br>OR Intravascular Technique* OR endovascular therap*<br>#3  MeSH descriptor: [Endovascular Procedures] explode all trees<br>#4  #1 OR #2 OR #3<br>#5 MeSH descriptor: [Conscious Sedation] explode all trees<br>#6 Moderate Sedation OR Conscious Sedation<br>#7  #5 OR #6<br>#8 MeSH descriptor: [Anesthesia, General]explode all trees<br>#9General Anesthesia*<br>#10  # 8 OR #9<br>#11  #4 AND #7 AND #10|108|
|Lilacs via Portal<br>BVS - 29/07/21|mh:"Thrombectomy" OR mh:E04.100.814.842$ OR Thrombectom* OR<br>mh:"Endovascular Procedures" OR mh:E04.100.814.529$ OR<br>mh:E04.502.382$ OREndovascular Procedure* OR Intravascular Procedure*<br>OR Intravascular Technique* OR endovascular therap*<br>AND<br>mh:"Conscious Sedation" OR (Moderate Sedation) OR (Conscious Sedation)<br>OR mh:E03.250$ AND<br>mh:"Anesthesia, General"OR (General Anesthesia*) OR mhE03.155.197$ Filter: Lilacs|19|
|Epistemonikos<br>29/07/21|(title:(Thrombectomy AND "Conscious Sedation" AND "General Anesthesia")<br>OR abstract:(Thrombectomy AND "Conscious Sedation" AND "General<br>Anesthesia"))|5|  
Para a seleção e resolução das duplicatas e possíveis conflitos foi utilizado o aplicativo Rayyan.  Essa etapa foi realizada  
de forma independente por dois pesquisadores. Os resultados foram extraídos em um formulário padronizado e foram analisados utilizando o software Revman 5.4.  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
- <mark>(a) Tipos de participantes: p</mark> acientes adultos (>18 anos) diagnosticados com AVCi agudo elegíveis para trombectomia.  
- <mark>(b) Tipo de intervenção: anestesia geral vs. Sedação consciente.</mark>  
- <mark>(c) Tipos de estudos: revisão sistemática ou ensaio clínico randomizado.</mark>  
<mark>(d) Desfechos: s</mark> obrevida; dependência física ou funcionalidade avaliadas por escalas validadas, como a Escala de Rankin modificada (mRS); mortalidade; reperfusão avaliada por exames de imagem; qualidade de vida avaliada por questionários validados, como SF-12, SF-36, _Stroke Specific Quality of Life Scale_ (SS-QoL), _Stroke Impact Scale_ (SIS); eventos adversos sérios, como a taxa de hemorragia intracraniana avaliada por exames de imagem; eventos adversos gerais.  
- <mark>(e) Idioma: não foi utilizada restrição em relação à linguagem e data de publicação.</mark>

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<u>Resultados da busca:</u>** -->
Os resultados da busca totalizaram 267 referências. Os resultados de cada etapa do processo de seleção dos estudos são apresentados na **Figura 26** .  
**Figura 26** - Fluxograma de seleção dos estudos incluídos.  
<!-- Start of picture text -->
Referéncias rastreadas por meio 5<br>da busca nas bases de dados fontesReferéncias rastreadas(n = 2) por meio de outras<br>(n= 267)<br>Referéncias duplicadas<br>(n=76)<br>Refer€ncias avaliadas por meio Referéncias excluidas(n=188)<br>de titulos e resumos (n = 191) " =<br>Textos completosavaliados<br>para elegibilidade (n= 3) Estudos excluidos, com razdes<br>(n=2)<br>elegibilidadeEstudos no preencheram (PICO) (n= 2) os critériosde<br>RevisSo sistematica incluida<br>para sintese quantitativa<br>(n=1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **<u>Análise e apresentação dos resultados</u>** -->
Os dados da revisão sistemática foram apresentados por meio de gráficos de floresta. O agrupamento dos dados foi realizado utilizando o modelo de efeitos aleatórios e as medidas sumárias dos dados dicotômicos foram apresentadas utilizando RR com IC95%.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Resumo das evidências:** -->
Para responder essa questão clínica, a etapa de seleção dos estudos considerou as revisões sistemáticas (RS) com meta-  
análises e, na ausência destas, ensaios clínicos randomizados (ECR) que apresentassem resultados comparativos entre anestesia  
geral e sedação consciente no paciente submetido à trombectomia mecânica. Após a etapa de seleção, foi incluída uma revisão sistemática<sup>30</sup> comparando os efeitos da anestesia geral versus sedação consciente em pacientes elegíveis para trombectomia mecânica.  
Deste modo, foram encontradas evidências que indicam que não parece haver diferença entre utilizar anestesia geral versus sedação consciente para os desfechos qualquer hemorragia (RR 0,89; IC95% 0,45 a 1,75; **Figura 27** ), mortalidade (RR 0,77; IC95% 0,53 a 1,13; **Figura 28** ) e complicações da intervenção (complicações vasculares como dissecção da artéria ou perfuração e hematoma na virilha) (RR 1,18; IC95% 0,62 a 2,26; **Figura 29** ). Apesar de não ter sido capaz de detectar diferença estatística entre usar anestesia geral quando comparado a sedação consciente, parece que os pacientes submetidos a anestesia geral têm maior sucesso de recanalização (RR 1,11; IC 95% 1,00 a 1,23; **Figura 30** ) e independência funcional (conforme avaliado pela Escala modificada de Rankin 0-2) em 3 meses (RR 1,24; IC95% 1,00 a 1,55; **Figura 31** ).  
**<mark>Figura 27</mark>** <mark>- Forest plot da comparação da anestesia geral vs. sedação consciente em pacientes elegíveis para TM para qualquer hemorragia intracraniana. F</mark> onte:  
Bai,2021<sup>30</sup> . Legenda: GA: Anestesia geral, CS: Sedação consciente.  
<!-- Start of picture text -->
Study or Subgroup AnesteEvent s iageralTotal___EventsSedacdo consciente__Total_Weight_M-H,RiskRandom,Ratio95% Cl M-H, R iskandom, Ratio95%<br>‘ANSTROKERenCANVASGOLIATH¢ 2020201920182016 9040 48206848 7233 422063455.5%22.2%58.6%5.3% 4.2910.30,4.130.140.20 (0.01, (0.01, (0.46, 6.54]2.76]2.69)3.92) Cl<br>SIESTA 2016 1 73 2 7 8.3% 0.53 10.06, 6.69]<br>Total (95% Cl) 251 24T 100.0% 0.89 [0.45, 1.76]<br>TotalHeterogeneity:events Tau= 0.00; Chi*= 3.30,14 df=4 (P= 0.51);17 P= 0%<br>Testor overal ofedt Z= 034 (P=0.73) ‘ . ont Favorece reAnestesia geral ' Favoreze Sedac&ojad conscien0<br><!-- End of picture text -->  
**<mark>Figura 28</mark>** <mark>- Forest plot da comparação da anestesia geral vs. sedação consciente em pacientes elegíveis para TM para mortalidade.</mark> Fonte: Bai,2021<sup>30</sup> . Legenda:  
GA: Anestesia geral, CS: Sedação consciente.  
<!-- Start of picture text -->
Anestesiageral__Sedacdo consciente Risk Ratio Risk Ratio<br>Study<br>‘AnSTROKERenCANVASGOLIATHC or2020 Subgroup201920182016 Events9156 Total__Events48206545 4968 __Total_Weight_M-H,42°20°6345° 126%20.9%174%356% Random,== 0610.880550.22,0.17 (0.02, (0.38, 2.00](0.21,1.75]95%1.26)1.36]Cl M-H, Random,95% Cl<br>SIESTA 2016 1873 19 TT 45.6% 1.00 (0.57, 1.75]<br>Total (95% Cl) 251 247 100.0% 0.77 (0.53, 1.13]<br>TesterowrietedTotalHeterogeneity:events Tau= 22135020190.00; Chit=38  3.96, df=4 (P = 0.41);53 P= 0% oma i i ia<br>Favorece Anestesia geral Favorece Sedac3o conscien<br><!-- End of picture text -->  
**<mark>Figura 29</mark>** <mark>- Forest plot da comparação da anestesia geral vs sedação consciente em pacientes elegíveis para TM para complicações da intervenção. F</mark> onte: Bai,2021<sup>30</sup> .  
<!-- Start of picture text -->
Anestesiageral__Sedacdo consciente Risk Ratio Risk Ratio<br>Study<br>‘AnSTROKERenCANVASGOLIATHC or2020 Subgroup201920182016 Events11090 Total48206545 Events8766 __Total_Weight_MLH,42206345 26.9%301%28.4%6.0% Random,0.980.071.621.83 (0.62, (0.00, (0.42,0.74,95%2.32]1.09)4.18}4.53]Cl M-H, Random,95% Cl<br>SIESTA 2016 2 73 2 77 9.6% 1.05 (0.15, 7.29]<br>Total (95% Cl) 251 247 100.0% 1.18 [0.62, 2.26]<br>TestTotalHeterogeneity:events Taut= 0.17; Chit=32 5.96, df= 4 (P= 0.20);29  F= 33% atas HH + +H ote<br>for overall effect Z= 0.50 (P= 0.61) Favorece Anestesia geral Favorece Sedac3o conscien<br><!-- End of picture text -->  
**<mark>Figura 30</mark>** <mark>- Forest plot da comparação da anestesia geral vs sedação consciente em pacientes elegíveis para TM para o desfecho recanalização.</mark> Fonte: Bai,2021<sup>30</sup> . Legenda: GA: Anestesia geral, CS: Sedação consciente.  
<!-- Start of picture text -->
‘Anestesia geal Sedaco consciente Risk Ratio Risk Ratio<br>Study or Subgroup Events<br>‘AnSTROKECANVASGOUATHRen © 2020 201920182016 at19-2050a2 Total__Events__Total_Weight_M.H,458548 40133836 45206342° 27.3%140%230%82% 41.02Random,1.021.464.28{1.00, 0.87, 0.89, [1.04,95%1.62]1.20)1.18]2.05]Cl M-H, Random,ae95% CI<br>SIESTA 2016 65 73 62 17 276% 4.11 10.97, 1.271<br>Total (95% Cl) 251 247 100.0% © 1.11 [1.00,1.23]<br>Total events nT 189<br>Heterogeneity: Taut= 0.01; Chit= 6.73, df= 4 (P = 0.18), P= 41% a at 5 +<br>Testor overall elect 2= 1.94 (P= 0.08) Favorece Sedaco consciente Favorece Anestesia geral<br><!-- End of picture text -->  
**<mark>Figura 31</mark>** <mark>- Forest plot da anestesia geral vs. sedação consciente em pacientes elegíveis para TM para independência funcional (mRS 0-2). F</mark> onte: Bai,2021<sup>30</sup> . Legenda: GA: Anestesia geral, CS: Sedação consciente.  
<!-- Start of picture text -->
Anestesiageral_Sedaco consciente Risk Ratio Risk Ratio<br>Study<br>‘AnSTROKECANVASGOLIATHRen C of2020 Subgroup201920182016 Events1945“44652m Total4820 Events2181032 __‘Total_Weight_M-H,42°452063 164%121%36.1%22.0% Random,© 41.33(0.99,1.081.101.00 (064,1.73] (061, (0.66,95% 1.79} 1.99)1.51]Cl M-H, Random,95% Cl<br>SIESTA 2016 7 73 14 77 13.3% 2.03 [1.16, 3.56] ——_——<br>Total (95% Cl) 251 247 100.0% 1.24 1.00, 1.55]<br>TotalTestHeterogeneity:foreventsoverall effectTau= Z= 0.01;1.96125Chit=(P=4.89,0.05) df= 4 (P = 0.30);95  F= 18% Favorece Sedacdooe  consciena Favoreceae Anestesia geral<br><!-- End of picture text -->  
O risco de viés da revisão sistemática incluída foi avaliado utilizando a ferramenta ROBIS que indicou que a revisão sistemática selecionada apresenta baixo risco de viés. Assim, entende-se que os resultados foram construídos por meio de uma metodologia rigorosa que avaliou passo a passo a elaboração, condução e conclusão desta revisão. Quanto ao risco de viés dos ensaios clínicos incluídos na revisão sistemática, os estudos foram avaliados por meio da ferramenta ROB 1.0 e todos os cinco estudos incluídos apresentaram alto risco de viés no domínio sigilo de alocação e cegamento de participantes e um estudo foi julgado como tendo alto risco de viés para o domínio seleção dos resultados relatados. Além disso, três estudos apresentavam risco incerto de viés para o domínio outros vieses. Todos os detalhes a respeito do julgamento do risco de viés da revisão sistemática são apresentados no **Quadro P** .  
**Quadro P** - Risco de viés do estudo Bai, 2021, avaliado com a ferramenta ROBIS.  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
|1.<br>Preocupação em relação a<br>especificação dos critérios de<br>elegibilidade|1.1 A revisão aderiu a objetivos e critérios de<br>elegibilidade pré-definidos?<br>1.2 Os critérios de elegibilidade foram<br>adequados para a pergunta da revisão?<br>1.3 Os critérios de elegibilidade eram não-<br>ambíguos?<br>1.4 Qualquer restrição nos critérios de<br>elegibilidade foi baseada em características de<br>estudo apropriadas (data, tamanho da amostra,<br>qualidade do estudo, desfechos medidos)?<br>1.5 Qualquer restrição nos critérios de<br>elegibilidade foi baseada em fontes de<br>informações apropriadas (status da publicação<br>ou formato, idioma, disponibilidade de dados)?|1.1 S/PS/PN/N/**NI**<br>1.2**S**/PS/PN/N/NI<br>1.3**S**/PS/PN/N/NI<br>1.4**S**/PS/PN/N/NI<br>1.5 S/**PS**/PN/N/NI|1.<br>Baixa|Esforço<br>considerável<br>foi<br>feito<br>para<br>especificar<br>claramente a questão da revisão e objetivo, e para pré<br>especificar e justificar os critérios de elegibilidade<br>apropriados para essa revisão|
|2.<br>Preocupação em relação<br>aos métodos utilizados para<br>identificar ou selecionar estudos|2.1 A pesquisa incluiu uma gama apropriada de<br>bases de dados / eletrônica de estudos<br>publicados e não publicados?<br>2.2 Foram utilizados métodos adicionais para a<br>pesquisa de bases de dados usada para<br>identificar estudos relevantes?|2.1**S**/PS/PN/N/NI<br>2.2**S**/PS/PN/N/NI<br>2.3**S**/PS/PN/N/NI<br>2.4 S/PS/PN/N/**NI**<br>2.5**S**/PS/PN/N/NI|2. Baixa|Houve esforço substancial para buscar estudos<br>relevantes, tanto quanto possível por uma variedade de<br>método de pesquisa, utilizando uma estratégia de busca<br>sensível e apropriada e medidas foram tomadas para<br>minimizar erros de seleção.|  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
||2.3 Os termos e a estrutura da estratégia de<br>busca tinham probabilidade de recuperar tantos<br>estudos elegíveis quanto possível?<br>2.4 As restrições foram baseadas na data,<br>formato de publicação ou idioma apropriado?<br>2.5 Foram feitos esforços para minimizar o erro<br>na seleção dos estudos?||||
|3.<br>Preocupação com a coleta<br>de dados e análise crítica dos<br>estudos|3.1 Foram feitos esforços para minimizar erros<br>na coleta de dados?<br>3.2<br>Existiam<br>informações<br>disponíveis<br>suficientes sobre as características dos estudos<br>para tanto os autores da revisão quanto os<br>leitores serem capazes de interpretar os<br>resultados?<br>3.3 Todos os resultados relevantes foram<br>coletados para serem usados na síntese?<br>3.4 O risco de viés (ou qualidade metodológica)<br>foi formalmente avaliado usando critérios<br>apropriados?<br>3.5 Foram feitos esforços para minimizar erros<br>na avaliação do risco de viés?|3.1**S**/PS/PN/N/NI<br>3.2**S**/PS/PN/N/NI<br>3.3**S**/PS/PN/N/NI<br>3.4**S**/PS/PN/N/NI<br>3.5**S**/PS/PN/N/NI|3. Baixo|Considerando os estudos incluídos, o risco de viés<br>utilizando critérios apropriados, a Extração de dados e a<br>avaliação do risco de viés envolveram dois revisores,  e<br>as características dos estudos relevantes e os resultados<br>foram extraídos.|  
|**Domínio**|**Perguntas sinalizadoras**|**Resposta às**<br>**perguntas**<br>**sinalizadoras**|**Preocupação**|**Racional**|
|---|---|---|---|---|
|4.<br>Preocupação com relação<br>aos métodos utilizados para a<br>síntese e resultados|4.1 A síntese incluiu todos os estudos que<br>deveria?<br>4.2 Todas as análises predefinidas foram<br>relatadas ou os resultados explicados?<br>4.3 A síntese foi apropriada dada a natureza e<br>semelhança em questões de pesquisa, desenho<br>de estudo e resultados dos estudos incluídos?<br>4.4 A variação mínima entre os estudos<br>(heterogeneidade) foi abordada na síntese?<br>4.5 Os achados foram robustos i. e. como<br>demonstrado por meio do gráfico de funil ou em<br>análises de sensibilidade?<br>4.6 Os vieses nos estudos primários foram<br>mínimos ou foram abordados na síntese?|4.1**S**/PS/PN/N/NI<br>4.2 S/PS/PN/N/**NI**<br>4.3**S**/PS/PN/N/NI<br>4.4 S/PS/PN/**N**/NI<br>4.5 S/PS/PN/**N**/NI<br>4.6 S/PS/**PN**/N/NI|4. Alto|A síntese provavelmente produz resultados enviesados<br>porque vieses potenciais foram ignorados e importante<br>variação entre os estudos não foi levada em<br>consideração.|
|**Perguntas**||**Resposta**|**Risco de viés n**|**a Revisão Sistemática**|
|A) A interpretação dos ach<br>nos domínios 1 ao 4?<br>B) A relevância dos est<br>apropriadamente conside|ados aborda todas as preocupações identificadas<br>udos incluídos para a questão clínica foi<br>rada?|A) S/**PS**/N/PN/NI<br>B) S/**PS**/N/PN/NI|**BAIXO**, ALTO|E INCERTO|  
|**Domínio**<br>**Perguntas sinalizadoras**|**Resposta às**|**Preocupação**|**Racional**|
|---|---|---|---|
||**perguntas**|||
||**sinalizadoras**|||
|C) Os revisores evitaram enfatizar os resultados baseados na significância<br>estatística?|C) S/**PS**/N/PN/NI|||  
Legenda: S: Sim / PS: Provavelmente Sim/ N: Não / PN: Provavelmente Não/ NI: Não Informado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Justificativa para a recomendação:** -->
Diante das evidências científicas disponíveis não apresentarem um grande tamanho de efeito em desfechos clínicos importantes entre utilizar anestesia geral e sedação consciente, os especialistas consideram que se deve utilizar um ou outro procedimento conforme preferência e experiência das equipes.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Considerações gerais para implementação:** -->
● Os especialistas sugerem monitorar rigorosamente os valores pressóricos no momento da abertura do vaso dentro para  
evitar hipotensão;  
● Foi acordado entre os painelistas que se pode iniciar o procedimento com sedação consciente e, se necessário, utilizar-  
se a anestesia geral.

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Perfil de evidências:** -->
Os resultados a respeito do perfil de evidências do uso da anestesia geral versus sedação consciente em pacientes com  
AVCi elegíveis para trombectomia são apresentados no **Quadro Q** .  
**Quadro Q** - Avaliação da certeza da evidência do uso da anestesia geral versus sedação consciente em pacientes com AVCi elegíveis para trombectomia.  
|**Avaliaçã**|**o da certeza**||||||**№ de pacie**|**ntes**|**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**d**|**e**<br>**Delineamento**|**do**<br>**Risco de**|<br>**Inconsistência**|<br>**Evidência**|**Imprecisão**|<br>**Outras**|**Anestesia**|**Sedação**|**Relativo**|**Absoluto**||
|**estudos**<br>**Independ**|**estudo**<br>**ência funcional**|**viés**<br>**(seguimento:**|**90 dias; avaliado**|**indireta**<br>**com: mRS 0-**|**2)**|**considerações**|**geral**||**(95% CI)**|**(95% CI)**||
|5<br>**Recanali**|ECR<br>**zação**|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|125/251<br>(49,8%)|95/247<br>(38,5%)|RR 1,24<br>(1,00 para<br>1,55)|92 mais por 1.000 (de<br>0 menos para 212<br>mais)|<br> <br>⨁⨁⨁◯<br>Moderada|
|5<br>**Qualque**|ECR<br>**r hemorragia int**|grave<sup>a</sup><br>**racraniana**|não grave|não grave|não grave|nenhum|217/261<br>(83,1%)|189/247<br>(76,5%)|RR 1,11<br>(1,00 para<br>1,23)|84 mais por 1.000<br>(de 0 menos para 176<br>mais)|<br>⨁⨁⨁◯<br>Moderada|
|5|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|14/251<br>(5,6%)|17/247<br>(6,9%)|RR 0,89<br>(0,45 para<br>1,76)|8 menos por 1.000<br>(de 38 menos para 52<br>mais)|<br>⨁⨁◯◯<br>Baixa|
|**Mortalid**|**ade (seguimento**|**: 90 dias)**||||||||||
|5|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|39/251<br>(15,5%)|53/247<br>(21,5%)|RR 0,77<br>(0,53 para<br>1,13)|49 menos por 1.000<br>(de 101 menos para 28<br>mais)|<br>⨁⨁◯◯<br>Baixa|  
|**Avaliaçã**|**o da certeza**||||||**№ de pacie**|**ntes**|**Efeito**||**Certeza**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**de**|<br>**Delineamento**|**do**<br>**Risco de**|**Inconsistência**|**Evidência**|**Imprecisão**|<br>**Outras**|**Anestesia**|**Sedação**|**Relativo**|**Absoluto**||
|**estudos**|**estudo**|**viés**||**indireta**||**considerações**|**geral**||**(95% CI)**|**(95% CI)**||
|**Complica**|**ções vasculares a**|**ssociadas à in**|**tervenção (comp**|**licações vasc**|**ulares, como**|**dissecção da artéria**|**ou perfuraç**|**ão e hematom**|**a na virilha)**|||
|5|ECR|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|32/251<br>(12,7%)|29/247<br>(11,7%)|RR 1,18<br>(0,62 para<br>2,26)|21 mais por 1.000<br>(de 45 menos para 148<br>mais)|⨁⨁◯◯<br>Baixa|  
IC: Intervalo de Confiança/ RR: Risco Relativo/ ECR: Ensaio Clínico Randomizado

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Perfil de evidências:** -->
a. Diminuído um nível devido às limitações metodológicas (alto risco de viés no sigilo da alocação e cegamento de participantes e interventores em todos os estudos)  
b. Diminuído um nível devido a presença de poucos evento

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
A **Tabela 5** apresenta o processo de tomada de decisão sobre o uso da anestesia geral versus sedação consciente para o tratamento do AVCi baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Tabela 5** - Processo de tomada de decisão referente ao uso da anestesia geral versus sedação consciente no tratamento de pacientes com AVCi elegíveis para trombectomia.  
|Item da EtD|Julgamento dos<br>painelistas|Justificativa|
|---|---|---|
|Efeitos desejáveis:|Varia|A maioria dos painelistas julgou que os efeitos desejáveis variam. Parece<br>que há uma maior proporção de pacientes com efeitos desejáveis no grupo<br>que<br>recebeu<br>anestesia<br>geral.<br>Entretanto,<br>não<br>houve<br>diferença<br>estatisticamente significante entre os grupos.|
|Efeitos indesejáveis|Trivial|A maioria dos painelistas considerou os efeitos indesejáveis são triviais, não<br>havendo diferença entre grupos para estes efeitos (complicações associadas<br>à intervenção, qualquer hemorragia e mortalidade). Julgamento baseado em<br>consenso clínico.|
|Balanço entre riscos e<br>benefícios:|Varia|O grupo entende que o balanço entre os efeitos varia.|
|Certeza da evidência:|Baixa|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|Recurso Requerido|Negligenciável|Nenhuma justificativa foi apontada.|
|Viabilidade de<br>implementação:|Sim|AG esteja associada a menos agitação e movimento, mas pode atrasar o<br>início do procedimento endovascular;<br>SC permite o monitoramento neurológico, mas pode induzir dor e<br>movimento, tornar o procedimento mais longo e tecnicamente mais difícil.|
|Outras considerações:|Não informado|Não foram reportadas outras considerações.|

---

<!-- METADADOS: doenca: Acidente Vascular Cerebral Isquêmico Agudo - Portaria Conjunta SAES-SECTICS n 29 | secao: **REFERÊNCIAS** -->
1.  GRADE. Grading of Recommendations Assessment, Development, and Evaluation 2021 [Internet]. Available from:  
https://www.gradeworkinggroup.org/  
2.  Whiting P, Savović J, Higgins JPT, Caldwell DM, Reeves BC, Shea B, et al. ROBIS: A new tool to assess risk of bias  
in systematic reviews was developed. J Clin Epidemiol. 2016;69:225–34.  
3.  Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: a revised tool for assessing risk  
of bias in randomised trials. BMJ. 2019;366:l4898.  
4.   Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. 2014  
5.  Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan-a web and mobile app for systematic reviews. Syst  
Rev. 2016;5:210.  
6. Hacke W, Kaste M, Bluhmki E, Brozman M, Dávalos A, Guidetti D, et al. Thrombolysis with Alteplase 3 to 4.5 Hours  
after Acute Ischemic Stroke. N Engl J Med [Internet]. 2008;359:1317–29. Available from:  
https://doi.org/10.1056/NEJMoa0804656  
7.  Group TNI of ND and S rt-PSS. Tissue plasminogen activator for acute ischemic stroke. N Engl J Med.  
1995;333:1581–7.  
8.  Harrison MW, Young A. Thrombolysis Guided by Perfusion Imaging up to 9 Hours after Onset of Stroke: ma H,  
Campbell BCV, Parsons MW, Churilov L, et al. N Engl J Med 2019;380: 1795-1803. J Emerg Med [Internet]. 2019;57:273‐274. Available from: https://www.cochranelibrary.com/central/doi/10.1002/central/CN-01981395/full  
9. Ringleb P, Bendszus M, Bluhmki E, Donnan G, Eschenfelder C, Fatar M, et al. Extending the time window for  
intravenous thrombolysis in acute ischemic stroke  using magnetic resonance imaging-based patient selection. Int J stroke  Off J Int Stroke  Soc. 2019;14:483–90.  
10. Thomalla G, Simonsen CZ, Boutitie F, Andersen G, Berthezene Y, Cheng B, et al. MRI-Guided Thrombolysis for  
Stroke with Unknown Time of Onset. N Engl J Med. 2018;379:611–22.  
11. Michel P, Ntaios G, Reichhart M, Schindler C, Bogousslavsky J, Maeder P, et al. Perfusion-CT guided  
intravenous thrombolysis in patients with unknown-onset stroke:  a randomized, double-blind, placebo-controlled, pilot feasibility trial. Neuroradiology. 2012;54:579–88.  
12. Bivard A, Huang X, Levi CR, Spratt N, Campbell BC V, Cheripelli BK, et al. Tenecteplase in ischemic stroke offers  
improved recanalization: Analysis of 2  trials. Neurology. 2017;89:62–7.  
13. Parsons M, Spratt N, Bivard A, Campbell B, Chung K, Miteff F, et al. A randomized trial of tenecteplase versus  
alteplase for acute ischemic stroke. N Engl J Med. 2012;366:1099–107.  
14. Campbell BC V, Mitchell PJ, Churilov L, Yassi N, Kleinig TJ, Dowling RJ, et al. Tenecteplase versus Alteplase  
before Thrombectomy for Ischemic Stroke. N Engl J Med. 2018;378:1573–82.  
15. Kvistad CE, Novotny V, Kurz MW, Rønning OM, Thommessen B, Carlsson M, et al. Safety and Outcomes of  
Tenecteplase in Moderate and Severe Ischemic Stroke. Stroke. 2019;50:1279–81.  
16. Haley ECJ, Thompson JLP, Grotta JC, Lyden PD, Hemmen TG, Brown DL, et al. Phase IIB/III trial of tenecteplase  
in acute ischemic stroke: results of a  prematurely terminated randomized clinical trial. Stroke. 2010;41:707–11.  
17. Xu Q, Huang K, Zhai Z, Yang Y, Wang J, Wang C. Initial thrombolysis treatment compared with anticoagulation for acute intermediate-risk pulmonary embolism: A meta-analysis. J Thorac Dis [Internet]. 2015;7:810–21. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L604853843&from=export     U2  - L604853843  
18. Conitec. Trombectomia mecânica para acidente vascular cerebral isquêmico agudo. Relatório de Recomendação n 589. 2020.  
19. Berkhemer OA, Fransen PSS, Beumer D, van den Berg LA, Lingsma HF, Yoo AJ, et al. A randomized trial of intraarterial treatment for acute ischemic stroke. N Engl J Med. 2015;372:11–20.  
20. BC C, PJ M, RJ D, Yan B, GA D, SM D. Endovascular Therapy Proven for Stroke – Finally! [Internet]. Vol. 24,  
Heart, lung & circulation. Australia; 2015. p. 733–5. Available from: https://pubmed.ncbi.nlm.nih.gov/25939723/  
21. Saver JL, Goyal M, Bonafe A, Diener H-C, Levy EI, Pereira VM, et al. Stent-retriever thrombectomy after intravenous  
t-PA vs. t-PA alone in stroke. N Engl J Med. 2015;372:2285–95.  
22. Mocco J, Zaidat OO, von Kummer R, Yoo AJ, Gupta R, Lopes D, et al. Aspiration Thrombectomy After Intravenous Alteplase Versus Intravenous Alteplase  Alone. Stroke. 2016;47:2331–8.  
23. KW M, GA F, CM M, Ford I, Murray A, Clifton A, et al. Endovascular therapy for acute ischaemic stroke: the Pragmatic Ischaemic Stroke Thrombectomy Evaluation (PISTE) randomised, controlled trial. J Neurol Neurosurg Psychiatry [Internet]. 2017;88:38–44. Available from: https://pubmed.ncbi.nlm.nih.gov/27756804/  
24. Jovin TG, Chamorro A, Cobo E, de Miquel MA, Molina CA, Rovira A, et al. Thrombectomy within 8 Hours after  
Symptom Onset in Ischemic Stroke. N Engl J Med [Internet]. 2015;372:2296–306. Available from: https://doi.org/10.1056/NEJMoa1503780  
25. Goyal M, Demchuk AM, Menon BK, Eesa M, Rempel JL, Thornton J, et al. Randomized Assessment of Rapid Endovascular Treatment of Ischemic Stroke. N Engl J Med [Internet]. 2015;372:1019–30. Available from: https://doi.org/10.1056/NEJMoa1414905  
26. Bracard S, Ducrocq X, Mas JL, Soudant M, Oppenheim C, Moulin T, et al. Mechanical thrombectomy after intravenous alteplase versus alteplase alone after  stroke (THRACE): a randomised controlled trial. Lancet Neurol. 2016;15:1138–47.  
27. Martins SO, Mont’Alverne F, Rebello LC, Abud DG, Silva GS, Lima FO, et al. Thrombectomy for Stroke in the Public Health Care System of Brazil. N Engl J Med [Internet]. 2020;382:2316–26. Available from: https://doi.org/10.1056/NEJMoa2000120  
28. Albers GW, Marks MP, Kemp S, Christensen S, Tsai JP, Ortega-Gutierrez S, et al. Thrombectomy for Stroke at 6 to 16 Hours with Selection by Perfusion Imaging. N Engl J Med [Internet]. 2018;378:708–18. Available from: https://doi.org/10.1056/NEJMoa1713973  
29. Nogueira RG, Jadhav AP, Haussen DC, Bonafe A, Budzik RF, Bhuva P, et al. Thrombectomy 6 to 24 Hours after Stroke with a Mismatch between Deficit and Infarct. N Engl J Med [Internet]. 2017;378:11–21. Available from: https://doi.org/10.1056/NEJMoa1706442  
30. Bai X, Zhang X, Wang T, Feng Y, Wang Y, Lyu X, et al. General anesthesia versus conscious sedation for endovascular therapy in acute  ischemic stroke: A systematic review and meta-analysis. J Clin Neurosci  Off J Neurosurg Soc Australas. 2021;86:10–7.

---

