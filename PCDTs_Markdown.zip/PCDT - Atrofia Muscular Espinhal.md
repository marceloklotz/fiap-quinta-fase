<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 3, DE 20 DE MARÇO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Atrofia Muscular Espinhal 5q tipos 1 e 2.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE SUBSTITUTO, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Atrofia Muscular Espinhal 5q tipos 1 e 2 no Brasil  
e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 867 e o Relatório de Recomendação nº 870, de dezembro de 2023, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Atrofia Muscular Espinhal 5q tipos 1 e 2. Parágrafo único. O Protocolo, objeto deste artigo, que contém o conceito geral da Atrofia Muscular Espinhal 5q tipos 1 e 2, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Atrofia Muscular Espinhal 5q tipos 1 e 2.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SECTICS nº 6, de 15 de maio de 2023, publicada no Diário Oficial da União nº 95, de 19 de maio de 2023, seção 1, pág. 375.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES  
LEANDRO PINHEIRO SAFATLE

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **1.        INTRODUÇÃO** -->
As atrofias musculares espinhais são um grupo diverso de desordens genéticas que afetam o neurônio motor espinhal. As diferentes formas de atrofias musculares espinhais estão associadas a numerosas mutações genéticas e significativa variabilidade fenotípica. A atrofia muscular espinhal (AME) 5q é a forma mais comum nesse grupo de doenças neuromusculares hereditárias autossômicas recessivas caracterizadas pela degeneração dos neurônios motores na medula espinhal e tronco encefálico. Além disso, a AME 5q é a causa mais frequente de morte infantil decorrente de uma condição monogênica, apresentando uma prevalência de 1-2 em 100.000 pessoas e incidências de 1 a cada 6.000 até 1 a cada 11.000 nascidos vivos, conforme verificado em estudos realizados fora do Brasil<sup>1,2</sup> . Já as AME não-5q são um grupo em expansão e heterogêneo de doenças do neurônio motor, com aspectos clínicos e genéticos complexos, que atingem outros genes que não o de sobrevivência do neurônio motor 1 (SMN1)<sup>3</sup> .  
A AME 5q é causada por alterações no _locus_ do gene de sobrevivência do neurônio motor, localizado na região 5q11.213.3 do cromossomo 5. O _locus_ é constituído por dois genes parálogos (classe particular de homólogos resultantes da duplicação genômica): o gene _SMN1_ , localizado na região telomérica do cromossomo, e o gene de sobrevivência do neurônio motor 2 ( _SMN2_ ), localizado na região centromérica. Os genes _SMN1_ e _SMN2_ são responsáveis pela síntese da proteína de sobrevivência do neurônio motor (SMN), fundamental para a manutenção dos neurônios motores. A ocorrência de deleções, duplicações e conversões acometendo esses genes constitui o principal mecanismo molecular associado à AME 5q<sup>4–7</sup> .  
Na AME 5q, ambas as cópias do éxon 7 do gene _SMN1_ estão ausentes em cerca de 95% dos pacientes afetados. Nos 5% restantes, pode haver heterozigose composta (deleção em um alelo e mutação de ponto no outro alelo) ou, mais raramente, em casos de consanguinidade, mutação de ponto em homozigose. O gene parálogo _SMN2_ revela uma constituição similar ao _SMN1_ , contudo, as sequências genômicas de _SMN2_ diferem principalmente em uma base nucleotídica - C (citosina) por T (timina) na posição 6 do éxon 7. Enquanto o _SMN1_ expressa altos níveis de SMN de comprimento total e funcional, o SMN2 produz baixos níveis de transcrição de SMN de comprimento total (aproximadamente 10% dos transcritos) e uma abundância de uma isoforma processada (SMNΔ7) que não inclui o éxon 7 e codifica de forma instável a SMN, que é rapidamente degradada. É importante ressaltar que a perda completa de SMN é uma condição letal e que a AME é causada por baixos níveis de SMN - não sua ausência total e, por isso, não foram identificados pacientes com AME que sejam nulos tanto para a _SMN1_ quanto para a _SMN2_<sup>5–8</sup> .  
A alteração bialélica do gene SMN é a situação em que a doença se expressa, sendo que o número de cópias do gene _SMN2_ , que pode variar de zero a oito, é o principal determinante da gravidade da doença<sup>9</sup> . Contudo, essa relação não pode ser considerada determinante, pois os níveis de proteína SMN nos tecidos periféricos, como sangue e fibroblastos, variam e nem sempre se correlacionam com o número de cópias de _SMN2_ e com os níveis de ácido ribonucleico mensageiro (RNAm)<sup>10,11</sup> . Ademais, pacientes com o mesmo número de cópias de _SMN2_ podem apresentar fenótipos muito diferentes, o que sugere o envolvimento de outros mecanismos relacionados à manifestação clínica e gravidade da AME 5q<sup>12–16</sup> .  
No sistema nervoso central (SNC), os neurônios motores inferiores, localizados no corno anterior da medula espinhal, são os principais alvos da doença. A falta da proteína SMN resulta em degeneração e perda progressiva da função desses neurônios, deixando os neurônios sensoriais intactos. Essa degeneração resulta em fraqueza, hiporreflexia e atrofia simétrica progressiva com predomínio dos músculos voluntários proximais de membros inferiores, superiores, e, durante a progressão da doença, pode afetar os músculos axiais, da respiração e bulbares que, por sua vez, pode gerar falha respiratória e morte<sup>5,17–19</sup> .  
A doença apresenta um padrão clínico similar ao miopático, com maior acometimento dos músculos proximais do que  
distais, dos membros inferiores do que os superiores, e estes últimos são mais afetados que os músculos da face e diafragma, ou seja, a fraqueza e atrofia musculares não apresentam uma distribuição homogênea<sup>5,19,20</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da AME 5q tipo 1B/C e tipo 2 (ver classificação no item 3 – Diagnóstico), em caso de doentes com diagnóstico genético confirmado e sem necessidade de ventilação mecânica invasiva (> 16 horas/dia).

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **2.        CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- G12.0 - Atrofia muscular espinal infantil tipo 1 (Werdnig-Hoffman)  
- G12.1 - Outras atrofias musculares espinais hereditárias

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **3.1 Classificação dos tipos de AME 5q** -->
A classificação clínica da AME 5q é dada pela idade de início e máxima função motora adquirida, podendo ser classificada em quatro tipos<sup>5,21</sup> .  
A AME 5q tipo 1 tem início precoce e é a mais grave e também a mais comum, representando 58% dos casos<sup>22</sup> . Os pacientes apresentam hipotonia, controle insuficiente da cabeça, redução de reflexos ou arreflexia antes dos 6 meses de idade, hipotonia profunda e geralmente nunca são capazes de se sentar sem auxílio. A fraqueza dos músculos intercostais é evidenciada pela observação de um padrão de respiração paradoxal do tipo abdominal, com a relativa preservação do diafragma, geralmente evoluindo para uma insuficiência respiratória antes dos 2 anos de vida. Fraqueza na deglutição e fasciculações de língua estão frequentemente presentes, e, à medida que a língua e os músculos faríngeos se enfraquecem, esses pacientes correm risco de aspiração. Apesar de todos estes sintomas, a cognição é normal<sup>21</sup> . A AME 5q tipo 1 pode ser dividida em 1a ou 0, 1b e 1c. Indivíduos com AME 5q tipo 1a, também denominada AME 5q tipo 0, apresentam apenas uma cópia do gene _SNM2_ e nenhum marco de desenvolvimento. A doença tem início pré-natal, com sintomas de hipotonia e insuficiência respiratória imediatamente após o nascimento; o exame físico revela arreflexia, diplegia facial, defeitos do septo interatrial e contraturas articulares, e a doença evolui para o óbito neonatal precoce<sup>21,23</sup> . Pacientes com AME tipo 1b geralmente apresentam duas cópias do gene _SNM2_ , com início dos sintomas antes dos 3 meses de idade, com controle cefálico pobre ou ausente, problemas respiratórios e alimentares, geralmente com evolução letal no segundo ou terceiro ano de vida. Pacientes com AME tipo 1c apresentam usualmente três cópias do gene _SNM2_ , com aparecimento dos sintomas depois dos 3 meses, podendo apresentar controle cefálico e problemas respiratórios e alimentares que atingem um _plateau_ nos primeiros 2 anos<sup>21,24,25</sup> .  
Já a AME 5q tipo 2 é caracterizada pela manifestação dos sintomas entre 6 e 18 meses de idade e estima-se que representa 27% dos casos de AME 5q<sup>2</sup> . A capacidade de sentar é geralmente alcançada por volta dos nove meses, embora esse marco possa ser atrasado. Os pacientes, em geral, não ficam de pé ou andam independentemente, mas alguns conseguem ficar de pé com a ajuda de órteses ou de uma estrutura ortostática. O exame físico demonstra fraqueza proximal predominante, que é mais grave nos membros inferiores, e os reflexos geralmente estão ausentes<sup>9</sup> . Além disso, a deglutição prejudicada e a insuficiência ventilatória são frequentes na AME 5q tipo 2, principalmente em indivíduos na extremidade grave do espectro do tipo 2<sup>19</sup> . A escoliose ocorre universalmente neste grupo e é um fator contribuinte significativo para distúrbios de ventilação restritivos. Embora a expectativa de vida seja reduzida em pacientes com AME 5q tipo 2, em grande parte devido às complicações respiratórias, a maioria desses indivíduos chega à idade adulta, devido à melhora da história natural relacionada aos cuidados de  
suporte<sup>9,19</sup> .  
Os tipos 3 e 4 da AME 5q afetam cerca de 13% e  5% dos individuos respectivamente. De forma geral, esses indíviduos apresentam mais de três cópias de _SMN2_ , com início dos sintomas após os 18 meses de vida. Nesses subtipos, a maioria das pessoas alcança a vida adulta, com expectativa de vida variável entre os tipos. O alcance de marcos motores é bem distinto entre as classificações, sendo que o tipo 3 apresenta pior função motora e o tipo 4 o melhor desenvolvimento motor. Outros sistemas orgânicos são, geralmente, preservados<sup>1,6,11,21</sup> . As características dos subtipos da AME 5q estão sintetizadas no Quadro 1.  
**Quadro 1** - Síntese das características gerais dos subtipos de AME 5q  
|**Subtipo de**<br>**AME 5q**|**Proporção**|**Número de**<br>**cópias de SMN2**|**Idade de**<br>**início dos**<br>**sintomas**|**Expectativa de vida**<br>**(mediana de**<br>**sobrevida)**|**Marco motor mais alto**<br>**alcançado**|
|---|---|---|---|---|---|
|AME tipo 1|60%|2 – 3 cópias|0-6 meses|< 2 anos|Senta com apoio|
|AME tipo 2|27%|3 cópias|7-18 meses|> 2 anos a 35 anos|Senta independentemente|
|AME tipo 3|13%|3 – 4 cópias|> 18 meses|Normal|Fica de pé e anda sem<br>apoio|
|AME tipo 4|-|4 ou mais cópias|Adultos|Normal|Caminha durante a idade<br>adulta|  
_Nota: Esclarecimento sobre número de cópias do gene SMN2 e definição população elegível para tratamento com Nusinersena, Risdiplam e Onasemnogeno abeparvoveque. Fonte: Eficácia e efetividade do nusinersena, risdiplam e onasemnogeno abeparvoveque para o tratamento de atrofia muscular espinhal (AME) 5q tipos 1 e 2, CCATES 2023 (PTC 2023)_<sup>_26_</sup>

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Suspeita clínica e condutas diagnósticas** -->
Em pacientes com AME 5q tipo 1 sintomáticos, a suspeita clínica inclui crianças com início de sintomas até seis meses de idade, com hipotonia e fraqueza muscular<sup>19</sup> . A fraqueza é progressiva, geralmente simétrica e mais proximal que distal, com predomínio nos membros inferiores, sensibilidade preservada e reflexos tendinosos ausentes ou diminuídos, com fasciculações presentes (preservação da mímica facial e interação com o examinador, isto é, acompanhamento com olhar e sorriso). Clinicamente, nota-se também fraqueza dos músculos intercostais, tórax em forma de sino e padrão respiratório paradoxal. A gravidade da fraqueza geralmente se correlaciona com a idade de início das manifestações clínicas e, portanto, quanto mais precoce o início dos sinais e sintomas, mais rápido deve ser o diagnóstico<sup>27</sup> .  
Nos pacientes com AME 5q tipo 1 pré-sintomáticos, a suspeita clínica é ocasionada por histórico familiar, entre pais que já tiveram filhos diagnosticados com AME, preconiza-se a realização de teste genético para corroborar o diagnóstico logo após o nascimento do segundo filho.  
Já em pacientes com AME 5q tipo 2, o início dos sintomas ocorre até os 18 meses de vida e é marcado pelo atraso no desenvolvimento motor das crianças portadoras. De forma geral, além do atraso motor, pode-se observar ganho de peso insuficiente, em decorrência da dificuldade de engolir; fraqueza dos músculos intercostais, respiração diafragmática, dificuldade para tossir (tosse fraca), presença de tremores finos nas mãos, contraturas nas extremidades inferiores e desenvolvimento de escoliose<sup>27</sup> .  
Como a AME 5q é uma doença genética, causada pela ausência homozigótica do éxon 7 e, eventualmente, do éxon 8 do gene SMN1, seu diagnóstico é baseado em testes genéticos moleculares<sup>22,27,28</sup> . De forma geral, não há necessidade de realização  
de biópsia muscular, eletromiografia ou mensuração dos níveis séricos de creatinoquinase (CK). O padrão-ouro do teste genético para AME é uma análise quantitativa de SMN1 e SMN2, usando MLPA (do inglês, _multiplex ligation-dependent probe amplification_ ) ou qPCR (do inglês, _quantitative polymerase chain reaction_ ). A ausência das duas cópias completas de SMN1 (homozigose), comprovada por qPCR ou MLPA confirmará o diagnóstico da AME 5q. Os pacientes com heterozigose composta (deleção em um alelo e mutação de ponto no outro alelo) ou mutação de ponto em homozigose (em casos de consanguinidade) deverão ser submetidos ao procedimento de identificação de mutação por sequenciamento por amplicon para confirmar o diagnóstico da AME 5q tipo 1 ou tipo 2<sup>6,28,29</sup> .  
Para definir a classificação fenotípica da AME, alguns outros aspectos devem ser observados. A maioria dos pacientes com AME 5q tipo 1 apresenta duas cópias do gene SMN2, ao passo que pacientes com AME 5q tipo 2 apresentam, geralmente, três cópias do gene; e esse é um importante fator de classificação da AME 5q, porém, isoladamente, não define o fenótipo<sup>30–32</sup> . Além das cópias de SMN2, a idade no início da doença, função motora e respiratória devem ser avaliadas<sup>25</sup> (Quadro 2). Os passos diagnósticos estão sintetizados na **Figura 1** .  
**Quadro 2** - Características da AME 5q tipos 1 e 2  
|**Tipo de**<br>**AME 5q**|**Início da**<br>**doença**|**Marco do**<br>**desenvolvimento**<br>**atingido**|**Evolução**|**Número de**<br>**cópias de**<br>**SMN2**|
|---|---|---|---|---|
|0 ou 1a|Pré-natal|Nenhum|Morte em semanas|1|
|1b/c|< 6 meses|Controle cefálico pobre ou<br>ausente|Hipotonia grave e precoce, problemas<br>respiratórios<br>e<br>alimentares<br>com<br>declínio progressivo, expectativa de<br>vida de até 24 meses.|2 a 3|
|2|Entre 7 e 18<br>meses|Sentar com ou sem apoio,<br>permanecer sentado sem<br>apoio|Fraqueza muscular, principalmente<br>dos membros inferiores; fraqueza<br>bulbar,<br>causando<br>tosse<br>fraca<br>e<br>dificuldade de deglutição; contraturas,<br>tremores e fraqueza dos músculos<br>intercostais.|3|  
Nota: a Lei Federal 14.154 de 2021 incluiu no denominado “teste do pezinho” o diagnóstico da AME em recém nascidos.  
**Figura 1** - Algoritmo de conduta diagnóstica da AME 5q.  
<!-- Start of picture text -->
Suspeita clinica<br>de AME 5q<br>,<br>Teste de variago de<br>ntimero de cépias do<br>SMN1e SMN2<br>{ {qPCRMLPA 1:<br>SMNI ‘SMNN2<br>[ | Y1<br>aOcdpia 1 cépia 22ebpias PocaPredicSo de<br>Confirmaciode AME genética Sq a)H .msmvrctdoae<br>' POs<br>|| comvaranteart | (EES a | ——!—+] Socouecsdosneas +Lo |lievesteto erecines<br>patogenka | eee neuromusculares<br>*MLPA, multiplex ligation-dependent probe amplification; qPCR, PCR quantitativo; **identificac3o de muta¢3o por sequenciamento por amplicon.<br><!-- End of picture text -->  
Fonte: Adaptado de: Mercuri _et al_<sup>27</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **4.        CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo indivíduos de ambos os sexos, com diagnóstico genético confirmado de AME 5q tipos 1  
e 2.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **_<u>Para uso do onasemnogeno abeparvoveque:</u>_** -->
Serão incluídos os indivíduos de ambos os sexos, com até seis meses de idade (na data de solicitação do medicamento) e idade máxima de sete meses na data de infusão do medicamento, diagnóstico genético confirmado de AME 5q tipo 1, com até três cópias de SMN2, desde que não estejam em ventilação mecânica invasiva por mais de 16 horas por dia. O uso poderá ser realizado em indivíduos pré-sintomáticos ou sintomáticos:  
- Pré-sintomáticos: diagnóstico genético confirmado de AME 5q e presença de até três cópias de SMN2<sup>26</sup> ;  
- Sintomáticos: diagnóstico genético confirmado de AME 5q, presença de até três cópias de SMN2 e início dos sintomas  
- até o sexto mês de vida<sup>26</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **_<u>Para uso de nusinersena ou risdiplam:</u>_** -->
Serão incluídos os indivíduos de ambos os sexos, com diagnóstico genético confirmado de AME 5q tipo 1 ou 2, com até  
três cópias de SMN2, além de cumprir os critérios a seguir, de acordo com a sua situação clínica:  
- Para pacientes com **<u>AME 5q do tipo 1</u>** <u>:</u>  
- Pré-sintomáticos: diagnóstico genético confirmado de AME 5q e presença de até três cópias de SMN2<sup>26</sup> ;  
- Sintomáticos: diagnóstico genético confirmado de AME 5q, presença de até três cópias de SMN2 e início dos sintomas  
até o sexto mês de vida<sup>26</sup> .  
<u>Para pacientes com</u> **<u>AME 5q do tipo 2</u>** <u>:</u>  
- Pré-sintomáticos: diagnóstico genético confirmado de AME 5q e presença de até três cópias de SMN2<sup>26</sup> ;  
- Sintomáticos: início dos sintomas entre 6 e 18 meses de vida, confirmado por diagnóstico genético e presença de até  
três cópias de SMN2<sup>26</sup> ; **e**  
º até 12 anos de idade no início do tratamento; **ou**  
º mais de 12 anos de idade no início do tratamento e preservada a capacidade de se sentar sem apoio e a função dos  
membros superiores.  
Adicionalmente, para utilização do onasemnogeno abeparvoveque, nusinersena ou risdiplam, independentemente da manifestação de sintomas, o paciente deverá apresentar condições de nutrição e hidratação adequadas, com ou sem gastrostomia, e estar com o calendário de vacinação em dia.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **5.        CRITÉRIOS DE EXCLUSÃO** -->
<u>Para o tratamento com nusinersena, devem ser observados os seguintes critérios de exclusão:</u>  
- sinais ou sintomas de AME 5q compatíveis com o subtipo 1a ou 0; ou seja, manifestações clínicas presentes ao  
- nascimento ou na primeira semana após o nascimento;  
- sinais ou sintomas de AME 5q compatíveis com os subtipos 3 ou 4; ou seja, surgimento de manifestações clínicas  
- após os 18 meses de idade;  
- hipersensibilidade às substâncias ativas ou excipientes das formulações que impeça o uso das alternativas  
- medicamentosas disponibilizadas;  
- necessidade de ventilação mecânica invasiva, entendida como 24 horas de ventilação/dia, continuamente, por ≥ 21  
dias<sup>8</sup> ;  
- presença de contraturas graves ou de escoliose grave que, de acordo com o médico assistente, possam interferir na  
- administração do medicamento, trazendo riscos para o paciente, evidenciados por radiografia ou outros exames de imagem; ou  
- história de doença cerebral ou da medula espinhal que impeça a administração intratecal de medicamento ou a  
- circulação do líquido cefalorraquidiano, presença de derivação implantada para drenagem do líquido cefalorraquidiano ou de cateter de sistema nervoso central implantado.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: <u>Para o tratamento com risdiplam, devem ser observados os seguintes critérios de exclusão:</u> -->
- sinais ou sintomas de AME 5q compatíveis com o subtipo 1a ou 0; ou seja, manifestações clínicas presentes ao  
- nascimento ou na primeira semana após o nascimento;  
- sinais ou sintomas de AME 5q compatíveis com os subtipos 3 ou 4; ou seja, surgimento de manifestações clínicas  
- após os 18 meses de idade;  
- hipersensibilidade às substâncias ativas ou excipientes das formulações que impeça o uso das alternativas  
- medicamentosas disponibilizadas;  
- necessidade de ventilação mecânica invasiva acima de 24 horas de ventilação/dia, continuamente, por ≥ 21 dias<sup>8</sup> ; ou  
- .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: <u>Para o tratamento com onasemnogeno abeparvoveque, devem ser observados os seguintes critérios de exclusão:</u> -->
- sinais ou sintomas de AME 5q compatíveis com os tipos 2, 3 ou 4;  
- hipersensibilidade às substâncias ativas ou excipientes das formulações que impeça o uso das alternativas  
- medicamentosas disponibilizadas;  
- necessidade de ventilação mecânica invasiva acima de 16 horas por dia<sup>34</sup> ;  
- idade superior a 6 meses na data da apresentação do pedido do medicamento à unidade de saúde responsável no SUS,  
- uma vez que não foram estabelecidos estudos de segurança e eficácia para essa população<sup>34</sup> .  
- idade superior a 7 meses na data de infusão do medicamento.  
- título de anticorpos contra o vírus adeno-associado sorotipo 9 (AAV9) igual ou maior que 1:50, uma vez que não foi  
- estabelecido se há risco de resposta imunológica para pacientes com anticorpo AAV9 pré-existentes em concentrações superiores  
e, portanto, a segurança e a eficácia do medicamento não está estabelecida para estas condições<sup>35</sup> .  
- presença de infecção viral ativa, de qualquer natureza, incluindo o imunodeficiência humana (HIV) ou sorologia positiva para hepatite B ou C, Zika vírus, dentre outros. Após manejo adequado da infecção viral, caso o paciente tenha alcançado mais de 6 meses de idade, estes poderão ainda utilizar as alternativas nusinersena ou risdiplam;  
- alergia ou hipersensibilidade conhecida à prednisolona ou a outros glicocorticóides ou seus excipientes<sup>34</sup> ; ou  
- incapacidade de deglutição, avaliada pelo médico responsável.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **6.        TRATAMENTO** -->
Por se tratar de uma condição clínica neurodegenerativa progressiva, os cuidados de suporte e tratamentos médicos especializados são fundamentais, levando ao aumento da expectativa e da qualidade de vida dos pacientes com AME 5q. Estudos da história natural da doença comprovam que houve aumento significativo da expectativa e qualidade de vida de indivíduos com AME 5q a partir da disponibilidade de cuidados de suporte e terapêuticos<sup>32,36</sup> .  
A AME é uma doença complexa que envolve diferentes aspectos do cuidado e profissionais da saúde. Uma conduta multidisciplinar é o elemento-chave na atenção aos pacientes com atrofia muscular espinhal, incluindo nutricionistas, enfermeiros, fonoaudiólogos e fisioterapeutas, além de outros cuidados em saúde.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **6.1 Tratamento não medicamentoso** -->
O tratamento não medicamentoso desses pacientes abrange, essencialmente, os cuidados nutricionais, respiratórios e ortopédicos.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Suporte nutricional** -->
O suporte nutricional e fonoaudiológico são recomendáveis, uma vez que as crianças com AME 5q perdem ou não desenvolvem a capacidade de se alimentarem por via oral. Também podem apresentar vários problemas gastrointestinais, sendo o refluxo diretamente relacionado à morbimortalidade desses pacientes, por estar associado à aspiração silenciosa e, consequentemente, pneumonia. Além disso, devido à motilidade gastrointestinal deficiente, podem apresentar constipações graves<sup>17</sup> .  
Os pacientes com AME 5q tipo 1 podem apresentar fraqueza muscular mastigatória, dificuldades de abrir a boca, pouco controle da cabeça, disfagia e problemas respiratórios que podem culminar na ingestão calórica reduzida e aspiração de alimentos. O controle nutricional e digestivo é destinado principalmente para resolver problemas relacionados à deglutição, disfunção gastrointestinal e suplementação alimentar ou controle de peso. É necessário monitorar sinais e sintomas, como refluxo gastroesofágico, constipação, retardo do esvaziamento gástrico e vômitos. Recomenda-se que o monitoramento nutricional envolva não apenas o controle de peso, mas também a ingestão de líquidos, macronutrientes e micronutrientes, especialmente a ingestão de cálcio e vitamina D para fortalecimento ósseo<sup>5,25</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Cuidados respiratórios** -->
Recomenda-se a avaliação respiratória contínua, pois os pacientes com AME 5q podem apresentar um diafragma relativamente forte e músculos intercostais fracos que, somado à dificuldade de tossir e eliminar o muco, pode resultar em hipoventilação (agravada durante o sono), atelectasia, depuração deficiente das secreções das vias aéreas e infecções recorrentes<sup>32,37,38</sup> .  
A fisioterapia respiratória é essencial no cuidado dos pacientes, especialmente nos casos de AME 5q tipo 1. Além disso, recomenda-se o uso de medidas para a remoção de muco e secreções aéreas. Em certos casos, indica-se o uso de ventilação  
mecânica não invasiva (VNI) com pressão positiva ou mesmo a ventilação mecânica invasiva.  
A VNI é recomendada para todas as crianças com AME com insuficiência respiratória aguda ou crônica agudizada. A VNI também pode ser recomendada para as crianças que não se assentam, mesmo antes do surgimento de sinais de insuficiência respiratória, visando a prevenir e minimizar a distorção da parede torácica, melhorar o funcionamento e desenvolvimento pulmonar e atenuar a dispneia. No entanto, o uso de VNI apresenta algumas limitações, como encontrar uma interface adequada e com bom ajuste para crianças. A VNI pode apresentar complicações decorrentes do uso da interface por longos períodos de tempo, como por mais de 16 horas por dia, o que pode ocasionar irritações e lesões de pele, hipoplasia da face média, distensão gástrica e vômitos<sup>32,37,38</sup> .  
A ventilação invasiva, normalmente com uso de cânula de traqueostomia, é uma opção para os pacientes em que a VNI não é efetiva. Essa decisão deve ser tomada em conjunto com a família, considerando-se o estado clínico, prognóstico e qualidade de vida do paciente. Em casos de asma, podem ser empregados broncodilatadores inalatórios<sup>37</sup> .  
A critério médico, os cuidados respiratórios e o suporte ventilatório podem ser demandados no SUS via diferentes modalidades da atenção domiciliar ou hospitalar. O suporte ventilatório foi regulamentado pela Portaria SCTIE/MS nº 68, de 23 de novembro de 2018 que incorporou no SUS a ventilação mecânica invasiva domiciliar para insuficiência respiratória crônica.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Cuidados ortopédicos, fisioterapia, fonoaudiologia e terapia ocupacional** -->
A AME 5q é primariamente uma doença do neurônio motor, mas a expressão deficiente da proteína SMN pode acontecer em todas as células durante o desenvolvimento fetal e pós-natal. Embora o acometimento de outros tecidos possa ter implicações nas condutas terapêuticas, em apenas uma parte dos pacientes com AME 5q verifica-se acometimento de outros órgãos<sup>37</sup> . Mesmo assim, os indivíduos também devem ser avaliados e tratados, conforme os outros locais de manifestação da doença.  
As condutas ortopédicas são destinadas à manutenção do movimento, prevenção e tratamento de fraturas, contraturas e deformidades pélvicas, torácicas, da coluna vertebral e dos membros inferiores. A escoliose é muito prevalente em pacientes com AME, assim como cifose torácica e deformidades do tórax. Para aqueles que não se sentam, as condutas dependem da sua estabilidade respiratória, digestiva e nutricional.  
A Rede de Cuidados à Pessoa com Deficiência conta com profissionais e equipamentos importantes para o indivíduo diagnosticado com AME. A fisioterapia, a terapia ocupacional e fonoaudiologia são serviços recomendados para mitigar a progressão da AME, bem como as consequências ortopédicas como as contraturas e melhoria na amplitude dos movimentos<sup>5,39</sup> . Os procedimentos referentes a estes cuidados estão elencados na Tabela de Procedimentos, Medicamentos e OPM do SUS.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **6.2 Tratamento medicamentoso** -->
Até a elaboração deste Protocolo, os medicamentos específicos aprovados no Brasil para o tratamento de AME 5q são nusinersena, risdiplam e onasemnogeno abeparvoveque. Os estudos recuperados têm apresentado como alvo terapêutico principal intervenções genômicas relacionadas à expressão da proteína SMN. A possibilidade de alterar o código genético abriu portas para o desenvolvimento de medicamentos que modificam ou modulam a decodificação e transcrição do DNA.  
O nusinersena, o risdiplam e o onasemnogeno abeparvoveque são as alternativas medicamentosas disponíveis no Sistema Único de Saúde. A **utilização simultânea desses medicamentos não está preconizada neste Protocolo** devido à falta de evidências que demonstrem benefícios clínicos e segurança para os pacientes com essa associação<sup>40–50</sup> . O Quadro 3 descreve os tratamentos medicamentos preconizados por este Protocolo, conforme idade do paciente e tipo da AME 5q.  
Este Protocolo não preconiza o uso de nusinersena ou risdiplam por pacientes que iniciaram o tratamento com onasemnogeno abeparvoveque. Assim, deve-se interromper o uso de nusinersena ou risdiplam após a infusão do onasemnogeno abeparvoveque.  
Há relatos de uso de nusinersena em pacientes com AME tipo 1 após o uso de onasemnogeno abeparvoveque como  
tentativa de maximizar os benefícios alcançados no ganho motor, mesmo sem perda na função motora ou regressão percebida nas escalas motoras<sup>42,48</sup> . Contudo, o uso sequencial ou simultâneo de nusinersena ou risdiplam em relação ao onasemnoeno abeparvoveque (“pontes terapêuticas”) não são recomendadas neste Protocolo, **devido à falta de evidências disponíveis para avaliar os riscos e benefícios dessa estratégia** ..  
**Quadro 3 -** Tratamentos medicamentosos disponíveis, conforme idade do paciente e tipo da AME 5q.  
|**Idade do**||**Tipo da A**|**ME 5q**||
|---|---|---|---|---|
|**paciente**|**1a**|**1b**|**1c**|**2**|
|||onasemnogeno|onasemnogeno||
|Até 6 meses|onasemnogeno|abeparvoveque<sup>a</sup><br>OU|abeparvoveque<sup>a</sup><br>OU|nusinersena<br>OU|
||abeparvoveque<sup>a</sup>|nusinersena<br>OU|nusinersena<br>OU|<br>risdiplam|
|||risdiplam|risdiplam||
|Acima de 6||nusinersena|nusinersena|nusinersena|
|<br>|-|OU|OU|OU|
|meses||risdiplam|risdiplam|risdiplam|  
Nota: Devem ser observados os demais critérios de inclusão para uso dos medicamentos.  
 Para onasemnogeno abeparvoveque, o limite de 7 meses deve ser respeitado como data limite para infusão do medicamento.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **_Definição do tratamento medicamentoso_** -->
A escolha do tratamento medicamentoso, dentre os preconizados neste Protocolo, tem como princípio imprescindível o relatório médico detalhado sobre a indicação do melhor tratamento para cada paciente e a escolha da família/paciente, considerando seu bem estar, comodidade e preferência. Estes quesitos são preconizados pela humanização dos cuidados em saúde e devem considerar a literacia em saúde, colocando o indivíduo como protagonista de seu tratamento.  
Eventuais mudanças na conduta terapêutica entre os medicamentos nusinersena e risdiplam deverão ser realizadas considerando, da mesma forma, a participação e escolha da família/paciente, assim como as definições a seguir.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **_Mudança do tratamento de nusinersena para risdiplam_** -->
- **_Nos casos de pacientes que tenham iniciado o tratamento com nusinersena_** , o médico assistente poderá prescrever  
risdiplam, após preenchimento de relatório médico descrevendo os motivos para suspensão e troca de tratamento, dentre os seguintes problemas:  
- **_ocorrência de reações adversas graves_**<sup>a</sup> **_ao nusinersena_** que demandem a suspensão do tratamento;  
- **_evolução para contraturas graves ou de escoliose grave_** que, de acordo com o médico assistente, possam interferir  
na administração do medicamento, trazendo riscos para o paciente, evidenciados por radiografia ou outros exames de imagem;  
- **_surgimento de doença cerebral ou da medula espinhal_** que impeça a administração intratecal de medicamento ou a  
- circulação do líquido cefalorraquidiano;  
- **_necessidade de uso de derivação implantada_** para drenagem do líquido cefalorraquidiano ou de cateter de sistema  
> a As reações adversas graves incluem infecções graves, coagulação sanguínea alterada, função renal comprometida, sintomas de hipertensão intracraniana, cefaléia, náusea, vômitos, letargia e edema de papila, dor e febre, lesão do parênquima nervoso, hemorragia e outros sinais de acometimento do SNC, como vertigem, sonolência, irritabilidade e convulsões; outras reações não previstas que impeçam a administração continuada do medicamento.  
nervoso central implantado;  
 **_inefetividade do tratamento caracterizada pela regressão_** nos indicadores de mobilidade (escalas: CHOP INTEND - _Children’s Hospital Of Philadelphia Infant Test Of Neuromuscular Disorders_ ; ou HFMSE - _Hammersmith Functional Motor Scale — Expanded_ ) após 12 meses de tratamento ou antes deste prazo, a critério médico, considerando necessariamente o resultado após duas avaliações consecutivas.  Uma perda maior que 2 pontos será considerada regressão na escala de mobilidade.  
 **_não adesão ao tratamento_** por preferência do paciente ou familiar em função da via de administração. **_Mudança do tratamento de risdiplam para nusinersena_**  
- **_Nos casos de pacientes que iniciaram com risdiplam,_** o médico assistente poderá prescrever nusinersena, após apresentar relatório médico descrevendo os motivos para a suspensão e troca de medicamento, dentre os listados abaixo:  
 **_Ocorrência de eventos adversos_** que demandem a suspensão do tratamento;  
 **_Inefetividade do tratamento caracterizada pela regressão_** nos indicadores de mobilidade (escalas: CHOP INTEND - _Children’s Hospital Of Philadelphia Infant Test Of Neuromuscular Disorders_ ; ou HFMSE - _Hammersmith Functional Motor Scale — Expanded_ ) após 12 meses de tratamento ou antes deste prazo, a critério médico, considerando necessariamente, o resultado após duas avaliações consecutivas. Uma perda maior que 2 pontos será considerada regressão na escala de mobilidade.  
 **_não adesão ao tratamento_** por preferência do paciente ou familiar em função da via de administração.  
Em todas as situações para a substituição do tratamento medicamentoso, além do relatório médico, deve ser anexado e preenchido o questionário de avaliação clínica descrito previsto no Apêndice 1 (QUESTIONÁRIO - AVALIAÇÃO CLÍNICA DE PACIENTES COM AME 5Q TIPOS 1 e 2).  
Uma vez que a avaliação de inefetividade deve ser realizada após duas medidas sucessivas, o período de transição entre as doses para a troca por risdiplam ou nusinersena deve ser decidido a critério do médico assistente, observados o desenvolvimento e condições clínicas do paciente. Da mesma forma, quando da ocorrência de eventos adversos graves ou contraturas que impeçam o uso destes medicamentos, o período de transição entre as doses deve ser decidido também a critério do médico assistente, observados o desenvolvimento e condições clínicas do paciente. Em todas as situações o médico assistente e a familia devem considerar o menor prazo possível de interstício, a fim de evitar a progressão da doença.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Risdiplam** -->
O risdiplam é um modificador do splicing (maturação) do pré-mRNA de sobrevivência do neurônio motor 2 (SMN2) desenvolvido para tratar a AME. Ele interfere no splicing de SMN2 para deslocar o equilíbrio da exclusão do éxon 7 para a inclusão desse éxon no mRNA transcrito, promovendo um aumento na produção da proteína SMN funcional e estável. Assim, o risdiplam trata a AME aumentando e mantendo os níveis funcionais da proteína SMN.  O risdiplam se distribui de modo uniforme em todas as partes do corpo, incluindo o SNC, atravessando a barreira hematoencefálica e levando, assim, ao aumento da proteína SMN no SNC e em todo o corpo. As concentrações de risdiplam no plasma e da proteína SMN no sangue refletem sua distribuição e seus efeitos farmacodinâmicos em tecidos, como o cerebral e o muscular<sup>33</sup> .  
O peso corporal e a idade foram identificados como covariáveis na análise de farmacocinética populacional. Desse modo, a dose é ajustada com base na idade (abaixo e acima de 2 anos) e peso corporal (até 20 kg) para obter uma exposição semelhante entre as faixas de idade e peso corporal.  
O risdiplam é metabolizado principalmente por flavina monooxigenase 1 e 3 (FMO1 e FMO3) e também pelas CYPs 1A1, 2J2, 3A4 e 3A7. A administração concomitante de 200 mg de itraconazol duas vezes ao dia, um forte inibidor de CYP3A, com uma dose oral única de 6 mg de risdiplam não mostrou efeito clinicamente relevante na farmacocinética de risdiplam (aumento de 11% na ASC, redução de 9% na Cmáx)<sup>33</sup> .  
Ainda, risdiplam não é um substrato da proteína humana tipo 1 de resistência a múltiplos medicamentos (MDR1). Aproximadamente 53% da dose (14% de risdiplam inalterado) foram excretados nas fezes e 28% na urina (8% de risdiplam  
inalterado). O fármaco não metabolizado foi o principal componente encontrado no plasma, totalizando 83% do material relacionado ao fármaco na circulação, enquanto o metabólito farmacologicamente inativo M1 foi identificado como o principal metabólito circulante<sup>33</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Nusinersena** -->
O nusinersena é um oligonucleotídeo anti-sentido que permite a inclusão do éxon 7 durante o processamento do ácido ribonucleico mensageiro (RNAm) de _SMN2_ , transcrito a partir do ácido desoxirribonucleico (DNA) do gene _SMN2_ . O oligonucleotídeo nusinersena atua ligando-se, de maneira anti-sentido ao RNAm de _SMN2_ , em um sítio de silenciamento e remoção intrônica presente no intron 7. Portanto, por ligação perfeita à região intrônica 7, o nusinersena impede que os fatores de silenciamento/remoção intrônico processem e removam o éxon 7 do RNAm de _SMN2_ . A retenção do éxon 7 no RNAm de _SMN2_ permite a leitura e tradução correta dessa molécula, levando à produção da proteína funcional relacionada com a sobrevivência do neurônio motor, a proteína _SMN_<sup>2</sup> .  
Dados obtidos de autópsias de pacientes (n = 3) com AME mostraram que o nusinersena administrado por via intratecal é amplamente distribuído ao longo do SNC, atingindo concentrações terapêuticas nos tecidos-alvo (medula espinhal). A farmacocinética das doses administradas por via intratecal (IT) foi determinada em pacientes pediátricos diagnosticados com AME<sup>53</sup> . A concentração média no líquido cefalorraquidiano (LCR) do nusinersena foi verificada aproximadamente 1,4 a 3 vezes, após múltiplas doses de indução e manutenção, atingindo o estado estacionário em aproximadamente 24 meses. Nenhum acúmulo adicional nos tecidos do SNC ou no LCR é esperado com doses adicionais após atingir o estado estacionário. Após administração IT, as concentrações plasmáticas do nusinersena foram relativamente baixas quando comparadas com a concentração observada no LCR<sup>52</sup> .  
O nusinersena é metabolizado lentamente pela via da hidrólise mediada por exonucleases e não é um substrato, inibidor ou indutor do complexo enzimático citocromo P450 (CYP450). A meia-vida de eliminação terminal no LCR foi estimada entre 135 e 177 dias. A provável via de eliminação é por excreção urinária do nusinersena e seus respectivos metabólitos<sup>52</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Onasemnogeno abeparvoveque** -->
O onasemnogeno abeparvoveque é uma terapia gênica baseada em um vetor do AAV9 que contém uma codificação transgênica correta da proteína humana SMN. A terapia utiliza o capsídeo do sorotipo 9 de um vírus adeno-associado (AAV9) para fornecer uma cópia totalmente funcional do SMN, o gene que tem como função codificar a proteína SMN humana.  
O vetor AAV9 demonstrou capacidade em atravessar a barreira hematoencefálica<sup>27,54</sup> . Dados obtidos por meio de autópsia de dois pacientes com AME tipo 1 que participaram do ensaio clínico de fase III demonstraram ampla biodistribuição de genomas do vetor onasemnogeno abeparvoveque, bem como a transcrição de RNAm e proteína SMN após administração intravenosa<sup>55</sup> .  
O DNA do vetor foi detectado na saliva, na urina e nas fezes, em baixas concentrações no 1° dia após a infusão do onasemnogeno abeparvoveque e diminuiu até níveis indetectáveis em 3 semanas<sup>35,55</sup> . A concentração do DNA do vetor foi considerada muito baixa no 1º dia após a infusão e diminuiu até níveis indetectáveis em 1 a 2 semanas. A concentração do DNA do vetor nas fezes foi superior ao encontrado na saliva e urina durante a primeira e segunda semana após infusão do medicamento. Observou-se redução a níveis indetectáveis em 1 a 2 meses após a infusão<sup>55</sup> .  
Crianças que utilizarão onasemnogeno abeparvoveque deverão aguardar a suspensão do uso de corticoides para realização de imunização com vacinas virais vivas ou outras que sejam contraindicadas neste contexto. A vacinação em pacientes em uso de corticoides, imunossuprimidos, pode resultar em eventos adversos graves. É importante ressaltar que a vacinação é segura quando administrada de forma correta após o término do período de uso dos corticoides.  
**6.2.1   Medicamentos**  
- Nusinersena: solução injetável de 2,4 mg/mL;  
- Onasemnogeno abeparvoveque: 2,0 × 10<sup>13</sup> gv/mL<sup>b</sup> ;  
- Risdiplam: pó para solução oral de 0,75 mg/mL.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Risdiplam** -->
<u>O risdiplam pó para solução oral deve ser constituído por um profissional de saúde antes de ser dispensado</u><sup>56</sup> . A constituição do medicamento é um requisito para sua dispensação. A farmácia encarregada de realizar a constituição da solução oral deve atender aos padrões de boas práticas recomendados pelas normas da Anvisa. Os procedimentos operacionais para constituição da solução oral, data de validade, armazenamento e outras instruções relevantes a serem repassadas às famílias e pacientes para administração da solução de risdiplam encontram-se na bula fornecida pelo fabricante.  
O medicamento deve ser administrado por via oral uma vez ao dia, aproximadamente no mesmo horário todos os dias, utilizando a seringa oral fornecida. A dose diária recomendada de risdiplam para pacientes com AME é determinada pela idade e peso corporal (Quadro 4)<sup>56</sup> .  
**Quadro 4** - Esquema de dose de risdiplam conforme idade e peso corporal do paciente.  
|**Idade e peso corporal**|**Dose diária recomendada**|
|---|---|
|< 2 meses de idade|0,15 mg/kg|
|2 meses a < 2 anos de idade|0,20 mg/kg|
|≥ 2 anos de idade (< 20 kg)|0,25 mg/kg|
|≥ 2 anos de idade (≥ 20 kg)|5 mg|  
**Fonte:** Bula Evrysdi (2023).  
Mudanças na dose devem ser realizadas sob a supervisão do médico assistente. Atenção especial deve ser dada aos pacientes em função do ganho ou perda de peso, por sua condição clínica ou faixa etária. **_Recomenda-se o ajuste de dose, pelo menos uma vez ao mês, até o paciente atingir 20 kg, em função da curva de ganho de peso na infância_** (lactente: 29 dias a 2 anos de idade; pré-escolar: 2 a 6 anos de idade e escolar). Doses maiores que 5 mg não foram estudadas e não são recomendadas.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Nusinersena** -->
O medicamento deve ser administrado por profissional médico habilitado para realizar o procedimento de administração intratecal por punção lombar. Técnicas assépticas devem ser utilizadas durante a preparação e administração do nusinersena<sup>53</sup> Recomenda-se que seja aspirado o mesmo volume de LCR, antes da administração do nusinersena<sup>53</sup> .  
- <u>Fase inicial: Nas três primeiras doses devem ser administrados 12 mg de nusinersena, por via intratecal, a cada 14 dias</u> (dias 0, 14 e 28). A quarta dose deve ser administrada 30 dias após a terceira, desde que a criança tenha condições clínicas de receber o medicamento.  
- <u>Fase de manutenção: 12 mg de nusinersena administrado por via intratecal a cada quatro meses.</u>  
É importante ressaltar que este Protocolo não preconiza ajuste de dose de nusinersena, visto que não foram identificadas evidências sobre eficácia, efetividade ou segurança de esquemas posológicos diferentes do preconizado em bula.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Onasemnogeno abeparvoveque** -->
b gv/mL = corresponde a quantidade de genomas virais por mL.  
O medicamento deve ser administrado por um profissional de saúde, em perfusão intravenosa de dose única. Uma resposta imunológica ao capsídeo do vetor AAV9 ocorrerá após a administração da terapia gênica, portanto, **os pacientes não devem ser infundidos mais de uma vez com onasemnogeno abeparvoveque** .  
Os procedimentos para preparação e manuseio do onasemnogeno abeparvoveque e outras informações importantes, como armazenamento e precauções, encontram-se na bula fornecida pelo fabricante.  
A dose recomendada do onasemnogeno abeparvoveque é 1,1x10<sup>14</sup> genomas virais por kg (gv/kg) (Quadro 5).  
**Quadro 5** - Dose recomenda para administração do onasemnogeno abeparvoveque  
|**Faixa de peso do paciente (kg)**|**Dose (gv)**|**Volume da dose (mL)**|
|---|---|---|
|2,6 – 3,0|3,3 × 10<sup>14</sup>|16,5|
|3,1 – 3,5|3,9 × 10<sup>14</sup>|19,3|
|3,6 – 4,0|4,4 × 10<sup>14</sup>|22,0|
|4,1 – 4,5|5,0 × 10<sup>14</sup>|24,8|
|4,6 – 5,0|5,5 × 10<sup>14</sup>|27,5|
|5,1 – 5,5|6,1 × 10<sup>14</sup>|30,3|
|5,6 – 6,0|6,6 × 10<sup>14</sup>|33,0|
|6,1 – 6,5|7,2 × 10<sup>14</sup>|35,8|
|6,6 – 7,0|7,7 × 10<sup>14</sup>|38,5|
|7,1 – 7,5|8,3 × 10<sup>14</sup>|41,3|
|7,6 – 8,0|8,8 × 10<sup>14</sup>|44,0|
|8,1 – 8,5|9,4 × 10<sup>14</sup>|46,8|
|8,6 – 9,0|9,9 × 10<sup>14</sup>|49,5|
|9,1 – 9,5|1,05 × 10<sup>15</sup>|52,3|
|9,6 – 10,0|1,10 × 10<sup>15</sup>|55,0|
|10,1 – 10,5|1,16 × 10<sup>15</sup>|57,8|
|10,6 – 11,0|1,21 × 10<sup>15</sup>|60,5|
|11,1 – 11,5|1,27 × 10<sup>15</sup>|63,3|
|11,6 – 12,0|1,32 × 10<sup>15</sup>|66,0|
|12,1 – 12,5|1,38 × 10<sup>15</sup>|68,8|  
|**Faixa de peso do paciente (kg)**|**Dose (gv)**|**Volume da dose (mL)**|
|---|---|---|
|12,6 – 13,0|1,43 × 10<sup>15</sup>|71,5|
|13,1 – 13,5|1,49 × 10<sup>15</sup>|74,3|
|13,6 – 14,0|1,54 x 10<sup>15</sup>|77|
|14,1 – 14,5|1,60 x 10<sup>15</sup>|79,8|
|14,6 – 15,0|1,65 x 10<sup>15</sup>|82,5|
|15,1 – 15,5|1,71 x 10<sup>15</sup>|85,3|
|15,6 – 16,0|1,76 x 10<sup>15</sup>|88|
|16,1 – 16,5|1,82 x 10<sup>15</sup>|90,8|
|16,6 – 17,0|1,87 x 10<sup>15</sup>|93,5|
|17,1 – 17,5|1,93 x 10<sup>15</sup>|96,3|
|17,6 – 18,0|1,98 x 10<sup>15</sup>|99|
|18,1 – 18,5|2,04 x 10<sup>15</sup>|101,8|
|18,6 – 19,0|2,09 x 10<sup>15</sup>|104,5|
|19,1 – 19,5|2,15 x 10<sup>15</sup>|107,3|
|19,6 – 20,0|2,20 x 10<sup>15</sup>|110|
|20,1 – 20,5|2,26 x 10<sup>15</sup>|112,8|
|20,6 – 21,0|2,31 x 10<sup>15</sup>|115,5|  
**NOTA** :  O volume da dose é calculado usando o limite superior da variação de peso corporal do paciente para pacientes pediátricos com menos de 2 anos de idade entre 2,6 kg e 21,0 kg<sup>35</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Risdiplam** -->
Devido aos efeitos reversíveis de risdiplam na fertilidade masculina com base nas observações de estudos em animais, os pacientes do sexo masculino não devem doar esperma durante o tratamento e por 4 meses após a última dose. Os pacientes do sexo masculino que desejarem ter filhos devem interromper o tratamento com risdiplam por, no mínimo, 4 meses. O tratamento pode ser reiniciado após a concepção. As pacientes do sexo feminino com potencial para engravidar devem utilizar contracepção altamente eficaz durante o tratamento com risdiplam e por no mínimo 1 mês após a última dose<sup>56</sup> .  
**_Risdiplam demonstrou ser embriofetotóxico e teratogênico em animais._** Não há dados clínicos sobre o seu uso em mulheres grávidas. Portanto, o uso de risdiplam durante a gestação deve ser evitado, uma vez que está incluído na categoria de risco C para gravidez. **_Além disso, não é recomendado o uso de risdiplam durante o período de lactação._** Apesar de não haver  
informações sobre a excreção do medicamento no leite materno humano, estudos em ratos demonstraram que o risdiplam é excretado no leite<sup>56</sup> .  
Por meio de um estudo clínico, verificou-se que, em pacientes com insuficiência hepática leve ou moderada, não houve impacto na farmacocinética, segurança e tolerabilidade de uma dose única de 5 mg de risdiplam, não sendo necessário o ajuste de doses para esses pacientes<sup>56</sup> . O risdiplam não foi estudado em pacientes com insuficiência renal, insuficiência hepática grave e com idade superior a 60 anos<sup>56</sup> .  
<u>Instruções para constituição do risdiplam</u>  
O pó para solução de risdiplam deve ser manuseado cuidadosamente por um profissional de saúde e deve ser dispensado ao paciente, após a constituição para solução oral. A inalação e o contato direto da pele ou membranas mucosas com o pó seco e a solução constituída devem ser evitados. O procedimento de constituição deve ser realizado com a utilização de luvas descartáveis, que também devem ser utilizadas na limpeza da superfície externa do frasco ou tampa e da superfície de trabalho após a constituição. Se houver contato, a área deve ser lavada completamente com água e sabão. Se este contato ocorrer com os olhos, eles devem ser lavados com água<sup>56</sup> .  
Caso o pó esteja com data de validade vencida, o mesmo não deve ser utilizado. A solução constituída não deve ser dispensada se a data de “descartar a solução constituída após dia/mês/ano” exceder a data de validade original do pó. O medicamento não deve ser utilizado se algum dos suprimentos estiver danificado ou faltando. É necessário o uso de água purificada ou água estéril para injeção para constituir o medicamento.  
Seringas orais que não sejam as fornecidas nas embalagens não devem ser adicionadas. O pó (medicamento não constituído) deve ser mantido no cartucho e armazenado sob refrigeração entre 2 e 8 °C. A solução com medicamento constituído, também deve ser armazenada entre 2 a 8 °C e deve ser mantida no frasco original, sempre em posição vertical e com a tampa bem fechada. Manter no frasco âmbar original para proteger da luz. Após constituída, a solução possui prazo de validade de 64 dias. Orientações adicionais e instruções sobre a forma de constituição e forma de administração estão disponíveis na bula do medicamento<sup>56</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Nusinersena** -->
Ultrassonografia ou outros exames de imagem podem ser usados para orientar a colocação da agulha espinhal, particularmente em pacientes mais jovens ou naqueles que possam necessitar de punção cervical guiada por imagem<sup>53,57</sup> .  
O uso de medicamentos anticoagulantes e antiplaquetários, como o ácido acetilsalicílico (AAS), deve ser evitado. Se indicado, recomenda-se a contagem de plaquetas, coagulograma completo e pesquisa de proteína na urina, preferencialmente usando-se amostra correspondente ao primeiro jato de urina da manhã, antes da administração de nusinersena. Em caso de persistência de proteinúria elevada, deve-se proceder a uma avaliação clínica e laboratorial mais completa.  
O nusinersena não foi estudado em pacientes com insuficiência renal, insuficiência hepática e com idade superior a 65 anos<sup>53</sup> .  
Mulheres grávidas ou que possam engravidar durante o tratamento devem evitar o uso de nusinersena, pois o medicamento se inclui na categoria de risco C para gravidez.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Onasemnogeno abeparvoveque** -->
A fim de controlar uma possível elevação dos níveis de aminotransferases hepáticas, todos os pacientes devem receber corticoide sistêmico, administrado por via oral um dia antes e diariamente até 30 dias depois da administração do onasemnogeno abeparvoveque. Recomenda-se o uso de prednisolona 1 mg/kg/dia ou equivalente, caso outro corticoide seja utilizado<sup>35</sup> . Antes da infusão, recomenda-se ainda o monitoramento da função hepática a partir dos níveis de parâmetros como ALT, AST, bilirrubina total, albumina, tempo de protrombina, PTT e RNI<sup>35</sup> (Quadro 6).  
Caso o indivíduo apresente função hepática normal, a dose de corticoide deve ser reduzida gradualmente ao longo dos 28 dias seguintes à infusão. Essa redução não deve ser considerada até que os níveis de ALT e AST se apresentem menores que duas vezes o limite superior de normalidade. Os corticoides sistêmicos não devem ser interrompidos abruptamente. A função hepática a partir dos níveis de ALT, AST e bilirrubina total devem ser monitorados por pelo menos 3 meses após a infusão e em outros momentos, conforme indicação clínica. Durante o mês seguinte à infusão do medicamento e durante a etapa de redução gradual do corticoide, o monitoramento deve ocorrer semanalmente. Se o paciente se encontrar clinicamente estável e com achados normais ao final do período de redução gradual do corticoide, o monitoramento da função hepática deve ser mantido, sendo realizado a cada duas semanas por mais um mês<sup>35</sup> .  
Em caso de anormalidade na função hepática, o uso de corticoide sistêmico deve ser prolongado até que os valores de ALT e AST reduzam abaixo de duas vezes o limite superior de normalidade. Em seguida, a dose de corticoide deve ser reduzida gradualmente ao longo dos 28 dias seguintes. Na suspeita de lesão hepática, testes adicionais, como albumina, tempo de protrombina, PTT e RNI, são recomendados<sup>35</sup> .  
Avaliações clínicas gastroenterológicas pediátricas ou hepatológicas devem ser realizadas se o paciente não responder adequadamente a 1 mg/kg/dia de prednisolona oral ou equivalente. Corticoides intravenosos podem ser considerados como uma indicação clínica no caso de não tolerabilidade a corticoterapia oral<sup>35</sup> . O onasemnogeno abeparvoveque deve ser considerado com cautela em pacientes com insuficiência hepática<sup>35</sup> .  
O onasemnogeno abeparvoveque deve ser administrado em infusão intravenosa por meio de um cateter primário em uma veia periférica. A infusão do medicamento deve ocorrer por meio de uma bomba de seringa com infusão intravenosa lenta por 60 minutos. O medicamento não deve ser administrado na forma de injeção intravenosa rápida ou em bolus<sup>35</sup> . Após a administração do medicamento, lavar o sistema de infusão com solução salina<sup>35</sup> .  
Uma resposta imunológica ao capsídeo do vetor do AAV9 ocorrerá após a administração do onasemnogeno abeparvoveque, portanto, os pacientes não devem ser infundidos novamente com onasemnogeno abeparvoveque<sup>35</sup> . **_O tratamento_**

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **_com onasemnogeno abeparvoveque consiste em uma dose única_**<sup>**_35_**</sup> **_._** -->
Antes de iniciar o uso com onasemnogeno abeparvoveque é necessário avaliar a presença de infecção viral ativa, incluindo vírus da imunodeficiência humana (HIV) ou sorologia positiva para hepatite B ou C, ou Zika vírus, dentre outros. O uso do medicamento deve ser adiado em pacientes com infecções ativas até que o quadro seja solucionado e o paciente esteja clinicamente estável<sup>35</sup> .  
Diante dos eventos adversos relacionados ao uso do onasemnogeno abeparvoveque, recomenda-se o monitoramento de parâmetros laboratoriais antes e após administração do medicamento, conforme descrito no Quadro 6.  
**Quadro 6** - Parâmetros laboratoriais que devem ser acompanhados após infusão do onasemnogeno abeparvoveque  
|**Exame**|**Pré-infusão**|**Pós-infusão**|**Frequência e duração**|
|---|---|---|---|
||||Uma vez, na pré-infusão. Semanalmente, no primeiro|
|ALT, AST e bilirrubina<br>total|X|X|mês após infusão.<br>A cada duas semanas no segundo e terceiro mês após a|
||||infusão.|
||||Semanalmente no primeiro mês após infusão.|
|Contagem de plaquetas|X|X|A cada duas semanas no segundo e terceiro mês após a<br>infusão|  
|**Exame**|**Pré-infusão**|**Pós-infusão**|**Frequência e duração**|
|---|---|---|---|
|Troponina I|X|X|Uma vez, na pré-infusão. Semanalmente, no primeiro<br>mês após infusão.<br>A cada duas semanas no segundo e terceiro mês após a|
||||infusão|
|Teste de anticorpos AAV9|X|-|Uma única vez, antes da infusão|
|Creatina|X|-|Uma única vez, antes da infusão|
|Hemograma completo|X|-|Uma única vez, antes da infusão|  
**Fonte** : adaptado de Zolgensma, 2022<sup>35</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **6.2.4  Eventos adversos** -->
O tratamento para AME contempla terapias inovadoras. Como todo tratamento inovador, a notificação de eventos adversos é extremamente importante para estabelecer ações corretivas e preventivas. Os eventos adversos observados com o uso de risdiplam, nusinersena ou onasemnogeno abeparvoveque devem ser registrados no formulário de notificação de eventos adversos a medicamentos e vacinas da Anvisa. Para notificar, não é necessário ser profissional de saúde. Todavia, os profissionais de saúde, como médicos, farmacêuticos e enfermeiros diretamente envolvidos com a prescrição, dispensação e administração dos medicamentos, têm maior possibilidade de perceber e notificar eventos adversos. Qualquer cidadão pode realizar a notificação por meio de sistema eletrônico específico para essa conforme disponível no endereço eletrônico a seguir: **https://www.gov.br/anvisa/pt-br/assuntos/fiscalizacao-e-monitoramento/notificacoes/vigimed.**

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Risdiplam** -->
Os eventos adversos  que ocorreram em uma frequência igual ou maior a 5% dos indivíduos foram diarreia e exantema cutâneo. Contudo, estes eventos ocorreram sem um período identificável ou padrão clínico e foram resolvidos sem a necessidade de interrupção do tratamento<sup>56</sup> .

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Nusinersena** -->
Os EA (eventos adversos) mais comumente associados à administração intratecal de nusinersena foram dor de cabeça, vômitos e dor lombar. A maioria destes eventos foi relatada no período de 72 horas após o procedimento. Não foram observadas complicações graves relacionadas - como infecções graves - durante os estudos clínicos. Entretanto, na pós-comercialização, foram relatados EA, incluindo complicações como infecções graves<sup>58</sup> .  
Por sua vez, a administração inadvertida por vias subcutânea ou intravenosa pode levar à trombocitopenia e anormalidades da coagulação sanguínea e toxicidade renal.  
Deve-se dar especial atenção à coagulação sanguínea, à função renal e aos sintomas e sinais de hipertensão intracraniana (cefaleia, náusea, vômitos, letargia e edema de papila) e outras complicações, como lesão do parênquima nervoso (dor lombar, rigidez de nuca, paresia ou mesmo paralisia), dor e febre devidas à infecção, hemorragia e outros sinais de acometimento do SNC, como vertigem, sonolência, irritabilidade e convulsões.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Onasemnogeno abeparvoveque** -->
A administração do onasemnogeno abeparvoveque pode resultar em elevação das aminotransferases. Indivíduos com  
lesão hepática ou infecção viral hepática aguda pré-existente apresentam um risco maior de lesão hepática grave/insuficiência hepática aguda.  
Em geral, as reações adversas com frequência maior que 5% após a administração do onasemnogeno abeparvoveque foram aumento dos níveis da aspartato aminotransferase, da alanina aminotransferase e das transaminases, vômitos, trombocitopenia, aumento dos níveis de troponina e da gama-glutamiltransferase e pirexia.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Risdiplam** -->
Os critérios de interrupção devem ser apresentados, de forma clara, aos indivíduos, pais ou responsáveis legais. As seguintes situações indicam a interrupção do uso de risdiplam:  
a) Ausência de benefício clínico associado ao tratamento, evidenciada por evolução para necessidade de ventilação mecânica invasiva por 24 horas por dia, continuamente, por período igual ou superior a 90 dias;  
- b) Hipersensibilidade ou reação adversa grave ao risdiplam;  
c) Regressão nos indicadores de mobilidade (escalas: CHOP INTEND ou HFMSE) após 12 meses de tratamento ou antes deste prazo, a critério médico, considerando necessariamente o resultado após duas avaliações consecutivas. Uma perda maior que 2 pontos será considerada regressão nos indicadores de mobilidade;  
- d) Gravidez ou lactação, pois o medicamento demonstrou ser embriofetotóxico, teratogênico, sendo excretado no leite  
- em estudos com modelos animais;  
e) Decisão do responsável legal ou indivíduo, após ser devidamente informado sobre os riscos e benefícios da sua decisão de não mais utilizar o tratamento medicamentoso.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Nusinersena** -->
Os critérios de interrupção devem ser apresentados, de forma clara, aos indivíduos, pais ou responsáveis legais. As seguintes situações indicam a interrupção do uso de nusinersena:  
a) Ausência de benefício clínico associado ao tratamento, evidenciada por evolução para necessidade de ventilação mecânica invasiva permanente por 24 horas de ventilação por dia, continuamente, por período igual ou superior a 90 dias;  
- b) Hipersensibilidade ou reação adversa grave ao nusinersena;  
c) Regressão nos indicadores de mobilidade (escalas: CHOP INTEND ou HFMSE) após 12 meses de tratamento ou antes deste prazo, a critério médico, considerando necessariamente o resultado após duas avaliações consecutivas. Uma perda maior que 2 pontos será considerada regressão na escala de mobilidade;  
d) Desenvolvimento de doença cerebral ou da medula espinhal que impeça a administração intratecal do medicamento ou a circulação do líquido cefalorraquidiano;  
- e) Presença de implante de derivação para drenagem do líquido cefalorraquidiano ou de cateter de SNC;  
- f) Gravidez ou lactação. O medicamento não deve ser utilizado por mulheres grávidas ou que possam engravidar durante  
- o tratamento;  
g) Decisão do responsável legal ou indivíduo, após ser devidamente informado sobre os riscos e benefícios da sua decisão de não mais utilizar o tratamento medicamentoso.  
A insuficiência respiratória que demande suporte ventilatório contínuo por outras causas não é considerada critério de suspensão do medicamento da AME 5q tipos 1 e 2.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Onasemnogeno abeparvoveque** -->
Por tratar-se de um medicamento de dose única, os critérios de interrupção não se aplicam ao onasemnogeno abeparvoveque. Uma resposta imunológica ao capsídeo do vetor do AAV9 ocorrerá após a administração do onasemnogeno abeparvoveque, portanto, os indivíduos não devem ser infundidos novamente com onasemnogeno abeparvoveque<sup>35</sup> . **_O tratamento com onasemnogeno abeparvoveque consiste em uma dose única_**<sup>**_35_**</sup> **_._**

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Risdiplam** -->
- AME 5q tipo 1: melhora definida como aumento global de 3 pontos ou mais, em pelo menos uma categoria da escala CHOP INTEND ou HMFSE, ou seja, um aumento na pontuação para controle da cabeça, rolamento, sentar, engatinhar, ficar em pé ou andar, e ter mais categorias com melhora do que piora;  
- AME 5q tipo 2: melhora definida como aumento global de 3 pontos ou mais na escala HFMSE e ter mais categorias  
- com melhora do que piora;  
- AME 5q tipo 1 e 2: estabilização da função motora definida como manutenção da pontuação nas escalas CHOP  
- INTEND ou HFMSE, em relação à linha de base, ou seja, antes do início do uso de risdiplam, e mantida durante todo o período de tratamento<sup>59–61</sup> ;  
Além dos benefícios expostos anteriormente, deve ser monitorada a ocorrência de efeitos adversos no aparelho respiratório, como pirexia, infecção do trato respiratório, tosse, pneumonia e desconforto respiratório<sup>56</sup> .  
Para avaliar os benefícios do tratamento para os indivíduos, os resultados de efetividade e segurança do risdiplam devem ser medidos, utilizando-se o Questionário para Avaliação Clínica de Paciente com AME 5q tipo 1 ou 2 ( **Apêndice 1** ), o qual deve ser anexado à solicitação deste medicamento às unidades de saúde responsáveispor autorizar o tratamento.  
Ao médico assistente cabe definir outros exames, além do exame físico, incluindo o neurológico, para a avaliação do resultado terapêutico em diferentes períodos, de acordo com a evolução clínica do indivíduo.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Nusinersena** -->
- AME 5q tipo 1: melhora definida como aumento global de 3 pontos ou mais em pelo menos uma categoria da escala CHOP INTEND ou HMFSE, ou seja, um aumento na pontuação para controle da cabeça, rolamento, sentar, engatinhar, ficar em pé ou andar, e ter mais categorias com melhora do que piora;  
- AME 5q tipo 2: melhora definida como aumento global de 3 pontos ou mais na escala HFMSE e ter mais categorias  
- com melhora do que piora;  
- AME 5q tipo 1 e 2: estabilização da função motora definida como manutenção da pontuação nas escalas CHOP  
- INTEND ou HFMSE, em relação à linha de base, ou seja, antes do início do uso de nusinersena, e mantida durante todo o período de tratamento<sup>8,62</sup> ;  
Além destes benefícios, deve ser também monitorada a ocorrência de infecção das meninges (meningite) após o início do tratamento com nusinersena, pois trata-se de um evento adverso grave que necessita de intervenção imediata. Este evento pode estar potencialmente relacionado com o medicamento ou com o procedimento de administração.  
Para avaliar os benefícios do tratamento para os indivíduos, os resultados de efetividade e segurança do nusinersena devem ser medidos, utilizando-se o Questionário para Avaliação Clínica de Paciente com AME 5q tipo 1 ou 2 ( **Apêndice 1** ), o qual deve ser anexado à solicitação deste medicamento às unidades de saúde responsáveis por autorizar o tratamento.  
Ao médico assistente cabe definir outros exames, além do exame físico, incluindo o neurológico, para a avaliação do resultado terapêutico em diferentes períodos, de acordo com a evolução clínica do indivíduo.  
**Onasemnogeno abeparvoveque**  
Os benefícios esperados com o onasemnogeno abeparvoveque em indivíduos com AME 5q tipo 1 são:  
- **Três meses após infusão:** ganho de pelo menos 10 pontos na escala CHOP INTEND quando comparado à linha de base  
- (antes do início do tratamento)<sup>63–65</sup> .  
- **Seis meses após infusão:** ganho de pelo menos 13 pontos na escala CHOP INTEND quando comparado à linha de base  
- (antes do início do tratamento)<sup>63–65</sup> .  
- AME 5q tipo 1: melhora definida como a manutenção da pontuação na escala CHOP INTEND acima de 40 pontos,  
- quando comparado à linha de base (antes do início do tratamento)<sup>66</sup> .  
- Ausência de necessidade de ventilação permanente, definida como traqueostomia ou a necessidade de 16h ou mais de  
- suporte ventilatório<sup>42,67</sup> .  
- Não regredir na função motora atingida (sustentar a cabeça, sentar, ficar de pé ou andar) após a infusão do onasemnogeno  
- abeparvoveque ou a linha de base (antes do início do tratamento).  
- Alcance da capacidade de sentar por pelo menos 30 segundos até 36 meses<sup>68</sup> .  
Além dos benefícios expostos anteriormente, deve ser monitorada a ocorrência de efeitos adversos, principalmente relacionados à hepatotoxicidade imunomediada, elevação de enzimas hepáticas, trombocitopenia e elevação da troponina I.  
Para avaliar os benefícios do tratamento para os indivíduos, os resultados de efetividade e segurança do onasemnogeno abeparvoveque devem ser relatados pelo médico assistente, utilizando-se o Questionário para Avaliação Clínica de Paciente com AME 5q tipo 1 ( **Apêndice 1** ).  
Ao médico assistente cabe definir outros exames, além do exame físico, incluindo o neurológico, para a avaliação do resultado terapêutico em diferentes períodos, de acordo com a evolução clínica do paciente.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **7.        MONITORAMENTO** -->
O acompanhamento do uso dos medicamentos nusinersena, risdiplam ou onasemnogeno abeparvoveque por pacientes com AME 5q tipos 1 ou 2 deve ser realizado com o objetivo de avaliar o desempenho da tecnologia (resultado terapêutico) em termos de benefícios obtidos, em vida real, para os pacientes com medidas da efetividade clínica e segurança.  
O fornecimento do nusinersena, risdiplam ou onasemnogeno abeparvoveque está vinculado à avaliação da sua efetividade e segurança no SUS. A avaliação de desempenho se dará pela mensuração da efetividade e segurança do tratamento periodicamente, por meio de medidas de função motora, cardiorrespiratória, gastrointestinal e nutricional, por meio de questionário clínico a ser anexado à solicitação destes medicamentos, bem como avaliação do perfil de eventos adversos (Quadro 7).  
Antes do início do uso dos medicamentos preconizados neste Protocolo, devem ter sido avaliados os dados sociodemográficos do paciente e seu histórico de saúde, bem como os resultados de exames laboratoriais.  
Esses exames e o _Questionário - Avaliação Clínica de Pacientes Com AME 5q Tipos 1 e 2_ deverão ser apresentados para o fornecimento dos medicamentos, observando a sua periodicidade. As avaliações clínicas para o monitoramento dos pacientes deverão ser realizadas a cada três meses, conforme os Quadros 7 e 8.  
Como a administração intratecal de nusinersena atinge principalmente os neurônios motores e há dúvidas quanto às disfunções pela deficiência da proteína SMN em outros sítios anatômicos, a exemplo do sistema cardiovascular, os pacientes tratados com nusinersena devem ser monitorados de forma integral, considerando-se os demais sistemas orgânicos, a coagulação sanguínea e a função renal.  
Para os pacientes em uso de **<u>onasemnogeno abeparvoveque</u>** <u>, o esquema de monitoramento clínico e parâmetros</u> laboratoriais devem seguir os Quadros 6 e 7  deste Protocolo. Além disso, para fins de cumprimento ao disposto no Acordo de Compartilhamento de Risco celebrado entre o Ministério da Saúde e a empresa que detém o registro da terapia gênica no país,  
equipes e serviços de estabelecimentos de saúde especificamente habilitados pelo Ministério da Saúde devem realizar o monitoramento conforme o disposto no Acordo e em instruções estabelecidas por documentos complementares a este PCDT, inclusive por meio de palataforma provida por este Ministério para a coleta de dados clínicos dos pacientes que tiverem acesso à terapia gênica.  
**Quadro 7** - Esquema de monitoramento clínico dos pacientes com AME 5q tipos 1 e 2 – medicamentos risdiplam; nusinersena e onasemnogeno abeparvoveque.  
|**Avaliações**|**Avaliação inicial**|**A cada 3 meses**|
|---|---|---|
|Exame genético confirmatório|**X**||
|**qPCR ou MLPA ou NGS**|||
|Situação vacinal<br>_calendário vacinal vigente no SUS_|**X**|**X**|
|Titulação de anticorpo AAV9_(apenas para uso do_<br>_onasemnogeno abeparvoveque)_|**X**||
|Função respiratória|**X**|**X**|
|**Saturação de Oxigênio**|||
|Condição nutricional|||
|**Peso**|**X**|**X**|
|**Medidas antropométricas**|**X**|**X**|
|Função motora*|**X**|**X**|
|Escala CHOP INTEND*|||
|Escala HFMSE*|||
|Questionário Clínico e Desenvolvimento Motor|**X**|**X**|  
**Legenda** : *O médico assistente deve escolher a escala adequada a faixa de idade e condição motora do paciente. Os pacientes com AME tipo 1 em uso do onasemnogeno abeparvoveque devem iniciar pela escala CHOP INTEND.  
Para o fornecimento do medicamento, o médico assistente deverá apresentar _Questionário - Avaliação Clínica de Pacientes Com AME 5q Tipos 1 e 2,_ onde descreverá a condição motora do paciente, a fim justificar a escolha da escala que melhor se adequa ao caso clínico. Também deverá ser apresentado o formulário utilizado com os resultados da aplicação da escala de função motora escolhida. A escala utilizada na avaliação inicial deverá ser mantida nos processos subsequentes de renovação da solicitação de dispensação do medicamento.  
As escalas para avaliação dos marcos de desenvolvimento motor deverão ser aplicadas de acordo os seguintes critérios<sup>69</sup> :

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **ESCALA CHOP INTEND** -->
A escala CHOP INTEND foi desenvolvida para ser usada em crianças de 3 meses a 4 anos, embora não se limite a essa faixa etária. Ela **_foi desenvolvida observando bebês com AME tipo 1._** Existem 16 itens e a escala avalia como as crianças podem executar certos movimentos. Cada item é pontuado de 0 a 4, com 0 indicando ‘nenhuma resposta’ e 4 indicando 'resposta completa', ou seja, capaz de realizar a tarefa. A pontuação total possível é 64. A escala CHOP INTEND pode ser utilizada em:  
- pacientes menores de 2 anos de idade;  
- pacientes maiores de 2 anos de idade e sem capacidade de sentar.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **ESCALA HFMSE** -->
A escala HFMSE foi desenvolvida para observar o desenvolvimento de crianças que têm AME tipo 2 e crianças e adultos  
que têm AME tipo 3. Isso significa que **_pode ser usada por períodos mais longos e para aqueles que se tornaram incapazes de andar_** . A HMFSE inclui 33 itens que se relacionam com a capacidade de sentar, rolar, rastejar, ficar em pé, andar, pular e até mesmo subir escadas. Cada item do teste é pontuado de 0 a 2 e o total é de 66. A escala HFMSE pode ser utilizada em:  
- pacientes maiores de 2 anos de idade e com capacidade de sentar;  
- se escore CHOP INTEND maior que 60: avaliar paciente com HFMSE, como alternativa a CHOP INTEND.  
Deve-se atentar aos fatores que podem influenciar na manutenção ou perda de escores nas escalas, tais como dificuldades no acesso à reabilitação, órtese, ganho ou perda de peso do paciente, presença de contraturas ou deformidades, taxa de crescimento, qualidade do sono, uso de medicamentos e presença de infecções. Como tais fatores podem acarretar em perda momentânea dos escores da escala, deve-se reavaliar o paciente em três meses. À principio, a regressão nos escores, medidas consecutivamente, caracterizam a inefetividade do tratamento.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **8.        REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017<sup>70</sup> e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017)<sup>71</sup> , relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras.  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS.  
A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da atenção primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o locus da atenção à saúde dos pacientes com doenças raras. Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no  
- mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
Os serviços e equipes de atenção primária à saúde, pontos cruciais nas redes de atenção à saúde, e serviços especializados de saúde mais próximos ao paciente com AME 5q tipos 1 ou 2 deverão contribuir para o acompanhamento dos pacientes e monitorização do tratamento, “referenciando” e “contra-referenciando” o paciente em caso de necessidade. Nos casos de pacientes com indicação de suporte domiciliar, deverá ser observada a Política Nacional de Atenção Domiciliar, segundo seus critérios e disponibilidade dos serviços.  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças  
Raras.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, tal como médico geneticista, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, assim como a duração e o monitoramento dos tratamentos clínico e de reabilitação necessários. Pacientes com suspeita de AME 5q devem ser encaminhados, preferencialmente, a um serviço especializado ou de referência em doenças raras para seu adequado diagnóstico.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com AME 5q deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Os pacientes diagnosticados com AME tipo 1 elegíveis para administração do onasemnogeno abeparvoveque devem ser encaminhados para um Serviço de Terapias Gênica habilitado para avaliação da indicação, protocolo da receita e exames junto às instâncias pertinentes. Destaca-se que os documentos orientadores deste processo se encontram disponíveis na página oficial das Doenças Raras, no domínio do Ministério da Saúde, no campo de Notas Técnicas e Informativas.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A adesão aos medicamentos e sua correta utilização **_devem ser monitoradas pelos serviços_** , a fim contribuir com a melhoria no tratamento, promovendo a qualidade do uso dos medicamentos, evitando-se o desperdício dos recursos terapêuticos e recomendando trocas e interrupções, quando adequado.  
O nusinersena é um medicamento sintético indicado para uso intratecal e deve ser administrado por  profissional, experiente (ex. pediatra, neurologista e geneticista), utilizando técnicas seguras e assépticas durante a sua preparação e administração.  
De acordo com as Portarias de incorporação<sup>72</sup> , o uso de nusinersena, no âmbito do SUS, ficou condicionado a:  
1. Observância a este Protocolo estabelecido pelo Ministério da Saúde;  
2. Atendimento dos pacientes realizado em centros de referência definidos pelos respectivos gestores estaduais e  
informados ao Ministério da Saúde, com avaliação da efetividade clínica;  
3. Registro dos dados nos sistemas nacionais de informação do SUS (SIA, SIH e HÓRUS ou outro sistema estadual  
similar de gerenciamento da assistência farmacêutica no SUS);  
4. Reavaliação pela Conitec após três anos da incorporação;  
5. Laudo próprio para dispensação do medicamento;  
6. Questionário de avaliação clínica do paciente anexado a Laudo;  
7. Fornecimento diretamente aos centros de referência definidos; e  
8. Negociação com o fabricante para redução significativa de preço.  
**_A dispensação e administração intratecal do nusinersena ocorrerão exclusivamente nos centros de referência_** definidos pelos respectivos gestores estaduais e informados ao Ministério da Saúde, **_não sendo fornecido o medicamento diretamente para os pacientes ou seus parentes ou representantes legais_** .  
**_O risdiplam é um medicamento de administração exclusivamente oral_** . A sua constituição deve ser realizada por um  
profissional de saúde antes da dispensação aos pacientes. Enquanto que o onasemnogeno abeparvoveque é uma terapia gênica a ser administrada por profissional de saúde por meio de infusão intravenosa.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
O nusinersena, o risdiplam e o onasemnogeno abeparvoveque integram a Relação Nacional de Medicamentos Essenciais (RENAME), sendo adquiridos pelo Ministério da Saúde e fornecidos aos centros de referência definidos pelas secretarias estaduais, municipais e distrital de saúde.  
Os seguintes procedimentos diagnósticos constam na Tabela de Medicamentos, Procedimentos, Órteses, Próteses e Materiais Especiais do SUS:  
- 03.01.01.019-6 – Avaliação clínica para o diagnóstico de doenças raras – EIXO I – Anomalias congênitas ou de  
- manifestação tardia;  
- 02.02.10.011-1 – Identificação de mutação por sequenciamento por amplicon até 500 pares de bases;  
- 02.02.10.006-5 – Análise de ácido desoxirribonucleico (DNA) pela técnica de Southern Blot;  
- 02.02.10.007-3 – Análise de DNA por MLPA;  
- 02.02.10.008-1 – Identificação de mutação ou rearranjos por PCR, PCR sensível a metilação, qPCR e qPCR sensível  
à metilação;  
- 02.02.10.009-0 – FISH em metáfase ou núcleo interfásico, por doença;  
- 02.02.10.010-3 – Identificação de Alteração Cromossômica Submicroscópica por Array-CGH;  
- 02.02.10.011-1 – Identificação de mutação por sequenciamento por amplicon.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como os critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **10.      REFERÊNCIAS** -->
1. Arnold WD, Kassar D, Kissel JT. Spinal muscular atrophy: Diagnosis and management in a new therapeutic era. Muscle Nerve [Internet]. 2015 Feb 1 [cited 2023 Jan 25];51(2):157–67. Available from: https://onlinelibrary.wiley.com/doi/full/10.1002/mus.24497  
2. Verhaart IEC, Robertson A, Wilson IJ, Aartsma-Rus A, Cameron S, Jones CC, et al. Prevalence, incidence and carrier frequency of 5q–linked spinal muscular atrophy – a literature review. Orphanet J Rare Dis [Internet]. 2017 Jan 23;12(1):124. Available from: https://doi.org/10.1186/s13023-017-0671-8  
3. Bocca W, Rezende V De, Victor P, Souza S De, Mattos B, Badia L, et al. Adult-onset non-5q proximal spinal muscular atrophy : a comprehensive review. 2020;912–23.  
4. Araújo AP de QC, Ramos VG, Cabello PH. Dificuldades diagnósticas na atrofia muscular espinhal. Arq Neuropsiquiatr [Internet]. 2005 Jan 23;63:145–9. Available from: http://www.scielo.br/j/anp/a/qnGQvZF55TnbdCSvSfV6j7w/abstract/?lang=pt  
5. Baioni MTC, Ambiel CR. Atrofia muscular espinhal: diagnóstico, tratamento e perspectivas futuras. J Pediatr (Rio J) [Internet]. 2010 Jan 23;86:261–70. Available from: http://www.scielo.br/j/jped/a/wfPCsMcS4z6xcRVNxct8btf/abstract/?lang=pt  
6. Farooq FT, Holcik M, MacKenzie A, Farooq FT, Holcik M, MacKenzie A. Spinal Muscular Atrophy: Classification, Diagnosis, Background, Molecular Mechanism and Development of Therapeutics [Internet]. IntechOpen; 2013. Available from: https://www.intechopen.com/state.item.id  
7. Pechmann A, Kirschner J. Diagnosis and New Treatment Avenues in Spinal Muscular Atrophy. Neuropediatrics [Internet]. 2017 Jan 23;48(4):273–81. Available from: http://www.thieme-connect.de/DOI/DOI?10.1055/s-00371603517  
8. Finkel RS, Mercuri E, Darras BT, Connolly AM, Kuntz NL, Kirschner J, et al. Nusinersen versus Sham Control in Infantile-Onset Spinal Muscular Atrophy. N Engl J Med [Internet]. 2017 Jan 23;377(18):1723–32. Available from: https://doi.org/10.1056/NEJMoa1702752  
9. Russman BS. Spinal muscular atrophy: Clinical classification and disease heterogeneity. J Child Neurol. 2007;22(8):946–51.  
10. Crawford TO, Paushkin S V, Kobayashi DT, Forrest SJ, Joyce CL, Finkel RS, et al. Evaluation of SMN Protein, Transcript, and Copy Number in the Biomarkers for Spinal Muscular Atrophy (BforSMA) Clinical Study. Schuelke M, editor. PLoS One [Internet]. 2012 Jan 23;7(4):e33572. Available from: https://dx.plos.org/10.1371/journal.pone.0033572  
11. Wadman RI, Stam M, Jansen MD, van der Weegen Y, Wijngaarde CA, Harschnitz O, et al. A Comparative Study of SMN Protein and mRNA in Blood and Fibroblasts in Patients with Spinal Muscular Atrophy and Healthy Controls. Gillingwater TH, editor. PLoS One [Internet]. 2016 Jan 23;11(11):e0167087. Available from: https://dx.plos.org/10.1371/journal.pone.0167087  
12. Hosseinibarkooie S, Peters M, Torres-Benito L, Rastetter RHH, Hupperich K, Hoffmann A, et al. The Power of Human Protective Modifiers: PLS3 and CORO1C Unravel Impaired Endocytosis in Spinal Muscular Atrophy and Rescue SMA Phenotype. Am J Hum Genet [Internet]. 2016 Sep 9 [cited 2023 Jan 26];99(3):647. Available from: /pmc/articles/PMC5011078/  
13. Oprea GE, Kröber S, McWhorter ML, Rossoll W, Müller S, Krawczak M, et al. Plastin 3 Is a Protective Modifier of Autosomal Recessive Spinal Muscular Atrophy. Science (80- ) [Internet]. 2008 Jan 23;320(5875):524–7. Available from: https://www.science.org/doi/10.1126/science.1155085  
14. Shorrock HK, Gillingwater TH, Groen EJN. Overview of Current Drugs and Molecules in Development for Spinal Muscular Atrophy Therapy. Drugs [Internet]. 2018;78(3):293–305. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L620396123&from=export  
15. Groen EJN, Talbot K, Gillingwater TH. Advances in therapy for spinal muscular atrophy: promises and challenges. Nat Rev Neurol [Internet]. 2018 Jan 23;14(4):214–24. Available from: https://www.nature.com/articles/nrneurol.2018.4  
16. Riessland M, Kaczmarek A, Schneider S, Swoboda KJ, Löhr H, Bradler C, et al. Neurocalcin Delta Suppression Protects against Spinal Muscular Atrophy in Humans and across Species by Restoring Impaired Endocytosis. Am J Hum Genet [Internet]. 2017 Feb 2 [cited 2023 Jan 26];100(2):297–315. Available from: https://pubmed.ncbi.nlm.nih.gov/28132687/  
17. Crawford TO, Pardo CA. The Neurobiology of Childhood Spinal Muscular Atrophy. Neurobiol Dis [Internet]. 1996 Jan 23;3(2):97–110. Available from: https://www.sciencedirect.com/science/article/pii/S0969996196900108  
18. Consensus Statement for Standard of Care in Spinal Muscular Atrophy - Ching H. Wang, Richard S. Finkel, Enrico S. Bertini, Mary Schroth, Anita Simonds, Brenda Wong, Annie Aloysius, Leslie Morrison, Marion Main, Thomas O. Crawford, Anthony Trela, , Partici [Internet]. 2023. Available from:  
https://journals.sagepub.com/doi/10.1177/0883073807305788?url_ver=Z39.88-  
2003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub  0pubmed  
19. Wang CH, Finkel RS, Bertini ES, Schroth M, Simonds A, Wong B, et al. Consensus statement for standard of care in spinal muscular atrophy. J Child Neurol. 2007;22(8):1027–49.  
20. Sumner CJ. Molecular Mechanisms of Spinal Muscular Atrophy. J Child Neurol [Internet]. 2007 Jan 23;22(8):979–89. Available from: https://doi.org/10.1177/0883073807305787  
21. Kolb SJ, Kissel JT. Spinal Muscular Atrophy. Neurol Clin [Internet]. 2015 Nov [cited 2023 Jan 26];33(4):831–46. Available from: https://pubmed.ncbi.nlm.nih.gov/26515624/  
22. Lefebvre S, Bürglen L, Reboullet S, Clermont O, Burlet P, Viollet L, et al. Identification and characterization of a spinal muscular atrophy-determining gene. Cell [Internet]. 1995 Jan 23;80(1):155–65. Available from: https://www.sciencedirect.com/science/article/pii/0092867495904603  
23. Bach JR, Vega J, Majors J, Friedman A. Spinal muscular atrophy type 1 quality of life. Am J Phys Med Rehabil [Internet]. 2003;82(2):137–42. Available from: http://www.ncbi.nlm.nih.gov/pubmed/12544760  
24. Wadman RI, van der Pol WL, Bosboom WMJ, Asselman FL, van den Berg LH, Iannaccone ST, et al. Drug treatment for spinal muscular atrophy types II and III. Cochrane Database Syst Rev [Internet]. 2020;2020(1). Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L630806517&from=export  
25. Talbot K, Tizzano EF. The clinical landscape for SMA in a new therapeutic era. Gene Ther [Internet]. 2017 Jan 23;24(9):529–33. Available from: https://www.nature.com/articles/gt201752  
26. CCATES - Centro Colaborador do SUS Avaliação de Tecnologias 7 Excelência em Saúde. Eficácia e efetividade do nusinersena, risdiplam e onasemnogeno abeparvoveque para o tratamento de atrofia muscular espinhal (AME) 5q tipos I e II. 2023;  
27. Mercuri E, Finkel RS, Muntoni F, Wirth B, Montes J, Main M, et al. Diagnosis and management of spinal muscular atrophy: Part 1: Recommendations for diagnosis, rehabilitation, orthopedic and nutritional care. Neuromuscul Disord  
[Internet]. 2018 Jan 23;28(2):103–15. Available from: https://www.sciencedirect.com/science/article/pii/S0960896617312841 28. Wirth B. An update of the mutation spectrum of the survival motor neuron gene (SMN1) in autosomal recessive spinal muscular atrophy (SMA). Hum Mutat [Internet]. 2000 Jan 23;15(3):228–37. Available from: https://onlinelibrary.wiley.com/doi/abs/10.1002/%28SICI%2910981004%28200003%2915%3A3%3C228%3A%3AAID-HUMU3%3E3.0.CO%3B2-9  
29. Arkblad E, Tulinius M, Kroksmark AK, Henricsson M, Darin N. A population-based study of genotypic and phenotypic variability in children with spinal muscular atrophy. Acta Paediatr [Internet]. 2009 Jan 23;98(5):865–72. Available from: https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1651-2227.2008.01201.x  
30. Feng Y, Ge X, Meng L, Scull J, Li J, Tian X, et al. The next generation of population-based spinal muscular atrophy carrier screening: Comprehensive pan-ethnic SMN1 copy-number and sequence variant analysis by massively parallel sequencing. Genet Med. 2017 Aug 1;19(8):936–44.  
31. Feldkötter M, Schwarzer V, Wirth R, Wienker TF, Wirth B. Quantitative Analyses of SMN1 and SMN2 Based on RealTime LightCycler PCR: Fast and Highly Reliable Carrier Testing and Prediction of Severity of Spinal Muscular Atrophy. Am J Hum Genet [Internet]. 2002 Jan 23;70(2):358–68. Available from: https://www.sciencedirect.com/science/article/pii/S0002929707639512  
32. Wirth B, Brichta L, Schrank B, Lochmüller H, Blick S, Baasner A, et al. Mildly affected patients with spinal muscular atrophy are partially protected by an increased SMN2 copy number. Hum Genet [Internet]. 2006 Jan 23;119(4):422–8. Available from: https://doi.org/10.1007/s00439-006-0156-7  
33. Yeo CJJ, Simeone SD, Townsend EL, Zhang RZ, Swoboda KJ. Prospective Cohort Study of Nusinersen Treatment in Adults with Spinal Muscular Atrophy. J Neuromuscul Dis [Internet]. 2020;7(3):257–68. Available from: http://www.ncbi.nlm.nih.gov/pubmed/32333595  
34. Day JW, Finkel RS, Chiriboga CA, Connolly AM, Crawford TO, Darras BT, et al. Onasemnogene abeparvovec gene therapy for symptomatic infantile-onset spinal muscular atrophy in patients with two copies of SMN2 (STR1VE): an open-label, single-arm, multicentre, phase 3 trial. Lancet Neurol. 2021 Apr 1;20(4):284–93.  
35. Zolgensma. Onasemnogeno abeparvoveque. Novartis Biociências S.A. 2022.  
36. Mercuri E, Bertini E, Iannaccone ST. Childhood spinal muscular atrophy: controversies and challenges. Lancet Neurol [Internet]. 2012 Jan 23;11(5):443–52. Available from: https://www.sciencedirect.com/science/article/pii/S1474442212700613  
37. Han KJ, Foster DG, Zhang NY, Kanisha K, Dzieciatkowska M, Sclafani RA, et al. Ubiquitin-specific Protease 9x Deubiquitinates and Stabilizes the Spinal Muscular Atrophy Protein-Survival Motor Neuron*. J Biol Chem [Internet].  
- 2012 Jan 23;287(52):43741–52. Available from:  
https://www.sciencedirect.com/science/article/pii/S0021925820417685  
38. Oskoui M, Levy G, Garland CJ, Gray JM, O’Hagen J, Vivo DC De, et al. The changing natural history of spinal muscular atrophy type 1. Neurology [Internet]. 2007 Jan 23;69(20):1931–6. Available from: https://n.neurology.org/content/69/20/1931  
39. Schroth MK. Special Considerations in the Respiratory Management of Spinal Muscular Atrophy. Pediatrics [Internet]. 2009 Jan 23;123(Supplement_4):S245–9. Available from: https://doi.org/10.1542/peds.2008-2952K  
40. Mirea A, Shelby ES, Axente M, Badina M, Padure L, Leanca M, et al. Combination therapy with nusinersen and onasemnogene abeparvovec-xioi in spinal muscular atrophy type i. J Clin Med. 2021;10(23).  
41. Oechsel KF, Cartwright MS. Combination therapy with onasemnogene and risdiplam in spinal muscular atrophy  type 1. Muscle Nerve. 2021 Oct;64(4):487–90.  
42. Mendell JR, Al-Zaidy SA, Lehman KJ, McColly M, Lowes LP, Alfano LN, et al. Five-Year Extension Results of the Phase 1 START Trial of Onasemnogene Abeparvovec in Spinal Muscular Atrophy. JAMA Neurol. 2021;78(7):834–41.  
43. Erdos J, Wild C. Mid- and long-term (at least 12 months) follow-up of patients with spinal  muscular atrophy (SMA) treated with nusinersen, onasemnogene abeparvovec, risdiplam or combination therapies: A systematic review of realworld study data. Eur J Paediatr Neurol  EJPN  Off J  Eur Paediatr Neurol Soc. 2022 Jul;39:1–10.  
44. Al-Zaidy SA, Mendell JR. From Clinical Trials to Clinical Practice: Practical Considerations for Gene Replacement Therapy in SMA Type 1. Pediatr Neurol [Internet]. 2019 Nov 1 [cited 2023 Jan 26];100:3–11. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0887899418311639  
45. Bitetti I, Lanzara V, Margiotta G, Varone A. Onasemnogene abeparvovec gene replacement therapy for the treatment of spinal muscular atrophy: a real-world observational study. Gene Ther. 2022;(May):1–6.  
46. D’Silva AM, Holland S, Kariyawasam D, Herbert K, Barclay P, Cairns A, et al. Onasemnogene abeparvovec in spinal muscular atrophy: an Australian experience of safety and efficacy. Ann Clin Transl Neurol. 2022;9(3):339–50.  
47. Friese J, Geitmann S, Holzwarth D, Müller N, Sassen R, Baur U, et al. Safety Monitoring of Gene Therapy for Spinal Muscular Atrophy with Onasemnogene Abeparvovec-A Single Centre Experience. J Neuromuscul Dis [Internet]. 2021 [cited 2023 Jan 30];8:209–16. Available from: www.smartcare.  
48. Harada Y, Rao VK, Arya K, Kuntz NL, DiDonato CJ, Napchan-Pomerantz G, et al. Combination molecular therapies for type 1 spinal muscular atrophy. Muscle and Nerve. 2020;62(4):550–4.  
49. Lee S, Lee YJ, Kong J, Ryu HW, Shim YK, Han JY, et al. Short-term clinical outcomes of onasemnogene abeparvovec treatment for spinal muscular atrophy. Brain Dev [Internet]. 2022;44(4):287–93. Available from:  
https://doi.org/10.1016/j.braindev.2021.12.006  
50. Waldrop MA, Karingada C, Storey MA, Powers B, Iammarino MA, Miller NF, et al. Gene therapy for spinal muscular atrophy: Safety and early outcomes. Pediatrics. 2020;146(3).  
51. Chiriboga CA, Bruno C, Duong T, Fischer D, Mercuri E, Kirschner J, et al. Risdiplam in Patients Previously Treated with Other Therapies for Spinal Muscular  Atrophy: An Interim Analysis from the JEWELFISH Study. Neurol Ther. 2023 Apr;12(2):543–57.  
52. Fujak A, Haaker G. Proximal spinal muscular atrophy: current orthopedic perspective. Appl Clin Genet [Internet]. 2013 Jan 23;113. Available from: http://www.dovepress.com/proximal-spinal-muscular-atrophy-current-orthopedicperspective-peer-reviewed-article-TACG  
53. Spinraza. Nusinersena. Biogen Brasil Produtos Farmacêuticos. 2020;  
54. Bevan AK, Duque S, Foust KD, Morales PR, Braun L, Schmelzer L, et al. Systemic Gene Delivery in Large Species for Targeting Spinal Cord, Brain, and Peripheral Tissues for Pediatric Disorders. Mol Ther. 2011 Nov 1;19(11):1971–80.  
55. Blair HA. Onasemnogene Abeparvovec: A Review in Spinal Muscular Atrophy. CNS Drugs [Internet]. 2022 Sep 1 [cited 2023 Jan 25];36(9):995–1005. Available from: https://link.springer.com/article/10.1007/s40263-022-00941-1  
56. Evrysdi. Risdiplam. Produtos Roche Químicos e Farmacêuticos S.A. 2020;  
57. Mendonça R de H, Fernandes H dos S, Pinto RBS, Matsui C, Polido GJ, Silva AMS da, et al. Managing intrathecal administration of nusinersen in adolescents and adults with 5q-spinal muscular atrophy and previous spinal surgery. Arq Neuropsiquiatr [Internet]. 2021 Mar 19 [cited 2023 Jan 26];79(2):127–32. Available from: http://www.scielo.br/j/anp/a/NHhSVpqgCxV36JW3LYHYvbj/?lang=en  
58. Moshe-Lilie O, Visser A, Chahin N, Ragole T, Dimitrova D, Karam C. Nusinersen in adult patients with spinal muscular atrophy: Observations from a single center. Neurology [Internet]. 2020 Jan 23;95(4):e413–6. Available from: https://n.neurology.org/content/95/4/e413  
59. Mercuri E, Baranello G, Boespflug-Tanguy O, De Waele L, Goemans N, Kirschner J, et al. Risdiplam in types 2 and 3 spinal muscular atrophy: A randomised, placebo-controlled, dose-finding trial followed by 24 months of treatment. Eur J Neurol. 2022;  
60. Masson R, Mazurkiewicz-Bełdzińska M, Rose K, Servais L, Xiong H, Zanoteli E, et al. Safety and efficacy of risdiplam in patients with type 1 spinal muscular atrophy  (FIREFISH part 2): secondary analyses from an open-label trial. Lancet Neurol. 2022 Dec;21(12):1110–9.  
61. Darras BT, Masson R, Mazurkiewicz-Bełdzińska M, Rose K, Xiong H, Zanoteli E, et al. Risdiplam-Treated Infants with Type 1 Spinal Muscular Atrophy versus Historical  Controls. N Engl J Med. 2021 Jul;385(5):427–35.  
62. Mercuri E, Darras BT, Chiriboga CA, Day JW, Campbell C, Connolly AM, et al. Nusinersen versus sham control in later-onset spinal muscular atrophy. N Engl J Med. 2018;378(7):625–35.  
63. Day JW, Finkel RS, Chiriboga CA, Connolly AM, Crawford TO, Darras BT, et al. Onasemnogene abeparvovec gene therapy for symptomatic infantile-onset spinal muscular atrophy in patients with two copies of SMN2 (STR1VE): an open-label, single-arm, multicentre, phase 3 trial. Lancet Neurol. 2021;20(4):284–93.  
64. Mercuri E, Muntoni F, Baranello G, Masson R, Boespflug-Tanguy O, Bruno C, et al. Onasemnogene abeparvovec gene therapy for symptomatic infantile-onset spinal muscular atrophy type 1 (STR1VE-EU): an open-label, single-arm, multicentre, phase 3 trial. Lancet Neurol. 2021;20(10):832–41.  
65. Erdos J, Wild C. Mid- and long-term (at least 12 months) follow-up of patients with spinal muscular atrophy (SMA) treated with nusinersen, onasemnogene abeparvovec, risdiplam or combination therapies: A systematic review of realworld study data. Eur J Paediatr Neurol. 2022 Jul 1;39:1–10.  
66. Mendell JR, Al-Zaidy S, Shell R, Arnold WD, Rodino-Klapac LR, Prior TW, et al. Single-Dose Gene-Replacement  
Therapy for Spinal Muscular Atrophy. N Engl J Med. 2017;377(18):1713–22.  
67. Mercuri E, Muntoni F, Baranello G, Masson R, Boespflug-Tanguy O, Bruno C, et al. Onasemnogene abeparvovec gene therapy for symptomatic infantile-onset spinal  muscular atrophy type 1 (STR1VE-EU): an open-label, single-arm, multicentre, phase 3 trial. Lancet Neurol. 2021 Oct;20(10):832–41.  
68. Bayley N. Bayley Scales of Infant and Toddler Development 3rd Edition: Screening Test Manual. San Antonio, TX Harcourt Assessment, Inc. 2006;  
69. Pechmann A, König K, Bernert G, Schachtrup K, Schara U, Schorling D, et al. SMArtCARE - A platform to collect reallife outcome data of patients with spinal muscular atrophy. Orphanet J Rare Dis. 2019;14(1):1–6.  
70. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 2, de 28 de setembro de 2017 [Internet]. 2017. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html  
71. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 6, de 28 de setembro de 2017. 2017; Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0006_03_10_2017.htmlA  
72. Brasil. Ministério da Saúde. PORTARIA No 24, DE 24 DE ABRIL DE 2019. Diário Of da União. 2019;  
73. Alves RMR, Calado AP de M, Van Der Linden V, Bello MAFC, Andrade LB de. Brazilian version of the CHOP INTEND scale: cross-cultural adaptation and validation. Arq Neuropsiquiatr [Internet]. 2023 Sep 4;81(09):816–24. Available from: http://www.thieme-connect.de/DOI/DOI?10.1055/s-0043-1772832

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER) - NUSINERSENA E RISDIPLAM** -->
Eu, ___________________________________________________________________________________ (nome do(a)  
paciente ou seu responsável), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do **nusinersena e risdiplam** , indicado para o tratamento medicamentoso da Atrofia Muscular  Espinhal 5q tipos 1 ou 2.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico ________________________  
_______________________________________________________________________(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- independência de ventilação mecânica invasiva acima de 24 horas de ventilação por dia, continuamente, durante o período do tratamento medicamentoso, exceto por uso em caso de insuficiência respiratória aguda gerada por outras causas que não a AME 5q tipos 1 ou 2;  
- independência de suporte nutricional invasivo durante o período de tratamento;  
- melhora ou estabilização de função motora, definida por critérios estabelecidos em escalas apropriadas; e  
- fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos  
- pelo uso do medicamento:

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Nusinersena** -->
Relacionados à punção lombar e administração intratecal:  
- dor de cabeça, náusea, vômitos, dor lombar e infecção. A maioria destes eventos foi relatada no período de 72 horas  
após o procedimento.  
 sintomas e sinais de hipertensão intracraniana (cefaleia, náusea, vômitos, letargia e edema de papila) e outras complicações à punção lombar e à administração intratecal, como lesão do parênquima nervoso (dor lombar, rigidez de nuca, fraqueza ou mesmo paralisia muscular), dor e febre devidas a infecção, hemorragia e outros sinais de acometimento do sistema nervoso central, como vertigem, sonolência, irritabilidade e convulsões.  
- Relacionadas à ação do medicamento:  
- baixa do número de plaquetas no sangue e alteração da coagulação sanguínea, após a administração de nusinersena;  
 alteração da função renal foi observada após administração de nusinersena por vias subcutânea e intravenosa, daí ser recomendada a realização do teste de presença de proteína em urina e, em caso de persistência de proteínas urinárias presentes em concentração elevada, deve-se proceder a uma melhor avaliação;  
- nos estudos de toxicidade realizados em modelos animais (in vivo), não foram observados efeitos relacionados aos  
- órgãos reprodutivos, na fertilidade masculina ou feminina ou no desenvolvimento do embrião ou fetal;  
- os efeitos do tratamento com nusinersena sobre o parto e o trabalho de parto são desconhecidos;  
 inexistem dados de estudos clínicos sobre o tratamento com nusinersena durante a gravidez (período gestacional) em seres humanos. O benefício do tratamento versus risco potencial deve ser discutido com mulheres em idade fértil ou grávidas, pois o nusinersena se inclui na categoria de risco C para gravidez;  
- insuficiência renal e alterações hepáticas não foram estudadas em pacientes em uso de nusinersena.  
- **Risdiplam**  
- Relacionadas à ação do medicamento:  
- nos estudos de toxicidade realizados em modelos animais (in vivo), foram observados efeitos relacionados aos órgãos  
- reprodutivos, na fertilidade masculina ou feminina ou no desenvolvimento do embrião ou fetal. Os pacientes com potencial  
reprodutivo devem ser informados dos riscos e devem utilizar contracepção altamente eficaz durante o tratamento e até pelo  
menos 1 mês após a última dose para pacientes do sexo feminino e 4 meses após a última dose para pacientes do sexo masculino;  
- os efeitos do tratamento com risdiplam sobre o parto e o trabalho de parto são desconhecidos;  
- o uso durante a gestação e/ou lactação é contra-indicado, uma vez que se inclui na categoria de risco C para gravidez.  
- Risdiplam demonstrou ser embriofetotóxico, teratogênico, sendo excretado no leite em estudos com modelos animais;  
- em pacientes com insuficiência hepática leve ou moderada e não houve impacto na farmacocinética, segurança e  
- tolerabilidade de uma dose única de 5 mg de risdiplam, não sendo necessário realizar o ajuste de doses;  
- insuficiência renal, insuficiência hepática grave e com idade superior a 60 nos não foram estudadas em pacientes em  
- uso de risdiplam;  
- Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não  
- queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Estou ciente que o uso deste medicamento demanda a realização de avaliação prévia e avaliações periódicas para monitoramento clínico e do desempenho motor.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(  ) sim      (  ) não  
Meu tratamento constará do seguinte medicamento:  
(    ) nusinersena            (    ) risdiplam  
|Local:<br>Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|Assinatura e carimbo do médico|||
|Data: _________________|||  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER) - ONASEMNOGENO ABEPARVOVEQUE** -->
Eu, <u>(nome do(a)</u>  
responsável pelo paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do onasemnogeno abeparvoveque, indicado para o tratamento medicamentoso da Atrofia Muscular Espinhal 5q tipo 1.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) _________________  
_______________________________________________________________________(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- independência de ventilação mecânica invasiva permanente, exceto por uso em caso de insuficiência respiratória aguda  
- gerada por outras causas que não a AME 5q tipo 1;  
- independência de suporte nutricional invasivo; e  
- melhora ou estabilização de função motora, definida por critérios estabelecidos em escalas apropriadas.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos pelo  
uso do medicamento:

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **ONASEMNOGENO ABEPARVOVEQUE** -->
Relacionadas à ação do medicamento:  
- Este medicamento pode causar uma resposta imunológica que pode levar a um aumento das enzimas produzidas pelo fígado ou lesão do fígado. Lesões no fígado podem levar a resultados graves, incluindo insuficiência hepática e morte.  
- Os possíveis sinais que necessitam de atenção após a administração deste medicamento incluem vômitos, icterícia (amarelamento da pele ou da parte branca dos olhos) ou redução do estado de alerta. Informe ao médico imediatamente se notar o desenvolvimento de algum sintoma sugestivo de lesão no fígado.  
- O paciente deverá fazer exames de sangue para verificar a função hepática antes de iniciar o tratamento com este medicamento. Também será necessário realizar exames de sangue regulares por pelo menos 3 meses após o tratamento para monitorar o aumento das enzimas hepáticas.  
- Caso ocorra infecção (por exemplo, resfriado, gripe ou bronquiolite) antes ou depois de ser tratado com este medicamento, isso pode levar a complicações mais graves. Cuidadores e contatos próximos ao paciente devem seguir as práticas de prevenção de infecções (por exemplo: higiene das mãos, etiqueta respiratória/tosse, limitar contatos potenciais).  
- Os sinais de uma possível infecção que precisam ser observadas incluem tosse, respiração ofegante, espirros, coriza, dor de garganta ou febre. Informe imediatamente o médico se notar o aparecimento de quaisquer sintomas sugestivos de infecção antes ou após o tratamento com este medicamento.  
- Hematomas ou hemorragias anormais após a administração do medicamento podem surgir devido a diminuição da contagem de plaquetas no sangue (trombocitopenia). Isto pode ocorrer geralmente nas primeiras duas semanas após o tratamento. Serão realizados exames de sangue para verificar a contagem das plaquetas por um período de tempo após o tratamento para monitorar alterações sanguíneas.  
Estou ciente de que este medicamento somente pode ser utilizado pelo paciente beneficiário.  
Estou ciente que o uso deste medicamento prevê avaliação prévia e avaliações periódicas para monitoramento clínico e do desempenho motor.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) sim                      (    ) não  
33  
<!-- Start of picture text -->
Local:  Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>Data: _________________                                    Assinatura e carimbo do médico<br><!-- End of picture text -->  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **QUESTIONÁRIO - AVALIAÇÃO CLÍNICA DE PACIENTES COM AME 5Q TIPOS 1 E 2** -->
**<u>(    ) Nusinersena         (   ) Risdiplam           (   ) Onasemnogeno abeparvoveque Função respiratória</u>** **_01 - Uso de ventilação mecânica nos três meses de acompanhamento (caso necessário pode ser assinalada mais de uma opção):_ ( ) Não ( ) Sim,** **_ventilação não invasiva_ , por:  ___ horas/dia, durante: ____ dias ( ) Sim,** **_ventilação invasiva_ , por: _____ horas/dia, durante: _____ dias Observações quanto ao uso de ventilação:** **_02 - Saturação de O2: ________ %_** **<u>Cuidado nutricional</u>** **_03 - Via de alimentação majoritária nos três meses de acompanhamento:_ ( ) Oral ( ) Nutrição enteral por tubo (nasoentérica, nasogástrica, entre outras ostomias)** **_04 - Consistência da dieta majoritária nos três meses de acompanhamento:_ ( ) Sólida ( ) Pastosa ( ) Líquida Observações:** **<u>Medidas antropométricas</u>** **_05 – Idade: ______ meses 06 – Peso: _____ kg 07 - Sexo: (  ) M       (  ) F 08 – Estatura: _____ cm 09 - Perímetro cefálico: ____ cm 10 -  Perímetro braquial: ____ cm 11 - Perímetro torácico: _____ cm_** **<u>Estado nutricional</u>** **_12 -  Escore Z (OMS): __________ 13 - Peso por idade: __________ 14 - Altura por idade: _________ 15 - Índice de Massa Corporal:___________** **<u>Função motora</u>**<sup>**1**</sup> **_16 - Classificação da AME – (  ) Tipo 1         (  ) Tipo 2          (  ) Tipo 3 ou 4 17 - Resultado escala CHOP INTEND:______ pontos – Data da avaliação: _____/______/______ 18 - Resultado escala HFMSE: ______ pontos – Data da avaliação: _____/______/______ Escala WHO - 6 Marcos de Desenvolvimento Motor 1) Senta sem apoio (  ) 2) Engatinha usando as mãos e os joelhos (  ) 3) Fica em pé com ajuda (  ) 4) Caminha com assistência (  ) 5) Fica em pé sem ajuda/sozinho (  ) 6) Caminha sem assistência/sozinho (  )_**  
**_Relatório médico com descrição da situação motora do paciente e justificativa para escolha da escala que melhor se adequa à condição do paciente (utilize o verso caso necessário):_**  
**_Local e data Médico Responsável (CRM)_**  
Notas: (1) Escolha a  escala que mais adequada a condição clínica do paciente; Escala CHOP INTEND: http://columbiasma.org/docs/cme-2010/CHOP%20INTEND%20for%20SMA%20Type%20I%20-%20Score%20Sheet.pdf. Orientações para a escala CHOP INTEND: http://columbiasma.org/docs/cme-2010/CHOP%20INTEND%20for%20SMA%20Type%20I%20- <u>%20Manual%20of%20Procedures.pdf</u> Escala HFMSE e orientações: http://columbiasma.org/docs/HFMSE_2019_Manual.pdf

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **VERSÃO BRASILEIRA DA ESCALA HFMSE** -->
**Nome do(a) paciente: ______________________________________________________________________________ Data da avaliação: ______/___________________/___________ Idade:________________**  
**Tempo desde a última alimentação: __________________________________________________________________**  
**Observação** : este documento deve ser completamente e corretamente preenchido para avaliação do processo administrativo de solicitação de medicamentos para pacientes com diagnóstico de AME tipo 1 e 2.  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
||O examinador deverá|||Capaz de sentar sem usar a mão como suporte por uma contagem de 3 ou mais.|2|
||encontrar a melhor<br>|O examinador<br>|Você consegue|Precisa do apoio de uma mão para manter o equilíbrio por uma contagem de 3.|1|
|**1 –**Sentado na<br>cadeira/chão|posição para que o<br>paciente fique<br>sentado sozinho no<br>chão ou na cadeira<br>(não pode ser de<br>rodas) com os pés<br>sem apoio.|deverá solicitar para<br>que o paciente<br>sentado erga os<br>braços sem ter<br>contato com o<br>corpo.|permanecer sentado<br>no chão ou na cadeira<br>sem usar as mãos<br>como apoio contando<br>até 3?|Precisa de apoio de duas mãos para manter o equilíbrio.|0|
||Sentado no chão ou|O paciente deverá|Você consegue<br>|Capaz de sentar no chão com as pernas retas sem apoio de mão por uma contagem de 3.|2|
|**2 -**Permanecer<br>|maca com as pernas<br>em extensão máxima|permanecer por um<br>longo tempo<br>|sentar-se no chão<br>sem usar as mãos<br>|Capaz de sentar no chão com as pernas retas apoiando com uma mão suporte por uma<br>contagem de 3.|1|
|sentado por um<br>longo período.|e as rótulas<br>apontando ao teto.<br>Voltar sem suporte.|sentado com as<br>pernas esticadas e os<br>braços para cima, os<br>braços não devem|<br>como apoio e com as<br>pernas direto para<br>uma contagem de 3?<br>Não deixe suas|Capaz de sentar-se por muito tempo usando as duas mãos por uma contagem de 3 ou<br>incapaz de sentar com as pernas retas.|0|  
37  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
|||estar em contato<br>com o corpo.|pernas rolarem.|||
||Sentado no chão ou<br>sobre a borda da|Todas as pontas dos|Você consegue|Capaz de levar uma mão à cabeça - braços livres de lado. Cabeça e tronco permanecem<br>estáveis.|2|
|**3 -**U ma mão na<br>|<br>cadeira (sem apoio<br>para as costas). Os<br>|dedos de uma mão<br>acima do nível do<br>|<br>colocar uma mão na<br>cabeça (acima da|Só pode levar a mão à cabeça flexionando a cabeça/tronco ou rastejando a mão até o topo<br>da cabeça.|<br>1|
|cabeça sentado.|braços podem estar<br>apoiados no<br>colchonete ou no<br>colo.|ouvido (podem ou<br>não estar em contato<br>com cabeça).|orelha) sem dobrar o<br>pescoço?|Incapaz de levar a mão à cabeça mesmo usando o movimento da cabeça e do tronco.|0|
||Sentado no chão ou<br>sobre a borda da|Todas as pontas dos<br>dedos (não inclui os|Você consegue|Capaz de colocar as duas mãos na cabeça ao mesmo tempo – braços livres de lado.<br>Cabeça e tronco permanecem estáveis.|2|
|**4 -**Duas mãos na<br>|<br>cadeira (sem apoio<br>para as costas). Os<br>|polegares) de ambas<br>as mãos acima do<br>|<br>levantar as duas mãos<br>ao mesmo tempo, até|<br> <br>Capaz de colocar as mãos na cabeça, mas usando apenas flexão da cabeça ou inclinação<br>lateral ou mãos rastejantes para cima ou uma de cada vez.|1|
|cabeça sentado.|braços podem estar<br>apoiados no<br>colchonete ou no<br>colo.|nível do ouvido<br>(podem ou não estar<br>em contato com a<br>cabeça).|a cabeça, sem dobrar<br>o pescoço?|Incapaz de colocar as duas mãos na cabeça.|0|
||Braços em decúbito|Os ombros devem||Capaz de rolar para o lado de supino em ambos os sentidos.|2|
||dorsal ao lado ou em|estar||Pode rolar para o lado apenas em um sentido (direita ou esquerda).|1|
|**5 –**Deitado de<br>lado|posição<br>intermediária, quadris<br>e ombros voltados<br>para cima em direção<br>ao teto.|<br>perpendiculares ao<br>chão, e o tronco e os<br>quadris devem estar<br>alinhados com o<br>ombro e o corpo. A|Você pode rolar para<br>o seu lado em ambas<br>as direções?|Não é possível rolar para o lado de qualquer maneira.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
|||posição da perna<br>não é importante,<br>mas as coxas são<br>empilhadas umas<br>sobre as outras.||||
||Decúbito ventral,|Decúbito dorsal||Rola totalmente em decúbito dorsal com os braços livres para a direita.|2|
||braços em posição<br>|com os braços por|Você consegue rolar<br>|Rola totalmente em decúbito dorsal puxando/empurrando os braços.|1|
|**6 -**Rolar de<br>prono a supino<br>para a direita|intermediária ou ao<br>lado, quadris e<br>ombros voltados para<br>baixo em direção ao<br>chão.|baixo do corpo,<br>quadris e ombros<br>voltados para cima<br>em direção ao teto.|da barriga para as<br>costas em ambas as<br>direções? Tente não<br>usar as mãos.|Incapaz de rolar em decúbito dorsal. Não inicia ou completa a posição supino.|0|
||Decúbito ventral,|Decúbito dorsal||Rola totalmente em decúbito dorsal com os braços livres para a esquerda.|2|
||braços em posição<br>|com os braços por|Você consegue rolar<br>|Rola totalmente em decúbito dorsal puxando/empurrando os braços.|1|
|**7 -**Rolar de<br>prono a supino<br>para a esquerda.|intermediária ou ao<br>lado, quadris e<br>ombros voltados para<br>baixo em direção ao<br>chão.|baixo do corpo,<br>quadris e ombros<br>voltados para cima<br>em direção ao teto.|da barriga para as<br>costas em ambas as<br>direções? Tente não<br>usar as mãos.|Incapaz de rolar em decúbito dorsal. Não inicia ou completa a posição supino.|0|
||Decúbito dorsal no|De bruços, com os|Você consegue rolar|Rola totalmente em decúbito ventral com os braços livres para a direita.|2|
|**8 –**Rolar de<br>|colchonete com os<br>|braços por baixo do<br>|<br>das costas para a|Rola totalmente em decúbito ventral puxando/empurrando os braços.|1|
|supino para<br>prono para a<br>direita.|braços em posição<br>intermediária ou ao<br>lado, quadris e<br>ombros voltados para|corpo, quadris e<br>ombros voltados<br>para baixo em<br>direção ao chão.|barriga em ambas as<br>direções? Tente não<br>usar nosso mãos.|Incapaz de rolar em decúbito ventral. Não inicia ou completa a posição prono.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
||cima em direção ao<br>teto.|||||
||Decúbito dorsal no|||Rola totalmente em decúbito ventral com os braços livres para a esquerda.|2|
||colchonete com os<br>|De bruços, com os<br>|Você consegue rolar|Rola totalmente em decúbito ventral puxando/empurrando os braços.|1|
|**9 -**Rolar de<br>supino para<br>prono para a<br>esquerda.|braços em posição<br>intermediária ou ao<br>lado, quadris e<br>ombros voltados para<br>cima em direção ao<br>teto.|braços por baixo do<br>corpo, quadris e<br>ombros voltados<br>para baixo em<br>direção ao chão.|das costas para a<br>barriga em ambas as<br>direções? Tente não<br>usar nosso mãos.|Incapaz de rolar em decúbito ventral. Não inicia ou completa a posição prono.|0|
||Sentado no<br>colchonete, com as|Decúbito dorsal,|Você consegue se|Capaz de se deitar de lado ou na linha média usando roupas de maneira<br>controlada/segura.|2|
|**10 –**Sentado<br>para deitar|pernas posicionadas<br>na frente do corpo.<br>|<br>quadris e ombros<br>voltados para cima|deitar de forma<br>controlada/segura a<br>|Capaz de se deitar caindo para a frente e rolando para os lados, ou de bruços de maneira<br>controlada/segura.|1|
||Não deve ser<br>realizado sentado na<br>beirada da cama.|em direção ao teto.|partir da posição<br>sentada?|Incapaz ou completa de forma não controlada/insegura.|0|
||Decúbito ventral com<br>a testa apoiada no|Decúbito ventral e<br>apoiado nos|Você consegue se|Capaz de alcançar suporte nos antebraços e manter a cabeça erguida independentemente<br>por uma contagem de 3.|2|
||colchonete, quadris e<br>|antebraços. Os<br>|apoiar nos antebraços<br>|Mantém a posição por uma contagem de 3 quando colocado.|1|
|**11 –**Aoio nos|ombros voltados ara|antebraos devem|com a cabea eruida|||
|p<br>antebraços|p<br>baixo em direção ao<br>chão (**pelve em**<br>**contato com o**<br>**colchonete**) – braços|ç<br>estar na superfície e<br>as mãos não<br>entrelaçadas. A<br>pelve deve estar em|ç g<br>(sem segurar a<br>cabeça) e segurar<br>contando até 3?|Incapaz ou retido por menos de uma contagem de 3.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
||para baixo ao lado.|contato com o<br>colchonete.||||
||Decúbito ventral com<br>a testa apoiada no|De bruços com o||Capaz de levantar a cabeça na linha média em decúbito ventral, braços para baixo ao lado<br>por uma contagem de 3.|2|
||colchonete, quadris e<br>Ombros voltados|queixo afastado do<br>tapete. Com os|Você consegue|Levanta a cabeça na posição vertical com os braços na posição intermediária por uma<br>contagem de 3.|1|
|**12 -**Levanta a|para baixo em|braços ao lado|levantar a cabeça|||
|cabeça no<br>decúbito|direção ao chão -<br>braços para baixo ao<br>lado. A pelve não<br>precisa estar em<br>contato com o<br>colchonete.|(pontuação 2) ou em<br>posição<br>intermediária<br>(abdução entre 70° e<br>110° (pontuação 1)).|<br> <br> <br>mantendo os braços<br>ao seu lado contando<br>até 3?|Incapaz ou levanta a cabeça por menos de 3.|0|
|||Decúbito ventral||Capaz de apoiar os braços estendidos, cabeça erguida por uma contagem de 3.|2|
||Decúbito ventral com<br>|com os cotovelos<br>||Pode se apoiar nos braços estendidos se colocado por uma contagem de 3.|1|
||a testa apoiada no<br>colchonete, quadris e<br>Ombros voltados|estendidos e tronco<br>em extensão - o<br>umbigo deve estar|Você consegue se|||
|**13 -**Suporte nos|para baixo em|livre da superfície.|sustentar com os|||
|braços estendidos|<br>direção ao chão<br>(pelve em contato<br>com o colchonete)<br>braços para baixo ao<br>lado.|A cabeça deve estar<br>acima da posição<br>neutra. A posição<br>das mãos no<br>colchonete e o<br>ângulo das mãos|braços retos contando<br>até 3?|<br>Impossível.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
|||não são importantes,<br>mas devem estar<br>dentro de um raio da<br>articulação do<br>ombro.||||
|||Sentar-se com a||Capaz de ficar sentado de lado ou em decúbito dorsal.|2|
|||parte inferior em||Vira em decúbito ventral ou em direção ao chão e empurra-se para sentar.|1|
|**14 -**Deitado para<br>sentar.|Braços em decúbito<br>dorsal ao lado,<br>quadris e ombros<br>voltados para cima<br>em direção ao teto.|contato com o<br>colchonete. As<br>pernas devem ser<br>posicionadas na<br>frente do corpo; no<br>entanto, a posição<br>precisa não importa.|Você pode passar de<br>deitado (supino) para<br>sentado sem rolar<br>com a barriga?|Impossível.|0|
||Decúbito ventral no|Posição ajoelhada<br>em quatro apoios||Consegue ficar ajoelhado em quatro apoios com a cabeça erguida e olhando para frente<br>por uma contagem de 3.|2|
||colchonete, braços<br>em posição|com a cabeça<br>estendida e olhando<br>f Mã|Você consegue ficar|Mantém a posição de quatro apoios com a cabeça estendida quando colocado por uma<br>contagem de 3.|1|
|**15 -**Deitado para<br>sentar.|intermediária ou ao<br>lado, quadris e<br>ombros voltados para<br>baixo em direção ao<br>chão.|para rente. os e<br>joelhos devem ser<br>posicionados<br>aproximadament e<br>sob os ombros e<br>quadris,<br>respectivamente. O|de mãos e joelhos<br>com a cabeça erguida<br>e contar até 3?|Impossível.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
|||alinhamento perfeito<br>não é necessário.||||
|||Permanece||Capaz de engatinhar para frente. Move todos os quatro apoios duas vezes ou mais.|2|
|||<br>ajoelhado em quatro<br>|Você pode|Move todos os quatro apoios apenas uma vez.|1|
|**16 -**<br>Engatinhando.|Ajoelhado em quatro<br>apoios.|<br>apoios, porém<br>avança. A distância<br>percorrida não é<br>importante.|engatinhar para<br>frente?|Impossível.|0|
|||Decúbito dorsal<br>com a cabeça|Você consegue|Em decúbito dorsal, pode levantar a cabeça através da flexão do pescoço na linha média.<br>O queixo se move em direção ao peito. Mantido por uma contagem de 3.|2|
|**17 -**Levanta a|Decúbito dorsal no<br>colchonete com os<br>b d|flexionada usando<br>flexão do pescoço<br>ã 2|<br>levantar a cabeça<br>para olhar para os|A cabeça é levantada, mas com flexão lateral, usando protração ou sem flexão do<br>pescoço. Mantido por uma contagem de 3.|1|
|cabeça em<br>decúbito dorsal.|raços cruzaos<br>sobre o peito<br>(cotovelos afastados<br>do colchonete).|(pontuaço ) ou<br>fora da superfície do<br>colchonete<br>(pontuação 1).<br>Cotovelos afastados<br>do colchonete.|dedos dos pés<br>mantendo os braços<br>cruzados contando<br>até 3?|Impossível|0|
||Ficar descalço no|||Consegue ficar de pé com o apoio de uma mão por uma contagem de 3.|2|
|**18**- Ficando de|chão. Sem uso de<br>órteses. O<br>|Ficar em pé com os<br>|Você consegue ficar<br>de pé usando uma|Capaz de ficar de pé com o apoio de uma mão e apoio mínimo de tronco (não quadril)<br>por uma contagem de 3.|1|
|pé|examinador deve<br>estar próximo para<br>vigiar o paciente a<br>fim de garantir a|dois pés usando uma<br>mão para apoio.|mão como apoio<br>contando até 3?|Consegue ficar de pé com o apoio de uma mão, mas precisa de apoio de joelho/quadril<br>para contar até 3 ou é incapaz de ficar em pé apoiado.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
||segurança. Um apoio<br>deve estar próximo à<br>altura do quadril se a<br>habilidade for incerta.|||||
||De pé descalço no|||Consegue ficar de pé sem suporte por mais de uma contagem de 3.|2|
||chão, os pés devem<br>|||Fica de pé sem suporte por uma contagem de 3.|1|
|**19**- Ficando de<br>pé sem suporte|estar separados por<br>aproximadamente 10<br>cm (largura do<br>quadril). Sem uso de<br>órteses. Um apoio<br>deve estar próximo à<br>altura do quadril se a<br>habilidade for incerta.|<br>De pé em ambos os<br>pés, tomando todo o<br>peso de forma<br>independente, a<br>postura não é<br>importante.|<br>Você consegue ficar<br>de pé sem segurar<br>nada contando até 3?|Ficade pé apenas momentaneamente (menos de uma contagem de 3) ou é incapaz de ficar<br>de pé sem suporte.|0|
||Descalço em piso|||Consegue dar mais de 4 passos sem ajuda.|2|
||plano. Sem órteses,|Permanece em pé,|Você pode andar sem|<br>Consegue dar de 2 a 4 passos sem ajuda.|1|
|**20 -**|meias e sapatos.|mas avança. A|usar nenhuma ajuda|||
|Caminhando.|Auxiliares de<br>caminhada não são<br>permitidos.|distância percorrida<br>não é importante.|ou auxílio? Mostre-<br>me.|Impossível.|0|
||Decúbito dorsal sobre|<br>A amplitude ativa|Você pode levar o|Flexão total do quadril alcançada. A flexão total é definida como > 110°.|2|
|**21 –**Flexão do<br>quadril direito em<br>|<br>o colchonete com<br>quadris e joelhos em<br>|completa de flexão<br>de quadril e joelho é<br>|<br> <br>joelho direito ao<br>peito? Tente ir o mais|<br>Capaz de iniciar flexão unilateral de quadril e joelho > 10% mas não atinge a plenitude<br>alcance (<110°)|1|
|decúbito dorsal.|extensão máxima<br>possível. Avalie a|alcançada e<br>permanece em|longe que puder.|Impossível|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
||amplitude passiva<br>para a flexão do<br>quadril e do joelho<br>antes de iniciar a<br>avaliação.|decúbito dorsal. A<br>coxa deve<br>aproximar-se do<br>peito do paciente e a<br>parte posterior da<br>panturrilha deve<br>aproximar-se da<br>coxa. Aproximar<br>não significa<br>necessariamente<br>tocar. Os braços não<br>podem ser utilizados<br>para auxiliar.||||
|||A amplitude ativa||Flexão total do quadril alcançada. A flexão total é definida como > 110°.|2|
||Decúbito dorsal sobre<br>o colchonete com|completa de flexão<br>de quadril e joelho é||Capaz de iniciar flexão unilateral de quadril e joelho > 10% mas não atinge a plenitude<br>alcance (<110°).|1|
||quadris e joelhos em|alcançada e||||
|**22**- Flexão do|extensão máxima|permanece em|Você pode levar o|||
|quadril esquerdo<br>em decúbito|possível. Avalie a<br>amplitude passiva|decúbito dorsal. A<br>coxa deve<br>|joelho esquerdo ao<br>peito? Tente ir o mais|||
|dorsal.|para a flexão do<br>quadril e do joelho<br>antes de iniciar a<br>avaliação.|aproximar-se do<br>peito do paciente e a<br>parte posterior da<br>panturrilha deve<br>aproximar-se da|longe que puder.|Impossível.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
|||coxa. Aproximar<br>não significa<br>necessariamente<br>tocar. Os braços não<br>podem ser utilizados<br>para auxiliar.||||
||Ajoelhado alto e os|Meio ajoelhado<br>definido como o<br>||Capaz de atingir a metade do joelho (com ou sem apoio de braço) e mantém a posição<br>sem apoio de braço por uma contagem de 10.|2|
||braços livres. O|peso colocado em<br>||Mantém meio ajoelhado com um apoio de braço por uma contagem de 10.|1|
|**23 -**Ajoelhado<br>alto a meio<br>ajoelhado<br>(direita)|Examinador deve<br>estar próximo a fim<br>de garantir a<br>segurança do<br>paciente. É permitido<br>o uso de banco/<br>bancada para apoio<br>de um braço ou do<br>próprio corpo.|<br>um joelho e o pé<br>oposto e as nádegas<br>afastadas da parte<br>inferior da perna. A<br>meia direita<br>ajoelhada é com o<br>peso apoiado no<br>joelho direito e o pé<br>esquerdo para a<br>frente. Alinhamento<br>não é um critério.|Você consegue<br>levantar a perna<br>esquerda de modo<br>que o pé fique<br>apoiado no chão sem<br>usar os braços e<br>segurar contando até<br>10?|Impossível.|0|
|**24 -**Ajoelhado<br>alto a meio|Ajoelhado alto e os<br>braços livres. O|Meio ajoelhado<br>definido como o|Você consegue<br>levantar a perna|Capaz de atingir a metade do joelho (com ou sem apoio de braço) e mantém a posição<br>sem apoio de braço por uma contagem de 10.|2|
|ajoelhado|Examinador deve<br>|peso colocado em<br>|direita de modo que o<br>|Mantém meio ajoelhado com um apoio de braço por uma contagem de 10.|1|
|(esquerda)|estar próximo a fim<br>de garantir a|um joelho e o pé<br>oposto e as nádegas|pé fique apoiado no<br>chão sem usar os|Impossível.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
||segurança do<br>paciente. É permitido<br>o uso de banco/<br>bancada para apoio<br>de um braço ou do<br>próprio corpo.|<br>afastadas da parte<br>inferior da perna. A<br>meia esquerda<br>ajoelhada é com o<br>peso apoiado no<br>joelho esquerdo e o<br>pé direito para a<br>frente. Alinhamento<br>não é um critério.|braços<br>e<br>segurar contando até<br>10?|||
|||De pé em ambos os||Capaz de ficar com os braços livres.|2|
|||pés, tomando todo o||Capaz de transferir o peso de ambos os joelhos (com ou sem apoio de braço).|1|
|||peso de forma||||
|**25 –**Ajoelhado||independente, a||||
|alto para em pé,||postura não é|Você consegue se|||
|conduzindo com<br>a perna esquerda<br>(através da|Ajoelhado alto e os<br>braços livres.|importante. Pode<br>precisar de<br>demonstração.|levantar dessa<br>posição começando<br>com a perna esquerda|Impossível.|0|
|metade do joelho<br>direito).||Tenha um banco por<br>perto caso o<br>paciente precise de<br>apoio para<br>equilíbrio ou força.|sem usar as mãos?|||
|**26 –**Ajoelhado|Ajoelhado alto e os|De pé em ambos os|Você consegue se|Capaz de ficar com os braços livres.|2|
|alto para em pé,|<br>braços livres.|pés, tomando todo o|levantar dessa|Capaz de transferir o peso de ambos os joelhos (com ou sem apoio de braço).|1|
|conduzindo com||peso de forma|posição começando|Impossível.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
|a perna direita<br>(através da<br>metade do joelho<br>esquerdo)||independente, a<br>postura não é<br>importante. Pode<br>precisar de<br>demonstração.<br>Tenha um banco por<br>perto caso o<br>paciente precise de<br>apoio para<br>equilíbrio ou força.|<br>com a perna direita<br>sem usar as mãos?|||
||Ficar descalço em um|||Capaz de sentar-se com os braços livres e sem colapso, de maneira controlada.|2|
||piso ou colchonete<br>|Sentar-se em||Senta-se no chão usando as mãos no chão/corpo ou cai.|1|
|**27 -**De pé para<br>sentar no chão|nivelado. Para avaliar<br>este item, o paciente<br>deve ser capaz de se<br>manter em pé<br>independente, sem<br>apoio de braço.<br>Proteja o paciente por<br>segurança.|contato com o<br>colchonete. As<br>pernas devem ser<br>posicionadas na<br>frente do corpo,<br>porém a posição<br>precisa não importa.|Consegue sentar-se<br>no chão de forma<br>controlada/segura<br>quando em pé? Tente<br>não usar os braços.|Impossível.|0|
||Descalço em pé em|Posição de|Você pode agachar?|Capaz de agachar com quadril e joelhos flexionados a mais de 90° e os braços livres.|2|
|**28 -**|um piso ou carpete|agachamento|Finja que você vai se|Inicia o agachamento em ambos os joelhos (10° a <90°), usa apoio de braço.|1|
|Agachamento|nivelado. Proteja o<br>paciente por<br>segurança. Nenhuma|definida como<br>quadris e joelhos<br>flexionados a mais|sentar em um assento<br>muito baixo, apenas<br>desça o máximo que|Incapaz decontrolar<br>ou iniciar.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
||órtese deve ser usada.|de 90°.|conseguir para<br>levantar-se sozinho.|||
||Descalço em piso|||Salta pelo menos 30 cm com ambos os pés simultaneamente.|2|
||plano e independente.|||Salta entre 5-28 cm com ambos os pés simultaneamente.|1|
||Posicione o paciente<br>em pé|Deve ter pousado|Você consegue pular<br>o mais lone ue|||
|**29 -**Saltar 30 cm<br>a frente.|<br>confortavelmente na<br>frente de duas linhas<br>paralelas (30 cm de<br>distância no chão).<br>Proteja o paciente por<br>segurança.|sem uso de apoio de<br>braço e sem cair<br>para frente.|g q<br>puder, com os dois<br>pés, desta linha até a<br>outra linha?|Incapaz de iniciar o salto com os dois pés simultaneamente|0|
|||De pé no topo da|Você consegue subir|Sobe quatro degraus, com auxílio de um corrimão, alternando os pés.|2|
|**30 -**Subir quatro<br>degraus com|Ficar independente e<br>|escada, ambos os<br>pés no degrau mais<br>|<br>os degraus? Você<br>pode usar o corrimão|Sobe 2-4 degrauscom auxílio de um<br>corrimão, qualquer padrão.|1|
|auxílio do<br>corrimão.|descalço na base dos<br>quatro degraus|alto. Pode usar o<br>corrimão para<br>suporte, se<br>necessário.|(pode usar as duas<br>mãos em um<br>corrimão).|Não é possível subir 2 degraus usando apenas um corrimão.|0|
|||De pé na base dos|Você consegue|Desce quatro degraus, com auxílio de um corrimão, alternando os pés.|2|
|**31 -**Descer<br>|Ficar independente e|quatro degraus,<br>|descer os degraus?<br>|Desce 2-4 degraus com auxílio de um corrimão, qualquer padrão.|1|
|quatro degraus<br>com auxílio do<br>corrimão.|descalço no topo dos<br>quatro degraus.|ambos os pés no<br>chão. Pode usar o<br>corrimão para<br>suporte, se|Você pode usar o<br>corrimão (pode usar<br>as duas mãos em um<br>corrimão).|Não é possível descer 2 degraus usando apenas um corrimão.|0|  
|**Critério**|**Posição inicial**|**Posição final**|**Instrução**|**Grau de resposta**|**Pontuação**|
|---|---|---|---|---|---|
|||necessário.||||
|**32-**Subir quatro<br>degraus sem|Ficar independente e<br>descalo na base dos|De pé no topo da<br>escada, ambos os|Você pode subir os<br>degraus? Desta vez,|Sobre quatro degraus com os braços livres (sem suporte e sem auxílio do corrimão)<br>alternando os pés.|2|
|auxílio do<br>|ç<br>quatro degraus.|pés no degrau mais<br>|tente não usar o<br>|Sobre 2-4 degraus com os braços livres, qualquer padrão.|1|
|corrimão.||alto.|corrimão.|Incapaz de subir 2 degraus sem auxílio dos braços.|0|
|**33 -**Descer<br>quatro degraus|Ficar independente e<br>descalo no too dos|De pé na base dos<br>quatro degraus,|Você pode subir os<br>degraus? Desta vez,|Desce quatro degraus com os braços livres (sem suporte e sem auxílio do corrimão)<br>alternando os pés.|2|
|sem auxílio do|ç  p<br>quatro degraus.|ambos os pés no|tente não usar o|Desce 2-4 degraus com os braços livres, qualquer padrão.|1|
|corrimão||chão.|corrimão.|Incapaz de descer 2 degraus sem auxílio dos braços.|0|  
Este documento é uma tradução livre da Escala Hammersmith Functional Motor Scale Expanded for SMA (HFMSE). Não é validada nem substitui a versão original, em inglês, disponível no endereço eletrônico:  
<u>http://columbiasma.org/docs/HFMSE_2019_Manual.pdf.</u>  
**Fonte** : Portaria Conjunta SAES/SCTIE/MS n° 03 - 18/01/2022

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **VERSÃO BRASILEIRA DA ESCALA CHOP INTEND** -->
|**Item**|**Observação**|
|---|---|
|1,2|Observe durante o teste|
|1|Movimento antigravitacional do ombro|
|1|Consegue retirar o cotovelo da superfície|
|1|Consegue retirar a mão e o antebraço da superfície|
|2|Movimento antigravitacional do quadril|
|2|Consegue retirar os joelhos e os pés da superfície|
|2|Movimento antigravitacional de adução e rotação interna do quadril|
|2|Joelhos fora da superfície|
|2|Movimento ativo do joelho sem ação da gravidade|
|3|Força do aperto de mão|
|3|Observe quando a criança começa a perder a força de preensão manual.|
|4|Vira a cabeça até parte do caminho de volta para a linha média|
|6|Iniciado a partir de|
|6|Para permitir que a criança tente rodar o corpo|
|6,7|Rolar para longe do lado testado|
|7|Permite a criança a sair da rotação|
|7|Endireitamento lateral da cabeça|
|8|Conter o braço inferior se necessário|
|8|Alcança prontamente um brinquedo apresentado no comprimento do braço no nível do ombro.|
|8|Libera a mão da superfície com movimento antigravitacional do braço|
|9|Flexão do ombro e flexão do cotovelo|
|10|Sentado no colo ou na borda do tablado com suporte na cabeça e no tronco reclinado em 20 graus|
|10|Fazer cócegas na superfície plantar do pé|
|11|Virado para a frente|
|11|Tocar o pé ou beliscar o dedo do pé|
|12|Colocar a criança sentada em anel com a cabeça ereta e dar assistência nos ombros (na frente e atrás).|
|12|Pode haver um atraso no escore dos graus 1 e 4 até ofinal do teste|
|12|Alcança a cabeça na vertical partindo da flexão e gira a cabeça de um lado para outro|
|12|Controle instável com a cabeça balançando|
|12|A cabeça fica pendurada|
|13.14|Fazer o escore com o item|
|15.16|Mantido por uma mão no abdômen superior|
|15|Tocar ao longo da coluna do pescoço até o sacro|
|16|Curvatura espinhal|
|16|Tocar paraespinhais toracolombares à direita e à esquerda.|
|16|Fazer cocégas no abdômen ou nos pés ou inclinar a criança com um Galant integrado|  
**Fonte** : Alves et al. (2023)<sup>73</sup>  
51

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Alteração pós-publicação** -->
Depois da publicação da Portaria Conjunta SAES-SECTICS/MS nº 3, de 20 de março de 2025, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Atrofia Muscular Espinhal 5q tipos 1 e 2, considerando que, conforme bula aprovada em setembro de 2025, o risdiplam obteve aprovação da Anvisa para o uso em crianças após o nascimento, portanto essas informações foram atualizadas no PCDT.  
À 114ª Reunião Ordinária da Conitec, em novembro de 2022, foi recomendado que, se houvesse a aprovação da Anvisa para o uso do risdiplam em pacientes menores de dois meses até a publicação do PCDT, essas informações seriam atualizadas no Protocolo. Assim, com a atualização da faixa etária na bula, a informação foi atualizada. Adicionalmente, foi incluída orientação acerca da administração de onasemnogeno abeparvoveque no item Regulação/Controle/Avaliação pelo Gestor.  
O tema foi apresentado como informe à 130ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 18/11/2025.  
O presente Apêndice consiste no documento de trabalho do Grupo Elaborador do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Atrofia muscular Espinhal 5q tipos 1 e 2 e descreve a metodologia de busca das evidências científicas tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **1 - Público-alvo, cenário e população-alvo do Protocolo.** -->
Este PCDT destina-se aos profissionais da saúde envolvidos na atenção ao paciente com atrofia muscular espinhal (AME) 5q tipos 1 e 2, como médicos, enfermeiros e demais profissionais que atuam nos diferentes níveis de atenção à saúde, ambulatorial e hospitalar, do Sistema Único de Saúde (SUS).  
Os pessoas com AME 5q tipo 1B/C e tipo 2, com diagnóstico genético confirmado, sem necessidade de ventilação mecânica invasiva permanente, são a sua população-alvo.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **2 - Metodologia para elaboração do Protocolo** -->
A elaboração da primeira versão deste Protocolo (Portaria Conjunta SAES-SCTIE/MS nº 15, de 22 de outubro de 2019) foi uma das condicionantes previstas para a incorporação do nusinersena (Portaria SCTIE/MS nº 24 de 24 de abril de 2019). À época, a Conitec recomendou a incorporação do medicamento para AME do tipo 1, forma mais grave e mais prevalente da doença, que representa 58% do total dos diagnósticos de AME no Brasil.  
O escopo do PCDT foi estabelecido em reunião que ocorreu em abril de 2019 com a presença de médicos neurologistas, representantes do comitê gestor e do grupo elaborador. Este escopo abrangia uma questão clínica e foi validado por painel de especialistas em reunião que ocorreu em julho de 2019.  
O grupo elaborador deste PCDT seguiu o processo preconizado pelo Manual de Desenvolvimento de Diretrizes da Organização Mundial da Saúde<sup>1</sup> e pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>2</sup> . O PCDT foi desenvolvido com base na metodologia GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), seguindo os passos descritos no Guidelines International Network - GIN ( _McMaster Guideline Development Checklist_ ) 3.  
Compuseram o grupo elaborador representantes do Projeto de Desenvolvimento de Diretrizes Clínico assistenciais para o SUS, do CCATES/UFMG, gestores da saúde, profissionais da saúde e representantes de sociedades de especialidades médicas  
52  
e de associações de pacientes. Os integrantes declararam não ter qualquer conflito de interesses na elaboração do PCDT.  
Em dezembro de 2021, o PCDT foi atualizado (Portaria Conjunta SAES-SCTIE/MS nº 03, de 18 de janeiro de 2022), devido à publicação da Portaria SCTIE/MS nº 26, de 1° de junho de 2021, que incorporou o nusinersena para tratamento da atrofia muscular espinhal 5q tipo 2, com diagnóstico até os 18 meses de idade.  
Em novembro de 2022, o PCDT da Atrofia Muscular Espinhal (AME) tipos 1 e 2 foi atualizado (Portaria Conjunta SAESSECTICS/MS nº 6, de 15 de maio de 2023) devido à publicação da Portaria SCTIE/MS nº 17, de 11 de março de 2022, a qual incorporou o risdiplam para tratamento da Atrofia Muscular Espinhal tipo 2 e da Portaria SCTIE/MS nº 19, de 11 de março de 2022 , a qual incorporou o risdiplam para o tratamento da Atrofia Muscular Espinhal tipo 1 no âmbito do Sistema Único de Saúde .  
A presente atualização do PCDT da AME 5q tipos 1 e 2 é uma demanda proveniente da publicação da Portaria SCTIE/MS nº 172, de 06 de dezembro de 2022 que incorporou o onasemnogeno abeparvoveque para o tratamento de pacientes pediátricos até 6 meses de idade com Atrofia Muscular Espinhal do tipo 1 que estejam fora da ventilação invasiva acima de 16 horas por dia.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **3 - Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Atrofia Muscular Espinhal (AME) 5q tipos 1 e 2 foi apresentada na 108ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em agosto de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS) e da Secretaria de Vigilância em Saúde e Ambiente (SVSA). Não foram apontadas necessidades de ajustes no texto.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **4 - Busca das evidências e recomendações** -->
Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas e um resumo das evidências que foram avaliadas pela Conitec.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **QUESTÃO 1: NUSINERSENA É EFICAZ E SEGURO PARA O TRATAMENTO DE PACIENTES COM DIAGNÓSTICO DE AME 5Q QUANDO COMPARADO AO PLACEBO?** -->
Para responder à questão sobre uso de nusinersena para AME 5q, foi realizada uma revisão sistemática sobre a eficácia, efetividade, segurança e custo-efetividade do uso de nusinersena para a AME 5q (Quadro A)<sup>4</sup> . A busca de literatura foi realizada nas bases de dados MEDLINE (via PubMed), EMBASE, Cochrane e Lilacs (Quadro B). A revisão foi realizada por dois revisores que avaliaram independentemente os títulos e resumos dos artigos, determinaram a elegibilidade e extraíram os dados e os sumarizaram. A evidência foi sintetizada narrativamente e resumida usando estatísticas descritivas. Em caráter complementar, foi realizada a busca manual por estudos relevantes entre as referências dos estudos inicialmente selecionados. Entre os desfechos avaliados estão sobrevida, sobrevida livre de evento (morte ou uso de ventilação mecânica permanente), qualidade de vida, uso de ventilação mecânica permanente, eventos adversos, número de hospitalizações e melhoras no escore das escalas motoras (Quadro A).  
**Quadro A** - Pergunta estruturada utilizada para responder à questão sobre uso de nusinersena para AME 5q  
|P|População|Pacientes com AME 5q|
|---|---|---|
|I|Intervenção|Nusinersena|
|C|Comparadores|Controle não ativo ou tratamento convencional|  
|O|(_Outcomes_) Desfechos|De maior relevância: sobrevida, sobrevida livre de evento (morte ou uso de<br>ventilação mecânica permanente), qualidade de vida, uso de ventilação mecânica<br>permanente, EA.<br>De menor relevância: número de hospitalizações, melhoras no escore das escalas<br>motoras|
|---|---|---|
|S|(_Study_) Tipo de estudo|Revisões  sistemáticas (RS) , ensaios clínicos randomizados (ECR) fase III e<br>estudos de coorte (concorrentes e não concorrentes)|  
**Quadro B** - Estratégias de busca de evidências nas base de dados  
|**Bases**|**Estratégia de Busca**|**Número**<br>**de**<br>**artigos**<br>**Recuperados**|
|---|---|---|
||(("Muscular Atrophy, Spinal"[Mesh]) OR ((Muscular Atrophy,<br>Spinal[Text Word] OR Atrophy, Spinal Muscular[Text Word] OR Spinal<br>Amyotrophy[Text Word] OR Amyotrophies, Spinal[Text Word] OR<br>Amyotrophy, Spinal[Text Word] OR Spinal Amyotrophies[Text Word]<br>OR Spinal Muscular Atrophy[Text Word] OR Distal Spinal Muscular<br>Atrophy[Text Word] OR Spinal Muscular Atrophy, Distal[Text Word]<br>OR Hereditary Motor Neuronopathy[Text Word] OR Hereditary Motor<br>Neuronopathies[Text Word] OR Motor Neuronopathies, Hereditary[Text<br>Word] OR Motor Neuronopathy, Hereditary[Text Word] OR<br>Neuronopathies, Hereditary Motor[Text Word] OR Neuronopathy,<br>Hereditary Motor[Text Word] OR Scapuloperoneal Form of Spinal<br>Muscular Atrophy[Text Word] OR Spinal Muscular Atrophy,<br>Scapuloperoneal Form[Text Word] OR Spinal Muscular<br>Atrophy, Scapuloperoneal[Text Word] OR Amyotrophy, Neurogenic||
|MEDLINE<br>(via Pubmed)|Scapuloperoneal, New England Type[Text Word] OR Scapuloperoneal<br>Spinal Muscular Atrophy[Text Word] OR Oculopharyngeal Spinal<br>Muscular Atrophy[Text Word] OR Spinal Muscular Atrophy,<br>Oculopharyngeal[Text Word] OR Progressive Muscular Atrophy[Text<br>Word] OR Atrophies, Progressive Muscular[Text Word] OR Atrophy,<br>Progressive<br>Muscular[Text<br>Word]<br>OR<br>Muscular<br>Atrophies,<br>Progressive[Text Word] OR Muscular Atrophy, Progressive[Text Word]<br>OR Progressive Muscular Atrophies[Text Word] OR Progressive<br>Myelopathic Muscular Atrophy[Text Word] OR Myelopathic Muscular<br>Atrophy, Progressive[Text Word] OR Progressive Proximal Myelopathic<br>Muscular Atrophy[Text Word] OR Proximal Myelopathic Muscular<br>Atrophy, Progressive[Text Word] OR Bulbospinal Neuronopathy[Text|125|
||Word]<br>OR<br>Bulbospinal<br>Neuronopathies[Text<br>Word]<br>OR||
||Neuronopathies,<br>Bulbospinal[Text<br>Word]<br>OR<br>Neuronopathy,<br>Bulbospinal[Text Word] OR Myelopathic Muscular Atrophy[Text<br>Word] OR Atrophy, Myelopathic Muscular[Text Word] OR Muscular||  
|**Bases**|**Estratégia de Busca**|**Número**<br>**de**<br>**artigos**<br>**Recuperados**|
|---|---|---|
||Atrophy, Myelopathic[Text Word] OR Adult-Onset Spinal Muscular<br>Atrophy[Text Word] OR Adult Onset Spinal Muscular Atrophy[Text<br>Word] OR Muscular Atrophy, Adult Spinal[Text Word] OR Adult Spinal<br>Muscular Atrophy[Text Word]))) AND ((("nusinersen" [Supplementary<br>Concept]) OR ((nusinersen[Text Word]) OR ((ASO-10-27[Text Word]<br>OR ISIS-SMN(Rx)[Text Word] OR ISIS-SMNRx[Text Word] OR ISIS<br>396443[Text Word] OR SPINRAZA[Text Word])))))||
||#1<br>MeSH descriptor: [Muscular Atrophy, Spinal] explode all trees<br>#2<br>Muscular<br>Atrophy,<br>Spinal<br>#3<br>#1 OR #2||
|Cochrane|#4<br>nusinersen<br>#5<br>INN-nusinersen<br>#6<br>Spinraza<br>#7<br>#4 OR #5 OR #6<br>#8<br>#3 AND #7|16|
||(tw:((tw:("MUSCULAR<br>ATROPHY,<br>SPINAL"))<br>OR<br>(tw:("MUSCULAR<br>ATROPHY,<br>SPINAL,<br>INFANTILE"))<br>OR<br>(tw:("SPINAL AMYOTROPHY")) OR (tw:("HEREDITARY MOTOR<br>NEURONOPATHY")) OR (tw:("SCAPULOPERONEAL FORM OF<br>SPINAL MUSCULAR ATROPHY")) OR (tw:("AMYOTROPHY,<br>NEUROGENIC SCAPULOPERONEAL, NEW ENGLAND TYPE"))<br>OR<br>(tw:("SCAPULOPERONEAL<br>SPINAL<br>MUSCULAR<br>ATROPHY"))<br>OR||
|Lilacs|(tw:("OCULOPHARYNGEAL SPINAL MUSCULAR ATROPHY"))<br>OR<br>(tw:("SPINAL<br>MUSCULAR<br>ATROPHY,<br>OCULOPHARYNGEAL"))<br>OR<br>(tw:("PROGRESSIVE<br>MUSCULAR<br>ATROPHY"))<br>OR<br>(tw:("PROGRESSIVE<br>MYELOPATHIC<br>MUSCULAR<br>ATROPHY"))<br>OR<br>(tw:("BULBOSPINAL NEURONOPATHY")) OR (tw:("ADULT-<br>ONSET SPINAL MUSCULAR ATROPHY")) OR (tw:("MUSCULAR<br>ATROPHY, ADULT SPINAL")))) AND<br>(tw:((tw:(Nusinersen)) OR (tw:(SPINRAZA))))|02|
|EMBASE|((EMB.EXACT.EXPLODE("spinal<br>muscular<br>atrophy")<br>OR<br>EMB.EXACT.EXPLODE("hereditary spinal muscular atrophy")) OR<br>(‘type IV spinal muscular atrophy’) OR (‘spinal muscular atrophy type<br>I’) OR (‘spinal muscular atrophy type II’) OR (‘spinal muscular atrophy<br>type III’) OR (‘spinal muscular atrophy type IV’) OR (‘spinal muscular<br>atrophy, hereditary’) OR (‘type 1 spinal muscular atrophy’) OR (‘type 2<br>spinal muscular atrophy’) OR (‘type 3 spinal muscular atrophy’) OR|286|  
|**Bases**|**Estratégia de Busca**|**Número**<br>**Recupera**|**de**<br>**dos**|**artigos**|
|---|---|---|---|---|
||(‘type 4 spinal muscular atrophy’) OR (‘type I spinal muscular atrophy’)||||
||OR (‘type II spinal muscular atrophy’) OR (‘type III spinal muscular||||
||atrophy’)) AND (EMB.EXACT.EXPLODE("nusinersen") OR (‘isis||||
||396443’) OR (‘isis396443’) OR (‘spinraza’))||||

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Seleção das evidências** -->
Para responder à questão sobre uso de nusinersena para AME 5q, após a atualização da busca nas bases de dados, 429 publicações foram recuperadas, 119 tratavam-se de duplicatas e 32 foram lidos na íntegra. Dois revisores independentes selecionaram estudos para leitura na íntegra aplicando os critérios de elegibilidade e, nos casos de divergências, um terceiro revisor procedeu à avaliação. Ao final, 10 estudos que respondiam à pergunta PICO foram incluídos (Figura A).  
**Figura A** - Fluxograma de seleção das evidências  
<!-- Start of picture text -->
nas bases de dados: 429<br>8g Publicacdes identificadas através da pesquisa<br>Sg PUBMED = 125<br>5 EMBASE= 286<br>3 LILACS = 02<br>Cochrane = 16<br>7<br>3sS PublicacBes apés remogdo de duplicatas: Publicagdes excluidas:<br>3a 310 119<br>Publicacdes excluidas segundo critérios<br>- de exclusio:<br>=3 Publicagdes selecionadas para leitura Tipo de estudo: 14<br>2 completa: 32 Tipo de desfecho: 8<br>=]<br>2<br>a<br>”<br>2AJ Estudos incluidos:<br>3 10<br>&<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Conclusão sobre as evidências** -->
Após revisão sistemática da literatura, dois ECR (estudos clínicos randomizados), um estudo de extensão e seis relatos de coorte foram incluídos<sup>4</sup> . Dos ECR, um avaliou o uso de nusinersena em pacientes com AME de início precoce (ou tipo 1) e o outro AME de início tardio (tipos 2 e 3).  
O ECR que avaliou o nusinersena para AME 5q tipo 1 (ENDEAR) incluiu apenas pacientes com diagnóstico genético da  
doença, duas cópias do gene SMN2, início dos sintomas até os seis meses de idade, adequadamente nutridos e hidratados. Foi identificada diferença estatisticamente significante entre o grupo em uso do medicamento e o grupo controle no desfecho primário de função motora, medido por HINE 2 ( _Hammersmith Infant Neurological Exam 2_ ). O mesmo foi observado em alguns desfechos definidos como secundários no estudo, como sobrevida livre de evento, CHOP INTEND e morte. Já para os desfechos proporção de pacientes que passaram a requerer ventilação mecânica e incidência de EA não houve diferença estatisticamente significante entre os dois grupos. No material suplementar do estudo, os autores referenciaram que: “o suporte ventilatório crônico por mais de 16 horas por dia, durante 2 a 4 semanas, foi considerado o ponto de corte em que os bebês provavelmente não vão recuperar habilidades respiratórias suficientes para tornar desnecessário o suporte ventilatório, de acordo com a legislação europeia”<sup>5</sup> . Quando feita uma análise de subgrupo entre crianças com menos de 13 semanas de duração da doença versus com mais de 13 semanas, observou-se que aquelas com menor tempo de duração tiveram melhor resultado em uso do nusinersena em relação à mortalidade e uso de ventilação mecânica. O estudo de extensão que continuou acompanhando os pacientes do estudo ENDEAR observou uma mudança média total no escore de HINE- 2, da linha de base ao final do estudo de 1,1 para pacientes previamente no grupo controle e de 5,8 para aqueles que receberam nusinersena desde o ENDEAR. A mediana do tempo até a morte ou ventilação mecânica para os pacientes do grupo controle no estudo ENDEAR foi de 22,6 semanas versus 73 semanas para aqueles do grupo nusinersena<sup>6</sup> .  
O outro ECR, que avaliou pacientes com AME 5q de início tardio (CHERISH), incluiu pacientes com início da manifestação dos sintomas a partir do sexto mês de vida, comprovado geneticamente. O ganho motor foi avaliado pela escala HFMSE, sendo maior no grupo nusinersena quando comparado ao controle. Os desfechos secundários não apresentaram diferenças estatisticamente significantes, assim como a segurança, já que 93% do grupo recebendo nusinersena e 100% do grupo controle apresentaram EA<sup>7</sup> .  
Os estudos que avaliaram a efetividade correspondiam a relatos de EAP de cinco países, todos relacionados com AME 5q tipo 1<sup>8-13</sup> . A maioria teve duração de seis meses, exceto o estudo de Farrar et al<sup>11</sup> , que durou 10 meses. Assim como no ECR de Finkel et al<sup>5</sup> , foram observadas maiores melhoras no escore CHOP INTEND nas crianças que iniciaram o tratamento até os sete meses de idade. Quanto ao HINE 2, os pacientes atingiram uma melhora variando de 1,26 a 1,5 após o período de uso do nusinersena. Em relação à função respiratória, 10% a 18% dos pacientes em tratamento passaram a necessitar de suporte ventilatório.  
Dessa forma, os resultados sugerem um benefício modesto do uso de nusinersena em relação ao controle para pacientes com AME 5q tipo 1, ou seja, de início precoce, com idade inferior a seis meses no início dos sintomas e até sete meses no início do tratamento.  
**RECOMENDAÇÃO DA CONITEC** : recomendar a incorporação no SUS do nusinersena para AME 5q tipo 1, para pacientes com diagnóstico genético confirmatório que não estejam em ventilação mecânica invasiva permanente contínua (24 horas por dia), coforme Relatório de Recomendação nº 449/2019 disponível em: <u>http://conitec.gov.br/images/Relatorios/2019/Relatorio_Nusinersena_AME5q.pdf</u>

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Referências** -->
1. WHO Library. WHO handbook for guideline development. Geneva: WHO Press, 2012.  
2. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretrizes metodológicas: Elaboração de Diretrizes Clínicas[recurso eletrônico] / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Gestão e Incorporação de Tecnologias em Saúde. – Brasília : Ministério da Saúde, 2016.  
3. SCHUNEMANN, H.J. et al. Grading quality of evidence and strength of recommendations for diagnostics tests and strategies. Britsh Medical Journal, London, v.336, n.7653, p.1106-1110, 2008.  
4. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Relatório de recomendação nº 449: Nusinersena para Atrofia Muscular Espinhal 5q. Brasília, Ministério da Saúde. Abril de 2019.  
5. FINKEL R.S.; MERCURI E.; DARRAS B.T., et al. Nusinersen versus Sham Control in Infantile-Onset Spinal Muscular Atrophy. New England Journal of Medicine.2017;377:1723-32. DOI: 10.1056/NEJMoa1702752.  
6. MERCURI E., DARRAS B.T., CHIRIBOGA C.A., et al. Nusinersen versus Sham Control in Later-Onset Spinal Muscular Atrophy. New England Journal of Medicine. 2018;378:625-35. DOI: 10.1056/NEJMoa1710504.  
7. PECHMANN A, LANGERA T, SCHORLINGA D. Evaluation of Children with SMA Type 1 Under Treatment with Nusinersen within the Expanded Access Program in Germany. _Journal of_ Neuromuscular Diseases. 2018. DOI 10.3233/JND180315.  
8. ARAGON-GAWINSKA, K.; SEFERIAN, A.M; DARON, A. et al. Nusinersen in spinal muscular atrophy type 1 patients older than 7 months A cohort study. Neurology. 2018;00:1-7. doi:10.1212/WNL.0000000000006281.  
9. PANE, N. PALERMO, C. MESSINA, S. et al. Nusinersen in type 1 SMA infants, children and young adults: Preliminary results on motor function. NeuromusculDisord. 2018 Jul;28(7):582-585. doi: 10.1016/j.nmd.2018.05.010. Epub 2018 Jun 1.  
- 10.MESSINA S., PANE M., SANSONE V., et al. Expanded access program with Nusinersen in SMA type I in Italy: Strengths and pitfalls of a successful experience. Neuromuscular Disorders. 2017 Dec;27(12):1084-1086. doi: 10.1016/j.nmd.2017.09.006  
- 11.FARRAR, M.A, TEOH H.L, CAREY, K.A, et al. Nusinersen for SMA: expanded access programme. Journal of Neurology, Neurosurgery and Psychiatry.2018;0:1–6. DOI:10.1136/ jnnp-2017- 317412.  
- 12.SCOTO M. _et al_ . The use of nusinersen in the “real world”: the UK and Ireland experience with the expanded access program (EAP). MND03. Abstracts of the 11th UK Neuromuscular Translational Research Conference / Neuromuscular Disorder 28S1 (2018) S5–S42.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Busca de evidências** -->
A avaliação do uso de nusinersena na AME 5q tipo 2 foi realizada por meio de uma revisão sistemática sobre a eficácia, efetividade, segurança e custo-efetividade do uso de nusinersena para a AME 5q tipo 2. A revisão foi realizada por dois revisores que avaliaram independentemente os títulos e resumos dos artigos, determinaram a elegibilidade e extraíram os dados e os sumarizaram. A evidência foi sintetizada narrativamente e resumida usando estatísticas descritivas.  
A literatura foi revisada por meio de pergunta PICO ( **Quadro C** ). A estratégia de busca está descrita no **Quadro D** .  
**Quadro C** - Pergunta estruturada utilizada para responder à questão sobre uso de nusinersena para AME 5q tipo 2  
|P|População|Pacientes com AME 5q tipo 2|
|---|---|---|
|I|Intervenção|Nusinersena|
|C|Comparadores|Controle não ativo ou tratamento convencional|
|O|(_Outcomes_) Desfechos|●|
|||Eficácia e efetividade: sobrevida livre de evento, função motora;<br>●|  
|||Segurança: incidência de eventos adversos.|
|---|---|---|
|S|(_Study_) Tipo de estudo|Revisões sistemáticas com ou sem meta-análises, ensaios clínicos fase II e III,|
|||estudos observacionais e estudos de mundo real (fase IV).|  
**Quadro D** - Estratégias de busca de evidências nas base de dados  
|**Bases de dados**|**Estratégia de busca**|**Número**<br>**de**<br>**artigos**<br>**recuperados**|
|---|---|---|
|**MEDLINE (via**<br>**PubMed)**|((‘Muscular Atrophy, Spinal’[Mesh]) OR ((Muscular Atrophy, Spinal[Text Word] OR<br>Atrophy, Spinal Muscular[Text Word] OR Spinal Amyotrophy[Text Word] OR<br>Amyotrophies, Spinal[Text Word] OR Amyotrophy, Spinal[Text Word] OR Spinal<br>Amyotrophies[Text Word] OR Spinal Muscular Atrophy[Text Word] OR Distal<br>Spinal Muscular Atrophy[Text Word] OR Spinal Muscular Atrophy, Distal[Text<br>Word] OR Hereditary Motor Neuronopathy[Text Word] OR Hereditary Motor<br>Neuronopathies[Text Word] OR Motor Neuronopathies, Hereditary[Text Word] OR<br>Motor Neuronopathy, Hereditary[Text Word] OR Neuronopathies, Hereditary<br>Motor[Text Word] OR Neuronopathy, Hereditary Motor[Text Word] OR<br>Scapuloperoneal Form of Spinal Muscular Atrophy[Text Word] OR Spinal Muscular<br>Atrophy, Scapuloperoneal Form[Text Word] OR Spinal Muscular Atrophy,<br>Scapuloperoneal[Text Word] OR Amyotrophy, Neurogenic Scapuloperoneal, New<br>England Type[Text Word] OR Scapuloperoneal Spinal Muscular Atrophy[Text Word]<br>OR Oculopharyngeal Spinal Muscular Atrophy[Text Word] OR Spinal Muscular<br>Atrophy, Oculopharyngeal[Text Word] OR Progressive Muscular Atrophy[Text<br>Word] OR Atrophies, Progressive Muscular[Text Word] OR Atrophy, Progressive<br>Muscular[Text Word] OR Muscular Atrophies, Progressive[Text Word] OR Muscular<br>Atrophy, Progressive[Text Word] OR Progressive Muscular Atrophies[Text Word]<br>OR Progressive Myelopathic Muscular Atrophy[Text Word] OR Myelopathic<br>Muscular Atrophy, Progressive[Text Word] OR Progressive Proximal Myelopathic<br>Muscular Atrophy[Text Word] OR Proximal Myelopathic Muscular Atrophy,<br>Progressive[Text Word] OR Bulbospinal Neuronopathy[Text Word] OR Bulbospinal<br>Neuronopathies[Text Word] OR Neuronopathies, Bulbospinal[Text Word] OR<br>Neuronopathy, Bulbospinal[Text Word] OR Myelopathic Muscular Atrophy[Text<br>Word] OR Atrophy, Myelopathic Muscular[Text Word] OR Muscular Atrophy,<br>Myelopathic[Text Word] OR Adult-Onset Spinal Muscular Atrophy[Text Word] OR|27|  
|**Bases de dados**|**Estratégia de busca**|**Número**<br>**de**<br>**artigos**<br>**recuperados**|
|---|---|---|
||Adult Onset Spinal Muscular Atrophy[Text Word] OR Muscular Atrophy, Adult<br>Spinal[Text Word] OR Adult Spinal Muscular Atrophy[Text Word]))) AND<br>(((‘nusinersen’[Supplementary Concept]) OR ((nusinersen[Text Word]) OR ((ASO-<br>10-27[Text Word] OR ISIS-SMN(Rx)[Text Word] OR ISIS-SMNRx[Text Word] OR<br>ISIS 396443[Text Word] OR SPINRAZA[Text Word])))))||
|**COCHRANE**|#1 MeSH descriptor: [Muscular Atrophy, Spinal] explode all trees<br>#2 Muscular Atrophy, Spinal<br>#3 Muscular Atrophy, Adult Spinal<br>#4 #1 OR #2 OR #3<br>#5 Nusinersen<br>#6 Spinraza<br>#7 #5 OR #6<br>#8 #4 AND #7|40|
|**EMBASE**<br>**Total**|((('spinal muscular atrophy'/exp OR 'spinal muscular atrophy') AND [embase]/lim) OR<br>(('hereditary spinal muscular atrophy'/exp OR 'hereditary spinal muscular atrophy')<br>AND [embase]/lim) OR (('type iv spinal muscular atrophy':ti,ab,kw OR 'spinal<br>muscular atrophy type i':ti,ab,kw OR 'spinal muscular atrophy type ii':ti,ab,kw OR<br>'spinal muscular atrophy type iii':ti,ab,kw OR 'spinal muscular atrophy type iv':ti,ab,kw<br>OR 'spinal muscular atrophy, hereditary':ti,ab,kw OR 'type 1 spinal muscular<br>atrophy':ti,ab,kw OR 'type 2 spinal muscular atrophy':ti,ab,kw OR 'type 3 spinal<br>muscular atrophy':ti,ab,kw OR 'type 4 spinal muscular atrophy':ti,ab,kw OR 'type i<br>spinal muscular atrophy':ti,ab,kw OR 'type ii spinal muscular atrophy':ti,ab,kw OR<br>'type<br>iii<br>spinal<br>muscular<br>atrophy':ti,ab,kw)<br>AND<br>[embase]/lim))<br>AND<br>((('nusinersen'/exp OR 'nusinersen') AND [embase]/lim) OR (('spinraza':ti,ab,kw OR<br>'isis 396443':ti,ab,kw) AND [embase]/lim)) AND [2019-2020]/py|457<br>**524**|

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Seleção das evidências** -->
Com base nos critérios de inclusão e exclusão, na estratégia de busca e nas referências dos artigos selecionados, foram incluídos 11 estudos, dos quais dois eram ensaios clínicos - um de fase 1b/2a aberto e um fase 3 controlado com placebo - e nove estudos observacionais (Figura B). O Quadro E apresenta os estudos incluídos e seus respectivos delineamentos.  
**Figura B** . Fluxograma de seleção das evidências.  
<!-- Start of picture text -->
Publicagées identificadas através da<br>pesquisa na linha de base: 642<br>Embase = 420<br>Pubmed = 182<br>Cochrane = 40<br>Duplicatas: 254<br>Publicagées selecionadas para leitura<br>de titulos e resumos: 388<br>Publicagdes excluidas: 368<br>Publicagées selecionadas para leitura<br>completa: 20<br>Excluidos segundo critérios<br>de incluso: 9<br>Estudos incluidos: 11<br>ECR fase 3=1<br>Ensaio clinico fase 1b/2a aberto = 1<br>Estudos observacionais = 8<br>Busca manual = 1<br><!-- End of picture text -->  
**Quadro E** . Estudos incluídos na revisão sistemática.  
|**Autor**||**Tipo de estudo**|**Ano**|
|---|---|---|---|
|1|Darras et al.|Ensaio clínico fase 1b/2a (_open-label_, multicêntrico e com escalonamento<br>de dose) (CS2) e de sua extensão (CS12)|2019|
|2|Mercuri et al|Ensaio clínico randomizado, controlado com placebo|2018|
|3|Hagenacker et al|Estudo observacional prospectivo|2020|  
|**Autor**||**Tipo de estudo**|**Ano**|
|---|---|---|---|
|4|Maggi et al.|Estudo observacional retrospectivo|2020|
|5|Mendonça et al.|Estudo observacional retrospectivo|2020|
|6|Moshe-Lilie et al|Estudo observacional retrospectivo|2020|
|7|Osmanovic et al|Estudo observacional prospectivo|2020|
|8|Szabó et al|Estudo observacional retrospectivo|2020|
|9|Veerapandiyan et al|Estudo observacional retrospectivo|2020|
|10|Yeo et al|Estudo observacional retrospectivo|2020|
|11|Walter et al.|Estudo observacional prospectivo|2019|

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Conclusão sobre as evidências** -->
Após busca sistematizada na literatura, um total de 11 estudos foram recuperados avaliando o uso de nusinersena para o tratamento de pacientes com AME 5q tipos 2 e 3. Dentre eles, apenas um ECR foi recuperado, sendo os outros um ensaio clínico fase 1b/2a e nove coortes. Essas evidências, entretanto, são limitadas a curtos períodos de administração e de acompanhamento, principalmente quando se considera a indicação do uso para pacientes com AME 5q de início tardio, que apresentam sobrevida mais longa quando comparados aos pacientes com AME 5q tipo 1. Há, ainda, uma grande incerteza com relação à eficácia, efetividade e segurança do nusinersena em longo prazo, já que o tempo médio de acompanhamento dos estudos varia de 10 a 24 meses. Como relatado pela própria bula aprovada pela autoridade sanitária para o medicamento: “estão disponíveis informações limitadas sobre a duração do efeito terapêutico e segurança do SPINRAZA® (nusinersena) após 3 anos de início do tratamento de Atrofia Muscular Espinhal (AME). A necessidade de continuação da terapia deve ser revisada regularmente e considerada de forma individual, dependendo das condições clínicas do paciente e da resposta ao tratamento”<sup>36</sup> .  
Outra limitação acerca dos estudos incluídos é a ausência de grupo comparador na maior parte deles. Dos 11 estudos avaliados, apenas os estudos de Moshe-Lilie et al. (2020)<sup>40</sup> , Mendonça et al. (2020)<sup>41</sup> e Mercuri et al. (2018)<sup>42</sup> apresentaram algum grupo comparador ou controle. Argumenta-se que o benefício poderia ser evidenciado pela simples não-progressão, ao que se esperaria tomando-se por base a história natural da doença. Todavia, diferenças no suporte clínico dos pacientes também podem influenciar a variação dos escores de função motora ao longo do tempo nos pacientes tratados com nusinersena. Tomar como referência a não-progressão da doença como principal benefício pode ser controverso, já que a doença é lentamente progressiva - especialmente para pacientes dos tipos 2 e 3 - e, segundo Moshe-Lilie e colaboradores (2020)<sup>40</sup> , a maior parte dos pacientes não tratados no estudo não apresentou declínio significativo da função motora em dois anos de acompanhamento.  
Considerando os resultados dos estudos, e que a maioria estratifica os resultados de acordo com o tipo de AME 5q de início tardio, optou-se por apresentar os desfechos neste relatório, sempre que possível, em pacientes com os tipos 2 e 3 separadamente. Isso foi motivado por algumas diferenças observadas entre estes pacientes, a saber:  
1) Diferença no tempo de sobrevida e expectativa de vida entre os tipos. Estudos de história natural sugerem que pacientes classificados com o tipo 2 apresentam uma expectativa de vida reduzida (em média, até 25 a 35 anos de idade) enquanto aqueles classificados com o tipo 3 apresentam expectativa de vida similar à da população em geral.<sup>1,11,43</sup>  
2) Os pacientes também apresentaram grandes diferenças com relação ao alcance de marcos motores. Nesse contexto, observou-se que algumas escalas foram mais sensíveis para avaliar um tipo do que outro. Um exemplo é a escala HFMSE, desfecho principal na maior parte das evidências, na qual pacientes com o tipo 2 alcançam maior diferença do escore observado na linha de base do que os pacientes com o tipo 3, provavelmente devido ao fato de pacientes com o tipo 3 já alcançarem marcos superiores e, consequentemente, maior escore na linha de base. Este último aspecto torna também complexa a tarefa de  
estabelecer medidas de desfecho e benefícios objetivos que se pretende alcançar com a terapia para os dois tipos de forma simultânea.  
3) grande diferença entre os pacientes com relação às características na linha de base dos estudos, como idade, número de cópias de SMN2, capacidade motora, capacidade de deambular, dentre outras características. No estudo CHERISH<sup>42</sup> , por exemplo, há a inclusão de pacientes mais jovens do que nos estudos observacionais, principalmente aqueles que incluem pacientes com o tipo 3.  
Com relação aos desfechos, não foram encontrados estudos que avaliassem ganho no tempo de sobrevida dos pacientes, e o principal desfecho avaliado foi a função motora, mensurada por diferentes escalas e ferramentas. O grande número de escalas diferentes utilizadas reflete a variabilidade do estadiamento da doença nos pacientes dos diferentes estudos. Este cenário torna complexa a percepção da dimensão do ganho proporcionado pelo medicamento, especialmente na ausência de um grupo comparador.  
A escala mais comumente utilizada foi HFMSE, que avalia a função motora de crianças e adultos com AME 5q capazes de sentar e andar. Estudos com pacientes acima de 30 anos apresentaram melhores resultados para o tipo 3 do que o tipo 2. Por outro lado, estudos com pacientes mais jovens (<10 anos de idade média) apresentaram melhores resultados para o tipo 2. Szabó et al. (2020)<sup>44</sup> apresenta correlação entre idade de início do tratamento e o escore HFMSE para pacientes com o tipo 2.  
As escalas ULM/RULM têm como objetivo avaliar o desempenho de membros superiores em pacientes com AME 5q. Apenas Darras et al. (2019)<sup>46</sup> utiliza a ULM, enquanto os demais utilizam sua versão revisada (RULM). Pacientes incluídos em Mercuri et al. (2019)<sup>42</sup> e Veerapandiyan et al. (2020)<sup>46</sup> apresentaram maior mudança de escore RULM e Darras et al. (2019)<sup>45</sup> no ULM quando comparado aos outros estudos. Estes estudos têm como característica pacientes mais jovens na linha de base. Pacientes do tipo 2 apresentaram maior diferença média na escala RULM que os do tipo 3. Por outro lado, em Maggi et al. (2020)<sup>47</sup> , os pacientes do tipo 3 deambulantes apresentaram aumento mediano de um ponto no escore em 10 meses e de dois pontos em 14 meses, ao passo que os não-deambulantes não apresentaram diferença no escore.  
O TC6M foi utilizado pelos estudos para avaliar a capacidade de deambulação dos pacientes - avaliado principalmente em pacientes com o tipo 3 e demonstraram aumentos na maioria dos estudos que avaliou este desfecho. Já o estudo de Yeo et al. (2020)<sup>48</sup> relatou estabilização.  
Com relação aos desfechos de segurança, os EA mais comuns foram aqueles relacionados à administração do medicamento. Os principais EA incluíram dor lombar, vômitos e cefaleia. Este foi também o principal motivo de interrupção do tratamento relatado nos estudos. Alguns pacientes acompanhados nos estudos observacionais não começaram ou interromperam o tratamento por receio de incertezas relacionadas ao uso do nusinersena em pacientes adultos, seja por ausência absoluta ou expressiva de benefícios que justificassem a exposição aos riscos e ao desconforto da administração via intratecal continuamente.<sup>40,47</sup>  
**RECOMENDAÇÃO FINAL DA CONITEC APÓS AUDIÊNCIA PÚBLICA** : recomendar a incorporação do nusinersena para o tratamento da atrofia muscular espinhal 5q tipo 2, com diagnóstico até os 18 meses de idade, conforme Protocolo Clínico e Diretrizes Terapêuticas do Ministério da Saúde; e pela não incorporação do nusinersena para tratamento da atrofia muscular espinhal 5q tipo 3, conforme Relatório de Recomendação nº 595/2021 disponível em: <u>http://conitec.gov.br/images/Relatorios/2021/20210602_Relatorio_595_nusinersena_AME5Q_2e3_P_26.pdf</u>

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Referências** -->
1. Moshe-lilie, O. et al. Nusinersen in adult patients with spinal muscular atrophy Observations from a single center. (2020) doi:10.1212/WNL.0000000000009914.  
2. Mendonça, R. H. et al. Real-World Data from Nusinersen Treatment for Patients with Later-Onset Spinal Muscular Atrophy: A Single Center Experience. J. Neuromuscul. Dis. 8, 101–108 (2021).  
3. Mercuri, E. et al. Long-term progression in type II spinal muscular atrophy. Neurology 93, e1241–e1247 (2019).  
4. Haataja, L. et al. Optimality score for the neurologic examination of the infant at 12 and 18 months of age. J. Pediatr. 135, 153–161 (1999).  
5. Szabó, L. et al. Efficacy of nusinersen in type 1, 2 and 3 spinal muscular atrophy: Real world data from Hungarian patients. Eur. J. Paediatr. Neurol. 1–6 (2020) doi:10.1016/j.ejpn.2020.05.002.  
6. Darras, B. T. et al. Nusinersen in later-onset spinal muscular atrophy: Long-term results from the phase 1/2 studies. Neurology 92, e2492–e2506 (2019).  
7. Veerapandiyan, A. et al. Nusinersen for older patients with spinal muscular atrophy: A real-world clinical setting experience. Muscle and Nerve 61, 222–226 (2020).  
8. Maggi, L. et al. Nusinersen safety and effects on motor function in adult spinal muscular atrophy type 2 and 3. J. Neurol. Neurosurg. Psychiatry jnnp-2020-323822 (2020) doi:10.1136/jnnp-2020-323822.  
9. Yeo, C. J. J., Simeone, S. D., Townsend, E. L., Zhang, R. Z. & Swoboda, K. J. Prospective Cohort Study of Nusinersen Treatment in Adults with Spinal Muscular Atrophy. J. Neuromuscul. Dis. 7, 257–268 (2020).

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **QUESTÃO 3: O USO DE RISDIPLAM É EFICAZ, SEGURO E CUSTO-EFETIVO EM PACIENTES COM ATROFIA MUSCULAR ESPINHAL TIPO 1 QUANDO COMPARADO AO TRATAMENTO DE SUPORTE OU A TRATAMENTOS ATIVOS ATUALMENTE DISPONÍVEIS NO SUS?** -->
Para responder à questão sobre uso de risdiplam a para AME 5q, foi realizada uma revisão sistemática (Quadro F). A atualização da busca foi realizada nas bases de dados MEDLINE (via PubMed), EMBASE, Cochrane e Lilacs (Quadro G). Em caráter complementar, foi realizada a busca manual por estudos relevantes entre as referências dos estudos inicialmente selecionados. Entre os desfechos avaliados estão sobrevida, sobrevida livre de evento (morte ou uso de ventilação mecânica permanente), qualidade de vida, uso de ventilação mecânica permanente, eventos adversos, número de hospitalizações e melhoras no escore das escalas motoras.  
**Quadro F** - Pergunta estruturada utilizada para responder à questão sobre uso de risdiplam para AME 5q  
|P|População|Pacientes AME tipo 1 sem ventilação mecânica invasiva permanente|
|---|---|---|
|I|Intervenção|Risdiplam|
|C|Comparadores|Controle ativo existente ou tratamento de suporte não medicamentoso|
|O|(_Outcomes_) Desfechos|De maior relevância:sobrevida, sobrevida livre de evento (morte ou uso de<br>ventilação mecânica permanente), qualidade de vida, uso de ventilação mecânica<br>permanente, efeitos adversos (EA).|
|||De menor relevância:número de hospitalizações, melhoras no escore das escalas<br>motoras|
|S|(_Study_) Tipo de estudo|Revisões sistemáticas, ensaios clínicos randomizados e estudos de coorte|

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Busca de evidências** -->
**Quadro G** - Estratégias de busca de evidências nas bases de dados  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|MEDLINE<br>(via Pubmed)|(("Muscular Atrophy, Spinal"[Mesh]) OR ((Muscular Atrophy, Spinal[Text<br>Word] OR Atrophy, Spinal Muscular[Text Word] OR Spinal Amyotrophy[Text<br>Word] OR Amyotrophies, Spinal[Text Word] OR Amyotrophy, Spinal[Text<br>Word] OR Spinal Amyotrophies[Text Word] OR Spinal Muscular Atrophy[Text<br>Word] OR Distal Spinal Muscular Atrophy[Text Word] OR Spinal Muscular<br>Atrophy, Distal[Text Word] OR Hereditary Motor Neuronopathy[Text Word]<br>OR Hereditary Motor Neuronopathies[Text Word] OR Motor Neuronopathies,<br>Hereditary[Text Word] OR Motor Neuronopathy, Hereditary[Text Word] OR<br>Neuronopathies, Hereditary Motor[Text Word] OR Neuronopathy, Hereditary<br>Motor[Text Word] OR Scapuloperoneal Form of Spinal Muscular Atrophy[Text<br>Word] OR Spinal Muscular Atrophy, Scapuloperoneal Form[Text Word] OR<br>Spinal Muscular Atrophy, Scapuloperoneal[Text Word] OR Amyotrophy,<br>Neurogenic<br>Scapuloperoneal,<br>New<br>England<br>Type[Text<br>Word]<br>OR<br>Scapuloperoneal Spinal Muscular Atrophy[Text Word] OR Oculopharyngeal<br>Spinal Muscular Atrophy[Text Word] OR Spinal Muscular Atrophy,<br>Oculopharyngeal[Text Word] OR Progressive Muscular Atrophy[Text Word]<br>OR Atrophies, Progressive Muscular[Text Word] OR Atrophy, Progressive<br>Muscular[Text Word] OR Muscular Atrophies, Progressive[Text Word] OR<br>Muscular Atrophy, Progressive[Text Word] OR Progressive Muscular<br>Atrophies[Text Word] OR Progressive Myelopathic Muscular Atrophy[Text<br>Word] OR Myelopathic Muscular Atrophy, Progressive[Text Word] OR<br>Progressive Proximal Myelopathic Muscular Atrophy[Text Word] OR Proximal<br>Myelopathic Muscular Atrophy, Progressive[Text Word] OR Bulbospinal<br>Neuronopathy[Text Word] OR Bulbospinal Neuronopathies[Text Word] OR<br>Neuronopathies, Bulbospinal[Text Word] OR Neuronopathy, Bulbospinal[Text<br>Word] OR Myelopathic Muscular Atrophy[Text Word] OR Atrophy,<br>Myelopathic Muscular[Text Word] OR Muscular Atrophy, Myelopathic[Text<br>Word] OR Adult-Onset Spinal Muscular Atrophy[Text Word] OR Adult Onset<br>Spinal Muscular Atrophy[Text Word] OR Muscular Atrophy, Adult Spinal[Text<br>Word] OR Adult Spinal Muscular Atrophy[Text Word]))) AND ((("risdiplam"<br>[Supplementary Concept]) OR ((risdiplan[Text Word]) OR EVRYSDI[Text<br>Word] AND (((randomized controlled trial[Publication Type]) AND (controlled<br>clinical trial[Publication Type])) AND (systematic review[Publication Type]))<br>AND (observational study[Publication Type]))))|23|  
|**Bases**|**Estratégia de Busca**|**Número de Artigos**<br>**Recuperados**|
|---|---|---|
|Cochrane|#1 MeSH descriptor: [Muscular Atrophy, Spinal] explode all trees 100<br>#2 (Muscular Atrophy, Spinal):ti,ab,kw (Word variations have been searched)<br>357<br>#3<br>(Muscular Atrophy, Adult Spinal):ti,ab,kw (Word variations have<br>been searched)<br>157<br>#4<br>#1 or #2 or #3     357<br>#5<br>(Risdiplam):ti,ab,kw (Word variations have been searched)<br>27<br>#6<br>(Evrysdi):ti,ab,kw (Word variations have been searched)   8<br>#7<br>(RG7916):ti,ab,kw (Word variations have been searched) 19<br>#8<br>(RO7034067):ti,ab,kw (Word variations have been searched)<br>18<br>#9<br>#5 or #6 or #7 or #8<br>39<br>#10<br>#4 and #9           38|38|
|Lilacs|((tw:((tw:("MUSCULAR ATROPHY, SPINAL")) OR (tw:("MUSCULAR<br>ATROPHY, SPINAL, INFANTILE")) OR (tw:("SPINAL<br>AMYOTROPHY")) OR (tw:("HEREDITARY MOTOR<br>NEURONOPATHY")) OR (tw:("SCAPULOPERONEAL FORM OF<br>SPINAL MUSCULAR ATROPHY")) OR (tw:("AMYOTROPHY,<br>NEUROGENIC SCAPULOPERONEAL, NEW ENGLAND TYPE")) OR<br>(tw:("SCAPULOPERONEAL SPINAL  MUSCULAR ATROPHY")) OR<br>(tw:("OCULOPHARYNGEAL SPINAL MUSCULAR ATROPHY")) OR<br>(tw:("SPINAL MUSCULAR ATROPHY, OCULOPHARYNGEAL")) OR<br>(tw:("PROGRESSIVE MUSCULAR ATROPHY")) OR<br>(tw:("PROGRESSIVE MYELOPATHIC MUSCULAR ATROPHY")) OR<br>(tw:("BULBOSPINAL NEURONOPATHY")) OR (tw:("ADULT- ONSET<br>SPINAL MUSCULAR ATROPHY")) OR (tw:("MUSCULAR ATROPHY,<br>ADULT SPINAL"))))) AND ("risdiplam" OR "evrysdi" OR "RG7916" OR<br>"RO7034067")|0|
|EMBASE|((('spinal muscular atrophy'/exp OR 'spinal muscular atrophy' OR 'hereditary<br>spinal muscular atrophy'/exp) AND 'spinal muscular atrophy'/exp OR 'spinal<br>muscular atrophy type 2'/exp OR 'spinal muscular atrophy type 1'/exp OR 'type<br>ii spinal muscular atrophy'/exp) AND 'type i spinal muscular atrophy'/exp OR<br>'risdiplam'/exp) AND ([cochrane review]/lim OR [systematic review]/lim OR<br>[meta analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled<br>trial]/lim) AND [2021-2022]/py|67|
|**Total**||**128**|  
**Nota** : A busca foi realizada em 02/05/2022

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Seleção das evidências** -->
Para responder à questão sobre uso de risdiplam para AME 5q, após a atualização da busca nas bases de dados, 128 publicações foram recuperadas. Destes, um estudo foi lido na íntegra e somado às evidências da revisão sistemática realizada  
Conclusão sobre as evidências

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: previamente que respondiam à pergunta PICO. -->
O FIREFISH consiste em um estudo de duas partes, aberto e multicêntrico para investigar a segurança, eficácia, tolerabilidade, farmacocinética e farmacodinâmica do risdiplam em bebês de 1 a 7 meses de idade com AME tipo 1. A parte 1 consiste na determinação da dose e a parte 2 é confirmatória para a dose que foi selecionada na parte 1. Na parte 1, 21 bebês foram inscritos com idade média na inclusão no estudo de 6,7 meses (amplitude de 3,3 a 6,9), os desfechos primários avaliados foram os estudos de segurança, farmacocinética e farmacodinâmica. As doses foram estabelecidas pelo método de escalonamento: 0,08 mg/kg na coorte com dose mais baixa (4 bebês) e 0,2 mg/kg na coorte com dosagem mais alta (17 bebês). A pontuação na CHOP INTEND no início do estudo apresentou uma mediana de 24 (amplitude de 10 a 34) e a pontuação da HINE-2 foi uma mediana de 1 (amplitude de 0 a 3). Neste estudo, os desfechos clínicos foram avaliados por análise exploratória _post-hoc_ de eficácia, com destaque para sobrevida livre de ventilação permanente, definida como estar vivo sem o uso de ventilação permanente (traqueostomia ou ventilação [pressão positiva de dois níveis nas vias aéreas] por período ≥ 16 horas por dia continuamente por mais de 3 semanas ou intubação contínua por mais de 3 semanas). Com base nos dados farmacocinéticos, a mediana do nível da proteína SMN foi 2,1 vezes o nível basal observado dentro de 4 semanas após o início do tratamento da coorte de alta dose. Assim, o regime definido para a parte 2 foi o de 0,2 mg/kg<sup>4</sup> .  
Na parte 2, foram inscritas 41 crianças com AME tipo 1 com idade média no início do acompanhamento de 5,3 meses (amplitude de 2,2 a 6,9), o desfecho primário avaliado foi a capacidade de sentar sem apoio por pelo menos 5 segundos (avaliado como componente da subescala motora grossa da _Bayley Scales of Infant and Toddler Development_ terceira edição) após o período de 12 meses de tratamento com o risdiplam. Os desfechos secundários consideraram uma pontuação de 40 ou mais na escala CHOP INTEND, resposta de marco motor mensurada pela HINE-2 e a sobrevivência sem ventilação permanente. Após 12 meses de tratamento, 12 crianças (29%) com intervalo de confiança de 95% (16-46) foram capazes de sentar sem apoio por pelo menos 5 segundos. Com relação aos desfechos secundários, o estudo basal apresentou uma pontuação na CHOP INTEND e na HINE-2 correspondente a uma mediana de 22,0 (amplitude de 8,0 a 37,0) e 1,0 (amplitude de 0,0 a 5,0), respectivamente. Ao final do período de 12 meses, a mediana passou a ser 42,0 (amplitude de 13,0 a 57,0) na CHO-INTEND. Para a escala HINE2, um total de 32 crianças de 41 bebês (78%; IC 95% 62-89) apresentaram uma resposta de marco motor em comparação com o critério de desempenho de 12%<sup>5</sup> . Os resultados deste estudo foram publicados com base no seguimento de 12 meses, mas o estudo ainda está em andamento com a última atualização de seu registro em janeiro de 2022<sup>6</sup> .  
Sergott et al.<sup>7</sup> avaliaram a segurança oftalmológica do medicamento risdiplam em pacientes diagnosticados com AME tipo 1 e 2. Neste estudo foram incluídos 338 pacientes diagnosticados com AME com idade entre 2 meses a 60 anos, inscritos nos ensaios clínicos FIREFISH, SUNFISH e JEWELFISH. Não foram incluídos no estudo pacientes com histórico de doença oftalmológica de origem basal ou pacientes impossibilitados de realizar avaliações oftalmológicas. Pacientes com histórico de uso dos medicamentos cloroquina, hidroxicloroquina, retigabina, vigabatrina ou tioridazina não foram incluídos devido à suspeita destes medicamentos serem possíveis causadores de toxicidade retinal. Dentre as avaliações oftalmológicas propostas, foram realizadas avaliações funcionais a respeito da acuidade visual e campo visual adequado a idade, exames de imagem como tomografia de coerência óptica de domínio espectral, exame de fundo de olho e autoflorescência de fundo. Dos 338 pacientes, 158 pacientes pertenciam aos estudos _open-label não-cego,_ FIREFISH parte 1 e 2, SUNFISH parte 1 e JEWELFISH, e 180 pacientes pertencem ao grupo do ensaio clínico SUNFISH parte 2. Destes pacientes, 64 pertencem ao grupo AME tipo 1 e 274 pacientes do grupo AME tipo 2/3, no qual 278 fizeram uso do medicamento risdiplam. O tempo de duração de acompanhamento foi de 30,2 meses, sendo que 28 pacientes não chegaram à primeira avaliação após o início do estudo, finalizando o estudo em 310 participantes. Foram identificados 11 eventos oftalmológicos no grupo de pacientes _open-label_ não-cego _,_ no qual 1,3% dos pacientes apresentaram hiperemia conjuntival, sendo 3,1% no grupo de pacientes AME tipo 1. A incidência de ocorrência foi  
igualmente (0,6%) para os eventos como olhos secos, alergia ocular, cisto macular, hiperemia ocular, fotopsia, exudato retinal e visão turva. Enquanto isso, no ensaio clínico SUNFISH parte 2, 13 pacientes (7,2%) apresentaram pelo menos um evento adverso oftalmológico, no qual olhos secos apresentou maior incidência (1,7%). Apesar disso, <mark>os eventos adversos envolvendo distúrbios oculares não foram sugestivos de toxicidade induzida por risdiplam e foram resolvidos com o tratamento contínuo. O monitoramento oftalmológico deste estudo demonstra que o risdiplam é seguro e não induz toxicidade oftalmológica</mark><sup>7</sup> <mark>.</mark>  
Uma revisão sistemática e meta-análise de comparação indireta entre o risdiplam e outros comparadores para o tratamento de AME tipos 1, 2 e 3 buscou os estudos nas bases de dados Embase, MEDLINE, Cochrane, CENTRAL e em fontes de informações complementares. Os desfechos foram avaliados quanto à sobrevida livre de evento, sobrevida global, desfechos relacionados à função motora (HINE-2, CHOP INTEND, MFM-32) e eventos adversos. Os critérios de inclusão incluíram ensaios clínicos randomizados (ECR) e não randomizados, ensaios de braço único e estudos observacionais prospectivos e retrospectivos. Os tipos de estudos incluídos foram ECR e ensaios de braço único. Entre estes, os estudos incluídos na análise de comparação de tratamento indireta consistiam em dois estudos clínicos que investigaram o risdiplam (FIREFISH e SUNFISH) e dois estudos que investigaram o nusinersena (ENDEAR, CHERISH) e um estudo que investigou o onasemnogeno abeparvoveque (STR1VE-US). O método de comparação indireta ajustada por pareamento (MAIC) (na sigla inglês, MAIC, _matching-adjusted indirect treatment comparison_ ) foi utilizado na análise. Desta forma, os pacientes do estudo FIREFISH (risdiplam) foram pareados aos pacientes do estudo ENDEAR (nusinersena) utilizando-se três variáveis que impactaram nos desfechos: idade na primeira dose, duração da doença e pontuação CHOP INTEND<sup>8</sup> .  
A sobrevivência foi analisada para os estudos FIREFISH e ENDEAR em razão da sobrevida global e sobrevida livre de eventos, sugerindo que o risdiplam pode resultar em um aumento na sobrevida livre de eventos quando comparado ao nusinersena. A razão de risco (em inglês, _hazard ratio_ ) para a sobrevida livre de eventos de risdiplam versus nusinersena foi estimada em 0,24 (IC 95%: 0,09–0,46) para análise não ajustada e 0,20 (IC 95%: 0,06–0,42) para análise MAIC. Os resultados do MAIC para a sobrevida global também sugeriram maior probabilidade para risdiplam em relação ao nusinersena (razão de risco: 0,26 [IC 95%: 0,03–0,67]). A análise sobre a resposta do marco motor (HINE-2), desfecho primário do ENDEAR, indicou que o risdiplam pode estar associado a uma maior probabilidade de resposta em comparação ao nusinersena, na análise MAIC o resultado encontrado foi uma razão de chance (em inglês, _odds ratio_ ) de 3,97 (IC de 95%: 2,03-8,38)<sup>8</sup> .  
Da mesma forma, os resultados das análises MAIC nas pontuações CHOP INTEND indicam que o risdiplam pode ser mais eficaz do que o nusinersena, por meio de uma melhora na pontuação CHOP INTEND ≥4 pontos (razão de chance: 7,59 [IC 95%: 3,06–35,71]) obtendo uma pontuação total de ≥40 pontos (razão de chance : 2,86 [IC 95%: 1,43–6,09]). Com relação aos eventos adversos graves, as estimativas de efeito relativo entre as análises não ajustadas e MAIC do risdiplam versus nusinersena praticamente não apresentaram diferenças, de modo que a razão de chances foi de 0,41 (IC 95%: 0,19–0,89) na análise não ajustada e 0,38 (IC 95%: 0,15–0,97), na análise MAIC. Na análise qualitativa, os eventos adversos graves eram semelhantes entre os ensaios e reflexo da doença subjacente. De maneira geral, esses resultados revelam o uso de risdiplam como uma alternativa melhor ao uso do nusinersena para o tratamento de pacientes com AME tipo 1<sup>8</sup> .  
**RECOMENDAÇÃO DA CONITEC** : recomendar a incorporação ao SUS do risdiplam para tratamento de pacientes diagnosticados com Atrofia Muscular Espinhal do tipo 1, conforme Relatório de Recomendação nº 709/2022 disponível em <u>http://conitec.gov.br/images/Relatorios/2022/20220314_Relatorio_709_risdiplam_AMEtipoI.pdf</u>

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Referências** -->
1. WHO Library. WHO handbook for guideline development. Geneva: WHO Press, 2012.  
2. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e  
Incorporação de Tecnologias em Saúde. Diretrizes metodológicas: Elaboração de Diretrizes Clínicas[recurso eletrônico] / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Gestão e Incorporação de Tecnologias em Saúde. – Brasília : Ministério da Saúde, 2016.  
3. SCHUNEMANN, H.J. et al. Grading quality of evidence and strength of recommendations for diagnostics tests and strategies. Britsh Medical Journal, London, v.336, n.7653, p.1106-1110, 2008.  
4. Seabrook T, Baranello G, Darras BT, Day JW, Deconinck N, Klein A, et al. Risdiplam in Type 1 Spinal Muscular Atrophy. N Engl J Med. 2021 Mar;384(10):915–23.  
5. Darras BT, Masson R, Mazurkiewicz-Bełdzińska M, Rose K, Xiong H, Zanoteli E, et al. Risdiplam-Treated Infants with Type 1 Spinal Muscular Atrophy versus Historical Controls. N Engl J Med. 2021 Jul;385(5):427–35.  
6. Hoffmann-La Roche. Investigate Safety, Tolerability, PK, PD and Efficacy of Risdiplam (RO7034067) in Infants With Type1 Spinal Muscular Atrophy (FIREFISH). NCT02913482. 2022.  
7. Sergott RC, Amorelli GM, Baranello G, Barreau E, Beres S, Kane S, et al. Risdiplam treatment has not led to retinal toxicity in patients with spinal muscular atrophy. Ann Clin Transl Neurol. 2021;8:54–65.  
8. Ribero, V. A., Daigl, M., Martí, Y., Gorni, K., Evans, R., Scott, D. A., Mahajan, A., Abrams, K. R., & Hawkins, N. (2022). How does risdiplam compare with other treatments for Types 1-3 spinal muscular atrophy: a systematic literature review and indirect treatment comparison. In Journal of Comparative Effectiveness Research (Vol. 11, Issue 5, pp. 347–370). Future Medicine Ltd. https://doi.org/10.2217/cer-2021-0216.  
**QUESTÃO 4: O USO DE RISDIPLAM É EFICAZ, SEGURO E CUSTO-EFETIVO EM PACIENTES COM ATROFIA MUSCULAR ESPINHAL TIPO 2 E 3A QUANDO COMPARADO AO TRATAMENTO DE SUPORTE OU A TRATAMENTOS ATIVOS ATUALMENTE DISPONÍVEIS NO SUS?**

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Busca de evidências** -->
A avaliação do uso de risdiplam na AME 5q tipo 2 foi realizada por meio de uma revisão sistemática sobre a eficácia, efetividade, segurança e custo-efetividade do uso de risdiplam para a AME 5q tipo 2. A revisão foi realizada por dois revisores que avaliaram independentemente os títulos e resumos dos artigos, determinaram a elegibilidade e extraíram os dados e os sumarizaram. A evidência foi sintetizada narrativamente e resumida usando estatísticas descritivas.  
A literatura foi revisada por meio de pergunta PICO ( **Quadro H** ). A atualização da estratégia de busca está descrita no **Quadro I** .  
**Quadro H** - Pergunta estruturada utilizada para responder à questão sobre uso de risdiplam para AME 5q tipo 2  
|P|População|Pacientes com AME 5q tipo 2|
|---|---|---|
|I|Intervenção|Risdiplam|
|C|Comparadores|Controle ativo existente ou tratamento de suporte não medicamentoso|
|O|(_Outcomes_) Desfechos|Eficácia e efetividade: sobrevida livre de evento, função motora;<br>Segurança: incidência de eventos adversos.|
|S|(_Study_) Tipo de estudo|Revisões sistemáticas com ou sem meta-análise, ensaios clínicos randomizados,<br>estudos de coorte.|  
**Quadro I** - Estratégias de busca de evidências na base de dados  
|**Bases**<br>**de**<br>**dados**|**Estratégia de busca**|**Número**<br>**de**<br>**artigos**<br>**recuperados**|
|---|---|---|
|**MEDLINE**<br>**(via PubMed)**|((‘Muscular Atrophy, Spinal’[Mesh]) OR ((Muscular Atrophy, Spinal[Text Word] OR<br>Atrophy, Spinal Muscular[Text Word] OR Spinal Amyotrophy[Text Word] OR<br>Amyotrophies, Spinal[Text Word] OR Amyotrophy, Spinal[Text Word] OR Spinal<br>Amyotrophies[Text Word] OR Spinal Muscular Atrophy[Text Word] OR Distal Spinal<br>Muscular Atrophy[Text Word] OR Spinal Muscular Atrophy, Distal[Text Word] OR<br>Hereditary<br>Motor<br>Neuronopathy[Text<br>Word]<br>OR<br>Hereditary<br>Motor<br>Neuronopathies[Text Word] OR Motor Neuronopathies, Hereditary[Text Word] OR<br>Motor Neuronopathy, Hereditary[Text Word] OR Neuronopathies, Hereditary<br>Motor[Text Word] OR Neuronopathy, Hereditary Motor[Text Word] OR<br>Scapuloperoneal Form of Spinal Muscular Atrophy[Text Word] OR Spinal Muscular<br>Atrophy, Scapuloperoneal Form[Text Word] OR Spinal Muscular Atrophy,<br>Scapuloperoneal[Text Word] OR Amyotrophy, Neurogenic Scapuloperoneal, New<br>England Type[Text Word] OR Scapuloperoneal Spinal Muscular Atrophy[Text Word]<br>OR Oculopharyngeal Spinal Muscular Atrophy[Text Word] OR Spinal Muscular<br>Atrophy, Oculopharyngeal[Text Word] OR Progressive Muscular Atrophy[Text<br>Word] OR Atrophies, Progressive Muscular[Text Word] OR Atrophy, Progressive<br>Muscular[Text Word] OR Muscular Atrophies, Progressive[Text Word] OR Muscular<br>Atrophy, Progressive[Text Word] OR Progressive Muscular Atrophies[Text Word]<br>OR Progressive Myelopathic Muscular Atrophy[Text Word] OR Myelopathic<br>Muscular Atrophy, Progressive[Text Word] OR Progressive Proximal Myelopathic<br>Muscular Atrophy[Text Word] OR Proximal Myelopathic Muscular Atrophy,<br>Progressive[Text Word] OR Bulbospinal Neuronopathy[Text Word] OR Bulbospinal<br>Neuronopathies[Text Word] OR Neuronopathies, Bulbospinal[Text Word] OR<br>Neuronopathy, Bulbospinal[Text Word] OR Myelopathic Muscular Atrophy[Text<br>Word] OR Atrophy, Myelopathic Muscular[Text Word] OR Muscular Atrophy,<br>Myelopathic[Text Word] OR Adult-Onset Spinal Muscular Atrophy[Text Word] OR<br>Adult Onset Spinal Muscular Atrophy[Text Word] OR Muscular Atrophy, Adult<br>Spinal[Text Word] OR Adult Spinal Muscular Atrophy[Text Word]))) AND<br>((("risdiplam"<br>[Supplementary<br>Concept])<br>OR<br>((risdiplan[Text<br>Word])<br>OR<br>EVRYSDI[Text Word] AND (((randomized controlled trial[Publication Type]) AND<br>(controlled clinical trial[Publication Type])) AND (systematic review[Publication<br>Type])) AND (observational study[Publication Type]))))|23|
|**COCHRANE**|#1        MeSH descriptor: [Muscular Atrophy, Spinal] explode all trees           100<br>#2        (Muscular Atrophy, Spinal):ti,ab,kw (Word variations have been searched)<br>357<br>#3        (Muscular Atrophy, Adult Spinal):ti,ab,kw (Word variations have been<br>searched)<br>157<br>#4        #1 or #2 or #3   357<br>#5        (Risdiplam):ti,ab,kw (Word variations have been searched)  27<br>#6        (Evrysdi):ti,ab,kw (Word variations have been searched)      8|38|  
|**Bases**<br>**de**<br>**dados**|**Estratégia de busca**|**Número**<br>**de**<br>**artigos**<br>**recuperados**|
|---|---|---|
||#7        (RG7916):ti,ab,kw (Word variations have been searched)     19<br>#8        (RO7034067):ti,ab,kw (Word variations have been searched) 18<br>#9        #5 or #6 or #7 or #8         39<br>#10      #4 and #9           38||
|**EMBASE**|(('spinal muscular atrophy'/exp OR 'spinal muscular atrophy' OR 'hereditary spinal muscular<br>atrophy'/exp OR 'hereditary spinal muscular atrophy' OR 'type iv spinal muscular<br>atrophy':ti,ab,kw OR 'spinal muscular atrophy type i':ti,ab,kw OR 'spinal muscular atrophy type<br>ii':ti,ab,kw OR 'spinal muscular atrophy type iii':ti,ab,kw OR 'spinal muscular atrophy type<br>iv':ti,ab,kw OR 'spinal muscular atrophy, hereditary':ti,ab,kw OR 'type 1 spinal muscular<br>atrophy':ti,ab,kw OR 'type 2 spinal muscular atrophy':ti,ab,kw OR 'type i spinal muscular<br>atrophy':ti,ab,kw OR 'type ii spinal muscular atrophy':ti,ab,kw OR 'type iii spinal muscular<br>atrophy':ti,ab,kw) AND ([cochrane review]/lim OR [systematic review]/lim OR [meta<br>analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim) AND<br>[2021-2022]/py AND [embase]/lim) AND ('risdiplam'/exp OR risdiplam)|40|
|**Total**||**101**|  
Nota: A busca foi realizada em 02/05/2022

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Seleção das evidências** -->
Para responder à questão sobre uso de risdiplam para AME 5q tipo 2, após a atualização da busca nas bases de dados, 101 publicações foram recuperadas. Destes, dois estudos foram lidos na íntegra e somados às evidências da revisão sistemática realizada previamente que respondiam à pergunta PICO (Quadro I).

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Conclusão sobre as evidências selecionadas** -->
O primeiro estudo trata-se de ECR de duas partes que avaliou a eficácia e segurança do risdiplam em pacientes com AME tipo 2 ou 3 não deambulantes com idade entre 2 e 25 anos (SUNFISH parte 2)¹. Os pacientes foram aleatoriamente randomizados para receber o risdiplam ou placebo (2:1, risdiplam: placebo) e avaliados de forma duplo-cega. O estudo incluiu 180 indivíduos e teve como desfecho primário a mudança na pontuação da escala MFM-32 após 12 meses de tratamento. Como desfechos secundários foram avaliados mudanças nas escalas RULM e HFMSE e em outras escalas como _Spinal Muscular Atrophy Independence Scale_ (SMAIS) e _Clinical Global Impression of Change_ (CGI-C). Além disso, a segurança foi avaliada, incluindo os eventos adversos e o monitoramento oftalmológico.  
No início do estudo, 38% (68 de 180 indivíduos) tinham idade superior ou igual a 12 anos, 50,6% eram do sexo feminino, 71,1% apresentavam AME tipo 2 e 28,9% AME tipo 3, sendo que a maior parte dos participantes possuíam 3 cópias de SMN2. Para o desfecho primário, a alteração média dos mínimos quadrados da linha de base na MFM-32 foi de 1,36 (IC 95% 0,61 a 2,11) no grupo risdiplam e –0,19 (–1,22 a 0,84) no grupo placebo, com diferença de tratamento de odds ratio (OR) de 1,55 (IC 95% 0,30 a 2,81, p=0,016) apresentando uma diferença significativa do tratamento à favor do risdiplam. Para os desfechos secundários:  
● 38% (n = 44/115) dos pacientes tratados com risdiplam alcançaram ≥ 3 pontos de aumento na MFM-32, comparado a 24% (n = 14/59) no grupo placebo, conferindo um OR de 2,35 (IC 95% 1,01 a 5,44) a favor do risdiplam;  
● 70% (n = 80/115) dos pacientes tratados com risdiplam que alcançaram pelo menos alguma mudança (pontuação ≥ 0)  
na pontuação total de MFM-32, contra 54% (n = 32/59) dos que receberam placebo (p = 0,043), conferindo um OR de 2,00  
(IC95%: 1,02 a 3,93) a favor do risdiplam;  
● foi observada alteração média dos mínimos quadrados na mudança da linha de base no escore total RULM entre os indivíduos do grupo risdiplam 1,61 (IC 95% 1,00 a 2,22) e aqueles do grupo placebo 0,02 (IC 95% –0,83 a 0,87), com um OR de 1,59 (IC 95%0,55 a 2,62);  
● não foi observada diferença entre os grupos para a alteração média dos mínimos quadrados desde a linha de base no escore total do HFMSE entre indivíduos do grupo risdiplam 0,95 (IC 95% 0,29 a 1,61) e aqueles do grupo placebo 0,37 (IC 95% –0,54 a 1,28), com um OR de 0,58 (IC 95% –0,53 a 1,69);  
● aumento na linha de base na pontuação total do membro superior no SMAIS relatado pelos cuidadores foi observado no grupo risdiplam 1,65 (IC 95% 0,66 a 2,63) em comparação com um declínio nas pontuações do grupo placebo –0,91 (–2,23 a 0,42), com um OR 2,55 (0,93 a 4,17);  
● a saúde global desde a linha de base, medida pela escala CGI-C apresentou uma proporção maior de indivíduos no grupo do risdiplam 48% (n = 57/120) com melhora em comparação ao grupo placebo 40% (n = 24/60) 1·38 com um OR de 0,70 a 2,74.  
Os eventos adversos relatados com maior frequência com uso de risdiplam do que com uso de placebo foram: infecção do trato respiratório superior (32%; n=38), nasofaringite (26% ; n=31), pirexia (21%; n=25), dor de cabeça (20%; n=24), diarréia (17%; n=20), vômitos (14%; n=17), tosse (14%; n=17) e bronquite (7%; n=8). Para os eventos adversos graves, os mais frequentes foram pneumonia (8%; n=9), gastroenterite (2%; n=2), bacteremia (2%; n=2), influenza (2%; n=2), pirexia (2%; n=2) e infecção pulmonar (1%; n=1). As interrupções do tratamento foram de curto prazo e ocorreram em ambos os grupos (ou seja, dez eventos adversos levaram à interrupção da dose em oito pacientes no grupo risdiplam, com duração de 1 a 4 dias; três eventos adversos levaram à interrupção da dose em dois pacientes no grupo placebo, com duração de 6 a 7 dias). As avaliações oftalmológicas não mostraram evidência de toxicidade retiniana induzida pelo risdiplam.  
O segundo estudo é uma revisão sistemática e meta-análise de comparação indireta entre o risdiplam e outros comparadores para o tratamento de AME tipo 1,2 e 3, cujos estudos foram identificados nas bases de dados Embase, MEDLINE, Cochrane, CENTRAL e em fontes de informações complementares. Os desfechos foram avaliados quanto à sobrevida livre de evento, sobrevida global, desfechos relacionados à função motora (HINE-2, CHOP INTEND, MFM-32) e eventos adversos. Os critérios de inclusão incluíram ensaios clínicos randomizados (ECR) e não randomizados, ensaios de braço único e estudos observacionais prospectivos e retrospectivos. Os tipos de estudos incluídos foram ECR e ensaios de braço único, entre estes, os estudos incluídos na análise de comparação de tratamento indireta consistiam em dois estudos clínicos que investigaram o risdiplam (FIREFISH e SUNFISH) e dois estudos que investigaram o nusinersena (ENDEAR, CHERISH) e um estudo que investigou o onasemnogene abeparvovec (STR1VE-US). O método de comparação indireta ajustada por pareamento (MAIC) (na sigla inglês, MAIC, _matching-adjusted indirect treatment comparison_ ) foi utilizado na análise².  
Para AME tipo 2 e 3 foram relatados dois ensaios clínicos: SUNFISH parte 2 (risdiplam) e CHERISH (nusinersena). O desfecho primário no estudo SUNFISH avaliou a alteração na linha de base na pontuação total do MFM-32 mas, como o estudo CHERISH não avaliou o mesmo desfecho, a comparação entre eles não foi possível. O desfecho primário HFMSE avaliado no estudo CHERISH permitiu a comparação entre os dois estudos, uma vez que este desfecho foi avaliado como secundário no estudo SUNFISH. Contudo, a pontuação do RULM foi avaliada para ambos os estudos como desfecho secundário. A comparação entre o risdiplam e  nusinersena foi limitada, uma vez que a heterogeneidade entre os ensaios clínicos impediu uma comparação com a população total do SUNFISH parte 2. Assim, a análise indireta adotou o método de comparações indiretas ajustadas por pareamento MAIC, os pacientes do ensaio SUNFISH foram pareados com os pacientes do estudo CHERISH por meio das variáveis com impacto nos desfechos idade, pontuação de função motora na linha de base e número de cópias SMN2. O pareamento reduziu o tamanho total da amostra do subconjunto SUNFISH para 68 pacientes. Os desfechos avaliados por meio da comparação indireta foram: desfecho relacionado à função motora (RULM) e eventos adversos graves².  
As análises neste estudo não forneceram evidências suficientes para que se pudesse retirar conclusões robustas sobre a eficácia em termos da mudança na linha de base do RULM e a resposta deste desfecho entre o risdiplam e o nusinersena. Neste mesmo sentido, conclusões sobre a eficácia comparativa do HFMSE não pode ser realizada, não se observou melhorias comparáveis nas pontuações do HFMSE ao longo do tempo, bem como não se tirar conclusões concretas sobre a segurança relativa entre risdiplam e nusinersena².  
**RECOMENDAÇÃO DA CONITEC:** recomendar a incorporação ao SUS do risdiplam para tratamento de pacientes diagnosticados com Atrofia Muscular Espinhal (AME) do tipo 2 conforme Protocolo Clínico e Diretrizes Terapêuticas do Ministério da Saúde; recomendar a **não** incorporação ao SUS do risdiplam para tratamento de pacientes diagnosticados com AME do tipo 3a, conforme Relatório de Recomendação nº 710/2022 disponível em: http://conitec.gov.br/images/Relatorios/2022/20220314_Relatorio_710_risdiplam_AMEtipoIIeIII.pdf

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Referências** -->
1. Mercuri E, Deconinck N, Mazzone ES, Nascimento A, Oskoui M, Saito K, et al. Safety and efficacy of once-daily risdiplam in type 2 and non-ambulant type 3 spinal muscular atrophy (SUNFISH part 2): a phase 3, double-blind, randomised, placebocontrolled trial. Lancet Neurol [Internet]. 2022;21:42–52. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1474442221003677  
2. Ribero, V. A., Daigl, M., Martí, Y., Gorni, K., Evans, R., Scott, D. A., Mahajan, A., Abrams, K. R., & Hawkins, N. (2022). How does risdiplam compare with other treatments for Types 1-3 spinal muscular atrophy: a systematic literature review and indirect treatment comparison. In Journal of Comparative Effectiveness Research (Vol. 11, Issue 5, pp. 347–370). Future Medicine Ltd. https://doi.org/10.2217/cer-2021-0216.  
**QUESTÃO 5: O onasemnogeno abeparvoveque é eficaz no tratamento de pacientes com atrofia muscular espinhal (AME) com qualquer número de cópias do gene SMN2, especialmente quando comparado com as tecnologias já disponíveis no SUS (nusinersena e/ou risdiplam)?**

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Busca de evidências** -->
A avaliação do uso do **onasemnogeno abeparvoveque** na AME 5q comparado a  nusinersena e/ou risdiplam foi realizada por meio de uma revisão sistemática sobre a eficácia, efetividade, segurança dos medicamentos. A literatura foi revisada por  
meio de uma pergunta PICO ( **Quadro I** ). A atualização da estratégia de busca está descrita no **Quadro J** .  
**Quadro I** - Pergunta estruturada utilizada para responder à questão  
|P|População|Pacientes com AME|
|---|---|---|
|I|Intervenção|onasemnogeno abeparvoveque|
|C|Comparadores|Nusinersena e/ou risdiplam|
|O|(_Outcomes_) Desfechos|Desfechos de eficácia: incluindo, mas não limitado a:<br>●<br>Sobrevida global,|
|||●<br>Redução da necessidade de ventilação mecânica permanente,<br>●<br>Melhora na pontuação da escala CHOP INTEND e alcance de marcos<br>motores.|
|||Desfechos de segurança: incluindo, mas não limitado a:<br>●<br>Eventos adversos e eventos adversos graves relacionados ao tratamento.|
|S|(_Study_) Tipo de estudo|Estudos clínicos randomizados, não-randomizados e estudos de observacionais<br>(prospectivos e retrospectivos)|  
**Quadro J** - Estratégias de busca de evidências na base de dados.  
|**Bases**<br>**de**<br>**dados**|**Estratégia de busca**|**Número**<br>**de**<br>**artigos**<br>**recuperados**|
|---|---|---|
|**MEDLINE**<br>**(via PubMed)**|("Zolgensma"[TIAB]<br>OR<br>18<br>"Zolgensma"[Supplementary<br>Concept]<br>OR<br>"onasemnogene abeparvovec-xioi"[TIAB] OR "onasemnogene abeparvovec"[TIAB]<br>OR "AVXS-101"[TIAB] OR "adeno-associated virus serotype 9"[TIAB])|415|
|**EMBASE**|('zolgensma':ti,kw,ab<br>OR<br>'onasemnogene<br>abeparvovecxioi':ti,kw,ab<br>OR<br>'onasemnogene abeparvovec':ti,kw,ab OR 'avxs 101'/exp OR 'avxs 101' OR 'avxs<br>101':ti,kw,ab OR 'adenoassociated virus serotype 9':ti,kw,ab) AND [embase]/lim|728|
|**Cochrane**|ID<br>Search Hits<br>#1<br>ZOLGENSMA   3<br>#2<br>'onasemnogene abeparvovec-xioi'<br>1<br>#3<br>'onasemnogene abeparvovec'<br>4<br>#4<br>AVXS-101         8<br>#5<br>'adeno-associated virus serotype 9'<br>15<br>#6<br>#1 OR #2 OR #3 OR #4 OR #5<br>26|26|
|**LILACS**|((zolgensma) OR (onasemnogene abeparvovec-xioi) OR (onasemnogene abeparvovec)<br>OR (avxs-101) OR ((adenoassociated virus) AND (serotype 9)) ) AND (<br>db:("LILACS"))|2|
|**Total**||**1.171**|  
**Nota** : A busca foi realizada em 05/01/2023

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Seleção das evidências** -->
Para responder à questão, após a execução das estratégias de busca nas bases de dados, 1.171 publicações foram recuperadas. Destas, 23 foram lidas na íntegra, porém nenhuma atendeu aos critérios estabelecidos pela pergunta PICOS.  
**Figura C:** Diagrama de busca  da pergunta 5  
<!-- Start of picture text -->
Pubicag6es identiicadas = 1.171<br>PUBMED= 415<br>EMBASE = 728 Duplicatas removidas = 177<br>Cochrane = 26<br>LILACS = 2<br>Analise de titulos ¢ resumos= Publicagdesremovidas = 971<br>Leitura integral das Publicagéesremovidas = 23<br>publicagdes= 23<br>Publicagées incluidas= 0<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Conclusão sobre as evidências selecionadas:** -->
Não foram encontrados estudos em que o uso do onasemnogeno abeparvoveque foi comparado diretamente com o uso de nusinersena e/ou risdiplam. Portanto, não é possível concluir qual dos medicamentos apresenta melhor benefício clínico.  
**RECOMENDAÇÃO DA CONITEC:** Recomenda-se manter a indicação do      onasemnogeno abeparvoveque determinada pela PORTARIA SCTIE/MS Nº 172, DE 6 DE DEZEMBRO DE 2022: pacientes pediátricos até 6 meses de idade com Atrofia Muscular Espinhal (AME) do tipo 1 que estejam fora de ventilação invasiva acima de 16 horas por dia, conforme protocolo estabelecido pelo Ministério da Saúde e Acordo de Compartilhamento de Risco.  
**QUESTÃO 6: O uso do onasemnogeno abeparvoveque antes ou após o uso de nusinersensa e/ou risdiplam resulta em algum benefício clínico para o paciente?**  
A avaliação de benefícios clínicos associados ao uso do **onasemnogeno abeparvoveque** na AME 5q tipo 1 antes ou após a utilização de nusinersena e/ou risdiplam foi realizada por meio de uma revisão sistemática sobre a eficácia, efetividade, segurança dos medicamentos. A literatura foi revisada por meio da pergunta PICOS ( **Quadro J** ). A atualização da estratégia de busca está descrita no **Quadro K** .  
**Quadro J** - Pergunta estruturada utilizada para responder à questão  
|P|População|Pacientes com AME|
|---|---|---|
|I|Intervenção|onasemnogeno abeparvoveque|
|C|Comparadores|Nusinersena e/ou risdiplam|
|O|(_Outcomes_)|Desfechos de eficácia: incluindo, mas não limitado a:|
||Desfechos|<br>Sobrevida global,|
|||<br>Redução da necessidade de ventilação mecânica permanente,<br><br>Melhora na pontuação da escala CHOP INTEND e alcance de marcos motores.<br>Desfechos de segurança: incluindo, mas não limitado a:<br><br>Eventos adversos e eventos adversos graves relacionados ao tratamento.|
|S|(_Study_)<br>Tipo<br>de<br>estudo|Estudos clínicos randomizados, não-randomizados e estudos observacionais (prospectivos e<br>retrospectivos)|  
**Quadro K** - Estratégias de busca de evidências na base de dados  
|**Bases de dados**|**Estratégia de busca**|**Número**<br>**de**<br>**artigos**<br>**recuperados**|
|---|---|---|
|**MEDLINE**<br>**(via PubMed)**|("Zolgensma"[TIAB]<br>OR<br>18<br>"Zolgensma"[Supplementary<br>Concept]<br>OR<br>"onasemnogene abeparvovec-xioi"[TIAB] OR "onasemnogene abeparvovec"[TIAB]<br>OR "AVXS-101"[TIAB] OR "adeno-associated virus serotype 9"[TIAB])|415|
|**EMBASE**|('zolgensma':ti,kw,ab<br>OR<br>'onasemnogene<br>abeparvovecxioi':ti,kw,ab<br>OR<br>'onasemnogene abeparvovec':ti,kw,ab OR 'avxs 101'/exp OR 'avxs 101' OR 'avxs<br>101':ti,kw,ab OR 'adenoassociated virus serotype 9':ti,kw,ab) AND [embase]/lim|728|
|**Cochrane**|ID<br>Search Hits<br>#1<br>ZOLGENSMA   3<br>#2<br>'onasemnogene abeparvovec-xioi'<br>1<br>#3<br>'onasemnogene abeparvovec'<br>4<br>#4<br>AVXS-101         8<br>#5<br>'adeno-associated virus serotype 9'<br>15<br>#6<br>#1 OR #2 OR #3 OR #4 OR #5<br>26|26|
|**LILACS**|((zolgensma)<br>OR<br>(onasemnogene<br>abeparvovec-xioi)<br>OR<br>(onasemnogene<br>abeparvovec) OR (avxs-101) OR ((adenoassociated virus) AND (serotype 9)) ) AND<br>( db:("LILACS"))|2|
|**Total**||**1.171**|  
Nota: A busca foi realizada em 05/01/2023  
**Seleção das evidências**  
Para responder à questão, após a execução das estratégias de busca nas bases de dados, 1.171 publicações foram recuperadas. Destas, 23 foram lidas na íntegra e 8 foram selecionadas.  
**Figura D:** Diagrama de busca da pergunta 6.  
<!-- Start of picture text -->
Publicações identificadas = 1.171<br>PUBMED = 415<br>EMBASE= 728  Duplicatas removidas = 177<br>Cochrane = 26<br>LILACS = 2<br>Análise de títulos e resumos = 994  Publicações removidas = 971<br>Publicações removidas = 16<br>Leitura integral das publicações =<br> Não relataram uso de<br>23<br>nusinersena e/ou<br>risdiplam antes/ após<br>onasemnogeno<br>abeparvoveque = 14<br> Delineamento de estudo<br>errado = 2<br>Publicações incluídas = 8<br><!-- End of picture text -->  
Não foram encontrados estudos de eficácia que compararam diretamente o uso do onasemnogeno abeparvoveque com o uso de nusinersena e/ou risdiplam. No entanto, foram identificados estudos observacionais contendo alguns pacientes que utilizaram nusinersena e/ou risdiplam antes ou após onasemnogeno abeparvoveque. Trata-se de análises descritivas contendo uma pequena amostra de pessoas.  
**Quadro L** - Resumo das publicações identificadas para a pergunta 6  
|**Publicações**<br>**avaliadas**|**Comentários**|
|---|---|
||Nesta coorte contendo pessoas com AME tipo 1 e até 3 cópias do SMN2 foi relatado o aumento 2 pontos da|
|Bitteti et al.,|mediana da pontuação CHOP-INTEND um mês após a troca de nusinersena por onasemnogeno|
|2022|abeparvoveque (7 pessoas). Após 3 meses, foi verificado um aumento de 10 pontos. Wilcoxon signed-rank|
||test p = 0.4036 para 1 mês e p = 0.0467 para 3 meses.|  
|**Publicações**<br>**avaliadas**|**Comentários**|
|---|---|
|D’Silva et al.,<br>2022|Esta coorte incluiu pessoas com AME tipo 1 sem restrição para o número de cópias de SMN2. 19/21 pessoas<br>fizeram uso prévio de nusinersena. Dentre elas, cinco continuaram o uso após onasemnogeno<br>abeparvoveque.  Aqueles previamente tratados com nusinersen mostraram ganhos na função motora, assim<br>como aqueles que receberam nusinersena após onasemnogeno abeparvoveque. No entanto, foi demonstrado<br>maior ganho motor ao longo do uso de nusinersena do que após o uso do      onasemnogeno abeparvoveque.|
|Friese et al.,<br>2021|Esta coorte retrospectiva incluiu 8 pessoas com AME que fizeram uso de nusinersena previamente ao<br>onasemnogeno abeparvoveque.|
|Harada et al.,<br>2020|Esta coorte retrospectiva inclui 5 pessoas que realizaram uso de nusinersena antes e/ou após onasemnogeno<br>abeparvoveque. Os autores demonstraram melhoras nas condições físicas dos participantes, mas não houve<br>comparação com desfechos obtidos por participantes que utilizaram apenas onasemnogeno abeparvoveque.|
|Lee<br>et<br>al.,<br>2022|Esta coorte incluiu 6 pessoas com AME tipo 1 ou 2 que realizaram uso de nusinersena antes do<br>onasemnogeno abeparvoveque. Foi verificado aumento na pontuação CHOP-INTEND em todos os<br>participantes, mas não houve comparação com desfechos obtidos por participantes que utilizaram apenas<br>onasemnogeno abeparvoveque.|
|Mendell et al.,<br>2021|Esta coorte se trata da extensão de cinco anos do estudo de fase 1 START incluindo pessoas com AME e<br>duas coópias do gene SMN 2. Sete dos 13 participantes estavam recebendo nusinersen concomitantemente<br>(3 pacientes na coorte de baixa dose e 4 na coorte de dose terapêutica) em uma tentativa de maximizar o<br>benefício e não por causa de uma perda na função motora ou percepção. Os dois participantes que atingiram<br>novos marcos motores não utilizaram nusinersena em momento algum.|
|Waldrop et al.,<br>2020|Esta coorte prospectiva incluiu 21 pessoas com AME, dentre elas 11 realizaram uso de nusinersena<br>previamente ao onasemnogeno abeparvoveque. Foi verificado aumento na pontuação CHOP-INTEND em<br>todos os participantes, mas não houve comparação com desfechos obtidos por participantes que utilizaram<br>apenas onasemnogeno abeparvoveque.|
|Weiß et al.,<br>2021|Houve aumento na pontuação da escala CHOP-INTEND em pessoas que utilizaram nusinersena antes do<br>onasemnogeno abeparvoveque (8,8 pontos entre a terapia de substituição gênica e o acompanhamento de 6<br>meses (p<0,0001)). Porém, foi observado maior aumento na pontuação no grupo que não realizou tratamento<br>prévio (9,4 pontos entre a terapia de substituição gênica e o acompanhamento de 6 meses (p=0,0030)).|  
Os resultados dos estudos recuperados são inconclusivos a respeito dos benefícios clínicos associados ao uso de nusinersena e/ou risdiplam antes ou após onasemnogeno abeparvoveque. Seria necessário a realização de estudos prospectivos com amostras maiores e um período mais longo para obter resultados conclusivos.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **Referências** -->
1. Bitetti I, Lanzara V, Margiotta G, Varone A. Onasemnogene abeparvovec gene replacement therapy for the treatment of spinal muscular atrophy: a real-world observational study. Gene Ther. 2022(May):1-6.  
2. D’Silva AM, Holland S, Kariyawasam D, Herbert K, Barclay P, Cairns A, et al. Onasemnogene abeparvovec in spinal muscular atrophy: an Australian experience of safety and efficacy. Ann Clin Transl Neurol. 2022;9(3):339–50.  
3. Friese J, Geitmann S, Holzwarth D, Müller N, Sassen R, Baur U, et al. Safety Monitoring of Gene Therapy for Spinal Muscular Atrophy with Onasemnogene Abeparvovec-A Single Centre Experience. J Neuromuscul Dis [Internet]. 2021 [cited 2023 Jan 30];8:209–16. Available from: www.smartcare.  
4. Harada Y, Rao VK, Arya K, Kuntz NL, DiDonato CJ, Napchan-Pomerantz G, et al. Combination molecular therapies for type 1 spinal muscular atrophy. Muscle and Nerve. 2020;62(4):550–4.  
5. Lee S, Lee YJ, Kong J, Ryu HW, Shim YK, Han JY, et al. Short-term clinical outcomes of onasemnogene abeparvovec treatment for spinal muscular atrophy. Brain Dev [Internet]. 2022;44(4):287–93. Available from: https://doi.org/10.1016/j.braindev.2021.12.006  
6. Waldrop MA, Karingada C, Storey MA, Powers B, Iammarino MA, Miller NF, et al. Gene therapy for spinal muscular atrophy: Safety and early outcomes. Pediatrics. 2020;146(3).  
7. Weiß C, Ziegler A, Becker LL, Johannsen J, Brennenstuhl H, Schreiber G, et al. Gene replacement therapy with onasemnogene abeparvovec in children with spinal muscular atrophy aged 24 months or younger and bodyweight up to 15 kg: an observational cohort study. Lancet Child Adolesc Heal. 2022;6(1):17–27.  
8. Mendell JR, Al-Zaidy SA, Lehman KJ, McColly M, Lowes LP, Alfano LN, et al. Five-Year Extension Results of the Phase  
- 1 START Trial of Onasemnogene Abeparvovec in Spinal Muscular Atrophy. JAMA Neurol. 2021;78(7):834–41.

---

<!-- METADADOS: doenca: PCDT - Atrofia Muscular Espinhal | secao: **APÊNDICE 5 HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO/DAS DIRETRIZES** -->
|**Relatório ou Portaria**||**Tecnologias avaliadas**<br>|**pela Conitec**|
|---|---|---|---|
|**de Publicação**|**Principais alterações**|**Incorporação ou alteração do uso  no**<br>**SUS**|**Não incorporação ao SUS**|
||Alteração<br>pós<br>publicação<br>na<br>idade<br>mínima para uso do<br>risdiplam e inclusão de<br>orientações<br>sobre<br>o<br>procedimento<br>de<br>administração<br>do|-|-|
|Relatório<br>de|nasemnogeno|||
|Recomendação<br>nº|abeparvoveque|||
|870/2023|Atualização devido à<br>incorporação<br>de<br>tecnologia no SUS|Onasemnogeno<br>abeparvoveque<br>para<br>tratamento de pacientes com AME tipo<br>1 que estejam fora de ventilação invasiva<br>acima de 16 horas por dia, no âmbito do<br>Sistema Único de Saúde.<br>Relatório de Recomendação nº 793 e<br>Portaria SCTIE/MS nº 172, de 07 de<br>dezembro de 2022|Não possui|
|||Risdiplam para tratamento da Atrofia<br>Muscular Espinhal tipo 2 no âmbito do<br>Sistema Único de Saúde.|**Não incorporar ao SUS:**|
|Portaria<br>Conjunta||Relatório de Recomendação nº710 de|Risdiplam para tratamento|
|SAES/SECTICS/MS<br>nº 06/2023|Atualização devido à<br>ampliação de uso de|2022 e Portaria SCTIE/MS nº 17, de 11<br>de março de 2022|da<br>Atrofia<br>Muscular<br>Espinhal tipo 3a|
|Relatório<br>de|tecnologias no SUS|Risdiplam para o tratamento da Atrofia|Relatório de Recomendação|
|Recomendação<br>nº<br>784/2022||Muscular Espinhal tipo 1 no âmbito do<br>Sistema Único de Saúde. Relatório de<br>Recomendação nº 709 de 2022 e Portaria<br>SCTIE/MS nº 19, de 11 de março de<br>2022|nº 710 de 2022 e Portaria<br>SCTIE/MS nº 17, de 11 de<br>março de 2022|
|Portaria<br>Conjunta<br>SAES-SCTIE/MS nº<br>03/2022<br>Relatório<br>de<br>Recomendação<br>nº|Atualização devido à<br>ampliação de uso de<br>tecnologias no SUS|Nusinersena para tratamento da atrofia<br>muscular espinhal 5q tipo 2, com<br>diagnóstico até os 18 meses de idade.<br>Relatório de Recomendação nº595/ 2021<br>e Portaria SCTIE/MS n 103 nº 06/2021|Nusinersena para tratamento<br>da atrofia muscular espinhal<br>5q tipo 3 – Relatório de<br>Recomendação nº 595/2021<br>e Portaria SCTIE/MS n 103<br>nº 06/2021|  
|**Relatório ou Portaria**<br>**de Publicação**|**Principais alterações**|**Tecnologias avaliadas p**<br>**Incorporação ou alteração do uso  no**<br>**SUS**|**ela Conitec**<br>**Não incorporação ao SUS**|
|---|---|---|---|
|691/2021||||
|Portaria<br>Conjunta<br>SAES-SCTIE/MS nº<br>15/2019.<br>Relatório<br>de|Elaboração da primeira<br>versão do documento|Nusinersena<br>para<br>atrofia<br>muscular<br>espinhal (AME) 5q tipo 1.<br>Relatório<br>de<br>Recomendação<br>nº<br>449/2019 e Portaria SCTIE/MS nº|-|
|Recomendação<br>nº<br>449/2019||24/2019||

---

