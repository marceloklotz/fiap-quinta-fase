<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 7 , DE 13 DE ABRIL DE 2020.  
Aprova as Diretrizes Diagnósticas e Terapêuticas de Tumor Cerebral no Adulto.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre o Tumor Cerebral no Adulto no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formuladas dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 512/2020 e o Relatório de Recomendação nº 521 de Março de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Ficam aprovadas as Diretrizes Diagnósticas e Terapêuticas - Tumor Cerebral no Adulto.  
Parágrafo único.  As Diretrizes objeto deste artigo, que contêm o conceito geral de tumor cerebral no adulto, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponíveis no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento de tumor cerebral no adulto.  
1  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa neoplasia em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria nº 599/SAS/MS, de 26 de junho de 2012, publicada no Diário Oficial da União nº 124, de 28 de junho de 2012, seção 1, página 208.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: DENIZAR VIANNA -->
2

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **1- INTRODUÇÃO** -->
Os tumores cerebrais primários são um conjunto de neoplasias malignas originárias de células de sustentação do tecido nervoso (a glia). São tumores raros, correspondendo a 2% de todos os cânceres conhecidos. A sua evolução varia com a célula original e comportamento biológico tumoral, e alguns tipos mais agressivos ainda mantêm elevada mortalidade em adultos – condição pouco modificada pelo emprego das modalidades terapêuticas disponíveis<sup>(1-3)</sup> .  
Vários são os fatores normalmente relacionados com o risco de glioma, mas suas definições são comprometidas devido à qualidade metodológica dos estudos, e mesmo os resultados significantes são limítrofes.  
Estudos demonstraram que alergias em geral, asma, eczema<sup>(4, 5)</sup> , presença de diabete e o consumo de vegetais<sup>(6, 7)</sup> e fatores genéticos, como os polimorfismos rs273600 e XRCC1-rs25487<sup>(8, 9)</sup> ,  são fatores protetores de glioma. No entanto, outros estudos evidenciaram que fatores alimentares e metabólicos, como o consumo de carne vermelha ou processada, chá, café, álcool, tabagismo, sobrepeso e prática de atividade física, não são fatores de risco para gliomas<sup>(10-16)</sup> .  
A associação entre outras formas de radiação, como a radiação eletromagnética e radiação de radiofrequência, e câncer é menos clara, e os dados não suportam um papel relevante para esses tipos de radiação como fatores de risco para tumores cerebrais. Numerosos estudos epidemiológicos têm procurado uma possível relação entre o uso do telefone celular e o desenvolvimento de tumores cerebrais<sup>(17, 18)</sup> . Uma meta-análise inconclusiva, que incluiu dados de 22 estudos do tipo caso-controle, apontou um ligeiro aumento no risco associado ao uso do telefone celular<sup>(18)</sup> . Além disso, o risco pareceu estar associado a um período de indução de 10 anos ou mais. A / Agência Internacional de Pesquisa sobre o Câncer (IARC) da Organização Mundial da Saúde (OMS) classifica os campos eletromagnéticos de radiofrequência como possivelmente cancerígenos para os seres humanos (Grupo 2B)<sup>(19)</sup> . No entanto, análises que consideram mudanças nas  
3  
taxas de incidência ao longo do tempo, prevalência do uso do telefone celular e período de latência não fornecem suporte para associações causais<sup>(20, 21)</sup> . O uso de hormonioterapia também não está relacionado ao risco de glioma<sup>(22, 23)</sup> . A radiação ionizante é o único fator de risco ambiental firmemente estabelecido para tumores cerebrais<sup>(24-29)</sup> .  
Uma pequena proporção de tumores cerebrais acontece devido a síndromes genéticas que estão correlacionadas com um maior risco de desenvolver tumores do sistema nervoso, como a neurofibromatose tipo 1, neurofibromatose tipo 2, síndrome de von Hippel-Lindau, síndrome de Li-Fraumeni, síndrome de Turcot e síndrome do nevo basocelular. A susceptibilidade genética também desempenha um papel na determinação do risco de tumores cerebrais, embora coletivamente essas variantes não representem uma grande proporção de risco<sup>(30-62).</sup>  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos do tumor cerebral no adulto, com o objetivo de orientar o que é válido e não válido técnicocientificamente, com base em evidências que garantam a segurança, a efetividade e a reprodutibilidade, para orientar condutas e protocolos assistenciais. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2 - CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS COM A SAÚDE (CID-10)** -->
- C71.0 Neoplasia maligna do cérebro, exceto lobos e ventrículos (neoplasia maligna supratentorial SOE);  
- C71.1 Neoplasia maligna do lobo frontal;  
- C71.2 Neoplasia maligna do lobo temporal;  
- C71.3 Neoplasia maligna do lobo parietal;  
- C71.4 Neoplasia maligna do lobo occipital;  
- C71.5 Neoplasia maligna do ventrículo cerebral (exclui quarto ventrículo, C 71.7);  
- C71.6 Neoplasia maligna do cerebelo;  
4  
- C71.7 Neoplasia maligna do tronco cerebral (neoplasia maligna infratentorial SOE);  
- C71.8 Neoplasia maligna do encéfalo com lesão invasiva (neoplasia maligna que comprometa dois ou mais locais contíguos dentro desta categoria de três algarismos, e cujo local de origem não possa ser determinado);  
- C71.9 Neoplasia maligna do encéfalo, não especificado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3- CRITÉRIOS DE INCLUSÃO** -->
Estas Diretrizes orientam condutas diagnósticas e terapêuticas institucionais para pacientes que se enquadram no seguintes critérios:  
- Idade ≥ 18 anos; e  
- diagnóstico morfológico ou presuntivo de glioma.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **4 - CRITÉRIOS DE EXCLUSÃO** -->
Ficam excluídos da abrangência destas Diretrizes os casos de:  
- Tumor com elementos embrionários (meduloepitelioma, tumor neuroectodérmico  
- primitivo, meduloblastoma, neuroblastoma, retinoblastoma e ependimoma);  
 tumor da região selar (adenoma hipofisário, carcinoma hipofisário e craniofaringioma);  
 tumor de origem linfo-hematopoética (linfomas, plasmocitoma e sarcoma granulocítico);  
 tumor de células germinativas (germinoma, carcinoma embrionário, tumor do seio endodérmico, coriocarcinoma, teratoma e tumores germinativos mistos);  
- tumor de meninge (meningioma, sarcomas e tumores melanocíticos);  
- tumores dos nervos cranianos e espinhais (neurofibroma, neurinoma e  
- Schwanoma maligno); e  
- metástase(s) cerebral(ais).  
5

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **5 - DIAGNÓSTICO** -->
A avaliação inicial compreende o exame físico e neurológico detalhados e exames de neuroimagem. A extensão da doença é diagnosticada minimamente por tomografia computadorizada contrastada (TC), complementada, se disponíveis, por ressonância magnética (RM) e espectroscopia/perfusão<sup>(63, 64)</sup> .  
O diagnóstico definitivo é firmado pelo estudo histopatológico. Nos pacientes candidatos à cirurgia, recomenda-se que o diagnóstico seja realizado pelo procedimento cirúrgico definitivo. Nos pacientes que não são candidatos à cirurgia como primeiro tratamento (por condições clínicas do paciente desfavoráveis ou localização do tumor em áreas críticas), o diagnóstico poderá ser obtido por intermédio de biópsia estereotáxica ou a céu aberto. Preferencialmente, o patologista deve ser informado sobre o quadro clínico do doente e os achados ao exame de neuroimagem. A gradação dos tumores é baseada em aspectos histopatológicos, quais sejam: atipias nucleares, índice mitótico, proliferação endotelial e grau de necrose<sup>(65)</sup> .  
<mark>Embora se proceda à biópsia para o diagnóstico histopatológico nos tumores cerebrais, as lesões de tronco cerebral são uma exceção, dado o potencial de complicações relacionado ao procedimento. Nesse sentido, o diagnóstico se ancora, iminentemente, na RM, sendo ela o guia da conduta terapêutica. Embora estudos que avaliaram o diagnóstico de gliomas de tronco cerebral tenham mostrado resultados favoráveis para a biópsia, esta resultou em maior risco de complicações que a RM</mark><sup>(66, 67)</sup> <mark>. Sendo assim, a biópsia estereotáxica pode ser indicada, considerando os critérios clínicos e a avaliação dos seus riscos e benefícios para o paciente.</mark>  
De acordo com o número de achados histopatológicos, os gliomas são classificados pela Organização Mundial da Saúde (OMS)<sup>(65)</sup> em:  
- Grau I: Lesões não infiltrativas, com baixo potencial proliferativo, sem atipias nucleares, mitoses, proliferação endotelial ou necrose;  
- Grau II: Lesões em geral infiltrativas, com atipias nucleares e baixo índice mitótico, sem proliferação endotelial ou necrose;  
- Grau III: Lesões infiltrativas, com dois critérios presentes, em geral atipias nucleares e alto índice mitótico; e  
- Grau IV: Lesões infiltrativas, com três ou quatro critérios presentes.  
6

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: <u>Fatores genético-moleculares de diagnóstico</u> -->
Os principais marcadores genético-moleculares relacionados ao diagnóstico de gliomas são a codeleção 1p/19q, mutações no gene da isocitrato desidrogenase (IDH) 1 e 2 e metilação de MGMT<sup>(68)</sup> . Mutações no gene da IDH 1 e 2 são marcadores de gliomas de baixo grau. Quando identificadas em indivíduos com grau III indicam prognóstico favorável<sup>30</sup> . A metilação do MGMT apresenta valor prognóstico e preditivo de resposta à quimioterapia.  
A realização desses exames não é condição _sine qua non_ para o diagnóstico e tratamento, cabendo, quando disponível, a avaliação do status de mutação do gene IDH por imuno-histoquímica ou métodos moleculares.  
<u>Classificação morfológica</u>  
A morfologia (M) das neoplasias correspondente aos gliomas malignos (/3) primários do cérebro (C71.-) encontra-se especificada ao final do Volume 1 da CID-10:  
M9380/3 Glioma maligno (C71.-) M9381/3 Gliomatose cerebral (C71.-) M9382/3 Glioma misto (C71.-) M9400/3 Astrocitoma SOE (C71.-) M9401/3 Astrocitoma anaplástico (C71.-) M9410/3 Astrocitoma protoplásmico (C71.-) M9411/3 Astrocitoma gemistocítico (C71.-) M9420/3 Astrocitoma fibrilar (C71.-) M9421/3 Astrocitoma pilocítico (C71.-) M9424/3 Xantoastrocitoma pleomórfico (C71.-) M9440/3 Glioblastoma SOE (C71.-) M9441/3 Glioblastoma de células gigantes (C71.-) M9442/3 Gliossarcoma (C71.-) M9443/3 Espongioblastoma polar primitivo (C71.--) M9450/3 Oligodendroglioma SOE (C71.-) M9451/3 Oligodendroglioma anaplástico (C71.-) M9460/3 Oligodendroblastoma (C71.-)  
<u>Classificação patológica segundo a Organização Mundial da Saúde (OMS)</u>  
7  
Com base na OMS<sup>65,68</sup> , a classificação patológica dos gliomas cerebrais encontra-  
se na

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Figura 1** e no **Quadro 1** . -->
<!-- Start of picture text -->
Astrocitoma  Oligoastrocitoma  Oligodendroglioma  Glioblastoma<br>IDH-mutados  IDH tipo selvagem  Teste genético não  IDH-mutados  IDH tipo selvagem<br>realizado ou não<br>conclusivo<br>Perda de ATRX *  Codeleção 1 p- 9q<br>Mutação  TP53 *<br>Após a exclusão de outros   Astrocitoma difuso, NAE<br>Astrocitoma difuso IDH-mutados  Oligodendroglioma Codeleção IDH-mutados e  1p-q9 tipos:   Astrocitoma difuso Oligodendroglioma, NAE   Oligodendroglioma, NAE Oligoastrocitoma, NAE Glioblastoma, NAE   Glioblastoma, IDH-mutados   Glioblastoma, IDH tipo selvagem<br>Histologia  Status IDH  Parâmetros genéticos  Tipo de glioma<br>1p-q9 e outros<br><!-- End of picture text -->  
**Figura 1 -** Classificação da Organização Mundial da Saúde de glioma difuso.  
* Característica, mas não necessária para o diagnóstico; IDH: fosfato-desidrogenase; ATRX: síndrome alfa talassemia/retardo mental ligada ao X; NAE: não anteriormente especificados.  
**Quadro 1 -** Classificação da Organização Mundial da Saúde (OMS) de gliomas  
astrocíticos e oligodendrogliais  
|**Classificação do Tumor**|**Grau**<br>**do**<br>**Tumor**|**Definição * ou aspectos**<br>**característicos genéticos**<br>**moleculares**|
|---|---|---|
|**_Tumores astrocíticos_**|||
|Astrocitoma difuso, IDH-mutados|II|Mutação_IDH1/2 *,_mutação<br>_TP53,_mutação ATRX|
|Astrocitoma difuso, IDH tipo selvagem|II|Sem mutação_IDH1/2_|
|Astrocitoma anaplásico, IDH-mutados|III|Mutação_IDH1/2 *,_mutação<br>_TP53,_mutação ATRX|  
8  
|Astrocitoma<br>anaplásico,<br>IDH<br>selvagem|tipo|III|Sem mutação_IDH1/2_|
|---|---|---|---|
|Glioblastoma, IDH-mutados||IV|Mutação_IDH1/2 *,_mutação<br>_TP53,_mutação ATRX|
|Glioblastoma, IDH tipo selvagem||IV|Sem mutação_IDH1/2,_mutação<br>promotora_TERT_|
|Glioblastoma, NAE||IV|Teste genético não realizado ou<br>não conclusivo|
|Glioma difuso da linha mediana,<br>_K27M_mutado|_H3_|IV|Mutação_H3 K27M *_|
|**_Tumores oligodendrogliais_**||||
|Oligodendroglioma,<br>IDH-mutados<br>codeleção 1p/19q|<br>e|II|Mutação_IDH1/2 *,_codeleção<br>1p/19q*, sem mutação ATRX_,_<br>mutação promotora_TERT_|
|Oligodendroglioma, NAE||II|Teste genético não realizado ou<br>não conclusivo|
|Oligoastrocitoma, NAE||II|Teste genético não realizado ou<br>não conclusivo|
|Oligodendroglioma<br>anaplásico,<br>I<br>mutados e codeleção 1p/19q|DH-|III|Mutação_IDH1/2 *,_codeleção<br>1p/19q*, sem mutação ATRX_,_<br>mutação promotora_TERT_|
|Oligodendroglioma anaplásico, NAE||III|Teste genético não realizado ou<br>não conclusivo|
|Oligoastrocitoma anaplásico, NAE||III|Teste genético não realizado ou<br>não conclusivo|  
* Alterações que definem a entidade de classificação da OMS são marcadas por um asterisco; IDH: fosfato-desidrogenase; ATRX: síndrome alfa talassemia / retardo mental ligada ao X; NAE: não anteriormente especificados;

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6 - TRATAMENTO** -->
<mark>Os pacientes devem ser avaliados e o plano de tratamento determinado por uma equipe multidisciplinar especializada, incluindo neurocirurgião, oncologista clínico, radioterapeuta, patologista e neuroradiologista</mark><sup>(69)</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **<mark>6.1. Cuidados gerais</mark>** -->
9  
<mark>De modo geral, são medicamentos utilizados nos cuidados clínicos dos pacientes:</mark> <u><mark>Corticosteroides: O uso de corticosteroide (geralmente</mark></u> dexametasona 8-16 mg/di <mark>a) permite uma redução rápida do edema cerebral associado ao tumor e melhora os sintomas. Os níveis de glicose dos pacientes precisam ser monitorados. Os esteroides não são necessários em pacientes sem aumento da pressão intracraniana ou na ausência de déficits neurológicos associados ao edema. Não há necessidade de terapia prolongada com esteroide após ressecção tumoral ou profilaxia durante a radioterapia em pacientes assintomáticos. É possível reduzir rapidamente e suspender o corticosteroide, para evitar os efeitos tóxicos associados à exposição prolongada, como miopatia e fraqueza, linfopenia e risco de infecção, osteoporose e síndrome de Cushing</mark><sup>(69)</sup> <mark>.</mark>  
<u><mark>Antiepilépticos: São indicados em pacientes com convulsões; no entanto, o uso</mark></u> <mark>profilático de anticonvulsivantes fora da fase perioperatória não é indicado. Após a ressecção do tumor, a indicação de terapia anti-convulsiva só deve ser utilizada se ocorrer convulsão</mark><sup>(70, 71)</sup> <mark>. Necessita-se cautela e vigilância com o uso de fenitoína durante a radioterapia, pelo risco de síndrome de S</mark> teven-Jonhson <mark>. Igualmente, necessita-se vigilância com o uso de ácido valproico por ele potencializar a fadiga e plaquetopenia, se em uso concomitante com a quimioterapia. Estudos que compararam a eficácia entre os anticonvulsivantes, em pacientes com gliomas, não foram capazes de demonstrar superioridade de u</mark> m <mark>em detrimento ao outro</mark><sup>(72-77)</sup> <mark>.</mark>  
<u><mark>Anticoagulantes: Os pacientes com glioma apresentam risco aumentado de</mark></u> <mark>eventos tromboembólicos devido a um estado pró-trombótico induzido pelo próprio tumor, pela quimioterapia, pela imobilização e pelo uso de esteroides</mark><sup>(78)</sup> <mark>. A anticoagulação profilática não é recomendada, porém a investigação ativa faz-se necessária diante de suspeita de tromboembolismo e, se confirmado, este deverá ser tratado. A presença de um tumor cerebral não é uma c</mark> ontraindicação <mark>para o uso de anticoagulantes padrão em pacientes com trombose comprovada</mark><sup>(69)</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.2. Gliomas graus I e II** -->
Para o tratamento dos gliomas de baixo grau são utilizadas várias modalidades terapêuticas, de forma isolada ou combinada.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.2.1. Tratamento cirúrgico** -->
<mark>A cirurgia é o tratamento de escolha para os casos de tumores primários do cérebro. A ressecção tumoral deve ser máxima, desde que a função neurológica não seja</mark>  
10  
<mark>comprometida pela extensão da ressecção, já que esta confere valor prognóstico</mark><sup>(79)</sup> <mark>. Quando a ressecção microcirúrgica não é segura (por exemplo, devido à localização do tumor ou condição clínica desfavorável do paciente), uma biópsia deve ser procedida</mark><sup>(69)</sup>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.2.2. Radioterapia** -->
Os fatores relacionados ao paciente, ao tumor e ao tipo de ressecção procedida interferem no prognóstico e na terapia adjuvante, pós-operatória. A sobrevivência mediana de pacientes com astrocitoma, glioma misto e oligodendroglioma foi, respectivamente, de 5,2, 5,6 e 7,2 anos nos EUA entre 2001 e 2011<sup>(80)</sup> . Além de existir uma correlação entre idade e histologia tumoral, pacientes jovens tendem a apresentar lesões de baixo grau associadas à localização de acesso cirúrgico mais favorável e se apresentarem oligossintomáticos. Com esses fatores, uma conduta conservadora após a cirurgia pode ser levada em conta. Pacientes idosos, com lesão residual após a cirurgia e com sintomas progressivos geralmente necessitam de uma terapia imediata mais agressiva, como radioterapia adjuvante ou mesmo sua associação com quimioterapia.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: <u>Radioterapia adjuvante de gliomas de baixo grau</u> -->
A radioterapia é, historicamente, utilizada como tratamento adjuvante à cirurgia, para tratar doença residual em pacientes com astrocitoma difuso. Pode também ser utilizada como “resgate”, quando comprovada evolução da doença radiológica, piora neurológica ou mesmo na documentação de transformação maligna.  
Controvérsias em relação à radioterapia em casos de glioma de baixo grau envolvem o momento ideal de sua aplicação e sua dose. O estudo EORTC ( _European Organization for Resarch and Treatment of Cancer_ ) 22845<sup>(81)</sup> demonstrou que a radioterapia imediata prolongou o tempo livre de progressão tumoral quando comparada à radioterapia aplicada somente no momento da progressão tumoral, sem afetar a sobrevida global dos pacientes. Porém, esse estudo não considerou o tipo de cirurgia e idade dos pacientes, fatores de grande importância no prognóstico, bem como a qualidade de vida dos pacientes tratados.  
Recomenda-se a radioterapia adjuvante, imediatamente após a cirurgia, nos pacientes com gliomas de baixo grau operados com as seguintes características:  
- Idade maior que 40 anos;  
11  
- doença recorrente ou em progressão;  
- tumores com diâmetro maior que 6 cm;  
- persistência ou progressão de sintomas ou sinais neurológicos;  
- lesões que crescem na região da linha média.  
A dose de radiação utilizada normalmente é de 50,4 Gy a 54 Gy com frações de 1,8Gy/dia, 5 dias/semana. Estudos que avaliaram doses de radiação mais elevadas como tratamento inicial não demonstraram aumento na sobrevida dos pacientes<sup>(82, 83)</sup> , que aumentam os efeitos tóxicos das doses elevadas de radiação.  
Quanto às técnicas de radioterapia utilizadas, a tridimensional é de fundamental importância para localização correta da área irradiada de interesse, permitindo alcançar a dose terapêutica adequada enquanto se tenta preservar as estruturas sadias adjacentes<sup>(84)</sup> . A técnica IMRT (Radioterapia de Intensidade Modulada) melhora significativamente a distribuição de dose com melhor preservação dos tecidos adjacentes em lesões próximas a estruturas eloquentes, como o tronco cerebral e trato óptico.  
A definição adequada do volume de tratamento requer o uso da RM associada à tomografia computadorizada (TC) de planejamento, chamado de fusão de imagens, e acessórios de imobilização que permitam a melhor reprodutibilidade diária (p.ex., apoio de cabeça e máscara termoplástica). Baseado em dados do protocolo RTOG 9802<sup>(83)</sup> e padrão de recidivas em variantes mais agressivas<sup>(85)</sup> , a definição dos volumes segue os seguintes critérios:  
 GTV ( _Gross Tumor Volume_ ) deve contemplar a cavidade cirúrgica vista na TC de planejamento somado à imagem de realce ao contraste paramagnético na ressonância após cirurgia e áreas com alteração de sinal nas sequências T2/FLAIR.  
 CTV ( _Clinical Target Volume_ ) adicionar margens de 1 cm ao GTV.  
 PTV ( _Planning Target Volume_ ), adicionar margens de 0,5 cm ao CTV.  
<u>Radioterapia adjuvante concomitante à quimioterapia – Gliomas de baixo grau</u>  
As evidências científicas disponíveis não demonstram benefício para radioterapia em uso concomitante à quimioterapia no tratamento adjuvante de adultos com glioma de  
12  
baixo grau<sup>(5)</sup> . Desta forma, não se recomenda radioterapia adjuvante concomitante à quimioterapia em gliomas graus I e II.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: <u>Radioterapia exclusiva de gliomas de baixo grau</u> -->
Pacientes com lesões não ressecadas devido à sua localização em áreas eloquentes ou pacientes com sintomas progressivos devem ter seu tratamento discutido individualmente, considerando os fatores prognósticos relacionados à doença (histologia, grau e, se disponível, perfil molecular) e ao paciente, para a definição quanto à finalidade curativa ou paliativa da radioterapia. Dessa forma, procede-se com escolha da técnica, dose e utilização ou não de quimioterapia concomitante. Cuidados paliativos devem ser considerados para os pacientes sintomáticos com lesões irressecáveis que acumulam mais de dois fatores prognósticos desfavoráveis.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: <u>Radioterapia nas recidivas de gliomas de baixo grau</u> -->
Apesar do prognóstico reservado em caso de lesões recidivadas, quando uma nova ressecção cirúrgica não pode ser procedida, a radioterapia com técnicas que permitem uma melhor localização da(s) lesão(ões) e elevadas doses de radiação por fração, como a radiocirurgia (dose única) ou radioterapia estereotáxica fracionada, podem ser utilizadas, quando disponíveis<sup>(86)</sup> Porém, tais casos devem ser avaliados para conduta individualizada de acordo com os riscos de nova aplicação de radioterapia e os benefícios que essa conduta trará ao paciente.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.2.3. Quimioterapia** -->
<mark>Os pacientes selecionados para terapia pós-operatória imediata devem receber radiação e quimioterapia sequencial.</mark>  
<mark>Estudos que avaliaram a combinação de radioterapia, na dose de 54 Gy em 30 frações, e quimioterapia com procarbazina, lomustina e vincristina (PCV) em seis ciclos, mostraram maior sobrevida global após dois anos e maior sobrevida livre de progressão tumoral em 2, 5 e 10 anos</mark><sup>(87-89)</sup> <mark>. Dessa forma, recomenda-se o uso da combinação de radioterapia 54 Gy em 30 frações associado a quimioterapia com PCV (6 ciclos (8 semanas cada ciclo) pós-radioterapia com procarbazina 60 mg/m</mark><sup>2</sup> <mark>, lomustina (CCNU) 110 mg/m</mark><sup>2</sup> <mark>e vincristina 1,4 mg/m</mark><sup>2</sup> <mark>).</mark>  
<mark>Ainda não está claro o papel da temozolomida (TMZ) na quimioterapia de gliomas de baixo grau e não existem estudos que comparem diretamente a TMZ com o esquema</mark>  
13  
<mark>PCV. Estudos de longo prazo não evidenciaram aumento de sobrevida nem da qualidade de vida dos pacientes tratados com radioquimoterapia com TMZ em relação àqueles somente submetidos à radioterapia</mark><sup>(5, 90)</sup> <mark>. No entanto, a TMZ tem sido prescrita, mormente por seu perfil de segurança ou impossibilidade de uso do esquema PVC.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.3. Gliomas graus III e IV – Gliomas de alto grau** -->
Para o tratamento dos gliomas de alto grau são utilizadas as mesmas modalidades terapêuticas que se utilizam para tratar os glioma de baixo grau.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.3.1. Tratamento cirúrgico** -->
<mark>A cirurgia é sempre o tratamento de escolha para os casos de tumores primários do cérebro. A ressecção tumoral deve ser máxima, desde que a função neurológica não seja comprometida pela extensão da ressecção, já que esta confere valor prognóstico</mark><sup>(78)</sup> <mark>. Quando a ressecção microcirúrgica não é segura (por exemplo, devido à localização do tumor ou condição clínica desfavorável do paciente), uma biópsia deve ser realizada</mark><sup>(69)</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.3.2. Radioterapia** -->
Para a decisão terapêutica, fatores prognósticos devem ser considerados<sup>(91)</sup> , como a condição clínica (capacidade funcional) do paciente, avaliada por meio da escala de KPS ( _Karnofsky Performance status_ ) - variável de 100 (sem sinais ou queixas, sem evidência de doença) a ≤ 10 (paciente agônico),  e da chamada RPA ( _Recursive Partitioning analysis_ )<sup>(92, 93)</sup> .  
Os fatores abaixo estão intimamente ligados à piora da mediana de sobrevida dos pacientes:  
- Idade ≥ 50 anos.  
- KPS < 70  
- Diagnóstico histopatológico de astrocitoma anaplásico ou glioblastoma.  
- Sintomas e sinais neurológicos presentes e de rápida progressão (< 3 meses)  
- Ressecção cirúrgica parcial ou apenas biópsia.  
<u>Radioterapia adjuvante de gliomas de alto grau</u>  
14  
Entre as principais condutas adjuvantes à cirurgia em pacientes com gliomas de alto grau, a radioterapia é comprovadamente a mais eficaz. Um estudo do BTCG ( _Brain Tumor Cooperative Group_ )<sup>(94)</sup> demonstrou aumento da sobrevida dos pacientes tratados com radioterapia pós-operatória quando comparada aos pacientes tratados exclusivamente com cirurgia. Quando comparada à quimioterapia adjuvante exclusiva, a radioterapia também foi mais efetiva. Quanto à dose de radiação a ser utilizada, o aumento da dose de 50 Gy para 60 Gy trouxe melhoras no tempo de sobrevida. Pacientes que receberam além dessa dose apresentaram aumento nas possibilidades de efeitos colaterais (95).  
Estudos que compararam o uso de temozolamida na dose de 75 mg/m2 concomitante à radioterapia e temozolamida 200mg/m<sup>2</sup> adjuvante à radioterapia, 5 dias na semana durante 6 meses, _versus_ somente a radioterapia (sem placebo ou outro esquema quimioterápico) demonstraram ganho de sobrevida global<sup>(96, 97)</sup> . Pacientes que apresentaram metilação da enzima MGMT evidenciaram benefício maior com a utilização da temozolamida.  
O uso da radioterapia tridimensional permite o adequado controle das doses de radiação liberadas no volume-alvo e estruturas normais adjacentes, fazendo do seu uso indispensável no tratamento de gliomas de alto grau. A técnica de radioterapia com feixe de intensidade modulada (IMRT) pode ser utilizada em situação em que a área a ser irradiada está adjacente às áreas eloquentes, como o tronco cerebral ou vias ópticas. Assim como nos gliomas de baixo grau, a fusão de imagens da tomografia computadorizada (TC) de planejamento com a RM pós-operatória apresenta particular interesse por fornecer informações precisas sobre o volume tumoral remanescente, áreas de edemas peri-tumorais e estruturas normais de interesse.  Os acessórios de imobilização devem ser customizados, buscando a reprodutibilidade e o máximo conforto do paciente por meio de apoios para cabeça e máscaras termoplásticas.  
Quanto à definição dos volumes de interesse, um estudo do RTOG ( _Radiation Therapy Oncology Group_ ) dividiu o tratamento em duas fases, sendo:  
 <u>Fase 1</u>  
GTV1: Cavidade cirúrgica vista à TC de planejamento + áreas de captação ao contraste paramagnético nas sequências ponderadas em T1 + áreas de alteração de sinal  
15  
nas adjacências à cavidade cirúrgica nas sequências ponderadas em T2/FLAIR. (RM pósoperatória)  
CTV1: GTV1 + 1 a 2 cm. Excluindo áreas sabidamente não acometidas pela doença que podem apresentar barreiras anatômicas à disseminação tumoral como ventrículos e ossos.  
PTV1: CTV1 + 3 a 5 mm.  
Dose: 46 a 50 Gy (1,8 a 2 Gy / dia – 5 dias /semana)  
- <u>Fase 2</u>  
GTV2: Cavidade cirúrgica vista à TC de planejamento + áreas de captação ao contraste paramagnético nas sequencias ponderadas em T1 (RNM pós-operatória).  
CTV2: GTV2 + 1 a 2 cm. Excluindo áreas sabidamente não acometidas pela doença que podem apresentar barreiras anatômicas à disseminação tumoral como ventrículos e ossos.  
PTV2: CTV2 + 3 a 5 mm.  
Dose: 60 Gy (1,8 a 2 Gy / dia – 5 dias/semana)

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: <u>Radioterapia de gliomas de alto grau não ressecados</u> -->
Assim como em casos de glioma de baixo grau, pacientes com lesões de alto grau não ressecadas devido à localização da lesão em áreas eloquentes ou pacientes com sintomas progressivos devem ter seu tratamento discutido individualmente, considerando-se os fatores prognósticos para definir a finalidade curativa ou paliativa da radioterapia. Dessa forma, procede-se à escolha da técnica e dose da radioterapia e sua combinação, ou não, com a quimioterapia. Cuidados paliativos devem ser considerados para os pacientes sintomáticos que acumulam fatores prognósticos desfavoráveis.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.3.3. Quimioterapia** -->
<mark>Estudos demostraram que a quimioterapia com TMZ concomitante à radioterapia e adjuvante à radioterapia foi superior em termos de eficácia quando comparada à</mark>  
16  
<mark>radioterapia isolada, ou seja</mark> sem placebo ou outro esquema quimioterápico<sup>(79, 96, 98-108)</sup> <mark>. A TMZ é administrada diariamente (7 dias por semana) durante a radioterapia (concomitante) e, durante a fase de manutenção, durante 5 dias a cada 4 semanas por 6 meses, podendo este tempo ser estendido por 12 meses, de acordo com o protocolo institucional</mark><sup>(99, 109)</sup> **<mark>.</mark>**  
<mark>Com pacientes idosos, os estudos que avaliaram esquemas com TMZ em monoterapia ou concomitante e adjuvante à radioterapia mostraram benefícios significantes, principalmente nos grupos de pacientes com metilação do MGMT (105, 110, 111). A metilação do promotor MGMT é fortemente preditiva para o benefício da quimioterapia TMZ, sugerindo que os pacientes com MGMT metilado obtêm melhores resultados com quimioterapia do que aqueles pacientes sem a metilação.</mark>  
<u><mark>Glioma de alto grau após a recidiva</mark></u>  
No caso de recidiva de glioma de alto grau, se indicado tratamento, pode ser realizada nova ressecção cirúrgica. Quando esta não for possível, a radioterapia com técnicas de radiocirurgia (fração única) ou radioterapia estereotáxica fracionada podem ser utilizadas. Esquemas de quimioterapia de segunda linha podem ser indicados. Muitas vezes, cuidados paliativos exclusivos representam uma opção melhor para pacientes em tais condições.  
<mark>A quimioterapia paliativa do glioma de alto grau recorrente pode ser feita com nitrosureia (carmustina ou temozolomida), inclusive re-exposição a TMZ em dose protraída (50mg/m</mark><sup>2</sup> <mark>), ou com lomustina ou irinotecano associada a bevacizumabe</mark><sup>(112-114)</sup> **<mark>.</mark>** <mark>Porém, muitos esquemas quimioterápicos são possíveis, em monoterapia ou em poliquimioterapia, utilizando carmustina, lomustina, irinotecano, temozolamida, bevacizumabe, procarbazina, carboplatina e vincristina.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.4.1. Gliomas de tronco cerebral em adultos** -->
São gliomas de comportamento e localização específicos, originando-se no tronco cerebral, ponte ou medula oblonga, podendo estender-se para o cerebelo, pedúnculo cerebelar ou terço superior da medula espinhal em sua região cervical. Ao contrário do  
17  
que se observa em crianças, em que o glioma de tronco é frequente (cerca de 20% dos tumores cerebrais) e possui um comportamento mais agressivo, o glioma de tronco em adultos representa de 1% a 2% dos gliomas em adultos e apresenta um comportamento favorável.  
Os gliomas de tronco cerebral apresentam um curso heterogêneo relacionado à sua extensão (focal ou difuso) e padrão radiológico ou, quando a biópsia e o exame patológico foram viáveis, padrão histopatológico. Com isso, são classificados em difusamente infiltrativo, focal, exofítico e glioma tectal.  
O glioma de tronco cerebral difusamente infiltrativo é o mais comum entre as outras variantes dessa localização e, em adultos, normalmente apresenta-se como lesão de baixo grau e de comportamento indolente, assim como as variantes exofítica e tectal. Já o glioma focal com captação do contraste paramagnético visto nas sequências em ponderação T1 na ressonância magnética (RM), normalmente é de alto grau e de comportamento mais agressivo.  
Exceto as lesões focais exofíticas de localização posterior com protrusão para o quarto ventrículo, as demais lesões não são operáveis, sendo a radioterapia a principal modalidade terapêutica. A cirurgia normalmente é realizada para diagnóstico histopatológico ou para derivações ventriculares em pacientes sintomáticos ou potencialmente sintomáticos.  
A radioterapia representa a principal modalidade terapêutica para os gliomas de tronco cerebral, podendo levar a uma diminuição ou mesmo estabilização nas suas dimensões. Devido ao comportamento variável de grande parte dessas lesões, o momento ideal para iniciar-se a radioterapia é tema de grande debate, visto que alguns pacientes podem passar anos com a lesão estável e sem manifestar qualquer sintoma, podendo alguns deles até serem conduzidos com derivação ventricular e seguimento. O diagnóstico histopatológico ou as características clínicas e radiológicas podem auxiliar no momento ideal para o início da radioterapia, que deve ser imediata em lesões com características desfavoráveis.  
Assim como nas lesões supratentoriais, a técnica minimamente aceitável é a tridimensional conformada com o uso adequado dos acessórios de imobilização. A  
18  
radiocirurgia ou a radioterapia estereotáxica fracionada pode ser utilizada, com resultados promissores, em lesões focais que captam contraste paramagnético à RM.  
A dose de radioterapia pode variar de 54 a 59,4 Gy com frações de 1,8 Gy/dia, 5 dias na semana, não havendo evidência de superioridade para fracionamentos alternativos (hiperfracionamento ou hipofracionamento)<sup>(43)</sup> .  
Para o planejamento da radioterapia, a fusão das imagens da TC de planejamento com RM é utilizada para a delimitação precisa da lesão a ser irradiada e das estruturas normais adjacentes.  
A definição dos volumes de tratamento segue os mesmos princípios dos gliomas supratentoriais:  
 GTV: Lesão vista à TC de planejamento + áreas de alteração de sinal nas sequencias T2/FLAIR da RNM + áreas de captação ao contraste paramagnético nas sequências ponderadas em T1 da RM.  
 CTV: GTV + 1 cm. Em lesões infiltrativas difusas com grande alteração de sinal nas sequências ponderadas em T2/FLAIR todo tronco cerebral deve ser incluído no CTV. O CTV deve ser editado excluindo-se áreas que representam potencial barreira anatômica para disseminação tumoral local, como os ventrículos cerebrais.  
 PTV: CTV + 3 a 5 mm.  
Inexiste evidência de que a quimioterapia agregue benefícios quando associada à radioterapia.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **6.4.2. Gliomas do trato óptico** -->
Glioma do trato óptico ocorre no trajeto dos nervos ópticos e frequentemente acomete crianças menores que 10 anos (75% dos casos). Quando ocorre em adultos, o que é raro, é tipicamente associado uma lesão de baixo grau, em sua maioria astrocitoma pilocítico. Tem forte associação com neurofibromatose do tipo 1 e sua localização é classificada como pré-quiasmática, quiasmática ou hipotalâmica. Cursa comumente com alteração da acuidade visual e protusão do globo ocular (proptose). A RM mostra, normalmente, lesão circunscrita e homogênea iso- ou hiperintensa nas sequências ponderadas em T2/FLAIR e isointensa em T1. A biópsia para o diagnóstico  
19  
histopatológico usualmente não é realizada, e o diagnóstico é feito com base nos achados clínicos e de imagem.  
Tipicamente, devido ao seu comportamento indolente, os casos de glioma do trato óptico são mantidos com observação, sendo tratados quando as lesões são progressivas ou sintomáticas. A radioterapia, apesar de oferecer um bom controle local, deve ser postergada o máximo possível devido à sua toxicidade local aguda e tardia, que leva à perda da acuidade visual, vasculopatias e disfunções endócrinas.  
A radioterapia normalmente é indicada em lesões progressivas ou refratárias a despeito do tratamento com quimioterapia ou então em lesões com extensão intracraniana. A dose de radiação utilizada tipicamente é entre 45 e 54 Gy com frações de 1,8 Gy/dia, 5 dias na semana, por técnica de radioterapia estereotáxica fracionada. A fusão de imagens com a RNM é mandatória para localização da lesão e estruturas adjacentes, assim como a técnica tridimensional é a mínima aceitável<sup>(115)</sup> .  
A vincristina e a carboplatina continuam sendo os antineoplásicos utilizados na quimioterapia de glioma do tronco cerebral.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **7 - MONITORIZAÇÃO** -->
- <mark>Exames laboratoriais prévios à quimioterapia: hemograma, creatinina sérica, aminotransferases/transaminases (ALT/TGP e AST/TGO), gamaglutamiltransferase (gamaGT) e glicemia.</mark>  
- <mark>Exames laboratoriais durante a radioquimioterapia: hemograma semanal.</mark>  
- <mark>Exames de neuroimagem: pré-tratamento, 45-90 dias após a radioquimioterapia e ao término da quimioterapia pós-operatória.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **7.1. Avaliação da resposta terapêutica** -->
20  
<mark>A avaliação da resposta ao tratamento antineoplásico paliativo é baseada na observação clínica e não pode ser feita exclusivamente por achados a exemae de neuroimagem.</mark>  
<mark>Alguns estudos observacionais avaliaram a monitorização do indivíduo com glioma, comparando os critérios de Mc Donald, RECIST e RANO</mark><sup>(116-120)</sup> <mark>. No entanto, devido à baixa qualidade desses estudos e ao fato de avaliarem desfechos e intervenções diferentes, não é possível recomendar um critério em detrimento de outro.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **7.2.Critérios de interrupção do tratamento** -->
<mark>A radioterapia paliativa deve ser suspensa na evidência clínico-neurológica progressão de doença.</mark>  
<mark>A quimioterapia deve ser suspensa, temporária ou definitivamente, na ocorrência</mark>  
<mark>de:</mark>  
- <mark>Toxicidade clínica graus 3 e 4, conforme os parâmetros propostos pelo</mark> _<mark>National Cancer Institute</mark>_ <mark>(EUA), de uso internacional;</mark>  
- <mark>redução da capacidade funcional do doente para os níveis 3 (confinado ao leito mais de 50% do dia;</mark> corresponde ao KPS = 30%-40% <mark>) ou 4 (totalmente confinado ao leito; corresponde ao KPS < 30%) da escala de Zubrod;</mark>  
- <mark>após seis ciclos de quimioterapia, nos doentes que recebem tratamento pósoperatório e não apresentam lesão residual;</mark>  
- <mark>a qualquer tempo, na evidência clínico-neurológica de progressão de doença;</mark>  
- <mark>falta de adesão ao tratamento;</mark>  
- <mark>manifestação voluntária do doente, após esclarecimento dos riscos envolvidos.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **8 - ACOMPANHAMENTO PÓS-TRATAMENTO** -->
 Consulta e exame físico, no mínimo a cada três meses no primeiro ano; quadrimestral no segundo ano; semestral no terceiro ano; e anual após, por toda a vida do doente.  
 Exames laboratoriais e de neuroimagem devem ser solicitados em bases individuais, de acordo com os sintomas e sinais notados durante o acompanhamento.  
21

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **9 - REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
É fundamental a observância aos protocolos e diretrizes diagnósticas e terapêuticas  publicados pelo Ministério da Saúde, todos disponíveis em http://conitec.gov.br/index.php/protocolos-e-diretrizes. Na ausência de protocolos publicados por este Ministério, os hospitais habilitados para a assistência de alta complexidade em oncologia no SUS devem estabelecer seus protocolos assistenciais, inclusive utilizando estas Diretrizes como orientadoras.<sup>(121)</sup>  
Doentes adultos com diagnóstico de neoplasia maligna cerebral devem ser preferencialmente atendidos em hospitais habilitados em oncologia com serviço de radioterapia e minimamente naqueles com porte tecnológico suficiente para diagnosticar, tratar e acompanhar.  
Além da familiaridade que esses hospitais guardam com a avaliação da extensão da doença, o tratamento, a prescrição das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e avaliação. Ações de controle e avaliação incluem, entre outras:  
- manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES);  
- autorização prévia dos procedimentos;  
 monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos);  
 verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente - primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica).  
Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso  
22  
assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Com poucas exceções, o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS, sem necessariamente indicar quais são esses medicamentos. Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do medicamento antineoplásico é desse hospital, seja ele público ou privado, com ou sem fins lucrativos.  
Os procedimentos radioterápicos (Grupo 03, Subgrupo 01) e cirúrgicos (Grupo 04, Subgrupo 03) da Tabela de Procedimentos, Medicamentos e OPM do SUS podem ser acessados, por código do procedimento ou nome do procedimento e por código da CID – Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde – para a respectiva neoplasia maligna, no SIGTAP - Sistema de Gerenciamento dessa Tabela, com versão mensalmente atualizada e disponbilizada em http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp?first=10).

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **10 - REFERÊNCIAS** -->
1. Chemotherapy for high-grade glioma. The Cochrane database of systematic reviews. 2002(4):Cd003913.  
2. Blomgren H. Brain tumors. Acta oncologica (Stockholm, Sweden). 1996;35 Suppl 7:16 21.  
3. Gutin PH, Posner JB. Neuro-oncology: diagnosis and management of cerebral gliomas--past, present, and future. Neurosurgery. 2000;47(1):1-8.  
4. Chen C, Xu T, Chen J, Zhou J, Yan Y, Lu Y, et al. Allergy and risk of glioma: a meta-analysis. European journal of neurology. 2011;18(3):387-95.  
5. Baumert BG, Hegi ME, van den Bent MJ, von Deimling A, Gorlia T, HoangXuan K, et al. Temozolomide chemotherapy versus radiotherapy in high-risk low-grade  
23  
glioma (EORTC 22033-26033): a randomised, open-label, phase 3 intergroup study. The Lancet Oncology. 2016;17(11):1521-32.  
6. Li Y. Association between fruit and vegetable intake and risk for glioma: A metaanalysis. Nutrition. 2014.  
7. Zhao L, Zheng Z, Huang P. Diabetes mellitus and the risk of glioma: a metaanalysis. Oncotarget. 2016;7(4):4483-9.  
8. Adel Fahmideh M, Schwartzbaum J, Frumento P, Feychting M. Association between DNA repair gene polymorphisms and risk of glioma: a systematic review and meta-analysis. Neuro-oncology. 2014;16(6):807-14.  
9. Zhou P, Wei L, Xia X, Shao N, Qian X, Yang Y. Association between telomerase reverse transcriptase rs2736100 polymorphism and risk of glioma. The Journal of surgical research. 2014;191(1):156-60.  
10. Galeone C, Malerba S, Rota M, Bagnardi V, Negri E, Scotti L, et al. A metaanalysis of alcohol consumption and the risk of brain tumours. Annals of oncology : official journal of the European Society for Medical Oncology. 2013;24(2):514-23.  
11. Malerba S, Galeone C, Pelucchi C, Turati F, Hashibe M, La Vecchia C, et al. A meta-analysis of coffee and tea consumption and the risk of glioma in adults. Cancer causes & control : CCC. 2013;24(2):267-76.  
12. Mandelzweig L, Novikov I, Sadetzki S. Smoking and risk of glioma: a metaanalysis. Cancer causes & control : CCC. 2009;20(10):1927-38. 13. Niedermaier T, Behrens G, Schmid D, Schlecht I, Fischer B, Leitzmann MF. Body mass index, physical activity, and risk of adult meningioma and glioma: A meta-analysis. Neurology. 2015;85(15):1342-50. 14. Saneei P, Willett W, Esmaillzadeh A. Red and processed meat consumption and risk of glioma in adults: A systematic review and meta-analysis of observational studies. Journal of Research in Medical Sciences. 2015;20(6):602-12.  
15. Sergentanis TN, Tsivgoulis G, Perlepe C, Ntanasis-Stathopoulos I, Tzanninis IG, Sergentanis IN, et al. Obesity and Risk for Brain/CNS Tumors, Gliomas and Meningiomas: A Meta-Analysis. PLoS One. 2015;10(9):e0136974.  
16. Wei Y, Zou D, Cao D, Xie P. Association between processed meat and red meat consumption and risk for glioma: a meta-analysis from 14 articles. Nutrition. 2015;31(1):45-50.  
17. Myung SK, Ju W, McDonnell DD, Lee YJ, Kazinets G, Cheng CT, et al. Mobile phone use and risk of tumors: a meta-analysis. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2009;27(33):5565-72.  
18. Corle C, Makale M, Kesari S. Cell phones and glioma risk: a review of the evidence. Journal of neuro-oncology. 2012;106(1):1-13. 19. IARC. Non-Ionizing Radiation, Part 2: Radiofrequency Electromagnetic Fields. IARC monographs on the evaluation of carcinogenic risks to humans. 102. Lyon: IARC; 2013.  
20. Little MP, Rajaraman P, Curtis RE, Devesa SS, Inskip PD, Check DP, et al. Mobile phone use and glioma risk: comparison of epidemiological study results with incidence trends in the United States. BMJ (Clinical research ed). 2012;344:e1147.  
21. Deltour I, Auvinen A, Feychting M, Johansen C, Klaeboe L, Sankila R, et al. Mobile phone use and incidence of glioma in the Nordic countries 1979-2008: consistency check. Epidemiology (Cambridge, Mass). 2012;23(2):301-7. 22. Benson VS, Kirichek O, Beral V, Green J. Menopausal hormone therapy and central nervous system tumor risk: large UK prospective study and meta-analysis. International journal of cancer. 2015;136(10):2369-77.  
24  
23. Repacholi MH, Lerchl A, Roosli M, Sienkiewicz Z, Auvinen A, Breckenkamp J, et al. Systematic review of wireless phone use and brain cancer and other head tumors. Bioelectromagnetics. 2012;33(3):187-206.  
24. Braganza MZ, Kitahara CM, Berrington de Gonzalez A, Inskip PD, Johnson KJ, Rajaraman P. Ionizing radiation and the risk of brain and central nervous system tumors: a systematic review. Neuro-oncology. 2012;14(11):1316-24.  
25. Bowers DC, Nathan PC, Constine L, Woodman C, Bhatia S, Keller K, et al. Subsequent neoplasms of the CNS among survivors of childhood cancer: a systematic review. The Lancet Oncology. 2013;14(8):e321-8.  
26. Neglia JP, Robison LL, Stovall M, Liu Y, Packer RJ, Hammond S, et al. New primary neoplasms of the central nervous system in survivors of childhood cancer: a report from the Childhood Cancer Survivor Study. Journal of the National Cancer Institute. 2006;98(21):1528-37.  
27. Relling MV, Rubnitz JE, Rivera GK, Boyett JM, Hancock ML, Felix CA, et al. High incidence of secondary brain tumours after radiotherapy and antimetabolites. Lancet (London, England). 1999;354(9172):34-9.  
28. Pearce MS, Salotti JA, Little MP, McHugh K, Lee C, Kim KP, et al. Radiation exposure from CT scans in childhood and subsequent risk of leukaemia and brain tumours: a retrospective cohort study. Lancet (London, England). 2012;380(9840):499505.  
29. Davis F, Il'yasova D, Rankin K, McCarthy B, Bigner DD. Medical diagnostic radiation exposures and risk of gliomas. Radiation research. 2011;175(6):790-6.  
30. Colman SD, Williams CA, Wallace MR. Benign neurofibromas in type 1 neurofibromatosis (NF1) show somatic deletions of the NF1 gene. Nature genetics. 1995;11(1):90-2.  
31. Cichowski K, Shih TS, Schmitt E, Santiago S, Reilly K, McLaughlin ME, et al. Mouse models of tumor development in neurofibromatosis type 1. Science (New York, NY). 1999;286(5447):2172-6.  
32. Vogel KS, Klesse LJ, Velasco-Miguel S, Meyers K, Rushing EJ, Parada LF. Mouse tumor model for neurofibromatosis type 1. Science (New York, NY). 1999;286(5447):2176-9.  
33. Rouleau GA, Merel P, Lutchman M, Sanson M, Zucman J, Marineau C, et al. Alteration in a new gene encoding a putative membrane-organizing protein causes neurofibromatosis type 2. Nature. 1993;363(6429):515-21.  
34. Scoles DR, Huynh DP, Morcos PA, Coulsell ER, Robinson NG, Tamanoi F, et al. Neurofibromatosis 2 tumour suppressor schwannomin interacts with betaII-spectrin. Nature genetics. 1998;18(4):354-9.  
35. Bruder CE, Ichimura K, Blennow E, Ikeuchi T, Yamaguchi T, Yuasa Y, et al. Severe phenotype of neurofibromatosis type 2 in a patient with a 7.4-MB constitutional deletion on chromosome 22: possible localization of a neurofibromatosis type 2 modifier gene? Genes, chromosomes & cancer. 1999;25(2):184-90.  
36. Goutagny S, Kalamarides M. Meningiomas and neurofibromatosis. Journal of neuro-oncology. 2010;99(3):341-7.  
37. Evans DG, Huson SM, Donnai D, Neary W, Blair V, Newton V, et al. A clinical study of type 2 neurofibromatosis. The Quarterly journal of medicine. 1992;84(304):60318.  
38. Perry A, Giannini C, Raghavan R, Scheithauer BW, Banerjee R, Margraf L, et al. Aggressive phenotypic and genotypic features in pediatric and NF2-associated meningiomas: a clinicopathologic study of 53 cases. Journal of neuropathology and experimental neurology. 2001;60(10):994-1003.  
25  
39. Larson JJ, van Loveren HR, Balko MG, Tew JM, Jr. Evidence of meningioma infiltration into cranial nerves: clinical implications for cavernous sinus meningiomas. Journal of neurosurgery. 1995;83(4):596-9.  
40. Hamilton SR, Liu B, Parsons RE, Papadopoulos N, Jen J, Powell SM, et al. The molecular basis of Turcot's syndrome. The New England journal of medicine. 1995;332(13):839-47.  
41. Stark Z, Campbell LJ, Mitchell C, James PA, Heath JA, Boussioutas A, et al. Clinical problem-solving. Spot diagnosis. The New England journal of medicine. 2014;370(23):2229-36.  
42. Bruwer Z, Algar U, Vorster A, Fieggen K, Davidson A, Goldberg P, et al. Predictive genetic testing in children: constitutional mismatch repair deficiency cancer predisposing syndrome. Journal of genetic counseling. 2014;23(2):147-55.  
43. Bouffet E, Larouche V, Campbell BB, Merico D, de Borja R, Aronson M, et al. Immune Checkpoint Inhibition for Hypermutant Glioblastoma Multiforme Resulting From Germline Biallelic Mismatch Repair Deficiency. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2016;34(19):2206-11.  
44. Wrensch M, Lee M, Miike R, Newman B, Barger G, Davis R, et al. Familial and personal medical history of cancer and nervous system conditions among adults with glioma and controls. American journal of epidemiology. 1997;145(7):581-93.  
45. Malmer B, Gronberg H, Bergenheim AT, Lenner P, Henriksson R. Familial aggregation of astrocytoma in northern Sweden: an epidemiological cohort study. International journal of cancer. 1999;81(3):366-70.  
46. Blumenthal DT, Cannon-Albright LA. Familiality in brain tumors. Neurology. 2008;71(13):1015-20.  
47. Malmer B, Iselius L, Holmberg E, Collins A, Henriksson R, Gronberg H. Genetic epidemiology of glioma. British journal of cancer. 2001;84(3):429-34.  
48. Sadetzki S, Bruchim R, Oberman B, Armstrong GN, Lau CC, Claus EB, et al. Description of selected characteristics of familial glioma patients - results from the Gliogene Consortium. European journal of cancer (Oxford, England : 1990). 2013;49(6):1335-45.  
49. Bainbridge MN, Armstrong GN, Gramatges MM, Bertuch AA, Jhangiani SN, Doddapaneni H, et al. Germline mutations in shelterin complex genes are associated with familial glioma. Journal of the National Cancer Institute. 2015;107(1):384.  
50. Robles-Espinoza CD, Harland M, Ramsay AJ, Aoude LG, Quesada V, Ding Z, et al. POT1 loss-of-function variants predispose to familial melanoma. Nature genetics. 2014;46(5):478-81.  
51. Shi J, Yang XR, Ballew B, Rotunno M, Calista D, Fargnoli MC, et al. Rare missense variants in POT1 predispose to familial cutaneous malignant melanoma. Nature genetics. 2014;46(5):482-6.  
52. Shete S, Hosking FJ, Robertson LB, Dobbins SE, Sanson M, Malmer B, et al. Genome-wide association study identifies five susceptibility loci for glioma. Nature genetics. 2009;41(8):899-904.  
53. Wrensch M, Jenkins RB, Chang JS, Yeh RF, Xiao Y, Decker PA, et al. Variants in the CDKN2B and RTEL1 regions are associated with high-grade glioma susceptibility. Nature genetics. 2009;41(8):905-8.  
54. Sanson M, Hosking FJ, Shete S, Zelenika D, Dobbins SE, Ma Y, et al. Chromosome 7p11.2 (EGFR) variation influences glioma risk. Human molecular genetics. 2011;20(14):2897-904.  
26  
55. Dobbins SE, Broderick P, Melin B, Feychting M, Johansen C, Andersson U, et al. Common variation at 10p12.31 near MLLT10 influences meningioma risk. Nature genetics. 2011;43(9):825-7.  
56. Gu J, Liu Y, Kyritsis AP, Bondy ML. Molecular epidemiology of primary brain tumors. Neurotherapeutics : the journal of the American Society for Experimental NeuroTherapeutics. 2009;6(3):427-35.  
57. Jiang J, Quan XF, Zhang L, Wang YC. The XRCC3 Thr241Met polymorphism influences glioma risk - a meta-analysis. Asian Pacific journal of cancer prevention : APJCP. 2013;14(5):3169-73.  
58. Backes DM, Siddiq A, Cox DG, Calboli FC, Gaziano JM, Ma J, et al. Singlenucleotide polymorphisms of allergy-related genes and risk of adult glioma. Journal of neuro-oncology. 2013;113(2):229-38.  
59. Schwartzbaum J, Ahlbom A, Malmer B, Lonn S, Brookes AJ, Doss H, et al. Polymorphisms associated with asthma are inversely related to glioblastoma multiforme. Cancer research. 2005;65(14):6459-65.  
60. Amirian E, Liu Y, Scheurer ME, El-Zein R, Gilbert MR, Bondy ML. Genetic variants in inflammation pathway genes and asthma in glioma susceptibility. Neurooncology. 2010;12(5):444-52.  
61. Wiemels JL, Wiencke JK, Kelsey KT, Moghadassi M, Rice T, Urayama KY, et al. Allergy-related polymorphisms influence glioma status and serum IgE levels. Cancer epidemiology, biomarkers & prevention : a publication of the American Association for Cancer Research, cosponsored by the American Society of Preventive Oncology. 2007;16(6):1229-35.  
62. Michaud DS, Siddiq A, Cox DG, Backes DM, Calboli FC, Sughrue ME, et al. Mannose-binding lectin 2 gene and risk of adult glioma. PLoS One. 2013;8(4):e61117. 63. Ferraz-Filho JR, Santana-Netto PV, Rocha-Filho JA, Sgnolf A, Mauad F, Sanches RA. Application of magnetic resonance spectroscopy in the differentiation of high-grade brain neoplasm and inflammatory brain lesions. Arquivos de neuro-psiquiatria. 2009;67(2a):250-3.  
64. Hutter A, Schwetye KE, Bierhals AJ, McKinstry RC. Brain neoplasms: epidemiology, diagnosis, and prospects for cost-effective imaging. Neuroimaging clinics of North America. 2003;13(2):237-50, x-xi.  
65. Louis DN, Perry A, Reifenberger G, von Deimling A, Figarella-Branger D, Cavenee WK, et al. The 2016 World Health Organization Classification of Tumors of the Central Nervous System: a summary. Acta neuropathologica. 2016;131(6):803-20.  
66. Dellaretti M, Touzet G, Reyns N, Dubois F, Gusmao S, Pereira JL, et al. Correlation between magnetic resonance imaging findings and histological diagnosis of intrinsic brainstem lesions in adults. Neuro-oncology. 2012;14(3):381-5.  
67. Rachinger W, Grau S, Holtmannspotter M, Herms J, Tonn JC, Kreth FW. Serial stereotactic biopsy of brainstem lesions in adults improves diagnostic accuracy compared with MRI only. Journal of neurology, neurosurgery, and psychiatry. 2009;80(10):11349.  
68. Stupp R, Tonn JC, Brada M, Pentheroudakis G. High-grade malignant glioma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Annals of oncology : official journal of the European Society for Medical Oncology. 2010;21 Suppl 5:v190-3.  
69. Stupp R, Brada M, van den Bent MJ, Tonn JC, Pentheroudakis G. High-grade glioma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Annals of oncology : official journal of the European Society for Medical Oncology. 2014;25 Suppl 3:iii93-101.  
27  
70. Rossetti AO, Stupp R. Epilepsy in brain tumor patients. Current opinion in neurology. 2010;23(6):603-9.  
71. Weller M, Stupp R, Wick W. Epilepsy meets cancer: when, why, and what to do about it? The Lancet Oncology. 2012;13(9):e375-82.  
72. De Groot M, Toering S, Douw L, Vecht C, Klein M, Aronica E, et al. Efficacy and tolerability of levetiracetam monotherapy in patients with primary brain tumors and epilepsy. Epilepsia. 2009;50:101. 73. Kim YH, Kim T, Joo JD, Han JH, Kim YJ, Kim IA, et al. Survival benefit of levetiracetam in patients treated with concomitant chemoradiotherapy and adjuvant chemotherapy with temozolomide for glioblastoma multiforme. Cancer. 2015;121(17):2926-32.  
74. Lim DA, Tarapore P, Chang E, Burt M, Chakalian L, Barbaro N, et al. Safety and feasibility of switching from phenytoin to levetiracetam monotherapy for glioma-related seizure control following craniotomy: a randomized phase II pilot study. Journal of neurooncology. 2009;93(3):349-54.  
75. Merrell RT, Anderson SK, Meyer FB, Lachance DH. Seizures in patients with glioma treated with phenytoin and levetiracetam. Journal of neurosurgery. 2010;113(6):1176-81.  
76. Rosati A, Buttolo L, Stefini R, Todeschini A, Cenzato M, Padovani A. Efficacy and safety of levetiracetam in patients with glioma: a clinical prospective study. Archives of neurology. 2010;67(3):343-6.  
77. Rossetti AO, Jeckelmann S, Novy J, Roth P, Weller M, Stupp R. Levetiracetam and pregabalin for antiepileptic monotherapy in patients with primary brain tumors. A phase II randomized study. Neuro-oncology. 2014;16(4):584-8.  
78. Lacroix M, Abi-Said D, Fourney DR, Gokaslan ZL, Shi W, DeMonte F, et al. A multivariate analysis of 416 patients with glioblastoma multiforme: prognosis, extent of resection, and survival. Journal of neurosurgery. 2001;95(2):190-8. 79. Gaber M, Selim H, El-Nahas T. Prospective study evaluating the radiosensitizing effect of reduced doses of temozolomide in the treatment of Egyptian patients with glioblastoma multiforme. Cancer management and research. 2013;5:349-56. 80. Claus EB, Walsh KM, Wiencke JK, Molinaro AM, Wiemels JL, Schildkraut JM, et al. Survival and low-grade glioma: the emergence of genetic information. Neurosurgical focus. 2015;38(1):E6.  
81. van den Bent MJ, Afra D, de Witte O, Ben Hassel M, Schraub S, Hoang-Xuan K, et al. Long-term efficacy of early versus delayed radiotherapy for low-grade astrocytoma and oligodendroglioma in adults: the EORTC 22845 randomised trial. Lancet (London, England). 2005;366(9490):985-90.  
82. Karim AB, Maat B, Hatlevoll R, Menten J, Rutten EH, Thomas DG, et al. A randomized trial on dose-response in radiation therapy of low-grade cerebral glioma: European Organization for Research and Treatment of Cancer (EORTC) Study 22844. International journal of radiation oncology, biology, physics. 1996;36(3):549-56.  
83. Shaw E, Arusell R, Scheithauer B, O'Fallon J, O'Neill B, Dinapoli R, et al. Prospective randomized trial of low- versus high-dose radiation therapy in adults with supratentorial low-grade glioma: initial report of a North Central Cancer Treatment Group/Radiation Therapy Oncology Group/Eastern Cooperative Oncology Group study. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2002;20(9):2267-76.  
84. Marsh JC, Godbole R, Diaz AZ, Gielda BT, Turian JV. Sparing of the hippocampus, limbic circuit and neural stem cell compartment during partial brain  
28  
radiotherapy for glioma: a dosimetric feasibility study. Journal of medical imaging and radiation oncology. 2011;55(4):442-9.  
85. McDonald MW, Shu HK, Curran WJ, Jr., Crocker IR. Pattern of failure after limited margin radiotherapy and temozolomide for glioblastoma. International journal of radiation oncology, biology, physics. 2011;79(1):130-6.  
86. Sutera PA, Bernard ME, Gill BS, Quan K, Engh JA, Burton SA, et al. Salvage stereotactic radiosurgery for recurrent gliomas with prior radiation therapy. Future oncology. 2017;13(29):2681-90.  
87. Buckner JC, Shaw EG, Pugh SL, Chakravarti A, Gilbert MR, Barger GR, et al. Radiation plus Procarbazine, CCNU, and Vincristine in Low-Grade Glioma. The New England journal of medicine. 2016;374(14):1344-55.  
88. Prabhu RS, Won M, Shaw EG, Hu C, Brachman DG, Buckner JC, et al. Effect of the addition of chemotherapy to radiotherapy on cognitive function in patients with lowgrade glioma: secondary analysis of RTOG 98-02. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2014;32(6):535-41.  
89. Shaw EG, Wang M, Coons SW, Brachman DG, Buckner JC, Stelzer KJ, et al. Randomized trial of radiation therapy plus procarbazine, lomustine, and vincristine chemotherapy for supratentorial adult low-grade glioma: initial results of RTOG 9802. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2012;30(25):3065-70.  
90. Reijneveld JC, Taphoorn MJ, Coens C, Bromberg JE, Mason WP, Hoang-Xuan K, et al. Health-related quality of life in patients with high-risk low-grade glioma (EORTC 22033-26033): a randomised, open-label, phase 3 intergroup study. The Lancet Oncology. 2016;17(11):1533-42.  
91. Mirimanoff RO, Gorlia T, Mason W, Van den Bent MJ, Kortmann RD, Fisher B, et al. Radiotherapy and temozolomide for newly diagnosed glioblastoma: recursive partitioning analysis of the EORTC 26981/22981-NCIC CE3 phase III randomized trial. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2006;24(16):2563-9. 92. Chakravarti A, Wang M, Aldape KD, Sulman EP, Bredel M, Magliocco AM, et al. A revised RTOG recursive partitioning analysis (RPA) model for glioblastoma based upon multiplatform biomarker profiles. Journal of Clinical Oncology. 2012;30(15_suppl):2001-. 93. Yang F, Yang P, Zhang C, Wang Y, Zhang W, Hu H, et al. Stratification according to recursive partitioning analysis predicts outcome in newly diagnosed glioblastomas. Oncotarget. 2017;8(26):42974-82.  
94. Selker RG, Shapiro WR, Burger P, Blackwood MS, Arena VC, Gilder JC, et al. The Brain Tumor Cooperative Group NIH Trial 87-01: a randomized comparison of surgery, external radiotherapy, and carmustine versus surgery, interstitial radiotherapy boost, external radiation therapy, and carmustine. Neurosurgery. 2002;51(2):343-55; discussion 55-7.  
95. Khan L, Soliman H, Sahgal A, Perry J, Xu W, Tsao MN. External beam radiation dose escalation for high grade glioma. The Cochrane database of systematic reviews. 2016(8):Cd011475.  
96. Stupp R, Hegi ME, Mason WP, van den Bent MJ, Taphoorn MJ, Janzer RC, et al. Effects of radiotherapy with concomitant and adjuvant temozolomide versus radiotherapy alone on survival in glioblastoma in a randomised phase III study: 5-year analysis of the EORTC-NCIC trial. The Lancet Oncology. 2009;10(5):459-66.  
97. Lam N, Chambers CR. Temozolomide plus radiotherapy for glioblastoma in a Canadian province: efficacy versus effectiveness and the impact of O6-methylguanine-  
29  
DNA-methyltransferase promoter methylation. Journal of oncology pharmacy practice : official publication of the International Society of Oncology Pharmacy Practitioners. 2012;18(2):229-38.  
98. Athanassiou H, Synodinou M, Maragoudakis E, Paraskevaidis M, Verigos C, Misailidou D, et al. Randomized phase II study of temozolomide and radiotherapy compared with radiotherapy alone in newly diagnosed glioblastoma multiforme. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2005;23(10):2372-7.  
99. Bhandari M, Gandhi AK, Devnani B, Kumar P, Sharma DN, Julka PK. Comparative study of adjuvant temozolomide six cycles versus extended 12 cycles in newly diagnosed glioblastoma multiforme. Journal of Clinical and Diagnostic Research. 2017;11(5):XC04-XC8.  
100. Feng E, Sui C, Wang T, Sun G. Temozolomide with or without Radiotherapy in Patients with Newly Diagnosed Glioblastoma Multiforme: A Meta-Analysis. European Neurology. 2017;77(3-4):201-10.  
101. Hart MG, Garside R, Rogers G, Stein K, Grant R. Temozolomide for high grade glioma. The Cochrane database of systematic reviews. 2013(4):Cd007415. 102. Karacetin D, Okten B, Yalcin B, Incekara O. Concomitant temozolomide and radiotherapy versus radiotherapy alone for treatment of newly diagnosed glioblastoma multiforme. Journal of BUON : official journal of the Balkan Union of Oncology. 2011;16(1):133-7.  
103. Kocher M, Frommolt P, Borberg SK, Ruhl U, Steingraber M, Niewald M, et al. Randomized study of postoperative radiotherapy and simultaneous temozolomide without adjuvant chemotherapy for glioblastoma. Strahlentherapie und Onkologie : Organ der Deutschen Rontgengesellschaft  [et al]. 2008;184(11):572-9. 104. Mao Y, Yao Y, Zhang LW, Lu YC, Chen ZP, Zhang JM, et al. Does Early Postsurgical Temozolomide Plus Concomitant Radiochemotherapy Regimen Have Any Benefit in Newly-diagnosed Glioblastoma Patients? A Multi-center, Randomized, Parallel, Open-label, Phase II Clinical Trial. Chinese medical journal. 2015;128(20):2751-8. 105. Perry JR, Laperriere N, O'Callaghan CJ, Brandes AA, Menten J, Phillips C, et al. Short-Course Radiation plus Temozolomide in Elderly Patients with Glioblastoma. The New England journal of medicine. 2017;376(11):1027-37. 106. Stupp R, Mason WP, van den Bent MJ, Weller M, Fisher B, Taphoorn MJ, et al. Radiotherapy plus concomitant and adjuvant temozolomide for glioblastoma. The New England journal of medicine. 2005;352(10):987-96. 107. Szczepanek D, Marchel A, Moskał M, Krupa M, Kunert P, Trojanowski T. Efficacy of concomitant and adjuvant temozolomide in glioblastoma treatment. A multicentre randomized study. Neurologia i Neurochirurgia Polska. 2013;47(2):101-8. 108. Van Den Bent MJ, Erridge S, Vogelbaum MA, Nowak AK, Sanson M, Brandes AA, et al. Results of the interim analysis of the EORTC randomized phase III CATNON trial on concurrent and adjuvant temozolomide in anaplastic glioma without 1p/19q codeletion: An Intergroup trial. Journal of Clinical Oncology. 2016;34. 109. Blumenthal DT, Gorlia T, Gilbert MR, Kim MM, Burt Nabors L, Mason WP, et al. Is more better? the impact of extended adjuvant temozolomide in newly diagnosed glioblastoma: A secondary analysis of EORTC and NRG Oncology/RTOG. Neurooncology. 2017;19(8):1119-26.  
110. Malmstrom A, Gronberg BH, Marosi C, Stupp R, Frappaz D, Schultz H, et al. Temozolomide versus standard 6-week radiotherapy versus hypofractionated  
30  
radiotherapy in patients older than 60 years with glioblastoma: the Nordic randomised, phase 3 trial. The Lancet Oncology. 2012;13(9):916-26.  
111. Wick W, Platten M, Meisner C, Felsberg J, Tabatabai G, Simon M, et al. Temozolomide chemotherapy alone versus radiotherapy alone for malignant astrocytoma in the elderly: The NOA-08 randomised, phase 3 trial. The Lancet Oncology. 2012;13(7):707-15.  
112. Friedman HS, Prados MD, Wen PY, Mikkelsen T, Schiff D, Abrey LE, et al. Bevacizumab alone and in combination with irinotecan in recurrent glioblastoma. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2009;27(28):4733-40.  
113. Wick W, Stupp R, Gorlia T, Bendszus M, Brandes AA, Voss MJ, et al. Sequence of bevacizumab and lomustine in patients with first progression of a glioblastoma: Phase II eortc study 26101. Neuro-oncology. 2016;18:iv11.  
114. Wick W, Brandes AA, Gorlla T, Bendszus M, Sahm F, Taal W, et al. EORTC 26101 phase III trial exploring the combination of bevacizumab and lomustine in patients with first progression of a glioblastoma. Journal of Clinical Oncology. 2016;34. 115. Combs SE, Schulz-Ertner D, Moschos D, Thilmann C, Huber PE, Debus J. Fractionated stereotactic radiotherapy of optic pathway gliomas: tolerance and long-term outcome. International journal of radiation oncology, biology, physics. 2005;62(3):8149.  
116. Darlix A, Langlois C, Laigre M, Castan F, Bauchet L, Duffau H, et al. Evaluating the response to bevacizumab in high grade gliomas: The importance of clinical assessment. Neuro-oncology. 2015;17:v158.  
117. Fabbro M, Laigre M, Langlois C, Castan F, Bauchet L, Duffau H, et al. Antiangiogenic treatment (AT) in glioblastoma multiform tumors (GBM): Imaging but also clinical assessment: Correlation between mcdonald, rano and recist 1.1 criteria. Neuro-oncology. 2012;14:iii60.  
118. Gallego Perez-Larraya J, Lahutte M, Petrirena G, Reyes-Botero G, GonzalezAguilar A, Houillier C, et al. Response assessment in recurrent glioblastoma treated with irinotecan-bevacizumab: comparative analysis of the Macdonald, RECIST, RANO, and RECIST + F criteria. Neuro-oncology. 2012;14(5):667-73. 119. Hashimoto N, Chiba Y, Tsuboi A, Kinoshita M, Hirayama R, Kagawa N, et al. A direct comparison of response assessments in a phase II clinical trial of wt1 peptide vaccination; macdonald, recist and rano criteria. Neuro-oncology. 2013;15:iii111. 120. Kucharczyk MJ, Parpia S, Whitton A, Greenspoon JN. Evaluation of pseudoprogression in patients with glioblastoma. Neuro-Oncology Practice. 2017;4(2):128-34.  
121. Ministério da Saúde. Secretaria de Atenção Especializada à Saúde. Instituto Nacional de Câncer - INCA. Departamento de Atenção Especializada e Temática - DAET.Departamento de Regulação, Avaliação e Controle - DRAC. Manual de Bases Técnicas da Oncologia - SIA/SUS - Sistema de Informações Ambulatoriais. 26 ed. Brasília: MS/SAES/DRAC/CGSI, Novembro de 2019. 164p. 2019. Disponível em: <u>ftp://arpoador.datasus.gov.br/siasus/Documentos/APAC/Manual_Oncologia_26a_edica o_Novembro_2019_03_12_2019.pdf.</u>  
31

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **APÊNDICE 1** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **A) Metodologia** -->
Com a presença de seis membros do Grupo Elaborador, sendo quatro especialistas e dois metodologistas, e um representante do Comitê Gestor, uma reunião presencial para definição do escopo das Diretrizes Diagnósticas e Terapêuticas (DDT) de Tumor Cerebral no Adulto foi conduzida. Todos os componentes do Grupo Elaborador preencheram o formulário de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde como parte dos resultados.  
Inicialmente, a macroestrutura do PCDT foi estabelecida considerando a Portaria N° 375/SAS, de 10 de novembro de 2009 (122), como roteiro para elaboração dos PCDT, e as seções do documento foram definidas.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de identificar as tecnologias que seriam consideradas nas recomendações.  
Os médicos especialistas no tema das presentes DDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO ( **Figura A** ), para cada nova tecnologia ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou de acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
32  
<!-- Start of picture text -->
L P| ee OEE<br>+Intervengdo, no caso de estudos experimentais<br>+Fator de exposi¢ao, em caso de estudos<br>observacionais<br>*Teste indice, nos casos de estudos de acuracia<br>diagnostica<br>*Controle, de acordo com tratamento/niveis de<br>exposi¢ao do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br><!-- End of picture text -->  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: PICO -->
Ao final dessa dinâmica, treze questões de pesquisa foram definidas para as presentes DDT ( **Quadro A** ).  
**Quadro A -** Questões de pesquisa elencadas pelo Grupo Elaborador das Diretrizes Diagnósticas e Terapêuticas  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|Quais os fatores de risco para a ocorrência de<br>gliomas?|Introdução|
|**2**|Qual o desempenho dos testes diagnósticos<br>inclusos nos critérios da OMS?|Diagnóstico|
|**3**|Qual o papel/aplicação/utilidade da biópsia em<br>gliomas de tronco (difuso captável x não<br>captável)?|Diagnóstico|
|**4**|Qual a eficácia e segurança da temozolomida e<br>quais são os esquemas de uso (concomitante,<br>adjuvante, etc)?|Tratamento|  
33  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**5**|Qual a eficácia e segurança do Keppra®<br>(levetiracetam) no tratamento da convulsão em<br>pacientes com glioma?|Tratamento|
|**6**|Qual a eficácia e segurança da Fenitoína (i.v.) no<br>tratamento da convulsão no pré-operatório?|Tratamento|
|**7**|Qual a eficácia e segurança do bevacizumabe para<br>pacientes com glioma?|Tratamento|
|**8**|Quais os tratamentos preconizados no período<br>pós-operatório em pacientes com Glioma grau I?|Tratamento|
|**9**|Quais os tratamentos preconizados no período<br>pós-operatório em pacientes com Glioma grau II?|Tratamento|
|**10**|Qual a melhor duração de adjuvância com<br>quimioterapia para glioma grau II (6 meses x 12<br>meses)?|Tratamento|
|**11**|Qual a eficácia e segurança da temozolomida em<br>pacientes idosos grau IV com ou sem metilação<br>MGMT?|Tratamento|
|**12**|Qual a melhor duração de adjuvância com<br>quimioterapia para gliomas grau III e IV (6 meses<br>x 12 meses)?|Tratamento|
|**13**|Qual o critério de monitorização do paciente com<br>glioma (todos os graus) (RANO x Mc Donald X<br>RECIST)?|Monitoramento|  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática assistencial estabelecidas e apenas com tecnologias  
34  
já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram aquela prática. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas à reunião de consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com metaanálise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clinico-demográficas e desfechos de eficácia e segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiuse um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão  
35  
para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias em formato PDF, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados do trabalho de elaboração das DDT. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo do Anexo.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. Essa extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2) (123), os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane (124), os estudos observacionais pela ferramenta Newcastle-Ottawa (125) e os estudos de acurácia diagnóstica pelo _Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2) (126). Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas a priori como alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa ao longo do Anexo.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ ) (127), de forma qualitativa, durante a reunião de consenso das recomendações. Os metodologistas mediaram as discussões apresentando cada um dos critérios GRADE para os dois objetivos do sistema GRADE, e as conclusões do painel  
36  
de especialistas foram apresentadas ao final do parágrafo do texto correspondente à recomendação.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **B) Questões de Pesquisa** -->
**Questão de Pesquisa 1:** Quais os fatores de risco para a ocorrência de gliomas?  
**1) Estratégia de Busca**

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
((((("Glioblastoma"[Mesh] OR glioblastoma*)) OR ("Glioma"[Mesh] OR glial cell tumor*))) AND ("Risk Factors"[Mesh] OR risk factor*)) AND (("Epidemiology"[Mesh]) OR "epidemiology" [Subheading] OR epidemiology OR descriptive epidemiology OR incidence OR prevalence)  
Total: 787 referências  
Data de acesso: 04/07/2017

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE** -->
'epidemiology'/exp OR 'epidemiology' OR 'incidence'/exp OR 'incidence' OR 'prevalence'/exp OR 'prevalence' AND ('risk factor'/exp OR 'risk factor') AND [embase]/lim AND ('glioblastoma'/exp OR 'glioblastoma' AND [embase]/lim OR ('glioma'/exp OR 'glioma' OR 'glial cell tumor' AND [embase]/lim))  
Total: 722 referências  
Data de acesso: 04/07/2017

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
Foram encontradas 1509 referências através das estratégias de busca acima. Após a exclusão de 154 duplicatas, 1355 referências foram triadas por título e resumo. Dessas, 25 revisões sistemáticas foram selecionadas para a leitura completa. Assim, cinco referências foram excluídas por se tratarem de revisões sistemáticas de estudos observacionais, para as quais já havia outra publicação mais atual e/ou com maior número de estudos. Ao final, 20 referências foram incluídas (4, 6-9, 11-16, 22, 23, 128-133).  
- **3)** **<mark>Descrição dos estudos e seus resultados</mark>**  
37  
A Tabela 1 exibe as características dos estudos incluídos, bem como os principais fatores de risco para a ocorrência de gliomas.  
38  
**Tabela 1 - Características dos estudos incluídos e principais fatores de risco para a ocorrência de gliomas.**  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|**Wang et**<br>**al. 2016**<br>**(128)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>relação entre<br>eczema e<br>risco de<br>glioma|13 estudos,<br>sendo 1<br>coorte e 12<br>caso-<br>controles,<br>com um total<br>de 10897<br>casos de<br>glioma|Histórico de<br>Eczema|Eczema|Não<br>eczema|Baixo|**Histórico de eczema vs.**<br>**Não eczema:**OR = 0,69<br>(0,61; 0,78) p<0,0001|
|**Zhao et**<br>**al. 2016**<br>**(7)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar o<br>risco de<br>glioma em<br>população<br>com<br>diabetes<br>mellitus.|11 estudos (7<br>caso-<br>controles e 4<br>coortes)<br>compreenden<br>do 5.898.251<br>participantes|Presença de<br>diabetes<br>mellitus|Diabetes|Não<br>diabetes|Alto<br>(Sem registro<br>prévio, não<br>mostra a<br>estratégia de<br>sumarização dos<br>dados (pooled),<br>estratégia de<br>avaliação da<br>heterogeneidade<br>inadequada)|**Diabetes vs. sem diabetes**<br>Geral: OR = 0,79 (0,67;<br>0,93) Sig.<br>**Subgrupos:**<br>Caucasiano: OR = 0,81<br>(0,69; 0,94) Sig.<br>Caso-controle: OR = 0,68<br>(0,53; 0,87)<br>Coorte: OR = 0,97 (0,83;<br>1,13) NS<br>Homens: OR = 0,83 (0,70;<br>0,99) Sig.<br>Mulheres: OR = 0,97<br>(0,78;1,21)NS|  
39  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|**Benson et**<br>**al. 2015**<br>**(22)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>relação entre<br>o uso de<br>terapia<br>hormonal na<br>menopausa e<br>o risco de<br>glioma|6 estudos<br>com 912<br>participantes<br>com gliomas|Exposição à<br>hormoniotera<br>pia na<br>menopausa|Expostos a<br>hormônios|Não<br>expostos à<br>hormônios|Alto<br>_(_Não vasculhou<br>literatura<br>cinzenta; não<br>mostra estudos<br>excluídos, não<br>avalia a<br>qualidade dos<br>estudos<br>incluídos; não<br>avalia viés de<br>publicação e não<br>declara conflitos<br>de interesse.|**Hormonioterapia vs. sem**<br>**hormonioterapia:**RR =<br>0,96 (0,86; 1,06) NS<br>**Hormonioterapia (só**<br>**estrogênio) vs. Sem**<br>**hormonioterapia:**RR =<br>1,23 (1,06; 1,42) Sig.<br>**Hormonioterapia**<br>**(estrogênio +**<br>**progestogênio) vs. Sem**<br>**hormonioterapia:**RR =<br>0,92 (0,78; 1,08) NS|
||Revisão<br>sistemática|Avaliar a<br>relação entre<br>obesidade,<br>sobrepeso e|8 estudos (5<br>coortes e 3<br>|Baixo peso<br>(IMC <18,5<br>Kg/m2)<br>Sb|Baixo peso<br>Sobrepeso|IMC<br>>18,5 a<br>24,9<br>Kg/m2||**Baixo peso vs. Peso**<br>**normal:**RR = 1,29 (0,67;<br>2,51) NS<br>**Sobrepeso vs. peso**<br>**normal:**RR = 1,06 (0,94;|
|**Niederme**<br>**ir et al.**<br>**2015 (13)**|com meta-<br>análise de<br>estudos<br>observacion<br>ais|prática de<br>exercício<br>físico com a<br>incidência<br>ou<br>mortalidade<br>por gliomas|caso-<br>controles)<br>com um total<br>de 3057<br>casos de<br>gliomas|orepeso<br>(IMC de 25 a<br>29,9 Kg/m2)<br>Obesidade<br>(IMC ≥**30**<br>**Kg/m2)**|Obesos<br>Estratos<br>maiores de<br>prática de|IMC < 25<br>Kg/m2<br>IMC < 25<br>Kg/m2|Baixo|1,20) NS<br>**Obesidade vs. peso**<br>**normal:**RR = 1,11 (0,98;<br>1,27) NS<br>**Atividade física (maior**<br>**estrato vs. menor**<br>**estrato):**RR (coortes e<br>caso-controles)=0,86|  
40  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|||||**Atividade**<br>**física**|atividade<br>física|Menor<br>estrato de<br>prática de<br>atividade<br>física||(0,76; 0,97) sig.; Só<br>coortes: RR = 0,91 (0,77;<br>1,07) NS|
|**Sannei et**<br>**al. 2015**<br>**(14)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>entre o<br>consumo de<br>carne<br>vermelha<br>e/ou<br>processada e<br>o risco de<br>glioma|18 estudos,<br>sendo 14<br>caso-<br>controles, 3<br>coorte e 1<br>caso-controle<br>aninhado à<br>coorte,<br>totalizando<br>4441 casos<br>de glioma|Exposição à<br>carne<br>vermelha e<br>ou<br>processada|Maior<br>estrato/cons<br>umo de<br>consumo de<br>carne<br>vermelha|Menor<br>estrato/con<br>sumo de<br>consumo<br>de carne<br>vermelha|Baixo*|**Carne vermelha não**<br>**processada**<br>Maior vs. menor categoria<br>de consumo: RR = 1,30<br>(1,08; 1,58) Sig<br>**Carne processada**<br>Maior vs. menor categoria<br>de consumo: RR = 1,14<br>(0,98; 1,33) NS<br>**Subgrupos:** <br>Estudos de base<br>populacional: RR = 1,26<br>(1,05; 1,51) Sig<br>Estudos de base hospitalar:<br>RR = 0,79 (0,65; 0,97)<br>Sig.<br>Estudos prospectivos: RR<br>= 1,08 (0,84; 1,37) NS<br>Ajustepor consumo|  
41  
**Fator de Autor, Desenho do Medida sumária (IC Objetivo População risco Casos Controles Risco de Viés ano estudo 95%)** **<u>avaliado</u>** calórico: RR = 0,98 (0,85; 1,13) NS **Consumo total de carne vermelha (não processada + processada)** Maior vs. menor categoria de consumo: RR = 1,05 <u>(0,89; 1,25) NS</u> **<u>Mulheres</u> Sobre peso/obeso vs. peso normal:** RR = 1,17 (1,03; 1,32) Sig. Obesidade/so **Sobrepeso vs. peso** brepeso (IMC **normal:** RR = 1,19 (1,02; 9 estudos (6 de 25 a ≥ 30 Obesos e Revisão 1,38) Sig. Avaliar a coortes e 3 Kg/m2) com sistemática **Obeso vs. peso normal: Sergentan** relação entre casosobrepeso com metaRR = 1,13 (0,92; 1,38) NS **is et al.** obesidade/so controles) Sobrepeso Peso análise de Baixo **2015** brepeso com com um total (IMC 25 a Sobrepeso normal estudos **<u>Homens</u> (15)**** o risco de de 3683 29,9 Kg/m2) observacion **Sobre peso/obeso vs. peso** glioma casos de ais **normal:** RR = 0,96 (0,76; glioma Obesidade Obesos 1,23) NS (IMC ≥ **30 Sobrepeso vs. peso Kg/m2) normal:** RR = 1,03 (0,84; 1,28) NS **Obeso vs. peso normal:** RR =0,81 (0,42; 1,57) <u>NS</u>  
42  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|**Wei et al.**<br>**2015 (16)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>entre o<br>consumo de<br>carne<br>vermelha<br>e/ou<br>processada<br>(Bacon, hot<br>dog,<br>salsicha,<br>presunto e<br>salame) e o<br>risco de<br>glioma|14 estudos,<br>sendo 3<br>coortes e 11<br>caso-<br>controles,<br>com total de<br>3896 casos<br>de glioma|Exposição à<br>carne<br>vermelha e<br>ou<br>processada|Maior<br>estrato/cons<br>umo de<br>consumo de<br>carne<br>vermelha|Menor<br>estrato/con<br>sumo de<br>consumo<br>de carne<br>vermelha|Alto<br>(Não avaliou a<br>qualidade<br>metodológica<br>dos estudos<br>incluídos; não<br>acrescentou<br>literatura<br>cinzenta)|**Carne processada**<br>Maior consumo vs. menor<br>consumo: RR = 1,25 (1,08;<br>1,45) Sig.<br>**Subgrupos:**<br>Caso-controles: RR = 1,33<br>(1,09; 1,62) Sig.<br>Coorte: RR = 1,10 (0,88;<br>1,37) NS<br>Bacon: RR = 1,54 (0,94;<br>2,53) NS<br>Hot dogs: RR = 1,09<br>(0,77; 1,54) NS<br>Presunto: RR = 1,08 (0,78;<br>1,45) NS<br>Salsicha: RR = 0,91 (0,35;<br>2,38) NS<br>Salame: RR = 0,90 (0,65;<br>1,25) NS<br>**Carne vermelha não**<br>**processada**<br>Maior consumo vs. menor<br>consumo: RR = 0,89 (0,71;<br>1,12) NS|  
43  
|||||||||**ERCC1 - rs3212986**<br>CA vs. AA: OR = 0,966<br>(0,852; 1,095) NS<br>AA vs. CC: OR = 0,929<br>(0,801; 1,078) NS<br>Dominante (CA/AA vs.<br>CC): OR = 1,006 (0,892;|
|---|---|---|---|---|---|---|---|---|
||||||ERCC1 -|ERCC1 -||1,136) NS|
||||||rs3212986|rs3212986||Recessivo (AA vs.|
||||||ERCC2|ERCC2||CA/CC): OR = 1,349|
|**Adel**|Revisão<br>sistemática<br>|Avaliar a<br>associação<br>entre a<br>presença de|27 estudos<br>d|Presença de<br>lifi|(XPD) -<br>rs13181<br>MGMT -<br>rs12917|(XPD) -<br>rs13181<br>MGMT -<br>rs12917|Alto<br>(Não fez seleção<br>independente;|(1,083; 1,680) Sig.<br>**ERCC2 (XPD) - rs13181**<br>AC vs. AA: OR = 1,142|
|**Fahmideh**|com meta-<br>análise de|polimorfism|e caso-<br>controle com|pomorsmo<br>nos enes de|PARP1 -|PARP1 -|não avaliou a|(1,015; 1,285) Sig.|
|**et al.**<br>**2014(8)**£|<br>estudos<br>observacion<br>ais|os nos genes<br>de reparo do<br>DNA e o|<br>13584 casos<br>de glioma|g<br>reparo do<br>DNA|rs1136410<br>XRCC1 -<br>rs25487|rs1136410<br>XRCC1 -<br>rs25487|qualidade dos<br>estudos; não<br>incluiu literatura|CC vs. AA: OR = 1,239<br>(1,044; 1,471) Sig.<br>Dominate (AC/CC vs.|
|||risco de|||(em várias|(em várias|cinzenta)|AA): OR = 1,180 (1,063;|
|||glioma|||combinaçõe|combinaçõ||1,310) Sig.|
||||||s de|es de||Recessivo (CC vs.|
||||||modelos|modelos||AC/AA): OR = 1,150|
||||||genéticos|genéticos||(0,983; 1,346) NS|  
**MGMT - rs12917** CT vs. CC: OR = 0,929 (0,801; 1,078) NS TT vs. CC: OR = 1,087 (0,702; 1,684) NS Dominante <u>(CT/TT vs.</u>  
44  
CC): OR = 0,838 (0,728; 0,964) Sig. Recessivo (TT vs. CT/CC): OR = 1,113 (0,721; 1,718) **PARP1 - rs1136410** TC vs. TT: OR = 0,778 (0,664; 0,911) Sig. dominante (TC/CC vs. TT): OR = 0,779 (0,684; 0,888) Sig. **XRCC1 -rs25487** AG vs. GG: OR = 1,104 (1,011; 1,206) Sig. AA vs. GG: OR = 1,223 (1,005; 1,487) sig. Dominante (GA/AA vs GG): OR = 1,143 (1,019; 1,283) Sig. Recessivo (AA vs. AG/GG): OR = 1,148 (1,014; 1,301) Sig.  
45  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|**Li et al.**<br>**2014 (6)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>relação entre<br>o consumo<br>de frutas e<br>vegetais e o<br>risco de<br>gliomas|15 estudos<br>(5562 casos<br>de glioma)<br>avaliando a<br>ingestão de<br>vegetais e 17<br>(3994 casos<br>de glioma)<br>avaliando a<br>ingestão de<br>frutas)|Exposição à<br>frutas e<br>vegetais|Maior<br>consumo|Menor<br>consumo|Alto<br>(Não avaliou a<br>qualidade<br>metodológica<br>dos estudos<br>incluídos; não<br>acrescentou<br>literatura<br>cinzenta)|**Consumo de vegetais**<br>Consumo alto vs. baixo:<br>RR = 0,775 (0,688; 0,872)<br>Sig.<br>Consumo de frutas<br>Consumo alto vs. baixo:<br>RR = 0,828 (0,659; 1,039)<br>NS<br>subgrupos:<br>estudos de base hospitalar:<br>RR = 0,586 (0,398; 0,863)<br>Sig.<br>Asiáticos: RR = 0,573<br>(0,346; 0,947) Sig.|  
46  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|**Xin et al.**<br>**2014 (129)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>relação entre<br>os<br>polimorfism<br>os ERCC1<br>C8092A e<br>ERCC2<br>Lys751Gln e<br>o risco de<br>glioma|7 estudos de<br>caso-controle<br>sobre<br>ERCC1<br>C8092A,<br>com 2936<br>casos de<br>glioma e<br>outros sete<br>sobre<br>ERCC2<br>Lys751Gln,<br>com 2758<br>casos de<br>glioma|Presença de<br>polimorfismo<br>s ERCC1<br>C8092A e<br>ERCC2<br>Lys751Gln|ERCC1<br>C8092A<br>A<br>CA<br>AA<br>Dominante<br>A<br>Recessivo<br>AA<br>ERCC2<br>Lys751Gln<br>T<br>GT<br>TT<br>Dominante<br>T<br>Recessivo<br>TT|ERCC1<br>C8092A<br>C<br>CC<br>CC<br>CC<br>C<br>ERCC2<br>Lys751Gl<br>n<br>G<br>GG<br>GG<br>GG<br>G|Baixo|**ERCC1 C8092A**<br>A vs. C: OR = 1,06 (0,95;<br>1,19) NS<br>CA vs. CC: OR = 0,99<br>(0,89; 1,09) NS<br>AA vs. CC: OR = 1,29<br>(1,07; 1,55) Sig.<br>A dominate vs. CC: OR =<br>1,03 (0,93; 1,13) NS<br>AA recessivo vs. C: OR =<br>1,29 (1,07; 1,55) Sig.<br>**ERCC2 Lys751Gln** <br>T vs. G: OR = 0,93 (0,84;<br>1,03) NS<br>GT vs. GG: OR = 1,00<br>(0,87; 1,16) NS<br>TT vs. GG: OR = 0,88<br>(0,75; 1,03) NS<br>T dominante vs. GG: OR =<br>0,97 (0,84; 1,11) NS<br>TT recessivo vs. G: OR =<br>0,91 (0,76; 1,10) NS|  
47  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|**Zhou et**<br>**al. 2014**<br>**(9)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>entre o<br>polimorfism<br>o rs2736100<br>da<br>transcriptase<br>reversa da<br>telomerase e<br>o risco de<br>glioma|9 estudos,<br>todos caso-<br>controle,<br>com um total<br>de 9411<br>casos de<br>glioma|Presença de<br>polimorfismo<br>rs2736100|Presença|Ausência|Alto<br>(Não avaliou a<br>qualidade<br>metodológica<br>dos estudos<br>incluídos; não<br>acrescentou<br>literatura<br>cinzenta)|**Presença vs. ausência de**<br>**polimorfismo**<br>Global: OR = 1,29 (1,24;<br>1,34) p< 0,001<br>Caucasianos: OR = 1,29<br>(1,24; 1,34) p< 0,001<br>Gliobastoma: OR = 1,45<br>(1,32; 1,60) p< 0,001<br>Astrocitoma: OR = 1,41<br>(1,26; 1,58) p< 0,001<br>Oligodendroglioma: OR =<br>1,20 (1,05;1,37) p=0,008|
|**Malerba**<br>**et al. 2013**<br>**(11)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Verificar a<br>associação<br>entre o<br>consumo de<br>café e chá e<br>o risco de<br>glioma|6 estudos,<br>sendo 4 de<br>coorte e 2 de<br>caso-<br>controle,<br>totalizando<br>2075 casos<br>de glioma|Exposição a<br>café e chá|Maior<br>consumo|Consumid<br>ores<br>ocasionais<br>/não<br>consumido<br>res|Alto<br>(Não avaliou a<br>qualidade<br>metodológica<br>dos estudos<br>incluídos; não<br>acrescentou<br>literatura<br>cinzenta) e não<br>declarou<br>conflitos de<br>interesse)|**Consumidores vs.**<br>**não/eventualmente**<br>**consumidores**<br>Café: RR = 0,96 (0,81;<br>1,13) NS<br>Chá: RR = 0,86 (0,78;<br>0,94) Sig.<br>**Consumo elevado vs.**<br>**baixo**<br>Café: RR = 1,01 (0,83;<br>1,22) NS<br>Chá: RR = 0,88 (0,69;<br>1,12) NS|  
48  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|||||||||Café e chá: RR = 0,75|
|||||||||(0,54; 1,05) NS|  
**Incremento de RR para cada xícara/dia de café** : RR = 1,00 (0,96; 1,05) NS  
|**Xu et al.**<br>**2013 (130)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Verificar a<br>associação<br>entre o<br>polimorfism<br>o de gene do<br>metileno<br>tetrahidrofol<br>ato redutase<br>(MTHFR) e<br>o risco de<br>giloma.|4 estudos de<br>caso-<br>controle,<br>com um total<br>de 1401<br>casos de<br>glioma|Presença do<br>polimorfismo<br>no gene do<br>metileno<br>tetrahidrofola<br>to redutase<br>(MTHFR)|T<br>TT<br>TC<br>TT+TC<br>TT|C<br>CC<br>CC<br>CC<br>CC+TC|Alto<br>(Não avaliou a<br>qualidade<br>metodológica<br>dos estudos<br>incluídos; não<br>acrescentou<br>literatura<br>cinzenta)|T vs. C: OR = 1,01 (0,91;<br>1,13) NS<br>TT vs. CC: OR = 1,09<br>(0,84; 1,40) NS<br>TC vs. CC: OR = 0,96<br>(0,83; 1,12) NS<br>TT+TC vs. CC: OR = 0,99<br>(0,85; 1,14) NS<br>TT vs. CC+TC: OR = 1,11<br>(0,87; 1,41) NS|
|---|---|---|---|---|---|---|---|---|
|**Galeone**<br>**et al. 2012**<br>**(11)**€|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos|Avaliar a<br>associação<br>entre o<br>consumo de<br>bebidas<br>alcoólicas e|9 estudos,<br>sendo 5<br>caso-<br>controles e 4<br>coortes,<br>totalizando|Exposição à<br>bebidas<br>alcoólicas|Consumo<br>de álcool|Nunca ter<br>consumido<br>álcool|Alto<br>(Não avalia a<br>qualidade<br>metodológica<br>dos estudos<br>incluídos,não|**Exposição ao álcool vs.**<br>**Nunca ter consumido**<br>**álcool**<br>Caso-controles: RR = 0,82<br>(0,69; 0,97) Sig.<br>Coortes:1,03 (0,89;1,20)|  
49  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
||observacion<br>ais|o risco de<br>câncer<br>cerebral|2870 casos<br>de glioma||||inclui literatura<br>cinzenta)|NS<br>Ambos estudos: RR = 0,93<br>(0,81;1,07) NS|
|**Yao et al.**<br>**2012 (131)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>entre os<br>polimorfism<br>os no<br>genótipo da<br>glutationa-<br>S-<br>transferase e<br>o risco de<br>glioma|12 estudos,<br>todos de<br>caso-<br>controle,<br>com 2325<br>casos de<br>glioma|Presença do<br>polimorfismo<br>do genótipo<br>da<br>Glutationa-S-<br>Transferase|GSTM1<br>GSTT1<br>GSTP1<br>(ile105val)|Ausência<br>de<br>polimorfis<br>mo|Alto<br>(Não avalia a<br>qualidade<br>metodológica<br>dos estudos<br>incluídos, não<br>inclui literatura<br>cinzenta; não<br>declara conflitos<br>de interesse)|GSTM1: OR = 1,008<br>(0,901; 1,129) NS<br>GSTT1: OR = 1,246<br>(0,963; 1,611) NS<br>GSTP1 (ile105val): OR =<br>1,061 (0,653; 1,724) NS|
|**Zhang et**<br>**al. 2012**<br>**(132)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>dos<br>polimorfism<br>os em p53<br>Arg72Pro e<br>MDM2 com<br>o risco de<br>glioma|13 estudos<br>de caso-<br>controle,<br>com 3193<br>casos de<br>glioma|Presença de<br>polimorfismo<br>s em p53<br>Arg72Pro e<br>MDM2|Presença de<br>polimorfism<br>o Arg/Pro;<br>Pro/Pro,<br>Dominante;<br>Recessivo,<br>T/T; G/G e<br>G/T|Arg/Arg|Alto<br>(Avaliou apenas<br>o PUBMED;<br>não avaliou a<br>qualidade dos<br>estudos<br>incluídos, não<br>avalia a<br>literatura<br>cinzenta; não<br>declara conflito<br>de interesse)|**Variante p53 Arg72Pro**<br>Arg/Pro vs. Arg/Arg:  OR<br>= 1.08 (0.85-1.37) NS<br>Pro/Pro Vs. Arg/Arg: OR<br>= 1.08 (0.85-1.36) NS<br>Dominate vs. Arg/Arg: OR<br>= 1.11 (0.90-1.38) NS<br>Recessivo Vs. Arg/Arg:<br>OR = 1.17 (0.85-1.61) NS<br>**Variante MDM2 SNP309**<br>G/T vs. T/T: OR = 1.95<br>(1.00-3.81) NS|  
50  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|||||||||G/G vs. T/T: OR = 2.14<br>(0.71-6.45) NS<br>Dominante Vs. T/T: OR =|
|||||||||1.86 (0.94-3.67) NS|
|||||||||Recessivo vs. T/T: OR =<br>1.25 (0.62-2.56) NS|  
|**Repacholi**<br>**et al. 2011**<br>**(23)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>entre o uso<br>de telefone<br>celular e o<br>risco de<br>gliomas|8 estudos de<br>caso-<br>controle, não<br>relata o<br>número de<br>pacientes<br>com glioma|Exposição ao<br>telefone<br>celular|Exposição<br>curta<br>Exposição<br>longa<br>Exposição<br>(geral)|Usuários<br>não<br>regulares<br>de celular<br>+ aqueles<br>que não<br>usam|Alto<br>(Não fez seleção<br>independente;<br>não incluiu<br>literatura<br>cinzenta; não<br>avaliou a<br>qualidade dos<br>estudos<br>incluídos; não<br>declarou<br>conflitos de<br>interesse)|**Exposição curta vs. Não**<br>**uso de celular**: OR = 1,03<br>(0,86; 1,24) NS<br>**Exposição Longa vs. Não**<br>**uso de celular**: OR = 1,40<br>(0,84; 2,31) NS<br>**Exposição (geral) vs. Não**<br>**uso de celular:**OR: 1,07<br>(0,89; 1,29) NS|
|---|---|---|---|---|---|---|---|---|  
51  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|**Chen et**<br>**al. 2011**<br>**(4)ᶧ**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>entre<br>condições<br>alérgicas<br>(asma,<br>eczema e<br>rinite) e o<br>risco de<br>glioma|12 estudos,<br>sendo 10 de<br>caso-controle<br>e 2 de coorte,<br>com um total<br>de 6408<br>pacientes<br>com glioma|Alergias<br>(asma,<br>eczema e<br>rinite)|Histórico de<br>alergia|Condições<br>não<br>alérgicas|Alto<br>(Não declara<br>conflitos de<br>interesse; não<br>busca por<br>literatura<br>cinzenta; incluiu<br>na análise<br>apenas as<br>medidas<br>sumárias sem<br>ajuste o que é<br>preocupante<br>sendo os estudos<br>de natureza<br>observacional)|**Alergia (geral) Vs. Não**<br>**alergia:** <br>OR = 0,60 (0,52; 0,69) p <<br>0,001<br>**Subgrupos:**<br>Caso-controles: OR = 0,60<br>(0,52; 0,69) p < 0,001<br>Coortes: OR = 0,67 (0,30;<br>1,48) NS<br>Asma: OR = 0,70 (0,62;<br>0,79) p < 0,001<br>Eczema: OR = 0,69 (0,62;<br>0,78) p < 0,001<br>Rinite: OR = 0,78 (0,70;<br>0,87) p < 0,001|
|**Tan et al.**<br>**2010 (133)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Avaliar a<br>associação<br>entre o<br>polimorfism<br>o +61A/G e<br>risco de<br>glioma|6 estudos,<br>todos caso-<br>controles,<br>com um total<br>de 1453<br>casos de<br>glioma|Presença do<br>polimorfismo<br>+ 61 A/G|Alelo G<br>GG<br>GA<br>GG + GA<br>GG|Alelo A<br>AA<br>AA<br>AA<br>GA + AA|Alto<br>(Avaliou apenas<br>o PUBMED;<br>não avaliou a<br>qualidade dos<br>estudos<br>incluídos, não<br>avalia a<br>literatura<br>cinzenta; não|**População Geral**<br>Alelo G vs. Alelo A: OR =<br>1,07 (0,85 (1,35) NS<br>GG vs. AA: OR = 1,19<br>(0,77; 1,85) NS<br>GA vs. AA: OR = 1,01<br>(0,96; 1,06) NS<br>GG+GA vs. AA: OR =<br>1,01 (0,98; 1,04) NS<br>GG vs. GA+AA: OR =<br>1,15 (0,81;1,61) NS|  
52  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
||||||||declara conflito<br>de interesse)|**Etnia asiática**<br>Alelo G vs. Alelo A: OR =<br>0,93 (0,89; 0,97) Sig.<br>GG vs. AA: OR = 0,94<br>(0,89; 0,99) Sig.<br>GA vs. AA: OR =0,97<br>(0,92; 1,03) NS<br>GG+GA vs. AA: OR =<br>0,97 (0,95; 1,00) NS<br>GG vs. GA+AA: OR|
|||||||||=0,86 (0,78; 0,95) Sig.|
|||||||||**Etnia europeia**<br>Alelo G vs. Alelo A: OR =<br>1,14 (1,04; 1,24) Sig.|
|||||||||GG vs. AA: OR = 1,33<br>(1,12; 1,60) Sig.|
|||||||||GA vs. AA: OR = 1,04<br>(0394; 1,15) NS<br>GG+GA vs. AA: OR =<br>1,07 (1,00; 1,15) NS|
|||||||||GG vs. GA+AA: OR =<br>1,38 (1,12; 1,71) Sig.|
|||||||||**População Brasileira**<sup>**¥**</sup><br>AleloG vs.Alelo A: OR =|  
53  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|||||||||1,11 (1,03; 1,19) Sig.<br>GG vs. AA: OR = 1,33<br>(1,12; 1,60) sig.<br>GA vs. AA: OR = 1,14<br>(0,69; 1,91) NS<br>GG+GA vs. AA: OR =<br>1,14 (0,70; 1,83) NS<br>GG vs. GA+AA: OR =<br>1,02 (0,65; 1,62) NS|
|**Mandelz**<br>**weig et al.**<br>**2009 (12)**|Revião<br>sistemática<br>com meta-<br>análise de<br>estudos<br>observacion<br>ais|Verificar a<br>associação<br>entre<br>exposição ao<br>fumo e risco<br>de glioma|17 estudos,<br>sendo 6<br>coortes e 11<br>caso-<br>controles,<br>com um total<br>de 4194<br>casos de<br>glioma|Exposição ao<br>fumo|Ter fumado<br>Histórico de<br>fumo<br>(presente/pa<br>ssado)<br>Dose-<br>resposta<br>(cigarros/di<br>a;<br>maços/ano)|Nunca ter<br>fumado|Alto<br>(Sem seleção<br>independente,<br>avaliou apenas o<br>PUBMED, sem<br>literatura<br>cinzenta, não<br>avaliou a<br>qualidade dos<br>estudos<br>incluídos, não<br>declara conflitos<br>de interesse.)|**Ter fumado (qualquer**<br>**categoria) vs. Não ter**<br>**fumado**<br>Coortes: RR = 1,10 (1,01;<br>1,20) Sig.<br>Caso-controle: RR = 1,00<br>(0,88; 1,15) NS<br>Ambos: RR = 1,06 (0,97;<br>1,15) NS<br>**Fumante atual vs. Nunca**<br>**ter fumado**<br>Coorte: RR = 1,07 (0,92;<br>1,24) NS<br>Caso-controle: RR = 0,88<br>(0,73; 1,07) NS<br>**Ex-fumante vs. Nunca**<br>**ter fumado**|  
54  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Fator de**<br>**risco**<br>**avaliado**|**Casos**|**Controles**|**Risco de Viés**|**Medida sumária (IC**<br>**95%)**|
|---|---|---|---|---|---|---|---|---|
|||||||||Todos os estudos: RR =<br>1,10 (0,99; 1,22) NS<br>Coorte: RR = 1,16 (1,04;<br>1,29) Sig.<br>Caso-controle: RR = 0,90<br>(0,73; 1,11) NS|
|||||||||**Risco adicional por anos**<br>**de fumo**<br>RR = 1,01 (0,94; 1,08) NS<br>**Risco adicional por**<br>**cigarros/dia**<br>RR = 1,02 (0,96; 1,08) NS<br>**Risco adicional por**<br>**maços/ano**<br>RR = 1,00 (0,96; 1,04)|  
*O estudo considerou que, por ser rara a condição (glioma), os valores individuais de OR e HR de cada artigo incluso, seriam reportados como RR; * Estudo inclui as mesmas referências que o artigo de Niedermeir et al., 2015. Portanto os resultados para a comparação considerando ambos os sexos não relatada; € somente foram relatos os resultados para pacientes com Gliomas, haja vista que o estudo fornece resultados para outros tipos de câncer cerebral; ᶧResultado do teste de Egger (p=0,04) e assimetria do funnel plot indicam presença de viés de publicação (os autores acreditam que isso não é capaz de modificar o efeito). No entanto os autores apenas consideraram as medidas de efeito não ajustadas dos estudos individuais, o que pode ter levado a significância do viés de publicação, haja vista que a medida de efeito é considerada no cálculo; ¥Resultados para apenas um estudo (não se trata de meta-análise) conduzido no Brasil; £ apenas foram relatados os resultados para os polimorfismos mais importantes e/ou com resultado estatisticamente significante. Demais polimorfismos (ERCC2 - rs1799793, OGG1 - rs1052133, XRCC1 - rs25489, XRCC1 - rs1799782, XRCC3 - rs861539) não apresentaram associação com risco de glioma. OR: Odds ratio; RR: Risco Relativo; NS: Não significante; Sig.: significante; IMC: Índice de Massa Corporal; IC: Intervalo de Confiança; MTHFR: Metiltetraidrofolatoredutase.  
55  
56  
**Questão de Pesquisa 2:** Qual o desempenho dos testes diagnósticos inclusos nos critérios da OMS?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
(((((((("Isocitrate Dehydrogenase"[Mesh] OR isocitrate Dehydrogenase)) OR (IDH OR IDH mutation))) OR ((((1p19q codeletion) OR 1p19q deletion) OR 1p/19q codeletion) OR 1p/19q deletion))) AND ("Glioma"[Mesh] OR glioma*)) AND ("Immunohistochemistry"[Mesh] OR immunohistochemistry)) AND (((("Polymerase Chain Reaction"[Mesh]) OR "Real-Time Polymerase Chain Reaction"[Mesh] OR PCR)) OR ("Sequence Analysis, DNA"[Mesh] OR DNA Sequencing OR sequencing))  
Total: 140 referências  
Data de acesso: 21/09/2017

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE** -->
(('glioma'/exp OR 'glioma') AND [embase]/lim) AND (('sequencing'/exp OR 'sequencing' OR 'dna sequence'/exp OR 'dna sequence' OR 'sequence analysis'/exp OR 'sequence analysis' OR 'polymerase chain reaction'/exp OR 'polymerase chain reaction' OR 'real time polymerase chain reaction'/exp OR 'real time polymerase chain reaction' OR 'pcr'/exp OR 'pcr') AND [embase]/lim) AND (('immunohistochemistry'/exp OR 'immunohistochemistry') AND [embase]/lim) AND ((('isocitrate dehydrogenase'/exp OR 'isocitrate dehydrogenase' OR 'idh' OR 'idh mutation') AND [embase]/lim) OR (('1p19q codeletion' OR '1p19q deletion' OR '1p/19q codeletion' OR '1p/19q deletion') AND [embase]/lim))  
Total: 243 referências  
Data de acesso: 21/09/2017

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
Apenas foram selecionados estudos que relataram as medidas de acurácia diagnóstica ou aqueles nos quais era possível calculá-las.  
57  
Por meio das buscas acima foram recuperadas 383 referências das bases de dados Medline e Embase. Foram excluídas 74 duplicatas, restando, portanto, um total de 309 referências a serem avaliadas por títulos e resumos. Vinte e uma referências foram avaliadas por meio da leitura completa dos textos. Cinco estudos foram excluídos, sendo quatro por estarem contidos em uma revisão sistemática inclusa e um por ser uma série de casos, com pacientes consecutivos, na qual os testes foram aplicados a grupos heterogêneos, sendo que apenas uma parcela recebeu os dois testes. Dessa forma, foram incluídos 16 estudos de acurácia diagnóstica, sendo uma revisão sistemática (134) e 15 estudos transversais de acurácia diagnóstica (15, 135-148).

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
A Tabela 2 exibe as principais características dos estudos incluídos. Na Tabela 3 são mostrados os resultados dos testes de acurácia diagnóstica e, quando relatadas, as características dos participantes de cada estudo.  
58  
59

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 2 - Principais características dos estudos incluídos.** -->
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Teste índice**|**Teste padrão**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Ballester et**<br>**al. 2017**<br>**(135)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Investigar as<br>alterações genéticas<br>mais comuns<br>detectadas por NGS<br>(sequenciamento de<br>próximageração)|161 casos de tumor<br>cerebral avaliados<br>para a mutação<br>IDH1 R132H|Imuno-<br>histoquímica<br>(pR312 H)|Sequenciamento<br>DNA|Alto<br>(Não é possível saber se um<br>teste foi feito sem o<br>conhecimento dos resultados<br>do outro).|
|**Gondim et**<br>**al.**<br>**2017(136)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Avaliar a acurácia<br>diagnóstica da imuno-<br>histoquímica vs. PCR<br>em pacientes com<br>gliomas difusos ou<br>não|63 pacientes com<br>gliomas|Imuno-<br>histoquímica<br>(Dianiva-clone<br>H09)|PCR|Alto<br>(Não é possível obter as<br>informações necessárias para<br>avaliar o risco de viés do<br>estudo (resumo de<br>congresso)|
|**Carter et**<br>**al.**<br>**2016(137)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar as técnicas<br>de sequenciamento<br>(SNG) e imuno-<br>histoquímica para a<br>detecção de mutação<br>IDH R132H e,<br>também, comparar<br>SNG com FISH para a<br>detecção de codeleção<br>1p/19q|50 amostras de<br>gliomas de baixo<br>grau, advindas de<br>50 pacientes|Imuno-<br>histoquímica<br>FISH|Sequenciamento<br>de DNA|Alto<br>(Não é possível saber se um<br>teste foi feito sem o<br>conhecimento dos resultados<br>do outro).|
|**Pyo et al.**<br>**2016 (134)**|Revisão<br>sistemática<br>com meta-<br>análise de<br>estudos de|Avaliar a acurácia<br>diagnóstica da imuno-<br>histoquímica vs.<br>sequenciamento em|303 pacientes com<br>gliobastoma|Imuno-<br>histoquímica|Sequenciamento<br>de DNA|Alto<br>(Os estudos inclusos na<br>meta-análise são<br>heterogêneos, nem todos<br>analisam todos ospacientes|  
60  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Teste índice**|**Teste padrão**|**Risco de viés**|
|---|---|---|---|---|---|---|
||acurácia<br>diagnóstica|pacientes amostra de<br>glioblastoma||||e não é possível saber se os<br>resultados de um teste foram<br>obtidos sem o conhecimento<br>do outro)|
|**Li et al.**<br>**2015 (15)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar a<br>concordância de três<br>testes: HRM,<br>sequenciamento e<br>imuno-histoquímica|51 amostras de<br>glioma não<br>identificadas para a<br>mutação IDH|Sequenciamento*|Imuno-<br>histoquímica e<br>HRM|Alto<br>(Não é possível saber se um<br>teste foi feito com<br>desconhecimento dos<br>demais)|
|**Takano et**<br>**al. 2015**<br>**(138)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Avaliar a acurácia<br>diagnóstica da imuno-<br>histoquímica dupla<br>(HMab-1 e MsMab-1)<br>vs. sequenciamento<br>genético|54 pacientes com<br>gliomas grau III|Imuno-<br>histoquímica<br>dupla (HMab-1 e<br>MsMab-1)|Sequenciamento<br>de DNA|Alto<br>(Não é possível saber se um<br>teste foi feito com<br>desconhecimento dos<br>demais)|
|**Catteau et**<br>**al. 2014**<br>**(139)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar três<br>métodos diagnósticos<br>para a detecção de<br>mutações IDH1/2:<br>IDH1/2 one-step<br>quantitative PCR<br>assay; sequenciamento<br>Sanger e imuno-<br>histoquímica|171 amostras<br>clínicas de gliomas|Imuno-<br>histoquímica<br>(DIA clone H09-<br>Dianova,<br>Germany)<br>Sequenciamento<br>de DNA|IDH1/2 one-step<br>quantitative PCR<br>assay|Alto<br>(Não é possível saber se um<br>teste foi feito com<br>desconhecimento dos<br>demais; os testes não foram<br>aplicados a todas as<br>amostras)|
|**Agarwal et**<br>**al. 2013**<br>**(140)**|Estudo<br>transversal de|Comparar a<br>concordância entre os<br>testes de imuno-|50 amostras de<br>gliomas difusos|Imuno-<br>histoquímica|Sequenciamento<br>de DNA (foi|Incerto<br>(Não foi definido um padrão<br>de referência)|  
61  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Teste índice**|**Teste padrão**|**Risco de viés**|
|---|---|---|---|---|---|---|
||acurácia<br>diagnóstica|histoquímica e<br>sequenciamento<br>genético||(antígeno DIA<br>H09)|considerado o re-<br>teste)||
|**Choi et al.**<br>**2013 (141)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar a<br>concordância entre<br>imuno-histoquímica,<br>Multiplex-PCR,<br>Sequenciamento e<br>PNA Clamping|127 sub-blocos de<br>amostras avindas de<br>5 pacientes (1<br>astrocitoma difuso,<br>2<br>oligodendrogliomas<br>e 2 astrocitomas<br>mistos).|Multiplex PCR<br>Sequenciamento<br>PNA-clamping|Imuno-<br>histoquímica<br>(dianova - H09L)|Incerto<br>(Amostra pequena de<br>participantes não<br>consecutivos ou aleatórios)|
|**Egoavil et**<br>**al. 2013**<br>**(142)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Validar técnica de<br>imuno-histoquímica<br>para a detecção de<br>mutação IDH1|171 amostras de<br>gliomas|Imuno-<br>histoquímica<br>(R132H Clone<br>H09, Histonova)|Sequenciamento<br>de DNA|Alto<br>(Resumo de congresso sem<br>as informações necessárias<br>par o julgamento do risco de<br>viés; os testes não foram<br>aplicados a todos os<br>pacientes)|
|**Perrech et**<br>**al. 2013**<br>**(143)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar RT-PCR vs.<br>Sequenciamento +<br>imuno-histoquímica<br>para a detecção de<br>mutação IDH1|71 amostras de<br>tumores de baixo e<br>alto grau|RT-PCR|Imuno-<br>histoquímica e<br>sequenciamento<br>genético|Alto<br>(Não é possível obter as<br>informações necessárias para<br>avaliar o risco de viés do<br>estudo (resumo de<br>congresso)|  
62  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Teste índice**|**Teste padrão**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Lee et al.**<br>**2012 (144)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Avaliar a<br>concordância entre<br>PNA clamp PCR,<br>Sequenciamento<br>direto, Piro-<br>sequenciamento e<br>imuno-histoquímica,<br>para a detecção de<br>mutaçãoIDH1|141 amostras de<br>Oligodendrogliomas|Sequenciamento<br>direto<br>Piro-<br>sequenciamento<br>Imuno-<br>histoquímica|PNA clamp PCR|Alto<br>(Não é possível saber se um<br>teste foi feito com<br>desconhecimento dos<br>demais)|
|**Loussouarn**<br>**et al. 2012**<br>**(145)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar os<br>resultados de acurácia,<br>para a detecção da<br>mutação IDH1R132H<br>entre imuno-<br>histoquímica vs. PCR<br>e sequenciamento|91 pacientes com<br>Oligodendrogliomas<br>graus II e III|Imuno-<br>histoquímica|PCR e<br>sequenciamento<br>genético|Baixo|
|**Preusser et**<br>**al. 2011**<br>**(146)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Avaliar o desempenho<br>diagnóstico da imuno-<br>histoquímica e do<br>sequenciamento na<br>detecção de mutação<br>IDH1 R132H|95 amostras de<br>biópsias de gliomas<br>difusos|Imuno-<br>histoquímica<br>(DIA-H09 e<br>IMab-1)|PCR e<br>sequenciamento<br>genético|Baixo|
|**Boisselier**<br>**et al. 2010**<br>**(147)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar três técnicas<br>de PCR mais a imuno-<br>histoquímica (versus<br>sequenciamento) para<br>a detecção de mutação<br>IDH1 R132H|10 amostras de<br>glioma contendo,<br>sabidamente, a<br>mutação e que<br>tinham sido<br>avaliadaspor|PCR HRM<br>Cold PCR HRM<br>Double cold PCR<br>HRM|Sequenciamento<br>genético|Alto (não é possível saber se<br>um teste foi feito sem o<br>conhecimento dos resultados<br>do outro; As amostras<br>testadas continham|  
63  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Teste índice**|**Teste padrão**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||sequenciamento<br>genético|Imuno-<br>histoquímica||sabidamente a mutação sob<br>investigação)|
|**Capper et**<br>**al. 2010**<br>**(148)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica|Comparar imuno-<br>histoquímica para<br>mutação IDH1 R132H<br>com o sequenciamento<br>genético|186 amostras de<br>gliomas de vários<br>graus|Imuno-<br>histoquímica<br>(mIDH1R132H)|Sequenciamento<br>genético|Alto<br>(Nem todos os pacientes<br>passaram por<br>sequenciamento (186/345),<br>foi feito re-sequenciamento<br>para confirmar os resultados)|  
*O sequenciamento foi escolhido com índice pois foi inferior aos outros dois testes, os quais forneceram resultados idênticos; HRM: High Resolution Melt; IDH: isocitatro desidrogenase; PCR: Reação em Cadeia da Polimerase; RT-PCR: Real Time PCR.  
**Tabela 3 - Principais características dos participantes e resultados de acurácia diagnóstica para os estudos incluídos.**  
|**Autor, ano**|**Idade teste**<br>**índice, média**<br>**anos (DP)**|**Idade teste**<br>**padrão, média**<br>**anos (DP)**|**Sexo masc.**<br>**Índice, n**<br>**(%)**|**Sexo masc.**<br>**Padrão, n**<br>**(%)**|**Resultados de acurácia/comparação entre testes**|
|---|---|---|---|---|---|
|**Ballester et**||||||
|**al. 2017**<br>**(135)**|NR|NR|NR|NR|Sensibilidade p/ R132H: 100%|
|**Gondim et**|||||Sensibilidade: 100%|
|**al. 2017**|NR|NR|31 (|50%)|Especificidade: 80%|
|**(136)**|||||VPP:100%|  
64  
|**Autor, ano**|**Idade teste**<br>**índice, média**<br>**anos (DP)**|**Idade teste**<br>**padrão, média**<br>**anos (DP)**|**Sexo masc.**<br>**Índice, n**<br>**(%)**|**Sexo masc.**<br>**Padrão, n**<br>**(%)**|**Resultados de acurácia/comparação entre testes**|
|---|---|---|---|---|---|
||||||**Imuno-histoquímica vs. sequenciamento (IDH 1 R132H)**<br>|
|**Carter et**|||||Sensibilidade: 100%|
|**al. 2016**<br>**(137)**|42,2 (variaçã|o 5 a 69 anos)|38 (|76%)|Especificidade: 100%<br>**FISH vs. Sequenciamento (codeleção 1p/19q)**<br>Sensibilidade:100%|
||||||Sensibilidade sumária: 1 (0,2; 1,0)|
|**Pyo et al.**<br>**2016 (134)**|NR|NR|NR|NR|Especificidade sumária: 0,99 (0,96; 1,0)<br>AUC: 0,8508<br>ORdiagnóstico:274,86 (46,70;1617,59)|
||||||**Sequenciamento vs. HRM/Imuno-histoquímica (IDH1 132**|
|**Li et al.**<br>**2015* (15)**|NR|NR|NR|NR|**H):**<br>Sensibilidade: 91 %<br>Especificidade:100%|
|**Takano et**<br>**al. 2015**<br>**(138)**|48,7 (|14,5)|NR|NR|Sensibilidade: 100%<br>Especificidade: 100%|
|**Catteau et**<br>**al. 2014**<br>**(139)**|NR|NR|NR|NR|**Imuno-histoquímica vs. PCR one-step**<br>Sensibilidade (IC95%): 100% (91,3; 99,7)<br>Especificidade (IC95%): 100% (94,9; 100)<br>**Sequenciamento vs. PCR one-step**<br>Sensibilidade (IC95%): 100% (94,6; 100)<br>Especificidade(IC95%): 92% (83,5; 96,7)|  
65  
|**Autor, ano**|**Idade teste**<br>**índice, média**<br>**anos (DP)**|**Idade teste**<br>**padrão, média**<br>**anos (DP)**|**Sexo masc.**<br>**Índice, n**<br>**(%)**|**Sexo masc.**<br>**Padrão, n**<br>**(%)**|**Resultados de acurácia/comparação entre testes**|
|---|---|---|---|---|---|
|**Agarwal et**<br>**al. 2013***<br>**(140)**|NR|NR|NR|NR|**Mutação R132H**<br>Sensibilidade: 100%<br>Especificidade: 100%<br>**Mutação R132L**<br>Sensibilidade: 75%<br>Especificidade: 100%<br>**Mutação 132C**<br>Sensibilidade: 0,0%<br>Especificidade: 100%<br>**Nenhuma mutação IDH1**<br>Sensibilidade: 14,3%<br>Especificidade:100%|
||||||**Sequenciamento vs. imuno-histoquímica:**<br>Sensibilidade (IC95%): 78,7 (73; 82,3)<br>Especificidade (IC95%): 81,8 (68,7; 95)<br>|
|**Choi et al.**<br>**2013 (141)**|32|,6|2 (4|0%)|**Multiplex PCR vs. imuno-histoquímica:**<br>Sensibilidade (IC95%): 86,2 (80,4; 90,1)<br>Especificidade (IC95%): 75,8 (61,1; 90,4)<br>**PNA vs. Imuno-histoquímica:**<br>Sensibilidade (IC95%): 96,8 (91,9; 99,1)<br>Especificidade(IC95%): 66,7(50,6; 82,8)|
|**Egoavil et**|||||Imuno-histoquímica vs. Sequenciamento|
|**al. 2013**|NR|NR|NR|NR|Sensibilidade: 100%|
|**(142)**|||||Especificidade:100%|
|**Perrech et**<br>**al. 2013**<br>**(143)**|NR|NR|NR|NR|Sensibilidade: 96%<br>Especificidade: 95%|  
66  
|**Autor, ano**|**Idade teste**<br>**índice, média**<br>**anos (DP)**|**Idade teste**<br>**padrão, média**<br>**anos (DP)**|**Sexo masc.**<br>**Índice, n**<br>**(%)**|**Sexo masc.**<br>**Padrão, n**<br>**(%)**|**Resultados de acurácia/comparação entre testes**|
|---|---|---|---|---|---|
||||||Acima de um cut-off de 0,111, sensibilidade e especificidade<br>são iguais a 100%|
|**Lee et al.**<br>**2012* (144)**|NR|NR|NR|NR|**Sequenciamento vs. PNA**<br>Sensibilidade: 76,1%<br>Especificidade: 100%<br>**Pirosequenciamento VS. PNA**<br>Sensibilidade: 76,8%<br>Especificidade: 100%<br>**Imuno-histoquímica vs. PNA**<br>Sensibilidade: 77,5%<br>Especificidade:100%|
|**Loussouarn**<br>**et al.**<br>**2012(145)**|Grau I<br>Grau I|I: 40,6<br>II: 50|Grau II:<br>Grau III:|25 (58)<br>32 (67)|**Imuno-histoquímica vs. PCR e sequenciamento (R132H):**<br>Sensibilidade: 100%<br>Especificidade:100%|
|**Preusser et**|||||**Imuno-histoquímica vs. sequenciamento****|
|**al. 2011***<br>**(146)**|NR|NR|NR|NR|Sensibilidade: 100%<br>Especificidade:100%|
||||||**IDH1R132H**|
|**Boisselier**|||||**Sensibilidade (%):**|
|**et al. 2010**<br>**(147)**|NR|NR|NR|NR|Imuno-histoquímica: 30%<br>PCR HRM: 80%<br>Double/Cold PCR HRM: 100%|  
67  
|**Autor, ano**|**Idade teste**<br>**índice, média**<br>**anos (DP)**|**Idade teste**<br>**padrão, média**<br>**anos (DP)**|**Sexo masc.**<br>**Índice, n**<br>**(%)**|**Sexo masc.**<br>**Padrão, n**<br>**(%)**|**Resultados de acurácia/comparação entre testes**|
|---|---|---|---|---|---|
||||||**Detecção de R132H:**<br>Sensibilidade: 100 %<br>Especificidade: 100%<br>**Qualquer mutação IDH1:**<br>Sensibilidade: 94%<br>Especificidade: 100%<br>**Diagnóstico astrocitoma III:**<br>Sensibilidade: 81%<br>Especificidade: 96%|
|**Capper et**<br>**al. 2010**<br>**(148)**|NR|NR|186/|345|**Diferenciação entre GBM primário e secundário:**<br>Sensibilidade: 71%<br>Especificidade: 96%<br>**Astrocitoma II e astrocitoma pilócítico I:**<br>Sensibilidade: 83%<br>Especificidade: 100%<br>**Ependimoma:**<br>Sensibilidade: 83%<br>Especificidade: 100%<br>**Diferenciação entre ependimoma III e astrocitoma III:**<br>Sensibilidade: 81%<br>Especificidade:100%|  
GBM: gliobastoma; PCR: Reação em Cadeia da Polimerase; NR: não reportado; *Dados não fornecidos e calculados durante a coleta de dados dos artigos; **Positividade foi considerada quando se tinha imunocoloração total ou parcial das células avaliadas. VPP; valor preditivo positivo; AUC: Área sob a curva (indica acurácia do teste); OR: Odds ratio; IC95% (Intervalo de confiança 95%).  
68  
**Pergunta de Pesquisa 3:** Qual o papel/aplicação/utilidade da biópsia em gliomas de tronco (difuso captável x não captável)?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
((((("Stereotaxic Techniques"[Mesh] OR stereotactic)) AND (("Biopsy"[Mesh] OR biopsy))) AND (("Brain Stem Neoplasms"[Mesh] OR Brain Stem Neoplasm OR brainstem glioma)))) AND ("Adult"[Mesh] OR adult)  
Total: 206 referências  
Data de acesso: 01/08/2017  
**EMBASE** (('brainstem glioma'/exp OR 'brainstem glioma' OR 'brain stem tumor'/exp OR 'brain stem tumor') AND [embase]/lim) AND (('stereotactic biopsy'/exp OR 'stereotactic biopsy') AND [embase]/lim) AND (('adult'/exp OR 'adult') AND [embase]/lim)  
Total: 32 referências  
Data de acesso: 01/08/2017

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
Foram encontradas 238 referências nas bases de dados Embase e Medline, de acordo com as estratégias de busca detalhadas acima. Foram excluídas 14 duplicatas. Dessa forma, 224 referências foram avaliadas por título e resumo, sendo 13 elegíveis para a leitura completa. Após a leitura completa, cinco referências foram excluídas, sendo três por se tratar de série de casos sem descrição de gliomas de tronco difusos ou sobre a captação desse glioma por técnica de imagem; uma por avaliar apenas crianças; e outra por avaliar tumor cerebral geral e não apenas de tronco. Sendo assim, oito referências foram incluídas, três estudos transversais de acurácia diagnóstica (66, 67, 149) e cinco séries de casos (150-154).  
69  
- **3) Descrição** **<mark>dos estudos e seus resultados</mark>**  
A Tabela 4 exibe as características principais dos estudos incluídos. A Tabela 5 mostra as principais aplicações e resultados do uso da biópsia estereotácica para gliomas de tronco encefálico.  
70

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 4 - Características dos estudos incluídos para a questão de pesquisa 3 do PCDT de Gliomas.** -->
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Risco de viés**|
|---|---|---|---|---|---|
|**Marques et**<br>**al. 2015**<br>**(150)**|Série de<br>casos|Descrever características<br>clínicas, demográficas, de<br>tratamento e sobrevida de<br>pacientes com gliomas de<br>tronco|22 pacientes adultos com<br>glioma de tronco encefálico|Biópsia (estereotácica<br>ou aberta) e RMN|Alto<br>(Resumo de congresso sem o<br>detalhamento necessário;<br>série de casos)|
|**Manoj et al.**<br>**2014 (151)**|Série de<br>casos|Analisar as características das<br>lesões através de biópsia em<br>pacientes com lesão de tronco<br>encefálico|41 adultos com lesão de<br>tronco encefálico**|Biópsia estereotácica<br>guiada por TC ou<br>RMN (via frontal,<br>suboccipital eparietal)|Alto<br>(Série de casos descritiva)|
|**Dellaretti et**<br>**al. 2012 (66)**|Transversal<br>(acurácia<br>diagnóstica)|Comparar os resultados de<br>RMN com os dados<br>histopatológicos obtidos por<br>biópsia em pacientes com<br>lesões no tronco encefálico|Pacientes adultos (18 a 75<br>anos) com lesões de tronco<br>encefálico intrínsecas|Biópsia estereoscópica<br>(Tailarach frame e<br>robótica) e RMN|Alto<br>(Não fala a respeito da<br>temporalidade da aplicação<br>de RMN e Biópsia; não há<br>relato de amostra consecutiva<br>ou randomizada)|
|**Rachinger**<br>**et al. 2009**<br>**(67)**|Transversal<br>(acurácia<br>diagnóstica)|Comparar os resultados de<br>RMN com os dados<br>histopatológicos obtidos por<br>biópsia em pacientes com<br>lesões no tronco encefálico|Pacientes adultos (18 a 78<br>anos) com suspeita<br>radiológica de glioma de<br>tronco encefálico|Biópsia estereoscópica<br>(frontal extra<br>ventricular e<br>suboccipital<br>transpeduncular) e<br>RMN<br>Lesão focal (suspeita<br>de baixo grau) e Lesão<br>difusa (suspeita de alto<br>grau)|Baixo|  
71  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Risco de viés**|
|---|---|---|---|---|---|
|**Shad et al.**<br>**2004 (152)**|Série de<br>casos|Avaliar a segurança e as<br>vantagens da biópsia de tronco<br>encefálico estando o paciente<br>acordado|13 pacientes adultos<br>consecutivos, com lesões de<br>tronco encefálico|Biópsia estereotácica<br>guiada por TC|Alto<br>(Série de casos)|
|**Boviatsis et**<br>**al. 2003**<br>**(153)**|Série de<br>casos|Reportar os desfechos de<br>pacientes com lesão de tronco<br>encefálico e que passaram por<br>biópsia estereotácica guiada<br>por TC|11 pacientes adultos, com<br>lesão de tronco encefálico|Biópsia estereotácica<br>guiada por TC<br>(transfrontal e<br>transcerebelar)|Alto<br>(Série de casos)|
|**Boviatsis et**<br>**al. 2001**<br>**(154)**|Série de<br>casos|Reportar os desfechos de<br>pacientes com lesão de tronco<br>encefálico e que passaram por<br>biópsia estereotácica guiada<br>por TC|5 pacientes adultos com<br>lesão de tronco encefálico|Biópsia estereotácica<br>guiada por TC<br>(transfrontal e<br>transcerebelar)|Alto<br>(Série de casos)|
|**Rajshekhar**<br>**et al. 1995***<br>**(149)**|Transversal<br>(acurácia<br>diagnóstica)|Comparar os resultados da<br>biósia estereotácica guiada por<br>TC com os achados de imagem<br>da TC|71 pacientes consecutivos<br>(25% adultos) com massa<br>isolada intrínseca no tronco<br>encefálico|Biópsia estereotácica<br>guiada por TC<br>(transfrontal e<br>transcerebelar); e TC<br>por contraste|Alto<br>(Não fala a respeito da<br>temporalidade da aplicação<br>de TC e Biópsia)|  
*Resultados obtidos de população mista, com apenas 25% de adultos; ** Para a maioria dos desfechos apenas foi considerada a população adulta (n = 41), pois o estudo também inclui população pediátrica; RMN: imagem por ressonância magnética nuclear; TC: Tomografia computadorizada.  
72

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 5 - Principais resultados clínicos e aplicações da biópsia estereotácica de glioma de tronco.** -->
|**Autor, ano**|**N**<br>**Homem,**<br>**n (%)**|**Idade, média**<br>**(DP) ou**<br>**(faixa) Anos**|**Resultados clínicos**|**Resultados de**<br>**Segurança**|**Conclusão do estudo**|
|---|---|---|---|---|---|
||||**Resultados de imagem por RMN**<br>Difuso intrínseco (n = 17)<br>cístico/necrótico (n = 2)<br>exofítico (n = 3)<br>Captável (n = 7)|||
|**Marques et**<br>**al. 2015**<br>**(150)**|22<br>12 (54,5)|33,5 (9,4)|**Resultados de biópsia (n = 10)**<br>Difuso (n = 6)<br>cístico/necrótico (n = 2)<br>exofítico (n = 2)<br>Astrocitoma pilocítico (n = 1)<br>Astrocitoma Grau II (n = 3)<br>Astrocitoma Grau III (n = 3)<br>Gliobastoma (n = 1)<br>Oligodendroglioma grau II (n = 1)<br>Oligodendrogliomagrau III(n = 1)|NR|O estudo realça a importância do uso<br>de biópsia nesse tipo raro de tumor|  
73  
|**Autor, ano**|**N**|**Homem,**<br>**n (%)**|**Idade, média**<br>**(DP) ou**<br>**(faixa) Anos**|**Resultados clínicos**|**Resultados de**<br>**Segurança**|**Conclusão do estudo**|
|---|---|---|---|---|---|---|
|**Manoj et**<br>**al. 2014**<br>**(151)**|41|<br>29 (70,7)|Mediana de 34<br>anos|**Características radiológicas das**<br>**lesões de tronco encefálico****<br>Lesão bem definida: 12 (35,3%)<br>Bem definida com componente<br>exofítico: 3 (8,8%)<br>Difusa: 19 (55,9)<br>Difusa não captável: n = 5 (todas<br>identificadas como astrocitoma<br>anaplásico pela biópsia)<br>**Fatores contribuindo para uma**<br>**biópsia inconclusivaᶧ**<br>Localização da lesão (p = 0,545)<br>Ser bem definida ou difusa (0,14)<br>Local da biópsia (0,513)<br>Captação (0,842)<br>Adulto vs. pediátrico (0,349)<br>TC vs. RMN(0,620)|2 (2,4%)<br>Deterioração de<br>nervo craniano<br>5 tiveram perda de<br>senso.<br>2 tiveram hematoma<br>pós-biópsia|A biópsia tem um papel importante:<br>o tratamento de gliomas de tronco<br>encefálico, principalmente em<br>adultos, devido à grande variedade<br>de lesões apresentadas nesse grupo<br>de pacientes|  
74  
|**Autor, ano**|**N**<br>**Homem,**<br>**n (%)**|**Idade, média**<br>**(DP) ou**<br>**(faixa) Anos**|**Resultados clínicos**|**Resultados de**<br>**Segurança**|**Conclusão do estudo**|
|---|---|---|---|---|---|
|**Dellaretti et**<br>**al. 2012**<br>**(66)**|96<br>54 (56,2)|41 (18-75)<br>anos|**Achados Radiológicos:**<br>Lesão difusa não captável (n=32)<br>Lesão difusa captável (n=31)<br>Lesão focal não captável (n=10)<br>Lesão focal captável (23)<br>**Diagnóstico histológico preciso:**<br>92 (95,8%) pacientes (sendo<br>identificados todos os 63 casos de<br>lesão difusa)<br>**Avaliação histológica:**<br>25 (89,3%) dos pacientes com lesão<br>difusa não captável e 21 (68%) dos<br>pacientes com lesão difusa captável<br>tinham glioma difuso|**Aumento da**<br>**morbidade por**<br>**condições pré-**<br>**existentes:**9% (9<br>pacientes)<br>**Morte durante**<br>**procedimento de**<br>**biópsia:**1 paciente<br>(lesão pontínica<br>captável e piora de<br>hemiparsia)|O efeito diagnóstico da biópsia<br>estereostácica foi maior em<br>pacientes com lesões focais ou<br>captáveis (p<0,05), nas quais o<br>diagnóstico de glioma difuso não é<br>frequente.|
||||9 pacientes com lesão focal não<br>captável e 23 pacientes com lesão<br>focal captável tinhamglioma difuso|||  
75  
|**Autor, ano**|**N**|**Homem,**<br>**n (%)**|**Idade, média**<br>**(DP) ou**<br>**(faixa) Anos**|**Resultados clínicos**|**Resultados de**<br>**Segurança**|**Conclusão do estudo**|
|---|---|---|---|---|---|---|
|**Rachinger**<br>**et al. 2009**<br>**(67)**|46|25 (54)|Mediana<br>(faixa): 43 (18-<br>78)|**Avaliação histológica**<br>Astrocitoma pilocítico (2); Glioma<br>grau II (14); Glioma maligno (12);<br>metástase (7); linfoma (5);<br>cavernoma (1); abscesso<br>inflamatório (1); e doença<br>desmielinizante inflamatória (1).<br>**Acurácia da RMN em relação à**<br>**biópsia estereotácica:**<br>Baixo grau: especificidade (46,6%),<br>sensibilidade (62,5%)<br>Alto grau: especificidade (61,7%) e<br>sensibilidade(58,3%)|Duas complicações<br>(4%) relacionadas à<br>biópsia: 1)<br>Complicação de<br>cicatrização; e 2)<br>agravamento de<br>ataxia|A biópsia estereotácica é um método<br>seguro de obter um diagnóstico<br>histológico válido e indispensável<br>para a decisão do diagnóstico|
|||||**Lesões difusas**<br>3 astrocitomas<br>1 linfoma de células B|||
|**Shad et al.**<br>**2004 (152)**|13|7 (54)|47 anos|**Demais lesões**<br>2 astrocitomas anaplásicos grau III<br>1 Tumor glio-epitelial de baixo<br>grau<br>1 Encefalite (sugestivo)<br>1 sem diagnóstico<br>1 glioma de baixo grau<br>1 linfoma<br>1glioma/hematoma|3 sequelas<br>neurológicas<br>temporárias|A biópsia é segura, efetiva e<br>confiável. A técnica utilizada pode<br>ajudar a minimizar a morbidade do<br>procedimento.|  
76  
|**Autor, ano**|**N**<br>**Homem,**<br>**n (%)**|**Idade, média**<br>**(DP) ou**<br>**(faixa) Anos**|**Resultados clínicos**|**Resultados de**<br>**Segurança**|**Conclusão do estudo**|
|---|---|---|---|---|---|
||||1 adenocarcinoma metastático|||
||||**Taxa de diagnóstico com a**<br>**biópsia:**92%|||  
|**Boviatsis et**<br>**al. 2003**<br>**(153)**|11|4 (36,4|49,9|**Resultados histológicos por**<br>**Biópsia**<br>Gliose diffusa (n = 2)<br>Astrocitoma anaplásico (n = 5)<br>Astrocitoma (n = 3)<br>meduloblastoma (n = 1)<br>**% de diagnóstico correto**:  100|Paresia de nervo<br>facial (1)<br>Hematoma com<br>deterioração (1)<br>Disfunção cerebelar<br>(1)|A biópsia de tronco é um método<br>seguro de obter amostra de tecido e<br>permite que o paciente tenha o<br>direcionamento para o tratamento<br>adequado|
|---|---|---|---|---|---|---|
|**Boviatsis et**<br>**al. 2001**<br>**(154)**|5|1 (20,0)|46,2 anos|**Resultados de Biópsia e TC**<br>Astrocitoma Não captável<br>Astrocitoma captável<br>Astrocitoma anaplásico captável<br>Astrocitoma anaplásico não<br>captável<br>Meduloblastoma não captável|1 paresia de nervo<br>facial<br>1 cefaleia grave|Através da biópsia foi feita a<br>classificação histológica correta o<br>que possibilitou a escolha do melhor<br>tratamento para cada caso|  
77  
|**Autor, ano**|**N**<br>**Homem,**<br>**n (%)**|**Idade, média**<br>**(DP) ou**<br>**(faixa) Anos**|**Resultados clínicos**|**Resultados de**<br>**Segurança**|**Conclusão do estudo**|
|---|---|---|---|---|---|
|**Rajshekhar**<br>**et al. 1995***<br>**(149)**|71<br>37 (52)|Mediana<br>(faixa): 9 (2,5<br>a 67)|**Morfologia na TC**<br>Lesão não captável hipodensa:  n =<br>25<br>Lesão não captável isodensa: n = 2<br>Lesão captável em anel: n=19<br>**Localização da lesão**<br>Difusa: n = 60<br>Focal: n = 11<br>**Resultado TC vs. Biópsia**<br>Um diagnóstico positivo com a<br>biópsia foi obtido em 98,5% das<br>amostras.<br>10 resultados obtidos pela biópsia,<br>para lesões benignas, foram<br>diferentes daqueles obtidospela TC|Um paciente teve<br>paralisia ocular,<br>facial;<br>hemihipalgesia;<br>paralisia retal e<br>diferenças de<br>temperatura<br>corporal.<br>Outros 4 pacientes<br>(5,6%)<br>experimentaram<br>alguma morbidade|Os autores concluem que a Biópsia<br>guiada por TC é segura e confiável<br>É importante de ser realizada em<br>lesões captáveis e focais para a<br>detecção de lesões benignas<br>Alguns pacientes com lesões difusas<br>não captáveis podem se beneficiar da<br>biópsia. E a falta de captação,<br>juntamente com a localização difusa<br>da lesão indica glioma maligno|  
TC: Tomografia computadorizada; RMN: imagem por ressonância magnética nuclear; *Resultados obtidos de população mista, com apenas 25% de adultos; ** Lesão bem definida foi aquela com margem bem definida pelo contraste na TC ou RMN, Lesão difusa foi aquela sem limites bem definidos pelo contraste na TC ou RMN; ᶧResultados considerando 41 pacientes pediátricos; NR: Não relatado; DP: Desvio padrão.  
78  
**Questão de Pesquisa 4:** Qual a eficácia e segurança da temozolomida e quais são os esquemas de uso (concomitante, adjuvante, etc)?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **1) Estratégia de Busca** -->
No dia 07/06/2017 foram realizadas as buscas por evidência nos sítios eletrônicos das bases de dados Medline e Embase. Como forma de fazer da busca a mais precisa possível, foram utilizados filtros validados para ensaios clínicos, nas duas bases de dados citadas acima, para a redução do quantitativo de bibliografia encontrada.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
(((((("temozolomide" [Supplementary Concept]) OR "temozolomide hexyl ester" [Supplementary Concept] OR temodal OR temozolomide OR schering plough brand of temozolomide)) AND ("Glioma"[Mesh] OR glioma OR glial cell tumor)) AND ("Antineoplastic Combined Chemotherapy Protocols"[Mesh] OR Drug Combinations, Antineoplastic OR adjuvant OR concomitant))) AND ((randomized controlled trial [pt] OR controlled clinical trial [pt] OR randomized controlled trials [mh] OR random allocation [mh] OR double-blind method [mh] OR single-blind method [mh] OR clinical trial [pt] OR clinical trials[mh] OR (“clinical trial”[tw]) OR ((singl*[tw] OR doubl*[tw] OR trebl*[tw] OR tripl*[tw]) AND (mask*[tw] OR blind*[tw])) OR (placebos [mh] OR placebo* [tw] OR random* [tw] OR research design [mh:noexp] OR comparative study [pt] OR evaluation studies as topic [mh] OR follow-up studies [mh] OR prospective studies [mh] OR control* [tw] OR prospective* [tw] OR volunteer* [tw]) NOT (animals [mh] NOT humans [mh])))  
Total: 765 referências  
Data de acesso: 07/16/2017

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE** -->
'glioma'/exp OR 'glioma' OR 'glioma cell'/exp OR 'glioma cell' AND ('temozolomide'/exp OR 'temozolomide') AND ('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR (cross NEXT/1 over*):de,ab,ti OR placebo*:de,ab,ti OR (doubl* NEAR/1 blind*):de,ab,ti OR (singl* NEAR/1 blind*):de,ab,ti OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND  
79  
[embase]/lim AND ('adjuvant'/exp OR 'adjuvant' OR 'adjuvant chemotherapy'/exp OR 'adjuvant chemotherapy' OR 'concomitant' OR 'concomitant chemotherapy' AND [embase]/lim OR ('combination chemotherapy'/exp OR 'combination chemotherapy' AND [embase]/lim))  
Total: 697 referências  
Data de acesso: 07/16/2017

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
Devido ao grande volume de referências encontradas foram considerados apenas os estudos de intervenção randomizados e revisões sistemáticas de ensaios clínicos randomizados. Demais estudos observacionais, prospectivos e retrospectivos foram excluídos.  
Foram encontradas 1462 referências através das estratégias de busca acima. Após a exclusão de 151 duplicatas, 1311 referências foram triadas por título e resumo. Dessas, 98 foram selecionadas para a leitura completa. Assim, 52 referências foram excluídas por se tratarem de estudos observacionais; oito eram revisões sistemáticas metodologicamente comprometidas; quatro artigos foram excluídos pois os desfechos estavam descritos em revisão sistemática; dois artigos _post-hoc_ cuja publicação original foi inclusa; um estudo por avaliar desfecho não elegível; 3 estudos por avaliarem tecnologia não aprovada no Brasil; sete resumos de congresso sem informação relevante ou cujo artigo original foi incluso; dois estudos clínicos eram comprometidos metodologicamente; e um se tratava de artigo de opinião ( _letter_ ). Ao final, foram incluídas duas revisões sistemáticas com meta-análise (100, 101) e 25 ensaios clínicos randomizados (79, 96, 98, 99, 102-108, 155-164), sendo um deles, por busca manual (98).

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
Os desfechos primários reportados a seguir incluem sobrevida geral, sobrevida livre de progressão, desfechos relacionados à qualidade de vida dos pacientes e eventos adversos.  
As Tabelas 6-11 exibem as características dos estudos incluídos, bem como resultados de eficácia e segurança para a comparação temozolomida + radioterapia versus radioterapia; as Tabelas 12-15 exibem os mesmos desfechos para a comparação temozolomida + radioterapia + bevacizumabe versus temozolomida + radioterapia; as Tabelas 16-19 mostram os desfechos para a comparação temozolomida + radioterapia + nitrosureias  
80  
versus temozolomida + radioterapia; as tabelas 20-23 relatam os resultados para diferentes dosagens de temozolomida (metronômica versus densa); e as Tabelas 24-26 exibem os resultados para comparação temozolomida + radioterapia + INFβ versus temozolomida + radioterapia.  
81

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.1 Resultados para os estudos incluídos para a comparação Temozolomida + Radioterapia vs. Radioterapia** -->
**Tabela 6 - Características dos estudos incluídos para a comparação Temozolomida + Radioterapia vs. Radioterapia.**  
|**Autor, ano**|**Desenho de estudo**|**População e**<br>**objetivo**|**Tipo de glioma**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||**Revisões sistem**|**áticas**|||
|**Feng et al.**<br>**2017 (100)**|Revisão sistemática<br>com meta-análise|Seis ensaios clínicos<br>randomizados (450<br>pacientes recebendo<br>TMZ + radio<br>(concomitante) e<br>449 recebendo radio<br>apenas)|Gliobastoma<br>multiforme<br>recém<br>diagnosticado|TMZ + Radio (+<br>TMZ adjuvante em<br>cinco dos seis<br>estudos)|Radioterapia padrão|Baixo|
|||||1) TMZ (adjuvante<br>e concomitante) +<br>radio|||
|**Hart et al.**<br>**2013 (101)**|Revisão sistemática<br>com meta-análise|Oito ensaios clínicos<br>randomizados (em<br>11 publicações)<br>incluindo 2220<br>participantes.|Glioblastoma<br>multiforme (7<br>estudos) e<br>glioblastoma ou<br>astrocitoma<br>anaplásico (1<br>estudo)|2) TMZ<br>(concomitante<br>apenas) + radio<br>3) TMZ (em<br>pacientes idosos)<br>4) TMZ (primeiro<br>concomitante e<br>depois adjuvante<br>(metronômico ou<br>_dose-dense_)|Radio|Baixo*|
|||**En**|**saios Clínicos Ran**|**domizados**|||  
82  
|**Autor, ano**|**Desenho de estudo**|**População e**<br>**objetivo**|**Tipo de glioma**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Bhandari et**<br>**al. 2017(99)**|Ensaio clínico<br>randomizado|40 pacientes adultos<br>com Glioblastoma<br>multiforme (pós-<br>operatório)|Glioblastoma<br>multiforme|Radio + TMZ<br>concomitante +<br>TMZ adjuvante (6<br>ciclos) **[C-TMZ]**|Radio + TMZ<br>concomitante +<br>TMZ adjuvante (12<br>ciclos) **[E-TMZ]**|Alto (amostra pequena<br>e não calculada; não há<br>detalhes sobre o sigilo<br>de alocação)|
|**Perry et al.**<br>**2017(105)**|Ensaio clínico<br>randomizado|562 pacientes com<br>idade ≥ 65 anos com<br>Glioblastoma<br>multiforme recém<br>diagnosticado|Glioblastoma<br>multiforme<br>recém<br>diagnosticado|Radio (Curso de<br>curta duração)|Radio (Curso de<br>curta duração) +<br>TMZ|Baixo|
|||||1) Radio + TMZ|||
|**Van der bent**<br>**et al. 2016**<br>**(108)**|Ensaio clínico<br>randomizado|748 pacientes<br>adultos com<br>glioblastoma recém<br>diagnosticado sem<br>codeleção 1p/19q|Glioblastoma<br>recém<br>diagnosticado<br>sem codeleção<br>1p/19q|(concomitante)<br>2) Radio + TMZ<br>(Adjuvate)<br>3) Radio + TMZ<br>(comcomitante e<br>adjuvante)|Radio|Alto (Resumo de<br>congresso sem<br>informação sobre<br>randomização,<br>alocação e cegamento)|
|**Mao et al.**<br>**2015 (104)**|Ensaio clínico<br>randomizado|99 pacientes adultos<br>(18-70 anos) com<br>glioblastoma<br>primário recém<br>diagnosticado|Glioblastoma<br>primário recém<br>diagnosticado|Regime<br>radioquimioterápico<br>+ TMZ precoce<br>pós-cirurgia<br>**(Grupo TMZ)**|Regime<br>radioquimioterápico<br>+ radio padrão pós-<br>cirurgia**(Grupo**<br>**Radio)**|Baixo|
|||60 pacientes entre||TMZ + radio|TMZ + radio<br>apenas no início e||
|**Gaber et al.**<br>**2013 (79)**|Ensaio clínico<br>randomizado|<br>18-70 anos com<br>glioblastoma<br>multiforme|Glioblastoma<br>multiforme|concomitante por<br>42 semanas**(TMZ**<br>**+ Radio conc)**|<br>após o uso do TMZ<br>nas últimas<br>semanas**(TMZ +**<br>**Radio interv)**|Baixo|  
83  
*O risco de viés na condução da revisão sistemática é baixo, porém o risco de viés dos ensaios clínicos randomizados incluídos é muito alto; TMZ: temozolomida; Radio: radioterapia.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 7 - Características de base dos estudos incluídos para a comparação Temozolomida + Radioterapia vs. Radioterapia.** -->
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**comparador**|**Idade**<br>**intervenção,**<br>**média (DP)**<br>**anos**|**Idade**<br>**comparador,**<br>**média (DP)**<br>**anos**|**Homens**<br>**intervenção**<br>**(%)**|<br>**Homens**<br>**comparador,**<br>**n (%)**|**Qualidade de vida**<br>**(escalas EORTC**<br>**QLQ-C30 e QLQ-**<br>**BN20), média (DP)**<br>*****|**Tempo de**<br>**seguimento, mês**<br>**média (DP)**|
|---|---|---|---|---|---|---|---|---|
|**Feng et al.**<br>**2017 (100)**|450|449|Medianas varia<br>an|ndo de 52,5 a 59<br>os|Variando d|e 31% a 66%|NR|NA|
|**Hart et al.**<br>**2013 (101)**|22|20|Médias descrita<br>a 72|s variando de 51<br>anos|Variando d|e 47% a 66%|NR|NA|
|**Bhandari et**<br>**al. 2017 (99)**|20|20|Mediana<br>(variação): 49<br>(19-65)|Mediana<br>(variação): 44<br>(19-62)|50%|30%|NR|Mediana<br>(variação): 17,25<br>(5,31; 36,03)|
|**Perry et al.**<br>**2017 (105)**|281|281|Mediana (varia|ção): 73 (65; 90)|172 (61,2)|171 (60,9)|NR|Mediana de 17<br>meses|
|**Van der**<br>**bent et al.**<br>**2016 (108)**|748 pacien<br>random|tes foram<br>izados|NR|NR|NR|NR|NR|NR|
|**Mao et al.**<br>**2015 (104)**|52|47|48,5 (13,0)|52,1 (10,1)|32 (62)|34 (72)|NR|24 meses|
|**Gaber et al.**<br>**2013 (79)**|30|30|47,4 (9,7)|48,3 (8,4)|24 (80)|10 (33,3)|NR|Mediana 11 (6; 24)<br>meses|  
*As escalas de qualidade de vida variam de 0-100. Para os desfechos de disfunção motora e déficit de comunicação, quanto menor, pior. Para os demais, quanto maior, melhor; NR: não relatado; DP: desvio padrão.  
84  
**Tabela 8 - Resultados de sobrevida global e sobrevida livre de progressão para as revisões sistemáticas incluídas para a comparação Temozolomida + Radioterapia vs. Radioterapia.**  
|**Autor, ano**|**Sobrevidaglobal**|**SLP**|
|---|---|---|
||Em 6 meses: OR = 0,690 (IC 95%<br>0,471; 1,011) p = 0,057; I2 = 0%|Em 6 meses: OR = 0,429 (IC 95% 0,183;<br>1,009) p = 0,052; I2 = 77,15% (p=0,004)|
|**Feng et al.**<br>**2017 (100)**|Em 1 ano: OR = 0,469 (IC 95%<br>0,237; 0,928) p = 0,030; I2 =<br>66,88% (p = 0,017) - Favorece TMZ<br>+ Radio|Em 1 ano: OR = 0,245 (IC 95% 0,162;<br>0,369) p < 0,001; I2 = 17,56 % (p = 0,303) -<br>Favorece TMZ + Radio|
||TMZ (concomitante e adjuvante) +<br>Radio vs. Radio: HR = 0,56 (IC<br>95% 0,42; 0,74) [favorece TMZ +<br>radio] p<0,001<br>TMZ (concomitante apenas) vs.<br>Radio: HR = 0,89 (IC95% 0,49;<br>1,61)|TMZ (concomitante e adjuvante) + Radio vs.<br>Radio: HR = 0,54 (IC 95% 0,46; 0,64)<br>[favorece TMZ + radio] p<0,001<br>TMZ (concomitante apenas) vs. Radio: HR =<br>1,06 (IC95% 0,65; 1,75)|
|**Hart et al.**<br>**2013 (101)**|TMZ (geral) vs. Radio: HR = 0,60<br>(IC95% 0,46; 0,79) [favorece TMZ<br>+ radio] p<0,001<br>**Resultados na população Idosa:**<br>TMZ vs. Radio hipofracionada: HR<br>= 0,82 (IC 95% 0,63; 1,07)|TMZ (geral) vs. Radio: HR = 0,63 (IC95%<br>0,43; 0,92) [favorece TMZ + radio] p=0,01<br>**Resultados na população idosa:**<br>TMZ vs. Radio padrão:<br>HR = 1,15 (IC95% 0,92; 1,44)|
||TMZ vs. Radio padrão:<br>HR =0,88 (IC95% 0,57;1,36)||  
SLP: Sobrevida Livre de progressão; OR: odds ratio; TMZ: temozolomida; HR: hazard ratio; IC 95%: intervalo de confiança; NR: não relatado.  
**Tabela 9 - Resultados de eficácia para os ensaios clínicos incluídos para a comparação temozolomida + radioterapia vs. Radioterapia.**  
|**Autor,**<br>**ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre**<br>**de progressão**<br>**(meses), média**<br>**(DP)**|**Resposta**<br>**RECIST, n**<br>**(%)**|
|---|---|---|---|---|
|**Bhandari**<br>**et al.**|C-TMZ|Mediana: 15,4|Mediana: 12,8|NR|
|**2017 (99)**||Em dois anos:12,9%|Em 2 anos:16,4%||
|||Mediana: 23,8|Mediana: 16,8||
||E-TMZ|Em dois anos: 35,5%<br>(p=0,044 entre<br>grupos)|Em dois anos:<br>18,7% (p=0,069<br>entregrupos)|NR|  
85  
|**Autor,**<br>**ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre**<br>**de progressão**<br>**(meses), média**<br>**(DP)**|**Resposta**<br>**RECIST, n**<br>**(%)**|
|---|---|---|---|---|
|**Perry et**<br>**al. 2017**<br>**(105)**|Radio|Mediana (IC95%):<br>7,6 (7,0; 8,4)|Mediana (IC95%):<br>3,9 (3,5; 4,3)|NR|
||Radio +<br>TMZ|Mediana (IC95%):<br>9,3 (8,3;10,3)|Mediana (IC95%):<br>5,3 (4,6; 6,2)|NR|
||HR (IC95%)<br>entre grupos|0,67 (0,56; 0,80)<br>p<0,001 [favorece<br>Radio + TMZ]|0,50 (0,41; 0,60)<br>p<0,001 [favorece<br>Radio +TMZ]||
||**Não**||||
|**Van der**<br>**Bent et**<br>**al. 2016**<br>**(108)**|**adjuvante**<br>(somente<br>Radio ou<br>Radio<br>concomitant<br>e com TMZ)|Mediana: 41,1 meses<br>Em 5 anos: 44,1 %|Mediana: 19<br>meses|NR|
||**Adjuvante**<br>(TMZ<br>Adjuvante<br>ou<br>concomitant<br>e +<br>adjuvante|Em 5 anos: 55,9%|Mediana: 42,8<br>meses|NR|
||HR (IC95%)<br>entre grupos|0,645 (0,450; 0,926)<br>p=0,0014 [favorece<br>adjuvância]|0,586 (0,472;<br>0,727) p<0,001<br>[favorece<br>adjuvância]||
|||**Mediana (IC95%):**<br>17,6 (15,2; 23,0)|||
|**Mao et**<br>**al. 2015**<br>**(104)**|TMZ|**% em meses:**<br>6: 93,6 (81,4; 97,9)<br>12: 83,4 (68,1; 91,7)<br>18: 48,5 (31,3; 63,8)<br>24:24,0 (8,8;43,2)|Mediana (IC95%):<br>8,74 (6,4; 14,8)|NR|
||Radio|**Mediana (IC95%):**<br>13,2 (11,1; 18,8) p =<br>0,021 em relação a<br>TMZ<br>**% em meses:**<br>6: 86,9 (71,3; 94,3)<br>12: 60,4 (41,1; 75,1)<br>18: 38,6 (20,1; 56,9)<br>24: NR|Mediana (IC95%):<br>10,4 (8,2; 15,4) p<br>= 0,695 em<br>relação a TMZ|NR|  
86  
|**Autor,**<br>**ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre**<br>**de progressão**<br>**(meses), média**<br>**(DP)**|**Resposta**<br>**RECIST, n**<br>**(%)**|
|---|---|---|---|---|
||TMZ +<br>Radio conc|Mediana (IC95%):<br>12,3 (7,7; 16,9)|Mediana (IC95%):<br>8,8 (5,9; 11,7)<br>12 meses: 32%|**Remissão**<br>**completa:**4<br>(13,3)<br>**Remissão**<br>**parcial:**8<br>(26,7)<br>**Doença**<br>**estável:**16<br>(53,3)|
|**Gaber et**<br>**al 2013**||||**Progressão:**<br>2(6,7)|
|**.**<br>**(79)**|TMZ +<br>radio interv|Mediana (IC95%):<br>14,3 (14; 14,7)<br>p=0,83 entre grupos|Mediana (IC95%):<br>11,5 (8,9; 14,2) p<br>= 0,571 entre<br>grupos<br>12 meses: 30%|**Remissão**<br>**completa:**2<br>(6,7)<br>**Remissão**<br>**parcial:**8<br>(26,7)<br>**Doença**<br>**estável:**20<br>(66)<br>**Progressão:**<br>0|  
IC: intervalo de confiança; TMZ: temozolomida; C-TMZ: TMZ adjuvante (6 ciclos); E-TMZ: TMZ adjuvante (12 ciclos); Radio: radioterapia;Radio interv.: radio apenas no início e após o uso do TMZ nas últimas semanas; TMZ + Radio conc: radio concomitante por 42 semanas; HR: Hazard ratio; DP; Desvio padrão; IC 95%: intervalo de confiança; NR: não relatado.  
87

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 10 - Eventos adversos para as revisões sistemáticas (e estudos inclusos em revisões sistemáticas) incluídas para a comparação entre Temozolomida + Radioterapia vs. Radioterapia.** -->
|**Autor,**<br>**ano**|**Szcz**<br>**k e**<br>**2013***|**epane**<br>**t al.**<br>**(107)**|**Karace**<br>**tin et**<br>**al.**<br>**2011***<sup>**¥**</sup><br>**(102)**|**Stupp**<br>**2005/**<br>**(96,**|**et al,**<br>**2009***<br>**106)**|**Koch**<br>**al, 2**<br>**(10**|**er et**<br>**008***<br>**3)**|**Atha**<br>**et al**<br>**(**|**nassiou**<br>**. 2005***<br>**98)**|**Hart**<br>**2013**|**et al.**<br>**(101)**|**Hart**<br>**2013****|**et al.**<br>**(101)**|**Ha**<br>**201**|**rt et al.**<br>**3**<sup>**φ**</sup>**(101)**|**Hart et al.**<br>**2013ᶧ (101)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento**<br>**adverso**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ +**<br>**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ**|**Radi**<br>**o**|**TM**<br>**Z**<br>**(****_dos_**<br>**_e-_**<br>**_dens_**<br>**_e_) **|**TMZ**<br>**(metron**<br>**ómica)**|**TM**<br>**Z**<br>**nitrosur**<br>**éia**|
|Anemia, n<br>(%)|NR|NR|NR|4 (1)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR<br>NR|
|||||Grau<br>2:<br>108|Grau<br>2:<br>65||||||||||||
|Fadiga, n<br>(%)|NR|NR|NR|(38)<br>Grau<br>3 e<br>4:<br>38<br>(13)|(23)<br>Grau<br>3 e<br>4:<br>20<br>(7)|NR|NR|NR|NR|OR =<br>(1,15;<br>[favo<br>rad|1,98<br>3,41)<br>rece<br>io]|OR =<br>(IC95%<br>2,2|1,22<br>0,67;<br>0)|OR<br>(IC9<br>1|= 2,59<br>5% 0,34;<br>9,40)|OR = 1,50<br>(IC95% 0,26;<br>8,82)|  
88  
|**Autor,**<br>**ano**|**Szcze**<br>**k et**<br>**2013***|**pane**<br>**al.**<br>**(107)**|**Karace**<br>**tin et**<br>**al.**<br>**2011***<sup>**¥**</sup><br>**(102)**|**Stupp**<br>**2005/**<br>**(96,**|**et al,**<br>**2009***<br>**106)**|**Koch**<br>**al, 2**<br>**(10**|**er et**<br>**008***<br>**3)**|**Atha**<br>**et al**<br>**(**|**nassiou**<br>**. 2005***<br>**98)**|**Hart**<br>**2013**|**et al.**<br>**(101)**|**Hart et al.**<br>**2013** (101)**|**Ha**<br>**201**|**rt et al.**<br>**3**<sup>**φ**</sup>**(101)**|**Ha**<br>**20**|**rt et al.**<br>**13ᶧ (101)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento**<br>**adverso**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ +**<br>**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ**<br>**Radi**<br>**o**|**TM**<br>**Z**<br>**(****_dos_**<br>**_e-_**<br>**_dens_**<br>**_e_) **|**TMZ**<br>**(metron**<br>**ómica)**|**TM**<br>**Z**|**nitrosur**<br>**éia**|
|Rash/even<br>tos<br>cutâneos,<br>n (%)|NR|NR|NR|Grau<br>2:<br>35<br>(12)<br>Grau<br>3 e<br>4: 9<br>(3)|Grau<br>2:<br>17<br>(6)<br>Grau<br>3 e<br>4: 3<br>(1)|NR|NR|NR|NR|NR|NR|OR = 0,75<br>(IC95% 0,37;<br>1,50)|NR|NR|NR|NR|
|Infecção,<br>n (%)|NR|NR|NR|Grau<br>2: 7<br>(2)<br>Grau<br>3 e<br>4:<br>20<br>(7)|Grau<br>2: 5<br>(2)<br>Grau<br>3 e<br>4: 8<br>(3)|NR|NR|NR|NR|OR =<br>(IC9<br>1,15;<br>[favo<br>rad|2,45<br>5%<br>5,23)<br>rece<br>io]|OR = 1,64<br>(IC95% 1,14;<br>2,34)<br>[favorece<br>radio]|NR|NR|NR|NR|  
89  
|**Autor,**<br>**ano**<br>**Evento**<br>**adverso**|**Szcze**<br>**k et**<br>**2013***<br>**TM**<br>**Z +**<br>**Rad**<br>**io**|**pane**<br>**al.**<br>**(107)**<br>**Rad**<br>**io**|**Karace**<br>**tin et**<br>**al.**<br>**2011***<sup>**¥**</sup><br>**(102)**<br>**TMZ +**<br>**Radio**|**Stupp**<br>**2005/**<br>**(96,**<br>**TM**<br>**Z +**<br>**Rad**<br>**io**|**et al,**<br>**2009***<br>**106)**<br>**Rad**<br>**io**|**Koch**<br>**al, 2**<br>**(10**<br>**TM**<br>**Z +**<br>**Rad**<br>**io**|**er et**<br>**008***<br>**3)**<br>**Rad**<br>**io**|**Atha**<br>**et al.**<br>**(**<br>**TM**<br>**Z +**<br>**Rad**<br>**io**|**nassiou**<br>**2005***<br>**98)**<br>**Radio**|**Hart**<br>**2013**<br>**TM**<br>**Z +**<br>**Rad**<br>**io**|**et al.**<br>**(101)**<br>**Rad**<br>**io**|**Hart**<br>**2013****<br>**TMZ**|**et al.**<br>**(101)**<br>**Radi**<br>**o**|**Ha**<br>**201**<br>**TM**<br>**Z**<br>**(****_dos_**<br>**_e-_**<br>**_dens_**<br>**_e_) **|**rt et al.**<br>**3**<sup>**φ**</sup>**(101)**<br>**TMZ**<br>**(metron**<br>**ómica)**|**Ha**<br>**20**<br>**TM**<br>**Z**|**rt et al.**<br>**13ᶧ (101)**<br>**nitrosur**<br>**éia**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Toxicidad||||||||||||||||||
|e grave, n<br>(%)|NR|NR|NR|n=3|n=1|NR|NR|NR|NR|NR||NR||NR|NR|NR|NR|
|Eventos<br>tromboem<br>bólicos, n<br>(%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|OR =<br>(IC9<br>0,35;|0,74<br>5%<br>1,58)|OR =<br>(IC95%<br>3,5<br>[favo<br>rad|2,12<br>1,25;<br>8)<br>rece<br>io]|NR|NR|NR|NR|
|Trombocit<br>openia,<br>n(%)|Grau<br>s 3 e<br>4: 1<br>(3)|Grau<br>s 3 e<br>4: 0|Graus 3<br>e 4:<br>15%|Grau<br>s 3 e<br>4:<br>33<br>(12)|NR|NR|NR|Grau<br>s 3 e<br>4: 3<br>(5,2)|NR|NR|NR|OR =<br>(IC95%<br>317,|19,06<br>1,14;<br>61)|OR<br>(IC9<br>4|= 0,45<br>5% 0,04;<br>,52)|NR|NR|
|Complicaç<br>ões<br>hematológ<br>icas, n (%)|1 (3)|0|NR|NR|NR|NR|NR|NR|NR|OR =<br>(IC9<br>4,69; 1<br>[favo<br>rad|8,09<br>5%<br>3,97)<br>rece<br>io]|NR|NR|NR|NR|O<br>(IC9|R = 1,01<br>5% 0,61;<br>1,65)|  
90  
|**Autor,**<br>**ano**|**Szcze**<br>**k et**<br>**2013***|**pane**<br>**al.**<br>**(107)**|**Karace**<br>**tin et**<br>**al.**<br>**2011***<sup>**¥**</sup><br>**(102)**|**Stupp**<br>**2005/**<br>**(96,**|**et al,**<br>**2009***<br>**106)**|**Koch**<br>**al, 2**<br>**(10**|**er et**<br>**008***<br>**3)**|**Athan**<br>**et al.**<br>**(9**|**assiou**<br>**2005***<br>**8)**|**Hart**<br>**2013**|**et al.**<br>**(101)**|**Hart et al.**<br>**2013** (101)**|**Har**<br>**201**|**t et al.**<br>**3**<sup>**φ**</sup>**(101)**|**Ha**<br>**201**|**rt et al.**<br>**3ᶧ (101)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento**<br>**adverso**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ +**<br>**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ**<br>**Radi**<br>**o**|**TM**<br>**Z**<br>**(****_dos_**<br>**_e-_**<br>**_dens_**<br>**_e_) **|**TMZ**<br>**(metron**<br>**ómica)**|**TM**<br>**Z**|**nitrosur**<br>**éia**|
|Convulsão<br>, n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|OR = 1,03<br>(IC95% 0,51;<br>2,05)|NR|NR|NR|NR|
|Náusea, n<br>(%)|8<br>(29)|10<br>(33)|NR|Grau<br>2:<br>79<br>(28)<br>Grau<br>3 e<br>4: 6<br>(2)|Grau<br>2: 9<br>(3)<br>Grau<br>3 e<br>4: 3<br>(1)|Grau<br>2:<br>28%<br>Grau<br>3 e<br>4:<br>4%|Grau<br>2: 0<br>Grau<br>3 e<br>4:<br>3%|NR|NR|NR|NR|OR = 4,03<br>(IC95% 1,74;<br>9,32)<br>[favorece<br>radio]|NR|NR|NR|NR|
|||||||Grau<br>2:|Grau<br>2:|||||OR = 41,21<br>(IC95%|OR|= 5,09|||
|Linfopeni<br>a, n (%)|NR|NR|NR|NR|NR|35%<br>Grau<br>3e|15%<br>Grau<br>3e|NR|NR|NR|NR|16,22;<br>104,73)<br>[favorece<br>radio]|(IC95<br>12,18)<br>metro|% 2,12;<br>[favorece<br>nomico]|NR|NR|  
91  
|**Autor,**<br>**ano**|**Szcze**<br>**k et**<br>**2013***|**pane**<br>**al.**<br>**(107)**|**Karace**<br>**tin et**<br>**al.**<br>**2011***<sup>**¥**</sup><br>**(102)**|**Stupp**<br>**2005/2**<br>**(96,**|**et al,**<br>**009***<br>**106)**|**Koch**<br>**al, 20**<br>**(10**|**er et**<br>**08***<br>**3)**|**Atha**<br>**et al.**<br>**(**|**nassiou**<br>**2005***<br>**98)**|**Hart**<br>**2013**|**et al.**<br>**(101)**|**Hart**<br>**2013****|**et al.**<br>**(101)**|**Har**<br>**201**|**t et al.**<br>**3**<sup>**φ**</sup>**(101)**|**Hart et al.**<br>**2013ᶧ (101)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||||**TM**|||
|**Evento**<br>**adverso**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ +**<br>**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ**|**Radi**<br>**o**|**Z**<br>**(****_dos_**<br>**_e-_**<br>**_dens_**<br>**_e_) **|**TMZ**<br>**(metron**<br>**ómica)**|**TM**<br>**Z**<br>**nitrosur**<br>**éia**|  
4: 4: 33% 6%  
|Neutropen<br>ia, n (%)|NR|NR|NR|Grau<br>s 3 e<br>4:<br>21<br>(7)|NR|NR|NR|NR|NR|NR|NR|OR = 52,21<br>(IC95%<br>14,62;<br>186,51)<br>[favorece<br>radio]|OR = 1,38<br>(IC95% 0,22;<br>8,50)|NR|NR|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Pancitope<br>nia, n (%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|OR = 5,11<br>(IC95% 0,24;<br>108,1)|NR<br>NR|NR|NR|
|Leucopeni<br>a, n (%)|NR|NR|Graus 3<br>e 4:<br>15%|Grau<br>s 3 e<br>4:<br>20<br>(7)|NR|NR|NR|Grau<br>s 3 e<br>4: 2<br>(3,5)|NR|NR|NR|NR<br>NR|OR = 2,59<br>(IC95% 0,34;<br>19,40)|NR|NR|  
92  
|**Autor,**<br>**ano**|**Szcze**<br>**k et**<br>**2013***|**pane**<br>**al.**<br>**(107)**|**Karace**<br>**tin et**<br>**al.**<br>**2011***<sup>**¥**</sup><br>**(102)**|**Stupp**<br>**2005/**<br>**(96,**|**et al,**<br>**2009***<br>**106)**|**Koch**<br>**al, 2**<br>**(10**|**er et**<br>**008***<br>**3)**|**Athan**<br>**et al.**<br>**(9**|**assiou**<br>**2005***<br>**8)**|**Hart**<br>**2013 (**|**et al.**<br>**101)**|**Hart et al.**<br>**2013** (101)**|**Ha**<br>**201**<br>**TM**|**rt et al.**<br>**3**<sup>**φ**</sup>**(101)**|**Hart et al.**<br>**2013ᶧ (101)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento**<br>**adverso**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ +**<br>**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Radio**|**TM**<br>**Z +**<br>**Rad**<br>**io**|**Rad**<br>**io**|**TMZ**<br>**Radi**<br>**o**|**Z**<br>**(****_dos_**<br>**_e-_**<br>**_dens_**<br>**_e_) **|**TMZ**<br>**(metron**<br>**ómica)**|**TM**<br>**Z**<br>**nitrosur**<br>**éia**|
|Qualquer<br>evento||||||||||OR =<br>(IC 9|2,76<br>5%|OR = 3,18<br>(IC95% 1,81;|OR<br>(IC9|= 2,12<br>% 115|OR = 1,19|
|adverso/to<br>xicidade,<br>n(%)|NR|NR|NR|NR|NR|NR|NR|NR|NR|2,02;<br>[favo<br>rad|3,77)<br>rece<br>io]|5,58)<br>[favorece<br>Radio]|<br>3,91)<br>metro|,;<br>[favorece<br>nomico]|(IC95% 0,81;<br>1,75)|  
TMZ: temozolomida; Radio: radioterapia; OR: Odds ratio; NR: não relatado; IC: Intervalo de confiança; *Estudos contidos na revisão sistemática de Feng et al, 2017; ¥ Estudo não relata desfechos de segurança para o grupo que usou apenas radioterapia; **Resultados para população idosa; φResultados para diferentes regimes de TMZ; ᶧResultados para pacientes com doença recorrente tratados com TMZ vs. Nitrosureia.  
**Tabela 11 - Eventos adversos para os ensaios clínicos randomizados incluídos para a comparação entre Temozolomida + Radioterapia vs. Radioterapia.**  
|**Autor, ano**|**Bhandari et**|**al. 2017(99)**|**Perry et al**|**. 2017 (105)**|**Mao et**<br>**(1**|**al. 2015**<br>**04)**|**Valor**<br>**p**|**Gaber et al**|**. 2013 (79)**|
|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|**C-TMZ**|**E-TMZ**|**Radio**|**Radio +**<br>**TMZ**|**TMZ**|**Radio**||**TMZ +**<br>**radio conc**|**TMZ +**<br>**radio**<br>**interv**|
|Mal-estar,n(%)|NR|NR|NR|NR|NR|NR|NR|14(46,7)|14(46,7)|  
93  
|**Autor, ano**|**Bhandari et**|**al. 2017(99)**|**Perry et al**|**. 2017 (105)**|**Mao et**<br>**(1**|**al. 2015**<br>**04)**|**Valor**<br>**p**|**Gaber et al**|**. 2013 (79)**|
|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|**C-TMZ**|**E-TMZ**|**Radio**|**Radio +**<br>**TMZ**|**TMZ**|**Radio**||**TMZ +**<br>**radio conc**|**TMZ +**<br>**radio**<br>**interv**|
|Alopecia,n(%)|NR|NR|NR|NR|NR|NR|NR|8 (26,7)|4(13,3)|
|Déficit||||||||||
|neurológico, n<br>(%)|NR|NR|NR|NR|NR|NR|NR|2 (6,7)|0|
|Anemia, n(%)|NR|NR|Graus 3 e<br>4: 0|Graus 3 e<br>4: 3 (1,1)|NR|NR|NR|NR|NR|
|Anorexia, n(%)|2(10)|2(10)|NR|NR|NR|NR|NR|NR|NR|
|Insônia,n(%)|1(5)|2(10)|NR|NR|NR|NR|NR|NR|NR|
|Cefaléia,n(%)|3(15)|2(10)|NR|NR|2(3,8)|10(23,8)|0,004|2(6,7)|0|
|Febre,n(%)|NR|NR|NR|NR|4(7,7)|5 (11,9)|0,507|NR|NR|
|Fadiga,n(%)|10 (50)|9 (45)|NR|NR|NR|NR|NR|NR|NR|
|Trombocitopenia,<br>n(%)|||Graus 3 e<br>4: 1 (0,4)|Graus 3 e<br>4: 30<br>(11,1)|12 (23)|14 (35)||||
|Complicações||||||||||
|hematológicas, n<br>(%)|5%|15%|NR|NR|NR|NR|NR|NR|NR|
|Convulsão,n(%)|NR|NR|NR|NR|NR|NR|NR|4(13,3)|0|
|Náusea,n(%)|4(20)|3(15)|NR|NR|8(15,4)|14(33,3)|0,041|2(6,7)|4(13,3)|
|Vômito,n(%)|2(10)|3 (15)|NR|NR|4(7,7)|12(28,6)|0,012|NR|NR|
||||Graus 3 e|Graus 3 e||||||
|Linfopenia, n (%)|NR|NR|4: 26<br>(10,3)|4: 73<br>(27,3)|NR|NR|NR|NR|NR|  
94  
|**Autor, ano**|**Bhandari et**|**al. 2017(99)**|**Perry et al.**|**2017 (105)**|**Mao et**<br>**(1**|**al. 2015**<br>**04)**|**Valor**<br>**p**|**Gaber et al**|**. 2013 (79)**|
|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|**C-TMZ**|**E-TMZ**|**Radio**|**Radio +**<br>**TMZ**|**TMZ**|**Radio**||**TMZ +**<br>**radio conc**|**TMZ +**<br>**radio**<br>**interv**|
|Neutropenia, n<br>(%)|NR|NR|Graus 3 e<br>4:2(0,8)|Graus 3 e<br>4:22(8,3)|19 (36)|6 (14)|NR|NR|NR|
|Leucopenia, n<br>(%)|NR|NR|Graus 3 e<br>4:1(0,4)|Graus 3 e<br>4:19 (7,0)|32 (62)|19 (45)|NR|NR|NR|
|Qualquer evento<br>adverso/toxicidad<br>e,n(%)|NR|NR|NR|NR|29<br>(55,8)|31 (73,8)|NR|26 (86,7)|16 (53,3)|  
TMZ: temozolomida; Radio: radioterapia; C-TMZ: TMZ adjuvante (6 ciclos); E-TMZ: TMZ adjuvante (12 ciclos); Radio: radioterapia; Radio interv.: radio apenas no início e após o uso do TMZ nas últimas semanas; TMZ + Radio conc: radio concomitante por 42 semanas; NR: não relatado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.2 Resultados para os estudos incluídos para a comparação Temozolomida + Radioterapia vs. Temozolomida + Radioterapia + Bevacizumabe** -->
**Tabela 12 - Características dos estudos incluídos para a comparação temozolomida + radioterapia vs. temozolomida + radioterapia + bevacizumabe.**  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e**<br>**objetivo**|**Tipo de glioma**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Balana et al.**<br>**2016 (156)**|Ensaio clínico<br>randomizado|93 pacientes<br>adultos com<br>glioblastoma<br>(não resectado)|Glioblastoma não<br>resectado|TMZ<br>(neoadjuvante,<br>concomitante<br>com Radio e<br>adjuvante)|TMZ +<br>Bevacizumabe<br>(TMZ+BEV)<br>(neoadjuvante e<br>concomitante<br>com radio)|Alto<br>(Desfecho incompleto, viés de<br>detecção - nem todos os<br>desfechos tiveram a confirmação<br>por avaliador cegado)|  
95  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e**<br>**objetivo**|**Tipo de glioma**|**Intervenção**<br>|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Chauffert et al.**<br>**2014 (157)**|Ensaio clínico<br>randomizado|120 pacientes<br>adultos (18-70<br>anos) com<br>glioblastoma<br>supratentorial_de_<br>_novo_|Glioblastoma<br>supratentorial_de_<br>_novo_|1) Neo-adjuvante<br>BEV + IRI;<br>2) Radio + BEV<br>+ IRI<br>3) Adjuvante<br>BEV + IRI<br>(GRUPOBEV)|1) Radio + TMZ<br>2) Adjuvante<br>TMZ (GRUPO<br>TMZ)|Alto<br>(Estudo fase II sem detalhamento<br>da metodologia de randomização<br>e cegamento dos avaliadores de<br>dado).|
|**Chinot et al.**<br>**2014/Taphoorn**<br>**et al. 2015**<br>**(158, 159)**|Ensaio clínico<br>randomizado|921 pacientes<br>adultos com<br>glioblastoma<br>supratentorial|Glioblastoma<br>supratentorial|1) Radio + TMZ<br>+ BEV (fase<br>comcomitante<br>2) TMZ + BEV<br>(manutenção)<br>3) BEV<br>(monoterapia)<br>(GRUPO BEV)|1) Radio + TMZ<br>+ placebo (fase<br>comcomitante<br>2) TMZ +<br>placebo<br>(manutenção)<br>3) placebo<br>(monoterapia)<br>(GRUPOPLA)|Baixo|
|**Hofland et al.**<br>**2014 (160)**|Ensaio clínico<br>randomizado|65 pacientes<br>adultos com<br>Glioblastoma<br>multiforme<br>histologicamente<br>identificado|Glioblastoma<br>multiforme|1) BEV + IRI<br>(Neoadjuvante)<br>2) BEV + IRI +<br>Radio<br>3) BEV + IRI<br>(Adjuvante)<br>(Grupo BEV +<br>IRI)|1) BEV + TMZ<br>(Neoadjuvante)<br>2) BEV + TMZ +<br>Radio<br>3) BEV + Radio<br>(Adjuvante)<br>(Grupo BEV +<br>TMZ)|Baixo|  
TMZ: temozolomida; Radio: radioterapia; IRI: irinotecano; BEV: bevacizumabe.  
96  
**Tabela 13 - Características de base dos estudos incluídos para a comparação temozolomida + radioterapia vs. temozolomida + radio + bevacizumabe.**  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**comparador**|**Idade**<br>**intervenção,**<br>**média (DP)**<br>**anos**|**Idade**<br>**comparador,**<br>**média (DP)**<br>**anos**|**Homens**<br>**intervenção**<br>**(%)**|**Homens**<br>**comparador,**<br>**n (%)**|**Qualidade de vida**<br>**(escalas EORTC**<br>**QLQ-C30 e QLQ-**<br>**BN20), média (DP)**<br>*****|**Tempo de**<br>**seguimento, mês**<br>**média (DP)**|
|---|---|---|---|---|---|---|---|---|
|**Balana et al.**<br>**2016 (156)**|45|48|Mediana: 62|Mediana:<br>62,9|55,60%|64,60%|NR|Completo (25<br>semanas)|
|**Chauffert et**<br>**al. 2014 (157)**|60|60|Mediana<br>(variação):<br>60,2(43; 69)|Mediana<br>(variação):<br>60,9 (43;71)|34 (56,7)|37 (61,7)|NR|24 meses|
|**Chinot et al.**<br>**2014;**<br>**Taphoorn et**<br>**al. 2015 (158,**<br>**159)**|458 (450<br>para<br>qualidade<br>de vida)|463 (452<br>para<br>Qualidade<br>de vida)|Mediana<br>(variação): 57<br>(20; 84)|Mediana<br>(variação): 56<br>(18; 79)|282 (61,6)|298 (64,4)|**Saúde global:**<br>BEV: 64.6 (22.4)<br>PLA: 67.4 (21.0)<br>**Função física:**<br>BEV: 82.9 (20.1)<br>PLA: 81.4 (22.4)<br>**Função Social:**<br>BEV: 71.7 (29.0)<br>PLA: 71.6 (28.6)<br>**Disfunção motora:**<br>BEV: 16.8 (23.2)<br>PLA: 14.8 (20.8)<br>**Déficit de**|17 meses|  
97  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**comparador**|**Idade**<br>**intervenção,**<br>**média (DP)**<br>**anos**|**Idade**<br>**comparador,**<br>**média (DP)**<br>**anos**|**Homens**<br>**intervenção**<br>**(%)**|**Homens**<br>**comparador,**<br>**n (%)**|**Qualidade de vida**<br>**(escalas EORTC**<br>**QLQ-C30 e QLQ-**<br>**BN20), média (DP)**<br>*****|**Tempo de**<br>**seguimento, mês**<br>**média (DP)**|
|---|---|---|---|---|---|---|---|---|
||||||||**comunicação:**<br>BEV: 16.9 (24.8)<br>PLA: 17.6 (25.2)<br>**Atividades**<br>**cotidianas:**<br>BEV: 66.6 (32.7)<br>PLA: 66.8 (32.4)<br>**Função emocional:**<br>BEV: 73.5 (23.1)<br>PLA: 74.3 (23.6)<br>**Função cognitiva:**<br>BEV: 74.4 (26.7)<br>PLA:74.5 (26.4)||
|**Hofland et al.**<br>**2014 (160)**|31|32|Mediana<br>(variação): 59<br>(36;77)|Mediana<br>(variação): 62<br>(30;73)|18 (58)|21 (65,6)|NR|Mediana 31 (19; 43)<br>meses|  
TMZ: temozolomida; Radio: radioterapia; BEV: bavacizumabe; IRI: Irinotecano; *As escalas de qualidade de vida variam de 0-100. Para os desfechos de disfunção motora e déficit de comunicação, quanto menor, pior. Para os demais, quanto maior, melhor.  
98  
**Tabela 14 - Resultados de eficácia para a comparação temozolomida + radioterapia vs. temozolomida + radioterapia + bevacizumabe.**  
|**Autor, ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre de**<br>**progressão (meses), média**<br>**(DP)**|**Qualidade de vida (escalas**<br>**EORTC QLQ-C30 e QLQ-**<br>**BN20), média (DP)***|**Resposta (RANO) /Mc**<br>**Donald, n (%)**|
|---|---|---|---|---|---|
||TMZ|7,7 meses (IC95% 5,4;<br>10,0)<br>Em 1 ano: 29,6%<br>Em 2 anos: 8,9%<br>Em3 anos:4,4%|2,2 meses (IC95% 2,0; 2,5)|NR|RANO:**Parcial:**3 (6,7)<br>**Doença estável:**8 (17,8)<br>**Benefício clínico:**11 (24,5)<br>**Progressão:**32 (71,1)|
|||10,6 meses (IC95%|||RANO:**Parcial:**11 (22,9)<br>**Doença estável:**18 (35,7)|
|**Balana et al.**<br>**2016 (156)**|TMZ+BEV|6,9; 14,3)<br>Em 1 ano: 48,9%<br>Em 2 anos: 20,5%<br>Em 3 anos: 10,9%|4,8 meses (IC95% 4,0; 5,6)|NR|**Benefício clínico**: 29 (60,4)<br>**Progressão:**15 (31,3)<br>**Não houve diferença no efeito**<br>**para resposta RANO entre os**<br>**grupos (OR não significante)**|
||HR<br>(IC95%)<br>entre|0,68 (0,44; 1,04)<br>p=0,07|0,70 (0,46; 1,07) p=0,10|NR|NR|
||grupos|||||
|**Chauffert et al.**|BEV|Mediana (IC95%):<br>11,1 (9,0; 15,0)|Mediana (IC95%): 7,1 (5,5;<br>9,2)<br>% em 6 meses: 61,7 (48,2;|NR|NR|
|**2014 (157)**|||72,6)|||
||TMZ|Mediana (IC95%):<br>11,1 (9,0; 15,0)|Mediana (IC95%): 5,2 (4,3;<br>6,8)|NR|NR|  
99  
|**Autor, ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre de**<br>**progressão (meses), média**<br>**(DP)**|**Qualidade de vida (escalas**<br>**EORTC QLQ-C30 e QLQ-**<br>**BN20), média (DP)***|**Resposta (RANO) /Mc**<br>**Donald, n (%)**|
|---|---|---|---|---|---|
||||% em 6 meses: 41,7 (29,2;<br>53,7)|||
||HR|||||
||(IC95%)<br>entre||0,82 (0,56; 1,19)|NR|NR|
||grupos|||||
|||||**Δ em relação ao basal**<br>**(saúde global):**<br>10 semanas: -3,8; 18<br>semanas: -0,9; 26 semanas: -<br>1,2; 34 semanas: -0,6; 43<br>semanas: +0,3; 52 semanas:<br>0; 61 semanas: +0,7; 70<br>semanas: +2,3||
|**Chinot et al.**<br>**2014/Taphoorn**<br>**et al. 2015**<br>**(158, 159)**|Radio +<br>TMZ +<br>BEV|Mediana: 16,8 meses<br>Em 1 ano: 72,4%<br>Em 2 anos: 33,9%|Mediana: 10,6 meses|**Função física:**<br>10 semanas: -5,3; 18<br>semanas: -4,5; 26 semanas: -<br>4,9; 34 semanas: -5,0; 43<br>semanas: -3,4; 52 semanas: -<br>3,7; 61 semanas: -2,1; 70<br>semanas: +0,7<br>**Função social:**<br>10 semanas: +0,3; 18<br>semanas: +0,5; 26 semanas:<br>+1,3; 34 semanas: +3,8; 43<br>semanas:+6,4; 52 semanas:|NR|  
100  
|**Autor, ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre de**<br>**progressão (meses), média**<br>**(DP)**|**Qualidade de vida (escalas**<br>**EORTC QLQ-C30 e QLQ-**<br>**BN20), média (DP)***|**Resposta (RANO) /Mc**<br>**Donald, n (%)**|
|---|---|---|---|---|---|
|||||+7,7; 61 semanas: +7,3; 70<br>semanas: +3,4<br>**Disfunção motora:**<br>10 semanas: +1,1; 18<br>semanas: +0,6; 26 semanas:<br>+1,1; 34 semanas: +0,6; 43<br>semanas: +3,0; 52 semanas:<br>+2,2; 61 semanas: +0,9; 70<br>semanas: -1,4<br>**Déficit de comunicação:**<br>10 semanas: -1,2; 18<br>semanas: +0,4; 26 semanas:<br>0; 34 semanas: +2,2; 43<br>semanas: +2,3; 52 semanas:<br>+1,2; 61 semanas: +2,3; 70<br>semanas:-1,0||
||Radio +<br>TMZ +<br>PLA|Mediana: 16,7 meses<br>Em 1 ano: 66,3% (p =<br>0,049 em relação à<br>intervenção)<br>Em 2 anos: 30,1% (p =<br>0,24 em relação à<br>intervenção)|Mediana: 6,2 meses|**Δ em relação ao basal**<br>**(saúde global):**<br>10 semanas: -6,6; 18<br>semanas: -5,0; 26 semanas: -<br>2,8; 34 semanas: -2,9; 43<br>semanas: -2,7; 52 semanas:<br>+0,7; 61 semanas: -1,8; 70<br>semanas: -1,3<br>**Função física:**<br>10 semanas: -5,2; 18<br>semanas:-4,8;26semanas:-|NR|  
101  
|**Autor, ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre de**<br>**progressão (meses), média**<br>**(DP)**|**Qualidade de vida (escalas**<br>**EORTC QLQ-C30 e QLQ-**<br>**BN20), média (DP)***|**Resposta (RANO) /Mc**<br>**Donald, n (%)**|
|---|---|---|---|---|---|
|||||4,0 34 semanas: -2,1; 43<br>semanas: -1,0; 52 semanas:<br>+0,4; 61 semanas: -1,6; 70<br>semanas: -3,0<br>**Função social:**<br>10 semanas: -2,5; 18<br>semanas: -4,8; 26 semanas:<br>+0,9; 34 semanas: +2,8; 43||
|||||semanas: +2,9; 52 semanas:<br>+2,9; 61 semanas: -2,7; 70<br>semanas: -0,3<br>**Disfunção motora:**<br>10 semanas: +4,2; 18<br>semanas: +3,4; 26 semanas:<br>+2,9; 34 semanas: +2,9; 43<br>semanas: +2,5; 52 semanas: -<br>0,2; 61 semanas: +0,6; 70<br>semanas: +2,8<br>**Déficit de comunicação:**<br>10 semanas: +1,6; 18<br>semanas: +2,2; 26 semanas:<br>+1,5; 34 semanas: +4,0; 43<br>semanas: +2,6; 52 semanas:<br>+0,6; 61 semanas: -0,7; 70<br>semanas:+0,8||  
102  
|**Autor, ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre de**<br>**progressão (meses), média**<br>**(DP)**|**Qualidade de vida (escalas**<br>**EORTC QLQ-C30 e QLQ-**<br>**BN20), média (DP)***|**Resposta (RANO) /Mc**<br>**Donald, n (%)**|
|---|---|---|---|---|---|
||HR<br>(IC95%)<br>entre<br>grupos)|0,88 (0,76; 1,02)<br>p=0,10|0,64 (0,55; 0,74) p<0,001 [a<br>favor do BEV]|**Estado de saúde geral:**0,64<br>(0,56; 0,74) p<0,001 [a favor<br>do BEV]<br>**Função física:**0,70 (0,61;<br>0,81) p<0,001 [a favor do<br>BEV]<br>**Função social:**0,63 (0,55;<br>0,73) p<0,001 [a favor do<br>BEV]<br>**Disfunção motora:**0,67<br>(0,58; 0,78) p<0,001 [a favor<br>do BEV]<br>**Déficit de comunicação:**<br>0,67 (0,58; 0,77) p<0,001 [a<br>favor do BEV]|NR|
||BEV +<br>TMZ|Mediana (IC95%):<br>11,8 (8,2; 15,3)|Mediana (IC95%): 7,7 (5,1;<br>10,2)<br>Em 6 meses: 53%|NR|Mc Donald:<br>**Parcial:**32% (17; 51%)<br>**Resposta menor:**35,5% (19;<br>55%)|
||||Em 12 meses: 6%||**Progressão:**13% (4;29%)|
|**Hofland et al.**<br>**2014 (160)**|BEV + IRI|Mediana (IC95%):<br>15,1 (9,6; 20,6)|(Mediana (IC95%): 7,3 (5,0;<br>9,3) p=0,79 em relação a<br>BEV + TMZ<br>Em 6 meses: 52%<br>Em 12 meses: 10%|NR|Mc Donald:<br>**Parcial:**23% (9; 44%) (p=0,56<br>em relação a Bev + TMZ)<br>**Resposta menor:**27% (12;<br>48%) (p=0,57 em relação a<br>BEV + TMZ)<br>**Progressão:**19% (8; 38%)|  
103  
|**Autor, ano**|**Grupos**|**Sobrevida (meses),**<br>**média (DP)**|**Sobrevida livre de**<br>**progressão (meses), média**<br>**(DP)**|**Qualidade de vida (escalas**<br>**EORTC QLQ-C30 e QLQ-**<br>**BN20), média (DP)***|**Resposta (RANO) /Mc**<br>**Donald, n (%)**|
|---|---|---|---|---|---|
||||||(p=0,73 em relação a BEV +<br>TMZ)|  
TMZ: temozolomida; Radio: radioterapia; BEV: bavacizumabe; IRI: Irinotecano; IC: intervalo de confiança; NR: Não relatado; DP: desvio padrão; HR: Hazard ratio.  
**Tabela 15 - Eventos adversos para os ensaios clínicos randomizados incluídos para a comparação entre temozolomida + radioterapia vs. temozolomida + radioterapia + bevacizumabe.**  
|**Autor, ano**|**Balana**<br>**(**|**et al. 2016***<br>**156)**|**Valo**<br>**r p**|**Chauff**<br>**2014**|**ert et al.**<br>**(157)**|**Chinot et al**|**. 2014 (158)**|**Valor**<br>**p**|**Hoflan**<br>**2014**|**d et al.**<br>**(160)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|**TMZ**|**TMZ+BE**<br>**V**||**BEV**|**TMZ**|**Radio + TMZ +**<br>**BEV**|**Radio + TMZ +**<br>**PLA**||**BEV +**<br>**TEM**|**BEV +**<br>**IRI**|
|Déficit<br>neurológico, n<br>(%)|24<br>(53,3)|12 (25)|0,005|NR|NR|NR|NR|NR|NR|NR|
|Anemia,n(%)|1(2,2)|1(2,1)|NR|0|0|NR|NR|NR|NR|NR|
|Proteinúria, n (%)|NR|NR|NR|NR|NR|72 (15,6)|19 (4,2)|p<0,0<br>01|NR|NR|
|HAS, n (%)|0|2 (4,2)|NR|0|0|181 (39,3)|57 (12,7)|p<0,0<br>01|15<br>(46,8)|10<br>(32,3)|  
104  
|**Autor, ano**|**Balana**<br>**(**|**et al. 2016***<br>**156)**|**Valo**<br>**r p**|**Chauff**<br>**2014**|**ert et al.**<br>**(157)**|**Chinot et al.**|**2014 (158)**|**Valor**<br>**p**|**Hoflan**<br>**2014**|**d et al.**<br>**(160)**|
|---|---|---|---|---|---|---|---|---|---|---|
|||**TMZ+BE**||||**Rdi + TMZ +**|**Rdi + TMZ +**||**BEV +**|**BEV +**|
|**Evento adverso**<br>|**TMZ**|**V**||**BEV**|**TMZ**|**ao**<br>**BEV**|**ao**<br>**PLA**||<br>**TEM**|<br>**IRI**|
|Hemorragia, n<br>(%)|0|1 (1,21)|NR|NR|NR|171 (37,1)|88 (19,6)|NR|NR|NR|
|Hemorragia|||||||||||
|Intracranial, n<br>(%)|0|2 (4,2)|NR|3 (5,3)|1 (1,8)|15 (3,3)|9 (2,0)|NR|NR|NR|
|Fadiga,n(%)|NR|NR|NR|NR|NR|NR|NR|NR|24(75)|23(74)|
|Infecção,n(%)|3 (6,6)|5 (10,4)|NR|5 (8,8)|2(3,6)|NR|NR|NR|NR|NR|
|Toxicidade grave,<br>n(%)|NR|NR|NR|NR|NR|179 (38,8)|115 (25,6)|p<0,0<br>01|NR|NR|
|Perfuração<br>gastrintestinal, n<br>(%)|0|1 (2,1)|NR|3 (5,3)|2 (3,6)|8 (1,7)|2 (0,4)|NR|NR|NR|
|Eventos<br>tromboembólicos,<br>n(%)|3 (6,6)|2 (4,2)|NR|5 (8,8)|0|**Arterial:**27 (5,9)<br>**Venoso:**38 (8,2)|**Arterial:**7 (1,6)<br>**Venoso:**43 (9,6)|p=0,0<br>01|0|1 (3,2)|
|Trombocitopenia,<br>n(%)|5<br>(11,1)|1 (2,1)|NR|2 (3,5)|8 (14,3)|**Grau 3:**69 (15)|**Grau 3:**44 (9,8)|p=0,0<br>2|NR|NR|
|Náusea, n (%)|0|1 (2,1)|NR|NR|NR|NR|NR|NR|12<br>(37,5)|13 (42)|
|Vômito,n(%)|NR|NR|NR|NR<br>|NR|NR|NR|NR|8 (25)|3 (9,7)|
|Linfopenia, n (%)|1 (2,2)|1 (2,1)|NR|7<br>(12,3)|7 (12,5)|NR|NR|NR|NR|NR|
|Neutropenia, n<br>(%)|3 (6,7)|1 (2,1)|NR|4 (7,0)|5 (9,0)|NR|NR|NR|NR|NR|
|Neutropenia<br>febril,n(%)|2 (4,4)|1 (2,1)|NR|1 (1,7)|0|NR|NR|NR|NR|NR|  
105  
|**Autor, ano**|**Balana**<br>**(**|**et al. 2016***<br>**156)**|**Valo**<br>**r p**|**Chauff**<br>**2014**|**ert et al.**<br>**(157)**|**Chinot et al**|**. 2014 (158)**|**Valor**<br>**p**|**Hoflan**<br>**2014**|**d et al.**<br>**(160)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|**TMZ**|**TMZ+BE**<br>**V**||**BEV**|**TMZ**|**Radio + TMZ +**<br>**BEV**|**Radio + TMZ +**<br>**PLA**||**BEV +**<br>**TEM**|**BEV +**<br>**IRI**|
|Leucopenia, n<br>(%)|2 (4,4)|1 (2,1)|NR|NR|NR|NR|NR|NR|NR|NR|
|Morte durante<br>tratamento,n(%)|4 (8,9)|4 (8,3)|NR|4 (7,0)|2 (3,5)|20 (4,3)|12 (2,7)|NR|NR|NR|
|Qualquer evento<br>adverso/toxicidad<br>e,n(%)|29<br>(64,4)|39 (81,3)|NR|NR|NR|454 (98,5)|432 (96)|<0,00<br>1|NR|NR|  
*Resultados de segurança (eventos graus 3-4) relatados apenas para o período neoadjuvante; TMZ: temozolomida; Radio: radioterapia; BEV: bavacizumabe; IRI: Irinotecano; NR: Não relatado.  
106

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.3 Resultados para os estudos incluídos para a comparação entre temozolomida + radioterapia vs. temozolomida + radioterapia + nitrosoureias** -->
**Tabela 16 - Características dos estudos incluídos para a comparação entre temozolomida + radioterapia vs. temozolomida + radioterapia + nitrosoureias.**  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**População e objetivo**|**Tipo de glioma**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Hart et al.**<br>**2013 (101)**|Revisão<br>sistemática com<br>meta-análise|Oito ensaios clínicos<br>randomizados (em 11<br>publicações) incluindo<br>2220 participantes.|Glioblastoma multiforme<br>(7 estudos) e<br>glioblastoma ou<br>astrocitoma anaplásico (1<br>estudo)|TMZ (primeiro<br>concomitante e depois<br>adjuvante a radio<br>(metronômico)|TMZ (primeiro<br>concomitante e<br>depois adjuvante<br>a radio (dose-<br>dense)|Baixo*|
|**Chang et**<br>**al. 2015**<br>**(161)**|Ensaio clínico<br>randomizado|196 pacientes adultos,<br>com confirmação<br>histológica de<br>astrocitoma anaplásico|Astrocitoma anaplásico|Radio + TMZ**(Grupo**<br>**TMZ)**|Radio +<br>Nitrosureias<br>(BCNU ou<br>CCNU)**(Grupo**<br>**NU)**|Alto<br>(Resumo de<br>congresso sem<br>informação sobre<br>randomização,<br>alocação e<br>cegamento)|
|**Kim et al.**<br>**2011 (162)**|Ensaio clínico<br>randomizado|76 pacientes adultos<br>com glioblastoma<br>recém diagnosticado|Glioblastoma recém<br>diagnosticado|Nimustina/cisplatina<br>(neoadjuvante) +<br>Radio + TMZ<br>adjuvante**(ACNU-**<br>**CDDP)**|Radio + TMZ<br>adjuvante<br>**(TMZ)**|Alto<br>(Estudo<br>interrompido com<br>apenas 49% do<br>recrutamento<br>completado,<br>devido a<br>toxicidade;<br>Análise estatística|  
107  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**População e objetivo**|**Tipo de glioma**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Hart et al.**<br>**2013 (101)**|Revisão<br>sistemática com<br>meta-análise|Oito ensaios clínicos<br>randomizados (em 11<br>publicações) incluindo<br>2220 participantes.|Glioblastoma multiforme<br>(7 estudos) e<br>glioblastoma ou<br>astrocitoma anaplásico (1<br>estudo)|TMZ (primeiro<br>concomitante e depois<br>adjuvante a radio<br>(metronômico)|TMZ (primeiro<br>concomitante e<br>depois adjuvante<br>a radio (dose-<br>dense)|Baixo*|
|||||||com pouco poder<br>(IC90%))|  
*Alto risco de viés dos estudos individuais incluídos; NU: nitrosureias; ACNU: nimustina; BCNU: carmustina; CCNU: lomustina; CDDP: cisplatina; TMZ: Temozolamida; Radio: radioterapia.  
**Tabela 17 - Características de base dos estudos incluídos para a comparação entre temozolomida + radioterapia vs. temozolomida + radioterapia + nitrosoureias.**  
|**Autor,**<br>**ano**|**N**<br>**intervenç**<br>**ão**|**N**<br>**comparad**<br>**or**|**Idade**<br>**intervenção,**<br>**média (DP)**<br>**anos**|**Idade**<br>**comparador,**<br>**média (DP) anos**|**Homens**<br>**intervenção (%)**|**Homens**<br>**comparador, n (%)**|**Tempo de seguimento, mês**<br>**média (DP)**|
|---|---|---|---|---|---|---|---|
|**Hart et**<br>**al. 2013**<br>**(101)**|222|0|Médias descrita<br>72|s variando de 51 a<br>anos|Variando d|e 47% a 66%|NR|  
108  
|**Chang et**<br>**al. 2015**|97|99|NR|NR|NR|NR|NR|
|---|---|---|---|---|---|---|---|
|**(161)**||||||||
|**Kim et**<br>**l**|||||||Não foi informado o tempo|
|**a.**<br>**2011****<br>**(162)**|38|38|51,4 (12,4)|51,1 (11,8)|11 (27,5)|15 (35,7)|médio/mediano de<br>seguimento|  
**Resultados descritos para a população inicialmente elegível de 82 pacientes; DP: desvio padrão; NR: não relatado.  
**Tabela 18 - Resultados de sobrevida para os estudos incluídos para comparação entre temozolamida+ radioterapia vs. temozolomida + radioterapia + nitrosoureias.**  
|**Autor, ano**|**Grupos**|**Sobrevida (meses), média (DP)**|**Sobrevida livre de progressão (meses),**<br>**média (DP)**|
|---|---|---|---|
|**Hart et al. 2013**<br>**(101)**|TMZ vs. nitrosureias|HR global = 0,90 (IC95% 0,76; 1,06)<br>**Doença recorrente:**HR = 0,79 (IC95%<br>0,61;1,03)|NR|
||TMZ|Mediana (IC95%): 3,9 (3,0; 7,0) anos|NR|
|**Chang et al. 2015**<br>|NU|Mediana (IC95%): 3,8 (2,2; 7,0) anos|NR|
|**(161)**|HR (IC95%) entre<br>grupos)|0,94 (0,67; 1,33)||
||ACNU-CDDP|Mediana (IC90%): 28,4 (2,1; NA) *|Mediana (IC90%): 6,6 (3,5; 9,5)|
|**Kim et al. 2011 (162)**|TMZ|Mediana (IC90%): 18,9 (17,1; 27,4) p =<br>0,2 entregrupos|Mediana (IC90%): 5,1 (3,8; 8,8) p = 0,8 entre<br>grupos|  
*De acordo com o os autores, não foi possível obter o intervalo de confiança superior; NU: nitrosureias; ACNU: nimustina; CDDP: cisplatina; TMZ: Temozolamida; Radio: radioterapia; IC: Intervalo de confiança.  
109  
**Tabela 19 - Eventos adversos para a comparação entre temozolomida + radioterapia vs. temozolomida + radioterapia + nitrosoureias.**  
|**Autor, ano**|**Chang et al.**|**2015(161)**|**Valorp**|**Kim et al. 201**|**1(162)**|
|---|---|---|---|---|---|
|**Evento adverso**|**TMZ**|**NU**||**ACNU-CDDP**|**TMZ**|
|Cefaleia,n(%)|NR|NR|NR|1(2,6)|2(5,2)|
|Toxicidadegrave,n(%)|47,90%|75,80%|p< 0,001|NR|NR|
|Trombocitopenia, n (%)|NR|NR|NR|6 (15,8)|0|
|Complicaçõeshematológicas,n(%)|NR|NR|NR|12(31,6)|0|
|Neutropenia, n (%)|NR|NR|NR|5 (13,2)|0|
|Morte durante tratamento, n (%)|NR|NR|NR|1(2,6)|0|  
NU: nitrosureias; ACNU: nimustina; CDDP: cisplatina; TMZ: Temozolamida; Radio: radioterapia; NR: Não relatado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.4 Resultados para os dos estudos incluídos para a comparação entre dose metronômica e densa de temozolomida** -->
**Tabela 20 - Características dos estudos incluídos para a comparação entre dose metronômica e densa de temozolomida.**  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**População e**<br>**objetivo**|**Tipo de glioma**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Hart et**<br>**al. 2013**<br>**(101)**|Revisão<br>sistemática<br>com meta-<br>análise|Oito ensaios clínicos<br>randomizados (em<br>11 publicações)<br>incluindo 2220<br>participantes.|Glioblastoma<br>multiforme (7<br>estudos) e<br>glioblastoma ou<br>astrocitoma<br>anaplásico(1 estudo)|TMZ (primeiro<br>concomitante e depois<br>adjuvante a radio<br>(metronômico)|TMZ (primeiro<br>concomitante e depois<br>adjuvante a radio<br>(dose-dense)|Baixo*|  
110  
|**Gilbert**<br>**et al.**<br>**2013;**<br>**Armstro**<br>**ng et al.**<br>**2013**<br>**(155,**<br>**163)**|Ensaio clínico<br>randomizado|833 pacientes<br>adultos com<br>glioblastoma. Para a<br>análise de<br>deterioração foram<br>considerados apenas<br>182 pacientes<br>(Armstrong et al.<br>2013)|Glioblastoma|TMZ + radio (fase<br>concomitante + TMZ<br>dose padrão inicial de<br>150mg/m<sup>2</sup>(fase de<br>manutenção) (TMZ<br>padrão)|TMZ + radio (fase<br>concomitante) + TMZ<br>dose densa inicial 75<br>mg/m<sup>2</sup>(fase de<br>manutenção) (TMZ<br>dose-densa)|Alto<br>(Não dá detalhes<br>sobre o cegamento;<br>desfechos incompletos<br>- mITT)|
|---|---|---|---|---|---|---|  
*O risco de viés na condução da revisão sistemática é baixo, porém o risco de viés dos ECR incluídos é muito alto; TMZ: temozolomida; Radio: radioterapia; mITT: _modified Intention to Treat;_

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 21 - Características de Base para a comparação entre doses metronômica e densa de temozolomida.** -->
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**comparador**|**Idade**<br>**intervenção,**<br>**média (DP)**<br>**anos**|**Idade**<br>**comparador,**<br>**média (DP)**<br>**anos**|**Homens**<br>**intervenção**<br>**(%)**|**Homens**<br>**comparador,**<br>**n (%)**|**Tempo de**<br>**seguimento, mês**<br>**média (DP)**|
|---|---|---|---|---|---|---|---|
|**Hart et al. 2013**<br>**(101)**|22|20|Médias descritas<br>72 a|variando de 51 a<br>nos|Variando de|47% a 66%|NA|
|**Gilbert et al.**|411|422||||||
|**2013; Armstrong**<br>**et al. 2013 (155,**<br>**163)**|**Deterioração**<br>**:** 92|**Deterioração**<br>**: 90**|≥50 anos: 73%|≥50 anos: 74%|239 (58)|237 (56)|Mediana de 31,5<br>meses|  
NA: Não se aplica; DP: desvio padrão.  
111  
**Tabela 22 - Resultados de sobrevida para a comparação entre temozolomida metronômica e densa.**  
|**Autor, ano**|**Grupos**|**Sobrevida (meses), média (DP)**|**Sobrevida livre de progressão (meses),**<br>**média (DP)**|
|---|---|---|---|
|**Hart et al. 2013 (101)**|TMZ padrão x densa|HR = 0,84 (IC95% 0,51; 1,40)|NR|
|**Gilbert et al 2013**|TMZ padrão|Mediana (IC95%): 16,6 (14,9; 18,0)|Mediana (IC95%): 5,5 (4,7; 6,1)|
|**. ;**<br>**Armstrong et al. 2013 (155,**|TMZ dose-densa|Mediana (IC95%): 14,9 (13,7; 16,5)|Mediana (IC95%): 6,7 (6,2; 7,7)|
|**163)**|HR (IC95%) entre<br>grupos|1,03 (0,88; 1,20)|0,87 (0,75; 1,0)|  
TMZ: temozolomida; HR: hazard ratio; NR: não relatado; IC: intervalo de confiança.  
**Tabela 23 - Principais eventos adversos para a comparação entre temozolomida metronômica e densa.**  
|**Autor, ano**|**Hart et al. 2013(101)**|**Gilbert et al. 2013; Arms**|**trong et al. 2013(155, 163)**|
|---|---|---|---|
|**Evento adverso**|**TMZ (****_dose-dense_) **<br>**TMZ (metronômica)**|**TMZ padrão**|**TMZ dose-densa**|
|Anemia, n (%)|NR<br>NR|4 (1)|4 (1)|
|Fadiga, n (%)|OR = 2,59 (IC95% 0,34; 19,40)|12 (3,0)|33 (9,0)|
|Toxicidadegrave,n(%)|NR<br>NR|194(52,6)|120 (34,2)|
|Trombocitopenia,n(%)|OR = 0,45(IC95% 0,04;4,52)|33(10,0)|26(7,0)|
|Náusea, n (%)|NR<br>NR|5 (1,0)|8 (2,0)|
|Linfopenia, n (%)|OR = 5,09 (IC95% 2,12; 12,18) [favorece<br>metronomico]|61 (22,0)|107 (39,0)|
|Neutropenia, n (%)|OR = 1,38 (IC95% 0,22; 8,50)|24 (7,0)|36 (10,0)|
|Leucopenia, n (%)|OR = 2,59 (IC95% 0,34; 19,40)|20 (6,0)|36 (10,0)|  
112  
|Qualquer evento|OR = 2,12 (IC95% 1,15; 3,91) [favorece|||
|---|---|---|---|
|adverso/toxicidade,n(%)|metronomico]|NR|NR|  
NR: Não relatado; OR: Odds ratio; TMZ: temozolomida.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.5 Resultados para a comparação Radioterapia + temozolomida + INF-β vs. Radioterapia + temozolomida** -->
**Tabela 24 - Características do estudo e da linha de base para a comparação radioterapia + temozolomida + INF-β vs. radioterapia + temozolomida.**  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**População e**<br>**objetivo**|**Tipo de**<br>**glioma**|**Intervenç**<br>**ão**|**Compara**<br>**dor**|**N**<br>**interven**<br>**ção**|**N**<br>**comparad**<br>**or**|**Tempo de**<br>**seguimento,**<br>**mês média**<br>**(DP)**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|**Wakabay**<br>**ashi et al.**<br>**2014 (164)**|Ensaio<br>clínico<br>randomizad<br>o|122 pacientes<br>com<br>glioblastoma<br>recém<br>diagnosticado|Glioblasto<br>ma recém<br>diagnostic<br>ado|Radio +<br>TMZ|Radio +<br>TMz +<br>INFβ|63|59|2 anos|Alto<br>(Resumo de<br>congresso sem<br>informação sobre<br>randomização,<br>alocação e<br>cegamento)|  
TMZ: temozolomida; INFβ: Interferon beta; Radio: radioterapia; DP: desvio padrão.  
**Tabela 25 - Resultados de sobrevida para a comparação radioterpia + temozolomida + INF vs. radioterapia + temozolomida.**  
|**Autor, ano**|**Grupos**|**Sobrevida (meses), média (DP)**|**Sobrevida livre de progressão (meses),**<br>**média (DP)**|
|---|---|---|---|
|**Wkbhi t**|Radio + TMZ|Mediana: 20,3|Mediana: 10,1|
|**aaayas e**<br>**al 2014 (164)**|Radio+ TMZ + INFβ|Mediana:24,0|Mediana: 8,5|
|**.**|HR(IC95%)|1,00 (0,65;1,55) p=0,51|1,25 (0,85;1,84) p=0,25|  
113  
TMZ: temozolomida; INFβ: Interferon beta; Radio: radioterapia; DP: desvio padrão; HR: Hazard ratio; IC: intervalo de confiança.  
**Tabela 26 - Principais eventos adversos para a comparação radioterapia + temozolomida + INF vs. radioterapia + temozolomida.**  
|**Autor, ano**|**Wak**|**abayashi et al. 2014(164)**|
|---|---|---|
|**Evento adverso**|**Radio + TMZ**|**Radio + TMZ + INF**|
|**Linfopenia, n (%)**|Indução: 54% (grau ≥ 3)<br>Adjuvante: 34,5%|Indução: 63,8 (grau ≥ 3)<br>Adjuvante:41,9%|
|**Neutropenia, n**|Indução: 12,7% (grau ≥ 3)|Indução: 20,7% (grau ≥ 3)|
|**(%)**|Adjuvante: 3,6%|Adjuvante: 9,3%|  
TMZ: temozolomida; INFβ: Interferon beta; Radio: radioterapia.  
114  
**Questão de Pesquisa 5:** Qual a eficácia e segurança do _levetiracetam_ no tratamento da convulsão em pacientes com glioma?  
**1)** **<mark>Estratégia de busca</mark>**

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
((((("glioma"[MeSH Terms] OR "glioma"[All Fields]) AND ("seizures"[MeSH Terms] OR "seizures"[All Fields] OR "seizure"[All Fields])) OR ("levetiracetam"[Supplementary Concept] OR "levetiracetam"[All Fields] OR "keppra"[All Fields]))  
<mark>Total: 51 referências:</mark>  
<mark>Data de acesso: 11/05/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE:** -->
<mark>('glioma'/exp OR glioma AND [embase]/lim)</mark>  
<mark>AND</mark>  
<mark>('levetiracetam'/exp OR levetiracetam OR 'keppra'/exp OR keppra AND [embase]/lim)</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: <mark>AND</mark> -->
<mark>('seizure'/exp OR 'seizure' AND [embase]/lim)</mark>  
<mark>Total: 176 referências</mark>  
<mark>Data de acesso: 11/05/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 227 referências (51 no MEDLINE e 176 no Embase). Destas, 24 foram excluídas por estarem duplicadas. Foi realizada uma busca manual que resultou em 04 (quatro) referências. Duzentos e sete referências foram triadas por meio da leitura de título e resumos, das quais 22 tiveram seus textos completos avaliados para confirmação da elegibilidade.</mark>  
115  
<mark>Quinze estudos foram excluídos: uma revisão sistemática por incluir somente um estudo para a análise (o estudo dessa revisão foi incluído para análise); seis estudos foram excluídos por analisar eficácia do</mark> Keppra® ( _levetiracetam_ ) <mark>associados a todos os tipos de tumor; cinco resumos de congresso foram excluídos por não apresentar dados suficientes; três estudos foram excluídos por não estratificar os desfechos em relação aos grupos intervenção e controle. Cinco estudos observacionais (165-169) e dois ensaios clínicos randomizados foram incluídos (170, 171).</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>Os estudos serão apresentados de acordo com as comparações realizadas. A descrição sumária dos estudos para eficácia estratificados por risco encontra-se na Tabela 27. As características dos pacientes para esses estudos encontram-se na Tabela 28 e os dados de desfechos nas Tabela 29-30.</mark>  
116

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 27 - Características dos estudos incluídos para eficácia do Keppra®.** -->
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Groot et al.**<br>**2015 (165)**<br>**(resumo)**|Estudo<br>observacional<br>(série de casos)|Determinar a eficácia e<br>tolerabilidade da<br>monoterapia do LEV|Pacientes com glioma<br>e epilepsia com até 06<br>(seis) semanas de pós-<br>operatório|LEV<br>(dose/posologia<br>não relatada)|Sem grupo<br>comparador|Alto<br>(Estudo não<br>randomizado, sem<br>esquema de<br>cegamento e sem<br>grupo controle)|
|**Kim et al.**<br>**2015 (166)**|Estudo coorte<br>retrospectiva|Avaliar o benefício de<br>sobrevida do LEV em<br>comparação com outros<br>anticonvulsivantes como<br>um quimiosensibilizador<br>para a temozolamida em<br>pacientes com<br>glioblastoma.|Pacientes com<br>diagnóstico de<br>gliobastoma primário<br>submetidos à<br>ressecção do tumor<br>tratados com<br>quimioradioterapia e<br>quimioterapia<br>adjuvante com<br>temozolamida<br>conforme o protocolo<br>descrito por Stupp|LEV ≤1000mg/ dia<br>LEV >1000 mg/<br>dia|<br>Ácido<br>valpróico<br>Topiramato<br>Pregabalina<br>Oxcarbazepin<br>a<br>(As dosagens<br>não foram<br>relatadas)|Alto<br>(Natureza<br>retrospectiva dos<br>dados, diferença na<br>proporção de<br>participantes que<br>completaram o<br>tratamento entre os<br>grupos e tratamento<br>interrompido na<br>progressão da<br>doença; grupo<br>tratamento continha<br>28 pacientes usando<br>as terapias controle<br>associadas)|
|**Rosseti et al.**<br>**2013 (170)**|Ensaio clínico<br>pragmático<br>randomizado,<br>aberto|Investigar a efetividade<br>do LEV e da<br>Pregabalina em<br>pacientes com tumor<br>primário (gliomas)|Pacientes com tumor<br>primário (glioma)<br>submetidos à<br>ressecção do tumor e<br>epilepsia|LEV 500 mg/ dia -<br>dose inicial<br>Aumento diário da<br>dose em 500 mg/<br>dia<br>Dosagem máxima:|<br> <br>Pregabalina<br>150mg/ dia -<br>dose inicial<br>Aumento<br>diário da dose<br>em<br>150mg/dia|<br> <br>Alto<br>(Esquema de<br>cegamento e<br>randomização não<br>detalhados; sem<br>comparação;<br>Desfecho incompleto|  
117  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||LEV 1500 mg/ 2x<br>dia|Dosagem<br>máxima<br>300mg/ 2x ao<br>dia|(ITT apenas se tiver<br>recebido uma dose);<br>50% dos<br>participantes de cada<br>grupo estavam<br>usando outros<br>antiepilépticos)|
|**Merrell et al.**<br>**20107 (167)**|Estudo<br>observacional<br>retrospectivo<br>(série de casos)|Avaliar a eficácia e a<br>tolerabilidade da<br>monoterapia do LEV e<br>PHT no tratamento das<br>convulsões|Pacientes com<br>diagnóstico de glioma<br>e histórico prévio de<br>01 (uma) crise<br>convulsiva|LEV<br>(Dose/posologia<br>não relatada)|Fenitoína<br>(Dose/posolo<br>gia não<br>relatada)|Alto<br>(Natureza<br>retrospectiva dos<br>dados; houve grande<br>alternância entre<br>grupos comparados<br>(troca de braços)|
|**Rosati et al.**<br>**2010 (168)**|Estudo<br>observacional<br>prospectivo<br>(série de casos)|Avaliar a eficácia e<br>segurança do LEV em<br>pacientes com<br>diagnóstico recente de<br>Glioma.|Pacientes<br>hospitalizados com<br>diagnóstico recente de<br>glioma,|LEV 500 mg/ 2x<br>ao dia LEV 250<br>mg/ 2x ao dia em<br>pacientes acima de<br>70 anos<br>LEV 3000mg a<br>4000 mg/ dia se<br>necessário|NR|Alto<br>(Série de casos, sem<br>comparador)|
||Ensaio clínico|Avaliar a segurança e a<br>viabilidade na mudança<br>da monoterapia da PHT|Pacientes com história<br>de convulsões<br>associadas ao glioma|LEV 500 mg / 2x<br>dia||Alto<br>(Estudo descritivo<br>(sem ajuste e análise|
|**Lim et al.**<br>**2009 (171)**|prospectivo<br>randomizado,<br>aberto, fase II|para o LEV (Keppra ®)<br>no controle das<br>convulsões em pacientes<br>no pós-operatório de|tratados em<br>monoterapia da PHT,<br>recrutados por 13<br>meses, estratificados|LEV 1000 mg/ 2x<br>dia<br>LEV 1500 mg/ 2x<br>dia|PHT 300 a<br>400 mg/ dia|das variáveis), sem<br>cegamento;<br>randomização<br>inadequada|
|||ressecção doglioma.|para iniciarem a|||(participantes|  
118  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||monoterapia com<br>LEV dentro de 24h<br>após a craniotomia, ou<br>a continuar com a<br>PHT.|||mulheres foram<br>alocadas no grupo<br>intervenção);<br>amostra menor que a<br>planejada)|
|**Wagner et al.**<br>**2003 (169)**|Estudo<br>observacional<br>prospectivo<br>(série de casos)|Avaliar a segurança e a<br>eficácia do LEV em<br>pacientes com gliomas.|Pacientes com<br>convulsão persistente,<br>reação adversa a<br>outros<br>anticonvulsivantes e/<br>ou potencial interação<br>medicamentosa com<br>quimioterápicos ou<br>glicocorticoides.|LEV 2000mg/dia<br>LEV 3000 a<br>4000mg/dia|<br>Sem grupo<br>comparador|Alto<br>(Estudo sem grupo<br>controle; efeito<br>devido à combinação<br>com outros<br>antiepilépticos)|  
LEV: levetiracetam; PHT: fenitoína; NR: não relatado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 28 - Características dos pacientes incluídos nos estudos eficácia do Keppra®.** -->
|**Autor,**<br>**ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>intervenç<br>ão|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>controle|<br>**Sexo**<br>**masculino**<br>**intervenç**<br>**ão**<br>**n (%)**|<br>**Sexo**<br>**masculi**<br>**no**<br>**control**<br>**e       n**<br>**(%)**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx.)**|**Descontinu**<br>**ação n (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo**<br>**de**<br>**seguimen**<br>**to (mín-**<br>**máx)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Groot**<br>**et al.**<br>**2015**|40|NA|NR||NR||NR|3 (7,5)|Progressão da<br>doença (3)|6 meses<br>(3-6)|  
119  
|**Autor,**<br>**ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>intervenç<br>ão|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>controle|**Sexo**<br>**masculino**<br>**intervenç**<br>**ão**<br>**n (%)**|**Sexo**<br>**masculi**<br>**no**<br>**control**<br>**e       n**<br>**(%)**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx.)**|**Descontinu**<br>**ação n (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo**<br>**de**<br>**seguimen**<br>**to (mín-**<br>**máx)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**(resumo**<br>**) (165)**<br>**Kim et**<br>**al. 2015**<br>**(166)**|LEV: 30<br>LEV +<br>outros<br>anticonvulsiv<br>antes (NR):<br>09<br>LEV + ácido<br>valpróico: 05<br>LEV +<br>topiramato:<br>14|Ácido<br>valpróico: 17<br>Topiramato:<br>12<br>Pregabalina:<br>2<br>Oxcarbamaze<br>pina: 1<br>Politerapia<br>sem LEV: 5<br>Não<br>receberam<br>anticonvulsiv<br>antes: 8|59 (19-<br>84) *|61 (18-<br>76) *|29 (50)|23 (51)|Intervenção:<br>16.9 meses<br>(4,6-49,5)<br>Controle:<br>15,5 (2,7-<br>71,5)<br>p=0.932|NR|NR|Clínico:<br>17 (3 -<br>72)<br>Radiológi<br>co:<br>13 (1 -<br>68)|
|**Rosseti**|||||||||Efeitos colaterais<br>(Intervenção: 6/<br>controle: 3)|<br> <br>|
|**et al.**<br>**2013**<br>**(170)**|25|27|54.5 (±<br>12.7)|52,7 (±<br>10,9)|16 (64)|15 (56)|≥ 12 meses<br>(NR)|7 (28)|Progressão da<br>doença<br>(Controle: 2)<br>Falta de eficácia<br>no controle da|<br>12 meses|  
**(resumo ) (165)**  
120  
|**Autor,**<br>**ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>intervenç<br>ão|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>controle|<br>**Sexo**<br>**masculino**<br>**intervenç**<br>**ão**<br>**n (%)**|**Sexo**<br>**masculi**<br>**no**<br>**control**<br>**e       n**<br>**(%)**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx.)**|**Descontinu**<br>**ação n (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo**<br>**de**<br>**seguimen**<br>**to (mín-**<br>**máx)**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||convulsão<br>(Intervenção: 1/||  
controle: 2)  
|**Merrell**<br>**et al.**<br>**20107**|51|25|50.5<br>(± 12,39)|52.3<br>(±**12,72)**|26 (51)|16 (64)||NR|NR|Low<br>grade<br>glioma:<br>38 meses<br>(9-78)<br>High|
|---|---|---|---|---|---|---|---|---|---|---|
|**(167)**||||||||||grade<br>glioma:<br>18 meses<br>(6-96)|
||||Epilepsia<br>:||Epilepsia:||||||
|**Rosati**<br>**et al.**<br>**2010**<br>**(168)**|176 (47%<br>com<br>epilepsia)|NA|50 (± 16)<br>Sem<br>epilepsia:<br>62 (±<br>13.2)|NA|52 (63)<br>Sem<br>Epilepsia:<br>49 (52)|NA|NR|2 (2)|Reação adversa<br>ao LEV: (2)|13.1<br>meses (10<br>meses-2.9<br>anos)|  
121  
|**Autor,**<br>**ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>intervenç<br>ão|**Idade**<br>**em anos,**<br>**média**<br>(DP)<br>controle|**Sexo**<br>**masculino**<br>**intervenç**<br>**ão**<br>**n (%)**|**Sexo**<br>**masculi**<br>**no**<br>**control**<br>**e       n**<br>**(%)**|**Tempo de**<br>**tratamento,**<br>**mediana**<br>**(mín-máx.)**|**Descontinu**<br>**ação n (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo**<br>**de**<br>**seguimen**<br>**to (mín-**<br>**máx)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Lim et**<br>**al. 2009**<br>**(171)**|20|9|46 (20–<br>56) *|39 (32–<br>83) *|14 (70)|9 (100)|06 meses<br>(NR)|06 (21)|Mudança de<br>tratamento: 3<br>Óbito: 1<br>Participação em<br>outro ensaio<br>clínico:1|<br>≥ 06<br>meses|
|**Wagner**<br>**et al.**<br>**2003**<br>**(169)**|26 (18 alto-<br>grau e 8<br>baixo grau)<br>LEV +<br>outros<br>anticonvulsiv<br>antes (NR):<br>25||NR||NR||12,8 (3,5 -<br>20)|NR|NR|9,3|  
<mark>N: total de pacientes; mg: miligrama; * mediana (valor mínimo – valor máximo); n: número de pacientes; LEV: levetiracetam; PHT: fenitoína; DP: desvio padrão; mín-máx.: mínimo e máximo; NR: não relatado; NA: não se aplica.</mark>  
122

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 29 - Desfechos de eficácia do Keppra® pelos estudos incluídos.** -->
|**Autor, ano**|**Ausência de**<br>**convulsão, n (%)**<br>**Intervenção**|**Ausência de**<br>**convulsão, n (%)**<br>**Controle**|**Presença de**<br>**convulsão, n**<br>**(%)**<br>**Intervenção**|**Presença de**<br>**convulsão, n**<br>**(%) Controle**|**Convulsões,**<br>**média (DP)**<br>**Intervenção**|**Convulsões,**<br>**média (DP)**<br>**Controle**|**Seguimento**|
|---|---|---|---|---|---|---|---|
|**Groot et al.**<br>**2015**<br>**(resumo)**<br>**(165)**|21 (57)<br>Redução 50%: 6<br>(16)<br>Sem alteração: 2<br>(5)|NR|NR|NR|NR|NR|6 meses|
|**Kim et al.**<br>**2015 (166)**|45 (77)|34 (76)|13 (23)|11 (24)<br>p=1,0 (entre<br>grupos)|NR|NR|17 meses|
|**Rosseti et al.**<br>**2013 (170)**|17 (65)|18 (75)|NR|NR|NR|NR|12 meses|
||||||0,075 (0,142) /|0,076 (0,135) /<br>mês (p=0,776||
|**Merrell et al.**<br>**20107 (167)**|NR|NR|NR|NR|mês<br>mediana (dias)<br>2ª convulsão:<br>882|entre grupos)<br>mediana (dias)<br>2ªconvulsão:<br>730 (p=0,54<br>entregrupos)|18 a 38<br>meses|
|**Rosati et al.**<br>**2010 (168)**|75 (91)|NR|NR|NR|NR|NR|12 meses|
|**Lim et al.**<br>**2009 (171)**|13 (87)|6 (75)|Raras: 2 (12)|Raras: 2 (25)|NR|NR|>6 meses|
||10 (38)|||||||
|**Wagner et**<br>**al. 2003**<br>**(169)**|Redução de até<br>50%: 9 de 20 (35)<br>Redução > 50%:<br>13de 20 (65)|NR|NR|NR|NR|NR|9,3 meses|  
<mark>n: número de pacientes; (%): proporção de pacientes; DP: desvio padrão; NR: não reportado.</mark>  
123  
**Tabela 30 - Eventos adversos reportados pelos estudos incluídos.**  
|**Autor, ano**|**Groot et al.**<br>**2015**<br>**(resumo)**<br>**(165)**|**Rosse**|**ti et al. 2013**<br>**(170)**|**Merrell**<br>**(**|**et al. 20107**<br>**167)**|**Valor**<br>**p**|**Rosati et al.**<br>**2010 (168)**|**Lim et al.**|**2009 (171)**|**Wagner**<br>**et al.**<br>**2003**<br>**(169)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|**LEV**|**LEV**|**Pregabalina**|**LEV**|**Fenitoína**||**LEV**|**LEV**|**Fenitoína**|**LEV**|
|Qualquer EA|3|NR|NR|5,9|20|0,106|NR|2 (13)|2 (29)|5 de 20<br>(25)|
|Baixa de<br>leucócitos(%)|NR|14,3|23,5|NR|NR|NR|NR|NR|NR|NR|
|Baixa de|||||||||||
|hemoglobina<br>(%)|NR|35,7|21,1|NR|NR|NR|NR|NR|NR|NR|
|Baixa de<br>plaquetas(%)|NR|80,8|22,2|NR|NR|NR|NR|NR|NR|NR|
|Agravo<br>(Epworth) ≥ 5<br>(%)|NR|44,4|21,7|NR|NR|NR|NR|NR|NR|NR|
|Ansiedade(%)|NR|25|23,1|NR|NR|NR|NR|NR|NR|NR|
|Insônia,n(%)|NR|NR|NR|NR|NR|NR|NR|6(40)|3(43)|NR|
|Irritabilidade<br>(%)|NR|12,5|15,4|NR|NR|NR|NR|NR|NR|NR|
|Instabilidade<br>emocional, n<br>(%)|NR|NR|NR|NR|NR|NR|NR|1 (7)|0|NR|
|Dificuldade de<br>fala,n(%)|NR|NR|NR|NR|NR|NR|NR|2 (13)|0|NR|
|Depressão(%)|NR|37,5|26,9|NR|NR|NR|NR|1(7)|1(14)|NR|  
124  
|**Autor, ano**|**Groot et al.**<br>**2015**<br>**(resumo)**<br>**(165)**|**Rosset**<br>|**i et al. 2013**<br>**(170)**|**Merrell**<br>**(**|**et al. 20107**<br>**167)**|**Valor**<br>**p**|**Rosati et al.**<br>**2010 (168)**|**Lim et al.**|**2009 (171)**|**Wagner**<br>**et al.**<br>**2003**<br>**(169)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|**LEV**|**LEV**|**Pregabalina**|**LEV**|**Fenitoína**||**LEV**|**LEV**|**Fenitoína**|**LEV**|
|Psicose(%)|NR|4,2|0|NR|NR|NR|NR|NR|NR|NR|
|Fraqueza, n<br>(%)|NR|NR|NR|NR|NR|NR|NR|3 (20)|3 (43)|NR|
|Capacidade de<br>concentração<br>baixa(%)|NR|37,5|30,8|NR|NR|NR|NR|NR|NR|NR|
|Infecção com|||||||||||
|necessidade de<br>antimicrobiano<br>(%)|NR|12,5|19,2|NR|NR|NR|NR|NR|NR|NR|
|Cefaleia(%)|NR|16,7|11,5|NR|NR|NR|NR|1(7)|1(14)|NR|
|Tontura(%)|NR|16,7|30,8|NR|NR|NR|NR|0|1(14)|NR|
|Diplopia,<br>visão borrada<br>(%)|NR|8,3|11,5|NR|NR|NR|NR|NR|NR|NR|
|Rash cutâneo<br>(%)|NR|0|7,7|NR|NR|NR|NR|NR|NR|NR|
|Ganho de peso<br>> 10%(%)|NR|4,2|7,7|NR|NR|NR|NR|NR|NR|NR|
|Arritmia<br>cardíaca(%)|NR|12,5|19,2|NR|NR|NR|NR|NR|NR|NR|
|Disfunção<br>erétil(%)|NR|8,3|0|NR|NR|NR|NR|NR|NR|NR|
|Disfunção de<br>libido(%)|NR|20,8|23,1|NR|NR|NR|NR|NR|NR|NR|  
125  
|**Autor, ano**|**Groot et al.**<br>**2015**<br>**(resumo)**<br>**(165)**|**Rosse**|**ti et al. 2013**<br>**(170)**|**Merrell**<br>**(1**|**et al. 20107**<br>**67)**|**Valor**<br>**p**|**Rosati et al.**<br>**2010 (168)**|**Lim et al.**|**2009 (171)**|**Wagner**<br>**et al.**<br>**2003**<br>**(169)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|**LEV**|**LEV**|**Pregabalina**|**LEV**|**Fenitoína**||**LEV**|**LEV**|**Fenitoína**|**LEV**|
|Sonolência, n<br>(%)|NR|NR|NR|NR|NR|NR|4 (2,3)|3 (20)|2 (29)|NR|
|Dificuldade|||||||||||
|coordenação, n<br>(%)|NR|NR|NR|NR|NR|NR|NR|0|2 (29)|NR|  
* desfechos após 6 meses de seguimento; EA: eventos adversos; LEV: levetiracetam; NR: não reportado.  
126  
**Questão de Pesquisa 6:** Qual a eficácia e segurança da Fenitoína (i.v.) no tratamento da convulsão no pré-operatório?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
((("glioma"[MeSH Terms] OR "glioma"[All Fields]) AND ("seizures"[MeSH Terms] OR "seizures"[All Fields] OR "seizure"[All Fields])) AND ("phenytoin"[MeSH Terms] OR "phenytoin"[All Fields])) OR hydantal[All Fields]  
<mark>Total de referências: 48 referências</mark>  
<mark>Data de acesso: 02/06/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE:** -->
<mark>(glioma AND [embase]/lim) OR ('glioma'/exp OR glioma AND [embase]/lim) AND</mark>  
<mark>('seizure'/exp OR 'seizure' AND [embase]/lim)</mark>  
<mark>AND</mark> ('phenytoin <mark>'/exp OR</mark> 'phenytoin' <mark>AND [embase]/lim) AND (</mark> 'hydantal <mark>'/exp OR</mark> hydantal <mark>AND [embase]/lim) Total: 398 referências</mark>  
<mark>Data de acesso: 02/06/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 446 referências (48 no MEDLINE e 398 no Embase). Destas, 14 foram excluídas por estarem duplicadas. Foi realizada uma busca manual que resultou em 01 (uma) referência. Quatrocentos e trinta e três referências foram triadas por meio da leitura de título e resumos, das quais 16 tiveram seus textos completos avaliados para confirmação da elegibilidade.</mark>  
127  
<mark>Onze estudos foram excluídos: uma meta análise por não descrever a eficácia e segurança dos anticonvulsivantes no período pré-operatório; uma revisão sistemática por incluir todos os tipos de tumores e não estratificar os dados do período pré-operatório; oito estudos observacionais foram excluídos por analisar eficácia do Hidantal</mark> (Fenitoína) <mark>associados somente aos períodos intra e pós-operatórios e um estudo por descrever os desfechos incompletos. No total, cinco estudos observacionais foram incluídos (172-176).</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>Os estudos serão apresentados de acordo com as comparações realizadas. A descrição sumária dos estudos para eficácia da fenitoína estratificados por risco encontrase na Tabela 31. As características dos pacientes para esses estudos encontram-se na Tabela 32, os dados de desfechos de eficácia nas Tabela 33-35 e os eventos adversos reportados pelos estudos foram descritos na Tabela 36.</mark>  
128

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 31 - Características dos estudos incluídos para eficácia da Fenitoína.** -->
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Risco de viés**|
|---|---|---|---|---|---|
|**Huang et al.**<br>**2017 (172)**|Estudo<br>observacional<br>retrospectivo<br>(série de casos)|<br>Elucidar os resultados do<br>tratamento e a epidemiologia<br>da epilepsia relacionada ao<br>glioma.|Pacientes adultos com<br>diagnóstico confirmado por<br>meio do anatomopatológico<br>para glioma.|Fenitoína<br>Ácido Valpróico<br>Fenobarbital<br>(dose/ posologia não<br>relatadas)<br>2 a 3 dias antes da<br>cirurgia até        6 dias<br>após a cirurgia|<br> <br> <br>Alto<br>(Série de casos,<br>descrição incompleta<br>da intervenção e dos<br>desfechos|
|**Iuchi et al.**<br>**2015 (173)**|Estudo<br>retrospectivo<br>observacional<br>(série de casos)|<br>Esclarecer a epidemiologia e<br>os resultados do tratamento da<br>epilepsia relatada em<br>pacientes com glioma|Pacientes adultos com<br>diagnóstico confirmado<br>histologicamente para<br>glioma.|Fenitoína<br>Ácido Valpróico<br>Fenobarbital<br>(dose/ posologia não<br>relatadas)<br>administrado 2 a 3 dias<br>antes da cirurgia até 6<br>dias após a cirurgia|<br> <br> <br> <br>Alto<br>(Série de casos,<br>descrição incompleta<br>da intervenção e<br>desfechos|
|||Determinar a frequência, os||Fenitoína<br>|<br>Alto|
|**Woo et al.**<br>**2014 (174)**|Estudo<br>retrospectivo<br>observacional<br>(série de casos)|<br>fatores de risco para<br>convulsão e os efeitos<br>adversos associados aos<br>anticonvulsivantes entre os<br>pacientes comGlioma.|Pacientes adultos com<br>diagnóstico confirmado para<br>Glioma.|Ácido valpróico<br>Fenobarbital<br>Carbamazepina<br>(dose/ posologia não<br>relatadas)|<br> <br>(Série de casos, sem<br>controle, sem<br>descrição da<br>intervenção e dos<br>desfechos|
|**Chaichana et**<br>**al. 2009 (175)**|Estudo<br>retrospectivo<br>observacional<br>(série de casos)|<br>Identificar a prevalência e as<br>características das convulsões<br>em pacientes submetidos a<br>ressecção primária de<br>astrocitoma; entender os<br>fatores associados com as<br>convulsões nopré-operatório;|Pacientes adultos com<br>diagnóstico de glioma|Fenitoína<br>Levetiracetam<br>Divalproato de sódio<br>Carbamazepina<br>Ácido Valpróico<br>Lamotrigina<br>Fenobarbital|<br> <br> <br> <br>Alto<br>(Série de casos,<br>desfechos<br>incompletos|  
129  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Risco de viés**|
|---|---|---|---|---|---|
|||avaliar os efeitos que a<br>cirurgia tem no controle da<br>convulsão e discernir os<br>fatores associados com o<br>controle prolongado das<br>convulsões||(dose/ posologia não<br>relatadas)||
|**Chang et al.**<br>**2008 (176)**|Estudo<br>retrospectivo<br>observacional<br>(série de casos)|<br>Identificar a prevalência e as<br>características das convulsões<br>em pacientes com Glioma;<br>determinar a taxa de controle<br>e preditores para o controle da<br>convulsão após a ressecção<br>cirúrgica e avaliar se a<br>convulsão recorrente é um<br>marcador confiável da<br>progressão do tumor(doença).|Pacientes adultos com<br>diagnóstico de glioma =><br>sem convulsão antes da<br>cirurgia, pacientes com<br>convulsão controlada e não<br>controlada com AED antes<br>da cirurgia.|Fenitoína<br>Carbamazepina<br>Divalproato de sódio<br>Ácido Valpróico<br>Lamotrigina<br>Fenobarbital<br>(dose/ posologia não<br>relatadas)|Alto<br>(Série de casos,<br>desfechos<br>incompletos|

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 32 - Características dos participantes incluídos nos estudos eficácia da Fenitoína.** -->
|**Autor, ano**|**Sexo masculino**<br>**intervenção**<br>**N (%)**|**Idade em anos,**<br>**média**<br>**(min-máx)**|**Tempo de seguimento**<br>**Mediana**<br>**(min-máx)**|**Tempo de tratamento,**<br>**mediana**<br>**(mín-máx)**|**Tempo de sobrevida,**<br>**mediana**<br>**(mín-máx)**|
|---|---|---|---|---|---|
|**Huang et al.**<br>**2017 (172)**|73 (61)|57 (NR)|39.6 meses<br>(3.7   –84.2 meses)|NR|20.2 meses (NR)|
|**Iuchi et al.**<br>**2015 (173)**|74 (61)|58 (NR)|39.7 meses<br>(3.6   – 84.4 meses)|NR|20.4 meses (NR)|  
130  
|**Autor, ano**|**Sexo masculino**<br>**intervenção**<br>**N (%)**|**Idade em anos,**<br>**média**<br>**(min-máx)**|**Tempo de seguimento**<br>**Mediana**<br>**(min-máx)**|**Tempo de tratamento,**<br>**mediana**<br>**(mín-máx)**|**Tempo de sobrevida,**<br>**mediana**<br>**(mín-máx)**|
|---|---|---|---|---|---|
||||Glioma Grau III|||
|**Woo et al.**<br>**2014 (174)**|124 (63)|55 (± 15)|11 meses (1-69)<br>Glioma Grau IV<br>8meses (1-36)|12 meses (5 dias - 182<br>meses)|15 meses|
|**Chaichana et**<br>**al. 2009 (175)**|102 (67)|55 (± 17)|12 meses (NR)|13.7 meses (8.9 - 20.3)|NR|
|**Chang et al.**<br>**2008 (176)**|194 (28)|39.3 (16–95)|12 meses (NR)|NR|NR|  
<mark>N: número de pacientes; * mediana (valor mínimo – valor máximo); n/N (%): proporção do número de pacientes; N</mark> R: não relatado; AED: anticonvulsivante; Mín: mínimo; Máx: máxima.  
**Tabela 33 - Distribuição dos participantes incluídos nos estudos de eficácia da Fenitoína e uso de anti-convulsivantes nos períodos préoperatório, intra-operatório e pós-operatório.**  
|**Autor, ano**|**Intervenção**<br>**N população**<br>**total**|**Ocorrência de**<br>**oper**<br>**n**|**convulsão (pré-**<br>**atório)**<br>**(%)**|**Ausência de**<br>**convulsão**<br>**(pré-operatório)**|**Intra-operatório**<br>**(PHT + outros**<br>**AED conjugados)**|**Pós-operatório**<br>**(PHT + outros AED**<br>**conjugados)**|
|---|---|---|---|---|---|---|
|||**Prevalência**|**Incidência**|**n (%)**|**n (%)**|**n (%)**|
||||19 (48.2) PHT|18 (22.5) PHT<br>6 (75) PB|102 (85.8) PHT|60 (56) PHT<br>58 (49) PB<br>56 (47) VPA|
|**Huang et al.**<br>**2017 (172)**|119|NA|9 (24.1) VPA<br>8 (20.7) PB<br>3 (7) NR|.<br>4(5) VPA<br>21(26.3) AED (NR)<br>31 (38.7) sem AED|14 (11.8) PB<br>2 (1.6) VPA<br>1 (0.8) ZN|20 (17) LEV<br>4 (3) GB<br>14 (12) CBZ<br>13 (11) AED (NR)<br>12(10)sem AED|  
131  
|**Autor, ano**|**Intervenção**<br>**N população**<br>**l**|**Ocorrência de**<br>**oper**<br>**n**|**convulsão (pré-**<br>**atório)**<br>**(%)**|**Ausência de**<br>**convulsão**<br>**(pré-operatório)**|**Intra-operatório**<br>**(PHT + outros**<br>**AED conjugados)**|**Pós-operatório**<br>**(PHT + outros AED**<br>**conjugados)**|
|---|---|---|---|---|---|---|
||**tota**|**Prevalência**|**Incidência**|**n (%)**|**n (%)**|**n (%)**|
|**Iuchi et al.**<br>**2015 (173)**|121|NA|19 (46.7) PHT<br>10 (23.3) VP<br>8 (20) PB<br>4 (10) NR|18 (22.5) PHT<br>6 (7.5) PB<br>4 (5) VPA<br>22 (27.5) AED (NR)<br>30 (37.5) sem AED|103 (85.1) PHT<br>15 (12.4) PB<br>2 (1.7) VPA<br>1 (0.8) ZN|61 (50) PHT<br>59 (49) PB<br>57 (47) VPA<br>14 (12) CBZ<br>21(17) LEV<br>4(3) GB|
|||||91 (55) PHT<br>69 (42) VPA|||
|**Woo et al.**<br>**2014 (174)**|198|NA|NR|3 (2) PB<br>2 (1) CBZ<br>33 sem AED|NR|NR|  
**<u>Controlada: (**)</u>** 86 (68) PHT 9 (7) LEV 9 (7) DS 4 (3) CBZ 216 (44) PHT 6 (5) VPA 94 (61) PHT 36 (7) PHT 70 (14) LEV 3 (2) LM 23 (15) LEV **Chaichana** 6 (1.2) LEV 17 (3.5) DS 1 (1) PB 10 (7) LM **et al. 2009** 648 NA 5 (1) DS 13 (2.5) CBZ 8 (5) CBZ **(175)** 3 (0.6) CBZ 13 (2.5) VPA **<u>Não controlada</u>** <u>:</u> 4 (3) DS 1 (0.02) VPA 166 (33.5) sem 16 (62) PHT 3 (2) VPA 444 (90) sem AED AED 4 (15) LEV 3 (12) DS 1 (4) CBZ 1 (4) VPA 1 (4) LM  
132  
|**Autor, ano**|**Intervenção**<br>**N população**<br>|**Ocorrência de co**<br>**operató**<br>**n (%**|**nvulsão (pré-**<br>**rio)**<br>**)**|**Ausência de**<br>**convulsão**<br>**(pré-operatório)**|**Intra-operatório**<br>**(PHT + outros**<br>**AED conjugados)**|**Pós-operatório**<br>**(PHT + outros AED**<br>**conjugados)**|
|---|---|---|---|---|---|---|
||**total**|**Prevalência**|**Incidência**|**n (%)**|**n (%)**|**n (%)**|
|||2 (8) PB|||||
|||**Controlada:**<br>84 (61.3) PHT<br>22 (16) CBZ<br>14 (10.2) DS|||||
|**Chang et al.**<br>**2008 (176)**|332|4 (2.9) VPA<br>2 (1.4) LM<br>11(8) PB<br>**Não controlada:**<br>64 (48.4) PHT<br>36 (27.3) CBZ<br>14 (10.6) DS<br>2 (1.5) VPA<br>6 (4.5) LM<br>14 (10.6) PB|NA|11 (17.5) PHT<br>1 (1.6) CBZ<br>1 (1.6) DS<br>1 (1.6) LM<br>1 (1.6) PB<br>48 (76) sem AED|<br>159 (47) PHT<br>59 (17) CBZ<br>29 (9) DS<br>6 (2) VPA<br>9 (3) LM<br>26 (8) PB<br>48 (14) sem AED|NR|  
LEV: levetiracetam; PHT: fenitoína; VPA: Ácido Valpróico; PB: Fenobarbital; GB: Gabapentina; ZN: Zonisamida; DS: Divalproato de Sódio; LM: Lamotrigina; AED: anticonvulsivante; <mark>mg: miligrama;</mark> NR: não relatado;; NA: não se aplica; Mín: mínimo; Máx: máxim <mark>a; (**): autor citou o mesmo número de pacientes no momento pré-operatório e intra-operatório.</mark>  
133  
**Tabela 34** **<mark>- Desfechos</mark> de eficácia da Fenitoína e outros anticonvulsivantes nos pacientes com presença de convulsão no período préoperatório.**  
|**Autor, ano**|**Fatore**<br>|**s de risco relacionados à ocorrência de**<br>|**convulsão**<br>|
|---|---|---|---|
||**Pré-operatório**|**Intra-operatório**|**Pós-operatório**|
||Grau II: 19 (47.2)<br>Grau III: 12 (28.4)<br>Grau IV: 8 (19.6)|10 (8.4) desenvolveram convulsões|Pré-operatório com convulsão (17.2),<br>maior risco, (5.2, p = 0.045)|
|**Huang et al.**<br>**2017(172)**|Astrocitoma (22.7) /<br>Oligodendroglioma (40.9)<br>(p 0.145)<br>Grau II / Grau IV (p = 0.026)|4 (37) dia da cirurgia<br>PB (21.4) / PHT (6.9) (p=0.226)|(<50 anos - 84.1) (≥ 50 - 52.6): p <0.003<br>Região associada: lobo frontal (p = 0.035)|
||(<50anos) (≥ 50, p<0.001)|||
||Grau II: 20 (47.7)<br>Grau III: 12 (28.6)<br>Grau IV: 9 (19.8)<br>Astrocitoma (23.2) /|11 (9.1) desenvolveram convulsões|Pacientes com convulsões pré-operatório:<br>(17.1%)|
|**Iuchi et al.**<br>**2015 (173)**|Oligodendroglioma (36.4)            (p<br>0.157)|4 (36.8) dia da cirurgia|Demais pacientes: 5.0%, (p = 0.035, entre<br>grupos)|
||Grau II/ Grau IV (p = 0.017)|PB (20) / PHT (7.8) (p = 0.146)|(<50 anos) (≥ 50 anos): p = 0.002|
||(<50 anos) (≥ 50, p < 0.0001)||Região associada: lobo frontal (p = 0.025)|
||Lobo frontal: (p = 0.096)|||  
134  
|**Autor, ano**|**Fatores d**<br>|**e risco relacionados à ocorrência de co**<br>|**nvulsão**<br>|
|---|---|---|---|
||**Pré-operatório**|**Intra-operatório**|**Pós-operatório**|
||Lobo temporal: (p = 0.751)|||
||Primário/ Múltiplos: (p = 0.794)|||  
|**Woo et al.**||||
|---|---|---|---|
|**2014 (174)**|NA|NA|NA|
||**Variáveis associadas à ocorrência de**||**Convulsões controlada:**|
||**convulsão:**||Alto KPS (RR 0.944, 95% IC 0.914–|
||Masculino: (p = 0.01)||0.977, p = 0.002)|
||(<50 anos): (p = 0.001)||KPS ≥ 80 (RR 0.097, 95% IC 0.028–|
|**Chaichana et**<br>**al. 2009 (175)**|Tumor pequeno: (p = 0.001)|NR|0.388) aumento do controle em mais de<br>dez vezes|
||Superfície córtex: (p < 0.001)||Engel: 6 meses após cirurgia (%)<br>Classe I: 86|
||Pouca cefaleia: (p = 0.01)||Classe II: 11<br>Classe III: 3|
||Pouco déficit sensorial: (p = 0.004)||Classe IV: 0|  
135  
|**Autor, ano**|**Fatores de**|**risco relacionados à ocorrênci**|**a de convulsão**|
|---|---|---|---|
||**Pré-operatório**|**Intra-operatório**|**Pós-operatório**|
||Déficit linguagem: (p = 0.05)<br>Déficit visual: (p = 0.03)<br>**Convulsões controlada:**||Engel: 12 meses após cirurgia (%)<br>Classe I: 84<br>Classe II: 12<br>Classe III: 2<br>Classe IV: 2|
||Astrocitoma (OR 1.988, 95% IC 1.070–<br>3.695, p = 0.03)<br>Lobo temporal (OR 1.775, 95% IC<br>1.027–3.695, p = 0.04)||**Convulsões não controladas**:<br>Convulsões não controladas no pré-<br>operatório (RR 2.748, 95% IC 1.131–<br>6.368, p = 0.03)|
||**Convulsões não controladas**:<br>Pacientes com baixo KPS: (p = 0.05)<br>Convulsões parciais complexas (OR<br>5.801, 95% IC 1.056–13.893, p = 0.03)||Lobo parietal (RR 4.236, 95% IC 1.582–<br>11.012, p = 0.005)<br>Engel: 6 meses após cirurgia (%)<br>Classe I: 88<br>Classe II: 6<br>Classe III: 6|
||Componente hemorrágico (OR 12.857,<br>95% IC 1.867–18.537, p = 0.01)<br>Tumor > 3 cm (OR 2.750 IC 1.011-||Classe IV: 0<br>Engel: 12 meses após cirurgia (%)<br>Classe I: 56|
||7.9160, p = 0.01)||Classe II: 13<br>Classe III: 19<br>Classe IV: 13|  
136  
|**Autor, ano**|**Fatores de**<br>|**risco relacionados à ocorrênci**<br>|**a de convulsão**<br>|
|---|---|---|---|
||**Pré-operatório**|**Intra-operatório**|**Pós-operatório**|
||||**Convulsões controlada:**|
||Lobo frontal (p = 0.0012)||Ressecção total: (OR 16, 95% IC 2.2–124,<br>p = 0.0064)|
||Subtipo histológico (p = 0.0001)||Engel: 6 meses após cirurgia (%)|
||Oligoastrocitoma (p = 0.0007)||Classe I: 80.3|
||||Classe II: 10.2|
||Oligodendroglioma (p = 0.001)||Classe III: 5.1|
||||Classe IV: 4.4|
||**Convulsões controlada**|||
||||Engel: 12 meses após cirurgia (%)|
||Convulsões generalizadas (p = 0.0005)||Classe I: 78.9|
|**Chang et al.**<br>**2008 (176)**|**Convulsões não controladas**:|NR|Classe II: 11.4<br>Classe III: 4.4<br>Classe IV: 5.3|
||Glioma Grau I e II envolvendo o lobo<br>temporal (p = 0.017)||**Convulsões não controladas**:<br>Convulsão parcial simples (OR 0.36, 95%|
||Tipo de convulsão (p = 0.001)||IC 0.18–0.72, p =<br>0.0042)|
||Convulsões parciais simples (p =|||
||0.0005)<br>Duração da convulsão (p = 0.006)||Pré-operatório convulsões não controladas<br>(p, 0,001)<br>Crises > 1 ano (OR 0.285, 95% IC 0.145–|
||Lobo temporal (p = 0.0089)||0.558, p = 0.0003)|  
137  
|||**Fatores de risco relacionados à ocorrênci**|**a de convulsão**|
|---|---|---|---|
|**Autor, ano**||||
||**Pré-operatório**|**Intra-operatório**|**Pós-operatório**|
||||Convulsões não controladas no pré-<br>operatório mais propensos as Classes II e<br>IV (6 e 12 meses), respectivamente (p <<br>0.02)|
||||Engel: 6 meses após cirurgia (%)<br>Classe I: 50.9;<br>Classe II: 25.9<br>Classe III: 10.3;<br>Classe IV: 12.9|
||||Engel: 12 meses após cirurgia (%)<br>Classe I: 53.8;<br>Classe II: 22.6<br>Classe III: 11.3;<br>ClasseIV:12.3|  
<mark>N: número de pacientes; N/ n (%); OR:</mark> _<mark>Odds Ratio</mark>_ <mark>; IC95%: intervalo de confiança em 95%; PB: Fenobarbital; PHT: Fenitoína; AED: anticonvulsivantes; Engel: cl</mark> asse I (sem convulsões), classe II (raras convulsões), classe III (melhora significativa), classe IV (sem melhora); RR: risco relativo.  
138

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 35** **<mark>- Desfechos</mark> de eficácia da Fenitoína e outros anticonvulsivantes nos pacientes sem história de convulsão no pré-operatório.** -->
139  
|**Autor, ano**|**Pré-operatório**|**Pós-operatório**|
|---|---|---|
|||14 (18) desenvolveram convulsões|
|**Huang et al.**<br>**2017(172)**|NR|40 (50) não desenvolveram convulsões:<br>Mediana 7.2 (1.4 – 69.1 meses)|
|||AED/ sem AEDpré-operatório (longrankp=0.584)|
|||15 (19) desenvolveram convulsões|
|**Iuchi et al. 2015**<br>**(173)**|NR|41 (51) não desenvolveram convulsões: mediana 7.3 (1.3   – 68.9<br>meses)|
|||AED/sem AEDpré-operatório(longrankp=0.574)|
|||93 (83) apresentaram convulsões|
|**Woo et al. 2014**<br>**(174)**|NR|Tempo de ocorrência médio das convulsões: 8 meses após operação<br>(1 – 75 meses)<br>**Fatores relacionados ao risco de convulsão:**|
|||Glioblastoma (OR adj: 2.33, P = 0.012)|
|||Radioterapia adjuvante(OR adj:2.87,P =0.001)|  
140

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **<u><mark>Fatores associadas à ausência de convulsão:</mark></u>** -->
(≥ 50 anos) - (OR 0.983, 95% IC 0.968–0.998, p = 0.03) **Chaichana et al.** 20 (4) relataram convulsões **2009 (175)** Tumor grande (OR 0.763, 95% IC 0.653–0.872, p < 0.001) 2 (1) convulsões significativas Córtex cerebral (OR 1.646, 95% IC 1.014– 2.672, <u>p = 0.04)</u> **<u>Fatores associadas à ausência convulsão:</u>**  
Córtex cerebral (p = 0.001) **Chang et al. 2008 (176)** Controle das crises após cirurgia (94%, p. 0.005) Glioma I e II envolvendo linha média, independente dos lobos envolvidos (p = 0.0175) <mark>OR:</mark> _<mark>Odds Ratio</mark>_ <mark>; IC95%: intervalo de confiança em 95%; AED: anticonvulsivantes.</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 36 - Eventos adversos reportados pelos estudos incluídos.** -->
|**Autor, ano**<br>**Evento adverso, n**<br>**(%)**|**PHT**|**Huang 20**<br>**CBZ**|**17 (172)**<br>**PB**|**LEV**|**Iuc**<br>**PHT**|**hi et al. 20**<br>**CBZ**|**15 (173**<br>**PB**|**)**<br>**LEV**|**Woo et al.**<br>**2014 (174)**|**Chaichana et**<br>**al. 2009 (175)**|**Chang et al.**<br>**2008 (176)**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|Sonolência/<br>Déficit cognitivo|NR|NR|NR|01(?)|NR|NR|NR|01<br>(4.8)|3 (2)|NR|NR|
|Reação cutânea|NR|NR|NR|NR|NR|NR|NR|NR|17 (9)|NR|NR|
|Hepatotoxicidade|NR|NR|NR|NR|NR|NR|NR|NR|17 (9)|NR|NR|  
141  
|Mielossupressão|NR|NR|NR|NR|NR|NR|NR|NR|4 (2)|NR|NR|
|---|---|---|---|---|---|---|---|---|---|---|---|
|índrome Steve Johso|NR|NR|NR|NR|NR|NR|NR|NR|2 (1)|NR|NR|  
N: número de pacientes; N/ n (%); PHT: fenitoína; CBZ: carbamazepina; PB: fenobarbital; LEV: levetiracetam;?: eventos citados pelo autor, entretanto; não relatada a prevalência dos efeitos adversos por medicamento.  
142  
**<mark>Questão de Pesquisa 7:</mark>** <mark>Qual a eficácia e segurança do bevacizumabe para pacientes</mark>  
<mark>com glioma?</mark>  
**1) Estratégia de busca**

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
((((("Glioma"[Mesh] OR gliomas OR Glial Cell Tumor*)))) AND (("Bevacizumab"[Mesh] OR Avastin))) AND ((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh])))  
Data de acesso: 30/05/2017  
Total: 177 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE:** -->
'glioma'/exp OR 'glioma' AND [embase]/lim OR (gliomas AND [embase]/lim) AND ('bevacizumab'/mj AND [embase]/lim OR ('avastin'/mj AND [embase]/lim)) AND ('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR (cross NEXT/1 over*):de,ab,ti OR placebo*:de,ab,ti OR (doubl* NEAR/1 blind*):de,ab,ti OR (singl* NEAR/1 blind*):de,ab,ti OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti)  
Data de acesso: 30/05/2017  
Total: 347 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
A busca das evidências resultou em 524 referências (177 no MEDLINE e 347 no EMBASE). Destas, 90 foram excluídas por estarem duplicadas. Quatrocentos e trinta e quatro referências foram triadas por meio da leitura de título e resumos, das quais cento e sessenta e uma referências tiveram seus textos completos avaliados para confirmação da elegibilidade.  
143  
Como critério de inclusão, para gliomas do tipo IV (gliobastomas) foram priorizadas revisões sistemáticas com meta- análise de ensaios clínicos randomizados e ensaios clínicos randomizados. Devido à escassez de evidência para estudos que analisavam gliomas de grau III (astrocitoma anaplásico, oligodendroglioma anaplásico, oligoastrocitoma anaplásico, ependimoma anaplásico) foram incluídos estudos que analisavam em conjunto gliomas do tipo IV e III do tipo observacionais comparativos. No caso de estudos que analisavam somente gliomas do tipo III foram incluídos estudos experimentais comparativos e não comparativos (série de casos) e observacionais comparativos. Gliomas mistos e secundários foram excluídos não foram considerados.  
No total, 135 estudos foram excluídos: 1) 51 estudos completos: 1.1) observacionais: cinco observacionais não comparativos; dois relatos de casos; três séries de casos e um caso-controle que analisaram populações e desfechos que não eram de interesse; 1.2) 13 séries de casos experimentais que analisaram glioma do tipo IV ou em conjunto III e IV; 1.3) ensaios clínicos randomizados: 1.3.1) três incluídos em revisões sistemáticas; 1.3.2) quatro tratavam de uma condição de não interesse; 1.3.3) dois não eram a intervenção de interesse; 1.3.4) quatro não tratavam do desfecho de interesse; 1.3.4)  quatro análises exploratórias que não tratavam dos objetivos principais dos estudos;  1.4) revisões sistemáticas: 1.4.1) três incluíram estudos que não eram randomizados; 1.4.2) um não atende aos requisitos essenciais de uma revisão sistemática; 1.4.3) três tratavam de uma condição de não interesse; 1.4.4) uma abordava uma intervenção de não interesse; 1.4.5) uma não tratava do desfecho de interesse; 1.4.6) uma continha os mesmo artigos, desfechos e qualidade comparáveis aos de uma publicação mais nova;  
2) 84 resumos de congressos: 2.1) um relato de casos e nove séries de casos experimentais do tipo IV ou em conjunto III e IV; 2.2) dois relatos de casos e nove séries de casos observacionais do tipo IV ou em conjunto III e IV; 2.3) ensaios clínicos: 2.3.1) seis incluídos em revisões sistemáticas; 2.3.2) 35 com artigos completos disponíveis; 2.3.3) cinco análises exploratórias que não tratavam dos objetivos principais dos estudos; 2.3.4) quatro que não abordavam os desfechos de interesse; 2.3.5) 13 que continham desfechos incompletos ou não relevantes.  
Em relação aos estudos que abordavam gliobastomas (IV), três revisões sistemáticas(177179)  e 12 ensaios clínicos randomizados de 18 referências foram incluídas (114, 157, 180-194), sendo cinco resumos de congressos (114, 186, 189, 192). Quanto aos estudos  
144  
que analisaram em conjunto gliomas do tipo III e IV, três estudos observacionais comparativos (195-197) foram incluídos. Em relação aos estudos que analisavam somente os gliomas do tipo III, devido à limitada evidência, cinco séries de casos experimentais (fase II, não comparativo) (198-202) foram incluídas, sendo três por busca manual (200-202).  Totalizando, 23 estudos de 29 referencias incluídas.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **<mark>3)Descrição dos estudos e seus resultados</mark>** -->
<mark>Os estudos incluídos serão apresentados de acordo com o grau de gliomas. Primeiramente serão descritas as características dos estudos, seguidas das características dos participantes, dos desfechos de eficácia e, por fim, dos desfechos de segurança. A descrição sumária dos estudos que abordaram o gliobastoma (grau IV) encontram-se nas Tabelas 37-52. Os estudos que analisaram em conjunto gliomas de grau III e IV estão apresentados nas Tabelas 53-56. A descrição dos estudos que analisaram somente os gliomas de grau III encontram nas Tabelas 57-60.</mark>  
145

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **1.1 Gliobastoma (IV): BEVA em monoterapia ou em combinação com radioterapia e temozolamida** -->
**Tabela 37 - Características dos estudos que compararam bevacizumabe monoterapia ou em combinação com radioterapia e temozolamida em gliomas de grau IV.**  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**<br>**(Tipo/ estágio**<br>**de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Lombardi**<br>**et al.**<br>**2017(177)**|Revisão<br>Sistemática<br>com meta-<br>análise<br>(Busca<br>realizada de<br>janeiro de<br>2006 até<br>janeiro de<br>2016)|Avaliar a eficácia de<br>anti-VEGF em<br>pacientes com<br>gliobastoma|Gliobastoma|7 ECR (4 na fase<br>II e 3 na fase III),<br>2449 participantes<br>(informações<br>referentes<br>somente do<br>BEVA)|**BEVA monoterapia**<br>**BEVA em**<br>**combinação com**<br>**outras drogas**<br>**citotóxicas**((RT+<br>TMZ); (IRI+ RT);<br>(RT+ IRI +TMZ);<br>LOM)|**Tratamentos**<br>**citotóxicos**((RT+<br>TMZ), LOM,<br>FOT)|**Alto risco de viés**,<br>restrição de data e<br>língua, não foi<br>avaliado o risco de<br>viés dos estudos<br>incluídos, lista de<br>excluídos não foi<br>fornecida)|
|**Khasraw**<br>**et al. 2014**<br>**(178)**|Revisão<br>Sistemática<br>com meta-<br>análise<br>(Busca<br>realizada de<br>2000 até|Avaliar a eficácia e<br>toxicidade do BEVA<br>e outros anti-VEGF<br>no tratamento de<br>gliomas de alto grau|Gliobastoma|1852<br>participantes, 4<br>ECR|BEVA monoterapia<br>ou em combinação<br>(desde que essa<br>combinação também<br>fosse fornecida no<br>grupo controle)<br>**(BEVA)**|Placebo, melhor<br>tratamento de<br>suporte ou<br>quimioterapia)<br>**(Controle)**|**Baixo Risco de**<br>**viés**|  
146  
**Número de População Desenho do estudos e Autor Objetivo (Tipo/ estágio Intervenção Controle Risco de Viés estudo participantes de glioma) incluídos** abril de 2014) Revisão **Alto risco de viés** Sistemática Avaliar a eficácia (não foi feito uma com metaclínica e segurança busca na literatura análise Recém **Tratamento Li et al.** do BEVA cinzenta, não foi (Busca diagnosticados 8 ECR, 2.185 **padrão** (RT+ **2016** comparado com **BEVA** avaliado o risco de realizada de com participantes TMZ); (IRI - **(179)** terapia padrão ou viés dos estudos janeiro de gliobastomas RT+TMZ; TMZ) outras incluídos, lista de 1966 até quimioterapias excluídos não agosto de fornecida) 2016) 921 participantes RT+TMZ+Placebo **Wick,et al 2016b** : - população da RT+TMZ+BEVA (6s - Detalhar a **Wick et** análise ITT (6s-concomitante); concomitante), pseudoprogressão e **al. 2016b;** ECR (BEVA: 458; TMZ+BEVA (6 TMZ+Placebo (6 pseudorespostas e os Recém **Saran et** (AVAglio), Placebo: 463) ciclos de 4s - ciclos de 4s - padrões de diagnosticados **Baixo Risco de al. 2016;** fase III manutenção) e manutenção) e crescimento dos com **viés Taphoorn** (Análise População da BEVA até PD Placebo até PD tumores gliobastomas **et al. 2015** exploratória) análise de (monoterapia) (monoterapia) **(180-182)** segurança: **Saran et al. 2016** : (BEVA: 461; **(BEVA+ RT/TMZ) (Placebo+** reportar em detalhe Placebo: 450) **RT/TMZ)**  
147  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**<br>**(Tipo/ estágio**<br>**de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|||os desfechos de<br>segurança||||||
|||**Taphoorn et al.**<br>**2015:**Avaliar a<br>QVRS||||||
|**Balana et**<br>**al. 2016**<br>**(183)**|ECR<br>(GENOM<br>009), fase II|Comparar a<br>monoterapia de TMZ<br>versus TMZ +<br>BEVA como terapia<br>neoadjuvante ou<br>concorrente|Gliobastomas<br>não ressecados.|102 participantes<br>randomizados,<br>mas somente 93<br>iniciou o<br>tratamento<br>(BEVA + TMZ:<br>48; TMZ: 45)<br>Imagens<br>disponíveis para<br>40 participantes:<br>BEVA + TMZ:<br>17; TMZ: 23)|TMZ/RT (Estágio<br>neoadjuvante: 85<br>mg/m2, 1-21 dias, 2<br>ciclos de 28 dias;<br>estágio concorrente:<br>radiação 60 Gy em 2<br>frações de Gy mais<br>TMZ 75 mg/m2/dia<br>por um máximo de<br>49 dias; estágio<br>concorrente foi<br>seguido de um<br>intervalo de 28 dias<br>e então o tratamento<br>com TMZ<br>neoadjuvante por 6<br>ciclos)**+**BEVA<br>(10mg/ kg nos dias 1<br>e 15 em cada ciclo|TMZ/RT<br>**(**tratamento<br>neoadjuvante: 85<br>mg/m2, 1-21 dias,<br>2 ciclos de 28 dias;<br>tratamento<br>concorrente:<br>radiação 60 Gy em<br>2 frações de Gy<br>mais TMZ 75<br>mg/m2/dia por um<br>máximo de 49<br>dias; estágio<br>concorrente foi<br>seguido de um<br>intervalo de 28<br>dias e então o<br>tratamento com<br>TMZ|<br>**Alto risco de viés,**<br>(Desfechos<br>incompletos:<br>análise foi por<br>intenção de tratar<br>modificada)|  
148  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**<br>**(Tipo/ estágio**<br>**de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
||||||adjuvante e nos dias<br>1,15 e 30 no|neoadjuvante por 6<br>ciclos)||
||||||tratamento<br>concorrente)|**(TMZ/RT)**||
||||||**(BEVA + TMZ/RT)**|||  
ECR: ensaio clínico randomizado; BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; VEGF: fator de crescimento endotelial vascular; PD: progressão da doença; s: semanas; QVRS: qualidade de vida relacionada à saúde; ITT: análise com intenção de tratar, ou seja, a população randomizada inicialmente.  
149  
**Tabela 38 - Características dos participantes dos estudos que compararam bevacizumabe monoterapia ou em combinação com radioterapia e temozolamida em gliomas de grau IV.**  
|**Autor, ano**|**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|**Idade**<br>**Controle**<br>**Mediana**<br>**(min-**<br>**max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
||BEVA|||||||||
|**Lombardi**<br>**et al. 2017**|BEVA +<br>drogas<br>citotóxicas|Tratamentos<br>citotóxicos|NR|NR|NR|NR|NR|NR|NR|
|**Khasraw**<br>**et al. 2014**|BEVA|Controle|NR|NR|NR|NR|NR|NR|NR|
|**Li et al.**<br>**2016**|BEVA|Tratamento<br>padrão|Variação: 62-<br>53.9|Variação:<br>60.9- 54.7|NR|BR|NR|NR|24-60 meses|  
150  
**Idade Idade n (%) Variáveis Controle n (%)sexo Variáveis clínicas Intervenção sexo clínicas Tempo de Autor, ano Intervenção Controle Mediana masculino relevantes Mediana masculino relevantes seguimento (minIntervenção Controle (min-max) Controle Intervenção max) KPS, n (%): KPS, n (%):** 50-80: 290 50-80:138 (30.7) (64.4) 90-100: 138 90-100: 313 (30.7) (68.0) **EP da OMS, EP da OMS, n(%): n(%):** 0: 231 (51.3) 0: 231 (50.1) 1-2: 219 (48.7) **Wick et al.** 1-2: 230 (49.9) **2016b; Uso de Saran et** NR **Uso de corticoides na al. 2016;** (BEVA+ (Placebo+ 290 57.0 (20–84)<sup>56.0 (18–</sup> 285 (61.8%) **corticoides na linha de base: Taphoorn** RT/TMZ) RT/TMZ) 79) (64.4%) Segurança:12.3- **linha de base:** Sim: 204 (45.3) **et al. 2015** 8.5 meses Sim: 189 (41.0) Não: 244 (54.2) Não: 270 (58.6) Não disponível: 2 **(AVAglio)** Não disponível: (0.4) 2 (0.4) **QVRS QVRS EORTC QLQEORTC QLQC30 média (DP): C30 média** 1) Status da saúde **(DP);** global: 67.4 **mediana:** (21.0); 66.7 1) Status da 2) FF: 81.4 (22.4);  
151  
|**Autor, ano**<br>**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|**Idade**<br>**Controle**<br>**Mediana**<br>**(min-**<br>**max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|
|||||||saúde global:<br>64.6 (22.4);<br>66.7<br>2) FF: 82.9<br>(20.1); 86.7<br>3) FS: 71.7<br>(29.0); 83.3<br>4) Disfunção<br>motora:16.8<br>(23.2); 11.1<br>5) Défice de<br>comunicação:<br>16.9 (24.8); 0.0|86.7<br>3) FS: 71.6 (28.6);<br>83.3<br>4) Disfunção<br>motora: 14.8<br>(20.8); 11.1<br>5) Défice de<br>comunicação:17.6<br>(25.2); 0.0||  
**EP ECOG n EP ECOG n Balana et (%): (%):** 62 (36– **al. 2016** 0: 8 (17.8) 0: 10 (20.8) Mínimo:18 BEVA + 62.9 (43–75) 75) 25 (55.6 TMZ/RT 31 (64.6 %) 1:24 (53.3) 1: 25 (52.1) meses TMZ/RT %) **(GENOM** 2: 13 (28.9) 2: 13 (27.1) **009)**  
152  
BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; min-max: mínimo e máximo; EP OMS: estado de performance da Organização Mundial da Saúde; EP ECOG: estado de performance do Grupo de Oncologia Cooperativa Oriental; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; QVRS: qualidade de vida relacionada à saúde; EORTC QLQ-C30: Questionário de qualidade de vida _the European Organisation for Research and Treatment of Cancer Quality of Life Questionnaire C30_ ; FF: funcionamento físico; FE: funcionamento emocional; FS: funcionamento social; TMS: tempo máximo de sobrevida, obtido no gráfico de Kaplan-Meier do estudo; NR: não reportado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 39 - Desfechos de eficácia dos estudos que compararam bevacizumabe monoterapia ou em combinação com radioterapia e temozolamida em gliomas de grau IV.** -->
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
|**Lombardi**<br>**et al. 2017**<br>(Revisão|BEVA<br>BEVA +<br>Trat.<br>Citotóxicos|Trat.<br>Citotóxicos|**SG**<br> HR: 1.09 (IC 95%:0.69,<br>1.70); 2 ECR, 164<br>participantes<br>HR: 0.96 (IC 95%:0.86,<br>1.06); 6 ECR, 2.352<br>participantes|0.7<br>0.3|**SLP**<br>HR: 0.63 (IC<br>95%:0.47, 0.85); I2:<br>NR; 2 ECR, 164<br>participantes<br>HR: 0.63 (IC<br>95%:0.52, 0.75); I2:<br>NR; 6 ECR, 2.352|0.003<br><0.001|NR|NR|
|Sistemática<br>com meta-<br>análise)|BEVA 1°<br>linha de<br>tratamento||HR: 0.98 (IC 95%:0.84,<br>1.13); 4 ECR, 1.848<br>participantes|0.7|participantes<br>HR: 0.70 (IC<br>95%:0.60, 0.81); I2:|<0.001|||
||BEVA 2°<br>linha de<br>tratamento||HR: 0.95 (IC 95%:0.77,<br>1.17); 4 ECR, 668<br>participantes|0.6|NR; 4 ECR, 1.848<br>participantes<br>HR: 0.52(IC|<0.001|||  
153  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||||95%:0.44, 0.62); I2:<br>NR; 4 ECR, 668<br>participantes||||
|**Khasraw**<br>**et al. 2014**<br>(Revisão<br>Sistemática<br>com meta-<br>análise)|BEVA|Controle|**SG (tempo da**<br>**randomização até a**<br>**morte)**<br>HR: 0.92 (IC 95% 0.83,<br>1.02), I2: 71%<br>(significativo); 4 ECR;<br>1852 participantes|0.12|**SLP (tempo da**<br>**randomização até a**<br>**morte até a morte por**<br>**qualquer causa ou**<br>**progressão da**<br>**doença)**<br>HR: 0.66 (IC 95%<br>0.59, 0.74), I2: 87%<br>(significativo); 4 ECR;<br>1712participantes|<0.00001|||
|**Li et al.**<br>**2016**<br>(Revisão<br>Sistemática|BEVA|Tratamento<br>padrão|**SG mediano:**HR: 1.01<br>(IC 95%:0.83, 1.23); I2:<br>66% (significativo); 5<br>ECR, 2012 participantes<br>**Taxa de SO aos 6**|0.95<br>0.01|**SLP mediano:**HR:<br>0.73 (IC 95%:0.62,<br>0.86); I2: 52%<br>(significativo); 5 ECR,<br>2012 participantes|0.0001<br><0.00001|NR|NR|
|com meta-<br>análise)|||**meses**: OR: 1.41 (IC<br>95%: 1.09, 1.84); I2:<br>12%;7 ECR;2152|0.03|**Taxa de SLP aos 6**<br>**meses**: OR: 3.33 (IC<br>95%: 2.73,4.06);I2:|<0.00001|||  
154  
|**Autor, ano**<br>**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|
||participantes<br>**Taxa de SO aos 12**<br>**meses:**OR: 1.23 (IC<br>95%: 1.02, 1.48); I2: 0%;<br>7 ECR; 2122<br>participantes<br>**Taxa de S0 aos 24**<br>**meses:**OR: 1.09 (IC<br>95%: 0.89, 1.35); I2:<br>44%; 6 ECR; 2068<br>participantes<br>**Taxa de S0 aos 36**<br>**meses:**OR: 0.57 (IC<br>95%: 0.32, 0.98); I2: 0%;<br>3 ECR; 1291<br>participantes|0.40<br>0.04|3%; 8 ECR; 2205<br>participantes<br>**Taxa de SLP aos 12**<br>**meses:**OR: 2.10 (IC<br>95%: 1.74, 2.54); I2:<br>0%; 7 ECR; 2117<br>participantes<br>**Taxa de SLP aos 24**<br>**meses:**OR: 0.85 (IC<br>95%: 0.53, 1.36); I2:<br>23%; 6 ECR; 2067<br>participantes<br>**Taxa de SLP aos 36**<br>**meses:**OR: 0.53 (IC<br>95%: 0.21, 1.34); I2:<br>NA; 1 ECR; 180<br>participantes|0.48<br>0.18|||  
155  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**SG mediana final:**<br>HR: 0.88 (IC 95%: 0.76,<br>1.02)<br>**SG de pacientes que**||**SLP final avaliada**<br>**pelos investigadores:**<br>||**QVRS**<br>**EORTC QLQ-C30**<br>1)Status de saúde global:<br>a)SLD: HR: 0.64 (IC 95%:<br>0.56, 0.74)<br>b)TD: HR: 0.76 (IC 95%:|<0.001<br>0.0041|
||||**tiveram mudanças do**<br>**padrão de tumor de não**<br>**difuso na linha de fase**|>0.05|HR: 0.64 (IC 95%:<br>0.55, 0.74)<br>|<0.05|0.63, 0.92)<br>2) FF:<br>a)SLD: HR: 0.70 (IC|<0.001<br>0.2394|
|**Wick,**|||**para difuso na**||**SLP final avaliada**||95%:0.61, 0.81)|<0.001|
|**2016b;**|||**progressão:**||**por empresa**<br>||b)TD: HR: 0.90 (IC 95%:|0.0113|
|**Saran et**<br>**al. 2016;**|BEVA|Plb|17.4 vs. 15 meses<br>HR: 0.85 (IC 95%: 0.51,||**independente:**<br>HR: 0.61 (IC 95%:|<0.05|0.75,1.08)<br>3) FS:|<0.001|
|**Taphoorn**<br>**et al. 2015**|(+<br>RT/TMZ)|(aceo+<br>RT/TMZ)|1.42)|0.5355|0.53, 0.71)||a)SLD:HR: 0.63 (IC<br>95%:0.55,  0.73)|0.2747|
||||**SG de pacientes com**||||b)TD: HR: 0.78 (IC|<0.001|
|**(AVAglio)**|||**tumor difuso na linha**<br>**de base:**<br>HR: 0.99 (IC 95% 0.82,<br>1.19)<br>**SG de pacientes com**|0.882<br>0.0303|**SLP de pacientes com**<br>**tumor difuso na linha**<br>**de base:**<br>HR: 0.69 (IC 95%<br>0.58, 0.83)<br>|<0.0001<br><0.0001|95%:0.64, 0.95)<br>4) Disfunção  motora:<br>a)SLD: HR: 0.67 (IC<br>95%:0.58,  0.78)<br>b)TD: HR: 0.87 (IC<br>95%:0.68, 1.11)|0.0295<br><0.05|
||||**tumor não difuso na**<br>**linha de base:**<br>HR: 0.76 (IC 95% 0.59,<br>0.98)||**SLP de pacientes com**<br>**tumor não difuso na**<br>**linha de base:**<br>HR: 0.57 (IC 95%<br>0.45, 0.73)||5) Défice de comunicação:<br>a)SLD: HR: 0.67 (IC<br>95%:0.58,  0.77)<br>b)TD: HR: 0.80 (IC<br>95%:0.66,0.98)|<0.05|  
156  
|**Autor, ano**<br>**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|
||||||**KPS:**<br>HR: 0.65 (IC 95%:0.56,<br>0.75)|<0.05|
||||||**Tempo para iniciação de**<br>**corticoides em pacientes**<br>**não tomavam corticoides**<br>**na linha de base:**<br>HR: 0.71 (IC 95%:0.57,<br>0.88)||
||||||**Tempo para**<br>**descontinuação de**<br>**corticoides em pacientes**<br>**que tomavam corticoides**<br>**na linha de base:**<br>HR: 0.69 (IC 95%:0.55,<br>0.87)||
||||||**Padrões do Tumor**<br>**1) Tumor focal**<br>**% Pacientes sem**<br>**mudanças da linha de base**<br>**(BEVA+ RT/TMZ) vs.**<br>**Placebo+ RT/TMZ), n/N**<br>**total(%):**||  
157  
|**Autor, ano**<br>**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**<br>**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|
|||||a) Tumor local na linha de<br>base e tumor local na<br>progressão: 198/299<br>(66.2%) vs. 215/333<br>(64.6%)||
|||||b) Tumor multifocal na<br>linha de base e tumor<br>multifocal na progressão:<br>57/299 (19.1%) vs.63/333<br>(18.9%)<br>**% Pacientes com**<br>**mudanças da linha de base**<br>**(BEVA+ RT/TMZ) vs.**<br>**Placebo+ RT/TMZ), n/N**<br>**total (%):**<br>a) Tumor local na linha de<br>base e tumor multifocal na<br>progressão: 19/299 (6.4) vs.<br>30/333 (9.0)||
|||||b) Tumor local na linha de<br>base e tumor distante na<br>progressão: 11/299 (3.7)<br>vs.15/333 (4.5)||
|||||c)Tumor multifocal na||  
158  
|**Autor, ano**<br>**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**<br>**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|
|||||linha de base e tumor local<br>na progressão: 9/299 (3.01)<br>vs. 2/333 (2.4)||
|||||d) Tumor multifocal na<br>linha de base e tumor<br>distante na progressão:<br>4/299 (1.3) vs. 2/333 (2.4)||
|||||e) Tumor sem padrão na<br>linha de base e tumor local<br>na progressão: 1/299 (0.3)<br>vs. 0/0 (0.0)||
|||||**2) Infiltração tumoral**<br>**% Pacientes sem**<br>**mudanças da linha de base**<br>**(BEVA+ RT/TMZ) vs.**<br>**Placebo+ RT/TMZ), n/N**<br>**total (%):**<br>a) Tumor não difuso na<br>linha de base e tumor não<br>difuso na progressão:<br>64/299 (21.4) vs. 104/333<br>(31.2)||
|||||b)Tumor difuso na linha de||  
159  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||||||base e tumor difuso na<br>progressão: 197/299 (65.9)<br>vs. 194/333 (58.3)<br>**% Pacientes com**<br>**mudanças da linha de base**<br>**(BEVA+ RT/TMZ) vs.**<br>**Placebo+ RT/TMZ), n/N**<br>**total (%):**<br>a) Tumor não difuso na<br>linha de base e tumor difuso<br>na progressão: 36/299<br>(12.0) vs. 34/333 (10.2)<br>b) Tumor difuso na linha de<br>base e tumor não difuso na<br>progressão: 2/299 (0.7) vs.<br>1/333 (0.3)||
|**Balana et**<br>**al. 2016**<br>**(GENOM**<br>**009)**|TMZ|BEVA +<br>TMZ|**SG mediana:**<br>BEVA + TMZ: 4.8 meses<br>(IC 95 %: 4.0, 5.6)<br>TMZ: 10.6 meses (IC 95<br>%: 6.9, 14.3)<br>HR: 0.68 (IC 95 %: 0.44,<br>1.04)<br>**Taxa de SO em A) 1**|0.07<br>NR|**SLP mediano:**<br>BEVA + TMZ: 4.8<br>meses (IC 95 %: 4.0,<br>5.6)<br>TMZ: 2.2 meses (IC 95<br>%: 2.0, 2.5)<br>HR: 0.70 (IC 95 %:<br>0.46,1.07)<br>**Análise multivariada**|0.10|**(TMZ + BEVA vs. TMZ)**<br>**Taxa de resposta (critério**<br>**RANO), n (%); OR (IC**<br>**95%):**<br>**1) Resposta completa:**0<br>vs. 0<br>**2) Resposta parcial:**11<br>(22.9) vs. 3 (6.7);<br>OR: 4.2 (1.1, 16.1)<br>**3) Doença estável:**18|0.04<br>0.03|  
160  
|**Autor, ano**<br>**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|
||**ano; B) 2 anos e C) 3**<br>**anos:**<br>BEVA + TMZ: A)<br>48.9%; B) 20.5%; C)10.9<br>%<br>TMZ: A) 29.6; B) 8.9; C)<br>4.4 %<br>**Análise multivariada**<br>**identificou apenas TMZ**<br>**+ BEVA como**<br>**marcador independente**<br>**de SG:**<br>HR: 1.68 (IC 95 %:1.07,<br>2.63)|0.02|**identificou apenas**<br>**TMZ + BEVA como**<br>**marcador**<br>**independente de SLP:**<br>HR: 1.58 (IC 95%: 1.0,<br>2.5)|0.05|(37.5) vs. 8 (17.8);<br>OR: 2.8 (1.1, 7.1)<br>**4) Benefício clínico (item**<br>**2+3):**29 (60.4) vs.11<br>(24.5);<br>OR: 4.7 (1.9, 11.5)<br>**3) PD:**15 (31.3) vs. 32<br>(71.1)<br>OR: 5.4 (2.2,13.2)|<0.001<br><0.001|  
SLP: sobrevida livre de progressão; SG: sobrevida global; SO: taxa de sobrevivência; BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; min-max: mínimo e máximo; QVRS: qualidade de vida relacionada à saúde; EORTC QLQ-C30: Questionário de qualidade de vida _the European Organisation for Research and Treatment of Cancer Quality of Life Questionnaire C30_ ; FF: funcionamento físico; FE: funcionamento emocional; FS: funcionamento social; SLD: sobrevida livre de deterioração; TD: tempo de deterioração; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; critério RANO: _Response Assessment in Neuro-Oncology;_ NR: não reportado; OR: odds ratio ou razão de chances; RR: risco relativo: HR: hazard ratio; IC 95%: intervalo de confiança de 95%; I2: estatística I2 para a avaliação da heterogeneidade dos estudos incluídos nas meta-análises.  
161  
**Tabela 40 - Desfechos de segurança dos estudos que compararam bevacizumabe monoterapia ou em combinação com radioterapia e temozolamida em gliomas de grau IV.**  
|**Eventos**<br>**Adversos**|**Li**<br>(Revisão Sis<br><br>**BEVA**|**et al. 2016**<br>temática com M<br>análise)<br>**Tratamento**<br>**Padrão**|eta-<br>**Valor**<br>**p**|**Wick, 2016b; Sar**<br>**(BEVA+**<br>**RT/TMZ)**|**an et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al. 2**<br>**BEVA + TMZ**|**016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|Isquemia<br>Cerebral|n (total): 7 de<br>127<br>OR:3.21 (IC<br>26.71),|n (total): 1<br>de 56<br>95% 0.39,<br>2 ECR|0.28|NR||NR|NR||NR|
||n (total): 9 de<br>848|n (total): 7<br>de 750||Todos os graus n<br>(%)♦: 15 (3.3) vs.<br>9 (2.0); (morte*:<br>0);|1) Todos os<br>graus n (%)♦: 9<br>(2.0); (morte*:<br>1);||n (%)▲: A) EN<br>grau 3- 4: 2 (4.2)|n (%)▲: A)<br>EN grau 3-<br>4:.0||
|Hemorragia<br>Cerebral|OR: 2.30 (IC<br>5.54),4|95% 0.96,<br>ECR|0.06|Grau ≥3♦: 9 (2.0)<br>(morte*: 0)<br>RR:1.85 (0.|2) Grau ≥3♦: 4<br>(0.9); (morte*:<br>1)<br>57; 6.02)|>0.05|EN grau 5: 2<br>(4.2)|EN grau 5: 0|0.24|
|Sangramento/<br>hemorragias<br>(outros)|NR||NR|Todos os graus n<br>(%)♦: 171 (37.1)<br>(morte*: 1<br>(0.6%);|Todos os graus<br>n (%)♦: 88<br>(19.6%);<br>(morte*:1<br>(1.1%));||NR||NR|  
162  
|**Eventos**<br>**Adversos**|**Li**<br>(Revisão Si<br>**BEVA**|**et al. 2016**<br>stemática com M<br>análise)<br>**Tratamento**<br>**Padrão**|eta-<br>**Valor**<br>**p**|**Wick, 2016b; Sa**<br>**(BEVA+**<br>**RT/TMZ)**|**ran et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||||Grau ≥3♦: 6<br>(1.3%) (morte*:<br>1 (16.7%)|Grau ≥3♦: 4<br>(0.9%);<br>(morte*: 1<br>(25.0%)|||||
|||||RR: 1.23 (0<br>Epistaxe<br>Todos os graus n<br>(%):<br>98(21.3%)|.35, 4.37)<br>Epistaxe<br>Todos os graus<br>n (%):  22<br>(4.9%)|>0.05||||
|||||Arterial:<br>Todos os graus n<br>(%)♦: 27 (5.9) vs.<br>7 (1.6); (morte*:<br>1 (3.7));|Arterial:<br>1) Todos os<br>graus n (%)♦:7<br>(1.6); (morte*:<br>1 (14.3));|||n (%)▲: A)||
|Eventos<br>tromboembólicos|n (total): 56<br>de 805|n (total): 55<br>de 766||Grau ≥3 ♦: 23<br>(5.0); (morte*: 1<br>(4.3))<br>Venoso:<br>1) Todos os<br>graus n (%)♦: 38<br>(8.2) vs. 43 (9.6);<br>(morte*: 3 (7.9)|Grau ≥3 ♦: 6<br>(1.3); (morte*:<br>1 (16.7))<br>Venoso:<br>1) Todos os<br>graus n (%)♦:<br>38 (8.2) vs. 43<br>(9.6); (morte*:||n (%)▲: A) EN<br>grau 3- 4: 2 (4.2)<br>EC grau 3- 4: 0|<br>EN grau 3- 4:<br>3 (6.6);<br>EC grau 3- 4:<br>3 (6.7)|NR|  
163  
|**Eventos**<br>**Adversos**|**Li**<br>(Revisão Sist<br>a<br>**BEVA**|**et al. 2016**<br>emática com M<br>nálise)<br>**Tratamento**<br>**Padrão**|eta-<br>**Valor**<br>**p**|**Wick, 2016b; Sa**<br>**(BEVA+**<br>**RT/TMZ)**|**ran et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||||vs. 1 (2.3));<br>2) Grau ≥3 ♦: 35<br>(7.6); (morte*: 3<br>(8.6))|3 (7.9) vs. 1<br>(2.3));<br>2) Grau ≥3 ♦:<br>36 (8.0);<br>(morte*: 1<br>(2.8))|||||
||OR: 0.97 (IC<br>1.42),4|95% 0.66,<br>ECR|0.86|Venoso: RR: 0.7|9 (0.50, 1.26)|>0.05||||
|Diarréia|n (total): 5 de<br>154<br>OR: 6.14 (IC<br>112.49),|n (total): 0<br>de 83<br>95% 0.34,<br>3 ECR|0.22|n (%): 96 (20.8)|n (%): 70 (15.6)|NR|NR||NR|
|Constipação|NR||NR|n (%): 178 (38.6)|<br>n (%):137<br>(30.4)|NR|n (%)<br>Grau 3:0<br>Grau 4: 0|n (%)<br>Grau 3: 0<br>Grau 4: 0|NR|
|Anemia|n (total): 9 de<br>344|n (total): 7<br>de 317||NR||NR|n (%) EN grau 3-<br>4:1 (2.1)|n (%) EN grau<br>3- 4: 1 (2.1)|NR|  
164  
|**Eventos**<br>**Adversos**|**Li et al. 2016**<br>(Revisão Sistemática com M<br>análise)<br>**BEVA**<br>**Tratamento**<br>**Padrão**|eta-<br>**Valor**<br>**p**|**Wick, 2016b; Sa**<br>**(BEVA+**<br>**RT/TMZ)**|**ran et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|
|Leucopenia<br>Neutropenia|OR: 1.19 (IC 95% 0.44,<br>3.23),3 ECR<br>NR<br>n (total): 31 de<br>344<br>n (total): 19<br>de 316<br>OR: 1.55 (IC 95% 0.86,<br>2.80),3 ECR|0.73<br>NR<br>0.15|n (%): 56 (12.1)<br>n (%): 66 (14.3)|n (%):41 (9.1)<br>n (%):55 (12.2)|NR<br>NR|n (%) EN grau 3-<br>4:1 (2.1)<br>EC grau 3- 4: 1<br>(2.1)<br>n (%) Febril: EN<br>grau 3- 4: 1 (2.1)<br>n (%) EN grau 3-<br>4: 1 (2.1)<br>EC grau 3- 4: 2<br>(4.2)|n (%) EN grau<br>3- 4: 2 (4.4);<br>EC grau 3- 4:<br>0<br> <br>n (%) Febril:<br>EN grau 3- 4:<br>2 (4.4)<br>n (%) EN grau<br>3- 4:  3 (6.7);<br>EC grau 3- 4:<br>0;|NR<br>NR|
|Trombocitopenia|NR|NR|n (%): 157 (34.1)|n (%):123<br>(27.3)|NR|n (%) EN grau 3-<br>4: 1 (2.1)<br>EC grau 3- 4: 3<br>(6.1)|n (%) EN grau<br>3- 4: 5 (11.1);<br>EC grau 3- 4:<br>0;|NR|  
165  
|**Eventos**<br>**Adversos**|**Li**<br>(Revisão Si<br>**BEVA**|**et al. 2016**<br>stemática com M<br>análise)<br>**Tratamento**<br>**Padrão**|eta-<br>**Valor**<br>**p**|**Wick, 2016b; Sa**<br>**(BEVA+**<br>**RT/TMZ)**|**ran et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|Linfopenia/<br>Linfocitopenia|N|R|NR|N|R|NR|n (%) EN grau 3-<br>4: 1 (2.1)<br>EC grau 3- 4: 8<br>(16.7)|n (%) EN grau<br>3- 4: 1 (2.1);<br>EC grau 3- 4:<br>3(6.7);|NR|
|Náusea e vômito|n (total): 11<br>de 287<br>OR: 2.03 (I<br>5.93),|n (total): 5<br>de 260<br>C 95% 0.70,<br>2 ECR|0.19|1) Náusea n (%):<br>223 (48.4)<br>2) Vômito: 149<br>(32.3)|1) Náusea n<br>(%): 191 (42.4);<br>2) Vômito: 102<br>(22.7)|<br>NR|n (%) EN grau 3-<br>4: 1 (2.1)|n (%) EN grau<br>3- 4: vs. 0;|NR|
|Fadiga|n (total): 48<br>de 330<br>OR: 1.72 (I<br>2.96),|n (total): 21<br>de 233<br>C 95% 1.00,<br>2 ECR|0.05|n (%): 191 (41.4)|<br>n (%):178<br>(39.6)|NR|n (%) EN grau 3-<br>4: 2 (4.2)<br>EC grau 3- 4: 3<br>(6.7)|n (%) A) EN<br>grau 3- 4: 1<br>(2.2);<br>EC grau 3- 4:<br>0;|NR|
||n (total): 71|||n (%): 178 (38.6)|<br>n (%): 51 (11.3)||n (%) ▲: EN: 2|n (%) ▲:||
|Hipertensão|de 848|n (total): 12<br>de 739||♦ Todos os graus<br>n (%)♦: 181|♦ Todos os<br>graus n (%)♦:57||(4.2)<br>EC: 1 (2.1)|EN:.0;<br>B) EC:. 0|NR|  
166  
|**Eventos**<br>**Adversos**|**Li et al. 2016**<br>(Revisão Sistemática com<br>análise)<br>**BEVA**<br>**Tratamento**<br>**Padrão**|Meta-<br>**Valor**<br>**p**|**Wick, 2016b; Sa**<br>**(BEVA+**<br>**RT/TMZ)**|**ran et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|
||OR: 5.54 (IC 95% 2.98,<br>10.29),4 ECR|<0.000<br>01|(39.3); (morte*:<br>0);<br>Grau ≥3 ♦: 52<br>(11.3) (morte*:<br>0)<br>RR: 4.64 (2|(12.7); (morte*:<br>0);<br>Grau ≥3 ♦: 10<br>(2.2); (morte*:<br>0)<br>.36, 9.13)|<0.05||||
|Cicatrização com<br>complicações|NR||Todos os graus n<br>(%)♦: 32 (6.9);<br>(morte*: 1 (3.1));<br>Grau ≥3♦: 15<br>(3.3); (morte*: 1<br>(6.7))|Todos os graus<br>n (%)♦: 21<br>(4.7); (morte*:);<br>Grau ≥3♦: 7<br>(1.6); (morte*:<br>0)||NR||NR|
||||RR: 1.77 (0|.72, 4.33)|>0.05||||
|Infecções|n (total): 16 de<br>154<br>n (total): 4<br>de 83<br>OR: 2.29 (IC 95% 0.74,<br>7.09),3 ECR|0.15|Nasofaringite n<br>(%): 63 (13.7);<br>Infecção do trato<br>urinário: 50<br>(10.8)<br>RR grau ≥3: 1.3|Nasofaringite n<br>(%):26 (5.8);<br>Infecção do<br>trato urinário:<br>29 (6.4)<br>2 (0.87, 2.01)|>0.05|n (%) EN grau 3-<br>4: 5 (10.4)|n (%) EN grau<br>3- 4: (6.6);|NR|  
167  
|**Eventos**<br>**Adversos**|**Li**<br>(Revisão Si<br>**BEVA**|**et al. 2016**<br>stemática com<br>análise)<br>**Tratamento**<br>**Padrão**|Meta-<br>**Valor**<br>**p**|**Wick, 2016b; Sa**<br>**(BEVA+**<br>**RT/TMZ)**|**ran et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||||n (%): 72 (15.6)|n (%): 72 (15.6)<br>vs. 19 (4.2)|||||
|Proteinúria|n (total): 33<br>de 431|n (total): 0<br>de 560||♦ Todos os graus<br>n (%)♦: 72<br>(15.6); (morte*:<br>0);|♦ a) Todos os<br>graus n (%)♦:<br>19 (4.2);<br>(morte*: 0);||n (%)▲ EN grau<br>3- 4: 0|n (%)▲ EN<br>grau 3- 4: 0|NR|
||OR: 94.24 (I<br>1542.53|C 95% 5.76,<br>),2 ECR|<0.001|Grau ≥3♦: 25<br>(5.4); (morte*: 0)|b) Grau ≥3♦: 0;<br>(morte*: 0)|||||
|Perfuração<br>Intestinal|N|R|NR|Todos os graus n<br>(%)♦: 8 (1.7);<br>(morte*: 2 (0.4)<br>Grau ≥3♦: 5<br>(1.1); (morte*: 2<br>(0.4))<br>RR: 4.11(0|Todos os graus<br>n (%)♦:  2 (0.4);<br>(morte*: 3<br>(0.7));<br>Grau ≥3♦: 1<br>(0.2); (morte*:<br>3 (0.7))<br>.48,35.17)|>0.05||n (%)▲ A)<br>EN: 1 (2.1)<br>vs. 0; B) EC:<br>1 (2.1) vs. 0|NR|  
168  
|**Eventos**<br>**Adversos**|<br>(Revisão<br>**BEVA**|**Li et al. 2016**<br>Sistemática com<br>análise)<br>**Tratamento**<br>**Padrão**|Meta-<br>**Valor**<br>**p**|**Wick, 2016b; Sa**<br>**(BEVA+**<br>**RT/TMZ)**|**ran et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||||Todos os graus l<br>n (%): 454 (98.5)|<br>Todos os graus<br>l n (%): 432<br>(96.0);|||||
|||NR|NR|Todos os graus♦<br>n (%): 349 (75.7)<br>Grau 3 n (%)♦:<br>150 (32.5) vs. 71<br>(15.8)<br>|<br>Todos os<br>graus♦ n (%):<br>204 (45.3);<br>Grau 3 n (%)♦:<br>71 (15.8)||n (%)<br>EN: 39 (81.3)|n (%)<br>EN: 29 (64.4);|<br>0.06;|
|Quaisquer EA||||Grau ≥3 n (%):<br>308 (66.8) vs.<br>231 (51.3);|Grau ≥3 n (%):<br>231 (51.3);||EC: 23 (47.9)|EC: 15 (33.3)|0.15|
|||||Grau ≥3 ▲: 150<br>(32.5)|Grau ≥3 ▲: 71<br>(15.8);|||||
|||||Grau 5: 20 (4.3)<br>Grau<br>RR: 3.18 (1<br>Grau<br>RR: 1.3(0.|Grau 5: 12<br>(2.7);<br>≥3:<br>.30; 7.81)<br>5:<br>63,2.65)|<0.05||||  
169  
|**Eventos**<br>**Adversos**|<br>(Revisão<br>**BEVA**|**Li et al. 2016**<br>Sistemática com M<br>análise)<br>**Tratamento**<br>**Padrão**|eta-<br>**Valor**<br>**p**|**Wick, 2016b; Sar**<br>**(BEVA+**<br>**RT/TMZ)**|**an et al. 2016 (A**<br>**(Placebo+**<br>**RT/TMZ)**|**VAglio)**<br>**Valor p**|**Balana et al.**<br>**BEVA + TMZ**|**2016 (GENOM**<br>**TMZ**|**009)**<br>**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||>0.05||||
|EA<br>severos/sérios|Gráfico não<br>com|permitiu reportar<br>precisão|0.033|n (%): 179 (38.8)<br>RR: 1.29(1.|n (%): 115<br>(25.6)<br>02,1.63)|<0.05||NR|NR|
|||||a) Descontin<br>uo<br>qualquer<br>tratament|a) Descont<br>inuo<br>qualquer<br>tratamen|||||
|A)<br>Descontinuação<br>B) interrupção ou<br>ajuste devido à<br>EA sérios|<br> <br>NR||NR|o n (%):<br>122<br>(26.5)<br>b) Descontin<br>uo<br>BEVA/<br>Placebo:<br>114<br>(24.7)|to n<br>(%): 61<br>(13.6);<br>b) Descont<br>inuo<br>BEVA/<br>Placebo:<br>46<br>(10.2)|NR|n:9|n:.6|NR|
|Morte devido ao<br>tratamento||NR|NR|Especificado em c<br>EA|ada coluna do<br>|NA|n (%): EN: 4<br>(8.3)|n (%): EN:<br>vs.0|NR|  
EA: eventos adversos; ECR: ensaios clínicos randomizados; BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; ♦ EA com especial interesse para o BEVA; EA: estágio neoadjuvante; EC: estágio concorrente; ▲ EA relacionados ao BEVA; OR: odds ratio ou razão de chances; RR: risco relativo; IC 95%: intervalo de confiança de 95%; NR: não reportado.  
170

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **1.2 Gliobastoma (IV): Bevacizumabe com irinotecano ou bevacizumabe com temozolamida** -->
**Tabela 41 - Características dos estudos que compararam bevacizumabe com irinotecano ou bevacizumabe com temozolamida em gliomas de grau IV.**  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de**<br>**glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Gilbert et**<br>**al. 2016**<br>**(184)**|ECR (RTOG<br>0625) fase II,<br>não<br>comparativo|Avaliar a eficácia<br>e segurança dos<br>regimes BEVA +<br>TMZ e BEVA +<br>IRI|Gliobastoma ou<br>gliosarcoma<br>recorrente ou<br>progressivo após<br>quimioradioterapia<br>padrão|123 participantes<br>(BEVA + TMZ:<br>63; BEVA + IRI:<br>60; (BEVA +<br>TMZ: 59; BEVA<br>+ IRI:57;<br>população por<br>intenção de tratar<br>modificada)|BEVA (10mg/ kg a<br>cada 2s)<br>TMZ (75-100<br>mg/m2 nos dias 1 a<br>21 dias a cada ciclo<br>de 28 dias)<br>**(BEVA + TMZ)**|BEVA (10mg/<br>kg a cada 2s)<br>IRI (125 mg/m2a<br>cada 2s)<br>**(BEVA + IRI)**|**Alto risco de viés**<br>(Sigilo de alocação<br>não reportado; não<br>cegamentos dos<br>profissionais,<br>participantes ou<br>investigadores;<br>desfechos<br>incompletos:<br>análise não foi por<br>intenção de tratar<br>(modificada);|
|**Hofland et**<br>**al. 2014**<br>**(185)**|ECR, fase II|Avaliar a eficácia<br>do BEVA<br>neoadjuvante<br>combinado com<br>IRI (BEVA + IRI)<br>versus BEVA +<br>TMZ antes,<br>durantes e depois<br>de radioterapia|Recém<br>diagnosticados<br>com gliobastomas|63 participantes,<br>sendo essa a<br>população por<br>protocolo (BEVA<br>+ IRI: 31; BEVA<br>+ TMZ: 32)|BEVA (10mg/ kg a<br>cada 2s, antes,<br>durante e depois da<br>radioterapia) + IRI<br>(A cada 2s antes,<br>durante e depois da<br>radioterapia, 340<br>mg/m2 e 125 mg/<br>m2para aqueles|BEVA (10mg/<br>kg a cada 2s,<br>antes, durante e<br>depois da<br>radioterapia) +<br>TMZ (200<br>mg/m2<br>diariamente por<br>5 dias e então 23|**Alto risco de viés**<br>(Não cegamento<br>dos participantes;<br>desfechos<br>incompletos:<br>análise com a<br>população por<br>protocolo)|  
171  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de**<br>**glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
||||||que utilizavam e<br>não utilizavam<br>drogas<br>antiepilépticas<br>indutoras<br>enzimáticas,<br>respectivamente).<br>(**BEVA + IRI)**|dias sem ser<br>administrado,<br>antes e depois da<br>radioterapia.<br>Durante a<br>radioterapia foi<br>dado uma dose<br>de 75 mg/m2<br>diariamente).||

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **<u>(BEVA + TMZ)</u>** -->
|**Bonnetain**<br>**et al.**<br>**2015;**<br>**Chauffert**|ECR<br>(TEMAVIR<br>study), fase<br>II não|Avaliar o BEVA e<br>IRI como<br>tratamento<br>neoadjuvante e<br>adjuvante<br>combinado com a<br>quimioradioterapia|Gliobastoma não<br>ressecados|120 participantes<br>((BEVA+IRI/<br>RT+TMZ): 60;|Tratamento<br>neoadjuvante:<br>BEVA (10mg/ kg)<br>+IRI (125 mg/m2) a<br>cada 2s por 4 ciclos<br>antes da RT<br>(60Gy),<br>concomitante oral<br>TMZ (75|Concomitante<br>TMZ (75<br>mg/m2/dia)<br>durante RT e<br>150-200mg/m2<br>por 5 dias a cada|**Alto risco de viés**<br>(Sigilo de alocação<br>não reportados; não<br>foi relatado se os<br>participantes,<br>profissionais ou<br>investigadores<br>foram mascarados)|
|---|---|---|---|---|---|---|---|
|**et al. 2014**<br>**(157, 186)**|,<br>comparativo|(TMZ).<br>**Bonnetain et al.**<br>**2015**: avaliar a<br>QVRS||(RT/TMZ: 60))|<br>mg/m2/dia) e<br>BEVA a cada 2s;<br>tratamento<br>adjuvante: BEVA +<br>IRI a cada 2s por 6<br>meses|28 dias por 6<br>meses<br>**(RT/TMZ)**|**Bonnetain et al.**<br>**2015**: resumo de<br>congresso<br>(informações<br>importantes|  
172  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de**<br>**glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
||||||**(BEVA+IRI/**<br>**RT+TMZ)**||insuficientes para<br>julgamento)|
|**Friedman**<br>**et al. 2009**<br>**(187)**|ECR, fase II<br>(BRAIN<br>study), não<br>comparativo|Avaliar a eficácia<br>do BEVA, sozinho<br>ou em combinação<br>com IRI|Gliobastoma<br>recorrente após<br>primeira linha de<br>terapia RT/TMZ|167 participantes<br>(BEVA: 85;<br>BEVA + IRI:82)|BEVA (10mg/ kg a<br>cada 2s) + IRI (a<br>cada 2s, 340 mg/m2<br>e 125 mg/ m2 para<br>aqueles que<br>utilizavam e não<br>utilizavam drogas<br>antiepilépticas<br>indutoras<br>enzimáticas,<br>respectivamente).<br>(**BEVA + IRI)**|BEVA (10mg/<br>kg a cada 2s)<br>**(BEVA)**|**Alto risco de viés**<br>(Sigilo de alocação<br>não reportados; não<br>cegamentos dos<br>participantes;<br>desfechos<br>incompletos: não<br>realizou análises<br>estatísticas para<br>comparação da<br>eficácia)|  
ECR: ensaio clínico randomizado; BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; IRI: irinotecano; PD: progressão da doença; s: semanas; QVRS: qualidade de vida relacionada à saúde;  
173  
**Tabela 42 - Características dos participantes dos estudos que compararam bevacizumabe com irinotecano ou bevacizumabe com temozolamida em gliomas de grau IV.**  
|**Autor, ano**|**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|<br>**Idade**<br>**Controle**<br>**Mediana**<br>**(min-max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|**Gilbert et**<br>**al. 2016**|BEVA +<br>TMZ|BEVA +<br>IRI|58 (24–82)|55 (23–78)|34 (57 %)|34 (57 %)|KPS n (%):<br>90–100: 30 (50 %)<br>70–80: 30 (50 %)|KPS n (%):<br>90–100: 26 (46<br>%)<br>70–80: 31 (54<br>%)|NR|
||||||||EP ECOG (n):|EP ECOG (n):||
|**Hofland et**<br>**al. 2014**|BEVA + IRI|BEVA +<br>TMZ|59 (36 – 77)|62 (30 – 73)|18 (58%)|21<br>(65.62%)|0: 20<br>1: 10<br>2: 1|0: 13<br>1: 17<br>2: 2|31 meses (19<br>– 43)|
|**Bonnetain**|||||||KPS, n (%):|KPS, n (%):||
|**et al. 2015;**|||||||50%: 8 (13.5);|50%: 4 (6.6);||
|**Chauffert**<br>**et al. 2014**|(BEVA+IRI/<br>RT+TMZ)|(RT/TMZ)|60.2 (43–69)|60.2 (43–<br>69)|34 (56.7)|37 (61.7)|60%: 4 (6.8)<br>70%: 11 (18.6);<br>80%: 17 (28.8)|60%: 10 (16.7)<br>70%: 16 (26.7) ;<br>80%: 13 (21.7)|NR|
|**(TEMAVIR**<br>**study**|||||||90%: 10 (17.0);<br>100%: 9(15.3)|90%: 14 (23.3);<br>100%: 3(5.0)||
|**Friedman**<br>**et al. 2009**<br>**(BRAIN**<br>**study)**|BEVA + IRI|BEVA|57 (23-79)|54 (23-78)|69.5%|68.2%|KPS (%):<br>90–100: 37.8%<br>70–80: 62.2%|KPS (%):<br>90–100: 44.7%<br>70–80: 55.3%|NR|  
174  
BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; IRI: irinotecano; EP ECOG: estado de performance do Grupo de Oncologia Cooperativa Oriental; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; min-max: mínimo e máximo; TMS: tempo máximo de sobrevida, obtido no gráfico de Kaplan-Meier do estudo; NR: não reportado.  
**Tabela 43 - Desfechos de eficácia dos estudos que compararam bevacizumabe com irinotecano ou bevacizumabe com temozolamida em gliomas de grau IV.**  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global**<br>**(SG) / taxa de**<br>**Sobrevivência(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|<br>**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
|**Gilbert**<br>**et**<br>**al. 2016**|<br>BEVA<br>+<br>TMZ|BEVA +<br>TMZ|<br>**SG**<br>**mediana**<br>BEVA + TMZ: 9.4|NR|**SLP**<br>**mediana:**<br>BEVA + TMZ: 4.7 meses|NR|**Taxa de resposta (critério**<br>**MacDonald)**|NR|
||||meses (IC 95 %: 6.7,||(IC 95 %: 3.5, 6.3)||**Completa**<br>**ou**<br>**parcial:**||
||||10.7)||BEVA + IRI: 4.1 meses||BEVA + TMZ: 19% de 59||
||||BEVA + IRI:  7.7||(IC 95 %: 3.4, 6.1)||BEVA + IRI: 27.8% de 57||
||||meses (IC 95 %: 6.7,||||Não<br>avaliados:<br>5||
||||9.1)||**Taxa de SLP aos 6 meses**||**Completa:**||
||||||BEVA + TMZ: 39 %<br>(23/59)||BEVA + TMZ: 2 (3 %)<br>BEVA + IRI: 2 (4 %)||
||||||BEVA + IRI: 38.6 %||**Parcial:**||
||||||(22/57)||BEVA + TMZ: 9 (16 %)||
||||||Pré-determinada taxa de<br>SLP aos 6 meses para<br>determinar eficácia: ≥<br>35%||BEVA + IRI: 13 (24 %)||  
175  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobre**<br>**(SG**<br>**Sobrev**|**vida global**<br>**) / taxa de**<br>**ivência(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|<br>**Ou**|**tros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Hofland et**|<br>BEVA + IRI|BEVA +|<br>**SG**|**mediana:**|NR|**SLP**<br>**mediana:**||**Taxa de**|**resposta (critério**||
|**al. 2014**||TMZ|BEVA|+ IRI: 15.1||BEVA + IRI: 7.3 meses|0.79*|**MacDo**|**nald modificado)**||
||||meses|(IC<br>95%:||(IC<br>95%:||**Comple**|**ta:**||
||||9.6,|20.6)||5.0,<br>9.3)||BEVA|+<br>IRI:<br>0||
||||BEVA|+ TMZ: 11.8||BEVA + TMZ: 7.7 meses||BEVA|+<br>TMZ:<br>0||
||||meses|(IC<br>95%:||(IC<br>95%:||**Não**|**avaliados**||
||||8.2, 15.3|)||5.1,<br>10.2)||**(excluíd**<br>**Parcial**|**os):**<br>**6**<br>**:**|<br>0.56*|
|||||||**Taxa de** **SLP aos A) 6**||BEVA|+ IRI: 23% (IC||
|||||||**meses e B) 12 meses:**||95%:|9,<br>44%)||
|||||||BEVA + IRI: A) 52%; B)||BEVA|+ TMZ: 32% (IC|<br>0.57*|
|||||||10%||95%:|17,<br>51%)||
|||||||BEVA + TMZ: A) 53%;||**Respost**|**a**<br>**marginal:**||
|||||||B) 6%||BEVA|+ IRI: 27% (IC||
|||||||||95%:|12,<br>48%)|<br>0.19*|
|||||||||BEVA|+ TMZ: 35.5% (IC||
|||||||||95%|CI<br>19,<br>55%)||
|||||||||**Parcial**<br>**margin**|<br>**+**<br>**Resposta**<br>**al:**|<br>0.73*|
|||||||||BEVA|+ IRI: 50% (IC||
|||||||||95%:<br>BEVA|29,<br>70%)<br>+ TMZ: 68% (IC|<br>|
|||||||||95%:|49,<br>83%)||  
176  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global**<br>**(SG) / taxa de**<br>**Sobrevivência(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|<br>**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
||||||||**PD:**<br>BEVA + IRI: 19% (IC<br>95%:<br>8,<br>38%)<br>BEVA + TMZ: 13% (IC<br>95%: 4, 29%)|<br> <br>|
|**Bonnetain**<br>**et al. 2015;**<br>**Chauffert**<br>**et al. 2014**|(BEVA+IRI/<br>RT+TMZ)|(RT/TMZ)|**SG**<br>**(curvas**<br>**se**<br>**sobrepõem):**<br>BEVA+IRI/<br>RT+TMZ: 11 meses<br>RT+TMZ :11,1 (9,0;|NR|**SLP**<br>**mediana:**<br>BEVA+IRI/<br>RT+TMZ:<br>7.1 meses (IC 95%: 5.5,<br>9.2)<br>RT+TMZ: 5.2 meses (IC||**QVRS**<br>**EORTC**<br>**QLQ-C30**<br>BEVA+IRI/<br>RT+TMZ<br>maior TUDD para 10/15<br>dimensões em relação ao|<br> <br> <br>|
|**(TEMAVIR**<br>**study)**|||15) meses||95%:<br>4.3,<br>6.8)<br>**Taxa de SLP aos 6 meses**<br>**(estimativa):**<br>BEVA+IRI/<br>RT+TMZ:<br>61.7% (IC 95%: (48.2,<br>72.6)<br>RT+TMZ: 41.7% (c 29.2,<br>53.7)<br>HR: 0.82 (IC95%: 0.56,<br>1.19) (incluído na meta-<br>análise de Lombardi et<br>al.)|>0.05|grupo<br>RT/TMZ<br>**Disfunção**<br>**motora,**<br>**mediana:**<br>BEVA+IRI/ RT+TMZ: 4.6<br>meses (IC 95%: 3.2, 9.4)<br>RT/TMZ: 3.3 meses (IC<br>95%:<br>2.8,<br>6.7)<br>HR: 0.70 (IC 95%: 0.45,<br>1.08)<br>**Défice**<br>**sensorial**<br>**está**<br>**associado**<br>**com**<br>**menor**<br>**TUDD**<br>**da**<br>**dimensão**<br>**fraqueza das pernas ou**<br>**morte:**<br>HR: 2.74(IC 95%: 1.41,|<br> <br> <br> <br> <br> <br> <br> <br>>0.05<br><0.05|  
177  
|**Autor, ano**<br>**Intervenção**<br>**Controle**|**Sobrevida global**<br>**(SG) / taxa de**<br>**Sobrevivência(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**<br>**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|
|||||5.30).||
|||||**QLQ-**<br>**BN20**<br>BEVA+IRI/<br>RT+TMZ<br>maior TUDD para 10/11<br>dimensões em relação ao<br>grupo RT/TMZ||  
178  
|**Autor, ano**|**Intervenção**<br>**Controle**|**Sobrevida global**<br>**(SG) / taxa de**<br>**Sobrevivência(SO)**|**Valor**<br>**p**<br>**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**<br>**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|
|**Friedman**<br>**et al. 2009**|<br>BEVA + IRI BEVA|**SG**<br>**mediana:**<br>BEVA + IRI: 8.7<br>meses (IC 95.0%: 7.8,|**Fase**<br>**III:**<br>**SLP**<br>**mediana:**<br>BEVA + IRI: 5.6 meses|<br>**Taxa de resposta (critério**<br>**de avaliação de resposta**<br>**da**<br>**OMS)**|<br> <br>|
|**(BRAIN**<br>**study)**||10.9)<br>BEVA: 9.2 meses (IC|(IC 95.0%: 4.4, 6.2)<br>BEVA: 4.2 meses (IC|**Objetivo (completa ou**<br>**parcial):**||
|||95.0%:<br>8.2,<br>10.7)|95.0%:<br>2.9,<br>5.8)|<br>BEVA + IRI: 37.8% (IC<br>97.5%:26.5%,<br>50.8%)|<br> <br>0.25<br>(respondes|
|||**SG mediana em a)**<br>**primeira recidiva e**<br>**b) segunda recidiva:**<br>BEVA + IRI: a) 8.7<br>meses; b) 7.0 meses<br>BEVA: a) 9.1 meses;<br>b) 9.2 meses|**SLP mediana aos 6**<br>**meses em a) primeira**<br>**recidiva e b) segunda**<br>**recidiva:**<br>BEVA + IRI: a) 5.5<br>meses;<br>b)5.6<br>meses.<br>BEVA: a) 4.4 meses; b)|BEVA:  28.2% (IC 97.5%:<br>18.5,<br>40.3)<br>**Objetivo (completa ou**<br>**parcial) em a) primeira**<br>**recidiva e b) segunda**<br>**recidiva:**<br>BEVA + IRI: a) 39.4%;|<br> <br> <br> <br> <br>vs.<br>Não<br>respondentes<br>do<br>grupo<br>BEVA<br>+<br>IRI)<br>0.36<br>respondes|
||||3.1<br>meses<br>**Taxa de SLP aos 6 meses**<br>BEVA + IRI: 50.3% (IC|b)31.3%<br>BEVA:  a) 31.9%; b)12.5%<br>**Completa:**<br>BEVA + IRI: 2 (2.4%)|<br>vs.<br>Não<br>respondentes<br>do<br>grupo<br>BEVA|
||||97.5%:<br>36.8%,<br>3.9%)|BEVA:<br>1<br>(1.2%)||
||||BEVA:<br>42.6%<br>(IC<br>97.5%: 29.6%, 55.5%)<br>**Taxa de SLP aos 6 meses**<br>**em a) primeira recidiva**<br>**e b) segunda recidiva:**<br>BEVA + IRI: a) 49%; b)<br>57.1%|**Parcial:**<br>BEVA + IRI: 29 (35.4%)<br>BEVA: 23 (27.1%)||  
179  
|**Autor, ano**<br>**Intervenção**<br>**Controle**|**Sobrevida global**<br>**(SG) / taxa de**<br>**Sobrevivência(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**<br>**Valor p**|
|---|---|---|---|---|---|
||||BEVA: a) 46.4%; b<br>27.8%|)||  
*Valor de p Intervenção vs. Controle*; SLP: sobrevida livre de progressão; SG: sobrevida global; SO: taxa de sobrevivência; BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; IRI: irinotecano; QVRS: qualidade de vida relacionada à saúde; OMS: Organização Mundial de Saúde; EORTC QLQ-C30: Questionário de qualidade de vida _the European Organisation for Research and Treatment of Cancer Quality of Life Questionnaire C30_ ; QLQ- BN20: EORTC modulo de cancêr no cérebro; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; critério RANO: _Response Assessment in Neuro-Oncology;_ TUDD: Tempo até a pontuação de deteriorização de QVRS definitiva, sendo a diferença clinicamente significante de pelo menos 10 pontos, incluindo ou não morte; PD: progressão da doença; HR: hazard ratio; IC 95%: intervalo de confiança de 95%; IC 97.5%:  intervalo de confiança de 97.5%; NR: não reportado.  
180

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 44 - Desfechos de segurança dos estudos que compararam bevacizumabe com irinotecano ou bevacizumabe com temozolamida em gliomas de grau IV.** -->
|**Eventos**<br>**Adversos**|**Gilbert**<br>**BEVA+**<br>**TMZ**|**et al. 2016**<br>**BEVA+I**<br>**RI**|<br>**Val**<br>**or p**|**Hoflan**<br>**BEVA+IRI**|**d et al. 2014**<br>**BEVA+ TMZ**|**Val**<br>**or p**|**Bonneta**<br>**Chauffe**<br>**(TEMA**<br>**(BEVA+IRI**<br>**/ RT+**<br>**TMZ)**|**in et al. 2015;**<br>**rt et al. 2014**<br>**VIR study)**<br>**RT + TMZ**|<br>**Val**<br>**or p**|**Friedma**<br>**(BRA**<br>**BEVA+ IRI**|**n et al. 2009**<br>**IN study)**<br>**BEVA**|<br>**Val**<br>**or p**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Hematológi<br>co|Grau 2 (n):<br>5<br>Grau 3 (n):<br>21<br>Grau 4 (n):<br>9<br>Grau 5 (n):<br>0|Grau 2<br>(n): 14<br>Grau 3<br>(n): 13<br>Grau 4<br>(n): 3<br>Grau 5<br>(n): 0|NR|Grau I/II (n):<br>Granulocitope<br>nia: 0<br>Linfocitopenia<br>: 2<br>Trombocitope<br>nia: 0<br>Grau III/IV<br>(n):<br>Granulocitope<br>nia: 1<br>Linfocitopenia<br>: 2<br>Trombocitope<br>nia: 0<br>Graus III/IV<br>(Fase<br>neoadjuvante)<br>: 3|Grau I/II (n):<br>Granulocitope<br>nia: 0<br>Linfocitopenia<br>: 1<br>Trombocitope<br>nia: 4<br>Grau III/IV<br>(n):<br>Granulocitope<br>nia: 3<br>Linfocitopenia<br>: 2<br>Trombocitope<br>nia:3<br>Graus III/IV<br>(Fase<br>neoadjuvante)<br>: 8|NR|Grau III-V<br>(n/N):<br>Neutropenia:<br>4/57<br>Neutropenia<br>febril: 1/57<br>Linfocitopen<br>ia: 7/57<br>Trombocitop<br>enia: 2/57<br>Aplasia:<br>1/57<br>Anemia:<br>0/57|Grau III-V<br>(n/N):<br>Neutropenia:<br>5/56<br>Neutropenia<br>febril: 0/56<br>Linfocitopen<br>ia: 7/56<br>Trombocitop<br>enia: 8/56<br>Aplasia:<br>0/56<br>Anemia:<br>0/56|NR|Leucopenia:<br>Grau ≥3 n<br>(%): 5 (6.3<br>%)<br>Neutropenia:<br>Grau ≥3 n<br>(%): 6 (7.6<br>%)<br>Linfocitopen<br>ia: Grau ≥3 n<br>(%): 6<br>(7.6%)<br>Cicatrização<br>com<br>complicaçõe<br>s:  A) Todos<br>os graus: 2<br>(2.5)|<br>Leucopenia<br>: Grau ≥3 n<br>(%): 0<br>(0%)<br>b)<br>Neutropeni<br>a: Grau ≥3<br>n (%): 2<br>(2.4%)<br>Linfocitope<br>nia: Grau<br>≥3 n (%): 2<br>(2.4%)<br>Cicatrizaçã<br>o com<br>complicaçõ<br>es: Todos|NR|  
181  
|**Eventos**|**Gilber**|**t et al. 2016**||**Hofla**|**nd et al. 2014**||**Bonneta**<br>**Chauff**<br>**(TEM**|**in et al. 2015;**<br>**ert et al. 2014**<br>**AVIR study)**|**Friedma**<br>**(BRA**|**n et al. 2009**<br>**IN study)**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|**BEVA+**<br>**TMZ**|**BEVA+I**<br>**RI**|**Val**<br>**or p**|**BEVA+IRI**|**BEVA+ TMZ**|**Val**<br>**or p**|**(BEVA+IRI**<br>**/ RT+**<br>**TMZ)**|**RT + TMZ**<br>**Val**<br>**or p**|**BEVA+ IRI**|**BEVA**|**Val**<br>**or p**|
|||||Graus III/IV|Graus III/IV||||Grau ≥3: 1|os graus: 5||
|||||(Todos os 6<br>ciclos):  8<br>Grau 5 (fatal):<br>0|<br>(Todos os 6<br>ciclos):  22<br>Grau 5 (fatal):<br>1||||(1.3 %)|(6.0%);<br>Grau ≥3: 2<br>(2.4%)||  
|Cardíaco|Grau 2 (n):<br>0<br>Grau 3 (n):<br>4|Grau 2<br>(n): 4<br>Grau 3<br>(n): 3|NR|NR|NR<br>N|R|NR|Hipertensão:<br>Todos os<br>graus: 21<br>(26.6)<br>Grau ≥3: 1|<br>Hipertensã<br>o:<br>Todos os<br>graus: 30<br>(35.7%);|NR|
|---|---|---|---|---|---|---|---|---|---|---|
||Grau 4 (n):<br>1|Grau 4<br>(n): 0||||||(1.3%)|Grau ≥3: 7<br>(8.3%)||
|Vascular|Trombose/<br>Coagulopat<br>ia<br>Grau 2 (n):|Trombose<br>/<br>Coagulop<br>atia|NR|NR|NR<br>Grau III-V<br>(n/N):<br>Hipertensão:<br>0/57|Grau III-V<br>(n/N):<br>Hipertensão:<br>0/56||Venoso<br>Todos os<br>graus: 8<br>101|Venoso<br>Todos os<br>graus: 3<br>36%|NR|
||0|Grau 2|||Embolismo|b)||(.);|(.);||  
182  
|**Eventos**<br>**Adversos**|**Gilbert**<br>**BEVA**|**et al. 2016**<br>**BEVAI**|<br>**Vl**|**Hofland et al. 2014**|**Vl**|**Bonneta**<br>**Chauffe**<br>**(TEM**<br>**(BEVA+IRI**|**in et al. 2015;**<br>**rt et al. 2014**<br>**AVIR study)**|<br>**Vl**|**Friedma**<br>**(BRA**|**n et al. 200**<br>**IN study)**|**9**<br>**Vl**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||**+**<br>**TMZ**|**+**<br>**RI**|**a**<br>**or p**|**BEVA+IRI**<br>**BEVA+ TMZ**|**a**<br>**or p**|**/ RT+**<br>**TMZ)**|**RT + TMZ**|**a**<br>**or p**|**BEVA+ IRI**|**BEVA**|**a**<br>**or p**|
||Grau 3 (n):<br>3<br>Grau 4 (n):<br>2|(n): 2<br>Grau 3<br>(n): 3<br>Grau 4<br>(n): 4||||pulmonar/ve<br>noso: 5/57<br>Isquemia<br>arterial: 1/57|Embolismo<br>pulmonar/ve<br>noso: 5/57<br>vs. 0/56<br>c) Isquemia<br>arterial: 1/57<br>vs. 1/56||Grau ≥3: 7<br>(8.9 %)<br>Arterial<br>Todos os<br>graus: 5<br>(6.3);<br>Grau ≥3: 2<br>(2.5 %)|Grau ≥3: 3<br>(3.6%)<br>Arterial<br>Todos os<br>graus: 4<br>(4.8%);<br>Grau ≥3: 2<br>(2.4%)|<br> <br>|
||Grau 2 (n):<br>20|Grau 2<br>(n): 14||||||||||
|Sintomas<br>constitucio<br>nais|Grau 3 (n):<br>7<br>Grau 4 (n):<br>0|Grau 3<br>(n): 10<br>Grau 4<br>(n): 1|NR|NR|NR|N|R|NR|N|R|NR|
|Pele|Grau 2 (n):<br>1<br>Grau 3 (n):<br>1|Grau 2<br>(n): 4<br>Grau 3<br>(n): 0|NR|NR|NR|N|R|NR|N|R|NR|  
183  
|**Eventos**<br>**Adversos**|**Gilbert**<br>**BEVA**|**et al. 2016**<br>**BEVAI**|<br>**Vl**|**Hofland et al. 2014**|**Vl**|**Bonneta**<br>**Chauffe**<br>**(TEM**<br>**(BEVA+IRI**|**in et al. 2015;**<br>**rt et al. 2014**<br>**AVIR study)**|<br>**Vl**|**Friedma**<br>**(BRA**|**n et al. 2009**<br>**IN study)**|<br>**Vl**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||**+**<br>**TMZ**|**+**<br>**RI**|**a**<br>**or p**|**BEVA+IRI**<br>**BEVA+ TMZ**|**a**<br>**or p**|**/ RT+**<br>**TMZ)**|**RT + TMZ**|**a**<br>**or p**|**BEVA+ IRI**|**BEVA**|**a**<br>**or p**|
||1) Grau 2<br>(n): 16 vs.<br>20|||||Grau III-V<br>(n/N):<br>Estomatite:<br>1/57|Grau III-V<br>(n/N):<br>Estomatite:<br>0/56||Diarreia<br>Grau ≥3 n<br>(%): 4<br>(5.1%)|Diarreia<br>Grau ≥3 n<br>(%): 4<br>(5.1%) vs.<br>1 (1.2%)||
|Digestivo/<br>Gastrointes<br>tinal|2) Grau 3<br>(n): 2 vs. 5<br>3) Grau 4<br>(n): 2 vs. 0||NR|NR|NR|Diarreia:<br>4/57<br>Perfuração<br>digestiva/<br>Infecções:<br>3/57 (1<br>morte)|Diarreia:<br>0/56<br>Perfuração<br>digestiva/<br>Infecções:<br>2/56 (1<br>morte)|NR|Perfuração<br>Intestinal:<br>n (%)▲:<br>Quaisquer<br>graus: 1<br>(2%) vs. 0;<br>Grau ≥3: 1<br>(2%)|Perfuração<br>Intestinal:<br>n (%)▲:<br>Quaisquer<br>graus: 0<br>(0%); Grau<br>≥3: 0 (0%|NR|
||Outros:<br>Grau 2 (n):<br>7|Outros:<br>Grau 2<br>(n): 2||||Intracranial:|Intracranial:||Cerebral<br>Todos os<br>graus: 21|Cerebral<br>Todos os<br>graus: 30||
|Hemorragi<br>a|Grau 3 (n):<br>4|Grau 3<br>(n): 1|NR|NR|NR|Grau III-V<br>(n/N): 3/57<br>(3 mortes)|Grau III-V<br>(n/N): 1/56<br>(1 morte)|NR|(26.6)<br>Grau ≥3: 1<br>(1.3 %)|(35.7%);<br>Grau ≥3: 0<br>(0%)|NR|
||Grau 4 (n):<br>0|Grau 4<br>(n): 0|||||||Outros|Outros||  
184  
|**Eventos**<br>**Adversos**|**Gilbert**<br>|**et al. 2016**<br>|<br>|**Hoflan**|**d et al. 2014**||**Bonneta**<br>**Chauffe**<br>**(TEM**<br>**(BEVA+IRI**|**in et al. 2015;**<br>**rt et al. 2014**<br>**AVIR study)**|<br> <br>|**Friedma**<br>**(BRA**|**n et al. 2009**<br>**IN study)**|<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**BEVA+**<br>**TMZ**|**BEVA+I**<br>**RI**|**Val**<br>**or p**|**BEVA+IRI**|**BEVA+ TMZ**|**Val**<br>**or p**|**/ RT+**<br>**TMZ)**|**RT + TMZ**|**Val**<br>**or p**|**BEVA+ IRI**|**BEVA**|**Val**<br>**or p**|
||Grau 5 (n):<br>0|Grau 5<br>(n): 1||||||||Todos os<br>graus: 21<br>(26.6)<br>Grau ≥3: 1<br>(1.3 %)|Todos os<br>graus: 30<br>(35.7%);<br>Grau ≥3: 0||
|Infecções|Grau 2 (n):<br>9<br>Grau 3 (n):<br>3<br>Grau 4 (n):<br>1|Grau 2<br>(n): 7<br>Grau 3<br>(n): 5<br>Grau 4<br>(n): 1|NR|N|R|NR|Grau III-V<br>(n/N): 5/57|Grau III-V<br>(n/N): 2/56|NR|N|R|NR|
||Grau 5 (n):<br>0|Grau 5<br>(n): 1|||||||||||
|Metabólico<br>/<br>Eletrólito|Grau 2 (n):<br>17|Grau 2<br>(n): 11<br>Grau 3|NR|N|R|NR|N|R|NR|Proteinúria:<br>n (%)▲:<br>Quaisquer|Proteinúria:<br>n (%)▲:<br>Quaisquer<br>graus: 4|<br>NR|  
185  
|**Eventos**|**Gilber**|**t et al. 2016**||**Hofland et al. 2014**||**Bonnetai**<br>**Chauffer**<br>**(TEMA**|**n et al. 2015;**<br>**t et al. 2014**<br>**VIR study)**||**Friedma**<br>**(BRA**|**n et al. 2009**<br>**IN study)**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|**BEVA+**|**BEVA+I**|**Val**||**Val**|**(BEVA+IRI**||**Val**||**Val**|
||<br>**TMZ**|**RI**|**or p**|**BEVA+IRI**<br>**BEVA+ TMZ**|**or p**|<br>**/ RT+**<br>**TMZ)**|**RT + TMZ**|**or p**|<br>**BEVA+ IRI**|**BEVA**<br><br>**or p**|
||Grau 3 (n):<br>5<br>Grau 4 (n):<br>1|(n): 8<br>Grau 4<br>(n): 0|||||||graus: 7<br>(12%);<br>Grau ≥3: 0|(6%); Grau<br>≥3: 2 (3%)|
||<br>Grau 2 (n):<br>6|Grau 2<br>(n): 7|||||||||
|Neurológic<br>o|Grau 3 (n):<br>6|Grau 3<br>(n): 2|NR|NR|NR|NR||NR|NR|<br>NR|
||Grau 4 (n):<br>0|Grau 4<br>(n): 1|||||||||
|Dor|Grau 2 (n):<br>7<br>Grau 3 (n):<br>3|Grau 2<br>(n): 6<br>Grau 3<br>(n): 0|NR|NR|NR|NR||NR|NR|<br>NR|
|Respiratóri<br>o|Grau 2 (n):<br>2<br>Grau 3 (n):<br>1|Grau 2<br>(n): 3<br>Grau 3<br>(n): 1|NR|NR|NR|NR||NR|NR|<br>NR|  
186  
|**Eventos**|**Gilber**|**t et al. 2016**||**Hoflan**|**d et al. 2014**||**Bonneta**<br>**Chauff**<br>**(TEM**|**in et al. 2015;**<br>**ert et al. 2014**<br>**AVIR study)**||**Friedma**<br>**(BRA**|**n et al. 2009**<br>**IN study)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||||**(BEVA+IRI**||||||
||**BEVA+**<br>**TMZ**|**BEVA+I**<br>**RI**|**Val**<br>**or p**|**BEVA+IRI**|**BEVA+ TMZ**|**Val**<br>**or p**|**/ RT+**<br>**TMZ)**|**RT + TMZ**|**Val**<br>**or p**|**BEVA+ IRI**|**BEVA**|**Val**<br>**or p**|
||**Piores:**|**Piores:**||Grau I/II (n):<br>Náusea: 13<br>Vômito: 3<br>Diarreia: 8<br>Alopecia: 7|Grau I/II (n):<br>Náusea: 12<br>Vômito: 8<br>Diarreia: 6<br>Alopecia: 0||||||||
||Grau 2, n<br>(%): 21<br>(35%)|Grau 2, n<br>(%): 23<br>(40%)||Hipertensão:<br>10<br>Fadiga: 23|Hipertensão:1<br>2<br>Fadiga: 22||||||||
|Toxicidade|Grau 3, n<br>(%): 23|Grau 3, n<br>(%):17||Grau III/IV<br>(n):<br>|Grau III/IV<br>(n):<br>|||||Fadiga:<br>Grau ≥3 n|Fadiga:<br>Grau ≥3 n||
|não-<br>hematológi<br>ca|(38%)<br>Grau 4, n<br>(%): 5|(30%)<br>Grau 4, n<br>(%): 5|NR|Náusea: 0<br>Vômito: 0<br>Diarreia: 0<br>Alopecia: 0|Náusea: 0<br>Vômito: 0<br>Diarreia: 0<br>Alopecia: 0|NR|N|R|NR|<br>(%): 7<br>(8.9%)|<br>(%):3<br>(3.6%)|NR|
||(8%)<br>Grau 5, n<br>(%): 1<br>(2%)|(9%)<br>Grau 5, n<br>(%): 3<br>(5%)||Hipertensão: 0<br>Fadiga: 0<br>Graus I/II<br>(Todos os 6<br>ciclos):  135<br>Graus III/IV<br>(Todos os 6<br>ciclos): 11|<br>Hipertensão: 3<br>Fadiga: 2<br>Graus I/II<br>(Todos os 6<br>ciclos): 128<br>Graus III/IV<br>(Todos os 6<br>ciclos): 12||||||||  
187  
|**Eventos**|**Gilber**|**t et al. 2016**||**Hoflan**|**d et al. 2014**||**Bonnet**<br>**Chauff**<br>**(TEM**|**ain et al. 2015;**<br>**ert et al. 2014**<br>**AVIR study)**||**Friedma**<br>**(BRA**|**n et al. 2009**<br>**IN study)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||||||**(BEVA+IRI**||||||
||**BEVA+**<br>**TMZ**|**BEVA+I**<br>**RI**|**Val**<br>**or p**|**BEVA+IRI**|**BEVA+ TMZ**|**Val**<br>**or p**|**/ RT+**<br>**TMZ)**|**RT + TMZ**|**Val**<br>**or p**|**BEVA+ IRI**|**BEVA**|**Val**<br>**or p**|
||Grau 2, n<br>(%): 9<br>(15%)|Grau 2, n<br>(%): 20<br>(35%)|||||||||||
|Pior|Grau 3, n<br>(%): 33<br>(55%)|Grau 3, n<br>(%):<br>22(39%)||||||||Quaisquer<br>|Quaisquer<br>||
|<br>toxicidade<br>global|Grau 4, n<br>(%): 11<br>(18%)|Grau 4, n<br>(%): 7<br>(12%)|NR|N|R|NR|N|R|NR|EA:  Grau<br>≥3:  37<br>(64%)|EA:  Grau<br>≥3: 36<br>(58%)|NR|
||Grau 5<br>(fatal), n<br>(%): 1<br>(2%)|Grau 5<br>(fatal), n<br>(%): 3<br>(5%)|||||||||||
|Descontinu|||||||||||||
|ação<br>devido ao|n: 5|n: 0|NR|N|R|NR|%: 8.3|%: 5.0|NR|n: 5|n: 4|NR|
|tratamento|||||||||||||
|Morte<br>devido ao<br>tratamento|n: 1|n: 3|NR|n: 0|n: 1|NR|Especifica<br>coluna|do em cada<br>do EA|NR|n (%): 2<br>(3%) vs. 0<br>(0%)|NR||  
188  
EA: eventos adversos; BEVA: bevacizumabe; RT: radioterapia; TMZ: temozolamida; ▲ EA relacionados ao BEVA; OR: odds ratio ou razão de chances; RR: risco relativo; IC 95%: intervalo de confiança de 95%; NR: não reportado.  
**1.3 Gliobastoma (IV): Bevacizumabe em combinação com lomustina**  
**Tabela 45 - Características dos estudos que compararam bevacizumabe em combinação com lomustina em gliomas de grau IV.**  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**<br>**(Tipo/ estágio**<br>**de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Weathers**<br>**et al. 2016**<br>**(188)**|ECR, fase II|Avaliar<br>a<br>eficácia da dose<br>baixa de BEVA<br>em combinação<br>com<br>LOM<br>comparado com<br>dose padrão de<br>BEVA.|Gliobastoma<br>recorrente<br>após primeira<br>linha<br>de<br>terapia<br>RT/TMZ|71<br>participantes<br>(BEVA+<br>LOM:<br>35; BEVA: 36)|Dose baixa de BEVA (5<br>mg/kg a cada 3s) + LOM<br>(inicial de 90 mg/m2 a<br>cada 6s, mas depois foi<br>reduzido para 75 mg/m2<br>devido<br>a<br>eventos<br>adversos, LOM foi dada<br>no dia 3 de cada ciclo de<br>6s)<br>**(BEVA + LOM)**|Monoterapia com<br>dose padrão de<br>BEVA (10mg/ kg<br>a<br>cada<br>2s)<br>**(BEVA)**|<br> <br> <br> <br>**Alto risco de viés**<br>(Sigilo de alocação<br>não reportado; não<br>foi<br>calculado<br>o<br>tamanho<br>e<br>a<br>representividade da<br>amostra; Desfechos<br>incompletos: análise<br>não foi por intenção<br>de<br>tratar<br>(modificada))|
|**Wick**<br>**et**<br>**al. 2016;**<br>**Taphoorn**|ECR, fase II e<br>III<br>(EORTC<br>26101),|**Wick**<br>**et**<br>**al.**<br>**2016:**Investigar<br>se a combinação|Gliobastoma<br>progressivo<br>após<br>terapia|Fase<br>III:<br>437<br>participantes<br>(BEVA + LOM:|**Fase III:**BEVA (10mg/<br>kg a cada 2s) + LOM (90<br>mg/m2 a cada 6s)|**Fase III:**LOM<br>(110 mg/m2 a<br>cada 6s)|<br> <br>**Alto risco de viés**<br>(Resumo<br>de<br>congresso:|
|**et**<br>**al.**<br>**2016;**|resumos<br>de<br>congressos|BEVA + LOM<br>melhora a SG|padrão<br>RT/TMZ com|288; LOM: 149)|**(BEVA**<br>**+**<br>**LOM)**|**(LOM)**|informações<br>importantes|
|**Wick**<br>**et**||comparado com|pelo menos 3||||insuficientes<br>para|
|**al. 2016c**||a<br>monoterapia|meses após a|Fase II: 1) LOM +|**Fase II**: 1) LOM (90||julgamento);|
|**(114, 189)**||de LOM na fase<br>III do estudo.|parte<br>concomitante|BEVA ◊ escolha):<br>70|mg/m2 a cada 6s) +<br>BEVA(10 mg/kga cada|||  
189  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**<br>**(Tipo/ estágio**<br>**de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**<br>**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|
|||**Taphoorn et al.**<br>**2016:**Avaliar a<br>QVRS<br>**Wick**<br>**et**<br>**al.**<br>**2016c**: Avaliar a<br>sequência<br>de<br>tratamento ideal<br>(agente único vs<br>sequencial<br>versus<br>combinação) da<br>LOM e BEVA<br>na fase II do<br>estudo.||2) LOM, ◊ BEVA:<br>73<br>3)<br>(BEVA,<br>◊<br>LOM+BEVA): 70<br>4)<br>(LOM,<br>◊<br>escolha): 36<br>2s) até na progressão,<br>com<br>subsequente<br>tratamento conservador<br>de acordo com a escolha<br>do investigador**(LOM +**<br>**BEVA**<br>**◊**<br>**escolha)**;<br>2) LOM 110 mg/m2<br>(máx. 200 mg) a cada 6s<br>e na progressão transitar<br>para BEVA a cada 2s)<br>**(LOM,**<br>**◊**<br>**BEVA)**;<br>3) BEVA a cada 2s e na<br>progressão<br>adicionar<br>LOM 90 mg/m2 (máx.<br>160 mg) a cada 6s e<br>continuar<br>BEVA<br>**(BEVA,**<br>**◊**<br>**LOM+BEVA);**<br>4) Monoterapia de LOM<br>110 mg/m2 (máx. 200<br>mg) a cada 6s e na<br>progressão de acordo<br>com<br>a<br>escolha<br>do<br>investigador**(LOM, ◊**<br>**escolha)**;||**Wick et al. 2016c**:<br>desfechos<br>incompletos, análise<br>com a população por<br>protocolo na fase II|  
190  
|**Autor**|**Desenho d**<br>**estudo**|**o**<br>**Objetivo**||**População**<br>**(Tipo/ estágio**<br>**de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**<br>**Inte**|**rvenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|---|
|**Taal et al.**<br>**2014 (190)**|ECR (BEL<br>trial), fase<br>(Incluído<br>RS<br>Lombardi<br>al. 2017)|OB<br>II<br>na<br>de<br>et<br>Avaliar<br>atividade<br> <br>BEVA<br>e<br>monoterapia<br>em combinaç<br>com LOM|a<br>do<br>m<br>ou<br>ão|<br> <br> <br> <br> <br>Primeira<br>recorrência de<br>gliobastoma<br>após<br>tratamento<br>com RT/TMZ|1) BEVA/ LOM<br>110: 8 (análise de<br>segurança)<br>2)<br>BEVA/LOM<br>90:<br>47<br>3)<br>LOM:<br>47<br>4) BEVA: 50<br>**1)**BEVA<br>cada 2s)<br>mg/m2 (a<br>de<br>**(BEVA +**<br>**2)**BEVA<br>cada<br>2s)<br>90mg/m2<br>máx.<br> <br>**(BEVA +**|(10mg/ kg a<br>+ LOM 110<br>cada 6s, máx.<br>200mg)<br>**LOM 110)**<br>(10mg/ kg a<br> <br>+<br>LOM<br>(a cada 6s,<br>de<br>160mg<br>**LOM 90)**|**3)**<br>LOM<br>110<br>mg/m2 (a cada<br>6s)<br>**(LOM)**;<br>**4)**BEVA (10mg/<br>kg a cada 2s)<br>**(BEVA)**|<br> <br> <br> <br>**Alto risco de viés**<br>(Método de sigilo de<br>alocação<br>não<br>reportados;<br>não<br>cegamentos<br>dos<br>investigadores;<br>desfechos<br>incompletos: análise<br>não foi por intenção<br>de<br>tratar<br>(modificada).|  
ECR: ensaio clínico randomizado; BEVA: bevacizumabe; LOM: lomustina; RT: radioterapia; TMZ: temozolamida; SG: sobrevida global; s: semanas; máx.: máximo.  
191

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 46 - Características dos participantes dos estudos que compararam bevacizumabe em combinação com lomustina em gliomas de grau IV.** -->
|**Autor, ano**|**Intervenç**<br>**ão**|**Contr**<br>**ole**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|**Idade**<br>**Controle**<br>**Mediana**<br>**(min-max)**|**n**<br>**(%)sexo**<br>**masculi**<br>**no**<br>**Interven**<br>**ção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Variáveis clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguiment**<br>**o**|
|---|---|---|---|---|---|---|---|---|---|
|**Weathers**<br>**et al. 2016**|BEVA +<br>LOM|BEVA|n (%) ≤ 50: 13<br>(37.1)<br>>50: 22 (62.9)|n (%) ≤ 50: 13<br>(36.1)<br>>50: 23 (63.9)|11<br>(31.4%)|<sup>12 (33.3%)</sup>|**KPS n (%):**<br>60–80: 11 (31.4%)<br>90–100: 24 (68.6%)<br>**Tumor**<br>Primeira recorrência<br>n (%): 25 (71.4)<br>Segunda recorrência<br>n(%): 10(28.7)|**KPS n (%):**<br>60–80: 13 (36.1%)<br>90–100: 23 (63.9%)<br>**Tumor**<br>Primeira recorrência<br>n (%): 24 (66.7)<br>Segunda recorrência<br>n(%): 12(33.3)|NR|
|**Wick et al.**<br>**2016;**<br>**Taphoorn**<br>**et al. 2016;**<br>**Wick et al.**<br>**2016c**<br>**(EORTC**<br>**26101)**|BEVA +<br>LOM|LOM|NR|NR|NR|NR|NR|NR|NR|
|**Taal et al.**<br>**2014**<br>**(BELOB**<br>**trial**)|1) BEVA/<br>LOM 110<br>2)<br>BEVA/L<br>OM 90|3)<br>LOM<br>4)<br>BEVA|1) 53 (29–62)<br>2) 58 (24–73)|3) 56 (28–73)<br>4) 58 (37–77)|1) 3<br>(38%)<br>2)30<br>(68%)|3) 26<br>(57%); 4)<br>32 (64%)|EP OMS<br>0**:**1) 3 (38%); 2) 11<br>(25%);<br>1: 1) 4 (50%); 2)28<br>(64%);|EP OMS<br>0: 3) 15 (33%); 4)13<br>(26%)<br>1: 3) 25 (54%); 4) 32<br>(64%)|NR|  
192  
|**Autor, ano**|**Intervenç**<br>**ão**|**Contr**<br>**ole**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|**Idade**<br>**Controle**<br>**Mediana**<br>**(min-max)**|**n**<br>**(%)sexo**<br>**masculi**<br>**no**<br>**Interven**<br>**ção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Variáveis clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguiment**<br>**o**|
|---|---|---|---|---|---|---|---|---|---|
||||||||2 :1) 1 (13%); 2) 5<br>(11%);|2: 3) 6 (13%); 4) 5<br>(10%)||  
BEVA: bevacizumabe; LOM: lomustina; LOM + BEVA ◊ escolha: LOM + BEVA até PD, com subsequente tratamento conservador de acordo com a escolha do investigador; EP OMS: estado de performance da Organização Mundial da Saúde; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; TMS: tempo máximo de sobrevida, obtido no gráfico de Kaplan-Meier do estudo; min-max.: mínimo e máximo; NR: não reportado.  
**Tabela 47 - Desfechos de eficácia dos estudos que compararam bevacizumabe em combinação com lomustina em gliomas de grau IV.**  
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**SG mediana:**<br>BEVA + LOM: 9.6 meses<br>(IC 95% 6.26, 16.73)<br>BEVA: 8.3 meses (IC 95%|0.75*|**SLP mediana:**<br>BEVA + LOM: 4.3 meses<br>(IC 95% 2.96, 8.34)<br>BEVA: 4.1 meses (IC 95%|0.19|**Taxa de resposta (critério**<br>**RANO):**||
|**Weathers**<br>**et al.**<br>**2016**|BEVA +<br>LOM|BEVA|6.42, 11.58)<br>**SG mediana para**<br>**pacientes tratados na**|0.98*|2.69, 5.55)<br>HR:  0.71 (IC 95%: 0.43,<br>1.18)||BEVA + LOM 90 mg/m2:<br>2/12 (17 %)<br>BEVA + LOM 75 mg/m2:<br>8/21 (38 %)|NR|
||||**primeira recorrência:**<br>BEVA + LOM: 13.05||**Taxa de SLP aos 6 meses:**<br>BEVA + LOM: 36.4 % (IC||BEVA: 7/36 (19 %)||
||||meses(IC 95% 7.08,17.82)||95% 23.3,57.1)||||  
193  
|**Autor,**<br>**ano**|**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|
|||BEVA: 8.8 meses (IC 95%<br>6.42, 20.22)||BEVA: 23.6% (IC 95%<br>12.9, 43.3)<br>**SLP mediana para**<br>**pacientes tratados na**<br>**primeira recorrência:**<br>**BEVA + LOM:**5.0 meses<br>(IC 95% 4.17,13.44)<br>BEVA: 3.2 meses (IC 95%<br>2.5, 6.01)<br>HR: 0.58 (IC 95% 0.31,<br>1.07)|0.08|||
|||||**Taxa de SLP aos 6 meses**<br>**para pacientes tratados na**<br>**primeira recorrência:**<br>BEVA + LOM: 45.8% (IC<br>95% 29.7, 70.8)<br>BEVA: 27.6% (IC 95%<br>14.0,54.5)||||  
194  
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**Fase III:**<br>**SG mediana:**<br>BEVA + LOM: 9.1 meses<br>(IC 95%: 8.1, 10.1)<br>LOM: 8.6 meses (IC 95%:<br>7.6, 10.4)<br>HR: 0.95 (IC 95%: 0.74,<br>1.21)|0.650|**SLP mediana:**<br>BEVA + LOM: 4.2 meses<br>(IC 95%: 3.7, 4.3)|NR|||
|**Wick et**<br>**al. 2016;**<br>**Taphoorn**<br>**et al.**<br>**2016;**<br>**Wick et**<br>**al. 2016c**<br>**(EORTC**<br>**26101)**|BEVA +<br>LOM|LOM|**Fase II:**<br>**Taxa de SO aos 12 meses:**<br>1)LOM + BEVA ◊<br>escolha): 32.9% (IC 95%:<br>25.4, 41.1)<br>2) LOM, ◊ BEVA: 27.4%<br>(IC 95%: 20.6, 35.2)<br>3) (BEVA, ◊<br>LOM+BEVA): 32.9% (IC<br>95%: 25.4, 41.1)<br>4) (LOM, ◊ escolha):<br>41.7% (IC 95%: 30.4, 53.7)<br>**SG mediana:**<br>1)LOM + BEVA ◊ escolha:<br>9.1 meses<br>2) LOM, ◊ BEVA: 7.8<br>meses||LOM:1.5 meses (IC 95%:<br>1.5, 2.5)<br>**Fase II:**<br>**SG mediana**<br>1) LOM + BEVA ◊ escolha:<br>4.2 meses<br>2) LOM, ◊ BEVA: 1.5<br>meses<br>3) (BEVA, ◊<br>LOM+BEVA): 2.8 meses<br>4) (LOM, ◊ escolha): 1.6<br>meses||**QVRS**<br>**EORTC-QLQ-C30**<br>**(intervenção vs. controle)**<br>FS média: 66 vs. 81<br>TD da QVRS (não foi<br>incluído tempo de PD): 13<br>vs. 13.1 semanas<br>SLD: 12.4 vs. 6.7 semanas|0.001<br>0.648<br><0.001|  
195  
|**Autor,**<br>**ano**|**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|
|||3) (BEVA, ◊||||||
|||LOM+BEVA): 7.9 meses||||||
|||4) (LOM, ◊ escolha): 9.3<br>meses||||||  
196  
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
|**Taal et al.**<br>**2014**<br>**(BELOB**<br>**trial)**|1) BEVA/<br>LOM 110<br>2)<br>BEVA/LOM<br>90|4) BEVA<br>3) LOM|**SG mediana:**<br>1) BEVA/ LOM 110: 16<br>meses (IC 95%: 2, 34)<br>2) BEVA/LOM 90: 11<br>meses (IC 95%: 8, 12)<br>3) LOM: 8 meses (IC 95%:<br>6, 11)<br>4) BEVA: 8 meses (IC<br>95%: 6, 9)<br>5)BEVA/ LOM 110+<br>BEVA/LOM 90: 12 meses<br>(IC 95%: 8, 13)<br>**Taxa de SO aos 9 meses:**<br>1) BEVA/ LOM 110: 87%<br>(IC 95%: 39, 98)<br>2) BEVA/LOM 90: 59%<br>(IC 95%: 43, 72)<br>3) LOM: 43% (IC 95%: 29,<br>57)<br>4) BEVA: 38% (IC 95%:<br>25, 51)<br>5)BEVA/ LOM 110+<br>BEVA/LOM 90: 63% (IC<br>95%: 49, 75)<br>**Taxa de SG aos12 meses:**|NR|**SLP mediana:**<br>1) BEVA/ LOM 110: 4<br>meses (IC 95%: 3, 8)<br>2) BEVA/LOM 90:<br>11meses (IC 95%: 1, 27)<br>3) LOM: 1 mês (IC 95%: 1,<br>3)<br>4) BEVA: 3 meses (IC 95%:<br>3, 4)<br>5)BEVA/ LOM 110+<br>BEVA/LOM 90: 4 meses<br>(IC 95%: 3, 8)<br>**Taxa de SLP aos 6 meses:**<br>1) BEVA/ LOM 110: 50%<br>(IC 95%: 15, 77)<br>2) BEVA/LOM 90: 41%<br>(IC 95%: 26, 55)<br>3) LOM: 13% (IC 95%: 5,<br>24)<br>4) BEVA: 16% (IC 95%: 7,<br>27)<br>5)BEVA/ LOM 110+<br>BEVA/LOM 90: 42% (IC<br>95%: 29, 55)|NR|**Taxa de Resposta**<br>**(critérios RANO)**<br>**Objetiva (completa ou**<br>**parcial)**<br>1) BEVA/ LOM 110: 5/8<br>(63%; IC 95%: 24, 91)<br>2) BEVA/LOM 90: 14/41<br>(34%; IC 95%: 20, 51)<br>3) LOM: 2/41 (5%; IC<br>95%: 1,17)<br>4) BEVA: 18/48 (38%; IC<br>95%: 24, 53)<br>5) BEVA/ LOM 110+<br>BEVA/LOM 90: 19/49<br>(39%; IC 95%: 25, 54)<br>**Atingiram resposta**<br>**objetiva vs. não atingiram**<br>**resposta objetiva:**<br>HR BEVA: 0·43 (IC 95%:<br>0.23, 0. 82)<br>HR BEVA/ LOM 110+<br>BEVA/LOM 90: 0. 37 (IC<br>95%: 0,23, 0.58)|<br>NR<br><0.05<br><0.05|  
197  
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||1) BEVA/ LOM 110: 63%<br>(IC 95%: 23, 86)<br>2) BEVA/LOM 90: 45%<br>(IC 95%: 30, 59)<br>3) LOM: 30% (IC 95%: 18,<br>44)<br>4) BEVA: 26% (IC<br>95%:15, 39)<br>5)BEVA/ LOM 110+<br>BEVA/LOM 90: 48% (IC<br>95%: 34, 61)||||||  
BEVA: bevacizumabe; LOM: lomustina; LOM + BEVA ◊ escolha: LOM + BEVA até PD, com subsequente tratamento conservador de acordo com a escolha do investigador; SLP: sobrevida livre de progressão; SG: sobrevida global; SO: taxa de sobrevivência; QVRS: qualidade de vida relacionada à saúde; EORTC QLQ-C30: Questionário de qualidade de vida _the European Organisation for Research and Treatment of Cancer Quality of Life Questionnaire C30_ ; critério RANO: _Response Assessment in Neuro-Oncology;_ PD: progressão da doença; SLD: sobrevida livre de deterioração; TD: tempo de deterioração; FS: funcionamento social; HR: hazard ratio; IC 95%: intervalo de confiança de 95%;NR: não reportado.  
198  
**Tabela 48 - Desfechos de segurança dos estudos que compararam bevacizumabe em combinação com lomustina em gliomas de grau IV.**  
|**Eventos**<br>**Adversos**|**Weath**<br>**BEVA + LOM**<br>**90mg/m2**|**ers et al. 201**<br>**BEVA +**<br>**LOM 75**<br>**mg/m2**|**6**<br>**BEVA**|**Valor**<br>**p**|**BEVA/LOM**<br>**110**|**Taal et al**<br> **(BELOB **<br>**BEVA/LOM**<br>**90**|**. 2014**<br> **trial)**<br>**LOM**|**BEVA**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|
|Isquemia<br>Cerebral|Grau 3 (n): 0;<br>Grau 4 (n): 0|Grau 3 (n):<br>0;<br>Grau 4(n): 0|<br>Grau 3 (n):<br>0;<br>Grau 4 (n):<br>2|NR||NR|||NR|
|Hemorragia<br>Cerebral|Grau 3 (n): 0;<br>Grau 4 (n): 0|Grau 3 (n):<br>0;<br>Grau 4 (n):<br>0|Grau 3 (n):<br>0;<br>Grau 4 (n):<br>0|NR||NR|||NR|
|Eventos<br>tromboembólicos||NR||NR|Grau 3, n (%): 0|Grau 3, n (%):<br>3 (7%)|Grau 3, n (%):<br>0|Grau 3, n<br>(%): 0|NR|
|Trato<br>respiratório/||NR||NR|Grau 1-2, n (%):<br>1 (13%)|Grau 1-2, n<br>(%):15 (34%)|Grau 1-2, n<br>(%):1 (2%)|Grau 1-2, n<br>(%): 5 (10%)|NR|
|Pulmonar|||||Grau 2, n (%): 0|Grau 2, n (%):<br>0|Grau 2, n (%):0|<br>Grau 2, n<br>(%): 2(4%)||  
199  
|**Eventos**<br>|**Weath**<br>|**ers et al. 201**<br>**BEVA +**|**6**|||**Taal et al**<br>**(BELOB**<br>|**. 2014**<br>**trial)**|||
|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|**BEVA + LOM**<br>**90mg/m2**|**LOM 75**<br>**mg/m2**|**BEVA**|**Valor**<br>**p**|**BEVA/LOM**<br>**110**|**BEVA/LOM**<br>**90**|**LOM**|**BEVA**|**Valor**<br>**p**|
||||||Grau 0-1, n (%):<br>2 (25%)|Grau 0-1, n<br>(%): 31 (70%)|Grau 0-1, n<br>(%): 30 (65%)|Grau 0-1, n<br>(%): 48<br>(96%)||
|Leucopenia|Grau 3 (n): 4<br>Grau 4 (n): 1|Grau 3 (n):<br>1<br>Grau 4 (n):<br>0|Grau 3 (n):<br>0<br>Grau 4 (n):<br>0|NR|Grau 2, n (%): 3<br>(38%)<br>Grau 3, n (%):3<br>(38%)|Grau 2, n (%):<br>10 (23%)<br>Grau 3, n (%):<br>3 (7%)|Grau 2, n (%):<br>8 (17%)<br>Grau 3, n (%):<br>7 (15%)|Grau 2, n<br>(%): 2 (4%)<br>Grau 3, n<br>(%): 0|NR|
||||||Grau 4, n (%): 0|<br>Grau 4, n (%):<br>0|Grau 4, n (%):<br>1 (2%)|Grau 4, n<br>(%):0||
|Neutropenia|Grau 3 (n): 3<br>Grau 4 (n):1|Grau 3 (n):<br>1<br>Grau 4 (n):<br>0|Grau 3 (n):<br>1<br>Grau 4<br>(n): 0|NR||NR|||NR|
|Trombocitopenia|Grau 3 (n): 4<br>Grau 4 (n): 2|Grau 3 (n):<br>2<br>Grau 4 (n):<br>0|Grau 3 (n):<br>0<br>Grau 4 (n):<br>0|NR|Grau 0-1, n (%):<br>2 (25%)<br>Grau 2, n (%): 1<br>(13%)<br>Grau 3, n (%):3<br>(38%)|Grau 0-1, n<br>(%):33 (75%)<br>Grau 2, n (%):<br>7 (16%)<br>Grau 3, n (%):3<br>(7%)|Grau 0-1, n<br>(%):27 (59%)<br>Grau 2, n<br>(%):10 (22%)<br>Grau 3, n (%):7<br>(15%)|Grau 0-1, n<br>(%): 48<br>(96%)<br>Grau 2, n<br>(%): 1 (2%)<br>Grau 3,n|NR|  
200  
|**Eventos**<br>|**Weath**<br>|**ers et al. 201**<br>**BEVA +**|**6**|||**Taal et al**<br>**(BELOB**<br>|**. 2014**<br>**trial)**|||
|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|**BEVA + LOM**<br>**90mg/m2**|<br>**LOM 75**<br>**mg/m2**|**BEVA**|**Valor**<br>**p**|**BEVA/LOM**<br>**110**|**BEVA/LOM**<br>**90**|**LOM**|**BEVA**|**Valor**<br>**p**|
||||||Grau 4, n (%): 2<br>(25%)|Grau 4, n (%):<br>1 (2%)|Grau 4, n (%):<br>2 (4%)|(%):0<br>Grau 4, n<br>(%): 1 (2%)||
|Linfopenia/<br>Linfocitopenia|Grau 3 (n): 6<br>Grau 4 (n): 3|Grau 3 (n):<br>6<br>Grau 4 (n):<br>1|Grau 3 (n):<br>8<br>Grau 4 (n):<br>0|NR||NR|||NR|
|Náusea e vômito||NR||NR|Grau 1-2, n (%):<br>4 (50%)<br>Grau 3, n (%): 1<br>(13%)|Grau 1-2, n<br>(%): 10 (23%)<br>Grau 3, n (%):<br>0|Grau 1-2, n<br>(%): 7 (15%)<br>Grau 3, n (%):<br>2(4%)|Grau 1-2, n<br>(%): 5 (10%)<br>Grau 3, n<br>(%): 1(2%)|NR|
|Fadiga||NR||NR|Grau 1-2, n (%):<br>7 (88%)<br>Grau 3, n (%): 0|Grau 1-2, n<br>(%): 31 (70%)<br>Grau 3, n (%):<br>8 (18%)|Grau 1-2, n<br>(%): 21 (46%)<br>Grau 3, n (%):<br>3 (7%)|Grau 1-2, n<br>(%): 30<br>(60%)<br>Grau 3, n<br>(%): 2 (4%)|NR|
||||||Grau 4, n (%): 0|Grau 4, n (%):<br>0|Grau 4, n (%):1<br>(2%)|Grau 4, n<br>(%):0||  
201  
|**Eventos**<br>|**Weath**<br>|**ers et al. 2016**<br>**BEVA +**||||**Taal et al**<br>**(BELOB**<br>|**. 2014**<br>**trial)**|||
|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|**BEVA + LOM**<br>**90mg/m2**|<br>**LOM 75**<br>**mg/m2**|**BEVA**|**Valor**<br>**p**|**BEVA/LOM**<br>**110**|**BEVA/LOM**<br>**90**|**LOM**|**BEVA**|**Valor**<br>**p**|
|Hipertensão||NR||NR|Grau 1-2, n (%):<br>1 (13%)<br>Grau 3, n (%): 3<br>(38%)|Grau 1-2, n<br>(%): 15 (34%)<br>Grau 3, n (%):<br>11 (25%)|Grau 1-2, n<br>(%): 8 (17%)<br>Grau 3, n (%):<br>3 (7%)|Grau 1-2, n<br>(%): 15<br>(30%)<br>Grau 3, n<br>(%): 13<br>(26%)|NR|
|Infecções||NR||NR|Grau 1-2, n (%):<br>2 (25%)<br>Grau 3, n (%): 0<br>Grau 4, n (%): 0|Grau 1-2, n<br>(%): 13 (30%)<br>Grau 3, n (%):<br>4 (9%)<br>Grau 4, n (%):<br>0|Grau 1-2, n<br>(%): 5 (11%)<br>Grau 3, n (%):<br>1 (2%)<br>Grau 4, n (%):<br>1 (2%)|Grau 1-2, n<br>(%): 7 (14%)<br>Grau 3, n<br>(%): 3 (6%)<br>Grau 4, n<br>(%): 0|NR|
||||||Grau 5, n (%): 0|Grau 5, n (%):1<br>(2%)|Grau 5, n (%):<br>0|Grau 5, n<br>(%):0||
||||||Grau 1, n (%): 0<br>Grau 2, n (%): 2|Grau 1, n (%):<br>16 (36%)|Grau 1, n (%):<br>10 (22%)|Grau 1, n<br>(%): 12<br>(24%)||
|Proteinúria||NR||NR|(25%)<br>Grau 3, n (%): 2<br>(25%)|Grau 2, n (%):<br>9 (20%)|Grau 2, n (%):<br>1 (2%)|Grau 2, n<br>(%): 3 (6%)|NR|  
202  
|**Eventos**<br>**Adversos**|**Weat**<br>**BEVA + LOM**<br>**90mg/m2**|**hers et al. 201**<br>**BEVA +**<br>**LOM 75**<br>**mg/m2**|**6**<br>**BEVA**|**Valor**<br>**p**|**BEVA/LOM**<br>**110**|**Taal et al**<br>**(BELOB**<br>**BEVA/LOM**<br>**90**|**. 2014**<br>**trial)**<br>**LOM**|**BEVA**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||Grau 3, n (%):<br>1 (2%)|Grau 3, n (%):<br>0|Grau 3, n<br>(%): 0||
|Perfuração<br>Intestinal|Grau 3 (n): 0<br>Grau 4 (n): 0|Grau 3 (n):<br>0<br>Grau 4 (n):<br>0|Grau 3 (n):<br>1<br>Grau 4 (n):<br>0|NR||NR|||NR|
|A)<br>Descontinuação<br>B) interrupção<br>ou ajuste devido<br>à EA||NR||NR||n: 3 (não especif|icou o grupo)||NR|
|Morte devido ao<br>tratamento|n: 0|n: 0|n: 0|NR|n: 2 (1 BE|VA +LOM 90 e 1|não especificou o|grupo)|NR|  
EA: eventos adversos; BEVA: bevacizumabe; LOM: lomustina; LOM 110: lomustina 110 mg/m2; LOM 90: lomustina 90 mg/m2; NR: não reportado. **1.4 Gliobastoma (IV): Bevacizumabe com diferentes combinações**  
203

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 49 - Características dos estudos que compararam bevacizumabe com diferentes combinações em gliomas de grau IV.** -->
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**<br>**(Tipo/ estágio**<br>**deglioma)**|**Número de e**<br>**e participa**<br>**incluíd**|**studos**<br>**ntes**<br>**os**|**Intervenção**|**Controle**|**Risco de Vié**|**s**|
|---|---|---|---|---|---|---|---|---|---|
|**Field et**<br>**al. 2015;**<br>**Hovey et**|ECR<br>(CABARET),<br>fase<br>II,|Comparar<br>a<br>monoterapia<br>de<br>BEVA|Gliobastoma<br>recorrente após<br>primeira<br>linha|Parte<br>1:<br>participantes<br>+<br>CARBO|122<br>(BEVA<br>:<br>60;|**Parte**<br>**1:**<br>**BEVA**<br>(10mg/ kg a cada 2s)<br>+**CARBO**(5 a cada 4|**Parte**<br>**1:**<br>**BEVA**<br>(10mg/ kg a cada 2s)|**Alto risco de**<br>(Sigilo de aloc<br>não reportado;|**viés**<br>ação<br>não|
|**al.  2015**<br>**(191,**<br>**192)**|dividido em 2<br>partes|versus<br>a<br>combinação<br>de BEVA +<br>CARBO<br>**Hovey et al.**<br>**2015:**analisou<br>o benefício do<br>BEVA<br>utilizado após<br>da PD (parte<br>2)|de<br>terapia<br>RT/TMZ|BEVA:<br>Parte<br>2:<br>participantes<br>(continuou<br>23; cessou<br>25)|62)<br>48<br>BEVA:<br>BEVA:|s)<br>**(BEVA + CARBO)**<br>**Parte 2:** participantes<br>que tiveram PD e<br>aceitaram continuar o<br>ECR<br>foram<br>randomizados:<br>1)<br>**continuaram**<br>**BEVA**|**(BEVA)**<br>**Parte**<br>**2:**<br>participantes<br>que<br>tiveram<br>PD<br>e<br>aceitaram continuar<br>o<br>ECR<br>foram<br>randomizados:<br>2)<br>**cessou**<br>**o**<br>**tratamento**<br>**com**<br>**BEVA**<br>(**Sem BEVA)**|cegamentos<br>profissionais<br>participantes<br>Parte 2: resumo<br>congresso<br>(informações<br>importantes<br>insuficientes<br> <br>julgamento);|dos<br>ou<br>de<br>para|
|**Brandes**<br>**et**<br>**al.**<br>**2016**<br>**(193)**|ECR<br>(AVAREG),<br>fase II|Examinar<br>a<br>eficácia<br>do<br>BEVA<br>ou<br>FOT|Gliobastoma<br>recorrente após<br>primeira<br>linha<br>de<br>terapia<br>RT/TMZ|91<br>parti<br>(BEVA: 59; F|cipantes<br>OT: 32)|**BEVA**(10mg/ kg a<br>cada 2s)<br>**(BEVA)**|**FOT**(75 mg/m2 nos<br>dias 1, 8 e 15; então<br>100 mg/m2 a cada<br>3s depois de um<br>intervalo de 35 dias)<br>**(FOT)**|**Alto risco de**<br>(Sigilo de aloc<br>e; não cegame<br>dos<br>profissio<br>participantes<br>investigadores)|**viés**<br>ação<br>ntos<br>nais,<br>ou|  
204  
|**Reardon**<br>ECR, fase II|Avaliar|a|<br>Gliobastoma|23|participantes|TMZ (50 mg/m2/dia|ETO<br>(50<br>mg/m2<br>**Alto risco de**|**viés**|
|---|---|---|---|---|---|---|---|---|
|**et**<br>**al.**|eficácia|do|<br>recorrente com|(TMZ+|BEVA: 10;|oral) + BEVA (10mg/|diariamente por 21<br>(Sigilo de aloca|ção e|
|**2011**|etoposídeo|em|<br>progressão<br>à|ETO +|BEVA; 13)|kg a cada 14 dias)|dias consecutivos a<br>método|de|
|**(194)**|dose||terapia anterior||||cada ciclo de 28<br>randomização|não|
||metronômi|ca|com BEVA|||**(TMZ +BEVA)**|dias)<br>+<br>BEVA<br>reportados;|não|
||(ETO)|ou|||||(10mg/ kg a cada 14<br>cegamentos|dos|
||TMZ em d|ose|||||dias)<br>profissionais,||
||metronômi|ca|||||participantes|ou|
||administrad<br>com BEVA|os<br>|||||**(ETO + BEVA)**<br>investigadores)||  
BEVA: bevacizumabe; FOT: fotemustina; CARBO: carboplatina; ETO: etoposídeo; RT: radioterapia; TMZ: temozolamida; ECR: ensaio clínico randomizado; PD: progressão da doença; s.: semanas.  
205  
**Tabela 50 - Características dos participantes dos estudos que compararam bevacizumabe com diferentes combinações em gliomas de grau IV.**  
|**Autor, ano**|**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|**Idade**<br>**Controle**<br>**Mediana**<br>**(min-max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|**Field et al.**<br>**2015; Hovey**<br>**et al.  2015**|BEVA +<br>CARBO|BEVA|55 (32–79)|55 (25–82)|34 (57%)|33 (53%)|**EP ECOG n**<br>**(%):**<br>0: 7 (12%)<br>1: 35 (58%)<br>2: 18 (30%)<br>|**EP ECOG n**<br>**(%):**<br>0: 11 (18%)<br>1: 35 (56%)<br>2: 16 (26%)<br>**KPS n (%):**<br>90–100: 22<br>|Parte 1: 32<br>meses<br>Parte 2: 12|
|**(CABARET)**|||||||**KPS n (%):**<br>90–100: 21 (35)<br>70–80: 28 (47)<br><70: 11 (18)<br>Não feito: 0 (0)|(35%)<br>70–80: 28<br>(45%)<br><70: 10 (16%)<br>Não feito: 2<br>(3%)|.<br>meses|
||||||||**EP ECOG**n<br>(%):<br>0: 29 (49%)|**EP ECOG**n<br>(%):<br>0:13 (41%)||
|**Brandes et**|||||||1:19 (32%)|1:16 (50%)||
|**al. 2016**|BEVA|FOT|59 (37- 74)|56 (28- 78)|39 (66%)|23 (72%)|2: 11 (19%)|2:3 (9%)|NR|
|**(AVAREG)**|||||||**EORTC QLQ-**<br>**C30**média (DP):<br>8.05 (26.40)<br>FF: 71.95|**EORTC QLQ-**<br>**C30**média<br>(DP): 66.13<br>(24.90)||  
206  
|**Autor, ano**|**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|**Idade**<br>**Controle**<br>**Mediana**<br>**(min-max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
||||||||(25.65)<br>FE: 73.56<br>(23.47)<br>FS: 72.99<br>(28.07)<br>**Uso de**<br>**esteroides:**<br>(n:42)|FF: 78.92<br>(25.07)<br>FE:<br>73.56+23.47<br>FS:<br>81.18+24.24<br>**Uso de**<br>**esteroides:**<br>(n:20)||
|**Reardon et**<br>**al. 2011**|TMZ<br>+BEVA|ETO +<br>BEVA|Mediana: 50.8|Mediana:<br>52.4|7 (70%)|11 (85%)|**KPS n (%):**<br>90–100: 6 (60)<br>70–80: 4(40)|**KPS n (%):**<br>90–100: 7 (54)<br>70–80: 6(46)|NR|  
BEVA: bevacizumabe; FOT: fotemustina; CARBO: carboplatina; ETO: etoposídeo; min-max: mínimo e máximo; EP ECOG: estado de performance do Grupo de Oncologia Cooperativa Oriental; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; EORTC QLQ-C30: Questionário de qualidade de vida _the European Organisation for Research and Treatment of Cancer Quality of Life Questionnaire C30_ ; FF: funcionamento físico; FE: funcionamento emocional; FS: funcionamento social; TMS: tempo máximo de sobrevida, obtido no gráfico de Kaplan-Meier do estudo.  
207

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 51 - Desfechos de eficácia dos estudos que compararam bevacizumabe com diferentes combinações em gliomas de grau IV.** -->
|**Autor, ano**|**Intervenção**|<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|<br>**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**Parte**<br>**1:**||**Parte**<br>**1:**||**Parte**<br>**1:**||
||||**SG**<br>**mediana:**<br>BEVA + CARBO: 6.9<br>meses<br>BEVA:<br>7.5<br>meses|<br> <br>0.38|**Taxa SLP aos 6 meses:**<br>BEVA + CARBO: 15%<br>BEVA:<br>18%|<br> <br>NR|**Taxa**<br>**de**<br>**resposta**<br>**(critério RANO), n (%)**<br>**(intervenção**<br>**vs.**<br>**controle):**|<br> <br> <br>0.18*|
||||HR: 1.18 (95%: 0.82, 1.69)||**SLP**<br>**mediana:**<br>BEVA + CARBO: 3.5|<br>|**Objetivo de resposta:**<br>1) Resposta completa:  0|<br>|
||||**Parte**<br>**2:**||meses (IC 95%: 2.2, 3.7)||vs.<br>0||
||||**SG**<br>**mediana:**||BEVA: 3.5 meses (IC 95%:||2) Resposta parcial:  8|<br>0.23*|
||||com BEVA: 3.4 meses||1.9,<br>3.7)|<br>0.66|(14%)<br>vs.<br>4<br>(6%)||
|**Field et al.**|||sem BEVA: 3.0 meses|<br>0.56|HR: 0.92 (IC 95% CI: 0.64,||||
|**2015; Hovey**<br>**et al.  2015**|BEVA +<br>CARBO|BEVA|HR: 0.84 (95%: 0.47, 1.50)||1.33)<br>**Parte**<br>**2:**||**Melhor**<br>**resposta:**<br>1) Resposta parcial: 8<br>(14%)<br>vs.<br>4<br>(6%)|<br> <br>|
|**(CABARET)**|||||**SLP**<br>**mediana:**<br>com BEVA: 1.8 meses<br>sem BEVA: 2.0 meses<br>HR: 1.08 (IC 95% CI: 0.59,<br>1.96)|<br> <br> <br>0.81|2) Doença estável: 36<br>(62%)<br>vs.<br>36<br>(58%)<br>3) PD: 14 (24%) vs. 22<br>(35%)<br>**Mudança média EORTC**<br>**QLQ-C30:**<br>BEVA + CARBO: -0.2<br>BEVA:<br>-5.2<br>∆ (BEVA + CARBO) -<br>BEVA: -5.0(-14.1,4.1)|<br> <br> <br> <br> <br> <br> <br>0.28|  
208  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|<br>**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**SG**<br>**mediana:**<br>BEVA: 7.3 meses (IC 95%:|NR|**SLP**<br>**mediana:**<br>BEVA: 3.38 meses (IC|NR|**Taxa**<br>**de**<br>**resposta**<br>**(critério**<br>**RANO):**|<br>NR|
||||5.8,<br>9.2)||95%:<br>3.15,<br>4.37)||BEVA: 29%; FOT: 9%||
||||FOT: 8.7 meses (IC 95%:||FOT: 3.45 meses (IC 95%:||||
||||6.3,<br>15.4)||1.87,<br>3.84)||**%**<br>**de**<br>**pacientes**<br>**que**<br>**receberam**<br>**outras**|<br>|
||||**Taxas de SO aos A) 6**||**Taxa SLP aos 6 meses:**||**terapias**<br>**após**<br>**PD:**||
||||**meses; B) 9 meses; C) 12**||BEVA:<br>26.3<br>%<br>(IC||BEVA:<br>32<br>(54%)||
||||**meses:**||95%:15.5,<br>39.7)||FOT:<br>18<br>(58%)||
||||BEVA % (IC 95%): A) 62.1||FOT:10.7% (IC 95% 2.3,||||
||||(48.4, 74.5); B) 37.9 (25.5,||28.3)||**QVRS**||
|**Brandes et**<br>**al. 2016**|BEVA|FOT|51.6); C) 25.9 (15.3, 39.0).<br>FOT % (IC 95%): A) 73.3 (||**Taxas de SLP aos 6 meses,**<br>**por**<br>**idade:**||**EORTC QLQ-C30 no**<br>**dia 46 ±3, DM (DP):**<br>**-Aumento:**||
|**(AVAREG)**|||54.1, 87.7); B) 46.7% (||BEVA ≥ 55 anos: 40.7%||FF BEVA: +10.37 (19.07)||
||||28.3, 65.7); C) 40.0 (22.7,<br>59.4);<br>**Taxas de SO aos A) 6**||BEVA <55 anos: 13.3%<br>FOT ≥ 55 anos: 7.7%<br>FOT <55 anos: 13.3%||FF FOT: +7.08 (12.76)<br>**-Diminuição:**<br>FOT<br>fadiga;<br>náusea;<br>insônia; perda de apetite: -|<br>|
||||**meses e  B) 9 meses, por**||||13.19<br>(25.73);<br>-8.33||
||||**idade:**||||(14.91); -8.33 (33.33); -||
||||BEVA ≥ 55 anos: A)||||10.42<br>(23.47).||
||||77.8%;<br>B)59.3<br>%;<br>BEVA <55 anos: A) 48.4|<br>0.05|||BEVA FM: -8.02 (3.62)||
||||%;<br>B)<br>19.3%;||||**Uso de esteroides depois**||
||||FOT ≥ 55 anos: A) 66.7 %;|0.0002|||**de 8s de tratamento:**||
||||B)<br>33<br>%;||||BEVA:<br>59.62%<br>sem||  
209  
|**Autor, ano**|**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**<br>**Outros**|**desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|
|||FOT <55 anos: A) 80 %; B)<br>60%<br>**Análises exploratórias de**<br>**SG**:<br>BEVA ≥ 55 anos vs. BEVA<br><55 anos:  HR: 2.02 ( IC<br>95%:<br>0.99,<br>4.11)<br>BEVA Mulheres vs. BEVA<br>homens: HR: 0.22 (IC 95%:<br>0.10,<br>0.49)|<br>0.0031<br>0.0006<br>0.011||mudança<br>dexametaso<br>diminuiu<br>17.32%<br>>2mg de<br>FOT: NR|na<br>dose<br>de<br>na;<br>23.08%<br>a<br>dosagem;<br>aumentou-se<br>dexametasona.|<br> <br> <br> <br>|
|||BEVA ECOG OS=0 vs.<br>BEVA ECOG OS=1: HR<br>3.70 (IC 95%: 1.55, 8.83)|NR|||||
|||BEVA ECOG OS=0 vs.<br>BEVA ECOG OS=2: HR:<br>7.71 (IC 95% CI: 2.39,<br>24.93)||||||
|||FOT ECOG OS=0 vs. FOT<br>ECOG OS=2: HR: 3.10 (IC<br>95%<br>CI:<br>2.02,<br>24.58)||||||  
**SG mediana daqueles que receberam vs.** **<u>que não</u>**  
210  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**|**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**receberam**<br>**terapia**<br>**pós**||||||
||||**PD:**||||||
||||BEVA: 11.2 vs. 4.6 meses||||||
||||FOT: 13.1 vs. 5.5 meses||||||  
211  
|**Autor, ano**|**Intervenção**|**Controle**|<br>**Sobrev**<br>**taxa d**|**ida global (SG) /**<br>**e Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|<br>**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**<br>**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
||||**SG**<br>BEVA<br>semanas<br>23.3)<br>BEVA<br>semanas<br>25.7)|**mediana:**<br>+<br>TMZ:<br>12.6<br>(IC 95 %: 4.6,<br>+<br>ETO:<br>19.0<br>(IC 95 %: 11.0,|NR|**SLP**<br>**mediano:**<br>BEVA + TMZ: 4.1 semanas<br>(IC<br>95<br>%:<br>3.0,<br>7.9)<br>BEVA + ETO: 8.1 semanas<br>(IC 95 %: 4.1, 12.0)<br>**Taxa de** **SLP aos 6 meses,**<br>**mediana:**<br>BEVA<br>+<br>TMZ:<br>0<br>BEVA + ETO: 7.7% (IC 95<br>%: 4.8, 29.2)|NR<br>**Taxa**<br>**de**<br>**resposta**<br>**radiográfica-**<br>**critérios**<br>**definidos pelos autores**<br>**(BEVA +TMZ vs. BEVA**<br>**+ETO):**<br>**1) Completa (%):**0 vs. 0<br>**2) Parcial (%):**0 vs. 0<br>**3) Doença estável(%):**4<br>(40)<br>vs.<br>8<br>(62)<br>**4) PD (%):**6 (60) VS. 4<br>(31)<br>**5) Não avaliado (%):**0|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br>NR|
|**Reardon et**<br>**al. 2011**|TMZ<br>+BEVA|ETO +<br>BEVA|||||vs.<br>1<br>(8)<br>**Padrões de progressão**<br>**do tumor A) antes e B)**<br>**durante a terapia com**<br>**BEVA**<br>**1)**<br>**Local:**<br>**Captável e Não captável**<br>BEVA + TMZ (n): A)7;<br>B)9;<br>BEVA + ETO (n): A) 7; B)<br>9<br>Não<br>captável:<br>BEVA + TMZ (n): A) 0;<br>B)<br>0;<br>BEVA + ETO(n): A)0;B)|<br> <br> <br> <br> <br> <br> <br> <br> <br>|  
212  
|**Autor, ano**|**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor**<br>**p**<br>**Outros desfechos**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|
||||||0;<br>**2)**<br>**Difuso**<br>**Captável e Não captável:**<br>BEVA + TMZ (n): A) 2;<br>B)<br>0;<br>BEVA + ETO (n): A) 3; B)<br>1|<br> <br> <br>|
||||||;<br>**Não**<br>**captável:**<br>BEVA + TMZ (n): A) 1;<br>B)<br>0;<br>BEVA + ETO (n): A) 2; B)<br>2;<br>**3) Distante**<br>**Captável e não captável/**<br>**não captável:**<br>BEVA + TMZ (n): 0;<br>BEVA + ETO (n): 1<br>**Declínio**<br>**clínico:**<br>BEVA + TMZ (n):  A)0;<br>B) 1; BEVA + ETO: A) 0;<br>B)<br>0<br>**Não PD até a data do**<br>**estudo**: BEVA + TMZ (n):<br>A)0; B) 1; BEVA + ETO:<br>A)0;B)1|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>|  
Valor de p Intervenção versus Controle *; BEVA: bevacizumabe; FOT: fotemustina; CARBO: carboplatina; ETO: etoposídeo; SLP: sobrevida livre de progressão; SG: sobrevida global; SO: taxa de sobrevivência; PD: progressão da doença; QVRS: qualidade de vida relacionada à saúde; EP ECOG:  
213  
estado de performance do Grupo de Oncologia Cooperativa Oriental; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; EORTC QLQ-C30: Questionário de qualidade de vida _the European Organisation for Research and Treatment of Cancer Quality of Life Questionnaire C30_ ; FF: funcionamento físico; FE: funcionamento emocional; FS: funcionamento social; FM: função motora; ∆: diferença; HR: hazard ratio; IC 95%: intervalo de confiança de 95%; NR: não reportado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 52 - Desfechos de segurança dos estudos que compararam bevacizumabe com diferentes combinações em gliomas de grau IV.** -->
|**Eventos**|**Field et al. 201**<br>**(CA**|**5; Hovey et al.  20**<br>**BARET)**|**15**|**Bran**<br>**(A**|**des et al. 2016**<br>**VAREG)**||**Reardo**|**n et al. 2011**|
|---|---|---|---|---|---|---|---|---|
|**Adversos**|**BEVA+ CARBO**|**BEVA**|**Valor**<br>**p**|**BEVA**|**FOT**|**Valor**<br>**p**|**BEVA+ TMZ**|**BEVA+ETO**<br>**Valor**<br>**p**|
|Isquemia<br>Cerebral|N|R|NR|n (%):<br>Grau 3: 1<br>(1.7%)<br>Grau 4: 0|n (%):<br>Grau 3:. 0;<br>Grau 4: 0|NR|NR|<br>NR|
|Hemorragia<br>Cerebral|n (%)▲:<br>Quaisquer graus: 3<br>(5%)<br>Grau ≥3: 1(2%)|n (%)▲:<br>Quaisquer graus:<br>3 (5%)<br>Grau ≥3: 0(0%)|NR|n (%):<br>Grau 3: 0<br>Grau 4: 1<br>(1.7%)|n (%):<br>Grau 3: 0<br>Grau 4: 0|NR|NR|<br>NR|
|Sangramento/|n (%)▲:<br>Quaisquer graus:|n (%)▲:<br>Quaisquer graus:|||||||
|hemorragias<br>(outros)|17 (29%)<br>Grau≥3: 1(2%)|16 (26%);<br>Grau≥3: 1(2%)|NR|N|R|NR|NR|<br>NR|  
214  
|**Eventos**<br>**Adversos**|**Field et al. 201**<br>**(CA**|**5; Hovey et al.  2**<br>**BARET)**|**015**<br>**Vl**|**Brand**<br>**(A**|**es et al. 2016**<br>**VAREG)**|**Vl**|**Reardo**|**n et al. 2011**|**Vl**|
|---|---|---|---|---|---|---|---|---|---|
||**BEVA+ CARBO**|**BEVA**|**aor**<br>|**BEVA**|**FOT**|**aor**<br>|**BEVA+ TMZ**|**BEVA+ETO**|**aor**<br>|
||||**p**|||**p**|||**p**|
|Eventos<br>tromboembólicos|n (%)▲:<br>1) Trombose<br>Venosa Profunda:<br>Quaisquer graus:<br>4 (7%); Grau ≥3: 2<br>(3%)<br>2) outros:<br>Quaisquer graus: 1<br>(2%);<br>Grau ≥3: 0<br>3) Embolismo<br>pulmonar:<br>n (%)▲:<br>Quaisquer graus: 2<br>(3%);<br>Grau ≥3: 2 (3%)|n (%)▲:<br>1) Trombose<br>Venosa<br>Profunda:<br>Quaisquer<br>graus: 6 (10%);<br>Grau ≥3: 0<br>2) outros:<br>Quaisquer graus:<br>1 (2%);<br>Grau ≥3: 0<br>3) Embolismo<br>pulmonar:<br>n (%)▲:<br>Quaisquer graus:<br>0;<br>Grau ≥3: 0|NR|Embolismo<br>pulmonar:  n<br>(%) A) Grau 3:<br>1 (1.7%) vs. 0;<br>B) Grau 4: 0<br>vs. 0||NR|NR||NR|
|Infarto agudo do<br>miocárdio|N|R|NR|n (%) grau 3: 1<br>(1.7%)<br>Grau 4(n): 0|n (%) grau 3:<br>0;<br>Grau 4(n): 0|NR|NR||NR|
||Todos os graus: 15|Todos os||||||||
|Diarreia|(26%)|graus:15 (24%);<br>Grau≥3: 0|NR|N|R|NR|NR||NR|  
215  
|**Eventos**|**Field et al. 201**<br>**(CA**|**5; Hovey et al.  2**<br>**BARET)**|**015**|**Brand**<br>**(A**|**es et al. 2016**<br>**VAREG)**||**Reardo**|**n et al. 2011**||
|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||**Valor**|||**Valor**|||**Valor**|
||**BEVA+ CARBO**|**BEVA**|<br>|**BEVA**|**FOT**|<br>|**BEVA+ TMZ**|**BEVA+ETO**|<br>|
||||**p**|||**p**|||**p**|
||Grau ≥3: 1 (2%)<br>(0%)|||||||||
|Constipação|Todos os graus: 26<br>(45%);<br>Grau≥3: 0(0%)|Todos os graus:<br>18 (29%);<br>Grau≥3: 0(0%)|NR|N|R|NR|Grau 2 (n): 0|Grau 2 (n): 1|NR|
||n (%):|n (%):||||||||
|Anemia|Todos os graus: 16<br>(28%);<br>Grau ≥3:  0(0%)|Todos os graus:<br>6 (10%);<br>Grau ≥3:  0(0%)|NR|n (%): 49<br>(83.1%)|n (%):27<br>(84.4%)|NR|NR||NR|
|Leucopenia|N|R|NR|n (%) grau 3: 1<br>(1.7%);|n (%) grau 3: 1<br>(3.1%);|NR|NR||NR|
|||||Grau 4: 0 vs. 0|Grau 4: 0|||||
||n (%) 1)Febril:<br>Todos os graus: 0<br>(0%);<br>Grau ≥3:  0 (0%)|n (%) 1)Febril:<br>Todos os graus:<br>0 (0%); Grau ≥3:<br>0 (0%)||n (%) grau 3:0;|n (%) grau 3:<br>3 (9.4%);|||||
|Neutropenia|2) Sem febre:<br>Todos os graus: 14<br>(24%);<br>Grau≥3: 4(7%)|2)Sem febre:<br>Todos os graus:<br>4 (6%); Grau ≥3:<br>0(0%)|<br>NR|Grau 4:1<br>(1.7%)|Grau 4: 1<br>(3.1%)|NR|Grau 4 (n): 0|Grau 4 (n): 1|NR|  
216  
|**Eventos**<br>**Adversos**|**Field et al. 201**<br>**(CA**|**5; Hovey et al.  2**<br>**BARET)**|**015**<br>**Valor**|**Brand**<br>**(A**|**es et al. 2016**<br>**VAREG)**|**Valor**|**Reardo**|**n et al. 2011**|**Valor**|
|---|---|---|---|---|---|---|---|---|---|
||**BEVA+ CARBO**|**BEVA**|<br>|**BEVA**|**FOT**|<br>|**BEVA+ TMZ**|**BEVA+ETO**|<br>|
||||**p**|||**p**|||**p**|
|||||n (%) grau 3: 0<br>vs. 1 (3.1%);|n (%) grau 3: 0<br>vs. 1 (3.1%);|||||
|Pancitopenia|NR||NR|Grau 4: 0 vs.1<br>(3.1%)|Grau 4: 0 vs.1<br>(3.1%)|NR|NR||NR|
|Trombocitopenia|Todos os graus: 32<br>(55%);<br>Grau≥3: 9(16%)|Todos os graus:<br>14 (23%);<br>Grau≥3: 2(3%)|NR|n (%)  grau 3:<br>0;<br>Grau 4: 0|n (%)  grau 3:<br>5 (15.6 %);<br>Grau 4: 2<br>(6.3%)|NR|NR||NR|
||Todos os graus: 29<br>(50%);|Todos os graus:<br>24 (39%);||||||||
|Náusea e vômito|||NR|N|R|NR|Grau 2 (n): 0|Grau 2 (n): 1|NR|
||Grau≥3: 0(0%)|Grau≥3: 2(3%)||||||||
|Fadiga|Todos os graus: 50<br>(86%);<br>Grau ≥3: 5(9%)|Todos os graus:<br>52 (84%);<br>Grau ≥3: 4(6%)|NR|N|R|NR|Grau 2 (n): 1<br>Grau 3 (n): 0|Grau 2 (n): 2<br>Grau 3 (n): 2|NR|
|Hipertensão|n (%)▲:<br>Quaisquer graus:<br>36 (62%);<br>Grau ≥3: 10 (17%)|<br>n (%)▲:<br>Quaisquer graus:<br>51 (82%);<br>Grau ≥3: 10<br>(16%)|<br>NR|n (%) grau 3: 1<br>(1.7%);<br>Grau 4: 0|n (%) grau 3:<br>0;<br>Grau 4: 0|NR|NR|NR||  
217  
|**Eventos**<br>|**Field et al. 201**<br>**(C**|**5; Hovey et al.  20**<br>**ABARET)**|**15**|**Brand**<br>**(A**|**es et al. 2016**<br>**VAREG)**||**Reardo**|**n et al. 2011**||
|---|---|---|---|---|---|---|---|---|---|
|**Adversos**|||**Valor**|||**Valor**|||**Valor**|
||**BEVA+ CARBO**|**BEVA**|<br>**p**|**BEVA**|**FOT**|<br>**p**|**BEVA+ TMZ**|**BEVA+ETO**|<br>**p**|
|Cicatrização com<br>complicações|n<br>(%)▲:Quaisquer<br>graus:  1 (2%)|n<br>(%)▲:Quaisquer<br>graus:  1 (2%)|NR|NR||NR|NR||NR|
|Infecções|N|R|NR|NR||NR|Grau 3 (n): 1 vs.<br>0|NR|NR|
||n (%)▲:|n (%)▲:||||||||
|Proteinúria|Quaisquer graus: 7<br>(12%);<br>Grau≥3: 0|<br>Quaisquer graus:<br>4 (6%); Grau ≥3:<br>2(3%)|NR|NR||NR|NR||NR|
|Perfuração<br>Intestinal|n (%)▲:<br>Quaisquer graus: 1<br>(2%);<br>Grau ≥3: 1 (2%)|<br>n (%)▲:<br>Quaisquer graus:<br>0 (0%);<br>Grau ≥3: 0 (0%)|NR|n (%) A) grau<br>3: 0<br>B) grau 4:<br>2(3.4%)|n (%) A) grau<br>3: 0<br>B) grau 4: 0|NR|NR||NR|
|Quaisquer EA|n (%):<br>Grau ≥3:  37<br>(64%);<br>Causaram morte: 2<br>(3%)|<br>n (%):<br>Grau ≥3: 36<br>(58%);<br>Causaram morte:<br>0(0%)|NR|NR||NR|NR||NR|
|A)<br>Descontinuação<br>B) interrupção<br>|A) n: 5|A) n: 4|NR|n (%): A) 11<br>(18. 6%);|n (%): A) 3<br>(9.4%);|NR|NR||NR|
|ou ajuste devido<br>à EA sérios||||B) 2 (3.4%)|B) 2 (6.4%)|||||  
218  
|**Eventos**|**Field et al. 2015**<br>**(CAB**|**; Hovey et al.**<br>**ARET)**|**2015**|**Bran**<br>**(A**|**des et al. 2016**<br>**VAREG)**||**Reardo**|**n et al. 2011**|
|---|---|---|---|---|---|---|---|---|
|**Adversos**|**BEVA+ CARBO**|**BEVA**|**Valor**<br>**p**|**BEVA**|**FOT**|**Valor**<br>**p**|**BEVA+ TMZ**|**BEVA+ETO**<br>**Valor**<br>**p**|
|Morte devido ao<br>tratamento|n: 2|n: 0|NR|n:1|n:0|NR|NR|<br>NR|  
EA: eventos adversos; BEVA: bevacizumabe; FOT: fotemustina; CARBO: carboplatina; ETO: etoposídeo; ▲ EA relacionados ao BEVA; NR: não reportado.  
**2. Gliobastomas (Grau IV) e Astrocitoma Anaplásico, Oligodendroglioma Anaplásico, Oligoastrocitoma Anaplásico, Ependimoma Anaplásico (Grau III)**  
- **2.1 Gliomas Grau IIII e IV: bevacizumabe em diferentes combinações**

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 53 - Características dos estudos que compararam bevacizumabe em diferentes combinações em gliomas de grau III e IV.** -->
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de**<br>**glioma)**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Yonezawa**<br>**et al. 2017**<br>**(195)**|Observacional,<br>retrospectivo,<br>comparativo|Elucidar o<br>efeito do<br>BEVA na<br>sobrevida<br>global|Gliomas malignos<br>não ressecados<br>(**Grau III**(n): 28;<br>astrocitoma<br>anaplásico (n): 19;<br>oligodendroglioma<br>anaplásico: 9;<br>gliobastoma (**grau**<br>**IV**), (n): 60|Os pacientes foram<br>divididos em 3 grupos:<br>1) Grupo 1: 88 pacientes<br>com gliomas malignos<br>não ressecados (BEVA<br>n: 24; não BEVA: 64);<br>2) Grupo 2: 41 pacientes<br>com gliomas malignos<br>não ressecados que<br>receberam<br>quimioradioterapia|Grupo 1:<br>receberam<br>BEVA<br>Grupo 2:<br>receberam<br>BEVA<br>Grupo 3:<br>receberam<br>BEVA|Grupo 1: não<br>utilizaram BEVA<br>Grupo 2: não<br>utilizaram BEVA<br>Grupo 3: não<br>utilizaram BEVA|**Alto risco de**<br>**viés**<br>(Não<br>representativo<br>da população;<br>não houve<br>controle de<br>confundidores;<br>coleta de<br>dados<br>retrospectiva)|  
219  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de**<br>**glioma)**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|||||baseada em TMZ<br>(BEVA: 22; não BEVA:<br>19);||||
|||||3) Grupo 3: 31 pacientes<br>com gliobastomas não<br>ressecados que<br>receberam<br>quimioradioterapia<br>baseada em TMZ<br>(BEVA: 20; não BEVA:<br>11)||||
|**Wiestler**<br>**et al. 2014**<br>**(196)**|Observacional,<br>retrospectivo,<br>comparativo|Avaliar a<br>sequência<br>ótima do uso<br>de BEVA e NU|Gliomas<br>recorrentes<br>primários (**Grau**<br>**III**: BEVA → NU,<br>(n): 4; NU →<br>BEVA, (n):5;<br>**grau IV**: BEVA<br>→ NU, (n): 11;<br>NU → BEVA, (n):<br>22)|42 pacientes (BEVA →<br>NU, (n): 15; NU→<br>BEVA, (n): 27)|Sequencialmente<br>BEVA → NU<br>(carmustina ou<br>nimustina)<br>**(BEVA**→**NU)**|Sequencialmente<br>NU (carmustina ou<br>nimustina) →<br>BEVA<br>**(NU**→**BEVA)**|**Alto risco de**<br>**viés**<br>(Não<br>representativo<br>da população;<br>não houve<br>controle de<br>confundidores;<br>coleta de<br>dados<br>retrospectiva)|  
220  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de**<br>**glioma)**|**Número de estudos e**<br>**participantes incluídos**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Niyazi et**<br>**al. 2012**<br>**(197)**|Observacional,<br>retrospectivo,<br>comparativo|Comparar os<br>desfechos dos<br>pacientes que<br>receberam re-<br>irradiação<br>baseados em<br>BEVA com<br>aqueles sendo<br>retratados sem<br>o BEVA|Gliomas<br>recorrentes<br>malignos tratados<br>com re-irradiação<br>e BEVA**(grau**<br>**III:**5;**grau IV**:<br>15) e sem BEVA<br>(**grau III:**3;**grau**<br>**IV**:7)|30 pacientes (BEVA: 20;<br>sem BEVA: 10 (7 sem<br>substância adicional e 3<br>com TMZ))|Pacientes em<br>retratamento com<br>RT + BEVA<br>**(RE-RT +**<br>**BEVA)**|Pacientes em<br>retratamento com<br>RT sem substância<br>adicional ou em<br>combinação com<br>RT<br>**(RE- RT)**|**Alto risco de**<br>**viés**<br>(Não<br>representativo<br>da população;<br>não houve<br>controle de<br>confundidores;<br>coleta de<br>dados<br>retrospectiva)|  
BEVA: bevacizumabe; NU: nitrosoureias; RT: radioterapia Re- RT: re- irradiação; TMZ: temozolamida.  
221  
**Tabela 54 - Características dos participantes estudos que compararam bevacizumabe em diferentes combinações em gliomas de grau III e IV.**  
|**Autor, ano**|**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana**<br>**(min-max)**|<br>**Idade**<br>**Controle**<br>**Mediana**<br>**(min-max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|**Yonezawa**<br>**et al. 2017**|Grupo 1<br>BEVA;<br>Grupo 2<br>BEVA;<br>Grupo 3<br>BEVA|Grupo 1<br>não<br>BEVA;<br>Grupo 2<br>não<br>BEVA;<br>Grupo 3<br>não<br>BEVA|Média (DP):<br>Grupo 1<br>BEVA: 65.3<br>(21.2)<br>Grupo 2<br>BEVA: 64.9<br>(21.8)<br>Grupo 3<br>BEVA: 67.9<br>(20.4)|Média (DP):<br>Grupo 1 não<br>BEVA: 67.9<br>(17.5)<br>Grupo 2 não<br>BEVA: 69.5<br>(18.3)<br>Grupo 3 não<br>BEVA: 67.2<br>(21.9)|(n):<br>Grupo 1<br>BEVA: 10;<br>Grupo 2<br>BEVA: 9<br>Grupo 3<br>BEVA: 8|(n):<br>Grupo 1 não<br>BEVA: 34;<br>Grupo 2  não<br>BEVA: 10;<br>Grupo 3 não<br>BEVA: 4|**EP 0,2 (n):**<br>Grupo 1 BEVA<br>(13); Grupo 2<br>BEVA (13);<br>Grupo 3 BEVA<br>(12);<br>**EP 3,4 (n):**<br>Grupo 1 BEVA<br>(11); Grupo 2<br>BEVA (9);<br>Grupo 3 BEVA<br>(8)|**EP 0,2 (n):**<br>Grupo 1 não<br>BEVA (30);<br>Grupo 2 não<br>BEVA (10);<br>Grupo 3 não<br>BEVA (3);<br>**EP 3,4 (n):**<br>Grupo 1 não<br>BEVA (34);<br>Grupo 2 não<br>BEVA (9);<br>Grupo 3 não<br>BEVA(8);|Mediana<br>(min-max):<br>263 dias (10-<br>2417 dias)|
|**Wiestler et**<br>**al. 2014**|BEVA →<br>NU|NU →<br>BEVA|Média (mín-<br>max): 51.4<br>(30–69)|Média (mín-<br>max): 49.2<br>(21–69)|NR|NR|**KPI,** **mediana**<br>**(min-max):**80<br>(70–90)|**KPI, mediana**<br>**(min-max):**80<br>(70–100)|NR|
|**Niyazi et**<br>**al. 2012**|RE-RT +<br>BEVA|RE- RT|50.0|61.5|n:12|n: 5|**KPS**<70, (n): 6<br>KPS ≥ 70, (n): 14|**KPS**<70, (n): 5<br>KPS ≥ 70, (n): 5|Mediana<br>(min-<br>max):137<br>dias (5-464<br>dias)|  
222  
BEVA: bevacizumabe; NU: nitrosoureias; RT: radioterapia Re- RT: re- irradiação; TMZ: temozolamida; min-max: mínimo e máximo; EP ECOG: estado de performance do Grupo de Oncologia Cooperativa Oriental; KPS: Escore de performance de Karnofsky, varia de 0 a 100 sendo que números maiores indicam melhor função; KPI: índice de performance de Karnosky; TMS: tempo máximo de sobrevida, obtido no gráfico de Kaplan-Meier do estudo; EP: estado de performance; DP: desvio padrão.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 55 - Desfechos de eficácia dos estudos que compararam bevacizumabe em diferentes combinações em gliomas de grau III e IV.** -->
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
|**Yonezawa**<br>**et al. 2017**|Grupo 1<br>BEVA;<br>Grupo 2<br>BEVA<br>;<br>Grupo 3<br>BEVA|Grupo 1 não<br>BEVA;<br>Grupo 2 não<br>BEVA;<br>Grupo 3 não<br>BEVA|**SG do Grupo 1 (BEVA vs.**<br>**Não BEVA)**<br>Tempo de sobrevivência<br>mediana (TSM): 566 vs.<br>243 dias<br>HR: 0.413 (IC 95%: 0.216,<br>0.787)<br>**SG do Grupo 2 (BEVA vs.**<br>**Não BEVA)**<br>TSM: 568 vs. 334 dias<br>HR: 0.404 (IC 95%: 0.175,<br>0.933)<br>**SG do Grupo 3(BEVA vs.**|0.003<br>0.016<br>0.001|NR|NR|**Fatores de**<br>**prognósticos para**<br>**sobrevivência - modelo**<br>**multivariado de COX**<br>**(A) n:72, receberam**<br>**terapia adjuvante**<br>**depois da biópsia; B)**<br>**n:41, que receberam**<br>**quimioterapia baseada**<br>**em TMZ depois da**<br>**biópsia):**<br>Grau III= A) HR: 0.453;<br>B) HR: 0.207|<br>A)<br>0.0110;<br>B) 0.03<br>A)<br><0.0001;|  
223  
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
||||**Não BEVA)**<br>TSM: 566 vs.160 dias<br>HR: 0.253 (IC 95%: 0.099,<br>0.646)||||EP (0,1,2): A) HR:<br>0.201; B) 0.135<br>BEVA: A) HR: 0.199;<br>B) 0.101|B)<br>0.0017<br>A)<br>0.0002;<br>B)<br>0.0002|
||||**SG mediana:**<br>BEVA → NU: 11.1 meses<br>(IC 95%: 8.4, 14.7)<br>NU → BEVA: 11.1 meses<br>IC 95%: 8.6, 14.6)|0.88*|**SLP mediana no**<br>**primeiro tratamento:**<br>BEVA no grupo<br>BEVA → NU: 5.3<br>meses (IC 95%: 4.1,<br>8.3)<br>NU no grupo NU →<br>BEVA: 2.8 meses (IC|0.02*|**Taxa de resposta**<br>**(critério RANO), (%):**<br>**1) Com o primeiro**<br>**tratamento**:<br>BEVA → NU: 27%<br>NU → BEVA: 0%<br>**2) Com o segundo**||
|**Wiestler**|BEVA →|NU → BEVA|||95%: 2.7, 4)||**tratamento:**||
|**et al. 2014**|NU||**SG mediana de todos os**<br>**participantes (n: 42), por**<br>**grau do glioma OMS:**<br>Grau III (n:9): 12.1 meses<br>(IC 95%: 5.5, 20.9)<br>Grau IV (n:33): 11.2 meses<br>(IC 95%: 9.1, 13.3)|Grau<br>III vs.<br>Grau<br>IV:<br>0.5668|**SLP mediana no**<br>**segundo tratamento:**<br>NU no grupo BEVA<br>→ NU: 2.9 meses (IC<br>95%: 1.9, 3.2)<br>BEVA no grupo NU<br>→ BEVA: 4.1 meses<br>(IC 95%: 2.7,4.9)|0.19*<br>0.03|BEVA → NU: 0%<br>NU → BEVA: 26%<br>**TTF:**<br>BEVA → NU: 9.6<br>meses (IC 95%: 7.0,<br>13.3)<br>NU → BEVA :9.2<br>meses(IC 95%: 7.1,|0.4216*<br>0.09*|  
224  
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
||||||**Tempo mediano para**<br>**PD com o uso do**<br>**BEVA foi maior**<br>**quando o BEVA foi**<br>**usado primeiro:**|0.5816|10.5)<br>**TFS:**<br>BEVA → NU: 9.6<br>meses (IC 95%: 7.0,<br>13.3)|Grau III<br>vs. Grau|
||||||(5.3 vs. 4.1 meses)||NU → BEVA :9.2|IV:|
||||||||meses (IC 95%: 7.1,|0.934|
||||||**Tempo mediano para**||10.5)||
||||||**PD com o uso das NU**|||Grau III|
||||||**foi similares para**<br>**ambos os grupos:**<br>(2.9 vs. 2.8 meses)|T1 vs.<br>T2:<br>0.0469|**TTF de todos os**<br>**participantes (n:42),**<br>**por grau do glioma**<br>**OMS:**|vs. Grau<br>IV:<br>0.6984|
||||||**SLP do BEVA por**||Grau III (n:9): 9.6||
||||||**tipo de progressão:**|T1 vs.|meses (IC 95%:4.1,||
||||||**Progressão T1**<br>**(contraste**<br>**aumentado) vs.**|T2:<br>0.2486|14.6)<br>Grau IV (n:33): 8.6<br>meses (IC 95%: 7.6,||
||||||**Progressão T2**<br>**(contraste não**<br>**aumentado):**<br>BEVA → NU: 5.75||10.7)<br>**TFS de todos os**<br>**participantes (n:42),**||
||||||(4.2 – 11.0) vs. 4.1<br>(2.3 – NA)||**por grau do glioma**<br>**OMS:**<br>Grau III (n:9): 2.0||
||||||NU → BEVA: 4.6||meses(IC 95%: 0.5,||  
225  
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor**<br>**p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
||||||(2.5 – 5.0) vs. 4.0 (1.5<br>– NA)||4.1)<br>Grau IV (n:33): 1.7<br>meses (IC 95%:1.2,<br>2.5)||
|**Niyazi et**<br>**al. 2012**|RE-RT +<br>BEVA|RE- RT|**SG mediana**<br>RE-RT + BEVA: NR♦<br>RE-RT: 175 dias<br>**Média de sobrevivência:**<br>RE-RT + BEVA: 367.6 dias<br>RE-RT: 187.4 dias|NR<br>0.03*|**SLP mediana**<br>RE-RT + BEVA: 243<br>dias<br>RE-RT: 143 dias<br>**SLP aos 6 meses:**<br>RE-RT + BEVA: 72%<br>RE-RT: 24%|0.045*|**Fatores de**<br>**prognósticos e/ou**<br>**preditivos para**<br>**sobrevivência - modelo**<br>**multivariado de COX**<br>**(n:30):**<br>KPS<70; KPS ≥ 70=<br>HR: 0.051<br>BEVA (sim/ não) = HR:<br>0.139<br>Grau na recorrência (III/<br>IV) =<br>HR: 0.029|0.011<br>0.025<br>0.007|  
Valor de p Intervenção versus Controle*; BEVA: bevacizumabe; NU: nitrosoureias; RT: radioterapia Re- RT: re- irradiação; TMZ: temozolamida; SLP: sobrevida livre de progressão; SG: sobrevida global; SO: taxa de sobrevivência; PD: progressão da doença; QVRS: qualidade de vida relacionada à saúde; ♦Não foi possível calcular SG mediana porque muitos desses pacientes foram censurados e a curva de sobrevivência ficou a níveis inferiores  de 50 %; TTF: Tempo para falha no tratamento, engloba o tempo desde o início de um tratamento até a data de falha do outro; TFS: Sobrevivência na falha  
226  
do tratamento, variou desde a data da progressão no segundo tratamento até a morte; HR: hazard ratio; IC 95%: intervalo de confiança de 95%; NR: não reportado.  
227  
**Tabela 56 - Desfechos de segurança dos estudos que compararam bevacizumabe em diferentes combinações em gliomas de grau III e IV.**  
||**Wiestle**|**r et al. 2014**||**Niyazi e**|**t al. 2012**||
|---|---|---|---|---|---|---|
|**Eventos Adversos**|**BEVA**→**NU**<br>**vs.**<br>|**NU**→**BEVA**|**Valor**<br>**p**|**RE-RT +**<br>**BEVA v**|**BEVA**|**Valor**<br>**p**|
|Hemorragia<br>Cerebral|n: 0|n: 1|NR|n (%): 0 (0%)|NR|NR|
|Eventos<br>tromboembolíticos|NR||NR|Grau 3, n (%):<br>1(5%)|NR|NR|
|Trombocitopenia|Grau 3 (n),<br>leuco-<br>trombopenia: 1|Grau 3 (n),<br>leuco-<br>trombopenia:<br>0|NR|NR||NR|
|Fadiga|NR||NR|Grau 2, n (%):<br>1(5%)|NR|NR|
|Hipertensão|NR||NR|Grau 2, n (%):<br>1(5%)|NR|NR|
|Cicatrização<br>com<br>complicações|NR||NR|Grau 4, n (%):<br>1(5%)|NR|NR|
|||||Grau 2, (n): 2|||
|Quaisquer EA|NR||NR|Grau 3, (n): 1|NR|NR|
|||||Grau 4, (n): 1|||
|A) Descontinuação<br>B) interrupção ou<br>ajuste devido à EA<br>sérios|n: 1 (devido ao<br>NU)|n: 1 (devido<br>ao NU)|NR|NR||NR|
|Morte devido ao<br>tratamento|n: 0|n: 0|NR|NR||NR|  
EA: eventos adversos; BEVA: bevacizumabe; NU: nitrosoureias; Re- RT: re- irradiação; NR: não reportado.  
228  
229

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.1 Glioma de grau III: estudos de fase II que analisaram o uso do bevacizumabe monoterapia ou em combinação com irinotecano** -->
**Tabela 57 - Características dos estudos que analisaram bevacizumabe monoterapia ou em combinação com irinotecano em gliomas de grau III.**  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de**<br>**Viés**|
|---|---|---|---|---|---|---|---|
|**Reardon et**<br>**al. 2012**<br>**(198)**|Análise<br>combinada<br>de três série<br>de casos<br>(um braço),<br>fase II|Performar uma análise<br>combinada de pacientes<br>de três ensaios clínicos<br>de fase II do BEVA e<br>combinações específicas<br>para avaliar os<br>desfechos gerais após a<br>descontinuação do<br>BEVA devido à PD e<br>receberam terapia<br>adicional com ou sem<br>BEVA|<br>Pacientes com<br>Glioma recorrente<br>maligno de**grau III**<br>que descontinuaram<br>o BEVA devido à<br>PD e receberam<br>adicional terapia|96 participantes<br>de 3 ensaios<br>clínicos de fase II.<br>Desses, 49<br>receberam terapia<br>adicional (BEVA:<br>23 (47%); não<br>BEVA: 26 (53%)|<br>Após PD,<br>receberam terapia<br>adicional:<br>continuaram a<br>receber BEVA<br>(BEVA)|Após PD,<br>receberam<br>terapia<br>adicional não<br>BEVA<br>(somente<br>quimioterapia)<br>(não BEVA)|**Alto risco**<br>**de viés**<br>Série de<br>casos para<br>avaliar<br>eficácia;|
|**Kreisl et al.**<br>**2011 (199)**|Série de<br>casos (um<br>braço), fase<br>II|Avaliar a atividade do<br>BEVA como agente<br>único e analisar sua<br>correlação com<br>parâmetros de imagens|Gliomas<br>anaplásicos<br>(astrocitoma<br>anaplásico: 68%;<br>oligoastrocitoma<br>anaplásico: 19%;<br>oligodendroglioma<br>anaplásico: 13%)|31 participantes|BEVA (10mg/ kg<br>a cada 14 dias)|NA|**Alto risco**<br>**de viés**<br>Série de<br>casos para<br>avaliar<br>eficácia;|  
230  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População (Tipo/**<br>**estágio de glioma)**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Risco de**<br>**Viés**|
|---|---|---|---|---|---|---|---|
|**Chamberlain**<br>**e Johnston,**<br>**2009 (200)**|Série de<br>casos (um<br>braço), fase<br>II|Determinar a eficácia do<br>BEVA|**Grau III**do tipo<br>Oligodendrogliomas<br>anaplásicos<br>(codeleção 1p19q)<br>recorrentes<br>refratários com<br>RT/TMZ|22 participantes|BEVA (10mg/ kg<br>a cada 14 dias)|NA|**Alto risco**<br>**de viés**<br>Série de<br>casos para<br>avaliar<br>eficácia;|
|**Chamberlain**<br>**e Johnston,**<br>**2009b (201)**|Série de<br>casos (um<br>braço), fase<br>II|Determinar a eficácia do<br>BEVA|**Grau III**do tipo<br>Astrocitoma<br>anaplásico<br>recorrentes<br>refratários com<br>RT/TMZ/ NU|25 participantes|BEVA (10mg/ kg<br>a cada 14 dias)|NA|**Alto risco**<br>**de viés**<br>Série de<br>casos para<br>avaliar<br>eficácia;|
|**Desjardins et**<br>**al. 2008**<br>**(202)**|Série de<br>casos (um<br>braço), fase<br>II|Reportar a eficácia e<br>segurança do BEVA +<br>IRI|Gliomas grau III<br>(astrocitoma<br>anaplásico: 25<br>(76%);<br>oligodendroglioma<br>anaplásico: 8<br>(24%)) recorrentes<br>após terapia padrão<br>RT/TMZ|33 participantes<br>(1ª Coorte:9; 2ª<br>Coorte:24)|**1ª Coorte:**BEVA<br>(10mg/ kg + IRI a<br>cada 14 dias),<br>coorte de<br>segurança;<br>**2ª Coorte:**BEVA<br>(15mg/ kg + IRI<br>nos dias 1,8, 22 e<br>29 em um ciclo de<br>42 dias). Ambas<br>coortes a dosagem|NA|**Alto risco**<br>**de viés**<br>Série de<br>casos para<br>avaliar<br>eficácia;|  
231  
|**Autor**|**Desenho do**<br>**estudo**|**O**|**bjetivo**<br>**P**<br>**es**|**opulação (Tipo/**<br>**tágio de glioma)**|**Número**<br>**estudos**<br>**participa**<br>**incluíd**|**de**<br>**e**<br>**ntes**<br>**os**<br>**Intervenção**|**Controle**|**Risco de**<br>**Viés**|
|---|---|---|---|---|---|---|---|---|
|EVA: bevaci<br>**bela 58 - Ca**<br>**omas de gra**|zumabe; IRI: iri<br>**racterísticas d**<br>**u III.**|notecano;<br>**os partici**|NU: nitrosoureias;<br>**pantes dos estudo**|RT: radioterapia;<br>**s que analisaram**|TMZ: temozo<br>**bevacizuma**|de IRI foi de 340<br>mg/m2 e 125 mg/<br>m2 para aqueles<br>que utilizavam e<br>não utilizavam<br>drogas<br>antiepilépticas<br>indutoras<br>enzimáticas,<br>respectivamente<br>lamida; PD: progressão da do<br>**be monoterapia** **ou em com**|ença.<br>**binação com i**|**rinotecano em**|
|**Autor, ano**|**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana (min-**<br>**max)**|**Idade Controle**<br>**Mediana (min-**<br>**max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|<br>**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**<br>**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
||||Idade que iniciou|Idade que||**KPS**<90, n|**KPS**<90,||
|**Reardon et**<br>**al. 2012**|BEVA|Não<br>BEVA|terapia<br>subsequente: 46<br>(24–68)|iniciou terapia<br>subsequente: 46<br>(25–62)|17 (74%)|16 (62%)<br>(%): 16 (70%)<br>KPS ≥ 90, n<br>(%): 7(30%)|<br>n (%): 19<br>(73%)<br>KPS≥90,|NR|  
BEVA: bevacizumabe; IRI: irinotecano; NU: nitrosoureias; RT: radioterapia; TMZ: temozolamida; PD: progressão da doença. **Tabela 58 - Características dos participantes dos estudos que analisaram bevacizumabe monoterapia ou em combinação com irinotecano em gliomas de grau III.**  
232  
|**Autor, ano**|**Intervenção**|**Controle**|**Idade**<br>**Intervenção**<br>**Mediana (min-**<br>**max)**|**Idade Controle**<br>**Mediana (min-**<br>**max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|||||||||n (%): 7<br>(27%)||
||||||||**KPS**mediano:<br>90% (mín- max:<br>60–100)|||
|**Kreisl et al.**<br>**2011**|BEVA|NA|44 (24-66)|NA|n: 21|NA|58% dos<br>pacientes<br>utilizavam<br>esteroides|NA|NR|
|**Chamberlain**<br>**e Johnston,**<br>**2009**|BEVA|NA|51 (24-60)|NA|13 (59%)|NA|**KPS mediano:**<br>80 (mín- max:<br>60–100)|NA|NR|
|**Chamberlain**|||||||**KPS mediano:**|||
|**e Johnston,**<br>**2009b**|BEVA|NA|50 (26–63)|NA|15 (60%)|NA|80(mín- max:<br>70–100)|NA|NR|
||||||||**KPS**, n (%):<br>100: 3 (9%)|||
|**Desjardins et**<br>**al. 2008**|BEVA +<br>IRI|NA|43 (22–62)|NA|22 (67%)||90: 15 (46%)<br>80: 12 (36%)<br>70:  3 (9%)<br>**Uso de**|NA|Mediana: 106<br>semanas|  
233  
|**Autor, ano**|**Intervenção**<br>**Controle**|**Idade**<br>**Intervenção**<br>**Mediana (min-**<br>**max)**|**Idade Controle**<br>**Mediana (min-**<br>**max)**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas**<br>**relevantes**<br>**Controle**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|
|||||||**corticosteroides**<br>(n): 12|||  
BEVA: bevacizumabe; IRI: irinotecano; min-max.: mínimo e máximo; NA: não se aplica; TMS: tempo máximo de sobrevida, obtido no gráfico de Kaplan-Meier do estudo.  
**Tabela 59 - Desfechos de eficácia dos estudos que analisaram bevacizumabe monoterapia ou em combinação com irinotecano em gliomas de grau III.**  
|**Autor, ano**|**Intervenção**<br>|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
|**Reardon et**<br>**al. 2012**|BEVA|Não<br>BEVA|**A) SG mediana; taxa de**<br>**SO B) aos 6 meses; C)**<br>**aos 12 meses; D) aos 24**<br>**meses após o início da**<br>**terapia adicional com:**<br>BEVA: A) 9.2 meses (IC<br>95%: 5.2, 13.6); B) 69.6<br>(IC 95%: 46.6, 84.2); C)<br>31.4 (IC 95%:13.4, 51.3);<br>D)15.7(IC 95%: 4,34.5)|0.9103*|**A) SLP mediana;**<br>**taxa de SLP B) aos 6**<br>**meses; C) aos 12**<br>**meses; D) aos 24**<br>**meses após o início**<br>**da terapia adicional**<br>**com:**<br>BEVA: A) 3.8 meses<br>(IC 95%:2.1, 6.9); B)<br>39.1%(IC|0.5082*|**Fatores de prognósticos**<br>**para sobrevivência -**<br>**modelo multivariado de**<br>**COX:**<br>Uso de dexametasona nos<br>ensaios clínicos com<br>BEVA (sim/não) = HR:<br>3.83 (C 95%:1.87, 7.86)|0.0002|  
234  
|**Autor, ano**|**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||Não BEVA: A) 10.3<br>meses (IC 95%: 2.5, 14.4);<br>B) 57.7 (IC 95%: 36.8,<br>73.9); C) 38.5 (IC 95%:<br>20.4, 56.3); D) 26.9 (IC<br>95%: 11.9, 44.5)||95%:19.9%, 58%); C)<br>17.4 (IC 95%: 5.4, 35);<br>D). Não disponível<br>Não BEVA: A) 1.9 (IC<br>95%:1.2, 4.1); B) 23.1<br>(IC 95%: 9.4, 40.3); C)<br>11.5 (IC 95%:2.9,<br>26.7); D) 11.5 (IC<br>95%: 2.9,26.7)||||  
235  
|**Autor, ano**|**Intervenção**|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
|**Kreisl et al.**<br>**2011**|BEVA|NA|**SG mediana:**12 meses<br>(IC 95%: 6.08- 22.8)<br>**SG mediana para**<br>**aqueles com:**<br>A) Média VTA acima de -<br>48.9%: 6.25 meses<br>B) Média VTA abaixo de -<br>48.9%: 28.04 meses|A vs.<br>B:<br>0.0008|**SLP mediana:**2.93<br>meses (IC 95%: 2.01,<br>4.93)<br>**Taxa de SLP aos 6**<br>**meses:**20.9% (IC<br>95%: 10.3, 42.5%)<br>**SLP mediana para**<br>**aqueles com:**<br>A) Média VTA acima<br>de -48.9%: 1.84 meses<br>B) Média VTA abaixo<br>de -48.9%: 4.12 meses|A vs.<br>B:<br>0.0296|**Taxa de resposta**<br>**(critério MacDonald),**<br>**(n=30):**<br>Geral: a) 67% (20<br>respostas parciais); b)<br>43% (13 respostas<br>parciais)<br>Média de duração de<br>resposta: 9. 07 meses<br>(DP: 7.27)<br>Doença estável por > 2<br>meses, n(%): 8 (26%)<br>**Parâmetros de imagens**<br>**de ressonância**<br>**magnética medidos em**<br>**a) 4 dias e b) 4 semanas**<br>**1) Diminuição da Média**<br>**VTA:**<br>a**)**43.5%; b) 56.6% e<br>**2) Diminuição da Média**<br>**de K trans:**<br>a) 30.8%; b) 51.9%<br>**3) Diminuição de fpv:**<br>a)21.4%;b)45.9%|<br> <br> <br>a)<br><0.001;<br>b)<br><0.001<br>a) 0.001;<br>b)<br><0.001<br>a)<br>0.0082;<br>b)<br><0.001|  
236  
|**Autor, ano**|**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||||**1) Parâmetros**<br>**relacionados com risco**<br>**de morte- Modelo**<br>**univariado de COX:**<br>a) VTA em 4 dias após a<br>linha de base=  HR: 1.82<br>b) VTA em 4 semanas<br>após a linha de base=HR:<br>1.44<br>c) ∆ VTA entre a linha de<br>base e 4 dias= HR:1.89|a) 0.031<br>b)<br>0.0455<br>c)<br><0.0001|
|||||||**2) Parâmetros**<br>**relacionados com risco**<br>**de PD- Modelo**<br>**univariado de COX:**<br>a) ∆ VTA entre a linha de<br>base e 4 dias= HR:2.22<br>b) ∆ VTA entre a linha de<br>base e 4 dias= HR: 1.28<br>**- Modelo multivariado**<br>**de COX:**∆ VTA entre a<br>linha de base e 4 dias|a)<br><0.0001<br>b)<br>0.0047<br><0.01|  
237  
|**Autor, ano**|**Intervenção**|<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
|**Chamberlain**<br>**e Johnston,**<br>**2009**|BEVA|NA|**SG mediana:**8 meses (IC<br>95%: 6.28, 9.72)<br>**Probabilidade de SO aos**<br>**a) 6 meses; b) 12 meses:**<br>a) 68%; b) 23%|NR|**SLP mediana:**<br>8 meses (IC 95%:<br>7.03, 8.97)|NR|**KPS, mediana (mín-**<br>**max)**: 60 (40-70)<br>**Taxa de resposta**<br>**(critério MacDonald), n**<br>**(%):**<br>Resposta completa: 0<br>(0%)<br>Resposta parcial: 14<br>(64%); (IC 95%: 44-84%)<br>Doença estável: 1 (5%);<br>(IC 95%: -4, 13%)<br>**Tempo para progressão**<br>**do tumor em pacientes**<br>**com resposta parcial ou**<br>**doença estável (n=16):**<br>8 meses (IC 95%: 7.02,<br>8.97)|NR|
||||||||**Uso de corticosteroides**<br>**(dexametasona), n (%):**<br>Redução de dose: 15<br>(68%)<br>Descontinuação: 10<br>(45%)||  
238  
|**Autor, ano**|**Intervenção**|<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
|**Chamberlain**|||**SG mediana:**9 meses (IC<br>95%: 6.6, 11.4)||**SLP mediana:**<br>7 meses (IC 95%: 4.5,<br>9.45)||**KPS, mediana (mín-**<br>**max):**60 (40-70)<br>**Taxa de resposta**<br>**(critério MacDonald), n**<br>**(%):**<br>Resposta completa: 0<br>(0%)<br>Resposta parcial: 16<br>(64%); (IC 95%: 45-83%)<br>Doença estável: 2 (8%);<br>(IC 95%: 3, 19%)||
|**e Johnston,**<br>**2009b**|BEVA|NA|**Probabilidade de SO aos**<br>**a) 6 meses; b) 12 meses:**<br>a) 76%; b) 36%||**SLP aos a) 6 meses;**<br>**b) 12 meses:**<br>a) 60%; b) 20%||**Tempo para progressão**<br>**do tumor em pacientes**<br>**com resposta parcial ou**<br>**doença estável (n=16):**<br>8 meses (IC 95%: 5, 20<br>meses)||
||||||||**Uso de corticosteroides**<br>**(dexametasona), n (%):**<br>Redução de dose: 16<br>(68%)<br>Descontinuação: 11<br>(44%)||  
239  
|**Autor, ano**|**Intervenção**<br>|**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|---|
||||**SG mediana:**||**SLP mediana:**|NR|||
||||AA + AO: 65 semanas<br>AO: 61 semanas<br>AA: 65 semanas|NR|AA + AO: 30 semanas<br>(IC 95%: 21- 60<br>semanas)||||
||||**Taxa de SO aos 6 meses:**||AO: 50 semanas (IC||||
||||AA + AO: 79% (IC 95%:||95%: 21, não||**Taxa de resposta**||
||||61, 89%)||determinado)||**(critério MacDonald)**||
||||AO: 88%||AA: 28 semanas (95%||Completa ou parcial: 20||
||||AA: 76%||CI, 17-60 semanas)||(61%)<br>Completa (n): 3||
|**Desjardins et**<br>**al. 2008**|BEVA +<br>IRI|NA|**Taxa de SO** **em a) 1 ano**<br>**e b) 2 anos**||**Taxa de** **SLP aos 6**<br>**meses**||Parcial (n): 17<br>Doença estável (n): 11|NR|
||||AA + AO: a) 55%; b) 32%||AA + AO: 55% (IC<br>95%: 36-70 semanas)||PD em 6 semanas (n): 2||
||||**Resposta do tumor**<br>**versus SG**||AO: 62% (IC 95%: 23,<br>86%)||**Uso de corticoides**<br>Redução de dose: 8 (67%)||
||||**a) SG  mediana; b)SO**||AA: 52% (IC 95%: 31,||Descontinuação: 5 (42%)||
||||**aos 6 meses; c) SO em**<br>**um ano; d) SO em dois**<br>**anos:**<br>**1)Resposta completa/**<br>**parcial (n=20)**<br>a)  80 semanas; b)  90%;|1 vs. 2:<br>0.1|69%)<br>**Taxa de SLP em a) 1**<br>**ano e b) 2 anos**<br>AA + AO: a) 39%; b)<br>11%|1 vs. 2:<br>0.09|||  
240  
|**Autor, ano**|**Intervenção**<br>**Controle**|**Sobrevida global (SG) /**<br>**taxa de Sobrevivência**<br>**(SO)**|**Valor p**|**Sobrevida livre de**<br>**progressão (SLP)**|**Valor p**|**Outros desfechos**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||c)  65% d) 38%<br>2)<br>**2) Doença estável/PD**<br>**(n:13)**<br>a)  31 semanas; b)  62%;<br>c)  39% d) 23%||**Resposta do tumor**<br>**versus SLP**<br>**a) SLP mediana;**<br>**b)SLP aos 6 meses; c)**<br>**SLP em um ano; d)**<br>**SLP em dois anos:**<br>**1)Resposta completa/**<br>**parcial (n=20)**<br>a) 50 semanas; b)<br>70%; c) 50% d) 15%<br>2)**Doença estável/PD**<br>**(n:13)**<br>a) 18 semanas; b)<br>31%; c) 23% d) não<br>disponível||||  
BEVA: bevacizumabe; IRI: irinotecano; min-max.: mínimo e máximo; NA: não se aplica; SLP: sobrevida livre de progressão; SG: sobrevida global; SO: taxa de sobrevivência; PD: progressão da doença; SLP: sobrevida livre de progressão; SG: sobrevida global; SO: taxa de sobrevivência; VTA: volume de tumor aumentado; Mapas paramétricos de K-trans: constante de transferência do vaso para o tecido; fpv: volume plasmático fracionado; AA: astrocitoma anaplásico; AO: oligodendroglioma anaplásico; HR: hazard ratio; IC 95%: intervalo de confiança de 95%; NR: não reportado.  
241  
**Tabela 60 - Desfechos de segurança dos estudos que analisaram bevacizumabe monoterapia ou em combinação com irinotecano em gliomas de grau III.**  
|**Eventos Adversos**|**Kreisl et al. 2012**<br>**BEVA**|**Valor**<br>**p**|**Chamberlain e**<br>**Johnston, 2009**<br>**BEVA**|**Valor**<br>**p**|**Chamberlain e**<br>**Johnston, 2009b**<br>**BEVA**|**Valor**<br>**p**|**Desjardins et al.**<br>**2008**<br>**BEVA + IRI**|**Valor**<br>**p**|
|---|---|---|---|---|---|---|---|---|
|**Isquemia Cerebral**|NR|NR|NR|NR|NR|NR|1°coorte:<br>Grau 4(n): 1|NR|
|**Hemorragia**<br>**Cerebral**|NR|NR|Grau 2 (n): 2|NR|NR|NR|2°coorte:<br>Grau 4(n): 1|NR|
||Epistaxe:<br>Grau 1 (n): 8;||||||||
|**Sangramento/**<br>**hemorragias**<br>**(outros)**|Grau 3 (n): 1<br>Hemorragia retal:<br>Grau 1 (n): 2;<br>Grau 2(n): 1|NR|NR|NR|NR|NR|NR|NR|
|**Eventos**<br>**tromboembolíticos**|Grau 4 (n): 2|NR|Tromboflebite<br>Grau 2 (n): 3<br>Grau 3 (n): 1|NR|Tromboflebite<br>Grau 2 (n): 3<br>Grau 3 (n): 2|NR|Trombose venosa<br>profunda<br>2°coorte:<br>Grau 3 (n): 3<br>Grau 4(n): 1|NR|
||||||||1°coorte:<br>Grau 1 (n): 1||
|**Diarréia**|NR|NR|NR|NR|NR|NR|Grau 2 (n): 3<br>2°coorte:<br>Grau 1(n): 6|NR|  
242  
|**Eventos Adversos**|**Kreisl et al. 2012**|**Valor**|**Chamberlain e**<br>**Johnston, 2009**|**Valor**|**Chamberlain e**<br>**Johnston, 2009b**|**Valor**|**Desjardins et al.**<br>**2008**|**Valor**|
|---|---|---|---|---|---|---|---|---|
||**BEVA**|**p**|**BEVA**|**p**|**BEVA**|**p**|**BEVA + IRI**|**p**|
||||||||1°coorte:<br>Grau 1 (n): 2<br>Grau 2 (n): 2||
|**Constipação**|NR|NR|Grade 2 (n): 4|NR|Grade 2 (n): 4|NR|2°coorte:<br>Grau 1 (n): 8<br>Grau 2 (n): 5<br>Grau 3(n): 7|NR|
|**Anemia**|Grau 1(n): 4|NR|Grade 2(n): 5|NR|Grade 2(n): 4|NR|NR|NR|
|**Leucopenia**|NR|NR|Grau 2 (n): 8;<br>Grau 3(n): 1|NR|Grau 2 (n): 6;<br>Grau 3(n): 1|NR|NR|NR|
||||||||1°coorte:<br>Grau 4 (n): 1||
|**Neutropenia**|NR|NR|NR|NR|NR|NR|2°coorte:<br>Grau 3 (n): 1<br>Grau 4(n): 2|NR|
|**Trombocitopenia**|Grau 1 (n): 6<br>Grau 2(n): 1|NR|NR|NR|NR|NR|2°coorte:<br>Grau 4(n): 1|NR|
|**Linfopenia/**<br>**Linfocitopenia**|Grau 1 (n): 1<br>Grau 2(n): 1|NR|NR|NR|NR|NR|NR|NR|  
243  
|**Eventos Adversos**|**Kreisl et al. 2012**|**Valor**|**Chamberlain e**<br>**Johnston, 2009**|**Valor**|**Chamberlain e**<br>**Johnston, 2009b**|**Valor**|**Desjardins et al.**<br>**2008**|**Valor**|
|---|---|---|---|---|---|---|---|---|
||**BEVA**|**p**|**BEVA**|**p**|**BEVA**|**p**|**BEVA + IRI**|**p**|
||||||||Náusea:<br>1°coorte:<br>Grau 1 (n): 3<br>Grau 3 (n): 1||
|**Náusea e vômito**|Náusea:<br>Grau 1 (n): 2<br>Vômito:<br>Grau 1 (n): 1|NR|Náusea<br>Grau 2 (n): 2|NR|Náusea<br>Grau 2 (n): 2|NR|2°coorte:<br>Grau 1 (n): 5<br>Grau 2 (n): 5<br>Grau 3 (n): 1<br>Vômitos<br>2°coorte:<br>Grau 1 (n): 5<br>Grau 2 (n): 3|NR|
||||||||Grau 3(n): 2||
||||||||1°coorte:<br>Grau 1 (n): 4<br>Grau 2 (n): 2||
|**Fadiga**|Grau 1 (n):3;<br>Grau 2 (n): 3|NR|Grau 2 (n): 10;<br>Grau 3 (n):4|NR|Grau 2 (n): 12;<br>Grau 3 (n):2|NR|Grau 3 (n): 1<br>2°coorte:<br>Grau 1 (n): 8<br>Grau 2 (n): 5|NR|
||||||||Grau 3(n): 2||  
244  
|**Eventos Adversos**|**Kreisl et al. 2012**|**Valor**|**Chamberlain e**<br>**Johnston, 2009**|**Valor**|**Chamberlain e**<br>**Johnston, 2009b**|**Valor**|**Desjardins et al.**<br>**2008**|**Valor**|
|---|---|---|---|---|---|---|---|---|
||**BEVA**|**p**|**BEVA**|**p**|**BEVA**|**p**|**BEVA + IRI**|**p**|
|**Hipertensão**|Grau 1 (n): 1;<br>Grau 2 (n): 4;<br>Grau 3 (n): 5|NR|Grau 2 (n): 4<br>Grau 3 (n): 1|NR|Grau 2 (n): 4;<br>Grau 3 (n): 1|NR|1°coorte:<br>Grau 2 (n): 1<br>2°coorte:<br>Grau 2(n): 1|NR|
|**Cicatrização com**<br>**complicações**|Grau 1 (n): 1|NR|Ferida pós- cirúrgica:<br>Grau 2 (n): 1<br>Grau 3(n): 1|NR|Ferida pós- cirúrgica:<br>Grau 3 (n): 1|NR|NR|NR|
|**Infecções**|NR|NR|Infecções sem<br>neutropenia Grau 2 (n):<br>2<br>Grau 3 (n): 1|NR|Infecções sem<br>neutropenia Grau 2 (n):<br>2<br>Grau 3 (n): 0|NR|Infecções normais<br>com contagem<br>absoluta de<br>neutrófilos<br>1°coorte:<br>Grau 2 (n): 1<br>Grau 3 (n): 1<br>2°coorte:<br>Grau 1 (n): 2<br>Grau 2 (n): 6<br>Grau 3 (n): 1<br>Grau 4(n): 1|NR|
|**Proteinúria**|Grau 1 (n): 8;<br>Grau 3(n): 1|NR|Grau 2 (n): 4|NR|Grau 2 (n): 4|NR|2°coorte:<br>Grau 3(n): 1|NR|  
245  
|**Eventos Adversos**<br>**K**|**reisl et al. 2012**|**Valor**|**Chamberlain e**<br>**Johnston, 2009**|**Valor**|**Chamberlain e**<br>**Johnston, 2009b**|**Valor**|**Desjardins et al**<br>**2008**|**.**<br>**Valor**|
|---|---|---|---|---|---|---|---|---|
||**BEVA**|**p**|**BEVA**|**p**|**BEVA**|**p**|**BEVA + IRI**|**p**|
||||Todos os graus (n): 57||Todos os graus (n): 50||||
|**Quaisquer EA**|NR|NR|Grau 2 (n): 48;<br>Grau 3(n): 9|NR|Grau 2 (n): 43;<br>Grau 3(n): 7|NR|NR|NR|
|**A) Descontinuação**|||||||||
|**B) interrupção ou**<br>**ajuste devido à EA**<br>**sérios**|NR|NR|n: 1|NR||NR|A) (n): 2;<br>B) 2° coorte (n):|9<br>NR|
|**Morte devido ao**<br>**tratamento**|NR|NR|n: 0|NR|n: 0|NR|n: 0|NR|  
BEVA: bevacizumabe; IRI: irinotecano; NR: não reportado.  
246  
**Questão de Pesquisa 8:** Quais os tratamentos preconizados no período pós-operatório em pacientes com Glioma grau I?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
<mark>(((((((((("glioma"[MeSH Terms] OR "glioma"[All Fields]) AND (low[All Fields] AND grade[All Fields])) OR grade[All Fields]) OR ("astrocytoma"[MeSH Terms] OR "astrocytoma"[All Fields])) OR pilocytic[All Fields]) AND ("adult"[MeSH Terms] OR "adult"[All Fields])) AND ("postoperative period"[MeSH Terms] OR ("postoperative"[All Fields] AND "period"[All Fields]) OR "postoperative period"[All Fields] OR "postoperative"[All Fields])))) AND (("drug therapy"[Subheading] OR ("drug"[All Fields] AND "therapy"[All Fields]) OR "drug therapy"[All Fields] OR "chemotherapy"[All Fields] OR "drug therapy"[MeSH Terms] OR ("drug"[All Fields] AND "therapy"[All Fields]) OR "chemotherapy"[All Fields]) OR ("radiotherapy"[Subheading] OR "radiotherapy"[All Fields] OR "radiotherapy"[MeSH Terms])) AND (randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR "clinical trials as topic"[MeSH Terms:noexp] OR randomly[tiab] OR trial[ti] NOT ("animals"[MeSH Terms] NOT "humans"[MeSH Terms]))</mark>  
<mark>Total: 750 referências</mark>  
<mark>Data de acesso: 03/08/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE:** -->
('glioma <mark>'/exp OR</mark> 'glioma' <mark>) AND [embase]/lim AND low AND grade AND [embase]/lim OR ('glioma'/exp OR 'glioma') AND [embase]/lim AND</mark> grad <mark>e AND i AND [embase]/lim [embase]/lim)</mark>  
<mark>OR</mark>  
('astrocytoma <mark>'/exp OR</mark> astrocytoma <mark>) OR ('</mark> pilocytic astrocytoma' <mark>/exp OR '</mark> pilocytic astrocytoma <mark>') AND [embase]/lim</mark>  
<mark>AND</mark>  
('chemotherapy'/exp OR 'chemotherapy') AND [embase]/lim OR ('radiotherapy'/exp OR 'radiotherapy') AND [embase]/lim  
247  
AND  
postoperativ <mark>e AND [embase]/lim</mark>  
<mark>AND</mark>  
('adult'/exp OR 'adult') AND [embase]/lim  
<mark>Total:  438 referências</mark>  
<mark>Data de acesso: 03/08/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2)** **<mark>Seleção das evidências</mark>** -->
Com o intuito de fazer a busca mais específica, utilizou-se filtros validados para os ensaios clínicos nas duas bases de dados citadas acima, visando a redução do quantitativo de bibliografia encontrada.  
<mark>A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 1188 referências (750 no MEDLINE e 438 no Embase). Destas, 11 foram excluídas por estarem duplicadas. Foi realizada busca manual que resultou em 03 (três) referências.</mark>  
<mark>Mil cento e oitenta e oito referências foram triadas por meio da leitura de título e resumos, das quais 31 tiveram seus textos completos avaliados para confirmação da elegibilidade.</mark>  
<mark>Vinte e quatro estudos foram excluídos: três ensaios clínicos por selecionar pacientes com glioma grau II; dezessete estudos observacionais por conter em sua população e resultados pacientes com glioma grau I, II e III; e quatro estudos observacionais que selecionaram pacientes com glioma grau I, entretanto, incluíram em sua população adultos e crianças e não estratificaram os resultados por faixa etária.</mark>  
<mark>Cinco estudos foram incluídos: estudos retrospectivos observacionais (203-207).</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>Os estudos serão apresentados de acordo com as comparações realizadas. A descrição sumária dos estudos, para os tratamentos preconizados no pós-operatório, em pacientes com glioma grau I, se encontra na Tabela 61. As características dos pacientes para esses estudos encontram-se na Tabela 62, os dados de desfechos de eficácia na Tabela 63.</mark>  
248  
249  
**Tabela 61 - Características dos estudos incluídos para tratamentos preconizados no pós-operatório em pacientes com glioma grau I.**  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes do tratamento**|**Risco de viés**|
|---|---|---|---|---|---|
|**Ye et al.**<br>**2014 (203)**|Estudo<br>retrospectivo<br>observacional<br>(série de casos)|Estudar os resultados da<br>cirurgia em adultos ≥ 17 anos<br>com astrocitoma pilocítico,<br>bem como identificar os fatores<br>que podem influenciar os<br>resultados|Pacientes adultos com<br>astrocitoma pilocítico|Quimioterapia<br>(Carboplatina)<br>Radioterapia (54 Gray)<br>em 30 frações|Alto<br>Série de casos,<br>descrição incompleta<br>dos desfechos.|
|**Johnson et**<br>**al. 2011**<br>**(204)**|Estudo coorte<br>retrospectiva|Construir uma perspectiva de<br>base populacional de adultos<br>portadores astrocitoma<br>pilocítico|Pacientes adultos com<br>astrocitoma pilocítico|Radioterapia|Alto<br>Natureza retrospectiva<br>dos dados, descrição<br>incompleta dos<br>desfechos.|
|**Ishkanian et**<br>**al. 2011**<br>**(205)**|Estudo<br>retrospectivo<br>observacional<br>(série de casos)|Analisar o impacto da<br>observação no pós-operatório<br>versus a radioterapia adjuvante<br>e reportar os resultados dos que<br>desenvolveram a progressão da<br>doença.|Pacientes adultos com<br>astrocitoma pilocítico|Radioterapia (50 Gray)<br>em 25 frações até seis<br>meses do pós-operatório<br>Terapia adjuvante|Alto<br>Série de casos.|
|**Ellis et al.**<br>**2009 (206)**|Estudo<br>retrospectivo<br>observacional<br>(série de casos)|Avaliar a frequência da<br>recorrência e a transformação<br>para a malignidade do<br>astrocitoma pilocítico em<br>adultos.|Pacientes adultos com<br>astrocitoma pilocítico|Radioterapia (54–60<br>Gray) em 30 – 33<br>frações<br>Radiocirurgia Gamma<br>Knife 22.7Gray|Alto<br>Série de casos, perda<br>de seguimento não<br>relatada.|
|**Brown et al.**<br>**2004 (207)**|Ensaio clínico<br>multicêntrico<br>(série de casos)|Obter dados clínicos e<br>resultados dos pacientes|Pacientes adultos com<br>astrocitoma pilocítico|Radioterapia (50.4 Gray)<br>em 28 frações<br>Progressão: Radioterapia<br>(55.8 Gray)|Alto<br>Série de casos<br>prospectiva, estudo sem<br>cegamento e<br>randomização,|  
250

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Detalhes do tratamento** -->
**Risco de viés** descrição incompleta dos desfechos.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **I.** -->
|**Autor,**<br>**ano**|**População**<br>**N (%)**|**QT/ RT +**<br>**terapia**<br>**adjuvante**<br>**n (%)**|**Pacientes**<br>**em**<br>**Observaçã**<br>**o**<br>**n(%)**|**Idade em**<br>**anos, média**<br>**(DP)**<br>**Intervenção**|**Sexo**<br>**masculi**<br>**no n**<br>**(%)**|**Recorrência QT/**<br>**RT + terapia**<br>**adjuvante**<br>**n**|**Recorrência**<br>**Observação**<br>**n (%)**|<br>**Tempo**<br>**de**<br>**recorrên**<br>**cia, (DP)**|**Tempo de**<br>**seguimento,**<br>**Mediana**<br>**(Mín-Máx.)**|
|---|---|---|---|---|---|---|---|---|---|
|**Ye et al.**<br>**2014**<br>**(203)**|STR:  10 (50)<br>GTR: 7 (35)<br>Biópsia: 1 (5)<br>ND:2(10)|QT: 2<br>RT: 1|NA|27<br>(Min-máx.:<br>17 - 52)|9 (45)|STR: 6<br>Cirurgia: 5|NA|4 - 36<br>Meses<br>(NR)|39 meses<br>(1 – 117)|
|**Johnson**<br>**et al.**<br>**2011**<br>**(204)**|STR: 199 (23)<br>GTR: 343<br>(39.8)<br>Biópsia: 164<br>(19)<br>Outros/<br>desconhecido:<br>90(10.4)|191 (22.1)|674 (77.9)|31 (19)|450 (52)|NR|NR|NR|66 meses (NR)|  
251  
|**Autor,**<br>**ano**|**População**<br>**N (%)**|**QT/ RT +**<br>**terapia**<br>**adjuvante**<br>**n (%)**|**Pacientes**<br>**em**<br>**Observaçã**<br>**o**<br>**n(%)**|**Idade em**<br>**anos, média**<br>**(DP)**<br>**Intervenção**|**Sexo**<br>**masculi**<br>**no n**<br>**(%)**|**Recorrência QT/**<br>**RT + terapia**<br>**adjuvante**<br>**n**|**Recorrência**<br>**Observação**<br>**n (%)**|<br>**Tempo**<br>**de**<br>**recorrên**<br>**cia, (DP)**|**Tempo de**<br>**seguimento,**<br>**Mediana**<br>**(Mín-Máx.)**|
|---|---|---|---|---|---|---|---|---|---|
||Sem<br>procedimento:<br>69 (18)|||||||||  
**<u>1ª Progressão:</u>** Cirurgia: 3 (27) RT: 5 (45) QT: 1 (9) Cirurgia + **<u>OBS:</u> Ishkania** STR: 17 (57) RT: 1 (9) Mediana Mediana QT: 2 **n et al.** GTR: 10 (33) 16 (63) Cirurgia + (mín87 meses (16RT: 11 (37) (mín-máx.): 20 (67) **2011** Biópsia: 3 Biópsia: 3 Cirurgia + QT: 1 QT: 1 (9) máx.): 4 420) 30 (18 - 64) **(205)** (10) (10) anos (NR) **<u>2ª Progressão:</u>** Cirurgia: 2 (29) RT: 1 (14) QT: 3 (43)  
252  
|**Autor,**<br>**ano**|**População**<br>**N (%)**|**QT/ RT +**<br>**terapia**<br>**adjuvante**<br>**n (%)**|**Pacientes**<br>**em**<br>**Observaçã**<br>**o**<br>**n(%)**|**Idade em**<br>**anos, média**<br>**(DP)**<br>**Intervenção**|**Sexo**<br>**masculi**<br>**no n**<br>**(%)**|**Recorrência QT/**<br>**RT + terapia**<br>**adjuvante**<br>**n**|**Recorrência**<br>**Observação**<br>**n (%)**|<br>**Tempo**<br>**de**<br>**recorrên**<br>**cia, (DP)**|**Tempo de**<br>**seguimento,**<br>**Mediana**<br>**(Mín-Máx.)**|
|---|---|---|---|---|---|---|---|---|---|
||||||||Cirurgia +<br>RT: 1 (14)|||  
**<u>Recorrência inicial: Recorrên</u>** RT **<u>cia inicial:</u>** fracionada: 2 Mediana (33) (mínRadiocirurgia: Mediana máx.): **Ellis et** 3 (50) STR: 5 (25) (mín-máx.): 16.5 (11– **al. 2009** 0 20 (100) 11 (55) NR GTR: 15 (75) 38 NA Reoperação: 1 46) **(206)** (21 - 62) (17) **<u>Recorrên cia Recorrência tardia: tardia:</u>** 17 (NR) * Reoperação: mediana 4 (67)  
253  
|**Autor,**<br>**ano**|**População**<br>**N (%)**|**QT/ RT +**<br>**terapia**<br>**adjuvante**<br>**n (%)**|**Pacientes**<br>**em**<br>**Observaçã**<br>**o**<br>**n(%)**|**Idade em**<br>**anos, média**<br>**(DP)**<br>**Intervenção**|**Sexo**<br>**masculi**<br>**no n**<br>**(%)**|**Recorrência QT/**<br>**RT + terapia**<br>**adjuvante**<br>**n**|**Recorrência**<br>**Observação**<br>**n (%)**|<br>**Tempo**<br>**de**<br>**recorrên**<br>**cia, (DP)**|**Tempo de**<br>**seguimento,**<br>**Mediana**<br>**(Mín-Máx.)**|
|---|---|---|---|---|---|---|---|---|---|  
Radiocirurgia: 2 (75) RT fracionada: 1 (25) STR: 6 (30) **Brown et** STR: 6 (30) Mediana GTR: 11 (55) Biópsia: **3** 0 STR: 1 (17) 18 meses 10 anos (6.1 – **al. 2004** GTR: 11 (mín-máx.): 7 (35) Biópsia: 3 (15) (NR) 14.8) **(207)** (55) 32 (20 - 47) <u>(15)</u>  
STR: ressecção subtotal; GTR: ressecção total; RT: radioterapia; QT: quimioterapia; <mark>OBS: grupo observação; N: total de pacientes</mark> **;** <mark>Mín-máx: valor mínimo – valor máximo; n: número de pacientes; (%): proporção de pacientes; NA: não se aplica; N</mark> R: não relatado; ND: não definido.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 63 - Desfechos de eficácia dos estudos para tratamentos preconizados no pós-operatório em pacientes com glioma grau I.** -->
|**Autor, ano**|**Sobrevida global**<br>**(IC 95%)**|**Sobrevida livre de progressão**<br>**(IC 95%)**|**Outros Desfechos de Sobrevida**<br>**(IC 95%)**|
|---|---|---|---|
||Sobrevida: 14 (70)|||
|**Ye et al.**||PFS: 60%|NR|
|**2014** (203)**|OS: 87%|Média: 68 meses (47 - 90)||
||Média:104 meses(87 - 121)|||  
254  
|**Autor, ano**|**Sobrevida global**<br>**(IC 95%)**|**Sobrevida livre de progressão**<br>**(IC 95%)**|**Outros Desfechos de Sobrevida**<br>**(IC 95%)**|
|---|---|---|---|
||||**Sobrevida Observada (%):**|
||||20 a 39 anos:<br>2 anos: 93.0 (90.5–94.8)<br>5 anos: 89.5 (86.5–91.8)|
||||40 a 59 anos:<br>2 anos: 86.5 (81.0–90.5)<br>5 anos: 77.0 (70.3–82.4)|
|**Johnson et al.**<br>**2011** (204)**|2 anos: 89.5% (87.2 – 91.4)<br>5 anos: 83.8% (81.0 – 86.3)|NR|60 ou mais:<br>2 anos: 65.9 (51.8–76.8)<br>5 anos: 52.9 (38.4–65.5)<br>**Sobrevida relativa (%):**<br>20 a 39 anos:<br>2 anos: 93.2 ( 90.7–95.0)<br>5 anos: 89.9 ( 86.9–92.3)|
||||40 a 59 anos:<br>2 anos: 87.2 (81.6–91.2)<br>5 anos: 78.5 (71.6–84.0)|
||||60 ou mais:<br>2 anos: 69.7 (54.3–80.8)<br>5 anos: 59.6 (42.5–73.1)|
||||**Cancer specific survival (CSS) (%):**|  
255  
|**Autor, ano**|**Sobrevida global**<br>**(IC 95%)**|**Sobrevida livre de progressão**<br>**(IC 95%)**|**Outros Desfechos de Sobrevida**<br>**(IC 95%)**|
|---|---|---|---|
||||20 a 39 anos:<br>2 anos: 94.1 (91.8–95.8)<br>5 anos: 92.3 (89.6–94.3)|
||||40 a 59 anos:<br>2 anos: 87.7 (82.3–91.5)<br>5 anos: 78.6 (71.9–83.9)|
||||60 ou mais:|
||||2 anos: 70.9 (56.9–81.1)<br>5 anos: 63.7 (48.8–75.3|
||||**Risco de morte:**<br>Idade: (HR 1.5 [1.4–1.7] cada 10 anos; p<br>< 0.0001)|
||||GTR em relação a STR/ biópsia: (HR<br>0.6 [ 0.3–0.9]; p = 0.0230)|
||||GTR em relação a pacientes que não<br>fizeram cirurgia/ ou cirurgia não<br>especificada: (HR 0.3 (0.1–0.4]; p =<br>0.0230)|
||||Pacientes que receberam radiação: (HR<br>2.7[1.9–4.0]; p<0.0001)|  
256  
|**Autor, ano**|**Sobrevida global**<br>**(IC 95%)**|**Sobrevida livre de progressão**<br>**(IC 95%)**|**Outros Desfechos de Sobrevida**<br>**(IC 95%)**|
|---|---|---|---|
|||Mediana: 8.4 anos (NR)||
||10 anos: 80% (mediana - NR)<br>5 anos: (RT: 100%) (OBS: 91%)|5 anos (população total): 37% (mediana -<br>3.7 anos)||
||10 anos: (RT: 81%) (OBS: 91%) (P = 0.94)<br>**1ª Progressão**:|5 anos: (RT: 91%) (OBS: 42%)<br>10 anos: (RT: 60%) (OBS: 17%) (p =<br>0.005)||
||OBS vs. terapia adjuvante (p = 0.43)|RT adjuvante pós-operatório: 5 e 10 anos<br>(p = 0.005)||
|**Ishkanian et**<br>**al. 2011 (205)**|**Resultado para pacientes que receberam**<br>**tratamento para a progressão**:|OBS vs. terapia adjuvante (p = 0.17)|NR|
||RT (após observação) (n=5) vs. cirurgia +<br>terapia adjuvante (n=5) (p = 1.0)|**1ª Progressão:**<br>OBS vs. terapia adjuvante (p = 0.17)||
||Cirurgia (n=3) vs. RT + terapia adjuvante<br>(n=6) (p = 1.0)|**Resultado para pacientes que**<br>**receberam tratamento para a**<br>**progressão**:||
||**2ª Progressão:**<br>5 anos: 63%|RT (n=5) vs. reoperação + terapia<br>adjuvante (n=5) (p = 0.70)<br>Cirurgia (n=3) vs. RT + terapia adjuvante<br>(n=6) (p=0.55)||
||||**Recorrência grupo observação:**|
|**Ellis et al. 2009**<br>**(206)**|NR|**Evolução:**3 (50) grau III|**12 meses:**94% (± 5%)<br>**24 meses:**76% (± 10%)|  
257  
|**Autor, ano**|**Sobrevida global**<br>**(IC 95%)**|**Sobrevida livre de progressão**<br>**(IC 95%)**|**Outros Desfechos de Sobrevida**<br>**(IC 95%)**|
|---|---|---|---|
||||**Mini-Mental State Examination: (%)**|
||||0 – 26 Meses: 01(5) cirúrgico|
||Sobrevida: 19 (95)<br>5 anos: 95% (75.13 - 99.87%)|5 anos: 95% (75.13 - 99.87%)<br>**GTR + STR (%):**|27 – 30 Meses: 09 (45) cirúrgico; 03<br>(15) biópsia<br>Desconhecido: 7 (41)|
|**Brown et al.**<br>**2004** (207)**|**GTR + STR (%):**<br>5 anos: 100% (30 - 100%)<br>**Biópsia (%):**<br>5 anos: 67% (30 - 100%)|5 anos: 94% (84 – 100)<br>**Biópsia (%):**<br>5 anos: 100% (84 – 100)|**Neurologic Function Score (%):**<br>0: 06 (30) cirúrgico; 01 (5) biópsia<br>1: 06 (30) cirúrgico; 01 (5) biópsia|
||||2: 01 (5) biópsia|
||||Desconhecido: 5 (25)|  
STR: ressecção subtotal; GTR: ressecção total; OBS: pacientes em observação; RT: radioterapia; OS: overall survival; PFS: progression free survival; CSS: cancer specific survival: porcentagem de pessoas em um grupo de estudo ou tratamento que não morreram de uma doença específica em um determinado período de tempo. O período de tempo, geralmente, começa no momento do diagnóstico ou no início do tratamento e termina no momento da morte. Pacientes que morreram de causas que não seja a doença que está sendo estudada não são contados nesta medição; Mini-Mental State Examination: o teste de exame de estado de Mini-Mental (MEEM) ou Folstein é um questionário de 30 pontos que é amplamente utilizado na clínica e pesquisa configurações para medir o comprometimento cognitivo; ** - desfechos relacionados a toda população (tratada e não tratada) participante do estudo; NR: não relatado; IC95%: intervalo de confiança de 95%; HR: Hazard ratio.  
258  
259  
**Questão de Pesquisa 9:** Quais os tratamentos preconizados no período pós-operatório em pacientes com Glioma grau II?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
((((((("Glioma"[Mesh] OR glioma)) OR (glioma AND low AND grade)) OR ("Astrocytoma"[Mesh] OR astrocytoma)) OR (astrocytoma AND grade AND ii)) OR (astrocytomas AND grade AND ii)) OR ("Oligodendroglioma"[Mesh] OR oligodendroglioma)) OR ("Ganglioglioma"[Mesh] OR ganglioglioma) AND ("adult"[MeSH Terms] OR "adult"[All Fields]) AND ((("postoperative period"[MeSH Terms] OR ("postoperative"[All Fields] AND "period"[All Fields]) OR "postoperative period"[All Fields] OR "postoperative"[All Fields]))) AND (((("drug therapy"[Subheading] OR ("drug"[All Fields] AND "therapy"[All Fields]) OR "drug therapy"[All Fields] OR "chemotherapy"[All Fields] OR "drug therapy"[MeSH Terms] OR ("drug"[All Fields] AND "therapy"[All Fields]) OR "chemotherapy"[All Fields]) OR ("radiotherapy"[Subheading] OR "radiotherapy"[All Fields] OR "radiotherapy"[MeSH Terms])))) AND (randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR "clinical trials as topic"[MeSH Terms:noexp] OR randomly[tiab] OR trial[ti] NOT ("animals"[MeSH Terms] NOT "humans"[MeSH Terms]))  
Total: 137 referências  
<mark>Data do acesso: 02/08/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE:** -->
(((('glioma'/exp OR 'glioma') AND [embase]/lim) OR (('astrocytoma'/exp OR 'astrocytoma') AND [embase]/lim) OR (('oligodendroglioma'/exp OR 'oligodendroglioma') AND [embase]/lim) OR (('ganglioglioma'/exp OR 'ganglioglioma') AND [embase]/lim) OR (('oligoastrocytoma'/exp OR 'oligoastrocytoma') AND [embase]/lim)) AND ((('postoperative period'/exp OR 'postoperative period') AND [embase]/lim) OR (('postoperative care'/exp OR 'postoperative care') AND [embase]/lim) OR ('postsurg*' AND [embase]/lim))) AND ('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR  
260  
random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti)  
Total: 265 referências  
<mark>Data do acesso: 02/08/2017</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das Evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 402 referências (137 MEDLINE e 265 no EMBASE). Destas, 33 foram excluídas por estarem duplicadas. Trezentos e sessenta e nove referências foram triadas por meio da leitura de título e resumos, <mark>das quais 18 tiveram seus textos completos avaliados para confirmação da elegibilidade e 15 publicações foram excluídas:</mark> seis por não incluírem glioma grau II (não especificado no título/resumo); cinco por não apresentarem resultados separados para glioma grau II; um por não se tratar de um ensaio clínico randomizado; um por não se tratar de tratamento pós-operatório; um por não relatar os graus de glioma dos pacientes incluídos; um por se tratar de revisão sistemática de estudos observacionais. Nove estudos foram identificados por meio da leitura das referências de outros estudos (5, 82, 83, 87, 88, 208-211). Por fim, doze estudos foram incluídos (5, 82, 83, 87-90, 208212).

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3) Descrição dos Estudos e seus Resultados** -->
A descrição sumária dos estudos encontra-se dividida em cinco seções, de acordo com cada comparação realizada nos estudos: comparação 1: Radioterapia versus Temozolomida (1,2) (Tabelas 64-68); comparação 2: Radioterapia versus Radioterapia + PCV (procarbazina, lomustina e vincristina) (3–5) (Tabelas 68-71); comparação 3: Radioterapia versus Radioterapia + Lomustina (6) (Tabelas 72-75); comparação 4: Radioterapia em dose alta versus Radioterapia em dose baixa (7–10) (Tabelas 76-79); e comparação 5: Radioterapia precoce versus Tratamento da progressão da doença (11,12) (Tabelas 80-83).  
261  
262

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.1) Comparação 1: Radioterapia versus Temozolomida** -->
**Tabela 64 - Características dos estudos.**  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do**<br>**estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Baumert et al.**<br>**2016 (1);**<br>**Reijneveld et al.**<br>**2016 (2)**|EORTC 22033-<br>26033: Ensaio<br>clínico<br>randomizado,<br>multicêntrico (78<br>centros em 19<br>países)|Avaliar os efeitos<br>da quimioterapia<br>com<br>temozolomida,<br>comparado à<br>radioterapia, na<br>sobrevida e<br>segurança<br>(**Baumert et al.**<br>**2016**) e na<br>qualidade de vida<br>e função cognitiva<br>**(Reijneveld et al.**<br>**2016)**em<br>pacientes com<br>glioma grau II de<br>alto risco|477 pacientes com<br>gliomas grau II,<br>idade ≥ 40 anos|**Grupo TMZ:**<br>Temozolomida<br>oral 75 mg/m<sup>2</sup>por<br>21 dias, repetidos<br>a cada 28 dias (1<br>ciclo) por até 12<br>ciclos ou até<br>progressão da<br>doença ou<br>toxicidade<br>inaceitável.<br>Antieméticos<br>foram<br>administrados de<br>acordo com a<br>avaliação de cada<br>centro|**Grupo RT:**<br>Radioterapia: dose<br>total de 50,4 Gy<br>em 28 sessões<br>fracionadas de 1,8<br>Gy cada, 5 dias<br>por semana<br>durante 5 à 6<br>semanas|Baixo|  
EORTC: _European Organisation for Research and Treatment of Cancer_ ; TMZ: temozolomida; RT: radioterapia.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 65 - Características dos pacientes.** -->
263  
|**Autor, ano**|**Tamanho am**<br>**TMZ**|**ostral (n)**<br>**RT**|**Idade (anos**<br>**TMZ**|**), mediana**<br>**RT**|**Sexo mascu**<br>**(%)**<br>**TMZ**|**lino, (n**<br>**)**<br>**RT**|**Tempo de seguimento**<br>**para sobreviventes**|
|---|---|---|---|---|---|---|---|
|**Baumert et al. 2016**<br>**(1);**<br>**Reijneveld et al. 2016**<br>**(2)**|237|240|45<br>(IQR 37 – 53)|43<br>(IQR 36 – 52)|137 (58%)|138<br>(58%)|Mediana: 4,0 anos<br>(IQR 31 – 56)|  
TMZ: temozolomida; RT: radioterapia; IQR: intervalo interquartil.  
264

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 66 - Desfechos de eficácia.** -->
|**Autor, ano**|**Sobrevida global**<br>**(SG)**|**Sobrevida livre de progressão (SLP)**|**Qualidade de vida**<sup>**a**</sup>|**Função cognitiva**|
|---|---|---|---|---|
|**Baumert et**<br>**al. 2016 (1);**<br>**Reijneveld et**<br>**al. 2016 (2)**|**Baumert et al. 2016**<br>Os autores reportam<br>que não foi possível<br>realizar análises<br>significativas de SG|**Baumert et al. 2016**<br>**TMZ:**39 meses (IC95% 35; 44)<br>**RT:**46 meses (IC95% 40; 56)<br>**HR:**1,16 (IC95% 0,92; 1,50), p=0,22<br>**- Resultados por subtipo molecular:**<br>**- Mediana da SLP**, em meses (IC95%)**:**<br>**Todos (n=318):**<br>**TMZ:**40,48 (35,25; 46,95);**RT:**50,99<br>(39,79; 61,63)<br>**IDHmt/codel (n=104):**<br>**TMZ:**55,03 (37,95; não alcançado);<br>**RT:**61,63 (42,32; não alcançado)<br>**IDHmt/non-codel (n=165):**<br>**TMZ:**36,01 (28,42; 46,95);**RT:**55,36<br>(47,87; 65,87)<br>**IDHwt (n=49):**<br>**TMZ:**23,69 (5,55; 42,25);**RT:**19,09<br>(11,27; 25,69)<br>**- Taxa de SLP em 5 anos**, em %<br>(IC95%)**:**<br>**Todos (n=318):**<br>**TMZ:**28,92 (19,78; 38,69);**RT:**40,18<br>(29,94; 50,19)|**Reijneveld et al. 2016**<br>**- Qualidade de vida**<br>**relacionada à saúde, média**<br>**± desvio padrão:**<br>**Basal**(nTMZ=217, nRT= 214):<br>**TMZ:**69,1 ± 1,42;**RT:**68,4<br>± 1,42<br>**Δ:**0,7 (IC95% -3,3; 4,6),<br>p=0,74<br>**3 meses**(nTMZ=196, nRT=<br>173):<br>**TMZ:**68,6 ± 1,47;**RT:**61,9<br>± 1,54<br>**Δ:**6,7 (IC95% 2,5; 10,9),<br>p=0,0017<br>**6 meses**(nTMZ=182, nRT=<br>158):<br>**TMZ:**68,7 ± 1,5;**RT:**70,5 ±<br>1,62<br>**Δ:**-1,8 (IC95% 6,1; 2,5),<br>p=0,42<br>**9 meses**(nTMZ=162, nRT=<br>146):<br>**TMZ:**71,5 ± 1,57;**RT:**71 ±<br>1,65|**Reijneveld et al. 2016**<br>**- Escore no MMSE, média ±**<br>**desvio padrão:**<br>**Basal**(nTMZ=236, nRT= 239):<br>**TMZ:**28,5 ± 0,15;**RT:**28,5<br>± 0,14<br>**Δ:**0 (IC95% -0,4; 0,4),<br>p>0,05<br>**3 meses**(nTMZ=184, nRT=<br>158):<br>**TMZ:**28,7 ± 0,15;**RT:**28,5<br>± 0,16<br>**Δ:**0 (IC95% -0,5; 0,6),<br>p>0,05<br>**6 meses**(nTMZ=160, nRT=<br>134):<br>**TMZ:**28,6 ± 0,18;**RT:**28,6<br>± 0,19<br>**Δ:**0,1 (IC95% -0,4; 0,6),<br>p>0,05<br>**9 meses**(nTMZ=148, nRT=<br>129):<br>**TMZ:**28,8 ± 0,20;**RT:**28,9<br>± 0,21|  
265  
|**Autor, ano**|**Sobrevida global**<br>**(SG)**|**Sobrevida livre de progressão (SLP)**|**Qualidade de vida**<sup>**a**</sup>|**Função cognitiva**|
|---|---|---|---|---|
|||**IDHmt/codel (n=104):**<br>**TMZ:**47,39 (30,71; 62,35);**RT:**58,49<br>(39,43; 73,41)<br>**IDHmt/non-codel (n=165):**<br>**TMZ:**19,43 (8,87; 33,00);**RT:**42,50<br>(27,38; 56,83)<br>**IDHwt (n=49):**<br>**TMZ:**17,78 (3,69; 40,48);**RT:**0 (0,00;<br>0,00)<br>**- HR da SLP**, para TMZ vs. RT<br>(IC95%)**:**<br>**Todos (n=318):**1,18 (0,87; 1,60)<br>**IDHmt/codel (n=104):**1,04 (0,56; 1,93)<br>**IDHmt/non-codel (n=165):**1,86 (1,21;<br>2,87)<br>**IDHwt (n=49):**0,67 (0,34; 1,32)|**Δ:**0,5 (IC95% -4,0; 4,9),<br>p=0,83<br>**12 meses**(nTMZ=154, nRT=<br>136):<br>**TMZ:**70 ± 1,61;**RT:**73 ±<br>1,7<br>**Δ:**-3,0 (IC95% -7,6; 1,6),<br>p=0,20<br>**15 meses**(nTMZ=139, nRT=<br>120):<br>**TMZ:**69,9 ± 1,67;**RT:**70,9<br>± 1,74<br>**Δ:**-1,0 (IC95% -5,7; 3,8),<br>p=0,69<br>**18 meses**(nTMZ=121, nRT=<br>121):<br>**TMZ:**71,6 ± 1,75;**RT:**70,3<br>± 1,77<br>**Δ:**1,3 (IC95% -3,5; 6,2),<br>p=0,59<br>**21 meses**(nTMZ=104, nRT=<br>112):<br>**TMZ:**71,6 ± 1,84;**RT:**70,8<br>± 1,83<br>**Δ:**0,8 (IC95% -4,3; 5,9),<br>p=0,76|**Δ:**0,2 (IC95% -0,2; 0,6),<br>p>0,05<br>**12 meses**(nTMZ=137, nRT=<br>116):<br>**TMZ:**29,0 ± 0,15;**RT:**28,7<br>± 0,16<br>**Δ:**-0,1 (IC95% -0,7; 0,4),<br>p>0,05<br>**15 meses**(nTMZ=127, nRT=<br>115):<br>**TMZ:**28,9 ± 0,17;**RT:**28,8<br>± 0,18<br>**Δ:**0,3 (IC95% -0,1; 0,7),<br>p>0,05<br>**18 meses**(nTMZ=102, nRT=<br>96):<br>**TMZ:**29,0 ± 0,15;**RT:**28,9<br>± 0,15<br>**Δ:**0,1 (IC95% -0,3; 0,5),<br>p>0,05<br>**21 meses**(nTMZ=94, nRT= 88):<br>**TMZ:**28,9 ± 0,16;**RT:**28,9<br>± 0,16<br>**Δ:**0 (IC95% -0,5; 0,4),<br>p>0,05<br>**24 meses**(nTMZ=88, nRT= 84):|  
266  
|**Autor, ano**|**Sobrevida global**<br>**(SG)**|**Sobrevida livre de progressão (SLP)**|**Qualidade de vida**<sup>**a**</sup>|**Função cognitiva**|
|---|---|---|---|---|
||||**24 meses**(nTMZ=105, nRT=<br>100):<br>**TMZ:**72,4 ± 1,86;**RT:**73,3<br>± 1,89<br>**Δ:**-0,9 (IC95% -6,1; 4,3),<br>p=0,73<br>**27 meses**(nTMZ=90, nRT= 86):<br>**TMZ:**69,6 ± 1,93;**RT:**68,8<br>± 2,02<br>**Δ:**0,8 (IC95% -4,7; 6,3),<br>p=0,78<br>**30 meses**(nTMZ=88, nRT= 83):<br>**TMZ:**68,4 ± 1,95;**RT:**72 ±<br>1,97<br>**Δ:**-3,6 (IC95% -9,0; 1,8),<br>p=0,20<br>**33 meses**(nTMZ=79, nRT= 73):<br>**TMZ:**70,2 ± 2,08;**RT:**70,1<br>± 2,09<br>**Δ:**0,1 (IC95% -5,7; 5,9),<br>p=0,96<br>**36 meses**(nTMZ=57, nRT= 63):<br>**TMZ:**71,6 ± 2,26;**RT:**71,1<br>± 2,18<br>**Δ:**0,5 (IC95% -5,6; 6,7),<br>p=0,86|**TMZ:**29,1 ± 0,14;**RT:**28,9<br>± 0,14<br>**Δ:**0,2 (IC95% -0,2; 0,6),<br>p>0,05<br>**27 meses**(nTMZ=76, nRT= 80):<br>**TMZ:**28,9 ± 0,19;**RT:**28,7<br>± 0,19<br>**Δ:**0,2 (IC95% -0,2; 0,7),<br>p>0,05<br>**30 meses**(nTMZ=73, nRT= 70):<br>**TMZ:**29,0 ± 0,16;**RT:**28,7<br>± 0,16<br>**Δ:**0,2 (IC95% -0,3; 0,7),<br>p>0,05<br>**33 meses**(nTMZ=62, nRT= 58):<br>**TMZ:**29,0 ± 0,16;**RT:**28,7<br>± 0,16<br>**Δ:**0,3 (IC95% -0,1; 0,7),<br>p>0,05<br>**36 meses**(nTMZ=54, nRT= 63):<br>**TMZ:**29,0 ± 0,21;**RT:**28,9<br>± 0,20<br>**Δ:**0,1 (IC95% -0,4; 0,6),<br>p>0,05|  
267  
|**Autor, ano**|**Sobrevida global**<br>**(SG)**|**Sobrevida livre de progressão (SLP)**|**Qualidade de vida**<sup>**a**</sup>|**Função cognitiva**|
|---|---|---|---|---|
|||||**- Função cognitiva**<br>**prejudicada de acordo com**<br>**o MMSE, n (%):**<br>**Basal**(nTMZ=236, nRT= 239):<br>**TMZ:**32 (14%);**RT:**32<br>(13%)<br>**36 meses**(nTMZ=54, nRT= 63):<br>**TMZ:**3 (6%);**RT:**5 (8%)|  
SG: sobrevida global; SLP: sobrevida livre de progressão; TMZ: Temozolomida; RT: Radioterapia; HR: _hazard ratio_ ; IC95%: intervalo de confiança de 95%; IDHmt/codel: mutação do gene IDH ( _isocitrate dehydrogenase_ ) com codeleção cromossômica 1p19q; IDHmt/non-codel: mutação do gene IDH ( _isocitrate dehydrogenase_ ) sem codeleção cromossômica 1p19q; IDHwt: gene IDH ( _isocitrate dehydrogenase_ ) do tipo selvagem ( _wild type_ ); Δ: média da diferença entre grupos TMZ e RT; MMSE: mini-mental state examination.<sup>a</sup> Pontuação do questionário de qualidade de vida relacionada à saúde, quanto maior a pontuação, melhor é a qualidade de vida do paciente.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 67 - Eventos adversos.** -->
|**Evento adverso**|**Baumert et al. 2016**<br>**TMZ**|**(1); Reijneveld et al. 2016 (2)**<br>**RT**|
|---|---|---|
|Alergia/imunologia|grau 1-2: 11 (5%); grau 3: 1 (<1%); grau 4: 0|grau 1-2: 3 (1%); grau 3: 0; grau 4: 0|
|Linfático|grau 1-2: 9 (4%); grau 3: 0; grau 4: 0|grau 1-2: 1 (<1%); grau 3: 1 (<1%); grau 4: 0|
|Cardiovascular|grau 1-2: 11 (5%); grau 3: 2 (1%); grau 4: 0|grau 1-2: 10 (4%); grau 3: 0; grau 4: 0|
|Vascular|grau 1-2: 1 (<1%); grau 3: 1 (<1%); grau 4: 0|grau 1-2: 2 (1%); grau 3: 1 (<1%); grau 4: 0|
|Dermatológico|grau 1-2: 73 (31%); grau 3: 4 (2%); grau 4: 0|grau 1-2: 112 (49%); grau 3: 0; grau 4: 0|  
268  
|**Evento adverso**|**Baumert et al. 2016 (1);**|**Reijneveld et al. 2016 (2)**|
|---|---|---|
||**TMZ**|**RT**|
|Dor|grau 1-2: 121 (51%); grau 3: 7 (3%); grau 4: 0|grau 1-2: 107 (47%); grau 3: 6 (3%); grau 4: 0|
|Endócrino/metabólico|grau 1-2: 12 (5%); grau 3: 0; grau 4: 0|grau 1-2: 9 (4%); grau 3: 0; grau 4: 0|
|Metabólico|grau 1-2: 4 (2%); grau 3: 0; grau 4: 0|grau 1-2: 1 (<1%); grau 3: 2 (1%); grau 4: 0|
|Gastrointestinal/hepático|grau 1-2: 158 (67%); grau 3: 10 (4%); grau 4: 0|grau 1-2: 66 (29%); grau 3: 4 (2%); grau 4: 0|
|Hepatobiliar|grau 1-2: 0; grau 3: 0; grau 4: 0|grau 1-2: 0; grau 3: 2 (1%); grau 4: 0|
|Leucopenia|grau 1-2: 120 (51%)grau 3: 8 (3%)grau 4: 1 (<1%)|grau 1-2: 12 (5%)grau 3: 0 grau 4: 0|
|Neutropenia|grau 1-2: 80 (34%)grau 3: 6 (3%)grau 4: 4 (2%)|grau 1-2: 6 (3%)grau 3: 0 grau 4: 0|
|Trombocitopenia|grau 1-2: 8 (3%); grau 3: 4 (2%); grau 4: 7 (3%)|grau 1-2: 0; grau 3: 0; grau 4: 0|
|Anemia|grau 1-2: 58 (25%); grau 3: 1 (<1%); grau 4: 1 (<1%)|grau 1-2: 7 (3%); grau 3: 0; grau 4: 0|
|Hemorragia|grau 1-2: 8 (3%); grau 3: 0; grau 4: 0|grau 1-2: 0; grau 3: 0; grau 4: 0|
|Infecção|grau 1-2: 66 (28%); grau 3: 7 (3%); grau 4: 1 (<1%)|grau 1-2: 23 (10%); grau 3: 2 (1%); grau 4: 0|
|Musculoesquelético|grau 1-2: 21 (9%); grau 3: 2 (1%); grau 4: 0|grau 1-2: 20 (9%); grau 3: 2 (1%); grau 4: 0|
|Oftalmológica|grau 1-2: 46 (20%); grau 3: 0; grau 4: 0;|grau 1-2: 36 (16%); grau 3: 0; grau 4: 0|
|Renal/genitourinário|grau 1-2: 16 (7%); grau 3: 0; grau 4: 0|grau 1-2: 4 (2%); grau 3: 2 (1%); grau 4: 0;|
|Respiratório|grau 1-2: 42 (18%); grau 3: 1 (<1%); grau 4: 0;|grau 1-2: 13 (6%); grau 3: 1 (<1%); grau 4: 0;|
|Sintomas constitucionais|grau 1-2: 159 (68%); grau 3: 15 (6%); grau 4: 1 (<1%)|grau 1-2: 141 (62%); grau 3: 8 (4%); grau 4: 0;|
|Neurológico|grau 1-2: 125 (53%); grau 3: 36 (15%); grau 4: 5 (2%)|grau 1-2: 134 (59%); grau 3: 25 (11%); grau 4: 3 (1%)|
|Sistema reprodutivo|grau 1-2: 11 (5%); grau 3: 4 (2%); grau 4: 0;|grau 1-2: 7 (3%); grau 3: 0; grau 4: 0|
|Dano intra-operatório|grau 1-2: 0; grau 3: 0; grau 4: 0|grau 1-2: 2 (1%); grau 3: 0; grau 4: 0|  
269  
|**Evento adverso**|**Baumert et al. 2**<br>**TMZ**|**016 (1); Reijneveld et al. 2016 (2)**<br>**RT**|
|---|---|---|
|Síndromas (gripe, sonolência)|grau 1-2: 12 (5%); grau 3: 0; grau 4: 0|grau 1-2: 3 (1%); grau 3: 0; grau 4: 0|
|Interrupção do tratamento|NR|NR|
|Óbito|2|2|  
Resultados expressos em n (%). TMZ: temozolomida; RT: radioterapia; NR: não reportado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 68 - Características dos estudos.** -->
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do**<br>**estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Buckner et al. 2016**<br>**(3);**<br>**Prabhu et al. 2014**<br>**(4);**<br>**Shaw et al. 2012**<br>**(5)**|RTOG 98-02:<br>ensaio clínico<br>randomizado,<br>multicêntrico|Avaliar os efeitos<br>da quimioterapia<br>com PCV<br>associada à<br>radioterapia em<br>pacientes adultos<br>com glioma grau<br>II na sobrevida<br>**(Buckner et al.**<br>**2016)**e na função<br>cognitiva**(Prabhu**<br>**et al. 2014)**|251 pacientes com<br>gliomas grau II,<br>idade entre 18 e 39<br>anos com<br>ressecção parcial<br>ou idade >39 com<br>ressecção total ou<br>parcial, KPS ≥ 60|**Grupo RT+PCV:**<br>Radioterapia: dose<br>total de 54 Gy em<br>30 sessões<br>fracionadas de 1,8<br>Gy cada, durante 6<br>semanas +<br>quimioterapia: 6<br>ciclos (8 semanas<br>cada ciclo) pós-<br>radioterapia com<br>procarbazina 60<br>mg/m<sup>2</sup>, lomustina|**Grupo RT:**<br>Radioterapia: dose<br>total de 54 Gy em<br>30 sessões<br>fracionadas de 1,8<br>Gy cada, durante 6<br>semanas|Incerto: sem<br>cegamento|  
270  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do**<br>**estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||(CCNU) 110<br>mg/m<sup>2</sup>e<br>vincristina 1,4<br>mg/m<sup>2</sup>|||  
RTOG: _Radiation Therapy Oncology Group_ ; PCV: procarbazina, lomustina e vincristina; KPS: _Karnofsky performance scale_ ; RT: radioterapia; CCNU: lomustina.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 69 - Características dos pacientes.** -->
|**Autor, ano**|**Tamanho am**<br>|**ostral (n)**<br>|**Idade (ano**<br>|**s), mediana**<br>|**Sexo masc**<br>**(%**<br>|**ulino, (n**<br>**))**<br>|**Tempo de seguimento**<br>**para sobreviventes**|
|---|---|---|---|---|---|---|---|
||**RT+PCV**|**RT**|**RT+PCV**|**RT**|**RT+PCV**|**RT**||
|**Buckner et al. 2016**||||||||
|**(3);**|||41|40||||
|**Prabhu et al. 2014**|126|128|(min 18 – max|(min 22 – max|65 (52%)|77 (61%)|Mediana: 11,9 anos|
|**(4);**|||82)|79)||||

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Shaw et al. 2012 (5)** -->
RT: radioterapia; PCV: procarbazina, lomustina e vincristina; min: valor mínimo; max: valor máximo.  
271

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 70 - Desfechos de eficácia.** -->
|**Autor, ano**|**Sobrevida global (SG)**|**Sobrevida livre de progressão (SLP)**|**Desfechos secundários**|
|---|---|---|---|
||**Shaw et al. 2012**(curto prazo)<br>**RT+PCV:**não alcançado (mais de 8,5|**Shaw et al. 2012**(curto prazo)<br>**RT+PCV:**não alcançado (mais de 6,1|**Shaw et al. 2012**(curto prazo)|
||anos)|anos)|**HR para óbito:**0,52 (IC95% 0,30;|
||**RT:**7,5 anos (IC95% 6,0; não|**RT:**4,4 anos (IC95% 3,6; 5,9)|0,91), p=0,02|
||alcançado)||**HR para progressão:**0,45 (IC95%|
|||**- Taxa de SG em 2 anos:**|0,29; 0,70), p<0,001|
||**- Taxa de SG em 2 anos:**|**RT+PCV:**74%||
||**RT+PCV:**85%|**RT:**75%|**Prabhu et al. 2014**|
||**RT:**87%|**- Taxa de SG em 5 anos:**|**- Alterações na função cognitiva de**|
|**Buckner et al.**|**- Taxa de SG em 5 anos:**|**RT+PCV:**63%|**acordo com o MMSE, n (%):**|
|**2016 (3);**|**RT+PCV:**72%|**RT:**46%|**1 ano de seguimento:**|
||**RT:**63%|**HR:**0,60 (IC95% 0,41; 0,86), p=0,005|**RT+PCV**(n=51): Declínio: 2 (4%);|
|**Prabhu et al. 2014**|**HR:**0,72 (IC95% 0,47; 1,10), p=0,33||Sem alteração: 44 (86%); Ganho: 5|
|**(4);**||**Probabilidade de SG por mais 3 anos,**|(10%)|
||**Probabilidade de SG por mais 3 anos,**|**após 2 anos do início do estudo e**|**RT**(n=74): Declínio: 5 (7%); Sem|
|**Shaw et al. 2012**|**após 2 anos do início do estudo e**|**exclusão dos casos de óbito:**|alteração: 66 (89%); Ganho: 3 (4%)|
|**(5)**|**exclusão dos casos de óbito:**|**RT+PCV:**74%|p=0,99|
||**RT+PCV:**84%|**RT:**52%|**2 anos de seguimento:**|
||**RT:**72%|**Probabilidade de SG por mais 3 anos,**|**RT+PCV**(n=50): Declínio: 0 (0%);|
||**Probabilidade de SG por mais 3 anos,**<br>**após 2 anos do início do estudo e**|**após 2 anos do início do estudo e**<br>**exclusão dos casos de óbito:**|Sem alteração: 43 (86%); Ganho: 7<br>(14%)|
||**exclusão dos casos de óbito:**|**RT+PCV:**66%|**RT**(n=60): Declínio: 1 (2%); Sem|
||**RT+PCV:**74%|**RT:**37%|alteração: 58 (97%); Ganho: 1 (2%)|
||**RT:**59%|**HR:**0,44 (IC95% 0,28; 0,69), p<0,001|p=0,50|
||**HR:**0,52 (IC95% 0,30; 0,90), p=0,02|**Buckner et al. 2016**(longo prazo)|**3 anos de seguimento:**|  
272  
**Autor, ano Sobrevida global (SG) Sobrevida livre de progressão (SLP) Desfechos secundários Buckner et al. 2016** (longo prazo) **RT+PCV:** 10,4 anos (IC95% 6,1; não **RT+PCV** (n=43): Declínio: 0 (0%); **RT+PCV:** 13,3 anos (IC95% 10,6; não alcançado) Sem alteração: 38 (88%); Ganho: 5 alcançado) **RT:** 4,0 anos (IC95% 3,1; 5,5) (12%) **RT:** 7,8 anos (IC95% 6,1; 9,8) **HR:** 0,50 (IC95% 0,36; 0,68), p<0,001 **RT** (n=48): Declínio: 1 (2%); Sem **HR:** 0,59 (IC95% 0,42; 0,83), p=0,003 alteração: 45 (94%); Ganho: 2 (4%) **- Taxa de SLP em 5 anos:** p=0,50 **- Taxa de SG em 5 anos: RT+PCV:** 61% (IC95% 53; 70) **5 anos de seguimento: RT+PCV:** 72% (IC95% 64; 80) **RT:** 44% (IC95% 35; 53) **RT+PCV** (n=25): Declínio: 2 (8%); **RT:** 63% (IC95% 55; 72) **- Taxa de SLP em 10 anos:** Sem alteração: 20 (80%); Ganho: 3 **- Taxa de SG em 10 anos: RT+PCV:** 51% (IC95% 42; 59) (12%) **RT+PCV:** 60% (IC95% 51; 69) **RT:** 21% (IC95% 14; 28) **RT** (n=22): Declínio: 0 (0%); Sem **RT:** 40% (IC95% 31; 49) alteração: 21 (96%); Ganho: 1 (5%) **- Oligodendroglioma grau 2:** p=0,99 **- Oligodendroglioma grau 2: HR para RT+PCV:** 0,36 (IC95% 0,21; **HR para RT+PCV:** 0,43 (IC95% 0,23; 0,62), p<0,001 0,82), p=0,009 **- Oligoastrocitoma grau 2: - Oligoastrocitoma grau 2: HR para RT+PCV:** 0,52 (IC95% 0,30; **HR para RT+PCV:** 0,56 (IC95% 0,32; 0,89), p=0,02 1,00), p=0,05 **- Astrocitoma grau 2: - Astrocitoma grau 2: HR para RT+PCV:** 0,58 (IC95% 0,33; **HR para RT+PCV:** 0,73 (IC95% 0,40; 1,03), p=0,06 1,34), p=0,31 **- Mutação no gene IDH1 R132H: - Mutação no gene IDH1 R132H: HR para RT+PCV:** 0,32 (IC95% 0,17; **HR para RT+PCV:** 0,42 (IC95% 0,20; 0,62), p<0,001 0,86), p=0,02  
SG: sobrevida global; SLP: sobrevida livre de progressão; RT: radioterapia; PCV: procarbazina, lomustina e vincristina; HR: _hazard ratio_ ; IC95%: intervalo de confiança de 95%; MMSE: mini-mental state examination.  
273

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 71 - Eventos adversos.** -->
|**Evento adverso**|**Buckner et al. 2016 (3); Prabhu e**<br>|**t al. 2014 (4); Shaw et al. 2012 (5)**<br>|
|---|---|---|
||**RT + PCV**|**RT**|
|Anorexia|grau 1-2: 31 (24%); grau 3: 1 (<1%); grau 4: 0; grau<br>5: 0|grau 1-2: 9 (7%); grau 3: 0; grau 4: 0; grau 5: 0|
|Constipação|grau 1-2: 29 (23%); grau 3: 0; grau 4: 0; grau 5: 0|grau 1-2: 3 (2%); grau 3: 0; grau 4: 0; grau 5: 0|
|Náusea|grau 1-2: 75 (60%); grau 3: 3 (2%); grau 4: 0; grau<br>5: 0|grau 1-2: 24 (19%); grau 3: 2 (1%); grau 4: 0; grau<br>5: 0|
|Vômito|grau 1-2: 37 (29%); grau 3: 4 (3%); grau 4: 0; grau<br>5: 0|grau 1-2: 5 (3%); grau 3: 2 (1%); grau 4: 0; grau 5:<br>0|
|Aumento de ALT|grau 1-2: 12 (9%); grau 3: 1 (<1%); grau 4: 1 (<1%);<br>grau 5: 0|grau 1-2: 0; grau 3: 0; grau 4: 0; grau 5: 0|
|Aumento de AST|grau 1-2: 12 (9%); grau 3: 0; grau 4: 1 (<1%); grau<br>5: 0|grau 1-2: 0; grau 3: 0; grau 4: 0; grau 5: 0|
|Neutropenia|grau 1-2: 18 (14%); grau 3: 44 (35%); grau 4: 11<br>(8%); grau 5: 0|grau 1-2: 0; grau 3: 1 (<1%) ; grau 4: 0; grau 5: 0|
|Neutropenia febril|grau 1-2: 1 (<1%); grau 3: 0; grau 4: 0; grau 5: 0|grau 1-2: 0; grau 3: 0; grau 4: 0; grau 5: 0|
|Linfocitopenia|grau 1-2: 3 (2%); grau 3: 1 (<1%); grau 4: 0; grau 5:<br>0|grau 1-2: 1 (<1%); grau 3: 0; grau 4: 0; grau 5: 0|
|Hemoglobina reduzida|grau 1-2: 43 (34%); grau 3: 5 (4%); grau 4: 1 (<1%);<br>grau 5: 0|grau 1-2: 2 (1%); grau 3: 0; grau 4: 0; grau 5: 0|
|Necessidade de transfusão de eritrócitos|<sup>grau 1-2: 1 (<1%); grau 3: 2 (1%); grau 4: 0; grau 5:</sup><br>0|grau 1-2: 0; grau 3: 0; grau 4: 0; grau 5: 0|  
274  
|**Evento adverso**|**Buckner et al. 2016 (3); Prabhu e**|**t al. 2014 (4); Shaw et al. 2012 (5)**|
|---|---|---|
||**RT + PCV**|**RT**|
|Trombocitopenia|grau 1-2: 32 (25%); grau 3: 23 (18%); grau 4: 0; grau<br>5: 0|grau 1-2: 2 (1%); grau 3: 0; grau 4: 0; grau 5: 0|
|Necessidade de transfusão de plaquetas|grau 1-2: 0; grau 3: 0; grau 4: 1 (<1%); grau 5: 0|grau 1-2: 0; grau 3: 0; grau 4: 0; grau 5: 0|
|Infecção|grau 1-2: 26 (20%); grau 3: 2 (1%); grau 4: 0; grau<br>5: 0|grau 1-2: 1 (<1%); grau 3: 0; grau 4: 0; grau 5: 0|
|Fadiga|grau 1-2: 72 (57%); grau 3: 7 (5%); grau 4: 1 (<1%)<br>; grau 5: 0|grau 1-2: 62 (49%); grau 3: 3 (2%); grau 4: 1 (<1%)<br>; grau 5: 0|
|Perda de peso|grau 1-2: 24 (19%); grau 3: 4 (3%); grau 4: 0; grau<br>5: 0|grau 1-2: 8 (6%); grau 3: 1 (<1%); grau 4: 0; grau 5:<br>0|
|Interrupção do tratamento|NR|NR|
|Óbito|0|0|  
Resultados expressos em n (%). RT: radioterapia; PCV: procarbazina, lomustina e vincristina; NR: não reportado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 72 - Características dos estudos.** -->
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do**<br>**estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||Ensaio clínico|Avaliar o efeito da|54 pacientes com|**Grupo**|**Grupo RT:**|Alto|
|**Eyre et al. 1993 (6)**|randomizado,|adição de|glioma grau I ou|**RT+CCNU:**|Radioterapia até 6|(Não relata|
||multicêntrico|lomustina (CCNU)|II, com ressecção|Radioterapia +|semanas após a|método de|  
275  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do**<br>**estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||à radioterapia no<br>tempo de<br>sobrevida mediana<br>de pacientes com<br>glioma de grau<br>baixo|cirúrgica<br>incompleta|quimioterapia com<br>lomustina (CCNU)<br>até 6 semanas após<br>a cirurgia: dose<br>total de 55 Gy<br>dividida em 32<br>frações,<br>administradas em<br>5 dias por semana<br>durante 7 semanas.<br>Quimioterapia<br>com lomustina 100<br>mg/m<sup>2</sup>a cada 6<br>semanas, iniciado<br>2 dias antes da<br>radioterapia. A<br>dose foi ajustada<br>posteriormente<br>para cada paciente.|cirurgia: dose total<br>de 55 Gy dividida<br>em 32 frações,<br>administradas em<br>5 dias por semana<br>durante 7 semanas|randomização, não<br>relata sigilo de<br>alocação, sem<br>cegamento)|  
CCNU: lomustina; RT: radioterapia.  
276

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 73 - Características dos pacientes.** -->
|**Autor, ano**|**Tamanho am**<br>**RT+CCNU**|**ostral (n)**<br>**RT**|**Idade (anos**<br>**RT+CCNU**|**), mediana**<br>**RT**|**Sexo mascu**<br>**(%)**<br>**RT+CCNU**|**lino, (n**<br>**)**<br>**RT**|**Tempo de seguimento**<br>**para sobreviventes**|
|---|---|---|---|---|---|---|---|
||||39|36||||
|**Eyre et al. 1993 (6)**|35|19|(min 17 – max<br>72)|(min 22 – max<br>73)|15 (43%)|13 (68%)|Até óbito do paciente|  
CCNU: lomustina; RT: radioterapia; min: valor mínimo; max: valor máximo.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 74 - Desfechos de eficácia.** -->
**Autor, ano Sobrevida global (SG) Sobrevida livre de progressão (SLP) RT+CCNU:** 7,4 anos **RT:** 4,5 anos **- Resultados por faixa etária (mediana): <30 anos:** >8 anos **Entre 30 e 50:** 5,5 anos **Eyre et al. 1993 (6)** NR **>50 anos:** 1,6 anos p=0,001 **- Taxa de remissão: RT+CCNU:** 54% **RT:** 79%  
277

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 75 - Eventos adversos.** -->
|**Et d**|**Eyre**|**et al. 1993**(**6)**|
|---|---|---|
|**veno averso**|**RT+CCNU**|**RT**|
|Gastrointestinal/hepático|grau 1-2: 14 (41%); grau 3-4: 1 (3%)|grau 1-2: 3 (17%); grau 3-4: 0|
|Hematológico|grau 1-2: 20 (59%); grau 3-4: 4 (12%)|grau 1-2: 3 (17%); grau 3-4: 0|
|Infecção|grau 1-2: 1 (3%); grau 3-4: 0|grau 1-2: 1 (6%); grau 3-4: 0|
|Perda de peso|grau 1-2: 1 (3%); grau 3-4: 1 (3%)|grau 1-2: 0; grau 3-4: 0|
|Alopecia|grau 1-2: 33 (97%); grau 3-4: 0|grau 1-2: 15 (83%); grau 3-4: 2 (11%)|
|Interrupção do tratamento|NR|NR|
|Óbito|NR|NR|  
Resultados expressos em n (%). RT: Radioterapia; CCNU: lomustina; NR: não reportado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3.4) Comparação 4: Radioterapia em dose alta versus Radioterapia em dose baixa** -->
278

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 76 - Características dos estudos.** -->
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do**<br>**estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Brown et al. 2003**<br>**(7)**<br>**Shaw et al. 2002**<br>**(8)**|Ensaio clínico<br>randomizado|Avaliar a eficácia<br>e segurança (Shaw<br>et al, 2002) e os<br>efeitos na função<br>cognitiva (Brown<br>et al, 2003) da<br>radioterapia em<br>dose baixa versus<br>radioterapia em<br>dose alta, em<br>pacientes adultos<br>com glioma de<br>grau baixo|211 pacientes com<br>gliomas grau II,<br>idade > 18 anos|**Grupo RT dose**<br>**alta (64,8Gy):**<br>Radioterapia: dose<br>total de 64,8 Gy<br>em 36 sessões<br>fracionadas|**Grupo RT dose**<br>**baixa (50,4Gy):**<br>Radioterapia: dose<br>total de 50,4 Gy<br>em 28 sessões<br>fracionadas|Alto: não relata<br>método de<br>randomização, não<br>relata sigilo de<br>alocação, sem<br>cegamento|  
|**Kiebert et al. 1998**<br>**(9);**<br>**Karim et al. 1996**<br>**(10)**|EORTC 22844:<br>ensaio clínico<br>randomizado,<br>multicêntrico (27<br>centros)|Avaliar dose-<br>resposta de duas<br>doses diferentes de<br>radioterapia pós-<br>operatória|379 pacientes com<br>glioma grau baixo<br>KPS ≥ 60, sem<br>doenças graves<br>cardiovasculares,<br>renais ou hepáticas|**Grupo RT dose**<br>**alta (59,4Gy):**<br>Radioterapia até 8<br>semanas após a<br>cirurgia: dose total<br>de 59,4 Gy<br>dividida em 33<br>frações durante 6,6<br>semanas|**Grupo RT dose**<br>**baixa (45Gy):**<br>Radioterapia até 8<br>semanas após a<br>cirurgia: dose total<br>de 45 Gy dividida<br>em 25 frações<br>durante 5 semanas|Baixo|
|---|---|---|---|---|---|---|  
EORTC: _European Organisation for Research and Treatment of Cancer_ ; RT: radioterapia; KPS: _Karnofsky performance scale_ .  
279

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 77 - Características dos pacientes.** -->
||**Tamanho a**|**mostral(n)**|**Idade (ano**|**s), mediana**|**Sexo mascu**|**lino, (n (%))**|**T d it**|
|---|---|---|---|---|---|---|---|
|**Autor, ano**|**RT dose**<br>**alta**|**RT dose**<br>**baixa**|**RT dose alta**|**RT dose baixa**|**RT dose**<br>**alta**|**RT dose**<br>**baixa**|**empo e segumeno para**<br>**sobreviventes**|
|**Brown et al. 2003**<br>**(7);**<br>**Shaw et al. 2002 (8)**|103|108|50% < 40 anos|49% < 40 anos|60 (59%)|57 (56%)|Mediana: 7,4 anos (Brown et<br>al. 2003)<br>6,4 anos (Shaw et al. 2002)|
|**Kiebert et al. 1998**||||||||
|**(9); Karim et al.**<br>**1996 (10)**|172|171|39|38|91 (53%)|105 (61%)|Mediana: 6,2 anos|  
RT: radioterapia.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 78 - Desfechos de eficácia.** -->
|**Autor, ano**|**Sobrevida global (SG)**|**Sobrevida livre de progressão**<br>**(SLP)**|**Qualidade de vida**|**Função cognitiva**|
|---|---|---|---|---|
|**Brown et al.**<br>**2003 (7);**<br>**Shaw et al.**<br>**2002 (8)**|8,4 anos (Brown et al, 2003)<br>9,25 anos (Shaw et al, 2002)<br>**- Taxa de SG em 2 anos:**<br>**RT64,8Gy:**85% (IC95% 78;<br>92)<br>**RT50,4Gy:**94% (IC95% 90;<br>99)<br>**- Taxa de SG em 5 anos:**|5,5 anos (Brown et al, 2003)<br>5,5 anos (Shaw et al, 2002)<br>**- Taxa de SLP em 2 anos:**<br>**RT64,8Gy:**74% (IC95% 66; 83)<br>**RT50,4Gy:**83% (IC95% 76; 91)<br>**- Taxa de SLP em 5 anos:**<br>**RT64,8Gy:**52% (IC95% 43; 64)<br>**RT50,4Gy:**55% (IC95% 46; 66)<br>p=0,65|NR|**Brown et al. 2003**<br>**- Pontuação no MMSE:**<br>**- Após 1 ano de seguimento:**<br>Redução significativa (3 ou<br>mais pontos)**:**<br>**RT64,8Gy:**6 pacientes de 43<br>vivos<br>**RT50,4Gy:**4 pacientes de 54<br>vivos<br>Pontuação estável:|  
280  
|**Autor, ano**|**Sobrevida global (SG)**|**Sobrevida livre de progressão**<br>**(SLP)**|**Qualidade de vida**|**Função cognitiva**|
|---|---|---|---|---|
||**RT64,8Gy:**65% (IC95% 56;<br>75)<br>**RT50,4Gy:**72% (IC95% 63;<br>81)<br>p=0,48|||**RT64,8Gy:**33 pacientes de<br>43 vivos<br>**RT50,4Gy:**46 pacientes de<br>54 vivos<br>Aumento significativo (3 ou<br>mais pontos):<br>**RT64,8Gy:**4 pacientes de 43<br>vivos<br>**RT50,4Gy:**4 pacientes de 54<br>vivos<br>**- Após 2 anos de**<br>**seguimento:**<br>Redução significativa (3 ou<br>mais pontos)**:**<br>**RT64,8Gy:**1 paciente de 25<br>vivos<br>**RT50,4Gy:**3 pacientes de 40<br>vivos<br>Pontuação estável:<br>**RT64,8Gy:**23 pacientes de<br>25 vivos<br>**RT50,4Gy:**35 pacientes de<br>40 vivos<br>Aumento significativo (3 ou<br>mais pontos):<br>**RT64,8Gy:**1 pacientes de 25<br>vivos|  
281  
**Sobrevida livre de progressão Autor, ano Sobrevida global (SG) Qualidade de vida Função cognitiva (SLP) RT50,4Gy:** 2 pacientes de 40 vivos **- Após 5 anos de seguimento:** Redução significativa (3 ou mais pontos) **: RT64,8Gy:** 0 de 21 vivos **RT50,4Gy:** 2 pacientes de 17 vivos Pontuação estável: **RT64,8Gy:** 19 pacientes de 21 vivos **RT50,4Gy:** 15 pacientes de 17 vivos Aumento significativo (3 ou mais pontos): **RT64,8Gy:** 2 pacientes de 21 vivos **RT50,4Gy:** 0 de 17 vivos **Kiebert et al, 1998 Kiebert et al. Karim et al, 1996** 180 participantes (47% da **1998 (9); Taxa de SLP em 5 anos:** amostra) completaram ao p=0,73 **RT45Gy:** 47% de 37 pacientes menos uma pergunta do NR **Karim et al. RT59,4Gy:** 50% de 35 pacientes questionário de qualidade de **1996 (10)** p=0,94 vida  
282  
|**Autor, ano**|**Sobrevida global (SG)**|**Sobrevida livre de progressão**<br>**(SLP)**|**Qualidade de vida**|**Função cognitiva**|
|---|---|---|---|---|
||||**Qualidade de vida dividido**<br>**por domínios**(valor de p da<br>comparação entre os grupos)**:**<br>**Funcionamento físico:**<br>Imediatamente após RT:<br>p=0,067<br>7-15 meses após RT: p=0,086<br>**Tempo de lazer:**<br>Imediatamente após RT:<br>p=0,288<br>7-15 meses após RT: p=0,017<br>**Memória e concentração:**<br>Imediatamente após RT:<br>p=0,143<br>7-15 meses após RT: p=0,521<br>**Interação social:**<br>Imediatamente após RT:<br>p=0,139<br>7-15 meses após RT: p=0,101<br>**Funcionamento sexual:**<br>Imediatamente após RT:<br>p=0,129<br>7-15 meses após RT: p=0,124<br>**Funcionamento emocional:**<br>Imediatamente após RT:<br>p=0,385<br>7-15 meses após RT: p=0,009||  
283  
|**Autor, ano**|**Sobrevida global (SG)**|**Sobrevida livre de progre**<br>**(SLP)**|**ssão**<br>**Qualidade de vida**|**Função cognitiva**|
|---|---|---|---|---|
||||**Bem-estar geral:**<br>Imediatamente após RT:<br>p=0,183<br>7-15 meses após RT: p=0,061<br>**Fadiga/mal-estar:**<br>Imediatamente após RT:<br>p=0,031<br>7-15 meses após RT: p=0,419<br>**Problemas de sono:**<br>Imediatamente após a RT:<br>**RT45Gy:**81%;**RT59,4Gy:**<br>64%; p=0,05||  
RT: radioterapia; SG: sobrevida global; SLP: sobrevida livre de progressão; MMSE: mini-mental state examination.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 79 - Eventos adversos.** -->
|**Evento adverso**|**Brown et al. 2003 (7);**<br>**Shaw et al. 2002(8)**|**Kiebert et al. 1998 (9); Karim et al. 1996 (10)**|
|---|---|---|
||**Todos**|**RT45Gy**<br>**RT59,4Gy**|
|Dermatite|grau 1-2: 65 (31%)|NR<br>NR|
|Náusea|grau 1-2: 6 (3%)|NR<br>NR|
|Letargia|grau 1-2: 14 (7%)|NR<br>NR|  
284  
|**Evento adverso**|**Brown et al. 2003 (7);**<br>**Shaw et al. 2002(8)**|**Kiebert et al. 1998 (9)**|**; Karim et al. 1996 (10)**|
|---|---|---|---|
||**Todos**|**RT45Gy**|**RT59,4Gy**|
|Neurológico não especificado|grau 1-2: 6 (3%)|NR|NR|
|Alopecia|grau 1-2: 50 (24%)|NR|NR|
|Otite|grau 1-2: 12 (6%)|NR|NR|
|Toxicidade grau 3 ou maior|grau 3-4-5: 27 (13%)|NR|NR|
|Cefaleia|NR|leve: 48 (28%); moderado: 24 (14%);<br>grave: 7 (4%)|leve: 50 (29%); moderado: 20 (12%);<br>grave: 3 (2%)|
|Epilepsia|NR|leve: 55 (32%); moderado: 26 (15%);<br>grave: 15 (9%)|leve: 45 (26%); moderado: 36 (21%);<br>grave: 7 (4%)|
|Distúrbio psíquico|NR|leve: 55 (32%); moderado: 22 (13%);<br>grave: 7 (4%)|leve: 41 (24%); moderado: 28 (16%);<br>grave: 11 (6%)|
|Distúrbio motor|NR|leve: 39 (22%); moderado: 20 (11%);<br>grave: 11 (6%)|leve: 36 (21%); moderado: 23 (13%);<br>grave: 11 (6%)|
|Déficit sensorial|NR|leve: 25 (14%); moderado: 4 (2%);<br>grave: 2 (1%)|leve: 18 (11%); moderado: 7 (4%); grave:<br>1 (1%)|
|Afasia|NR|leve: 23 (13%); moderado: 10 (6%);<br>grave: 4 (2%)|leve: 20 (12%); moderado: 13 (8%);<br>grave: 3 (2%)|
|Anormalidade do nervo<br>craniano|NR|leve: 19 (11%); moderado: 4 (2%);<br>grave: 1 (1%)|leve: 14 (8%); moderado: 9 (5%); grave:<br>0 (0%)|
|Interrupção do tratamento|NR|0|9|
|Óbito|NR|NR|NR|  
Resultados expressos em n (%). RT: radioterapia; NR: não reportado.  
285

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 80 - Características dos estudos.** -->
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do**<br>**estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**van den Bent et al.**<br>**2005 (11);**<br>**Karim et al. 2002**<br>**(12)**|EORTC 22845:<br>Ensaio clínico<br>randomizado,<br>multicêntrico (24<br>centros na Europa)|Comparar a<br>eficácia do<br>tratamento pós-<br>operatório de<br>radioterapia<br>precoce versus<br>abordagem<br>conservadora<br>(tratamento na<br>progressão da<br>doença)|311 pacientes com<br>glioma grau II<br>KPS ≥ 60, sem<br>outras doenças<br>sistêmicas<br>significantes|**Grupo RT**<br>**precoce:**<br>Radioterapia até 8<br>semanas após a<br>cirurgia: dose total<br>de 54 Gy, sendo 5<br>sessões<br>fracionadas de 1,8<br>Gy por semana,<br>durante 6 semanas|**Grupo Tto**<br>**tardio:**<br>Tratamento na<br>progressão da<br>doença:<br>combinação de<br>cirurgia,<br>quimioterapia e/ou<br>radioterapia|Incerto: apresenta<br>desvio de alocação<br>de intervenção (3<br>participantes<br>foram alocados no<br>grupo controle<br>mas receberam a<br>intervenção, sem<br>citar os motivos)|  
EORTC: _European Organisation for Research and Treatment of Cancer_ ; KPS: _Karnofsky performance scale_ ; RT: radioterapia TMZ: temozolomida.  
286

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 81 - Características dos pacientes.** -->
|**Autor, ano**|**Tamanho am**<br>**RT precoce**|**ostral (n)**<br>**Tto**<br>**tardio**|**Idade (ano**<br>**RT precoce**|**s), mediana**<br>**Tto tardio**|**Sexo mascu**<br>**(%)**<br>**RT precoce**|**lino, (n**<br>**)**<br>**Tto**<br>**tardio**|**Tempo de seguimento**<br>**para sobreviventes**|
|---|---|---|---|---|---|---|---|
|**van den Bent et al.**||||||||
|**2005 (11);**<br>**Karim et al.  2002**<br>**(12)**|154|157|36,5<br>(min 15 – max<br>69)|41,0<br>(min 17 – max<br>68)|91 (59%)|100<br>(64%)|Mediana: 7,8 anos|  
RT: radioterapia; Tto: tratamento; min: valor mínimo; max: valor máximo.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 82 - Desfechos de eficácia.** -->
|**Autor, ano**|**Sobrevida global (SG)**|**Sobrevida livre de progressão (SLP)**|
|---|---|---|
||**Karim et al, 2002 (12)**<br>**RR para SG:**1,15 (IC95% 0,67; 1,74), p=0,49|**Karim et al. 2002 (12)**<br>**RT precoce:**4,8 anos<br>**Tto tardio:**3,4 anos|
|**van den Bent et al. 2005 (11);**|**Taxa de SG em 5 anos:**<br>**RT precoce:**63%|**RR para SG:**0,68 (IC95% 0,50; 0,94), p=0,02|
|**Karim et al. 2002 (12)**|**Tto tardio:**66%<br>**van den Bent et al, 2005**(11)<br>**RT precoce:**7,2 anos (IC95% 6,4; 8,6)|**Taxa de SG em 5 anos:**<br>**RT precoce:**44%<br>**Tto tardio:**37%|  
287  
|**Autor, ano**|**Sobrevida global (SG)**|**Sobrevida livre de progressão (SLP)**|
|---|---|---|
||**Tto tardio:**7,4 anos (IC95% 6,1; 8,9)|**van den Bent et al, 2005**(11)|
||**HR:**0,97 (IC95% 0,71; 1,34), p=0,872|**RT precoce:**5.3 anos (IC95% 4,6; 6,3)<br>**Tto tardio:**3,4 anos (IC95% 2,9; 4,4)|
||**Taxa de SG em 5 anos:**<br>**RT precoce:**68,4% (IC95% 60,7; 76,2)|**HR:**0,59 (IC95% 0,45; 0,77), p<0,0001|
||**Tto tardio:**65,7% (IC95% 57,8; 73,5)|**Taxa de SLP em 5 anos:**<br>**RT precoce:**55,0% (IC95% 46,7; 63,3)<br>**Tto tardio:**34,6% (IC95% 26,7; 42,5)|  
RR: risco relativo; SG: sobrevida global; SLP: sobrevida livre de progressão; RT: Radioterapia; Tto: tratamento; HR: _hazard ratio_ ; IC95%: intervalo de confiança de 95%; NR: não reportado.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 83 - Eventos adversos.** -->
|**Classificação dos eventos adversos em**|**van den Bent et al. 2005 (11); Karim et**|**al. 2002 (12)**|
|---|---|---|
|**sistemas orgânicos**|**RT precoce**|**Tto tardio**|
|Eritema|grau 1: 34%; grau 2: 6%; grau 3: 1%; grau 4: 1%|NR|
|Otite|grau 1: 5%; grau 2: 1%; grau 3: 0%|NR|
|Vômito|grau 1: 8%; grau 2: 1%; grau 3: 0%|NR|
|Cefaleia|grau 1: 25%; grau 2: 8%; grau 3: 1%|NR|
|Alopecia|< 10%|NR|
|Interrupção do tratamento|6|0|
|Óbito|NR|NR|  
288  
Legenda: Resultados expressos em número absoluto. RT: Radioterapia; Tto: tratamento; NR: não reportado.  
289  
**Questão de Pesquisa 10:** Qual a melhor duração de adjuvância com quimioterapia para glioma grau II (6 meses x 12 meses)?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
(((((low-grade glioma OR WHO grade 2 glioma* OR Diffuse astrocytomas OR Pilocytic astrocytomas OR Oligodendrogliomas OR Gangliogliomas OR Mixed gliomas OR grade II glioma* OR grade II astrocytoma*))) AND ("Chemotherapy, Adjuvant"[Mesh] OR Adjuvant Chemotherapy))) AND ((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh])))  
Data de acesso: 16/08/2017  
Total: 343 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE** -->
('grade ii glioma' OR 'low-grade glioma'/exp OR 'low-grade glioma' OR 'diffuse astrocytoma'/exp OR 'diffuse astrocytoma' OR 'pilocytic astrocytoma'/exp OR 'pilocytic astrocytoma' OR 'oligodendroglioma'/exp OR 'oligodendroglioma' OR 'ganglioglioma'/exp OR 'ganglioglioma' OR 'mixed glioma' OR 'grade ii astrocytoma') AND (('cancer adjuvant therapy'/exp OR 'cancer adjuvant therapy' OR 'adjuvant chemotherapy'/exp OR 'adjuvant chemotherapy' OR 'adjuvant chemoradiotherapy'/exp OR 'adjuvant chemoradiotherapy') AND [embase]/lim) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim)  
Data de acesso: 16/08/2017  
Total: 367 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
290  
Somente foram selecionados ensaios clínicos randomizados que comparassem os esquemas de tratamento (em monoterapia ou associados) temozolomida; procarbazina, lomustina e vincristina (PCV) e radioterapia. Para gliomas grau II (oligoastrocitoma, astrocitoma grau II e oligodendroglioma), apenas foram identificados estudos que utilizavam 12 ciclos de 28 dias para a quimioterapia.  
Foram encontradas 710 referências por meio das estratégias de busca acima. Após a retirada de 92 duplicatas, 618 referências foram avaliadas pela leitura de títulos e resumos. Dessas, 4 foram selecionadas para a leitura na íntegra. Duas referências foram excluídas, por avaliarem conjuntamente outros graus de glioma, que não o II, restando assim dois ensaios clínicos randomizados (88, 89). Ademais, foram incluídos, manualmente, mais três ensaios clínicos randomizados (5, 87, 90). Sendo assim, temos três ECR que compõem o grande estudo RTOG-9802(87-89) (PCV + radioterapia vs. radioterapia) e outros dois ECR que compõem o estudo EORTC 22033-26033 (5, 90) (radioterapia vs. temozolomida).

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3) Descrição** **<mark>dos estudos e seus resultados</mark>** -->
As Tabelas 84-87 apresentam as características do estudo, dados basais e resultados de eficácia e segurança para a comparação entre PCV + radioterapia vs. radioterapia. As Tabelas 88-91 exibem o mesmo conteúdo, porém para a comparação radioterapia vs. temozolomida.  
291

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **1) Radioterapia + PCV vs. Radioterapia** -->
**Tabela 84 - Característica dos estudos incluídos para a questão 10 do PCDT de gliomas, para a comparação PCV + Radio vs. Radio.**  
|**Autor, ano**|**Desenho**<br>**de**<br>**estudo**|**População**|**Objetivo**|**Intervenção**|**Comparador**|**Duração da**<br>**adjuvância**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Buckner et**<br>**al. 2016**<br>**(87);**<br>**Prabhu et**<br>**al. 2014**<br>**(88); Shaw**<br>**et al. 2012**<br>**(89)**|ECR|Pacientes adultos,<br>escor de<br>Karnofsky > 60,<br>apresentando<br>astrocitoma grau<br>II,<br>oligoastrocitoma e<br>oligodendroglioma|Avaliar os resultados<br>de sobrevida e<br>segurança, a curto<br>prazo (**Shaw et al.**<br>**2012**), longo prazo<br>(**Buckner et al.**<br>**2016**), da Radio vs.<br>radio + quimioterapia<br>e a função cognitiva<br>(**Prabhu et al. 2014**)|**Radio**54 Gy (6<br>semanas) +**PCV**<br>(procarbazina 60<br>mg/m<sup>2</sup>; CCNU 110<br>mg/m<sup>2</sup>; e vincristina<br>1,4 mg/m<sup>2</sup>)|**Radio**54 Gy<br>(6 semanas)|6 ciclos de 8<br>semanas<br>cada (12<br>meses de<br>adjuvância)|Incerto<br>(O protocolo não<br>descreve,<br>detalhadamente, o<br>meio do sigilo de<br>alocação, nem<br>randomização;<br>Desfechos incompletos<br>(mITT)|  
ECR: Ensaio clínico randomizado; Radio: radioterapia; PCV: procarbazina + lomustina + vincristina; mITT: modified Intention-to-Treat.  
**Tabela 85 - Características basais dos estudos incluídos para a comparação PCV + Radio vs. Radio.**  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**comparador**|**Sexo masc.,**<br>**n (%)**<br>**intervenção**|**Sexo masc., n (%)**<br>**comparador**|**Idade, mediana**<br>**(variação) anos**<br>**- intervenção**|**Idade,**<br>**mediana**<br>**(variação)**<br>**anos -**<br>**comparador **|**Seguimento,**<br>**mediana (anos)**|
|---|---|---|---|---|---|---|---|  
292  
|**Buckner et al.**||||||**Buckner et al.,**<br>**2016:**11,9 (para<br>sobreviventes)|
|---|---|---|---|---|---|---|
|**2016 (87);**||||||**Prabhu et al., 2014:**|
|**Prabhu et al.**<br>125|126|65 (52)|77 (61)|41 (18; 82)|40 (22; 79)|9,7 (para|
|**2014 (88); Shaw**||||||sobreviventes)|
|**et al. 2012 (89)**||||||**Shaw et al., 2012:**|
|||||||5,9 (para<br>sobreviventes)|  
N: frequência absoluta.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 86 - Principais resultados de sobrevida, qualidade de vida e função cognitiva para a comparação PCV + Radio vs. Radio.** -->
|**Autor, ano**|**Sobrevida livre de progressão**<br>**(SLP), mediana (IC95%) anos**|**Sobrevida global (SG)**|**Função cognitiva (MMSE), %**|
|---|---|---|---|
||**Curto Prazo (Shaw 2012)**|**Curto Prazo (Shaw 2012)**|**Ano 1**|
||Radio+PCV: Não alcançado|Radio+PCV: Não alcançado|**Radio:**|
|**Buckner et al.**<br>**2016 (87);**|Radio: 4,4 (3,6; 5,9)<br>**Taxa de SLP, % (2 anos)**|Radio: 7,5 (6,0; NR)<br>**Taxa de SG, % (2 anos)**|Declínio: 7<br>Sem mudança: 89|
|**Prabhu et al.**|Radio+PCV: 74|Radio+PCV: 85|Ganho: 4|
|**2014 (88); Shaw**|Radio: 75|Radio: 85|**Radio+PCV**|
|**et al. 2012 (89)**|**Taxa de SLP, % (5 anos)**|**Taxa de SG, % (5 anos)**|Declínio: 4|
||Radio+PCV: 63|Radio+PCV: 72|Sem mudança: 86|
||Radio:46|Radio: 63|Ganho:10|  
293  
|**Autor, ano**|**Sobrevida livre de progressão**<br>**(SLP), mediana (IC95%) anos**|**Sobrevida global (SG)**|**Função cognitiva (MMSE), %**|
|---|---|---|---|
||HR: 0,60 (0,41; 0,86), p = 0,005|HR: 0,72 (0,47; 1,10), p = 0,13|**Ano 2**<br>**Radio:**|
||**Longo Prazo (Buckner 2016)**|**Longo Prazo (Buckner 2016)**|Declínio: 2|
||Radio+PCV: 10,4 (6,1; NR)|Radio+PCV: 13,3 (10,6; NR)|Sem mudança: 97|
||Radio: 4,0 (3,1; 5,5)|Radio: 7,8 (6,1; 9,8)|Ganho: 2|
||HR: 0,5 (0,36; 0,68) p<0,001|HR: 0,59 (0,42; 0,83) p=0,003|**Radio+PCV**|
||**Taxa de SLP, % (5 anos)**|**Taxa de SG, % (5 anos)**|Declínio: 0|
||Radio+PCV: 61 (53; 70)|Radio+PCV: 72 (64; 80)|Sem mudança: 86|
||Radio: 44 (35; 53)|Radio: 63 (55; 72)|Ganho: 14|
||**Taxa de SLP, % (10 anos)**|**Taxa de SG, % (10 anos)**|**Ano 3**|
||Radio+PCV: 51 (42; 59)|Radio+PCV: 60 (51; 69)|**Radio:**|
||Radio: 21 (14; 28)|Radio: 40 (31; 49)|Declínio: 2|
||**SLP (por tipo histológico)**|**SG (por tipo histológico)**|Sem mudança: 94|
||Oligodendroglioma grau II|Oligodendroglioma grau II|Ganho: 4|
||HR: 0,36 (0,21; 0,62), p < 0,001<br>Oligoastrocitoma grau II|HR: 0,43 (0,23; 0,82), p = 0,009<br>Oligoastrocitoma grau II|**Radio+PCV**<br>Declínio: 0|
||HR: 0,52 (0,30; 0,89), p = 0,02|HR: 0,56 (0,32; 1,0) p = 0,05|Sem mudança: 88|
||Astrocitoma grau II|Astrocitoma grau II|Ganho: 12|
||HR: 0,58 (0,33; 1,03) p = 0,06|HR: 0,73 (0,40; 1,34), p = 0,31|**Ano 5**|
||**Mutação IDH1 R132H**|**Mutação IDH1 R132H**|**Radio:**|
||HR: 0,32 (0,17; 0,62) p<0,001|HR: 0,42 (0,20; 0,86), p= 0,02|Declínio: 0<br>Sem mudança: 96<br>Ganho: 5|
||||**Radio+PCV**<br>Declínio: 8|
||||Sem mudança: 80<br>Ganho: 12<br>**Variáveis influenciando no escore MMSE:**|  
294  
**Sobrevida livre de progressão Autor, ano Sobrevida global (SG) Função cognitiva (MMSE), %** **<u>(SLP), mediana (IC95%) anos</u> Tempo:** (p<0,001) aumenta com tempo **Boa função neurológica** (p=0,01) e **lateralização direita** (p=0,04) estão <u>associados com melhores resultados.</u>  
MMSE: Mini-exame de estado mental; Radio: radioterapia; PCV: procarbazina + lomustina + vincristina; HR: Hazard ratio; NR: não relatado/não alcançado; SLP: Sobrevida livre de progressão; SG: Sobrevida global.  
295  
**Tabela 87 - Principais eventos adversos para a comparação PCV + Radio vs. Radio.**  
||**Buckner et al. 2016(87); Prabhu et al. 2**|**014(88); Shaw et al. 2012*(89)**|
|---|---|---|
|**Evento adverso**|**Radio**|**Radio+PCV**|
|Fadiga, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:**42,20, 3,1, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5: **47,25,7,1, 0|
|Perda de peso, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 8, 0,1, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**14,10,4, 0, 0|
|Baixa de<br>hemoglobina,n(%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:**2, 0, 0, 0,0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:** 32,11, 5,1, 0|
|Queda de plaquetas,<br>n(%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:**1, 0, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**20,12,23, 0, 0|
|Neutropenia, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 0, 0,1, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**7,11,44,11, 0|
|Neutropenia febril, n<br>(%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 0, 0, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:** 0, 0,1, 0, 0|
|Infecção, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 0,1, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**11,15,2, 0, 0|
|Linfopenia, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 0,1, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:** 0, 3,1, 0, 0|
|Anorexia, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 8,1, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**23, 8,1, 0, 0|
|Constipação, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 3, 0, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**18,11, 0, 0, 0|
|Náusea, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:**20,4,2, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**46,29, 3, 0, 0|
|Vômito, n (%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 3,2,2, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**22,15,4, 0, 0|
|ALT aumentada, n<br>(%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 0, 0, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**11,1,1,1, 0|
|AST aumentada, n<br>(%)|**Respectivamente para Graus 1, 2, 3, 4**<br>**e 5:** 0, 0, 0, 0, 0|**Respectivamente para Graus**<br>**1, 2, 3, 4e 5:**11,1, 0,1, 0|  
ALT: Alanina aminotransferase; AST: Aspartato aminotransferase; *Estudo de Shaw et al. 2012 apenas reportou os eventos adversos por nível (graus 3 e 4) sem defini-los, portanto, os desfechos de eventos adversos relatados aqui são apenas os de Buckner et al. 2016.  
296

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Temozolomida vs. radioterapia** -->
**Tabela 88 - Características dos estudos incluídos para a questão 10 do PCDT de gliomas, para a comparação Temozolomida vs. Radioterapia.**  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**População**|**Objetivo**|**Intervenção**|**Comparador**|**Duração da**<br>**adjuvância**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Baumert**||Pacientes adultos|Avaliar desfechos de|Temozolomida (dose-<br>||||
|**et al. 2016**||<br>com astrocitoma|sobrevida e segurança|densa) 75 mg/m<sup>2</sup>,||12 ciclos de 28|Incerto|
|**(5);**|ECR|<br>rau II|em pacientes com|diariamente por 21|Radioterapia|dias cada (12|(Não informa|
|**Reijneveld**||g ,<br>olioastrocitoma e|glioma grau II em uso|dias, e repetido a cada|50,4Gy|meses de|sobre o sigilo de|
|**et al. 2016**||g<br>oliodendrolioma|de radioterapia vs.|28 dias (1 ciclo), por||adjuvância)|alocação).|
|**(90)**||gg|temozolomida|nomáximo12ciclos||||  
ECR: ensaio clínico randomizado.  
**Tabela 89 - Características basais dos estudos incluídos para a comparação Temozolomida vs. Radioterapia.**  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**comparador**|**Sexo masc.,**<br>**n (%)**<br>**intervenção**|**Sexo masc.,**<br>**n (%)**<br>**comparador**|**Idade, mediana**<br>**(IQR) anos -**<br>**intervenção**|**Idade, mediana**<br>**(IQR) anos -**<br>**comparador**|**Seguimento, mediana [IQR]**|
|---|---|---|---|---|---|---|---|
|**Baumert et al.**<br>**2016 (5);**<br>**Reijneveld et al.**<br>**2016 (90)**|237|240|137 (58)|138 (58)|45 (37-53)|43 (36-52)|4 anos (48 meses [31-56])|  
N: frequência absoluta; IQR: intervalo interquartil.  
297  
**Tabela 90 - Principais resultados de sobrevida, qualidade de vida e função cognitiva para a comparação entre Temozolomida e Radioterapia.**  
|**Autor, ano**|**Sobrevida livre de progressão (SLP),**<br>**mediana (IC95%) anos**|**Sobrevida global (SG)**|**Qualidade de vida, média**<br>**(DP)**|**Função cognitiva**<br>**(MMSE), média (DP)**|
|---|---|---|---|---|
||Radioterapia (meses): 46 (40; 56)||**Basal**|**Basal**|
||TMZ: 39 (35; 44)||TMZ: 69,1 (1,42)|TMZ: 28,5 (0,15)|
||HR: 1,16 (0,9; 1,5), p = 0,22||Radio: 68,4 (1,42)|Radio: 28,5 (0,14)|
||||Δ (IC95%): 0,7 (-3,3; 4,6), p|Δ (IC95%): 0 (-0,4; 0,4)|
||**Resultados por subtipo molecular**||= 0,74|**3 meses**|
||**(IDH e 1p-19q)**||**3 meses**|TMZ: 28,7 (0,15)|
||**SLP mediana (meses)**||TMZ: 68,6 (1,47)|Radio: 28,5 (0,16)|
||**TMZ:**||Radio: 61,9 (1,54)|Δ (IC95%): 0 (-0,5; 0,6)|
||Todos: 40,48 (35,25; 46,95)||Δ (IC95%): 6,7 (2,5; 10,9), p|**6 meses**|
|**Baumert et al.**|IDHmt/codel: 55,03 (37,95; NR)|Nh áli|= 0,0017|TMZ: 28,6 (0,18)|
|**2016 (5);**|IDHmt/non-codel: 36,01 (28,42; 46,95)|enuma anse<br>iifii fi íl|**6 meses**|Radio: 28,6 (0,19)|
|**Reijneveld et**|IDHwt: 23,69 (5,55; 42,25)|sgncatva o possve,<br>dd btid|TMZ: 68,7 (1,5)|Δ (IC95%): 0,1 (-0,4;0,6)|
|**al. 2016 (90)**|**Radioterapia:**|com os aos oos|Radio: 70,5 (1,62)|**9 meses**|
||Todos: 50,99 (39,79; 61,63)||Δ (IC95%): -1,8 (-6,1; 2,5), p|TMZ: 28,8 (0,2)|
||IDHmt/codel: 61,63 (42,32; NR)||= 0,42|Radio: 28,9 (0,21)|
||IDHmt/non-codel: 55,36 (47,87; 65,87)||**9 meses**|Δ (IC95%): 0,2 (-0,2; 0,6)|
||IDHwt: 19,09 (11,27; 25,69)||TMZ: 71,5 (1,57)|**12 meses**|
||p=0,013 (TMZ vs. Radio)||Radio: 71 (1,65)|TMZ: 29,0 (0,15)|
||<br>**SLP mediana em 5 anos, % (meses)**||Δ (IC95%): 0,5 (-4; 4,9), p =|Radio: 28,7 (0,16)|
||<br>**TMZ:**||<br>0,83|Δ (IC95%): -0,1 (-0,7; 0,4)|
||Todos: 28,92 (19,78; 38,69)||**12 meses**|**15 meses**|
||IDHmt/codel:47,39 (30,71; 62,35)||TMZ:70,0 (1,61)|TMZ:28,9 (0,17)|  
298  
|**Autor, ano**|**Sobrevida livre de progressão (SLP),**<br>**mediana (IC95%) anos**|**Sobrevida global (SG)**|**Qualidade de vida, média**<br>**(DP)**|**Função cognitiva**<br>**(MMSE), média (DP)**|
|---|---|---|---|---|
||IDHmt/non-codel: 19,43 (8,87; 33,00)||Radio73 (1,70)|Radio: 28,8 (0,18)|
||IDHwt: 17,78 (3,69; 40,48)||Δ (IC95%): -3,0 (-7,6; 1,6), p|Δ (IC95%): 0,3 (-0,1; 0,7)|
||**Radioterapia:**||= 0,20|**18 meses**|
||Todos: 40,18 (29,94; 50,19)||**15 meses**|TMZ: 29,0 (0,15)|
||IDHmt/codel: 58,49 (39,43; 73,41)||TMZ: 69,9 (1,67)|Radio: 28,9 (0,15)|
||IDHmt/non-codel: 42,50 (27,38; 56,83)||Radio: 70,9 (1,74)|Δ (IC95%): 0,1 (-0,3; 0,5)|
||IDHwt: 17,78 0,0 (0,0; 0,0)||Δ (IC95%): -1,0 (-5,7; 3,8), p|**21 meses**|
||p=0,013 (TMZ vs. Radio)||= 0,69|TMZ: 28,9 (0,16)|
||**HR para SLP global (TMz vs. radio):**||**18 meses**|Radio: 28,9 (0,16)|
||Todos: 1,18 (0,87; 1,60), p = 0,30||TMZ: 71,6 (1,75)|Δ (IC95%): 0 (-0,5; 0,4)|
||IDHmt/codel: 1,04 (0,56; 1,93), p =||Radio: 70,3 (1,77)|**24 meses**|
||0,91||Δ (IC95%): 1,3 (-3,5; 6,2), p|TMZ: 29,1 (0,14)|
||IDHmt/non-codel: 1,86 (1,21; 2,87), p =||= 0,59|Radio: 28,9 (0,14)|
||0,004||**21 meses**|Δ (IC95%): 0,2 (-0,2; 0,6)|
||IDHwt: 0,67 (0,34; 1,32), p = 0,24||TMZ: 71,6 (1,84)|**27 meses**|
||||Radio: 70,8 (1,83)|TMZ: 28,9 (0,19)|
||||Δ (IC95%): 0,8 (-4,3; 5,9), p|Radio: 28,7 (0,19)|
||||= 0,76|Δ (IC95%): 0,2 (-0,2; 0,7)|
||||**24 meses**|**30 meses**|
||||TMZ: 72,4 (1,86)|TMZ: 29 (0,16)|
||||Radio: 73,3 (1,89)|Radio: 28,7 (0,16)|
||||Δ (IC95%): -0,9 (-6,1; 4,3), p|Δ (IC95%): 0,2 (-0,3; 0,7)|
||||= 0,73|**33 meses**|
||||**27 meses**|TMZ: 29,0 (0,16)|
||||TMZ: 69,6 (1,93)|Radio: 28,7 (0,16)|
||||Radio: 68,8 (2,02)|Δ (IC95%): 0,3 (-0,1; 0,7)|
||||Δ (IC95%): 0,8 (-4,7; 6,3), p|**36 meses**|
||||=0,78|TMZ:29 (0,21)|  
299  
**Sobrevida livre de progressão (SLP), Qualidade de vida, média Função cognitiva Autor, ano Sobrevida global (SG)** **<u>mediana (IC95%) anos (DP) (MMSE), média (DP)</u> 30 meses** Radio: 28,9 (0,20) TMZ: 68,4 (1,95) Δ (IC95%): 0,1 (-0,4; 0,6) Radio: 72 (1,97) Δ (IC95%): -3,6 (-9,0; 1,8), p = 0,20 **33 meses** TMZ: 70,2 (2,08) Radio: 70,1 (2,09) Δ (IC95%): 0,1 (-5,7; 5,9), p= 0,96 **36 meses** TMZ: 71,6 (2,26) Radio: 71,1 (2,18) Δ (IC95%): 0,5 (-5,6; 6,7), p = 0,86  
TMZ: temozolomida; Radio: Radioterapia; HR: Hazard ratio; SLP: sobrevida livre de progressão; SG: sobrevida global; Δ: diferença média em relação ao basal; MMSE: Mini exame de estado mental.  
300  
**Tabela 91 - Principais eventos adversos para a comparação entre temozolomida e radioterapia.**  
||**Baumert et al. 2016 (**|**5); Reijneveld et al. 2016 (90)**|
|---|---|---|
|**Evento adverso**|**Radioterapia**|**Temozolomida**|
|Eventos<br>neurológicos, n (%)|**Respectivamente para graus**<br>**1/2, 3 e 4:**134 (59), 25 (11), 3<br>(1)|**Respectivamente para graus 1/2, 3 e 4:**<br>125 (53), 36 (15), 5 (2)|
|Eventos oculares, n<br>(%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **36 (16), 0,0|**Respectivamente para graus 1/2, 3 e 4:**<br>46 (20), 0, 0|
|Evento respiratório,<br>n(%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **13 (6),1(<1), 0|**Respectivamente para graus 1/2, 3 e 4:**<br>42(18),1(<1),4(2)|
|Hemorragia, n (%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **0, 0, 0|**Respectivamente para graus 1/2, 3 e 4:**<br>8 (3), 0, 0|
|Eventos<br>gastrintestinais, n<br>(%)|**Respectivamente para graus**<br>**1/2, 3 e 4:**66 (29), 4 (2), 0|**Respectivamente para graus 1/2, 3 e 4:**<br>158 (67), 10 (4), 0|
|Eventos endócrinos,<br>n(%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **9 (4), 0, 0|**Respectivamente para graus 1/2, 3 e 4:**<br>12(5), 0, 0|
|Eventos<br>dermatológicos, n<br>(%)|**Respectivamente para graus**<br>**1/2, 3 e 4:**112 (49), 0, 0|**Respectivamente para graus 1/2, 3 e 4:**<br>73 (31), 4 (2), 0|
|Eventos cardíacos, n<br>(%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **10 (4), 0, 0|**Respectivamente para graus 1/2, 3 e 4:**<br>11(5),2(1), 0|
|Dano na audição, n<br>(%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **37(16),4(2), 0|**Respectivamente para graus 1/2, 3 e 4:**<br>35 (15),1(<1), 0|
|Alergia, n (%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **3 (1), 0, 0|**Respectivamente para graus 1/2, 3 e 4:**<br>11(5),1(<1), 0|
|Anemia, n (%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **7(3), 0, 0|**Respectivamente para graus 1/2, 3 e 4:**<br>58 (25),1(<1),1(<1)|
|Trombocitopenia, n<br>(%)|**Respectivamente para graus**<br>**1/2, 3 e 4: **0 para todos osgraus|**Respectivamente para graus 1/2, 3 e 4:**<br>8 (3),4(2),7(3)|
|Neutropenia, n (%)|**Respectivamente para graus**<br>**1/2, 3 e 4:** 6 (3),1(<1), 0|**Respectivamente para graus 1/2, 3 e 4:**<br>80 (34), 6 (3)e 4(2)|
|Leucopenia, n (%)|**Respectivamente para graus**<br>**1/2, 3 e 4:**12(5), 0,0|**Respectivamente para graus 1/2, 3 e 4:**<br>120 (51), 8 (3),1(<1)|
|Infecção, n (%)|**Respectivamente para graus**<br>**1/2, 3 e 4:**23(10),2(1),0|**Respectivamente para graus 1/2, 3 e 4:**<br>66(28),7(3),1(<1)|  
301  
**Questão de Pesquisa 11:** Qual a eficácia e segurança da temozolomida em pacientes idosos grau IV com ou sem metilação MGMT?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
((((("temozolomide" [Supplementary Concept] OR temozolomide OR temodal OR temodar)) AND ("Aged"[Mesh] OR "Frail Elderly"[Mesh] OR elderly OR frail elderly)) AND ("Glioblastoma"[Mesh] OR glioblastoma* OR grade IV glioma OR Grade IV Astrocytoma))) AND ((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh])))  
Data de acesso: 09/08/2017  
Total: 225 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE** -->
<mark>((('glioblastoma'/exp OR 'glioblastoma') AND [embase]/lim) AND (('temozolomide'/exp OR 'temozolomide' OR 'temodal'/exp OR 'temodal' OR 'temodar'/exp OR 'temodar') AND [embase]/lim) AND (('aged'/exp OR 'aged' OR 'elderly'/exp OR 'elderly' OR 'frail elderly'/exp OR 'frail elderly') AND [embase]/lim)) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim)</mark>  
302  
Data de acesso: 09/08/2017  
<mark>Total: 348 referências</mark>

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
Foram identificadas 573 referências utilizando as estratégias de buscas relatadas acima. Para ambas as bases de dados foram utilizados filtros validados para a busca de ensaios clínicos randomizados. Foram retiradas 118 duplicatas. Dessa forma, 455 referências tiveram elegibilidade avaliada através da leitura de títulos e resumos. Dessas, 10 referências foram avaliadas através da leitura do texto completo. Foram excluídas sete referências, sendo quatro revisões sistemáticas (uma sem meta-análise, portanto optamos pela inclusão dos estudos originais; uma por agregar diferentes desenhos de estudo na mesma meta-análise; uma por não estratificar os resultados por estado de metilação MGMT; e uma pois o resultado do estudo individual, incluído na meta-análise, não correspondia ao relatado pelo estudo original) e três ensaios clínicos randomizados, na forma de resumo de congresso, para os quais textos completos estão disponíveis e foram inclusos. Sendo assim, três ensaios clínicos randomizados, fase III (110, 111, 213) foram incluídos.  
Somente foram selecionados ensaios clínicos randomizados ou revisões sistemáticas com pacientes idosos (> 60 anos); em uso de temozolomida, em monoterapia ou combinada a radioterapia, e que avaliaram desfechos estratificados por estado de metilação de MGMT.  Resultados de segurança não foram relatados, pois os estudos não mostram essa informação estratificada por metilação de MGMT, apenas para a população total, de acordo com as intervenções.

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3) Descrição** **<mark>dos estudos e seus resultados</mark>** -->
A Tabela 92 a seguir exibe as principais características dos estudos incluídos. Na Tabela 93 estão descritas as características basais de cada um dos estudos. A Tabela 94 exibe os desfechos de sobrevida, de acordo com o estado de metilação MGMT, para a população idosa com glioblastoma.  
303  
304

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 92 - Características principais dos estudos incluídos.** -->
|**Autor, ano**|**Desenho**<br>**de**<br>**estudo**|**População**|**Objetivo**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Perry et al.**<br>**2017 (213)**|ECR|562 pacientes<br>idosos com<br>glioblastoma<br>recém<br>diagnosticado,<br>dos quais 354<br>foram avaliados<br>por estado de<br>metilação MGMT|Avaliar se a combinação<br>de TMZ + radioterapia<br>confere bons resultados<br>de sobrevida à população<br>idosa com glioblastoma|**Radioterapia**40 Gy<br>(15 seções diárias<br>por 3 semanas) +<br>**TMZ**(concomitante:<br>75 mg/m2 por 21<br>dias; e adjuvante:<br>150 a 200 mg/m2 em<br>ciclos de 28 dias,<br>sendo 12 ciclos.|**Radioterapia**40<br>Gy (15 seções<br>diárias por 3<br>semanas)|Incerto<br>(Sigilo de alocação não<br>reportado; não é possível<br>saber se todos os desfechos<br>foram avaliados de forma<br>cega)|
|**Wick et al.**<br>**2012 (111)**|ECR|373 pacientes,<br>idade ≥ 65 anos,<br>escore de<br>karnofsky > 60,<br>com astrocitoma<br>anaplásico ou<br>glioblastoma|Avaliar a não<br>inferioridade e segurança<br>da TMZ em relação a<br>radioterapia|TMZ 100mg/m2|Radioterapia 60 Gy|Incerto<br>(Desfecho incompleto -<br>mITT)|
|**Malmstrom**<br>**et al. 2012**<br>**(110)**|ECR|342 pacientes,<br>idade ≥ 60 anos,<br>com glioblastoma|Comparar os resultados<br>de sobrevida, qualidade<br>de vida e segurança entre<br>TMZ e radioterapias<br>hipofracionada e<br>convencional|TMZ 200 mg/m2|**Radioterapia**<br>**hipofracionada:**<br>34 Gy<br>**Radioterapia**<br>**padrão:**60 Gy|Incerto<br>(Randomização feita de<br>forma diferente em centros<br>de pesquisa diferentes; não<br>são inclusos na tabela basal<br>os pacientes que foram<br>randomizados para TMZ e<br>radiação hipofracionada -<br>segunda randomização)|  
ECR: Ensaio clínico randomizado; mITT: Análise por Intenção de Tratar modificada; TMZ: temozolomida.  
305

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 93 - Características basais para os estudos incluídos.** -->
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**comparador**|**Idade**<br>**intervenção,**<br>**mediana**<br>**(variação),**<br>**anos**|**Idade**<br>**comparador,**<br>**mediana**<br>**(variação),**<br>**anos**|**Sexo masc,**<br>**n (%)**<br>**intervenção**|**Sexo masc,**<br>**n (%)**<br>**comparador**|**Estado de**<br>**metilação**<br>**MGMT,**<br>**n(%)**<br>**(intervenção)**|**Estado de**<br>**metilação**<br>**MGMT,**<br>**n(%)**<br>**(comparador)**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|**Perry et al.**<br>**2017 (213)**|281 (181<br>estado<br>MGMT<br>disponível)|281 (173<br>estado<br>MGMT<br>disponível)|73 (6|5-90)|171 (60,9)|172 (61,2)|**Metilado:**<br>88/181 (48.6)<br>**Não**<br>**metilado:**<br>93/181(51.4)|**Metilado:**<br>77/173 (44,5)<br>**Não**<br>**metilado:**<br>96/173 (55.5)|17 meses (para<br>aqueles<br>sobreviventes)|
|**Wick et al.**<br>**2012 (111)**|195 (101<br>estado de<br>MGMT<br>disponível)|178 (101 com<br>estado de<br>MGMT<br>disponível)|72 (66; 84)|71 (66; 82)|88 (45)|88 (49)|**Metilado:**31<br>(16)<br>**Não**<br>**metilado:**77<br>(39)|**Metilado:**42<br>(24)<br>**Não**<br>**metilado:**59<br>(33)|Seguimento<br>mínimo: 12<br>meses|
|**Malmstrom**<br>**et al. 2012***<br>**(110)**|119|Radioterapia:<br>hipo (123);<br>padrão (100)|70 (60; 88)|Hipo: 70 (60;<br>83);<br>Padrão: 70<br>(60; 80)|55 (59)|Hipo: 50<br>(51)<br>Padrão: 68<br>(68%)|NR|NR|NR|  
*Idade e sexo foram informados baseados apenas nos 291 pacientes inicialmente randomizados; na segunda randomização (51 pacientes) a mediana de idade foi mais avançada; Hipo: hipofracionada  
306

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 94 - Desfechos de eficácia.** -->
|**Autor, ano**|**N**|**Sobrevida global, mediana**<br>**(IC95%), meses**|**Sobrevida livre de progressão,**<br>**mediana (IC95%)**|
|---|---|---|---|
|||**Pacientes sem metilação MGMT,**<br>**% (IC95%)**<br>**12 meses**<br>Radio: 21,3 (13,7–30,0)<br>Radio + TMZ: 32,3 (23,0–42,0)<br>**18 meses**<br>Radio: 12,7 (6,9–20,3)<br>Radio + TMZ: 13,4 (7,3–21,2)<br>**24 meses**<br>Radio: 3,8 (1,1–9,6)<br>Radio + TMZ: 6,7 (2,7–13,1)||
|||**Pacientes com metilação MGMT,**<br>**% (IC95%)**<br>||
|**Perry et al.**<br>**2017 (213)**|562|**12 meses**<br>Radio: 29,9 (19,9–40,5)<br>Radio + TMZ: 55,7 (44,7–65,3)<br>**18 meses**<br>Radio: 13,6 (7,0–22,4)<br>Radio + TMZ: 34,1 (24,4–44,0)<br>**24 meses**<br>Radio: 4,1 (1,1–10,4)<br>Radio + TMZ: 17,8 (10,5-–26,7)|NR|
|||**HR para morte entre Radio +**<br>**TMZ vs. Radio:**<br>Metilado: 0,53 (0,38; 0,73);<br>p<0.001).<br>Não metilado: 0,75 (0,56; 1.01); p =<br>0.055;||
|**Wick et al.**<br>**2012 (111)**|373|**TMZ**<br>MGMT não metilado: 7 (5,7; 8,7)<br>MGMT metilado: NR (10,1; NR)<br>**Radioterapia**<br>MGMT não metilado: 10,4 (8; 11,6)<br>MGMT metilado: 9,6 (6,4; NR)<br>**TMZ x Radio:**<br>HR (metilado) = 0,69 (0,35; 1,16)<br>HR (Não metilado) = 1,34 (0,92;<br>1,95)|**Sobrevida livre de evento**<br>**(progressão ou morte)**<br>**TMZ**<br>MGMT não metilado: 3,3 (3,0; 3,5)<br>MGMT metilado: 8,4 (5,5; 11,7)<br>**Radioterapia**<br>MGMT não metilado: 4,6 (3,7; 6,3)<br>MGMT metilado: 4,6 (4,2; 5,0)<br>**TMZ x Radio:**<br>HR (metilado) = 0,53 (0,33; 0,86)<br>HR(Não metilado)= 1,95 (1,41;2,69)|  
307  
**<u>Não metilado</u>** Qualquer radio: 7,0 (5,7; 8,3) TMZ: 6,8 (5,9; 7,7) HR = 1,16 (0,78; 1,72), p = 0,46 (NS) **Sobrevida em 1 ano, % (IC95%):** Qualquer radio: 26 (16; 37) TMZ: 16 (5; 27) **<u>Metilado</u>** Qualquer radio: 8,2 (6,6; 9,9) TMZ: 9,7 (8,0; 11,4) HR = 0,64 (0,39; 1,04), p = 0,07 (NS) **Sobrevida em 1 ano, % (IC95%):** Qualquer radio: 26 (15; 37) **Malmstrom** TMZ: 32 (15; 49) **et al. 2012** 342 NR **<u>Temozolomida</u> (110)** Não metilado: 6,8 (5,9; 7,7) Metilado: 9,7 (8,0; 11,4) HR = 0,56 (0,34; 0,93), p = 0,02 (favorece metilado) **Sobrevida em 1 ano, %(IC95%):** Qualquer radio: 16 (5; 27) TMZ: 32 (15; 49) **<u>Qualquer Radio</u>** Não metilado: 7,0 (5,7; 8,3) Metilado:  8,2 (6,6; 9,9) HR = 0,97 (0,69; 1,38), p = 0,81 (NS) **Sobrevida em 1 ano, %(IC95%):** Qualquer radio: 26 (16; 37) TMZ: 26 <u>(15; 37)</u>  
N: frequência absoluta; IC95%: intervalo de confiança 95 %; NR: não relatado; Radio: radioterapia; TMZ: temozolomida; HR: hazard ratio.  
**Questão de Pesquisa 12:** Qual a melhor duração de adjuvância com quimioterapia para  
gliomas grau III e IV (6 meses x 12 meses)?  
**1) Estratégias de busca**  
**MEDLINE via Pubmed:**  
308  
(((((("Radiotherapy"[Mesh]) OR "Radiotherapy, Adjuvant"[Mesh] OR radiotherapy OR Radiation Therapy)) OR (("Consolidation Chemotherapy"[Mesh] OR "Induction Chemotherapy"[Mesh] OR "Maintenance Chemotherapy"[Mesh] OR "Chemotherapy, Adjuvant"[Mesh] OR chemotherapy OR temozolomide OR PCV OR procarbazine OR lomustine OR vincristine OR irinotecan OR bevacizumab OR carmustine)))) AND (("Glioblastoma"[Mesh] OR glioblastoma* OR Grade IV Astrocytoma* OR high-grade glioma OR high grade glioma OR anaplastic astrocytoma OR anaplastic oligodendroglioma OR anaplastic oligoastrocytoma OR anaplastic ependymoma))) AND ((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh])))  
Data de acesso: 22/08/2017  
Total: 1744 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE** -->
(('glioblastoma'/exp OR 'glioblastoma' OR 'grade iv astrocytoma' OR 'high-grade glioma' OR 'high grade glioma' OR 'anaplastic astrocytoma' OR 'anaplastic oligoastrocytoma'/exp OR anaplastic oligoastrocytoma' OR 'anaplastic oligodendroglioma' OR 'anaplastic ependymoma'/exp OR 'anaplastic ependymoma') AND [embase]/lim) AND (('chemotherapy'/exp OR 'chemotherapy' OR 'temozolomide'/exp OR 'temozolomide' OR 'pcv' OR 'procarbazine'/exp OR 'procarbazine' OR 'lomustine'/exp OR 'lomustine' OR 'vincristine'/exp OR 'vincristine' OR 'irinotecan'/exp OR 'irinotecan' OR 'bevacizumab'/exp OR 'bevacizumab' OR 'radiotherapy'/exp OR 'radiotherapy') AND [embase]/lim) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim)  
Data de acesso: 22/08/2017  
Total: 2792 referências  
309

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
Foram selecionados apenas estudos que comparassem os dois períodos de adjuvância (6 vs. 12 meses), no período pós-operatório, em indivíduos com glioma grau III e glioblastoma (glioma grau IV OMS).  
Através das estratégias de busca acima foram recuperadas 4536 referências. Foram retiradas 682 duplicatas. Foram avaliadas, por título e resumo, um total de 3854 referências e dessas 122 foram selecionadas para uma triagem mais elaborada. Ao final, apenas dois estudos (99, 109) foram incluídos, sendo um ensaio clínico randomizado (99) e o outro uma análise posthoc de quatro ensaios clínicos randomizados (109).

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
A Tabela 95 exibe as principais características dos estudos incluídos. A Tabela 96 mostra os resultados basais. Nas Tabelas 97 e 98 estão descritos os resultados de sobrevida e toxicidade, respectivamente.  
310  
311  
**Tabela 95 - Características basais dos estudos incluídos.**  
|**Autor, ano**|**Desenho**|**População**|**Objetivo**|**Intervenção**|**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Bhandari**<br>**et al. 2017**<br>**(99)**|Ensaio<br>Clínico<br>Randomizado|40 pacientes<br>adultos com<br>glioblastoma.|Avaliar os<br>desfechos de<br>sobrevida e<br>toxicidade da<br>TMZ em 6 vs.<br>12 ciclos|Terapia concomitante de<br>TMZ (75 mg/m2) + TMZ<br>150 mg/m2 (primeiro<br>ciclo) e 200 mg/m2 (para<br>os ciclos subsequentes)<br>por 6 meses**(C-TMZ)**|Terapia concomitante de<br>TMZ (75 mg/m2) +<br>TMZ 150 mg/m2<br>(primeiro ciclo) e 200<br>mg/m2 (para os ciclos<br>subsequentes) por 12<br>meses **(E-TMZ)**|Alto (não descreve sigilo<br>de alocação, sem<br>cegamento, amostra<br>pequena)|
|**Blumenthal**<br>**et al. 2017**<br>**(109)**|Análise<br>_posthoc_de 4<br>ensaios<br>clínicos<br>randomizados|624 pacientes<br>adultos com<br>glioblastoma<br>recém<br>diagnosticado|Avaliar os<br>desfechos de<br>sobrevida em<br>análise por<br>conglomerado de<br>4 ECR|TMZ adjuvante por 6<br>ciclos**(6C)**|TMZ adjuvante por mais<br>de 6 ciclos**(>6C)**|Incerto (apenas selecionou<br>pacientes sem progressão<br>após 6 ciclos de TMZ;<br>análise posthoc de ECR<br>retrospectiva)|  
ECR: Ensaio Clínico Randomizado; TMZ: temozolomida; 6C: 6 ciclos.  
**Tabela 96 - Características basais dos estudos incluídos.**  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade intervenção,**<br>**mediana (variação),**<br>**anos**|**Idade Controle,**<br>**mediana**<br>**(variação), anos**|**Masculino n(%)**<br>**Intervenção**|**Masculino n(%)**<br>**Controle**|**Seguimento, mediana**<br>**(variação)**|
|---|---|---|---|---|---|---|---|
|**Bhandari et**<br>**al. 2017 (99)**|20|20|49 (19-65)|44 (19-62)|10 (50)|14 (70)|17,25 meses (5,31;<br>36,03)|
|**Blumenthal**<br>**et al. 2017**<br>**(109)**|333|291|<50 anos: 36,6%<br>≥50 anos: 63,4%|<50 anos: 34%<br>≥50 anos: 66%|191 (57,4)|162 (55,7)|33,7 meses (2,0; 53,3)|  
312

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 97 - Principais resultados de sobrevida.** -->
|**Autor, ano**|**Sobrevidaglobal, mediana**|**Sobrevida livre deprogressão, mediana**|
|---|---|---|
||C-TMZ: 15,4 meses|C-TMZ: 12,8 meses|
||E-TMZ: 23,8 meses|E-TMZ: 16,8 meses|
|**Bhandari et al. 2017**|||
|**(99)**|**Em 2 anos:**<br>C-TMZ: 12,9 %|**Em 2 anos:**<br>C-TMZ: 16,4 %|
||E-TMZ: 35,5 % (p=0,044,entregrupos)|E-TMZ:18,7% (p=0,069,entregrupos)|
||6C: 24,9 meses (19,9; 28,7)||
||>6C: 27,0 meses (21,5; 30,9)|6C: 10,4 meses (8,7; 11,9)<br>>6C: 12,2 meses (9,4; 14,0)|
||**Em 2 anos (IC95%):**||
||6C: 50,9% (44,7; 56,7)|**Em 2 anos (IC95%):**|
|**Blumenthal et al.**<br>**2017 (109)**|>6C: 53,9% (47,6; 59,7)<br>HR: 0,92 p=0,52.<br>**MGMT status:**|6C: 28,9% (23,5; 34,5)<br>>6C: 19,4% (14,8; 24,5)<br>HR: 0,80 (0,65; 0,98) p = 0,03|
||Metilado: HR = 0,89 (0,63; 1,26), p =|**MGMT status:**|
||0,51|Metilado: HR = 0,65 (0,50; 0,85), p = 0,019|
||Não metilado: HR = 0,85 (0,58; 1,25), p<br>=0,41|Não metilado: HR = 0,88 (0,64; 1,21), p = 0,43|  
TMZ: temozolomida; IC95%: intervalo de confiança de 95%; HR: Hazard ratio.  
313

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 98 - Eventos adversos relatados.** -->
||**Autor, ano**|
|---|---|
|**Evento Adverso**|**Bhandari et al. 2017*(99)**|
||**C-TMZ**<br>**E-TMZ**|
|Anorexia,n(%)|2(10)<br>2(10)|
|Fadiga,n(%)|10(50)<br>9(45)|
|Cefaleia,n(%)|3(15)<br>2(10)|
|Náusea,n(%)|4(20)<br>3(15)|
|Vômito,n(%)|2(10)<br>3(15)|
|Insônia,n(%)|1(5)<br>2(10)|  
*apenas eventos grau 2; TMZ: temozolomida.  
314  
**Questão de Pesquisa 13:** Qual o critério de monitorização do paciente com glioma  
(todos os graus) (RANO x Mc Donald X RECIST)?

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **MEDLINE via Pubmed:** -->
(("Glioma"[Mesh] OR glioma OR brain tumor)) AND ((rano criteria) AND recist criteria)  
Data de acesso: 04/08/2017  
Total: 12 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **EMBASE** -->
((('recist' OR 'response evaluation criteria in solid tumors'/exp OR 'response evaluation criteria in solid tumors' OR 'mrecist') AND [embase]/lim) AND ('rano criteria' AND [embase]/lim)) AND (('glioma'/exp OR 'glioma') AND [embase]/lim)  
Data de acesso: 04/08/2017  
Total: 13 referências

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **2) Seleção das evidências** -->
Somente foram consideradas elegíveis referências que comparecem os três critérios (RANO, RECIST e Mac Donald) em pacientes com glioma.  
Através das estratégias de busca acima foram selecionadas 25 referências nas bases de dados Embase e Medline. Nenhuma duplicata foi encontrada. Foram excluídas 17 referências por meio da leitura de títulos e resumos. Dessa forma, oito estudos foram selecionados para a leitura do texto completo. Três referências foram excluídas, após a leitura completa: uma por avaliar condição diferente de glioma; uma por não comparar os critérios de resposta entre si; e uma por se tratar de resumo de congresso existente em mais de uma publicação avaliada (duplicata), sendo uma inclusa. Dessa forma, cinco referências foram incluídas: uma coorte retrospectiva (120) e quatro séries de casos (116-119).  
315

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
A Tabela 99 mostra as principais características dos cinco estudos incluídos. Na Tabela 100 são exibidos os principais resultados de progressão e sobrevida, para cada um dos estudos, de acordo com os critérios adotados (RANO, RECIST ou Mac Donald).  
316

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 99 - Principais características dos estudos incluídos para a questão 13 do PCDT de Gliomas em Adultos.** -->
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo**|**População**|**Intervenção**|**Risco de viés**|
|---|---|---|---|---|---|
|**Kucharczyk**<br>**et al. 2016**<br>**(120)**|Coorte<br>retrospectiva|Determinar qual dentre os<br>critérios (RANO, RECIST e<br>Mc Donald) permite a melhor<br>classificação de<br>pseudoregressão|130 pacientes adultos com<br>glioblastoma|Aplicação dos critérios<br>RANO, Mc Donald e<br>RECIST|Moderado (dados<br>não coletados<br>diretamente; viés de<br>não resposta)|
|**Darlix et al.**<br>**2015 (116)**|Série de casos<br>(resumo)|Comparar os desfechos clínicos<br>avaliados por Mac donal,<br>RANO, eRECIST 1.1|109 pacientes adultos com<br>gliomas grau III e IV|Aplicação dos critérios<br>RANO, Mc Donald e<br>RECIST|Alto (Série de casos;<br>resumo sem muito<br>detalhamento)|
|**Hashimoto**<br>**et al. 2013**<br>**(119)**|Ensaio clínico<br>fase II (único<br>braço)|Avaliar dentre os três critérios<br>(Mac Donald, RANO e<br>RECIST) qual é o melhor para<br>a medida de sobrevidaglobal|50 pacientes com diagnóstico de<br>glioblastoma recorrente em uso<br>conjunto de TMZ e vacina WT1|Aplicação dos critérios<br>RANO, Mc Donald e<br>RECIST|Alto (Série de casos;<br>resumo sem muito<br>detalhamento)|
|**Fabbro et**<br>**al. 2012**<br>**(117)**|Série de casos<br>(resumo)|Comparar os desfechos clínicos<br>avaliados pelos critérios de<br>Mac Donald, RANO, e<br>RECIST 1.1|45 pacientes adultos com<br>glioblastoma em terapia conjunta<br>DE RADIO + TMZ|Aplicação dos critérios<br>RANO, Mc Donald e<br>RECIST|Alto (Série de casos;<br>resumo sem muito<br>detalhamento)|
|**Gallego**<br>**Perez-**<br>**Larraya et**<br>**a. 2012**<br>**(118)**|Série de casos|Comparar os desfechos clínicos<br>avaliados pelos critérios de<br>Mac Donald, RANO, e<br>RECIST 1.1|78 pacientes adultos com<br>glioblastoma recorrente e tratados<br>com terapia de resgate de<br>bevacizumabe + irinotecano|Aplicação dos critérios<br>RANO, Mc Donald,<br>RECIST + F e<br>RECIST|Alto (série de casos)|  
RECIST: Response Evaluation Criteria In Solid Tumors; RANO: Response Assessment in Neuro-Oncology criteria; TMZ: temozolomide; RADIO;  
radioterapia.  
317

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Tabela 100 - Principais resultados de progressão e sobrevida.** -->
|**Autor, ano**|**Amostra**<br>**(n)**|**Homens (%)**|**Idade, anos**<br>**(DP)**|**Resultados de progressão**|**Resultados de sobrevida**|
|---|---|---|---|---|---|
||||||**Sobrevida mediana (meses) de acordo com a**<br>**resposta**<br>Estável<br>RANO: 12,5<br>Mac Donald: 12,0<br>RECIST: 11,6|
||||||Pseudoprogressão<br>RANO: 13,0|
|**Kucharczyk**||||**Incidência de**<br>**pseudoprogressão**|Mac Donald: 11,8<br>RECIST: 9,9<br>|
|<br>**et al. 2016**<br>**(120)**|130|84 (64)|56 (9,0)|RANO: 0,15 (0,10; 0,22)<br>Mac Donald: 0,19 (0,13; 0,27)<br>RECIST: 0,23 (0,17; 0,31)|Progressão<br>RANO: 7,0<br>Mac Donald: 6,3<br>RECIST: 7,0|
||||||**Sobrevida global - HR (IC 95%) - de acordo**|
||||||**com a resposta**<br>Estável<br>RANO: 0,52 (0,20; 1,35)<br>Mac Donald: 0,51 (0,20; 1,31)<br>RECIST: 0,48 (0,19; 1,23)<br>Pseudoprogressão<br>RANO: 0,70 (0,35;1,42)|  
318  
|**Autor, ano**|**Amostra**<br>**(n)**|**Homens (%)**|**Idade, anos**<br>**(DP)**|**Resultados de progressão**|**Resultados de sobrevida**|
|---|---|---|---|---|---|
||||||Mac Donald: 0,86 (0,47; 1,58)<br>RECIST: 1,00 (0,57; 1,78)<br>Progressão<br>RANO: 2,01 (1,16; 3,45)<br>Mac Donald: 2,27 (1,28; 4,02)<br>RECIST: 1,65 (0,89; 3,06)<br>**De acordo com os autores não houve**<br>**diferença significativa para a sobrevida entre**<br>**os três critérios**|
|**Darlix et al.**<br>**2015 (116)**|109|NR|Mediana: 53|**Duração média da melhor**<br>**resposta**<br>RECIST: 3,7 meses<br>Mac Donald: 3,3 meses<br>RANO: 3,0 meses|NR|
|||||**Correlação (κ) entre RANO e**<br>**Mac Donald para mudanças**||  
319  
|**Autor, ano**|**Amostra**<br>**(n)**|**Homens (%)**|**Idade, anos**<br>**(DP)**|**Resultados de progressão**|**Resultados de sobrevida**|
|---|---|---|---|---|---|
|||||**> 20% nas medidas do**<br>**FLAIR**: 0,91.||
|**Hashimoto**<br>**et al. 2013**<br>**(119)**|50|NR|NR|**Taxa de consistência p/**<br>**resposta clínica (remissão ou**<br>**progressão)**<br>Mac Donald x RECIST: 80%<br>Mac Donald x RANO: 94%<br>RECIST x RANO: 76,7%|**Diferença em Sobrevida Global (entre os**<br>**grupos de progressão):**<br>Mac Donald: de 8,3 a 14,5 meses<br>RECIST: de 8,4 a 12,1 meses<br>RANO: de 8,3 a 23,7 meses<br>(O estudo conclui que o critério RANO é o<br>melhor devido a essa maior amplitude)|
|**Fabbro et al.**<br>**2012 (117)**|45|NR|Mediana: 55<br>anos (35; 78)|**Eficácia de acordo com cada**<br>**critério**<br>Mac Donald:<br>Resposta parcial: 17%<br>Doença estável: 44%<br>Progressão: 39%<br>RANO<br>Resposta parcial: 9%<br>Doença estável: 40%<br>Progressão: 51%<br>RECIST<br>Resposta parcial: 16%<br>Doença estável: 67%<br>Progressão: 16%|NR|  
320  
|**Autor, ano**|**Amostra**<br>**(n)**|**Homens (%)**|**Idade, anos**<br>**(DP)**|**Resultados de progressão**|**Resultados de sobrevida**|
|---|---|---|---|---|---|
|||||**Concordância (κ) entre**<br>**testes:**<br>Mac Donald x RANO: 0,76<br>Mac Donald x RECIST: 0,41<br>Segundo o estudo os valores de<br>concordância favorecem o<br>critério RANO||
|||||Taxas de resposta entre os<br>critérios<br>RECIST|**Mediana (IC 95%) de tempo livre de**<br>**progressão**<br>RECIST: 13,6 (9,5; 17,6)|
|||||Resposta completa: 9%|RECIST + F: 12,3 (9,4; 15,2)|
|**Gallego**||||Resposta parcial: 30%<br>Resposta objetiva: 39%|Mac Donald: 12,7 (9,7; 15,7)<br>RANO: 11,7 (9,3; 14,2)|
|**Perez-**<br>**Larraya et a.**<br>**2012 (118)**|78|62%|NR|Doença estável: 45%<br>Progressão: 16%<br>RECIST + F|**Somente pacientes com progressão difusa não**<br>**captável**|
|||||Resposta completa: 8%<br>Resposta parcial: 26%<br>Resposta objetiva: 34%<br>Doença estável: 48%|RECIST + F: Redução de 39 dias<br>RANO: Redução de 33 dias (p=0,256) se<br>comparados a Mac Donald e RECIST.|
|||||Progressão:18%|Todos os tempos livres deprogressãopara os 4|  
321  
|**Autor, ano**|**Amostra**<br>**(n)**|**Homens (%)**|**Idade, anos**<br>**(DP)**|**Resultados de progressão**|**Resultados de sobrevida**|
|---|---|---|---|---|---|
|||||Mac Donald<br>Resposta completa: 9%<br>Resposta parcial: 36%<br>Resposta objetiva: 45%<br>Doença estável: 39%<br>Progressão: 16%<br>RANO<br>Resposta completa: 8%<br>Resposta parcial: 33%<br>Resposta objetiva: 41%<br>Doença estável: 41%<br>Progressão: 18%|critérios se correlacionaram bem com tempo se<br>sobrevida global (p<0,001)|
|||||**Comparação em termos de**<br>**melhor resposta**<br>RECIST x RECIST + F: 0,92<br>(0,85; 0,99)<br>RECIST x Mac Donald: 0,88<br>(0,79; 0,97)<br>RECIST + F x Mac Donald:<br>0,81 (0,69; 0,92)<br>RECIST x RANO: 0,81 (0,69;<br>0,92)<br>RECIST + F x RANO: 0,83<br>(0,72; 0,93)<br>Mac Donald x RANO: 0,92<br>(0,85; 0,99)||  
322  
|**Autor, ano**|**Amostra**<br>**(n)**|**Homens (%)**|**Idade, anos**<br>**(DP)**|**Resultados de progressão**|**Resultados de sobrevida**|
|---|---|---|---|---|---|
|||||**Comparação em termos do**<br>**tipo de progressão**<br>RECIST x RECIST + F: 0,83<br>(0,72; 0,95)<br>RECIST x Mac Donald: 0,98<br>(0,93; 1,00)<br>RECIST + F x Mac Donald:<br>0,81 (0,69; 0,93)<br>RECIST x RANO: 0,76 (0,62;<br>0,92)<br>RECIST + F x RANO: 0,92<br>(0,84; 1,00)<br>Mac Donald x RANO: 0,78<br>(0,65; 0,91)||  
RECIST: Response Evaluation Criteria In Solid Tumors; RANO: Response Assessment in Neuro-Oncology criteria; DP: desvio padrão; IC: intervalo de confiança; HR: Hazard Ratio; NR: Não relatado.  
323

---

<!-- METADADOS: doenca: Tumor Cerebral no Adulto | secao: **Referências** -->
1. Chemotherapy for high-grade glioma. The Cochrane database of systematic reviews. 2002(4):Cd003913.  
2. Blomgren H. Brain tumors. Acta oncologica (Stockholm, Sweden). 1996;35 Suppl 7:16-21.  
3. Gutin PH, Posner JB. Neuro-oncology: diagnosis and management of cerebral gliomas--past, present, and future. Neurosurgery. 2000;47(1):1-8.  
4. Chen C, Xu T, Chen J, Zhou J, Yan Y, Lu Y, et al. Allergy and risk of glioma: a meta-analysis. European journal of neurology. 2011;18(3):387-95.  
5. Baumert BG, Hegi ME, van den Bent MJ, von Deimling A, Gorlia T, HoangXuan K, et al. Temozolomide chemotherapy versus radiotherapy in high-risk low-grade glioma (EORTC 22033-26033): a randomised, open-label, phase 3 intergroup study. The Lancet Oncology. 2016;17(11):1521-32.  
6. Li Y. Association between fruit and vegetable intake and risk for glioma: A meta-analysis. Nutrition. 2014.  
7. Zhao L, Zheng Z, Huang P. Diabetes mellitus and the risk of glioma: a metaanalysis. Oncotarget. 2016;7(4):4483-9.  
8. Adel Fahmideh M, Schwartzbaum J, Frumento P, Feychting M. Association between DNA repair gene polymorphisms and risk of glioma: a systematic review and meta-analysis. Neuro-oncology. 2014;16(6):807-14.  
9. Zhou P, Wei L, Xia X, Shao N, Qian X, Yang Y. Association between telomerase reverse transcriptase rs2736100 polymorphism and risk of glioma. The Journal of surgical research. 2014;191(1):156-60.  
10. Galeone C, Malerba S, Rota M, Bagnardi V, Negri E, Scotti L, et al. A metaanalysis of alcohol consumption and the risk of brain tumours. Annals of oncology : official journal of the European Society for Medical Oncology. 2013;24(2):514-23.  
11. Malerba S, Galeone C, Pelucchi C, Turati F, Hashibe M, La Vecchia C, et al. A meta-analysis of coffee and tea consumption and the risk of glioma in adults. Cancer causes & control : CCC. 2013;24(2):267-76.  
12. Mandelzweig L, Novikov I, Sadetzki S. Smoking and risk of glioma: a metaanalysis. Cancer causes & control : CCC. 2009;20(10):1927-38.  
13. Niedermaier T, Behrens G, Schmid D, Schlecht I, Fischer B, Leitzmann MF. Body mass index, physical activity, and risk of adult meningioma and glioma: A metaanalysis. Neurology. 2015;85(15):1342-50.  
324  
14. Saneei P, Willett W, Esmaillzadeh A. Red and processed meat consumption and risk of glioma in adults: A systematic review and meta-analysis of observational studies. Journal of Research in Medical Sciences. 2015;20(6):602-12.  
15. Sergentanis TN, Tsivgoulis G, Perlepe C, Ntanasis-Stathopoulos I, Tzanninis IG, Sergentanis IN, et al. Obesity and Risk for Brain/CNS Tumors, Gliomas and Meningiomas: A Meta-Analysis. PLoS One. 2015;10(9):e0136974.  
16. Wei Y, Zou D, Cao D, Xie P. Association between processed meat and red meat consumption and risk for glioma: a meta-analysis from 14 articles. Nutrition. 2015;31(1):45-50.  
17. Myung SK, Ju W, McDonnell DD, Lee YJ, Kazinets G, Cheng CT, et al. Mobile phone use and risk of tumors: a meta-analysis. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2009;27(33):5565-72.  
18. Corle C, Makale M, Kesari S. Cell phones and glioma risk: a review of the evidence. Journal of neuro-oncology. 2012;106(1):1-13.  
19. IARC. Non-Ionizing Radiation, Part 2: Radiofrequency Electromagnetic Fields. IARC monographs on the evaluation of carcinogenic risks to humans. 102. Lyon: IARC; 2013.  
20. Little MP, Rajaraman P, Curtis RE, Devesa SS, Inskip PD, Check DP, et al. Mobile phone use and glioma risk: comparison of epidemiological study results with incidence trends in the United States. BMJ (Clinical research ed). 2012;344:e1147.  
21. Deltour I, Auvinen A, Feychting M, Johansen C, Klaeboe L, Sankila R, et al. Mobile phone use and incidence of glioma in the Nordic countries 1979-2008: consistency check. Epidemiology (Cambridge, Mass). 2012;23(2):301-7.  
22. Benson VS, Kirichek O, Beral V, Green J. Menopausal hormone therapy and central nervous system tumor risk: large UK prospective study and meta-analysis. International journal of cancer. 2015;136(10):2369-77.  
23. Repacholi MH, Lerchl A, Roosli M, Sienkiewicz Z, Auvinen A, Breckenkamp J, et al. Systematic review of wireless phone use and brain cancer and other head tumors. Bioelectromagnetics. 2012;33(3):187-206.  
24. Braganza MZ, Kitahara CM, Berrington de Gonzalez A, Inskip PD, Johnson KJ, Rajaraman P. Ionizing radiation and the risk of brain and central nervous system tumors: a systematic review. Neuro-oncology. 2012;14(11):1316-24.  
25. Bowers DC, Nathan PC, Constine L, Woodman C, Bhatia S, Keller K, et al. Subsequent neoplasms of the CNS among survivors of childhood cancer: a systematic review. The Lancet Oncology. 2013;14(8):e321-8.  
325  
26. Neglia JP, Robison LL, Stovall M, Liu Y, Packer RJ, Hammond S, et al. New primary neoplasms of the central nervous system in survivors of childhood cancer: a report from the Childhood Cancer Survivor Study. Journal of the National Cancer Institute. 2006;98(21):1528-37.  
27. Relling MV, Rubnitz JE, Rivera GK, Boyett JM, Hancock ML, Felix CA, et al. High incidence of secondary brain tumours after radiotherapy and antimetabolites. Lancet (London, England). 1999;354(9172):34-9.  
28. Pearce MS, Salotti JA, Little MP, McHugh K, Lee C, Kim KP, et al. Radiation exposure from CT scans in childhood and subsequent risk of leukaemia and brain tumours: a retrospective cohort study. Lancet (London, England). 2012;380(9840):499505.  
29. Davis F, Il'yasova D, Rankin K, McCarthy B, Bigner DD. Medical diagnostic radiation exposures and risk of gliomas. Radiation research. 2011;175(6):790-6.  
30. Colman SD, Williams CA, Wallace MR. Benign neurofibromas in type 1 neurofibromatosis (NF1) show somatic deletions of the NF1 gene. Nature genetics. 1995;11(1):90-2.  
31. Cichowski K, Shih TS, Schmitt E, Santiago S, Reilly K, McLaughlin ME, et al. Mouse models of tumor development in neurofibromatosis type 1. Science (New York, NY). 1999;286(5447):2172-6.  
32. Vogel KS, Klesse LJ, Velasco-Miguel S, Meyers K, Rushing EJ, Parada LF. Mouse tumor model for neurofibromatosis type 1. Science (New York, NY). 1999;286(5447):2176-9.  
33. Rouleau GA, Merel P, Lutchman M, Sanson M, Zucman J, Marineau C, et al. Alteration in a new gene encoding a putative membrane-organizing protein causes neuro-fibromatosis type 2. Nature. 1993;363(6429):515-21.  
34. Scoles DR, Huynh DP, Morcos PA, Coulsell ER, Robinson NG, Tamanoi F, et al. Neurofibromatosis 2 tumour suppressor schwannomin interacts with betaII-spectrin. Nature genetics. 1998;18(4):354-9.  
35. Bruder CE, Ichimura K, Blennow E, Ikeuchi T, Yamaguchi T, Yuasa Y, et al. Severe phenotype of neurofibromatosis type 2 in a patient with a 7.4-MB constitutional deletion on chromosome 22: possible localization of a neurofibromatosis type 2 modifier gene? Genes, chromosomes & cancer. 1999;25(2):184-90.  
36. Goutagny S, Kalamarides M. Meningiomas and neurofibromatosis. Journal of neuro-oncology. 2010;99(3):341-7.  
326  
37. Evans DG, Huson SM, Donnai D, Neary W, Blair V, Newton V, et al. A clinical study of type 2 neurofibromatosis. The Quarterly journal of medicine. 1992;84(304):603-18.  
38. Perry A, Giannini C, Raghavan R, Scheithauer BW, Banerjee R, Margraf L, et al. Aggressive phenotypic and genotypic features in pediatric and NF2-associated meningiomas: a clinicopathologic study of 53 cases. Journal of neuropathology and experimental neurology. 2001;60(10):994-1003.  
39. Larson JJ, van Loveren HR, Balko MG, Tew JM, Jr. Evidence of meningioma infiltration into cranial nerves: clinical implications for cavernous sinus meningiomas. Journal of neurosurgery. 1995;83(4):596-9.  
40. Hamilton SR, Liu B, Parsons RE, Papadopoulos N, Jen J, Powell SM, et al. The molecular basis of Turcot's syndrome. The New England journal of medicine. 1995;332(13):839-47.  
41. Stark Z, Campbell LJ, Mitchell C, James PA, Heath JA, Boussioutas A, et al. Clinical problem-solving. Spot diagnosis. The New England journal of medicine. 2014;370(23):2229-36.  
42. Bruwer Z, Algar U, Vorster A, Fieggen K, Davidson A, Goldberg P, et al. Predictive genetic testing in children: constitutional mismatch repair deficiency cancer predisposing syndrome. Journal of genetic counseling. 2014;23(2):147-55.  
43. Bouffet E, Larouche V, Campbell BB, Merico D, de Borja R, Aronson M, et al. Immune Checkpoint Inhibition for Hypermutant Glioblastoma Multiforme Resulting From Germline Biallelic Mismatch Repair Deficiency. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2016;34(19):2206-11.  
44. Wrensch M, Lee M, Miike R, Newman B, Barger G, Davis R, et al. Familial and personal medical history of cancer and nervous system conditions among adults with glioma and controls. American journal of epidemiology. 1997;145(7):581-93.  
45. Malmer B, Gronberg H, Bergenheim AT, Lenner P, Henriksson R. Familial aggregation of astrocytoma in northern Sweden: an epidemiological cohort study. International journal of cancer. 1999;81(3):366-70.  
46. Blumenthal DT, Cannon-Albright LA. Familiality in brain tumors. Neurology. 2008;71(13):1015-20.  
47. Malmer B, Iselius L, Holmberg E, Collins A, Henriksson R, Gronberg H. Genetic epidemiology of glioma. British journal of cancer. 2001;84(3):429-34.  
48. Sadetzki S, Bruchim R, Oberman B, Armstrong GN, Lau CC, Claus EB, et al. Description of selected characteristics of familial glioma patients - results from the  
327  
Gliogene Consortium. European journal of cancer (Oxford, England : 1990). 2013;49(6):1335-45.  
49. Bainbridge MN, Armstrong GN, Gramatges MM, Bertuch AA, Jhangiani SN, Doddapaneni H, et al. Germline mutations in shelterin complex genes are associated with familial glioma. Journal of the National Cancer Institute. 2015;107(1):384.  
50. Robles-Espinoza CD, Harland M, Ramsay AJ, Aoude LG, Quesada V, Ding Z, et al. POT1 loss-of-function variants predispose to familial melanoma. Nature genetics. 2014;46(5):478-81.  
51. Shi J, Yang XR, Ballew B, Rotunno M, Calista D, Fargnoli MC, et al. Rare missense variants in POT1 predispose to familial cutaneous malignant melanoma. Nature genetics. 2014;46(5):482-6.  
52. Shete S, Hosking FJ, Robertson LB, Dobbins SE, Sanson M, Malmer B, et al. Genome-wide association study identifies five susceptibility loci for glioma. Nature genetics. 2009;41(8):899-904.  
53. Wrensch M, Jenkins RB, Chang JS, Yeh RF, Xiao Y, Decker PA, et al. Variants in the CDKN2B and RTEL1 regions are associated with high-grade glioma susceptibility. Nature genetics. 2009;41(8):905-8.  
54. Sanson M, Hosking FJ, Shete S, Zelenika D, Dobbins SE, Ma Y, et al. Chromosome 7p11.2 (EGFR) variation influences glioma risk. Human molecular genetics. 2011;20(14):2897-904.  
55. Dobbins SE, Broderick P, Melin B, Feychting M, Johansen C, Andersson U, et al. Common variation at 10p12.31 near MLLT10 influences meningioma risk. Nature genetics. 2011;43(9):825-7.  
56. Gu J, Liu Y, Kyritsis AP, Bondy ML. Molecular epidemiology of primary brain tumors. Neurotherapeutics : the journal of the American Society for Experimental NeuroTherapeutics. 2009;6(3):427-35.  
57. Jiang J, Quan XF, Zhang L, Wang YC. The XRCC3 Thr241Met polymorphism influences glioma risk - a meta-analysis. Asian Pacific journal of cancer prevention : APJCP. 2013;14(5):3169-73.  
58. Backes DM, Siddiq A, Cox DG, Calboli FC, Gaziano JM, Ma J, et al. Singlenucleotide polymorphisms of allergy-related genes and risk of adult glioma. Journal of neuro-oncology. 2013;113(2):229-38.  
59. Schwartzbaum J, Ahlbom A, Malmer B, Lonn S, Brookes AJ, Doss H, et al. Polymorphisms associated with asthma are inversely related to glioblastoma multiforme. Cancer research. 2005;65(14):6459-65.  
328  
60. Amirian E, Liu Y, Scheurer ME, El-Zein R, Gilbert MR, Bondy ML. Genetic variants in inflammation pathway genes and asthma in glioma susceptibility. Neurooncology. 2010;12(5):444-52.  
61. Wiemels JL, Wiencke JK, Kelsey KT, Moghadassi M, Rice T, Urayama KY, et al. Allergy-related polymorphisms influence glioma status and serum IgE levels. Cancer epidemiology, biomarkers & prevention : a publication of the American Association for Cancer Research, cosponsored by the American Society of Preventive Oncology. 2007;16(6):1229-35.  
62. Michaud DS, Siddiq A, Cox DG, Backes DM, Calboli FC, Sughrue ME, et al. Mannose-binding lectin 2 gene and risk of adult glioma. PLoS One. 2013;8(4):e61117.  
63. Ferraz-Filho JR, Santana-Netto PV, Rocha-Filho JA, Sgnolf A, Mauad F, Sanches RA. Application of magnetic resonance spectroscopy in the differentiation of high-grade brain neoplasm and inflammatory brain lesions. Arquivos de neuropsiquiatria. 2009;67(2a):250-3.  
64. Hutter A, Schwetye KE, Bierhals AJ, McKinstry RC. Brain neoplasms: epidemiology, diagnosis, and prospects for cost-effective imaging. Neuroimaging clinics of North America. 2003;13(2):237-50, x-xi.  
65. Louis DN, Perry A, Reifenberger G, von Deimling A, Figarella-Branger D, Cavenee WK, et al. The 2016 World Health Organization Classification of Tumors of the Central Nervous System: a summary. Acta neuropathologica. 2016;131(6):803-20.  
66. Dellaretti M, Touzet G, Reyns N, Dubois F, Gusmao S, Pereira JL, et al. Correlation between magnetic resonance imaging findings and histological diagnosis of intrinsic brainstem lesions in adults. Neuro-oncology. 2012;14(3):381-5.  
67. Rachinger W, Grau S, Holtmannspotter M, Herms J, Tonn JC, Kreth FW. Serial stereotactic biopsy of brainstem lesions in adults improves diagnostic accuracy compared with MRI only. Journal of neurology, neurosurgery, and psychiatry. 2009;80(10):1134-9.  
68. Stupp R, Tonn JC, Brada M, Pentheroudakis G. High-grade malignant glioma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Annals of oncology : official journal of the European Society for Medical Oncology. 2010;21 Suppl 5:v190-3.  
69. Stupp R, Brada M, van den Bent MJ, Tonn JC, Pentheroudakis G. High-grade glioma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Annals of oncology : official journal of the European Society for Medical Oncology. 2014;25 Suppl 3:iii93-101.  
70. Rossetti AO, Stupp R. Epilepsy in brain tumor patients. Current opinion in neurology. 2010;23(6):603-9.  
329  
71. Weller M, Stupp R, Wick W. Epilepsy meets cancer: when, why, and what to do about it? The Lancet Oncology. 2012;13(9):e375-82.  
72. De Groot M, Toering S, Douw L, Vecht C, Klein M, Aronica E, et al. Efficacy and tolerability of levetiracetam monotherapy in patients with primary brain tumors and epilepsy. Epilepsia. 2009;50:101.  
73. Kim YH, Kim T, Joo JD, Han JH, Kim YJ, Kim IA, et al. Survival benefit of levetiracetam in patients treated with concomitant chemoradiotherapy and adjuvant chemotherapy with temozolomide for glioblastoma multiforme. Cancer. 2015;121(17):2926-32.  
74. Lim DA, Tarapore P, Chang E, Burt M, Chakalian L, Barbaro N, et al. Safety and feasibility of switching from phenytoin to levetiracetam monotherapy for gliomarelated seizure control following craniotomy: a randomized phase II pilot study. Journal of neuro-oncology. 2009;93(3):349-54.  
75. Merrell RT, Anderson SK, Meyer FB, Lachance DH. Seizures in patients with glioma treated with phenytoin and levetiracetam. Journal of neurosurgery. 2010;113(6):1176-81.  
76. Rosati A, Buttolo L, Stefini R, Todeschini A, Cenzato M, Padovani A. Efficacy and safety of levetiracetam in patients with glioma: a clinical prospective study. Archives of neurology. 2010;67(3):343-6.  
77. Rossetti AO, Jeckelmann S, Novy J, Roth P, Weller M, Stupp R. Levetiracetam and pregabalin for antiepileptic monotherapy in patients with primary brain tumors. A phase II randomized study. Neuro-oncology. 2014;16(4):584-8.  
78. Lacroix M, Abi-Said D, Fourney DR, Gokaslan ZL, Shi W, DeMonte F, et al. A multivariate analysis of 416 patients with glioblastoma multiforme: prognosis, extent of resection, and survival. Journal of neurosurgery. 2001;95(2):190-8.  
79. Gaber M, Selim H, El-Nahas T. Prospective study evaluating the radiosensitizing effect of reduced doses of temozolomide in the treatment of Egyptian patients with glioblastoma multiforme. Cancer management and research. 2013;5:34956.  
80. Claus EB, Walsh KM, Wiencke JK, Molinaro AM, Wiemels JL, Schildkraut JM, et al. Survival and low-grade glioma: the emergence of genetic information. Neurosurgical focus. 2015;38(1):E6.  
81. van den Bent MJ, Afra D, de Witte O, Ben Hassel M, Schraub S, Hoang-Xuan K, et al. Long-term efficacy of early versus delayed radiotherapy for low-grade astrocytoma and oligodendroglioma in adults: the EORTC 22845 randomised trial. Lancet (London, England). 2005;366(9490):985-90.  
330  
82. Karim AB, Maat B, Hatlevoll R, Menten J, Rutten EH, Thomas DG, et al. A randomized trial on dose-response in radiation therapy of low-grade cerebral glioma: European Organization for Research and Treatment of Cancer (EORTC) Study 22844. International journal of radiation oncology, biology, physics. 1996;36(3):549-56.  
83. Shaw E, Arusell R, Scheithauer B, O'Fallon J, O'Neill B, Dinapoli R, et al. Prospective randomized trial of low- versus high-dose radiation therapy in adults with supratentorial low-grade glioma: initial report of a North Central Cancer Treatment Group/Radiation Therapy Oncology Group/Eastern Cooperative Oncology Group study. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2002;20(9):2267-76.  
84. Marsh JC, Godbole R, Diaz AZ, Gielda BT, Turian JV. Sparing of the hippocampus, limbic circuit and neural stem cell compartment during partial brain radiotherapy for glioma: a dosimetric feasibility study. Journal of medical imaging and radiation oncology. 2011;55(4):442-9.  
85. McDonald MW, Shu HK, Curran WJ, Jr., Crocker IR. Pattern of failure after limited margin radiotherapy and temozolomide for glioblastoma. International journal of radiation oncology, biology, physics. 2011;79(1):130-6.  
86. Sutera PA, Bernard ME, Gill BS, Quan K, Engh JA, Burton SA, et al. Salvage stereotactic radiosurgery for recurrent gliomas with prior radiation therapy. Future oncology. 2017;13(29):2681-90.  
87. Buckner JC, Shaw EG, Pugh SL, Chakravarti A, Gilbert MR, Barger GR, et al. Radiation plus Procarbazine, CCNU, and Vincristine in Low-Grade Glioma. The New England journal of medicine. 2016;374(14):1344-55.  
88. Prabhu RS, Won M, Shaw EG, Hu C, Brachman DG, Buckner JC, et al. Effect of the addition of chemotherapy to radiotherapy on cognitive function in patients with low-grade glioma: secondary analysis of RTOG 98-02. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2014;32(6):535-41.  
89. Shaw EG, Wang M, Coons SW, Brachman DG, Buckner JC, Stelzer KJ, et al. Randomized trial of radiation therapy plus procarbazine, lomustine, and vincristine chemotherapy for supratentorial adult low-grade glioma: initial results of RTOG 9802. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2012;30(25):3065-70.  
90. Reijneveld JC, Taphoorn MJ, Coens C, Bromberg JE, Mason WP, Hoang-Xuan K, et al. Health-related quality of life in patients with high-risk low-grade glioma (EORTC 22033-26033): a randomised, open-label, phase 3 intergroup study. The Lancet Oncology. 2016;17(11):1533-42.  
91. Mirimanoff RO, Gorlia T, Mason W, Van den Bent MJ, Kortmann RD, Fisher B, et al. Radiotherapy and temozolomide for newly diagnosed glioblastoma: recursive partitioning analysis of the EORTC 26981/22981-NCIC CE3 phase III randomized trial.  
331  
Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2006;24(16):2563-9.  
92. Chakravarti A, Wang M, Aldape KD, Sulman EP, Bredel M, Magliocco AM, et al. A revised RTOG recursive partitioning analysis (RPA) model for glioblastoma based upon multiplatform biomarker profiles. Journal of Clinical Oncology. 2012;30(15_suppl):2001-.  
93. Yang F, Yang P, Zhang C, Wang Y, Zhang W, Hu H, et al. Stratification according to recursive partitioning analysis predicts outcome in newly diagnosed glioblastomas. Oncotarget. 2017;8(26):42974-82.  
94. Selker RG, Shapiro WR, Burger P, Blackwood MS, Arena VC, Gilder JC, et al. The Brain Tumor Cooperative Group NIH Trial 87-01: a randomized comparison of surgery, external radiotherapy, and carmustine versus surgery, interstitial radiotherapy boost, external radiation therapy, and carmustine. Neurosurgery. 2002;51(2):343-55; discussion 55-7.  
95. Khan L, Soliman H, Sahgal A, Perry J, Xu W, Tsao MN. External beam radiation dose escalation for high grade glioma. The Cochrane database of systematic reviews. 2016(8):Cd011475.  
96. Stupp R, Hegi ME, Mason WP, van den Bent MJ, Taphoorn MJ, Janzer RC, et al. Effects of radiotherapy with concomitant and adjuvant temozolomide versus radiotherapy alone on survival in glioblastoma in a randomised phase III study: 5-year analysis of the EORTC-NCIC trial. The Lancet Oncology. 2009;10(5):459-66.  
97. Lam N, Chambers CR. Temozolomide plus radiotherapy for glioblastoma in a Canadian province: efficacy versus effectiveness and the impact of O6-methylguanineDNA-methyltransferase promoter methylation. Journal of oncology pharmacy practice : official publication of the International Society of Oncology Pharmacy Practitioners. 2012;18(2):229-38.  
98. Athanassiou H, Synodinou M, Maragoudakis E, Paraskevaidis M, Verigos C, Misailidou D, et al. Randomized phase II study of temozolomide and radiotherapy compared with radiotherapy alone in newly diagnosed glioblastoma multiforme. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2005;23(10):2372-7.  
99. Bhandari M, Gandhi AK, Devnani B, Kumar P, Sharma DN, Julka PK. Comparative study of adjuvant temozolomide six cycles versus extended 12 cycles in newly diagnosed glioblastoma multiforme. Journal of Clinical and Diagnostic Research. 2017;11(5):XC04-XC8.  
100. Feng E, Sui C, Wang T, Sun G. Temozolomide with or without Radiotherapy in Patients with Newly Diagnosed Glioblastoma Multiforme: A Meta-Analysis. European Neurology. 2017;77(3-4):201-10.  
332  
101. Hart MG, Garside R, Rogers G, Stein K, Grant R. Temozolomide for high grade glioma. The Cochrane database of systematic reviews. 2013(4):Cd007415.  
102. Karacetin D, Okten B, Yalcin B, Incekara O. Concomitant temozolomide and radiotherapy versus radiotherapy alone for treatment of newly diagnosed glioblastoma multiforme. Journal of BUON : official journal of the Balkan Union of Oncology. 2011;16(1):133-7.  
103. Kocher M, Frommolt P, Borberg SK, Ruhl U, Steingraber M, Niewald M, et al. Randomized study of postoperative radiotherapy and simultaneous temozolomide without adjuvant chemotherapy for glioblastoma. Strahlentherapie und Onkologie : Organ der Deutschen Rontgengesellschaft  [et al]. 2008;184(11):572-9.  
104. Mao Y, Yao Y, Zhang LW, Lu YC, Chen ZP, Zhang JM, et al. Does Early Postsurgical Temozolomide Plus Concomitant Radiochemotherapy Regimen Have Any Benefit in Newly-diagnosed Glioblastoma Patients? A Multi-center, Randomized, Parallel, Open-label, Phase II Clinical Trial. Chinese medical journal. 2015;128(20):2751-8.  
105. Perry JR, Laperriere N, O'Callaghan CJ, Brandes AA, Menten J, Phillips C, et al. Short-Course Radiation plus Temozolomide in Elderly Patients with Glioblastoma. The New England journal of medicine. 2017;376(11):1027-37.  
106. Stupp R, Mason WP, van den Bent MJ, Weller M, Fisher B, Taphoorn MJ, et al. Radiotherapy plus concomitant and adjuvant temozolomide for glioblastoma. The New England journal of medicine. 2005;352(10):987-96.  
107. Szczepanek D, Marchel A, Moskał M, Krupa M, Kunert P, Trojanowski T. Efficacy of concomitant and adjuvant temozolomide in glioblastoma treatment. A multicentre randomized study. Neurologia i Neurochirurgia Polska. 2013;47(2):101-8.  
108. Van Den Bent MJ, Erridge S, Vogelbaum MA, Nowak AK, Sanson M, Brandes AA, et al. Results of the interim analysis of the EORTC randomized phase III CATNON trial on concurrent and adjuvant temozolomide in anaplastic glioma without 1p/19q codeletion: An Intergroup trial. Journal of Clinical Oncology. 2016;34.  
109. Blumenthal DT, Gorlia T, Gilbert MR, Kim MM, Burt Nabors L, Mason WP, et al. Is more better? the impact of extended adjuvant temozolomide in newly diagnosed glioblastoma: A secondary analysis of EORTC and NRG Oncology/RTOG. Neurooncology. 2017;19(8):1119-26.  
110. Malmstrom A, Gronberg BH, Marosi C, Stupp R, Frappaz D, Schultz H, et al. Temozolomide versus standard 6-week radiotherapy versus hypofractionated radiotherapy in patients older than 60 years with glioblastoma: the Nordic randomised, phase 3 trial. The Lancet Oncology. 2012;13(9):916-26.  
333  
111. Wick W, Platten M, Meisner C, Felsberg J, Tabatabai G, Simon M, et al. Temozolomide chemotherapy alone versus radiotherapy alone for malignant astrocytoma in the elderly: The NOA-08 randomised, phase 3 trial. The Lancet Oncology. 2012;13(7):707-15.  
112. Friedman HS, Prados MD, Wen PY, Mikkelsen T, Schiff D, Abrey LE, et al. Bevacizumab alone and in combination with irinotecan in recurrent glioblastoma. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2009;27(28):4733-40.  
113. Wick W, Stupp R, Gorlia T, Bendszus M, Brandes AA, Voss MJ, et al. Sequence of bevacizumab and lomustine in patients with first progression of a glioblastoma: Phase II eortc study 26101. Neuro-oncology. 2016;18:iv11.  
114. Wick W, Brandes AA, Gorlla T, Bendszus M, Sahm F, Taal W, et al. EORTC 26101 phase III trial exploring the combination of bevacizumab and lomustine in patients with first progression of a glioblastoma. Journal of Clinical Oncology. 2016;34.  
115. Combs SE, Schulz-Ertner D, Moschos D, Thilmann C, Huber PE, Debus J. Fractionated stereotactic radiotherapy of optic pathway gliomas: tolerance and longterm outcome. International journal of radiation oncology, biology, physics. 2005;62(3):814-9.  
116. Darlix A, Langlois C, Laigre M, Castan F, Bauchet L, Duffau H, et al. Evaluating the response to bevacizumab in high grade gliomas: The importance of clinical assessment. Neuro-oncology. 2015;17:v158.  
117. Fabbro M, Laigre M, Langlois C, Castan F, Bauchet L, Duffau H, et al. Antiangiogenic treatment (AT) in glioblastoma multiform tumors (GBM): Imaging but also clinical assessment: Correlation between mcdonald, rano and recist 1.1 criteria. Neuro-oncology. 2012;14:iii60.  
118. Gallego Perez-Larraya J, Lahutte M, Petrirena G, Reyes-Botero G, GonzalezAguilar A, Houillier C, et al. Response assessment in recurrent glioblastoma treated with irinotecan-bevacizumab: comparative analysis of the Macdonald, RECIST, RANO, and RECIST + F criteria. Neuro-oncology. 2012;14(5):667-73.  
119. Hashimoto N, Chiba Y, Tsuboi A, Kinoshita M, Hirayama R, Kagawa N, et al. A direct comparison of response assessments in a phase II clinical trial of wt1 peptide vaccination; macdonald, recist and rano criteria. Neuro-oncology. 2013;15:iii111.  
120. Kucharczyk MJ, Parpia S, Whitton A, Greenspoon JN. Evaluation of pseudoprogression in patients with glioblastoma. Neuro-Oncology Practice. 2017;4(2):128-34.  
121. Ministério da Saúde. Secretaria de Atenção Especializada à Saúde. Instituto Nacional de Câncer - INCA. Departamento de Atenção Especializada e Temática -  
334  
DAET.Departamento de Regulação, Avaliação e Controle - DRAC. Manual de Bases Técnicas da Oncologia - SIA/SUS - Sistema de Informações Ambulatoriais. 26 ed. Brasília: MS/SAES/DRAC/CGSI, Novembro de 2019. 164p. 2019. Disponível em: ftp://arpoador.datasus.gov.br/siasus/Documentos/APAC/Manual_Oncologia_26a_edica o_Novembro_2019_03_12_2019.pdf  
122. Brasil. Ministério da Saúde. Portaria n°375, de 10 de novembro de 2009. Aprova o roteiro a ser utilizado na elaboração de Protocolos Clínicos e Diretrizes Terapêuticas no âmbito da Secretaria de Atenção à Saúde. In: Ministério da Saúde, editor. Brasília2009.  
123. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or nonrandomised studies of healthcare interventions, or both. BMJ (Clinical research ed). 2017;358:j4008.  
124. Higgins JPT, Green S. Cochrane Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration. 2011.  
125. Wells G SB, O’Connell D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analyses. 2013.  
126. Whiting PF, Rutjes AW, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, et al. QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. Annals of internal medicine. 2011;155(8):529-36.  
127. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ: British Medical Journal. 2008;336(7650):924.  
128. Wang G, Xu S, Cao C, Dong J, Chu Y, He G, et al. Evidence from a large-scale meta-analysis indicates eczema reduces the incidence of glioma. Oncotarget. 2016;7(38):62598-606.  
129. Xin Y, Hao S, Lu J, Wang Q, Zhang L. Association of ERCC1 C8092A and ERCC2 Lys751Gln polymorphisms with the risk of glioma: a meta-analysis. PLoS One. 2014;9(4):e95966.  
130. Xu C, Yuan L, Tian H, Cao H, Chen S. Association of the MTHFR C677T polymorphism with primary brain tumor risk. Tumour biology : the journal of the International Society for Oncodevelopmental Biology and Medicine. 2013;34(6):345764.  
335  
131. Yao L, Ji G, Gu A, Zhao P, Liu N. An updated pooled analysis of glutathione S- transferase genotype polymorphisms and risk of adult gliomas. Asian Pacific journal of cancer prevention : APJCP. 2012;13(1):157-63.  
132. Zhang JN, Yi SH, Zhang XH, Liu XY, Mao Q, Li SQ, et al. Association of p53 Arg72Pro and MDM2 SNP309 polymorphisms with glioma. Genetics and Molecular Research. 2012;11(4):3618-28.  
133. Tan D, Xu J, Li Y, Lai R. Association between +61G polymorphism of the EGF gene and glioma risk in different ethnicities: a meta-analysis. The Tohoku journal of experimental medicine. 2010;222(4):229-35.  
134. Pyo JS, Kim NY, Kim RH, Kang G. Concordance analysis and diagnostic test accuracy review of IDH1 immunohistochemistry in glioblastoma. Brain tumor pathology. 2016;33(4):248-54.  
135. Ballester LY, Fuller GN, Powell SZ, Sulman EP, Patel KP, Luthra R, et al. Retrospective analysis of molecular and immunohistochemical characterization of 381 primary brain tumors. Journal of neuropathology and experimental neurology. 2017;76(3):179-88.  
136. Gondim DD, Gener MAH, Cheng L, Hattab EM. Determining IDH status in gliomas using IDH1 R132H antibody and polymerase chain reaction. Laboratory Investigation. 2017;97:433A.  
137. Carter JH, McNulty S, Cottrell C, Heusel J. Targeted NGS in molecular subtyping of lower-grade diffuse gliomas: Application of the who's 2016 revised criteria for CNS tumors. Journal of Molecular Diagnostics. 2016;18(6):1009.  
138. Takano S, Kato Y, Yamamoto T, Liu X, Ishikawa E, Kaneko MK, et al. Diagnostic advantage of double immunohistochemistry using two mutation-specific anti-IDH antibodies (HMab-1 and MsMab-1) in gliomas. Brain Tumor Pathology. 2015;32(3):169-75.  
139. Catteau A, Girardi H, Monville F, Poggionovo C, Carpentier S, Frayssinet V, et al. A new sensitive PCR assay for one-step detection of 12 IDH1/2 mutations in glioma. Acta neuropathologica communications. 2014;2:58.  
140. Agarwal S, Sharma MC, Jha P, Pathak P, Suri V, Sarkar C, et al. Comparative study of IDH1 mutations in gliomas by immunohistochemistry and DNA sequencing. Neuro-Oncology. 2013;15(6):718-26.  
141. Choi J, Lee EY, Shin KJ, Minn YK, Kim J, Kim SH. IDH1 mutation analysis in low cellularity specimen: A limitation of diagnostic accuracy and a proposal for the diagnostic procedure. Pathology Research and Practice. 2013;209(5):284-90.  
336  
142. Egoavil CM, Paya A, Irles E, Garcia-Martinez A, Soto JL, Castillejo A, et al. Validation of immunohistochemistry for identification of IDH1 mutation in gliomas. Laboratory Investigation. 2013;93:474A.  
143. Perrech M, Dreher L, Röhn G, Goldbrunner R, Timmer M. Analysis of IDH1 mut expression in human astrocytomas by RT-PCR. Neuro-Oncology. 2013;15:iii149.  
144. Lee D, Suh YL, Kang SY, Park TI, Jeong JY, Kim SH. IDH1 mutations in oligodendroglial tumors: Comparative analysis of direct sequencing, pyrosequencing, immunohistochemistry, nested PCR and PNA-mediated clamping PCR. Brain Pathology. 2013;23(3):285-93.  
145. Loussouarn D, Le Loupp AG, Frenel JS, Leclair F, Von Deimling A, Aumont M, et al. Comparison of immunohistochemistry, DNA sequencing and allele-specific PCR for the detection of IDH1 mutations in gliomas. International Journal of Oncology. 2012;40(6):2058-62.  
146. Preusser M, Wohrer A, Stary S, Hoftberger R, Streubel B, Hainfellner JA. Value and limitations of immunohistochemistry and gene sequencing for detection of the IDH1-R132H mutation in diffuse glioma biopsy specimens. Journal of neuropathology and experimental neurology. 2011;70(8):715-23.  
147. Boisselier B, Marie Y, Labussière M, Ciccarino P, Desestret V, Wang X, et al. COLD PCR HRM: A highly sensitive detection method for IDH1 mutations. Human Mutation. 2010;31(12):1360-5.  
148. Capper D, Weissert S, Balss J, Habel A, Meyer J, Jager D, et al. Characterization of R132H mutation-specific IDH1 antibody binding in brain tumors. Brain pathology (Zurich, Switzerland). 2010;20(1):245-54.  
149. Rajshekhar V, Chandy MJ. Computerized tomography-guided stereotactic surgery for brainstem masses: A risk-benefit analysis in 71 patients. Journal of neurosurgery. 1995;82(6):976-81.  
150. Marques JRLDM, Fernandes M, Passos J, Azevedo AL, Costa I, Nunes JMDA, et al. Brainstem gliomas in adult patients. European journal of neurology. 2015;22:314.  
151. Manoj N, Arivazhagan A, Bhat D, Arvinda H, Mahadevan A, Santosh V, et al. Stereotactic biopsy of brainstem lesions: Techniques, efficacy, safety, and disease variation between adults and children: A single institutional series and review. Journal of Neurosciences in Rural Practice. 2014;5(1):32-9.  
152. Shad A, Green A, Bojanic S, Aziz T. Awake stereotactic biopsy of brain stem lesions: technique and results. Acta neurochirurgica. 2005;147(1):47-9; discussion 9-50.  
337  
153. Boviatsis EJ, Kouyialis AT, Stranjalis G, Korfias S, Sakas DE. CT-guided stereotactic biopsies of brain stem lesions: Personal experience and literature review. Neurological Sciences. 2003;24(3):97-102.  
154. Boviatsis EJ, Voumvourakis K, Goutas N, Kazdaglis K, Kittas C, Kelekis DA. Stereotactic biopsy of brain stem lesions. Minimally Invasive Neurosurgery. 2001;44(4):226-9.  
155. Armstrong TS, Wefel JS, Wang M, Gilbert MR, Won M, Bottomley A, et al. Net clinical benefit analysis of radiation therapy oncology group 0525: a phase III trial comparing conventional adjuvant temozolomide with dose-intensive temozolomide in patients with newly diagnosed glioblastoma. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2013;31(32):4076-84.  
156. Balana C, De Las Penas R, Sepulveda JM, Gil-Gil MJ, Luque R, Gallego O, et al. Bevacizumab and temozolomide versus temozolomide alone as neoadjuvant treatment in unresected glioblastoma: the GENOM 009 randomized phase II trial. Journal of neuro-oncology. 2016;127(3):569-79.  
157. Chauffer B, Feuvret L, Bonnetain F, Taillandier L, Frappaz D, Taillia H, et al. Randomized phase II trial of irinotecan and bevacizumab as neo-adjuvant and adjuvant to temozolomide-based chemoradiation compared with temozolomide-chemoradiation for unresectable glioblastoma: Final results of the TEMAVIR study from ANOCEF. Annals of Oncology. 2014;25(7):1442-7.  
158. Chinot OL, Wick W, Mason W, Henriksson R, Saran F, Nishikawa R, et al. Bevacizumab plus radiotherapy-temozolomide for newly diagnosed glioblastoma. New England Journal of Medicine. 2014;370(8):709-22.  
159. Taphoorn MJB, Henriksson R, Bottomley A, Cloughesy T, Wick W, Mason WP, et al. Health-related quality of life in a randomized phase III study of bevacizumab, temozolomide, and radiotherapy in newly diagnosed glioblastoma. Journal of Clinical Oncology. 2015;33(19):2166-75.  
160. Hofland KF, Hansen S, Sorensen M, Engelholm S, Schultz HP, Muhic A, et al. Neoadjuvant bevacizumab and irinotecan versus bevacizumab and temozolomide followed by concomitant chemoradiotherapy in newly diagnosed glioblastoma multiforme: A randomized phase II study. Acta oncologica (Stockholm, Sweden). 2014;53(7):939-44.  
161. Chang SM, Zhang P, Cairncross JG, Gilbert MR, Bahary JP, Dolinskas C, et al. Results of NRG oncology/RTOG 9813: A phase III randomized study of radiation therapy (RT) and temozolomide (TMZ) versus RT and nitrosourea (NU) therapy for anaplastic astrocytoma (AA). Journal of Clinical Oncology. 2015;33(15).  
162. Kim IH, Park CK, Heo DS, Kim CY, Rhee CH, Nam DH, et al. Radiotherapy followed by adjuvant temozolomide with or without neoadjuvant ACNU-CDDP  
338  
chemotherapy in newly diagnosed glioblastomas: a prospective randomized controlled multicenter phase III trial. Journal of neuro-oncology. 2011;103(3):595-602.  
163. Gilbert MR, Wang M, Aldape KD, Stupp R, Hegi ME, Jaeckle KA, et al. Dosedense temozolomide for newly diagnosed glioblastoma: a randomized phase III clinical trial. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2013;31(32):4085-91.  
164. Wakabayashi T, Natsume A, Mizusawa J, Katayama H, Fukuda H, Shibui S. JCOG0911 integra trial: A randomized screening phase II trial of chemoradiotherapy with interferonβ plus temozolomide versus chemoradiotherapy with temozolomide alone for newly-diagnosed glioblastoma. Neuro-Oncology. 2014;16:v21.  
165. De Groot M TS, Douw L, Vecht C, Klein M, Aronica E, Heimans J, Reijneveld J. Efficacy and tolerability of levetiracetam monotherapy in patients with primary brain tumors and epilepsy. Epilepsia. 2009;12:iii1–iii66.  
166. Kim YH KT, Joo JD, Han JH, Kim YJ, Kim IA, Yun CH, Kim CY. Survival benefit of levetiracetam in patients treated with concomitant chemoradiotherapy and adjuvant chemotherapy with temozolomide for glioblastoma multiforme. Cancer. 2015;121(17):2926-32.  
167. Merrell RT AS, Meyer FB, Lachance DH. Seizures in patients with glioma treated with phenytoin and levetiracetam. Journal of neurosurgery. 2010;113(6):117681.  
168. Rosati A BL, Stefini R, Todeschini A, Cenzato M, Padovani A. . Efficacy and safety of levetiracetam in patients with glioma: a clinical prospective study. Archives of neurology 2010;67(3):343-6.  
169. Wagner GL WE, Van Donselaar CA, Vecht CJ. Levetiracetam: preliminary experience in patients with primary brain tumours. Seizure. 2003;12(8):585-6.  
170. Rossetti AO JS, Novy J, Roth P, Weller M, Stupp R. Levetiracetam and pregabalin for antiepileptic monotherapy in patients with primary brain tumors. A phase II randomized study. Neuro-oncology. 2013;16(4):584-8.  
171. Lim DA TP, Chang E, Burt M, Chakalian L, Barbaro N, Chang S, Lamborn KR, McDermott MW. Safety and feasibility of switching from phenytoin to levetiracetam monotherapy for glioma-related seizure control following craniotomy: a randomized phase II pilot study. Journal of neuro-oncology. 2009;93(3):349-54.  
172. Huang S CJ, Wang L. Epileptic seizures in patients with glioma: A single centrebased study in China. Tropical Journal of Pharmaceutical Research. 2017;16(3):673-9.  
339  
173. Iuchi T HY, Kawasaki K, Sakaida T. Epilepsy in patients with gliomas: incidence and control of seizures. Journal of Clinical Neuroscience. 2015;22(1):87-91.  
174. Woo PY CD, Chan KY, Wong WK, Po YC, Kwok JC, Poon WS. Risk factors for seizures and antiepileptic drug‐associated adverse effects in high‐grade glioma patients: A multicentre, retrospective study in Hong Kong. Surgical practice. 2015;19(1):2-8.  
175. Chaichana KL PS, Olivi A, Quiñones-Hinojosa A. Long-term seizure outcomes in adult patients undergoing primary resection of malignant brain astrocytomas. Journal of neurosurgery. 2009;111(2):282-92.  
176. Chang EF PM, Keles GE, Lamborn KR, Chang SM, Barbaro NM, Berger MS. Seizure characteristics and control following resection in 332 patients with low-grade gliomas. J Neurosurg 2008;108(2):227-35.  
177. Lombardi G, Pambuku A, Bellu L, Farina M, Della Puppa A, Denaro L, et al. Effectiveness of antiangiogenic drugs in glioblastoma patients: A systematic review and meta-analysis of randomized clinical trials. Critical reviews in oncology/hematology. 2017;111:94-102.  
178. Khasraw M, Ameratunga MS, Grant R, Wheeler H, Pavlakis N. Antiangiogenic therapy for high-grade glioma. The Cochrane database of systematic reviews. 2014(9):Cd008218.  
179. Li Y, Hou M, Lu G, Ciccone N, Wang X, Zhang H. The prognosis of antiangiogenesis treatments combined with standard therapy for newly diagnosed glioblastoma: A meta-analysis of randomized controlled trials. PLoS ONE. 2016;11(12).  
180. Wick W, Chinot OL, Bendszus M, Mason W, Henriksson R, Saran F, et al. Evaluation of pseudoprogression rates and tumor progression patterns in a phase III trial of bevacizumab plus radiotherapy/temozolomide for newly diagnosed glioblastoma. Neuro-Oncology. 2016;18(10):1434-41.  
181. Saran F, Chinot OL, Henriksson R, Mason W, Wick W, Cloughesy T, et al. Bevacizumab, temozolomide, and radiotherapy for newly diagnosed glioblastoma: Comprehensive safety results during and after first-line therapy. Neuro-Oncology. 2016;18(7):991-1001.  
182. Taphoorn MJ, Henriksson R, Bottomley A, Cloughesy T, Wick W, Mason WP, et al. Health-Related Quality of Life in a Randomized Phase III Study of Bevacizumab, Temozolomide, and Radiotherapy in Newly Diagnosed Glioblastoma. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2015;33(19):2166-75.  
340  
183. Balana C, De Las Penas R, Sepúlveda JM, Gil-Gil MJ, Luque R, Gallego O, et al. Bevacizumab and temozolomide versus temozolomide alone as neoadjuvant treatment in unresected glioblastoma: the GENOM 009 randomized phase II trial. Journal of neuro-oncology. 2016;127(3):569-79.  
184. Gilbert MR, Pugh SL, Aldape K, Sorensen AG, Mikkelsen T, Penas-Prado M, et al. NRG oncology RTOG 0625: a randomized phase II trial of bevacizumab with either irinotecan or dose-dense temozolomide in recurrent glioblastoma. Journal of neurooncology. 2016;131(1):193-9.  
185. Hofland KF, Hansen S, Sorensen M, Engelholm S, Schultz HP, Muhic A, et al. Neoadjuvant bevacizumab and irinotecan versus bevacizumab and temozolomide followed by concomitant chemoradiotherapy in newly diagnosed glioblastoma multiforme: A randomized phase II study. Acta Oncologica. 2014;53(7):939-44.  
186. Bonnetain F, Dabakuyo TS, Pozet A, Feuvret L, Taillandier L, Frappaz D, et al. Impact of bevacizumab added to temozolomide-chemoradiation on time to healthrelated quality of life deterioration in unresectable glioblastoma: Results of a phase II randomized clinical trial. Journal of Clinical Oncology. 2015;33(15).  
187. Friedman HS, Prados MD, Wen PY, Mikkelsen T, Schiff D, Abrey LE, et al. Bevacizumab alone and in combination with irinotecan in recurrent glioblastoma. Journal of Clinical Oncology. 2009;27(28):4733-40.  
188. Weathers SP, Han X, Liu DD, Conrad CA, Gilbert MR, Loghin ME, et al. A randomized phase II trial of standard dose bevacizumab versus low dose bevacizumab plus lomustine (CCNU) in adults with recurrent glioblastoma. Journal of neurooncology. 2016;129(3):487-94.  
189. Taphoorn M, Bottomley A, Coens C, Reijneveld J, Gorlia T, Brandes AA, et al. Health-related quality of life (HRQoL) in patients with progressive glioblastoma treated with combined bevacizumab and lomustine versus lomustine only (randomized phase iii EORTC study 26101). Neuro-Oncology. 2016;18:vi157.  
190. Taal W, Oosterkamp HM, Walenkamp AM, Dubbink HJ, Beerepoot LV, Hanse MC, et al. Single-agent bevacizumab or lomustine versus a combination of bevacizumab plus lomustine in patients with recurrent glioblastoma (BELOB trial): a randomised controlled phase 2 trial. The Lancet Oncology. 2014;15(9):943-53.  
191. Field KM, Simes J, Nowak AK, Cher L, Wheeler H, Hovey EJ, et al. Randomized phase 2 study of carboplatin and bevacizumab in recurrent glioblastoma. Neuro-oncology. 2015;17(11):1504-13.  
192. Hovey EJ, Field KM, Rosenthal M, Nowak AK, Cher L, Wheeler H, et al. Continuing or ceasing bevacizumab at disease progression: Results from the CABARET study, a prospective randomized phase II trial in patients with recurrent glioblastoma. Journal of Clinical Oncology. 2015;33(15).  
341  
193. Brandes AA, Finocchiaro G, Zagonel V, Reni M, Caserta C, Fabi A, et al. AVAREG: A phase II, randomized, noncomparative study of fotemustine or bevacizumab for patients with recurrent glioblastoma. Neuro-Oncology. 2016;18(9):1304-12.  
194. Reardon DA, Desjardins A, Peters K, Gururangan S, Sampson J, Rich JN, et al. Phase II study of metronomic chemotherapy with bevacizumab for recurrent glioblastoma after progression on bevacizumab therapy. Journal of neuro-oncology. 2011;103(2):371-9.  
195. Yonezawa H, Hirano H, Uchida H, Habu M, Hanaya R, Oyoshi T, et al. Efficacy of bevacizumab therapy for unresectable malignant glioma: A retrospective analysis. Molecular and Clinical Oncology. 2017;6(1):105-10.  
196. Wiestler B, Radbruch A, Osswald M, Combs SE, Jungk C, Winkler F, et al. Towards optimizing the sequence of bevacizumab and nitrosoureas in recurrent malignant glioma. Journal of neuro-oncology. 2014;117(1):85-92.  
197. Niyazi M, Ganswindt U, Schwarz SB, Kreth FW, Tonn JC, Geisler J, et al. Irradiation and bevacizumab in high-grade glioma retreatment settings. International journal of radiation oncology, biology, physics. 2012;82(1):67-76.  
198. Reardon DA, Herndon JE, 2nd, Peters K, Desjardins A, Coan A, Lou E, et al. Outcome after bevacizumab clinical trial therapy among recurrent grade III malignant glioma patients. Journal of neuro-oncology. 2012;107(1):213-21.  
199. Kreisl TN, Zhang W, Odia Y, Shih JH, Butman JA, Hammoud D, et al. A phase II trial of single-agent bevacizumab in patients with recurrent anaplastic glioma. Neurooncology. 2011;13(10):1143-50.  
200. Chamberlain MC JS. Bevacizumab for recurrent alkylator‐refractory anaplastic oligodendroglioma. Cancer. 2009;115(8):1734-43.  
201. Chamberlain MC JS. Salvage chemotherapy with bevacizumab for recurrent alkylator-refractory anaplastic astrocytoma. Journal of neuro-oncology. 2009;91(3):35967.  
202. Desjardins A RD, Herndon JE, Marcello J, Quinn JA, Rich JN, Sathornsumetee S, Gururangan S, Sampson J, Bailey L, Bigner DD. Bevacizumab plus irinotecan in recurrent WHO grade 3 malignant gliomas. Clinical Cancer Research. 2008;14(21):7068-73.  
203. Ye JM YM, Kranz S, Lo P. A 10 year retrospective study of surgical outcomes of adult intracranial pilocytic astrocytoma. . Journal of Clinical Neuroscience. 2014;21(12):2160-4.  
342  
204. Johnson DR BP, Galanis E, Hammack JE. Pilocytic astrocytoma survival in adults: analysis of the Surveillance, Epidemiology, and End Results Program of the National Cancer Institute. Journal of neuro-oncology. 2012;108(1):187-93.  
205. Ishkanian A LN, Xu W, Millar BA, Payne D, Mason W, Sahgal A. Upfront observation versus radiation for adult pilocytic astrocytoma. Cancer. 2011;117(17):4070-9.  
206. Ellis JA WA, Balmaceda C, Canoll P, Bruce JN, Sisti MB. Rapid recurrence and malignant transformation of pilocytic astrocytoma in adult patients. Journal of neurooncology. 2009;95:377.  
207. Brown PD BJ, O'Fallon JR, Iturria NL, Brown CA, O'Neill BP, Scheithauer BW, Dinapoli RP, Arusell RM, Abrams RA, Curran WJ. Adult patients with supratentorial pilocytic astrocytomas: a prospective multicenter clinical trial. International journal of radiation oncology, biology, physics. 2004;58(4):1153-60.  
208. Brown PD, Buckner JC, O'Fallon JR, Iturria NL, Brown CA, O'Neill BP, et al. Effects of radiotherapy on cognitive function in patients with low-grade glioma measured by the folstein mini-mental state examination. Journal of clinical oncology : official journal of the American Society of Clinical Oncology. 2003;21(13):2519-24.  
209. Eyre HJ, Crowley JJ, Townsend JJ, Eltringham JR, Morantz RA, Schulman SF, et al. A randomized trial of radiotherapy versus radiotherapy plus CCNU for incompletely resected low-grade gliomas: a Southwest Oncology Group study. Journal of neurosurgery. 1993;78(6):909-14.  
210. Karim AB, Afra D, Cornu P, Bleehan N, Schraub S, De Witte O, et al. Randomized trial on the efficacy of radiotherapy for cerebral low-grade glioma in the adult: European Organization for Research and Treatment of Cancer Study 22845 with the Medical Research Council study BRO4: an interim analysis. International journal of radiation oncology, biology, physics. 2002;52(2):316-24.  
211. van den Bent MJ, Afra D, de Witte O, Ben Hassel M, Schraub S, Hoang-Xuan K, et al. Long-term efficacy of early versus delayed radiotherapy for low-grade astrocytoma and oligodendroglioma in adults: the EORTC 22845 randomised trial. Lancet (London, England). 2005;366(9490):985-90.  
212. Kiebert GM, Curran D, Aaronson NK, Bolla M, Menten J, Rutten EH, et al. Quality of life after radiation therapy of cerebral low-grade gliomas of the adult: results of a randomised phase III trial on dose response (EORTC trial 22844). EORTC Radiotherapy Co-operative Group. European journal of cancer (Oxford, England : 1990). 1998;34(12):1902-9.  
213. Perry JR, Laperriere N, O'Callaghan CJ, Brandes AA, Menten J, Phillips C, et al. Short-course radiation plus temozolomide in elderly patients with glioblastoma. New England Journal of Medicine. 2017;376(11):1027-37.  
343  
344

---

