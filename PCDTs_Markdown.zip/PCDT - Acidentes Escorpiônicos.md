<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: Geral -->
MINISTÉRIO DA SAÚDE

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
MINISTÉRIO DA SAÚDE Secretaria de Vigilância em Saúde e Ambiente Departamento de Doenças Transmissíveis

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
**Ç**  
2026 Ministério da Saúde.  
Esta obra é disponibilizada nos termos da Licença Creative Commons – Atribuição – Não Comercial – Compartilhamento pela mesma licença 4.0 Internacional. É permitida a reprodução parcial ou total desta obra, desde que citada a fonte.  
A coleção institucional do Ministério da Saúde pode ser acessada, na íntegra, na Biblioteca Virtual em Saúde do Ministério da Saúde: bvsms.saude.gov.br.  
1ª edição – 2026 – versão eletrônica  
_Elaboração, distribuição e informações:_ MINISTÉRIO DA SAÚDE Secretaria de Vigilância em Saúde e Ambiente Departamento de Doenças Transmissíveis Coordenação-Geral de Vigilância de Zoonoses e Doenças de Transmissão Hídrica e Alimentar SRTVN 701, via W5 Norte, Edifício PO 700, 6º andar CEP: 70723-040 – Brasília/DF Site: https://www.gov.br/saude/pt-br/assuntos/saudede-a-a-z/a/animais-peconhentos E-mail: cgzha@saude.gov.br  
Secretaria de Ciência, Tecnologia e Inovação em Saúde Departamento de Gestão e Incorporação de Tecnologias em Saúde Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas Esplanada dos Ministérios, Bloco G, Edifício Sede, 8º andar CEP: 70058-900 – Brasília/DF Site: https://www.gov.br/saude/pt-br/assuntos/pcdt E-mail: pcdt.conitec@saude.gov.br  
_Ministro da Saúde:_ Alexandre Rocha Santos Padilha  
_Secretária de Ciência, Tecnologia e Inovação em Saúde:_ Fernanda De Negri  
_Secretária de Vigilância em Saúde e Ambiente:_ Mariângela Batista Galvão Simão  
###### _Elaboração de texto:_  
Alec Brian Lacerda – NUD/Unifesp Aline Evangelista – NUD/Unifesp Andréa da Silva Dourado – NUD/Unifesp Bruna Bento dos Santos – NUD/Unifesp Camila Francisca Tavares Chacarolli – CGPCDT/Dgits/ SCTIE/MS  
Daniela Oliveira de Melo – NUD/Unifesp Juliana Cordeiro Dias Rodrigues – CGPCDT/Dgits/ SCTIE/MS  
Morgana do Canto Pesenti – NUD/Unifesp Stéfani Sousa Borges – NUD/Unifesp Thais Pinheiro da Costa – NUD/Unifesp  
###### _Revisão técnica_  
Marta da Cunha Lobo Souto Maior – CGPCDT/Dgits/ SCTIE/MS  
_Supervisão:_  
Luciene Fontes Schluckebier Bonan – Dgits/SCTIE/MS Marta da Cunha Lobo Souto Maior – CGPCDT/Dgits/ SCTIE/MS  
_Organização:_  
Etna de Jesus Leal – CGZHA/DEDT/SVSA Flávio Santos Dourado – CGZHA/DEDT/SVSA Francisco Edílson Ferreira de Lima Júnior – CGZHA/ DEDT/SVSA  
Lúcia Regina Montebello Pereira – CGZHA/DEDT/SVSA Silene Lima Dourado Ximenes Santos – CGZHA/ DEDT/SVSA  
_Diagramação:_ Sabrina Lopes – CGEVSA/Daevs/SVSA  
_Revisão textual:_ Tatiane Souza – CGEVSA/Daevs/SVSA  
_Normalização:_ Valéria Gameleira da Mota – Editora MS  
###### Ficha Catalográfica  
Brasil. Ministério da Saúde.  
Protocolo Clínico e Diretrizes Terapêuticas dos Acidentes Escorpiônicos [recurso eletrônico] / Ministério da Saúde. – Brasília : Ministério da Saúde, 2026.  
30 p. : il.  
Modo de acesso: World Wide Web: https://bvsms.saude.gov.br/bvs/publicacoes/pcdt_acidentes_escorpionicos.pdf ISBN 978-65-5993-993-0  
1. Saúde Pública. 2. Animais Venenosos. 3. Protocolos Clínicos. I. Secretaria de Ciência, Tecnologia e Inovação em Saúde. II. Secretaria de Vigilância em Saúde e Ambiente. III. Título.  
Catalogação na fonte – Coordenação-Geral de Documentação e Informação – Editora MS – OS 2025/0526 _Título para indexação:_ Clinical Protocol and Therapeutic Guidelines for Scorpion Accidents  
CDU 614.2  
|**1 **|**CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL**||
|---|---|---|
||**DE DOENÇAS E PROBLEMAS RELACIONADOS**||
||**À SAÚDE – CID-10**|_4_|
|**2  **|**DIAGNÓSTICO**|_5_|
||**2.1 Diagnóstico precoce**|_5_|
||**2.2 Diagnóstico clínico**|_6_|
||**2.3 Diagnóstico diferencial**|_8_|
||**2.4 Tempo de observação**|_8_|
||**2.5 Determinantes de gravidade**|_9_|
|**3**|**CRITÉRIOS DE INCLUSÃO**|_10_|
|**4**|**CRITÉRIOS DE EXCLUSÃO**|_11_|
|**5**|**ABORDAGEM TERAPÊUTICA**|_12_|
||**5.1 Tratamento inicial**|_12_|
||**5.2 Tratamento sintomático**|_13_|
||**5.3 Tratamento específico**|_14_|
|**6  **|**MONITORAMENTO**|_18_|
|**7**|**REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR**|_21_|
|**8**|**FLUXO DE TRATAMENTO**|_23_|
||**REFERÊNCIAS**|_25_|

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
T63.2 Efeito tóxico do contato com animais peçonhentos: veneno de escorpião.  
X22 Contato com escorpiões.

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
##### **2.1 DIAGNÓSTICO PRECOCE**  
O diagnóstico precoce é um fator fundamental no escorpionismo, pois permite o tratamento adequado e imediato, reduzindo a mortalidade e a morbidade<sup>1,2</sup> . Em casos de maior gravidade, o encaminhamento a hospitais ou unidades de saúde com recursos apropriados para oferecer cuidados intensivos é imprescindível. Contudo, a indisponibilidade desses serviços não deve impedir a administração do soro antiveneno<sup>1</sup> .  
Diante da importância do tempo no prognóstico dos pacientes, é necessário um planejamento estratégico para implementação de ações de saúde. O estado de São Paulo, por exemplo, promoveu em 2021 uma reestruturação operacional para garantir o atendimento em tempo oportuno às vítimas de escorpionismo<sup>3</sup> . Além disso, a descentralização de estoques de soro antiveneno e a disponibilidade de profissionais da saúde nas comunidades de difícil acesso são medidas indispensáveis para assegurar o atendimento precoce.  
Nas regiões com isolamento geográfico, condições habitacionais precárias ou dificuldade de acesso aos serviços de saúde, o planejamento da assis tência torna-se um ato de proteção à vida, e não apenas uma intervenção técnica. Assim, é essencial assegurar o atendimento e tratamento rápido, mesmo em cenários desafiadores<sup>4</sup> .  
#### **2.2 DIAGNÓSTICO CLÍNICO**  
O diagnóstico é fundamentalmente clínico-epidemiológico<sup>5,6,7,8</sup> . A dor provocada pela picada do escorpião é a manifestação mais comum e pode estar associada a parestesias com discreto edema local, que se intensifica visto à ação de hialuro nidases e metaloproteinases que degradam a matriz extracelular da pele e aumentam o fluxo sanguíneo para a região afetada<sup>7,8</sup> . Na maioria dos casos, é classificada como de gravi dade leve, com possibilidade de reversão total do quadro<sup>5</sup> .  
As manifestações clínicas em casos moderados e graves se distinguem entre as espécies amazônicas e as de outras regiões do Brasil. Os acidentes causados pelas espécies _Tityus serrulatus, T. stigmurus_ e _T. bahiensis_ são caracterizados por alterações cardiovasculares, respiratórias, digestivas e neurológicas<sup>6,9</sup> . Nos casos moderados, destacam-se sintomas como sudorese, sialorreia, lacrimejamento, náuseas e vômitos (sinal indicativo e sensível de gravidade)<sup>6,9,10,11,12</sup> . Em casos mais graves, os sinais e sintomas mais comuns incluem hipotermia, confusão mental, taquicardia, hipo ou hipertensão, insuficiência ventricular esquerda aguda, edema agudo de pulmão (EAP), dispneia, bradipneia, choque, convulsões. Além disso, os vômitos incoercíveis e a sialorreia podem persistir e se intensificar em estágios com maior agravamento sistêmico<sup>6,10</sup> . Vale destacar que, embora a hipotermia seja comum, a hipertermia também pode ser identificada devido à resposta fisiopatológica variada do organismo diante da severidade do envenenamento<sup>13,14</sup> .  
Por outro lado, as espécies prevalentes na Região Amazônica, como _T. obscurus,_ diferem das demais por apresentarem manifestações predominantemente neurológicas, como mioclonia, disartria, ataxia de marcha e sensação de choque elétrico. Esses sinais e sintomas estão associados à ação direta das toxinas sobre o sistema nervoso central<sup>15</sup> .  
A classificação dos acidentes escorpiônicos adotada atualmente no Brasil pode ser feita em três níveis ( **Quadro 1** ), e é a que orienta as doses de antiveneno a serem empregadas na soroterapia. Outra classificação baseiase em um consenso internacional sobre as características da picada do escorpião ( **Quadro 2** ), que define quatro níveis de gravidade e, embora amplamente aceita pela comunidade científica, não é validada para orientar a administração de soro antiveneno no Brasil<sup>11,16</sup> . No entanto, ambas as classificações não consideram as manifestações neuromusculares relacionadas aos acidentes com escorpiões da Amazônia.  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
6  
###### **QUADRO 1**  
Classificação da gravidade do escorpionismo recomendada pelo Ministério da Saúde  
|**CLASSIFICAÇÃO**|**MANIFESTAÇÃO**|
|---|---|
|**Leve**|Dor, eritema, parestesia, sudorese. Ocasionalmente: náusea, vômito,<br>agitação e taquicardia discretas, relacionadas à dor.|
|**Moderado**|Quadro local associado a algumas das seguintes manifestações<br>sistêmicas de pequena intensidade: sudorese, náuseas, alguns<br>episódios de vômitos, redução ou aumento da frequência cardíaca,<br>aumento da pressão arterial e agitação.|
|**Grave**|Inúmeros episódios de vômitos, sudorese profusa, redução ou aumento<br>da frequência cardíaca, redução ou aumento da pressão arterial,<br>sialorreia, agitação alternada com sonolência, taquidispneia, priapismo,<br>convulsões, insuficiência cardíaca, edema agudo de pulmão.|  
Fonte: Ofício Circular n.º 4/2016 – CGDT/Devit/SVS/MS<sup>16</sup> .  
###### **QUADRO 2**  
Classificação da gravidade do escorpionismo conforme consenso internacional  
|**CLASSIFICAÇÃO**|**MANIFESTAÇÕES**|
|---|---|
|**Picada seca**|Picada de escorpião sem inoculação de veneno caracterizado apenas<br>por dor local.|
|**I**|Locais: erupção bolhosa, sensação de ardor, equimose, eritema,<br>hiperestesia, prurido, necrose, dor, parestesia, púrpura ou petequia,<br>edema, formigação.|
|**II**|Menores (não ameaçadoras à vida): distensão abdominal, agitação<br>ou inquietação ou entusiasmo, anisocoria, artralgia, ataxia, confusão,<br>convulsão, diarreia, boca seca, distonia, encefalopatia, hemorragia<br>gastrointestinal, hematúria, cefaleia, hipertensão, hipertermia,<br>hipotermia, lacrimejamento, câimbras, miose, midríase, mioclonia,<br>náusea, nistagmo, odinofagia, palidez, pancreatite, parestesia geral,<br>priapismo, prostação, ptose, rinorreia, salivação, sonolência ou letargia,<br>estridor, sudorese, taquicardia, sedem retenção urinária, vômitos,<br>presença de sibilos.|
|**III**|Graves (ameaçadoras à vida) – presença de pelo menos um dos<br>seguintes sinais:<br>**■**Insuficiência cardíaca:<br> �hipotensão, arritmia ventricular, bradicardia e colapso<br>cardiovascular.<br>**■**Insuficiência respiratória:<br> �cianose, dispneia e edema agudo de pulmão.<br>**■**Comprometimento neurológico:<br> �escore de Glasgow ≤ 6 (em ausência de drogas sedativas)<br>e paralisia.|  
Fonte: Khattabi _(_ 2011)<sup>17</sup> .  
Inexiste recomendação de exames laboratoriais para confirmação da presença do veneno<sup>8</sup> . No entanto, há exames complementares que podem ser realizados para auxiliar no monitoramento do quadro clínico e na detecção precoce de possíveis complicações, os quais serão abordados no tópico _Monitoramento_<sup>7</sup> .  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
7  
#### **2.3 DIAGNÓSTICO DIFERENCIAL**  
O diagnóstico diferencial é essencial quando as manifestações clínicas de escorpionismo são semelhantes às de outras condições. Nesse contexto, acidentes envolvendo outros animais peçonhentos são objetos de estudo para diferenciar sinais e sintomas<sup>7</sup> .  
O araneísmo é comumente utilizado para essa diferenciação, pois as aranhas habitam ambientes semelhantes aos dos escorpiões. Em particular, a _Phoneutria_ (aranhaarmadeira), gênero de espécies de importância para saúde pública, pode provocar quadro local e sistêmico similar ao dos acidentes escorpiônicos<sup>5,7</sup> . De acordo com especialistas clínicos, a diferenciação clínica entre acidentes provocados por aranhaarmadeira e escorpiões é extremamente difícil. No entanto, a picada da aranha-armadeira pode causar uma reação local mais evidente, acompanhada por edema e dor intensa e de difícil controle, enquanto acidentes com escorpiões, geralmente, não deixam marcas visíveis de picada e o aparecimento de edema é incomum. Diante de dúvida diagnóstica, o soro antiaracnídico ( _Loxosceles_ , _Phoneutria_ e _Tityus_ ), que contém antígenos tanto para aranhas quanto para escorpiões pode ser utilizado<sup>18</sup> .  
#### **2.4 TEMPO DE OBSERVAÇÃO**  
O tempo de observação é determinado conforme as características das manifestações clínicas ( **Quadro 3).** Essas manifestações geralmente surgem nas primeiras horas após o escorpionismo, podendo se prolongar e causar alterações sistêmicas<sup>8</sup> .  
**QUADRO 3**  
Tempo de observação recomendado conforme o tipo de escorpionismo  
|**CLASSIFICAÇÃO**|**PRINCIPAIS MANIFESTAÇÕES**|**TEMPO DE**<br>**OBSERVAÇÃO**|
|---|---|---|
|**Sem clínica de**<br>**envenenamento**|Ausência de manifestações clínicas|4 horas|
|**Casos leves**|Dor, eritema, parestesia, sudorese; ocasionalmente<br>náusea, vômito e agitação e taquicardia discretas,<br>relacionadas à dor.|6 a 12 horas*|
|**Casos que**<br>**requerem soro**<br>**antiveneno**|Manifestações sistêmicas de pequena intensidade<br>persistentes ao tratamento sintomático ou<br>manifestações sistêmicas intensas.|24 horas|  
Fonte: adaptado do Ofício Circular n.º 4/2016 – CGDT/Devit/SVS/MS<sup>16</sup> .  
*Recomenda-se a observação clínica por 6 a 12 horas, conforme a organização e o planejamento do serviço de saúde, garantindo que não haja comprometimento sistêmico que indique a necessidade de terapia antiveneno. Os casos moderados e graves são tratados com soro independentemente da faixa etária.  
Nos casos graves, com instabilidade respiratória ou comprometimento clínico significativo, é indicada a internação com monitorização contínua dos sinais vitais em unidade de terapia intensiva (UTI)<sup>9</sup> . No entanto, a indisponibilidade de cuidados intensivos não deve se tornar barreiras para o atendimento imediato. Em regiões onde não há UTI disponível, esse monitoramento pode ser realizado em unidades de saúde, conforme seus recursos, garantindo, assim, a melhor assistência possível.  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
8  
#### **2.5 DETERMINANTES DE GRAVIDADE**  
<!-- Start of picture text -->
9<br><!-- End of picture text -->  
Crianças com idade menor ou igual a 10 anos, especialmente as menores de 7 anos<sup>3,10,13-15,19,20</sup> , são mais vulneráveis ao desenvolvimento de manifestações sistêmicas graves devido à menor superfície corpórea que leva à maior sensibilidade ao veneno<sup>4,8,11,14,15,21-23</sup> . Entre as associações empíricas feitas em relação aos acidentes e sua gravidade, destaca-se a eliminação mais lenta do veneno na população pediátrica. No entanto, essa correlação foi observada apenas em estudos pré-clínicos<sup>19</sup> . Entre outros fatores de risco somados à idade estão as comorbidades, como hipertensão arterial sistêmica, diabete melito, cardiopatias e nefropatias<sup>24</sup> . No entanto, o tratamento para idosos não difere do aplicado a adultos mais jovens<sup>10,12</sup> .  
A gravidade do quadro também pode ser influenciada pela relação da quantidade de veneno e o peso corporal do paciente, pela espécie do escorpião e pelo tempo decorrido entre o acidente e a assistência médica<sup>25</sup> . Outro fator é a concentração plasmática do veneno circulante, que pode ser medida por ensaio imunoenzimático e pode ter relação direta ao desenvolvimento de manifestações sistêmicas<sup>26</sup> . Além disso, a localização da picada parece ter associação a complicações sistêmicas, devido à proximidade dos órgãos vitais e ao fato de o retorno venoso dos membros inferiores para o coração ser mais lento<sup>1,8</sup> .  
Há diversas outras hipóteses de fatores que podem influenciar na gravidade dos acidentes. Acredita-se, por exemplo, que o comportamento do escorpião em resposta à ameaça percebida pode agravar a condição clínica. Dados experimentais mostram que escorpiões da família Buthidae possuem a capacidade de regular a composição do veneno. Quando percebem uma ameaça maior, o veneno tende a ter uma aparência leitosa, caso contrário, sua coloração é clara<sup>27</sup> .  
9 Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
Serão incluídos pacientes de todas as faixas etárias com manifestações compatíveis com picadas de escorpiões, independentemente da gravidade do quadro clínico.  
**Para o uso de soroterapia** , devem ser utilizados em casos moderados ou graves de acidentes causados por picadas de escorpiões do gênero _Tityus_ .  
Se a paciente estiver grávida, antes de iniciar o tratamento com soro antiveneno, o médico deverá ser informado.

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
Serão excluídas pessoas que, após investigação, determine-se que as manifestações são causadas por acidentes com outros animais peçonhentos.  
Os critérios de exclusão também deverão considerar a idade, hipersensibilidade e contraindicações previstas em bula, para cada um dos medicamentos recomendados no documento.

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
#### **5.1 TRATAMENTO INICIAL**  
Na ocorrência de escorpionismo, o primeiro cuidado deve ser a lavagem do local da picada com água e sabão, evitando o uso de torniquetes ou a aplicação de qualquer substância sobre o ferimento não indicada pela equipe de saúde<sup>7</sup> . Após a chegada na Unidade Básica de Saúde, o tratamento deve ser orientado pelas manifestações clínicas apresentadas pelo paciente.  
#### **5.2 TRATAMENTO SINTOMÁTICO**  
Na chegada do paciente à unidade de saúde, deve ser realizado o tratamento sintomático, conforme os sinais e sintomas apresentados pelo paciente. Para o tratamento da dor, é fundamental utilizar um instrumento de escala de dor (detalhada no item Monitoramento) para definição da analgesia, independentemente do uso do soro antiveneno. Em casos de dor leve, as evidências recomendam o uso de dipirona por via oral<sup>2,5,7,9,12,23,28-30</sup> . Na presença de dor moderada, pode-se optar pela administração intravenosa (IV) da dipirona, e na dor intensa, associase à infiltração local de lidocaína a 2% sem vasoconstritor<sup>5,7,9,23</sup> , que pode ser repetida até três vezes, em intervalos de 40 a 60 minutos<sup>9,10,23</sup> . Há incertezas quanto ao uso de bloqueio anestésico local em acidentes escorpiônicos causados por espécies da Região Amazônica, uma vez que pode intensificar a sensação de choque elétrico<sup>2</sup> . No entanto, essa manifestação precisa ser analisada no contexto da prática clínica, uma vez que as evidências científicas disponíveis, ainda limitadas, não permitem sustentar uma recomendação sobre o uso desse recurso. Em caso de recidiva da dor, recomenda-se a associação de um opioide fraco<sup>7,9,12,23,25</sup> . Além do controle da analgesia, sugere-se aplicar uma compressa morna na área afetada, visando à redução da intensidade da dor.  
O uso da dexametasona para tratar a inflamação provocada pela picada do escorpião ainda está sob investigação e não é recomendado. No momento, apenas estudos préclínicos sobre seu uso em acidentes escorpiônicos foram identificados<sup>31-35</sup> .  
Nos casos moderados, o tratamento inclui a soroterapia<sup>5,6,12,19,23,24</sup> . Quando necessário, a desidratação pode ser tratada com cloreto de sódio a 0,9% (soro fisiológico) de forma cautelosa, principalmente em crianças, evitando-se a sobrecarga hídrica e consequente evolução para choque cardiogênico<sup>23</sup> . Os distúrbios metabólicos, como hipocalemia e hiperglicemia, podem ser identificados, no entanto, tendem a se normalizar em até 24 horas após o soro antiveneno específico<sup>5</sup> . Na presença de vômitos profusos, que não se cessam após a soroterapia, as evidências recomendam o uso de antieméticos, especialmente metoclopramida<sup>7,9,19,28,29</sup> . Como a metoclopramida tem uso restrito em crianças e adolescentes, outros antieméticos podem ser utilizados na população pediátrica, conforme disponibilidade. Recomenda-se o uso criterioso dessa classe terapêutica, com atenção à possibilidade, ainda que incomum, de reações adversas cardiológicas<sup>36,37</sup> .  
Benzodiazepínicos, como o diazepam, podem ser utilizados no tratamento dos acidentes escorpiônicos envolvendo espécies da Região Amazônica, onde as manifestações neuromusculares são prevalentes<sup>31</sup> . Nesse contexto, essa terapia medicamentosa auxilia no controle das mioclonias, proporcionando alívio dos sintomas e conforto ao paciente<sup>6,12,19,24,38</sup> .  
A hipertensão arterial geralmente possui caráter transitório e tende a se normalizar após o tratamento específico, não exigindo intervenção medicamentosa. No entanto, caso a elevação da pressão arterial persista, após o uso do soro antiveneno, alfabloqueadores, vasodilatadores e bloqueadores de canais de cálcio podem ser considerados como opções terapêuticas<sup>1,3,13,20,39</sup> .  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
13  
A administração intravenosa da furosemida é recomendada como terapia de suporte em casos de insuficiência cardíaca congestiva ou edema agudo de pulmão (EAP)<sup>8,9,23,28,29,39</sup> . Além disso, há evidências que apontam os benefícios da oxigenoterapia, seja em associação a diureticoterapia ou de forma isolada<sup>9,12,25,27,35</sup> .  
Em casos graves, com presença de hipotensão ou choque, recomenda-se o uso de aminas vasoativas, preferencialmente a dobutamina<sup>5,9,23,28,39,40-43</sup> , se disponível, a milrinona pode ser utilizada. Contudo, caso o paciente apresente choque misto (distributivo e cardiogênico) pode ser necessário o uso de aminas vasopressoras, como a noradrenalina<sup>23</sup> . No entanto, sugere-se cautela no tratamento do escorpionismo em crianças com o uso de noradrenalina e adrenalina<sup>38</sup> . Além da administração desses inotrópicos, a associação com ventilação mecânica pode contribuir para a melhora do choque<sup>5,6,8,9,23,25,28,29,41,43</sup> .  
A terapia com insulina em altas doses tem sido apontada para tratamento do choque cardiogênico induzido por intoxicações medicamentosas<sup>44</sup> . Contudo, sua aplicação no tratamento do choque cardiogênico associado ao escorpionismo permanece limitada, e inexistem evidências que justifiquem sua recomendação.  
Inexiste recomendação para o uso de antibióticos como medida profilática no escor pionismo. No entanto, infecções secundárias relacionadas ao agravo devem ser tratadas conforme necessidade<sup>10,24,45</sup> . Já a profilaxia antitetânica deve ser realizada conforme o esquema de condutas profiláticas de acordo com o tipo de ferimento e a situação vacinal, previstos no calendário do Ministério da Saúde<sup>18</sup> .  
#### **5.3 TRATAMENTO ESPECÍFICO**  
O soro antiescorpiônico deve ser administrado o mais precocemente possível, com o objetivo de neutralizar o veneno circulante do escorpião, de acordo com a gravidade do envenenamento<sup>5</sup> ( **Quadro 4** ). Em casos classificados como moderados ou graves, a administração desse soro é recomendada imediatamente, independentemente da idade. Na ausência do soro antiescorpiônico ou na dúvida diagnóstica entre acidentes escorpiônicos e aracnídicos, o soro antiaracnídico ( _Loxosceles_ , _Phoneutria_ e _Tityus_ ) pode ser utilizado<sup>18</sup> .  
Após a administração do soro antiveneno, o paciente deverá ser monitorado e mantido em observação clínica por, no mínimo, 24 horas<sup>16</sup> . Caso as manifestações persistam, o quadro deve ser reclassificado para que o tratamento com o soro antiveneno seja ajustado e, se necessário, complementado, visando à reversão dos sinais de envenenamento<sup>15</sup> .  
O tratamento com o soro antiveneno parece apresentar diferenças na efetividade entre acidentes causados por _T. serrulatus_ e _T. obscurus_ , devido às variações nas estruturas primárias das toxinas, no perfil eletroforético e nos epítopos antigênicos dessas espécies<sup>45</sup> . Como resultado, alguns sintomas comuns característicos dos acidentes da Região Amazônica podem persistir mesmo após a soroterapia produzida pelo antígeno de _T. serrulatus_ , sendo necessária a complementação com o tratamento sintomático,  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
14  
como o uso de benzodiazepínicos<sup>11,45</sup> . No entanto, enquanto são necessários estudos para desenvolver um soro específico para as espécies da Região Amazônica ou para revisar as doses do soro disponível, recomenda-se o uso do soro antiescorpiônico independentemente do escorpião do gênero _Tityus_ .  
Embora reações de hipersensibilidade precoce possam ocorrer, seu agravamento é raro, pois, em alguns casos de acidentes escorpiônicos, a presença de manifestações adrenérgicas parece impedir o desenvolvimento desses eventos adversos<sup>5,21,23</sup> . Quando presentes, os sinais e sintomas abrangem desde reações cutâneas até broncoespasmo e insuficiência respiratória. O uso profilático de corticosteroides e antihistamínicos não é recomendado, já que não impedem completamente o surgimento de manifestações alérgicas e, também, devido à baixa frequência que esses eventos ocorrem<sup>10</sup> .  
É importante destacar que tanto o soro antiaracnídico quanto o soro antiescorpiônico podem desencadear reações de hipersensibilidade imediata, assim como reações tardias, como a doença do soro, caracterizada por febre, urticária, erupções cutâneas e outras manifestações de intensidade variável, que exigem monitoramento e tratamento imediato<sup>46-48</sup> .  
###### **5.3.1 MEDICAMENTOS**  
- **Soro antiescorpiônico (SAEsc) ▶** solução injetável que contém imunoglobulinas heterólogas que neutralizam 1,0 mg de veneno-referência de _Tityus serrulatus_ (soroneutralização em camundongo) por mL de soro.  
Indicado para o tratamento dos envenenamentos causados por picadas de escorpiões do gênero _Tityus_ . As imunoglobulinas específicas presentes no soro se ligam ao veneno que ainda não se fixou nas células dos tecidosalvo, neutralizandoo<sup>47</sup> .  
- **Soro antiaracnídico (** **_Loxosceles, Phoneutria e Tityus_ ) (SAA) ▶** solução injetável que contém imunoglobulinas heterólogas que neutralizam, no mínimo, 1,5 Dose Mínima Mortal (DMM) de veneno de _Tityus serrulatus_ (1,5 DMM/mL), 1,5 DMM de veneno de _Phoneutria nigriventer_ (1,5 DMM/mL) e 15 Dose Mínima Necrosante (DMN) de veneno de _Loxosceles gaucho_ (15 DMN/mL).  
Indicado para o tratamento dos envenenamentos causados por picadas de aranhas dos gêneros _Loxosceles_ e _Phoneutria_ e de escorpiões do gênero _Tityus_ . Seu uso em escorpionismo é recomendado apenas na ausência do soro antiescorpiônico, e em casos de **impossibilidade de diferenciação** entre os acidentes com aranhas do gênero _Phoneutria_ e escorpiões do gênero _Tityus_ . As imunoglobulinas específicas contidas no soro ligamse especificamente ao veneno ainda não fixado nas células dos tecidos eletivos, neutralizando-o<sup>48</sup> .  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
15  
###### **5.3.2 ESQUEMAS DE ADMINISTRAÇÃO**  
Há incertezas quanto às doses de antiveneno no esquema de administração atualmente adotado. Os estudos incluídos em uma síntese de evidências sobre o uso de soroterapia no escorpionismo (Apêndice 1) identificaram ampla variação na quantidade de soro antiveneno usado: de 1 a 20 frascos-ampolas, administrados de acordo com a gravidade dos casos. Isso diverge das orientações do Ministério da Saúde, especialmente nos casos leves, para os quais não há indicação do uso de soro antiveneno.  
Dada a heterogeneidade das evidências disponíveis sobre as doses de soro antiveneno a serem utilizadas, bem como a escassez de estudos específicos para a população pediátrica, não se justifica uma atualização nas orientações das doses de antiveneno estabelecidas pelo Ministério da Saúde para o tratamento do escorpionismo, e esta deve ser utilizada para determinar as quantidades de terapia antiveneno ( **Quadro 4** ). O uso racional do soro deve ser priorizado, e é fundamental que a administração seja realizada de forma criteriosa, considerando a gravidade do envenenamento e os riscos associados ao tratamento.  
**QUADRO 4**  
Classificação do escorpionismo quanto à gravidade e ao tratamento específico  
|**CLASSIFICAÇÃO**|**SORO ANTIVENENO SAESC* OU SAA****|
|---|---|
|**Leve**|-|
|**Moderado**|3 frascos-ampolas|
|**Grave**|6 frascos-ampolas|  
Fonte: adaptado de Funasa (2001)<sup>5</sup> . *SAEsc: Soro Antiescorpiônico; **SAA: Soro Antiaracnídico ( _Loxosceles_ , _Phoneutria_ e _Tityus_ ). Nota: não devem ser administrados mais que 6 frascos-ampolas.  
O soro antiescorpiônico deve ser administrado por via intravenosa ou, em situações em que não for possível o acesso venoso, por via intraóssea (na indisponibilidade de acesso venoso). Na administração intravenosa, a solução deve ser diluída em cloreto de sódio a 0,9% (soro fisiológico) ou em solução glicosada a 5%, na proporção de 1:2 a 1:5, podendo ser realizada também na proporção 1:1<sup>14,25,45,47</sup> . Quando diluído, o soro antiveneno parece reduzir a frequência de reações adversas<sup>45</sup> . A infusão deve ser realizada em um período de 10 a 15 minutos ou em _bolus_ , com uma velocidade de 8 a 12 mL/min, com atenção especial ao risco de sobrecarga hídrica em crianças com insuficiência cardíaca e/ou EAP<sup>25,45,47</sup> .  
Quando necessário, o uso de soro antiaracnídico deve seguir as mesmas recomendações aplicadas ao soro antiescorpiônico, exceto pelo tempo de infusão, que deve ser maior (entre 20 e 60 minutos)<sup>23,48</sup> .  
Quanto aos cuidados com a administração, a equipe multiprofissional desempenha um papel essencial. Deve-se seguir atentamente as instruções da bula dos medicamentos e garantir a infusão correta. O farmacêutico, por sua vez, é fundamental na revisão das prescrições, além de orientar sobre o uso, armazenamento e transporte do soro  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
16  
antiveneno<sup>49</sup> . A atuação integrada desses profissionais com a equipe médica, aliada a uma rotina de capacitação, é indispensável para garantir a segurança e efetividade do tratamento<sup>50</sup> .  
###### **5.3.3 ARMAZENAMENTO E TRANSPORTE**  
Os soros antiescorpiônico e antiaracnídico devem ser armazenados e transportados em temperaturas entre 2°C e 8°C, evitando-se o congelamento. Após a abertura, deve ser utilizado imediatamente<sup>47,48</sup> . O serviço de saúde deve adotar um plano de contingência para falta de energia e situações de risco para armazenamento, conforme o _Manual de Rede de Frio do Programa Nacional de Imunizações_<sup>51</sup> .  
Para garantir que a assistência aos pacientes seja realizada de forma eficiente e contínua, é importante identificar e mitigar as fragilidades das unidades de saúde, especialmente as remotas, como a falta ocasional de soro e condições de armazenamento e transporte.  
###### **5.3.4 CRITÉRIOS DE INTERRUPÇÃO**  
A interrupção da terapia específica com os soros antiescorpiônico ou antiaracnídico deve ser considerada especialmente em casos de reações de hipersensibilidade, conforme orientação médica. Após a remissão dos sintomas, o tratamento deve ser reinstituído<sup>47</sup> .  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
17

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
A monitorização dos parâmetros vitais – como pressão arterial, frequência cardíaca, frequência respiratória, saturação de oxigênio e temperatura corporal – são essenciais no acompanhamento dos casos de escorpionismo, especialmente aqueles com indicação de soro antiveneno<sup>23</sup> . Quando indicada, a soroterapia requer que o paciente seja monitorado por pelo menos 24 horas, conforme tópico **Tempo de Observação** , para avaliação de sua efetividade e identificação de possíveis eventos adversos.  
A mensuração da intensidade da dor a partir de escalas permite direcionar o tratamento analgésico e prevenir sua recorrência<sup>10,15,23</sup> . A escala verbal numérica (EVN) ( **Figura 1** ), que classifica a dor em quatro categorias, orienta a escolha do analgésico, conforme descrito no tópico Tratamento sintomático<sup>23</sup> .  
Além da EVN, outras escalas – como a de faces e a visual analógica – podem ser utilizadas para monitorar a eficácia da analgesia<sup>10,23,24</sup> . Na monitorização da dor em crianças, a escala de faces é frequentemente preferida, pois utiliza uma abordagem lúdica e acessível para facilitar a comunicação sobre a intensidade da dor<sup>10</sup> .  
**FIGURA 1**  
**Escala verbal numérica – EVN**  
|**sem dor**||**dor leve**|**dor**|**modera**|**da**|**dor intensa**||
|---|---|---|---|---|---|---|---|
|**0**|**1**|**2**|**3**<br>**4**|**5**|**6**|**7**<br>**8**<br>**9**|**10**|  
Fonte: adaptado de Drummond (2000).  
Os exames complementares são indicados apenas na presença de manifestações sistêmicas, quando é necessário monitorar a evolução do envenenamento e do desen volvimento da Síndrome da Resposta Inflamatória Sistêmica (Sirs)<sup>17,23</sup> . Contudo, a indisponibilidade desses exames não deve ser impedimento para a administração do soro antiveneno.  
Entre os principais exames laboratoriais utilizados na monitorização do escorpionismo estão o hemograma completo, a glicemia, os eletrólitos (especialmente potássio), a amilase e a gasometria<sup>5-9,20,25</sup> . Estes últimos são utilizados para detecção de hipocalemia, hiperamilasemia e acidose metabólica. Nos achados hematológicos, a leucocitose com neutrofilia é a alteração mais comum, reflexo da elevação da atividade adrenérgica<sup>6,39,42</sup> . A hiperglicemia observada geralmente ocorre nas primeiras 24 horas após o acidente, sendo decorrente da resistência insulínica transitória. Em casos pediátricos ou potencialmente graves, o uso da glicemia capilar para detecção precoce e prevenção do agravamento clínico é útil<sup>23</sup> . Também podem ser consideradas as dosagens de ureia e creatinina como marcadores de monitorização da função renal<sup>25</sup> .  
O exame de urina rotina também pode ser utilizado no monitoramento para detecção de glicosúria, cetonúria e hemoglobinúria<sup>6,23,25</sup> . A mioglobinúria, também detectável nesse exame, pode ser utilizada como um marcador de rabdomiólise, especialmente em acidentes provocados por _T. obscurus_<sup>12</sup> _._ Durante a anamnese, é essencial investigar a retenção urinária, que é uma queixa comum, especialmente em casos ocorridos na Região Amazônica. No entanto, embora esse sintoma seja significativo no exame clínico, trata-se de um exame pouco avaliado nos estudos clínicos. Além disso, a observação da retenção urinária, sem outros exames, não é um parâmetro determinante para o diagnóstico ou a suspeita de agravamento clínico<sup>6,17,24,52</sup> .  
Para avaliação de danos ao miocárdio, a creatinoquinase (CK), especialmente sua fração MB, é um parâmetro utilizado no acompanhamento clínico. Juntamente à CKMB, a troponina se destaca como um marcador na investigação de alterações cardiovasculares<sup>6,7,9,17,23,41-43,53</sup> . Além disso, a dosagem do peptídeo NT-proBNP pode ser útil na detecção de insuficiência cardíaca<sup>6</sup> .  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
19  
Entre os exames de imagem, a radiografia de tórax permite identificar sinais de congestão, edema pulmonar (uni ou bilateral) e aumento da área cardíaca<sup>5-7,9,23,28,29,52</sup> . O ecocardiograma é amplamente utilizado na detecção de miocardite, revelando possíveis alterações como redução da fração de ejeção, hipocinesia do ventrículo esquerdo e regurgitação mitral<sup>6,20,28,41,42,43</sup> . Além disso, o eletrocardiograma é uma ferramenta importante para detectar arritmias ventriculares, como extrassístoles, taquicardia sinusal ou bradicardia, fibrilação atrial, ondas U proeminentes e inversão da onda T em múltiplas derivações. Sua utilização é recomendada na admissão ao serviço de saúde, especialmente em crianças, devido à rápida evolução dos quadros clínicos<sup>5,6,8,9,14,17,40,42</sup> .  
Por outro lado, a ultrassonografia pulmonar e a ecocardiografia cardíaca à beira leito (Ultrassonografia PointofCare – POCUS) emergem como opções rápidas para detecção precoce de sinais de gravidade, como a disfunção ventricular e o EAP<sup>53</sup> . No entanto, o acesso à essa tecnologia ainda é limitado, o que faz com que exames tradicionais sejam mais utilizados.  
Na maioria dos casos, os pacientes evoluem de forma favorável, apresentando apenas leves alterações no eletrocardiograma e no ecocardiograma. Em casos mais graves, a evolução pode incluir choque cardiogênico, que representa um risco significativo à vida<sup>6</sup> . Destaca-se que, em situações graves, o soro antiveneno nem sempre é capaz de reverter completamente as alterações hemodinâmicas, como edema agudo de pulmão e choque cardiogênico<sup>17</sup> . No entanto, a literatura ainda carece de estudos aprofundados sobre essas e outras complicações, especialmente em longo prazo.  
A tomografia computadorizada do crânio é indicada quando há suspeita de acidente vascular cerebral ou outras complicações neurológicas, ainda que pouco frequentes. Na presença de hemiplegia, por exemplo, o exame pode auxiliar na identificação de alterações compatíveis com infarto cerebral<sup>5,6,9</sup> . Na Região Amazônica, pode-se usar escalas e testes para monitorar déficits neurológicos, devido à predominância de manifestações neuromusculares nos acidentes escorpiônicos. Entre os instrumentos, destacam-se a escala de Glasgow para avaliação do nível de consciência, o teste de tônus muscular (Escala de Ashworth Modificada), a avaliação dos pares cranianos (III, IV, V, VII e VIII), o Teste de Espasmo Muscular e a Escala Cooperativa Internacional para Avaliação de Ataxias (ICARS)<sup>10,24</sup> .  
Todos os procedimentos mencionados estão disponíveis na Rede de Atenção em Saúde para todas as faixas etárias, exceto o POCUS. Além disso, a dosagem do peptídeo NTproBNP está disponível apenas para a detecção de insuficiência cardíaca em adultos.  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
20

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste protocolo, a duração e a monitorização do tratamento, bem como para a verificação das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Os casos de envenenamento devem ser encaminhados, sempre que possível, a hospitais de referências para o atendimento de acidentes por animais peçonhentos, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com indicação de uso de soro antiveneno devem ser monito rados por 24 horas para avaliação do tratamento e da prevenção de manifestações sistêmicas. A existência de centro de referência facilita o tratamento em si, bem como o controle de possíveis reações de hipersensibilidade.  
Devese verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste protocolo.  
<!-- Start of picture text -->
22<br><!-- End of picture text -->  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s), e encaminhar essas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (Bnafar), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02) e terapêuticos clínicos (Grupo 03) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a condição clínica, no Sistema de Gerenciamento da Tabela (Sigtap) (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada. Os procedimentos citados neste PCDT são compatíveis com os seguintes códigos:  
- 02.14.01.001-5 **▶** GLICEMIA CAPILAR  
- 02.02.01.060-0 **▶** DOSAGEM DE POTASSIO  
- 02.02.01.018-0 **▶** DOSAGEM DE AMILASE  
- 02.02.01.069-4 **▶** DOSAGEM DE UREIA  
- 02.02.01.031-7 **▶** DOSAGEM DE CREATININA  
- 02.02.05.011-4 **▶** DOSAGEM DE PROTEINAS (URINA DE 24 HORAS)  
- 02.02.01.032-5 **▶** DOSAGEM DE CREATINOFOSFOQUINASE (CPK)  
- 02.02.01.033-3 **▶** DOSAGEM DE CREATINOFOSFOQUINASE FRAÇÃO MB  
- 02.02.03.120-9 **▶** DOSAGEM DE TROPONINA  
- 02.02.01.079-1 **▶** DOSAGEM DE PEPTÍDEOS NATRIURÉTICOS TIPO B (BNP E NT-PROBNP)  
- 02.02.02.038-0 **▶** HEMOGRAMA COMPLETO  
- 02.04.03.017-0 **▶** RADIOGRAFIA DE TORAX (PA)  
- 02.05.01.003-2 **▶** ECOCARDIOGRAFIA TRANSTORACICA  
- 02.05.02.013-5 **▶** ULTRASSONOGRAFIA DE TORAX (EXTRACARDIACA)  
- **02.06.01.007-9 ▶ TOMOGRAFIA COMPUTADORIZADA DO CRÂNIO**  
22 Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
**FIGURA 2**  
###### Fluxo de tratamento dos acidentes escorpiônicos  
<!-- Start of picture text -->
Escorpionismo<br>CONFIRMADO ou SUSPEITO<br>Manter o paciente em  Não Clínica de  Sim  O CIATox deve ser consultado para<br>observação por  4 horas envenenamento? apoio na identificação da espécie,<br>classificação de gravidade, diagnóstico<br>diferencial, definição da conduta,<br>Não Reavaliar clínica   Sim Avaliar sintomas clínicos   indicação de soro, avaliação da<br>e aplicar escala de dor necessidade de transferência, condutas<br>de envenenamento?<br>complementares e prognóstico.<br>Não Sintomas  Sim<br>sistêmicos?<br>Não Sintomas  Sim<br>intensos?<br>CASO MODERADO CASO GRAVE<br>CASO LEVE<br>Quadro local associado a algumas manifestações  Inúmeros episódios de vômitos, sudorese profusa,<br>Dor, eritema, parestesia, sudorese.<br>sistêmicas de pequena intensidade (sudorese,  redução ou aumento da frequência cardíaca, redução ou<br>Ocasionalmente: náusea, vômito,<br>náuseas, alguns episódios de vômitos, redução  aumento da pressão arterial, sialorreia, agitação alternada<br>agitação e taquicardia discretas,<br>ou aumento da frequência cardíaca, aumento da  com sonolência, taquidispneia, priapismo, convulsões,<br>relacionadas à dor.<br>pressão arterial e agitação).  insuficiência cardíaca, edema agudo de pulmão.<br>Controle analgésico e de  SAEsc ou SAA:  SAEsc ou SAA: Em caso de escorpionismo<br>náuseas, compressa quente   com espécies amazônicas, pode<br>3 frascos-ampolas** 6 frascos-ampolas<br>e/ou bloqueio anestésico haver sintomas neurológicos.<br>Manter o paciente em internação (CTI) com  Reavaliar o<br>Para aqueles submetidos à soroterapia, manter<br>Manter o paciente  em internação por, no mínimo, 24 horas monitoramento contínuo por, no mínimo, 24 horas quadro clínico<br>em observação   do paciente para<br>por 6 a 12 horas* Controle de dor e náuseas, compressa quente Controle de dor e náuseas, demais tratamentos  complementar<br>sintomáticos conforme necessidade.<br>tratamento<br>ALTA<br>Em regiões sem CTI disponível,<br>o monitoramento pode ser realizado em<br>unidades de saúde conforme seus recursos.<br>Não Necessidade de  Sim<br>reclassificação?<br><!-- End of picture text -->  
Fonte: adaptado de Drummond (2000).  
Legenda: CIATox: Centro de Informação e assistência Toxicológica; SAEsc: Soro Antiescorpiônico; SAA: Soro Antiaracnídico ( _Loxosceles_ , _Phoneutria_ e _Tityus_ ); CTI: Centro de Terapia Intensiva. *Conforme a organização e o planejamento do serviço de saúde, garantindo que não haja comprometimento sistêmico que indique a necessidade de soro antiveneno.  
**Independentemente da faixa etária, recomenda-se utilizar três ampolas para casos moderados e seis para casos graves. Os pacientes não devem receber mais que seis ampolas. Nota: O SAA pode ser utilizado na falta do SAEsc ou na dúvida diagnóstica.

---

<!-- METADADOS: doenca: PCDT - Acidentes Escorpiônicos | secao: PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DOS <mark>ACIDENTES ESCORPIÔNICOS</mark> -->
<!-- Start of picture text -->
25<br><!-- End of picture text -->  
1. NOBRE SOMBRA, N. N. _et al._ ClinicalLaboratory Profile of Child and Young Populations Bit By Scorpion Attended at a Information and Assistance Toxicological Center in Brazil. **Journal of Young Pharmacists** , v. 13, n. 3, p. 246-250, 15 set. 2021. DOI: https://dx.doi.org/10.5530/jyp.2021.13.50. Disponível em: https://archives.jyoungpharm.org/article/1583. Acesso em: 24 nov. 2025.  
2.  DA SILVA, B. A. J. _et al._ Implication of Tityus apiacas (Lourenco, 2002) in scorpion envenomations in the southern Amazon border, Brazil. **Revista da Sociedade Brasileira de Medicina Tropical** , v. 50, n. 3, p. 427–430, 2017. DOI: https://doi.org/10.1590/0037-8682-0490-2016. Disponível em: https://www.scielo.br/j/rsbmt/a/PdgnH77sSTgPQQZPwYQ46xx. Acesso em: 24 nov. 2025.  
3. ELOY, L. _et al._ Escorpionismo no estado de São Paulo: Reestruturação Operacional para o Atendimento Oportuno às Vítimas. **Boletim Epidemiológico Paulista** , v. 18, n. 209, p. 16-30, 2021. DOI: https://doi.org/10.57148/bepa.2021.v.18.36653. Disponível em: https://periodicos.saude.sp.gov.br/BEPA182/article/view/36653. Acesso em: 24 nov. 2025.  
4. TORREZ, P. P. Q.; BERTOLOZZI, M. R.; FRANÇA, F. O. de S. Vulnerabilities and clinical manifestations in scorpion envenomations in Santarém, Pará, Brazil: a qualitative study. **Revista da Escola de Enfermagem** , v. 54, p. 1-7, 2020. DOI: https://doi.org/10.1590/S1980-220X2018050403579. Acesso em: 24 nov. 2025.  
5.  FUNDAÇÃO NACIONAL DE SAÚDE (Brasil). **Manual de Diagnóstico e Tratamento de Acidentes por Animais Peçonhentos** . 2. ed. rev. Brasília, DF: Ministério da Saúde, 2001. Disponível em: https://portaldeboaspraticas.iff.fiocruz.br/wpcontent/ uploads/2025/03/Manual-de-diagnostico-e-tratamento-de-acidentes-por-animaispeconhentos.pdf. Acesso em: 24 nov. 2025.  
6.  CUPO, P. Clinical update on scorpion envenoming. **Revista da Sociedade Brasileira de Medicina Tropical** , v. 48, n. 6, 2015. DOI: https://doi.org/10.1590/00378682-0237-2015. Disponível em: https://www.scielo.br/j/rsbmt/a/ C6vMnTMvwrwXmBSWjySsVYm. Acesso em: 24 nov. 2025.  
7. PARRELA, A. F. B. _et al._ Scorpion envenomation in Brazil: an update. **Infectio** , v. 26, n. 2, p. 172-180, 2022. DOI: https://doi.org/10.22354/in.v26i2.1018. Disponível em: http://revistainfectio.org/P_OJS/index.php/infectio/article/view/1018. Acesso em: 24 nov. 2025.  
25 Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
8.  ORNELAS, Y. C. R. C. **Escorpionismo em crianças e adolescentes do Norte de Minas Gerais** : aspectos epidemiológicos e clínicos associados aos casos graves. 120 f. Dissertação (Mestrado em em Cuidado Primário em Saúde) – Programa de Pós-Graduação em Cuidado Primário em Saúde, Universidade Estadual de Montes Claros, 2022. Disponível em: https://repositorio.unimontes.br/handle/1/1920. Acesso em: 24 nov. 2025.  
9.  CUPO, P.; HERING, S. E.; AZEVEDO-MARQUES, M. M. Acidentes por animais peçonhentos: escorpiões e aranhas. **Medicina** , Ribeirão Preto, v. 36, p. 490-497, 2003. Disponível em: https://repositorio.usp.br/item/001440586. Acesso em: 24 nov. 2025.  
10.  TORREZ, P. P. Q. **Estudo clínico-epidemiológico, laboratorial e de vulnerabilidade dos acidentes escorpiônicos atendidos no Hospital Municipal de Santarém – Pará** . Tese (Doutorado) – Programa de Doenças Infecciosas e Parasitárias, Faculdade de Medicina da Universidade de São Paulo, São Paulo, 2016. Disponível em: https://repositorio.usp.br/item/002777190. Acesso em: Acesso em: 24 nov. 2025.  
11. GOMES, J. V. _et al._ Clinical profile of confirmed scorpion stings in a referral center in Manaus, Western Brazilian Amazon. **Toxicon** , v. 187, p. 245–254, 1 nov. 2020. DOI: https://doi.org/10.1016/j.toxicon.2020.09.012. Disponível em: https://pubmed.ncbi.nlm.nih.gov/32991937/. Acesso em: 24 nov. 2025.  
12.  CARDOSO, F. J. T. **Escorpionismo na Amazônia: a epidemiologia, a clínica e a vulnerabilidade aos acidentes escorpiônicos em Rurópolis, Pará, Brasil** . Tese (Doutorado) – Universidade de São Paulo, São Paulo, 2019. Disponível em: https://repositorio.usp.br/item/003021777. Acesso em: 24 nov. 2025.  
13. FREIRE-MAIA, L.; CAMPOS, J. A.; AMARAL, C. F. S. Approaches to the treatment of scorpion envenoming. **Toxicon** , v. 32, n. 9, p. 1009-1014, 1994. DOI: https://doi.org/10.1016/0041-0101(94)90382-4. Disponível em: https://pubmed.ncbi.nlm.nih.gov/7801334/. Acesso em: 24 nov. 2025.  
14. BUCARETCHI, F. _et al._ Clinical consequences of Tityus bahiensis and Tityus serrulatus scorpion stings in the region of Campinas, southeastern Brazil. **Toxicon** , v. 89, p. 17-25, 2014. DOI: https://doi.org/10.1016/j.toxicon.2014.06.022. Disponível em: https://pubmed.ncbi.nlm.nih.gov/25011046/. Acesso em: 24 nov. 2025.  
15. BORGES, A. _et al._ Amazonian scorpions and scorpionism: integrating toxinological, clinical, and phylogenetic data to combat a human health crisis in the world’s most diverse rainforest. **Journal of Venomous Animals and Toxins Including Tropical Diseases** , v. 27, 2021. DOI: https://doi.org/10.1590/1678-9199-JVATITD-2021-0028. Acesso em: 24 nov. 2025.  
16.  BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. **Ofício Circular n.º 4/2016 – CGDT/Devit/SVS/MS** . Encaminha a Nota informativa n.º 25, de 2016- GDT/DEVIT/SVS/MS. Brasília, DF: MS, 2016. Disponível em: https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/a/ animaispeconhentos/acidentesofidicos/publicacoes/oficiocircularno042016 cgdt-devit-svs-ms/view. Acesso em: 24 nov. 2025.  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
26  
17.  KHATTABI, A. _et al._ Classification of clinical consequences of scorpion stings: consensus development. **Transactions of the Royal Society of Tropical Medicine and Hygiene** , v. 105, n. 7, p. 364–369, 2011. DOI: https://doi.org/10.1016/j. trstmh.2011.03.007. Disponível em: https://pubmed.ncbi.nlm.nih.gov/21601228/. Acesso em: 24 nov. 2025.  
18. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Articulação Estratégica de Vigilância em Saúde. **Guia de Vigilância em Saúde** . 1. ed. atual. Brasília, DF: MS, 2017. 3. v.  
19. OLIVEIRA, S. M. S. DE. **Escorpionismo no interior da Amazônia** : geoespacialização e aspectos clínico-epidemiológicos. 2018. Tese (Doutorado) – Escola de Enfermagem da Universidade de São Paulo, Universidade de São Paulo, São Paulo, 2018. DOI: https://doi.org/10.11606/T.7.2020.tde-16122019-134938. Disponível em: https://www.teses.usp.br/teses/disponiveis/7/7143/tde-16122019-134938/pt-br.php. Acesso em: 24 nov. 2025.  
20.  TOMASSONE, R.; VAINSTUB, V.; PEIRANO, S. Envenenamiento grave por escorpión en Pediatría. **Arch.argent.pediatr** , v. 101, n. 5, 2003. Disponível em: https://www.sap.org.ar/docs/publicaciones/archivosarg/2003/392-397.pdf. Acesso em: 24 nov. 2025.  
21. MONTEIRO, W. M. _et al._ Perspectives and recommendations towards evidence-based health care for scorpion sting envenoming in the Brazilian Amazon: A comprehensive review. **Toxicon** , v. 169, p. 68-80, 2019. DOI: https://doi.org/10.1016/j. toxicon.2019.09.003. Disponível em: https://pubmed.ncbi.nlm.nih.gov/31494205/. Acesso em: 24 nov. 2025.  
22. BORGES, A. _et al._ Venom diversity in the Neotropical scorpion genus Tityus: Implications for antivenom design emerging from molecular and immunochemical analyses across endemic areas of scorpionism. **Acta Tropica** , v. 204, 2020. DOI: https://doi.org/10.1016/j.actatropica.2020.105346. Disponível em: https://pubmed.ncbi.nlm.nih.gov/31982434/. Acesso em: 24 nov. 2025.  
23.  PROTOCOLO Clínico: Escorpionismo no Estado de São Paulo. No prelo.  
24. BORGES, R. F. **Manifestações neuromusculares no escorpionismo em Ruropolis (Pará)** . 2023. Dissertação (Mestrado) – Escola de Enfermagem da Universidade de São Paulo, Universidade de São Paulo, São Paulo, 2023. Disponível em: https://www.teses.usp.br/teses/disponiveis/7/7144/tde-02042025-164507/ publico/DissertacaoManifestacoesNeuromusculares_Escorpionismo_Ruropolis.pdf. Acesso em: 24 nov. 2025.  
25. SANTOS, M. S. V. _et al_ . Clinical and Epidemiological Aspects of Scorpionism in the World: A Systematic Review. **Wilderness and Environmental Medicine** , v. 27, n. 4, p. 504-518, 2016. DOI: https://doi.org/10.1016/j.wem.2016.08.003. Disponível em: https://pubmed.ncbi.nlm.nih.gov/27912864/. Acesso em: 24 nov. 2025.  
26.  REZENDE, N. A. DE; CHAVÉZ-OLORTEGUI, C.; AMARAL, C. F. Is the severity of Tityus serrulatus scorpion envenoming related to plasma venom concentrations? **Toxicon** , v. 34, n. 7, p. 820-823, 1996. DOI: https://doi.org/10.1016/0041-0101(96)00022-0. Disponível em: https://pubmed.ncbi.nlm.nih.gov/8843582/. Acesso em: 24 nov. 2025.  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
27  
27.  LIRA, A. F. A. _et al._ Threat level influences the use of venom in a scorpion species, Tityus stigmurus (Scorpiones, Buthidae). **Acta ethologica** , v. 20, p. 291-295, 2017. DOI: https://doi.org/10.1007/s10211-017-0274-3. Disponível em: https://www.researchgate.net/publication/318881744_Threat_level_influences_ the_use_of_venom_in_a_scorpion_species_Tityus_stigmurus_Scorpiones_Buthidae. Acesso em: 24 nov. 2025.  
28. AMARAL, C. F. S.; DE REZENDE, N. A.; FREIRE-MAIA, L. Acute pulmonary edema after Tityus serrulatus scorpion sting in children. **American Journal of Cardiology** , v. 71, n. 2, p. 14–17, 1993. DOI: https://doi.org/10.1016/0002-9149(93)90746-y. Disponível em: https://pubmed.ncbi.nlm.nih.gov/8421991/. Acesso em: 24 nov. 2025.  
29.  AMARAL, C. F. S. _et al._ Electrocardiographic, enzymatic and echocardiographic evidence of myocardial damage after tityus serrulatus scorpion poisoning. **American Journal of Cardiology** , v. 67, n. 7, p. 655-657, 1991. DOI: https://doi.org/10.1016/00029149(91)90912-5. Disponível em: https://pubmed.ncbi.nlm.nih.gov/1705750/. Acesso em: 24 nov. 2025.  
30.  OLIVEIRA, S. M. S. DE _et al._ Electric shock sensation in the first reports of envenomations by Tityus strandi in the Brazilian Amazon. **Toxicon** , v. 178, n. January, p. 8-12, 2020. DOI: https://doi.org/10.1016/j.toxicon.2020.01.005. Disponível em: https://pubmed.ncbi.nlm.nih.gov/32094100/. Acesso em: 24 nov. 2025.  
31. REIS, M. B. _et al._ Interleukin-1 receptor-induced PGE2 production controls acetylcholine-mediated cardiac dysfunction and mortality during scorpion envenomation. **Nature communications** , v. 11, n. 1, p. 5433, 2020. DOI: https://doi.org/10.1038/s41467-020-19232-8. Disponível em: https://pubmed.ncbi.nlm.nih.gov/33116136/. Acesso em: 24 nov. 2025.  
32.  YAMASHITA, F. DE O. _et al._ Mangaba (Hancornia speciosa Gomes) fruit juice decreases acute pulmonary edema induced by Tityus serrulatus venom: Potential application for auxiliary treatment of scorpion stings. **Toxicon** , v. 179, p. 42-52, 2020. DOI: https://doi.org/10.1016/j.toxicon.2020.02.025. Disponível em: https://pubmed.ncbi.nlm.nih.gov/32174508/. Acesso em: 24 nov. 2025.  
33. MALAQUE, C. M. S. A. _et al._ The role of dexamethasone in scorpion venom-induced deregulation of sodium and water transport in rat lungs. **Intensive Care Medicine Experimental** , v. 3, p. 1-14, 2015. DOI: https://doi.org/10.1186/s40635-015-0063-0. Disponível em: https://pubmed.ncbi.nlm.nih.gov/26392398/. Acesso em: 24 nov. 2025.  
34. NASCIMENTO JR, E. B. _et al._ Pharmacological investigation of the nociceptive response and edema induced by venom of the scorpion Tityus serrulatus. **Toxicon** , v. 45, n. 5, p. 585-593, 2005. DOI: https://doi.org/10.1016/j.toxicon.2004.12.020. Disponível em: https://pubmed.ncbi.nlm.nih.gov/15777954/. Acesso em: 24 nov. 2025.  
35. LAMRAOUI, A.; ADI-BESSALEM, S.; LARABA-DJEBARI, F. Immunopathologic effects of scorpion venom on hepatorenal tissues: Involvement of lipid derived inflammatory mediators. **Experimental and molecular pathology** , v. 99, n. 2, p. 286-296, 2015. DOI: https://doi.org/10.1016/j.yexmp.2015.07.013. Disponível em: https://pubmed.ncbi.nlm.nih.gov/26231296/. Acesso em: 24 nov. 2025.  
36. NOVARTIS. **Dizeres de texto de bula – profissional da saúde** : Zofran® (cloridrato de ondansetrona). São Paulo: Novartis, 2021.  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
28  
37.  SANOFI. **Dizeres de texto de bula – profissional da saúde** : Plasil® (cloridrato de metoclopramida). Suzano: Sanofi, 2024.  
38. PARDAL, P. P. O. _et al._ Clinical aspects of envenomation caused by Tityus obscurus (Gervais, 1843) in two distinct regions of Pará state, Brazilian Amazon basin: A prospective case series. **Journal of Venomous Animals and Toxins Including Tropical Diseases** , v. 20, n. 1, p. 1-7, 2014. DOI: https://doi.org/10.1186/1678-9199-20-3. Disponível em: https://www.scielo.br/j/jvatitd/a/F7vkvb46pcTv5JTZycvQFHt/. Acesso em: 24 nov. 2025.  
39.  BUCARETCHI, F. _et al._ A comparative study of severe scorpion envenomation in children caused by Tityus bahiensis and Tityus serrulatus. **Revista do Instituto de Medicina Tropical de São Paulo** , v. 37, p. 331-336, 1995. DOI: https://doi.org/10.1590/S0036-46651995000400008. Disponível em: https://www.scielo.br/j/rimtsp/a/MfWwGXbKND3vzqrZdmQVMrd. Acesso em: 24 nov. 2025.  
40.  GORDILLO, M. E.; BUGLIOLO, A. G.; DELLONI, A. Escorpionismo en pediatria. **Archivos Argentinos de Pediatria** , v. 98, n. 5, p. 296-303, 2000. Disponível em: https://www.sap.org.ar/docs/publicaciones/archivosarg/2000/296.pdf. Acesso em: 24 nov. 2025.  
41. ROSTAGNO, G.; SAENZ, S. Escorpionismo en pacientes pediátricos internados en terapia intensiva. Serie de casos. **Archivos Argentinos de Pediatria** , v. 117, n. 4, p. 7-10, 2019.  
42. CUPO, P. _et al._ Acute left ventricular dysfunction of severe scorpion envenomation is related to myocardial perfusion disturbance. **International Journal of Cardiology** , v. 116, n. 1, p. 98-106, 2 mar. 2007. DOI: https://doi.org/10.1016/j.ijcard.2006.02.015. Disponível em: https://pubmed.ncbi.nlm.nih.gov/16828898/. Acesso em: 24 nov. 2025.  
43. CUPO, P.; HERING, S. E. Cardiac troponin I release after severe scorpion envenoming by Tityus serrulatus. **Toxicon** , v. 40, n. 6, p. 823-830, 2002. DOI: https://doi.org/10.1016/s0041-0101(02)00080-6. Disponível em: https://pubmed.ncbi.nlm.nih.gov/12175620/. Acesso em: 24 nov. 2025.  
44. LAVONAS, E. J. _et al._ 2023 American Heart Association focused update on the management of patients with cardiac arrest or life-threatening toxicity due to poisoning: an update to the American Heart Association Guidelines for Cardiopulmonary Resuscitation and Emergency Cardiovascular Care. **Circulation** , v. 148, n. 16, p. e149-e184, 2023. DOI: https://doi.org/10.1161/cir.0000000000001161. Disponível em: https://pubmed.ncbi.nlm.nih.gov/37721023/. Acesso em: 24 nov. 2025.  
45.  MARTINS, J. G. _et al._ On the noxious black Amazonian scorpion, Tityus obscurus (Scorpiones, Buthidae): Taxonomic notes, biology, medical importance and envenoming treatment. **Toxicon** , v. 228, 2023. DOI: https://doi.org/10.1016/j. toxicon.2023.107125. Disponível em: https://pubmed.ncbi.nlm.nih.gov/37054995/. Acesso em: 24 nov. 2025.  
46. MIRANDA, A. L. S. de _et al._ History, challenges and perspectives on Loxosceles (brown spiders) antivenom production in Brazil. **Toxicon** , v. 192, p. 40-45, 2021. DOI: https://doi.org/10.1016/j.toxicon.2021.01.004. Disponível em: https://pubmed.ncbi.nlm.nih.gov/33465358/. Acesso em: 24 nov. 2025.  
47.  INSTITUTO BUTANTAN. **Dizeres de texto de bula – Profissional da saúde** : soro antiescorpiônico. São Paulo: Instituto Butantan, 2022.  
Protocolo Clínico e Diretrizes Terapêuticas dos acidentes escorpiônicos  
29  
48.  INSTITUTO BUTANTAN. **Dizeres de texto de Bula – Profissional da Saúde** : soro antiaracdínico. São Paulo: Instituto Butantan, 2021.  
49. SANTANA, C. R.; OLIVEIRA, M. G. Evaluation of the use of antivenom sera in the emergency service of a regional public hospital in vitória da conquista (BA), Brazil. **Ciência e Saúde Coletiva** , v. 25, n. 3, p. 869-878, mar. 2020. DOI: https://doi.org/10.1590/1413-81232020253.16362018. Disponível em: https://www.scielo.br/j/csc/a/CnqHC9fbBMxkZxzfSP36kmr/. Acesso em: 24 nov. 2025.  
50.  SACHETT, J. G. de A.; WEN, F. H.; MONTEIRO, W. M. **Guia para o tratamento dos acidentes ofídicos** . Manaus: Ed. do autor, 2022. Disponível em: https://www.saude. ms.gov.br/wp-content/uploads/2024/06/SAVING_PROTOCOLO_PT-BR_COMPLETO1-JUNHO-2022-I.pdf. Acesso em: 24 nov. 2025.  
51. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. **Manual de rede de frio do Programa Nacional de Imunizações** . 5. ed. Brasília, DF: MS, 2017. Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/manual_rede_frio_programa_ imunizacoes_5ed.pdf. Acesso em: 24 nov. 2025.  
52. TORREZ, P. P. Q. _et al._ Acute cerebellar dysfunction with neuromuscular manifestations after scorpionism presumably caused by Tityus obscurus in Santarém, Pará/Brazil. **Toxicon** , v. 96, p. 68-73, 2015. DOI: https://doi.org/10.1016/j.toxicon.2014.12.012. Disponível em: https://pubmed.ncbi.nlm.nih.gov/25549940/. Acesso em: 24 nov. 2025.  
53.  ALMEIDA, J. S. _et al._ Use of point-of-care ultrasound to assess the severity of scorpion stings in hospitalized patients. **Clinical Toxicology** , v. 62, n. 3, p. 145-151, 2024. DOI: https://doi.org/10.1080/15563650.2024.2328346. Disponível em; https://pubmed.ncbi.nlm.nih.gov/38563526/. Acesso em: 24 nov. 2025.  
Conte-nos o que pensa sobre esta publicação. **CLIQUE AQUI e responda a pesquisa.**  
Secretaria de Vigilância em Saúde e Ambiente | Ministério da Saúde  
30  
Biblioteca Virtual em Saúde do Ministério da Saúde bvsms.saude.gov.br  
Comissão Nacional de Incorporaçãode Tecnologias no Sistema Único de Saúde

---

