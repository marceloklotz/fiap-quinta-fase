<!-- METADADOS: doenca: PCDT - Osteoporose | secao: PORTARIA CONJUNTA SAES/SECTICS Nº 22, DE 22 DE OUTUBRO DE 2025. -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 04 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Osteoporose no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 1009/2025 e o Relatório de Recomendação nº 1012 de junho de 2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Osteoporose.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da Osteoporose, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Osteoporose.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SECTICS nº 19, de 28 de setembro de 2023, publicada no Diário Oficial da União nº 201, de 23 de outubro de 2023, seção 1, pág. 105.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: MOZART JULIO TABOSA SALES -->
FERNANDA DE NEGRI

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **1. INTRODUÇÃO** -->
A osteoporose é uma doença metabólica caracterizada pela diminuição da massa óssea e pela deterioração da sua microarquitetura, com consequente aumento da fragilidade óssea e da susceptibilidade a fraturas<sup>1</sup> . Estima-se que aproximadamente 50% das mulheres e 20% dos homens com idade igual ou superior a 50 anos sofrerão uma fratura osteoporótica ao longo da vida<sup>22</sup> . Além das fraturas, as complicações clínicas da osteoporose incluem dor crônica, deformidade, redução da mobilidade, piora da qualidade de vida e aumento da mortalidade. A fratura de quadril é considerada a mais grave, com aumento da taxa de mortalidade em 12% a 20% nos dois anos seguintes à fratura<sup>2</sup> . Além da fratura de quadril, fraturas vertebrais e não vertebrais também podem ocorrer e trazer limitações físicas, interferindo na qualidade de vida do paciente<sup>3</sup> .  
A presença de determinadas condições nas primeiras décadas de vida, capazes de interferir na saúde óssea pode determinar o risco de osteoporose de um indivíduo. Durante o crescimento e desenvolvimento, o esqueleto passa por um processo complexo de formação e reabsorção óssea, que inicia na vida fetal e continua até a fusão epifisária ao final da segunda década de vida, determinando a forma adulta dos ossos. A massa óssea é adquirida lentamente durante a infância, seguida por uma aceleração significativa nos primeiros anos de puberdade. O pico de aquisição de massa óssea usualmente ocorre aos 12 anos em meninas e aos 14 anos em meninos, logo após o pico de crescimento. Nos anos seguintes, até o final da adolescência, cerca de 95% da massa óssea adulta estará formada. Estima-se que aproximadamente 60% a 80% da massa óssea seja determinada geneticamente, enquanto fatores ambientais e hormônios sexuais modulam os 20% restantes. Entre os fatores ambientais que podem afetar o pico de massa óssea estão ingestão de cálcio, níveis de vitamina D, prática de atividade física, medicamentos e comorbidades. A otimização do pico de massa óssea, com condições ambientais favoráveis, pode prevenir ou retardar o desenvolvimento de osteoporose nos anos seguintes<sup>4</sup> .  
Devido à prevalência elevada, a osteoporose representa um sério problema de saúde pública. Estima-se que afete mais de 200 milhões de pessoas no mundo e, aproximadamente, 30% das mulheres nos Estados Unidos e na Europa<sup>5</sup> . No Brasil, dados epidemiológicos do estudo BRAZOS ( _Brazilian Osteoporosis Study_ ), que incluiu 2.420 indivíduos acima de 40 anos oriundos de várias regiões do país, mostraram que fraturas de baixo impacto foram identificadas em 15,1% das mulheres e 12,8% dos homens avaliados, sendo os principais sítios de fratura o antebraço distal (30%), quadril (12%), úmero (8%), costelas (6%) e coluna (4%). Não foram observadas diferenças significativas em relação ao gênero e à classe social, mas houve maior incidência de fraturas nas mulheres das regiões metropolitanas quando comparada às da área rural. A maioria dos pacientes com fratura osteoporótica prévia desconhecia a condição de fragilidade óssea associada ao diagnóstico de osteoporose<sup>6</sup> . Estudo conduzido em São Paulo, em indivíduos com mais de 65 anos, mostrou a incidência de fraturas vertebrais morfométricas em 17,1% das mulheres e 13,2% dos homens, das quais 7,6% e 5,4% eram moderadas a graves, respectivamente<sup>7</sup> . Nessa população, foi observada a associação entre fraturas vertebrais e piores escores de qualidade de vida, particularmente no domínio de desempenho físico<sup>8</sup> . Em uma cidade do sul do Brasil, uma análise de todas as internações por fratura de quadril entre 2010 e 2012 verificou uma incidência anual de 268 casos/100.000 mulheres e 153 casos/100.000 homens, com taxa de mortalidade hospitalar de 7,5%, chegando a 25% após 12 meses seguintes ao evento<sup>9</sup> .  
A osteoporose pode ser classificada em primária ou secundária, conforme sua etiologia. A forma primária, mais comum, é diagnosticada na ausência de doenças ou outras condições associadas à fragilidade óssea. Nesses casos, a perda de massa óssea está relacionada ao processo de envelhecimento ou pós-menopausa. A osteoporose secundária deve ser  
considerada na presença de uma condição sabidamente associada à fragilidade óssea e corresponde a aproximadamente 30% dos casos em mulheres na pós-menopausa, 40% a 50% em mulheres na pré-menopausa e 50 a 55% em homens com diagnóstico de osteoporose<sup>10,11</sup> .  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da osteoporose. A identificação de fatores de risco e da doença em estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- M80.0 Osteoporose pós-menopáusica com fratura patológica  
- M80.1 Osteoporose pós ooforectomia com fratura patológica  
- M80.2 Osteoporose de desuso com fratura patológica  
- M80.3 Osteoporose por má absorção pós cirúrgica com fratura patológica  
- M80.4 Osteoporose induzida por drogas com fratura patológica  
- M80.5 Osteoporose idiopática com fratura patológica  
- M80.8 Outras osteoporoses com fratura patológica  
- M81.0 Osteoporose pós-menopáusica  
- M81.1 Osteoporose pós ooforectomia  
- M81.2 Osteoporose de desuso  
- M81.3 Osteoporose devido à má absorção pós cirúrgica  
- M81.4 Osteoporose induzida por drogas  
- M81.5 Osteoporose idiopática  
- M81.6 Osteoporose localizada  
- M81.8 Outras osteoporoses  
- M82.0 Osteoporose na mielomatose múltipla  
- M82.1 Osteoporose em distúrbios endócrinos  
- M82.8 Osteoporose em outras doenças classificadas em outra parte  
- M85.8 Outros transtornos especificados da densidade e da estrutura óssea

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **3.1. Diagnóstico clínico e densitométrico** -->
A definição clínica de osteoporose baseia-se tanto na evidência de fratura por fragilidade, independentemente da massa óssea, como na avaliação da densidade mineral óssea (DMO), por meio de densitometria óssea (g/cm<sup>2</sup> ) da coluna lombar, fêmur total, colo do fêmur ou terço médio do rádio<sup>14</sup> .  
A realização de rastreamento populacional amplo e aleatório com densitometria óssea não é preconizada pelo custo relativamente elevado<sup>15</sup> . No entanto, o rastreamento para avaliar a DMO está indicado para todas as mulheres com idade ≥ 65 anos e homens ≥ 70 anos ou na presença de fatores de risco para osteoporose, como baixo peso, fratura prévia, uso de medicamentos ou presença de doenças que sabidamente afetam a saúde óssea<sup>16</sup> .  
Sendo assim, o número de desvios-padrão abaixo do normal em comparação ao adulto jovem, conhecido como T- escore, é usado para definir a doença em mulheres e homens, geralmente, na pós-menopausa e acima dos 50 anos de idade,  
respectivamente. Embora a redução da massa óssea esteja associada a um maior risco de fratura, o T-escore, obtido pela densitometria óssea, indica um risco relativo e não um risco absoluto para fraturas. A maior parte das fraturas ocorre em pacientes com osteopenia, já que a distribuição gaussiana da massa óssea na população concentra o maior número de indivíduos no intervalo entre -1,0 e -2,5 desvios padrão (DP) em relação ao T-escore<sup>17</sup> .  
A osteoporose refere-se a uma condição em que há:  
- o T-escore menor ou igual a -2,5 DP em homens acima dos 50 anos e mulheres na pós menopausa na coluna lombar  
- (ântero-posterior), colo femoral, quadril total ou 1/3 do rádio, mesmo na ausência de uma fratura prevalente ou;  
- presença de fratura osteoporótica (também chamada de fratura de fragilidade), ou seja, uma fratura decorrente de  
- trauma mínimo, insuficiente para fraturar um osso normal, independentemente do T-escore ou;  
- o T-escore entre -1 e -2,49 associado a um aumento de risco de fratura avaliado pela ferramenta FRAX<sup>®</sup> ( _Fracture_  
- _Risk Assessment Tool_ )<sup>10, 14</sup> .  
Em situações em que não há disponibilidade de densitometria óssea, a presença de fraturas osteoporóticas e o uso da ferramenta FRAX<sup>®</sup> , mesmo na ausência de dados densitométricos, poderão estratificar o risco do paciente e direcionar o tratamento, conforme critérios de inclusão deste Protocolo.  
É considerada osteoporose **grave** quando o paciente com T-escore menor ou igual a – 2,5 DP associado a uma ou mais fraturas por fragilidade.  
Estratégias que considerem fatores clínicos de risco podem adicionar informações sobre o risco individual de fratura, independentemente das medidas da DMO. A ferramenta FRAX<sup>®</sup> é o primeiro modelo de predição de fraturas específico, com calibração para cada país onde a epidemiologia das fraturas de quadril e mortalidade tenha sido publicada. Consiste em um algoritmo _online_ que calcula a probabilidade de ocorrer, em 10 anos, uma fratura osteoporótica maior (fratura clínica vertebral, úmero, punho ou quadril) ou uma fratura de quadril isolada, em homens e mulheres entre 40 e 90 anos após análise individual. A probabilidade é calculada a partir de dados clínicos do paciente como idade, sexo e índice de massa corporal, além de fatores de risco como história de fratura por fragilidade óssea, história parental de fratura de quadril, tabagismo atual ou prévio, uso prolongado de glicocorticoides, artrite reumatoide, alto consumo de álcool ou outras causas de osteoporose secundária (diabetes melito tipo 1, menopausa precoce – antes dos 40 anos). A DMO do colo femoral pode ser opcionalmente inserida para melhorar a predição do risco de fratura.  
A partir das variáveis clínicas inseridas, é calculado um limiar de intervenção fixado como “limiar de fratura” e apresentado na ferramenta, baseado na probabilidade de fratura por idade específica equivalente a mulheres com fratura de fragilidade prévia (Figura 1)<sup>18–20</sup> . Esse instrumento foi validado para uso na população brasileira, é reconhecido pela Organização Mundial da Saúde (OMS) e é disponibilizado pela Associação Brasileira de Avaliação Óssea e Osteometabolismo (ABRASSO)<sup>21</sup> , no endereço eletrônico: <u>https://abrasso.org.br/frax-brasil/. O FRAX</u><sup>®</sup> auxilia na identificação dos pacientes em risco de fratura e, baseado nos critérios do _National Osteoporosis Guideline Group_ (NOGG), auxilia na indicação de tratamento. Essa abordagem de avaliação mostrou-se custo-efetiva em determinados cenários, sendo incorporada nas indicações de tratamento medicamentoso para pacientes com osteoporose em uma variedade de diretrizes clínicas<sup>2,10,18,22</sup> .  
**Figura 1** . Limite de intervenção FRAX.  
<!-- Start of picture text -->
30<br>gers 25 Limitede intervencéo<br>g<br>& 20<br>S<br>5 15<br>3x<br>3 10<br>°<br>& 5<br>940 50 60 70 80 90<br>Idade anos<br><!-- End of picture text -->  
Além disso, o risco de fraturas também pode ser estratificado em uma das categorias do **Quadro 1** .  
**Quadro 1.** Categorias de estratificação de risco de fratura  
|**Risco**|**Fatores**|
|---|---|
|Baixo a|Todos os fatores:|
|Moderado|-<br>Paciente sem diagnóstico de osteoporose (T-escore maior que -2,5 DP), baixo risco de fratura no<br>FRAX<sup>®</sup> **e**sem fraturas prévias.|
|Alto|Qualquer um dos fatores:<br>-<br>T-escore igual ou inferior a -2,5 DP;**ou**<br>-<br>T-escore entre -1,0 e -2,49 DP**e**alto risco de fratura no FRAX<sup>®</sup>;**ou**<br>-<br>Fratura prévia.|
|Muito alto|Um ou mais dos seguintes fatores:<br>-<br>Fratura nos últimos 12 meses;**ou**<br>-<br>Múltiplas fraturas**ou**<br>-<br>Fraturas durante o tratamento;**ou**|
||-<br>Fraturas em uso de medicamento que altera o metabolismo ósseo;**ou**<br>-<br>T-escore inferior a -3,0 DP;**ou**<br>-<br>Muito alto risco de fratura no FRAX<sup>®</sup>;**ou**<br>-<br>Risco de queda aumentado.|  
Legenda: DP – desvio padrão.  
Fonte: Kanis, 2020<sup>23</sup> ; Schoback, 2020<sup>24</sup> ; Eastell, 2019<sup>25</sup> e Camacho, 2020<sup>10</sup> .  
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, racismo, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **3.2. Diagnóstico laboratorial** -->
Para o diagnóstico de causas secundárias de osteoporose ou monitoramento do tratamento, deve-se utilizar exames laboratoriais, tais como hemograma, velocidade de hemossedimentação (VHS), dosagens séricas de cálcio, fósforo, albumina, creatinina, fosfatase alcalina, PTH, TSH, T4 livre, 25-hidroxivitamina D (25OHD) e dosagem de cálcio na urina de 24 horas<sup>10</sup> . Podem ser necessários outros exames complementares para diagnosticar causas secundárias de osteoporose, de acordo com o quadro clínico e a história do paciente.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **3.3. Diagnóstico por imagem** -->
Exames radiológicos, em especial radiografias da coluna vertebral dorsal e lombar em anteroposterior (AP) e perfil, são indicados para diagnóstico de fraturas vertebrais, sintomáticas ou não, que aumentam em muito o risco de novas fraturas osteoporóticas, além de ajudar no diagnóstico diferencial com outras doenças ósseas. Podem ser solicitados nos casos de pacientes com diagnóstico densitométrico ou clínico de osteoporose, no início do tratamento e sempre que sintomas sugestivos de fraturas vertebrais (dor aguda intensa ou crônica persistente e perda de altura maior que 4 cm) estiverem presentes<sup>23</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo indivíduos com suspeita de osteoporose ou osteoporose confirmada que apresentarem pelo menos um dos critérios a seguir<sup>26,27</sup> :  
- Fraturas maiores (i.e., fêmur proximal, rádio distal, úmero proximal ou coluna vertebral) ou fraturas de quadril, por baixo impacto (decorrentes de queda da própria altura ou menos) e comprovadas radiologicamente, sem necessidade de densitometria;  
- Exame densitométrico com T-escore menor ou igual a -2,5 no fêmur proximal (colo ou fêmur total), coluna lombar  
- ou terço distal do rádio;  
- Baixa massa óssea (T-escore menor ou igual a -1,0 e maior ou igual a -2,49) em pacientes frágeis, com risco de queda aumentada, independentemente da idade ou em pacientes com probabilidade de fratura pelo FRAX®, acima do limiar de intervenção.  
<u>Adicionalmente, para o uso dos seguintes medicamentos, os pacientes devem apresentar os seguintes critérios:</u>  
Para uso de **ácido zoledrônico** , os pacientes deverão ainda apresentar intolerância ou dificuldades de deglutição dos bisfosfonatos orais decorrentes de anormalidades do esôfago que retardam o esvaziamento esofágico, tais como estenose ou acalasia, doença do refluxo gastroesofágico importante, ou situações clínicas que comprometem de forma significativa a absorção de bisfosfonatos orais.  
Para o uso de **calcitonina** , o paciente deve apresentar osteonecrose de mandíbula ou fratura atípica de fêmur ou contraindicação absoluta aos outros medicamentos.  
Para o uso de **raloxifeno** , a paciente deve ser mulher, estar na pós menopausa, ter baixo risco de tromboembolismo venoso, não estar em uso concomitante de estrógenos e apresentar um dos critérios abaixo:  
- Alto risco de câncer de mama; **ou**  
- Osteonecrose de mandíbula ou fratura atípica de fêmur; **ou**  
- Intolerância ou contraindicação aos bisfosfonatos.  
Para o uso de **estrógenos conjugados** , a paciente deve ser mulher, estar no climatério, apresentar comprometimento da qualidade de vida pelos sintomas vasomotores e não estar em uso concomitante de raloxifeno.  
Para o uso de **romosozumabe** , as pacientes devem ser mulheres na pós-menopausa **e** apresentar osteoporose grave **e** falha terapêutica, definida por:  
- Presença de duas ou mais fraturas incidentes por fragilidade em vigência de tratamento para osteoporose; ou  
- Presença de uma fratura incidente após tempo mínimo de tratamento de 1 ano com agente preconizado neste protocolo **e** perda significativa de densidade mineral óssea (redução de mais de 5% em qualquer sítio no intervalo avaliado), considerando boa adesão ao tratamento e ausência de causas secundárias de perda de massa óssea.  
Nota: Considera-se pacientes frágeis aqueles que apresentam pelo menos um dos seguintes critérios: idade igual ou maior que 75 anos, vive em instituições de longa permanência para idosos (ILPI), encontra-se acamado, esteve hospitalizado recentemente por qualquer razão, apresente doenças sabidamente causadoras de incapacidade funcional – acidente vascular encefálico, síndromes demenciais e outras doenças neurodegenerativas, etilismo, neoplasia terminal, amputações de membros –, encontra-se com  pelo menos uma incapacidade funcional básica, ou viva situações de violência doméstica. Considera-se paciente com alto risco de queda aquele que se enquadra em um dos seguintes critérios: paciente independente, que se locomove e realiza suas atividades sem ajuda de terceiros, mas possui pelo menos um fator de risco; paciente dependente de ajuda de terceiros para realizar suas atividades, com ou sem a presença de algum fator de risco, que anda com auxílio (de pessoa ou de dispositivo) ou se locomove em cadeira de rodas; ou paciente acomodado em maca, por exemplo, aguardando a realização de exames, procedimentos ou transferência, com ou sem a presença de fatores risco.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos os pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso dos respectivos medicamentos ou procedimentos preconizados neste Protocolo.  
Este Protocolo não preconiza o tratamento medicamentoso de pacientes com doença renal crônica (DRC) estágios 4 e 5, uma vez que os medicamentos aqui citados podem ser contraindicados para essa população. Para estes pacientes, o tratamento não medicamentoso e controle adequado da DRC devem ser considerados.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **6. CASOS ESPECIAIS** -->
Em indivíduos adultos com plano de início e manutenção de tratamento com glicocorticoides em dose diária superior a 5 mg de prednisona ou equivalente, por período igual ou superior a 3 meses, há indicação de tratamento medicamentoso na presença de fratura osteoporótica prévia, T-escore menor ou igual a -2,0 DP na coluna ou quadril ou probabilidade de fratura pelo FRAX<sup>®</sup> acima do limiar de intervenção<sup>28,29</sup> .  
Em homens com história de carcinoma de próstata e plano de início e manutenção de terapia de privação androgênica com agonistas ou antagonistas de GnRH ou com terapia antiandrogênica, há indicação de tratamento medicamentoso na presença de fratura osteoporótica prévia, T-escore menor ou igual a −2,0 DP na coluna ou quadril ou probabilidade de fratura pelo FRAX<sup>®</sup> acima do limiar de intervenção<sup>30,31</sup> .  
Em indivíduos com história de carcinoma de mama com plano de início e manutenção de tratamento com inibidores de aromatase, há indicação de tratamento medicamentoso na presença de T-escore menor ou igual a −2,0 DP na coluna ou quadril ou redução anual da DMO em 5% a 10% após início da terapia. Para pacientes com T-escore maior que -2,0 DP, o tratamento medicamentoso está indicado na presença de 2 ou mais fatores de risco: T-escore menor que -1,5 DP, idade maior  
que 65 anos, IMC menor que 20 kg/m², história familiar de fratura de quadril, história pessoal de fratura por fragilidade, tabagismo ou uso de glicocorticoides por período maior que 6 meses<sup>30,32</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7. TRATAMENTO** -->
Em pacientes com risco de desenvolver osteoporose, medidas preventivas devem ser adotadas. Já em pacientes com baixa DMO ou histórico de fraturas, o tratamento visa a diminuir o risco da primeira ou segunda fratura óssea e suas consequências de morbimortalidade. Sabe-se que, clinicamente, a fratura de quadril está associada à dor aguda e perda de função, frequentemente ocasionando a hospitalização do paciente. A recuperação é lenta e o processo de reabilitação incompleto, com 50% desses pacientes necessitando de institucionalização permanente<sup>33</sup> .  
As fraturas vertebrais podem causar dor aguda e perda de função, mas são, frequentemente, assintomáticas. Uma fratura vertebral aumenta exponencialmente o risco de novas fraturas e pode ocorrer a “cascata fraturária”. Quando recorrentes, as fraturas vertebrais podem interferir significativamente na qualidade de vida e este impacto aumenta com o número de fraturas. Já as fraturas de antebraço cursam com dor aguda, mas, usualmente, a recuperação funcional é completa<sup>3</sup> .  
O tratamento da osteoporose consiste em medidas não medicamentosas e medicamentosas. Ainda, as medidas não medicamentosas e suplementação de cálcio e colecalciferol (vitamina D) são preconizadas em todas as situações citadas<sup>25</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Exercício físico** -->
A atividade física contribui para a redução do risco de fratura porque a força biomecânica que os músculos exercem sobre os ossos é capaz de aumentar a DMO. Exercícios com ação da gravidade parecem desempenhar importante papel no aumento e na preservação da massa óssea. Além disso, a atividade física regular pode ajudar a prevenir quedas que ocorrem devido a alterações do equilíbrio e diminuição de força muscular e de resistência<sup>34</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Prevenção de quedas e reabilitação** -->
Tendo em vista a forte relação causal entre quedas e fraturas, medidas de prevenção devem ser adotadas. Além dos exercícios físicos, deve-se incluir a revisão do uso de medicamentos associados ao risco de quedas, avaliação de problemas neurológicos, correção de distúrbios visuais e auditivos, medidas de segurança ambiental, conforme protocolos de prevenção de quedas<sup>35</sup> . Preconiza-se que sejam adotadas as medidas previstas na Cartilha do Idoso do Ministério da Saúde e as orientações do Instituto Nacional de Traumatologia e Ortopedia<sup>36,37</sup> .  
Além disso, estratégias relacionadas à reabilitação podem incluir a proposição de grupos de orientação sobre prevenção de quedas, conservação de energia e proteção articular, adaptação na rotina e de utensílios para melhora da capacidade funcional, treino de atividade de vida diária com pacientes egressos de procedimentos cirúrgicos ortopédicos ou ambulatórios de reumatologia, com diminuição da massa óssea e prescrição de órteses para repouso ou auxílio na função manual.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Fumo e álcool** -->
O tabagismo deve ser desencorajado, bem como a ingestão excessiva de álcool, desde a fase de crescimento (adolescência) até a vida adulta.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2. Tratamento medicamentoso** -->
A maior parte dos estudos que demonstraram eficácia do tratamento medicamentoso na prevenção de fraturas foi realizada em populações de pacientes com osteoporose na pós-menopausa. Os medicamentos utilizados para tratamento de osteoporose incluem: o carbonato de cálcio e o colecalciferol (vitamina D), que usualmente fazem parte de todos os esquemas  
terapêuticos; os agentes antirreabsortivos (bisfosfonatos - alendronato, risedronato, pamidronato e ácido zoledrônico); o modulador seletivo dos receptores de estrogênio (raloxifeno); os estrógenos conjugados; a calcitonina e o agente antirreabsortivo e anabólico (romosozumabe).  
Preconiza-se a reposição de cálcio e colecalciferol (vitamina D) associada ao uso de um bisfosfonato (alendronato ou risedronato), como tratamento preferencial. Contudo, pacientes que não possam utilizar alendronato ou risedronato devido à intolerância gastrintestinal ou dificuldades de deglutição, devem utilizar um medicamento administrado por via endovenosa, como o ácido zoledrônico ou pamidronato.  
Considera-se falha terapêutica uma das seguintes situações:  
- quando o paciente apresenta duas ou mais fraturas osteoporóticas enquanto em uso dos medicamentos preconizados neste Protocolo por pelo menos um ano, com adequação das posologias de cálcio e vitamina D; ou  
- quando o paciente apresenta uma fratura incidente após tempo mínimo de tratamento de 1 ano com medicamento preconizado neste Protocolo e perda significativa de densidade mineral óssea (redução de mais de 5% em qualquer sítio no intervalo avaliado), considerando boa adesão ao tratamento e ausência de causas secundárias de perda de massa óssea.  
Não são considerados em falha ao tratamento aqueles pacientes que apresentaram perda de DMO ou que tenham apresentado fraturas logo após o início da terapia medicamentosa ou fraturas não osteoporóticas. Nestes casos, recomendase individualizar a conduta, avaliando a adesão ao tratamento, possíveis problemas de absorção de cálcio, uso de medicamentos que podem causar perda óssea e outras causas secundárias de osteoporose<sup>38–41</sup> .  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo<sup>42</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.1 Reposição de cálcio e vitamina D** -->
Embora vários nutrientes estejam envolvidos na formação e manutenção da massa óssea, o cálcio e o colecalciferol (vitamina D) são os mais importantes e fazem parte do tratamento padrão na prevenção de fraturas. A suplementação de cálcio deve ser garantida caso a ingestão mínima diária de alimentos lácteos não seja atingida. A ingestão de cálcio recomendada varia ao longo da vida, mas de maneira geral, recomenda-se que seja mantida entre 1.000 a 1.200 mg de cálcio elementar por dia. Em casos especiais, como na gravidez, lactação e síndromes disabsortivas intestinais, pode haver benefício com doses maiores, à critério clínico. Preocupações sobre a segurança da suplementação de cálcio quanto ao aumento do risco de eventos cardiovasculares, não foram confirmadas, exceto nos casos de excesso de suplementação, principalmente acima de 1.400 mg/dia. Assim, a dose deve ser inferior a 1.400 mg/dia de cálcio elementar e fracionada em doses de 500 mg de cálcio elementar.  
Em relação à vitamina D, recomenda-se a ingestão diária de, pelo menos, 800 a 1.000 UI de colecalciferol ou 7.000 UI por semana para todos os pacientes, exceto idosos a partir dos 60 anos, que podem necessitar até 2.000 UI por dia ou  
14.000 UI por semana. Eventualmente, pacientes com níveis séricos de 25-hidroxivitamina D abaixo de 20 ng/mL e idosos a partir dos 60 anos de idade, podem utilizar doses maiores, até que os níveis séricos se estabilizem acima de 30 ng/mL<sup>43,44</sup> .  
Alguns estudos mostraram que essa dose de vitamina D associada ao cálcio leva à redução das fraturas de quadril e das não vertebrais, especialmente na população com risco aumentado de quedas, como nos idosos institucionalizados com histórico ou risco de fraturas por fragilidade<sup>45</sup> .  
Já o calcitriol, análogo do colecalciferol, não repõe níveis de 25-hidroxivitamina D e só é preconizado para pacientes com insuficiência renal crônica com depuração de creatinina endógena (DCE) menor ou igual a 30 mL/min, com osteomalácia hipofosfatêmica ou por deficiência de 1-alfa-hidroxilase, com insuficiência hepática ou hipoparatireoidismo.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.2 Bisfosfonatos** -->
Os bisfosfonatos são a classe mais utilizada entre os medicamentos que reduzem fraturas osteoporóticas<sup>46,47</sup> , sendo os de uso oral a primeira escolha<sup>48</sup> . Embora não haja evidência de superioridade de um bisfosfonato em relação aos outros na prevenção de fraturas ou em termos de perfil de eventos adversos, a escolha de alendronato de sódio ou risedronato sódico baseia-se na maior experiência de seu uso e no menor custo. Os eventos adversos gastrointestinais mais frequentes como esofagite e gastrite são similares para todos os bisfosfonatos orais<sup>46,48</sup> . Fraturas atípicas do fêmur e necrose asséptica da mandíbula, apesar de raras, têm sido associadas a uso em longo prazo de bisfosfonatos<sup>49</sup> , portanto, após cinco anos de uso de bisfosfonatos orais pode haver uma pausa ou ‘férias' de 1 a 2 anos.  
Para evitar o risco de ulceração esofágica é importante que seja observada a orientação de evitar o decúbito por até 30 a 60 minutos, após a ingestão do medicamento. A comparação entre o uso diário ou semanal de bisfosfonato mostra maiores taxas de adesão e persistência de tratamento a favor do uso semanal<sup>50–52</sup> .  
No caso de bisfosfonatos de uso oral (alendronato e risedronato), as contraindicações ao seu uso incluem hipersensibilidade ao medicamento ou a qualquer componente da fórmula, hipocalcemia, gravidez e lactação e insuficiência renal grave (DCE abaixo de 30 mL/min), bem como inabilidade do paciente para sentar-se ou ficar em pé por pelo menos 30-60 minutos após a ingestão do medicamento<sup>53,54</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Alendronato de sódio** -->
O alendronato de sódio é efetivo na prevenção primária de fraturas em pacientes com osteoporose, havendo evidência de sua efetividade na redução de incidência de fraturas vertebrais, não vertebrais e de quadril<sup>53</sup> .  Não é necessário ajuste posológico para pacientes idosos ou para pacientes com insuficiência renal leve a moderada (depuração da creatinina plasmática de 35 a 60 mL/min). O alendronato de sódio não é recomendado para pacientes com insuficiência renal mais grave (depuração da creatinina plasmática menor que 35 mL/min) em razão da falta de experiência com o medicamento em tal condição<sup>55</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Risedronato sódico** -->
O risedronato sódico previne fraturas tanto em mulheres na pós-menopausa como em homens com osteoporose estabelecida, havendo evidência de sua efetividade na prevenção secundária de fraturas vertebrais, não vertebrais e de quadril 54. Em pacientes com perda de função renal pré-existente, essa função deve ser monitorada a cada 1 a 3 meses.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Ácido zoledrônico** -->
A terapia antirreabsortiva óssea com ácido zoledrônico intravenoso (IV) é indicada para pacientes de ambos os sexos com osteoporose densitométrica ou osteopenia e história de fratura por fragilidade ou alto risco de fratura, calculado pelo FRAX®. Devido à sua via de administração, deve ser utilizado por pacientes com intolerância ou dificuldades de deglutição dos bisfosfonatos orais, decorrentes de anormalidades do esôfago que retardem o esvaziamento esofágico, tais como estenose ou acalasia, ou situações clínicas que comprometem de forma significativa a absorção de bisfosfonatos orais.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Pamidronato** -->
O pamidronato é outro bisfosfonato de uso intravenoso e constitui uma alternativa de tratamento para pacientes com intolerância aos bisfosfonatos de administração oral. Há evidências, oriundas de estudos controlados não randomizados e de estudos retrospectivos, que o uso de pamidronato associado a cálcio e colecalciferol (vitamina D) aumenta a DMO e é bem tolerado no tratamento da osteoporose na pós-menopausa. Entretanto, devido à maior frequência de administrações, este Protocolo preconiza seu uso apenas em casos de indisponibilidade ou contraindicações ao ácido zoledrônico.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.3 Raloxifeno** -->
O raloxifeno é um modulador seletivo do receptor de estrógeno aprovado para prevenção e tratamento da osteoporose em mulheres após a menopausa e para a redução do risco de câncer de mama, em mulheres na pós-menopausa com osteoporose<sup>56</sup> . Apresenta evidência para prevenção de fraturas vertebrais, mas não para as de quadril ou não vertebrais<sup>57</sup> . Dessa forma, parece ser um tratamento menos efetivo do que os bisfosfonatos.  
Seu uso deve ser reservado para pacientes com baixo risco de eventos tromboembólicos, que não estão em uso concomitante de estrógenos e que tenham alto risco de câncer de mama, uma vez que ele pode diminuir este risco<sup>58</sup> . É uma opção para pacientes com histórico de osteonecrose de mandíbula ou fratura atípica de fêmur associadas ao uso de bisfosfonatos. O raloxifeno também é preconizado para mulheres com intolerância ou contraindicação aos bisfosfonatos com baixo risco de tromboembolismo venoso<sup>58</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.4 Estrógenos conjugados** -->
Os estrógenos conjugados constituem uma alternativa para prevenção de osteoporose para as pacientes no climatério e que apresentam comprometimento da qualidade de vida pelos sintomas vasomotores. Deve-se atentar para os riscos potenciais dos estrógenos conjugados, como acidente vascular encefálico, câncer de mama ou tromboembolismo venoso. Quando prescritos, a dose deve ser individualizada. Há evidência de que o uso de estrógenos reduz o risco de fraturas de quadril, vertebrais e não vertebrais<sup>56</sup> .  
Antes do início do tratamento, devem ser avaliados os antecedentes pessoais e familiares de neoplasias dependentes de estrogênios, além de realizar exames ginecológico e geral completos, considerando as contraindicações e advertências de uso. Mulheres não submetidas à histerectomia necessitam fazer uso de associação com progestágenos.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.5 Romosozumabe** -->
O romosozumabe é um anticorpo monoclonal humanizado (IgG2) que liga e inibe a esclerostina, estimulando a formação óssea em superfícies ósseas trabeculares e corticais, bem como a atividade osteoblástica, resultando em aumentos de massa óssea trabecular e cortical e em melhorias na massa, estrutura e força óssea.  
Antes do início do tratamento, os níveis séricos de cálcio devem ser avaliados e corrigidos, pois o medicamento é contraindicado em pacientes com hipocalcemia não corrigida. Eventos cardiovasculares como infarto do miocárdio (IM) e acidente vascular encefálico (AVE) devem ser considerados, apesar de, segundo o fabricante, não ter sido estabelecida relação causal entre romosozumabe e estes eventos e estudos recentes não terem confirmado a associação. O medicamento não deve ser iniciado em pacientes que sofreram IM ou AVE no ano anterior<sup>59–61</sup> .  
Em julho de 2024 foram revisadas as evidências científicas sobre eficácia, segurança e avaliação econômica entre os medicamentos romosozumabe e teriparatida. A recomendação foi favorável à ampliação de uso do romosozumabe para o tratamento de osteoporose grave e falha terapêutica e pela exclusão da teriparatida<sup>62,63</sup> .  
O tempo de uso de romosozumabe é de no máximo um ano. Após esse período, o paciente deve iniciar tratamento com bisfosfonato imediatamente, para preservar o ganho de massa óssea e prevenir fraturas, mesmo que tenha ocorrido ganho substancial em DMO ao longo do tratamento.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.6 Calcitonina** -->
Permanece como opção terapêutica somente nos seguintes casos: osteonecrose de mandíbula ou fratura atípica associadas ao uso de bisfosfonatos ou em pacientes com contraindicação absoluta aos outros fármacos. A calcitonina _solução nasal_ na dose de 400 UI/dia mostrou redução do risco de novas fraturas vertebrais, com mínimo aumento da DMO da coluna e sem redução significativa de fraturas não vertebrais e de quadril. Além disso, foi observada maior incidência de malignidade em pacientes tratados com calcitonina. Apesar de haver pouca plausibilidade biológica para esta associação e de limitações de segurança, como por exemplo o desenvolvimento de malignidades no uso de longo-prazo, preconiza-se evitar seu uso ou limitar o uso prolongado da calcitonina no tratamento de pacientes com osteoporose<sup>25,58,66,67</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.7 Medicamentos** -->
- Ácido zoledrônico: solução para infusão de 5 mg/100mL;  
- Alendronato de sódio: comprimidos de 10 e 70 mg;  
- Calcitonina: solução nasal com 200 UI/dose;  
- Calcitriol: cápsula de 0,25 mcg;  
- Carbonato de cálcio: comprimido de 1.250 mg (equivalente a 500 mg de cálcio elementar);  
- Carbonato de cálcio + colecalciferol: comprimidos de 1.250 mg (equivalente a 500 mg de cálcio elementar) + 200  
- UI ou 400 UI; comprimidos de 1.500 mg (equivalente a 600 mg de cálcio elementar) + 400 UI;  
- Fosfato de cálcio tribásico + colecalciferol: comprimidos de 1661,616 mg (equivalente a 600 mg de cálcio  
- elementar) + 400 UI;  
- Cloridrato de raloxifeno: comprimidos de 60 mg;  
- Estrogênios conjugados: comprimidos de 0,3 mg e 0,625 mg;  
- Pamidronato dissódico: pó para solução injetável de 60 mg;  
- Risedronato sódico: comprimidos de 35 mg;  
- Romosozumabe: solução injetável de 90 mg/mL.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.8 Esquemas de administração** -->
- Ácido zoledrônico: dose de 5 mg, por via intravenosa (IV), uma vez ao ano.  
- Alendronato de sódio: dose de 10 mg/dia ou 70 mg, uma vez por semana, por via oral (VO). Deve ser ingerido em jejum, pelo menos meia hora antes da primeira refeição e de outros medicamentos, com um copo de água (200 mL). Após a ingestão, o paciente deve ficar sentado ou de pé por pelo menos 30 a 60 minutos.  
- Calcitonina: dose de 400 UI/dia, por via intranasal.  
- Calcitriol: dose de 0,25 mcg, duas vezes ao dia, por VO.  
- Carbonato de cálcio: dose de 500 a 1.400 mg por dia de cálcio elementar por VO, divididas em administrações de,  
- no máximo, 500 mg de cálcio elementar por vez.  
- Fosfato de cálcio tribásico + colecalciferol: doses de 600 a 1200 mg por dia de cálcio elementar por VO, divididas  
- em no máximo 600 mg de cálcio elementar por vez.  
- Estrógenos conjugados: dose individualizada, por VO.  
- Pamidronato dissódico: dose de 60 mg, por via IV a cada 3 meses. Após reconstituição, deve-se diluir o fármaco em  
500 mL de soro fisiológico. A duração mínima da infusão é de 2 horas;  
- Raloxifeno: dose de 60 mg por dia, por VO.  
- Risedronato sódico: dose de 35 mg, uma vez por semana, por VO. Deve ser ingerido em jejum, pelo menos 30 minutos antes da primeira refeição e de outros medicamentos, com um copo de água. Após a ingestão, o paciente deve ficar sentado ou de pé por 30 minutos;  
- Romosozumabe: dose recomendada de 210 mg, por via subcutânea, uma vez por mês durante um período de 12 meses. Os pacientes devem ser adequadamente suplementados com cálcio e colecalciferol (vitamina D).

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.9 Tempo de tratamento – critérios de interrupção** -->
A maioria dos estudos que embasam o uso de medicamentos na prevenção de fraturas osteoporóticas tem seguimento de 3 a 5 anos. O estudo FIT mostrou redução de fraturas com alendronato por 5 anos<sup>46</sup> . No entanto, o estudo FLEX, seguimento do primeiro, randomizou os pacientes do grupo alendronato para manutenção com alendronato por mais 5 anos (totalizando 10 anos de tratamento) ou para placebo (com interrupção do alendronato após 5 anos), mostrando leve benefício apenas na prevenção de fraturas vertebrais com a manutenção em longo prazo<sup>47</sup> . Portanto, com base no exposto, o tratamento da osteoporose deve ser mantido por cinco anos em pacientes em uso de bisfosfonato oral e por três anos, para bisfosfonato intravenoso. No entanto, em pacientes com risco de fratura elevado (T-escore menor que -3,0 DP ou na presença de fraturas), o tratamento pode ser estendido por dez anos para bisfosfonato oral e seis anos para bisfosfonato IV. Nestes casos, recomendase a individualização da conduta<sup>25</sup> .  
Naqueles pacientes que, mesmo em tratamento medicamentoso, apresentem piora da DMO à densitometria e ocorrência de fraturas, deve-se avaliar adesão ao tratamento, fatores interferentes na absorção do medicamento e causas secundárias de osteoporose. Assim, antes de uma mudança no tratamento medicamentoso, a equipe multidisciplinar deve considerar esses fatores, bem como o cumprimento dos critérios de inclusão deste Protocolo.  
Durante o uso de estrógenos deve-se acompanhar o risco do paciente de desenvolvimento de eventos tromboembólicos, avaliação periódica do risco cardiovascular e risco de câncer de mama e sua suspensão deve ser realizada de acordo com diretrizes de terapia de reposição hormonal da menopausa<sup>68,69</sup> .  
O tempo de uso do romosozumabe é de no máximo um ano, sendo recomendado o seguimento com o uso de bisfosfonato, para preservar o ganho de massa óssea e prevenir fraturas, independentemente da DMO, salvo contraindicação para uso. Caso haja contraindicação, a escolha da terapia sequencial deverá ser individualizada. O possível aumento de risco de eventos adversos cardiovasculares deve ser considerando quando em uso de romosozumabe<sup>70</sup> . Inexiste, até o momento, evidência científica robusta que justifique retratamento com romosozumabe para pacientes com osteoporose.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.10 Fluxo de tratamento** -->
**Figura 2.** Fluxograma para tratamento da osteoporose.  
<!-- Start of picture text -->
Pacino com suspeta de osteoporose ou osteoporose<br>confirmada®<br>EL _/Paciente apresenta\ ><br>bistostonatoCalcio + colecalteroloral alendronato=  ou Ndo sastintestinal/~“intoetanca ou \ sim __|42 Cliouso intravenoso(écido+ colecacterol+ bistosfo zoled n atoico<br>‘isedronato) \ "reudade do / ‘ou pamaronato)><br>sm / _/pacientocom indicagdo NBO sin / Pacente com \ Nao<br>para substturcolecatcitrsl calcio \. lioIndicagZo+ caecpar a terolsubstiuir por<br>\\—porcatctiot? —/ \catetnior? /<br>i —“ral > VL / {Calcio+ bisfostonato+ colecaliterl oral . (bistosfonatointravencsoCaletroldo+ uso — colecaetoroReposicloe uso nravenoso de= bsfostonato cao +<br>‘vali‘do stuacio paciente* cinica |S _// Pacerjanaintoleranca terapeusica areseniou 20s ou \\\ NiO eeae<br>\__wybistosfonatos? / erlodicamente<br>jeMunerescom asteonecroseapbs menopause de ‘Munarespies apbs me menopausaRepealeae com Coe‘Mulneresaac apbs 'Mulnerescomprometimentono cimatérioé3com | (Pacientes‘mandtbulacomou aturaosteonecrose atipica de de Cree<br>femur | eeconcomitante de estrégenos tromboemboismoseal [qualidade‘sifomas vasomotores de vida devido aos ‘émur oueS contraindicaco aos fama terapdutestCD<br>— Eee | cams | rengaort ano<br>(_Apés tratamento com»)<br>RT romosozumabe,Iniciar terapia<br>panesak K antreabsorivo,usualmente‘sequencialDisfostonatocom agente J<br>Contrada por um dos seguintescrtrostaturas maloes (12,<br>nos) e comprovadas radologicamente, sem necessidadetémur proximal, rédo dstal, mero proximalou coluna vertebra) ou tetas de quad por Baio mpacto(decorrentasda quada da propria altura ou<br>ido OU bara massa éssea (T-escore menor ou igual 2-10de© malar densitometia au igual OU2-2,49) exame em denstométrcopacientes frdges, com T-escorecom isco de menorqueda ou aumentada igual a-2,5 noindependentemente fémur proximal (coloda ouade fémur ou total),em pacientescluna lombarcom probabildade ou terco dstalde do ature<br>pelo FRAX®, acma do limar de intervenco.<br>©om© usocalcio!incutcéncia de pamicronato¢recomendadohepatica estou reservadoparanipoparatreoidemopacientesas stuagbesrenaiscrdnicas em quecom o aciddepuracdo zoledrénico de creatinna ester indisponivelendogans  ou o(OCE) paciente menor apresentarcontraindicacSoou igual a 30 mLimin, com osteomaléciaMpotestatémica ao Seu uso. ou por defciincia da 1-aa-hidroslase,<br>‘Manter a reposcao de calcio ~colecalefrol ou calcio independente da atematvatrapéutica escobida<br>jtaminaFahvaterapdutca:pacienteD OU quando 0 pacienteapresentaapresenta duas ouumamaisfaturafraturasncidantoosteoporticasapos tempo enquanto minim de emtatamanto uso dos medicamentosde 1 ano com  preconizadesmedicamanto preconizadonasto ProtocolonesteporProtocolo polo menos@ perda um ano,signicatwacom adaquacdodo dansidade das posologiasmineral ossea de cécio ©<br>reducdo de mais de 5% em qualquer sito no intervaloavaiado), consderando boa adesdo ao tratamentoe auséncia de causas secundarias de parda de massa Osea<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **7.2.11 Benefícios esperados** -->
O tratamento da osteoporose tem por objetivo reduzir a incidência de fraturas osteoporóticas vertebrais, não vertebrais e de quadril, bem como as complicações delas advindas.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **8. MONITORAMENTO** -->
Deve ser realizada densitometria óssea inicial na primeira avaliação e após o início do tratamento, repetindo-se o exame a cada 1 a 2 anos, até que a massa óssea esteja estável. O antebraço pode ser considerado uma alternativa quando os outros sítios apresentam artefatos ou em pacientes com hiperparatireoidismo. O monitoramento posterior deve ser baseado na avaliação clínica individual. É importante utilizar o mesmo equipamento de densitometria para as comparações futuras. Radiografia de coluna dorsal e lombar em perfil deve ser repetida, caso o paciente apresente clínica sugestiva de fratura ou  
perda progressiva de altura superior a 4 cm. Exames laboratoriais devem ser repetidos a critério clínico, basicamente para verificar níveis séricos de vitamina D e cálcio ou para reinvestigar causas secundárias, se o tratamento não for eficaz. O tratamento é considerado bem-sucedido<sup>10</sup> com a DMO crescente ou estável ou sem evidência de novas fraturas.  
A adesão ao tratamento medicamentoso e não medicamentoso deve ser monitorada regularmente durante o tratamento. Deve-se reforçar a importância do uso correto dos medicamentos e identificar e tratar possíveis eventos adversos que contribuam para a má adesão.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamentos prescritas e dispensadas, além da adequação de uso de medicamentos. Doentes com osteoporose devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com osteoporose em tratamento devem ser avaliados periodicamente em relação à eficácia do mesmo e ao desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses, conforme necessário e o controle de efeitos adversos.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **11. REFERÊNCIAS** -->
1. Professor Kanis JA, Melton LJ, Christiansen C, Johnston CC, Khaltaev N. The diagnosis of osteoporosis. Journal of Bone and Mineral Research. 1994 Aug 1;9(8):1137–41.  
2. Radominski SC, Bernardo W, Paula AP de, Albergaria B, Moreira C, Fernandes CE, et al. Diretrizes brasileiras para o diagnóstico e tratamento da osteoporose em mulheres na pós‐menopausa. Rev Bras Reumatol. 2017;57:452–66.  
3. Kanis JA, Cooper C, Rizzoli R, Reginster JY. European guidance for the diagnosis and management of osteoporosis in postmenopausal women. Osteoporosis International. 2019 Jan 18;30(1):3–44.  
4. Weaver CM, Gordon CM, Janz KF, Kalkwarf HJ, Lappe JM, Lewis R, et al. The National Osteoporosis Foundation’s position statement on peak bone mass development and lifestyle factors: a systematic review and implementation recommendations. Osteoporosis International. 2016 Apr 1;27(4):1281–386.  
5. Sozen T, Ozisik L, Calik Basaran N. An overview and management of osteoporosis. Eur J Rheumatol. 2017 Mar 1;4(1):46–56.  
6. Pinheiro MM, Ciconelli RM, Martini LA, Ferraz MB. Clinical risk factors for osteoporotic fractures in Brazilian women and men: the Brazilian Osteoporosis Study (BRAZOS). Osteoporosis International. 2009 Mar 3;20(3):399– 408.  
7. Domiciano DS, Machado LG, Lopes JB, Figueiredo CP, Caparbo VF, Takayama L, et al. Incidence and risk factors for osteoporotic vertebral fracture in low-income community-dwelling elderly: a population-based prospective cohort study in Brazil. The São Paulo Ageing &amp; Health (SPAH) Study. Osteoporosis International. 2014 Dec 5;25(12):2805–15.  
8. Lopes JB, Fung LK, Cha CC, Gabriel GM, Takayama L, Figueiredo CP, et al. The impact of asymptomatic vertebral fractures on quality of life in older community-dwelling women: the São Paulo Ageing &amp; Health Study. Clinics. 2012;67(12):1401–6.  
9. Silva DMW, Lazaretti-Castro M, Freitas Zerbini CA de, Szejnfeld VL, Eis SR, Borba VZC. Incidence and excess mortality of hip fractures in a predominantly Caucasian population in the South of Brazil. Arch Osteoporos. 2019 Dec 16;14(1):47.  
10. Watts NB, Camacho PM, Lewiecki EM, Petak SM. American Association of Clinical Endocrinologists/American College of Endocrinology Clinical Practice Guidelines for the Diagnosis and Treatment of Postmenopausal Osteoporosis—2020 Update. Endocrine Practice. 2021 Apr;27(4):379–80.  
11. Walker-Bone K. Recognizing and treating secondary osteoporosis. Nat Rev Rheumatol. 2012 Aug 10;8(8):480–92.  
12. MINISTÉRIO DA SAÚDE DIRETRIZES METODOLÓGICAS ELABORAÇÃO DE DIRETRIZES CLÍNICAS [Internet]. Available from: www.gov.br/conitec/pt-br/  
13. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008 Apr 26;336(7650):924–6.  
14. Kanis JA, Kanis JA. Assessment of fracture risk and its application to screening for postmenopausal osteoporosis: Synopsis of a WHO report. Osteoporosis International. 1994 Nov;4(6):368–81.  
15. Nicholson WK, Silverstein M, Wong JB, Chelmow D, Coker TR, Davis EM, et al. Screening for Osteoporosis to Prevent Fractures. JAMA. 2025 Jan 14;  
16. Shuhart C, Cheung A, Gill R, Gani L, Goel H, Szalat A. Executive Summary of the 2023 Adult Position Development Conference of the International Society for Clinical Densitometry: DXA Reporting, Follow-up BMD Testing and Trabecular Bone Score Application and Reporting. J Clin Densitom. 2024;27(1):101435.  
17. Siris ES, Chen YT, Abbott TA, Barrett-Connor E, Miller PD, Wehren LE, et al. Bone Mineral Density Thresholds for Pharmacological Intervention to Prevent Fractures. Arch Intern Med. 2004 May 24;164(10):1108.  
18. Kanis JA, Harvey NC, Johansson H, Liu E, Vandenput L, Lorentzon M, et al. A decade of FRAX: how has it changed the management of osteoporosis? Aging Clin Exp Res. 2020 Feb 11;32(2):187–96.  
19. Sousa C de J, Oliveira MLC de. FRAX Tool in Brazil: an integrative literature review following validation. Revista Brasileira de Geriatria e Gerontologia. 2018 Feb;21(1):108–15.  
20. Augusto De Freitas Zerbini C. FRAX Modelo Brasil: um texto clínico explicativo sobre limiares para intervenção terapêutica [Internet]. Available from: https://www.shef-  
21. Zerbini CAF, Szejnfeld VL, Abergaria BH, McCloskey E V., Johansson H, Kanis JA. Incidence of hip fracture in Brazil and the development of a FRAX model. Arch Osteoporos. 2015 Dec 25;10(1):28.  
22. Augusto De Freitas Zerbini C. FRAX Modelo Brasil: um texto clínico explicativo sobre limiares para intervenção terapêutica [Internet]. Available from: https://www.shef-  
23. Kanis JA, Cooper C, Rizzoli R, Reginster JY. European guidance for the diagnosis and management of osteoporosis in postmenopausal women. Osteoporosis International. 2019 Jan 18;30(1):3–44.  
24. Shoback D, Rosen CJ, Black DM, Cheung AM, Murad MH, Eastell R. Pharmacological Management of Osteoporosis in Postmenopausal Women: An Endocrine Society Guideline Update. J Clin Endocrinol Metab. 2020 Mar 1;105(3):587–94.  
25. Eastell R, Rosen CJ, Black DM, Cheung AM, Murad MH, Shoback D. Pharmacological Management of Osteoporosis in Postmenopausal Women: An Endocrine Society Clinical Practice Guideline. J Clin Endocrinol Metab. 2019 May 1;104(5):1595–622.  
26. Cosman F, de Beur SJ, LeBoff MS, Lewiecki EM, Tanner B, Randall S, et al. Clinician’s Guide to Prevention and Treatment of Osteoporosis. Osteoporosis International. 2014 Sep 26;25(10):2359–81.  
27. Prevention and management of osteoporosis. World Health Organ Tech Rep Ser. 2003;921:1–164, back cover.  
28. Compston J. Glucocorticoid-induced osteoporosis: an update. Endocrine. 2018 Jul 24;61(1):7–16.  
29. Humphrey MB, Russell L, Danila MI, Fink HA, Guyatt G, Cannon M, et al. 2022 American College of Rheumatology Guideline for the Prevention and Treatment of <scp>Glucocorticoid‐Induced</scp> Osteoporosis. Arthritis & Rheumatology. 2023 Dec 16;75(12):2088–102.  
30. Rachner TD, Coleman R, Hadji P, Hofbauer LC. Bone health during endocrine therapy for cancer. Lancet Diabetes Endocrinol. 2018 Nov;6(11):901–10.  
31. Russell N, Grossmann M. Management of bone and metabolic effects of androgen deprivation therapy. Urologic Oncology: Seminars and Original Investigations. 2021 Oct;39(10):704–12.  
32. Hadji P, Aapro MS, Body JJ, Bundred NJ, Brufsky A, Coleman RE, et al. Management of aromatase inhibitorassociated bone loss in postmenopausal women with breast cancer: practical guidance for prevention and treatment. Annals of Oncology. 2011 Dec;22(12):2546–55.  
33. Morrison RS, Chassin MR, Siu AL. The medical consultant’s role in caring for patients with hip fracture. Ann Intern Med. 1998 Jun 15;128(12 Pt 1):1010–20.  
34. Howe TE, Shea B, Dawson LJ, Downie F, Murray A, Ross C, et al. Exercise for preventing and treating osteoporosis in postmenopausal women. Cochrane Database of Systematic Reviews. 2011 Jul 6;  
35. Tricco AC, Thomas SM, Veroniki AA, Hamid JS, Cogo E, Strifler L, et al. Comparisons of Interventions for Preventing Falls in Older Adults. JAMA. 2017 Nov 7;318(17):1687.  
36. CADERNETA DE SAÚDE DA PESSOA IDOSA DA PESSOA IDOSA [Internet]. Available from: www.saude.gov.br/idoso  
37. INTO. Instituto Nacional de Traumatologia e Ortopedia. Como reduzir quedas no idoso [Internet]. [cited 2025 Jan 19]. Available from: https://www.into.saude.gov.br/lista-dicas-dos-especialistas/186-quedas-e-inflamacoes/272como-reduzir-quedas-no-idoso  
38. Diez-Perez A, Adachi JD, Agnusdei D, Bilezikian JP, Compston JE, Cummings SR, et al. Treatment failure in osteoporosis. Osteoporos Int. 2012 Dec;23(12):2769–74.  
39. Carey JJ. What is a “failure” of bisphosphonate therapy for osteoporosis? Cleve Clin J Med. 2005 Nov;72(11):1033– 9.  
40. Confavreux CB, Paccou J, David C, Mehsen N, Leboime A, Thomas T. Defining treatment failure in severe osteoporosis. Joint Bone Spine. 2010 Dec;77 Suppl 2:S128-32.  
41. Silva BC, Madeira M, d’Alva CB, Maeda SS, Holanda NCP de, Ohe MN, et al. Definition and management of very high fracture risk in women with postmenopausal osteoporosis: a position statement from the Brazilian Society of Endocrinology and Metabolism (SBEM) and the Brazilian Association of Bone Assessment and Metabolism (ABRASSO). Arch Endocrinol Metab. 2022 Oct 3;  
42. Ministério da Saúde. PORTARIA GM/MS N<sup>o</sup> 4.379, DE 14 DE JUNHO DE 2024. Altera a Portaria de Consolidação GM/MS n<sup>o</sup> 2, de 28 de setembro de 2017, para estabelecer as Diretrizes Nacionais do Cuidado Farmacêutico no âmbito do Sistema Único de Saúde - SUS. [Internet]. Brasília; 2024. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2024/prt4379_17_06_2024.html  
43. Moreira CA, Ferreira CE dos S, Madeira M, Silva BCC, Maeda SS, Batista MC, et al. Reference values of 25hydroxyvitamin D revisited: a position statement from the Brazilian Society of Endocrinology and Metabolism (SBEM) and the Brazilian Society of Clinical Pathology/Laboratory Medicine (SBPC). Arch Endocrinol Metab. 2020 May 27;  
44. Holick MF, Binkley NC, Bischoff-Ferrari HA, Gordon CM, Hanley DA, Heaney RP, et al. Evaluation, Treatment, and Prevention of Vitamin D Deficiency: an Endocrine Society Clinical Practice Guideline. J Clin Endocrinol Metab. 2011 Jul;96(7):1911–30.  
45. Avenell A, Mak JC, O’Connell DL. Vitamin D and vitamin D analogues for preventing fractures in post-menopausal women and older men. Cochrane Database of Systematic Reviews. 2014 Apr 14;2021(6).  
46. Black DM, Cummings SR, Karpf DB, Cauley JA, Thompson DE, Nevitt MC, et al. Randomised trial of effect of alendronate on risk of fracture in women with existing vertebral fractures. The Lancet. 1996 Dec;348(9041):1535– 41.  
47. Black DM, Schwartz A V., Ensrud KE, Cauley JA, Levis S, Quandt SA, et al. Effects of Continuing or Stopping Alendronate After 5 Years of Treatment. JAMA. 2006 Dec 27;296(24):2927.  
48. Byun JH, Jang S, Lee S, Park S, Yoon HK, Yoon BH, et al. The Efficacy of Bisphosphonates for Prevention of Osteoporotic Fracture: An Update Meta-analysis. J Bone Metab. 2017;24(1):37.  
49. Black DM, Abrahamsen B, Bouxsein ML, Einhorn T, Napoli N. Atypical Femur Fractures: Review of Epidemiology, Relationship to Bisphosphonates, Prevention, and Clinical Management. Endocr Rev. 2019 Apr 1;40(2):333–68.  
50. Kothawala P, Badamgarav E, Ryu S, Miller RM, Halbert RJ. Systematic Review and Meta-analysis of Real-World Adherence to Drug Therapy for Osteoporosis. Mayo Clin Proc. 2007 Dec;82(12):1493–501.  
51. Wells GA, Hsieh SC, Zheng C, Peterson J, Liu W, Kelly SE, et al. Risedronate for the primary and secondary prevention of osteoporotic fractures in postmenopausal women. Cochrane Database of Systematic Reviews. 2022 May 3;2022(7).  
52. Wells GA, Cranney A, Peterson J, Boucher M, Shea B, Welch V, et al. Alendronate for the primary and secondary prevention of osteoporotic fractures in postmenopausal women. Cochrane Database of Systematic Reviews. 2008 Jan 23;  
53. Aché Laboratórios Farmacêuticos S.A. Farmacêutica. Alendronato de sódio. [Internet]. [cited 2025 Jan 20]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=ALENDRONATO%20DE%20SODIO  
54. Legrand Pharma Indústria Farmacêutica LTDA. Risedronato sódico. [Internet]. [cited 2025 Jan 20]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?numeroRegistro=167730579  
55. Cellera Farmacêutica S/A. Alendronato de Sódio [Internet]. [cited 2025 Feb 12]. Available from: https://www.cellerafarma.com.br/wp-content/uploads/2019/04/Bula-do-Profissional_ENDROSTAN.pdf  
56. EMS S/A. Cloridrato de Raloxifeno [Internet]. [cited 2025 Jan 20]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=cloridrato%20de%20raloxifeno  
57. Barrionuevo P, Kapoor E, Asi N, Alahdab F, Mohammed K, Benkhadra K, et al. Efficacy of Pharmacological Therapies for the Prevention of Fractures in Postmenopausal Women: A Network Meta-Analysis. J Clin Endocrinol Metab. 2019 May 1;104(5):1623–30.  
58. Agnusdei D, Iori N. Raloxifene: results from the MORE study. J Musculoskelet Neuronal Interact. 2000 Dec;1(2):127–32.  
59. Cheng SH, Chu W, Chou WH, Chu WC, Kang YN. Cardiovascular Safety of Romosozumab Compared to Commonly Used Anti-osteoporosis Medications in Postmenopausal Osteoporosis: A Systematic Review and Network Metaanalysis of Randomized Controlled Trials. Drug Saf. 2025 Jan;48(1):7–23.  
60. Saag KG, Petersen J, Brandi ML, Karaplis AC, Lorentzon M, Thomas T, et al. Romosozumab or Alendronate for Fracture Prevention in Women with Osteoporosis. New England Journal of Medicine. 2017 Oct 12;377(15):1417– 27.  
61. Brasil. Ministério da Saúde. Relatório de Recomendação n<sup>o</sup> 788 -  Romosozumabe para o tratamento da osteoporose grave em mulheres na pós-menopausa, acima de 70 anos, em falha terapêutica ao padrão de tratamento atualmente disponível no SUS e em muito alto risco de  fratura por fragilidade. 2022 Nov [cited 2025 Jan 20]; Available from: https://www.gov.br/conitec/pt-  
br/midias/relatorios/2022/20221206_relatorio_romosozumabe_osteoporose_grave_falha.pdf  
62. Brasil. Ministério da Saúde. Relatório de Recomendação n<sup>o</sup> 920 - Ampliação de uso do romosozumabe e reavaliação da teriparatida para o tratamento de osteoporose grave [Internet]. Brasília; 2024 Jul. Available from: https://www.gov.br/conitec/pt-br  
63. Brasil. Ministério da Saúde. Relatório de Recomendação n<sup>o</sup> 921 - Teriparatida para o tratamento de osteoporose secundária a glicocorticoides, pacientes do sexo masculino e pacientes que apresentaram infarto  do miocárdio ou acidente vascular cerebral no ano anterior [Internet]. Brasília; 2024 Aug. Available from: https://www.gov.br/conitec/pt-br  
64. Lewiecki EM, Blicharski T, Goemaere S, Lippuner K, Meisner PD, Miller PD, et al. A Phase III Randomized Placebo-Controlled Trial to Evaluate Efficacy and Safety of Romosozumab in Men With Osteoporosis. J Clin Endocrinol Metab. 2018 Sep 1;103(9):3183–93.  
65. Kobayakawa T, Kanayama Y, Hirano Y, Nakamura Y. Comparison of Denosumab with Romosozumab in the treatment of male osteoporosis: a retrospective cohort study. Sci Rep. 2024 Oct 1;14(1):22785.  
66. Wells G, Chernoff J, Gilligan JP, Krause DS. Does salmon calcitonin cause cancer? A review and meta-analysis. Osteoporosis International. 2016 Jan 5;27(1):13–9.  
67. Li N, Gong YC, Chen J. A meta-analysis of the therapeutic effect of intranasal salmon calcitonin on osteoporosis. Eur J Med Res. 2021 Dec 8;26(1):140.  
68. Oliveira GMM de, Almeida MCC de, Arcelus CMA, Espíndola L, Rivera MAM, Silva-Filho AL da, et al. Brazilian Guideline on Menopausal Cardiovascular Health – 2024. Revista Brasileira de Ginecologia e Obstetrícia. 2024 Oct 7;46.  
69. “The 2022 Hormone Therapy Position  Statement of The North American Menopause Society” Advisory  Panel. The 2022 hormone therapy position statement of The North American Menopause Society. Menopause. 2022 Jul 1;29(7):767–94.  
70. Fuggle NR, Beaudart C, Bruyère O, Abrahamsen B, Al-Daghri N, Burlet N, et al. Evidence-Based Guideline for the management of osteoporosis in men. Nat Rev Rheumatol. 2024 Apr 14;20(4):241–51.  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER ÁCIDO ZOLEDRÔNICO, ALENDRONATO, CALCITONINA, CALCITRIOL, CARBONATO DE CÁLCIO, COLECALCIFEROL, PAMIDRONATO, RALOXIFENO, RISEDRONATO E ROMOSOZUMABE**  
Eu, __________________________________________________________________ (nome do [a] paciente),  
declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de ácido zoledrônico, alendronato, calcitonina, calcitriol, carbonato de cálcio, colecalciferol, pamidronato, raloxifeno, risedronato e romosozumabe indicados para o tratamento da **osteoporose** .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ___________________________________________________________________________________________ (nome do (a) médico (a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- redução de fraturas osteoporóticas;  
- redução das complicações relacionadas a fraturas.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- os bisfosfonatos orais (alendronato e risedronato) não devem ser usados por quem não consegue ficar sentado ou de pé por 30 min após a ingestão com água; a função dos rins deve ser avaliada antes e durante o tratamento; são contraindicados em quem tem cálcio baixo no sangue, na gravidez e na amamentação; caso engravide, devo avisar imediatamente o médico;  
- o raloxifeno é contraindicado em quem tem risco de trombose ou embolia; não se pode usar estrógenos ao mesmo  
- tempo;  
- os estrógenos conjugados são contraindicados em quem tem risco de câncer de mama, de trombose ou de isquemia;  
- - eventos adversos mais comuns do calcitriol: náuseas, vômitos, sede aumentada, urina aumentada (por  
- hipercalcemia). Os eventos menos comuns incluem dor de cabeça, dor abdominal e manchas na pele (rash);  
- eventos adversos mais comuns dos bisfosfonatos orais (alendronato e risedronato): dores abdominais, náusea, diarreia, gases, dor no estômago, depressão, tonturas, insônia, ansiedade, dores nos músculos, câimbras, formigamentos, aumento da pressão arterial, dor no peito, falta de ar, vermelhidão e coceira na pele, infecções em geral;  
- eventos adversos mais comuns do ácido zoledrônico: dores de cabeça, musculares e nas juntas, febre, cansaço, fraqueza, sonolência ou insônia, náuseas, perda do apetite, aumento dos batimentos do coração, aumento da pressão arterial, tonturas, formigamentos, prisão de ventre, aftas, dor no local da aplicação, diminuição das células do sangue (células brancas e plaquetas);  
- eventos adversos mais comuns do raloxifeno: câimbras nas pernas, fogachos, formação de coágulos nas veias  
- profundas das pernas, inchaço, náusea, vômitos, dores abdominais e dor de cabeça;  
- eventos adversos mais comuns da calcitonina: náusea, diarreia, prisão de ventre, gases, dor no estômago, perda de apetite, calorões/fogachos, aumento da pressão arterial, dor no peito, falta de ar, chiado no peito, tonturas, aumento do volume de urina, infecções, dores em geral, sangramento e irritação nasal, formação de crostas no nariz quando via nasal, espirros, reações no local de aplicação do medicamento (quando administrado pela via subcutânea), reações alérgicas, vermelhidão na pele e fraqueza;  
- eventos adversos mais comuns do pamidronato: febre, cansaço, sonolência ou insônia, náusea, perda do apetite,  
- aumento dos batimentos do coração, aumento da pressão arterial, prisão de ventre, aftas, dor no local da aplicação e diminuição das células do sangue (células brancas e plaquetas);  
- eventos adversos mais comuns do romosozumabe: o uso de romosozumabe pode resultar em hipocalcemia transitória, sendo necessário corrigir a hipocalcemia antes de iniciar o tratamento, além de monitorar os pacientes quanto a sinais e sintomas de hipocalcemia e suplementá-los com cálcio e vitamina D. Muito comumente pode ocorrer infecção viral do trato respiratório superior e artralgia. Comumente, podem ocorrer reações de hipersensibilidade (com erupções cutâneas, dermatite ou urticária), dor de cabeça, tosse, dor no pescoço, espasmos musculares, edema periférico e reações no local da injeção;  
- contraindicação em caso de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula;  
- risco da ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(  ) Sim   (  ) Não  
Meu tratamento constará do seguinte medicamento:  
<!-- Start of picture text -->
( ) ácido zoledrônico<br>( ) estrogênios conjugados<br>( ) alendronato de sódio<br>( ) pamidronato<br>( ) calcitonina<br>( ) raloxifeno<br>( ) calcitriol<br>( ) risedronato sódico<br>( ) carbonato de cálcio<br>( ) romosozumabe<br>( ) colecalciferol (vitamina D)<br><!-- End of picture text -->  
<!-- Start of picture text -->
Local:                               Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  U<br>F:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Alteração pós publicação** -->
Depois da publicação da Portaria Conjunta SAES-SECTICS/MS nº 22/2025, impôs-se um ajuste do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose, pela necessidade de se incluir o termo “associado a” na redação da definição de osteoporose grave, disposta no tópico “3.1 Diagnóstico clínico e densitométrico”.  
O tema foi apresentado como informe à 132ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 13 de janeiro de 2025.  
Depois da publicação da Portaria Conjunta SAES-SECTICS/MS nº 22/2025, impôs-se um ajuste do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose, pela necessidade de se incluir o termo “pós-menopausa” nos critérios de inclusão do medicamento romosozumabe, considerando a indicação prevista em bula aprovada pela Agência Nacional de Vigilância Sanitária (Anvisa).  
O tema foi apresentado como informe à 131ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 16 de dezembro de 2025.  
**Atualização do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose após ampliação do uso do romosozumabe e exclusão da teriparatida no SUS − versão 2025**

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **1. Escopo e finalidade do Protocolo** -->
O objetivo desta atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Osteoporose foi incluir orientações sobre a exclusão da teriparatida, conforme Portaria SECTICS/MS nº 39, de 19 de setembro de 2024 e ampliação do uso do romosozumabe para o tratamento de osteoporose grave e em falha terapêutica, conforme Portaria SECTICS/MS nº 40, de 12 de setembro de 2024.  
Considerando a versão do PCDT da Osteoporose, publicado por meio da Portaria Conjunta SAES/SECTICS/MS nº 19, de 28 de setembro de 2023, esta atualização rápida focou na inclusão de orientações sobre a ampliação de uso de romosozumabe e da exclusão da teriparatida no âmbito do SUS.  
O processo de atualização rápida do Protocolo se iniciou com uma reunião de alinhamento em 27 de novembro 2024, na qual foram discutidos os tópicos a serem atualizados no documento.  
Todos os membros do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao MS para análise prévia à reunião.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: Colaboração externa -->
O Protocolo foi atualizado pelo NATS Nuclimed do Hospital de Clínicas de Porto Alegre (Nuclimed HCPA).  
**Declaração e Manejo de Conflitos de Interesse**  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos b|enefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de<br>alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser<br>afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever|(   ) Sim|
|e que deveria ser do conhecimento público?|(   ) Não|  
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa|(   ) Sim|
|---|---|
|afetar sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados|(   ) Sim|
|acima?|(   ) Não|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Osteoporose foi apresentada na 122ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em janeiro de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES); Secretaria de Vigilância em Saúde e Ambiente (SVSA) e Secretaria de Atenção Primária à Saúde (SAPS). A proposta foi aprovada para avaliação da Conitec. O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 137ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Consulta pública** -->
A Consulta Pública nº 16/2025, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose, foi realizada entre os dias 26/03/2025 e 14/04/2025. Foram recebidas 142 contribuições, que podem ser verificadas em: (https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/contribuicao-cp-16_2025-pcdt-para-osteoporose).

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **3. Busca da evidência e recomendações** -->
Considerando a versão do PCDT da Osteoporose, publicada por meio da Portaria Conjunta SAES/SECTICS/MS nº MS nº 19, de 28 de setembro de 2023, esta atualização rápida teve foco na inclusão de orientações sobre a exclusão da teriparatida, conforme Portaria SECTICS/MS nº 39, de 19 de setembro de 2024 e ampliação do uso do romosozumabe para o tratamento de osteoporose grave e em falha terapêutica, conforme Portaria SECTICS/MS nº 40, de 12 de setembro de 2024. As evidências e pergunta de pesquisa avaliadas no momento das avaliações, incluídas nesta atualização, encontramse nos Relatórios de Recomendação nº 920/2024 e 921/2024, respectivamente. Disponível em: (https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-no-920-ampliacao-de-uso-do- <u>romosozumabe)</u> e (https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-no-921- <u>teriparatida).</u>  
Também foram feitas revisões pontuais no texto e incluídas referências publicadas após a atualização anterior do PCDT.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Atualização do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose após incorporação do** -->
**romosozumabe no SUS − versão 2023**

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **1. Escopo e finalidade do Protocolo** -->
O objetivo da atualização deste Protocolo foi incluir orientações sobre o uso do romosozumabe, devido à incorporação desse novo tratamento no âmbito do SUS após a recomendação do plenário da Conitec, no dia 09 de novembro de 2022, de atualização do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose. A deliberação da Conitec, conforme o Relatório nº 788 – Romosozumabe para o tratamento da osteoporose grave em mulheres na pós-menopausa, acima de 70 anos, e falha terapêutica ao padrão de tratamento atualmente disponível no SUS e em muito alto risco de fratura por fragilidade, foi:  
“recomendar a incorporação do romosozumabe para mulheres com osteoporose na pós menopausa, a partir de 70 anos, que apresentam risco muito alto de fratura por fragilidade e falha com o padrão de tratamento medicamentoso, conforme protocolo estabelecido pelo Ministério da Saúde. A decisão de incorporação da tecnologia foi publicada por meio da Portaria SCTIE/MS nº 166, de 5 de dezembro de 2022.  
Processo de atualização do PCDT:  
Houve atualização na seção sobre tratamento da osteoporose, sendo o romosozumabe incluído entre as opções de tratamento medicamentoso.  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do PCDT de Osteoporose foi apresentada na 105ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em janeiro de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES); Secretaria de Vigilância em Saúde e Ambiente (SVSA) e Secretaria de Atenção Primária à Saúde (SAPS).  
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Osteoporose contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
A atualização do PCDT da Osteoporose iniciou-se com a demanda pelo Ministério da Saúde (MS) da atualização do texto e das referências do PCDT vigente. A reunião de escopo foi realizada em Brasília, em 19 de março de 2019.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
Os trabalhos foram conduzidos considerando o Protocolo publicado por meio da Portaria SAS/MS nº 45, de 09 de junho de 2014, publicada em 10 de junho de 2014 e retificada em 18 de junho de 2014) e a estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009.  
Ficou estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não demandariam questões de pesquisa definidas por serem práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Ainda, foram elencadas três novas questões de pesquisa para a revisão do PCDT.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo elaborador deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do DGITS. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do PCDT de Osteoporose foi apresentada na 102ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em agosto de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Primária à Saúde (SAPS) Secretaria de Atenção Especializada à Saúde (SAES) e Secretaria Especial de Saúde Indígena. O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Plenário da Conitec em sua 112ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.  
Consulta pública  
A Consulta Pública nº 06/2023, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose, foi  
realizada entre os dias 06/04/2023 a 25/04/2023. Foram recebidas 171 contribuições, que podem ser verificadas em:  
<u>https://www.gov.br/conitec/pt-br/assuntos/participacao-social/consultas-publicas/encerradas .</u>

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **3. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ou PIRO ( **Figura A** ). Durante a reunião de escopo deste PCDT três questões de pesquisa foram definidas ( **Quadro A)** .  
**Figura A** . Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
f PR <Populag ou condo cic<br>Fo<br>*interven¢do, no caso de estudos experimentais<br>Fator de exposi¢do, em caso de estudos observacionais<br>Teste indice, nos casos de estudos de acurdcia diagndéstica<br>q<br>*Controle, de acordo com tratamento/niveis de exposi¢ao do fator/exames<br>disponiveis no SUS<br>‘*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
**Quadro A.** Questões PICO elencadas para atualização do PCDT da Osteoporose.  
|**PICO**|**Pergunta**|
|---|---|
||Ácido zoledrônico é eficaz, seguro e custo-efetivo no tratamento de pacientes com osteoporose com|
|**1**|intolerância ou dificuldades de deglutição dos bisfosfonatos orais, comparado a alendronato, risedronato,<br>pamidronato ou placebo?|
|**2**|Denosumabe e teriparatida são eficazes, efetivos, seguros e custo-efetivos no tratamento de pacientes com<br>osteoporose grave e falha terapêutica (após segunda fratura) comparado a bisfosfonatos e raloxifeno?|
|**3**|Denosumabe é eficaz, seguro e custo-efetivo no tratamento de pacientes com osteoporose com insuficiência<br>renal grave (DCE < 30 mL/min), comparado a qualquer comparador ativo ou placebo?|  
A equipe de metodologistas do projeto PCDT do HAOC foi responsável pela busca e avaliação de evidências, segundo metodologia GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ )<sup>1</sup> . A busca na literatura foi realizada nas bases de dados PubMed e Embase, bem como no Google Scholar e Epistemonikos. A estratégia de busca contemplou os vocabulários padronizados e não padronizados para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por um metodologista e checada por outro ou por dois metodologistas independentes. Dessa forma, na etapa de triagem dos estudos por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios de elegibilidade (de acordo com a pergunta de pesquisa) foram mantidos, independentemente do delineamento do estudo. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia/segurança.  
Adicionalmente, verificou-se a existência de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados. Os estudos excluídos na elegibilidade (leitura completa dos textos) tiveram suas razões de exclusão relatadas e referenciadas. O processo de seleção dos estudos foi representado em forma de fluxograma e pode ser visto ao longo do texto dos materiais suplementares específicos.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel®. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2)<sup>2</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane - _Risk of Bias –_ segunda versão (RoB)<sup>3</sup> e os estudos observacionais pela _ferramenta Risk Of Bias In Non-Randomised Studies - of Interventions_ (ROBINS-I)<sup>4</sup> .  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. A seguir, podem ser consultadas as estratégias de busca, síntese e avaliação das evidências para cada uma das questões PICO avaliadas para o presente PCDT.  
ÁCIDO ZOLEDRÔNICO PARA PACIENTES COM OSTEOPOROSE COM INTOLERÂNCIA OU DIFICULDADES DE DEGLUTIÇÃO DOS BISFOSFONATOS ORAIS<sup>5-6</sup>  
Para a avaliação desta tecnologia, foi elaborada a seguinte pergunta de pesquisa: “Ácido zoledrônico é eficaz, seguro e custo-efetivo no tratamento de pacientes com osteoporose com intolerância ou dificuldades de deglutição dos bisfosfonatos orais, comparado a alendronato, risedronato, pamidronato ou placebo?”  
Nesta pergunta, a população (P) foram os pacientes com osteoporose com intolerância ou dificuldades de deglutição dos bisfosfonatos orais; a intervenção (I) foi o ácido zoledrônico; o comparador alendronato, risedronato, pamidronato ou placebo (C); os _outcomes_ /desfechos (O) primários ‘qualquer fratura osteoporótica’; e secundários, eventos adversos graves e não graves e a densidade mineral óssea; o desenho de estudo incluído (S) foi ensaio clínico randomizado.  
A seguir, são apresentados o processo de busca da evidência, triagem e seleção de estudos, resultados e síntese dos dados, avaliação do risco de viés e avaliação da certeza na evidência. A avaliação detalhada dessa tecnologia encontra-se no Relatório de Recomendação nº 741, de junho de 2022 - Ácido zoledrônico para pacientes com osteoporose com intolerância ou dificuldades de deglutição dos bisfosfonatos orais, disponível no _site_ da Conitec<sup>2</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **A) Busca da Evidência** -->
Com base na pergunta estruturada no acrônimo PICOS, foi realizada uma busca em 10 de setembro de 2021 nas plataformas de busca PubMed e Embase. Não houve restrições com relação à data de publicação, mas houve em relação ao idioma na busca inicial para português, inglês e espanhol. As estratégias de busca podem ser vistas no **Quadro B** .  
**Quadro B.** Estratégias de busca sobre o uso de ácido zoledrônico para tratamento da osteoporose  
|**Fonte de dados**|**Estratégia de busca**|**Estudos**<br>**acessados**|
|---|---|---|
|PubMed/Embase|(((osteoporosis[MeSH Terms]) OR (osteoporosis[Title/Abstract]))<br>AND<br>((((((((risedronate[MeSH<br>Terms])<br>OR<br>(risedronate[Title/Abstract])) OR (alendronate[Title/Abstract])) OR<br>(alendronate[MeSH Terms])) OR (pamidronate[MeSH Terms])) OR<br>(pamidronate[Title/Abstract])) OR (zoledronic acid[Title/Abstract]))<br>OR (zoledronic acid[MeSH Terms]))) AND (((randomized controlled<br>trial[Publication Type]) OR (Controlled clinical trial[Publication<br>Type])<br>OR<br>(randomized[Title/Abstract])<br>OR<br>(randomly[Title/Abstract]) OR (trial[Title/Abstract])))|1.587|
|Embase|('osteoporosis'/exp OR osteoporosis) AND ('risedronic acid'/exp/mj<br>OR 'alendronic acid'/exp/mj OR 'pamidronic acid'/exp/mj OR<br>'zoledronic acid'/exp/mj) AND ('randomized controlled trial'/exp OR<br>'randomized controlled trial' OR (randomized AND controlled AND<br>('trial'/exp OR trial)) OR 'controlled clinical trial'/exp OR 'controlled<br>clinical trial' OR randomized:ti,ab,kw OR randomly:ti,ab,kw OR<br>trial:ti,ab,kw)|1.899|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **B) Seleção dos estudos** -->
A revisão sistemática avaliou 2.533 registros depois de remoção de duplicidades, dos quais 2.259 foram considerados irrelevantes durante a triagem e 204 foram excluídos após leitura dos textos na íntegra. Desta forma, foram incluídos 70 estudos na análise final. O fluxograma do processo de seleção dos estudos pode ser visto na **Figura B.**  
**Figura B** . Fluxograma da seleção dos estudos.  
<!-- Start of picture text -->
Bases do dados Artigos excluldos antes da triagem<br>MEDLINE/PubMedEmbase (n= (n1899)= 1.587) Duplicata de artigos (n = 953)<br>Artigas triados Exclufdos apds leitura de titulo @ resumo<br>(n= 2.533) (n= 2.259)<br>‘Anigas998 selecionados para letura<br>selecionadas<br>5 (n= 274) para (n=Artigas9) nde acassadas na integra<br>=<br>Amigosslogibilidade(n=avaliados274) para ArtigasPopulacaoexcluidos:inelegivel (n = 80)<br>TratamantoDasenha de inaiaaivelastudo inslagivel(9 = 103(n = 21)<br>Amigos incluidas na ravisae<br>(n= 70)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **C) Resultados e síntese de dados** -->
- Descrição dos estudos incluídos  
Os estudos incluídos foram descritos narrativamente. As informações sobre cada um deles pode ser consultada no Relatório de Recomendação nº 741, de junho de 2022<sup>2</sup> , disponível no _site_ da Conitec.  
- Síntese dos dados  
Foram conduzidas meta-análises para os desfechos de fratura geral, fratura vertebral, fratura não vertebral, DMO em coluna, em colo femoral, quadril, trocanter, evento adverso, evento adverso grave e evento adverso gastrointestinal.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Fratura geral** -->
A NMA foi composta por 36 estudos, os quais totalizaram 32.901 participantes. A Figura C demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem sete intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, placebo, risedronato), com 21 estimativas de efeito relativo (Quadro C). Estes resultados foram apresentados usando uma matriz chamada tabela de classificação (ou _league table_ ), a qual contém todos informações sobre a eficácia relativa e sua incerteza para todos os pares de intervenções possíveis. A NMA também verificou a contribuição de cada par de intervenções e de cada estudo no resultado apresentado na matriz.  
**Figura C** . NMA para fratura geral em pacientes com osteoporose.  
<!-- Start of picture text -->
‘AcidoZoledronicoting<br>‘secronato<br>Alendronato20mg<br>amisronatotSomgorat ‘Alendronato7omgsemana<br><!-- End of picture text -->  
Ao considerar a NMA, o ácido zoledrônico possui menor risco para a ocorrência de fraturas quando comparado ao placebo (RR: 0,762; IC95%: 0,584 – 0,995) e não possui diferença significativa quando comparado aos demais tratamentos.  
**Quadro C** . _League table_ para fratura geral em pacientes com osteoporose.  
|Ácido Zoledrônico 5mg|1.008<br>(0.703, 1.444)|0.873<br>(0.488, 1.562)|0.899<br>(0.352, 2.294)|2.287<br>(0.785, 6.662)|**0.762**<br>**(0.584,**<br>**0.995)**|1.362<br>(0.943,<br>1.968)|
|---|---|---|---|---|---|---|
|0.992<br>(0.693, 1.422)|Alendronato 10 mg|0.866<br>(0.489, 1.534)|0.893<br>(0.354, 2.253)|2.270<br>(0.784, 6.575)|0.757<br>(0.594,<br>0.964)|1.352<br>(0.976,<br>1.872)|
|1.146<br>(0.640, 2.050)|1.154<br>(0.652, 2.044)|Alendronato 20 mg|1.030<br>(0.365, 2.904)|2.620<br>(0.823, 8.338)|0.873<br>(0.521,<br>1.465)|1.560<br>(0.877,<br>2.777)|
|1.112<br>(0.436, 2.837)|1.120<br>(0.444, 2.828)|0.971<br>(0.344, 2.737)|Alendronato 70 mg semana|2.543<br>(0.646, 10.015)|0.848<br>(0.345,<br>2.081)|1.514<br>(0.615,<br>3.731)|
|0.437<br>(0.150, 1.274)|0.441<br>(0.152, 1.276)|0.382<br>(0.120, 1.215)|0.393<br>(0.100, 1.548)|Pamidronato 150 mg oral|0.333<br>(0.118,<br>0.939)|0.595<br>(0.205,<br>1.729)|
|**1.312**<br>**(1.005, 1.712)**|1.322<br>(1.037, 1.684)|1.145<br>(0.682, 1.921)|1.180<br>(0.481, 2.895)|3.000<br>(1.065, 8.449)|Placebo|1.786<br>(1.385,<br>2.303)|
|0.734<br>(0.508, 1.061)|0.740<br>(0.534, 1.024)|0.641<br>(0.360, 1.141)|0.660<br>(0.268, 1.627)|1.679<br>(0.578, 4.878)|0.560<br>(0.434,<br>0.722)|Risedronat<br>o|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Fratura vertebral** -->
A NMA foi composta por 16 estudos, os quais totalizaram 23.816 participantes. A Figura D demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem sete intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, placebo, risedronato), com 21 estimativas de efeito relativo (Quadro D).  
**Figura D** . NMA para fratura vertebral em pacientes com osteoporose.  
Ao considerar a NMA, o ácido zoledrônico possui menor risco para a ocorrência de fraturas vertebrais quando comparado ao alendronato 10 mg (RR: 0,200; IC95%: 0,049 – 0,815) e placebo (RR: 0,343; IC95% 0,218 – 539) e não possui diferença significativa quando comparado aos demais tratamentos.  
**Quadro D** . _League table_ fratura vertebral em pacientes com osteoporose.  
|Ácido Zoledrônico|**0.200**|0.560|3.210|0.579|**0.343**|0.857|
|---|---|---|---|---|---|---|
|5 mg|**(0.049, 0.815)**|(0.201, 1.559)|(0.145, 71.215)|(0.203, 1.652)|**(0.218, 0.539)**|(0.469, 1.566)|
|**4.989**|Alendronato|2.795|16.016|2.889|1.711|4.275|
|**(1.226, 20.300)**|10 mg|(0.556, 14.057)|(0.566, 452.822)|(0.565, 14.761)|(0.453, 6.462)|(1.067, 17.126)|
|1.785|0.358|Alendronato|5.730|1.034|0.612|1.530|
|(0.642, 4.966)|(0.071, 1.799)|20 mg|(0.233, 140.710)|(0.277, 3.863)|(0.244, 1.534)|(0.562, 4.165)|
|0.312|0.062|0.175|Alendronato|0.180|0.107|0.267|
|(0.014, 6.912)|(0.002, 1.765)|(0.007, 4.286)|70 mg semana|(0.007, 4.466)|(0.005, 2.294)|(0.012, 5.881)|
|1.727|0.346|0.967|5.543|Pamidronato|0.592|1.480|
|(0.605, 4.926)|(0.068, 1.768)|(0.259, 3.616)|(0.224, 137.222)|150 mg oral|(0.230, 1.525)|(0.530, 4.133)|
|**2.916**|0.584|1.633|9.359|1.688|Plb|2.499|
|**(1.857, 4.579)**|(0.155, 2.207)|(0.652, 4.092)|(0.436, 200.899)|(0.656, 4.348)|aceo|(1.675, 3.727)|
|1.167|0.234|0.654|3.746|0.676|0.400||
|(0.638, 2.133)|(0.058, 0.937)|(0.240, 1.780)|(0.170, 82.517)|(0.242, 1.887)|(0.268, 0.597)|Risedronato|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Fratura não vertebral** -->
A NMA foi composta por 15 estudos, os quais totalizaram 23.773 participantes. A Figura E demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem seis intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, placebo, risedronato), com 153 estimativas de efeito relativo (Quadro E).  
**Figura E** . NMA para fratura vertebral em pacientes com osteoporose.  
<!-- Start of picture text -->
risedronato Alendronatot0mg<br>®<br>Alendronato20mg<br>‘Aenaronate7/omgsemana<br><!-- End of picture text -->  
Ao considerar a NMA, o ácido zoledrônico não possui diferença significativa quando comparado aos demais tratamentos ou placebo.  
**Quadro E** . _League table_ fratura não vertebral em pacientes com osteoporose.  
|Ácido Zoledrônico|0.929|1.147|0.319|1.020|1.490|
|---|---|---|---|---|---|
|5 mg|(0.398, 2.168)|(0.457, 2.876)|(0.033, 3.125)|(0.644, 1.614)|(0.763, 2.909)|
|1.077|Alendronato|1.235|0.344|1.098|1.604|
|(0.461, 2.513)|10 mg|(0.424, 3.594)|(0.033, 3.587)|(0.539, 2.238)|(0.677, 3.800)|
|0.872|0.810|Alendronato|0.279|0.889|1.299|
|(0.348, 2.188)|(0.278, 2.358)|20 mg|(0.026, 2.985)|(0.401, 1.973)|(0.511, 3.304)|
|3.131|2.908|3.590|Alendronato|3.193|4.663|
|(0.320, 30.631)|(0.279, 30.332)|(0.335, 38.471)|70 mg semana|(0.342, 29.809)|(0.474, 45.883)|
|0.981|0.911|1.124|0.313||1.461|
|(0.619, 1.552)|(0.447, 1.857)|(0.507, 2.494)|(0.034, 2.924)|Placebo|(0.898, 2.376)|
|0.671|0.624|0.770|0.214|0.685||
|(0.344, 1.311)|(0.263, 1.478)|(0.303, 1.958)|(0.022, 2.110)|(0.421, 1.114)|Risedronato|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Densidade mineral óssea – Coluna vertebral** -->
A NMA foi composta por 48 estudos, os quais totalizaram 28.897 participantes. A Figura F demonstra a rede na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem 10 intervenções (alendronato 10 mg, alendronato 20 mg, placebo, alendronato 40 mg, alendronato 5 mg, alendronato 1 mg, alendronato 2,5 mg, alendronato 70 mg, risedronato, ácido zoledrônico 5 mg, pamidronato 150 mg, risedronato 35 mg, pamidronato 1x ano, pamidronato 4x ano ácido zoledrônico 2 mg), com 43 estimativas de efeito relativo (Quadro F).  
**Figura F** . NMA para densidade mineral óssea na coluna vertebral em pacientes com osteoporose.  
<!-- Start of picture text -->
sae =<br>//<br>/<br>/<br>/<br>/<br>/<br>pamaronato somgora / Aenaronstosomg<br>/<br>/<br>/<br>/<br>/<br>‘Acso024 AeraronsteTimaxemans<br>coed LL<br><!-- End of picture text -->  
Ao considerar a obtenção do desfecho de densidade mineral óssea para coluna, a NMA demonstrou que o ácido zoledrônico possui aumento de 4,646% (IC 95%: 1,252 - 8,040) quando comparado ao placebo e não possui diferença significativa quando comparado ao demais tratamentos.  
**Quadro F** . _League table_ densidade mineral óssea da coluna vertebral em pacientes com osteoporose.  
|Ácido|-0.186|-1.823|-1.248|0.503|-2.113|-1.654|-2.254|**4.646**|1.837|
|---|---|---|---|---|---|---|---|---|---|
|Zoledrônico|(-4.117,|(-6.675,|(-10.265,|(-4.730,|(-10.011,|(-12.542,|(-13.273,|**(1.252,**|(-2.699,|
|5mg|3.746)|3.029)|7.770)|5.737)|5.785)|9.234)|8.764)|**8.040)**|6.372)|
|0.186|Aldt|-1.638|-1.062|0.689|-1.928|-1.469|-2.069|4.831|2.022|
|(-3.746,|enrona<br>10|(-5.174,|(-9.427,|(-4.181,|(-9.336,|(-12.007,|(-12.742,|(2.827,|(-1.374,|
|4.117)|o  mg|1.899)|7.304)|5.559)|5.481)|9.069)|8.604)|6.836)|5.418)|
|1.823|1.638|Aldt|0.576|2.326|-0.290|0.169|-0.431|6.469|3.660|
|(-3.029,|(-1.899,|enronao<br>20|(-7.949,|(-3.344,|(-8.223,|(-10.744,|(-11.475,|(2.996,|(-0.903,|
|6.675)|5.174)|mg|9.100)|7.997)|7.643)|11.082)|10.612)|9.942)|8.222)|
|1.248|1.062|-0.576||1.751|-0.866|-0.407|-1.007|5.893|3.084|
|(-7.770,|(-7.304,|(-9.100,|Alendronato<br>|(-7.731,|(-11.852,|(-13.706,|(-14.413,|(-2.463,|(-5.776,|
|10.265)|9.427)|7.949)|40 mg|11.232)|10.120)|12.892)|12.399)|14.250)|11.944)|
|-0.503|-0.689|-2.326|-1.751|Alendronat<br>|-2.616|-2.158|-2.758|4.142|1.333|
|(-5.737,|(-5.559,|(-7.997,|(-11.232,|o<br>|(-11.059,|(-13.447,|(-14.173,|(-0.375,|(-3.559,|
|4.730)|4.181)|3.344)|7.731)|70 mg<br>semana|5.826)|9.131)|8.657)|8.660)|6.225)|
|2.113|1.928|0.290|0.866|2.616|Pidt|0.459|-0.141|6.759|3.950|
|(-5.785,|(-5.481,|(-7.643,|(-10.120,|(-5.826,|amronao<br>|(-12.107,|(-12.820,|(-0.373,|(-3.836,|
|10.011)|9.336)|8.223)|11.852)|11.059)|150 mg oral|13.024)|12.538)|13.891)|11.735)|
|1.654|1.469|-0.169|0.407|2.158|-0.459|Pidt|-0.600|6.300|3.491|
|(-9.234,|(-9.069,|(-11.082,|(-12.892,|(-9.131,|(-13.024,|amrona<br>|(-11.010,|(-4.045,|(-7.315,|
|12.542)|12.007)|10.744)|13.706)|13.447)|12.107)|o 1x ano|9.810)|16.645)|14.297)|
|2.254|2.069|0.431|1.007|2.758|0.141|0.600|i|6.900|4.091|
|(-8.764,|(-8.604,|(-10.612,|(-12.399,|(-8.657,|(-12.538,|(-9.810,|Pamdronat<br>|(-3.583,|(-6.847,|
|13.273)|12.742)|11.475)|14.413)|14.173)|12.820)|11.010)|o 4x ano|17.383)|15.029)|
|**-4.646**|-4.831|-6.469|-5.893|-4.142|-6.759|-6.300|-6.900|Placebo|-2.809|  
|**(-8.040, -**|(-6.836, -|(-9.942, -|(-14.250,|(-8.660,|(-13.891,|(-16.645,|(-17.383,||(-5.931,|
|---|---|---|---|---|---|---|---|---|---|
|**1.252)**|2.827)|2.996)|2.463)|0.375)|0.373)|4.045)|3.583)||0.313)|
|-1.837|-2.022|-3.660|-3.084|-1.333|-3.950|-3.491|-4.091|2.809||
|(-6.372,|(-5.418,|(-8.222,|(-11.944,|(-6.225,|(-11.735,|(-14.297,|(-15.029,|(-0.313,|Risedronato|
|2.699)|1.374)|0.903)|5.776)|3.559)|3.836)|7.315)|6.847)|5.931)||

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Densidade mineral óssea – Colo femoral** -->
A NMA foi composta por 39 estudos, os quais totalizaram 23.451 participantes. A Figura G demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem nove intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, pamidronato 150 mg oral, pamidronato 1x IV, pamidronato 4x IV, placebo, risedronato), com 153 estimativas de efeito relativo (Quadro G).  
**Figura G** . NMA para densidade mineral óssea no colo femoral em pacientes com osteoporose.  
<!-- Start of picture text -->
AcidaZoledronicosmg<br>sto10me<br>Alendopato20mg<br>pamidronatoxano AlendronitgFOmgsemana<br>pamidronatotane amidronato!SOmgoral<br><!-- End of picture text -->  
Ao considerar a obtenção do desfecho de densidade mineral óssea para colo femoral, a NMA demonstrou que o ácido zoledrônico possui aumento de 2,785% (IC95%: 0,086 - 5,484) quando comparado ao placebo e não possui diferença significativa quando comparado ao demais tratamentos.  
**Quadro G** . _League table_ densidade mineral óssea do colo femoral em pacientes com osteoporose.  
|Ácido<br>Zoledrônico<br>5mg|-0.079<br>(-3.177,<br>3.018)|-0.674<br>(-4.606,<br>3.257)|0.756<br>(-4.146,<br>5.659)|4.595<br>(-3.019,<br>12.209)|-1.515<br>(-9.708,<br>6.678)|-1.515<br>(-9.720,<br>6.689)|**2.785**<br>**(0.086, 5.484)**|1.648<br>(-2.033,<br>5.328)|
|---|---|---|---|---|---|---|---|---|
|0.079<br>(-3018 3177)|Alendronato<br>10 mg|-0.595<br>(-3.454,|0.836<br>(-3.436,|4.674<br>(-2.606,|-1.436<br>(-9.319,|-1.436<br>(-9.331,|2.864<br>(1344 4384)|1.727<br>(-0.910,|
|., .||2.264)|5.107)|11.954)|6.448)|6.460)|., .|4.364)|
|0674|0.595|Alendronato|1.431|5.269|-0.841|-0.841|3459|2.322|
|.<br>3257 4606|(-2.264,|<br>20|(-3.521,|(-2.403,|(-9.088,|(-9.099,|.<br>0600 6318|(-1.369,|
|(-., .)|3.454)|mg|6.382)|12.941)|7.406)|7.418)|(., .)|6.013)|
|0756|-0.836|-1.431|Alndrnt|3.839|-2.271|-2.271|2.029|0.891|
|-.<br>5659 4146|(-5.107,|(-6.382,|eoao<br>70|(-4.373,|(-11.023,|(-11.034,|(-2.064,|(-3.201,|
|(-., .)|3.436)|3.521)|mg semana|12.050)|6.480)|6.491)|6.121)|4.984)|
|-4595|-4.674|-5.269|-3.839|Pamidronato|-6.110|-6.110|-1.810|-2.947|
|.<br>|(-11.954,|(-12.941,|(-12.050,|<br>|(-16.623,|(-16.632,|(-8.929,|(-10.493,|
|(-12.209, 3.019)|2.606)|2.403)|4.373)|150 mg oral|4.403)|4.412)|5.309)|4.599)|
|1515|1.436|0.841|2.271|6.110|Pidt|0.000|4.300|3.163|
|.<br>(-6678 9708)|(-6.448,|(-7.406,|(-6.480,|(-4.403,|amronao<br>1x ano|(-7.411,|(-3.436,|(-4.967,|
|., .|9.319)|9.088)|11.023)|16.623)||7.411)|12.036)|11.293)|
|1515|1.436|0.841|2.271|6.110|0.000|Pamidronato|4.300|3.163|
|.<br>(-6689 9720)|(-6.460,|(-7.418,|(-6.491,|(-4.412,|(-7.411,|<br>4x ano|(-3.448,|(-4.979,|
|., .|9.331)|9.099)|11.034)|16.632)|7.411)||12.048)|11.305)|
||-2.864|-3.459|-2.029|1.810|-4.300|-4.300||-1.137|
|**-2.785**<br>|(-4.384, -|(-6.318, -|(-6.121,|(-5.309,|(-12.036,|(-12.048,|Placebo|(-3.639,|
|**(-5.484, -0.086)**|1.344)|0.600)|2.064)|8.929)|3.436)|3.448)||1.365)|
|-1.648<br>(-5.328, 2.033)|-1.727|-2.322|-0.891|2.947|-3.163|-3.163|1.137|Risedronato|  
|(-4.364,|(-6.013,|(-4.984,|(-4.599,|(-11.293,|(-11.305,|(-1.365,|
|---|---|---|---|---|---|---|
|0.910)|1.369)|3.201)|10.493)|4.967)|4.979)|3.639)|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Densidade mineral óssea – Quadril** -->
A NMA foi composta por 32 estudos, os quais totalizaram 24.434 participantes. A Figura H demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem nove intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, pamidronato 150 mg oral, pamidronato 1x IV, pamidronato 4x IV, placebo, risedronato), com 153 estimativas de efeito relativo (Quadro H).  
**Figura H** . NMA para densidade mineral óssea no quadril em pacientes com osteoporose.  
<!-- Start of picture text -->
AcidaZeledroncasing<br>raedronato<br>106<br>Pracebo Alendronato20 79<br>pamidrontosxano \ ‘Aendronatodome<br>pamidronato1xano ‘Aenaronity7omesemana<br><!-- End of picture text -->  
Ao considerar a obtenção do desfecho de densidade mineral óssea para quadril, a NMA demonstrou que o ácido zoledrônico possui aumento de 3,730% (IC95%: 1,244 - 6,216) quando comparado ao placebo e não possui diferença significativa quando comparado ao demais tratamentos.  
**Quadro H** . _League table_ densidade mineral óssea do quadril em pacientes com osteoporose.  
|Ácido<br>Zoledrônico<br>5 mg|0.634<br>(-2.330,<br>3.598)|-0.034<br>(-3.939,<br>3.872)|0.403<br>(-5.647,<br>6.453)|1.526<br>(-2.645,<br>5.697)|0.530<br>(-7.001, 8.062)|-1.070<br>(-8.526,<br>6.386)|**3.730**<br>**(1.244, 6.216)**|2.472<br>(-1.341,<br>6.284)|
|---|---|---|---|---|---|---|---|---|
|-0.634<br>(-3.598, 2.330)|Alendronato<br>10 mg|-0.667<br>(-3.765,<br>2.430)|-0.231<br>(-5.763,<br>5.301)|0.892<br>(-2.682,<br>4.466)|-0.104<br>(-7.394, 7.187)|-1.704<br>(-8.916,<br>5.509)|3.096<br>(1.482, 4.710)|1.838<br>(-1.031,<br>4.706)|
|0.034<br>|0.667<br>(-2.430,|Alendronato<br>|0.436<br>(-5.287,|1.560<br>(-2.898,|0.564<br>|-1.036<br>(-8.684,|3.764<br>|2.505<br>(-1.537,|
|(-3.872, 3.939)|3.765)|20 mg|6.160)|6.017)|(-7.158, 8.285)|6.611)|(0.751, 6.776)|6.547)|
|-0.403<br>(-6.453, 5.647)|0.231<br>(-5.301,<br>5.763)|-0.436<br>(-6.160,<br>5.287)|Alendronato<br>40 mg|1.123<br>(-5.292,<br>7.538)|0.127<br>(-8.871, 9.125)|-1.473<br>(-10.409,<br>7.462)|3.327<br>(-2.189, 8.843)|2.068<br>(-4.056,<br>8.193)|
|-1.526<br>|-0.892<br>(-4.466,|-1.560<br>(-6.017,|-1.123<br>(-7.538,|Alendronato<br>|-0.996<br>|-2.596<br>(-10.383,|2.204<br>|0.946<br>(-2.680,|
|(-5.697, 2.645)|2.682)|2.898)|5.292)|70 mg semana|(-8.855, 6.863)|5.191)|(-1.145, 5.553)|4.571)|
|0530|0.104|-0.564|-0.127|0.996|Pidt|-1.600|3.200|1.942|
|-.<br>(8062 7001)|(-7.187,|(-8.285,|(-9.125,|(-6.863,|amronao<br>1 n|(-8.851,|(-3.909,|(-5.733,|
|-., .|7.394)|7.158)|8.871)|8.855)|x ao|5.651)|10.309)|9.616)|
|1.070<br>|1.704<br>(-5.509,|1.036<br>(-6.611,|1.473<br>(-7.462,|2.596<br>(-5.191,|1.600<br>|Pamidronato<br>|4.800<br>(-2.230,|3.542<br>(-4.059,|
|(-6.386, 8.526)|8.916)|8.684)|10.409)|10.383)|(-5.651, 8.851)|4x ano|11.830)|11.142)|
||-3.096|-3.764|-3.327|-2.204|-3.200|-4.800||-1.258|
|**-3.730**<br>|(-4.710, -|(-6.776, -|(-8.843,|(-5.553,|(-10.309,|(-11.830,|Placebo|(-4.149,|
|**(-6.216, -1.244)**|1.482)|0.751)|2.189)|1.145)|3.909)|2.230)||1.632)|
|-2.472<br>(-6.284, 1.341)|-1.838|-2.505|-2.068|-0.946|-1.942<br>(-9.616, 5.733)|-3.542|1.258<br>(-1.632, 4.149)|Risedronato|  
|(-4.706,|(-6.547,|(-8.193,|(-4.571,|(-11.142,|
|---|---|---|---|---|
|1.031)|1.537)|4.056)|2.680)|4.059)|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Densidade mineral óssea – Trocanter** -->
A NMA foi composta por 32 estudos, os quais totalizaram 18.888 participantes. A Figura I demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem oito intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, pamidronato 150 mg oral, pamidronato 1x IV, pamidronato 4x IV, placebo, risedronato), com 153 estimativas de efeito relativo (Quadro I).  
**Figura I** . NMA para densidade mineral óssea no trocanter em pacientes com osteoporose.  
<!-- Start of picture text -->
_ eo<br><!-- End of picture text -->  
Ao considerar a obtenção do desfecho de densidade mineral óssea para trocanter, a NMA demonstrou que o ácido zoledrônico não possui diferença significativa quando comparado ao demais tratamentos e ao placebo.  
45  
**Quadro I** . _League table_ densidade mineral óssea do trocanter em pacientes com osteoporose.  
|Ácido zoledrônico 5 mg|0.791<br>(-7.340, 8.922)|0.939<br>(-7.798, 9.677)|1.438<br>(-8.006, 10.882)|1.725<br>(-12.332,<br>15.782)|-1.975<br>(-16.338,<br>12.388)|4.525<br>(-3.192,<br>12.242)|2.081<br>(-6.524,<br>10.686)|
|---|---|---|---|---|---|---|---|
|-0.791<br>(-8.922, 7.340)|Alendronato 10<br>mg|0.148<br>(-4.053, 4.348)|0.647<br>(-5.222, 6.516)|0.934<br>(-11.092,<br>12.959)|-2.766<br>(-15.147,<br>9.614)|3.734<br>(1.173, 6.294)|1.290<br>(-2.774,<br>5.354)|
|-0.939<br>(-9.677, 7.798)|-0.148<br>(-4.348, 4.053)|Alendronato 20 mg|0.499<br>(-6.258, 7.256)|0.786<br>(-11.658,<br>13.229)|-2.914<br>(-15.701,<br>9.873)|3.586<br>(-0.511,<br>7.683)|1.142<br>(-4.271,<br>6.556)|
|-1.438<br>(-10.882, 8.006)|-0.647<br>(-6.516, 5.222)|-0.499<br>(-7.256, 6.258)|Alendronato 70<br>mg<br>semana|0.287<br>(-12.662,<br>13.236)|-3.413<br>(-16.693,<br>9.867)|3.087<br>(-2.357,<br>8.530)|0.643<br>(-5.099,<br>6.386)|
|-1.725<br>(-15.782, 12.332)|-0.934<br>(-12.959, 11.092)|-0.786<br>(-13.229, 11.658)|-0.287<br>(-13.236, 12.662)|Pamidronato<br>1x ano|-3.700<br>(-15.713,<br>8.313)|2.800<br>(-8.950,<br>14.550)|0.356<br>(-11.994,<br>12.707)|
|1.975<br>(-12.388, 16.338)|2.766<br>(-9.614, 15.147)|2.914<br>(-9.873, 15.701)|3.413<br>(-9.867, 16.693)|3.700<br>(-8.313,<br>15.713)|Pamidronato<br>4x ano|6.500<br>(-5.613,<br>18.613)|4.056<br>(-8.641,<br>16.753)|
|-4.525<br>(-12.242, 3.192)|-3.734<br>(-6.294, -1.173)|-3.586<br>(-7.683, 0.511)|-3.087<br>(-8.530, 2.357)|-2.800<br>(-14.550,<br>8.950)|-6.500<br>(-18.613,<br>5.613)|Placebo|-2.444<br>(-6.250,<br>1.363)|
|-2.081<br>(-10.686, 6.524)|-1.290<br>(-5.354, 2.774)|-1.142<br>(-6.556, 4.271)|-0.643<br>(-6.386, 5.099)|-0.356<br>(-12.707,<br>11.994)|-4.056<br>(-16.753,<br>8.641)|2.444<br>(-1.363,<br>6.250)|Risedronato|  
46

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Evento adverso** -->
A NMA foi composta por 46 estudos, os quais totalizaram 23.605 participantes. A Figura J demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem oito intervenções (Ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, pamidronato 150 mg oral, pamidronato 1x IV, pamidronato 4x IV, placebo, risedronato), com 153 estimativas de efeito relativo (Quadro J).  
**Figura J** . NMA para evento adverso em pacientes com osteoporose.  
<!-- Start of picture text -->
acres<br>panisortosane enenatzing<br>\<br>\<br>\<br>\<br>\<br>ponitonso ano<br>paz oA<br><!-- End of picture text -->  
Ao considerar a NMA, o ácido zoledrônico possui maior risco para a ocorrência de eventos adversos quando comparado ao alendronato 70 mg de uso semanal (RR: 1,093; IC95% 1,009 – 1,184) e placebo (RR: 1,048; IC95%: 1,017 – 1,080).  
47  
**Quadro J** . _League table_ de eventos adversos em pacientes com osteoporose.  
|Ácido Zoledrônico|1.028|1.030|**1.093**|1.048|1.048|**1.048**|1.040|
|---|---|---|---|---|---|---|---|
|5 mg|(0.985, 1.073)|(0.964, 1.101)|**(1.009, 1.184)**|(0.023, 47.613)|(0.023, 47.613)|**(1.017, 1.080)**|(0.991, 1.092)|
|0.973|Alendronato|1.002|1.063|1.019|1.019|1.019|1.012|
|(0.932, 1.015)|10 mg|(0.945, 1.062)|(0.980, 1.153)|(0.022, 46.312)|(0.022, 46.312)|(0.989, 1.051)|(0.972, 1.054)|
|0.971|0.998|Alendronato|1.061|1.017|1.017|1.017|1.010|
|(0.908, 1.037)|(0.941, 1.058)|20 mg|(0.964, 1.168)|(0.022, 46.238)|(0.022, 46.238)|(0.959, 1.079)|(0.944, 1.080)|
|**0.915**|0.941|0.942|Alendronato|0.959|0.959|0.959|0.952|
|**(0.845, 0.991)**|(0.867, 1.020)|(0.856, 1.037)|70 mg semana|(0.021, 43.584)|(0.021, 43.584)|(0.888, 1.035)|(0.878, 1.031)|
|0.954|0.981|0.983|1.043|Pamidronato|1.000|1.000|0.993|
|(0.021, 43.341)|(0.022, 44.563)|(0.022, 44.661)|(0.023, 47.408)|1x ano|(0.022, 45.422)|(0.022, 45.422)|(0.022, 45.092)|
|0.954|0.981|0.983|1.043|1.000|Pamidronato|1.000|0.993|
|(0.021, 43.341)|(0.022, 44.563)|(0.022, 44.661)|(0.023, 47.408)|(0.022, 45.422)|4x ano|(0.022, 45.422)|(0.022, 45.092)|
|**0.954**|0.981|0.983|1.043|1.000|1.000||0.993|
|**(0.926, 0.983)**|(0.951, 1.011)|(0.926, 1.043)|(0.966, 1.126)|(0.022, 45.422)|(0.022, 45.422)|Placebo|(0.955, 1.031)|
|0.961|0.988|0.990|1.051|1.008|1.008|1.008||
|(0.916, 1.009)|(0.949, 1.029)|(0.926, 1.059)|(0.970, 1.138)|(0.022, 45.769)|(0.022, 45.769)|(0.969, 1.047)|Risedronato|  
48

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Evento adverso grave** -->
A NMA foi composta por 39 estudos, os quais totalizaram 26.296 participantes. A Figura K demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem seis intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, placebo, risedronato), com 153 estimativas de efeito relativo (Quadro K).  
**Figura K** . NMA para evento adverso grave em pacientes com osteoporose.  
Ao considerar a NMA, o ácido zoledrônico possui maior risco para a ocorrência de eventos adversos quando comparado ao alendronato 70 mg de uso semanal (RR: 1,577; IC95%: 1,020 – 2,438).  
49  
**Quadro K** . _League table_ de evento adverso grave em pacientes com osteoporose.  
|Ácido Zoledrônico|1.044|0.972|**1.577**|0.984|0.960|
|---|---|---|---|---|---|
|5 mg|(0.834, 1.306)|(0.746, 1.267)|**(1.020, 2.438)**|(0.847, 1.143)|(0.753, 1.224)|
|0.958|Alendronato|0.931|1.511|0.942|0.920|
|(0.766, 1.199)|10 mg|(0.720, 1.205)|(0.977, 2.337)|(0.797, 1.114)|(0.749, 1.130)|
|1.029|1.074|Alendronato|1.622|1.012|0.988|
|(0.789, 1.341)|(0.830, 1.389)|20 mg|(1.021, 2.577)|(0.813, 1.259)|(0.744, 1.313)|
|**0.634**|0.662|0.616|Alendronato|0.624|0.609|
|**(0.410, 0.981)**|(0.428, 1.024)|(0.388, 0.980)|70 mg semana|(0.414, 0.939)|(0.395, 0.939)|
|1.017|1.061|0.988|1.603||0.976|
|(0.875, 1.181)|(0.898, 1.254)|(0.794, 1.230)|(1.065, 2.413)|Placebo|(0.806, 1.182)|
|1.041|1.087|1.012|1.642|1.024||
|(0.817, 1.328)|(0.885, 1.335)|(0.762, 1.345)|(1.065, 2.531)|(0.846, 1.240)|Risedronato|  
50

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Evento adverso gastrointestinal** -->
A NMA foi composta por 39 estudos, os quais totalizaram 26.413 participantes. A Figura L demonstra a rede, na qual o tamanho dos nós representa o número de estudos e a espessura das linhas representa o tamanho da amostra. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, existem sete intervenções (ácido zoledrônico 5 mg, alendronato 10 mg, alendronato 20 mg, alendronato 70 mg semana, placebo, risedronato), com 153 estimativas de efeito relativo (Quadro L).  
**Figura L** . NMA para evento adverso gastrointestinal em pacientes com osteoporose.  
<!-- Start of picture text -->
‘Ntendronato10mg<br>we<br>~—<br>"Reendronato20mg<br>pamidronato150mgoral ~S<br>acidozoledronicosmg ~<br>isedp<<br><!-- End of picture text -->  
Ao considerar a NMA, o ácido zoledrônico não possui maior risco para a ocorrência de eventos adversos gastrointestinais.  
51  
**Quadro L** . _League table_ de evento adverso gastrointestinal em pacientes com osteoporose.  
|Ácido Zoledrônico|1.445|1.615|1.781|1.507|1.593|1.581|
|---|---|---|---|---|---|---|
|5mg|(0.791, 2.641)|(0.872, 2.989)|(0.949, 3.342)|(0.675, 3.361)|(0.876, 2.898)|(0.859, 2.909)|
|0.692|Alendronato|1.118|1.233|1.043|1.103|1.094|
|(0.379, 1.265)|10 mg|(0.952, 1.312)|(0.969, 1.569)|(0.607, 1.791)|(1.018, 1.194)|(0.964, 1.242)|
|0.619|0.895|Alendronato|1.103|0.933|0.987|0.979|
|(0.335, 1.146)|(0.762, 1.050)|20 mg|(0.839, 1.451)|(0.536, 1.625)|(0.852, 1.144)|(0.809, 1.185)|
|0.561|0.811|0.907|Alendronato|0.846|0.895|0.888|
|(0.299, 1.053)|(0.638, 1.032)|(0.689, 1.192)|70 mg semana|(0.472, 1.515)|(0.710, 1.128)|(0.696, 1.132)|
|0.664|0.959|1.072|1.182|Pamidronato|1.058|1.050|
|(0.298, 1.481)|(0.558, 1.647)|(0.615, 1.867)|(0.660, 2.118)|150 mg oral|(0.620, 1.806)|(0.606, 1.818)|
|0.628|0.907|1.013|1.118|0.945|Plb|0.992|
|(0.345, 1.141)|(0.837, 0.982)|(0.874, 1.174)|(0.886, 1.409)|(0.554, 1.614)|aceo|(0.875, 1.125)|
|0.632|0.914|1.021|1.126|0.953|1.008||
|(0.344, 1.164)|(0.805, 1.037)|(0.844, 1.236)|(0.884, 1.436)|(0.550, 1.650)|(0.889, 1.142)|Risedronato|  
52

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **D) Avaliação do risco de viés** -->
De modo geral, os estudos apresentaram algumas preocupações. No total, 15 estudos apresentaram baixo viés global; 30, algumas preocupações e 25, alto risco de viés. Os principais motivos para redução foram randomização, desvio das intervenções pretendidas, dados perdidos e mensuração do desfecho. A avaliação de cada estudo está descrita no Quadro M.  
**Quadro M.** Sumário da avaliação do risco de viés dos ECR por meio da ferramenta Rob2.  
|**Estudo**|**Randomização**|**Desvio das**<br>**intervenções**<br>**pretendidas**|**Dados**<br>**perdid**<br>**os**|**Mensuraçã**<br>**o do**<br>**desfecho**|**Seleção**<br>**do**<br>**resultad**<br>**o**<br>**relatado**|**Viés**<br>**glob**<br>**al**|
|---|---|---|---|---|---|---|
|Adachi 2009<sup>(14)</sup>|||||||
|Adami 1993<sup>(15)</sup>|||||||
|Adami 1995<sup>(16)</sup>|||||||
|Ascott-Evans<br>2003<sup>(17)</sup>|||||||
|Bai 2013<sup>(18)</sup>|||||||
|Bauer 2000<sup>(19)</sup>|||||||
|Bell 2002<sup>(20)</sup>|||||||
|Black 2015<sup>(21)</sup>|||||||
|Bone 2000<sup>(22)</sup>|||||||
|Bonnick 2006<sup>(23)</sup>|||||||
|Bonnick 2007<sup>(24)</sup>|||||||
|Boonen 2009<sup>(25)</sup>|||||||
|Boonen 2012<sup>(26)</sup>|||||||
|Boutsen 2001<sup>(27)</sup>|||||||
|Brumsen 2002<sup>(28)</sup>|||||||
|Chao 2013<sup>(29)</sup>|||||||
|Chesnut 1995<sup>(30)</sup>|||||||
|Chevrel 2006<sup>(31)</sup>|||||||
|Clemmesen<br>1997<sup>(32)</sup>|||||||
|Cryer 2005<sup>(33)</sup>|||||||
|Devogelaer<br>1996<sup>(34)</sup>|||||||
|Downs 2000<sup>(35)</sup>|||||||
|Eastell 2011<sup>(36)</sup>|||||||
|Eisman 2004<sup>(37)</sup>|||||||
|FIT I 1996<sup>(38)</sup>|||||||
|FIT II 1998<sup>(39)</sup>|||||||  
53  
|**Estudo**|**Randomização**|**Desvio das**<br>**intervenções**<br>**pretendidas**|**Dados**<br>**perdid**<br>**os**|**Mensuraçã**<br>**o do**<br>**desfecho**|**Seleção**<br>**do**<br>**resultad**<br>**o**<br>**relatado**|**Viés**<br>**glob**<br>**al**|
|---|---|---|---|---|---|---|
|Fogelman 2000<sup>(40)</sup>|||||||
|FOSIT 1999<sup>(41)</sup>|||||||
|Greenspan<br>1998<sup>(42)</sup>|||||||
|Greenspan<br>2002<sup>(43)</sup>|||||||
|Greenspan<br>2003<sup>(44)</sup>|||||||
|Greenspan et al<br>2015<sup>(45)</sup>|||||||
|HIP 2001<sup>(46)</sup>|||||||
|HORIZON-<br>PFT<sup>(47, 48)</sup>|||||||
|Hosking 2003<sup>(49)</sup>|||||||
|Huang 2017<sup>(50)</sup>|||||||
|Hwang<br>et<br>al<br>2011<sup>(51)</sup>|||||||
|Ilter 2006<sup>(52)</sup>|||||||
|Ito 2018<sup>(53)</sup>|||||||
|Johnnell 2002<sup>(54)</sup>|||||||
|Kalder 2015<sup>(55)</sup>|||||||
|Kung 2000<sup>(56)</sup>|||||||
|Lau 2000<sup>(57)</sup>|||||||
|Lems 2006<sup>(58)</sup>|||||||
|Leung 2005<sup>(59)</sup>|||||||
|Lewiecki 2007<sup>(60)</sup>|||||||
|Liang 2017<sup>(61)</sup>|||||||
|Lindsay 1999<sup>(62)</sup>|||||||
|McClung 1998<sup>(63)</sup>|||||||
|McClung 2006<sup>(64)</sup>|||||||
|McClung 2007<sup>(65)</sup>|||||||
|McClung 2009<sup>(66)</sup>|||||||
|Milller 2004<sup>(67)</sup>|||||||
|Murphy 2001<sup>(68)</sup>|||||||  
54  
|**Estudo**|**Randomização**|**Desvio das**<br>**intervenções**<br>**pretendidas**|**Dados**<br>**perdid**<br>**os**|**Mensuraçã**<br>**o do**<br>**desfecho**|**Seleção**<br>**do**<br>**resultad**<br>**o**<br>**relatado**|**Viés**<br>**glob**<br>**al**|
|---|---|---|---|---|---|---|
|Nakamura2017<sup>(69)</sup>|||||||
|Orwoll 2000<sup>(70)</sup>|||||||
|Orwoll 2010<sup>(71)</sup>|||||||
|Paggiosi 2014<sup>(72)</sup>|||||||
|Palomba 2002<sup>(73)</sup>|||||||
|Reid 1994<sup>(74)</sup>|||||||
|Reid 2002<sup>(75)</sup>|||||||
|Reid 2008<sup>(76)</sup>|||||||
|Rosen 2005<sup>(77)</sup>|||||||
|Saag 1998<sup>(78)</sup>|||||||
|Saag 2007<sup>(79)</sup>|||||||
|Shiraki 2003<sup>(80)</sup>|||||||
|Stoch 2009<sup>(81)</sup>|||||||
|Tucci 1996<sup>(82)</sup>|||||||
|VERT-MN<br>2000<sup>(83)</sup>|||||||
|VERT-NA<br>1999<sup>(84)</sup>|||||||  
Legenda: = baixo risco; = alto risco; = algumas preocupações.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **E) Avaliação da certeza na evidência** -->
Os Quadros N a W descrevem a avaliação da certeza da evidência por desfecho.  
55  
**Quadro N** . Avaliação geral da evidência – fratura geral.  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés de**<br>**publicação**|**Evidência**<br>**indireta**|**Impreci**<br>**são**|**Heterogeneida**<br>**de**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Placebo|9|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - Placebo|15|AP|BR|NP|NP|GP|GP|Muito<br>Baixo|
|Alendronato 10 mg - Risedronato|1|AP|BR|NP|GP|NP|GP|Muito<br>Baixo|
|Alendronato 20 mg - Placebo|1|NP|BR|NP|GP|NP|NP|Moderado|
|Alendronato 70 mg semana - Placebo|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - risedronato|1|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 150 mg oral - Placebo|1|AP|BR|NP|NP|GP|NP|Baixo|
|Placebo - risedronato|7|AP|BR|NP|NP|NP|GP|Baixo|
|Ácido Zoledrônico 5 mg – Alendronato 10 mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido zoledrônico 5 mg – Alendronato 20 mg|0|NP|BR|NP|GP|NP|NP|Moderado|
|Ácido Zoledrônico 5 mg – Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg – Pamidronato 150 mg<br>oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg – risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg – Alendronato 20 mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg – Alendronato 70 mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg – pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg – Alendronato 70 mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|  
56  
|**Comparações**|**n**<br>**Viés**<br>**do**<br>**estudo**|**Viés de**<br>**publicação**|**Evidência**<br>**indireta**|**Impreci**<br>**são**|**Heterogeneida**<br>**de**|**Incoerência**|**Avaliação**<br>**Final**|
|---|---|---|---|---|---|---|---|
|Alendronato 70 mg semana – pamidronato 150<br>mg oral|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 150 mg oral - risedronato|0<br>AP|BR|NP|GP|NP|NP|Baixo|  
Legenda: NP: nenhuma preocupação; AP: Algumas preocupações; GP: Grandes preocupações; BR: Baixo risco  
57  
**Quadro O** . Avaliação geral da evidência – fratura vertebral.  
|**Comparações**|**n**|**Viés do**<br>**estudo**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato 10 mg - Placebo|3|GP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 20 mg - Placebo|1|NP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 70 mg semana - Placebo|2|AP|BR|NP|GP|NP|GP|Muito baixo|
|Pamidronato 150 mg oral - Placebo|1|AP|BR|NP|GP|NP|GP|Muito baixo|
|Placebo - risedronato|4|AP|BR|NP|NP|NP|GP|Baixo|
|Ácido Zoledrônico 5mg - Alendronato 10<br>mg|0|AP|BR|NP|NP|GP|GP|Muito baixo|
|Ácido Zoledrônico 5mg - Alendronato 20<br>mg|0|NP|BR|NP|GP|NP|GP|Muito baixo|
|Ácido Zoledrônico 5mg - Alendronato 70<br>mg semana|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Ácido Zoledrônico 5mg - pamidronato<br>150 mg oral|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Ácido Zoledrônico 5 mg - risedronato|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - Alendronato 20 mg|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - Alendronato 70 mg<br>semana|0|GP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - pamidronato 150 mg<br>oral|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - risedronato|0|AP|BR|NP|NP|GP|GP|Muito baixo|
|Alendronato 20 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 20 mg - pamidronato 150 mg<br>oral|0|AP|BR|NP|GP|NP|GP|Muito baixo|  
58  
|**Comparações**|**n**|**Viés do**<br>**estudo**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato 20 mg - risedronato|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 70 mg semana - pamidronato<br>150 mg oral|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 70 mg semana - risedronato|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Pamidronato 150 mg oral - risedronato|0|AP|BR|NP|GP|NP|GP|Muito baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP -  Grandes preocupações; BR -  Baixo risco  
59  
**Quadro P** . Avaliação geral da evidência – fratura não vertebral.  
|**Comparações**|**n**|**Viés do**<br>**estudo**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Placebo|5|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - Placebo|3|GP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 20 mg - Placebo|1|NP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 70 mg semana -<br>Placebo|2|AP|BR|NP|GP|NP|GP|Muito baixo|
|Placebo - risedronato|4|AP|BR|NP|GP|NP|GP|Muito baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>Alendronato 10 mg|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>Alendronato 20 mg|0|NP|BR|NP|GP|NP|GP|Muito baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>Alendronato 70 mg semana|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>risedronato|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - Alendronato<br>20 mg|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - Alendronato<br>70 mg semana|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 10 mg - risedronato|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 20 mg - Alendronato<br>70 mg semana|0|AP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 20 mg - risedronato|0|NP|BR|NP|GP|NP|GP|Muito baixo|
|Alendronato 70 mg semana -<br>risedronato|0|AP|BR|NP|GP|NP|GP|Muito baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP -  Grandes preocupações; BR -  Baixo risco  
60  
**Quadro Q** . Avaliação geral da evidência – densidade mineral óssea da coluna vertebral  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg -<br>Alendronato 70 mg semana|1|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg -<br>Placebo|8|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato<br>10<br>mg<br>-<br>Alendronato 20 mg|6|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>10<br>mg<br>-<br>Alendronato 40 mg|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 10 mg - Placebo|2<br>2|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato<br>10<br>mg<br>-<br>risedronato|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato<br>20<br>mg<br>-<br>Alendronato 40 mg|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 20 mg - Placebo|7|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 40 mg - Placebo|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 70 mg semana -<br>Placebo|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana -<br>risedronato|2|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 150 mg oral -<br>Placebo|2|AP|BR|NP|GP|NP|NP|Baixo|  
61  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Pamidronato 1 x ano - Placebo|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato 4 x ano - Placebo|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Placebo - risedronato|7|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato<br>1<br>x<br>ano<br>-<br>pamidronato 4 x ano|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Ácido Zoledrônico 5 mg -<br>Alendronato 10 mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg -<br>Alendronato 20 mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg -<br>Alendronato 40 mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg -<br>pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg -<br>pamidronato  1 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg -<br>pamidronato 4 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg -<br>risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato<br>10<br>mg<br>-<br>Alendronato 70 mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato<br>10<br>mg<br>-<br>pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|  
62  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato<br>10<br>mg<br>-<br>pamidronato  1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>10<br>mg<br>-<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>20<br>mg<br>-<br>Alendronato 70 mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato<br>20<br>mg<br>-<br>pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato<br>20<br>mg<br>-<br>pamidronato  1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>20<br>mg<br>-<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>20<br>mg<br>-<br>risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato<br>40<br>mg<br>-<br>Alendronato 70 mg semana|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>40<br>mg<br>-<br>pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato<br>40<br>mg<br>-<br>pamidronato 1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>40<br>mg<br>-<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato<br>40<br>mg<br>-<br>risedronato|0|GP|BR|NP|GP|NP|NP|Muito baixo|  
63  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato 70 mg semana -<br>pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana -<br>pamidronato  1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 70 mg semana -<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato 150 mg oral -<br>pamidronato  1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato 150 mg oral -<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato 150 mg oral -<br>risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato<br>1<br>x<br>ano<br>-<br>risedronato|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato<br>4<br>x<br>ano<br>-<br>risedronato|0|GP|BR|NP|GP|NP|NP|Muito baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP - Grandes preocupações; BR -  Baixo risco  
64  
**Quadro R** . Avaliação geral da evidência – densidade mineral óssea do colo femoral  
|**Comparações**|**n**|**Viés do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Placebo|7|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - Alendronato<br>20 mg|5|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 10 mg - Placebo|19|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - risedronato|3|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 20 mg - Placebo|5|GP|BR|NP|NP|GP|NP|Muito<br>baixo|
|Alendronato 70 mg semana -<br>Placebo|2|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana -<br>risedronato|2|AP|BR|NP|GP|NP|NP|Baixo|
|pamidronato 150 mg oral -<br>Placebo|1|AP|BR|NP|GP|NP|NP|Baixo|
|pamidronato  1 x ano - Placebo|1|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|pamidronato 4 x ano - Placebo|1|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Placebo - risedronato|5|AP|BR|NP|GP|NP|NP|Baixo|
|pamidronato<br>1<br>x<br>ano<br>-<br>pamidronato 4 x ano|1|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>Alendronato 10 mg|0|AP|BR|NP|GP|NP|NP|Baixo|  
65  
|**Comparações**|**n**|**Viés do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>Alendronato 20 mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>Alendronato 70 mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>pamidronato  1 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Ácido<br>Zoledrônico<br>5<br>mg<br>-<br>risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Alendronato<br>70 mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - pamidronato<br>150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - pamidronato<br>1 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 10 mg - pamidronato<br>4 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 20 mg - Alendronato<br>70 mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - pamidronato<br>150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|  
66  
|**Comparações**|**n**|**Viés do**<br>**estudo**|**Viés**<br>**de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato 20 mg - pamidronato<br>1 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 20 mg - pamidronato<br>4 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 20 mg - risedronato|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 70 mg semana -<br>pamidronato 150 mg oral|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana -<br>pamidronato 1 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 70 mg semana -<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Pamidronato 150 mg oral -<br>pamidronato 1 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Pamidronato 150 mg oral -<br>pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Pamidronato 150 mg oral -<br>risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 1 x ano - risedronato|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Pamidronato 4 x ano - risedronato|0|GP|BR|NP|GP|NP|NP|Muito<br>baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP -  Grandes preocupações; BR -  Baixo risco  
67  
**Quadro S** . Avaliação geral da evidência – densidade mineral óssea do quadril  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Placebo|7|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - Alendronato 20 mg|3|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 10 mg - Alendronato 40 mg|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 10 mg - Placebo|1<br>4|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - risedronato|3|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 20 mg - Alendronato 40 mg|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 20 mg - Placebo|4|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 40 mg - Placebo|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 70 mg semana - Placebo|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - risedronato|2|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato  1 x ano - Placebo|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato 4 x ano - Placebo|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Placebo - risedronato|2|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato  1 x ano - pamidronato 4 x ano|1|GP|BR|NP|GP|NP|NP|Muito baixo|
|Ácido Zoledrônico 5 mg - Alendronato 10<br>mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 20<br>mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 40<br>mg|0|AP|BR|NP|GP|NP|NP|Baixo|  
68  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Alendronato 70<br>mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - pamidronato 1 x<br>ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Ácido Zoledrônico 5 mg - pamidronato 4 x<br>ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Ácido Zoledrônico 5 mg - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - pamidronato  1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 10 mg - pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 20 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - pamidronato  1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 20 mg - pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 20 mg - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 40 mg - Alendronato 70 mg<br>semana|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 40 mg - pamidronato 1 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 40 mg - pamidronato 4 x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 40 mg - risedronato|0|GP|BR|NP|GP|NP|NP|Muito baixo|
|Alendronato 70 mg semana - pamidronato 1<br>x ano|0|GP|BR|NP|GP|NP|NP|Muito baixo|  
69  
|**Comparações**|**n**<br>**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|
|Alendronato 70 mg semana - pamidronato 4<br>x ano|0<br>GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato 1 x ano - risedronato|0<br>GP|BR|NP|GP|NP|NP|Muito baixo|
|Pamidronato 4 x ano - risedronato|0<br>GP|BR|NP|GP|NP|NP|Muito baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP - Grandes preocupações; BR - Baixo risco  
70  
**Quadro T** . Avaliação geral da evidência – densidade mineral óssea do trocanter.  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato 10 mg - Alendronato 20 mg|5|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Placebo|16|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - risedronato|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - Placebo|6|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - Placebo|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - risedronato|2|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Placebo|2|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 1 x ano - Placebo|1|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 4 x ano - Placebo|1|AP|BR|NP|GP|NP|NP|Baixo|
|Placebo - risedronato|5|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 1 x ano - pamidronato 4 x ano|1|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 10<br>mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - pamidronato 1 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - pamidronato 4 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 20<br>mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - pamidronato 1 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|  
71  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato 20 mg - pamidronato 4 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 70<br>mg semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - pamidronato<br>1 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - pamidronato<br>4 x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - pamidronato  1<br>x ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - pamidronato 4 x<br>ano|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 1 x ano - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 4 x ano - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP -  Grandes preocupações; BR -  Baixo risco.  
72  
**Quadro U** . Avaliação geral da evidência – evento adverso  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Alendronato 10<br>mg|1|AP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Ácido Zoledrônico 5 mg - Alendronato 70<br>mg semana|1|AP|BR|NP|NP|GP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Placebo|8|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - Alendronato 20 mg|5|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Placebo|22|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 10 mg - risedronato|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - Placebo|5|GP|BR|NP|GP|NP|NP|Muito<br>baixo|
|Alendronato 70 mg semana - Placebo|4|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - risedronato|1|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 1 x ano - Placebo|1|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Pamidronato 4 x ano - Placebo|1|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Placebo - risedronato|6|AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 1 x ano - pamidronato 4 x ano|1|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Ácido Zoledrônico 5 mg - Alendronato 20<br>mg|0|AP|BR|NP|GP|NP|GP|Muito<br>baixo|  
73  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - pamidronato 1 x<br>ano|0|AP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Ácido Zoledrônico 5 mg - pamidronato 4 x<br>ano|0|AP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Ácido Zoledrônico 5 mg - risedronato|0|AP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 10 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 10 mg - pamidronato 1 x ano|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 10 mg - pamidronato 4 x ano|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 20 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 20 mg - pamidronato 1 x ano|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 20 mg - pamidronato 4 x ano|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 20 mg - risedronato|0|AP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Alendronato 70 mg semana - pamidronato<br>1 x ano|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|  
74  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliação**<br>**final**|
|---|---|---|---|---|---|---|---|---|
|Alendronato 70 mg semana - pamidronato<br>4 x ano|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Pamidronato 1 x ano - risedronato|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|
|Pamidronato 4 x ano - risedronato|0|GP|BR|NP|GP|NP|GP|Muito<br>baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP -  Grandes preocupações; BR -  Baixo risco  
75  
**Quadro V** . Avaliação geral da evidência – evento adverso grave.  
|**Comparações**|**n**|**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliaçã**<br>**o final**|
|---|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Placebo|7|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Alendronato 20 mg|5|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Placebo|19|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - risedronato|3|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - Placebo|6|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - Placebo|4|AP|BR|NP|NP|GP|GP|Muito<br>baixo|
|Alendronato 70 mg semana - risedronato|1|AP|BR|NP|NP|GP|GP|Muito<br>baixo|
|Placebo - risedronato|5|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 10<br>mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 20<br>mg|0|AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 70<br>mg semana|0|AP|BR|NP|NP|GP|NP|Baixo|
|Ácido Zoledrônico 5 mg - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - Alendronato 70 mg<br>semana|0|AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 20 mg - risedronato|0|AP|BR|NP|GP|NP|NP|Baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP -  Grandes preocupações; BR -  Baixo risco.  
76  
**Quadro W** . Avaliação geral da evidência – evento adverso gastrointestinal.  
|**Comparações**|**n**<br>**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliaçã**<br>**o final**|
|---|---|---|---|---|---|---|---|
|Alendronato 10 mg - Alendronato 20 mg|4<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Placebo|22<br>AP|BR|NP|NP|GP|NP|Baixo|
|Alendronato 10 mg - risedronato|3<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - Placebo|5<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - Placebo|4<br>AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 70<br>mg semana|1<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - risedronato|1<br>AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Placebo|1<br>NP|BR|NP|GP|NP|NP|Moderado|
|Pamidronato 150 mg oral - Placebo|1<br>AP|BR|NP|GP|NP|NP|Baixo|
|Placebo - risedronato|7<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - Alendronato 70 mg<br>semana|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - Alendronato 10<br>mg|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 10 mg - pamidronato 150 mg<br>oral|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - Alendronato 70 mg<br>semana|0<br>AP|BR|NP|GP|NP|NP|Baixo|  
77  
|**Comparações**|**n**<br>**Viés**<br>**do**<br>**estud**<br>**o**|**Viés de**<br>**publicação**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Avaliaçã**<br>**o final**|
|---|---|---|---|---|---|---|---|
|Ácido Zoledrônico 5 mg - Alendronato 20<br>mg|0<br>NP|BR|NP|GP|NP|NP|Moderado|
|Alendronato 20 mg - pamidronato 150 mg<br>oral|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 20 mg - risedronato|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Alendronato 70 mg semana - pamidronato<br>150 mg oral|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - pamidronato 150<br>mg oral|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Ácido Zoledrônico 5 mg - risedronato|0<br>AP|BR|NP|GP|NP|NP|Baixo|
|Pamidronato 150 mg oral - risedronato|0<br>AP|BR|NP|GP|NP|NP|Baixo|  
Legenda: NP - nenhuma preocupação; AP - Algumas preocupações; GP - Grandes preocupações; BR -  Baixo risco  
78

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: DENOSUMABE E TERIPARATIDA PARA O TRATAMENTO INDIVÍDUOS COM OSTEOPOROSE GRAVE E FALHA TERAPÊUTICA AOS MEDICAMENTOS DISPONÍVEIS NO SISTEMA ÚNICO DE SAÚDE<sup>7-8</sup> -->
Para a avaliação desta tecnologia, foi elaborada a seguinte pergunta de pesquisa: “Denosumabe e teriparatida são eficazes, efetivos, seguros e custo-efetivos no tratamento de pacientes com osteoporose grave e falha terapêutica (após segunda fratura) comparado a bisfosfonatos e raloxifeno?”  
Nesta pergunta, população (P) foram os pacientes com osteoporose grave e falha terapêutica (após segunda fratura); as intervenções (I) foram denosumabe e teriparatida; os comparadores (C) foram os bisfosfonatos e raloxifeno; os _outcomes_ /desfechos (O) primários número de pacientes com ao menos uma nova fratura vertebral; número de pacientes com ao menos uma nova fratura não vertebral; número de pacientes com descontinuação de tratamento devido a evento adverso; número de pacientes com ao menos um evento adverso grave; e secundários, mudança percentual da densidade mineral óssea de colo femoral; mudança percentual da densidade mineral óssea de coluna lombar; mudança percentual da densidade mineral óssea de quadril total; número de pacientes com ao menos uma nova fratura clínica; número de pacientes com ao menos uma nova ou piora de fratura relacionada à osteoporose; número de pacientes com ao menos um evento adverso; e os desenhos de estudo (S) foram revisões sistemáticas, ensaios clínicos randomizados e estudos de coorte comparativos. Após definição da pergunta PICO em 2019, foi identificada necessidade de adequação da pergunta PICO, em que foram acrescentados aos compradores o ácido zoledrônico, teriparatida e denosumabe.  
A seguir, são apresentados o processo de busca da evidência, triagem e seleção de estudos, resultados e síntese dos dados, avaliação do risco de viés e avaliação da certeza na evidência. A avaliação detalhada dessa tecnologia encontra-se no Relatório de Recomendação nº 742, de junho de 2022 - Denosumabe e teriparatida para o tratamento indivíduos com osteoporose grave e falha terapêutica aos medicamentos disponíveis no Sistema Único de Saúde<sup>8</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **A) Busca da evidência** -->
Com base na pergunta PICO estruturada, foi realizada uma busca em maio de 2021 nas seguintes plataformas: PubMed, EMBASE e The Cochrane Library. Para validação da estratégia de busca, uma busca no Epistemonikos foi realizada visando a identificação de potenciais revisões sistemáticas não recuperadas nas bases principais e estudos primários recuperados por essas revisões. O Quadro X a seguir detalha as estratégias de busca efetuadas em cada plataforma.  
**Quadro X.** Estratégia de busca nas plataformas consultadas em maio de 2021.  
|**Plataforma**<br>**s de busca**|**Estratégia de busca**|
|---|---|
|**PubMed**|"osteoporosis"[MH] OR osteoporo*[TIAB] OR “bone loss”[TIAB] OR “bone losses”[TIAB] OR<br>Fractures, Bone[MH] OR “Bone Fractures”[TIAB] OR “Bone Fracture”[TIAB] OR “Broken<br>Bone”[TIAB] OR “Broken Bones”[TIAB] OR Bone Resorption[MH] OR “Bone Resorption”[TIAB]<br>OR “Bone Resorptions”[TIAB] OR  Bone Density[MH] OR “Bone Density”[TIAB] OR “Bone<br>Densities”[TIAB] OR “Bone Mineral Density”[TIAB] OR “Bone Mineral Densities”[TIAB] OR<br>“Bone Mineral Content”[TIAB] OR “Bone Mineral Contents”[TIAB]<br>AND<br>teriparatid*[TIAB] OR "teriparatide"[MH] OR "denosumab"[MH] OR "denosumab"[TIAB] OR<br>Parathar[TIAB] OR Forteo[TIAB] OR Prolia[TIAB]<br>NOT|
||(animals[MH:noexp] NOT (animals[MH:noexp] AND humans[MH]))|  
79  
||NOT<br>(editorial[PT] OR historical article[PT] OR Case Reports[PT] OR News[PT])|
|---|---|
|**EMBASE**|('osteoporosis':ti,ab,kw OR osteoporo*:ti,ab,kw OR 'bone loss':ti,ab,kw OR 'bone losses':ti,ab,kw OR<br>'fractures, bone':ti,ab,kw OR 'bone fractures':ti,ab,kw OR 'bone fracture':ti,ab,kw OR 'broken<br>bone':ti,ab,kw OR 'broken bones':ti,ab,kw OR 'bone resorption':ti,ab,kw OR 'bone resorptions':ti,ab,kw<br>OR 'bone density':ti,ab,kw OR 'bone densities':ti,ab,kw OR 'bone mineral density':ti,ab,kw OR 'bone<br>mineral densities':ti,ab,kw OR 'bone mineral content':ti,ab,kw OR 'bone mineral contents':ti,ab,kw)<br>AND<br>(teriparatid*:ti,ab,kw OR 'denosumab':ti,ab,kw OR parathar:ti,ab,kw OR forteo:ti,ab,kw OR<br>prolia:ti,ab,kw)<br>AND<br>[embase]/lim NOT ([embase]/lim AND [medline]/lim)|
|**_The_**|osteoporo* OR “bone loss” OR “bone losses” OR “Bone Fractures” OR “Bone Fracture” OR “Broken|
|**_Cochrane_**<br>**_Library_**<br>**(Apenas**<br>**revisões)**|Bone” OR “Broken Bones” OR “Bone Resorption” OR “Bone Resorptions” OR “Bone Density” OR<br>“Bone Densities” OR “Bone Mineral Density” OR “Bone Mineral Densities” OR “Bone Mineral<br>Content” OR “Bone Mineral Contents”<br>AND<br>teriparatid* OR "denosumab" OR Parathar OR Forteo OR Prolia|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **B) Seleção dos estudos** -->
Foram recuperadas 5.825 publicações nas bases de dados consultadas, restando 5.621 após remoção de duplicatas identificadas eletronicamente. Durante a seleção, 5.071 registros foram considerados irrelevantes na triagem e 543 foram excluídos na etapa de leitura na íntegra, o que pode ser observado na Figura M. Assim, sete registros foram incluídos, referente a seis estudos: cinco ECR e um estudo de coorte comparativa.  
80  
**Figura M** . Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Registros identificados de: Registros_removidos antes da Registros identificados de:<br>PubMed (n = 3.160) triagem: Websites (n = 0)<br>Embase (n = 2.647) Registros duplicados removidos Organizacdes (n = 0)<br>Cochrane (n= 18) eletronicamente (n = 204) Pesquisa de citagGes (n = 0)<br>(n=5.071)<br>(n=5.621) |<br>Registros procurados para Registros ndo recuperados Registros procurados para Registros n3o recuperados<br>recuperago (n=0) recuperacdo >| (n=0)<br>(n=550) (n=0)<br>Registros avaliados_ para Registros excluidos: Registros avaliados._-— para Registros excluidos<br>elegibilidade i—+| Populacdo (n=515) elegibilidade >| (n=0)<br>(n=550) Intervencdo (n = 10) (n=0)<br>Controle (n= 6)<br>Desfechos (n = 2)<br>Tipo de estudo (n = 5)<br>Tipo de publicacdo (n = 3)<br>Duplicidades identificadas<br>manualmente (n= 2)<br>Registros incluidos no PTC<br>(n=7)<br>Estudos incluidos no PTC<br>(n=6)<br><!-- End of picture text -->  
81  
- **C) Resultados e síntese de dados**  
- Descrição dos estudos incluídos  
Os estudos incluídos foram descritos com auxílio de quadros e tabelas. As informações sobre cada um deles podem  
ser consultadas no Relatório de Recomendação nº 742, de junho de 2022<sup>8</sup> , disponível no _site_ da Conitec.  
- Síntese dos dados  
Foram conduzidas meta-análises para todos os desfechos. Os resultados são apresentados nas Tabelas A a D<sup>8</sup> .  
**Tabela A** . Meta-análise para fratura vertebral, considerando apenas estudos que atendem aos critérios de elegibilidade deste relatório de recomendação (caso-base).  
|Teriparatida|0.50 [0.34; 0.75]|0.35 [0.22; 0.55]|0.15 [0.02; 1.20]|
|---|---|---|---|
|0.50 [0.34; 0.75]|Risedronato|.|.|
|0.35 [0.22; 0.55]|0.69 [0.37; 1.28]|Placebo|.|
|0.15 [0.02; 1.20]|0.30 [0.04; 2.48]|0.43 [0.05; 3.63]|Alendronato|  
Interpretação: O triângulo inferior corresponde aos resultados das meta-análises em rede, enquanto o triângulo superior aos resultados das metaanálises diretas. A leitura deve ser feita da esquerda para a direita, por exemplo, teriparatida reduz o risco de fraturas vertebrais em relação a todos os comparadores (de 50% a 65%), exceto alendronato. As terapias são ranqueadas pela probabilidade de ser a opção mais eficaz, portanto, para esse desfecho teriparatida tem potencial de ser a terapia mais eficaz e alendronato a terapia menos eficaz.  
**Tabela B** . Meta-análise para fratura não vertebral, considerando apenas estudos que atendem aos critérios de elegibilidade deste relatório de recomendação (caso-base).  
|Teriparatida|0.78 [0.55; 1.11]|0.46 [0.25; 0.86]|
|---|---|---|
|0.78 [0.55; 1.11]|Risedronato|.|
|0.46 [0.25; 0.86]|0.59 [0.29; 1.20]|Placebo|  
Interpretação: O triângulo inferior corresponde aos resultados das meta-análises em rede, enquanto o triângulo superior aos resultados das metaanálises diretas. A leitura deve ser feita da esquerda para a direita, por exemplo, teriparatida reduz o risco de fraturas não vertebrais em relação a placebo (54%). As terapias são ranqueadas pela probabilidade de ser a opção mais eficaz, portanto, para esse desfecho teriparatida tem potencial de ser a terapia mais eficaz e placebo a opção menos eficaz.  
**Tabela C** . Meta-análise para mudança da DMO em colo femoral, considerando apenas estudos que atendem aos critérios de elegibilidade deste relatório de recomendação (caso-base).  
|Teriparatida|1.34 [ 0.08;<br>2.60]|.|3.21 [ 2.83;<br>3.59]|3.50 [ 2.80;<br>4.20]|.|
|---|---|---|---|---|---|
|1.34 [ 0.08;<br>2.60]|Risedronato|.|.|.|.|
|2.21 [ 1.53;<br>2.89]|0.87 [-0.56;<br>2.30]|Denosumabe|1.00 [ 0.43;<br>1.57]|.|1.30 [ 0.77;<br>1.83]|
|3.21 [ 2.83;<br>3.59]|1.87 [ 0.56;<br>3.18]|1.00 [ 0.43;<br>1.57]|Alendronato|.|.|
|3.50 [ 2.80;<br>4.20]|2.16 [ 0.72;<br>3.60]|1.29 [ 0.31;<br>2.27]|0.29 [-0.51;<br>1.09]|Placebo|.|
|3.51 [ 2.64;|2.17 [ 0.65;|1.30 [ 0.77;|0.30 [-0.48;|0.01 [-1.11;|Ácido|
|4.38]|3.69]|1.83]|1.08]|1.13]|zoledrônico|  
Interpretação: O triângulo inferior corresponde aos resultados das meta-análises em rede, enquanto o triângulo superior aos resultados das meta-  
análises diretas. A leitura deve ser feita da esquerda para a direita, por exemplo, teriparatida aumenta a DMO em relação a todos os comparadores (de 1,34%  
82  
a 3,51% a mais que estes comparadores). As terapias são ranqueadas pela probabilidade de ser a opção mais eficaz, portanto, para esse desfecho teriparatida tem potencial de ser a terapia mais eficaz e ácido zoledrônico a terapia menos eficaz.  
**Tabela D** . Meta-análise para mudança da DMO em coluna lombar, considerando apenas estudos que atendem aos critérios de elegibilidade deste relatório de recomendação (caso-base).  
|Teriparatida|5.17 [ 3.79;<br>6.55]|.|8.55 [ 8.10;<br>9.00]|8.60 [ 7.79;<br>9.41]|.|
|---|---|---|---|---|---|
|5.17 [ 3.79;<br>6.55]|Risedronato|.|.|.|.|
|7.37 [ 6.64;<br>8.10]|2.20 [ 0.64;<br>3.76]|Denosumabe|1.18 [ 0.60;<br>1.76]|.|2.10 [ 1.53;<br>2.67]|
|8.55 [ 8.10;<br>9.00]|3.38 [ 1.93;<br>4.83]|1.18 [ 0.60;<br>1.76]|Alendronato|.|.|
|8.60 [ 7.79;<br>9.41]|3.43 [ 1.83;<br>5.03]|1.23 [ 0.14;<br>2.32]|0.05 [ -0.87;<br>0.97]|Placebo|.|
|9.47 [ 8.55;|4.30 [ 2.64;|2.10 [ 1.53;|0.92 [ 0.11;|0.87 [ -0.36;|Ácido|
|10.39]|5.96]|2.67]|1.73]|2.10]|zoledrônico|  
Interpretação: O triângulo inferior corresponde aos resultados das meta-análises em rede, enquanto o triângulo superior aos resultados das metaanálises diretas. A leitura deve ser feita da esquerda para a direita, por exemplo, teriparatida aumenta a DMO em relação a todos os comparadores (de 5,17% a 9,47% a mais que estes comparadores). As terapias são ranqueadas pela probabilidade de ser a opção mais eficaz, portanto, para esse desfecho teriparatida tem potencial de ser a terapia mais eficaz e ácido zoledrônico a terapia menos eficaz.

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **D) Avaliação do risco de viés** -->
A avaliação do risco de viés para os desfechos primários é apresentada na Figura N e no Quadro Y.  
**Figura N.** Risco de viés por estudo e desfecho  
<!-- Start of picture text -->
[Emu inteceneio |Comsardar —_[Deafecha pio | op | oa | os | Ge<br>Intent<br>devr tender 2010(TAND) Derosmabe Aertonatotdaapecemim00 QO) @ @ OO @ sicixe<br>Decprotecle [Render 2010(SAND) ewaamate Aeionato _|racenescom eertosée camara | @ | @ | @/ OO) O | | @ wwixe<br>Perpretcelo |Naler2016 _—_Derwamabe cin oltre (acenescomeenosée wor @ @ @ OO @<br>Imenco<br>de vata Niles 2015 _ewwsmabe iozl eric acintescom faa OO © OO | re pesiossa terre ete<br>Perprotcslo fender<br>2017 (VERO) Terps rietonato_Paceescom evetosce woman QQ @ @ QQ 05 sercso de restas reetawn<br>Perpreteelo_|tuts2012 Terparatiss [tiadonato_[racenescom eenosée womans @1@/@'@ @ @<br>Intenso deat fender 2017VERO) Teprtéh Rimkonato | acentescom aia eee00 0<br>Intenso<br>Intengéo d eea tra t ar Hadj 2012Pico 2011 Te riparrr a t i dan Risedr[Alrk onato __Facientescom| Pacientescom f raturarat eoeo5ueet@C6ieee8 O<br><!-- End of picture text -->  
Legenda: D: domínio; DMO: densidade mineral óssea.  
83  
**Quadro Y.** Avaliação dos estudos observacionais, segundo a ROBINS-I.  
|||||**Domínios**|||||
|---|---|---|---|---|---|---|---|---|
|**Estudo**|**Confusão**|**Seleção**<br>**dos**<br>**partici-**<br>**pantes**|**Classificaç**<br>**ão**|**Desvios**|**Dados**<br>**incompl**<br>**etos**|**Mensu-**<br>**ração**|**Seleção de**<br>**resultado**|**Viés**<br>**geral**|
|Caggiari<br>2016<sup>18</sup>|Grave|Baixo|Baixo|Sem<br>informação|Baixo|Baixo|Sem<br>informação|Grave<br>risco de<br>viés|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **E) Avaliação da certeza na evidência** -->
A avaliação da certeza na evidência dos desfechos primários é apresentada no Quadro Z.  
84  
**Quadro Z.** Avaliação da qualidade da evidência (adaptado da ferramenta GRADE).  
||||**Ava**|**liação da qualida**|**de**|||**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
|**Comparação**|||||||**Confiança**||
||**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|<br>**geral da**<br>|**Impacto**|
||||||||**evidência**||
|Pacientes com ao<br>|menos uma nova fratu<br>|ra vertebral(desfe<br>|choprimário)||||||
|Denosumabe<br>vs alendronato|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Teriparatida vs<br>alendronato|80<br>(1 ECR)|Muito<br>grave<sup>a</sup>|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Teriparatida<br>é<br>similar<br>a<br>alendronato<br>com<br>base em estudo de<br>baixa qualidade (RR<br>0,15 (IC 95% 0,02;<br>1,20))|
|Denosumabe<br>vs risedronato|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Teriparatida vs<br>risedronato|1752<br>(2 ECR)|Muito<br>grave<sup>c</sup>|Não grave|Não grave|Não grave|Nenhum|⨁⨁◯◯<br>BAIXA|Teriparatida<br>é<br>superior<br>a<br>risedronato<br>por<br>reduzir em 54% o<br>risco de nova fratura<br>vertebral (RR 0,46<br>(IC95% 0,36;0,59))|
|Denosumabe<br>vs teriparatida|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Pacientes com des|continuação de tratam|entopor evento ad|verso(desfechoprimár|io)|||||
|Denosumabe<br>vs alendronato|502<br>(1 ECR)|Não grave|Não grave|Não grave|Não grave|Nenhum|⨁⨁⨁⨁<br>ALTA|Denosumabe<br>não<br>provê<br>prejuízo<br>adicional<br>na<br>comparação<br>com<br>alendronato<br>(p=1,00)|
|Teriparatida vs<br>alendronato|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Denosumabe<br>vs risedronato|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Teriparatida vs<br>alendronato|2070<br>(2 ECR)|Não grave|Não grave|Não grave|Não grave|Nenhum|⨁⨁⨁⨁<br>ALTA|Teriparatida<br>não<br>provê<br>prejuízo|  
85  
||||**Ava**|**liação da qualida**|**de**|||**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
|**Comparação**|||||||**Confiana**||
||**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**ç**<br>**geral da**<br>**evidência**|**Impacto**|
|||||||||adicional<br>na<br>comparação<br>com<br>risedronato<br>(RR<br>1,33 (IC 95% 0,57;<br>3,09))|
|Denosumabe<br>vs teriparatida|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Pacientes com ao|menos um evento adv|ersograve(desfec|hoprimário)||||||
|Denosumabe<br>vs alendronato|502<br>(1 ECR)|Não grave|Não grave|Não grave|Não grave|Nenhum|⨁⨁⨁⨁<br>ALTA|Denosumabe<br>não<br>provê<br>prejuízo<br>adicional<br>na<br>comparação<br>com<br>alendronato<br>(p=0,86)|
|Teriparatida vs<br>alendronato|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Denosumabe<br>vs risedronato|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Teriparatida vs<br>alendronato|2070<br>(2 ECR)|Não grave|Não grave|Não grave|Não grave|Nenhum|⨁⨁⨁⨁<br>ALTA|Teriparatida<br>não<br>provê<br>prejuízo<br>adicional<br>na<br>comparação<br>com<br>risedronato<br>(RR<br>1,01 (IC 95% 0,10;<br>10,46))|
|Denosumabe<br>vs teriparatida|0<br>(0)|Sem<br>informação|Sem informação|Sem<br>informação|Sem<br>informação|Sem informação|Sem<br>informação|Sem informação|
|Mudança da densi|dade mineral ósseape|rcentual de colo fe|moral(desfecho secun|dário)|||||
|Denosumabe<br>vs alendronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Denosumabe<br>aumenta a densidade<br>mineral óssea em<br>1,0% a mais na<br>comparação<br>com<br>alendronato<br>(MD<br>1,0 (IC 95% 0,43;<br>1,57))|  
86  
|**Comparação**|||**Ava**|**liação da qualida**<br>|**de**||**Confiança**|**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
||**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|<br>**geral da**<br>**evidência**|**Impacto**|
|Teriparatida vs<br>alendronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|não grave|Nenhum|⨁⨁⨁◯<br>MODERAD<br>A|Teriparatida<br>aumenta a densidade<br>mineral óssea em<br>3,21% a mais na<br>comparação<br>com<br>alendronato<br>(MD<br>3,21 (IC 95% 2,83;<br>3,59))|
|Denosumabe<br>vs risedronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Denosumabe<br>é<br>similar<br>a<br>risedronato,<br>podendo apresentar<br>aumento<br>maior<br>(0,56%) ou menor (-<br>2,30%)<br>que<br>risedronato (MD -<br>0,87 (IC 95% -<br>32,30;0,56))|
|Teriparatida vs<br>risedronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Teriparatida<br>aumenta a densidade<br>mineral óssea em<br>1,34% a mais na<br>comparação<br>com<br>risedronato<br>(MD<br>1,34 (IC 95% 0,08;<br>2,60))|
|Denosumabe<br>vs teriparatida<br>Mudança da densi|1932<br>(4 ECR)<br>dade mineral ósseape|Grave<sup>a</sup><br>rcentual de colun|Não grave<br>a lombar(desfecho secu|Não grave<br>ndário)|Não grave|Nenhum|⨁⨁⨁◯<br>MODERAD<br>A|Teriparatida<br>aumenta a densidade<br>mineral óssea em<br>2,21% a mais na<br>comparação<br>com<br>denosumabe<br>(MD<br>2,21 (IC 95% 1,53;<br>2,89))|  
87  
|**Comparação**|||**Av**|**aliação da qualida**<br>|**de**||**Confiança**|**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
||**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|<br>**geral da**<br>**evidência**|**Impacto**|
|Denosumabe<br>vs alendronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Denosumabe<br>aumenta a densidade<br>mineral óssea em<br>1,18% a mais na<br>comparação<br>com<br>alendronato<br>(MD<br>1,18 (IC 95% 0,60;<br>1,76))|
|Teriparatida vs<br>alendronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|não grave|Nenhum|⨁⨁⨁◯<br>MODERAD<br>A|Teriparatida<br>aumenta a densidade<br>mineral óssea em<br>8,55% a mais na<br>comparação<br>com<br>alendronato<br>(MD<br>8,55 (IC 95% 8,10;<br>9,00))|
|Denosumabe<br>vs risedronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Denosumabe<br>aumenta a densidade<br>mineral óssea em<br>2,2% a menos que<br>risedronato (MD -<br>2,20 (IC 95% -3,76;<br>-0,64))|
|Teriparatida vs<br>risedronato|1932<br>(4 ECR)|Grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Teriparatida<br>aumenta a densidade<br>mineral óssea em<br>5,17% a mais na<br>comparação<br>com<br>risedronato<br>(MD<br>5,17 (IC 95% 3,79;<br>6,55))|
|Denosumabe<br>vs teriparatida|1932<br>(4 ECR)|Grave<sup>a</sup>|Não grave|Não grave|Não grave|Nenhum|⨁⨁⨁◯<br>MODERAD<br>A|Teriparatida<br>aumenta a densidade<br>mineral óssea em<br>7,4% a mais na<br>comparação<br>com|  
88  
||||**Ava**|**liação da qualid**|**ade**|||**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
|**Comparação**|**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Confiança**<br>**geral da**<br>**evidência**|**Impacto**|
|||||||||denosumabe<br>(MD<br>7,37 (IC 95% 6,64;<br>8,10))|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **E) Avaliação da certeza na evidência** -->
a. Algumas preocupações para domínios relativos à randomização, desvio da intervenção pretendida e reporte seletivo de resultado.  
b. Similaridade estatística entre comparadores.  
c. Algumas preocupações devido a problemas nos domínios relativos à randomização, desvio da intervenção pretendida e reporte seletivo de resultado.  
**ECR:** ensaio clínico randomizado **; IC** : intervalo de confiança; **MD** : diferença média; **RR** : risco relativo.  
89  
DENOSUMABE PARA O TRATAMENTO DE OSTEOPOROSE E DOENÇA RENAL CRÔNICA EM ESTÁGIO 4 e 5 9-10  
Para a avaliação desta tecnologia, foi elaborada a seguinte pergunta de pesquisa: “Denosumabe é eficaz, seguro e custo-efetivo no tratamento de pacientes com osteoporose com insuficiência renal grave (DCE < 30 mL/min), comparado a qualquer comparador ativo ou placebo?”  
Nesta pergunta, população (P) foram os pacientes com osteoporose com insuficiência renal grave (DCE < 30 mL/min); intervenção (I) foi o denosumabe; comparador (C) foi qualquer comparador ativo ou placebo; _outcomes_ /desfechos (O) primários foram novas fraturas vertebrais e não vertebrais; e eventos adversos graves; e os secundários DMO de colo femoral, coluna lombar e no quadril total em relação ao _baseline_ , eventos adversos em geral; e os desenhos de estudo (S) foram revisão sistemática com e sem meta-análise, ensaios clínicos randomizados, estudos de coorte (prospectivos e retrospectivo) com grupo comparador.  
A seguir, são apresentados o processo de busca da evidência, triagem e seleção de estudos, resultados e síntese dos dados, avaliação do risco de viés e avaliação da certeza na evidência. A avaliação detalhada dessa tecnologia encontra-se no Relatório de Recomendação nº 740, de junho de 2022 - denosumabe para o tratamento de osteoporose e doença renal crônica em estágio 4 e 5<sup>9-10</sup> .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **A) Busca da evidência** -->
Com base na pergunta PICO estruturada, foram realizadas buscas nas plataformas Medline (PUBMED) e EMBASE. As estratégias de busca adotadas em cada uma das plataformas, assim como os resultados obtidos, são apresentadas no **Quadro AA** .  
**Quadro AA.** Estratégias de busca nas plataformas consultadas em 01/06/2021.  
|**Bases**<br>**de**<br>**dados**|**Estratégia de Busca**|
|---|---|
|**MEDLINE**|("Osteoporosis"[Mesh] OR "Osteoporosis" OR Osteoporoses OR "Osteoporosis, Post-Traumatic"|
|**via Pubmed**|OR "Osteoporosis, Post Traumatic" OR "Post-Traumatic Osteoporoses" OR "Post-Traumatic<br>Osteoporosis" OR "Osteoporosis, Senile" OR "Osteoporoses, Senile" OR "Senile Osteoporoses" OR<br>"Osteoporosis, Involutional" OR "Senile Osteoporosis" OR "Osteoporosis, Age-Related" OR<br>"Osteoporosis, Age Related" OR "Bone Loss, Age-Related" OR "Age-Related Bone Loss" OR "Age-<br>Related Bone Losses" OR "Bone Loss, Age Related" OR "Bone Losses, Age-Related" OR "Age-<br>Related Osteoporosis" OR "Age Related Osteoporosis" OR "Age-Related Osteoporoses" OR<br>"Osteoporoses, Age-Related") AND ("Denosumab"[Mesh] OR "AMG 162" OR Prolia)|
|**EMBASE**|('osteoporosis'/exp OR 'endocrine osteoporosis' OR 'osteoporotic decalcification') AND<br>('denosumab'/exp OR 'amg 162' OR 'amg162' OR 'amgiva' OR prolia) NOT [1-6-2021]/sd AND<br>[embase]/lim|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **B) Seleção dos estudos** -->
Foram encontradas 6.030 publicações nas plataformas de busca (1.378 no MEDLINE e 4.649 no EMBASE) e três por meio de busca manual. Após a remoção de duplicatas, 4.836 registros foram triados (leitura de título e resumo). Na fase seguinte, 94 textos completos foram avaliados quanto a elegibilidade. Ao final, um artigo foi incluído na revisão. A **Figura O** descreve o fluxograma da seleção dos estudos e suas etapas.  
90  
**Figura O.** Fluxograma da seleção das evidências.  
<!-- Start of picture text -->
3 Ragiswos idenilicadox Registros removidos antes da<br>(n=6030) fodean<br>3 Medline (n = 1-378) Registros duplicados removidos<br>Embase (n = 4.649) (n =1.194}<br>3 Busca manual (n = 03) inet Tes)<br>Registros triados »| Registros axcluidos<br>in = 4.836) (n= 4.742)<br>Registros solicitados para >| Ragistros nao racuparados:<br>recuperagio (n = 94) (n=0)<br>Regisiros avaliados quanto Registros excluides (n = 93)<br>a eleg bilidade (n = 94) ., fe<br>Tipo de participante (n = 40)<br>Tipo de intervengéio (n = 02)<br>Tipo Ge comparacao (n = 05)<br>Tipe de estudo (n = 35)<br>Tivo de publicaggio (n = 11)<br>|<br>8<br>S| | Estudos incluidas na<br>2 revisdo (n = 1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **C) Resultados e síntese de dados** -->
Na comparação entre denosumabe e placebo, o denosumabe pode fazer pouca ou nenhuma diferença no risco de fratura vertebral (risco relativo, RR 0,35, intervalo de confiança de 95%, IC 95% 0,04; 3,23). O mesmo acontece para fratura não vertebral, não houve diferença estatisticamente significante entre os comparadores (RR 0,51, IC 95% 0,05; 5,42), conforme apresentado na **Figura P** .  
91  
<!-- Start of picture text -->
4.1 Fratura vertebral<br>denosumabe placebo Risk Ratio Risk Ratio<br>Study or Subgrou Events Total _Events Total Weight _M-H,Random,95%Cl M-H.Random,95%C1<br>Jamal_2011_Stage 4 CKD by CG 1 3t 3-33 100.0% 0.36 (0.04, 3.23]<br>Jamal_2011_Stage 4 CKD by MDRD 0 5 o 9 Not estimable<br>Total(95% Cl) 36 42 100.0% 0.35 (0.04, 3.23]<br>Total events 1 3<br>Testoest for overallova teeffect:aean2 = 0.92 (PP= = 0.360.36) Favours091 [experimental] ' Favours (controlio<br><!-- End of picture text -->  
<!-- Start of picture text -->
1.2 Fratura nao vertebral<br>denosumabe placebo Risk Ratio Risk Ratio<br>Study or Subgrou Events Total Events Total Weight _M-H,Random,95%Cl M-H,Random,95%Cl<br>Jamal_2011_Stage 4 CKD by CG 1 36 2 37 100.0% 0.51 (0.05, 5.42)<br>Jamal_2011_Stage 4 CKD by MORD o 8 0 9 Not estimable<br>Total (95% Cl) 44 46 100.0% 0.54 [0.05, 5.42]<br>Total events 1 2<br>Heterogeneity: Not applicable 01 07 7 70<br>Test for overall effect: Z = 0.55 (P = 0.58) Favours [experimental] Favours [co<br><!-- End of picture text -->  
**Figura P.** _Forest plots_ das meta-análises para desfechos de fraturas vertebrais (1.1) e não vertebrais (1.2).

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Mudança percentual na densidade mineral óssea (DMO)** -->
As alterações na DMO colo femoral e quadril total foram a favor do denosumabe, quando comparado ao placebo. O denosumabe foi associado a um aumento significativo (p≤ 0,0002) de 5,9% (IC 95% 3,3; 8,5) na DMO colo femoral e 5,9% (IC 95% 3,0; 8,7) na DMO de quadril total ao longo de 36 meses. Na DMO da coluna lombar não houve diferença estatisticamente significante entre denosumabe e placebo (percentual de diferença de 5,0%, IC 95% -0,8; 10,8).

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Eventos adversos graves** -->
Na comparação entre denosumabe e placebo, não houve diferenças na incidência de eventos adversos graves  
(denosumabe n= 15 e placebo n= 13), conforme apresentado na **Tabela E** .

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **Eventos adversos graves relacionados à infecção e cardiovasculares** -->
Na comparação entre denosumabe e placebo não houve diferença na incidência de eventos adversos graves relacionados à infecção (denosumabe n= 4 e placebo n= 1) ou eventos adversos cardiovasculares graves (denosumabe n= 4 e placebo n= 3), conforme apresentado na **Tabela E** .  
**Tabela E.** Incidência de eventos adversos na comparação denosumabe e placebo.  
|**Desfecho**|**Placebo, n participantes (%)**<br>**N=37**|**Denosumabe, n participantes**<br>**(%) N=36**|
|---|---|---|
|**Pacientes com eventos adversos**|35 (94,6)|35 (97,2)|
|**Pacientes com eventos adversos grave**|13 (35,1)|15 (41,7)|
|**Pacientes**<br>**com**<br>**eventos adversos**<br>**graves relacionados à infecção**|1 (2,7)|4 (11,1)|
|**Pacientes**<br>**com**<br>**eventos adversos**<br>**cardiovasculares graves**|3 (8,1)|4 (11,1)|

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **D) Avaliação do risco de viés** -->
A avaliação do risco de viés está descrita na **Figura Q** .  
92  
**Figura Q.** Avaliação do risco de viés dos estudos incluídos por tipo de desfecho.  
<!-- Start of picture text -->
Domínios do risco de viés<br>Estudo/ Comparação/ Desfecho avaliado  D D D D D Geral<br>1  2  3  4  5<br>@eeee00@<br>NOK NOVO 2<br>O©OO@0@08<br>Domínios:  Julgamento:<br>D1: Risco de viés decorrente do processo de randomização  ® Alto<br>D2: Risco de viés devido a desvios das intervenções pretendidas  e@ Moderado<br>D3: Risco de viés devido à falta de dados de resultados  @ Baixo<br>D4: Risco de viés na medição do resultado<br>D5: Risco de viés na seleção do resultado relatado<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **E) Avaliação da certeza na evidência** -->
A avaliação da certeza na evidência está descrita na Tabela F.  
93  
**Tabela F:** Sumarização dos resultados dos estudos incluídos ( _Summary of Findings_ ; SoF) e avaliação da qualidade da evidência (do _webapp_ Grade PRO).  
|||**Risco**|**Certeza da evid**|**ência**|||**№ de pac**|**ientes**|**E**<br>**Relativo**|**feito**|**Ct**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**denosumabe**|**placebo**|**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**ereza**|**mpornca**|
|||||**Novas**|**fraturas de qu**|**alquer tipo (Pop**|**ulação com oste**|**oporose)**<br>|<br>**RR 0.58**|**63 menos**<br>|||
|1<br>1<br>1|ensaios<br>clínicos<br>randomizados<br>ensaios<br>clínicos<br>randomizados<br>ensaios<br>clínicos<br>randomizados<br>ensaios|grave<sup>a</sup><br>,g<br>grave<sup>h</sup><br>,i<br>grave<sup>h</sup><br>,i<br><sup>a</sup>|grave<sup>c</sup><br> <br>não grave<br>**No**<br>não grave|grave<sup>d</sup><br>**Novas fratur**<br>não grave<br>**vas fraturas**<br>não grave<br>|não grave<br>**as vertebrais (P**<br>grave<sup>f,j</sup><br>**não vertebrais**<br>grave<sup>f,j</sup><br>**DMO coluna lo**|nenhum<br>**opulação com os**<br>nenhum<br>**(População com**<br>nenhum<br>**mbar (Populaçã**|324/3702<br>(8.8%)<br>**teoporose e DR**<br>1/36 (2.8%)<br>**osteoporose e D**<br>1/44 (2.3%)<br>**o com osteopor**<br>|557/369<br>1<br>(15.1%)<br>**C estágios 4**<br>3/42<br>(7.1%)<br>**RC estágios**<br>2/46<br>(4.3%)<br>**ose)**<br>|<br>(0.51<br>para<br>0.66)<br>**e 5)**<br>**RR 0.35**<br>(0.04<br>para<br>3.23)<br>**4 e 5)**<br>**RR 0.51**<br>(0.05<br>para<br>5.42)<br>|**por 1.000**<br>(de 74<br>menos para<br>51 menos)<br>**46 menos**<br>**por 1.000**<br>(de 69<br>menos para<br>159mais)<br>**21 menos**<br>**por 1.000**<br>(de 41<br>menos para<br>192 mais)<br>|⨁◯◯◯<br>Muito<br>baixa<br>⨁⨁◯◯<br>Baixa<br>⨁⨁◯◯<br>Baixa<br>⨁◯◯◯|CRÍTICO<br>CRÍTICO<br>CRÍTICO|
|4|clínicos<br>randomizados|grave<br>,b|grave<sup>c</sup>|grave<sup>d</sup>|não grave|nenhum|Percentual<br>5,41%|e mudança<br>(IC 95%: 1,9|a favor do de<br>2; 8,90), p=|nosumabe:<br>0,002.|Muito<br>baixa|IMPORTANTE|
||ensaios|muito||**DMO colu**|**na lombar (Pop**|**ulação com oste**|**oporose e DRC**<br>|**estágios 4 e**<br>|**5)**<br>||⨁◯◯◯||
|1|<br>clínicos<br>randomizados|<br>grave<sup>h,</sup><br>i,k|não grave|não grave|grave<sup>j</sup>|nenhum|Percentual de<br>(I|mudança a fa<br>C 95% -0,8; 1|vor do deno<br>0,8), p> 0,0|sumabe: 5,0%<br>5.|Muito<br>baixa|IMPORTANTE|
||<br>ensaios|<sup>a</sup>|||**DMO quadril**|**total (População**|**com osteoporo**<br>|**se)**<br>|||<br>||
|4|clínicos<br>randomizados|grave<br>,b|não grave|grave<sup>d</sup>|não grave|nenhum|Percentual<br>1,65%|e mudança<br>(IC 95%: 1,1|favor do de<br>2; 2,19), p<0|nosumabe:<br>,0001.|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|||||**DMO qua**|**dril total (Pop**|**ulação com osteo**|**porose e DRC e**|**stágios 4 e 5**|**)**||||
||ensaios|muito<br>|||||Percentual de|mudana a fa|vor do deno|umabe: 59%|⨁◯◯◯||
|1|clínicos<br>randomizados|grave<sup>h,</sup><br>i,k|não grave|não grave|grave<sup>j</sup>|nenhum|<br>(IC|ç<br>95% 3,0; 8,|<br>7), p≤ 0,000|,<br>2.|Muito<br>baixa|IMPORTANTE|  
94  
|||**Risco**|**Certeza da evid**|**ência**<br>|||**№ de pa**|**cientes**|**E**<br>**Relativo**|**feito**|**Ct**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**denosumabe**|**placebo**|**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**ereza**|**mpornca**|
|2|ensaios<br>clínicos<br>randomizados<br>|grave<sup>a</sup><br>|não grave|grave<sup>d</sup><br>**DMO co**|**DMO colo fem**<br>não grave<br>**lo femoral (Pop**|**oral (População**<br>nenhum<br>**ulação com osteo**|**com osteoporo**<br>Percentual<br>1,79%<br>**porose e DRC e**|**se)**<br>de mudança<br>(IC 95%: 1,0<br>**stágios 4 e 5**|<br>a favor do de<br>6; 2,52), p<0<br>**)**|nosumabe:<br>,0001.|⨁⨁◯◯<br>Baixa<br>|IMPORTANTE|
||ensaios|muito|||||||||⨁◯◯◯||
|1|<br>clínicos<br>randomizados|<br>grave<sup>h,</sup><br>i,k|não grave|não grave|grave<sup>j</sup>|nenhum|Percentual de<br>(I|mudança a fa<br>C 95% 3,3; 8,|vor do deno<br>5), p≤ 0,000|sumabe: 5,9%<br>2.|Muito<br>baixa|IMPORTANTE|
||||||**Eventos adverso**|**s geral (Populaç**|**ão com osteopo**|**rose)**|||||
|4<br>1|ensaios<br>clínicos<br>randomizados<br>ensaios<br>clínicos<br>randomizados|grave<sup>a</sup><br>,e<br>grave<sup>h</sup><br>,i|não grave<br> <br>não grave|grave<sup>d</sup><br>**Eventos adve**<br>não grave|grave<sup>f</sup><br>**rsos em geral (**<br>grave<sup>f,j</sup>|nenhum<br>**População com o**<br>nenhum|3728/4120<br>(90.5%)<br>**steoporose e DR**<br>35/36<br>(97.2%)|3735/41<br>10<br>(90.9%)<br>**C estágios 4**<br>35/37<br>(94.6%)|**RR 1.00**<br>(0.98<br>para<br>1.01)<br>**e 5)**<br>**RR 1.03**<br>(0.93<br>para<br>1.13)|**0 menos**<br>**por 1.000**<br>(de 18<br>menos para<br>9mais)<br>**28 mais por**<br>**1.000**<br>(de 66<br>menos para<br>123 mais)|⨁◯◯◯<br>Muito<br>baixa<br>⨁⨁◯◯<br>Baixa|CRÍTICO<br>CRÍTICO|
|4<br>1|ensaios<br>clínicos<br>randomizados<br>ensaios<br>clínicos<br>randomizados|grave<sup>a</sup><br>,e<br>grave<sup>h</sup><br>,i|não grave<br>não grave|**E**<br>grave<sup>d</sup><br>**Eventos adv**<br>não grave|**ventos adversos**<br>grave<sup>f</sup><br>**ersos graves (P**<br>grave<sup>f,j</sup>|**graves (Populaç**<br>nenhum<br>**opulação com ost**<br>nenhum|**ão com osteopo**<br>1011/4120<br>(24.5%)<br>**eoporose e DR**<br>15/36<br>(41.7%)|**rose)**<br>980/411<br>0<br>(23.8%)<br>**C estágios 4**<br>13/37<br>(35.1%)|**RR 1.03**<br>(0.95<br>para<br>1.11)<br>**e 5)**<br>**RR 1.18**<br>(0.66<br>para<br>2.13)|**7 mais por**<br>**1.000**<br>(de 12<br>menos para<br>26 mais)<br>**63 mais por**<br>**1.000**<br>(de 119<br>menos para<br>397 mais)|⨁◯◯◯<br>Muito<br>baixa<br>⨁⨁◯◯<br>Baixa|CRÍTICO<br>CRÍTICO|  
**IC:** Intervalo de confiança; **DM:** Diferença média; **RR:** Risco relativo.  
**Justificativa** :  
95  
**a.** ausência de informação quanto ao método utilizado para garantir o sigilo da alocação durante a randomização; **b.** ausência de cegamento de participantes; **c.** heterogeneidade considerável; **d.** população diferente da proposta, estudo realizado em mulheres com osteoporose na pós-menopausa. Evidência avaliada para pacientes com osteoporose e doença renal crônica em estágios avançados (4 e 5); **e.** ausência de informação de desvios da intervenção pretendida; **f.** o resultado ultrapassa a linha de nulidade; **g.** ausência de dados dos desfechos relatados; **h.** método de randomização não descrito, foi informado que a randomização foi estratificada de acordo com grupos de 5 anos; **i.** houve perda de dados balanceada entre os grupos de intervenção, no entanto o motivo não foi relatado; **j.** tamanho amostral pequeno, não teve poder suficiente para avaliar uma diferença no desfecho avaliado.  
**k.** o desfecho de DMO foi relatado de forma incompleta (sem dados do grupo de controle).  
96

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **4. REFERÊNCIAS** -->
1. Guyatt G H, Oxman A D, Vist G E, Kunz R, Falck-Ytter Y, Alonso-Coello P et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations BMJ 2008; 336 :924 doi:10.1136/bmj.39489.470347.AD.  
2. Shea, B. J., Reeves, B. C., Wells, G., Thuku, M., Hamel, C., Moran, J., Henry, D. A. (2017). AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. bmj, 358.  
3. Sterne JAC, Savović J, Page MJ, et al. RoB 2: a revised tool for assessing risk of bias in randomised trials. BMJ. Published online August 28, 2019:l4898. doi:10.1136/bmj.l4898  
4. Sterne JA, Hernán MA, Reeves BC, et al. ROBINS-I: a tool for assessing risk of bias in non-randomised studies of interventions. BMJ. 2016;355:i4919.  
5. Brasil. Ministério da Saúde. Relatório de recomendação – Ácido zoledrônico para pacientes com osteoporose com intolerância ou dificuldades de deglutição dos bisfosfonatos orais. Brasília, 2022.  
6. Brasil Ministério da Saúde. PORTARIA SCTIE/MS Nº 61, DE 19 DE JULHO DE 2022. Brasília, 2022.  
7. Brasil. Ministério da Saúde. Relatório de recomendação - Denosumabe e teriparatida para o tratamento indivíduos com osteoporose grave e falha terapêutica aos medicamentos disponíveis no Sistema Único de Saúde. Brasília, 2022.  
8. Brasil Ministério da Saúde. PORTARIA SCTIE/MS Nº 62, DE 19 DE JULHO DE 2022. Brasília, 2022.  
9. Brasil. Ministério da Saúde. Relatório de recomendação - Denosumabe para o tratamento de osteoporose e doença renal crônica em estágio 4 e 5  
10. Brasil. Ministério da Saúde. PORTARIA SCTIE/MS Nº 64, DE 11 DE JULHO DE 2022. Brasília, 2022.  
97

---

<!-- METADADOS: doenca: PCDT - Osteoporose | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**<br>**da diretriz clínica**|**Princiais**|**Tecnologias avaliadas**|**pela Conitec**|
|---|---|---|---|
|<br>**(Conitec) ou Portaria**<br>**de Publicação**|**p**<br>**alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||Ajuste da redação do<br>item<br>3.1<br>para<br>definição<br>de<br>osteoporosegrave|-|-|
||Ajuste dos critérios<br>de<br>inclusão<br>do|||
|Relatório<br>de|romosozumabe|||
|Recomendação<br>nº<br>1012/2025|considerando<br>mulheres<br>pós-<br>menopausa|-|-|
||Atualização devido à<br>incorporação<br>de<br>tecnologias no SUS|Ampliação do uso do romosozumabe<br>para o tratamento de osteoporose grave<br>e<br>em<br>falha<br>terapêutica<br>[Portaria<br>SECTICS/MS nº 40/2024; Relatório de<br>Recomendação nº920]|Exclusão<br>da<br>teriparatida<br>[Portaria SECTICS/MS nº<br>39/2024;<br>Relatório<br>de<br>Recomendação nº 920]|
|||Romosozumabe para mulheres com<br>osteoporose na pós menopausa, a partir||
|Relatório<br>de<br>Recomendação<br>nº<br>826/2023|Atualização devido à<br>incorporação<br>de<br>tecnologias no SUS|de 70 anos, que apresentam risco muito<br>alto de fratura por fragilidade e que<br>falharam (apresentaram duas ou mais<br>fraturas) com o padrão de tratamento<br>medicamentos [Portaria SCTIE/MS nº<br>166/2022].|Não possui|
|Relatório de<br>Recomendação nº<br>780/2022|Atualização devido à<br>incorporação<br>de<br>tecnologias no SUS e<br>exclusão<br>de<br>apresentação<br>farmacêutica.|Ácido zoledrônico para o tratamento de<br>pacientes<br>com<br>osteoporose<br>com<br>intolerância<br>ou<br>dificuldades<br>de<br>deglutição dos bisfosfonatos orais.<br>[Portaria<br>SCTIE/MS<br>nº<br>61/2022;<br>Relatório<br>de<br>Recomendação<br>nº<br>741/2022]<br>Teriparatida<br>para<br>o<br>tratamento<br>indivíduos com osteoporose grave e<br>falha terapêutica aos medicamentos<br>disponíveis no Sistema Único de Saúde<br>[Portaria SCTIE/MS nº 62/ 2022;<br>Relatório<br>de<br>Recomendação<br>nº<br>742/2022]|Denosumabe<br>para<br>o<br>tratamento indivíduos com<br>osteoporose grave e falha<br>terapêutica aos medicamentos<br>disponíveis no Sistema Único<br>de Saúde<br>[Portaria<br>SCTIE/MS<br>nº<br>61/2022;<br>Relatório<br>de<br>Recomendação nº 742/2022]<br>Denosumabe<br>para<br>o<br>tratamento de osteoporose e<br>doença renal crônica em<br>estágios 4 e 5 [Portaria<br>SCTIE/MS<br>nº<br>64/2022;<br>Relatório de Recomendação<br>nº 740/2022]|
|Portaria SAS/MS nº<br>451, de 9 de junho de<br>2014|Atualização<br>do<br>conteúdo do PCDT|-|-|  
98

---

