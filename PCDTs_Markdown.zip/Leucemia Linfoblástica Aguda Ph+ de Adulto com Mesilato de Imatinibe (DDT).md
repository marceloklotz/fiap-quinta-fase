<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
PORTARIA CONJUNTA Nº 21, DE 10 DE DEZEMBRO DE 2021.  
Aprova as Diretrizes Diagnósticas e Terapêuticas – Mesilato de Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo do Adulto.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a leucemia linfoblástica aguda cromossoma Philadelphia positivo no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento de adultos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 678/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 682 – Novembro de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e Considerando a avaliação técnica do Departamento de Gestão de Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Ficam aprovadas as Diretrizes Diagnósticas e Terapêuticas – Mesilato de Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo do Adulto.  
Parágrafo único. As diretrizes objeto deste artigo, que contêm o conceito geral de leucemia linfoblástica aguda cromossoma Philadelphia positivo do adulto, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da leucemia linfoblástica aguda cromossoma Philadelphia positivo do adulto.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria SAS/MS n<sup>o</sup> 312, de 27 de março de 2013, publicada no Diário Oficial da União nº 60, de 28  de março de 2013, seção 1, páginas 92.  
Art. 5º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
HÉLIO ANGOTTI NETO  
ANEXO

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
LEUCEMIA LINFOBLÁSTICA AGUDA CROMOSSOMA PHILADELPHIA POSITIVO DE ADULTOS

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
A Leucemia Linfoblástica Aguda (LLA) caracteriza-se pelo acúmulo de células imaturas da linhagem linfoide, na medula óssea, sangue periférico e órgãos linfoides. A LLA é classificada na categoria de neoplasias de linhagem B ou T<sup>1,2</sup> . A LLA tem algumas variantes biologicamente distintas, entre elas a leucemia linfoblástica aguda cromossoma Philadelphia positivo (LLA Ph+)<sup>3,4</sup> .  
A Organização Mundial da Saúde (OMS) classifica a LLA Ph+ como t(9;22)(q34;q11.2) ou BCR-ABL1 positivo<sup>3,4</sup> . Isto se deve a que essa anormalidade cromossômica envolve o gene ABL1 (gene da leucemia de Abelson), localizado no cromossoma 9, e o gene BCR (“breakpoint cluster region”, em Inglês = região de ponto de quebra), no cromossoma 22<sup>2</sup> . O gene BCR-ABL1 é devido a uma translocação, ocorrida durante a divisão celular na medula óssea, entre os cromossomas 9 e 22<sup>5,6</sup> . Neste subtipo de LLA, as células com material genético mutante que se multiplicam são as que possuem o cromossoma Philadelphia<sup>3,4</sup> . A positividade para o gene BCR-ABL1, detectado por exame molecular, geralmente indica pior prognóstico para a doença<sup>7</sup> , porém o surgimento de novas terapias, a incorporação do monitoramento da doença residual mínima (DRM) e a maior segurança do transplante de células-tronco hematopoéticas (TCTH) alogênico têm trazido melhores resultados em caso de pacientes já tratados de LLA e de pacientes idosos com LLA.<sup>6</sup>  
A literatura especializada relata que a prevalência da LLA Ph+ é de 3% entre crianças com menos de 15 anos, aumentando para cerca de 30% a partir dos 30 anos e ocorrendo em mais de 50% dos casos de LLA diagnosticados após os 65 anos <mark>de idade</mark><sup>8,9</sup> . No Brasil, o Instituto Nacional de Câncer (INCA) estima que, para cada ano do triênio 2020/2022, sejam diagnosticados 5.920 casos novos de leucemia entre homens e 4.890, entre mulheres<sup>10</sup> . Esses números correspondem a um risco estimado de 5,67 casos novos para cada 100 mil homens e 4,56 casos novos para cada 100 mil mulheres<sup>10</sup> .  
A LLA Ph+ está associada a características clínicas adversas e persistência de DRM. A apresentação da LLA Ph+ é semelhante à de outras LLA com história de início agudo (evolução de menos de 3 meses) caracterizada por febre (50%), sangramento (50%), sintomas inespecíficos (25%) e dor osteoarticular (15%). Ao exame físico inicial, síndrome anêmica (80%100%), hepatomegalia (40%) e esplenomegalia (60%) são comuns, e o acometimento do sistema nervoso central (SNC) é menos frequente (1%-3%). O diagnóstico é feito por exames capazes de identificar a presença do cromossoma Ph+ no sangue periférico (SP) ou na medula óssea (MO): citogenético,  hibridização _in situ_ ( _In Situ Hybridization -_ ISH, sigla em Inglês) ou técnica de biologia molecular. A Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) recomenda que o diagnóstico seja feito, também, por técnica de biologia molecular, chamada reação em cadeia da polimerase com transcrição reversa em tempo real ( _Real Time Polymerase Chain Reaction_ - RT-PCR, sigla em Inglês), qualitativa e quantitativa<sup>11</sup> .  
O tratamento da LLA Ph+ é poliquimioterapia, cujo protocolo é padronizado pelo hospital, com ou sem TCTH. O mesilato de imatinibe, um inibidor de tirosinoquinase (ITQ; em Inglês, TKI – _tyrosine kinase inhibito_ r) é um composto 2-fenil-aminopirimidina que inibe seletivamente essa enzima<sup>12-14</sup> . Este medicamento é associado tanto à poliquimioterapia quanto ao TCTH<sup>15,16</sup> .  
Historicamente, pacientes com LLA Ph+ são de mau prognóstico, com uma taxa de sobrevida livre de doença (SLD) de 10%-20%. O TCTH com doador compatível foi amplamente utilizado como tratamento de consolidação, melhorando essa taxa de SLD para 30%-65% entre os que recebiam o TCTH em primeira remissão completa (RC). Em casos de primeira RC, o TCTH foi curativo em uma pequena proporção de pacientes, com apenas 5%-17% de SLD. A utilização de inibidor da tirosinoquinase (ITQ) tem revolucionado a terapia das leucemias Ph+<sup>16</sup> .  
<mark>Um estudo que incluiu 268 pacientes adultos com LLA Ph+, distribuídos em dois braços (poliquimioterapia de intensidade reduzida mais imatinibe em dose alta</mark> _<mark>versus</mark>_ <mark>HiperCVAD mais imatinibe em dose padrão), obteve, em um seguimento médio de 4,8 anos, 5 anos de sobrevida livre de eventos e uma sobrevida global estimada, respectivamente, de 37,1% e 45,6%, sem diferença estatisticamente significativa  entre os dois braços. O TCTH alogênico associou-se a um significante benefício na sobrevida livre de recaída leucêmica.</mark><sup>17</sup>  
A presença da t(9;22)(q34:q11.2), abrangendo os genes BCR e ABL1, é predominante em adultos e está associada a uma sobrevida livre de doença de 10%-20%, a despeito de tratamentos intensivos<sup>8</sup> <mark>. A despeito da idade, a recaída leucêmica é uma situação intransponível em muitos casos, sendo que a maior taxa de recaída observada entre adultos com LLA é possivelmente devida à doença ser de alto risco, do ponto de vista citogenético e molecular, e m</mark> anter DRM persistente.<sup>5</sup>  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Estas Diretrizes visam a estabelecer os critérios de uso do mesilato de imatinibe no tratamento da leucemia linfoblástica aguda Ph+ e do linfoma linfoblástico Ph+, com o objetivo de orientar o que é válido e não válido técnico-cientificamente, com base em evidências que garantam a segurança dos tratamentos ~~,~~ e as efetividade e reprodutibilidade terapêuticas, para orientar condutas e protocolos assistenciais. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
C91.0 Leucemia Linfoblástica Aguda  
C83.5 Linfoma linfoblástico

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
O diagnóstico de LLA Ph+ é estabelecido pela presença de 20% ou mais de linfoblastos na medula óssea. A avaliação diagnóstica compreende<sup>4,6,7,10</sup> :  
✓ Citomorfologia (se necessário, com citoquímica) por microscopia ótica do sangue periférico (SP) e medula óssea (MO);  
✓ Biópsia de medula óssea com exame de imuno-histoquímica, indicada em caso de aspirado medular "seco" e em caso  
de quantidade de blastos insuficiente no sangue periférico para proceder-se à imunofenotipagem;  
- ✓ Citomorfologia do líquor;  
- ✓ Imunofenotipagem das células blásticas do SP, MO ou líquor; e  
✓ Identificação do cromossoma Philadelphia no SP ou na MO por exame de citogenética convencional ou FISH, ou do oncogene BCR-ABL1 por PCR.  
A LLA pode ser classificada em três tipos principais: Linfoma/ leucemia linfoblástica de células B, sem outra especificação; Linfoma/ leucemia linfoblástica de células B, com anormalidades genéticas recorrentes, com nove subtipos possíveis; e Linfoma/leucemia linfoblástica de células T ( **Quadro 1** ).  
**Quadro 1** - Classificação da Leucemia Linfoblástica Aguda da Organização Mundial da Saúde  
|**Classificação de Leucemia Linfoblástica Aguda**<sup>**a**</sup>|
|---|
|**Linfoma/ leucemia linfoblástica de células B, sem outra especificação**|
|**Linfoma/ leucemia linfoblástica de células B, com anormalidades genéticas recorrentes**|
|Linfoma/leucemia linfoblástica de células B com hipodiploidia|
|Linfoma/ leucemia linfoblástica de células B com hiperdiploidia|
|Linfoma/ leucemia linfoblástica de células B com t(9;22)(q34;q11.2)[BCR-ABL1]|
|Linfoma/ leucemia linfoblástica de células B com t(v11q23)[rearranjo MLL]|
|Linfoma/ leucemia linfoblástica de células B com t(12;21)(p13;q22)[ETV6-RUNX1]<br>Linfoma/ leucemia linfoblástica de células B com t(1;19)(q23;p13.3)[TCF3-PBX1]<br>Linfoma/ leucemia linfoblástica de células B com t(5;14)(q31;q32)[IL3-IGH]<br>Linfoma/ leucemia linfoblástica de células B com amplificação intracromossomial do cromossomo 21 (iAMP21) b<br>Linfoma/leucemia linfoblástica de células B com translocações que envolvem tirosinoquinase ou receptores de citoquinas<br>(‘BCR-ABL1)<sup>**b**</sup>|
|**Linfoma/ leucemia linfoblástica de células T**|
|Linfoma/ leucemia linfoblástica precoces precursoras de células T|  
> **a** Segundo a classificação da Organização Mundial da Saúde de leucemias agudas e neoplasias mieloides revisada, 2016.4  
> **b** _provisional entity_ (termo em Inglês para ‘temporária’)  
**NOTA 1:** Na LLA Ph1, o subtipo de transcrito BCR-ABL1 é o p190, em 60%-80% dos casos. O transcrito p210 ocorre de 20%-30% dos casos. Em menos de 5% dos casos, ambos os transcritos podem ser detectados. Não se identificou qualquer tipo de diferença clínica ou laboratorial entre os casos com diferentes transcritos. O subtipo de transcrito pode ser determinado tanto pela técnica de FISH quanto pela técnica de biologia molecular.  
**NOTA 2:** Inexiste um aspecto morfológico ou citoquímico único que distinga a LLA Ph+ de outros tipos de LLA. A imunofenotipagem da LLA B com t(9;22) é tipicamente CD10+, CD19+ e TdT+. A expressão dos antígenos mieloides associados ao CD13 e ao CD33 é frequente. O CD117 é negativo e o CD25+ é fortemente associado à LLA B Ph+, principalmente nos adultos. Raros casos de LLA t(9;22) são de precursor T<sup>6</sup> . A distribuição das categorias de LLA e LLb (Leucemia/linfoma linfoblástico) são linhagem B (85%), linhagem T (10% a 15%) e linhagem _Natural Killer_ (NK) (<1%). O imunofenótipo é usado para classificar a LLA/LLb de células T e entidades relacionadas. A categoria leucemia linfoblástica aguda das células T/linfoma linfoblástico das células T (LLA/LLb-T) é definida pela presença de CD3 citoplasmático ou de superfície, e pode ser subdividido em subtipos cortical e medular com base em combinações de marcadores de linhagem T. Os marcadores de células B e mieloides que definem a linhagem são negativos. Leucemia linfoblástica precursora de células T precoce é uma entidade diagnóstica provisória na classificação da OMS de 2016 que é sempre CD7 positivo e geralmente positivo para CD2 e CD3 citoplasmático;  
variavelmente positivo para CD4 e CD5; CD1a e CD8 negativos; e positivo para pelo menos um dos seguintes: CD34, CD117 (KIT), HLA-DR, CD13, CD33, CD11b ou CD65.  
**NOTA 3:** Deve-se proceder ao exame de histocampatibilidade, ao diagnóstico de LLA ou LLb, com vistas à inscrição do doente no Registro Nacional de Receptores de Medula Óssea (REREME), antecipando a necessidade de uma eventual busca no Registro Nacional de Doadores de Medula Óssea (REDOME).

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Serão incluídos nestas DDT os pacientes que preencherem todos os critérios abaixo:  
- Idade de 19 ou mais anos;  
- diagnóstico de LLA ou de Linfoma linfoblástico B (LLb), ambos com a presença do cromossoma Philadelphia [t(9;22)(q34;q11.2) ou rearranjo BCR-ABL1]; **ou**  
- diagnóstico de recidiva de LLA ou de LLb, ambos com a presença do cromossoma Philadelphia [(t(9;22)(q34;q11.2) ou rearranjo BCR-ABL1] e sem tratamento anterior com o mesilato de imatinibe.  
Devem ser observados os critérios estabelecidos no Regulamento Técnico do Sistema Nacional de Transplantes (SNT) para a indicação de transplante de células-tronco hematopoéticas (TCTH) alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, ou autólogo de medula óssea ou de sangue periférico, devendo todos os potenciais receptores estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS.  
**NOTA** : Pacientes com menos de 19 anos serão incluídos nas Diretrizes Diagnósticas e Terapêuticas - Tratamento da Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Criança e Adolescente com Mesilato de Imatinibe.<sup>18</sup>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Serão excluídos destas DDT os pacientes:  
- Sem comprovação do cromossoma Ph+ [t(9;22)(q34;q11.2) ou rearranjo BCR-ABL1 por exame genético ou molecular];  
- com teste de gravidez positivo e decidida a prosseguir com a gestação, a despeito de saber que tem uma doença grave e  
- letal, se não tratada; **ou**  
- que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicação absoluta ao uso do mesilato de imatinibe ou a procedimento, inclusive o TCTH, preconizado nestas Diretrizes.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
O tratamento de LLA é definido pelo protocolo terapêutico adotado no hospital. Os pacientes são classificados ao diagnóstico e se enquadram nos protocolos específicos para os doentes sem tratamento prévio (recém-diagnosticados) e recidivados.  
Os detalhes das fases da poliquimioterapia de indução, consolidação, reindução e manutenção - com quimioterapia intratecal e, quando adotada no protocolo do hospital, radioterapia do SNC - variam de acordo com cada protocolo de tratamento.  
O mesilato de imatinibe é preconizado em primeira linha de tratamento da LLA Ph+ de adultos já a partir da fase de indução<sup>16</sup> , ou em caso de recidiva sem uso prévio desse medicamento.  
Devem ser realizados os seguintes exames basais (antes do início do tratamento):  
- hemograma com contagem de plaquetas;  
- exames sorológicos para hepatites B e C e para HIV;  
- dosagem sérica das aminotransferases/transaminases (AST/TGO, ALT/TGP), bilirrubinas, fosfatase alcalina e  
- desidrogenase láctica (DHL);  
- dosagem sérica de glicose, ureia, creatinina, ácido úrico, sódio, potássio e cálcio;  
- dosagem sérica de gonadotrofina coriônica (beta-HCG), em casos de mulheres em idade fértil;  
- estudo da coagulação sanguínea, incluindo fibrinogênio;  
- exame parasitológico de fezes;  
- exame sumário de urina;  
- eletrocardiograma e ecocardiograma com fração de ejeção; e  
- radiografia simples de tórax em PA e perfil.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
A profilaxia da invasão do SNC é obtida com quimioterapia intratecal, aplicada conjuntamente com a quimioterapia sistêmica, conforme o protocolo terapêutico adotado no hospital.  
O objetivo de se proceder à profilaxia no SNC com a aplicação de quimioterapia intratecal é prevenir recidiva leucêmica em local inacessível à quimioterapia sistêmica por causa da barreira hemato-encefálica<sup>19</sup> . A quimioterapia intratecal é indicada durante todo o curso do tratamento, nas fases de indução, consolidação e manutenção, independentemente de haver cromossomo Ph e idade do paciente<sup>16,19</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
O transplante de células-tronco  hematopoéticas (TCTH) alogênico continua sendo indicado, com qualquer tipo de doador (familiar idêntico e não idêntico, não aparentado idêntico ou sangue de cordão umbilical), em primeira remissão da LLA<sup>20</sup> .  
Um estudo mostrou que o TCTH apresentou melhores resultados que a quimioterapia em pacientes com DRM positiva, independentemente dos fatores de risco basais<sup>20</sup> . Porém, o resultado do TMO alogênico é melhor em pacientes com DRM negativa.  
Por sua vez, o TMO autólogo somente poderá ser considerado em pacientes sem doença residual mínima (DRM negativa)<sup>16,21,22</sup> . Dessa forma, ambos os tipos transplante podem ser indicados em caso de primeira remissão de LLA Ph+ com DRM negativa.  
A indicação de TCTH deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
A dose de imatinibe é de 400–600 mg/dia, por via oral<sup>23</sup> , dependendo do protocolo adotado no hospital e da toxicidade, inclusive intolerância, apresentada pelo paciente. Ele pode ser administrado em dose única, ou em dose dividida, de manhã e à  
noite, e deve ser administrado com comida e um grande copo de água. Caso não seja possível a deglutição dos comprimidos, eles não devem ser esmagados. Nesse caso, devem ser dispersos em água ou suco de maçã, sendo que o número de comprimidos deve estar em volume adequado de líquido e misturado com uma colher (50ml de líquido para cada 100mg de comprimido). A suspensão deve ser ingerida imediatamente após a desintegração do comprimido<sup>23</sup> .  
A data do início do uso de imatinibe deve ser de acordo com o protocolo adotado no hospital no qual o paciente for atendido, habitualmente no D15 (15º dia) da fase de indução. Em caso de TCTH, o imatinibe é habitualmente iniciado a partir do 30º dia do transplante. O tempo de uso pós-TCTH, apesar de não uniforme, tem sido adotado pela maioria dos hospitais por pelo menos 12 meses<sup>16</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
A literatura especializada relata que incluir um ITQ na quimioterapia da LLA Ph+ tanto na fase de indução como na de consolidação gera altas taxas de remissão leucêmica completa e de sobrevida dos pacientes<sup>19</sup> .  
Estudos mostraram aumento de sobrevida com a associação de imatinibe à poliquimioterapia, resultado este que pode ser ainda maior quando essa associação é seguida de TCTH<sup>16</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Para a avaliação da resposta ao tratamento, inclusive com o mesilato de imatinibe, é necessário monitorar a resposta citogenética ou molecular, conforme o protocolo adotado no hospital.  
A doença residual mínima (DRM) é um fator preditivo de recaída leucêmica, e a sua mensuração pode ser realizada por meio de citometria de fluxo (imunofenotipagem) e de RT-PCR<sup>24-28</sup> .  
Um ponto de corte comumente utilizado para definir a positividade para a DRM é 0,01%. Assim, pacientes que apresentam valores inferiores a 0,01% têm chance elevada de permanecer em remissão com a terapia de manutenção. Adicionalmente, a detecção de DRM anteriormente ao transplante de células-tronco hematopoéticas alogênico está associada a um aumento do risco de recidiva pós-transplante<sup>29</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Os eventos adversos associados ao uso do imatinibe podem ser descritos de acordo com a seguinte categorização<sup>30</sup> :  
**COMUNS** (21%-100%): Náusea/diarreia, retenção hídrica, edema periférico, edema periorbitário, mielossupressão (neutrófilos/plaquetas), fadiga, _rash_ , câimbras musculares, artralgia. Retardo do crescimento, principalmente em pacientes impúberes.  
**OCASIONAIS** (5%-20%): Febre, tremores e calafrios, síndrome tipo resfriado, dor abdominal, cefaleia, dor no peito, dispepsia/queimação, flatulência, vômitos, zumbidos, insônia, constipação, sudorese noturna, ganho de peso, disgeusia, anemia, anorexia, mialgia, hemorragia, disfagia, esofagite, odinofagia, mucosite/estomatite, tosse, epistaxe, prurido, ascite, neuropatia (motora ou sensorial) e, mais tardiamente, despigmentação (vitiligo) e alopecia. Diminuição da densidade óssea e aumento do volume da trabécula óssea.  
**RAROS** (<5%): Angioedema, aumento da pressão intracraniana, edema cerebral, desidratação, elevação das transferases/transaminases, fosfatase alcalina e bilirrubina, derrame pleural, edema pulmonar, pneumonite, dispneia, edema pericárdico, dermatite exfoliativa, hemorragia/sangramento sem trombocitopenia de grau 3 ou 4 - incluindo o SNC, olho, pulmão e trato gastrointestinal -, conjuntivite, borramento da visão, olho seco, hipocalemia, hiponatremia, hipofosfatemia, ansiedade, alteração do humor, infecções. De aparecimento mais tardio, destacam-se: hepatotoxicidade, toxicidade renal, insuficiência renal, rotura esplênica, artrite, osteonecrose, fraqueza muscular (descrita como temporária e nas extremidades inferiores), disfunção do ventrículo esquerdo (secundária a dano nos miócitos), trombose/tromboembolismo.  
Todos os eventos adversos relacionados ao uso do imatinibe devem ser valorizados e registrados, pois podem contribuir para uma sub-utilização deste medicamento. O emprego do imatinibe pode ser mantido na vigência de leve efeito adverso, desde que haja acompanhamento regular com o hematologista; porém, a ocorrência de efeito adverso moderado ou grave exige a suspensão do uso, passível de reintrodução na dependência do dano causado e da vontade do paciente ou seu responsável legal.<sup>30</sup>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
O uso concomitante do imatinibe com outros medicamentos – principalmente com os que também podem produzir depressão da medula óssea, hepatotoxicidade e nefrotoxicidade – deve ser cuidadosa e rigorosamente monitorado. Devem-se buscar exaustivamente possíveis interações de qualquer medicamento a ser administrado concomitantemente ao imatinibe.<sup>30</sup>  
O imatinibe é metabolizado primariamente pela enzima CYP3A4. Dessa forma, é necessário evitar o uso concomitante com medicamentos que sejam indutores dessa enzima, e considerar até 50% de aumento da dose se essa co-administração não puder ser evitada. Logo, medicamentos metabolizados por enzimas dessa classe devem ser evitados ou concomitantemente usados com cautela, objetivando-se evitar interações medicamentosas e a amplificação de eventos.<sup>30-32</sup>  
As principais interações medicamentosas do imatinibe estão descritas no **Quadro 2.**  
**Quadro 2** **_-_** Interações medicamentosas do imatinibe  
|**Aumenta os níveis plasmáticos do imatinibe**|**Diminui os níveis p**|**lasmáticos do imatinibe**|
|---|---|---|
|Cetoconazol<br>Ciclosporina<br>Claritromicina<br>Eritromicina, Itraconazol<br>Toranja (_grapefruit_)|Carbamazepina<br>Dexametasona<br>Erva de São João|Fenobarbital<br>Fenitoína<br>Rifampicina<br>Rifabutina|  
Fonte: Eurofarma<sup>33</sup>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
O Relatório de Recomendação nº 584/2020 da Conitec trata da avaliação de dasatinibe para adultos com leucemia linfoblástica aguda cromossomo Philadelphia positivo resistentes/intolerantes ao mesilato de imatinibe<sup>34</sup> . Os resultados de Consulta Pública sobre o tema foram apresentados à 93ª Reunião Ordinária do Plenário da Conitec, realizada em dezembro de 2020, quando os membros presentes deliberaram por unanimidade recomendar a não ampliação de uso do dasatinibe. Assim, a Portaria Nº 67/SCTIE/MS, de 30 de dezembro de 2020<sup>35</sup> , tornou pública a decisão de não ampliar o uso do dasatinibe em adultos com leucemia linfoblástica aguda cromossomo Philadelphia positivo resistentes/intolerantes ao mesilato de imatinibe, no âmbito do Sistema Único de Saúde - SUS.  
O ponatinibe, um ITQ de 3ª geração, não teve demanda para avaliação pela Conitec, pois, à época da reunião de escopo destas DDT, este medicamento não tinha registro na Agência Nacional de Vigilância Sanitária (Anvisa), de modo que sua avaliação não pôde ser feita.  
Anticorpos monoclonais indicados para o tratamento da LLA Ph+ também não foram demandados para avaliação pela Conitec.  
Esta versão das DDT poderá ser atualizada a qualquer tempo, demandando também a atualização da literatura especializada e avaliação de novas tecnologias pela Conitec.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Para o monitoramento laboratorial, devem ser realizados os exames previstos no protocolo utilizado no hospital, incluindo o mielograma, os exames citogenéticos e a determinação quantitativa da DRM na medula óssea. Controles periódicos do líquor serão realizados por ocasião das aplicações de quimioterapia intratecal.  
Não se procede ao monitoramento dos níveis séricos do imatinibe.  
O monitoramento de doença residual mínima (DRM) deve ser realizado conforme previsto no protocolo adotado pelo hospital, para a identificação de pacientes que precisem intensificar o tratamento pelo TCTH<sup>31,33</sup> . Quando a intenção é reduzir a intensidade da quimioterapia, o ideal é utilizar como parâmetro o método mais sensível para se detectar a DRM. Portanto, a resposta terapêutica adequada em caso de LLA Ph+ significa ausência de BCR-ABL1 na medula óssea, avaliado pela técnica de PCR (sensibilidade até 106).<sup>24</sup>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Devem ser observados os critérios de inclusão e exclusão de pacientes para o uso do mesilato de imatinibe, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso desse medicamento.  
Casos de leucemia linfoblástica aguda, inclusive LLA Ph+ e LLb Ph+, devem ser atendidos em hospitais habilitados em Oncologia e com porte tecnológico suficiente para diagnosticar, tratar e acompanhar clínica e laboratorialmente os pacientes.  
Além da familiaridade que esses hospitais guardam com o tratamento, o ajuste das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento aos pacientes e muito facilita as ações de controle e avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos); e a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos pacientes.  
Para a autorização do TCTH alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados submetidos a TCTH alogênico, originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), radioterápicos e quimioterápicos  (Grupo 03, Subgrupo 04), cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
**NOTA 1** – O mesilato de imatinibe, de uso preconizado nestas Diretrizes, é, hoje, adquirido pelo Ministério da Saúde e fornecido pelas Secretarias de Saúde para os hospitais e, por esses, aos usuários do Sistema Único de Saúde (SUS). Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Assim, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de outros medicamentos contra a LLA e LLb, previstos nos respectivos protocolos que adotam e que eles, livremente, padronizem, adquiram e forneçam, cabendo-lhes codificar e registrar conforme o respectivo procedimento seja o hospital público ou privado, com ou sem fins lucrativos.  
**NOTA 2** – O uso do mesilato de imatinibe é associado aos outros antineoplásicos do esquema terapêutico e, assim, o seu fornecimento pode ser concomitante à autorização de APAC para os seguintes procedimentos da tabela do SUS para a quimioterapia de leucemia linfoblástica aguda ou linfoma linfoblástico, em não tendo havido uso prévio ao respectivo procedimento:  
03.04.06.023-2 – Quimioterapia de leucemia linfoide/linfoblástica aguda, linfoma linfoblástico, leucemia mieloide aguda  
e leucemia promielocítica aguda - 1ª linha – fases terapêuticas iniciais;  
03.04.06.024-0 –  Quimioterapia de leucemia linfoide/linfoblástica aguda, linfoma linfoblástico, leucemia mieloide aguda e leucemia promielocítica aguda - 1ª linha – fase de manutenção;  
03.04.06.008-9 – Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 2ª linha  
03.04.06.009-7 – Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 3ª linha.  
03.04.06.010-0 – Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 4ª linha.  
**NOTA 3 –** Como o mesilato de imatinibe é comprado pelo Ministério da Saúde e fornecido aos hospitais habilitados em oncologia no SUS pela Assistência Farmacêutica das Secretarias Estaduais de Saúde, não pode ser autorizada APAC para procedimento de quimioterapia, _quando o seu uso é isolado_ , como, por exemplo, para manutenção no pós-transplante. Neste caso, o atendimento ambulatorial pode ser ressarcido como consulta especializada (procedimento 03.01.01.007-2 - Consulta Médica em Atenção Especializada).

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado nestas Diretrizes, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
1. Silva BN, Felipe MFB, Martins ML, Dias RG, Nascimento TS, Alves KRL. Leucemia linfoblástica aguda  
philadelphia positivo de linhagem B: relato de caso. Hematol Transfus Cell Ther. 2020; 42(S2): S1-S567  
2. Rafei H, Kantarjian HM, Jabbour EJ. Recent advances in the treatment of acute lymphoblastic leukemia.  
Leukemia and Lymphoma. 2019;60(11):2606-2621. doi: 10.1080/10428194.2019.1605071.  
3. Swerdlow SH, Campo E, Pileri SA, Lee Harris N, Stein H, Siebert R, et al. The 2016 revision of the World  
Health Organization classification of lymphoid neoplasms. Blood. 2016; 127(20):2375-2390.  
4. Arber DA, Orazi A, Hasserjian R, Thiele J, Borowitz MJ, Le Beau MM, et al. The 2016 revision to the World  
Health Organization classification of myeloid neoplasms and acute leukemia. Blood. 2016; 127(20):2391–405.  
5. Thomas X, Dombret H. Treatment of Philadelphia chromosome-positive adult acute lymphoblastic leukemia.  
Leukemia and Lymphoma. 2008, (1): 118–122.  
6. DeAngelo DJ, Jabbour E, Advani A. Recent Advances in Managing Acute Lymphoblastic Leukemia. Am Soc  
Clin Oncol Educ B. 2020; 40: 330-342. doi: 10.1200/EDBK_280175.  
7. Yanada M, Takeuchi J, Sugiura I, Akiyama H, Usui N, Yagasaki F, et al. High complete remission rate and  
promising outcome by combination of imatinib and chemotherapy for newly diagnosed BCR-ABL-positive acute lymphoblastic leukemia: A phase II study by the Japan adult leukemia study group. J Clin Oncol. 2006, 24(3); 460-466.  
8. Schaffel R, Simões BP. Leucemia Linfoblástica Aguda Filadélfia positiva. Revista Brasileira de Hematologia e  
Hemoterapia, 2008, 30(suplemento 1):52-5.  
9. Ministério de Salud (Chile). Subsecretaría de Salud Pública. Protocolo Clínico Leucemia Linfoblástica Aguda Philadelphia Positivo en Mayores de 15 años. Disponível em: https://www.sochihem.cl/site/docs/PROTOCOLO_MINSAL1.pdf. Acesso em 04/10/2021.  
10. Brasil. Ministério da Saúde. Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA). Estimativa 2020: Incidência de Câncer no Brasil. Rio de Janeiro: INCA; 2020. 130 p.  
11. Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias em Saúde - Conitec. Relatório de Recomendação nº 475 - Reação em cadeia da polimerase – transcriptase reversa (RT-PCR) qualitativa e quantitativa (RTqPCR) e Hibridização in situ (ISH) para o diagnóstico e monitoramento da Leucemia Mieloide Crônica (LMC) e da Leucemia Linfoblástica Aguda cromossoma Philadelphia positivo (LLA Ph+). 2019.  
12. Gruber F, Mustjoki S, Porkka K. Impact of tyrosine kinase inhibitors on patient outcomes in Philadelphia chromosome-positive acute lymphoblastic leukaemia. British Journal of Haematology. 2009, 145(5):581-97. doi: 10.1111/j.1365-2141.2009.07666.  
13. Wieduwilt MJ. How should we treat older adults with Ph+ adult ALL and what novel approaches are being investigated? Best Practice and Research: Clinical Haematology. 2017, 30(3):201-211. doi: 10.1016/j.beha.2017.07.001.  
14. Liu-Dumlao T, Kantarjian H, Thomas DA, O’Brien S, Ravandi F. Philadelphia-positive acute lymphoblastic leukemia: Current treatment options. Curr Oncol Rep. 2012; 14(5):387-394.  
15. DeFilipp Z, Langston AA, Chen Z, Zhang C, Arellano ML, El Rassi F, et al. Does Post- Transplant Maintenance Therapy With Tyrosine Kinase Inhibitors Improve Outcomes of Patients With High-Risk Philadelphia Chromosome-Positive Leukemia? Clin Lymphoma, Myeloma Leuk. 2016, 16(8):466-471. doi: 10.1016/j.clml.2016.04.017.  
16. National Comprehensive Cancer Network. NCCN Clinical Practice Guidelines in Oncology: Acute Lymphoblastic Leukemia. Version 2.2021. Disponível em <u>https://www.nccn.org/professionals/physician_gls/pdf/all.pdf. Acesso em 26/09/2021.</u>  
17. Chalandon Y, Thomas X, Hayette S, Cayuela JM, Abbal C, Huguet F, et al. Randomized study of reducedintensity chemotherapy combined with imatinib in adults with Ph- positive acute lymphoblastic leukemia. Blood. 2015, 125(24):3711-9.  
18. Ministério da Saúde (Brasil). Portaria Conjunta SAES/SCTIE nº 11, de 02 de julho de 2021. Diretrizes diagnósticas e terapêuticas - Tratamento da leucemia linfoblástica aguda cromossoma Philadelphia positivo de crianças e adolescentes com mesilato de imatinibe.  
19. Hatta Y, Hayakawa F, Yamazaki E. JSH practical guidelines for hematological malignancies, 2018: I. leukemia-3. acute lymphoblastic leukemia/lymphoblastic lymphoma (ALL/LBL). Int J Hematol. 2020;112(4):439-458. doi:10.1007/s12185-020-02965-z.  
20. Webster JA, Luznik L, Tsai HL, Imus PH, DeZern AE, Pratz KW, et al. Allogeneic transplantation for Ph1 acute lymphoblastic leukemia with posttransplantation cyclophosphamide. Blood Adv. 2020;4(20):5078–88.  
21. Gorin NC, Labopin M, Piemontese S, Arcese W, Santarone S, Huang H, et al. T-cell- replete haploidentical transplantation versus autologous stem cell transplantation in adult acute leukemia: A matched pair analysis. Haematologica. 2015; 100(4):558-564.  
22. Hallböök H, Hägglund H, Stockelberg D, Nilsson PG, Karlsson K, Björkholm M, et al. Autologous and allogeneic stem cell transplantation in adult ALL: The Swedish Adult ALL Group experience. Bone Marrow Transplant. Bone Marrow Transplant, 35(12):1141-8, 2005.  
23. Glivec [package insert]. São Paulo, BR: Novartis Biociêcias S/A; 2021. Disponível em https://portal.novartis.com.br/upload/imgconteudos/2258.pdf. Acesso em 26/09/2021.  
24. Schrappe M. Detection and management of minimal residual disease in acute lymphoblastic leukemia. Hematol Am Soc Hematol Educ Progr. 2014;2014(1):244-249. doi:10.1182/asheducation-2014.1.244.  
25. Pfeifer H, Cazzaniga G, van der Velden VHJ et al. Standardisation and consensus guidelines for minimal residual disease assessment in Philadelphia-positive acute lymphoblastic leukemia (Ph + ALL) by real-time quantitative reverse transcriptase PCR of e1a2 BCR-ABL1. Leukemia. Springer Nature Limited 2019. https://doi.org/10.1038/s41375-019-0413-0.  
26. Arunachalam AK, Janet NB, Korula A et al. Prognostic value of MRD monitoring based on BCR-ABL1 copy numbers in Philadelphia chromosome positive acute lymphoblastic leucemia. Leuk Lymphoma. 2020 Dec;61(14):34683475. doi: 10.1080/10428194.2020.1811272. Epub 2020 Aug 27.  
27. Delbuono E, Maekawa YH,  Latorre MRDO, Seber A, Petrilli AS, Braga JAP, Lee MLM. Simplified flow cytometric assay to detect minimal residual disease in childhood with acute lymphoblastic leucemia. Rev. Bras. Hematol. Hemoter. 30 (4) • Aug 2008 • https://doi.org/10.1590/S1516-84842008000400010.  
28. Hoelzer D. Monitoring and Managing Minimal Residual Disease in Acute Lymphoblastic. 2013 ASCO  
EDUCATIONAL BOOK | asco.org/edbook.  
29. Campana D. Minimal residual disease in acute lymphoblastic leukemia. Hematol Am Soc Hematol Educ Progr.  
2010;2010:7-12. doi:10.1182/asheducation-2010.1.7.  
30. Mesilato de Imatinibe [package insert]. São Paulo, BR: EMS S/A; 2017.  
31. Brasil. Ministério da Saúde. Portaria nº 312/SAS/MS, de 27 de março de 2013. Diretrizes Diagnósticas e  
Terapêuticas - Tratamento da Leucemia Linfoblástica Ph+ de Adulto com Mesilato de Imatinibe.  
32. Brasil. Ministério da Saúde. Portaria Conjunta nº 11/SAES e SCTIE/MS, de 02 de julho de 2021. Mesilato de  
Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes.  
33. Mesilato de Imatinibe [package insert]. São Paulo, BR: Eurofarma Laboratórios S.A.; 2015.  
34. Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias em Saúde - Conitec. Relatório de Recomendação nº 584 - Dasatinibe para adultos com leucemia linfoblástica aguda cromossomo Philadelphia positivo resistentes/Intolerantes ao mesilato de imatinibe. 2020.  
35. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos. Portaria Nº 67/SCTIE/MS, de 30 de dezembro de 2020.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Eu, (nome do(a) paciente), declaro ter  
sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de mesilato de imatinibe para o tratamento da leucemia linfoblástica aguda cromossoma Philadelphia positivo (Ph+) e linfoma linfoblástico Ph+.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
___________________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- diminuição das contagens de glóbulos brancos no sangue;  
- chance de controle da doença por longo prazo;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso do medicamento:  
o mesilato de imatinibe é utilizado para o tratamento da leucemia linfoblástica aguda cromossoma Philadelphia positivo (Ph+) e linfoma linfoblástico Ph+;  
- o mesilato de imatinibe não pode ser usado durante a gravidez pelo risco de má-formação do feto;  
- homens e mulheres com vida sexual ativa devem usar meios de contracepção adequados durante a terapia com mesilato de  
- imatinibe;  
- o mesilato de imatinibe é excretado no leite humano. Devido à incerteza sobre a segurança do medicamento em lactentes,  
- deve-se decidir entre suspender a amamentação ou o tratamento, levando-se em conta a importância do medicamento para a sobrevivência da mãe.  
- efeitos adversos: astenia, cefaleia, tontura, alterações no paladar, parestesia, insônia, náuseas, vômitos, diarreia, mialgia, cãibras musculares, artralgia, erupção cutânea, edemas superficiais periorbitários ou dos membros inferiores, alopecia, conjuntivite, hiperlacrimação, dispneia, epistaxe, neutropenia, trombocitopenia e anemia são frequentes. Raramente ocorrem derrame pleural, ascite, edema pulmonar e aumento rápido de peso com ou sem edema superficial, desidratação, hiperuricemia, hipocalemia, gota, hipofosfatemia, hipercalemia, hiponatremia, depressão, ansiedade, diminuição da libido, confusão mental, hemorragia cerebral, síncope, neuropatia periférica, hipoestesia, sonolência, enxaqueca, comprometimento da memória, edema macular, papiledema, hemorragia retiniana, hemorragia vítrea, glaucoma, vertigem, zumbido, insuficiência cardíaca, edema pulmonar, taquicardia, pericardite, tamponamento cardíaco, hematoma, hipertensão, hipotensão, rubor, extremidades frias, tromboembolismo, fibrose pulmonar, pneumonite intersticial, hemorragia gastrintestinal, melena, ascite, úlcera gástrica, gastrite, eructação, boca seca, colite, diverticulite, obstrução intestinal, pancreatite, icterícia, hepatite, hiperbilirrubinemia, insuficiência hepática, petéquias, sufusão, aumento da sudorese, urticária, onicoclase, reações de fotossensibilidade, púrpura, hipotricose, queilite, hiperpigmentação da pele, hipopigmentação da pele, psoríase, dermatite esfoliativa, erupções bolhosas, angioedema, erupção cutânea vesicular, síndrome de Stevens-Johnson, dermatose neutrofílica febril aguda (síndrome de Sweet), dor ciática,  
rigidez articular e muscular, necrose avascular, osteonecrose de quadril, insuficiência renal, dor renal, polaciúria, hematúria, ginecomastia, edema escrotal, menorragia, dor no mamilo e disfunção sexual.  
- contraindicado em casos de alergia (hipersensibilidade) aos componentes do medicamento;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem e com o uso concomitante de outros  
- medicamentos.  
Devo informar ao meu médico qualquer uso de medicamentos, suplementos nutricionais ou produtos naturais durante o uso do mesilato de imatinibe.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento,  
desde que assegurado o anonimato.         (   ) Sim ( ) Não  
Local: Data: Nome do paciente: Número do Cartão Nacional de Saúde do paciente: Nome de responsável legal, se aplicável: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal Médico responsável: CRM/UF: Assinatura e carimbo do médico responsável Data:  
**Observação** : O medicamento deste termo é adquirido pelo Ministério da Saúde e fornecido a hospitais habilitados em oncologia no SUS pelas respectivas Secretarias Estaduais de Saúde.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
O processo de atualização das Diretrizes Diagnósticas e Terapêuticas (DDT) - Mesilato de Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Philadelphia Positivo em Adultos teve início com reunião presencial para delimitação do escopo do documento. Esta reunião foi composta por cinco membros do Grupo Elaborador, sendo 3 especialistas e 2 metodologistas, e dois representantes do Comitê Gestor.  
Inicialmente, a macroestrutura das DDT foi estabelecida com base na Portaria SAS/MS nº 375, de 10 de novembro de 2009, que define o roteiro para elaboração das DDT, definindo-se as seções do documento.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de identificar as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas do tema da presente DDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO ( **Figura A** ), para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
L P| mee NONE<br>+Intervencdo, no caso de estudos experimentais<br>+Fator de exposigao, em caso de estudos<br>observacionais<br>*Teste indice, nos casos de estudos de acuracia<br>diagnéstica<br>*Controle, de acordo com tratamento/niveis de<br>exposi¢ao do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br><!-- End of picture text -->  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Ao final dessa dinâmica, seis questões de pesquisa foram definidas para as presentes DDT ( **Quadro A** ). Ressalta-se, entretanto, que à época da reunião de escopo o medicamento ponatinibe não tinha registro pela Anvisa, de modo que sua avaliação não pôde ser feita.  
**Quadro A -** Questões de pesquisa elencadas pelo Grupo Elaborador  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|Qual a eficácia e segurança do dasatinibe como tratamento de<br>1ª linha na LLA Ph+ no adulto?|Tratamento|
|**2**|Qual a eficácia e segurança do ponatinibe como tratamento na<br>LLA Ph+ no adulto?|Tratamento|
|**3**|Qual a eficácia e segurança do uso de Inibidores da Tirosina-<br>quinase pós- transplante de medula óssea?|Tratamento|
|**4**|Qual a eficácia e segurança dos transplantes autólogo e<br>alogênico na LLA Ph+ no adulto não detectável?|Tratamento|
|**5**|Qual a eficácia e segurança do tratamento com de Inibidores<br>da tirosino-quinase na fase de manutenção pós- transplante de<br>medula óssea?|Tratamento|
|**6**|Quais são os resultados de eficácia e segurança das diferentes<br>intensidades (p. ex.:_reduced intensity_) de quimioterapia?|Tratamento|  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
A reunião presencial para definição do escopo das DDT foi conduzida com a presença de membros do Grupo Elaborador. Todos os participantes do Grupo Elaborador preencheram os respectivos formulários de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde como parte dos resultados.  
A proposta de atualização das Diretrizes Diagnósticas e Terapêuticas foi apresentada à 86º Reunião da Subcomissão Técnica de Avaliação de PCDT, realizada dia 11 de fevereiro de 2021. A reunião teve a presença de representantes do Departamento de Gestão, Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e Departamento de Atenção Especializada e Temática (DAET/SAES/MS). Nessa reunião, os membros presentes apontaram a necessidade de importantes ajustes e, assim, o texto retornou ao Grupo Elaborador.  
Após os ajustes, o documento retornou à 91ª Reunião da Subcomissão Técnica de Avaliação de PCDT, em 15 de julho de 2021, quando os presentes concordaram em encaminhar o texto para apreciação do Plenário da Conitec.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
À 100ª Reunião do Plenário da Conitec, realizada em 04 de agosto de 2021, foi apresentada por representante do Grupo Elaborador a atualização das Diretrizes Diagnósticas e Terapêuticas - Mesilato de Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo em Adulto. Os membros presentes deliberaram encaminhar o tema para consulta pública, com recomendação preliminar favorável à aprovação da atualização das referidas Diretrizes.  
A Consulta Pública nº 70/2021 ficou disponível para contribuições entre 20 de agosto de 2021 a 08 de setembro de 2021. Foram recebidas contribuições de 28 pessoas físicas ou jurídicas, com 13 anexos. Das contribuições, 57% avaliaram o documento como ruim ou muito ruim.  
Ainda, entre os documentos encaminhados por meio da Consulta Pública, alguns relataram mais de cinquenta tópicos que necessitavam de correção ou ajuste, conforme o **Quadro B** :  
**Quadro B –** Sumarização das contribuições da Consulta Pública nº 70/2021.  
|**Contribuição**|**Resposta**|
|---|---|
|**Solicitação de novas tecnologias**<br>Sugiro a inclusão de Dasatinibe e Ponatinibe para<br>pacientes com mutações de resistência a Imatinibe e<br>também para os que não são elegíveis a transplante de<br>medula óssea em primeira linha de tratamento.|Como mencionado no texto exposto à Consulta Pública: “O<br>Relatório de Recomendação nº 584/2020 trata da avaliação de<br>dasatinibe para adultos com leucemia linfoblástica aguda<br>cromossomo Philadelphia positivo resistentes/ intolerantes ao<br>mesilato de imatinibe. Os resultados de Consulta Pública<br>sobre o tema foram apresentados na 93ª Reunião Ordinária do<br>Plenário da Conitec, realizada em dezembro de 2020, quando|
|A incorporação de somente Imatinibe para o<br>tratamento<br>de<br>LLA<br>Philadelphia<br>positivo<br>é<br>insuficiente, nos deixando ainda em situação de atraso<br>no que diz respeito a oferta de melhores opções<br>terapêuticas para uma doença potencialmente curável.|os membros presentes deliberaram por unanimidade<br>recomendar a não ampliação de uso do dasatinibe. Assim, a<br>Portaria SCTIE/MS nº 67, de 30 de dezembro de 2020, tornou<br>pública a decisão de não ampliar o uso do dasatinibe em<br>adultos com leucemia linfoblástica aguda cromossomo<br>Philadelphia positivo resistentes/ intolerantes ao mesilato de<br>imatinibe, no âmbito do Sistema Único de Saúde - SUS.”<br>Quanto ao ponatinibe, este outro inibidor de tirosinoquinase<br>(ITQ) não teve demanda para avaliação pela Conitec.<br>Ressalta-se que o potencial de cura de caso de LLA Ph+ não<br>se prende ao ITQ, mas à poliquimioterapia de longa duração<br>e,<br>eventualmente,<br>ao<br>transplante<br>de<br>células-tronco<br>hematopoéticas (TCTH), aos quais passou-se a associar o<br>ITQ.|
|**Exames**|Sugestão acatada.|
|Não  está  claro o uso dos exames de acompanhamento|Todos os trechos relativos aos exames, inclusive a citometria|
|da LLA, como a citometria de fluxo com citometro de<br>8 cores e monitoramento do gene de fusão  BCR-|de fluxo e o PCR quantitativo, para o diagnóstico, o<br>monitoramento terapêutico e o monitoramento pós-|  
|**Contribuição**|**Resposta**|
|---|---|
|ABL1, por PCR quantitativo, nem  a frequencia nem<br>o tempo em que devem ser realizados. Esses  são  9s<br>ecames específicos  mais importantes  para o<br>acompanhamento. Citação  no texto de que é<br>necessário  exames de fezes a cada 3 meses é<br>realmente absolutamente desnecessario e não  parece<br>tratar do tema com a expertise necessaria.|tratamento foram reformulados, inclusive ressaltando-se a<br>observância que se deve ter aos diferentes protocolos<br>adotados nos hospitais.|
|**Transplante**|Sugestão acatada.|
|Incompreensível no texto as reais indicações  e os<br>momentos de indicação  do transplante alogênico  e<br>muito menos do transplante autologo, cuja indicação<br>nestes casos é muito mais restrita, podendo ser<br>considerado apenas nos pacidntes em remissão<br>molecular completa.|Os trechos foram reformulados.|
|**Referências**|Sugestão acatada.|
|O texto precisa ser reescrito e atualizado. As<br>referências  não  condizem com as afirmações  e não<br>são  atuais. Visto que muitos trabalhos sobre o tema<br>foram publicados  nos ultimos 2- 3 anos.|O texto foi reformulado e as referências revisadas e<br>atualizadas.|
|**Terminologia**<br>Em vários locais do texto são utilizadas referencias<br>referentes a LLA Ph-like como se fosse LLA Ph+.<br>Essas são duas entidades distintas.,<br>O nome correto do gene é BCR-ABL1 e deve constar<br>nessa forma em todo o texto., Outras observações:, -<br>O nome a ser utilizado em português é LLA Filadélfia<br>positiva. Favor uniformizar no texto.|Sugestão acatada.<br>Os trechos foram reformulados.|
|**CID**<br>Item 2. Classificação diagnostica: excluir CID 83.5.<br>Manter apenas CID91.0,<br>**Tratamento**|Sugestão não acatada.<br>A Classificação WHO junta as duas entidades em um só<br>capítulo e com códigos diferentes. Foimantido o código<br>C83.5 da CID-10, pois a LLA e o Linfoma Linfoblástico<br>(LLb) são apresentações da mesma doença, inclusive quanto<br>ao Ph+, e têm o mesmo tratamento.<br>Sugestão acatada.|  
|**Contribuição**|**Resposta**|
|---|---|
|- Pagina 15, item 6.2: a frase “Em algumas<br>circunstancias, pode ser possível transplantar a medula<br>óssea de outra parte do corpo do próprio paciente, isto<br>é conhecido como transplante autólogo”. Essa<br>certamente não é a descrição correta de um transplante<br>autólogo. Precisa ser corrigido"|A Seção 6 – Tratamento foi reformulada.|
|**Diagnóstico**|Sugestão acatada.|
|13. Item 3. Diagnostico: o diagnóstico é feito com a<br>presença de > 20% de linfoblastos em MO ou SP. As<br>referências que são citadas não apontam para o texto<br>que fala em 20 ou 25% de linfoblastos. Em verdade<br>nem se referem ao tópico específico de diagnóstico de<br>LLA Ph+.|O texto foi reformulado e as referências revisadas e<br>atualizadas.|
|**Diagnóstico**<br>14. Pagina 9: há duas notas. Talvez seja importante<br>numerar ou apenas incluir no texto. A segunda nota<br>pode ser totalmente excluída, tendo em vista que não<br>faz referência à doença aqui discutida e não adiciona<br>qualquer tipo de informação importante para esse<br>tópico.<br>15. Pagina 10: Nota: essa nota quanto a tipagem de<br>HLA ao diagnostico, e o termo correto seria exame de<br>histocompatibilidade (A, B, C, DR, DQ) e não apenas<br>HLA-DR,<br>deveria<br>ser<br>acrescentado<br>no<br>item<br>transplante de medula óssea e não como nota.|Sugestão não acadatada. As Notas 1 e 2 agregam informação<br>sobre o diagnóstico e a Nota 3 orienta a boa prática de se<br>proceder ao exame de histocampatibilidade, ao  diagnóstico<br>de LLA ou LMC, com vistas à inscrição do doente no Registro<br>Nacional de Receptores de Medula Óssea (REREME),<br>antecipando a necessidade de uma eventual busca no Registro<br>Nacional de Doadores de Medula Óssea (REDOME).<br>Sugestão acatada e correção realizada.|
|**Cuidados Paliativos**<br>Propor uso de ácido acetil salicílico e ibuprofeno para<br>cuidados paliativos de paciente que não responde a<br>imatinibe sem considerar a utilização de outro inibidor<br>tirosina quinase e imunoterapia, que podem levar o<br>paciente à remissão completa e propiciar transplante<br>de medula óssea curativo é uma imensa afronta à<br>medicina e ainda maior aos pacientes, a quem<br>devotamos o cuidado de toda uma vida.,<br>**Crítica**|Sugestão acatada e correção realizada.<br>Devido às críticas ao documento, seu texto foi reformulado.|  
|**Contribuição**|**Resposta**|
|---|---|
|Ante ao exposto no relatório técnico desta PCDT, em<br>termos gerais, avalio que esta diretriz não está<br>totalmente atualizada a literatura vigente, aborda<br>alguns conceitos que não são muito relevantes no<br>manejo de pacientes adultos com diagnóstico de LLA<br>Ph-positiva e deixa de trazer a tona outros conceitos<br>importantes. Além disso, não oferece opções<br>adicionais de inibidores de tirosinoquinase, que é a<br>classe de droga mais importante para estes casos, aos<br>pacientes que sejam resistentes ou intolerantes ao<br>imatinibe.<br>Considero<br>que<br>seria<br>extremamente<br>importante revisar e atualizar esta diretriz.||
|**Acesso ao teste molecular**<br>Alta proporção dos pacientes recidivam com mutação<br>T315I do gene ABL, sendo que grande parte destes<br>pacientes já apresentam a mutação ao diagnóstico, que<br>pode ser detectada por técnicas moleculares de maior<br>sensibilidade. O acesso a este teste deve ser garantido<br>aos pacientes, assim como o ajuste da terapia guiada<br>pelo tipo de mutação e histórico de resposta/exposição<br>aos inibidores de tirosinoquinase do paciente.|A Portaria GM/MS nº 3.721, de 22 de dezembro de 2020,<br>incluiu na Tabela de Procedimentos, Medicamentos, Órteses,<br>Próteses e Materiais Especiais do Sistema Único de Saúde –<br>SUS os procedimentos 02.02.10.021-9 Diagnóstico de<br>leucemia cromossoma Philadelphia positivo por técnica<br>molecular e 02.02.10.022-7 - Reavaliação diagnóstica de<br>leucemia cromossoma Philadelphia positivo por técnica<br>molecular.|  
Todas as contribuições recebidas foram lidas e avaliadas. Diante das críticas recebidas, a Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas – CGPCDT/DGITIS/SCTIE/MS conclui pela necessidade de reformulação das Diretrizes. Esse trabalho foi procedido por médicos especialistas do Instituto Nacional de Câncer (INCA/SAES/MS) e da Secretaria de Atenção Especializada à Saúde (SAES/MS), do Ministério da Saúde.  
Com a reformulação, todas as referências do documento encaminhado para Consulta Pública foram revisadas e seu texto foi reescrito, a fim de atender às contribuições recebidas e a dar maior clareza ao texto. Também foram incluídas novas referências.  
Ressalta-se que a opção pela reformulação do documento e a publicação das Diretrizes foi necessária devido à necessidade de se incluírem os procedimentos dos exames de reação em cadeia da polimerase – transcriptase reversa (RT-PCR) qualitativa e quantitativa (RT-qPCR) e hibridização _in situ_ (ISH) para o diagnóstico e monitoramento da Leucemia Mieloide Crônica (LMC) e da Leucemia Linfoblástica Aguda cromossoma Philadelphia positivo (LLA Ph+), conforme as portarias nº 57/SCTIE/MS, de 18 de novembro de 2019, e nº 3.721/GM/MS, de 22 de dezembro de 2020.  
No entanto, apenas com o intuito de preservar o registro e dar transparência às etapas de atualização do documento, pelo Grupo Elaborador, a seguir constam informações sobre o seu trabalho original de busca e avaliação da literatura.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
TRABALHO ORIGINAL DO GRUPO ELABORADOR

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
O processo de atualização das Diretrizes Diagnósticas e Terapêuticas (DDT) - Mesilato de Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Philadelphia Positivo em Adultos teve início com reunião presencial para delimitação do escopo do documento. Esta reunião foi composta por cinco membros do Grupo Elaborador, sendo 3 especialistas e 2 metodologistas, e dois representantes do Comitê Gestor.  
Inicialmente, a macroestrutura das DDT foi estabelecida com base na Portaria n° 375/SAS/MS, de 10 de novembro de 2009, que define o roteiro para elaboração das DDT, definindo-se as seções do documento.  
Após essa definição, cada seção foi detalhada e discutida pelo Grupo Elaborador, com o objetivo de identificar as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas do tema das presentes DDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO ( **Figura A** ), para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
L232 me IS<br>+Intervencdo, no caso de estudos experimentais<br>+Fator de exposigao, em caso de estudos<br>observacionais<br>*Teste indice, nos casos de estudos de acuracia<br>diagnéstica<br>*Controle, de acordo com tratamento/niveis de<br>exposi¢ao do fator/exames disponiveis no SUS<br>+Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br><!-- End of picture text -->  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Ao final dessa dinâmica, seis questões de pesquisa foram definidas para as presentes DDT ( **Quadro A** ). Ressalta-se, entretanto, que à época da reunião de escopo o medicamento ponatinibe não tinha registro pela Anvisa, de modo que sua avaliação não pôde ser feita.  
**Quadro A -** Questões de pesquisa elencadas pelo Grupo Elaborador  
||**Número**|**Descrição**|**Seção**|
|---|---|---|---|
|**1**||Qual a eficácia e segurança do dasatinibe como tratamento<br>de 1ª linha na LLA Ph+ no adulto?|Tratamento|
|**2**||Qual a eficácia e segurança do ponatinibe como<br>tratamento na LLA Ph+ no adulto?|Tratamento|
|**3**||Qual a eficácia e segurança do uso de Inibidores da<br>Tirosina-quinase pós- transplante de medula óssea?|Tratamento|
|**4**||Qual a eficácia e segurança dos transplantes autólogo<br>e alogênico na LLA Ph+ no adulto não detectável?|Tratamento|
|**5**||Qual a eficácia e segurança do tratamento com de Inibidores<br>da tirosino-quinase na fase de manutenção pós- transplante<br>de medula óssea?|Tratamento|
|**6**||Quais são os resultados de eficácia e segurança das<br>diferentes intensidades (p. ex.:_reduced intensity_) de<br>quimioterapia?|Tratamento|  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
A reunião presencial para definição do escopo das DDT foi conduzida com a presença de membros do Grupo Elaborador. Todos os participantes do Grupo Elaborador preencheram os respectivos formulários de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde como parte dos resultados.  
A proposta de atualização das Diretrizes Diagnósticas e Terapêuticas foi apresentada à 86º Reunião da Subcomissão Técnica de PCDT, realizada dia 11 de fevereiro de 2021. A reunião teve a presença de representantes do Departamento de Gestão, Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e Departamento de Atenção Especializada e Temática (DAET/SAES/MS). Nessa reunião, os membros presentes apontaram a necessidade de importantes ajustes e, assim, o texto retornou ao Grupo Elaborador.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: Geral -->
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida nas DDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clinico-demográficas e desfechos de eficácia/segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias em formato PDF, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados das DDT. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo deste Apêndice.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess Systematic Reviews 2_ (AMSTAR-2)76; os ensaios clínicos randomizados, pela ferramenta de risco de viés da Cochrane77; os estudos observacionais, pela ferramenta Newcastle-Ottawa78; e os estudos de acurácia diagnóstica, _pelo Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2)79. Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas _a priori_ como alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa ao longo deste Apêndice.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ ), de forma qualitativa, durante a reunião de consenso das recomendações. Os metodologistas mediaram as discussões apresentando cada um dos critérios GRADE para os dois objetivos  
do sistema GRADE, e as conclusões do painel de especialistas foram apresentadas ao final do parágrafo do texto correspondente à recomendação 6.Questões de Pesquisa  
**Questão de Pesquisa 1:** Qual a eficácia e segurança do dasatinibe como tratamento de 1ª linha na LLA Ph+ no adulto?

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca** -->
((((("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia, Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia))) AND ("Dasatinib"[Mesh] OR dasatinib OR BMS354825 OR Sprycel))) AND ("aged"[MeSH Terms] OR "adult"[MeSH Terms:noexp] OR "adult"[MeSH Terms] OR of age OR middle age)  
Total: 117 referências  
Data do acesso: 15/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca** -->
'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca** -->
'dasatinib'/exp/mj AND [embase]/lim OR sprycel AND [embase]/lim AND  
('adult'/exp OR 'adult' AND [embase]/lim) OR ('aged'/exp OR 'aged' AND [embase]/lim) OR (of AND age AND [embase]/lim) Total: 138 referências  
Data do acesso: 16/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **2) Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 255 referências (117 no MEDLINE e 138 no Embase). Destas, 55 foram excluídas por estarem duplicadas. Duzentas referências foram triadas por meio da leitura de título e resumos, das quais 15 tiveram seus textos completos avaliados para confirmação da elegibilidade. Um estudo foi excluído nessa etapa por se tratar de revisão narrativa. Foram incluídos sete estudos (14 publicações), sendo um publicado apenas como resumo de congresso.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela A** . As características dos pacientes encontram-se descritas na **Tabela B** . As **tabelas C e D** apresentam dados de eficácia e segurança, respectivamente.  
**Tabela A -** Características dos estudos  
|**Autor, ano**|**Desenho de**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do**|**Risco de viés**|
|---|---|---|---|---|---|---|
||**estudo**||||**controle**||
|**Chilkulwar et**|Série de casos|Revisar os casos de|Pacientes com LLA Ph+|Terapia de indução com dasatinibe 100mg ou|NA|Alto risco:|
|**al. 2015**<sup>80</sup>|retrospectiva,|pacientes com LLA|tratados na fase de indução|140mg/dia até RHC. Prednisona 60mg/m<sup>2</sup>/dia até dia||Dados de|
||unicêntrico|Ph+ tratados na fase|com dasatinibe e|24, redução até a interrupção no dia 32.||eficácia|
|||de indução com|prednisona, e que|Quimioterapia com MTX e Ara-C foi administrada||provenientes de|
|||dasatinibe e|receberam TMO alogênico|2x durante o período de indução||pequena série de|
|||prednisona|como terapia pós-|||casos não|
||||remissão|||controlada|
|**Lee et al.**|Série de casos|Avaliar eficácia e|Pacientes adultos recém|Dasatinibe 50mg oral 2x/dia ou 100mg 1x/dia nos|NA|Alto risco:|
|**2011**<sup>81</sup>|(resumo de|segurança do|diagnosticados com LLA|primeiros 14 dias de cada um de 8 ciclos de||Dados de|
||congresso)|dasatinibe +|Ph+ (26%), LLA Ph+ e|HCVAD. Pacientes em RC receberam manutenção||eficácia|
|||quimioterapia|outras anormalidades|com dasatinibe + prednisona mensal + vincristina||provenientes de|
|||HCVAD como|(62%) e LLA Ph-|por 2 anos, seguido por dasatinibe indefinidamente.||pequena série de|
|||tratamento de|BCR/ABL positivo (12%)|Após 2 anos, o protocolo sofreu uma emenda e os||casos não|
|||primeira linha em||pacientes receberam 100mg de dasatinibe nos||controlada|
|||pacientes com LLA||primeiros 14 dias do ciclo 1 e 70mg/dia nos 7|||
|||Ph+||ciclos seguintes + 2 doses de rituximabe 375mg/m<sup>2</sup>|||
|||||nos primeiros 4 ciclos|||
|**Yoon et al.**|Série de asos|Avaliar eficácia e|Pacientes adultos (15-65|Ciclo de HCVAD alternando com citarabina em|NA|Alto risco:|
|**2016**<sup>82</sup>|(estudo fase 2),|segurança do|anos) com LLA Ph+|dose alta + MTX; Profilaxia SNC (IT tripla),||Dados de|
||multicêntrico|dasatinibe +||seguida de ciclo de 4 semanas de monoterapia||eficácia|
|||quimioterapia no||com dasatinibe 100mg 1x/dia imediatamente após||provenientes de|
|||tratamento inicial de||recuperação de neutrófilos (=>1x10<sup>9</sup>/L) e||série de casos|
|||pacientes adultos com||plaquetas (=>50x109/L).||não controlada|  
|**Autor, ano**|**Desenho de**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do**|**Risco de viés**|
|---|---|---|---|---|---|---|
||**estudo**||||**controle**||
|||LLA Ph+||Administrados até 4 ciclos de dasatinibe|||
|**Foa et al.**|Série de casos|Avaliar eficácia do|Pacientes adultos com|Prednisona em doses crescentes (10-60mg/m2/dia)|NA|Alto risco:|
|**2011**<sup>83</sup>|(estudo fase 2),<br>multicêntrico|dasatinibe no<br>tratamento inicial de|LLA Ph+, virgens de<br>tratamento|por 7 dias na pré- fase. Dasatinibe 70mg 2x/dia por<br>84 dias + prednisona 60mg/m<sup>2</sup>/dia até dia 24,||Dados de<br>eficácia|
|||adultos com LLA Ph+|quimioterápico. Permitido<br>uso prévio de esteróides|seguida de redução e interrupção no dia 32. MTX<br>IT nos dias 22 e 43||provenientes de<br>série de casos<br>não controlada|
|**Ravandi et al.**|Série de casos|Avaliar eficácia e|Pacientes adultos com|Dasatinibe 50mg 2x/dia (nos primeiros 42|NA|Alto risco:|
|**2015**<sup>84–87</sup>|(estudo fase 2),|segurança do|LLA Ph+. Foi permitida a|pacientes) ou 100mg 1x/dia nos primeiros 14 dias||Dados de|
||unicêntrico|dasatinibe +|inclusão de 9 pacientes|de cada um dos 8 ciclos de quimioterapia HCVAD||eficácia|
|||quimioterapia no|que receberam|alternando com citarabina em dose alta + MTX||provenientes de|
|||tratamento inicial de|quimioterapia prévia|||série de casos|
|||pacientes adultos com||||não controlada|
|||LLA Ph+|||||
|**Rousselot et al.**|<br>Série de casos|Avaliar eficácia e|Pacientes adultos com|Pré-fase com dexametasona 10mg/dia nos dias -7 a|NA|Alto risco:|
|**2016**<sup>41</sup>|(estudo fase 2),|segurança do|LLA Ph+, virgens de|-3. Indução: de ciclo de 4 semanas com dasatinibe||Dados de|
||multicêntrico|dasatinibe +|tratamento|140mg 1x/dia + vincristina semanal 2mg/EV +||eficácia|
|||quimioterapia no|quimioterápico. Permitido|dexametasona 40mg por 2 dias. Consolidação:||provenientes de|
|||tratamento inicial de|uso prévio de esteroides|dasatinibe 100mg/dia, MTX 1000mg/m2 EV no dia||série de casos|
|||pacientes idosos com|ou dose única de|1 e asparaginase 10000 IU/m2 IM no dia 2 nos||não controlada|
|||LLA Ph+|vincristina|ciclos 1, 3, 5, e citarabina 1000mg/m2 EV a 12/12h|||  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||nos dias 1, 3, 5 nos ciclos 2, 4, 6, em ciclos de 4<br>semanas. Manutenção: dasatinibe 100 mg/dia<br>seguido de 6-mercaptopurina (60 mg/m2/dia) e<br>MTX (25mg/m2/semana) VO 1x/mês, e<br>dexametasona/vincristina a cada 2- 3 meses até 24<br>meses. Pós-manutenção: monoterapia com<br>dasatinibe|||
|**Sasaki et al.**|Estudo|Avaliar resultados|110 pacientes adultos sem|Ponatinibe 45mg/dia durante 2 semanas na fase de|NR|Baixo risco: O|
|**2016**<sup>88</sup>|comparativo não|<br>clínicos de pacientes|tratamento prévio,|indução e 30mg/dia a partir do ciclo 2, com redução||estudo tem a|
||randomizado,|com LLA Ph+|provenientes de 2 estudos|adicional para 15mg/dia quando obtida RCM||limitação de ser|
||com análise de|tratados com|fase 2 similares, que|||retrospectivo,|
||escore de|quimioterapia|foram pareados utilizando|||mas utilizou|
||propensão|HCVAD + ponatinibe|escore de propensão|||análises que|
|||versus quimioterapia||||minimizam|
|||HCVAD + dasatinibe||||vieses de|
|||||||comparações não|
|||||||randomizadas|  
LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo; NA: não se aplica; RHC: resposta hematológica completa; MTX: metotrexato; TMO: Transplante de medula óssea; HCVAD: quimioterapia hiperfracionada com ciclofosfamida + vincristina+ doxorubicina + dexametasona; RC: remissão completa; SNC: sistema nervoso central; IT: intratecal; EV: endovenoso; IM: intramuscular; VO: via oral; RCM: resposta citogenética maior.  
**Tabela B -** Características dos pacientes  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade**|**Idade,**<br>**contro**<br>**le**|**% sexo**<br>**masculino**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação (n**<br>**paciente)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Chilkulwar**<br>**et al. 2015**<sup>80</sup>|15|NA|62<br>(19-73)|NA|33,3|NA|41,5 dias (22-69)|0/15 (na fase de<br>indução)|NA|11,7 meses<br>(4,1-40)|
|**Lee et al.**<br>**2011**<sup>81</sup>|61|NA|56<br>(22-80)|NA|NR|NA|NR|NR|NR|21 meses<br>(4-58)|
|**Yoon et al.**|51|NA|46|NA|53|NA|Mediana de 2|6/51 (11,8)|Descontinuação|54 meses|
|**2016**<sup>82</sup>|||(19–64)||||ciclos (1-4)||temporária, nenhuma<br>por evento adverso<br>sério|(40–63)|
|**Foa et al.**<br>**2011**<sup>83</sup>|55 (dados de<br>53 pacientes<br>incluídos)|NA|53,6<br>(23,8-<br>76,5)|NA|47|NA|Máximo 84<br>dias (protocolo)|4/53|Derrame pleural,<br>náusea/vômito,<br>proteinúria, elevação<br>TGO/TGP|24,8 meses<br>(8,9-35,3)|
|**Ravandi et al.**<br>**2015**<br>84–87|72|NA|55<br>(21-80)|NA|55|NA|Mediana de 6<br>ciclos (1-8)|12/62|Derrame pleural<br>(6),hipertensão<br>pulmonar (2),<br>sangramento GI (2),<br>outros (2)|67 meses (33-97)|
|**Rousselot et**<br>**al. 2016**<sup>41</sup>|71|NA|69<br>(59-83)|NA|42|NA|7,8 meses (0,6-<br>72,4)|59/71 (83)|Recaída ou óbito (38),<br>evento adverso (14),<br>transplante (7)|32 meses (2-88)|  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade**|**Idade,**<br>**contro**<br>**le**|**% sexo**<br>**masculino**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação (n**<br>**paciente)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Sasaki et al.**|41|41|57 (27-|55 (22-|NR|NR|Resposta|NR|NR|30 meses no|
|**2016**<sup>88</sup>|||80)|75)|||medida em 3|||grupo tratamento|
||||||||meses|||e 65 meses no|
|||||||||||grupo controle|  
N: número de pacientes; Dasa: dasatinibe; n: número de pacientes que apresentaram o evento; NA: não se aplica; NR: não reportado. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).  
**Tabela C -** Desfechos de eficácia  
|**Autor, ano**|**Grupo**|**Mortalidade ou sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
|**Chilkulwar**<br> <sup>80</sup>|NA|Mortalidade: 0/15 (durante fase de indução)|RHC: 14/15 (93,3)|Tempo até RCC 42|NR|
|**et al. 2015**||SG: 354 dias (57-1061)|RCC: 11/15 (73)|dias (22-69)||
|||SLP: 315 dias (57-1061)|RMM: 5/15 (33)|||
|**Lee et al. 2011**<sup>81</sup>|NA|SG após resgate: 6,7 meses (0,6-24,4)<br>SLP após resgate: 5,3 meses (0,7-17,3)<br>SLP em 3 anos: 49%<br>SG em 3 anos: 62%<br>Mortalidade: 16/61 (26)|RC: 57/61 (94)|NR|NR|
|**Yoon et al. 2016**<sup>82</sup>|NA|Mortalidade: 25/51 (49)<br>SLP: 52% (IC 95% 37,4%-64,7%)<br>SG: 51% (IC95% 36,6%-63,6%)|RC até o segundo ciclo: 46/49 (93,9) RMM<br>até o segundo ciclo: 38/49 (77,6) DRM até o<br>segundo ciclo: 22/49 (44,9)|Não reportado|RC: 12 (2-24)<br>Incidência cumulativa de<br>recidiva em 4 anos:<br>15/51(30)|
|**Foa et al. 2011**<sup>83</sup>|NA|Mortalidade: 19/53 (35,8) SG: 30,8 meses<br>(NR)<br>SLP: 21,5 meses (NR)|**Resposta à indução:**<br>RHC: 53/53 (100)|RHC: 23 dias (NR)|Tempo até recidiva: 5,9<br>(2,8-23,6)<br>Incidência<br>cumulativa de recidiva em<br>20 meses: 30,9% (IC95%<br>29,6%-32,3%)|  
|**Autor, ano**|**Grupo**|**Mortalidade ou sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
|**Ravandi et al.**|NA|Mortalidade: 39/72 SG: 47 meses (0,2-97)|**Resposta à indução:**|RMM mas|NR|
|**2015**||SLP: 31 meses (0,3-97)|RC: 69/72 (96)|não completa:||
|84–87|||RCC: 59/69 (83)|4 semanas (2-||
||||RCM: 5/69 (7,2)|38)||
||||RMC: 45/69 (65)|DRM: 3 semanas||
||||RMM, mas não completa, em 4 semanas<br>(mediana): 19/69 (28)|(2-37)||
||||**Após recaída:**|||
||||RC: 7/14 (50)|||
||||RC com recuperação incompleta: 2/14 (14)<br>RG: 9/14 (64)|||
|**Rousselot et al.**|NA|Mortalidade: 49/71 (69)|RC: 67/71 (96)|NR|Até recidiva: 36/71 (51)|
|**2016**||SG: 25,8 meses|DRM: 33/55 (60)||Incidência cumulativa de|
|41||SG: 45% (43%-67%)|RMM: 36/55 (65)||recaída em 5 anos: 54%|
|||Sobrevida livre de evento (obito, recidiva<br>hematológica): 18,9 meses|||(IC95% 42-66)|
|||SLP: 19,1 meses||||
|**Sasaki et al.**<br>**2016**<sup>88</sup>|Dasa|SLP em 3 anos: 69%<br>SG em 3 anos: 83%<br>Mortalidade: 6/41 (14,6%)|RCC na RC: 31/33 (94%) RMM na RC: 68%<br>RMC na RC: 13/13(47%)<br>RC após indução: 41/41(100%)<br>DRM negativa no dia 21 da terapia de<br>indução: 29/40(73%)|NR|NR|
||||RMC em 3 meses: 16/19 (84%)|||  
|**Autor, ano**|**Grupo**|**Mortalidade ou sobrevida**|**Resposta n/N (%)**|**Tempo até**|**Duração da resposta**|
|---|---|---|---|---|---|
|||||**resposta**||
||Controle|SLP em 3 anos: 46%|RCC na RC: 28/32 (88%) RMM na RC: 50%|NR|NR|
|||SG em 3 anos: 56%|RMC na RC:6/16 (38%)|||
|||Mortalidade: 21/41 (51,2%)|RC após indução: 38/41(95%)|||
||||DRM negativa no dia 21 da terapia de|||
||||indução: 19/35(54%)|||
||||RMC em 3 meses: 10/16 (63%)|||
||P para<br>proporções|SLP em 3 anos: p=0,04 SG em 3 anos:<br>p=0,03|RRC na RC: p=0,37 RMM na RC: p=0,27<br>RMC após indução: p=0,56 RC após indução:|NA|NA|
||ou HR|Mortalidade: p não reportado|p=0,36 DRM negativa: p=0,10 RMC em 3|||
|||SLP: HR 0,9 (IC95%0,3-0,78) p=0,003 SG:<br>HR 0,37 (IC95% 0,21-0,67) p=0,001|meses: p=0,25|||  
N: número de pacientes; Dasa: dasatinibe; n: número de pacientes que apresentaram o evento; NA: não se aplica; NR: não reportado; SLP: Sobrevida livre de progressão; SG: Sobrevida global; RHM: Resposta hematológica maior; RHC: Resposta hematológica completa; RC: remissão completa; DRM: Doença residual mínima; RHMe: Resposta hematológica menor; SED: Sem evidência de doença; RCC: Resposta citogenética completa; RCP: Resposta citogenética parcial; RHG: Resposta Hematológica Geral; RCMe: Resposta Citogenética Menor; RCMin: Resposta Citogenética mínima; RG: resposta global: HR: hazard ratio.  
Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou mediana (Intervalo de confiança de 95%) ou n/N (%).  
**Tabela D -** Eventos adversos  
|**Eventos**|||**Au**|**tor, ano de pub**<br>|**licação**|||
|---|---|---|---|---|---|---|---|
||**Chilkulw**|||**Ravandi et**||**Rousselot et**|**Sasaki**|
|**adversos**||**Lee et**|**Foa et al.**||**Yoon et**|||
|**(Grau 3-4)**|**ar et al.**<br>**2015**|**al. 2011**|**2011**|**al.**<br>**2015**|**al. 2016**|**al.**<br>**2016**|**et al.**<br>**2016**|
|**Arritmia cardíaca**|NR|NR|NR|6/72 (8,3)|NR|4/71 (5,6)|NR|
|**Bacteremia/ sepsis**|NR|NR|NR|NR|NR|13/71 (18,3)|NR|
|**Derrame pericárdico**|NR|NR|NR|4/72 (5,5)|NR|1/71 (1,4)|NR|
|**Derrame Pleural**|NR|NR|2/53 (3,7)|6/72 (8,3)|NR|7/71 (98)|NR|
|**Diarreia**|NR|NR|NR|5/72 (6,9)|NR|NR|NR|
|**Elevação de**<br>**creatinina**|NR|NR|NR|7/72 (9,7)|NR|NR|NR|
|**Elevação de**|NR|NR|1/53 (1,8)|19/72|NR|5/71 (7)|NR|
|**TGO/TGP**||||(26,4)||||
|**Embolia pulmonar**|NR|NR|NR|4/72 (5,5)|NR|3/71 (4,2)|NR|
|**Febre**|NR|NR|1/53 (1,8)|NR|NR|NR|NR|
|**Fibrinopenia**|NR|NR|NR|7/72 (9,7)|NR|NR|NR|
|**Hematoma de tecido**<br>**mole**|NR|NR|NR|3/72 (4,1)|NR|NR|NR|
|**Hematoma subdural**|NR|NR|NR|4/72 (5,5)|NR|1/71 (1,4)|NR|
|**Hiperglicemia**|NR|NR|NR|27/72<br>(37,5)|NR|NR|NR|
|**Hipertensão**<br>**pulmonar**|NR|NR|NR|2/72 (2,7)|NR|NR|NR|
|**Hipocalcemia**|NR|NR|NR|69/72<br>(95,8)|NR|NR|NR|
|**Hipocalemia**|NR|NR|NR|48/72<br>(66,6)|NR|NR|NR|
|**Hipofosfatemia**|NR|NR|NR|63/72<br>(87,5)|NR|NR|NR|
|**Infecção**|NR|NR|NR|66/72<br>(91,6)|NR|NR|NR|
|**Insuficiência**<br>**cardíaca**|NR|NR|NR|NR|NR|2/72 (2,8)|NR|
|**Insuficiência renal**<br>**aguda**|NR|NR|NR|14/72<br>(19,4)|NR|1/71 (1,4)|NR|
|**Náusea**|NR|NR|1/53 (1,8)|4/72 (5,5)|NR|NR|NR|
|**Neutropenia**|NR|NR|NR|NR|NR|11 (fase<br>manutenção)|NR|  
|**Eventos**|||**Au**|**tor, ano de pu**<br>|**blicação**|||
|---|---|---|---|---|---|---|---|
|**adversos**|**Chilkulw**|**Lee et**|**Foa et al.**|**Ravandi et**|**Yoon et**|**Rousselot et**|**Sasaki**|
||**ar et al.**|||**al.**||**al.**|**et al.**|
|**(Grau 3-4)**|**2015**|**al. 2011**|**2011**|**2015**|**al. 2016**|**2016**|**2016**|  
|||||||4 (fase<br>consolidação)||
|---|---|---|---|---|---|---|---|
|**Pneumonia não**|NR|NR|NR|NR|NR|2/72 (2,8)|NR|
|**bacteriana**||||||||
|**Proteinúria**|NR|NR|1/53 (1,8)|NR|NR|NR|NR|
|**Sangramento**|NR|NR|NR|13/72|NR|3/71 (4,2)|NR|
|**gastrointestinal**||||(18,5)||||
|**Sangramento**|NR|NR|NR|3/72 (4,1)|NR|NR|NR|
|**geniturinário**||||||||
|**Síndrome de lise**|NR|NR|NR|NR|NR|1/71 (1,4)|NR|
|**tumoral**||||||||
|**Trombose venosa**|NR|NR|NR|6/72 (8,3)|NR|NR|NR|
|**profunda**||||||||
|**Vômito**|NR|NR|NR|4/72 (5,5)|NR|NR|NR|  
NR: não reportado. Dados foram apresentados em n/N (%).  
**Questão de Pesquisa 2:** Qual a eficácia e segurança do ponatinibe como tratamento na LLA Ph+ no adulto?

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca MEDLINE via Pubmed:** -->
((("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia,  
Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia))) AND ("ponatinib" [Supplementary Concept] OR ponatinib OR AP 24534 OR Iclusig)  
Total: 44 referências  
Data do acesso: 15/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca MEDLINE via Pubmed:** -->
'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim  
AND  
('ponatinib'/mj AND [embase]/lim) OR ('iclusig'/mj AND [embase]/lim) AND  
('adult'/exp OR 'adult' AND [embase]/lim) OR ('aged'/exp OR 'aged' AND [embase]/lim) OR (of AND age AND [embase]/lim) Total: 56 referências  
Data do acesso: 16/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **2) Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 100 referencias (44 no MEDLINE e 56 no Embase). Destas, 13 foram excluídas por estarem duplicadas. Oitenta e sete referências foram triadas por meio da leitura de título e resumos, sendo que 15 tiveram seus textos completos avaliados para confirmação da elegibilidade. Sete estudos foram excluídos nessa etapa. A maioria dos excluídos apresentou resultados em leucemias Ph+ LMC e LLA de forma conjunta, sem especificar os desfechos por tipo de leucemia. Um estudo comparou ponatinibe com transplante de células tronco, utilizando dados secundários de eficácia do ponatinibe e dados primários do banco de transplantes, sem utilizar metodologia apropriada de comparações indiretas. Ao final, quatro estudos foram incluídos (oito publicações).  
**3) Descrição dos estudos e seus resultados** A descrição sumária dos estudos encontra-se na **Tabela E** . As características dos pacientes encontram-se descritas na **Tabela F** . As **tabelas G e H** apresentam dados de eficácia e segurança, respectivamente.  
**Tabela E -** Características dos estudos  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Sasaki et al.**|Estudo|Avaliar resultados|110 pacientes adultos sem|Ponatinibe 45mg/dia durante 2|NR|Baixo risco: O estudo|
|**2016**<sup>88</sup>|comparativo<br>não<br>randomizado,|clínicos de pacientes<br>com LLA Ph+<br>tratados com|tratamento prévio, provenientes<br>de 2 estudos fase 2 similares,<br>que foram pareados utilizando|semanas na fase de indução e<br>30mg/dia a partir do ciclo 2, com<br>redução adicional para 15mg/dia||tem a limitação de ser<br>retrospectivo, mas<br>utilizou análises que|
||com análise de<br>escore de<br>propensão|quimioterapia<br>HCVAD +<br>ponatinibe_versus_<br>quimioterapia<br>HCVAD +<br>dasatinibe.|escore de propensão|quando obtida RCM||minimizam vieses de<br>comparações não<br>randomizadas|
|**Jabbour et al.**|Série de casos,|Avaliar eficácia e|37 pacientes adultos com LLA|Ponatinibe 45mg/dia VO nos|NA|Alto risco: série de|
|**2015**<sup>89</sup>|unicêntrico fase<br>2|segurança da terapia<br>combinada de<br>ponatinibe +<br>quimioterapia HCVD|Ph+ consecutivos tratados e não<br>tratados previamente|primeiros 14 dias do ciclo 1 e<br>continuamente durante os 7 ciclos<br>seguintes de quimioterapia de<br>consolidação. Após 8 ciclos de<br>HCVAD e ponatinibe, foi<br>administrada terapia de manutenção<br>de 45mg/dia de ponatinibe VO<br>durante 2 anos.<br>Administrada vincristina EV no dia 1<br>e prednisona VO 200mg/dia nos dias<br>1-5. Intensificação da HCVAD e<br>pomatinibe nos meses 6 e 13||casos com o objetivo<br>de avaliar eficácia|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||(mesmo esquema da indução). Após,<br>ponatinibe 45mg/dia VO<br>indefinidamente na manutenção|||
|**Cortes et al.**<br>**2013**<sup>8</sup>|Série de casos,<br>multicêntrico<br>(66 centros),<br>fase 2|Avaliar a eficácia e<br>segurança do<br>ponatinibe|Pacientes adultos (449) com<br>LMC em fase crónica, LMC em<br>fase acelerada, LMC em fase de<br>blástica ou LLA Ph+ com<br>resistência ao ou intolerância ao<br>dasatinibe ou nilotinibe ou com<br>a mutação T315I (6 coortes)|Ponatinibe 45mg/dia VO. Desfechos<br>avaliados ao final do ciclo 1 (28<br>dias), ciclo 2 e a cada 2 meses.|NA|Alto risco: série de<br>casos com o objetivo<br>de avaliar eficácia|
|**Papayannidis**<br>**et al. 2013**<sup>90</sup>|Série de casos|Avaliar a eficácia e<br>segurança do<br>ponatinibe|Pacientes adultos com LLA Ph+<br>avançada e LMC, resistentes ou<br>intolerantes aos iTK<br>administrados previamente|Ponatinibe 45mg/dia VO|NA|Alto risco: série de<br>casos com o objetivo<br>de avaliar eficácia<br>(resumos de<br>congresso)|  
LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo; NR: não reportado; NA: não se aplica; HCVAD: quimioterapia hiperfracionada com ciclofosfamida + vincristina+ doxorubicina+ dexametasona; EV: endovenoso; VO: via oral.  
**Tabela F -** Características dos pacientes  
|**Autor, ano**|**N intervenção**|**N**|**Idade Pona**|**Idade,**|**% sexo**|**% sexo**|**Tempo de**|**Descontinuação**|**Razão para**|**Tempo de**|
|---|---|---|---|---|---|---|---|---|---|---|
|||**controle**||**controle**|**masculino**<br>**Pona**|**masculino**<br>**controle**|**tratamento**|**n/N (%)**|**descontinuação (n**<br>**paciente)**|**seguimento**|
|**Sasaki et al.**|41|41|57 (27-80)|55 (22-|NR|NR|Resposta ao|NR|NR|30 meses no|
|**2016**<sup>88</sup>||||75)|||tratamento|||grupo tratamento|
||||||||avaliada em 3|||e 65 meses no|
||||||||meses|||grupo controle|
|**Jabbour et**<br>**al. 2015**<sup>89</sup>|37, sendo 34 não<br>tratados|NA|51 (27–75)|NA|20/37(54)|NA|NR|11/37|EA (2), opção de<br>troca de|26 meses<br>(15-39)|
||previamente e 3||||||||medicamento (dasa:||
||tratados<br>previamente||||||||8 e Nilo: 1)||
|**Cortes et al.**|449 no total, sendo|NA|Exclusiva|NA|NR|NA|12,8 (1 dia -|31/32 (97%) -|Progressão da|6 meses (0,1-19)|
|**2013**<sup>8</sup>|48 LMC na fase||para||||>24,8 meses)|exclusivo para a|doença (17), EA (2),|- exclusivo para|
||blástica ou LLA Ph+||pacientes||||- dados gerais|coorte LLA Ph+|óbito (6), retirou|LLA Ph+|
||com resistência ou||LLA Ph+:||||para as 6||consentimento (3),||
||intolerância ao||62 (20–80)||||coortes.||Outras razões (6),||
||dasa/Nilo, 46 LMC||||||||Ausência de eficácia||
||na fase blástica ou||||||||(4), Decisão médica||
||LLA Ph+ + mutação<br>T351I||||||||(1)||  
|**Autor, ano**|**N intervenção**|**N**|**Idade Pona**|**Idade,**|**% sexo**|**% sexo**|**Tempo de**|**Descontinuação**|**Razão para**|**Tempo de**|
|---|---|---|---|---|---|---|---|---|---|---|
|||**controle**||**controle**|**masculino**|**masculino**|**tratamento**|**n/N (%)**|**descontinuação (n**|**seguimento**|
||||||**Pona**|**controle**|||**paciente)**||
|**Papayannidis**|Relato 2013a: 14|NA|Relato|NA|Relato 2013a:|NA|Relato 2013b:|Relato 2013a: 7/14|Relato 2013a:|Relato 2013a:|
|**et al. 2013**<sup>90</sup>|pacientes, sendo 12||2013a: 55||6/14 (43%).||139 dias (14-|(50%). Relato|ausência de eficácia|80 dias (15-|
||LLA Ph+ e 2 LMC||(18-94)||Relato 2013b:||>540)|2013b:|(5), TMO (2). Relato|>225)|
||fase blástica. Relato||Relato||8/17 (47)|||12/17 (71)|2013b: progressão da|<br>Relato 2013b:|
||2013b: 17 pacientes,||2013b: 64||||||doença (5), TMO (6),|284|
||sendo 14 LLA Ph+ e||anos (23-||||||Intolerância (1)|dias (8->540)|
||3 LMC fase blástica||77)||||||||  
N: número de pacientes; Pona: ponatinibe; Dasa: dasatinibe; Nilo: nilotinibe; n: número de pacientes que apresentaram o evento; NA: não se aplica; NR: não reportado; EA: evento adverso; TMO: transplante de medula óssea. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).  
**Tabela G -** Desfechos de eficácia  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|
|**Sasaki et al.**<br>**2016**<sup>88</sup>|Dasa|SLP em 3 anos: 69%<br>SG em 3 anos: 83%<br>Mortalidade: 6/41 (14,6%)|RCC na RC: 31/33 (94%) RMM na RC: 68%<br>RMC na RC: 13/13(47%)<br>RC após indução: 41/41(100%)<br>DRM negativa no dia 21 da indução: 29/40(73%)<br>RMC em 3 meses: 16/19 (84%)|NR|NR|
||Controle|SLP em 3 anos: 46%<br>SG em 3 anos: 56%|RCC na RC: 28/32 (88%) RMM na RC: 50%<br>RMC na RC:6/16 (38%)|NR|NR|
|||Mortalidade: 21/41 (51,2%)|RC após indução: 38/41(95%)<br>DRM negativa no dia 21 da indução: 19/35(54%)<br>RMC em 3 meses: 10/16 (63%)|||
||P para<br>proporções|SLP em 3 anos: p=0,04 SG em 3<br>anos: p=0,03|RRC na RC: p=0,37<br>RMM na RC: p=0,27|NA|NA|
||ou HR|Mortalidade: p não reportado<br>SLP: HR 0,9 (IC95%0,3-0,78)<br>p=0,003 SG: HR 0,37 (IC95%<br>0,21-0,67) p=0,001|RMC após indução: p=0,56 RC após indução: p=0,36<br>DRM negativa: p=0,10<br>RMC em 3 meses: p=0,25|||
|**Jabbour et al.**|NA|SG em 2 anos: 80% (IC 95%:63–|RC: 36/36 (100%)|RMM: 3 semanas (2-|NR|
|**2015**<sup>89</sup>||90)|RCC: 32/32 (100%)|14)||
|||SLP: 81% (IC 95%: 64-90)|RMM: 35/37 (95%)|RMC: 11 semanas (2-||
||||RMC: 29/37 (78%)|96)||
||||Citometria de fluxo negativa: 35/36 (97%)|DRM: 3 semanas (3-<br>14)||  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|
|**Cortes et al.**|NA|SG em 12 meses: 40%|RHM: 13/32 (41)|RHM: 2,9 semanas|RHM: 3 meses (2-14)|
|**2013**<sup>8</sup>||SG em 2 anos: 21%|RHM para resistente/intolerante: 5/10 (50) RHM para|(1,6-24)|RCM: 3,7 meses|
|||SLP: 7%, mediana de 3 meses|mutação T351I: 8/22 (36)<br>RCM: 15/32 (47)|RCM: 1 mês (0,9-3,7)|(NR)|
||||RCM para resistente/intolerante: 6/10 (60) RCM para<br>mutação T351I: 9/22 (41)|||
||||RCC: 12/32 (38)|||
||||RCC para resistente/intolerante: 5/10 (50)<br>RCC para mutação T351I: 7/22 (32)|||
|**Papayannidis et**<br>**al.**<br>**2013**<sup>90</sup>|NA|Relato 2013a: SG: 19 meses (11-<br>>44) Relato 2013b: Mortalidade<br>por progressão<br>de doença: 5/17 (29)|Relato 2013a: RHM: 12/14 (86)<br>Relato 2013b: RHM maior: 13/17 (76)|Relato 2013a: RHM:<br>24 dias (NR)|NR|  
N: número de pacientes; Dasa: dasatinibe; n: número de pacientes que apresentaram o evento; NA: não se aplica; NR: não reportado. SLP: Sobrevida livre de progressão; SG: Sobrevida global; RHM: Resposta hematológica maior; RHC: Resposta hematológica completa; RC: remissão completa; DRM: Doença residual mínima; RHMe: Resposta hematológica menor; SED: Sem evidência de doença; RCC: Resposta citogenética completa; RCP: Resposta citogenética parcial; RHG: Resposta Hematológica Geral; RCMe: Resposta Citogenética Menor; RCMin: Resposta Citogenética mínima; RG: resposta global. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou mediana (Intervalo de confiança de 95%) ou n/N (%)

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **2) Seleção das evidências** -->
|**Eventos adversos**<br>**(Grau 3-5)**||**Autor, ano d**|**e publicação**||
|---|---|---|---|---|
||**Sasaki et al. 2016**|**Jabbour et al.**<br>**2015**|**Cortes et al.**<br>**2013**|**Papayannidis et**<br>**al. 2013**|
|**Anemia**|NR|NR|4/32 (12)|NR|
|**Anorexia**|NR|1/37 (3)|NR|NR|
|**Cefaleia**|NR|NR|0|1/17 (6)|
|**Constipação**|NR|0|1/32 (3)|NR|
|**Derrame pericárdico**|NR|1/37 (3)|NR|NR|
|**Derrame Pleural**|NR|0|NR|NR|
|**Diarreia**|NR|2/37 (5)|NR|NR|
|**Dispneia**|NR|NR|0|NR|
|**Dor abdominal**|NR|3/37 (8)|2/32 (6)|NR|
|**Eventos trombolíticos**|NR|3/37 (8)|NR|NR|
|**Hipertensão**|NR|6/37 (16)|1/32 (3)|NR|
|**Infarto do miocárdio**|NR|3/37 (8)|NR|NR|
|**Infecção**|NR|32/37 (86)|NR|NR|
|**Injuria renal**|NR|2/37 (5)|NR|NR|
|**Mucosite**|NR|4/37(11)|NR|NR|
|**Náusea**|NR|3/37 (8)|0|NR|
|**Neutropenia**|NR|NR|4/32 (12)|NR|
|**Neutropenia febril**|NR|NR|2/32 (6)|NR|
|**Pancreatite**|NR|6/37 (16)|0|NR|
|**Rash**|NR|8/37 (22)|1/32 (3)|3/17 (18)|
|**Sangramento**|NR|5/37 (14)|NR|NR|
|**Trombocitopenia**|NR|NR|2/32 (6)|NR|
|**Vômito**|NR|2/37 (5)|0|NR|  
NR: não reportado. Dados foram apresentados em n/N (%).  
**Questão de Pesquisa 3:** Qual a eficácia e segurança do uso de TKI pós TMO?

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca MEDLINE via Pubmed:** -->
(((((("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia,  
Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia)))) AND (((tyrosine kinase inhibitors) OR ("Imatinib Mesylate"[Mesh] OR imatinib OR Gleevec OR Glivec OR STI 571 OR ST 1571 OR CGP 57148 OR CGP57148B)) OR (("Dasatinib"[Mesh] OR dasatinib OR BMS354825  
OR Sprycel))))) AND ("Bone Marrow Transplantation"[Mesh] OR Bone marrow transplant OR Bone Marrow Grafting) Total: 120 referências  
Data do acesso: 15/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca MEDLINE via Pubmed:** -->
'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **1) Estratégia de busca MEDLINE via Pubmed:** -->
('protein tyrosine kinase inhibitor'/exp OR 'tyrosine kinase inhibitor' AND [embase]/lim) OR [('imatinib'/exp/mj AND [embase]/lim) OR ('gleevec'/mj AND [embase]/lim) OR ('glivec'/mj AND [embase]/lim)] OR ('dasatinib'/exp/mj AND [embase]/lim OR sprycel AND [embase]/lim)  
('bone marrow transplantation'/exp OR 'bone marrow transplantation' AND [embase]/lim) OR ('bone'/exp OR bone AND ('marrow'/exp OR marrow) AND ('transplant'/exp OR transplant) AND [embase]/lim) OR ('bone'/exp OR bone AND ('marrow'/exp OR marrow) AND ('grafting'/exp OR grafting) AND [embase]/lim)  
([young adult]/lim OR [adult]/lim OR [middle aged]/lim OR [aged]/lim OR [very elderly]/lim) AND [embase]/lim Total: 205 referências  
Data do acesso: 16/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **2) Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 325 referencias (120 no MEDLINE e 205 no Embase). Destas, 33 foram excluídas por estarem duplicadas. Duzentas e noventa e duas referências foram triadas por elegibilidade. Três estudos foram excluídos por analisar o efeito das iTKs no pós-transplante considerando conjuntamente populações com LLA e LMC. Um estudo foi adicionalmente excluído por ser relato de caso. Seis estudos referem-se à manutenção do uso dos iTKs após TMO, ou seja, avaliaram iTKs no período pré e manutenção das iTKs no período póstransplante, e foram considerados para a questão de pesquisa 5 (Qual a eficácia e segurança do tratamento com TKI na fase de manutenção pós-TMO?). Ao final, dois estudos foram selecionados por avaliarem o uso dos iTKs no período pós- transplante, como tratamento da recorrência molecular.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela I** . As características dos pacientes encontram-se descritas na  
**<mark>Tabela J.</mark>** <mark>A</mark> **<mark>Tabela K</mark>** <mark>apresenta dados de eficácia. Nenhum dos estudos descreveu eventos adversos.</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes**<br>**do controle**|<br>**Risco de viés**|
|---|---|---|---|---|---|---|
|**Nishiwaki et**<br>**al. 2015**<sup>93</sup>|Estudo<br>observacional<br>retrospectivo|Avaliar o impacto da<br>situação de DRM no<br>momento do transplante<br>alogênico nos desfechos<br>pós-transplantes e avaliar<br>os iTK no pós-TMO|Pacientes japoneses com pelo<br>menos 16 anos que tenham<br>realizado primeiro transplante<br>para LLA Ph+ em resposta<br>completa|A mediana de dias da administração dos iTK foi de<br>141 dias pós-transplante (21-1903). Imatinibe foi<br>administrado em 85 pacientes, com mediana de dose<br>de 400mg/dia; e o dasatinibe foi administrado em<br>18 pacientes, com mediana de dose de100 mg/dia.<br>Pós-transplante sem recorrência molecular<br>(profilático) foi administrado em 34 pacientes; em<br>recorrência molecular em 24 pacientes, em 42<br>pacientes com recorrência hematológica e 3 em<br>tempos não conhecidos.|NA|Alto risco: análise<br>retrospectiva não<br>comparativa com o<br>objetivo de avaliar<br>eficácia.|
|**Wassmann**<br>**et al. 2005**<sup>55</sup>|Série de<br>casos|Avaliar eficácia e<br>segurança do imatinibe<br>em pacientes com LLA<br>Ph+ e evidência<br>molecular de leucemia<br>recorrente após TMO<br>alogênico ou autólogo|Pacientes > 15 anos, com LLA<br>Ph+ e fase blástica da LMC (não<br>é informada a proporção de<br>cada, mas o título menciona<br>apenas LLA Ph+). Desta forma,<br>foi inferido que a maioria dos<br>pacientes incluídos era de LLA<br>Ph+|Imatinibe dose oral inicial diária de 400mg,<br>podendo ser escalonada para 600mg e<br>subsequentemente 800mg/dia em pacientes que<br>permaneceram bcr-abl+. As aspirações de medula<br>óssea para citologia e análise de DRM foram<br>programadas após os primeiros 28 dias de<br>tratamento com Imatinibe e subsequentemente a<br>cada 6 a 8 semanas durante o primeiro ano de<br>terapia. 18/27 (67%) receberam imatinibe antes do<br>transplante, sendo 9 na resposta completa, 1durante<br>tratamento de primeira linha e 9 no resgate|NA|Alto risco: série de<br>casos com objetivo<br>de avaliar eficácia.|  
DRM: Doença Residual Mínima; iTKs: Inibidores da Tirosina-quinase; TMO: transplante de medula óssea; LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo.  
**Tabela J -** Características dos pacientes  
|**Autor, ano**|**N**|**Idade**|**% sexo**<br>**masculino**|**Tempo de**<br>**tratamento pós**<br>**TMO**|**Tempo entre o**<br>**diagnóstico e o**<br>**TMO**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(n paciente)**|**Tempo de**<br>**seguimento**<br>**pós TMO**|
|---|---|---|---|---|---|---|---|---|
||432 pacientes, sendo que 277<br>receberam TMO em DRM- e 155||||||||
|**Nishiwaki et**<br>**al. 2015**<sup>93</sup>|receberam TMO em DRM+. Do total<br>de 425 pacientes com dados para<br>administração de iTK pós-transplante,|43 (16–68)|56%|NR|NR|NR|NR|NR|
||103 receberam iTK pós-transplante||||||||
|**Wassmann et**<br>**al. 2005**<sup>55</sup>|27 pacientes, sendo que 24 receberam<br>TMO alogênico e 3 receberam TMO<br>autólogo|48 (16-63)|14/27 (52)|Tempo entre<br>transplante e início<br>do imatinibe: 4,4<br>meses (1,1-19,2)|NR|10/27 (37)|Recorrência<br>molecular (3),<br>sem descrição de<br>causa (6), óbito<br>por AVC (1)|<br>8,3 meses (0,9-<br>31)|  
N: número de pacientes; n: número de pacientes que apresentaram o evento; NR: não reportado; TMO: transplante de medula óssea; DRM: doença residual mínima; AVC: acidente vascular cerebral. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
|**Autor, ano**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da resposta**|
|---|---|---|---|---|
||Análise multivariada (presença e ausência de administração<br>iTK profilático ou em RM):||||
|**Nishiwaki et al.**<br>**2015**<sup>93</sup>|SLP: HR 2,07 (IC95% 1,38-3,10; p<0,000)1<br>RM: HR 16,7 (IC95% 10,3-27,2; p<0,0001)<br>Mortalidade sem recorrência: HR 0,11 (IC95% 0,03-0,34;<br>p<0,0001)|NR|NR|NR|
|**Wassmann et al.**<br>**2005**<sup>55</sup>|SLP 1 ano em pacientes sem detecção de DRM: 91% ± 9%<br>SG em 1 ano em pacientes sem detecção de DRM: 100%<br>SLP em 13 meses em pacientes com detecção de DRM: 8% ±<br>7%<br>SG em 13 meses em pacientes sem detecção de DRM: 23% ±<br>13%<br>(valores de p para as comparações entre os subgrupos = <<br>0,001 para ambos os desfechos)<br>SLP em 2 anos em pacientes sem detecção de DRM:  54.5% ±<br>21%<br>SG em 2 anos em pacientes sem detecção de DRM: 80% ±<br>18%<br>SG em 13 meses em pacientes com DRM em 13 meses: 23%<br>± 13%|RM: 15/27 (55)<br>Probabilidade de recorrência: 52% ±<br>10%<br>Remissão molecular: 14/27 (52)<br>Probabilidade do paciente com DRM<br>persistir após 3 meses de tratamento<br>com imatinibe: <10%<br>Recorrência durante tratamento: 0<br>Negatividade da PCR em pacientes<br>não tratados com imatinibe antes do<br>transplante (n=9): 6/9 (67)|Remissão molecular<br>em 2 meses: n=9<br>Remissão molecular<br>em 3 meses: n=2<br>Tempo até negativar<br>por PCR: 1,5 meses<br>(0,9-3,7)|Duração da remissão<br>molecular em todos os<br>pacientes: 6,6 meses (0,9-31)<br>Duração da remissão<br>molecular em pacientes<br>detectados com DRM: 3,6<br>meses (0,9-6,6)<br>Duração da remissão<br>molecular em pacientes<br>detectados sem DRM: 28,6<br>meses (NR)|  
N: número de pacientes; n: número de pacientes que apresentaram o evento; iTKs: Inibidores da Tirosina-quinase; RM: recorrência molecular; HR: hazard ratio; NR: não reportado.; SLP: Sobrevida livre de progressão; SG:  
Sobrevida global; DRM: doença residual mínima; PCR: proteína C reativa.  
Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou mediana (Intervalo de confiança de 95%) ou n/N  
**<mark>Questão de Pesquisa 4:</mark>** <mark>Qual a eficácia e segurança dos transplantes autólogo e alogênico na LLA Ph+ no adulto não detectável?</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>Search  (("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia, Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia) AND ("Transplantation, Autologous"[Mesh] OR Autologous transplantation OR Autografting OR Autotransplantation OR "Transplantation, Homologous"[Mesh] OR Allogeneic transplantation OR Allografting OR Homografting) AND ("Remission Induction"[Mesh] OR remission OR post-remission OR postremission OR first complete remission) AND ("aged"[MeSH Terms] OR "adult"[MeSH Terms:noexp] OR "adult"[MeSH Terms] OR of age OR middle age)) Sort by: Author Filters: Clinical Trial; Comparative Study; Multicenter Study; Meta-Analysis; Randomized Controlled Trial; Systematic Reviews</mark>  
<mark>Total: 383 referências</mark>  
<mark>Data do acesso: 17/03/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>('allogenic bone marrow transplantation'/mj AND [embase]/lim)</mark>  
<mark>AND</mark>  
<mark>('autologous bone marrow transplantation'/mj AND [embase]/lim)</mark>  
<mark>('remission'/exp AND [embase]/lim) OR (post AND 'remission'/mj AND [embase]/lim)</mark>  
<mark>Total: 54 referências</mark>  
<mark>Data do acesso: 16/01/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 437 referências (383 no MEDLINE e 54 no Embase). Foram excluídas cinco citações duplicadas e 432 referências foram triadas por meio da leitura de título e resumos, das quais 42 tiveram seus textos completos avaliados, quando disponíveis, para confirmação da elegibilidade.</mark>  
<mark>Não foram localizados os textos completos em versão eletrônica de sete citações publicadas nas décadas de 80 e 90. Adicionalmente, um estudo foi publicado no idioma Chinês. A avaliação da elegibilidade desses estudos foi realizada somente por meio das informações disponíveis nos resumos. Nenhum desses estudos foi considerado elegível por não apresentarem dados estratificados para a população de LLA Ph+.</mark>  
<mark>Foram identificadas uma</mark> _<mark>overview</mark>_ <mark>de revisões sistemáticas, três revisões sistemáticas e uma meta-análise de dados individuais, porém, nenhuma delas apresentou resultados estratificados por tipo de transplante e/ou para a população com LLA Ph+ e, portanto, foram excluídas. Adicionalmente identificamos uma revisão narrativa que também foi excluída.</mark>  
<mark>Dois estudos foram excluídos por terem avaliado diferentes fontes de células para transplante (medula óssea ou sangue periférico). Vinte e oito estudos primários foram excluídos por não apresentarem resultados estratificados por tipo de transplante e/ou para a população com LLA Ph+. No total foram incluídas seis publicações, correspondentes a quatro estudos.</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>A descrição sumária dos estudos encontra-se na Tabela L. As características dos pacientes encontram-se descritas na Tabela M. A Tabela N apresenta os dados de eficácia.</mark>  
**Tabela L -** Características dos estudos.  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Gorin et al. 2015**<sup>94</sup>|Estudo retrospectivo,<br>multicêntrico, com<br>coortes pareadas por<br>idade, diagnóstico,<br>status do transplante<br>(em R1 ou R2),<br>intervalo desde o<br>diagnóstico e status<br>citogenético|Avaliar efeito do<br>transplante de célula<br>tronco autólogo ou<br>alogênico<br>haploidêntico em<br>pacientes com LMC e<br>LLA|Pacientes adultos com LMC e LLA<br>que receberam transplante de<br>células tronco autólogo (n=356,<br>sendo 103 no grupo LLA) ou<br>alogênico haploidêntico (n=188,<br>sendo 56 no grupo LLA).<br>Apresentou desfechos para<br>pacientes com LLA Ph+ que<br>receberam transplante autólogo<br>(n=37) e alogênico (n=19)|Transplante alogênico<br>haploidêntico|Transplante autólogo|Moderado-alto:<br>apesar de ser um<br>estudo<br>observacional,<br>houve<br>pareamento dos<br>pacientes|
|**Hallbook et al.**<br>**2005**<sup>95</sup>|Estudo de coorte<br>retrospectivo,<br>multicêntrico (8<br>centros na Suécia)|Avaliar efeito do<br>transplante autólogo,<br>alogênico de doador<br>aparentado ou<br>alogênico de doador<br>não aparentado|Pacientes adultos (<16 anos) com<br>LLA que receberam transplante de<br>células tronco autólogo (n=67) ou<br>alogênico de doapor aparentado<br>(n=78) ou alogênico de doador não<br>aparentado (n=42)|Transplante alogênico<br>(recomendado na R1 em<br>pacientes <45anos).<br>Condicionamento e<br>profilaxia de DECH a<br>critério de cada<br>instituição|Transplante autólogo<br>(recomendado na R1<br>em pacientes<br>>45anos e naqueles<br>sem doador<br>compatível).<br>Condicionamento e<br>profilaxia de DECH<br>a critério de cada<br>instituição|Alto: estudo<br>retrospectivo,<br>com co-<br>intervenções<br>heterogêneas.<br>Não apresentou<br>número de<br>pacientes com<br>LLA Ph+ que<br>recebeu cada tipo<br>de transplante|  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**LALA-94, 2004**<sup>50</sup>|Estudo de coorte<br>prospectivo, avaliando<br>pacientes com LLA de<br>alto risco que<br>receberam transplante<br>alogênico quando<br>houvesse doador<br>compatível ou<br>autólogo|Avaliar efeito do<br>transplante de célula<br>tronco autólogo ou<br>alogênico em<br>pacientes adultos com<br>LLA Ph+|Pacientes adultos com LLA de alto<br>risco (n=1000) randomizados para<br>receber diferentes tratamentos para<br>indução. Após indução, dos 154<br>pacientes com LLA Ph+, 140<br>receberam transplante alogênico<br>quando houvesse doador (n=75) ou<br>autólogo (n=65)|Transplante alogênico|Transplante autólogo|Alto: trata-se de<br>estudo<br>observacional,<br>com intervenções<br>alocadas de<br>acordo com a<br>disponibilidade<br>de doador|
|||||||Alto: trata-se de|
|**UKALLXII/ECOG**<br>**2993, 2009**<sup>27</sup>|Estudo de coorte<br>prospectivo,<br>multicêntrico,<br>avaliando pacientes<br>com LLA que<br>receberam transplante<br>alogênico quando|Avaliar o efeito do<br>transplante alogênico<br>em adultos com LLA e<br>avaliar o efeito do<br>transplante autólogo_vs_<br>quimioterapia padrão.|Pacientes adultos com LLA Ph+<br>(n=267). Pacientes que atingiram<br>R1 (n=220), com <55anos e doador<br>compatível receberam transplante<br>alogênico (n=76). Os demais foram|Transplante alogênico<br>com doador aparentado<br>ou não aparentado.<br>Condicionamento com<br>irradiação de corpo<br>inteiro; irradiação<br>testicular (homens) +|Transplante autólogo<br>na ausência de<br>doador compatível<br>ou quimioterapia.<br>Esquema de<br>condicionamento pré|estudo<br>observacional,<br>com intervenções<br>alocadas de<br>acordo com a<br>disponibilidade<br>de doador.|
||houvesse doador e<br>ECR avaliando<br>transplante autólogo vs<br>quimioterapia|Dados apresentados<br>apenas para pacientes<br>LLA Ph+|randomizados para transplante<br>autólogo ou quimioterapia|<br>etoposide 60mg/kg EV.<br>Profilaxia de DECH com<br>ciclosporina e MTX|<br>transplante foi o<br>mesmo em ambos os<br>grupos|Excluíram<br>transplantes não<br>realizados por<br>protocolo|  
<mark>R1: primeira remissão; R2: segunda remissão; LLA: Leucemia linfoblástica aguda; LMC: Leucemia mielóide crônica; LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo; DECH: d</mark> oença enxerto versus hospedeiro; ECR: Ensaio Clínico Randomizado; <mark>EV: endovenoso; MTX: metotrexato.</mark>  
**Tabela M -** Características dos pacientes.  
|**Autor,**<br>**ano**|**N intervenção**|**N controle**|**Idade**<br>**Alogênico**|**Idade, autólogo**|**% sexo**<br>**masculino**<br>**Alogênico**|**% sexo**<br>**masculino**<br>**Autólogo**|**Tempo de**<br>**tratamento**|**Tempo de seguimento**|
|---|---|---|---|---|---|---|---|---|
|**Gorin et**<br>**al. 2015**<sup>94</sup>|19 no estrato LLA<br>Ph+|37 no estrato LLA<br>Ph+|42 (18-69), para<br>todos LMC e LLA|43 (18-71), para<br>todos LMC e<br>LLA|59% (para<br>todos LMC e<br>LLA)|56% (para<br>todos LMC e<br>LLA)|214 dias (82-4172)|28 meses (1-87)|
|**Hallbook**<br>**et al.**<br>**2005**<sup>95</sup>|120 pacientes com<br>LLA receberam<br>transplante<br>alogênico. Total de<br>LLA Ph+ = 35 em<br>R1 e 7 em R2<br>(ambos os tipos de<br>transplante)|67 pacientes com<br>LLA receberam<br>transplante autólogo.<br>Total de LLA Ph+ =<br>35 em R1 e 7 em R2<br>(ambos os tipos de<br>transplante)|Considerando 120<br>pacientes com<br>LLA: Doador<br>aparentado: 32<br>(17–59); doador<br>não aparentado:<br>31 (18–54)|Considerando 67<br>pacientes com<br>LLA: 35 (17–66)|Considerando<br>pacientes<br>com LLA:<br>71/120 (59%)|Considerando<br>pacientes<br>com LLA:<br>40/67 (60%)|Pacientes LLA em R1:<br>Média 5,4 meses (DP<br>± 2,5); Pacientes LLA<br>após R1: Média 22<br>meses<br>(DP ± 17,5)|Sobreviventes: 89<br>meses (17–197);<br>transplante autólogo: 99<br>meses (57–197); doador<br>aparentado: 92 meses<br>(17–194); doador não<br>aparentado: 48 meses<br>(18–105)|
|**LALA**|||42 (11-56) (De 154|42 (11-56) (De|89/154 (58%)<br>(De 154|89/154 (58%)<br>(De 154|Alogênico aparentado:<br>113 dias (90-192);<br>Aloênico não||
|**-**<br>**94, 2004**<sup>50</sup>|75|65|pacientes com<br>LLA Ph+)|154 pacientes com<br>LLA Ph+)|pacientes<br>com LLA<br>Ph+)|pacientes<br>com LLA<br>Ph+)|g<br>aparentado: 138 (92-<br>227); Autólogo: 128<br>(79-350)|5 anos|
|**UKALL**<br>**XII/ECO**<br>**G**<br>**2993,**<br>**2009**<sup>27</sup>|Transplante<br>alogênico 'por<br>protocolo': 76 (com<br>doador aparentado<br>n:45 e não<br>aparentado n:31)|Transplante<br>autólogo: 7|40 (15-60)<br>intervenção e<br>controle. Neste<br>grupo 95%<br>pacientes <50 anos|40 (15-60)<br>intervenção e<br>controle. Neste<br>grupo 77%<br>pacientes <50<br>anos|56% (interven|ção e controle)|Alogênico aparentado:<br>153 dias (79-284);<br>Alogênico não-<br>aparentado: 191 dias<br>(113-276); Autólogo:<br>NR|51 sobreviventes: 8 anos<br>e 2 meses (3 anos - 14<br>anos)|  
<mark>N: número de pacientes; Leucemia mielóide crônica; LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo; LMC: Leucemia mielóide crônica; LLA: Leucemia linfoblástica aguda; R1: Primeira remissão; R2:</mark>  
<mark>Segunda remissão; DP: Desvio Padrão; NR: não reportado. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).</mark>  
**Tabela N -** Desfechos de eficácia.  
|**Autor, ano**|**Mortalidade/Sobrevida**<br>**Transplante Alogênico**|**Mortalidade/Sobrevida**<br>**Transplante Autólogo**|**p**|**Resposta**<br>**Alogênico**|**Resposta**<br>**Autólogo**|**p**|
|---|---|---|---|---|---|---|
||**Pacientes LLA Ph+ transplantados em**<br>**R1:**|**Pacientes LLA Ph+ transplantados**<br>**em R1:**|Mortalidade: p =||||
|**Gorin et al. 2015**|Mortalidade não relacionada à recorrência:|Mortalidade não relacionada à recaída:|0,0006|Recorrência: 5/17|Recorrência: 13/36|<br>|
|94|7/17 (43)|1/36 (4)|SLP: p = 0,005|(32)|(36)|p = 0,86|
||SLP: 4/17 (26)|SLP: 21/36 (60)|SG: p = 0,001||||
||SG: 4/17 (26)|SG: 27/36 (76)|||||
||**Pacientes transplantados em R1:**|**Pacientes transplantados em R1:**|||||
|**Hallbook et al.**<br>**2005**<sup>95</sup>|SLP em 5 anos: 30% (IC95% 12-47%)<br>**Pacientes transplantados após R1:**<br>Sobrevida em 7 meses: 0%|SLP em 5 anos: 0%<br>**Pacientes transplantados após R1:**<br>Sobrevida em 7 meses: 0%|SLP em 5 anos:<br>p=0,04|NR|NR|NR|
||Mortalidade relacionada ao tratamento em|Mortalidade relacionada ao tratamento||Recorrência: em 3|Recorrência em 3||
|**LALA-94,**<br>**2004**<sup>50</sup>|3 anos: 22%<br>SG: 21,5 meses|em 3 anos: 26%<br>SG: 14,2 meses|Mortalidade: p= NS|anos: 53%<br>Recorrência em 5|anos: 77%<br>Recorrência em 5|p = 0,003|
||SLP: 34 meses|SLP: 34 meses||anos: 58%|anos: 90%||
||**SG em 5 anos**:<br>Aparentado: 44% (IC95% 29-59)<br>Não aparentado: 36% (IC95% 19-52)|**SG em 5 anos**:<br>Autólogo: 29% (IC95% 0-62)<br>Quimioterapia: 19% (IC95%10-28)|||||
|**UKALLXII/EC**<br>**OG**<br>**2993, 2009**<sup>27</sup>|**SLE em 5 anos:**<br>Aparentado: 41% (IC95% 27-56)<br>Não aparentado: 36% (IC95% 19-52)<br>**SLP em 5 anos:**<br>Aparentado: 57% (IC95% 40-73)<br>Não aparentado: 66% (IC95% 48-85)|**SLE em 5 anos:**<br>Autólogo: 29% (IC95% 0-62)<br>Quimioterapia: 9% (IC95% 3-15)<br>**SLP em 5 anos:**<br>Autólogo: 44% (IC95% 1-88)|NR|NR|NR|NR|  
|**Autor, ano**|**Mortalidade/Sobrevida**<br>**Transplante Alogênico**|**Mortalidade/Sobrevida**<br>**Transplante Autólogo**|**p**|**Resposta**<br>**Alogênico**|**Resposta**<br>**Autólogo**<br>**p**|
|---|---|---|---|---|---|
|||Quimioterapia: 10% (IC95% 3-18)||||  
<mark>LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo; S</mark> LP: Sobrevida livre de progressão; SG: Sobrevida global <mark>; NR: não reportado; NS: Não significativo; SLE: Sobrevida livre de eventos; IC: Intervalo de confiança.</mark>  
<mark>Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo), proporção (Intervalo de confiança de 95%) ou n/N (%).</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>O estudo UKALLXII/ECOG2993 descreveu que no grupo de pacientes que recebeu transplante alogênico aparentado, 29/45 (64%) apresentou doença do enxerto contra hospedeiro, sendo 6/45 (13%) graduadas como 3 e 4. No grupo de pacientes que recebeu transplante alogênico não aparentado, 15/31 (48%) apresentou doença do enxerto contra hospedeiro, sendo 2/31 (6,4%) graduadas como 3 e 4.</mark>  
<mark>Os demais estudos não apresentaram dados de segurança.</mark>  
**<mark>Questão de Pesquisa 5:</mark>** <mark>Qual a eficácia e segurança do tratamento com TKI na fase de manutenção pós-TMO?</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>(((((("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia, Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia)))) AND (((tyrosine kinase inhibitors) OR ("Imatinib Mesylate"[Mesh] OR imatinib OR Gleevec OR Glivec OR STI 571 OR ST 1571 OR CGP 57148 OR CGP57148B)) OR (("Dasatinib"[Mesh] OR dasatinib OR BMS354825 OR Sprycel))))) AND ("Bone Marrow Transplantation"[Mesh] OR Bone marrow transplant OR Bone Marrow Grafting)</mark>  
<mark>Total: 120 referências</mark>  
<mark>Data do acesso: 15/01/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>('protein tyrosine kinase inhibitor'/exp OR 'tyrosine kinase inhibitor' AND [embase]/lim) OR [('imatinib'/exp/mj AND [embase]/lim) OR ('gleevec'/mj AND [embase]/lim) OR ('glivec'/mj AND [embase]/lim)] OR ('dasatinib'/exp/mj AND [embase]/lim OR sprycel AND [embase]/lim)</mark>  
<mark>('bone marrow transplantation'/exp OR 'bone marrow transplantation' AND [embase]/lim) OR ('bone'/exp OR bone AND ('marrow'/exp OR marrow) AND ('transplant'/exp OR transplant) AND [embase]/lim) OR ('bone'/exp OR bone AND ('marrow'/exp OR marrow) AND ('grafting'/exp OR grafting) AND [embase]/lim)</mark>  
<mark>([young adult]/lim OR [adult]/lim OR [middle aged]/lim OR [aged]/lim OR [very elderly]/lim) AND [embase]/lim</mark>  
<mark>Total: 205 referências</mark>  
<mark>Data do acesso: 16/01/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 325 referencias (120 no MEDLINE e 205 no Embase). Destas, 33 foram excluídas por estarem duplicadas. Duzentas e noventa e duas referências foram triadas por meio da leitura de título e resumos, das quais 12 tiveram seus textos completos avaliados para confirmação da elegibilidade. Três estudos foram excluídos por analisar o efeito das iTKs no pós-transplante considerando conjuntamente populações com LLA e LMC. Um estudo foi adicionalmente excluído por ser relato de caso. Dois estudos referem-se à avaliação do uso dos iTKs no período pós-transplante, como tratamento da recorrência molecular e foram considerados para a questão de pesquisa 3 (Qual a</mark>  
<mark>eficácia e segurança do uso de TKI pós-TMO?). Por fim, seis estudos foram selecionados por avaliarem o uso de iTKs no período</mark>  
<mark>pré e manutenção das iTKs no período pós-transplante.</mark>  
**3** **<mark>) Descrição dos estudos e seus resultados</mark>**  
<mark>A descrição sumária dos estudos encontra-se na Tabela O. As características dos pacientes encontram-se descritas na</mark>  
<mark>Tabela P. As Tabelas Q e R apresentam dados de eficácia e segurança, respectivamente.</mark>  
**Tabela O -** Características dos estudos.  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Burke et**<br>**al. 2008**<sup>96</sup>|Estudo<br>observacional<br>comparativo<br>retrospectivo|Avaliar a eficácia do<br>imatinibe no peri e pós-<br>TMO|Pacientes com LLA<br>Ph+|As doses de imatinibe variaram de 240 a<br>340mg/ m2/dia para pediátricos e 400 a<br>800mg/dia para adultos. Quando a<br>terapêutica com imatinibe foi iniciada pós-<br>TMO, iniciou-se em média, no dia +120<br>(intervalo: 80-180) e continuou até o dia|O estudo apresenta uma análise<br>de grupos. Dezessete dos 32<br>pacientes não receberam<br>imatinibe. Porém, alguns<br>desfechos são apresentados em<br>relação ao grupo que apenas|Alto risco:<br>análise<br>retrospectiva e<br>com viés de<br>seleção|
|||||+365|recebeu imatinibe no pré-TMO||
||||Pacientes com LLA<br>Ph+ e LMC adultos e<br>pediátricos.||||
|**Carpenter**<br>**et al.**<br>**2007**<sup>97</sup>|Estudo<br>observacional<br>prospectivo|Avaliar a eficácia do<br>imatinibe no pós-TMO|Apresentados apenas<br>os dados referentes à<br>população com LLA<br>Ph+, sendo que o|Imatinibe 400mg/dia em adultos e<br>260mg/m2/dia em crianças. 14/15<br>pacientes com LLA Ph+ receberam<br>imatinibe pré-TMO|NA|Alto risco: série<br>de casos para<br>avaliar eficácia|
||||estudo não apresenta||||
||||os resultados por||||
||||faixa etária||||
|||||Tratamento com imatinibe durante 3-12||Alto risco: viés|
||Estudo|||meses pós-TMO, até que os níveis de||de seleção (os|
|**Chen et**<br>**al. 2012**<sup>75</sup>|observacional<br>prospectivo,<br>comparativo,|Avaliar o tratamento com<br>imatinibe no pós-TMO|Pacientes com LLA<br>Ph+ < 60 anos|transcrição BCR-ABL fossem negativos<br>pelo menos 3 testes consecutivos. Dose<br>inicial de imatinibe de 400mg/dia para|Pacientes que não receberam<br>outra terapia pós-TMO|pacientes que<br>não receberam o<br>tratamento|
||fase 2|||adultos (> 17 anos) e 260mg/m2/dia para||tinham|
|||||crianças (<17 anos)||contraindicação|  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||||para receber|
|||||||imatinibe)|  
|**Kebriaei**<br>**et al.**<br>**2012**<sup>98</sup>|Estudo<br>observacional<br>retrospectivo|Avaliar a eficácia dos<br>iTK de manutenção pós-<br>TMO (iTK administrado<br>nos primeiros 6 meses<br>pós-TMO na ausência de<br>doença|Pacientes adultos e<br>pediátricos com LLA<br>Ph+|Imatinibe como linha de frente de<br>tratamento + quimioterapia HCVAD, dose<br>entre 400 e 800mg, em 62 pacientes; e 11<br>pacientes receberam dasatinibe entre 50 e<br>140mg. No pós-TMO, imatinibe foi<br>utilizado em todos exceto um paciente<br>(que recebeu dasatinibe também como<br>tratamento de linha de frente antes do<br>TMO)|NA|Alto risco:<br>análise<br>retrospectiva não<br>comparativa com<br>o objetivo de<br>avaliar eficácia|
|---|---|---|---|---|---|---|
|**Pfeifer et**<br>**al. 2013**<sup>58</sup>|Ensaio clínico<br>randomizado,<br>multicêntrico<br>(publicação<br>refere-se à uma<br>análise interina<br>dos 55 primeiros<br>pacientes)|Comparar duas<br>estratégias: imatinibe<br>profilático logo que<br>clinicamente viável no<br>pós-TMO (fase de<br>manutenção)_versus_<br>imatinibe administrado<br>na DRM desencadeada<br>após a primeira detecção<br>de BCR-ABL1<br>(recorrência molecular)|Pacientes >18 anos<br>com LLA Ph+<br>(n=54) ou LMC em<br>crise blástica (n=1)<br>que receberam TMO<br>na primeira remissão<br>completa|Imatinibe 600mg (sendo400mg também<br>permitido) profilático, iniciado em uma<br>mediana de 48 dias (23-88)|Imatinibe 600mg (sendo 400mg<br>também permitido) após a<br>detecção de DRM (que ocorreu<br>em uma mediana de 70 dias<br>pós-transplante (39-567)<br>Pacientes com DRM detectada<br>por RT-PCR e confirmada por<br>nested-PCR|Alto risco:<br>randomização e<br>sigilo da<br>alocação não<br>foram<br>adequadamente<br>descritos|  
|**Autor,**<br>**ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Ribera et**<br>**al. 2010**<sup>54</sup>|Estudo<br>observacional,<br>prospectivo, fase<br>2|Avaliar a eficácia da<br>administração<br>concomitante de<br>imatinibe e quimioterapia<br>intensiva durante a<br>indução e consolidação<br>da remissão e a<br>viabilidade e eficácia do<br>imatinibe pós-TMO<br>autólogo ou alogênico. O<br>imatinibe foi<br>administrado em 13 dos<br>21 pacientes<br>transplantados|Pacientes até 65 anos<br>de idade com LLA<br>Ph + recentemente<br>diagnosticada|Interrupção do imatinibe 15 dias antes do<br>TMO. Após TMO, imatinibe (400 mg/dia)<br>a partir do momento da RHC durante pelo<br>menos 1 ano se a remissão molecular<br>persistisse. Se a toxicidade ou intolerância<br>relacionada com o imatinibe ocorresse, a<br>dose poderia ser reduzida para 300 ou<br>200mg antes de considerar sua<br>descontinuação definitiva|NA|Alto risco: série<br>de casos não<br>comparativa com<br>o objetivo de<br>avaliar eficácia|  
TMO: transplante de medula óssea; NA: não se aplica; <mark>LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo; LMC: leucemia mielóide crônica; i</mark> TKs: Inibidores da Tirosina-quinase; <mark>HCVAD: quimioterapia</mark>  
<mark>hiperfracionada com ciclofosfamida + vincristina+ doxorubicina + dexametasona; DRM:</mark> Doença Residual Mínima; <mark>PCR: proteína C reativa; RHM: resposta hematológica completa.</mark>  
**Tabela P -** Características dos pacientes.  
|**Autor,**<br>**ano**|**N intervenção**|**N controle**|**Idade**<br>**Intervenção**<br>|**Idade**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**<br>**pós-TMO**|**Tempo**<br>**entre o**<br>**diagnóstico**<br>**e TMO**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**<br>**após TMO**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Burke et**<br>**al. 2008**<sup>96</sup>|15 pacientes,<br>sendo que 9<br>receberam<br>imatinibe<br>apenas pré-<br>TMO, 2<br>receberam pré e<br>pós-TMO, 2<br>somente pós-<br>TMO, e 2 no<br>pré-TMO e na<br>recorrência|17<br>pacientes,<br>sendo que<br>11 nunca<br>receberam<br>e 6<br>receberam<br>apenas na<br>recorrência|21,9 (2,8-5<br>Foi apresentad<br>total de pacie<br>estudo|5,2)<br>o para o<br>ntes no<br>|18/32 (<br>Foi apresent<br>total de pac<br>estud|56,3)<br>ado para o<br>ientes no<br>o|NR|Grupo<br>imatinibe:<br>164 dias<br>(NR).<br>Grupo<br>controle:<br>154 dias<br>(NR)|NR|NA|0,93 anos<br>(0,04–4,86)|
||27 pacientes<br>(LLA Ph+ e||||||Administração|||||
||LMC), sendo 2||||||do imatinibe|||||
|**Carpenter**<br>**et al.**<br>**2007**<sup>97</sup>|óbitos, 1<br>recorrência<br>maligna antes<br>da<br>administração|NA|37 (4-49)|NA|7/15 (47)|NA|pós-TMO: 27<br>dias (21-39).<br>Tempo de<br>tratamento:<br>334 dias (44-|NR|NR|NA|1,4 anos<br>(0,74-2,7)|
||do imatinibe e 2<br>tiveram||||||426)|||||  
|**Autor,**<br>**ano**|**N intervenção**|**N controle**|**Idade**<br>**Intervenção**|**Idade**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**<br>**pós-TMO**|**Tempo**<br>**entre o**<br>**diagnóstico**<br>**e TMO**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**<br>**após TMO**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||contraindicação<br>para imatinibe.<br>Quinze|||||||||||
||pacientes com|||||||||||
||LLA Ph+ foram<br>avaliados.|||||||||||
|||20|||||||||Grupo<br>imatinibe: 31|
|**Chen et al.**<br>**2012**<sup>75</sup>|62 pacientes<br>receberam o<br>imatinibe|pacientes<br>que não<br>receberam|29(6-50)|27,5(3-<br>51)|43/62 (69)|12/20 (60)|90 dias (13-<br>540)|NR|NR|NA|meses (2,5-<br>76).<br>Controle:|
|||imatinibe|||||||||24,5 meses<br>(4-72)|
|||||||||||Recorrência da||
|**Kebriaei**<br>**et al.**<br>**2012**<sup>98</sup>|113 pacientes,<br>sendo 102<br>adultos e 11<br>crianças|NA|37,5 (3-63)|NA|58/113 (51)|NA|10,6 meses<br>(0,6-64)|6,2 meses<br>(1,6-130,9)|19/113 (16,8)|doença (7),<br>conclusão da<br>terapia planejada<br>em 1 ano (11),<br>toxicidade (2)|5 anos (1,1-<br>20,4) nos 75<br>sobreviventes|  
|**Autor,**<br>**ano**|**N intervenção**|**N controle**|**Idade**<br>**Intervenção**|**Idade**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**<br>**pós-TMO**|**Tempo**<br>**entre o**<br>**diagnóstico**<br>**e TMO**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**<br>**após TMO**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Pfeifer et**<br>**al. 2013**<sup>58</sup>|26 pacientes|29|39 (18–56)|43 (19–<br>68)|17/26 (65)|14/29 (48)|Grupo A: 201<br>dias (4-927).<br>Grupo B:127<br>dias (18-964)|Grupo A:<br>4,5 meses.<br>Grupo B:<br>4,8 meses|Grupo A: 16/26<br>(67). Grupo B:<br>10/29 (71)|EA grave (13),<br>não aderência (2),<br>óbito em RC1<br>(1),<br>recorrência (4)<br>persistência de<br>DMR (2)|Grupo A:<br>30,3 meses<br>(5,3-64,2).<br>Grupo B:<br>32,4 (9,5-<br>69,3)|
|**Ribera et**<br>**al. 2010**<sup>54</sup>|30 pacientes<br>tratados desde o<br>início e 21<br>submetidos a<br>TMO após RC1<br>(16 TMO<br>alogênico e 5<br>TMO autólogo)|NA|44 (8-62)|NA|16/30 (53)|NA|TMO autólogo:<br>2 de 4<br>pacientes em<br>tratamento por<br>até 60 meses.<br>TMO<br>alogênico: 9<br>pacientes em<br>tratamento por<br>9 meses (1-27)|Tempo<br>entre a RC<br>e TMO:<br>187 dias<br>(129-297)|Pré-TMO: 9/21<br>(43). Pós-TMO:<br>2/10 (20)|Pré-TMO:<br>recorrência (3),<br>doença do<br>enxerto contra o<br>hospedeiro (2),<br>toxicidade (2),<br>óbito não<br>associado à<br>recorrência (1),<br>decisão do<br>paciente (1). Pós-<br>TMO: toxicidade<br>(2)|4,1 anos (3,9-<br>4,8)|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; T</mark> MO: transplante de medula óssea; <mark>NR: não reportado; N</mark> A: não se aplica; <mark>LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo;</mark>  
<mark>LMC: leucemia mielóide crônica; EA: evento adverso; RC1: primeira remissão completa; DRM: D</mark> oença Residual Mínima. <mark>Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).</mark>  
**Tabela Q -** Desfechos de eficácia.  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
||Imatinibe|Mortalidade relacionada ao TMO (todo o grupo):<br>3/15 (20)<br>SG em 2 anos: 100%<br>SLP em 2 anos: 100%|Recorrência (todo o grupo): 2/15 (13)<br>Recorrência no grupo imatinibe pós-<br>TMO em 2 anos (n=2): 0|NR|NR|
|**Burke et al.**<br>**2008**<sup>96</sup>|Controle|Mortalidade relacionada ao TMO (grupo sem<br>imatinibe): 5/17 (29)<br>SG em 2 anos (imatinibe apenas no pré-TMO): 52%<br>SLP em 2 anos (imatinibe apenas no pré-TMO): 62%|Recorrência (todo o grupo): 6/17 (35)<br>Recorrência no grupo imatinibe somente<br>pré-TMO em 2 anos (n=13): 2/13 (15,4)|NR|NR|
||P|Mortalidade: p=0,57<br>SG: p=0,28<br>SLP=0,34|Recorrência: p=0,20<br>Recorrência no grupo pré-TMO: p=0,55|NA|NA|
||||Recorrência: 2/15 (13)|||
|**Carpenter et**<br>**al. 2007**<sup>97</sup>|NA|Mortalidade: 3/15 (20)|RH: 13/15 (87)<br>RC: 13/13 (100)<br>RM (FISH): 13/13 (100)<br>RM (q-PCR): 12/13 (92)|NR|NR|
|**Chen et al.**<br>**2012**<sup>75</sup>|Imatinibe|Mortalidade não relacionada à recorrência: 4/62 (6)<br>Probabilidade de recorrência em 5 anos: 10,2%<br>±3,9%<br>Sobreviventes: 52/62 (84)<br>Probabilidade de SLP em 5 anos: 81,5%± 5,0%|RH: 4/62 (6)<br>RLE: 1/62 (2)|Tempo até recorrência:<br>9,5 meses (2,5-17,5)|NR|
|||Probabilidade de SG em 5 anos: 86,7% ± 4,4%||||  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
|||Mortalidade não relacionada à recorrência: 7/20 (35)<br>Probabilidade de recorrência em 5 anos: 33,1%||||
||Controle|±10,8%<br>Sobreviventes: 8/20 (40)<br>Probabilidade de SLP em 5 anos: 33,5%± 10,6%<br>Probabilidade de SG em 5 anos: 34,3%± 10,5%|RH: 7/20 (35)<br>RLE: 1/10 (10)|Tempo até recorrência:<br>12 meses (3-22)|NR|
|||Mortalidade: p=0,0006||||
|||Recorrência: p= 0,016||||
||P|Sobrevida: NR<br>SLP em 5 anos: p< 0,001<br>SG em 5 anos: p<0,001|NR|NR|NA|
|||SLP em 2 e 5 anos: 36% e 31%<br>SLP em 5 anos no estrato TMO na RC1: 42%<br>SLP em 5 anos no estrato TMO na RC2: 9%<br>SLP em 5 anos no estrato TMO com doença ativa no<br>momento do transplante: 16%||||
|**Kebriaei et al.**<br>**2012**<sup>98</sup>|NA|SG em 2 e 5 anos: 44% e 33%.<br>SG em 5 anos no estrato TMO na RC1: 43%<br>SG em 5 anos no estrato TMO na RC2: 9%<br>SG em 5 anos no estrato TMO com doença ativa no<br>momento do transplante: 16%<br>Análise multivariada para mortalidade e iTK pré-<br>TMO: HR 1,1 (IC 95% 0,4-2,8); p=0,9<br>Incidência cumulativa de mortalidade não|RC: 103/105 (98)<br>Recorrência: 33 pacientes em mediana<br>de 5 meses (1-39) pós-TMO|NR|NR|  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
|||relacionada à recorrência em 100 dias, 2 e 5 anos:<br>17%, 35% e 39%||||
||Imatinibe<br>profilático|Remissão em 5 anos: 91,6%<br>SLP: 83,9%<br>SLE até recorrência: 72,1%<br>SG: 80,1%|Probabilidade de não atingir DRM (PCR<br>-) em 46 meses pós-TMO: 45,6%<br>Frequência de DRM pós-TMO:10/26<br>(40)<br>Manutenção da RC: 81%|NR|Duração da RM: 26,5<br>meses|
|**Pfeifer et al.**<br>**2013**<sup>58</sup>|Imatinibe<br>pós-DRM|Remissão em 5 anos: 75,5%<br>SLP: 60,4%<br>SLE até recorrência: 53,3%<br>SG: 74,5%|Probabilidade de não atingir DRM (PCR<br>-) em 46 meses pós-TMO: 27,4%<br>Frequência de DRM pós-TMO: 20/29<br>(69)<br>Manutenção da RC: 78%|NR|Duração da RM: 6,8<br>meses|
||P|Remissão: p=0,65<br>SLP: p=0,89<br>SLE: p=0,89<br>SG: p=0,84|Probabilidade de não atingir DRM:<br>p=0,074<br>Frequência de DRM: p=0,046|NA|p=0,06|
|**Ribera et al.**<br>**2010**<sup>54</sup>|NA|SLP: 1,5 anos<br>SG: 1,7 anos|RC: 27/30 (90)|NR|NR|  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
|||Probabilidade de SLP: 30% (IC 95% 16-45)||||
|||Probabilidade de SG: 30% (IC 95% 15-45)||||  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento;</mark> TMO: transplante de medula óssea <mark>; NR: não reportado; NA: Não se aplica;</mark> SG: Sobrevida global; SLP: Sobrevida livre de progressão; RH: Remissão  
hematológica; RC: Remissão citogenética; RM: remissão molecular; q-PCR: reação em cadeia da polimerase quantitativa; RLE: recorrência de leucemia extramedular; RC1: primeira remissão completa; RC2: segunda remissão completa; iTKs: Inibidores da Tirosina-quinase; HR: hazard ratio; SLE: sobrevida livre de eventos; RM: remissão molecular. <mark>Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou mediana (Intervalo de confiança de 95%) ou n/N (%).</mark>  
**Tabela R -** Eventos adversos.  
||||**Auto**|**r, ano**|||
|---|---|---|---|---|---|---|
|||||**Kebriaei**|||
|**Eventos adversos**<br>**(Grau 3-5)**|**Burke et**<br>**al. 2008**|**Carpenter**<br>**et al. 2007**|**Chen et al.**<br>**2012**|<br>**et al.**<br>**2012**|**Pfeifer et**<br>**al. 2013**|**Ribera et al.**<br>**2010**|
|Alterações renais e hepáticas|NR|NR|NR|NR|1/38 (2,6)|NR|
|Constipação|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Desequilíbrio hidroeletrolítico|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Edema|NR|NR|3/62 (4,8)|NR|NR|1/30 (3,3) *|
|Elevação de bilirrubina|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Elevação de creatinina|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Elevação de transaminases|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Estomatite|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Evento hematológico|NR|NR|4/62 (6,4)|NR|NR|NR|
|Fadiga|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Falência do enxerto|NR|NR|NR|NR|1/38 (2,6)|NR|
|Fibrose pulmonar|NR|NR|NR|NR|1/38 (2,6)|NR|
|Hemorragia de retina|NR|NR|NR|NR|1/38 (2,6)|NR|
|Ileus|NR|NR|NR|NR|NR|1/30 (3,3) *|
|Infecção|NR|NR|NR|NR|NR|11/30 (37) *|
|Intolerância gastrointestinal|NR|NR|NR|NR|6/38 (15,8)|NR|
|Náusea/vômitos|NR|NR|4/62 (6,4)|NR|NR|1/30 (3,3) *|
|Neutropenia|NR|NR|4/62 (6,4)|NR|1/38 (2,6)|25/30 (83,3) *|
|Toxicidade cardíaca|10/32<br>(31,2)|NR|NR|NR|NR|NR|
|Trombocitopenia|NR|NR|2/62 (3,2)|NR|NR|15/30 (50) *|  
<mark>NR: não reportado. Dados foram apresentados em n/N (%).</mark>  
<mark>* No período de indução.</mark>  
**<mark>Questão de Pesquisa 6:</mark>** <mark>Quais são os resultados de eficácia e segurança das diferentes intensidades (ex.: reduced intensity) de quimioterapia?</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>((((((("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia, Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia))))) AND (((((("Induction Chemotherapy"[Mesh] OR Induction Chemotherapy)) OR ("Consolidation Chemotherapy"[Mesh] OR Consolidation Chemotherapy)) OR ("Maintenance Chemotherapy"[Mesh] OR Maintenance Chemotherapy))) OR "Antineoplastic Combined Chemotherapy Protocols"[Mesh])) AND ((("administration and dosage" [Subheading] OR Therapeutic scheme OR reduced intensity OR reduced-intensity chemotherapy OR low-intensity chemotherapy)))) AND (((("aged"[MeSH Terms] OR "adult"[MeSH Terms:noexp] OR "adult"[MeSH Terms] OR of age OR middle age)))) Filters: Meta-Analysis; Randomized Controlled Trial; Systematic Reviews</mark>  
<mark>Total: 165 referências</mark>  
<mark>Data do acesso: 15/01/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>'chemotherapy'/exp OR 'chemotherapy' AND [embase]/lim</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>('dose calculation'/exp AND [embase]/lim) OR ('reduced intensity' AND ('chemotherapy'/exp OR chemotherapy) AND [embase]/lim) OR ('low intensity' AND ('chemotherapy'/exp OR chemotherapy) AND [embase]/lim)</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>([young adult]/lim OR [adult]/lim OR [middle aged]/lim OR [aged]/lim OR [very elderly]/lim) AND [embase]/lim</mark>  
<mark>Total: 152 referências</mark>  
<mark>Data do acesso: 16/01/2017</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 317 referências (165 no MEDLINE e 152 no Embase). Destas, duas foram excluídas por estarem duplicadas. Trezentas e quinze referências foram triadas por meio da leitura de título e resumos, das quais 18 tiveram seus textos completos avaliados para confirmação da elegibilidade. Quatorze publicações foram excluídas nesta etapa por não apresentarem dados para o extrato de pacientes com LLA Ph+, sendo sete resumos de congresso referentes ao mesmo estudo. Adicionalmente foi identificado um estudo apresentado em congresso por meio de busca manual. Ao final, quatro estudos (cinco publicações) foram incluídos.</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
<mark>A descrição sumária dos estudos encontra-se na Tabela S. As características dos pacientes encontram-se descritas na Tabela T. As Tabelas U e V apresentam dados de eficácia e segurança, respectivamente.</mark>  
**Tabela S** - Características dos estudos.  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Chalandon**<br>**et al.**<br>**2015**<sup>24</sup>|ECR<br>multicêntrico|Avaliar o efeito de<br>quimioterapia de baixa<br>intensidade + imatinibe<br>_vs._quimioterapia<br>convencional (HCVAD)<br>+ imatinibe|Pacientes adultos<br>com diagnóstico<br>recente de LLA Ph+<br>e/ou BCR-ABL1+.<br>Dos 270 pacientes<br>incluídos, 247 eram<br>LLA Ph+|Pré-fase com PDN 60mg/m2/dia VO e MTX<br>15mg IT. Ciclo 1: Imatinibe 400mg 2x/dia VO<br>nos dias 1 a 28 + VCR 2mg/dia EV nos dias 1,<br>8, 15 e 22 + DXM 40mg/dia VO nos dias 1-2,<br>8-9, 15-16, 22-23. Ciclo 2: Imatinibe 400mg<br>2x/dia VO nos dias 1 a 14 + MTX<br>1000mg/m2/dia EV continuo no dia 1 +<br>Citarabina 3000 mg/m2/12h EV nos dias 2-3.|Pré-fase idêntica ao grupo<br>experimental. Ciclo 1: Ciclo 1:<br>Imatinibe 400mg 2x/dia VO<br>nos dias 1 a 14 + HCVAD<br>padrão. Ciclo 2: idêntico ao<br>grupo experimental. Interfase<br>pré-transplante; ciclos<br>subsequentes para pacientes<br>que não receberam transplante e<br>manutenção foram iguais entre|<br>Alto risco: Não<br>descrito como<br>foi realizada a<br>randomização e<br>sigilo da<br>alocação|
||||||os grupos||
||||Pacientes adultos|Pré-fase com DXM 10mg/dia nos dias -7 a -3.<br>Indução: 4 semanas com dasatinibe 140mg<br>1x/dia + VCR semanal 2mg/EV + DXM 40mg|||
|||Avaliar eficácia e|com LLA Ph+,|por 2 dias. Consolidação: dasatinibe||Alto risco:|
|**Rousselot**|Série de casos|segurança do dasatinibe|virgens de|100mg/dia, MTX 1000mg/m2 EV no dia 1 e||Dados de|
|<br>**et al.**<br>**2016**<sup>42</sup>|(estudo fase<br>2),|+ quimioterapia no<br>tratamento inicial de|tratamento<br>quimioterápico.|asparaginase 10000 IU/m2 IM no dia 2 nos<br>ciclos 1, 3, 5, e citarabina 1000mg/m2 EV a|NA|eficácia<br>provenientes de|
||multicêntrico|pacientes idosos com|Permitido uso prévio|12/12h nos dias 1, 3, 5 nos ciclos 2, 4, 6, em||série de casos|
|||LLA Ph+|de esteróides ou<br>dose única de VCR|ciclos de 4 semanas. Manutenção: dasatinibe<br>100 mg/dia seguido de 6-mercaptopurina (60<br>mg/m2/dia) e MTX (25mg/m2/semana) VO||não controlada|
|||||1x/mês, e DXM/VCR a cada 2-3 meses até 24|||  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**<br>meses. Pós-manutenção: monoterapia com<br>dasatinibe|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Rea et al.**<br>**2006**<sup>99</sup>|Estudo piloto<br>experimental<br>controlado|Avaliar o efeito de<br>esquema de imatinibe<br>em alta intensidade +<br>quimioterapia de baixa<br>intensidade|Pacientes adultos<br>com LLA Ph+<br>(n=18) e LMC em<br>crise blastica (n=13).<br>Dados de eficácia<br>apresentados apenas<br>para o estrato LLA<br>Ph+; dados de<br>segurança<br>apresentados para<br>todos os pacientes<br>agregados|Ciclo único curso de indução com Imatinibe<br>800mg/dia (400mg 2x) até recuperação<br>hematológica por no máximo 56 dias + VCR<br>2mg EV nos dias 1, 8, 15 e 22 + DXM 40mg<br>VO ou EV nos dias 1-2, 8-9, 15-16 e 22-23.<br>Profilaxia do SNC com quatro injeções IT de<br>MTX 15mg + citosina arabinósido 40mg +<br>DXM 40mg nos dias 1, 8, 15 e 22.|NA|Alto risco:<br>estudo piloto<br>com pequeno<br>tamanho<br>amostral, não<br>controlado|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
||||||Protocolo RALL-2009,|Alto risco:|
|**Gavrilina**<br>**et al.**<br>**2016**<sup>61</sup>|Estudo<br>observacional<br>controlado<br>retrospectivo<br>(registro em<br>base de<br>dados)|Avaliar a efetividade do<br>protocolo RALL-2009<br>com ITK (convencional)<br>e RALL-Ph+-2012<br>(intensidade reduzida)<br>em pacientes com LLA<br>Ph+|Pacientes com LLA<br>Ph+ (n=25)|RALL-Ph+2012, utilizado entre 2012-2016<br>(n=15 pacientes), consistiu de Imatinibe<br>600mg+PDN, VCR, L-asp, seguido de 6-MP e<br>MTX. Ambos os protocolos sugerem mudança<br>para dasatinibe (100-140mg) se RMC não for<br>obtida em 70 dias de tratamento|utilizado entre 2010-2012<br>(n=10 pacientes) inclui 8 drogas<br>citostáticas, sem intervalo entre<br>as fases de tratamento. Ambos<br>os protocolos sugerem mudança<br>para dasatinibe (100-140mg) se<br>RMC não for obtida em 70 dias|<br> <br>Dados de<br>eficácia<br>provenientes de<br>pequena série de<br>casos<br>retrospectiva<br>com controle não|
||||||de tratamento|concorrente|  
ECR: Ensaio clínico randomizado; <mark>HCVAD: quimioterapia hiperfracionada com ciclofosfamida + vincristina+ doxorubicina + dexametasona; LLA Ph+: Leucemia linfoblástica aguda cromossomo Philadelphia positivo; PDN: Prednisona; VO: Via oral; MTX: metotrexato; IT: intratecal; VCR: Vincristina; EV: Endovenoso; DXM: doxorrubicina; HCVAD: quimioterapia hiperfracionada com ciclofosfamida + vincristina+ doxorubicina + dexametasona; IM: Intramuscular; NA: Não se aplica; SNC: Sistema nervoso central; ITK: Inibidores de tirosina quinase; L-asp: L-Asparaginase; 6-MP: 6-Mercaptopurine; RMC: resposta molecular completa.</mark>  
**Tabela T** - Características dos pacientes.  
|**Autor, ano**|**N**<br>**intervençã**<br>**o**|**N**<br>**controle**|**Idade**<br>**intervençã**<br>**o**|**Idade,**<br>**controle**|**% sexo**<br>**masculino**<br>**intervençã**<br>**o**|**% sexo**<br>**masculino**<br>**controle**|**Tempo de tratamento**|**Descontinuaçã**<br>**o**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(n paciente)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Chalandon**<br>**et al. 2015**<sup>24</sup>|135|133|48,6 (18-<br>59)|45 (21-<br>59)|63 (46,6%)|82 (61,6%)|Durante ciclo 1: Uso de<br>imatinibe: mediana de 28<br>dias (1-35) no grupo<br>experimental e 14 dias<br>(7-28) no grupo controle.|NR|NR|Mediana 4,8<br>anos|
|**Rousselot et**<br>**al. 2016**<sup>42</sup>|71|NA|69 (59-83)|NA|42|NA|7,8 meses (0,6-72,4)|59/71 (83)|Recaída ou óbito (38),<br>evento adverso (14),<br>transplante (7)|32 meses<br>(2-88)|
|**Rea et al.**<br>**2006**<sup>99</sup>|31 (sendo<br>18 com<br>LLA Ph+)|NA|50 (10-65)|NA|14/18 (77,7)|NA|NR|3/31<br>(descontinuaçã<br>o temporária)|Pancitopenia grave<br>(1), retenção de fluido<br>(1), náusea (1)|256 dias<br>(28-1049)|
|**Gavrilina et**<br>**al. 2016**<sup>61</sup>|15|10|40 (17-61)|35 (19-<br>68)|7/15 (46,7)|5/10 (50)|NR|NR|NR|3 anos|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; NR: não reportado; NA: não se aplica. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).</mark>  
**Tabela U** - Desfechos de eficácia.  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
||Intervenção|SLP em 5 anos: 42,2% (IC95% 33,5-50,6)<br>SG em 5 anos: 48,3% (IC95% 39,2-56,8)<br>Mortalidade: 66/135 (48,9)|RMM na segunda remissão: 66,1%<br>RHC: 98,5%<br>Recorrência: 43/135<br>Incidência cumulativa de recorrência em 5<br>anos: 32,8% (IC95%25,4-41,5)|NR|NR|
|**Chalandon et al.**<br>**2015**<sup>24</sup>|Controle|SLP em 5 anos: 32,1% (IC95% 24,0-40,4)<br>SG em 5 anos: 43% (IC95% 33,9-51,7)<br>Mortalidade: 62/133 (46,6)|RMM na segunda remissão: 64,5%<br>RHC: 91%<br>Recorrência: 49/133<br>Incidência cumulativa de recorrência: em 5<br>anos: 41,3% (IC95% 33-50,8)|NR|NR|
||P ou HR|SLP: HR 1,27 (IC95% 0,93-1,72), p=0,13<br>SG: HR 1,17 (IC95% 0,84-1,62), p=0,37|RMM: p=0,88<br>RHC: p=0,006<br>Incidência cumulativa: p=0,34|NA|NA|
|**Rousselot et al.**<br>**2016**<sup>42</sup>|NA|Mortalidade: 49/71 (69)<br>SG: 25,8 meses<br>SG: 45% (43%-67%)<br>Sobrevida livre de evento (óbito, recidiva<br>hematológica): 18,9 meses<br>SLP: 19,1 meses|RC: 67/71 (96)<br>DRM: 33/55 (60)<br>RMM: 36/55 (65)|NR|Até recidiva: 36/71 (51)<br>Incidência cumulativa de<br>recaída em 5 anos: 54%<br>(IC95% 42-66)|
|**Rea et al. 2006**<sup>99</sup>|NA|Mortalidade: 8/18 (44,4)<br>SG: 404 dias*<br>SLP (para os que tingiram RHM): 228<br>dias*|RHC: 17/18 (94,4)<br>RCC ou parcial: 10/11 (90,9)<br>RMC: 1/15 (6,7)|Tempo até RHC:<br>33,5 dias (mín-<br>máx): 20-68)|NR|  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Duração da resposta**|
|---|---|---|---|---|---|
|||Mortalidade em 2 meses: 0/15|RMC em 70 dias: 6/15 (40)|||
||Intervenção|SG em 3 anos: 27,7%|RHC em 70 dias: 15/15 (100)|NR|NR|
|||SLP em 3 anos: 22,1%|Probabilidade de recorrência em 3 anos: 57%|||
|**Gavrilina et al.**<br>**2016**<sup>61</sup>|Controle|Mortalidade em 2 meses: 2/10<br>SG em 3 anos: 45%<br>SLP em 3 anos: 45%|RMC em 70 dias: 4/10 (40)<br>RHC em 70 dias: 8/10 (80)<br>Probabilidade de recorrência em 3 anos:<br>35,7%|NR|NR|
||P|SG em 3 anos: p=0,27<br>SLP: p=0,94|Probabilidade de recorrência em 3 anos:<br>p=0,29|NA|NA|  
<mark>N: número de pacientes; n: número de pacientes que apresentaram o evento; S</mark> LP: Sobrevida livre de progressão; SG: Sobrevida global; RMM: Resposta molecular maior; RHC: Resposta hematológica completa; <mark>NR: não reportado;</mark> HR: Hazard ratio; <mark>NA: não se aplica;</mark> RC: remissão completa; DRM: Doença residual mínima; RHM: Resposta hematológica maior; RCC: Resposta citogenética completa; RMC: Remissão molecular completa. *Dados agregados para LLA Ph+ e LMC.  
**Tabela V -** Eventos adversos.  
|||**Autor, ano**||||
|---|---|---|---|---|---|
|**E d**|**Chalandon et al.**|**Chalandon et al.**||||
|**ventos aversos**<br>**(Grau 3-4)**|**2015**<br>Grupo baixa<br>intensidade|**2015**<br>Grupo alta<br>intensidade|**Rousselot et**<br>**al. 2016**|**Rea et al.**<br>**2006**|**Gavrilina**<br>**et al. 2016**|
|**Arritmia cardíaca**|NR|NR|4/71 (5,6)|NR|NR|
|**Bacteremia/septicemia**|NR|NR|13/71 (18,3)|NR|NR|
|**Derrame pericárdico**|NR|NR|1/71 (1,4)|NR|NR|
|**Derrame Pleural**|NR|NR|7/71 (98)|NR|NR|
|**Elevação de TGO/TGP**|NR|NR|5/71 (7)|NR|NR|
|**Embolia pulmonar**|NR|NR|3/71 (4,2)|NR|NR|
|**Hematoma subdural**|NR|NR|1/71 (1,4)|1/31|NR|
|**Infecção**|Ciclo 1: 50/135 (37)<br>Ciclo 2: 60/135 (44)|Ciclo 1: 77/133 (58)<br>Ciclo 2: 42/133 (32)|NR|10/31 (32)|NR|
|**Insuficiência cardíaca**|NR|NR|NR|2/72 (2,8)|NR|
|**Insuficiência renal aguda**|NR|NR|NR|1/71 (1,4)|NR|
||||11 (fase|||
|**Náusea**|NR|NR|manutenção);<br>4 (fase<br>consolidação)|3/31|NR|
|**Pneumonia não bacteriana**|NR|NR|2/72 (2,8)|NR|NR|
|**Sangramento**<br>**gastrointestinal**|NR|NR|3/71 (4,2)|NR|NR|
|**Síndrome de lise tumoral**|NR|NR|1/71 (1,4)|NR|NR|
|**Outros eventos**<br>**Classe 3-4**|Ciclo 1: 56/135 (41)<br>Ciclo 2: 41/135 (30)|Ciclo 1: 61/133 (46)<br>Ciclo 2: 22/133 (17)|NR|NR|NR|
|**Neuropatia**|NR|NR|NR|14/31 (45)|NR|
|**Retenção de líquido**|NR|NR|NR|4/31 (12,9)|NR|
|**Fibrose pulmonar**<br>**reversível**|NR|NR|NR|1/31 (3,2)|NR|
|**Mucosite bucal**|NR|NR|NR|4/31 (12,9)|NR|
|**Hepatopatia**|NR|NR|NR|1/31 (3,2)|NR|
|**Pancitopenia**|NR|NR|NR|1/31 (3,2)|NR|  
<mark>NR: não reportado. Dados foram apresentados em n/N (%).</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Ph+ de Adulto com Mesilato de Imatinibe (DDT) | secao: **3) Descrição dos estudos e seus resultados** -->
1. Silva BN, Felipe MFB, Martins ML, Dias RG, Nascimento TS, Alves KRL. Leucemia Linfoblástica aguda Philadelphia positivo de linhagem B: relato de caso. Hematol Transfus Cell Ther, 2020, 42(S2): 161;  
2. Rafei H, Kantarjian HM, Jabbour EJ. Recent advances in the treatment of acute lymphoblastic leukemia. Leukemia and Lymphoma, 2019, 60(11):2606-2621.  
3. Swerdlow SH, Campo E, Pileri SA, Lee Harris N, Stein H, Siebert R, Advani R, Ghielmini M, Salles GA, Zelenetz AD, Jaffe ES. The 2016 revision of the World Health Organization classification of lymphoid neoplasms. Blood, 2016, 127(20):23752390;  
4. Arber DA, Orazi A, Hasserjian R, Thiele J, Borowitz MJ, Le Beau MM, Bloomfield CD, Cazzola M, Vardiman JW. The 2016 revision to the World Health Organization classification of myeloid neoplasms and acute leukemia. Blood. 2016 May;127(20):2391–2405.  
5. Tekgündüz E, Göker H, Kaynar L, Sari I, Pala Ç, Doǧu MH, et al. Adult Philadelphia Chromosome-Positive Acute Lymphoblastic Leukemia in Daily Practice: A Multicenter Experience. Clin Lymphoma, Myeloma Leuk. 2016, 16(5):269-74;  
6. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008 Apr;336(7650):924–6.  
7. DeAngelo DJ, Jabbour E, Advani A. Recent Advances in Managing Acute Lymphoblastic Leukemia. Am Soc Clin Oncol Educ B. 2020, 40: 330-342;  
8. Cortes JE, Kim D-W, Pinilla-Ibarz J, le Coutre P, Paquette R, Chuah C, et al. A Phase 2 Trial of Ponatinib in Philadelphia Chromosome–Positive Leukemias. N Engl J Med. 2013, 369(19):1783-96;  
9. Fullmer A, O’Brien S, Kantarjian H, Jabbour E. Emerging therapy for the treatment of acute lymphoblastic leukemia. Expert Opinion on Emerging Drugs. 2010, 15(1):1-11;  
10. Wang W, Cortes JE, Lin P, Beaty MW, Ai D, Amin HM, et al. Clinical and prognostic significance of 3q26.2 and other chromosome 3 abnormalities in CML in the era of tyrosine kinase inhibitors. Blood. 2015, 126(14):1699-706;  
11. Ministério da Saúde (Brasil). Instituto Nacional de Câncer (INCA). Leucemia Linfóide Aguda em Adulto. Rev Bras Cancerol. 2002;48(3):309–12.  
12. Ministério da Saúde (Brasil). Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA). Estimativa 2020: Incidência de Câncer no Brasil. Rio de Janeiro: INCA; 2020. 130 p.  
13. Schrappe M. Management of childhood acute lymphoblastic leukemia: The current BFM strategy. Ann Hematol. 2015, 94:S47-S49;  
14. Yanada M, Takeuchi J, Sugiura I, Akiyama H, Usui N, Yagasaki F, et al. High complete remission rate and promising outcome by combination of imatinib and chemotherapy for newly diagnosed BCR-ABL-positive acute lymphoblastic leukemia: A phase II study by the Japan adult leukemia study group. J Clin Oncol. 2006, 24(3):460-6;  
15. Pui CH, Roberts KG, Yang JJ, Mullighan CG. Philadelphia Chromosome–like Acute Lymphoblastic Leukemia. Clinical Lymphoma, Myeloma and Leukemia. 2017; 130(19):2064-2072;  
16. Li C, Mi JQ, Wang J. Advances in Philadelphia chromosome-like acute lymphoblastic leukemia. Journal of Shanghai Jiaotong University (Medical Science). 2020; 12): 1294-1301;  
17. Ministério da Saúde (Brasil). CONITEC- Relatório de Recomendação nº 475/2019 - Reação em cadeia da polimerase – transcriptase reversa (RT-PCR) qualitativa e quantitativa (RT-qPCR) e Hibridização in situ (ISH) para o diagnóstico e monitoramento da Leucemia Mieloide Crônica (LMC) e da Leucemia Linfoblástica Aguda cromossoma Philadelphia positivo  
(LLA Ph+). 2019.  
18. DeFilipp Z, Langston AA, Chen Z, Zhang C, Arellano ML, El Rassi F, et al. Does Post- Transplant Maintenance Therapy With Tyrosine Kinase Inhibitors Improve Outcomes of Patients With High-Risk Philadelphia Chromosome-Positive Leukemia? Clin Lymphoma, Myeloma Leuk. 2016, 16(8):466-471.e1;  
19. Gruber F, Mustjoki S, Porkka K. Impact of tyrosine kinase inhibitors on patient outcomes in Philadelphia chromosomepositive acute lymphoblastic leukaemia. British Journal of Haematology. 2009; 145(5):581-97.  
20. Wieduwilt MJ. How should we treat older adults with Ph+ adult ALL and what novel approaches are being investigated? Best Practice and Research: Clinical Haematology. 2017, 30(3):201-211.  
21. Liu-Dumlao T, Kantarjian H, Thomas DA, O’Brien S, Ravandi F. Philadelphia-positive acute lymphoblastic leukemia: Current treatment options. Curr Oncol Rep. 2012; 14(5):387-394  
22. Thomas X, Dombret H. Treatment of Philadelphia chromosome-positive adult acute lymphoblastic leukemia. Leukemia and Lymphoma. 2008; 49(7):1246-54.  
23. Chalandon Y, Thomas X, Hayette S, Cayuela JM, Abbal C, Huguet F, et al. Randomized study of reduced-intensity chemotherapy combined with imatinib in adults with Ph- positive acute lymphoblastic leukemia. Blood. 2015, 125(24):3711-9; 24. Cook J, Litzow M. Advances in Supportive Care for Acute Lymphoblastic Leukemia.  Current Hematologic Malignancy Reports. 2020; 15(4):276-293;  
25. Samra B, Jabbour E, Ravandi F, Kantarjian H, Short NJ. Evolving therapy of adult acute lymphoblastic leukemia: State-ofthe-art treatment and future directions. Journal of Hematology and Oncology. 2020, 13(1):70;  
26. Fielding AK, Rowe JM, Richards SM, Buck G, Moorman A V., Durrant IJ, et al. Prospective outcome data on 267 unselected adult patients with Philadelphia chromosome-positive acute lymphoblastic leukemia confirms superiority of allogeneic transplantation over chemotherapy in the pre-imatinib era: Results from the International ALL Trial MRC UKALLXII/ECOG2993. Blood. 2009, 113(19):4489-96;  
27. Moorman A V., Harrison CJ, Buck GAN, Richards SM, Secker-Walker LM, Martineau M, et al. Karyotype is an independent prognostic factor in adult acute lymphoblastic leukemia (ALL): Analysis of cytogenetic data from patients treated on the Medical Research Council (MRC) UKALLXII/Eastern Cooperative Oncology Group (ECOG) 2993 trial. Blood. 2007, 109(8):3189-97;  
28. Groffen J, Stephenson JR, Heisterkamp N, de Klein A, Bartram CR, Grosveld G. Philadelphia chromosomal breakpoints are clustered within a limited region, bcr, on chromosome 22. Cell. 1984, 36(1):93-9;  
29. Lee S, Kim DW, Cho B, Kim YJ, Kim YL, Hwang JY, et al. Risk factors for adults with Philadelphia-chromosome-positive acute lymphoblastic leukaemia in remission treated with allogeneic bone marrow transplantation: The potential of real-time quantitative reverse-transcription polymerase chain reaction. Br J Haematol. 2003, 120(1):145-53;  
30. Paul S, Rausch CR, Welch MA, Kantarjian HM, Jabbour EJ. SOHO State of the Art Update and Next Questions: Advances in the Treatment of Adult Acute Lymphoblastic Leukemia. Clinical Lymphoma, Myeloma and Leukemia. 2019.  
31. Ravandi F. Current management of Philadelphia chromosome positive ALL and the role of stem cell transplantation. Hematology. 2017; 19(8):471-479  
32. Park JH. Managing older adults with Ph-negative ALL: What is new? Recent advances in treating older adults with ALL. Best Practice and Research: Clinical Haematology. 2021, 34(1):101258.  
33. Ministério da Saúde (Brasil). Secretaria de Atenção à Saúde. Portaria SAS/MS nº 312, de 27 de março de 2013. Aprova o Protocolo de tratamento da leucemia linfoblástica aguda cromossoma Philadelphia positivo de adulto com mesilato de imatinibe. 2013.  
34. Schaffel R, Simões BP. Leucemia Linfoblástica Aguda Filadélfia positiva. Revista Brasileira de Hematologia e Hemoterapia. 2008, 30(Supl. 1):52-58;  
35. Brasil. Ministério da Saúde. Portaria GM/MS nº 1.831 de julho de 2020;  
36. Brasil. Ministério da Saúde. Portaria Conjunta SAES-SCTIE/MS n<sup>o</sup> 11, de 02 de julho de 2021. Aprova as. Diretrizes diagnósticas e terapêuticas - Tratamento da leucemia linfoblástica aguda cromossoma Philadelphia positivo de crianças e adolescentes com mesilato de imatinibe. 2021;  
37. Hochhaus A, Saussele S, Rosti G, Mahon FX, Janssen JJWM, Hjorth-Hansen H, et al. Chronic myeloid leukaemia: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2017; 28 (suppl 4): iv41–iv51;  
38. Zanichelli MA, Colturato VAR, Simões BP, Sobrinho J, Ikoma MRV. Indicações de Transplante de Células-Tronco Hematopoéticas,(TCTH) em LLA de adultos. Consensos da Sociedade Brasileira de Terapia Celular e Transplante de Medula Óssea (SBTMO), 2015. Disponível em: https://sbtmo.org.br/consensos-sbtmo/. Acesso em 04/10/2021;  
39. Ministerio de Salúd (Chile). Subsecretaría de Salud. Protocolo Clínico Leucemia Linfoblástica Aguda Philadelphia positivo en mayores de 15 años. 2020;  
40. Ohno R. Treatment of adult patients with Philadelphia chromosome-positive acute lymphoblastic leukemia. Current Oncology Reports. 2008, 10(5):379-87;  
41. Rousselot P, Coudé MM, Gokbuget N, Passerini CG, Hayette S, Cayuela JM, et al. Dasatinib and low-intensity chemotherapy in elderly patients with Philadelphia chromosome-positive ALL. Blood. 2016, 128(6):774-82;  
42. Tanguy-Schmidt A, Rousselot P, Chalandon Y, Cayuela JM, Hayette S, Vekemans MC, et al. Long-Term Follow-Up of the Imatinib GRAAPH-2003 Study in Newly Diagnosed Patients with De Novo Philadelphia Chromosome-Positive Acute Lymphoblastic Leukemia: A GRAALL Study. Biol Blood Marrow Transplant. 2013; 19(1):150-5.  
43. Pidala J, Djulbegovic B, Anasetti C, Kharfan-Dabaja MA, Kumar A. Allogeneic Hematopoietic Cell Transplantation for Acute Lymphoblastic Leukemia In First Complete Remission: A Systematic Review and Meta-Analysis. Blood. 2010;116(21):3511–3511.  
44. Wells J, Jain N, Konopleva M. Philadelphia chromosome-like acute lymphoblastic leukemia: Progress in a new cancer subtype. Clin Adv Hematol Oncol. 2017; 15(7):554-561;  
45. Webster JA, Luznik L, Tsai HL, Imus PH, DeZern AE, Pratz KW, et al. Allogeneic transplantation for Ph1 acute lymphoblastic leukemia with posttransplantation cyclophosphamide. Blood Adv. 2020;4(20):5078–88.  
46. Ministério da Saúde (Brasil). Portaria GM/MS n<sup>o</sup> 2.600, de 21 de outubro de 2009. Aprova o Regulamento Técnico do Sistema Nacional de Transplantes.  
47. Ministério da Saúde (Brasil). Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA). REDOME. Registro Nacional de Doadores Voluntários de Medula Óssea. Disponível em: http://redome.inca.gov.br/profissional-de-saude/registro- <u>nacional-de-receptores-de-medula-ossea-rereme/. Acesso em 05/10/2021.</u>  
48. Gleissner B, Gökbuget N, Bartram CR, Janssen B, Rieder H, Janssen JWG, et al. Leading prognostic relevance of the BCRABL translocation in adult acute B-lineage lymphoblastic leukemia: A prospective study of the German Multicenter Trial Group and confirmed polymerase chain reaction analysis. Blood. 2002, 99(5):1536-43 ;  
49. Dombret H, Gabert J, Boiron JM, Rigal-Huguet F, Blaise D, Thomas X, et al. Outcome of treatment in adults with Philadelphia chromosome-positive acute lymphoblastic leukemia - Results of the prospective multicenter LALA-94 trial. Blood. 2002; 100(7):2357-2366;  
50. Kantarjian HM, O’Brien S, Smith TL, Cortes J, Giles FJ, Beran M, et al. Results of treatment with hyper-CVAD, a doseintensive regimen, in adult acute lymphocytic leukemia. J Clin Oncol. 2000; 18(3):547-61;  
51. Rowe JM, Buck G, Burnett AK, Chopra R, Wiernik PH, Richards SM, et al. Induction therapy for adults with acute lymphoblastic leukemia: Results of more than 1500 patients from the international ALL trial: MRC UKALL XII/ECOG E2993. Blood. 2005; 106(12):3760-7;  
52. Hoelzer D, Thiel E, Loffler H, Buchner T, Ganser A, Heil G, et al. Prognostic factors in a multicenter study for treatment of acute lymphoblastic leukemia in adults. Blood. 1988; 71(1):123-31;  
53. Ribera JM, Oriol A, González M, Vidriales B, Brunet S, Esteve J, et al. Concurrent intensive chemotherapy and imatinib before and after stem cell transplantation in newly diagnosed Philadelphia chromosome-positive acute lymphoblastic leukemia. Final results of the CSTIBES02 trial. Haematologica. 2010; 95(1):87-95;  
54. Wassmann B, Pfeifer H, Stadler M, Bornhäuser M, Bug G, Scheuring UJ, et al. Early molecular response to posttransplantation imatinib determines outcome in MRD+ Philadelphia-positive acute lymphoblastic leukemia (Ph + ALL). Blood. 2005; 106(2):458-63;  
55. Oriol A, Vives S, Hernández-Rivas JM, Tormo M, Heras I, Rivas C, et al. Outcome after relapse of acute lymphoblastic leukemia in adult patients included in four consecutive risk-adapted trials by the PETHEMA study group. Haematologica. 2010; 95(4):589-96;  
56. Ministério da Saúde (Brasil). Relatório de Recomendação nº 584/2020 - Dasatinibe para adultos com leucemia linfoblástica aguda cromossomo Philadelphia positivo resistentes / Intolerantes ao mesilato de imatinibe. 2020;  
57. Pfeifer H, Wassmann B, Bethge W, Dengler J, Bornhäuser M, Stadler M, et al. Randomized comparison of prophylactic and minimal residual disease-triggered imatinib after allogeneic stem cell transplantation for BCR-ABL1-positive acute lymphoblastic leukemia. Leukemia. 2013; 27(6):1254-62;  
58. Gökbuget N, Kneba M, Raff T, Trautmann H, Bartram CR, Arnold R, et al. Adult patients with acute lymphoblastic leukemia and molecular failure display a poor prognosis and are candidates for stem cell transplantation and targeted therapies. Blood. 2012; 120(9):1868-76;  
59. Glivec [package insert]. São Paulo, BR: Novartis Biociêcias S/A; 2021. Disponível em https://portal.novartis.com.br/upload/imgconteudos/2258.pdf. Acesso em 26/09/2021  
60. Gravilina OA, Parovichnikova EN, Troitskaya VV, Sokolov AN, Kuzmina LA, Baskhaeva G; Zarubina K, Savchenko VG. De-intensification of the chemotherapy did not affect the outcome of Ph-positive acute lymphocytic leukemia patients in the era of tyrosine kinase inhibitors. Blood. 2016; 128 (22): 2805;  
61. Brissot E, Labopin M, Beckers MM, Socié G, Rambaldi A, Volin L, et al. Tyrosine kinase inhibitors improve long-term outcome of allogeneic hematopoietic stem cell transplantation for adult patients with philadelphia chromosome positive acute lymphoblastic leukemia. Haematologica. 2015; 100(3):392-9;  
62. Snyder DS, Nademanee AP, O’Donnell MR, Parker PM, Stein AS, Margolin K, et al. Long- term follow-up of 23 patients with Philadelphia chromosome-positive acute lymphoblastic leukemia treated with allogeneic bone marrow transplant in first complete remission. Leukemia. 1999; 13(12):2053-8;  
63. Jabbour E, Pui CH, Kantarjian H. Progress and Innovations in the Management of Adult Acute Lymphoblastic Leukemia. JAMA Oncol. 2018; (10):1413-1420;  
64. Lee KH, Lee JH, Choi SJ, Lee JH, Seol M, Lee YS, et al. Clinical effect of imatinib added to intensive combination chemotherapy for newly diagnosed Philadelphia chromosome- positive acute lymphoblastic leukemia. Leukemia. 2005; 19(9):1509-16;  
65. Cortes JE, Kantarjian HM, Pinilla-Ibarz J, le Coutre PD, Paquette R, Chuah C, et al. 5-Year Updates from the Pivotal Phase 2 Ponatinib PACE Trial: Efficacy, Safety and Landmark Analysis in Heavily Pretreated Patients with Chronic-Phase Chronic Myeloid Leukemia. Clin Lymphoma Myeloma Leuk. 2017, 17(Supp 2): S307-S308;  
66. Hamerschlak N, Seber, Luis Fernando da S Bouzas A, Silla L, Ruiz MA. Diretrizes da Sociedade Brasileira de Transplante de Medula Óssea 2012. Sociedade Brasileira de Transplante de Medula Óssea, 2012; 320p.  
67. Ministério da Saúde (Brasil). Protocolos Clínicos e Diretrizes Terapêuticas em Oncologia, 2014;  
68. Chew S, Short NJ, Kantarjian HM, Jabbour E. Management of Philadelphia Chromosome-Positive Acute Lymphoblastic Leukemia. In: In: Faderl S.H., Kantarjian H.M., Estey E. (eds) Acute Leukemias. Hematologic Malignancies. Springer, Cham, 2021;  
69. Yilmaz M, Kantarjian H, Ravandi-Kashani F, Short NJ, Jabbour E. Philadelphia chromosome-positive acute lymphoblastic leukemia in adults: Current treatments and future perspectives. Clin Adv Hematol Oncol. 2018; 16(3):216-223;  
70. Ministério da Saúde (Brasil). Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA). Tópicos em Transplante de Células-Tronco Hematopoéticas. 2012. 194 p.  
71. Maino E, Sancetta R, Viero P, Imbergamo S, Scattolin AM, Vespignani M, et al. Current and future management of Ph/BCR-ABL positive ALL. Expert Review of Anticancer Therapy. 2014, 14(6):723-40;  
72. Yurkiewicz I, Craig J, Muffly L. Hematopoietic Cell Transplantation for Philadelphia Chromosome Negative Adult Acute Lymphoblastic Leukemia in the Modern Era of Immune Therapy. Current Hematologic Malignancy Reports. 2020; 15(3):187193;  
73. Chen H, Liu KY, Xu LP, Liu DH, Chen YH, Zhao XY, et al. Administration of imatinib after allogeneic hematopoietic stem cell transplantation may improve disease-free survival for patients with Philadelphia chromosome-positive acute lymphoblastic leukemia. J Hematol Oncol. 2012; 8;5:29;  
74. Baccarani M, Saglio G, Goldman J, Hochhaus A, Simonsson B, Appelbaum F, et al. Evolving concepts in the management of chronic myeloid leukemia: Recommendations from an expert panel on behalf of the European LeukemiaNet. Blood. 2006; 108(6):1809-20.  
75. Hochhaus A, Baccarani M, Silver RT, Schiffer C, Apperley JF, Cervantes F, et al. European LeukemiaNet 2020 recommendations for treating chronic myeloid leukemia. Leukemia, 34:966-984. 2020.  
76. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: A critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017; 358:j40008;  
77. Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: A revised tool for assessing risk of bias in randomised trials. BMJ. 2019;366:l4898;  
78. Wells G, Shea B, O’Connell D, Peterson J, Welch V, Losos M, et al. The Newcastle- Ottawa Scale (NOS) for assessing the quality if nonrandomized studies in metaanalyses.The Ottawa Hospital, 2012. Disponível em: http//www.ohri.ca/programs/clinical_epidemiology/oxford.asp. Acesso em 05/10/2021;  
79. Whiting PF, Rutjes AWS, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, et al. Quadas-2: A revised tool for the quality assessment of diagnostic accuracy studies. Annals of Internal Medicine. 2011; 155(8):529-36;  
80. Chilkulwar A, Fazal S, De Yao JT, Padhi P, Khan C, Lister J. Induction Therapy with Dasatinib and Prednisone for Patients with Philadelphia Positive ALL. Blood. 2015, 126(23):4907;  
81. Lee HJ, Kantarjian HM, Thomas DA, Faderl S, Koller C, Ferrajoli A, et al. Long-Term Follow-up of Combined Hypercvad (hCVAD) Regimen with Dasatinib (Db) in the Front Line Therapy of Patients (pts) with Philadelphia Chromosome Positive (Ph+) Acute Lymphoblastic Leukemia (ALL). Blood. 2011; 118(21):1512;  
82. Yoon JH, Yhim HY, Kwak JY, Ahn JS, Yang DH, Lee JJ, et al. Minimal residual disease- based effect and long-term outcome of first-line dasatinib combined with chemotherapy for adult Philadelphia chromosomepositive acute lymphoblastic leukemia. Ann Oncol. 2016; 27(6):1081-1088;  
83. Foà R, Vitale A, Vignetti M, Meloni G, Guarini A, De Propris MS, et al. Dasatinib as first- line treatment for adult patients with Philadelphia chromosome-positive acute lymphoblastic leukemia. Blood. 2011; 118(25):6521-8;  
84. Ravandi F, O´Brien S, Garris R, Faderl SH, Thomas DA, Burger JA, et al. Final report of single-center study of chemotherapy plus dasatinib for the initial treatment of patients with philadelphia- chromosome positive acute lymphoblastic leukemia. Blood. 2013, 122(21):3914;  
85. Ravandi F, O’Brien S, Thomas D, Faderl S, Jones D, Garris R, et al. First report of phase 2 study of dasatinib with hyperCVAD for the frontline treatment of patients with Philadelphia chromosome-positive (Ph +) acute lymphoblastic leukemia. Blood. 2010, 116(12):2070-7;  
86. Ravandi F, O’Brien S, Cortes JE, Thomas DM, Garris R, Faderl S, et al. Long-term follow-up of a phase 2 study of chemotherapy plus dasatinib for the initial treatment of patients with Philadelphia chromosome-positive acute lymphoblastic leukemia. Cancer. 2015; 121(23):4158-64;  
87. Ravandi F, Othus M, O’Brien S, Forman SJ, Ha CS, Wong JYC, et al. Multi-center US intergroup study of intensive chemotherapy plus dasatinib followed by allogeneic stem cell transplant in patients with philadelphia chromosome positive acute lymphoblastic leukemia younger than 60. Blood. 2015, 126(23):796-796;  
88. Sasaki K, Jabbour EJ, Ravandi F, Short NJ, Thomas DA, Garcia-Manero G, et al. Hyper- CVAD plus ponatinib versus hyper-CVAD plus dasatinib as frontline therapy for patients with Philadelphia chromosome-positive acute lymphoblastic leukemia: A propensity score analysis. Cancer. 2016; 122(23):3650-3656;  
89. Jabbour E, O’Brien S, Konopleva M, Kantarjian H. New insights into the pathophysiology and therapy of adult acute lymphoblastic leukemia. Cancer. 2015, 121(15):2517-28;  
90. Papayannidis C, De Benedittis C, Soverini S, Iacobucci I, Abbenante MC, Sartor C, et al. Ponatinib Is Well Tolerated and Active In Patients With Relapsed/Refractory Philadelphia Positive Acute Lymphoblastic Leukemia (PH+ ALL) and Advanced Phase Of Chronic Myelogenous Leukemia (CML) Harbouring T315I Mutation: The Bologna Experience. Blood. 2013, 122(21):3911;  
91. Nishiwaki S, Imai K, Mizuta S, Kanamori H, Ohashi K, Fukuda T, et al. Impact of MRD and TKI on allogeneic hematopoietic cell transplantation for Ph+ALL: A study from the adult ALL WG of the JSHCT. Bone Marrow Transplant. 2016, 51(1):43-50;  
92. Gorin NC, Labopin M, Piemontese S, Arcese W, Santarone S, Huang H, et al. T-cell- replete haploidentical transplantation versus autologous stem cell transplantation in adult acute leukemia: A matched pair analysis. Haematologica. 2015;  
93. Hallböök H, Hägglund H, Stockelberg D, Nilsson PG, Karlsson K, Björkholm M, et al. Autologous and allogeneic stem cell transplantation in adult ALL: The Swedish Adult ALL Group experience. Bone Marrow Transplant. 2005, 100(4):558-564; 94. Burke MJ, Trotz B, Luo X, Baker KS, Weisdorf DJ, Wagner JE, et al. Allo-hematopoietic cell transplantation for Ph chromosome-positive ALL: Impact of imatinib on relapse and survival. Bone Marrow Transplant. 2009, 43(2):107-13;  
95. Carpenter PA, Snyder DS, Flowers MED, Sanders JE, Gooley TA, Martin PJ, et al. Prophylactic administration of imatinib after hematopoietic cell transplantation for high-risk Philadelphia chromosome-positive leukemia. Blood. 2007, 109(7):2791-3 96. Kebriaei P, Saliba R, Rondon G, Chiattone A, Luthra R, Anderlini P, et al. Long-term follow-up of allogeneic hematopoietic stem cell transplantation for patients with philadelphia chromosome-positive acute lymphoblastic leukemia: Impact of tyrosine kinase inhibitors on treatment outcomes. Biol Blood Marrow Transplant. 2012, 18(4):584-92;  
97. Rea D, Legros L, Raffoux E, Thomas X, Turlure P, Maury S, et al. High-dose imatinib mesylate combined with vincristine and dexamethasone (DIV regimen) as induction therapy in patients with resistant Philadelphia-positive acute lymphoblastic leukemia and lymphoid blast crisis of chronic myeloid leukemia. Leukemia. 2006, 20(3):400-3;

---

