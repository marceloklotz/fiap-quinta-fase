<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 10, DE 02 DE JULHO DE 2021.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Leucemia Mieloide Crônica de Crianças e Adolescentes.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a leucemia mieloide crônica no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento de crianças e adolescentes com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 617/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 622 – Maio de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão de Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Leucemia Mieloide Crônica de Crianças e Adolescentes.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral de leucemia mieloide crônica de crianças e adolescentes, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt , é de caráter nacional</u> e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da leucemia mieloide crônica de crianças e adolescentes.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 114/SAS/MS, de 10 de fevereiro de 2012, publicada no Diário Oficial da União nº 35 , de 17 de fevereiro de 2012, seção 1, páginas 59 a 61.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: HÉLIO ANGOTTI NETO -->
1  
ANEXO

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **1. INTRODUÇÃO** -->
A Leucemia Mieloide Crônica (LMC) é uma doença mieloproliferativa clonal da célula precursora hematopoética, associada à translocação cromossômica 9;22, que resulta na formação do cromossoma Philadelphia<sup>1,2</sup> . A translocação do cromossoma 9 conduz à fusão entre a porção do gene BCR do cromossoma 22 e o segmento do gene ABL do cromossoma 9. Esse gene quimérico direciona a síntese de uma nova fosfoproteína com elevada atividade inibidora da tirosinoquinase, responsável pela etiopatogenia da LMC.  
A LMC progride tipicamente em três fases: Fase Crônica (FC), Fase de Transformação (FT), também chamada de fase acelerada e Fase Blástica (FB), fase terminal de LMC também chamada de fase aguda ou de crise blástica 1–3.  
As três fases da LMC se diferenciam de acordo com alterações observadas no exame físico, sangue periférico, medula óssea e achados genéticos/moleculares. Em mais de 90% dos casos de LMC pediátrica e de adultos, o transcrito BCR-ABL1 resulta em uma proteína de fusão de 210 kDa<sup>4,5</sup> . O Instituto Nacional de Câncer (INCA) estima que, para cada ano do triênio 2020/2022, sejam diagnosticados no Brasil 5.920 casos novos de leucemia em homens e 4.890 em mulheres. Esses valores correspondem a um risco estimado de 5,67 casos novos a cada 100 mil homens e 4,56 casos novos para cada 100 mil mulheres<sup>6</sup> . Cerca de 15% dos novos casos de leucemia são de LMC. Em crianças, a LMC é de ocorrência rara, representando menos do que 10% de todos os casos e menos de 3% de todas as leucemias na infância, com 0,7 caso/milhão/ano, na faixa etária entre 1 e 14 anos de idade. Essa incidência aumenta para 1,2/milhão/ano na adolescência<sup>7</sup> . A grande maioria dos pacientes com diagnóstico de LMC é assintomática e geralmente eles são diagnosticados durante um exame físico de rotina ou exames de sangue. Os sinais e sintomas comuns da LMC, quando presentes, resultam de anemia e esplenomegalia. Isso inclui fadiga, perda de peso, mal-estar e saciedade fácil. Podem ocorrer também, com menor frequência, febre, infecções recorrentes, hematomas e sangramentos espontâneos.  
O diagnóstico da LMC é geralmente feito na idade entre 11 e 12 anos (variação de 1 a 18 anos), sendo que 10% dos casos se encontram em fase avançada<sup>7</sup> . Mais de 80% dos casos são diagnosticados após os 4 anos de idade, sendo observado que mais de 60% deles são crianças maiores de 10 anos<sup>7</sup> . Existem, entretanto, relatos da ocorrência da doença em lactentes menores de 24 meses de idade<sup>8,9</sup> . A LMC não tem predileção por sexo ou raça e não está associada a síndromes genéticas constitucionais ou a agentes infecciosos<sup>5</sup> . A exposição à radiação ionizante é, até o momento, o único fator de risco conhecido a se relacionar com o desenvolvimento desse tipo de leucemia<sup>5,7</sup> . A proporção de pacientes pediátricos diagnosticados em fase avançada da doença (FT e FB) é maior do que nos adultos<sup>5</sup> . Devido à baixa incidência e às escassas publicações sobre LMC em crianças e adolescentes, a prática assistencial para o controle desse tipo de leucemia nesses grupos etários não está tão bem estabelecida como para os adultos.<sup>1,5,7,10–13</sup> . Após a introdução do inibidor da tirosinoquinase (ITQ) mesilato de imatinibe, há aproximadamente 15 anos, o tratamento da LMC mudou consideravelmente.<sup>14,15</sup> . A indicação de transplante de células-tronco hematopoéticas alogênico (TCTH-AL), único tratamento ainda estabelecido como curativo, é agora postergada pela possibilidade terapêutica com ITQ. Quanto ao surgimento de novos fármacos desta mesma classe, o dasatinibe tem se mostrado bem tolerado pelos adultos<sup>4,5,10,16</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado oferecem à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da leucemia mieloide crônica  
2  
em crianças e adolescentes. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- C92.1 Leucemia mieloide crônica

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **3. DIAGNÓSTICO** -->
O diagnóstico de LMC é dado mediante a anamnese, exame físico, hemograma completo com plaquetometria, mielograma (aspirado de medula óssea) ou biópsia de medula óssea, no caso de aspirado seco devido à fibrose medular moderada ou intensa, e exame de citogenética positivo para o cromossoma Philadelphia (Ph+) em amostra de medula óssea ou exame de biologia molecular positivo (reação em cadeia de polimerase - PCR) em sangue periférico ou medula óssea para o proto-oncogene BCR-ABL<sup>1,12,13,17–19</sup> .  
Mesmo que o exame de BCR-ABL positivo também defina o diagnóstico de LMC, deve-se ter em mente que outras anormalidades cromossômicas podem ser observadas.  
Os achados clínicos e laboratoriais caracterizam as fases evolutivas.  
**3.1. Classificação diagnóstica da Organização Mundial da Saúde (OMS) para leucemia mieloide crônica**  
Atualmente, a classificação das neoplasias mieloides e leucemias agudas da Organização Mundial da Saúde (OMS) é o sistema mais aceito para o diagnóstico e classificação da LMC. De acordo com essa classificação diagnóstica, a caracterização das fases deve apresentar os seguintes achados<sup>20</sup> :

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **3.1.1. Fase Crônica (LMC-FC)** -->
A LMC na Fase Crônica (FC) apresenta-se com leucocitose (12-1.000 x 10⁹/L, com mediana de 100 x 10⁹/L), presença de desvio escalonado acentuado e blastos geralmente abaixo de 2% da leucometria global. A basofilia absoluta está presente e a eosinofilia é comum. A plaquetose é uma característica comum, com valores de plaquetometria que podem variar entre normal e acima de 1.000 x 10<sup>9</sup> /L. A trombocitopenia não é comum. Não há displasia significativa da medula óssea. A basofilia absoluta está presente e a eosinofilia é comum. A monocitose absoluta pode estar presente, porém, com os monócitos abaixo de 3%, exceto nos raros casos associados com BCR-ABL1 p190, em que pode ser confundida com a leucemia mielomonocítica crônica<sup>20</sup> .  
No exame do aspirado medular (mielograma), observa-se medula óssea extremamente hipercelular com relação G/E > 10/1; hiperplasia granulocítica acentuada com discreta hipogranulação em todas as fases do setor granulocítico; eosinofilia e basofilia; hiperplasia megacariocítica não displásica acentuada; presença de < 5% de blastos, sem outras alterações displásicas. Quando procedida, a biópsia de medula óssea mostra celularidade aumentada devido ao padrão de maturação semelhante ao mielograma. Embora os megacariócitos possam estar normais ou discretamente diminuídos em número, entre 40% e 50% dos pacientes apresentam moderada à intensa hiperplasia megacariocítica. Podese observar fibrose medular moderada<sup>20</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **3.1.2. Fase de Transformação (LMC-FT)** -->
A LMC na Fase de Transformação (FT) é diagnosticada por<sup>20</sup> :  
a) Aumento persistente da leucometria (> 10 x 10⁹/L) ou de esplenomegalia não responsiva à terapia;  
b) trombocitose (> 1.000 x 10⁹/L) não responsiva à terapia;  
c) trombocitopenia persistente (< 100 x 10⁹/L) e não relacionada à terapia;  
- d) evolução citogenética clonal no cariótipo ao diagnóstico;  
e) 20% ou mais de basófilos no sangue periférico;  
f) 10% a 19% de blastos no sangue periférico ou na medula óssea;  
g) anormalidades cromossômicas adicionais ao diagnóstico nas células Ph+ (duplo Ph, trissomia 8,  
isocromossomo17q, trissomia 19), cariótipo complexo ou anormalidades do 3q26.2; e  
3  
h) qualquer anormalidade cromossômica nas células Ph+ adquirida durante a terapia.  
Os critérios a) a d) estão mais associados à transição da FC para a FT, enquanto os critérios e) e f) são  
mais indicativos de uma transição entre a FT e a Fase Blástica (FB). Embora modificações e novas sugestões desses  
critérios venham sendo propostas, recomenda-se que sejam considerados como progressão de doença.  
**3.1.3. Fase Blástica (LMC-FB)**  
A LMC-FB é diagnosticada quando<sup>20</sup> :  
a) A quantidade de blastos é igual ou maior do que 20% no sangue periférico ou forem encontradas ≥  
20% das células nucleadas na medula óssea; ou  
b) quando há proliferação blástica extramedular, podendo haver formação tumoral (cloroma).  
Pode ocorrer evolução blástica linfoide, mieloide ou como leucemia de linhagem mista. A investigação  
do transcrito BCR-ABL1 210 está recomendada em todos os casos de leucemia aguda, com a finalidade de diferenciar os casos secundários de uma crise blástica de LMC.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que preencherem todos os critérios a seguir:  
- Idade inferior a 19 anos;  
- diagnóstico confirmado de LMC em qualquer das três fases, por hemograma e mielograma;  
- exame de citogenética (determinação de cariótipo) positivo para o cromossoma Philadelphia (Ph+) em  
amostra de medula óssea ou exame de biologia molecular positivo em sangue periférico para o oncogene BCR-ABL1;  
- exame de beta-hCG negativo na suspeita de gravidez; e  
- estar em primeira linha de tratamento de qualquer das três fases da LMC ou na recaída (hematológica,  
- citogenética ou molecular) após TCTH-AL.  
**NOTA** : Doentes de LMC com 19 ou mais anos de idade devem ser incluídos no protocolo específico estabelecido pelo Ministério da Saúde para o uso do mesilato de imatinibe no tratamento dessa doença nos adultos.  
Para a indicação de TCTH-AL <mark>aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, devem ser observados os critérios estabelecidos no Regulamento Técnico do Sistema Nacional de Transplantes (SNT), devendo todos os potenciais receptores estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS.</mark>

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste PCDT:  
- Pacientes que apresentarem resultado negativo para o cromossoma Philadelphia no exame de  
- citogenética e seu correspondente BCR-ABL1 em exame de biologia molecular;  
- pacientes em fase de amamentação; ou  
- pacientes que apresentem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou tenham contraindicação absoluta ao uso do mesilato de imatinibe ou a procedimento, inclusive o TCTH, preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **6. CASOS ESPECIAIS** -->
- **6.1 Inibidor de tirosinoquinase e gravidez**  
A literatura atual é limitada em humanos, porém pesquisas em animais sugerem que a dose padrão do mesilato de imatinibe não prejudica a fertilidade do adulto masculino ou do adulto feminino que utilizam esse  
4  
medicamento na época da concepção. Contudo, se uma paciente deseja engravidar, é aconselhável planejar a gravidez e buscar uma resposta terapêutica o mais profunda possível, pelo menos, uma Resposta Molecular Maior (RMM)<sup>21,22</sup> .  
De acordo com as recomendações do fabricante, o mesilato de imatinibe não é recomendado durante a gravidez a menos que claramente necessário, pois pode prejudicar o desenvolvimento do feto. Pacientes em uso de ITQ e que engravidam devem ser orientadas a interromper o uso desses medicamentos de imediato, vez que são contraindicados durante a gravidez.  
A terapia deve ser interrompida, com preferência por um período de repouso de três meses antes da concepção e durante a gravidez, e deve ser reiniciada imediatamente após o nascimento.  
No entanto, se houver uma gravidez não planejada ou se a paciente for diagnosticada durante a gravidez, o tratamento da LMC durante a gestação dependerá do momento do tratamento em que a paciente se encontra<sup>21,22</sup> .  
Pacientes recém-diagnosticadas com LMC durante ou juntamente com a gestação muitas vezes poderão submeter-se, no primeiro trimestre da gestação, apenas a sessões de leucocitoafereses para controle da hiperleucocitose.  
A alfa-interferona poderá ser utilizada em gestantes a partir do segundo trimestre da gestação, sempre levando em consideração uma análise dos riscos frente aos benefícios.  
O imatinibe pode ser substituído pela alfainterferona (IFN-α 2B) para mulheres com RMM prolongada; nos casos com resposta molecular inferior, a gravidez deve ser adiada ou o imatinibe deve ser substituído pela IFN-α 2B no primeiro trimestre e novamente administrado no segundo ou terceiro trimestre de gestação<sup>2,21</sup> .  
Crianças nascidas de homens sob tratamento com mesilato de imatinibe nascem saudáveis e, com isso, não há necessidade de aconselhamento ou de suspensão do seu tratamento. Entretanto, para crianças nascidas de mulheres expostas ao mesilato de imatinibe no primeiro trimestre de gravidez, os resultados são menos encorajadores, já que há relatos de anormalidades congênitas, especialmente nos rins, esqueleto, coração, cérebro e intestino<sup>1,12,23</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7 TRATAMENTO** -->
A despeito da disponibilidade de medicamentos que alteraram sobremaneira a evolução da LMC e os resultados do seu tratamento, o TCTH-AL continua a ser uma alternativa terapêutica dessa leucemia, mandatória em alguns casos. Daí, deve-se proceder à tipagem HLA dos pacientes e sua inclusão no REREME/INCA/MS, para uma eventual busca de seus potenciais doadores.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1 Tratamento Medicamentoso** -->
As fases crônica, de transformação e blástica da LMC podem assim se apresentar ao primeiro diagnóstico; como evolutivas de fase anteriormente diagnosticada e tratada (ou seja, de FC para FT, de FC para FB ou de FT para FB); ou como regressivas pelo efeito terapêutico (ou seja, de FB para FT, de FB para FC e de FT para FC).  
No caso de o efeito terapêutico do ITQ ter feito regredir a fase leucêmica para uma anterior (de FB para FT ou FC; de FT para FC), não se modifica a dose de medicamento já em uso.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.1. Mesilato de Imatinibe** -->
Confirmado o diagnóstico, o mesilato de imatinibe é primeira linha de tratamento dos casos de LMC.  
O imatinibe é um derivado da fenilaminopirimidina e um inibidor seletivo da atividade da tirosinoquinase do gene de fusão BCR-ABL1 (oncoproteína), o produto do cromossoma Philadelphia. O mesilato de imatinibe também possui alta atividade de bloqueio da atividade da tirosinoquinase do c-kit (receptor do fator stem-cell - SCF) e do receptor do Fator de Crescimento Derivado das Plaquetas (PDGF). A capacidade do imatinibe de inibir a atividade da tirosinoquinase do BCR-ABL1 está relacionada com sua ocupação no local da quinase na proteína, que bloqueia o acesso ao ATP e previne a fosforilação do substrato, inibindo a proliferação celular dependente de BCRABL<sup>18,24</sup> .  
5  
O imatinibe causa a apoptose ou parada de crescimento em células hematopoéticas que expressam BCRABL1 e é bem absorvido após a administração oral; níveis séricos máximos são alcançados com 2 a 4 horas após a administração. A vida-média de eliminação do imatinibe e seu maior metabólito ativo, o derivado piperazínico N- desmetilado (CGP71588), é, aproximadamente, de 18 e 40 horas, respectivamente. Cerca de 95% do imatinibe é ligado a proteínas, principalmente a albumina e glicoproteina alfa-1-ácida. A maior enzima responsável por seu metabolismo é a CYP3A4<sup>2,12,25</sup> .  
O mesilato de imatinibe mudou substancialmente o tratamento da LMC do adulto, eliminando a indicação de TCTH-AL para muitos pacientes com LMC em fase crônica. Uma vez que a LMC constitui um evento raro na infância, as estratégias terapêuticas adotadas provêm da experiência obtida dos estudos clínicos feitos com adultos. A análise dos dados padronizados pelo _European Leukaemia Net_ (ELN)<sup>2</sup> , colhidos nos últimos anos sobre o uso dos ITQ por adultos, estabeleceu a melhor forma de conduzir o tratamento das três fases na LMC, segundo os exames citogenéticos e a monitoração molecular dos transcritos BCR-ABL1<sup>2,12,25</sup> . Até o momento, o mesilato de imatinibe é a terapêutica de escolha para o início do tratamento da LMC em todas as faixas etárias, e a sua interrupção, fora de estudos clínicos, ainda não pode ser fortemente recomendada<sup>7</sup> . A recaída da LMC traz um mau prognóstico e a necessidade de novos antileucêmicos<sup>7,11,16</sup> .  
A LMC em fase de transformação ou em fase blástica normalmente se apresenta com resistência à terapia, inclusive o mesilato de imatinibe.  
**7.1.1.1. Esquema de administração e doses**  
A hidroxiureia deve ser utilizada somente para reduzir o número de leucócitos, enquanto se aguardam os resultados dos exames que confirmem o diagnóstico de LMC<sup>2,3</sup> .  
O imatinibe só deve ser iniciado com leucometria reduzida previamente com hidroxiureia, pois, pela experiência acumulada com seu uso por pacientes de todas as faixas etárias, a hidroxiureia é muito eficaz para uma redução imediata da hiperleucocitose, devendo-se iniciar o imatinibe com a leucometria em torno de 20.000/mm<sup>3</sup> .  
Após controle hematológico, com o uso da hidroxiureia, por via oral, na dose de 30 a 40mg/kg/dia, com ajustes da dose de acordo com a redução da leucometria global para aproximadamente 20.000/mm<sup>3</sup> , indica-se o mesilato de imatinibe como primeira linha de tratamento da LMC em qualquer de suas fases ao diagnóstico:  
São preconizadas as seguintes posologias do mesilato de imatinibe<sup>23</sup> :  
a) LMC-FC: 260 a 300 mg/m<sup>2</sup> (com arredondamento de dose para a centena mais próxima e dose  
máxima diária de 400 mg), por via oral, 1 vez ao dia e após a maior refeição do dia.  
b) LMC-FT: 300 a 340 mg/m<sup>2</sup> (com arredondamento de dose para a centena mais próxima e dose máxima diária de 600 mg), por via oral, 1 vez ao dia e após a maior refeição do dia.  
c) LMC-FB: 340 mg/m<sup>2</sup> (dose máxima 600 mg) associado ao esquema poliquimioterápico adotado no hospital de acordo com a linhagem celular agudizada (linfoide ou mieloide).  
O comprimido de mesilato de imatinibe pode ser dissolvido em água ou suco de maçã, usando 50 ml do líquido para 100 mg do comprimido ou 200 ml do líquido para 400 mg do comprimido. O resíduo do copo deve ser diluído e ingerido imediatamente. Para crianças com menos de 3 anos, deve-se oferecer, pelo menos, 120 ml de água ou alimento, para evitar irritação esofágica<sup>23</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.2. Tratamento do paciente em fila para o TCTH-AL** -->
O tratamento da criança ou adolescente com LMC-FC com hidroxiureia seguido por IFN-α 2B com ou  
6  
sem citosina arabinosídio é utilizado hoje para crianças e adolescentes que aguardam o TCTH-AL. A IFN-α 2B também é o agente de escolha durante a gestação ou em pacientes de baixo risco que apresentam comorbidades ou façam uso de outros medicamentos que contraindicam o uso do imatinibe<sup>5</sup> .  
A tolerância reduzida e a cinética de resposta mais lenta à IFN-α 2B em comparação com os inibidores de tirosinoquinases reduziram o uso daquele medicamento. No entanto, a terapia com ITQ pode ser limitada por resistência leucêmica, toxicidade (intolerância ou outro evento adverso) ou não adesão ao medicamento, e quando a terapia é suspensa.  
A IFN-α 2B tem uma ampla gama de efeitos terapêuticos que podem reduzir a probabilidade de resistência ou recidiva, especialmente quando usada em combinação com outras terapias da LMC. A alfa-interferona isolada ou em combinação com citarabina ou hidroxiureia pode resultar em resposta clínica e hematológica em 70%-80% dos casos, resposta citogenética completa em 5%-15% e taxa de sobrevida em 5 anos de 57%, com relatos de resposta completa molecular em 5%-10% duradouras, mesmo anos após a suspensão do tratamento<sup>26–28</sup> . Respostas citogenéticas são esperadas com 12 meses de tratamento e, a este ponto, a conduta deve ser modificada se não houver evidência de resposta citogenética. O tratamento permite redução ou estabilidade da mielofibrose associada à LMC, fator limitante para indicação ulterior de TCTH-AL<sup>29–31</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.2.1. Esquema de administração de alfainterferona e citarabina** -->
A IFN-α 2B é usada na dose de 2.500.000 a 5.000.000 UI/m<sup>2</sup> /dia, por via subcutânea (SC), isolada  
ou associada à citarabina 20mg/m<sup>2</sup> /dia, por via SC, durante 10 dias a cada mês (D1 a D10, mensalmente) até que se imponha a suspensão do tratamento, observe-se resistência ou recaída leucêmica ou se proceda ao TCTH-AL da criança ou adolescente<sup>31–33</sup> .

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.3. Benefícios Esperados** -->
O tratamento medicamentoso da LMC tem como objetivo<sup>12,18,24,34–39</sup> :  
- normalizar as contagens das células sanguíneas;  
- destruir as células leucêmicas;  
- normalizar o tamanho do fígado, do baço e de outros locais, como decorrência da destruição dessas  
células;  
- reduzir a indicação ou aguardar o TCTH-AL;  
- aumentar a sobrevida livre de LMC; e  
- aumentar a sobrevida global dos doentes.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.4.1. Resposta terapêutica ao imatinibe** -->
A avaliação da resposta terapêutica ao mesilato de imatinibe deve considerar os seguintes critérios e  
definições<sup>12,18,24,34–39</sup> :  
- RESPOSTA HEMATOLÓGICA COMPLETA (RHC):  
- leucometria < 10 x 10<sup>9</sup> /L;  
- basófilos < 5%;  
- nenhum mielócito, pró-mielócito ou mieloblasto na contagem diferencial;  
- contagem de plaquetas < 450 x 10<sup>9</sup> /L;  
- baço impalpável.  
-  
7  
- RESPOSTA CITOGENÉTICA (RC):  
- completa (RCC): ausência do cromossoma Ph+;  
- parcial (RCP): 1% a 35% de metáfases Ph+;  
- menor (RCm): 36% a 65% de metáfases Ph+;  
- mínima (RCmin): 66% a 95% de metáfases Ph+;  
- sem resposta: > 95% de metáfases Ph+.  
- RESPOSTA MOLECULAR (RMo):  
- completa (RMoC): Transcritos de RNAm do BCR-ABL1 indetectáveis pelo RT-PCR em duas  
amostras de sangue consecutivas de adequada qualidade (sensibilidade > 104);  
- maior (RMoM): Razão BCR-ABL1/ABL ≤ 0,1% na escala internacional.  
- **7.1.4.2. Definições de resposta ótima ao mesilato de imatinibe**  
As definições de resposta ótima são<sup>2,12,25</sup> :  
- Em três meses - Atingir RHC e RCm (Ph+ ≤ 65%);  
- Em seis meses - Atingir pelo menos RCP (Ph+ ≤ 35%);  
- Em 12 meses - Atingir RCC;  
- Em 18 meses - Atingir RMoM (BCR-ABL1/ABL ≤ 0,1% (escala internacional);  
- Em qualquer momento - Manter ou melhorar a RMoM.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.4.3. Definições de Alerta** -->
As definições de alerta são<sup>2,12,25</sup> :  
- Em três meses – Atingir BCR-ABL ˃ 10% em dois exames consecutivos ou Ph+ 36%-95%;  
- Em seis meses – Atingir BCR-ABL 1%-10% em dois exames consecutivos ou Ph+ 1%- 35%;  
- Em 12 meses – Atingir BCR-ABL ˃ 0,1%-1% em dois exames consecutivos;  
- Em qualquer momento – Outras alterações citogenéticas em células Ph- (-7 ou 7q-).

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.4.4. Definições de falha do imatinibe** -->
As definições de falha ao imatinibe são<sup>2,12,25,39</sup> :  
- Em três meses - Não atingir RHC;  
- Em seis meses - Sem resposta citogenética (Ph+ > 95%);  
- Em 12 meses – Não atingir RCP (Ph+ > 35%);  
- Em 18 meses - Não atingir RCC;  
- Em qualquer momento - Perder RHC, perder RCC e aparecimento de alterações cromossômicas  
- complexas/Ph+.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.5 Interações Medicamentosas relacionadas ao imatinibe** -->
O mesilato de imatinibe pode interagir com outros medicamentos<sup>23</sup> . Isto inclui o seguinte:  
8  
- Alguns medicamentos para tratamento de infecções, tais como: cetoconazol, itraconazol,  
- eritromicina ou claritromicina;  
- alguns medicamentos usados para tratamento de epilepsia, tais como: carbamazepina,  
- oxcarbazepina, fenobarbital, fenitoína, fosfenitoína ou primidona;  
- alguns medicamentos para tratamento de colesterol alto, tais como: sinvastatina;  
- alguns medicamentos para tratamento de distúrbios mentais, tais como: benzodiazepínicos ou  
- pimozida;  
- alguns medicamentos para tratamento de pressão sanguínea alta ou distúrbios do coração, tais  
- como: bloqueadores de canais de cálcio ou metoprolol;  
- rifampicina, um medicamento para tratamento da tuberculose;  
- Erva de São João – um produto fitoterápico utilizado para tratamento da depressão e outras  
- condições  
- dexametasona – um medicamento anti-inflamatório;  
- ciclosporina – um medicamento imunossupressor;  
- varfarina – um medicamento utilizado no tratamento de distúrbios da coagulação sanguínea (tais  
como coágulos sanguíneos ou tromboses).

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.6 Eventos adversos do imatinibe** -->
A toxicidade do mesilato de imatinibe é comum, e os efeitos adversos ocorrem com a mesma ou menor frequência, embora menos severamente, em crianças e adolescentes do que nos adultos<sup>12,18,23,24,34–38</sup> .  
Os efeitos adversos mais frequentes são neutropenia e eventos musculoesqueléticos. Mielossupressão ocorre em cerca de 25% dos pacientes com LMC-FC, especialmente nas primeiras 6 semanas, sendo esta taxa mais elevada do que nos adultos. Em termos de citopenias, 27%, 5% e 2,5% desenvolvem, em graus 3 ou 4, neutropenia, trombocitopenia e anemia, respectivamente. Os sintomas gastrointestinais são comuns, principalmente náusea, nas primeiras semanas de tratamento. A biodisponibilidade do imatinibe não é significativamente afetada pela alimentação, a não ser pelo suco de toranja<sup>1,5,7,12,13,17,23</sup> .  
Efeitos adversos frequentes são edema, retenção de fluido, cãibras (em mãos, pés, panturrilhas e coxas), dor óssea (que afeta 10% das crianças), erupções cutâneas (considerando prurido e lesões maculopapulosas), diarreia, letargia e ganho de peso<sup>1,5,7,12,13,17</sup> .  
Efeitos adversos menos frequentes compreendem alteração das provas de função hepática e do metabolismo ósseo, retardo do crescimento e possível cardiotoxicidade (efeito observado em modelo animal, secundário a dano nos miócitos)<sup>1,5,7,12,13,17</sup> .  
Em caso de crianças com esqueleto ainda em formação e em uso prolongado de ITQ, tem-se observado retardo na velocidade do crescimento. Crianças na fase pré-puberal são afetadas mais significativamente, e supõe-se que o eixo hormônio do crescimento-fator de crescimento ligado à insulina-1 (IGF-1) seja afetado. Entretanto, não foram mostradas segurança e eficácia no tratamento com hormônio de crescimento ou IGF-1 recombinante na deficiência daqueles hormônios. Esquemas de tratamento intermitente com o mesilato de imatinibe podem ser uma estratégia para evitar efeitos adversos nos pacientes pediátricos que mantêm remissão molecular sustentada; entretanto, mais estudos são necessários para definir esse procedimento, comparado com o uso contínuo do ITQ.  
A indicação da IFN-α 2B isolada ou associada à citarabina em baixa dose também deve ser bem avaliada pelo potencial da sua toxicidade. Os efeitos adversos mais frequentes na criança são: anorexia, febre, disfunção hepática, síndrome gripal, sintomas neurológicos ou psiquiátricos e alterações dermatológicas. Menos frequentemente, mas com toxicidade mais grave, incluem-se: trombocitopenia, hipotireoidismo, anemia hemolítica e lúpus eritematoso sistêmico.  
9  
A tolerância e a adesão podem ser melhoradas com a gradação da IFN-α 2B, administrada à noite antes de dormir, e o uso de paracetamol para minimizar o estado de síndrome gripal.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.1.7 Critérios de interrupção do tratamento com o mesilato de imatinibe** -->
Embora haja estudos sobre a interrupção do tratamento com o mesilato de imatinibe, recomendando mantê-lo durante dois anos de remissão molecular completa mantida e suspendê-lo após 24 meses sob controle mensal por exame de biologia molecular no sangue periférico<sup>12,18,23,34–39</sup> , ainda não se estabeleceram definitivamente os critérios para a suspensão do medicamento. Assim, não se preconiza neste Protocolo a interrupção do tratamento fora de estudos clínicos.  
A suspensão do tratamento deve-se dar-se nas seguintes condições:  
- Resposta sub-ótima e falha do imatinibe;  
- falta de adesão ao tratamento;  
- a ocorrência de toxicidade de graus 3 e 4, segundo os critérios de graduação do NCI/EUA, indica  
a suspensão temporária do imatinibe, retornando-se a ele, com menor dose do que a anteriormente utilizada. Se esta dose menor for aquém da mínima dose efetiva terapêutica, deve-se suspender definitivamente o medicamento.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **7.2. Transplante de células-tronco hematopéticas alogênico (TCTH-AL)** -->
O TCTH-AL continua sendo o único tratamento curativo da LMC, e as evidências não demonstram o efeito de cura com o uso de ITQ. Entretanto, nem todos os pacientes dispõem de doadores ou critérios para indicação do TCTH-AL, como, por exemplo, ter atingido resposta molecular maior com ITQ.  
Preconiza-se o TCTH-AL para pacientes com LMC-FT, LMC-FB ou com mutação T315I e para aqueles sem resposta terapêutica a ITQ. Eventualmente, pode-se considerá-lo em pacientes com resposta sub-ótima a ITQ, principalmente se se incluírem no grupo de alto risco. Pacientes com LMC-FT ou LMC-FB virgens de tratamento devem submeter-se ao TCTH-AL, se elegíveis, após tratamento inicial com 600 mg/dia de imatinibe. O tratamento com ITQ, se eficaz, não deve ser suspenso nem devem ser reduzidas as doses abaixo das preconizadas, na ausência de efeitos adversos significativos.  
O mais prudente é a avaliação dinâmica do tratamento, redirecionando a conduta de acordo com a  
monitorização laboratorial.  
As indicações de TCTH-AL em pacientes pediátricos com LMC Ph+ são as seguintes:  
- LMC-FT ou LMC-FB ao diagnóstico;  
- progressão para LMC-FT ou LMC-FB (a pesquisa positiva da mutação T315I está associada a  
- mau prognóstico);  
- pacientes com baixa adesão ao tratamento com ITQ;  
- falha terapêutica do ITQ; ou  
- toxicidade grave do ITQ.  
Também devem ser observados os critérios estabelecidos no Regulamento Técnico do SNT para a indicação de TCTH-AL aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, devendo todos os potenciais receptores estar inscritos no REREME/INCA/MS.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **8. MONITORAMENTO** -->
O monitoramento da toxicidade dos tratamentos inclui<sup>1,4,5</sup> :  
- Medida do peso e altura a cada consulta, com observação da velocidade do crescimento.  
10  
- O ganho de peso pode exceder a 10% nos pacientes pediátricos. Neste caso, o paciente deve ser encaminhado ao endocrinologista.  
- Se houver evidência de um padrão anormal do crescimento, a criança deve ser encaminhada para avaliação endocrinológica. O acompanhamento deverá ser iniciado já na idade pré-púbere, com realização de radiografia simples para determinação da idade óssea e, para acompanhar a osteopenia associada ao uso crônico de ITQ, a densitometria óssea. Vale lembrar que, nos adolescentes, a padronização da densitometria óssea é diferente da nos adultos e, portanto, deve ser procedida à densitometria óssea sob protocolo pediátrico. Se houver evidência de um padrão anormal do crescimento, a criança deve ser encaminhada para avaliação endocrinológica para acompanhamento regular e realização de exames complementares.  
- Estadiamento Tanner a cada visita. Análise das gonadotropinas e dos esteroides sexuais a partir da idade pré-púbere. Havendo evidência de atraso puberal, a criança deve ser encaminhada para avaliação e conduta endocrinológica.  
- Dosagem dos hormônios tireoidianos (TSH e T4 livre), 4 a 6 semanas após iniciar o ITQs e mantendo  
monitoramento anual.  
- Aconselhamento sobre reprodução para jovens mulheres em idade fértil.  
- Eletrocardiograma e ecocardiograma, anualmente.  
- Estimular atividades físicas aeróbicas como prevenção do ganho de peso e da osteoporose.  
- Observar o aparecimento de acne (que pode ser acentuada), manchas hipercrômicas ou  
- despigmentação da pele e atuar conforme indicado.  
O monitoramento de casos transplantados deve seguir a conduta adotada pelo hospital transplantador.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **9 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
Pacientes com menos de 19 anos e diagnóstico de LMC devem ser atendidos em hospitais habilitados em oncologia com serviço de hematologia ou de oncologia pediátrica com hematologista e com porte tecnológico suficiente para diagnosticar, tratar e realizar seu monitoramento laboratorial.  
Além da familiaridade que esses hospitais guardam com o tratamento, o ajuste das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento aos pacientes, e muito facilita as ações de controle e avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos); e a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses);  
11  
compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Para a autorização do TCTH-AL aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, todos os potenciais receptores devem estar inscritos no REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do SNT.  
Os receptores transplantados submetidos ao TCTH-AL, originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
**NOTA 1** – O mesilato de imatinibe, de uso preconizado neste PCDT, é, hoje, adquirido pelo Ministério da Saúde e fornecido pelas Secretarias de Saúde para os hospitais e, por esses, aos usuários do Sistema Único de Saúde (SUS). Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Assim, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de outros medicamentos contra a LMC, observando o presente Protocolo, que eles, livremente, padronizem, adquiram e forneçam, cabendo-lhes codificar e registrar conforme o respectivo procedimento, seja o hospital público ou privado, com ou sem fins lucrativos.  
**NOTA 2 –** A aquisição pelo Ministério da Saúde e o fornecimento pelas Secretarias de Saúde não anulam a obrigatoriedade da solicitação, autorização e registros dos respectivos procedimentos em APAC.  
**NOTA 3** – Como o mesilato de imatinibe é comprado pelo Ministério da Saúde e fornecido aos hospitais habilitados em oncologia no SUS pela Assistência Farmacêutica das Secretarias Estaduais de Saúde, não pode, assim, ser autorizada APAC para procedimento de quimioterapia de câncer na infância e adolescência (do Grupo 04, Subgrupo 03 e Forma de Organização 07), quando o seu uso é isolado. Neste caso, o atendimento ambulatorial pode ser ressarcido como consulta especializada (procedimento 03.01.01.007-2 - Consulta Médica em Atenção Especializada).  
**NOTA 4** – Quando o mesilato de imatinibe é associado a outros antineoplásicos do esquema terapêutico da LMC em fase blástica, o seu fornecimento pode ser concomitante à autorização de APAC para os seguintes procedimentos da Tabela do SUS para a quimioterapia de crianças e adolescentes, sob o código da CID-10 correspondente à Leucemia Mieloide Crônica. Os procedimentos se encontram no Sistema de Informações Ambulatoriais do SUS - SIASUS e estão descritos no **Quadro 1** :  
**Quadro 1** - Procedimentos quimioterápicos da LMC em fase de transformação ou em fase blástica  
|- 03.04.07.001-7 Quimioterapia de Câncer na Infância e Adolescência – 1ª linha|
|---|
|- 03.04.07.002-5 Quimioterapia de Câncer na Infância e Adolescência – 2ª linha (primeira recidiva)|
|- 03.04.07.004-1 Quimioterapia de Câncer na Infância e Adolescência – 3ª linha (segunda recidiva)|
|- 03.04.07.003-3 Quimioterapia de Câncer na Infância e Adolescência – 4ª linha (terceira recidiva)|  
**10 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)**  
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos  
12  
adversos relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no respectivo Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **11 REFERÊNCIAS** -->
1. Pallera A, Altman JK, Berman E, Abboud CN, Bhatnagar B, Curtin P, et al. NCCN Guidelines Insights: Chronic Myeloid Leukemia, Version 1.2017. J Natl Compr Cancer Netw. 2016;  
2. Hochhaus A, Baccarani M, Silver RT, Schiffer C, Apperley JF, Cervantes F, et al. European LeukemiaNet 2020 recommendations for treating chronic myeloid leukemia. Leukemia. 2020.  
3. Brasil. Ministério da Saúde. Portaria Conjunta N<sup>o</sup> 04/SAES-SCTIE, de 01 de março de 2021. Diário Oficial da União, Seção 1, No. 44, de 08 de março de 2021. Disponível em https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt.  
4. Aplenc R, Blaney SM, Strauss LC, Balis FM, Shusterman S, Ingle AM, et al. Pediatric phase I trial and pharmacokinetic study of dasatinib: A report from the children’s oncology group phase I consortium. J Clin Oncol. 2011;  
5. Hijiya N, Schultz KR, Metzler M, Millot F, Suttorp M. Pediatric chronic myeloid leukemia is a unique disease that requires a different approach. Blood. 2016.  
6. Ministérios da Saúde (Brasil). Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA). Estimativa 2020: Incidência de Câncer no Brasil. Rio de Janeiro: INCA; 2020. 130 p.  
7. Suttorp M, Millot F. Treatment of pediatric chronic myeloid leukemia in the year 2010: use of tyrosine kinase inhibitors and stem-cell transplantation. Hematology / the Education Program of the American Society of Hematology. American Society of Hematology. Education Program. 2010.  
8. Richardson MW, Grewal SS. Use of imatinib mesylate in a 15-month old with Philadelphia chromosome positive (Ph+) chronic myelogenous leukemia [1]. Pediatric Blood and Cancer. 2008.  
9. Arancibia AM, Bendit I, Epelman S. Complete response to imatinib mesylate treatment in a 12-month-old patient with chronic myeloid leukemia. Pediatric Blood and Cancer. 2008.  
10. Gore L, Kearns PR, de Martino Lee ML, De Souza CA, Bertrand Y, Hijiya N, et al. Dasatinib in pediatric patients with chronic myeloid leukemia in chronic phase: Results from a phase II trial. J Clin Oncol. 2018;  
11. Zwaan CM, Rizzari C, Mechinaud F, Lancaster DL, Lehrnbecher T, Van Der Velden VHJ, et al. Dasatinib in children and adolescents with relapsed or refractory leukemia: Results of the CA180-018 phase I dose-escalation study of the Innovative Therapies for Children With Cancer Consortium. J Clin Oncol. 2013;  
12. de la Fuente J, Baruchel A, Biondi A, de Bont E, Dresse MF, Suttorp M, et al. Managing children with chronic myeloid leukaemia (CML): Recommendations for the management of CML in children and young people up to the age of 18 years. Br J Haematol. 2014;  
13. Millot F, Baruchel A, Guilhot J, Petit A, Leblanc T, Bertrand Y, et al. Imatinib is effective in children with previously untreated chronic myelogenous leukemia in early chronic phase: Results of the french national phase IV trial. J Clin Oncol. 2011;  
14. Muramatsu H, Takahashi Y, Sakaguchi H, Shimada A, Nishio N, Hama A, et al. Excellent outcomes of children with CML treated with imatinib mesylate compared to that in pre-imatinib era. Int J Hematol. 2011;  
15. Ulmer A, Tabea Tauer J, Glauche I, Jung R, Suttorp M. TK inhibitor treatment disrupts growth hormone axis: Clinical observations in children with CML and experimental data from a Juvenile Animal Model. Klin Padiatr. 2013;  
16. Zwaan M, Stork LC, Bertrand Y, Gore L, Hijiya N, De Souza C, et al. A phase II study of dasatinib therapy in children and adolescents with newly diagnosed chronic phase chronic myelogenous leukemia (CML-CP) or Philadelphia chromosome-positive (Ph+) leukemias resistant or intolerant to imatinib. J Clin Oncol. 2012;  
17. Andolina JR, Neudorf SM, Corey SJ. How I treat childhood CML. Blood. 2012. 18. Shah NP. NCCN Guidelines Updates: Discontinuing TKI Therapy in the Treatment of Chronic Myeloid Leukemia. Journal of the National Comprehensive Cancer Network : JNCCN. 2019.  
19. Millot F, Guilhot J, Baruchel A, Petit A, Bertrand Y, Mazingue F, et al. Impact of early molecular response in children with chronic myeloid leukemia treated in the French Glivec phase 4 study. Blood. 2014;  
20. WHO. World Health Organization. WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues WHO Classification of Tumours. WHO; 2017 4th Edition. [Available from: http://publications.iarc.fr/Book-AndReport-Series/Who-Iarc-Classification-Of-Tumours/Who-Classification-Of-Tumou.  
21. Pentheroudakis G, Orecchia R, Hoekstra HJ, Pavlidis N. Cancer, fertility and pregnancy: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2010;  
22. Peccatori FA, Azim JA, Orecchia R, Hoekstra HJ, Pavlidis N, Kesic V, et al. Cancer, pregnancy and fertility: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2013;  
23. Novartis Biociências S.A. Bula de medicamento: Glivec® (mesilato de imatinibe ) Comprimido 100 mg e 400 mg. 2019.  
24. Hochhaus A, Saussele S, Rosti G, Mahon FX, Janssen JJWM, Hjorth-Hansen H, et al. Chronic myeloid 13  
- leukaemia: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2017;  
- 25. Baccarani M, Deininger MW, Rosti G, Hochhaus A, Soverini S, Apperley JF, et al. European LeukemiaNet recommendations for the management of chronic myeloid leukemia: 2013. Blood. 2013.  
26. Allan NC, Shepherd PCA, Richards SM. UK Medical Research Council randomised, multicentre trial of interferon-αn1 for chronic myeloid leukaemia: improved survival irrespective of cytogenetic response. Lancet. 1995;  
27. Allan L, Hays H, Jensen N-H, Le Polain De Waroux B, Bolt M, Donald R, et al. Randomised crossover trial of transdermal fentanyl and sustained release oral morphine for treating chronic non-cancer pain. Br Med J. 2001;322(7295):1154–8.  
28. Giles FJ, Shan J, Chen S, Advani SH, Supandiman I, Aziz Z, et al. A prospective randomized study of alpha-2b interferon plus hydroxyurea or cytarabine for patients with early chronic phase chronic myelogenous leukemia: The international oncology study group CML1 study. Leuk Lymphoma. 2000;  
29. Talpaz M, Hehlmann R, Quintás-Cardama A, Mercer J, Cortes J. Re-emergence of interferon-α in the treatment of chronic myeloid leukemia. Leukemia. 2013;27(4):803–12.  
30. Schmidt E, Lister J, Neumann M, Wiecek W, Fu S, Vataire AL, et al. Cabozantinib Versus Standard-of-Care Comparators in the Treatment of Advanced/Metastatic Renal Cell Carcinoma in Treatment-naïve Patients: a Systematic Review and Network Meta-Analysis. Target Oncol. 2018;  
31. Ministérios da Saúde (Brasil). Protocolos Clínicos e Diretrizes Terapêuticas em Oncologia. 2014; Available from: www.saude.gov.br  
32. Lipton JH, Khoroshko N, Golenkov A, Abdulkadyrov K, Nair K, Raghunadharao D, et al. Phase II, randomized, multicenter, comparative study of peginterferon-α-2a (40 kD) (Pegasys®) versus interferon α-2a (Roferon®-A) in patients with treatment-naïve, chronic-phase chronic myelogenous leukemia. Leuk Lymphoma. 2007;  
33. M. M, F. M, M. D, A. H, A. R, R.T. S, et al. Pegylated recombinant interferon alpha-2b vs recombinant interferon alpha-2b for the initial treatment of chronic-phase chronic myelogenous leukemia: A phase III study. Leukemia. 2004.  
34. Atallah E, Schiffer CA. Discontinuation of tyrosine kinase inhibitors in chronic myeloid leukemia: When and for whom? Haematologica. 2020.  
35. Richter J, Lübking A, Söderlund S, Lotfi K, Markevärn B, Själander A, et al. Molecular status 36 months after TKI discontinuation in CML is highly predictive for subsequent loss of MMR-final report from AFTER-SKI. Leukemia [Internet]. 2021;10–2. Available from: http://www.ncbi.nlm.nih.gov/pubmed/33589755  
36. Carofiglio F, Lopalco A, Lopedota A, Cutrignelli A, Nicolotti O, Denora N, et al. Bcr-abl tyrosine kinase inhibitors in the treatment of pediatric cml. International Journal of Molecular Sciences. 2020.  
37. Kantarjian H, Shah NP, Hochhaus A, Cortes J, Shah S, Ayala M, et al. Dasatinib versus Imatinib in Newly Diagnosed Chronic-Phase Chronic Myeloid Leukemia. N Engl J Med. 2010;  
38. Colson P, Rolain J-M, Lagier J-C, Brouqui P, Raoult D. Chloroquine and hydroxychloroquine as available weapons to fight COVID-19. International journal of antimicrobial agents. Netherlands; 2020. p. 105932.  
39. Brasil. Ministério da Saúde. Secretaria de Atenção à. Secretaria de Atenção à Saúde. Portarias SAS 431/2001, 347/2008 e 649/2008 – Diretrizes Terapêuticas da Leucemia Mielóide Crônica do Adulto. Brasília Ministério da Saúde. 2011;  
40. Belgaumi AF, Al-Shehri A, Ayas M, Al-Mahr M, Al-Seraihy A, Al-Ahmari A, et al. Clinical characteristics and treatment outcome of pediatric patients with chronic myeloid leukemia. Haematologica. 2010;  
41. Champagne MA, Capdeville R, Krailo M, Qu W, Peng B, Rosamilia M, et al. Imatinib mesylate (STI571) for treatment of children with Philadelphia chromosome-positive leukemia: Results from a Children’s Oncology Group phase 1 study. Blood. 2004;  
42. Champagne MA, Fu CH, Chang M, Chen H, Gerbing RB, Alonzo TA, et al. Higher dose imatinib for children with de novo chronic phase chronic myelogenous leukemia: A report from the Children’s Oncology Group. Pediatr Blood Cancer. 2011;  
43. Giona F, Putti MC, Micalizzi C, Menna G, Moleti ML, Santoro N, et al. Long-term results of high-dose imatinib in children and adolescents with chronic myeloid leukaemia in chronic phase: the Italian experience. Br J Haematol. 2015;  
44. Hamidieh AA, Ansari S, Darbandi B, Soroush A, Arjmandi Rafsanjani K, Alimoghaddam K, et al. The treatment of children suffering from chronic myelogenous leukemia: A comparison of the result of treatment with imatinib mesylate and allogeneic hematopoietic stem cell transplantation. Pediatr Transplant. 2013;  
45. Lakshmaiah KC, Bhise R, Purohit S, Abraham LJ, Lokanatha D, Suresh TM, et al. Chronic myeloid leukemia in children and adolescents: Results of treatment with imatinib mesylate. Leuk Lymphoma. 2012;  
46. Millot F, Guilhot J, Nelken B, Leblanc T, De Bont ES, Békassy AN, et al. Imatinib mesylate is effective in children with chronic myelogenous leukemia in late chronic and advanced phase and in relapse after stem cell transplantation. Leukemia. 2006;  
47. Cortes JE, Jones D, O’Brien S, Jabbour E, Ravandi F, Koller C, et al. Results of dasatinib therapy in patients with early chronic-phase chronic myeloid leukemia. J Clin Oncol. 2010;  
48. Jabbour E, Kantarjian HM, Saglio G, Steegmann JL, Shah NP, Boqué C, et al. Early response with dasatinib or imatinib in chronic myeloid leukemia: 3-year follow-up from a randomized phase 3 trial (DASISION). Blood. 2014;  
14

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: MESILATO DE IMATINIBE -->
Eu, ____________________________________________ (nome do [a] paciente ou de seu responsável legal), declaro ter sido informado (a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de mesilato de imatinibe, indicado para o tratamento da Leucemia Mielóde Crônica com presença do cromossoma Philadelphia.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico __________________________ (nome do médico que prescreve). Assim, declaro que fui claramente informado (a) de que o medicamento que passo a tomar/fornecer ao meu (minha) filho(a) pode contribuir para trazer as seguintes melhoras:  
- recuperação das contagens celulares;  
- destruição das células malignas; e  
- diminuição do tamanho do fígado, do baço e outros locais, em decorrência da destruição dessas células.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso do medicamento:  
- risco de uso no imatinibe na gravidez: caso o (a) doente engravide, deve avisar imediatamente o médico; - interação do imatinibe com outros medicamentos, por exemplo, anticonvulsivantes, antidepressivos, alguns antitérmicos, remédios contra fungos e outros, o que exige a leitura detalhada das recomendações descritas pelo fabricante;  
- efeitos adversos mais comumente relatados: diminuição da produção dos glóbulos brancos, glóbulos vermelhos e plaquetas, problemas no fígado e ossos, dores articulares e musculares, náusea, vômitos, alteração do metabolismo ósseo, certa diminuição da velocidade do crescimento, problemas respiratórios e cardíacos;  
- contraindicação em casos de hipersensibilidade (alergia) ao remédio; e  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim/meu (minha) filho (a), comprometendo-me a devolvê-lo ao hospital para que este o devolva à Assistência Farmacêutica da Secretaria Estadual de Saúde, caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que eu/meu (minha) filho (a) continuarei/continuará a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as secretárias de Saúde a fazerem uso de informações relativas ao tratamento do (a) meu (minha) filho (a) ou meu próprio, desde que assegurado o anonimato.  
- (   ) Sim (   ) Não  
Local: Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal:  
Assinatura do responsável legal ou do paciente  
Médico responsável: CRM: UF: Assinatura e carimbo do médico Data:  
Observação: O medicamento deste termo é adquirido pelo Ministério da Saúde e fornecido a hospitais habilitados em oncologia no SUS pelas respectivas Secretarias Estaduais de Saúde.  
15

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **APÊNDICE 1** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **METODOLOGIA** -->
Com a presença de quatro membros do Grupo Elaborador, sendo dois especialistas e dois metodologistas, e dois representantes do Comitê Gestor, uma reunião presencial para definição do escopo do PCDT foi conduzida. Todos os componentes do Grupo Elaborador preencheram o formulário de declaração de conflitos de interesse, que foram enviados ao Ministério da Saúde como parte dos resultados.  
Inicialmente, a macroestrutura da PCDT foi estabelecida com base na Portaria SAS/MS n° 375, de 10 de novembro de 2009, que define o roteiro para elaboração de PCDT, definindo-se as seções do documento.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de identificar  as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas do tema da presente PCDT foram, então, orientados a elencar questões de pesquisa,   estruturadas de acordo com o acrônimo PICO, para cada nova tecnologia não incorporada no SUS ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica. Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO esta representada na **Figura A** .  
**Figura A –** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
aa *Populagdo ou condic¢ao clinica<br>+Intervengdo, no caso de estudos experimentais<br>+Fatorde exposi¢ao, em caso de estudos<br>observacionais<br>—————————— *Testediagnéstica indice, nos casos de estudos de acuracia<br>*Controle, de acordo com tratamento/niveis de<br>exposigo do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br><!-- End of picture text -->  
Ao final dessa dinâmica, duas questões de pesquisa foram definidas para o presente PCDT ( **Quadro A.1** ).  
**Quadro A.1 –** Questões de pesquisa elencadas pelo Grupo Elaborador do PCDT.  
16  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|Qual<br>a<br>segurança<br>e<br>eficácia<br>do<br>dasatinibe<br>em<br>casos<br>de<br>resistência/refratariedade do imatinibe (fases crônica, de transformação e<br>aguda)?|Tratamento|
|**2**|Qual a evidência do imatinibe na cura da LMC de crianças e adolescentes?|Tratamento|
|**3**|Qual a eficácia do dasatinibe como primeira linha de tratamento na LMC<br>de crianças e adolescentes?|Tratamento|
|**4**|Quais são os critérios de resposta terapêutica ao imatinibe?|Monitoramento|  
LMC: leucemia mieloide crônica.  
As perguntas de pesquisa serviram para dar subsídio à redação do texto. O medicamento dasatinibe, apesar de avaliado nesse Protocolo, não foi considerado para incorporação para essa população, pois, como estabelecido em bula, não possui indicação para crianças e adolescentes. O mesmo medicamento foi apreciado pelo Plenário da Conitec, em sua 91ª reunião ordinária, no dia 07 de outubro de 2020, para população adulta com LLA Ph+ e teve parecer preliminar desfavorável à incorporação. Para os pacientes adultos com LMC, o tratamento com dasatinibe é fornecido, seguindo ao preconizado na Portaria Conjunta SAES-SCTIE/MS nº 04, de 01 de março de 2021.  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínicas estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após a atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação para ser discutida entre o painel de especialistas na ocasião do consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida no PCDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada.  
Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clínico-demográficas e desfechos de eficácia/segurança. Adicionalmente, para complementar o corpo das evidências, foram identificados ensaios clínicos randomizados adicionais que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na  
17  
estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiuse um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, estas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa também foram mantidos para posterior discussão e inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias em formato pdf, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados do PCDT.  
O detalhamento desse processo de seleção foi descrito por questão de pesquisa correspondente.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, isso significaria que não havia comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Dessa forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess Systematic Reviews 2_ (AMSTAR-2) (Shea Bj _et al._ , 2017); os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane (Higgins Jpt e Green S, 2011); os estudos observacionais pela ferramenta Newcastle-Ottawa (Wells G, 2013), e; os estudos de acurácia diagnóstica pelo _Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2) (Whiting Pf _et al._ , 2011). Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas _a priori_ como detentoras de alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **1 Questões de Pesquisa** -->
**Questão de Pesquisa 1:** Qual a segurança e eficácia do dasatinibe em casos deresistência/refratariedade do imatinibe (fases crônica, de transformação e aguda)?

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **1) Estratégia de busca  MEDLINE via Pubmed:** -->
(((("Leukemia, Myeloid, Chronic-Phase"[Mesh] OR "Leukemia, Myelogenous, Chronic, BCR-ABL Positive"[Mesh] OR Leukemia, Chronic Myelogenous OR Leukemia, Chronic Myeloid OR Leukemia, Myelocytic, Chronic OR Chronic Myelocytic Leukemia OR Chronic Myelogenous Leukemia OR Chronic Myeloid Leukemia)) AND ("Adolescent"[Mesh] OR "Child"[Mesh] OR "Child, Preschool"[Mesh] OR children)) AND ("Dasatinib"[Mesh] OR Sprycel OR BMS  
18  
354825)) AND (imatinib resistance OR imatinib-resistant OR resistant to imatinib OR imatinib-refractory OR imatinib refractory OR refractory to imatinib OR imatinib refractoriness)  
Total: 51 referências Data do acesso: 15/01/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **EMBASE:** -->
('chronic myeloid leukemia'/exp/mj AND [embase]/lim) OR (chronic AND myelogenous AND leukemia AND [embase]/lim) OR (leukaemia, AND myelogenous, AND chronic, AND 'bcr abl' AND positive AND [embase]/lim) AND  
'dasatinib'/exp/mj AND [embase]/lim OR sprycel AND [embase]/lim AND  
('imatinib refractory' AND [embase]/lim) OR (imatinib AND refractory AND [embase]/lim) OR (imatinib AND resistance AND [embase]/lim) OR ('imatinib resistant' AND [embase]/lim) OR (imatinib AND refractoriness AND [embase]/lim)  
AND  
('child'/exp/mj AND [embase]/lim) OR ('adolescent'/exp/mj AND [embase]/lim) OR ('children'/exp OR children AND [embase]/lim) OR (pediatric AND  
[embase]/lim) Total: 21 referências  
Data do acesso: 09/02/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **2) Seleção das evidências** -->
A busca das evidências nas bases MEDLINE (via PubMed) e Embase resultou em 72 referências (51 MEDLINE e 21 no EMBASE). Destas, três foram excluídas por estarem duplicadas. Sessenta e nove referências foram triadas por meio da leitura de título e resumos, das quais 12 tiveram seus textos completos avaliados para confirmação da elegibilidade e oito publicações foram excluídas: sete por avaliarem população adulta e um resumo de congresso que menciona apenas o protocolo de estudo em andamento, sem resultados. Por fim, quatro publicações (referentes a dois estudos) envolvendo população pediátrica com LMC foram incluídos

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **3) Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela A** . As características dos pacientes encontramse descritas na **Tabela B** . As **Tabelas C** e **D** apresentam dados de eficácia e segurança, respectivamente.  
19  
**Tabela A –** Características dos estudos  
|**Autor, ano**|**Desenho de estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Risco de viés**|
|---|---|---|---|---|---|
|**Aplenc et al.**<br>**2011**<sup>4</sup>|Série de casos (estudo fase I de<br>escalonamento de dose),<br>multicêntrico (21 centros)|Estudo fase I e de<br>farmacocinética do<br>dasatinibe.|Pacientes pediátricos entre 1 e 21<br>anos, com leucemias Ph+ resistentes<br>ao imatinibe (mielóide=9 e<br>linfoblástica=2) e pacientes com<br>tumores sólidos.<br>Dados aqui apresentados somente para<br>o estrato LMC.|Dose inicial de 50mg/m<sup>2</sup><br>2x/dia com escalonamento<br>para 65, 85 e 110mg/m<sup>2</sup>. Os<br>cursos tiveram duração de 28<br>dias, sem interrupção entre os<br>cursos.|Alto risco: série de<br>casos, população não<br>representativa.|
|**Zwaan et al.**<br>**2013**<sup>11</sup>|Série de casos (estudo fase I de<br>escalonamento<br>de<br>dose),<br>multicêntrico (6 centros)|Estabelecer a dose para<br>estudo de fase II, avaliar<br>tolerabilidade, eficácia e<br>segurança do dasatinibe.|Pacientes pediátricos com LMC,<br>LMA, LLA Ph+ ou LLA Ph-<br>previamente expostas/refratárias ao<br>imatinibe. Dados aqui apresentados<br>somente para o estrato LMC em fase<br>crônica.|Dasatinibe 1x/ dia com dose<br>inicial de 60mg/m2 e<br>aumento de dose baseada na<br>tolerabilidade e resposta<br>individual até 120mg/m<sup>2</sup>.<br>Em 6 pacientes a dose inicial<br>foi de 80mg/m<sup>2</sup>1x/dia.|Alto risco: série de<br>casos, população não<br>representativa.|  
LMC: Leucemia mieloide crônica; Leucemia mieloide aguda; Ph+: cromossomo Philadelphia positivo; Ph-: cromossomo Philadelphia negativo.  
20  
**Tabela B –** Características dos pacientes  
|**Autor, ano**|**N intervenção**|**Idade**|**% sexo**<br>**masculino**|**Tempo de**<br>**tratamento**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(N)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|
|**Aplenc et al. 2011**<sup>4</sup>|9 com LMC|10 (2,7-17,6) -<br>somente para a coorte<br>LMC + LLA|Toda a coorte:<br>20/39 (51)|Número de<br>ciclos: 3 (1-20)|NR|NR|NR|
|**Zwaan et al. 2013**<sup>11</sup>|17 no estrato LMC<br>crônica|10|67|24,1 meses<br>(2,3-50,6)|6/17 (35)|Transplante de medula<br>óssea|24 meses|  
N: número de pacientes; n: número de pacientes que apresentaram o evento; NR: não reportado. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).  
**Tabela C –** Desfechos de eficácia  
|**Autor, ano**|**Mortalidade ouSobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração da resposta**|
|---|---|---|---|---|
|**Aplenc et al. 2011**|NR|RCC: 3/8 (38)<br>RCP: 2/8 (25)<br>RHC e RCP: 1/8 (13)<br>RCMin: 1/8 (13)<br>RCMe: 1/8 (13)|NR|NR|
|**Zwaan et al. 2013**<sup>11</sup>|Mortalidade: 3/17 (18)<br>Mortalidade relacionada ao tratamento: 0<br>SG: mediana não alcançada SLP: mediana<br>não alcançada Taxa estimada de SG: 88%<br>Taxa estimada de SLP:|RHC cumulativa: 16/17 (94)<br>RCM: 15/17 (88)<br>RCC: 14/17 (82)<br>RMM: 8/17 (47)|Até RCM: 12 semanas em 8<br>pacientes e 24 semanas em<br>14 pacientes|Duração da RHC: mediana<br>não alcançada<br>Duração da RCM: mediana<br>não alcançada|  
N: número de pacientes; n: número de pacientes que apresentaram o evento; NR: não reportado; SG: Sobrevida Global; SLP: Sobrevida Livre de Progressão; RCC: Resposta Citogenética Completa; RCP: Resposta citogenética parcial; RHC: Resposta hematológica completa; RCMin: Resposta Citogenética Mínima; RCMe: Resposta Citogenética Menor; RMM: Resposta Molecular Maior. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).  
46  
**Tabela D –** Eventos adversos  
|**Eventos adversos (Grau 3-4)**|**Autor, ano de publicação**<br>**Aplenc et al. 2011**<sup>4</sup><br>**Zwaan et al. 2013**<sup>11</sup>|
|---|---|
|**Anemia**|NR<br>0|
|**Artralgia**|NR<br>0|
|**Cefaleia**|NR<br>1/17 (5,8)|
|**Diarreia**|2/9 (22)<br>0|
|**Dor nas extremidades**|NR<br>0|
|**Edema periférico**|NR<br>0|
|**Epistaxe**|NR<br>0|
|**Fadiga**|NR<br>0|
|**Febre**|NR<br>0|
|**Hipocalemia**|1/9 (11)<br>NR|
|**Lombalgia**|NR<br>0|
|**Mal-estar**|NR<br>0|
|**Nasofaringite**|NR<br>0|
|**Náusea**|NR<br>0|
|**Neutropenia**|NR<br>4/17 (23,5)|
|**Proteinúria**|1/9 (11)<br>NR|
|**Prurido**|NR<br>0|
|**Rash**|1/9 (11)<br>0|
|**Sangramento gastrointestinal**|1/9 (11)<br>NR|
|**Trombocitopenia**|NR<br>2/17 (11,7)|
|**Ulceração de boca**|NR<br>0|
|**Urticária**|NR<br>0|
|**Vômito**|NR<br>0|  
NR: não reportado. Dados foram apresentados em n/N (%).  
**Questão de Pesquisa 2:** Qual a evidência do imatinibe na cura da LMC de crianças e adolescentes?  
**1) Estratégia de busca MEDLINE via Pubmed:**  
((("Leukemia, Myeloid, Chronic-Phase"[Mesh] OR "Leukemia, Myelogenous, Chronic, BCR-ABL Positive"[Mesh] OR Leukemia, Chronic Myelogenous OR Leukemia, Chronic Myeloid OR Leukemia, Myelocytic, Chronic OR Chronic Myelocytic Leukemia OR Chronic Myelogenous Leukemia OR Chronic Myeloid Leukemia)) AND ("Imatinib Mesylate"[Mesh] OR Imatinib OR Mesylate, Imatinib OR Imatinib Methanesulfonate OR STI-571 OR Gleevec OR Glivec)) Filters: Adolescent: 13-18 years; Child: birth-18 years; Infant: birth-23 months; Infant: 1-23 months; Preschool Child: 2-5 years; Child: 6-12 years  
Total: 684 referências  
Data do acesso: 19/02/2017  
47

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **EMBASE:** -->
('chronic myeloid leukemia'/exp/mj AND [embase]/lim) OR (chronic AND myelogenous AND leukemia AND [embase]/lim) OR (leukaemia, AND myelogenous, AND chronic, AND 'bcr abl' AND positive AND [embase]/lim) AND  
'imatinib'/mj AND [embase]/lim OR 'gleevac'/exp OR gleevac OR 'gleevec'/exp OR gleevec OR 'glivec'/exp OR glivec OR 'glivic'/exp OR glivic OR 'imatinib'/exp OR imatinib AND mesilate OR 'imatinib'/exp OR imatinib AND ('mesylate'/exp OR mesylate) AND [embase]/lim  
AND  
('child'/exp/mj AND [embase]/lim) OR ('adolescent'/exp/mj AND [embase]/lim) OR ('children'/exp OR children AND [embase]/lim) OR (pediatric AND [embase]/lim)

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: AND -->
([cochrane review]/lim OR [systematic review]/lim OR [meta-analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim)  
Total: 34 referências  
Data do acesso: 09/02/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **2) Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 718 referências (684 no MEDLINE e 34 no Embase). Destas, 18 foram excluídas por estarem duplicadas. Setecentas referências foram triadas por meio da leitura de título e resumos, das quais 13 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dois estudos potencialmente elegíveis foram excluídos por serem relato de caso e série de casos com apenas 6 participantes, que pouco contribuiriam com informações para responder à questão proposta. Dois estudos apresentaram critérios de resposta terapêutica aos ITKs e foram considerados potencialmente elegíveis para a questão 5, que objetivou avaliar critérios de resposta ao Imatinibe. Por fim, nove estudos foram incluídos (Champagne _et al._ , 2004; Millot _et al._ , 2006; Belgaumi e Al-Shehri, 2010; Champagne _et al._ , 2011; Millot _et al._ , 2011; Muramatsu _et al._ , 2011; Lakshmaiah _et al._ , 2012; Hamidieh _et al._ , 2013; Giona _et al._ , 2015).

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **3) Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela E** . As características dos pacientes encontram-se descritas na **Tabela F** . As **Tabelas G** e **H** apresentam dados de eficácia e segurança, respectivamente  
48  
**Tabela E –** Características dos estudos  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do**<br>**controle**|<br>**Risco de viés**|
|---|---|---|---|---|---|---|
|**Belgaumi et al.**<br>**2010**<sup>40</sup>|Série de casos<br>retrospectiva|Avaliar a eficácia do<br>imatinibe em população<br>pediátrica com LMC.|População pediátrica com LMC|Imatinibe 300 mg/m<sup>2</sup>1x/dia|NA|Alto risco: série de casos<br>para avaliar eficácia.|
|**Champagne et**<br>**al.2004**<sup>41</sup>|Estudo<br>experimental<br>(estudo fase I de<br>escalonamento<br>de dose),<br>multicêntrico (23<br>centros)|Determinar a dose ótima de<br>imatinibe, toxidade e<br>farmacocinética em população<br>pediátrica com LMC.|População pediátrica (<22<br>anos) com leucemias Ph+<br>(LMC, LLA e LMA)|Imatinibe 260-570 mg/m<sup>2</sup><br>1x/dia, curso de 28 dias|NA|Alto: série de casos para<br>avaliar eficácia.|
|**Champagne et**<br>**al.2011**<sup>42</sup>|Estudo<br>experimental<br>(estudo fase II),<br>prospectivo,<br>multicêntrico (37<br>centros)|Avaliar a eficácia do imatinibe<br>em população pediátrica recém<br>diagnosticada com LMC.|População pediátrica recém<br>diagnosticada com LMC|Imatinibe 260-570 mg/m<sup>2</sup><br>1x/dia, cada curso de 28 dias,<br>por no máximo 13 cursos|NA|Alto risco: série de casos<br>para avaliar eficácia.|
|**Giona et**<br>**al.**<br>**2015**<sup>43</sup>|Série de casos,<br>prospectivo<br>multicêntrico (9<br>centros)|Avaliar a eficácia do<br>imatinibe em alta dose e<br>desfechos de longo prazo em<br>pacientes pediátricos com<br>LMC.|Pacientes pediátricos (< 18<br>anos) com LMC não tratados<br>ou resistentes ao IFN|Imatinibe 340 260-570 mg/m<sup>2</sup><br>1x/dia ou Imatinibe 340 mg/m<sup>2</sup><br>por 3 semanas mensalmente<br>(terapia intermitente) em<br>pacientes com IS BCR-ABL1<br>≤0,01% e sem RMM.|NA|Alto risco: série de casos<br>para avaliar eficácia.|  
49  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da Intervenção**|**Detalhes do**<br>**controle**|<br>**Risco de viés**|
|---|---|---|---|---|---|---|
|**Hamidieh et**<br>**al. 2013**<sup>44</sup>|Estudo<br>observacional<br>comparativo<br>retrospectivo|Comparar a eficácia comparativa<br>do tratamento com imatinibe e<br>transplante de medula óssea em<br>população pediátrica.|População pediátrica com LMC|Dose inicial de imatinibe 260<br>mg/m<sup>2</sup>1x/dia, aumentada para<br>320 mg/m<sup>2</sup>1x/dia se os<br>pacientes não apresentassem<br>RHC após três meses ou RCM<br>após 12 meses (metafase<br><35%) ou se houvesse recidiva<br>dentro de 3 meses<br>após RHM.|Transplante<br>alogênico<br>de medula<br>óssea|Alto risco: estudo não<br>randomizado, sem análise<br>ajustada para as<br>diferenças nas<br>características de base dos<br>grupos.|
|**Lakshmaiah et**<br>**al.**<br>**2012**<sup>45</sup>|Série de casos<br>retrospectiva|Avaliar a eficácia do imatinibe<br>em população pediátrica com<br>LMC|Adultos e adolescentes (< 20<br>anos) com LMC|Imatinibe 260 mg/m<sup>2</sup>, dose até<br>400 mg/m<sup>2</sup>|NA|Alto risco: série de casos<br>para avaliar eficácia|
|**Millot et**<br>**al.**<br>**2006**<sup>46</sup>|Estudo<br>experimental<br>(estudo fase II),<br>multicêntrico (23<br>centros)|Avaliar a eficácia do imatinibe<br>em população pediátrica com<br>LMC|População pediátrica com<br>LMC, na fase crônica,<br>avançada e em recorrência no<br>pós- transplante. Apenas os<br>dados referentes à fase crônica<br>foram<br>relatados|Imatinibe 260-340 mg/m<sup>2</sup><br>1x/dia. Mediana de dose<br>inicial: 292 mg/m<sup>2</sup>(mínimo:<br>241; máximo: 333)|NA|Alto risco: série de casos<br>para avaliar eficácia|
||Estudo||||||
|**Millot et al.**<br>**2011**<sup>13</sup>|experimental<br>prospectivo, fase<br>IV, multicêntrico<br>(16 centros)|Avaliar a eficácia do imatinibe<br>em população pediátrica recém-<br>diagnosticada com LMC|População pediátrica recém-<br>diagnosticada com LMC|Imatinibe 260 mg/m<sup>2</sup>, dose até<br>400 mg/m<sup>2</sup>|NA|Alto risco: estudo não<br>comparativo para avaliar<br>eficácia|
|**Muramatsu et**<br>**al.2011**<sup>14</sup>|Estudo<br>observacional<br>comparativo<br>retrospectivo|Comparar a eficácia do<br>tratamento com imatinibe_vs._<br>transplante de medula óssea<br>alogênico em população<br>pediátrica com LMC|População pediátrica com LMC|Imatinibe dose mediana de<br>329 mg/m<sup>2</sup>/dia (mínimo 263;<br>máximo 364)|NA|Alto risco: estudo não<br>randomizado, sem análise<br>ajustada para as diferenças<br>nas<br>características de base<br>dos grupos|  
LMC: Leucemia Mieloide Crônica; NA: Não se aplica; Ph+: cromossomo Philadelphia positivo; LLA: Leucemia Linfoblástica Aguda; LMA: Leucemia Mieloide Aguda; RMM: Resposta Molecular Maior; RHC: Resposta Hematológica Completa; RCM: Resposta Citogenética Maior; RHM: Resposta Hematológica Maior.  
50  
**Tabela F –** Características dos pacientes  
|**Autor, ano**|**Intervenção**<br>**(N)**|**Controle**<br>**(N)**|**Idade**<br>**intervenção**|**Idade**<br>**controle**|**Sexo**<br>**masculino**<br>**intervenção**<br>**n/N (%)**|**Sexo**<br>**masculino**<br>**controle**<br>**n/N (%)**|**Tempo de**<br>**tratamento**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Belgaumi et al.**<br>**2010**<sup>40</sup>|12|NA|NR<br>(2,5-12,5)|NA|7/12 (58)|NA|NR|7/12 (58,3)|Transplante<br>medula óssea (6);<br>eventos<br>adversos (1)|NR|
|**Champagne et al.**<br>**2004**<sup>41</sup>|<br>31, sendo<br>14 com<br>LMC|NA|14 anos<br>(3-20) -<br>toda a<br>coorte|NA|23/31 (747)<br>- toda a<br>coorte|NA|NR|NR|NA|NR|
|**Champagne et al.**<br>**2011**<sup>42</sup>|<br>51|NA|11,8 anos<br>(2,3-19,1)|NA|22/51 (43)|NA|NR|22/51 (43)|Hepatite auto-<br>imune (1);<br>transplante<br>medula óssea<br>(21)|3,8 anos (NR)|
|**Giona et al.**<br>**2015**<sup>43</sup>|47|NA|11,8 anos<br>(2,8-17,9)|NA|28/47 (59,6)|NA|48 meses (1–<br>126);<br>> 24 meses<br>em 75% dos<br>pacientes|16/47 (34)|Transplante de<br>medula óssea<br>(8); falha de<br>tratamento (7)|52 meses (3-<br>146)|
|**Hamidieh et al.**<br>**2013**<sup>44</sup>|19|14|12,85 anos<br>(8,5-169)|9,5 (2-<br>16)|6/8 (75)|6/13 (46)|NR|NR|NA|2 anos (1,2-<br>8,4)|
|**Lakshmaiah et al.**<br>**2012**<sup>45</sup>|43|NA|15 anos<br>(7-20)|NA|24/43 (56)|NA|NR|0|NA|43 meses (16-<br>104)|  
51  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade**<br>**intervenção**|**Idade**<br>**controle**|**Sexo**<br>**masculino**<br>**intervenção**<br>**n/N (%)**|**Sexo**<br>**masculino**<br>**controle**<br>**n/N (%)**|**Tempo de**<br>**tratamento**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação**<br>**(n pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Millot et al. 2006**<sup>46</sup>|22|NA|NR (6-17,5)|NA|11/22 (50)|NA|NR|Toda a coorte:<br>17/30 (56,6); 11<br>descontinuados<br>em fase crônica,<br>mas sem<br>especificação<br>das causas|NR|34 meses (25-<br>38)|
|**Millot et al. 2011**<sup>13</sup>|44|NA|11,5 anos<br>(10 meses-<br>17 anos)|NA|28/44 (64)|NA|27 meses (2-<br>77)|14/44 (32)|Evento adverso<br>(2);<br>refratariedade<br>citogenética (1);<br>perda de resposta<br>(3); não alcançou<br>RMC (5); outros<br>(3)|31 meses (11-<br>64)|
|**Muramatsu et al.**<br>**2011**<sup>14</sup>|<br>12|16|9 anos<br>(2-14)|9 anos<br>(3-14)|6/12 (50)|10/16<br>(62,5)|NR|Grupo<br>imatinibe: 1/12<br>(8,3)|Transplante de<br>medula após<br>tratamento com<br>imatinibe|NR|  
**N: número de pacientes; n: número de pacientes que apresentaram o evento; NA: Não se aplica; NR: Não reportado; RMC: Resposta Molecular Completa. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo).**  
**Tabela G –** Desfechos de eficácia  
|**Autor, ano**<br>**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Descontinuação por**<br>**resposta durável**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|  
52  
|**Belgaumi**<br>**et al.**<br>**2010**<sup>40</sup>|NA|SLP em 4 anos: 65,6%<br>Mortalidade: 0|RHM em 3 meses: 11/12<br>(91,6)<br>RCC em 12 meses: 7/9 (78)<br>RMM: 5/6 (83)<br>Recorrência: 1/12 (8)|RMM: 7,5 meses<br>(3-17,3)|NR|NR|
|---|---|---|---|---|---|---|
|**Champagn**<br>**e et al.**<br>**2004**<sup>41</sup>|NA|Probabilidade de manutenção da RHC em<br>2 anos: 92% (IC 95% 57-99)<br>Mortalidade: 1/14 (7)|RHC: 14/14 (100)<br>Recorrência RHC: 1/14 (7)<br>RCC: 10/12 (83)<br>RCC com curso adicional:<br>8/12 (62)<br>Recorrência da RCC: 4/12 (33)<br>Progressão da doença após<br>25 e 45 cursos: 0|RHC: NR (7-30<br>dias)<br>RCC: 3 meses (2-<br>6)|NR|NR|
|**Champagn**<br>**e et al.**<br>**2011**<sup>42</sup>|NA|Mortalidade: 5/51 (9,8)<br>SLP em 3 anos: 72% ±6,4<br>SG em 3 anos: 92% ± 3,9|RHC ao final do curso 1: 9/48<br>(19)<br>RHC ao final do curso 2:<br>39/49 (80)<br>RCC ao final do curso 3: 12/51<br>(23,5)<br>RCP ao final do curso 3: 10/51<br>(19,6)<br>RCMin ao final do curso 3:<br>8/51 (16)<br>RCC em 5,6 meses: 33/46 (72)<br>RCM: 40/46 (87)<br>RMM: 6/22 (27)|NR|NR|NR|
||||Recorrência: 13/51 (25,5)||||  
53  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Descontinuação por**<br>**resposta durável**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|---|
|**Giona et**<br>**al. 2015**<sup>43</sup>|NA|Mortalidade: 0<br>SLP em 10 anos: 60%|RHC: 31/31 (100)<br>RCC: 33/36 (91,5)<br>RCP: 2/36 (5,5)<br>RCMin: 1/36 (2,7)<br>RCC em 3 meses: 8/20(29,6)<br>RCC em 6 meses: 26/28 (93)<br>RCC em 12 meses: 24/25 (96)<br>RMM em sangue periférico:<br>22/28 (78,6)<br>RMM em medula óssea:<br>31/34 (91)<br>IS BCR-ABL1 ≤0,01% em<br>sangue periférico em 15<br>meses (2,3-41): 17/28 (71) IS<br>BCR-ABL1 ≤0,01% em<br>medula óssea em 13 meses<br>(2,6-43,4): 19/34 (56)|RHC: 34 dias<br>(4 dias-9 meses)<br>RCC: 6,3 meses<br>(2,5-23,5)|NR|NR|
||Intervenç<br>ão|SLP em 2 anos: 82%<br>SG: 87%|RHC: 11/19 (58)<br>RCC: 7/19 (37)<br>Recorrência hematológica:|NR|NR|NR|
|**Hamidieh**|||8/19 (42,1)||||
|**et al. 2013**<sup>44</sup>|||RHC: 9/14 (64,3)|Tempo até<br>|||
||Controle|SLP em 2 anos: 59%<br>SG: 84%|<br>RCC: 7/9 (78)<br>Recorrência hematológica:<br>5/14 (36)|recorrência<br>hematológica:<br>média 265 dias<br>(NR)|NR|NR|
||P|SLP: p=0,88<br>SG: p=0,714|RHC: p=NR<br>RCC: p=NR<br>Recorrência hematológica:|NA|NA|NA|  
54  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Descontinuação por**<br>**resposta durável**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|---|
||||p=0,524||||
|**Lakshmaia**<br>**h et al.**<br>**2012**<sup>45</sup>|NA|SLP: 100%<br>Mortalidade: 0<br>SG: 100%<br>SLE em 43 meses: 92,8%|RHC: 43/43 (100)<br>RCC em qualquer momento:<br>25/43 (58,1)<br>RHM em qualquer momento:<br>18/43 (42)<br>Perda da RHC: 5/43 (11,6)<br>Perda da RHM: 1/18 (5,5)|RHC: 2 meses<br>(NR)<br>RCC: 15 (5-60)<br>RMM: 21 (NR)|NR|NR|
|**Millot et**<br>**al. 2006**<sup>46</sup>|NA|SG em 12 meses: 95% (IC 95% 87-100)|RHC: 8/10 (80), sendo que<br>adicionais 12 pacientes já<br>estavam em RHC na ocasião<br>da introdução do imatinibe<br>RHP: 1/22 (4,5)<br>RCC ou FISH negativo em<br>mediana de 5 meses (1-15):<br>12/20 (60), sendo que adicionais<br>2 já estavam em RCC na ocasião<br>da introdução do imatinibe<br>Perda da RCC: 1/22 (4,5)|RHM: 4 semanas<br>(3-6)|6/22 (27,3)<br>Recorrência hematológica<br>12 meses pós<br>descontinuação: 1/6 (16,6)|RHC: 26 meses (1-<br>37)|
|**Millot et**<br>**al.2014**<br>19|NA|Mortalidade: 1/44 (2)<br>SLP em 36 meses: 98% (IC 95% 85-100)<br>Incidência cumulativa de RMM em 36<br>meses: 60% (IC95% 46-75)<br>Incidência cumulativa de RHC em 36<br>meses: 98% (IC95% 90-100)<br>Incidência cumulativa de RCM em 36|RHC: 43/44 (98)<br>RHC em 3 meses: 38/44 (86)<br>Recorrência RHC: 1/44 (3)<br>RCC em 6 meses: 20/44 (46)<br>RCC em 12 meses: 27/44 (61)<br>RCC>12 meses [mediana 18<br>meses|RCC: 6 meses (6-<br>20)|NR|NR|  
55  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**|**Tempo até**<br>**resposta**|**Descontinuação por**<br>**resposta durável**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|---|
|||meses: 84% (IC95% 71-93)<br>Incidência cumulativa de RCC em 36<br>meses: 83% (IC95% 69-92)<br>Incidência cumulativa de redução de 4- log<br>de CMR4 em 36 meses: 35% (IC95% 21-<br>55)<br>Incidência cumulativa de transcripto<br>indetectável em 36 meses:|(16-20) ]: 6/17 (35)<br>RCC durante todo<br>seguimento: 36/44 (77)<br>RMC: 25/44 (57)<br>Proporção de pacientes em<br>tratamento ao final do<br>seguimento: 31/44 (70)||||
|35)||17%<br>(IC95%<br>8-|||||
|**Muramatsu**<br>**et al. 2011**<sup>14</sup>|Intervenç|ão<br>SLE: 100%<br>Mortalidade: 0|Progressão da doença: 0<br>RCC em 12 meses: 54,6%<br>(IC95% 29,3-83,3)<br>RMM em 12 meses: 0%<br>RCC em 36 meses: 90,9%<br>(IC95% 66,7-99,5)<br>RMM em 36 meses: 36,4%<br>(IC95% 15,5-70,3)|NR|NR|NR|
||Controle|SLE em 5 anos: 87,5 (IC95% 58,6-<br>96,7)<br>SLE em 15 anos: 64,2% (IC95%<br>33,6-<br>83,5)<br>Mortalidade: 8/16|Progressão da doença:<br>6/16(37,5)|NR|NR|NR|
||P|NR|Progressão da doença:<br>p=0,006|NA|NA|NA|  
n: número de pacientes que apresentaram o evento; N: número de pacientes; SLP: Sobrevida Livre de Progressão; RHM: Resposta Hematológica Maior; RCC: Resposta Citogenética Completa; RMM: Resposta Molecular Maior; NR: não reportado; RHC: Resposta Hematológica Completa; IC: Intervalo de Confiança; SG: Sobrevida Global; RCP: Resposta Citogenética Parcial; RCMin: Resposta Citogenética Mínima; SLE: Sobrevida Livre de Eventos. Quando não especificado, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).  
56  
**Tabela H –** Eventos adversos  
|||||**Autor,**|**ano depu**|**blicação**||||
|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**<br>**(Grau 3-4)**|**Belgau**<br>**mi**<br>**2010**<sup>40</sup>|**Champa**<br>**gne**<br>**2004***<sup>41</sup>|**Champa**<br>**gne**<br>**2011**<sup>42</sup>|**Giona**<br>**2015**<sup>**#**</sup><br>43|**Hamidi**<br>**eh**<br>**2013**<sup>**$**44</sup>|**Lakshmaia**<br>**h et al.**<br>**2012**<sup>45</sup>|**Millot**<br>**et al.**<br>**2006**<sup>46</sup>|**Millot**<br>**et al.**<br>**2011**<sup>13</sup>|**Muramat**<br>**su et al.**<br>**2011**<sup>14</sup>|
|**Alteração**<br>**plaquetas**|5/12<br>(41,<br>6)|NR|NR|NR|NR|NR|NR|NR|NR|
|**Alteração renal**|0|NR|NR|NR|NR|NR|NR|NR|NR|
|**Anemia**|3/12 (25)|NR|7/50 (14)|1/47<br>(2,1)|NR|0|0|1/44<br>(2,5)|1/28 (3,5)|
|**Artralgia**|2/12<br>(16,<br>6)|NR|NR|9/47<br>(19,<br>1)|1/19<br>(5,2)|0|NR|1/44<br>(2,5)|NR|
|**Cefaleia**|NR|NR|1/50 (2)|NR|NR|NR|0|0|NR|
|**Deficiência**<br>**d**<br>**e crescimento**|NR|NR|NR|0|NR|NR|NR|NR|NR|
|**Diarreia**|NR|NR|1/50 (2)|1/47<br>(2,1)|NR|0|0|0|NR|
|**Disfunção**<br>**endócrina**|NR|NR|NR|0|NR|NR|NR|NR|NR|
|**Dor abdominal**|NR|NR|3/50 (6)|2/47<br>(4,2)|NR|NR|NR|NR|NR|
|**Dor**<br>**em**<br>**extremidades**|<br>1/12<br>(8,3)|NR|NR|NR|NR|NR|NR|NR|NR|
|**Edema**|NR|NR|NR|NR|NR|0|0|0|NR|
|**Elevação**<br>**bilirrubina**|0|NR|NR|NR|NR|NR|NR|NR|NR|
|**Elevação**<br>**d**<br>**e transaminases**|0|NR|NR|NR|NR|NR|1/22<br>(3)|NR|NR|
|**Fadiga **|NR|NR|NR|NR|NR|NR|NR|0|NR|
|**Hepatite viral**|NR|NR|NR|1/47<br>(2,1)|NR|NR|NR|NR|NR|
|**Hipofosfatemia**|NR|NR|1/50(2)|NR|NR|0|NR|NR|NR|
|**Hipoplasia**<br>**medular**|NR|NR|NR|0|NR|NR|NR|NR|NR|
|**Infecção**|NR|NR|NR|NR|NR|NR|1/22<br>(3)|NR|NR|
|**Mialgia**|NR|NR|6/50 (12)|NR|1/19<br>(5,2)|0|NR|2/44 (5)|NR|
|**Náusea**|NR|NR|NR|NR|NR|0|0|0|NR|
|**Neutropenia**|3/12 (25)|NR|16/50 (32)|7/47<br>(14,<br>9)|NR|2/43 (4,6)|5/22<br>(17)|12/44<br>(27)|1/28 (3,5)|
|**Osteoalgia**|NR|NR|NR|NR|1/19<br>(5,2)||NR|NR|NR|
|**Pancitopenia**<br>**Pancreatite**|NR<br>NR|NR<br>NR|NR<br>NR|NR<br>0|NR<br>NR|NR<br>NR|NR<br>NR|NR<br>NR|1/28(3,5)<br>NR|  
57  
|**Parestesia**|NR|NR|NR|NR|NR|NR|NR|1/44<br>(2,5)|NR|
|---|---|---|---|---|---|---|---|---|---|
|**Rash**|NR|NR|NR|1/47<br>(2,1)|1/19<br>(5,2)|0|0|NR|NR|
|**Redução**<br>**d**<br>**a densidade**<br>**mineral**<br>**óssea**|NR|NR|NR|0|NR|NR|NR|NR|NR|
|**Retenção hídrica**|NR|NR|NR|1/47<br>(2,1)|NR|NR|NR|NR|NR|
|**Trombocitopeni**<br>**a**|NR|NR|8/50 (16)|7/47<br>(14,<br>9)|NR|3/43 (6,9)|3/22<br>(10)|2/44 (5)|2/28 (7)|
|**Vômito**|NR|NR|1/50 (2)|2/47<br>(4,2)|NR|0|0|0|NR|  
NR: não reportado. Dados foram apresentados em n/N (%). *Reportou redução de dose em 7/14 (50%)  
pacientes com LMC após evento adverso.<sup>#</sup> Eventos Grau ≥2 no primeiro ano de tratamento;<sup>$</sup> Grau não descrito.  
58  
**Questão de Pesquisa 3:** Qual a eficácia do dasatinibe como primeira linha de tratamento na LMC de crianças e adolescentes?  
**1) Estratégia de busca MEDLINE via Pubmed:** (((("Leukemia, Myeloid, Chronic-Phase"[Mesh] OR "Leukemia, Myelogenous, Chronic, BCR-ABL Positive"[Mesh] OR Leukemia, Chronic Myelogenous OR Leukemia, Chronic Myeloid OR Leukemia, Myelocytic, Chronic OR Chronic Myelocytic Leukemia OR Chronic Myelogenous Leukemia OR Chronic Myeloid Leukemia)) AND ("Adolescent"[Mesh] OR "Child"[Mesh] OR "Child, Preschool"[Mesh] OR children)) AND ("Dasatinib"[Mesh] OR Sprycel OR BMS 354825)) Total: 114 referências  
Data do acesso: 15/01/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **EMBASE:** -->
('chronic myeloid leukemia'/exp/mj AND [embase]/lim) OR (chronic AND myelogenous AND leukemia AND [embase]/lim) OR (leukaemia, AND myelogenous, AND chronic, AND 'bcr abl' AND positive AND [embase]/lim)  
AND  
'dasatinib'/mj AND [embase]/lim OR 'sprycel'/mj AND [embase]/lim AND  
AND  
('child'/exp/mj AND [embase]/lim) OR ('adolescent'/exp/mj AND [embase]/lim) OR  
('children'/exp OR children AND [embase]/lim) OR (pediatric AND [embase]/lim) Total: 50 referências  
Data do acesso: 09/02/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **2) Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 164 referencias (114 no MEDLINE e 50 no Embase). Destas, 21 foram excluídas por estarem duplicadas. Cento e quarenta e três referências foram triadas por meio da leitura de título e resumos, das quais seis tiveram seus textos completos avaliados para confirmação da elegibilidade. Três estudos foram excluídos. Um deles, conduzido em população pediátrica e publicado como resumo de congresso, mencionou apenas que o estudo está em andamento, mas a publicação principal desses dados não foi encontrada. Outro estudo, publicado em 2012, apresentou resultados agregados para a classe de medicamento, incluindo participantes recebendo imatinibe, nilotinibe e dasatinibe, sem estratificar os resultados por tipo de molécula. Uma revisão sistemática foi adicionalmente excluída por não atender ao objetivo da questão de pesquisa. Por fim, devido à ausência de estudos que respondessem diretamente à questão de pesquisa, foram incluídos três estudos conduzidos em população adulta.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **3) Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela I** As características dos pacientes encontram-se descritas na **Tabela J** . As **Tabelas K** e **L** apresentam dados de eficácia e segurança, respectivamente.  
59  
**Tabela I –** Características dos estudos  
|**Autor, ano**|**Desenho**<br>**de estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Cortes**<br>**et al.**<br>**2010**<sup>47</sup>|ECR|Avaliar duas doses de<br>dasatinibe como tratamento de<br>primeira linha da LMC|Pacientes adultos com LMC<br>diagnosticados em até 6<br>meses, sem tratamento prévio<br>ou máximo hidroxiureia ou 1<br>mês de imatinibe (31% dos 62<br>pacientes incluídos)|Dasatinibe 100mg<br>1x/dia VO|Dasatinibe<br>50mg 2x/dia<br>VO|Alto risco: não há informações<br>sobre o método de randomização<br>e sigilo da alocação. Análises não<br>realizadas de acordo com o<br>princípio ITT (exceto as<br>relacionadas aos eventos<br>adversos).|
|**Jabbour et al.**<br>**2013**<sup>48</sup>|ECR fase III.<br>Seguimento de<br>3 anos do<br>estudo<br>DASISION|Avaliar o valor preditivo das<br>respostas precoces para os<br>resultados dos pacientes<br>tratados no ensaio DASISION<br>com um seguimento mínimo<br>de 3|Adultos com LMC Ph+|Dasatinibe 100mg<br>1x/dia VO|Imatinibe,<br>400mg<br>1x/dia VO|Alto risco: não há informações<br>sobre o método de randomização<br>e sigilo da alocação.|
|**Kantarjian**<br>**et**<br>**al.**<br>**2010**<sup>37</sup>|ECR fase III,<br>multicêntrico<br>(108<br>centros em<br>26 países)|Avaliar RCC em pacientes que<br>receberam dasatinibe_vs_<br>imatinibe como primeira linha de<br>tratamento|<br>Adultos com LMC Ph +|Dasatinibe 100mg<br>1x/dia VO|Imatinibe,<br>400mg<br>1x/dia VO|Alto risco, pois não há<br>informações sobre o método de<br>randomização e sigilo da<br>alocação.|  
ECR: Ensaio Clínico Randomizado; LMC: Leucemia Mieloide Crônica; VO: via oral; Ph+: cromossomo Philadelphia positivo; ITT: intenção de tratar; RCC: Resposta Citogenética Completa.  
*Estudos conduzidos em população adulta.  
60  
**Tabela J –** Características dos pacientes  
|**Autor, ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**intervenção**|**Idade**<br>**controle**|**Sexo**<br>**masculino**<br>**intervenção**|**Sexo**<br>**masculino**<br>**controle**|**Tempo de**<br>**tratamento**|**Descontinuação**<br>**n/N (%)**|**Razão para**<br>**descontinuação (n**<br>**pacientes)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Cortes et**<br>**al. 2010**<sup>47</sup>|31|31|46 (18-70)|47 (22-<br>76)|NR|NR|NR|12/62 (3,22)|Razões pessoais: 1/62 (1,6).<br>Observados por menos de 3<br>meses (sem descrição da<br>causa): 11/62 (18)|24 meses<br>(1-39)|
|**Jabbour et**<br>**al. 2013**<sup>47</sup>|Na data das<br>análises,<br>183/259<br>(71%)<br>estavam<br>recebendo<br>dasa.<br>Para a análise<br>de SG, 90%<br>dos pacientes<br>foram<br>considerados.|Na data das<br>análises,<br>179/260 (69%)<br>estavam<br>recebendo<br>ima.<br>Para a análise<br>de SG, 90%<br>dos pacientes<br>foram<br>considerados.|46 (18-84)|49 (18-<br>78)|144/259<br>(56)|163/260<br>(63)|Dasa: 36,8<br>meses (0,3-<br>49,7)<br>Ima: 36,8<br>meses (0,3-<br>49,7)|Dasa:<br>75/258 (29)<br>Ima:<br>79/258 (31)|Progressão: Dasa<br>17/258(7); Ima 18/258 (7).<br>Falha de tratamento: Dasa<br>8/258(3); Ima 12/258 (5);<br>EA: Dasa 27/258(10); Ima<br>16/258 (6); EA não<br>relacionados: Dasa<br>6/258(2); Ima 2/258(<1);<br>Outros: Dasa 13/258(5);<br>Ima 30/258 (12)|Dasa: 39,9<br>meses (0,2-<br>49,8)<br>Ima: 37<br>meses (0,7-<br>49,7)|
|**Kantarjian**<br>**et al. 2010**<sup>37</sup>|259|260|46 (18-84)|49 (18-<br>78)|144/259<br>(56)|163/260(63)|Dasa: 14<br>meses (0,3-<br>24,1)<br>Ima: 14,3<br>meses (0,3-<br>25,8)|Dasa: 40/258<br>(15,5)<br>Ima: 48/258<br>(18,6)|EA: Dasa 13/258 (5); Ima<br>11/258 (4,3).<br>Hematologicos: Dasa 4/258<br>(1,6); Ima 3/258 (1,2). Não-<br>hematológicos: Dasa 9/258<br>(3,5); Ima: 8/258 (3,1).<br>Retirou consentimento:<br>Dasa 2/258 (1); Ima 3/258<br>(1). Outros: Dasa 12/258<br>(5); Ima 18/258 (9)|Mínimo de<br>12 meses|  
N: número de pacientes; n: número de pacientes que apresentaram o evento; NR: Não reportado; Dasa: Dasatinibe; Ima: Imatinibe; SG: Sobrevida Global; EA: Evento Adverso. Quando não especificados, dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N(%).  
*Estudos conduzidos em população adulta.  
61  
**Tabela K –** Desfechos de eficácia  
|**Autor, ano**|**Grupo**|**Mortalidade ou**<br>**Sobrevida**|**Resposta n/N (%)**||**Tempo até resposta**|**Duração da**<br>**resposta**|
|---|---|---|---|---|---|---|
|**Cortes et al.**<br>**2010**<sup>47</sup>|Dasa<br>1x/dia<br>Dasa<br>2x/dia|**Dados para ambos os**<br>**grupos:**<br>SLE em 24 meses 55/62 (88)|RCC: 100%<br>RCC em 6 meses: 92%<br>RMM: 79%<br>RCC em 12 meses: 100%<br>RMM em 12 meses: 71%<br>RCC em 18 meses: 94%<br>RMM em 18 meses: 82%<br>RCC: 96%<br>RCC em 6 meses: 96%<br>RMM: 85%<br>RCC em 12 meses: 95%<br>RMM em 12 meses: 71%<br>RCC em 18 meses: 94%|**Dados para ambos**<br>**os grupos:**<br>RHC: 45/45 (100)<br>RCC a qualquer momento:<br>49/50 (98)<br>RMM: 41/50 (82)<br>RMC: 5/50 (10)<br>RMM em 12 meses: 71%<br>RMM em 18 meses: 79%<br>RCC em 3 meses: 41/50 (82)<br>RCC em 6 meses: 46/50 (94)|**Dados para ambos**<br>**os grupos:**<br>RCC: 3 meses (3-9)<br>RMC: 6 meses (3-18)|**Dados para**<br>**ambos os grupos:**<br>Até RHC:<br>4 semanas (0,3-24)|
||<br>P<br>A|N|RMM em 18 meses: 76%<br>RCC: p=1,0<br>RCC em 6 meses:<br>NR RMM: p=0,72<br>RCC em 12 meses: p=1,0<br>RMM em 12 meses:<br>p=1,0 RCC em 18 meses:<br>p=0,6|NA|NA|NA|
||||RMM em 18 meses: p=1,0||||
|**Jabbour et al**<br>**2013**<sup>48</sup>|Dasa<br>**.**|Mortalidade: 17/259 (7%)<br>SG em 3 anos: 93,7%<br>SLP em 3 anos: 91%<br>Sobrevida sem transformação<br>AP/BP em 3 anos: 94,1%|RCC a qualquer momento: 87<br>RCC confirmada a qualquer m<br>RMM cumulativa em 36 mese<br>Descontinuação do tratamento<br>10%|%<br>omento: 82%<br>s: 69%<br>por progressão de doença:|RCC confirmada: 3 1 meses<br>(IC 95% 3 0-3 1)|NR|
||Ima|Mortalidade: 20/258 (7%)<br>SG em 3 anos: 93,2%<br>SLP em 3 anos: 90,9%<br>Sobrevida sem transformação<br>AP/BP em 3 anos: 93,5%|RCC a qualquer momento: 83<br>RCC confirmada a qualquer m<br>RMM cumulativa em 36 mese<br>por progressão de doença:<br>12%|%<br>omento: 77%<br>s: 55%|RCC confirmada: 5 8 meses<br>(IC 95% 5,6-6,0)<br>NR Descontinuação do tratam|ento|  
62  
|**Autor, ano**|**Grupo**|**Mortalidade**<br>**ou Sobrevida**|**Resposta n/N (%)**|**Tempo até resposta**|**Duração**<br>**da**<br>**resposta**|
|---|---|---|---|---|---|
||P|NR|HR para RMM cumulativa em 36 meses: 1,62; p<0,001<br>Demais NR|NR||
||Dasa|SG em 12 meses: 97%|Progressão da doença: 11/258 (4,3)<br>RCC confirmada em 12 meses: 199/259 (77%); IC95% 71-82<br>RCC em 12 meses: 216/259 (83%); IC95% 78-88<br>RMM a qualquer momento: 135/259 (52%); IC95% 46-<br>58 RMM em 12 meses: 119/259 (46%); IC95% 40-52|Atingiram RCC:<br>em 3 meses: 54%<br>em 6 meses: 73%<br>em 9 meses: 78%<br>Atingiram RMM:<br>em 3 meses: 8%<br>em 6 meses: 27%<br>em 9 meses: 39%|NR|
|**Kantarjian**<br>**et al. 2010**<sup>37</sup>|Ima|SG em 12 meses: 99%|Progressão da doença: 14/258 (5,4)<br>RCC confirmada em 12 meses: 172/260 (66% IC 95% 60-72)<br>RCC em 12 meses: 186/260 (72% IC 95% 66/77)<br>RMM a qualquer momento: 88/260 (34% IC 95% 28-40)<br>RMM em 12 meses: 73/260 (28% IC 95% 23-34)|Atingiram RCC:<br>em 3 meses: 31%<br>em 6 meses: 59%<br>em 9 meses: 67%<br>Atingiram RMM:<br>em 3 meses: 0,4%<br>em 6 meses: 8%<br>em 9 meses: 18%|NR|
||P|NR|RCC confirmada em 12 meses: p=0,007<br>RCC em 12 meses: p=0,001<br>RMM a qualquer momento: p<0,0001<br>RMM em 12 meses: p<0,0001|NR|NA|  
n: número de pacientes que apresentaram o evento; N: número de pacientes; Dasa: Dasatinibe; SLE: Sobrevida Livre de Eventos; RHC: Resposta Hematológica Completa; RCC: Resposta Citogenética Completa; RMM: Resposta Molecular Maior; RMC: Resposta Molecular Completa; NA: Não se aplica; NR: Não reportado; Ima: Imatinibe; SG: Sobrevida Global; SLP: Sobrevida Livre de Progressão; IC: Intervalo de Confiança; HR: _Hazard Ratio_ . Quando não especificados, os dados foram apresentados em mediana (valor mínimo – valor máximo) ou n/N (%).  
*Estudos conduzidos em população adulta.  
63  
**Tabela L –** Eventos adversos  
||**Autor, ano**||||||
|---|---|---|---|---|---|---|
|**Eventos adversos**<br>**(Grau 3- 5)**|**Cortes et**|**al. 2010**<sup>47</sup><br>|**Jabbour**|**et al. 2013**<sup>48</sup>|**Kantarji**|**an et al. 2010**<sup>37</sup>|
||**Dasa 1x/dia**|**Dasa**<br>**2x/dia**|**Dasa**|**Ima**|**Dasa**|**Ima**|
|**Anemia**|1/31 (2)|3/31 (5)|22/183<br>(12)|16/179 (9)|26/258<br>(10)|18/258 (7)|
|**Cefaleia**|2/31 (3)|0|0|0|0|0|
|**Derrame Pleural**|1/31 (2)|0|5/258 (2)|0|0|0|
|**Diarreia**|1/31 (2)|0|<1%|3/258 (1)|1/258 (<1)|3/258 (1)|
|**Dispneia**|2/31 (3)|1/31 (2)|NR|NR|NR|NR|
|**Dor músculo-esquelética**|2/31 (3)|2/31 (3)|NR|NR|0|1/258 (<1)|
|**Edema superficial**|0|0|0|<1%|0|<1%|
|**Fadiga**|4/31 (6)|0|<1%|0|1/258 (<1)|0|
|**Hipertensão pulmonar**|NR|NR|8/183(4)|0|NR|NR|
|**Hipofosfatemia**|0|1/31 (2)|13/183 (7)|50/179<br>(28)|NR|NR|
|**Infecção**|NR|NR|60/183<br>(33)|44/179<br>(25)|NR|NR|
|**Mialgia**|NR|NR|0|<1%|0|0|
|**Náusea**|0|0|0|0|0|0|
|**Neuropatia**|1/31 (2)|2/31 (3)|NR|NR|NR|NR|
|**Neutropenia**|2/31 (3)|5/31 (8)|44/183<br>(24)|38/179<br>(21)|54/258<br>(21)|52/258 (20)|
|**Rash**|NR|NR|0|5/258 (2)|0|3/258 (1)|
|**Trombocitopenia**|2/31 (3)|4/31 (6)|35/183<br>(19)|20/179<br>(11)|49/258<br>(19)|26/258 (10)|
|**Vômito**|0|0|0|0|0|0|  
Dasa: Dasatinibe; Ima: Imatinibe; NR: não reportado. Dados foram apresentados em n/N (%). *Estudos conduzidos em população adulta.  
64  
**Questão de Pesquisa 4:** Quais são os critérios de resposta terapêutica ao imatinibe?

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **MEDLINE via Pubmed:** -->
((("Leukemia, Myeloid, Chronic-Phase"[Mesh] OR "Leukemia, Myelogenous, Chronic, BCR-ABL Positive"[Mesh] OR Leukemia, Chronic Myelogenous OR Leukemia, Chronic Myeloid OR Leukemia, Myelocytic, Chronic OR Chronic Myelocytic Leukemia OR Chronic Myelogenous Leukemia OR Chronic Myeloid Leukemia)) AND ("Imatinib Mesylate"[Mesh] OR Imatinib OR Mesylate, Imatinib OR Imatinib Methanesulfonate OR STI-571 OR Gleevec OR Glivec)) Filters: Adolescent: 13-18 years; Child: birth-18 years; Infant: birth-23 months; Infant: 1-23 months; Preschool Child: 2-5 years; Child: 6-12 years Total: 684 referências  
Data do acesso: 19/02/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **EMBASE:** -->
('chronic myeloid leukemia'/exp/mj AND [embase]/lim) OR (chronic AND myelogenous AND leukemia AND [embase]/lim) OR (leukaemia, AND myelogenous, AND chronic, AND 'bcr abl' AND positive AND [embase]/lim)  
AND  
'imatinib'/mj AND [embase]/lim OR 'gleevac'/exp OR gleevac OR 'gleevec'/exp OR gleevec OR 'glivec'/exp OR glivec OR 'glivic'/exp OR glivic OR 'imatinib'/exp OR imatinib AND mesilate OR 'imatinib'/exp OR imatinib AND ('mesylate'/exp OR mesylate) AND [embase]/lim  
AND  
('child'/exp/mj AND [embase]/lim) OR ('adolescent'/exp/mj AND [embase]/lim) OR ('children'/exp OR children AND [embase]/lim) OR (pediatric AND [embase]/lim)

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: AND -->
([cochrane review]/lim OR [systematic review]/lim OR [meta analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim)  
Total: 34 referências  
Data do acesso: 09/02/2017

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **2) Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 718 referencias (684 no MEDLINE e 34 no Embase). Destas, 18 foram excluídas por estarem duplicadas. Setecentas referências foram triadas por meio da leitura de título e resumos, das quais 13 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dois estudos potencialmente elegíveis foram excluídos por serem relato de caso e série de casos com apenas 6 participantes, que pouco contribuiriam com informações para responder à questão proposta. Um estudo foi excluído por considerar o tratamento com imatinibe, dasatinibe e nilotinibe e não apresentar os resultados de estratificados por molécula. Nove estudos (10 publicações) avaliaram o efeito do imatinibe no tratamento de crianças e adolescentes com LMC e apresentaram critérios e esquema de monitoramento de resposta terapêutica ao imatinibe.

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **Descrição dos estudos e seus resultados** -->
A descrição dos critérios de respostas ao imatinibe, recorrência e esquemas de monitoramento utilizados nos estudos que avaliaram o efeito do imatinibe em população pediátrica com LMC encontra-se na **Tabela M** .  
65  
**Tabela M –** Definições de respostas, recorrências e esquema de monitoramento  
|**Autor, ano**|**População**|**Definição de**<br>**resposta**<br>**hematológica**|**Definição de resposta**<br>**citogenética**|**Definição de**<br>**resposta**<br>**molecular**|**Definição de**<br>**Recorrência**|**Esquema de monitoramento de**<br>**resposta**|
|---|---|---|---|---|---|---|
|**Belgaumi e**<br>**Al-Shehri,**<br>**2010**<sup>40</sup>|População<br>pediátrica<br>com LMC|NR||RMC: BCR-ABL<br>não detectável ao<br>nível <1/10<sup>5</sup>- 10<sup>6</sup><br>RMM: Células<br>BCR-ABL<br>positivas <1/10<sup>4</sup>|Nova positividade<br>citogenética após ter<br>atingido RMM|Monitoramento quantitativo do<br>transcrito BCR-ABL após transplante<br>de célula tronco é crítico para definição<br>do clone leucêmico e para detecção<br>precoce de falha (estudo não descreve<br>periodicidade).|
|**Champagne**<br>**et al. 2004**<sup>41</sup>|População<br>pediátrica (<22<br>anos) com<br>leucemias Ph+<br>(LMC, LLA e<br>LMA)|RHC: Contagem<br>de leucócitos<br><10.000x10<sup>6</sup>/mL<br>e plaquetas<br><450x10<sup>9</sup>/mL|Proporção do número de<br>metafases Ph+ na medula<br>óssea dividida pelo número<br>inicial de metafases Ph+.<br>RCC: 0% de células Ph+.<br>RCP: mais de 0% de cálulas<br>Ph+ a<br>≤35%. RCMenor: >35% a<br>≤65% de células Ph+.<br>RCMin: >65% a ≤95% de<br>células Ph+. Ausência de<br>resposta: >95% de células<br>Ph+|NR|Aumento de contagem de<br>leucócitos e plaquetas por<br>quatro semanas<br>consecutivas|Critério de resposta foi avaliado por<br>meio da contagem de leucócitos,<br>contagem de blastos na medula óssea e<br>estudos citogenéticos de medula óssea<br>ao final de cada ciclo e imatinibe nos 3<br>primeiros ciclos, e após a cada 4 meses<br>ou quando indicado clinicamente.|  
66  
|**Autor, ano**|**População**|**Definição de**<br>**resposta**<br>**hematológica**|**Definição de resposta**<br>**citogenética**|**Definição de**<br>**resposta**<br>**molecular**|**Definição de**<br>**Recorrência**|**Esquema de monitoramento de**<br>**resposta**|
|---|---|---|---|---|---|---|
|**Champagne**<br>**et al. 2011**<sup>42</sup>|População<br>pediátrica<br>recém<br>diagnosticada<br>com LMC|Redução da<br>contagem de<br>leucócitos >50%<br>em relação ao<br>valor de base e<br>mantida por 2<br>semanas. RHC:<br>redução da<br>contagem de<br>leucócitos para<br><10.000/μl e<br>plaquetas para<br><450.000/μl<br>mantida por 4<br>semanas sem<br>características de<br>progressão da<br>doença|Proporção do número de<br>metafases Ph+ na medula<br>óssea dividida pelo número<br>inicial de metafases Ph+.<br>RCC: 0% de células Ph+.<br>RCP: mais de 0% de células<br>Ph+ a<br>≤35%. RCMenor: >35% a<br>≤65% de células Ph+.<br>RCMin: >65% a ≤95% de<br>células Ph+. Ausência de<br>resposta: >95% de células<br>Ph+|Razão BCR-<br>ABL1 dividida<br>por ABL1. RMM:<br>BCR-<br>ABL1/ABL1<br>≤ 0,05% a 0,1%|Progressão da doença<br>definida como aumento<br>≥ 30% de Ph+ nas células<br>medulares (avaliada por<br>citogenética padrão) ou<br>progressão da LMC para<br>fase acelerada ou crise<br>blástica, definida como<br>dobro do tempo de<br>leucócitos <5 dias;<br>cloroma; fibrose medular;<br>>10% de blastos na medula<br>óssea ou blastos +<br>promielócitos >20%;<br>basófilos em sangue<br>periférico e eosinófilos<br>>20%; aumento da<br>esplenomegalia; aumento<br>na contagem de<br>leucócitos ou<br>transformação blástica|Contagem de células sanguíneas e<br>plaquetas no início, semanalmente nos<br>ciclos 1 e 2, e após a cada 2 semanas<br>até o final do tratamento. Resposta<br>hematológica foi avaliada nos ciclos 1 e<br>2. Resposta citogenética da medula<br>avaliada no final dos ciclos 3, 6 e 9 e<br>durante o segundo ano de tratamento.<br>Se RCC fosse obtida foi realizada<br>análise do BCR-ABL1 por RT-PCR<br>para avaliar resposta molecular.|  
|**Giona et al**|Pacientes<br>pediátricos (<|Resposta<br>hematológica e|||Progressão da doença foi<br>definida como perda da|Avaliação da morfologia da medula<br>óssea e citogenética no início do|
|---|---|---|---|---|---|---|
|**.**<br>**2015**<sup>43</sup>|18 anos) com|citogenética|RCP: células Ph+ entre 1% e<br>|RMM: BCR-<br>|RCC ou RMM confirada|tratamento e a cada 3 meses.|
||LMC não<br>|definidas de<br>|≤35%|ABL1 IS ≤0,1%|em 2 amostras levando à<br>|Hibridização fluorescente in situ quando|
||tratados ou<br>resistentes ao|acordo com a<br>European|||troca de tratamento e<br>evolução para fase|RCC for obtida. qPCR mensalmente no<br>sangue periférico e|  
67  
|**Autor, ano**|**População**|**Definição de**<br>**resposta**<br>**hematológica**|**Definição de resposta**<br>**citogenética**|**Definição de**<br>**resposta**<br>**molecular**|**Definição de**<br>**Recorrência**|**Esquema de monitoramento de**<br>**resposta**|
|---|---|---|---|---|---|---|
||IFN|Leukaemia Net<sup>5</sup>|||acelerada ou crise<br>blástica. Recorrência<br>citogenética:<br>Reaparecimento de células<br>Ph+ em paciente com Ph-,<br>confirmado em 2 amostras<br>obtidas com<br>≥1 mês de intervalo|a cada 3 meses na medula óssea.<br>Avaliação de mutação gênica no<br>domínio BCR-ABL1 por<br>sequenciamento direto nos pacientes<br>que não responderam ao tratamento<br>com imatinibe.|
|**Hamidieh et**<br>**al. 2013**<sup>44</sup>|População<br>pediátrica<br>com LMC|RHC: contagem<br>de leucócitos<br><10.000/mm3,<br>plaquetas<br><450.000/mm3,<br>mielócitos e<br>metamielócitos no<br>sangue periférico<br><5%, ausência de<br>blastos e<br>promielócitos no<br>sangue periférico,<br>e basófilos <20%<br>sem envolvimento<br>extramedular|RCM: combinação de RCC<br>e RCP. RCC: ausência de<br>células Ph+ em metafase.<br>RCP: células Ph+ em<br>metafase entre 1% e<br>≤35%. RCMenor: células<br>Ph+ em metafase entre 36-<br>65%. RCMin: células Ph+<br>em metafase entre 66-95%.<br>Ausência de resposta: >95%<br>de células Ph+.|RMC: níveis de<br>BCR-ABL<br>transcrito não<br>detectáveis ou<br>negativo. RMM:<br>razão BCR-ABL<br>/ABL <0,05%|Recorrência hematológica:<br>leucocitose em sangue<br>periférico com<br>predominância de<br>mielócitos e neutrófilos,<br>medula óssea "hyper-<br>cellular" e análise<br>citogenética com Ph+.<br>Recorrência citogenética:<br>≥ Ph+ detectado, sem<br>evidência de recorrência<br>hematológica|Em pacientes que receberão<br>transplante de células tronco, realizar<br>análise citogenética e histopatológica<br>por aspiração da medula óssea e<br>biópsia para confirmar ausência de<br>fase blástica nas duas semanas que<br>precedem o transplante. Sem outros<br>detalhes sobre a periodicidade para<br>avaliar resposta.|  
68  
|**Autor, ano**|**População**|**Definição de**<br>**resposta**<br>**hematológica**|**Definição de resposta**<br>**citogenética**|**Definição de**<br>**resposta**<br>**molecular**|**Definição de**<br>**Recorrência**|**Esquema de monitoramento de**<br>**resposta**|
|---|---|---|---|---|---|---|
|**Lakshmaiah**<br>**et al. 2012**<sup>45</sup>|Adultos e<br>adolescentes<br>(< 20 anos)<br>com LMC|RHC: contagem<br>de leucócitos<br><10x10<sup>9</sup>/L,<br>plaquetas <450<br>x10<sup>9</sup>/L, ausência<br>de células imaturas<br>(blastos,<br>promielócitos ou<br>mielócitos) no<br>sangue periférico,<br>e ausência de<br>sinais e sintomas<br>relacionados à<br>doença (incluindo<br>esplenomegalia).|RCC: ausência de Ph+ após<br>análise de ≥20 metafases.|RMM: razão<br>BCR-ABL<br>/ABL<br>≤0,10%|Progressão da doença:<br>progressão para fase<br>acelerada ou blástica.<br>Progressão para fase<br>acelerada: presença de<br>blastos ≥15% no sangue ou<br>medula óssea, blastos<br>+ promielócitos no sangue<br>ou medula óssea<br>≥30%, basófilos<br>periférico ≥20%, ou<br>trombocitopenia<br>(plaquetas<br><100.000/mm3) não<br>relacionada ao tratamento.<br>Progressão para fase<br>bástica: presença de<br>blastos<br>≥30% no sangue ou<br>medula óssea ou<br>envolvimento<br>extramedular.|Contagem de células sanguíneas e<br>bioquímica no início do tratamento.<br>Após, contagem de células sanguíneas<br>mensalmente. Análise citogenética<br>convencional de banda no início do<br>tratamento, 6 e 12 meses, após<br>anualmente ou em caso de falha ou<br>progressão. q-PCR no sangue periférico<br>no início do tratamento e a cada 6<br>meses após.|  
69  
|**Autor, ano**|**População**|**Definição de**<br>**resposta**<br>**hematológica**|**Definição de resposta**<br>**citogenética**|**Definição de**<br>**resposta**<br>**molecular**|**Definição de**<br>**Recorrência**|**Esquema de monitoramento de**<br>**resposta**|
|---|---|---|---|---|---|---|
|**Millot et al.**<br>**2006**<sup>46</sup>|População<br>pediátrica<br>com LMC, na<br>fase crônica,<br>avançada e em<br>recorrência no<br>pós-<br>transplante|RHC:<br>desapareciment o<br>de todos os sinais<br>e sintomas da<br>doença, contagem<br>de leucócitos<br><10x10<sup>9</sup>/L e<br>normalização da<br>contagem de<br>plaquetas por<br>tempo >4<br>semanas. RHP:<br>mesmo<br>critério<br>para RHC, mas<br>esplenomegalia<br>com redução<br>≥50%, porém<br>ainda palpável,<br>trombocitose e/ou<br>presença de<br>poucas células<br>imaturas<br>(mielócitos +<br>metamielócitos<br>≤5%).|RCC: Células Ph+ 0%. RCP:<br>Células Ph+ 1-35%.<br>RCMenor: Células Ph+ 36-<br>95%. Ausência de resposta:<br>Células Ph+<br>>95%|NR|Crise blástica: blastos +<br>promielócitos ≥30% no<br>sangue e/ou blastos +<br>promielócitos ≥50% na<br>medula óssea. Fase<br>acelerada: presença de<br>pelo menos um dos<br>seguintes: blastos >10% e<br><30% no sangue<br>periférico ou medula<br>óssea, blastos ou<br>promielócitos >20% no<br>sangue periférico ou<br>medula óssea, basófilos<br>periférico >20%,<br>trombocitopenia<br><100x10<sup>9</sup>/L, progressão<br>da esplenomegalia ou<br>evolução de cariótipo<br>(anormalidades<br>cromossômicas +<br>cromossomo Ph único).|Exame físico 3x/semana no primeiro<br>mês, 1x/semana nos meses 2 a 4, 2x/mês<br>nos meses 5 e 6, e mensalmente após.<br>Contagem de células sanguíneas<br>completa 3x/semana no primeiro mês,<br>1x/semana nos meses 2 e 3 e a cada 15<br>dias até mês 6. Bioquímica 1x/semana<br>nos primeiros 4 meses e após<br>simultaneamente com a contagem de<br>células. Análise de medula óssea<br>(morfologia, citogenética, ou<br>hibridização in situ fluorescente)<br>mensalmente nos primeiros 3 meses e<br>no final do mês<br>6. Contagem de células, bioquímica e<br>análise de medula óssea a cada 3 meses<br>após mês 6. PCR para avaliação do<br>transcrito BCR-ABL no início do<br>tratamento e para avaliar resposta<br>molecular nos pacientes que atingiram<br>RCC.|  
70  
|**Autor, ano**|**População**|**Definição de**<br>**resposta**<br>**hematológica**|**Definição de resposta**<br>**citogenética**|**Definição de**<br>**resposta**<br>**molecular**|**Definição de**<br>**Recorrência**|**Esquema de monitoramento de**<br>**resposta**|
|---|---|---|---|---|---|---|
|**Millot et al.**<br>**2011**<sup>13</sup>|População<br>pediátrica<br>recém<br>diagnosticada<br>com LMC|RHC: contagem<br>de leucócitos<br><10x10<sup>9</sup>/L,<br>plaquetas <450<br>x10<sup>9</sup>/L, ausência<br>de células<br>imaturas no<br>sangue,<br>desapareciment o<br>dos sinais e<br>sintomas da<br>doença por tempo<br>>4<br>semanas|RCC: Células Ph+ 0%. RCP:<br>Células Ph+ 1-35%.<br>RCMenor: Células Ph+ 36-<br>95%. Ausência de resposta:<br>Células Ph+<br>>95%|RMM: Razão<br>BCR-ABL<br>/ABL<br>≤0,1%. BCR-ABL<br>não detectável:<br>BCR-ABL /ABL<br>≤0,001%.|Falha do tratamento: perda<br>da RCC ou RHC, falha em<br>obter RHC após 3 meses de<br>tratamento, persistência de<br>100% das metáfases Ph+<br>após 6 meses de<br>tratatemento, metáfases Ph+<br>≥35% após 12 meses de<br>tratamento, ou<br>metáfases Ph+ ≥5% após 18<br>meses de tratamento.|Morfologia de medula óssea e<br>citogenética avaliadas ao disgnóstico, 6<br>e 12 meses após início do tratamento<br>com imatinibe e anualmente após RCC.<br>RT-PCR para avaliação do BCR-ABL<br>transcrito no sangue a cada 3 meses.|
|**Muramatsu**<br>**et al. 2011**<sup>14</sup>|População<br>pediátrica<br>com LMC|Critérios da<br>European<br>Leukemia Net|Critérios da European<br>Leukemia|Critérios da<br>European<br>Leukemia Net|Critérios da European<br>Leukemia Net|NR|  
LMC: Leucemia Mieloide Crônica; NR: não reportado; RMC: Resposta Molecular Completa; RMM: Resposta Molecular Maior; Ph+: cromossomo Filadélfia positivo; LLA: Leucemia Linfoblástica Aguda; LMA: Leucemia Mieloide Aguda; RHC: Resposta Hematológica Completa; RCC: Resposta Citogenética Completa; RCP: Resposta Citogenética Parcial; RCMenor: Resposta Citogenética Menor; RCMin: Resposta Citogenética Mínima; RT-PCR: Reação em cadeia da polimerase via transcriptase reversa; IFN: interferon; qPCR: Reação em cadeia da polimerase quantitativa; RHP: resposta hematológica parcial  
71

---

<!-- METADADOS: doenca: Leucemia Mieloide Crônica de Criança e Adolescente | secao: **REFERÊNCIAS** -->
1. Pallera A, Altman JK, Berman E, Abboud CN, Bhatnagar B, Curtin P, et al. NCCN Guidelines Insights: Chronic Myeloid Leukemia, Version 1.2017. J Natl Compr Cancer Netw. 2016;  
2. Hochhaus A, Baccarani M, Silver RT, Schiffer C, Apperley JF, Cervantes F, et al. European LeukemiaNet 2020 recommendations for treating chronic myeloid leukemia. Leukemia. 2020.  
3. Brasil. Ministério da Saúde. Portaria Conjunta N<sup>o</sup> 04/SAES-SCTIE, de 01 de março de 2021. Diário Oficial da União, Seção 1, No. 44, de 08 de março de 2021. Disponível em https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt.  
4. Aplenc R, Blaney SM, Strauss LC, Balis FM, Shusterman S, Ingle AM, et al. Pediatric phase I trial and pharmacokinetic study of dasatinib: A report from the children’s oncology group phase I consortium. J Clin Oncol. 2011;  
5. Hijiya N, Schultz KR, Metzler M, Millot F, Suttorp M. Pediatric chronic myeloid leukemia is a unique disease that requires a different approach. Blood. 2016.  
6. Ministérios da Saúde (Brasil). Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA). Estimativa 2020: Incidência de Câncer no Brasil. Rio de Janeiro: INCA; 2020. 130 p.  
7. Suttorp M, Millot F. Treatment of pediatric chronic myeloid leukemia in the year 2010: use of tyrosine kinase inhibitors and stem-cell transplantation. Hematology / the Education Program of the American Society of Hematology. American Society of Hematology. Education Program. 2010.  
8. Richardson MW, Grewal SS. Use of imatinib mesylate in a 15-month old with Philadelphia chromosome positive (Ph+) chronic myelogenous leukemia [1]. Pediatric Blood and Cancer. 2008.  
9. Arancibia AM, Bendit I, Epelman S. Complete response to imatinib mesylate treatment in a 12month-old patient with chronic myeloid leukemia. Pediatric Blood and Cancer. 2008.  
10. Gore L, Kearns PR, de Martino Lee ML, De Souza CA, Bertrand Y, Hijiya N, et al. Dasatinib in pediatric patients with chronic myeloid leukemia in chronic phase: Results from a phase II trial. J Clin Oncol. 2018;  
11. Zwaan CM, Rizzari C, Mechinaud F, Lancaster DL, Lehrnbecher T, Van Der Velden VHJ, et al. Dasatinib in children and adolescents with relapsed or refractory leukemia: Results of the CA180018 phase I dose-escalation study of the Innovative Therapies for Children With Cancer Consortium. J Clin Oncol. 2013;  
12. de la Fuente J, Baruchel A, Biondi A, de Bont E, Dresse MF, Suttorp M, et al. Managing children with chronic myeloid leukaemia (CML): Recommendations for the management of CML in children and young people up to the age of 18 years. Br J Haematol. 2014;  
13. Millot F, Baruchel A, Guilhot J, Petit A, Leblanc T, Bertrand Y, et al. Imatinib is effective in children with previously untreated chronic myelogenous leukemia in early chronic phase: Results of the french national phase IV trial. J Clin Oncol. 2011;  
14. Muramatsu H, Takahashi Y, Sakaguchi H, Shimada A, Nishio N, Hama A, et al. Excellent outcomes of children with CML treated with imatinib mesylate compared to that in pre-imatinib era. Int J Hematol. 2011;  
15. Ulmer A, Tabea Tauer J, Glauche I, Jung R, Suttorp M. TK inhibitor treatment disrupts growth hormone axis: Clinical observations in children with CML and experimental data from a Juvenile Animal Model. Klin Padiatr. 2013;  
16. Zwaan M, Stork LC, Bertrand Y, Gore L, Hijiya N, De Souza C, et al. A phase II study of dasatinib therapy in children and adolescents with newly diagnosed chronic phase chronic myelogenous leukemia (CML-CP) or Philadelphia chromosome-positive (Ph+) leukemias resistant or intolerant to imatinib. J Clin Oncol. 2012;  
17. Andolina JR, Neudorf SM, Corey SJ. How I treat childhood CML. Blood. 2012.  
18. Shah NP. NCCN Guidelines Updates: Discontinuing TKI Therapy in the Treatment of Chronic Myeloid Leukemia. Journal of the National Comprehensive Cancer Network : JNCCN. 2019.  
19. Millot F, Guilhot J, Baruchel A, Petit A, Bertrand Y, Mazingue F, et al. Impact of early molecular response in children with chronic myeloid leukemia treated in the French Glivec phase 4 study. Blood. 2014;  
20. WHO. World Health Organization. WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues WHO Classification of Tumours. WHO; 2017 4th Edition. [Available from: http://publications.iarc.fr/Book-And-Report-Series/Who-Iarc-Classification-Of-Tumours/WhoClassification-Of-Tumou.  
21. Pentheroudakis G, Orecchia R, Hoekstra HJ, Pavlidis N. Cancer, fertility and pregnancy: ESMO  
Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2010;  
22. Peccatori FA, Azim JA, Orecchia R, Hoekstra HJ, Pavlidis N, Kesic V, et al. Cancer, pregnancy and fertility: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2013;  
23. Novartis Biociências S.A. Bula de medicamento: Glivec® (mesilato de imatinibe ) Comprimido 100 mg e 400 mg. 2019.  
24. Hochhaus A, Saussele S, Rosti G, Mahon FX, Janssen JJWM, Hjorth-Hansen H, et al. Chronic myeloid leukaemia: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2017;  
25. Baccarani M, Deininger MW, Rosti G, Hochhaus A, Soverini S, Apperley JF, et al. European LeukemiaNet recommendations for the management of chronic myeloid leukemia: 2013. Blood. 2013.  
26. Allan NC, Shepherd PCA, Richards SM. UK Medical Research Council randomised, multicentre trial of interferon-αn1 for chronic myeloid leukaemia: improved survival irrespective of cytogenetic response. Lancet. 1995;  
27. Allan L, Hays H, Jensen N-H, Le Polain De Waroux B, Bolt M, Donald R, et al. Randomised crossover trial of transdermal fentanyl and sustained release oral morphine for treating chronic noncancer pain. Br Med J. 2001;322(7295):1154–8.  
28. Giles FJ, Shan J, Chen S, Advani SH, Supandiman I, Aziz Z, et al. A prospective randomized study of alpha-2b interferon plus hydroxyurea or cytarabine for patients with early chronic phase chronic myelogenous leukemia: The international oncology study group CML1 study. Leuk Lymphoma. 2000;  
29. Talpaz M, Hehlmann R, Quintás-Cardama A, Mercer J, Cortes J. Re-emergence of interferon-α in the treatment of chronic myeloid leukemia. Leukemia. 2013;27(4):803–12.  
30. Schmidt E, Lister J, Neumann M, Wiecek W, Fu S, Vataire AL, et al. Cabozantinib Versus Standardof-Care Comparators in the Treatment of Advanced/Metastatic Renal Cell Carcinoma in Treatmentnaïve Patients: a Systematic Review and Network Meta-Analysis. Target Oncol. 2018;  
31. Ministérios da Saúde (Brasil). Protocolos Clínicos e Diretrizes Terapêuticas em Oncologia. 2014; Available from: www.saude.gov.br  
32. Lipton JH, Khoroshko N, Golenkov A, Abdulkadyrov K, Nair K, Raghunadharao D, et al. Phase II, randomized, multicenter, comparative study of peginterferon-α-2a (40 kD) (Pegasys®) versus interferon α-2a (Roferon®-A) in patients with treatment-naïve, chronic-phase chronic myelogenous leukemia. Leuk Lymphoma. 2007;  
33. M. M, F. M, M. D, A. H, A. R, R.T. S, et al. Pegylated recombinant interferon alpha-2b vs recombinant interferon alpha-2b for the initial treatment of chronic-phase chronic myelogenous leukemia: A phase III study. Leukemia. 2004.  
34. Atallah E, Schiffer CA. Discontinuation of tyrosine kinase inhibitors in chronic myeloid leukemia: When and for whom? Haematologica. 2020.  
35. Richter J, Lübking A, Söderlund S, Lotfi K, Markevärn B, Själander A, et al. Molecular status 36 months after TKI discontinuation in CML is highly predictive for subsequent loss of MMR-final report from AFTER-SKI. Leukemia [Internet]. 2021;10–2. Available from: http://www.ncbi.nlm.nih.gov/pubmed/33589755  
36. Carofiglio F, Lopalco A, Lopedota A, Cutrignelli A, Nicolotti O, Denora N, et al. Bcr-abl tyrosine kinase inhibitors in the treatment of pediatric cml. International Journal of Molecular Sciences. 2020.  
37. Kantarjian H, Shah NP, Hochhaus A, Cortes J, Shah S, Ayala M, et al. Dasatinib versus Imatinib in Newly Diagnosed Chronic-Phase Chronic Myeloid Leukemia. N Engl J Med. 2010;  
38. Colson P, Rolain J-M, Lagier J-C, Brouqui P, Raoult D. Chloroquine and hydroxychloroquine as available weapons to fight COVID-19. International journal of antimicrobial agents. Netherlands; 2020. p. 105932.  
39. Brasil. Ministério da Saúde. Secretaria de Atenção à. Secretaria de Atenção à Saúde. Portarias SAS 431/2001, 347/2008 e 649/2008 – Diretrizes Terapêuticas da Leucemia Mielóide Crônica do Adulto. Brasília Ministério da Saúde. 2011;  
40. Belgaumi AF, Al-Shehri A, Ayas M, Al-Mahr M, Al-Seraihy A, Al-Ahmari A, et al. Clinical characteristics and treatment outcome of pediatric patients with chronic myeloid leukemia. Haematologica. 2010;  
41. Champagne MA, Capdeville R, Krailo M, Qu W, Peng B, Rosamilia M, et al. Imatinib mesylate (STI571) for treatment of children with Philadelphia chromosome-positive leukemia: Results from a Children’s Oncology Group phase 1 study. Blood. 2004;  
42. Champagne MA, Fu CH, Chang M, Chen H, Gerbing RB, Alonzo TA, et al. Higher dose imatinib for children with de novo chronic phase chronic myelogenous leukemia: A report from the Children’s Oncology Group. Pediatr Blood Cancer. 2011;  
43. Giona F, Putti MC, Micalizzi C, Menna G, Moleti ML, Santoro N, et al. Long-term results of highdose imatinib in children and adolescents with chronic myeloid leukaemia in chronic phase: the Italian experience. Br J Haematol. 2015;  
44. Hamidieh AA, Ansari S, Darbandi B, Soroush A, Arjmandi Rafsanjani K, Alimoghaddam K, et al. The treatment of children suffering from chronic myelogenous leukemia: A comparison of the result of treatment with imatinib mesylate and allogeneic hematopoietic stem cell transplantation. Pediatr Transplant. 2013;  
45. Lakshmaiah KC, Bhise R, Purohit S, Abraham LJ, Lokanatha D, Suresh TM, et al. Chronic myeloid leukemia in children and adolescents: Results of treatment with imatinib mesylate. Leuk Lymphoma. 2012;  
46. Millot F, Guilhot J, Nelken B, Leblanc T, De Bont ES, Békassy AN, et al. Imatinib mesylate is effective in children with chronic myelogenous leukemia in late chronic and advanced phase and in relapse after stem cell transplantation. Leukemia. 2006;  
47. Cortes JE, Jones D, O’Brien S, Jabbour E, Ravandi F, Koller C, et al. Results of dasatinib therapy in patients with early chronic-phase chronic myeloid leukemia. J Clin Oncol. 2010;  
48. Jabbour E, Kantarjian HM, Saglio G, Steegmann JL, Shah NP, Boqué C, et al. Early response with dasatinib or imatinib in chronic myeloid leukemia: 3-year follow-up from a randomized phase 3 trial (DASISION). Blood. 2014;

---

