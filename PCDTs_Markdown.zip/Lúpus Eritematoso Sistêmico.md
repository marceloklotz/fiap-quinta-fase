<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: Geral -->
MINISTÉRIO DA SAÚDE

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 21, de 01 de NOVEMBRO de 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Lúpus Eritematoso Sistêmico.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE - SUBSTITUTA e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE – SUBSTITUTA, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Lúpus Eritematoso Sistêmico no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 758/2022 e o Relatório de Recomendação nº 761 – Julho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Lúpus Eritematoso Sistêmico.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do Lúpus Eritematoso Sistêmico, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Lúpus Eritematoso Sistêmico.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º  
Art. 4º Fica revogada a Portaria SAS/MS n<sup>o</sup> 100, de 07 de fevereiro de 2013, publicada no Diário Oficial da União nº 28, de 08 de fevereiro de 2013, seção 1, páginas 70-75.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: MARIA INEZ PORDEUS GADELHA -->
ANA PAULA TELES FERREIRA BARRETO

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **1. INTRODUÇÃO** -->
O Lúpus Eritematoso Sistêmico (LES) é uma doença autoimune multissistêmica caracterizada pela produção de autoanticorpos, formação e deposição de imunocomplexos, com consequente inflamação em diversos órgãos, que pode resultar em dano tecidual e disfunção de órgãos. Sua etiologia permanece pouco conhecida, porém sabe-se da importante participação de fatores genéticos, hormonais, ambientais e imunológicos para o surgimento da doença. As manifestações clínicas são polimórficas e a evolução costuma ser crônica, com períodos de exacerbação e remissão. A doença pode cursar com sintomas constitucionais, artrite, serosite, nefrite, vasculite, miosite, manifestações mucocutâneas, hemocitopenias imunológicas, diversos quadros neuropsiquiátricos, hiperatividade reticuloendotelial e pneumonite<sup>1</sup> .  
O LES afeta mais as mulheres, sendo 9 a 10 vezes mais frequente em mulheres durante a idade reprodutiva<sup>2,3</sup> . A incidência estimada em diferentes locais do mundo é de aproximadamente 1 a 22 casos para cada 100.000 pessoas por ano, e a prevalência pode variar de 7 a 160 casos para cada 100.000 pessoas<sup>3-6</sup> . No Brasil, estima-se uma incidência de LES em torno de 8,7 casos para cada 100.000 pessoas por ano, de acordo com um estudo epidemiológico realizado na região Nordeste<sup>7</sup> .  
A mortalidade dos pacientes com LES é cerca de 3 a 5 vezes maior que a da população geral e está relacionada à atividade inflamatória da doença, especialmente quando há acometimento renal e do sistema nervoso central (SNC), à maior risco de infecções graves decorrentes da imunossupressão e, tardiamente, às complicações da própria doença e do tratamento, sendo a doença cardiovascular um dos mais importantes fatores de morbidade e mortalidade dos pacientes<sup>8-13</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do Lúpus Eritematoso Sistêmico. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 2** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- L93.0 Lúpus discóide  
- L93.1 Lúpus cutâneo subagudo  
- M32.1 Lúpus eritematoso disseminado (sistêmico) com comprometimento de outros órgãos e sistemas  
- M32.8 Outras formas de lúpus eritematoso disseminado (sistêmico)

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **3.1. Diagnóstico clínico** -->
A fadiga é uma das queixas mais prevalentes do LES em atividade. Febre, geralmente moderada e com resposta rápida ao glicocorticoide, é verificada na maioria dos pacientes no momento do diagnóstico. Mialgias, perda de peso e linfadenomegalia reacional periférica podem ser comumente encontradas nos pacientes com LES<sup>14</sup> .  
O acometimento articular é a manifestação mais frequente, depois dos sintomas constitucionais, sendo detectado em mais de 90% dos pacientes durante a evolução da doença, manifestando-se, principalmente, por poliartrite ou poliartralgia simétrica e aditiva. Raramente, evolui com erosões e deformidades ósseas<sup>1</sup> . Pode ocorrer necrose asséptica de múltiplas articulações, principalmente da cabeça do fêmur, particularmente nos pacientes em uso de glicocorticoide em dose elevada por longos  
períodos<sup>15</sup> . Perda de massa óssea com aumento do risco de osteoporose e fraturas geralmente está associada com uso crônico de glicocorticoide e deficiência de vitamina D decorrente da baixa exposição solar<sup>16,17</sup> .  
As lesões de pele são comuns e podem ser variadas. A maioria dos pacientes apresenta fotossensibilidade após exposição à radiação solar ou artificial (lâmpadas fluorescentes ou halógenas). A clássica lesão em asa de borboleta, caracterizada por eritema malar e no dorso do nariz, preservando o sulco naso labial, é identificada em menos de 50% dos casos<sup>18</sup> . Úlceras orais e nasais, em geral indolores, são observadas em cerca de um terço dos pacientes. As lesões do lúpus discoide manifestam-se por placas eritematosas cobertas por uma escama aderente, envolvendo comumente o couro cabeludo, as orelhas, a face e o pescoço. Inicialmente, essas lesões são hiperpigmentadas e evoluem com uma área central atrófica, com ausência de pelos<sup>18</sup> . Neste Protocolo, o lúpus discoide é abordado como uma forma de manifestação cutânea associada ao LES, sendo a sua forma isolada, sem manifestações sistêmicas, considerada uma doença dermatológica. No lúpus cutâneo subagudo, as lesões são simétricas, superficiais, não cicatriciais, localizadas em áreas fotoexpostas. Elas iniciam como pequenas pápulas eritematosas, progredindo para lesões anulares policíclicas ou papuloescamosas (psoriasiformes) e costumam estar associadas à presença do anticorpo antiRo/SSA<sup>18</sup> . O fenômeno de Raynaud, caracterizado por alterações vasculares (vasoconstrição e vasodilatação) que determinam mudança na coloração das extremidades (palidez, cianose e eritema), está presente em 16% a 40% dos pacientes e geralmente se associa com estresse emocional ou frio<sup>14</sup> . Na experiência clínica, alopecia, geralmente difusa ou frontal, é um achado frequente, constituindo-se em um bom marcador de agudização do LES.  
Pericardite é a manifestação cardíaca mais comum, podendo ser clínica ou subclínica, e ocorre em até 55% dos pacientes<sup>19</sup> . O derrame pericárdico geralmente é pequeno e detectável apenas por ecocardiografia, raramente evoluindo para tamponamento cardíaco ou pericardite constritiva. Miocardite está frequentemente associada à pericardite, ocorrendo em cerca de 25% dos casos. Acometimento valvar é frequentemente detectado por ecocardiografia e o espessamento valvar é a alteração mais encontrada. Endocardite de Libman-Sacks caracteriza-se por lesões verrucosas, localizadas especialmente nas valvas aórtica e mitral, sendo descritas em até 43% dos pacientes<sup>20</sup> . Geralmente, apresenta um curso clínico silencioso, podendo, em raros casos, evoluir com eventos tromboembólicos e endocardite infecciosa. Episódios tromboembólicos também podem estar associados à presença de anticorpos antifosfolipídeos e ao uso crônico de glicocorticoide ou de anticoncepcional oral<sup>21</sup> . Doença arterial coronariana, outra manifestação muito importante, está relacionada ao processo acelerado de aterogênese e com morbidade e mortalidade precoces<sup>22</sup> .  
Acometimento pulmonar ou pleural ocorre em cerca de 50% dos pacientes. A manifestação mais comum é a pleurite com derrame de pequeno a moderado volume, geralmente bilateral; mais raramente, podem ocorrer hipertensão arterial pulmonar e pneumonite lúpica. A hipertensão pulmonar geralmente é de intensidade leve a moderada, ocorrendo em 12% a 23% dos casos. O quadro agudo de pneumonite cursa com febre, tosse, hemoptise, pleurisia e dispneia, detectada em até 10% dos pacientes<sup>23</sup> . Síndrome do pulmão encolhido e hemorragia alveolar aguda ocorrem mais raramente<sup>24,25</sup> .  
Manifestações de doença renal ocorrem em cerca de 50% dos pacientes, sendo hematúria e proteinúria persistentes os achados mais observados. Nefrite lúpica pode cursar com síndrome nefrítica ou nefrótica, consumo de complementos, positivação do anti-DNA nativo e, nas formas mais graves, trombocitopenia. Quando não tratada de modo adequado e precoce, a nefrite lúpica, sobretudo nas formas proliferativas, podem evoluir para insuficiência renal crônica. Esse risco é maior nas recidivas da nefrite e em pacientes não caucasianos<sup>1</sup> .  
Sintomas neuropsiquiátricos podem ocorrer nos pacientes com LES, sendo possível dividi-los em eventos primários (danos imunomediados ou por doença vascular) ou secundários (repercussão da doença em outros órgãos ou complicações do tratamento). O Colégio Americano de Reumatologia propôs uma nomenclatura padronizada para a classificação de 19 manifestações neuropsiquiátricas atribuídas ao LES e subdivididas em sistema nervoso central (crises convulsivas, meningite asséptica, cefaleia, doença cérebro vascular, síndromes desmielinizantes, mielopatia, desordens do movimento, estado confusional agudo, desordens de ansiedade, disfunção cognitiva, alterações do humor e psicose) e periférico  
(poliradiculoneuropatia desmielinizante inflamatória aguda, desordens autonômicas, mononeuropatia, miastenia gravis, neuropatia craniana, plexopatia e polineuropatia)<sup>26</sup> . Diagnósticos diferenciais devem sempre ser considerados. A prevalência destas manifestações pode variar de 21% a 95%, dependendo da população estudada e dos métodos de avaliação e definição dos casos. O lúpus neuropsiquiátrico geralmente se manifesta nos primeiros anos de doença e tem associação com atividade de doença<sup>27</sup> , relacionando-se com perda de qualidade de vida, maior morbidade e diminuição da sobrevida. Há relato de aumento de 10 vezes na taxa de mortalidade de pacientes com lúpus neuropsiquiátrico, quando comparados à população em geral<sup>28</sup> .  
Ao longo da evolução clínica, observam-se períodos de exacerbação e atividade de doença. Este padrão evolutivo pode ser resumido em 3 modelos<sup>29</sup> :  
- 1)  pacientes cronicamente ativos (40%);  
- 2)  pacientes que alternam exacerbação e remissão (35%) e  
- 3)  pacientes com remissão sustentada por longos períodos (25%).  
A distribuição percentual dos pacientes nesses padrões pode variar de acordo com a população estudada e com as ferramentas utilizadas para quantificar atividade de doença. Comprovadamente, a atividade de doença, independentemente da ferramenta utilizada para sua medida, determina dano cumulativo ao longo do tempo, o que se correlaciona diretamente com aumento de mortalidade<sup>30</sup> . Além da atividade de doença, o uso de corticoide de forma contínua e em doses acima de 7,5 mg/dia determina de maneira independente maior dano acumulado e consequentemente incremento da mortalidade<sup>31,32</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **3.2. Diagnóstico laboratorial** -->
Para o diagnóstico de LES, é fundamental as anamnese e exame físico completos e de alguns exames laboratoriais que podem auxiliar na detecção de alterações clínicas e laboratoriais da doença, a saber:  
- Hemograma completo com contagem de plaquetas;  
- contagem de reticulócitos;  
- teste de Coombs direto;  
- velocidade de hemossedimentação (VHS);  
- proteína C reativa;  
- eletroforese de proteínas;  
- aspartato-aminotransferase (AST/TGO);  
- alanina-aminotransferase (ALT/TGP);  
- fosfatase alcalina;  
- bilirrubinas total e frações;  
- desidrogenase láctica (LDH);  
- ureia e creatinina;  
- eletrólitos (cálcio, fósforo, sódio, potássio e cloro);  
- exame qualitativo de urina (EQU);  
- complementos (CH50, C3 e C4);  
- albumina sérica;  
- proteinúria de 24 horas;  
- VDRL; e  
- avaliação de autoanticorpos (FAN, anti-DNA nativo, anti-Sm, anticardiolipinas IgG, IgM ou IgA, anticoagulante lúpico, anti-beta2-glicoproteína1 IgG, IgM ou IgA, anti-La/SSB, anti-Ro/SSA e anti-RNP).  
A solicitação dos exames deve basear-se na avaliação clínica de cada paciente. Algumas das alterações que podem ser observadas nos exames estão descritas nos critérios de classificação da doença. Caso sejam observadas, a conduta é definida pelo médico assistente, que deve ser capacitado para o tratamento desta doença.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **3.3. Critérios da** **_American College of Rheumatology_ (ACR) 1982/1997** -->
O paciente pode ser classificado com LES a partir da presença de, pelo menos, 4 dos 11 critérios descritos no **Quadro 1** , em qualquer momento da vida, propostos pelo _American College of Rheumatology_ (ACR) em 1982<sup>33</sup> e revisados em 1997<sup>34</sup> e aceitos universalmente.  
**Quadro 1** - Critérios ACR 1987/1999 para Lúpus Eritematoso Sistêmico  
**Critérios** Eritema malar: eritema fixo, plano ou elevado nas eminências malares, tendendo a poupar a região nasolabial. Lesão discoide: lesão eritematosa, infiltrada, com escamas queratóticas aderidas e tampões foliculares, que evolui com cicatriz atrófica e discromia. Fotossensibilidade: eritema cutâneo resultante de reação incomum ao sol, por história do paciente ou observação do médico. Úlcera bucal: ulceração bucal ou nasofaríngea, geralmente não dolorosa, observada pelo médico. Artrite: artrite não erosiva envolvendo 2 ou mais articulações periféricas, caracterizada por dor à palpação, edema ou derrame. Serosite: a) pleurite – história convincente de dor pleurítica ou atrito auscultado pelo médico ou evidência de derrame pleural; ou b) pericardite – documentada por eletrocardiografia ou atrito ou evidência de derrame pericárdico. Alteração renal: a) proteinúria persistente de mais de 0,5 g/dia ou acima de 3+ (+++) se não quantificada; ou b) cilindros celulares – podem ser hemáticos, granulares, tubulares ou mistos. Alteração neurológica: a) convulsão – na ausência de fármacos implicados ou alterações metabólicas conhecidas (por exemplo, uremia, cetoacidose, distúrbios hidroeletrolíticos); ou b) psicose – na ausência de fármacos implicados ou alterações metabólicas conhecidas (por exemplo, uremia, cetoacidose, distúrbios hidroeletrolíticos). Alterações hematológicas: a) anemia hemolítica com reticulocitose; ou b) leucopenia de menos de 4.000/mm<sup>3</sup> em duas ou mais ocasiões; ou c) linfopenia de menos de 1.500/mm<sup>3</sup> em duas ou mais ocasiões; ou d) trombocitopenia de menos de 100.000/mm<sup>3</sup> na ausência de uso de fármacos causadores. Alterações imunológicas: a) presença de anti-DNA nativo; ou b) presença de anti-Sm; ou c) achados positivos de anticorpos antifosfolipídeos baseados em concentração sérica anormal de anticardiolipina IgG ou IgM, em teste positivo para anticoagulante lúpico, usando teste-padrão ou em VDRL falso-positivo por, pelo menos, 6 meses e confirmado por FTA-Abs negativo.  
Anticorpo antinuclear (FAN): título anormal de FAN por imunofluorescência ou método equivalente em qualquer momento, na ausência de medicamentos sabidamente associados ao lúpus induzido por fármacos.  
Fonte: _American College of Rheumatology_ (ACR)<sup>33,34</sup> .  
Embora o FAN esteja presente em mais de 95% dos pacientes com a doença ativa, o teste apresenta baixa especificidade, de modo que o FAN pode ser encontrado em 13% das pessoas sadias. Títulos de FAN acima de 1:80 são considerados significativos<sup>35</sup> . Nos casos com pesquisa de FAN negativa, particularmente com lesões cutâneas fotossensíveis, deve-se realizar a pesquisa de anticorpos anti-Ro/SSA e anti-La/SSB. Dosagens de anticorpos anti-DNA nativo e anticorpos anti-Sm são consideradas testes específicos, mas têm menor sensibilidade. A presença de anticorpos tem valor clínico quando ocorrer em pacientes com manifestações compatíveis com o diagnóstico de LES.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **3.4. Critérios SLICC 2012** -->
Em 2012, os critérios SLICC foram elaborados pela revisão dos critérios da ACR de 1997. Os critérios SLICC possuem maior sensibilidade, porém menor especificidade em comparação com os critérios do ACR de 1997 (sensibilidade de 97% versus 83% e especificidade de 84% versus 96%, respectivamente). Já são critérios validados pela comunidade científica mundial e se uso é recomendado em diretrizes clínicas, além de serem utilizados em estudos clínicos<sup>36,37</sup> .  
De acordo com os critérios SLICC, o paciente pode ser classificado como com LES quando apresentar, pelo menos, quatro dos critérios a seguir, incluindo pelo menos um critério clínico e um critério imunitário ou se apresentar biópsia renal compatível com nefrite lúpica na presença de FAN ou anticorpos anti-dsDNA. Os critérios, descritos no **Quadro 2** , são cumulativos e não necessitam ser concomitantes.  
**Quadro 2** - Critérios SLICC 2012 para Lúpus Eritematoso Sistêmico  
**Critérios clínicos** Lúpus cutâneo agudo: eritema malar (não é contabilizado se for lesão discoide), lúpus bolhoso, variante com necrose epidérmica tóxica, eritema maculopapular, eritema fotossensível (na ausência de dermatomiosite) ou lúpus cutâneo subagudo (anular policíclico ou psoriasiforme não cicatricial, apesar de poder evoluir com alteração de pigmentação ou teleangiectasias). Lúpus cutâneo crônico: eritema discóide localizado (acima do pescoço) ou generalizado (acima e abaixo do pescoço), lúpus hipertrófico (verrucoso), paniculite (lúpus profundus), lúpus mucoso, lúpus eritematoso tumidus, eritema pérnio ou sobreposição de lúpus discoide e líquen plano. Alopecia não cicatricial: afinamento difuso ou fragilidade capilar com quebra visível de cabelos (na ausência de outras causas, tais como alopecia areata, alopecia androgênica, medicamentos, deficiências vitamínicas ou ferropenia). Úlceras orais ou nasais: ulcerações geralmente pouco dolorosas localizadas no palato, boca e língua ou úlceras nasais (na ausência de outras causas, tais como vasculites, doença de Behçet, infecções – herpes vírus, doença intestinal inflamatória, artrite reativa, medicamentos ou comidas ácidas). Alterações articulares: sinovite em duas ou mais articulações, com edema ou derrame articular ou artralgia em duas ou mais articulações e rigidez matinal maior que 30 minutos. Serosites: dor pleurítica típica por mais de um dia ou derrame pleural ou atrito pleural ou dor pericárdica típica por mais de um dia ou derrame pericárdico ou atrito pericárdico ou eletrocardiograma com sinais de pericardite (na ausência de outras causas, tais como infecção, uremia ou síndrome de Dressler). Alterações renais: relação entre proteína e creatinina urinárias (ou proteinúria de 24 horas) representando mais de 500 mg de proteínas nas 24 horas ou presença de cilindros hemáticos. Alterações neurológicas: convulsão, psicose, mononeurite múltipla, mielite, neuropatia periférica ou craniana ou estado confusional agudo (na ausência de vasculites primárias, infeccções, distúrbios hidroeletrolíticos, distúrbios metabólicos, uremia, medicamentos, intoxicações ou diabetes melito). Anemia hemolítica: presença de anemia hemolítica.  
Leucopenia ou linfopenia: contagem de leucócitos <4.000/mm³ ou linfopenia <1.000/mm³, em pelo menos uma ocasião (na ausência de outras causas, tais como síndrome de Felty, medicamentos ou hipertensão portal).  
Trombocitopenia: contagem de plaquetas <100.000/mm³ em pelo menos uma ocasião (na ausência de outras causas, tais como medicamentos, hipertensão portal ou púrpura trombocitopênica trombótica).

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Critérios imunológicos** -->
Fator Antinuclear: fator antinuclear acima do valor de referência.  
Anti-DNA nativo: anti-DNA nativo acima do valor de referência ou 2 vezes acima do valor de referência quando testado por ELISA.  
Anti-Sm: anticorpo anti-Sm positivo.  
Antifosfolipídeos: qualquer um dos seguintes: anticoagulante lúpico positivo; VDRL falso-positivo; anticardiolipinas (IgA, IgG ou IgM) em títulos moderados ou altos ou anti-beta 2-glicoproteína 1 (IgA, IgG ou IgM) positivo.  
Complementos reduzidos (abaixo do limite inferior da normalidade de acordo com a técnica do laboratório): frações C3, C4 ou CH50.  
Coombs direto: Coombs direto positivo (na ausência de anemia hemolítica).  
Fonte: _Systemic Lupus International Colaborating Clinics_<sup>36</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **3.5. Critérios Eular/ACR 2019** -->
Em 2019, foram publicados critérios da _European Legue Against Rheumatism/American College of Rheumatology_ (Eular/ACR), baseado em sete domínios clínicos e três laboratoriais. Na coorte de validação, a sensibilidade e a especificidade destes critérios de classificação foram, respectivamente, 96,1% e 93,4%<sup>38-40</sup> .  
O paciente pode ser classificado como com LES se tiver pontuação ≥ 10, sendo que, em cada domínio, deve ser utilizada a maior pontuação. Ainda, é condição necessária a positividade de FAN ≥ 1:80. Uma revisão sistemática e meta-regressão que incluiu 13.080 casos mostrou uma sensibilidade de 98% do FAN ≥ 1:80 para o LES<sup>41</sup> . Os critérios estão descritos no **Quadro 3** .  
**Quadro 3** - Critérios Eular/ACR 2019  
|**Domínio Constitucional**|**Pontuação**|**Domínio hematológico**|**Pontuação**|
|---|---|---|---|
|Febre|2|Leucopenia|3|
|**Domínio Cutâneo**||Plaquetopenia|4|
|Alopecia não cicatricial|2|Hemólise autoimune|4|
|Úlceras orais|2|**Domínio renal**||
|Lúpus cutâneo subagudo ou Lúpus Eritematoso<br>Discoide|4|Proteinúria ≥ 0,5 g/24 horas|4|
|Lúpus cutâneo agudo|6|Biópsia renal classe II ou nefrite lúpica classe<br>V|8|
|**Domínio articular**||Biópsia renal classe III ou nefrite lúpica<br>classe IV|10|
|Sinovite ou dor à palpação ≥ 2 articulações e<br>rigidez matinal ≥ 30 minutos|6|**Domínio dos anticorpos antifosfolipídicos**||
|**Domínio neurológico**||aCL (IgG > 400PL ou anti-B2GPI IgG > 40<br>ou LAC+|2|
|Delírio|2|**Domínio complemento**||  
|Psicose|3|C3 baixo ou C4 baixo|3|
|---|---|---|---|
|Convulsão|5|C3 e C4 baixos|4|
|**Domínio serosas**||**Domínio**<br>**dos**<br>**anticorpos**<br>**altamente**<br>**específicos**||
|Derrame pleural ou pericárdico|5|Anti-dsDNA|6|
|Pericardite aguda|6|Anti-Smith|6|  
Fonte: _European Legue Against Rheumatism/American College of Rheumatology_<sup>38</sup> . Legenda: aCL: Anticorpos anticardiolipina; anti-B2GPI: Anticorpos antibeta2 glicoproteína 1; LAC: Anticoagulante lúpico.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **3.6. Avaliação da atividade do LES** -->
A atividade da doença pode ser avaliada pela combinação de anamnese, exame físico e exames laboratoriais. Existem vários índices com sensibilidade semelhante<sup>42</sup> para avaliar a atividade da doença, tais como: SLEDAI ( _Systemic Lupus Erythematosus Disease Activity Index_ )<sup>43,44</sup> , SLAM ( _Systemic Lupus Activity Measure_ )<sup>45</sup> e BILAG ( _British Isles Lupus Assessment Group_ )<sup>46</sup> .  
A ferramenta mais utilizada para avaliar a atividade de doença tem sido o SLEDAI (Apêndice 1). Assim, por avaliar a atividade global de doença, o SLEDAI é um fator determinante de dano acumulado. O aumento no escore do SLEDAI associase ao aumento da mortalidade, do seguinte modo<sup>31,43,47</sup> :  
- 20 pontos ou mais: risco relativo (RR) de 14,1 para morte em 6 meses;  
- 11 a 19 pontos: RR de 4,7 para morte em 6 meses;  
- 6 a 10 pontos: RR de 2,3 para morte em 6 meses;  
- 1 a 5 pontos: RR de 1,3 para morte em 6 meses.  
Há ferramentas variantes do SLEDAI e uma das mais utilizadas nos estudos clínicos tem sido o SELENA-SLEDAI, que consiste no SLEDAI com modificações de alguns descritores com validação e aplicação relativamente simples na prática clínica. Apresenta 24 descritores que englobam 9 órgãos/sistemas e considera somente alterações relacionadas ao LES no intervalo de 10 dias antes da consulta<sup>48</sup> .  
Outra ferramenta, conhecida como SRI ( _Systemic Lupus Erythemthosus Response Index_ ), tem sido validada em ensaios clínicos desenvolvidos para estudar novos medicamentos no tratamento de pacientes com LES. Trata-se de uma ferramenta composta que, além de considerar a melhora de 4 pontos no escore do SELENA-SLEDAI, inclui a não piora avaliada pelo escore BILAG<sup>49</sup> .  
A detecção de lesão irreversível ou sequela decorrente da doença ou do tratamento empregado no controle da atividade de doença pode ser medida por meio do índice de dano SLICC ( _Systemic Lupus International Colaborating Clinics/American College of Rheumatology DAMAGE INDEX_ )<sup>50</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Inluem-se neste Protocolo todos os pacientes com o diagnóstico confirmado de LES, segundo os critérios de classificação do ACR 1982/1997, do SLICC 2012 ou do Eular/ACR 2019.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Lúpus induzido por medicamentos (LDR)** -->
As manifestações clínicas surgem após a administração de medicamentos, sendo hidralazina e procainamida os mais frequentemente envolvidos. Também têm sido descritos casos associados ao uso de medicamentos anti-TNF. Os sintomas podem ser semelhantes aos de LES, havendo comprometimento cutâneo, musculoesquelético, sintomas constitucionais e serosites. Raramente, ocorrem alterações hematológicas graves, acometimento neuropsiquiátrico ou renal. Caracteriza-se pela presença de anticorpos anti-histona. As manifestações desaparecem com a retirada do fármaco desencadeante<sup>51</sup> . O tratamento envolve uso de medicamentos para o controle dos sintomas, como analgésicos comuns e anti-inflamatórios não esteroides (AINES) e, em casos refratários, glicocorticoides, como a prednisona em dose de 0,5 mg/kg/dia até a resolução do quadro clínico.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Lúpus na gestação** -->
Mulheres lúpicas geralmente têm fertilidade preservada. Durante a gestação, as complicações obstétricas são maiores, assim como o risco de exacerbação da doença, especialmente no puerpério. O prognóstico é melhor para ambos, mãe e feto, quando a doença está em remissão há, pelo menos, 6 meses antes da concepção. Durante a gestação, há maior prevalência de pré-eclâmpsia, eclâmpsia, sofrimento fetal e morte fetal, principalmente em mulheres com nefrite lúpica e presença de anticorpos antifosfolipídeos<sup>52</sup> .  
O tratamento pode ser realizado com glicocorticoide e antimaláricos, nas doses indicadas no item esquema de administração, além de todos os cuidados e orientações preconizados para os demais pacientes com LES. Imunossupressores geralmente são contraindicados durante a gestação. Em casos excepcionais com maior gravidade, podem ser utilizadas a azatioprina ou a ciclosporina para controle da atividade de doença. Nestes casos, uma ampla discussão com a paciente, sua família e o médico obstetra deve ser realizada, para que a decisão seja compartilhada, avaliando riscos e benefícios<sup>53-55</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Lúpus neonatal** -->
É uma condição clínica caracterizada por graus variados de bloqueio cardíaco fetal, trombocitopenia, alterações hepáticas e cutâneas relacionadas com a passagem transplacentária de autoanticorpos maternos, especialmente anti-Ro/SSA e antiLa/SSB<sup>56</sup> . O bloqueio cardíaco fetal pode ocorrer em até 2% das mães com anti-Ro/SSA positivo e 5% das mães com antiRo/SSA e anti-La/SSB positivo, podendo haver risco ainda maior naqueles casos com bloqueio cardíaco fetal prévio<sup>57</sup> .  
Em mulheres grávidas com anti-Ro/SSA ou antiLa/SSB positivos é preconizada a realização de ecocardiograma fetal semanal a partir da semana 16 até a semana 26<sup>57</sup> . Alguns autores recomendam complementar este acompanhamento ecocardiográfico fetal a cada 2 semanas depois da 26ª semana até a 34ª semana de gestação<sup>58</sup> . O tratamento do bloqueio cardíaco fetal depende da gravidade e é realizado com glicocorticoide que atravessem a barreira placentária, tais como dexametasona ou betametasona, em doses que variam de acordo com a gravidade. Embora não uniformemente efetivos, apresentam benefício em bloqueios de 1º e 2º graus, o que até o momento não foi demonstrado em bloqueio de 3º grau.  
Em casos graves com cardiomiopatia, fibroelastose endocárdica e hidropsia fetal, além do glicocorticoide pode ser considerado o uso de imunoglobulina intravenosa ou plasmaférese. Nestas situações, geralmente as condições do feto são ameaçadoras à vida e o tratamento é feito em nível hospitalar, onde a interrupção da gestação pode acontecer a qualquer momento. Entretanto, há riscos da terapia com glicocorticoide para mãe e para a criança, tais como infecção, hipertensão, necrose avascular, diabetes gestacional, oligodramnia, restrição do crescimento e ainda potenciais efeitos neurocognitivos<sup>59</sup> . As demais manifestações tendem a ser leves e geralmente estarão resolvidas até o 6º mês de vida da criança. O uso da hidroxicloroquina tem sido recomendado devido ao potencial benefício em diminuir o risco de bloqueio cardíaco fetal<sup>57,60</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7. TRATAMENTO** -->
Os objetivos do tratamento do LES são<sup>61</sup> :  
> - propiciar controle das manifestações clínicas e laboratoriais, reduzindo a atividade de doença;  
- prevenir as recidivas de atividade de doença;  
- prevenir o dano ao longo da evolução da doença;  
- diminuir a dose cumulativa de corticoide e  
- melhorar a qualidade de vida dos pacientes.  
Na busca desses objetivos, há uma série de medidas medicamentosas e não medicamentosas que podem ser utilizadas. Entretanto, mesmo utilizando fármacos adequados, muitos pacientes ainda se mantêm com a doença ativa e com progressão para danos irreversíveis, o que determina maior mortalidade.  
Entre as medidas não medicamentosas, o exercício físico aeróbico parece ser uma medida eficaz e adequada na redução da fadiga causada pela doença, conforme revisões sistemáticas de 2016 e 2017<sup>62,63</sup> . O tratamento do LES envolve inicialmente medidas gerais, listadas a seguir<sup>2,37, 64-66</sup> :  
- aconselhamento, suporte e orientação por meio de tratamento multidisciplinar para o paciente e seus familiares, informar  
- sobre a doença e sua evolução, possíveis riscos e recursos disponíveis para diagnóstico e tratamento; transmitir otimismo e motivação para estimular a adesão ao tratamento e o cumprimento dos projetos de vida;  
- orientação dietética para prevenção e controle de osteoporose, dislipidemia, obesidade e hipertensão arterial sistêmica (HAS); dar preferência para uma dieta balanceada, com baixo teor de sal, carboidratos e lipídios, especialmente nos usuários crônicos de glicocorticoide; considerar a dieta rica em cálcio ou suplementação quando necessário<sup>67</sup> ;  
- suplemento de vitamina D, objetivando manter níveis séricos de 25 (OH) vitamina D sérica maiores que 30 ng/mL, para  
- todos os pacientes;  
- prevenção da osteoporose nos usuários crônicos de glicocorticoide, de acordo com o Protocolo Clínico e Diretrizes  
- Terapêuticas (PCDT) da Osteoporose, publicado pelo Ministério da Saúde e disponível em https://www.gov.br/conitec/ptbr/assuntos/avaliacao-de-tecnologias-em-saude/protocolos-clinicos-e-diretrizes-terapeuticas#O;  
- exercícios físicos regulares aeróbicos para melhorar e manter o condicionamento físico dos pacientes; evitar exercícios  
- nos períodos de importante atividade sistêmica da doença;  
- proteção contra a luz solar e outras formas de irradiação ultravioleta, por meio de barreiras físicas, como roupas com  
- mangas longas, gola alta e uso de chapéus; evitar exposição direta ou indireta ao sol e às lâmpadas fluorescentes ou halógenas. Deve-se usar fotoprotetores em áreas fotoexpostas, reaplicando a intervalos regulares;  
- avaliação ginecológica anual, com exame clínico das mamas e do colo do útero para detecção de displasia cervical  
- causada por HPV.  
- avaliação oftalmológica a cada 12 meses, especialmente para pacientes em uso de antimaláricos;  
- consulta odontológica periódica para preservação da saúde bucal;  
- atualização do calendário vacinal, incluindo vacinação anual contra o vírus da gripe<sup>68</sup> , vacina para hepatite B e vacina  
- pneumocócica. Em pacientes com LES e em uso de imunossupressores, deve-se evitar vacinas com vírus vivos atenuados, especialmente tríplice viral e contra febre amarela;  
- suspensão do tabagismo;  
- pesquisa de Tuberculose (TB) ativa e infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) antes de se iniciar o  
uso de imunossupressores, incluindo glicocorticoides em doses acima de 20 mg/dia;  
- investigação sorológica e tratamento para sífilis, hepatite B, hepatite C e HIV antes do início do tratamento;  
- tratamento empírico com anti-helmíntico para estrongiloidíase antes de iniciar o uso dos medicamentos imunossupressores (o anti-helmíntico pode ser repetido a cada 6 a 12 meses, dependendo das condições socioeconômicas e hábitos dietéticos dos pacientes);  
- para pacientes com nefrite lúpica, uso de inibidores da enzima conversora da angiotensina (captopril, enalapril) ou  
- bloqueadores do receptor AT1 da angiotensina II (losartana potássica) como antiproteinúricos para todos os pacientes (exceto  
em caso de contraindicação). Nestes casos, deve-se evitar medicamentos nefrotóxicos, especialmente os anti-inflamatórios não esteroidais (AINE).  
- prevenção e tratamento dos fatores de risco cardiovasculares, tais como sedentarismo, diabetes melito, HAS (pressão arterial alvo menor que 130 x 80 mmHg), dislipidemia (LDL alvo menor que 100 mg/dL) e obesidade - o uso de medicamentos hipolipemiantes pode ser feito, conforme PCDT da Dislipidemia: prevenção de eventos cardiovasculares e pancreatite, publicado pelo Ministério da Saúde e disponível em https://www.gov.br/conitec/pt-br/assuntos/avaliacao-de-tecnologias-emsaude/protocolos-clinicos-e-diretrizes-terapeuticas#D;  
- profilaxia para _Pneumocystis jirovecii_ nos casos de infecções prévias ou nos pacientes com linfopenia menor que 500mm<sup>3</sup> persistente, especialmente se associadas à hipocomplementemia adquirida ou genética; e  
- orientações a respeito da anticoncepção (havendo necessidade de uso de anticoncepcionais orais, dar preferência para os sem ou com baixa dose de estrogênio. Não é aconselhado o uso de anticoncepcionais orais em pacientes com LES e história de doença cardiovascular ou risco aumentado para a ocorrência de fenômenos tromboembólicos. Deve-se evitar a concepção nos períodos de atividade da doença ou durante o tratamento com medicamentos contraindicados na gestação).  
O tratamento medicamentoso consiste de antimaláricos (cloroquina e hidroxicloroquina), glicocorticoides (betametasona, dexametasona, metilprednisolona e prednisona) e diversos tipos de imunossupresores ou imunomoduladores, a depender do órgão ou sistema afetado pela doença<sup>2,37,66</sup> .  
Todos os pacientes com LES têm indicação para uso de antimaláricos, exceto em situações envolvendo reações de hipersensibilidade ou desenvolvimento de complicações relacionadas a estes medicamentos, especialmente maculopatia. Os antimaláricos têm demostrado eficácia em controlar manifestações leves de atividade de doença, diminuir exacerbações, melhorar sobrevida, limitar cronicidade e permitir redução da dose de glicocorticoides<sup>37, 69-71</sup> .  
Os glicocorticoides são os medicamentos mais utilizados no tratamento de LES, e as doses diárias variam de acordo com a gravidade de cada caso. Apresentam inúmeros eventos adversos e, por isso, devem ser utilizados na menor dose efetiva para o controle da atividade da doença e, assim que possível, reduzidos gradualmente até a suspensão. Para pacientes em uso de antimaláricos e que não conseguem atingir a dose de manutenção de prednisona menor ou igual a 7,5 mg/dia, há indicação de associação de outro medicamento para poupar glicocorticoides, tais como a azatioprina e o metotrexato<sup>72,73</sup> .  
O belimumabe é um anticorpo monoclonal IgG1 totalmente humano cujo mecanismo de ação se dá pela ligação ao BLyS ( _B Lymphocite Stimulator_ ) solúvel, impedindo sua ligação ao linfócito B, diminuindo sua maturação, diferenciação e sobrevida. O medicamento está registrado na Agência Nacional de Vigilância Sanitária (Anvisa) para terapia adjuvante em pacientes adultos com LES ativo, que apresentam alto grau de atividade da doença (ex.: anti-DNA nativo positivo e baixo complemento) e que estejam em uso de tratamento padrão, incluindo AINES, glicocorticoide, antimaláricos ou outros imunossupressores. O belimumabe foi avaliado e não incorporado no âmbito do SUS. A análise conduzida apontou baixa qualidade dos estudos que comparam seu benefício e segurança, frente aos tratamentos já disponibilizados pelo SUS, além do seu alto custo<sup>74</sup> . Por isso, este Protocolo não preconiza o uso de belimumabe para o tratamento do LES.  
O rituximabe, anticorpo monoclonal quimérico que desencadeia depleção de linfócitos B, apesar de não ser aprovado pela Anvisa para tratamento do LES, apresenta relatos e séries de casos sobre seu uso em pacientes com doença grave e refratária. A experiência clínica com o uso do rituximabe no LES mostra um papel importante no tratamento de pacientes com doença grave e refratária ao tratamento convencional, especialmente nos casos de acometimento renal, mas também musculoesquelético, hematológico, cutâneo e neurológico<sup>75-77</sup> . Entretanto, estudos que avaliaram o rituximabe em pacientes com doença moderada à grave com acometimento renal e extra renal não apresentaram superioridade de eficácia em relação ao placebo, apesar de um perfil de segurança adequado. Há grande discussão a respeito das limitações destes estudos, o que talvez não tenha permitido mostrar os benefícios do seu uso<sup>78</sup> . Este Protocolo não preconiza o uso de rituximabe para o tratamento do LES.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.1. Manifestações cutâneas** -->
O tratamento dependerá da extensão e da gravidade do comprometimento cutâneo. Preconisa-se aos pacientes a não exposição ao sol devido à relação entre radiação UV-B e fotossensibilidade e outras lesões cutâneas do LES. O uso de glicocorticoide tópico, como dexametasona, para lesões isoladas também pode ser considerado. As lesões do lúpus cutâneo subagudo costumam responder bem ao uso de antimaláricos isolados ou em combinação com terapia tópica<sup>79</sup> .  
O uso de fotoprotetor solar tem mostrado benefícios em pacientes com manifestações cutâneas e sistêmicas da doença e deve ser recomendado a todos os pacientes. Dá-se preferência aos fotoprotetores com ação bloqueadora UV-A e UV-B, resistentes à água e com FPS 30, pelo menos. Além disto, medidas físicas devem ser estimuladas, tais como sombrinhas, roupas e chapéus<sup>80-86</sup> .  
Pacientes com lesões cutâneas disseminadas devem utilizar glicocortcoide sistêmico em associação com imunossupressores. Uma revisão sistemática do grupo Cochrane de 2009 e sua atualização de 2017 avaliou a eficácia e a segurança do uso de azatioprina, hidroxicloroquina, clofazimina, dapsona, sais de ouro, metotrexato, alfainterferona, fenitoína, retinoides, sulfasalazina, bloqueadores da calcineurina tópicos (pimecrolimo e tacrolimo), agentes biológicos (etanercepte, efalizumabe, infliximabe e rituximabe) e talidomida nos pacientes com lúpus discoide<sup>87,88</sup> . Hidroxicloroquina e acitretina mostraram-se eficazes em aproximadamente 50% dos pacientes, embora tais medicamentos não tenham sido testados contra placebo nesta situação. Além disso, eventos adversos foram mais frequentes e mais graves com o uso da acitretina. Não havendo evidências científicas suficientes na literatura atual que embasem o uso dos outros medicamentos avaliados nessa revisão para a manifestação de lúpus discoide, a hidroxicloroquina deve ser o medicamento utilizado como primeira escolha. Nos pacientes que apresentam manifestações cutâneas refratárias aos glicocorticoides e aos antimaláricos, pode-se associar metotrexato na dose de 10 a 20 mg/semana, podendo ser aumentado até 25 mg/semana<sup>72</sup> , ou azatioprina<sup>89</sup> .  
Embora não existam estudos controlados, talidomida se mostrou uma opção para casos com lesões cutâneas refratárias, desde que os pacientes não apresentem risco de gravidez. O primeiro estudo usando talidomida em LES foi publicado em 1993<sup>90</sup> . Nesse estudo, 23 pacientes com LES e lesões cutâneas refratárias ao uso de glicocorticoide e cloroquina receberam talidomida na dose inicial de 300 mg/dia. Três deles necessitaram suspender o medicamento por eventos adversos (sonolência e alergia) e 18 dos 20 pacientes apresentaram desaparecimento das lesões ativas, sendo 2 com resposta parcial. Como a reativação das lesões foi comum, preconiza-se a utilização da menor dose de manutenção possível (25-100 mg/dia). Outros estudos também demonstraram a eficácia de talidomida em pacientes com lesões cutâneas refratárias<sup>91-101</sup> , sendo preconizada neste Protocolo.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.2. Manifestações articulares** -->
Artrite crônica com recidivas frequentes ocorre em cerca de 10% dos pacientes. O tratamento geralmente é feito com AINES, antimaláricos<sup>102</sup> ou glicocorticoides. Nos casos refratários, pode-se optar por metotrexato<sup>103</sup> . Um ensaio clínico duplocego brasileiro randomizou pacientes lúpicos com atividade leve para participarem de grupo placebo ou grupo metotrexato, com o objetivo de avaliar a resposta clínica e a capacidade de reduzir a necessidade do uso de glicocorticoide sistêmico em pacientes que não estivessem recebendo antimalárico. Após 6 meses de seguimento, os seguintes resultados foram obtidos, comparando os grupos tratados e não tratado com metotrexato: o número de pacientes com lesões cutâneas ativas (lesão discoide ou eritema malar) foi de 16% _versus_ 84%; o de pacientes com manifestações articulares (artralgia ou artrite) foi de 5% _versus_ 84%; e o de pacientes com redução de, pelo menos, 50% na dose do glicocorticoide em relação à dose inicial foi de 72,2% _versus_ 5%, evidenciando claramente os melhores resultados clínicos com o uso de metotrexato<sup>72</sup> . Já uma revisão sistemática publicada em 2014 confirmou os bons resultados do metotrexato em reduzir níveis leves a moderados de atividade de doença e ser uma boa opção para poupar uso de glicocorticoide<sup>104</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.3. Manifestações neuropsiquiátricas** -->
Complicações neuropsiquiátricas em pacientes com LES incluem manifestações focais ou difusas, agudas ou crônicas. As mais graves são convulsões, psicose, mielite transversa, doença cerebrovascular e distúrbios do movimento. O diagnóstico deve ser confirmado após a exclusão de infecções, eventos adversos de medicamentos e alterações hidroeletrolíticas ou metabólicas<sup>105,106</sup> . O tratamento dos pacientes com acometimento neuropsiquiátrico grave envolve o uso de terapia de controle específico para cada manifestação (por exemplo, anticonvulsivante para convulsões e antipsicóticos para psicose), glicocorticoide sistêmico em doses imunossupressoras e ciclofosfamida.  
Revisão sistemática do grupo Cochrane encontrou evidência de superioridade de ciclofosfamida em relação à metilprednisolona em pacientes com diagnóstico de LES e acometimento neuropsiquiátrico, caracterizado por convulsões, síndrome cerebral orgânica ou neuropatia craniana<sup>107</sup> . Neste estudo, foi incluído um ensaio clínico randomizado com 32 pacientes com lúpus neuropsiquiátrico, comparando o uso de ciclofosfamida e metilprednisolona. No grupo que utilizou ciclofosfamida, houve 94,7% (18/19) de resposta terapêutica versus 46,2% (6/13) no grupo com metilprednisolona, no período de 24 meses (RR 2,05, IC95% 1,13 a 3,73). O NNT para a resposta terapêutica foi 2 (IC95% 1 a 6). O uso de ciclofosfamida foi associado à redução da dose de glicocorticoide, bem à redução significativa no número de convulsões mensais. Todos os pacientes do grupo ciclofosfamida tiveram melhora eletroencefalográfica, e não houve diferença significativa entre os grupos quanto aos eventos adversos. Assim, caso o paciente não apresente resposta ao uso de glicocorticoides, deve utilizar ciclofosfamida<sup>108,109</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.4. Manifestações renais** -->
Os objetivos do tratamento são normalizar ou prevenir a perda de função renal, induzir remissão da atividade renal, prevenir reativações renais e evitar ao máximo a toxicidade do tratamento.  
O tratamento da nefrite lúpica (NL) envolve o uso de glicocorticoide e outros imunossupressores, além de medidas gerais, tais como cessação do tabagismo, uso de medicamentos renoprotetores (inibidor da enzima conversora de angiotensina ou bloqueador de receptores da angiotensina) e controle da pressão arterial. A utilização de prednisona por via oral ou de pulsos de metilprednisolona intravenosa evidencia melhora ou estabilização da função renal<sup>109-112</sup> . Pacientes com nefrite proliferativa devem ser tratados com glicocorticoide em doses altas por um período de 6 a 8 semanas, com posterior redução gradativa da dose<sup>113</sup> . A pulsoterapia com metilprednisolona é preconizada para casos graves com disfunção renal aguda<sup>114</sup> . As recomendações da EULAR publicadas em 2019 incluem o uso de glicocorticoides em doses menores e a manutenção com a dose mínima possível de glicocorticoides pelo menor tempo necessário, a fim de reduzir os eventos adversos<sup>115</sup> .  
O uso de agentes imunossupressores citostáticos está indicado no tratamento dos casos de glomerulonefrite proliferativa. A ciclofosfamida intravenosa pode ser inicialmente sob a forma de pulsos mensais por seis meses<sup>115</sup> . Alguns autores recomendam doses menores de ciclofosfamida (500 mg) a cada 15 dias por um período de 3 meses, introduzindo precocemente azatioprina para terapia de manutenção<sup>116</sup> . No entanto, como a ciclofosfamida não é capaz de controlar todos os casos e devido à sua alta toxicidade e eventos adversos, especialmente risco de infecções, surgimento de neoplasias e indução de infertilidade, novas terapêuticas têm sido propostas<sup>117</sup> .  
Uma meta-análise evidenciou que o uso concomitante de azatioprina ou ciclofosfamida e tratamento com glicocorticoide diminuiu a incidência da progressão para insuficiência renal terminal e a mortalidade total quando comparado com o glicocorticoide isolado<sup>110</sup> . Estudos do Instituto Nacional de Saúde americano demonstraram que a probabilidade de evitar progressão para insuficiência renal em 10 a 12 anos em pacientes de alto risco foi de 90% com ciclofosfamida, de 60% com azatioprina e de 20% com prednisona<sup>111</sup> . O benefício da ciclofosfamida na nefrite lúpica começou a ser demonstrado em estudo que avaliou a função renal de pacientes que utilizaram prednisona por via oral ou medicamentos imunossupressores. Os resultados mostraram que a combinação de ciclofosfamida intravenosa e prednisona em dose baixa foi superior ao uso de  
prednisona em dose alta isolada na preservação da função renal<sup>111,112,118</sup> . O seguimento desses mesmos pacientes, reavaliados após 4 anos, demonstrou resultados semelhantes.  
Um ensaio clínico randomizado com 82 pacientes apresentando nefrite proliferativa comparou pulsos de 1 g/m<sup>2</sup> de metilprednisolona mensal por 12-36 meses, pulsos de 1 g/m<sup>2</sup> de ciclofosfamida mensal por 6 meses seguido por pulsos trimestrais por 24 meses e a combinação dos dois esquemas. Os pacientes que utilizaram somente glicocorticoide tiveram maior probabilidade de duplicar a creatinina sérica do que os que usaram esquemas com ciclofosfamida. O seguimento de cerca de 11 anos mostrou que o grupo que recebeu pulsoterapia combinada apresentou significativamente menor número de pacientes que duplicaram a creatinina sérica, quando comparado aos outros grupos. O risco cumulativo de infecções graves não foi diferente entre os 3 grupos<sup>119</sup> .  
Outro ensaio clínico randomizado comparou o uso de ciclofosfamida intravenosa e oral administrada em forma de pulsoterapia com o uso de ciclofosfamida oral de forma contínua<sup>120</sup> . Trinta e dois pacientes com nefrite proliferativa foram randomizados em dois grupos. Dezesseis deles receberam esquema de pulsoterapia de 10 mg/kg de ciclofosfamida intravenosa a cada 3 semanas por 9 semanas, seguido por pulsoterapia oral de 10 mg/kg de ciclofosfamida mensal até a 104ª semana. O outro grupo também com 16 pacientes recebeu esquema com 2 mg/kg/dia de ciclofosfamida. Ambos os grupos usaram metilprednisolona associada e, após o término do uso de ciclofosfamida, iniciaram azatioprina. O acompanhamento do estudo teve duração de 3,7 anos para o grupo pulsoterapia com CFF e de 3,3 anos para o grupo ciclofosfamida de forma contínua. Os resultados foram semelhantes nos 2 grupos, tanto para controle da doença quanto para eventos adversos. O estudo sustentou a possibilidade de uso de ciclofosfamida oral de forma contínua como opção à pulsoterapia de ciclofosfamida<sup>120</sup> .  
Pacientes com contraindicação ou refratários ao tratamento com ciclofosfamida ainda são um desafio para o tratamento. O micofenolato de mofetila tem sido empregado para o tratamento da NL com bons resultados, especialmente em pacientes com formas proliferativas (focal e difusa) e membranosa. Revisão sistemática demonstrou que o micofenolato de mofetila é tão efetivo quanto a ciclofosfamida para induzir remissão da nefrite lúpica com menos eventos adversos e é uma boa alternativa para a terapia de manutenção<sup>121</sup> . Dois consensos internacionais (Colégio Americano de Reumatologia e Liga Europeia Contra o Reumatismo) e o Consenso nacional para tratamento da nefrite lúpica recomendam seu uso tanto na primeira linha, quanto na falha à ciclofosfamida<sup>115,122,123</sup> .  
Nos pacientes com nefrite membranosa pura, o tratamento é controverso. Podem ser utilizados glicocorticoides ou agentes imunossupressores, na dependência do quadro de síndrome nefrótica. Entre os imunossupressores podem ser indicadas ciclofosfamida, ciclosporina, azatioprina e micofenolato de mofetila<sup>2,115, 121,123</sup> .  
Revisão sistemática de 2013 sugeriu que micofenolato de mofetila possa ser utilizado também em manifestações lúpicas não renais, com bons resultados no controle de atividade de doença, na redução de exacerbações e com efeito poupador de glicocorticoide ao longo do tempo<sup>124</sup> . Assim, o uso de micofenolato de mofetila no âmbito do SUS foi avaliado pela Conitec, conforme Relatório de Recomendação nº 358/2018<sup>125</sup> . À época, em função do medicamento não possuir indicação em bula para o uso no tratamento da nefrite lúpica, a decisão de incorporação ficou pendente de autorização de uso excepcional pela Anvisa. No entanto, em abril de 2022, a Anvisa autorizou a indicação do medicamento para terapia de indução e manutenção de pacientes adultos com nefrite lúpica classe III a V. Assim, conforme a Portaria SCTIE/MS nº 46/2022, o micofenolato de mofetila foi incorporado no âmbito do SUS para tratamento de nefrite lúpica<sup>125</sup> .  
O tacrolimo é um fármaco inibidor da calcineurina que desencadeia diminuição dos níveis de interleucina-2 (IL-2) e outras citocinas que atuam preferencialmente no funcionamento dos linfócitos T. Este medicamento tem sido utilizado em algumas situações no LES, mas ainda as evidências científicas, tanto em manifestações renais quanto extra-renais, são pequenas e predominantemente voltadas para população asiática sem resultados a longo prazo<sup>126-128</sup> . Um levantamento de revisões sistemáticas e meta-análises de 2017 sobre o tratamento das manifestações renais concluiu que tanto o tacrolimo como o micofenolato de mofetila são mais eficazes e seguros do que a ciclofosfamida, enquanto que a eficácia e a segurança são  
comparáveis entre o tacrolimo e o micofenolato de mofetila na terapia de indução<sup>128</sup> . A terapia de combinação de tacrolimo e o micofenolato de mofetila em baixas doses pode ser uma opção para pacientes com NL. Já seu uso combinado é superior ao tacrolimo ou ao micofenolato de mofetila em monoterapia, mas são necessárias mais evidências que avaliem os resultados em longo prazo e na manutenção dos pacientes, especialmente para avaliar o risco de toxicidade renal destes fármacos<sup>129</sup> .  
Ainda, a biópsia renal deve ser feita, sempre que possível e quando houver indicação. Quando não for possível, o tratamento deve ser orientado com base na inferência da classe histológica baseado em dados clínicos (como hipertensão arterial) e laboratoriais (creatinina, urina tipo I, proteinúria 24 horas ou relação proteína/creatinina).

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.5. Manifestações hematológicas** -->
Os pacientes com LES podem desenvolver complicações hematológicas graves, como anemia hemolítica autoimune ou plaquetopenia. O tratamento de escolha para anemia hemolítica tem sido glicocorticoide em doses que dependem da gravidade da apresentação. O período de tratamento é variado, em média 4 a 6 semanas, com posterior redução, dependendo da resposta. Setenta e cinco por cento dos pacientes responde satisfatoriamente a esta terapêutica<sup>130</sup> . Nos casos graves, pode ser usada pulsoterapia com metilprednisolona<sup>131</sup> . Nos casos refratários ao glicocorticoide ou mesmo corticodependentes, podem-se usar imunossupressores, como azatioprina e ciclosporina<sup>132</sup> . Todos os estudos, entretanto, são baseados em relatos e série de casos, não sendo possível estabelecer superioridade entres os medicamentos.  
A plaquetopenia pode ser tratada com glicocorticoide em doses que dependem da intensidade e da presença de fenômenos hemorrágicos. Quando for refratária ao uso de glicocorticoide ou tornar-se corticodependente, pode-se usar danazol com bons resultados<sup>133</sup> . Outros medicamentos que podem ser utilizados, mas com evidência científica escassa, são ciclofosfamida<sup>134</sup> , antimaláricos associados à prednisona<sup>135</sup> , azatioprina<sup>136</sup> , ciclosporina<sup>137</sup> e micofenolato de mofetila<sup>124</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.6. Manifestações cardiopulmonares** -->
Pacientes com pericardite ou pleurite podem inicialmente ser tratados com AINES, desde que não apresentem contraindicações. Nos casos mais graves ou que não respondem adequadamente aos AINES, podem ser utilizados glicocorticoides em dose moderada e imunossupressores poupadores de glicocorticoides, como a azatioprina<sup>138,139</sup> . Miocardite geralmente requer tratamento com glicocorticoide em dose alta, por via oral ou em pulsoterapia na fase inicial, e, em casos refratários, imunossupressores como azatioprina ou ciclofosfamida podem ser benéficos, apesar de a evidência basear-se em estudos não controlados<sup>140</sup> . Pneumonite lúpica aguda e hemorragia pulmonar são manifestações graves e incomuns, para as quais pulsoterapia com glicocorticoide isolado ou em combinação com ciclofosfamida, plasmaférese, azatioprina ou micofenolato de mofetila podem ser preconizados<sup>124,139</sup> . Outras apresentações, como doença pulmonar intersticial e síndrome dos pulmões encolhidos, podem ser tratadas com glicocorticoide associado ou não a imunossupressores<sup>139</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.7. Fármacos** -->
- Acetato de betametasona + fosfato dissódico de betametasona: suspensão injetável de (3 mg +3 mg)/mL;  
- Azatioprina: comprimidos de 50 mg;  
- Ciclofosfamida: comprimidos de 50 mg e pó para solução injetável de 200 e 1.000 mg;  
- Ciclosporina: cápsulas de 10, 25, 50, 100 mg e solução oral de 100 mg/mL – frasco de 50 mL;  
- Cloroquina: comprimidos de 150 mg;  
- Danazol: cápsulas de 100 ou 200 mg;  
- Dexametasona: comprimidos de 4 mg;  
- Hidroxicloroquina: comprimidos de 400 mg;  
- Metilprednisolona: pó para solução injetável de 500 mg;  
- Metotrexato: comprimidos de 2,5 mg e solução injetável de 25 mg/mL;  
- Micofenolato de mofetila: comprimidos de 500 mg;  
- Prednisona: comprimidos de 5 ou 20 mg;  
- Talidomida: comprimido de 100 mg.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.8. Esquemas de administração** -->
- Azatioprina: dose inicial de 0,5 a 1 mg/kg/dia, por via oral, aumentando 0,5 mg/kg a cada 4 semanas até atingir o controle da atividade da doença, que é evidenciado por resolução das alterações clínicas e laboratoriais apresentadas pelo paciente. A dose máxima não deve ultrapassar 3 mg/kg/dia.  
- Ciclofosfamida: 1-3 mg/kg/dia, por via oral, 1 vez/dia, ou infusão de 0,5-1,0 g/m<sup>2</sup> por via intravenosa a cada 4 semanas. Para prevenir cistite hemorrágica, recomenda-se a administração de mesna por via intravenosa ou oral (1 mg para cada 1 mg de ciclofosfamida) dividida em 4 administrações: 30 minutos antes da infusão e 2, 4 e 6 horas após o término da infusão. Sugere-se administração de 1.000 mL de cloreto de sódio (soro fisiológico) 0,9%, por via intravenosa, 1 hora antes da infusão, bem como o uso de diuréticos. Hidratação oral deve ser estimulada ao longo do tratamento com ciclofosfamida.  
- Ciclosporina: doses de até 5 mg/kg/dia, divididas em 2 administrações, por via oral.  
- Cloroquina: 2-3 mg/kg/dia, por via oral.  
- Danazol: dose inicial de 100 mg, 2 vezes/dia, por via oral, durante 30 dias, aumentando progressivamente até 400 mg, 2 vezes/dia. Quando a dose terapêutica for alcançada, manter o danazol por mais 30 dias e iniciar a retirada de glicocorticoide. Quando a dose de glicocorticoide atingir 10 mg/dia e as plaquetas estiverem em níveis adequados (acima de 100.000/mm<sup>3</sup> ) durante 2 meses consecutivos, iniciar a redução da dose de danazol até 100 mg/dia. Esta dose pode ser mantida por 2 a 3 anos de acordo com a evolução clínica.  
- Hidroxicloroquina: 5 mg/kg/dia, por via oral.  
- Metilprednisolona: pulsoterapia de 250-1.000 mg/dia ou 15-20 mg/kg/dia, por via intravenosa, ao longo de 1 hora por  
3 dias consecutivos; repetir mensalmente conforme resposta terapêutica.  
- Metotrexato: dose inicial de 10 mg/semana, por via oral ou intramuscular, podendo ser aumentada para até 25  
- mg/semana.  
- Micofenonato de mofetila: na fase de indução, a dose preconizada é 2 a 3 g/dia, por via oral, dividida em 2 administrações diárias. Na fase de manutenção, de acordo com a resposta clínica e laboratorial, a dose pode ser diminuída para 1 a 2 g/dia, de maneira lenta e gradual. A retirada gradual do tratamento poderá ser tentada após pelo menos 3 a 5 anos de tratamento em resposta clínica completa.  
- Prednisona: 0,125 a 2 mg/kg/dia, por via oral, em dose única ou dividida em 3 doses, de acordo com a manifestação a ser tratada. Se houver controle da doença, iniciar diminuição gradual da dose não acima de 20% da dose vigente a cada 4 semanas até 10 mg/dia e manter conforme evolução clínica. Na fase de manutenção, a dose de prednisona deve ser inferior a 7,5 mg/dia. Caso haja recidiva da manifestação durante a diminuição de dose, retornar à mínima dose efetiva. Deve ser usada em associação com outros medicamentos citados neste Protocolo, quando não for possível reduzir a dose de glicocorticoide.  
- Talidomida: a menor dose possível (25-100 mg/dia), dividida em 2 doses diárias por, pelo menos, 6 meses, por via oral. A dose máxima preconizada é cerca de 200 mg/dia, devido ao menor risco de toxicidade. Se não ocorrer reativação da lesão cutânea, deve-se tentar reduzir a dose (50 mg em dias alternados) e, depois de 3 meses, suspende-se a talidomida. Caso surjam novas lesões cutâneas, reinicia-se o tratamento.  
Tendo como padrão o uso de prednisona por via oral, as doses podem ser divididas em<sup>139</sup> :  
- dose baixa: 0,125 mg/kg/dia;  
- dose moderada: 0,125 a 0,5 mg/kg/dia;  
- dose alta: 0,6 a 1 mg/kg/dia;  
- dose muito alta: 1 a 2 mg/kg/dia;  
- pulsoterapia com glicocorticoide: aplicação intravenosa de metilprednisolona (15 a 20 mg/kg/dia) até 1.000 mg/dia,  
administrada em 1 hora, habitualmente por 3 a 5 dias consecutivos.  
Esquemas usuais de prednisona utilizados em pacientes com LES também podem ser ajustados da seguinte maneira<sup>137</sup> :  
- dose baixa: menos de 7,5 mg/dia;  
- dose moderada: 7,5 a 30 mg/dia;  
- dose alta: 30 a 100 mg/dia;  
- dose muito alta: mais de 100 mg/dia;  
- pulsoterapia com glicocorticoide: aplicação intravenosa de metilprednisolona 125 a 1.000 mg/dia, administrada em 1  
- hora, habitualmente por 3 dias consecutivos.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Para lúpus neonatal** -->
- Dexametasona ou betametasona: dose inicial de 4 mg/dia por via oral ou 3 mg/dia por via intravenosa, respectivamente, e seguir conforme descrito na **Tabela 1**<sup>58,59,141</sup> . O paciente deve ser acompanhado por reumatologista, obstetra, neonatologista e cardiologista pediátrico em serviços especializados, onde a conduta poderá ser individualizada de acordo com as condições clínicas maternofetais.  
**Tabela 1** – Monitoramento e controle da cardiopatia associada ao lúpus neonatal.  
|**Apresentação clínica**|**Conduta**<sup>**a**</sup>|
|---|---|
|Intervalo PR>140 ms ou moderada regurgitação<br>tricúspide|Ecocardiografia fetal seriada em 1-3 dias; sem tratamento<br>específico.|
|Intervalo PR>150 ms|Ecocardiografia fetal seriada em 1-3 dias; considerar uso de<br>dexametasona 4 mg/dia ou betamesona 3 mg/dia.|
|BAV de 2<sup>o</sup>grau ou 2º e 3<sup>o</sup>graus alternantes|Dexametasona 4 mg/dia ou betamesona 3 mg/dia.|
|BAV com sinais de miocardite, insuficiência cardíaca,<br>regurgitação tricúspide ou hidropsia fetal.|Dexametasona 4 mg/dia ou betamesona 3 mg/dia.|
||Monitorar conforme evolução; uso de dexametasona ou|
|BAV de 3<sup>o</sup>grau sem hidropsia fetal|betametasona é controverso (levar em consideração tempo de<br>surgimento do BAV); considerar simpaticomiméticos.|
|BAV de 3<sup>o</sup>grau com hidropsia fetal grave, miocardite ou<br>cardiomiopatia, fibroelastose ou regurgitação tricúspide<br>grave|Dexametasona 4 mg/dia ou betamesona 3 mg/dia; considerar<br>cesariana se pulmão fetal maduro.|  
BAV: bloqueio atrioventricular; ms: milissegundos.<sup>a</sup> Considerar imunoglobulina intravenosa ou plasmaférese, conforme o item 6. Casos Especiais.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.9. Tempo de tratamento** -->
Inexiste um período estabelecido para a duração do tratamento. Atingida a remissão clínica, as doses dos medicamentos podem ser diminuídas gradualmente, sob monitorização sistemática da atividade de doença. Sugere-se reduzir primeiro a dose da prednisona. Após suspensão do glicocorticoide, deve-se diminuir a dose dos imunossupressores em intervalos mensais ao longo de aproximadamente 6 a 12 meses. A hidroxicloroquina deve ser utilizada de forma contínua ao longo do tempo e somente deve ser retirada se houver evento adverso significativo<sup>33</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.10. Contraindicações** -->
O uso de qualquer um dos medicamentos preconizados neste Protocolo é contraindicado em pacientes com histórico de hipersensibilidade ao fármaco específico ou a qualquer outro componente da sua fórmula. Outras contraindicações específicas para cada medicamento estão elencadas a seguir:  
- cloroquina e hidroxicloroquina: uso concomitante de primaquina, maculopatia prévia associada aos antimaláricos;  
- azatioprina: infecção aguda ou crônica ativa, tuberculose sem tratamento, lactação, neoplasia em atividade. Em modelos experimentais, há relato de malformações fetais, mas em humanos, este risco aparentemente é muito baixo, o que possibilita seu uso em casos de manifestações graves nos quais o risco é menor que o benefício, especialmente nos casos de nefrite lúpica, mas a dose preconizada deve ser de, no máximo, 2 mg/kg/dia<sup>115</sup> ;  
- ciclosporina: insuficiência renal crônica, neoplasia em atividade, lactação, infecção aguda ou crônica ativa, tuberculose  
- sem tratamento, hipertensão não controlada;  
- ciclofosfamida: neoplasia em atividade, obstrução do trato urinário, infecção aguda ou crônica ativa, tuberculose sem  
- tratamento, gestação, lactação, concepção (homens e mulheres);  
- danazol: doença hepática, renal ou cardíaca grave, porfiria, sangramento uterino anormal, gestação, lactação;  
- metilprednisolona, dexametasona, betametasona e prednisona: úlcera péptica ativa, infecção aguda ou crônica ativa,  
- tuberculose sem tratamento;  
- metotrexato: tuberculose sem tratamento, infecção aguda ou crônica ativa, hepatites B ou C agudas, elevação de enzimas hepáticas (ALT/TGO e AST/TGO) igual ou três vezes o limite superior da normalidade (LSN), cirrose, alcoolismo, taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica, gestação, amamentação e concepção (homens e mulheres);  
- micofenolato de mofetila: gestação, lactação, concepção (homens e mulheres), infecção aguda ou crônica ativa,  
- tuberculose sem tratamento;  
- talidomida: mulheres em idade reprodutiva que não estejam usando pelo menos dois métodos contraceptivos, gestação, neuropatia periférica.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **7.11. Benefícios esperados** -->
- Controle da atividade da doença (rápido e persistente), que pode ser avaliada pelo SLEDAI;  
- prevenção das recidivas de atividade de doença;  
- diminuição da dose cumulativa de corticoide;  
- controle e impedimento do surgimento de complicações crônicas do LES ou decorrentes do próprio tratamento empregado, que podem ser aferidos pela ferramenta avalia índice de dano SLICC<sup>50</sup> ;  
- melhora da qualidade de vida dos pacientes.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **8. MONITORAMENTO** -->
A frequência das consultas de seguimento é determinada pela atividade e gravidade da doença e de suas complicações. Pacientes com doença leve podem ser avaliados em intervalos de 3 a 6 meses. Pacientes com doença grave ou com complicações do tratamento devem ter consultas mais frequentes, assim como aqueles que estão iniciando a terapia sistêmica. Nem sempre existe relação direta entre a melhora clínica e a normalização dos exames laboratoriais. Por isso, é importante que haja um acompanhamento criterioso dos pacientes.  
Antes do início do uso de imunossupressores, incluindo glicocorticoides em doses acima de 20 mg/dia, e com objetivo de realizar o planejamento terapêutico adequado, deve-se pesquisar a ocorrência de TB e ILTB. Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados para investigar a presença de ILTB, como  
radiografia simples de tórax e prova tuberculínica (PT). O IGRA (do inglês _Interferon Gama Release Assay_ ) pode ser solicitado para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame estabelecidos na sua portaria de incorporação.  
O tratamento da ILTB é indicado para pacientes com PT≥5 mm, ou positividade ao IGRA, alterações radiográficas compatíveis com tuberculose prévia não tratada ou contato próximo com caso de tuberculose. O esquema de tratamento da TB ativa e ILTB deve seguir o Manual de recomendações para o controle da tuberculose no Brasil e demais orientações do Ministério da Saúde.  Preconiza-se o início do uso de imunossupressores após 1 mês do início do tratamento de ILTB e concomitantemente ao tratamento da TB ativa. Para fins de acompanhamento, considera-se desnecessário repetir a PT de pacientes com PT ≥ 5 mm, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB. Pacientes que que já foram tratados de ILTB (em qualquer momento da vida) não precisam se tratar novamente dessa condição; da mesma forma que os pacientes que já se submeteram ao tratamento completo de TB, exceto quando em caso de nova exposição (novo contato). Enquanto estiverem em uso de imunossupressores, o paciente deve ser acompanhado periodicamente para sinais e sintomas de TB. Pacientes com PT < 5 mm necessitam repetir a PT anualmente. Não há necessidade de repetir a radiografia simples de tórax, caso não haja suspeita clínica de TB.  
A ferramenta SLEDAI para avaliar atividade de doença deve ser utilizada periodicamente. Ela permite uma detecção mais objetiva e organizada de exacerbações e auxilia muitas vezes na tomada de decisão. Em pacientes com doença ativa, ela deve ser repetida em cada consulta, entretanto, em pacientes com doença estável e inativa, ela pode ser realizada anualmente. Para acompanhar cronicidade, é preconizada aplicação da ferramenta índice de dano SLICC, pelo menos anualmente.  
Preconiza-se a realização dos seguintes exames periodicamente, os quais podem ser modificados de acordo com as manifestações clínicas encontradas em cada paciente:  
- hemograma completo com contagem de plaquetas;  
- complementos (CH50, C3 e C4);  
- anti-DNA nativo;  
- creatinina;  
- aspartato-aminotransaminase (AST/TGO);  
- alanina-aminotransferase (ALT/TGP);  
- fosfatase alcalina;  
- exame qualitativo de urina (EQU) e urocultura;  
- velocidade de hemossedimentação (VHS);  
- proteína C reativa; e  
- albumina sérica e proteinúria de 24 horas ou relação proteína/creatinina em amostra isolada de urina: se houver história  
- de nefrite ou lúpus grave (em risco de ter nefrite).  
A conduta a ser adotada depende da alteração encontrada nos exames. O FAN é um exame laboratorial utilizado para o diagnóstico e não tem valor comprovado no acompanhamento da atividade da doença. O uso de medicamentos imunossupressores deve ser precedido por triagem de doenças infecciosas (hepatite B, hepatite C, SIDA e tuberculose), história clínica, exames laboratoriais.  
A dose dos medicamentos utilizados deve ser sempre revisada e ajustada, se o paciente apresentar perda de função renal caracterizada por depuração de creatinina endógena calculada abaixo de 50 mL/min, exceto para os glicocorticoides.  
A toxicidade dos medicamentos empregados deve ser cuidadosamente monitorizada:  
- Azatioprina: deve ser solicitada a realização de hemograma, plaquetas, fosfatase alcalina, TGO e TGP quinzenalmente  
- nos primeiros 3 meses e, após, trimestralmente ou se houver mudança nas doses. A azatioprina deve ser suspensa ou ter a dose  
reduzida em pacientes que desenvolverem leucopenia (menos de 4.000/mm<sup>3</sup> ) ou plaquetopenia (menos de 100.000/mm<sup>3</sup> ). O aumento de aminotransferases (transaminases hepáticas) e fosfatase alcalina pode ocorrer em alguns casos e, caso esteja duas vezes acima do LSN, o medicamento deve ser suspenso até a normalização do exame.  
- Glicocorticoides (betametasona, dexametasona, metilprednisolona e prednisona): devem ser realizadas glicemia de jejum, dosagens de potássio, perfil lipídico, densitometria óssea e aferição da pressão arterial no início do tratamento e ao longo do acompanhamento. O uso de bisfosfonados é preconizado para prevenir perda óssea em todos os homens e mulheres, nos quais o tratamento com glicocorticoides em doses acima de 5 mg/dia ultrapassar 3 meses, ou nos pacientes que já recebem glicocorticoides por tempo prolongado, nos quais o T-Score da densidade mineral óssea na coluna ou no quadril estiver abaixo do normal. Reavaliar anualmente o perfil lipídico e a densitometria óssea. O tratamento e prevenção da osteoporose deve ser feito de acordo com o PCDT de Osteoporose do Ministério da Saúde disponível em https://www.gov.br/conitec/ptbr/assuntos/avaliacao-de-tecnologias-em-saude/protocolos-clinicos-e-diretrizes-terapeuticas#O.  
- Cloroquina e hidroxicloroquina: deve ser realizado exame oftalmológico no início do tratamento e depois anualmente a critério do médico assistente que levará em consideração fatores de risco para maculopatia (dose diária de hidroxicloroquina maior que 5mg/kg ou cloroquina maior que 2,3 mg/kg de peso corporal real, tempo de uso maior que 5 anos, presença de disfunção renal, uso concomitante de tamoxifeno ou presença de doença macular). Somente o exame de fundo de olho não é suficiente para detecção precoce de maculopatia. A Academia Americana de Oftalmologia atualmente recomenda a dose de hidroxicloroquina de até 5 mg/kg/dia como mais segura a longo prazo para diminuir risco de complicações oftalmológicas. Além disto, há preferência no uso da hidroxicloroquina em relação à cloroquina pelo menor risco de maculopatia<sup>142</sup> . Quanto à eficácia no controle da atividade de doença e todos os seus demais benefícios, não há dados que corroborem o uso de doses menores e isto vai depender da avaliação do médico assistente para cada caso individualmente. Hemograma periódico é preconizado, pelo menos, a cada 3 a 6 meses. Casos de neutropenia (menos de 1.000 neutrófilos/mm<sup>3</sup> ), anemia (nível de hemoglobina inferior a 8,0 g%) ou plaquetopenia (menos de 50.000 plaquetas/mm<sup>3</sup> ) requerem a suspensão temporária do medicamento. Nestes casos, avaliar a possibilidade de atividade da doença, considerando os demais parâmetros clínicos. A dosagem de enzimas musculares (fosfocreatinoquinase-CPK e aldolase) está indicada nos casos com suspeita de miopatia. Os antimaláricos devem ser suspensos definitivamente, caso seja confirmada maculopatia, miopatia ou cardiotoxicidade.  
- Ciclofosfamida: realizar hemograma entre o 12º e 14º dia após a infusão, para verificar o nadir dos leucócitos e adequar a dose de ciclofosfamida. Em seguida, deve-se solicitar hemograma, plaquetas, creatinina, eletrólitos, análise do sedimento urinário mensalmente, citologia da urina e exame citopatológico de colo uterino anualmente. A dose deve ser reduzida em caso de alteração, a critério médico.  
- Ciclosporina: a dose deve ser ajustada conforme os níveis séricos a serem avaliados regularmente, a cada 3 a 6 meses. Deve ser feita monitorização da pressão arterial sistêmica e da função renal (creatinina) antes do início do tratamento e repetida a cada 2 semanas nos primeiros 3 meses de tratamento e, após, mensalmente se o paciente estiver clinicamente estável. Se houver desenvolvimento de hipertensão arterial sistêmica, deve ser realizada redução de 25% a 50% da dose de ciclosporina; persistindo a hipertensão após esta redução, o tratamento deve ser interrompido. Nos casos de aumento de creatinina sérica acima de 30% do valor basal, deve-se reduzir a dose ou suspender o uso de ciclosporina. A monitorização de eletrólitos, ácido úrico e creatinina deve ser feita rotineiramente e, de forma especial, naqueles pacientes com hipertensão arterial sistêmica, hiperpotassemia e hiperuricemia.  
- Danazol: deve-se avaliar as enzimas hepáticas (fosfatase alcalina e transaminases) e o perfil lipídico (colesterol total, HDL e triglicerídios) a cada 3 meses. Deve-se realizar avaliação oftalmológica de fundo de olho e, em casos com sinais ou sintomas de hipertensão intracraniana sugestivos de pseudotumor cerebral, está indicada a suspensão do medicamento. Se o tratamento for prolongado (mais de 6 meses), preconiza-se a realização de ultrassonografia hepática bianualmente. Casos com  
elevação persistente de enzimas hepáticas (elevação de pelo menos 2 a 3 vezes o LSN por, pelo menos, 3 a 6 meses) e alterações de imagem à ultrassonografia requerem a suspensão do medicamento.  
- Metotrexato: devem ser solicitadas dosagens das enzimas hepáticas (fosfatase alcalina e aminotransferases/ transaminases), hemograma, plaquetas, ureia e creatinina antes do início do tratamento e, mensalmente, nos primeiros 6 meses e, após, a cada 2 a 3 meses durante seu uso ou conforme necessidade clínica. Se houver elevação de transaminases 2 vezes acima do valor do LSN, o medicamento deve ser suspenso por 2 semanas e nova aferição de enzimas hepáticas deve ser realizada. O consumo de bebidas alcoólicas é desaconselhado ao longo do tratamento com metotrexato. Caso o paciente apresente diminuição da contagem de leucócitos (menos de 4.000/mm<sup>3</sup> ) ou de plaquetas (menos de 100.000/mm<sup>3</sup> ) ou surjam úlceras orais ou estomatite, deve-se reduzir a dose de metotrexato. Tosse e dispneia devem ser avaliadas com raio X de tórax e testes de função pulmonar em razão do potencial risco de pneumonite e o metotrexato deve ser usado com cautela em pacientes com pneumopatias. Sintomas como náusea e vômitos respondem à redução da dose, ao incremento da dose semanal de ácido fólico ou à mudança da via de administração para metotrexato injetável. Pode ser utilizado anti-emético ou o medicamento pode ser ingerido com as refeições para tentar diminuir estes sintomas.  As causas mais comuns de toxicidade aguda do metotrexato são insuficiência renal aguda e administração concomitante de sulfametoxazol + trimetoprima. A associação de ácido fólico (5 a 10 mg/semana) pode minimizar os eventos adversos.  
- Micofenolato de mofetila: preconiza-se realização de hemograma com plaquetas após 1 a 2 semanas do início do uso para avaliar toxicidade medular (anemia, leucopenia - menos de 4.000/mm<sup>3</sup> ou plaquetopenia - menos de 100.000/mm<sup>3</sup> , desde que não seja relacionada à atividade de doença). Se esta primeira avaliação não detectar alterações, este exame pode ser repetido a cada 2 a 3 meses. Em casos de alteração, a suspensão ou redução de, pelo menos, 50% da dose pode ser necessária, dependendo do grau de toxicidade. Dentre os eventos adversos, queixas gastrointestinais como náusea, diarreia e dor abdominal tem sido os mais comuns e geralmente melhoram com o passar do tempo. No entanto, em determinados casos, a dose deve ser reduzida para aliviar estas queixas. O micofenolato de mofetila reduz os níveis séricos de hormônios contraceptivos, o que pode tornar este método ineficaz. Desta forma, por se tratar de um medicamento teratogênico, outros métodos contraceptivos eficazes devem ser recomendados.  
- Talidomida: deve-se suspender o uso de talidomida e solicitar eletroneuromiografia nos casos em que houver surgimento de queixas compatíveis com neuropatia periférica. Além disso, deve-se sempre avaliar e monitorar a possibilidade de gravidez em mulheres férteis. Está indicada a realização de hemograma com plaquetas, fosfatase alcalina e transaminases a cada 3 meses. Não há necessidade de outro controle laboratorial específico na ausência de achados clínicos. O aumento de transaminases hepáticas pode ocorrer em raros casos e quando estiverem 2 vezes acima do valor do LSN, o medicamento deve ser suspenso até a normalização do exame.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **8.1. Acompanhamento pós-tratamento** -->
Inexiste uma duração de tratamento pré-determinada. O seguimento dos pacientes, incluindo consultas e exames complementares, deverá ser programado conforme a evolução clínica do caso e o monitoramento do tratamento.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Doentes de LES devem ser atendidos em serviços especializados em reumatologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **11. REFERÊNCIAS** -->
1. Gladman DD. Overview of the clinical manifestations of systemic lupus erythematosus in adults. UpToDate [Internet]. 2017  (atualizado em 25/08/2017). Acesso em 03/12/2017.  Disponível em: https://www.uptodate.com/contents/overview-ofthe-clinical-manifestations-of-systemic-lupus-erythematosus-in  
adults?source=search_result&search=Overview%20of%20the%20clinical%20manifestations%20of%20systemic%20lupus%2 0erythematosus%20in%20adults.&selectedTitle=1~150  
2. Borba EF, Brenol JCT, Latorre LC, et al. [Consensus of systemic lupus erythematosus]. Rev Bras Reum.  
2008;48(4):196-207. Portuguese.  
- 3 D'Cruz DP, Khamashta MA, Hughes GR. Systemic lupus erythematosus. Lancet. 2007 Feb 17;369(9561):587-96.  
4. Lawrence RC, Helmick CG, Arnett FC, et al. Estimates of the prevalence of arthritis and selected musculoskeletal  
disorders in the United States. Arthritis Rheum. 1998 May;41(5):778-99.  
5. Chakravarty EF, Bush TM, Manzi S, et al. Prevalence of adult systemic lupus erythematosus in California and  
Pennsylvania in 2000: estimates obtained using hospitalization data. Arthritis Rheum. 2007 Jun;56(6):2092-4.  
6. Pons-Estel GJ, Alarcon GS, Scofield L, et al. Understanding the epidemiology and progression of systemic lupus  
erythematosus. Semin Arthritis Rheum. 2010 Feb;39(4):257-68.  
7. Vilar MJ, Sato EI. Estimating the incidence of systemic lupus erythematosus in a tropical region (Natal, Brazil). Lupus.  
2002;11(8):528-32.  
8. Chogle AR, Chakravarty A. Cardiovascular events in systemic lupus erythematosus and rheumatoid arthritis : emerging  
concepts, early diagnosis and management. J Assoc Physicians India. 2007 Jan;55:32-40.  
9. Boumpas DT, Austin HA, 3rd, Fessler BJ, et al. Systemic lupus erythematosus: emerging concepts. Part 1: Renal,  
neuropsychiatric, cardiovascular, pulmonary, and hematologic disease. Ann Intern Med. 1995 Jun 15;122(12):940-50.  
10. Jonsson H, Nived O, Sturfelt G. Outcome in systemic lupus erythematosus: a prospective study of patients from a defined population. Medicine (Baltimore). 1989 May;68(3):141-50.  
11. Manzi S, Selzer F, Sutton-Tyrrell K, et al. Prevalence and risk factors of carotid plaque in women with systemic lupus erythematosus. Arthritis Rheum. 1999 Jan;42(1):51-60.  
12. Pistiner M, Wallace DJ, Nessim S, et al. Lupus erythematosus in the 1980s: a survey of 570 patients. Semin Arthritis  
Rheum. 1991 Aug;21(1):55-64.  
13. Swaak AJ, Nossent JC, Smeenk RJ. Prognostic factors in systemic lupus erythematosus. Rheumatol Int.  
1991;11(3):127-32.  
14. Cervera R, Khamashta MA, Font J, et al. Morbidity and mortality in systemic lupus erythematosus during a 10-year period: a comparison of early and late manifestations in a cohort of 1,000 patients. Medicine (Baltimore). 2003 Sep;82(5):299308.  
15. Cronin ME. Musculoskeletal manifestations of systemic lupus erythematosus. Rheum Dis Clin North Am. 1988  
Apr;14(1):99-116.  
16. Lee C, Almagor O, Dunlop DD, et al. Self-reported fractures and associated factors in women with systemic lupus erythematosus. J Rheumatol. 2007 Oct;34(10):2018-23.  
17. Ruiz-Irastorza G, Egurbide MV, Olivares N, et al. Vitamin D deficiency in systemic lupus erythematosus:  
prevalence, predictors and clinical consequences. Rheumatology (Oxford). 2008 Jun;47(6):920-3.  
18. Merola JF, Moschella SL.  Overview of cutaneous lupus erythematosus. UpToDate [Internet]. 2017, atualizado em  
24/07/2017 [Acesso em 03/12/2017]; Available from: <u>https://www.uptodate.com/contents/overview-of-cutaneous-lupuserythematosus?source=search_result&search=Mucocutaneous%20manifestations%20of%20systemic%20lupus%20erythemato sus.&selectedTitle=4~150</u>  
19. Moder KG, Miller TD, Tazelaar HD. Cardiac involvement in systemic lupus erythematosus. Mayo Clin Proc. 1999  
Mar;74(3):275-84.  
20. Roldan CA, Shively BK, Crawford MH. An echocardiographic study of valvular heart disease associated with  
systemic lupus erythematosus. N Engl J Med. 1996 Nov 7;335(19):1424-30.  
21. Khamashta MA. Management of thrombosis in the antiphospholipid syndrome. Lupus. 1996 Oct;5(5):463-6.  
22. Mucenic T, Brenol JC, Bredemeier M, et al. Glu298Asp eNOS polymorphism is not associated with SLE. Lupus.  
2009 Apr;18(5):448-51.  
23. Orens JB, Martinez FJ, Lynch JP, 3rd. Pleuropulmonary manifestations of systemic lupus erythematosus. Rheum  
Dis Clin North Am. 1994 Feb;20(1):159-93.  
24. Badsha H, Teh CL, Kong KO, et al. Pulmonary hemorrhage in systemic lupus erythematosus. Semin Arthritis  
Rheum. 2004 Jun;33(6):414-21.  
25. Karim MY, Miranda LC, Tench CM, et al. Presentation and prognosis of the shrinking lung syndrome in systemic  
lupus erythematosus. Semin Arthritis Rheum. 2002 Apr;31(5):289-98.  
26. The American College of Rheumatology nomenclature and case definitions for neuropsychiatric lupus syndromes.  
Arthritis Rheum. 1999 Apr;42(4):599-608.  
27.  Hanly, J. G. Diagnosis and management of neuropsychiatric SLE. Nat. Rev. Rheumatol. Jun;10(6):338-47.  
28.  Magro-Checa C, Zirkzee EJ, Huizinga TW, Steup-Beekman GM. Management of Neuropsychiatric Systemic Lupus  
Erythematosus: Current Approaches and Future Perspectives. Drugs. 2016 Mar;76(4):459-  
29. Barr SG, Zonana-Nacach A, Magder LS, et al. Patterns of disease activity in systemic lupus erythematosus. Arthritis  
Rheum. 1999 Dec;42(12):2682-8.  
30. Chambers SA, Allen E, Rahman A, et al. Damage and mortality in a group of British patients with systemic lupus  
erythematosus followed up for over 10 years. Rheumatology (Oxford). 2009 Jun;48(6):673-5.  
31. Zonana-Nacach A, Barr SG, Magder LS, et al. Damage in systemic lupus erythematosus and its association with  
corticosteroids. Arthritis Rheum. 2000 Aug;43(8):1801-8.  
32. Gladman DD, Urowitz MB, Rahman P, et al. Accrual of organ damage over time in patients with systemic lupus  
erythematosus. J Rheumatol. 2003 Sep;30(9):1955-9  
33. Tan EM, Cohen AS, Fries JF, et al. The 1982 revised criteria for the classification of systemic lupus erythematosus.  
Arthritis Rheum. 1982 Nov;25(11):1271-7.  
34. Hochberg MC. Updating the American College of Rheumatology revised criteria for the classification of systemic  
lupus erythematosus. Arthritis Rheum. 1997 Sep;40(9):1725.  
35. Dellavance A, Gabriel Júnior A, Nuccitelli B, et al. [Third Brazilian Consensus for autoantibodies screening in HEp-  
2 cells (ANA): recommendations for standardization of autoantibodies screening trial in HEp-2 cells, quality control and clinical associations]. Rev Bras Reumatol. 2009;49(2):89-98. Portuguese.  
36. Petri M, Orbai AM, Alarcon GS, Gordon C, Merrill JT, Fortin PR, et al. Derivation and validation of the systemic  
lupus international collaborating clinics classification criteria for systemic lupus erythematosus. Arthritis Rheum. 2012;64(8):2677–86.  
37. Gordon C. Amissah-Arthur M-B, et al. The British Society for Rheumatology guideline for the management of  
systemic lupus erythematosus in adults. Rheumatology, 2017 (doi:10.1093/rheumatology/kex286.  
38. Aringer M, Costenbader K, Daikh D, et al. 2019 European League Against Rheumatism/American College of  
Rheumatology classification criteria for systemic lupus erythematosus. Annals of the Rheumatic Diseases 2019;78:1151-1159.  
39. Dörner T, Furie R. Novel paradigms in systemic lupus erythematosus. Lancet, 2019; 393: 2344-58  
40. Tedeschi SK, Johnson SR, Boumpas DT, et al. Multicriteria decision analysis process to develop new classification  
criteria for systemic lupus erythematosus. Annals of the Rheumatic Diseases 2019;78:634-640.  
41. Leuchten N, Hoyer A, Brinks R, et al. Perfomance of antinuclear antibodies for classifying systemic lupus  
erythematosus: a systematic literature review and meta-regression of diagnostic data. Arthritis Care & Research; 2018;70:428438.  
42. Griffiths B, Mosca M, Gordon C. Assessment of patients with systemic lupus erythematosus and the use of lupus  
disease activity indices. Best Pract Res Clin Rheumatol. 2005 Oct;19(5):685-708.  
43. Bombardier C, Gladman DD, Urowitz MB, et al. Derivation of the SLEDAI. A disease activity index for lupus  
patients. The Committee on Prognosis Studies in SLE. Arthritis Rheum. 1992 Jun;35(6):630-40.  
44. Petri M, Genovese M, Engle E, et al. Definition, incidence, and clinical description of flare in systemic lupus  
erythematosus. A prospective cohort study. Arthritis Rheum. 1991 Aug;34(8):937-44.  
45. Liang MH, Socher SA, Larson MG, et al. Reliability and validity of six systems for the clinical assessment of disease  
activity in systemic lupus erythematosus. Arthritis Rheum. 1989 Sep;32(9):1107-18.  
46. Symmons DP, Coppock JS, Bacon PA, et al. Development and assessment of a computerized index of clinical disease  
activity in systemic lupus erythematosus. Members of the British Isles Lupus Assessment Group (BILAG). Q J Med. 1988 Nov;69(259):927-37.  
47. Cook RJ, Gladman DD, Pericak D, et al. Prediction of short term mortality in systemic lupus erythematosus with  
time dependent measures of disease activity. J Rheumatol. 2000 Aug;27(8):1892-5.  
48. Petri M, Kim MY, Kalunian KC, et al. Combined oral contraceptives in women with systemic lupus erythematosus.  
N Engl J Med. 2005 Dec 15;353(24):2550-8.  
49. Furie RA, Petri MA, Wallace DJ, et al. Novel evidence-based systemic lupus erythematosus responder index.  
Arthritis Rheum. 2009 Sep 15;61(9):1143-51.  
50. Gladman D, Ginzler E, Goldsmith C, et al. The development and initial validation of the Systemic Lupus  
International Collaborating Clinics/American College of Rheumatology damage index for systemic lupus erythematosus. Arthritis Rheum. 1996 Mar;39(3):363-9.  
51. Rubin RL. Drug-induced lupus. In: Wallace DJ, Hahn BH, editors. Dubois' Lupus Erythematosus. 7th ed.  
Philadelphia, PA: Lippincott Williams & Wilkens; 2007: p. 870-900.  
52. Karpouzas GA, Kitridou RC. The mother in systemic lupus erythematosus. In: Wallace DJ, Hahn BH, editors.  
Dubois'Lupus Erythematosus. 7th ed. Philadelpia, PA: Lippincott Williams & Wilkins; 2007: p. 992-1038.  
53. Skorpen CG, et al. The EULAR points to consider for use of antirheumatic drugs before pregnancy, and during  
pregnancy and lactation. Ann Rheum Dis 2016;75:795–810.  
54. Bermas BL. Safety of antiinflammatory and immunosuppressive drugs in rheumatic diseases during pregnancy and lactation. UpToDate 2017 (acesso em 03/12/2017) Atualizado em 13/11/2017. Disponível em <u>https://www.uptodate.com/contents/safety-of-antiinflammatory-and-immunosuppressive-drugs-in-rheumatic-diseases-duringpregnancy-and-</u>  
<u>lactation?source=search_result&search=Safety%20of%20antiinflammatory%20and%20immunosuppressive%20drugs%20in% 20rheumatic%20diseases%20during%20pregnancy%20and%20lactation&selectedTitle=1~150</u>  
55.  Saavedra Salinas MÁ, Barrera Cruz A, Cabral Castañeda AR et al. Clinical practice guidelines for the management of pregnancy in women with autoimmune rheumatic diseases of the Mexican College of Rheumatology. Part II. Reumatol Clin. 2015;11(5):305–315.)  
56. Buyon JP, Clancy RM. Neonatal Lupus. In: Wallace DJ, Hahn BH, editors. Dubois’ Lupus Erythematosus. 7th ed. Philadelphia, PA: Lippincott Williams & Wilkins; 2006: p. 1058-80.  
57.  Saavedra Salinas MÁ, Barrera Cruz A, Cabral Castañeda AR et al. Clinical practice guidelines for the management  
of pregnancy in women with autoimmune rheumatic diseases of the Mexican College of Rheumatology. Part I. Reumatol Clin. 2015 Sep-Oct;11(5):295-304.  
58.  Phoon CK, Kim MY, Buyon JP, Friedman DM. Finding the "PR-fect" solution: what is the best tool to measure fetal cardiac PR intervals for the detection and possible treatment of early conduction disease? <u><mark>Congenit Heart Dis. 2012 Jul-</mark></u> <mark>Aug;7(4):349-60.</mark>  
59.  Saxena A, Izmirly, PM, Mendez B, Buyon JP, Friedman, DM. Prevention and Treatment In Utero of Autoimmune-  
Associated Congenital Heart Block. Cardiology in Review, 2014:  22(6), 263–267.  
60. Izmirly P, Saxena A, Buyon JP. Progress in the pathogenesis and treatment of cardiac manifestations of neonatal  
lupus. Curr Opin Rheumatol. 2017 Sep;29(5):467-472.  
61. Mosca M, Boumpas DT, Bruce IN, et al. Treat-to-target in systemic lupus erythematosus: where are we today? Clin  
Exp Rheumatol. 2012 Jul-Aug;30(4 Suppl 73):S112-5.  
62.  del Pino-Sedeño T, Trujillo-Martín MM, Ruiz-Irastorza G, Cuellar-Pompa L, de Pascual-Medina AM, SerranoAguilar P. Spanish Systemic Lupus Erythematosus CPG Development Group Effectiveness of Nonpharmacologic Interventions for Decreasing Fatigue in Adults With Systemic Lupus Erythematosus: A Systematic Review.Arthritis Care Res (Hoboken). 2016 Jan;68(1):141-8.  
63.  Wu ML, Yu KH, Tsai JC. The Effectiveness of Exercise in Adults With Systemic Lupus Erythematosus: A Systematic Review and Meta-Analysis to Guide Evidence-Based Practice. Worldviews Evid Based Nurs. 2017 Aug;14(4):306315.  
64. Barber C, Gold WL, Fortin PR. Infections in the lupus patient: perspectives on prevention. Curr Opin Rheumatol.  
2011 Jul;23(4):358-65.  
65. Mosca M, Tani C, Aringer M, et al. European League Against Rheumatism recommendations for monitoring patients with systemic lupus erythematosus in clinical practice and in observational studies. Ann Rheum Dis. 2010 Jul;69(7):1269-74.  
66. Consenso Brasileiro para Tratamento da Nefrite Lúpica - Rev Bras Reumatol. 2015 Jan-Feb;55(1):1-21..  
67.  Andrades C, Fuego C, Manrique-Arija S, & Fernández-Nebro A. Management of cardiovascular risk in systemic  
lupus erythematosus: a systematic review. Lupus, (2017) 26(13), 1407–1419.  
68.  Liao Z, Tang H, Xu X, Liang Y, Xiong Y, Ni J. Immunogenicity and Safety of Influenza Vaccination in Systemic  
Lupus Erythematosus Patients Compared with Healthy Controls: A Meta-Analysis. PLoS One. 2016 Feb 4;11(2) e0147856  
69. The Canadian Hydroxychloroquine Study Group. A randomized study of the effect of withdrawing hydroxychloroquine sulfate in systemic lupus erythematosus. N Engl J Med. 1991 Jan 17;324(3):150-4.  
70. Tsakonas E, Joseph L, Esdaile JM, et al. A long-term study of hydroxychloroquine withdrawal on exacerbations in  
systemic lupus erythematosus. The Canadian Hydroxychloroquine Study Group. Lupus. 1998;7(2):80-5.  
71. Meinao IM, Sato EI, Andrade LE, et al. Controlled trial with chloroquine diphosphate in systemic lupus  
erythematosus. Lupus. 1996 Jun;5(3):237-41.  
72. Carneiro JR, Sato EI. Double blind, randomized, placebo controlled clinical trial of methotrexate in systemic lupus  
erythematosus. J Rheumatol. 1999 Jun;26(6):1275-9.  
73. McCune WJ, Marder ME, Riskalla M. Immunosuppressive drug therapy. Dubois' Lupus Erythematosus. 7th ed;  
2007. p. 1198-1224.  
74.  PORTARIA Nº 19, DE 10 JULHO DE 2018. Torna pública a decisão de não incorporar o belimumabe para lúpus  
eritematoso sistêmico no âmbito do Sistema Único de Saúde - SUS. Relatório de recomendação n° 344 de Julho/2018. Belimumabe paralúpus eritematoso sistêmico. Disponível em: <u>http://conitec.gov.br/images/Relatorios/2018/Recomendacao/Belimumabe_Lupus_eritematoso_sistemico_344_2017.pdf</u>  
75.  Harvey PR, Gordon C. B-cell targeted therapies in systemic lupus erythematosus: successes and challenges.  
BioDrugs. 2013 Apr;27(2):85-95.  
76. <mark>Cobo-Ibáñez T, Loza-Santamaría E, Pego-Reigosa JM, et al. Efficacy and safety of rituximab in the treatment of</mark>  
<mark>non-renal systemic lupus erythematosus: a systematic review. Semin Arthritis Rheum. 2014;44(2):175</mark>  
77. Rydén-Aulin M, Boumpas D, Bultink I, et al. Off-label use of rituximab for systemic lupus erythematosus in  
Europe. Lupus Science & Medicine 2016;3:e000163.  
78. <u><mark>Borba HH, Wiens A, de Souza TT, Correr CJ, Pontarolo R. E</mark></u> fficacy and safety of biologic therapies for systemic  
lupus erythematosus treatment: Systematic review and meta-analysis. BioDrugs. 2014 Apr;28(2):211-28  
79. Wozniacka A, McCauliffe DP. Optimal use of antimalarials in treating cutaneous lupus erythematosus. Am J Clin  
Dermatol. 2005;6(1):1-11.  
80.  Herzinger T, Plewig G, Röcken M. Use of sunscreens to protect against ultraviolet-induced lupus erythematosus.  
Arthritis Rheum. 2004 Sep;50(9):3045-6.  
81.  Kreuter A, Lehmann P. Relevant new insights into the effects of photoprotection in cutaneous lupus erythematosus.  
Exp Dermatol. 2014 Oct;23(10):712-3. doi: 10.1111/exd.12466.  
82.  Patsinakidis N, Wenzel J, Landmann A, Koch R, Gerß J, Luger TA, Metze D, Surber C, Kuhn A. Suppression of  
UV-induced damage by a liposomal sunscreen: a prospective, open-label study in patients with cutaneous lupus erythematosus and healthy controls. Exp Dermatol. 2012 Dec;21(12):958-61.  
83.  Kuhn A, Gensch K, Haust M, Meuth AM, Boyer F, Dupuy P, Lehmann P, Metze D,Ruzicka T. Photoprotective  
effects of a broad-spectrum sunscreen in ultraviolet-induced cutaneous lupus erythematosus: a randomized,vehicle-controlled, double-blind study. J Am Acad Dermatol. 2011 Jan;64(1):37-48.  
84.  Kuhn A, Ruland V, Bonsmann G. Photosensitivity, phototesting, and photoprotection in cutaneous lupus  
erythematosus. Lupus. 2010 Aug;19(9):1036-46.  
85.  Sanders CJ, Van Weelden H, Kazzaz GA, Sigurdsson V, Toonstra J, Bruijnzeel-Koomen CA. Photosensitivity in  
patients with lupus erythematosus: a clinical and photobiological study of 100 patients using a prolonged phototest protocol. Br J Dermatol. 2003 Jul;149(1):131-7.  
86.  Zahn S, Graef M, Patsinakidis N, Landmann A, Surber C, Wenzel J, Kuhn A. Ultraviolet light protection by a  
sunscreen prevents interferon-driven skin inflammation in cutaneous lupus erythematosus. Exp Dermatol. 2014 Jul;23(7):5168.  
87. Jessop S, Whitelaw DA, Delamere FM. Drugs for discoid lupus erythematosus. Cochrane Database Syst Rev. 2009  
(4):CD002954.  
88. Jessops S, et al. Drugs for discoid lupus erythematosus. Cochrane Database Syst Rev. 2017 May 5;5:CD002954.  
89. Drake LA, Dinehart SM, Farmer ER, et al. Guidelines of care for cutaneous lupus erythematosus. American Academy of Dermatology. J Am Acad Dermatol. 1996 May;34(5 Pt 1):830-6.  
90. Atra E, Sato EI. Treatment of the cutaneous lesions of systemic lupus erythematosus with thalidomide. Clin Exp  
Rheumatol. 1993 Sep-Oct;11(5):487-93.  
91. Coelho A, Souto MI, Cardoso CR, et al. Long-term thalidomide use in refractory cutaneous lesions of lupus  
erythematosus: a 65 series of Brazilian patients. Lupus. 2005;14(6):434-9.  
92. Cuadrado MJ, Karim Y, Sanna G, et al. Thalidomide for the treatment of resistant cutaneous lupus: efficacy and safety  
of different therapeutic regimens. Am J Med. 2005 Mar;118(3):246-50.  
93. Doherty SD, Hsu S. A case series of 48 patients treated with thalidomide. J Drugs Dermatol. 2008 Aug;7(8):769-73.  
94. Hasper MF, Klokke AH. Thalidomide in the treatment of chronic discoid lupus erythematosus. Acta Derm Venereol.  
1982;62(4):321-4.  
95. Housman TS, Jorizzo JL, McCarty MA, et al. Low-dose thalidomide therapy for refractory cutaneous lesions of  
lupus erythematosus. Arch Dermatol. 2003 Jan;139(1):50-4.  
96. Knop J, Bonsmann G, Happle R, et al. Thalidomide in the treatment of sixty cases of chronic discoid lupus  
erythematosus. Br J Dermatol. 1983 Apr;108(4):461-6.  
97. Kyriakis KP, Kontochristopoulos GJ, Panteleos DN. Experience with low-dose thalidomide therapy in chronic  
discoid lupus erythematosus. Int J Dermatol. 2000 Mar;39(3):218-22.  
98. Lyakhovisky A, Baum S, Shpiro D, et al. [Thalidomide therapy for discoid lupus erythematosus]. Harefuah. 2006  
Jul;145(7):489-92, 551.  
99. Ordi-Ros J, Cortes F, Cucurull E, et al. Thalidomide in the treatment of cutaneous lupus refractory to conventional  
therapy. J Rheumatol. 2000 Jun;27(6):1429-33.  
100. Sato EI, Assis LS, Lourenzi VP, et al. Long-term thalidomide use in refractory cutaneous lesions of systemic lupus  
erythematosus. Rev Assoc Med Bras. 1998 Oct-Dec;44(4):289-93.  
101. Stevens RJ, Andujar C, Edwards CJ, et al. Thalidomide in the treatment of the cutaneous manifestations of lupus  
erythematosus: experience in sixteen consecutive patients. Br J Rheumatol. 1997 Mar;36(3):353-9.  
102. Williams HJ, Egger MJ, Singer JZ, et al. Comparison of hydroxychloroquine and placebo in the treatment of the  
arthropathy of mild systemic lupus erythematosus. J Rheumatol. 1994 Aug;21(8):1457-62.  
103. Rahman P, Humphrey-Murto S, Gladman DD, et al. Efficacy and tolerability of methotrexate in antimalarial  
resistant lupus arthritis. J Rheumatol. 1998 Feb;25(2):243-6.  
104. Sakthiswary R, Suresh E. Methotrexate in systemic lupus erythematosus: a systematic review of its efficacy. Lupus  
2014;23:225_35.  
105. Hermosillo-Romo D, Brey RL. Diagnosis and management of patients with neuropsychiatric systemic lupus  
erythematosus (NPSLE). Best Pract Res Clin Rheumatol. 2002 Apr;16(2):229-44.  
106. Gold R, Fontana A, Zierz S. Therapy of neurological disorders in systemic vasculitis. Semin Neurol. 2003  
Jun;23(2):207-14.  
107. Fernandes Moça Trevisani V, et al. Cyclophosphamide versus methylprednisolone for treating neuropsychiatric  
involvement in systemic lupus erythematosus. Cochrane Database Syst Rev. 2013 Feb 28;(2):CD002265.  
108. Boumpas DT, Yamada H, Patronas NJ, et al. Pulse cyclophosphamide for severe neuropsychiatric lupus. Q J Med.  
1991 Dec;81(296):975-84.  
109. Barile-Fabris L, Ariza-Andraca R, Olguin-Ortega L, et al. Controlled clinical trial of IV cyclophosphamide versus IV methylprednisolone in severe neurological manifestations in systemic lupus erythematosus. Ann Rheum Dis. 2005 Apr;64(4):620-5.  
110. Bansal VK, Beto JA. Treatment of lupus nephritis: a meta-analysis of clinical trials. Am J Kidney Dis. 1997  
Feb;29(2):193-9.  
111. Ginzler EM. Clinical trials in lupus nephritis. Curr Rheumatol Rep. 2001 Jun;3(3):199-204.  
112. Hejaili FF, Moist LM, Clark WF. Treatment of lupus nephritis. Drugs. 2003;63(3):257-74.  
113. Fessler BJ, Boumpas DT. Severe major organ involvement in systemic lupus erythematosus. Diagnosis and management. Rheum Dis Clin North Am. 1995 Feb;21(1):81-98.  
114. Kimberly RP, Lockshin MD, Sherman RL, et al. High-dose intravenous methylprednisolone pulse therapy in systemic lupus erythematosus. Am J Med. 1981 Apr;70(4):817-24.  
115. Bertsias, G.K., et al., Joint European League Against Rheumatism and European Renal Association-European Dialysis and Transplant Association EULAR/ERA-EDTA) recommendations for the management of adult and paediatric lupus nephritis. Ann Rheum Dis, 2012. 71(11): p. 1771-82.  
116. Houssiau FA, Vasconcelos C, D'Cruz D, et al. Immunosuppressive therapy in lupus nephritis: the Euro-Lupus Nephritis Trial, a randomized trial of low-dose versus high-dose intravenous cyclophosphamide. Arthritis Rheum. 2002 Aug;46(8):2121-31.  
117. Balow JE. Choosing treatment for proliferative lupus nephritis. Arthritis Rheum. 2002 Aug;46(8):1981-3.  
118. D'Cruz D, Cuadrado MJ, Mujic F, et al. Immunosuppressive therapy in lupus nephritis. Clin Exp Rheumatol. 1997  
May-Jun;15(3):275-82.  
119. Illei GG, Austin HA, Crane M, et al. Combination therapy with pulse cyclophosphamide plus pulse methylprednisolone improves long-term renal outcome without adding toxicity in patients with lupus nephritis. Ann Intern Med. 2001 Aug 21;135(4):248-57.  
120. Yee CS, Gordon C, Dostal C, et al. EULAR randomised controlled trial of pulse cyclophosphamide and methylprednisolone versus continuous cyclophosphamide and prednisolone followed by azathioprine and prednisolone in lupus nephritis. Ann Rheum Dis. 2004 May;63(5):525-9.  
121.  Henderson L, Masson P, Craig JC, Flanc RS, Roberts MA, Strippoli GF, Webster AC.Treatment for lupus nephritis. Cochrane Database Syst Rev. 2012 Dec 12;12  
122. Hahn, B.H., et al., American College of Rheumatology guidelines for screening, treatment, and management of lupus nephritis. Arthritis Care Res (Hoboken), 2012. 64(6): p. 797-808.  
123.  Klumb, E.M., et al., [Consensus of the Brazilian Society of Rheumatology for the diagnosis, management and treatment of lupus nephritis]. Rev Bras Reumatol, 2015. 55(1): p. 1-21.  
124. Pego-Reigosa JM, Cobo-Iba´ n˜ ez T, Calvo-Ale´n J et al. Efficacy and safety of nonbiologic immunosuppressants in the treatment of nonrenal systemic lupus erythematosus: a systematic review. Arthritis Care Res 2013;65:1775_85.  
125.  Brasil. Relatório de Recomendação nº 358/2018. Comissão Nacional de incorporação de Tecnologias no SUS : Micofenolato de mofetila e micofenolato de sódio para nefrite lúpica. 2018.  
126.  Deng J, Huo D, Wu Q, Yang Z, Liao Y.. A meta-analysis of randomized controlled trials comparing tacrolimus with  
intravenous cyclophosphamide in the induction treatment for lupus nephritis.Tohoku J Exp Med. 2012 Aug;227(4):281-8.  
127.  Hannah J, Casian A, D'Cruz D. Tacrolimus use in lupus nephritis: A systematic review and meta-analysis.  
Autoimmun Rev. 2016 Jan;15(1):93-101.  
128.  Zhang X, Ji L, Yang L, Tang X, Qin W. The effect of calcineurin inhibitors in the induction and maintenance treatment of lupus nephritis: a systematic review and meta-analysis.Int Urol Nephrol. 2016 May;48(5):731-43.  
129.  Chen Y, Sun J, Zou K, Yang Y, Liu G. Treatment for lupus nephritis: an overview of systematic reviews and metaanalyses. Rheumatol Int. 2017 Jul;37(7):1089-1099.  
130. Gomard-Mennesson E, Ruivard M, Koenig M, et al. Treatment of isolated severe immune hemolytic anaemia  
associated with systemic lupus erythematosus: 26 cases. Lupus. 2006;15(4):223-31.  
131. Jacob HS. Pulse steroids in hematologic diseases. Hosp Pract (Off Ed). 1985 Aug 15;20(8):87-94.  
132. Wang XT, Lam VM, Engel PC. Marked decrease in specific activity contributes to disease phenotype in two human  
glucose 6-phosphate dehydrogenase mutants, G6PD(Union) and G6PD(Andalus). Hum Mutat. 2005 Sep;26(3):284.  
133. Cervera H, Jara LJ, Pizarro S, et al. Danazol for systemic lupus erythematosus with refractory autoimmune  
thrombocytopenia or Evans' syndrome. J Rheumatol. 1995 Oct;22(10):1867-71.  
134. Roach BA, Hutchinson GJ. Treatment of refractory, systemic lupus erythematosus-associated thrombocytopenia  
with intermittent low-dose intravenous cyclophosphamide. Arthritis Rheum. 1993 May;36(5):682-4.  
135. Arnal C, Piette JC, Leone J, et al. Treatment of severe immune thrombocytopenia associated with systemic lupus  
erythematosus: 59 cases. J Rheumatol. 2002 Jan;29(1):75-83.  
136. Goebel KM, Gassel WD, Goebel FD. Evaluation of azathioprine in autoimmune thrombocytopenia and lupus  
erythematosus. Scand J Haematol. 1973;10(1):28-34.  
137. Quartuccio L, Sacco S, Franzolini N, et al. Efficacy of cyclosporin-A in the long-term management of  
thrombocytopenia associated with systemic lupus erythematosus. Lupus. 2006;15(2):76-9.  
138. Maksimowicz-Mckinnon K, Manzi S. Cardiovascular Manifestation of Lupus. Dubois' Lupus Erythematosus.  
2007;Seventh Edition:663-77.  
139. D'Cruz D, Khamashta MA, Hughes G. Pulmonary Manifestations of Systemic Lupus Erythematosus. In: Wallace  
DJ, Hahn BH, editors. Dubois' Lupus Erythematosus. 7th ed. Philadelphia, PA: Lippincott Williams & Wilkins; 2007: p. 67899.  
140. Kirou KA, Boumpas DT. Systemic glucocorticoid therapy in systemic lupus erythematosus. Dubois' Lupus  
Erythematosus. 2007;Senventh Edition:1175-97.  
141.  Zhou KY, Hua YM. Autoimmune-associated Congenital Heart Block: A New Insight in Fetal Life. Chin Med J  
(Engl). 2017 Dec 5;130(23):2863-2871.  
142.  Marmor MF, Kellner U, Lai TY, Melles RB, Mieler WF; American Academy of Ophthalmology.Recommendations  
on Screening for Chloroquine and Hydroxychloroquine Retinopathy (2016 Revision).Ophthalmology. 2016 Jun;123(6):138694.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER** -->
AZATIOPRINA, BETAMETASONA, CICLOFOSFAMIDA, CICLOSPORINA, CLOROQUINA, DANAZOL, DEXAMETASONA, HIDROXICLOROQUINA, METILPREDNISOLONA, METOTREXATO, MICOFENOLATO DE MOFETILA, PREDNISONA E TALIDOMIDA.  
Eu,_________________________________________________________________________________________  
(nome do[a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de azatioprina, betametasona, ciclofosfamida, ciclosporina, cloroquina, danazol, dexametasona, hidroxicloroquina, metilprednisolona, metotrexato, micofenolato de mofetila, prednisona e talidomida, indicada para o tratamento de lúpus eritematoso sistêmico.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico (a)  
____________________________________________________________________________________________________  
(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- controle da doença;  
- melhora dos sintomas;  
- prevenção de complicações  da doença.  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- prednisona: medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- cloroquina, hidroxicloroquina, ciclosporina, dexametasona, betametasona e metilprednisolona: medicamentos classificados na gestação como fator de risco C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior que os riscos);  
- azatioprina e micofenolato de mofetila: medicamento classificado na gestação como fator de risco D (há evidências de riscos ao feto, mas um benefício potencial pode ser maior que os riscos);  
- ciclofosfamida, danazol, metotrexato e talidomida: medicamentos classificados na gestação como fator de risco X (seu uso é contraindicado para gestantes ou mulheres planejando engravidar);  
- dexametasona/metilprednisolona/prednisona: retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabetes melito;  
- betametasona: insônia, aumento do apetite, aumento do risco de infecções;  
- cloroquina e hidroxicloroquina: principais eventos adversos são usualmente relacionadas com a dose e o tempo de tratamento; problemas nos olhos, como visão borrada, ou qualquer alteração na visão, diminuição das células brancas e vermelhas do sangue, alterações emocionais, problemas para escutar, convulsões, problemas no coração, problemas nos músculos dos cílios, causando dificuldade para ler, diarreia, perda de apetite, náusea, dor no estômago, vômito, dor de cabeça, coceira, descoloração e queda de cabelo, descoloração da pele, das unhas ou no interior na boca, tontura, nervosismo, inquietação, vermelhidão, problemas de pele;  
- azatioprina: diminuição das células brancas (células de defesa), vermelhas e plaquetas do sangue, aumento do risco de infecções por vírus, fungos e bactérias, anemia, problemas no fígado náusea, vômitos, diarreia, dor abdominal, fezes com sangue, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar, pressão baixa;  
- ciclofosfamida: diminuição das células brancas e aumento do risco de infecções, fraqueza, náusea, vômito, perda de apetite, diarreia, estomatite, infecções da bexiga, sangramento por inflamação da bexiga, problemas nos rins, no coração, pulmão, queda de cabelos, aumento do risco de desenvolver cânceres, infertilidade, reativação de tuberculose, vermelhidão na face, dor de cabeça, erupção na pele, alteração do sódio no sangue, congestão nasal, lacrimejamento, corrimento nasal, congestão dos seios da face e espirros;  
- ciclosporina: problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, aumento do crescimento da gengiva, aumento do colesterol e triglicerídios, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada a temperatura, aumento das mamas;  
- danazol: eventos adversos mais comuns incluem náusea, vômitos, diarreia, dor de cabeça, nervosismo, desorientação, fraqueza, convulsões, ganho de peso, inchaço, alterações do paladar, aumento da pressão arterial, perda de potássio, insuficiência cardíaca congestiva;  
- metotrexato: pode causar problemas gastrointestinais com ou sem sangramento, diminuição do número de glóbulos brancos no sangue, diminuição do número de plaquetas, aumento da sensibilidade da pele aos raios ultravioleta, feridas na boca, inflamação nas gengivas, inflamação na garganta, espinhas, perda do apetite, náusea, palidez, coceira , vômitos; mais raramente e dependendo da dose utilizada, podem ocorrer cansaço associado à formação de bolhas e com perda de regiões da pele e de mucosas (síndrome de Stevens-Johnson e necrólise epidérmica tóxica) e problemas graves de pele; também pode facilitar o estabelecimento ou agravar infecções;  
- micofenolato de mofetila: diarreia, vômito, dispepsia, diminuição das célulasno sangue, anemia, infecção generalizada e outros tipos de infecção, incluindo doença pelo citomegalovírus, candidíase e herpes zoster;  
- talidomida: evento adverso mais importante é a teratogenicidade, ou seja, causa graves defeitos no corpo dos bebês de mulheres que o utilizam na gravidez; também causa sono e problemas nos nervos das extremidades; em casos mais raros, pode causar tremor, fraqueza, tonturas, alterações do humor, prisão de ventre, boca seca, aumento do apetite, inchaço, náusea, problemas na menstruação.  
Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (  ) azatioprina  
- (  ) betametasona  
- (  ) ciclofosfamida  
- (  ) ciclosporina  
- (  ) cloroquina  
- (  ) danazol  
- (  ) dexametasona  
- (  ) hidroxicloroquina  
- (  ) metilprednisolona  
- (  ) metotrexato  
- (  ) micofenolato de mofetila  
- (  ) prednisona  
- (  ) talidomida  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
**Nota 1:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**Nota 2** - Para dispensação da talidomida, devem ser exigidos os termos específicos conforme o RDC n° 11/Anvisa, de 22 de março de 2011.  
**Nota 3** - A administração endovenosa de metilprednisolona e de ciclofosfamida é compatível, respectivamente, com os procedimentos 03.03.02.001-6 - Pulsoterapia I (por aplicação) e 03.03.02.002-4 - Pulsoterapia II (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **APÊNDICE 1** -->
SLEDAI ( _Systemic Lupus Erythematosus Disease Activity Index_ )  
|**Escore**|**Item**|
|---|---|
|8<br>8|Convulsão – início recente, excluir outras causas, tais como distúrbios metabólicos, infecções ou medicamentos.<br>Psicose – distúrbio na percepção da realidade, incluindo alucinações, delírios, incoerências, perda de associações,<br>pensamento não lógico, comportamento bizarro, desorganizado ou catatônico. Excluir outras causas, tais como<br>uremia ou medicações|
||Síndrome cerebral orgânica – alteração da função mental, com prejuízo na orientação, memória ou outras funções|
|8|intelectuais, com rápido surgimento e flutuações, incapacidade de sustentar a atenção, somado a pelo menos dois<br>dos seguintes achados: distúrbio da percepção, diálogo incoerente, insônia, sonolência e aumento ou diminuição<br>da atividade psicomotora. Excluir outras causas, tais como distúrbios metabólicos, infecções ou medicamentos|
|8|Visual – alterações no fundo do olho, como corpos citoides, hemorragias retinianas, exsudatos ou hemorragias<br>na coroide ou nervo óptico. Excluir outras causas, tais como hipertensão, infecções ou medicamentos.|
|8|Nervos cranianos – surgimento de neuropatia sensitiva ou motora dos nervos cranianos.|
|8|Cefaleia lúpica – persistente e grave, enxaquecosa, com pouca resposta a analgésicos opioides.|
|8|AVC – evento de início recente e não relacionado com aterosclerose ou hipertensão.|
|8|Vasculite – ulceração, gangrena, nódulo, infarto periungueal, hemorragias puntiformes, biópsia ou arteriografia<br>compatíveis com vasculite.|
|4|Artrite – duas articulações ou mais com sinais flogísticos.|
|4|Miosite – fraqueza ou dor muscular proximal com elevação de creatinofosfoquinase ou aldolase, ou<br>eletroneuromiografia compatível com miosite ou biópsia com infiltrado inflamatório em fibra muscular.|
|4|Cilindros – hemáticos ou granulosos.|
|4|Hematúria – mais de 5 hemácias/campo de grande aumento. Excluir cálculos, infecções ou outras causas.|
|4|Proteinúria – acima de 0,5 g/24h.|
|4|Piúria – mais de 5 leucócitos/campo de grande aumento. Excluir infecção.|
|2|_Rash_malar novo.|
|2|Alopecia – perda de cabelo anormal, difusa ou localizada.|
|2|Membranas mucosas – ulcerações nasais ou orais.|
|2|Pleurite – dor pleurítica com atrito pleural, ou derrame pleural ou espessamento pleural.|
|2|Pericardite – dor compatível com pericardite somada a pelo um dos seguintes achados: atrito pericárdico, derrame<br>pericárdico, eletrocardiograma ou ecocardiograma compatíveis com pericardite.|
|2|Baixos complementos – diminuição do CH50, C3 ou C4 abaixo do limite da normalidade, de acordo com os<br>valores de referência do exame.|
|2|Anti-DNA nativo – aumento acima do valor considerado normal para este exame.|
|1|Febre (temperatura axilar acima de 38º C). Excluir infecções.|
|1|Trombocitopenia (menos de 100.000 plaquetas/mm3). Excluir outras causas, tais como medicamentos.|
|1<br>TOTAL|Leucopenia (menos de 3.000 leucócitos/mm3). Excluir outras causas, tais como medicamentos.|  
**Observação:** O resultado dos exames laboratoriais deve ter sido obtido em cerca de 10 dias da avaliação clínica do paciente. As definições de atividade da doença são classificadas da seguinte forma: LES inativo: 0; Atividade leve: 1-5; Atividade moderada: 6-10; Atividade alta: 11-19; e Atividade muito alta: 20 ou mais.  
|**Itens**|**Descritores**|**Escore**|
|---|---|---|
|**OCULAR**|Catarata-1 e Retinopatia ou atrofia óptica-1|0 a 2|
|**NEUROPSIQUIÁTRICO**|Déficit cognitivo ou psicose maior-1, Convulsões (> 6 meses)-1, AVC em<br>qualquer época-1 (se >1 escore 2), Neuropatia craniana ou periférica (exclui<br>óptica)-1, Mielite transversa-1|0 a 6|
|**RENAL**|DCE < 50%-1, Proteinúria >3,5g/ 24 h-1 ou doença renal em estágio final-3|<br>0 a 3|
|**PULMONAR**|Hipertensão pulmonar-1, Fibrose pulmonar-1, Pulmão encolhido-1, Fibrose<br>pleural-1, Infarto pulmonar-1|0 a 5|
|**CARDIOVASCULAR**|Angina ou_bypass_arterial-1, IAM em qualquer época-1 (se >1 escore 2),<br>Cardiomiopatia-1, Doença valvular -1, Pericardite (>6 meses) ou<br>pericardiectomia-1|0 a 6|
|**DOENÇA VASCULAR**|Claudicação (>6 meses)-1, Perda de tecido (polpas digitais)-1, Perda|0 a 5|
|**PERIFÉRICA**|significante de tecido (dedo ou membro)-1 (se > 1 escore 2), TV com<br>ulceração, edema ou estase venosa-1||
|**GASTROINTESTINAL**|Infarto ou ressecção do intestino, fígado, baço ou VB-1 (se >1 sítio, escore<br>2), Insuficiência mesentérica-1, Peritonite crônica-1, Constrição ou cirurgia<br>TGI superior em qualquer ocasião-1, Pancreatite crônica-1|0 a 6|
|**MUSCULOESQUELÉTICO**|Atrofia ou fraqueza muscular-1, Artrite deformante ou erosiva-1,<br>Osteoporose com fratura-1, Necrose avascular -1 (se >1 escore 2),<br>Osteomielite-1, Ruptura de tendão-1|0 a 7|
|**PELE**|Alopecia crônica cicatricial-1, Extensa cicatrização da pele ou panículo<br>(exceto em couro cabeludo ou polpa digital)-1, Úlcera cutânea > 6 meses<br>(excluir TV)-1|0 a 3|
|**INSUFICÊNCIA GONADAL**|< 40 anos-1|0 ou 1|
|**PREMATURA**|||
|**DIABETES**|Independente do tratamento-1|0 ou 1|
|**MALIGNIDADE**|(exceto displasia) (se >1 sítio, escore 2)|0 a 2|
|**TOTAL**||0 a 47|

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Lúpus eritematoso sistêmico, contendo a descrição da metodologia de busca de evidências científicas, tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor deste Protocolo foi composto por metodologistas e um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Lúpus Eritematoso Sistêmico foi inicialmente apresentada à 53ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 20 de fevereiro de 2018. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE) e da Secretaria de Vigilância em Saúde (SVS). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Plenário da Conitec em sua 64ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Consulta pública** -->
A Consulta Pública nº 15/2018, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Lúpus eritematoso sistêmico, foi realizada entre os dias 27/03/2018 a 16/04/2018. Foram recebidas 213 contribuições, que podem ser verificadas  
em:  
<u>http://conitec.gov.br/images/Consultas/Contribuicoes/2018/CP_CONITEC_15_2018_PCDT_Lpus_eritematoso_sistmico1.pdf</u>  
**2. Busca da evidência e recomendações**  
- **A) Levantamento de informações para planejamento da reunião com os especialistas**  
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), sítio da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais do SUS e o Protocolo Clínico e Diretriz Terapêutica (PCDT) de Lúpus Eritematoso Sistêmico (LES) vigente para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas.  
A partir das consultas realizadas, foi possível identificar:  
- o tratamento no SUS observa o PCDT do LES, conforme a Portaria SAS/MS nº 100, de 7 de fevereiro de 2013,  
- retificada em 22 de março de 2013.  
- os medicamentos já disponíveis são: cloroquina, hidroxicloroquina, betametasona, dexametasona, metilprednisolona,  
- prednisona, azatioprina, ciclosporina, ciclofosfamida, danazol, metotrexato e talidomida.  
- não havia solicitação de avaliação de nenhuma nova tecnologia na CONITEC.  
Na enquete pública realizada pelo Ministério da Saúde sobre os PCDT, foram identificadas as seguintes contribuições na atualização do PCDT:  
- inclusão dos medicamentos micofenolato de mofetila, belimumabe e rituximabe.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **B) Reunião com especialistas** -->
Foi realizada reunião com o consultor especialista e metodologista do comitê elaborador na qual foram apresentados os resultados do levantamento de informações realizados pelos metodologistas. O consultor especialista indicou a necessidade de avaliação de inclusão dos medicamentos micofenolato de mofetila, rituximabe e belimumabe.  
Após revisão da literatura, foi verificado que o rituximabe não possui evidência para sua incorporação no SUS e não possui autorização da Anvisa para uso em pacientes com LES. Desta forma, foi solicitada a incorporação dos medicamentos micofenolato de mofetila e belimumabe. Sendo assim, foi estabelecido que o Protocolo se destina a pacientes com LES, ambos os sexos, sem restrição de idade e tem por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca do PCDT vigente.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Belimumabe** -->
A fim de revisar a literatura sobre a eficácia, efetividade e segurança do belimumabe, foi elaborado um parecer técnico científico (PTC), o qual foi avaliado pelo Plenário da CONITEC na reunião de 06 de julho de 2017 (57ª reunião). A conclusão foi pela não recomendação da sua incorporação<sup>71</sup> .

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **Micofenolato de mofetila e de sódio** -->
Foi elaborado PTC para avaliar a segurança e eficácia do micofenolato de mofetila e de sódio para pacientes com nefrite lúpica, o qual foi avaliado pelo Plenário da CONITEC na reunião de de 06 de julho de 2017 (57ª reunião). A recomendação inicial foi pela incorporação do micofenolato de mofetila, mas à época, o medicamento não possuía indicação aprovada em bula e a Anvisa não havia se manifestado sobre a autorização de uso excepcional do medicamento, impedindo que o Protocolo preconizasse o medicamento. Em abril de 2022, a Anvisa incluiu a indicação de “terapia de indução e manutenção de pacientes adultos com nefrite lúpica classe III a V” na bula do medicamento micofenolato de mofetila. Assim, a decisão de incorporação do medicamento foi publicada por meio da Portaria SCTIE/MS nº 46/2022.

---

<!-- METADADOS: doenca: Lúpus Eritematoso Sistêmico | secao: **D) Buscas na literatura para atualização do PCDT** -->
A fim de guiar a revisão do PCDT vigente foram realizadas buscas na literatura sobre tratamento, diagnóstico e monitorização. A seguinte pergunta PICO foi estabelecida ( **Quadro A** ):  
**Quadro A –** Pergunta PICO  
|**População**|Pacientes com LES|
|---|---|
|**Intervenção**|Diagnóstico e tratamento clínico|
|**Comparação**|Sem restrição de comparadores|
|**Desfechos**|Segurança e eficácia|
|**Tipos de estudos**|Meta-análises, revisões sistemáticas e_guidelines_|  
O **Quadro B** apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados. As evidências relacionadas aos medicamentos micofenolato de mofetila e belimumabe foram avaliadas em pareceres técnico científicos (PTC) submetidos à CONITEC<sup>70,121</sup> .  
**Quadro B -** Buscas sobre intervenções terapêuticas - Revisões sistemáticas e meta-análises.  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via<br>PubMed)<br>Data da busca:<br>10/07/2017|"Lupus Erythematosus, Systemic"[Mesh] AND<br>"Therapeutics"[Mesh] AND ((Meta-<br>Analysis[ptyp] OR systematic[sb]) AND<br>"humans"[MeSH Terms] AND (English[lang]<br>OR Portuguese[lang] OR Spanish[lang])) AND<br>("2011/06/16"[PDAT] : "2017/07/10"[PDAT])|81|----|
|Embase<br>Data da busca:<br>10/07/2017|'systemic lupus erythematosus'/exp/mj AND<br>'therapy'/exp/mj AND ([systematic review]/lim<br>OR [meta analysis]/lim) AND ([english]/lim<br>OR [portuguese]/lim OR [spanish]/lim) AND<br>[humans]/lim AND [16-6-2011]/sd NOT [11-7-<br>2017]/sd|27|----|
|Cochrane<br>Library<br>Data da busca:<br>10/07/2017|'lupus erythematosus in Title Abstract<br>Keyword - with Cochrane Library publication<br>date between Jun 2011 and Jun 2017, in<br>Cochrane Reviews (Word variations have been<br>searched)'|5|----|
||Duplicados (7)|106|19<br>**Motivo das exclusões:**<br>- assunto muito específico, foge do<br>escopo do PCDT: 39<br>- incluídos no PTC de belimumabe e<br>micofenolato de mofetila: 10<br>- revisão simples: 22<br>- medicamento sem registro no Brasil<br>ou sem indicação na bula: 5<br>- medicamentos ainda não disponíveis<br>no SUS: 2<br>- protocolo de revisão sistemática: 1|  
As buscas realizadas sobre diagnóstico da doença, bem como o número de artigos incluídos e motivos das exclusões estão descritos no **Quadro C** .  
**Quadro C -** Busca por diagnóstico e monitorização.  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via|"Lupus Erythematosus,|101|4|
|PubMed)|Systemic/diagnosis"[Mesh] AND<br>((Consensus Development||**Motivo das exclusões:**<br>- incluídos na busca Medline|
|Data da busca:|Conference[ptyp] OR Consensus||tratamento: 4|
|10/07/2017|Development Conference, NIH[ptyp]<br>OR Government Publications[ptyp]<br>OR Guideline[ptyp] OR Practice<br>Guideline[ptyp] OR systematic[sb])<br>AND "humans"[MeSH Terms] AND<br>(English[lang] OR Portuguese[lang]<br>OR Spanish[lang])) AND<br>("2011/06/16"[PDAT] :<br>"2017/07/10"[PDAT])||- assunto muito específico, foge do<br>escopo do PCDT: 64<br>- incluídos no PTC de belimumabe e<br>micofenolato de mofetila: 3<br>- revisão simples: 14<br>- medicamento sem registro no Brasil: 1<br>- testes diagnósticos sem aplicabilidade<br>clínica definida: 11|  
Foram analisadas 106 referências para revisão do tratamento e 101, para o diagnóstico, havendo 11 repetidas entre as buscas. Foram incluídos 23 estudos, entre revisões sistemáticas, meta-análises, _guidelines_ e consensos. Foram também utilizados como referência a base de dados _UpToDate_ , versão 2017, livros texto, referências de conhecimento dos autores e referências sugeridas na consulta pública. As revisões sistemáticas e meta-análises selecionadas nas buscas estão descritas na **Tabela 1** .  
**Tabela 1** - Resumo dos artigos selecionados na busca para atualização do PCDT de LES.  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|_Combined Oral_<br>_Contraceptives in_<br>_Women_|- Estudo de não-<br>inferioridade duplo-<br>cego, randomizado.|-**Número de**<br>**participantes:**183.|-**Intervenção:**<br>- Contraceptivo<br>oral (etinilestradiol|**- Primários:**<br>- Recaída grave<br>(_sever eflare_).|- Recaída grave foi infrequente<br>em ambos os grupos: 7 de 91<br>indivíduos no grupo|- O tamanho da<br>amostra foi menor<br>do que inicialmente|
|_with Systemic Lupus_<br>_Erythematosus,_2005.|**- Critérios de**<br>**elegibilidade:**<br>pacientes deveriam<br>preencher pelo menos<br>4 critérios do<br>_American College of_<br>_Rheumatology_para<br>classificação de lúpus<br>eritematoso sistêmico<br>(LES) e ter menos de<br>40 anos de idade, no<br>caso de não-<br>fumantes, ou menos<br>de 36 anos de idade,<br>no caso de fumantes.<br>Todos os<br>participantes<br>deveriam ter doença<br>clinicamente estável<br>ou apresentando|- As participantes<br>foram recrutadas de<br>junho de 1997 a<br>julho de 2002 em 15<br>centros nos Estados<br>Unidos.<br>- População:<br>Mulheres com LES<br>inativo (76%) ou em<br>atividade, porém<br>estável (24%).|trifásico [35 μg] +<br>noretindrona [0,5<br>mg, 0,75 mg ou 1<br>mg]; 91 mulheres).<br>**- Controle:**<br>- Placebo (92<br>mulheres).<br>**- Tempo de uso:**<br>12 ciclos de 28 dias<br>cada.<br>**- Tempo de**<br>**seguimento:**1, 2,<br>3, 6, 9 e 12 meses<br>(até julho de 2003).|**- Secundários:**<br>- Recaída leve a<br>moderada (_mild or_<br>_moderate flares_).<br>- Escore SELENA-<br>SLEDAI.|contraceptivo oral (7,7%) e 7<br>de 92 indivíduos no grupo<br>placebo (7,6%), sendo que dois<br>dos casos de recaída grave no<br>grupo contraceptivo oral<br>aconteceram quando os<br>participantes não estavam<br>tomando o medicamento em<br>estudo.<br>- As taxas de recaída grave em<br>12 meses foram similares:<br>0,084 (IC95% 0,024 - 0,14)<br>para o grupo recebendo<br>contraceptivo oral e 0,087<br>(IC95% 0,025 - 0,15) para o<br>grupo placebo, resultando em<br>uma diferença de -0,0028 entre<br>os grupos (p=0,95; o limite<br>superior para a diferença foi de<br>0,069, estando dentro da<br>margem de não-inferioridade|planejado.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||melhora durante os 3<br>meses anteriores ao<br>ingresso no estudo.<br>Imunossupressores<br>foram permitidos<br>caso a dose estivesse<br>estável durante os 2<br>meses anteriores ao<br>estudo. Indivíduos<br>com níveis<br>moderados ou altos<br>de anticorpos<br>anticardiolipina,<br>anticoagulante lúpico<br>ou histórico de<br>trombose foram<br>excluídos.<br>**- Objetivo:**avaliar,<br>prospectivamente, o<br>efeito de<br>contraceptivos orais<br>na atividade do LES<br>em mulheres pré-<br>menopáusicas.||||pré-especificada de 9%).<br>- O risco relativo estimado de<br>ocorrência de recaída grave<br>enquanto recebendo<br>contraceptivo oral, comparado<br>a placebo, foi de 0,93 (p=0,89;<br>IC95% 0,33 – 2,65).<br>- A análise por protocolo, que<br>incluiu 57 indivíduos<br>recebendo contraceptivo oral e<br>58 recebendo placebo, mostrou<br>uma taxa estimada de recaída<br>grave em 12 meses de 0,088<br>para contraceptivos orais<br>(IC95% 0,014 – 0,16) e 0,12<br>para placebo (IC95% 0,037 –<br>0,20). A diferença da taxa de<br>recaída grave em 12 meses<br>entre os grupos foi de –0,033<br>(p=0,56). O limite superior do<br>IC95% foi de 0,060, menos do<br>que a margem pré-especificada<br>de 9%, corroborando os<br>resultados da análise por<br>intenção de tratar de que||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||anticoncepcional oral não é<br>inferior a placebo no que diz<br>respeito ao risco de recaída<br>grave.<br>- Em ambos os grupos de<br>estudo, os indivíduos que<br>entraram no estudo com<br>doença ativa, porém estável,<br>tiveram maior risco de recaída<br>grave comparados àqueles com<br>doença inativa. O risco relativo<br>estimado foi de 3,50 (IC95%<br>1,23 – 9,99; P = 0,02).<br>- As taxas de recaída leve a<br>moderada não diferiram<br>significativamente entre os<br>grupos: 63 participantes<br>recebendo contraceptivo oral<br>(69%) e 55 recebendo placebo<br>(60%) tiveram uma ou mais<br>recaída leve a moderada. A<br>taxa de incidência de recaída<br>leve a moderada, incluindo<br>múltiplas recaídas em um<br>mesmo indivíduo, foi de 1,40||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||recaídas por pessoa-ano para o<br>grupo contraceptivo oral e 1,44<br>para o grupo placebo (risco<br>relativo 0,98, IC95% 0,76-<br>1,26; p=0,86).<br>- A probabilidade de ter pelo<br>menos recaída de qualquer tipo<br>durante os 12 meses de<br>seguimento foi de 76% para<br>participantes recebendo<br>contraceptivo oral e 69% para<br>participantes recebendo<br>placebo, uma diferença de 0,07<br>(p=0,34; limite superior do<br>IC95% de 0,19). O risco<br>relativo estimado no grupo<br>contraceptivo oral baseado no<br>tempo para a primeira recaída<br>de qualquer tipo foi de 1,09<br>(p=0,65; IC95% 0,76 a 1,55).<br>- A mudança nos escores<br>SELENA-SLEDAI não foi<br>significativamente diferente<br>entre os grupos em nenhum<br>momento durante o||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||seguimento.<br>- No grupo contraceptivo oral<br>houve uma trombose venosa<br>profunda e um enxerto<br>coagulado (_clotted graft_); no<br>grupo placebo, houve uma<br>trombose venosa profunda,<br>uma trombose ocular, uma<br>tromboflebite superficial e uma<br>morte (após término do<br>estudo).||
|_Efficacy and Safety of_|- Revisão sistemática.|-**Número de**|-**Intervenção:**|**- Eficácia:**|- A ciclofosfamida demonstrou|- Vários|
|_Nonbiologic_||**estudos incluídos:**|Imunossupressores|**-**Manifestações|eficácia para o LES|imunossupressores|
|_Immunosuppressants_|-**Período da busca:**|65.|não biológicos:|não-renais.|neuropsiquiátrico, prevenindo|demonstraram sua|
|_in the Treatment of_|até outubro de 2011.||- Metotrexato|- Escores por|recidivas com um efeito|segurança e eficácia|
|_Nonrenal Systemic_||-**Número de**|(MTX) 7,5 – 20|índices de|poupador de esteroide|no LES não-renal.|
|_Lupus_|-**Bases consultadas:**|**participantes:**813|mg/semana.|atividade,|adicional, embora seu uso|Um fármaco|
|_Erythematosus: A_|Medline, Embase, e|(nos ECR).|- Ciclofosfamida|exacerbações do|tenha sido associado a danos|específico para cada|
|_Systematic Review,_|_Cochrane Central_||(CYC) 0,5 – 1|LES, efeito|cumulativos, desenvolvimento|manifestação|
|2013_._|_Register of_<br>_Controlled Trials_.<br>Uma busca manual<br>também foi realizada<br>pela revisão das|- População:<br>Pacientes adultos<br>diagnosticados com<br>LES.<br>|g/m²/mês, 200-400<br>mg/mês.<br>- Azatioprina<br>(AZA) 3-4 mg/kg.<br>- Leflunomida|poupador de<br>esteroides e assim<br>por diante.<br>-**Segurança:**|de neoplasia intraepitelial<br>cervical e falência ovariana.<br>- Outros imunossupressores<br>(azatioprina, metotrexato,|particular não pode<br>ser recomendado,<br>embora a<br>ciclofosfamida possa<br>ser usada em casos|
||||(LEF) 100 mg/dia||leflunomida, micofenolato|mais graves, e o|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||referências dos<br>estudos incluídos.<br>**- Critérios de**<br>**elegibilidade:**<br>estudos incluindo<br>pacientes adultos com<br>LES, intervenção<br>com agentes<br>imunossupressores<br>não biológicos, grupo<br>de comparação com<br>placebo ou<br>medicamento ativo e<br>medidas de desfecho<br>avaliando a eficácia<br>ou a segurança. Meta-<br>análises, revisões<br>sistemáticas, ensaios<br>clínicos e estudos de<br>coorte foram<br>incluídos.<br>**- Objetivo:**analisar a<br>eficácia e segurança|- Em geral, os<br>estudos foram de<br>baixa qualidade, com<br>apenas 11 ensaios<br>clínicos<br>randomizados.<br>- Dos estudos, 29<br>eram sobre<br>ciclofosfamida, 2<br>sobre azatioprina, 7<br>sobre metotrexato,2<br>sobre leflunomida, 8<br>sobre micofenolato<br>mofetila, 8 sobre<br>ciclosporina, 2 sobre<br>tacrolimo e 6 sobre<br>combinações de<br>medicamentos<br>imunossupressores.|por 3 dias e após 20<br>mg/dia.<br>- Micofenolato<br>mofetila (MMF)<br>0,5 g/12h e após<br>aumentar para 1,5<br>g/12h.<br>- Ciclosporina A<br>(CSA) 1- 5<br>mg/kg/dia.<br>- Prednisona (PRD)<br>0,5-1 mg/kg, 20,5<br>mg/dia.<br>- Metilprednisolona<br>(MP) 1 g/dia por 3<br>dias.<br>- Tacrolimo (TAC).<br>-**Controle:**<br>- Placebo ou<br>comparador ativo.<br>**- Tempo de**<br>**tratamento:**não<br>relatado.|- Infecções,<br>eventos<br>cardiovasculares,<br>malignidades e<br>assim por diante.|mofetila e ciclosporina)<br>demonstraram eficácia na<br>redução da atividade não-renal<br>com efeito poupador de<br>esteroides, embora apenas em<br>um ECR não controlados por<br>placebo e com um número<br>pequeno de pacientes.|metotrexato pode ser<br>a primeira opção na<br>maioria dos casos de<br>LES moderadamente<br>ativo.<br>- São necessários<br>ECR de alta<br>qualidade com um<br>número maior de<br>pacientes.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||de imunossupressores<br>não biológicos no<br>tratamento de lúpus<br>eritematoso sistêmico<br>não-renal (LES).||**- Tempo de**<br>**seguimento:**os<br>ECR tiveram<br>duração variável de<br>6 a 30 meses.||||
|_Methotrexate in_<br>_systemic lupus_<br>_erythematosus: a_<br>_systematic review of_|- Revisão sistemática;<br>**- Período da busca:**<br>não relatado.|**- Número de**<br>**estudos incluídos:**9<br>(3 ECR e 6 estudos<br>observacionais|-**Intervenção:**<br>- Metotrexato 2,5 a<br>25 mg/semana.|**- Eficácia:**<br>- Escores de<br>atividade da<br>doença (SLEDAI).|- O MTX é eficaz na redução<br>da atividade do LES e confere<br>um efeito poupador de<br>esteroides.|- O MTX parece ser<br>mais útil em<br>pacientes com artrite<br>ativa ou|
|_its efficacy,_2014.|**- Bases consultadas:**<br>MEDLINE<br>(PubMed), EMBASE<br>e_Cochrane_<br>_Controlled Trials_<br>_Registry_.<br>**- Critérios de**<br>**elegibilidade:**ECR e<br>estudos<br>observacionais que<br>examinaram os<br>efeitos de metotrexato|prospectivos).<br>**- Número de**<br>**participantes:**351.<br>-**População:**<br>Pacientes adultos<br>com LES.<br>- Todos os estudos<br>incluídos envolvem<br>predominantemente<br>pacientes com artrite<br>ou características|-**Controle:**<br>- Placebo.<br>- Corticosteroides.<br>- Antimaláricos.<br>**- Tempo de**<br>**tratamento:**não<br>relatado.<br>**- Tempo de**<br>**seguimento:**a<br>duração dos<br>estudos variou de 6<br>a 26 meses. O|-Redução na dose<br>de esteroides.<br>- Alteração nos<br>marcadores<br>sorológicos e<br>laboratoriais (anti-<br>dsDNA, proteínas<br>do complemento e<br>taxa de<br>sedimentação de<br>eritrócitos (ESR)).|- Houve redução significativa<br>do SLEDAI entre os pacientes<br>tratados com MTX quando<br>comparados com os controles<br>(p=0,001, OR= 0,444, IC95%<br>0,279 a 0,707).<br>- Houve também uma redução<br>significativa na dose média de<br>corticosteroides entre os<br>pacientes tratados com MTX<br>quando comparados com os<br>controles (p= 0,001, OR 0,335,|manifestações<br>cutâneas, mas seu<br>lugar no tratamento<br>de manifestações<br>renais,<br>neuropsiquiátricas<br>ou hematológicas<br>ainda não foi<br>estabelecido.<br>-Há uma escassez de<br>ensaios controlados<br>bem projetados<br>sobre o uso do MTX|
||(MTX) semanal em|mucocutâneas|tempo de||IC95% 0,202 a 0,558).|no LES. Além disso,|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||pacientes adultos com<br>LES foram elegíveis<br>para inclusão. Outros<br>critérios de inclusão<br>foram: diagnóstico de<br>LES com base nos<br>critérios do_American_<br>_College of_<br>_Rheumatology_(ACR)<br>ou na opinião do<br>médico envolvido;<br>tratamento com MTX<br>por um período<br>mínimo de três<br>meses; administração<br>de placebo ou terapia<br>padrão para pacientes<br>randomizados para o<br>braço controle.<br>**- Objetivo:**avaliar a<br>evidência quanto à<br>eficácia do MTX no<br>lúpus eritematoso|- A amostra variou<br>de 12 a 86<br>participantes por<br>estudo.<br>- Dos ECR, 2 eram<br>duplo-cegos e 1<br>open-label. Dos<br>estudos<br>observacionais,<br>apenas 2 utilizaram<br>grupos controles.<br>- A distribuição<br>geográfica destes<br>estudos foi ampla,<br>incluindo América<br>do Norte, Ásia,<br>Europa, Austrália e<br>América do Sul.<br>- Os estudos foram<br>todos publicados|acompanhamento<br>foi de até 12 meses<br>para os ECR.||- O efeito do MTX em<br>marcadores laboratoriais e<br>serológicos, incluindo a taxa de<br>sedimentação de eritrócitos,<br>anti-dsDNA e níveis de<br>complemento (C3 e C4), não<br>pôde ser determinado devido<br>ao número limitado de ensaios<br>controlados.|os tamanhos de<br>amostra em quase<br>todos os estudos<br>incluídos eram<br>pequenos e a<br>duração do<br>seguimento<br>geralmente não era<br>suficientemente<br>longa (até 12 meses<br>para os estudos<br>controlados).<br>- Exclusão dos<br>estudos de casos<br>(havia muitas séries<br>de casos que eram<br>de natureza<br>descritiva, e uma<br>análise dessas séries<br>poderia ter fornecido<br>informações úteis<br>adicionais, porém<br>devido a sua baixa|
||sistêmico (LES).|entre 1994 e 2012.||||evidência elas não|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||foram incluídas na<br>revisão).|
|||||||- Inclusão de estudos<br>antigos, alguns deles<br>conduzidos há mais<br>de 15-20 anos.|
|||||||- Outra limitação foi<br>a dificuldade em<br>determinar a dose de<br>tratamento ideal do<br>MTX no LES<br>devido à ampla<br>gama de doses<br>utilizadas nos|
|||||||diferentes estudos.|
|_Drugs for discoid_<br>_lupus erythematosus_|- Atualização de<br>revisão publicada em|**- Número de**<br>**estudos incluídos:**5.|- Qualquer<br>medicamento cujo|**- Primários:**<br>**-**Porcentagem de|- Um estudo de fluocinonida<br>creme 0,05% comparada com|-Grande<br>heterogeneidade|
|_(Review),_2017.|2000 e previamente||tratamento tinha|pessoas com|hidrocortisona creme 1% em|entre os estudos.|
||atualizada em 2009.|**- Número de**|como objetivo|completa resolução|78 pessoas relatou resolução||
|||**participantes:**197.|clarear ou melhorar|das lesões de pele|completa das lesões de pele em|-Todas as|
||**- Período da busca:**||as lesões do LED.|(isto é, retorno à|27% dos participantes no|comparações|
||Até 22 de setembro|**-População:**||aparência normal|grupo fluocinonida e 10% no|incluídas nesta|
||de 2016.|Participantes com||da pele).|grupo hidrocortisona, dando|revisão foram|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||**- Bases consultadas:**<br>_Cochrane Skin_<br>_Specialised Register_,<br>CENTRAL,<br>MEDLINE, Embase e<br>LILACS. Além disso,<br>5 bases de dados<br>foram consultadas e<br>listas de referências<br>foram checadas.<br>Busca manual no<br>Index Medicus (1956<br>a 1966) foi feita e<br>autores foram<br>contatados. ISRCTN<br>_registry_;_US National_<br>_Institutes of Health_|pelo menos 18 anos<br>de idade.<br>- Diagnóstico clínico<br>de lúpus eritematoso<br>discóide, foi aceito<br>com ou sem<br>confirmação<br>histológica. Estudos<br>que incluíam pessoas<br>com tipos diferentes<br>de lúpus cutâneo<br>foram incluídas se o<br>subgrupo com LED<br>pudesse ser<br>identificado<br>separadamente|-**Intervenção:**os<br>estudos incluídos<br>usaram:<br>**-**Pimecrolimus 1%<br>creme, 2x/dia.<br>- R-salbutamol<br>0,5% creme tópico<br>2x/dia.<br>- Tacrolimo 0,1%<br>creme.<br>- Fluocinonida<br>creme 0,05% 3x/dia<br>sem oclusão.<br>- Acitretina 50<br>mg/dia.<br>-**Controle:**|- Porcentagem de<br>pessoas com<br>clareamento do<br>eritema em pelo<br>menos 50% das<br>lesões<br>(pigmentação pós-<br>inflamatória<br>poderia persistir).<br>- Melhoria nas<br>medidas do<br>paciente de<br>satisfação/qualidad<br>e de vida.<br>**- Secundários:**|um benefício absoluto de 17%<br>a favor da fluocinonida (RR<br>2,77, IC95% 0,95 a 8,08).<br>Eventos adversos não levaram<br>a interrupção do medicamento.<br>Irritação na pele ocorreu em 3<br>pessoas usando hidrocortisona<br>e 1 pessoa desenvolveu acne.<br>Queimação ocorreu em 2<br>pessoas usando fluocinonida.<br>- Um estudo comparativo de<br>dois medicamentos orais<br>acitretina (50 mg) e<br>hidroxicloroquina (400 mg)<br>relatou 2 dos desfechos de<br>interesse: resolução completa<br>foi vista em 13 dos 28|avaliadas em<br>estudos únicos, que<br>não permitiram<br>avaliar a<br>consistência dos<br>resultados em todos<br>os estudos.|
||_Ongoing Trials_<br>_Register; Australian_<br>_New Zealand Clinical_<br>_Trials Registry;_<br>_World Health_<br>_Organization_||- Placebo ou<br>qualquer outro<br>medicamento (via<br>oral, tópica ou<br>parenteral):<br>- Betametasona 17-<br>valerate 0,1%.|- Taxa de recaídas<br>quando o<br>medicamento foi<br>interrompido ou<br>sua dose reduzida.|participantes (46%) no grupo<br>acitretina e 15 de 30 no<br>hidroxicloroquina (RR 0,93,<br>IC95% 0,54 a 1,59).<br>Clareamento do eritema em<br>pelo menos 50% das lesões foi<br>relatado em 10 dos 24||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||_International Clinical_<br>_Trials_<br>_Registry platform;_<br>_EU_<br>_ClinicalTrialsRegiste_<br>_r._<br>**- Critérios de**<br>**elegibilidade:**foram<br>incluídos ECR de<br>medicamentos para<br>tratamento de<br>pacientes com LED,<br>em qualquer grupo<br>populacional e de<br>qualquer gênero.<br>Comparações<br>incluíram qualquer<br>medicamento usado<br>para LED contra<br>qualquer outro<br>medicamento ou<br>contra placebo em<br>creme. Foi excluído<br>tratamento com laser,||- Placebo.<br>- Hidrocortisona<br>creme 1% 3x/dia<br>sem oclusão.<br>- Hidroxicloroquina<br>400 mg/dia.<br>**- Tempo de uso:**<br>variou de 8 a 12<br>semanas entre os<br>estudos.<br>**- Tempo de**<br>**seguimento:**no<br>_Barikbin 2009_,<br>seguimento de 8<br>semanas. Os outros<br>estudos não<br>relataram se houve<br>ou não seguimento.|- Prevenção de<br>novas lesões.<br>- Eventos adversos<br>dos medicamentos<br>levando à<br>interurpção ou<br>morbidade<br>significativa.<br>- Implicações para<br>os custos de<br>cuidados de saúde.|participantes (42%) no<br>acitretina e 17 dos 25 (68%) no<br>hidroxicloroquina (RR 0,61,<br>IC95% 0,36 a 1,06). Pacientes<br>tomando acitretina mostraram<br>aumento leve nos triglicerídeos<br>séricos, não o suficiente para<br>interromper o medicamento.<br>Os principais efeitos adversos<br>foram lábios secos (93% no<br>grupo acitretina e 20% no<br>hidroxicloroquina) e distúrbio<br>gastrointestinal (11% no<br>acitretina e 17% no<br>hidroxicloroquina). Quatro<br>participantes no acitretina<br>abandonaram devido a eventos<br>gastrointestinais ou lábios<br>secos.<br>- Um estudo comparou<br>tacrolimo creme 0,1% com<br>placebo, mas não relatou os<br>desfechos primários<br>solicitados. No grupo do<br>tacrolimo, 5 participantes||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||cirurgia, fototerapia,<br>outras formas de<br>tratamento físico e<br>fotoproteção.<br>**- Objetivo:**avaliar se<br>existe alguma nova<br>informação<br>disponível para tratar<br>LED, como ainda não<br>havia segurança<br>quanto à efetividade<br>dos medicamentos<br>disponíveis e para<br>saber como selecionar<br>o tratamento mais<br>apropriado para um<br>indivíduo com LED.||||queixaram-se de queimação<br>leve e coceira, e para 1<br>participante houve reativação<br>de infecção por herpes simples.<br>- R-Salbutamol tópico 0,5%<br>creme foi comparado com<br>placebo em estudo de 37<br>pessoas. Três tiveram melhora<br>significativa na dor e coceira<br>no grupo salbutamol em 2, 4, 6<br>e 8 semanas comparado com<br>placebo, mas o estudo não<br>relatou medida formal de<br>qualidade de vida. Mudanças<br>no eritema não mostrou<br>benefício acima no salbutamol,<br>mas não foi possível obter do<br>estudo o número de<br>participantes com clareamento<br>do eritema em pelo menos 50%<br>das lesões.<br>- Em conclusão, fluocinonida<br>creme parece ser mais efetivo<br>que hidrocortisona no<br>clareamento das lesões.||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||- Hidroxicloroquina e acitretina<br>parecem ser equieficazes em<br>termos de completa resolução,<br>embora os eventos adversos<br>possam ser mais frequentes no<br>acitretina, e o clareamento das<br>lesões ocorre menos<br>frequentemente na aplicação<br>do acitretina.||
|_Tacrolimus use in_<br>_lupus nephritis: A_<br>_systematic review and_<br>_meta-analysis,_2015.|-Revisão sistemática<br>e meta-análise.<br>**- Período da**<br>**busca:**17 de junho de<br>2015.<br>**- Bases consultadas:**<br>Cochrane, SCOPUS,<br>_Web of_<br>_Science_e OVID<br>(MEDLINE e<br>EMBASE).<br>**- Critérios de**|**- Número de**<br>**estudos incluídos:**9.<br>- Como nenhum<br>estudo controlado<br>relacionado ao uso<br>de tacrolimo na<br>gravidez ou à nefrite<br>lúpica de início na<br>infância ou<br>adolescência foi<br>encontrado, estudos<br>de coorte<br>(prospectivos e<br>retrospectivos)|-**Intervenção:**<br>- Tacrolimo (TAC).<br>- Tacrolimo (TAC)<br>+ micofenolato de<br>mofetila (MMF).<br>**- Controle:**<br>- Ciclofosfamida<br>intravenosa<br>(IVCYC).<br>- Micofenolato de<br>mofetila (MMF).<br>- Placebo.<br>**- Tempo de uso:**|- Taxa de remissão<br>completa.<br>- Taxa de remissão<br>parcial.<br>- Eventos adversos.|- TAC vs. IVCYC (5 estudos<br>considerados [dois deles<br>publicados na forma de<br>resumo] de baixa<br>heterogeneidade): apesar de os<br>resultados individuais não<br>demonstrarem diferenças<br>estatisticamente significativas,<br>a meta-análise combinada<br>sugere aumento significativo<br>dos pacientes tratados com<br>tacrolimo atingindo remissão<br>completa ou remissão completa<br>ou parcial comparado ao grupo<br>IVCYC (p = 0,004 e p =|- Poucos estudos<br>incluídos e de<br>qualidade a desejar.<br>- Desfechos<br>secundários não<br>foram relatados em<br>todos os estudos.<br>- Falta de dados de<br>resultados a longo<br>prazo.<br>- Amostra de origem<br>predominantemente|
||**elegibilidade:**|relacionados a esses|não especificado.||0,0009 respectivamente). RR|asiática.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||estudos controlados<br>(prospectivos ou<br>retrospectivos) de<br>pacientes com lúpus<br>eritematoso sistêmico<br>(LES) complicado<br>por nefrite lúpica.<br>Somente artigos<br>escritos em inglês<br>foram incluídos.<br>**- Objetivo:**avaliar as<br>evidências<br>relacionadas ao uso<br>de tacrolimo no<br>tratamento da nefrite<br>lúpica.|subtópicos também<br>foram incluídos.<br>**- Número de**<br>**participantes:**não<br>especificado.<br>- A maioria dos<br>estudos ocorreu na<br>China.|**- Tempo de**<br>**seguimento:**6 – 24<br>meses.||remissão completa = 1,59<br>(IC95% 1,16 - 2,19).<br>- TAC + MMF vs. IVCYC (2<br>estudos): os 2 estudos,<br>individualmente, mostraram<br>resultados significativamente<br>favoráveis para o grupo TAC +<br>MMF; contudo, houve<br>heterogeneidade significativa<br>(I2 =67% para remissão<br>completa e I2 =11% para<br>remissão completa ou parcial).<br>Os resultados combinados são<br>estatisticamente significativos<br>somente ao se analisar<br>remissão completa e parcial<br>juntas. RR remissão completa<br>= 3,23 (IC95% 0,64 – 16,45).<br>- TAC vs. MMF (3 estudos): a<br>heterogeneidade foi baixa (0-<br>27%) e de maneira geral não<br>houve diferença entre os dois<br>grupos (p = 0,87 para remissão<br>completa, p = 0,27 para<br>remissão completa ou parcial).|- Alta variação nas<br>doses de tacrolimo.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||RR remissão completa = 0,97<br>(IC95% 0,64 – 1,46).<br>- Proteinúria (poucos dados<br>disponíveis e relatados de<br>diferentes maneiras,<br>dificultando a combinação dos<br>resultados): em 6 meses, os<br>grupos usando tacrolimo<br>pareceram ter redução<br>ligeiramente maior da<br>proteinúria, com uma diferença<br>média de -0,68 g/24 hr (IC95%<br>-1,54 – 0,14).<br>- Eventos adversos: os dados<br>relatados não se mostraram<br>estatisticamente significativos.<br>- Gravidez: um relato de caso,<br>uma série de casos com 2<br>pacientes e uma análise<br>retrospectiva de 9 pacientes,<br>todos tratados com sucesso<br>com tacrolimo durante a<br>gravidez. Cinco dessas<br>pacientes já estavam usando<br>tacrolimo antes da gravidez e||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||mantiveram-se com a doença<br>quiescente durante a gestação.<br>As outras 7 mulheres– em uso<br>de azatioprina –tiveram<br>recaída, apresentando<br>proteinúria; nesses casos, TAC<br>foi introduzido ou substituiu o<br>tratamento anterior. Todas as<br>pacientes que tiveram recaída<br>atingiram remissão completa<br>ou parcial em até 6 meses após<br>o parto. Nenhuma das<br>mulheres abortou e todas as<br>crianças nasceram com peso<br>adequado para a idade<br>gestacional e sem alterações<br>congênitas. As duas pacientes<br>da série de casos<br>amamentaram, e concentrações<br>relativamente baixas de<br>tacrolimo foram encontradas<br>no plasma dos bebês; ambas as<br>crianças e as mães<br>mantiveram-se saudáveis em 3<br>anos de seguimento.||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||- Pacientes juvenis (4 estudos<br>não-controlados, prospectivos,<br>analisando TAC ou TAC +<br>Mizoribina na nefrite lúpica de<br>início na infância ou<br>adolescência, totalizando 43<br>casos [embora 4 pacientes<br>tenham sido duplicados em 2<br>estudos], com idade média de<br>17,4 anos [9-38 anos]):<br>agrupando os resultados dos 4<br>estudos, 67,4% dos pacientes<br>alcançaram remissão completa<br>e 90,6% atingiram remissão<br>completa ou parcial. Houve 4<br>casos de infecção por herpes e<br>2 episódios de bronquite, mas<br>não houve relato de<br>leucopenia, sintomas<br>gastrointestinais, alterações<br>hepáticas, hiperglicemia ou<br>amenorreia. Nenhum paciente<br>suspendeu o tratamento.||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|_Impact of sex_<br>_disparities on the_<br>_clinical_<br>_manifestations_<br>_in patients with_<br>_systemic lupus_<br>_erythematous: A_<br>_systematic review and_<br>_meta-analysis,_2016.|- Revisão sistemática<br>e meta-análise.<br>**- Período da busca:**<br>até janeiro de 2016.<br>**- Bases consultadas:**<br>MEDLINE/ PubMed<br>e EMBASE,<br>referências dos<br>artigos incluídos e<br>alguns_websites_<br>oficiais, como o<br>_“Medicine”._<br>**- Critérios de**<br>**elegibilidade:**<br>estudos comparando<br>as manifestações<br>clínicas de pacientes<br>femininos e<br>masculinos com lupus<br>eritematoso sistêmico<br>(LES). Estudos de<br>caso, cartas ao editor|**- Número de**<br>**estudos**<br>**incluídos:**16.<br>**- Número de**<br>**participantes:**11<br>934.<br>- População: 10331<br>mulheres e 1603<br>homens foram<br>incluídos.<br>- Proporção média de<br>mulheres para<br>homens nos estudos:<br>9,3:1.|**- Tempo de**<br>**seguimento:**22,9 ±<br>34,6 meses–<br>14,7±8,7 anos.|- Manifestações<br>clínicas dos<br>sistemas<br>cardiovascular,<br>respiratório, renal,<br>hematológico,<br>dermatológico,<br>neurológico e do<br>tecido conjuntivo.|- Alopecia, fotosensibilidade e<br>úlceras orais foram<br>significativamente maiores em<br>mulheres (OR 0,36, IC95%<br>0,29–0,46, p<0,00001; OR<br>0,72, IC95% 0,63–0,83,<br>p<0,00001; e OR 0,70, IC95%<br>0,60–0,82, p< 0,00001,<br>respectivamente).<br>- Artrite também foi<br>significativamente menor em<br>homens (OR 0,72, IC95%<br>1,25–1,84, p < 0,00001).<br>Entretanto, serosite e pleurite<br>foram significativamente<br>maiores em pacientes homens<br>(OR 1,52, IC95% 1,25–1,84,<br>p<0,0001; e OR 1,26, IC95%<br>1,07–1,48, p = 0,006,<br>respectivamente).<br>- Acometimento renal também<br>foi significativamente menor<br>em mulheres (OR 1,51, IC95%<br>1,31–1,75, p< 0,00001).<br>Pericardite, convulsão e|- Alta variabilidade<br>nos tamanhos das<br>coortes e duração do<br>seguimento<br>- Não foram<br>analisadas as<br>diferenças de cada<br>sexo dentro de cada<br>grupo étnico, devido<br>à falta de dados.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||e artigos de revisão<br>foram excluídos.<br>**- Objetivo:**comparar<br>o impacto do sexo<br>nos desfechos<br>clínicos do LES em<br>diferentes<br>populações.||||psicoses e manifestaram de<br>maneira quase similar em<br>homens e mulheres (OR 1,19,<br>IC95% 0,97–1,45, p = 0,10;<br>OR 1,18, IC95% 0,92–1,50,<br>p=0,19; e OR 0,76, IC95%<br>0,53–1,10, p=0,14,<br>respectivamente).<br>- Manifestações hematológicas,<br>de maneira geral, foram<br>similares entre homens e<br>mulheres (OR 0,92, IC95%<br>0,71–1,19, p = 0,52). Se<br>analisadas individualmente,<br>anemia hemolítica e linfopenia<br>foram similares em homens e<br>mulheres (OR 1,03, IC95%<br>0,81–1,31, P = 0,80; e OR<br>1,13, IC95% 0,96–1,33, P =<br>0,15, respectivamente).<br>Entretanto, trombocitopenia foi<br>significativamente maior em<br>homens (OR 1,31, IC95%<br>1,10–1,56, p = 0,002).<br>-_Rash_malar foi||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||significativamente maior em<br>mulheres (OR 0,68, IC95%<br>0,53–0,88, p= 0,003).<br>- Fenômeno de Raynaud e<br>manifestações neurológicas<br>foramsimilares entre homens e<br>mulheres (OR 0,76, IC95%<br>0,46–1,24, p = 0,27; e OR<br>1,16, IC95% 0,80–1,69, p =<br>0,42, respectivamente).<br>- Anticorpos anticardiolipina<br>manifestaram-se de maneira<br>similar entre homens e<br>mulheres (OR 1,26, IC95%<br>0,79–2,00, p = 0,33).<br>Anticoagulante lúpico foi<br>significativamente maior em<br>pacientes mulheres (OR 1,98,<br>IC95% 1,53–2,57, p <<br>0,00001). Baixo nível de C3<br>também foi mais aparente em<br>mulheres (OR 1,36, IC95% CI<br>1,06–1,76, p = 0,02). Baixo<br>nível de C4 foi observado de<br>maneira similar entre homens e||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||||||mulheres (OR 0,98, IC95%<br>0,74–1,31, p = 0,91). Anti-<br>DNA foi maior em pacientes<br>homens (OR 1,22, IC95%<br>1,02–1,45, p= 0,03).||
|_Cyclophosphamide_<br>_versus_|- Atualização de<br>revisão publicada em|- Número de estudos<br>incluídos: 1 estudo.||*Após a<br>randomização,|**- Primários:   ***Efetividade:<br>Resposta ao -tratamento pela|Considerando o<br>risco de viés,|
|_methylprednisolone_|2000 e previamente|||todos os pacientes|avaliação clínica de força|geração da|
|_for treating_|atualizada em 2006.|- Número de||receberam|muscular, deficiências|sequência de|
|_neuropsychiatric_||participantes: 32||metilprednisolona|motoras, reflexos|alocação ficou em|
|_involvement in_|- Período da busca:|pacientes.||1g/dia por 3 dias|neuromusculares, persistência|baixo risco, no|
|_systemic lupus_|Até junho de 2012.|||como tratamento|de atividade convulsiva e uso|entanto, sigilo de|
|_erythematosus_||-População:||indutor.|de escalas adequadas para|alocação, cegamento|
|_(Review), 2013._|- Bases consultadas:<br>Cochrane Central<br>Register of|Pacientes de<br>qualquer idade ou<br>sexo, que||-**Intervenção:**<br>ciclofosfamida|avaliação de disfunção<br>neurocognitiva (MMSE),<br>depressão (HDRS) e avaliação|e relatório seletivos<br>ficaram em alto<br>risco. Resposta ao|
||Controlled Trials|preenchessem os||0,75g/m² por mês|de sintomas psicóticos (BPRS),|tratamento, definida|
||(CENTRAL),|critérios da_American_||por 1 ano e depois|escala de síndrome positivo e|como melhora de|
||MEDLINE,<br>EMBASE, LILACS,<br>SCOPUS e WHO.|_Rheumatology_<br>_Association_para o<br>diagnóstico de LES e||a cada 3 meses por<br>outro ano.|negativo (PANSS) ou medidas<br>neurológicas equivalentes e<br>específicas.|20% das condições<br>clínicas, sorológicas<br>e medidas|
||Artigos foram<br>buscados|que apresentassem<br>um dos seguintes||-**Controle:**|-Escores de avaliação de dano<br>(SLICC).|neurológicas<br>específicas basais,|
||manualmente assim|eventos||metilprednisolona|-Atividade global (SLEDAI).|foi encontrada em|
|||neuropsiquiátricos:||1g/dia por 3|-Poupador de prednisona.|94.7% (18/19) dos|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||como, entrou-se em<br>contato com experts.<br>- Critérios de<br>elegibilidade: Foram<br>incluídos ECRs que<br>comparavam<br>ciclofosfamida à<br>metilprednisolona em<br>pacientes com LES<br>de qualquer idade,<br>sexo, e apresentando<br>qualquer tipo de<br>manifestação<br>neuropsiquiátrica.<br>Não houve restrição<br>de língua ou data de|psicose, alucinações<br>visuais ou auditivas,<br>delirium,<br>pensamentos ilógicos<br>e distúrbios de<br>comportamento,<br>depressão, cefaleia,<br>convulsões,<br>síndrome orgânica<br>cerebral (delirium,<br>estupor, coma),<br>neuropatia craniana<br>(cegueira, ptose<br>palpebral, paralisia<br>facial), AVC<br>isquêmico ou<br>hemorrágico, mielite||dias/mês por 4<br>meses, depois<br>bimestral por 6<br>meses e depois a<br>cada 3 meses por 1<br>ano.<br>*Prednisona oral 1<br>mg/kg por não<br>mais de 3 meses e<br>afilado de acordo<br>com a atividade da<br>doença / remissão.<br>**- Tempo de uso:**<br>descrito acima.|-Convulsões.<br>*Segurança: eventos adversos<br>(infecções, hipertensão,<br>hiperglicemia, alopecia) e<br>mortalidade global (pacientes<br>que morreram durante o<br>período inteiro de tratamento).<br>**- Secundários:**Aderência ao<br>tratamento.|pacientes usando<br>ciclofosfamida<br>comparado com<br>46.2% (6/13) no<br>grupo que recebeu<br>metilprednisolona<br>em 24 meses (RR<br>2,05, IC95%  1,13 a<br>3,73). Isso foi<br>estatisticamente<br>significativo e o<br>NNT para desfecho<br>benéfico adicional<br>da resposta ao<br>tratamento foi 3.<br>Não foram<br>encontradas|
||publicação.<br>- Objetivo: Avaliar os<br>benefícios e prejuízos<br>de ciclofosfamida e<br>metilprednisolona no<br>tratamento de|transversa,<br>mononeurite,<br>polineuropatia,<br>desordens<br>autonômicas,<br>miastenia gravis,<br>síndrome||**- Tempo de**<br>**seguimento pós**<br>**tratamento:**não<br>relatado.||diferenças<br>estatisticamente<br>significativas entre<br>os grupos em<br>relação às medidas<br>do índice de dano<br>(SLICC). A média|
||manifestações|desmielinizante,||||da avaliação de|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||neuropsiquiátricas de<br>LES.|meningite asséptica e<br>distúrbio de<br>mielopatia.||||SLEDA) favoreceu<br>o grupo<br>ciclofosfamida. O<br>uso de<br>ciclofosfamida foi<br>associado à redução<br>na necessidade de<br>prednisona. Todos|
|||||||os pacientes no|
|||||||grupo|
|||||||ciclofosfamida|
|||||||tiveram melhoras<br>eletroencefalográfic|
|||||||as, mas não houve|
|||||||diferença estatística|
|||||||significativa na<br>diminuição do|
|||||||número de|
|||||||convulsões por mês|
|||||||entre os dois grupos.<br>Não houve|
|||||||diferenças|
|||||||estatisticamente|
|||||||significativas em|
|||||||eventos adversos,|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||incluindo<br>mortalidade.|
|_Effectiveness of_|- Revisão sistemática|- Número de estudos||-**Intervenção:**|**- Primários:**|Sete dos estudos|
|_Nonpharmacologic_||incluídos: 12||*Exercício|*Fadiga (avaliada em 7|incluídos eram|
|_Interventions for_|- Período da busca:|estudos.||aeróbico 30 min, 3|estudos), 6 diferentes|ECRs e 1 era não|
|_Decreasing Fatigue_|junho de 2014.|||x/sem, por 8|instrumentos foram utilizados|randomizado e 4|
|_in Adults with_||- Número de||semanas.|para avaliar fadiga, sendo o|estudos prospectivos|
|_Systemic Lupus_|- Bases consultadas:|participantes: 549||*Exercício|mais freqüente_Fatigue_|observacionais. Eles|
|_Erythematosus: A_|Medline/PreMedline,|pacientes.||aeróbico 50 min,|_Severity Scale_, depois Likert|avaliaram 5|
|_Systematic Review,_|Embase, PsycINFO,|||3x/semana, fase 1:|scales e escala visual|categorias de|
|_2016._|SCI-EXPANDED,|- População:||8 semanas (com|analógica. Outras foram:|intervenção:|
||Social Sciences|Pacientes maiores de||supervisão) e fase|_Profile of Mood States_|exercício,|
||Citation|18 anos de idade||2: 28 semanas|_Subscale for fatigue, the_|abordagens|
||Index, e the Cochrane|com diagnóstico de||(supervisão por|_Chalder Fatigue Scale, the_|comportamentais e|
||Library.|LES.||telefone/pacientes|_Fatigue Intensity Scale e  the_|psicológicas, dieta,|
|||||em casa).|_Multidimensional Assessment_|acupuntura e|
||- Critérios de|||*Exercício|_of Fatigue_.|fototerapia. Todas as|
||elegibilidade: Os|||aeróbico ou||intervenções|
||estudos eram elegidos|||relaxamento||produziram reduções|
||se avaliassem a|||3x/sem por 12||na fadiga, medida|
||efetividade de|||semanas.||usando pelo menos 1|
||estratégias não|||*Programa de||instrumento.|
||medicamentosas para|||treino||Exercício aeróbico|
||reduzir fadiga em|||cardiovascular||pareceu ser efetivo e|
||adultos|||supervisionado por||adequado para|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||diagnosticados com<br>LES, mesmo se<br>fadiga não fosse<br>medida de desfecho<br>primários. ECRs,<br>estudos não<br>randomizados e<br>estudos<br>observacionais<br>publicados em inglês<br>ou espanhol foram<br>incluídos. Os grupos<br>de comparação<br>poderiam usar<br>tratamento padrão,<br>placebo, nenhum<br>tratamento ou<br>tratamentos<br>alternativos.<br>- Objetivo: Sobrevida<br>de pacientes com<br>LES tem melhorado<br>significativamente ao<br>longo das décadas.|||60min, 3x/semana,<br>por 12 semanas.<br>*Programa de<br>exercícios em casa<br>usando Wii Fit 3<br>dias/semana por 30<br>min por 10 sem.<br>*Estratégia de<br>intervenção por<br>telefone por 6<br>meses.<br>*Intervenção<br>psicoeducacional.<br>*Tratamento<br>próprio 2 horas por<br>6 semana<br>*Terapia<br>cognitivo-<br>comportamental<br>com sessões de 2 e<br>1 hora.<br>*Protocolo de<br>acupuntura<br>padronizada, 10||reduzir a fadiga, mas<br>os resultados não<br>foram sempre<br>consistentes entre os<br>instrumentos<br>utilizados. A<br>diversidade de<br>intervenções<br>psicológicas limita a<br>significância dos<br>resultados; no<br>entanto, dados<br>apontam para um<br>impacto positivo na<br>fadiga. Ainda há<br>poucos dados sobre<br>o efeito da<br>acupuntura, dieta e<br>radiação ultravioleta<br>A.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||Como os pacientes<br>com LES vivem mais,<br>eles inevitavelmente<br>passam por várias<br>manifestações<br>clínicas e sintomas<br>somáticos. Qualidade<br>de vida pode também<br>ser impactada por<br>uma série de<br>indicadores<br>subjetivos. Dentre<br>esses parâmetros,<br>fadiga é a queixa<br>mais prevalente.<br>Estratégias não<br>medicamentosas<br>parecem ser<br>regularmente<br>utilizadas para o<br>controle de fadiga no<br>LES; no entanto, seus<br>reais efeitos não são<br>conhecidos.|||sessões por mais<br>de 5sem.<br>*Dieta com baixo<br>índice glicêmico.<br>*Terapia com<br>radiação UVA.<br>-**Controle:**<br>*Exercícios de<br>alongamento não<br>aeróbico 30 min 3<br>x/semana por 8<br>sem.<br>*Amplitude de<br>movimento/fortale<br>cimento muscular<br>50 min 3 x/sem,<br>fase 1: 8 sem e fase<br>2: 28 sem.<br>*Sem treinamento<br>ou relaxamento.<br>*Estratégia de<br>monitoramento de<br>sintomas.|||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||*Intervenção de<br>atenção.<br>*Sem intervenção.<br>*Tratamento<br>padrão.<br>*Controle mínimo<br>de agulhas.<br>*Dieta com<br>restrição calórica<br>por 6 semanas.|||
|||||**- Tempo de uso:**<br>O tempo de<br>acompanhamento<br>das intervenções<br>variou de 3 a 35<br>semanas.|||
|||||**- Tempo de**<br>**seguimento pós**<br>**tratamento:**Não<br>relatado.|||
|_The effect of_<br>_calcineurin inhibitors_<br>_in the induction and_|- Meta-análise e<br>revisão sistemática;|- Pacientes adultos<br>ou jovens com<br>nefrite lúpica;||-**Intervenção:**<br>- Tratamento de<br>indução ou|**- Primários (para o período**<br>**da indução):**taxa de remissão<br>completa (RC), a taxa de|- A eficácia das<br>CNIs, CyA e TAC<br>na terapia de|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|_maintenance_|-**Período da busca:**|- Com exceção de||manutenção:|remissão parcial (RP) e a taxa|indução para nefrite|
|_treatment of lupus_|até fevereiro de 2015;|dois estudos, todos||prednisona oral +|de resposta, conforme definido|lúpica é comparável|
|_nephritis: a_||os pacientes||CyA OU TAC;|pela soma das taxas de|a ivCYC e MMF,|
|_systematic review and_|-**Bases consultadas:**|apresentavam nefrite|||remissão completa e parcial;|sendo muito mais|
|_meta-analysis, 2016._|PubMed, The|lúpica proliferativa||-**Controle:**||seguras do que a|
||Cochrane Library,|comprovada por||- Prednisona oral +|**- Eficácia:**nível de creatinina|ivCYC;|
||Embase e|biópsia.||ivCYC OU AZA|sérica (sCr) e de proteinúria de||
||CENTRAL;|||OU MMF OU|24 horas;|- O tratamento com|
|||||placebo;||CNI durante o|
||**- Critérios de**||||**- Segurança:**taxas de|período de|
||**elegibilidade:**ECRs|||**- Tempo de**|infecção, leucocitopenia,|manutenção também|
||e quasi-ECRs,|||**tratamento:**não|hipertensão, hiperglicemia e|foi tão eficaz quanto|
||publicados ou não,|||relatado;|distúrbios menstruais;|o tratamento com|
||que avaliaram|||||AZA, com um risco|
||qualquer uma das|||**- Tempo de**|- Todos os estudos usaram a|muito menor de|
||seguintes opções:|||**seguimento:**o|redução da proteinúria como|eventos adversos. As|
||tratamento isolado ou|||tempo de|critério de remissão e exigiram|CNIs, CyA e TAC|
||em combinação por|||seguimento variou|uma redução na proteinúria|devem ser|
||mais de 6 meses na|||de 6 a 24 meses.|para menos de 0,5 g/dia para|recomendadas para|
||indução e 9 meses no||||remissão completa;|terapia de indução e|
||período de|||||manutenção do NL;|
||manutenção com||||- Os critérios de remissão||
||corticosteroides,||||parcial variaram entre os|**- Indução**|
||ciclofosfamida, MMF||||artigos, mas todos exigiram|Os resultados da|
||(micofenolato||||uma redução superior a 50% na|<br>análise indicaram|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**<br>**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|
||mofetila), tacrolimo,<br>azatioprina ou<br>ciclosporina. Foram<br>incluídos apenas<br>estudos envolvendo<br>pacientes com nefrite<br>lúpica comprovada<br>por biópsia, critérios<br>de remissão<br>claramente definidos,<br>dados quanto aos<br>desfechos de<br>remissão e dados<br>quanto à segurança;<br>**- Objetivo:**avaliar a<br>eficácia e segurança<br>dos inibidores da<br>calcineurina (CNIs),<br>ciclosporina (CyA) e<br>tacrolimo (TAC) no<br>tratamento de indução<br>e manutenção da<br>nefrite lúpica (LN).|||proteinúria ou proteinúria<br>inferior a 3,5 g/dia.|que, no tratamento<br>de indução, não<br>houve diferença<br>estatisticamente<br>significativa nas<br>taxas de remissão<br>completa (RC),<br>remissão parcial<br>(RP) ou resposta<br>entre as CNIs e a<br>ciclofosfamida<br>intravenosa<br>(ivCYC);<br>**- Manutenção**<br>No período de<br>tratamento de<br>manutenção, a taxa<br>de recaída entre as<br>CNIs e azatioprina<br>(AZA) foi<br>semelhante (RR<br>0,44, p = 0,27),<br>enquanto a taxa de<br>leucocitopenia foi|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||menor com as CNIs<br>(RR 0,26, p =<br>0,0005);|
|||||||**- Segurança**<br>As taxas de eventos|
|||||||adversos, como|
|||||||infecção (RR 0,65, p<br>= 0,04),|
|||||||leucocitopenia (RR|
|||||||0,32, p = 0,04) e|
|||||||distúrbio menstrual|
|||||||(RR 0,37, p = 0,01)|
|||||||após o uso das CNIs|
|||||||foram notavelmente|
|||||||menores do que|
|||||||aqueles depois de|
|||||||ivCYC. Não foram|
|||||||observadas|
|||||||diferenças nas taxas|
|||||||de RC, RP, infecção<br>ou leucocitopenia|
|||||||entre os CNIs e o|
|||||||micofenolato|
|||||||mofetila (MMF).|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|_Effects of exercise on_|- Revisão sistemática|**- Número de**||-**Intervenções:**|-**Eficácia:**redução dos|- Os resultados|
|_depressive symptoms_|de meta-análises;|**estudos incluídos:**2||treinamento|sintomas depressivos;|sugerem que o|
|_in_||meta-análises;||aeróbico e de||exercício melhora os|
|_adults with arthritis_|**- Período da busca:**|||força,|-**Segurança:**há uma aparente|sintomas|
|_and other rheumatic_|até julho de 2013;|**- Número de**||supervisionado ou|escassez de dados disponíveis|depressivos em|
|_disease:_||**participantes:**1164;||não|quanto a eventos adversos e|adultos com|
|_a systematic review_|**- Bases consultadas:**|||supervisionado;|custo-efetividade nos estudos|fibromialgia,|
|_of meta-analyses,_|PubMed,|- Ambas as meta-|||incluídos em ambas as meta-|podendo ser|
|_2014._|Sport Discus, Web of<br>Science, Scopus,|análises incluídas<br>envolveram||**- Tempo de**<br>**tratamento:**a|análises;|recomendado como<br>parte de um plano de|
||Proquest, Cochrane|participantes com||duração da|- O estudo considerou os|tratamento geral que|
||Database|fibromialgia,||intervenção variou|intervalos de confiança não|também pode incluir|
||of Systematic|conforme definido||de 6 a 26 semanas;|sobrepostos para as SMDs; a|educação ou|
||Reviews,|pelos critérios dos|||significância estatística das|farmacoterapia. No|
||Physiotherapy|estudos originais.||**- Tempo de**|SMDs; a sensibilidade dos|entanto, existe a|
||Evidence Database,|||**seguimento:**não|resultados, com cada estudo|necessidade de|
||Database of Abstract|||relatado;|sendo excluído do modelo uma|trabalho meta-|
||of Reviews of Effects|- População:|||vez; meta-análise cumulativa;|analítico adicional|
||(DARE) e Health|pacientes adultos||- A frequência do|baixo NNT; número absoluto|nesta área,|
||Evidence Canada|com osteoartrite,||treinamento variou|de pessoas nos EUA que|incluindo, mas não|
||(HEC);|artrite reumatoide,||de 1 a 7|podem se beneficiar iniciando|se limitando, à|
|||fibromialgia ou lúpus||vezes/semana,|e mantendo um programa de|inclusão de adultos|
||**- Critérios de**|eritematoso||cada sessão|exercícios; melhoras|com osteoartrite,|
||**elegibilidade:**|sistêmico.|||percentuais como resultado do|artrite reumatoide e|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||revisões sistemáticas<br>anteriores com meta-<br>análise de ensaios|||durando de 15 a 90<br>minutos.|exercício; e boa qualidade<br>metodológica global de cada<br>meta-análise, conforme|lúpus eritematoso<br>sistêmico;|
||clínicos<br>randomizados ou||||avaliada pelo instrumento<br>AMSTAR;|- Exercício menos as<br>reduções no grupo|
||dados de ECRs|||||controle quanto aos|
||relatados|||||sintomas|
||separadamente se a|||||depressivos foram|
||meta-análise incluiu|||||encontrados para|
||estudos com outros|||||ambas as meta-|
||desenhos; adultos de|||||análises (SMD, -|
||18 anos ou mais com|||||0,61, IC de 95%, -|
||osteoartrite, artrite|||||0,99 a -0,23, p =|
||reumatóide,|||||0,002; SMD, -0,32,|
||fibromialgia ou lúpus<br>eritematoso|||||IC 95%, -0,53 a -<br>0,12, p = 0,002).|
||sistêmico, conforme|||||Melhoras|
||definido pelos|||||percentuais (U3)|
||critérios de inclusão|||||foram equivalentes a|
||dos autores das meta-|||||22,9 e 12,6. O|
||análises originais;|||||número necessário|
||intervenção (ões)|||||para tratar foi de 6 e|
||envolvendo|||||9, com estimativa de|
||treinamento aeróbico|||||0,83 e 0,56 milhões|
||ou de força com|||||de pessoas com|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||duração média de<br>pelo menos 4<br>semanas; estudos<br>publicados e não<br>publicados<br>(dissertações e teses<br>de mestrado) em<br>qualquer idioma;<br>exercício menos a<br>diferença do grupo<br>controle quanto a<br>sintomas depressivos<br>sendo o desfecho<br>primário na meta-<br>análise original e<br>relatado como a<br>diferença média<br>padronizada (SMD);|||||fibromialgia<br>potencialmente<br>sendo beneficiadas;<br>-  Os achados gerais<br>das meta-análises<br>incluídas se<br>comparam bastante<br>favoravelmente aos<br>efeitos das<br>intervenções<br>medicamentosas<br>sobre os sintomas<br>depressivos em<br>adultos<br>com fibromialgia<br>verificados em<br>outros estudos.|
||**- Objetivo:**realizar<br>uma revisão<br>sistemática de meta-<br>análises anteriores<br>sobre os efeitos do<br>exercício (aeróbico,||||||  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||musculação ou<br>ambos) nos sintomas<br>depressivos em<br>adultos com<br>osteoartrite, artrite<br>reumatoide,<br>fibromialgia e LES||||||
|_Management of_<br>_cardiovascular risk in_|- Revisão sistemática;|**- Número de**<br>**estudos incluídos:**||-**Intervenções:**<br>promoção da saúde|-**Primários:**eventos<br>cardiovasculares fatais e não-|Dieta hipocalórica<br>ou com baixo índice|
|_systemic lupus_<br>_erythematosus: a_<br>_systematic review_,|**- Período da busca:**<br>até dezembro de<br>2015;|19 (1 transversal, 3<br>coortes, 3 caso-<br>controle, 4 ensaios||(dieta, exercícios e<br>cessação do<br>tabagismo);|fatais (infarto do miocárdio,<br>angina instável,_by-pass_<br>coronário ou angioplastia|glicêmico pode ser<br>uma opção útil para<br>prevenção|
|2017.|**- Bases consultadas:**<br>_Medline_e_Embase_;<br>**- Critérios de**<br>**elegibilidade:**meta-<br>análises, revisões<br>sistemáticas, ECR,<br>fase II, III e IV,<br>ensaios clínicos não-<br>randomizados e não-<br>controlados e estudos<br>observacionais|clínicos não-<br>randomizados, 5<br>ECR, 1 revisão<br>sistemática e 2 meta-<br>análises);<br>**- Número de**<br>**participantes:**<br>10236 (variando de 8<br>a 4095).<br>População:<br>- Pacientes adultos||fármacos (terapia<br>hipolipemiante,<br>tratamento<br>antiplaquetário,<br>anticoagulante e<br>antihipertensivo);<br>tratamento<br>específico para<br>LES<br>(antimaláricos);|coronária percutânea, acidente<br>vascular encefálico e doença<br>arterial periférica);<br>-**Secundários:**mortalidade e<br>mudanças nos principais<br>fatores de risco<br>cardiovasculares (pressão<br>arterial sistólica e diastólica,<br>IMC, circunferência<br>abdominal, cálcio coronariano,<br>níveis de glicose, resistência|secundária em<br>pacientes obesos<br>com LES, e<br>exercício físico pode<br>melhorar a função<br>endotelial, medida<br>por dilatação fluxo-<br>mediada, nesse<br>grupo de pacientes.<br>O uso de<br>medicamentos<br>hipolipemiantes|
||(transversal, coorte e|com LES ou|||insulínica [HOMA-IR], LDL,|pode melhorar o|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||caso-controle)<br>avaliando a<br>efetividade de<br>intervenções para<br>promoção da saúde<br>em pacientes adultos<br>com lúpus<br>eritematoso sistêmico<br>(LES) ou pacientes<br>com síndrome<br>antifosfolípide<br>secundária ao LES. A<br>busca foi restringida a<br>artigos em inglês,<br>francês e espanhol;<br>**- Objetivo:**avaliar a<br>efetividade de<br>intervenções para<br>prevenção primária e<br>secundária de eventos<br>cardiovasculares e<br>mortalidade e,<br>também, a efetividade<br>de intervenções para|pacientes com<br>síndrome<br>antifosfolípide<br>secundária ao LES.||**- Tempo de**<br>**tratamento:**não<br>especificado;<br>**- Tempo de**<br>**seguimento:**<br>variou de 6<br>semanas a 16 anos<br>nos estudos<br>longitudinais.|colesterol, HDL e dilatação<br>fluxo-mediada).|perfil lipídico em<br>pacientes com LES e<br>hiperlipidemia, mas<br>o efeito desse<br>tratamento na<br>mortalidade<br>cardiovascular<br>permanece<br>desconhecido.<br>Antiplaquetários,<br>anticoagulantes,<br>antimaláricos e<br>medicamentos<br>hipolipemiantes<br>podem ser efetivas<br>na prevenção<br>primária e<br>secundária de<br>eventos<br>cardiovasculares<br>como infarto do<br>miocárdio ou<br>acidente vascular<br>encefálico. Nesse<br>sentido,|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||redução do fator de<br>risco cardiovascular<br>em pacientes com<br>LES.|||||hipolipemiantes e<br>antimaláricos<br>parecem reduzir os<br>níveis séricos de<br>colesterol total,<br>LDL, glicose,<br>pressão arterial<br>diastólica e<br>deposição de cálcio<br>nas artérias<br>coronárias. Esses<br>medicamentos<br>também podem<br>melhorar resistência<br>insulínica e o nível<br>de HDL.<br>O tratamento com<br>antihipertensivos<br>reduz a pressão<br>sanguínea.|
|_Efficacy and Safety of_|- Revisão sistemática|**- Número de**||-**Intervenções:**|**- Eficácia:**escore SELENA-|Eficácia|
|_Biologic Therapies_<br>_for Systemic Lupus_|e meta-análise;|**estudos incluídos:**<br>13;||**-**belimumabe (1 e<br>10 mg/kg IV nos|SLEDAI, SRI (_Systemic Lupus_<br>_Erythematosus Responder_|belimumabe:<br>- Resultados|
|_Erythematosus_<br>_Treatment:_|**- Período da busca:**<br>até setembro de 2013;|**- Número de**<br>**participantes:**não||dias 0, 14, 28, e<br>então a cada 28|_Index_), normalização do C3<br>baixo (<90 mg/dL),_anti_-|significativos de<br>eficácia de|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|_Systematic Review_||especificado.||dias, como infusão|_dsDNA positivo para negativo_|belimumabe 1|
|_and Meta-Analysis,_|**- Bases consultadas:**|**- População:**||única, ou como|_e nenhum novo BILAG_(_British_|mg/kg na semana 52|
|2013.|_MEDLINE, Cochrane_<br>_Library, SCIELO,_<br>_Scopus,_ _International_<br>_Pharmaceutical_<br>_Abstracts_;<br>**- Critérios de**<br>**elegibilidade:**ECR<br>duplo-cegos e<br>controlados por<br>placebo - publicados<br>em inglês, alemão,<br>português ou|Pacientes adultos<br>com LES.||duas infusões<br>separadas por 21<br>dias)_vs._placebo;<br>- rituximabe (1.000<br>mg IV nos dias 1,<br>15, 168, e 182)_vs._<br>placebo;<br>- outros agentes<br>biológicos<br>(abétimo sódico,<br>atacicepte,<br>abatacepte,|_Isles Lupus Assessment Group_<br>_index_)_1A ou 2B;_<br>**- Segurança:**eventos<br>adversos, eventos adversos<br>sérios e graves, morte,<br>malignidade, infecções,<br>reações às infusões e abandono<br>ao tratamento devido à falta de<br>eficácia ou eventos adversos.|em relação ao SRI,<br>redução do C4 no<br>escore SELENA-<br>SLEDAI,<br>normalização do C3,<br>negativação do anti-<br>dsDNA e_nenhum_<br>_novo BILAG 1A ou_<br>_2B.  Foi detectada_<br>_alta_<br>_heterogeneidade_(I<sup>2</sup><br>= 60 %) entre os|
||espanhol -<br>comparando terapias<br>biológicas com|||sifalimumabe e<br>epratuzumabe);||estudos, com análise<br>de sensibilidade<br>indicando um dos|
||placebo em pacientes|||**- Tempo de**||estudos como o|
||adultos com LES<br>recebendo cuidado<br>padrão (prednisona,<br>antimalárico e<br>medicamentos|||**tratamento:**vide<br>Intervenções;<br>**- Tempo de**<br>**seguimento:**não||responsável; após<br>remoção do estudo<br>em questão da<br>análise, I<sup>2</sup>reduziu<br>para 33 %).|
||imunossupressores).|||especificado.||- Resultados|
||**- Objetivo:**avaliar a|||||significativos de|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||eficácia, segurança e<br>tolerabilidade dos<br>medicamentos<br>biológicos comparado<br>com placebo para o<br>tratamento de LES.|||||belimumabe 10<br>mg/kg na semana 52<br>em relação aos<br>mesmos desfechos.<br>Também_foi_<br>_detectada alta_<br>_heterogeneidade_(I<sup>2</sup><br>= 78 %) entre os<br>estudos, mas análise<br>de sensibilidade não<br>indicou um estudo<br>como sendo o<br>responsável.|
|||||||Segurança de<br>belimumabe:<br>- Não foram<br>observadas<br>diferenças<br>significativas entre<br>belimumabe (1 e 10<br>mg/kg) e placebo,<br>indicando que o<br>medicamento tem|
|||||||bom perfil de|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||segurança. Também<br>não foram<br>observadas<br>diferenças<br>significativas de<br>abandono ao|
|||||||tratamento. Não foi<br>detectada<br>heterogeneidade<br>entre os estudos com<br>relação aos<br>desfechos de<br>segurança de<br>belimumabe em|
|||||||ambas as doses (I<sup>2</sup>=<br>0%).|
|||||||Eficácia rituximabe:<br>-Não houve<br>diferenças|
|||||||significativas entre<br>rituximabe e<br>placebo. Não foi<br>detectada|
|||||||heterogeneidade|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||entre os estudos (I<sup>2</sup><br>= 0%).<br>Segurança<br>rituximabe:<br>- Não foram<br>observadas<br>diferenças<br>significativas entre<br>rituximabe e<br>placebo, indicando<br>que o medicamento<br>tem bom perfil de<br>segurança. Não foi<br>detectada<br>heterogeneidade<br>entre os estudos (I<sup>2</sup><br>= 0%).|
|||||||Eficácia de outros<br>agentes biológicos:<br>- Abétimo sódico (1<br>estudo de fase II e 1<br>de fase III):<br>capacidade de|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||reduzir anticorpos<br>anti-dsDNA,<br>melhorar atividade<br>clínica da doença e<br>aumentar as<br>concentrações<br>médias de C3. Além<br>disso, acredita-se<br>que seja eficaz em<br>prolongar o tempo<br>de exacerbação da<br>doença renal.<br>- Atacicepte:<br>resultados<br>promessores<br>observados nos<br>níveis de<br>complemento e<br>escores SELENA-<br>SLEDAI.<br>Resultados sugerem<br>que o medicamento<br>pode ter atividade<br>clínica no LES.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||- Sifalimumabe (2<br>estudos de fase I):<br>resultados indicam<br>que o medicamento<br>pode promover<br>melhora<br>significativa do<br>LES.<br>- Epratuzumabe<br>(estudo de fase IIb):<br>resultados sugerem<br>que o medicamento<br>pode melhorar a<br>atividade da doença.|
|||||||Segurança de outros<br>agentes biológicos:<br>- Não foram<br>observadas<br>diferenças<br>significativas entre<br>os agentes<br>biológicos e<br>placebo, indicando<br>que essas terapias|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||podem ter bom<br>perfil de segurança.|
|_Treatment for lupus_|- Revisão sistemática|**- Número de**||**- Intervenções:**|**- Eficácia:**taxa de remissão|Terapia de indução:|
|_nephritis: an_|e meta-análise;|**estudos incluídos:**||Das 22 meta-|completa; taxa de remissão|- Tacrolimo +|
|_overview of_||24 (3 meta-análises||análises, 11|parcial; taxa de resposta total;|micofenolato|
|_systematic reviews_|**- Período da busca:**|em rede, 19 meta-||focaram na terapia|taxa de função renal estável;|mostrou maior taxa|
|_and meta-analyses,_|até 13 de julho de|análises, 2 revisões||de indução e 3 na|taxa de remissão de|de remissão|
|2017.|2016;|sistemáticas; 17||terapia de|proteinuria; nível de|completa (RR =|
|||estudos incluíram||manutenção; as|proteinuria em 24h; nível|4,33, IC95% 1,45–|
||**- Bases consultadas:**|somente ECR,||demais não|sérico de creatinina; nível|12,91), taxa de|
||_OVID MEDLINE,_|enquanto os demais||especificaram|sérico de albumina; taxa de|resposta total (RR =|
||_OVID EMBASE,_|incluíram estudos||estágio.|remissão da creatinina sérica;|1,37, IC95% 1,14–|
||_Cochrane Library_;|observacionais);|||taxa de doença renal terminal;|1,63), taxa de função|
||**- Critérios de**|||- Terapia de|taxa de recaída renal; falha em|renal estável (RR =|
||**elegibilidade:**|**- Número de**||indução: tacrolimo|induzir remissão; taxa de|1,73, IC95% 1,15–|
||revisões sistemáticas|**participantes:**não||+ micofenolato vs.|remissão sustentada; taxa de|2,60) e taxa de|
||e meta-análises|especificado.||ciclofosfamida;|insuficiência renal;|remissão de|
||publicadas de ECR e|**População:**||inibidores da||proteinúria (RR =|
||estudos|Pacientes adultos||calcineurina vs.|**- Eventos adversos:**função|4,33, IC95% 1,45–|
||observacionais|com LES.||ciclofosfamida;|anormal do fígado; infecção;|12,91) do que|
||avaliando tratamentos|||tacrolimo vs.|aumento da creatinina sérica;|ciclofosfamida;|
||para nefrite lúpica|||ciclofosfamida;|alteração da glicose; sintomas||
||sem restrição de|||micofenolato vs.|gastrointestinais; amenorreia;|- Inibidores da|
||agentes terapêuticos.|||ciclofosfamida;|leucopenia; alopecia;|calcineurina|
||Foram incluídos|||leflunomida vs.|hipertensão; mortalidade;|aumentaram|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||somente estudos<br>publicados em inglês.|||ciclofosfamida;<br>inibidores da<br>calcineurina vs.|infecção grave; falência<br>ovariana; infecção por herpes<br>zoster (HZV); doença renal|significativamente a<br>taxa de remissão<br>completa (RR =|
||**- Objetivo:**revisar o<br>tratamento de nefrite|||micofenolato;<br>tacrolimo vs.|terminal ou morte;_rash;_<br>interrupção devido a eventos|1,56, IC95% 1,14–<br>2,15) e taxa de|
||lúpica analisando|||micofenolato;|adversos; pneumonia;|resposta total (RR =|
||revisões sistemáticas|||plasmaferese +|admissão hospitalar.|1,23, IC95% 1,07–|
||e meta-análises.|||imunossupressor||1,42) e reduziu a|
|||||vs.||incidência de|
|||||imunossupressor;||sintomas|
|||||ciclofosfamida IV||gastrointestinais,|
|||||vs. ciclofosfamida||amenorreia e|
|||||oral;||leucopenia|
|||||ciclofosfamida vs.||comparado a|
|||||azatioprina; dose||ciclofosfamida;|
|||||alta vs. dose baixa|||
|||||de ciclofosfamida;||- 6 estudos relataram|
|||||ciclofosfamida vs.||que tacrolimo foi|
|||||ciclosporina A;||superior a|
|||||ciclofosfamida +||ciclofosfamida em|
|||||corticosteroide vs.||termos de taxa de|
|||||corticosteroide;||remissão completa|
|||||||(RR = 1,61, IC95%|
|||||- Terapia de||1,17–2,23; RR =|
|||||manutenção:||1,59, IC95% 1,16–|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||micofenolato vs.<br>azatioprina;<br>azatioprina vs.<br>ciclofosfamida;<br>azatioprina vs.<br>ciclosporina A;<br>dose alta vs. dose<br>baixa de<br>ciclofosfamida IV;<br>micofenolato vs.<br>ciclofosfamida;<br>prednisona vs.<br>ciclofosfamida;<br>inibidores da<br>calcineurina vs.<br>azatioprina;<br>- Terapia de<br>indução ou<br>manutenção:<br>micofenolato vs.<br>ciclofosfamida;<br>ciclofosfamida +<br>esteroides vs.<br>esteroides;||2,19; RR = 1,52,<br>IC95% 1,06–2,17),<br>taxa de resposta total<br>(RR = 1,25, IC95%<br>1,09–1,44; RR =<br>1,23, IC95% 1,07–<br>1,41; OR = 2,35,<br>IC95% 1,03–5,45;<br>RR = 1,22, IC95%<br>1,05–1,41) e taxa de<br>negativação do anti-<br>dsDNA (RR = 1,34,<br>IC95% 1,01–1,78).<br>Tacrolimo também<br>levou a menos<br>eventos adversos<br>gastrointestinais e<br>amenorreia do que<br>ciclofosfamida;<br>- 10 estudos<br>relataram que<br>micofenolato teve<br>maior taxa de<br>resposta total (RR =<br>1,19, IC95% 1,00–|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||azatioprina +<br>esteroides vs.<br>esteroides;||1,43; RR = 1,18,<br>IC95% 1,04–1,35) e<br>menores taxas de|
|||||plasmaferese +||leucopenia, falência|
|||||imunossupressor||ovariana e alopecia|
|||||vs.||comparado a|
|||||imunossupressor;||ciclofosfamida;|
|||||ciclofosfamida vs.||- Não houve|
|||||azatioprina;||diferença na eficácia|
|||||ciclofosfamida +||e eventos adversos|
|||||azatioprina +||entre tacrolimo e|
|||||esteroides vs.<br>esteroide;||micofenolato;|
|||||ciclosporina A +||Terapia de|
|||||esteroides vs.||manutenção:|
|||||esteroides;||- 6 estudos relataram<br>que micofenolato|
|||||**- Tempo de**||levou a menores|
|||||**tratamento:**não||taxas de recaída (RR|
|||||especificado;||= 0,70, IC95% 0,49–|
|||||**- Tempo de**||1,00; RR = 0,55,|
|||||**seguimento:**não||IC95% 0,37– 0,81;|
|||||especificado.||RR = 0,69, IC95%|
|||||||0,48–1,00) e de|
|||||||leucopenia (RR =|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||0,12, IC95% 0,04-<br>0,39; RR = 0,16,<br>IC95% 0,04– 0,59;<br>IRR = 0,14, IC95%<br>0,05–0,42)<br>comparado a<br>azatioprina,<br>enquanto nenhuma<br>diferença nas taxas<br>de doença renal<br>terminal e<br>mortalidade foi<br>detectada.|
|_B-Cell Targeted_<br>_Therapies in Systemic_|- Artigo de revisão;|**- Número de**<br>**estudos incluídos:**-|-|-**Intervenções:**<br>**-**Rituximabe<br>-||- Revisões<br>sistemáticas de|
|_Lupus_|**- Período da busca:**-|**- Número de**||(anticorpo||estudos abertos,|
|_Erythematosus,_||**participantes:**-||monoclonal||especialmente em|
|_Successes and_|**- Bases consultadas:**|||quimérico anti-||pacientes com LES|
|_Challenges_, 2013.|-<br>**- Critérios de**<br>**elegibilidade:**-<br>**- Objetivo:**discutir|||CD20 que depleta<br>as células B, mas<br>não as células<br>plasmáticas);||refratário à terapia<br>convencional,<br>sugerem que<br>rituximabe pode ser|
||quatro terapias que|||- Belimumabe||efetivo para lúpus|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||têm como alvo as<br>células B (rituximabe,<br>belimumabe,<br>atacicepte e<br>epratuzumabe).|||(anti-corpo<br>monoclonal<br>humanizado contra<br>o estimulador de<br>linfócitos B);<br>- Atacicepte<br>(proteína de fusão<br>humanizada que se<br>liga ao estimulador<br>de linfócitos B<br>[BLys] e APRIL<br>[ligante indutor de<br>proliferação]);<br>- Epratuzumabe<br>(anticorpo<br>monoclonal<br>humanizado que<br>tem como alvo o<br>CD22 em células<br>B, resultando na<br>modulação da<br>função e migração<br>de células B, já que<br>o CD22 regula a<br>adesão e inibe a||com ou sem<br>acometimento renal.<br>Entretanto, ECR<br>duplo-cegos<br>comparando<br>rituximabe com<br>placebo em adição<br>ao tratamento<br>padrão longo de 12<br>meses falharam em<br>demonstrar eficácia<br>usando os desfechos<br>primários<br>planejados, embora<br>algumas análises<br>_post-hoc_tenham<br>sugerido que<br>rituximabe possa ter<br>efeitos beneficos<br>que merecem mais<br>estudos, já que não<br>foi demonstrada<br>toxicidade<br>significativa.|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||sinalização do<br>receptor de células<br>B);<br>**- Tempo de**<br>**tratamento:**-<br>**- Tempo de**<br>**seguimento:**-||- Tratamento com<br>belimumabe foi<br>mais eficaz do que<br>placebo e não<br>mostrou aumento<br>significativo dos<br>eventos adversos em<br>2 estudos de fase III<br>com pacientes não-<br>renais quando<br>administrado junto<br>ao tratamento<br>padrão por 52<br>semanas.<br>- Atacicepte pode<br>ser mais eficaz do<br>que belimumabe no<br>tratamento do lupus;<br>porém, um estudo de<br>fase II/III com<br>atacicepte na nefrite<br>lúpica teve de parar<br>devido a baixos<br>níveis de<br>imunoglobulinas e|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||de pneumonias em<br>alguns pacientes. No<br>entanto, essas<br>complicações podem<br>ter sido decorrentes<br>do tratamento<br>concomitante com<br>micofenolato, e<br>resultados de um<br>estudo de fase III de<br>52 semanas com<br>pacientes não-renais<br>é esperado;<br>- Epratuzumabe em<br>dose cumulativa de<br>2.400 mg ao longo<br>de 4 semanas<br>mostrou melhorar a<br>atividade da doença<br>comparado a<br>placebo 12 semanas<br>após início da<br>terapia em estudo de<br>fase II e na fase III<br>de um estudo de 12|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||meses em<br>andamento.|
|_Immunogenicity and_|- Revisão sistemática|**- Número de**||-**Intervenções:**|- Imunogenicidade: taxa de|- Comparando com a|
|_Safety of Influenza_|e meta-análise;|**estudos incluídos:**|||soroproteção; taxa de|população em geral,|
|_Vaccination in_||18 (todos estudos de||**-**7 estudos|soroconversão; fatores que|a taxa de|
|_Systemic Lupus_|**- Período da busca:**|coorte comparando||utilizaram vacina|aumentam o título geométrico|soroproteção em|
|_Erythematosus_|até abril de 2015;|pacientes com LES||trivalente contendo|médio do anticorpo (GMT);|pacientes com LES|
|_Patients Compared_||com população||os antígenos de|- Segurança: eventos adversos,|foi|
|_with Healthy_|**- Bases consultadas:**|saudável);||superfície dos|incluindo eventos adversos e|significativamente|
|_Controls: A Meta-_|_PubMed, Embase,_|**- Número de**||vírus influenza|exacerbações do LES.|menor em pacientes|
|_Analysis,_2016.|_Cochrane Library,_<br>_China National_|**participantes:**1966<br>pacientes com LES e||H1N1, H3N2 e B;||com vacinas<br>H1N1(OR = 0,36,|
||_Knowledge_|1112 indivíduos||- 10 estudos||IC95% 0,27–0,50) e|
||_Infrastructure_|saudáveis||usaram vacina||H3N2 (OR = 0,48,|
||(CNKI) e_Science_|-População: um total||univalente||IC95% 0,24–0,93),|
||_Direct_;|de 1106 pacientes||contendo cepa||mas não vacina|
||**- Critérios de**|com escore SLEDAI||semelhante ao||influenza B (OR =|
||**elegibilidade:**|baixo a moderado ou||vírus H1N1;||0,55, IC95% 0,24–|
||estudos de pacientes|doença estável foram||- 1 Estudo utilizou||1,25);|
||com LES que|relatados nos estudos||vacina bivalente||- A taxa de|
||receberam vacina|originais.||H1N1/H3N2;||soroconversão|
||influenza; estudos|||**- Tempo de**||também reduziu|
||com resultados de|||**tratamento:**-||significativamente|
||título de anticorpo|||||em pacientes com|
||contra o vírus|||**- Tempo de**||vacinas H1N1 (OR|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||influenza, medido<br>pelo teste de inibição<br>da hemaglutinação<br>(HAI); estudos de<br>coorte;<br>**- Objetivo:**avaliar a<br>imunogenicidade e<br>segurança da vacina<br>influenza em<br>pacientes com LES.|||**seguimento:**não<br>especificado.||= 0,39, IC95% 0,27–<br>0,57) e influenza B<br>(OR = 0,47, IC95%<br>0,29–0,76), mas não<br>vacina H3N2 (OR =<br>0,62, IC95% 0,21–<br>1,79);<br>- Entretanto, a<br>imunogenicidade da<br>vacina influenza em<br>pacientes com LES<br>quase alcançou a dos<br>_guidelines_CPMP;<br>- OR para eventos<br>adversos (pacientes<br>_vs._controles<br>saudáveis) foi de<br>3,24 (IC95% 0,62–<br>16,76);<br>- Entre 1966<br>pacientes com LES,<br>32 experimentaram<br>exacerbação leve do<br>LES e 5 tiveram<br>eventos adversos|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||sérios por outras<br>razões.|
|_A Meta-Analysis of_<br>_Randomized_<br>_Controlled Trials_<br>_Comparing_|- Meta-análise de<br>ECR;<br>**- Período da busca:**|**- Número de**<br>**estudos incluídos:**5;<br>**- Número de**<br>**participantes:**255.||-**Intervenções:**<br>- Ciclofosfamida<br>IV (CYCIV);<br>- Tacrolimo (oral|**Eficácia: t**axas de resposta e<br>de remissão; proteínas na<br>urina; albumina sérica; taxa de<br>conversão negativa do anti-|- Tacrolimo<br>aumentou<br>significativamente<br>remissão completa|
|_Tacrolimus with_<br>_Intravenous_|até novembro de<br>2011;|**-População:**203<br>mulheres e 52||ou IV);|dsDNA; C3 sérica; SLE-DAI;|(RR 1,61; IC95%<br>1,17-2,23; p=0,004),|
|_Cyclophosphamide in_||homens, todos||**- Tempo de**|**Segurança:**eventos adversos.|taxa de resposta (RR|
|_the Induction_|**- Bases consultadas:**|chineses;||**tratamento:**não||1,25; IC95% 1,09-|
|_Treatment for Lupus_<br>_Nephritis,_2012.|PUBMED,<br>EMBASE,_Cochrane_<br>_Central Register of_<br>_Controlled Trials,_<br>_China Biology_<br>_Medicine Databse,_<br>_China National_<br>_Knowledge_<br>_Infrastructure_<br>_Databse;_<br>**- Critérios de**<br>**elegibilidade:**ECR<br>de pacientes com<br>LES e nefrite lúpica<br>classes III, IV, V,|- Idade média dos<br>participantes entre os<br>estudos variou de 24<br>a 33 anos.||especificado;<br>**- Tempo de**<br>**seguimento:**6<br>meses.||1,44; p=0,001),<br>nível de albumina<br>sérica (SMD 1,11;<br>IC95% 0,17-2,06;<br>p=0,02) e taxa de<br>conversão negativa<br>do anti-dsDNA (RR<br>1,34; IC95% 1,01-<br>1,78; p=0,04) e<br>reduziu proteínas na<br>urina (SMD -0,52;<br>IC95% -0,83 a -<br>0,22; p=0,0008),<br>SLE-DAI (systemic<br>lupus erythematosus|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||V+III ou V+IV<br>comparando eficácia<br>e segurança de<br>tacrolimo com<br>ciclofosfamida IV;<br>**- Objetivo:**comparar<br>a eficácia e segurança<br>entre tacrolimo (oral<br>ou IV) e<br>ciclofosfamida IV no<br>tratamento de indução<br>da nefrite lúpica.|||||disease activity<br>índex) (SMD -0,59;<br>IC95% -1,00 a -<br>0,19; p=0,004)<br>comparado a<br>ciclofosfamida IV.<br>- As taxas de<br>sintomas<br>gastrointestinais e<br>irregularidade<br>menstrual (ou<br>amenorreia) foram<br>significativamente<br>menores no grupo<br>tacrolimo do que no<br>grupo<br>ciclofosfamida IV<br>(RR 0,46; IC95%<br>0,22-0,93; p=0,03 e<br>RR 0,14; IC95%<br>0,04-0,5; p=0,003).<br>As taxas de<br>leucopenia,<br>infecção, alopecia,|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||||alteração de função<br>hepática, aumento<br>de creatinina sérica,<br>hipertensão e<br>hiperglicemia foram<br>similares entre os<br>dois grupos de<br>tratamento.|
|_The Effectiveness of_<br>_Exercise in Adults_<br>_with Systemic Lupus_|- Revisão sistemática<br>e meta-análise;|**- Número de**<br>**estudos incluídos:**3<br>(2 ECR e 1 estudo de||-**Intervenções:**<br>foram aplicados<br>exercícios físicos|- Foram utilizadas 4 escalas de<br>fadiga para avaliar a fadiga dos<br>pacientes com LES:_Fatigue_|- Exercícios físicos<br>aeróbicos<br>diminuíram|
|_Erythematosus: A_<br>_Systematic Review_<br>_and Meta-Analysis to_<br>_Guide Evidence-_<br>_Based Practice,_2017.|**- Período da busca:**<br>até 3 de fevereiro de<br>2016;<br>**- Bases consultadas:**<br>MEDLINE,<br>CINAHL, PEDro<br>(_Physiotherapy_<br>_Evidence Database_),<br>_Cochrane Library_,<br>_Scopus_e PQDT<br>(_ProQuest Dis-_<br>_sertations and_<br>_Theses_);|quasi-experimento);<br>**- Número de**<br>**participantes:**163.<br>- População:<br>pacientes com LES<br>entre 19 e 65 anos de<br>idade;<br>- Idade média dos<br>participantes entre 34<br>e 43 anos.||de intensidade<br>moderada; os<br>componentes do<br>treinamento<br>incluíram<br>frequência do<br>treinamento,<br>intensidade, tipo de<br>exercício e a<br>duração dos<br>exercícios por<br>sessão;<br>- O exercício<br>aeróbico,|_Severity Scale_(FSS),_Visual_<br>_Analogue Scale_(VAS),<br>_Chalder Fatigue Scale_(CFS) e<br>_Short Form-36_(SF-36).|significativamente a<br>gravidade da fadiga<br>(MD= –0,52, IC95<br>[–0,91, –0,13],_p_=<br>0,009), mas<br>exercícios de<br>relaxamento não<br>mostraram essa<br>associação (MD =<br>0,00, IC95% [–0,63,<br>0,63],_p_= 1,00);<br>- O efeito do<br>treinamento a longo-<br>prazo (12 semanas;|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
||**- Critérios de**<br>**elegibilidade:**ECR,|||3x/semana e de<br>intensidade||MD = –0,68, IC95%<br>[–1,2, –0,17],_p_=|
||ensaios clínicos e|||moderada foi||0,009) foi maior do|
||estudos de quasi-|||comum aos 3||que o efeito de|
||experimento|||estudos incluídos;||curto-prazo (8|
||publicados em inglês;|||- 2 estudos foram||semanas; MD = –|
||**- Objetivo:**revisar e|||conduzidos em um||0,31, IC95% [–0,91,|
||sintetizar o|||ambiente||0,29],_p_= 0,31);|
||conhecimento atual|||supervisionado e 1||- A análise de|
||sobre a efetividade de|||estudo foi||subgrupos mostrou|
||exercícios físicos no|||realizado em||que os exercícios|
||tratamento da fadiga|||ambiente||supervisionados|
||entre adultos com|||domiciliar;||reduziram os|
||LES.|||**- Tempo de**||sintomas de fadiga|
|||||**tratamento:**a||em uma extensão|
|||||duração mínima de||significativamente|
|||||exercícios por||maior do que os|
|||||sessão foi de 20||exercícios|
|||||minutos, enquanto||domiciliares (MD =|
|||||a máxima foi de 50||–0,53,_p_= 0,03,|
|||||minutos;||IC95% [–1,00, –|
|||||||0,06]; MD = –0,50,|
|||||**- Tempo de**||_p_= 0,16, IC95% [–|
|||||**seguimento:**todos||1,21, 0,21],|
|||||os estudos||respectivamente);|  
|**Título do artigo/ano**|**Desenho**|**Amostra**|**Intervenção/**<br>**controle**|**Desfechos**|**Resultados**|**Limitações/**<br>**considerações**|
|---|---|---|---|---|---|---|
|||||implementaram<br>sessões de<br>exercícios<br>3x/semana. No<br>estudo de_Ramsey-_<br>_Goldman et al_.<br>(2000), os<br>exercícios foram<br>mantidos por 8<br>semanas, havendo<br>depois uma<br>segunda fase com<br>duração de 6<br>meses. Os dois<br>estudos restantes<br>duraram 12<br>semanas cada.||- Houve efeito<br>positivo dos<br>exercícios aeróbicos<br>na vitalidade no SF-<br>36 (MD = 14,98,<br>IC95% [7,45,<br>22,52], p <0,001).|

---

