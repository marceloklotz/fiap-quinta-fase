<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
PORTARIA CONJUNTA SAES/SCTIE Nº 27, DE 27 DE NOVEMBRO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Alzheimer.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E**  
**INOVAÇÃO EM SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 04 de junho de 2025, e  
Considerando a necessidade de se atualizarem os parâmetros sobre a Doença de Alzheimer no Brasil e as diretrizes nacionais para  
diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 1051/2025 e o Relatório de Recomendação nº 1051/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença de Alzheimer.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da Doença de Alzheimer, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Doença de Alzheimer.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta nº 13, de 28 de novembro de 2017, publicada no Diário Oficial da União (DOU) nº 235, em 8 de dezembro de 2017, seção 1, página 201.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
FERNANDA DE NEGRI  
MOZART JULIO TABOSA SALES  
1

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A demência é uma condição caracterizada pelo comprometimento de diversos domínios cognitivos, como memória, julgamento, desorientação e confusão, resultando em um declínio funcional significativo do indivíduo 1. Estes comprometimentos têm implicações diretas na qualidade de vida da pessoa que vive com demência, aumentando o ônus para famílias e a sociedade em geral<sup>2</sup> .  
Atualmente, aproximadamente 50 milhões de pessoas em todo o mundo vivem com demência, sendo registrados cerca de 10 milhões de novos casos a cada ano<sup>3</sup> . Estima-se que a incidência de demência aumenta com a idade, duplicando a cada cinco anos<sup>4</sup> . Entre 1990 e 2018, estudos populacionais realizados na Ásia, Europa, América do Norte, África e América do Sul, indicam que 80 em cada 10.000 pessoas entre 50 e 59 anos viviam com demência, esse número aumenta para 3.572 em cada 10.000 entre aqueles com 90 a 99 anos<sup>4</sup> . De acordo com o Ministério da Saúde, a prevalência média de demência na população brasileira com 60 anos ou mais correspondeu a 8,5% em 2019, sendo 9,1% entre as mulheres e 7,7% entre os homens<sup>5</sup> .  
A Doença de Alzheimer (DA) é a principal causa de demência, abrangendo até 70% dos casos mundiais<sup>6</sup> e cerca de 60% desses casos no Brasil<sup>7</sup> . O desenvolvimento e progressão da DA ocorre devido a alterações cerebrais que resultam em um declínio cognitivo progressivo, que, nas fases iniciais pode ser sutil, e à medida que evolui, os sintomas tornam-se mais evidentes comprometendo a capacidade do indivíduo de realizar atividades diárias<sup>1</sup> .  
O desenvolvimento da DA pode ser descrito como um _continuum_ , composto por três estágios principais: pré-clínica, comprometimento cognitivo leve (CCL) e demência<sup>1</sup> . Nos estágios iniciais, fases pré-clínica e CCL, os sintomas podem não ser tão perceptíveis e não interferir nas atividades diárias. Já a fase de demência é categorizada em leve, moderada e grave. Na fase leve, os indivíduos, apesar dos comprometimentos iniciais associados a memória, linguagem e função executiva, mantêm certa independência; na fase moderada, enfrentam desafios crescentes de memória, linguagem, reconhecimento e orientação; e na fase grave, tornam-se aparentes sintomas como julgamento comprometido, desorientação, confusão, agressão e agitação, bem como outras complicações<sup>1,8,9</sup> , implicando na necessidade de cuidados constantes. O período que um indivíduo passa em cada fase varia e é influenciado por fatores como idade, genética, sexo biológico, entre outros<sup>1</sup> .  
As alterações cerebrais relacionadas ao desenvolvimento e à progressão da DA consistem no acúmulo de peptídeo β- amiloide em placas externas aos neurônios e na fosforilação anormal de proteína tau, com posterior agregação intraneuronal<sup>10</sup> . Estas alterações interferem na comunicação neuronal e no metabolismo celular, desencadeando uma resposta inflamatória crônica e resultando em atrofia cerebral. Esta série de eventos biológicos precede o declínio cognitivo observado em pacientes com DA<sup>10</sup> .  
Os fatores de risco mais importantes para DA são idade avançada, genética (relacionada ao gene da apolipoproteína E - APOE) e histórico familiar de DA<sup>10</sup> . No entanto, é fundamental destacar a relevância dos fatores de risco modificáveis, como baixa escolaridade, perda auditiva, colesterol LDL alto, depressão, traumatismo craniano, sedentarismo, diabetes, tabagismo, hipertensão, obesidade, consumo excessivo de álcool, isolamento social, poluição do ar e perda visual<sup>1,11,12</sup> Esses fatores contribuem para o risco de desenvolvimento da DA, mas também oferecem oportunidades para prevenção e intervenção. No  
2  
contexto do Brasil estima-se que cerca de 60% dos casos poderiam ser evitados ou postergados por meio da redução ou controle desses fatores de risco<sup>12</sup> .  
Devido à importância da sua prevenção, diagnóstico e tratamento no âmbito do Sistema Único de Saúde (SUS), este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da DA, contribuindo para a definição correta, terapia específica e redução da morbidade e mortalidade a ela relacionada. A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária à Saúde um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
- G30.0 – Doença de Alzheimer de início precoce  
- G30.1 – Doença de Alzheimer de início tardio  
- G30.8 – Outras formas de doença de Alzheimer  
- F00.0 – Demência na doença de Alzheimer de início precoce  
- F00.1 – Demência na doença de Alzheimer de início tardio  
- F00.2 – Demência na doença de Alzheimer, forma atípica ou mista

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Para que as pessoas com DA (e seus familiares) recebam o tratamento e cuidados que precisam e que estão disponíveis, é necessário estabelecer que os indivíduos com suspeita possuem diagnóstico provável. De modo geral, as taxas de diagnóstico permanecem baixas em todo o mundo<sup>13</sup> . No Brasil estima-se que apenas 20% dos casos de demência são formalmente diagnosticados, com índices ainda menores nas regiões Norte e Nordeste<sup>14</sup> . As razões para estas altas taxas de subdiagnóstico são inúmeras e incluem, entre outras: a crença equivocada de que perda de memória e outros problemas cognitivos são parte do envelhecimento normal; a negação ou o não reconhecimento dos sinais e sintomas pelos próprios pacientes, familiares e pelos profissionais de saúde. A própria evitação ou o não relato do diagnóstico para pacientes e familiares pelos clínicos pode contribuir para uma normatização do diagnóstico mais tardio, o que deveria ser desestimulado<sup>14,15</sup> .  
A forma predominante da DA é a amnésica que ocorre em 85% dos casos e em que predomina, no início do quadro, o prejuízo da memória episódica, enquanto nas suas formas atípicas pode iniciar com alterações da linguagem, das habilidades visuoespaciais, das funções executivas ou motoras complexas<sup>9</sup> .  
A DA evolui com um declínio cognitivo e de funcionamento nas atividades diárias, apresentando características clínicas distintas com a evolução da doença, trazendo desafios diferentes para o reconhecimento e o diagnóstico nos seus diversos estágios. Nos estágios iniciais da doença, os sintomas podem ser leves e nem sempre perceptíveis. Caracteriza-se particularmente pela progressão dos sintomas amnésicos e outros transtornos cognitivos, como a linguagem, função executiva e orientação tempo-espacial. Os sintomas passam a ser mais fáceis de serem notados no estágio moderado e a pessoa com DA passa a necessitar de mais suporte nas atividades diárias instrumentais. Na fase mais avançada da doença, o paciente fica totalmente dependente, com a memória reduzida, desorientação pessoal, com dificuldades de marcha e, posteriormente, de manter-se sentado e da deglutição, necessitando de ajuda para atividades do autocuidado, como se alimentar, tomar banho e se vestir. Os sintomas neuropsiquiátricos ocorrem em todas as fases da doença e pioram com a sua progressão, sendo também comum a falta  
3  
de reconhecimento pela pessoa com DA dos seus déficits cognitivos<sup>1</sup> . Assim, uma avaliação detalhada, tanto dos domínios cognitivos afetados quanto do funcionamento do paciente nas suas atividades diárias, é fundamental para o diagnóstico clínico.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O comprometimento cognitivo é detectado e diagnosticado mediante a combinação de anamnese com paciente e informante que tenha conhecimento da história do paciente e de avaliação cognitiva objetiva, mediante exame breve das funções cognitivas ou avaliação neuropsicológica. A avaliação neuropsicológica deve ser realizada quando a anamnese e o exame cognitivo breve realizado pelo médico não forem suficientes para permitir um diagnóstico confiável ou não sejam capazes de contribuir para um diagnóstico diferencial com outros transtornos neurocognitivos<sup>9</sup> .  
Recomendam-se<sup>9</sup> a realização dos testes de rastreio e de avaliação neuropsicológica, apresentados nos Quadros 1, 2 e 3 13. A escolha dos testes é critério do profissional de saúde, e de acordo com a necessidade e disponibilidade destes.  
**Quadro 1.** Testes para rastreio cognitivo.  
|**Testes breves**|
|---|
|Mini-Exame do Estado Mental (MEEM)<sup>16,17</sup>|
|_Montreal Cognitive Assessment_(MoCA)<sup>18,19</sup>|
|_Cognitive Abilities Screening Instrument – Short Form_(CASI-S)<sup>20,21</sup>|
|Bateria Breve de Rastreio Cognitivo (BBRC)<sup>22,23</sup>|
|**Baterias multifuncionais**|
|Exame Cognitivo de Addenbrooke – versão revisada (ACE-R)<sup>24,25</sup>|
|_Cambridge Cognitive Examination_– versão revisada (CAMCOG-R)<sup>26–28</sup>|
|_Alzheimer’s Disease Assessment Scale-cognitive subscale_(ADAS-COG)<sup>29,30</sup>|
|_Consortium to Establish a Registry for Alzheimer’s Disease_(CERAD)<sup>31,32</sup>|
|_Mattis Dementia Rating Scale_(MDRS)<sup>33,34</sup>|  
**Fonte:** Adaptado do consenso da Associação Brasileira de Neurologia (ABN)<sup>9</sup> .  
O Ministério da Saúde publicou uma guia para orientar a identificação da população alvo e o rastreio cognitivo inicial na Atenção Primária à Saúde<sup>35</sup> .  
**Quadro 2.** Avaliação dos diferentes domínios cognitivos.  
|**Memória episódica não verbal**|
|---|
|Teste de aprendizado auditivo-verbal de Rey (RAVLT)<sup>36</sup>|
|Subteste de aprendizado de palavras da Bateria CERAD|
|**Memória não verbal**|
|Resgate tardio das 10 figuras da BBRC|
|Subteste de recordação das figuras geométricas da Bateria CERAD|
|Resgate tardio da Figura Complexa de Rey<sup>37</sup>|
|**Linguagem**|
|Fluência verbal (fonêmica e semântica)<sup>38,39</sup>|
|Teste de nomeação de Boston<sup>40,41</sup>|  
4  
**Atenção e função executiva** Span ou extensão de dígitos em ordem direta e inversa<sup>42,43</sup> Teste do desenho do relógio<sup>44,45</sup> Fluência verbal **Habilidades visuais-espaciais / visuais-construtivas** Subteste de cópia das figuras do CERAD / MoCA Teste do desenho do relógio  
**Fonte:** Adaptado do consenso da Associação Brasileira de Neurologia (ABN)<sup>9</sup> .  
**Quadro 3** . Avaliação da funcionalidade.  
**Atividades instrumentais de vida diária** _Functional Activities Questionnaire_<sup>46,47</sup> _Informant Questionnaire on Cognitive Decline in the Elderly_ (IQCODE)<sup>48,49</sup> _Direct Assessment of Functional Status-Revised_ (DAFS-R)<sup>50,51</sup> _Disability Assessment for Dementia_ (DAD)<sup>52,53</sup> _Activities of Daily Living Questionnaire_ (ADL-Q)<sup>54,55</sup> _Bayer Activities of Daily Living Scale_ (B-ADL)<sup>56,57</sup> AD8 _Dementia Screening Interview_<sup>58</sup> **Atividades básicas de vida diária** Katz _scale_<sup>59,60</sup> _Functional Activities Questionnaire_<sup>47,48</sup> **Estadiamento da demência** _Clinical dementia rating scale_ (CDR)<sup>61,62</sup>  
**Fonte:** Adaptado do consenso da Associação Brasileira de Neurologia (ABN)<sup>9</sup> .  
A anamnese com paciente e informante deve focar nas alterações neuropsiquiátricas e cognitivas mais comuns na DA, com o objetivo de diferenciá-la de outras doenças neurodegenerativas e estabelecer o estágio da sua apresentação atual<sup>9</sup> :  
- Memória: caracterizado por comprometimento da capacidade para adquirir ou evocar informações recentes, com sintomas  
que incluem repetição das mesmas perguntas ou assuntos e esquecimento de eventos, compromissos ou do lugar onde guardou seus pertences;  
 Funções executivas: caracterizado por comprometimento do raciocínio, da realização de tarefas complexas e do julgamento, com sintomas como compreensão pobre de situações de risco e redução da capacidade para cuidar das finanças, de tomar decisões e de planejar atividades complexas ou sequenciais;  
 Habilidades visuoespaciais: com sintomas que incluem incapacidade de reconhecer faces ou objetos comuns ou de encontrar objetos no campo visual, ou dificuldade para manusear utensílios ou para vestir-se, inexplicáveis por deficiência visual ou motora;  
 Linguagem (expressão, compreensão, leitura e escrita): com sintomas que incluem dificuldade para encontrar ou compreender palavras, erros ao falar e escrever, com trocas de palavras ou fonemas, inexplicáveis por déficit sensorial ou motor;  
5  
 Alterações neuropsiquiátricas: com sintomas que incluem alterações do humor, agitação, apatia, desinteresse, isolamento social, perda de empatia, desinibição e comportamentos desinibidos obsessivos, compulsivos ou socialmente inapropriados.  
O diagnóstico clínico da DA parte de um diagnóstico sindrômico de demência de qualquer etiologia de acordo com os critérios do _National Institute on Aging and Alzheimer's Association Disease and Related Disorders Association (NIA/AA)_<sup>63</sup> _._ O Quadro 4 apresenta os critérios de doença de Alzheimer provável que são endossados pela Academia Brasileira de Neurologia (ABN)<sup>9</sup> .  
**Quadro 4.** Critérios para demência devido à doença de Alzheimer.  
- **DEMÊNCIA NA DOENÇA DE ALZHEIMER PROVÁVEL** Demência é diagnosticada quando há sintomas cognitivos ou comportamentais (neuropsiquiátricos) que<sup>64</sup> : 1. Interferem com a habilidade no trabalho ou em atividades usuais; 2. Representam declínio em relação a níveis prévios de funcionamento e desempenho; 3. Não são explicáveis por delirium (estado confusional agudo) ou doença psiquiátrica maior; à Todos os critérios de demência acima foram preenchidos, mais as seguintes características: A. início insidioso (meses a anos);  
- B. clara história de perda cognitiva referida pelo informante;  
- C. o déficit cognitivo mais proeminente e inicial é evidente na história e exame em uma das seguintes categorias:  
- Apresentação amnésica: mais comum, deve haver prejuízo no aprendizado e na evocação de informações  
- recentemente aprendidas. - Apresentação não amnésica: prejuízos na linguagem, habilidades visuoespaciais ou função executiva.  
- Linguagem (lembranças de palavras).  
- Visual-espacial (cognição espacial ou agnosia para objetos ou faces e alexia).  
- Funções executivas (alteração do raciocínio, julgamento e solução de problemas).  
- D. Tomografia ou, preferencialmente, ressonância magnética de crânio deve ser realizada para excluir outras  
- possibilidades diagnósticas ou comorbidades, principalmente a doença vascular cerebral. E. Esse diagnóstico não se aplica quando existe evidência de:  
- Doença cerebrovascular importante definida por história de AVC temporalmente relacionada ao início ou piora do  
- comprometimento cognitivo ou presença de infartos múltiplos ou extensos, ou lesões acentuadas na substância branca evidenciadas por exames de neuroimagem; ou  
- Características centrais de demência com corpos de Lewy (alucinações visuais, parkinsonismo, distúrbio  
- comportamental do sono REM e flutuação cognitiva); ou  
- Características proeminentes da variante comportamental da demência frontotemporal (hiperoralidade,  
- hipersexualidade, perseveração); ou  
- Características proeminentes de afasia progressiva primária manifestando-se como a variante semântica (com  
- discurso fluente, anomia e dificuldades de memória semântica) ou como a variante não-fluente (com agramatismo e/ou apraxia de fala importante); ou  
- Outra doença concomitante ativa (neurológica ou não neurológica) ou uso de medicamento que pode ter efeito  
- substancial sobre a cognição.  
**Fonte:** Adaptado de _National Institute on Aging and Alzheimer's Association_ (NIA-AA) [ _Criteria for Alzheimer Disease_ ] e Associação Brasileira de Neurologia (ABN)<sup>9</sup> . **Legenda:** AVC: acidente vascular cerebral; REM: _Rapid Eye Movement_ (Movimento rápido dos olhos).  
6

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Diversas condições clínicas podem causar alterações cognitivas, como por exemplo hipotireoidismo, hipovitaminoses e neurossífilis<sup>9,64</sup> . Uma avaliação médica inicial é recomendada para identificar também doenças sistêmicas e comorbidades que possam contribuir para o agravamento do quadro, como dislipidemia e diabetes<sup>9</sup> . A depressão é uma comorbidade comum e tratável em pacientes com demência e deve ser rastreada<sup>64</sup> .  Também é recomendado realizar uma avaliação laboratorial básica para afastar as principais causas secundárias de declínio cognitivo. A deficiência de vitamina B12 é comum em idosos, devendo a dosagem de nível sérico de B12 ser incluída na rotina de avaliação. Devido à frequência, o hipotireoidismo deve ser pesquisado nos pacientes idosos<sup>9,64</sup> .  
A avaliação cerebral por exames de neuroimagem estrutural como tomografia computadorizada (TC) ou ressonância magnética (RM) de crânio é um passo fundamental para o diagnóstico adequado da DA, tanto para descartar lesões secundárias, como para identificar padrões de atrofia cerebral que sejam próprios da doença<sup>9</sup> .  
Os seguintes exames podem ser utilizados para diagnóstico diferencial, mediante avaliação clínica e a critério do médico:  
**Exames laboratoriais:** Hemograma completo, dosagens de eletrólitos (sódio, potássio, cálcio), glicemia, ureia e creatinina, TSH e ALT/TGP, AST/TGO, vitamina B12, ácido fólico, VDRL e sorologia anti-HIV.  
**Exame de imagem:** Um exame de imagem cerebral – TC ou RM – é útil para excluir lesões estruturais que podem contribuir para a demência, como infarto cerebral, neoplasia e coleções subdurais.  
**Outros exames:** A punção lombar deve ser realizada apenas nos casos de suspeita de câncer metastático, de infecção do sistema nervoso central (SNC) e em pacientes com sorologia sérica reativa para sífilis, hidrocefalia, idade menor de 65 anos, demências de início e evolução atípica, imunossupressão e suspeita de vasculite do SNC. A dosagem de biomarcadores específicos que identificam alterações biológicas características da doença<sup>65</sup> , não está disponível no SUS.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A DA é um diagnóstico que muitos temem e talvez a sua revelação ao paciente e aos familiares seja uma das tarefas mais difíceis no cuidado às pessoas com DA. Pacientes podem se ressentir de uma certa falta de clareza na precisão do diagnóstico ou na explicação do mesmo e do seu prognóstico, assim como de pouca oportunidade para discutir as emoções das pessoas com DA e seus familiares diante do diagnóstico,  discussão limitada sobre as alternativas de tratamento e falta de seguimento e suporte 66. A maioria das diretrizes internacionais sugere que a preocupação não deve estar em revelar ou não revelar a doença, mas sim em como e quando informar ao paciente seu diagnóstico. Uma abordagem estruturada pode aliviar a ansiedade do clínico e melhorar a experiência das pessoas com DA e seus familiares<sup>67,68</sup> .  
Um ponto importante é que a revelação diagnóstica não é um evento único, mas um processo dinâmico que inclui um período preparatório antes da revelação e a revelação em si, que deve ser individualizada e seguida de suporte prático e emocional. As melhores práticas sugerem: preparar e envolver os familiares além da pessoa com a DA, explorar as perspectivas do paciente e dos familiares, revelar o diagnóstico de forma individualizada e respeitando os desejos do paciente, responder às reações do paciente, focar na qualidade de vida, planejar o futuro e comunicar efetivamente<sup>66,67</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Serão incluídos neste Protocolo indivíduos adultos com diagnóstico de DA provável segundo os critérios do _National Institute on Aging and Alzheimer's Association Disease and Related Disorders Association_ (NIA/AA), endossados pela Academia Brasileira de Neurologia (ABN)<sup>9,63</sup> ( **Quadro 4** ).  
7  
**Adicionalmente, para uso de galantamina ou rivastigmina em monoterapia, os pacientes devem apresentar todos os critérios a seguir:**  
- Escore no MEEM entre 12 e 24 (para pacientes com mais de 4 anos de escolaridade) **ou** entre 8 e 21 (para pacientes  
- com até 4 anos de escolaridade); **E** escore na escala CDR igual a 1 ou 2 (demência leve ou moderada).  
- **Para uso de memantina combinada à galantamina ou à rivastigmina, os pacientes também devem apresentar todos**

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
- Escore no MEEM entre 12 e 19 (para pacientes com mais de 4 anos de escolaridade) **ou** entre 8 e 15 (para pacientes  
- com escolaridade menor ou igual a 4 anos); **E** escore na escala CDR igual a 2 (demência moderada).  
**Para uso de memantina combinada à donepezila, os pacientes também devem apresentar todos os critérios a seguir:**  
- Escore no MEEM entre 12 e 19 (para pacientes com mais de 4 anos de escolaridade) **ou** entre 8 e 15 (para pacientes  
- com escolaridade menor ou igual a 4 anos); **E** escore na escala CDR igual a 2 demência moderada); **ou**  
- Escore no MEEM entre 5 e 11 (para pacientes com escolaridade maior que 4 anos) **ou** entre 3 e 7 (para pacientes com  
- escolaridade menor ou igual a 4 anos) **E** escore na escala CDR igual a 3 (demência grave).

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
- Escore no MEEM entre 12 e 24 (para pacientes com mais de 4 anos de escolaridade) **ou** entre 8 e 21 (para pacientes  
- com escolaridade menor ou igual 4 anos de escolaridade) **E** escore na escala CDR igual a 1 ou 2 (demência leve ou moderada);  
**ou**  
- Escore no MEEM entre 5 e 11 (para pacientes com escolaridade maior que 4 anos) **ou** entre 3 e 7 (para pacientes com  
escolaridade menor ou igual a 4 anos) **E** escore na escala CDR igual a 3 (demência grave).

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
- Escore no MEEM entre 5 e 11 (para pacientes com escolaridade maior que 4 anos) **ou** entre 3 e 7 (para pacientes com  
- escolaridade menor ou igual a 4 anos) **E** escore na escala CDR igual a 3 (demência grave).

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Indivíduos que apresentarem intolerância, hipersensibilidade ou contraindicação a qualquer conduta preconizada neste PCDT deverão ser excluídos da respectiva conduta. Adicionalmente, para o tratamento medicamentoso, os pacientes são excluídos se preencherem pelo menos um dos critérios a seguir:  
**Para donepezila, galantamina e rivastigmina:**  
- Identificação de incapacidade de adesão ao tratamento.  
- Evidência de lesão cerebral orgânica ou metabólica simultânea não compensada.  
- Insuficiência ou arritmia cardíaca graves;  
- Alteração na condução cardíaca, tais como: bradicardia sintomática, bloqueio atrioventricular (AV) de segundo ou  
- terceiro grau, síndrome do nó sinusal doente;  
- Asma ou doença pulmonar obstrutiva grave ou descompensadas.  
Além dos citados acima, o uso de galantamina está contraindicado em casos de insuficiência hepática ou renal graves.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
- Identificação de incapacidade de adesão ao tratamento; ou  
- Clearance de creatinina abaixo de 5 mL/minuto/1,73 m<sup>2</sup> .  
8

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Este Protocolo inclui o tratamento medicamentoso e não medicamentoso da DA. O tratamento da DA deve ser multidisciplinar e multiprofissional, contemplando os diversos sinais e sintomas da doença e suas peculiaridades de condutas.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Medidas para tratar os sintomas psicológicos e comportamentais podem incluir diferentes abordagens, tais como intervenções psicoeducacionais, terapia de estimulação cognitiva (CST), cuidado dos cuidadores e cuidados paliativos.  
A maioria das pessoas com demência por DA (aproximadamente 90%) apresentará pelo menos um sintoma psicológico e comportamental associado à demência (SPCD)<sup>69</sup> . Um estudo brasileiro identificou que as pessoas com demência apresentam pelo menos um entre doze sintomas (delírios, alucinações, agitação, depressão, ansiedade, euforia, apatia, desinibição, irritabilidade, alterações psicomotoras, alteração do sono e alteração alimentar) e que a prevalência dos sintomas variou de 4,3% (sintomas clinicamente significativos relacionados à euforia) a 41,5% (sintomas relacionados a mudanças no apetite)<sup>70</sup> . Depressão, ansiedade e alterações do sono estavam entre os sintomas com frequência superior a 20%<sup>70</sup> .  
O tratamento medicamentoso desses sintomas está potencialmente associado a desfechos negativos<sup>71,72</sup> . Um consenso internacional Delphi sugeriu que intervenções não medicamentosas sejam priorizadas diante da existência de SPCD em pessoas com demência por DA<sup>69</sup> . Entre as recomendações do consenso, os tratamentos não medicamentosos mais recomendados foram o controle de possíveis gatilhos, capacitação do cuidador, adaptações do ambiente, bem como o cuidado centrado na pessoa e um programa de atividades personalizadas<sup>69</sup> .  
Tratamentos não medicamentosos mais específicos podem ser considerados, por exemplo, para os sintomas relacionados à depressão, agitação e agressividade, uma vez que têm demonstrado eficácia superior aos tratamentos usuais<sup>73,74</sup> . De acordo com duas recentes revisões sistemáticas com meta-análises em rede, entre os tratamentos mais eficazes terapia de estimulação cognitiva sozinha ou combinada com exercício físico e interação social, terapia ocupacional, cuidado multidisciplinar e terapia do toque e massagem foram capazes de reduzir os sintomas relacionados à depressão<sup>74</sup> . Para os sintomas de agitação e agressividade, o cuidado multidisciplinar, a terapia do toque e massagem sozinha ou combinada com musicoterapia foram as intervenções com maiores eficácias<sup>73</sup> .  
A equipe de saúde deve se organizar junto aos profissionais especializados, como os componentes das equipes multiprofissionais, para mapear locais no território ou desenvolver ações e programas relacionados às práticas corporais e atividades físicas dentro dos estabelecimentos de saúde e polos do Programa Academia da Saúde na APS, além de fortalecer algumas atividades, como as Práticas Integrativas e Complementares em Saúde (PICS).  
As PICS, sempre que disponíveis nos serviços de saúde, devem compor o rol de ações e intervenções voltadas ao cuidado de indivíduos, complementando o tratamento da equipe multiprofissional. A Política Nacional de Práticas Integrativas e Complementares no SUS (PNPIC) orienta que estados, distrito federal e municípios instituam suas próprias normativas trazendo para o SUS práticas que atendam às necessidades regionais. As PICS podem ser consideradas de forma complementar ao tratamento, devido aos possíveis benefícios aos pacientes e seus cuidadores. Contudo, ressalta-se que as PICS não substituem os demais tratamentos preconizados pelo Protocolo e que o tratamento medicamentoso não pode ser interrompido sem orientação médica.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
As intervenções baseadas em multicomponentes se referem à combinação de intervenções baseadas em evidências, normalmente associando duas ou mais das seguintes: terapia de estimulação cognitiva, psicoeducação, grupos de suporte e  
9  
aconselhamento aos cuidadores. Essas intervenções estão entre as que mais apresentam efeitos positivos nos desfechos associados à presença de SPDC nas pessoas com demência e de sintomas psiquiátricos nos cuidadores<sup>75</sup> .  
As intervenções psicoeducacionais estão entre as que mais apresentam efeitos positivos, inclusive associadas à postergação da institucionalização, à redução dos sintomas de desgaste do cuidador e ao aumento da qualidade de vida<sup>75–77</sup> . Têm como objetivo a transmissão de conhecimento sobre a doença e sobre habilidades relacionadas ao cuidado, serviços disponíveis e como lidar com a sobrecarga associada ao cuidado. Essas intervenções podem ser passivas ou podem envolver ativamente os cuidadores na construção do conhecimento, sendo essa última opção mais associada aos desfechos positivos normalmente medidos, tais como postergação da institucionalização da pessoa com demência, aumento da qualidade de vida do cuidador e redução dos seus sintomas psiquiátricos<sup>77</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Intervenções voltadas para cognição em pessoas com demência ainda carecem de mais estudos controlados e randomizados. Duas revisões sistemáticas da Cochrane identificaram pequenos a moderados efeitos em estudos de treino cognitivo, na cognição de pessoas com demência<sup>78,79</sup> . No entanto, há evidências mais consistentes para as práticas de estimulação cognitiva<sup>80,</sup> as quais implicam em benefícios para cognição, bem como na melhora da comunicação e interação social, qualidade de vida, humor e alterações de comportamento<sup>80</sup> .  
A Terapia de Estimulação Cognitiva (do inglês, _Cognitive Stimulation Therapy_ - CST), por exemplo, é uma intervenção breve, realizada com pessoas com demência leve a moderada<sup>81</sup> . A CST é realizada em grupo e tem como objetivo a melhora da cognição por meio de atividades que estimulam implicitamente funções cognitivas como a memória episódica, as funções executivas e a linguagem. Dentre todas as intervenções voltadas para esse objetivo, a CST é a que mais demonstrou evidências de melhora cognitiva e de qualidade de vida<sup>81</sup> .  
A CST é conduzida com grupos de cinco a oito participantes, em sete semanas, duas vezes por semana, totalizando 14 encontros. As atividades são delineadas para serem compatíveis com as habilidades do grupo e para serem as mais inclusivas possível. Estudos iniciais no Brasil sinalizam que o uso é possível e apropriado à população-alvo, sendo necessários pequenos ajustes culturais visando à redução de barreiras associadas à adesão<sup>82,83</sup> . Resultados do primeiro estudo indicaram melhora do humor e nas atividades de vida diária das pessoas com demência, mas não houve efeitos significativos da cognição e qualidade de vida<sup>82</sup> .  
O _National Institute for Health and Care Excellence (NICE)_ incluiu a CST como uma das intervenções nãomedicamentosas voltadas para cognição com evidências científicas suficientes para serem recomendadas, e específicas o suficiente para serem replicadas em outros cenários, e que apresenta estudos de custo-efetividade que justificam sua implementação<sup>84</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Cuidadores de pessoas com demência por DA apresentam maiores riscos para sintomas e quadros relacionados à depressão, ansiedade e estresse/sobrecarga<sup>85,86</sup> . Apesar dos fatores relacionados ao quadro de demência serem as principais fontes de desgaste do cuidador, outros fatores tais como ser o único cuidador (ou aquele que mais permanece em horas no exercício do cuidado) e número de doenças do cuidador também estão associados ao desgaste<sup>87</sup> . A maioria dos cuidadores é considerada informal (sem vínculo empregatício) e são familiares<sup>88</sup> . Esse fato aumenta a chance dos cuidadores não receberem instruções e formação/capacitação suficiente sobre a demência e sobre como exercer o cuidado de forma eficaz e que reduza a sobrecarga, aumentando a chance de aparecimento de sintomas psiquiátricos<sup>89</sup> .  
10  
Uma revisão sistemática com meta-análise demonstrou que intervenções psicoterapêuticas apresentaram grandes efeitos na redução de sintomas depressivos em cuidadores familiares, especialmente as intervenções baseadas em Terapia Cognitivo Comportamental<sup>90</sup> . Na mesma direção, estudos randomizados e controlados baseados no uso da Terapia de Aceitação e Compromisso demonstraram que os cuidadores familiares reduziram os sintomas de depressão e ansiedade após a intervenção 91,92. Por fim, outra revisão sistemática com meta-análise demonstrou que intervenções baseadas na atenção plena ( _mindfulness_ ) demonstraram efeitos moderados a grandes na redução dos sintomas depressivos, de ansiedade, estresse e no aumento da qualidade de vida dos cuidadores familiares<sup>93</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A DA é uma doença neurodegenerativa, crônica, progressiva e terminal, que justifica abordagem paliativa desde o início devido ao seu impacto multidimensional e à ausência de tratamento curativo<sup>11,94</sup> . Pessoas com demência por DA em estágio grave podem se beneficiar de cuidados paliativos que maximizem o conforto e a qualidade de vida. No entanto, o tratamento convencional dessas pessoas não costuma ser delineado sob uma ótica paliativa, uma vez que a doença evolui lentamente para a maioria das pessoas, e o tempo médio entre o diagnóstico e a morte varia, em média, entre três e oito anos, a depender da idade no momento do diagnóstico<sup>95</sup> .  
Há poucos estudos voltados para o impacto do cuidado paliativo de pessoas com demência em estágio grave e de uma revisão sistemática da Cochrane sinalizou a ausência de estudos de alta qualidade que permitam conclusões sobre os efeitos de intervenções voltadas para o cuidado paliativo<sup>95</sup> . O consenso internacional Delphi sobre o assunto<sup>96</sup> obteve consensos completos em dez domínios, relacionados ao cuidado centrado na pessoa, comunicação e tomada de decisão; tratamento ideal dos sintomas e promoção do conforto, evitando tratamentos agressivos, desgastantes e desnecessários; metas de cuidados e planejamento antecipado; continuidade do cuidado; apoio psicossocial e espiritual; cuidado e envolvimento da família; educação/capacitação da equipe de saúde; questões sociais e éticas; prognóstico; e por fim, o reconhecimento oportuno da morte<sup>96</sup> .  
De acordo com o consenso, o cuidado paliativo em demência determina que metas individuais devem ser traçadas e modificadas com a progressão da doença, para que seja possível o auxílio na antecipação de futuros problemas relacionados à natureza terminal da doença, aumentando a qualidade de vida, mantendo a funcionalidade e maximizando o conforto<sup>96</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O objetivo do tratamento medicamentoso é propiciar a estabilização do comprometimento cognitivo, do comportamento e da realização das atividades de vida diária (ou modificar as manifestações da doença), com um mínimo de eventos adversos.  
A conclusão geral das revisões sistemáticas com meta-análises publicadas a partir de 2013 sobre a segurança e eficácia de tratamento clínico para demência devido à DA é a de que os inibidores da acetilcolinesterase podem melhorar os sintomas primariamente nos campos cognitivos e na função global, sendo indicados em casos de demência leve a moderada. Os inibidores da acetilcolinesterase galantamina e rivastigmina são recomendados para o tratamento da DA leve a moderada. Já a donepezila, pode ser utilizada no tratamento da DA leve a grave, pois apresenta resultados positivos na demência grave em cognição, atividades de vida diária e em medidas globais de melhora<sup>97</sup> ,  
A substituição de um inibidor da anticolinesterase por outro só é justificada pela intolerância ao medicamento, e não pela falta de resposta clínica<sup>98–103</sup> . Uma das limitações do uso desses medicamentos é sua tolerância relacionada ao trato digestório, dado que náusea e vômitos são muitas vezes intoleráveis. Para esse fim, foi desenvolvida uma apresentação farmacêutica de adesivo para aplicação transdérmica de rivastigmina ( _patch_ ).<sup>78,79</sup> A revisão sistemática da Cochrane<sup>100</sup> evidenciou eficácia  
11  
similar entre as formas farmacêuticas de apresentação da rivastigmina, e com menos eventos adversos associados ao uso de adesivos transdérmicos e a apresentação trans.  
Além da degeneração do sistema colinérgico, a DA está também associada ao aumento da perda dos neurônios glutamatérgicos, com distúrbios nos receptores N-metil-D-aspartato (NMDA – receptor glutamatérgico). Há evidência de eficácia do uso da memantina, um antagonista do NMDA, em monoterapia ou em combinação com inibidores da colinesterase 95,100–104. Apesar da intensidade do efeito da memantina sobre os campos cognitivo, comportamentais e funcionais na DA ter sido pequeno, foi significativo e influenciou favoravelmente a qualidade de vida dos pacientes e cuidadores<sup>104</sup> . Além da redução do declínio cognitivo, esta associação também levou a uma progressão mais lenta e os domínios comportamental e funcional foram beneficiados<sup>104</sup> . Apesar de alguns artigos diferirem entre si, há evidências de que os anticolinesterásicos possam reduzir a mortalidade na DA<sup>105</sup> .  
Em pacientes com DA moderada, preconiza-se o uso de memantina em monoterapia ou da terapia combinada de memantina e um inibidor da acetilcolinesterase (donepezila, galantamina ou rivastigmina). Já para os pacientes com DA grave, preconiza-se o uso de memantina ou donepezila em monoterapia ou da associação memantina e donepezila.  
Este Protocolo não preconiza o uso de memantina solução oral ou comprimido orodispersível para pacientes com DA moderada ou grave com disfagia, uma vez que, devido ao impacto orçamentário elevado, essas apresentações não foram incorporadas ao Sistema Único de Saúde.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
- Bromidrato de galantamina: cápsulas de liberação prolongada de 8 mg, 16 mg e 24 mg;  
- Cloridrato de donepezila: comprimidos de 5 mg e 10 mg;  
- Cloridrato de memantina: comprimidos de 10 mg;  
 Rivastigmina: cápsulas de 1,5 mg, 3 mg, 4,5 mg e 6 mg; solução oral de 2 mg/mL; adesivos transdérmicos de 5 cm<sup>2</sup> contendo 9 mg de rivastigmina com percentual de liberação de 4,6 mg/24 horas, e; de 10 cm<sup>2</sup> contendo 18 mg de rivastigmina, percentual de liberação de 9,5 mg/24 horas.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Os esquemas de administração dos medicamentos por via oral estão descritos no Quadro 5.  
12  
**Quadro 5.** Esquemas de administração dos medicamentos (via oral).  
|**Medicamento**|**Dose inicial**|**Duração e outras orientações**|
|---|---|---|
|Donepezila|5 mg/dia, via oral|A dose pode ser aumentada para 10 mg/dia após 4 a 6 semanas.<br>Os comprimidos podem ser ingeridos com ou sem alimentos.|
|Galantamina|8 mg/dia, via oral|A dose inicial deve ser utilizada durante 4 semanas.<br>A dose de manutenção é de 16 mg/dia durante pelo menos quatro<br>semanas. A dose máxima é de 24 mg/dia.<br>Por serem cápsulas de liberação prolongada, devem ser<br>administradas uma vez ao dia, pela manhã, de preferência com alimentos.<br>Em caso de insuficiência hepática ou renal moderada, a dose deve<br>ser ajustada considerando a dose máxima de 16 mg/dia.|
|Rivastigmina<br>(cápsula)|3 mg/dia, via oral|A dose pode ser aumentada para 6 mg/dia após 2 semanas.<br>Aumentos subsequentes para 9 mg/dia e para 12 mg/dia devem ser feitos<br>de acordo com a tolerabilidade e após um intervalo de 2 semanas.<br>A dose máxima é de 12 mg/dia. As doses devem ser divididas em<br>duas administrações, junto às refeições.<br>É desnecessário realizar ajuste em casos de insuficiência hepática<br>ou renal, mas deve-se ter cautela em caso de insuficiência hepática<br>(administrar as menores doses possíveis).|
|Memantina|5<br>mg/dia<br>(1/2<br>comprimido)|Aumentar 5 mg/semana nas 3 semanas subsequentes até chegar à<br>dose de 20 mg/dia (1 comprimido de 10 mg duas vezes por dia) na quarta<br>semana e manter esta dose.<br>Em pacientes com função renal ligeiramente alterada (depuração<br>de creatinina entre 50 e 80 mL/min), não há necessidade de ajuste de<br>dose. Nos casos de comprometimento moderado (entre 30 e 49 mL/min),<br>a dose inicial é de 10 mg/dia, podendo ser aumentada para 20 mg/dia após<br>7 dias se bem tolerada. Já em comprometimento grave (entre 5 e 29<br>mL/min), a dose deve ser mantida em 10 mg/dia.|  
**Fonte** : elaboração própria com base na bula dos medicamentos<sup>106–109</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O uso de adesivos transdérmicos inicia-se com a apresentação de 5 cm<sup>2</sup> por, no mínimo, 4 semanas de tratamento. Havendo boa tolerância do paciente após este período de tratamento, o adesivo deve passar para o de 10 cm<sup>2</sup> , que traz a dose considerada efetiva. Aplica-se um adesivo a cada 24 horas em um dos lados da parte superior do braço, do peito ou da parte superior ou inferior das costas. Caso o paciente não tolere o uso do adesivo de 10 cm<sup>2</sup> , uma alternativa terapêutica deve ser buscada pelo médico assistente<sup>110</sup> . Ainda, nesses casos de intolerância ao uso do adesivo de 10 cm<sup>2</sup> , uma vez que o adesivo de 5 cm<sup>2</sup> não traz a dose considerada efetiva, não se deve manter o tratamento com adesivo de 5 cm<sup>2</sup> .  
Pacientes tratados com rivastigmina por via oral podem ser transferidos para o tratamento com adesivos transdérmicos da seguinte forma: os que estão recebendo uma dose menor do que 6 mg/dia de rivastigmina oral podem migrar para o adesivo de 5 cm<sup>2</sup> e, após 4 semanas de uso, passar para o de 10 cm<sup>2</sup> , em caso de boa tolerância; já os que estão recebendo uma dose de 6 a  
13  
12 mg/dia de rivastigmina por via oral podem migrar diretamente para o adesivo de 10 cm<sup>2</sup> . A aplicação do primeiro adesivo deve ser feita um dia após a última dose oral<sup>108</sup> .  
O **Quadro 6** apresenta as principais orientações de uso da rivastigmina adesivo transdérmico.  
**Quadro 6.** Orientações de uso de rivastigmina adesivo transdérmico.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
- Aplicar uma vez ao dia sobre a pele limpa, seca, preferencialmente sem pelos, na parte superior ou inferior das costas,  
- no braço ou no peito, em locais que não sofram atritos com roupas apertadas.  
- Trocar o adesivo a cada 24 horas, mantendo padrão de horários de troca.  
- Fazer rodízio quanto aos locais de aplicação, evitando colocar o adesivo seguidamente no mesmo lugar.  
- Antes de colocar um novo adesivo, retirar o anterior.  
- Não aplicar o adesivo em locais da pele que estejam vermelhos, irritados ou machucados.  
- O adesivo deve ser pressionado por cerca de 30 segundos no local onde será aplicado para maior fixação.  
- Não cortar o adesivo em pedaços, em hipótese alguma.  
- Não deixar as embalagens dos adesivos próximos a fontes de calor.  
- Estando o adesivo aplicado, evitar que o paciente fique exposto a fontes de calor extremo por longos períodos, como  
sol e/ou saunas.  
- Após usar, dobrar o adesivo e descartar adequadamente, longe do alcance das crianças.  
- Lavar as mãos com água e sabão após manipular os adesivos.  
- **Fonte:** Bula do medicamento Exelon® Patch<sup>108</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O tratamento deve ser interrompido caso o paciente apresente uma das seguintes situações<sup>9,111</sup> :  
- 1.Após no mínimo seis meses do início do tratamento, não se observando melhora ou estabilização da deterioração do  
- quadro à reavaliação (por falta de benefício);  
2.Declínio do escore MEEM: abaixo de 12, para pacientes com mais de 4 anos de escolaridade, ou abaixo de 8, para pacientes com menos de 4 anos de escolaridade, mesmo que os pacientes estejam em tratamento contínuo, pois não há qualquer evidência de benefício;  
- 3.Pacientes com Escala CDR 3 (demência grave), mesmo que estejam em tratamento contínuo, pois não há qualquer  
- evidência de benefício; e  
4.Em casos de intolerância ao medicamento, pode-se reduzir a dose do medicamento ou substitui-lo por outro. Nos casos  
em que a dose for reduzida e haja diminuição de melhora, ainda é possível substituir o medicamento por outro da mesma classe.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O tratamento deve ser interrompido em três situações distintas<sup>9,111</sup> :  
- 1.Em pacientes com demência leve ou moderada, ausência de melhora ou estabilização da deterioração do quadro à  
reavaliação (por falta de benefício) após no mínimo seis meses do início do tratamento;  
- 2.Em pacientes com demência grave, ausência de resposta na avaliação clínica; sem estabilização do quadro grave;  
- 3.Em pacientes com demência leve ou moderada, em casos de intolerância ao anticolinesterásico, pode-se substituir o  
- medicamento por outro da mesma classe.  
14

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O tratamento deve ser interrompido em três situações distintas:  
- 1.Após no mínimo seis meses do início do tratamento, não havendo melhora ou estabilização da deterioração do quadro  
à reavaliação (por falta de benefício);  
- 2.Declínio dos escores do MEEM para menos de 3 pontos (para pacientes com 4 anos de escolaridade ou menos) ou para  
- menos de 5 pontos (para pacientes com mais de 4 anos de escolaridade) nas reavaliações;  
- 3.Em casos de intolerância ao medicamento.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Diversos tratamentos e abordagens têm sido pesquisados para controlar e gerenciar os sintomas e melhorar a qualidade de vida dos pacientes. Entre os principais benefícios encontrados estão<sup>10,94</sup> :  
- Redução na velocidade de progressão da doença, que pode ser obtida por medicamentos específicos.  
- Melhora da memória e da atenção: embora os medicamentos não revertam o dano já causado pela doença, eles podem  
- ajudar a melhorar a memória e a atenção em alguns pacientes.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Após três a quatro meses do início do tratamento, o paciente deve ser submetido a uma reavaliação. Após esse período, o acompanhamento deve ocorrer a cada seis meses, para estimar o benefício e a necessidade de continuidade do tratamento pela avaliação clínica e aplicação do MEEM e da Escala CDR, bem como o monitoramento dos eventos adversos oriundos da terapia medicamentosa.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Como a donepezila é metabolizada por enzimas hepáticas, a taxa de metabolização pode ser influenciada por medicamentos que elevam ou reduzem a quantidade dessas enzimas. Carbamazepina, dexametasona, fenobarbital, fenitoína e rifampicina são exemplos de fármacos que aumentam as enzimas hepáticas e, ao aumentar a eliminação de donepezila, podem reduzir os seus efeitos. Já o cetoconazol bloqueia as enzimas hepáticas que metabolizam a donepezila. Desta forma, o uso concomitante de cetoconazol e donepezila pode resultar no aumento da concentração de donepezila e, possivelmente, levar à maior ocorrência de eventos adversos. A quinidina também inibe as enzimas que metabolizam a donepezila, podendo piorar, assim, o perfil de seus eventos adversos. A donepezila deve ser usada com cautela em indivíduos com anormalidades supraventriculares da condução cardíaca ou naqueles em uso de fármacos que reduzam significativamente a frequência cardíaca, com história de convulsão de asma ou doença pulmonar obstrutiva crônica (DPOC) e com risco de úlcera.  
**Monitoramento do uso de galantamina**  
A galantamina deve ser usada com cautela em pacientes com atraso da condução cardíaca ou em uso de fármacos que atrasam a condução no nodo sinoatrial ou atrioventricular, com história de úlcera péptica, convulsão, doenças respiratórias graves e obstrução urinária.  
Devem ser monitorizadas as funções renais (creatinina) e hepática (ALT/TGP e AST/TGO). A succinilcolina aumenta o bloqueio neuromuscular. Agentes colinérgicos podem apresentar efeitos sinérgicos. Inibidores centrais da acetilcolinesterase podem aumentar o risco de sintomas piramidais relacionados aos antipsicóticos.  
**Monitoramento do uso de rivastigmina**  
15  
Os agentes anticolinérgicos podem reduzir os efeitos da rivastigmina. Outras interações significativas não foram observadas. A rivastigmina deve ser usada com precaução em pacientes com úlcera péptica, história de convulsão, alterações da condução cardíaca e asma.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A memantina deve ter sua dose de manutenção reduzida à metade (10 mg/dia) quando a taxa de depuração de creatinina for menor do que 50 mL/minuto. Se bem tolerada após pelo menos 7 dias de tratamento, a dose poderá ser aumentada até 20 mg/dia de acordo com o esquema de titulação padrão. Em pacientes com comprometimento renal grave (depuração da creatinina 5 a 29 mL/min), a dose diária deverá ser de 10 mg por dia<sup>109</sup> .  
O **Quadro 7** apresenta as principais interações medicamentosas relacionadas a farmacoterapia da DA, contudo, outras interações podem não estar contempladas.  
**Quadro 7.** Interações medicamentosas mais importantes na farmacoterapia da DA.  
|**Medicamen**<br>**to**|**Interação medicamentosa**|**Cuidados**|
|---|---|---|
|Bromidrato|Diminui a depuração da amitriptilina,<br>fluoxetina<br>e<br>quinidina<br>e<br>aumenta<br>a<br>biodisponibilidade de cimetidina, eritromicina e<br>cetoconazol.|Monitorar o paciente.<br>Interromper o uso da cimetidina e propor a<br>substituição por um inibidor de bomba de prótons<br>(IBP).|
|de galantamina|Efeitos<br>potencializados<br>dos<br>medicamentos bradicárdicos: betabloquadores,<br>digoxina, amiodarona, bloqueadores dos canais<br>de cálcio e anticolinérgicos.|Monitorar o paciente.|
||Evitar a administração junto com outros<br>colinomiméticos.|Buscar alternativas ou distanciar os horários<br>de tomada.<br>Monitorar o paciente.|
|Cloridrato<br>de donepezila|Rifampicina, fenitoína e carbamazepina e<br>o etanol podem reduzir os efeitos do cloridrato de<br>donepezila.|Monitorar o paciente.<br>Suspender/reduzir o consumo de bebidas<br>alcoólicas.|
||Itraconazol, cetoconazol, eritromicina,<br>fluoxetina, quinidina podem atuar inibindo o<br>metabolismo do cloridrato de donepezila.|Monitorar o paciente.|
|Cloridrato|Ação antagonista aditiva é vista com<br>amantadina, cetamina.|Monitorar o paciente.<br>Deve-se verificar o uso concomitante de<br>cetamina (utilizado em sala cirúrgica e em<br>depressão maior).|
|<br>de memantina|A taxa de eliminação do cloridrato de<br>memantina diminui na presença de bicarbonato<br>de sódio e inibidores da anidrase carbônica.|Não utilizar bicarbonato de sódio em<br>horário próximo ao uso da memantina.|
||A concentração plasmática de cimetidina,<br>hidroclorotiazida, nicotina e quinidina é alterada|Monitorar o paciente.|  
16  
|**Medicamen**<br>**to**|**Interação medicamentosa**|**Cuidados**|
|---|---|---|
||quando<br>administrada<br>com<br>cloridrato<br>de<br>memantina.|Interromper o uso de cimetidina e propor a<br>substituição por um inibidor da bomba de prótons.|
||Evitar a administração junto com outros<br>colinomiméticos.|Buscar alternativas ou distanciar os horários<br>de administração.<br>Monitorar o paciente.|
||Não associar com metoclopramida devido<br>à possibilidade de efeitos extrapiramidais<br>aditivos.|Substituir metoclopramida pelo cloridrato<br>de ondansentrona.|
|Rivastigmin|Evitar uso com succinilcolina pois pode<br>haver potencialização dos efeitos de relaxamento<br>muscular.|Monitorar o paciente.|
|a|Se usada com betabloqueadores (como<br>atenolol) pode aumentar os efeitos bradicárdicos.|Monitorar o paciente.|
||Pode aumentar os efeitos neurotóxicos<br>centrais de antipsicóticos.|Monitorar o paciente, verificar se há<br>potencialização dos efeitos antipsicóticos; verificar<br>a possibilidade de mudar o antipsicótico em uso.|
||Pode potencializar os eventos adversos da<br>bromoprida.|Monitorar o paciente.|
|**Fonte:**Bulas dos medicame|Corticoides sistêmicos podem aumentar<br>os<br>eventos<br>adversos<br>dos<br>medicamentos<br>inibidores da acetilcolinesterase.<br>ntos<sup>106–109</sup>.|Monitorar o paciente.|  
O **Quadro 8** elenca os principais eventos adversos dos medicamentos preconizados para DA.  
**Quadro 8.** Eventos adversos oriundos da terapia medicamentosa.  
|**Medicamento**|**Eventos adversos**|
|---|---|
||Mais frequentes: insônia, náusea, vômitos, diarreia, anorexia, dispepsia, cãibras<br>musculares e fadiga.|
|Donepezila|Menos frequentes: menos comumente podem ocorrer cefaleia, sonolência, tontura,<br>depressão, perda de peso, sonhos anormais, aumento da frequência urinária, síncope, bradicardia,<br>artrite e equimoses.|
|Galantamina|Mais frequentes: náusea, vômitos, diarreia, anorexia, perda de peso, dor abdominal,<br>dispepsia, flatulência, tontura, cefaleia, depressão, fadiga, insônia e sonolência.<br>Menos frequentes: infecção do trato urinário, hematúria, incontinência, anemia, tremor,<br>rinite e aumento da fosfatase alcalina.|
|Rivastigmina|Mais frequentes: tontura, cefaleia, náusea, vômitos, diarreia, anorexia, fadiga, insônia,<br>confusão e dor abdominal.|  
17  
||Menos frequentes: depressão, ansiedade, sonolência, alucinações, síncope, hipertensão,<br>dispepsia, constipação, flatulência, perda de peso, infecção do trato urinário, fraqueza, tremor,<br>angina, úlcera gástrica ou duodenal e erupções cutâneas.|
|---|---|
||Mais frequentes: cefaleia, cansaço e tontura.<br>Menos frequentes: alucinações, alterações de marcha, anorexia, ansiedade, artralgia,|
|Memantina|bronquite, cistite, constipação, diarreia, confusão, dor lombar, edema periférico, hipertensão,<br>hipertonia, infecção de trato respiratório, insônia, aumento da libido, náusea, queda, sonolência e<br>vômitos.|  
**Fonte:** elaboração própria com base na bula dos medicamentos<sup>106–109</sup> .  
Por fim, cabe salientar que a frequência de monitoramento deve ser avaliada de forma particular, conforme critério médico e estado clínico do paciente.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pacientes com doença de Alzheimer devem ser atendidos e acompanhados por profissionais que compõem os três níveis da Rede de Atenção à Saúde para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento, incluindo profissionais da Atenção Primária à Saúde e aqueles que integram serviços especializados em neurologia, geriatria e psiquiatria, entre outros, com treinamento na avaliação de quadro demenciais. A demência, como problema de saúde pública cada vez mais prevalente, deve ser reconhecida e diagnosticada oportunamente, especialmente no contexto de Atenção Primária. O manejo dessa condição pode ser apoiado por profissionais especialistas focais, e contar com o uso de tecnologias de informação e comunicação, como a telessaúde. A adequada qualificação profissional deve ser garantida em todos os níveis de atenção, permitindo que cada vez mais pessoas possam ser diagnosticas e tratadas adequadamente.  
Pacientes com doença de Alzheimer devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Como parte da rede de Atenção Primária à Saúde, o Programa Academia da Saúde é uma estratégia de promoção da saúde e produção do cuidado que funciona com a implantação de espaços públicos conhecidos como polos, voltados ao desenvolvimento de ações culturalmente inseridas e adaptadas aos territórios locais e que adotam como valores norteadores de suas atividades o desenvolvimento de autonomia, equidade, empoderamento, participação social, entre outros. Nesse sentido, deve ser observado o artigo 7° da Portaria de Consolidação nº 5, de 28 de setembro de 2017, que estabelece os seguintes eixos de ações para serem desenvolvidos nos polos do programa: Práticas corporais e Atividades físicas; produção do cuidado e de modos de vida saudáveis; promoção da alimentação saudável; PICS; práticas artísticas e culturais; educação em saúde; planejamento e gestão; e mobilização da comunidade.  
Em relação às PICS, estas práticas foram institucionalizadas pela PNPIC. Uma das ideias centrais dessa abordagem é uma visão ampliada do processo saúde e doença, assim como a promoção do cuidado integral do ser humano, especialmente do  
18  
autocuidado. As indicações às práticas se baseiam no indivíduo como um todo, considerando seus aspectos físicos, emocionais, mentais e sociais. As PICS não substituem o tratamento tradicional e podem ser indicadas por profissionais específicos conforme as necessidades de cada caso.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A Erro! Fonte de referência não encontrada. descreve o fluxograma de tratamento dos pacientes com doença de Alzheimer.  
**Figura 1.** Fluxograma para definição de tratamento para pacientes com DA baseado na gravidade dos sintomas.  
<!-- Start of picture text -->
Paciente com diagnéstico provavel de Doenga de Alzheimer |<br>Doenca de Alzheimer DoencaWoderadade Alzheimer | DoencaGrave<br>cOR=1Leve CDR=2 cDR=3de Alzheimer<br>(MEM enire 12 @ 24° ou! MEEM enire 12¢ 24° ou) | MEM entre 12.6 19° MEEM entre 5e 11°<br>entre 8 e 21° entre 8 © 21° ou entre 8 @ 15° ou entre 37°<br>Donepezila, Donepezita, | Memantina+ |<br>galantaminafivastigmina emou ‘ivastigminagalantamina ou em Salantamina(Gonepezita ou ou Memantinamonoterapia em| | || Memantina+donepezita | | Donepezila‘monoterapiaem<br>monoterapia® monoterapia® rivastigmina?®<br>Monitorar paciente®<br>‘Mantermonitorar tratamentopaciente e eo apresentouraces.crtérios5 de Sim _, nterrompere reavaliar trtamentopaciente<br>interrup¢ao®?<br>Notas:<br>}* Para pacientes com mais de 4 anos de escolaridade<br>Para pacientes com 4 anos de escolaridade ou menos;<br>|° Em caso de intolerdncia ao anticolinesterdsico, pode-se substituir por outro representante da mesma classe, respettando-se os critéios de inclusdo.<br>| Considerar a possibilidade de progressao da doenca que requer mudanca no tratamento, conforme preconizado no Protocolo.<br>|* So possiveis critérios de interrupcdo: Tratamento por 6 meses ou mais sem melhora ou establizacdo do paciente: reduco da pontuacdo no MEM ou CDR: presenca de<br>leventos adversos: auséncia de resposta na avaliacdo clinica ou Intolerancia ao medicamento,<br><!-- End of picture text -->  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento,  
levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).  
19  
20

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
1. Alzheimer’s Association. Alzheimer’s disease facts and figures. Special Report: The patient journey an era of new treatments. Alzheimer’s & Dementia. 2023 Apr 14;19(4):1598–695.  
2. Kelley AS, McGarry K, Gorges R, Skinner JS. The Burden of Health Care Costs for Patients With Dementia in the Last 5 Years of Life. Ann Intern Med. 2015 Nov 17;163(10):729–36.  
3. Alzheimer’s Disease International. World Alzheimer Report 2021 [Internet]. 2021. Available from: https://www.alzint.org/resource/world-alzheimer-report-2021/  
4. Cao Q, Tan CC, Xu W, Hu H, Cao XP, Dong Q, et al. The Prevalence of Dementia: A Systematic Review and Meta-Analysis. Journal of Alzheimer’s Disease. 2020 Feb 4;73(3):1157–66.  
5. Melo SC de, Champs APS, Goulart RF, Malta DC, Passos VM de A. Dementias in Brazil: increasing burden in the 2000–2016 period. Estimates from the Global Burden of Disease Study 2016. Arq Neuropsiquiatr. 2020 Dec;78(12):762–71.  
6. Querfurth HW, LaFerla FM. Alzheimer’s Disease. New England Journal of Medicine. 2010 Jan 28;362(4):329–44.  
7. Bottino CMC, Azevedo D, Tatsch M, Hototian SR, Moscoso MA, Folquitto J, et al. Estimate of dementia prevalence in a community sample from São Paulo, Brazil. Dement Geriatr Cogn Disord. 2008 Oct;26(4):291–9.  
8. Atri A. The Alzheimer’s Disease Clinical Spectrum. Medical Clinics of North America. 2019 Mar;103(2):263– 93.  
9. Schilling LP, Balthazar MLF, Radanovic M, Forlenza OV, Silagi ML, Smid J, et al. Diagnóstico da doença de Alzheimer: recomendações do Departamento Científico de Neurologia Cognitiva e do Envelhecimento da Academia Brasileira de Neurologia. Dement Neuropsychol. 2022 Sep;16(3 suppl 1):25–39.  
10. Alzheimer’s Association. Alzheimer’s disease facts and figures. Special Report: Race, Ethnicity and Alzheimer’s in America. Alzheimers & Dementia [Internet]. 2021 [cited 2023 Sep 24];17(3). Available from: https://www.alz.org/media/Documents/alzheimers-facts-and-figures-2021.pdf  
11. Livingston G, Huntley J, Liu KY, Costafreda SG, Selbæk G, Alladi S, et al. Dementia prevention, intervention, and care: 2024 report of the Lancet standing Commission. The Lancet. 2024 Aug;404(10452):572–628.  
12. Suemoto CK, Borelli W V., Calandri IL, Bertola L, Castilhos RM, Caramelli P, et al. The potential for dementia prevention in Brazil: a population attributable fraction calculation for 14 modifiable risk factors. The Lancet Regional Health - Americas. 2025 Sep;49:101209.  
13. Lang L, Clifford A, Wei L, Zhang D, Leung D, Augustine G, et al. Prevalence and determinants of undetected dementia in the community: a systematic literature review and a meta-analysis. BMJ Open. 2017 Feb 3;7(2):e011146.  
14. BRASIL. Ministério da Saúde. Relatório Nacional sobre a Demência no Brasil: necessidades de cuidado, custos, produção científica e investimento em pesquisa. [Internet]. Brasília; 2024 [cited 2025 Aug 7]. Available from: https://static.poder360.com.br/2023/12/pesquisa-cuidados-demencia.pdf  
15. Ferri CP, Jacob KS. Dementia in low-income and middle-income countries: Different realities mandate tailored solutions. PLoS Med. 2017 Mar 28;14(3):e1002271.  
16. Folstein MF, Folstein SE, McHugh PR. “Mini-mental state”. J Psychiatr Res. 1975 Nov;12(3):189–98.  
17. Brucki SMD, Nitrini R, Caramelli P, Bertolucci PHF, Okamoto IH. Sugestões para o uso do mini-exame do estado mental no Brasil. Arq Neuropsiquiatr. 2003 Sep;61(3B):777–81.  
21  
18. Memória CM, Yassuda MS, Nakano EY, Forlenza O V. Brief screening for mild cognitive impairment: validation of the Brazilian version of the Montreal cognitive assessment. Int J Geriatr Psychiatry. 2013 Jan;28(1):34–40. 19. Nasreddine ZS, Phillips NA, BÃ©dirian V, Charbonneau S, Whitehead V, Collin I, et al. The Montreal Cognitive Assessment, MoCA: A Brief Screening Tool For Mild Cognitive Impairment. J Am Geriatr Soc. 2005 Apr;53(4):695–9.  
20. Teng EL LELKGALHC. Screening for dementia: the Cognitive Abilities Screening Instrument – short version (CASI Short). . In: APA, editor. Proceedings of the 106th Annual Convention of the American Psychological Association . San Francisco: American Psychological Association; 1998. p. 14–8.  
21. Damasceno A, Delicio AM, Mazo DFC, Zullo JFD, Scherer P, Ng RTY, et al. Validation of the Brazilian version of mini-test CASI-S. Arq Neuropsiquiatr. 2005 Jun;63(2b):416–21.  
22. Nitrini R, Helena Lefèvre B, Mathias SC, Caramelli P, Carrilho PEM, Sauaia N, et al. Testes neuropsicológicos de aplicação simples para o diagnóstico de demência. Arq Neuropsiquiatr. 1994 Dec;52(4):457–65.  
23. Nitrini R, Brucki SMD, Yassuda MS, Fichman HC, Caramelli P. The Figure Memory Test: diagnosis of memory impairment in populations with heterogeneous educational background. Dement Neuropsychol. 2021 Apr;15(2):173–85.  
24. Carvalho VA, Caramelli P. Brazilian adaptation of the Addenbrooke’s Cognitive Examination-Revised (ACER). Dement Neuropsychol. 2007 Jun;1(2):212–6.  
25. Mioshi E, Dawson K, Mitchell J, Arnold R, Hodges JR. The Addenbrooke’s Cognitive Examination Revised (ACE-R): a brief cognitive test battery for dementia screening. Int J Geriatr Psychiatry. 2006 Nov;21(11):1078–85.  
26. Aprahamian I, Martinelli JE, Cecato J, Izbicki R, Yassuda MS. Can the CAMCOG be a good cognitive test for patients with Alzheimer’s disease with low levels of education? Int Psychogeriatr. 2011 Feb 3;23(1):96–101.  
27. Nunes P V., Diniz BS, Radanovic M, Abreu ID, Borelli DT, Yassuda MS, et al. CAMcog as a screening tool for diagnosis of mild cognitive impairment and dementia in a Brazilian clinical sample of moderate to high education. Int J Geriatr Psychiatry. 2008 Nov;23(11):1127–33.  
28. Roth M, Tym E, Mountjoy CQ, Huppert FA, Hendrie H, Verma S, et al. CAMDEX: A Standardised Instrument for the Diagnosis of Mental Disorder in the Elderly with Special Reference to the Early Detection of Dementia. British Journal of Psychiatry. 1986 Dec 29;149(6):698–709.  
29. Rosen WG MRDKL. A new rating scale for Alzheimer’s disease. American Journal of Psychiatry. 1984 Nov;141(11):1356–64.  
30. Schultz RR, Siviero MO, Bertolucci PHF. The cognitive subscale of the ‘Alzheimer’s Disease Assessment Scale’ in a Brazilian sample. Brazilian Journal of Medical and Biological Research. 2001 Oct;34(10):1295–302.  
31. Moms JC, Heyman A, Mohs RC, Hughes JP, van Belle G, Fillenbaum G, et al. The Consortium to Establish a Registry for Alzheimer’s Disease (CERAD). Part I. Clinical and neuropsychological assesment of Alzheimer’s disease. Neurology. 1989 Sep 1;39(9):1159–1159.  
32. Bertolucci PHF, Okamoto IH, Brucki SMD, Siviero MO, Toniolo Neto J, Ramos LR. Applicability of the CERAD neuropsychological battery to Brazilian elderly. Arq Neuropsiquiatr. 2001 Sep;59(3A):532–6.  
33. Vitaliano PP, Breen AR, Russo J, Albert M, Vitiello M V., Prinz PN. The clinical utility of the Dementia Rating Scale for assessing Alzheimer patients. J Chronic Dis. 1984 Jan;37(9–10):743–53.  
34. Porto CS, Fichman HC, Caramelli P, Bahia VS, Nitrini R. Brazilian version of the Mattis dementia rating scale: diagnosis of mild dementia in Alzheimer’s disease. Arq Neuropsiquiatr. 2003 Jun;61(2B):339–45.  
35. Brasil. Ministério da Saúde. Identificação da Demência na Atenção Primária. Brasília; 2024.  
22  
36. Malloy-Diniz LF, Lasmar VAP, Gazinelli L de SR, Fuentes D, Salgado JV. The Rey Auditory-Verbal Learning Test: applicability for the Brazilian elderly population. Revista Brasileira de Psiquiatria. 2007 Aug 3;29(4):324–9.  
37. FOSS MPBFM de S e SJGeraldo. Rey’s complex figures for the elderly. Aval psicol [online]. 2010;9(1):53–  
6.  
38. Hazin I, Leite G, Oliveira RM, Alencar JC, Fichman HC, Marques P d. N, et al. Brazilian Normative Data on Letter and Category Fluency Tasks: Effects of Gender, Age, and Geopolitical Region. Front Psychol. 2016 May 10;7.  
39. Caramelli P, Carthery-Goulart MT, Porto CS, Charchat-Fichman H, Nitrini R. Category Fluency as a Screening Test for Alzheimer Disease in Illiterate and Literate Patients. Alzheimer Dis Assoc Disord. 2007 Jan;21(1):65–7.  
40. Mansur LL, Radanovic M, Araújo G de C, Taquemori LY, Greco LL. Teste de nomeação de Boston: desempenho de uma população de São Paulo. Pro Fono. 2006 Jan;18(1):13–20.  
41. Kaplan E, Goodglass H, Weintraub S. Boston naming test. Lippincott Williams & Wilkins. 2001;  
42. Zimmermann N, Cardoso C de O, Trentini CM, Grassi-Oliveira R, Fonseca RP. Brazilian preliminary norms and investigation of age and education effects on the Modified Wisconsin Card Sorting Test, Stroop Color and Word test and Digit Span test in adults. Dement Neuropsychol. 2015 Jun;9(2):120–7.  
43. Wechsler D. Wechsler Adult Intelligence Scale-III. The Psychological Corporation. Harcourt; 1997.  
44. Shulman KI, Shedletsky R, Silver IL. The challenge of time: Clock-drawing and cognitive function in the elderly. Int J Geriatr Psychiatry. 1986 Oct;1(2):135–40.  
45. Fuzikawa C, Lima-Costa MF, Uchoa E, Barreto SM, Shulman K. A population based study on the intra and inter-rater reliability of the clock drawing test in Brazil: the Bambuí Health and Ageing Study. Int J Geriatr Psychiatry. 2003 May;18(5):450–6.  
46. Pfeffer RI, Kurosaki TT, Harrah CH, Chance JM, Filos S. Measurement of Functional Activities in Older Adults in the Community. J Gerontol. 1982 May 1;37(3):323–9.  
47. Herrera E, Caramelli P, Silveira ASB, Nitrini R. Epidemiologic Survey of Dementia in a Community-Dwelling Brazilian Population. Alzheimer Dis Assoc Disord. 2002 Apr;16(2):103–8.  
48. Jorm AF, Jacomb PA. The Informant Questionnaire on Cognitive Decline in the Elderly (IQCODE): sociodemographic correlates, reliability, validity and some norms. Psychol Med. 1989 Nov 9;19(4):1015–22.  
49. Sanchez MA dos S, Lourenço RA. Informant Questionnaire on Cognitive Decline in the Elderly (IQCODE): adaptação transcultural para uso no Brasil. Cad Saude Publica. 2009 Jul;25(7):1455–65.  
50. Loewenstein DA, Bates CB. The Direct Assessment of Functional Status-Revised (DAFS-R). Manual for administration and scoring Neuropsychological Laboratories and the Wien Center for Alzheimer’s Disease and Memory Disorders, Mount Sinai Medical Center. 2006;  
51. Pereira FS, Oliveira AM, Diniz BS, Forlenza O V., Yassuda MS. Cross-cultural Adaptation, Reliability and Validity of the DAFS-R in a Sample of Brazilian Older Adults. Archives of Clinical Neuropsychology. 2010 Jun 1;25(4):335–43.  
52. Bahia VS, Carthery-Goulart MT, Novelli MM, Kato-Narita EM, Areza-Fegyveres R, Caramelli P, et al. Functional Disability in Alzheimer Disease. Alzheimer Dis Assoc Disord. 2010 Jul;24(3):291–5.  
53. Gauthier L, Gélinas I, McIntyre M, Gauthier S, Laberge H, Dauphinee SW. Disability Assessment for Dementia (DAD) user’s guide. 1994.  
54. Medeiros M, Guerra R. Tradução, adaptação cultural e análise das propriedades psicométricas do Activities of Daily Living Questionnaire (ADLQ) para avaliação funcional de pacientes com a doença de Alzheimer. Braz J Phys Ther. 2009 Jun;13(3):257–66.  
23  
55. Johnson N, Barion A, Rademaker A, Rehkemper G, Weintraub S. The Activities of Daily Living Questionnaire: a validation study in patients with dementia. Alzheimer Dis Assoc Disord. 2004;18(4):223–30.  
56. Hindmarch I, Lehfeld H, de Jongh P, Erzigkeit H. The Bayer Activities of Daily Living Scale (B-ADL). Dement Geriatr Cogn Disord. 1998;9(Suppl. 2):20–6.  
57. Folquitto JC, Bustamante SEZ, Barros SB, Azevedo D, Lopes MA, Hototian SR, et al. The Bayer: Activities of Daily Living Scale (B-ADL) in the differentiation between mild to moderate dementia and normal aging. Revista Brasileira de Psiquiatria. 2007 May 8;29(4):350–3.  
58. Galvin JE, Roe CM, Powlishta KK, Coats MA, Muich SJ, Grant E, et al. The AD8. Neurology. 2005 Aug 23;65(4):559–64.  
59. Katz S. Studies of Illness in the Aged. JAMA. 1963 Sep 21;185(12):914.  
60. Lino VTS, Pereira SRM, Camacho LAB, Ribeiro Filho ST, Buksman S. Adaptação transcultural da Escala de Independência em Atividades da Vida Diária (Escala de Katz). Cad Saude Publica. 2008 Jan;24(1):103–12.  
61. Hughes CP, Berg L, Danziger W, Coben LA, Martin RL. A New Clinical Scale for the Staging of Dementia. British Journal of Psychiatry. 1982 Jun 29;140(6):566–72.  
62. Fagundes Chaves ML, Camozzato AL, Godinho C, Kochhann R, Schuh A, de Almeida VL, et al. Validity of the Clinical Dementia Rating Scale for the Detection and Staging of Dementia in Brazilian Patients. Alzheimer Dis Assoc  
Disord. 2007 Jul;21(3):210–7.  
63. McKhann GM, Knopman DS, Chertkow H, Hyman BT, Jack CR, Kawas CH, et al. The diagnosis of dementia due to Alzheimer’s disease: Recommendations from the National Institute on Aging‐Alzheimer’s Association workgroups on diagnostic guidelines for Alzheimer’s disease. Alzheimer’s & Dementia. 2011 May 22;7(3):263–9.  
64. Smid J, Studart-Neto A, César-Freitas KG, Dourado MCN, Kochhann R, Barbosa BJAP, et al. Declínio cognitivo subjetivo, comprometimento cognitivo leve e demência - diagnóstico sindrômico: recomendações do Departamento Científico de Neurologia Cognitiva e do Envelhecimento da Academia Brasileira de Neurologia. Dement Neuropsychol. 2022 Sep;16(3 suppl 1):1–24.  
65. Jack CR, Andrews JS, Beach TG, Buracchio T, Dunn B, Graf A, et al. Revised criteria for diagnosis and staging of Alzheimer’s disease: Alzheimer’s Association Workgroup. Alzheimer’s & Dementia. 2024 Aug 27;20(8):5143–69.  
66. Frank CC, Lee L, Molnar F. Disclosing a diagnosis of dementia. Can Fam Physician. 2018 Jul;64(7):518.  
67. Byszewski AM, Molnar FJ, Aminzadeh F, Eisner M, Gardezi F, Bassett R. Dementia Diagnosis Disclosure. Alzheimer Dis Assoc Disord. 2007 Apr;21(2):107–14.  
68. Yates J, Stanyon M, Samra R, Clare L. Challenges in disclosing and receiving a diagnosis of dementia: a systematic review of practice from the perspectives of people with dementia, carers, and healthcare professionals. Int Psychogeriatr. 2021 Nov 17;33(11):1161–92.  
69. Kales HC, Gitlin LN, Lyketsos CG. Assessment and management of behavioral and psychological symptoms of dementia. BMJ. 2015 Mar 2;350(mar02 7):h369–h369.  
70. Nunes PV, Schwarzer MC, Leite REP, Ferretti-Rebustini RE de L, Pasqualucci CA, Nitrini R, et al. Neuropsychiatric Inventory in Community-Dwelling Older Adults with Mild Cognitive Impairment and Dementia. Journal of Alzheimer’s Disease. 2019 Mar 29;68(2):669–78.  
71. Watt JA, Goodarzi Z, Veroniki AA, Nincic V, Khan PA, Ghassemi M, et al. Safety of pharmacologic interventions for neuropsychiatric symptoms in dementia: a systematic review and network meta-analysis. BMC Geriatr. 2020 Dec 16;20(1):212.  
24  
72. Yunusa I, Alsumali A, Garba AE, Regestein QR, Eguale T. Assessment of Reported Comparative Effectiveness and Safety of Atypical Antipsychotics in the Treatment of Behavioral and Psychological Symptoms of Dementia. JAMA Netw Open. 2019 Mar 22;2(3):e190828.  
73. Watt JA, Goodarzi Z, Veroniki AA, Nincic V, Khan PA, Ghassemi M, et al. Comparative Efficacy of Interventions for Aggressive and Agitated Behaviors in Dementia. Ann Intern Med. 2019 Nov 5;171(9):633.  
74. Watt JA, Goodarzi Z, Veroniki AA, Nincic V, Khan PA, Ghassemi M, et al. Comparative efficacy of interventions for reducing symptoms of depression in people with dementia: systematic review and network metaanalysis. BMJ. 2021 Mar 24;n532.  
75. Cheng ST, Li KK, Or PPL, Losada A. Do caregiver interventions improve outcomes in relatives with dementia and mild cognitive impairment? A comprehensive systematic review and meta-analysis. Psychol Aging. 2022 Dec;37(8):929–53.  
76. Walter E, Pinquart M. How Effective Are Dementia Caregiver Interventions? An Updated Comprehensive Meta-Analysis. Gerontologist. 2020 Nov 23;60(8):e609–19.  
77. Vandepitte S, Van Den Noortgate N, Putman K, Verhaeghe S, Faes K, Annemans L. Effectiveness of Supporting Informal Caregivers of People with Dementia: A Systematic Review of Randomized and Non-Randomized Controlled Trials. Journal of Alzheimer’s Disease. 2016 May 23;52(3):929–65.  
78. Bahar-Fuchs A, Clare L, Woods B. Cognitive training and cognitive rehabilitation for mild to moderate Alzheimer’s disease and vascular dementia. Cochrane Database of Systematic Reviews. 2013 Jun 5;  
79. Bahar-Fuchs A, Martyr A, Goh AM, Sabates J, Clare L. Cognitive training for people with mild to moderate dementia. Cochrane Database of Systematic Reviews. 2019 Mar 25;  
80. Woods B, Rai HK, Elliott E, Aguirre E, Orrell M, Spector A. Cognitive stimulation to improve cognitive functioning in people with dementia. Vol. 2023, Cochrane Database of Systematic Reviews. John Wiley and Sons Ltd; 2023.  
81. Spector A, Stoner CR, Chandra M, Vaitheswaran S, Du B, Comas-Herrera A, et al. Mixed methods implementation research of cognitive stimulation therapy (CST) for dementia in low and middle-income countries: study protocol for Brazil, India and Tanzania (CST-International). BMJ Open. 2019 Aug 20;9(8):e030933.  
82. Marinho V, Bertrand E, Naylor R, Bomilcar I, Laks J, Spector A, et al. Cognitive stimulation therapy for people with dementia in Brazil (CST‐Brasil): Results from a single blind randomized controlled trial. Int J Geriatr Psychiatry. 2021 Feb 11;36(2):286–93.  
83. Bertrand E, Naylor R, Laks J, Marinho V, Spector A, Mograbi DC. Cognitive stimulation therapy for brazilian people with dementia: examination of implementation’ issues and cultural adaptation. Aging Ment Health. 2019 Oct 3;23(10):1400–4.  
84. Knapp M, Iemmi V, Romeo R. Dementia care costs and outcomes: A systematic review. Vol. 28, International Journal of Geriatric Psychiatry. 2013. p. 551–61.  
85. Collins RN, Kishita N. Prevalence of depression and burden among informal care-givers of people with dementia: a meta-analysis. Ageing Soc. 2020 Nov 6;40(11):2355–92.  
86. Ma M, Dorstyn D, Ward L, Prentice S. Alzheimers’ disease and caregiving: a meta-analytic review comparing the mental health of primary carers to controls. Aging Ment Health [Internet]. 2018 Nov 2;22(11):1395–405. Available from: https://doi.org/10.1080/13607863.2017.1370689  
87. Park M, Sung M, Kim SK, Kim S, Lee DY. Multidimensional determinants of family caregiver burden in Alzheimer’s disease. Int Psychogeriatr. 2015 Aug 8;27(8):1355–64.  
25  
88. Prince M, Wimo A, Guerchet M, Ali GC, Wu YT, Prina M, et al. World Alzheimer Report 2015. The Global Impact of Dementia: An analysis of prevalence, incidence, cost and trends. [Internet]. 2015. Available from: www.alz.co.uk/worldreport2015corrections  
89. Brodaty H, Donkin M. Family caregivers of people with dementia. Dialogues Clin Neurosci. 2009 Jun 30;11(2):217–28.  
90. Cheng ST, Li KK, Losada A, Zhang F, Au A, Thompson LW, et al. The effectiveness of nonpharmacological interventions for informal dementia caregivers: An updated systematic review and meta-analysis. Psychol Aging. 2020 Feb;35(1):55–77.  
91. Losada A, Márquez-González M, Romero-Moreno R, Mausbach BT, López J, Fernández-Fernández V, et al. Cognitive–behavioral therapy (CBT) versus acceptance and commitment therapy (ACT) for dementia family caregivers with significant depressive symptoms: Results of a randomized clinical trial. J Consult Clin Psychol. 2015 Aug;83(4):760–72.  
92. Márquez-González M, Romero-Moreno R, Cabrera I, Olmos R, Pérez-Miguel A, Losada A. Tailored versus manualized interventions for dementia caregivers: The functional analysis-guided modular intervention. Psychol Aging. 2020 Feb;35(1):41–54.  
93. Han A. Effects of Mindfulness-Based Interventions on Depressive Symptoms, Anxiety, Stress, and Quality of Life in Family Caregivers of Persons Living with Dementia: A Systematic Review and Meta-analysis. Res Aging. 2022 Aug 6;44(7–8):494–509.  
94. NICE. National Institute for Health and Care Excellence. Dementia: Assessment, management and support for people living with dementia and their carers (NICE Guideline No. 97). [Internet]. NICE Guidence. 2018 [cited 2023 May 13]. Available from: https://www.nice.org.uk/guidance/ng97  
95. Walsh SC, Murphy E, Devane D, Sampson EL, Connolly S, Carney P, et al. Palliative care interventions in advanced dementia. Cochrane Database of Systematic Reviews. 2021 Sep 28;2021(9).  
96. van der Steen JT, Radbruch L, Hertogh CM, de Boer ME, Hughes JC, Larkin P, et al. White paper defining optimal palliative care in older people with dementia: A Delphi study and recommendations from the European Association for Palliative Care. Palliat Med. 2014 Mar 4;28(3):197–209.  
97. Winblad B, Black SE, Homma A, Schwam EM, Moline M, Xu Y, et al. Donepezil treatment in severe Alzheimer’s disease: a pooled analysis of three clinical trials. Curr Med Res Opin. 2009 Nov 1;25(11):2577–87.  
98. Laver K, Dyer S, Whitehead C, Clemson L, Crotty M. Interventions to delay functional decline in people with dementia: a systematic review of systematic reviews. BMJ Open. 2016 Apr 27;6(4):e010767.  
99. Ströhle A, Schmidt DK, Schultz F, Fricke N, Staden T, Hellweg R, et al. Drug and Exercise Treatment of Alzheimer Disease and Mild Cognitive Impairment: A Systematic Review and Meta-Analysis of Effects on Cognition in Randomized Controlled Trials. The American Journal of Geriatric Psychiatry. 2015 Dec;23(12):1234–49.  
100. Birks JS, Grimley Evans J. Rivastigmine for Alzheimer’s disease. In: Birks JS, editor. Cochrane Database of Systematic Reviews. Chichester, UK: John Wiley & Sons, Ltd; 2015.  
101. Jiang D, Yang X, Li M, Wang Y, Wang Y. Efficacy and safety of galantamine treatment for patients with Alzheimer’s disease: a meta-analysis of randomized controlled trials. J Neural Transm. 2015 Aug 30;122(8):1157–66. 102. Kobayashi H, Ohnishi T, Nakagawa R, Yoshizawa K. The comparative efficacy and safety of cholinesterase inhibitors in patients with mild‐to‐moderate Alzheimer’s disease: a Bayesian network meta‐analysis. Int J Geriatr Psychiatry. 2016 Aug 17;31(8):892–904.  
26  
103. Zhang XSJWYZW. Efficacy of galantamine in treatment of Alzheimer’s disease: an update meta-analysis. Int J Clin Exp Med . 2016;9(4):7423–30.  
104. Brasil. Ministério da Saúde. Memantina para doença de Alzheimer [Internet]. Brasília; 2017 Oct [cited 2023 Sep 24]. Available from: http://antigoconitec.saude.gov.br/images/Relatorios/2017/Recomendacao/Relatorio_memantina_DoencadeAlzheimer_310_FINAL.pdf  
105. Blanco-Silvente L, Castells X, Saez M, Barceló MA, Garre-Olmo J, Vilalta-Franch J, et al. Discontinuation, Efficacy, and Safety of Cholinesterase Inhibitors for Alzheimer’s Disease: a Meta-Analysis and Meta-Regression of 43 Randomized Clinical Trials Enrolling 16 106 Patients. International Journal of Neuropsychopharmacology. 2017 Jul 1;20(7):519–28.  
106. Pfizer Brasil Ltda. Eranz®. Cloridrato de Donepezila. [Internet]. Pfizer Brasil Ltda. 2023 [cited 2023 Oct 9]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=ERANZ  
107. Janssen-Cilag Farmacêutica Ltda. REMINYL® ER. Bromidrato de Galantamina. [Internet]. Janssen-Cilag Farmacêutica Ltda. 2020 [cited 2023 Oct 9]. Available from:  
https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=REMINYL  
108. United Medical. Exelon®. Hemitartarato de Rivastigmina. [Internet]. United Medical. . 2023 [cited 2023 Oct 9]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=EXELON  
109. Libbs Farmacêutica Ltda. Zider. Cloridrato de Memantina [Internet]. 2024 [cited 2025 May 21]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=zider  
110. United Medical. Exelon® Patch. Rivastigmina. Adesivos Transdérmicos. [Internet]. United Medical. 2023 [cited 2023 Oct 9]. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=EXELON 111. Lopera F, Custodio N, Rico-Restrepo M, Allegri RF, Barrientos JD, Garcia Batres E, et al. A task force for diagnosis and treatment of people with Alzheimer’s disease in Latin America. Front Neurol. 2023 Jul 11;14.  
112. Morris JC. The Clinical Dementia Rating (CDR). Neurology. 1993 Nov;43(11):2412.2-2412-a.  
113. Ferretti C, Sarti FM, Nitrini R, Ferreira FF, Brucki SMD. An assessment of direct and indirect costs of dementia in Brazil. Larson BA, editor. PLoS One [Internet]. 2018 Mar 1;13(3):e0193209. Available from: https://doi.org/10.1371/journal. pone.0193209  
114. Brasil. Ministério da Saúde. O uso de limiares de custo-efetividade nas decisões em saúde: recomendações da comissão nacional de incorporação de tecnologias no SUS [Internet]. Brasília; 2022. Available from: https://www.gov.br/conitec/pt-br/midias/pdf/2022/20221106_relatorio-uso-de-limiares-de-custo-efetividade-nasdecisoes-em-saude.pdf  
27  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE DONEPEZILA, GALANTAMINA, MEMANTINA E RIVASTIGMINA  
Eu,______________________________________________________________________________________ (nome  
do [a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de donepezila, galantamina, memantina e rivastigmina indicados para o tratamento da Doença de Alzheimer.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ___________________  
_______________________________________________________________________(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Redução na velocidade de progressão da doença.  
- Melhora da memória e da atenção.  
Fui também informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
**Donepezila** – insônia, náusea, vômitos, diarreia, anorexia, dispepsia, cãibras musculares e fadiga. Efeitos menos frequentes incluem cefaleia, sonolência, tontura, depressão, perda de peso, sonhos anormais, aumento da frequência urinária, síncope, bradicardia, artrite e equimoses. A donepezila deve ser usada com cautela em indivíduos com anormalidades supraventriculares da condução cardíaca, bloqueio de ramo ou naqueles em uso de fármacos que reduzam significativamente a frequência cardíaca, ou com história de convulsão, asma ou DPOC e com risco de úlcera péptica.  
**Galantamina** - náusea, vômitos, diarreia, anorexia, perda de peso, dor abdominal, dispepsia, flatulência, tontura, cefaleia, depressão, fadiga, insônia e sonolência. Efeitos menos frequentes: infecção do trato urinário, hematúria, incontinência, anemia, tremor, rinite e aumento da fosfatase alcalina.  
**Memantina** - cefaleia, cansaço e tontura. Efeitos menos frequentes incluem alucinações, alterações de marcha, anorexia, ansiedade, artralgia, bronquite, cistite, constipação, diarreia, confusão, dor lombar, edema periférico, hipertensão, hipertonia, infecção de trato respiratório, insônia, aumento da libido, náusea, queda, sonolência e vômitos.  
**Rivastigmina** - tontura, cefaleia, náusea, vômitos, diarreia, anorexia, fadiga, insônia, confusão e dor abdominal. Efeitos menos frequentes: depressão, ansiedade, sonolência, alucinações, síncope, hipertensão, dispepsia, constipação, flatulência, perda de peso, infecção do trato urinário, fraqueza, tremor, angina, úlcera gástrica ou duodenal e erupções cutâneas.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) Donepezila (    ) Memantina (    ) Galantamina (    ) Rivastigmina  
28  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
29

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da doença de Alzheimer, contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos da especialidade de Psiquiatria, Neurologia e Neuropsicologia.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A elaboração do PCDT da doença de Alzheimer, a iniciou-se com a demanda pelo Ministério da Saúde (MS) e as reuniões de pré-escopo, de escopo e de priorização de perguntas realizadas entre 23/06/2022 e 18/07/2022.  
Os trabalhos foram conduzidos considerando as Diretrizes Metodológicas para elaboração de PCDT. Definiu-se que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não demandariam questões de pesquisa definidas por serem práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Ainda, foram elencadas três questões de pesquisa para a elaboração do PCDT.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A proposta inicial de elaboração do PCDT da Doença de Alzheimer foi inicialmente discutida durante a reunião de préescopo, ocorrida em 23 de junho de 2022. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador e representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS).  
Posteriormente, o escopo do documento foi discutido em reunião de escopo, ocorridas em 18 de julho de 2022. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da SECTICS, representantes de sociedades médicas e especialistas convidados.  
Foram elaboradas perguntas PICO para as dúvidas clínicas e tecnologias que necessitariam de avaliação pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Após levantamento inicial das evidências pelo Grupo Elaborador, elas foram apresentadas em reunião ocorrida em 11 de agosto de 2022, com a presença de metodologistas e especialistas do Grupo Elaborador e representantes da SECTICS, SAPS, SAES e SVSA. A partir das evidências encontradas, as perguntas de pesquisa a serem respondidas foram priorizadas e validadas.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
30  
A proposta de atualização do PCDT da Doença de Alzheimer foi apresentada na 125ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 20 de maio de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS). da Secretaria de Atenção Especializada à Saúde (SAES), da Secretaria de Atenção Primária à Saúde (SAPS) e da Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de Protocolos Clínicos e Diretrizes Terapêuticas da Conitec em sua 141ª Reunião Ordinária.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A Consulta Pública nº 51/2025, para a elaboração do PCDT da Doença de Alzheimer, foi realizada entre os dias 24 de junho de 2025 e 14 de julho de 2025. Foram recebidas 46 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/contribuicao-da-cp-51_2025_protocolo_clinico_e.pdf.</u>

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (Quadro A).  
**Quadro A.** Níveis de evidências de acordo com o sistema GRADE  
||Nível|Definição|Implicações|
|---|---|---|---|
||Alto|Há forte confiança de que o<br>verdadeiro efeito esteja próximo daquele<br>estimado|É improvável que trabalhos adicionais irão modificar<br>a confiança na estimativa do efeito.|
|do|Modera|Há confiança moderada no efeito<br>estimado.|Trabalhos futuros poderão modificar a confiança na<br>estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
||Baixo|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante em nossa confiança na estimativa de efeito.|
|baixo|Muito<br>|A confiança na estimativa de efeito<br>é muito limitada.<br>Há importante grau de incerteza<br>nos achados.|Qualquer estimativa de efeito é incerta.|  
**Fonte:** Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
**QUESTÃO 1: Do ponto de vista orçamentário, é viável a incorporação da memantina solução oral e comprimido orodispersível como mais uma alternativa para o tratamento de pacientes com DA moderada e grave e que possuam dificuldade de deglutição com comprimidos?**  
31  
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de memantina solução oral e comprimido orodispersível para doença de Alzheimer moderada e grave em pacientes com disfagia, conforme Relatório de Recomendação nº 996/2025, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio-derecomendacao-no-996-cloridrato-de-memantina-em-solucao-oral-e-comprimido-orodispersivel-para-o-tratamento-da-doencade-alzheimer-moderada-e-grave-em-pacientes-com-disfagia.</u>  
A estrutura PICO para esta pergunta foi:  
|População|Pacientes com DA moderada a grave e dificuldade de adesão/ deglutição|
|---|---|
|Intervenção|Memantina solução oral<br>Memantina comprimido orodispersível|
|Comparador|Memantina comprimido|
|Desfechos|Custo incremental a cada ano e acumulado em 5 anos|  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a análise de impacto orçamentário apresentada no Relatório de Recomendação n° 996/2025 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de donepezila em monoterapia para doença de Alzheimer grave, conforme Relatório de Recomendação nº 976/2025, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio-de-recomendacao-no-976-donepezila-alzheimer.</u>  
A estrutura PICO para esta pergunta foi:  
|População|Pacientes diagnosticados recentemente com DA grave (CDR=3) em início de terapia<br>Pacientes com indicação de manutenção do tratamento que progridem para CDR=3|
|---|---|
|Intervenção|Donepezila em monoterapia ou associada à memantina|
|Comparador|(1) Placebo<br>(2) Memantina|
|Desfechos|Desfecho crítico: função cognitiva<br>Desfechos importantes: atividades diárias, sintomas neuropsiquiátricos e qualidade de vida|

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 976/2025 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**QUESTÃO 3: A CST associada ao tratamento padrão é eficaz, custo-efetiva e viável economicamente como tratamento de pacientes com doença de Alzheimer leve a moderada?**  
32  
Recomendação: Em 21 de agosto de 2024, durante a 12ª reunião da Subcomissão de Produtos e Procedimentos. entendeu que não seria necessária a avaliação do procedimento na Conitec, considerando que o procedimento só pode ser realizado mediante treinamento, e que este custo não poderia ser incluído na análise. Assim não foi possível discutir a recomendação do procedimento, e o relatório não prosseguiu para apreciação da Conitec.  
A seguir é apresentado o resultado da síntese de evidência e avaliação econômica, bem como impacto orçamentário, realizados para avaliação do procedimento.  
A estrutura PICO para esta pergunta foi:  
|População|Pacientes com DA leve e moderada|
|---|---|
|Intervenção|CST associada ao tratamento padrão|
|Comparador|Tratamento padrão|
||Desfecho crítico: cognição|
|Desfechos|Desfechos importantes: atividades de vida diárias, sintomas neuropsiquiátricos e qualidade<br>de vida|

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A população priorizada neste PTC é composta por pacientes com DA, de ambos os sexos e que apresentavam diagnóstico de DA leve a moderada. No entanto, sendo identificada evidência escassa, estudos avaliando participantes com demência também foram incluídos. Neste PTC, entendeu-se como doença de DA leve e moderada a partir do diagnóstico clínico de demência considerando os critérios do Manual de Diagnóstico de Transtornos Mentais (DSM-IV) para demência<sup>1</sup> , Mini-Exame do Estado Mental (MMSE) pontuação entre 10 e 24 que sugere demência leve e moderada<sup>2</sup> , ou Classificação Clínica de Demência (CDR) pontuação entre 0,5 e 2,0 que sugere demência leve a moderado<sup>3</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A intervenção de interesse foi a CST, a qual é recomendada pelas diretrizes do NICE do Reino Unido de 2018 “para promover cognição, independência e bem-estar” para pessoas com demência leve a moderada<sup>4</sup> . O relatório Mundial de Alzheimer também recomenda a CST para pessoas com demência em estágio inicial, seja complementando o tratamento com AChEIs ou como a principal terapia de suporte para função cognitiva naqueles que não atendem aos critérios baseados em evidências para AChEIs<sup>5</sup> .  
A CST é a única intervenção não farmacológica que envolve exercícios cognitivos estruturados e repetitivos com o objetivo de melhorar o funcionamento cognitivo, a comunicação e a qualidade de vida de indivíduos com DA e outras formas de demência<sup>6,7</sup> . A CST padrão é oferecida em grupo e conduzida por facilitadores treinados (profissionais de saúde como psicólogos, terapeutas ocupacionais, enfermeiros ou mesmo por cuidadores). As sessões de CST consistem em 14 encontros, 45 minutos cada sessão, sendo realizada em até duas vezes por semana durante um total de 7 a 14 semanas, incluindo de cinco a oito participantes por grupo<sup>8</sup> . Os grupos da CST podem ocorrer em vários ambientes, como residências / casas de repouso, hospitais ou centros-dia. As atividades temáticas realizadas durante as sessões são pré-definidas (jogos físicos, sons, infância, comida, atualidade, rostos / cenas, associação de palavras, criatividade, categorização de objetos, orientação, uso do dinheiro, jogos de números, jogos de palavras e teste de equipe)<sup>8</sup> .  
As sessões da CST visam estimular e envolver ativamente as pessoas com demência, proporcionando um ambiente de aprendizagem ideal e benefícios sociais de um grupo. Os efeitos da CST parecem ser comparáveis aos relatados com os tratamentos farmacológicos disponíveis para demência<sup>9</sup> .  
33  
Além disso, também é recomendada a CST manutenção, a qual consiste na repetição do programa da CST padrão, a fim de alcançar benefícios contínuos por seis meses<sup>10</sup> . Em estudo avaliando a CST manutenção, identificou-se que aqueles que receberam a CST manutenção e medicamento para demência (AchEIs) obtiveram melhor respostas, sugerindo a importância das duas opções disponíveis<sup>10</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Não foi considerada restrição para a composição do tratamento padrão, prevendo-se a realização de análises de sensibilidade para otimizar a homogeneidade ou alinhamento com a prática do SUS como tratamento medicamentoso. Na ausência de estudos contemplando um tratamento padrão, foram considerados estudos que compararam a CST com nenhuma intervenção ou uso de medicamento (nos grupos intervenção e controle). Além disso, ainda que a CST não seja recomendada no SUS, foram considerados estudos que compararam diferentes modalidades de CST (CST individual, CST + treinamento para cuidadores e Terapia Ocupacional). Tanto a intervenção quanto os comparadores poderiam estar associados ao tratamento padrão ou _sham_ ou ‘simulação’.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Em reunião realizada entre grupo gestor, elaborador e especialistas foram priorizados os desfechos relativos à cognição, qualidade de vida, atividades de vida diária e sintomas neuropsiquiátricos. A definição de cada um deles é apresentada a seguir:  
<u>Primários (críticos):</u>  
<u>Cognição: avaliada por questionários e/ou instrumentos de avaliação diagnóstica e de monitoramento, como o Manual</u> Diagnostico de Transtornos Mentais (DSM-IV), Mini-Exame do Estado Mental (MMSE), Escala de Avaliação da Doença de Alzheimer – subescala cognitiva (ADAS-Cog) ou Classificação Clínica de Demência (CDR).  
<u>Secundários (importantes):</u>  
<u>Atividade de vida diária (função cotidiana): avaliada por questionário e ou relatado pelo paciente ou cuidador.</u>  
<u>Qualidade de vida: avaliada por questionário e/ou escala de qualidade de vida autorreferida.</u>  
<u>Sintomas neuropsiquiátricos: avaliados por questionários e/ou instrumentos de avaliação diagnóstica, incluindo alterações</u> no comportamento, sintomas depressivos e de ansiedade.  
Não houve restrição para o tipo de pergunta ou a escala e questionário em que o desfecho foi avaliado. Neste PCT, a DA leve a moderada foi definida a partir do diagnóstico do DSM-IV ou outro instrumento de diagnóstico como o MMSE, ADASCog ou CDR.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Foram considerados para inclusão revisões sistemáticas, com ou sem meta-análises e ensaios clínicos randomizados (ECR). Não foi feita restrição para data de publicação, idioma, fase do ensaio clínico, para número de participantes por grupo ou tempo de acompanhamento. Foram excluídos os ensaios clínicos e as revisões sistemáticas que não especificaram e/ou definiram a CST como terapia de estimulação cognitiva. Adicionalmente, foram excluídos estudos reportados apenas em resumo de congresso.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Com base na pergunta PICO estruturada, foi elaborada a estratégia de busca utilizando sinônimos dos termos que englobam a população e a intervenção ( **Quadro B** ). A busca nas bases de dados foi realizada em março de 2023 por meio do PubMed Central e Medline (via PubMed), EMBASE e Cochrane Library. Os termos e resultados dessa busca encontram-se nos quadros a seguir. Para validação da estratégia de busca, uma busca no Epistemonikos foi realizada visando a identificação de potenciais revisões sistemáticas não recuperadas nas bases principais e estudos primários recuperados por essas revisões.  
34  
**Quadro B** . Estratégia de busca de evidências em base de dados.  
|Busc<br>a|Base de dados|Itens<br>encontrados|
|---|---|---|
|PubM|ed||
|#1|(((((((((((((Dementia[MeSH<br>Terms]))<br>OR<br>(Dementias[Title/Abstract]))<br>OR<br>(Amentia[Title/Abstract]))<br>OR<br>(Amentias[Title/Abstract]))<br>OR<br>(Senile<br>Paranoid<br>Dementia[Title/Abstract])) OR (Dementias, Senile Paranoid[Title/Abstract])) OR (Paranoid<br>Dementia, Senile[Title/Abstract])) OR (Paranoid Dementias, Senile[Title/Abstract])) OR<br>(Senile Paranoid Dementias[Title/Abstract])) OR (Familial Dementia[Title/Abstract])) OR<br>(Dementia, Familial[Title/Abstract])) OR (Dementias, Familial[Title/Abstract])) OR<br>(Familial Dementias[Title/Abstract])|202,825|
|#2|((((((((((((“Alzheimer Disease”[Mesh] ) OR (Alzheimer Dementia[Title/Abstract]))<br>OR (Alzheimer Dementias[Title/Abstract])) OR (Dementia, Alzheimer[Title/Abstract]))<br>OR<br>(Alzheimer’s<br>Disease[Title/Abstract]))<br>OR<br>(Dementia,<br>Alzheimer<br>Type[Title/Abstract])) OR (Alzheimer Type Dementia[Title/Abstract])) OR (Alzheimer-<br>Type<br>Dementia<br>(ATD[Title/Abstract])))<br>OR<br>(Alzheimer<br>Type<br>Dementia<br>(ATD[Title/Abstract]))) OR (Dementia, Alzheimer-Type (ATD[Title/Abstract]))) OR<br>(Alzheimer’s Diseases[Title/Abstract])) OR (Alzheimer Diseases[Title/Abstract])) OR<br>(Alzheimers Diseases[Title/Abstract])|18,963|
|#3|#1 OR #2|260,779|
|#4|((((Cognitive stimulation Therapy [Supplementary Concept]) OR (Therapy,<br>Cognitive<br>stimulation<br>[Title/Abstract]))<br>OR<br>(cognitive<br>stimulation<br>Therapies<br>[Title/Abstract]))<br>OR<br>(Therapies,<br>Cognitive<br>stimulation<br>[Title/Abstract]))<br>OR<br>(CST[Title/Abstract])|6,191|
|#5|(“randomized controlled trial”[Publication Type] OR “controlled clinical<br>trial”[Publication Type] OR “randomized”[Title/Abstract] OR “placebo”[Title/Abstract]<br>OR<br>“drug<br>therapy”[MeSH<br>Subheading]<br>OR<br>(“randomly”[Title/Abstract]<br>OR<br>“trial”[Title/Abstract] OR “groups”[Title/Abstract])) NOT (“animals”[MeSH Terms] NOT<br>“humans”[MeSH Terms])|4,963,44<br>5|
|#6|(((systematic review[ti] OR systematic literature review[ti] OR systematic scoping<br>review[ti] OR systematic narrative review[ti] OR systematic qualitative review[ti] OR<br>systematic evidence review[ti] OR systematic quantitative review[ti] OR systematic meta-<br>review[ti] OR systematic critical review[ti] OR systematic mixed studies review[ti] OR<br>systematic mapping review[ti] OR systematic 35lzheime review[ti] OR systematic search<br>and review[ti] OR systematic integrative review[ti]) NOT comment[pt] NOT (protocol[ti]<br>OR protocols[ti])) NOT MEDLINE [subset]) OR (Cochrane Database Syst Rev[ta] AND<br>review[pt]) OR systematic review[pt]|260,823|
|#7<br>#8|#5 AND #6<br>#3 AND #4 AND #7|5,116,05<br>5<br>234|  
35  
|Busc<br>a|Base de dados|Itens<br>encontrados|
|---|---|---|
|Emba|se||
|#1|((‘dementia’/exp OR ‘dementia’ OR ‘amentia’ OR ‘demention’|448,849|
|#2|‘alzheimer disease’/exp OR ‘alzheimer disease’ OR ‘alzeimer disease’ OR<br>‘alzeimer`s disease’ OR ‘alzeimers disease’ OR ‘alzheimer dementia’ OR ‘alzheimer<br>fibrillary change’ OR ‘alzheimer fibrillary lesion’ OR ‘alzheimer neurofibrillary change’<br>OR ‘alzheimer neurofibrillary degeneration’ OR ‘alzheimer neuron degeneration’ OR<br>‘alzheimer perusini disease’ OR ‘alzheimer sclerosis’ OR ‘alzheimer syndrome’ OR<br>‘alzheimer`s disease’ OR ‘alzheimers disease’ OR ‘cortical sclerosis, diffuse’ OR<br>‘dementia, alzheimer’ OR ‘diffuse cortical sclerosis’ OR ‘late onset  lzheimer disease’)<br>AND [embase]/lim|263,558|
|#3|#1 OR #2|448,849|
|#4|(‘cognitive stimulation therapy’/exp OR ‘cognitive stimulation therapy’ OR ‘cst’)<br>AND [embase]/lim|8,066|
|#5|#1 ‘randomized controlled trial’/de<br>#2 ‘controlled clinical trial’/de<br>#3 random*:ti,ab,tt<br>#4 ‘randomization’/de<br>#5 ‘intermethod comparison’/de<br>#6 placebo:ti,ab,tt<br>#7 (compare:ti,tt OR compared:ti,tt OR comparison:ti,tt)<br>#8 (evaluated:ab OR evaluate:ab OR evaluating:ab OR assessed:ab OR assess:ab)<br>AND (compare:ab OR compared:ab OR comparing:ab OR comparison:ab)<br>#9 (open NEXT/1 label):ti,ab,tt<br>#10 ((double OR single OR doubly OR singly) NEXT/1 (blind OR blinded OR<br>blindly)):ti,ab,tt<br>#11 ‘double blind procedure’/de<br>#12 (parallel NEXT/1 group*):ti,ab,tt<br>#13 (crossover:ti,ab,tt OR ‘cross over’:ti,ab,tt)<br>#14 ((assign* OR match OR matched OR allocation) NEAR/6 (alternate OR group<br>OR groups OR intervention OR interventions OR patient OR patients OR subject OR<br>subjects OR participant OR participants)):ti,ab,tt<br>#15 (assigned:ti,ab,tt OR allocated:ti,ab,tt)<br>#16 (controlled NEAR/8 (study OR design OR trial)):ti,ab,tt<br>#17 (volunteer:ti,ab,tt OR volunteers:ti,ab,tt)<br>#18 ‘human experiment’/de<br>#19 trial:ti,tt<br>#20 #1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10 OR #11<br>OR #12 OR #13 OR #14 OR #15 OR #16 OR #17 OR #18 OR #19|5,441,11<br>4|  
36  
|Busc<br>a|Base de dados|Itens<br>encontrados|
|---|---|---|
||#21 (((random* NEXT/1 sampl* NEAR/8 (‘cross section*’ OR questionnaire* OR<br>survey OR surveys OR database or databases)):ti,ab,tt) NOT (‘comparative study’/de OR<br>‘controlled<br>study’/de<br>OR<br>‘randomised<br>controlled’:ti,ab,tt<br>OR<br>‘randomized<br>controlled’:ti,ab,tt OR ‘randomly assigned’:ti,ab,tt))<br>#22 (‘cross‐sectional study’/de NOT (‘randomized controlled trial’/de OR<br>‘controlled clinical trial’/de OR ‘controlled study’/de OR ‘randomised controlled’:ti,ab,tt<br>OR ‘randomized controlled’:ti,ab,tt OR ‘control group’:ti,ab,tt OR ‘control groups’:ti,ab,tt))<br>#23<br>(‘case<br>control*’:ti,ab,tt<br>AND<br>random*:ti,ab,tt<br>NOT<br>(‘randomised<br>controlled’:ti,ab,tt OR ‘randomized controlled’:ti,ab,tt))<br>#24 (‘systematic review’:ti,tt NOT (trial:ti,tt OR study:ti,tt))<br>#25 (nonrandom*:ti,ab,tt NOT random*:ti,ab,tt)<br>#26 ‘random field*’:ti,ab OR ‘random field*’:tt<br>#27 (‘random cluster’ NEAR/4 sampl*):ti,ab,tt<br>#28 (review:ab AND review:it) NOT trial:ti,tt<br>#29 (‘we searched’:ab AND (review:ti,tt OR review:it))<br>#30 ‘update review’:ab<br>#31 (databases NEAR/5 searched):ab<br>#((rat:ti,tt OR rats:ti,tt OR mouse:ti,tt OR mice:ti,tt OR swine:ti,tt OR porcine:ti,tt<br>OR murine:ti,tt OR sheep:ti,tt OR lambs:ti,tt OR pigs:ti,tt OR piglets:ti,tt OR rabbit:ti,tt OR<br>rabbits:ti,tt OR cat:ti,tt OR cats:ti,tt OR dog:ti,tt OR dogs:ti,tt OR cattle:ti,tt OR bovine:ti,tt<br>OR monkey:ti,tt OR monkeys:ti,tt OR trout:ti,tt OR marmoset*:ti,tt) AND ‘animal<br>experiment’/de)<br>#33 ‘animal experiment’/de NOT (‘human experiment’/de OR ‘human’/de)<br>#34 #21 OR #22 OR #23 OR #24 OR #25 OR #26 OR #27 OR #28 OR #29 OR #30<br>OR #31 OR #32 OR #33<br>#35 #20 NOT #34||
|#6|(‘meta analysis (topic)’/exp OR ‘meta analysis’/exp OR ((meta NEXT/1<br>analy*):ab,ti) OR metaanaly*:ab,ti OR ‘systematic review (topic)’/exp OR ‘systematic<br>review’/exp OR ((systematic NEXT/1 review*):ab,ti)|740,204|
|#7<br>#8|((systematic NEXT/1 overview*):ab,ti) OR cancerlit:ab,ti OR  lzheime:ab,ti OR<br>embase:ab,ti OR psychlit:ab,ti OR psyclit:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti OR<br>cinahl:ab,ti OR cinhal:ab,ti OR ‘science citation index’:ab,ti OR bids:ab,ti OR ((reference<br>NEXT/1 list*):ab,ti) OR bibliograph*:ab,ti OR ‘hand search*’:ab,ti OR ((manual NEXT/1<br>search*):ab,ti) OR ‘relevant journals’:ab,ti OR ((‘data extraction’:ab,ti OR ‘selection<br>criteria’:ab,ti) AND review/it)) NOT (letter/it OR editorial/it OR (‘animal’/exp NOT<br>(‘animal’/exp AND ‘human’/exp)))<br>#6 AND #7||  
37  
|Busc<br>a|Base de dados|Itens<br>encontrados|
|---|---|---|
|#9|[embase]/lim NOT ([embase]/lim AND [medline]/lim) AND (‘Article’/it OR<br>‘Article in Press’/it OR ‘Chapter’/it OR ‘Conference Paper’/it OR ‘Conference Review’/it<br>OR ‘Erratum’/it OR ‘Note’/it OR ‘Review’/it OR ‘Short Survey’/it OR ‘Tombstone’/it)|5,463,67<br>5|
|#10|#3 AND #4 AND #5 AND #8 AND #9|29|
|Coch|rane Library||
|#1|((‘dementia’/exp OR ‘dementia’ OR ‘amentia’ OR ‘demention’|448,849|
|#2|‘alzheimer disease’/exp OR ‘alzheimer disease’ OR ‘alzeimer disease’ OR<br>‘alzeimer`s disease’ OR ‘alzeimers disease’ OR ‘alzheimer dementia’ OR ‘alzheimer<br>fibrillary change’ OR ‘alzheimer fibrillary lesion’ OR ‘alzheimer neurofibrillary change’<br>OR ‘alzheimer neurofibrillary degeneration’ OR ‘alzheimer neuron degeneration’ OR<br>‘alzheimer perusini disease’ OR ‘alzheimer sclerosis’ OR ‘alzheimer syndrome’ OR<br>‘alzheimer`s disease’ OR ‘alzheimers disease’ OR ‘cortical sclerosis, diffuse’ OR<br>‘dementia, alzheimer’ OR ‘diffuse cortical sclerosis’ OR ‘late onset  lzheimer disease’)<br>AND [embase]/lim|263,558|
|#3|#1 OR #2|448,849|
|#4|(‘cognitive stimulation therapy’/exp OR ‘cognitive stimulation therapy’ OR ‘cst’)<br>AND [embase]/lim|8,066|
|#5|#1 ‘randomized controlled trial’/de<br>#2 ‘controlled clinical trial’/de<br>#3 random*:ti,ab,tt<br>#4 ‘randomization’/de<br>#5 ‘intermethod comparison’/de<br>#6 placebo:ti,ab,tt<br>#7 (compare:ti,tt OR compared:ti,tt OR comparison:ti,tt)<br>#8 (evaluated:ab OR evaluate:ab OR evaluating:ab OR assessed:ab OR assess:ab)<br>AND (compare:ab OR compared:ab OR comparing:ab OR comparison:ab)<br>#9 (open NEXT/1 label):ti,ab,tt<br>#10 ((double OR single OR doubly OR singly) NEXT/1 (blind OR blinded OR<br>blindly)):ti,ab,tt<br>#11 ‘double blind procedure’/de<br>#12 (parallel NEXT/1 group*):ti,ab,tt<br>#13 (crossover:ti,ab,tt OR ‘cross over’:ti,ab,tt)<br>#14 ((assign* OR match OR matched OR allocation) NEAR/6 (alternate OR group<br>OR groups OR intervention OR interventions OR patient OR patients OR subject OR<br>subjects OR participant OR participants)):ti,ab,tt<br>#15 (assigned:ti,ab,tt OR allocated:ti,ab,tt)<br>#16 (controlled NEAR/8 (study OR design OR trial)):ti,ab,tt|5,441,11<br>4|  
38  
|Busc<br>a|Base de dados|Itens<br>encontrados|
|---|---|---|
||#17 (volunteer:ti,ab,tt OR volunteers:ti,ab,tt)<br>#18 ‘human experiment’/de<br>#19 trial:ti,tt<br>#20 #1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10 OR #11<br>OR #12 OR #13 OR #14 OR #15 OR #16 OR #17 OR #18 OR #19<br>#21 (((random* NEXT/1 sampl* NEAR/8 (‘cross section*’ OR questionnaire* OR<br>survey OR surveys OR database or databases)):ti,ab,tt) NOT (‘comparative study’/de OR<br>‘controlled<br>study’/de<br>OR<br>‘randomised<br>controlled’:ti,ab,tt<br>OR<br>‘randomized<br>controlled’:ti,ab,tt OR ‘randomly assigned’:ti,ab,tt))<br>#22 (‘cross‐sectional study’/de NOT (‘randomized controlled trial’/de OR<br>‘controlled clinical trial’/de OR ‘controlled study’/de OR ‘randomised controlled’:ti,ab,tt<br>OR ‘randomized controlled’:ti,ab,tt OR ‘control group’:ti,ab,tt OR ‘control groups’:ti,ab,tt))<br>#23<br>(‘case<br>control*’:ti,ab,tt<br>AND<br>random*:ti,ab,tt<br>NOT<br>(‘randomised<br>controlled’:ti,ab,tt OR ‘randomized controlled’:ti,ab,tt))<br>#24 (‘systematic review’:ti,tt NOT (trial:ti,tt OR study:ti,tt))<br>#25 (nonrandom*:ti,ab,tt NOT random*:ti,ab,tt)<br>#26 ‘random field*’:ti,ab OR ‘random field*’:tt<br>#27 (‘random cluster’ NEAR/4 sampl*):ti,ab,tt<br>#28 (review:ab AND review:it) NOT trial:ti,tt<br>#29 (‘we searched’:ab AND (review:ti,tt OR review:it))<br>#30 ‘update review’:ab<br>#31 (databases NEAR/5 searched):ab<br>#((rat:ti,tt OR rats:ti,tt OR mouse:ti,tt OR mice:ti,tt OR swine:ti,tt OR porcine:ti,tt<br>OR murine:ti,tt OR sheep:ti,tt OR lambs:ti,tt OR pigs:ti,tt OR piglets:ti,tt OR rabbit:ti,tt OR<br>rabbits:ti,tt OR cat:ti,tt OR cats:ti,tt OR dog:ti,tt OR dogs:ti,tt OR cattle:ti,tt OR bovine:ti,tt<br>OR monkey:ti,tt OR monkeys:ti,tt OR trout:ti,tt OR marmoset*:ti,tt) AND ‘animal<br>experiment’/de)<br>#33 ‘animal experiment’/de NOT (‘human experiment’/de OR ‘human’/de)<br>#34 #21 OR #22 OR #23 OR #24 OR #25 OR #26 OR #27 OR #28 OR #29 OR #30<br>OR #31 OR #32 OR #33<br>#35 #20 NOT #34||
|#6|(‘meta analysis (topic)’/exp OR ‘meta analysis’/exp OR ((meta NEXT/1<br>analy*):ab,ti) OR metaanaly*:ab,ti OR ‘systematic review (topic)’/exp OR ‘systematic<br>review’/exp OR ((systematic NEXT/1 review*):ab,ti)|740,204|
|#7|((systematic NEXT/1 overview*):ab,ti) OR cancerlit:ab,ti OR  lzheime:ab,ti OR<br>embase:ab,ti OR psychlit:ab,ti OR psyclit:ab,ti OR psychinfo:ab,ti OR psycinfo:ab,ti OR<br>cinahl:ab,ti OR cinhal:ab,ti OR ‘science citation index’:ab,ti OR bids:ab,ti OR ((reference<br>NEXT/1 list*):ab,ti) OR bibliograph*:ab,ti OR ‘hand search*’:ab,ti OR ((manual NEXT/1||  
39  
|Busc<br>a|Base de dados|Itens<br>encontrados|
|---|---|---|
||search*):ab,ti) OR ‘relevant journals’:ab,ti OR ((‘data extraction’:ab,ti OR ‘selection||
||criteria’:ab,ti) AND review/it)) NOT (letter/it OR editorial/it OR (‘animal’/exp NOT<br>(‘animal’/exp AND ‘human’/exp)))||
|#8|#6 AND #7||
|#9|[embase]/lim NOT ([embase]/lim AND [medline]/lim) AND (‘Article’/it OR|5,463,67|
||‘Article in Press’/it OR ‘Chapter’/it OR ‘Conference Paper’/it OR ‘Conference Review’/it|5|
||OR ‘Erratum’/it OR ‘Note’/it OR ‘Review’/it OR ‘Short Survey’/it OR ‘Tombstone’/it)||
|#10|#3 AND #4 AND #5 AND #8 AND #9|29|  
**Fonte:** elaboração própria.  
Uma busca no clinicaltrials.gov foi realizada com o intuito de identificar os estudos em andamento sobre a CST, e como busca manual, avaliar se tem resultado já publicado sobre estes estudos. Para isso foram utilizados apenas os termos “ _dementia_ ” OR “ _Azheimer disease_ ” AND “ _cognitive stimulation therapy_ ” OR “CST” e a busca foi realizada em março de 2023.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A seleção dos estudos elegíveis, compreendendo as etapas de leitura de título e resumo (triagem) e leitura por texto completo (elegibilidade) foi realizada por um avaliador, sendo consultado um segundo avaliador em caso de dúvidas que foram resolvidas em consenso. Foi utilizado o software Rayyan<sup>11</sup> para realizar a exclusão das referências duplicadas e a triagem dos estudos em avaliação.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Para a extração dos dados foi utilizada uma planilha Microsoft Office Excel® pré-estruturada e foi realizada por um único avaliador. Os seguintes dados foram extraídos:  
- Características dos estudos, intervenções e participantes: autor; ano; país; desenho do estudo; características gerais da população; número de participantes; idade média; alternativas comparadas; profissional que conduziu a intervenção; duração do tratamento e critérios de inclusão.  
- Desfechos e resultados: na extração dos dados dos desfechos, coletou-se as pontuações médias, os desvios-padrão e os tamanhos das amostras dos estudos. Quando essas informações não foram fornecidas, os valores foram calculados ou imputados, usando métodos recomendados no _Cochrane Handbook for Systematic Reviews of Interventions_<sup>12</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O risco de viés foi avaliado de acordo com o delineamento do estudo _,_ por um único avaliador. Havendo revisão sistemática incluída, foi avaliada por meio da ferramenta AMSTAR-2<sup>13</sup> . Havendo ensaios clínicos randomizados incluídos, foram avaliados por meio da ferramenta _Cochrane Risk of Bias Tool – ROB 2.0_<sup>14,15</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
As características dos estudos e dos participantes foram apresentadas de forma narrativa e por estatística descritiva, incluindo tabelas para o auxílio na apresentação dos resultados. Os resultados narrativos foram agrupados por desfecho.  
Existindo mais de um estudo incluído e homogeneidade entre eles, análises quantitativas (meta-análises diretas) foram realizadas com o uso dos softwares R e R Studio<sup>16</sup> . Os dados contínuos dos ensaios clínicos controlados foram avaliados por meio da média e desvio-padrão da mudança entre antes e após a realização das sessões de CST, sendo sumarizada pela diferença de média (MD) [IC 95%].  
40  
Nas análises quantitativas, os resultados foram agrupados segundo os desfechos e os resultados foram apresentados em tabelas e _forest plot._ Foram consideradas diferenças médias (avaliações dentro de uma escala) ou diferenças médias padronizadas (avaliações considerando múltiplas escalas para um mesmo desfecho). Metarregressão foi planejada para a variável idade média dos participantes e análises de subgrupos foram planejadas considerando características da CST (profissional, frequência semanal e duração), escalas utilizadas e separando DA de demência.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A qualidade ou confiança da evidência foi avaliada considerando _Grading of Recommendations Assessment, Development and Evaluation (GRADE) Working Group,_ diretrizes metodológicas: sistema GRADE<sup>17</sup> .  A qualidade da evidência do desfecho primário, cognição, foi graduada em alta, moderada, baixa e muito baixa confiança, considerando os critérios de rebaixamento da qualidade (limitações metodológicas, evidência indireta, inconsistência, imprecisão de estimativa de efeito e risco de viés de publicação). Os dados do ECR foram inicialmente classificados como de alta qualidade; em seguida a qualidade da evidência para cada resultado foi rebaixada ou não a partir deste ponto inicial.  
Não há um padrão bem estabelecido para limiar de significância clínica, porém foi adotado SMD de 0,50 ou mais como uma diferença importante, considerando definição utilizada em revisão sistemática da Colaboração Cochrane<sup>18</sup> . Este limiar inclusive é mais conservador que a literatura sobre diferenças clinicamente importante mínimas em estudos de demência que apontam 0,40<sup>19</sup> , considerando assim menor que 0,10 como insignificante; 0,10 a 0,40 leve; 0,40 a 0,50 pequeno.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A **Figura A** apresenta o fluxograma de seleção dos estudos.  
**Figura A.** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
fi Rogistros identficados (n= 275) ogists removidos antes da<br>CochrEmbasePubMedGlinic l a netrials (n=(n(n= = 29) 234)(n= 12)120) Registros duplicados‘iagom:(8)removidos eletronicamente WebsitesOrganizacéesPesquisaRogistos (n= identicadosde citagoes0)(n= 0) (n=de: 0)<br>Rogistos trades Rogistros excuidos<br>(n= 386) (0=334)<br>=<br>i<br>B | Rosistos procurados para Rogistros nfo recuperados n=O n=O)<br>reciperaglo(a=52)<br>Hy<br>H ae" | = =<br>i == =<br>1 | Sesrsesciesrf elegibilidade exciuidos<br>Rogistros avaliados para Po 2)<br>siegbiade(a= 52) Desfechosino)(n=6)<br>Delineamento do estudo (n=14)<br>‘Trials sem resultados (n=2)<br>(19)<br>Estudos incluidos no PTC<br>(o=19)<br>| Regatosnculdos no PTC<br><!-- End of picture text -->  
**Fonte** : Traduzido e preenchido de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
41  
Foram incluídos 10 ensaios clínicos randomizados (ECR) e nove revisões sistemáticas (RS) nos quais se avaliou a eficácia da CST ( **Quadro** e **Quadro D** ). Além destes, foi incluído um ECR avaliando a modalidade da CST de manutenção como evidência complementar.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
As revisões sistemáticas foram publicadas entre 2012 e 2023 incluindo de cinco a 44 estudos. Em sete revisões sistemáticas foram incluídas meta-análises diretas<sup>18,20–25</sup> e em duas meta-análises em rede<sup>26,27</sup> . Embora as revisões sistemáticas sejam recentes, observou-se diferentes critérios de elegibilidade (população, modalidades de intervenção e desfecho) entre elas, o que resultou em diferentes estudos incluídos ( **Quadro** ). Desta forma, optou-se por dar ênfase à análise dos ECR.  
**Quadro C** . Caracterização das revisões sistemáticas com meta-análise.  
|Estudo|Características da<br>população|N de estudos /<br>participantes|Alternativas comparadas|Desfechos de interesse<br>para o PTC reportados|
|---|---|---|---|---|
|Gomez-Soria,<br>2023<sup>**20**</sup>|Idosos >= 65 anos<br>saudáveis, CCL ou<br>demência.|33 estudos /<br>2.724<br>participantes|CST_versus_tratamento<br>padrão ou controle ativo|Cognição, qualidade<br>de vida, depressão e<br>ansiedade.|
|Woods, 2023<sup>**18**</sup>|Pacientes com<br>diagnóstico de demência.|36 estudos /<br>718<br>participantes|CST_versus_tratamento<br>padrão/sem intervenção|Cognição, qualidade<br>de vida, depressão.|
|Chen, 2022<sup>**21**</sup>|Pacientes com<br>diagnóstico de DA.|10 estudos /<br>315<br>participantes|CST_versus_tratamento<br>padrão/AchEIs|Cognição, qualidade,<br>depressão, ansiedade e<br>AVD.|
|Saragih, 2022<sup>**22**</sup>|Pacientes com<br>demência leve a<br>moderada.|26 estudos /<br>2.244<br>participantes|CST_versus_tratamento<br>padrão|Cognição e<br>depressão.|
|Sun, 2022<sup>**26**</sup>|Pacientes com<br>diagnóstico de demência<br>ou DA.|17 estudos /<br>1.680<br>participantes|CST, MCST, iCST<br>_versus_grupo controle|Cognição e<br>qualidade de vida.|
|Cafferata, 2021<sup>**23**</sup>|Pacientes com<br>diagnóstico de demência.|44 estudos /<br>2.444<br>participantes|OR, CST e RT_versus_<br>grupo controle|Cognição, qualidade<br>de vida, AVD,<br>depressão, ansiedade,<br>comportamento.|
|Chen, 2019<sup>**24**</sup>|Pacientes com<br>diagnóstico de DA.|5 estudos /<br>315<br>participantes|CST + AChEIs_versus_<br>AchEIs.|Cognição e<br>comportamento.|
|Duan, 2018<sup>**27**</sup>|Pacientes com<br>diagnóstico de DA leve a<br>moderado.|10 estudos /<br>682<br>participantes|Intervenções psicossociais<br>(CST, HE, GE, RT, WP,<br>MBAS e AT)_versus_grupo<br>controle (tratamento padrão<br>ou AChEIS)|Cognição.|  
42  
|Estudo|Características da|N de estudos /|Alternativas comparadas|Desfechos de interesse|
|---|---|---|---|---|
||população|participantes||para o PTC reportados|
|Huntley, 2015<sup>**25**</sup>|Participantes com|33 estudos /|CS, CT e CR_versus_|Cognição.|
||diagnóstico de demência.|1.010<br>participantes|tratamento padrão / não<br>intervenção.||  
**Fonte** : Elaboração própria. **Legenda** : CCL: Comprometimento cognitivo leve; DA: Doença de Alzheimer; CST: Terapia de estimulação cognitiva; AVD: atividade de vida diária; AChEIs: inibidores de acetilcolinesterase; MCST: terapia de estimulação cognitiva de manutenção; iCST: terapia de estimulação cognitiva individual; OR: orientação da realidade; RT: terapia de reminiscência; HE: exercícios domiciliares; GE: exercícios em grupo; WP: programa de caminhada; MBAS: estimulação de Alzheimer baseada em _mindfulness_ ; AT: arte terapia; CS: estimulação cognitiva; CT: treinamento cognitivo; CR: reabilitação cognitiva.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Os ECRs foram publicados de 2003 a 2021 envolvendo um total de 926 participantes. Nos estudos foram incluídos participantes de uma variedade de ambientes como residências / casas de repouso (n=6), centros-dia (n=3) e sanatório militar (n=1), sendo conduzidos em diferentes países como Inglaterra (n=3), Itália (n=3), Brasil (n=1), Turquia (n=1), Japão (n=1) e China (n=1). A média de idade dos participantes variou entre 77,8 e 87,4. A caracterização dos ECR e dos participantes foi descrita nos parágrafos abaixo e no **Quadro D.**  
Em todos os ECR elegíveis se avaliou a eficácia da CST comparada a um tratamento padrão, placebo ou outras modalidades de intervenção, e em todos se avaliaram os desfechos no pré- e pós-intervenção (após as 14 sessões).  
Em oito estudos<sup>7,28–34</sup> se definiu como critério de elegibilidade o diagnóstico de demência leve e moderada, e em outros dois<sup>35,36</sup> o diagnóstico de DA. A duração da CST variou de sete a 14 semanas, o tempo de sessão variou de 45 a 60 minutos e a frequência de sessões de uma a duas vezes por semana.  
Em dois estudos<sup>28,29</sup> , realizados na Itália, se comparou a eficácia da CST com um grupo controle ativo (atividades educacionais alternativas como leitura de artigos, jornais ou livros, discussão em grupo e atividades criativas, como colorir, pintar, decorar ou cozinhar). Em cinco estudos<sup>7,31,33–35</sup> se comparou a eficácia da CST com tratamento padrão. Em geral, nos estudos em que foi relatado, o tratamento padrão foi descrito como visitas ao psiquiatra geriátrico e tratamento medicamentoso com ACHEIs. Nesses casos ambos os grupos receberam os mesmos medicamentos.  
Em um estudo se avaliou a eficácia da CST comparando-a a um grupo _sham,_ isto é, intervenção simulada<sup>36</sup> . Em três estudos se comparou a eficácia da CST com dois outros grupos, sendo os pacientes randomizados para três grupos diferentes 30,32,37, mas para este PTC foi analisado apenas os resultados de comparação da CST com grupo controle e/ou _sham_ .  
Em quatro estudos se utilizou como critério de inclusão a confirmação do diagnóstico de demência pelo DSM-IV e a definição de demência leve a moderada a partir do MMSE<sup>9,28,30,34</sup> . Em dois estudos se considerou como critério de inclusão o diagnóstico de demência leve a moderada tanto pelo MMSE e CDR<sup>29,32</sup> . Em quatro estudos se utilizou apenas o critério de demência leve a moderada pelo MMSE<sup>31,33,35,36</sup> .  
Em relação às ferramentas utilizadas para aferir o desfecho primário, função cognitiva, em quatro dos onze estudos se utilizou apenas uma escala (MMSE ou ADAS-Cog)<sup>7,34–36</sup> . Nos demais se utilizaram de duas a três escalas (MMSE, ADAS-Cog ou CDR). Em relação aos desfechos secundários, em sete estudos se utilizaram diferentes questionários para avaliar qualidade de vida<sup>28–31,33–35</sup> , em três se avaliou a atividade de vida diária<sup>28,29,34</sup> e em sete os sintomas neuropsiquiátricos, como alterações de comportamento<sup>28,29,32,33,36</sup> , depressão<sup>9,28,29,33,34</sup> e ansiedade<sup>33</sup> .  
43  
**Quadro D** . Caracterização dos ensaios clínicos randomizados (ECR).  
|Autor, ano|Pais, contexto|Delineamento|Características da<br>população/<br>critérios de<br>seleção*|N|Média de<br>idade|Alternativas<br>comparadas|Desfechos primários<br>avaliados: escalas|Profissionais/<br>participantes por<br>grupo|Frequência e duração|
|---|---|---|---|---|---|---|---|---|---|
|Carbone et<br>al, 2021<sup>**28**</sup>|Itália, Casas de<br>repouso e<br>centros dia.|ECR, simples<br>cego,<br>multicêntrico|Pacientes com<br>demência leve a<br>moderada.<br>MMSE: ≥ 14;<br>CDR: 1 ou 2.|225|83,6|CST_versus_<br>controle ativo<br>a|Cognição: MMSE e<br>ADAS-Cog; Qualidade<br>de vida: QoL-AD;<br>Atividade de vida diária:<br>DAD; Sintomas<br>neuropsiquiátricos: NPI|Psicólogos<br>treinados<br>7 a 8 participantes|7 semanas – 2 x por<br>semana (14 sessões)|
|Marinho et<br>al, 2021<sup>**34**</sup>|Brasil, Centro<br>para DA<br>(CDA –<br>UFRJ).|ECR, simples<br>cego, centro<br>único.|Pacientes com<br>demência leve a<br>moderada.<br>MMSE: 10 a 24|47|77,8|CST +<br>AchEIs_versus_<br>tratamento<br>padrão<sup>b</sup>+<br>AchEIs|Cognição: ADAS-Cog;<br>Sintomas<br>neuropsiquiátricos:<br>CSDD; Atividade de<br>vida diária: ADCS-<br>ADL; Qualidade de ida:<br>QoL-AD.|Pesquisadores<br>treinados<sup>c</sup><br>5 a 8 participantes|7 semanas – 2 x por<br>semana (no mesmo<br>dia com intervalo)<br>(14 sessões de 45<br>min).|
|Lok et al,<br>2019<sup>**35**</sup>|Turquia,<br>Policlínica<br>neurológica.|ECR, centro<br>único.|Pacientes com DA<br>leve a moderada<sup>1</sup>.<br>MMSE: 13 a 24;|60|NR|CST baseado<br>em RAM<br>_versus_<br>tratamento<br>padrão<sup>d</sup>|Cognição: MMSE;<br>Qualidade de vida:<br>QoL-AD|NR / NR|7 semanas – 2 x por<br>semana (Sessões de<br>45 min)|
|Capotosto<br>et al, 2017<br>**29**|Itália,<br>Residênciais.|ECR, simples<br>cego,<br>multicêntrico|Pacientes com<br>demência leve a<br>moderada<sup>2</sup>.<br>MMSE: ≥ 14;|39|87,4|CST_versus_<br>controle ativo<br>a|Cognição: MMSE e<br>ADAS-Cog; Qualidade<br>de vida: QoL-AD;<br>Sintomas|Psicólogos<br>treinados<br>7 a 8 participantes|7 semanas – 2 x por<br>semana (Sessões de<br>45 min)|  
44  
|Autor, ano|Pais, contexto|Delineamento|Características da<br>população/<br>critérios de<br>seleção*|N|Média de<br>idade|Alternativas<br>comparadas|Desfechos primários<br>avaliados: escalas|Profissionais/<br>participantes por<br>grupo|Frequência e duração|
|---|---|---|---|---|---|---|---|---|---|
||||CDR: 1 ou2||||neuropsiquiátricos:<br>CSDD|||
|Cove et al,<br>2014<sup>**30**</sup>|Inglaterra,<br>Comunidade.|ECR, simples<br>cego, centro<br>único.|Pacientes com<br>demência leve a<br>moderada<sup>3</sup>.<br>MMSE: 18 a 30|72|77,3|CST_versus_<br>lista de espera|Cognição: MMSE e<br>ADAS-Cog; Qualidade<br>de vida: QoL-AD|NR / NR|14 semanas – 1x por<br>semana (Sessões de<br>45 min)|
|Mapelli et<br>al, 2013<sup>**32**</sup>|Itália, Casas de<br>repouso.|ECR, centro<br>único.|Idosos com<br>demência leve a<br>moderada<sup>3</sup><br>MMSE: 14 a24<br>CDR: 1 ou 2|30|83,7|CST versus<br>placebo (TO)<sup>f</sup><br>_versus_<br>tratamento<br>padrão<sup>g</sup>|Cognição: CDR; MMSE<br>e ENB2; Sintomas<br>neuropsiquiátricos:<br>Behave-AD|Psicólogo<br>NR|8 semanas, 40<br>sessões (1 hora<br>p/sessão ou 5<br>h/semanais).|
|Yamanaka|Japão,|ECR, simples|Idosos com|56|83,9|CST v_ersus_|Cognição: MMSE e|Pesquisadores|7 semanas – 2 x por|
|et al, 2013<br>**31**|Residênciais.|cego,<br>multicêntrico|demência leve a<br>moderada.<br>MMSE: ≥10|||tratamento<br>padrão<sup>d</sup>|COGNISTAT;<br>Qualidade de vida:<br>QoL-AD e EQ-5D.|treinados c<br>NR|semana (Sessões de<br>45 min)|
|Coen et al,<br>2011<sup>**33**</sup>|Inglaterra,<br>Residênciais e<br>Hospitais.|ECR, simples<br>cego,<br>multicêntrico|Pacientes com<br>demência leve a<br>moderada.<br>MMSE: 10 a 23|27|79,8|CST +<br>tratamento<br>padrão h<br>_versus_<br>tratamento<br>padrão<sup>h</sup>|Cognição: MMSE, CDR<br>e ADAS-Cog;<br>Qualidade de vida:<br>QoL-AD; Sintomas<br>neuropsiquiátricos:<br>CAPE-BRS e RAID.|Terapeuta<br>ocupacional<br>5 participantes|7 semanas – 2 x por<br>semana (Sessões de<br>45 min)|  
45  
|Autor, ano|Pais, contexto|Delineamento|Características da<br>população/<br>critérios de<br>seleção*|N|Média de<br>idade|Alternativas<br>comparadas|Desfechos primários<br>avaliados: escalas|Profissionais/<br>participantes por<br>grupo|Frequência e duração|
|---|---|---|---|---|---|---|---|---|---|
|Niu et al,<br>2010<sup>**36**</sup>|China,<br>Sanatório<br>militar|ECR, simples<br>cego,<br>multicêntrico|Pacientes com DA<br>leve a moderada<sup>4</sup><br>MMSE: 10 a 24;<br>NPI:> 5|32|79,13|CST + Acheis<br>_versus_shaw<sup>i</sup><br>+ ACheis|Cognição: MMSE;<br>Sintomas<br>neuropsiquiátricos: NPI|Psicólogo treinado<br>NR|10 semanas - 2x por<br>semana (sessões de<br>45 min)|
|Spector et|Inglaterra,|ECR, simples|Pacientes com|201|85,3|CST_versus_|Cognição: MMSE,|Psicólogo treinado|7 semanas - 2 x por|
|al, 2003<sup>**9**</sup>|Centros dia e<br>residênciais.|cego,<br>multicêntrico|demência leve a<br>moderada.<br>MMSE: 10 a 24;|||tratamento<br>padrão<sup>j</sup>|ADAS-Cog e CDR;<br>Qualidade de vida:<br>QoL-AD; Sintomas|5 participantes|semana (Sessões de<br>45 min)|
||||CAPE–BRS: 0 ou<br>1||||neuropsiquiátricos:<br>CAPE-BRS, CSDD e<br>RAID.|||  
**Fonte:** Elaboração própria. **Legenda:** AVD: atividade de vida diária, CST: Terapia de estimulação cognitiva; N: número de participantes. AchEIs: Inibidores de acetilcolinesterase; DA: doença de Alzheimer. NR: não reportado. TO: terapeuta ocupacional; RAM: Roy’s adaptation model; MMSE: Mini-exame do estado mental; ADAS-Cog: Escala de Avaliação da Doença de Alzheimer – subescala cognitiva; CDR: Classificação Clínica de Demência; COGNISTAT: Exame do estado cognitivo neurocomportamental; ENB2: Exame Neuropsicológico Breve 2; Qol-AD: Escala de Qualidade de vida para doença Alzheimer; EQ-5D: Escala de Qualidade de vida - Euro-Qol; DAD: Avaliação de Incapacidade para Demência; ADSC-ADL: Escala de Atividade de vida diária da doença de Alzheimer; NPI: Inventario Neuropsiquiátrico; _Behave_ -AD: Escala de avaliação da patologia comportamental na doença de Alzheimer; CAPE-BRS: _Clifton Assessment Procedures for the Elderly_ - Escala de Avaliação Comportamental; CSDD: Escala Cornell para Depressão na Demência; GDS-15:Escala de Depressão Geriátrica - 15 itens; RAID: Classificação Ansiedade na Demência. **Notas:** *pontuação nos testes/ escalas como critério de seleção para o estudo; 1 ambos os grupos estavam em tratamento atual com AchEIs; 2 sem tratamento atual de AchEIs; 3 inclui participantes com e sem uso de AchEIs; 4  todos os pacientes estavam em tratamento com donepezila por pelo menos 3 meses; a. Controle ativo: atividades educacionais alternativas como leitura de artigos, jornais ou livros, discussão em grupo e atividades criativas, como colorir, pintar, decorar ou cozinhar; b. visitas regulares a cada 2/3 meses a um psiquiatra geriátrico e prescrição de AChEI, e participação em atividades oferecidas no centro de recrutamento (CDA‐UFRJ), como terapia ocupacional, atividades físicas e psicoterapia; c. o artigo não reporta a formação dos pesquisadores; d. tratamento de rotina (monitoramento policlínico mensal); e. o artigo não especificou o tratamento padrão; f. Terapia ocupacional (TO): série de atividades programadas: ler e debater jornal, jogar bingo, cantar, terapia com animais, estimulação psicomotora e oficinas criativas; g. programa de atividades habituais na casa de repouso; h. programas de atividades de rotina executados por terapeutas ocupacionais, fisioterapeutas (grupos de exercícios/equilíbrio/membros inferiores), fonoaudiólogos (SONAS – programas de estimulação multissensorial), ou líderes de atividades treinados (por exemplo, bingo, música, arte); i. intervenção simulada: exercício de comunicação (controlando tempo e atenção), foco na interação através da conversa e no apoio psicológico, em vez da prática ou exercícios; j. jogos como bingo, música e canto, artes e ofícios e grupos de atividades.  
46

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A função cognitiva foi mensurada por diferentes escalas e os resultados foram apresentados por desfecho e por subgrupo (escala). Na maioria dos estudos foi utilizada mais de uma medida para avaliar a função cognitiva. Em nove estudos se utilizou a escala **MMSE** (Mini-exame do estado mental), um teste genérico de função cognitiva breve, mas amplamente utilizado, com pontuações mais altas indicando melhor cognição<sup>2</sup> . Em seis dos estudos se utilizou a escala **ADAS-Cog** (Escala de Avaliação da Doença de Alzheimer - subescala cognitiva), um teste cognitivo padrão usado em ensaios clínicos para demência, na qual são consideradas 11 tarefas. Para essa escala as pontuações mais altas indicam um funcionamento cognitivo mais prejudicado<sup>38</sup> .  
Em dois estudos se utilizou a **CDR** (Classificação Clínica de Demência), uma escala de 5 pontos (0 = sem demência; 0,5 = demência possível; 1 = demência leve; 2 = demência moderada; 3 = demência grave), segundo a qual quanto menor a pontuação melhor a cognição<sup>3</sup> . Em um estudo se utilizou o **COGNISTAT** (Exame do estado cognitivo neurocomportamental), composto por 10 subescalas, com pontuações mais altas indicando melhor funcionamento<sup>39</sup> , e em outro estudo o **ENB2** (Exame Neuropsicológico Breve 2), uma bateria neuropsicológica que inclui 14 subtestes, na qual uma pontuação total é calculada para obter uma medida geral do estado cognitivo, quanto maior, melhor o funcionamento cognitivo<sup>40</sup> .  
No geral, a CST foi associada à redução do declínio cognitivo em relação ao tratamento padrão isolado. O resultado da meta-análise dos estudos descritos está apresentado no _forest plot_ pela diferença de média agrupada usando modelo de efeitos aleatórios ( **Erro! Fonte de referência não encontrada.** ).  
Na meta-análise de nove estudos, incluindo 650 participantes nos quais se utilizou a escala **MMSE** , não houve heterogeneidade entre os estudos (I<sup>2</sup> = 8%; τ<sup>2</sup> =0,1318, p=0,37). Para essa escala, a CST foi associada à redução clinicamente significativa no declínio cognitivo (DM:  1,50, IC 95%:  0,88 a 2,12), sendo observadas diferenças significativas entre os grupos CST _versus_ controle ( **Erro! Fonte de referência não encontrada.** ).  
Na meta-análise de seis estudos, incluindo 491 participantes, para o desfecho pontuação na escala **ADAS-Cog** , observouse inconsistência moderada entre os estudos (I<sup>2</sup> = 34%; τ<sup>2</sup> = 4,6956, p=0,18). O efeito da CST na redução do declínio cognitivo não foi diferente do grupo controle (DM: 0,04, IC 95%: -2,77 a 2,86 ( **Erro! Fonte de referência não encontrada.** ).  
Em dois estudos, incluindo 40 participantes, se utilizou a escala **CDR** . Como resultado da meta-análise não se observaram diferenças significativas entre os efeitos da CST e do grupo controle em relação ao declínio cognitivo (DM:  0,85 pontos, IC 95%: -2,93 a 1,23I<sup>2</sup> : 80%). Em um estudo com 56 participantes, se utilizou o **COGNISTAT** , e a diferença média foi de 6,90 (IC 95%: -3,65 a 17,45). Em outro estudo com 20 participantes, se utilizou o **ENB2** a diferença média foi de 10,90 (IC 95%: 1,66 a 20,14). Considerando a pontuação nas escalas CDR e COGNISTAT não houve diferença entre os grupos, apenas na escala ENB2 os resultados foram favoráveis a CST _versus_ controle, porém com IC largo e não foi possível comparar com outros estudos ( **Erro! Fonte de referência não encontrada.** ).  
47  
**Figura B** : Forest plot da comparação entre CST versus grupo controle para o desfecho de cognição, subgrupos por escala  
<!-- Start of picture text -->
Total Mean ‘SD Total Mean sD Mean Difference MD 95%-Cl<br>‘Study Experimental Control<br>escala = MMSE<br>Carbone, 2021 108 0.89 5.9900 101 -1.23 5.7000 i 2.12 [ 0.54; 3.70]<br>Lok, 2019 30 240 6.3800 30 -2.00 6.3300 _ 440 [ 1.18; 7.62]<br>Capotosto, 2017 20 0.18 4.5700 19 -0.39 5.3400 0.57 [-2.56; 3.70]<br>Cove, 2014 21 -0.33 6.0500 21 -0.78 4.5400 0.45 [-2.79; 3.69]<br>Mapelli, 2013 10 2.90 5.0200 10 -0.30 3.8200 3.20 [-0.71; 7.11]<br>Yamanaka, 2013 26 1.63 5.9800 30 -0.40 5.9500 2.03 [-1.10; 5.16]<br>Coen, 2011 14 0.80 3.6000 11 -2.10 2.5000 a 2.90 [ 0.50; 5.30)<br>Niu, 2010 16 0.81 1.1100 16 -0.19 0.6600 1.00 [ 0.37; 1.63)<br>Spector, 2003 97 0.90 3.5000 70 -0.40 3.5000 1.30 [ 0.22; 2.38)<br>Random effects model 342 308 + 1.50 [ 0.88; 2.12]<br>escala = ADAS-Cog<br>Carbone, 2021 91 -2.32 14.9000 80 1.88 17.1600 ~4.20 [-9.05; 0.65]<br>Marinho, 2021 23 2.00 23.8900 24 1.79 23.1900 0.21 [-13.26; 13.68]<br>Capotosto, 2017 20 -0.90 16.0200 19 2.68 17.7300 -3.58 [-14.20; 7.04]<br>Cove, 2014 21 0.91 11.5700 21 241 9.7000 -1.50 [-7.96; 4.96]<br>Coen, 2011 13 0.20 7.2000 12 -2.30 4.1000 2.10 [-2.45; 6.65]<br>Spector, 2003 97 1.90 62000 70 -0.30 5.5000 el 2.20 [ 0.42; 3.98]<br>Random effects model 265 226 0.04 [-2.77; 2.86]<br>escala = CDR<br>Coen, 2011 10 0.50 2.0000 10 0.10 2.1000 al 0.40 [-1.40; 2.20]<br>Mapelli, 2013 10 -0.25 05400 10 1.50 0.7300 1.75 [-2.31; -1.19]<br>Random effects model 20 20 0.85 [-2.93; 1.23]<br>escala = COGNISTAT<br>Yamanaka, 2013 26 6.48 20.1100 30 -0.42 20.0500 6.90 [-3.65; 17.45]<br>escala = ENB2<br>Mapelli, 2013 10 8.70 10.8700 10 -2.20 10.2100 ——#—— 10.90 [ 1.66; 20.14]<br>Heterogeneity: /? = 81%, x = 2.0166, p < 0.01<br>Test for subgroup differences: 73 = 10.51, df = 4 (p = 0.03) 20-10 0 10 20<br><!-- End of picture text -->  
**Fonte:** elaboração própria. **Legenda:** CI: intervalo de confiança; MMSE: Mini-exame do Estado Mental; ADAS-Cog: Escala de Avaliação da Doença de Alzheimer - subescala cognitiva; CDR: Classificação Clínica de Demência; COGNISTAT: Exame do estado cognitivo neurocomportamental. ENB2: Exame Neuropsicológico Breve 2.  
**Nota:** Não é representado um losango para a meta-análise inteira, uma vez que os mesmos pacientes são avaliados em múltiplas escalas. As médias e desvio padrão do estudo Marinho (2021) foram extraídos dos gráficos usando software WebPlotDigitizer, com a conversão do erro padrão para desvio padrão.  
Para as medidas de desfecho **MMSE** e **ADAS-Cog** , análises de metarregressão não revelaram associações significativas em relação à idade média (MMSE: p 0,5969; ADAS-Cog: p 0,1347). Desta forma, a idade não explica a heterogeneidade identificada.  
Análises de subgrupo por frequência e duração implicou na exclusão de um estudo, pois só esse estudo apresentou características discrepantes em relação aos demais<sup>32</sup> . No entanto, mesmo com a exclusão não houve diferença significativa que explique a heterogeneidade encontrada.  
O estudo no qual se investigou a eficácia da CST manutenção<sup>10</sup> , se avaliou a cognição a partir das escalas **MMSE** e **ADAS-Cog** , após 3 e 6 meses de acompanhamento. A partir dos resultados da **MMSE** foi observada uma pequena redução média de 17,17 (IC 95%: 15,09-19,25) para 17,25 (IC 95%: 14,63-19,87, p= 0,03) no grupo que recebeu a CST manutenção combinado a inibidores de acetilcolinesterase (AChEis). Embora a pontuação do **MMSE** tenha variado 0,85 pontos (MD) para o grupo CST manutenção após seis meses quando comparado ao grupo controle, isso não sugere que a CST manutenção tenha efeitos substanciais na cognição, para além dos benefícios da CST padrão, mas que não há piora do declínio cognitivo, sugerindo uma preservação do quadro. Não foram observadas diferenças significativas entre os grupos a partir da avaliação da escala **ADASCog** .  
48

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Foram utilizadas três escalas para avaliar a qualidade de vida nos diferentes estudos. Na maioria dos estudos se utilizou a **Qol-AD** (Escala de Qualidade de vida para doença Alzheimer), a qual abrange 13 domínios de qualidade de vida, e as pontuações mais altas refletem melhor qualidade de vida<sup>41</sup> . Em apenas um estudo<sup>40</sup> se utilizou a **EQ-5D** (Escala de Qualidade de vida - Euro-Qol), uma escala de qualidade de vida relacionada à saúde utilizada internacionalmente, na qual a pontuação de utilidade varia de 0,01 a 1,000, e quanto maior a pontuação melhor a qualidade de vida<sup>42</sup> .  
A qualidade de vida também foi mensurada por diferentes escalas e o resultado apresentado no _forest plot_ pela diferença média agrupada usando modelo de efeitos aleatórios (Erro! Fonte de referência não encontrada.). Em geral, não houve melhora na qualidade de vida para o grupo CST em comparação com o grupo controle.  
Em sete estudos, incluindo 606 participantes, se utilizou a escala **Qol-AD** (Escala de Qualidade de vida para doença Alzheimer) e a diferença de média geral foi de 3,04 pontos (IC 95%: -0,43 a 6,50). Não foram observadas diferenças clinicamente significantes entre os grupos CST _versus_ controle. No entanto, houve alta heterogeneidade entre os estudos (I<sup>2</sup> = 76%) (Erro! Fonte de referência não encontrada.).  
Em um estudo incluindo 56 participantes, se utilizou o **EQ-5D** (Escala de Qualidade de vida - Euro- Qol) e o resultado não foi favorável para CST na melhora da qualidade de vida (DM= 0,01, IC 95%: -0,17 a 0,19) quando comparada ao grupo controle (Erro! Fonte de referência não encontrada.).  
**Figura C:** Forest plot da comparação entre CST versus grupo controle: desfecho qualidade de vida.  
<!-- Start of picture text -->
Total Mean SD Total Mean SD Mean Difference MD 95%-Cl<br>Study Experimental Control<br>cala = QoL-AD<br>Carbone, 2021 118 1.52 12.6000 97 -0.31 11.5200 1.83 [-1.40; 5.06]<br>Lok, 2019 30 12.00 11.5200 30 -2.00 7.4600 —+— 14.00 [ 9.09; 18.91]<br>Capotosto, 2017 20 1.25 11.5000 19 0.05 9.9100 1.20 [-5.53; 7.93]<br>Cove, 2014 21 0.77 7.9700 21 0.54 7.7300 -1.31 [-6.06; 3.44)<br>Yamanaka, 2013 26 0.19 85700 30 -0.43 9.1700 0.62 [-4.03; 5.27]<br>Coen, 2011 14 3.60 3.7000 13 0.50 4.4000 3.10 [0.02; 6.18]<br>Spector, 2003 97 1.30 5.1000 70 -0.80 5.6000 na 2.10 [0.44; 3.76]<br>Random effects mode ¢ 4 [-0.4<br>scala = EQ-5D<br>Yamanaka, 2013 26 0.00 0.3500 30 -0.01 0.3400 0.01 [-0.17; 0.19]<br>Heterogeneity: /? = 84%, x” = 14.8198, p < 0.01<br>Test for subgroup differences: x; = 2.92, df= 1 (p = 0.09) 15-10 5 0 5 10 15<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
**Legenda:** CI: intervalo de confiança; Qol-AD: Escala de Qualidade de vida para doença Alzheimer; EQ-5D: Escala de Qualidade de vida - Euro- Qol. Nota: Não é representado um losango para a meta-análise inteira, uma vez que os mesmos pacientes são avaliados em múltiplas escalas.  
A metarregressão foi realizada para idade média, porém os resultados encontrados não explicam a heterogeneidade, ou seja, esse parâmetro não está relacionado às diferenças de resultados entre os estudos (p: 0,6360).  
No estudo em que se investigou a eficácia da CST manutenção<sup>10</sup> , se avaliou a qualidade de vida a partir da escala **QolAD** após 3 e 6 meses de acompanhamento. Na avaliação após seis meses, o grupo CST manutenção obteve pontuações mais altas na **Qol-AD** com uma diferença média de 1,78 (IC 95%: -0,01-3,57, p=0,03), quando comparada ao grupo tratamento padrão, indicando não ter diferença entre os grupos na qualidade de vida.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
49  
Duas escalas foram utilizadas para avaliar atividade de vida diária, a **DAD** (Avaliação de Incapacidade para Demência), a qual abrange atividades básicas, instrumentais e de lazer em 10 áreas, com pontuações mais altas refletindo melhor capacidade 43 e **ADSC-ADL** (Escala de Atividade de vida diária da doença de Alzheimer), que avalia a capacidade funcional ao longo da faixa de gravidade da demência com pontuações mais altas resultando em melhores competências<sup>44</sup> .  
O desfecho atividade de vida diária foi avaliado em três estudos utilizando duas escalas diferentes. A partir da análise de diferença de média padronizada (SMD) não houve melhora significativa na atividade de vida diária em ambos os subgrupos (escalas), e não houve heterogeneidade entre os grupos CST _versus_ controle (SMD=0,11, IC95%= -0,15 a 0,38, I<sup>2</sup> =0%) ( ).  
Em dois estudos incluindo 179 participantes, se avaliou a atividade de vida diária a partir da escala **DAD** . A CST não apresenta melhora na capacidade funcional dos participantes (SMD= 0,09, IC 95%: -0,21 a 0,39) quando comparada ao grupo controle. Embora não se tenha observado heterogeneidade entre os estudos (I<sup>2</sup> = 0%), o resultado não seria confiável, considerando o reduzido número de estudos, participantes e amplo intervalo de confiança observado no estudo do grupo de Capotosto (2017). Em outro estudo no qual foram incluídos 68 participantes, se utilizou a **ADCS-ADL** e a diferença média padronizada foi de 0,20 (IC 95%: -0,37 a 0,78).  
**Figura D.** Forest plot da comparação entre CST versus grupo controle: desfecho atividade de vida diária.  
<!-- Start of picture text -->
Study Experimental Control Standardised Mean<br>Total Mean SD Total Mean = SD Difference SMD —-95%-Cl Weight<br>|<br>Carbone, 2021 84 -0.76 34.4900 56 -4.61 34.2000 Ss 0.11 [-0.23; 0.45] 61.0%<br>Capotosto, 2017 20 -0.35 27.5900 19 -0.63 31.0000 = 0.01 [-0.62; 0.64] 17.7%<br>Marinho, 2021 23 2.50 21.3600 24 -1.75 19.7100 0.20 [-0.37; 0.78] 21.2%<br>Random effects model 127 99 0.11 [-0.15; 0.38] 100.0%<br>Prediction interval [-1.60; 1.83]<br>Heterogeneity: ? = 0%, x = 0, p = 0.90<br>Test for subgroup differences: 5 = 0.12, df= 1 (p = 0.73) 15 -1-050 05 1 15<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
**Legenda:** CI: intervalo de confiança; DAD: Avaliação de Incapacidade para Demência; ADL: Escala de Atividade de vida diária da doença de Alzheimer. **Nota:** As médias e desvio padrão do estudo Marinho (2021) foram extraídos dos gráficos usando software WebPlotDigitizer, e com a conversão do erro padrão para desvio padrão.  
A metarregressão foi realizada para idade (média), porém os resultados encontrados não explicam a heterogeneidade, ou seja, o parâmetro não está relacionado às diferenças de resultados entre os estudos (p: 0,8151).

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Os sintomas neuropsiquiátricos mais avaliados foram as alterações de comportamento, sintomas depressivos e de ansiedade, os quais foram mensurados por diferentes escalas.  
Em dois estudos se avaliou o comportamento por meio da escala **NPI** (Inventario Neuropsiquiátrico), que abrange 10 comportamentos que ocorrem comumente na demência. Para essa escala pontuações mais baixas refletem melhor comportamento, e quanto mais altas indicam problemas comportamentais mais frequentes e mais graves<sup>45</sup> . Outra escala utilizada para avaliar o comportamento foi a **Behave-AD** (Escala de avaliação da patologia comportamental na doença de Alzheimer), a qual inclui 25 sintomas comportamentais, agrupados em 7 categorias, cada sintoma é pontuado, quanto à sua gravidade, em escalas de 4 pontos, quanto mais alto mais grave o comportamento<sup>46</sup> . A escala **CAPE-BRS** ( _Clifton Assessment Procedures for_  
50  
_the Elderly_ - Escala de Avaliação Comportamental) abrange o comportamento geral, cuidado pessoal e comportamento em relação aos outros, pontuações mais altas indicam maior comprometimento funcional e dependência<sup>47</sup> .  
A escala mais utilizada para avaliar depressão foi a **CSDD** (Escala Cornell para Depressão na Demência) e inclui 19 itens que avaliam sinais e sintomas de depressão maior em pessoas com demência. Para essa escala pontuações totais abaixo de 6 indicam ausência de sintomas depressivos significativos, acima de 10, provável depressão maior, e acima de 18, definitivamente depressão maior<sup>48</sup> . A **GDS-15** (Escala de Depressão Geriátrica - 15 itens) é um questionário de autorrelato que fornece uma pontuação global, quanto maior a pontuação mais provável a presença de sintomas depressivos<sup>49</sup> .  
A escala **RAID** (Classificação Ansiedade na Demência) foi a única escala utilizada para avaliar ansiedade; essa classifica a ansiedade em quatro categorias principais (preocupação, apreensão e vigilância, tensão motora e hipersensibilidade), pontuações mais baixas refletem melhora na ansiedade<sup>50</sup> .  
Como resultados, observaram-se reduções nos sintomas avaliados, relacionadas a melhora significativa em alterações do comportamento e sintomas depressivos, mas não em sintomas de ansiedade  
Em cinco estudos se avaliou o desfecho comportamento a partir de diferentes escalas, os resultados são apresentados a partir da diferença de média. Em dois estudos, incluindo 256 participantes, se utilizou o **NPI** indicando que houve melhora no comportamento (DM: -2,59, IC 95%: -4,87 a -0,31), e moderada heterogeneidade entre os estudos (I<sup>2</sup> = 30%;). Enquanto, em dois estudos, incluindo 194 participantes, se utilizou a **CAPE-BRS** e não identificou melhora no comportamento quando comparado ao grupo controle (DM= 0,11, IC 95%: -7,47 a 0,32; I<sup>2</sup> = 0%). Já em um estudo, incluindo apenas 20 participantes, se utilizou a **Behave-AD** e a diferença de média foi de -9,70 (IC 95%: -15,94 a -3,46), indicando redução dos sintomas de alteração de comportamento, porém apresenta um IC 95% largo e não foi possível comparar com outros estudos (  
).  
Em cinco estudos se avaliou o desfecho depressão utilizando duas escalas diferentes Quatro deles, incluindo 477 participantes, utilizou a **CSDD** para avaliar depressão, indicando redução clinicamente significativa nos sintomas depressivos (DM: -1,47; IC 95%: -2,83 a -0,12), e heterogeneidade moderada entre os estudos (I<sup>2</sup> = 56%). Em um estudo, incluindo apenas 26 participantes, utilizou a **GDS-15** , a diferença média foi de 1 ponto (IC 95%: -0,93 a 2,93), não indicando melhora no comportamento quando comparado ao grupo controle. Entretanto, não foi possível comparar com outros estudos (  
).  
Em dois estudos, incluindo 194 participantes, se avaliou a ansiedade a partir da escala **RAID** e não foi identificada redução da ansiedade quando comparado ao grupo controle (DM: -0,32, IC 95%: -2,50 a 1,86; I<sup>2</sup> = 0%) (  
).  
51  
**Figura E.** Forest plot da comparação entre CST versus grupo controle: desfecho sintomas neuropsiquiátricos – alterações de comportamento, sintomas de depressão e de ansiedade.  
<!-- Start of picture text -->
Total Mean ‘SD Total Mean sD Mean Difference MD 95%-Cl<br>Study Experimental Control<br>escala = NPI (comportamento<br>Carbone, 2021 123 -2.84 17.2800 101 2.30 20.0500 5.14 [-10.10; -0.18]<br>Niu, 2010 16 -2.06 1.3900 16 0.00 1.0300 2.06 [-2.91;-1.21]<br>Random effects model 139 117 > 2.59 [-4.87; -0.31]<br>escala = Behave-AD (comportamento)<br>Mapelli, 2013 10 -7.20 8.0500 10 2.50 6.0400 ——=—— -9.70 [-15.94; -3.46]<br>escala = CAPE-BRS (comportamento)<br>Coen, 2011 14 0.00 3.6000 13 1.40 5.4000 -1.40 [-4.89; 2.09]<br>Spector, 2003 97 -0.20 6.1000 70 -0.70 5.5000 Ss all 0.50 [-1.27; 2.27]<br>Random effects model 111 83 0.11 47; 1.69]<br>escala = CSDD (depressao)<br>Carbone, 2021 123 -1.91 7.1300 101 0.94 7.3300 -_ -2.85 [-4.76; -0.94]<br>Marinho, 2021 23 -1.21 2.2600 24 0.95 2.2300 all -2.16 [-3.44; -0.88)<br>Capotosto, 2017 20 -140 2.8600 19 -0.42 3.4900 0.98 [-2.99; 1.03]<br>Spector, 2003 97 0.00 6.2000 70 -0.50 7.0000 ~ 0.50 [-1.55; 2.55]<br>Random effects model 263 214 1.47 [-2.83; -0.12]<br>escala = GDS-15 (depressao)<br>Coen, 2011 13 0.90 3.0000 13 -0.10 1.9000 = 1.00 [-0.93; 2.93]<br>escala = RAID (ansiedade<br>Coen, 2011 14 -1.10 7.3000 13 1.60 6.4000 -2.70 [-7.87; 2.47]<br>Spector, 2003 97 -0.50 10.2000 70 -0.70 5.5000 a 0.20 [-2.20; 2.60]<br>Heterogeneity:Random effects/? = 64%,modelx” = 1.6758,111 p < 0.01 83 na 0.32 [-2.50; 1.86]<br>Test for subgroup differences: 72 = 15.95, df = 5 (p < 0.01) 15-10 5 0 5 10 15<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
**Legenda:** CI: intervalo de confiança; NPI: Inventario Neuropsiquiátrico; Behave-AD: Escala de Avaliação da Patologia Comportamental na Doença de Alzheimer; CAPE-BRS: Clifton Assessment Procedures for the Elderly - Escala de Avaliação Comportamental; CSDD: Escala Cornell para Depressão na Demência; GDS-15: Escala de Depressão Geriátrica (GDS-15); RAID: Classificação Ansiedade na Demência.  
**Nota:** Não é representado um losango para a meta-análise inteira, uma vez que os mesmos pacientes são avaliados em múltiplas escalas. As médias e desvio padrão do estudo Marinho (2021) foram extraídos dos gráficos usando software WebPlotDigitizer, e com a conversão do erro padrão para desvio padrão.  
Os resultados encontrados para os sintomas depressivos não explicam a heterogeneidade (p= 0,0937).  
O número limitado de estudos que incluiu os desfechos de comportamento e ansiedade impediu a análise de metarregressão.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Para o desfecho de eficácia, as avaliações quanto ao risco de viés geral resultaram em ‘baixo risco de viés’ (4 avaliações) seguido por ‘algumas preocupações’ (3 avaliações) e ‘alto risco de viés’ (3 avaliações). Os domínios em que todas as avaliações foram classificadas como ‘baixo risco de viés’ foram: i) desvios da intervenção pretendida; e ii) dados incompletos. ‘Algumas preocupações’ foram classificadas em itens que avaliam ‘processo de randomização’ devido a ausências de informações sobre o  
52  
processo de randomização **(Figura F)** . Os itens de ‘mensuração de desfecho’ foram os que apresentaram alto risco de viés, por motivos como por exemplo, ausência de informações sobre o conhecimento dos avaliadores acerca do grupo em que estavam inseridos os participantes no momento da avaliação.  
**Figura F.** Risco de viés dos ensaios clínicos randomizados para o desfecho cognição.  
<!-- Start of picture text -->
|W Estudo Intervencio. Comparador Desfecho Dla Dib D2 D3 D4 D5 Total<br>carbone, 2028 ST controle ato corto @ O® @@@@@ @ tiwrico<br>Marino, 2003 cst tratamentopadrio ars @@ @ @ @ @ @_  @ Aeuaspreccupasses<br>ok 2039 GST tratamentopadrio corso @ D @ @ @ @ @ @ Biorixo<br>capotosto,2017 = GST_—_controleatho on MO)<br>cove, 2014 cst tratamentopadréo certo @ @ @ @ @ @ @_o% Preeesoderaniomizasso<br>Namanaka,ape, 2013 GST tratamentopadtdo coors OD @ @ @S SO @ O_o rerpose senicasso/recruramentds particpants|<br>coen, 2011 2013 cstGST trat ae mentop astdoadrio c oaritooors @ @ @D @ @ O@ @@D @ _®_&» veesicsdodosic am ervsl e snsso pretensa<br>i,sector, 2030 2003 GSTcst __tratamentopadcioplacebo cantocart @@ @@ @@ @@ @OO@ @_& 5 _SelerSodosr nitadosreportdosMersaasse d e stecro<br><!-- End of picture text -->  
**Fonte:** Elaboração própria.  
**Legenda:** D: Domínio. CST: Terapia de estimulação cognitiva.  
A avaliação do risco de viés geral do estudo de Orrel _et al._ (2014) complementar que avaliou a eficácia da CST  
manutenção, resultou em ‘baixo risco de viés’, tendo todos os domínios avaliados como ‘baixo risco de viés’.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A certeza da evidência foi considerada alta para o desfecho cognição, quando avaliado pela **MMSE** e moderada quando avaliado pela **ADAS-Cog** . Mais detalhes da avaliação da certeza da evidência para a comparação da CST versus tratamento padrão pode ser encontrados no  
**Quadro**  
**Quadro** E. Avaliação da qualidade da evidência para a comparação da CST versus tratamento padrão em pacientes  
diagnosticados com doença de Alzheimer leve a moderada para o desfecho cognição.e do risco de viés (  
Figura F. Risco de viés dos ensaios clínicos randomizados para o desfecho cognição.  
**Figura** ).  
> **Quadro E** . Avaliação da qualidade da evidência para a comparação da CST versus tratamento padrão em pacientes diagnosticados com doença de Alzheimer leve a moderada para o desfecho cognição.  
53  
|Avaliaç|ão da certeza||||||№ de|pacientes|Efeito||
|---|---|---|---|---|---|---|---|---|---|---|
|№ dos<br>estudos|Delineame<br>nto do<br>estudo|Risco<br>de<br>viés|Inconsi<br>stência|Evidência<br>indireta|Imprecisão|Outras<br>consider<br>ações|CST|Controle|DM (IC<br>95%)|Certeza|
|Cogniçã<br>6|o – ADAS-C<br>ECR|og<br>Não<br>grave|Não<br>grave|Não<br>grave|Grave<sup>a</sup>|nenhu<br>ma|265|226|0,04 (-<br>2,77 a<br>2,86)|⨁⨁⨁◯<br>Moderada|
|Cogniçã|o – MMSE||||||||||
|9|ECR|Não<br>grave|Não<br>grave|Não<br>grave|Não grave|nenhu<br>ma|342|308|1,50<br>(0,88 a<br>2,12)|⨁⨁⨁⨁<br>Alta|  
**Legenda:** DM: diferença de média; IC: Intervalo de confiança; ECR: ensaios clínicos randomizados.  
**Explicações:** a. Não há diferença com significância estatística.  
Referente à avaliação da qualidade da evidência para a comparação da CST manutenção (n=123) versus tratamento padrão (n=113) em pacientes diagnosticados com DA leve a moderada para o desfecho cognição, considerando apenas um estudo (ECR), o efeito para o MMSE (DM: 0,85; IC 95% -0,29 a 1,99, p 0,03) e para o ADAS-Cog (DM: -0,65 (-3,71 a 2,42, p 0,67), e a avaliação do risco de viés ‘baixo risco’ a evidência foi considerada moderada, devido à imprecisão.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Considerando os achados da revisão sistemática, sobre os benefícios identificados e ausência de relato de efeitos indesejáveis, o balanço sugere benefício clínico referente à redução do declínio cognitivo do uso da CST em grupo para paciente com DA leve a moderado quando comparado ao tratamento padrão, bem como da CST manutenção na preservação do quadro  
por mais seis meses.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Realizou-se uma avaliação econômica (AE) para estimar a relação de custo-utilidade incremental da CST em grupo combinada ao tratamento padrão, em comparação ao tratamento padrão isolado, como opção terapêutica para o tratamento de pacientes com DA leve a moderada.  
Para a análise foi elaborado um modelo econômico do tipo análise de custo-utilidade (ACU) no software Microsoft Office Excel® (Microsoft Corporation, Redmond, WA, EUA), seguindo as recomendações das Diretrizes Metodológicas de AE do Ministério da Saúde (MS)<sup>51</sup> . Além disso, com a finalidade de aumentar a clareza e transparência do estudo, este relato segue o _reporting checklist CHEERS Task Force Report_ – 2022<sup>52</sup> e os principais aspectos da análise estão sumarizados no **Quadro** .  
**Quadro F.** Características do modelo de análise de custo-efetividade.  
|População-alvo|Pacientes com doença de Alzheimer leve a moderada|
|---|---|
|Perspectiva de<br>análise|Sistema Único de Saúde (SUS)|
|Intervenção|Terapia de estimulação cognitiva (CST) combinada ao tratamento padrão|  
54  
|Comparador|Tratamento padrão isolado|
|---|---|
|Horizonte temporal|aproximadamente 1 ano (7 ciclos de 7 semanas)|
|Medidas de<br>efetividade|Anos de vida ajustados pela qualidade (QALY)|
|Estimativa de custos|Custos médicos diretos|
|Moeda|Real (R$)|
|Taxa de desconto|Não se aplica|
|Modelo escolhido|Modelo de Markov|
|Análise de|Análises determinística (Deterministic Sensitivity Analysis - DAS) e probabilística multivariada|
|sensibilidade|(Probabilistic Sensitivity Analysis - PSA).|  
**Fonte:** elaboração própria

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A população considerada como base para cálculo dos custos e desfechos desta avaliação econômica foi constituída por pacientes, de ambos os sexos, com diagnóstico de DA leve a moderada. Para esta análise, entendeu-se como DA leve a moderada a partir do diagnóstico clínico de demência considerando a pontuação entre 0,5 e 2,0 dos critérios da Classificação Clínica de Demência ( _Clinical Dementia Rating_ – CDR)<sup>3</sup> .  
A média de idade é de 83 anos, referente à média de idade encontrada pela revisão sistemática<sup>52</sup> realizada.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A perspectiva adotada foi a do SUS.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A intervenção de interesse é a CST em grupo combinada ao tratamento padrão (detalhado no tópico comparador). A CST é recomendada pelo relatório Mundial de Alzheimer<sup>5</sup> , para pessoas com demência em estágio inicial, e pelas diretrizes do _National Institute for Health and Care Excellence_ (NICE) do Reino Unido de 2018<sup>4</sup> , “para promover cognição, independência e bem-estar” para pessoas com demência leve à moderada.  
Para esta análise, incluíram-se informações fornecidas pela equipe CST-Brasil (RJ) e as evidências da meta-análise realizada para o desfecho cognição utilizando a ferramenta MMSE<sup>53</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O comparador desta análise é o tratamento padrão de cuidado de pacientes com DA leve e moderado. Neste modelo foi adotado o uso dos AChEIs disponíveis no SUS e recomendados pelo PCDT da DA publicado em 2017<sup>54</sup> : comprimidos de donepezila de 5 mg e 10 mg, cápsulas de liberação prolongada de galantamina de 8 mg, 16 mg e 24 mg, cápsulas de rivastigmina de 1,5 mg, 3 mg, 4,5 mg e 6 mg, frasco de 120 ml de solução oral de rivastigmina de 2,0 mg/ml e adesivos transdérmico de rivastigmina de 9 mg e 18 mg. O PCDT também recomenda o uso de comprimidos de memantina de 10 mg em combinação com um dos AChEIs somente para pacientes de grau moderado.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O horizonte temporal de avaliação é de 7 ciclos de 7 semanas, correspondendo a aproximadamente 1 ano, portanto uma taxa de desconto não foi aplicada para custos e desfechos, conforme recomendado pelas Diretrizes Metodológicas de AE do MS 51. A escolha deste período de avalição deve-se ao fato de que as evidências para a CST estão restritas a 1 ano, não são recomendados tratamentos de longo prazo e não são esperados efeitos de longo prazo após a interrupção da CST. Contudo, a CST manutenção oferecida após as 14 sessões da CST padrão, poderia promover a preservação do quadro do paciente com DA leve a moderada impactando na velocidade do declínio cognitivo.  
55

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O desfecho utilizado para essa análise foi a efetividade em termos de anos de vida ajustados pela qualidade (QALY). Considerando a falta de dados brasileiros de utilidade para DA, foram utilizados os valores do estudo de Neumann _et al_ , 1999 55.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Apenas custos médicos diretos foram incluídos no modelo. A composição do custo considerou custos hospitalares e ambulatoriais, relacionados a procedimentos, exames e monitoramento dos pacientes com DA, seguindo as recomendações do PCDT da DA publicado em 2017<sup>54</sup> . Fator de correção de custos da tabela do SUS foi considerado na análise de sensibilidade determinística.  
Para o tratamento padrão, a composição do custo considerou os valores de custo dos medicamentos disponíveis no SUS e recomendados pelo PCDT da DA publicado em 2017<sup>54</sup> . Para cada medicamento, os custos utilizados foram extraídos, em novembro de 2023, dos registros do Banco de Preços em Saúde (BPS) e do Sistema Integrado de Administração de Serviços Gerais (SIASG)<sup>56</sup> , considerando o menor preço praticado no ano de 2023 como valor pontual. Nas análises de sensibilidade levou-se em conta 20% a menos do valor pontual como limite inferior e o maior preço praticado no ano de 2023 como limite superior, exceto para a galantamina de 8 mg que foi 20% a mais do valor pontual.  
Para a composição do custo anual de cada medicamento foi calculado a quantidade anual de medicamento necessária baseando-se na posologia recomendada pelo PCDT publicado em 2017<sup>54</sup> , sendo os valores com desperdício de medicamento para análise basal e sem desperdício como análise exploratória.  
Para a composição do tratamento padrão, também foi necessário determinar as porcentagens de uso de cada AChEI. As proporções de usuários para cada medicamento foram calculadas a partir dos dados, do ano de 2022, extraídos em 29/09/2023 da Sala Aberta de Inteligência em Saúde (Sabeis)<sup>57</sup> . Nas análises de sensibilidade foram considerados os intervalos de 95% de confiança de cada proporção, estes foram obtidos pelo método de _Clopper-Pearson_ , exceto para donepezila de 10mg por comprimido, pois como apresentou o maior erro-padrão, foi o escolhido para ser a proporção complementar.  
O PCDT da DA publicado em 2017<sup>54</sup> também recomenda a terapia combinada entre AChEIs e memantina somente para pacientes de grau moderado e memantina isolada para pacientes de grau grave. Desta forma, a estimação da proporção de pacientes de grau moderado usuários de AChEIs combinado com memantina foi com base na distribuição de pacientes com DA por grau obtida pelo estudo brasileiro publicado por Ferretti C _et al_ , 2018<sup>58</sup> e os números totais de usuários de AChEIs (115.628) e memantina (26.731) no ano de 2022 extraídos da Sabeis<sup>57</sup> , resultando em **32,4%** dos pacientes com grau moderado.  
Os custos dos serviços de saúde e outros recursos (excluindo medicamentos) para atendimento ao paciente com DA por grau foram extraídos do estudo brasileiro publicado por Ferretti C _et al_ , 2018<sup>58</sup> .  
Os custos para o tratamento padrão e os detalhes para a obtenção destes estão dispostos de forma detalhada na **Tabela A.** Para a composição do custo da CST em grupo para pacientes com DA, foram considerados, além do custo das sessões, também o custo do treinamento e dos materiais necessários, informados pela equipe de treinamento CST-Brasil (RJ)<sup>a</sup> O valor de custo utilizado para estas sessões é do procedimento “03.01.04.003-6 - TERAPIA EM GRUPO” do Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e Órteses/Próteses e Materiais Especiais do SUS (SIGTAP)<sup>59</sup> .  
Para o tratamento padrão, a composição do custo considerou os valores de custo dos medicamentos disponíveis no SUS e recomendados pelo PCDT de DA<sup>54</sup> . Para cada medicamento, os custos utilizados foram extraídos, em novembro de 2023, dos registros do Banco de Preços em Saúde (BPS) e do Sistema Integrado de Administração de Serviços Gerais (SIASG)<sup>56</sup> , considerando o menor preço praticado no ano de 2023 como valor pontual. Para as análises de sensibilidade, utilizou-se a distribuição Gama e levou-se em conta 20% a menos do valor pontual como limite inferior e o maior preço praticado no ano de  
a Daniel Mograbi, Coordenador do projeto CST-Brasil - Universidade Federal do Rio de Janeiro (UFRJ).  
56  
2023 como limite superior, exceto para a galantamina de 8 mg que foi 20% a mais do valor pontual, como apresentado na tabela a seguir.  
**Tabela A.** Valores de custo individual dos medicamentos utilizados no modelo econômico.  
|**Medicamento**|**Valor**<br>**Pontual ¹ (R$)**|**(R$)**|**Mínimo ²**|**(R$)**|**Máximo ¹**|
|---|---|---|---|---|---|
|**Donepezila 5 mg por comprimido**|0,11||0,09||2,00|
|**Donepezila 10 mg por comprimido**|0,18||0,14||2,50|
|**Galantamina 8 mg por cápsula de liberação prolongada**|3,00||2,40||3,60 ³|
|**Galantamina 16 mg por cápsula de liberação prolongada**|2,45||1,96||5,76|
|**Galantamina 24 mg por cápsula de liberação prolongada**|2,91||2,33||4,45|
|**Rivastigmina 1,5 mg por cápsula**|0,49||0,39||2,50|
|**Rivastigmina 2,0 mg/ml solução oral por frasco de 120 ml**|269,70||215,76||269,72|
|**Rivastigmina 3 mg por cápsula**|1,52||1,22||5,50|
|**Rivastigmina 4,5 mg por cápsula**|1,51||1,21||2,60|
|**Rivastigmina 6 mg por cápsula**|1,92||1,54||5,31|
|**Rivastigmina 9 mg por adesivo transdérmico**|10,92||8,74||23,75|
|**Rivastigmina 18 mg por adesivo transdérmico**|4,14||3,31||25,00|
|**Memantina 10 mg por comprimido**|0,12||0,10||1,04|  
**Fonte** : ¹ BPS/SIASG, extração 30/11/2023<sup>56</sup> ;² -20% do valor pontual; ³ +20% do valor pontual.  
Para a composição do custo anual de cada medicamento foi calculado a quantidade anual de medicamento necessária  
baseando-se na posologia recomendada pelo PCDT vigente<sup>54</sup> e é apresentado no  
**Quadro** , representando valores com e sem desperdício de medicamento.  
**Quadro G.** Quantidade de medicamento anual por paciente por medicamento, conforme posologia, considerando com e sem desperdício, utilizados no modelo econômico.  
|Medicamento|Com<br>desperdício|Sem<br>desperdício|Posologia ¹|
|---|---|---|---|
|Donepezila 5 mg por comprimido|695,0|695,0|5 mg/dia nas 5 primeiras semanas e 10|
|Donepezila 10 mg por comprimido|365,0|347,5|mg/dia nas semanas seguintes|
|Galantamina 8 mg por cápsula de liberação|702,0|702,0|8 mg/dia nas 4 primeiras semanas e|
|prolongada|||16mg/dia nas semanas seguintes|
|Galantamina 16 mg por cápsula de|365,0|351,0||
|liberação prolongada||||
|Galantamina 24 mg por cápsula de|365,0|234,0||
|liberação prolongada||||
|Rivastigmina 1,5 mg por cápsula|2752,0|2752,0|3 mg/dia nas 2 primeiras semanas, 6|
|Rivastigmina 2,0 mg/ml solução oral por|17,20|17,2|mg/dia nas 2 semanas seguintes, 9|
|frasco de 120 ml|||mg/dia nas 2 semanas seguintes e 12|
|Rivastigmina 3 mg por cápsula|1376,0|1376,0|mg/dia nas semanas seguintes|
|Rivastigmina 4,5 mg por cápsula|1039,0|917,3||  
57  
|Medicamento|Com<br>desperdício|Sem<br>desperdício|Posologia ¹|
|---|---|---|---|
|Rivastigmina 6 mg por cápsula|702,0|688,0||
|Rivastigmina 9 mg adesivo transdérmico|1039,0|897,4||
|(equivalente a 4,6mg/dia da cápsula)||||
|Rivastigmina 18 mg adesivo transdérmico|688,0|434,5||
|(equivalente a 9,5mg/dia da cápsula)||||
|Memantina 10 mg por comprimido|716,0|709,0|5 mg/dia nas 3 primeiras semanas, 10<br>mg/dia na semana seguinte, 15 mg/dia<br>na semana seguinte e 20 mg/dia nas<br>semanas seguintes|  
**Fonte:** ¹ baseado nas recomendações do PCDT de doença de Alzheimer<sup>54</sup> .  
Para a composição do tratamento padrão, também foi necessário determinar as porcentagens de uso de cada AChEI. As proporções de usuários para cada medicamento foram calculadas a partir dos dados, do ano de 2022, extraídos em 29/09/2023 da Sala Aberta de Inteligência em Saúde (Sabeis)<sup>57</sup> , como apresentado na **Tabela B** . Para as análises de sensibilidade, a distribuição Dirichlet foi utilizada e foram considerados os intervalos de 95% de confiança de cada proporção, estes foram obtidos pelo método de _Clopper-Pearson_ , exceto para donepezila de 10mg por comprimido, pois como apresentou o maior erropadrão, foi o escolhido para ser a proporção complementar.  
**Tabela B.** Proporções de uso de cada inibidor de acetilcolinesterase utilizados no modelo econômico.  
|**Medicamento**|**Valor**<br>**Pontual**|**Mínimo¹**|**Máximo¹**|
|---|---|---|---|
|**Donepezila 5 mg por comprimido**|0,162|0,160|0,164|
|**Donepezila 10 mg por comprimido²**|0,375|0,372|0,378|
|**Galantamina 8 mg por cápsula de liberação prolongada**|0,052|0,051|0,054|
|**Galantamina 16 mg por cápsula de liberação prolongada**|0,062|0,060|0,063|
|**Galantamina 24 mg por cápsula de liberação prolongada**|0,088|0,087|0,090|
|**Rivastigmina 1,5 mg por cápsula**|0,021|0,020|0,022|
|**Rivastigmina 2,0 mg/ml solução oral por frasco de 120 ml**|0,009|0,008|0,009|
|**Rivastigmina 3 mg por cápsula**|0,024|0,023|0,025|
|**Rivastigmina 4,5 mg por cápsula**|0,012|0,012|0,013|
|**Rivastigmina 6 mg por cápsula**|0,024|0,024|0,025|
|**Rivastigmina 9 mg por adesivo transdérmico**|0,030|0,029|0,031|
|**Rivastigmina 18 mg por adesivo transdérmico**|0,140|0,138|0,142|
|**Memantina 10 mg por comprimido**|0,162|0,160|0,164|  
**Fonte** : calculados com base na Sabeis de 2022, extração em 29/09/2023<sup>57</sup> .  
**Legenda** : ¹ intervalos de 95% de confiança calculados via método de _Clopper-Pearson_ ; ² proporções complementares para os valores mínimo e máximo.  
O PCDT de DA<sup>54</sup> também recomenda a terapia combinada entre AChEIs e memantina somente para pacientes de grau moderado e memantina isolada para pacientes de grau grave. Desta forma, a estimação da proporção de pacientes de grau moderado usuários de AChEIs combinado com memantina foi com base na distribuição de pacientes com DA por grau obtida  
58  
pelo estudo brasileiro publicado por Ferretti C _et al_ , 2018<sup>58</sup> e os números totais de usuários de AChEIs (115.628) e memantina (26.731) no ano de 2022 extraídos da Sabeis<sup>57</sup> , resultando em **32,4%** dos pacientes com grau moderado, como apresentado na **Tabela C** .  
**Tabela C.** Estimação das proporções de pacientes com doença de Alzheimer segundo grau de doença<sup>a</sup> e medicamento utilizado.  
|**Parâmetro**|**Valor pontual**|**Limite inferior**<br>**Limite**<br>**Superior**|
|---|---|---|
|**Inibidor de acetilcolinesterase isolado**|||
|**Proporção de pacientes de grau leve**|0,415|0,314<br>0,521|
|**Proporção de pacientes de grau moderado**|0,585|Complementar ao valor para pacientes de grau<br>leve|
|**Inibidor de acetilcolinesterase + memantina**|||
|**Proporção de pacientes de grau moderado**|0,821|0,708<br>0,904|
|**Memantina**|||
|**Proporção de pacientes de grau grave**|0,179|Complementar ao valor para pacientes de grau<br>moderado usuários de memantina|  
**Fonte:** calculados com base em Ferretti C _et al_ , 2018<sup>58</sup> .  
**Nota** : a - grau segundo escala de avaliação clínica da demência CDR ( _clinical dementia rating_ )<sup>112</sup> .  
O resumo dos valores de custo dos medicamentos por grau de doença encontra-se na **Tabela** dos serviços de saúde e outros recursos (excluindo medicamentos) para atendimento ao paciente com DA por grau foram extraídos do estudo brasileiro publicado por Ferretti C _et al_ , 2018<sup>58</sup> . Os valores apresentados pelo artigo estão em dólares americanos de 29/02/2016, então foi realizada a conversão para reais de 30/11/2023 pelo método paridade do poder de compra (PPC), ou seja, os valores foram multiplicados por 3,979 para conversão de dólar para real<sup>60</sup> e 1,48 para ajuste da inflação<sup>61</sup> . Para as análises de sensibilidade, o intervalo de 95% de confiança, calculado a partir do desvio-padrão fornecido pelo estudo, foi considerado e a distribuição de probabilidade Beta foi utilizada. Os valores utilizados para os pacientes com DA leve, moderado e grave estão especificados na **Tabela D** .  
**Tabela D** . Custos dos medicamentos, serviços de saúde e outros recursos para atendimento ao paciente com doença de Alzheimer segundo grau de doença.  
|**Grau de doença**<sup>**a**</sup>|**Valor**<br>**pontual**|**Desvio**<br>**padrão**|**Limite**<br>**inferior**|**Limite**<br>**Superior**|**Distribuição**|
|---|---|---|---|---|---|
|**Custo do medicamentodo paciente (R$)**||||||
|**Leve**|1.204,82|||||
|**Moderado**|1.232,68|Composição da|s informações da|s Tabelas A1, A|2, A3 e A4|
|**Grave**|85,92|||||
|**Custo dos serviços de saúde para tratam**|**ento do pacient**|**e (R$)**||||
|**Leve**|1.457,15|1.946,88|958,54|1.955,77||
|**Moderado**|1.319,35|1.223,25|1.035,95|1.602,76|Gama|
|**Grave**|1.472,70|1.744,06|678,81|2.266,59||
|**Custo de outros recursos para atendime**|**nto ao paciente,**|**excluindo medi**|**camentos e serv**|**iços de saúde (**|**R$)**|
|**Leve**|1.968,78|3.082,50|1.179,32|2.758,25||
|**Moderado**|584,42|495,38|469,65|699,19|Gama|  
59  
|**Grave**|0,00<br>-<br>-<br>-|
|---|---|  
**Fonte** : valores convertidos de Ferretti C et al, 2018<sup>113</sup> .  
**Nota** : a - grau segundo escala de avaliação clínica da demência CDR ( _clinical dementia rating_ )<sup>112</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Todos os preços e custos foram obtidos e apresentados em reais (BRL, R$), considerando consultas realizadas em novembro de 2023.  
Os custos extraídos do estudo publicado por Ferretti C _et al_ , 2018<sup>58</sup> foram apresentados em dólares americanos de 29/02/2016, portanto foi realizada a conversão para reais de 30/11/2023 pelo método paridade do poder de compra (PPC), ou seja, os valores foram multiplicados por 3,979 para conversão de dólar para real<sup>60</sup> e 1,48 para ajuste da inflação<sup>61</sup> .  
Na análise de sensibilidade determinística foi analisada a aplicação de fator de correção para custos da tabela SUS<sup>10</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O modelo utilizado foi do tipo Markov ( **Erro! Fonte de referência não encontrada.** ) em que a CST combinada ao tratamento padrão é comparada ao tratamento padrão isolado em pacientes com diagnóstico de DA de grau leve a moderado. Este modelo simula uma coorte de pacientes com DA, incialmente em grau leve ou moderado, e que podem permanecer ou evoluir para os outros graus ou morrer dentro de ciclos de 7 semanas. Os graus seguem a pontuação dos critérios da CDR)<sup>3</sup> .  
**Figura H.** Modelo conceitual do tipo Markov.  
<!-- Start of picture text -->
Leve<br>Moderado Grave<br>Óbito<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
**Nota:** Os graus leve, moderado e greve seguem a pontuação dos critérios da CDR)<sup>3</sup>  
A distribuição inicial dos pacientes (leve ou moderado) utilizada foi com base na distribuição de pacientes com DA por grau obtida pelo estudo brasileiro publicado por Ferretti C _et al_ , 2018<sup>58</sup> . As probabilidades de transição, dentro de 1 ano, entre os graus de doença para o tratamento padrão foram extraídas do estudo Yunusa I _et al_ , 2021<sup>62</sup> . O estudo apresentou matrizes de transição para cada combinação de medicamentos e não uma geral do tratamento padrão, desta forma optou-se por utilizar a matriz com as probabilidades em que o paciente permanece em melhores condições, uma vez que o objetivo do presente estudo  
60  
é avaliar a CST e não cada medicamento isolado. Os valores foram transformados de 1 ano para 7 semanas. Para a análise de sensibilidade foi escolhido a distribuição Dirichlet e foram arbitrariamente atribuídos mais ou menos 20% aos valores pontuais nas probabilidades de transição para outro grau e no caso para a permanência foram considerados os valores complementares.  
Para a composição das probabilidades de transição para a CST em grupo combinada ao tratamento padrão foi considerado a diferença de médias para cognição, medida pelo instrumento MMSE, apresentada pela meta-análise realizada. Nas análises de sensibilidade, os limites inferior e superior considerados são os valores do intervalo de 95% de confiança e a distribuição de probabilidade Beta foi utilizada. A razão de chances foi estimada pelo método apresentado pelo manual da Cochrane<sup>63</sup> e foi multiplicada às probabilidades de transição para um grau maior do modelo para representar as probabilidades de transição para a CST em grupo combinada ao tratamento padrão.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Como é inerente aos modelos econômicos, foi necessário assumir algumas premissas para a condução da avaliação econômica. Esses pressupostos podem representar limitações à validade externa da análise.  
 as probabilidades de transição para o tratamento padrão utilizadas no estudo de origem (Yunusa I _et al_ , 2021<sup>62</sup> ) não se referem ao tratamento padrão em geral, mas para o tratamento da combinação com donepezila e memantina. Optou-se por esta escolha, pois foi a matriz de transição em que o paciente permanece em melhores condições, não beneficiando a intervenção em análise;  
 algumas evidências para a CST em grupo utilizadas foram retiradas de estudos sobre demência em geral e não somente especificamente para DA, tendo em vista que a maioria dos estudos que avaliam CST não delimitarem para DA. Destaca-se, entretanto, que este pressuposto não representa uma limitação importante para a análise, tendo em vista a maioria dos pacientes com demência apresentarem DA e, ainda, que a resposta terapêutica entre indivíduos com DA e outras demências seja similar;  
 os valores de custo dos serviços de saúde e outros recursos (excluindo medicamentos) para atendimento ao paciente utilizados foram extraídos de estudo que engloba pacientes com demência e não especificamente para DA;  
 escolha de um curto horizonte temporal deve-se ao fato de que as evidências para a CST estão restritas a 1 ano;  
 as probabilidades de transição para CST foram aplicadas somente após as 7 semanas de aplicação da CST, ou seja, o primeiro ciclo. De forma conservadora, para os ciclos seguintes, optou-se por utilizar as probabilidades do tratamento padrão, uma vez que não há evidências de continuidade de melhora após a interrupção da intervenção.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
As análises de sensibilidade determinística ( _Deterministic Sensitivity Analysis_ - DAS) foram apresentadas em diagrama de tornado, sendo que a magnitude de variação de cada parâmetro foi definida com base na variação identificada nos estudos ou, quando a variação não estava disponível, uma variação de mais ou menos 20% foi assumida. No caso dos parâmetros custo do acompanhamento/supervisão após o treinamento, número de pacientes por sessão de terapia em grupo e número de grupos atendidos por ano, foi considerado o valor médio na análise basal e os extremos como limite inferior e superior. Os valores detalhados são apresentados no  
**Quadro I** Principais parâmetros do modelo e considerações para as análises de sensibilidade determinística e probabilística.  
|Parâmetro|Determinístico|Mínimo|Máximo|Distribuição para<br>PSA|
|---|---|---|---|---|
|Diferença de médias para|1,74|1,20|2,28|Log-Normal|
|cognição|||||  
61  
|Parâmetro|Determinístico|Mínimo|Máximo|Distribuição para<br>PSA|
|---|---|---|---|---|
|Probabilidade de transição<br>do grau Leve para o grau<br>Moderado ¹|0,0045|0,0036|0,0054|Dirichlet|
|Probabilidade de transição<br>do grau Leve para o grau<br>Grave ¹|0,0011|0,0009|0,0013|Dirichlet|
|Probabilidade de transição|0,0005|0,0004|0,0006|Dirichlet|
|do grau Leve ¹ para o Óbito|||||
|Probabilidade de transição<br>do grau Moderado para o<br>grau Leve ¹|0,0129|0,0102|0,0156|Dirichlet|
|Probabilidade de transição<br>do grau Moderado para o<br>grau Grave ¹|0,0464|0,0359|0,0576|Dirichlet|
|Probabilidade de transição<br>do grau Moderado ¹ para o<br>Óbito|0,0063|0,0050|0,0076|Dirichlet|
|Probabilidade de transição<br>do grau Grave ¹ para o Óbito|0,0217|0,0171|0,0265|Dirichlet|
|Custo dos serviços de saúde<br>para tratamento de pacientes<br>no grau Leve (R$)|195,62|128,68|262,56|Gama|
|Custo dos serviços de saúde<br>para tratamento de pacientes<br>no grau Moderado (R$)|177,12|139,07|215,16|Gama|
|Custo dos serviços de saúde<br>para tratamento de pacientes<br>no grau Grave (R$)|197,71|91,13|304,28|Gama|
|Custo de outros recursos<br>para atendimento de<br>pacientes no grau Leve (R$)|264,30|158,32|370,29|Gama|
|Custo de outros recursos<br>para atendimento de<br>pacientes no grau Moderado<br>(R$)|78,46|63,05|93,86|Gama|
|Número de pacientes por<br>sessão|7|5|8|Uniforme|
|Número de grupos atendidos<br>por ano|2|1|3|Uniforme|  
62  
|Parâmetro|Determinístico|Mínimo|Máximo|Distribuição para<br>PSA|
|---|---|---|---|---|
|Custo do treinamento<br>presencial para grupo no 1º<br>ano (R$)|12.000,00|9.600,00|14.400,00|Gama|
|Custo do acompanhamento/<br>supervisão após treinamento<br>(R$)|6.000,00|4.800,00|7.200,00|Gama|
|Custo de materiais para uso<br>permanente (R$)|1.500,00|1.200,00|1.800,00|Gama|
|Custo da substituição dos<br>materiais a partir do 2º ano<br>(R$)|300,00|240,00|360,00|Gama|
|Utilidade do grau Leve<br>(QALY)|0,690|0,552|0,828|Beta|
|Utilidade do grau Moderado<br>(QALY)|0,530|0,424|0,636|Beta|
|Proporção de usuários por<br>medicamento|Todas as proporções<br>apresentadas nas**Tabelas A a**<br>**D e Quadro G**variam ao<br>mesmo tempo|Dirichlet|||
|Proporção de pacientes<br>usuários de AChEIs no grau<br>Leve|0,415|0,314|0,521|Beta|
|Proporção de pacientes<br>usuários de Memantina no<br>grau Moderado|0,821|0,708|0,904|Beta|  
Para a análise probabilística multivariada ( _probabilistic sensitivity analysis_ - PSA) foram executadas 1.000 simulações de Monte Carlo de segunda ordem, em que os parâmetros variados obedeceram a um comportamento pré-estabelecido por distribuições de probabilidade validadas pela literatura e usando os valores dos limites definidos na análise determinística. Foram consideradas as seguintes distribuições para representar o comportamento das variáveis: beta para parâmetros que variaram independentemente de 0 a 1, Dirichlet para parâmetros que variaram dependentemente de 0 a 1, gama para os custos (que variam de 0 a infinito) e uniforme para parâmetros de contagens ( **Quadro** **_I_** ). Os resultados foram apresentados em gráficos de dispersão, representando o plano de custo-efetividade incremental, bem como em curvas de aceitabilidade de custo-efetividade (CEAC), acompanhados de análise narrativa. Para construção das CEAC foi considerado o valor de limiar de custo-efetividade conforme recomendado pela Conitec (R$ 40.000,00 por QALY)<sup>64</sup> , sendo variados entre uma e três vezes o valor de referência.  
**Quadro I** Principais parâmetros do modelo e considerações para as análises de sensibilidade determinística e probabilística.  
63  
|Parâmetro|Determinístico|Mínimo|Máximo|Distribuição para<br>PSA|
|---|---|---|---|---|
|Diferença de médias para<br>cognição|1,74|1,20|2,28|Log-Normal|
|Probabilidade de transição<br>do grau Leve para o grau<br>Moderado ¹|0,0045|0,0036|0,0054|Dirichlet|
|Probabilidade de transição<br>do grau Leve para o grau<br>Grave ¹|0,0011|0,0009|0,0013|Dirichlet|
|Probabilidade de transição<br>do grau Leve ¹ para o Óbito|0,0005|0,0004|0,0006|Dirichlet|
|Probabilidade de transição<br>do grau Moderado para o<br>grau Leve ¹|0,0129|0,0102|0,0156|Dirichlet|
|Probabilidade de transição<br>do grau Moderado para o<br>grau Grave ¹|0,0464|0,0359|0,0576|Dirichlet|
|Probabilidade de transição<br>do grau Moderado ¹ para o<br>Óbito|0,0063|0,0050|0,0076|Dirichlet|
|Probabilidade de transição<br>do grau Grave ¹ para o Óbito|0,0217|0,0171|0,0265|Dirichlet|
|Custo dos serviços de saúde<br>para tratamento de pacientes<br>no grau Leve (R$)|195,62|128,68|262,56|Gama|
|Custo dos serviços de saúde<br>para tratamento de pacientes<br>no grau Moderado (R$)|177,12|139,07|215,16|Gama|
|Custo dos serviços de saúde<br>para tratamento de pacientes<br>no grau Grave (R$)|197,71|91,13|304,28|Gama|
|Custo de outros recursos<br>para atendimento de<br>pacientes no grau Leve (R$)|264,30|158,32|370,29|Gama|
|Custo de outros recursos<br>para atendimento de<br>pacientes no grau Moderado<br>(R$)|78,46|63,05|93,86|Gama|
|Número de pacientes por<br>sessão|7|5|8|Uniforme|  
64  
|Parâmetro|Determinístico|Mínimo|Máximo|Distribuição para<br>PSA|
|---|---|---|---|---|
|Número de grupos<br>atendidos por ano|2|1|3|Uniforme|
|Custo do treinamento<br>presencial para grupo no 1º<br>ano (R$)|12.000,00|9.600,00|14.400,00|Gama|
|Custo do acompanhamento/<br>supervisão após treinamento<br>(R$)|6.000,00|4.800,00|7.200,00|Gama|
|Custo de materiais para uso<br>permanente (R$)|1.500,00|1.200,00|1.800,00|Gama|
|Custo da substituição dos<br>materiais a partir do 2º ano<br>(R$)|300,00|240,00|360,00|Gama|
|Utilidade do grau Leve<br>(QALY)|0,690|0,552|0,828|Beta|
|Utilidade do grau Moderado<br>(QALY)|0,530|0,424|0,636|Beta|
|Proporção de usuários por<br>medicamento|Todas as proporções<br>apresentadas nas**Tabelas A a**<br>**D e Quadro G**variam ao<br>mesmo tempo|Dirichlet|||
|Proporção de pacientes<br>usuários de AChEIs no grau<br>Leve|0,415|0,314|0,521|Beta|
|Proporção de pacientes<br>usuários de Memantina no<br>grau Moderado|0,821|0,708|0,904|Beta|  
**Legenda** : PSA = análise probabilística multivariada ( _probabilistic sensitivity analysis_ ); ¹grau segundo escala de avaliação clínica da demência CDR ( _clinical dementia rating_ )<sup>112</sup> ; (a) calculada pela meta-análise, cognição medida pelo instrumento MMSE; (b) equipe de treinamento CST-Brasil (RJ); QALY = anos de vida ajustados pela qualidade; AChEIs = inibidores da acetilcolinesterase.  
Seguindo as diretrizes de boas práticas de modelagem<sup>65,66</sup> , foi realizada validação interna dos dados, fazendo análises em duplicata para certificar que todas as equações haviam sido descritas corretamente.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Para o horizonte temporal de aproximadamente 1 ano, a análise indicou que a CST em grupo combinada ao tratamento padrão como opção terapêutica para o tratamento de pacientes com DA leve a moderada, apresenta maior benefício clínico (0,0041 QALY) e um maior custo total (R$ 152,42) comparado ao tratamento padrão isolado, apresentando razão de custoefetividade incremental (RCEI) de R$ 37.280,24 por QALY ganho, conforme apresentado na **Tabela** .  
65  
**Tabela E.** Custos, desfechos e razão de custo-efetividade incremental (RCEI) para a análise de custo-efetividade/utilidade.  
||**Procedimento Padrão**|**Terapia de Estimulação Cognitiva +**<br>**Procedimento Padrão**|
|---|---|---|
|**Efetividade Esperada Total (QALY)**|0, 5427|0,5468|
|**Efetividade Incremental (QALY)**|-|0,0041|
|**Custo Esperado Total (R$)**|2.917,50|3.069,92|
|**Custo Incremental (R$)**|-|152,42|
|**RCEI (R$/QALY)**|-|37.280,24|  
**Fonte:** elaboração própria.  
**Legenda:** QALY: anos de vida ajustado pela qualidade; RCEI: razão de custo-efetividade incremental.  
As análises de sensibilidade probabilísticas são apresentadas nas **Figuras H a K** . Os resultados corroboram com os valores obtidos no caso-base, visto que os pontos dos gráficos de dispersão estão dispostos praticamente em sua totalidade no quadrante superior direito, confirmando que a CST em grupo combinada ao tratamento padrão apresenta benefício clínico para o desfecho apesar de maior custo incremental.  
Também nas **Figuras H a K** é apresentada a curva de aceitabilidade gerada a partir da análise de sensibilidade probabilística, confirmando que a CST em grupo combinada ao tratamento padrão tem uma probabilidade de 42,2% de ser custoefetivo considerando o valor do limiar de custo-efetividade recomendado pela Conitec<sup>114</sup> e 94,3% se considerado três vezes esse valor de limiar.  
Por meio das análises de sensibilidade univariadas determinísticas ( **Figuras H** a **K** ), foi possível observar que dez parâmetros impactam na RCEI e a incerteza destes podem tornar a intervenção sob investigação acima do limiar recomendado pela Conitec<sup>114</sup> . A aplicação de fator de correção para custos, a utilidade para o grau grave, o custo da compra dos materiais e equipamentos para CST e a proporção de pacientes usuários de AChEIs no grau leve são os que mais impactam indiretamente na RCEI, ou seja, respectivamente R$ 108.231,71 (+190,3%), R$ 61.332,35 (+64,5%), R$ 42.521,42 (+14,1%) e R$ 42.806,97 (+14,8%). Enquanto os parâmetros utilidade para o grau moderado, número de grupos atendidos por ano, número de pacientes por sessão, probabilidade de transição do grau moderado para o grau grave, custo dos serviços de saúde para tratamento de pacientes no grau grave e utilidade para o grau leve são o que mais impactam diretamente na RCEI, ou seja, respectivamente R$ 74.596,36 (+100,1%), R$ 66.630,86 (+78,7%), R$ 50.223,86 (+34,7%), R$ 44.886,23 (+20,4%), R$ 41.376,70 (+11,0%) e R$ 41.053,90 (+10,1%).  
A **Tabela F.** apresenta o cenário exploratório em que considera o custo dos medicamentos sem desperdício. O valor da RCEI pode diminuir até 0,8% (R$ 36.980,45) da análise basal.  
**Tabela F** . Custos, desfechos e razão de custo-efetividade incremental (RCEI) para a análise de custo-efetividade/utilidade considerando sem desperdício dos medicamentos.  
||**Procedimento Padrão**|**Terapia de Estimulação Cognitiva +**|
|---|---|---|
|||**Procedimento Padrão**|
|**Efetividade Esperada Total (QALY)**|0,5427|0,5468|
|**Efetividade Incremental (QALY)**|-|0,0041|
|**Custo Esperado Total (R$)**|2.809,42|2.960,61|
|**Custo Incremental (R$)**|-|151,19|
|**RCEI (R$/QALY)**|-|36.980,45|  
**Fonte:** elaboração própria.  
**Legenda:** QALY: anos de vida ajustado pela qualidade; RCEI: razão de custo-efetividade incremental.  
66  
No primeiro ano da implementação da CST, há o custo inicial do treinamento, acompanhamento e materiais. Para os anos seguintes, seria somente o custo de renovação de equipamentos danificados ou perdidos em que a equipe de treinamento CSTBrasil (RJ) estimou em R$ 300,00. Desta forma, o valor da RCEI a partir do segundo ano de implementação da CST em grupo seria R$ 13.170,79/QALY ( **Tabela** ). Neste cenário, a intervenção pode ser custo-efetiva considerando o valor do limiar de custo-efetividade recomendado pela Conitec<sup>67</sup> . E na análise de sensibilidade probabilística, pode ter uma probabilidade de 95,1% de ser custo-efetiva dentro desse limiar ( **Figuras A8-A11** ).  
**Tabela G** . Custos, desfechos e razão de custo-efetividade incremental (RCEI) para a análise de custo-efetividade/utilidade, cenário considerando custos da CST após 1 ano.  
||**Procedimento Padrão**|**Terapia de Estimulação Cognitiva +**<br>**Procedimento Padrão**|
|---|---|---|
|**Efetividade Esperada Total (QALY)**|0,5427|0,5468|
|**Efetividade Incremental (QALY)**|-|0,0041|
|**Custo Esperado Total (R$)**|2.917,50|2.971,35|
|**Custo Incremental (R$)**|-|53,85|
|**RCEI (R$/QALY)**|-|13.170,79|  
**Fonte:** elaboração própria.  
**Legenda:** QALY: anos de vida ajustado pela qualidade; RCEI: razão de custo-efetividade incremental.  
Após as 7 semanas de aplicação da CST, pode-se aplicar a CST de manutenção, a qual consiste na repetição das 14 sessões ao longo de 7 semanas subsequentes. Os resultados do estudo conduzido por Orrel _et al_ . (2014) demonstraram que a função cognitiva dos pacientes permaneceu estável, ou seja, houve a preservação da cognição dos pacientes com DA<sup>10</sup> . Para a simulação deste cenário, usou-se a premissa de que as probabilidades de transição para um grau pior da doença seriam nulas após aplicação da terapia, mas para os próximos ciclos, as probabilidades de transição seriam as mesmas do tratamento padrão. Então, nesta situação, o valor da RCEI seria R$ R$ 23.657,29/QALY ( **Tabela** ), o que configura 36,5% a menos do valor basal obtido.  
**Tabela H** . Custos, desfechos e razão de custo-efetividade incremental (RCEI) para a análise de custo-efetividade/utilidade, cenário considerando aplicação da CST de manutenção.  
||**Procedimento Padrão**|**Terapia de Estimulação Cognitiva +**<br>**Procedimento Padrão**|
|---|---|---|
|**Efetividade Esperada Total (QALY)**|0,5427|0,55018|
|**Efetividade Incremental (QALY)**|-|0,0074|
|**Custo Esperado Total (R$)**|2.917,50|3.092,20|
|**Custo Incremental (R$)**|-|174,69|
|**RCEI (R$/QALY)**|-|23.657,29|  
**Fonte:** elaboração própria.  
**Legenda:** QALY: anos de vida ajustado pela qualidade; RCEI: razão de custo-efetividade incremental.  
**Figura H** . Plano de custo-efetividade incremental de custo-utilidade da terapia de estimulação cognitiva em grupo combinada ao tratamento padrão para anos de vida ajustado a qualidade - QALY.  
67  
<!-- Start of picture text -->
:<br>son00 Andlise de Sensibilidade Probabilistica<br>400.0 oR net A vate go :<br>= so + Fae ree eT<br>|é IEar ee<br>= . eeWie 8 Pe a RehanLe, Eashie?<br>aEtt IERe ait (OLA 80<br>tooos 7.eid,3 BesseyFis aeReyesRGR aOo oTAtLNSAH A Te SL<br>001 0000900 9001.20}. «MKS mms coy emsSoem | aol0,<br>Efetividade Incremental (QALY ganho}<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
**Figura I** . Curva de aceitabilidade para análise de custo-utilidade da terapia de estimulação cognitiva em grupo combinada ao tratamento padrão para anos de vida ajustados pela qualidade – QALY.  
<!-- Start of picture text -->
Curva de Aceitabilidade<br>—Procesiment Padrio  —Procedento Pada<br>10090% + Terapia de Estmuagbo Cogntha<br>g 000% Siam.<br>20.00%<br>3<br>& 70,00%<br>Z scooos<br>&4 s000%<br>$ som<br>§0<br>ra00%<br>3<br>“ 10,00%<br>00%00 000 16000 24000 2000 0000<br>Disposig30apagar(RS/QALY ganho)<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
68  
<!-- Start of picture text -->
Anélise de Sensibilidade Deterministica<br>A imte Superior tite infer<br>Fe ed ST<br>PetiaNineime REE spent seo | ——$_--— NEToO<br>de rans do uate rns gn ne =<br>anoarenerena pn Vamentade Mas Patoncentrnpro agoueCoge ve SSSeem=<br>Casto ses deepcaso aafvstymitanto ceptsimg vonsiemesgran ==<br>eterno omer 4<br>ttle<br>de varsodo iewepaso erty t<br>ItaiCaso Deeper eo cm) :<br>de varaodo ie Nodensoprseea ee<br>caso aotnestgnny L3 mo os |<br>tronaredepeerescaso a attain ncponer cos e tse ormesconeeaera<br>Caso sats 20musesrl emantnao oufs oso<br>RS2400000 n53722000 RS5056000 RSEABIO00 RS7.12000 R$9040000 RS 10368000<br>Razio de Custo-efIncr e mentaltividade(R$/QALY ganho)<br><!-- End of picture text -->  
**Figura J** . Diagrama de tornado para análise de custo-utilidade da terapia de estimulação cognitiva em grupo combinada ao tratamento padrão para anos de vida ajustados pela qualidade - QALY.  
**Fonte:** elaboração própria.  
<!-- Start of picture text -->
Curva de Aceitabilidade<br>—Procediment Padrdo  —Procedimento Palo<br>+ Terapia de Estimulaco Cogntva<br>100,00%<br>95 som<br>0.00%<br>8<br>5 s0.00%<br>% 70.00%<br>2 coos<br>8<br>© sooon<br>FH 40,00%<br>3§ 000%<br>B 20,00%<br>&<br>10.00%<br>00%00 4090 s000 12000 ares16000<br>Disposi¢3oa pagar (RS/QALY ganho)<br><!-- End of picture text -->  
**Figura K** . Curva de aceitabilidade para análise de custo-utilidade da terapia de estimulação cognitiva em grupo combinada ao tratamento padrão, cenário considerando custos da CST após 1 ano, para anos de vida ajustados pela qualidade – QALY.  
**Fonte:** elaboração própria.  
69

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A população considerada elegível desta análise foi constituída por pacientes, de ambos os sexos, com diagnóstico de DA leve à moderada. Para a estimativa do número de pacientes elegíveis a cada ano foi utilizada as metodologias de demandas aferida e epidemiológica.  
O número de usuários de medicamentos indicados para o tratamento de DA leve e moderada foi utilizado como uma aproximação para estimar o número de pessoas elegíveis para tratamento com a CST. Os dados sobre o número de usuários de medicamentos, com diagnosticados com DA, foi extraído em 29/09/2023 da Sala Aberta de Inteligência em Saúde (Sabeis)<sup>57</sup> .  
Como informado anteriormente, a população-alvo é de pacientes com diagnóstico de DA leve a moderada. Desta forma, o número total de usuários de AChEIs foi considerado para a população total elegível para esta análise, uma vez que segundo o PCDT de DA vigente<sup>54</sup> , esta classe de medicamento é recomendada somente para pacientes de graus leve a moderado. Para o total de usuários de AChEIs (donepezila, galantamina e rivastigmina) foram utilizados os valores dos anos de 2018 a 2022, mas ignorando o ano de 2020, pois houve uma queda significativa. Esta queda, segundo especialistas consultados, se deve a baixa procura por estes medicamentos durante a pandemia de COVID-19 ocorrida nesse ano. Já para o total de usuários de memantina foram utilizados os valores disponíveis entre os anos de 2019 e 2022. Considerando os dados retrospectivos extraídos da Sabeis, estimou-se por meio de ajuste de curva o crescimento esperado de novos entrantes nos anos seguintes da série. Detalhes das estimações encontram-se nas **Figuras L** a **R** .  
O PCDT vigente também recomenda a terapia combinada entre AChEIs e memantina somente para pacientes de grau moderado e memantina isolada para pacientes de grau grave. Logo, uma parcela da população usuária de memantina também foi considerada nesta análise usando-se, além da aferida, o método de demanda epidemiológica. A distribuição de pacientes com DA por grau foi definida por meio dos dados apresentados pelo estudo brasileiro publicado por Ferreti C, _et al_<sup>58</sup> . Neste estudo, dos pacientes com diagnóstico de DA de acima de grau moderado, **81,2%** apresentaram grau moderado.  
A população elegível obtida para cada ano é apresentada na **Tabela I** .  
**Tabela I.** Projeção da população utilizada no modelo de impacto orçamentário.  
|Estimativa populacional||Ano 1||Ano 2||Ano 3||Ano 4||Ano 5|
|---|---|---|---|---|---|---|---|---|---|---|
|ANO||2025||2026||2027||2028||2029|
|População usuária de AChEIs||123.3||129.8||138.1||148.3||160.4|
|= População elegível total|77||45||80||82||52||
|População usuária de memantina total||53.00||61.73||70.45||79.18||87.91|
||3||0||7||4||1||
|População usuária de memantina de||43.51||50.67||57.83||65.00||72.16|
|grau moderado (81,2%*)|0||4||8||2||6||  
**Fonte:** elaboração própria; *Ferreti C, _et al_<sup>58</sup> .  
**Legenda:** AChEIs= inibidores da acetilcolinesterase.  
Para o tratamento padrão, foi necessário determinar as porcentagens de uso de cada AChEI. Essas porcentagens foram projetadas a partir dos dados retrospectivos coletados da Sabeis dos anos de 2018 a 2022, mas ignorando o ano de 2020 (como justificado anteriormente). As estimações das projeções das proporções nos anos seguintes da série foram por meio de ajuste de curva e são apresentados em detalhe nas **Figuras L** a **R** .  
70  
O número de usuários de medicamentos, com diagnosticados com DA, foi extraído em 29/09/2023 da Sala Aberta de Inteligência em Saúde (Sabeis)<sup>57</sup> . Estas informações são apresentadas na **Tabela J** .  
**Tabela J.** Número de pacientes diagnosticados com doença de Alzheimer, usuários de medicamentos no Sistema Único de Saúde, no período de 2018 a 2022.  
|Medicamento|2018|2019|2020|2021|2022|
|---|---|---|---|---|---|
|Donepezila 5 mg por comprimido|28.89|22.43|18.09|18.76|18.75|
||3|3|4|8|0|
|Donepezila 10 mg por comprimido|43.56|43.46|41.37|41.47|43.37|
||3|8|5|3|6|
|Galantamina 8 mg por cápsula de|5.806|5.829|5.041|5.514|6.039|
|liberação prolongada)||||||
|Galantamina 16 mg por cápsula de|7.124|6.507|5.882|6.363|7.153|
|liberação prolongada||||||
|Galantamina 24 mg por cápsula de|9.946|10.04|9.141|9.377|10.20|
|liberação prolongada||7|||4|
|Rivastigmina 1,5 mg por cápsula|6.055|4.803|2.919|3.071|2.460|
|Rivastigmina 2,0 mg/ml solução oral|2.429|1.877|1.625|1.242|1.009|
|por frasco de 120 ml||||||
|Rivastigmina 3 mg por cápsula|8.556|7.276|6.122|5.008|2.733|
|Rivastigmina 4,5 mg por cápsula|4.681|3.826|2.943|2.404|1.433|
|Rivastigmina 6 mg por cápsula|8.237|6.739|4.964|4.345|2.826|
|Rivastigmina<br>9<br>mg<br>em<br>adesivo|1.912|4.567|4.064|3.622|3.459|
|transdérmico||||||
|Rivastigmina 18 mg em adesivo|2.736|7.313|11.42|14.09|16.18|
|transdérmico|||4|2|6|
|Memantina 10 mg por comprimido|0|771|9.017|18.40<br>7|26.73<br>1|  
**Fonte** : Sabeis, extração em 29/09/2023<sup>57</sup> .  
Considerando os dados retrospectivos extraídos da Sabeis, estimou-se por meio de ajuste de curva o crescimento esperado de novos entrantes nos anos seguintes da série.  
Para o total de usuários de AChEIs (donepezila, galantamina e rivastigmina), foi realizada um ajuste polinomial de ordem 2. Para esta estimação, foram utilizados os valores dos anos de 2018 a 2022, mas ignorando o ano de 2020, pois houve uma queda significativa. Esta queda, segundo especialistas consultados, se deve a baixa procura por estes medicamentos durante a pandemia de COVID-19 ocorrida nesse ano. O valor do coeficiente de correlação para a série indica uma boa correlação entre os dados (R² = 0,9869), como observado na **Figura L.**  
71  
<!-- Start of picture text -->
Demanda Aferida<br>150.000<br>© — Populacao Aferida : 2<br>8 sao.c00 | “#"" Populacao Estimada<br>g Polinomial (Populacao Aferida) Fed<br>a<br>& 130.000 @. ;<br>2 . :<br>‘3 120.000 - ="<br>z - _ ><br>ey ° y = 933,67x?- 4E+06x<br>110.000 R? = 0,9869 + 4E+09<br>2018 2019 2020 2021 2022 2023 2024 2025 2026 2027 2028<br>Ano<br><!-- End of picture text -->  
**Figura L.** Estimativa da população usurária de inibidores da acetilcolinesterase com diagnóstico de doença de Alzheimer, baseada em demanda aferida.  
**Fonte:** elaboração própria.  
Para o total de usuários de memantina, foi realizada um ajuste linear. Para esta estimação, foram utilizados os valores disponíveis entre os anos de 2019 e 2022. O valor do coeficiente de correlação para a série indica uma boa correlação entre os dados (R² = 0,9994), como observado na **Figura M.**  
<!-- Start of picture text -->
Demanda Aferida<br>90.000<br>© Populacao Aferida<br>‘ 7560 .000  | ...@-+ Populacao Estimadainear (Populacdo Aferida) oe —<br>B 45.000 ver<br>25 e wet y= 8727K-2  2407<br>E 30.000 R? =0,9994<br>3*<br>2<br>15.000 . a<br>oe<br>2019 2020 2021-2022» 2023-2024 «2025-2026 »= «2027'S «-2028<br>Ano<br><!-- End of picture text -->  
**Figura M.** Estimativa da população usurária de memantina com diagnóstico de doença de Alzheimer, baseada na demanda aferida.  
**Fonte:** elaboração própria.  
Para o tratamento padrão, foi necessário determinar as porcentagens de uso de cada AChEIs. Essas porcentagens foram projetadas a partir dos dados retrospectivos coletados da Sabeis dos anos de 2018 a 2022, mas ignorando o ano de 2020 (como justificado anteriormente). As estimações das projeções das proporções nos anos seguintes da série foram por meio de ajuste de curva.  
Para os usuários de comprimidos de donepezila de 5 mg e 10 mg, foi realizada um ajuste polinomial de ordem 2. O valor do coeficiente de correlação para a série indica uma boa correlação entre os dados (R²>0,9), como apresentado na **Figura N.**  
72  
<!-- Start of picture text -->
Demanda Aferida- Donepezila (por comprimido)<br>wv 40%<br>a s atssenscnnenen seseseneetee@ . °<br>8é 30% e ~ y= - 0,0003x? > - 1,3439x3 + 1348,6 8,<br>© R? = 0,9639<br>3 r<br>2 20% ><br>g3g Y = 0,007%-a 28, 156x+ 28452 °<br>3@ 10% R=0,9718<br>0%<br>e<br>s 2018 2019 2020 2021 2022<br>* Ano<br>© Populacdo Aferida - Smg © Populacao Aferida - 10mg<br>Polinomial (Populago Aferida -Smg) --------+ Polinomial (Populago Aferida - 10mg)<br><!-- End of picture text -->  
**Figura N.** Estimativa da proporção de usuários, com diagnóstico de doença de Alzheimer, de comprimidos de donepezila (5mg e 10mg), baseada na demanda aferida.  
**Fonte:** elaboração própria.  
**Legenda** : AChEIs= inibidores da acetilcolinesterase.  
Para os usuários de cápsulas de liberação prolongada de galantamina de 8 mg, 16 mg e 24 mg, foi realizada um ajuste polinomial de ordem 2. O valor do coeficiente de correlação para a série indica uma boa correlação entre os dados (R²>0,85), como apresentado na **Figura O.**  
<!-- Start of picture text -->
Demanda Aferida - Galantamina (por capsula de liberacdo prolongada)<br>wn 10%<br>&a y = 0,0005 3 13x < + 194 °<br>g<ow 8% ¢ Sd *<br>3<br>B8z 6% y= 0,0016x?R?=-  0,9986,2632x + 6324,1 at<br>Ss3 °t ; P4° sess 5 se° °<br>R4=0,9048<br>8 4% y= 0,0004x2 - 1,5666x4+1580,7<br>8<br>B 2%<br>a 2018 2019 2020 2021 2022<br>Ano<br>© Populacdo Aferida - 8mg © Populacdo Aferida - 16mg<br>© — Populagdo Aferida- 24mg Polinomial (Populagao Aferida - 8mg)<br>-sss-++ Polinomial (Populagao Aferida - 16mg) Polinomial (Populago Aferida - 24mg)<br><!-- End of picture text -->  
**Figura O.** Estimativa da proporção de usuários, com diagnóstico de doença de Alzheimer, cápsulas de liberação prolongada de galantamina (8 mg, 16 mg e 24 mg), baseada na demanda aferida.  
**Fonte:** elaboração própria.  
**Legenda** : AChEIs= inibidores da acetilcolinesterase.  
Para os usuários de cápsulas de rivastigmina de 1,5 mg, 3 mg, 4,5 mg e 6 mg, foi realizada ajuste linear. O valor do coeficiente de correlação para a série indica uma boa correlação entre os dados (R²>0,9), como apresentado na **Figura P** .  
73  
<!-- Start of picture text -->
Demanda Aferida- Rivastigmina (por capsula)<br>a 7%<br>a¢<br>5 a . y=-0,0099x+ 20,113<br>< Se e@i. R?=0,9488<br>25% | —¥=-0,0063x-+12,664.oe. 27 . . y=-0,0094x.+ 19,085<br>gsg2 i R?=0,9947 : rte, : B2=ee  0,9914 °<br>g bd 8.<br>8 3% e. + Settee)<br>Ssg<br>2y=+0,0057x+ 11,5:<br>a °<br>1%<br>2018 2019 2020 2021 2022<br>Ano<br>© PopulagSo Aferida - 1,5mg. © — Populacdo Aferida - 3mg<br>© Populacdo Aferida - 4,5mg, © — Populacdo Aferida - 6mg,<br>LinearLinear (Populacao(Populacdo AferidaAferida -- 4,5mg)1.5mg) ssssss LinearLinear (Populago(Populagdo Aferida -  3me6mg )<br><!-- End of picture text -->  
**Figura P.** Estimativa da proporção de usuários, com diagnóstico de doença de Alzheimer, cápsulas de rivastigmina (1,5  
mg, 3 mg, 4,5 mg e 6 mg), baseada na demanda aferida.  
**Fonte:** elaboração própria.  
**Legenda:** AChEIs= inibidores da acetilcolinesterase.  
Para os usuários de adesivos transdérmico de rivastigmina de 9 mg e 18 mg, foi realizada ajuste linear. O valor do coeficiente de correlação para a série indica uma boa correlação entre os dados (R²>0,9), como apresentado na **Figura Q.**  
<!-- Start of picture text -->
Demanda Aferida - Rivastigmina (adesivo transdérmico)<br>wn 20%<br>a<br>z<br>2<br>= 15% y= 0,0301x- 60,806<br>3 R?=0,9885 °<br>8<br>3<br>@<br>x3 5% fto- y 3-0,0023x+° R?=0/98614,603<br>Ss 0%<br>. 2018 2019 2020 2021 2022<br>Ano<br>© Populacao Aferida - 9mg © — Populagdo Aferida - 18mg,<br>Linear (Populacao Aferida - 9mg) Linear (Populacao Aferida - 18m@)<br><!-- End of picture text -->  
**Figura Q.** Estimativa da proporção de usuários, com diagnóstico de doença de Alzheimer, adesivos transdérmico de rivastigmina (9 mg e 18 mg), baseada na demanda aferida.  
**Fonte:** elaboração própria.  
**Legenda** : AChEIs= inibidores da acetilcolinesterase.  
Para os usuários de frascos de 120 mL de solução oral de 2,0 mg de rivastigmina, foi realizada ajuste linear. O valor do coeficiente de correlação para a série indica uma boa correlação entre os dados (R²>0,9), como apresentado na **Figura R.**  
74  
<!-- Start of picture text -->
Demanda Aferida- Rivastigmina 2,0 mg/ml solucao oral<br>a 2,0%<br>3 15% Se y=~0,0024x/+-4,9047<br>S te RB 0,986<br>B 10% a<br>3 05%<br>: 2018 2019 2020 2021 2022<br>° Ano.<br>- © — Populagdo Aferida ~~~ Linear (Populacdo Aferida)<br><!-- End of picture text -->  
**Figura R** . Estimativa da proporção de usuários, com diagnóstico de doença de Alzheimer, frascos de 120 mL de solução  
oral de 2,0 mg de rivastigmina, baseada na demanda aferida.  
**Fonte:** elaboração própria.  
**Legenda** : AChEIs= inibidores da acetilcolinesterase.  
Quando os valores das projeções fossem negativos, assumiu-se valor zero, subentendendo que há uma descontinuidade de uso daquela tecnologia após alguns anos. A soma das porcentagens das projeções não são exatamente 100%, então esses valores ainda foram normalizados.  
Quando os valores das projeções fossem negativos, assumiu-se valor zero, subentendendo que há uma descontinuidade de uso daquela tecnologia após alguns anos. A soma das porcentagens das projeções não são exatamente 100%, então esses valores ainda foram normalizados. Essas porcentagens são apresentadas na tabela do _market share_ ( **Tabela K** ).

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
No cenário atual, considerou-se os pacientes que realizam o tratamento com um dos AChEIs isolado ou combinado com a memantina. Para cada AChEIs foi considerada uma porcentagem de usuários por ano. Estas porcentagens foram estimadas via normalização dos valores obtidos pelo ajuste das curvas das proporções de uso de cada medicamento. Para a memantina, foi considerado os pacientes de grau moderado que fazem a terapia combinada. A porcentagem é dada pela razão entre os números projetados para usuários de memantina de grau moderado e para usuários de AChEIs para cada ano.  
Para o cenário alternativo 1 (Tabela K), foi estimada uma taxa de difusão conservadora para a aplicação da CST em grupo com um aumento de 20% ao ano, chegando em cinco anos a atingir 100% dos pacientes com DA leve a moderado. Como a intervenção em avaliação é combinada ao tratamento padrão, esta permanece 100% em uso ao longo dos anos.  
**Tabela K.** Cenário alternativo 1 com _market share_ e taxa de difusão.  
|Cenário||Ano||Ano||Ano||Ano||Ano|
|---|---|---|---|---|---|---|---|---|---|---|
||1||2||3||4||5||
|Tratamento padrão||100||100||100||100||100|
||%||%||%||%||%||
|Donepezila 5 mg por comprimido||22,4||24,9||27,5||30,0||32,5|
||%||%||%||%||%||
|Donepezila 10 mg por comprimido||33,4||31,0||28,6||26,4||24,4|
||%||%||%||%||%||  
75  
|Galantamina 8 mg por cápsula de liberação||5,4||5,3||5,2||5,1||5,0|
|---|---|---|---|---|---|---|---|---|---|---|
|prolongada|%||%||%||%||%||
|Galantamina 16 mg por cápsula de liberação||8,5||9,1||9,6||10,2||10,7|
|prolongada|%||%||%||%||%||
|Galantamina 24 mg por cápsula de liberação||8,7||8,4||8,1||7,9||7,6|
|prolongada|%||%||%||%||%||
|Rivastigmina 1,5 mg por cápsula|%|0,1|%|0,0|%|0,0|%|0,0|%|0,0|
|Rivastigmina 2,0 mg/ml solução oral por||0,1||0,0||0,0||0,0||0,0|
|frasco de 120 ml|%||%||%||%||%||
|Rivastigmina 3 mg por cápsula|%|0,0|%|0,0|%|0,0|%|0,0|%|0,0|
|Rivastigmina 4,5 mg por cápsula||0,0||0,0||0,0||0,0||0,0|
||%||%||%||%||%||
|Rivastigmina 6 mg por cápsula|%|0,0|%|0,0|%|0,0|%|0,0|%|0,0|
|Rivastigmina 9 mg por adesivo transdérmico||1,9||1,5||1,2||0,9||0,7|
||%||%||%||%||%||
|Rivastigmina 18 mg por adesivo transdérmico||19,4||19,7||19,7||19,4||19,0|
||%||%||%||%||%||
|Memantina 10 mg por comprimido||35,2||39,0||41,9||43,8||45,0|
||%||%||%||%||%||
|Terapia de estimulação cognitiva||20%||40%||60%||80%|%|100|  
**Fonte:** elaboração própria.  
Além disso, um segundo cenário alternativo foi estimado, prevendo uma taxa de difusão mais agressiva, partindo-se da premissa de que todos os pacientes elegíveis seriam encaminhados para CST em grupo, combinado ao tratamento padrão, já no primeiro ano.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Foi adotada a perspectiva do Sistema Único de Saúde (SUS).

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O horizonte temporal utilizado foi de cinco anos, conforme as Diretrizes Metodológicas de AIO do MS<sup>68</sup> .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O modelo considerou apenas custos médicos diretos. A composição do custo do tratamento medicamentoso padrão e da  
CST em grupo para esta análise foi a mesma considerada na avaliação econômica e está descrita em detalhes no item Preços e  
custos da tecnologia e nas **Tabelas A a D** e **Quadro G** .

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Foram assumidos alguns pressupostos para a condução desta análise de impacto orçamentário, sendo eles:  
76  
 a composição da população elegível foi com base na soma do número de usuários de cada medicamento (utilizado por pacientes com diagnóstico de DA). A estimativa para a população total pode estar superestimada, uma vez que possa haver indivíduos que fizeram uso de mais de um medicamento no mesmo ano.  
 a composição da população de grau moderado que faz uso combinado de memantina e um dos AChEIs foi baseado em demanda epidemiológica.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A análise de sensibilidade determinística, para avaliar a variação do custo acumulado nos cinco anos, contou com a variação de alguns parâmetros relacionados a CST. Parâmetros relacionados ao procedimento padrão também foram verificados, porém anulam o resultado de interesse, uma vez que o procedimento padrão está presente em ambas as estratégias. Para os parâmetros custo do acompanhamento/supervisão após o treinamento, número de pacientes por sessão de terapia em grupo e número de grupos atendidos por ano, foi considerado o valor médio como pontual na AIO e os extremos como limite inferior e superior. Enquanto os parâmetros de custo do treinamento presencial para grupo no primeiro ano, dos materiais para uso permanente e sua substituição a partir do 2º ano foram variados em mais ou menos 20% na análise de sensibilidade. Detalhes são apresentados na **Tabela** L.  
**Tabela L** . Parâmetros variados na análise de sensibilidade determinística da avaliação de impacto orçamentário.  
|Parâmetro|Valor<br>pontual|Limite<br>Inferior|Limite<br>Superior|
|---|---|---|---|
|Número de pacientes por sessão de terapia em grupo<sup>a</sup>|7|5|8|
|Número de grupos atendidos por ano a|2|1|3|
|Custo do treinamento presencial para grupo no 1º ano (R$)|12.000,00|9.600,00|14.400,00|
|b<br>Custo do acompanhamento/ supervisão após treinamento|9.000,00|6.000,00|12.000,00|
|(R$)<sup>a</sup>||||
|Custo de materiais para uso permanente (R$)<sup>b</sup>|1.500,00|1.200,00|1.800,00|
|Custo da substituição dos materiais a partir do 2º ano (R$)<br>b|300,00|240,00|360,00|  
**Fonte:** equipe de treinamento CST-Brasil (RJ).  
**Notas** : a - valor médio como pontual e os extremos como limite inferior e superior; b - ±20% do valor pontual como limite inferior e superior.  
Seguindo diretrizes de boas práticas de modelagem<sup>65,66</sup> , foi realizada validação interna dos dados, fazendo análises em duplicata para certificar que todas as equações haviam sido descritas corretamente.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
O resultado da AIO, apresentados na **Tabela** , na **Figura** e na **Figura** , para um horizonte temporal de 5 anos, mostra que a incorporação da CST em grupo, combinada ao tratamento padrão, geraria um incremento de custo, ou seja, um impacto econômico positivo, gerando um total acumulado de R$ 17.228.301,34 em cinco anos. Como no primeiro ano há o investimento do treinamento inicial de profissionais e compra de materiais, o valor incremental é maior do que nos anos seguintes (em que há somente o custo de substituição de materiais), assim, a análise apresentou um custo de R$ 3.264.555,48 no primeiro ano, mas de quase de R$ 1,7 milhões no segundo ano, chegando a cerca de R$ 5,4 milhões no quinto ano de análise.  
**Tabela M.** Resultado da análise de impacto orçamentário para o cenário alternativo 1.  
77  
||**Cenário atual (R$)**|**(R$)**|**Cenário alternativo 1**|<br>**Impacto**<br>**orçamentário (R$)**|
|---|---|---|---|---|
|**Ano 1**<br>~~nn~~<br>~~—Css~~|R$ 138.684.894,24<br>~~SCSC~~|~~SC~~|R$ 141.949.449,72<br>~~SCS~~|R$ 3.264.555,48<br>~~Ci‘is~~|
|**Ano 2**<br><br>|R$ 141.433.161,11<br>||R$ 143.184.952,09<br>|R$ 1.751.790,98<br>|
|**Ano 3**<br>~~nn~~<br>~~T—“C~~|R$ 145.826.155,14<br>~~ssSCS~~|~~S~~|R$ 148.622.519,56<br>~~SCs~~|R$ 2.796.364,42<br>~~‘isis~~|
|**Ano 4**<br><br>|R$ 151.347.203,67<br>||R$ 155.350.979,48<br>|R$ 4.003.775,81<br>|
|**Ano 5**<br>~~nn~~<br>~~T—“C~~|R$ 157.985.092,81<br>~~ssSCS~~|~~S~~|R$ 163.396.907,46<br>~~SCs~~|R$ 5.411.814,66<br>~~‘isis~~|
|**Acumulado**<br>**(5 anos)**<br><br>|R$ 735.276.506,97<br>||R$ 752.504.808,32<br>|R$ 17.228.301,34<br>|  
**Fonte:** elaboração própria.  
<!-- Start of picture text -->
Impacto Orgamentario<br>R$ 150.000.000,00<br>R$ 125.000.000,00<br>R$ 100.000.000,00<br>RS 75.000.000,00<br>R$ 50.000.000,00<br>R$ 25.000.000,00<br>RS 0,00<br>Ano 1 ‘Ano 2 Ano 3 Ano4 Ano S<br>mCenérioAtual m Cendrio Proposto<br><!-- End of picture text -->  
**Figura S.** Comparação entre cenário atual e cenário proposto.  
**Fonte:** elaboração própria.  
<!-- Start of picture text -->
Impacto Orgamentario<br>R$ 150.000.000,00<br>R$ 125.000.000,00<br>R$ 100.000.000,00<br>RS 75.000.000,00<br>RS 50.000.000,00<br>RS 25.000.000,00<br>R$ 0,00 — — _ om<br>Ano 1 Ano 2 Ano 3 Ano 4 ‘Ano 5<br>mCenério Atual__m Impacto orcamentario<br><!-- End of picture text -->  
**Figura T.** Comparação entre cenário atual e impacto orçamentário. **Fonte:** elaboração própria.  
Na análise de sensibilidade determinística, representada pelo gráfico de tornado da **Figura** , os parâmetros com maior implicação no valor do impacto orçamentário acumulado em 5 anos foram: número de grupos atendidos por ano (indiretamente variando de –22,9% a 68,7% do basal), número de pacientes por sessão (indiretamente de -12,5% a 40,0% do basal) e custo do  
78  
treinamento presencial para grupo no primeiro ano (diretamente, sendo ±10,3% do basal). Enquanto os outros parâmetros impactaram diretamente menos de 5% do valor basal.  
<!-- Start of picture text -->
Anilise de Sensibilidade Deterministica<br>‘Acumuladoem S anos<br>Nimaro de pacientes porsesso Es 24.2<br>ste EEE<br>+s1900<br>Custo para uso permanente por um ano MB ts1776<br>Custo dotreinamento presencial para grupo no 18 ano |asaza7<br>Custodo acompanhamento/supervisiopmo  apos RS.17,25,<br>sin Si7a8 was SSD<br>oe<br>inte Siperor nae near<br><!-- End of picture text -->  
**Figura U.** Diagrama de tornado do impacto orçamentário do acumulado em 5 anos.  
**Fonte:** elaboração própria.  
A **Tabela** apresenta o cenário considerando o custo dos medicamentos sem desperdício. O resultado do impacto orçamentário não é diferente do caso basal, pois a diminuição do custo dos medicamentos ocorre no cenário atual e alternativo da mesma forma. Entretanto, o total acumulado de 5 anos nos cenários atual e proposto 1 podem diminuir.  
**Tabela N.** Resultado da análise de impacto orçamentário para o cenário alternativo 1, considerando custo dos medicamentos sem desperdício.  
|||**Cenário atual (R$)**|**Cenário alternativo**<br>**1 (R$)**|<br>**Impacto**<br>**orçamentário (R$)**|
|---|---|---|---|---|
|**Ano 1**||R$ 105.332.806,11|R$ 108.597.361,59|R$ 3.264.555,48|
|**Ano 2**||R$ 106.757.311,61|R$ 108.509.102,59|R$ 1.751.790,98|
|**Ano 3**||R$ 109.797.619,83|R$ 112.593.984,25|R$ 2.796.364,42|
|**Ano 4**||R$ 113.817.844,37|R$ 117.821.620,19|R$ 4.003.775,81|
|**Ano 5**||R$ 118.789.502,81|R$ 124.201.317,46|R$ 5.411.814,66|
|**Acumulado**<br>**anos)**|**(5**|R$ 554.495.084,74|R$ 571.723.386,08|R$ 17.228.301,34|  
**Fonte:** elaboração própria.  
A **Tabela** presenta o cenário considerando a aplicação da CST de manutenção. Este procedimento consiste na repetição das 14 sessões em 7 semanas logo após a aplicação da CST em grupo padrão. A incorporação da tecnologia geraria um incremento no total acumulado de R$ 22.624.051,54 em cinco anos da análise, o que configura 31,3% a mais do caso basal.  
**Tabela O.** Resultado da análise de impacto orçamentário para o cenário alternativo 1, considerando a aplicação da CST de manutenção.  
79  
||**Cenário atual (R$)**|**(R$)**|**Cenário alternativo 1**|**Impacto**<br>**orçamentário (R$)**|
|---|---|---|---|---|
|**Ano 1**|R$ 138.684.894,24||R$ 142.252.957,14|R$ 3.568.062,90|
|**Ano 2**|R$ 141.433.161,11||R$ 143.823.788,19|R$ 2.390.627,08|
|**Ano 3**|R$ 145.826.155,14||R$ 149.642.286,51|R$ 3.816.131,37|
|**Ano 4**|R$ 151.347.203,67||R$ 156.811.060,37|R$ 5.463.856,70|
|**Ano 5**|R$ 157.985.092,81||R$ 165.370.466,30|R$ 7.385.373,49|
|**Acumulado (5**|R$ 735.276.506,97||R$ 757.900.558,52|R$ 22.624.051,54|

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
**Fonte:** elaboração própria.  
Considerando um segundo cenário alternativo de _market share_ agressivo, em que se pressupõe que a CST em grupo em combinação ao tratamento padrão seja indicado para 100% da população elegível já no primeiro ano, a incorporação geraria um incremento de custo de um pouco mais de R$ 16 milhões no primeiro ano, mas cerca de R$ 4,4 milhões a R$ 5,4 milhões nos anos seguintes, gerando um total acumulado de R$ 35.779.396,62 em cinco anos da análise ( **Tabela** ).  
**Tabela P.** Resultado da análise de impacto orçamentário para o cenário alternativo 2.  
||||**Cenário**|**atual**|**Cenário alternativo 2**|**Impacto orçamentário**|
|---|---|---|---|---|---|---|
||||**(R$)**|**(R$)**|**(R$)**||
||**Ano 1**||R$ 138.684.894,24||R$ 155.007.671,62|R$ 16.322.777,38|
||**Ano 2**||R$ 141.433.161,11||R$ 145.812.638,56|R$ 4.379.477,45|
||**Ano 3**||R$ 145.826.155,14||R$ 150.486.762,51|R$ 4.660.607,37|
||**Ano 4**||R$ 151.347.203,67||R$ 156.351.923,44|R$ 5.004.719,77|
||**Ano 5**||R$ 157.985.092,81||R$ 163.396.907,46|R$ 5.411.814,66|
|**anos)**|**Acumulado**|**(5**|R$ 735.276.506,97||R$ 771.055.903,59|R$ 35.779.396,62|  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A CST se trata de um procedimento não invasivo, não medicamentoso, para o tratamento de DA leve a moderada. Em comparação com as demais alternativas disponíveis no SUS para o tratamento de DA, pode ser percebida como altamente aceitável pela perspectiva do paciente, cuidador e profissionais de saúde, visto que foi associada à redução da velocidade do declínio cognitivo. Para cuidadores, há que se reconhecer a necessidade de investir recursos financeiros e de tempo para acompanhamento e deslocamento para os serviços de saúde que oferecerão o procedimento de uma a duas vezes na semana.  
Ainda, do ponto de vista dos profissionais de saúde e gestores, será necessário dispor de espaço físico para realização das sessões de CST e de profissionais para realizarem o treinamento, multiplicar entre os pares e realizar as sessões de CST.  
80  
Portanto, a expectativa é que tanto os profissionais quanto os serviços de saúde percebam a CST como uma alternativa benéfica em adição ao tratamento medicamentoso.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
A CST é administrada em grupo por profissionais de saúde com ensino superior (psicólogos, enfermeiros, terapeuta ocupacional, fisioterapeuta e outros), desde que treinados.  
Assim, quanto à implementação, a modalidade de terapia em grupo é um procedimento clínico, caracterizado como acompanhamento terapêutico já ofertada pelo SUS. Sendo assim, a administração da CST na modalidade em grupo não parece impor restrições quanto a sua implementação e viabilidade técnica e operacional, visto que os serviços de saúde já oferecem terapia em grupo, e estariam preparados para ofertá-los, mediante treinamento dos profissionais. Isso ressalta a praticidade e a adaptabilidade da CST como abordagem terapêutica e sua inserção no contexto de saúde.  
No tocante à viabilidade, as estimativas da avaliação econômica e de impacto orçamentário apontam que a terapia padrão combinada a CST em grupo para pacientes com DA leve a moderada apresenta um benefício clínico superior, embora os custos totais sejam mais elevados em comparação ao tratamento padrão isolado. Assim, embora tenha sido identificado que cada um real gasto com CST resulte em mais saúde para o paciente do que a abordagem atual, o investimento financeiro adicional pode representar um impeditivo orçamentário para o SUS.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Em 04 de outubro de 2023 foram realizadas buscas por “ _CST_ ” ou “ _cognitive stimulation therapy_ ” AND “ _dementia_ ” em agências internacionais, sendo encontrada recomendações apenas no NICE ( _National Institute for Health and Care Excellence_ - Inglaterra)<sup>69</sup> ( **Quadro** **_J_** . Avaliação de Agência internacional de ATS. **Quadro J** ).  
**Quadro J** . Avaliação de Agência internacional de ATS.  
|Instituição|Data<br>da<br>recomendação|Parecer/Recomendação|
|---|---|---|
|NICE (National Institute for<br>Health and Care Excellence)<sup>**69**</sup>|Junho de 2018|A CST é recomendada “para promover cognição,<br>independência e bem-estar” para pessoas com demência<br>leve a moderada.|  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: Geral -->
Segundo a **síntese de evidência** baseada em dez estudos primários e nove revisões sistemáticas, a análise da eficácia da CST combinada ao tratamento padrão em pacientes com DA leve a moderada, demonstrou resultados favoráveis à CST em comparação com o tratamento padrão isolado.  
Considerando os benefícios, a CST combinada ao tratamento padrão demonstrou ser benéfica, evidenciando uma redução clinicamente significativa na velocidade do declínio cognitivo, bem como redução de alterações comportamentais e de sintomas depressivos. Entretanto, ao avaliar os desfechos relacionados a qualidade de vida, atividade de vida diária e sintomas neuropsiquiátricos relacionados a ansiedade não foram observados resultados favoráveis para a CST.  
A **análise de custo-efetividade/utilidade** , para um ano de horizonte temporal, a CST em grupo combinada ao tratamento padrão como opção terapêutica para o tratamento de pacientes com DA leve a moderada está relacionada a um maior benefício clínico e um maior custo total comparado ao tratamento padrão isolado.  
81  
As análises de sensibilidade probabilística indicaram que a intervenção analisada, no primeiro ano de implementação, tem cerca de 42,2% de ser custo-efetiva considerando o valor do limiar de custo-efetividade recomendado pela Conitec e 94,3% se considerado três vezes esse limiar<sup>114</sup> . Ademais, as análises de sensibilidade determinística revelaram que as incertezas acerca dos parâmetros fator de correção de custos e número de grupos atendidos por ano são os que mais impactam na RCEI, porém a intervenção sob investigação permanece custo-efetiva para três vezes o limiar recomendado.  
A avaliação econômica apresenta algumas limitações, especialmente: (a) as probabilidades de transição utilizadas não se referem ao tratamento padrão em geral. Apesar disso, optou-se pela matriz de transição em que o paciente permanece em melhores condições, não beneficiando a intervenção em análise; (b) as evidências para a CST em grupo utilizadas e os custos dos serviços de saúde e outros recursos (excluindo medicamentos) para atendimento ao paciente com DA foram retirados de estudos sobre demência em geral e não somente para DA. Apesar disso, pode-se considerar como parâmetros representativos, uma vez que nesses estudos a maioria dos pacientes são diagnosticados com DA; e (c) escolha de um curto horizonte temporal deve-se ao fato de que as evidências para a CST estão restritas a 1 ano.  
Apesar dessas limitações, identificou-se que a realização da CST em grupo combinada ao tratamento padrão pode ser custo-efetiva, principalmente se for considerado o cenário dos anos seguintes após a sua implementação.  
A **análise de impacto orçamentário** sugere que a incorporação da CST em grupo, associada ao tratamento padrão, para pacientes com DA leve a moderada, em comparação ao tratamento padrão isolado, no SUS, com incrementos de 20% anuais, geraria um total acumulado de cerca de R$ 17,3 milhões em cinco anos. No primeiro ano, o incremento seria maior, de aproximadamente R$ 3,3 milhões, devido ao investimento com o treinamento dos profissionais e compra de materiais, mas para os anos seguintes seria de cerca de R$ 1,7 milhões (no segundo ano) a cerca de R$ 5,4 milhões (no quinto ano).  
Ademais, ao considerar uma difusão dessa tecnologia para 100% dos pacientes elegíveis, nos cinco anos, um total acumulado de aproximadamente R$ 35,8 milhões foi observado.  
A análise de sensibilidade determinística mostrou que a diminuição do número de grupos atendidos por ano geraria um acréscimo de R$ 29.060.852,49 (68,7% do valor basal) no total acumulado em cinco anos de análise.  
Como toda análise baseada em modelos, limitações são esperadas. Em primeiro lugar, algumas limitações apontadas na análise de custo-efetividade também estiveram presentes na análise de impacto orçamentário, sendo assim as principais limitações são: (a) a taxa de difusão para cenário atual e proposto foram baseados em suposições; e (b) está AIO considerou somente a incorporação da nova tecnologia e não o progresso da doença, fato que poderia diminuir no custo incremental.  
Considerando aspectos relacionados à **aceitabilidade, implementação e viabilidade da inclusão** da CST para tratamento da doença de Alzheimer leve a moderada, há potencial ser bem aceita tanto por usuários quanto pela equipe multiprofissional, visto o benefício e impacto da CST no tratamento da DA como favorável. Ademais, não se prevê potenciais barreiras substanciais para implementação e execução da CST. A abordagem não farmacológica, modalidade de intervenção em grupo e a estrutura já existente no contexto de saúde contribuem para a viabilidade da CST. No entanto, é importante considerar fatores adicionais que podem impactar em custos, como o treinamento dos profissionais e as supervisões de acompanhamento, e em materiais utilizados durante as sessões, na tomada de decisão sobre a implementação da CST no sistema de saúde.

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: 1. Equipe de elaboração e partes interessadas -->
Colaboração externa  
O Protocolo foi atualizado pelo UATS do Hospital Alemão Oswaldo Cruz.  
82

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: 1. Equipe de elaboração e partes interessadas -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro K** ).  
Quadro K. Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar f<br>algum dos benefícios abaixo?|inance|iramente|
|---|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|Sim<br>Não|(   )<br>(   )|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|Sim<br>Não|(   )<br>(   )|
|c) Financiamento para redação de artigos ou editorias|Sim<br>Não|(   )<br>(   )|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|Sim<br>Não|(   )<br>(   )|
|e) Recursos ou apoio financeiro para membro da equipe|Sim<br>Não|(   )<br>(   )|
|f) Algum outro benefício financeiro|Sim<br>Não|(   )<br>(   )|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma<br>ser beneficiada ou prejudicada com as recomendações da diretriz?|Sim<br>Não|(   )<br>(   )|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de||(   )|
|marca, royalties) de alguma tecnologia ligada ao tema da diretriz?|Sim<br>Não|(   )|
|4. Você já atuou como perito judicial na área tema da diretriz?|Sim|(   )|  
83  
(   ) Não  
5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetados pela sua atividade na elaboração ou revisão da diretriz?  
|a) Instituição privada com ou sem fins lucrativos|Sim<br>Não|(   )<br>(   )|
|---|---|---|
|b) Organização governamental ou não-governamental|Sim<br>Não|(   )<br>(   )|
|c) Produtor, distribuidor ou detentor de registro|Sim<br>Não|(   )<br>(   )|
|d) Partido político|Sim<br>Não|(   )<br>(   )|
|e) Comitê, sociedade ou grupo de trabalho|Sim<br>Não|(   )<br>(   )|
|f) Outro grupo de interesse|Sim<br>Não|(   )<br>(   )|
|6. Você poderia ter algum tipo de benefício clínico?|Sim<br>Não|(   )<br>(   )|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos||(   )|
|interesses possam ser afetados?|Sim<br>Não|(   )|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer||(   )|
|o que você irá escrever e que deveria ser do conhecimento público?|Sim<br>Não|(   )|  
84  
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado|(|)|
|---|---|---|
|acima, que possa afetar sua objetividade ou imparcialidade?|Sim||
||(<br>Não|)|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos|(|)|
|conflitos listados acima?|Sim||
||(<br>Não|)|

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: 2. Referências -->
1. APA. American Psychiatric Association. Diagnostic and statistical manual of mental disorders: DSM-IV. Vol. 4. Washington: APA.; 1994.  
2.  Folstein MF, Folstein SE, Mchugh PR. “MINI-MENTAL STATE” A PRACTICAL METHOD FOR GRADING THE  
COGNITIVE STATE OF PATIENTS FOR THE CLINICIAN*. Vol. 12, J. gsychiaf. Res. Pergamon Press; 1975.  
3. Morris JC. The Clinical Dementia Rating (CDR). Neurology. 1993 Nov;43(11):2412.2-2412-a.  
4. NICE. National Institute for Health and Care Excellence. Dementia: Assessment, management and support for people living with dementia and their carers (NICE Guideline No. 97). [Internet]. NICE Guidence. 2018 [cited 2023 May 13]. Available from: https://www.nice.org.uk/guidance/ng97  
5. Brasil. Ministério da Saúde. Secretaria de Atenção Primária à Saúde. Departamento de Gestão do Cuidado Integral.  
Relatório nacional sobre a demência: Epidemioligia, (re)conhecimento e projeções futuras [recurso eletrônico]. Brasília: Ministério da Saúde, 2024. Disponível em: http://bvsms.saude.gov.br/bvs/publicacoes/relatorio_nacional_demencia_brasil.pdf  
6. Spector A, Davies S, Woods B, Orrell M. Reality Orientation for Dementia. Gerontologist. 2000 Apr 1;40(2):206–12.  
7. Spector A, Thorgrimsen L, Woods B, Royan L, Davies S, Butterworth M, et al. Efficacy of an evidence-based cognitive  
stimulation therapy programme for people with dementia. British Journal of Psychiatry. 2003 Sep 2;183(3):248–54.  
8. University College London (UCL). International Cognitive Stimulation Therapy (CST) Centre [Internet]. University College London (UCL). 2023 [cited 2023 May 13]. Available from: https://www.ucl.ac.uk/international-cognitive-stimulationtherapy/international-cognitive-stimulation-therapy-cst-centre  
9. Spector A, Thorgrimsen L, Woods B, Royan L, Davies S, Butterworth M, et al. Efficacy of an evidence-based cognitive  
stimulation therapy programme for people with dementia: Randomised controlled trial. British Journal of Psychiatry. 2003 Sep 1;183(SEPT.):248–54.  
10. Orrell M, Aguirre E, Spector A, Hoare Z, Woods RT, Streater A, et al. Maintenance cognitive stimulation therapy for  
dementia: Single-blind, multicentre, pragmatic randomised controlled trial. British Journal of Psychiatry. 2014;204(6):454–61.  
11. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews.  
Syst Rev. 2016 Dec 5;5(1):210.  
12. Higgins JPT, Green S. Cochrane Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration.  
2011;  
85  
13. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017 Sep 21;j4008.  
14. Higgins JPT, Altman DG, Gotzsche PC, Juni P, Moher D, Oxman AD, et al. The Cochrane Collaboration’s tool for  
assessing risk of bias in randomised trials. BMJ. 2011 Oct 18;343(oct18 2):d5928–d5928.  
15. Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: a revised tool for assessing risk  
of bias in randomised trials. BMJ. 2019 Aug 28;l4898.  
16. RStudio Team. RStudio: Integrated Development Environment for R. [Internet]. Boston, MA. . 2015 [cited 2023 May  
18]. Available from: http://www.rstudio.com/  
17. Ministério da Saúde. Diretrizes Metodológicas - Sistema GRADE – manual de graduação da qualidade da  
evidência e força de recomendação para tomada de decisão em saúde. Vol. 33, Assistenza Infermieristica e Ricerca. 2014.  
18. Woods B, Rai HK, Elliott E, Aguirre E, Orrell M, Spector A. Cognitive stimulation to improve cognitive functioning  
in people with dementia. Vol. 2023, Cochrane Database of Systematic Reviews. John Wiley and Sons Ltd; 2023.  
19. Howard R, Phillips P, Johnson T, O’Brien J, Sheehan B, Lindesay J, et al. Determining the minimum clinically  
important differences for outcomes in the DOMINO trial. Int J Geriatr Psychiatry. 2011 Aug;26(8):812–7.  
20. Gómez-Soria I, Iguacel I, Aguilar-Latorre A, Peralta-Marrupe P, Latorre E, Zaldívar JNC, et al. Cognitive stimulation  
and cognitive results in older adults: A systematic review and meta-analysis. Vol. 104, Archives of Gerontology and Geriatrics. Elsevier Ireland Ltd; 2023.  
21. Chen X. Effectiveness of cognitive stimulation therapy (CST) on cognition, quality of life and neuropsychiatric  
symptoms for patients living with dementia: A meta-analysis. Geriatr Nurs (Minneap). 2022 Sep 1;47:201–10.  
22. Saragih ID, Tonapa SI, Saragih IS, Lee BO. Effects of cognitive stimulation therapy for people with dementia: A  
systematic review and meta-analysis of randomized controlled studies. Int J Nurs Stud. 2022 Apr 1;128.  
23. Cafferata RMT, Hicks B, von Bastian CC. Effectiveness of cognitive stimulation for dementia: A systematic review  
and meta-analysis. Psychol Bull. 2021 May 24;147(5):455–76.  
24. Chen J, Duan Y, Li H, Lu L, Liu J, Tang C. Different durations of cognitive stimulation therapy for Alzheimer’s  
disease: A systematic review and meta-analysis. Vol. 14, Clinical Interventions in Aging. Dove Medical Press Ltd.; 2019. p. 1243–54.  
25. Huntley JD, Gould RL, Liu K, Smith M, Howard RJ. Do cognitive interventions improve general cognition in  
dementia? A meta-analysis and meta-regression. BMJ Open. 2015 Apr 2;5(4):e005247–e005247.  
26. Sun Y, Zhang X, Wang Z. Comparative Effectiveness of 3 Settings of Cognitive Stimulation Therapy on Cognition  
and Quality of Life for People With Dementia: A Systematic Review and Network Meta-analysis. Vol. 23, Journal of the American Medical Directors Association. Elsevier Inc.; 2022. p. 461-467.e11.  
27. Duan Y, Lu L, Chen J, Wu C, Liang J, Zheng Y, et al. Psychosocial interventions for Alzheimer’s disease cognitive  
symptoms: a Bayesian network meta-analysis. BMC Geriatr. 2018 Aug 7;18(1).  
28. Carbone E, Gardini S, Pastore M, Piras F, Vincenzi M, Borella E. Cognitive Stimulation Therapy for Older Adults  
with Mild-to-Moderate Dementia in Italy: Effects on Cognitive Functioning, and on Emotional and Neuropsychiatric Symptoms. Journals of Gerontology - Series B Psychological Sciences and Social Sciences. 2021;76(9):1700–10.  
29. Capotosto E, Belacchi C, Gardini S, Faggian S, Piras F, Mantoan V, et al. Cognitive stimulation therapy in the Italian context: its efficacy in cognitive and non-cognitive measures in older adults with dementia. Int J Geriatr Psychiatry. 2017 Mar 1;32(3):331–40.  
30. Cove J, Jacobi N, Donovan H, Orrell M, Stott J, Spector A. Effectiveness of weekly cognitive stimulation therapy for people with dementia and the additional impact of enhancing cognitive stimulation therapy with a carer training program. Clin Interv Aging. 2014 Dec 11;9:2143–50.  
86  
31. Yamanaka K, Kawano Y, Noguchi D, Nakaaki S, Watanabe N, Amano T, et al. Effects of cognitive stimulation therapy Japanese version (CST-J) for people with dementia: A single-blind, controlled clinical trial. Aging Ment Health. 2013;17(5):579–86.  
32. Mapelli D, Di Rosa E, Nocita R, Sava D. Cognitive Stimulation in Patients with Dementia: Randomized Controlled Trial. Dement Geriatr Cogn Dis Extra. 2013 Aug 29;3(1):263–71.  
33. Coen RF, Flynn B, Rigney E, Fitzgerald L, Murray C, Dunleavy C, et al. Efficacy of a cognitive stimulation therapy programme for people with dementia. Vol. 28, Ir J Psych Med. 2011.  
34. Marinho V, Bertrand E, Naylor R, Bomilcar I, Laks J, Spector A, et al. Cognitive stimulation therapy for people with dementia in Brazil (CST-Brasil): Results from a single blind randomized controlled trial. Int J Geriatr Psychiatry. 2021 Feb 1;36(2):286–93.  
35. Lok N, Buldukoglu K, Barcin E. Effects of the cognitive stimulation therapy based on Roy’s adaptation model on Alzheimer’s patients’ cognitive functions, coping-adaptation skills, and quality of life: A randomized controlled trial. Perspect Psychiatr Care. 2020 Jul 1;56(3):581–92.  
36. Niu YX, Tan JP, Guan JQ, Zhang ZQ, Wang LN. Cognitive stimulation therapy in the treatment of neuropsychiatric symptoms in Alzheimer’s disease: A randomized controlled trial. Clin Rehabil. 2010 Dec;24(12):1102–11.  
37. Sun Y, Zhang X, Wang Z. Comparative Effectiveness of 3 Settings of Cognitive Stimulation Therapy on Cognition and Quality of Life for People With Dementia: A Systematic Review and Network Meta-analysis. Vol. 23, Journal of the American Medical Directors Association. Elsevier Inc.; 2022. p. 461-467.e11.  
38. Rosen W, Mohs R, Davis K. A new rating scale for Alzheimer’s disease. American Journal of Psychiatry. 1984  
Nov;141(11):1356–64.  
39. Matsuda O, Nakatani M. Manual for Japanese version of the Neurobehavioral Cognitive Status Examination (COGNISTAT). Matsuda, O., & Nakatani, M. (2004). Manual for Japanese version of the Neurobehavioral Cognitive Status Examination (COGNISTAT). . Tokyo: World Planning. 2004.  
40. Mondini S, Mapelli D, Vestri A, Arcara G, Bisiacchi P. Esame neuropsicologico Breve 2, ENB-2. . Raffaello Cortina  
Editore.; 2011.  
41. Logsdon RG, Gibbons LE, McCurry SM, Teri L. Assessing Quality of Life in Older Adults With Cognitive  
Impairment. Psychosom Med. 2002 May;64(3):510–9.  
42. EuroQol Group. EuroQol - a new facility for the measurement of health-related quality of life. Health Policy (New  
York). 1990 Dec;16(3):199–208.  
43. De Vreese LP, Caffarra P, Savarè R, Cerutti R, Franceschi M, Grossi E. Functional Disability in Early Alzheimer’s Disease – A Validation Study of the Italian Version of the Disability Assessment for Dementia Scale. Dement Geriatr Cogn Disord. 2008;25(2):186–94.  
44. Galasko D, Bennett D, Sano M, Ernesto C, Thomas R, Grundman M, et al. An inventory to assess activities of daily living for clinical trials in Alzheimer’s disease. The Alzheimer’s Disease Cooperative Study. Alzheimer Dis Assoc Disord. 1997;11 Suppl 2:S33-9.  
45. Cummings JL, Mega M, Gray K, Rosenberg-Thompson S, Carusi DA, Gornbein J. The Neuropsychiatric Inventory:  
Comprehensive assessment of psychopathology in dementia. Neurology. 1994 Dec 1;44(12):2308–2308.  
46. Reisberg B, Auer SR, Monteiro IM. Behavioral Pathology in Alzheimer’s Disease (BEHAVE-AD) Rating Scale. Int  
Psychogeriatr. 1997 May 7;8(S3):301–8.  
47. Pattie AH, Gilleard CJ. Clifton assessment procedures for the elderly. British Journal of Clinical Psychology. 1979;  
48. Alexopoulos GS, Abrams RC, Young RC, Shamoian CA. Cornell scale for depression in dementia. Biol Psychiatry.  
1988 Feb;23(3):271–84.  
87  
49. Yesavage JA, Sheikh JI. Geriatric Depression Scale (GDS). Clin Gerontol. 1986 Nov 18;5(1–2):165–73.  
50. SHANKAR KK, WALKER M, FROST D, ORRELL MW. The development of a valid and reliable scale for rating anxiety in dementia (RAID). Aging Ment Health. 1999 Feb;3(1):39–49.  
51. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e  
Tecnologia. Diretrizes metodológicas: Diretriz de Avaliação Econômica. 2. ed. Brasília: Ministério da Saúde; 2014. 132 p.  
52. Husereau D, Drummond M, Augustovski F, de Bekker-Grob E, Briggs AH, Carswell C, et al. Consolidated Health  
Economic Evaluation Reporting Standards 2022 (CHEERS 2022) statement: updated reporting guidance for health economic evaluations. BMC Med [Internet]. 2022 Jan 12;20(1):23. Available from: http://www.pubmedcentral.nih.gov/articlerender.fcgi?artid=PMC8753858  
53. Woods B, Rai HK, Elliott E, Aguirre E, Orrell M, Spector A. Cognitive stimulation to improve cognitive functioning  
in people with dementia. Vol. 2023, Cochrane Database of Systematic Reviews. John Wiley and Sons Ltd; 2023.  
54. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Doença de Alzheimer [Internet]. 2020 [cited 2023 Oct 1]. Available from: https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicose-diretrizes-terapeuticas-pcdt/arquivos/2020/portaria-conjunta-13-pcdt-alzheimer-atualizada-em-20-05-2020.pdf  
55. Neumann PJ, Kuntz KM, Leon J, Araki SS, Hermann RC, Hsu MA, et al. Health Utilities in Alzheimer’s Disease. Med Care [Internet]. 1999 Jan;37(1):27–32. Available from: http://journals.lww.com/00005650-199901000-00005  
56. Brasil. Ministério da Saúde. BPS - Banco de Preços em saúde [Internet]. 2023 [cited 2023 Nov 29]. Available  
from: http://bps.saude.gov.br  
57. Brasil. Ministério da Saúde. Sabeis - Sala Aberta de Inteligência em Saúde [Internet]. 2023 [cited 2023 Sep 28]. Available from: https://sabeis-ats.shinyapps.io/painel/  
58. Ferretti C, Sarti FM, Nitrini R, Ferreira FF, Brucki SMD. An assessment of direct and indirect costs of dementia in Brazil. Larson BA, editor. PLoS One [Internet]. 2018 Mar 1;13(3):e0193209. Available from: https://doi.org/10.1371/journal. pone.0193209  
59. Brasil. Ministério da Saúde. SIGTAP - Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos  
e OPM do SUS [Internet]. 2023 [cited 2023 Oct 1]. Available from: http://sigtap.datasus.gov.br/tabela-  
unificada/app/sec/inicio.jsp  
60. Brasil. Banco Central do Brasil [Internet]. [cited 2023 Nov 29]. Available from: https://www.bcb.gov.br/  
61. Brasil. Instituto Brasileiro de Geografia e Estatística. Inflação [Internet]. [cited 2023 Nov 29]. Available from: https://www.ibge.gov.br/explica/inflacao.php  
62. Yunusa I, Alsahali S, Rane A, Eguale T. Comparative Value of Cholinesterase Inhibitors and Memantine in Persons with Moderate-to-Severe Alzheimer’s Disease in the United States: A Cost-Effectiveness Analysis1. J Alzheimers Dis Rep [Internet]. 2021 Sep 6 [cited 2023 Dec 12];5(1):705–13. Available from: https://doi.org/10.3233/ADR-210307  
63. Higgins J, Thomas J, Chandler J, Cumpston M, Li T, Page M, et al., editors. Cochrane Handbook for Systematic Reviews of Interventions version 6.4 (updated August 2023) [Internet]. Cochrane; 2023. Available from: www.training.cochrane.org/handbook  
64. BRASIL. Ministério da Saúde. O uso de limiares de custo-efetividade nas decisões em saúde: recomendações da comissão nacional de incorporação de tecnologias no SUS [Internet]. Brasília; 2022 [cited 2022 Nov 30]. Available from: https://www.gov.br/conitec/pt-br/midias/pdf/2022/20221106_relatorio-uso-de-limiares-de-custo-efetividade-nas-decisoes-emsaude.pdf  
65. Eddy DM, Hollingworth W, Caro JJ, Tsevat J, McDonald KM, Wong JB, et al. Model transparency and validation: a report of the ISPOR-SMDM Modeling Good Research Practices Task Force--7. Value Health. 2012 Sep;15(6):843–50.  
88  
66. Stout NK, Knudsen AB, Kong CY, McMahon PM, Gazelle GS. Calibration Methods Used in Cancer Simulation Models and Suggested Reporting Guidelines. Pharmacoeconomics. 2009 Jul;27(7):533–45.  
67. Brasil. Ministério da Saúde. O uso de limiares de custo-efetividade nas decisões em saúde: recomendações da comissão nacional de incorporação de tecnologias no SUS [Internet]. Brasília; 2022. Available from: https://www.gov.br/conitec/pt-br/midias/pdf/2022/20221106_relatorio-uso-de-limiares-de-custo-efetividade-nas-decisoes-emsaude.pdf  
68. Brasil. Ministério da Saude. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes Metodológicas: Análise de Impacto Orçamentário: Manual para o Sistema de Saúde do Brasil. Série A: Normas e Manuais Técnicos. 2012.  
69. NICE | The National Institute for Health and Care Excellence [Internet]. [cited 2022 Sep 25]. Available from: https://www.nice.org.uk/  
89

---

<!-- METADADOS: doenca: Doenças de Alzheimer | secao: 2. Referências -->
|**Número**<br>**do**||**Tecnologias avaliadas pela**|**Conitec**|
|---|---|---|---|
|**Relatório da diretriz**|**Principais**|||
|**clínica**<br>**(Conitec)**<br>**ou**<br>**Portaria de Publicação**|<br>**alterações**|**Incorporação ou alteração**<br>**do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório<br>de<br>Recomendação<br>n°<br>1051/2025|Atualização do<br>documento<br>e<br>ampliação do uso de<br>tecnologia|Donepezila (em monoterapia<br>ou combinada a memantina) para o<br>tratamento<br>de<br>pacientes<br>diagnosticados recentemente como<br>grave (CDR=3) em início de terapia<br>e pacientes com indicação de<br>manutenção do tratamento que<br>progridem para CDR=3 [Relatório<br>de Recomendação nº 976/2025;<br>Portaria SECTICS/MS nº 20, de 12<br>de maio de 2025]|- Memantina (solução oral)<br>para o tratamento de pacientes com<br>DA moderada a grave e dificuldade<br>de adesão/ deglutição, [Relatório de<br>Recomendação<br>nº<br>966/2025;<br>Portaria SECTICS/MS nº 24/2025,<br>de 07 de maio de 2025|
|Portaria Conjunta||Rivastigmina<br>via<br>transdérmica<br>(adesivo)<br>para<br>o<br>tratamento<br>de<br>pacientes<br>com<br>demência leve e moderadamente<br>grave do tipo Alzheimer [Relatório|Rivastigmina<br>adesivo<br>transdérmico para o tratamento de<br>demência para Doença de Alzheimer<br>[Relatório de Recomendação nº<br>206/2016; Portaria SCTIE/MS nº|
|SAS-SCTIE/MS nº 13,<br>de 28 de novembro de<br>2017|Atualização do<br>conteúdo|de Recomendação nº 224/2016;<br>Portaria SCTIE/MS nº 31/2016]<br>Memantina para doença de<br>Alzheimer<br>[Relatório<br>de<br>Recomendação<br>nº<br>310/2017;<br>Portaria SCTIE/MS nº 49/2017]|08/2016]<br>Souvenaid para melhora de<br>memória em pacientes com doença<br>de Alzheimer na fase leve [Relatório<br>de Recomendação nº 118/2014;<br>Portaria SCTIE/MS nº 25/2014]|
|Portaria SAS/MS<br>nº 1.298, de 21 de<br>novembro de 2013|Atualização do<br>conteúdo|||
|Portaria SAS/MS<br>nº491, de 23 de setembro<br>de 2010|Atualização do<br>conteúdo|||
|Portaria SAS/MS<br>nº 843, de 31 de outubro<br>de 2002|Primeira versão<br>do documento|||  
90

---

