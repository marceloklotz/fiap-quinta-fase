<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Angioedema associado à deficiência de C1 esterase (C1-INH).

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Considerando a necessidade de se atualizarem parâmetros sobre o angioedema associado à deficiência de C1 esterase (C1-INH) no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação; e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolve:  
Art. 1º  Ficam aprovados, na forma do Anexo, disponível no sítio: <u>www.saude.gov.br/sas, o Protocolo Clínico e Diretrizes Terapêuticas - Angioedema associado à</u> deficiência de C1 esterase (C1-INH).  
Parágrafo único. O Protocolo de que trata este artigo, que contém o conceito geral do angioedema associado à deficiência de C1 esterase (C1-INH), critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do angioedema associado à deficiência de C1 esterase (C1-INH).  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 109/SAS/MS, de 10 de março de 2010, publicada no Diário Oficial da União nº 47, de 11 de março de 2010, seção 1, páginas 62-6.  
FRANCISCO DE ASSIS FIGUEIREDO

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
ANGIOEDEMA HEREDITÁRIO ASSOCIADO À DEFICIÊNCIA DE C1 ESTERASE (C1-INH)

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A revisão da literatura foi realizada com pesquisa nas bases de dados MEDLINE/PubMed e EMBASE usando a estratégia de busca “angioedema, hereditary”[mesh] AND “drug therapy”[mesh] com os limites: tipo de estudo (ensaios clínicos, meta-análises, ensaios clínicos randomizados). Todos os artigos identificados foram revisados, sendo incluídos aqueles que versavam sobre angioedema e sua terapia com danazol.  
Adicionalmente, foi realizada revisão na MEDLINE/PubMed sobre a eficácia e a segurança do uso de agentes antifibrinolíticos no tratamento do angioedema hereditário. A estratégia de busca utilizada foi “angioedema, hereditary”[mesh] AND “antifibrinolytics agents”[mesh], com o limite tipo de estudo (ensaios clínicos, meta-análises, ensaios clínicos randomizados). Todos os artigos identificados foram revisados, sendo incluídos aqueles que versavam sobre angioedema e sua terapia.  
As bibliografias dos artigos incluídos também foram revisadas e artigos não indexados também foram incluídos. Outras fontes consultadas para elaboração deste Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foram livros-texto e o _UpToDate_ versão 17.3.  
<mark>Em 29/02/2016 foi realizada atualização da busca na literatura. Foram incluídos estudos controlados, ensaios clínicos randomizados, revisões sistemáticas e meta-análises avaliando a terapêutica do angioedema hereditário. Na base MEDLINE/PubMed, foi utilizada a estratégia “"Angioedemas, Hereditary"[Mesh]) AND "Therapeutics"[Mesh] Filters: Randomized Controlled Trial, Clinical Trial, Systematic Reviews, Meta-Analysis”, sendo localizados 34 estudos; nenhum foi selecionado para leitura na íntegra.</mark>  
<mark>Na base Embase utilizou-se a estratégia “angioedema:ti AND 'therapy'/exp AND ([cochrane review]/lim OR [systematic review]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND [humans]/lim AND [embase]/lim”, tendo sido localizados 102 estudos; destes, quatro foram selecionados para leitura na íntegra e um foi incluído neste Protocolo.</mark>  
<mark>Também foi realizada busca na biblioteca Cochrane com a estratégia “hereditary angioedema”, não sendo localizado nenhum estudo.</mark>  
<mark>Foi consultado também o</mark> _<mark>UpToDate</mark>_<sup></sup> <mark>versão 19.3.</mark>  
<mark>Foram excluídos estudos avaliando desfechos não clínicos e intervenções não disponíveis no Brasil e incluídos outros artigos de conhecimento dos autores, resultando na inclusão de oito novas referências, bem como de um relatório da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC).</mark>

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Angioedema é o termo utilizado para descrever um edema localizado e autolimitado do tecido submucoso e subcutâneo e que ocorre devido ao aumento temporário da permeabilidade vascular causada pela liberação de mediadores vasoativos. Ele geralmente ocorre como parte da urticária, estando, nesse caso, associado à ocorrência de pápulas.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Quando o angioedema ocorre de forma repetida e sem pápulas, o paciente provavelmente apresenta angioedema hereditário (AEH) ou angioedema adquirido (AEA), sendo este o mais frequente (1).  
O AEH é uma imunodeficiência primária do sistema complemento, com herança autossômica dominante, heterogeneidade de lócus e expressividade variável. A classificação mais atualizada do AEH (1) agrupa os pacientes naqueles com deficiência do inibidor da C1esterase (C1-INH), codificado pelo gene _SERPING1_ (2-11), e naqueles sem deficiência de C1INH (antigo tipo 3). O C1-INH é uma molécula inibidora da calicreína, de bradicinina e de outras serases do plasma; quando deficiente, ocorre aumento dos níveis de bradicinina, nanopeptídeo que tem ação vasodilatadora, ocasionando, em consequência, as manifestações clínicas associadas. O AEH sem deficiência do C1-INH pode ser idiopático ou causado pela presença de mutação em heterozigoze no gene que codifica o fator de coagulação XII. Essa forma de AEH ocorre principalmente no sexo feminino, devido aos níveis elevados de estrogênio.  
A forma mais comum de AEH é aquela associada à deficiência do C1-INH. Ocorre em 80%-85% dos casos, e os níveis plasmáticos do C1-INH usualmente estão reduzidos em 5%-30% do normal. No tipo 2, que corresponde a 15%-20% dos casos, o C1-INH permanece com níveis séricos normais ou mesmo elevados, sendo diagnosticado mediante demonstração de que sua atividade está abaixo de 50% do normal (12). A classificação em tipo 1 e 2, portanto, depende da presença de defeitos quantitativos do C1-INH (tipo 1) ou de defeitos funcionais do C1-INH (tipo 2) (12).  
História familiar positiva fortalece a suspeita diagnóstica de AEH, mas sua ausência não exclui o diagnóstico. Não há estudos de prevalência do AEH no Brasil. Estima-se que 1:10.00050.000 indivíduos sejam afetados pela doença (8).  
O AEH manifesta-se pelo surgimento de edema não pruriginoso, não doloroso e não eritematoso em qualquer parte do corpo, principalmente na face e nas extremidades (2,3), e afeta os sistemas respiratório e gastrointestinal, podendo desencadear edema de glote ou cólicas abdominais, respectivamente. O comprometimento da respiração pode resultar em asfixia e, se não tratado, pode ser responsável pelo óbito em cerca de 25% dos pacientes. Além disso, as cólicas abdominais podem ser interpretadas como abdômen agudo, e muitos pacientes acabam sendo submetidos à laparotomia exploradora desnecessariamente. As crises podem ser espontâneas ou desencadeadas por ansiedade, estresse, pequenos traumas, cirurgias, tratamentos dentários, menstruação ou gravidez (2-5). A suspeita de AEH deve ser considerada em pacientes com crises repetidas de angioedema e de dor abdominal sem quadros de urticária, e em pacientes com história familiar (7).  
O AEA pode ser idiopático (dos tipos histaminérgico e não histaminérgico), ocorrer devido ao uso de inibidores da enzima conversora da angiotensina ou, ainda, ser devido à deficiência não genética do C1-INH (1,5,9). Nessa última situação, a idade de início das manifestações clínicas é geralmente superior à do AEH, sem história familiar, e a metade dos pacientes possui doença hematológica subjacente, tais como gamopatia monoclonal de origem incerta ou neoplasia de células B. O AEA do tipo histaminérgico é a forma mais comum de angioedema, e o seu tratamento envolve anti-histamínicos e corticoides (1).  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Como pode ser uma doença genética, também está indicada a realização de aconselhamento genético.  
Em relação ao tratamento, este Protocolo refere-se somente ao AEH associado à deficiência do C1-INH, uma vez que esta é a única forma que possui tratamento aprovado e evidência que lhe dê suporte. Para as demais formas, existem apenas pequenos estudos não controlados e o uso dos medicamentos é _off label_ (1).  
3 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
**-** D84.1 Defeito no sistema complemento

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O diagnóstico de AEH associado à deficiência do C1-INH (tipos 1 e 2) é obtido pela presença dos seguintes critérios (8-11):  
- Anamnese, exame físico e quadro clínico compatível com AEH; e  
- Evidência bioquímica [constatação laboratorial de ausência ou redução (<50%) ou de defeito funcional do C1-INH (função <50%); de redução do complemento hemolítico total (CH50); e de diminuição da fração C4 do complemento]. Deve-se ressaltar que C4 e CH50 podem encontrar-se normais fora das crises); OU  
- Evidência genética (presença de mutação patogênica em _SERPING1_ ) da doença.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Serão incluídos neste Protocolo os pacientes que apresentarem diagnóstico confirmado de AEH com deficiência de C1-INH conforme critérios especificados no item Diagnóstico.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Serão excluídos deste Protocolo os pacientes que apresentarem pelo menos um dos critérios abaixo (1,13,14):  
- Mulheres com sangramento genital de origem desconhecida;  
- Disfunção grave hepática, renal ou cardíaca;  
- Gravidez ou lactação, devido à possibilidade de ocorrência de efeitos androgênicos no sexo feminino;  
- Porfiria;  
- Hipersensibilidade ou intolerância ao medicamento;  
- Tumor dependente de androgênio (neoplasia de fígado ou de próstata);  
- História de icterícia ou _pruritus gravidarum_ ;  
- Presença ou história de eventos tromboembólicos;  
- Crianças (até 12 anos de idade).

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Os pacientes com AEH não associado à deficiência de C1-INH, assim como crianças até 12 anos de idade, deverão ser considerados casos especiais e encaminhados para acompanhamento em serviços de referência.  
Os pacientes expostos a situações que possam desencadear um evento grave, tais como manipulação da cavidade bucal para cirurgia odontológica ou manobras endoscópicas, devem

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
utilizar o danazol com intuito profilático, conforme orientação constante no item Esquema de Administração (15-26).

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tratamento do AEH com deficiência de C1-INH pode ser subdividido em:  
- a) profilaxia de crises e  
- b) tratamento das crises  
Para a profilaxia das crises já foram avaliados agentes anti-fibrinolíticos (ácido épsilon aminocaproico e ácido tranexâmico, inibidores da plasmina e da ativação do plasminogênio, respectivamente) e andrógenos atenuados, estes com maior eficácia (8-12,15-21).  
Entre os andrógenos atenuados, o mais utilizado é o danazol, dado o maior nível de evidência de benefício. Ensaio clínico duplo-cego com nove pacientes comparou 93 cursos de 28 dias de danazol ou placebo em pacientes com angioedema hereditário. As crises ocorreram em 93,6% dos cursos com placebo contra 2,2% do danazol (p<0,001). Análise do efeito do danazol demonstrou que as crises ocorreram mais tardiamente nos pacientes durante um curso de placebo precedido de um curso de danazol (média de 14 dias contra 9 dias se precedido de placebo; p<0,05). Não houve diferença de efeitos adversos nos dois grupos (cursos) (19). Considerando a magnitude do efeito nesse ensaio clínico, o danazol continua sendo o medicamento de primeira escolha nessa doença para a prevenção de novas crises (2225).  
Os estudos com outros medicamentos além do danazol, inclusive inibidores da plasmina e da ativação do plasminogênio, são metodologicamente limitados (26). A busca realizada não encontrou ensaios clínicos randomizados contra placebo (ou contra danazol) envolvendo o ácido épsilon aminocaproico. Em relação ao ácido tranexâmico, foi localizado um ensaio clínico contra placebo, do tipo cruzado e duplo-cego, com cinco pacientes; efeito benéfico foi observado em três deles. (27). Assim, o danazol permanece como o medicamento mais bem estudado nessa condição clínica, e por isso recomendado neste PCDT como agente profilático das crises de AEH (28).  
O tratamento das crises é predominantemente hospitalar, e não inclui o uso de danazol (8,10). Caso haja risco de asfixia, pode-se utilizar plasma fresco. O icatibanto, um antagonista seletivo do receptor tipo II da bradicinina é comercializado no Brasil para tratamento de crises em maiores de 18 anos. Sua eficácia no tratamento de crises de AEH foi avaliada em três ensaios clínicos (FAST 1, 2 e 3), nos quais foi comparado com placebo (FAST-1 e 3) e com ácido tranexâmico (FAST-2). No estudo FAST-1, indivíduos com crises de gravidade moderada ou alta foram randomizados para receber icatibanto 30 mg por via subcutânea (n=27) ou placebo (n=29). Nesse estudo, não se demonstrou diferença estatisticamente significativa entre os grupos no desfecho primário, definido como o tempo (mediana) até alívio clinicamente relevante do sintoma índice (2,5 _versus_ 4,6 horas com icatibanto e placebo, respectivamente; p=0,14). Oito pacientes tiveram edema de laringe e receberam icatibanto em regime aberto; destes, três usaram medicamento de resgate (concentrado de C1, opioides, antieméticos) dentro de 24 horas após a administração de icatibanto (29).  
No estudo FAST-2, pacientes com sintomas moderados ou graves foram randomizados para icatibanto 30 mg (n=36) ou ácido tranexâmico (n=38) uma vez ao dia por 2 dias consecutivos. O cegamento foi quebrado no caso de desenvolvimento de edema de laringe, de forma que esses casos viessem a receber icatibanto; houve ainda uma extensão aberta em que

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
foi avaliado o retratramento de crises subsequentes com icatibanto. O tempo (mediana) para alívio do sintoma índice foi de 2 horas no grupo icatibanto e 12 horas no grupo controle (p<0,001). Três pacientes tiveram sintomas laríngeos e receberam icatibanto; destes, nenhum usou medicamento de resgate, e um veio a ser intubado. No estudo FAST-1, não foram observados efeitos adversos graves. No estudo FAST-2, 11% dos indivíduos no grupo icatibanto e 3% no grupo controle desenvolveram efeitos adversos graves (29).  
No estudo FAST-3, pacientes foram randomizados para receber icatibanto (n=46) ou placebo (n=47) dentro de 6 ou 12 horas, de acordo com a gravidade dos sintomas. Pacientes com sintomas laríngeos graves (n=5) receberam icatibanto em esquema _open-label._ O desfecho primário, para pacientes com sintomas abdominais ou cutâneos foi o tempo até melhora de 50% da gravidade dos sintomas; para pacientes com sintomas laríngeos, foi o tempo até a redução de 50% da pontuação na escala visual de gravidade dos sintomas. Houve diferença estatisticamente significativa quanto ao desfecho primário entre pacientes com sintomas abdominais/cutâneos que receberam icatibanto e placebo <mark>(2</mark> _<mark>versus</mark>_ <mark>19,8 h, respectivamente; p < 0,001); já em pacientes com sintomas laríngeos não se observou diferença estatisticamente significativa (2,5 e 3,2 h para icatibanto</mark> _<mark>versus</mark>_ <mark>placebo, respectivamente) (30).</mark>  
Críticas aos estudos com icatibanto incluem a falta de comparação com tratamento ativo (plasma) e problemas na apresentação dos dados. Em todos os estudos, foi permitido o uso de medicamentos de resgate, incluindo concentrado de C1; entretanto, o impacto de cointervenções nos resultados não foi devidamente avaliado. Desfechos duros como a necessidade de intubação e tempo de hospitalização também não foram avaliados. Além disso, o delineamento aberto prejudicou a avaliação do efeito para sintomas laríngeos. Dessa forma, o uso do icatibanto não foi recomendado pela Comissão Nacional de Incorporação de Tecnologias (CONITEC) em junho de 2015, após Consulta Pública (http://conitec.gov.br/images/Consultas/Relatorios/2015/Relatorio_IcatibantoAngioedema_C P.pdf) (31) e, sendo assim, não está indicado neste Protocolo.  
8.1 FÁRMACO  
- Danazol: cápsula de 100 e 200 mg

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Danazol: 200 mg, por via oral, divididos em duas administrações diárias, durante o primeiro mês. Após o primeiro mês, a dose deve ser ajustada conforme resposta clínica e laboratorial (ver Monitorização). Dose máxima diária de 600 mg para profilaxia a longo prazo (o uso de doses acima de 200 mg/dia, nesses casos, deve ser considerado somente em casos especiais – item 7 Casos Especiais) (14).  
Nos casos em que o paciente será exposto à situação potencialmente desencadeadora de crise, o danazol deve ser administrado na dose de 400-600 mg/dia nos 5 dias anteriores ao procedimento, e nos 3 dias posteriores ao procedimento (1).

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tratamento deve ser mantido continuadamente. A menor dose do medicamento deve ser estabelecida para o controle dos sintomas clínicos e minimização dos efeitos adversos. Na presença de tumores hepáticos, o tratamento deve ser interrompido.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Redução do número ou da gravidade das manifestações de angioedema.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Após o primeiro mês de tratamento, avaliar a resposta clínica (ausência de evento agudo) e laboratorial (atividade da C1-INH em aproximadamente 50% do valor normal e C4 dentro dos valores normais). Se o resultado inicial for satisfatório, promover a redução da dose do danazol para a menor dose capaz de controlar os sintomas clínicos. Com vistas a reduzir o potencial para efeitos adversos, a menor dose eficaz deve ser a utilizada (32).  
O paciente deve ser acompanhado pela possibilidade de desenvolver adenoma hepático e hipertensão intracraniana benigna (pseudo-tumor cerebral) com o uso prolongado de danazol (33). É controversa a associação entre o uso de danazol e o risco aumentado de aterosclerose (34-36). Estudos de acompanhamento de longo prazo de pacientes em uso de danazol demonstram que o benefício da prevenção de crises é maior em casos mais graves e que a monitorização de efeitos adversos deve ser mandatória (17,18). Farkas et al. (37), em um estudo longitudinal e retrospectivo, avaliaram 92 pacientes com AEH, sendo 46 em uso de danazol (dose diária de manutenção: 33-200 mg/dia) e 46 sem tratamento, por um período mínimo de 4 anos, não sendo encontradas, entre os dois grupos, diferenças clinicamente relevantes nos parâmetros de função e de ultrassonografia hepática. Tais autores sugerem que o desenvolvimento de tumores hepáticos associado ao uso de danazol está associado a doses diárias elevadas desse medicamento (400-800 mg), à falta de monitorização dos pacientes e ao maior tempo de uso do danazol (neste caso, independente da dose), e chamam a atenção para a necessidade de definição da menor dose clinicamente eficaz.  
Efeitos androgênicos, como mudança de voz, acne, aumento de pelos, irregularidade menstrual e acúmulo de gordura, entre outros, devem ser acompanhados.  
Em relação aos efeitos adversos, devem ser avaliados hematócrito, hemoglobina, AST/TGO, ALT/TGP, fosfatase alcalina, colesterol total e frações, triglicerídeos, e realizado exame qualitativo de urina a cada 6 meses (38). A maioria das alterações bioquímicas associadas é dependente de dose e sem repercussão clínica, mas deve ser controlada de forma individualizada, sendo raramente necessária a suspensão do medicamento.  
Inexiste evidência, a longo prazo, de aumento do risco de ocorrência de eventos cardiovasculares ou de complicações ateroscleróticas em pacientes tratados com o danazol. Sugere-se ultrassonografia abdominal anual para visualização hepática, devido ao risco de desenvolvimento de adenoma hepático e carcinoma hepatocelular, complicações raras que tendem a ocorrer após 10 anos do início do tratamento, mesmo com o uso de baixas doses de danazol, e que nem sempre são precedidas por história de doença hepática ou de alteração de testes de função hepática (38,39).  
Em pacientes em uso de danazol e carbamazepina podem ocorrer significantes aumentos dos níveis de carbamazepina com resultante toxicidade. Deve-se evitar o uso de inibidores da enzima conversora de angiotensina (ECA) e estrogênios, por serem potencialmente desencadeadores de crises (1).  
10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR  
Devem ser observados os critérios de inclusão e exclusão de pacientes neste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses do medicamento prescritas e dispensadas e da adequação de uso.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde** -->
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento do Componente Especializado da Assistência Farmacêutica preconizado neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde** -->
1. Cicardi M, Aberer W, Banerji A, Bas M, Bernstein JA, Bork K, et al. Classification, diagnosis, and approach to treatment for angioedema: consensus report from the Hereditary Angioedema International Working Group. Allergy. 2014;69(5):602-16.  
2. Atkinson J. Pathogenesis and clinical manifestations of hereditary angiodema [Internet]. UpToDate; 2008. [acesso em 07 mai 2010]. Disponível em: http://www.uptodate.com patients/content/topic.do?topicKey=~khRaD40Nj4l03q.  
3. Morgan BP, Harris CL. Complement therapeutics; history and current progress. Mol Immunol. 2003;40(2-4):159-70.  
4. Davis AE 3rd. The pathogenesis of hereditary angioedema. Transfus Apher Sci. 2003;29(3):195-203.  
5. Markovic SN, Inwards DJ, Frigas EA, Phyliky RP. Acquired C1 esterase inhibitor deficiency. Ann Intern Med. 2000;132(2):144-50.  
6. Binkley KE, Davis AE 3rd. Estrogen-dependent inherited angioedema. Transfus Apher Sci. 2003;29(3):215-9.  
7. Nzeako UC, Frigas E, Tremaine WJ. Hereditary angioedema: a broad review for clinicians. Arch Intern Med. 2001;161(20):2417-29.  
8. Bork K, Hardt J, Schicketanz KH, Ressel N. Clinical studies of sudden upper airway obstruction in patients with hereditary angioedema due to C1 esterase inhibitor deficiency. Arch Intern Med. 2003;163(10):1229-35.  
9. Kirschfink M, Grumach AS. Deficiências de complemento. In: Grumach AS. Alergia e imunologia na infância e na adolescência. Rio de Janeiro: Atheneu; 2001. p. 497-513.  
10. Cicardi M, Zingale LC, Pappalardo E, Folcioni A, Agostoni A. Autoantibodies and lymphoproliferative diseases in acquired C1-inhibitor deficiencies. Medicine (Baltimore). 2003;82(4):274-81.  
11. Gompels MM, Lock RJ, Unsworth DJ, Johnston SL, Archer CB, Davies SV. Misdiagnosis of hereditary angio-oedema type 1 and type 2. Br J Dermatol. 2003;148(4):719-23.  
12. Atkinson J, Cicardi M, Sheffer A. Diagnosis of hereditary and acquired angioedema (C1 inhibitor disorders). In: Up ToDate, Rose, BD (Ed), Up To Date, Waltham, MA. 2008.  
13. Davis-Lorton M. An update on the diagnosis and management of hereditary angioedema with abnormal C1 inhibitor. J Drugs Dermatol. 2015;14(2):151-7.  
14. Longhurst HJ, Tarzi MD, Ashworth F, Bethune C, Cale C, Dempster J, et al. C1 inhibitor deficiency: 2014 United Kingdom consensus document. Clin Exp Immunol. 2015;180(3):475-83.  
15. Craig TJ. Appraisal of danazol prophylaxis for hereditary angioedema. Allergy Asthma Proc. 2008;29(3):225-31.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde** -->
16. Zuraw BL. Diagnosis and management of hereditary angioedema: an American approach. Transfus Apher Sci. 2003;29(3):239-45.  
17. Bork K, Bygum A, Hardt J. Benefits and risks of danazol in hereditary angioedema: a longterm survey of 118 patients. Ann Allergy Asthma Immunol. 2008;100(2):153-61.  
18. Zuraw BL. Hereditary angiodema: a current state-of-the-art review, IV: short- and longterm treatment of hereditary angioedema: out with the old and in with the new? Ann Allergy Asthma Immunol. 2008;100(1 Suppl 2):S13-8.  
19. Banerji A, Sloane DE, Sheffer AL. Hereditary angioedema: a current state-of-the-art review, V: attenuated androgens for the treatment of hereditary angioedema. Ann Allergy Asthma Immunol. 2008;100(1 Suppl 2):S19-22.  
20. Farkas H, Harmat G, Fust G, Varga L, Visy B. Clinical management of hereditary angiooedema in children. Pediatr Allergy Immunol. 2002;13(3):153-61.  
21. Fay A, Abinun M. Current management of hereditary angio-oedema (C'1 esterase inhibitor deficiency). J Clin Pathol. 2002;55(4):266-70.  
22. Cicardi M, Zingale L. How do we treat patients with hereditary angioedema. Transfus Apher Sci. 2003;29(3):221-7.  
23. Bowen T, Hebert J, Ritchie B, Burnham J, MacSween M, Warrington R. Management of hereditary angioedema: a Canadian approach. Transfus Apher Sci. 2003;29(3):205-14.  
24. Gelfand JA, Sherins RJ, Alling DW, Frank MM. Treatment of hereditary angioedema with danazol. Reversal of clinical and biochemical abnormalities. N Engl J Med. 1976;295(26):1444-8.  
25. DrugDex. Micromedex Healthcare Series – Integrated Index® System [CD-ROM]. Vol. 120. 1974-2004.  
26. Atkinson J. Prevention of attacks in hereditary angiodema. UpToDate; 2009. [acesso em 07 mai 2010]. Disponível em: http://www.uptodate.com/patients/content/topic.do?topicKey=~q4q8ma_ EQaw_FP..  
27. Blohmé G. Treatment of hereditary angioneurotic oedema with tranexamic acid. A random double-blind cross-over study. Acta Med Scand. 1972;192(4):293-8.  
28. Zuraw B, Bingham CO. An overview of angioedema: Clinical features, diagnosis, and management [Internet]. UpToDate; 2014. [acesso em 04 set 2014]. Disponível em: http://www.uptodate.com/contents/an-overview-of-angioedema-clinical-featuresdiagnosis-and-management?source=related_link  
29. Cicardi M, Banerji A, Bracho F, Malbran A, Rosenkranz B, Riedl M, et al. Icatibant, a new bradykinin-receptor antagonist, in hereditary angioedema. N Engl J Med. 2010;363(6):532-41.  
30. Lumry WR, Li HH, Levy RJ, Potter PC, Farkas H, Moldovan D, et al. Randomized placebocontrolled trial of the bradykinin B(2) receptor antagonist icatibant for the treatment of acute attacks of hereditary angioedema: the FAST-3 trial. Ann Allergy Asthma Immunol. 2011;107(6):529-37.  
31. Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Icatibanto para o tratamento da crise aguda moderada ou grave do Angioedema Hereditário. [Internet]. Brasília, DF: Secretaria de Ciência, Tecnologia e Insumos Estratégicos; 2015. [acesso em 29/02/2016]. Disponível em: <u>http://conitec.gov.br/images/Consultas/Relatorios/2015/Relatorio_IcatibantoAngioede ma_CP.pdf</u>  
32. Buyantseva LV, Sardana N, Craig TJ. Update on treatment of hereditary angioedema. Asian Pac J Allergy Immunol. 2012;30(2):89-98.  
33. Wickersham RM, editor. Drug facts and comparisons. St. Louis: Wolters Kluwer Health Inc.; 2007.  
34. Széplaki G, Varga L, Valentin S, Kleiber M, Karádi I, Romics L, et al. Adverse effects of danazol prophylaxis on the lipid profiles of patients with hereditary angioedema. J Allergy Clin Immunol. 2005;115(4):864-9.  
35. Szegedi R, Széplaki G, Varga L, Prohászka Z, Széplaki Z, Karádi I, et al. Long-term danazol prophylaxis does not lead to increased carotid intima-media thickness in hereditary angioedema patients. Atherosclerosis. 2008;198(1):184-91.  
36. Birjmohun RS, Kees Hovingh G, Stroes ES, Hofstra JJ, Dallinga-Thie GM, Meijers JC, et al. Effects of short-term and long-term danazol treatment on lipoproteins, coagulation, and progression of atherosclerosis: two clinical trials in healthy volunteers and patients with hereditary angioedema. Clin Ther. 2008;30(12):2314-23.  
37. Farkas H, Czaller I, Csuka D, Vas A, Valentin S, Varga L, et al. The effect of long-term danazol prophylaxis on liver function in hereditary angioedema-a longitudinal study. Eur J Clin Pharmacol. 2010;66(4):419-26.  
38. Maurer M, Magerl M. Long-term prophylaxis of hereditary angioedema with androgen derivates: a critical appraisal and potential alternatives. J Dtsch Dermatol Ges. 2011;9(2):99-107.  
39. Riedl MA. Critical appraisal of androgen use in hereditary angioedema: a systematic review. Ann Allergy Asthma Immunol. 2015;114(4):281-288.e7.

---

<!-- METADADOS: doenca: Angioedema deficiência C1esterase | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Eu, _____________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento **danazol** , indicado para o tratamento do **angioedema hereditário associado à deficiência de C1-INH** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _____________________________________________________ (nome do médico que prescreve).  
Assim declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- redução do número ou gravidade das manifestações do angioedema.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- não se sabe ao certo os riscos do uso deste medicamento na gravidez; portanto, caso engravide, o médico deverá ser avisado imediatamente;  
- pequenas quantidades do medicamento podem passar para o leite materno; portanto, o uso do danazol durante a amamentação não é indicado;  
- os efeitos adversos já relatados são os seguintes: náusea, vômitos, diarreia, dores de cabeça, nervosismo, desorientação, fraqueza, convulsões, ganho de peso, inchaço, alterações do paladar, aumento da pressão arterial, perda de potássio e insuficiência cardíaca congestiva.  
- o medicamento está contraindicado em casos de hipersensibilidade (alergia) conhecida ao fármaco;  
- o risco da ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido, inclusive em caso de eu desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
<u>( ) Sim ( ) Não</u>  
Local: Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal:  
_____________________________________ Assinatura do paciente ou do responsável legal Médico Responsável: CRM: UF: ___________________________ Assinatura e carimbo do médico Data:____________________

---

