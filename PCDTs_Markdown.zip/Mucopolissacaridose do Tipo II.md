<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICOINDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 11, DE 09 DE JULHO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Mucopolissacaridose do tipo II.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhe confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 4 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Mucopolissacaridose do tipo II no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença; Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 937/2024 e o Relatório de Recomendação nº 940/2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Mucopolissacaridose do tipo II. Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Mucopolissacaridose do tipo II, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizesterapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Mucopolissacaridose do tipo II.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 16, de 24 de maio de 2018, publicada no Diário Oficial da União (DOU) nº 100, de 25 de maio de 2018, seção 1, página 35.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: FERNANDA DE NEGRI -->
1  
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DA MUCOPOLISSACARIDOSE DO TIPO II

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **1. INTRODUÇÃO** -->
A mucopolissacaridose tipo II (MPS II) ou síndrome de Hunter é a única mucopolissacaridose com herança ligada ao cromossomo X recessiva, sendo causada pela atividade deficiente da iduronato-2-sulfatase (IDS). Essa enzima catalisa o primeiro passo da degradação dos glicosaminoglicanos (GAG), sulfato de dermatan e sulfato de heparan. Assim, sua deficiência causa o acúmulo desses GAG nos tecidos e o aumento da sua excreção urinária<sup>1</sup> . O gene _IDS_ , que codifica a enzima IDS, localiza-se na região cromossômica Xq28, abrange 44kb e está estruturado em nove éxons<sup>2</sup> .  
Dado o seu padrão de herança, os pacientes são principalmente do sexo masculino; as mulheres heterozigotas são, geralmente, assintomáticas<sup>3-5</sup> . Ainda assim, há alguns relatos de pacientes do sexo feminino afetadas, mas com fenótipo atenuado<sup>6,7</sup> .  
As manifestações clínicas são heterogêneas e progressivas e, de acordo com a ocorrência de regressão neurológica (caracterizada por perda dos marcos do desenvolvimento neuropsicomotor ou perda de funções neurológicas já adquiridas, confirmada por avaliação formal com neurologista), a doença pode ser classificada em grave ou atenuada<sup>8,9</sup> . No entanto, a MPS II tem sido considerada como um espectro de doenças com envolvimento somático e neurocognitivo, em vez de uma doença com uma delimitação clara entre os dois subtipos previamente definidos<sup>10</sup> . As manifestações comuns incluem fácies típica, obstrução de vias aéreas superiores, regurgitação valvular cardíaca, doença pulmonar restritiva, hepatoesplenomegalia, hérnias, contraturas articulares, irritabilidade, apneia obstrutiva do sono e redução da qualidade de vida. Achados adicionais incluem baixa estatura, macrocefalia com ou sem hidrocefalia comunicante, macroglossia, perda auditiva e síndrome do túnel do carpo<sup>9</sup> . Na forma grave, as manifestações se iniciam até os dois anos de idade, progredindo para sintomas somáticos e deficiência cognitiva durante a infância; a regressão neurológica se consolida, em média, aos 6 anos de idade<sup>8,9</sup> .  
Os pacientes com a forma atenuada apresentam os primeiros sintomas na infância tardia, com progressão da doença somática mais lenta e branda; esses podem vir a apresentar pouca ou nenhuma deficiência cognitiva, não ocorrendo regressão neurológica<sup>8,9</sup> . Não há como predizer, em idade precoce, se o paciente apresentará regressão neurológica, forma grave da doença ou forma atenuada. A expectativa de vida é, em média, de 20 anos em pacientes com a forma grave, mas alguns indivíduos podem sobreviver até a 4ª ou 5ª décadas, caso apresentem forma atenuada<sup>9</sup> .  
Estudos internacionais estimam que a incidência geral de MPS II seja entre 1:77.000 e 1:165.000 nascidos vivos do sexo masculino<sup>11,12</sup> ou entre 1:156.000 e 1:320.000 recém-nascidos vivos (masculino e feminino)<sup>11,12</sup> . Não foram localizados dados sobre a prevalência na população geral. O fenótipo grave, com regressão neurológica, pode ser cerca de duas vezes mais prevalente que a forma atenuada da doença<sup>7</sup> ; estima-se que alguma forma de envolvimento neurológico esteja presente em até 84% dos pacientes<sup>12</sup> . Os dados da Rede MPS Brasil indicam que a MPS II é o tipo de mucopolissacaridose mais frequente no país, com 358 casos entre 1982 e 2019<sup>13</sup> , em torno 10  
2  
pacientes/ano. A incidência mínima da MPS II no Brasil seria estimada, portanto, em 1:140.000 recém-nascidos vivos com 1:106.000 recém-nascidos do sexo masculino<sup>14,15</sup> .  
A chance de um novo filho do sexo masculino, do mesmo casal, apresentar MPS II é de 50%, se a mãe for heterozigota. Em cerca de um terço dos casos sem história familiar, acontece mutação nova, ou seja, a mãe não é heterozigota, com chance virtualmente nula de recorrência familiar<sup>9</sup> . Assim, é importante que a família dos pacientes com MPS II receba adequado aconselhamento genético, por pessoas capacitadas.  
Não há tratamento curativo para a MPS II. A conduta terapêutica nesses pacientes envolve equipe multidisciplinar e inclui intervenções realizadas para amenizar o fenótipo, como cirurgias, ou intervenções específicas, como o transplante de células tronco-hematopoiéticas (TCTH) ou a terapia de reposição enzimática (TRE) intravenosa (IV)<sup>9,16</sup> . As evidências sobre as alternativas terapêuticas, sobre o uso intratecal de TRE e a terapia gênica, são insuficientes para solicitação de registro ou ainda estão em fase de desenvolvimento<sup>9,16-20</sup> . Há um ensaio clínico em andamento sobre o uso de alfapabinafuspe, uma terapia de reposição enzimática capaz de atravessar a barreira hemato-encefálica e potencialmente tratar as manifestações da MPS II no Sistema Nervoso Central e, portanto, o medicamento ainda não possui registro válido no Brasil<sup>21-23</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a nortear o diagnóstico, tratamento e acompanhamento dos pacientes com MPS II no âmbito do Sistema Único de Saúde, incluindo os critérios para uso da terapia de reposição enzimática e do TCTH.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E76.1 Mucopolissacaridose do tipo II.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **3. DIAGNÓSTICO** -->
O diagnóstico de MPS II é realizado pela suspeita clínica, sendo confirmado por marcadores bioquímicos e teste genético. A suspeita deve ocorrer em indivíduos, principalmente do sexo masculino, que apresentem pelo menos um dos seguintes sinais e sintomas relacionados à doença, especialmente se combinados, com início tipicamente entre 18 meses e quatro anos de idade<sup>9,19</sup> :  
- Características faciais sugestivas de doença lisossômica - face de “depósito”;  
- Infecções respiratórias superiores precoces e de repetição, incluindo otite média, excluídas as causas mais  
- frequentes, tipo resfriados comuns;  
- Hérnia inguinal ou umbilical, especialmente se concomitantes e em crianças, excluídas as causas mais  
- frequentes;  
- Hepatoesplenomegalia, excluídas as causas mais frequentes;  
3  
- Alterações esqueléticas ou articulares típicas - disostose múltipla, giba, limitação da amplitude de  
movimento (AM) das articulações, mãos em garra;  
- Síndrome do túnel do carpo em crianças;  
- Achados oculares característicos - papiledema, atrofia óptica e, raramente, opacificação de córnea;  
- História familiar compatível, como: irmão do sexo masculino com MPS II; primo ou tio (sexo masculino),  
pelo lado materno, com MPS II; ou história familiar de MPS compatível com herança ligada ao X recessiva.  
Ressalta-se que os achados clínicos variam conforme a gravidade da doença e, por si só, não são diagnósticos. Assim, é necessária a confirmação por análises bioquímicas ou genéticas<sup>9</sup> .  
A Figura 1 apresenta o fluxograma de diagnóstico e tratamento da MPS II.  
**Figura 1** - Fluxograma de diagnóstico e tratamento da MPS II.  
<!-- Start of picture text -->
‘Suspeita diagnéstica a partir de sinais e sintomas de Mucopolissacaridose tipo Il<br>Aividade da enzima IDS menor que 10% do limite inferior<br>valores de referéncia (em plasma, leucécitos ou fibroblastos)<br>8 dos<br>= E ms ,<br>3 Atividade normal de pelo menos outra sulfatase (medida na siden mptsen<br>2 ‘mesma amostra na qual foi determinada a atividade da IDS) ae<br>a E<br>Presenca de niveis aumentados de GAG totais na urina ou de<br>excreco urindria aumentada de sulfatos de dermatan e heparan<br>Diagnéstico confirmado de MPS II<br>2 ‘Avaliar inicio da TRE com<br>2 oe Avaliar possibilidade |_| idursulfase, se paciente nao<br>Fy= ore de TCTH apresentarexclusdo critgrios de<br><!-- End of picture text -->  
- **3.1. Diagnóstico laboratorial**  
A confirmação do diagnóstico de MPS II envolve métodos bioquímicos e genéticos.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **3.1.1. Atividade da Iduronato-2-sulfatase (IDS)** -->
A redução ou ausência de atividade da IDS em fibroblastos, leucócitos, sangue impregnado em papel-filtro ou plasma sugerem fortemente o diagnóstico de MPS II, mas não são suficientes para confirmação como único teste, devido à possibilidade de ocorrência de deficiência de múltiplas sulfatases, doença genética causada por mutações no gene _SUMF1_ , entre outros. Portanto, é necessário documentar a atividade normal de ao menos uma outra sulfatase como, por exemplo, da arilsulfatase B. A maioria dos pacientes do sexo masculino com MPS II apresentam atividade indetectável da IDS<sup>8,9</sup> .  
A medida da atividade enzimática em gotas de sangue impregnadas em papel-filtro tem a vantagem do transporte e da manipulação do material serem mais fáceis, no entanto, deve-se considerar o método de triagem  
4  
utilizado, devido aos casos de falso-positivos e falso-negativos associados<sup>24-26</sup> . Desta forma, sugere-se que a medida da IDS em papel-filtro seja considerada como triagem e que o diagnóstico seja firmado por análise em leucócitos, plasma ou fibroblastos. A medida da atividade da IDS em vilo coriônico cultivado ou em amniócitos é, rotineiramente, utilizada no diagnóstico pré-natal de MPS II<sup>9</sup> . Como os resultados por vezes diferem entre os laboratórios, é importante que os valores de referência para a atividade da IDS sejam estabelecidos em cada serviço<sup>25</sup> . O diagnóstico de MPS II em indivíduo do sexo feminino é uma situação muito rara<sup>6,7</sup> . O modo mais confiável, tanto para o diagnóstico da doença como para o diagnóstico de heterozigotas, é a análise genética<sup>9</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **3.1.2. Análise de GAG urinários** -->
A análise de GAG urinários pode ser quantitativa, pelo método espectrofotométrico<sup>27</sup> , ou permitir a identificação do tipo de GAG que está sendo excretado em quantidade aumentada na urina, por cromatografia ou eletroforese<sup>27,28</sup> . Na MPS II, ocorre aumento da excreção dos sulfatos de dermatan e de heparan<sup>1,28</sup> , porém nenhum dos dois métodos prediz a enzima lisossômica deficiente, uma vez que não são específicos para as diferentes MPS. No entanto, uma anormalidade detectada por um ou por ambos os métodos sugere a presença provável de algum tipo de MPS e a necessidade de realização de testes adicionais.  
Caso o paciente já esteja em tratamento, a quantificação da GAG também é útil para sua monitorização, uma vez que ocorre diminuição de sua excreção<sup>28,29</sup> . Salienta-se que os GAG não podem ser considerados como marcadores de gravidade da doença<sup>9</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **3.1.3. Teste genético** -->
A análise do gene _IDS_ e a detecção da variante patogênica causadora da doença em um paciente do sexo masculino pode ser útil para obter o diagnóstico molecular preciso, para realizar o diagnóstico genético pré e pósnatal na família e para a detecção de heterozigotas, facilitando o aconselhamento genético individual e familiar<sup>9</sup> . Entretanto, há grande variação genotípica na MPS II, com mais de 600 diferentes variantes já descritas para o gene _IDS_ , sendo cerca de 70% mutações privadas, ou seja, específicas para uma determinada família<sup>19</sup> . Cerca de 82% dos pacientes apresentam mutações de ponto ou pequenas inserções/deleções; 9%, deleções de éxons ou do gene inteiro e 9% rearranjos complexos resultantes, principalmente, da recombinação com o pseudogene _IDSP1_ , localizado 25 kb telomérico ao _IDS_<sup>9</sup> . A taxa de detecção de variantes patogênicas por sequenciamento pelo método Sanger das regiões exônicas e éxon-íntron do gene _IDS_ é de, aproximadamente, 82%<sup>9</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **3.2. Associação genótipo-fenótipo clínico** -->
A maior importância dos estudos que correlacionam genótipo-fenótipo é a tentativa de identificação, em idade precoce, daqueles indivíduos que apresentarão a forma grave da doença. No entanto, este tipo de correlação nem sempre é confiável<sup>9</sup> . Variantes no gene _IDS_ de indivíduos gravemente afetados causam influência significativa na estrutura terciária da proteína IDS, resultando na perda da atividade enzimática, enquanto a maioria das variantes em pacientes com fenótipo atenuado tem a estrutura da proteína afetada parcialmente, com preservação de alguma atividade enzimática residual, causando manifestações clínicas mais leves<sup>9,30</sup> .  
5  
Para algumas variantes, há associação entre genótipo e fenótipo. Por exemplo, a variante c.1122C>T está associada a um fenótipo lentamente progressivo e inteligência normal, mais frequentemente<sup>31</sup> . A variante p.Ser333Leu está associada a fenótipo grave com mais frequência. A deleção total do gene _IDS_ e rearranjos complexos costumam se associar a formas graves<sup>13,31,32</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste PCDT todos os pacientes que apresentarem pelo menos um dos sinais ou sintomas descritos no item “Diagnóstico”, além da confirmação do diagnóstico de MPS II, conforme um dos critérios abaixo relacionados.  
- Atividade da enzima IDS menor que 10% do limite **inferior dos valores de referência** em plasma, leucócitos ou fibroblastos **E** atividade normal de pelo menos outra sulfatase (medida na mesma amostra em que foi determinada a atividade da IDS) **E** presença de níveis aumentados de GAG totais na urina ou de excreção urinária aumentada de sulfatos de dermatan e heparan;  
**OU**  
- Presença de variante reconhecidamente patogênica no gene _IDS_ .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **Para uso de TRE (idursulfase alfa)** -->
Para serem elegíveis à TRE com idursulfase alfa, os pacientes devem apresentar diagnóstico confirmado de MPS II **E** não apresentar regressão neurológica.  
Todos os pacientes com MPS II, incluindo os que não foram transplantados ou os que tiveram falha do procedimento, podem apresentar benefícios por receber TRE, uma vez que ela pode melhorar a hepatomegalia, a mobilidade articular e reduzir a excreção de GAG urinários. Já foi demonstrado que a TRE antes do TCTH é bem tolerada e pode melhorar a condição clínica pré TCTH de alguns pacientes, desde que seu início não atrase a realização do procedimento. Além disso, a TRE não causa nenhuma interferência em relação ao enxerto ou no sucesso do transplante.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **Para o TCTH** -->
Para elegibilidade ao TCTH, o paciente deve ter diagnóstico confirmado de MPS II e observar as regras estabelecidas para transplantes, conforme normas técnicas e operacionais do Sistema Nacional de Transplantes<sup>1,33,34</sup> .  
TCTH pode ser indicado como tratamento para a forma grave com regressão neurológica da MPS II, único tratamento disponível capaz de proporcionar benefícios<sup>9,34</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **Para a TRE com idursulfase alfa** -->
Serão excluídos os pacientes que apresentarem algum dos seguintes critérios:  
6  
- Regressão neurológica, ou seja, perda dos marcos do desenvolvimento neuropsicomotor ou perda de  
- funções neurológicas já adquiridas, confirmada por avaliação formal com neurologista;  
- Condição médica irreversível que implique em sobrevida menor que 6 meses, como resultado da MPS II ou  
- de outra doença associada, acordado entre mais de um especialista;  
- Idade maior que 18 anos e que, após serem informados sobre os potenciais riscos e benefícios associados ao  
- tratamento com idursulfase alfa, recusarem o tratamento;

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **Para o TCTH** -->
Serão excluídos os pacientes para o TCTH alogênico mieloablativo aparentado com doadores homozigotos portadores de mutações patogênicas no gene _IDS_ . A indicação de transplante envolvendo doadores heterozigotos portadores de mutações patogênicas no gene _IDS_ deve ser avaliada caso-a-caso.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6. TRATAMENTO** -->
O atendimento dos pacientes com MPS II envolve equipe multidisciplinar<sup>9,14,33</sup> e tratamento específico com idursulfase alfa<sup>9,33,34</sup> e/ou TCTH<sup>9</sup> .  
Por se tratar de uma doença crônica, progressiva e multissistêmica, frequentemente, requer cuidados por equipe multiprofissional, com fonoaudiólogos, fisioterapeutas, terapeutas ocupacionais, equipe de enfermagem e diferentes especialidades médicas<sup>9,10,19,33,34</sup> .  
É crucial que um profissional médico acompanhe continuamente o paciente, monitorando a evolução da doença, fornecendo orientação à família, encaminhando a especialistas quando necessário e coordenando o atendimento geral do indivíduo.  
Sempre que disponível, o paciente deve ser acompanhado em CR, pois esses serviços possuem uma equipe multidisciplinar integrada de especialistas<sup>31</sup> que assegura o cuidado integral aos pacientes com MPS II, desde o diagnóstico, tratamento e seguimento.  
Além disso, é importante que os pacientes e as famílias sejam orientados sobre sua doença, possíveis complicações e seus os riscos, por meio de relatório escrito. Os pacientes também devem ser orientados a procurar o médico assistente em caso de emergência, que deve ser informado da doença e receber cópia do relatório.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1. Tratamentos das manifestações clínicas** -->
As principais manifestações clínicas da MPS II e suas opções de tratamento de suporte/sintomáticos podem ser encontradas no Quadro 1.  
É importante frisar que nem todos os pacientes apresentarão todas as manifestações citadas, as quais costumam ser mais frequentes e mais graves nos pacientes com a forma grave da doença. Da mesma forma, nem todas as alternativas terapêuticas serão adequadas a todos os pacientes com MPS II.  
7  
**Quadro 1** - Principais manifestações clínicas da MPS II e alternativas terapêuticas de suporte e sintomáticas.  
|**Órgão/sistema**|**Manifestação clínica**|**Avaliação/tratamento**|
|---|---|---|
||Atraso de desenvolvimento<br>neuropsicomotor.|Psicopedagogia, fonoaudiologia,<br>fisioterapia, psicomotricidade.|
|Sistema nervoso<br>central|Hidrocefalia / Hipertensão intracraniana|Derivação ventrículo-peritoneal,<br>Ressonância magnética de crânio,<br>raquimanometria.|
||Crises convulsivas, alterações ciclo sono-<br>vigília, distúrbio do comportamento.|Exame eletroencefalográfico.<br>Medicamentoso, psicológico.|
|||Ressonância magnética de coluna. Estudos|
|Sistema Nervoso|Compressão medular.|neurofisiológicos.|
|Periférico||Cirúrgico, fisioterapia.|
||Síndrome do Túnel do Carpo.|Cirúrgico|
||Acuidade visual diminuída.||
|Olhos|Atrofia do Nervo Óptico.<br>Glaucoma.<br>Retinose pigmentar.|Avaliação oftalmológica.|
||Síndrome da apneia obstrutiva do sono.|Amigdalectomia, adenoidectomia,<br>oxigenoterapia.|
|Vias aéreas||Avaliação pneumológica.|
||Infecções de repetição, hipersecreção|Medicamentoso|
||Doença pulmonar restritiva|Fisioterapia|
|Tecido conjuntivo|Hérnias.|Cirúrgico.|
|Articulações|Dor, contraturas.|Fisioterapia, terapia ocupacional.<br>Medicamentoso.|
|Ossos|Giba toracolombar, geno valgo.|Coletes, cirúrgico.|
|Orlh|Hipoacusia.|Próteses (em casos específicos).|
|eas|Otites de repetição|Medicamentoso, cirúrgico.|
||Diarreia.|Orientação nutricional.|
|Gtittil|Ganho inadequado ou excessivo de peso|Orientação nutricional.|
|asronesna|Distúrbio da deglutição.|Medicamentoso, fonoaudiologia. Cirurgia<br>(gastrostomia).|
|Bucomaxilo|Má oclusão, dentição anômala.|Cirúrgico. Aparelho ortodôntico.|
|Cardiovascular|Valvulopatias, cardiomiopatia, insuficiência<br>cardíaca.|Avaliação cardiológica.<br>Medicamentoso, cirúrgico.|  
8

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.1. Tratamento das manifestações neurológicas** -->
Dependendo da gravidade da doença, as manifestações neurológicas dos pacientes com MPS II podem incluir atraso na obtenção dos marcos do desenvolvimento, comprometimento cognitivo e convulsões<sup>9,19</sup> . Os sinais neurológicos mais comuns são as alterações de comportamento e cognição, mais frequentes na forma progressiva precoce<sup>7,9</sup> .  
As crises convulsivas podem ser tratadas com anticonvulsivantes, usualmente indicados para crises tônicoclônicas e, preferencialmente, iniciar com monoterapia e a menor dose efetiva, conforme orientação do PCDT de Epilepsia vigente<sup>35</sup> .  
Pode ocorrer hidrocefalia comunicante, compressão da medula espinhal e síndrome do túnel do carpo, que podem necessitar de intervenção cirúrgica<sup>9,10,36,37</sup> . A síndrome do túnel do carpo é prevalente e pode ser difícil determinar se a dor é pela compressão do nervo mediano. Sugere-se, assim, estudos de condução a partir de 5 anos de idade<sup>9,10,37</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.2. Tratamento das manifestações oftalmológicas** -->
O envolvimento ocular na MPS II consiste, geralmente, em edema do disco óptico, papiledema, atrofia óptica e degeneração pigmentar da retina. A opacidade da córnea é rara, ainda que lesões de córnea discretas possam ser observadas. O glaucoma, raramente presente, deve ser tratado prontamente se detectado<sup>9,38</sup> .  
O reconhecimento e o tratamento precoce do comprometimento oftalmológico são recomendados e os pacientes devem ser submetidos à avaliação oftalmológica anual, incluindo medida da pressão intraocular<sup>38</sup> . O tratamento das complicações oculares em pacientes com MPS II não difere substancialmente das condutas utilizadas em outros indivíduos, como o uso de lentes corretivas, as quais devem ser prescritas, conforme apropriado<sup>9,38</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.3. Tratamento das manifestações respiratórias** -->
Muitas alterações anatômicas da MPS II contribuem para aumentar a morbidade e mortalidade relacionadas ao comprometimento das vias aéreas<sup>19</sup> . Um dos objetivos do tratamento clínico é melhorar o controle das infecções recorrentes das vias aéreas<sup>10</sup> . Solução salina isotônica nasal ou hipertônica pode ser usada para eliminar crostas e secreções, melhorar a mobilidade dos cílios e reduzir o edema da mucosa<sup>39</sup> . É comum a ocorrência de infecções respiratórias de vias aéreas superiores crônicas e recorrentes com mais de seis episódios ao ano e os pacientes podem se beneficiar da vacina contra _Streptococcus pneumoniae_ e _Haemophilus influenzae_<sup>10</sup> . Antibióticos são utilizados para o tratamento de exacerbações respiratórias de origem bacteriana aguda, como otite média ou amigdalite, em cursos de 10 a 14 dias, de acordo com critérios clínicos. O uso de corticoides sistêmicos por breves períodos pode ajudar a reduzir o edema e a facilitar a drenagem de secreções. Além disso, medicamentos para tratamento da asma, se presente, devem ser administrados conforme a condição clínica e orientação do PCDT de Asma vigente<sup>40</sup> .  
O tratamento inicial para apneia obstrutiva do sono inclui suplementação noturna de oxigênio. A amigdalectomia e adenoidectomia podem ser realizadas, mas o benefício pode ser temporário e parcial, devido ao  
9  
envolvimento progressivo da garganta e da traqueia<sup>9,10</sup> . O papel da fisioterapia respiratória não foi estudado diretamente na MPS II, mas se sabe que a fisioterapia visa a melhorar a função pulmonar, ventilação e biomecânica respiratória na MPS II.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.4. Tratamento das manifestações musculoesqueléticas e ortopédicas** -->
As complicações ortopédicas são comuns em pacientes com MPS II, tais como: baixa estatura, deformidades da coluna, mãos em garra, rigidez e contraturas articulares, que podem causar incapacidade significativa<sup>41</sup> .  As "disostoses múltiplas" são achados radiográficos encontrados em todos os tipos de MPS e se manifestam como um espessamento generalizado da maioria dos ossos longos, particularmente costelas, com centros de ossificação epifisária irregulares em muitas áreas<sup>9</sup> .  
A fisioterapia motora dinâmica pode trazer benefícios aos pacientes e seu objetivo principal é a prevenção de deformidades osteoarticulares e incentivo de mudanças de decúbito, visando a facilitar as atividades de vida diária, melhorar a mobilidade do paciente e sua independência, além de fornecer orientação familiar para promover uma melhor qualidade de vida<sup>41</sup> . No entanto, inexistem estudos que avaliem o papel da fisioterapia motora, especificamente, na MPS II. Programas específicos voltados para a necessidade de cada indivíduo devem ser desenvolvidos. Sugere-se envolver mobilização, treinamento de força e resistência, aprimoramento das habilidades motoras finas para as mãos e treinamento de marcha para articulações dos membros inferiores<sup>34,41</sup> .  
É importante que o paciente possa realizar o treino sozinho, uma vez que sessões de treinamento regulares e curtas de 10 minutos/dia, por exemplo, podem ser mais eficazes do que uma sessão semanal com um fisioterapeuta<sup>33</sup> . Além disso, é importante documentar o progresso do paciente, realizando avaliações basais e periódicas. Antes do início da fisioterapia, recomenda-se avaliar se as manifestações musculoesqueléticas presentes não são de origem neurológica. Deve-se evitar a hiperextensão da cabeça devido ao comprometimento atlantoaxial<sup>41</sup> . A instabilidade desta articulação pode ser avaliada por radiografias de flexão-extensão do pescoço.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.5. Tratamento da dor** -->
Pacientes com MPS II frequentemente apresentam dor, especialmente devido a contraturas articulares e alterações do sistema nervoso periférico<sup>41</sup> . A aplicação de escalas de dor pode auxiliar na avaliação e na instituição de tratamento apropriado<sup>42</sup> . Intervenções medicamentosas e não medicamentosas podem ser utilizadas, de acordo com a intensidade da dor<sup>9,41,42</sup> , conforme PCDT da Dor crônica vigente<sup>43</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.6. Tratamento das manifestações audiológicas** -->
A perda de audição ocorre na quase totalidade dos pacientes e pode contribuir para problemas comportamentais e dificuldades de aprendizado, podendo causar dificuldades sociais semelhantes ao observado em distúrbios do espectro autista<sup>19,44</sup> . Por isso, o uso de aparelhos auditivos é um aspecto importante do controle da doença<sup>44</sup> .  
10  
Também é comum a ocorrência de otite média crônica, podendo ocorrer perda auditiva condutiva. Deste modo, avaliações otológicas e audiológicas devem ser realizadas pelo menos a cada 6 a 12 meses e, no caso de otites, estas devem ser tratadas, conforme necessário<sup>33,44</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.7. Tratamento das manifestações digestivas** -->
O acúmulo de GAG leva ao aumento do fígado e baço em pacientes com MPS II. Sendo assim, distensão abdominal, hérnias umbilicais e hérnias inguinais são comumente observadas nesses pacientes, necessitando avaliação e tratamento específicos<sup>9,19</sup> . Entretanto, disfunção específica hepática e esplênica não costumam ocorrer<sup>19</sup> . Diarreia crônica é frequente nas formas graves da doença e pode necessitar intervenção e orientação nutricional<sup>9,19</sup> .  
A disfagia orofaríngea é bastante prevalente em pacientes com MPS II, mesmo naqueles sem comprometimento neurológico<sup>45</sup> . Essa alteração pode afetar as funções respiratória e nutricional, devendo ser monitoradas<sup>45,46</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.8. Tratamento das manifestações bucomaxilares** -->
O cuidado oral padrão deve ser realizado sempre que necessário e é recomendada avaliação a cada seis meses<sup>47</sup> . Devido à abertura limitada do maxilar, procedimentos odontológicos de rotina podem ser difíceis de serem realizados e, alguns, exigirão anestesia geral, representando riscos particulares em pacientes com MPS II<sup>33,47</sup> .  
Há relatos de erupção dentária atrasada, particularmente com os primeiros molares permanentes<sup>47</sup> . Além disso, recomenda-se acompanhamento fonoterápico, uma vez que os pacientes apresentam comprometimento da deglutição, da mastigação e muitos apresentam respiração bucal<sup>46</sup> .  
Assim, a terapia fonoaudiológica em motricidade orofacial para pacientes com MPS pode aumentar o tônus muscular, mudar padrões funcionais e prevenir desvios no desenvolvimento craniofacial, além de auxiliar na correta orientação dos familiares na presença de dificuldades<sup>46</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.9. Tratamento das manifestações cardíacas** -->
As complicações cardiovasculares estão presentes na maioria dos pacientes e se manifestam em idade precoce<sup>9,48</sup> . As modificações típicas incluem doença valvar afetando as válvulas mitral, aórtica, tricúspide e pulmonar em frequência decrescente, respectivamente, hipertrofia ventricular, hipertensão arterial, arritmias (taquicardia, bradicardia, bloqueio atrioventricular)<sup>33,48</sup> . O envolvimento cardíaco deve ser avaliado no diagnóstico e ser monitorado após, com ecocardiografia, eletrocardiograma e Holter regularmente, se indicado<sup>33</sup> .  
O cuidado do envolvimento cardíaco é essencialmente de suporte, envolvendo identificação e tratamento de pacientes com insuficiência cardíaca congestiva, desenvolvida como resultado da miocardiopatia, geralmente hipertrófica, ou, mais raramente, devido à disfunção valvar grave<sup>10</sup> . Nesse caso, o paciente deve ser tratado com beta-bloqueadores, inibidores da enzima conversora da angiotensina (ECA) ou diuréticos, conforme avaliação clínica e tratamento preconizado para a população geral. Em casos extremos, os pacientes podem ser submetidos à valvoplastia com balão ou reparação/substituição valvar cirúrgica, embora tais procedimentos sejam raros<sup>10</sup> . A  
11  
hipertensão é, geralmente, sub-diagnosticada em pacientes com MPS II e deve ser tratada com medicamentos utilizados para tal condição. As arritmias devem ser tratadas com ablação, medicamentos antiarrítmicos, anticoagulantes e, se necessário, com desfibrilador cardioversor implantável<sup>10</sup> . A profilaxia para endocardite bacteriana é indicada apenas para pacientes com história de endocardite ou prótese valvar<sup>49</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.1.10. Outros aspectos do acompanhamento clínico** -->
Como se trata de uma doença crônica, multissistêmica e progressiva, os pacientes com MPS II e suas famílias requerem, geralmente, apoio psicológico e social considerável a partir do diagnóstico<sup>10</sup> . As associações de pacientes fornecem apoio psicossocial muito importante e a possibilidade de estabelecer vínculos com outros indivíduos afetados, proporcionando troca de experiências e melhor enfrentamento das dificuldades encontradas.  
Deve ser oferecido aconselhamento genético a todas as famílias e aos pacientes, visando fornecer informações sobre heterozigotas, diagnóstico pré-natal e chance de recorrência. A chance de um novo filho do sexo masculino do mesmo casal apresentar MPS II é de 50%, se a mãe for heterozigota<sup>9</sup> . É importante que uma equipe multidisciplinar acompanhe o paciente, com nutricionistas, fonoaudiólogos, psicólogos, fisioterapeutas e dentistas<sup>10,33,34</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.2. Tratamento cirúrgico** -->
Muitos pacientes apresentam infecções respiratórias recorrentes e obstruções de vias aéreas, sendo que a indicação de adenoidectomia e amigdalectomia pode ser apropriada<sup>10</sup> . Entretanto, o bloqueio das vias aéreas nas mucopolissacaridoses é multifatorial e os resultados de adenotonsilectomia variam. Na maioria dos casos, a melhora a médio prazo na qualidade respiratória é percebida. A cirurgia das vias aéreas pode ser complicada pela macroglossia, abertura limitada da boca e instabilidade da coluna cervical. Além disso, existe o risco de compressão medular aguda após a hiperextensão do pescoço<sup>36</sup> .  
Uma alternativa de realização de adenoidectomia quando o acesso pela abertura bucal está comprometido é a cirurgia endoscópica por via nasal<sup>50</sup> . No entanto, à medida que a doença progride, a traqueostomia pode ser necessária<sup>10</sup> . Há evidência que adenoamigdalectomia é efetiva em crianças com MPS II diagnosticadas com apneia obstrutiva do sono leve a moderada, conforme revisão sistemática da Cochrane<sup>51</sup> . A traqueostomia deve ser evitada, sempre que possível, por dificuldades na técnica cirúrgica, endurecimento da traqueia, alterações anatômicas significativas, como pescoço curto, além da alta taxa de complicações pós-operatórias, como traqueíte, pneumonia recorrente e bloqueio da traqueostomia por secreções espessas<sup>52</sup> . A broncoscopia pode ser realizada para uma avaliação mais detalhada das vias aéreas<sup>33</sup> . A deglutição, já prejudicada pela anatomia e pelo comprometimento neurológico, tende a piorar, aumentando o risco de aspiração<sup>53</sup> . Os desafios da gestão de uma traqueostomia nesses pacientes, associados à dificuldade de aceitação pelo paciente e pela família, também devem ser considerados na tomada de decisão.  
Em pacientes com perda auditiva secundária à otite crônica secretora, pode ser discutida a possibilidade de miringotomia e colocação de tubos de ventilação ou o uso de aparelhos auditivos<sup>10,34</sup> . Ambos são efetivos, mas os aparelhos auditivos são preferidos nas crianças com comorbidades significativas<sup>10</sup> .  
12  
Complicações neurológicas, como hidrocefalia comunicante e compressão medular, podem surgir ao longo da evolução da doença<sup>9</sup> . Os sinais clássicos de hipertensão intracraniana geralmente estão ausentes, evoluem de forma insidiosa e os sintomas são difíceis de distinguir de danos primários ao cérebro<sup>10</sup> . Alterações comportamentais, como agitação ou hipoatividade, podem ser sinais de hipertensão intracraniana<sup>54</sup> . Pode ser difícil a diferenciação entre hidrocefalia e atrofia cerebral e, sendo assim, a combinação de estudos de imagem e raquimanometria para medida de pressão liquórica pode fornecer um diagnóstico mais confiável<sup>54</sup> .  
Em pacientes com hidrocefalia comunicante ou evidência de aumento ventricular progressivo, a derivação ventriculoperitoneal pode ser eficaz em reduzir a pressão intracraniana<sup>36,54</sup> . Embora pouco se saiba sobre como modificar a progressão da doença, há relatos de melhora motora, de sintomas como dor de cabeça ou do comportamento do sono, após a colocação da derivação<sup>36</sup> . Devido ao mecanismo particular da hipertensão intracraniana nas mucopolissacaridoses, recomenda-se utilizar válvulas de alta pressão, no intuito de evitar síndrome de hiperdrenagem<sup>54</sup> .  
Uma característica comum da MPS II é a compressão progressiva da medula espinhal, que resulta em mielopatia cervical e pode levar a atividade reduzida, dificuldade para sentar-se, paresias e espasticidades, dor ou perda de sensibilidade na parte superior e inferior do corpo, bem como disfunção vesical e intestinal<sup>10,36</sup> . O dano medular pode ser irreversível se não tratado. Recomenda-se, então, considerar a descompressão cirúrgica quando ocorrem os sintomas e o diagnóstico é confirmado<sup>10,36</sup> .  
Em pacientes com síndrome do túnel do carpo, a descompressão cirúrgica do nervo mediano é indicada<sup>9,37</sup> . Nos pacientes com MPS II, a articulação do quadril pode apresentar o acetábulo muito raso, ocorrendo o achatamento da cabeça do fêmur, levando à osteoartrite e à redução da mobilidade. Assim, os pacientes podem necessitar de artroplastia do quadril com colocação de prótese<sup>33</sup> . Como se trata de um procedimento de grande porte, os riscos, benefícios e a expectativa de vida do paciente devem ser considerados. As hérnias inguinais e umbilicais são comuns entre os pacientes com MPS II e, em muitos deles, a história de reparo de uma hérnia pode anteceder o diagnóstico da doença<sup>9,33</sup> .  
O risco anestésico em muitos desses pacientes é elevado por características próprias da doença, como pescoço curto e obstrução das vias aéreas superiores. Sempre que possível, as cirurgias devem ser realizadas em CR com experiência no cuidado de pacientes com MPS, sendo fundamental a presença de anestesista com habilidade em intubação difícil para a realização dos procedimentos, pois a necessidade de acompanhar a intubação com fibroscópio é frequente. As máscaras laríngeas podem ser usadas para a viabilização das vias aéreas por períodos curtos ou para facilitar a intubação de fibra óptica<sup>55</sup> . A extubação também apresenta risco importante, como edema pulmonar pós-operatório e edema das vias aéreas superiores. Além disso, alguns pacientes podem não conseguir manter a via aérea após a extubação, resultando na necessidade de reintubação urgente ou traqueostomia<sup>10,55</sup> . Como a extubação precoce pode reduzir esse risco<sup>55</sup> , a anestesia local ou regional deve ser considerada, sempre que possível<sup>10</sup> .  
13

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.3. Tratamento com TCTH** -->
Para elegibilidade ao TCTH, o paciente deve ter diagnóstico de MPS II e observar normas técnicas do Sistema Nacional de Transplantes. A utilização das fontes de células-tronco hematopoéticas, de medula óssea, de sangue periférico ou de sangue de cordão umbilical, deve considerar os riscos para o doador e os riscos e benefícios para o receptor<sup>1,5,30,36</sup> .  
O TCTH alogênico mieloablativo, aparentado (preferencialmente com doadores homozigotos normais, ou seja, não portadores de variantes patogênicas no gene _IDS_ ) e o não aparentado, parecem ter risco de morbimortalidade progressivamente menor com o passar dos anos e alguns efeitos positivos na MPS II.  
A indicação de transplante envolvendo doadoras heterozigotas portadoras de variantes patogênicas no gene _IDS_ deve ser avaliada caso-a-caso.  
O TCTH pode ser indicado como tratamento para a forma grave com regressão neurológica da MPS II, uma vez que ele é o único tratamento atualmente disponível, potencialmente capaz de proporcionar benefícios em termos neurológicos, quando critérios rígidos de seleção são respeitados. Assim, o TCTH alogênico pode ser indicado em idade precoce, preferencialmente, até 3 anos de idade<sup>9,33</sup> .  
Para a autorização do TCTH alogênico aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes. Os resultados de todos os casos de MPS tipo II submetidos a TCTH mieloablativo halogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical deverão ter sua evolução registrada no REREME a cada três meses até completar pelo menos um ano da realização do transplante.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.4. Tratamento medicamentoso** -->
A idursulfase alfa é uma forma recombinante da IDS produzida por técnicas de engenharia genética utilizando a linhagem celular derivada de fibrossarcoma (HT-1080) que produz uma proteína glicosilada análoga à IDS humana nativa<sup>29</sup> . Segundo avaliações, a TRE pode reduzir a hepatoesplenomegalia e a excreção de GAG urinários e melhorar a capacidade funcional<sup>29,56</sup> .  
Segundo revisão sistemática com meta-análise<sup>57</sup> , há efeitos positivos na distância percorrida no Teste da Caminhada de 6 minutos (TC6M) e na capacidade vital forçada (CVF), embora ambos sejam considerados clinicamente não significativos. A maioria dos estudos não incluiu pacientes com regressão neurológica, que é o fenótipo grave e, ainda, a idade ótima para o início da TRE é desconhecida. Sugere-se que o início precoce, nos primeiros meses de vida, tenha benefício adicional<sup>57</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.4.1. Medicamento** -->
- Idursulfase alfa: 2 mg/mL solução injetável.  
14

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.4.2. Esquema de administração** -->
A dose de idursulfase alfa é de 0,5 mg/kg de peso corporal administrado uma vez por semana por infusão intravenosa (IV). A solução deve ser diluída em 100 mL de cloreto de sódio a 0,9% e administrada durante 1 a 3 horas.  
Deve ser feita em ambiente hospitalar ou ambulatorial, sob vigilância de um médico ou outro profissional de saúde em ambiente dotado de infraestrutura necessária ao manejo clínico relacionado às intercorrências. Infusões domiciliares podem ser consideradas após 6 meses de tratamento, caso não tenham ocorrido intercorrências.  
Recomenda-se o uso de um dispositivo de infusão com um filtro de 0,2 μm<sup>58</sup> . A taxa de infusão inicial deve ser 8 mL/hora nos primeiros 15 minutos e, se bem tolerado, pode ser aumentada em 8 mL/hora a cada 15 minutos, até uma taxa máxima de 100 mL/h. Se a taxa for reduzida, o tempo de infusão não deve exceder 8 horas, uma vez que o medicamento não possui conservantes<sup>59</sup> . A administração de medicamentos antitérmicos e anti-histamínicos antes das infusões não deve ser considerada como recomendação padrão, sendo utilizada somente para prevenção de recorrência de reações à infusão<sup>60</sup> .  
O uso de idursulfase alfa administrada por infusão IV na dose de 0,5 mg/kg quinzenalmente é relatada em alguns centros e é considerada prescrição _off label,_ não aprovada no registro do medicamento<sup>60</sup> . O estudo de Muenzer et al. (2006)<sup>29</sup> considerou os desfechos em pacientes utilizando a dose de 0,5 mg/kg semanalmente, a dose de 0,5 mg/kg quinzenalmente e placebo e identificou uma taxa de melhora estatisticamente significante no TC6M quando comparou pacientes que utilizaram a dose semanal e o placebo (44,3  12,3 metros versus 7,3  9,5 metros; P=0,0131). Já com a dose quinzenal, apesar de pequena melhora, não houve significância estatística (30,3  10,3 metros versus 7,3  9,5 metros; P=0,0732). Ainda, os resultados referentes à CVF absoluta foram estatisticamente superiores no tratamento com idursulfase semanal quando comparado ao grupo placebo (0,22  0,05 litros versus 0,06  0,03 litros; P=0.0011); e entre o grupo da idursulfase quinzenal e o grupo placebo (0,07  0,03 litros versus 0,06  0,03 litros; P=0,0176). No entanto, quando comparado a intervenção da idursulfase com o placebo, houve melhora no escore composto pela distância percorrida no TC6M e a previsão da porcentagem da CVF, tanto na intervenção com idursulfase semanal (escore diferença do tratamento= 18,96  6,47; P=0,0049) quanto quinzenal (escore diferença do tratamento = 12,86  6,17; P=0,0416)<sup>29</sup> . Não há estudos comparando de forma direta o uso semanal e quinzenal da enzima. Sendo assim, a mudança de dose e esquema posológico não está preconizado neste PCDT, visto que não foram identificadas evidências sobre eficácia, efetividade ou segurança de esquemas posológicos de administração quinzenal<sup>60</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.4.3. Eventos adversos** -->
Os eventos adversos relatados, na maioria dos casos, são leves e facilmente tratáveis, apesar de frequentes, tanto relacionado à infusão quanto ao tratamento em si. Os eventos adversos graves com risco de vida, que ocorreram durante a TRE, estavam dentro do esperado para a história natural da MPS II e não foram relacionados ao medicamento<sup>20,29,61–63</sup> .  
15  
Os eventos adversos relacionados à infusão são frequentes, mas podem ser atenuados com medicamentos, conforme o caso. Os eventos mais comuns foram cefaleia, febre, reações cutâneas, como urticária e eritema<sup>60–63</sup> , vômitos<sup>63</sup> , dispneia, dor abdominal e síncope vasovagal<sup>62</sup> .  
Em relação ao desenvolvimento de anticorpos IgG anti-idursulfase alfa, sabe-se que ocorrem em 50% a 60% dos pacientes<sup>29,58,63-66</sup> e em 67,9% dos pacientes pediátricos incidem em pelo menos uma ocasião<sup>64</sup> . Apesar da alta prevalência de anticorpos entre os pacientes tratados, a sua presença não parece reduzir o efeito do tratamento de forma clinicamente significativa<sup>58,67</sup> . Quando houver reação mediada por IgE à infusão, deve ser discutida a possibilidade do uso de protocolos que promovam a tolerabilidade<sup>66</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.4.4. Critérios de interrupção** -->
O tempo de tratamento não é pré-determinado, mas devido às características da doença e à ausência de tratamento específico alternativo, deve ser mantido por toda a vida do paciente. Para fins deste PCDT, recomendase que a TRE seja interrompida nas seguintes situações<sup>34</sup> :  
1) Desenvolvimento de regressão neurológica com perda de funções adquiridas, durante a vigência do tratamento;  
2) Ausência de benefício clínico associado ao tratamento, considerando o período de 12 meses após o início das infusões. A presença de pelo menos um dos itens a seguir é evidência de benefício clínico:  
a) redução da excreção urinária de GAG, em pelo menos 50%;  
b) qualquer redução da hepatomegalia por quaisquer dos métodos utilizados para aferição da mesma (exame físico, ecografia abdominal ou ressonância abdominal);  
c) qualquer redução da esplenomegalia por quaisquer dos métodos utilizados para aferição da mesma (exame físico, ecografia abdominal ou ressonância abdominal);  
d) melhora da qualidade de vida, aferida por questionários validados.  
3) Falta de adesão ao tratamento, ou seja, pacientes que não apresentarem pelo menos 50% de adesão ao número de infusões previstas em um ano; ou ao número de consultas previstas em um ano; ou ao número de avaliações previstas em um ano com o médico responsável pelo seguimento do paciente; desde que previamente inseridos, sem sucesso, em programa específico para melhora de adesão, ou seja, pacientes que mesmo após o programa não comparecerem a pelo menos 50% do número de infusões, consultas ou de avaliações previstas em um ano.  
4) Pacientes que apresentarem hipersensibilidade ou reação adversa grave (choque anafilático, risco de óbito) com o uso da idursulfase alfa, que não podem ser controlados com segurança utilizando medidas terapêuticas e preventivas apropriadas.  
5) Pacientes que desenvolverem condição irreversível que implique em morte iminente, cujo prognóstico não se alterará devido ao uso da TRE, como resultado da MPS II ou de outra doença associada, em acordo entre mais de um especialista.  
6) Pacientes com idade > 18 anos e que, após devidamente informados sobre os riscos e benefícios de sua decisão, optarem por não mais se submeterem ao tratamento com TRE IV com idursulfase alfa.  
16  
Os critérios de interrupção do tratamento devem ser apresentados, de forma clara, aos pais/paciente ou aos responsáveis quando a TRE estiver sendo considerada e antes de iniciá-la. Durante o acompanhamento clínico do paciente em TRE, os parâmetros de resposta terapêutica deverão ser avaliados periodicamente e discutidos com os pais/paciente ou responsáveis. No caso de interrupção por falha de adesão, o paciente e familiares deverão ser inseridos em programa de incentivo à adesão e poderão retornar ao tratamento, caso haja comprometimento explícito de seguimento das recomendações médicas.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **6.5. Tratamento em populações específicas** -->
A idursulfase alfa é considerada um medicamento classe C para uso na gestação e aleitamento. Foi excretada no leite de ratas lactantes em uma concentração 4 a 5 vezes maior do que no plasma, mas não se sabe se é excretada no leite humano<sup>68</sup> . Ainda, como a doença é ligada ao X e recessiva, as mulheres são, geralmente, assintomáticas e não há relatos na literatura de pacientes femininas tratadas com idursulfase alfa, até o momento. Sendo assim, o uso da TRE com idursulfase alfa em mulheres grávidas ou que estejam amamentando não é recomendado<sup>68</sup> .  
Não foram encontradas evidências na literatura sobre o efeito na espermatogênese em pacientes tratados com idursulfase alfa. Contudo, o uso do medicamento não apresentou efeito na fertilidade nem na reprodutibilidade de ratos do sexo masculino<sup>68</sup> .

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **7. MONITORAMENTO** -->
Os pacientes devem ser monitorizados para a resposta terapêutica e os eventos adversos. O médico deve realizar anamnese completa em cada visita e coletar dados de altura, em pé ou decúbito dorsal ou por segmento, em caso de restrições nos membros inferiores, peso e perímetro cefálico, de preferência usando o mesmo instrumento devidamente calibrado. O exame físico deve ser completo e incluir sinais vitais (temperatura, frequência cardíaca, frequência respiratória e pressão arterial), bem como medidas para quantificação do tamanho do fígado por hepatimetria e do baço. A avaliação do desenvolvimento sexual deve ser realizada em adolescentes, de acordo com os critérios de Tanner<sup>10,34</sup> .  
Nas visitas, dados sobre todas as avaliações realizadas desde o último agendamento devem ser obtidos e os testes necessários devem ser solicitados, incluindo avaliação por especialistas em neurologia, otorrinolaringologia, oftalmologia, cardiologia e pneumologia; um estudo do sono; e avaliação de volumes viscerais com RNM, TC ou, quando o paciente não for capaz de passar por esses exames, com ecografia<sup>10,34</sup> .  
Para fins de diagnóstico e acompanhamento, radiografias do crânio de perfil, de coluna vertebral de perfil, incluindo região cervical, tórax póstero-anterior, coxofemoral póstero-anterior e ambas as mãos devem ser realizadas<sup>10,34</sup> . Exposição excessiva à radiação deve ser evitada. As avaliações de rotina devem ser realizadas anualmente pelo pediatra ou clínico, além de ginecologista para adolescentes e mulheres adultas, com vacinas seguindo o calendário vacinal brasileiro, orientação dietética, exames e informações preventivas.  
17  
O médico assistente sempre deve solicitar informações sobre ou avaliar, periodicamente, outros membros afetados da família, além de avaliar se a família tem uma boa compreensão da doença e riscos reprodutivos, fornecendo ou encaminhando para orientação e aconselhamento genético adicionais, quando aplicável.  
Pacientes com MPS também devem ser monitorados por outros profissionais como dentistas, fisioterapeutas, fonoaudiólogos, terapeutas ocupacionais, nutricionistas e psicólogos<sup>10,33,34</sup> . É papel do médico transmitir a estes profissionais informações pertinentes, discutir os riscos e benefícios das intervenções e incentivar a família a seguir corretamente as terapias. O médico também é responsável, juntamente com o assistente social, por identificar as dificuldades encontradas pelas famílias e deve procurar ajudá-los, orientando-os nas avaliações e tratamento, atividades de vida diária, atividades escolares e inserção social do paciente e sua família. O Apêndice 2 apresenta as avaliações consideradas mínimas para o acompanhamento de pacientes com MPS II. São definidos períodos mínimos apenas para aquelas avaliações que têm por objetivo detectar a eficácia e segurança da TRE; para as demais, a periodicidade de avaliações fica a critério do médico assistente.  
O seguimento de pacientes submetidos a TCTH deve seguir a conduta adotada pelo centro transplantador.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste PCDT, a duração e o monitoramento dos tratamentos clínico e de reabilitação necessários, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
O tratamento da MPS II deve ser feito por equipe em serviços especializados ou de referência em doenças raras, para fins de diagnóstico e de acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige experiência e familiaridade com manifestações clínicas associadas, convém que o médico responsável tenha experiência e seja treinado nessa atividade. Cabe destacar que, sempre que possível, o atendimento da pessoa com MPS II deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Para a administração dos medicamentos é essencial o atendimento centralizado, para maior racionalidade do uso e avaliação da efetividade. A infusão deve ser feita em ambiente hospitalar ou ambulatorial sob vigilância de um médico ou outro profissional da saúde, devido ao risco de reações durante a infusão. Infusões domiciliares podem ser consideradas após 6 meses de tratamento sem intercorrências.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
Os Estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normas vigentes.  
18  
Para a autorização do TCTH alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Os resultados de todos os casos MPS II submetidos a TCTH mieloablativo alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, deverão ter sua evolução registrada no REREME a cada três meses até completar pelo menos um ano da realização do transplante.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras.  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno, redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da Atenção Primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil e as associações beneficentes e voluntárias são o lócus da atenção à saúde dos pacientes com doenças raras. Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
• Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
19  
• Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS e, se houver necessidade, o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade, e a linha de cuidados de pacientes com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Pacientes com suspeita de deficiência intelectual devem ser encaminhados, preferencialmente, a um serviço especializado ou de referência em doenças raras para seu adequado diagnóstico.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **10. REFERÊNCIAS** -->
1. Neufeld EF MJ. The Mucopolysaccharidoses. In: Scriver CR, editor. The Metabolic & Molecular Bases of Inherited Disease. New York; Montreal: McGraw-Hill; 2010.  
2. D'Avanzo F, Rigon L, Zanetti A, Tomanin R. Mucopolysaccharidosis Type II: One Hundred Years of Research, Diagnosis, and Treatment. Int J Mol Sci. 2020 Feb 13;21(4):1258.  
3. de Camargo Pinto LL, Maluf SW, Leistner-Segal S, Zimmer da Silva C, Brusius-Facchin A, Burin MG, et al. Are MPS II heterozygotes actually asymptomatic? A study based on clinical and biochemical data, Xinactivation analysis and imaging evaluations. Am J Med Genet A. 2011;155A: 50–57.  
4. Schwartz IVD, Pinto LLC, Breda G, Lima L, Ribeiro MG, Mota JG, et al. Clinical and biochemical studies in mucopolysaccharidosis type II carriers. J Inherit Metab Dis. 2009;32: 732–738.  
20  
5. Schwartz IVD, Ribeiro MG, Mota JG, Toralles MBP, Correia P, Horovitz D, et al. A clinical study of 77 patients with mucopolysaccharidosis type II. ActaPaediatr. 2007;96: 63–70.  
6. Tuschl K, Gal A, Paschke E, Kircher S, Bodamer OA (2005) Mucopolysaccharidosis type II in females: case report and review of literature. Pediatr Neurol 32:270–272.  
7. Wraith JE, Scarpa M, Beck M, et al. Mucopolysaccharidosis type II (Hunter syndrome): a clinical review and recommendations for treatment in the era of enzyme replacement therapy. Eur J Pediatr, 2008;167(3):267-277.  
8. Martin R, Beck M, Eng C, Giugliani R, Harmatz P, Muñoz V, et al. Recognition and diagnosis of mucopolysaccharidosis II (Hunter syndrome). Pediatrics. 2008;121: e377–86.  
9. Scarpa M. Mucopolysaccharidosis Type II. 2007 Nov 6 [Updated 2018 Oct 4]. In: Adam MP, Mirzaa GM, Pagon RA, et al., editors. GeneReviews® [Internet]. Seattle (WA): University of Washington, Seattle; 1993-2023.  
10. Scarpa M, Almássy Z, Beck M, Bodamer O, Bruce IA, De Meirleir L, et al. Mucopolysaccharidosis type II: European recommendations for the diagnosis and multidisciplinary management of a rare disease. Orphanet J Rare Dis. 2011;6: 72.  
11. Nelson J, Crowhurst J, Carey B, Greed L. Incidence of the mucopolysaccharidoses in Western Australia. Am J Med Genet A. 2003;123A: 310–313.  
12. Baehner F, Schmiedeskamp C, Krummenauer F, Miebach E, Bajbouj M, Whybra C, et al. Cumulative incidence rates of the mucopolysaccharidoses in Germany. J Inherit Metab Dis. 2005;28: 1011–1017.  
13. Josahkian JA, Trapp FB, Burin MG, Michelin-Tirelli K, Magalhães APPS, Sebastião FM, Bender F, Mari JF, Brusius-Facchin AC, Leistner-Segal S, Málaga DR, Giugliani R. Updated birth prevalence and relative frequency of mucopolysaccharidoses across Brazilian regions. Genet Mol Biol. 2021 Jan 27;44(1):e20200138.  
14. Wraith JE, Beck M, Giugliani R, Clarke J, Martin R, Muenzer J, et al. Initial report from the Hunter Outcome Survey. Genet Med. 2008;10: 508–516.  
15. Giugliani R, Federhen A, Michelin-Tirelli K, Riegel M, Burin M. Relative frequency and estimated minimal frequency of Lysosomal Storage Diseases in Brazil: Report from a Reference Laboratory. Genet Mol Biol. 2017;40: 31–39.  
16. Schwartz IV, Souza CFM de, Giugliani R. Treatment of inborn errors of metabolism. J Pediatr. 2008;84: S8–19.  
17. Motas S, Haurigot V, Garcia M, Marcó S, Ribera A, Roca C, et al. CNS-directed gene therapy for the treatment of neurologic and somatic mucopolysaccharidosis type II (Hunter syndrome). JCI Insight. 2016;1: e86696.  
18. Muenzer J, Hendriksz CJ, Fan Z, Vijayaraghavan S, Perry V, Santra S, et al. A phase I/II study of intrathecal idursulfase-IT in children with severe mucopolysaccharidosis II. Genet Med. 2016;18: 73–81.  
21  
19. Mohamed S, He QQ, Singh AA, Ferro V. Mucopolysaccharidosis type II (Hunter syndrome): Clinical and biochemical aspects of the disease and approaches to its diagnosis and treatment. Adv Carbohydr Chem Biochem. 2020;77:71-117.  
20. Muenzer J, Burton BK, Harmatz P, Gutiérrez-Solana LG, Ruiz-Garcia M, Jones SA, Guffon N, InbarFeigenberg M, Bratkovic D, Hale M, Wu Y, Yee KS, Whiteman DAH, Alexanderian D; SHP609-302 study group. Long-term open-label extension study of the safety and efficacy of intrathecal idursulfase-IT in patients with neuronopathic mucopolysaccharidosis II. Mol Genet Metab. 2022 Sep-Oct;137(1-2):92103.  
21. Giugliani <mark>R, Martins AM, So S, Yamamoto T, Yamaoka M, Ikeda T, Tanizawa K, Sonoda H, Schmidt M, Sato Y. Iduronate-2-sulfatase fused with anti-hTfR antibody, pabinafusp alfa, for MPS-II: A phase 2 trial in Brazil. Mol Ther. 2021 Jul 7;29(7):2378-2386.</mark>  
22. <mark>Okuyama T, Eto Y, Sakai N, Nakamura K, Yamamoto T, Yamaoka M, Ikeda T, So S, Tanizawa K, Sonoda H, Sato Y. A Phase 2/3 Trial of Pabinafusp Alfa, IDS Fused with Anti-Human Transferrin Receptor Antibody, Targeting Neurodegeneration in MPS-II. Mol Ther. 2021 Feb 3;29(2):671-679.</mark>  
23. <mark>Falavigna M, Migliavaca CB, Tanaka E, Santos M. Innovative mechanisms of pre-marketing authorization access for rare diseases in Brazil: a case study of pabinafusp-alfa for mucopolysaccharidosis type II. J Bras Econ Saude. 2023;15(1):67-70.</mark>  
24. Cobos PN, Steglich C, Santer R, Lukacs Z, Gal A. Dried blood spots allow targeted screening to diagnose mucopolysaccharidosis and mucolipidosis. JIMD Rep. 2015;15: 123–132.  
25. Rezende MM, Müller KB, Pereira VG, D’Almeida V. Brazilian reference values for MPS II screening in 12 dried blood spots--a fluorimetric assay. ClinBiochem. 2014;47: 1297–1299.  
26. de Jong JG, Hasselman JJ, van Landeghem AA, Vader HL, Wevers RA. The spot test is not a reliable screening procedure for mucopolysaccharidoses. Clin Chem. 1991;37: 572–575.  
27. Auray-Blais C, Lavoie P, Tomatsu S, Valayannopoulos V, Mitchell JJ, Raiman J, et al. UPLC-MS/MS detection of disaccharides derived from glycosaminoglycans as biomarkers of mucopolysaccharidoses. Anal ChimActa. 2016;936: 139–148.  
28. PLC-MS/MS detection of disaccharides derived from glycosaminoglycans as biomarkers of mucopolysaccharidoses. Anal ChimActa. 2016;936: 139–148.  
29. Muenzer J, Wraith JE, Beck M, Giugliani R, Harmatz P, Eng CM, et al. A phase II/III clinical study of enzyme replacement therapy with idursulfase in mucopolysaccharidosis II (Hunter syndrome). Genet Med. 2006;8: 465–473.  
30. Froissart R, Da Silva IM, Maire I. Mucopolysaccharidosis type II: an update on mutation spectrum. ActaPaediatr. 2007;96: 71–77.  
31. Kato T, Kato Z, Kuratsubo I, Tanaka N, Ishigami T, Kajihara JI, Sukegawa-Hayasaka K, Orii K, Isogai K, Fukao T, Shimozawa N, Orii T, Kondo N, Suzuki Y. Mutational and structural analysis of Japanese patients with mucopolysaccharidosis type II. J Hum Genet. 2005;50(8):395-402.  
22  
32. Brusius-Facchin AC, Schwartz IVD, Zimmer C, Ribeiro MG, Acosta AX, Horovitz D, et al. Mucopolysaccharidosis type II: identification of 30 novel mutations among Latin American patients. Mol Genet Metab. 2014;111: 133–138.  
33. Muenzer J, Beck M, Eng CM, Escolar ML, Giugliani R, Guffon NH, Harmatz P, Kamin W, Kampmann C, Koseoglu ST, Link B, Martin RA, Molter DW, Muñoz Rojas MV, Ogilvie JW, Parini R, Ramaswami U, Scarpa M, Schwartz IV, Wood RE, Wraith E. Multidisciplinary management of Hunter syndrome. Pediatrics. 2009;124:e1228–39.  
34. Giugliani R, Villarreal MLS, Valdez CAA, Hawilou AM, Guelbert N, Garzón LNC, et al. Guidelines for diagnosis and treatment of Hunter Syndrome for clinicians in Latin America. Genet Mol Biol. 2014;37: 315–329.  
35. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Epilepsia. Portaria Conjunta SAS/SCTIE/MS nº 17, de 21 de junho de 2018. Acesso em 28 nov 2023. Disponível em: <u>https://www.gov.br/conitec/pt-br/midias/protocolos/pcdt_epilepisia_2019.pdf</u>  
36. Ballenger CE, Swift TR, Leshner RT, El Gammal TA, McDonald TF. Myelopathy in mucopolysaccharidosis type II (Hunter syndrome). Ann Neurol. 1980;7: 382–385.  
37. Haddad FS, Jones DH, Vellodi A, Kane N, Pitt MC. Carpal tunnel syndrome in the mucopolysaccharidoses and mucolipidoses. J Bone Joint Surg Br. 1997;79: 576–582.  
38. Ashworth JL, Biswas S, Wraith E, Lloyd IC. Mucopolysaccharidoses and the eye. Surv Ophthalmol. 2006;51:1–17.  
39. Principi N, Esposito S. Nasal Irrigation: An Imprecisely Defined Medical Procedure. Int J Environ Res Public Health. 2017;14. doi:10.3390/ijerph14050516.  
40. Brasil. Ministério da Saúde. Protocolos Clínicos e Diretrizes Terapêuticas da Asma.  Portaria SAES/SECTICS/MS nº 32, de 20 de dezembro de 2023. Acesso em 29 dez 2023. Disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/portaria/2023/portaria-conjunta-saes-sectics-no-32-pcdt-</u>

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: <u>asma.pdf</u> -->
41. Link B, de Camargo Pinto LL, Giugliani R, Wraith JE, Guffon N, Eich E, et al. Orthopedic manifestations in patients with mucopolysaccharidosis type II (Hunter syndrome) enrolled in the Hunter Outcome Survey. OrthopRev . 2010;2: e16.  
42. Raluy-Callado M, Chen WH, Whiteman DA, Fang J, Wiklund I. The impact of Hunter syndrome (mucopolysaccharidosis type II) on health-related quality of life. Orphanet J Rare Dis. 2013;8:101.  
43. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica. Portaria SAES/SAPS/SECTICS/MS nº 1, de 22 de agosto de 2024. Acesso em 11 out 2024. Disponível em: <u>https://www.gov.br/conitec/pt-br/midias/protocolos/dorcronica-1.pdf</u>  
44. Keilmann A, Nakarat T, Bruce IA, Molter D, Malm G; HOS Investigators. Hearing loss in patients with mucopolysaccharidosis II: data from HOS - the Hunter Outcome Survey. J Inherit Metab Dis. 2012 Mar;35(2):343-53.  
23  
45. Carneiro L, Souza CFM, Giugliani R, Fagondes SC. Oropharyngeal Dysphagia in Mucopolysaccharidoses: Evidence from Videofluoroscopic Swallowing Study. J inborn errors metab screen. 2022;10:e20220004.  
46. Turra GS, Schwartz IV. Evaluation of orofacial motricity in patients with mucopolysaccharidosis: a crosssectional study. J Pediatr 2009;85(3):254-260.  
47. Ríos AV, Llorensi M. Manifestaciones bucales de pacientes con mucopolisacaridosis. Revista de la Asociación Odontológica Argentina, 109(1), 34-40. Epub 15 de abril de 2021.  
48. Kampmann C, Beck M, Morin I, Loehr JP. Prevalence and characterization of cardiac involvement in Hunter syndrome. J Pediatr. 2011;159: 327–31.e2.  
49. Wilson W, Taubert KA, Gewitz M, Lockhart PB, Baddour LM, Levison M, et al. Prevention of infective endocarditis: guidelines from the American Heart Association: a guideline from the American Heart Association Rheumatic Fever, Endocarditis, and Kawasaki Disease Committee, Council on Cardiovascular Disease in the Young, and the Council on Clinical Cardiology, Council on Cardiovascular Surgery and Anesthesia, and the Quality of Care and Outcomes Research Interdisciplinary Working Group. Circulation. 2007;116:1736-1754.  
50. D’Ascanio L, Manzini M. Safe and rapid approach to the deviated nasal septum in children. Laryngoscope. 2009;119: 2000–2003.  
51. Venekamp RP, Hearne BJ, Chandrasekharan D, Blackshaw H, Lim J, Schilder AGM. Tonsillectomy or adenotonsillectomy versus non-surgical management for obstructive sleep-disordered breathing in children. Cochrane Database of Systematic Reviews. 2015.  
52. Jeong H-S, Cho D-Y, Ahn KM, Jin D-K. Complications of tracheotomy in patients with mucopolysaccharidoses type II (Hunter syndrome). Int J PediatrOtorhinolaryngol. 2006;70: 1765–1769.  
53. Fraga JC, Souza JCK de, Kruel J. Pediatrictracheostomy. J Pediatr .2009;85: 97–103.  
54. Dalla Corte A, Corte AD, de Souza CFM, Anés M, Giugliani R. Hydrocephalus and mucopolysaccharidoses: what do we know and what do we not know? Childs Nerv Syst. 2017;33: 1073– 1080.  
55. Clark BM, Sprung J, Weingarten TN, Warner ME. Anesthesia for patients with mucopolysaccharidoses: Comprehensive review of the literature with emphasis on airway management. Bosn J Basic Med Sci. 2018. Feb 20;18(1):1-7.  
56. da Silva EM, Strufaldi MW, Andriolo RB, Silva LA. Enzyme replacement therapy with idursulfase for mucopolysaccharidosis type II (Hunter syndrome). Cochrane Database Syst Rev. 2016 Feb 5;2(2):CD008185.  
57. Alegra T, Eizerik DP, de Cerqueira CCS, Pereira TV, Dornelles AD, Schwartz IVD. [Efficacy and safety of idursulfase therapy in patients with mucopolysaccharidosis type II with and without comparison to placebo: systematic review and meta-analysis]. CadSaude Publica. 2013;29 Suppl 1: S45–58.  
58. Pano A, Barbier AJ, Bielefeld B, Whiteman DAH, Amato DA. Immunogenicity of idursulfase and clinical outcomes in very young patients (16 months to 7.5 years) with mucopolysaccharidosis II (Hunter syndrome). Orphanet J RareDis. 2015;10: 50.  
24  
59. Sweetman S. Idursulfase. Martindale: The Complete Drug Reference. 2009. p. 2324.  
60. Elaprase: Idursulfase. In: Bulário Eletrônico ANVISA [Internet]. Acesso em 27 ago 2023. Disponível em: https://consultas.anvisa.gov.br/#/medicamentos/25351779252202068/  
61. Muenzer J, Gucsavas-Calikoglu M, McCandless SE, Schuetz TJ, Kimura A. A phase I/II clinical trial of enzyme replacement therapy in mucopolysaccharidosis II (Hunter syndrome). Mol Genet Metab. 2007;90: 329–337.  
62. Okuyama T, Tanaka A, Suzuki Y, Ida H, Tanaka T, Cox GF, et al. Japan Elaprase Treatment (JET) study: idursulfase enzyme replacement therapy in adult patients with attenuated Hunter syndrome (Mucopolysaccharidosis II, MPS II). Mol Genet Metab. 2010;99: 18–25.  
63. Muenzer J, Beck M, Eng CM, Giugliani R, Harmatz P, Martin R, et al. Long-term, open-labeled extension study of idursulfase in the treatment of Hunter syndrome. Genet Med. 2011;13: 95–101.  
64. Giugliani R, Hwu W-L, Tylki-Szymanska A, Whiteman DAH, Pano A. A multicenter, open-label study evaluating safety and clinical outcomes in children (1.4-7.5 years) with Hunter syndrome receiving idursulfase enzyme replacement therapy. Genet Med. 2014;16: 435–441.  
65. Kim J, Park MR, Kim DS, Lee JO, Maeng SH, Cho SY, et al. IgE-mediated anaphylaxis and allergic reactions to idursulfase in patients with Hunter syndrome. Allergy. 2013;68: 796–802.  
66. Giugliani R, Harmatz P, Jones SA, Mendelsohn NJ, Vellodi A, Qiu Y, et al. Evaluation of impact of antiidursulfase antibodies during long-term idursulfase enzyme replacement therapy in mucopolysaccharidosis II patients. Mol Genet Metab Rep. 2017;12: 2–7.  
67. Barbier AJ, Bielefeld B, Whiteman DAH, Natarajan M, Pano A, Amato DA. The relationship between anti-idursulfase antibody status and safety and efficacy outcomes in attenuated mucopolysaccharidosis II patients aged 5 years and older treated with intravenous idursulfase. Mol Genet Metab. 2013;110: 303–310.  
68. Drugs and Lactation Database (LactMed®) [Internet]. Bethesda (MD): National Institute of Child Health and Human Development; 2006. Idursulfase. Atualizado em 21/06/2021. Disponível em: https://www.ncbi.nlm.nih.gov/books/NBK500606/.  
25

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **IDURSULFASE ALFA** -->
Eu, ______________________________________________________________________________ (nome do paciente), declaro ter sido informado claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **idursulfase alfa** , indicada para o tratamento da **mucopolissacaridose tipo II (MPS II)** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a)________  
_______________________________________________________________________________________ (nome do(a) médico(a) que prescreve). Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Melhora dos sintomas da doença, como hepatomegalia e rigidez articular. Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Desenvolvimento de regressão neurológica (perda de funções adquiridas) durante a vigência do tratamento,  
- uma vez que não há benefício comprovado da TRE nos pacientes que já possuem regressão neurológica; - O uso da TRE com idursulfase alfa em mulheres grávidas ou que estejam amamentando não é  
- recomendado; - Os eventos adversos da idursulfase alfa relacionados à infusão mais comuns são dores de cabeça, febre,  
- reações na pele (urticária e eritema);  
- Contraindicação em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula. Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim (    ) Não Meu tratamento constará do seguinte medicamento: (    ) Idursulfase alfa  
26  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:    CRM:    UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontra o medicamento preconizado neste Protocolo.  
27

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **1. Escopo e finalidade do Protocolo** -->
A atualização do PCDT da Mucopolissacaridose tipo II (MPS II)<sup>1</sup> foi uma demanda que cumpre o Decreto nº 7.508 de 28 de junho de 2011. O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do PCDT MPS II<sup>1</sup> , contendo a descrição dos aspectos metodológicos, tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
A proposta inicial de atualização do PCDT da MPS II foi inicialmente discutida durante a reunião de préescopo, ocorrida em 03 de outubro de 2022. A reunião teve a presença de metodologistas e especialista do grupo elaborador, e representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS) e da Secretaria de Atenção Especializada em Saúde (SAES).  
Posteriormente, o escopo do documento foi discutido em reunião, ocorrida em 10 de abril de 2023. A reunião teve a presença de metodologistas e especialista do grupo elaborador, representantes da SECTICS, SAES e de especialistas externos convidados.  
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME)<sup>2</sup> e o sítio eletrônico da Conitec para a identificação das tecnologias terapêuticas disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da MPS II. Não foram encontradas tecnologias disponíveis já incorporadas para o tratamento da MPS II, além da idursulfase alfa e TCTH.  
Adicionalmente não foram identificadas novas tecnologias diagnósticas e terapêuticas a serem priorizadas nesse PCDT. As buscas de evidências foram realizadas em bases de dados com data a partir da publicação do PCDT vigente e contemplaram o atendimento às necessidades sinalizadas pelos especialistas durante a reunião de escopo. Dentre elas destaca-se: a citação da terapia de reposição enzimática quinzenal (realizada de forma _off label_ ), dados sobre o TCTH e a revisão da frequência da realização da dosagem de glicosaminoglicanos urinários.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **2. Equipe de elaboração e partes interessadas** -->
Colaboração externa  
O Protocolo foi atualizado pelo NATS Nuclimed do Hospital das Clínicas de Porto Alegre.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro A).  
28  
**Quadro A** - Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiram<br>benefícios abaixo?|ente algum dos|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser<br>beneficiada ou prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca,<br>royalties) de alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses pos<br>pela sua atividade na elaboração ou revisão da diretriz?|sam ser afetados|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|  
29  
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser<br>afetados?|(   ) Sim<br>(   ) Não|
|---|---|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá|(   ) Sim|
|escrever e que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que|(   ) Sim|
|possa afetar sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos|(   ) Sim|
|listados acima?|(   ) Não|

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Mucopolissacaridose tipo II foi apresentada na 117ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em julho de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 19ª Reunião Extraordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **Consulta pública** -->
A Consulta Pública nº 52/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Mucopolissacaridose tipo II, foi realizada entre os dias 26/08/2024 e 16/09/2024. Foram recebidas 17 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2024/contribuicao-da-cp-52-de-2024-pcdt-da-mucopolissacaridose-tipo-ii.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **3. Busca da evidência e recomendações** -->
Por se tratar de atualização do PCDT da MPS II<sup>1</sup> , o trabalho envolveu a revisão das recomendações já publicadas e a busca de novos artigos publicados para o cuidado dos pacientes com MPS II. Optou-se por definir uma data de início para as buscas, baseada na data de busca de publicações do PCDT publicado por meio da Portaria Conjunta SAS/SCTIE/MS nº 16/2018. Assim, em relação às diretrizes clínicas para a MPS II as bases de dados foram pesquisadas de janeiro de 2018 até a data de 20 de novembro de 2023 (data final da busca).  
Foi também realizada, em 20 de novembro de 2023, busca por estudos clínicos, ensaios clínicos randomizados, meta-análises, revisões sistemáticas, diretrizes clínicas e a busca está detalhada no Quadro B.  
30  
**Quadro B** - Estratégias de busca, de acordo com a base de dados  
|**Bases de dados**|**Estratégia de busca**|**Número de resultados**<br>**encontrados**|
|---|---|---|
|Medline (via<br>Pubmed)|(("Mucopolysaccharidosis II"[MeSH Terms]) OR ("MPS<br>II") OR ("Mucopolysaccharidosis II")) Filters: Clinical<br>Trial, Guideline, Meta-Analysis, Randomized Controlled<br>Trial, Systematic Review|12 artigos|
|Embase|('mucopolysaccharidosis ii'/exp OR<br>'mucopolysaccharidosis ii' OR<br>(('mucopolysaccharidosis'/exp OR<br>mucopolysaccharidosis) AND ii)) AND ([cochrane<br>review]/lim OR [systematic review]/lim OR [meta-<br>analysis]/lim OR [controlled clinical trial]/lim OR<br>[randomized controlled trial]/lim) AND [01-01-2018]/sd<br>NOT [21-11-2023]/sd|31 artigos|
|Cochrane library|Mucopolysaccharidosis II in Title Abstract Keyword|0 Cochrane Reviews|  
Nota: Realizadas entre 01 de janeiro de 2018 e 20 de novembro de 2023. Também foram consultadas manualmente as seguintes bases específicas de diretrizes clínicas:  
- NICE guidelines (http://www.nice.org.uk/guidance/published?type=CG);  
- National Library of Australia (http://webarchive.nla.gov.au/gov/);  
- Diretrizes Associação Médica Brasileira (AMB).  
Foram localizados 43 artigos em duas bases de dados. Excluindo as 9 duplicatas restaram 34 artigos; sendo que apenas três<sup>3-5</sup> foram selecionados para leitura na íntegra e incorporados a este relatório, abordando especialmente tópicos sobre a terapia de reposição enzimática, seus benefícios e possíveis efeitos adversos.  
Adicionalmente, outros 16 artigos<sup>6-21</sup> foram identificados por busca manual/consultada a(s) base(s) PubMed e Embase e incluídos artigos de conhecimento dos autores. Tais artigos visaram responder aos questionamentos sobre manifestações clínicas específicas, diagnóstico e abordagem terapêutica da mucopolissacaridose tipo II.

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **3. Busca da evidência e recomendações** -->
1. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Mucopolissacaridose tipo II. Portaria SAS/SCTIE/MS nº 16, de 24 de maio de 2018. Acesso em 28 nov 2023. Disponível em: <u>https://www.gov.br/saude/pt-br/assuntos/pcdt/arquivos/2018/pcdt_mps-ii.pdf</u>  
31  
2. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde. Departamento de Assistência Farmacêutica e Insumos Estratégicos. Relação Nacional de Medicamentos Essenciais Rename 2022 [recurso eletrônico] / Ministério da Saúde, Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde, Departamento de Assistência Farmacêutica e Insumos Estratégicos. – Brasília: Ministério da Saúde, 2022.  
3. Muenzer J, Burton BK, Harmatz P, Gutiérrez-Solana LG, Ruiz-Garcia M, Jones SA, Guffon N, InbarFeigenberg M, Bratkovic D, Hale M, Wu Y, Yee KS, Whiteman DAH, Alexanderian D; SHP609-302 study group. Long-term open-label extension study of the safety and efficacy of intrathecal idursulfase-IT in patients with neuronopathic mucopolysaccharidosis II. Mol Genet Metab. 2022 Sep-Oct;137(1-2):92103.  
4. da Silva EM, Strufaldi MW, Andriolo RB, Silva LA. Enzyme replacement therapy with idursulfase for mucopolysaccharidosis type II (Hunter syndrome). Cochrane Database Syst Rev. 2016 Feb 5;2(2):CD008185.  
5. Muenzer J, Beck M, Eng CM, Giugliani R, Harmatz P, Martin R, et al. Long-term, open-labeled extension study of idursulfase in the treatment of Hunter syndrome. Genet Med. 2011;13: 95–101.  
6. D'Avanzo F, Rigon L, Zanetti A, Tomanin R. Mucopolysaccharidosis Type II: One Hundred Years of Research, Diagnosis, and Treatment. Int J Mol Sci. 2020 Feb 13;21(4):1258.  
7. Tuschl K, Gal A, Paschke E, Kircher S, Bodamer OA (2005) Mucopolysaccharidosis type II in females: case report and review of literature. Pediatr Neurol 32:270–272.  
8. Wraith JE, Scarpa M, Beck M, et al. Mucopolysaccharidosis type II (Hunter syndrome): a clinical review and recommendations for treatment in the era of enzyme replacement therapy. Eur J Pediatr, 2008;167(3):267-277.  
9. Josahkian JA, Trapp FB, Burin MG, Michelin-Tirelli K, Magalhães APPS, Sebastião FM, Bender F, Mari JF, Brusius-Facchin AC, Leistner-Segal S, Málaga DR, Giugliani R. Updated birth prevalence and relative frequency of mucopolysaccharidoses across Brazilian regions. Genet Mol Biol. 2021 Jan 27;44(1):e20200138.  
10. Mohamed S, He QQ, Singh AA, Ferro V. Mucopolysaccharidosis type II (Hunter syndrome): Clinical and biochemical aspects of the disease and approaches to its diagnosis and treatment. Adv Carbohydr Chem Biochem. 2020;77:71-117.  
11. Kato T, Kato Z, Kuratsubo I, Tanaka N, Ishigami T, Kajihara JI, Sukegawa-Hayasaka K, Orii K, Isogai K, Fukao T, Shimozawa N, Orii T, Kondo N, Suzuki Y. Mutational and structural analysis of Japanese patients with mucopolysaccharidosis type II. J Hum Genet. 2005;50(8):395-402.  
12. Ashworth JL, Biswas S, Wraith E, Lloyd IC. Mucopolysaccharidoses and the eye. Surv Ophthalmol. 2006;51:1–17.  
13. Brasil. Ministério da Saúde. Protocolos Clínicos e Diretrizes Terapêuticas da Asma.  Portaria SAES/SECTICS/MS nº 32, de 20 de dezembro de 2023. Acesso em 29 dez 2023. Disponível em:  
32  
<u>https://www.gov.br/conitec/pt-br/midias/relatorios/portaria/2023/portaria-conjunta-saes-sectics-no-32-pcdtasma.pdf</u>  
14. Raluy-Callado M, Chen WH, Whiteman DA, Fang J, Wiklund I. The impact of Hunter syndrome (mucopolysaccharidosis type II) on health-related quality of life. Orphanet J Rare Dis. 2013;8:101.  
15. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica. Portaria SAES/SAPS/SECTICS/MS nº 1, de 22 de agosto de 2024. Acesso em 11 out 2024. Disponível em: <u>https://www.gov.br/conitec/pt-br/midias/protocolos/dorcronica-1.pdf</u>  
16. Keilmann A, Nakarat T, Bruce IA, Molter D, Malm G; HOS Investigators. Hearing loss in patients with mucopolysaccharidosis II: data from HOS - the Hunter Outcome Survey. J Inherit Metab Dis. 2012 Mar;35(2):343-53.  
17. Carneiro L, Souza CFM, Giugliani R, Fagondes SC. Oropharyngeal Dysphagia in Mucopolysaccharidoses: Evidence from Videofluoroscopic Swallowing Study. J inborn errors metab screen [Internet]. 2022;10:e20220004.  
18. Ríos AV, Llorensi M. Manifestaciones bucales de pacientes con mucopolisacaridosis. Revista de la Asociación Odontológica Argentina, 109(1), 34-40. Epub 15 de abril de 2021.  
19. Barbier AJ, Bielefeld B, Whiteman DAH, Natarajan M, Pano A, Amato DA. The relationship between anti-idursulfase antibody status and safety and efficacy outcomes in attenuated mucopolysaccharidosis II patients aged 5 years and older treated with intravenous idursulfase. Mol Genet Metab. 2013;110: 303–310.  
20. Drugs and Lactation Database (LactMed®) [Internet]. Bethesda (MD): National Institute of Child Health and Human Development; 2006. Idursulfase. Atualizado em 21/06/2021. Disponível em: https://www.ncbi.nlm.nih.gov/books/NBK500606/  
21. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde. Departamento de Assistência Farmacêutica e Insumos Estratégicos. Relação Nacional de Medicamentos Essenciais Rename 2022. Brasília: Ministério da Saúde, 2022.  
33

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **MPS II SOB TRE OU NÃO** -->
|**Avaliações**|**Avaliação**<br>**inicial**|**A cada 6**<br>**meses**|**A cada 12**<br>**meses**|
|---|---|---|---|
|Atividade enzimática|X|||
|Análise genética específica|X|||
|GAG urinários|X||X|
|História médica|X|X||
|Aconselhamento Genético|X|||
|Revisão do número de infusões realizadas no período||X||
|Determinação da adesão ao acompanhamento/tratamento||X||
|Avaliação nutricional (peso/altura)|X|X||
|Avaliação de Sinais Vitais|X|X||
|Hepatimetria|X|X||
|Aplicação de questionário de qualidade de vida validado|X||X|
|AVALIAÇÃO NEUROLÓGICA||||
|- Exame neurológico clínico|X||X|
|- RNM de crânio e/ou TC de crânio<br>- RNM de coluna|X|||
|- Velocidade de condução do nervo mediano|X|||
|- Avaliação do neurodesenvolvimento por neurologista|X||X|
|AVALIAÇÃO OFTALMOLÓGICA (acuidade visual, retina,<br>córnea)|X|||
|AUDIOMETRIA|X|||
|AVALIAÇÃO FUNCIONAL||||
|- Eletrocardiograma|X|||
|- Ecocardiograma|X|||
|- CVF/VEF1|X|||
|- Polissonografia|X|||
|- Avaliação de Mobilidade Articular<br>RX ÓSSEO|X<br>X|||  
* Para pacientes em tratamento específico. As demais avaliações devem ser realizadas em períodos determinados pelo médico assistente.  
CVF = Capacidade vital forçada; GAG = glicosaminoglicanos; RNM = Ressonância magnética; TC = Tomografia computadorizada; VEF1 = volume expiratório forçado no primeiro segundo.  
34

---

<!-- METADADOS: doenca: Mucopolissacaridose do Tipo II | secao: **APÊNDICE 3 HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**||**Tecnologias avalia**|**das pela Conitec**|
|---|---|---|---|
|**Relatório da diretriz**<br>**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório de<br>Recomendação nº<br>940/2024|Atualização de<br>conteúdo|-|-|
|Relatório nº 342/2018<br>Portaria Conjunta<br>SAS/SCTIE/MS n°<br>16/2018|Primeira versão do<br>PCDT da<br>Mucopolissacaridose<br>tipo II|Idursulfase como terapia de<br>reposição enzimática na<br>mucopolissacaridose tipo II<br>[Relatório Técnico nº 311;<br>Portaria SCTIE/MS nº 62/2017]<br>Ampliação do Transplante de<br>Células-Tronco<br>Hematopoiéticas para<br>Mucopolissacaridose Tipo II<br>[Relatório Técnico  nº 330 ;<br>Portaria SCTIE/MS nº<br>09/2018].|-|  
35

---

