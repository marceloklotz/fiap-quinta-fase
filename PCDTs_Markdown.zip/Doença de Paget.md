<!-- METADADOS: doenca: Doença de Paget | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 2, de 17 de JANEIRO DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Paget.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a doença de Paget no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta síndrome;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os Registros de Deliberação nº 405/2018, nº 433/2019 e nº 489/2019 e os Relatórios de Recomendação nº 416 - Dezembro de 2018, nº 444 - Abril de 2019 e nº 498 - Dezembro de 2019, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Paget.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral Doença de Paget, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Doença de Paget.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria disponível no sítio citado no parágrafo único do art 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria no 456/SAS/MS, de 21 de maio de 2012, publicada no Diário Oficial da União nº 98, de 22 de maio de 2012, seção 1, páginas 95 e 96.

---

<!-- METADADOS: doenca: Doença de Paget | secao: MINISTÉRIO DA SAÚDE -->
1  
ANEXO

---

<!-- METADADOS: doenca: Doença de Paget | secao: **1. INTRODUÇÃO** -->
A Doença de Paget Óssea (DPO), também conhecida como osteíte deformante (do Inglês, _Osteitis Deformans_ ), é uma doença óssea hipermetabólica que acomete um (monostótica) ou mais (poliostótica) ossos e se caracteriza por áreas de reabsorção óssea aumentada mediada por osteoclastos, seguida de reparo ósseo osteoblástico desorganizado (1,2). Apesar de não ser uma doença genética, a história familiar está presente em cerca de 5%-40% dos casos e existem mutações em genes que aumentam a suscetibilidade para o seu desenvolvimento (1,2,3). Além disso, algumas infecções virais também têm sido alvo de investigação como possíveis agentes patogênicos (1).  
Como consequência desse processo patológico, há desestruturação da arquitetura nos tecidos ósseos acometidos, o que resulta em aumento de volume e maior fragilidade óssea, que podem se manifestar com dor, fraturas, deformidades ou compressão de estruturas vasculares e nervosas (2,3). A transformação neoplásica das lesões (especialmente osteossarcoma) ocorre raramente (menos de 1% dos pacientes) (1,2). A doença costuma acometer ossos do crânio, pelve, vértebras, fêmur e tíbia (2,3).  
A DPO acomete homens e mulheres, e sua prevalência aumenta com a idade (raramente se manifesta antes dos 40 anos) (1,3). É uma doença mais comum nos países da Europa Ocidental, América do Norte, Austrália e Nova Zelândia, com taxas de prevalência que variam de 0,7% a 4,6% (1). No Brasil, um estudo realizado em Recife observou uma prevalência em adultos maiores de 45 anos de 0,68% e uma incidência de 50,3 por 1.000 pessoas/ano (2,4). As características epidemiológicas e apresentação clínica parecem ser semelhantes nos pacientes brasileiros com aquelas descritas na literatura internacional (2,3).  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da doença de Paget óssea. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Doença de Paget | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- M88.0 - Doença de Paget do crânio.  
- M88.8 - Doença de Paget de outros ossos.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **3. DIAGNÓSTICO** -->
A DPO é frequentemente descoberta por achados incidentais, como aumento da fosfatase alcalina em pacientes sem doença hepatobiliar ou outras doenças ósseas, ou por alterações sugestivas de DPO em exame radiológico feito por outro motivo (1,2).

---

<!-- METADADOS: doenca: Doença de Paget | secao: **3.1 AVALIAÇÃO CLÍNICA** -->
2  
A maioria dos pacientes é assintomática. Quando presentes, as manifestações clínicas mais frequentes são dor e deformidades ósseas, que podem se manifestar por fraturas ou compressão de estruturas adjacentes (por exemplo, nervo e vasos sanguíneos) (1,2). A dor óssea é o sintoma mais frequente, sendo normalmente de leve a moderada intensidade e descrita como profunda. Pode haver relato de piora à noite. Além disso, pode haver dor por osteoartrose em articulações adjacentes a ossos acometidos pela DPO. A deformidade óssea é a segunda manifestação clínica mais comum, sendo os locais mais acometidos a tíbia e a o fêmur (1,2).  
Em decorrência do hipermetabolismo tecidual, pode haver calor e rubor sobre os ossos acometidos. Cefaleia, perda auditiva por acometimento do osso temporal, compressão de raízes nervosas ou medula espinhal por acometimento da coluna vertebral são complicações que podem ocorrer na DPO. Entre todas essas, a perda auditiva é a mais comum e parece estar relacionada a um dano coclear (1,3). Insuficiência cardíaca de alto débito e transformação neoplásica das lesões são manifestações muito raras da DPO (1,2).

---

<!-- METADADOS: doenca: Doença de Paget | secao: **3.2 AVALIAÇÃO LABORATORIAL** -->
Os achados laboratoriais são decorrentes do aumento da reabsorção e acreção óssea em consequência da ação de osteoblastos e osteoclastos. A fosfatase alcalina sérica (FAs), assim como a FA óssea (FAo) e as moléculas de propeptídioprocolágeno tipo C-terminal (P1CP) e propeptídioprocolágeno tipo 1 N-terminal (P1NP) estão usualmente elevadas em pacientes com DPO e medem produtos da formação óssea, dependente da ação dos osteoblastos. Os marcadores da reabsorção óssea dos osteoclastos são a hidroxiprolina urinária, a deoxipiridinolina (D-Pyr), as piridinolinas, N-telopeptídio (NTX) e moléculas de degradação do colágeno C-telopeptídio (CTX) tipo I e tipo II. Esses diversos marcadores do metabolismo ósseo já foram comparados em uma meta-análise que demonstrou que a elevação de todos eles está relacionada com atividade da doença, não havendo diferença entre eles (5). Por essa razão, este Protocolo preconiza utilizar a dosagem de FAs como marcador de atividade da doença (1). Os níveis de FAs são usualmente adequados para avaliar e acompanhar essa atividade e a resposta ao tratamento, sem necessidade dos outros marcadores.  
Dosagens de cálcio sérico para descartar hiperparatireodismo e a exclusão de doença hepatobiliar com avaliação de aspartato-aminotransferase (AST/TGO), alanino-aminotransferase (ALT/TGP) e bilirrubinas total e frações devem ser procedidas (1). Nos pacientes com hipercalcemia, o paratormônio (PTH) deve ser dosado para afastar-se hiperparatireoidismo.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **3.3 EXAMES DE IMAGEM** -->
A cintilografia óssea permite verificar a extensão da doença, localizando áreas de aumento da atividade metabólica. As áreas acometidas devem ser radiografadas. O uso de radiografias simples para diagnóstico, em substituição à cintilografia óssea, já foi avaliado e a investigação  radiográfica pode iniciar pelo abdômen, crânio com ossos da face e tíbias bilateralmente (6). Essa conduta diagnóstica contempla até 93% dos pacientes com DPO e pode ser uma alternativa em locais onde a cintilografia não está disponível. Os achados característicos são hiperostose (aumento da espessura da cortical), osteoesclerose (desorganização e espessamento das trabéculas) e expansão óssea, sendo necessária a presença de pelo menos um dos achados (1,2,6). Tomografia computadorizada e ressonância magnética nuclear podem auxiliar na avaliação de complicações associadas à DPO (compressão de estruturas vasculares ou nervosas, suspeita de neoplasia), mas não se recomenda a sua utilização rotineira na avaliação de pacientes com DPO (1,7).

---

<!-- METADADOS: doenca: Doença de Paget | secao: **3.4 BIÓPSIA ÓSSEA E EXAME ANÁTOMO-PATOLÓGICO** -->
A biópsia óssea é muito raramente necessária, estando indicada apenas quando houver incerteza quanto ao diagnóstico (por exemplo, quando neoplasia for um diagnóstico diferencial possível) (1,2). Os achados anátomo-patológicos de DPO são arquitetura óssea desorganizada com grupamentos de osteoclastos grandes e hipermultinucleados (1,2).  
3

---

<!-- METADADOS: doenca: Doença de Paget | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes com diagnóstico radiológico de DPO e pelo menos um dos seguintes critérios:  
- fosfatase alcalina no soro acima do valor de referência;  
- hipercalcemia com PTH normal/baixo;  
- dor óssea em área acometida;  
- síndrome neurológica ou vascular decorrente de compressão por tecido ósseo acometido;  
- acometimento de ossos longos em membros inferiores, da base do crânio e de vértebras, comprovado por exame de imagem;  
- fratura óssea em tecido acometido; ou  
- plano de intervenção cirúrgica em tecido ósseo acometido.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que apresentarem um dos seguintes critérios:  
- aumento do cálcio sérico (hipercalcemia) e PTH acima do limite superior do valor de referência dos métodos; ou  
- intolerância, hipersensibilidade ou contraindicação ao uso dos medicamentos preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **6. TRATAMENTO** -->
O tratamento da DPO tem por objetivo melhorar a dor e evitar complicações crônicas decorrentes de compressão de estruturas adjacentes ou fraturas ósseas, sendo feito com bisfosfonatos, orais ou intravenosos (IV), ou calcitonina (2,8).  
Pacientes com doença sintomática e ativa devem ser tratados, mesmo que a FAs esteja normal (2). O tratamento para pacientes com doença assintomática comprovada deve levar em conta a localização da doença e a presença de comorbidades, ou seja, doença bioquimicamente ativa em locais onde complicações podem acontecer, como no crânio, coluna, ossos de suporte e lesões contíguas a articulações. Em outros locais, é razoável iniciar o tratamento se a FAs estiver de 2 a 4 vezes além do limite superior do normal. Em pacientes com lesão única e sem alterações bioquímicas, sugere-se a avaliação cintilográfica e acompanhamento anual para sinais de progressão da doença. Há ainda indicação de tratamento para pacientes com DPO com planejamento de cirurgia no local da lesão óssea para evitar sangramentos excessivos ou para os raros pacientes com hipercalcemia por imobilização e doença poliostótica (multifocal) (1,2).  
A calcitonina foi o primeiro tratamento utilizado em pacientes com DPO e ela atua sobre os receptores de calcitonina nos osteoclastos. Por ter curto tempo de ação, desenvolver tolerância e apresentar perfil de efeitos adversos desfavorável, a calcitonina deve ser reservada para aqueles pacientes que não toleram ou têm contraindicações ao uso dos bisfosfonatos (1,2).  
Os bisfosfonatos são inibidores potentes da reabsorção óssea caracteristicamente aumentada nesta doença, com grande afinidade pela hidroxiapatita. Os osteoclastos são o principal alvo destes medicamentos. Com o seu uso, há diminuição substancial dos índices bioquímicos da atividade da doença e melhora sintomática significante. Os níveis séricos de FAs diminuem, e há melhora radiológica e cintilográfica das lesões, com melhora da dor e das deformidades ósseas. Há relação positiva entre a resposta bioquímica inicial ao medicamento e a duração da remissão alcançada, mas não há relação positiva entre o prolongamento do tratamento e a remissão mais longa. A supressão efetiva e sustentada da atividade dos osteoclastos com intensidade e tempo suficientes prevenirá recrutamento de novos osteoclastos doentes com eventual destruição da população  
4  
anormal. O controle em longo prazo da atividade da doença é uma meta relevante do tratamento pela possibilidade de redução das complicações futuras (deformidades, fraturas e degeneração articular óssea) (1,2).  
Dos bisfosfonatos, o alendronato, o risedronato e o ácido zoledrônico podem ser empregados no tratamento da DPO (2,815). Para o controle da dor, paracetamol e anti-inflamatórios não esteroidais (AINE) também podem ser utilizados (1).  
O ácido zoledrônico é um bisfosfonato heterocíclico, portador de nitrogênio, com potência anti-reabsortiva pelo menos 120 vezes maior do que a do pamidronato e desenvolvido para administração intravenosa (IV). Este bisfosfonato já foi avaliado em diversos estudos clínicos para tratamento de DPO e se mostrou mais eficaz que placebo ou outros bisfosfonatos (pamidronato, risedronato) em reduzir os níveis séricos de FAs, com nível de evidência moderado. A sua superioridade em melhorar desfechos clínicos somente foi avaliada como desfecho secundário com resultados discordantes. Inexiste evidência inequívoca de que o seu uso seja superior a outros bisfosfonatos em desfechos clínicos ou complicações futuras da DPO e o real valor do uso dos níveis de FAs como desfecho substituto é questionável. Além disso, apresenta um bom perfil de segurança e um esquema de tratamento conveniente, podendo favorecer a adesão dos pacientes, quando comparado ao pamidronato (17). Sendo assim, conforme os relatórios de recomendação nº 416 de dezembro de 2018 e n° 444 de abril de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS, este Protocolo atualiza-se com a inclusão do ácido zoledrônico e a exclusão do pamidronato, respectivamente, para o tratamento da DPO (16,17).  
Além da escolha do representante da classe dos bisfosfonatos, um ensaio clínico (PRISM) foi realizado comparando dois desfechos para o uso de bisfosfonatos no tratamento de pacientes com DPO sintomática: normalização da FAs, para o grupo alocado a tratamento intensivo, ou melhora da dor óssea, para o grupo alocado a tratamento sintomático. O desfecho primário foram fraturas e os secundários, níveis de FAs, dor, procedimentos ortopédicos e qualidade de vida. Qualquer bisfosfonato poderia ser utilizado no tratamento, sendo o risedronato o mais comumente utilizado (nesse estudo inicial o ácido zoledrônico não foi utilizado). Nesse estudo, com 1.324 pacientes, apesar de menores níveis de FAs no grupo de tratamento baseado em parâmetros bioquímicos, ao longo de 3 anos de seguimento não houve diferenças entre os dois grupos com respeito a fraturas, necessidade de cirurgia ortopédica, qualidade de vida, dor óssea ou modificação da audição (18).  
Em 2017, uma extensão do estudo PRISM foi publicada, e os pacientes que complementaram este primeiro estudo foram convidados a participar (19). Nessa segunda parte do estudo, 502 pacientes foram incluídos e mantiveram o mesmo tratamento para o qual haviam sido randomizados no PRISM (sintomático em 232 pacientes e intensivo em 270 pacientes). Nessa extensão, o ácido zoledrônico foi o bisfosfonato de escolha para o tratamento. As diferenças na resposta dos níveis de FAs sempre foram maiores e com diferença significativa ao longo do estudo no grupo com ácido zoledrônico, com níveis sempre mais baixos que o grupo sintomático, mas sem relação com desfechos clínicos. Estes dois estudos têm grande importância, uma vez que avaliaram como desfechos eventos clínicos (fraturas foi o desfecho primário em ambos os estudos) e demonstraram que a conduta de tratar os pacientes com DPO somente quando estes apresentam sintomas é comparável ao tratamento intensivo (determinado pelo nível sérico de FAs e objetivando manter está dentro dos níveis normais). Além disso, os resultados desse estudo questionam o valor do uso da FAs como desfecho substituto.  
Com base no acima exposto, o tratamento para DPO em atividade deve ser preferencialmente feito com bisfosfonatos, sendo a calcitonina reservada para aqueles pacientes que tenham contraindicação (insuficiência renal com DCE abaixo de 30 mL/min/1,73 m<sup>2</sup> ) ou que não tolerem os bisfosfonatos.  
Nos pacientes com contraindicação aos bisfosfonatos orais (alendronato e risedronato) em função de dismotilidade esofágica ou impossibilidade de manter-se ortostase após ingestão dos comprimidos, o bisfosfonato intravenoso (ácido zoledrônico) deve ser a terapia de escolha. Nos demais pacientes, os bisfosfonatos orais (alendronato e risedronato) também podem ser utilizados.  
Antes de iniciar o tratamento com bisfosfonatos, é importante que se garanta o aporte adequado de cálcio e vitamina D, o que é alcançado com reposição de cálcio e colecalciferol.  
5

---

<!-- METADADOS: doenca: Doença de Paget | secao: **6.1** -->
- Alendronato de sódio: comprimidos de 10 mg  
- Risedronato sódico: comprimidos de 35 mg  
- Ácido zoledrônico: frasco com 100 mL de solução, com 5 mg/100 mL  
- Calcitonina: aerossol nasal em frasco de 200 UI  
- Carbonato de cálcio + colecalciferol: comprimidos de 1.250 mg (500 mg de cálcio elementar) + 200 ou 400 UI; comprimidos de 1.500 mg (600 mg de cálcio elementar) + 400 UI

---

<!-- METADADOS: doenca: Doença de Paget | secao: **6.2 ESQUEMAS DE ADMINISTRAÇÃO** -->
**Alendronato de sódio:** 40 mg por via oral, em dose única diária, por 6 meses. Deve ser ingerido pela manhã, meia hora antes da refeição, com um copo cheio de água (180-240 ml). O paciente deve ficar de pé ou sentado, com espaldar reto por no mínimo 30 minutos após a administração do medicamento.  
**Risedronato sódico:** 35 mg por via oral*<sup>1</sup> , em dose única diária, por 2 meses. Deve ser ingerido pela manhã, meia hora antes da refeição, com 300 mL de água. O paciente deve ficar de pé ou sentado por no mínimo 30 minutos após a administração do medicamento.  
**Ácido Zoledrônico:** 5 mg por via intravenosa. A dose é de 5 mg, com 12 meses de intervalo mínimo para retratamento.  
**Calcitonina:** 200 UI por via inalatória nasal, diariamente ou 3 vezes por semana por 6 a 18 meses.  
**Carbonato de cálcio + colecalciferol:** 1,2 a 1,5 g/dia de cálcio elementar e 600 a 1.200 UI/dia de colecalciferol, dividido  
em 3 doses por 6 meses. Verificar a apresentação mais adequada de acordo com a posologia prescrita.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **6.3 TEMPO DE TRATAMENTO** -->
Após completar cada ciclo de tratamento, que varia em duração para cada medicamento, os pacientes que persistirem com doença ativa são candidatos a novo ciclo (uma vez ou mais), mantendo-se o acompanhamento a cada 3 a 6 meses (1,2). Nos pacientes com doença estável, o acompanhamento pode ser espaçado para intervalos de 6 a 12 meses (1,2).

---

<!-- METADADOS: doenca: Doença de Paget | secao: **6.4 BENEFÍCIOS ESPERADOS** -->
O tratamento da DPO tem por objetivo melhorar os sintomas e evitar complicações crônicas, tais como fraturas e compressão de estruturas neurovasculares.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **7. MONITORIZAÇÃO** -->
No acompanhamento dos pacientes com DPO, a avaliação clínica deve receber especial atenção para investigação e prevenção de fraturas, deformidades ósseas e sinais de comprometimento de vasos e nervos. A dosagem de fosfatase alcalina deve ser dosada a cada 3 a 6 meses, podendo este tempo ser aumentado para 6 a 12 meses em pacientes estáveis.  
Os pacientes que permanecerem ou se tornarem novamente sintomáticos (dor ou deformidade óssea) ou com sinais laboratoriais de atividade da doença (elevação da fosfatase alcalina) são candidatos a novos ciclos de tratamento. Quando houver suspeita de acometimento de novos locais, deve ser feito exame radiológico da respectiva região. Nos casos de aumento de  
> 1 *A dose do risedronato mais estudada e recomendada para o tratamento da DPO são 30 mg diários; porém a apresentação disponível no Brasil é somente a de 35 mg.  
6  
volume ósseo, apesar de raro, deve ser feita investigação com exame de imagem para exclusão de transformação neoplásica, podendo ser necessária biópsia do osso. Por outro lado, aqueles pacientes que permanecerem sem sinas clínicos e laboratoriais de atividade podem ter o tratamento interrompido e ficar somente em acompanhamento.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **8. ACOMPANHAMENTO PÓS-TRATAMENTO** -->
O acompanhamento dos pacientes deve ser feito por toda a vida.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Pacientes com doença de Paget devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica.  
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se cientificar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos colaterais relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **11. REFERÊNCIAS** -->
1. Singer FR, Bone HG, Hosking DJ, Lyles KW, Murad MH, Reid IR, Siris ES, Endocrine Society. Paget's disease of bone: an endocrine society clinical practice guideline. J Clin Endocrinol Metab. 2014 Dec;99(12):4408-22.  
2. Griz L, Fontan D, Mesquita P, Lazaretti-Castro M, Borba VZ, Borges JL, Fontenele T, Maia J, Bandeira F, Brazilian Society of Endocrinology and Metabolism. Diagnosis and management of Paget's disease of bone. Arq Bras Endocrinol Metabol. 2014 Aug;58(6):587-99.  
3. Werner de Castro GR, Heiden GI, Zimmermann AF, Morato EF, Neves FS, Toscano MA, de Magalhães Souza Fialho SC, Pereira IA. Paget's disease of bone: analysis of 134 cases from an island in Southern Brazil: another cluster of Paget's disease of bone in South America. Rheumatol Int. 2012 Mar;32(3):627-31.  
4. Reis RL, Poncell MF, Diniz ET, Bandeira F. Epidemiology of Paget's disease of bone in the city of Recife, Brazil. Rheumatol Int. 2012 Oct;32(10):3087-91.  
5. Al Nofal AA, Altayar O, BenKhadra K, Qasim Agha OQ, Asi N, Nabhan M, Prokop LJ, Tebben P, Murad MH. Bone turnover markers in Paget's disease of the bone: A Systematic review and meta-analysis. Osteoporos Int. 2015 Jul;26(7):1875-91.  
6. Guañabens N, Rotés D, Holgado S, Gobbo M, Descalzo MÁ, Gorordo JM, Martínez-Ferrer MA, Salmoral A, Morales-Piga A. Implications of a new radiological approach for the assessment of Paget disease. Calcif Tissue Int. 2012 Dec;91(6):40915.  
7. Morales H. MR Imaging Findings of Paget's Disease of the Spine. Clin Neuroradiol 2015 Sep;25(3):225-32.  
7  
8. Mahmood W, McKenna M. Proposed new approach for treating Paget's disease of bone. Irish Journal of Medical Science (2011) 180:1 (121-124).  
9. Reid IR, Nicholson GC, Weinstein RS, Hosking DJ, Cundy T, Kotowicz MA, et al. Biochemical and radiologic improvement in Paget's disease of bone treated with alendronate: a randomized, placebo-controlled trial. Am J Med. 1996;101(4):341-8.  
10. Siris ES, Chines AA, Altman RD, Brown JP, Johnston CC, Jr., Lang R, et al. Risedronate in the treatment of Paget's disease of bone: an open label, multicenter study. J Bone Miner Res. 1998;13(6):1032-8.  
11. Gutteridge DH, Retallack RW, Ward LC, Stuckey BG, Stewart GO, Prince RL, et al. Clinical, biochemical, hematologic, and radiographic responses in Paget's disease following intravenous pamidronate disodium: a 2-year study. Bone. 1996;19(4):387-94.  
12. Miller PD, Brown JP, Siris ES, Hoseyni MS, Axelrod DW, Bekker PJ. A randomized, double-blind comparison of risedronate and etidronate in the treatment of Paget's disease of bone. Paget's Risedronate/Etidronate Study Group. Am J Med. 1999;106(5):513-20.  
13. Walsh JP, Ward LC, Stewart GO, Will RK, Criddle RA, Prince RL, et al. A randomized clinical trial comparing oral alendronate and intravenous pamidronate for the treatment of Paget's disease of bone. Bone. 2004;34(4):747-54.  
14. Nishida Y, Yamada Y, Tsukushi S, Sugiura H, Urakawa H, Ishiguro N. Midterm outcome of risedronate therapy for patients with Paget's disease of bone in the central part of Japan. Clinical Rheumatology (2013) 32:2 (241-245).  
15. Ohara M, Imanishi Y, Nagata Y, Ishii A, Kobayashi I, Mori K, Ito M, Miki T, Nishizawa Y, Inaba M. Clinical efficacy of oral risedronate therapy in Japanese patients with Paget's disease of bone.  J Bone Miner Metab. 2015 Sep;33(5):584-90.  
16. 2018. Relatório de Recomendação nº 416 – Ácido Zoledrônico no tratamento da doença de Paget - dezembro de 2018. In: CONITEC, 2018.  
17. 2019. Relatório de Recomendação nº 444 - Exclusão do pamidronato dissódico para tratamento da doença de Paget óssea - abril de 2019. In: CONITEC, 2019.  
18. Langston AL, Campbell MK, Fraser WD, MacLennan GS, Selby PL, Ralston SH. Randomized trial of intensive bisphosphonate treatment versus symptomatic management in Paget's disease of bone. J Bone Miner Res. 2010;25(1):2031.  
19. Tan A, Goodman K, Walker A, Hudson J, MacLennan GS, Selby PL, et al. Long-Term Randomized Trial of Intensive Versus Symptomatic Management in Paget's Disease of Bone: The PRISM-EZ Study. J Bone Miner Res. 2017;32(6):116573.  
8

---

<!-- METADADOS: doenca: Doença de Paget | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ALENDRONATO, RISEDRONATO, CALCITONINA, ÁCIDO ZOLEDRÔNICO, CARBONATO DE CÁLCIO + COLECALCIFEROL.  
Eu, __________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente  
sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **alendronato** , **risedronato** , **ácido zoledrônico** e **calcitonina** , indicados para o tratamento da **doença de Paget – osteíte deformante** .  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico  
_______________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- melhora dos sintomas;  
- prevenção de complicações.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do  
uso destes medicamentos:  
- não se sabe ao certo os riscos do uso dos medicamentos na gravidez; portanto, caso engravide, devo avisar imediatamente o médico;  
- efeitos adversos mais comuns do alendronato: dor abdominal, úlcera esofágica, dificuldade para engolir ou distensão abdominal, dores musculoesqueléticas, prisão de ventre, diarreia, flatulência, cefaleia;  
- efeitos adversos mais comuns do risedronato: dores abdominais, náusea, diarreia, gases, dor no estômago, depressão, tonturas, insônia, ansiedade, dores nos músculos, cãibras, formigamentos, aumento da pressão arterial, dor no peito, falta de ar, vermelhidão e coceira na pele, infecções em geral;  
- efeitos adversos mais comuns do ácido zoledrônico: febre, dor de cabeça, tontura, dor de estômago, vômito, diarreia, dor muscular, dor nas juntas, dor nos ossos, dor nas costas, dor nas mãos ou pés, sintomas de gripe (como febre, dor de garganta, cansaço, calafrios, dor muscular e nas juntas), calafrios, cansaço, fraqueza, dor, indisposição, sintomas devido ao baixo nível de cálcio no sangue, como espasmos musculares, dormência ou sensação de formigamento, especialmente na área ao redor da boca, falta de ar.  
- efeitos adversos mais comuns da calcitonina: náusea, diarreia, prisão de ventre, gases, dor no estômago, perda de apetite, calorões, aumento da pressão arterial, dor no peito, falta de ar, chiado no peito, tonturas, aumento do volume de urina, infecções, dores em geral, sangramento e irritação nasal, formação de crostas no nariz (quando administrado por essa via), espirros, reações no local de aplicação do medicamento (quando administrado pela via subcutânea), reações alérgicas, vermelhidão na pele, fraqueza;  
- efeitos adversos mais comuns do carbonato de cálcio + colecalciferol: distensões abdominais e flatulência (gases). Uso prolongado de cálcio em pacientes idosos pode provocar constipação intestinal. Excessivas quantidades de sais de cálcio podem causar hipercalcemia; os sintomas de hipervitaminose D podem incluir hipercalcemia, perda de apetite, debilidade, diarreia, poliúria, náusea, vômitos e depósitos de cálcio nos tecidos moles e, em casos graves, arritmia cardíaca e coma;  
- medicamentos estão contraindicados em casos de hipersensibilidade (alergia) aos fármacos;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
9  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento,  
desde que assegurado o anonimato.    (    ) Sim                (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (   ) alendronato  
- (   ) risedronato  
- (   ) ácido zoledrônico  
- (   ) calcitonina  
- (   ) carbonato de cálcio + colecalciferol  
|Local:|Data:||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do r|esponsável legal:||
||_____________________________________<br>Assinatura do paciente ou do responsável legal||
|Médico responsável:|CRM:|UF:|
||__________________________<br>Assinatura e carimbo do médico||
||Data:____________________||  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência  
Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
10

---

<!-- METADADOS: doenca: Doença de Paget | secao: **Escopo e finalidade do Protocolo** -->
Este PCDT se destina a profissionais da saúde, pacientes com Doença de Paget e gestores do SUS. O documento foi elaborado visando a garantir o melhor cuidado de saúde e o uso racional dos recursos disponíveis no Sistema Único de Saúde.  
Depois da publicação, em 17/01/2020, da Portaria Conjunta SAES/SCTIE/MS n<sup>o</sup> 2, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Doença de Paget, pela necessidade de se excluírem apresentações farmacêuticas de calcitonina devido à ausência de registros válidos na Agência Nacional de Vigilância Sanitária (Anvisa). Para tal, foi também adequado o Relatório de Recomendação n.º 489/2019 da Conitec.  
À 104ª Reunião Ordinária da Conitec, realizada dia 09/12/2021, havia sido analisado o Relatório de Recomendação nº 694/2021, que se refere à exclusão de medicamentos cujos registros sanitários caducaram ou foram cancelados no Brasil. Àquela ocasião, foi deliberado, por unanimidade, recomendar a exclusão de calcitonina solução injetável 50 UI e 100 UI. A decisão de exclusão das apresentações foi publicada por meio da Portaria SCTIE/MS nº 83, de 29/12/2021. Por fim, o tema foi apresentado como informe à 96ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 22/02/2022 e também à 106ª Reunião Ordinária da Conitec, em 10/03/2022.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **A) LEVANTAMENTO DE INFORMAÇÕES PARA O PLANEJAMENTO DA REUNIÃO COM OS ESPECIALISTAS** -->
Para a identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas, foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec), o Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos OPM do SUS (SIGTAP) e o Protocolo Clínico e Diretrizes Terapêuticas (PCDT) Doença de Paget – Osteíte Deformante vigente.  
A partir das consultas realizadas foi possível identificar:  
- O tratamento no SUS segue o orientado no PCDT Doença de Paget – Osteíte Deformante, conforme Portaria SAS/MS nº 456, de 21 de maio de 2012;  
- Os medicamentos disponíveis são: alendronato, risedronato, pamidronato, calcitonina e carbonato de cálcio/colecalciferol;  
- Não há solicitação de nenhuma nova tecnologia para avaliação pela CONITEC;  
Na enquete realizada pelo MS foram levantadas as seguintes questões:  
- Falta de resultado eficaz com uso de calcitonina;  
- Sugestão de inclusão do ácido zoledrônico;  
- Apresentação disponível de risedronato (35 mg) diferente da indicada no PCDT (5 mg);  
- Sugestão de enfatizar que o paciente não deve submeter-se a intervenções cirúrgicas (osteotomias corretivas) antes da melhora da qualidade óssea.  
Todas as solicitações encaminhadas pela enquete foram avaliadas e ajustadas e, no caso do ácido zoledrônico, PTC foi  
elaborado. Em relação à calcitonina, esta foi mantida por ser a única opção de tratamento para pacientes que não toleram bisfosfonatos ou que tem contraindicações ao uso dessa classe.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **B) REUNIÃO COM ESPECIALISTAS** -->
11  
Foi realizada reunião com os consultores especialistas e metodologistas do comitê elaborador dos PCDT na qual foram apresentados os resultados do levantamento de informações realizados pelos metodologistas. Os consultores especialistas indicaram a necessidade de avaliação de inclusão de ácido zoledrônico.  
Sendo assim, foi estabelecido que o presente Protocolo destina-se a pacientes com doença de Paget, ambos os sexos, sem restrição de idade e tem por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca do PCDT vigente.

---

<!-- METADADOS: doenca: Doença de Paget | secao: **Ácido zoledrônico** -->
A fim de revisar a literatura sobre a eficácia, efetividade e segurança do ácido zoledrônico foi elaborado um parecer técnico científico, na qual foi avaliado pela plenária da Conitec na reunião de 29/08/2018. A conclusão foi pela recomendação da incorporação do ácido zoledrônico (16).

---

<!-- METADADOS: doenca: Doença de Paget | secao: **Pamidronato dissódico** -->
Foi elaborado Relatório de Recomendação solicitando a desincorporação do pamidronato dissódico, na qual foi avaliada pela plenária da Conitec na reunião de 03/04/2019. A conclusão foi pela recomendação de exclusão do pamindronato dissódico do tratamento da doença de Paget óssea(17).

---

<!-- METADADOS: doenca: Doença de Paget | secao: **D) BUSCAS NA LITERATURA PARA ATUALIZAÇÃO DO PCDT** -->
A fim de guiar a revisão do PCDT vigente foi realizada busca na literatura sobre **intervenções terapêuticas** definidas pela pergunta PICO estabelecida no **Quadro 1** .  
**Quadro 1 -** Pergunta PICO – intervenções terapêuticas  
|População|Pacientes com doença de Paget|
|---|---|
|Intervenção|Tratamento clínico|
|Comparação|Sem restrição de comparadores|
|Desfechos|Segurança e eficácia (níveis séricos de marcadores de metabolismo ósseo, sintomas, fraturas,|
||deformidades, eventos adversos, alterações hidroeletrolíticas)|  
A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Medicamentos registrados no Brasil;  
- Medicamentos com indicação em bula do tratamento de doença de Paget;  
- Estudos realizados em humanos;  
- Estudos com mais de 10 pacientes (excluídos relatos de caso e séries de casos muito pequenas);  
- Estudos com dados originais (excluídas revisões narrativas, editoriais, etc);  
- Estudos publicados de forma completa (excluídos resumos em anais de congresso);  
- Estudos de intervenção terapêutica.  
O **Quadro 2** apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de  
selecionados. Os artigos selecionados encontram-se na **Tabela 1** . Os artigos relacionados ao medicamento ácido zoledrônico foram considerados/avaliados em parecer técnico científico (PTC).  
**Quadro 2 -** Buscas sobre intervenções terapêuticas – sem restrição de tipos de estudos  
12  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via PubMed)<br>Data da busca:<br>27/10/2017|"Osteitis Deformans"[Mesh] AND<br>"Therapeutics"[Mesh] AND<br>(("2011/08/18"[PDAT] :<br>"2017/10/27"[PDAT]) AND<br>"humans"[MeSH Terms] AND<br>(English[lang] OR Portuguese[lang]<br>OR Spanish[lang]))|27|2<br>**Motivo das exclusões:**<br>- Estudos  com menos de 10<br>pacientes: 5<br>- Estudos sem dados originais: 7<br>- Estudos não relacionados a Paget: 7<br>- Medicamento sem indicação para a<br>doença no Brasil: 1<br>- Estudos avaliando ácido<br>zolêdronico: 5|
|Embase<br>Data da busca:<br>27/10/2017|'paget bone disease'/exp AND<br>'therapy'/exp AND [humans]/lim AND<br>([english]/lim OR [portuguese]/lim OR<br>[spanish]/lim) AND [18-8-2011]/sd<br>NOT [28-10-2017]/sd|295|3<br>**Motivo das exclusões:**<br>- Estudos com menos de 10<br>pacientes: 33<br>- Estudos sem dados originais: 32<br>- Estudos não relacionados a Paget:<br>215<br>- Estudos não avaliando tratamento:<br>20<br>- Estudos avaliando ácido<br>zolêdronico: 16<br>- Resumos de congresso: 5<br>- Estudo avaliando medicamento sem<br>registro Brasil: 1<br>- Estudos já incluídos na busca do<br>Pubmed/tratamento: 2|
|Cochrane Library<br>Data da busca:<br>27/10/2017|MeSH descriptor: [Osteitis Deformans]<br>explode all trees'|1|0<br>**Motivo das exclusões:**<br>- estudo incluído no PTC ácido<br>zoledrônico|  
13  
A fim de guiar a revisão do PCDT vigente foi realizada busca na literatura sobre **diagnóstico** nos principais consensos e  
_guidelines internacionais_ . O **Quadro 3** apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados  
e o número de selecionados. Os artigos selecionados encontram-se na **Tabela 1** .  
A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Testes laboratoriais disponíveis no Brasil;  
- Estudos abordando doença de Paget;  
- Estudos realizados em humanos;  
- Estudos com mais de 10 pacientes (excluídos relatos de caso e séries de casos muito pequenas);  
- Excluídas revisões narrativas;  
- Estudos publicados de forma completa (excluídos resumos em anais de congresso).  
**Quadro 3 -** Busca por diagnóstico e consensos  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via<br>PubMed)|"Osteitis Deformans"[Mesh] AND<br>"Diagnosis"[Mesh] AND<br>(("2011/08/18"[PDAT] :|151|3<br>**Motivo das exclusões:**|
|Data da busca:<br>27/10/2017|"2017/10/27"[PDAT]) AND "humans"[MeSH<br>Terms] AND (English[lang] OR<br>Portuguese[lang] OR Spanish[lang]))||- Estudos com menos de 10<br>pacientes: 63<br>- Estudos não relacionados a Paget:<br>36<br>- Estudos não avaliando<br>diagnóstico: 14<br>- Estudos avaliando exames não<br>disponíveis: 6<br>- Revisões narrativas: 26<br>- Estudos já incluídos na busca do<br>Embase/tratamento: 2<br>- Estudos já incluídos na busca do<br>Pubmed/tratamento: 1|  
Para informações adicionais de **dados nacionais sobre a doença** também foi realizada uma busca, conforme **Quadro 4** , que apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados. Os artigos selecionados encontram-se na **Tabela 1** .  
A seleção dos artigos levou em considerações os seguintes critérios de inclusão:  
- Estudos de terapia da doença de Paget;  
- Estudos de diagnóstico da doença de Paget;  
- Dados nacionais sobre doença de Paget;  
- Estudos realizados em humanos;  
- Estudos com mais de 10 pacientes (excluídos relatos de caso e séries de casos muito pequenas);  
- Estudos com dados originais, revisões sistemáticas ou consensos (excluídas revisões narrativas, editoriais, etc);  
14  
- Estudos publicados de forma completa (excluídos resumos em anais de congresso).  
**Quadro 4 -** Busca por dados nacionais sobre a doença  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via|"Osteitis Deformans"[Mesh] AND|3|2|
|PubMed)|"Brazil"[Mesh] AND|||
||(("2011/08/18"[PDAT] :||**Motivo das exclusões:**|
|Data da busca:|"2017/10/27"[PDAT]) AND||- Estudos já incluídos na|
|27/10/2017|"humans"[MeSH Terms])||busca Embase/tratamento: 1|  
15  
**Tabela 1 -** Artigos selecionados  
|**Estudo**|**Desenho**|**Intervenção/**<br>**Desfecho**|**Resultados**|**Limitações**|
|---|---|---|---|---|
|_Clinical efficacy of oral_<br>_risedronate therapy in_<br>_Japanese patients with_<br>_Paget's disease of bone,_<br>2015.|Série de casos  (11<br>pacientes com DP)|Uso de<br>risendronato, 17,5<br>mg por dia por 8<br>semanas|- Os pacientes foram tratados por<br>elevação da FA acima do valor de<br>referência.<br>- O uso de risendronato foi associado<br>como queda dos marcadores de<br>metabolismo ósseo.<br>- Dos 11 pacientes, 6 pacientes<br>responderam ao tratamento e 5 não.|- Pequeno número de pacientes.<br>- Uso de desfecho secundário.<br>- Sem grupo controle.|
|_Midterm outcome of_<br>_risedronate therapy for_<br>_patients with Paget's disease_<br>_of bone in the central part of_<br>_Japan,_2013.|Série de casos  (17<br>pacientes com DP)|Uso de<br>risendronato, 17,5<br>mg por dia por 8<br>semanas|- Os pacientes foram tratados por<br>elevação da FA acima do valor de<br>referência ou sintomas.<br>- O uso de risendronato foi associado<br>como queda dos marcadores de<br>metabolismo ósseo e melhora dos<br>sintomas.<br>- Dos 17 pacientes, todos apresentaram<br>melhora dos marcadores de<br>metabolismo ósseo. Dos 10 pacientes<br>com dor ósseoa, 8 apresentaram<br>melhora.<br>- 7 dos 17 pacientes necessitaram de<br>retratamento com bisfosfonados por<br>elevação da FA.|- Pequeno número de pacientes.<br>- Sem grupo controle.|  
16  
|**Estudo**|**Desenho**|**Intervenção/**<br>**Desfecho**|**Resultados**|**Limitações**|
|---|---|---|---|---|
|_Proposed new approach for_<br>_treating Paget's disease of_<br>_bone_, 2011.|Série de casos<br>prospectiva (n= 31<br>pacientes com DP)|Uso de<br>bisfofonados|- Todos os pacientes receberam<br>bisfosfonados (alendronato, risedronato<br>ou ácido zolendrônico).<br>- Foi observada queda dos níveis de FA<br>em praticamente todos os pacientes<br>(97%).|- Pequeno número de pacientes.<br>- Sem grupo controle.|
|_Bone turnover markers in_<br>_Paget's disease of the bone: A_<br>_Systematic review and_<br>_meta-analysis,_2015.|Revisão sistemática<br>e meta-análise de 17<br>estudos<br>observacionais e um<br>ensaio clínico,<br>totalizando 953<br>pacientes|Marcadores de<br>metabolismo ósseo<br>e atividade da<br>doença<br>Marcadores<br>avaliados:<br>Fosfatase alcalina<br>(FA), fosfatase<br>alcalina óssea<br>(FAO),_procollagen_<br>_type 1 amino-_<br>_terminal propeptide_<br>(P1NP),_C-terminal_<br>_telopeptide_urinário<br>(uCTx) e sérico<br>(sCTx), e_N-_<br>_terminal_|- Para diagnóstico, todos os<br>marcadores apresentaram correlação<br>moderada-forte com a atividade da<br>doença na cintilografia óssea.<br>- Não houve diferença na comparação<br>entre os diversos marcardores.<br>Depois de iniciado o tratamento com<br>bisfosfonatos, o marcador que menos<br>se correlacionou com atividade da<br>doença foi FA, porém ainda com uma<br>correlação aceitável (variando de 0,43<br>a 0,70).||  
17  
|**Estudo**|**Desenho**|**Intervenção/**<br>**Desfecho**|**Resultados**|**Limitações**|
|---|---|---|---|---|
|||_telopeptide_urinário<br>(uNTx).|||
|_MR Imaging Findings of_<br>_Paget's Disease of the Spine_,<br>2015.|Série de casos<br>(n=16 pacientes<br>com DP)|Não se aplica|-<br>Foram<br>revisados<br>exames<br>de<br>ressonância<br>magnética<br>de<br>16<br>pacientes com doença de paget<br>acometendo a coluna vertebral.<br>Os seguintes achados foram descritos:<br>padrão misto de sinal em T1<br>(compatível com a fase mista da<br>doença). Expansão do corpo vertebral<br>ou processos posteriores.|- Limitações inerentes ao desenho do<br>estudo, série de casos.|
|_Implications of a new_<br>_radiological approach for the_<br>_assessment of Paget disease_,<br>2012.|Estudo transversal<br>(n= 208 pacientes<br>com DP não<br>tratada)|Comparação do uso<br>de radiografia com<br>cintilografia óssea<br>para o diagnóstico|- O uso da radiografia de abdômen<br>isolada identificou 79% dos pacientes<br>(IC95% 74%-85%)<br>- O uso da associação das radiografias<br>de  abdômen, crânio com ossos da face<br>e tíbias bilateralmente permitiu o<br>diagnóstico de 93% dos pacientes com<br>DP.|- Dado de um centro único, não<br>reproduzido em outros centros.|
|_Paget's disease of bone:_<br>_analysis of 134 cases from an_<br>_island in Southern Brazil:_<br>_another cluster of Paget's_<br>_disease of bone in South_<br>_America_, 2010.|Série de casos|Não se aplica|- Os autores avaliaram as principais<br>características clínicas de 134 pacientes<br>com DP.<br>- Idade média ao diagnóstico 63,2 anos;<br>67,2% mulheres, 91,1% caucasianos.|- Limitações inerentes ao desenho do<br>estudo, série de casos.|  
18  
|**Estudo**|**Desenho**|**Intervenção/**<br>**Desfecho**|**Resultados**|**Limitações**|
|---|---|---|---|---|
||||- História familiar positiva em 8,2% dos<br>pacientes.<br>- Doença polóstica estava presente em<br>75% dos pacientes e dor óssea era<br>sintoma em 77,9%. Os ossos da pelve<br>eram os mais acometidos (7%).<br>- Complicações da DP: surdez (8,2%),<br>fraturas (3%), hidrocéfalos (2,2%),<br>síndrome da cauda equina (0,7%).||
|_Paget's disease of bone: an_<br>_endocrine society clinical_<br>_practice guideline_, 2014.|Consenso de<br>especialistas<br>(_Endocrine Society_)|Não se aplica|Baseado em ampla revisão da literatura,<br>foram<br>feitas<br>18<br>recomendações,<br>utilizando o sistema GRADE.|Apesar de ser baseado em evidências,<br>este tipo de documento pode conter<br>vieses e deve ser visto com certo<br>cuidado.|
|_Diagnosis and management_<br>_of Paget's disease of bone_,<br>2014.|Consenso de<br>especialistas<br>(Departamento de<br>Metabolismo Ósseo<br>da Sociedade<br>Brasileira de<br>Endocrinologia)|Não se aplica|Baseado em ampla revisão da literatura,<br>foram feitas recomendações.|Apesar de ser baseado em evidências,<br>este tipo de documento pode conter<br>vieses e deve ser visto com certo<br>cuidado.|
|_Epidemiology of Paget's_<br>_disease of bone in the city of_<br>_Recife, Brazil_, 2011.|Estudo<br>epidemiológico|Não se aplica|O estudo avaliou a presença de Doença<br>de Paget em todos os adultos que<br>consultaram<br>em<br>um<br>centro<br>de<br>tratamento de doenças ósseas em Recife|O estudo foi realizado em um centro<br>especializado de tratamento, logo<br>pode não refletir a real prevalência da|  
19  
|**Estudo**|**Desenho**|**Intervenção/**<br>**Desfecho**|**Resultados**|**Limitações**|
|---|---|---|---|---|
||||e observou uma prevalência em adultos<br>maiores de 45 anos de 0,68% e uma<br>incidência de 50,3 por 1.000 pessoas-<br>ano.|Doença de Paget na população<br>brasileira.|  
20  
21

---

