<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
PORTARIA Nº 956, DE 26 DE SETEMBRO DE 2014.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Linfoma Difuso de Grandes Células B.  
O Secretário de Atenção à Saúde, no uso das atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre o linfoma difuso de grandes células B no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os Protocolo Clínico e Diretrizes Terapêuticas (PCDT) são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando as sugestões dadas à Consulta Pública n<sup>o</sup> 29/SAS/MS, de 25 de agosto de 2010;  
Considerando o Registro de Deliberação nº 26/2010 da Comissão de Incorporação de Tecnologias - CITEC/MS;  
Considerando o Registro de Deliberação Nº 74, de 05 de dezembro de 2013, da Comissão Nacional de Incorporação de Tecnologias no SUS – CONITEC;  
Considerando a Portaria nº 9/SCTIE/MS, de 22 de abril de 2014; e  
Considerando a avaliação da Assessoria Técnica da Secretaria de Atenção à Saúde - SAS, resolve:  
Art. 1º  Ficam aprovadas, na forma do Anexo desta Portaria, o Protocolo Clínico e Diretrizes Terapêuticas – Linfoma Difuso de Grandes Células B.  
§ 1º  O protocolo e diretrizes objeto deste Artigo, que contêm o conceito geral linfoma difuso de grandes células B, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, são de caráter nacional e devem ser utilizadas pelas  
Secretarias de Saúde dos Estados e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
§ 2º  É obrigatória a cientificação ao paciente, ou ao seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizado para o tratamento do linfoma difuso de grandes células B.  
§ 3º  Os gestores estaduais e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 2º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 3º  Fica revogada a Portaria nº 621/SAS/MS, de 5 de julho de 2012, publicada no Diário Oficial da União nº 130, de 6 de julho de 2012, seção 1, páginas 6769.  
FAUSTO PEREIRA DOS SANTOS  
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS EM ONCOLOGIA LINFOMA DIFUSO DE GRANDES CÉLULAS B NO ADULTO

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Foi realizada em 30/01/2012 uma busca na base eletrônica Medline, acessada via PubMed, utilizando os descritores de interesse para linfoma difuso de grandes células B (“Diffuse Large B-Cell Lymphoma”): (systematic review [ti] OR meta-analysis [pt] OR meta-analysis [ti] OR systematic literature review [ti] OR (systematic review [tiab] AND review [pt]) OR consensus development conference [pt] OR practice guideline [pt] OR cochrane database syst rev [ta] OR acp journal club [ta] OR health technol assess [ta] OR evid rep technol assess summ [ta]) OR ((evidence based[ti] OR evidence-based medicine [mh] OR best practice* [ti] OR evidence synthesis [tiab]) AND (review [pt] OR diseases category[mh] OR behavior and behavior mechanisms [mh] OR therapeutics [mh] OR evaluation studies[pt] OR validation studies[pt] OR guideline [pt])) OR ((systematic [tw] OR systematically [tw] OR critical [tiab] OR (study selection [tw]) OR (predetermined [tw] OR inclusion [tw] AND criteri* [tw]) OR exclusion criteri* [tw] OR main outcome measures [tw] OR standard of care [tw] OR standards of care [tw]) AND (survey [tiab] OR surveys [tiab] OR overview* [tw] OR review [tiab] OR reviews [tiab] OR search* [tw] OR handsearch [tw] OR analysis [tiab] OR critique [tiab] OR appraisal [tw] OR (reduction [tw]AND (risk [mh] OR risk [tw]) AND (death OR recurrence))) AND (literature [tiab] OR articles [tiab] OR publications [tiab] OR publication [tiab] OR bibliography [tiab] OR bibliographies [tiab] OR published [tiab] OR unpublished [tw] OR citation [tw] OR citations [tw] OR database [tiab] OR internet [tiab] OR textbooks [tiab] OR references [tw] OR scales [tw] OR papers [tw] OR datasets [tw] OR trials [tiab] OR meta-analy* [tw] OR (clinical [tiab] AND studies [tiab]) OR treatment outcome [mh] OR

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
treatment outcome [tw])) NOT (letter [pt] OR newspaper article [pt] OR comment [pt]).  
Entre 103 referências encontradas, as 64 mais recentes (últimos cinco anos) foram selecionadas para revisão, das quais foram incluídos 22 estudos clínicos e metaanálises referentes a tratamento; e não foram considerados 20 estudos de ciência básica ou pré-clínica; 13 artigos sobre doenças fora do escopo deste Protocolo; 7 revisões narrativas ou estudos opinativos; e 2 textos sobre produtos sem registro na ANVISA.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Os linfomas (Doença de Hodgkin e Linfomas não Hodgkin) constituem um grupo de doenças neoplásicas malignas que se originam de células do sistema imunológico. Os Linfomas não Hodgkin (LNH) agressivos compreendem um grupo biológica e clinicamente heterogêneo de hemopatias malignas. Destes, o Linfoma Difuso de Grandes Células B (LDGC B) é o mais comum, correspondendo a cerca de 40% dos novos casos diagnosticados e a cerca de 30% de todos os casos de LNH. Juntamente com o Linfoma de Burkitt, o LDGC B é dos mais incidentes em indivíduos HIV positivos[1-4].  
O LDGC B pode-se manifestar nos linfonodos ou sítios extra-nodais, como osso, pele, tireoide, trato gastro-intestinal (TGI), sistema nervoso central (SNC) e testículo. A taxa de resposta completa (RC) a diversos tratamentos do LDGC B, encontrada em muitos estudos, varia entre 70% e 80%; e, há 25 anos, o tratamento padrão, com um índice de cura dos doentes adultos com LDGC B de 30% a 40%, é o CHOP (ciclofosfamida, doxorrubicina, vincristina e prednisona)[5-7].  
O Rituximabe é um anticorpo monoclonal quimérico contra o antígeno CD 20 presente na superfície dos linfócitos B normais e neoplásicos, que, quando associado ao CHOP (R-CHOP), conforme demonstrado estatisticamente, aumenta os percentuais de RC, de SLD e de sobrevida global (SG). Os resultados estatísticos conhecidos de

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
pesquisas feitas com o R-CHOP mostram um aumento de 20,6% na taxa de RC e uma diminuição de 31% no risco de morte em 04 anos. Um estudo da University of British Columbia (Vancouver, Canadá) mostrou que doentes com linfomas agressivos de célula B tratados com R-CHOP tiveram uma melhora absoluta de 18% na sobrevida livre de doença (SLD) em 02 anos e de 25% na sobrevida global (SG), quando comparado aos esquemas semelhantes ao CHOP, resultando numa diminuição de aproximadamente 50% no risco de morte nos primeiros 02 anos do diagnóstico[8-10].  
As taxas de SLD e SG dos doentes tratados com o R-CHOP permanecem estatisticamente superiores no seguimento de 05 anos. Em revisões sistemáticas envolvendo doentes de LDGC B, o uso associado na quimioterapia com finalidade curativa apresentou um impacto de mais de 11% de probabilidade de sobrevida em 36 meses. Quando comparados CHOP versus R-CHOP, os seguintes resultados se apresentaram no estudo GELA (idosos): 53% versus 36% vivos em 07 anos; no estudo E4494 (idosos): 74% versus. 63% vivos em 02 anos; e no estudo MinT (adultos): 95% versus 86% vivos. A quimioterapia com Rituximabe, no Canadá, aumentou a sobrevida em 2 anos para idosos (67% vs 40%) e adultos (87% vs 69%) com LDGC B[11-13].  
Não se recomenda o uso de Rituximabe em doentes de LDGC B com anti-HIV positivo, mesmo em associação a terapia anti-retroviral muito ativa e antibioticoterapia profilática, particularmente se os doentes apresentam contagem baixa de linfócitos CD4[14,15].  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
C-83.3 - Linfoma não-Hodgkin difuso de grandes células, reticulossarcoma ou sarcoma de células reticulares.  
4. DIAGNÓSTICO E ESTADIAMENTO  
O diagnóstico de LDGC B é estabelecido pela biopsia do tumor e, ao exame imuno-histoquímico ou de citometria de fluxo, a identificação de antígenos de linfócitos B (CD 19, 20, 22 e 79a), CD 45 e IgM de superfície[3,6,16].  
Os seguintes exames são necessários para a avaliação inicial do doente e da extensão da doença (estadiamento):  
- Exame físico;  
- Hemograma completo com contagem de plaquetas e reticulócitos;  
- Teste de Coombs;  
- Desidrogenase lática sérica;  
- Beta-2-microglobulina;  
- Exame sorológico para hepatite do tipo B e C;  
- Exame sorológico para HIV;  
- Biopsia de medula óssea;  
- Tomografia computadorizada (TC) tóraco-abdômino-pélvica ou Tomografia por emissão de pósitrons (PET-CT); e  
- Exame do líquor em caso de infiltração linfomatosa da medula óssea, SNC ou estrutura na cabeça e pescoço.  
O sistema de estadiamento preconizado é dado pela classificação - TNM – Classificação de Tumores Malignos – UICC (Ann Arbor)[17], em quatro estágios tumorais (estádios):  
|ESTÁDIO|EXTENSÃO DA DOENÇA|SUBESTÁDIO|
|---|---|---|
|I|Cadeia linfonodal única.|IE|
||Localização/órgão<br>extralinfático<br>único, localizado.||
|II|Duas ou mais cadeias linfonodais,||
||mesmo lado do diafragma.<br>Local/órgão extra-linfático único,|IIE|
||localizado, com seus||  
|**Ministério da Saúde**<br>**Secretaria de Atenção à Saúd**<br>linfonodos regionais, com ou sem<br> <br> <br> <br> <br>|**e**<br>|
|---|---|
|outras<br>cadeias<br>linfonodais<br>do<br>mesmo lado do diafragma.<br>||
|III<br>Cadeias linfonodais em ambos os<br>lados do diafragma com ou sem<br>local/órgão<br>extralinfático<br>único,<br>localizado.<br>|IIIE<br>|
|Baço.<br>|IIIS<br>|
|Ambos.<br>|IIIE+S<br>|
|IV<br>Comprometimento<br>difuso<br>ou<br>multifocal<br>de<br>órgão(s)<br>||
|extralinfático(s)<br>com<br>ou<br>sem<br>linfonodo(s)<br>||
|regional(ais); órgão extralinfático<br>isolado e linfonodos não regionais.<br>||
|Qualquer<br>Sem perda de peso/febre/sudorese.<br>|A<br>|
|Com perda de peso/febre/sudorese.<br>Com a finalidade de estimar prognóstico, recomenda<br>fatores de risco segundo o Índice Prognóstico Internaciona<br>Idade maior do que 60 anos, estágio III ou IV, acometimento<br>nodal, perfomance status maior do que 2 e dosagem séric<br>além do limite máximo normal.<br>De acordo com o número de fatores presentes, c<br>grupos de risco[2,6]:<br>- Baixo risco: 0 ou 1 fator de risco;<br>- Risco intermediário-baixo: 2 fatores de risco;|B<br>-se registrar o número de<br>l (IPI), entre os seguintes:<br>de mais de um sítio extra-<br>a de desidrogenase láctica<br>lassificam-se os seguintes<br>|  
- Risco intermediário-alto: 3 fatores de risco;  
- Alto risco: 4 ou 5 fatores de risco.  
O IPI foi desenvolvido a partir de informações históricas sobre o tratamento de doentes com linfoma antes da introdução do rituximabe. Para doentes tratados com esquemas terapêuticos, quimioterápicos, contendo este medicamento, um agrupamento mais simples fornece boa discriminação prognóstica[18]:  
- Baixo risco: nenhum fator de risco;  
- Risco intermediário: 1 ou 2 fatores de risco;  
- Alto risco: 3, 4 ou 5 fatores de risco.  
Nos doentes com LDGC e infecção por HIV, o diagnóstico prévio de síndrome da imunodeficiência adquirida (AIDS/SIDA) e presença de 3 ou mais fatores de risco pelo IPI parecem indicar pior prognóstico[4].  
5. CRITÉRIOS DE INCLUSÃO  
- Idade de 18 ou mais anos.  
- Diagnóstico inequívoco de LDGC B.  
Nota: Doentes com LDGC B com menos de 18 anos devem ser avaliados e tratados segundo protocolos institucionais.  
6. OPÇÕES TERAPÊUTICAS  
- 6.1- Quimioterapia de 1ª linha  
6.1.1- CHOP  
Ciclofosfamida – 750mg/m2 – EV - Dia 1  
Doxorrubicina – 50mg/m2 – EV – D1  
Vincristina – 1,4mg/m2 (máximo de 2mg) – EV – D1  
Prednisona – 40mg/m2 – VO – D1 a D5  
Intervalo de 21 dias  
Total de ciclos = 06, podendo ser 08, se não se alcançar RC após o 4º ciclo ou se houver doença residual após o 6º ciclo. Porém, o tratamento deve ser suspenso na ausência de resposta após o 4º ciclo ou se houver progressão da doença na vigência da quimioterapia.  
NOTA: O CHOP aqui descrito, caracterizado como CHOP-21, pode ser substituído pelo CHOP-14. Embora haja outros esquemas quimioterápicos de 1ª linha, o CHOP deve ser considerado o de escolha[5].  
6.1.2- R-CHOP  
Indicado para doentes com mais de 18 anos de idade e diagnóstico histopatológico de LDGC B CD 20 positivo de novo, (ou seja, sem ser por evolução de outro tipo de linfoma), excluindo-se linfoma primário cerebral; em estágio III ou IV, ou em estádio I ou II com sintomas B ou com doença volumosa (maior do que 7,5 cm); sem tratamento prévio; e com resultado de exame sorológico negativo para HIV e incompatível com hepatite tipo B e tipo C ativa[9,10]. O Rituximabe não é indicado se o CHOP é contra-indicado.  
O esquema terapêutico consiste no CHOP (o mesmo do item 6.1.1) associado ao rituximabe (375mg/m2 – EV – D1 – antes dos demais quimioterápicos), administrado em intervalo de 21 dias por um total de seis (se se alcançar RC ao 4º ciclo) a oito ciclos (se não se alcançar RC após o 4º ciclo ou se houver doença residual após o 6º ciclo). Porém, o tratamento deve ser suspenso na ausência de resposta após o 4º ciclo ou se houver progressão da doença na vigência da quimioterapia.  
6.2- Quimioterapia de 2ª linha  
Indicada em caso de ausência de resposta após o 4º ciclo, ausência de RC após o 8º ciclo ou progressão na vigência da quimioterapia de 1ª linha, ou à primeira recidiva, utilizando-se esquemas terapêuticos como DHAP, ESHAP, EPOCH, ICE, MINE, com objetivo de identificar casos de doença sensível à quimioterapia e que possam se beneficiar de transplante autólogo de células tronco hematopoéticas [7,19-21].  
O total de ciclos é 06, podendo ser 08, se não se alcançar RC após o 4º ciclo ou se houver doença residual após o 6º ciclo, porém, o tratamento deve ser suspenso na ausência de resposta após o 4º ciclo ou se houver progressão da doença na vigência da quimioterapia. O número total de ciclos dependerá da resposta clínica obtida, tolerância do paciente e tratamento subsequentemente indicado – transplante de células-tronco hematopoéticas ou radioterapia.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Indicada com intuito paliativo em casos selecionados, quando houver ausência de resposta, progressão clínica ou recidiva após a quimioterapia de 2ª linha em doente com capacidade funcional classificada como Zubrod 0, 1 ou 2[19,22]. Utiliza-se esquema terapêutico não utilizado anteriormente como de 2ª linha.  
Total de ciclos = 06, podendo ser 08, se não se alcançar RC após o 4º ciclo ou se houver doença residual após os 06 ciclos. Porém, o tratamento deve ser suspenso na ausência de resposta após o 4º ciclo ou se houver progressão da doença na vigência da quimioterapia.  
6.4- Fator estimulante de crescimento de colônias de granulócitos  
Reservado para os casos de doentes intensamente neutropênicos, em intervalo de quimioterapia (fora do nadir) e impedidos de receber a quimioterapia programada[23]. Caso as neutropenias (fora do nadir) se repetirem em pelo menos dois ciclos consecutivos, comprovadas por hemograma, pode-se adotar o tratamento profilático com o fator estimulante.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A indicação de TCTH autólogo se faz para doentes com recidiva sensível à quimioterapia de 2ª linha, medicamente aptos para o procedimento.  
O uso do rituximabe no tratamento inicial não limita a indicação de TCTH, mas pacientes primariamente refratários ou com recidiva resistente ao tratamento de 2ª linha não se beneficiam desta modalidade terapêutica. A obtenção de células–tronco

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
para o procedimento pode ser feita da medula óssea (punção aspirativa) ou, preferencialmente, a partir do sangue periférico (aférese)[25-27].  
As indicações e os procedimentos de TCTH devem observar o Regulamento Técnico do Sistema Nacional de Transplante em vigor no Brasil.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A radioterapia não é uma modalidade terapêutica de uso estabelecido para doentes com LDGC B, ficando a sua utilização a critério das condutas adotadas nos serviços[28,29].  
NOTA 1: Embora ainda sem evidência consistente de efetividade, a quimioterapia intratecal profilática tem sido indicada no tratamento inicial ou da doença recidivada, em casos de estádio IV, massa paravertebral e acometimento primário de sítios na cabeça.  
NOTA 2: Esgotadas as possibilidades terapêuticas descritas no item 6, o atendimento do doente assume caráter paliativo e deve ser privilegiado o controle de sintomas e a preservação da qualidade de vida.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O exame físico e os exames complementares de resultado anormal à avaliação inicial do doente e da extensão da doença (estadiamento) devem ser repetidos para a avaliação da resposta terapêutica ao final do 4º ciclo (se o doente apresentar RC ao exame físico) e do último ciclo da quimioterapia planejada (6º, se alcançada RC ao 4º ciclo, ou 8º, se não alcançada RC ao 4º ciclo), sendo a resposta terapêutica assim estabelecida:  
- Resposta Completa (RC) - Quando há o desaparecimento total da(s) lesão(ões) previamente existente(s). Sem aparecimento de novas lesões.  
- Resposta Parcial (RP) - Quando se observa uma redução de, no mínimo, 50% da(s) lesão(ões) previamente existente(s). Sem aparecimento de novas lesões.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Doença Estável (DE) - Redução inferior a 50% ou aumento inferior a 25%. Sem aparecimento de novas lesões.  
- Progressão de Doença (PD) - Aumento de 25%, ou mais, no tamanho de uma ou mais lesões, comparado à avaliação prévia, ou aparecimento de uma nova lesão.  
NOTA 1: Define-se como Recidiva o reaparecimento de lesão antiga ou o aparecimento de nova lesão, após o alcance de resposta completa.  
NOTA 2: A TC é o exame de imagem padrão para avaliar a resposta terapêutica, podendo ser substituída pela PET-CT, se disponível na avaliação final, ao término da quimioterapia.  
7.2. CRITÉRIOS DE INTERRUPÇÃO DO TRATAMENTO  
A quimioterapia deve ser suspensa, temporária ou definitivamente, na ocorrência de:  
- Graus de toxicidade 3 e 4, conforme os parâmetros mensuráveis do National Cancer Institute - NCI, de uso internacional.  
- Capacidade funcional do doente, também mensurada como medida dos graus de toxicidade 3 e 4, utilizando-se os critérios propostos pelo Eastern Cooperative Oncology Group - ECOG.  
- Ausência de resposta após o 4º ou o 8º ciclo.  
- Progressão de doença.  
- Falta de aderência ao tratamento.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O acompanhamento pós-tratamento para doentes com LDGC-B visa à identificação e tratamento de complicações do tratamento e recidivas da doença. Apesar de potencialmente curável, 10% a 65% dos pacientes apresentarão recidiva da doença, a depender do estádio clínico e do IPI; quando a recidiva ocorre após um ano do tratamento, recomenda-se a repetição da biópsia para confirmar o tipo histopatológico do linfoma. Após o tratamento, deve-se atentar para o rastreamento

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
de infertilidade, hipotiroidismo (irradiação do pescoço), cárie e doença periodontal (irradiação da boca e glândulas salivares), mielodisplasia e neoplasias malignas secundárias, tais como leucemia mieloide aguda, câncer de mama, melanoma e câncer do colo uterino[6,34,35].  
Inexiste evidência inquestionável de que exames de imagem no paciente em remissão completa possam melhorar a sobrevida com o diagnóstico precoce de recaída. Além do mais, algumas alterações de imagem podem levar a resultado falso positivo, passando esses exames a representarem fonte de ansiedade. Assim, exame de imagem deve ser solicitado conforme os achados anormais ao exame físico, na suspeita de recaída. A PET-CT não deve ser indicada no acompanhamento de doentes com LBGC B tratados.  
Além de vacinação anual para influenza e antipneumocócica a cada cinco anos,  
recomenda-se:  
A cada 3 meses, por dois anos e semestral no terceiro ano:  
- exame físico, atentando em especial para os linfonodos superficiais, pele,  
- tireoide, tórax e abdome; e  
- hemograma e dosagem de desidrogenase lática sérica; e  
- dosagem de hormônio tireoestimulante (TSH), se houve irradiação do pescoço. A cada 6 meses, no quarto e quinto ano de seguimento:  
- exame físico, atentando em especial para os linfonodos superficiais, pele,  
- tireoide, tórax e abdome; e  
- hemograma e dosagem de desidrogenase lática sérica.  
Anualmente, no quarto e quinto ano de seguimento:  
- dosagem de hormônio tireoestimulante (TSH), se houve irradiação do pescoço.  
9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR  
Doentes com diagnóstico de linfoma difuso de grandes células B devem ser atendidos em hospitais habilitados em oncologia com porte tecnológico suficiente para diagnosticar, tratar e realizar o seu acompanhamento.  
Além da familiaridade que esses hospitais guardam com o estadiamento, o tratamento, o manejo das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
Os procedimentos radioterápicos (Grupo 03, Subgrupo 01) e de transplantes (Grupo 05, Subgrupo 05) da Tabela de Procedimentos, Medicamentos e OPM do SUS podem ser acessados, por código do procedimento ou nome do procedimento e por código da CID – Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde – para a respectiva neoplasia maligna, no SIGTAP-Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela- <u>unificada/app/sec/inicio.jsp), com versão mensalmente disponibilizada.</u>  
São os seguintes os procedimentos da tabela do SUS para a quimioterapia de adultos com linfoma difuso de grandes células B:  
03.04.06.013-5 - Quimioterapia de linfoma não Hodgkin de graus de malignidade intermediário ou alto – 1ª linha  
03.04.06.022-4 - Quimioterapia de linfoma difuso de grandes células B – 1ª linha (excludente com o procedimento 03.04.06.013-5 Quimioterapia de Linfoma não Hodgkin de Grau Intermediário ou Alto – 1ª linha)  
03.04.06.011-9 - Quimioterapia de linfoma não Hodgkin grau intermediário ou alto - 2ª linha  
03.04.06.012-7 - Quimioterapia de linfoma não Hodgkin grau intermediário ou alto - 3ª linha  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações  
de controle e avaliação. Ações de controle e avaliação incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos); a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente - primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica) e análise dos percentuais de LDGC B entre o total de LNH de graus intermediário e alto e entre o total de todos os procedimentos de LNH.  
Ações de auditoria devem verificar in loco, por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico (LDGC B e CD 20 positivo); compatibilidade do procedimento codificado com o diagnóstico e capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Exceto pela Talidomida para o tratamento de Mieloma Múltiplo e pelo Mesilato de Imatinibe para a quimioterapia do Tumor do Estroma Gastrointestinal (GIST), da Leucemia Mieloide Crônica e Leucemia Linfoblástica Aguda cromossoma Philadelphia positivo, o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo  
procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do medicamento antineoplásico é desse hospital, seja ele público ou privado, com ou sem fins lucrativos.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
1 - Simon R, Durrleman S, Hoppe RT, Bonadonna G, Bloomfield CD, Rudders RA, et al. The Non-Hodgkin Lymphoma Pathologic Classification Project. Long-term followup of 1153 patients with non-Hodgkin lymphomas. Ann Intern Med. 1988 Dec 15;109(12):939-45.  
2 - The International Non-Hodgkin's Lymphoma Prognostic Factors Project. A predictive model for aggressive non-Hodgkin's lymphoma. The International Non-Hodgkin's Lymphoma Prognostic Factors Project. N Engl J Med. 1993 Sep 30;329(14):987-94.  
3 - Harris NL, Jaffe ES, Diebold J, Flandrin G, Muller-Hermelink HK, Vardiman J. Lymphoma classification--from controversy to consensus: the R.E.A.L. and WHO Classification of lymphoid neoplasms. Ann Oncol. 2000;11 Suppl 1:3-10.  
4 - Tanaka PY, Pracchia LF, Bellesso M, Chamone DA, Calore EE, Pereira J. A prognostic score for AIDS-related diffuse large B-cell lymphoma in Brazil. Ann Hematol. 2009 Jun 4.  
5 - Hallack Neto AE, Pereira J, Beitler B, Chamone DA, Llacer PD, Dulley FL, et al. Results of CHOP chemotherapy for diffuse large B-cell lymphoma. Braz J Med Biol Res. 2006 Oct;39(10):1315-22.  
6 - Jost L. Newly diagnosed large B-cell non-Hodgkin's lymphoma: ESMO clinical recommendations for diagnosis, treatment and follow-up. Ann Oncol. 2007;18 Suppl 2:ii55-6.  
7 - Flowers CR, Sinha R, Vose JM. Improving outcomes for patients with diffuse large B-cell lymphoma. CA Cancer J Clin. 2010;60(6):393-408.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
8 - Sehn LH, Donaldson J, Chhanabhai M, Fitzgerald C, Gill K, Klasa R, et al. Introduction of combined CHOP plus rituximab therapy dramatically improved outcome of diffuse large B-cell lymphoma in British Columbia. J Clin Oncol. 2005 Aug 1;23(22):5027-33.  
9 - Pfreundschuh M, Trumper L, Osterborg A, Pettengell R, Trneny M, Imrie K, et al. CHOP-like chemotherapy plus rituximab versus CHOP-like chemotherapy alone in young patients with good-prognosis diffuse large-B-cell lymphoma: a randomised controlled trial by the MabThera International Trial (MInT) Group. Lancet Oncol. 2006 May;7(5):379-91.  
10 - Coiffier B, Lepage E, Briere J, Herbrecht R, Tilly H, Bouabdallah R, et al. CHOP chemotherapy plus rituximab compared with CHOP alone in elderly patients with diffuse large-B-cell lymphoma. N Engl J Med. 2002 Jan 24;346(4):235-42.  
11 - Molina A. A decade of rituximab: improving survival outcomes in nonHodgkin's lymphoma. Annu Rev Med. 2008;59:237-50.  
12 - Hill M, Kyle F. NHL (diffuse large B-cell lymphoma). Clin Evid (Online). 2010;2010.  
13 - Gao G, Liang X, Jiang J, Zhou X, Huang R, Chu Z, et al. A systematic review and meta-analysis of immunochemotherapy with rituximab for B-cell non-Hodgkin's lymphoma. Acta Oncol. 2010;49(1):3-12.  
14 - Kaplan LD, Lee JY, Ambinder RF, Sparano JA, Cesarman E, Chadburn A, et al. Rituximab does not improve clinical outcome in a randomized phase 3 trial of CHOP with or without rituximab in patients with HIV-associated non-Hodgkin lymphoma: AIDS-Malignancies Consortium Trial 010. Blood. 2005 Sep 1;106(5):1538-43.  
15 - Levine AM. HIV-associated lymphoma. Blood. 2010 Apr 15;115(15):2986-7.  
16 - Costa FPS, Pereira FG, Vassalo J, Freitas LLL, Lorand-MetzeI I. A utilidade da citologia por punção com agulha fina aliada a imunofenotipagem no diagnóstico dos linfomas não-Hodgkin. Rev Bras Hematol Hemoter. 2005;27(1):16-20.

---

<!-- METADADOS: doenca: Linfoma Difuso de Grandes Células B | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
17 - International Union Against Cancer. TNM: classificação de tumores malignos, 6a. ed. Rio de Janeiro: INCA, 2004. 254p.  
18 - Sehn LH, Berry B, Chhanabhai M, Fitzgerald C, Gill K, Hoskins P, et al. The revised International Prognostic Index (R-IPI) is a better predictor of outcome than the standard IPI for patients with diffuse large B-cell lymphoma treated with R-CHOP. Blood. 2007 Mar 1;109(5):1857-61.  
19 - Seshadri T, Kuruvilla J, Crump M, Keating A. Salvage therapy for relapsed/refractory diffuse large B cell lymphoma. Biol Blood Marrow Transplant. 2008;14(3):259-67.  
20 - Gisselbrecht C, Mounier N. Improving second-line therapy in aggressive nonHodgkin's lymphoma. Semin Oncol. 2004 Feb;31(1 Suppl 2):12-6.  
21 - Prichard M, Harris T, Williams ME, Densmore JJ. Treatment strategies for relapsed and refractory aggressive non-Hodgkin's lymphoma. Expert Opin Pharmacother. 2009 Apr;10(6):983-95.  
22 - Salminen E, Nikkanen V, Lindholm L. Palliative chemotherapy in nonHodgkin's lymphoma. Oncology. 1997 Mar-Apr;54(2):108-11.  
23 - Lyman GH. Guidelines of the National Comprehensive Cancer Network on the use of myeloid growth factors with cancer chemotherapy: a review of the evidence. J Natl Compr Canc Netw. 2005 Jul;3(4):557-71.  
24 - van Kampen RJ, Canals C, Schouten HC, Nagler A, Thomson KJ, Vernant JP, et al. Allogeneic stem-cell transplantation as salvage therapy for patients with diffuse large B-cell non-Hodgkin's lymphoma relapsing after an autologous stem-cell transplantation: an analysis of the European Group for Blood and Marrow Transplantation Registry. J Clin Oncol. 2011;29(10):1342-8.  
25 - Baldissera R, Bigni R, Neto AEH, Dias DF, Souza RA, Chiattone CS, et al. O transplante de células-tronco hematopoéticas no tratamento dos linfomas não Hodgkin. Rev Bras Hematol Hemoter. 2010;32(Supl.1):106-14.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
26 - Oliansky DM, Czuczman M, Fisher RI, Irwin FD, Lazarus HM, Omel J, et al. The role of cytotoxic therapy with hematopoietic stem cell transplantation in the treatment of diffuse large B cell lymphoma: update of the 2001 evidence-based review. Biol Blood Marrow Transplant. 2011;17(1):20-47 e30.  
27 - Smith SD, Bolwell BJ, Rybicki LA, Kang T, Dean R, Advani A, et al. Comparison of outcomes after auto-SCT for patients with relapsed diffuse large B-cell lymphoma according to previous therapy with rituximab. Bone Marrow Transplant. 2011;46(2):262-6.  
28 - Lowry L, Smith P, Qian W, Falk S, Benstead K, Illidge T, et al. Reduced dose radiotherapy for local control in non-Hodgkin lymphoma: a randomised phase III trial. Radiother Oncol. 2011 Jul;100(1):86-92.  
29 - Akoum R, Brihi E, Saade M, Hanna T, Chahine G. Salvage abdominal irradiation for refractory non-Hodgkin's lymphoma. J Cancer Res Ther. 2007 JulSep;3(3):143-9.  
30 - Terasawa T, Dahabreh IJ, Nihashi T. Fluorine-18-fluorodeoxyglucose positron emission tomography in response assessment before high-dose chemotherapy for lymphoma: a systematic review and meta-analysis. Oncologist. 2010;15(7):750-9.  
31 - Terasawa T, Lau J, Bardet S, Couturier O, Hotta T, Hutchings M, et al. Fluorine-18-fluorodeoxyglucose positron emission tomography for interim response assessment of advanced-stage Hodgkin's lymphoma and diffuse large B-cell lymphoma: a systematic review. J Clin Oncol. 2009;27(11):1906-14.  
32 - Terasawa T, Nagai H. Current clinical evidence on interim fluorine-18 fluorodeoxy glucose positron emission tomography for advanced-stage Hodgkin lymphoma and diffuse large B-cell lymphoma to predict treatment outcomes. Leuk Lymphoma. 2009;50(11):1750-2.  
33 - Hosein PJ, Lossos IS. The evolving role of F-FDG PET scans in patients with aggressive non-Hodgkin's lymphoma. European J Clin Med Oncol. 2010 Feb;2(1):131-8.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
34 - Tilly H, Dreyling M. Diffuse large B-cell non-Hodgkin's lymphoma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2010;21 Suppl 5:v172-4.  
35 - Wolach O, Bairey O, Lahav M. Late-onset neutropenia after rituximab treatment: case series and comprehensive review of the literature. Medicine (Baltimore). 2010;89(5):308-18.

---

