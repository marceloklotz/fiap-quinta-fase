<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 04, de 10 de janeiro de 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas para Imunossupressão no Transplante Hepático em Pediatria.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS - Substituta, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a imunossupressão no transplante hepático em pediatria no Brasil e diretrizes nacionais para as indicações, prescrições e acompanhamento dos indivíduos com esta condição;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 404/2018 e o Relatório de Recomendação n<sup><u>o</u></sup> 415 – Dezembro de 2018 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Imunossupressão no Transplante Hepático em Pediatria.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral de imunossupressão no transplante hepático em pediatria, indicações, critérios de inclusão, prescrições e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para a imunossupressão no transplante hepático em pediatria.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa condição em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria n<sup>o</sup> 1.322/SAS/MS, de 25 de novembro de 2013, publicada no Diário Oficial da União nº 230, de 27 de novembro de 2013, seção 1, páginas 150 a 153.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
VANIA CRISTINA CANUTO SANTOS  
1

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
IMUNOSSUPRESSÃO NO TRANSPLANTE HEPÁTICO EM PEDIATRIA

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A metodologia utilizada na elaboração do presente PCDT foi a metodologia  GRADE (Grading of Recommendations Assessment, Development, and Evaluation)<sup>(1)</sup> . Uma reunião presencial para a definição do escopo do PCDT foi realizada com a participação do Grupo Elaborador (GE) do PCDT, composto de especialistas e metodologistas, e um membro da CONITEC, integrante do Comitê Gestor do PCDT. Para cada incerteza clínica ou tecnologia não incorporada no SUS, uma questão de pesquisa estruturada, de acordo com o acrônimo PICO, foi elencada para nortear a busca pelas evidências científicas.  
Por meio de um processo sistemático, os dados dos estudos identificados para cada questão de pesquisa foram extraídos e avaliados em relação à qualidade da evidência. A qualidade da evidência dos estudos incluídos no corpo da evidência pode ser avaliada como alta, moderada, baixa ou muito baixa ( **Tabela A** ).  
**Tabela A –** Graduação da qualidade da evidência. Fonte: Schünemann et al.<sup>(1)</sup> .  
||**Qualid**|**ade da evidência**||
|---|---|---|---|
|**Alta**|**Moderada**|**Baixa**|**Muito Baixa**|
|Há uma maior confiança|A confiança na estimativa do|A confiança na estimativa do|Há muita pouca confiança na|
|de que o verdadeiro<br>efeito está próximo da<br>estimativa do efeito.|efeito é moderada: o efeito<br>verdadeiro provavelmente<br>está próximo da estimativa<br>do efeito, mas existe a<br>possibilidade de que seja<br>substancialmente diferente.|efeito é limitada: o verdadeiro<br>efeito pode ser<br>substancialmente diferente da<br>estimativa do efeito.|estimativa do efeito: o efeito<br>verdadeiro provavelmente será<br>substancialmente diferente da<br>estimativa do efeito.|  
Com base na graduação da qualidade da evidência e nos demais critérios considerados pela metodologia GRADE para julgar a direção e a força das recomendações, as recomendações baseadas em evidência foram obtidas por consenso pelo grupo (painel de especialistas).  
Para formular as recomendações considera-se a direção (a favor ou contra) e a graduação da força (forte ou condicional) da recomendação<sup>(1)</sup> ( **Tabela B** ).  
**Tabela B –** Força da recomendação. Fonte: Schünemann et al.<sup>(1)</sup> .  
||**Força da Recomendação**<br>|
|---|---|
|Forte|Condicional|
|<br>O Grupo Elaborador está confiante de|<br>Os efeitos desejáveis provavelmente superam os efeitos indesejáveis. No|
|que os efeitos desejáveis de uma|entanto, existe uma incerteza considerável.|
|intervenção<br>superam<br>seus<br>efeitos|<br>Implica que nem todos os indivíduos serão mais bem atendidos pelo curso|
|indesejáveis<br>ou<br>que<br>os<br>efeitos|de ação recomendado;|
|indesejáveis<br>de<br>uma<br>intervenção|<br>Há uma necessidade de considerar, com mais cuidado do que o habitual, as|
|superam seus efeitos desejáveis.|circunstâncias, preferências e valores individuais do paciente.|
|<br>Implica que a maioria ou todos os|<br>Os cuidadores precisam alocar mais tempo para a tomada de decisão|
|indivíduos serão mais bem atendidos|compartilhada, certificando-se de que eles expliquem de forma clara e|
|pelo curso de ação recomendado.|abrangente os possíveis benefícios e danos para o paciente.|  
2  
A descrição detalhada de toda a metodologia utilizada na elaboração do PCDT (questões de pesquisas definidas pelos especialistas na reunião de definição de escopo, elaboração das estratégias de busca, descrição do fluxo de seleção das evidências científicas) e as tabulações dos dados de cada um dos estudos incluídos, para cada questão de pesquisa, referentes às características dos participantes, características dos estudos e desfechos de eficácia e segurança, quando aplicável, encontram-se no **Apêndice 1** .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O transplante de fígado é a terapia definitiva para os pacientes em insuficiência hepática, sejam adultos ou crianças<sup>(2-4)</sup> . Inúmeros avanços nas diversas fases do transplante de fígado têm possibilitado excelentes resultados em crianças com doença hepática aguda ou crônica, bem como a ampliação do rol de indicações com a inclusão dos tumores hepáticos e dos erros inatos do metabolismo com ou sem envolvimento hepático<sup>(2, 4)</sup> . Dados publicados recentemente mostram sobrevida do paciente pediátrico de 94% em 1 ano, 91% em 5 anos e 88% em 10 anos após o transplante de fígado<sup>(4, 5)</sup> .  
O Brasil é o segundo país em número absoluto de transplante de fígado<sup>(6)</sup> . Em 2015, foi relatado que o número desses transplantes em pediatria nos últimos anos tinham-se mantido inferior a 200 transplantes por ano<sup>(6)</sup> . Sobrevida superior a 90% ao final do primeiro ano de transplante de fígado em crianças tem sido alcançada por alguns grupos transplantadores brasileiros<sup>(7, 8)</sup> .  
Dados do Sistema Nacional de Tansplantes mostram que, no Brasil, houve aumento do número de transplantes de fígado nos últimos anos, variando de 1.322, em 2009 (no SUS), para 2.118, em 2017 (no SUS e não SUS). Em doentes de até 18 anos de idade, esses números foram, respespectivamente, 177 e 208. O número de equipes transplantadoras de fígado aumentou de 44 em 2009 para 76 em 2017.  
Parte da melhora na sobrevida após transplante foi resultante do aprimoramento no uso dos imunossupressores e de melhor equilíbrio entre rejeição e infecção<sup>(4)</sup> . Contudo, até dois terços dos óbitos tardios podem ser atribuídos a complicações da imunossupressão como infecções e neoplasias<sup>(2, 4, 9, 10)</sup> .  
Quando um órgão ou tecido de um indivíduo é transplantado em um receptor geneticamente não idêntico, uma série de eventos celulares e moleculares é iniciada como resposta imunológica e de rejeição ao enxerto<sup>(11)</sup> . A terapia imunossupressora, por meio da administração de diferentes agentes farmacológicos, tem por objetivo controlar essa resposta imunológica, evitando a rejeição e a perda do órgão transplantado.  
A imunossupressão pode ser dividida em três fases: indução, manutenção e tratamento de rejeição. Na fase de indução da imunossupressão básica, agentes imunossupressores são administrados para inibir o reconhecimento imune ou bloquear linfócitos imunoativos. A fase de manutenção da imunossupressão básica visa prevenir a estimulação do sistema imunológico por meio do bloqueio de receptores moleculares específicos<sup>(12, 13)</sup> .Em relação à fase de rejeição, esta pode ocorrer em 15% a 30% dos receptores de fígado adultos, mesmo sob imunossupressão<sup>(14)</sup> . Em crianças, a porcentagem se eleva até 60% e ocorrem comumente nos primeiros seis meses do transplante<sup>(4, 15)</sup> . Para o tratamento da rejeição, agentes imunossupressores são utilizados para bloquear a resposta imunológica contra o enxerto<sup>(12, 13)</sup> .  
A imunossupressão na criança é geralmente mais complexa e desafiadora quando comparada com o uso de medicamentos imunossupressores pelos pacientes adultos transplantados de fígado.  
A população pediátrica usualmente requer doses de imunossupressores proporcionalmente maiores que as dos adultos para que os níveis sanguíneos adequados sejam atingidos<sup>(4, 13)</sup> .  
As particularidades fisiológicas da criança alteram a farmacocinética dos imunossupressores, afetando sua absorção, distribuição, metabolismo e  excreção dos medicamentos<sup>(2, 4)</sup> . A capacidade de deglutição de cápsulas e comprimidos é variável de criança para criança, e a impossibilidade de administração às lactentes e crianças pequenas exige formulação em solução ou manipulação para a forma líquida, com risco de variação na concentração do medicamento a cada preparação. Eventualmente, as soluções orais podem ser pouco palatáveis, exigindo a utilização de sonda gástrica ou enteral para a sua administração.  
As concentrações sanguíneas dos medicamentos podem variar conforme a formulação utilizada, exigindo a atenção quando da modificação da apresentação administrada. A interação com a dieta, suplementos e outros medicamentos pode variar significativamente de uma apresentação para outra.  
3  
As crianças são dependentes de seus cuidadores para receberem a medicação e todos os indivíduos envolvidos no cuidado devem ser orientados sobre o uso dos imunossupressores. Instabilidade na relação intrafamiliar pode trazer risco de erros de administração de medicamentos<sup>(4)</sup> .  
As crianças transplantadas de fígado têm expectativa de uso de imunossupressores por longos períodos, com impacto no crescimento e desenvolvimento, no risco de infecções virais, bacterianas e fúngicas, no risco de neoplasias e, consequentemente, na adesão ao tratamento<sup>(4)</sup> .  
Nas últimas décadas, novos agentes imunossupressores foram desenvolvidos oferecendo alternativas e possibilidades de combinações para a prevenção e o tratamento da rejeição ao enxerto e dos efeitos adversos destes medicamentos. Entretanto, há poucos estudos clínicos com dados robustos para o uso racional desses novos agentes na faixa etária pediátrica, exigindo adaptação dos resultados observados em adultos e provocando a utilização off-label (sem indicação em bula) desses medicamentos<sup>(2, 11)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Serão considerados elegíveis para este Protocolo Clínico e Diretrizes Terapêuticas (PCDT) os pacientes com até 18 anos,  
submetidos a transplante de fígado.  
**4. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- Z94.4 Transplante hepático  
- T86.4 Falência ou rejeição de transplante de fígado

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
- **a. Diagnóstico de rejeição no transplante de fígado**  
Define-se a rejeição pela piora aguda da função do enxerto, sendo mais comum nos primeiros 6 meses após o procedimento. No entanto, pode se manifestar após 6 meses do transplante e até anos mais tarde, em geral quando há mudanças na imunossupressão<sup>(16)</sup> .  
A rejeição aguda pode ser classificada em:  
Rejeição hiperaguda (humoral) – mediada por anticorpo, se desenvolve em pacientes com anticorpos anti-doador. Em geral  
as manifestações de falência do enxerto ocorrem nos 2 primeiros dias pós-transplante e em 0,3%-2% dos transplantes em pacientes altamente sensibilizados.  
Rejeição aguda celular (RAC) – mediada pelas células T, envolve leucócitos T citotóxicos (CD8+), células T auxiliares (CD4+), macrófagos e plasmócitos. A probabilidade de um episódio de rejeição celular aguda ocorrer dentro de 5 anos após o transplante de fígado está em torno de 60%<sup>(17)</sup> .  
O diagnóstico das rejeições agudas é composto pelas etapas clínicas, laboratoriais e histológica:  
**Diagnóstico clínico:** pode ser realizado em qualquer época de vida do enxerto. As manifestações clínicas podem variar desde ausentes até presença de icterícia, febre, dor abdominal intensa e aumento da ascite;  
**Diagnóstico laboratorial:** elevação das enzimas hepáticas (AST, ALT, GGT) e bilirrubina direta compõem as alterações laboratoriais observadas nas rejeições agudas. O hemograma pode se alterar com leucocitose e eosinofilia. Pode ocorrer alteração na coagulação (Razão Internacional Normalizado ou International Normalized Ratio - INR prolongado). Em pacientes muito sensibilizados (por ex. transfusões excessivas pré transplante), pode haver a presença de anticorpos doador específico (Donor Specific Antibodies - DSA). Títulos maiores de 15.000 pela técnica de intensidade média de fluorescência (MFI) sugere positividade de DSA.  
**Diagnóstico histológico:** O diagnóstico confirmatório é essencialmente histológico. Recomenda-se fazer biópsia hepática na suspeita clínica e laboratorial de RAC. Atualmente, utilizam-se os critérios de Banff<sup>(18)</sup> para graduar a gravidade da rejeição mediada pelas células T em leve, moderada e grave. Os critérios globais incluem:  
4  
- a) Leve: infiltrado linfocitário discreto nas áreas do espaço porta ou perivenulares;  
- b) Moderada: infiltrado linfocitário moderado, acometendo a maioria dos espaços porta ou áreas perivenulares com necrose confluente/presença de apoptose;  
- c) Grave: infiltrado linfocitário intenso, com derramamento (spillover) para áreas periportais ou moderada a grave inflamação perivenular que se estende ao parênquima hepático.  
- A graduação (por pontuação) quantitativa é necessária e é chamada índice de atividade de rejeição (Rejection Activity  
Index - RAI). Quanto maior a pontuação, mais grave é a rejeição aguda ( **Tabela C** ).  
**Tabela C –** Índice de atividade de rejeição: critérios utilizados para classificar biópsias de aloenxerto hepático com rejeição aguda. Adaptado de acordo com os critérios de Banff<sup>(18)</sup> .  
|**Categoria**|**Critério**|**Pontuação**|
|---|---|---|
|Inflamação|Principalmente inflamação linfocítica envolvendo, mas não notavelmente em expansão, uma|1|
|Portal|minoria dos espaços portais.||
||Expansão da maioria ou de todas as áreas portais por infiltrado misto contendo linfócitos com<br>ocasionais blastos, neutrófilos e eosinófilos. Se os eosinófilos forem conspícuos e<br>acompanhados por edema e a hipertrofia das células endoteliais microvasculares for<br>proeminente, a rejeição aguda mediada por anticorpos (AMR) deve ser considerada.|2|
||Marcada expansão da maioria ou de todos os espaços portais com infiltrado misto contendo<br>numerosos blastos e eosinófilos, com extravasamento inflamatório no parênquima periportal|3|
|Danos<br>na<br>Inflamação<br>do|Uma minoria dos ductos é permeada por células inflamatórias e mostra apenas alterações<br>reativas discretas, como aumento da relação nuclear/citoplasmática das células epiteliais|1|
|Ducto Biliar|A maioria ou todos os ductos são permeados por células inflamatórias. Ductos biliares, mais<br>do que ocasionalmente, mostram alterações degenerativas como pleomorfismo nuclear,<br>alterações na polaridade e vacuolização citoplasmática em células epiteliais|2|
||Como citado no item 2, com a maioria ou todos os ductos biliares apresentando alterações<br>degenerativas, além de perda da estrutura ductal|3|
|Inflamação<br>endotelial|Infiltração linfocítica subendotelial envolvendo algumas, mas não a maioria das vênulas portal<br>e / ou hepática|1|
|venosa|Infiltração subendotelial envolvendo a maioria ou todos os ramos da veia porta e das veias<br>centrolobulares, com ou sem necrose / dropout conflitante de hepatócitos envolvendo uma<br>minoria de regiões perivenulares.|2|
||Assim como supracitado no item 2, com inflamação perivenular moderada ou grave que se<br>estende para o parênquima perivenular, associada à necrose perivenular de hepatócitos,<br>envolvendo a maioria das regiões perivenulares.|3|  
Mais recentemente em transplante de fígado tem sido descrita rejeição mediada por anticorpos específicos anti-HLA do doador (DSA), na grande maioria de classe II (loci DR). Normalmente o fígado transplantado não apresenta C4d no tecido hepático. Quando há presença de C4d na imuno-histoquímica (IH) – imunoperoxidase, na grande maioria das vezes, é caracterizada a rejeição mediada por anticorpos. Em geral ocorre nos primeiros 90 dias pós-transplante hepático, correspondendo a um grupo com risco de perda do enxerto. Nestes casos, segundo os critérios de Banff, recomenda-se fazer imunoperoxidase para C4d e anticorpos anti-HLA (DSA) nos casos graves de RAC.  
5

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Em relação ao diagnóstico, não há um critério específico clínico ou bioquímico para diagnóstico de rejeição crônica. Clinicamente pode aparecer icterícia, prurido ou obstrução biliar com aumento de bilirrubina direta, AST, ALT, gama GT e fosfatase alcalina. A recomendação é que o diagnóstico deve ser essencialmente histopatológico. A característica histológica é a ductopenia.  
A rejeição crônica, uma condição que pode levar à disfunção e fibrose do enxerto em longo prazo, pode ser precoce ou tardia. A incidência de rejeição crônica varia de 5 a 10% e é a principal causa de perda tardia do enxerto. Na fase precoce pode haver perda de menos de 50% dos ductos biliares envolvendo menos de 25% dos espaços portais, infiltrado perivenular, necrose lítica em zona 3 e fibrose perivenular. Na fase tardia há perda de mais de 50% dos ductos biliares, envolvendo mais de 50% dos espaços portais, graus de inflamação variáveis, obliteração focal, graus variados de fibrose em ponte, hiperplasia da intima, fibrose mural, colestase<sup>(19)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Recomenda-se como primeira linha de tratamento o uso do Tacrolimo (FK506) associado à metilprednisolona<sup>(20-22)</sup> .  
Recomenda-se a substituição do tacrolimo por ciclosporina nos casos de intolerância ou eventos adversos (exemplo: convulsões).  
Para casos de maior risco de rejeição (doador não isogrupo, retransplante, insuficiência hepática aguda grave) e pacientes com insuficiência renal prévia ou atual, recomenda-se como primeira linha de tratamento o uso da associação tacrolimo e basiliximabe. As evidências são limitadas em termos de número de estudos, porém evidenciam redução significante de RAC com o uso da associação basiliximabe + tacrolimo associado ou não ao corticosteroide<sup>(23-28)</sup> .  
Não é possível recomendar o uso da timoglobulina na fase de indução da imunossupressão do transplante hepático em pediatria. As evidências disponíveis não permitem concluir sobre a superioridade da timoglobulina em relação ao esquema de indução de imunossupressão recomendado como primeira linha, sendo que a maioria dos estudos não evidenciou diferenças significantes para os desfechos rejeição do enxerto, recorrência de hepatite C, sobrevida do enxerto ou global e infecção<sup>(29-39)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Recomenda-se a associação de tacrolimo e prednisolona/prednisona como primeira opção de imunossupressão na fase de manutenção da imunossupressão básica. A prednisolona/prednisona pode ser retirada no prazo variável, geralmente de três a seis meses após o transplante. Utiliza-se no pós-operatório imediato a metilprednisolona intravenosa e transaciona-se para prednisolona ou prednisona via oral assim que for possível. Recomenda-se não suspender o corticosteroide nos casos de hepatite autoimune, colangite esclerosante primária e evidência de rejeição. Recomenda-se a substituição do tacrolimo por ciclosporina nos casos de intolerância ou eventos adversos (exemplo: convulsões).  
Nos casos de alergia grave (anafilaxia) e neoplasias, recomenda-se a suspensão total do tacrolimo. Nos casos de disfunção renal grave ou doença linfoproliferativa, sugere-se diminuir a dose ou suspender o tacrolimo. Nessas situações, recomenda-se a substituição do tacrolimo por sirolimo ou everolimo<sup>(40)</sup> . Sirolimo pode ser usado em combinação com corticosteroide, micofenolato, dose baixa de inibidores da calcineurina ou como agente único. Recomenda-se cautela com o uso combinado de tacrolimo e sirolimo uma vez que, embora não reportado em população pediátrica, há evidências que demonstram um aumento na incidência de trombose da artéria hepática em população adulta com o uso dessa associação. O sirolimo pode ser utilizado em pacientes com rejeição crônica, toxicidade aos inibidores da calcineurina tais como disfunção renal, microangiopatia trombótica e doença linfoproliferativa póstransplante. Devido ao seu efeito anti-neoplásico, o sirolimo tem sido utilizado em transplante hepático associado a hepatoblastoma, angiosarcoma e outros<sup>(40)</sup> . As evidências provenientes de literatura publicada são de baixa qualidade, sendo que a maioria é representada por séries de casos e realizada na população adulta (especialmente no caso do everolimo) e não permitem embasar a recomendação, apesar de ser a conduta já adotada na prática clínica. No entanto há estudos de efetividade<sup>(41-45)</sup> e custo-efetividade (em pacientes transplantados renais)<sup>(46, 47)</sup> , conduzidos no âmbito nacional em população adulta, que embasam indiretamente a utilização desses fármacos na população pediátrica. Com base nas evidências científicas disponíveis, não é possível recomendar o sirolimo em  
6  
detrimento ao everolimo e vice-versa. A decisão acerca de qual terapia administrar fica condicionada ao critério do prescritor e disponibilidade do serviço. A azatioprina pode ser utilizada nos casos de hepatite autoimune de novo ou recorrente.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O tratamento na RAC é baseado nos critérios de gravidade de Banff<sup>(18)</sup> .  
Nos casos de RAC leve recomenda-se aumento das doses dos inibidores de calcineurina (tacrolimo ou ciclosporina) ou substituição da ciclosporina por tacrolimo.  
Quando a rejeição é moderada/grave são utilizadas altas doses de corticosteroides (bolus de metilprednisolona na dose de 10 a 20 mg/kg/dose, por três dias), seguido de prednisolona/prednisona (1 mg/kg/dia, por 30 dias) via oral com redução gradual da dose.  
Quando a rejeição é corticoresistente recomenda-se a utilização da preparação anti-linfocitária timoglobulina<sup>(48-55)</sup> . Podese também associar micofenolato de mofetila/sódico<sup>(56, 57)</sup> . **(GRADE: recomendação condicional; qualidade da evidência: muito baixa)**

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
As opções terapêuticas para o tratamento da rejeição crônica consistem em utilizar níveis séricos maiores de imunossupressores (em geral tacrolimo), conversão para diferentes imunossupressores (de ciclosporina para tacrolimo) ou adição de outros imunossupressores (micofenolato)<sup>(58-63)</sup> . Os pacientes pediátricos respondem relativamente bem ao aumento das doses dos imunossupressores, ou adição de outros imunossupressores (micofenolato). A falta de resposta indica a necessidade de retransplante. Não foram identificados estudos para o tratamento para a rejeição crônica. A literatura apresentada para a questão (ANEXO) referese à prática clínica anterior, quando a ciclosporina era utilizada como primeira linha de tratamento.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Na imunossupressão no transplante de fígado em pediatria poderão ser utilizados os seguintes fármacos, apresentados em ordem alfabética:  
- Azatioprina: comprimido de 50 mg;  
- Basiliximabe: frasco-ampola de 20 mg;  
- Ciclosporina: cápsulas de 25, 50 e 100 mg; solução oral de 100 mg/ml (frascos de 50 ml); frasco-ampola de 50 mg;  
- Everolimo: comprimidos de 0,5, 0,75 e 1 mg;  
- Metilprednisolona: solução injetável de 500 mg;  
- Micofenolato de mofetila: comprimidos de 500 mg;  
- Micofenolato de sódio: comprimidos de 180 e 360 mg;  
- Prednisolona: solução oral de 1 mg/ml ou 3 mg/ml;  
- Prednisona: comprimidos de 5 e 20 mg;  
- Sirolimo: comprimidos de 1 e 2 mg;  
- Timoglobulina: frasco-ampola de 25 mg;  
- Tacrolimo: cápsulas de 1 e 5 mg; frasco-ampola de 0,5 mg.  
7

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A dose oral inicial é de 0,15 a 0,2 mg/kg/dia dividida em duas administrações de forma consistente. Realizar jejum uma hora antes e uma hora depois da administração do medicamento. Não administrar este medicamento duas horas antes ou após o uso de antiácidos. A gastroenterite aguda pode aumentar a absorção e os níveis séricos de tacrolimo. O início da administração do tacrolimo é variável, geralmente nas primeiras 24 horas, dependendo das condições clínicas do paciente (insuficiência renal ou utilização do esquema de indução) ( **Tabela D** )<sup>(64)</sup> .  
**Tabela D –** Níveis sanguíneos de Tacrolimo na Imunossupressão Primária (fase de manutenção) e na Rejeição.  
|**Fases**|**Valores mínimos – máximos de níveis sanguíneos**|
|---|---|
|**IMUNOSSUPRESSÃO PRIMÁRIA**||
|Do 1° ao 14° dia|10 - 15 ng/mL|
|Do 15° ao 30° dia|5 - 10 ng/mL|
|Do 1° ao 3° mês|5 - 8 ng/mL|
|A partir do 3° mês|5 - 6 ng/mL|
|**TRATAMENTO DE REJEIÇÃO**||
|Rejeição aguda|10 - 15 ng/mL|
|Rejeição crônica/conversão de ciclosporina para tacrolimo|10 - 15 ng/mL|  
O tacrolimo tem estreita janela terapêutica, recomenda-se a monitorização do seu nível sérico, cuja frequência dependerá da fase do pós-operatório e do nível sérico do medicamento. Existe acentuada diferença inter e intra-indivíduo na farmacocinética. A meia-vida do medicamento em crianças é 50% inferior à dos adultos e o clareamento é 2 a 4 vezes maior; portanto as crianças necessitam de doses maiores para alcançar níveis similares de tacrolimo<sup>(64)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A solução oral, pouco palatável, deve ser diluída, de preferência, com suco de maçã, laranja ou outras bebidas. Quando houver associação com sirolimo, a ciclosporina deve ser administrada 4 horas antes.  
A taxa de metabolização da ciclosporina é maior em crianças, sendo a sua biodisponibilidade menor em pacientes mais jovens e correlaciona-se com a idade<sup>(40)</sup> . A presença de anastomose em Y-Roux altera a farmacocinética da ciclosporina de modo significativo em comparação aos adultos, nos quais a anastomose biliar ducto-ducto é a preferida.  
Preconiza-se a dose inicial de 5 a 15 mg/kg/dia dividido em 2 doses após o transplante. A ciclosporina sob forma de microemulsão tem biodisponibildade maior do que a formulação original.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Os níveis sanguíneos não são bons preditores de rejeição ou de evolução dos enxertos. Portanto, deve ser utilizada a dosagem do nível de concentração do medicamento 2 horas após a dose de ciclosporina ( **Tabela E** ).  
8  
**Tabela E –** Níveis sanguíneos de ciclosporina  
|**Tempo pós transplante (meses)**|**Nível vale**<br>**(ng/ml)**|**Nível 2h após a dose**<br>**(ng/ml)**|
|---|---|---|
|1 - 3 Meses|250 - 300|800 - 1200|
|4 - 8 Meses|200 - 250|600 - 1000|
|9 – 18 Meses|150 - 200|400 - 800|
|>18 Meses|50 - 150|200 - 600|

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O esquema do uso dos corticosteroides varia entre os diferentes programas de transplante. Um dos fatores a considerar é a indicação dos transplantes. Nos casos de infecções virais em atividade (por exemplo, hepatite C) há interesse em rapidamente diminuir a dose. Nos casos de doença autoimune, não há urgência na redução das doses. De uma maneira geral, inicia-se por ocasião da cirurgia com uma formulação intravenosa (geralmente metilprednisolona) que, tão logo seja possível, deve ser substituída por prednisona ou prednisolona, por via oral. A maioria dos centros de transplante pediátricos adota o esquema apresentado na **Tabela F** .  
**Tabela F –** Esquema de corticosteroides em transoperatória e manutenção do transplante de fígado  
|**Fases**|**Esquema d**|**e tratamento**|
|---|---|---|
||**Medicamento**|**Dose**|
|Intraoperatório após a revascularização<br>do enxerto|Metilprednisolona em infusão por via<br>intravenosa|10 mg/kg|
|||1º dia: 10 mg/kg/dia|
|||2º dia: 8 mg/kg/dia|
|||3º dia: 6 mg/kg/dia|
|Pós-operatório*|Prednisona ou prednisolona por via<br>oral|4º dia: 4 mg/kg/dia<br>5º dia: 2 mg/kg/dia|
|||6º dia até 10º dia:1 mg/kg/dia|
|||11º dia até o terceiro mês: manter 0,5<br>mg/kg/dia|  
*Dependendo da evolução, suspender o corticoide após o terceiro mês, com exceção dos casos de doença autoimune ou evidência de rejeição.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O esquema do uso do Basiliximabe de acordo com peso encontra-se na **Tabela G** .  
9  
**Tabela G –** Esquema de uso do Basiliximabe  
|**Peso (Kg)**|**Dose inicial**|**Segunda dose**|
|---|---|---|
|< 35 kg|10 mg IV 2x|10 mg - PO4|
|> 35 kg|20 mg IV 2x|20 mg - PO4|  
IV: intravenosa; PO: pós-operatório.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A timoglobulina (globulina antitimócito de coelhos) é utilizada no tratamento de rejeição aguda refratária ao tratamento com corticosteroides.  
Dose: 1,5 mg/kg/dia administrada por via endovenosa por 7 a 14 dias. Pré-medicação com corticosteroide, acetaminofeno ou antihistamínico pode reduzir as reações adversas relacionadas à infusão.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
São utilizados como agentes poupadores de inibidores da calcineurina em pacientes com rejeição crônica ou toxicidade acentuada aos inibidores da calcineurina. Os efeitos adversos gastrintestinais do micofenolato de mofetila podem melhorar com a conversão para micofenolato de sódio. O uso de ciclosporina aumenta a dose necessária de micofenolato de mofetila comparado às crianças que recebem tacrolimo.  
Micofenolato de mofetila: dose inicial de 10 a 20 mg/kg/dia ou 600 mg/m2 por dose (máximo 1g por dose) em duas administrações por via oral de 12/12 horas.  
Micofenolato de sódio: dose inicial de 7,5 a 15 mg/kg/dia ou 400 mg/m2 por dose (máximo de 1440 mg/dia), por via oral, de 12/12 horas.  
O ganciclovir e aciclovir devem ser administrados com cautela pois podem aumentar a concentração plasmática de ácido micofenólico e potencializar a supressão medular. Cuidados devem também ser tomados com o uso concomitante de outras substâncias, como os antiácidos que contenham magnésio e alumínio, colestiramina, ferro, metronidazol, norfloxacina e rifampicina, pois poderá haver redução dos níveis de ácido micofenólico.  
Apesar de não ser prática clínica no Brasil, as evidências disponíveis demonstram benefícios com a monitorização de ácido micofenólico, para manutenção de níveis terapêuticos adequados<sup>(65-71)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A dose de ataque de sirolimo é 3 mg/m2 no primeiro dia e de manutenção 1mg/m2/dia, em uma ou duas administrações, por via oral. O nível sérico deve ser mantido entre 5 a 10 ng/ml.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Iniciar com pelo menos 30 dias pós-transplante. Dose inicial 1 mg 2x ao dia; manter a dose por um intervalo de 4-5 dias baseado na concentração, tolerabilidade e resposta. Manter nível sérico vale entre 3 e 8 ng/mL. Se o nível for <3 ng/mL, dobrar a dose total; se for >8 ng/mL em duas medidas consecutivas, diminuir a dose para 0,25 mg 2x ao dia. Pode ser administrado com tacrolimo (menor dose) e corticosteroides. A variabilidade na farmacocinética e a estreita janela terapêutica tornam a monitorização terapêutica essencial.  
10

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Dose inicial de 1 a 2mg/kg/dia em dose única diária.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Após os transplantes a imunossupressão deve, a priori, ser mantida pelo resto da vida dos indivíduos. Não há tempo definido para a manutenção dos medicamentos. A intensidade da imunossupressão e o número dos medicamentos utilizados serão definidos conforme a evolução dos pacientes e a diminuição da reação imunológica ao enxerto. A seção a seguir resume os efeitos adversos dos medicamentos.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Os eventos adversos mais comumente relatados, de acordo com o medicamento administrado e frequência, encontram-se resumidos na **Tabela H** .  
**Tabela H –** Eventos adversos comumente relatados com o tratamento para imunossupressão no transplante hepático em pediatria  
|**Imunossupressores**|**Corticoides**|**CsA**|**TAC**|**MMF/MS**|**AZA**|**EVR**|
|---|---|---|---|---|---|---|
|Leucopenia||||+|++|+|
|Anemia||||+|++|+|
|Trombocitopenia||||+|++|+|
|Nefrotoxicidade||++|++||||
|Hipertensão|+++|++|+/++||||
|Hipomagnesemia||+|+||||
|Hiperpotassemia||+|+||||
|Alteração gastrointestinal|+|+|++|+++/++||+|
|Alergia alimentar|||+||||
|Úlcera digestiva|+||||||
|Hepatotoxicidade||+|+||+||
|Hiperlipemia|++/+++|++|+|||+++|
|Hiperglicemia|++|+|++||||
|Hiperplasia gengival||++|||||
|Hirsutismo|+|++|||||
|Neurotoxicidade|+|+|+||||
|Retardo do crescimento|+||||||
|Diabetes Mellitus|++/+++|+|++||||
|Má cicatrização|+|||||+|
|Osteoporose|+++|++|+||||
|Catarata|+||||||
|Alteração psiquiátrica|+||||||
|Alopecia|||+||+||  
CsA: ciclosporina; TAC: tacrolimo; MMF/MS: micofenolato de mofetila/ micofenolato de sódio; AZA: azatioprina; EVR: everolimo. +: intensidade do efeito adverso.  
Os eventos adversos do sirolimo podem ser descritos de acordo com a seguinte classificação:  
Eventos adversos muito comuns: linfocele; edema periférico, dor abdominal; hipertensão arterial; diarreia; constipação;  
anemia; trombocitopenia; hipertrigliceridemia; hipercolesterolemia; hipofosfatemia; hiperglicemia; hipocalemia.  
11  
Eventos adversos comuns: cicatrização anormal; tromboembolismo, edema; febre; infecções fúngicas, virais e bacterianas.  
Em relação ao basiliximabe, os eventos adversos mais comumente relatados são: obstipação, diarreia, infecção do trato urinário, dor, náusea, edema periférico, hipertensão, anemia, cefaleia e hiperpotassemia, hipercalemia, hipercolesterolemia, aumento da creatinina no sangue, hipofosfatemia, aumento de peso e complicações de ferimentos pós-operatórios.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
As principais interações medicamentosas relatadas com o uso do tacrolimo e ciclosporina podem ser resumidos no **Quadro**

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
**Quadro 1 –** Principais interações medicamentosas com tacrolimo e ciclosporina  
|**Fármacos que elevam o nível do TAC e CsA**|**Fármacos que diminuem o nível do TAC e CsA**|
|---|---|
|Claritromicina||
|Eritromicina||
|Azitromicina|Anfotericina/caspofungina|
|Fluconazol/itraconazol/voriconazol|Sulfadiazina/trimetropina i.v.|
|Antiretrovirais (lopinavir/nelfinavir/ritonavir)|Isoniazida/rifampcina|
|Nifedipina/ Verapamil/ Diltiazem|Carbamazepina/fenobarbital/fenitoína/|
|Alopurinol|primidona|
|Omeprazol/lanzoprazol|Octreotida|
|Metoclopramida||
|Metilprednisolona||  
CsA: ciclosporina; TAC: tacrolimo; i.v.: infusão venosa.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A monitorização dos efeitos esperados dos imunossupressores é realizada periodicamente por meio de exames bioquímicos e, eventualmente, da avaliação histológica do fígado. Os inibidores de calcineurina devem ter seu nível sanguíneo avaliado para ajuste da dose à janela terapêutica. As recomendações sobre monitoramento das concentrações dos fármacos estão descritas na seção de esquemas de administração.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Devem ser observados os critérios de inclusão nesse PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso dos medicamentos. Doentes transplantados de fígado devem ser atendidos em serviços especializados em transplante hepático para sua adequada inclusão no PCDT e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Na RENAME 2018, a prednisona e a prednisolona encontram-se no **Componente Básico** da Assistência Farmacêutica e  
a prednisona encontra-se também no **Componente Estratégico** desta Assistência.  
Os seguintes medicamentos integram procedimentos **hospitalares** especiais, em AIH, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS: 06.03.08.001-4 Basiliximabe 20 mg injetável (por frasco-ampola), 06.03.02.005-4 Ciclosporina 50 mg injetável (por frasco-ampola), 06.03.08.002-2 Ciclosporina 10 mg p/ transplante (por cápsula), 06.03.08.003-0 Ciclosporina 100 mg p/ transplante (por cápsula), 06.03.08.004-9 Ciclosporina 25 mg p/ transplante (por cápsula), 06.03.08.005-7 Ciclosporina 50 mg p/ transplante (por cápsula), 06.03.02.007-0 Imunoglobulina obtida/coelho antitimócitos 200 mg injetável (por frasco-ampola de 10 ml) _– atualmente indisponível no mercado brasileiro_ , <u>06.03.02.008-9</u> Imunoglobulina obtida/coelho antitimócitos humanos 100 mg injetável (por frasco-ampola 0,5 ml) _– atualmente indisponível no mercado brasileiro_ , 06.03.02.009-7 Imunoglobulina obtida/coelho antitimócitos humanos 25 mg injetável (por frasco-ampola 0,5 ml), 06.03.08.012-0 Metilprednisolona 500 mg injetável p/ transplante (por frasco-ampola); 06.03.08.013-8 Micofenolato de mofetila 500mg p/ transplante  
12  
(por comprimido), 06.03.08.014-6 Micofenolato de sódio 360mg p/ transplante (por comprimido), 06.03.08.016-2  Sirolimo 1mg p/ transplante (por drágea), 06.03.08.017-0 Sirolimo 1mg/ml solucao oral p/ transplante (por frasco de 60ml) _– atualmente sem registro no Brasil,_ 06.03.08.018-9 Sirolimo 2 mg p/ transplante (por drágea), 06.03.08.019-7 Tacrolimo 0,5 mg p/transplante (por frascoampola), 06.03.08.022-7 Micofenolato de sódio 180mg p/transplante (por comprimido), 06.03.08.027-8 Everolimo 0,5 mg para transplante (por comprimido), 06.03.08.028-6 Everolimo 0,75 mg para transplante (por comprimido) e 06.03.08.029-4 Everolimo 1 mg para transplante (por comprimido).  
Os seguintes medicamentos integram procedimentos **ambulatoriais** do **Componente Especializado** da Assistência Farmacêutica, em APAC, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS: 06.04.28.0106 Metilprednisolona 500 mg injetável (por ampola), 06.04.32.001-9 Everolimo 0,5 mg (por comprimido), 06.04.32.002-7 Everolimo 0,75 mg (por comprimido), 06.04.32.003-5 Everolimo 1 mg (por comprimido), 06.04.32.005-1 Micofenolato de mofetila 500 mg (por comprimido), 06.04.32.006-0 Micofenolato de sodio 180 mg (por comprimido), 06.04.32.007-8 Micofenolato de sodio 360 mg (por comprimido), 06.04.32.008-6 Sirolimo 1 mg (por drágea), 06.04.32.009-4 Sirolimo 2 mg (por drágea), 06.04.34.001-0 Ciclosporina 10 mg (por cápsula), 06.04.34.002-8 Ciclosporina 25 mg (por cápsula), 06.04.34.003-6 Ciclosporina 50 mg (por cápsula), 06.04.34.004-4 - Ciclosporina 100 mg (por cápsula), 06.04.34.005-2 Ciclosporina 100 mg/ml solução oral (por frasco de 50 ml), 06.04.34.006-0 Tacrolimo 1 mg (por cápsula), 06.04.34.007-9 Tacrolimo 5 mg (por cápsula), 06.04.53.001-3 Azatioprina 50 mg (por comprimido).

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste PCDT, bem como sobre os critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
1. Schünemann H BJ, Oxman A. GRADE handbook for grading quality of evidence and strength of recommendations. . Cochrane Collaboration. 2013.  
2. Dhawan A. Immunosuppression in pediatric liver transplantation: Are little people different?. Liver Transplantation. 2011;17(Supl  3):S13-9.  
3. Jadlowiec CC TT. Liver transplantation: Current status and challenges. World journal of gastroenterology. 2016;22(18):4438.  
4. Miloh T BA, Wheeler J, Pham Y, Hewitt W, Keegan T, Sanchez C, Bulut P, Goss J,. Immunosuppression in pediatric liver transplant recipients: Unique aspects. Liver Transplantation. 2017;23(2):244-56.  
5. Ng VL, Alonso EM, Bucuvalas JC, Cohen G, Limbers CA, Varni JW, et al. Health status of children alive 10 years after pediatric liver transplantation performed in the US and Canada: report of the studies of pediatric liver transplantation experience. The Journal of pediatrics. 2012;160(5):820-6.  
6. Associação Brasileira de Transplantes de Órgãos. Registro Brasileiro de Transplantes. Ano XXI. No 4. 2015.  
7. Neto JS, Pugliese R, Fonseca EA, Vincenzi R, Pugliese V, Candido H, et al. Four hundred thirty consecutive pediatric living donor liver transplants: variables associated with posttransplant patient and graft survival. Liver Transplantation. 2012;18(5):577-84.  
8. Tannuri AC, Gibelli NE, Ricardi LR, Santos MM, Maksoud-Filho JG, Pinho-Apezzato ML, et al. Living related donor liver transplantation in children. Transplantation proceedings 2011;43(1):161-4.  
9. Kelly DA, Bucuvalas JC, Alonso EM, Karpen SJ, Allen U, Green M, et al. Long‐term medical management of the pediatric patient after liver transplantation: 2013 practice guideline by the American Association for the Study of Liver Diseases and the American Society of Transplantation. Liver Transplantation. 2013;19(8):798-825.  
10. Soltys KA, Mazariegos GV, Squires RH, Sindhi RK, Anand R. Late graft loss or death in pediatric liver transplantation: an analysis of the SPLIT database. American Journal of Transplantation. 2007;7(9):2165-71.  
11. Coelho T, Tredger M, Dhawan A. Current status of immunosuppressive agents for solid organ transplantation in children. Pediatric transplantation. 2012;16(2):106-22.  
12. Malat G, Culkin C. The ABCs of Immunosuppression: A Primer for Primary Care Physicians. Medical Clinics. 2016;100(3):505-18.  
13. Thangarajah D, O’Meara M, Dhawan A. Management of acute rejection in paediatric liver transplantation. Pediatric Drugs. 2013;15(6):459-71.  
14. Fenkel JM, Halegoua-DeMarzio DL. Management of the Liver Transplant Recipient: Approach to Allograft Dysfunction. Medical Clinics. 2016;100(3):477-86.  
15. Ng VL, Fecteau A, Shepherd R, Magee J, Bucuvalas J, Alonso E, et al. Outcomes of 5-year survivors of pediatric liver transplantation: report on 461 children from a North American multicenter registry. Pediatrics. 2008;122(6):e1128-35.  
16. Soltys KA, Mazariegos GV, Squires RH, Sindhi RK, Anand R, Group SR. Late graft loss or death in pediatric liver transplantation: an analysis of the SPLIT database. American journal of transplantation : official journal of the American Society of Transplantation and the American Society of Transplant Surgeons. 2007;7(9):2165-71.  
17. VL N, A F, R S, J M, J B, E A, et al. Outcomes of 5-year survivors of pediatric liver transplantation: report on 461 children from a North American multicenter registry. Pediatrics. 2008;122(6):e1128-35.  
13  
18. Demetris AJ, Bellamy C, Hubscher SG, O'Leary J, Randhawa PS, Feng S, et al. 2016 Comprehensive Update of the Banff Working Group on Liver Allograft Pathology: Introduction of Antibody-Mediated Rejection. American journal of transplantation : official journal of the American Society of Transplantation and the American Society of Transplant Surgeons. 2016;16(10):2816-35. 19. Venturi C, Sempoux C, Bueno J, Ferreres Pinas JC, Bourdeaux C, Abarca‐Quinones J, et al. Novel Histologic Scoring System for Long‐Term Allograft Fibrosis After Liver Transplantation in Children. American Journal of Transplantation. 2012;12(11):2986-96.  
20. McDiarmid SV BR, Ascher NL, Burdick J, D'alessandro AM, Esquivel C, Kalayoglu M, Klein AS, Marsh JW, Miller CM. FK506 (tacrolimus) compared with cyclosporine for primary immunosuppression after pediatric liver transplantation. Results from the US Multicenter Trial. Transplantation. 1995;59(4):530-6. 21. Kelly D JP, Rodeck B, Lykavieris P, Burdelski M, Becker M, Gridelli B, Boillot O, Manzanares J, Reding R. . Tacrolimus and steroids versus ciclosporin microemulsion, steroids, and azathioprine in children undergoing liver transplantation: randomised European multicentre trial. . The Lancet. 2004;364(9439):1054-61. 22. McAlister VC HE, Renouf E, Malthaner RA, Kjaer MS, Gluud LL. Cyclosporin versus Tacrolimus as Primary Immunosuppressant After Liver Transplantation: A Meta‐Analysis. American Journal of Transplantation. 2006;6(7):1578-85. 23. Spada M, Petz W, Bertani A, Riva S, Sonzogni A, Giovannelli M, et al. Randomized trial of basiliximab induction versus steroid therapy in pediatric liver allograft recipients under tacrolimus immunosuppression. American Journal of Transplantation. 2006;6(8):1913-21. 24. Ganschow R, Broering DC, Stuerenburg I, Rogiers X, Hellwege HH, Burdelski M, et al. First experience with basiliximab in pediatric liver graft recipients. Pediatric Transplantation. 2001;5(5):353-8. 25. Ganschow R, Grabhorn E, Schulz A, Von Hugo A, Rogiers X, Burdelski M, et al. Long-term results of basiliximab induction immunosuppression in pediatric liver transplant recipients. Pediatric Transplantation. 2005;9(6):741-5. 26. Ganschow R, Lyons M, Grabhorn E, Venzke A, Broering DC, Rogiers X, et al. Experience with Basiliximab in pediatric liver graft recipients. Transplantation Proceedings. 2001;33(7 8):3606-7. 27. Gras JM, Gerkens S, Beguin C, Janssen M, Smets F, Otte JB, et al. Steroid-free, tacrolimus-basiliximab immunosuppression in pediatric liver transplantation: clinical and pharmacoeconomic study in 50 children. Liver transplantation : official publication of the American Association for the Study of Liver Diseases and the International Liver Transplantation Society. 2008;14(4):469-77. 28. Reding R, Gras J, Sokal E, Otte JB, Davies HF. Steroid-free liver transplantation in children. Lancet (London, England). 2003;362(9401):2068-70. 29. Benitez CE, Puig-Pey I, Lopez M, Martinez-Llordella M, Lozano JJ, Bohne F, et al. ATG-Fresenius treatment and lowdose tacrolimus: results of a randomized controlled trial in liver transplantation. American journal of transplantation : official journal of the American Society of Transplantation and the American Society of Transplant Surgeons. 2010;10(10):2296-304. 30. Bogetti D, Jarzembowski TM, Sankary HN, Manzelli A, Knight PS, Chejfec G, et al. Hepatic ischemia/reperfusion injury can be modulated with thymoglobulin induction therapy. Transplantation Proceedings. 2005;37(1):404-6. 31. Bogetti D, Sankary HN, Jarzembowski TM, Manzelli A, Knight PS, Thielke J, et al. Thymoglobulin induction protects liver allografts from ischemia/reperfusion injury. Clinical Transplantation. 2005;19(4):507-11. 32. Boillot O, Seket B, Dumortier J, Pittau G, Boucaud C, Bouffard Y, et al. Thymoglobulin induction in liver transplant recipients with a tacrolimus, mycophenolate mofetil, and steroid immunosuppressive regimen: A five-year randomized prospective study. Liver Transplantation. 2009;15(11):1426-34. 33. Casciato PC, Marciano S, Galdame OA, Villamil AG, Bandi JC, De Santibañes E, et al. Short-term, low-dose thymoglobuline: The best option to spare calcineurin inhibitors in liver transplant recipients with renal failure? Transplantation. 2010;90:36. 34. Eason JD, Loss GE, Blazek J, Nair S, Mason AL. Steroid-free liver transplantation using rabbit antithymocyte globulin induction: Results of a prospective randomized trial. Liver Transplantation. 2001;7(8):693-7. 35. Eason JD, Nair S, Cohen AJ, Blazek JL, Loss GE, Jr. Steroid-free liver transplantation using rabbit antithymocyte globulin and early tacrolimus monotherapy. Transplantation. 2003;75(8):1396-9. 36. Garcia-Saenz-de-Sicilia M, Olivera-Martinez MA, Grant WJ, Mercer DF, Baojjang C, Langnas A, et al. Impact of AntiThymocyte Globulin During Immunosuppression Induction in Patients with Hepatitis C After Liver Transplantation. Digestive Diseases and Sciences. 2014;59(11):2804-12.  
37. Grant W, Botha J, Mercer D, Olivera-Martinez M, McCashland T, Langnas A. A randomized, single-center trial comparing thymoglobulin (TG) induction therapy and delayed initiation of tacrolimus to no induction with immediate initiation of tacrolimus in liver transplant (LT) recipients to assess the impact on renal function. American Journal of Transplantation. 2012;12:539. 38. Langrehr JM, Nussler NC, Neumann U, Guckelberger O, Lohmann R, Radtke A, et al. A prospective randomized trial comparing interleukin-2 receptor antibody versus antithymocyte globulin as part of a quadruple immunosuppressive induction therapy following orthotopic liver transplantation. Transplantation. 1997;63(12):1772-81.  
39. Neuhaus P, Klupp J, Langrehr JM, Neumann U, Gebhardt A, Pratschke J, et al. Quadruple tacrolimus-based induction therapy including azathioprine and ALG does not significantly improve outcome after liver transplantation when compared with standard induction with tacrolimus and steroids: results of a prospective, randomized trial. Transplantation. 2000;69(11):2343-53.  
40. Miloh T BA, Wheeler J, Pham Y, Hewitt W, Keegan T, Sanchez C, Bulut P, Goss J,. Immunosuppression in pediatric liver transplant recipients: Unique aspects. Liver Transplantation. 2017;23(2):244-56. 41. Bilbao I, Salcedo M, Gomez MA, Jimenez C, Castroagudin J, Fabregat J, et al. Renal function improvement in liver transplant recipients after early everolimus conversion: A clinical practice cohort study in Spain. Liver transplantation : official publication of the American Association for the Study of Liver Diseases and the International Liver Transplantation Society. 2015;21(8):1056-65. 42. Gomez-Camarero J SM, Rincon D, Iacono OL, Ripoll C, Hernando A, Sanz C, Clemente G, Banares R. Use of everolimus as a rescue immunosuppressive therapy in liver transplant patients with neoplasms. Transplantation. 2007;84(6):786-91. 43. Herden U, Galante A, Fischer L, Pischke S, Li J, Achilles E, et al. Early Initiation of Everolimus After Liver Transplantation: A Single-Center Experience. Annals of transplantation. 2016;21:77-85. 44. Jimenez-Rivera C, Avitzur Y, Fecteau AH, Jones N, Grant D, Ng VL. Sirolimus for pediatric liver transplant recipients with post-transplant lymphoproliferative disease and hepatoblastoma. Pediatric transplantation. 2004;8(3):243-8. 45. Nielsen D, Briem-Richter A, Sornsakrin M, Fischer L, Nashan B, Ganschow R, et al. The use of everolimus in pediatric liver transplant recipients: First experience in a single center. Pediatric Transplantation. 2011;15(5):510-4.  
14  
46. Acurcio Fde A, Saturnino LT, Silva AL, Oliveira GL, Andrade EI, Cherchiglia ML, et al. [Cost-effectiveness analysis of immunosuppressive drugs in post-renal transplantation maintenance therapy in adult patients in Brazil]. Cad Saude Publica. 2013;29 Suppl 1:S92-109. 47. Felipe C, Tedesco-Silva H, Ferreira Brigido A, Bessa A, Ruppel P, Hiramoto L, et al. Cost-Effectiveness Analysis of Everolimus versus Mycophenolate in Kidney Transplant Recipients Receiving No Pharmacological Prophylaxis for Cytomegalovirus Infection: A Short-Term Pharmacoeconomic Evaluation (12 Months). Value Health Reg Issues. 2017;14:108-15. 48. Amir AZ, Ling SC, Naqvi A, Weitzman S, Fecteau A, Grant D, et al. Liver transplantation for children with acute liver failure associated with secondary hemophagocytic lymphohistiocytosis. Liver transplantation : official publication of the American Association for the Study of Liver Diseases and the International Liver Transplantation Society. 2016;22(9):1245-53. 49. Aw MM, Taylor RM, Verma A, Parke A, Baker AJ, Hadzic D, et al. Basiliximab (Simulect) for the treatment of steroidresistant rejection in pediatric liver transpland recipients: a preliminary experience. Transplantation. 2003;75(6):796-9. 50. Aydogan C, Sevmis S, Aktas S, Karakayali H, Demirhan B, Haberal M. Steroid-resistant acute rejections after liver transplant. Experimental and clinical transplantation : official journal of the Middle East Society for Organ Transplantation. 2010;8(2):172-7. 51. Benjamin MM, Dasher KJ, Trotter JF. A comparison of outcomes between OKT3 and antithymocyte globulin for treatment of steroid-resistant rejection in hepatitis C liver transplant recipients. Transplantation. 2014;97(4):470-3. 52. Bijleveld CG, Klompmaker IJ, van den Berg AP, Gouw AS, Hepkema BG, Haagsma EB, et al. Incidence, risk factors, and outcome of antithymocyte globulin treatment of steroid-resistant rejection after liver transplantation. Transplant international : official journal of the European Society for Organ Transplantation. 1996;9(6):570-5. 53. Lee JG, Lee J, Lee JJ, Song SH, Ju MK, Choi GH, et al. Efficacy of rabbit anti-thymocyte globulin for steroid-resistant acute rejection after liver transplantation. Medicine. 2016;95(23):e3711. 54. Schmitt TM, Phillips M, Sawyer RG, Northup P, Hagspiel KD, Pruett TL, et al. Anti-thymocyte globulin for the treatment of acute cellular rejection following liver transplantation. Digestive diseases and sciences. 2010;55(11):3224-34. 55. Shigeta T, Sakamoto S, Uchida H, Sasaki K, Hamano I, Kanazawa H, et al. Basiliximab treatment for steroid-resistant rejection in pediatric patients following liver transplantation for acute liver failure. Pediatric transplantation. 2014;18(8):860-7. 56. Demirağ A KM, Ekci B, Gülçelik T, Gökçe Ö. Sirolimus for rescue of steroid and anti-thymocyte globulin-resistant recurrent acute rejection after liver transplantation: report of one case. Transplant Proc. 2009;41(1):435-6. 57. Lladó L, Fabregat J, Castellote J, Ramos E, Torras J, Serrano T, et al. Sirolimus-based rescue therapy after rejection in liver transplantation. Clin Transplant. 2009;23(1):89-95. 58. Egawa H, Esquivel CO, So SK, Cox K, Concepcion W, Lawrence L. FK506 conversion therapy in pediatric liver transplantation. Transplantation. 1994;57(8):1169-73. 59. Jain A, Mazariegos G, Pokharna R, Parizhskaya M, Smith A, Kashyap R, et al. Almost total absence of chronic rejection in primary pediatric liver transplantation under tacrolimus. Transplant Proc. 2002;34(5):1968-9. 60. Jain A, Mazariegos G, Pokharna R, Parizhskaya M, Kashyap R, Kosmach-Park B, et al. The absence of chronic rejection in pediatric primary liver transplant patients who are maintained on tacrolimus-based immunosuppression: a long-term analysis. Transplantation. 2003;75(7):1020-5.  
61. McDiarmid SV, Klintmalm GB, Busuttil RW, Author A, Department of P, University of California LAMCLACA, et al. FK506 conversion for intractable rejection of the liver allograft. Transplant International. 1993;6(6):305-12. 62. Riva S, Sonzogni A, Bravi M, Bertani A, Alessio MG, Condusso M, et al. Late graft dysfunction and autoantibodies after liver transplantation in children: Preliminary results of an Italian experience. Liver Transplantation. 2006;12(4):573-7. 63. Winkler M, Ringe B, Jost U, Melter M, Rodeck B, Buhr T, et al. Conversion from cyclosporin to FK 506 after liver transplantation. Transplant international : official journal of the European Society for Organ Transplantation. 1993;6(6):319-24. 64. (tacrolimo) P. Farmacêutica responsável: Sandra Winarski CRF-SP: 18.496. Fabricado e embalado por: Astellas Ireland Co. Ltd. Killorglin – Co. Kerry – Irlanda. Registrado e importado por: Astellas Farma Brasil Importação e Distribuição de Medicamentos Ltda. Av. Guido Caloi, 1935, Bloco B, 2º andar, Santo Amaro, CEP: 05802-140 – São Paulo – SP. Bula de Remádio. 2015. 65. Attard TM, Dhawan A, Tredger JM, Conner K, Kling K, Colombani P, et al. Mycophenolic acid metabolite levels in pediatric liver transplantation: Correlation with a limited sampling strategy. Journal of Applied Research. 2008;8(2):135-42. 66. Aw MM, Brown NW, Itsuka T, Gonde CE, Adams JE, Heaton ND, et al. Mycophenolic acid pharmacokinetics in pediatric liver transplant recipients. Liver transplantation : official publication of the American Association for the Study of Liver Diseases and the International Liver Transplantation Society. 2003;9(4):383-8. 67. Brown NW, Aw MM, Mieli-Vergani G, Dhawan A, Tredger JM, Author A, et al. Mycophenolic acid and mycophenolic acid glucuronide pharmacokinetics in pediatric liver transplant recipients: Effect of cyclosporine and tacrolimus comedication. Therapeutic Drug Monitoring. 2002;24(5):598-606. 68. Barau C, Barrail-Tran A, Habes D, Hermeziu B, Taburet AM, Debray D, et al. Optimization of the dosing regimen of mycophenolate mofetil in pediatric liver transplant recipients. Therapeutic Drug Monitoring. 2011;33(4):536. 69. Lobritto SJ, Rosenthal P, Bouw R, Leung M, Snell P, Mamelok RD. Pharmacokinetics of mycophenolate mofetil in stable pediatric liver transplant recipients receiving mycophenolate mofetil and cyclosporine. Liver Transplantation. 2007;13(11):1570-5. 70. Parant F, Rivet C, Boulieu R, Gagnieu MC, Dumortier J, Boillot O, et al. Age-related variability of mycophenolate mofetil exposure in stable pediatric liver transplant recipients and influences of donor characteristics. Therapeutic Drug Monitoring. 2009;31(6):727-33. 71. Tredger JM, Brown NW, Adams J, Gonde CE, Dhawan A, Rela M, et al. Monitoring mycophenolate in liver transplant recipients: Toward a therapeutic range. Liver Transplantation. 2004;10(4):492-502. 72. Brasil. Ministério da Saúde. Portaria n°375, de 10 de novembro de 2009. Aprova o roteiro a ser utilizado na elaboração de Protocolos Clínicos e Diretrizes Terapêuticas no âmbito da Secretaria de Atenção à Saúde. In: Ministério da Saúde, editor. Brasília2009. 73. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. Bmj. 2017;358:j4008. 74. Higgins JPT, Green S. Cochrane Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration. 2011. 75. Wells G SB, O’Connell D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analyses. 2013. 76. Whiting PF, Rutjes AW, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, et al. QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. Annals of internal medicine. 2011;155(8):529-36.  
15  
77. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ: British Medical Journal. 2008;336(7650):924.  
78. Reding R SE, Paul K, Janssen M, Evrard V, Wilmotte L, Chardot C, Otte JB, Wallemacq P. Efficacy and pharmacokinetics of tacrolimus oral suspension in pediatric liver transplant recipients. Pediatric transplantation. 2002;6(2):124-6.  
79. Dick AAS, Hansen KC, Hsu EK, Horslen S, Reyes JD, Healey PJ, et al. Thymoglobulin induction immunosuppression in pediatric liver transplantation. Pediatric Transplantation. 2013;17 SUPPL. 1:78.  
80. Heffron TG, Pescovitz MD, Florman S, Kalayoglu M, Emre S, Smallwood G, et al. Once-daily tacrolimus extendedrelease formulation: 1-Year post-conversion in stable pediatric liver transplant recipients. American Journal of Transplantation. 2007;7(6):1609-15.  
81. Quintero J, Juamperez J, Sanchez M, Misercahs M, Bilbao I, Charco R, et al. Conversion from a twice-daily tacrolimusbased regimen to once-daily tacrolimus extended-release formulation in stable pediatric liver transplant recipients: Efficacy, safety, and immunosuppressant adherence. Transplant International. 2015;28 SUPPL. 4:200.  
82. Sampol-Manos E, Garaix F, Tsimaratos M, Lacaralle B, Author A, Department of Pharmacokinetic a, et al. Efficacy, safety, immunosuppressant adherence in stable pediatric transplant patients converted to once-daily tacrolimus formulation. Therapeutic Drug Monitoring. 2011;33(4):539.  
83. Gomez-Camarero J SM, Rincon D, Iacono OL, Ripoll C, Hernando A, Sanz C, Clemente G, Banares R. Use of everolimus as a rescue immunosuppressive therapy in liver transplant patients with neoplasms. Transplantation. 2007;84(6):786-91.  
84. Dhawan A, Tredger JM, North-Lewis PJ, Gonde CE, Mowat AP, Heaton NJ, et al. Tacrolimus (FK506) malabsorption: Management with fluconazole coadministration. Transplant International. 1997;10(4):331-4. 85. Furlan V, Perello L, Jacquemin E, Debray D, Taburet AM, Author A, et al. Interactions between FK506 and rifampicin or erythromycin in pediatric liver recipients. Transplantation. 1995;59(8):1217-8.  
86. Hickey MD, Quan DJ, Chin-Hong PV, Roberts JP. Use of rifabutin for the treatment of a latent tuberculosis infection in a patient after solid organ transplantation. Liver transplantation : official publication of the American Association for the Study of Liver Diseases and the International Liver Transplantation Society. 2013;19(4):457-61.  
87. Hurst AL, Clark N, Carpenter TC, Sundaram SS, Reiter PD. Supra-therapeutic tacrolimus concentrations associated with concomitant nicardipine in pediatric liver transplant recipients. Pediatric transplantation. 2015;19(4):E83-7.  
88. Sheiner PA, Mor E, Chodoff L, Glabman S, Emre S, Schwartz ME, et al. Acute renal failure associated with the use of ibuprofen in two liver transplant recipients on FK506. Transplantation. 1994;57(7):1132-3.  
89. Wungwattana M, Savic M, Author A, Department of Pharmacy M, Medical Center PUS, Correspondence A, et al. Tacrolimus interaction with nafcillin resulting in significant decreases in tacrolimus concentrations: A case report. Transplant Infectious Disease. 2017;19:2 Article Number: e12662.  
16

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Eu, (nome do (a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de azatioprina, basiliximabe, ciclosporina, metilprednisolona, micofenolato de mofetila, micofenolato de sódio, tacrolimo e timoglobulina, indicados para a imunossupressão no transplante hepático pediátrico.  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico (nome do médico que prescreve). Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- Manter a imunossupressão;  
- Prevenir ou reduzir os episódios de rejeição do fígado;  
- Tratar os eventuais episódios de rejeição aguda e crônica.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso deste medicamento:  
- não se sabe ao certo os riscos do uso do basiliximabe, da ciclosporina, do everolimo, da metilprednisolona, do micofenolato de mofetila ou de sódio, da prednisilona, da prednisona, do sirolimo, do tacrolimo e da timoglobulina na gravidez; portanto, caso engravide, devo avisar imediatamente o médico;  
- azatioprina: há riscos para o feto durante a gravidez, porém o benefício pode ser maior que o risco e isso deve ser discutido com o médico;  
- <u>efeitos adversos da azatioprina: diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos,</u> diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar, pressão baixa;  
- efeitos adversos da ciclosporina: problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, aumento do crescimento da gengiva, aumento do colesterol e triglicerídIos, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas;  
- <u>efeitos adversos do everolimo: feridas na boca, vermelhidão, leucopenia, fadiga, astenia, anorexia, diarreia, náusea,</u> vômito, tosse, inchaço de extremidades (edema periférico), infecções, pele seca, dificuldade de cicatrização, sangramento nasal, coceira e falta de ar;  
- efeitos adversos da metiprednisolona: retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabete mélito;  
- efeitos adversos do micofenolato de mofetila; e micofenolato de sódio: diarreia, diminuição das células brancas do sangue, infecção generalizada e vômitos, dor no peito, palpitações, pressão baixa, trombose, insuficiência cardíaca, hipertensão pulmonar, morte súbita, desmaio, ansiedade, depressão, rigidez muscular, trombocitopenia, hiperlipemia, formigamentos, sonolência, neuropatia, convulsões, alucinações, vertigens, tremores, insônia, tonturas, queda de cabelo, aumento da quantidade de pelos no corpo, coceiras, ulcerações na pele, espinhas, vermelhidão da pele, prisão de ventre, náusea, azia e dor de estômago, perda de apetite, gases, gastrite, gengivite, problemas na gengiva, hepatite, sangue na urina, aumento da frequência ou retenção urinária, insuficiência renal, desconforto para urinar, impotência sexual, anemia, diminuição das plaquetas do sangue, diabete mélito, hipotireoidismo, inchaço, alteração de eletrólitos (hipofosfatemia, hipocalemia, hipercalemia, hipocloremia), hiperglicemia, hipercolesterolemia, alteração de enzimas hepáticas, febre, dor de cabeça, fraqueza, dor nas costas e no abdômen, pressão alta, falta de ar, tosse;  
- efeitos adversos da prednisolona: aumento do apetite, indigestão, úlcera péptica, inflamação no pâncreas (pancreatite), inflamação no esôfago (esofagite), nervosismo, fadiga, dificuldade para dormir (insônia), alteração psiquiátrica, reações alérgicas locais, má cicatrização, catarata, glaucoma, aumento da glicemia, diabetes mellitus, aumento de colesterol, aumento da pressão arterial, desconforto gastrointestinal, retardo de crescimento, aumento na quantidade de pelos (hirsutismo), problemas nos ossos (osteoporose);  
- efeitos adversos da prednisona: alterações no sangue (retenção de sódio, hipocalemia), fraqueza muscular, problemas nos ossos (osteoporose), úlcera péptica, inflamação no esôfago (esofagite), inflamação no pâncreas (pancreatite), dificuldade de cicatrização, coceira, tontura, dor abdominal, aumento do colesterol e da glicemia, aumento da pressão arterial,  manifestação de diabetes mellitus, alterações de crescimento fetal ou infantil, catarata, glaucoma, dificuldade de dormir (insônia), alterações psiquiátricas;  
- efeitos adversos do sirolimo: infecções, feridas na boca (estomatite), diarreia, dor abdominal, náusea, nasofaringite, acne, dor no peito, aumento dos batimentos cardíacos e da pressão arterial, fadiga, inchaço em extremidades (edema periférico), infecção do trato respiratório, tosse, falta de ar, dor de cabeça, tontura, dor muscular e articular, diminuição de glóbulos brancos (leucopenia) e de plaquetas (trombocitopenia), aumento do colesterol e alterações menstruais;  
- efeitos adversos do tacrolimo: tremores, dor de cabeça, diarreia, aumento da pressão arterial, náusea e alteração renal, dor no peito, diminuição da pressão arterial, palpitações, formigamentos, falta de ar, colangite, amarelão, diarreia, prisão de ventre, vômitos, diminuição do apetite, azia e dor no estômago, gases, hemorragia, dano hepático, agitação, ansiedade, convulsão, depressão,  
17  
tontura, alucinações, incoordenação, psicose, sonolência, neuropatia, perda de cabelo, aumento da quantidade de pelos no corpo, vermelhidão de pele, coceiras, anemia, aumento ou diminuição das células brancas do sangue, diminuição das plaquetas do sangue, desordens na coagulação, síndrome hemolítico-urêmica, edema periférico, alterações metabólicas (hipo/hiperpotassemia, hiperglicemia, hipomagnesemia, hiperuricemia), diabete mélito, elevação de enzimas hepáticas, toxicidade renal, diminuição importante do volume da urina, febre, acúmulo de líquido no abdômen e na pleura, fraqueza, dor lombar, atelectasias, osteoporose, dores no corpo, peritonite, fotossensibilidade, alterações visuais;  
- contraindicados em casos de hipersensibilidade (alergia) aos fármacos; - risco da ocorrência de efeitos adversos aumenta com a superdosagem; - a administração de vacinas é recomendada para pacientes em uso de altas doses de imunossupressores; - o uso prolongado de corticoides pode levar a alterações de crescimento e desenvolvimento, além de e inibir a produção  
- endógena de corticosteroides, sendo necessário acompanhamento cuidadoso.  
Estou ciente de que o medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de eu desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (   ) Sim            (   ) Não  
Meu tratamento constará do seguinte medicamento:  
(    ) azatioprina (    ) basiliximabe (    ) ciclosporina (    ) everolimo (    ) metiprednisolona (    ) micofenolato de mofetila (    ) micofenolato de sódio (    ) prednisolona (    ) prednisona (    ) sirolimo (    ) tacrolimo  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo  
18

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Com a presença de cinco membros do Grupo Elaborador, sendo 3 especialistas e 2 metodologistas, e 2 representantes do Comitê Gestor, uma reunião presencial para definição do escopo do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida. Todos os componentes do Grupo Elaborador preencheram o formulário de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde, como parte dos resultados.  
Inicialmente, a macroestrutura do PCDT foi estabelecida considerando a Portaria N° 375/SAS/MS, de 10 de novembro de 2009<sup>(72)</sup> como roteiro para elaboração dos PCDTs, e as seções do documento foram definidas.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de discutir as condutas clínicas e identificar as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas do tema do presente PCDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO, para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Para cada incerteza clínica ou tecnologia não incorporada no SUS, uma questão de pesquisa estruturada, de acordo com o acrônimo PICO ( **Figura 1** ), foi elencada para nortear a busca pelas evidências científicas:  
<!-- Start of picture text -->
•População ou condição clínica<br>P<br>•Intervenção, no caso de estudos experimentais<br>•Fator de exposição, em caso de estudos<br>observacionais<br>I<br>•Teste índice, nos casos de estudos de acurácia<br>diagnóstica<br>•Controle, de acordo com tratamento/níveis de<br>C exposição do fator/exames disponíveis no SUS<br>•Desfechos: sempre que possível, definidos a<br>O priori, de acordo com sua importância<br><!-- End of picture text -->  
**Figura 1 –** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
Ao final dessa dinâmica, 11 questões de pesquisa foram definidas para o presente PCDT ( **Quadro 1A** ).  
19  
**Quadro 1A –** Questões de pesquisa elencadas pelo Grupo Elaborador do Protocolo Clínico e Diretrizes Terapêuticas  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|1|Qual a eficácia da formulação xarope de tacrolimo na imunossupressão<br>(básica, na rejeição aguda e crônica)?|Tratamento Medicamentoso|
|2|Quais as indicações, eficácia e segurança do basiliximabe na fase de<br>indução da imunossupressão básica?|Tratamento Medicamentoso|
|3|Quais as indicações, eficácia e segurança da timoglobulina na fase de<br>indução da imunossupressão básica?|Tratamento Medicamentoso|
|4|Qual a eficácia da apresentação tacrolimo de liberação prolongada na fase<br>de manutenção da imunossupressão básica?|Tratamento Medicamentoso|
|5|Qual a eficácia e segurança do sirolimo na fase de manutenção da<br>imunossupressão em crianças com transplante hepático e com tumor?|Tratamento Medicamentoso|
|6|Qual a eficácia e segurança do everolimo na fase de manutenção da<br>imunossupressão em crianças com transplante hepático, com tumor ou com<br>alergia?|Tratamento Medicamentoso|
|7|Qual a eficácia e segurança da timoglobulina ou basiliximabe nos casos de<br>resistência à primeira opção de tratamento na rejeição aguda?|Tratamento Medicamentoso|
|8|Qual a eficácia e a segurança dos inibidores de mTOR sirolimo e everolimo<br>no tratamento de rejeição aguda resistente a terapia com esteroides em<br>crianças que realizaram transplante hepático?|Tratamento Medicamentoso|
|9|Quais são as opções de tratamento medicamentoso na rejeição crônica?|Tratamento Medicamentoso|
|10|Quais são as interações medicamentosas entre os imunossupressores<br>objetos desse PCDT e anticonvulsivantes; inibidores da bomba de próton;<br>antibióticos; antifúngicos; e anti-inflamatórios?|Interações Medicamentosas|
|11|Qual a importância/necessidade de dosagem sérica de micofenolato?|Tratamento Medicamentoso|  
PCDT: Protocolo Clínico e Diretrizes Terapêuticas.  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE, via Pubmed, e Embase, para cada questão de pesquisa definida no PCDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com metaanálise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-  
20  
análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clinico-demográficas e desfechos de eficácia/segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas, quer por conta de limitações na estratégia de busca da revisão, quer por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados, prospectivos e depois os retrospectivos, e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão sobre a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias, em formato pdf, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados do PCDT. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo do Anexo.  
Com o corpo das evidências identificado, procedeu-se a extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta A MeaSurement Tool to Assess systematic Reviews 2 (AMSTAR-2)<sup>(73)</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>(74)</sup> , os estudos observacionais pela ferramenta Newcastle-Ottawa<sup>(75)</sup> e os estudos de acurácia diagnóstica pelo Quality Assessment of Diagnostic Accuracy Studies 2 (QUADAS-2)<sup>(76)</sup> . Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas, a priori, como alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas, de modo a auxiliar a interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa ao longo do Anexo.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE (Grading of Recommendations, Assessment, Development and Evaluations)<sup>(77)</sup> , de forma qualitativa, durante a reunião de consenso das recomendações. Os metodologistas mediaram as discussões apresentando cada um dos critérios GRADE para os dois objetivos do sistema GRADE, e as conclusões do painel de especialistas foram apresentadas ao final do parágrafo do texto correspondente à recomendação.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
**Questão de Pesquisa 1: Qual a eficácia da formulação xarope de tacrolimo (TAC) na imunossupressão (básica, na rejeição**

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
**MEDLINE via Pubmed:**  
((("Tacrolimus"[Mesh] OR tacrolimus OR tacrolimo)) AND (("Suspensions"[Mesh]) OR "Emulsions"[Mesh] OR syrup OR sirup)) Total: 94 referências  
21  
Data de acesso: 30/07/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
'tacrolimus'/exp OR 'tacrolimus' AND ('syrup'/exp OR 'syrup') AND [embase]/lim  
Total: 24 referências  
Data de acesso: 03/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A busca nas bases de dados resultou em 118 referências (94 no MEDLINE e 24 no EMBASE). Destas, quatro estavam duplicadas. Cento e quatorze referências foram triadas pela leitura de título e resumo. Quatro publicações tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destas, três foram excluídas por avaliaram apenas a estabilidade física da suspensão  
durante a armazenagem, sem apresentar desfechos clínicos de interesse.  
Ao final, apenas um estudo<sup>(78)</sup> foi considerado elegível para responder à questão de pesquisa.  
- **3) Descrição dos estudos e seus resultados**  
A descrição sumária do estudo encontra-se na **Tabela 1** . A **Tabela 2** apresenta as características dos participantes nos  
estudos. A **Tabela 3** apresenta os desfechos relacionados à imunossupressão reportados nos estudos.  
22  
**Tabela 1 –** Descrição dos estudos avaliando a eficácia da formulação xarope de tacrolimo na imunossupressão pós-transplante hepático em pacientes pediátricos  
|**Autor, ano**|**Desenho de estudo**|**População e objetivodo**<br>**estudo**|**Detalhes da Int**|**ervenção**|**Detal**|**hes do controle**|**Tempo de**<br>**seguimento**|**Risco d**|**e viés**|
|---|---|---|---|---|---|---|---|---|---|
|Reding et al.<br>2002<sup>(78)</sup>|Estudo experimental<br>prospectivo com<br>controle histórico|Avaliar a eficácia e<br>farmacocinética e do<br>tacrolimo em suspensão<br>oral vs. cápsulas em<br>pacientes pediátricos pós-<br>transplante hepático<br>Tacroli<br>0,5mg/<br>Minnea<br>adminis<br>até atin<br>segund<br>partir d<br>permiti|mo suspensão oral ma<br>mL de Ora-Plus (Padd<br>polis, MN, USA) e xa<br>trada 0,1mL/kg, 2x/d<br>gir níveis séricos de 1<br>a semana pós-transpla<br>a segunda semana. Ap<br>dos como co-interven|nipulada com<br>ock Laboratories,<br>rope comum,<br>ia, com ajuste diário<br>0–15 ng/mL na<br>nte e 6–10 ng/mL a<br>enas corticoides fora<br>ção|m<br>Dados hi<br>farmacoc<br>formulaç<br>(paciente<br>mesmo c|stóricos de<br>inética da<br>ão em cápsula<br>s oriundos do<br>entro)|Mediana<br>223 dias|Alt<br>Estudo de intervenção<br>outros vieses: em  13/<br>formulação suspensão<br>para cápsulas em uma<br>dias (entre 14-341 dia<br>devido a razões prátic<br>validade curta (n=10)<br>não apropriados (n=3|o<br>não randomizado;<br>15 pacientes a<br>oral foi trocada<br>mediana de 44<br>s) pós-transplante<br>as como: data de<br>ou níveis séricos<br>)|
|**Tabela 2 –**C<br>**Autor, ano**|aracterísticas dos pacie<br>**N**<br>**intervenção**<br>|ntes incluídos nos estudos avaliando<br>**N**<br>**controle**<br>**Idade, mediana**<br>**(Mínimo-Máximo)**<br>**intervenção**|a eficácia da formulaç<br>**Idade, mediana**<br>**(Mínimo-**<br>**Máximo) controle**|ão xarope de tacrolim<br> <br>**% sexo**<br>**masculino**<br>**intervenção**<br>|o na imunos<br>**% sexo**<br>**masculino**<br>**controle**|supressão pós-trans<br>**Tipo de**<br>**transplante**<br>**intervenção**|plante hepático em<br>**Tipo de**<br>**transplante**<br>**controle**|pacientes pediátricos<br>**Perda de**<br>**seguimento**<br>**intervenção**|**Perda de**<br>**seguimento**<br>**controle**|
|Reding et a<br>2002<sup>(78)</sup>|l.<br>15<br>16|<br>1,4 anos (0,4–10,6)|NR,<br>mas<br>sem<br>diferença<br>estatística|<br>NR<br>N|R|Doador<br>vivo<br>(n=8),<br>doador<br>cadáver (n=7)|<br> <br>NR, mas sem<br>diferença<br>estatística|<br>NR<br>N|R|  
N: número de pacientes no grupo; NR: não reportado.  
23  
**Tabela 3 –** Desfechos de eficácia da formulação xarope de tacrolimo na imunossupressão pós-transplante hepático em pacientes pediátricos  
|**Auto**|**r, ano**|**Desfechos intervenção**|**Desfechos controle**|**p para**<br>**comparação**|
|---|---|---|---|---|
|||Sobrevida: 15/15 (100)<br>Rejeição aguda comprovada por biópsia: 9/15 (60)|||
|Reding<br>2002<sup>(78)</sup>|et|al.<br>Rejeição aguda corticoide-resistente: 3/15 (20)<br>Rejeição crônica: 0|Não foram reportados desfechos<br>clínicos no grupo controle|NA|
|||Doença linfoproliferativa (nódulos intrahepáticos com sorologia<br>positiva para vírus Epstein-Barr e PCR positiva): 1/15 (6,6)|||  
NA: não se aplica. Dados foram apresentados como n/N (%).  
Por não haver evidências, essa apresentação de TAC em xarope não pode ser considerada para embasar uma recomendação do GE no texto principal do PCDT.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
- **1) Estratégia de busca**

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
((((("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting*) AND ("basiliximab" [Supplementary Concept] OR basiliximab)) AND ("Immunosuppression"[Mesh] OR Immunosuppression* OR Anti-Rejection Therap* OR Antirejection Therap*)("Child"[Mesh] OR "Adolescent"[Mesh] OR "Pediatrics"[Mesh] OR children OR teenager* OR youth* OR pediatric*)))) Total: 31  
Data de acesso: 15/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
'liver transplantation'/exp OR 'liver transplantation' AND ('pediatrics'/exp OR 'pediatrics') AND ('basiliximab'/exp OR 'basiliximab') AND [embase]/lim  
Total: 99  
Data de acesso: 16/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A busca nas bases de dados resultou em 130 referências (31 no MEDLINE e 99 no EMBASE). Destas, quatro estavam duplicadas. Cento e vinte e seis referências foram triadas pela leitura de título e resumo. Dezesseis publicações tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destas, 10 foram excluídas. Uma revisão sistemática apresentou uma metaanálise considerando na mesma estimativa dados de estudos que utilizaram daclizumabe ou diferentes esquemas de imunossupressão, o que não foi considerado adequado (os estudos elegíveis foram recuperados na busca e apresentados individualmente). Três estudos (um ensaio clínico e dois comparativos não randomizados) foram conduzidos em população adulta. Seis estudos foram excluídos por serem séries de casos ou descritivos.  
Ao final, seis publicações referentes a três estudos foram consideradas elegíveis, sendo um ensaio clínico randomizado e dois estudos comparativos não randomizados<sup>(23-28)</sup> .  
24

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A descrição sumária dos estudos encontra-se na **Tabela 4** . A **Tabela 5** apresenta as características dos participantes nos estudos. A **Tabela 6** apresenta os desfechos relacionados à imunossupressão reportados nos estudos.  
25  
**Tabela 4 –** Descrição dos estudos avaliando a eficácia e segurança do basiliximabe na fase de indução da imunossupressão  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do**<br>**estudo**|**Detalhes da Intervenção**|**Detalhes do controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|Spada et al.<br>2006<sup>(23)</sup>|ECR|Avaliar imunossupressão<br>com tacrolimo +<br>basiliximabe vs<br>tacrolimo + esteroides<br>em pacientes pediátricos<br>(<18 anos) pós-<br>transplante hepático<br>primário e isolado|Duas doses de BAS (Simulect®; Novartis, Basel,<br>Switzerland)10mg (ou 20mg em pacientes >35kg) IV<br>(infusão 10min): primeira dose em até 6h pós-<br>transplante e segunda dose no PO4. Terceira dose foi<br>administrada no PO8-10 se drenagem abdominal<br>>70mL/kg de peso corporal. Manutenção com TAC<br>(Prograf®;<br>Fujisawa, Munich, Germany) 0,04mg/kg VO em até<br>12h de PO para atingir conventração plasmática de<br>10–15ng/mL nas semanas 1–4; 8–10ng/mL nos meses<br>2–3; 6–8ng/mL nos meses 4–6; e 5–7ng/mL nos meses<br>subsequentes. Todos os pacientes receberam<br>metilprednisolona 10mg/kg IV durante a reperfusão do<br>enxerto|TAC no mesmo esquema descrito no grupo<br>experimental.<br>Metilpredinisolona 2mg/kg/dia IV (dose<br>máxima 40mg) entre dias 1–6.<br>Metilpredinisolona VO 1mg/kg/dia a partir<br>do dia 7 (dose máxima 40mg) reduzida até<br>retirada entre meses 3–6 (exceto se<br>clinicamente indicado sua manutenção).<br>Todos os pacientes receberam<br>metilprednisolona 10mg/kg IV durante a<br>reperfusão do enxerto|1 ano|Alto<br>Não descrito processo de<br>randomização, sigilo da<br>alocação, sem esquema de<br>cegamento|
|Ganschow et<br>al. 2005<sup>(24-26)</sup>|Estudo<br>observacional<br>comparativo<br>(controle histórico<br>pareado)|Avaliar desfechos em<br>longo prazo em<br>pacientes pediátricos<br>pós-transplante hepático<br>que receberam indução<br>com basiliximabe|Duas doses de BAS de 10mg em pacientes <30kg e<br>20mg em pacientes >30kg nos dias PO1 e PO4 +<br>Ciclosporina (NeoralTM, Novartis<br>Pharma, Basel, Switzerland) dose inicial para 150–<br>200 lg/L, até dose de manutenção após 1 anos para 80–<br>100l g/L. Prednisolona (dose inicial 60mg/m2), com<br>redução para 30 mg/m2 após 1 semana seguida de<br>redução semanal de 5 mg/m2 e retirada 12 meses após<br>tx|Controle histórico pareado por idade, sexo e<br>diagnóstico pré tx, que receberam tx<br>hepático nos 3 anos precedentes ao grupo<br>experimental. O grupo controle recebeu<br>terapia dupla com ciclosporina e<br>prednisolona|28-52 meses|Moderado-alto: apesar do<br>pareamento, o controle foi<br>histórico, não recebendo<br>cuidados "contemporâneos",<br>análises não ajustadas|
|Gras et al.<br>2008<sup>(27, 28)</sup>|Estudo<br>observacional<br>comparativo<br>(grupo intervenção<br>prospectivo<br>comparado com<br>série histórica)|Avaliar desfechos em<br>longo prazo (3 anos) da<br>imunossupressão com<br>TAC e BAS vs<br>esteroides +TAC em<br>pacientes pediátricos<br>pós-transplante hepático|TAC VO (Prograf, Fujisawa<br>GmbH) 0,1 mg/kg e ajustada 2x dia para níveis de 8-12<br>ng/mL no 1° mês e após para atinjir 5-8 ng/mL.<br>BAS (Simulect, Novartis Pharma<br>sa) IV, sendo a primeira dose administrada dentro de 8<br>h após a reperfusão do enxerto e a 2° no PO4, dose 10<br>mg (pacientes<35 kg de peso corpora) ou 20 mg<br>(pacientes >35 kg)|Metilprednisolona IV intra-operatório (em<br>bolus 10 mg/kg) e 2 mg/kg/dia entre PO1 e<br>PO6. A corticoterapia foi então alterada<br>para a prednisolona VO com redução<br>gradual (dias 7-13: 1 mg/kg/dia, dias 14-20:<br>0,75 mg/kg/dia, dias 21-28: 0,5mg/kg/dia,<br>após: 0,25 mg/kg/dia, e dias alternados<br>entre mês 3-6|3 anos|Alto. O grupo comparador é<br>proveniente de uma série<br>histórica não recebendo<br>cuidados "contemporâneos", não<br>há descrição de dados<br>importantes de baseline nos<br>grupos, as análises não foram<br>ajustadas|  
ECR: ensaio clínico randomizado; BAS: basiliximabe; IV: intravenoso; tx: transplante; PO: pós-operatório; TAC: tacrolimo, VO: via oral.  
26  
**Tabela 5 –** Características dos pacientes incluídos nos estudos a eficácia e segurança do basiliximabe na fase de indução da imunossupressão  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade, anos**<br>**intervenção**|**Idade, anos**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tipo de t**<br>**inter**|**ransplante**<br>**venção**|**Tipo de transplante**<br>**controle**|**Perda de**<br>**seguimento**<br>**intervenção**|**Perda de**<br>**seguimento**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|Spada<br>et<br>al.<br>2006<sup>(23)</sup>|<br>36|36|Média 2,9<br>(IC95%1,5–4,3)|Média 2,8<br>(IC95%1,5–4,2)|18/36 (50)|15/36 (41,7)|Tempo med<br>dias (mín 0;|iano até tx: 46<br>máx 373)|Tempo mediano até tx:<br>44 dias (mín 1; máx 347)|0|0|
|Ganschow et al.<br>2005<sup>(24-26)</sup>|<br>54|54|Mediana 4,2 anos<br>(mín 0,3; máx 8,9)|<br>NR,<br>mas<br>pareado|NR|, mas pareado|15/54<br>aparentados|doadores<br>vivos|20/54<br>doadores<br>aparentados vivos|0|0|
|Gras<br>et<br>al.<br>2008<sup>(27, 28)</sup>|<br>50|34|1,7 (0,4-14,0)|2,0 (0,4-14,0)|27/50 (54)|16/34(47)|Doador apa<br>26/50(52)<br>Doadores<br>24/50 (48)|rentado vivo:<br>cadavéricos:|Doador aparentado<br>vivo:<br>19/34(55)<br>Doadores cadavéricos:<br>15/34(45)|0|0|  
N: número de pacientes no grupo; IC95%: intervalo de confiança de 95%; tx: transplante; NR: não reportado. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
27

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
|**Autor, ano**|**Desfechos de eficácia intervenção**|**Desfechos de eficácia controle**|**p para**<br>**comparação**|**Eventos adversos intervenção**|**Eventos adversos controle**|**p para comparação**|
|---|---|---|---|---|---|---|
|Spada et al.<br>2006<sup>(23)</sup>|Em 1 ano:<br>Rejeição aguda: 4/36 (11,1)<br>Sobrevida: 32/36 (88,9)<br>Sobrevida do enxerto:<br>29/36 (80,6)<br>Sobrevida livre de rejeição em 1 ano<br>(curva de KM): 87,7%<br>Tempo até primeira rejeição:<br>mediana 28,5 dias<br>(mín 24; máx 33)<br>Em 2 anos:<br>Óbito: 0/32|Em 1 ano:<br>Rejeição aguda: 11/36 (30,6)<br>Sobrevida: 33/36 (91,7)<br>Sobrevida do enxerto:<br>31/36 (86,1)<br>Sobrevida livre de rejeição em 1 ano<br>(curva de KM): 67,6%<br>Tempo até primeira rejeição:<br>mediana 10 dias<br>(mín 5; máx 266)<br>Em 2 anos:<br>Óbito: 0/33|Rejeição:<br>p=0,042<br>Sobrevida:<br>p=0,489<br>Sobrevida do<br>enxerto: p=0,430<br>Sobrevida livre<br>de rejeição:<br>p=0,036<br>Demais: NR|Em 1 ano<br>Complicações vasculares: 5/36 (13,8)<br>Complicações biliares: 6/36 (16,7)<br>Infecção: 18/36 (50)<br>EBV sintomático: 6/36 (17)<br>PTLD: 1/36 (2,7)<br>IRA requerendo diálise: 3/36 (8,3) HAS<br>requerendo<br>Anti-hipertesivos: 3/36 (8,3)<br>Em 2 anos:<br>PTLD: 1/32 (3,1)<br>Sepse (meningite/endocardite):<br>1/32 (3,1)|Em 1 ano:<br>Complicações vasculares: 5/36 (13,8)<br>Complicações biliares: 8/36 (22)<br>Infecção: 26/36 (72,2)<br>EBV sintomático: 4/36 (11)<br>PTLD: 1/36 (2,7)<br>IRA requerendo diálise: 1/36 (2,7)<br>HAS requerendo<br>Anti-hipertesivos: 8/36 (16,7)<br>Em 2 anos:<br>PTLD: 1/32 (3,1)<br>Infecção por EBV: 2/33 (6)|Complicações<br>vasculares: p=NS<br>Complicações biliares:<br>p=0,383<br>Infecção: p=0,035<br>EBV sintomático:<br>p=0,367<br>HAS requerendo anti-<br>hipertesivos: p=0,094<br>Demais: NR|
||Falência de enxerto: 0/32|Falência de enxerto: 0/33||<br>Rejeição crônica<br>(emquimioterapia): 1/32(3,1)|<br>Rejeição crônica: 2/33 (6)||
|Ganschow<br>et al.<br>2005<sup>(24-26)</sup>|Sobrevida: 53/54 (98)<br>Re-tx: 1/54 (18,5)<br>Rejeição aguda: 9/54 (16,6)<br>Rejeição crônica: 4/54(7,4)<br>Rejeição com resistência a esteroide<br>em biópsia: 4/54 (7,4)|Sobrevida: 51/54 (94,4)<br>Re-tx: 3/54 (5,5)<br>Rejeição aguda: 29/54 (53,7)<br>Rejeição crônica: 4/54(7,4)<br>Rejeição com resistência a esteroide<br>em biópsia: 6/54(11)|Rejeição aguda:<br>p<0,001<br>Demais: NR|Infecção: 26/54 (48)<br>Sepse: 5/54 (9,2)<br>PTLD: 1/54 (1,8)<br>HAS: 1/54 (27,8)<br>Toxicidade renal: 2/54 (3,7)<br>Toxicidade SNC: 0<br>Hepatotoxicidade: 0|Infecção: 28/54 (52)<br>Sepse: 4/54 (7,4)<br>PTLD: 0<br>HAS: 17/54 (31,5)<br>Toxicidade renal: 3/54 (5,6)<br>Toxicidade SNC: 2/54(3,7)<br>Hepatotoxicidade: 2/54(3,7)|HAS: NS<br>Toxicidade renal: NS<br>Toxicidade SNC: NS<br>Hepatotoxicidade: NS|
|Gras et al.<br>2008<sup>(27, 28)</sup>|Sobrevida livre de rejeição em 6<br>meses (n=20): 90%<br>Sobrevida livre de rejeição em 12<br>meses (n=20): 75%<br>Sobrevida global em 3 anos: 96%<br>Sobrevida do enxerto em 3 anos:<br>94%<br>Mortalidade em 3 anos: 2/50 (4)<br>Sobrevida livre de rejeição em 3<br>anos: 72%<br>Recorrência de rejeição aguda: 0/50<br>(0)<br>Tempo até rejeição: mediana 23 dias|Sobrevida livre de rejeição em 6<br>meses (n=20): 50%<br>Sobrevida livre de rejeição em 12<br>meses (n=20): 50%<br>Sobrevida global em 3 anos: 91%<br>Sobrevida do enxerto em 3 anos:<br>88%<br>Mortalidade em 3 anos: 3/34 (8)<br>Sobrevida livre de rejeição em 3<br>anos: 41%<br>Recorrência de rejeição aguda: 3/34<br>(9)<br>Tempo até rejeição: mediana 16 dias|p=0,05<br>p=0,05<br>p=0,370<br>p=0,38<br>NR<br>P=0,007<br>NR<br>0,172|HAS requerendo anti-hipertensivos em 1<br>ano: 2/20 (10)<br>Episódios de infecção (bacterial, viral,<br>fúngica): 1,1/paciente<br>Sepse: 7/50 (14)<br>Infecção viral: 0,5/paciente|HAS requerendo anti-hipertensivos em<br>1 ano: 10/20 (50)<br>Episódios de infecção (bacterial, viral,<br>fúngica): 1,3/paciente<br>Sepse:12/34 (35)<br>Infecção viral: 0,7/paciente|<br>HAS: p=0,005<br>Infecção: p=0,711<br>Sepse: p=0,033<br>Infecção viral: 0,045|  
KM: Kaplan-Meyer; NR: não reportado; EBV: Epstein-Barr virus; PTLD: Doença linfoproliferativa pós-transplante; IRA: insuficiência renal aguda; HAS: hipertensão arterial sistêmica; NS: não significativo; tx: transplante; SNC: sistema nervoso central. Dados foram apresentados como n/N (%).  
28  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e  
no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“Para casos de maior risco de rejeição (doador não isogrupo, retransplante, insuficiência hepática aguda grave) e pacientes com insuficiência renal prévia ou atual, recomenda-se como primeira linha de tratamento o uso da associação tacrolimo e basiliximabe. As evidências são limitadas em termos de número de estudos, porém evidenciam redução significante de RAC com o uso da associação basiliximabe + tacrolimo associado ou não ao corticosteroide”

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
((((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR drug therapy[sh] OR randomly[tiab] OR trial[tiab] OR groups[tiab] NOT (animals [mh] NOT humans [mh]))) AND Humans[Mesh])) AND (((((((("thymoglobulin" [Supplementary Concept] OR thymoglobulin OR anti-thymocyte globulin OR antithymocyte globulin OR rabbit antithymocyte globulin))) AND ("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting* OR hepatic grafting)) AND Humans[Mesh])) NOT ("allogeneic hematopoietic stem cell transplantation" OR "allogeneic hematopoietic cell transplantation" OR "hematopoietic cell transplantation" OR "stem cell transplantation" OR "kidney transplantation" OR "renal transplantation" OR "intestinal transplantation" OR "bowel transplantation")) AND Humans[Mesh])  
Total: 127  
Data de acesso: 23/11/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
(('liver transplantation'/exp OR 'liver transplantation' OR 'liver grafting' OR 'hepatic grafting') AND [embase]/lim) AND ((('thymocyte antibody'/exp OR 'thymocyte antibody') AND [embase]/lim OR 'thymoglobulin'/exp OR 'thymoglobulin' OR 'thymoglobuline'/exp OR 'thymoglobuline' OR 'antithymocyte globlulin' OR 'rabbit antithymocyte globulin'/exp OR 'rabbit antithymocyte globulin') AND [embase]/lim) NOT (('allogeneic hematopoietic stem cell transplantation'/exp OR 'allogeneic hematopoietic stem cell transplantation' OR 'allogeneic hematopoietic cell transplantation'/exp OR 'allogeneic hematopoietic cell transplantation' OR 'hematopoietic cell transplantation'/exp OR 'hematopoietic cell transplantation' OR 'stem cell transplantation'/exp OR 'stem cell transplantation' OR 'kidney transplantation'/exp OR 'kidney transplantation' OR 'renal transplantation'/exp OR 'renal transplantation' OR 'intestinal transplantation' OR 'bowel transplantation') AND [embase]/lim) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim)  
Total: 113  
Data de acesso: 23/11/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A busca nas bases de dados resultou em 240 referências (127 no MEDLINE e 113 no EMBASE). Destas, 23 estavam duplicadas. Duzentas e dezessete referências foram triadas pela leitura de título e resumo. Treze ensaios clínicos randomizados tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Desses, dois foram excluídos, sendo um por se tratar de resumo de congresso, para o qual o artigo completo já foi publicado e incluído; e outro por não relatar os desfechos de eficácia rejeição e  
29  
sobrevida. Dessa forma, 11 ensaios clínicos randomizados, todos conduzidos em doentes adultos, foram incluídos<sup>(29-39)</sup> . Além desses, foi inclusa uma série de casos retrospectiva<sup>(79)</sup> , avaliando a timoglobulina em doentes pediátricos. Sendo assim, foram considerados ao todo 12 referências.  
- **3) Descrição dos estudos e seus resultados**  
A descrição sumária dos estudos encontra-se na **Tabela 7** . A **Tabela 8** apresenta as características dos participantes nos estudos. A **Tabela 9** apresenta os desfechos relacionados à imunossupressão reportados nos estudos. Na **Tabela 10** estão os principais eventos adversos relatados.  
30  
**Tabela 7 –** Descrição dos estudos avaliando a eficácia e segurança da timoglobulina na fase de indução da imunossupressão  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Detalhes do controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|Dick et al.<br>2013<sup>(79)</sup>|Série de casos<br>retrospectiva|Avaliar o efeito da<br>imunossupressão de indução com<br>TG em população pediátrica<br>transplantada de fígado|Indução: TG 3 mg/kg intraoperatório e<br>2mg/kg no dia 1 pós-operatório.<br>Manutenção: monoterapia com TAC|NA|6 meses|Alto.<br>Análise retrospectiva, sem descrição de<br>variáveis de base essenciais, análises não<br>ajustadas, desfechos não apropriadamente<br>relatados|
|De Sicilia et al.<br>2014; Grant et<br>al. 2012<sup>(36, 37)</sup>|ECR|Subgrupos de pacientes adultos,<br>HCV positivos e realizando<br>transplante primário de fígado.<br>Objetivo: avaliar a segurança e<br>eficácia da TG em casos resistentes<br>a terapia primária|Indução: TG 1,5 mg/kg dia 0 (fase<br>anepática), depois nos dias 2, 4 e 6<br>associado ao TAC 0,075 BID mg/kg a<br>partir do dia 7<br>Manutenção: TAC + prednisona pelo por<br>período de 1 ano|TAC 0,075 mg/kg, BID após<br>um dia do transplante|Aprx. 21<br>meses|Alto<br>Análise de um subgrupo com HCV; não utilizou<br>análise por ITT; não descreve como foi<br>realizado o sigilo de alocação.|
|Benitez et al.<br>2010<sup>(29)</sup>|ECR|Pacientes maiores de 18 anos com<br>transplante primário de fígado.<br>Objetivo: avaliar a segurança e<br>eficácia da TG em casos resistentes<br>a terapia primária e a redução de<br>dose de TAC|Indução: TG 9 mg/kg 2-3 hrs antes do<br>transplante (infundido i.v.por 6h); 500 mg<br>metilprednisolona i.v.; 1g acetaminofeno<br>i.v.; e 20 mg defenidramina i.v. TAC oral<br>foi administrado 0,05 mg/kg/dia no dia após<br>a cirurgia.|TAC 0,05 mg/kg/dia no dia<br>após a cirurgia, associado a 1g<br>metilprednisolona IV durante<br>a cirurgia e 20 mg de<br>prednisona no primeiro mês<br>pós-transplante.|12 meses|Incerto<br>Apesar de não haver direcionamento a favor da<br>intervenção, a utilizada foi menor aquela<br>calculada formalmente; ademais, o estudo foi<br>interrompido antes do planejado, por falta de<br>eficácia.|
|Casciato et al.<br>2010 (33)|ECR|Pacientes adultos cirróticos com<br>falha renal. Objetivo: Avaliar a<br>eficácia e a segurança de três<br>esquemas de retirada de inibidores<br>da calcineurina|Indução: 1) TG 1,5 mg/kg por 7 dias; 2) 1,5<br>mg/kg por 3 dias|Basiliximabe 20 mg nos dias 1<br>e 4|NR|Alto<br>Resumo de congresso sem informações<br>necessárias para julgamento|  
31  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Detalhes do controle**|**Tempo de**<br>**seguimento**||**Risco de viés**|
|---|---|---|---|---|---|---|---|
|Boillot et al.<br>2009<sup>(32)</sup>|ECR|Avaliar os efeitos da indução com<br>TG em pacientes adultos<br>submetidos a alotransplante<br>hepático ortotópico, incluindo<br>transplante parcial|Indução: TG dose inicial 100mg/dia com<br>início no intraoperatorio até o dia 6.<br>Manutenção: TAC dose inicial 0,075 mg/kg<br>2x/dia ajustada para níveis de 8-12 ng/mL<br>no mês 1, 7-10 ng/mL durante o primeiro<br>ano e 3-7 ng/mL em diante de acordo com a<br>tolerância. Micofenolato de mofetila VO<br>dose inicial 2 g/dia e ajustada para 1 g/dia<br>ou menos conforme eficácia e tolerância.<br>Solumedrol 500 mg intraoperatório, após<br>20 mg/dia com redução progressiva para 5<br>mg/dia e, se possível, suspensão até o mês 3|Mesmo esquema de<br>imunossupressão sem indução<br>com TG|5 anos|Alto<br>Sem descrição d<br>sigilo da alocaçã|o método de randomização e<br>o|
|Bogetti et al.<br>2005<sup>(30, 31)</sup>|ECR|Avaliar os efeitos da indução com<br>TG na proteção contra injúria<br>isquêmica/reperfusão em receptor<br>de transplante hepático de doador<br>cadavérico|Indução: TG 1,5 mg/kg/dose durante a fase<br>anepática e 2x dose no pós-operatório em<br>dias alterados<br>Manutenção: TAC dose inicial de 0,1<br>mg/kg (níveis entre 5 e 10 nng/dL). Em<br>presença toxicidade ao TAC, ciclosporina<br>alvo nível de 100-150 ng/mL.<br>Metiloprednisolona 500mg pré-operatório e<br>prednisona no pós-operatório,<br>suspendendo-se no dia 90 pós-operatório|Indução: TG 1,5 mg/kg/dose<br>durante a fase anepática ou no<br>pós-operatório<br>Manutenção: TAC dose inicial<br>de 0,1 mg/kg (níveis entre 5 e<br>10 ng/dL). Em presença<br>toxicidade ao TAC,<br>ciclosporina alvo nível de 100-<br>150 ng/mL. Esteroide:<br>metilprednisolona 500 mg pré-<br>operatório e prednisona no<br>pós, suspendendo-se no dia 90<br>pós-operatório|3 meses|Alto. Sem descr<br>randomização e<br>tamanho de amo|ição do método de<br>sigilo da alocação, aberto,<br>stra pequeno|  
32  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Detalhes do controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|Eason et al.<br>2003 e 2001<br>(34, 35)|ECR|Avaliar a eficácia e a segurança da<br>TG em substituição aos esteroides<br>na terapia de indução em pacientes<br>adultos realizando transplante<br>ortotópico de fígado|Indução: TG 1,5 mg/kg na fase anepática e<br>no dia posterior ao transplante.<br>Manutenção:<br>Fase I: TAC nível de 10-12 ng/mL no dia 5<br>+ MMF 1 g 2x/dia<br>Fase II: MMF foi descontinuado em 2<br>semanas|Indução: 1g metilprednisolona<br>durante a fase anepática com<br>seguinte redução para 20 mg<br>de prednisona no dia 6.<br>Manutenção:<br>Fase I: TAC nível de 10-12<br>ng/mL no dia 5 + MMF 1 g<br>2x/dia + prednisona<br>Fase II: MMF foi<br>descontinuado em 2 semanas|Média de 18,5<br>meses|Alto: sem descrição do método de<br>randomização e sigilo da alocação|
|Neuhaus et al.<br>2000<sup>(39)</sup>|ECR|Avaliar a eficácia<br>imunossupressora das terapias de<br>indução dupla (TAC + esteroides)<br>vs. a quádrupla (TAC + AZA + TG<br>+esteroide) e pacientes adultos que<br>realizaram transplante ortotópico<br>de fígado.|Indução: TAC 0,025 mg/kg 2x/dia do dia 0<br>até o 2. A dose foi aumentada para 0,05<br>mg/kg entre os dias 3 e 5 e depois para 0,1<br>mg/kg até o dia 7. Bolus de<br>metilprednisolona 500 mg na reperfusão e<br>250 mg após 6h de transplante.<br>Prednisolona foi iniciada em 100 mg no dia<br>1 e reduzida gradualmente até 15 mg em<br>dois meses pós-transplante. AZA 150 mg<br>pré transplante e 25 mg/dia após o<br>transplante até o dia 7. TG 0,5 mg i.v dos<br>dias 0 a 5.|Indução: TAC 2 mg iniciado<br>6h após o após o transplante e<br>continuado em 0,05 mg/kg até<br>o dia 2. A dose foi aumentada<br>para 0,1 mg/kg até o dia 7.<br>Bolus de metilprednisolona<br>500 mg na reperfusão e 250<br>mg após 6h de transplante.<br>Prednisolona foi iniciada em<br>100 mg no dia 1 e reduzida<br>gradualmente até 15 mg em<br>dois meses pós-transplante|Média de 42<br>meses|Alto: Sem descrição do método de<br>randomização e sigilo da alocação|  
33  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Detalhes do controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||Avaliar a eficácia e a segurança de<br>dois esquemas quádruplos de|Indução: TG 5 mg/kg/dia. CsA iniciada<br>ente 6 e 48 horas pós-transplante na dose de<br>1mg/kg 2x i.v. Após 3 meses a CsA deveria|Indução: BT563 10 mg/dia.<br>CsA iniciada ente 6 e 48 horas<br>pós-transplante na dose de 1<br>mg/kg 2x i.v.Após 3 meses a<br>CsA deveria se manter entre|||
|Langrehr et al.<br>1997<sup>(38)</sup>|ECR|indução, um contendo anticorpo do<br>receptor de IL-2 (BT563) e o outro<br>contendo TG, em pacientes adultos|se manter entre 300-600 ng/mL. Durante a<br>cirurgia 500 mg de prednisona bolus foi<br>utilizado e depois de 6 horas um novo bolus|300-600 ng/mL. Durante a<br>cirurgia 500 mg de prednisona<br>bolus foi utilizado e depois de|Mínimo de 3<br>anos|Alto: Sem descrição do método de<br>randomização e sigilo da alocação|
|||com transplante ortotópico de|de 250 mg foi adicionado. Antes da cirurgia|6 horas um novo bolus de 250|||
|||fígado|150 mg de AZA foi administrada e após 25<br>mg de AZA/dia.|mg foi adicionado. Antes da<br>cirurgia 150 mg de AZA foi<br>administrada e após 25 mg de<br>AZA/dia.|||  
ECR: ensaio clínico randomizado; TG: timoglobulina, TAC: tacrolimo, VO: via oral, NA: não se aplica; HCV: Vírus da hepatite C; BID: duas vezes ao dia; ITT: análise por intenção de tratar; MMF: micofenolato de mofetila; AZA: azatioprina; CsA: ciclosporina.  
**Tabela 8 –** Características dos pacientes incluídos nos estudos a eficácia e segurança da timoglobulina na fase de indução da imunossupressão  
|**Autor, ano**|**N intervenção**|**N**<br>**controle**|**Idade, anos**<br>**intervenção,**<br>**média (DP)**|**Idade, anos**<br>**controle, média**<br>**(DP)**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tipo de transplante**<br>**intervenção**|**Tipo de transplante**<br>**controle**|**Perda de**<br>**seguimento**<br>**intervenção**|**Perda de**<br>**seguimento**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|
|Dick et al. 2013<sup>(79)</sup>|38|NA|NR|NA|NR|NA|NR|NA|NR|NA|
|De Sicilia et al. 2014;<br>Grant et al. 2012<sup>(36, 37)</sup>|26|23|55,5 (7,07)|53,3 (6,9)|18 (69)|16 (70)|Primeiro transpl.|Primeiro transpl.|5|4|  
34  
|**Autor, ano**|**N intervenção**|**N**<br>**controle**|**Idade, anos**<br>**intervenção,**<br>**média (DP)**|**Idade, anos**<br>**controle, média**<br>**(DP)**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tipo de transplante**<br>**intervenção**|**Tipo de transplante**<br>**controle**|**Perda de**<br>**seguimento**<br>**intervenção**|**Perda de**<br>**seguimento**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|
|Benitez et al. 2010<sup>(29)</sup>|21|16|51 (11)|53 (9)|18 (84)|12 (75)|Primeiro transpl.|Primeiro transpl.|9|3|
|Casciato et al.<br>2010<sup>(33)</sup>|TG reg: 17<br>TG Baixa dose:<br>14|Basi: 14|NR|NR|NR|NR|NR|NR|NR|NR|
|Boillot et al. 2009<sup>(32)</sup>|44|49|50,5 (9,1)|48,9 (8,8)|57%|59%|Todos de doador<br>cadavérico, sendo 4<br>"split"|Todos de doador<br>cadavérico, sendo 4<br>"split"|22,7%|NR12,2%|
|Bogetti et al. 2005<sup>(30,</sup><br>31)|12|10|52 (mín 27;<br>máx 67)|53 (mín 47;<br>máx 62)|5/12 (71,4)|08/10 (80)|Doador cadavérico<br>com morte<br>encefálica|Doador cadavérico<br>com morte<br>encefálica|NR|NR|
|Eason et al. 2003 e<br>2001<sup>(34, 35)</sup>|60|59|NR|NR|NR|NR|Ortotópico|Ortotópico|NR|NR|
|Neuhaus et al.<br>2000<sup>(39)</sup>|59|61|45 (11)|46 (10)|34 (58)|40 (66)|Primário e<br>ortotópico|Primário e<br>ortotópico|NR|NR|
|Langrehr et al.<br>1997<sup>(38)</sup>|41|39|38,6 (3,7)|42,5 (4,3)|26 (63)|26 (66,7)|Primário e<br>ortotópico|Primário e<br>ortotópico||9|  
Transpl.: transplante; N: número de pacientes no grupo; NR: não reportado, NA: não se aplica. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
35  
**Tabela 9 –** Desfechos a eficácia e segurança da timoglobulina na fase de indução da imunossupressão  
|**Autor, ano**|**Desfechos intervenção**|**Desfechos controle**|**p para comparação**|
|---|---|---|---|
|Dick et al. 2013<sup>(79)</sup>|Tempo até primeira rejeição: 7-210 dias com 46% dos episódios de rejeição<br>ocorrendo<br>no<br>primeiro<br>mês<br>pós-transplante.<br>Complicações linfoproliferativas: 0<br>Infecção por CMV: 2|<br>NA|NA|
||Recorrência: 7 (26,9)|Recorrência: 17 (73,9)|0,001|
|De Sicilia et al. 2014; Grant et al.<br>2012<sup>(36, 37)</sup>|<br>Sobrevida em 1 ano: 80%<br>Sobrevida em 2 anos: 56%<br>Rejeição aguda: 19,2%<br>Infecção: 46,1%|Sobrevida em 1 ano: 86%<br>Sobrevida em 2 anos: 81%<br>Rejeição aguda: 8,7%<br>Infecção: 34,7%|0,558<br>0,089<br>0,263<br>0,562|
||Infecção fúngica: 5 (19,2%)|Infecção fúngica: 0|0,034|
||Taxa de filtração glomerular (mediana): 7,4|Taxa de filtração glomerular (mediana): -8,79|0,02|
|Benitez et al. 2010<sup>(29)</sup>|Ad hoc<br>Sobrevida 1 ano: 95,23%<br>Sobrevida do enxerto: 90,47%<br>Rejeição: 83,3%<br>|Ad hoc<br>Sobrevida 1 ano: 93,75%<br>Sobrevida do enxerto: 93,75%<br>Rejeição: 31%<br>ITT|NS<br>NS<br>0,008|
||ITT<br>Pelo menos 1 rejeição aguda: 66,7%<br>Rejeição aguda em 3 meses: 52,4%<br>Rejeição aguda após 3 meses: 61,9%|Pelo menos 1 rejeição aguda: 31,2%<br>Rejeição aguda em 3 meses: 25%<br>Rejeição aguda após 3 meses: 6,2%|0,033<br>0,09<br>0,001|
|Casciato et al 2010<sup>(33)</sup>|Rejeição aguda:<br>4 (23)<br>3 (21)|Rejeição aguda:<br>BASI: 6 (43)|P<0,05|
|.|Sobrevida:<br>15 (88)<br>11 (79)|Sobrevida:<br>BASI: 12 (85)|NS|
|Boillot et al. 2009<sup>(32)</sup>|Em 5 anos: Rejeição comprovada por biópsia: 5/44 (11,4%; IC95% 3,8-<br>24,6)<br>Tempo até rejeição: 132 (141) dias; mínimo 15, máximo 366<br>Óbito: 10/44<br>Função hepática normal: 27/34 (79)<br>Biópsia normal ou quase normal: 24/34 (70,6)<br>Infecção requerendo ATB: 22/44 (50)<br>Infecçãopor CMV: 6/44(13,6)|Em 5 anos:<br>Rejeição comprovada por biópsia: 7/49 (14,3%; IC95% 5,9-27,2)<br>Tempo até rejeição: 26 (40) dias; mínimo 4, máximo 110<br>Óbito: 6/49 (12,2)<br>Função hepática normal: 41/43 (95,3)<br>Biópsia normal ou quase normal: 31/39 (79,5)<br>Infecção requerendo ATB: 18/49 (37)<br>Infecçãopor CMV: 3/49(6,1)|Função hepática normal:<br>p<0,03<br>Necessidade de diálise<br>perioperatória: p=0,3<br>Contagem de leucócitos até dia<br>7: p<0,05<br>Demais: NS|  
36  
|**Autor, ano**|**Desfechos intervenção**|**Desfechos controle**|**p para comparação**|
|---|---|---|---|
||De novo diabetes requerendo insulina>30 dias: 9/44 (21)<br>De novo hipertensão arterial requerendo administração prolongada de<br>antiipertensivo: 13/44 (30)<br>Doença linfoproliferativa: 0|De novo diabetes requerendo insulina>30 dias: 9/49 (18)<br>De novo hipertensão arterial requerendo administração prolongada<br>de antiipertensivo: 13/49 (27)<br>Doença linfoproliferativa: 0||
||Kaposi síndrome: 0<br>Recorrência de HCV: 5/7 (71)|Kaposi síndrome: 0<br>Recorrência de HCV: 8/10 (80)||
||Perioperatório:|Perioperatório:||
||Disfunção precoce do enxerto (elevação de aminotransferases >1500 IU/L e|Disfunção precoce do enxerto (elevação de aminotransferases||
||razão de protrombina <50% até dia 7): 3/44 (6,8)<br>Necessidade de diálise perioperatória: 11/44 (25)|>1500 IU/L e razão de protrombina <50% no dia 7): 4/49 (8,2)<br>Necessidade de diálise perioperatória: 4/44 (16,3)||
||Contagem de leucócitos até dia 7: significativamente menor que grupo<br>controle|||
||Sobrevida em 3 meses: 100%|Sobrevida em 3 meses: 100%|p=1|
||Sobrevida do enxerto em 3 meses: 100%|Sobrevida do enxerto em 3 meses: 100%|p=1|
|Bogetti et al 2005<sup>(30, 31)</sup>|Tempo de hospitalização: 8 dias (3)<br>|Tempo de hospitalização: 13 dias (8)<br>|p= 0,047<br>|
|.|Rejeição aguda em 3 meses: 25%|Rejeição aguda em 3 meses: 30%|p=0,08|
||Infecção por CMV: 6%|Infecção por CMV: 8%|NR|
||Eventos adversos graves: 0|Eventos adversos graves: 0|p=1|
||Sobrevida em 1 ano: 85%|Sobrevida em 1 ano: 85%|NS|
||Sobrevida em 2 anos: 82%|Sobrevida em 2 anos: 83%|NS|
|E t l 2003  2001<sup>(34, 35)</sup>|Sobrevida do enxerto 1 ano: 82%|Sobrevida do enxerto 1 ano: 80%|NS|
|ason e a.  e|Rejeição: 25%|Rejeição: 31%|NS|
||Rejeição necessitando esteroide: 6,6%|Rejeição necessitando esteroide: 50%|P=0,03|
||HCV recorrente: 18/29|HCV recorrente: 24/33|NS|
||Sobrevida em 1 ano: 96,6%|Sobrevida em 1 ano: 91,8%|0,32|
||Sobrevida em 3 anos: 94,9%|Sobrevida em 3 anos: 88,5%||
|Neuhaus et al 2000<sup>(39)</sup>|Sobrevida do enxerto 1 ano: 91,5%|Sobrevida do enxerto 1 ano: 88,5%|0,78|
|.|Sobrevida do enxerto 3 anos: 84,8%|Sobrevida do enxerto 3 anos: 86,9%||
||Rejeição: 42%|Rejeição: 41%|0,9|
||Rejeição aguda: 24,6%|Rejeição aguda: 27,1%|0,87|
||Sobrevida em 1 ano: 90,2%|Sobrevida em 1 ano: 84,6%||
||Sobrevida em 2 anos: 87,8%|Sobrevida em 2 anos: 84,6%||
|Langrehr et al. 1997<sup>(38)</sup>|Sobrevida em 3 anos: 87,8%|Sobrevida em 3 anos: 84,6%|NS|
||Sobrevida do enxerto 1 ano: 82,9%|Sobrevida do enxerto 1 ano: 79,5%||
||Sobrevida do enxerto 2 anos: 82,9%|Sobrevida do enxerto 2 anos: 79,5%||  
37  
|**Autor, ano**|**Desfechos intervenção**|**Desfechos controle**|**p para comparação**|
|---|---|---|---|
||Sobrevida do enxerto 3 anos: 82,9%|Sobrevida do enxerto 3 anos: 79,5%||
||Rejeição: 18 (43,9)|Rejeição: 8 (20,5)||  
CMV: citomegalovírus; NR: não reportado; IC95%: intervalo de confiança de 95%; ATB: antibioticoterapia; HCV: vírus hepatite C; NS: não significativo; NA: não se aplica. Dados foram apresentados como n/N (%);  
Adhoc: população que finalizou o seguimento; ITT: população por intenção de tratar; IC95%: intervalo de confiança de 95%.  
38  
**Tabela 10 –** Principais eventos adversos relatados pelos estudos  
|**Evento adverso**|**Benitez e**|**t al., 2010**|**valorp**|**Ca**|**sciato et al., 2010**||**valorp**|**Autor, a**<br>**Eason et**|**no**<br>**al., 2003 e 2001**|**valorp**|**Neuhaus et a**|**l., 2000**|**Langre**<br>**1**|**hr et al.,**<br>**997**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**G**|**T**<br>**AC**||**TG 1,5/7d**|**TG 1,5/3d**|**ASI**|**B**|**G**|**T**<br>**Esteroides**||**TG (terapia**<br>**quadrupla)**|**Terapia**<br>**dupla**|**TG**|**BT563**|
|Infecções, n (%)|1(52,3)|1<br>3(81)|S|NR|NR|R|N<br>S|3(22)|1<br>15 (25)|S|20 (32,8)|20 (33,9)|31<br>(75,6)*|24<br>(61,5)*|
|Inf. Bacteriana, n (%)|1(52,3)|1<br>3(81)|S|5 (29)|3 (21)|(14)|2<br>S|R|N<br>NR|A|NR|NR|46|41|
|Inf. CMV, n (%)|0(4,76)|1<br>0(6,25)|S|5 (29)|2 (14)|(14)|2<br>0,05|(5)|3<br>14 (23)|,05|7 (11,5)|1 (1,7)|3|1|
|Reoperação, n (%)|R|N<br>R|R|NR|NR|R|N<br>R|R|N<br>NR|R|12 (20)|8 (13)|NR|NR|
|Dist. Cardiovascular, n<br>(%)|R|N<br>R|R|NR|NR|R|N<br>R|R|N<br>NR|R|8 (13,6)|11 (18)|NR|NR|
|Dist. Neurológico, n<br>(%)|R|N<br>R|R|NR|NR|R|N<br>R|R|N<br>NR|R|16 (27,1)|15 (24,6)|NR|NR|
|Dist. hematologicos, n<br>(%)|R|N<br>R|R|NR|NR|R|N<br>R|R|N<br>NR|R|11 (18,6)|8 (13)|NR|NR|
|Inf. Fúngica, n (%)|0|0|S|NR|NR|R|N<br>R|R|N<br>NR|A|NR|NR|7|9|
|Estenose biliar, n (%)|0|(31,25)|,008|NR|NR|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Anastomose, n (%)|0|(18,75)|,045|NR|NR|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Não anastomose, n<br>(%)|0|(12,5)|S|NR|NR|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Bilioma, n (%)|0 (4,76)|1<br>0|S|NR|NR|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Trombose de artéria<br>hepática, n (%)|0 (4,76)|1<br>(12,5)|S|NR|NR|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Sangramento<br>intraoperatório, n (%)|(23,8)|5<br>(12,5)|S|N<br>R|N<br>R|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|  
39  
||||||||||**Autor, an**|**o**||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Evento adverso**|**Benitez e**|**t al., 2010**|**valorp**|**Ca**|**sciato et al.,**|**2010**||**valorp**|**Eason et**|**al., 2003 e 2001**|**valorp**|**Neuhaus et a**|**l., 2000**|**Langr**<br>**1**|**ehr et al.,**<br>**997**|
||**G**|**T**<br>**AC**||**TG 1,5/7d**|**TG 1,5/3d**||**ASI**|**B**|**G**|**T**<br>**Esteroides**||**TG (terapia**<br>**quadrupla)**|**Terapia**<br>**dupla**|**TG**|**BT563**|
|Neurotoxicidade do<br>TAC, n (%)|(19,0)|4<br>(25)|S|N<br>R|R|N|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|HAS, n (%)|(14,28)|3<br>(18,75)|S|N<br>R|R|N|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Diabetes mellitus, n<br>(%)|(14,28)|3<br>(31,5)|S|N<br>R|R|N|R|N<br>R|R|N<br>NR|A|8 (13,6)|4 (6,6)|NR|NR|
|Fraturas, n (%)|0||S|N<br>R|R|N|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Rejeição crônica, n(%)|0||S|N<br>R|R|N|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|
|Hipersensibilidade a<br>TG, n (%)|0 (4,76)|1|S|N<br>R|R|N|R|N<br>R|R|N<br>NR|A|NR|NR|NR|NR|  
*Valor corresponde ao número de pacientes e porcentagem em relação ao total; os demais valores correspondem ao número de evento e, não necessariamente ao número de pacientes. NR: Não relatado; NS: Não  
significante; TG: timoglobulina; BASI: basiliximabe; TAC: tacrolimus; TG: timoglobulina; HAS: hipertensão arterial sistêmica; BASI: basiliximabe.  
40  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“Não é possível recomendar o uso da timoglobulina na fase de indução da imunossupressão do transplante hepático em pediatria. As evidências disponíveis não permitem concluir sobre a superioridade da timoglobulina em relação ao esquema de indução de imunossupressão recomendado como primeira linha, sendo que a maioria dos estudos não evidenciou diferenças para os desfechos rejeição do enxerto, recorrência de hepatite C, sobrevida do enxerto ou global e infecção”.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting*) AND ((extended-release OR extended release) AND ("Tacrolimus"[Mesh] OR tacrolimus))  
Total: 18  
Data de acesso: 15/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
'tacrolimus'/exp OR 'tacrolimus' AND ('extended release' OR 'extended release formulation' OR 'xl' OR 'extended-release') AND ('liver transplantation'/exp OR 'liver transplantation') AND [embase]/lim  
Total: 47  
Data de acesso: 16/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A busca nas bases de dados resultou em 65 referências (18 no MEDLINE e 47 no EMBASE). Destas, 15 estavam duplicadas. Cinquenta referências foram triadas pela leitura de título e resumo. Quinze referências tiveram seus textos completos avaliados na íntegra, sendo sete excluídas por serem estudos observacionais conduzidos em população adulta. Um estudo que sumarizou os resultados de dois estudos randomizados Fase II conduzidos em adultos foi adicionalmente excluído, pois incluiu população com transplante hepático e renal, sem apresentar os resultados estratificados. Adicionalmente, três resumos de congresso que não tinham informações suficientes sobre população (se adulto ou pediátrico) ou desfechos foram excluídos.  
Apenas três estudos observacionais conduzidos em população pediátrica, dois deles publicados como resumo de congresso, foram identificados(80-82). Adicionalmente, um ensaio clínico randomizado que responde à questão, porém conduzido em população adulta, foi incluído como fonte de evidência indireta<sup>(53)</sup> , totalizando quatro estudos elegíveis<sup>(53, 80-82)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A descrição sumária dos estudos encontra-se na **Tabela 11** . A **Tabela 12** apresenta as características dos participantes nos  
estudos. A **Tabela 13** apresenta os desfechos relacionados à imunossupressão reportados nos estudos.  
41  
**Tabela 1 –** Descrição dos estudos avaliando a eficácia da apresentação TAC de liberação prolongada na fase de manutenção da imunossupressão  
|**Autor, ano**|**Desenho de estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Detalhes do controle**|**Tempo de seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|Heffron et al.<br>2007<sup>(80)</sup>|Estudo observacional,<br>prospectivo,<br>multicêntrico|Avaliar eficácia do TAC de liberação<br>prolongada em população pediátrica, <12<br>anos, ambos os sexos, pós-transplante<br>hepático realizado há pelo menos 6 meses<br>e estáveis por 2 semanas em uso de<br>imunossupressão com TAC 2x/dia|Conversão para TAC liberação<br>prolongada 1x/dia, no dia 8 após o início<br>do estudo|NA|1 ano|Moderado<br>Apesar das análises<br>terem sido ajustadas, o estudo é<br>uma série de casos|
|Quintero et al.<br>2015<sup>(81)</sup>|Série de casos<br>retrospectiva|Avaliar a eficácia e segurança da<br>conversão de TAC 2x/dia para TAC de<br>liberação prolongada 1x/dia em pacientes<br>pediátricos pós-transplante hepático<br>estáveis|TAC de liberação prolongada 1x/dia,<br>dose 1:1 em relação à dose diária, em<br>pacientes com >1 ano pós-transplante e<br>taxa de filtração glomerular >60<br>mL/min/m2 por pelo menos 6 meses pré-<br>conversão|NA|36 meses|Alto<br>Série de casos para avaliar<br>eficácia|
|Sampol-Manos<br>et al. 2011<sup>(82)</sup>|Série de casos<br>retrospectiva|Avaliar impacto clínico, qualidade de<br>vida e aderência após a conversão de<br>TAC 2x/dia para TAC de liberação<br>prolongada 1x/dia em pacientes<br>pediátricos pós tx de órgãos sólidos (6<br>hepáticos, 2 renais)|TAC de liberação prolongada 1x/dia dose<br>1:1|NA|NR|Alto<br>Pequena série de casos para<br>avaliar impacto clínico e<br>qualidade de vida, incluindo<br>dois casos de tx renal|
|Kim<br>et<br>al.<br>2015<sup>(53)</sup>|ECR de não-<br>inferioridade|Comparar a eficácia e a segurança do<br>TAC de liberação prolongada versus TAC<br>2x/dia em adultos transplantados de<br>fígado|TAC liberação prolongada 1x/dia, dose<br>média de 1mg|TAC 2x/dia, dose média de<br>1 mg|6 meses|Alto<br>Não há descrição adequada de<br>nenhum dos domínios<br>considerados. As análises não<br>foram por intenção de tratar|  
TAC: tacrolimo; tx: transplante; NA: não se aplica; NR: não reportado; ECR: ensaio clínico randomizado.  
42  
**Tabela 22 –** Características dos pacientes incluídos nos estudos avaliando a eficácia da apresentação TAC de liberação prolongada  
|**Autor, ano**|**N**<br>**intervenção**|**N**<br>**controle**|**Idade, anos**<br>**intervenção**|**Idade,**<br>**anos**<br>**controle**|**% sexo**<br>**masculino**<br>**intervenção**|**% sexo**<br>**masculino**<br>**controle**|**Tempo entre tx e**<br>**conversão**<br>**Intervenção***|**Tempo entre tx**<br>**e início**<br>**tratamento**<br>**Controle****|**Tipo de tx intervenção**|**Tipo de tx**<br>**controle**|**Perda de seguimento**<br>**intervenção**|**Perda de seguimento**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Heffron et al.<br>2007<sup>(80)</sup>|18|NA|8,6 (5,0-13,0)|NA|5/18 (28)|NA|1426 dias<br>(218 – 3776)|NA|Fígado inteiro de<br>doador falecido: 55,6%<br>Fígado parcial do<br>doador falecido: 22,2%<br>Doador vivo: 22,2%|NA|Descontinuação: 0/18<br>(0)|NA|
|Quintero et al.<br>2015<sup>(81)</sup>|43|NA|9,6 (3,0)|NA|60,9%|NA|5,9 anos (3,1)|NA|NR|NA|NR|NA|
|Sampol-Manos<br>et al. 2011<sup>(82)</sup>|8 (sendo 2 tx<br>renal)|NA|16,6 (3,3)|NA|50%|NA|> 6 meses|NA|NR|NA|NR|NA|
|Kim<br>et<br>al.<br>2015<sup>(53)</sup>|48|46|34 (22-66)|35 (21-56)|22/39 (56,4)|27/40 (67,5)|55 meses<br>(13-204)|48 meses (15-<br>180)|Doador vivo:<br>28/39 (71,8)|Doador vivo:<br>32/40 (80)|Descontinuação: 3/48<br>(6)|Descontinuação: 4/46<br>(9)|  
N: número de pacientes no grupo; tx: transplante; TAC: tacrolimo; XR: liberação prolongada; NA: não se aplica; NR: não reportado. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).*Tempo até a conversão para TAC liberação prolongada. **Tempo até o início do tratamento com TAC liberação normal. No ECR incluso a conversão não se aplica e o tempo se refere ao início do tratamento com TAC liberação prolongada.  
43  
**Tabela 33 –** Desfechos a eficácia e segurança da apresentação TAC de liberação prolongada na fase de manutenção da imunossupressão básica  
|**Autor, ano**|**Desfechos de Eficácia**<br>**Intervenção**|**Desfechos de Eficácia**<br>**Controle**|**p para comparação**|**Desfechos de Segurança**<br>**Intervenção**|**Desfechos de Segurança**<br>**Controle**|**p para comparação**|
|---|---|---|---|---|---|---|
|Heffron et al. 2007<sup>(80)</sup>|Rejeição aguda: 0/18 (0)<br>Perda do enxerto: 0/18 (0)<br>Mortalidade: 0/18 (0)|NA|NA|Não houve aumento na incidência de<br>eventos ao longo do tempo de<br>tratamento, não ocorreram<br>malignidades após a conversão<br>Os parâmetros laboratoriais<br>investigados permaneceram normais e<br>estáveis|NA|NA|
|Quintero et al. 2015<sup>(81)</sup>|Rejeição aguda em<br>36 meses: 0<br>Aderência (EAV)<br>Pré: 82 (12,1)<br>Aderência (EAV)<br>Após 1 ano: 96,6 (7,5); p<0,07|NA|NA|Evento adverso m 36 meses: 0|NA|NA|
|Sampol-Manos et al. 2011<sup>(82)</sup>|Rejeição: 0<br>"Adolescentes relataram melhora<br>da qualidade de vida após<br>conversão"|NA|NA|Evento adverso: 0|NA|NA|
|Kim et al. 2015<sup>(53)</sup>|Rejeição aguda comprovada por<br>biópsia: 0/39 (0)<br>Perda do enxerto: 0/39 (0)<br>Mortalidade: 0/39 (0)|Rejeição aguda comprovada por<br>biópsia: 0/40 (0)<br>Perda do enxerto: 0/40 (0)<br>Mortalidade: 0/40 (0)|P> 0,05 para todas as<br>comparações|Sem diferenças entre os grupos,<br>porém os resultados não são relatados<br>de acordo com o grupo. Apenas se<br>relata que 109 eventos em 56/91<br>pacientes ocorreram<br>Infecção: 19,6%|Sem diferenças entre os<br>grupos, porém os resultados<br>não são relatados de acordo<br>com o grupo. Apenas se relata<br>que 109 eventos em 56/91<br>pacientes ocorreram<br>Infecção: 31,1%|p=0,57<br>p>0,05|  
NA: não se aplica; EAV: escala analógica visual. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
44  
A qualidade da evidência é baixa, o único estudo comparativo não evidenciou diferenças em relação à apresentação convencional de TAC e seu custo é muito superior ao TAC de apresentação convencional.  Por outro lado, não seria esperado diferenças em eficácia, uma vez que se trata do mesmo princípio ativo, e o desfecho mais importante dessa comparação, que seria medidas de adesão ao tratamento por parte da criança e mesmo alguma medida de qualidade de vida em relação a quem tem o desafio de administrar esse medicamento nessa população, não foram estudados. Do ponto de vista de experiência dos especialistas, essa evidência existe, e aumenta de forma significante a adesão, por ser administrado uma única vez ao dia. Uma vez que é sabido que essa tecnologia será apreciada pela CONITEC, será aguardada a decisão da mesma para se finalizar a recomendação em relação ao TAC de liberação prolongada.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
(((((((("Child"[Mesh] OR "Adolescent"[Mesh] OR "Pediatrics"[Mesh] OR children OR teenager* OR youth* OR pediatric*) AND ("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting*)))) AND ("Sirolimus"[Mesh] OR sirolimus)))  
Total: 135 referências  
Data de acesso: 15/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
'liver transplantation'/exp OR 'liver transplantation' AND ('pediatrics'/exp OR 'pediatrics') AND [embase]/lim AND ('rapamycin'/exp OR 'rapamycin' AND [embase]/lim OR ('sirolimus'/exp OR 'sirolimus' AND [embase]/lim))  
Total: 127 referências  
Data de acesso: 16/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A busca nas bases de dados resultou em 262 referências (135 no MEDLINE e 127 no EMBASE). Após remoção de 16 duplicadas, 246 referências foram triadas pela leitura de título e resumo. Quatro publicações tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destas, três foram excluídas. Um estudo conduzido em população adulta foi excluído por avaliar a imunossupressão com sirolimo em pacientes que sofreram transplante hepático devido à carcinoma hepatocelular. Dois estudos, conduzidos em população pediátrica, foram excluídos por avaliarem a imunossupressão com sirolimo em substituição ao tacrolimo, sem a condição concomitante de presença de tumor.  
Ao final, apenas uma série de casos conduzida em população pediátrica foi considerada elegível para responder à questão de pesquisa<sup>(44)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A descrição sumária do estudo encontra-se na **Tabela 14** . A **Tabela 15** apresenta as características dos participantes no  
estudo e os desfechos relacionados à imunossupressão reportados.  
45  
**Tabela 14 –** Descrição do estudo avaliando a eficácia e segurança do sirolimo na fase de manutenção da imunossupressão em crianças com transplante hepático e tumor  
|**Autor, ano**|**Desenho de estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Tempo de seguimento**|**Perda de seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|Jimenez-Rivera et<br>al. 2004<sup>(44)</sup>|Estudo observacional<br>(série de casos<br>retrospectiva)|Avaliar o efeito do sirolimo no curso clínico<br>dos pacientes pediátricos que receberam<br>transplante hepático e desenvolveram doença<br>linfoproliferativa pós-transplante (n=6) ou<br>hepatoblastoma (n=2)|Sirolimo 0,10-0,14<br>mg/kg/dia|Toda a coorte: 17 meses (5-<br>23)|NR|Alto<br>Natureza retrospectiva,<br>desfechos quantitativos<br>não reportados|  
NR: Não reportado.  
**Tabela 4 –** Características dos pacientes incluídos no estudo avaliando a eficácia e segurança do sirolimo na fase de manutenção da imunossupressão em crianças com transplante hepático e tumor  
|**Autor, ano**|**N intervenção**|**Idade, anos**|**Sexo**|**Tempo entre tx e a**<br>**intervenção**|**Desfechos de Eficácia Intervenção**|**Desfechos de Segurança Intervenção**|
|---|---|---|---|---|---|---|
|Jimenez-Rivera<br>et al. 2004<sup>(44)</sup>|2|Paciente 1: 12 anos<br>Paciente 2: 5,5 anos|NR|Paciente 1: 0,1 ano<br>Paciente 2: 0,5 ano|Não reportado de acordo com o caso. Apenas é<br>informado na discussão que os pacientes com<br>hepatoblastoma estavam livres da doença e<br>permaneciam em uso de monoterapia com sirolimo ao<br>final do estudo|Anormalidades bioquímicas/hematológicas:<br>Paciente 1: hiperlipidemia e leucopenia<br>Paciente 2: hiperlipidemia<br>Achados clínicos:<br>Paciente 1: nenhum<br>Paciente 2: úlceras bucais<br>O gerenciamento dos achados foi feito mediante redução a dose<br>de sirolimo, em ambos os casos|  
N: número de pacientes no grupo; NR: não reportado.  
46  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e  
no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“Nos casos de alergia grave (anafilaxia) e neoplasias, recomenda-se a suspensão total do tacrolimo. Nos casos de disfunção renal grave ou doença linfoproliferativa, sugere-se diminuir a dose ou suspender o tacrolimo. Nessas situações, recomenda-se a substituição do tacrolimo por sirolimo ou everolimo<sup>(40)</sup> . Sirolimo pode ser usado em combinação com corticosteroide, micofenolato, dose baixa de inibidores da calcineurina ou como agente único. Recomenda-se cautela com o uso combinado de tacrolimo e sirolimo uma vez que, embora não reportado em população pediátrica, há evidências que demonstram um aumento na incidência de trombose da artéria hepática em população adulta com o uso dessa associação. O sirolimo pode ser utilizado em pacientes com rejeição crônica, toxicidade aos inibidores da calcineurina tais como disfunção renal, microangiopatia trombótica e doença linfoproliferativa póstransplante. Devido ao seu efeito anti-neoplásico, o sirolimo tem sido utilizado em transplante hepático associado a hepatoblastoma, angiosarcoma e outros<sup>(40)</sup> . As evidências provenientes de literatura publicada são de baixa qualidade, sendo que a maioria é representada por séries de casos e realizada na população adulta (especialmente no caso do everolimo) e não permitem embasar a recomendação, apesar de ser a conduta já adotada na prática clínica. No entanto há estudos de efetividade<sup>(41-45)</sup> e custo-efetividade (em pacientes transplantados renais)<sup>(46, 47)</sup> , conduzidos no âmbito nacional em população adulta, que embasam indiretamente a utilização desses fármacos na população pediátrica. Com base nas evidências científicas disponíveis, não é possível recomendar o sirolimo em detrimento ao everolimo e vice-versa. A decisão acerca de qual terapia administrar fica condicionada ao critério do prescritor e disponibilidade do serviço.”

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
((("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting*)) AND ("Everolimus"[Mesh] OR everolimus)) AND ("Child"[Mesh] OR "Adolescent"[Mesh] OR "Pediatrics"[Mesh] OR children OR teenager* OR youth* OR pediatric*)  
Total: 26 referências  
Data de acesso: 30/07/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
(('liver transplantation'/exp OR 'liver transplantation') AND [embase]/lim) AND (('pediatrics'/exp OR 'pediatrics') AND [embase]/lim) AND (('everolimus'/exp OR 'everolimus') AND [embase]/lim)  
Total: 25 referências  
Data de acesso: 03/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A busca nas bases de dados resultou em 51 referências (26 no MEDLINE e 25 no EMBASE). Destas, cinco estavam duplicadas e 46 referências foram triadas pela leitura de título e resumo. Onze citações tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Nenhum estudo preencheu diretamente os critérios para responder à questão de pesquisa. Desta forma, foram selecionadas evidências INDIRETAS para responder à questão sendo: três estudos<sup>(41, 43, 83)</sup> avaliando a intervenção de interesse no pós-transplante hepático de pacientes ADULTOS com tumor ou alergia e um estudo avaliando a intervenção de interesse como  
47  
terapia de resgate no pós-transplante hepático de pacientes pediátricos, porém, apenas pequena proporção com apresentou hepatoblastoma<sup>(45)</sup> .  
- **3) Descrição dos estudos e seus resultados**  
A descrição sumária dos estudos encontra-se na **Tabela 16** . A **Tabela 17** apresenta as características dos participantes nos  
estudos. A **Tabela 18** apresenta os desfechos clínicos reportados nos estudos.  
48  
**Tabela 16 –** Descrição dos estudos avaliando a eficácia e segurança do everolimo na fase de manutenção da imunossupressão em pacientes pós-transplante hepático, com tumor ou alergia  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**Detalhes da Intervenção**||**Detalhes do controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|Bilbao et al.<br>2015<sup>(41)</sup>|Estudo<br>observacional,<br>retrospectivo,<br>multicêntrico (20<br>centros)|Avaliar indicações, eficácia,<br>segurança da administração de<br>everolimo (monoterapia ou<br>combinação) em pacientes<br>adultos pós-transplante hepático|Doses de everolimo:*<br>dia 1: 1,5 (0,9) mg/dia<br>1 mês: 1,7 (1,0) mg/dia<br>3 meses: 1,8 (1,2) mg/dia<br>6 meses: 1,7 (1,1) mg/dia<br>12 meses: 1,7 (1,0) mg/dia<br>Monoterapia:<br>dia 1: 45/481 (9,4)<br>1 mês: 73/456 (16)<br>3 meses: 104/446 (23,3)<br>6 meses: 110/416 (26,4)<br>12 meses: 112/390 (28,7)<br>Dupla terapia:<br>dia 1: 221/481 (45,9)<br>1 mês: 200/456 (43,9)<br>3 meses: 203/446 (44,6)<br>6 meses: 216/416 (50,7)<br>12 meses: 199/390(51)|Terapia tripla:<br>dia 1: 172/481 (35,8)<br>1 mês: 140/456 (30,7)<br>3 meses: 110/446 (24,7)<br>6 meses: 65/416 (15,6)<br>12 meses: 42/390 (10,8)<br>Terapia Quádrupla:<br>dia 1: 25/481 (5,2)<br>1 mês: 18/456 (3,9)<br>3 meses: 10/446 (2,2)<br>6 meses: 3/416 (0,7)<br>12 meses: 1/390 (0,3)|NA|Coorte carcinoma<br>hepatocelular: 7,1<br>meses<br>(IIQ, 1,2-20,4)<br>Outros tumores: 68,7<br>meses (IIQ, 36-118,8)|Alto. Sem ajuste de análises,<br>natureza retrospectiva do estudo,<br>perdas significantes ao longo do<br>seguimento|
|Gomez-<br>Camarero et al.<br>2007<sup>(83)</sup>|Estudo observacional<br>com controle<br>histórico (oriundo do<br>mesmo centro)|Avaliar sobrevida e segurança<br>do everolimo em pacientes<br>adultos com neoplasia pós-<br>transplante hepático|Everolimo em doses variando<br>dose de ataque na conversão.<br>entre 3–8 ng/mL|entre 0,5 e 1,5, 2x/dia, sem<br>Alvo terapêutico sérico|Tratamento padrão antes do<br>uso de everolimo<br>(quimioterapia,<br>cirurgia/radioterapia, redução<br>da imunossupressão ou não<br>tratamento)|12,7 (5,5–27,5) meses<br>no grupo intervenção.<br>Mediana de<br>seguimento no grupo<br>controle não<br>reportado|Alto: grupo controle histórico,<br>não recebendo cuidados e co-<br>intervenções comparáveis e<br>análises não ajustadas para essas<br>variáveis|
|Herden et al.<br>2016<sup>(43)</sup>|Estudo<br>observacional, série<br>de casos<br>retrospectiva|Avaliar desfechos de longo<br>prazo em pacientes adultos pós-<br>transplante hepático de novo,<br>em combinação com baixas<br>doses de IC|Everolimo no dia 1 pos-opera<br>alcançar a concentração de 6<br>50-80 ng/mL ou tacrolimo 3-5<br>Basiliximabe foi administrado<br>médica.|tório, com o objetivo de<br>ng/mL + IC (Ciclosporina<br>ng/mL) e prednisolona.<br>de acordo com a decisão|NA|4,6 anos (1,2-6,3)|Alto. Sem ajuste de análises,<br>natureza retrospectiva do estudo,<br>a maioria dos desfechos<br>relatados foi apresentada para a<br>coorte inteira e não de acordo<br>com a indicação do everolimo.<br>Desta forma, não foi possível<br>relatá-los na condição de tumor<br>concomitante|  
49  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**Detalhes da Intervenção**|**Detalhes do controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|Nielsen et al.<br>2011<sup>(45)</sup>|Estudo<br>observacional, série<br>de casos prospectiva|Avaliar o efeito do everolimo<br>em população pediátrica por<br>diferentes indicações (2 por<br>hepatoblastoma) na terapia de<br>resgate após falha do esquema<br>padrão de imunosspressão pós-<br>transplante hepático|Everolimo dose inicial de 0,4 mg/m2, 2x/dia|NA|Toda coorte: 13<br>meses (4,0-24,0)<br>Casos com tumor: NR<br>(16-20)|Alto. Sem ajuste de análises,<br>relato de casos, com tempo de<br>seguimento insuficiente para<br>avaliar o desfecho de interesse<br>(metástase)|  
NA: não se aplica; IIQ: intervalo interquartil; IC: inibidores de calcineurina. Quando não especificado, dados apresentados como mediana (mínimo-máximo).  
*Doses de everolimo: média de dose em cada período de avaliação (desvio padrão)  
**n/N (%) de pacientes em cada período de avaliação  
50  
**Tabela 17 –** Características dos pacientes incluídos nos estudos avaliando a eficácia e segurança do everolimo na fase de manutenção da imunossupressão em pacientes pós-transplante hepático, com tumor ou alergia.  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade (anos)**<br>**Intervenção**|**Idade (anos)**<br>**Controle**|**% Homens**<br>**Intervenção**|**% Homens**<br>**Controle**|**Tempo entre tx e**<br>**tratamento**<br>**Intervenção**|**Tempo entre tx**<br>**e tratamento**<br>**Controle**|**Perdas de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|---|---|
|Bilbao et al.<br>2015<sup>(41)</sup>|Total 486. Analisados: 477. Destes, em<br>30,1% (145/481 pacientes) a indicação foi<br>por tumor no fígado, sendo em 20,8 para<br>profilaxia e 7,9 por recorrência do tumor.<br>Adicionalmente, em 29,7% (143/481<br>participantes) a indicação da conversão para<br>everolimo foi por causa de recorrência de<br>outros tumores não hepáticos|NA|56,5<br>(IIQ 12–72)|NA|376/477 (78,8)|A|Coorte com CHC:<br>7,1 meses<br>(1,2–20,4)<br>Outros tumores:<br>68,7 meses<br>(36–118,8)|NA|9/486 (1,85)|
|Gomez-<br>Camarero et<br>al. 2007<sup>(83)</sup>|10 pacientes tratados na instituição a partir<br>de 2004|14 controles pareados por tipo<br>de tumor (histologia e<br>estadiamento), que não<br>receberam everolimo, tratados<br>na instituição entre 1991 e 2002|Mediana 54 (35–<br>64)|Mediana 60<br>(42–70)|NR|N<br>R|38 meses (2–142)<br>até diagnóstico de<br>novo tumor|NR|NR|
|Herden et al.<br>2016<sup>(43)</sup>|91, sendo que 50 iniciaram everolimo entre<br>os dias 1 e 5 após o transplante e 41 em 5<br>dias pós-transplante. Destes, 29,7% (27<br>pacientes) iniciaram everolimo por causa de<br>recorrência de carcinoma hepatocelular|NA|56 (18-80)|NA|NR|NA|4 dias (1–93)|NA|NR|
|Nielsen et al.<br>2011<sup>(45)</sup>|18 pacientes, sendo que apenas 2 por<br>indicação de hepatoblastoma iniciado 2<br>semanas pós-transplante|NA|Toda coorte: 6,0<br>(0,5-15,6)|NA|NR|NA|NR|NA|NR|  
N: número de amostra; Tx: transplante; NA: não se aplica; IIQ: intervalo interquartil; CHC: carcinoma hepatocelular; NR: não reportado. Quando não especificado, dados foram apresentados como n/N (%) ou mediana (mínimo-máximo).  
51  
**Tabela 18 –** Desfechos de eficácia e segurança do everolimo na fase de manutenção da imunossupressão em pacientes pós-transplante hepático, com tumor ou alergia.  
|**Autor, ano**|**Desfechos de eficácia**<br>**Intervenção**|**Desfechos d**|**e eficácia Controle**|**P para comparação**|**Desfechos de segurança**<br>**Intervenção**|**Desfechos de**<br>**segurança**<br>**Controle**|**p para**<br>**comparação**|
|---|---|---|---|---|---|---|---|
|Bilbao et al.<br>2015<sup>(41)</sup>|Sobrevida em 3 anos após conversão para<br>everolimo:<br>Coorte CHC: 59,5%<br>Outros tumores: 71,1%<br>Mortalidade (toda a coorte): 28,5%<br>Mortalidade por causa de progressão de tumor:<br>14,3%|NA||NA|Rejeição aguda após conversão para everolimo (toda a<br>coorte):<br>Em 3 meses: 8/237 (3,4)<br>Em 6 meses: 7/231 (3,0)<br>Descontinuação do everolimo:<br>Coorte CHC: 29,7%<br>Outros tumores: 26,6%|NA|NA|
|Gomez-<br>Camarero et al.<br>2007<sup>(83)</sup>|Sobrevida: mediana 21,3 (7,5– 40,5) meses<br>Sobrevida: 7/10, sendo 5 em remissão completa e 3<br>com tumor estável<br>Rejeição durante tratamento com everolimo: 0<br>Sobrevida em 12 meses: 72%<br>Sobrevida em 24 meses: 29%|Sobrevida:<br>meses<br>Sobrevida e<br>Sobrevida e|mediana 5,3 (0 –70)<br>m 12 meses: 50%<br>m 24 meses: 14%|HR: 4,6 (IC95% 1,3–<br>16,4); p=0,008|Elevação transitória de aminotransferases/transaminases,<br>com histologia normal: 2/10<br>Deterioração da função renal (em relação ao período<br>pré-everolimo): 1/10<br>Alteração hematológica: 4/10<br>Hiperlipidemia: 2/10<br>Edema bilateral de membros inferiores: 1/10<br>Úlceras orais: 0<br>Deiscencia de ferida operatória: 0<br>Trombose de artéria hepática: 0<br>Infecção: 4/10|NA|NA|
|Herden et al.<br>2016<sup>(43)</sup>|Mortalidade: 4/25 (16%)||NA|NA|NR para estrato de interesse|NA|NA|
|Nielsen et al.<br>2011<sup>(45)</sup>|Ocorrência de metástase: 0/2||NA|NA|NR|NA|NA|  
CHC: carcinoma hepatocelular; NA: não se aplica; NR: não reportado; HR: hazard ratio; IC95%: intervalo de confiança de 95%. Quando não especificado, dados foram apresentados como n/N (%) ou mediana (mínimomáximo).  
52  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“Nos casos de alergia grave (anafilaxia) e neoplasias, recomenda-se a suspensão total do tacrolimo. Nos casos de disfunção renal grave ou doença linfoproliferativa, sugere-se diminuir a dose ou suspender o tacrolimo. Nessas situações, recomenda-se a substituição do tacrolimo por sirolimo ou everolimo<sup>(40)</sup> . Sirolimo pode ser usado em combinação com corticosteroide, micofenolato, dose baixa de inibidores da calcineurina ou como agente único. Recomenda-se cautela com o uso combinado de tacrolimo e sirolimo uma vez que, embora não reportado em população pediátrica, há evidências que demonstram um aumento na incidência de trombose da artéria hepática em população adulta com o uso dessa associação. O sirolimo pode ser utilizado em pacientes com rejeição crônica, toxicidade aos inibidores da calcineurina tais como disfunção renal, microangiopatia trombótica e doença linfoproliferativa póstransplante. Devido ao seu efeito anti-neoplásico, o sirolimo tem sido utilizado em transplante hepático associado a hepatoblastoma, angiosarcoma e outros<sup>(40)</sup> . As evidências provenientes de literatura publicada são de baixa qualidade, sendo que a maioria é representada por séries de casos e realizada na população adulta (especialmente no caso do everolimo) e não permitem embasar a recomendação, apesar de ser a conduta já adotada na prática clínica. No entanto há estudos de efetividade<sup>(41-45)</sup> e custo-efetividade (em pacientes transplantados renais)<sup>(46, 47)</sup> , conduzidos no âmbito nacional em população adulta, que embasam indiretamente a utilização desses fármacos na população pediátrica. Com base nas evidências científicas disponíveis, não é possível recomendar o sirolimo em detrimento ao everolimo e vice-versa. A decisão acerca de qual terapia administrar fica condicionada ao critério do prescritor e disponibilidade do serviço”.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
(((((("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting* OR hepatic grafting)) AND (((basiliximab OR "basiliximab" [Supplementary Concept])) OR (("thymoglobulin" [Supplementary Concept] OR thymoglobulin OR anti-thymocyte globulin OR antithymocyte globulin OR rabbit antithymocyte globulin))))) NOT ("allogeneic hematopoietic stem cell transplantation" OR "allogeneic hematopoietic cell transplantation" OR "hematopoietic cell transplantation" OR "stem cell transplantation" OR  
"kidney transplantation" OR "renal transplantation" OR "intestinal transplantation" OR "bowel transplantation"))) AND (((randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR clinical trials as topic[mesh:noexp] OR randomly[tiab] OR trial[ti] NOT (animals[mh] NOT humans [mh]))) AND Humans[Mesh])  
Total: 85 referências  
Data de acesso: 23/11/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
(((((('thymocyte antibody'/exp OR 'thymocyte antibody') AND [embase]/lim OR 'thymoglobulin'/exp OR 'thymoglobulin' OR 'thymoglobuline'/exp OR 'thymoglobuline' OR 'antithymocyte globlulin' OR 'rabbit antithymocyte globulin'/exp OR 'rabbit antithymocyte globulin') AND [embase]/lim) OR (('basiliximab'/exp OR 'basiliximab') AND [embase]/lim)) AND (('liver transplantation'/exp OR 'liver transplantation' OR 'liver grafting' OR 'hepatic grafting') AND [embase]/lim)) NOT (('allogeneic hematopoietic stem cell transplantation'/exp OR 'allogeneic hematopoietic stem cell transplantation' OR 'allogeneic hematopoietic cell transplantation'/exp OR 'allogeneic hematopoietic cell transplantation' OR 'hematopoietic cell transplantation'/exp OR 'hematopoietic cell transplantation' OR 'stem cell transplantation'/exp OR 'stem cell transplantation' OR 'kidney transplantation'/exp OR 'kidney transplantation' OR 'renal transplantation'/exp OR 'renal transplantation' OR 'intestinal transplantation' OR 'bowel transplantation') AND [embase]/lim)) AND (('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-  
53  
blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti) AND [embase]/lim)  
Total: 236 referências  
Data de acesso: 23/11/2017  
- **2) Seleção das evidências**  
A busca nas bases de dados resultou em 321 referências (85 no MEDLINE e 236 no EMBASE). Destas, 43 estavam duplicadas e 278 referências foram triadas pela leitura de título e resumo. Duzentas e quarenta e seis referências foram excluídas após a leitura por título e resumo, restando 32 referências para uma análise apurada. Todas essas 32 referências foram excluídas, por analisarem a fase de indução pós-transplante e não a rejeição. Foram incluídos oito estudos<sup>(48-55)</sup> advindos de busca manual, sendo seis acerca da timoglubolina<sup>(48, 50-54)</sup> e dois acerca do basiliximabe<sup>(49, 55)</sup> .  
- **3) Descrição dos estudos e seus resultados**  
A descrição sumária dos estudos avaliando segurança e eficácia da timoglobulina encontra-se na **Tabela 19** . A **Tabela 20** apresenta as características dos participantes e desfechos apresentados nos estudos avaliando a timoglobulina nos casos de rejeição aguda resistente a esteroide. Nas **tabelas 21 e 22** estão as características dos estudos que avaliaram o basiliximabe, bem como seus principais resultados de eficácia e segurança.  
54  
**Tabela 19 –** Descrição dos estudos avaliando a timoglobulina nos casos de resistência à primeira opção de tratamento na rejeição aguda no pós-transplante hepático  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Detalhes da**<br>**Intervenção**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|
|Amir et al. 2016<sup>(48)</sup>|Série de casos<br>retrospectiva|Reportar evolução pós-transplante hepático subsequente à isuficiência<br>hepática aguda decorrente de LHF em pacientes pediátricos. Destes, apenas<br>quatro casos foram tratados com timoglobulina na primeira recorrência de<br>LHF (condizendo com rejeição aguda) após falha da imunossupressão com<br>dexametasona|Timoglobulina após<br>falha da<br>imunossupressão com<br>dexametasona|6 meses pós-<br>transplante|Alto<br>O tratamento com timoglobulina foi utilizado como<br>primeira opção após falha da imunossupressão com<br>dexametasona, implicando em evidência indireta.<br>Ademais, trata-se de pequena série de casos para<br>inferir eficácia|
|Lee et al. 2016<sup>(53)</sup>|Série de casos<br>retrospectiva|Reportar os desfechos clínicos e bioquímicos de resposta a terapia com<br>timoglobulina em grupo de pacientes com rejeição aguda resistente a<br>esteroides|TG 2,5 mg/kg|Relatado: 6 meses<br>após TG|Alto<br>Série de casos retrospectiva.|
|Benjamin et al.<br>2014<sup>(51)</sup>|Série de casos<br>retrospectiva|Comparar os desfechos clínicos e bioquímicos de eficácia do tratamento de<br>rejeição aguda resistente a esteroide nos grupos de pacientes adultos com<br>HCV utilizando OKT3 ou TG|TG 1,5 mg/kg/dia de 7 a<br>14 dias<br>OKT3 5 mg/dia por 10<br>dias|TG: 3,2 anos<br>OKT3: 4,3 anos|Alto<br>Série de casos retrospectiva.|
|Aydogam et al.<br>2010<sup>(50)</sup>|Série de casos<br>retrospectiva|Avaliar os resultados da terapia com TG num grupo de pacientes (doentes<br>adultos e pediátricos) com rejeição aguda resistente a esteroide|TG 5 mg/kg/dia|Média (DP): 38,2<br>(26) meses, pós-TG|Alto<br>Série de casos retrospectiva|
|Schmitt et al. 2010<sup>(54)</sup>|Série de casos<br>retrospectiva|Avaliar resultados de eficácia e segurança da TG no tratamento de rejeição<br>aguda resistente a esteroide em pacientes adultos transplantados de fígado|TG 1,5 mg/kg por 4 dias|Mediana: 65,5 (4,3-<br>101,7) meses|Alto<br>Série de casos retrospectiva|
|Bijleveld et al.<br>1996<sup>(52)</sup>|Série de casos<br>retrospectivo|Avaliar os resultados a longo prazo e a segurança da TG no tratamento de<br>pacientes adultos com rejeição aguda resistente a esteroides.|TG 4 mg/kg, em 5<br>doses, dia sim, dia não.|Mínimo de 6 meses|Alto<br>Série de casos retrospectiva|  
TG: timoglobulina; LHF: linfohistiocitose hemofagocítica; HCV: vírus da hepatite C; OKT3: muromonabe.  
**Tabela 20 –** Características dos pacientes e desfechos apresentados nos estudos avaliando a timoglobulina nos casos de resistência à primeira opção de tratamento na rejeição aguda no pós-transplante hepático  
55  
|**Autor, ano**|**N pacientes**|**Idade, mediana**<br>**(variação)**|**% sexo**<br>**masculino**|**Tempo entre transplan**<br>**rejeição**|**te e**<br>**Desfechos por paciente**|**Valor p**|**Desfechos de segurança**|
|---|---|---|---|---|---|---|---|
|Amir et al.<br>2016<sup>(48)</sup>|4|Mínimo 8 meses, Máximo<br>7 anos e 5 meses|1/4|Mediana 31 dias<br>Mínimo 16 dias<br>Máximo 348 dias|1) TMO, seguido de nova rejeição, sepse e óbito em 8 meses<br>2) Recorrência seguida de sepse e óbito em 1,5 meses<br>3) Recorrência seguida de sepse e óbito em 14 meses<br>4) Vivo em 16 meses|NR|NR|
||||||AST (UI/L)<br>Início: 138 (45–406)<br>1 dia pós-TG: 63 (15–152)<br>1 mês pós-TG: 25<br>ALT (UI/L)<br>Início: 327 (57–486)<br>1 dia pós-TG: 70 (32–233)<br>1 mês pós-TG: 41<br>Cont. linfócitos<br>Início: 390 (210–900)<br>1 dia pós-TG: 190 (40–540)|0,013<br>0,038<br>0,006<br>0,004<br>0,022||
|Lee et al.<br>2016<sup>(53)</sup>|11|52 (9-66)|7 (53,6)|Mínimo: 7 dias<br>Máximo: 446 dias|%CD3<br>Início: 77.3 (47.7–87.2)<br>1 dia após: 7.4 (0.0–93.4)<br>Bilirrubina mediana total (mg/dL)<br>Início: 6,5<br>1 mês pós-TG: 1,8<br>Sobrevida do enxerto<br>SRAR<br>1 ano: 90,9%<br>3 anos: 68,2%<br>SSAR|0,017<br>0,041<br>0,594 p/<br>SRAR vs.|Reativação de HCV: 1<br>Infecção por CMV: 3|
||||||1 ano: 95,7%<br>3 anos: 85,8,2%|SSAR||
||||||ALT (UI/L)<br>TG<br>Início: 262<br>Final trat.: 68|||
|Benjamin et<br>al. 2014<sup>(51)</sup>|32 (17 TG)|Média (DP)<br>TG: 49,1 (2,3)<br>OKT3: 50,1 (7,9)|NR|Média (DP)<br>TG: 46 (403) dias<br>OKT3: 11 (378) dias|OKT3<br>Início: 241<br>Final trat.: 53<br>Bilirrubina média (DP) total (mg/dL)<br>TG<br>Início: 9,6 (5,4)<br>Final trat.: 3,8(3,2)|NS entre<br>grupos|NR|  
56  
|**Autor, ano**|**N pacientes**|**Idade, mediana**<br>**(variação)**|**% sexo**<br>**masculino**|**Tempo entre transplan**<br>**rejeição**|**te e**<br>**Desfechos por paciente**|**Valor p**|**Desfechos de segurança**|
|---|---|---|---|---|---|---|---|
||||||OKT3<br>Início: 7,7 (7,3)<br>Final trat.: 2,0 (1,7)<br>Sobrevida<br>TG<br>1 ano: 82%<br>2 anos: 77%<br>5 anos: 64%<br>OKT3<br>1 ano: 80%<br>2 anos: 73%<br>5 anos: 67%<br>Perda de enxerto<br>TG:4 (23,5%)<br>OKT3: 4(26,8)|||
|Aydogam et<br>al. 2010<sup>(50)</sup>|12 (8 crianças)|<sup>Média (DP)</sup><br>16,08 (12,1)|7 (58,3)|Média (DP)<br>73,58 (59,24) dias|Bilirrubina média (DP) total (mg/dL)<br>Início: 11,99 (9,16)<br>Final trat.: 2,26 (2,18)<br>AST (UI/L), média (DP)<br>Início: 180,50 (120,66)<br>Final trat.: 44,75 (27,49)<br>ALT (UI/L), média (DP)<br>Início: 287,16 (221,39)<br>Final trat.: 56,58(34,18)|NR|Mais comum:<br>Febre: 4 episódios|
|Schmitt et al.<br>2010<sup>(54)</sup>|20|Mediana (variação): 48,3<br>(14,3–71,7)|15 (75)|NR|AST (UI/L), média<br>Início: 172<br>Pós-TG: 34<br>ALT (UI/L), média<br>Início: 350<br>Pós-TG: 50<br>Bilirrubina média total (mg/dL)<br>Início: 9,1<br>Pós-TG: 1,3<br>Sobrevida pós-TG: 85%<br>Recorrência empacientes HCV+: 100%|<0,001<br><0,001<br>0,005|Infecções: 6 episódios|  
57  
|**Autor, ano**|**N pacientes**|**Idade, mediana**<br>**(variação)**|**% sexo**<br>**masculino**|**Tempo entre transplante e**<br>**rejeição**|**Desfechos por paciente**|**Valor p**|**Desfechos de segurança**|
|---|---|---|---|---|---|---|---|
|Bijleveld et<br>al. 1996<sup>(52)</sup>|13 pacientes<br>com SRAR|Mediana (variação): 38<br>(23-58)|3 (23)|Mediana (variação): 48 (11-<br>142) dias|Bilirrubina total mediana (variação) (µmol/L)<br>Início: 228 (70-520)<br>1 ano pós-TG: 18 (8-575)<br>ALT (UI/L), mediana (variação)<br>Início: 625 (256-1260)<br>1 ano pós-TG: 39 (12-915)<br>Sobrevida:<br>Paciente (2 anos): 83%<br>Enxerto (2anos): 75%<br>Risco relativo de rejeição crônica: 21,9 (em relação aos pacientes<br>SSRA)|NR<br>NR<br>NR<br>P<br><0,025|NR|  
TG: timoglobulina; LHF: linfohistiocitose hemofagocítica; HCV: vírus da hepatite C; OKT3: muromonabe; TMO: transplante de medula óssea. SRAR: rejeição aguda resistente a esteroide; SSRA: rejeição aguda sensível a esteroide; AST: aspartato aminotransferase; ALT: alanina aminotransferase; NR: não reportado.  
**Tabela 51 –** Descrição dos estudos avaliando o basiliximabe nos casos de resistência à primeira opção de tratamento na rejeição aguda no pós-transplante hepático  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Tempo de seguimento**|**Risco de viés**|
|---|---|---|---|---|---|
|Shigeta et al. 2014<sup>(55)</sup>|Série de casos<br>prospectiva|Avaliar os desfechos de eficácia e segurança do uso de basiliximabe em uma<br>população pediátrica com rejeição aguda resistente a esteroide e falha<br>hepática aguda.|BASI 10 mg 2x dia, nos dias 0 e 4|Variando de 2 a 51 meses|Alto<br>Série de casos|
|Aw et al. 2003<sup>(49)</sup>|Série de casos<br>prospectiva|Avaliar os desfechos de eficácia do basiliximabe como terapia de resgate para<br>rejeição aguda esteroide-resistente em crianças que fizeram transplante<br>hepático|BASI 10 mg p/ crianças < 30 kg; e<br>BASI 20 mg p/ crianças ≥ 30 kg|Mediana (variação): 22 (5-32)<br>meses|Alto<br>Série de casos|  
BASI: basiliximabe.  
58  
**Tabela 22 –** Características dos pacientes e desfechos apresentados nos estudos que avaliam a timoglobulina nos casos de resistência à primeira opção de tratamento na rejeição aguda no pós-transplante hepático  
|**Autor, ano**|**N pacientes**|**Idade, mediana**<br>**(variação)**|**% sexo**<br>**masculino**|**Tempo entre**<br>**transplante e**<br>**rejeição**|**Desfechos por paciente**|**Valor p**|**Desfechos de segurança**|
|---|---|---|---|---|---|---|---|
|Shigeta et al.<br>2014<sup>(55)</sup>|7|10 (6-12) meses|5 (71,4)|NR|Sobrevida: 100% (avaliada após 31,5 dias – tempo<br>mediano de alta hospitalar.<br>Aparentemente os valores de AST, ALT e bilirrubina<br>total de normalizaram, porém não são mostrados dados<br>numéricos.||Infecção por CMV: Até duas semanas após<br>BASI: 6/7|
||||||AST (UI/L), mediana (variação) *|||
||||||Início: 249 (63-768)|0,042||
||||||Pós-BASI: 53 (31-262)|||
|Aw et al. 2003<sup>(49)</sup>|7|22 (7 meses a 12<br>anos) meses|2 (28,6)|Mediana (variação):<br>30 dias (8 dias a 23<br>meses)|3 crianças normalizaram os níveis de AST após BASI<br>Bilirrubina (µmol/L), mediana (variação) *<br>Início: 62 (39-315)||2 (28,6%) CMV positivos|
||||||Pós-BASI: 20 (4-279)|0,128||
||||||5 crianças normalizaram os níveis de AST após BASI|||  
*Valores não informados no estudo e calculados por nós (os testes estatísticos foram calculados por teste de wilcoxon); AST: aspartato aminotransferase; ALT: alanina aminotransferase.  
59  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“Quando a rejeição é corticoresistente recomenda-se a utilização da preparação anti-linfocitárias timoglobulina. Pode-se também associar micofenolato de mofetila/sódico”.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
OBS: com base nas evidências, não foi possível recomendar o uso do basiliximabe na rejeição corticoresistente.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
((((("Sirolimus"[Mesh] OR sirolimus OR Rapamycin)) OR ("Everolimus"[Mesh] OR everolimus))) AND ("Liver Transplantation"[Mesh] OR liver transplantation)) AND (steroid-resistant OR steroid resistant)  
Data de acesso: 01/12/2017  
Total: 20 referências

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
(('rapamycin'/exp OR 'rapamycin' OR 'sirolimus'/exp OR 'sirolimus' OR 'everolimus'/exp OR 'everolimus') AND [embase]/lim) AND (('liver transplantation'/exp OR 'liver transplantation') AND [embase]/lim) AND (('steroid-resistant' OR 'steroid resistant') AND [embase]/lim)  
Data de acesso: 01/12/2017  
Total: 32 referências

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Foram recuperadas ao todo 52 referências, de acordo com as estratégias de busca acima, sendo 20 na MEDLINE e 32 no Embase. Treze referências duplicadas foram retiradas, restando 39 estudos a serem analisados por meio da leitura de títulos e resumos. Nove referências foram selecionadas a partir da leitura de títulos e resumos, das quais sete foram excluídas pelos seguintes motivos: 1) cinco por não avaliarem especificamente a rejeição aguda resistente a esteroide; 2) um por não mostrar resultados específicos de sirolimo e everolimo e 3) um por avaliar paciente com transplante renal/hepático com a presença da rejeição no rim. Dessa forma, dois estudos (56, 57) foram incluídos, os dois analisando sirolimo.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
As **tabelas 23 e 24** exibem, respectivamente, as características dos estudos incluídos e as informações sobre os participantes e desfechos.  
60  
**Tabela 63 –** Principais características dos estudos incluídos  
|Autor, ano|Desenho do estudo|População e objetivo|Detalhes da intervenção|Tempo de seguimento|Risco de viés|
|---|---|---|---|---|---|
|Demirag et al.<br>2009<sup>(56)</sup>|Relato de caso|Um paciente adulto, sexo masculino, com rejeição aguda resistente a<br>esteroides e a Timoglobulina, o qual passou por transplante hepático devido<br>a HCV. Objetivo: tratamento de rejeição aguda em receptores de fígado.|Sirolimo 2 mg/d (manter os<br>níveis séricos entre 12 e 20<br>ng/mL|6 meses|Alto: relato de caso|
|Llado<br>et<br>al.<br>2009<sup>(57)</sup>|Série<br>de<br>casos<br>retrospectiva|Descrever a experiência do uso de SRL para controle de SRAR (5 pacientes)<br>e de rejeição ductopenica (8 pacientes) em pacientes adultos com<br>insuficiência renal e que realizaram transplante hepático|Sirolimo 0,05-0,08 mg/kg (dose<br>média de 3,8 mg/d)|Mediana de 6 meses|Alto: relato de caso|  
SRL: sirolimo; SRAR: rejeição aguda resistente a esteroides; HCV: vírus da hepatite C.  
**Tabela 74 –** Principais desfechos de eficácia e segurança mostrados pelos estudos incluídos  
|**Autor, ano**|**N**|**Idade**|**Sexo masc., n (%)**|**Desfechos por paciente**|**Valor p**|**Desfechos de segurança**|
|---|---|---|---|---|---|---|
|||||Biblirrubina total (mg/dL):<br>Início: 13<br>14 dias pós-SRL: 2|||
|Demirag et al.<br>2009<sup>(56)</sup>|1|26|1 (100)|AST (UI/L):<br>Início: 18<br>14 dias pós-SRL: 39|NR|Nenhum efeito adverso significante<br>por mais de seis meses após SRL|
|||||ALT (UI/L):|||
|||||Início: 15|||
|||||14 dias pós-SRL: 60|||
|||||Completa resolução da rejeição: 6/13 (46,2%)|||
|ld  l||Média||Valores séricos pré-conversão ao SRL (respondentes vs. Não respondentes)<br>ilibi l di  21 25  554 15||77% sofreram algum evento adverso:|
|Lao et a.<br>2009<sup>(57)</sup>|13|(DP): 55<br>(13)|9 (69,2)|Brruna, µmo/L, méa (DP): 0 (0) vs.  (9)<br>Clearance creatinina, mL/min, média (DP): 37 (11) vs. 25 (11)<br>Valores séricos pós-conversão ao SRL (respondentes vs. Não respondentes)|0,07<br>0,09|8 (61,5%) anemia; 4 (30,8%)<br>infecção.|
|||||Clearance creatinina, mL/min, média (DP): 11 (1,8) vs. 7,5 (3,3)|0,03||  
SRL: sirolimo; AST: aspartato aminotransferase; ALT: alanina aminotransferase; DP: Desvio padrão; NR: Não relatado.  
61  
Com base nas evidências, não foi possível recomendar o uso dos mTOR sirolimo e everolimo no tratamento de rejeição aguda resistente a terapia com esteroides em crianças que realizaram transplante hepático  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“Quando a rejeição é corticoresistente recomenda-se a utilização da preparação anti-linfocitárias timoglobulina  Pode-se também associar micofenolato de mofetila/sódico”.

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
((((((("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting* OR hepatic grafting))) AND ("Graft Rejection"[Mesh] OR chronic transplant rejection OR Graft Rejection* OR Transplant Rejection OR Transplantation Rejections))) AND ("Child"[Mesh] OR "Adolescent"[Mesh] OR "Pediatrics"[Mesh] OR children OR teen* OR youth* OR pediatric*))) AND ("Drug Therapy"[Mesh] OR Pharmacotherapy OR Pharmacotherapies OR pharmacological treatment)  
Total: 625  
Data de acesso: 15/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
'liver transplantation'/exp OR 'liver transplantation' AND ('graft rejection'/exp OR 'graft rejection') AND ('pediatrics'/exp OR 'pediatrics') AND ('drug therapy'/exp OR 'drug therapy') AND [embase]/lim  
Total: 515  
Data de acesso: 16/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A busca nas bases de dados resultou em 1140 referências (625 no MEDLINE e 515 no EMBASE). Após remoção das 56 duplicadas, 1.084 referências foram triadas pela leitura de título e resumo. Vinte e quatro referências foram avaliadas na íntegra, sendo 18 excluídas nessa etapa, principalmente por não avaliar a condição de rejeição crônica, ou incluírem população adulta. Foram incluídas seis publicações referentes a cinco estudos que apresentaram intervenções farmacológicas para rejeição crônica em pacientes pediátricos pós-transplante hepático<sup>(58-63)</sup> , um deles avaliando população com rejeição crônica e mista<sup>(63)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A **Tabela 25** descreve a população e estudos apresentando opções de tratamento medicamentoso na rejeição crônica. A  
**Tabela 26** apresenta os tratamentos e desfechos na rejeição crônica em pacientes pós-transplante hepático.  
62  
**Tabela 25 –** Descrição da população e estudos apresentando opções de tratamento medicamentoso na rejeição crônica  
|**Autor, ano**|**Desenho de estudo**|**População e objetivo do estudo**|**N**|**Idade**|**% sexo**<br>**masculino**|**Tipo de tx**|**Tempo até**<br>**rejeição**|**Tempo de seguimento**|**Perda de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|---|
|||Avaliar eficácia e segurança da conversão||1) 8 anos<br>2) 15 anos|||1) 16 meses<br>2) 32 meses||||
|Egawa et al.<br>1994<sup>(58)</sup>|Estudo observacional<br>(Série de casos<br>prospectiva)|para TAC após falha da imunosupressão<br>(total de 31 pacientes, sendo 8 pacientes por<br>rejeição crônica) com ciclosporina em<br>pacientes pediátricos pós-transplante|8|3) 3 meses<br>4) 4 anos<br>5) 2 anos<br>6) 13 meses|NR|NR|3) 44 dias<br>4) 12 meses<br>5) 12 meses<br>6) 1 mês|Média 10 meses<br>(2-25)|0|Alto<br>Série de casos para avaliar<br>eficácia|
|||hepático||7) 13 anos<br>8) 6 meses|||7) 34 meses<br>8) 18 dias||||
|Jain et al.<br>2003<sup>(59, 60)</sup>|Estudo observacional<br>prospectivo|Examinar a incidência de rejeição crónica<br>comprovada por biópsia no tx hepático<br>primário em população pediátrica em com<br>TAC|166|5,9 (2,9)|95/166<br>(57)|DDoador<br>cadavérico:<br>100%|NR|9,0 anos (7,4–10,4)|NR|Moderado<br>Não foram realizadas<br>comparações por tipo de<br>tratamento. Estudo<br>descritivo|
|McDiarmid et<br>al. 1993<sup>(61)</sup>|Estudo observacional<br>(série de casos<br>prospectiva),<br>multicêntrico|Avaliar o efeito da conversão da<br>imunossupressão para TAC em população<br>adulta e pediátrica com rejeição aguda ou<br>crônica (Apenas os dados referentes à<br>rejeição crônica serão relatados)|12, sendo 8<br>adultos e 4<br>crianças|Adultos:<br>43,6 (3,8)<br>Crianças:<br>5,5 (1,0)|NR|R|522 dias (528)|181 dias<br>(77)|NR|Alto<br>Não há descrição de<br>variáveis de base dos<br>participante. As análises<br>não foram ajustadas. Os<br>dados não foram<br>estratificados entre<br>população adulta e<br>pediátrica|  
63  
|**Autor, ano**|**Desenho de estudo**|**População e objetivo do estudo**|**N**|**Idade**|**% sexo**<br>**masculino**|**Tipo de tx**|**Tempo até**<br>**rejeição**|**Tempo de seguimento**|**Perda de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|---|
|||Avaliar a evolução clínica, características e|||||||||
|Riva et al.<br>2006<sup>(62)</sup>|Estudo observacional<br>(Série de casos<br>retrospectiva)|resposta ao tratamento de pacientes<br>pediátricos pós-transplante ortotópico que<br>evoluem com rejeição crônica (n=13) ou<br>hepatite autoimune (n=9)|13|NR|NR|Ortotópico|45,7 meses (39,3)|NR|0|Alto<br>Série de casos para avaliar<br>eficácia|
|||||||||||Alto: Não há descrição de<br>variáveis de base dos|
||||19, sendo 7|||||||participantes. As análises|
|Winkler et al.<br>1993<sup>(63)</sup>|Estudo observacional<br>(não é possível<br>determinar se<br>prospectivo ou<br>retrospectivo)|Avaliar o efeito da conversão de tratamento<br>de ciclosporina para TAC em população<br>adulta e pediátrica com rejeição aguda ou<br>crônica (Apenas os dados referentes à<br>rejeição crônica serão relatados)|com rejeição<br>mista (aguda e<br>crônica) e 12<br>em rejeição<br>crônica<br>avançada|Crianças <16<br>anos (NR)<br>Adultos: NR<br>(17-66)|NR|NR|NR|9 meses<br>(0,2-30)|NR|não foram ajustadas. Não<br>é possível determinar se<br>coleta de dados foi<br>prospectiva ou<br>retrospectivo. Os dados<br>não foram estratificados<br>entre população adulta e<br>pediátrica|  
N: número de pacientes; TAC: tacrolimo; NR: não reportado; tx: transplante. Quando não especificado dados foram apresentados como média (desvio padrão) ou mediana (mínimo-máximo) ou n/N(%).  
64  
**Tabela 26 –** Descrição dos tratamentos e desfechos na rejeição crônica  
|**Autor ano**|**Tratamento prévio á rejeição**|**Detalhes da Intervenção para rejeição**|**Desfechos de Eficácia Intervenção**|**Desfechos de Segurança Intervenção**|
|---|---|---|---|---|
|**,**||**crônica**|||
|Egawa et al.<br>1994<sup>(58)</sup>|CsA + predinisona|TAC IV 0,025 mg/kg/12h ou VO 0,15<br>mg/kg/12h, dose ajustada de acordo com<br>resposta clínica, toxicidade e níveis<br>plasmáticos entre 0,2 a 2 ng/mL|1) Vivo; com normalização da função hepática<br>2) Vivo após retransplante; com alteração da função<br>hepática<br>3) Óbito (arritmia)<br>4) Óbito (re-tx)<br>5) Vivo; com normalização da função hepática<br>6) Óbito (asfixia)|NR|
||||7) Vivo; com melhora parcial da função hepática||
||||8) Vivo; com melhora parcial da função hepática||
||13/141(9%) dos pacientes sem imunossupressão;||||
||97/141 (70%) em monoterapia com TAC;|Apenas 3 pacientes apresentaram rejeição|||
||25/141 (18%) em terapia dupla;|crônica:|||
|Jain et al.|6/141 (4%) em terapia tripla.|1) redução de dose de TAC em 50% por 10|Incidência de rejeição crônica comprovada por biópsia:|NR|
|2003<sup>(59, 60)</sup>|TAC (n=97): 3,5 (3,1) mg/dia|meses;|4/166 (2,4)||
||Prednisona (n =30): 6,0 (4,3) mg/dia|2) descontinuação de TAC por 11 meses;|||
||Azatioprina (n=4): 40 (28) mg/dia|3) descontinuação de TAC por 2 meses|||
||Micofenolato de mofetila (n=5), 400 (417) mg/dia||||
|||Após 24h da descontinuação do agente||Nefrotoxicidade:|
|||imunossupressor prévio, duas doses de TAC||Redução de pelo menos 50% na TFG:|
|||(0,075 mg/kg) IV em 12h. 12h após TAC VO||6/10 (60)|
|||(0,15 mg/kg) a cada 12h + prednisona (15-20|Sobrevida do enxerto: 50%|Diálise: 2/27 (7,4)|
|McDiarmid|CsA, altas doses de esteroides ou qualquer outro|mg/dia em adultos e 0,3 mg/kg/dia em|Sobrevida global: 66,7%|Hipertensão: 1/27 (3,7)|
|et al. 1993<sup>(61)</sup>|agente imunossupressor|crianças).|Mortalidade: 4/12 (33)|Neurotoxicidades:|
|||Após ocorrência de neuro e nefrotoxicidade, o|Ausência de resposta: 2/12 (16,6)|Insônia: 4/27 (14,8)|
|||protocolo foi alterado para: doses orais||Cefaleia: 6/27 (22)|
|||iniciais entre 0,05 mg/kg a 0,15 mg/kg em 12<br>h.||Outras:<br>Anorexia: 6/27 (22)|  
65  
|**Autor, ano**|**Trata**|**mento prévio á rejeição**|**Detalhes da Intervenção para rejeição**<br>**crônica**|**Desfechos de Eficácia Intervenção**|**Desfechos de Segurança Intervenção**|
|---|---|---|---|---|---|
||||Os pacientes que necessitaram de TAC IV<br>receberam apenas 0,025mg/kg por 12 h como<br>infusão contínua||Mialgia: 3/27 (11)<br>Malignidade: 1/27 (3,7)<br>Infecção hepatite B: 1/27 (3,7)|
||||Aumento de dose de CNI (n=8)|Normalização da função hepática em mediana 7,3 meses||
|Riva et al.<br>2006<sup>(62)</sup>|CsA (n=11)<br>TAC (n=2)||Troca de CsA para TAC (n=7)<br>Introdução de esteroide/azatioprina (n=3)|(mínimo 0,7; máx 27,6): 9/13<br>Melhora da função hepática: 4/13|NR|
||||CNI + esteroide/azatioprina (n=5)|Rejeição ductopênica crônica: 2/13||
||||Adultos: dose inicial IV de 0,10 mg/kg de no|Resposta completa (normalização da função hepática):<br>Rejeição mista: 3/7 (43)<br>Rejeição crônica: 4/12 (33)<br>Resposta parcial (redução dos níveis de||
||||1° dia, seguida de uma dose oral de 0,20<br>mg/kg/dia.|aminotransferases/transaminases e manutenção de<br>bilirrubina):||
||||Crianças: doses iniciais entre 0,075 e 0,15|Rejeição mista: 1/7 (14,3)|Toda a coorte (n=37)|
|Winkler et|||mg/kg/dia IV administrado como infusão|Rejeição crônica: 2/12(16,6)|Tremor: 70%|
|<br>l 1993<sup>(63)</sup>||CsA|contínua ao longo de 24h, seguido de dose|Ausência de resposta:|Nefrotoxicidade: 60%|
|a.|||oral de 0,15-0,30 mg/kg/dia (2x/dia).|Rejeição mista: 3/7 (42,9)|Hipertensão: 23,3%|
||||Em 17 dos 19 pacientes com rejeição crônica,|Rejeição crônica: 6/12(50)|DM: 20,0%|
||||esteroides foram administrados antes do|Sobrevida global:||
||||tratamento com TAC; 2 pacientes também|Rejeição mista: 71,4%||
||||receberam 7 dias de OKT3.|Rejeição crônica:66,6%<br>Sobrevida do enxerto:||
|||||Rejeição mista: 71,4%||
|||||Rejeição crônica: 25%||  
66  
CsA: ciclosporina; TAC: tacrolimo; IV: intravenoso; VO: via oral; tx: transplante; NR: não reportado; TFG: taxa de filtração glomerular; CNI: inibidor de calcineurina; DM: diabetes mellitus. Quando não especificado dados foram apresentados como média (desvio padrão) ou mediana (mínimo-máximo) ou n/N(%).  
67  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e  
no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“As opções terapêuticas para o tratamento da rejeição crônica consistem em utilizar níveis séricos maiores de imunossupressores (em geral tacrolimo), conversão para diferentes imunossupressores (de ciclosporina para tacrolimo)  ou adição de outros imunossupressores (micofenolato)”

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
“Os pacientes pediátricos respondem relativamente bem ao aumento das doses dos imunossupressores, ou adição de outros imunossupressores (micofenolato). A falta de resposta indica a necessidade de retransplante. Não foram identificados estudos para o tratamento para a rejeição crônica. A literatura apresentada para a questão (ANEXO) refere-se à prática clínica anterior, quando a ciclosporina era utilizada como primeira linha de tratamento.”

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
((("Liver Transplantation"[Mesh] OR Hepatic Transplantation OR Liver Grafting* OR hepatic grafting)) AND (("Immunosuppression"[Mesh] OR Immunosuppression* OR Anti-Rejection Therap* OR Antirejection Therap* OR immunosuppressive drugs))) AND ("Drug Interactions"[Mesh] OR Drug Interaction)  
Total: 337 referências  
Data de acesso: 15/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
'liver transplantation'/exp OR 'liver transplantation' AND ('immunosuppressive treatment'/exp OR 'immunosuppressive treatment') AND ('drug interaction'/exp OR 'drug interaction') AND [embase]/lim AND ('anticonvulsive agent'/exp OR 'anticonvulsive agent' AND [embase]/lim OR ('proton pump inhibitor'/exp OR 'proton pump inhibitor' AND [embase]/lim) OR ('antiinfective agent'/exp OR 'antiinfective agent' AND [embase]/lim) OR ('antifungal agent'/exp OR 'antifungal agent' AND [embase]/lim) OR ('analgesic, antiinflammatory, antirheumatic and antigout agents'/exp OR 'analgesic, antiinflammatory, antirheumatic and antigout agents' AND  
[embase]/lim))  
Total: 352 referências  
Data de acesso: 16/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A estratégia de busca resultou em 689 referências (337 no MEDLINE e 352 no EMBASE). Após a remoção de 44 referências duplicadas, 645 citações foram avaliadas por meio da leitura de título e resumo. Sessenta e nove publicações foram avaliadas na íntegra, sendo 62 excluídas nessa etapa, principalmente por não avaliar interações medicamentosas ou por avaliar interações medicamentosas em população adulta pós-transplante hepático. Adicionalmente, foi excluído um estudo avaliando interações em uma  
série de casos que incluiu apenas um caso de paciente pediátrico pós-transplante hepático e não descreveu o esquema de imunossupressão utilizado. Ao final foram incluídos seis estudos avaliando interações medicamentosas em pacientes pediátricos póstransplante hepático<sup>(84-89)</sup> .  
68

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A **Tabela 27** apresenta a descrição sumária dos estudos e interações medicamentosas relatadas entre imunossupressores e anticonvulsivantes, antifúngicos, antibióticos e anti-inflamatórios em pacientes pós-transplante hepático.  
69  
**Tabela 27 –** Estudos reportando interações medicamentosas em pacientes pediátricos pós-transplante hepático  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Interação descrita**|**N**|**Idade**|**Sexo**<br>**masculino**|**Tempo de**<br>**seguimento**|**Achados da interação**|
|---|---|---|---|---|---|---|---|---|
|||Apresentar relato de caso de<br>paciente de 9 anos pós-||||||Paciente apresentou falha em manter níveis<br>terapêuticos com TAC, mesmo com aumentos<br>de doses para até 60mg/dia, associada a piora da|
|Dhawan et al.<br>1997<sup>(84)</sup>|Relato de caso|transplante hepático e re-tx 6<br>meses após, que manteve níveis<br>terapêuticos de TAC as custas da<br>interação com fluconazol|TAC + fluconazol|1|9 anos|100%|12 meses após<br>retransplante|função hepática. Após introdução de fluconazol<br>(100mg/dia), metabolismo de TAC foi inibido e<br>níveis plasmáticos terapêuticos foram atingidos<br>com doses 5mg 2x/dia VO em até 12 meses<br>após retransplante|
||||Caso 1: TAC 4 mg 2x/dia +<br>rifampicina 150 mg bid, 15|||||Caso 1: queda significante nas concentrações de|
|Furlan et al.<br>1995<sup>(85)</sup>|Série de casos|Descrever os resultados das<br>interações entre TAC e<br>eritromicina ou rifampicina em<br>pacientes pediátricos pós-<br>transplante hepático que<br>receberam TAC de resgate na<br>rejeição|dias após, para prurido.<br>Caso 2: TAC 1 mg bid +<br>eritromicina 10 meses após,<br>500 mg tid para infecção<br>pulmonar.<br>Caso 3: TAC em terapia<br>convencional + fenobarbital<br>+ eritromicina 500 mg tid<br>por infecção por|13 pacientes<br>monitorados, 3<br>sofreram<br>reações de<br>interação<br>medicamentos<br>a|Caso 1:<br>10 anos<br>Caso 2:<br>3 anos<br>Caso 3:<br>7 anos|2/3 (75%)|Caso 1: NR<br>Caso 2: 2 semanas<br>após início da<br>eritromicina<br>Caso 3: NR|TAC.<br>Caso 2: 5 dias após, a eritromicina foi<br>descontinuada e exames revelaram sinais de<br>toxicidade renal com aumento na azotemia e<br>creatinina plasmática e aumento na<br>concentração plasmática de TAC.<br>Caso 3: aumento da concentração de TAC,<br>insuficiência renal aguda com oligoanuria<br>requerendo terapia com diuréticos.|
||||micobactéria||||||
|||Descrever os resultados<br>farmacocinéticos de 3 condutas|Esquema de<br>imunossupressão: TAC,||||Paciente recebeu<br>|Imediatamento pós administração da<br>rifampicina, a concentração de TAC caiu|
|Hickey et al.<br>2013<sup>(86)</sup>|Relato de caso|diferentes para o tratamento de<br>tuberculose latente em um caso<br>tratado com TAC para<br>imunossupressão pós-transplante<br>renal e hepático|micofenolato de mofetila e<br>metilprednisolona<br>+ rifampicina 10 mg/kg (3<br>meses após início da<br>imunossupressão)|1|14 anos|100%|alta hospitalar 2<br>meses após início<br>da rifampicina para<br>tratamento<br>ambulatorial|drasticamente e as doses foram aumentadas.<br>Após 10 dias de terapia com rifampicina,<br>adicionou-se cetoconazol na tentativa de<br>aumentar os níveis de TAC. O paciente<br>desenvolveu insuficiência renal aguda,|  
70  
|**Autor, ano**|**Desenho de**<br>**estudo**|**População e objetivo do estudo**|**Interação descrita**|**N**|**Idade**|**Sexo**<br>**masculino**|**Tempo de**<br>**seguimento**|**Achados da interação**|
|---|---|---|---|---|---|---|---|---|
||||||||durante mais 2<br>meses|hipercalemia e intervalo QT prolongado. A<br>rifampicina foi substituida por rifabutina 5<br>mg/kg.|
|Hurst et al.<br>2015<sup>(87)</sup>|Série de casos|Explorar as relações entre altas<br>concentrações de TAC e<br>covariáveis, incluindo interações<br>medicamentosas, tempo de<br>isquemia fria, duração da<br>cirurgia e complicações antes e<br>imediatamente pós-tx hepático|TAC + nicardipina|4 casos|Caso 1:<br>1,4 anos<br>Caso 2:<br>5,3 anos<br>Caso 3:<br>8,5 anos<br>Caso 4:<br>8,7 anos|3/4 (75%)|Caso 1: 16 dias<br>pós-op<br>Caso 2: 7 dias pós-<br>op|Nicardipina está associada com concentrações<br>supra-terapêuticas de TAC|
|Sheiner et<br>al.1994<sup>(88)</sup>|Série de casos|Descrever os resultados das<br>interações entre TAC e<br>ibuprofeno em 2 pacientes pós-<br>transplante hepático|Caso 1: TAC de resgate<br>6mg/2x dia e consumiu 4<br>comprimidos de ibuprofeno<br>devido a dor abdominal<br>Caso 2: TAC primário 5 mg<br>bid + 3 comprimidos de 400<br>mg de ibuprofeno para<br>cefaleia|2 casos|Caso 1:<br>18 anos<br>Caso 2:<br>17 anos|0/2 (0)|Caso 1: até alta<br>hospitalar, após 4<br>sessões de<br>hemodiálise<br>Caso 2: 2 semanas|Caso 1: retorno ao hospital por fraqueza,<br>confusão e anúria, internada em UTI, submetida<br>à hemodiálise de emergência. TAC foi<br>interrompido e administrado PGE1<br>Caso 2: Administrado ibuprofeno durante<br>internação hospitalar e em 48h houve aumento<br>significante da creatinina e oligúria|
|Wungwattana<br>e Savic,<br>2017<sup>(89)</sup>|Relato de caso|Apresentar relato de caso de<br>interação de TAC com nafcilina<br>em paciente com fibrose cística<br>pós-transplante hepático|TAC + nafcilina|1|13 anos|100%|Durante primeira<br>internação de 10<br>dias + 5 dias pós-<br>alta. Durante 14<br>dias da segunda<br>internação|Paciente com doses estáveis (1,5mg 2x/dia VO)<br>e níveis terapêuticos (alvo 3-5 ng/mL) de TAC<br>antes de iniciar tratamento com nafcilina. Em<br>duas internações nas quais naficilina foi<br>administrada por piora da função respiratória,<br>níveis de TAC plasmáticos decresceram para<br><2,0ng/mL, mesmo com doses orais mantidas.<br>Níveis de TAC retornaram aos valores normais<br>após suspensão de nafcilina na alta hospitalar.|  
71  
N: número de pacientes; tx: transplante; TAC: tacrolimo; VO: via oral; UTI: unidade de terapia intensiva; PGE1: prostaglandina E1.  
72

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
((("mycophenolate mofetil" [Supplementary Concept] OR mycophenolate OR mycophenolic acid morpholinoethyl ester OR Sodium Mycophenolate)) AND ("Drug Monitoring"[Mesh] OR therapeutic drug monitoring)) AND ("Liver Transplantation"[Mesh] OR liver transplantation)  
Total: 125  
Data: 15/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
'drug monitoring'/exp OR 'drug monitoring' AND ('liver graft'/exp OR 'liver graft' OR 'liver transplantation'/exp OR 'liver transplantation') AND ('mycophenolate mofetil'/exp OR 'mycophenolate mofetil' OR 'mycophenolic acid'/exp OR 'mycophenolic acid') AND [embase]/lim  
Total: 194 referências  
Data: 06/08/2017

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
As estratégias de busca resultaram em 319 referências (125 na MEDLINE e 194 na EMBASE). Após a remoção de trinta e seis referências duplicadas, 286 citações foram avaliadas por título e resumo. Vinte e nove publicações foram avaliadas na íntegra, sendo 22 estudos excluídos por avaliarem a importância da dosagem sérica do micofenolato em população adulta pós-transplante hepático. Ao final, sete publicações referentes a seis estudos foram consideradas elegíveis para responder à questão<sup>(65-71)</sup> , um deles envolvendo população adulta e pediátrica<sup>(71)</sup> .

---

<!-- METADADOS: doenca: Imunossupressão no Transplante Hepático em Pediatria | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A descrição sumária dos estudos avaliando a importância de dosagem sérica de micofenolato no pós-transplante hepático em pacientes pediátricos encontra-se na **Tabela 28** . A **Tabela 29** apresenta as características dos participantes e períodos de determinação da dosagem sérica. A **Tabela 30** apresenta os desfechos farmacocinéticos e variáveis que interferem nos níveis séricos de micofenolato.  
73  
**Tabela 28 –** Descrição dos estudos avaliando a importância de dosagem sérica de micofenolato no pós-transplante hepático de pacientes pediátricos  
|**Autor, ano**|**Desenho de estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Detalhes da cointervenção**|**Método de dosagem do MMF**|
|---|---|---|---|---|---|
|Attard et al. 2008<sup>(65)</sup>|Série de casos<br>prospectiva (estudo de<br>farmacocinética),<br>multicêntrico|Validar uma estratégia de dosagem limitada de MPA em<br>população pediátrica pós-transplante hepático e avaliar a<br>influência do TAC e Ciclosporina no metabolismo do<br>MMF|1° centro (n=20) = 219 mg/dia<br>2° centro (n=21) = 285 mg/dia em pacientes<br>que receberam TAC concomitante e 548<br>mg/dia em pacientes que receberam<br>ciclosporina concomitante|1° centro (n=20) = todos em uso<br>de TAC<br>2° centro (n=21) = 11 em uso de<br>TAC e 10 em uso de CsA|HPLC (cromatografia líquida de alto<br>desempenho)|
|Aw et al. 2003<sup>(66, 67)</sup>|Série de casos<br>prospectiva (estudo de<br>farmacocinética)|Avaliar o tempo para a melhor concentração (ASC) de<br>MPA em pacientes pediátricos estáveis pós-transplante<br>hepático|MMF dose inicial 10 mg/kg/dia 2x/dia,<br>aumentado até máximo de 1 g 2x/dia. Dose<br>foi ajustada de acordo com presença de<br>eventos adversos (leucopenia e diarreia)|TAC (n=2), TAC + prednisolona<br>(n=9), CsA + prednisolona<br>(n=10)|Enzyme-multiplied immunoassay technique<br>(EMIT; Dade<br>Behring; San Jose, CA) no Cobas Mira<br>analyzer (Roche,<br>Nutley, NJ)|
|Barau et al. 2009<sup>(68)</sup>|Série de casos<br>prospectiva (estudo de<br>farmacocinética)|Determinar a dose MMF requerida para atingir ASC 0-<br>12h de concentração plasmática de MPA >30 mg h/L em<br>pacientes pediátricos pós-transplante hepático|MMF dose inicial mediana 300 mg/m2<br>2x/dia (mín186; máx 554 mg/m2 2x/dia) 1h<br>após administração de CNI|TAC (n=13) ou CsA (n=2)<br>2 pacientes também receberam<br>rifampin por prurido grave<br>induzido por colestase em dose<br>40 mg (5,4 mg/kg/dia) ou 50 mg<br>(2,8 mg/kg/dia) em 2 doses|MPA plasmático: método de cromatografia<br>de fase reversa; a LiChrospher 100 RP 18<br>column (250mm x 4mm) e uma fase móvel<br>consistindo de 45vol acetonitrile/55 vol<br>orthophosphoric ácido buffer (10 mM, pH<br>2). Extração sólido-líquida foi realizada por<br>meio das colunas Bond Elut, e MPA foi<br>observada por detecção ultravioleta à<br>216nm. Limite de quantificação de<br>0,1mg/L.|
|Lobritto et al. 2007<sup>(69)</sup>|Série de casos<br>prospectiva (estudo de<br>farmacocinética),<br>multicêntrico|Avaliar a farmacocinética do MMF em combinação com<br>CsA em população pediátrica pós-transplante hepático<br>estável e estimar a dose de MMF requerida para ofertar<br>concentrações de MPA similares às observadas em<br>adultos|MMF dose administrada: 138 mg (52,2) =<br>285 mg/m2 (81,1) = 12,9 mg/kg (3,32); 2x<br>dia|CsA|Cromatografia líquida específica validada /<br>espectrometria de massa|  
74  
|**Autor, ano**|**Desenho de estudo**|**População e objetivo do estudo**|**Detalhes da Intervenção**|**Detalhes da cointervenção**|**Método de dosagem do MMF**|
|---|---|---|---|---|---|
|Parant et al. 2009<sup>(70)</sup>|Série de casos<br>prospectiva (estudo de<br>farmacocinética)|Monitorar os níveis de MMF em população pediátrica<br>pós-transplante hepático clinicamente estável e<br>caracterizar os fatores que influenciam na variação de<br>concentração plasmática|Dose inicial de 20 mg/kg por dia, sendo 10<br>em monoterapia e 10 em uso concomitante<br>de TAC.<br>Dose de manutenção: 431 mg/m2 por dia<br>(189-833 mg/m2/dia)|TAC doses não reportadas.<br>Concentrações séricas: 6,3 µg/L<br>(2-10,5)|Analisador Cobas Mira Plus|
|Tredger et al. 2004<sup>(71)</sup>|Série de casos<br>prospectiva|Em população pediátrica pós-transplante hepático: 1).<br>Estabelecer um intervalo alvo de níveis plasmáticos que<br>minimizam os eventos terapêuticos adversos, 2) definir<br>fatores que influenciam as relações de concentração de<br>MMF / MPA em receptores de enxerto de fígado adultos<br>e pediátricos, 3) documentar as características do método<br>de ensaio de rotina empregado, e 4) demonstrar se houve<br>alguma justificativa econômica para o monitoramento de<br>rotina de MPA. (Apenas os dados referentes à população<br>pediátrica serão relatados e a maioria dos desfechos só<br>foi avaliada em população adulta)|Dose inicial 5 mg/kg de peso corporal<br>2x/dia, aumento ao longo do tempo para 10 e<br>20 mg/kg 2x/ se tolerado ou necessário|Glicocorticoides (n=60), TAC<br>(n=40) e CsA (n=22). Dezessete<br>receberam azatioprina antes de<br>iniciar o MMF|EMIT (enzyme multiplied immunoassay<br>technique)|  
MMF: micofenolato de mofetil; MPA: ácido micofenólico; TAC: tacrolimo; CsA: ciclosporina; ASC: área sobre a curva; tx: transplante; CNI: inibidor de calcineurina.  
75  
**Tabela 29 –** Características dos pacientes incluídos nos estudos avaliando a importância de dosagem sérica de micofenolato no pós-transplante hepático em pacientes pediátricos  
|**Autor, ano**|**N**|**Idade em anos, mediana**<br>**(Mínimo-Máximo)**|**% sexo masculino**|**Tipo de transplante**|**Tempo de transplante**|**Tempo do transplante ao início do**<br>**tratamento com MMF**|**Períodos de determinação da**<br>**concentração do MMF**|
|---|---|---|---|---|---|---|---|
|Attard et al.<br>2008<sup>(65)</sup>|41 pacientes|1° centro (n=20): 4,0 (0,5-17,2)<br>2° centro (n=21): 6,2 (1,2-16,5)|28/41 (68,3)|Cadavéricos e intervivos,<br>NR as proporções|<br>NR|NR|0, 20, 40, 75 minutos e 2, 4, 6<br>e 8 horas|
|Aw et al.<br>2003<sup>(66, 67)</sup>|21|9,5 (2,1-15,3)|12/21|NR|Mediana 4,7 anos (mín<br>1,3; máx 11,4)|Tempo de tratamento com MMF >6<br>meses sem alterações de doses na<br>última semana; mediana 30 meses<br>(mín 9; máx 49)|0, 0,33, 0,67, 1,25, 2, 3,5, 5, e<br>7 horas após administração de<br>MMF|
|Barau et al.<br>2009<sup>(68)</sup>|15|8,3 (1,1-15,2)|8/15|Cadavérico: 3/15|Mediana 11 meses (mín<br>0,5; máx 88,0)|Tempo desde início do tratamento<br>com MMF mediana 0,4 meses (0,2 -<br>48)|0-12h (1 a cada hora)|
|Lobritto et<br>al. 2007<sup>(69)</sup>|9 pacientes, sendo 8<br>incluídos nas<br>análises|16 meses (9-60)|3/8 (37,5)|Doador vivo aparentado|NR|NR|0,5; 0,75; 1,0; 1,5; 2,0; 4,0; 8,0<br>e 12 horas|
|Parant et al.<br>2009<sup>(70)</sup>|20 pacientes e 34<br>mensurações|12 (1-18)|11/20 (55)|12 pediátricos,<br>6 adultos vivos, 2<br>adultos cadavéricos|88 meses (3-179)|27 meses (3-91)|1, 3 e 6 horas após<br>administração de manhã|
|Tredger et<br>al. 2004<sup>(71)</sup>|63|3,5 (0,3-19,5)|31/63 (49,2)|NR|NR|2,4 meses (0-129,9)|Entre 8 e 21 horas após<br>administração, por 25 meses|  
N: número de pacientes; NR: não reportado; MMF: micofenolato de mofetil. Quando não especificado dados foram apresentados como mediana (mínimo-máximo) ou n/(%).  
**Tabela 80 –** Desfechos farmacocinéticos  
76  
|**Autor, ano**|**Desfechos de farmacocinética**|**Correlações**|**Fatores avaliados que influenciaram nas**<br>**concentrações**|
|---|---|---|---|
|Attard et al.<br>2008<sup>(65)</sup>|Mediana dos níveis de MPA:<br>1° centro (n=20) = 100% em uso concomitante de TAC: 24 mg/L (18-50)<br>2° centro (n=21) = 52,4% em uso concomitante de TAC: 29 (18-50) e 47,6%<br>em uso concomitante de ciclosporina: 42 mg/L (22-54)|NR|Tipo de imunossupressor concomitante (TAC e CsA)|
|Aw et al.<br>2003<sup>(66, 67)</sup>|Tempo médio para concentração máxima de MPA: mediana 0,83 horas (mín<br>0,33; máx 3,5)<br>Concentração plasmática MPA:<br>Tempo 0: 0,36 a 3,7 mg/L<br>Cmax: 2,8 a 39,99 mg/L<br>ASC0-7: 9,3 a 80,3 mg/L.hr<br>ASC0-12: 12,3 a 104,4 mg/L.hr|Correlação entre ASC0-7 e:<br>Concentração plasmática em C0 (r=0,84), p<0,001<br>Concentração plasmática em C3 (r=0,87), p<0,001<br>Dose real de MMF (r=0,55), p<0,01, em vez de dose corrigida por<br>peso corpóreo (r=0,29), p=0,2|Elevação de AST/TGO sem evidência de rejeição<br>reduziu os níveis de MPA: 0,77 vs. 1,76 mg/L, 7/21<br>pacientes; p=0,05<br>Pacientes tratados com CsA receberam doses absolutas<br>de MMF maiores (mediana 500mg; mín 250; máx 1000<br>vs mediana 250mg; mín 65; máx 500; p=0,006)|
||Proporção de pacientes que necessitaram de ajuste de dose para MPA ASC >30<br>mg h/L: 14/15<br>Tempo mediano de pico de concentração de MPA: 1 hora após dosagem: (0,5-|||
|Barau et al.<br>2009<sup>(68)</sup>|8)<br>Pico rebote observado entre 4-12 horas em 5/15 (33%) dos pacientes<br>Nos pacientes recebendo TAC: dose mediana inicial de 300 mg/m2 2x/dia<br>(186-554 mg/m2 2x/dia, dose máx 1500 mg 2x/dia): MPA ASC0-12 foi <30<br>mg h/L em 11/13 pacientes|NR|NR|
|Lobritto et al.<br>2007<sup>(69)</sup>|MPA-ASC 0-12h: 22,7 µg.h/mL (10,5)<br>MPA-ASC0-12h normalizado para 600 mg/m2: 47,0 µg.h/mL (21,8)|NR|NR|
|Parant et al.<br>2009<sup>(70)</sup>|C0 de MPA =0,97 mg/L (0,26-6,93 mg/L)<br>ASC0-12h: 27 mg/h/L (17-79 mg/h/L)<br>Proporção de pacientes que atingiram limiar terapêutico de 30 mg/h/L: 44%|Idade da criança e ASC0-6h: cs=0,45; (IC 95% 0,14-0,69),<br>p<0,01<br>Idade da criança e ASC0-12h: cs=0,40; (IC 95% 0,07-0,65),<br>p=0,02<br>MPA-C0 e ASC0-6h: cs=0,75; (IC 95% 0,56-0,87), p=0,01<br>MPA-C0 e ASC0-6h em crianças de 3 a 10 anos: cs=0,68; (IC|As concentrações de MPA foram mais baixas apenas no<br>subgrupo de pacientes <10 anos e que receberam o órgão<br>de doador pediátrico|  
77  
|**Autor, ano**||**Desfechos de farmacocinética**|**Correlações**|**Fatores avaliados que influenciaram nas**<br>**concentrações**|
|---|---|---|---|---|
||||95% 0,17-0,90), p=0,02||
||||MPA-C0 e ASC0-6h em crianças de >10 anos: cs=0,79; (IC 95%||
||||0,49-0,93), p<0,01)||
|Tredger et al.<br>2004<sup>(71)</sup>|Proporção de p<br>62,5%|opulação pediátrica que sofreu variabilidade interpaciente:|NR|Idade, co-medicações|  
MPA: ácido micofenólico; TAC: tacrolimo; NR: não reportado; CsA: ciclosporina; Cmáx: concentração máxima; ASC: área sobre a curva 0-7: área sobre a curva entre 0 e 7 horas; ASC 0-12: área sobre a curva entre 0 e 12 horas; C0: concentração plasmática medida em tempo 0; C3: concentração plasmática medida em 3 horas; MMF: micofenolato de mofetil; AST: aspartatoaminotransferase/TGO: transaminase glutâmico-oxalacética; IC95%: intervalo de confiança de 95%.  
78  
Com base na interpretação das evidências provenientes dos estudos incluídos, na graduação da qualidade da evidência e  
no consenso do GE em relação à direção (a favor ou contra) e força da recomendação (forte ou condicional), a seguinte recomendação foi definida no PCDT:  
“Apesar de não ser prática clínica no Brasil, as evidências disponíveis demonstram benefícios com a monitorização de ácido micofenólico, para manutenção de níveis terapêuticos adequados”  
**(GRADE: recomendação condicional a favor; qualidade da evidência: moderada).**  
79

---

