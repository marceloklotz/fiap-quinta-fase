<!-- METADADOS: doenca: Tabagismo | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 10, DE 16 DE ABRIL DE 2020  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Tabagismo.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso das atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre o tabagismo no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando a Portaria Nº 571/GM/MS, de 5 de abril de 2013, que atualiza as diretrizes de cuidado à pessoa tabagista no âmbito da Rede de Atenção à Saúde das Pessoas com Doenças Crônicas do Sistema Único de Saúde (SUS) e dá outras providências;  
Considerando os registros de deliberação N<sup><u>o</u></sup> 468/2019 e N<sup><u>o</u></sup> 511/2020 e os relatórios de recomendação n<sup>o</sup> 468 – Julho de 2019 e n<sup><u>o</u></sup> 520 – Março de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas –  
Tabagismo.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do tabagismo, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser</u> utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos  
correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do tabagismo.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 761/SAS/MS, de 21 de junho 2016, publicada no Diário Oficial da União (DOU) nº 118, de 22 de junho de 2016, seção 1, páginas 68.

---

<!-- METADADOS: doenca: Tabagismo | secao: DENIZAR VIANNA -->
ANEXO

---

<!-- METADADOS: doenca: Tabagismo | secao: **1. INTRODUÇÃO** -->
O tabagismo é considerado uma doença epidêmica decorrente da dependência à nicotina e se inclui na 10ª Classificação Internacional de Doenças (CID10) no grupo de transtornos mentais e de comportamento devido ao uso de substâncias psicoativas. Além de ser uma doença, é fator causal de aproximadamente 50 outras doenças incapacitantes e fatais, como câncer, doenças cardiovasculares e doenças respiratórias crônicas (1).  
Segundo estimativas da Organização Mundial de Saúde (OMS), o fumo é responsável por 71% das mortes por câncer de pulmão, 42% das doenças respiratórias crônicas e aproximadamente 10% das doenças cardiovasculares, além de ser fator de risco para doenças transmissíveis, como a tuberculose (2). Para o ano de 2030, foram estimadas em torno de 8 milhões de mortes em todo o mundo por doenças relacionadas ao tabaco, caso não sejam adotadas medidas para o controle e cessação do tabagismo (3).  
Como uma resposta a esse grave problema de saúde pública, desde 1989 a governança do controle do tabagismo no Brasil passou a ser articulada pelo Ministério da Saúde (MS), por meio do seu Instituto Nacional de Câncer (INCA), o que inclui um conjunto de ações nacionais que compõem o Programa Nacional de Controle do Tabagismo (PNCT). O Programa tem como objetivo geral reduzir a prevalência de fumantes e, consequentemente, a morbimortalidade relacionada ao consumo de derivados do tabaco no Brasil, seguindo um modelo lógico pelo qual ações educativas, de comunicação e de atenção à saúde, junto com ações legislativas e econômicas, se potencializam para prevenir a iniciação do tabagismo, promover a cessação do tabagismo e proteger a população dos riscos do tabagismo passivo, alcançando, assim, o objetivo proposto (4).  
Em novembro de 2005, o Brasil tornou-se Estado Parte da ConvençãoQuadro da OMS para Controle do Tabaco (CQCT), primeiro tratado internacional de Saúde Pública negociado sob os auspícios desta Organização, que coloca, diante dos  
países que o ratificaram, o desafio de implementar medidas intersetoriais relacionadas à redução da demanda e da oferta dos produtos de tabaco. Com a ratificação deste tratado pelo Brasil sua implementação nacional ganhou o _status_ de política de Estado – a Política Nacional de Controle do Tabaco. Com isso, o Programa Nacional de Controle do Tabagismo passa a ter como objetivo a implementação da CQCT no âmbito da saúde e apoio fundamental na adoção de medidas intersetoriais (5,6).  
Como resultado de todo esse esforço, a prevalência do tabagismo vem apresentando queda a partir da implementação de medidas de controle do tabaco que incluem, além de educação da população sobre os danos à saúde, medidas legislativas como restrições à propaganda, comercialização e proibição do uso de produtos fumígenos, derivados ou não do tabaco, em locais fechados. Entre os homens brasileiros, a prevalência de tabagismo declinou de 43,3% em 1989 para 18,9% em 2013 e, entre as mulheres, respectivamente de 27,0% para 11,0% (7,8).  
Parte integrante do Programa Nacional de Controle do Tabagismo desde 1996 e uma das medidas descritas na Convenção-Quadro para o Controle do Tabaco, as ações para promover a cessação do tabagismo têm como objetivo motivar fumantes a deixarem de fumar e aumentar o seu acesso aos métodos eficazes para o tratamento da dependência à nicotina (9).  
No que tange a cessação do tabagismo, a Portaria SAS/MS n° 1.575/2002 instituiu o tratamento do tabagismo formalmente no SUS, porém limitando o atendimento à assistência especializada de alta complexidade (10). A partir da publicação das portarias GM/MS n° 1.035/2004 e SAS/MS nº 442/2004, o acesso ao tratamento foi ampliado à Atenção Primária à Saúde (APS) e à assistências especializada de média complexidade e houve a aprovação do Plano para Implantação da Abordagem e Tratamento do Tabagismo no SUS, a publicação do Protocolo Clínico de Diretrizes Terapêuticas (PCDT) da Dependência à Nicotina e a definição do financiamento dos procedimentos a serem utilizados (11,12).  
A Lei nº 12.401/2011 estabeleceu as diretrizes diagnósticas e terapêuticas baseadas em evidências para o SUS como Protocolos Clínicos e Diretrizes Terapêuticas (PCDT). Segundo a CONITEC, os PCDT são documentos que estabelecem critérios para o diagnóstico da doença ou do agravo à saúde; o tratamento preconizado, com os medicamentos e demais produtos apropriados, quando couber; as posologias  
recomendadas; os mecanismos de controle clínico; e o acompanhamento e a verificação dos resultados terapêuticos, a serem seguidos pelos gestores do SUS. Devem ser baseados em evidência científica e considerar critérios de eficácia, segurança, efetividade e custo-efetividade das tecnologias recomendadas (13).  
Em 2013, foi publicada a Portaria nº 571 GM/MS, a qual atualizou as Diretrizes no âmbito do SUS, reforçando a APS como um âmbito privilegiado e estratégico para o desenvolvimento das ações de estímulo e apoio à adoção de hábitos mais saudáveis de vida. Essa Portaria também revogou a anterior, incluindo o Anexo que continha o supracitado PCDT (14). Tal decisão foi revista por meio da Portaria SAS nº 761, de 21 de junho de 2016 (15), que validou as orientações técnicas do protocolo anteriormente revogado. Essa iniciativa foi atrelada ao compromisso de elaboração de um novo PCDT que desse suporte ao tratamento do tabagismo no País e estivesse em consonância com o modelo de protocolos e diretrizes baseados em evidências.  
A atuação dos profissionais da Atenção Primária dá um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do tabagismo. A sua elaboração seguiu as recomendações do Ministério da Saúde contidas em suas diretrizes metodológicas (16). Foram realizadas buscas estruturadas por revisões sistemáticas (RS) para todas as questões nele abordadas. Quando não foram encontradas RS que respondessem às perguntas, foram realizadas buscas sistemáticas por ensaios clínicos randomizados (ECR), e o conjunto das evidências foi utilizado para responder aos desfechos de interesse. Para a avaliação da qualidade da evidência disponível na literatura, foi utilizado o sistema GRADE ( _Grading of Recommendations, Assessment, Development and Evaluation_ ), que classifica a qualidade da evidência em quatro categorias (muito baixa, baixa, moderada e alta) (17,18). Foram desenvolvidas tabelas com a sumarização das evidências na plataforma GRADEpro 2015 (19). A partir disso, foram elaboradas as recomendações, forte ou fraca, a favor ou contra, para cada intervenção. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E**

---

<!-- METADADOS: doenca: Tabagismo | secao: **PROBLEMAS  RELACIONADOS À SAÚDE (CID-10)** -->
- F17.1 Transtornos devido ao uso do fumo – uso nocivo para a saúde  
- F17.2 Transtornos mentais e comportamentais devidos ao uso de fumo – síndrome de dependência  
- F17.3 Transtornos mentais e comportamentais devidos ao uso de fumo – síndrome (estado) de abstinência  
- T65.2  Efeito tóxico do tabaco e da nicotina  
- Z72.0 Uso de Tabaco

---

<!-- METADADOS: doenca: Tabagismo | secao: **3. DIAGNÓSTICO DA DEPENDÊNCIA À NICOTINA** -->
A nicotina, substância encontrada no tabaco, é classificada como psicoativa e atua estimulando o sistema nervoso central (sistema mesolímbico), que está relacionado com a motivação, sexualidade, atenção, prazer e recompensa (20-22).  
O risco de dependência está diretamente relacionado à rapidez com a qual a substância produz seu pico de ação. Poucos segundos após a tragada do produto, a nicotina atinge o sistema de recompensa estimulando a liberação de neurotransmissores, como a dopamina, que é responsávelpela sensação de prazer, melhora da cognição, promoção de maior controle de estímulos e emoções negativas e redução de ansiedade e do apetite. Esse processo produz um reforço positivo e a necessidade de repetição de seu uso (21,22).  
Outra ação é a de inibição do sistema GABA (ácido gama-aminobutírico), pois, estando bloqueado pela ação da nicotina, o tabagista, ao tragar, experimentará uma sensação de prazer e bem-estar ainda mais intensa e duradoura. Com o tempo, uma maior quantidade será necessária para alcançar e manter essas sensações, caracterizando tolerância, e, portanto, o quadro de dependência química. Além disso, a nicotina apresenta meia-vida de duas horas e, após esse período, com a redução dos níveis plasmáticos, sintomas desagradáveis, como irritação, depressão, ansiedade e aumento do apetite, podem surgir e dificultar a abstinência, levando o tabagista a fumar novamente para livrar-se do desconforto (21-24).  
Essas características de ação da nicotina levaram a OMS à inclusão do tabagismo no grupo de transtornos mentais e de comportamentos decorrentes do uso de substâncias psicoativas (25). São considerados como dependentes os indivíduos que tenham  
apresentado, no ano anterior, pelo menos três dos critérios a seguir:  
- Desejo forte e compulsivo para consumir a substância (fissura ou _craving_ );  
- dificuldade para controlar o uso (início, término e níveis de consumo);  
- estado de abstinência fisiológica diante da suspensão ou redução, caracterizado por  síndrome de abstinência e consumo da mesma substância ou similar, com a intenção de aliviar ou evitar sintomas de abstinência (reforço negativo);  
- evidência de tolerância, ou seja, necessidade de doses crescentes da substância para obter os efeitos produzidos anteriormente com doses menores;  
- abandono progressivo de outros prazeres em detrimentos do uso de substâncias psicoativas;  
- aumento do tempo empregado para conseguir ou consumir a substância ou recuperar- se de seus efeitos;  
- persistência no uso apesar das evidentes consequências, como câncer pelo uso do tabaco, humor deprimido ou perturbações das funções cognitivas relacionada com a substância.  
O diagnóstico de dependência da nicotina é cliínco e deve ser feito por meio de avaliação procedida pelo profissional da saúde que atende o usuário de tabaco, seguindo os critérios diagnósticos descritos acima. Não são utilizados exames físicos, laboratoriais ou de imagem para este fim. O profissional da saúde baseia-se no relato do paciente.  
Para avaliar o grau de dependência à nicotina, pode ser usado o Teste de Fagerström ( **Quadro 1** ). Composto de seis perguntas, com escores que variam de zero a dez, ele indica que o tabagista poderá experimentar sintomas desconfortáveis da síndrome de abstinência, quando o resultado encontrado for acima de 6 pontos (26).  
**Quadro 1 -** Teste de Fagerström para a dependência à nicotina  
|**Perguntas**|**Respostas**|**Pontuação**|
|---|---|---|
|1. Quanto tempo após acordar você fuma seu primeiro|Nos primeiros 5 minutos|3|
|cigarro?|De 6 a 30 minutos<br>De 31 a 60 minutos<br>Mais de 60 minutos|2<br>1<br>0|
|2. Você acha difícil não fumar em lugares proibidos?|Sim|1|
||Não|0|
|3. Qual o cigarro do dia que traz mais satisfação?|O 1° da manhã<br>Os outros|1<br>0|
|4. Quantos cigarros você fuma por dia?|Menos de 10|0|
||11-20|1|
||21-30|2|
||Mais de 31|3|
|5. Você fuma mais frequentemente pela manhã?|Sim|1|
||Não|0|
|6. Você fuma mesmo doente, quando precisa ficar|Sim|1|
|acamado a maiorparte do tempo?|Não|0|
|Escore Total (da dependência): 0-2 = muito baixa; 3-4 = baixa; 5|= média; 6-7 = elevada; 8-10 = muito elevada||  
O teste de Fagerström não engloba todas as situações possíveis da rotina do fumante, como, por exemplo: indivíduos que adotaram outras formas de uso em decorrência da legislação sobre Ambientes 100% Livres da Fumaça de Tabaco e fumam em outros locais e horários, para evitar o desconforto da síndrome de abstinência prolongada; indivíduos que fumam mais no período da noite ou interrompem o sono para fumar para sair da síndrome de abstinência, sem apresentar insônia em seguida; e tabagistas ocasionais ou irregulares, que associam o tabagismo ao consumo de bebidas alcóolicas.

---

<!-- METADADOS: doenca: Tabagismo | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Ficam incluídos neste Protocolo, para todos os tratamentos, medicamentoso e não medicamentoso, os tabagistas atendidos nos diferentes níveis de atenção do Sistema Único de Saúde (SUS).

---

<!-- METADADOS: doenca: Tabagismo | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Do tratamento medicamentoso preconizado neste Protocolo, serão excluídos  
os tabagistas com contraindicação ao uso do respectivo medicamento.

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.1. Casos de recaída -->
É indicado que tabagistas previamente tratados e que tenham apresentado recaída recebam incentivo para realizar novamente o tratamento do tabagismo, sempre valorizando as experiências por eles vividas nas tentativas anteriores de cessação. Acolher o paciente na sua totalidade, reforçar os ganhos, destacando a sua importante decisão de parar de fumar, esclarecer que o fato de ter recidivado no vício não significa impossibilidade de cessá-lo e discutir as estratégias futuras são imprescindíveis para o sucesso desta nova etapa. De forma conjunta, paciente e profissional da saúde devem decidir qual medida terapêutica será utilizada. Se possível esse paciente deve ser encaminhado para acompanhamento psicológico concomitante.  
Existe a liberdade para se manter ou alterar os medicamentos. Há evidências de que, independentemente do fármaco anteriormente utilizado, ele continua apresentando eficácia superior ao placebo, em um novo tratamento (27-29). É importante que os eventos adversos relatados na tentativa prévia sejam considerados na escolha do novo medicamento, de forma a aumentar a adesão ao tratamento.

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.2. Adolescentes (indivíduos menores de 18 anos) -->
As evidências sobre a eficácia de intervenções comportamentais para a cessação do tabagismo em adolescentes são limitadas por questões como imprecisão, heterogeneidade e risco de viés dos estudos. O aconselhamento em grupo parece ser mais promissor do que as intervenções individuais, podendo ser uma escolha terapêutica apropriada (30). Com relação ao uso de farmacoterapia nesta faixa etária, ainda há poucos estudos com resultados imprecisos; portanto, o uso de bupropiona não é preconizado em pessoas com menos de 18 anos de idade, até que novas pesquisas possam justificar o seu uso nessa faixa etária.  
Sendo assim, o adolescente deve receber tratado com o aconselhamento estruturado/abordagem intensiva, ressaltando-se a importância de oferecer atendimento a essa população, que costuma ser mais vulnerável, principalmente com a entrada no mercado de novos produtos derivados de tabaco.

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.3. Gestantes e nutrizes -->
Para gestantes e nutrizes, é indicado o aconselhamento estruturado para a cessação do tabagismo, sendo o efeito benéfico dessa intervenção observado tanto ao final da gestação quanto a longo prazo (medido até 17 meses após o parto) (31).  
Inexistem evidências científicas suficientes de eficácia e segurança na utilização de  farmacoterapia [terapia de reposição de nicotina (TRN) e cloridrato de bupropiona] durante a gestação (32).  
Gestantes e nutrizes devem tentar parar de fumar sem utilizar nenhum tratamento medicamentoso.

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.4. Idosos -->
Não se preconizam condutas terapêuticas do tabagismo para idosos que sejam diferentes das utilizadas para a população adulta, exceto quando esses indivíduos apresentarem comorbidades, que contraindiquem o uso de algum medicamento (33).  
Em indivíduos acima de 65 anos, preconiza-se a dose matinal de 150 mg/ dia de cloridrato de bupropiona (34).  
O tratamento medicamentoso deve ser utilizado objetivando a complementação da terapia cognitivo-comportamental, tendo também como efeito o alívio dos sintomas da abstinência. Independentemente da idade, deixar de fumar pode aumentar a expectativa de vida, melhorar a saúde e a qualidade de vida. Aqueles idosos que decidem fazer uma tentativa têm elevada taxa de sucesso (35,36).

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.5. Pacientes com tuberculose -->
Segundo dados da OMS, mais de 20% da incidência global de tuberculose pode ser atribuída ao tabagismo, que aumenta em duas vezes e meia o risco dessa doença. Tabagistas sem história anterior de tuberculose apresentam risco de morte por essa doença nove vezes maior quando comparados com os que nunca fumaram. Ao parar de fumar, o risco de morte por tuberculose reduz-se cerca de 65% em comparação aos que continuam a fumar (37).  
A associação tabagismo e tuberculose requer medidas regulatórias e  
educacionais, além de estratégias terapêuticas, investigação clínica, política, pesquisa e componentes programáticos, desenvolvidos de forma articulada e coordenada por ambos os programas – de controle do tabagismo e de controle da tuberculose - em todos os níveis de atenção à saúde. Neste sentido, as medidas terapêuticas para o controle do tabagismo deve ser uma parte integrante do cuidado do paciente com tuberculose (38-40).  
É indicado que portadores de tuberculose, em qualquer fase do tratamento, sejam tratados da dependência à nicotina e utilizem as mesmas medidas terapêuticas empregadas para a população em geral. O tratamento preconizado é a associação de aconselhamento estruturado com farmacoterapia (36).

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.6. Pacientes com câncer -->
A identificação do tabagismo e as intervenções para a sua cessação são recomendadas como parte essencial da assistência oncológica. Parar de fumar diminui os riscos de doença e de complicações pós-operatórias, aumenta a eficácia da quimioterapia, diminui as complicações da radioterapia e aumenta o tempo de sobrevida e a qualidade de vida dos doentes (41).  
Pacientes com câncer devem ser encorajados a parar de fumar e, portanto, devem receber auxílio para tal. É indicado que o tratamento do tabagismo seja iniciado o mais breve possível e que a conduta terapêutica inclua a associação de intervenções não medicamentosas e medicamentosas (41-43).

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.7. <u>Pacientes com transtorno psiquiátrico (incluindo dependência ao álcool e outras drogas)</u> -->
É indicado que intervenções para a cessação do tabagismo, incluindo a farmacoterapia e sua combinação com o aconselhamento estruturado, sejam oferecidas aos fumantes em tratamento e reabilitação da dependência de álcool e outras drogas. Inexiste evidência da eficácia do aconselhamento isolado para o tratamento de cessação do tabagismo nessa população, em ambientes hospitalares, ambulatoriais ou em reabilitação (44).  
Pacientes com depressão atual ou pregressa apresentam melhores resultados para eficácia, quando o tratamento para a cessação do tabagismo é associado a um tratamento psicossocial para controle do humor. Em fumantes com depressão pregressa, a  
bupropiona aumenta a cessação do tabagismo, em comparação a placebo. Contudo, para tabagistas com depressão atual, não há evidências de que a bupropiona aumente a cessação. Também não há evidências significativas da eficácia de TRN, em comparação a placebo, no tratamento para cessação do tabagismo em paciente com depressão atual (45).  
Para pacientes com esquizofrenia, a bupropiona aumenta a cessação do tabagismo, quando comparada a placebo. Não há evidências de benefícios na utilização de outros tratamentos medicamentosos (TRN) e intervenções psicossociais como recursos terapêuticos para a dependência à nicotina nessa população (46).  
É necessário que pacientes tabagistas que relatem história pregressa de transtorno psiquiátrico sejam encaminhados (caso ainda não o tenham sido) para avaliação de profissional da saúde mental e tratamento adequado. O tratamento para a cessação do tabagismo pode se dar após ou em paralelo ao tratamento definido para o transtorno. O mesmo deve acontecer quando, independentemente do relato de história pregressa, o profissional que faz o atendimento para a cessação do tabagismo avalie ou identifique a necessidade de encaminhamento para o atendimento especializado em saúde mental, para melhor caracterização, diagnóstico e tratamento de caso suspeito de transtorno psiquiátrico.

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.8. Pacientes hospitalizados -->
Não foram encontradas revisões sistemáticas que avaliassem como desfecho a redução de sintomas de abstinência em pacientes hospitalizados.  
Intervenções comportamentais de alta intensidade iniciadas durante a internação hospitalar, e que incluam contato para apoio após a alta por pelo menos um mês, auxiliam na cessação do tabagismo entre os pacientes hospitalizados, independente do diagnóstico de admissão. Inexistem evidências de eficácia para intervenções de menor intensidade ou menor duração. A associação de farmacoterapia (no caso, a TRN) ao aconselhamento intensivo aumenta significativamente a cessação, em comparação ao aconselhamento intensivo isolado. Inexistem evidências de que a associação de bupropiona ao aconselhamento intensivo aumente a eficácia do tratamento para a cessação do tabagismo, quando comparada ao aconselhamento intensivo isolado nessa população (47).

---

<!-- METADADOS: doenca: Tabagismo | secao: 6.9. Pacientes internados em instituições de média e longa permanência (hospitais <u>psiquiátricos/reabilitação clínica/ presídios)</u> -->
Ver achados relacionados a internações em instituições psiquiátricas inseridos no sub-item 6.7, acima, referente a pacientes com transtornos psiquiátricos.  
As abordagem terapêutica e farmacoterapia aumentam a chance de cessação do tabagismo nos presídios, com resultados semelhantes aos observados na população geral. É indicado, portanto, que a população carcerária receba atendimento para tratamento desta dependência, que deve ser oferecido respeitando as regras, estruturas e especificidades do sistema carcerário (48,49).

---

<!-- METADADOS: doenca: Tabagismo | secao: **7.1. Boas Práticas no Tratamento do Tabagismo** -->
O artigo 14 da Convenção-Quadro da OMS para Controle do Tabaco recomenda que cada país signatário elabore e divulgue diretrizes apropriadas, completas e integradas, fundamentadas em provas científicas e nas melhores práticas, tendo em conta as circunstâncias e prioridades nacionais, devendo adotar medidas eficazes para promover a cessação do consumo do tabaco, bem como o tratamento adequado à sua dependência.  
O tratamento da dependência ao tabaco deve estar amplamente disponível e acessível. Deve ser inclusivo, levando em conta fatores como gênero, cultura, religião, idade, escolaridade, situação sócio-econômica e necessidades especiais, e eventualmente adaptadas às reais necessidades de diferentes tabagistas e dos grupos com maior prevalência de uso do tabaco.  
A fim de desenvolver o tratamento do tabagismo de forma mais rápida e com menor custo, devem ser usados ao máximo possível os recursos e infraestruturas existentes e garantir que os usuários de tabaco recebam pelo menos um aconselhamento breve em todo o SUS.  
Todos os profissionais da saúde devem ser treinados para perguntar sobre o uso do tabaco, registrar as respostas nos prontuários dos pacientes, dar breves conselhos sobre o abandono de fumar e encaminhar os fumantes para o tratamento mais adequado e eficaz disponível localmente. A abordagem breve deve ser implementada como um componente essencial do protocolo de atuação na área da saúde (9).  
A abordagem breve/mínima (PAAP, sigla para Perguntar e Avaliar, Aconselhar e Preparar) consiste em perguntar, avaliar, aconselhar e preparar o fumante para que deixe de fumar, sem, no entanto, acompanhá-lo neste processo. Pode ser feita por qualquer profissional da saúde durante a consulta de rotina, sobretudo por aqueles que têm dificuldade de fazer um acompanhamento deste tipo de paciente (p.ex., profissionais que atuam em pronto-socorro, pronto-atendimento, triagem etc.). Esse tipo de abordagem pode ser realizado em 3 minutos durante o contato com o paciente. Vale salientar que, embora não se constitua na forma ideal de atendimento, pode propiciar resultados positivos como instrumento de cessação do tabagismo, pois permite que um grande número de fumantes seja beneficiado a um baixo custo (50).  
A abordagem básica (PAAPA – sigla para Perguntar e Avaliar, Aconselhar, Preparar e Acompanhar) consiste em perguntar, avaliar, aconselhar, preparar e acompanhar um fumante para que deixe de fumar. Também pode ser feita por qualquer profissional da saúde durante a consulta de rotina, com duração mínima de 3 minutos e máxima de 5 minutos em cada contato. É indicada para todos os fumantes e mais recomendada que a anterior (PAAP) porque prevê o retorno do paciente para acompanhamento na fase crítica da abstinência, constituindo-se em uma importante estratégia em termos de saúde pública (50).  
As perguntas sugeridas para essas abordagens são:  
- Você fuma? Há quanto tempo? _(Permite diferenciar a experimentação do uso regular.)_  
- Quantos cigarros fuma por dia? _(Pacientes que fumam 20 cigarros ou mais por dia provavelmente terão uma maior chance de desenvolverem fortes sintomas de síndrome de abstinência na cessação de fumar.)_  
- Quanto tempo após acordar acende o 1º cigarro? _(Pacientes que fumam nos primeiros 30 minutos após acordar, provavelmente terão uma maior chance de desenvolverem fortes sintomas de síndrome de abstinência na cessação de fumar.)_  
- O que você acha de marcar uma data para deixar de fumar? _(Permite avaliar se o fumante está pronto para iniciar o processo de cessação de fumar.)_ <u>Em caso de resposta afirmativa, perguntar: Quando?</u>  
Já tentou parar? _(Se a resposta for afirmativa, fazer a próxima_  
_pergunta.)_  
- O que aconteceu? ( _Permite identificar o que ajudou e o que atrapalhou a deixar de fumar, de modo que esses dados sejam trabalhados na próxima tentativa.)_  
A partir das respostas às perguntas acima, preconiza-se aconselhar o fumante a parar de fumar, adaptando as mensagens ao seu perfil e levando em consideração a idade e existência de doenças associadas ao tabagismo, entre outros aspectos. A conduta deve estar de acordo com o interesse do fumante em deixar de fumar, ou não, no momento da consulta.  
Os fumantes que não estiverem dispostos a parar nos próximos 30 dias, devem ser estimulados a pensar sobre o assunto e serem abordados no próximo contato. É importante que o profissional da saúde se mostre disposto a apoiá-los nesse processo.  
Para aqueles interessados em parar de fumar, a etapa seguinte é prepará-los para isso. Nessa etapa da preparação para cessação, o profissional da saúde deve sugerir que o fumante marque uma data para o início do seu processo; explicar os sintomas da abstinência; e sugerir estratégias para controlar a vontade fumar (repetidamente tomar água e escovar os dentes, por exemplo) e para quebrar os estímulos para fumar (como restringir o uso de café e de bebidas alcoólicas, desfazer-se de isqueiros, evitar ambientes ou situações que estimulem o fumar e aprender a lidar com situações de estresse, entre outros). Esse preparo deve levar em consideração as experiências individuais do paciente e do próprio profissional que o está atendendo.  
O ideal é que todos os fumantes que estão em processo de cessação de fumar sejam acompanhados com consultas de retorno para garantir um apoio na fase inicial da abstinência, quando os riscos de recaída são maiores.  
Diversos fatores podem afetar a cessação do tabagismo, aumentando ou diminuindo as chances de parar de fumar. Os estudos são heterogêneos, bem como seus resultados. Menor nível de dependência parece aumentar a chance de cessação do tabagismo (51-55). Por outro lado, a presença de algum distúrbio psiquiátrico pode ser um fator complicador para cessação (51,56-58).  
Evidências menos consistentes apontam para outros fatores relacionados  
com a dificuldade em parar de fumar, como baixa motivação, ausência de atividade física, ausência de doenças relacionadas ao tabagismo, tempo de uso de tabaco igual ou inferior a 20 anos, início do tabagismo com 18 anos ou mais, não participações em sessões de manutenção, presença de gatilhos, ser solteiro(a) e alta escolaridade (52,53,55,58-60).

---

<!-- METADADOS: doenca: Tabagismo | secao: **7.2. Tratamento do Tabagismo** -->
O tratamento para cessação do tabagismo no SUS consiste no aconselhamento terapêutico estruturado/abordagem intensiva (ver o sub-item 7.2.1, adiante), acompanhado pelo tratamento medicamentoso, salvo em situações especiais descritas no sub-item 6.  
Este último inclui os seguintes medicamentos: nicotina (adesivo, goma e pastilha), na TRN isolada ou em combinação; e cloridrato de bupropiona.  
O tempo de tratamento total preconizado é de 12 meses e envolve as etapas de avaliação, intervenção e manutenção da abstinência.  
A etapa de avaliação é o momento em que será possível conhecer a história tabagística (como idade de iniciação e tentativas para deixar de fumar), histórico patológico (presença ou não de doenças relacionadas com o tabaco), avaliação do grau de dependência da nicotina (Teste de Fagerström) e estágios de motivação para cessação do tabagismo. Essa avaliação inicial permitirá ao profissional da saúde definir se, além da abordagem cognitivo-comportamental, o paciente necessitará de medicação e de qual tipo.  
As etapas de intervenção e manutenção estão descritas no sub-item 7.2.1., a seguir.  
O desfecho esperado é a cessação total do tabagismo, ou seja, a interrupção do uso da nicotina em qualquer de suas formas.  
A falha terapêutica deve ser entendida como o não alcance da cessação do tabagismo ao final do tratamento.

---

<!-- METADADOS: doenca: Tabagismo | secao: **7.2.1. Tratamento não medicamentoso** -->
Todos os indivíduos em tratamento do tabagismo devem receber  
aconselhamento terapêutico estruturado/abordagem intensiva. O aconselhamento terapêutico da dependência à nicotina envolve a intervenção não medicamentosa, que visa ao entendimento do problema e a melhora no controle dos sintomas de abstinência.  
Cabe ressaltar que o formato do aconselhamento estruturado/abordagem intensiva deve considerar, preferencialmente, a disponibilidade e viabilidade dos indivíduos, dos profissionais e dos serviços de saúde.  
Esse tratamento deve ser baseado na terapia cognitivo-comportamental e realizado em sessões periódicas, de preferência em grupo de apoio, podendo também ser individual. Consiste em fornecer informações sobre os riscos do tabagismo e os benefícios de  se parar de fumar, e no estímulo ao autocontrole ou autocuidado para que os indivíduos possam administrar o ciclo da dependência.  
O aconselhamento estruturado/abordagem intensiva deve ser coordenado por profissionais da saúde, de nível superior, capacitados, tendo como sugestão o esquema abaixo (já utilizado no SUS desde 2001, com material de apoio específico).

---

<!-- METADADOS: doenca: Tabagismo | secao: <u>Aconselhamento estruturado/Abordagem Intensiva:</u> -->
Quatro sessões iniciais, preferencialmente semanais, são programadas, nas quais são abordados os seguintes conteúdos:  
|Sessão 1: Entender por que se fuma e como isso afeta a saúde.|
|---|  
|Nesta sessão serão desenvolvidas orientações sobre os aspectos do tabagismo; ambivalência do fumante em parar ou continuar<br>fumante; métodos para deixar de fumar; as principais substâncias contidas na fumaça do produto e seus prejuízos à saúde.|
|---|
|Também serão abordadas tarefas para que o paciente identifique e mensure sua dependência física e psicológica; pense numa data e o|
|método que usará futuramente para deixar de fumar e apresentará na sessão 2, objetivando a organização de seu processo de|
|cessação|
|Sessão 2: Os primeiros dias sem fumar.|  
|Nesta sessão serão conduzidas discussões sobre viver os primeiros dias sem fumar, síndrome de abstinência e estratégias para<br>superá-la, exercícios de respiração e relaxamento, definição de assertividade e sua relação com o parar de fumar, o que são e<br>quais as contribuições do pensamento construtivo diante dos sintomas da abstinência, motivação, tarefas que estimulem o fumante<br>a efetivar a cessação na data e método escolhidos para deixar de fumar e trazer o resultado na próxima sessão.<br>Sessão 3: Como vencer os obstáculos para permanecer sem fumar.|
|---|  
|Nesta sessão o indivíduo será estimulado a identificar os benefícios físicos obtidos após parar de fumar, descrição das causas e<br>estratégias para lidar com o ganho de peso que se segue ao parar de fumar, o papel do álcool e sua relação com o parar de fumar,<br>importância do apoio interpessoal para continuar sem fumar.|
|---|
|Também serão apresentadas tarefas que envolvem leituras e estímulo à prática dos exercícios de relaxamento e dos|
|procedimentos práticos para lidar com a fissura (ânsia).|
|Sessão 4: Benefícios obtidos apósparar de fumar.|  
Nesta sessão, após a definição pelo coordenador da abordagem sobre os benefícios indiretos em parar de fumar, o indivíduo é estimulado a apresentar alguns exemplos desses benefícios. O coordenador aborda então as principais armadilhas evitáveis para permanecer sem fumar, os benefícios a longo prazo obtidos com o parar de fumar, planos de acompanhamento para prevenção da recaída.  
Também faz parte dessa sessão a orientação aos que não conseguiram parar de fumar.  
Duas sessões quinzenais, iniciando a fase de manutenção da abstinência.  
O teor das sessões de manutenção não mais será estruturado, pois o objetivo fundamental é conhecer as dificuldades e estratégias de cada fumante para permanecer sem fumar e auxiliá-lo com orientações.  
Uma sessão mensal aberta, para prevenção de recaída, até completar 1 ano.  
Assim como nas sessões de manutenções quinzenais, as sessões de manutenção mensal não são estruturadas, e seu teor continua a ser conhecer as dificuldades e estratégias de cada fumante para permanecer sem fumar, orientar e fortalecer a decisão de permanecer sem fumar.  
O material que detalha o desenvolvimento de cada uma das sessões, instruindo o profissional da saúde sobre os procedimentos adequados no cuidado com o paciente, é o Manual do Coordenador. Há também os manuais destinados aos tabagistas em tratamento, que visam a orientá-lo sobre os passos a serem dados até o alcance da abstinência (Manuais do Participante). Esse material integra os insumos oferecidos para o tratamento e está disponível nas unidades de saúde do SUS.

---

<!-- METADADOS: doenca: Tabagismo | secao: **7.2.2. Associação dos tratamentos não medicamentosos e medicamentosos** -->
A associação entre o aconselhamento estruturado/abordagem intensiva e a farmacoterapia é indicada para tratar a dependência à nicotina. A associação das duas formas de tratamento é mais eficaz do que somente o aconselhamento estruturado/abordagem intensiva ou a farmacoterapia isolada.  
No entanto, o aconselhamento estruturado/abordagem intensiva isolada é, preferencialmente, preconizado em pacientes que apresentem uma ou mais das características abaixo:  
- relato de ausência de sintomas de abstinência;  
- nº de cigarros consumidos diariamente igual ou inferior a 5;  
- consumo do primeiro cigarro do dia igual ou superior a 1 hora após acordar (*);  
- pontuação no teste de Fagerström igual ou inferior a 4 (*).  
**(*)** Os critérios sobre o horário de consumo do primeiro cigarro do dia e a pontuação no teste de Fagerström foram debatidos e inseridos nesta Protocolo durante a realização do painel de especialistas, com base em suas práticas assistenciais.  
Além disso, independentemente da carga tabágica (número de cigarros/dia ou anos de tabagismo) e do grau de dependência à nicotina, a farmacoterapia não deve ser utilizada em pacientes que apresentem contraindicações clínicas ou por aqueles que optarem pelo não uso de medicamentos, mesmo após receberem esclarecimento adequado por parte do profissional da saúde que os acompanham.  
Com relação à farmacoterapia, o tratamento com Terapia de Reposição de Nicotina (TRN) pode combinar forma lenta (adesivo) e rápida (goma ou pastilha) de liberação de nicotina, sendo o tratamento preferencial por sua maior eficácia.  
Podem ser oferecidas como opções terapêuticas à TRN combinada: bupropiona isolada, TRN isolada (adesivo, goma ou pastilha) ou bupropiona associada a uma TRN isolada.  
Em casos de pacientes com contraindicação ao uso de TRN, ou paciente com transtornos psiquiátricos como depressão e esquizofrenia, a indicação de bupropiona deve ser considerada, sendo para isso, necessária a avaliação por profissional médico, preferencialmente um especialista em saúde mental.  
A TRN isolada é indicada no caso de contraindicação do uso de uma das formas de liberação da nicotina e impossibilidade do uso de bupropiona.  
Em casos de falha terapêutica, o novo tratamento deve ser definido considerando os motivos da falha, como, por exemplo, eventos adversos da terapia ou dificuldade de adesão ao(s) medicamento(s).  
As possibilidades de tratamento medicamentoso devem sempre ser precedidas pela avaliação individual e cuidadosa do paciente, pois somente mediante o conhecimento das características de seu quadro clínico e da dependência à nicotina será possível ao profissional da saúde a escolha do fármaco que potencializará as chances de cessação do tabagismo pelo paciente ou da contraindicação ao uso do fármaco selecionado.

---

<!-- METADADOS: doenca: Tabagismo | secao: **7.3. Fármacos** -->
- Cloridrato de bupropiona: comprimido de 150 mg (liberação prolongada);  
- Nicotina (de liberação lenta): adesivo de 7, 14 e 21 mg (uso transdérmico); e  
• Nicotina (de liberação rápida): goma de mascar de 2 mg e pastilha de 2mg.

---

<!-- METADADOS: doenca: Tabagismo | secao: **7.4. Fluxograma de tratamento** -->
O tratamento tem o seu fluxograma mostrado na **Figura 1** .

---

<!-- METADADOS: doenca: Tabagismo | secao: **7.5. Esquemas de administração** -->
Na **Tabela 1** , encontram-se os esquemas de administração dos medicamentos preconizados nesre Protocolo para o tratamento da dependência à nicotina.

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.5.1. Terapia de reposição de nicotina combinada (CTRN) -->
Importante destacar que a TRN, seja isolada ou em combinação, só deve ser iniciada na data em que o paciente deixar de fumar. A TRN não deve ser usada de forma concomitante com o cigarro ou outros derivados de tabaco.  
As combinações de adesivo + goma ou pastilha de nicotina podem ser feitas de acordo com o esquema de uso do adesivo descrito a seguir, sendo a goma ou pastilha utilizada para o controle da fissura ou em casos de consumo de até 5 cigarros/dia.

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.5.2. Adesivos de nicotina (transdérmico): -->
- A reposição de nicotina deve considerar 1 mg de nicotina para cada cigarro  
fumado.  
- Não se deve ultrapassar a dose de 42 mg/dia.  
- A dose inicial de reposição de nicotina, para efeito de cálculo deve  
considerar:  
a) Até 5 cigarros/dia: Não é indicado o uso de adesivo. Iniciar com goma ou pastilha, não ultrapassar 5 gomas/pastilhas de 2 mg ou 3 gomas/pastilhas de 4 mg.  
- b) De 6 a 10 cigarros/dia: iniciar com adesivo de 7 mg/dia.  
- c) De 11 a 19 cigarros/dia: iniciar com adesivo de 14 mg/dia  
d) Vinte (20) ou mais cigarros/dia: iniciar com adesivo de 21 mg/dia.

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.5.3. Associação de adesivos -->
- Os tabagistas que fumam mais de 20 cigarros/dia, e que apresentam  
- dificuldade para reduzir o número de cigarros, mas que estão motivados a parar de fumar, são candidatos ao uso associado de adesivos.  
- As combinações podem ser feitas de acordo com a quantidade de cigarros  
- fumados e a intensidade dos sintomas de abstinência a nicotina:  
a) Fuma mais de 40 cigarros por dia: 21mg + 21mg/dia.  
b) Fuma acima de 30 a 40 cigarros por dia: 21mg +14mg/dia.  
c) Fuma acima de 20 a 30 cigarros por dia: 21mg + 7mg/dia.  
- A redução das doses associadas de adesivos deve ser paulatina. Preconiza-se a retirada de 7 mg a cada semana, avaliada pela intensidade dos sintomas de síndrome de abstinência.

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.5.4. Cloridrato de bupropiona -->
- Pacientes idosos podem ser mais sensíveis ao tratamento com cloridrato de bupropiona. O médico deve avaliar a necessidade e, nesse caso, prescrever dose única diária matinal (após o desjejum) de 150 mg.  
- Para pacientes com quadros de insuficiência renal crônica ou hepatopatia crônica é aconselhável reduzir a dose para 150mg/dia, em razão da maior biodisponibilidade do medicamento.  
- Para pacientes que pararam de fumar com o uso de bupropiona e que não apresentem síndrome de abstinência, a critério médico, pode ser mantida dose única diária matinal (após o desjejum) de 150 mg.  
- O trabalhador noturno deve tomar o primeiro comprimido de bupropiona no horário em que desperta (após o desjejum).  
- Pessoas que sintam desconforto gástrico ou relatem história recente de gastrite devem tomar o comprimido de bupropiona após a alimentação.

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.6.1. Adesivo de nicotina (transdérmico): -->
- Prurido, exantema, eritema, cefaleia, tontura, náusea, vômitos, dispepsia, distúrbios do sono (sonhos incomuns e insônia), tremores e palpitações, sendo os dois últimos mais observados quando em dose excessiva de nicotina (61).  
- Pode ocorrer irritação na pele durante o uso do adesivo (decorrente da cola). Esta reação pode ser minimizada com o uso de creme de corticoide, na noite anterior e no dia seguinte ao da aplicação, no local onde o adesivo será aplicado.  
- No caso de reação cutânea, o paciente deve ser orientado a fazer limpeza  
(com água e sabão) e secar bem o local antes da aplicação, para retirar algum resíduo do creme.

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.6.2. Goma e pastilha de nicotina: -->
- Tosse, soluços, irritação na garganta, estomatite, boca seca, diminuição ou perda do paladar, parestesia, indigestão, flatulência desconforto digestivo, dor abdominal.  
- Os soluços são mais observados com o uso das pastilha.

---

<!-- METADADOS: doenca: Tabagismo | secao: <u>7.6.3. Cloridrato de bupropiona</u> -->
- Boca seca, insônia, dor de cabeça, náusea, tontura, depressão, ansiedade, pânico, dor torácica, reações alérgicas, desorientação e perda de apetite (35).  
- Risco de convulsão: 1:1.000 pessoas que tomam a dose máxima diária recomendada (300 mg).

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.7.1. Terapia de Reposição de Nicotina (TRN) -->
A TRN é bem tolerada nos pacientes cardiopatas crônicos estáveis, não aumentando a gravidade da cardiopatia. Nos eventos agudos, como no infarto agudo do miocárdio (IAM), deve- se evitar a TRN nas primeiras duas semanas do evento, pelo risco aumentado de arritmias causado pelo estímulo adrenérgico da nicotina (61).  
Entretanto, na prática assistencial, há pacientes com eventos cardiovasculares agudos, que podem se beneficiar do uso antecipado da TRN na forma de adesivo de nicotina. Para tanto, esses indivíduos devem ser avaliados pelo médico assistente quanto ao quadro clínico cardiovascular estável, principalmente quando existir risco real de tabagismo entre esses pacientes. Essa decisão deverá considerar os riscos e benefícios do uso da TRN antes dos 15 dias após evento agudo.  
Além disso, deve-se ajustar a dose da TRN, ou mesmo suspender o tratamento, caso ocorra algum efeito colateral relevante (26,61).

---

<!-- METADADOS: doenca: Tabagismo | secao: <u>Contraindicações específicas</u> -->
- Adesivo de nicotina (transdérmico): História recente de IAM (nos últimos 15 dias), arritmias cardíacas graves (fibrilação atrial), _angina pectoris_ instável, doença vascular isquêmica periférica, úlcera péptica, doenças cutâneas, gravidez e lactação (61).  
- Goma de nicotina: Incapacidade de mascar, lesões na mucosa bucal, úlcera péptica, sub-luxação na articulação temporomandibular (ATM) e uso de próteses dentárias móveis.  
- <u>Pastilha de nicotina: Lesões na mucosa bucal, úlcera péptica, uso de</u> próteses dentárias móveis e edema de corda vocal (edema de Reinke).

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.7.2. Cloridrato de bupropiona -->
As ontraindicações absolutas para o uso de bupropiona são: epilepsia, convulsão febril na infância, tumor do sistema nervoso central, histórico de traumatismo crânio-encefálico, anormalidades no eletroencefalograma e uso concomitante de inibidor da enzima monoamino-oxidase (IMAO) como o são os medicamentos selegilina, fenelzina, tranicilpromina e isocarboxazida.  
Caso o paciente faça ou tenha feito uso de IMAO, deve ser observado um período de 15 dias a partir da suspensão para poder iniciar a bupropiona, em razão do aumento do risco de crise convulsiva.  
Além disso, o cloridrato de bupropiona pode apresentar interações medicamentosas com os seguintes medicamentos: carbamazepina, barbitúricos, fenitoína, antipsicóticos, corticoides e hipoglicemiantes (26).

---

<!-- METADADOS: doenca: Tabagismo | secao: 7.7.3. <u>Medidas auxiliares</u> -->
Algumas medidas podem ser utilizadas para auxiliar o tratamento do tabagismo em virtude de terem boa abrangência e baixo custo.  
Canais telefônicos de suporte ao tratamento de dependência à nicotina aumentam a cessação do tabagismo. Três ou mais contatos telefônicos melhoram as chances de cessação, quando comparadas a intervenção mínima ou aconselhamento breve,  
materiais de autoajuda e farmacoterapia isolada (62). No Brasil, dispõe-se o telefone 136 – Disque Saúde –, que orienta sobre a cessação do tabagismo.  
Materiais impressos de autoajuda apresentam um pequeno efeito positivo na cessação, quando comparados a nenhuma intervenção. Entretanto, não foram encontradas evidências de benefício adicional quando utilizados em associação a outras intervenções, como aconselhamento com profissional da saúde ou de farmacoterapia (TRN) (63).  
7.7.4. Práticas integrativas e complementares em saúde  
Práticas Integrativas e Complementares em Saúde (PICS) são tratamentos que utilizam recursos terapêuticos baseados em conhecimentos tradicionais. Atualmente, o SUS oferece, de forma integral e gratuita, 29 procedimentos de PICS à população, entre eles acupuntura, aromaterapia, cromoterapia, dança circular, hipnoterapia, homeopatia e meditação, entre outras.  
Para o tratamento do tabagismo, a acupuntura, hipnoterapia e meditação _mindfulness_ não apresentaram evidências de eficácia, quando comparadas às terapias comportamentais, TRN ou nenhuma intervenção (64-66).  
As PICS são intervenções populares e seguras, quando utilizadas de forma adequada por profissionais capacitados. Entretanto, não devem ser utilizadas de forma isolada, mas quando disponível e de interesse do paciente, como alternativa complementar ao tratamento do tabagismo preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Tabagismo | secao: **8. MONITORIZAÇÃO** -->
A monitorização do tratamento do tabagismo deve ser feita pelas unidades de saúde que ofertam esse tratamento, por meio do registro do número de pacientes atendidos, de sua situação em relação ao uso do tabaco a cada consulta e, ainda, o registro de abandono de tratamento até que se completem os 12 meses preconizados. O desfecho é avaliado por meio do relato pelos pacientes quanto à abstinência de produtos com nicotina. Deste modo, torna-se possível a criação de indicadores de cessação do uso e de adesão ou abandono do tratamento que auxiliam a sua monitorização e avaliação, nos diferentes níveis de atenção do SUS.  
O tratamento do tabagismo pode ser iniciado em qualquer nível de atenção à saúde, sendo preferencialmente na Atenção Primária à Saúde (APS). Ao término do tratamento, caso seja alcançada a abstinência, recomenda-se que o paciente seja acompanhado por até um ano para o apoio na manutenção deste quadro.  
No caso de recaída, deve-se reavaliar o tratamento feito anteriormente e decidir em conjunto como proceder em relação ao retratamento. Sugere-se ainda a busca ativa de pacientes que tenham abandonado o tratamento.  
Os possíveis efeitos adversos pelo uso dos medicamentos, já relatados, devem ser acompanhados pelo profissional da saúde responsável pelo atendimento, que irá decidir sobre a melhor conduta a ser adotada em cada caso, fazendo, quando necessário, encaminhamentos para outros profissionais ou unidades de saúde.  
A abstinência tabágica é o desfecho pretendido no programa de tratamento do tabagismo desenvolvido nas unidades de saúde, tendo como eixo central, intervenções cognitivas e treinamento de habilidades comportamentais, visando não só à cessação mas também a prevenção de recaída. No entanto, o monitoramento dos resultados dessa ação contemplada no SUS deve fundamentalmente levar em consideração os aspectos que caracterizam essa doença crônica como é o caso da dependência química, ou seja, o estado de abstinência fisiológica, o qual, mediante a suspensão do produto, evidenciará síndrome de abstinência e necessidade de consumo da substância com intenção de aliviar ou evitar sintomas de abstinência (critérios diagnósticos).  
Assim é que, dada às características da doença, e segundo a literatura, as tentativas podem somar cinco ou mais vezes com a não resposta ao desfecho pretendido (abandono do vício) ou recaídas, até que a abstinência seja de fato alcançada. Portanto, não será adequado condicionar a resposta terapêutica com uso do aconselhamento isolado ou acompanhado de medicamento ao imediato sucesso na cessação, ou reversão do quadro de dependência tabágica, desconsiderando que dificuldades em cessar o uso é um dos itens que compõem o diagnóstico de dependência.

---

<!-- METADADOS: doenca: Tabagismo | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
O tratamento do tabagismo pode ser realizado em qualquer nível de atenção do SUS. Ressalta- se que, por sua capilaridade, a rede de Atenção Primária à Saúde (APS) permite um maior alcance territorial e, por conseguinte, populacional.  
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Os manuais técnicos das sessões de tratamento e o medicamento devem estar disponíveis nas unidades de saúde que já ofertem ou se interessem por ofertar o tratamento.  
_Ressalta-se que para o medicamento cloridrato de bupropiona, há a necessidade de prescrição médica e guarda e dispensação sob responsabilidade de profissional farmacêutico, conforme preconiza a Portaria SVS n.º 344, de 12 de maio de 1998 – Regulamento Ttécnico sobre substâncias e medicamentos sujeitos a controle especial._  
Destaca-se, ainda, que o uso da terapia medicamentosa pressupõe, como já mencionado anteriormente, a participação em sessões estruturadas com acompanhamento de profissional da saúde.  
Para o alcance dos objetivos, é fundamental a capacitação e participação de profissionais da saúde de nível superior (médico, enfermeiro, psicólogo, nutricionista, farmacêutico, fisioterapeuta, assistente social, educador físico, terapeuta ocupacional, odontólogo OU fonoaudiólogo) que procederão ao tratamento do tabagismo nas unidades de saúde prestadoras do SUS, tendo como referencial o modelo terapêutico do tabagismo do Programa Nacional de Controle do Tabagismo. Historicamente, essa tem sido uma demanda trazida pelos próprios profissionais e gestores da saúde, dada a ausência desta formação na maioria dos cursos de graduação. Os profissionais da saúde de nível médio, como o Agente Comunitário de Saúde, podem apoiar as ações para a cessação do tabagismo no que diz respeito a busca ativa de pacientes que tenham abandonado o tratamento ou sensibilização de fumantes para que parem de fumar e busquem tratamento na unidade de saúde.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição, dispensação e administração do  
medicamento e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Tabagismo | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Tabagismo | secao: **11. REFERÊNCIAS** -->
1. WHO Global Report on Trends in Prevalence of Tobacco Smoking 2000–2025, second edition. Geneva: World Health Organization, 2018. Available from: <u>https://apps.who.int/iris/bitstream/handle/10665/272694/9789241514170-eng.pdf?ua=1</u>  
2. WHO Fact Sheet on tuberculosis and tobacco 2009. Available  From: <u>https://www.who.int/tobacco/publications/health_effects/fact_sheet_tb_tobacco/en/</u>  
3. WHO Report on the Global Tobacco Epidemic, 2019: Offer help to quit tobacco use. Available from: https://apps.who.int/iris/bitstream/handle/10665/326043/9789241516204- <u>eng.pdf?ua=1</u>  
4. BRASIL. Ministério da Saúde. Instituto Nacional de Câncer José de Alencar Gomes da Silva. Programa Nacional de Controle do Tabagismo. Rio de Janeiro: INCA, 2019.  
5. BRASIL. Ministério da Saúde. Instituto Nacional de Câncer José de Alencar Gomes da Silva. Convenção-Quadro para Controle do Tabaco: texto oficial. 2. reimpr. Rio de Janeiro: INCA, 2015. p. 59.  
6. Rangel, E. C. Enfrentamento do controle do tabagismo no Brasil: o papel das audiências públicas no Senado Federal na ratificação da Convenção-Quadro para o controle do tabaco (2004/2005). ENSP/FIOCRUZ; 2011.  
7. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Análise em Saúde e Vigilância de Doenças não Transmissíveis. Vigitel Brasil 2018: vigilância de fatores de risco e proteção para doenças crônicas por inquérito telefônico: estimativas sobre frequência e distribuição sociodemográfica de fatores de risco e proteção para doenças crônicas nas capitais dos 26 estados brasileiros e no Distrito Federal em 2018. Brasília: Ministério da Saúde, 2019. 132.: il.  
8. Szklo AS, de Souza MC, Szklo M, de Almeida LM. Smokers in Brazil: who are they? Tob Control. 2016;25(5):564-70.  
9. BRASIL. Ministério da Saúde. Instituto Nacional de Câncer José Alencar Gomes da Silva. Diretrizes para Implementação do Artigo 14 da Convenção-Quadro da Organização Mundial da Saúde para o Controle do Tabaco – Medidas de redução de demanda relativas à dependência e à cessação do consumo do tabaco. Rio de Janeiro: 2016.  
10. BRASIL. Ministério da Saúde. Gabinete do Ministro. Portaria nº 1.575, de 29 de agosto de 2002. Consolida o Programa Nacional de Controle do Tabagismo. Diário Oficial da União, Brasília, DF, 3 set. 2002. p. 42.  
11. BRASIL. Ministério da Saúde. Gabinete do Ministro. Portaria nº 1.035, de 31 de maio de 2004. Amplia o acesso à abordagem e tratamento do tabagismo para a rede de atenção básica e de média complexidade do Sistema Único de Saúde – SUS. Diário Oficial da  
União, Brasília, DF, 1 jun. 2004. p. 24.  
12. BRASIL. Ministério da Saúde. Secretaria de Atenção à Saúde. Portaria nº 442, de 13 de agosto de 2004.Aprova, na forma do Anexo I desta Portaria, o Plano para Implantação da Abordagem e Tratamento do Tabagismo no Sistema Único de Saúde – SUS. Diário Oficial da União, Brasília, DF, 17 ago. 2004. p. 62.  
13. BRASIL. Lei n° 12.401. Altera a Lei no 8.080, de 19 de setembro de 1990, para dispor sobre a assistência terapêutica e a incorporação de tecnologia em saúde no âmbito do Sistema Único de Saúde - SUS. . 28 abr. 2011, Sec. 1, p. 80–81.  
14. BRASIL. Ministério da Saúde. Gabinete do Ministro. Portaria nº 571, de 5 de abril de 2013. Atualiza as diretrizes de cuidado à pessoa tabagista no âmbito da Rede de Atenção à Saúde das Pessoas com Doenças Crônicas do Sistema Único de Saúde (SUS) e dá outras providências. Diário Oficial da União, Brasília, DF, 8 abr. 2013. p. 56.  
15. BRASIL. Ministério da Saúde. Secretaria de Atenção à Saúde. Portaria nº 761, de 21 de junho de 2016. Valida as orientações técnicas do tratamento do tabagismo constantes no Protocolo Clínico e Diretrizes Terapêuticas - Dependência à Nicotina. Diário Oficial da União, Brasília, DF, 22 jun. 2016. p. 68  
16. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas. Brasília: Ministério da Saúde, 2016. 96 p. il.  
17. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. Brasília: Ministério da Saúde, 2014. 72 p.: il.  
18. Schünemann HJ, Brożek J, Guyatt GH, Oxman AD, editors. GRADE Working Group. GRADE handbook for grading quality of evidence and strength of recommendations. Updated October 2013. Available from: <u>https://gdt.gradepro.org/app/handbook/handbook.html</u>  
19. GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. McMaster University, 2015 (developed by Evidence Prime, Inc.) Available from: <u>https://gradepro.org/</u>  
20. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância de Doenças e Agravos Não Transmissíveis e Promoção da Saúde. Saúde Brasil 2017: uma análise da situação de saúde e os desafios para o alcance dos objetivos de desenvolvimento sustentável [recurso eletrônico]. Brasília: Ministério da Saúde, 2018. 426 p.:il.  
21. Núcleo Einstein de Álcool e Drogas do Hospital Israelita Albert Einstein - NEAD. Álcool e Drogas sem Distorção [Internet]. 2002. Available from: <u>www.einstein.br/alcooledrogas</u>  
22. Organização Mundial de Saúde - OMS. Neurociência do uso e da dependência de substâncias psicoativas [tradução Fábio Corregiari]. São Paulo: Roca; 2006. Disponível em: <u>https://extranet.who.int/iris/restricted/bitstream/10665/42666/2/9788572416665_por.pdf</u>  
23. Perkins KA. Chronic tolerance to nicotine in humans and its relationship to tobacco dependence. Nicotine Tob Res Off J Soc Res Nicotine Tob. 2002 Nov;4(4):405–22.  
24. McCrady BS, Epstein EE. Addictions: A Comprehensive Guidebook. 1 edition. New York: Oxford University Press; 1999. 672 p.  
25. CID-10. Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde. 10a rev. Centro Colaborador da Organização Mundial de Saúde para a Classificação de Doenças em Português. São Paulo: Faculdade de Saúde Pública. Universidade de São Paulo; 1997. Disponível em: <u>http://www.datasus.gov.br/cid10/V2008/cid10.htm</u>  
26. Reichert J, de Araújo AJ, Gonçalves CMC, Godoy I, Chatkin JM, Sales MPU et al. Diretrizes para cessação do tabagismo. J Bras Pneumol. 2008;34(10):845–80. 27. Gourlay SG, Forbes A, Marriner T, Pethica D, McNeil JJ. Double blind trial of repeated treatment with transdermal nicotine for relapsed smokers. BMJ. 1995 Aug 5; 311(7001): 363–66.  
28. Gonzales DH, Nides MA, Ferry LH, Kustra RP, Jamerson BD, Segall N et al. Bupropion SR as an aid to smoking cessation in smokers treated previously with bupropion: a randomized placebo-controlled study. Clin Pharmacol Ther. 2001 Jun;69(6):438-44.  
29. Shiffman S, Dresler CM, Rohay JM. Successful treatment with a nicotine lozenge of smokers with prior failure in pharmacological therapy. Addiction. 2004 Jan;99(1):83-92.  
30. Fanshawe TR, Halliwell W, Lindson N, Aveyard P, Livingstone-Banks J, HartmannBoyce J. Tobacco cessation interventions for young people. Cochrane Database Syst Rev. 2017 Nov 17;11:CD003289.  
31. Chamberlain C, O'Mara-Eves A, Porter J, Coleman T, Perlen SM, Thomas J et al. Psychosocial interventions for supporting women to stop smoking in pregnancy. Cochrane Database of Systematic Reviews. 2017, Issue 2. Art. No.: CD001055.  
32. Coleman T, Chamberlain C, Davey MA, Cooper SE, Leonardi-Bee J. Pharmacological interventions for promoting smoking cessation during pregnancy. Cochrane Database of Systematic Reviews. 2015, Issue 12. Art. No.: CD010078.  
33. Chen D, Wu LT. Smoking cessation interventions for adults aged 50 or older: A systematic review and meta-analysis. Drug Alcohol Depend. 2015 Sep 1;154:14-24. 34. Appel DW, Aldrich TK. Smoking cessation in the elderly. Clin Geriatr Med. 2003;19(1):77-100.  
35. Fiore M, Jaén C, Baker T, Bailey WC, Benowitz NL, Curry SJ et al. Treating Tobacco Use and Dependence: 2008 Update. Rockville, MD: 2008. Available from: <u>https://www.ncbi.nlm.nih.gov/books/NBK63952/</u>  
36. Ossip-Klein DJ, Pearson TA, McIntosh S, Orleans CT. Smoking is a geriatric health issue. Nicotine Tob Res. 1999;1(4):299–300.  
37. Wen CP, Chan TC, Chan HT, Tsai MK, Cheng TY, Tsai SP. The reduction of tuberculosis risks by smoking cessation. BMC Infectious Diseases 2010, 10:156-65.  
38. WHO. The Union monograph on TB and tobacco control: joining efforts to control two related global epidemics 2007. Available from: <u>https://www.who.int/tobacco/resources/publications/tb_tobac_monograph.pdf</u>  
39. Racil H, Amar JB, Cheikrouhou S, Hassine E, Zarrouk M, Chaouch N et al. Pulmonary tuberculosis in smokers. Presse Med. 2010, 39(2):25-8.  
40. Aryanpur M, Hosseini M, Masjedi MR, Mortaz E, Tabarsi P, Soori H et al. A randomized controlled trial of smoking cessation methods in patients newly diagnosed with pulmonary tuberculosis. BMC Infect Dis. 2016 Aug 5;16:369  
41. National Comprehensive Cancer Network: NCCN Clinical Practice Guidelines in Oncology (NCCN Guidelines®) Smoking Cessation Version 1. 2017.  
42. Nayan S, Gupta MK, Strychowsky JE, Sommer DD. Smoking cessation interventions and cessation rates in the oncology population: an updated systematic review and metaanalysis. Otolaryngol Head Neck Surg. 2013 Aug;149(2):200-11.  
43. Klemp I, Steffenssen M, Bakholdt V, Thygesen T, Sorensen JA. Counseling Is Effective for Smoking Cessation in Head and Neck Cancer Patients-A Systematic Review and Meta-Analysis. J Oral Maxillofac Surg. 2016 Aug;74(8):1687-94.  
44. Apollonio D, Philipps R, Bero L. Interventions for tobacco use cessation in people in treatment for or recovery from substance use disorders. Cochrane Database of Systematic Reviews. 2016, Issue 11. Art. No.: CD010274.  
45. van der Meer RM, Willemsen MC, Smit F, Cuijpers P. Smoking cessation interventions for smokers with current or past depression. Cochrane Database of Systematic Reviews. 2013, Issue 8. Art. No.: CD006102.  
46. Tsoi DT, Porwal M, Webster AC. Interventions for smoking cessation and reduction  
in individuals with schizophrenia. Cochrane Database of Systematic Reviews. 2013, Issue 2. Art. No.: CD007253.  
47. Rigotti NA, Clair C, Munafò MR, Stead LF. Interventions for smoking cessation in hospitalized patients. Cochrane Database of Systematic Reviews. 2012, Issue 5. Art. No.: CD001837.  
48. Andrade D, Kinner SA. Systematic review of health and behavioral outcomes of smoking cessation interventions in prisons. Tob Control. 2016;26(5):495-501.  
49. Djachenko A, St John W, Mitchell C. Smoking cessation in male prisoners: a literature review. Int J Prison Health. 2015;11(1):39-48.  
50. BRASIL. Ministério da Saúde. Instituto Nacional de Câncer. Coordenação de Prevenção e Vigilância. Abordagem e Tratamento do Fumante. Consenso. Rio de Janeiro: INCA, 2001. 38p. il.  
51. Vangeli E, Stapleton J, Smit ES, Borland R, West R. Predictors of attempts to stop smoking and their success in adult general population samples: a systematic review. Addiction. 2011;106(12):2110-21.  
52. Pawlina MMC, Rondina RDC, Espinosa MM, Botelho C. Ansiedade e baixo nível motivacional associados ao fracasso na cessação do tabagismo. J Bras Psiquiatr. 2014;63(2):113-20.  
53. França SAS, das Neves ALF, de Souza TAS, Martins NCN, Carneiro SR, Sarges ESNF et al. Factors associated with smoking cessation. Rev Saude Publica. 2015;49:1-8.  
54. Varela DMVL, Anido T, Ravira M, Goja B, Tubino M, Alfonso G et al. Factores asociados con la abstinencia y eficacia de un programa de cesación de tabaquismo. Rev Med Urug. 2007;23(1):25- 33.  
55. Sattler AC, Cade NV. Prevalência da abstinência ao tabaco de pacientes tratados em unidades de saúde e fatores relacionados. Ciênc. Saúde Coletiva. 2013;18(1):253-64.  
56. Peña P, Navarrete S, Acuña M, Bertoglia MP, Cavada G, Suárez C, et al. Resultados de un programa multidisciplinario para el control del hábito tabáquico. Rev Med Chil. 2013;141(3):345-52.  
57. Azevedo RCS, Higa CMH, de Assumpção ISMA, Frazatto CRG, Fernandes RF, Goulart W et al. Grupo terapêutico para tabagistas: resultados após seguimento de dois anos. Rev Assoc Med Bras. 2009;55(5):593-6.  
58. Tejada CAO, Ewerling F, Santos AMA, Bertoldi AD, Menezes AM. Factors associated with smoking cessation in Brazil. Cad Saude Publica. 2013;29(8):1555-64.  
59. Azevedo RCS, Fernandes RF. Factors relating to failure to quit smoking: a prospective cohort study. São Paulo Med J. 2011;129(6):380-86.  
60. Tamblay N, Seijas D. Factores determinantes en el éxito de un tratamiento antitabaco. Rev Med Chil. 2008;136(2):179-85.  
61. Oliveira GMM, Mendes M, Dutra OP, Achutt A, Fernandes M, Azevedo V et al. 2019: Recomendações para a redução do consumo de tabaco nos países de língua portuguesa - Posicionamento da Federação das Sociedades de Cardiologia da Língua Portuguesa. Arq Bras Cardiol. 2019;112 (4):477- 86.  
62. Stead LF, Hartmann-Boyce J, Perera R, Lancaster T. Telephone counselling for smoking cessation. Cochrane Database of Systematic Reviews 2013, Issue 8. Art. No.: CD002850.  
63. Hartmann-Boyce J, Lancaster T, Stead LF. Print-based self-help interventions for smoking cessation. Cochrane Database of Systematic Reviews 2014, Issue 6. Art. No.: CD001118.  
64. Barnes J, McRobbie H, Dong CY, Walker N, Hartmann-Boyce J. Hypnotherapy for smoking cessation. Cochrane Database of Systematic Reviews. 2019, Issue 6. Art. No.: CD001008.  
65. White AR, Rampes H, Liu JP, Stead LF, Campbell J. Acupuncture and related interventions for smoking cessation. Cochrane Database of Systematic Reviews. 2014, Issue 1. Art. No.: CD000009.  
66. Maglione MA, Maher AR, Ewing B, Colaiaco B, Newberry S, Kandrack R et al. Efficacy of mindfulness meditation for smoking cessation: A systematic review and metaanalysis. Addict Behav. 2017Jun;69:2734.  
67. BRASIL. Ministério da Saúde. Agência Nacional de Vigilância Sanitária. Bulário eletrônico. Disponível em: http://www.anvisa.gov.br/datavisa/fila_bula/index.asp  
68. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde. Departamento de Assistência Farmacêutica e Insumos Estratégicos. Relação Nacional de Medicamentos Essenciais: RENAME 2020 [recurso eletrônico]. Brasília: Ministério da Saúde, 2019. 217 p. Disponível em: <u>https://bvsms.saude.gov.br/bvs/publicacoes/relacao_medicamentos_rename_2020.pdf</u>

---

<!-- METADADOS: doenca: Tabagismo | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ADESIVO DE NICOTINA E CLORIDRATO DE BUPROPIONA  
Eu, __________________________________ (nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre os benefícios, riscos, contra-indicações e principais efeitos adversos relacionados ao uso do(s) medicamento(s) **adesivo de nicotina e cloridrato de bupropiona.**  
Os termos médicos foram explicados e todas as minhas dúvidas foram  
resolvidas pelo médico _____________________________________________________________  (nome do  
médico que prescreve).  
Assim declaro que:  
Fui claramente informado(a) que o tratamento medicamentoso do tabagismo deve ser utilizado em complementação da terapia cognitivo-comportamental e que o(s) medicamento(s) que passo a receber pode trazer as **seguintes melhorias** :  
- ajuda-me a deixar de fumar, com o que aumento a minha expectativa de vida e melhoro a minha saúde e a qualidade da minha vida; e  
- alívia os sintomas da abstinência.  
Fui também claramente informado(a) que são as seguintes **contraindicações, potenciais efeitos adversos e riscos** :  
- gestantes e nutrizes devem tentar parar de fumar sem utilizar nenhum tratamento medicamentoso, portanto, se caso engravidar, devo avisar imediatamente o médico;  
- os efeitos adversos mais comumente relatados para os medicamentos são:  
- **para a nicotina em adesivo:** Prurido (coceira), exantema ou <mark>rash cutâneo (erupções cutâneas vermelhas)</mark> , eritema (rubor cutâneo), dor de cabeça, tontura, náusea, vômitos, dispepsia, distúrbios do sono (sonhos incomuns e insônia), tremores e palpitações, sendo os dois últimos mais observados com dose excessiva de nicotina. Pode ocorrer irritação na pele durante o uso do adesivo (decorrente da cola), reação esta que pode ser minimizada com o uso de creme de corticoide no local onde o adesivo será aplicado, na noite anterior e no dia seguinte à aplicação. Em isso ocorrendo, devo limpar o local (com água e sabão) e secar bem o local antes da aplicação do adesivo, para retirar algum resíduo do creme.  
- **para a nicotina em goma ou pastilha:** Tosse, soluços, irritação na garganta, estomatite, boca seca, diminuição ou perda do paladar, parestesia, indigestão,  
flatulência desconforto digestivo, dor abdominal. Os soluços são mais observados com o uso das pastilha.  
- **para a bupropiona:** Boca seca, insônia, dor de cabeça, náusea, tontura, depressão, ansiedade/pânico, dor torácica, reações alérgicas, desorientação e perda de apetite. O risco de convulsão de 1:1000 pessoas que tomam a dose máxima diária recomendada (300 mg).  
- os medicamentos estão contraindicados em caso de hipersensibilidade  
(alergia) aos fármacos;  
- o risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que o(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvê-lo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido, inclusive em caso de eu desistir de usar o medicamento.  
Meu tratamento constará do seguinte medicamento:  
- (   ) adesivo de nicotina  
- (   ) cloridrato de bupropiona  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (  ) Sim    (  ) Não  
<!-- Start of picture text -->
Local:                                                                                                                         Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico Responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do prescritor<br>Data:____________________<br><!-- End of picture text -->  
**<mark>Nota</mark>** <mark>: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.</mark>  
<!-- Start of picture text -->
Abordagem breve a todo ususrio fumante atendido pelo SUS por<br>qualquer profissional de satide.<br><Ouer narar de fumar?><br>sim Nao<br>Deve continuar sendo<br>Em caso de nao indicacao de uso do Abordagem estruturada + Terapia Em caso de impossibilidade aconselhado a cada<br>\conselhamento estruturado isolado Combinadai ((CTRN| ) .Ss ~~.»| Bupropiona;. Bupropiona:  e profissional de saudeui<br>TRN; TRN isolada<br>Ver critérios no item 8.2<br>Paciente parou de fumar?> Paciente parou de fumar? - _---’<br>sim Nao<br>Manutencdo até Optar por uma das<br>sim Nao completar 1 ano (em caso alternativas abaixo<br>de recaida, refazer 0<br>Manutengo até Continuar o tratamento até tratamento - ver item 12)<br>completar 1 ano (em que seja alcangada a<br>caso de recaida, cessagao (reavaliar a<br>refazer~ver o item tratamento12) possibilidademedicamento). do uso de estruturadaAbordagem+ estruturadaAbordagem + estruturada‘Abordagem+ TRN estruturada‘Abordagem +<br>cTRN TRN isolada + Bupropiona Bupropiona<br>Se 0 paciente parar de fumar, ir para manutengdo até completar 1 ano. Se no, continuar o tratamento com uma das<br>opsdes acima, até que seja alcancada a cessagdo. Em caso de recaida, refazer o tratamento — ver item 12.<br><!-- End of picture text -->  
**Figura 1** – Fluxograma de Tratamento  
28  
**Tabela 1 -** Medicamentos para tratamento da dependência à nicotina  
|**Denominaçãogenérica**|**Forma de**<br>**apresentação**|**Posologia**|**Modo de usar**|
|---|---|---|---|
||Adesivos<br>transdérmicos7mg,<br>14mg e 21mg<br>(liberação lenta)<br>Gomas de<br>|Adesivos:<br>1ª a 4ª semana: adesivo de 21mg a cada 24<br>horas;<br>5ª a 8ª semana: adesivo de 14mg a cada 24<br>horas;<br>9ª a 12ª semana: adesivo de 7mg a cada 24<br>horas.<br>Essa posologia está condicionada ao<br>número de|Deve-se aplicar o adesivo pela manhã, em áreas cobertas (parte superior do tórax ou regiões anteriores, posteriores<br>e superiores laterais do braço). Fazer rodízio entre os locais e trocar na mesma hora do dia. Evitar exposição solar<br>no local.<br>Deve-se mascar a goma, sem parar, por 30 minutos, até o surgimento de um sabor forte ou uma leve sensação de<br>formigamento. Nesse momento, deve-se parar de mascar. A goma deve ser mantida entre a bochecha e a gengiva<br>por aproximadamente 2 minutos ou até que desapareça o sabor ou o formigamento (tempo necessário para<br>absorver a nicotina). Voltar a mascar lentamente a goma, repetindo o processo, por 30 minutos, para uma segunda<br>liberação de nicotina.|
|**Terapia de**<br>**Reposição de**<br>**Nicotina**<br>**Combinada**<br>**(CTRN)**|mascar 2mg<br>(liberação<br>rápida)<br>Pastilhas<br>2mg<br>(liberação<br>rápida)|cigarros fumados/dia.<br>Ver detalhamento no sub-item 7.5.<br>Gomas/pastilhas:<br>Uso indicado nos momentos de maior fissura.|Além disso, antes do uso da goma, é indicado ingerir um copo de água para neutralizar o pH bucal e para<br>remoção de resíduos alimentares.<br>Deve-se mover a pastilha, de um lado para o outro da boca, repetidamente, até dissolver, o que leva em torno de<br>20 a 30 minutos. A pastilha não deve ser partida, mastigada ou engolida inteira. Não se deve comer ou beber<br>enquanto estiver com a pastilha na boca.|
|||A boa prática clínica recomenda que<br>não se<br>ultrapasse a quantidade de 5<br>gomas/pastilhas<br>de 2mg/dia de<br>nicotina.||  
29  
|**Denominaçãogenérica**|**Forma de**<br>**apresentação**|**Posologia**|**Modo de usar**|
|---|---|---|---|
|||1º ao 3º dia de tratamento: 1 comprimido de<br>150mg pela manhã; 4º ao 84º dia de<br>tratamento: 1 comprimido de 150mg pela<br>manhã e outro de 150mg após oito horas da<br>primeira tomada.|Os comprimidos devem ser engolidos inteiros, não podem ser partidos, triturados e nem mastigados. Pois isso pode<br>aumentar a chance de eventos adversos, inclusive convulsões.<br>O intervalo de oito horas entre a 1<sup>a</sup>e a 2<sup>a</sup>dose deve ser respeitado. Recomenda-se não fazer uso da 2ª|
|**Cloridrato de**|Comprimido||dose após as 16 horas, pelo risco de insônia.|
|**Bupropiona**|150 mg|A dose máxima recomendada é de<br>300mg/dia de cloridrato de<br>bupropiona,<br>dividida em duas<br> tomadas de 150mg.|**Medicamento sujeito a prescrição médica e controle especial, conforme preconizado pela Portaria SVS**<br>**n.º 344, de 12 de maio de 1998.**|
||Adesivos<br>transdérmicos7mg,<br>14mg e|1ª a 4ª semana: adesivo de 21mg a cada 24<br>horas;<br>5ª a 8ª semana: adesivo de 14mg a cada 24<br>horas;<br>9ª a 12ª semana: adesivo de 7mg a cada 24<br>horas.|Deve-se aplicar o adesivo pela manhã, em áreas cobertas (parte superior do tórax ou<br>regiões anteriores, posteriores e superiores laterais do braço). Fazer rodízio entre os locais<br>e trocar na mesma hora do dia. Evitar exposição solar no local.|
|**Terapia de**<br>**Reposição de**|21mg<br>(liberaçãolenta)|Essa posologia está condicionada ao<br>número de<br>cigarros fumados/dia.<br>Ver detalhamento no 7.5.||
|**Nicotina**<br>**Isolada (TRN)**||||
||Goma de mascar<br>2mg (liberação<br>rápida)|1ª a 4ª semana: 1 goma de 2mg a cada 1 a<br>2 horas;<br>5ª a 8ª semana: 1 goma de 2mg a cada 2 a<br>4 horas;|Deve-se mascar a goma, sem parar, por 30 minutos, até o surgimento de um sabor forte ou uma leve sensação de<br>formigamento. Nesse momento, deve-se parar de mascar. A goma deve ser mantida entre a bochecha e a gengiva<br>por aproximadamente 2 minutos ou até que desapareça o sabor ou o formigamento (tempo necessário para<br>absorver a|  
30  
|**Denominaçãogenérica**|**Forma de**<br>**apresentação**|**Posologia**|**Modo de usar**|
|---|---|---|---|
|**Terapia de**<br>**Reposição de**<br>**Nicotina Isolada**<br>**(TRN)**||9ª a 12ª semana: 1 goma de 2 mg a cada 4 a<br>8 horas.<br>A quantidade máxima é de 15 gomas de 2mg de<br>nicotina/dia.|<br>nicotina). Voltar a mascar lentamente a goma, repetindo o processo, por 30 minutos, para uma segunda liberação de<br>nicotina.<br>Além disso, antes do uso da goma, é indicado ingerir um copo de água para neutralizar o pH bucal e para<br>remoção de resíduos alimentares.|
||Pastilha 2mg<br>(liberação rápida)|1ª a 4ª semana: 1 pastilha de 2mg a cada 1 a<br>2 horas;<br>5ª a 8ª semana: 1 pastilha de 2mg a cada 2 a<br>4 horas;<br>9ª a 12ª semana: 1 pastilha de 2 mg a cada 4<br>a 8 horas.|Deve-se mover a pastilha, de um lado para o outro da boca, repetidamente, até dissolver, o que leva em torno de 20 a<br>30 minutos. A pastilha não deve ser partida, mastigada ou engolida inteira. Não se deve comer ou beber enquanto<br>estiver com a pastilha na boca.|
|||A quantidade máxima é de 15 pastilhas de<br>2mg de nicotina/dia.||  
Fontes:  
- Portaria SAS / MS Nº 761, 21 de junho de 2016. Protocolo Clínico e Diretrizes Terapêuticas da Dependência à Nicotina (15).  
- Ministério da Saúde. ANVISA. Bulário Eletrônico (67).  
- Relação Nacional de Medicamentos Essenciais: RENAME 2020. SCTIE. DAF. Brasília: Ministério da Saúde, 2019 (68).  
- NCCN Clinical Practice Guidelines in Oncology Smoking Cessation, 2017 (40).  
31  
**APÊNDICE 1**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA  
Este Protocolo tem como público-alvo os profissionais da saúde envolvidos na atenção do paciente com dependência à nicotina, nos diferentes níveis do Sistema Único de Saúde (SUS), em especial os que atuam na Atenção Primária à Saúde (APS).  
Tabagistas em qualquer idade são a sua população-alvo.  
O Instituto Nacional de Câncer (INCA), do Ministério da Saúde, por meio de suas divisões de Controle do Tabagismo e de Pesquisa Populacional, coordenou o trabalho de elaboração deste PCDT em parceria com o Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos do Ministério da Saúde.  
Para compor o Comitê Gestor da elaboração do PCDT, foram convidados representantes das citadas divisões do INCA, da Coordenação-Geral de Atenção Especializada (CGAES/DAET/SAES/MS), da Coordenação-Geral de Garantia dos Atributos da Atenção Primária à Saúde (CGGA/DESF/SAPS/MS), da Coordenação-Geral do Componente Estratégico da Assistência Farmacêutica (CGCESAF/DAF/SCTIE), da Universidade Federal do Rio de Janeiro (UFRJ) e da Subcomissão Técnica de Avaliação de PCDT da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC).  
O Grupo Elaborador foi formado por equipe multidisciplinar, incluindo especialistas em tabagismo e metodologistas com _expertise_ em síntese de evidências, epidemiologia, saúde coletiva e avaliação de tecnologias em saúde, além de contar com profissionais bibliotecários.  
Os métodos utilizados na elaboração deste Protcolo seguiram as recomendações das Diretrizes Metodológicas: Diretrizes Clínicas (1), que estabelecem o uso das melhores e mais atuais evidências clínicas sobre eficácia, segurança, efetividade e acurácia das tecnologias avaliadas. Foi desenvolvida com base na metodologia GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ) (2). Também foram seguidas as orientações sobre o processo de síntese de evidências e de desenvolvimento de diretrizes, segundo princípios do _Institute of Medicine e do Guideline International Network_ para o desenvolvimento de diretrizes (3).  
32

---

<!-- METADADOS: doenca: Tabagismo | secao: **DEFINIÇÃO DO TÓPICO E ESTABELECIMENTO DAS QUESTÕES PICOS (População, Intervenção, Comparação e Desenho de Estudo)** -->
A definição do escopo e da primeira versão das questões de pesquisa foram estabelecidas em oficina, realizada em maio de 2017, com o Comitê Gestor e o Grupo Elaborador. Posteriormente, houve uma reestruturação para melhor adequação metodológica, em fevereiro de 2019, com consultores do Hospital Moinhos de Vento, com financiamento no âmbito do Programa de Apoio ao Desenvolvimento Institucional do SUS (PROADI-SUS).  
As questões de pesquisa foram estruturadas de acordo com o acrônimo PICOS, em que P é a população avaliada; I, a intervenção tecnológica; C, o comparador em relação à tecnologia avaliada; O (de _outcome_ ), os desfechos ou resultados observados; e S (de _study design_ ), o desenho de estudo.  
As questões definidas para este PCDT foram:  
1. O aconselhamento estruturado é mais eficaz que o aconselhamento breve ou cuidado usual para a cessação do tabagismo?  
2. O tratamento medicamentoso associado ao aconselhamento estruturado é mais eficaz que o aconselhamento estruturado isolado?  
3. O tratamento medicamentoso associado ao aconselhamento estruturado é mais eficaz que o tratamento medicamentoso isolado?  
4. O tratamento com TRN combinada é mais eficaz e seguro do que o tratamento com TRN isolada?  
5. O tratamento com bupropiona é mais eficaz e seguro do que o tratamento com TRN isolada?  
6. O tratamento com bupropiona associada a TRN isolada é mais eficaz e seguro do que o tratamento com TRN isolada?  
7. O tratamento com bupropiona é mais eficaz e seguro do que o tratamento com TRN combinada?  
Salienta-se que não foi considerada a vareniclina no tratamento do  
33  
tabagismo, visto ter sido este medicamento avaliado e não recomendado pela CONITEC, conforme o Relatório de Recomendação N<sup>o</sup> 468 – Julho de 2019 (4), e a Portaria N<sup>o</sup> 41/SCTIE/MS, de 24 de julho de 2019 (5), que não a incorporou ao SUS.

---

<!-- METADADOS: doenca: Tabagismo | secao: **Obtenção de evidências** -->
Inicialmente, foram realizadas buscas por Revisões Sistemáticas (RS), sendo que as estratégias foram desenvolvidas a partir dos conceitos centrais de cada pergunta PICOS. Foram utilizados termos padronizados (MeSH e DeCS) e palavraschaves definidos pela equipe de bibliotecários.  
As bases de dados consultadas foram: MEDLINE (por meio do PubMED), EMBASE, The Cochrane Library, LILACS (por meio da BVS) e PsycINFO. Revisões de RS e _guidelines_ não foram considerados como referências. Não houve restrições quanto ao idioma das publicações.  
Os critérios de inclusão e exclusão foram utilizados para balizar a decisão de selecionar, manter ou não os estudos recuperados das bases de dados eletrônicas. Esses critérios foram estabelecidos a partir dos PICOS de cada pergunta.  
A seleção inicial das evidências foi feita pela leitura de títulos e resumos. Em seguida, os textos das publicações selecionadas foram recuperados na íntegra, para uma avaliação mais detalhada e sua consequente inclusão ou exclusão. Quando foram encontradas mais de uma     RS com meta-análise, a mais atual, completa e com menor risco de viés foi selecionada.  
Adicionalmente, foram realizadas buscas por Ensaios Clínicos Randomizados (ECR) quando não foram identificadas RS que atendessem aos critérios PICOS e para atualizar as RS consideradas.  
Para a questão sobre eficácia de bupropiona associada a TRN, em comparação a TRN isolada, a RS selecionada (6) foi atualizada com a inclusão de dados mais recentes (7). Uma nova meta-análise utilizando modelo de efeitos aleatórios foi procedida. A heterogeneidade entre os estudos foi avaliada utilizando o teste I-quadrado e a análise de viés de publicação foi realizada por meio do _funnel plot_ . Foi utilizado o software Stata (versão 15), pacote _metan_ (8).  
Após a seleção das publicações foi feita a extração de seus resultados para uma planilha Excel. Foram extraídas as características dos estudos, número de  
34  
participantes, estimativas de efeito para os desfechos de interesse (eficácia e segurança) e medidas de precisão.  
O risco de viés das publicações foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Para RS, foi utilizada a ferramenta ROBIS – _Risk of Bias in Systematic Reviews_ (9) e para ECR a ferramenta de avaliação de risco de viés da Cochrane (10).  
1. Para responder à questão “O aconselhamento estruturado é recomendado para a cessação?”, foi utilizada a RS de Lindson-Hawley et al (2015) (11), publicada pela Cochrane Library, por ser a mais atual, com baixo risco de viés e a que melhor se enquadra no critério PICOS.  
2. Para responder à questão “O tratamento medicamentoso associado ao aconselhamento estruturado é mais eficaz que o aconselhamento estruturado isolado?”, foi utilizada a RS de Stead et al (2016) (12), publicada pela Cochrane Library, por ser a mais atual, com baixo risco de viés e a que melhor se enquadra no critério PICOS.  
3. Para responder à questão “O tratamento medicamentoso associado ao aconselhamento estruturado é mais eficaz que o tratamento medicamentoso isolado?”, foi utilizada a RS de Hartmann-Boyce et al (2019) (13), por ser a mais atual com baixo risco de viés e a que melhor se enquadra no critério PICOS.  
4. Para responder à questão “O tratamento com TRN combinada é mais eficaz e seguro do que o tratamento com TRN isolada?”, foi considerada a RS de Lindson et al (2019) (14), por ser a mais atual, a que melhor atende aos critérios PICOS e ter baixo risco de viés.  
5. Para responder às questões sobre eficácia e segurança do tratamento com Bupropiona comparado com TRN isolada, eficácia e segurança da Bupropiona associada a TRN isolada comparada com TRN isolada e eficácia e segurança de Bupropiona comparada a TRN combinada, foi realizada a atualização da RS de Hughes et al (2014) (6), considerando que é a mais atual e a que melhor responde às perguntas PICOS, além de ter baixo risco de viés. A busca por novas referências foi realizada a partir de julho de 2013 na base de dados MEDLINE (via PubMed), além de busca manual feita a partir dos estudos selecionados. A seguir é apresentada a estratégia de busca utilizada para a atualização:  
35

---

<!-- METADADOS: doenca: Tabagismo | secao: <u>Estratégia de busca para atualização:</u> -->
(((tobacco use cessation[mh] OR tobacco use cessation products[mh] OR smoking cessation[mh] OR smok*[tiab] OR cigarette*[tiab] OR tobacco[tiab]) AND (quit*[tiab] OR stop*[tiab] OR cessation[tiab])) AND (bupropion*[mh] OR bupropion*[tiab] OR zyban[tiab]) AND (nicotine replacement therap*[tiab] OR NRT[tiab] OR transdermal patch*[mh] OR patch*[tiab] OR lozenge[tiab] OR gum[tiab] OR chewing gum[mh] OR chewing gum[tiab])) AND ((randomized controlled trial [pt] OR controlled clinical trial [pt] OR randomized controlled trials [mh] OR random allocation [mh] OR double-blind method [mh] OR single-blind method [mh] OR clinical trial [pt] OR clinical trials[mh] OR (“clinical trial”[tw]) OR ((singl*[tw] OR doubl*[tw] OR trebl*[tw] OR tripl*[tw]) AND (mask*[tw] OR blind*[tw])) OR (placebos [mh] OR placebo* [tw] OR random* [tw] OR research design [mh:noexp] OR comparative study [pt] OR evaluation studies as topic  [mh] OR follow-up studies [mh] OR prospective studies [mh] OR control* [tw] OR prospective* [tw] OR volunteer* [tw]) NOT (animals [mh] NOT humans [mh]))) .  
Para as questões relacionadas ao tratamento da dependência à nicotina em situações especiais, como em adolescentes, gestantes, idosos, pacientes com câncer e outros, e a utilização de ferramentas auxiliares e práticas integrativas e complementares foram realizadas buscas sistemáticas por RS, sendo selecionadas as publicações mais recentes e que melhor respondessem aos desfechos de interesse (eficácia e segurança).

---

<!-- METADADOS: doenca: Tabagismo | secao: **Avaliação da qualidade da evidência** -->
O sistema GRADE foi utilizado para avaliar a qualidade das evidências. Neste sistema, a avaliação da qualidade da evidência é realizada para cada desfecho analisado, utilizando o conjunto disponível de evidências (2). Foram desenvolvidas tabelas de evidências na plataforma GRADEpro (GRADEpro GDT) para cada questão PICOS, e os critérios considerados para a avaliação foram: limitações metodológicas (risco de viés), inconsistência, evidência indireta, imprecisão e viés de publicação. No GRADE, a qualidade da evidência é classificada em quatro níveis: alto, moderado, baixo e muito baixo, de acordo com o **Quadro A** . Esses níveis representam a confiança na estimativa dos efeitos apresentados.  
36  
**Quadro A -** Níveis de evidências de acordo com o sistema GRADE  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado.|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|**Moderado**|Há confiança moderada no efeito estimado.|Trabalhos futuros poderão modificar a confiança na estimativa<br>de efeito, podendo, inclusive, modificar a estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto importante<br>em nossa confiança na estimativa de efeito.|
|**Muito**<br>**baixo**|A confiança na estimativa de efeito é muito<br>limitada. Há importante        grau<br>de<br>incerteza nos achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.

---

<!-- METADADOS: doenca: Tabagismo | secao: **Desenvolvimento de recomendações** -->
O painel para a definição das recomendações foi realizado em 01 e 02 de agosto de 2019, com participantes do Comitê Gestor, do Grupo Elaborador, especialistas, representante de sociedade médica, uma profissional da saúde atuante Programa Nacional de Controle do Tabagismo (PNCT) na APS e uma paciente. Para cada recomendação, foram discutidos a direção do curso da ação (a favor ou contra) e a força de recomendação (forte ou fraca), segundo o sistema GRADE ( **Quadro B** ).  
**Quadro B -** Implicação da força da recomendação para profissionais, pacientes e gestores da saúde.  
|**Público alvo**|**Forte**|**Fraca (condicional)**|
|---|---|---|
|**Gestores**|A recomendação deve ser adotada como política<br>de saúde na maioria<br>das situações.|É necessário debate substancial e envolvimento das<br>partes interessadas.|
|**Pacientes**|A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um|Grande parte dos indivíduos desejaria que a<br>intervenção fosse indicada; contudo considerável|
||pequeno<br>número<br>não<br>aceitaria<br>essa<br>recomendação.|número não aceitaria essa recomendação.|
|**Profissionais da**<br>**saúde**|A maioria dos pacientes deve receber<br>a<br>intervenção recomendada.|O profissional deve reconhecer que diferentes<br>escolhas serão apropriadas para cada paciente para<br>definir uma decisão consistente com os seus<br>valores e preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para a elaboração das recomendações, foram considerados os riscos e os benefícios das condutas propostas, o nível de evidências, custos, uso de recursos,  
37  
aceitabilidade pelos profissionais da saúde e pacientes, além das potenciais dificuldades e barreiras para implementação de cada intervenção. A recomendação poderia ser a favor ou contra a intervenção proposta,e ainda poderia ser uma recomendação forte (o grupo estava bastante confiante que os benefícios superavam os riscos) ou fraca (a recomendação ainda gerava dúvidas quanto ao balanço entre benefício e risco).  
Observações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou esclarecimentos foram documentadas. A direção e a força da recomendação, assim como sua redação, foram definidas durante essa reunião.  
O Grupo Elaborador recebeu as tabelas GRADE e EtD (Evidence to Decision) de cada questão PICOS. As evidências, riscos e benefícios da intervenção proposta, os custos e valores e as preferências dos pacientes foram apresentados e discutidos um a um. Cada domínio foi debatido separadamente, de forma estruturada, seguindo a metodologia preconizada pelo GRADE, pelo qual se buscou o consenso em relação às recomendações ( **Quadro C** ). Todo processo seguiu os padrões da Rede Internacional de Diretrizes do Instituto de Medicina Americano (3).  
**Quadro C -** Consenso do grupo elaborador para as recomendações do PCDT  
|**Questões**|**Considerações sobre a decisão**|
|---|---|
|1. O aconselhamento estruturado é recomendadopara a cessação?|Houve consenso entre o grupo.|
|2. O tratamento medicamentoso associado ao aconselhamento estruturado é mais eficaz que<br>o aconselhamento estruturado isolado?|Houve consenso entre o grupo.|
|3.<br>O<br>tratamento<br>medicamentoso<br>associado<br>o<br>aconselhamento|Houve consenso entre o grupo.|
|estruturado mais eficazque o tratamento medicamentoso?||
|4. O tratamento com TRN combinada é mais eficaz e seguro do que o tratamento com TRN<br>isolada?|Houve consenso entre o grupo.|
|5. O tratamento com Bupropiona é mais eficaz e seguro do que o tratamento com TRN<br>isolada?|Houve consenso entre o grupo.|
|6. O tratamento com Bupropiona associada a TRN isolada é mais eficaz e seguro do que o<br>tratamento com TRN isolada?|Houve consenso entre o grupo.|
|7. O tratamento com Bupropiona é mais eficaz e seguro do que o tratamento com TRN<br>combinada?|Houve consenso entre o grupo.|  
38  
**RECOMENDAÇÕES PARTE I – TRATAMENTO NÃO MEDICAMENTOSO Questão 1 – O aconselhamento estruturado é recomendado para a cessação?** **<u>Recomendação 1: Sugerimos que o aconselhamento estruturado seja utilizado para</u> o tratamento da dependência à nicotina, condicionado a estrutura e recursos dos serviços de saúde e disponibilidade dos pacientes (recomendação condicional a favor; qualidade da evidência moderada).**  
**<u>Resumo de evidências:</u>** A RS de Lindson-Hawley et al (2015) (11) avaliou ensaios clínicos randomizados (ECR) com tabagistas de ambos os sexos, recrutados em qualquer ambiente, exceto mulheres grávidas e adolescentes. A intervenção foi entrevista motivacional (uma a seis sessões, com duração de cada sessão variando de 10 a 60 minutos). Foi verificado que a entrevista motivacional apresentou um aumento na cessação de tabagismo por 6 meses quando comparada ao aconselhamento breve ou cuidados habituais (RR: 1,26; IC 95% 1,16 - 1,36; 28 estudos; N = 16.803, qualidade da evidência moderada).  
**<u>Comentários:</u>** Com relação às características do tratamento terapêutico não medicamentoso foram encontradas quatro RS que avaliaram o tratamento em termos de categoria profissional envolvida, o aconselhamento do paciente (individual ou em grupo), número e duração das sessões.  
As terapias em grupo, quando comparadas aos cuidados habituais, autoajuda, aconselhamento individual, outra intervenção comportamental ou nenhuma intervenção, apresentam maior eficácia na cessação do tabagismo (RR: 1,88; IC95% 1,52-2,33). Além disso, não há evidência de que o aconselhamento individual é mais eficaz que o em grupo (RR: 0,99; IC95% 0,76-1,28) (15).  
Não foram encontradas diferenças estatisticamente significativas na cessação do tabagismo nos grupos tratados pelos diferentes tipos de profissionais (11,12).  
Com relação ao número de sessões que devem compor o tratamento, as evidências apontam que não há diferença na eficácia com o aumento do número de sessões (11-13). Contudo, em uma RS publicada em 2013, foi observada diferença na eficácia do aconselhamento feito em 1 sessão (RR: 1,55; IC95% 1,35-1,79), quando comparada com múltiplas sessões (RR: 2,27; IC95% 1,87-2,75) (16).  
Para o tempo das sessões de aconselhamento, não há evidência de que o aumento da duração do contato (acima de 30 minutos), aumenta o efeito na cessação do tabagismo  
39  
(12).  
Também não foram verificadas evidências de que haja diferença na eficácia do tratamento para cessação do tabagismo por nível de aconselhamento (mínimo ou intensivo), população de estudo (população geral e população de alto risco), uso de subsídios para ajudar no aconselhamento (manuais de autoajuda, folhetos explicativos, etc.) (16) e por motivação do participante para parar de fumar (11).

---

<!-- METADADOS: doenca: Tabagismo | secao: **PARTE II – ASSOCIAÇÃO DOS TRATAMENTOS NÃO MEDICAMENTOSO E MEDICAMENTOSO** -->
**Questão 2 - O tratamento medicamentoso associado ao aconselhamento estruturado é mais eficaz que o aconselhamento estruturado isolado?** **<u>Recomendação 2: Recomendamos que seja utilizada farmacoterapia associada ao</u> aconselhamento estruturado para o tratamento da dependência à nicotina (recomendação forte a favor; qualidade da evidência moderada).**  
**<u>Resumo de evidências:</u>** A RS de Stead et al (2016) (12) avaliou tabagistas, recrutados em qualquer ambiente, com a exceção de mulheres grávidas. As intervenções para cessação do tabagismo incluíram apoio comportamental e disponibilidade de farmacoterapia, independentemente do tipo. A prestação de informações escritas, breves instruções sobre o uso correto da farmacoterapia e cuidados habituais foram considerados como o comparador. Foi observado benefício da farmacoterapia combinada ao tratamento comportamental (RR: 1,83, IC 95% 1,68-1,98; 52 estudos; N = 19.488, qualidade da evidência moderada).  
**Questão 3 - O tratamento medicamentoso associado ao aconselhamento estruturado é mais eficaz que o tratamento medicamentoso?** **<u>Recomendação 3: Recomendamos que seja utilizada farmacoterapia associada ao</u> aconselhamento estruturado para o tratamento da dependência à nicotina (recomendação forte a favor; qualidade da evidência moderada).**  
**<u>Resumo de evidências:</u>** A RS de Hartmann-Boyce et al (2019) (13) avaliou tabagistas, recrutados em qualquer ambiente, com a exceção de mulheres grávidas e adolescentes. Todos os participantes tiveram acesso a farmacoterapia, utilizada de forma isolada ou combinada, e a uma ou mais intervenções comportamentais. No grupo controle, o aconselhamento foi de menor intensidade (com base no número ou na duração das  
40  
sessões) quando comparado ao grupo intervenção. Foi verificado que o aconselhamento mais intenso associado a farmacoterapia apresentou um benefício estatisticamente significativo, para a cessação a partir dos seis meses (RR: 1,15; IC 95% 1,08 - 1,22; 65 estudos; N = 23.331, qualidade da evidência moderada).

---

<!-- METADADOS: doenca: Tabagismo | secao: **TRN x placebo** -->
Para qualquer forma de apresentação de TRN, sua utilização é maior para a cessação do tabagismo aos seis meses, quando comparada à placebo. O aumento na cessação produzido pela TRN ocorre independentemente da intensidade do suporte comportamental (17).  
Com relação aos diferentes esquemas terapêuticos, em fumantes altamente dependentes há maior benefício na utilização de 4 mg de goma de nicotina em comparação com 2 mg. Assim como, o adesivo com 21 mg é mais eficaz do que o com 14 mg, em 24 horas. A utilização de adesivo por um período curto anterior à data de parada parece aumentar a cessação aos seis meses, quando comparado ao início da utilização no dia de parada (14).  
Palpitações, taquicardia, dores no peito, náusea, vômitos e distúrbios gastrointestinais estão relacionados ao uso de TRN, em comparação ao placebo (17-21). Em geral, os EA são referentes ao tipo de apresentação do produto: goma, pastilha, comprimido sublingual, sprays nasal e bucal (soluços, dores e úlceras na boca e garganta, tosse); adesivo transdérmico (irritação na pele). Não há evidências de que a TRN, em qualquer forma de apresentação, esteja relacionada a eventos adversos (EA) graves, incluindo morte (18,19).  
**Questão 4 - O tratamento com TRN combinada é mais eficaz e seguro do que o tratamento com TRN isolada?**  
**<u>Recomendação 4: Recomendamos que TRN combinada seja oferecida para o</u> tratamento da dependência à nicotina, em vez de TRN isolada (recomendação forte a favor; qualidade da evidência alta).**  
**<u>Resumo de evidências:</u>** Foi encontrada uma RS da Cochrane publicada em abril de 2019 que avaliou a combinação de diferentes apresentações de TRN com TRN isolada  
41  
(14). Esse estudo incluiu tabagistas motivados a parar, independemente do local em que foram recrutados ou do nível inicial de dependência de nicotina. Os autores verificaram que a combinação de TRN é mais eficaz do que a TRN isolada (RR: 1,25; IC 95% 1,15-1,36; 14 estudos; N= 11.356, qualidade da evidência alta). Quando comparada a combinação de TRN com adesivo, a cessação do tabagismo para quem utiliza a combinação é 23% maior (RR: 1,23; IC 95% 1,121,36; 12 estudos; N= 8.992). Também foi observada superioridade na combinação de TRN quando comparada a uma forma rápida de entrega de nicotina (RR: 1,30; IC 95% 1,09-1,54; 6 estudos; N= 2.364, qualidade da evidência alta).  
Os indivíduos tratados com combinação de TRN (adesivo + pastilha) apresentaram mais náusea (diferença de risco: −6,4; IC95% −11,3 a −1,6), indigestão (DR: −8,3; IC 95% −11,6 a −5,0), problemas orais (DR: −6,6; IC 95% −9,5 a −3,7) e soluços (DR: −6,2; IC 95% −8,5 a −3,9), quando comparado com TRN isolada (adesivo) (21). Para a ocorrência de EA graves relacionados a utilização de CTRN x TRN isolada não foi verificada diferença estatisticamente significativa (RR: 4,44; IC 95% 0,76-25,85). Cabe salientar que a ocorrência de EA graves é rara, sendo que foram observados 6 casos entre 1475 no grupo de CTRN e 1 caso entre 1413 no grupo de TRN isolada (14).

---

<!-- METADADOS: doenca: Tabagismo | secao: **Bupropiona x placebo** -->
O uso de bupropiona para o tratamento de dependência à nicotina demonstra aumento na cessação por seis meses ou mais, em relação ao placebo. Na comparação entre diferentes doses (300 mg _versus_ 150 mg), não há evidência de diferença significativa na cessação (6).  
Os principais EA associados ao uso de bupropiona em comparação a placebo são: boca seca, insônia, perturbação gastrointestinal e constipação. Não há evidências de EA graves, EA graves cardiovasculares e nem EA graves neuropsiquiátricos associados ao uso de bupropiona para cessação do tabagismo (6,21,22).  
**QUESTÃO 5 - O tratamento com Bupropiona é mais eficaz e seguro do que o tratamento com TRN isolada?**  
**<u>Recomendação 5: Sugerimos que Bupropiona em monoterapia seja utilizada para o</u> tratamento de dependência à nicotina, em vez de TRN isolada. Condicionada a**  
42  
**existência de médico prescritor, estrutura e recursos dos serviços de saúde e características individuais dos pacientes (recomendação condicional a favor; qualidade da evidência moderada).**  
**<u>Resumo de evidências:</u>** A RS de Hughes et al (2014) (6) avaliou o uso de antidepressivos, entre eles, a bupropiona, para o tratamento de tabagistas. A análise foi feita incluindo dois ECR que avaliavam a combinação de TRN, sendo assim a metaanálise foi refeita excluindo esses estudos. Quando comparada com a TRN isolada, a bupropiona não demonstrou eficácia superior, sendo o RR 1,02 (IC95% 0,90 -1,17; 10 estudos, N=3.366).  
A busca foi atualizada a partir de julho de 2013, sendo encontrados dois ECR (7,23). Foi refeita a meta-análise, mas não houve mudança no resultado (RR: 1,03; IC95% 0,921,14; 12 estudos, N= 5.440, qualidade da evidência moderada).  
Com relação aos EA, Stapleton et al (2013) (24) avaliou 827 indivíduos e verificou maiores incidências de boca seca, cefaleia, náusea, tontura, depressão, ansiedade/pânico, dor torácica, desorientação e perda de apetite entre os que usaram bupropiona. Irritação nasal (spray nasal de nicotina) e irritação da pele (adesivo de nicotina) foram mais comuns entre aqueles que utilizaram a TRN. Anthenelli et al (2016) (23), avaliou 1995 participantes de uma coorte não psiquiátrica e não observou diferença significativa com relação aos EA neuropsiquiátricos entre os que utilizaram bupropiona e TRN (adesivo) (Diferença de risco: 0,13; IC 95% −1,19 to 1,45). Para os EA a qualidade da evidência foi baixa.  
**QUESTÃO 6 - O tratamento com Bupropiona associada a TRN isolada é mais eficaz e seguro do que o tratamento com TRN isolada?**  
**<u>Recomendação 6: Sugerimos que Bupropiona associada a TRN isolada seja</u> oferecida para o tratamento de dependência à nicotina em pacientes que não se beneficiam de TRN isolada. Condicionada a existência de médico prescritor, estrutura e recursos dos serviços de saúde e características individuais dos pacientes (recomendação condicional a favor; qualidade da evidência muito baixa).**  
**<u>Resumo de evidências:</u>** O tratamento combinado de bupropiona com TRN comparado ao uso de TRN isolada também foi um desfecho avaliado pela RS de Hughes et al (2014) (6), sendo que a associação de TRN à bupropiona não foi capaz de superar a TRN com  
43  
adesivo (RR: 1,24; IC95% 0,84-1,84; 9 estudos, N= 1.774), com pastilha (RR: 1,21; IC95% 0,81-1,81; 2 estudos; N= 1.051) ou pela livre escolha de TRN (RR: 0,97; IC 95% 0,73-1,28; 1 estudo; N= 662). Foi encontrado um novo ECR (5) na atualização da busca e a inclusão desses achados na nova meta-análise não alterou o resultado (RR: 1,21; IC 95% 0,98-1,51; 13 estudos; N= 3.547, qualidade da evidência muito baixa).  
Na avaliação de segurança, a qualidade da evidência foi baixa. Kalman et al (2011) (25) não  observou diferenças significativas entre os grupos de TRN (n= 70) e bupropiona + TRN (n= 73), com relação a insônia, ansiedade, dor de cabeça, tontura, boca seca e náusea. No estudo de Schnoll et al (2010) (26), que avaliou 246 indivíduos, também não houve diferença significativa entre os braços de tratamento para o conjunto de eventos adversos (p = 0,80). Simon et al (2004) (27) também não encontrou diferença significativa no percentual de participantes que relatou um ou mais eventos adversos, quando comparados os grupos de TRN (n= 123) e bupropiona + TRN (n= 121) (P = 0,07). Comparado com o grupo TRN, o grupo de bupropiona relatou boca seca (22% vs 8%; P <0,01) e desconforto gastrointestinal (9% vs 1%; P <0,01) mais frequentemente. Stapleton et al (2013) (24) (n= 662) verificou maior incidência de distúrbios do sono, dor de cabeça, boca seca, náusea, tontura, desorientação e perda de apetite no grupo bupropiona + TRN, enquanto no grupo TRN foi maior irritação na pele (P<0,05).  
**QUESTÃO 7 - O tratamento com Bupropiona é mais eficaz e seguro do que o tratamento com TRN combinada?**  
**<u>Recomendação 7: Sugerimos que TRN combinada seja oferecida para o tratamento</u> de dependência à nicotina, em vez de Bupropiona (recomendação fraca contra a intervenção, a favor do comparador; qualidade da evidência alta).**  
**<u>Resumo de evidências:</u>** Poucos ECR avaliaram o tratamento para dependência a nicotina usando bupropiona em comparação a combinação de TRN. Na RS de Hughes et al (2014) (6) foram incluídos apenas dois estudos e o resultado da meta-análise aponta para menor eficácia da bupropiona quando comparada a TRN combinada (adesivo + goma) (RR: 0,74; IC 95%: 0,55-0,98; N= 720, qualidade da evidência alta). Não foram encontrados ECR adicionais, que respondessem a essa pergunta, na atualização da busca.  
Com relação aos EA, a qualidade da evidência foi baixa. Piper et al (2009) (28) observou que houve maior proporção de relatos de eventos adversos entre os  
44  
participantes que utilizaram combinações de TRN (adesivo + pastilha) (n= 262) do que entre os que utilizaram bupropiona (n= 262). Os autores não apresentaram estatística de comparação entre os grupos de tratamento. De forma geral boca seca, alteração no paladar, distúrbios no sono e sonhos anormais foram mais frequentes no grupo bupropiona, enquanto náusea, irritação na pele, na boca e na garganta, soluços, flatulência e dispepsia foram mais frequentes no grupo de combinação de TRN.

---

<!-- METADADOS: doenca: Tabagismo | secao: **REFERÊNCIAS** -->
1. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas. Brasília: Ministério da Saúde, 2016. 96 p. il.  
2. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. Brasília: Ministério da Saúde, 2014. 72 p.: il.  
3. Qaseem A, Forland F, Macbeth F, Ollenschläger G, Phillips S, van der Wees P. Board of Trustees of the Guidelines International Network. Guidelines International Network: toward international standards for clinical practice guidelines. Ann Intern Med. 2012 Apr 3;156(7):525-31.  
4. Ministério da Saúde. Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde. Conitec. Relatório de Recomendação nº 468 – Vareniclina para cessação do tabagismo - julho de 2019. Disponível em: http://conitec.gov.br/images/Relatorios/2019/Relatorio_VARENICLINA_TABAGISMO_ FINAL_468.pdf.  
5. BRASIL. Ministério da Saúde. Secretária de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde. Portaria nº 41, de 24 de julho de 2019. Torna pública a decisão de não incorporar a vareniclina para a cessação do tabagismo no âmbito do Sistema Único de Saúde - SUS. Diário Oficial da União, Brasília, DF, 25 jul. 2019. p. 148.  
6. Hughes JR, Stead LF, Hartmann-Boyce J, Cahill K, Lancaster T. Antidepressants for smoking cessation. Cochrane Database of Systematic Reviews 2014, Issue 1. Art. No.: CD000031.  
45  
7. Chandrashekar M, Sattar FA, Bondade S, Kumar KK. A comparative study of different modalities of treatment in nicotine dependence syndrome. Asian J Psychiatr. 2015 Oct;17:29-35.  
8. StataCorp. 2017. Stata Statistical Software: Release 15. College Station, TX: StataCorp LLC.  
9. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. ROBIS – Risk of Bias in Systematic Reviews: ferramenta para avaliar o risco de viés em revisões sistemáticas: orientações de uso / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2017. 52 p.: il.  
10. Higgins JPT, Altman DG, Gotzsche PC, Juni P, Moher D, Oxman, AD et al. The Cochrane Collaboration’s tool for assessing risk of bias in randomized trials. BMJ 2011;343:d5928.  
11. Lindson-Hawley N, Thompson TP, Begh R. Motivational interviewing for smoking cessation. Cochrane Database of Systematic Reviews 2015, Issue 3. Art. Nº.:CD006936.  
12. Stead LF, Koilpillai P, Fanshawe TR, Lancaster T. Combined pharmacotherapy and behavioral interventions for smoking cessation. Cochrane Database of Systematic Reviews 2016, Issue 3. Art. Nº.: CD008286.  
13. Hartmann-Boyce J, Hong B, Livingstone-Banks J, Wheat H, Fanshawe TR. Additional behavioral support as an adjunct to pharmacotherapy for smoking cessation. Cochrane Database of Systematic Reviews 2019, Issue 6. Art. No.: CD009670.  
14. Lindson N, Chepkin SC, Ye W, Fanshawe TR, Bullen C, Hartmann-Boyce J. Different doses, durations and modes of delivery of nicotine replacement therapy for smoking cessation. Cochrane Database of Systematic Reviews 2019, Issue 4. Art. No.: CD013308.  
15. Stead LF, Carroll AJ, Lancaster T. Group behavior therapy programmes for smoking cessation. Cochrane Database of Systematic Reviews 2017, Issue 3. Art. Nº.:CD001007.  
16. Stead LF, Buitrago D, Preciado N, Sanchez G, Hartmann-Boyce J, Lancaster T. Physician advice for smoking cessation. Cochrane Database of Systematic Reviews 2013, Issue 5. Art. Nº.:CD000165.  
46  
17. Hartmann-Boyce J, Chepkin SC, Ye W, Bullen C, Lancaster T. Nicotine replacement therapy versus control for smoking cessation. Cochrane Database of Systematic Reviews 2018, Issue 5. Art. No.: CD000146.  
18. Moore D, Aveyard P, Connock M, Wang D, Fry-Smith A, Barton P. Effectiveness and safety of nicotine replacement therapy assisted reduction to stop smoking: systematic review and meta-analysis. BMJ 2009;338:b1024.  
19. Mills EJ, Wu P, Lockhart I, Wilson K, Ebberts JO. Adverse events associated with nicotine replacement therapy (NRT) for smoking cessation. A systematic review and metaanalysis of one hundred and twenty studies involving 177.390 individuals. Tobacco Induced Diseases 2010, 8:8.  
20. Stead LF, Perera R, Bullen C, Mant D, Hartmann-Boyce J, Cahill K, Lancaster T. Nicotine replacement therapy for smoking cessation. Cochrane Database of Systematic Reviews 2012, Issue 11. Art. No.: CD000146.  
21. Cahill K, Stevens S, Perera R, Lancaster T. Pharmacological interventions for smoking cessation: an overview and network meta-analysis. Cochrane Database of Systematic Reviews 2013, Issue 5.Art.No.:CD009329.  
22. Wu P, Wilson K, Dimoulas P, Mills EJ. Effectiveness of smoking cessation therapies: a systematic review and meta-analysis. BMC Public Health. 2006 Dec 11;6:300.  
23. Anthenelli RM, Benowitz NL, West R, St Aubin L, McRae T, Lawrence D et al. Neuropsychiatric safety and efficacy of varenicline, bupropion, and nicotine patch in smokers with and without psychiatric disorders (EAGLES): a double-blind, randomized, placebo-controlled clinical trial. Lancet. 2016 Jun 18;387(10037):2507-20.  
24. Stapleton J, West R, Hajek P, Wheeler J, Vangeli E, Abdi Z et al. Randomized trial of nicotine replacement therapy (NRT), bupropion and NRT plus bupropion for smoking cessation: effectiveness in clinical practice. Addiction. 2013 Dec;108(12):2193-201.  
25. Kalman D, Herz L, Monti P, Kahler CW, Mooney M, Rodrigues S et al. Incremental efficacy of adding bupropion to the nicotine patch for smoking cessation in smokers with a recent history of alcohol dependence: results from a randomized, double-blind, placebocontrolled study. Drug Alcohol Depend. 2011 Nov 1;118(2-3):111-18.  
26. Schnoll RA, Martinez E, Tatum KL, Weber DM, Kuzla N, Glass M et al. A bupropion smoking cessation clinical trial for cancer patients. Cancer Causes Control. 2010 Jun;21(6):811-20.  
27. Simon JA, Duncan C, Carmody TP, Hudes ES. Bupropion for smoking cessation: a  
47  
randomized trial. Arch Intern Med. 2004 Sep 13;164(16):1797-803.  
28. Piper ME, Smith SS, Schlam TR, Fiore MC, Jorenby DE, Fraser D et al. A randomized placebo- controlled clinical trial of 5 smoking cessation pharmacotherapies. Arch Gen Psychiatry. 2009 Nov;66(11):1253-262.  
29. Baker TB, Piper ME, Stein JH, Smith SS, Bolt DM, Fraser DL et al. Effects of Nicotine Patch vs Varenicline vs Combination Nicotine Replacement Therapy on Smoking Cessation at 26 Weeks: A Randomized Clinical Trial. JAMA. 2016 Jan 26;315(4):371-9.  
48

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 1** -->
|**INTERVENÇÃO:**|**aconselhamento estruturado (entrevista motivacional realizada em 1 a 6 sessões, com duração de cada sessão variando de 10 a 60 minutos)**|
|---|---|
|**COMPARADOR:**|**aconselhamento breve ou cuidado usual (em menor intensidade em relação ao cuidado estruturado)**|

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 1** -->
|**№**|**Delineament**|**Risco de**|**GRADE**<br>**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**<br>**considerações**|**№ de p**<br>**aconselhament**|**acientes**<br>**aconselhame**|**Efeito**<br>**Relati**|**Absolu**|**Certeza da**<br>**evidência**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**dos**<br>**estud**|**odo**<br>**estudo**|**viés**||**indireta**|||**o**<br>**estruturado**|**nto breve ou**<br>|**vo**|**to**|||
|**os**||||||||**cuidado**|**(95%**|**(95%**|||
|||||||||**usual**|**CI)**|**CI)**|||

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 1** -->
|28<br>ensaios<br>clínicos<br>randomiza<br>dos|não grave|não grave|grave<sup>a</sup>|não grave|nenhu<br>m|1234/90<br>21<br>(13.7%<br>)|810/7782<br>(10.4%)|**RR 1.26**<br>(1.16<br>para 1.36)|**27 mais**<br>**por**<br>**1.000**<br>(de 17<br>mais<br>para 37<br>mais)|⨁⨁⨁`◯`<br>MODERADA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|  
**95% CI:** Intervalo de confiança; **RR:** Risco relativo **Explicações**  
a. Diferentes intervenções motivacionais utilizadas nos ECR  
64

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
|**OPÇÃO:**|**tratamento medicamentoso associado ao aconselhamento estruturado**|
|---|---|
|**COMPARAÇÃO:**|**aconselhamento estruturado isolado**|
|**PRINCIPAIS DESFECHOS:**|**Eficácia (cessação)**|  
||||**GRADE**||||**№ de pac**|**ientes**|**Efeito**|**Certeza da**<br>**evidência**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineament**<br>**odo**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**tratamento**<br>**medicamentoso**|**aconselhame**<br>**nto**<br>**estruturado**<br>**isolado**|**Relati**<br>**vo**<br>**(95%**|**Absolu**<br>**to**<br>**(95%**||
||||||||**associado ao**||**CI)**|**CI)**||
||||||||**aconselhamento**<br>**estruturado**|||||

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
|52<br>ensai<br>os<br>clínic<br>os<br>randomizad<br>os|não grave|não grave|grave<sup>a</sup>|não grave|nenhu<br>m|1529/10070<br>(15.2%)|808/9418<br>(8.6%)|**RR 1.83**<br>(1.68<br>para 1.98)|**71 mais**<br>**por**<br>**1.000**<br>(de 58<br>mais<br>para 84<br>mais)|⨁⨁⨁`◯`<br>MODERADA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|  
**95% CI:** Intervalo de confiança; **RR:** Risco relativo

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
a. Variação no tipo e duração do suporte comportamental entre os estudos.  
65

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
|**OPÇÃO:**|**tratamento medicamentoso associado o aconselhamento estruturado**|
|---|---|
|**COMPARAÇÃO:**|**tratamento medicamentoso isolado**|
|**PRINCIPAIS DESFECHOS:**|**Eficácia (cessação)**|  
||||**GRADE**||||**№ de pa**|**cientes**<br>|**Efeito**||**Certeza da**<br>**evidência**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**|**Delineament**|**Risco de**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**tratamento**|**tratamento**|**Relati**|**Absolu**|||
|**dos**<br>**estud**<br>**os**|**odo**<br>**estudo**|**viés**||**indireta**||**considerações**|**medicamentos**<br>**oassociado**|**medicamentoso**<br>**isolado**|**vo**<br>**(95%**|**to**<br>**(95%**|||
||||||||||**CI)**|**CI)**|||
||||||||**aconselhamento**<br>**estruturado**||||||

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
|65|ensai<br>os<br>clínic<br>os<br>randomizad<br>os|não grave<sup>a</sup>|não grave|grave<sup>b</sup>|não grave|nenhu<br>m|2291/11630<br>(19.7%)|2006/11701<br>(17.1%)|**RR 1.15**<br>(1.08<br>para 1.22)|**26 mais**<br>**por**<br>**1.000**<br>(de 14<br>mais<br>para 38<br>mais)|⨁⨁⨁`◯`<br>MODERADA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
**95% CI:** Intervalo de confiança; **RR:** Risco relativo

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
a. A maioria dos estudos fez randomização e cegamento. Com relação a sigilo de alocação: 22 fizeram,1 não fez e para 39 ECR não houve certeza.  
b. Em alguns ECR a população avaliada foi diferente da pop. geral (usuários de álcool, em tratamento com metadona, pacientes hospitalizados, HIV+, portadores de esquizofrenia, militares, fumantes leves, adultos sem teto, adolescentes), variação nas intervenções comportamentais; 2 ECR c/ desfecho em 12 sem; 14 ECR com financiamento não declarado ou com conflito de interesse.  
66

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
**O tratamento com TRN combinada é mais eficaz e seguro do que o tratamento com TRN isolada para a cessação do tabagismo?**  
|**OPÇÃO:**|**combinação de TRN (CTRN)**|
|---|---|
|**COMPARAÇÃO:**|**TRN isolada**|
|**PRINCIPAIS DESFECHOS:**|**Eficácia (cessação); Segurança (eventos adversos)**|  
||||**GRADE**||||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudo**<br>**s**|**Delineament**<br>**odo**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**combinação**<br>**de TRN**|**TRN isolada**|**Relativ**<br>**o(95%**<br>**CI)**|**Absolut**<br>**o (95%**<br>**CI)**|**Certeza da**<br>**evidência**|**Importância**|

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
|14<br>ensai<br>os<br>clínic<br>os<br>randomizad<br>os|não grave<sup>a</sup>|não grave|não grave|não grave|nenhu<br>m|881/5218<br>(16.9%)|852/6138<br>(13.9%)|**RR 1.25**<br>(1.15<br>para 1.36)|**35 mais**<br>**por**<br>**1.000**<br>(de 21<br>mais<br>para 50<br>mais)|⨁⨁⨁⨁<br>ALTA|CRÍTI<br>CO|
|---|---|---|---|---|---|---|---|---|---|---|---|  
**Segurança (eventos adversos) (seguimento: 6 meses)**  
67  
|**№**<br>**dos**<br>**estud**<br>**os**|**G**<br>**Delineamen**<br>**todo**<br>**estudo**|**RADE**<br>**Risco de**<br>**viés**|**Inconsistênc**<br>**ia**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**№ de pacientes**<br>**Efeito**<br>**combinação**<br>**de TRN**<br>**TRN isolada**<br>**Relati**<br>**vo**<br>**(95%**<br>**CI)**<br>**Absoluto**<br>**(95% CI)**|**Certeza da**<br>**evidência**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|1|ensaios<br>clínicos<br>randomizad<br>os|grave<sup>b</sup>|não grave|não grave|grave<sup>c</sup>|nenhu<br>m|Baker et al. (2016) (29) com 1.086 participantes - Os<br>indivíduos tratados com combinação de TRN (adesivo +<br>pastilha) apresentaram mais náusea<br>(diferença de risco: −6,4; IC95% −11,3 a −1,6), indigestão<br>(DR: −8,3; IC 95%<br>−11,6 a −5,0), problemas bucais (DR: −6,6; IC 95% −9,5 a<br>−3,7) e soluços (DR:<br>−6,2; IC 95% −8,5 a −3,9), quando comparado com TRN<br>isolada (adesivo). Para os demais EA avaliados não houve<br>diferença entre os grupos (coceira, sonhos vívidos, insônia,<br>vermelhidão, vômito, constipação, tontura, dor de cabeça,<br>sonolência). Foi encontrada uma RS (Lindson et al, 2019)<br>que comparou a ocorrência de EA graves com relação a<br>utilização de CTRN x TRN isolada e não encontrou<br>diferença estatisticamente significativa entre as intervenções<br>(RR: 4,44; IC 95% 0,76-25,85). Cabe salientar que a<br>ocorrência de EA graves é rara, sendo que foram observados 6<br>casos entre 1475 no grupo de CTRN e 1 caso entre 1413 no<br>grupo de TRN isolada.|⨁⨁`◯◯`<br>BAIXA|IMPORTANTE|  
**95% CI:** Intervalo de confiança; **RR:** Risco relativo

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
a. Cinco ECR não fizeram cegamento; randomização foi incerta em 4 ECR; sigilo de alocação não foi feito em um e foi incerto em outros 5 ECR. Contudo, acredita-se que esses problemas metodológicos não possuem grande influência sobre o resultado.  
b. O estudo apresenta risco de viés para alocação sigilosa e cegamento.  
c. Estudo único, com pequeno n para evidência.  
68

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
**O tratamento com bupropiona é mais eficaz e seguro do que o tratamento com TRN isolada para a cessação do tabagismo? Devemos usar BUP ou TRN isolado?**  
|**OPÇÃO:**|**Bupropiona**|
|---|---|
|**COMPARAÇÃO:**|**TRN isolada**|
|**PRINCIPAIS DESFECHOS:**|**Eficácia (cessação); Segurança (eventos adversos)**|  
<!-- Start of picture text -->
Certeza da evidência Importância<br>№ dos  Delineamento       Risco de viés  Inconsistência Evidência Imprecisão  Outras considerações bupropiona TRN isolada Relativo Absoluto<br>estudos do estudo indireta<br>(95% CI)  (95% CI)<br><!-- End of picture text -->  
**Eficácia (cessação) (seguimento: 6 meses)**  
<!-- Start of picture text -->
12  ensai não grave  a não grave  não grave  grave  b nenhu 500/2352  673/3088  RR 1.03  7 mais  ⨁⨁⨁ ◯ CRÍTI<br>os  m  (21.3%)  (21.8%)  (0.92  por  MODERADA  CO<br>clínic para 1.14)  1.000<br>os<br>randomizad<br>os<br>(de 17<br>menos<br>para<br>31 mais)<br><!-- End of picture text -->  
**Segurança (eventos adversos) (seguimento: 6 meses)**  
69  
||||**GRADE**||||**№ de pacientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineamen**<br>**todo**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistên**<br>**cia**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**bupropiona**<br>**TRN**<br>**isolada**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza da**<br>**evidência**|**Importância**|
|2|ensaios<br>clínicos<br>randomiza<br>dos|grave<sup>c</sup>|grave<sup>d</sup>|não grave|não grave|nenhu<br>m|Stapleton (2013), avaliou 827<br>incidências de boca seca, cefa<br>ansiedade / pânico, dor torá<br>apetite entre os que tomava<br>(spray nasal de nicot<br>(adesivo de nicotina) foram<br>utilizaram a TRN. Anthe<br>participantes de uma coorte n<br>diferença significativa com rel<br>entre os que utilizaram b<br>(Diferença de risco: 0,1|indivíduos e ve<br>leia, náusea, ton<br>cica, desorientaç<br>m bupropiona. Ir<br>ina) e irritação d<br>mais comuns ent<br>nelli (2016), ava<br>ão psiquiátrica e<br>ação aos EA ne<br>upropiona e TRN<br>3;IC 95% −1,19|rificou maiores<br>tura, depressão,<br>ão e perda de<br>ritação nasal<br>a pele<br>re aqueles que<br>liou 1995<br>não observou<br>uropsiquiátricos<br>(adesivo)<br>a 1,45).|⨁⨁`◯◯`<br>BAIXA||  
**95% CI:** Intervalo de confiança; **RR:** Risco relativo

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
a. Seis ECR não fizeram cegamento, não houve certeza com relação a sigilo de alocação e randomização para a maioria dos estudos. Contudo, acredita-se que esses problemas metodológicos não possuem grande influência sobre o resultado.  
b. IC da estimativa de efeito varia de 0,92 a 1,14, entre a superioridade e inferioridade da bupropiona, ou seja, existe risco de dano ou benefício, de modo a agregar incerteza na estimativa. c. Um dos estudos (Stapleton, 2013) não realizou cegamento.  
d. Os resultados com relação aos EA neuropsiquiátricos foram contraditórios entre os dois ECR.  
70

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
|**OPÇÃO:**|**bupropiona + TRN**|
|---|---|
|**COMPARAÇÃO:**|**TRN isolada**|
|**PRINCIPAIS DESFECHOS:**|**Eficácia (cessação); Segurança (eventos adversos)**|  
<!-- Start of picture text -->
GRADE  № de pacientes  Efeito<br>Certeza da<br>evidência Importância<br>№  Delineamen Risco de  Inconsistência  Evidência  Imprecisã Outras  bupropion TRN  Relativo  Absoluto<br>dos  to do  viés  indireta  o  considerações  isolada<br>a +  (95% CI)  (95% CI)<br>estud estudo<br>os  TRN<br><!-- End of picture text -->  
**Eficácia (cessação) (seguimento: 6 meses)**  
<!-- Start of picture text -->
13  ensai não grave  a grave  b grave  c grave  d nenhu 375/1678  352/1869  RR 1.21  40 mais  ⨁ ◯◯◯ CRÍTI<br>os  m  (22.3%)  (18.8%)  (0.98  por  MUITO  CO<br>clínic para 1.51)  1.000  BAIXA<br>os<br>randomizad<br>os<br>(de 4<br>menos<br>para 96<br>mais)<br><!-- End of picture text -->  
**Segurança (eventos adversos) (seguimento: 6 meses)**  
71  
||**G**|**RADE**|||||**№ de pacientes**<br>**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineamen**<br>**todo**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**bupropion**<br>**a +**<br>**TRN**<br>**TRN isolada**<br>**Relativo**<br>**(95% CI)**<br>**Absoluto**<br>**(95% CI)**|**Certeza da**<br>**evidência**|**Importância**|
|4|ensaios<br>clínicos<br>randomizad<br>os|grave<sup>e</sup>|grave<sup>f</sup>|grave<sup>g</sup>|não grave|nenhu<br>m|Kalman (2011) não observou diferenças significativas entre os<br>grupos de TRN (n= 70) e bupropiona + TRN (n= 73), com<br>relação a insônia, ansiedade, dor de cabeça, tontura, boca seca<br>e náusea. No estudo de Schnoll (2010), que avaliou 246<br>indivíduos, também não houve diferença significativa entre os<br>braços de tratamento para o conjunto de eventos adversos (p =<br>0,80). Simon (2004) também não encontrou diferença<br>significativa no percentual de participantes que relatou um ou<br>mais eventos adversos, quando comparados os grupos de<br>TRN (n= 123) e bupropiona + TRN (n= 121) (P = 0,07).<br>Comparado com o grupo TRN, o grupo de bupropiona relatou<br>boca<br>seca (22% vs 8%; P <0,01) e desconforto gastrointestinal (9%<br>vs 1%; P <0,01)<br>mais frequentemente. Stapleton (2013) (n= 662) verificou<br>maior incidência de distúrbios do sono, dor de cabeça, boca<br>seca, náusea, tontura, desorientação e perda de apetite no<br>grupo bupropiona + TRN, enquanto no grupo TRN foi maior<br>irritação na pele (P<0,05).|⨁`◯◯◯`<br>MUITO<br>BAIXA|IMPORTANTE|  
**95% CI:** Intervalo de confiança; **RR:** Risco relativo

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
a. Incerteza sobre sigilo de alocação, randomização e cegamento para a maioria dos estudos. Três ECR não fizeram cegamento. Contudo, acredita-se que esses problemas metodológicos não possuem grande influência sobre o resultado. b. Inconsistência: I² de 49,4%, estudos heterogêneos.  
c. Dos 13 ECR incluídos 7 apresentaram populações específicas e 1 apresenta desfecho medido em 12 semanas.  
d. O IC da estimativa de efeito varia de 0,97 a 1,43, entre a superioridade e inferioridade da bupropiona + TRN.  
e. Para 3 dos 4 ECR não há certeza sobre randomização, sigilo de alocação e cegamento e 1 ECR não foi cego.  
- f. Quando avaliados os EA separadamente, 2 ECR não encontraram diferença significativa e 2 ECR verificaram diferenças entre os grupos. Os 2 ECRS que avaliaram o conjunto de EA não encontraram diferenças entre os grupos. g. Em 2 estudos a população avaliada era composta por pacientes com diagnóstico de câncer e com uso abusivo de álcool.  
72

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
|**OPÇÃO:**|**bupropiona**|
|---|---|
|**COMPARAÇÃO:**|**combinação de TRN**|
|**PRINCIPAIS DESFECHOS:**|**Eficácia (cessação); Segurança (eventos adversos)**|  
<!-- Start of picture text -->
GRADE  № de pacientes  Efeito<br>Certeza da  Importância<br>evidência<br>№  Delineamen Risco de  Inconsistência  Evidência  Imprecisã Outras  bupropiona  combinação  Relativo  Absoluto<br>dos  to do  viés  indireta  o  considerações<br>de TRN  (95%  (95% CI)<br>estud estudo<br>os  CI)<br><!-- End of picture text -->  
**Eficácia (cessação) (seguimento: 6 meses)**  
<!-- Start of picture text -->
2 ensai não grave  a não grave  não grave  não grave  nenhu 43/174  182/546  RR 0.74  87 menos  ⨁⨁⨁⨁ CRÍTI<br>os  m  (24.7%)  (33.3%)  (0.55  por 1.000  ALTA  CO<br>clínic para 0.98)<br>os<br>randomizad<br>os<br>(de 150<br>menos<br>para<br>7 menos)<br><!-- End of picture text -->  
**Segurança (eventos adversos) (seguimento: 6 meses)**  
73  
<!-- Start of picture text -->
GRADE  № de pacientes  Efeito<br>№  Delineamen Risco de  Inconsistên Evidência  Imprecisão  Outras considerações  bupropiona  combinação  Relativo  Absoluto  Certeza da  Importância<br>dos  to do  viés  cia  indireta  evidência<br>de TRN  (95%  (95% CI)<br>estud estudo<br>os  CI)<br>1 ensaios  grave  b não grave  não grave  grave  c nenhu Piper (2009) observou que houve maior proporção de relatos  ⨁⨁ ◯◯ IMPORTANTE<br>clínicos  m<br>de eventos adversos entre os participantes que utilizaram  BAIXA<br>randomiza<br>dos  combinações de TRN (adesivo + pastilha) (n= 262) do que<br>entre os que utilizaram bupropiona (n= 262). Os autores não<br>apresentaram estatística de comparação entre os grupos de<br>tratamento. De forma geral boca seca, alteração no paladar,<br>distúrbios no sono e sonhos anormais foram mais frequentes<br>no grupo bupropiona, enquanto náusea, irritação na pele, na<br>boca e na garganta, soluços, flatulência e dispepsia foram<br>mais frequentes no grupo de combinação de TRN.<br><!-- End of picture text -->  
**95% CI:** Intervalo de confiança; **RR:** Risco relativo

---

<!-- METADADOS: doenca: Tabagismo | secao: **PERGUNTA 2** -->
a. Smith, 2009 não fez cegamento e para Piper, 2009 não houve certeza com relação a esse critério. Não houve certeza com relação à randomização para ambos os estudos e ao sigilo de alocação para Smith, 2009. Contudo, acredita-se que esses problemas metodológicos não possuem grande influência sobre o resultado. b. Não houve certeza sobre randomização e cegamento.  
c. Estudo único, com n pequeno para evidência.  
74

---

