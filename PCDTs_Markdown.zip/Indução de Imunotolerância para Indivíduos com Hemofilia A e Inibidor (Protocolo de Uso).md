<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE -->
PORTARIA CONJUNTA SAES/SECTICS Nº 13, DE 09 DE OUTUBRO DE 2024.  
Aprova o Protocolo de Uso de fator VIII da coagulação na imunotolerância para indivíduos com hemofilia A e inibidor do fator VIII da coagulação sanguínea.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE,  no uso das atribuições que lhes confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024,  
Considerando a necessidade de se estabelecerem os parâmetros sobre o uso de fator VIII da coagulação na imunotolerância para indivíduos com hemofilia A e inibidor do fator VIII da coagulação sanguínea no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos de uso de tecnologias em saúde são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 924/2024 e o Relatório de Recomendação ~~n~~<sup><u>o</u></sup> 927 – Agosto de 2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo de Uso de fator VIII da coagulação na imunotolerância para indivíduos com hemofilia A e inibidor do fator VIII da coagulação sanguínea.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito do uso de fator VIII da coagulação na imunotolerância para indivíduos com hemofilia A e inibidor do fator VIII da coagulação sanguínea, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao implante e uso de fator VIII da coagulação na imunotolerância para indivíduos com hemofilia A e inibidor do fator VIII da coagulação sanguínea.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: ADRIANO MASSUDA -->
CARLOS AUGUSTO GRABOIS GADELHA

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **PROTOCOLO DE USO** -->
FATOR VIII DA COAGULAÇÃO NA IMUNOTOLERÂNCIA PARA INDIVÍDUOS COM HEMOFILIA A E INIBIDOR DO FATOR VIII DA COAGULAÇÃO SANGUÍNEA

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **1. INTRODUÇÃO** -->
As hemofilias são doenças hemorrágicas, de herança genética ligada ao cromossomo X, que se caracterizam pela deficiência do fator VIII (hemofilia A) ou do fator IX (hemofilia B) da coagulação sanguínea. Apesar de clinicamente semelhantes, o diagnóstico diferencial entre as hemofilias A e B é realizado por exames laboratoriais de dosagens específicas da atividade de fator VIII e de fator IX.  
O nível plasmático de atividade coagulante do fator deficiente permite classificar as hemofilias em leve (quando o nível de fator é maior que 5% a 40% ou maior que 0,05 unidades internacionais a 0,40 unidades internacionais [UI/mL]), moderada (de 1% a 5% ou de 0,01 UI/mL a 0,05 UI/mL) ou grave (inferior a 1% ou inferior a 0,01 UI/mL)<sup>1</sup> . A magnitude das manifestações hemorrágicas nas hemofilias é variável, conforme a gravidade do caso. A prevenção ou o tratamento dos episódios hemorrágicos na hemofilia demandam a infusão intravenosa do fator de coagulação deficiente de origem plasmática ou recombinante.  
Uma das possíveis complicações em indivíduos com hemofilia em tratamento é o desenvolvimento de inibidores do fator de coagulação. Esses inibidores são anticorpos neutralizantes da classe IgG direcionados contra os fatores VIII (hemofilia A) e IX (hemofilia B) infundidos (aloanticorpos). Nesses casos, os indivíduos acometidos passam a não responder à infusão do fator de coagulação deficiente e apresentam episódios hemorrágicos de difícil controle<sup>2</sup> . Os inibidores se desenvolvem mais frequentemente em indivíduos com hemofilia grave e após as primeiras infusões de fator de coagulação, em geral até a 50ª infusão. Os fatores de risco sabidamente associados ao desenvolvimento de inibidores do fator de coagulação são o tipo e gravidade da hemofilia (mais comum na hemofilia A grave), tipo de mutação (mais comum nas inversões, mutações sem sentido e grandes defeitos moleculares), intensidade do uso do concentrado de fator de coagulação deficiente e a história familiar de inibidor do fator de coagulação<sup>3–5</sup> . Outros potenciais fatores de risco são a classificação do complexo de histocompatibilidade (HLA), etnia/raça e o tipo de produto utilizado no tratamento (fator de coagulação de origem recombinante ou plasmática)<sup>6</sup> . Entre 20% e 35% dos indivíduos com hemofilia A e entre 1% e 5% dos indivíduos com hemofilia B desenvolvem inibidores do fator de coagulação durante a vida<sup>7</sup> .  
O único tratamento capaz de erradicar os inibidores do fator de coagulação é a imunotolerância, que consiste na infusão regular do concentrado de fator deficiente em altas doses, na tentativa de dessensibilizar o paciente<sup>8,9</sup> . Este tratamento pode durar de semanas a anos<sup>10,11</sup> , sendo realizado principalmente na hemofilia A, e eficaz em 60% a 80% dos casos tratados<sup>12</sup> . Após a erradicação do inibidor do fator de coagulação, o paciente volta a responder ao tratamento de reposição do fator deficiente.  
Este Protocolo visa a estabelecer os critérios para indução de imunotolerância ao fator VIII de coagulação em indivíduos com hemofilia A que tenham desenvolvido inibidores persistentes contra o fator VIII de coagulação. O público-alvo deste Protocolo são profissionais da saúde envolvidos no cuidado integral desses indivíduos, no âmbito da atenção primária e da atenção especializada à saúde, bem como, gestores da saúde, com vistas a subsidiar as decisões clínicas e otimizar a qualidade do cuidado ofertado a esses pacientes.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- D66 Deficiência hereditária do fator VIII  
- D68.3 Transtorno hemorrágico devido a anticoagulantes circulantes

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **3.1. Diagnóstico Clínico** -->
A suspeita clínica de inibidores contra o fator VIII da coagulação ocorre quando um paciente com hemofilia A passa a responder de forma inadequada à reposição com o concentrado de fator VIII da coagulação, seja durante a profilaxia ou durante o tratamento de um sangramento agudo. Em pacientes sem inibidores esta reposição deve ser suficiente para prevenir a quase totalidade dos sangramentos espontâneos, e a controlar rapidamente quadros de sangramento agudo. Qualquer resposta distinta desta deve suscitar a suspeita clínica, e a realização de testes laboratoriais específicos para este fim.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **3.1.1. Diagnóstico laboratorial** -->
A presença do inibidor do fator VIII da coagulação sanguínea é titulada por meio do método Bethesda como Unidades Bethesda (UB). Os inibidores podem ser classificados segundo o título de anticorpos circulantes e a resposta antigênica. De acordo com recomendação do _Factor VIII and Factor IX Subcommittee da International Society of Thrombosis and Haemostasis_ (ISTH), classicamente, deve-se considerar de baixa resposta, os inibidores do fator de coagulação que mantêm níveis iguais ou menores a 5 UB/mL, apesar de constante estímulo com o fator deficiente<sup>1</sup> . Considera-se inibidor do fator de coagulação de alta resposta aquele em que a atividade inibitória seja maior que 5 UB/mL, em qualquer momento da existência do inibidor do fator deficiente de coagulação.<sup>15,16</sup> .

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que preencherem os seguintes critérios:  
- Paciente com hemofilia A congênita com histórico de inibidor do fator VIII de coagulação (pico histórico máximo <  
500 UB/mL) em profilaxia com emicizumabe e um dos critérios abaixo:  
- a) Inibidor persistente, com título ≥ 2 UB/mL;  
- b) Inibidor com título ≥ 2 UB/mL após desafio com infusão de fator VIII.  
Nota: O esquema de desafio com concentrado de fator VIII de coagulação consiste em: infusão de 25 U/kg a 50 U/kg de fator VIII de coagulação (preferencialmente aquele associado ao desenvolvimento do inibidor), seguido pela coleta de nova quantificação de inibidor de fator VIII de coagulação após 1 semanas a 4 semanas desta infusão.  
Paciente com hemofilia A congênita e histórico de inibidor persistente (duas quantificações consecutivas com intervalo  
de 2 a 4 semanas) e de alta resposta e necessidade de agentes de “bypassing”, que não se encontra em uso de profilaxia com emicizumabe.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a qualquer um dos medicamentos neste Protocolo deverão ser excluídos ao uso do respectivo medicamento.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6. TRATAMENTO** -->
É recomendado que os pacientes em uso de emicizumabe que desenvolveram inibidores do fator VIII de coagulação sanguínea incluídos neste Protocolo realizem pelo menos uma tentativa de erradicação do inibidor do fator VIII de coagulação sanguínea por meio da indução da imunotolerância. Para estes pacientes, é recomendado que o início do tratamento de indução de imunotolerância ocorra quando limitações clinicamente relevantes de acesso venoso tenham sido superadas.  
Os pacientes devem apresentar avaliação favorável da equipe multidisciplinar do Centro de Tratamento de Hemofilia  
(CTH), documentada pela assinatura do “Termo de anuência da equipe multiprofissional para tratamento de imunotolerância” (Apêndice 1) quanto às condições do paciente/responsáveis em participarem desta modalidade terapêutica. Além disso, o início da indução de imunotolerância fica condicionado ao acesso ao CTH e ao monitoramento laboratorial do tratamento.  
O tratamento de imunotolerância somente poderá ser iniciado após a liberação do órgão responsável do Ministério da Saúde, mediante a solicitação de inclusão do paciente no Programa de Imunotolerância no Sistema Hemovida Web Coagulopatias (HWC), que é de responsabilidade do CTH. No momento da solicitação, os Apêndice 1 (Termo de anuência da equipe multiprofissional para tratamento da imunotolerância) e Apêndice 2 (Termo de consentimento para tratamento da imunotolerância), devem ser inseridos pelo CTH no Sistema HWC.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.1. Indução de imunotolerância** -->
Diversos protocolos de imunotolerância já foram propostos, com diferentes esquemas e doses<sup>17–19</sup> . Entretanto, até o presente momento, não há um esquema ótimo que seja universalmente recomendado<sup>20–23</sup> .  
A avaliação do fator VIII de coagulação para o tratamento de imunotolerância em dose de 50 UI/kg 3 vezes por semana ou 200 UI/kg/dia em indivíduos classificados como de bom prognóstico (idade inferior a 8 anos, início de imunotolerância antes de 24 meses do diagnóstico de inibidor do fator de coagulação, título de inibidor pré-imunotolerância inferior a 10 UB/mL e pico histórico entre 5 UB/mL e 200 UB/mL) foi conduzida pelo _The International Immune Tolerance Study_<sup>24,25</sup> . Observou-se um número cumulativamente maior de hemorragias no grupo de baixa dose e um tempo médio para resposta aproximadamente 50% menor em pacientes que receberam a dose maior. Contudo não foi demonstrada diferenças de eficácia entre os dois grupos de tratamento, conforme doses adotadas<sup>24,25</sup> .  
Até recentemente, no Sistema Único de Saúde, a indução da imunotolerância era recomendada com um esquema de tratamento com baixas doses de início com 50 UI/kg, 3 vezes por semana<sup>26</sup> ; com possibilidade de escalonamento para doses mais elevadas e frequência de uso diária diante de sinais de resposta insatisfatória com o esquema de baixas doses. Contudo, a recomendação atual é de realizar a indução da imunotolerância com o regime de baixas doses (50 UI/kg, 3 vezes por semana), sem previsão de escalonamento. Além disso, o tempo para avaliação máxima de resposta foi modificado de 33 meses para 18 meses.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.2. Intercorrências hemorrágicas e profilaxia concomitante** -->
Até recentemente pacientes em imunotolerância que apresentavam sangramentos recorrentes tinham como única estratégia terapêutico o uso de agentes de _bypassing_ , que apresentam eficácia reduzida na prevenção destes sangramentos. Com o advento de estratégias terapêuticas não-dependentes da reposição do fator deficiente, como o uso do anticorpo monoclonal biespecífico emicizumabe para o tratamento de pacientes com hemofilia A<sup>27–29</sup> , estes pacientes em imunotolerância passam a apresentar uma alternativa adicional, mais eficaz para profilaxia. Seu mecanismo de ação o torna eficaz para promoção da hemostasia como profilaxia em pacientes com hemofilia A. Os resultados de eficácia do emicizumabe mostraram redução substancial da taxa anualizada de sangramentos e aumento da proporção de pacientes com sangramento zero, de ordem de grandeza semelhante às observadas nos regimes de profilaxia primária em pacientes sem inibidores<sup>30–32</sup> .

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.3. Profilaxia durante o tratamento de imunotolerância** -->
A profilaxia de sangramentos durante o tratamento de imunotolerância será feita com emicizumabe, nos casos que atendem os critérios de inclusão do uso desse medicamento, conforme o Protocolo de Uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea publicado pelo Ministério da  
Saúde. Caso o paciente tenha contraindicação ao uso de emicizumabe, o uso de profilaxia com agentes de _bypassing_ será recomendado apenas para aqueles com alta tendência hemorrágica ao início da imunotolerância, até que se atinja uma titulação de inibidor inferior a 5 UB/mL.  
Ressalta-se que pacientes com alta tendência hemorrágica são aqueles que possuem articulação-alvo ou história de sangramento grave (por exemplo, hemartroses de repetição, hemorragia intracraniana, retroperitonial, de iliopsoas ou síndrome compartimental).  
Nos casos em que houver contraindicação à profilaxia com emicizumabe, o tipo de agente _bypassing_ a ser utilizado deverá considerar principalmente a resposta do paciente ao produto. Entretanto, o concentrado de complexo protrombínico parcialmente ativado deve ser preferencialmente utilizado devido à sua meia-vida mais longa, o que permite seu uso 3 vezes na semana. A dose preconizada de complexo protrombínico parcialmente ativado é de 75 UI/kg, 3 vezes por semana ou em dias alternados. O concentrado de fator VII ativado recombinante somente deve ser utilizado se o paciente não apresenta resposta ao concentrado de complexo protrombínico parcialmente ativado. Neste caso, a dose deve ser de 90 mcg/kg inicialmente 3 vezes na semana, podendo ser aumentado para 5 a 7 vezes na semana. Quando o paciente atingir a titulação de 5 UB/mL ou mediante a redução das hemorragias, o uso profilático de agentes _bypassing_ deverá ser suspenso.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.4. Intercorrências hemorrágicas** -->
Nos pacientes em uso de emicizumabe como profilaxia, as intercorrências hemorrágicas deverão ser tratadas por meio  
de:  
- Infusão de doses elevadas (até duas vezes) do fator VIII de coagulação (o mesmo utilizado para imunotolerância), quando o título de inibidor atingir titulação inferior a 5 UB/mL e o paciente apresentar boa resposta ao uso de fator VIII de coagulação;  
- Infusão de fator VII de coagulação ativado recombinante, quando o título de inibidor for maior que 5 UB/mL ou houver resposta inadequada ao uso de fator VIII de coagulação. Quando indicado o uso de agentes de _bypassing_ e na ausência de resposta ao fator VII de coagulação ativado recombinante, o complexo protrombínico parcialmente ativado poderá ser usado na dose máxima de 50 U/kg, não ultrapassando a dose diária máxima de 100U/kg. Neste caso, atenção redobrada deve ser dada ao risco de complicações trombóticas/microangiopáticas.  
Nota: informações adicionais sobre o tratamento de intercorrências hemorrágicas em pacientes em uso de emicizumabe podem ser obtidas no item sobre “Tratamento de episódios hemorrágicos durante o uso de emicizumabe”, do Protocolo de Uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea publicado pelo Ministério da Saúde.  
Nos pacientes que não utilizam emicizumabe como profilaxia, as intercorrências hemorrágicas devem ser tratadas conforme estabelecido no Manual de Diagnóstico e Tratamento de Inibidor em Pacientes com Hemofilia Congênita, aprovado na Portaria SAES/MS n<sup>o.</sup> 11, de 05 de janeiro de 2022<sup>33</sup> , com agentes de _bypassing_ .

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.5. Critérios de definição de desfecho clínico** -->
Os principais preditores de resposta do tratamento de indução de imunotolerância são a presença de título de inibidor do fator VIII de coagulação inferior a 10 UB/mL ao início da imunotolerância e o pico histórico máximo de inibidor do fator VIII de coagulação menor que 200 UB/mL<sup>34</sup> . Contudo, os resultados são conflitantes quanto à idade e ao intervalo de tempo decorrido entre o diagnóstico do inibidor do fator VIII de coagulação e o início da imunotolerância<sup>35,36</sup> . O tipo de mutação também parece estar associado à resposta à imunotolerância<sup>37</sup> .

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.6. Sucesso terapêutico total** -->
É considerado como em sucesso terapêutico total o paciente que apresentar todos os seguintes critérios:  
- Negativação do título de inibidor do fator VIII de coagulação pelo método de Bethesda modificado, isto é, titulação do inibidor do fator VIII de coagulação inferior a 0,6 UB/mL por pelo menos duas vezes consecutivas em um período mínimo de 2 meses entre cada dosagem; e  
- Teste de recuperação normal de fator VIII, isto é, 66% dos valores esperados; e  
- Vida média normal do fator VIII de coagulação, isto é, vida média de 6 horas, avaliado após período de 72 horas de  
_wash-out_ de fator VIII de coagulação; e  
- Ausência de resposta anamnéstica à exposição ao fator VIII de coagulação.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.7. Sucesso terapêutico parcial** -->
É considerado como em sucesso terapêutico parcial o paciente que apresentar resposta clínica à infusão de fator VIII de coagulação, e pelo menos um dos seguintes critérios:  
- Título de inibidor do fator VIII de coagulação superior a 0,6 UB/mL e inferior a 2 UB/mL pelo método de Bethesda  
- modificado;  
- Teste de recuperação do fator VIII de coagulação inferior a 66% dos valores esperados;  
- Vida média do fator VIII de coagulação inferior a 6 horas, avaliado após período de 72 horas de _wash-out_ de fator VIII  
- de coagulação.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.8. Falha terapêutica** -->
É considerado como em falha terapêutica o paciente que apresentar pelo menos um dos seguintes critérios:  
- Ausência de critério para sucesso total ou parcial após 18 meses de tratamento;  
- Pico de inibidor do fator VIII de coagulação acima de 200 UB/mL em qualquer momento durante a imunotolerância.  
Nota 1: para os pacientes que iniciaram a imunotolerância antes da vigência deste Protocolo, o período máximo de tratamento será de 18 meses desde o início do uso de emicizumabe, ou 33 meses desde o início da imunotolerância, o que vier antes.  
Nota 2: a sistemática laboratorial para ensaios de atividade de fator VIII de coagulação e pesquisa/quantificação de inibidores durante o uso de emicizumabe difere da usual e está descrita no Protocolo de Uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.9. Tratamento em populações específicas** -->
 Uso em idosos, crianças e outros grupos de risco:  não existe recomendação especial de dosagem para idosos e outras categorias de risco.  
 Mulheres grávidas ou amamentando: não foi estabelecida a segurança do fator VIII de coagulação nessa população. Recomenda-se a administração de Fator VIII de Coagulação durante a gravidez e lactação humana somente se indicado.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.10. Medicamentos** -->
- Fator VIII de coagulação: pó para solução injetável de 250 UI, 500 UI, 1.000 UI;  
- Fator VIII de coagulação recombinante: pó para solução injetável de 250 UI, 500 UI, 1.000 UI.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.11. Esquemas de administração** -->
A indução de imunotolerância deverá ser feita, por via intravenosa, com o seguinte esquema:  
- Fator VIII de coagulação (plasmático ou recombinante) 50 UI/kg/dia, 3 vezes por semana.  
A imunotolerância deverá, sempre que possível, ser realizada com o fator VIII de coagulação com o qual o paciente desenvolveu o inibidor, seja este de origem plasmática ou recombinante.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **6.12. Critérios de interrupção** -->
O tratamento de imunotolerância deverá ser interrompido quando for caracterizada a falha terapêutica, conforme definido anteriormente, ou em casos de abandono do tratamento. Será caracterizado como abandono de tratamento o não-comparecimento do paciente ao CTH para infusão do fator VIII de coagulação por tempo superior a 30 dias consecutivos ou a não-infusão domiciliar pelo mesmo período, sem motivo justificável.  
Os pacientes devem ser informados sobre os sinais precoces de reações de hipersensibilidade incluindo erupções cutâneas, urticária generalizada, sensação de opressão torácica, respiração ruidosa, hipotensão e anafilaxia. Na presença de qualquer destes sintomas, deve-se interromper a infusão imediatamente. Em caso de choque devem ser seguidas as recomendações em vigor para o tratamento do choque.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **7. MONITORAMENTO** -->
O monitoramento da resposta a indução de imunotolerância deve ser realizado por meio da avaliação clínica e laboratorial a qual deve incluir o nível plasmático de atividade coagulante do fator VIII, além do teste de triagem e titulação do inibidor do fator VIII de coagulação pelo método de Bethesda modificado, teste de recuperação de fator VIII de coagulação e meia-vida do fator VIII (Apêndice 3).  
A quantificação do inibidor deverá ser realizada mensalmente nos primeiros 6 meses de tratamento e, em seguida, a cada 2 meses até que o paciente atinja sucesso terapêutico total ou apresente critério de falha ao tratamento. Caso o tratamento seja realizado em nível domiciliar, o paciente deverá retornar, ao CTH, os frascos do fator VIII de coagulação vazios, assim como equipo, agulhas e seringas utilizados. O paciente deverá ainda, a cada retorno, apresentar ao CTH um registro de infusões domiciliares e de eventos hemorrágicos, conforme modelo de registro sugerido por este Protocolo (Apêndice 4) ou outro similar fornecido pelo CTH.  
Recomenda-se que a equipe multiprofissional monitore os pacientes em tratamento de imunotolerância para garantir a adesão do paciente e da família ao tratamento e identificar precocemente a não-adesão e abandono.  
O medicamento utilizado no protocolo de imunotolerância, que é o concentrado de fator VIII da coagulação, é bem tolerado por pacientes com hemofilia, de modo que os eventos adversos relacionados especificamente à imunotolerância estão relacionados à dificuldade de obtenção de acesso venoso para punções periódicas, em particular em crianças abaixo de 6 anos.  
Não há interações medicamentosas relevantes especificamente relacionadas a este protocolo. Entretanto, o fator VIII de coagulação não deve ser combinado com outros medicamentos durante a infusão. Pelo fato de o fator VIII ser um medicamento procoagulante, as doses devem seguir as diretrizes de tratamento de pacientes com hemofilia, particularmente quando utilizado com outros agentes hemostáticos.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **7.1. Monitoramento de recidiva do inibidor** -->
Em casos de sucesso terapêutico, o monitoramento da recidiva de inibidor deverá ser feito após eventual reexposição ao  
fator VIII de coagulação, após 2 semanas a 4 semanas do término de cada período de tratamento.  
Nos casos de exposição mais intensiva (cirurgias e sangramentos graves) o monitoramento laboratorial deve ser feito mais frequentemente, a cada 3 dias a 5 dias.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **7.2. Conduta após o término do protocolo de imunotolerância** -->
Se houver falha terapêutica, o paciente em uso de emicizumabe deve manter o uso do medicamento, conforme respectivo Protocolo de Uso.  
Se houver resposta completa ou parcial ao tratamento, a decisão de migração para a profilaxia com fator VIII de coagulação ou manutenção do emicizumabe (segundo critérios e recomendações do Protocolo de Uso de emicizumabe para tratamento de indivíduos com hemofilia A moderada e grave e inibidores do fator VIII da coagulação sanguínea) deve ser realizada em conjunto pela equipe do CTH, paciente e familiares, sendo a opinião dos dois últimos prioritária para a decisão.  
Uma vez atingido o sucesso no tratamento de indução de imunotolerância, e caso o paciente atenda aos critérios para a profilaxia com emicizumabe, não se recomenda utilizar o fator VIII de coagulação para manutenção da imunotolerância.  
A saída do paciente do protocolo e a sua migração para a profilaxia com fator VIII de coagulação ou com emicizumabe deve ser comunicada ao Ministério da Saúde por meio do sistema HWC. Os resultados dos testes de recuperação e de vida média do fator VIII de coagulação, assim como as dosagens de inibidor do fator VIII de coagulação, devem ser inseridos no sistema HWC.  
Em caso de abandono do tratamento por parte do paciente ou responsável, um relatório deverá ser enviado à CoordenaçãoGeral de Sangue e Hemoderivados (CGSH) pelo CTH, contendo justificativa detalhada e documentação (com assinatura do paciente ou responsável) do conhecimento relativo às consequências do abandono da terapia de imunotolerância.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **8. REGULAÇÃO E CONTROLE** -->
Devem ser observados os critérios de inclusão e exclusão dos indivíduos neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pacientes com hemofilia A devem ser atendidos em CTH para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Devido à complexidade do cuidado de pacientes com hemofilia e inibidor do fator VIII de coagulação e do tratamento de imunotolerância, a prestação da assistência à saúde a esses indivíduos deve ser realizada nos CTH de maior complexidade (centro de referência do Estado) por equipe experiente no cuidado destes pacientes.  
Nos casos excepcionais em que o paciente for acompanhado no centro de hemofilia regional, o centro de referência do Estado deverá se responsabilizar pelo treinamento, monitoramento e supervisão do tratamento de imunotolerância pela equipe técnica daquele centro, prestando consultorias periódicas, sempre que necessário.  
É responsabilidade do CTH proporcionar a realização de exames rotineiros de coagulação, além de dosagem de fator VIII de coagulação, teste de triagem e titulação do inibidor pelo método de Bethesda modificado, teste de recuperação de fator VIII de coagulação e meia-vida do fator VIII. As amostras para realização destes testes poderão ser enviadas a um laboratório conveniado, sendo responsabilidade do gestor local a garantia das condições de boas práticas laboratoriais, assim como o estabelecimento de acordos que viabilizem esta colaboração.  
Pacientes com hemofilia A devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de efeitos adversos.  
Deve ser considerada a vacinação apropriada (hepatite A e B) dos pacientes que recebem de maneira regular ou  
repetidamente concentrados de fatorVIII derivados do plasma humano. Recomenda-se que, a cada administração de Fator VIII de Coagulação, seja registrado o nome e número de lote do produto para manter a rastreabilidade entre o paciente e o produto.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **9. REFERÊNCIAS** -->
1. Blanchette VS, Key NS, Ljung LR, Manco-Johnson MJ, van den Berg HM, Srivastava A. Definitions in hemophilia: Communication from the SSC of the ISTH. Journal of Thrombosis and Haemostasis. 2014 Nov 1;12(11):1935–9.  
2. Ljung R, Auerswald G, Benson G, Dolan G, Duffy A, Hermans C, et al. Inhibitors in haemophilia A and B:  
Management of bleeds, inhibitor eradication and strategies for difficult-to-treat patients. Eur J Haematol. 2019 Feb 1;102(2):111–22.  
3. Schwaab R, Brackmann HH, Meyer C, Seehafer J, Kirchgesser M, Haack A, et al. Haemophilia A: Mutation  
type determines risk of inhibitor formation. Thromb Haemost. 1995;74(6):1402–6.  
4. Gouw SC, Van Der Bom JG, Van Den Berg HM. Treatment-related risk factors of inhibitor development in  
previously untreated patients with hemophilia A: The CANAL cohort study. Blood. 2007 Jun 1;109(11):4648–54.  
5. Goodeve AC, Peake IR. The molecular basis of hemophilia A: Genotype - Phenotype relationships and  
inhibitor development. Semin Thromb Hemost. 2003;29(1):23–30.  
6. Peyvandi F, Garagiola I, Young G. The past and future of haemophilia: diagnosis, treatments, and its  
complications. The Lancet. 2016 Jul 9;388(10040):187–97.  
7. Hill FGH. The incidence of factor VIII and factor IX inhibitors in the hemophilia population of the UK and  
their effect on subsequent mortality, 1977-99. Journal of Thrombosis and Haemostasis. 2004 Jul;2(7):1047–54.  
8. Aledort LM, Kroner B, Mariani G. Immune tolerance induction: Treatment duration analysis and economic  
considerations. Haematologica. 2000;85(10 SUPPL.):83–5.  
9. Berntorp E, Shapiro A, Astermark J, Blanchette VS, Collins PW, Dimichele D, et al. Inhibitor treatment in  
haemophilias A and B: Summary statement for the 2006 international consensus conference. Haemophilia. 2006 Dec;12(SUPPL. 6):1–7.  
10. Colowick AB, Bohn RL, Avorn J, Ewenstein BM. Immune tolerance induction in hemophilia patients with  
inhibitors: Costly can be cheaper. Blood. 2000 Sep 1;96(5):1698–702.  
11. Di Minno MN, Di Minno G, Di Capua M, Cerbone AM, Coppola A. Cost of care of haemophilia with  
inhibitors. Haemophilia. 2010 Jan;16(1).  
12. DiMichele DM, Hoots WK, Pipe SW, Rivard GE, Santagostino E. International workshop on immune  
tolerance induction: Consensus recommendations. Haemophilia. 2007 Jul;13(SUPPL. 1):1–22.  
13. Conitec. Relatório de recomendação No. 841/23 [Internet]. 2023 [cited 2024 May 11]. Available from: chrome-  
extension://efaidnbmnnnibpcajpcglclefindmkaj/https://www.gov.br/conitec/pt-  
br/midias/relatorios/2023/relatorio_final_emicizumabe_com-inibidores_hemofilia_841_2023.pdf  
14. Portaria SAES/MS n<sup>o</sup> 1.114, de 16 de novembro de 2021 [Internet]. 2021 [cited 2024 May 11]. Available from:  
<u>https://www.gov.br/saude/pt-br/composicao/se/dgip/air-e-melhoria-normativa/dispensas/2021/portaria-saes-no-1-114-de-16de-novembro-de-2021</u>  
15. Collins PW, Chalmers E, Hart DP, Liesner R, Rangarajan S, Talks K, et al. Diagnosis and treatment of factor  
VIII and IX inhibitors in congenital haemophilia: (4th edition). Br J Haematol. 2013 Jan;160(2):153–70.  
16. Collins P, Chalmers E, Alamelu J, Hay C, Liesner R, Makris M, et al. First-line immune tolerance induction  
for children with severe haemophilia A: A protocol from the UK Haemophilia Centre Doctors’ Organisation Inhibitor and  
Paediatric Working Parties. Haemophilia. 2017 Sep 1;23(5):654–9.  
17. Brackmann HH, Oldenburg J, Schwaab R. Immune Tolerance for the Treatment of Factor VIII Inhibitors ‐ Twenty Years’ ‘Bonn Protocol.’ Vox Sang. 1996 Feb;70(s1):30–5.  
18. Oldenburg J, Schwaab R, Brackmann HH. Induction of immune tolerance in haemophilia A inhibitor patients  
by the “Bonn Protocol”: Predictive parameter for therapy duration and outcome. Vox Sang. 1999;77(SUPPL. 1):49–54. 19. Mauser-Bunschoten EP, Nieuwenhuis HK, Roosendaal G, Van Den Berg HM. Low-dose immune tolerance  
induction in hemophilia A patients with inhibitors. Blood. 1995 Aug 1;86(3):983–8.  
20. Kroner BL. Comparison of the International Immune Tolerance Registry and the North American Immune  
Tolerance Registry. Vox Sang. 1999;77(SUPPL. 1):33–7.  
21. Mariana G, Kroner B, Miller RT, Ewing NP, Butler R, Morfini M, et al. Immune tolerance in hemophilia with  
factor VIII inhibitors: Predictors of success. Haematologica. 2001;86(11):1186–93.  
22. Lenk H, Brackmann HH, Auerswald G, Pollmann H, Auberger K, Scharrer I, et al. The German registry of  
immune tolerance treatment in hemophilia - 1999 Update. Haematologica. 2000;85(10 SUPPL.):45–7.  
23. DiMichele D. The North American Immune Tolerance Registry: Contributions to the thirty-year experience  
with immune tolerance therapy. Haemophilia. 2009 Jan;15(1):320–8.  
24. Hay CRM, DiMichele DM. The principal results of the International Immune Tolerance Study: A randomized  
dose comparison. Blood. 2012 Feb 9;119(6):1335–44.  
25. Dimichele DM, Hay CRM. The international immune tolerance study: A multicenter prospective randomized  
trial in progress [2]. Journal of Thrombosis and Haemostasis. 2006 Aug;4(10):2271–3.  
26. PORTARIA CONJUNTA N<sup>o</sup> 15, DE 26 DE AGOSTO DE 2021 [Internet]. 2021 [cited 2024 May 11].  
Available from: https://bvsms.saude.gov.br/bvs/saudelegis/Saes/2021/poc0015_30_08_2021.html 27. Shima M, Hanabusa H, Taki M, Matsushita T, Sato T, Fukutake K, et al. Factor VIII–Mimetic Function of  
Humanized Bispecific Antibody in Hemophilia A. New England Journal of Medicine. 2016 May 26;374(21):2044–53.  
28. Nogami K, Shima M. New therapies using nonfactor products for patients with hemophilia and inhibitors.  
Blood. 2019 Jan 31;133(5):399–406. 29. Arruda VR, Doshi BS, Samelson-Jones BJ. Novel approaches to hemophilia therapy: Successes and  
challenges. Blood. 2017 Nov 23;130(21):2251–6.  
30. Oldenburg J, Mahlangu JN, Kim B, Schmitt C, Callaghan MU, Young G, et al. Emicizumab Prophylaxis in  
Hemophilia A with Inhibitors. New England Journal of Medicine. 2017 Aug 31;377(9):809–18.  
31. Mahlangu J, Oldenburg J, Paz-Priel I, Negrier C, Niggli M, Mancuso ME, et al. Emicizumab Prophylaxis in  
Patients Who Have Hemophilia A without Inhibitors. New England Journal of Medicine. 2018 Aug 30;379(9):811–22.  
32. Young G, Liesner R, Chang T, Sidonio R, Oldenburg J, Jiménez-Yuste V, et al. A multicenter, open-label  
phase 3 study of emicizumab prophylaxis in children with hemophilia A with inhibitors. Blood. 2019 Dec 12;134(24):2127– 38. 33. PORTARIA N<sup>o</sup> 11, DE 05 DE JANEIRO DE 2022 [Internet]. 2022 [cited 2024 May 11]. Available from:  
<u>https://bvsms.saude.gov.br/bvs/saudelegis/saes/2022/prt0011_11_01_2022.html#:~:text=Aprovado%20o%20Manual%20de %20Diagn%C3%B3stico,em%20Pacientes%20com%20Hemofilia%20Cong%C3%AAnita.</u>  
34. Oomen I, Camelo RM, Rezende SM, Voorberg J, Mancuso ME, Oldenburg J, et al. Determinants of successful  
immune tolerance induction in hemophilia A: systematic review and meta-analysis. Res Pract Thromb Haemost [Internet]. 2023 Jan 1 [cited 2024 May 11];7(1):100020. Available from: http://www.ncbi.nlm.nih.gov/pubmed/36891524  
35. Coppola A, Santoro C, Tagliaferri A, Franchini M, Di Minno G. Understanding inhibitor development in  
haemophilia A: Towards clinical prediction and prevention strategies. Haemophilia. 2010 Jan;16(SUPPL. 1):13–9.  
36. Camelo RM, Dias MM, Caram-Deelder C, Gouw S, de Magalhães LP, Zuccherato LW, et al. Time between inhibitor detection and start of immune tolerance induction: Association with outcome in the BrazIT study. Journal of Thrombosis and Haemostasis. 2022 Nov 1;20(11):2526–37.  
37. Coppola A, Margaglione M, Santagostino E, Rocino A, Grandone E, Mannucci PM, et al. Factor VIII gene (F8) mutations as predictors of outcome in immune tolerance induction of hemophilia A patients with high-responding inhibitors. Journal of Thrombosis and Haemostasis. 2009 Nov;7(11):1809–15.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **APÊNDICE 1** -->
TERMO DE ANUÊNCIA DA EQUIPE MULTIPROFISSIONAL PARA TRATAMENTO DA IMUNOTOLERÂNCIA  
A equipe multiprofissional abaixo discriminada está de acordo e aprovou a inclusão do paciente ____________________  
___________________________________________________________________________________, data de nascimento: ____/_____/______,  filho de (nome da mãe) _________________________________________________________________,  
no programa de imunotolerância. Ao assinar este documento, a equipe assume que o paciente preencheu todos os critérios de  
inclusão do paciente no programa, de acordo com o protocolo vigente do Ministério da Saúde.  
|**Profissional**|**Nome**|**Registro no Conselho**<br>**(n**<sup>**o**</sup>**)**|**Data**|**Assinatura**|
|---|---|---|---|---|
|Médico (a)|||||
|Enfermeiro (a)|||||
|Assistente social|||||
|Psicólogo (a)|||||
|Farmacêutico (a)|||||  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: TERMO DE CONSENTIMENTO PARA TRATAMENTO DA IMUNOTOLERÂNCIA -->
Nome completo do paciente: _____________________________________________________________________________  
Data de nascimento: ___/___/______  
Número do registro no Hemovidaweb Coagulopatias: __________________________________________________________  
Nome do Centro de Hemofilia onde o paciente está cadastrado: __________________________________________________  
Nome da mãe: _________________________________________________________________________________________  
Nome do pai: __________________________________________________________________________________________

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **O que é inibidor e como ele interfere no meu tratamento da hemofilia?** -->
Os inibidores são anticorpos que são produzidos pelo paciente com hemofilia contra o fator VIII infundido. É uma complicação da hemofilia e pode acontecer em até 35% dos pacientes com hemofilia A, sendo mais frequente em pacientes com hemofilia A grave. Os pacientes que desenvolvem inibidor passam a não responder bem a infusão de fator VIII e, neste caso o sangramento dura mais tempo. Em alguns casos, as hemorragias não melhoram com a infusão de fator VIII e o paciente precisa usar outros medicamentos para controle dos sangramentos, que podem, em algumas situações, ser menos eficazes que o fator VIII.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **O que é imunotolerância?** -->
A imunotolerância é um tratamento de “dessensibilização” do inibidor que se desenvolveu contra o fator VIII. A imunotolerância que está sendo oferecida a você/seu filho consiste na infusão frequente de fator VIII, em geral associada a outros medicamentos que previnem os sangramentos.  
**Por que a imunotolerância pode ser benéfica para meu tratamento?**  
Os tratamentos usados para prevenir sangramentos em pacientes com inibidores podem ser menos eficazes que o concentrado de fator VIII, particularmente no caso de sangramentos graves ou cirurgias. É para restaurar a capacidade de resposta ao fator VIII nestes pacientes que a imunotolerância está indicada.  
**Quem pode participar da imunotolerância?**  
Poderão participar da imunotolerância todos os pacientes com hemofilia A que apresentam inibidor persistente.  
**Como será feito o acompanhamento do tratamento?**  
O paciente deverá ser avaliado periodicamente pelo médico até a suspensão da imunotolerância (que pode durar até cerca de 1 ano e meio). Durante o tratamento de imunotolerância, o teste de dosagem do inibidor será realizado com frequência no centro de hemofilia, de acordo com orientação médica. As consultas, orientações e coletas de sangue para exames devem ser rigorosamente seguidas pelo paciente.  
A cada visita médica, o paciente deverá trazer a ficha de uso do fator de coagulação devidamente preenchida com todas as informações solicitadas. Caso o tratamento seja realizado na casa do paciente, ele deverá retornar ao centro os frascos vazios dos concentrados de fator, assim como equipo, agulhas e seringas usadas.  
**Quais são as possibilidades de resultados do tratamento e como isso influencia meu tratamento no futuro?**  
O tratamento pode ter sucesso total, parcial ou não ter sucesso, não sendo possível prever antecipadamente este resultado. Caso o tratamento resulte em sucesso total ou parcial, isto é, o fator VIII volte a ter efeito, você poderá usar este medicamento (concentrados de fator VIII) em caso de sangramentos agudos ou cirurgias. Independentemente do resultado do tratamento, o paciente poderá continuar usando o tratamento padrão para prevenção de inibidores disponibilizado pelo Ministério da Saúde que é atualmente o emicizumabe.  
**Quais são os riscos da imunotolerância para o paciente?**  
Quando a imunotolerância é feita conjuntamente ao tratamento de profilaxia de sangramentos com emicizumabe, os riscos de sangramentos ficam bastante reduzidos. Assim, o maior risco da imunotolerância são aqueles relacionados à maior frequência das infusões endovenosas de fator VIII, que consistem em acidentes de punção. Por último, existe o risco de infecções por agentes transmitidos pelo sangue caso o paciente esteja sendo tratado com fator de origem plasmática, embora atualmente este risco seja desprezível para os agentes infecciosos conhecidos.  
**O que acontece se o paciente se recusar a fazer o tratamento da imunotolerância?**  
O paciente que não quiser fazer o tratamento continuará a ser atendido normalmente no centro de hemofilia, independentemente da concordância ou não fazer o tratamento de imunotolerância. O acesso ao tratamento profilático com emicizumabe será disponibilizado para todos os pacientes com inibidores que preencham os critérios exigidos pelo Protocolo de uso de emicizumabe para pacientes com inibidores. No entanto, é importante destacar que se os títulos de inibidor continuarem elevados, o paciente poderá perder a oportunidade de utilizar o concentrado de fator VIII em caso de sangramentos mais graves ou cirurgias, devendo usar nestes casos o concentrado de fator VII ativado recombinante, cuja eficácia é inferior à do fator VIII.  
Ao recusar este tratamento, o paciente ou responsável declara que a ele foi dada a oportunidade de uso, que foi por ele recusada, não cabendo ao Ministério da Saúde nem ao centro de hemofilia serem responsabilizados por esta recusa no futuro. A qualquer momento, caso o paciente ou responsável mude de ideia, eles poderão solicitar inclusão no tratamento de imunotolerância.  
Ao assinar este documento, o paciente/responsável declara que:  
- Foi devidamente orientado e compreendeu o que é imunotolerância e qual é a sua indicação;  
- Está ciente dos benefícios, das potenciais complicações do tratamento e de suas responsabilidades quanto  
ao uso e retorno de informações;  
 Compromete-se a: cumprir todas as regras do tratamento, incluindo comparecer às consultas agendadas, coletar sangue para exames, devolver ao centro todo material das infusões domiciliares (frascos, equipos, seringas e agulhas) e não suspender o tratamento sem recomendação médica.  
- (   ) Sim, aceito participar.  
- (   ) Não, não aceito participar (nesse caso preencher o motivo abaixo)  
|Motivo: __________________________________________________________________________________<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________<br>_________________________________________________________________________________________<br>Local e data:__________________________________________, __ de ___________________ de _________|
|---|
|Nome legível do paciente ou responsável: _______________________________________________________<br>_________________________________________________________________________________________|
|Assinatura:________________________________________________________________________________|

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: AVALIAÇÃO LABORATORIAL DA IMUNOTOLERÂNCIA PARA TRATAMENTO DE PACIENTES COM HEMOFILIA A E INIBIDOR -->
Para o acompanhamento do tratamento de imunotolerância (IT), três testes são utilizados: (1) Quantificação de inibidor, (2) Teste de recuperação _in vivo_ (IVR), e (3) Vida-média de fator VIII. Neste material abordaremos a metodologia de cada um dos testes e os parâmetros de avaliação que devem ser considerados para determinação do sucesso ou não do protocolo de IT. Conforme detalhado no “Protocolo de uso de emicizumabe por pacientes com hemofilia A e inibidores do fator VIII”, o emicizumabe interfere nos testes coagulométricos de dosagem da atividade de fator VIII, que estão na base dos testes aqui elencados. Desta forma, os princípios gerais relacionados ao tipo de amostra e ao uso de reagentes e métodos adequados para realização destes testes em pacientes em uso de emicizumabe devem ser aplicados nos três testes listados a seguir (detalhes no protocolo citado anteriormente). <u>De forma resumida, qualquer teste que envolva a dosagem da atividade do fator VIII em pacientes em uso de emicizumabe deve ser baseado em metodologia cromogênica, com reagentes bovinos.</u>

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: 1. **Quantificação de inibidor de fator VIII** -->
Deve ser feita utilizando método de Bethesda, modificado:  
 **Método Bethesda:** A versão original ou o método clássico de Bethesda envolve a mistura da amostra do paciente com um mesmo volume de _pool_ de plasma normal. Como a maior parte dos anticorpos são tempo e temperatura dependentes, a mistura deve ser incubada por 2 horas a 37°C antes de se realizar a dosagem de fator VIII coagulante (FVIII:C). Simultaneamente, um plasma com nível FVIII:C conhecido é misturado com o tampão diluente para uma análise em paralelo (Figura 1. A).  
 **Método Nijmegen (Bethesda modificado):** A variação de Nijmegen do método de Bethesda envolve duas modificações (Figura 1. B): (1) o _pool_ de plasma normal é tamponado e estabilizado com tampão imidazol e (2) o plasma controle é misturado com o plasma deficiente em fator VIII ao invés de tampão. Estas modificações, além de diminuir a possibilidade de resultado falso positivo, reduzem o coeficiente de variação do teste comparado com o teste clássico de Bethesda, melhorando, assim, a sua confiabilidade.  
**Figura 1** . Ilustração esquemática dos testes de Bethesda (A) e Bethesda modificado por Nijmegen (B)  
<!-- Start of picture text -->
A Teste Classico de Bethesda<br>maePlasma |17 tif[omyTT Misturacewema50/5017 \\/ BissTampao<br>aTeste FVIIIae<br>B Teste de Bethesda<br>modificado por Nijmegen<br>Plasma 1 ty Fimemep\ Plasma<br>[Reagomec]pocence W \fy YeaterrnavePRD \(|  WeReagents<br>"| Mistura 50/50 "| 8]<br>XK. Iana’sxeeback 7<br>Teste FVIII<br><!-- End of picture text -->  
O mesmo protocolo poderá ser utilizado para a **determinação do inibidor de fator IX** , mas o tempo de incubação para esta determinação poderá ser de apenas 10 minutos, uma vez que o inibidor de fator IX não apresenta caráter tempo-dependente.  
- 1.1. **Técnica para realização do teste Bethesda Modificado por Nijmegen**  
**Preparo do plasma Controle (mistura 1):**  
- Preparar o _pool_ de plasma normal tamponado (reagente A), misturando 1 parte de _pool_ de plasma normal  
- com 1 parte de tampão imidazol (volume/volume)  
- Mistura 1: misturar 1 parte do _pool_ de plasma normal tamponado (reagente A) com 1 parte de plasma  
- deficiente em FVIII (reagente B) (volume/volume).  
**Preparo da amostra-teste:**  
- Mistura 2: misturar 1 parte do plasma do paciente (reagente C) com 1 parte de pool de plasma normal  
- tamponado (reagente A) (volume/volume)  
- Repetir o procedimento anterior a fim de obter diluições 1:2, 1:4, 1:8 do plasma do paciente. Caso haja  
- suspeita de inibidor de alto título, estas diluições podem ser aumentadas.  
- **Análise:**  
- Incubar as misturas 1 e 2 por 2 horas a 37ºC  
- Quantificar a atividade de FVIII.  
- **Cálculo da Atividade do Inibidor:**  
- Cálculo da atividade de fator residual: o valor nominal de FVIII de cada diluição (mistura 2) deverá ser  
dividido pelo valor de FVIII encontrado no plasma controle (mistura 1) e multiplicado por 100.  
- A atividade residual de FVIII versus a diluição é plotada em papel mono – log em uma escala aritmética (ver  
- Figura 2).  
Por definição, uma unidade Bethesda corresponde à quantidade de inibidor capaz de neutralizar 50% da atividade de fator VIII plasmático, após incubação por 2 horas a 37ºC. A atividade residual de 100% é o mesmo que 0% de unidades Bethesda, sendo possível obter um gráfico que tenha correlação entre atividade de fator VIII residual e o título de inibidor (Figura 2). É importante notar que o título de inibidor deverá ser plotado em um gráfico quando a atividade de fator residual estiver entre 25% e 75%.  
**Figura 2** . Exemplo 1 do cálculo da atividade residual do fator VIII.  
<!-- Start of picture text -->
Tlustracao grafica da atividade coagulante de FVII<br>FV<br>Residual |Diluicao Bethesda<br>at” prem Pe fs es [ns<br>75 mp} a | 120 | 55 [osrx20| 17.4 |<br>ad 0.45 x 40<br>Hl H<br>! i i<br>10 : ; ;<br>1.0 2.0<br>Unidade Bethesdapor ml de plasma<br>Ref: WFH Laboratory Sciences Commitiee<br><!-- End of picture text -->  
Os pontos são plotados em um gráfico log - linear com 100%, 50% e 25% de atividade residual, correspondendo a 0, 1 e 2 Unidades Bethesda, respectivamente. No exemplo anterior o plasma A é testado nas diluições 1:10, 1:20 e 1:40. O título final é obtido multiplicando-se o valor obtido pelo fator de diluição correspondente. Notar que as amostras evidenciaram unidades semelhantes de inibidor nas diversas diluições. Este resultado é o mais frequentemente encontrado. No entanto, como a cinética de reação dos anticorpos pode ser variável, títulos muito diferentes de inibidores podem ser obtidos numa mesma amostra em diluições diferentes (Figura 3). O exemplo a seguir demonstra esse cenário.  
**Figura 3** . Exemplo 2 do cálculo da atividade residual do fator VIII.  
<!-- Start of picture text -->
Tlustracao grafica da atividade coagulante de FVII<br>FYO<br>Residual (%)<br>100 FVII% |Unidades X | Unidades<br>Residual |Diluicdo Bethesda<br>10 : ;<br>1.0 2.0<br>Unidades Bethesdapor ml de plasma<br>Ref: WFH Laboratory Sciences Commitiee<br><!-- End of picture text -->  
Em casos como este o resultado deve ser baseado na menor titulação, ou seja, 1:10. **Valores menores que 0,6 UB/mL de plasma são considerados negativos** . No entanto, é importante que se estabeleça o valor de referência negativo em cada laboratório, através da determinação plasmática de inibidor de FVIII:C em um número representativo de indivíduos normais.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: 2. **Testes de recuperação** **_in vivo_ do fator VIII e vida-média do fator VIII** -->
Para o acompanhamento de resposta ao tratamento de IT estes dois testes são fundamentais, uma vez que os anticorpos circulantes não-inibitórios podem estar presentes ainda que a quantificação do inibidor esteja negativa, isto é, menor que 0,6 UB/mL. Estes inibidores podem reduzir a recuperação do FVIII no plasma e encurtar a vida-média do FVIII.  
O teste de recuperação in vivo expressa a relação ou a porcentagem da atividade máxima do FVIII observada no plasma após a infusão de concentrado de fator VIII exógeno por Kg de peso do paciente. O cálculo da expectativa do nível de FVIII: C é baseado na observação da capacidade de 1UI de FVIII infundido por Kg do peso corpóreo, prover 0.02 UI/mL de FVIII:C na circulação. Portanto, o princípio do teste envolve a comparação do valor teórico do FVIII administrado com o valor esperado da recuperação deste fator no plasma do paciente. O teste de recuperação in vivo pode ser baseado na atividade de FVIII considerando o peso corpóreo (relação - IVR), ou no volume plasmático (%). O cálculo baseado no peso corpóreo tem mostrado preferência nos estudos de farmacocinética para teste de recuperação.  
A vida-média refere-se ao tempo despendido para que um medicamento reduza sua atividade em 50%, sendo este tempo dependente do medicamento administrado e da resposta individual.  
Para o teste de recuperação in vivo e a vida-média do FVIII é necessário a determinação da atividade do FVIII:C em três etapas e em sete tempos distintos:  
1. Coleta FVIII:C e quantificação de inibidor antes da administração de fator,  
2. Coletas aos 15 minutos, 30 minutos e 60 minutos após a administração do fator para o cálculo do teste de recuperação  
do fator VIII.  
3. Coleta 3 horas, 6 horas e 24 horas após a administração do fator, para o cálculo da vida-média do fator VIII.  
Para garantir a qualidade dos resultados e não permitir que os mesmos sejam subestimados, alterando assim toda a análise, é recomendável que o teste de FVIII:C seja determinado através de uma curva de calibração produzida com amostra padrão comercial conhecida como calibrador, em que o valor do FVIII:C é conhecido e preciso. Esta curva de calibração deverá ser validada para utilização apenas quando houver resultados de controle comercial normal e patológico dentro dos valores esperados (coeficiente de variação < 10% em relação à média esperada).

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: 2.1. **Recomendações para realização dos testes recuperação de fator VIII e meia vida de fator VIII na avaliação de imunotolerância** -->
Para a realização do teste de recuperação de FVIII e meia vida de FVIII na avaliação de IT, algumas questões devem ser consideradas antes da coleta das amostras:  
 Considerar que para o teste de recuperação e meia-vida do FVIII, deverá ser programado a coleta de amostras em sete tempos distintos, incluindo uma amostra com 24 horas após a infusão do fator, ou seja, no dia seguinte.  
- O paciente deverá ter pelo menos dois resultados de quantificação de inibidor de FVIII negativos (< 0,6 UB/mL), com  
- pelo menos 30 dias de intervalo entre cada teste.  
- O paciente não deverá ter recebido concentrado de FVIII ou qualquer outro produto que contenha FVIII por pelo menos  
- 72 horas antes da realização dos testes (período de wash-out)  
- No dia da realização do teste de recuperação e meia vida, uma amostra de sangue deverá ser coletada para a  
- determinação do FVIII:C e da quantificação de inibidor de FVIII antes da infusão do concentrado de fator VIII.  
- Para os testes de recuperação e vida-média do FVIII a dose de infusão recomendada é de 50 UI/Kg

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: 2.2. **Cálculo do Teste de recuperação do fator administrado:** -->
Para o cálculo do teste de recuperação do fator administrado são necessários os seguintes dados: (1) o valor da dose total administrada em UI, (2) o peso do paciente no dia da realização do teste em Kg e o (3) resultado da determinação do FVIII:C antes da infusão e aos 15, 30 e 60 minutos após a infusão em UI/dL.  
O cálculo poderá ser expresso por duas maneiras, (a) Relação IVR ou (b) Porcentagem de recuperação (%). Para o cálculo <u>considerar o maior valor de FVIII:C entre os tempos (15 min, 30 min e 60 min após administração do concentrado de fator VIII).</u>  
**1. Relação IVR**  
IVR (IU dL<sup>-1</sup> por IU Kg<sup>-1</sup> ) = FVIII:C (%) x peso (Kg) / dose total FVIII administrada (UI)

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **2. Porcentagem (%)** -->
Recuperação (%) = FVIII:C (%) x 0.45 (dL Kg<sup>-1</sup> ) x peso (Kg) x100 / dose total FVIII (UI)  
**Obs:** a constante 0.45 dL Kg<sup>-1</sup> corresponde ao percentual estimado de volume plasmático.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: 2.3. **Cálculo da vida-média de Fator VIII (T1/2)** -->
A vida-média pode ser calculada a partir de um gráfico de concentração plasmática do fator (%) versus o tempo (t).  
Uma das alternativas para este cálculo é selecionar uma concentração aleatória e verificar o tempo que leva para que esta concentração diminua pela metade. No entanto, dada a diferença metabólica de cada indivíduo, a forma mais fidedigna para se obter este resultado é através de uma análise gráfica, considerando a constante de velocidade de eliminação (Kel).  
A constante de velocidade de eliminação é a taxa de fármaco removido por unidade de tempo, e é expressa por fração decimal em unidades de tempo invertida (ex. 0,01 min.-1).  
A constante de velocidade de eliminação pode ser calculada a partir da inclinação da linha formada sobre gráfico semilogarítmico de concentração plasmática versus o tempo, e expressa em unidade de tempo.  
A fórmula para obtenção da vida-média de uma proteína é:  
T1/2=0, 693/Kel  
(Kel)= (neperiano da concentração inicial – neperiano da concentração final) / (tempo final-tempo inicial) (0,693) =  
Logaritmo natural de 2 (constante).

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **APÊNDICE 4** -->
PLANILHA DE INFUSÃO DOMICILIAR PARA PACIENTES COM HEMOFILIA A EM TRATAMENTO DE IMUNOTOLERÂNCIA  
Nome: _______________________________________________________________________________________________________________________________________  
Data de nascimento: _____/_____/______  
Centro de tratamento: ___________________________________________________________________________________________________________________________  
|**DAD**|**OS GER**|**AIS**||**PRODUT**|**O**||**MOTIVO DA INFUSÃ**|**O**|**HEMO**|**RRAGIA**||
|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||**Hemorragia***||||**Assinatura**|
|**Data**|**Hora**|**Peso**|**Nome comercial**|**Lote**|**Nº UI, KUI ou mg**|**Profilaxia**|**artic**<br>**musc**<br>**out**|**Continuidade**|**Local**<sup>**#**</sup>|**Lado**<sup>**&**</sup>||  
***** Hemorragia: art=articular; musc=muscular; out=outros.  
> # Local: **articular:** joelho=J;       cotovelo=C;       tornozelo=T;       ombro=O;       punho=P;        quadril=Q; outros. **Muscular:** panturrilha=pant.; antebraço=anteb.; coxa; perna; glúteo; mão; pé; outros. **Outros:** sistema nervoso central=SNC; cavidade oral=CO; outros  
> **&** Lado: direito=D; esquerdo=E; não sabe ou não se aplica=NA

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo de Indução de Imunotolerância para indivíduos com hemofilia A e inibidores ao fator VIII de coagulação contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do Protocolo de Uso, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas sob coordenação da CoordenaçãoGeral de Sangue e Hemoderivados (CGSH/DAET/SAES/MS). O painel de especialistas incluiu médicos hematologistas e hematopediatras.  
Todos os participantes do processo de elaboração do Protocolo de Uso preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **Equipe de elaboração e partes interessadas** -->
Equipe multiprofissional incluindo médicos hematologistas, hematopediatras, farmacêuticos, enfermeiras, outros profissionais da saúde, Coordenação-Geral de Sangue e Hemoderivados (CGSH/DAET/SAES/MS), e Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS).

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **Etapas do processo de elaboração** -->
Inicialmente foi constituído um grupo de trabalho especificamente para este fim, composto por hematologistas e hematopediatras com experiência clínica no tratamento de pacientes com hemofilia e inibidores, e em imunotolerância. As atividades ocorreram entre novembro de 2023 e fevereiro de 2024.  
O grupo de trabalho inicialmente se reuniu para análise do Relatório de Recomendação Nº 841/2023 da Conitec, que embasou a definição do Protocolo de Uso de emicizumabe para indivíduos com hemofilia A moderada e grave e inibidores contra o fator VIII da coagulação sanguínea. Ao trabalhar naquele Protocolo, o grupo constatou que as modificações exigiriam uma atualização também no Protocolo de Indução de Imunotolerância. Assim, o grupo procedeu à análise do Protocolo atualmente vigente sobre a indução de imunotolerância (Protocolo de Uso de Indução de Imunotolerância para indivíduos com Hemofilia A e inibidores, definido pela Portaria SAES/MS nº 1.113 de 16 de novembro de 2021), sobre o qual as discussões se basearam. Procedeu-se então à ampliação da base de referências bibliográficas daquele Protocolo com foco em artigos científicos relatando a experiência clínica com emicizumabe durante a imunotolerância em pacientes com hemofilia A e inibidores. Isto foi feito na plataforma Pubmed. Foram ainda considerados documentos da própria empresa fabricante do medicamento e a experiência clínica dos participantes.  
As reuniões do grupo de trabalho abordaram os seguintes aspectos: (a) critérios de inclusão e exclusão; e (b) especificidades da imunotolerância em pacientes em uso de emicizumabe como profilaxia. O texto foi sendo escrito e revisado em tempo real durante as reuniões do grupo. O produto final foi discutido, revisado e aprovado pelo grupo de trabalho de especialistas.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do Protocolo de Uso de fator VIII da coagulação na imunotolerância para indivíduos com  
hemofilia A e inibidor do fator VIII da coagulação sanguínea foi apresentada na 116ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 11 de junho de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O Protocolo de Uso foi aprovado para avaliação da Conitec e a proposta foi inicialmente apresentada aos membros do Comitê de PCDT da Conitec em sua 131ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto, e deliberaram, por unanimidade, recomendar a atualização do Protocolo na 19ª Reunião Extraordinária da Conitec.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **Consulta pública** -->
A Consulta Pública nº 46/2024, para a atualização do Protocolo de Uso de fator VIII da coagulação na imunotolerância para indivíduos com hemofilia A e inibidor do fator VIII da coagulação sanguínea foi realizada entre os dias 15 de julho de 2024 a 24 de julho de 2024. Foram recebidas 467 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2024/cp_conitec_046_2024_protocolo_de_uso.pdf.</u>

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: **Busca da evidência e recomendações** -->
As evidências foram obtidas por consulta à plataforma Pubmed. Este Protocolo de Uso foi desenvolvido conforme processos preconizados pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde.  
A relatoria das seções do documento foi atribuída a um dos especialistas que atuou como coordenador das discussões. As modificações foram realizadas em tempo real durante as reuniões pelos especialistas, responsáveis pela redação da primeira versão do texto.

---

<!-- METADADOS: doenca: Indução de Imunotolerância para Indivíduos com Hemofilia A e Inibidor (Protocolo de Uso) | secao: HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO -->
|**Número do Relatório**||**Tecnologias avaliadas p**|**ela Conitec**<br>|
|---|---|---|---|
|**da diretriz clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração**<br>**do uso no SUS**|**Não**<br>**incorporação ou**<br>**não alteração no**<br>**SUS**|
|Relatório<br>de<br>Recomendação<br>nº<br>927/2024|Revisão dos valores de titulação do inibidor do<br>fator VIII da coagulação; e adicionadas<br>especificações dos pacientes em profilaxia<br>concomitante, excluído o escalonamento e uso<br>de altas doses do fator VIII, e alterado o tempo<br>para avaliação máxima de resposta.|-|-|
|Portaria<br>SAS/MS<br>nº<br>1.114,<br>de<br>16<br>de<br>novembro de 2021|<br>Atualizações<br>pontuais,<br>adequando-o<br>às<br>inovações do tratamento da doença.|-|-|
|Portaria<br>SAS/MS<br>nº<br>478, de 16 de junho de<br>2014|<br>Primeira versão da diretriz|Fator<br>VIII<br>de<br>origem<br>recombinante para a profilaxia<br>primária<br>e<br>tratamento<br>de<br>pacientes com hemofilia A no<br>Sistema Único de Saúde<br>(Portaria SCTIE/MS nº 11, de<br>6 de março de 2013)|-|

---

