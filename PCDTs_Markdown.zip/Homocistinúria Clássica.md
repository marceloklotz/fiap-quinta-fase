<!-- METADADOS: doenca: Homocistinúria Clássica | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 3 DE 17 DE JANEIRO DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas Homocistinúria Clássica.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a homocistinúria clássica no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação n<sup><u>o</u></sup> 437/2019 e n<sup><u>o</u></sup> 495/2019 e os relatórios de recomendação n<sup><u>o</u></sup> 448 – Abril de 2019 e  n<sup><u>o</u></sup> 504 – Dezembro de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Homocistinúria  
Clássica.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da homocistinúria clássica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas</u> Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da homocistinúria clássica.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
DENIZAR VIANNA  
ANEXO

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A homocistinúria clássica (HCU) ou deficiência de cistationina β-sintase (CBS) é um erro inato do metabolismo, de herança autossômica recessiva, causado pela presença de variantes patogênicas bialélicas no gene _CBS_ . A atividade da CBS é dependente de piridoxina (vitamina B6), em um ciclo no qual participam também o ácido fólico e a vitamina B12 ( **Figura 1** ). Na HCU, a atividade deficiente de CBS leva ao acúmulo de metionina, homocisteína e seus derivados, e à deficiência de cistationina e de cisteína (1), conforme representado pelo passo 1 na **Figura 1** .  
<!-- Start of picture text -->
Serina AcidoTHE Folico Metionina aXe ATP<br>Dimetil-<br>Glicina + SAM<br>Meee Meco! \® TR, Produto<br>roi B12 ncn Glicina Substrato<br>on<br>1 5-<br>XM Betaina ome Metilado<br>Metileno UA<br>~ THF Homocisteina Adenosina<br>Serina<br>1 Piridoxal 5 - Fosfato<br>Cistationina<br>Bo<br>11<br>2 - Oxobutirato<br>Cisteina<br><!-- End of picture text -->  
**Figura 1 -** Homocistinúria clássica (HCU) e rota do metabolismo da metionina e da homocisteína  
Adaptada de Morris _et al._ , 2016)(1).  
_SAM, S-adenosilmetionina; SAH, S-adenosilhomocisteína; THF, Tetrahidrofolato; MeCbl, Metilcobalamina_ . _Cada passo da rota (1 a 11) é catalisado por uma enzima: 1, Cistationina beta- sintase ou CBS; 2, metionina adenosiltransferase I/III; 3, metionina adenosiltransferase II; 4, glicina N - metiltransferase; 5, numerosas metilltransferases; 6, S - adenosilhomocisteína hidrolase; 7, metionina sintase; 8, betainahomocisteína metilltransferase; 9, serina hidroximetiltransferase; 10, metilenetetrahidrofolato redutase; 11, cistationina gama-liase._  
Em caso de diagnóstico e tratamento tardios, o paciente com HCU pode apresentar um quadro clínico clássico caracterizado por comprometimento ocular (ectopia _lentis_ , miopia, glaucoma, descolamento de retina, entre outros), esquelético (escoliose, osteoporose, vértebras bicôncavas, espículas metafisárias, pés cavos, palato arqueado, aumento do tamanho de ossos longos, dolicoestenomelia, aracnodactilia, entre outros), vascular (tromboembolismo, _flush_ malar, livedo _reticularis)_ e neurológico (acidentes vasculares cerebrais, manifestações psiquiátricas, deficiência intelectual, sinais extrapiramidais, anormalidades eletroencefalográficas entre outros) (1, 2).  
A HCU é uma doença multissistêmica, de curso lento e progressivo, na qual os recém-nascidos não apresentam manifestações clínicas. Os primeiros sinais são inespecíficos e podem surgir nos lactentes. A história natural da doença foi descrita em estudo seminal que incluiu 629 pacientes, que demonstrou que os pacientes responsivos à piridoxina apresentam quadro  
clínico mais brando (3). <mark>Estudos multicêntricos revelaram uma forte correspondência de ectopia</mark> _<mark>lentis,</mark>_ <mark>d</mark> eficiência intelectual, <mark>convulsões e eventos tromboembólicos entre os pares de irmãos afetados, indicando um papel proeminente dos fatores genéticos na determinação do fenótipo (3, 4).</mark>  
Uma revisão sistemática com meta-análise demonstrou que, em indivíduos com eventos tromboembólicos venosos, independente da causa, há risco significativo de ocorrência de hiperhomocisteinemia (níveis plasmáticos de homocisteína total acima de 15 micromol/L), principalmente antes dos 60 anos (5). Dessa forma, acredita-se que a hiperhomocisteinemia associada à HCU esteja relacionada ao maior risco de ocorrência de fenômenos tromboembólicos, e que a diminuição dos níveis de homocisteína associa-se à redução do risco de ocorrência desses fenômenos. O diagnóstico precoce e a adesão ao tratamento mudam a história natural da doença (1).  
A HCU pode ser classificada em três formas segundo o teste de suplementação/responsividade descrito no item 3.3 deste PCDT (3):  
1. Forma responsiva à piridoxina: inclui pacientes que, em uso de piridoxina, têm seus níveis plasmáticos de homocisteína reduzidos para abaixo de 50 micromol/L. Representa cerca de 13% dos casos identificados em triagem neonatal e 47% dos casos diagnosticados tardiamente (1);  
2. Forma não-responsiva à piridoxina: inclui pacientes que, em uso de piridoxina, não têm seus níveis plasmáticos de homocisteína reduzidos abaixo de 50 micromol/L, e que mantêm esses níveis acima de 80% dos níveis basais após o teste de responsividade. Representa cerca de 78% dos casos identificados em triagem neonatal e 43,7% dos casos diagnosticados tardiamente;  
3. Forma com resposta intermediária à piridoxina: inclui pacientes que, em uso de piridoxina, não têm seus níveis plasmáticos de homocisteína reduzidos para abaixo de 50 micromol/L, mas que mantêm esses níveis abaixo de 80% dos níveis basais após teste de responsividade. Representa cerca de 9% dos casos identificados em triagem neonatal e 12,7% dos casos diagnosticados tardiamente.  
A incidência internacional da HCU é estimada em 1:200.000 a 1:300.000 recém-nascidos vivos, podendo chegar a 1:60.000 (1). Estudos recentes baseados na análise mutacional em amostras de recém-nascidos sugerem que a doença possa ser mais frequente, com uma incidência de até 1:20.000 (1, 6). No Brasil, existem pelo menos 72 pacientes diagnosticados (7), não havendo outros dados epidemiológicos sobre a doença disponíveis no país.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da homocistinúria clássica. A metodologia de  
busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
- E72.1 Distúrbios do metabolismo dos aminoácidos que contêm enxofre – homocistinúria

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A presença de um ou mais sinais clínicos clássicos (ectopia _lentis_ ou miopia grave; alterações vasculares tromboembólicas em idade preococe e de repetição; hábito marfanoide) ou de história familiar positiva devem levar à suspeita clínica de HCU, mas o diagnóstico definitivo dessa condição deve ser estabelecido com base em anormalidades bioquímicas  
específicas (1).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O diagnóstico definitivo de HCU exige a confirmação laboratorial, que pode ser feita pela dosagem de metabólitos em sangue ou da análise de DNA (1). A dosagem de metabólitos é baseada na quantificação, em plasma, de homocisteína total e de metionina. Essa quantificação pode ser realizada por métodos cromatográficos, como a cromatografia líquida de alta _performance_ (HPLC - _high perfomance liquid cromatography_ ) (8), ou por imunoensaio automatizado com fluorescência polarizada (9). A homocisteína livre somente é detectável quando as concentrações da homocisteína total são aproximadamente 50-60 micromol/L, logo não é recomendada por ter baixa sensibilidade. Em pacientes não tratados, a homocisteína total está geralmente acima de 100 micromol/L, mas pode ser mais baixa. A metionina pode estar elevada ou limítrofe no plasma, a concentração de cistationina é baixa no plasma e há um aumento da relação metionina/cistationina (1). Os níveis dos aminoácidos geralmente encontrados em pacientes com HCU são apresentados na **Tabela 1** (8, 10).  
**Tabela 1 -** Níveis plasmáticos de aminoácidos sulfurados em pacientes com HCU (independente da faixa etária).  
|Aminoácido|Idade|Homocistinúria clássica (micromol/L)|Controles normais (micromol/L)|
|---|---|---|---|
||Recém-nascidos|200-1500|10-40|
|Metionina|> 7 anos|> 50|10-40|
||Recém-nascidos|Variável de 50 a > 100|> 15|
|Homocisteína total|> 7 anos|> 100|5-15|
|Homocistina|Qualquer idade|10-110|Não detectável|  
De forma geral, uma dosagem elevada de homocisteína total em plasma, associada à elevação plasmática nos níveis de metionina na dosagem por HPLC confirma o diagnóstico de HCU em pacientes com suspeita clínica.  
A análise de DNA (pesquisa de mutações por sequenciamento do gene _CBS – código_ 02.02.10.011-1 _)_ não é usada rotineiramente no diagnóstico da doença, mas pode ser útil em casos duvidosos. Quando um paciente é diagnosticado, deve ser oferecido rastreamento de outros membros da família com medida de homocisteína total e, se necessário, análise de DNA (1).  
Segundo o Human Gene Mutation Database (11), já foram descritas 214 mutações no gene _CBS_ . No Brasil, as mutações mais frequentemente detectadas são as seguintes: p.Ile278Thr (18,2% dos alelos), p.Trp323Ter (11,3% dos alelos), p.Thr191Met (11,3% dos alelos) e c.828+1G>A (11,3% dos alelos) (12). A presença de um alelo com a mutação pan-étnica p.Ile278Thr geralmente é preditora de responsividade à piridoxina (6, 13, 14). Já a mutação p.Thr191Met, altamente prevalente na América Latina e Península Ibérica, usualmente está associada à não responsividade à piridoxina.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O diagnóstico de responsividade à piridoxina é fundamentado de acordo com os níveis plasmáticos de homocisteína total após teste de suplementação, como indicado no **Quadro 1** :  
**Quadro 1** - Grau de responsividade à piridoxina  
Responsivo Níveis plasmáticos de homocisteína total <50 µmol/L após teste de suplementação Níveis plasmáticos de homocisteína total ≥ 50 µmol/L em uso de piridoxina após teste de suplementação com níveis de Não responsivo homocisteína >80% do valor basal Níveis plasmáticos de homocisteína total ≥ 50 µmol/L em uso de piridoxina após teste de suplementação com níveis de Intermediário homocisteína <80% do valor basal  
Fonte: Mudd SH, _et al._ (3)  
Para determinação do grau de responsividade à piridoxina é necessária a realização do teste de responsividade/suplementação (1). Estão descritas diferentes maneiras para a realização desse teste, com variações em relação à dose utilizada de piridoxina, à posologia e ao intervalo de tempo para verificação da responsividade (redução de homocisteína pós-teste) (1). O esquema de testagem de responsividade mais racional e mais amplamente utilizado consiste na dosagem dos níveis basais de homocisteína total durante a vigência de uma dieta normal (sem restrições), suplementação oral de 5mg de ácido fólico seguida da administração oral de piridoxina, na dose de 10 mg/Kg/dia (mínimo de 100 mg/dia e máximo de 500 mg/dia; para neonatos a dose máxima é de 300 mg/dia) e dosagem de homocisteína total após 2 semanas e 6 semanas, esta útima nos casos não-responsivos (1). Antes da realização do teste de responsividade, é fundamental que seja excluída e tratada deficiência eventual de vitamina B12. O fluxograma de diagnóstico e tratamento da HCU está detalhado na **Figura 2** .  
**Figura 2** - Fluxograma de diagnóstico e tratamento de Homocistinúria Clássica  
<!-- Start of picture text -->
Dosagem dos níveis basais de homocisteína total. Dieta sem restrições<br>*Descartar e tratar déficit de vitamina B12 (1.000 mcg IM de<br>i b l i 1 / ê )<br>Suplementação de ácido fólico (5 mg/dia)<br>Iniciar piridoxina<br>Dose 10 mg/Kg/dia (mínimo de 100 mg/dia e máximo de 500<br>mg/dia; para neonatos a dose máxima é de 300 mg/dia)<br>a<br>Repetir  homocisteína  total  em  duas<br>semanas, mantendo a suplementação de<br>piridoxina e de ácido fólico<br>Sim  Não<br><50µmol/L<br>Repetir o teste em 6 semanas<br>mantendo piridoxina e ácido<br>fólico<br>=<br>Sim  <80% do  Não<br>valor inicial<br>s<br>Considerar responsivo à  Considerar parcialmente  Considerar não<br>piridoxina. Manter<br>responsivo à piridoxina.  responsivo à<br>suplementação de<br>Manter suplementação  piridoxina. Iniciar<br>piridoxina e ácido fólico.  de piridoxina e ácido  dieta e fórmula<br>fólico e iniciar dieta e  metabólica.<br>fórmula metabólica.<br>Diagnóstico<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Serão incluídos neste Protocolo os pacientes que tiverem o diagnóstico de HCU confirmado laboratorialmente por meio de um dos exames abaixo relacionados:  
a) quantificação plasmática de homocisteína total **E** de metionina elevadas (acima do valor de referência do laboratório) **OU**  
b) presença de duas mutações reconhecidamente patogênicas no gene _CBS_ .

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Serão excluídos deste Protocolo os pacientes com diagnóstico de outro tipo de homocistinúria que não a HCU ou hiperhomocisteinemia secundária a outras causas.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Gestação em mulheres responsivas à piridoxina não apresenta um aumento de risco significativo de malformações fetais (15-17). Há poucos dados a respeito dos desfechos de mulheres grávidas não responsivas à piridoxina. Em um trabalho que incluiu 15 gestações em 11 mulheres, cinco das quais não responsivas à piridoxina, foram relatados dois casos de pré-eclâmpsia, um caso de trombose venosa superficial, dois abortamentos de primeiro trimestre e 10 gestações a termo com recém-nascidos vivos, embora um com múltiplas malformações e outro com síndrome de Beckwith-Wiedemann. Nenhuma correlação pode ser estabelecida entre a gravidade das alterações bioquímicas durante a gestação, as complicações gestacionais e os desfechos na prole, sugerindo que esses são eventos infrequentes. No entanto, o monitoramento rigoroso, com consultas frequentes e quantificações periódicas de homocisteína total, é mandatório nesses casos (16).  
Inexistem evidências de que a HCU afete a fertilidade. Anticoncepcionais de altas doses de estrogênio devem ser  
evitados devido ao aumento do risco de trombose. Não são conhecidos os riscos com doses baixas (1).  
Pelo maior risco que mulheres com HCU têm de tromboembolismo, especialmente no pós-parto (inclusive com trombose venosa cerebral) (18), a profilaxia com anticoagulante durante o terceiro trimestre de gravidez e por seis semanas no pós-parto é recomendada (1). A escolha do melhor esquema de anticoagulação deve ser individualizado (19).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
<mark>Intervenções cirúrgicas e anestesia representam um risco adicional de trombose na HCU. Os controles bioquímico e nutricional devem ser otimizados antes dos procedimentos eletivos. Medidas antitrombóticas padrão devem ser seguidas durante e após o procedimento cirúrgico. A</mark> escolha do melhor esquema de anticoagulação deve ser individualizado, <mark>sendo preconizada em casos de imobilização prolongada. O óxido nitroso aumenta as concentrações de homocisteína e deve ser evitado (1)</mark> .

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Recomenda-se que os pacientes sejam diagnosticados, tratados e monitorados em centros de referência que contem com uma equipe multidisciplinar integrada de especialistas, que assegurem o gerenciamento abrangente dos pacientes com HCU, desde o diagnóstico até o tratamento e seguimento.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Atualmente, existem três modalidades de tratamento reconhecidas para HCU, que serão detalhadas a seguir (20, 21). Para aqueles indivíduos que são responsivos à piridoxina, o tratamento consiste na administração de cloridrato de piridoxina (22) em combinação com o ácido fólico (21, 23). Os pacientes parcialmente responsivos recebem cloridrato de piridoxina em combinação com o ácido fólico, dieta com restrição de metionina e fórmula metabólica isenta de metionina (FMIM). Para pacientes não-responsivos à piridoxina, o tratamento é baseado em dieta isenta de proteínas de alto valor biológico, de origem animal, e restrita em alimentos de origem vegetal com alto teor de metionina e utilização de FMIM (24, 25). Ácido fólico e vitamina B12 devem ser prescritos, esta última quando houver deficiência (21, 25, 26).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O paciente com HCU tem uma doença crônica, progressiva e multissistêmica e rotineiramente requer cuidados urgentes por equipe multiprofissional que inclua fonoaudiólogos, fisioterapeutas, terapeutas ocupacionais, equipe de enfermagem e diferentes médicos especialistas (1). Além disso, é importante que os pacientes e as famílias sejam orientados sobre sua doença e possíveis complicações e riscos, também por meio de um relatório escrito. Os pacientes também devem ser orientados para que, em caso de emergência, o médico assistente deve ser informado da doença e receber uma cópia do relatório médico. O paciente e sua família também devem ser encaminhados para aconselhamento genético e serem alertados sobre os riscos associados à gestação, especialmente no caso de pacientes do sexo feminino.  
É importante frisar que nem todos os pacientes apresentarão todas as manifestações clínicas e que nem todos os pacientes necessitarão ser submetidos a todas as formas de tratamento. Pelo risco de desenvolvimento de osteoporose nesses pacientes, sugerem-se avaliações periódicas e tratamento conforme o protocolo específico do Ministério da Saúde (27), disponível em <u>www.conitec.gov.br</u> .

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Apesar de não haver ensaios clínicos randomizados específicos em pacientes com HCU, a história natural da doença impõe um altíssimo risco de eventos tromboembólicos nesses indivíduos (risco de 50% de um evento até os 29 anos de idade) (3). Ácido acetilsalicílico (AAS) deve ser utilizado para prevenção primária ou secundária de eventos tromboembólicos em pacientes com HCU que apresentaram evento tromboembólico prévio, ou outro fator de risco para eventos tromboembólicos além da HCU, ou que não estejam bem-controlados (1).  
A fórmula metabólica isenta de metionina (FMIM) é composta por aminoácidos essenciais e não essenciais, enriquecida de vitaminas e minerais, e consiste em um produto liofilizado utilizado na reposição dos aminoácidos essenciais que são retirados da dieta instituída ao paciente (exceto metionina). Alimentos fontes de proteína são reduzidos da dieta e a fonte principal de aminoácidos essenciais passa a ser provida por fórmula de aminoácidos, essencialmente isenta de metionina (o aminoácido precursor da homocisteína, que, acumulada, passa a ser tóxico ao organismo) (28). A reposição permite que o paciente mantenha o desenvolvimento somático e neurológico adequado apesar da importante restrição dietética que lhe será imposta.  
Nos 23 pacientes tratados com restrição de proteínas e suplementação com fórmula, a mediana de consumo de metionina foi de 230 mg/dia (variando entre 160-900 mg/dia), sendo particularmente mais difícil a adesão em crianças mais velhas e adolescentes. Nenhum dos 11 pacientes com diagnóstico precoce (por triagem neonatal), e início do tratamento com restrição dietética e suplementação com FMIM, desenvolveu manifestações clínicas de homocistinúria (como hábito marfanoide, aracnodactilia, ectopia _lentis_ ). A mediana do quociente de inteligência (QI) nesses indivíduos foi de 100 (variando entre 84-117), significativamente superior aos dos indivíduos com tratamento tardio (pacientes não responsivos à piridoxina com tratamento tardio, mediana de QI 58, variando 20-86, _P_ <0,0001; pacientes responsivos à piridoxina com tratamento tardio, mediana de QI 82, variando 57-101, _P_ =0,02). A redução da ingestão de suplemento de aminoácidos também pode estar associada com diminuição do crescimento e desnutrição e aumento dos níveis de homocisteína (17).  
Lim _et al._ , 2013 estudaram 5 pacientes não responsivos à piridoxina, em uso de FMIM, piridoxina, betaína e ácido fólico,  
para avaliar densidade mineral óssea (DMO) (29). Todos os pacientes apresentavam valores normais quando comparados à população coreana. Após 3,4 anos, o escore Z para coluna lombar aumentou 0,2; para cabeça do fêmur diminuiu 2,3 (sem baixa densidade mineral óssea); e para corpo total diminuiu 0,8 (sem baixa densidade mineral óssea). O bom controle metabólico parece auxiliar na manutenção da densidade mineral óssea. Três pacientes, correspondente a 60% da amostra, apresentavam leve escoliose. O bom controle metabólico parece prevenir anormalidades ósseas.  
A vitamina B12 deve ser suplementada quando houver deficiência, independentemente da responsividade à piridoxina. A vitamina B12 pode ser administrada na dose de 1.000 mcg IM de cianocobalamina 1x/mês ou a critério do médico assistente. Já o ácido fólico deve ser utilizado na dose de 5mg/dia (1).  
O cloridrato de piridoxina apresenta boa absorção gastrintestinal, meia-vida entre 15 a 20 dias e concentração plasmática ótima na ordem de 60 nanomol/L. A piridoxina é a precursora do fosfato de piridoxal (30), cofator essencial da enzima CBS, potencializando a atividade residual desta (31, 32). Na HCU, o uso de piridoxina pode reduzir os níveis plasmáticos de homocisteína, podendo inclusive normalizá-los (nos pacientes considerados responsivos) (1). Esse desfecho substitutivo (laboratorial) tem boa correlação com a história natural da doença (quanto menores os níveis de homocisteína plasmática, menor a incidência de eventos tromboembólicos) (22).  
Os benefícios clínicos da piridoxina foram inicialmente demonstrados em ensaios clínicos não-randomizados e nãocontrolados na década de 60, já que desde a melhor compreensão bioquímica da fisiopatologia da HCU seu uso terapêutico foi empregado nos pacientes diagnosticados. A piridoxina reduz de forma substancial os níveis de homocisteína, sendo inclusive o teste terapêutico essencial para a classificação do paciente, conforme item 2, deste PCDT.  
Trabalhos realizados desde 1967 mostram ser um medicamento seguro, com efeitos benéficos sobre as principais manifestações clínicas da doença, a saber:  
- redução de eventos tromboembólicos e cardiovasculares (17, 21, 23, 33);  
- melhora do prognóstico neurológico (retardo mental) (34);  
- redução no número de complicações oftalmológicas (e.g., _ectopia lentis_ ) (17, 21, 35);  
- diminuição das manifestações esqueléticas da doença (aracnodactilia, hábito marfanoide e osteoporose) (17, 21).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
- Ácido acetilsalicílico: comprimido de 100 e 500 mg  
- Ácido fólico: comprimido de 5 mg  
- Cianocobalamina (vitamina B12): solução injetável de 1.000 mcg  
- Cloridrato de piridoxina (vitamina B6): comprimido de 40 e 100 mg  
- Fórmula metabólica isenta de metionina

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Os esquemas de administração variam conforme o tipo clínico e a faixa etária dos pacientes e as recomendações  
sugeridas muitas vezes devem ser ajustadas à resposta terapêutica dos pacientes (conforme monitorização dos níveis plasmáticos de homocisteína total e demais aminoácidos). É recomendado que a FMIM seja usada três a quatro vezes ao dia para maximizar a retenção de nitrogênio e alcançar o crescimento apropriado (1).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A recomendação do uso de cloridrato de piridoxina é 10 mg/kg/dia até a dose máxima de 500 mg/dia. Pacientes que apresentam homocisteína total no plasma < 50 micromol/L em uso de piridoxina e ácido fólico, são claramente responsivos e não necessitam tratamento adicional (1).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Quando o paciente é parcialmente responsivo à piridoxina, de acordo com os critérios apresentados no item 3.3, devese adicionar ao tratamento com piridoxina/ácido fólico a dieta com restrição de proteína (e, portanto, de metionina) e FMIM, nos mesmos moldes descritos no item 8.4.3

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Nos pacientes não responsivos à piridoxina, não há evidência de que seu uso apresente benefício se não houver resposta bioquímica em um teste bem conduzido. Deve-se iniciar dieta com restrição de metionina associada à FMIM. A tolerância à metionina (e, portanto, à proteína natural) é individualizada para cada paciente.  
A prescrição da FMIM varia considerando a idade, o peso do paciente e o controle metabólico. A quantidade de aminoácidos em 100g da FMIM pode variar dependendo do fabricante, por este motivo é importante conhecer a informação nutricional da fórmula prescrita.  
Para a prescrição da FMIM, é necessário primeiramente estabelecer a tolerância à metionina do paciente (tolerância pode ser definida como a quantidade máxima de metionina que pode ser ingerida mantendo os níveis de homocisteína no alvo terapêutico). A tolerância é estabelecida por meio da avaliação do nutricionista, a qual calcula a ingestão diária de metionina do paciente e compara os mesmos com os valores de homocisteína. Estabelecida a tolerância, é possível determinar individualmente a quantidade de proteína natural que pode ser ingerida na dieta. Para estabelecer a quantidade de FMIM, é necessário subtrair a quantidade de proteína tolerada da necessidade proteica estimada para sexo e faixa etária ( **Tabela 2** ). Devido à menor biodisponibilidade dos aminoácidos provenientes da fórmula, a ingestão proteica deve ser maior do que as recomendações vigentes para a população. Baseado nos estudos em fenilcetonúria estima-se que um adicional proteico de 20 a 40% deve ser considerado na prescrição da fórmula (36, 37). Para otimizar o balanço nitrogenado na HCU, a fórmula metabólica deve ser fracionada em, no mínimo três vezes ao dia, e ingerida preferencialmente após as refeições.  
Restrição excessiva de metionina, com concentrações de metionina baixas no plasma, pode causar prejuízo no crescimento e atraso no neurodesenvolvimento da criança.  
A recomendação de consumo diário de proteína, metionina e cistina para pacientes com as formas não responsiva e  
parcialmente responsiva da HCU pode ser encontrada na **Tabela 2** .  
**Tabela 2** - Recomendação de consumo diário de proteína, metionina e cistina em pacientes com as formas não-responsiva e parcialmente responsiva da Homocistinúria Clássica.  
|**Idade (anos)**|**Proteína***<br>**(g/kg/dia)**|**Metionina**<br>**(mg/Kg/dia)**|**Cistina (mg/Kg/dia)**|
|---|---|---|---|
|0 – 6 meses|3,0-3,5|15-60|85-150|
|6 <12 meses|2,5-3,0|12-43|85-150|  
||**(g/dia)**|**(**|**mg/Kg/dia)**|**(mg/Kg/dia)**|
|---|---|---|---|---|
|1 - 4 anos|>30||9-28|60-100|
|4 < 7 anos|>35||5-22|20-80|
|7 < 11 anos|>40|**Homens**|5-22|20-80|
|11 < 19 anos|>65||5-22|20-80|
|Adultos|>65||5-22|20-80|
|||**Mulheres**|||
|11 < 19 anos|>50||5-22|20-80|
|Adultas|>50||5-22|20-80|
|Gestante/Nutriz|>71||5-22|20-80|  
Fonte: (38, 39)

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O tratamento deverá ser mantido por toda a vida, já que a interrupção das medidas terapêuticas produz o retorno ao quadro bioquímico inicial e suas consequentes manifestações clínicas.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O objetivo bioquímico do tratamento é controlar (e se possível, normalizar) a intensa hiperhomocisteinemia que é característica desta condição (40). Os benefícios clínicos esperados no tratamento da HCU variam de acordo com a idade ao diagnóstico. Nos casos em que o diagnóstico é realizado em recém-nascidos, os objetivos das medidas terapêuticas são, idealmente, evitar o aparecimento de qualquer complicação ocular, esquelética, tromboembólica, bem como garantir o desenvolvimento intelectual normal (40). No entanto, nos casos com diagnóstico tardio, muitas vezes, complicações já ocorreram e os benefícios esperados das medidas terapêuticas descritas são a prevenção de eventos tromboembólicos fatais e da progressão das complicações já ocorridas (33), como anormalidades ortopédicas e oftalmológicas que às vezes exigem intervenções cirúrgicas (35).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Os pacientes com HCU devem ser acompanhados por uma equipe multidisciplinar (clínico ou pediatra, oftalmologista, cardiologista, neurologista, psiquiatra e nutricionista), uma vez que as manifestações multissistêmicas da doença assim o exigem. O acompanhamento clínico ambulatorial que se segue após o diagnóstico deve ser mensal para que haja o ajuste das medidas terapêuticas e otimização dietética, conforme resultados laboratoriais. Principalmente no período pós-diagnóstico, mas também durante todo o acompanhamento, deve ser enfatizada a importância da adesão ao tratamento (41).  
Após o período de otimização terapêutica, o acompanhamento clínico deve ocorrer com periodicidade a ser individualizada, dependendo da evolução clínica e das dificuldades da família. O acompanhamento laboratorial, com dosagem de homocisteína total e de aminoácidos plasmáticos por HPLC também deve ser estabelecido (9). A avaliação oftalmológica  deve ser realizada ao diagnóstico e ter a sua periodicidade _a posteriori_ estabelecida (1). Pacientes com tratamento dietético necessitam de testes adicionais, citados na **Tabela 3** . Conforme decisão da equipe multidisciplinar do Centro de Referência, algumas situações especiais de dificuldade no seguimento podem definir uma rotina diferenciada de acompanhamento clínico ou laboratorial, com a redução dos prazos acima definidos.  
**Tabela 3** - Avaliações mínimas sugeridas e respectiva periodicidade para acompanhamento dos pacientes com HCU  
|**Área**|**Testes ou procedimentos**|**Ao diagnóstico**|**Frequência**|
|---|---|---|---|
|Antropometria|Peso e altura|X|A cada 4 meses|
|Avaliação nutricional|Avaliação da adesão à dieta|X|A cada 4 meses|
|Controle metabólico|Homocisteína total plasmática e dosagem de<br>metionina|X|A cada 4 meses|
|Nutricional|Vitamina B12, folato, hemograma com<br>plaquetas, albumina, ferritina, vitamina D,<br>dosagem quantitativa de todos os<br>aminoácidos***|X|Anualmente|
|Neurológico|Exame clínico|X|*|
|Exame de imagem|RNM de crânio e EEG||*|
|Função neuropsicológica|Teste de QI||*|
|Psicológica|Avaliação clínica psicológica ou psiquiátrica||*|
|Densidade óssea|Densitometria óssea|X (não realizar se|A cada 2 anos após os 10|
|||idade <10 anos)|anos de idade|
|Cardiovascular|Perfil lipídico|X|Anualmente|
||Ecocardiograma|X|Anualmente|
|Avaliação oftalmológica**||X|*|
|Aconselhamento genético||X|Reforços periódicos|  
*a critério do médico assistente;  
**a avaliação  oftalmológica deve incluir acuidade visual, fundo de olho e exame com lâmpada de fenda;  
***a dosagem quantitativa anual de todos os aminoácidos está indicada somente para os pacientes em dieta restrita em metionina.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O objetivo do tratamento é manter a homocisteína total plasmática em níveis seguros, manter uma nutrição adequada, incluindo concentrações normais de metionina e outros aminoácidos essenciais. O alvo-terapêutico na forma responsiva à piridoxina é manter a homocisteína total plasmática < 50 micromol/L. Este valor pode não ser atingido nos pacientes parcialmente responsivos a piridoxina. Nos pacientes não responsivos a piridoxina, é sugerido manter a homocisteína total plasmática < 100 micromol/L (1). Além disso, os níveis inferiores de metionina idealmente devem se manter entre 20-40 micromol/L.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
O uso de piridoxina em doses diárias superiores a 900 mg já foi associado ao aparecimento de neuropatia periférica (1); nesses casos é aconselhável a redução da dose até a reversão dos sintomas (41). Algumas crianças que receberam doses diárias iguais ou superiores a 500 mg de piridoxina ao dia desenvolveram insuficiência respiratória (com necessidade de suporte ventilatório), que foram resolvidos com a retirada da piridoxina. Rabdomiólise já foi relatada (42).  
É fundamental a monitorização dos níveis de metionina, já que valores superiores a 1.000 micromol/L estão possivelmente associados a edema cerebral (1, 43).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Doentes de homocistinúria devem ser atendidos em centros de referência, para seu adequado diagnóstico e inclusão neste Protocolo.  
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso dos medicamentos e  
controle de efeitos adversos.  
A dosagem quantitativa de aminoácidos é compatível com o procedimento 02.02.10.015-4 da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
A identificaçâo de mutação por sequenciamento por amplicon até 500 pares de bases é compatível com o procedimento 02.02.10.011-1 da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Deve-se cientificar o paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
1. Morris AA, Kožich V, Santra S, Andria G, Ben-Omran TI, Chakrapani AB, et al. Guidelines for the diagnosis and management of cystathionine beta-synthase deficiency. J Inherit Metab Dis. 2017;40(1):49-74.  
2. Garland J, Prasad A, Vardy C, Prasad C. Homocystinuria: Challenges in diagnosis and management. Paediatr Child Health. 1999;4(8):557-62.  
3. Mudd SH, Skovby F, Levy HL, Pettigrew KD, Wilcken B, Pyeritz RE, et al. The natural history of homocystinuria due to cystathionine beta-synthase deficiency. Am J Hum Genet. 1985;37(1):1-31.  
4. De Franchis R, Sperandeo MP, Sebastio G, Andria G. Clinical aspects of cystathionine beta-synthase deficiency: how wide is the spectrum? The Italian Collaborative Study Group on Homocystinuria. Eur J Pediatr. 1998;157 Suppl 2:S67-70.  
5. Ray JG. Meta-analysis of hyperhomocysteinemia as a risk factor for venous thromboembolic disease. Arch Intern Med. 1998;158(19):2101-6.  
6. Skovby F, Gaustadnes M, Mudd SH. A revisit to the natural history of homocystinuria due to cystathionine beta-synthase deficiency. Mol Genet Metab. 2010;99(1):1-3.  
7. Poloni S, Hoss GW, Sperb-Ludwig F, Borsatto T, Doriqui MJR, Leão EKEA, et al. Diagnosis and Management of Classical  
Homocystinuria in Brazil: A Summary  
of 72 Late-Diagnosed Patients. Journal of Inborn Errors of Metabolism  
& Screening. 2018;6:1 - 6.  
8. Moat SJ, Bonham JR, Tanner MS, Allen JC, Powers HJ. Recommended approaches for the laboratory measurement of homocysteine in the diagnosis and monitoring of patients with hyperhomocysteinaemia. Ann Clin Biochem. 1999;36 ( Pt 3):372-9.  
9. Shipchandler MT, Moore EG. Rapid, fully automated measurement of plasma homocyst(e)ine with the Abbott IMx analyzer. Clin Chem. 1995;41(7):991-4.  
10. Sacharow   S, Picker   J, Levy   H. Homocystinuria  Caused by Cystathionine Beta-Synthase Deficiency. In: MP A, HH A, RA P, editors. GeneReviews. Seattle2017.  
11. Human Gene Mutation Database: http://www.hgmd.cf.ac.uk/ac/index.php; [  
12. Poloni S, Sperb-Ludwig F, Borsatto T, Weber Hoss G, Doriqui MJR, Embiruçu EK, et al. CBS mutations are good predictors for B6-responsiveness: A study based on the analysis of 35 Brazilian Classical Homocystinuria patients. Mol Genet Genomic Med. 2018;6(2):160-70.  
13. Gaustadnes M, Wilcken B, Oliveriusova J, McGill J, Fletcher J, Kraus JP, et al. The molecular basis of cystathionine beta-synthase deficiency in Australian patients: genotype-phenotype correlations and response to treatment. Hum Mutat. 2002;20(2):117-26.  
14. Kruger WD, Wang L, Jhee KH, Singh RH, Elsas LJ. Cystathionine beta-synthase deficiency in Georgia (USA): correlation of clinical and biochemical phenotype with genotype. Hum Mutat. 2003;22(6):434-41.  
15. Vilaseca MA, Cuartero ML, Martinez de Salinas M, Lambruschini N, Pintó X, Urreizti R, et al. Two successful pregnancies in pyridoxine-nonresponsive homocystinuria. J Inherit Metab Dis. 2004;27(6):775-7.  
16. Levy HL, Vargas JE, Waisbren SE, Kurczynski TW, Roeder ER, Schwartz RS, et al. Reproductive fitness in maternal homocystinuria due to cystathionine beta-synthase deficiency. J Inherit Metab Dis. 2002;25(4):299-314.  
17. Walter JH, Wraith JE, White FJ, Bridge C, Till J. Strategies for the treatment of cystathionine beta-synthase deficiency: the experience of the Willink Biochemical Genetics Unit over the past 30 years. Eur J Pediatr. 1998;157 Suppl 2:S71-6.  
18. Novy J, Ballhausen D, Bonafé L, Cairoli A, Angelillo-Scherrer A, Bachmann C, et al. Recurrent postpartum cerebral sinus vein thrombosis as a presentation of cystathionine-beta-synthase deficiency. Thromb Haemost. 2010;103(4):871-3.  
19. Calvert SM, Rand RJ. A successful pregnancy in a patient with homocystinuria and a previous near-fatal postpartum cavernous sinus thrombosis. Br J Obstet Gynaecol. 1995;102(9):751-2.  
20. Yap S, Naughten ER, Wilcken B, Wilcken DE, Boers GH. Vascular complications of severe hyperhomocysteinemia in patients with homocystinuria due to cystathionine beta-synthase deficiency: effects of homocysteine-lowering therapy. Semin Thromb Hemost. 2000;26(3):335-40.  
21. Yap S, Naughten E. Homocystinuria due to cystathionine beta-synthase deficiency in Ireland: 25 years' experience of a newborn screened and treated population with reference to clinical outcome and biochemical control. J Inherit Metab Dis. 1998;21(7):738-47.  
22. Turner B. Pyridoxine treatment in homocystinuria. Lancet. 1967;2(7526):1151.  
23. Wilcken DE, Wilcken B. The natural history of vascular disease in homocystinuria and the effects of treatment. J Inherit Metab Dis. 1997;20(2):295-300.  
24. Perry TL, Hansen S, Love DL, Crawford LE, Tischler B. Treatment of homocystinuria with a low-methionine diet, supplemental cystine, and a methyl donor. Lancet. 1968;2(7566):474-8.  
25. Komrower GM. Dietary treatment of homocystinuria. Am J Dis Child. 1967;113(1):98-100.  
26. Perry TL, Dunn HG, Hansen S, MacDougall L, Warrington PD. Early diagnosis and treatment of homocystinuria. Pediatrics. 1966;37(3):502-5.  
27. Saúde Md. PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS: OSTEOPOROSE.2014 08/09/2019. Available from: http://portalarquivos.saude.gov.br/images/pdf/2014/abril/02/pcdt-osteoporose-2014.pdf.  
28. Schimke RN. Low methionine diet treatment of homocystinuria. Ann Intern Med. 1969;70(3):642-3.  
29. Lim JS, Lee DH. Changes in bone mineral density and body composition of children with well-controlled homocystinuria caused by CBS deficiency. Osteoporos Int. 2013;24(9):2535-8.  
30. Clayton PT. B6-responsive disorders: a model of vitamin dependency. J Inherit Metab Dis. 2006;29(2-3):317-  
26.  
31. Wilcken B, Turner G. Homocystinuria in New South Wales. Arch Dis Child. 1978;53(3):242-5.  
32. Mudd SH, Edwards WA, Loeb PM, Brown MS, Laster L. Homocystinuria due to cystathionine synthase deficiency: the effect of pyridoxine. J Clin Invest. 1970;49(9):1762-73.  
33. Yap S, Boers GH, Wilcken B, Wilcken DE, Brenton DP, Lee PJ, et al. Vascular outcome in patients with homocystinuria due to cystathionine beta-synthase deficiency treated chronically: a multicenter observational study. Arterioscler Thromb Vasc Biol. 2001;21(12):2080-5.  
34. Yap S, Rushe H, Howard PM, Naughten ER. The intellectual abilities of early-treated individuals with pyridoxine-nonresponsive homocystinuria due to cystathionine beta-synthase deficiency. J Inherit Metab Dis. 2001;24(4):437-47.  
35. Harrison DA, Mullaney PB, Mesfer SA, Awad AH, Dhindsa H. Management of ophthalmic complications of homocystinuria. Ophthalmology. 1998;105(10):1886-90.  
36. van Wegberg AMJ, MacDonald A, Ahring K, Bélanger-Quintana A, Blau N, Bosch AM, et al. The complete European guidelines on phenylketonuria: diagnosis and treatment. Orphanet J Rare Dis. 2017;12(1):162.  
37. Rocha JC, MacDonald A. Dietary intervention in the management of phenylketonuria: current perspectives. Pediatric Health Med Ther. 2016;7:155-63.  
38. Thomas, JA. Homocystinuria:  
Diagnosis and Management. In: Bernstein, LE, F R, JR H, editors. Nutrition  
Management of Inherited Metabolic Diseases Lessons from Metabolic University: Springer; 2015.  
39. ACOSTA PB, & YANNICELLI, S. _Nutrition support protocols: the Ross metabolic formula system_ . . Columbus, Ohio, Ross Products Division, Abbot Laboratories.2001.  
40. Yap S. Classical homocystinuria: vascular risk and its prevention. J Inherit Metab Dis. 2003;26(2-3):259-65.  
41. Ludolph AC, Masur H, Oberwittler C, Koch HG, Ullrich K. Sensory neuropathy and vitamin B6 treatment in homocystinuria. Eur J Pediatr. 1993;152(3):271.  
42. Shoji Y, Takahashi T, Sato W, Takada G. Acute life-threatening event with rhabdomyolysis after starting on high-dose pyridoxine therapy in an infant with homocystinuria. J Inherit Metab Dis. 1998;21(4):439-40.  
43. Yaghmai R, Kashani AH, Geraghty MT, Okoh J, Pomper M, Tangerman A, et al. Progressive cerebral edema associated with high methionine levels and betaine therapy in a patient with cystathionine beta-synthase (CBS) deficiency. Am J Med Genet. 2002;108(1):57-63.  
44. Kurczynski TW, Muir WA, Fleisher LD, Palomaki JF, Gaull GE, Rassin DK, et al. Maternal homocystinuria: studies of an untreated mother and fetus. Arch Dis Child. 1980;55(9):721-3.  
45. Langendonk JG, Roos JC, Angus L, Williams M, Karstens FP, de Klerk JB, et al. A series of pregnancies in women with inherited metabolic disease. J Inherit Metab Dis. 2012;35(3):419-24.  
46. Yap S, Barry-Kinsella C, Naughten ER. Maternal pyridoxine non-responsive homocystinuria: the role of dietary treatment and anticoagulation. BJOG. 2001;108(4):425-8.  
47. Brenton DP, Cusworth DC, Biddle SA, Garrod PJ, Lasley L. Pregnancy and homocystinuria. Ann Clin Biochem. 1977;14(3):161-2.  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**  
ÁCIDO ACETILSALICÍLICO, ÁCIDO FÓLICO, CIANOCOBALAMINA, CLORIDRATO DE PIRIDOXINA E FÓRMULA METABÓLICA ISENTA DE METIONINA.  
Eu,___________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **ácido acetilsalicílico, ácido fólico, cianocobalamina, cloridrato de piridoxina e fórmula metabólica isenta de metionina** indicados para o tratamento da **homocistinúria clássica** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
_____________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que os medicamentos que passo a receber podem trazer os seguintes benefícios:  
- prevenção do aparecimento de complicações, como do entupimento das veias;  
- melhora dos sintomas da doença, como aumento da densidade do osso.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos: - o uso de piridoxina em doses diárias superiores a 900 mg foi associado ao aparecimento de neuropatia periférica e insuficiência respiratória;  
- contraindicação em casos de hipersensibilidade (alergia) à fórmula metabólica ou aos seus componentes, bem como a  
- qualquer dos medicamentos e suplementos mencionados neste PCDT.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (   ) Sim (   ) Não  
O meu tratamento constará de um ou mais dos seguintes medicamentos:  
- (   ) Ácido acetilsalicílico (   ) Ácido fólico (   ) Cianocobalamina  
- (   ) Cloridrato de piridoxina  
(   ) Fórmula metabólica isenta de metionina  
Local:                                                                                          Data: Nome do paciente:  
Cartão Nacional do SUS:  
Nome do responsável legal: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal Médico:                                                                           CRM:                                 RS: ______________________________ Assinatura e carimbo do médico Data:  
**Nota** : Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A Política Nacional de Atenção Integral às Pessoas com Doenças Raras foi publicada em 12 de fevereiro de 2014 por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014<sup>1</sup> , que, além de instituir a referida política, aprovou as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS) e instituiu incentivos financeiros de custeio.  
Essa Política tem como objetivo reduzir a mortalidade e a incapacidade causadas por essas doenças, bem como contribuir para a melhoria da qualidade de vida das pessoas com doenças raras. Está organizada no conceito das Redes de Atenção à Saúde (RAS), considerando-se todos os pontos de atenção, assim como os sistemas logísticos e de apoio necessários para garantir a oferta de ações de promoção, detecção precoce, diagnóstico, tratamento e cuidados paliativos, de forma oportuna, para as pessoas com doenças raras.  
A política utiliza como definição de doença rara a estabelecida pela Organização Mundial de Saúde: “aquela doença que afeta até 65 pessoas em cada 100.000 indivíduos, ou seja, 1,3 pessoas para cada 2.000 indivíduos”, conforme estabelecido nas diretrizes citadas acima.  
Como não seria possível organizar as diretrizes abordando as doenças raras de forma individual, devido ao grande número de destas, essas diretivas foram organizadas na forma de eixos estruturantes, que permitem classificar as doenças raras de acordo com suas características comuns, com a finalidade de maximizar os benefícios aos usuários.  
Dessa forma, as doenças raras foram classificadas em dois eixos: a) Doenças raras de origem genética, com três grupos: 1 - Anomalias congênitas ou de manifestação tardia, 2 - Deficiência intelectual, 3 - Erros inatos do metabolismo; b) Doenças Raras de origem não genética, com os seguintes grupos de causas: 1 - Infecciosas, 2 - Inflamatórias, 3 - Autoimunes, 4 - Outras doenças raras não genéticas.  
Para a implantação e implementação dessa política foram incorporados, inicialmente, 15 exames na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materias Especiais do SUS, abrangendo biologia molecular, citogenética e imunoensaios, além do aconselhamento genético.  
Os princípios e diretrizes dessa Portaria, expressos no artigo 6º, inciso VI, visam garantir a incorporação e o uso de tecnologias voltadas para a promoção, a prevenção e o cuidado integral na RAS, incluindo tratamento medicamentoso e fórmulas nutricionais, quando indicados no âmbito do SUS, que devem ser resultado das recomendações formuladas por órgãos governamentais a partir do processo de avaliação e aprovação pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e elaboração dos Protocolos Clínicos e Diretrizes Terapêuticas (PCDT).  
Para viabilizar as definições e a implementação da Política, a Coordenação de Média e Alta Complexidade (CGMAC), juntamente com a CONITEC, organizou um encontro com especialistas que atuam em doenças raras em todo o país, abarcando os dois eixos da Política e seus respectivos grupos supracitados. O “Painel de Especialistas”, realizado nos dias 19 e 20 de maio de 2014, objetivou estabelecer critérios e prioridades para a elaboração de PCDTs para a implementação da Política Nacional de Atenção Integral às Pessoas com Doenças Raras no SUS. Entre as doenças elencadas para elaboração de PCDT priorizados está a Homocistinúria Clássica (HCU).

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
A fim de dar continuidade ao processo de elaboração do PCDT, foi realizada uma reunião de escopo com o comitê gestor e elaborador deste Protocolo no dia 10 de abril de 2017 no Hospital Alemão Oswaldo Cruz (HAOC), quando foram estabelecidas as seguintes perguntas de pesquisa para elaboração deste PCDT:  
- 1) Em quais situações será necessário realizar diagnóstico genético?  
- 2) O diagnóstico bioquímico deve incluir dosagem de metionina ou apenas homocisteína?  
- 3) Quais níveis de homocisteína são indicativos de tratamento?  
> 1 Republicada para consolidar as alterações introduzidas pela Portaria nº 981/GM/MS, de 20 de maio de 2014, publicada no Diário Oficial da União nº 95, de 21 de maio de 2014, Seção 1, página 44.  
4) A dieta hipoproteica e suplementação de aminoácidos é eficaz para os seguintes desfechos: sobrevida/mortalidade, eventos troemboembolicos, qualidade de vida, estado nutricional, densidade mineral óssea, luxação de cristalino, segurança (níveis de metionina), alterações neuropsiquiátricas, deficiência intelectual, níveis séricos de homocisteína, escoliose, convulsão?  
- 5) Quando utilizar B12 e B6?  
- 6) Qual melhor maneira de realizar teste de responsividade pirodoxina?

---

<!-- METADADOS: doenca: Homocistinúria Clássica | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
Foram consultadas a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da HCU. Foi também realizada busca por diretrizes nacionais e internacionais a respeito da doença.  
Não foram encontradas tecnologias disponíveis, já incorporadas ou em avaliação.  
As seguintes bases de diretrizes foram consultadas:  
- NICE guidelines (http://www.nice.org.uk/guidance/published?type=CG);  
- National Library of Australia – http://webarchive.nla.gov.au/gov/;  
- Diretrizes Associação Médica Brasileira (AMB).  
- Pubmed/Medline  
As únicas diretrizes localizadas foram as seguintes:  
- Guidelines for the diagnosis and management of cystathionine beta-synthase deficiency. Morris AA et al. J Inherit Metab  
- Dis. (2017).  
Após a reunião de escopo, ficou estabelecido que o PCDT se destina a crianças e adultos com HCU, ambos os sexos, e tem  
por objetivo revisar práticas diagnósticas e terapêuticas e incorporar as recomendações referentes ao tratamento com fórmula metabólica isenta de metionina.  
Para elaboração dos critérios diagnósticos, foram utilizados _guidelines_ internacionais elaborados por diferentes grupos de especialistas, que são utilizados como consenso nos diversos centros de referência.  
Para avaliação das situações especiais de gestação e aleitamento, a estratégia de busca e seu resultado encontram-se na **Tabela A** , sendo incluídos apenas os estudos que descrevessem desfechos relacionados a essas situações especiais. A base de dados pesquisadas foi Medline/PubMed e foram incluídos todos os artigos encontrados referentes aos desfechos de interesse, sem restrição de idiomas.  
**Tabela A** - Resultados das buscas para avaliação das situações especiais de gestação e aleitamento publicados até 08/07/2019  
|Estratégia de Busca|Resultados|Incluídos|Referências Incluídas|
|---|---|---|---|
|“cystathionine<br>beta-synthase|144 artigos|10 artigos|(1, 15-19, 44-47)|
|deficiency AND pregnancy”||||
|“cystathionine<br>beta-synthase|16 artigos|Nenhum||
|deficiency AND breastfeeding”||||  
Para avaliação de interrupção de tratamento, foi utilizada a seguinte estratégia de busca: “cystathionine beta-synthase deficiency AND interruption”, sendo apenas dois resultados encontrados, listados abaixo. A base de dados buscada foi Medline/PubMed e as duas referências encontradas não respondiam à pergunta definida na reunião de escopo, sendo utilizados os guidelines internacionais acima citados para responder à questão.  
- Albuquerque EV, Scalco RC, Jorge AA. MANAGEMENT OF ENDOCRINE DISEASE: Diagnostic and therapeutic approach of  
tall stature. Eur J Endocrinol. 2017 Jun;176(6):R339-R353. doi: 10.1530/EJE-16-1054. Epub 2017 Mar 8. Review.  
- Miller JW, Nadeau MR, Smith J, Smith D, Selhub J. Folate-deficiency-induced homocysteinaemia in rats: disruption of S-  
adenosylmethionine's co-ordinate regulation of homocysteine metabolism. Biochem J. 1994 Mar 1;298 ( Pt 2):415-9.  
||Para elaboração dos demais itens do PCDT foram utilizadas as buscas, recomenda|ções e referências do relatório nº 448|
|---|---|---|
|de|recomendação<br>da<br>fórmula<br>de<br>aminoácidos|isenta<br>de<br>metionina|
|http:|//conitec.gov.br/images/Relatorios/2019/Relatorio_FMIM_homocistinuria_FINAL_448|_2019.pdf|

---

