<!-- METADADOS: doenca: Hipoparatireoidismo | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA CONJUNTA SAES/SCTIE Nº 70, DE 05 DE AGOSTO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Hipoparatireoidismo.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E**  
**INOVAÇÃO EM SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, e,  
Considerando a necessidade de se atualizarem os parâmetros sobre Hipoparatireoidismo no Brasil e as diretrizes nacionais para  
diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Relatório de Recomendação nº 1074/2025e o Registro de Deliberação nº 1075/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Hipoparatireoidismo.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Asma, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt- <u>br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados,</u> do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento de Hipoparatireoidismo.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede  
assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS nº 450, publicada no Diário Oficial da União nº82, de 02 de maio de 2016, seção 1, pág. 53.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES  
FERNANDA DE NEGRI  
1

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **1. INTRODUÇÃO** -->
O hipoparatireoidismo é uma afecção caracterizada por ausência ou concentrações inadequadamente baixas de hormônio da paratireoide (PTH) circulante, levando à hipocalcemia, hiperfosfatemia e fracionamento elevado da excreção urinária de cálcio<sup>1,2</sup> .  
O cálcio é um dos elementos mais abundantes no organismo humano e é essencial para formação óssea, transmissão nervosa e contração muscular. Sua regulação é realizada pela ação dos hormônios calcitonina, PTH e vitamina D que controlam o transporte de cálcio no intestino, nos rins e nos ossos<sup>3,4</sup> . A calcitonina, liberada pelas células parafoliculares da tireoide em resposta a um aumento no cálcio sérico, estimula os osteoblastos a depositarem cálcio nos ossos, bem como inibe a reabsorção renal de cálcio, aumentando sua excreção urinária, e impede a absorção de cálcio no intestino. As glândulas paratireoides liberam o PTH, uma molécula composta de 84 aminoácidos, e que é o principal hormônio de controle dos níveis circulantes de cálcio<sup>1,3,4</sup> . Na vigência de uma diminuição do cálcio sérico, o PTH atua nos rins para aumentar a reabsorção de cálcio. Os rins respondem ao estímulo do PTH aumentando a secreção de vitamina D, que por sua vez estimula a absorção de cálcio pelo intestino. Adicionalmente, o PTH atua nos ossos estimulando os osteoclastos envolvidos na reabsorção óssea e na liberação de cálcio livre<sup>3,4</sup> .  
A causa mais frequente de hipoparatireoidismo é o dano cirúrgico durante as cirurgias de tireoide, paratireoide e neoplasias de cabeça e pescoço<sup>5–7</sup> . As doenças autoimunes das paratireoides são a segunda causa mais comum de hipoparatireoidismo<sup>2,8</sup> . Outras causas menos frequentes envolvem: a) doenças genéticas<sup>9,10</sup> b) doenças infiltrativas, como hemocromatose, doença de Wilson e metástase<sup>1</sup> , c) doenças de depósito<sup>11,12</sup> , d) lesão por irradiação, e) idiopáticas<sup>13.</sup> . Adicionalmente, pode ser decorrente de hipomagnesemia<sup>14</sup> ou hipermagnesemia<sup>15</sup> , sendo chamado nesses casos de hipoparatireoidismo funcional, pois é reversível com a correção dos distúrbios do magnésio<sup>1</sup> .  
Outra condição relacionada ao PTH é o pseudo-hipoparatireoidismo, caracterizado pela resistência tecidual à ação do hormônio da paratireoide, doença hereditária rara, evidenciada por hipocalcemia e níveis normais ou altos de hormônio da paratireoide<sup>2,16</sup> .  
Estima-se que a prevalência do hipoparatireoidismo crônico nos Estados Unidos e na Escócia é similar, correspondendo a 37 e 40 casos por 100.000 indivíduos, respectivamente<sup>17,18</sup> . Adicionalmente, as taxas estimadas de prevalência do hipoparatireoidismo pós-cirúrgico apresentaram valores semelhantes entre os Estados Unidos e diferentes países europeus, variando entre 22 e 29 casos por 100.000 indivíduos<sup>17–19</sup> , com exceção da Noruega, em que a prevalência foi menor (6 casos por 100.000 indivíduos)<sup>20</sup> . De forma análoga, a prevalência do hipoparatireoidismo não cirúrgico apresentou semelhanças entre os países europeus e os Estados Unidos, variando entre 2 e 8 casos por 100.000 indivíduos<sup>18,20,21</sup> , com exceção da Escócia, em que a prevalência foi maior (17 casos por 100.000 indivíduos)<sup>17</sup> . Tais discrepâncias podem refletir variações reais na prevalência da doença, subdiagnóstico<sup>17,20</sup> ou diferenças nos resultados dos procedimentos cirúrgicos<sup>22</sup> , considerando que a causa mais frequente de hipoparatireoidismo decorre dessas intervenções cirúrgicas (75%)<sup>18,23–25</sup> . Esses dados evidenciam a heterogeneidade existente entre os estudos e seus respectivos subgrupos.  
Além disso, embora a prevalência de causas hereditárias de hipoparatireoidismo seja semelhante entre homens e mulheres<sup>26,27</sup> , o hipoparatireoidismo pós-cirúrgico é mais comum em mulheres do que nos homens<sup>28–33</sup> , pois o sexo feminino é mais propenso à tireoidectomia decorrente da maior prevalência de doença tireoidiana<sup>33–36</sup> . Ademais, cabe ressaltar que até o momento, não existem dados epidemiológicos brasileiros robustos de incidência ou prevalência dessa doença.  
2  
As principais comorbidades relacionadas ao hipoparatireoidismo são: dermatológicas (cabelos grossos, unhas quebradiças, psoríase, pele seca e prurido)<sup>37</sup> , deficiência na dentição<sup>38</sup> , oftálmica (catarata)<sup>39</sup> , cardíaca (arritmias e cardiomiopatia dilatada)<sup>40</sup> , renal (doença renal e nefrolitíase)<sup>41</sup> , sistema nervoso central (epilepsia e doença de Parkinson)<sup>42</sup> ; psiquiátricas (ansiedade e depressão)<sup>43</sup> ; miopatias<sup>44</sup> e sistema nervoso periférico (tetania, parestesia e cãibras musculares)<sup>45</sup> .  
A cirurgia extensa envolvendo a tireoide<sup>44</sup> , a redução no cálcio ionizável e a diminuição do paratormônio no pósoperatório das cirurgias cervicais são os principais fatores riscos para o desenvolvimento do hipoparatireoidismo<sup>46</sup> . A idade é um fator de risco independente após a cirurgia para o desenvolvimento do hipoparatireoidismo<sup>47</sup> .  
A Atenção Primária à Saúde (APS), como porta de entrada preferencial e ordenadora do cuidado na rede de atenção à saúde, exerce papel fundamental na promoção da saúde, na prevenção de doenças, na identificação de fatores de risco e na detecção precoce, oportunizando, desta forma, a promoção de intervenções oportunas e o encaminhamento adequado para o nível especializado de atenção à saúde quando necessário. O vínculo contínuo com os usuários e a atuação direta no território, princípios e diretrizes basilares da APS, possibilitam uma abordagem longitudinal e integral, favorecendo, por conseguinte, melhores desfechos terapêuticos e o prognóstico dos casos, além de fortalecer a coordenação do cuidado ao longo do tempo.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
E20.0 – Hipoparatireoidismo idiopático  
E20.1 – Pseudo-hipoparatireoidismo  
E20.8 – Outro hipoparatireoidismo  
E89.2 – Hipoparatireoidismo pós-procedimento

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **3.1. Diagnóstico clínico** -->
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, de raça, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.  
A manifestação clínica do hipoparatireoidismo é variável. A maioria dos sintomas decorre da hipocalcemia. A intensidade da hipocalcemia e a rapidez de sua instalação correlacionam-se aos sintomas. Ambos os fatores podem ter conexão com a etiologia do hipoparatireoidismo e o momento da doença (fase aguda ou crônica)<sup>49</sup> .  
Na causa mais comum, a do hipoparatireoidismo pós-cirúrgico, o início da hipocalcemia é agudo e rápido. Em geral, os sintomas são mais intensos, predominantemente neuromusculares e estão associados a hiperexcitabilidade neuromuscular. A hipocalcemia diminui o limiar para despolarização da membrana axonal com facilitação da transmissão do impulso nervoso. Na hipocalcemia grave (cálcio total abaixo de 7,5 mg/dL ou 1,9 mmol/L)<sup>50</sup> , pode haver risco iminente de vida, por arritmia cardíaca, broncoespasmo ou laringoespasmo. O eletrocardiograma pode apresentar alargamento do intervalo QT corrigido (maior que o normal de até 440 ms)<sup>51</sup> .  
Além disso, as manifestações mais comuns da irritabilidade neuromuscular leve incluem queixas parestésicas, que podem ser perioral, nas extremidades ou generalizadas, além de dores musculares, nas panturrilhas ou generalizadas, e câimbras. Em casos raros, a hipocalcemia pode manifestar-se por meio de queixas de mal-estar intenso e mal definido, acompanhado de uma sensação de morte iminente. A tetania pode ocorrer de forma espontânea e, em casos mais graves, pode haver convulsões focais ou tônico-crônicas generalizadas, mesmo na ausência de tetania ou parestesia<sup>49</sup> .  
3  
Atualmente, o hipoparatireoidismo pós-cirúrgico é considerado permanente se persistir por mais de 12 meses após a cirurgia<sup>52</sup> .  
Os sinais clínicos úteis para pesquisa de hipocalcemia são o sinal de Chvostek e o sinal de Trousseau, descritos no **Quadro 1** .  
**Quadro 1** - Sinais clínicos para avaliação de hipocalcemia em pacientes com suspeita de hipoparatireoidismo.  
|**Sinal Clínico**|**Método de Pesquisa**|**Resposta na Hipocalcemia**|**Observação**|
|---|---|---|---|
|Chvostek|Percussão do nervo facial,|Contratura da musculatura da face.|Possui baixa especificidade|
||cerca de 2 cm pré-auricular.||e sensibilidade.<br>Presente em até 25% de<br>pessoas sem hipocalcemia.<br>Ausente em até 29% dos<br>casos.|
|Trousseau|Compressão do braço com|Espasmo Carpal: flexão do pulso e|É mais confiável.|
||manguito do|articulações metacarpofalangeanas,|Presente em 1 a 4% de|
||esfigmomanômetro insuflado|extensão das articulações|pessoas sadias.|
||acima da pressão sistólica por|interfalangeanas distais e|Ausente em até 4% dos|
||3 minutos,|proximais, e adução do polegar e|indivíduos com|
|||dedos,|hipocalcemia.|  
Fonte: Adaptado de Maeda _et al_ (2006)<sup>49</sup> .  
A hipocalcemia crônica e leve pode ser assintomática e alguns indivíduos podem ser oligossintomáticos, de modo que, as queixas podem ser despercebidas pelos profissionais de saúde. Na fase crônica, os sintomas neuropsíquicos são os mais frequentes e algumas manifestações clínicas podem decorrer do tratamento<sup>36</sup> . O **Quadro 2** descreve algumas manifestações clínicas na fase crônica.  
**Quadro 2** - Manifestações clínicas na fase crônica.  
|**Órgão/Sistema/**<br>**Condição**|**Manifestação**|**Comentário**|
|---|---|---|
|Neurológica|Hiperexcitabilidade neuromuscular|Parestesias, câimbras, espasmos.|
|Ocular|Catarata|Ocorre em cerca de 50% dos casos não cirúrgicos e<br>pode ser o achado inicial. Maior tempo de<br>hipocalcemia. A apresentação é diferente da catarata<br>senil, com pequenos cristais. Prevalência mediana<br>estimada geral é de 17%.|
|Renal|Nefrolitíase e Nefrocalcinose|Complicação do tratamento. Prevalência estimada<br>em 15%.|
|Renal|Doença Renal Crônica|Complicação do tratamento. Prevalência estimada<br>em 12%.|
|Neurológica|Convulsão|Prevalência estimada em 11%.|
|Psiquismo|Depressão,<br>ansiedade,<br>distúrbio<br>bipolar|Prevalência (mediana) é 11%.|  
4  
|**Órgão/Sistema/**<br>**Condição**|**Manifestação**|**Comentário**|
|---|---|---|
|Infecção|Aumento risco de infecção do trato<br>urinário e respiratória|Prevalência (mediana) é 11%.|
|Mortalidade<br>por<br>qualquer causa|Diminuição da sobrevida|Prevalência (mediana) é 6%.|
|Cardiovascular|Arritmia|Prevalência (mediana) é 7%.|
|Cardiovascular|Doença Isquêmica|Prevalência (mediana) é 7%.|
|Ocular|Papiledema|Raro. Reversível com correção da hipocalcemia.|
|Neurológica|Calcificação em Gânglios da Base|52 a 74% dos casos. Impacto clínico não definido.<br>Em poucos casos, relato de parkinsonismo e distonia.|
|Cardiovascular|Prolongamento do intervalo QT|Reversível com correção da hipocalcemia.|
|Cardiovascular|Cardiomiopatia<br>dilatada<br>e<br>Insuficiência Cardíaca Congestiva|Raro. Reversível com correção da hipocalcemia.|
|Osso|Diminuição do remodelamento ósseo|Sem impacto clínico definido.|
|Dentes|Encurtamento das raízes e hipoplasia<br>do esmalte|Em<br>pacientes<br>com<br>hipoparatireoidismo<br>não<br>cirúrgico.|
|Muscular|Miopatia|Redução da força muscular.|
|Pele e anexos|Unhas quebradiças, pele seca e<br>escamosa|-|
|Digestiva|Esteatorreia|Rara e relacionada à menor secreção bilio-<br>pancreática.|  
Fonte: Adaptado de Mannstadt _et al._ (2017), Khan _et al._ (2022), e Yao _et al._ (2022)<sup>22,53,54</sup> .  
Outras manifestações podem estar associadas à etiologia do hipoparatireoidismo. Por exemplo, o hipoparatireoidismo da doença pluriglandular autoimune pode estar associado a candidíase mucocutânea, hipoadrenalismo, esteatorreia e alopecia<sup>55</sup> . Em algumas causas genéticas, pode haver hipoplasia do timo, hipoplasia renal e surdez em associação à hipocalcemia<sup>56</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **3.2. Diagnóstico laboratorial** -->
O diagnóstico laboratorial do hipoparatireoidismo inicia-se pela dosagem bioquímica de cálcio total ou ionizado no sangue. A faixa de normalidade do cálcio total é de 8,5 a 10,2 mg/dL (2,12 a 2,55 mmol/L)<sup>22,49</sup> . A adequada avaliação do cálcio total inclui a correção para o nível de albumina e é expressa na fórmula a seguir<sup>1</sup> :  
Cálcio Total corrigido = Cálcio total medido + [0,8 x (4,0 - Albumina sérica)]  
Assim, para cada 1 g/dL de albumina abaixo de 4 g/dL, deve-se adicionar 0,8 mg/dL à medida do cálcio total. A faixa de normalidade do cálcio ionizado é de 4,8 a 5,6 mg/dL (1,20 a 1,40 mmol/L)<sup>57</sup> .  
O diagnóstico de hipoparatireoidismo é definido pela detecção de hipocalcemia, definida como cálcio total corrigido para albuminemia menor que 8 mg/dL (2,2 mmol/L) ou cálcio iônico menor que 4 mg/dL (1,1 mmol/L), associada a níveis séricos de PTH baixos (PTH menor que 20 pg/mL ou menor que 2,1 pmol/L) ou inapropriadamente baixo ou normal considerando-se a hipocalcemia<sup>57,58</sup> .  
5  
Ademais, esses índices podem ser confirmados pelo menos duas vezes ao longo de um período de seis meses para que a condição reconhecida como hipoparatireoidismo crônico seja estabelecida<sup>59</sup> .  
A anamnese e o exame físico são fundamentais para presumir a etiologia. Em caso de suspeita de causas genéticas ou autoimunes, a investigação pode ser aprofundada com testes genéticos ou pesquisa de anticorpos<sup>57</sup> . Não há indicação para essas avaliações em casos de etiologia pós-cirúrgica<sup>57</sup> .  
Para a avaliação complementar, são necessárias as dosagens séricas de fósforo, magnésio, creatinina e vitamina D, assim como da calciúria em 24 horas<sup>57</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo crianças e adultos com suspeita ou diagnóstico laboratorial de hipoparatireoidismo.  
O tratamento com sais de cálcio e análogo de vitamina D deve ser iniciado somente após a confirmação do diagnóstico laboratorial.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo pacientes com hipoparatireoidismo transitório ou funcional que tenham a função das paratireoides normalizada. Pacientes com contraindicação, intolerância ou toxicidade aos medicamentos preconizados neste Protocolo serão excluídos do respectivo tratamento.  
Ainda, pacientes com hipoparatireoidismo funcional devido à hipomagnesemia ou hipermagnesemia que tenham a função das paratireoides normalizada após correção da magnesemia serão excluídos dos tratamentos específicos para hipoparatireoidismo, exceto aquele com magnésio.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **6.1. Pseudo-hipoparatireoidismo** -->
O diagnóstico do pseudo-hipoparatireoidismo é realizado por critérios clínicos maiores e menores, baseado em características clínicas e bioquímicas. Entre os critérios clínicos maiores estão a resistência do PTH, calcificações ectópicas e braquidactilia<sup>60</sup> . A resistência ao PTH por sua vez é diagnosticada por meio das seguintes alterações laboratoriais<sup>61,62</sup> :  
- Níveis elevados de PTH;  
- Hipocalcemia (dosagem sérica de cálcio total corrigido para albumina menor que 8 mg/dL (2 mmol/L) ou cálcio iônico  
- menor que 4 mg/dL (1 mmol/L));  
- Hiperfosfatemia (fósforo acima dos valores de referência, o qual varia com a idade), na ausência de deficiência de  
- vitamina D (menor que 20 ng/mL), redução da função renal e alterações dos níveis de magnésio.  
Aos pacientes com diagnóstico de pseudo-hipoparatireoidismo, aplicam-se os mesmos princípios do tratamento do hipoparatireoidismo.  
Adicionalmente, destaca-se que a taxa de filtração glomerular não é um parâmetro laboratorial para diagnóstico do pseudohipoparatireoidismo. Assim, seu uso é limitado ao monitoramento de pacientes com doença renal cursando com hipoparatireoidismo crônico.  
6

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7. TRATAMENTO** -->
O tratamento do hipoparatireoidismo tem o objetivo de reduzir a mortalidade e morbidade<sup>63</sup> da condição principal e suas comorbidades. Todavia, diversos fatores podem influenciar o controle de cálcio e a adesão ao tratamento<sup>24</sup> :  
a) socioeconômico e cultural: sexo, idade, menor escolaridade, menor renda, religião, acesso a transporte, distância, moradia em zona rural e situações de desastres e epidemias<sup>28,64</sup> ;  
b) próprias ao tratamento medicamentoso: custo, eventos adversos, esquemas complexos e tratamento contínuo e para toda a vida<sup>65–67</sup> ;  
c) sistema de saúde: relacionamento profissional de saúde e paciente, tipo e eficácia da comunicação, tratamento não individualizado, falha em identificar a não adesão e falta de atualização<sup>68–70</sup> ;  
d) dependente do paciente: negação da doença, falta de percepção do benefício do tratamento, conhecimento inadequado sobre a doença e do seu tratamento, esquecimento da tomada dos medicamentos, medo de dependência e dos efeitos adversos do tratamento e falta de apoio familiar<sup>67,71,72</sup> ;  
e) relacionada à doença: ausência de sintomas, complicações a longo prazo, presença de comorbidades associadas e modificação na qualidade de vida<sup>63,64,73</sup> .  
Frente à importância das evidências sobre a adequada adesão, estratégias devem ser implementadas para minimizar os efeitos no controle inadequado e, consequentemente, as repercussões deletérias com lesão de órgão-alvo, como o sistema renal<sup>63,64,73</sup> .  
Recomenda-se ações em nível educacional, de gestão clínica do tratamento e organizacional para estimular a adesão ao tratamento. As estratégias educacionais envolvem o acolhimento e orientação, abordando as consequências do tratamento inadequado, a curto e a longo prazo, podendo usar recursos tecnológicos, como o telemonitoramento, educação em saúde individual e grupal, uso de lembretes e caixas organizadoras de medicamentos, apoio familiar e social e envio de mensagem por telefonia móvel ou aplicativos<sup>73</sup> .  
A gestão clínica do tratamento permite evitar doses inadequadas, monitorar possíveis eventos adversos, com prescrições de fácil entendimento, escritas ou impressas, incluindo tratamento diferenciado para grupos específicos (afrodescendentes, idosos, mulheres, indivíduos com obesidade ou diabete). As ações de gestão organizacional incluem o estabelecimento de vínculo com a pessoa com hipoparatireoidismo, fixação da equipe de atendimento, linguagem simples, monitoramento de evasões ao tratamento, visitas domiciliares, abordagem multidisciplinar e acesso aos medicamentos<sup>63,64,73</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.1.1. Formas de Prevenção de Hipoparatireoidismo pós-cirúrgico** -->
O hipoparatireoidismo pós-cirúrgico é uma das complicações mais comum após procedimentos cirúrgicos cervicais, tais como tireoidectomia, que pode desencadear hipocalcemia e hiperfosfatemia<sup>74</sup> .  
Para prevenir essa complicação, recomenda-se a adoção de cuidado intraoperatórios e pós-operatórios. No intraoperatório, é importante preservar as glândulas paratireoides e o autotransplante de paratireoide, em casos de remoção inadvertida ou lesão irreversível das glândulas<sup>75</sup> .  
No pós-operatório, a prevenção deve priorizar o monitoramento dos níveis de cálcio, especialmente nas primeiras 24 a 48 horas após a cirurgia, com a suplementação de cálcio e vitamina D e a educação do paciente focada no reconhecimento de sinais e sintomas de hipocalcemia, para busca de assistência precoce<sup>76,77</sup> .  
7

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.1.2. Orientação nutricional** -->
Com o objetivo de prevenir e controlar a hiperfosfatemia, recomenda-se uma dieta com baixo teor de fósforo<sup>24,25</sup> . Entretanto, inexiste estudo específico direcionado aos pacientes com hipoparatireoidismo em relação aos valores nutricionais recomendados de fósforo, apenas para pacientes com doença renal crônica<sup>78</sup> .  
Uma dieta com baixo teor de fósforo é considerada um consumo diário inferior a 700 mg, que é o valor médio da necessidade nutricional diária para indivíduos saudáveis, segundo as recomendações nutricionais (RDA)<sup>79</sup> .  
O **Quadro 3** elenca a quantidade, em mg de fósforo, de alguns alimentos, lácteos e não lácteos<sup>80,81</sup> , ressaltando que alimentos ricos em cálcio (lácteos) apresentam alto teor de fósforo e, portanto, devem ser evitados. Adicionalmente, recomendase uma redução dos alimentos que são processados, cujo aditivo é a base de fósforo (ácido fosfórico, polifosfatos e pirofosfato), como alimentos embutidos, cereais, biscoitos, refrigerantes a base de cola, entre outros<sup>80</sup> . Neste sentido, alimentos _in natura_ são preferidos, por apresentarem menor disponibilidade de fósforo<sup>81,82</sup> .  
**Quadro 3** - Principais alimentos fontes de fósforo.  
|**Alimento**|**Quantidade (g)**|**Medida caseira**|**Fósforo (mg)**|
|---|---|---|---|
|Carne bovina|85|1 bife médio|209|
|Carne suína|80|1 bisteca média|147|
|Carne de frango|80|1 filé de peito médio|150|
|Pescada branca|84|1 filé médio|241|
|Ovo|50|1 unidade|90|
|Queijo prato|30|2 fatias|153|
|Leite|150|1 copo|140|
|Feijão cozido|154|1 concha média|133|
|Amendoim|50|1 pacote pequeno|252|
|Chocolate|40|1 barra pequena|92|  
Fonte: Adaptado de Carvalho e Barreto (2021)<sup>80,81</sup> .  
Para tratar a hipercalciúria e, consequentemente, prevenir a nefrolitíase, recomenda-se uma dieta com baixo teor de sódio<sup>25</sup> . Inexistem dados específicos para pacientes com hipoparatireoidismo, porém, a recomendação é manter uma ingestão diária de 1.500 a 2.300 mg de sal para os pacientes com hipercalciúria e nefrolitiase em geral<sup>83</sup> . Além disto, orienta-se evitar ingestão excessiva de proteína de origem animal, sendo a quantidade máxima recomendada de 1,0 g/kg de proteína ao dia<sup>84</sup> . O **Quadro 4** apresenta a quantidade de proteínas em alguns alimentos não lácteos<sup>80</sup> .  
**Quadro 4** - Principais alimentos fontes de proteínas não lácteas.  
|**Alimento**|**Quantidade (g)**|**Medida caseira**|**Proteína**|
|---|---|---|---|
|Carne bovina|85|1 bife médio|26,0|
|Carne suína|80|1 bisteca média|21,2|
|Carne de frango|80|1 filé de peito médio|23,0|
|Pescada branca|84|1 filé médio|20,6|
|Fígado de boi|85|1 bife médio|22,7|
|Ovo|50|1 unidade|6,0|
|Presunto|30|2 fatias|14,0|
|Feijão cozido|154|1 concha média|6,9|  
8  
|**Alimento**|**Quantidade (g)**|**Medida caseira**|**Proteína**|
|---|---|---|---|
|Amendoim|50|1 pacote pequeno|13,0|  
**Fonte:** Adaptado de Carvalho e Barreto (2021)<sup>80,81</sup>

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.1.3. Práticas Integrativas e Complementares em Saúde (PICS)** -->
A equipe de saúde deve se organizar junto aos profissionais especializados, como os componentes das equipes multiprofissionais, para mapear locais no território ou desenvolver ações e programas relacionados às práticas corporais e atividades físicas dentro dos estabelecimentos de saúde e polos do Programa Academia da Saúde na APS, além de fortalecer algumas atividades, como as Práticas Integrativas e Complementares em Saúde (PICS).  
As PICS, sempre que disponíveis nos serviços de saúde, devem compor o rol de ações e intervenções voltadas ao cuidado de indivíduos, complementando o tratamento da equipe multiprofissional. A Política Nacional de Práticas Integrativas e Complementares no SUS (PNPIC) orienta que estados, distrito federal e municípios instituam suas próprias normativas trazendo para o SUS práticas que atendam às necessidades regionais<sup>1</sup> . As PICS podem ser consideradas de forma complementar ao tratamento, devido aos possíveis benefícios aos pacientes com hipoparatireoidismo. Contudo, ressalta-se que as PICS não substituem os demais tratamentos preconizados pelo Protocolo e que o tratamento medicamentoso não pode ser interrompido sem orientação médica.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.2. Tratamento medicamentoso** -->
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.2.1. Metas terapêuticas e critérios para início de tratamento** -->
O objetivo do tratamento do hipoparatireoidismo e do pseudo-hipoparatireoidismo é aliviar os sintomas da hipocalcemia e prevenir complicações a longo prazo, mantendo o cálcio sérico, fósforo sérico e a vitamina D dentro dos valores de referência<sup>25,85</sup> .  
A dosagem de vitamina D sérica é o indicador mais confiável para monitorar os níveis de vitamina D. Os valores considerados como pontos de corte para pacientes com hipoparatireoidismo variam entre os estudos. No entanto, para pacientes com doenças ósseas, valores iguais ou acima de 30 ng/mL (80 nmol/L) são considerados dentro da faixa normal. Em pacientes que usam calcitriol e cálcio, espera-se atingir níveis séricos de até 60 ng/mL. Já em pacientes graves e que usam apenas colecalciferol pode-se atingir níveis acima de 80 ng/mL<sup>86–88</sup> .  
O tratamento com sais de cálcio e análogo de vitamina D deve ser iniciado logo após o diagnóstico do hipoparatireoidismo ou pseudo-hipoparatireoidismo. As doses dependerão da gravidade da hipocalcemia, do tipo do sal de cálcio e da presença ou não de comorbidades associadas<sup>25,85</sup> .  
9  
Em uma situação de hipocalcemia grave com manifestações agudas (tetania, convulsões, laringoespasmo, broncoespasmo ou falência cardíaca) ou hipofosfatemia grave, o tratamento urgente com cálcio intravenoso está indicado. Neste caso, é indicado o gliconato de cálcio 10 % (90 mg de cálcio elementar por 10 mL de solução por ampola) diluído em 100 mL de solução salina 0,9% ou soro glicosado 5%, com administração lenta (10 a 20 minutos). A dose de manutenção de gliconato de cálcio em infusão contínua é de 0,5 a 2,0 mg/kg de peso, diluído em soro glicosado a 5%<sup>85</sup> .  
Destaca-se também que o alfacalcidol não é mais utilizado na prática clínica e foi excluído do SUS, por meio da Portaria SECTICS/MS nº 56/2024<sup>89</sup> . Dessa forma, este Protocolo não recomenda o seu uso.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.2.2. Hipercalciúria** -->
Em algumas situações, a abordagem medicamentosa baseada na associação cálcio + vitamina D em doses elevadas pode ocasionar complicações, dentre elas, a hipercalciúria, que requer redução das doses de cálcio e vitamina D, bem como administração de diuréticos tiazídicos, para corrigir a hipercalciúria<sup>24,25</sup> .  
Neste sentido, é recomendado o uso de diuréticos tiazídicos (hidroclorotiazida) nas doses iniciais diárias de 12,5 mg e 25 mg, respectivamente<sup>90</sup> . Estas doses podem ser aumentadas até o máximo de 50 mg de hidroclorotiazida, duas vezes ao dia. O uso dos diuréticos tiazídicos para o tratamento da hipercalciúria está indicado quando o cálcio na urina 24 horas for superior a 250 mg/dia em mulheres e 300 mg/dia em homens, ou acima de 4 mg/kg/dia<sup>25</sup> . É importante salientar que os diuréticos tiazídicos são contraindicados na gestação, em pacientes com insuficiência adrenal, com hipocalcemia autossômica dominante ou com síndrome de Bartter<sup>91</sup> . Além disso, a utilização de diuréticos tiazídicos pode permitir uma redução nas doses posológicas dos suplementos de cálcio e vitamina D<sup>24,25</sup> . O controle da hipercalciúria está relacionado com a prevenção de nefrolitíase<sup>25</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.2.3. Hiperfosfatemia** -->
Na prevenção da hiperfosfatemia, é indicada uma dieta com baixo teor de fósforo, assim como o uso dos sais de cálcio junto com as refeições, servindo como quelantes de fósforo. Adicionalmente, a dose do análogo da vitamina D deve ser reavaliada e, se possível, reduzida. Inexistem dados sobre o uso de outros quelantes de fósforo, como cloridrato de sevelâmer, em pacientes com hipoparatireoidismo<sup>25</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.2.4. Hipomagnesemia** -->
O magnésio desempenha um papel fundamental em diversos processos fisiológicos, incluindo a secreção e as ações do PTH. A redução nos níveis de magnésio pode resultar em hipoparatireoidismo funcional, uma vez que comprometem a capacidade residual das glândulas paratireoides de secretar PTH<sup>24,92,93</sup> . Adicionalmente, a deficiência de magnésio pode manifestar sintomas clínicos semelhantes aos observados na hipocalcemia. Assim, recomenda-se que os níveis séricos de magnésio sejam determinados após a avaliação da hipocalcemia, a fim de descartar a possibilidade de hipoparatireoidismo funcional<sup>93</sup> . Diante disso, é recomendável que os níveis séricos de magnésio sejam mantidos dentro dos valores de referência estabelecidos<sup>24,92,93</sup> .  
Nos pacientes que apresentem redução significativa de magnésio, abaixo de 1 mg/dL, e manifestações clínicas de hiperexcitabilidade neuromuscular (tetania, convulsões, fasciculações e fraqueza muscular), além de hipocalemia e alterações no eletrocardiograma, deve-se repor magnésio por via intravenosa com 1 g a 2 g sulfato de magnésio em até 15 minutos, podendo chegar a 6 g em 24 horas. Recomenda-se manter a reposição por 3 a 7 dias, com o paciente monitorado em unidade de terapia intensiva<sup>94</sup> .  
Para pacientes assintomáticos ou com hipomagnesemia leve a moderada, a reposição oral é a abordagem preferencial. As preparações orais devem ser iniciadas em doses baixas e aumentadas gradualmente, sendo recomendada uma dose diária de 800 mg a 1.600 mg (40 a 80 mEq ou 20 a 40 mmol) para casos moderados a graves<sup>95</sup> . A suplementação oral de magnésio geralmente  
10  
é bem tolerada, mas pode desencadear efeitos gastrointestinais como diarreia, náuseas e vômitos. Em pacientes com distúrbios gastrointestinais pré-existentes, essa terapia pode ser desafiadora, pois a diarreia induzida pelo magnésio pode agravar o déficit<sup>95</sup> .  
O magnésio compartilha vias metabólicas semelhantes às do cálcio, e sua concentração pode diminuir, particularmente em situações de hipocalcemia. Geralmente, os níveis de magnésio se normalizam concomitantemente aos do cálcio. No entanto, em determinados casos, a suplementação com sais de magnésio pode ser necessária para restabelecer os níveis adequados deste mineral<sup>24</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.2.5. Acloridria** -->
O uso de inibidores de bombas de prótons ou a realização de gastrectomias podem levar à redução na absorção do carbonato de cálcio, uma vez que este sal necessita de acidez gástrica para sua adequada absorção<sup>25,126</sup> .  
Ressalta-se que o uso prolongado de inibidores de bomba de prótons pode levar a um quadro de hipomagnesemia grave<sup>96</sup> .  
A **Figura 1** descreve o algoritmo de tratamento dos pacientes com hipoparatireoidismo, baseado nas recomendações deste Protocolo.  
**Figura 1** - Fluxograma de tratamento de pacientes com hipoparatireoidismo.  
<!-- Start of picture text -->
Individuo diagnosticado com hipoparatireoidismo<br>Considerar suporte nutricional, conforme PCDT<br>Tratamento com calcio +<br>colecalciferol e calcitriol<br>Sim Pacientes com Nao<br>manifestagdeshipocalcemia agudas?grave e i<br>Gliconato10% e iniciarde calcio ou : carbonatoManutencaode calcio do<br>manter carbonato de + colecalciferol e<br>calcio + colecalciferol e. calcitriol<br>calcitriol ———s<br>Sim Pacientes com Nao<br>hipercalcitiria?<br>]<br>Ajuste da dose de calcio. Manutenc&o de<br>e adicionar tratamento | carbonato de calcio +<br>com diuréticos tiazidicos, colecalciferol e calcitriol)<br>eee {TESS J<br>Monitorar resposta, adesdo<br>ao tratamento e reacgdes<br>adversas<br>Apds o diagndstico de hipoparatireoidismo, o tratamento com carbonato de calcio +|<br>|colecalciferol e calcitriol deve ser mantido regularmente, uma vez quea interrupcao dos|<br>Imedicamentos pode levar a reducdo do calcio sérico e aumento do fésforo sérico. O ajuste<br>\da dose deve ser realizado de acordo com o resultado dos exames de monitoramento.<br><!-- End of picture text -->  
Fonte: elaboração própria.  
11

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.3. Medicamentos** -->
- Calcitriol: cápsulas de 0,25 mcg;  
- Carbonato de cálcio + colecalciferol: comprimidos de 500 mg de cálcio + 200 UI;  
- Carbonato de cálcio + colecalciferol: comprimidos de 500 mg de cálcio + 400 UI;  
- Carbonato de cálcio + colecalciferol: comprimidos de 600 mg de cálcio + 400 UI;  
- Carbonato de cálcio: comprimidos de 500 mg de cálcio elementar;  
- Gliconato de cálcio: solução injetável 10%.  
- Hidroclorotiazida: comprimidos de 12,5 mg e 25 mg;  
- Sulfato de magnésio: solução injetável de 10% ou 50%;  
NOTA: Sulfato de magnésio e gliconato de cálcio devem ser utilizados no tratamento de casos graves, em ambiente hospitalar.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.4. Tempo de tratamento e esquemas de administração** -->
O tratamento padrão deve ser mantido por toda a vida. O gliconato de cálcio deve ser administrado apenas em casos de hipocalcemia grave com manifestações agudas ou hipofosfatemia grave, em ambiente hospitalar, até a resolução do quadro clínico. Após a estabilização, o paciente deve retornar ao tratamento oral otimizado<sup>24,59,92</sup> .  
**Carbonato de cálcio ou carbonato de cálcio + colecalciferol:** dose usual de 2 a 3 g de cálcio ao dia, por via oral, em duas ou três administrações, juntamente com as refeições. Caso o paciente utilize doses maiores, recomenda-se fracionamento em 3 a 4 administrações<sup>49,54,64,65</sup> . Se o paciente necessitar apenas da reposição de cálcio e ele estiver disponível apenas em associação com colecalciferol, deve-se optar pelo uso da menor dose de colecalciferol<sup>24,92,93</sup> . Se for necessário o uso de carbonato de cálcio + colecalciferol, a dose do colecalciferol deve ser selecionada de acordo com a necessidade do paciente.  
**Calcitriol:** dose inicial de 0,25 mcg, por via oral, 1 vez ao dia, com ajuste de dose subsequente de acordo com a calcemia. A dose de manutenção é geralmente de 0,25 a 3 mcg ao dia em uma ou duas administrações, porém nos casos mais graves, recomenda-se fracionamento em 3 ou 4 vezes<sup>25,85,92,93</sup> .  
**Hidroclorotiazida:** Pode ser utilizado no controle da hipercalciúria nas doses de 12,5 a 50 mg ao dia, até atingir níveis adequado de cálcio<sup>25,85,92,93</sup> .  
**Gliconato de cálcio:** 1 a 2 ampolas de 10%, por via intravenosa, em 10 a 20 minutos nos casos de hipocalcemia grave, que se manifesta com tetania, arritmias, convulsões ou prolongamento do intervalo QT no eletrocardiograma<sup>25,85,92,93</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.5.1. Gravidez e lactação** -->
O tratamento dos distúrbios da paratireoide durante a gravidez pode ser desafiador e difere significativamente de várias maneiras em pacientes não grávidas. As evidências científicas de avaliações sistemáticas sobre esta questão são muito limitadas, em particular no que diz respeito ao tratamento materno e aos resultados fetais<sup>97–101</sup> . Portanto, há necessidade de cuidados especiais.  
Alguns pontos devem ser salientados:  
a) a expansão do volume plasmático durante a gravidez com subsequente redução das concentrações de albumina contribui para uma diminuição nas concentrações totais de cálcio. Mas o cálcio ionizado (livre) e o cálcio ajustado à albumina permanecem inalterados durante a gravidez e podem ser parâmetros na decisão clínica<sup>98–101</sup> ;  
b) O cálcio necessário para o crescimento do esqueleto fetal deriva principalmente do aumento da absorção intestinal de cálcio e outros minerais na mãe<sup>98–101</sup> , portanto, níveis adequados de cálcio são necessários tanto para mãe como para o concepto;  
12  
c) As concentrações de PTH são mais baixas em mulheres grávidas em comparação com mulheres não grávidas, geralmente no limite inferior da faixa normal ou ligeiramente abaixo do limite inferior<sup>98–101</sup> ;  
d) o PTH não atravessa a barreira hemato-placentária<sup>98–101</sup> .  
Não existe um rastreamento para hipoparatireoidismo eficaz durante o pré-natal. Em geral, a paciente já possui diagnóstico prévio à gestação ou o diagnóstico é realizado com base na sintomatologia<sup>97–101</sup> .  
Em mulheres grávidas sem diagnóstico conhecido, sintomas hipocalcêmicos, como parestesia, dores musculares ou mesmo cãibras devem levar a avaliações laboratoriais com dosagens de cálcio. Se for detectada hipocalcemia, o PTH e a vitamina D devem ser determinados para avaliar o diagnóstico de hipoparatireoidismo como uma condição com hipocalcemia em combinação com concentrações de PTH reduzidas ou inadequadamente baixas. Deve-se ainda valorizar o antecedente de cirurgia cervical anterior à hipótese diagnóstica de hipoparatireoidismo na gravidez<sup>102</sup> .  
No hipoparatireoidismo, a função renal pode estar acometida, o que pode piorar a evolução da pré-eclâmpsia<sup>103</sup> . O principal risco para o feto de gestantes com hipoparatireoidismo ou pseudo-hipoparatireoidismo é o desenvolvimento de hiperparatireoidismo secundário e desmineralização óssea. A vitamina D com maior experiência de uso durante a gestação é o calcitriol. Ao longo da gestação, há necessidade de aumento da dose do calcitriol para a manutenção dos níveis de cálcio no limite inferior da normalidade. Após o parto, as necessidades de calcitriol retornam para o patamar pré-gestacional<sup>99,103–105</sup> .  
No tratamento, a suplementação de vitamina D é recomendada, bem como de cálcio, sendo que ambos são tratamentos seguros durante a gravidez. O uso de diuréticos tiazídicos deve ser interrompido durante a gestação e o PTH recombinante não está adequadamente avaliado<sup>1</sup> . Nos casos de deficiência de magnésio associada, este pode ser suplementado. Em casos de hipocalcemia aguda com tetania e/ou arritmias cardíacas, pode ser empregado 1 a 2 g de gliconato de cálcio por via intravenosa durante 10 minutos<sup>102</sup> .  
O monitoramento dos casos de hipoparatireoidismo em gestantes deve ser realizado durante a confirmação da gravidez pelo beta-hCG nos casos previamente conhecidos ou quando houver o diagnóstico durante a gestação, por meio das dosagens séricas de cálcio, fosfato, vitamina D, magnésio, taxa de filtração glomerular e excreção urinária de cálcio<sup>99,103</sup> .  
A faixa de normalidade do cálcio total no soro deve ser corrigida para albuminemia no limite inferior da normalidade, isto é, entre 8 e 8,5 mg/dL (2 e 2,1 mmol/L)<sup>103</sup> . Quando houver excreção excessiva de cálcio ou sintomatologia, o ultrassom de vias urinárias pode ser indicado, bem como de vitalidade fetal<sup>99</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **7.5.2. Crianças e adolescentes** -->
As formas genéticas de hipoparatireoidismo raramente se manifestam como hipocalcemia neonatal, que está mais provavelmente associada à prematuridade, asfixia ao nascer, diabete materno, hipomagnesemia, alcalose metabólica, aumento da carga de fosfato ou defeitos no metabolismo da vitamina D<sup>25</sup> . O diagnóstico é feito com os mesmos critérios que a população adulta. Em linhas gerais, o tratamento é feito com os mesmos medicamentos utilizados nos adultos, atentando-se à individualização das doses<sup>25</sup> .  
Em comparação com adultos com hipoparatireoidismo pós-cirúrgico, as crianças com hipoparatireoidismo não cirúrgico apresentam maiores desafios para o controle da doença e apresentam prevalência relativamente alta de doenças renais e cerebrais, e calcificações, quando tratadas com terapia convencional no longo prazo<sup>25</sup> .  
Ademais, crianças com hipoparatireoidismo necessitam de cálcio, magnésio e vitamina D adequados na dieta, a fim de apoiar o crescimento linear normal e acúmulo de massa óssea. Uma dieta muito restrita em fosfato pode ser desaconselhável em crianças com hipoparatireoidismo, pois as crianças serão obrigadas a reduzir a ingestão de laticínios<sup>25</sup> .  
Considerando o tempo de exposição da doença, é essencial um bom controle metabólico e monitorização de complicações renais e oftalmológicas, que são as mais comuns<sup>25</sup> .  
13

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **8. MONITORAMENTO** -->
Recomenda-se acompanhar os pacientes com hipoparatireoidismo e pseudo-hipoparatireoidismo por meio das dosagens regulares de cálcio e fósforo séricos, creatinina, vitamina D e de creatinúria e calciúria em 24 horas<sup>25,85,91,106</sup> .  
No início do tratamento, os exames devem ser realizados com periodicidade de 7 a 14 dias, com intervalo interconsultas espaçadas progressivamente mediante ajuste de dose. Após o ajuste de tratamento, as consultas podem ser feitas a cada 3 ou 6 meses<sup>25,85,91,106</sup> .  
Para pacientes estáveis, há recomendação de dosagem de cálcio, creatinina, magnésio e fósforo entre 3 e 12 meses. A vitamina D deve ser verificada a cada 6 a 12 meses. O cálcio em urina de 24 horas deve ser analisado a cada 6 a 24 meses<sup>53</sup> .  
Durante a gravidez, os exames devem ser avaliados a cada 2 ou 3 semanas e a cada 4 semanas durante a lactação<sup>25,85,92,99</sup> .  
A função renal deve ser avaliada periodicamente com taxa de filtração glomerular estimada e exames de imagem (ultrassonografia, a cada dois anos em pacientes com hipercalciúria e a cada cinco entre aqueles com aumento da creatinina). Imagens cerebrais devem ser solicitadas caso o paciente apresente sintomas neurológicos<sup>85,91,92,106</sup> .  
Recomenda-se avaliação oftalmológica entre pacientes idosos e aqueles com mais tempo de doença<sup>85,91,92,106</sup>  
Em caso de alterações laboratoriais, a vigência de hipocalcemia requer avaliação da adesão ao tratamento<sup>25,85,91,106</sup> .  
O gliconato de cálcio é a formulação preferencial para a reposição intravenosa de cálcio, pelo menor risco de necrose tecidual nos casos de extravasamento vascular durante a infusão. Quando for feita a infusão de cloreto de cálcio, recomenda-se que seja feito em acesso central para minimizar o risco de extravasamento<sup>25,85,92,93</sup> .  
Ao administrar diuréticos tiazídicos é preciso considerar que o efeito hipocalciúrico é dose-dependente. Recomenda-se a associação do tratamento com a restrição de sódio para potencializar os efeitos terapêuticos. Para a redução do cálcio urinário em um período de 24 horas, é comumente necessária a administração de doses relativamente elevadas em duas tomadas diárias, como 50 mg de hidroclorotiazida duas vezes ao dia<sup>92,93</sup> . No entanto, o aumento da dose está associado a um risco elevado de eventos adversos, que devem ser monitorados ao longo do tratamento, incluindo distúrbios eletrolíticos, como os níveis de magnésio e potássio e alterações na pressão arterial. Em particular, durante o uso de hidroclorotiazida, é fundamental atentar-se ao efeito hipotensor e ao risco de hipopotassemia, hipomagnesemia e hiperuricemia<sup>25,85,92,93</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **9. GESTÃO E CONTROLE** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento e acompanhamento pós-tratamento<sup>107,108</sup> .  
Na APS, o diagnóstico de hipoparatireoidismo pode ser estabelecido a partir da suspeita clínica, especialmente em pacientes que apresentam sintomas como parestesias, cãibras ou espasmos musculares, bem como em indivíduos com histórico de cirurgia tireoidiana ou cervical. Para a avaliação inicial, a APS pode solicitar exames laboratoriais, incluindo a dosagem de cálcio sérico, de fósforo e de PTH, com o objetivo de identificar hipocalcemia, hiperfosfatemia e níveis reduzidos ou inadequados de PTH. Caso os resultados laboratoriais corroborem a suspeita diagnóstica, o tratamento inicial pode ser instituído na própria APS. No entanto, na impossibilidade de realizar esses exames ou de confirmar o diagnóstico, é necessário encaminhar o paciente a um serviço especializado, como a endocrinologia, para a confirmação diagnóstica e a implementação do tratamento adequado<sup>107,108</sup> . Nos casos em que haja adesão ao tratamento e o paciente não apresente comorbidades associadas, o paciente poderá ser acompanhado apenas na APS<sup>107,108</sup> . Nesse contexto, a APS pode contribuir com a solicitação periódica dos exames laboratoriais recomendados para monitoramento de pacientes estáveis.  
14  
A atuação da APS inclui ainda a promoção da educação em saúde, com foco na adesão ao tratamento, no uso correto dos medicamentos, no reconhecimento de sinais de alerta, na compreensão da necessidade do monitoramento laboratorial e na adoção de modos de vida que favoreçam o controle da condição.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Pacientes com hipoparatireoidismo ou pseudo-hipoparatireoidismo podem ter direito à concessão de benefício previdenciário. Contudo, o médico responsável pelo acompanhamento do paciente deve informar, para fins de encaminhamento, o tempo da doença e comorbidades, uma vez que apenas a informação sobre o código da CID-10 não configura doença grave ou descompensada<sup>74,75</sup> .  
Como parte da rede de Atenção Primária à Saúde, o Programa Academia da Saúde é uma estratégia de promoção da saúde e produção do cuidado que funciona com a implantação de espaços públicos conhecidos como polos, voltados ao desenvolvimento de ações culturalmente inseridas e adaptadas aos territórios locais e que adotam como valores norteadores de suas atividades o desenvolvimento de autonomia, equidade, empoderamento, participação social, entre outros. Nesse sentido, deve ser observado o artigo 7° da Portaria de Consolidação nº 5, de 28 de setembro de 2017, que estabelece os seguintes eixos de ações para serem desenvolvidos nos polos do programa: Práticas corporais e Atividades físicas; produção do cuidado e de modos de vida saudáveis; promoção da alimentação saudável; PICS; práticas artísticas e culturais; educação em saúde; planejamento e gestão; e mobilização da comunidade.  
Em relação às PICS, estas práticas foram institucionalizadas pela PNPIC. Uma das ideias centrais dessa abordagem é uma visão ampliada do processo saúde e doença, assim como a promoção do cuidado integral do ser humano, especialmente do autocuidado. As indicações às práticas se baseiam no indivíduo como um todo, considerando seus aspectos físicos, emocionais, mentais e sociais. As PICS não substituem o tratamento tradicional e podem ser indicadas por profissionais específicos conforme as necessidades de cada caso.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Recomenda-se informar o paciente e/ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **11. REFERÊNCIAS** -->
1.  Shoback D. Clinical practice. Hypoparathyroidism. N Engl J Med. 2008 Jul 24;359(4):391–403.  
2.  Husebye ES, Perheentupa J, Rautemaa R, Kämpe O. Clinical manifestations and management of patients with autoimmune polyendocrine syndrome type I. J Intern Med. 2009 May;265(5):514–29.  
3.  Munoz F, Hu H. The Role of Store-operated Calcium Channels in Pain. Adv Pharmacol. 2016;75:139–51.  
4.  Keung L, Perwad F. Vitamin D and kidney disease. Bone Rep. 2018 Dec;9:93–100.  
5.  Shoback D. Hypoparathyroidism. New England Journal of Medicine. 2008 Jul 24;359(4):391–403.  
6.  Bilezikian JP, Khan A, Potts JT, Brandi ML, Clarke BL, Shoback D, et al. Hypoparathyroidism in the adult: Epidemiology, diagnosis, pathophysiology, target-organ involvement, treatment, and challenges for future research. Journal of Bone and Mineral Research. 2011 Oct 1;26(10):2317–37.  
15  
7.  Powers J, Joy K, Ruscio A, Lagast H. Prevalence and Incidence of Hypoparathyroidism in the United States Using a Large Claims Database. Journal of Bone and Mineral Research. 2013 Dec 1;28(12):2570–6.  
8.  Shikama N, Nusspaumer G, Holländer GA. Clearing the AIRE: on the pathophysiological basis of the autoimmune polyendocrinopathy syndrome type-1. Endocrinol Metab Clin North Am. 2009 Jun;38(2):273–88, vii.  
9.  Thakker R V. Genetics of endocrine and metabolic disorders: parathyroid. Rev Endocr Metab Disord. 2004 Mar;5(1):37–51.  
10.  Carpenter TO, Carnes DL, Anast CS. Hypoparathyroidism in Wilson’s Disease. New England Journal of Medicine. 1983 Oct 13;309(15):873–7.  
11.  Toumba M, Sergis A, Kanaris C, Skordis N. Endocrine complications in patients with Thalassaemia Major. Pediatr Endocrinol Rev. 2007 Dec;5(2):642–8.  
12.  de Sèze S, Solnica J, Mitrovic D, Miravet L, Dorfmann H. Joint and bone disorders and hypoparathyroidism in hemochromatosis. Semin Arthritis Rheum. 1972;2(1):71–94.  
13.  Goswami R, Goel S, Tomar N, Gupta N, Lumb V, Sharma YD. Prevalence of clinical remission in patients with sporadic idiopathic hypoparathyroidism. Clin Endocrinol (Oxf). 2010 Mar;72(3):328–33.  
14.  Cole DEC, Quamme GA. Inherited disorders of renal magnesium handling. J Am Soc Nephrol. 2000 Oct;11(10):1937–47.  
15.  Koontz SL, Friedman SA, Schwartz ML. Symptomatic hypocalcemia after tocolytic therapy with magnesium sulfate and nifedipine. Am J Obstet Gynecol. 2004 Jun;190(6):1773–6.  
16.  Bilezikian JP, Khan A, Potts JT, Brandi ML, Clarke BL, Shoback D, et al. Hypoparathyroidism in the adult: epidemiology, diagnosis, pathophysiology, target-organ involvement, treatment, and challenges for future research. J Bone Miner Res. 2011 Oct;26(10):2317–37.  
17.  Vadiveloo T, Donnan PT, Leese GP. A Population-Based Study of the Epidemiology of Chronic Hypoparathyroidism. Journal of Bone and Mineral Research. 2018 Mar 1;33(3):478–85.  
18.  Clarke BL, Brown EM, Collins MT, Jüppner H, Lakatos P, Levine MA, et al. Epidemiology and Diagnosis of Hypoparathyroidism. J Clin Endocrinol Metab. 2016 Jun;101(6):2284–99.  
19.  Underbjerg L, Sikjaer T, Mosekilde L, Rejnmark L. Cardiovascular and renal complications to postsurgical hypoparathyroidism: A Danish nationwide controlled historic follow-up study. Journal of Bone and Mineral Research. 2013 Nov 1;28(11):2277–85.  
20.  Astor MC, Løvås K, Debowska A, Eriksen EF, Evang JA, Fossum C, et al. Epidemiology and Health-Related Quality of Life in Hypoparathyroidism in Norway. J Clin Endocrinol Metab. 2016 Aug;101(8):3045–53.  
21.  Underbjerg L, Sikjaer T, Mosekilde L, Rejnmark L. The Epidemiology of Nonsurgical Hypoparathyroidism in Denmark: A Nationwide Case Finding Study. Journal of Bone and Mineral Research. 2015 Sep 1;30(9):1738–44.  
22.  Mannstadt M, Bilezikian JP, Thakker R V, Hannan FM, Clarke BL, Rejnmark L, et al. Hypoparathyroidism. Nat Rev Dis Primers. 2017 Aug 31;3:17055.  
23.  Shoback DM, Bilezikian JP, Costa AG, Dempster D, Dralle H, Khan AA, et al. Presentation of Hypoparathyroidism: Etiologies and Clinical Features. J Clin Endocrinol Metab. 2016 Jun;101(6):2300–12.  
24.  Maeda SS, Moreira CA, Borba VZC, Bandeira F, Farias MLF de, Borges JLC, et al. Diagnosis and treatment of hypoparathyroidism: a position statement from the Brazilian Society of Endocrinology and Metabolism. Arch Endocrinol Metab. 2018;62(1):106–24.  
25.  Khan AA, Guyatt G, Ali DS, Bilezikian JP, Collins MT, Dandurand K, et al. Management of Hypoparathyroidism. Journal of Bone and Mineral Research. 2022 Dec 1;37(12):2663–77.  
16  
26.  Miller BS, Dimick J, Wainess R, Burney RE. Age‐ and Sex‐Related Incidence of Surgically Treated Primary Hyperparathyroidism. World J Surg. 2008 May 31;32(5):795–9.  
27.  Mazeh H, Sippel RS, Chen H. The Role of Gender in Primary Hyperparathyroidism: Same Disease, Different Presentation. Ann Surg Oncol. 2012 Sep 26;19(9):2958–62.  
28.  Chen K, Krasner A, Li N, Xiang CQ, Totev T, Xie J. Clinical burden and healthcare resource utilization among patients with chronic hypoparathyroidism, overall and by adequately vs not adequately controlled disease: a multicountry chart review. J Med Econ. 2019 Nov 2;22(11):1141–52.  
29.  Gut L, Bernet S, Huembelin M, Mueller M, Baechli C, Koch D, et al. Sex-Specific Differences in Outcomes Following Thyroidectomy: A Population-Based Cohort Study. Eur Thyroid J. 2021;10(6):476–85.  
30.  Vodopivec DM, Silva AM, Garcia‐Banigan DC, Christakis I, Stewart A, Schwarz K, et al. Gender differences in bone mineral density in patients with sporadic primary hyperparathyroidism. Endocrinol Diabetes Metab. 2018 Oct 4;1(4).  
31.  Mazeh H, Sippel RS, Chen H. The Role of Gender in Primary Hyperparathyroidism: Same Disease, Different Presentation. Ann Surg Oncol. 2012 Sep 26;19(9):2958–62.  
32.  Underbjerg L, Sikjaer T, Mosekilde L, Rejnmark L. Postsurgical Hypoparathyroidism—Risk of Fractures, Psychiatric Diseases, Cancer, Cataract, and Infections. Journal of Bone and Mineral Research. 2014 Nov 1;29(11):2504– 10.  
33.  Melton LJ. The epidemiology of primary hyperparathyroidism in North America. J Bone Miner Res. 2002 Nov;17 Suppl 2:N12-7.  
34.  Shah V, Bhadada S, Bhansali A, Behera A, Mittal B, Bhavin V. Influence of age and gender on presentation of symptomatic primary hyperparathyroidism. J Postgrad Med. 2012;58(2):107–11.  
35.  Miller BS, Dimick J, Wainess R, Burney RE. Age‐ and Sex‐Related Incidence of Surgically Treated Primary Hyperparathyroidism. World J Surg. 2008 May 31;32(5):795–9.  
36.  Davies L, Welch HG. Current Thyroid Cancer Trends in the United States. JAMA Otolaryngology–Head & Neck Surgery. 2014 Apr 1;140(4):317.  
37.  Knuever J, Tantcheva-Poor I. Generalized pustular psoriasis: A possible association with severe hypocalcaemia due to primary hypoparathyroidism. J Dermatol. 2017 Dec;44(12):1416–7.  
38.  Walls AW, Soames J V. Dental manifestations of autoimmune hypoparathyroidism. Oral Surg Oral Med Oral Pathol. 1993 Apr;75(4):452–4.  
39.  Jafari R, Kamali M, Rad MM. A new pattern of bilateral cataracts associated with hypocalcemia secondary to uncontrolled hypoparathyroidism. Oman J Ophthalmol. 2022;15(3):389–92.  
40.  Saini N, Mishra S, Banerjee S, Rajput R. Hypocalcemic cardiomyopathy: a rare presenting manifestation of hypoparathyroidism. BMJ Case Rep. 2019 Sep 12;12(9).  
41.  Herteux J, Geiger SJ, Starchl C, Windisch J, Lerchl T, Tmava-Berisha A, et al. Hospitalizations, emergency room visits and causes of death in 198 patients with permanent hypoparathyroidism: a retrospective Austrian study (20052022). Endocr Connect. 2023 May 1;12(5).  
42.  Shao Y, Cai WJ, Wang XL, Chen K, Du J, Zang L, et al. Clinical data analysis of 22 cases with hypoparathyroidism misdiagnosed as epilepsy. Neuro Endocrinol Lett. 2022 Jun 7;43(2):113–8.  
43.  Büttner M, Krogh D, Siggelkow H, Singer S. Impairments in quality of life and predictors of symptom burden in patients with hypoparathyroidism: results from a population-based survey. Endocrine. 2023 Nov;82(2):419–26.  
44.  Babu TA, Hashim Z, Neyaz Z, Mani VE, Jain N, Bhatia E, et al. Nonsurgical hypoparathyroidism is associated with skeletal muscle dysfunction and restrictive lung disease. Eur J Endocrinol. 2023 Aug 2;189(2):141–8.  
17  
45.  Sępek M, Marciniak D, Głód M, Kaliszewski K, Rudnicki J, Wojtczak B. Risk Factors for Calcium-Phosphate Disorders after Thyroid Surgery. Biomedicines. 2023 Aug 18;11(8).  
46.  Wang X, Wang SL, Cao Y, Li CQ, He W, Guo ZM. Postoperative hypoparathyroidism after thyroid operation and exploration of permanent hypoparathyroidism evaluation. Front Endocrinol (Lausanne). 2023;14:1182062.  
47.  Naushad A, Sattar S, Salik M, Wajid M, Khalid F, Hussain A, et al. Frequency and Risk Factors of Permanent Hypoparathyroidism After Total Thyroidectomy: An Experience at a Tertiary Care Hospital in Pakistan. Ear Nose Throat  
J. 2023 Apr 26;1455613231173455.  
48.  Brasil, Ministério da Saúde., Secretaria de Ciência TI e C da S, Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretrizes metodológicas : elaboração de diretrizes clínicas [Internet]. 2023 [cited 2023 Oct 8]. Available from:  
https://bvsms.saude.gov.br/bvs/publicacoes/diretrizes_metodologicas_elaboracao_metodologicas_1ed.pdf  
49.  Maeda SS, Fortes EM, Oliveira UM, Borba VCZ, Lazaretti-Castro M. Hypoparathyroidism and pseudohypoparathyroidism. Arquivos Brasileiros de Endocrinologia & Metabologia. 2006 Aug;50(4):664–73.  
50.  Turner J, Gittoes N, Selby P, __. SOCIETY FOR ENDOCRINOLOGY ENDOCRINE EMERGENCY GUIDANCE: Emergency management of acute hypocalcaemia in adult patients. Endocr Connect. 2016 Sep;5(5):G7–8. 51.  Mannstadt M, Mitchell D. Clinical Manifestations of Hypoparathyroidism. In: Bilezikian J, editor. The Parathyroids. 3<sup>a</sup> . London: Academic Press; 2015. p. 761–70.  
52.  Clarke BL. Hypoparathyroidism: update of guidelines from the 2022 International Task Force. Arch Endocrinol Metab. 2022 Nov 16;66(5):604–10.  
53.  Khan AA, Bilezikian JP, Brandi ML, Clarke BL, Gittoes NJ, Pasieka JL, et al. Evaluation and Management of Hypoparathyroidism Summary Statement and Guidelines from the Second International Workshop. J Bone Miner Res. 2022 Dec;37(12):2568–85.  
54.  Yao L, Hui X, Li M, Li J, Ahmed MM, Lin C, et al. Complications, Symptoms, Presurgical Predictors in Patients With Chronic Hypoparathyroidism: A Systematic Review. J Bone Miner Res. 2022 Dec;37(12):2642–53.  
55.  Bello M, Garla V. Polyglandular Autoimmune Syndrome Type I. [Updated 2023 Mar 20]. Treasure Island. 2023.  
56.  Cianferotti L, Brandi ML. The Molecular Genetics of Hypoparathyroidism. In: Bilezikian J, editor. The Parathyroids. 3<sup>a</sup> . London: Academic Press; 2015. p. 719–36.  
57.  Shoback D. Hypoparathyroidism in the Differential Diagnosis of Hypocalcemia. In: Bilezikian J, editor. The Parathyroids. 3rd ed. London: Academic Press; 2015. p. 687–96.  
58.  Shoback DM, Bilezikian JP, Costa AG, Dempster D, Dralle H, Khan AA, et al. Presentation of Hypoparathyroidism: Etiologies and Clinical Features. J Clin Endocrinol Metab. 2016 Jun;101(6):2300–12.  
59.  Bilezikian JP. Hypoparathyroidism. J Clin Endocrinol Metab. 2020 Jun 1;105(6):1722–36.  
60.  Mantovani G, Bastepe M, Monk D, de Sanctis L, Thiele S, Usardi A, et al. Diagnosis and management of pseudohypoparathyroidism and related disorders: first international Consensus Statement. Nat Rev Endocrinol. 2018 Aug;14(8):476–500.  
61.  Mantovani G, Bastepe M, Monk D, de Sanctis L, Thiele S, Ahmed SF, et al. Recommendations for Diagnosis and Treatment of Pseudohypoparathyroidism and Related Disorders: An Updated Practical Tool for Physicians and Patients. Horm Res Paediatr. 2020;93(3):182–96.  
62.  Linglart A, Levine MA, Jüppner H. Pseudohypoparathyroidism. Endocrinol Metab Clin North Am. 2018 Dec;47(4):865–88.  
63.  Casey C, Hopkins D. The role of preoperative vitamin D and calcium in preventing post-thyroidectomy hypocalcaemia: a systematic review. Eur Arch Otorhinolaryngol. 2023 Apr;280(4):1555–63.  
18  
64.  Fanget F, Demarchi MS, Maillard L, El Boukili I, Gerard M, Decaussin M, et al. Hypoparathyroidism: Consequences, economic impact, and perspectives. A case series and systematic review. Ann Endocrinol (Paris). 2021 Dec;82(6):572–81.  
65.  Ponce de León‐Ballesteros G, Bonilla‐Ramírez C, Hernández‐Calderón FJ, Pantoja‐Millán JP, Sierra‐Salazar M, Velázquez‐Fernández D, et al. Mid‐Term and Long‐Term Impact of Permanent Hypoparathyroidism After Total Thyroidectomy. World J Surg. 2020 Aug 22;44(8):2692–8.  
66.  Cusano NE, Rubin MR, McMahon DJ, Irani D, Tulley A, Sliney J, et al. The Effect of PTH(1–84) on Quality of Life in Hypoparathyroidism. J Clin Endocrinol Metab. 2013 Jun 1;98(6):2356–61.  
67.  Arlt W, Fremerey C, Callies F, Reincke M, Schneider P, Timmermann W, et al. Well-being, mood and calcium homeostasis in patients with hypoparathyroidism receiving standard treatment with calcium and vitamin D. Eur J Endocrinol. 2002 Feb 1;215–22.  
68.  Bilezikian JP, Brandi ML, Cusano NE, Mannstadt M, Rejnmark L, Rizzoli R, et al. Management of Hypoparathyroidism: Present and Future. J Clin Endocrinol Metab. 2016 Jun;101(6):2313–24.  
69.  Anaforoglu I, Sancak S, Akbas EM, Oruk GG, Canat M, Tezcan KA, et al. Effects of Treatment Adherence on Quality of Life in Hypoparathyroid Patients. Experimental and Clinical Endocrinology & Diabetes. 2021 Dec 10;129(12):918–25.  
70.  Cho NL, Moalem J, Chen L, Lubitz CC, Moore FD, Ruan DT. Surgeons and Patients Disagree on the Potential Consequences of Hypoparathyroidism. Endocrine Practice. 2014 May;20(5):427–46.  
71.  Siggelkow H, Clarke BL, Germak J, Marelli C, Chen K, Dahl‐Hansen H, et al. Burden of illness in not adequately controlled chronic hypoparathyroidism: Findings from a 13‐country patient and caregiver survey. Clin Endocrinol (Oxf). 2020 Feb 11;92(2):159–68.  
72.  Hadker N, Egan J, Sanders J, Lagast H, Clarke BL. Understanding the Burden of Illness Associated with Hypoparathyroidism Reported Among Patients in the Paradox Study. Endocrine Practice. 2014 Jul;20(7):671–9.  
73.  Organização Mundial da Saúde. ADHERENCIA A LOS TRATAMIENTOS A LARGO PLAZO Pruebas para la acción. 1<sup>a</sup> . Vol. 1. Washington; 2004.  
74.  Bergenfelz A, Jansson S, Kristoffersson A, Mårtensson H, Reihnér E, Wallin G, et al. Complications to thyroid surgery: results as reported in a database from a multicenter audit comprising 3,660 patients. Langenbecks Arch Surg. 2008 Sep 17;393(5):667–73.  
75.  Sitges-Serra A, Lorente-Poch L, Sancho J. Parathyroid autotransplantation in thyroid surgery. Langenbecks Arch Surg. 2018 May 10;403(3):309–15.  
76.  Koimtzis G, Stefanopoulos L, Geropoulos G, Papavramidis T. The outcomes of parathyroid gland autotransplantation during thyroid surgery: a systematic review, meta-analysis and trial sequential analysis. Endocrine. 2024 Aug 24;  
77.  Santa Ritta Barreira CE, Kowalski LP, Dias FL, Farias TPDE, Santos IC, Vartanian JG, et al. Guideline From the Brazilian Society of Surgical Oncology and Brazilian College of Surgeons in Preventing and Managing Acute Hypoparathyroidism After Thyroid Surgery. J Surg Oncol. 2024 Sep 24;130(4):705–13.  
78.  Vervloet MG, van Ballegooijen AJ. Prevention and treatment of hyperphosphatemia in chronic kidney disease. Kidney Int. 2018 May;93(5):1060–72.  
79.  Fulgoni K, Fulgoni VL. Trends in Total, Added, and Natural Phosphorus Intake in Adult Americans, NHANES 1988-1994 to NHANES 2015-2016. Nutrients. 2021 Jun 29;13(7).  
80.  Carvalho AB, Barreto FC. Update of Brazilian Guidelines for Treatment and Assessment of Chronic Kidney Disease - Mineral and Bone Disorders. Jornal brasileiro de nefrologia. 2021;43(4 Suppl 1):613–4.  
19  
81.  Carvalho AB, Nerbass FB, Cuppari L. Control of hyperphosphatemia and maintenance of calcemia in CKD. Brazilian Journal of Nephrology. 2021;43(4 suppl 1):632–8.  
82.  Kidney Disease: Improving Global Outcomes (KDIGO) CKD-MBD Update Work Group. KDIGO 2017 Clinical Practice Guideline Update for the Diagnosis, Evaluation, Prevention, and Treatment of Chronic Kidney Disease–Mineral and Bone Disorder (CKD-MBD). Kidney Int Suppl (2011). 2017 Jul;7(1):1–59.  
83.  Pearle MS, Goldfarb DS, Assimos DG, Curhan G, Denu-Ciocca CJ, Matlaga BR, et al. Medical management of kidney stones: AUA guideline. J Urol. 2014 Aug;192(2):316–24.  
84.  Betz M. Whole Diet Approach to Calcium Oxalate Kidney Stone Prevention. J Ren Nutr. 2022 Jan;32(1):e11–7. 85.  Maeda SS, Moreira CA, Borba VZC, Bandeira F, Farias MLF de, Borges JLC, et al. Diagnosis and treatment of hypoparathyroidism: a position statement from the Brazilian Society of Endocrinology and Metabolism. Arch Endocrinol Metab. 2018;62(1):106–24.  
86.  Sakane EN, Vieira MCC, Vieira GMM, Maeda SS. Treatment options in hypoparathyroidism. Arch Endocrinol Metab. 2022 Nov 11;66(5):651–7.  
87.  Gafni RI, Collins MT. Hypoparathyroidism. New England Journal of Medicine. 2019 May 2;380(18):1738–47.  
88.  Bilezikian JP, Brandi ML, Cusano NE, Mannstadt M, Rejnmark L, Rizzoli R, et al. Management of Hypoparathyroidism: Present and Future. J Clin Endocrinol Metab. 2016 Jun 1;101(6):2313–24.  
89.  BRASIL. Ministério da Saúde. Relatório de Recomendação: Exclusão dos medicamentos hidróxido de alumínio e alfacalcidol para o tratamento de Distúrbio Mineral Ósseo na Doença Renal Crônica e Hipoparatireoidismo . 2024.  
90.  Pachaly MA, Baena CP, Carvalho M de. Therapy of nephrolithiasis: where is the evidence from clinical trials? Jornal Brasileiro de Nefrologia. 2016;38(1).  
91.  Brandi ML, Bilezikian JP, Shoback D, Bouillon R, Clarke BL, Thakker R V, et al. Management of Hypoparathyroidism: Summary Statement and Guidelines. J Clin Endocrinol Metab. 2016 Jun;101(6):2273–83.  
92.  Sakane EN, Vieira MCC, Vieira GMM, Maeda SS. Treatment options in hypoparathyroidism. Arch Endocrinol Metab. 2022 Nov 16;66(5):651–7.  
93.  Bollerslev J, Schalin-Jäntti C, Rejnmark L, Siggelkow H, Morreau H, Thakker R, et al. Management of Endocrine Disease: Unmet therapeutic, educational and scientific needs in parathyroid disorders. Eur J Endocrinol. 2019 Sep 1;181(3):P1–19.  
94.  Tong GM, Rude RK. Magnesium deficiency in critical illness. J Intensive Care Med. 2005;20(1):3–17.  
95.  Salinas M, López-Garrigós M, Flores E, Leiva-Salinas C. Improving diagnosis and treatment of hypomagnesemia. Clinical Chemistry and Laboratory Medicine (CCLM). 2024 Jan 26;62(2):234–48.  
96.  Martínez Faedo C, Bellido Castañeda V, Riestra Fernández M. [Severe hypomagnesemia refractory to oral supplementation associated to omeprazole treatment]. Endocrinol Nutr. 2012;59(7):463–5.  
97.  Bollerslev J, Rejnmark L, Zahn A, Heck A, Appelman-Dijkstra NM, Cardoso L, et al. European Expert Consensus on Practical Management of Specific Aspects of Parathyroid Disorders in Adults and in Pregnancy: Recommendations of the ESE Educational Program of Parathyroid Disorders. Eur J Endocrinol. 2022 Feb 1;186(2):R33–63.  
98.  Kovacs CS. Maternal Mineral and Bone Metabolism During Pregnancy, Lactation, and Post-Weaning Recovery. Physiol Rev. 2016 Apr;96(2):449–547.  
99.  Khan AA, Clarke B, Rejnmark L, Brandi ML. MANAGEMENT OF ENDOCRINE DISEASE: Hypoparathyroidism in pregnancy: review and evidence-based recommendations for management. Eur J Endocrinol. 2019 Feb 1;180(2):R37–44.  
100.  Ali DS, Dandurand K, Khan AA. Hypoparathyroidism in Pregnancy and Lactation: Current Approach to Diagnosis and Management. J Clin Med. 2021 Mar 29;10(7).  
20  
101.  Pilz S, Zittermann A, Obeid R, Hahn A, Pludowski P, Trummer C, et al. The Role of Vitamin D in Fertility and during Pregnancy and Lactation: A Review of Clinical Data. Int J Environ Res Public Health. 2018 Oct 12;15(10). 102.  Shoback DM, Bilezikian JP, Costa AG, Dempster D, Dralle H, Khan AA, et al. Presentation of Hypoparathyroidism: Etiologies and Clinical Features. J Clin Endocrinol Metab. 2016 Jun;101(6):2300–12.  
103.  Appelman-Dijkstra NM, Pilz S. Approach to the Patient: Management of Parathyroid Diseases Across Pregnancy. J Clin Endocrinol Metab. 2023 May 17;108(6):1505–13.  
104.  Gallo S, McDermid JM, Al-Nimr RI, Hakeem R, Moreschi JM, Pari-Keener M, et al. Vitamin D Supplementation during Pregnancy: An Evidence Analysis Center Systematic Review and Meta-Analysis. J Acad Nutr Diet. 2020 May;120(5):898-924.e4.  
105.  Hartogsohn EAR, Khan AA, Kjærsulf LU, Sikjaer T, Hussain S, Rejnmark L. Changes in treatment needs of hypoparathyroidism during pregnancy and lactation: A case series. Clin Endocrinol (Oxf). 2020 Sep 19;93(3):261–8. 106.  Bollerslev J, Rejnmark L, Marcocci C, Shoback DM, Sitges-Serra A, van Biesen W, et al. European Society of Endocrinology Clinical Guideline: Treatment of chronic hypoparathyroidism in adults. Eur J Endocrinol. 2015 Aug;173(2):G1-20.  
107.  Brasil. Protocolo Clínico e Diretrizes Terapêuticas do Hipoparatireoidismo [Internet]. Brasilia. 2016 [cited 2023 Oct 2]. Available from: https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticaspcdt/arquivos/2016/hipoparatireoidismo-pcdt.pdf  
108.  Secretaria de Estado da Saúde do Rio Grande do Sul. Documentos e exames necessários para solicitação administrativa de medicamentos do componente especializado da assistência farmacêutica − doenças que possuem Protocolo Clínico e Diretrizes Terapêuticas (PCDT) publicado pelo Ministério da Saúde [Internet]. 2015 [cited 2023 Oct 2]. Available from: https://saude.rs.gov.br/upload/arquivos/201701/18143019-1434565482-documentos-e-examespara-solicitacao-administrativa-de-medicamentos-do-ceaf-2015-versao-junho-de-2015-word-97.pdf  
21

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE CALCITRIOL, CARBONATO DE CÁLCIO + COLECALCIFEROL E HIDROCLOROTIAZIDA** -->
Eu, ___________________________________________________________________________________ (nome do(a)  
paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso dos medicamentos **calcitriol, carbonato de cálcio + colecalciferol e hidroclorotiazida** , indicados para o tratamento do **hipoparatireoidismo** .  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a) _______________  
______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Melhorar os sintomas de cálcio baixo no sangue;  
- Evitar complicações agudas e crônicas de cálcio baixo no sangue.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Não se sabe ao certo os riscos do uso destes medicamentos na gravidez; portanto, caso engravide, não interrompa o  
- tratamento e avise imediatamente o médico;  
- Em relação à amamentação, a segurança para o uso dos medicamentos deve ser avaliada pelo médico assistente,  
- considerando riscos e benefícios, visto ser excretado pelo leite materno;  
- Os principais eventos adversos de **calcitriol e carbonato de cálcio** são aumento da quantidade de cálcio no sangue, caracterizada por dor óssea, constipação, diarreia, secura da boca, dor de cabeça, sede intensa, aumento da frequência ou da quantidade de urina, perda do apetite, gosto metálico, dor muscular, náusea, vômitos, cansaço e fraqueza. Efeitos crônicos podem incluir conjuntivite, diminuição da libido, irritabilidade, coceira, infecções do trato urinário, febre alta, aumento da pressão arterial, batimentos cardíacos irregulares, aumento da sensibilidade dos olhos à luz ou irritação, aumento dos níveis de fósforo e colesterol no sangue, perda de peso, pancreatite e psicose, que é o sintoma mais raro. O risco da ocorrência de efeitos adversos aumenta com a superdosagem;  
- Os principais eventos adversos de **colecalciferol** são secura da boca, cefaleia, polidipsia, poliúria, perda de apetite,  
- náuseas, vômitos, fadiga, sensação de fraqueza, dor muscular, prurido e perda de peso;  
- **Hidroclorotiazida** é contraindicada em caso de gota; e pode ser contraindicada em indivíduos com síndrome metabólica,  
- intolerância à glicose, gravidez, hipercalcemia e hipocalemia. Os principais eventos adversos são fraqueza, cãibras, hipovolemia, disfunção erétil, hiponatremia, hipocalemia, hipercalcemia e aumento do ácido úrico.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido, inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (   ) Sim    (   ) Não  
Meu tratamento constará do seguinte medicamento:  
- (   ) Calcitriol  
- (   ) Carbonato de cálcio + colecalciferol  
- (   ) Hidroclorotiazida  
22  
<!-- Start of picture text -->
Local:                                                                                  Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>Assinatura do paciente ou do responsável legal<br>Médico Responsável:   CRM:   UF:<br>_________________________<br>Assinatura e carimbo do médico<br>                                                Data:____________________<br><!-- End of picture text -->  
**Nota** : Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
23  
**APÊNDICE 1 – METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA**

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Hipoparatireoidismo, contendo a descrição da metodologia de busca de evidências científicas e as recomendações, tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (DGITS/SCTIE/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo.  
A revisão do PCDT do Hipoparatireoidismo foi iniciada com as reuniões de pré-escopo, escopo e priorização de perguntas de pesquisa, realizadas entre julho e agosto de 2023, cujo objetivo foi discutir a atualização do referido PCDT. As reuniões virtuais tiveram a participação de até dezoitos participantes, incluindo especialistas, pesquisadores e apoio administrativo do Grupo Elaborador e representantes de sociedade médica e do Ministério da Saúde.  
A dinâmica da reunião foi conduzida com base no PCDT publicado por meio da Portaria SAS/MS nº 450, de 29/04/2016, e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Foi elencada uma nova questão de pesquisa para a revisão deste PCDT para a qual foi elaborado um relatório de recomendação pelo Grupo elaborador.  
A relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **2. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT do Hipoparatireoidismo foi apresentada na 127ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 15 de julho de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em Saúde (SCTIE); Secretaria de Atenção Especializada à Saúde (SAES); Secretaria de Saúde Indígena (SESAI) e Secretaria de Atenção Primária à Saúde (SAPS). A proposta foi aprovada para avaliação da Conitec.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **3. Consulta Pública** -->
A Consulta Pública nº 79/2025, do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Hipoparatireoidismo, foi realizada entre os dias 29 de setembro de 2025 e 20 de outubro de 2025. Foram recebidas cinco contribuições, que podem ser  
24  
verificadas na página da CONITEC em: https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/contribuicao-dacp-79-2025-pcdt-do-hipoparatireoidismo

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ou PIRO ( **Figura A** ).  
**Figura A** - Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
FP «Populacdoou condi¢ao clinica<br>*Intervencdo, no caso de estudos experimentais<br>*Fator de exposi¢do, em caso de estudos observacionais<br>*Teste indice, nos casos de estudos de acurdcia diagndéstica<br>«Controle, de acordo com tratamento/niveis de exposi¢do do fator/exames<br>disponiveis no SUS<br>«Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
Durante a reunião de escopo deste PCDT uma questão de pesquisa foi definida:  
**QUESTÃO 1: O aumento da dose de vitamina D, adicional à combinação de cálcio+vitamina D, é seguro, eficaz e custo-efetivo para o tratamento de pacientes com hipoparatireoidismo comparado ao uso da combinação de cálcio+vitamina D nas doses preconizadas no PCDT vigente?**  
Devido à ausência de evidência comparativa demonstrando benefício incremental do aumento da dose de vitamina D, foi definido o não seguimento da demanda para avaliação da Conitec. Para fins de informação, um resumo da revisão sistemática conduzida, é apresentado a seguir.  
A estrutura PICO para esta pergunta foi:  
|População|Indivíduos com hipoparatireoidismo|
|---|---|
||Vitamina D isolada (3.000 UI; 4.000 UI; 5.000 UI; 7.000 UI; 10.000 UI; 14.000 UI, 30.000 UI,|
|Intervenção|50.000 UI; 60.000 UI) + cálcio combinado à vitamina D (500 mg + 200 UI; 500 mg + 400 UI; 600<br>mg + 400 UI)|
|Comparador|Cálcio e vitamina D combinado (500 mg + 200 UI; 500 mg + 400 UI; 600 mg + 400 UI)|
||Primários (críticos):<br>Níveis séricos de vitamina D<br>Níveis séricos de cálcio|
|Desfechos|Níveis urinários de cálcio|
||Razão cálcio/creatinina na urina de 24 horas<br>Função renal|
||Secundários (importantes):|  
25  
||Níveis séricos de fosfato<br>Níveis séricos de magnésio<br>Eventos adversos (críticos):<br>Hospitalização/visitas em emergência por hipocalcemia<br>Hospitalização/visitas em emergência por hipercalcemia<br>Hipercalciúria<br>Hiperfosfatemia<br>Hipercalcemia<br>Hipercalcemia grave|
|---|---|
|Tipos de estudos|Revisões sistemáticas (com ou sem meta-análise), ensaios clínicos randomizados e estudos<br>observacionais comparativos.|

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1. Métodos e resultados da busca** -->
Para responder essa pergunta, foi utilizada uma síntese de evidências.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.1. Critérios de elegibilidade** -->
**População:** A população priorizada na revisão sistemática é composta por indivíduos com hipoparatireoidismo tratados com os medicamentos disponíveis no SUS.  
**Intervenção:** A intervenção avaliada nesta revisão sistemática é a vitamina D em doses elevadas (3.000 UI; 4.000 UI; 5.000 UI; 7.000 UI; 10.000 UI; 14.000 UI, 30.000 UI, 50.000 UI; 60.000 UI) adicional ao cálcio isolado ou associado à vitamina D em baixa dose, priorizada para avaliação para a população supracitada em reunião de escopo realizada entre grupo gestor, grupo elaborador e médicos especialistas.  
**Comparadores:** O comparador avaliado nesta revisão sistemática é o cálcio isolado ou associado à vitamina D (500 mg + 200 UI; 500 mg + 400 UI; 600 mg + 400 UI).  
**Desfechos:** Em reunião de priorização de perguntas realizada entre grupo gestor, elaborador e especialistas foram  
priorizados os desfechos relativos à eficácia clínica, eficácia humanística e segurança especificados a seguir:

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: <u>Primários (críticos):</u> -->
<u>Níveis séricos de vitamina D: Os níveis de 25-hidroxi-vitamina D (25[OH]D) foram considerados normais quando se</u> mantiveram até 500 ng/mL.  
<u>Níveis séricos de cálcio: O cálcio sérico total foi considerado dentro da faixa normal estabelecida, que varia entre 8,5 e</u> 10,2 mg/dL.  
<u>Níveis urinários de cálcio: O cálcio foi mensurado na urina de 24 horas.</u>  
<u>Razão cálcio/creatinina na urina de 24 horas: A razão cálcio/creatinina na urina de 24 horas superior a 0,2 mg/mg foi</u> definida como hipercalciúria.  
<u>Função renal: A função renal foi avaliada com base na creatinina sérica, cuja faixa normal é de 0,4 a 1,2 mg/dL.</u>

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: <u>Secundários (importantes):</u> -->
<u>Níveis séricos de fósforo: O fósforo inorgânico foi considerado dentro da faixa normal estabelecida, que varia entre 2,5 e</u> 4,5 mg/dL. Valores de fósforo sérico superiores a 4,5 mg/mL foram definidos como hiperfosfatemia.  
<u>Níveis séricos de magnésio: Não foram encontrados estudos que relatassem resultados para esse desfecho; portanto, não</u> foi estabelecida uma definição.  
26  
<u>Eventos adversos (críticos): os desfechos que foram considerados como eventos adversos, foram relatados nos estudos</u> como resultados desfavoráveis ao uso da terapia e as definições adotadas foram aquelas fornecidas pelos estudos.  
<u>Hospitalização/visitas em emergência por hipocalcemia:</u> Proporção de pacientes que necessitaram de tratamento de emergência por hipocalcemia.  
<u>Hospitalização/visitas em emergência por hipercalcemia: Proporção</u> de pacientes que necessitaram de tratamento de emergência por hipercalcemia.  
<u>Hipercalciúria: Proporção de pacientes que apresentaram aumento na excreção de cálcio na urina.</u>  
<u>Hiperfosfatemia: Proporção de pacientes que apresentaram aumento de fosfato no sangue.</u>  
<u>Hipercalcemia: Níveis de cálcio sérico total superiores a 10,6 mg/dL foram considerados critérios como hipercalcemia. Hipercalcemia grave: Níveis de cálcio sérico total superiores a 11,0 mg/dL foram considerados critérios como</u> hipercalcemia grave.  
**Tipos de estudo:** Foram considerados para inclusão revisões sistemáticas atualizadas, sendo definidas como aquelas que continham todos os ensaios clínicos randomizados (ECR) e estudos observacionais comparativos que contemplavam a população. Não havendo revisões sistemáticas atualizadas, os ECR e/ou estudos observacionais comparativos foram identificados e sintetizados. Não foi empregada restrição para data de publicação ou idioma.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **Termos de busca e bases de dados** -->
Para a condução dessa revisão sistemática, elaborou-se uma estratégia de busca (baseada nos critérios de elegibilidade mencionados anteriormente) através do uso de descritores, palavras-chave e termos MeSH que permitissem a identificação dos estudos de interesse em diferentes bases de dados, os quais foram combinados com os operadores lógicos booleanos AND e OR. O **Quadro A** detalha as estratégias de busca utilizadas em cada plataforma.  
Não foram utilizados limites temporais, bem como não foram inseridos critérios para comparadores, desfechos e delineamento de estudos na estratégia original, para que esta fosse mais sensível e menos específica. As bases de dados utilizadas seguiram a hierarquia de prioridade sugerida pela Diretriz para Elaboração de Pareceres Técnico-Científicos do Ministério da Saúde<sup>1</sup> . A referida estratégia foi realizada em 02/09/2024 e aplicada em quatro bases de dados eletrônicas distintas: _The Cochrane Library_ , _Medical Literature Analysis and Retrieval System Online_ (MEDLINE via Pubmed), Literatura Latino-Americana e do Caribe em Ciências da Saúde (LILACS) e _Excerpta Medica dataBASE_ (EMBASE).  
**Quadro A** - Estratégias de buscas de evidências em bases de dados eletrônicas.  
|**Base de**<br>**dados**|**Estratégia**|**Resultados**<br>**encontrados**|
|---|---|---|
|PubMed|(((("Hypoparathyroidism"[MeSH Terms]) OR|1.847|
||((Hypoparathyroidism[Title/Abstract])) OR ((Idiopathic||
||Hypoparathyroidism[Title/Abstract]))) OR ((Hypoparathyroidism,<br>Idiopathic[Title/Abstract])))) AND (((((((((((("Vitamin D"[MeSH Terms]) OR<br>("Cholecalciferol"[MeSH Terms])) OR ("Calcitriol"[MeSH Terms])) OR ((Vitamin<br>D[Title/Abstract]))) OR ((Cholecalciferol[Title/Abstract]))) OR<br>((Calcitriol[Title/Abstract]))) OR ((Calciol[Title/Abstract]))) OR<br>((Cholecalciferol*[Title/Abstract]))) OR ((Dihydroxyvitamin D3[Title/Abstract])))<br>OR ((Dihydroxycholecalciferol[Title/Abstract]))) OR ((Dihydroxy vitamin||
||D[Title/Abstract]))) OR ((High dose vitamin D[Title/Abstract])))||  
27  
|**Base de**<br>**dados**|**Estratégia**|**Resultados**<br>**encontrados**|
|---|---|---|
|EMBASE*|'hypoparathyroidism'/syn AND ('vitamin d'/syn OR 'colecalciferol'/syn OR<br>'calcitriol'/syn OR 'dihydroxy vitamin d3'/syn) AND [embase]/lim NOT<br>([embase]/lim AND [medline]/lim)|2.062|
|Cochrane|'#1<br>MeSH descriptor: [Hypoparathyroidism] explode all trees<br>167<br>#2<br>(Hypoparathyroidism, Idiopathic):ti,ab,kw OR (Idiopathic<br>Hypoparathyroidism):ti,ab,kw OR (Hypoparathyroidism):ti,ab,kw<br>443<br>#3<br>#1 OR #2<br>460<br>#4<br>MeSH descriptor: [Vitamin D] explode all trees<br>7949<br>#5<br>MeSH descriptor: [Cholecalciferol] explode all trees<br>4319<br>#6<br>MeSH descriptor: [Calcitriol] explode all trees<br>1160<br>#7<br>(Vitamin D):ti,ab,kw OR (Cholecalciferol):ti,ab,kw OR<br>(Calcitriol):ti,ab,kw OR (Calciol):ti,ab,kw OR (Cholecalciferol*):ti,ab,kw OR<br>(Dihydroxyvitamin D3):ti,ab,kw OR (Dihydroxycholecalciferol):ti,ab,kw OR<br>(Dihydroxy vitamin D):ti,ab,kw OR (High dose vitamin D):ti,ab,kw<br>19704<br>#8<br>#4 OR #5 OR #6 OR #7 19929<br>#9<br>#3 AND #8<br>171|171|
|LILACS<br>Total|(mh:(Hipoparatireoidismo)) OR (mh:(C19.642.482$)) OR (Hipoparatireoidismo)<br>OR (Hypoparathyroidism) OR (Hipoparatiroidismo) OR (Hypoparathyroïdie) AND<br>(mh:("Vitamina D")) OR (mh:(D04.210.500.812.768$)) OR (Vitamina D) OR<br>(Vitamin D) OR (Vitamina D) OR (Vitamine D) OR (mh:(Colecalciferol)) OR<br>(mh:(D04.210.500.247.222.159$)) OR (mh:(D04.210.500.247.808.146$)) OR<br>(mh:(D04.210.500.812.768.196$)) OR (mh:(D10.570.938.146$)) OR (Vitamina D<br>3) OR (Cholecalciferol) OR (Colecalciferol) OR (Cholécalciférol) OR<br>(mh:(Calcitriol)) OR (mh:(D04.210.500.247.222.159.478.387.300$)) OR<br>(mh:(D04.210.500.247.808.146.478.387.300$)) OR<br>(mh:(D04.210.500.812.768.196.478.387.300$)) OR<br>(mh:(D10.570.938.146.478.387.300$)) OR (Calcitriol) OR (1 alfa,25-Di-<br>Hidroxicolecalciferol) OR (1 alfa,25-Di-Hidroxivitamina D 3) OR (1, 25-<br>(OH)2D3) OR (1,25-Di-Hidroxicolecalciferol) OR (1,25-Di-Hidroxivitamina D 3)|142<br>4.222|  
Fonte: Elaboração própria. Legenda: *O objetivo deste filtro foi eliminar os resultados duplicados do Medline, uma vez que a pesquisa na Medline foi realizada por meio da PubMed.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **Seleção dos estudos** -->
O processo de seleção dos estudos identificados nas bases de dados seguiu as etapas pré-estabelecidas pelas recomendações do Ministério da Saúde<sup>1</sup> . Após as buscas nas bases de dados, realizou-se a exclusão dos estudos em duplicatas por meio do gerenciador de referências Mendeley®. Na sequência, as publicações que permaneceram foram exportadas para a plataforma Rayyan QCRI (Qatar Foundation, Doha, Qatar), aplicativo web desenvolvido para realizar revisão sistemática (identificação, triagem, elegibilidade e inclusão)<sup>2</sup> . Assim, foi realizada a triagem (fase 1) por meio da leitura dos títulos e resumos dos estudos identificados. Os estudos que não obedeceram aos critérios de elegibilidade foram excluídos, enquanto aqueles  
28  
incluídos passaram para elegibilidade (fase 2), consistindo na leitura do artigo na íntegra. Nas duas fases, a revisão foi realizada por um único avaliador, e um segundo avaliador interveio para resolver quaisquer dúvidas, tanto na triagem quanto na fase de elegibilidade. Os estudos incluídos ao final do processo de seleção seguiram para a etapa de extração de dados.  
Buscas manuais nas listas de referências dos estudos incluídos também foram realizadas para capturar potenciais estudos não encontrados pelas bases de dados. Além disso, todas as publicações citadas foram verificadas e incluídas na revisão sistemática, se cumpriram os critérios de elegibilidade.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **Extração dos dados** -->
Os dados dos estudos incluídos foram extraídos por meio de planilha padronizadas do _software_ Microsoft Office Excel® por um único avaliador. Foram extraídos os seguintes dados:  
- I. Identificação do estudo: autor, ano, país e desenho do estudo;  
- II. Características dos estudos, intervenções e participantes: características gerais da população; número de participantes;  
idade média; sexo; alternativas comparadas; co-intervenções; duração do tratamento e critérios de inclusão.  
- III. Desfechos e resultados: resultados médios (média final ou média da variação), os desvios-padrão (DP), valor de p e  
- os tamanhos das amostras dos estudos.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.3. Análise do risco de viés e qualidade metodológica** -->
Para a avaliação do risco de viés de ECR empregou-se a ferramenta _Revised Cochrane risk of bias tool for randomized trials_ (RoB 2.0)<sup>3,4</sup> . Já para os estudos e intervenção não randomizados, foi utilizada a ferramenta _Risk of bias in non-randomized studies - of interventions_ (ROBINS-I)<sup>5</sup> . A avaliação foi feita por estudo e por desfecho. Paralelamente, as revisões sistemáticas tiveram a qualidade metodológica avaliada pela ferramenta AMSTAR-2 ( _A MeaSurement Tool to Assess systematic Reviews version_ 2)<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.4. Síntese e análise de dados** -->
<u>Síntese e representação individual dos resultados: As características do estudo, características dos participantes, resultados</u> individuais e avaliação da qualidade dos estudos incluídos foram apresentadas de forma narrativa e a estatística descritiva (média e desvio padrão [DP] ou mediana e intervalo interquartil [IIQ]), incluindo tabelas para o auxílio na apresentação dos resultados. Os resultados narrativos foram agrupados por desfecho, destacando as alternativas comparadas. Para avaliação da heterogeneidade, métodos informais foram utilizados considerando inspeção visual de tabelas de características e resultados e potenciais modificadores de efeito (características dos participantes).  
<u>Síntese e representação das revisões sistemáticas: foram incluídas revisões sistemáticas que cumpriram os critérios de</u> elegibilidade relativos à população, intervenção, comparador e desfechos.  
<u>Meta-análises diretas: o</u> _software_ R Studio versão 2024.09.0 foi utilizado para a condução de meta-análises diretas, por meio do pacote meta. Os desfechos contínuos empregados para a condução desta análise foram os níveis séricos de fosfato e à razão cálcio/creatinina na urina de 24 horas, cuja medida de efeito empregada foi diferença de médias (DM) e valores de p<0,05 foram considerados significativos. Para os desfechos dicotômicos, como a proporção de pacientes com hiperfosfatemia e hipercalciúria, foi empregada a medida de efeito risco relativo (RR) considerando os mesmos valores de p. Ademais, considerando a existência de heterogeneidade entre os grupos vitamina D em baixas doses (alfacalcidol e calcitriol), foi empregado o modelo de efeitos randômicos. O método estatístico utilizado foi o inverso da variância.  
29

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.5. Avaliação da certeza da evidência** -->
A certeza da evidência foi avaliada a partir do _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE) _Working Group_<sup>7</sup> _._ Desfechos relevantes para paciente e/ou gestores foram graduados em alta, moderada, baixa e muito baixa confiança, considerando os critérios de rebaixamento da qualidade (limitações metodológicas, inconsistência, evidência indireta, imprecisão de estimativa de efeito e risco de viés de publicação) e aumento da qualidade (grande magnitude do efeito, controle apropriado de potenciais variáveis de confusão que produzem subestimação do efeito e avaliação ou presença de gradiente dose-resposta).

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.6. Resultados** -->
Foram recuperadas 4.222 publicações nas bases de dados consultadas, restando 3.924 após remoção de duplicatas identificadas eletronicamente e manualmente. Durante a seleção, 3.899 registros foram considerados irrelevantes na triagem, enquanto 19 foram excluídos na etapa de leitura na íntegra e quatro registros não foram localizados. Um artigo foi selecionado no processo de busca manual ( **Figura B** ). Estudos excluídos na elegibilidade, com os seus respectivos motivos de exclusão estão apresentados no **Quadro B** . Portanto, três registros foram incluídos, referentes a três estudos, sendo eles um ensaio clínico randomizado (ECR)<sup>8</sup> , um estudo observacional<sup>9</sup> e uma revisão sistemática<sup>10</sup> .  
30  
**Figura B** . Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Identificacao de estudos via bases de dados e registros Identificagdo de estudos por outros métodos<br>iy | Pest klenaneaias de Registros removidos antes<br>g Ents oso da triagem Registros identificados de<br>€ PubMed (n = 1847) Registros duplicados Websites (n - 01)<br>= Cochrane (i= 173) termewiees oe omens Pesquisa de citagdes (n = 50)<br>z Lilacs (n = 142) neeey)<br>Registros triados Registros excluidos<br>A (n = 3924) (n = 3899)<br>g2<br>=<br>ie Registros procurados para Registros nao recuperados Registrosrecuperacao procurados(n = 01) para recuperadosRegistros nao(n = 0)<br>z recuperacao (n = 25) (n = 04)<br>5<br>2 Registros avaliados para Registros excluidos<br>i Registros avaliados para Registros excluidos (n-19) elegibilidade (n = 01) (n= 0)<br>elegibilidade (n - 21) Populacao (n-02)<br>Tipo de estudo (n-12)<br>Tipo de publicacao (n-05)<br>° Estudos incluidos no PTC -<br>3 03 registros referentesa1<br>a] ECR, 1 estudo observacional<br>£ 1 revisao sistematica<br><!-- End of picture text -->  
**Fonte:** Traduzido e preenchido de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. _The PRISMA 2020 statement: an updated guideline for reporting systematic reviews._ BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/  
31  
**Quadro B** - Estudos excluídos na fase de elegibilidade e motivos para exclusão.  
|**Autor, ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Sanabria et al., 2011|_Routine postoperative administration of vitamin D and calcium after total_<br>_thyroidectomy: a meta-analysis_|População|
|Ravikumar et al.,|_A Prospective Study on Role of Supplemental Oral Calcium and Vitamin D_|População|
|2017|_in Prevention of Postthyroidectomy Hypocalcemia_||
|Bilginer et al., 2022|_Assessment of calcium and vitamin D medications adherence in patients with_<br>_hypoparathyroidism after thyroidectomy_|Delineamento de<br>estudo|
|Boyanov et al., 2023|_Biochemical Control of 78 Patients with Chronic Hypoparathyroidism_<br>_Referred between 2006 and 2020-Where do We Actually Stand?_|Delineamento de<br>estudo|
|Canat et al., 2023|_The effects of adequate dietary calcium intake in patients with_<br>_hypoparathyroidism non-adherent to treatment: a prospective randomized_<br>_controlled trial_|Delineamento de<br>estudo|
|Di Maio et al., 2018|_Current treatment of hypoparathyroidism: theory versus reality waiting_<br>_guidelines for children and adolescents_|Delineamento de<br>estudo|
|Gertner et al., 1997|_25-Hydroxyvitamin D levels in patients treated with high-dosage ergo- and_<br>_cholecalciferol_|Delineamento de<br>estudo|
|Gronskaia et al.,<br>2020|_A registry for patients with chronic hypoparathyroidism in Russian adults_|Delineamento de<br>estudo|
|Mitchell et al., 2012|_Long-term follow-up of patients with hypoparathyroidism_|Delineamento de<br>estudo|
|Radakrishnan et al.,<br>2021|_Hypocalcemia prevention and management after thyroidectomy in children:_<br>_A systematic review_|Delineamento de<br>estudo|
|Underbjerg et al.,|_Long-Term Complications in Patients With_|Delineamento de|
|2018|_Hypoparathyroidism Evaluated by Biochemical Findings: A Case-Control_<br>_Study_|estudo|
|van Dijk et al., 2023|_Management of Postthyroidectomy Hypoparathyroidism and Its Effect on_<br>_Hypocalcemia-Related Complications: A Meta-Analysis_|Delineamento de<br>estudo|
|Wang et al., 2009|_Treatment of hypocalcemia caused by hypoparathyroidism or_<br>_pseudohypoparathyroidism with domestic-made calcitriol: a prospective and_<br>_self-controlled clinical trial_|Delineamento de<br>estudo|
|Zanchetta et al.,|_Hipopara-Red, Real Life Experience in 322 Patients With_|Delineamento de|
|2020|_Hypoparathyroidism_|estudo|
|Mazoni et al., 2020|_Safety and Efficacy of Conventional Therapy with Calcium and Activated_<br>_Vitamin D in Patients with Chronic Post-Operative Hypoparathyroidism:_<br>_Results of a Cross-Sectional Case-Control Study_|Tipo de publicação|
|Zanchetta et al.,<br>2019|_Hipopara-red, real life experience in 322 patients_<br>_with hypoparathyroidism in Argentina_|Tipo de publicação|
|Gronskaya et al.,|_The first results from the russian registry on hypoparathyroidism and_|Tipo de publicação|
|2019|_pseudohypopar-athyroidism in adults_||  
32  
|**Autor, ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Edafe et al., 2017|_Calcium, vitamin D or recombinant parathyroid hormone for managing_<br>_post-thyroidectomy hypoparathyroidism_|Tipo de publicação|
|Amaral et al., 2017|_Conventional treatment of hypoparathyroidism is not sufficient to prevent_<br>_hyperphosphatemia and hypercalciuria_|Tipo de publicação|
|Schwetz et al., 2016|_Hypoparathyroidism descriptive results of a large retrospective Austrian_<br>_cohort_|Não encontrado|
|Iervolino et al.,|_Impact of the cholecalciferol calcitriol coadministration on the metabolic_|Não encontrado|
|2013|_control, calciuria and renal function in patients with hypoparathyroidism_||
|Proye et al., 1990|_The parathyroid risk in thyroid surgery. Argument against the early_|Não encontrado|
||_postoperative prescription of vitamin D. Experience with 729_<br>_thyroidectomies in 1988._||
|Sawicki et al., 1991|_Postoperative hypoparathyroidism: long term observation and therapy_|Não encontrado|  
Fonte: Elaboração própria.  
O ECR<sup>8</sup> foi conduzido na Índia, incluindo pacientes diagnosticados com hipoparatireoidismo idiopático. O diagnóstico foi baseado na hipocalcemia e baixos níveis séricos do PTH intacto. Inicialmente, os pacientes receberam doses diárias de alfacalcidol variando de 0,5 mcg a 1,0 mcg, conforme a gravidade da hipocalcemia, associadas à administração de 1,0 a 2,0 g de cálcio elementar na forma de carbonato de cálcio (cada comprimido continha 500 mg de cálcio elementar e 250 UI de colecalciferol), divididos nas refeições da manhã e da noite. Durante o acompanhamento, a dose de alfacalcidol foi ajustada para o máximo de 3,0 mcg/dia para atingir um controle ideal dos níveis de cálcio sérico. Apenas os pacientes que mantiveram níveis de cálcio sérico dentro da faixa ideal durante os dois últimos acompanhamentos, com pelo menos um mês de intervalo entre eles, foram incluídos no estudo.  
Para equilibrar o número de pacientes com hiperfosfatemia e/ou hipercalciúria entre os grupos alfacalcidol e calcitriol, foi realizada uma randomização estratificada. Após um jejum noturno, os pacientes foram instruídos a coletar urina de 24 horas e medir o volume utilizando um cilindro apropriado. Amostras de sangue foram coletadas e analisadas para cálcio sérico, fósforo inorgânico e a razão cálcio-creatinina na urina para possibilitar a randomização estratificada. Aqueles com cálcio sérico dentro da faixa normal (8,0 a 10,0 mg/dL) foram divididos em quatro grupos com base nos níveis de fósforo e na razão cálcio-creatinina na urina: hiperfosfatêmicos e hipocalciúricos, hiperfosfatêmicos e normocalciúricos, normofosfatêmicos e hipocalciúricos, e normofosfatêmicos e normocalciúricos. Hiperfosfatemia foi definida como fósforo sérico acima de 4,5 mg/dL e hipocalciúria como razão cálcio-creatinina acima de 0,2 mg/mg.  
Os pacientes estratificados em cada um dos quatro foram alocados nos grupos alfacalcidol ou calcitriol. Os pacientes do grupo alfacalcidol continuaram com a dose estabelecida, enquanto aqueles no grupo calcitriol foram trocados de alfacalcidol para calcitriol com metade da dose de alfacalcidol. Quando não foi possível administrar exatamente a metade da dose de alfacalcidol, o calcitriol foi prescrito na quantidade mais próxima à metade da dose. Todos os pacientes continuaram com a dose diária habitual de carbonato de cálcio.  
Em cada acompanhamento, foram medidos o cálcio total sérico, o fósforo e a razão cálcio-creatinina na urina de 24 horas. Se o cálcio total sérico medido em qualquer acompanhamento estivesse entre 8,0 e 9,5 mg/dL, a dose de alfacalcidol ou calcitriol foi mantida. A dose foi ajustada se o cálcio total sérico fosse maior que 10,0 mg/dL ou menor que 7,5 mg/dL em qualquer acompanhamento e entre 9,5 e 10,0 mg/dL ou entre 7,5 e 8,0 mg/dL em dois acompanhamentos consecutivos. A dose diária de alfacalcidol ou calcitriol foi ajustada em incrementos de 0,25 mcg durante o acompanhamento. Pacientes em ambos os braços de intervenção receberam 60.000 UI de colecalciferol mensalmente a partir do terceiro mês até a conclusão do estudo.  
33  
A partir do terceiro mês de acompanhamento, iniciou-se a administração de uma alta dose de vitamina D (colecalciferol). Durante todo o período de seguimento, os pacientes dos grupos que receberam alfacalcidol e calcitriol mantiveram doses baixas de vitamina D. Para a análise, foram coletados e considerados os resultados mensais, quando disponíveis. Assim, como a administração da alta dose de vitamina D começou no terceiro mês, os dados do segundo mês – representando pacientes que receberam apenas doses baixas de vitamina D – e do quarto mês – quando os pacientes já haviam recebido altas doses por dois meses – foram utilizados para comparação, permitindo a análise entre o uso de doses baixas e altas de vitamina D com o mesmo tempo de seguimento.  
Na análise por intenção de tratar (ITT), foram apresentados os resultados mensais referentes aos desfechos de **níveis séricos de fosfato**<sup>**a**</sup> , **razão cálcio/creatinina na urina de 24 horas**<sup>**b**</sup> e proporção de pacientes com **hipercalciúria** e **hiperfosfatemia** . Não foram observadas diferenças estatisticamente significativas entre os grupos tratados com alfacalcidol ou calcitriol (vitamina D em baixa dose) e aqueles tratados com colecalciferol (vitamina D em alta dose) ao comparar os dados do segundo e do quarto mês de acompanhamento para os desfechos supracitados.  
Para os desfechos contínuos, **níveis séricos de fosfato** (DM 0,10 [IC 95% -0,14 a 0,34; p = 0,40]) e **razão cálcio/creatinina na urina de 24 horas** (DM 0,00 [IC 95% -0,06 a 0,06; p = 0,94]) foram calculados os resultados combinados para comparação do grupo vitamina D baixa dose e alta dose. Para ambos os desfechos não foram encontradas diferenças estatisticamente significativas entre os grupos. A mesma ausência de diferença entre os grupos foi observada nos desfechos dicotômicos, para **hipercalciúria** (RR 0,97 [IC 95% 0,76 a 1,24; p = 0,80]) e **hiperfosfatemia** (RR 0,95 [IC 95% 0,72 a 1,26; p = 0,72]). Quanto aos demais desfechos avaliados, para os quais não foi possível realizar a comparação entre os grupos de vitamina D em baixa dose (alfacalcidol ou calcitriol) e vitamina D em alta dose (colecalciferol), os pacientes atingiram um controle adequado dos níveis de cálcio. Não foram observadas diferenças significativas entre os grupos alfacalcidol e calcitriol ao longo de seis meses de acompanhamento em relação aos **níveis séricos de cálcio**<sup>**c**</sup> (média (DP) 8,7 ± 0,4 _versus_ 8,9 ± 0,4 mg/dL; p = 0,13), **níveis séricos de 25-hidroxivitamina D (25[OH]D)**<sup>**d**</sup> (média (DP) 44,0 ± 10,4 _versus_ 47,0 ± 11,8 ng/mL; p = 0,40), **níveis urinários de cálcio** (média (DP) 198 ± 99 versus 260 ± 123 mg; p = 0,08), **hipercalcemia**<sup>e</sup> (2/18 _versus_ 5/24; 0,68) e **hipercalcemia grave**<sup>f</sup> (1/18 _versus_ 2/24; valor p não relatado), respectivamente.  
A **função renal** foi avaliada por meio da taxa de filtração glomerular estimada (TFGe)<sup>g</sup> e, após 6 meses de acompanhamento, não houve diferenças entre os grupos alfacalcidol e calcitriol (94 ± 22 _versus_ 92 ± 27 mL/min/1,73 m<sup>2</sup> ; p = 0,85).  
Em nenhum dos grupos (alfacalcidol e calcitriol), os pacientes necessitaram de **hospitalização ou visitas em emergência por hipocalcemia** .  
O estudo observacional<sup>9</sup> conduzido por Streeten et al., 2017 foi uma coorte retrospectiva realizada por meio de revisão de prontuários eletrônicos de pacientes com diagnóstico confirmado de hipoparatireoidismo crônico que foram tratados em um hospital universitário nos Estados Unidos. Foram extraídas informações sobre idade, sexo, causa do hipoparatireoidismo, níveis  
a O fósforo inorgânico foi considerado dentro da faixa normal estabelecida, que varia entre 2,5 e 4,5 mg/dL. Valores de fósforo sérico superiores a 4,5 mg/mL foram definidos como hiperfosfatemia.  
b A razão cálcio/creatinina na urina de 24 horas superior a 0,2 mg/mg foi definida como hipercalciúria.  
c O cálcio sérico total foi considerado dentro da faixa normal estabelecida, que varia entre 8,6 e 10,2 mg/dL.  
d O 25-hidroxivitamina D foi mensurado por meio do imunoensaio de quimioluminescência com um coeficiente de variação de 2,9% a 5,5%.  
e Níveis de cálcio sérico total superiores a 10,6 mg/dL foram considerados critérios como hipercalcemia.  
f Níveis de cálcio sérico total superiores a 11,0 mg/dL foram considerados critérios como hipercalcemia grave.  
g A função renal foi mensurada por meio da taxa de filtração glomerular (TFG), que foi calculada por meio da equação de colaboração em epidemiologia da doença renal crônica: TFGe = 141 X min(Scr/ĸ, 1)α  X max(Scr/ĸ, 1)-1.209  X 0,993Idade X 1.018 [se feminino]  X 1.159 [se negro], onde Scr é a creatinina sérica, ĸ é 0,7 para mulheres e 0,9 para homens, α é 0,329 para mulheres e 0,411 para homens, min indica o menor valor entre Scr/ĸ ou 1, e max indica o maior valor entre Scr/ĸ ou 1<sup>11</sup> .  
34  
séricos de cálcio e creatinina, entre outras variáveis. Os pacientes foram divididos em dois grupos de tratamento: um grupo recebeu vitamina D2 (em altas doses) e o outro, calcitriol (em baixas doses). A análise dos dados incluiu os dois a três anos mais recentes de acompanhamento. A maior parte dos dados foi obtida de registros eletrônicos, com algumas informações laboratoriais disponíveis apenas em registros em papel. O acompanhamento foi realizado pelos autores e por outros membros da equipe de endocrinologia do centro médico, com alguns pacientes sob a supervisão de docentes de medicina interna.  
Inicialmente, foram identificados 155 pacientes potencialmente elegíveis. Destes, 125 foram excluídos devido à ausência de registros em prontuários eletrônicos, diagnóstico de hipoparatireoidismo primário ou secundário, hipoparatireoidismo pósoperatório transitório ou falta de diagnóstico relacionado às paratireoides. Assim, foram incluídos 30 pacientes com hipoparatireoidismo crônico e com uma duração mínima de quatro anos. Não foram observadas diferenças significativas entre os grupos em termos de idade média, duração ou etiologia do hipoparatireoidismo. A maioria dos pacientes em ambos os grupos era do sexo feminino, com a etiologia cirúrgica predominando, seguida por causas genéticas. No grupo tratado com vitamina D2 (alta dose), a maioria dos pacientes também fazia uso de suplementos de cálcio, variando de 400 a 2000 mg de cálcio elementar por dia, com um paciente recebendo carbonato de cálcio 1.000 mg quatro vezes ao dia. No grupo que recebeu calcitriol (baixa dose), metade dos pacientes utilizava suplementos de cálcio, com doses variando de 250 a 2.000 mg de cálcio elementar por dia, exceto um paciente que tomava 2.500 mg três vezes ao dia.  
No geral, os desfechos primários elegíveis neste estudo não apresentaram diferenças significativas entre os grupos vitamina D2 (alta dose) e calcitriol (baixa dose) para **os níveis séricos cálcio**<sup>h</sup> (média (DP) 8,6 ± 0,6 mg/dL _versus_ 8,4 ± 0,7; p = 0,37), **níveis de creatinina sérica**<sup>i</sup> (média (DP) 0,92 ± 0,33 mg/dL _versus_ 0,98 ± 0,26; p = 0,71) e **níveis urinários de cálcio**<sup>**j**</sup> (média (DP) 171 ± 89 _versus_ 185 ± 183 mg/24 horas; valor de p não apresentado pelos autores), respectivamente.  
Os **níveis séricos de vitamina D**<sup>**k**</sup> foram avaliados somente para os participantes do grupo vitamina D2. A variação de dose da vitamina D2 administrada foi de 2.000 a 50.000 UI/dia, enquanto os níveis séricos de 25-hidroxi-vitamina D (25[OH]D) variaram de 37 a 456 ng/mL. Adicionalmente, os níveis de cálcio sérico estavam normais em todos os casos analisados, mesmo quando os níveis de 25(OH) vitamina D alcançaram 500 ng/mL. A **Figura C** mostra que diferentes doses de vitamina D2 afetam os níveis séricos de 25(OH) vitamina D.  
**Figura C** - Relação entre a 25-hidroxivitamina D sérica e a dose de vitamina D2 no grupo vitamina D2.  
<!-- Start of picture text -->
~ Grupo vitamina D2<br>z 500<br>> |e...<br>£ | 400<br>2 | ss0 +<br>= 300<br>3 °<br>wm | 2<br>N 200 | + 7<br>©<br>TS |iso<br>3Bo | 10 °<br>3 oly eS<br>SE<br>° 10000 20000 30,000 40.000 50000 60000<br>Dose vitamina D2 (UI/dia)<br><!-- End of picture text -->  
**Legenda:** 25(OH)D: 25-hidroxivitamina D; UI: unidades internacionais. **Fonte:** adaptado de Streeten et al., 2017  
h O cálcio sérico médio foi ajustado para níveis de albumina, com a faixa normal estabelecida entre 8,5 e 10,2 mg/dL. i A função renal foi avaliada com base na creatinina sérica, cuja faixa normal é de 0,4 a 1,2 mg/dL. j Os dados sobre os níveis urinários de cálcio não estavam disponíveis para todos os participantes. No grupo tratado com vitamina D2, esses dados estavam disponíveis para 8 dos 16 pacientes, enquanto no grupo tratado com calcitriol, estavam disponíveis para 3 dos 14 pacientes.  
k Os níveis de 25-hidroxivitamina D foram considerados normais quando se mantiveram até 500 ng/mL.  
35  
No grupo calcitriol (baixa dose), quatro dos 16 pacientes necessitaram de **hospitalização ou visitas em emergência por hipocalcemia** _versus_ nenhum dos 16 pacientes no grupo vitamina D2 (alta dose) (p = 0,03). Dos pacientes que apresentaram hipocalcemia no grupo calcitriol, três necessitaram de múltiplas visitas ao hospital. Para o desfecho de **hospitalizações ou visitas a serviços de emergência devido à hipercalcemia** , dois dos 14 pacientes no grupo tratado com calcitriol (baixa dose) necessitaram desses atendimentos. O mesmo ocorreu com dois dos 16 pacientes no grupo tratado com vitamina D2 (alta dose) (p = 1,00).  
**Edafe et al., 2019** realizaram uma revisão sistemática<sup>10</sup> de ensaios clínicos randomizados, com o objetivo de avaliar os efeitos do cálcio, vitamina D e hormônio paratireoide recombinante no tratamento do hipoparatireoidismo pós-tireoidectomia. Foram realizadas buscas estruturadas em dezembro de 2018. Os critérios de elegibilidade incluíam ECRs ou ensaios clínicos controlados (ECCs). Do total de 1.751 registros, após leitura dos textos completos de 29 artigos potencialmente relevantes, nenhum foi elegível para inclusão nesta revisão sistemática. Isso ocorreu, porque os estudos não eram ECRs ou ECCs e a intervenção, comparador ou ambos não corresponderam aos critérios pré-especificados. Portanto, a revisão sistemática destacou a lacuna existente na literatura e a falta de evidências para o tratamento do hipoparatireoidismo a longo prazo<sup>l</sup> .

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.7. Risco de viés dos estudos incluídos** -->
O risco de viés para o ECR recuperado (Saha et al., 2021) foi realizado utilizando a ferramenta RoB 2.0<sup>3,4</sup> . O ensaio clínico foi julgado com ‘algumas preocupações’ para todos os desfechos avaliados. As fragilidades metodológicas foram principalmente identificadas no domínio do processo de randomização, que apesar de detalhar como foi realizado o processo de alocação não deixou explícito se o controle desse processo foi realizado por uma organização externa e independente dos pesquisadores envolvidos. No que diz respeito ao domínio 2, relativo aos vieses de desvios da intervenção, não foram encontrados fatores que aumentassem o risco de viés, uma vez que os pacientes receberam pacotes contendo a quantidade necessária de cápsulas de alfacalcidol ou calcitriol, acompanhados pelos comprimidos de cálcio. Ademais, as análises realizadas por ITT eram apropriadas para estimar o efeito da intervenção.  
Em relação ao domínio 3, relativo aos vieses de dados incompletos, o risco de viés foi considerado baixo, pois as desistências foram mínimas e os dados ausentes foram adequadamente imputados. No domínio 4, relativo aos vieses de mensuração do desfecho, os métodos de mensuração foram comparáveis entre os grupos. Embora os autores tenham mantido um registro dos medicamentos administrados a cada paciente, sugerindo que os avaliadores estavam cientes da intervenção recebida, os desfechos foram mensurados por parâmetros laboratoriais, e o conhecimento da intervenção poderia não influenciar os resultados. O mesmo racional foi seguido para o desfecho hospitalização/visitas em emergência por hipocalcemia, visto que a natureza do desfecho também não pode ser afetada pelo conhecimento da intervenção pelos julgadores.  
Por fim, no domínio 5, relativo aos vieses de relato de resultado, não foram identificadas evidências claras de relatos seletivo de desfechos, ou seja, os resultados pré-especificados foram relatados. O protocolo do estudo estava disponível e os resultados obtidos estavam em conformidade com os resultados registrados (CTRI/2019/05/019203). O **Quadro C** detalha a avaliação do risco de viés.  
> l Hipoparatireoidismo de longa duração definido como a necessidade de suplementos de cálcio, vitamina D ou ambos para manter a normocalcemia seis meses ou mais após a cirurgia.  
36  
**Quadro C** - Avaliação do risco de viés do ensaio clínico randomizado, segundo desfechos avaliados.  
|**Estudo**|**Desfecho**|**D1**|**D2**|**D3**|**D4**|**D5**|**Geral**|
|---|---|---|---|---|---|---|---|
||Níveis séricos de vitamina D|||||||
||Níveis séricos de cálcio|||||||
||Níveis séricos de fosfato|||||||
||Níveis urinários de cálcio|||||||
||Função renal*|||||||
|Saha et al.,<br>2021|Razão cálcio/creatinina na urina<br>de 24 horas|||||||
||Hipercalcemia|||||||
||Hipercalcemia grave|||||||
||Hipercalciúria|||||||
||Hiperfosfatemia|||||||
||Hospitalização/visitas em<br>emergência por hipocalcemia|||||||  
**Fonte:** Elaboração própria. Legenda: : Baixo; :    Algumas preocupações  
**Nota:** *Função renal avaliada por meio da taxa de filtração glomerular estimada.  
D1: domínio relativo a vieses do processo de randomização, D2: domínio relativo a vieses de desvios da intervenção, D3: domínio relativo a vieses de dados incompletos, D4: domínio relativo a vieses de mensuração do desfecho, D5: domínio relativo a vieses de reporte de resultado.  
A avaliação do risco de viés para o estudo de Streeten et al. (2017) foi conduzida utilizando a ferramenta ROBINS-I<sup>5</sup> . Este estudo observacional foi julgado com ‘risco de viés grave’ para a maioria dos desfechos avaliados, com exceção dos níveis séricos de vitamina D. As principais fragilidades metodológicas foram principalmente identificadas no domínio viés de confundimento. Embora os fatores de confusão, como idade, causa e duração do hipoparatireoidismo tenham sido controlados, não houve controle para fatores adicionais, principalmente aqueles relacionados aos exames laboratoriais (cálcio, vitamina D, creatinina, magnésio, fósforo) e o tempo de seguimento. Adicionalmente, para o desfecho níveis séricos de vitamina D, os resultados não foram apresentados para o grupo comparador, sendo classificado com ‘risco de viés crítico’. No que se refere ao domínio 2, relativo ao viés na seleção dos participantes do estudo, não foram identificados fatores que aumentassem o risco de viés. Os pacientes foram selecionados com base em registros eletrônicos e o diagnóstico de hipoparatireoidismo crônico foi confirmado por endocrinologistas.  
Em relação ao domínio 3, que avalia o viés na classificação das intervenções, o risco de viés foi considerado baixo, uma vez que a intervenção com vitamina D2 e o comparador, calcitriol, foram claramente definidos. No domínio 4, que aborda o viés devido às intervenções planejadas, não foram observados episódios que divergiram da prática usual ou que sugerissem desequilíbrios entre os grupos avaliados para os desfechos analisados. No domínio 5, relativo ao viés de relato de resultado, todos os dados estavam disponíveis para os 30 pacientes incluídos no estudo, resultando em um risco de viés baixo. Contudo, os  
37  
dados sobre os níveis urinários de cálcio estavam disponíveis apenas para um número reduzido de amostras (n = 11), sendo classificado com risco de viés grave neste desfecho.  
Para o domínio 6, relativo ao viés na mensuração dos desfechos, as avaliações laboratoriais realizadas foram menos suscetíveis a viés, dado que essas medidas não são influenciadas pelo julgamento dos avaliadores, conforme indicado no guia da ferramenta ROBINS-I, mesmo que os julgadores estivessem cientes da intervenção recebida pelos pacientes. Em contrapartida, a abordagem para os desfechos de hospitalizações/visitas a emergências foi diferente, pois os pesquisadores confiaram nos relatos dos pacientes e nos prontuários médicos da instituição. Contudo, é possível que alguns pacientes tenham sido internados ou atendidos em outras instituições sem comunicar esses eventos a seus médicos. Para o desfecho níveis séricos de cálcio, o risco de viés foi considerado grave, visto que os dados disponíveis, ou seja, número de medidas, variou entre os participantes.  
Por fim, no domínio 7, relativo ao viés de seleção no relato dos desfechos, não foram geradas múltiplas estimativas de efeito para diferentes medidas ou utilizados diferentes métodos analíticos para subgrupos distintos. O **Quadro D** detalha a avaliação do risco de viés.  
38  
**Quadro D** - Avaliação do risco de viés do estudo observacional, segundo desfechos avaliados.  
|**Estudo**|**Desfecho**|**D1**|**D2**|**D3**|**D4**|**D5**|**D6**|**D7**|**Geral**|
|---|---|---|---|---|---|---|---|---|---|
||Níveis séricos de vitamina D|||||||||
||Níveis séricos de cálcio|||||||||
|S  l|Níveis urinários de cálcio|||||||||
|treeten et a.,<br>2017|Função renal*|||||||||
||Hospitalização/visitas em<br>emergência por hipocalcemia|||||||||
||Hospitalização/visitas em<br>emergência por hipercalcemia|||||||||  
**Fonte:** Elaboração própria. Legenda:     : Baixo;       :Grave;       : Crítico  
**Nota:** *Função renal avaliada por meio dos níveis séricos de creatinina.  
D1: domínio relativo ao viés de confundimento; D2: domínio relativo ao viés na seleção dos participantes do estudo; D3: domínio relativo ao viés na classificação das intervenções; D4: domínio relativo ao viés devido às intervenções planejadas; D5: domínio relativo ao viés de reporte de resultado; D6: domínio relativo ao viés na mensuração dos desfechos; D7: domínio relativo ao viés de seleção no relato dos desfechos.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.8. Qualidade metodológica das revisões sistemáticas** -->
Embora a revisão sistemática incluída tenha sido elaborada pela colaboração Cochrane, os autores não identificaram estudos elegíveis que atendessem aos critérios de inclusão estabelecidos no protocolo. Por conseguinte, nenhum estudo foi incluído para análise qualitativa ou quantitativa. Assim, considerou-se que esta revisão sistemática apresentou alta qualidade metodológica, uma vez que não foi possível penalizar nenhum dos domínios relacionados aos resultados, devido ao fato desta revisão sistemática ser vazia (nenhum estudo elegível foi incluído). No entanto, a avaliação dos domínios referentes à metodologia foi viável por meio da ferramenta AMSTAR-2<sup>6</sup> , conforme **Quadro E** .  
**Quadro E** - Avaliação da qualidade metodológica da revisão sistemática incluída.  
|Domínios|Edafe et al.,<br>2019|
|---|---|
|1* - As perguntas de pesquisa e os critérios de inclusão para a revisão incluem os componentes do PICO?|Sim|
|2 - O relatório da revisão contém uma declaração explícita de que os métodos de revisão foram estabelecidos<br>antes da realização da revisão e o relatório justificou quaisquer desvios significativos do protocolo?|Sim|
|3 - Os autores da revisão explicaram a seleção dos desenhos de estudo para inclusão na revisão?|Sim|
|4* - Os autores da revisão usaram uma estratégia abrangente de pesquisa de literatura?|Sim|
|5 - Os autores da revisão realizaram a seleção do estudo em duplicata?|Sim|
|6 - Os autores da revisão realizaram a extração de dados em duplicata?|NA|
|7* - Os autores da revisão fornecem uma lista de estudos excluídos e justificam as exclusões?|NA|
|8 - Os autores da revisão descrevem os estudos incluídos em detalhes adequados?|NA|
|9* - Os autores da revisão usaram uma técnica satisfatória para avaliar o risco de viés (RoB) em estudos<br>individuais que foram incluídos na revisão?|NA|
|10 - Os autores da revisão relataram as fontes de financiamento para os estudos incluídos na revisão?|NA|  
39  
|Domínios|Edafe et al.,<br>2019|
|---|---|
|11* - Se a metanálise foi realizada, os autores da revisão usaram métodos apropriados para a combinação<br>estatística de resultados?|NA|
|12 - Se a metanálise foi realizada, os autores da revisão avaliaram o impacto potencial do risco de viés em<br>estudos individuais sobre os resultados da metanálise ou outra síntese de evidências?|NA|
|13* - Os autores da revisão consideraram risco de viés em estudos individuais ao interpretar / discutir os<br>resultados da revisão?|NA|
|14 - Os autores da revisão forneceram uma explicação satisfatória e discussão de qualquer heterogeneidade<br>observada nos resultados da revisão?|NA|
|15* - Se eles realizaram síntese quantitativa, os autores da revisão realizaram uma investigação adequada<br>do viés de publicação (pequeno viés de estudo) e discutiram seu provável impacto nos resultados da revisão?|NA|
|16 - Os autores da revisão relataram quaisquer fontes potenciais de conflito de interesses, incluindo algum<br>financiamento recebido para realizar a revisão?|Sim|
|Qualidade metodológica geral<br>(Criticamente baixa, Baixa, Moderada ou Alta)|Alta<sup>#</sup>|  
**Legenda:** AMSTAR-2: _A MeaSurement Tool to Assess systematic Reviews_ ; NA, não se aplica. **Nota:** *Itens considerados críticos;<sup>#</sup> Avaliação metodológica considerada alta, devido a possível avaliação dos domínios relacionados a metodologia do estudo. Com relação aos domínios que avaliavam os resultados não foi possível realizar a avaliação. **Fonte:** Elaboração própria.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.9. Avaliação da certeza da evidência** -->
A avaliação da certeza da evidência, conduzida utilizando a ferramenta _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE)<sup>7</sup> revelou uma confiança considerada muito baixa para todos os desfechos examinados no ECR. Para avaliar a comparação entre grupos de vitamina D em baixas e altas doses, foram considerados na análise da certeza da evidência apenas os desfechos para os quais foi possível realizar comparações estatísticas entre os grupos. Ademais, a confiança foi classificada como baixa para todos os desfechos avaliados no estudo observacional.  
Com relação ao ECR, os principais fatores que justificaram o rebaixamento da certeza da evidência incluíram o risco de viés, com algumas preocupações relacionadas ao processo de randomização; a evidência indireta, uma vez que a intervenção elegível não permitiu comparações diretas entre os grupos de intervenção de interesse (vitamina D em altas doses versus baixas doses), os resultados foram obtidos por meio de abordagens estatísticas adotadas pelos avaliadores para estimar a magnitude do efeito de vitamina D em altas doses versu _s_ baixas doses; e a imprecisão, considerando que os intervalos de confiança cruzaram a linha de nulidade. Para o estudo observacional, a certeza da evidência foi considerada baixa, principalmente em decorrência do rebaixamento em risco de viés, devido a presença de fatores confundidores e da imprecisão, com ausência de diferença estatística entre os grupos e o não alcance dos critérios do tamanho ótimo da informação. Os **Quadros F** e **G** descrevem a avaliação da certeza da evidência para vitamina D isolada em altas doses para pacientes com HP.  
40  
**Quadro F** - Avaliação da certeza da evidência do ensaio clínico randomizado pelo sistema GRADE.  
|**A**<br>**№**<br>**dos**<br>**Delineament**<br>**Risco de**|**valiação da conf**<br>**Inconsistênci**|**iança**<br>**Evidência**|**Imprecisão**|**Outras**<br>**consider**|**№ de p**<br>**Vitamina**<br>**D em**|**acientes**<br>**Vitamina**<br>**D em**|**Ef**<br>**Risco**<br>**Relativ**|**eito**<br>**Absoluto**|**Valor**<br>**de p**|**Confiança**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**estud**<br>**os**<br>**o do estudo**<br>**viés**<br>**Razão cálcio/creatinina na**<br>1<br>ECR<br>grave<sup>a</sup>|**a**<br>**urina de 24 hor**<br>não grave|**indireta**<br>**as (seguiment**<br>grave<sup>b</sup>|<br>**o: 2 a 4 meses;**<br>grave<sup>c</sup>|**ações**<br>**avaliado co**<br>nenhum|**altas**<br>**doses**<br>**m mg/mg)**<br>45|**baixas**<br>**doses**<br>45|**o (IC**<br>**95%)**<br>-|**(IC 95%)**<br>DM<br>0<br>(0,06<br>menor<br>para 0,06<br>mais alto)|<br>0,94|⨁◯◯◯<br>Muito<br>baixa<sup>a,b,c</sup>|CRÍTICO|
|**Níveis séricos de fosfato (se**<br>1<br>ECR<br>grave<sup>a</sup>|**guimento: 2 a 4**<br>não grave|**meses; avalia**<br>grave<sup>b</sup>|**do com mg/dL**<br>grave<sup>c</sup>|**)**<br>nenhum|45|45|-|DM<br>0.1<br>mais alto<br>(0,14<br>menor<br>para 0,34<br>mais alto)|0,40|⨁◯◯◯<br>Muito<br>baixa<sup>a,b,c</sup>|IMPORTANT<br>E|
|**Hipercalciúria (seguimento**|**: 2 a 4 meses)**|||||||||||
|1<br>ECR<br>grave<sup>a</sup>|não grave|grave<sup>b</sup>|grave<sup>c</sup>|nenhum|34/45<br>(75,6%)|33/45<br>(73,3%)|RR 0,97<br>(0,76<br>para<br>1,34)|22 menos<br>por 1.000<br>(de<br>176<br>menos<br>para<br>249<br>mais)|0,80|⨁◯◯◯<br>Muito<br>baixa<sup>a,b,c</sup>|CRÍTICO|
|**Hiperfosfatemia (seguimen**|**to: 2 a 4 meses)**|||||||||||  
41  
|1<br>ECR|grave<sup>a</sup>|não grave|grave<sup>b</sup>|grave<sup>c</sup>|nenhum|32/45<br>(71,1%)|30/45<br>(66,7%)|RR 0,95<br>(0,72<br>para<br>1,26)|33 menos<br>por 1.000<br>(de<br>187<br>menos<br>para<br>173<br>mais)|0,72|⨁◯◯◯<br>Muito<br>baixa<sup>a,b,c</sup>|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
**Fonte:** Elaboração própria. **Legenda** : **DM:** diferença de média; **ECR:** ensaio clínico randomizado; **IC:** intervalo de confiança; **RR:** risco relativo  
**Explicações** : a. O risco de viés foi classificado como apresentando algumas preocupações, especialmente em relação ao processo de randomização. Essa preocupação decorre principalmente da ausência de menção sobre o controle da alocação por uma entidade externa e independente dos pesquisadores envolvidos. Assim, a evidência foi rebaixada em um nível por risco de viés.  
b. O ECR não apresentou uma comparação direta entre as intervenções de interesse (vitamina D em alta dose versus baixa dose). Para fins de análise, foram consideradas as abordagens estatísticas adotadas para realizar as comparações entre os grupos de interesse para responder ao acrônimo PICO.  
c. O intervalo de confiança de 95% ao redor da estimativa de efeito pontual foi largo o suficiente para incluir os intervalos de benefício e de dano (atravessa a linha de não efeito).  
42  
**Quadro G** - Avaliação da certeza da evidência do estudo observacional pelo sistema GRADE.  
|**№**<br>**dos**<br>**estud**<br>**os**|**Delineament**<br>**o do estudo**<br>**Níveis séricos de**<br><br>estudo|**A**<br>**Risco**<br>**de viés**<br>**cálcio (seg**|**valiação da con**<br>**Inconsistênci**<br>**a**<br>**uimento: NR; av**|**fiança**<br>**Evidência**<br>**indireta**<br>**aliado com:**|**Imprecisão**<br>**mg/dL)**<br>|**Outras**<br>**consider**<br>**ações**<br>|**№ de p**<br>**Vitamina**<br>**D em altas**<br>**doses**<br>**(vitamina**<br>**D2)**<br>|**acientes**<br>**Vitamina**<br>**D em**<br>**baixas**<br>**doses**<br>**(calcitriol)**<br>|**Resu**<br>**Média**<br>**(DP) ou**<br>**N (%)**<br>**da**<br>**vitamin**<br>**a D em**<br>**altas**<br>**doses**<br>|**ltados**<br>**Média**<br>**(DP) ou**<br>**N (%)**<br>**da**<br>**vitamin**<br>**a D em**<br>**baixas**<br>**doses**<br>|**Valor**<br>**de p**<br>|**Confiança**<br>⨁⨁◯◯|**Importância**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||1<br>|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|16|14|8,6 (0,6)|8,4 (0,7)|0,37||CRÍTICO|
||observacional<br>**Função renal (se**<br>estudo|**guimento:**|<br>**NR; avaliado co**|<br>**m: níveis séri**|**cos de creatinin**<br>|**a – mg/dL)**|||0,92|0,98||Baixa<sup>ab</sup><br>⨁⨁◯◯||
||1<br>bil|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|16|14|<br>033|<br>026|0,71|Bi<sup>ab</sup>|CRÍTICO|
||oservacona<br>**Níveis urinários**<br>estudo|**de cálcio (s**|**eguimento: NR;**|**avaliado com**|**: mg/24horas)**||||(,)|(,)<br>185||axa<br>⨁⨁◯◯||
||1|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|8|3|171 (89)||0,90*||CRÍTICO|
||observacional|||||||||(183)||Baixa<sup>ab</sup>||
||**Hospitalização o**|**u visitas e**|**m emergência po**|**r hipocalcemi**|**a (seguimento:**|**NR)**||||||||
||estudo|||||||||||⨁⨁◯◯||
||1<br>|grave<sup>a</sup>|não grave|não grave|grave<sup>c</sup>|nenhum|16|14|0 (0%)|4 (29%)|0,03||CRÍTICO|
||observacional<br>**Hospitalização o**<br><br>estudo|**u visitas e**<br>|**m emergência po**<br>|**r hipercalcem**<br>|**ia (seguimento**<br>|**: NR)**<br>||||||Baixa<sup>ac</sup><br>⨁⨁◯◯||
||1<br>|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|16|14|2 (13%)|2 (14%)|1,00|<sup>b</sup>|CRÍTICO|
||observacional|||||||||||Baixa<sup>a</sup>||
||**Níveis séricos de**|**vitamina**|**D (seguimento: N**|**R; avaliado c**|**om: ng/mL)**|||||||||  
43  
|1<br>estudo<br>observacional|grave<sup>a</sup>|não grave|não grave|grave<sup>d</sup>|nenhum|A variação de dose da vitamina D2 (alta dose) administrada<br>foi de 2.000 a 50.000 UI/dia, enquanto os níveis séricos de<br>25(OH)D variaram de 37 a 456 ng/mL.|⨁⨁◯◯<br>Baixa<sup>ad</sup><br>CRÍTICO|
|---|---|---|---|---|---|---|---|  
**Fonte:** Elaboração própria. **Legenda** : **25(OH)D:** 25-hidroxi-vitamina D **DP:** desvio padrão; **ECR:** ensaio clínico randomizado; **NR:** não relatado; **Vitamina D2** : ergocalciferol **Nota: *** Valor de p calculado pelo parecerista, pois os autores não relataram o valor de p para esse desfecho.  
**Explicações** : a. O risco de viés foi considerado moderado para os estudos observacionais, principalmente pela presença de fatores confundidores não considerados nas análises dos dados. Assim, a evidência foi rebaixada em um nível por risco de viés.  
- b. Não foi observada uma diferença estatisticamente significativa, por esta razão a imprecisão foi rebaixada em um nível.  
- c. Diferença estatisticamente significativa, no entanto o tamanho ótimo da informação não foi alcançado, por esta razão a imprecisão foi rebaixada em um nível.  
- d. Devido à ausência de resultados para o grupo comparador, a imprecisão foi rebaixada em um nível.  
44

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **4.1.10.Balanço entre efeitos desejáveis e indesejáveis** -->
Os estudos incluídos na análise evidenciaram que os tratamentos avaliados para população com HP – alfacalcidol versus calcitriol e vitamina D em altas doses _versus_ em baixas doses, seja no resultado combinado, seja nos resultados provenientes do estudo observacional – foram eficazes na manutenção dos níveis séricos de vitamina D, cálcio, fosfato e função renal, tanto nos resultados combinados quanto nos dados oriundos dos estudos primários embora sem diferenças estatisticamente significativas entre os grupos. No entanto, em relação ao desfecho de hospitalização ou visitas em emergência por hipocalcemia, o estudo observacional indicou uma maior incidência no grupo tratado com calcitriol (baixa dose), enquanto o grupo que recebeu vitamina D2 (alta dose) não relatou tais eventos.  
Assim, os achados da revisão sistemática conduzida sugerem que os tratamentos avaliados apresentaram eficácia comparável, sem que haja predominância de um sobre o outro. Em termos de segurança, não foram observados eventos de hospitalização por hipocalcemia no ECR que suplementou colecalciferol (60.000 UI) em ambos os grupos de tratamento; no estudo observacional, esses eventos ocorreram exclusivamente no grupo que não recebeu vitamina D em altas doses. Contudo, a certeza da evidência variou de muito baixa a baixa para todos os desfechos apresentados, para ECR e estudo observacional, respectivamente.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **5. Equipe de elaboração e partes interessadas** -->
Colaboração externa  
O Protocolo foi atualizado pelo UATS do Hospital Alemão Oswaldo Cruz.

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro H** ).  
**Quadro H** - Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos b|enefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|  
45  
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser|afetados pela sua|
|---|---|
|atividade na elaboração ou revisão da diretriz?||
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **6. REFERÊNCIAS** -->
1.  Brasil. Ministério da Saúde. Diretrizes metodológicas: elaboração de pareceres técnico-científicos [Internet]. Brasília, DF; 2021 [cited 2024 Oct 2]. Available from: https://www.gov.br/conitec/pt-  
br/midias/artigos_publicacoes/diretrizes/diretrizes_metodologicas_ptc.pdf  
2.  Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan-a web and mobile app for systematic reviews. Syst Rev [Internet]. 2016 Dec 5 [cited 2024 Oct 2];5(1):1–10. Available from: https://systematicreviewsjournal.biomedcentral.com/articles/10.1186/s13643-016-0384-4  
3.  Higgins JPT, Altman DG, Gøtzsche PC, Jüni P, Moher D, Oxman AD, et al. The Cochrane Collaboration’s tool for assessing risk of bias in randomised trials. The BMJ [Internet]. 2011 Oct 29 [cited 2024 Oct 2];343(7829). Available from: /pmc/articles/PMC3196245/  
4.  Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: a revised tool for assessing risk of bias in randomised trials. BMJ [Internet]. 2019 [cited 2024 Oct 2];366. Available from: https://pubmed.ncbi.nlm.nih.gov/31462531/  
5.  Sterne JA, Hernán MA, Reeves BC, Savović J, Berkman ND, Viswanathan M, et al. ROBINS-I: a tool for assessing risk of bias in non-randomised studies of interventions. BMJ [Internet]. 2016 Oct 12 [cited 2024 Oct 2];355. Available from: https://www.bmj.com/content/355/bmj.i4919  
46  
6.  Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ [Internet]. 2017 Sep 21 [cited 2024 Oct 2];358:4008. Available from: https://www.bmj.com/content/358/bmj.j4008  
7.  Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ [Internet]. 2008 Apr 24 [cited 2024 Oct 2];336(7650):924–6. Available from: https://www.bmj.com/content/336/7650/924  
8.  Saha S, Sreenivas V, Goswami R. Alfacalcidol vs Calcitriol in the Management of Patient With Hypoparathyroidism: A Randomized Controlled Trial. J Clin Endocrinol Metab. 2021 Jun 16;106(7):2092–102.  
9.  Streeten EA, Mohtasebi Y, Konig M, Davidoff L, Ryan K. Hypoparathyroidism: Less Severe Hypocalcemia With Treatment With Vitamin D2 Compared With Calcitriol. J Clin Endocrinol Metab. 2017 May 1;102(5):1505–10.  
10. Edafe O, Mech CE, Balasubramanian SP. Calcium, vitamin D or recombinant parathyroid hormone for managing post-thyroidectomy hypoparathyroidism. Cochrane Database of Systematic Reviews. 2019 May 22;2019(5).  
11. Levey AS, Stevens LA, Schmid CH, Zhang Y, Castro AF, Feldman HI, et al. A new equation to estimate glomerular filtration rate. Ann Intern Med [Internet]. 2009 May 5 [cited 2024 Oct 2];150(9):604–12. Available from: https://pubmed.ncbi.nlm.nih.gov/19414839/  
47

---

<!-- METADADOS: doenca: Hipoparatireoidismo | secao: **APÊNDICE 2 – HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório da**||**Tecnologias**<br>|**avaliadas pela Conitec**|
|---|---|---|---|
|**diretriz clínica (Conitec) ou**<br>**Portaria de Publicação**|**Principais alterações**|**Incorporação ou**<br>**alteração do uso no**<br>**SUS**|**Exclusão, não incorporação**<br>**ou não alteração no SUS**|
|Relatório de Recomendação<br>nº 1.074/2025|Atualização do documento<br>e exclusão do alfacalcidol||Exclusão do alfacalcidol para<br>hipoparatireoidismo [Portaria<br>SECTICS/MS nº 56/2024;<br>Relatório de Recomendação nº<br>937/2024]|
|Portaria SAS/MS nº 450, de<br>29 de abril de 2016|Atualização do documento|||
|Portaria SAS/MS nº 14, de|Primeira versão do|||
|15 de janeiro de 2010|documento|||  
48

---

