<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: Geral -->
<!-- Start of picture text -->
eS<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA SECTICS/MS Nº 76, DE 28 DE DEZEMBRO DE 2023.  
Torna pública a decisão de aprovar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 - Diagnóstico, Manejo e Acompanhamento de Crianças Expostas ao HIV.  
Ref.: 25000.127349/2023-13  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.798, de 28 de novembro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica aprovado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 - Diagnóstico, Manejo e Acompanhamento de Crianças Expostas ao HIV.  
Art. 2º. Ficam atualizados, no âmbito do SUS, os capítulos 1 a 5 do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes, conforme consta do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 - Diagnóstico, Manejo e Acompanhamento de Crianças Expostas ao HIV.  
Art. 3º. O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/pt-br.  
Art. 4º. Esta Portaria entra em vigor na data de sua publicação.  
CARLOS A. GRABOIS GADELHA  
1  
**ANEXO**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A Política de Atenção Integral à Saúde da Criança - PNASC<sup>1</sup> inclui entre seus eixos, vigilância e prevenção da mortalidade infantil e atenção à saúde do recém-nascido. As recomendações do Ministério da Saúde (MS) contidas neste Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para o Manejo da Infecção pelo HIV em Crianças e Adolescentes buscam contribuir para a sobrevivência, qualidade de vida das crianças vivendo com HIV (CVHA), assim como, para o cumprimento dos compromissos do país diante das metas dos Objetivos de Desenvolvimento Sustentável 2015-2030 (ODS) das Nações Unidas.<sup>2</sup>  
Esta atualização amplia a indicação de inibidores da integrase (INI) na profilaxia de crianças expostas ao HIV, e no início de tratamento, incluindo, assim, todas as faixas etárias. Também altera esquemas terapêuticos, buscando tornar a terapia antirretroviral (TARV) mais tolerável, um permanente desafio para a população de CVHA, devido às limitadas apresentações de medicamentos.  
Além das indicações de medicamentos e testes laboratoriais, este Protocolo amplia os aspectos ligados ao cuidado, trazendo a abordagem da prevenção combinada como estratégia de prevenção ao HIV. Sobretudo, aborda um conjunto de intervenções biomédicas, comportamentais e estruturais propondo que sejam oferecidas aos indivíduos e suas parcerias, nos grupos sociais a que pertencem. Trata-se de ações e informações que consideram as necessidades e especificidades de crianças e adolescentes e as variadas formas de transmissão do vírus.  
Tal abordagem é muito importante, principalmente, em relação aos adolescentes e jovens, faixa etária que apresenta aumento significativo na incidência da infecção pelo HIV. Assim, as informações sobre o início da atividade sexual, transmissibilidade do vírus, sexo seguro e prevenção da gravidez não planejada, entre outras, são imprescindíveis para fortalecer a confiança e melhorar a autoestima dos adolescentes e jovens que vivem com HIV e suas parcerias sexuais, bem como, prevenir novos casos da infecção.  
Além da abordagem para a infecção pelo HIV, é importante que os profissionais e os serviços de saúde estejam estruturados para uma atuação multidisciplinar para o cuidar de crianças e adolescentes vivendo com HIV. O olhar atento e cuidadoso de profissionais e equipes multiprofissionais deve acontecer desde o início do processo de acolhimento, investigação ou revelação diagnóstica. Deve considerar a importância da adesão, vinculação, retenção e seguimento das crianças e adolescentes. Os cuidados devem ir além do manejo do HIV para garantir que crianças e adolescentes desenvolvam todo seu potencial de crescimento, respeitando sua condição peculiar de uma pessoa em desenvolvimento.  
Assim, este PCDT estabelece diretrizes para remover barreiras do diagnóstico, contribuindo para o início precoce e oportuno do tratamento de crianças e adolescentes vivendo com HIV, com apresentações que melhoram adesão e podem aumentar a retenção no cuidado contínuo de crianças.  
O PCDT abrange desde a instituição do tratamento preemptivo em recém-nascidos expostos, o manejo de TARV inicial e estruturação de esquemas de resgate quando for caracterizada falha terapêutica em crianças até 13 anos de idade. O manejo do tratamento antirretroviral na falha terapêutica em maiores de 13 anos podem ser encontrados no PCDT de TARV em adultos, disponível em: <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts</u>  
Considerando a importância da assistência integral a crianças e adolescentes, este Protocolo destina-se a toda a equipe multiprofissional envolvida no atendimento às pessoas vivendo com HIV (PVHA), à sociedade civil organizada e às próprias pessoas que vivem com HIV ou Aids. Cuidar de suas crianças é um atributo de uma sociedade saudável, considerando os princípios éticos de respeito a mulheres, crianças e de valorização da vida.  
2  
Importância da vigilância epidemiológica da infecção pelo HIV nas crianças e adolescentes no  
Brasil  
Atualmente, a infecção pelo HIV e a aids, em todas as faixas etárias, inclusive em crianças expostas, é de notificação compulsória.  
Todos os casos de HIV ou de aids e de crianças expostas ao HIV **devem ser notificados** por qualquer profissional de saúde ou responsáveis pelos estabelecimentos de saúde, públicos ou privados.  
Entretanto, a subnotificação de casos no Sistema de Informação de Agravos de Notificação (SINAN) traz importantes implicações para a resposta ao HIV/aids na população de crianças e adolescentes, uma vez que permanecem desconhecidas informações como: número de gestantes diagnosticadas com HIV e que receberam tratamento, número total de casos de crianças expostas e de crianças diagnosticadas com HIV ou aids, comportamentos e vulnerabilidades, entre outras.  
A ausência de registro de notificação reflete negativamente na programação orçamentária, comprometendo a racionalização do sistema para o fornecimento contínuo de medicamentos, serviços de laboratório e assistência, bem como, no monitoramento de fatores de risco envolvidos na transmissão vertical do HIV e na morbimortalidade por aids, dentre outras ações de vigilância. A transmissão vertical do HIV é um agravo em eliminação no Brasil.  
O Boletim Epidemiológico de HIV/Aids do atual Departamento de HIV/Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis (DATHI), da Secretaria de Vigilância em Saúde e Ambiente (SVSA), do MS, publicado anualmente, descreve o cenário epidemiológico da infecção, apresentando informações e análises sobre os casos de HIV/aids no Brasil, regiões, estados e capitais, de acordo com os principais indicadores epidemiológicos e operacionais estabelecidos. O Boletim encontrase disponível em: https://www.gov.br/aids/pt-br/centrais-de-conteudo/boletins-epidemiologicos. Além das informações do Boletim Epidemiológico, foi desenvolvida uma funcionalidade _on-line_ com **indicadores** que mostram dados de **HIV/aids** dos 5.570 municípios brasileiros, os quais podem ser visualizados por meio do endereço eletrônico:https://www.gov.br/aids/pt-br/indicadores- <u>epidemiologicos/paineis-de-indicadores-e-dados-basicos.</u>  
As fontes utilizadas para a obtenção dos dados são as notificações compulsórias dos casos de HIV e de aids no Sinan, além de dados obtidos no Sistema de Informações sobre Mortalidade (SIM), do qual são selecionados os óbitos cuja causa básica foi o HIV/aids (CID10: B20 a B24); do Sistema de Informação de Exames Laboratoriais de CD4+/CD8+ e Carga Viral do HIV (SISCEL); e do Sistema de Controle Logístico de Medicamentos (SICLOM), aos quais todos os indivíduos registrados nesses sistemas são relacionados. Algumas variáveis são exclusivas do Sinan, como escolaridade, categoria de exposição e raça/cor da pele e apresentam um elevado percentual de registros ignorados, enfatizando a necessidade de realizar a notificação nesse sistema.  
Atualmente, existe um alerta no SICLOM com o objetivo de informar os profissionais de saúde sobre pessoas vivendo com HIV/aids (PVHA) que não possuem notificação no SINAN. Ressalta-se que **a vinculação da dispensação dos antirretrovirais à notificação do caso não impedirá a entrega dos ARV às PVHA** . A notificação deve ser feita em qualquer fase da vida da criança, e em dois momentos quando do diagnóstico: de infecção pelo HIV e quando preencher algum critério de definição de aids, mesmo que retroativamente, assim que identificada a ausência de notificação. Deverá ser utilizada a Ficha de Notificação e Investigação de HIV/aids específica para a idade da criança no momento do diagnóstico. Para maiores informações sobre a vigilância epidemiológica, consultar o Guia de Vigilância em Saúde 6ª edição, volume 2 (Brasil, 2023), disponível em: <u>https://bvsms.saude.gov.br/bvs/publicacoes/guia_vigilancia_saude_6ed_v3.pdf</u>  
3  
Além dos sistemas apresentados, recomenda-se aos serviços o uso do Sistema de Monitoramento Clínico das Pessoas Vivendo com HIV/aids (SIMC), importante ferramenta de monitoramento de adesão dos pacientes, permitindo a identificação de pacientes em falha terapêutica ou abandono de tratamento.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
O processo de desenvolvimento desse PCDT envolveu a realização de avaliações de revisões sistemáticas (RS) e ensaios clínicos randomizados (ECR) para as sínteses de evidências, que foram adotadas e/ou adaptadas às recomendações de diretrizes já publicadas para as tecnologias que se encontram disponíveis no SUS para o tratamento da hepatite B. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Com a importante redução do número de casos de transmissão vertical no Brasil nos últimos anos<sup>1,2,3</sup> , os profissionais de saúde identificam com mais frequência crianças expostas ao HIV do que crianças com infecção pelo HIV ou com aids.  
Apesar de menos frequente, o risco de transmissão vertical ainda existe, inclusive pelo aleitamento materno, por mulheres previamente diagnosticadas ou que se infectaram pelo HIV durante o período de aleitamento. Ressalta-se que o aleitamento materno por mulheres vivendo com HIV está contraindicado, mesmo quando elas estiverem estáveis, em uso regular de TARV e com carga viral de HIV (CV-HIV) indetectável.  
São descritos três padrões distintos da infecção em crianças, de acordo com a evolução natural da infecção, se não for instituída a TARV<sup>3</sup> :  
1) **“Progressão rápida”** : ocorre em cerca de 20% a 30% das crianças não tratadas, que evoluem com quadros graves no primeiro ano de vida e podem morrer antes dos quatro anos;  
2) **“Progressão normal”:** é mais lenta e abrange a maioria (70% a 80%) dos casos. Nessas crianças, o desenvolvimento dos sintomas se inicia após um ano de idade, com tempo médio de sobrevida de nove a dez anos;  
3) **“Progressão lenta”:** ocorre em uma porcentagem pequena (menos que 5%) dos casos. São crianças que apresentam progressão da infecção considerada lenta, com contagens normais de linfócitos T CD4+ (LT-CD4+).  
O **diagnóstico precoce** em crianças tem grande importância, uma vez que nesta faixa etária, principalmente naquelas infectadas no útero ou durante o parto, ocorre progressão mais rápida da doença. Diferente do que ocorre no adulto infectado pelo HIV, devido à imaturidade imunológica, a evolução da infecção em crianças ocorre rapidamente e com alta CV-HIV<sup>4-5</sup> .  
A suspeita da infecção pelo HIV deve partir do vínculo epidemiológico (exposição ao HIV na gestação, parto ou aleitamento materno) ou ser sempre considerada em crianças de todas as faixas etárias que apresentem as manifestações descritas no **Quadro 1** , independente do diagnóstico materno.  
4  
**Quadro 1:** Principais sinais, sintomas e alterações laboratoriais da infecção pelo HIV em crianças e adolescentes.  
- Infecções recorrentes de vias aéreas superiores, inclusive sinusite ou otite;  
- Linfadenomegalia generalizada, hepatomegalia e/ ou esplenomegalia;  
- Parotidite recorrente;  
- Pneumonias de repetição;  
- Monilíase oral persistente;  
- Diarreia recorrente ou crônica;  
- Déficit ponderal e de estatura;  
- Atraso no desenvolvimento neuropsicomotor;  
- Febre de origem indeterminada;  
- Púrpura trombocitopênica idiopática;  
- Anemia;  
- Linfopenia;  
- Trombocitopenia.  
Fonte: DATHI/SVSA/MS.  
Diante da suspeita clínica, o profissional de saúde deve iniciar, imediatamente, a investigação laboratorial para infecção pelo HIV<sup>6,7</sup> . Além disso, o(a) responsável pela criança ou adolescente deve ser orientado(a) sobre a suspeita da infecção e os passos da investigação, a fim de manter o seguimento até a definição do caso<sup>8,9</sup>  
O diagnóstico precoce da criança infectada por transmissão vertical é essencial para o início da TARV, da profilaxia das infecções oportunistas e do manejo das intercorrências infecciosas e dos distúrbios nutricionais<sup>10,11</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A identificação precoce da criança infectada verticalmente é essencial para o início da TARV, para a profilaxia das infecções oportunistas e para o manejo das intercorrências infecciosas e dos distúrbios nutricionais.  
A passagem transplacentária de anticorpos maternos do tipo IgG anti-HIV, principalmente no terceiro trimestre de gestação, interfere no diagnóstico imunológico da infecção por transmissão vertical. Os anticorpos maternos podem persistir até os 18 meses de idade e, em raros casos, até 24 meses. Portanto, métodos que realizam a detecção de anticorpos não são recomendados para o diagnóstico em crianças com idade inferior ou igual a 18 meses de idade, sendo necessária a realização de testes moleculares (TM), como a quantificação do RNA viral (CV-HIV) e a detecção de DNA pró-viral<sup>12</sup> .  
5  
Em crianças com idade inferior ou igual a 18 meses, o diagnóstico da infecção pelo HIV **não** deve ser realizado pela detecção de anticorpos anti-HIV<sup>4</sup> .  
Para o diagnóstico em crianças com idade inferior ou igual a 18 meses, são disponibilizados os exames de carga viral do HIV e de DNA pró-viral do HIV<sup>13,14</sup> .  
O exame de **DNA pró-viral do HIV** é um teste molecular que utiliza técnicas de amplificação de ácidos nucleicos para detectar a presença de DNA do HIV que se encontra integrado ao genoma das células do hospedeiro.  
No entanto, é importante considerar que os testes moleculares podem ser afetados pela TARV materna, por meio da transferência transplacentária de medicamentos antirretrovirais da gestante para o feto ou por medicamentos antirretrovirais administrados ao bebê como profilaxia ou terapia para a infecção pelo HIV.  
Em relação à **CVHIV, a primeira coleta deve ser realizada imediatamente após o nascimento** . O exame deverá ser coletado por punção periférica, preferencialmente, antes do início da profilaxia com ARV. Não deve ser feita a coleta de material de cordão umbilical. No entanto, **a coleta não deve atrasar a administração dos medicamentos ARV** .  
O **início da profilaxia antirretroviral** , indicada para todas as crianças expostas ao HIV, deve ser realizada ainda na sala de parto, após os cuidados imediatos, de preferência nas **primeiras quatro horas após o nascimento.**  
Para toda **CV-HIV** cujo resultado apresentar-se **detectável** , independentemente do valor de viremia, deverá ser indicada a **coleta imediata para realização de DNA pró-viral (preferencialmente)** **<u>ou para uma nova CV-HIV.</u>** Neste fluxo, com o resultado de **DNA pró-viral** apresentando-se **detectável** **<u>ou</u>** o resultado da **segunda CV-HIV for igual ou superior a 100 cópias/mL,** finaliza-se a investigação diagnóstica e considera-se que houve transmissão vertical do HIV à criança.<sup>15–19</sup>  
Caso o resultado da **segunda CV-HIV seja inferior a 100 cópias/mL** , deverá ser realizada a **coleta imediata de DNA pró-viral** . Caso este apresente-se **detectável** , finaliza-se a investigação diagnóstica, considerando-se que houve transmissão vertical do HIV à criança.  
Caso o resultado da **CV-HIV (primeira ou segunda)** ou do **DNA pró-viral** seja **não detectável,** as crianças deverão continuar em investigação, conforme os períodos recomendados de novas coletas de CV-HIV para definição diagnóstica descritos no **Quadro 2** .  
Quando for identificada criança com CV-HIV detectável, o tratamento preemptivo dessa criança deve ser iniciado imediatamente, a fim de reduzir a morbimortalidade relacionada à aids. O tratamento preemptivo deve ser mantido até a definição diagnóstica.  
Ainda, deve-se atentar para a recomendação de que a **coleta de amostra para o exame de genotipagem do HIV deve realizada no mesmo momento** da coleta para um dos exames complementares, **DNA pró-viral ou segunda CV-HIV,** para otimizar a oportunidade de acesso. No entanto, o exame de genotipagem do HIV somente deverá ser executado pelo laboratório se o resultado de **DNA pró-viral for detectável ou** da **segunda CV-HIV** for **igual ou superior a 100 cópias/mL.**  
Crianças cujo resultado de DNA pró-viral seja não detectável e permaneçam no período de profilaxia ARV após a exposição, por 28 dias, devem permanecer com os três antirretrovirais até completar o prazo recomendado.<sup>18,19</sup> Aquelas que estavam em profilaxia apenas com zidovudina (AZT) e modificaram para o tratamento com três medicamentos ARV devem permanecer com o esquema completo (com os três medicamentos).  
6  
**Quadro 2:** Seguimento laboratorial da criança exposta ao HIV com carga viral CV-HIV.  
|**EXAME**|**QUANDO COLETAR**|
|---|---|
||Ao nascimento|
|CV-HIV|14 dias de vida|
||2 semanas após término da profilaxia (6 semanas de vida)|
||8 semanas após término da profilaxia (12 semanas de vida)|  
Fonte: DATHI/SVSA/MS.  
Quando for identificada uma criança exposta que não coletou a CV-HIV no momento adequado, o exame deverá ser coletado imediatamente. Após esta primeira investigação, conforme as orientações anteriores, as próximas coletas deverão seguir o fluxo e os tempos para cada faixa etária.  
A interpretação dos resultados deve considerar que o uso de ARV, tanto pela mãe quanto pelo recém-nascido, pode diminuir a sensibilidade e retardar a detecção da carga viral pelos exames, principalmente nas crianças em profilaxia com mais de um ARV. Por esse motivo, recomenda-se solicitar o exame de CV-HIV antes de iniciar a profilaxia e, adicionalmente, duas e oito semanas após a suspensão da profilaxia.  
**Assim, a criança será considerada positiva para infecção pelo HIV (status de CVHA) quando apresentar:**  
**Um resultado de carga viral do HIV (CV-HIV) detectável seguido de um exame de DNA pró-viral detectável.**  
**OU**  
**Dois resultados de carga viral do HIV (CV-HIV) detectáveis, sendo o segundo com valor igual ou superior a 100 cópias/mL.**  
Para fins de definição diagnóstica de crianças expostas com idade inferior ou igual a 18 meses, nas quais a investigação de infecção pelo HIV iniciou-se no nascimento; recomenda-se seguir o algoritmo descrito na **Figura 1** .  
7  
<!-- Start of picture text -->
{ Suspelcio de infeceo pelo HIV |<br>ov<br>a<br>; Iniciar ratamento<br>| Nao detectavel | [qualquerDetectavel vator) coinSépreempt chogntecen até<br>ManterConmeera investigacéaude a H{| Definiggo ciinicoaboretorial quanto Fluxo PSpreferencial |H<br>aS | | a0 segundo teste: DNA pré-ial !<br>: (oreferencial) ou CV-HIV i<br>Realzarnova amostraCVHIV com ‘genotipagemColter amestado HIVpara3 i+i CSaie iiH<br>| io cemctive | {_| |, Detectavein e t m | [ {100Dete c opiasimL)tavel i; | Nao detectével (qualquerDetecta v elalon i|}<br>ManterinvestigacSo4 | | Inicartrtamento Iniciar tratamento- H: = iniciari H!<br>conforme idade da | | (confirmacéo Beceem : a etek H<br>ctianca diagnéstica) Gagnéstcaane iH ctanca, {confirmagéoiagnéstcay H |<br>USS oe ba cesecensscnssenssenesenseesseoseseseaseestsssecesseneseneesaed<br>tipficagdo do alelo HLA-B'5701, 2 depender da oportunidade de<br>coletas de exames subsequentes<br><!-- End of picture text -->  
**Figura 1.** Algoritmo de conduta em criança exposta ao HIV com idade inferior ou igual a 18 meses, com investigação de infecção pelo HIV desde o nascimento.  
Fonte: DATHI/SVSA/MS.  
a. A amostra deve ser coletada logo após a CV-HIV detectável, mas o exame somente será realizado após conclusão diagnóstica;  
b. Somente será realizado o exame de genotipagem se o resultado da primeira CV-HIV for superior a 500 cópias/mL.  
c. A decisão clínica deverá considerar que o limite de detecção para a metodologia utilizada no exame de DNA pro-viral é de 300 cópias/mL.  
Obs.: Não postergar o início ou manutenção da terapia antirretroviral até o resultado da genotipagem do HIV.  
Obs.: Atentar para indicar coleta o mais precoce possível de amostra para tipificação do alelo HLA-B*5701, a depender da oportunidade de coletas de exames subsequentes.  
A **exclusão definitiva do diagnóstico de infecção pelo HIV na criança** é baseada na presença de **todos** os seguintes critérios:  
- a) pelo menos duas CV-HIV indetectáveis obtidas após a suspensão da profilaxia antirretroviral.  
- b) boas condições clínicas, bom desenvolvimento neuropsicomotor e sem evidência de déficit imunológico, excluindo-se alterações dessas condições que não possam ser justificadas pela infecção pelo HIV.  
- c) documentação da sororreversão anti-HIV em imunoensaio realizado na criança aos **12 meses de idade** . A sororreversão normalmente ocorre após os 18 meses de idade, no entanto, é possível a documentação a partir de 12 meses. Caso não se observe sororreversão nesta idade, deve-se aguardar até os 18 meses para realização de novo imunoensaio. Caso permaneça o resultado reagente aos 18 meses de idade, realizar nova coleta aos 24 meses.  
8  
**A infecção pelo HIV pode ser excluída presumivelmente** quando a criança não está sendo amamentada, está assintomática e sem evidências clínicas de imunodeficiência, e com pelo menos duas CV-HIV indetectáveis, após o término da profilaxia antirretroviral.  
Neste caso, também pode ser indicada a suspensão do sulfametoxazol + trimetoprima (SMX+TMP), profilaxia primária para _Pneumocystis jiroveci_ , e mantida a investigação para exclusão definitiva do diagnóstico da infecção pelo HIV.  
Na presença de **sinais e sintomas** de infecção pelo HIV ( **Quadro 1** ), mesmo que a mãe não apresente diagnóstico prévio de HIV, a criança deve ser investigada. Nos casos em que a mãe não tem diagnóstico de infecção pelo HIV, deve ser realizado o algoritmo diagnóstico completo da infecção pelo HIV de acordo com as recomendações do Manual Técnico para o Diagnóstico da Infecção pelo HIV (https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuais-tecnicos-para-diagnostico).

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A amamentação é **contraindicada** por mulheres vivendo com HIV, mesmo naquelas com CVHIV indetectável e em uso regular de antirretrovirais.  
Para crianças amamentadas de pessoa fonte vivendo com HIV, seja de PVHA em uso de TARV ou com diagnóstico de infecção recente, após o parto, recomenda-se:  
- **imediata interrupção da amamentação;**  
- realização do exame de **CV-HIV;**  
- início da profilaxia pós-exposição **(PEP)** simultaneamente à investigação diagnóstica;  
- realização da CV-HIV duas e oito semanas após o final da PEP.  
Cabe ressaltar a necessidade de ações de Prevenção Combinada para IST/HIV/hepatites virais para mulheres sem infecção de HIV e que amamentam, para informar sobre a transmissão vertical de HIV pelo leite materno, e realizar orientação centrada na pessoa e suas práticas sexuais.  
Nas crianças expostas nessa condição, caso haja dúvida diagnóstica com o uso da CV-HIV, deve ser utilizado o DNA pró-viral, não devendo ocorrer investigação com sorologia, devido à possibilidade de transferência de anticorpos maternos além da possibilidade através dos exames moleculares, de diagnóstico mais precoce.  
Para mais informações sobre PEP, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição de Risco à Infecção pelo HIV, IST e Hepatites Virais”, disponível em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts.</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Em crianças com idade superior a 18 meses, é esperado que os títulos de anticorpos maternos antiHIV não estejam presentes na circulação. A investigação laboratorial é semelhante à realizada em adultos, com testes diagnósticos anti-HIV, conforme recomendações do Manual Técnico para Diagnóstico da Infecção pelo HIV”, disponível em https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuais-tecnicos- <u>para-diagnostico.</u>  
9

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Deverão ser notificados todos os casos de criança expostas ao HIV, e de infecção pelo HIV e aids, conforme denominações a seguir:  
- **Criança exposta** : criança nascida de mulher vivendo com HIV (exposta ao HIV durante a gestação ou parto), ou que tenha sido amamentada por mulher infectada pelo HIV.  
- **Criança exposta não infectada** : criança exposta ao HIV que apresente resultado negativo da sorologia disponível, coletado após 12 meses.  
É importante, para fins de vigilância epidemiológica, documentar os casos de crianças expostas, independentemente da conclusão final da investigação.  
O encerramento do caso deve ser efetuado de acordo com as orientações contidas na ficha de notificação da criança exposta ao HIV e no fluxograma de investigação diagnóstica deste documento.  
A notificação da criança com infecção pelo HIV deve ser feita após o diagnóstico da infecção, seguindo o fluxograma da figura 1 deste documento técnico.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Deverá ser considerada **criança exposta infectada menor ou igual a 18 meses de idade, quando apresentar:**  
1. Uma carga viral detectável (com qualquer valor) + DNA pró-viral detectável **OU**  
2. 1ª carga viral detectável (com qualquer valor) + 2ª carga viral detectável maior ou igual a 100 cópias/mL.  
Para fins de atualização de fluxo diagnóstico em crianças com idade igual ou inferior a 18 meses de idade, considerar fluxograma do capítulo acima descrito ( **Figura 1** ).  
**<u>Caso suspeito de infecção pelo HIV</u>** deverá ser considerado quando apresentar:  
- 1ª carga viral detectável (com qualquer valor) + 2ª carga viral detectável menor que 100  
- cópias/mL.  
Nesse contexto, deverá seguir com DNA pró-viral como 3º teste para encerramento de investigação diagnóstica (conforme fluxograma do capítulo acima descrito ( **Figura 1** ).  
A notificação da criança e do adolescente com aids deve preencher os critérios de definição de caso:

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
**(Revisão 2013)**  
Evidência laboratorial de infecção pelo HIV em crianças, conforme critérios normatizados pelo Ministério da Saúde de acordo com a idade atual da criança  
**+ (mais)**  
10  
›Presença de, pelo menos, uma doença indicativa de aids de caráter moderado ou grave e/ou contagem de LT-CD4+ menor que a esperada para a idade;  
**E/OU**  
›Contagem de linfócitos T-CD4+ menor do que o esperado para a idade atual da criança.  
Fonte: DATHI/SVSA/MS.  
Os critérios de notificação para os casos de óbito com diagnóstico principal “aids” são:  
**›** Menção de aids/Sida (ou termos equivalentes) em algum dos campos da Declaração de Óbito;  
**OU**  
**›** Menção à infecção pelo HIV (ou termos equivalentes) e de doença indicativa/presuntiva de aids em algum dos campos da Declaração de Óbito, além de doença (s) associada(s) à infecção pelo HIV; **E**  
**›** Investigação epidemiológica inconclusiva.  
Em maiores de 13 anos os critérios de definição de aids seguem conforme identificação em adultos, destacados no PCDT de Manejo da infecção de HIV em adultos, disponível em: <u>https://www.gov.br/aids/ptbr/centrais-de-conteudo/pcdts</u>  
<mark>As fichas de notificação de caso de infecção pelo HIV e de notificação/investigação de aids</mark> devem ser solicitadas à vigilância epidemiológica local ou no site do SINAN: <u>http://portalsinan.saude.gov.br/aids-crianca.</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
<mark>A criança exposta ao HIV deve ser atendida em serviço especializado, com cuidado</mark> compartilhado na unidade de Atenção Primária de referência, pelo menos até a definição de seu diagnóstico.  
As crianças e adolescentes que tiverem o diagnóstico da infecção pelo HIV confirmado permanecem em cuidado compartilhado, ao passo que as expostas ao HIV e não infectadas poderão ser acompanhadas em serviços de Atenção Primária. Recomenda-se que as crianças expostas ao HIV e não infectadas realizem acompanhamento periódico anual com especialista até o final da adolescência, devido à exposição ao HIV e aos ARV.  
As crianças expostas ao HIV e não infectadas tendem a apresentar mais infecções bacterianas e quadros mais graves quando comparadas às crianças sem exposição ao HIV na gestação e parto. A diminuição dos níveis de anticorpos maternos transferidos por via placentária e o não aleitamento por mães com HIV/aids são possíveis razões da diferença entre esses dois grupos<sup>4,20</sup> . Além disso, a exposição _in útero,_ a viremia materna elevada e a contagem de LT-CD4+ baixa, no momento do parto, também estão associados ao risco de infecção, principalmente bacteriana<sup>21</sup> .  
11

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
As orientações para cuidados imediatos com o recém-nascido exposto ao HIV encontram-se nos **Quadros 3** e **4** . Ressalta-se que as recomendações dependem das condições do nascimento do RN.  
**Quadro 3** : Cuidados imediatos com o RN exposto ao HIV na sala de parto e pós=parto imediato.  
|**CUIDADOS NA SALA DE PARTO E PÓS-PARTO IMEDIATO**|
|---|
|1.<br>Sempre que possível, realizar o parto empelicado, com a retirada do neonato mantendo as<br>membranas corioamnióticas íntegras.|
|2.<br>Clampear imediatamente o cordão após o nascimento, sem qualquer ordenha. São reconhecidos<br>os benefícios do clampeamento tardio. No entanto, recomenda-se que:<br>- Mulheres em contexto de replicação viral (CV-HIV desconhecida ou superior a 1000 cópias/mL); ou,<br>ainda, com sintomas de infecção aguda pelo HIV, e/ou déficits de adesão; mantém-se a indicação geral,<br>de clampeamento imediato.<br>- Casos considerados “extra-protocolo” sejam discutidos conjuntamente com especialistas para tomada<br>de decisão.|
|3.<br>Realizar o banho do recém-nascido ainda na sala de parto, preferencialmente com fonte de água<br>corrente, assim que esteja estável.<br>Limpar com compressas macias todo sangue e secreções visíveis no RN.|
|A compressa deve ser utilizada de forma delicada, com cuidado ao limpar as secreções, para não lesar a<br>pele frágil da criança e evitar umapossível contaminação.|
|4.<br>Evitar aspiração de boca,narinas ou vias aéreas e,se for necessária,deve ser cuidadosa.|
|5.<br>Aspirar também o conteúdo gástrico de líquido amniótico, somente se necessário, com sonda<br>oral, evitando traumatismos. Se houver presença de sangue, realizar lavagem gástrica com soro<br>fisiológico.|
|6.<br>Colocar o RN junto à mãe o mais brevemente possível. É recomendado o alojamento conjunto<br>emperíodo integral,com o intuito de fortalecer o vínculo mãe-filho.|
|7.<br>Iniciar a profilaxia para prevenção da transmissão vertical do HIV (PTVHIV) o mais<br>precocemente possível, na sala de parto, logo após os cuidados iniciais, preferencialmente nas primeiras<br>quatro (4) horas após o nascimento, de acordo com a classificação de risco de exposição da criança<br>(**Quadro 5**).|
|8.<br>A coleta da primeira CV-HIV deve ser realizada nas primeiras horas de vida, preferencialmente,<br>antes da primeira dose da profilaxia. No entanto, em nenhuma hipótese, a coleta deve atrasar o início<br>do(s)ARV(s).|
|9.<br>Orientar a não amamentação e inibir a lactação com medicamento (cabergolina).<br>A mãe deve ser orientada a substituir o leite materno por fórmula láctea infantil até, pelo menos, 6 meses<br>de idade<sup>a</sup>.|
|O aleitamento misto também é contraindicado.<br>Pode-se usar leite humano pasteurizado proveniente de banco de leite credenciado pelo MS (p. ex., RN<br>pré-termo ou de baixopeso). Nunca devendo ser realizadapasteurização domiciliar.|
|10.<br>Mesmo em mães com CV-HIV indetectável, se em algum momento do seguimento, a prática<br>de aleitamento materno for identificada, suspendê-lo imediatamente, solicitar exame de CV-HIV para o<br>RN e iniciarprofilaxiapós-exposição(PEP)simultaneamente à investigação diagnóstica<sup>b</sup>.<br>Fonte: DATHI/SVSA/MS.|  
a A Nota Técnica nº 4/2021 CGIST/.DCCI/SVS/MS dispõe sobre a recomendação do medicamento cabergolina 0,5 mg e da fórmula láctea infantil na prevenção da transmissão vertical do HIV e do HTLV.  
b Para mais informações sobre PEP, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição de Risco à Infecção pelo HIV, IST e Hepatites Virais”, disponível em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts</u>  
12  
**Quadro 4** : Cuidados imediatos com o RN exposto ao HIV antes da alta.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
1. É recomendado o alojamento conjunto em período integral, com o intuito de fortalecer o vínculo mãe-filho. 2. Iniciar precocemente, ainda na maternidade ou na primeira consulta ambulatorial, o monitoramento laboratorial em todas as crianças expostas, independentemente de serem ou não prétermo, considerando a possibilidade de eventos adversos aos ARV utilizados pela mãe. 3. É contraindicado o aleitamento cruzado, amamentação da criança por outra nutriz, e o uso de leite humano com pasteurização domiciliar. Orientar a mãe a substituir o leite materno por fórmula láctea infantil até a criança completar 6 meses de idade, pelo menos. <mark>4. Anotar no resumo de alta do RN as informações do pré-natal, as condições do nascimento, os</mark> dados neonatais, o tempo de uso de zidovudina injetável na mãe, o momento do início da profilaxia no RN, o(s) medicamento(s) e dose(s) utilizado(s), a periodicidade e a previsão da data de término, além dos exames realizados, vacinas aplicadas, mensurações antropométricas, tipo de alimento fornecido à criança e outras informações importantes relativas ao parto. Essas informações deverão ser disponibilizadas ao Serviço de Assistência Especializada (SAE) e à Unidade Básica de Saúde (UBS) que acompanharão a criança e a puérpera. É importante registrar no documento de alta qual o SAE e qual as UBS farão este atendimento  
5. A alta da maternidade é acompanhada de consulta agendada em serviço especializado para seguimento de crianças expostas ao HIV e coleta de CV-HIV ou DNA pró-viral com 14 dias de vida. Se o exame de CV-HIV realizado ao nascimento apresentar resultado detectável, recomenda-se coleta imediata de segunda amostra, conforme fluxograma de diagnóstico da infecção pelo HIV em menores de 18 meses. O comparecimento a essa consulta necessita ser monitorado. Em caso de não comparecimento, contatar a puérpera. A data da primeira consulta não deve ser superior a 15 dias a contar do nascimento, idealmente na primeira semana de vida.  
<mark>6. Preencher as fichas de notificação da “Criança Exposta ao HIV” e enviá-las ao núcleo de</mark> vigilância epidemiológica competente.  
7. Atentar para as anotações feitas na Caderneta de Saúde da Criança referentes a dados que remetam à exposição ao HIV, comprometendo o sigilo, uma vez que se trata de um documento comumente manuseado pela família e algumas vezes requerido no trabalho dos progenitores para liberação do salário-família e para frequência à creche.  
Atentar para todas as imunizações recomendadas para o RN.  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Todos os RN expostos ao HIV devem receber profilaxia para PTVHIV com ARV. O esquema recomendado depende da classificação de risco de transmissão vertical do HIV (TVHIV), conforme o **Quadro 5** .  
Crianças com **baixo risco** de transmissão vertical devem receber apenas zidovudina e aquelas com **alto risco** devem receber profilaxia combinada com zidovudina + lamivudina + raltegravir granulado de  
13  
100 mg ( **<u>AZT+3TC+RAL)</u>** , durante **<u>28 dias</u>** <u>. Estudos apontam maior eficácia da profilaxia com esquemas</u> combinados para crianças com alto risco de transmissão<sup>22–27</sup> .  
O uso de raltegravir granulado de 100 mg para solução oral está indicado para recém-nascidos expostos ao HIV a partir de 37 semanas de idade gestacional, até 4 semanas de vida. Portanto, contraindicado em crianças com idade gestacional menor de 37 semanas ao nascimento e para aquelas com peso inferior a 2 kg. Nestes casos, a opção para profilaxia de situações de alto risco e idade gestacional entre 34 e 37 semanas deve ser: zidovudina + lamivudina associada a nevirapina durante **<u>28 dias.</u>** Aquelas crianças com idade gestacional abaixo de 34 semanas deverão realizar a profilaxia apenas com zidovudina durante 28 dias, independentemente do risco de exposição ao HIV.  
Os resultados dos exames realizados para investigação diagnóstica devem ser avaliados o mais breve possível, para avaliar a necessidade ou não de terapia preemptiva ou, no caso de confirmação diagnóstica, de tratamento antirretroviral.  
**Para eficácia da profilaxia, esta deve ser iniciada o mais precocemente possível após o nascimento, preferencialmente até as primeiras quatro horas de vida. A indicação da profilaxia após 48 horas do nascimento deve ser avaliada individualizando o caso**<sup>26,27</sup> .  
Um dos fatores de maior risco para TVHIV é a viremia materna ao longo da gestação e periparto. A infecção materna aguda pelo HIV durante a gestação ou no período do aleitamento também está associada a um maior risco de TVHIV, se comparadas a mulheres com infecção crônica pelo HIV, devido ao pico de CV-HIV e à queda na contagem de LT-CD4+ que ocorrem no momento da infecção primária<sup>26,27</sup> .  
Excepcionalmente, quando a criança não possuir condições de receber o medicamento por via oral (VO), deve ser utilizada a zidovudina injetável, em dose correspondente a 75% da dose por VO, com o mesmo intervalo entre as doses. Se houver indicação da associação de lamivudina e raltegravir, deverá ser avaliada a administração por sonda nasoenteral, pois esses medicamentos se encontram disponíveis apenas em apresentações por VO.  
14  
**Quadro 5:** Indicação de ARV para a profilaxia da transmissão vertical do HIV, de acordo com classificação de exposição de risco e posologias dos ARV para a profilaxia conforme IG.  
|**Risco de**<br>**TV**|**Indicação**|**ARV**|**IG do RN**<br>**(semanas)**|**Posologia**|**Duração**<br>**Total**|
|---|---|---|---|---|---|
||||35 ou mais|4 mg/kg/dose,de 12/12 horas||
|**Baixo**|Uso de TARV na gestação**E**CV-HIV indetectável a partir da|**Zidovudina**|Entre 30 e 35|2 mg/kg/dose de 12/12 horas por 14 dias +<br>3 mg/kg/dose de 12/12 horas apartir do 15º dia;|**4 semanas**|
|**Risco**|28ª semana (3° trimestre)**E**sem falha na adesão à TARV|(VO)|Menos de 30|2 mg/kg/dose, de 12/12 horas;<br>Se for necessário, a dose intravenosa corresponde a<br>75% da dose VO,de 12/12 horas||
||Qualquer uma das condições abaixo:||35 ou mais|4 mg/kg/dose,de 12/12 horas||
||- Pré-natal não realizado;<br>|**Zidovudina**|Entre 30 e 35|2 mg/kg/dose de 12/12 horas por 14 dias +<br>3 mg/kg/dose de 12/12 horas apartir do 15º dia|**4**|
||- TARV não utilizada durante a gestação;<br>- Profilaxia no momento do parto indicada, mas não realizada;<br>- Início da TARV após 2ª metade da gestação;<br>|(VO)|Menos de 30|2 mg/kg/dose, de 12/12 horas;<br>Se for necessário, a dose intravenosa corresponde a<br>75%da dose VO,de 12/12 horas.|**semanas**|
||- Uso de antirretrovirais somente no intraparto;<br>- Infecção materna aguda pelo HIV durante a gestação ou<br>aleitamento;|**Lamivudina**<br>(VO)|34 ou mais|Do nascimento até 4 semanas de vida:<br>2 mg/kg/dose de 12/12 horas.|**4 semanas**|
|**Alto**<br>**Risco**|<br>- Manutenção da CV-HIV detectável no 3º trimestre de gestação;<br>- Carga viral do HIV materna desconhecida;<br>- Diagnóstico materno da infecção pelo HIV realizado no|**Raltegravir**<br>(VO)|37 semanas ou<br>mais<sup>a</sup>|1ª semana: 1,5 mg/kg/dose 1x por dia<sup>B</sup>;<br>A partir da 2ª semana até 4ª semana: 3 mg/kg/dose de<br>12/12 horas.|**4 semanas**|
||<br>momento do parto.|**Nevirapina**<br>(VO)|Entre 34 e 37<br>37 ou mais<br>(alternativa ao<br>raltegravir no<br>alto risco)|1ª semana: 4 mg/kg/dose, de 12/12 horas;<br>A partir da 2ª semana até 4ª semana:<br>6 mg/kg/dose,de 12/12 horas<br>6 mg/kg/dose, de 12/12 horas|**4 semanas**|  
Fonte: DATHI/SVSA/MS.  
IG: idade gestacional ao nascimento; RN: recém-nascido; Terapia Antirretroviral (TARV); Carga Viral do HIV (CV-HIV).  
a O raltegravir não deve ser utilizado em crianças com IG menor de 37 semanas ou peso menor a 2 kg. Em alto risco de exposição ao HIV indica-se raltegravir 100 mg granulado.  
15  
Obs.: Para os RN de IG entre 34 e 37 semanas ou com peso menor a 2 kg, a profilaxia deverá realizada com zidovudina e lamivudina, associada a nevirapina durante 28 dias. Nascimento a 1ª semana de vida: nevirapina 4 mg/kg por dose 2 x por dia. 2ª semana de vida: nevirapina 6 mg/kg por dose 2 x por dia. A dose de 200 mg/m² de superfície corporal só deve ser utilizada para lactentes com infecção confirmada pelo HIV (Apêndice B – Fórmula para cálculo da superfície corpórea em pediatria). b Se a mãe fez uso de raltegravir entre 2 a 24 horas antes do parto, a primeira dose do neonato deve ser postergada até 24 a 48 horas após o parto.  
Obs.: Raltegravir (RAL) 100 mg granulado para suspensão oral deve ser considerado como preferencial em Recém-Nascido (RN) com 37 semanas de idade gestacional obedecendo o seguinte esquema terapêutico: 1ª semana: 1,5 mg/kg 1x por dia; A partir da 2ª semana até a 4ª semana: 3 mg/kg 2 x por dia.  
16  
Ressalta -se que em RN com **idade gestacional inferior a 34 semanas** está indicado **zidovudina como único medicamento ARV** (inclusive na classificação de alto risco).  
Destaca-se que em todos os esquemas ARV profiláticos, independente da IG e dos medicamentos utilizados, recomenda-se **duração de 4 semanas** . As respectivas posologias de acordo com a IG se encontram no **Quadro 5** .  
Ainda, conforme **Quadro 6** , que resume os esquemas ARV recomendados de acordo com IG, em **situações excepcionais** , nas quais não exista possibilidade de indicar raltegravir 100 mg granulado, há a **alternativa de uso da nevirapina suspensão oral** compondo esquemas profiláticos para crianças expostas de alto risco com IG igual ou maior a 37 semanas.  
Em situações excepcionais, para crianças expostas de alto risco nas quais não haja possibilidade de indicar raltegravir granulado 100 mg, a **nevirapina suspensão oral** poderá ser utilizada, conforme **Quadro 6** :  
**Quadro 6** : Esquemas profiláticos da exposição ao HIV indicados de acordo com idade gestacional.  
|**Risco de TV**|**Idade Gestacional**<br>**(semanas)**|**ARV indicados**|
|---|---|---|
|**Baixo risco**<br>Duração**: 4 semanas**|**Qualquer**|Zidovudina|
|**Alto risco**|**≥ 37**|**Opção**<br>**preferencial**:<br>Zidovudina<br>+<br>Lamivudina<br>+<br>Raltegravir<br>**Opção alternativa: **Zidovudina + Lamivudina + Nevirapina|
|Duração**: 4 semanas**|**34 a 37**|Zidovudina + Lamivudina + Nevirapina|
||**< 34**|Zidovudina|  
Recém-nascidos expostos ao HIV que não possam receber zidovudina por via oral devem utilizála por via intravenosa, disponível em apresentação de 10 mg/mL. A dose administrada por via intravenosa corresponde a 75 % da dose da via oral, conforme **Quadro 7** .  
**Quadro 7** : Esquemas de administração de **zidovudina injetável** a serem utilizados na impossibilidade de administração por via oral.  
|**Idade gestacional no**<br>**nascimento**|**Dose de zidovudina (IV)**|**Duração**|
|---|---|---|
|35 semanas ou mais|3 mg/kg de 12/12 horas|4 semanas|
|Entre 30 e 35 semanas|1,5 mg/kg/dose de 12/12 horas nos primeiros 14 dias<br>de vida +<br>2,3 mg/kg/dose de 12/12 horas a partir do 15º dia de<br>vida|4 semanas|
|Menos de 30 semanas|1,5 mg/kg/dose de 12/12 horas|4 semanas|  
Fonte: DATHI/SVSA/MS.  
17

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Os recém-nascidos de mães com teste rápido (TR) reagente para HIV no momento do parto e sem diagnóstico ou com história prévia de uso de TARV são considerados como alto risco para TVHIV e devem receber profilaxia combinada com três antirretrovirais, conforme a idade gestacional de nascimento ( **Quadro 5** ), e não devem ser amamentados até a definição de diagnóstico da mãe.  
Se confirmado o diagnóstico de HIV materno, deve-se seguir todos os procedimentos para PTVHIV. A inibição com cabergolina deve ser realizada somente se o diagnóstico da infecção pelo HIV for confirmado **.**  
Se infecção materna for excluída, a profilaxia deve ser suspensa e o aleitamento pode ser instituído. Em raros casos, o TR pode apresentar resultado “falso-reagente”, em função da presença de aloanticorpos 27,28. O exame de CV-HIV deve ser solicitado para a mãe em casos de suspeita de infecção aguda pelo HIV. Para mais informações, consultar o Manual Técnico para Diagnóstico de Infecção pelo HIV em Adultos e crianças, disponível em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuais-tecnicos-paradiagnostico</u> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Nas gestantes com teste prévio para HIV não reagente e com parceria HIV reagente, caso o resultado do teste da parturiente for reagente no momento do parto, deve-se seguir a conduta do item anterior.  
**Se o resultado do teste para HIV materno for não reagente e a parceria estiver em TARV com CV-HIV indetectável (considerando resultados realizados no período do último trimestre da gestação)** , manter o aleitamento materno e orientar a PTVHIV no pós-parto, enfatizando a importância das medidas de prevenção, como o uso de preservativo e adesão da parceria à TARV, além do uso de Profilaxia Pré-Exposição ao HIV (PrEP)<sup>29,30</sup> .  
Orientar e encaminhar a puérpera para um dos serviços de saúde do Sistema Único de Saúde que ofereçam a PrEP para avaliação de indicação.  
**Se o resultado do teste para HIV for não reagente e a parceria não estiver em TARV e/ou tiver CV-HIV detectável ou desconhecida** , explicar à puérpera o risco de estar em janela imunológica. Coletar a CV-HIV do RN e iniciar imediatamente profilaxia combinada para o RN com zidovudina + lamivudina + raltegravir (AZT+3TC+RAL) ou zidovudina + lamivudina + nevirapina (AZT+3TC+NVP) conforme **Quadro 5** . Também se deve coletar exame de CV-HIV na puérpera, suspender a amamentação temporariamente, até o resultado do teste, mas **<u>não inibir lactação</u>** <u>.</u>  
**Se a CV-HIV materna for detectável** , seguir todos os procedimentos para PTVHIV, incluindo inibição da lactação. **Se a CV-HIV materna for indetectável** , suspender a profilaxia e manter o recémnascido em aleitamento materno, reforçando as medidas de proteção e risco de infecção futura, caso a parceria se mantenha com CV-HIV indetectável. Orientar e encaminhar a puérpera para um dos serviços de saúde do SUS que ofereçam a PrEP para avaliação de indicação<sup>31,32</sup> .  
Para as situações descritas anteriormente no contexto de parcerias sorodiferentes, **o uso da PrEP enquanto durar a amamentação é uma importante medida de prevenção da TVHIV**<sup>31,32</sup> **.** A associação de tenofovir e entricitabina (TDF 300 mg/FTC 200 mg) é segura e eficaz durante a gestação e o aleitamento é seguro, tanto para a mãe quanto para o feto, RN e lactente. Após o aleitamento, o uso da PrEP deve ser discutido e incentivado com a mulher.  
A política brasileira de controle da infeção pelo HIV/aids reconhece a PrEP como uma das estratégias de prevenção combinada do HIV. As parcerias sorodiferentes para HIV, com relato de exposições sexuais sem uso consistente de preservativos, foram identificadas como um dos segmentos prioritários para oferta de  uso da profilaxia, como estratégia da prevenção combinada ao HIV<sup>33,34</sup> . Para  
18  
mais informações, consultar o PCDT para Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV, disponível em https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts<sup>35</sup> <u>.</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A transmissão do HIV pode ocorrer pela ingestão de leite humano contendo o vírus (aleitamento materno ou pela amamentação cruzada).  
Considerando-se que essa via de transmissão contribui substancialmente para a TVHIV, é conveniente realizar o teste na mãe no período da lactação, mesmo com resultados não reagentes para HIV durante o pré-natal e no momento do parto. Deve-se avaliar suas vulnerabilidades e orientar a prevenção após o parto, conforme as medidas da prevenção combinada, reforçando medidas como preservativo e PrEP, reduzindo a possibilidade de infecção da mulher durante o período de amamentação.  
A infecção aguda pelo HIV durante a lactação tem maior risco de infecção da criança devido ao rápido aumento da CV-HIV e queda na contagem de LT-CD4+ materno.  
A mãe deve ser orientada a interromper a amamentação na suspeita ou no diagnóstico de infecção pelo HIV. A inibição da lactação é feita com cabergolina assim que o diagnóstico for confirmado. Deve-se reforçar a contraindicação de amamentação cruzada em qualquer circunstância.  
A inibição farmacológica da lactação deve ser realizada **imediatamente após o parto em puérperas com diagnóstico de infecção pelo HIV** , utilizando-se **cabergolina 1,0 mg via oral, em dose única** (dois comprimidos de 0,5 mg por via oral).  
Código do procedimento hospitalar: 06.03.04.001-2 – cabergolina 0,5 mg (por comprimido).  
Na ocorrência de lactação rebote, fenômeno pouco comum, pode-se realizar uma nova dose do inibidor<sup>36</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A pneumonia por _Pneumocystis jiroveci_ é a mais frequente infecção oportunista (IO) em crianças infectadas pelo HIV. Crianças no primeiro ano de vida representam o grupo de maior risco. A doença pode manifestar-se rapidamente, causando insuficiência respiratória com alta letalidade, o que justifica a indicação de profilaxia primária. Em crianças menores de 12 meses, a contagem de LT-CD4+ não apresenta boa correlação com o risco de doença.  
**Recomenda-se que todas as crianças expostas ao HIV recebam profilaxia com sulfametoxazol + trimetoprima (SMX-TMP) a partir da quarta semana de vida, até que tenham, pelo menos, duas CV-HIV indetectáveis, coletadas com 6 e 12 semanas de vida.**  
**A dose diária recomendada do SMX-TMP para profilaxia primária ao** **_P. jiroveci_ é de 750 mg de SMX/m**<sup>**2**</sup> **/dia, três vezes na semana. A dose pode ser dividida em duas administrações no dia.**  
Para as crianças com diagnóstico pelo HIV confirmado ou enquanto a infecção for indeterminada, **essa profilaxia é mantida até um ano de idade, independentemente da contagem de LT-CD4+.** Para os casos de infecção em investigação, deve-se suspender a profilaxia em caso de conclusão de não infecção. **Após um ano de idade** , a indicação desse medicamento será orientada pela contagem de LT-CD4+, conforme o **Quadro 8** .  
19  
**Quadro 8:** Recomendações para profilaxia primária de _P. jiroveci_ em crianças nascidas de mães infectadas pelo HIV  
|**IDADE**||**RECOMENDAÇÃO**|
|---|---|---|
|**Nascimento a**|**té 4 semanas**|Não indicarprofilaxia|
|**4 semanas a 4**|**meses**|Indicar profilaxia até definição diagnóstica, independente do status<br>de LT-CD4|
|**4 meses a 12**<br><br><br>HIV|**meses:**<br>Criança não infectada<br>Criança infectada pelo<br>ou infecção indeterminada|<br>Não indicar ou suspender profilaxia<br><br>Indicar e manter profilaxia até definição<br>diagnóstica. Para as crianças infectadas, a profilaxia será<br>mantida atépelo menos os 12 meses|
|**Após os 12 me**<br>|**ses:**<br>Criança infectada|-Indicar profilaxia de acordo com a contagem de LT-CD4+.<br>**De 1 a até 6 anos**:<br>Se LT-CD4+ inferior a 500 células/mm<sup>3</sup>ou menor que 22%<br>**Entre 6 e 12 anos**:<br>Se LT-CD4+ inferior a 200 células/mm<sup>3</sup>ou menorque 14%|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
**O acompanhamento das crianças expostas ao HIV deve ser mensal nos primeiros seis meses e, no mínimo bimestral, a partir do 2º semestre de vida.** Em todas as consultas, deve-se registrar o peso, o comprimento/altura e o perímetro cefálico. A avaliação sistemática do crescimento e desenvolvimento é extremamente importante, visto que as crianças infectadas podem, já nos primeiros meses de vida, apresentar déficits. Os gráficos de crescimento e a tabela de desenvolvimento constam na Caderneta de Saúde da Criança do Ministério da Saúde<sup>37</sup> .  
As crianças nascidas de mães infectadas pelo HIV também podem ter maior risco de exposição a outros agentes infecciosos. Entre estes, destacam-se o _Treponema pallidum_ , os vírus das hepatites B e C, o HTLV-1/2, o vírus do herpes simples, o citomegalovírus, _Toxoplasma gondii_ e _Mycobacterium tuberculosis_ . Outros agravos devem ser considerados segundo a prevalência regional (malária, leishmaniose, doença de Chagas, dentre outros). O reconhecimento precoce e o tratamento de possíveis coinfecções devem ser considerados prioritários no atendimento dessas crianças<sup>34,38</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A anamnese deve ser completa com perguntas acerca das condições habituais de vida da criança, alimentação, sono, comportamento e intercorrências infecciosas recentes ou pregressas. Explorar a presença de sinais e sintomas sugestivos de toxicidade mitocondrial, que pode se apresentar como manifestações neurológicas, incluindo encefalopatia, convulsões e retardo do desenvolvimento; sintomas cardíacos devidos a miocardiopatia e disfunção de ventrículo esquerdo; sintomas gastrointestinais atribuíveis à hepatite (esteatose hepática); miopatia, retinopatia, pancreatite e acidose láctica<sup>27,39–41</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A avaliação clínica deve sempre conter o exame físico detalhado e acompanhado da observação dos sinais específicos da infecção pelo HIV: presença de linfonodos, alterações no perímetro cefálico, retardo de crescimento e desenvolvimento, hepatoesplenomegalia, candidíase oral e/ou genital e sinais clínicos de má formação congênita associada ao uso de ARV<sup>27,39–41</sup> .  
20

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Na presença de dados da história clínica, alterações ao exame físico ou achados laboratoriais ou de imagem sugestivos de toxicidade mitocondrial, sugere-se acompanhamento conjunto com outros especialistas, como neuropediatra ou cardiologista infantil.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
O **Quadro 9** elenca os exames laboratoriais para o acompanhamento de crianças expostas, a fim de monitorar efeitos adversos devidos à exposição intrauterina e pós-natal aos ARV, bem como promover diagnóstico precoce das repercussões sistêmicas da infecção pelo HIV<sup>27,39–41</sup> .  
**Quadro 9** : Roteiro para acompanhamento laboratorial de crianças expostas verticalmente ao HIV  
||||**Id**|**ade**|||
|---|---|---|---|---|---|---|
|**Exames**|||||||
||**Nascimento**|**2**<br>**semanas**|**6**<br>**semanas**|**12**<br>**semanas**|**6 - 12**<br>**meses**|**12-18**<br>**meses**|
|CV-HIV<sup>A</sup>|SIM|SIM|SIM|SIM|NA|NA|
|Hemograma|SIM|NA|SIM|SIM|SIM|SIM|
|AST, ALT, GGT, FA,<br>bilirrubinas|SIM|NA|SIM|NA|NA|SIM|
|Glicemia|SIM|NA|SIM|SIM|NA|SIM|
|Sorologia HIV<sup>B</sup>|NA|NA|NA|NA|NA|SIM<sup>C</sup>|
|TORCH<sup>D</sup>|SIM|NA|NA|NA|NA|NA|
|Sífilis (VDRL, RPR)|SIM|NA|NA|NA|NA|NA|
|Anti-HBs<sup>E</sup>|NA|NA|NA|NA|NA|SIM|
|Anti-HTLV 1/2<sup>F</sup>|NA|NA|NA|NA|NA|SIM|
|Sorologia anti-HCV|NA|NA|NA|NA|NA|SIM|
|Sorologia para doença<br>de Chagas<sup>G</sup>|NA|NA|NA|NA|NA|SIM|  
Fonte: DATHI/SVSA/MS  
NA: não aplicável  
Notas:  
A. Crianças com idade inferior a 18 meses e sintomáticas devem ter a coleta de CV-HIV imediata;  
B. Sempre que houver dúvidas em relação ao estado de infecção da mãe em crianças com idade superior a 18 meses (p. ex., crianças abandonadas ou mães sem documentação confiável em relação a seu estado de infecção).  
C. Caso o resultado da sorologia seja positivo ou indeterminado, recomenda-se repetir exame.  
D. Sorologias para toxoplasmose, rubéola, citomegalovírus e herpes simples.  
E. Coletar anti-HBs para verificar soroconversão 30-60 dias após o término de esquema de vacinação. Todas as crianças têm indicação de vacina para HBV.  
21  
F. Para crianças cujas mães têm exame reagente para HTLV-1/2. Caso reagente, encaminhar para serviço especializado.  
G. Indicado para locais em que a doença de Chagas é endêmica, ou caso a mãe seja portadora.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
O efeito adverso hematológico mais comum é a anemia relacionada ao uso de zidovudina (AZT), geralmente com resolução espontânea, entre 3 e 6 meses após a suspensão do medicamento. As alterações hematológicas podem ser mais intensas quando há exposição a esquemas mais complexos e com duração mais longa. O uso de zidovudina também pode acometer outras séries hematológicas, como neutrófilos, linfócitos e plaquetas. A neutropenia e a linfopenia, quando ocorrem, tendem a ser mais prolongadas que a anemia<sup>39</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Devido ao risco potencial de alterações metabólicas relatadas em crianças expostas, em casos raros, o uso crônico de nevirapina foi associado a exantema e hepatite tóxica; porém, esses efeitos adversos não foram observados no uso da profilaxia com zidovudina e nevirapina<sup>22</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
O tratamento adequado das crianças expostas à sífilis e às hepatites B e C, bem como o seguimento laboratorial, deverá ser verificado no “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia da Transmissão Vertical do HIV, Sífilis e Hepatites Virais”<sup>34</sup> , disponível em <u>https://www.gov.br/aids/ptbr/centrais-de-conteudo/pcdts</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A gestante vivendo com HIV deve receber TARV. O benefício do tratamento e supressão viral para a mulher e a criança são superiores aos **raros** riscos descritos.  
É inegável o benefício da PTVHIV com o uso de ARV, uma vez que ele permite prevenir a infecção por HIV do recém-nascido. Porém, alguns efeitos adversos atribuídos ao uso de ARV, seja materno durante a gestação ou na profilaxia ao nascimento, têm sido relatados. Sendo assim, o acompanhamento da criança exposta é importante, mesmo as não infectadas, tanto por exposição ao vírus, quanto aos ARV. Aspectos como os efeitos dos ARV sobre o feto, incluindo o potencial de teratogenicidade e carcinogênese, além da farmacocinética e da toxicidade fetal, devem ser considerados.  
Os recém-nascidos e crianças com suspeita de eventos adversos relacionados ao uso de ARV devem ter o atendimento realizado de forma prioritária, independentemente de serem infectadas ou não pelo HIV.  
Os eventos adversos identificados nessa população devem ser relatados à ANVISA por meio do site: https://www.gov.br/anvisa/pt-br/assuntos/fiscalizacao-emonitoramento/notificacoes/vigimed  
22

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Em 2018, a Organização Mundial da Saúde (OMS) alertou sobre o relato do estudo Tsepamo, em relação à observação de Defeito de Tubo Neural (DTN) em crianças nascidas de mulheres que usaram dolutegravir no período periconcepcional e/ou no 1° trimestre de gestação. Portanto, em função dos achados daquele momento, o estudo aventou uma possível associação entre uso periconcepcional de dolutegravir e ocorrência de DTN, quando comparado com o uso periconcepcional de efavirenz<sup>42,43</sup> .  
Essa coorte foi atualizada em 2020, com a inclusão de mais casos de exposição periconcepcional. Já não houve mais diferença na ocorrência de DTN em gestantes que conceberam com esquemas de TARV contendo dolutegravir quando comparadas às gestantes com esquemas de TARV sem dolutegravir<sup>38</sup> . A análise foi realizada pela Coorte Nacional de estudo do dolutegravir com mulheres vivendo com HIV e que engravidaram em uso de TARV, entre janeiro de 2015 a maio de 2018. Do total de 1.468 mulheres, 382 em uso de dolutegravir e 1.086 em uso de raltegravir ou efavirenz não foram identificados DTN.  
Essas atualizações<sup>44–46</sup> possibilitaram a recomendação de dolutegravir para mulheres em idade fértil, com desejo gestacional, e para gestantes. As especificações para tal decisão estão descritas na Nota Informativa<sup>47</sup>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A infecção pelo HIV esteve associada à maior taxa de partos prematuros e baixo peso ao nascer na era pré-antirretroviral. O advento da TARV para PTVHIV mostrou associação entre o uso de esquemas com três medicamentos e o aumento na prematuridade e baixo peso ao nascer<sup>44–46</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
O uso dos inibidores da transcriptase reversa análogos de nucleosídeo (ITRN) pode causar certo grau de disfunção mitocondrial e as manifestações clínicas dependem do órgão afetado. Convulsões, retardo mental e alterações cardíacas já foram descritas. Aumento transitório do lactato sérico também pode ocorrer, embora não se saiba ao certo o significado clínico. Apesar da disfunção mitocondrial ser considerada uma questão controversa, recomenda-se, devido à sua gravidade, o seguimento em longo prazo das crianças expostas aos ARV<sup>27,39,48</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
As alterações cardíacas relacionadas à exposição aos ARV variam desde miocardiopatia assintomática até quadros de insuficiência cardíaca grave e parece estar mais associado à exposição materna precoce aos ARV, desde o 1º trimestre<sup>49–51</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A presença de tumores malignos em crianças expostas a ARV não difere significativamente da população em geral<sup>27,39,52,53</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Estudos envolvendo recém-nascidos expostos à ARV intraútero demonstram que os níveis de insulina foram inferiores aos do grupo controle. Contudo, não se verificou diferença quanto à glicemia neonatal. Esses resultados podem ser explicados porque alguns ARV estão relacionados à diminuição de  
23  
tolerância à glicose, consequente da secreção e/ou ação diminuída da insulina ou pelo efeito tóxico direto desses agentes sobre as células betapancreáticas.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Dados de vários estudos, tanto em países desenvolvidos como em desenvolvimento, sugerem que as crianças expostas ao HIV e não infectadas têm risco acrescido de infecção grave e maior morbimortalidade, comparadas a crianças não expostas ao HIV, principalmente no primeiro ano de vida 4,20,21,54–57. A maior suscetibilidade a infecções e a evolução para doença grave e ameaçadora à vida pode, em parte, ser explicada por um sistema imunológico potencialmente deficiente. A redução da transferência de anticorpos maternos para os filhos de mães vivendo com HIV tem sido documentada, principalmente em mulheres com CV-HIV elevada<sup>21,56,58–61</sup> .  
Além disso, nesse cenário, há o ambiente intrauterino com ativação imune pró-inflamatória, o que poderia predispor à apoptose linfocitária e imunossenescência no lactente. As infecções mais comumente relatadas são causadas por bactérias encapsuladas, o que sugere resposta imune humoral menos efetiva, embora a imunidade celular também esteja comprometida<sup>56,57,60–62</sup> . As hospitalizações são causadas principalmente por gastroenterite, sepse, meningite e pneumonia e são mais comuns nos lactentes de mães HIV vivendo com HIV com CV-HIV detectável no momento do parto<sup>56,57,60–62</sup> . O número de hospitalizações também costuma ser maior nesses lactentes.  
A etiologia dessas alterações é multifatorial e está relacionada à exposição intraútero ao HIV, aos ARV e à exposição ambiental a patógenos comumente presentes em contato intradomiciliar, além da redução da proteção de anticorpos maternos pela inexistência do aleitamento<sup>56,57,60–62</sup> .  
Assim, é importante salientar que, apesar de não infectados por HIV, esses lactentes são afetados tanto pelo vírus como pelo tratamento ao longo da gestação e das primeiras semanas de vida, assim como pelo meio ambiente onde vivem, podendo apresentar maior suscetibilidade a infecções.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Dados do estudo _Surveillance Monitoring for ART Toxicities_ (SMARTT)<sup>63</sup> evidenciam que crianças que nasceram de mães expostas ao efavirenz durante a gestação, apresentam maior probabilidade (aproximadamente 2,5 vezes) de apresentar microcefalia.  
Além da microcefalia, à exposição ao efavirenz está relacionada ao atraso no desenvolvimento neuropsicomotor das crianças.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Os avanços no protocolo de PTVHIV associado ao sucesso na instituição e cumprimento deste, além do incentivo aos cuidados com a saúde e garantia aos direitos sexuais e reprodutivos da população que vive com HIV colaboraram para a grande elevação do número de gestações nessa população e expressivo crescimento do número de crianças expostas não infectadas pelo HIV (ENI), não apenas no Brasil, mas em todo o mundo.  
Em 2018 a UNAIDS estimou cerca de 14,8 milhões de ENI em todo o mundo<sup>64.</sup> Trata-se de uma população global em franca expansão, considerando que, em 2000, representavam 6,7 milhões de crianças.  
Apesar da maioria das crianças estar crescendo e desenvolvendo-se bem, sabemos que as ENI são submetidas a múltiplas exposições em fases muito precoces na vida, entre elas ao HIV e ARVs, a um ambiente intraútero imunologicamente perturbado, a potencial doença física e, algumas vezes, psíquica materna, à exposição amplificada a patógenos infecciosos, estando inseridas, não raras vezes, em um contexto com circunstâncias socioeconômicas desafiadoras e uma nutrição infantil abaixo do ideal<sup>64</sup> .  
24  
Todas essas adversidades podem trazer risco acrescido às ENI, o que vem sendo demonstrado em estudos que se iniciaram desde a década de 90, impondo ao sistema e aos profissionais de saúde que se adote um olhar diferenciado a esse grupo. Esse cenário possibilita que o mapeamento, pesquisas e políticas de saúde sejam implementados para garantir o pleno desenvolvimento dessas crianças com uma boa qualidade de vida.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Vários estudos descrevem risco de morbimortalidade maior em ENI quando comparadas com crianças não expostas e não infectadas ao HIV (NENI). As primeiras descrições foram realizadas no início da década de 90, em países de baixa renda, mostrando maior incidência de diarreia aguda e sarampo, com risco acrescido de evolução para óbito em ENI<sup>65,66</sup> .  
Com os anos, a assistência à saúde dessas crianças melhorou. No entanto, o risco de adoecimento e óbito se manteve em locais com esse perfil, principalmente aquele relacionado a doenças respiratórias (incluindo as virais por influenza e parainfluenza), com maiores taxas de hospitalização, internações em unidades de terapia intensiva, falhas de tratamento.  
Alguns possíveis fatores de risco para essa evolução foram identificados, tais como: prematuridade, baixo peso ao nascer, idade menor de 2 anos (possibilidade maior de adoecimento e risco de desfecho desfavorável), baixa renda familiar, presença de doença avançada, imunodepressão materna com dosagem de LT-CD4+ baixo e introdução tardia do ARV para gestante<sup>64,67–69</sup> .  
Em países de alta renda, resultados de estudos apontam aumento do risco de adoecimento das ENI, porém sem elevação das taxas de óbito<sup>70</sup> . O risco de doença pneumocócica invasiva, sepse por estreptococo do grupo B, pneumonia e diarreia aguda se mostra superior entre ENI, a depender da idade considerada<sup>70–</sup> 72.  
Estudo conduzido em países de baixa e alta renda reafirmou o risco elevado de hospitalização durante o primeiro ano de vida entre os ENI, quando comparados com os NENI, sendo reforçado que o momento de introdução do ARV materno foi fator de grande interferência nesse desfecho. Em gestantes que iniciaram ARV durante a gestação, as ENI tiveram 4 vezes mais risco de hospitalização, do que os NENI. A introdução do ARV anterior a gestação pode ser bastante impactante na redução do risco de hospitalização das ENI por quadros infecciosos. As alterações imunológicas em ambiente fetal são muito mais intensas na introdução tardia do ARV, interferindo diretamente no risco de hospitalização infantil<sup>73</sup> .  
As razões para esse risco acrescido de infecções ou mesmo para pior evolução são ainda incertas. A infecção materna crônica pelo HIV pode promover alterações que incluem inflamação placentária com redução da transferência de anticorpos maternos, induzindo alterações da resposta da imunidade inata da criança exposta ao HIV. Avaliações específicas nas ENI mostram alteração na maturação e resposta prejudicada de células T (CD4 e CD8), alteração do tamanho do timo, neutropenia frequente, assim como aumento da produção de citocinas, especialmente nas primeiras semanas de vida.  
A associação da carga viral materna no momento do parto com a imunidade fetal e infantil parece existir. Mães com carga viral superiores a 1000 cópias/mL, apresentam chance maior de imunodepressão, o que pode afetar o desenvolvimento do sistema imunológico da criança.  
Com relação à resposta vacinal, essa parece normal nas ENI. Mais estudos sobre a imunidade de ENI, assim como sobre a resposta vacinal, são necessários, para melhor compreensão das possíveis alterações<sup>74–76</sup> .  
Meta-análises e revisões sistemáticas envolvendo o tema mostraram resultados concordantes com os estudos acima descritos, porém concluem que as pesquisas realizadas são bastante heterogêneas, sendo necessários estudos adicionais para melhor elucidação sobre o tema<sup>72,77–80</sup> . A interferência da ausência do aleitamento materno, na gênese da elevada morbimortalidade das ENI também não conseguiu ser determinada.  
25

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Alterações cardíacas, incluindo miocardiopatia, são possíveis em crianças que vivem com HIV/aids e em ENI. Entre os ENI, há achados de redução da dimensão e massa do ventrículo esquerdo e parede septal, além de alterações de contratilidade diastólica nos primeiros dois anos de vida<sup>81</sup> . Estudos prosseguiram com avaliações até os quatro anos, mostrando que ENI expostos ao ARV intraútero apresentavam índices ecocardiográficos significativamente diferentes quando comparados com NENI, tendo em parcela considerável dos casos, sintomas subclínicos, porém significativos<sup>82</sup> .  
Estudo de coorte prospectivo conduzido em Barcelona encontrou as mesmas alterações em crianças aos 6 meses de vida, além de níveis significativamente mais elevados de pressão arterial, com 50% das ENI preenchendo critérios para hipertensão _versus_ 3,7% nas NENI, havendo portanto um comprometimento cardíaco subclínico associado a hipertensão nos ENI nessa idade, podendo elevar o risco cardiovascular a longo prazo<sup>83</sup> .  
Pesquisa conduzida pelo _Pediatric HIV/AIDS Cohort Study_ (PHACS), incluindo pacientes ENI maiores de 6 anos reunidos de vários centros dos Estados Unidos, corroborou tais achados. Todos os estudos descritos sugeriram que o monitoramento contínuo desses pacientes, inclusive com acompanhamento ecocardiográfico seriado entre os ENI, seria importante visando ao diagnóstico precoce de tais alterações. A condução de estudos adicionais mais robustos para melhor elucidar essas alterações, além de seguimento dos pacientes até idade adulta, possibilitando a avaliação da relevância de tais achados na vida adulta, também são considerados importantes<sup>82,84</sup> .  
O estudo PHACS SMARTT mostrou que ENI apresentavam peso acima da média quando comparadas com NENI, podendo acarretar risco cardiometabólico a longo prazo para aquele grupo. O mesmo estudo detectou maior incidência de obesidade na adolescência dos ENI, com maior risco para hipertensão arterial. A avaliação da repercussão de tais achados na vida adulta ainda precisa ser realizada 80,85.  
Avaliações de crescimento de ENI mostraram piores evoluções de estatura, com maiores possibilidades de baixa estatura entre essa população. Muitos desses estudos observacionais foram realizados em países de baixa renda, onde havia alta cobertura de ARV entre as gestantes, com a grande maioria das crianças em regime de aleitamento materno<sup>86</sup> . Quando replicados os estudos em países de alta renda, nem sempre foi possível a mesma observação<sup>80</sup> . Revisão bibliográfica das principais referências sobre o tema propõe que as ENI são atingidas de forma direta e indireta por uma série de fatores de risco universais, incluindo questões ambientais (como saneamento, alimentação entre outras), determinantes socioeconômicos e familiares, exposições intrautero a agentes infecciosos e toxinas (álcool e drogas), intercorrências neonatais (entre elas, a prematuridade), doença ou óbito materno, além da própria exposição ao HIV e ARV, podendo resultar em um crescimento e neurodesenvolvimento prejudicado das ENI<sup>87</sup> . Estudos mais conclusivos são necessários.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Crescimento e neurodesenvolvimento alterados repercutem de forma direta com a qualidade de vida e oportunidades futuras das crianças. A literatura relata a possibilidade de interferência no neurodesenvolvimento exercida pela exposição ao HIV ou aos ARV. As alterações descritas normalmente são mais sutis que as apresentadas por crianças infectadas, podendo atingir áreas de linguagem, cognição, motora e comportamento. Muitos desses estudos foram realizados em países de baixa e média renda, onde outros fatores já descritos acima (socioeconômicos, alimentares, familiares e outras adversidades) podem influenciar no neurodesenvolvimento<sup>87</sup> .  
A infecção materna pelo HIV e a CV-HIV apresentada na gestação desencadeiam desregulação imunológica, tanto materna quando na criança até 2 anos. Alterações imunológicas podem repercutir  
26  
diretamente no desenvolvimento neuropsicomotor da criança, especialmente em aspectos motores<sup>88</sup> . Volumes reduzidos de substância cinzenta total e caudada cerebral foram encontradas em lactentes ENI em comparação com NENI nas primeiras semanas de vida, sendo essa alteração relacionada à imunossupressão materna<sup>89</sup> .  
Estudo comparativo entre ENI e NENI abordando desempenho acadêmico precoce mostrou que ENI obtinham pontuações significativamente mais baixas de habilidades intelectuais, leitura e matemática durante a primeira infância, ressaltando a importância de abordagem precoce dessas questões para otimizar o aprendizado dessa população<sup>90</sup> .  
Meta-análise e revisão sistemática com esse foco de avaliação evidenciou que as ENI possuem risco de deficiências sutis na linguagem expressiva e no desenvolvimento motor grosso aos 2 anos de idade, não sendo encontrada relação com os esquemas ARV utilizados pela mãe. Concluiu-se que grandes estudos longitudinais de alta qualidade são necessários com essa temática<sup>91</sup> , já que não existe ainda um consenso da literatura sobre esses aspectos. Há uma grande heterogeneidade de estudos e populações. Uma parcela das pesquisas que discorrem sobre a ausência de prejuízo de neurodesenvolvimento salientam que parte dessas alterações poderiam se manifestar apenas no futuro, especialmente na adolescência ou idade adulta. Isso reforça a necessidade de pesquisas a longo prazo para conclusão definitiva, considerando que diversos fatores, especialmente ambientais, de estimulação e oportunidades de vida, podem interferir nesses desfechos, fazendo com que esses estudos se tornem de difícil realização.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Os ARV da classe dos ITRN são relacionados à possibilidade de indução de disfunção mitocondrial, podendo causar alteração dos níveis de DNA mitocondrial em recém-nascidos expostos intraútero a esses medicamentos, sendo desconhecido o quão relevantes clinicamente podem ser essas anormalidades.  
A coorte da _French Perinatal StudyGroup_ descreve a possibilidade, em raros casos, de convulsões, atrasos cognitivos e motores, alterações de exames de imagem de sistema nervoso central, hiperlactatemia, disfunção cardíaca e mesmo óbito relacionado à toxicidade mitocondrial, podendo ser essa possibilidade considerada frente a ENI com achados clínicos de etiologia desconhecida, especialmente cardíacos e neurológicos<sup>80</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Por vários anos houve o receio de risco maior de câncer em ENI devido à exposição aos ARV na gestação. Os estudos mostraram que o número de casos em ENI não diferiu significativamente do encontrado na população geral, porém sugere-se que haja uma vigilância clínica contínua para avaliarmos esse risco potencial na idade adulta<sup>81</sup> . Estudo recém-publicado, usando registros do Departamento de Saúde dos Estados Unidos, evidenciou que o risco de tumores cerebrais em ENI foi limítrofe superior ao esperado na população geral, não sendo mostrado risco elevado para leucemia e outros tipos de câncer. Estudo concluiu que mais pesquisas são necessárias para conclusões definitivas<sup>92</sup> .  
Revisão sistemática sobre a possibilidade de transtornos psiquiátricos em ENI mostrou que esse grupo apresentou maior prevalência em relação aos NENI, indicando que fatores como estresse psicossocial, situação socioeconômica e estigma contribuem para a elevação do risco de alterações de saúde mental em ENI<sup>93</sup> . Quando comparados ENI na adolescência com jovens que vivem com HIV, notou-se que a incidência de transtornos psiquiátricos, especialmente de humor, ansiedade, comportamento e uso de substâncias, foi bem próxima<sup>94</sup> .  
Pesquisas mostram altas taxas de transtornos psiquiátricos entre crianças e especialmente entre adultos jovens, com antecedentes de terem sido ENI, com maiores incidências de uso de substâncias,  
27  
estresse relacionado com estigma e medo sobre a doença materna e risco de mortalidade da mãe, transtorno de ansiedade e depressão, risco de suicídio. Muitas vezes, há relação de tais quadros com falta de emprego ou matrícula escolar, vulnerabilidade, inclusive na vivência da sexualidade, falta de moradia e risco de encarceramento. As pesquisas apontam também, que apesar dos achados demonstrarem altas taxas de diagnósticos e sintomas psiquiátricos nos jovens previamente expostos e não infectados pelo HIV, estes têm menor probabilidade do que seus pares que vivem com HIV por transmissão vertical, em receber tratamento de saúde mental.  
A saúde mental em crianças e adolescentes expostos, mas não infectados pelo HIV, pode ser afetada por diversos fatores relacionados à sua situação familiar e social. Embora eles não tenham o vírus, podem enfrentar desafios emocionais e psicológicos significativos, entre eles estigma, discriminação, medo, ansiedade, luto, alterações no cuidado e suporte familiar e o segredo e silêncio vivenciado dentro da família. Mais pesquisas comparando ENI com NENI e pessoas que vivem com HIV, ajustadas para possíveis fatores de confusão que podem interferir nas conclusões, são necessárias.  
Já as perdas auditivas parecem ser mais prováveis estatisticamente em CVHIV e ENI quando comparadas com NENI. Fatores causadores de tais alterações ainda são desconhecidos. Observação auditiva mais rigorosa é desejável nesse grupo, assim como novos estudos que elucidem melhor a questão 95.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
Todas as ENI devem realizar acompanhamento compartilhado no serviço especializado em HIV/aids e atenção básica desde o nascimento até sua conclusão diagnóstica da exposição ao HIV, com negativação da sorologia anti-HIV.  
Após esse momento, seu acompanhamento de rotina passará a ser realizado apenas na unidade básica de saúde, sendo indicado que ela mantenha consultas anuais de seguimento a longo prazo até o final da adolescência com o serviço especializado em HIV/aids, com objetivo de monitorar o surgimento de intercorrências consequentes à exposição ao HIV e aos ARV.  
No momento da transferência do cuidado de rotina para a unidade básica de saúde, é importante que a família ou cuidador receba um resumo de alta, com informações fundamentais sobre o seguimento.  
Recomenda-se ainda que seja enviada cópia dos últimos exames realizados e, se possível, o número da notificação de criança exposta ao HIV no Sinan.  
Deve-se orientar a família/cuidadores que a entrega da documentação na unidade básica que fará o seguimento da criança é aconselhável. Em decorrência das questões relacionadas ao segredo familiar do diagnóstico, estigma e preconceito, grande parte das famílias/cuidadores não expõe seu diagnóstico e nem mesmo a documentação enviada para a equipe que dará continuidade do cuidado. Por isso, deve-se sensibilizar a família/cuidadores a, sempre que possível, informar o profissional responsável pelo seguimento, para que esse, munido dos dados, possa realizar o acompanhamento, monitorando possíveis alterações.  
Sempre que possível, deve-se estimular a família/cuidadores que revelem à criança/adolescente, em idade adequada para a compreensão e manejo da informação, a situação de exposição prévia ao HIV, assim como seu histórico de seguimento. O segredo em torno do assunto foi relacionado por alguns autores como uma das possíveis origens de transtornos psiquiátricos neste grupo.  
Embora existam poucos estudos específicos sobre a revelação diagnóstica em ENI, algumas referências podem fornecer informações relevantes a respeito do tema<sup>96,97</sup> .  
As intervenções relacionadas à **revelação diagnóstica devem ser estendidas as ENI** . Considerase muito importante que esses pacientes possam compreender como ocorreu seu desenvolvimento físico e psicoafetivo nos seus primeiros anos de vida, e ao caminhar para vida adulta, podendo se apropriar do conhecimento dos riscos inerentes a essa condição. Essa revelação é também desafiadora, já que a grande  
28  
maioria dos filhos desconhece o diagnóstico dos pais, devendo ser estimulada, inclusive, como possibilidade de fortalecimento de laços entre pais e filhos, favorecendo a comunicação, melhoria das relações familiares e compreensão da situação dos pais<sup>96,97</sup> .  
Durante o seguimento a longo prazo é fundamental realizar sempre anamnese e exame físico completo, questionando sobre intercorrências clínicas no período e monitorando de forma mais cautelosa a evolução nutricional, especialmente peso e estatura, desenvolvimento neuropsicomotor e saúde mental. Deve-se solicitar avaliação laboratorial de monitoramento (hemograma, transaminases, glicemia, lactato), direcionando a investigação diagnóstica com outros exames complementares a depender da situação clínica do paciente. Sempre que possível, deve-se solicitar ecocardiograma para investigação de alterações cardíacas relacionadas à exposição ao HIV. Ainda, também deve-se encaminhar o paciente para avaliação por outros especialistas, a depender dos achados clínicos.  
Com relação à imunização, as ENI devem receber as vacinas recomendadas para CVHIV até os 18 meses, passando, após esse período, a seguir o esquema vacinal básico da criança e adolescente recomendado pelo PNI, incluindo-se apenas a vacina contra poliomielite inativada em todo o esquema.  
É imprescindível promover ações de educação em saúde direcionadas aos profissionais que atuam no cuidado de crianças e adolescentes nas unidades de saúde básica. O objetivo é capacitá-los para reconhecer possíveis alterações no desenvolvimento infantil, permitindo assim um monitoramento mais atento e cuidadoso dos pacientes.  
Deve-se reforçar ainda com esses profissionais a importância da garantia do sigilo para as famílias/cuidadores, o que, quando respeitado, facilita muito a adesão ao acompanhamento.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A população de ENI representa um grande desafio para a equipe multiprofissional, necessitando de estruturação e desenvolvimento de políticas de saúde para acolher as suas demandas, com integração entre atenção primária e serviços especializados em HIV/aids, para assegurar não apenas os cuidados à saúde, mas também o combate ao estigma e preconceito enfrentado por estas famílias. O uso universal de ARV para pessoas que vivem com HIV visa à equidade de expectativa e qualidade de vida entre pessoas que vivem ou não com HIV, Entre crianças e adolescentes que vivem com HIV, ENI ou NENI deve haver a mesma equidade de cuidado e atenção, respeitando as particularidades e necessidades de cada grupo. Investimentos globais e estudos mais robustos são necessários para elucidar melhor todos os fatores ligados as ENI.  
Destaca-se a necessidade do desenvolvimento de intervenções e políticas públicas específicas para essa população invisibilizada e altamente vulnerável.  
Salienta-se que os achados apresentados nos estudos não devem desestimular os profissionais a incentivarem as gestações dentro das famílias que vivem com HIV, mas sim, trazer subsídios para uma melhor observação e assistência às crianças e aos adolescentes durante o seguimento, inclusive alertando a rede de apoio a esse cuidado.  
Deve-se melhorar a saúde materna, antes mesmo da gestação, com diagnóstico precoce da infecção pelo HIV e instituição de TARV precocemente, atingindo e mantendo a carga viral indetectável. Ainda, deve-se possibilitar sua recuperação imunológica, a qual exerce influência marcante não apenas no risco de transmissão vertical do HIV, mas também na evolução das ENI a longo prazo.  
A assistência materna deverá estar associada ao cuidado integral à saúde da criança e adolescente. Além do HIV e ARV, as ENI são submetidas a outras exposições multifatoriais ( **Figura 2** ), o que pode restringir seus resultados ao explorar e aproveitar suas potencialidades. Assim, devem ser implementadas medidas de intervenção para cada um desses fatores ao estruturar o cuidado global a esse grupo. O conjunto dessas ações colaborará para que as ENI atinjam todo seu potencial de crescimento e desenvolvimento com qualidade de vida<sup>98,99</sup> .  
29  
<!-- Start of picture text -->
Exposi¢ao perinatal ao HIV<br>Desigualdade >~_ pike: wo de<br>social by <* Exposigao perinatal<br>/ \ aos ARV<br>s \\ nil intectadas /<br>Exposi¢éo a ee % Intercorréncias<br>patégenos goa Ke neonatais ena<br>/ ms infancia<br>Morbimortalidade @ asusénciade<br>qatar Anmentartoinadequada (EC) seamesi=materno<br><!-- End of picture text -->  
**Figura 2.** Exposições multifatoriais das crianças expostas não infectadas pelo HIV.  
Adaptado de _It is a question of equity: time to talk about children who are HIV-exposed and “HIV-_  
_free_ ”<sup>98</sup>  
Nota: ARV e HIV em vermelho indicam riscos específicos desse grupo de ENI. Os demais riscos, em preto, indicam fatores de risco universais. Desigualdade social inclui estigma, exclusão social, dificuldades financeiras e outras adversidades que podem ser mais frequentes nas famílias que vivem com HIV<sup>98</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
1. Saúde M DA. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Ações Programáticas Estratégicas. Política Nacional de Atenção Integral à Saúde da Criança : orientações para implementação / Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Ações Programáticas Estratégicas. – Brasília : Ministério da Saúde, 2018. Accessed November 30, 2023. https://portaldeboaspraticas.iff.fiocruz.br/wp-content/uploads/2018/07/Pol%C3%ADtica-Nacional-deAten%C3%A7%C3%A3o-Integral-%C3%A0-Sa%C3%BAde-da-Crian%C3%A7a-PNAISCVers%C3%A3o-Eletr%C3%B4nica.pdf  
2. United Nations. OBJETIVOS DE DESENVOLVIMENTO SUSTENTÁVEL (ODS). Published 2014. Accessed August 22, 2023. https://www.pactoglobal.org.br/ods#:~:text=Os%20ODS%20buscam%20assegurar%20os,maiores%20de safios%20de%20nossos%20tempos.  
3. Aldrovandi NHT and GM. Immunology of Pediatric HIV Infection. _Immunol Rev_ . 2014;254(1):143-169. doi:doi:10.1111/imr.12074.  
4. Aldrovandi NHT and GM. Immunology of Pediatric HIV Infection. _Immunol Rev_ . 2014;254(1):143-169. doi:doi:10.1111/imr.12074.  
5. Newell M louise, Coovadia H, Cortina-borja M, Rollins N, Gaillard P, Dabis F. Mortality of infected and uninfected infants born to HIV-infected mothers in Africa : a pooled analysis. 2004;364:12361243.  
6. Mugauri H, Mugurungi O, Chadambuka A, et al. Early Infant Diagnosis Sample Management in Mashonaland West Province , Zimbabwe , 2017. _AIDS Res Treat_ . 2018;2018. doi:10.1155/2018/4234256  
30  
7. Celletti F, Sherman G, Mazanderani AH. Early infant diagnosis of HIV. _Curr Opin HIV AIDS_ . 2017;12(2):112-116. doi:10.1097/COH.0000000000000343  
8. Kiyaga C, Narayan V, McConnell I, et al. Retention outcomes and drivers of loss among HIVexposed and infected infants in Uganda: a retrospective cohort study. _BMC Infect Dis_ . 2018;18(1):416. doi:10.1186/s12879-018-3275-6  
9. World Health Organisation. HIV TESTING IN YOUNG CHILDREN.  
10. Brice J, Sylla M, Sayon S, et al. Qualitative and quantitative HIV antibodies and viral reservoir size characterization in vertically infected children with virological suppression. _Journal of Antimicrobial Chemotherapy_ . 2017;72(4):1147-1151. doi:10.1093/jac/dkw537  
11. Malik S, White V, Sundaram S, Humphreys K, Patel R, Samraj S. ‘Don’t forget the children’ – test before it is too late. _Int J STD AIDS_ . 2017;28(2):192-195. doi:10.1177/0956462416676623  
12. Goulder PJ, Lewin SR, Leitman EM. PAEDIATRIC HIV INFECTION: THE POTENTIAL FOR CURE. _Nat Rev Immunol_ . 2016;16(4):259. doi:10.1038/NRI.2016.19  
13. Working Group on Antiretroviral Therapy and Medical Management of HIV-Infected Children. Guidelines for the use of antiretroviral agents in pediatric HIV infection, January 7, 2000. HIV clinical trials. doi:10.3205/zma001094  
14. Bernard M. B, S. Michele O, Laura G. W, et al. _Laboratory Testing for the Diagnosis of HIV Infection : Updated Recommendations_ .; 2014. doi:10.15620/cdc.23447  
15. Ajibola G, Maswabi K, Hughes MD, et al. Brief Report: Long-Term Clinical, Immunologic, and Virologic Outcomes Among Early-Treated Children With HIV in Botswana: A Nonrandomized Controlled Clinical Trial. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2023;92(5):393-398. doi:10.1097/QAI.0000000000003147  
16. Kuhn L, Paximadis M, Da Costa Dias B, et al. Predictors of Cell-Associated Human Immunodeficiency Virus (HIV)-1 DNA Over 1 Year in Very Early Treated Infants. _Clinical Infectious Diseases_ . 2022;74(6):1047-1054. doi:10.1093/cid/ciab586  
17. Patel F, Shiau S, Strehlau R, et al. Low Pretreatment Viral Loads in Infants With HIV in an Era of High-maternal Antiretroviral Therapy Coverage. _Pediatric Infectious Disease Journal_ . 2021;40(1):55-59. doi:10.1097/INF.0000000000002897  
18. Maswabi K, Ajibola G, Bennett K, et al. Safety and Efficacy of Starting Antiretroviral Therapy in the First Week of Life. _Clinical Infectious Diseases_ . 2021;72(3):388-393. doi:10.1093/cid/ciaa028  
19. Domínguez-Rodríguez S, Tagarro A, Palma P, et al. Reduced Time to Suppression Among Neonates With HIV Initiating Antiretroviral Therapy Within 7 Days After Birth. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2019;82(5):483-490. doi:10.1097/QAI.0000000000002188  
20. Evans C, Jones CE, Prendergast AJ. HIV-exposed, uninfected infants: new global challenges in the era of paediatric HIV elimination. _Lancet Infect Dis_ . 2016;16(6):e92-e107. doi:10.1016/S14733099(16)00055-4  
21. Taron-Brocard C, Le Chenadec J, Faye A, et al. Increased Risk of Serious Bacterial Infections Due to Maternal Immunosuppression in HIV-Exposed Uninfected Infants in a European Country. _Clinical Infectious Diseases_ . 2014;59(9):1332-1345. doi:10.1093/cid/ciu586  
22. Nielsen-Saines K, Watts DH, Veloso VG, et al. Three Postpartum Antiretroviral Regimens to Prevent Intrapartum HIV Infection. _New England Journal of Medicine_ . 2012;366(25):2368-2379. doi:10.1056/NEJMoa1108275  
23. Haile-Selassie H, Townsend C, Tookey P. Use of neonatal post-exposure prophylaxis for prevention of mother-to-child HIV transmission in the UK and Ireland, 2001-2008. _HIV Med_ . 2011;12(7):422-427. doi:10.1111/j.1468-1293.2010.00902.x  
31  
24. McKeegan K, Rutstein R, Lowenthal E. Postnatal Infant HIV Prophylaxis: A Survey of U.S. Practice. _AIDS Patient Care STDS_ . 2011;25(1):1-4. doi:10.1089/apc.2010.0255  
25. Chiappini E, Galli L, Giaquinto C, et al. Use of combination neonatal prophylaxis for the prevention of mother-to-child transmission of HIV infection in European high-risk infants. _AIDS_ . 2013;27(6):991-1000. doi:10.1097/QAD.0b013e32835cffb1  
26. BHIVA. British HIV Association guidelines for the management of HIV infection in pregnant women 2018. Published online 2018:75-91.  
27. Panel on Treatment of Pregnant Women with, HIV Infection and Prevention of Perinatal Transmission. _Recommendations for the Use of Antiretroviral Drugs in Pregnant Women with HIV Infection and Interventions to Reduce Perinatal HIV Transmission in the United States_ .; 2020.  
28. Association BH. _British HIV Association Guidelines for the Management of HIV in Pregnancy and Postpartum 2018 (2019 Second Interim Update)_ .; 2019.  
29. Rodger AJ, Cambiano V, Bruun T, et al. Sexual Activity Without Condoms and Risk of HIV Transmission in Serodifferent Couples When the HIV-Positive Partner Is Using Suppressive Antiretroviral Therapy. _JAMA_ . 2016;316(2):171. doi:10.1001/jama.2016.5148  
30. Brooks JT, Kawwass JF, Smith DK, et al. Effects of Antiretroviral Therapy to Prevent HIV Transmission to Women in Couples Attempting Conception When the Man Has HIV Infection — United States, 2017. _MMWR Morb Mortal Wkly Rep_ . 2017;66(32):859-860. doi:10.15585/mmwr.mm6632e1  
31. Seidman DL, Weber S, Timoney MT, et al. Use of HIV pre-exposure prophylaxis during the preconception, antepartum and postpartum periods at two United States medical centers. _Am J Obstet Gynecol_ . 2016;215(5):632.e1-632.e7. doi:10.1016/j.ajog.2016.06.020  
32. Seidman DL, Weber S, Cohan D. Offering pre-exposure prophylaxis for HIV prevention to pregnant and postpartum women: a clinical approach. _J Int AIDS Soc_ . 2017;20:21295. doi:10.7448/IAS.20.2.21295  
33. Ministério da Saúde do Brasil. _Protocolo Clínico e Diretrizes Terapêuticas Para Profilaxia PréExposição Ao HIV (PrEP) de Risco à Infecção Pelo HIV_ .; 2017.  
34. Ministério da Saúde do Brasil. Protocolo Clínico e Diretrizes Terapêuticas para a Prevenção da Transmissão Vertical de HIV, Sífilis e hepatites Virais. Published online 2020.  
35. Ministério da Saúde do Brasil. Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia PréExposição (PrEP) de Risco à Infecção pelo HIV. Published online 2018.  
36. Sau R DA. PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS PARA PREVENÇÃO DA TRANSMISSÃO VERTICAL DO HIV, SÍFILIS E HEPATITES VIRAIS. Accessed August 23, 2023. http://www.saude.gov.br/tuberculose,  
37. Ministério da Saúde do Brasil. _Caderneta de Saúde Da Criança_ .; 2014.  
38. Panel on Opportunistic Infections in HIV-Exposed and HIV-Infected Children. Guidelines for the Prevention and Treatment of Opportunistic Infections in HIV-Exposed and HIV-Infected Children. Department of Health and Human. Published online 2020:w1 a w9.  
39. Heidari S, Mofenson L, Cotton MF, Marlink R, Cahn P, Katabira E. Antiretroviral Drugs for Preventing Mother-to-Child Transmission of HIV: A Review of Potential Effects on HIV-Exposed but Uninfected Children. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2011;57(4):290-296. doi:10.1097/QAI.0b013e318221c56a  
40. Leroy, Valériane; Ladner, Joel; Nyiraziraje, Marie; De Clercq, Andre; Bazubagira, Anatolie; Van de Perre, Philippe; Karita, Etienne; Dabis F and HSG. Effect of HIV-1 infection on pregnancy outcome in women in Kigali, Rwanda, 1992–1994. _AIDS_ . 1998;12(6):643-650.  
32  
41. Townsend CL, Cortina-Borja M, Peckham CS, Tookey PA. Antiretroviral therapy and premature delivery in diagnosed HIV-infected women in the United Kingdom and Ireland. _AIDS_ . 2007;21(8):10191026. doi:10.1097/QAD.0b013e328133884b  
42. Zash R, Makhema J, Shapiro RL. Neural-Tube Defects with Dolutegravir Treatment from the Time of Conception. _New England Journal of Medicine_ . 2018;379(10):979-981. doi:10.1056/NEJMc1807653  
43. Zash R, Holmes L, Diseko M, et al. Neural-Tube Defects and Antiretroviral Treatment Regimens in Botswana. _New England Journal of Medicine_ . 2019;381(9):827-840. doi:10.1056/NEJMoa1905230  
44. Chen JY, Ribaudo HJ, Souda S, et al. Highly Active Antiretroviral Therapy and Adverse Birth Outcomes Among HIV-Infected Women in Botswana. _J Infect Dis_ . 2012;206(11):1695. doi:10.1093/INFDIS/JIS553  
45. Zash R, Makhema J, Shapiro RL. Neural-Tube Defects with Dolutegravir Treatment from the Time of Conception. _N Engl J Med_ . 2018;379(10):979. doi:10.1056/NEJMC1807653  
46. Pereira GFM, Kim A, Jalil EM, et al. Dolutegravir and pregnancy outcomes in women on antiretroviral therapy in Brazil: a retrospective national cohort study. _Lancet HIV_ . 2021;8(1):e33-e41. doi:10.1016/S2352-3018(20)30268-X  
47. NOTA INFORMATIVA N<sup>o</sup> 1/2022-CGIST/.DCCI/SVS/MS — Departamento de HIV/Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis. Accessed August 23, 2023. https://www.gov.br/aids/pt-br/centrais-de-conteudo/notas-informativas/2022/sei_25000010273_2022_15_-_nota_informativa_no_12022-cgist-dcci_-svs_-ms__dispoe_sobre_as_recomendacoes_do_uso_de_dolutegravir_em_gestantes.pdf/view  
48. Jao J, Abrams EJ. Metabolic Complications of in utero Maternal HIV and Antiretroviral Exposure in HIV-exposed Infants. _Pediatr Infect Dis J_ . 2014;33(7):734-740. doi:10.1097/INF.0000000000000224  
49. Sibiude J, Mandelbrot L, Blanche S, et al. Association between Prenatal Exposure to Antiretroviral Therapy and Birth Defects: An Analysis of the French Perinatal Cohort Study (ANRS CO1/CO11). _PLoS Med_ . 2014;11(4):e1001635. doi:10.1371/JOURNAL.PMED.1001635  
50. Watts DH, Huang S, Culnane M, et al. Birth defects among a cohort of infants born to HIV-infected women on antiretroviral medication. _J Perinat Med_ . 2011;39(2):163. doi:10.1515/JPM.2010.139  
51. Brogly SB, Abzug MJ, Watts DH, et al. Birth defects among children born to HIV-infected women: Pediatric AIDS Clinical Trials Protocols 219 and 219C. _Pediatr Infect Dis J_ . 2010;29(8):721. doi:10.1097/INF.0B013E3181E74A2F  
52. Ivy W, Nesheim SR, Paul SM, et al. Cancer Among Children With Perinatal Exposure to HIV and Antiretroviral Medications—New Jersey, 1995–2010. _JAIDS Journal of Acquired Immune Deficiency Syndromes_ . 2015;70(1):62-66. doi:10.1097/QAI.0000000000000695  
53. Hleyhel M, Goujon S, Delteil C, et al. Risk of cancer in children exposed to didanosine in utero. _AIDS_ . 2016;30(8):1245-1256. doi:10.1097/QAD.0000000000001051  
54. Adler C, Haelterman E, Barlow P, Marchant A, Levy J, Goetghebuer T. Severe Infections in HIVExposed Uninfected Infants Born in a European Country. Davies MA, ed. _PLoS One_ . 2015;10(8):e0135375. doi:10.1371/journal.pone.0135375  
55. Epalza C, Goetghebuer T, Hainaut M, et al. High Incidence of Invasive Group B Streptococcal Infections in HIV-Exposed Uninfected Infants. _Pediatrics_ . 2010;126(3):e631-e638. doi:10.1542/peds.2010-0183  
56. Ruck C, Reikie BA, Marchant A, Kollmann TR, Kakkar F. Linking Susceptibility to Infectious Diseases to Immune System Abnormalities among HIV-Exposed Uninfected Infants. _Front Immunol_ . 2016;7. doi:10.3389/fimmu.2016.00310  
33  
57. Slogrove AL, Goetghebuer T, Cotton MF, Singer J, Bettinger JA. Pattern of Infectious Morbidity in HIV-Exposed Uninfected Infants and Children. _Front Immunol_ . 2016;7. doi:10.3389/fimmu.2016.00164  
58. Bunders M, Pembrey L, Kuijpers T, Newell ML. Evidence of Impact of Maternal HIV Infection on Immunoglobulin Levels in HIV-Exposed Uninfected Children. _AIDS Res Hum Retroviruses_ . 2010;26(9):967-975. doi:10.1089/aid.2009.0241  
59. Reikie BA, Naidoo S, Ruck CE, et al. Antibody Responses to Vaccination among South African HIV-Exposed and Unexposed Uninfected Infants during the First 2 Years of Life. _Clinical and Vaccine Immunology_ . 2013;20(1):33-38. doi:10.1128/CVI.00557-12  
60. Hygino J, Lima PG, Filho RGS, et al. Altered immunological reactivity in HIV-1-exposed uninfected neonates. _Clinical Immunology_ . 2008;127(3):340-347. doi:10.1016/j.clim.2008.01.020  
61. Kakkar F, Lamarre V, Ducruet T, et al. Impact of maternal HIV-1 viremia on lymphocyte subsets among HIV-exposed uninfected infants: protective mechanism or immunodeficiency. _BMC Infect Dis_ . 2014;14(1):236. doi:10.1186/1471-2334-14-236  
62. Afran L, Garcia Knight M, Nduati E, Urban BC, Heyderman RS, Rowland-Jones SL. HIVexposed uninfected children: a growing population with a vulnerable immune system? _Clin Exp Immunol_ . 2014;176(1):11-22. doi:10.1111/cei.12251  
63. Williams PL, Yildirim C, Chadwick EG, et al. Association of maternal antiretroviral use with microcephaly in children who are HIV-exposed but uninfected (SMARTT): a prospective cohort study. _Lancet HIV_ . 2020;7(1):e49-e58. doi:10.1016/S2352-3018(19)30340-6  
64. Slogrove AL, Powis KM, Johnson LF, Stover J, Mahy M. Estimates of the global population of children who are HIV-exposed and uninfected, 2000–18: a modelling study. _Lancet Glob Health_ . 2020;8(1):e67-e75. doi:10.1016/S2214-109X(19)30448-6  
65. Thea DM, St. Louis ME, Atido U, et al. A Prospective Study of Diarrhea and HIV-1 Infection among 429 Zairian Infants. _New England Journal of Medicine_ . 1993;329(23):1696-1702. doi:10.1056/NEJM199312023292304  
66. Embree JE, Datta P, Stackiw W, et al. Increased Risk of Early Measles in Infants of Human Immunodeficiency Virus Type 1-Seropositive Mothers. _J Infect Dis_ . 1992;165(2):262-267. doi:10.1093/infdis/165.2.262  
67. Marinda E, Humphrey JH, Iliff PJ, et al. Child Mortality According to Maternal and Infant HIV Status in Zimbabwe. _Pediatr Infect Dis J_ . 2007;26(6):519. doi:10.1097/01.inf.0000264527.69954.4c  
68. McNally LM, Jeena PM, Gajee K, et al. Effect of age, polymicrobial disease, and maternal HIV status on treatment response and cause of severe pneumonia in South African children: a prospective descriptive study. _Lancet_ . 2007;369(9571):1440-1451. doi:10.1016/S0140-6736(07)60670-9  
69. Smith C, Huo Y, Patel K, et al. Immunologic and Virologic Factors Associated With Hospitalization in Human Immunodeficiency Virus–Exposed, Uninfected Infants in the United States. _Clin Infect Dis_ . 2021;73(6):1089. doi:10.1093/CID/CIAB272  
70. Jallow S, Madhi SA. Pneumococcal conjugate vaccine in HIV-infected and HIV-exposed, uninfected children. _Expert Rev Vaccines_ . 2017;16(5):453-465. doi:10.1080/14760584.2017.1307740  
71. Manzanares Á, Prieto-Tato LM, Escosa-García L, et al. Increased risk of group B streptococcal sepsis and meningitis in HIV-exposed uninfected infants in a high-income country. _Eur J Pediatr_ . 2023;182(2):575-579. doi:10.1007/s00431-022-04710-6  
72. Brennan AT, Bonawitz R, Gill CJ, et al. A Meta-analysis Assessing Diarrhea and Pneumonia in HIV-Exposed Uninfected Compared With HIV-Unexposed Uninfected Infants and Children. _J Acquir Immune Defic Syndr_ . 2019;82(1):1-8. doi:10.1097/QAI.0000000000002097  
73. Goetghebuer T, Smolen KK, Adler C, et al. Initiation of Antiretroviral Therapy Before Pregnancy Reduces the Risk of Infection-related Hospitalization in Human Immunodeficiency Virus–exposed  
34  
Uninfected Infants Born in a High-income Country. _Clinical Infectious Diseases_ . 2019;68(7):1193-1203. doi:10.1093/cid/ciy673  
74. Abu-Raya B, Kollmann TR, Marchant A, MacGillivray DM. The Immune System of HIVExposed Uninfected Infants. _Front Immunol_ . 2016;7:383. doi:10.3389/fimmu.2016.00383  
75. Adetokunboh OO, Ndwandwe D, Awotiwon A, Uthman OA, Wiysonge CS. Vaccination among HIV-infected, HIV-exposed uninfected and HIV-uninfected children: a systematic review and metaanalysis of evidence related to vaccine efficacy and effectiveness. _https://doi.org/101080/2164551520191599677_ . 2019;15(11):2578-2589. doi:10.1080/21645515.2019.1599677  
76. Kakkar F, Lamarre V, Ducruet T, et al. Impact of maternal HIV-1 viremia on lymphocyte subsets among HIV-exposed uninfected infants: protective mechanism or immunodeficiency. _BMC Infect Dis_ . 2014;14(1):236. doi:10.1186/1471-2334-14-236  
77. Arikawa S, Rollins N, Newell ML, Becquet R. Mortality risk and associated factors in HIVexposed, uninfected children. _Tropical Medicine & International Health_ . 2016;21(6):720-734. doi:10.1111/tmi.12695  
78. Brennan AT, Bonawitz R, Gill CJ, et al. A meta-analysis assessing all-cause mortality in HIVexposed uninfected compared with HIV-unexposed uninfected infants and children. _AIDS_ . 2016;30(15):2351. doi:10.1097/QAD.0000000000001211  
79. Slogrove AL, Goetghebuer T, Cotton MF, Singer J, Bettinger JA. Pattern of Infectious Morbidity in HIV-Exposed Uninfected Infants and Children. _Front Immunol_ . 2016;7. https://www.frontiersin.org/articles/10.3389/fimmu.2016.00164  
80. Long-Term Follow-Up of Infants Exposed to Antiretroviral Drugs  NIH. Published online January 2023. https://clinicalinfo.hiv.gov/en/guidelines/perinatal/management-infants-long-term-follow-upexposed-arv-drugs  
81. Lipshultz SE, Miller TL, Wilkinson JD, et al. Cardiac effects in perinatally HIV-infected and HIVexposed but uninfected children and adolescents: a view from the United States of America. _J Int AIDS Soc_ . 2013;16(1). doi:10.7448/IAS.16.1.18597  
82. LIPSHULTZ SE, SASAKI N, THOMPSON B, et al. Left Ventricular Diastolic Dysfunction in HIV-Uninfected Infants Exposed in utero to Antiretroviral Therapy. _AIDS_ . 2020;34(4):529-537. doi:10.1097/QAD.0000000000002443  
83. García-Otero L, López M, Goncé A, et al. Cardiac Remodeling and Hypertension in HIVUninfected Infants Exposed in utero to Antiretroviral Therapy. _Clin Infect Dis_ . 2021;73(4):586-593. doi:10.1093/cid/ciab030  
84. Guerra V, Leister EC, Williams PL, et al. Long-Term Effects of In Utero Antiretroviral Exposure: Systolic and Diastolic Function in HIV-Exposed Uninfected Youth. _AIDS Res Hum Retroviruses_ . 2016;32(7):621. doi:10.1089/AID.2015.0281  
85. Jao J, Jacobson DL, Yu W, et al. A comparison of metabolic outcomes between obese HIVexposed uninfected youth from the PHACS SMARTT Study and HIV-unexposed youth from the NHANES Study in the U.S. _J Acquir Immune Defic Syndr_ . 2019;81(3):319-327. doi:10.1097/QAI.0000000000002018  
86. NEARY J, LANGAT A, SINGA B, et al. Higher prevalence of stunting and poor growth outcomes in HIV-exposed uninfected than HIV-unexposed infants in Kenya. _AIDS_ . 2022;36(4):605-610. doi:10.1097/QAD.0000000000003124  
87. Wedderburn CJ, Evans C, Yeung S, Gibb DM, Donald KA, Prendergast AJ. Growth and Neurodevelopment of HIV-Exposed Uninfected Children: a Conceptual Framework. _Curr HIV/AIDS Rep_ . 2019;16(6):501. doi:10.1007/S11904-019-00459-0  
35  
88. Sevenoaks T, Wedderburn CJ, Donald KA, et al. Association of maternal and infant inflammation with neurodevelopment in HIV-exposed uninfected children in a South African birth cohort. _Brain Behav Immun_ . 2021;91:65-73. doi:10.1016/j.bbi.2020.08.021  
89. Wedderburn CJ, Groenewold NA, Roos A, et al. Early structural brain development in infants exposed to HIV and antiretroviral therapy in utero in a South African birth cohort. _J Int AIDS Soc_ . 2022;25(1):e25863. doi:10.1002/JIA2.25863  
90. Young JM, Bitnun A, Read SE, Smith M Lou. Early academic achievement of HIV-exposed uninfected children compared to HIV-unexposed uninfected children at 5 years of age. _Child Neuropsychology_ . 2021;27(4):532-547. doi:10.1080/09297049.2021.1871891  
91. Wedderburn CJ, Weldon E, Bertran-Cobo C, et al. Early neurodevelopment of HIV-exposed uninfected children in the era of antiretroviral therapy: a systematic review and meta-analysis. _Lancet Child Adolesc Health_ . 2022;6(6):393-408. doi:10.1016/S2352-4642(22)00071-2  
92. Horner MJ, Hazra R, Barnholtz-Sloan JS, Shiels MS, Engels EA. Cancer risk among HIV-exposed uninfected children in the United States. _AIDS_ . 2023;37(3):549-551. doi:10.1097/QAD.0000000000003458  
93. Ameri S, Moseholm E, Weis N. Psychiatric disorders in perinatally HIV-exposed, uninfected children: a systematic review. _https://doi.org/101080/0954012120222141185_ . Published online 2022. doi:10.1080/09540121.2022.2141185  
94. Mellins CA, Elkington KS, Leu CS, et al. Prevalence and Change in Psychiatric Disorders Among Perinatally HIV-Infected and HIV-Exposed Youth. _AIDS Care_ . 2012;24(8):953-962. doi:10.1080/09540121.2012.668174  
95. Torre P, Zeldow B, Hoffman HJ, et al. Hearing Loss in Perinatally Human Immunodeficiency Virus-Infected and Human Immunodeficiency Virus -Exposed but Uninfected Children and Adolescents. _Pediatr Infect Dis J_ . 2012;31(8):835-841. doi:10.1097/INF.0b013e31825b9524  
96. Bucek A, Mellins CA, Leu CS, et al. Psychiatric disorders and young adult milestones in HIVexposed, uninfected youth. _AIDS Care_ . 2020;32(4):420-428. doi:10.1080/09540121.2019.1668535  
97. PSYCHIATRIC DISORDERS IN HIV-EXPOSED UNINFECTED VS NON-HIV-EXPOSED CHILDREN - CROI Conference. Accessed August 23, 2023. https://www.croiconference.org/abstract/psychiatric-disorders-in-hiv-exposed-uninfected-vs-non-hivexposed-children/  
98. Slogrove AL. It is a question of equity: time to talk about children who are HIV-exposed and “HIV-free.” _J Int AIDS Soc_ . 2021;24(11):e25850. doi:10.1002/jia2.25850  
99. Ramokolo V, Goga AE, Slogrove AL, Powis KM. Unmasking the vulnerabilities of uninfected children exposed to HIV. _BMJ_ . 2019;366:l4479. doi:10.1136/bmj.l4479  
36  
**Apêndice A: Classificação imunológica do HIV com base em LT-CD4+, em números absolutos e percentuais, e de acordo com a idade**  
|**Classificação de**|**C**|**ontagem de**|**LT-CD4 (cél**|**ulas/m**<sup>**3**</sup>**) con**|**forme idade**||
|---|---|---|---|---|---|---|
|**imunossupressão***|**Menor qu**|**e 1 ano**|**1 a 6 a**|**nos**|**A partir d**|**e 6 anos**|
|1 – Ausente|≥ 1.500|≥ 34|≥ 1.000|≥ 30|≥ 500|≥ 26|
|2 – Moderada|750-1.490|26-33|500-999|22-29|200-499|14-25|
|3 – Grave<sup>(a)</sup>|< 750|< 26|< 500|< 22|< 200|< 14|  
Fonte: _Morbidity and Mortality Weekly Report. Recommendations and Reports /_ Vol. 63 / No. 3 April 11, 2014 _Revised Surveillance Case Definition for HIV Infection_ — United States, 2014.  
*A classificação é inicialmente realizada pela contagem de LT-CD4+. Na sua indisponibilidade, considerar a porcentagem.  
(a) Independentemente do resultado da contagem de LT-CD4+, na presença de uma infecção oportunista, a classificação 3 (grave) é estabelecida.  
37  
**Apêndice B – Fórmula para cálculo da superfície corpórea em pediatria**  
Fonte: BAILEY, B. J.; BRIARS, G. L _. Estimating the surface area of the human body_ . Statistics in Medicine, [S.l.], v. 15, n. 13, p. 1325-32, 15 jul. 1996. Disponível em: https://www.ncbi.nlm.nih.gov/pubmed/8841644. Acesso em: 15 mar. 2018.  
38

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 - Diagnóstico, manejo e acompanhamento de crianças expostas ao HIV contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
O grupo elaborador deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do DATHI. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A proposta de atualização do PCDT de Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2: Diagnóstico, manejo e tratamento de crianças e adolescentes vivendo com HIV foi apresentada na 108ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 29 de agosto de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 123ª Reunião Ordinária, os quais recomendaram favoravelmente à atualização do texto.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A Consulta Pública nº 42/2023, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas do Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 - Diagnóstico, Manejo e Acompanhamento de Crianças Expostas ao HIV, foi realizada entre os dias 09/10/2023 e 30/10/2023. Foram recebidas duas contribuições, que podem ser verificadas em: https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2023/contribuicoes-cp-42-pcdt-para-manejo-da-infeccao-pelo-hiv-emcriancas-e-adolescentes-modulo-1.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 2: Diagnóstico, manejo e tratamento de crianças e  
39  
adolescentes vivendo com HIV contou com a participação do comitê de experts no tratamento da doença. O grupo de especialistas foi composto por representantes da comunidade científica, representante da Sociedade Brasileira de Infectologia, representantes da sociedade civil e especialistas com longa experiência no cuidado e tratamento de pessoas que vivem com HIV e Aids, oriundos de instituições envolvidas com o cuidado às pessoas vivendo com HIV.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao MS para análise prévia às reuniões de escopo e formulação de recomendações.  
Para a atualização das recomendações do novo documento, elaborou-se uma proposta inicial do escopo de atualização do PCDT, que motivou a primeira reunião on-line com o grupo técnico assessor realizada em abril de 2023. Nesta reunião, foram estabelecidos os pontos que demandavam atualização, considerando as novas tecnologias em saúde previamente incorporadas, o cenário epidemiológico e as principais estratégias de enfrentamento à epidemia de Aids.  
Diante do exposto, foram realizadas buscas na literatura científica por revisões sistemáticas, ensaios clínicos randomizados, além de protocolos e diretrizes clínicas internacionais sobre os temas específicos de cada uma das seções. Também foram utilizados os Relatórios de Recomendação referente às novas tecnologias incorporadas, como raltegravir 100 mg granulado e dolutegravir 5 mg, em apresentações mais adequadas ao uso pediátrico.  
Após a análise das evidências científicas, buscou-se identificar as necessidades de atualização do PCDT publicado em 2018, como subsídio para a nova reunião com o grupo de especialistas, que ocorreu em julho de 2023. O levantamento de evidências resultante das buscas na literatura científica, foi utilizado para elaboração da proposta preliminar.  
Previamente, os especialistas receberam a proposta elaborada pela Coordenação-Geral de Vigilância do HIV/Aids e das Hepatites Virais (CGAHV/DATHI/SVSA/MS) e que elencava os pontos chave para atualização do PCDT. Durante o encontro, foi aplicada uma adaptação do método Delphi para obter o consenso dos especialistas para a tomada de decisão sobre as novas recomendações e também em relação àquelas que apresentavam diferenças de parâmetros na literatura.  
Os principais temas atualizados foram:  
Módulo 1:  
1. Inclusão do capítulo sobre 'Diagnóstico da infecção pelo HIV em menores de 18 meses': fluxo de diagnóstico com DNA pró-viral e atualização do ponto de corte da carga viral (CV-HIV).  
2. Inclusão do medicamento raltegravir 100 mg granulado para profilaxia da transmissão vertical ao HIV em crianças com alto risco de exposição ao HIV conforme relatório técnico de recomendação da Conitec nº 831/2023.  
3. Inclusão de capítulo novo sobre ‘Manejo de crianças expostas e não infectadas’. Módulo 2:  
1. Inclusão de nova formulação de ARV da classe de inibidores da integrase: dolutegravir 5 mg comprimidos dispersíveis, para tratamento do HIV e prevenção em crianças com HIV de 2 meses a 6 anos de idade em conforme relatório técnico de recomendação da Conitec nº 830/2023.  
2. Inclusão de capítulos novos sobre ‘Transição do Cuidado de Pediatria para Atenção de Adultos’; ‘Prevenção combinada e Profilaxias Pré e Pós-exposição ao HIV (PrEP e PEP-HIV)’.  
Após a reunião, as decisões foram incorporadas ao texto do documento final, o qual foi compartilhado com o grupo de especialistas para a definição da versão final, sendo que as sugestões adicionais foram consolidadas pela equipe da CGAHV/DATHI/SVSA/MS.  
40  
Na sequência, a minuta de texto atualizado foi apresentada à Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS) e, após revisão, foi avaliada pela Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas  
41

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Crianças e Adolescentes - Módulo 1 | secao: MINISTÉRIO DA SAÚDE -->
|**Número do Relatório**<br>**da**<br>**diretriz**<br>**clínica**||**Tecnologias avaliadas**<br>|**pela Conitec**<br>|
|---|---|---|---|
|**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório<br>de<br>Recomendação<br>nº<br>830/2023 e 831/2023.|Desmembramento do<br>texto em módulos;<br>Atualização do texto<br>do documento e<br>inclusão de<br>orientações referentes<br>às tecnologias<br>incorporada<br>Inclusão de<br>informações sobre<br>cuidado de crianças<br>expostas e não<br>infectadaspelo HIV|Raltegravir 100 mg granulado para<br>profilaxia da transmissão vertical do<br>HIV em crianças com alto risco de<br>exposição ao HIV. [Relatório de<br>Recomendação nº 831/2023; Portaria<br>SECTICS/MS nº 38/2023]<br>Dolutegravir 5 mg como tratamento<br>complementar ou substitutivo em<br>crianças de 2 meses a 6 anos de idade<br>com HIV. [Relatório de Recomendação<br>nº 830/2023; Portaria SECTICS/MS nº<br>36/2023]|-|
|Relatório<br>de<br>Recomendação nº 283;<br>Portaria SCTIE/MS nº<br>31, de 01/09/2017|Primeira versão do<br>documento|-|-|  
42

---

