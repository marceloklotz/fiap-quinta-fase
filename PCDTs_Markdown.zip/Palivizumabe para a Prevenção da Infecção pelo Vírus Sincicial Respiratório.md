<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: Geral -->
SECRETARIA DE ATENÇÃO À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 23, DE 3 DE OUTUBRO DE 2018.  
Aprova o Protocolo de Uso do Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a infecção pelo vírus sincicial respiratório no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta infecção;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 12/2012 e o Relatório de Recomendação n<sup><u>o</u></sup> 16 – Novembro de 2012 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC);  
Considerando a 66ª Reunião da CONITEC, em 9 de maio de 2018, na qual foi aprovada a substituição da apresentação farmacêutica de palivizumabe em pó liofilizado + diluente, por descontinuidade de produção dessa apresentação pelo fabricante, para o palivizumabe em solução injetável; e  
Considerando a avaliação do Departamento de Ações Programáticas Estratégicas (DAPES/SAS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), resolvem:  
Art. 1º  Fica aprovada atualização do Protocolo de Uso do Palivizumabe na Prevenção da Infecção pelo Vírus Sincicial Respiratório, conforme o Anexo a esta Portaria.  
§ 1º  O Protocolo objeto desta Portaria, que contém o conceito geral da infecção pelo vírus sincicial respiratório, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
§ 2º  Diante das evidências que vêm sendo disponibilizadas, ficam o Departamento de Ações Programáticas Estratégicas (DAPES/SAS/MS) e o Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) responsáveis por demandar a CONITEC para a revisão do  uso do palivizumabe para a prevenção da infecção pelo vírus sincicial respiratório.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso do medicamento preconizado para a prevenção da infecção pelo vírus sincicial respiratório.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 522/SAS/MS, de 13 de maio de 2013, publicada no Diário Oficial da União nº 92, de 15 de maio de 2013, seção 1, páginas 43 à 45.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
MARCO ANTÔNIO DE ARAÚJO FIREMAN  
ANEXO

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **1. INTRODUÇÃO** -->
O vírus sincicial respiratório (VSR) é um dos principais agentes etiológicos das infecções que acometem o trato respiratório inferior entre lactentes e crianças menores de 2 anos de idade, podendo ser responsável por até 75% das bronquiolites e 40% das pneumonias durante os períodos de sazonalidade.  
Lactentes com menos de seis meses de idade, principalmente prematuros, crianças com doença pulmonar crônica da prematuridade e cardiopatas são a população de maior risco para desenvolver infecção respiratória mais grave, necessitando de internação por desconforto respiratório agudo em 10% a 15% dos casos. Nesta população, as condições associadas ao desenvolvimento de doença grave são decorrentes do sistema imune imaturo, reduzida transferência de anticorpos maternos e menor calibre das vias aéreas; acrescidos da baixa reserva energética, frequente desmame precoce, anemia, infecções de repetição e uso de corticóides, tornando-se mais suscetíveis à ação do VSR.  
A prematuridade é um dos principais fatores de risco para hospitalização pelo VSR. Em prematuros com menos de 32 semanas de idade gestacional, a taxa de internação hospitalar é de 13,4% (IC95% 11,8-13,8%); esta taxa de hospitalização decresce com o aumento da idade gestacional. A presença de malformações cardíacas está relacionada a uma maior gravidade e taxas de hospitalização maiores em caso de infecções causadas pelo VSR. A hiper-reatividade vascular pulmonar e a hipertensão pulmonar são responsáveis pela gravidade do quadro. A taxa de admissão hospitalar nesses quadros é de 10,4%, com maior necessidade de internação em terapia intensiva e ventilação mecânica - 37% vs 1,5%, (p<0,01) e mortalidade de 3,4% comparada a uma taxa de 0,5% na população previamente sadia. A Doença Pulmonar Crônica da Prematuridade (DPCP) é uma condição na qual uma injúria pulmonar se estabelece num pulmão imaturo, o que leva à necessidade de suplementação de oxigênio e outras terapias medicamentosas; muitos estudos demonstram uma maior susceptibilidade de crianças com DPCP em desenvolver infecções graves pelo VSR, nesta situação a taxa de internação hospitalar atinge 17%.  
Estudos prospectivos têm demonstrado que a infecção de trato respiratório inferior no início da vida eleva em 25% a 80% a ocorrência de asma e hiper-reatividade brônquica comparada ao grupo controle, até 11 anos mais tarde.  
O VSR atinge o trato respiratório através do contato íntimo de pessoas infectadas ou através de superfícies ou objetos contaminados.  
A infecção ocorre quando o material infectado atinge e penetra o organismo através da membrana mucosa dos olhos, boca e nariz ou pela inalação de gotículas derivadas de tosse ou espirro. O tempo de sobrevida do VSR nas mãos é de menos de 1 hora, no entanto, em superfícies duras e não porosas (como, por exemplo, o estetoscópio), pode durar até aproximadamente 24 horas.  
O período de incubação da doença respiratória é de quatro a cinco dias, o vírus se replica em nasofaringe e o período de excreção viral pode variar de 3-8 dias até 3-4 semanas em recém-nascidos. A ocorrência de surtos de infecção por VSR pode ocorrer na comunidade como também no ambiente hospitalar. A ocorrência de surtos de infecção por VSR em serviços de saúde pode ocorrer a partir da infecção ou colonização de pais, visitantes e profissionais da saúde como médicos e enfermeiros que cuidam de crianças com infecção por VSR, que passam a funcionar como agentes de transmissão do vírus no ambiente hospitalar.  
Algumas características especiais como a sazonalidade, imunidade não permanente, presença de dois sorotipos diferentes e ausência de anticorpos específicos fazem com que o VSR esteja associado à doença de maior morbidade em populações de alto risco. Nesse sentido é fundamental que sejam instituídas medidas de prevenção desta infecção.  
Cabe ressaltar que este Protocolo visa a estabelecer critérios para o uso de palivizumabe para a prevenção da infecção pelo vírus sincicial respiratório, não englobando outras estratégias terapêuticas em caso de recém-nascido prematuro, de criança com doença pulmonar crônica da prematuridade com doença (displasia pulmonar) ou de criança com doença cardíaca congênita com repercussão hemodinâmica demonstrada, conforme estabelecido no item 3. CRITÉRIOS DE INCLUSÃO.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **2. PREVENÇÃO DA INFECÇÃO PELO VSR** -->
- 2.1. Medidas gerais Cuidados básicos para reduzir a transmissibilidade do VSR:  
- Higienizar as mãos antes e após contato com pacientes;  
- Limitar o contato com pessoas infectadas;  
- Intensificar os cuidados de higiene pessoal;  
- Orientar os familiares quanto à importância da higienização correta das mãos;  
- Fazer desinfecção das superfícies expostas às secreções corporais;  
- Instituir as precauções de contato e gotículas em pacientes hospitalizados com suspeita de infecção por VSR;  
- 2.2 Cuidados com pacientes que fazem parte dos grupos de risco:  
- Evitar locais com aglomeração de pessoas, inclusive creches, nos meses de maior incidência da doença;  
- Evitar exposição passiva ao fumo dos pais e familiares;  
- Vacinar contra Influenza crianças a partir dos 6 meses de vida até 2 anos de acordo com o Programa Nacional de Imunização do Ministério da Saúde.  
- 2.3. Medidas para controle da transmissão hospitalar:  
- Lavar as mãos antes e após contato com qualquer paciente ou material biológico e equipamentos ligados ao paciente;  
- Identificar precocemente os suspeitos e instituir as precauções de contato;  
- Utilizar preferencialmente quarto privativo, porém na impossibilidade de quarto privativo, utilizar incubadora como barreira para acomodar recém-nascido com suspeita ou caso confirmado de infecção viral;  
- Manter precauções de contato para todos os pacientes com doença por VRS, confirmada ou suspeita, que incluem;  
- Lavagem das mãos antes e após contato com o paciente e seus pertences;  
- Uso de luvas e avental para manipulação do recém-nascido;  
- Uso de máscara e óculos de proteção de acordo com a possibilidade de contato direto com secreções e aerossolização de partículas, como por exemplo, durante aspiração de vias aéreas;  
- Proibir a entrada de visitantes com infecção do trato respiratório;  
- Afastar profissionais da saúde, com infecção do trato respiratório dos cuidados com recém-nascidos e lactentes.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: 2.4. Medidas preventivas passivas: -->
A imunização passiva pode ser obtida com a utilização de imunoglobulinas policlonal e monoclonal. O anticorpo monoclonal humanizado palivizumabe tem-se mostrado eficaz na prevenção das doenças graves pelo VSR por apresentar atividade neutralizante e inibitória da fusão contra este vírus.  
Estudos científicos demonstram que a administração mensal do palivizumabe durante a sazonalidade do VSR reduziu de 45% a 55% a taxa de hospitalização relacionada à infecção por este vírus. Observado também que, entre as crianças internadas com diagnóstico de infecção por VSR com uso prévio de palivizumabe diminuiu significativamente o número de dias de hospitalização e o número de dias com necessidade aumentada de oxigênio.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **3. CRITÉRIOS DE INCLUSÃO** -->
A incorporação do palivizumabe foi aprovada pela CONITEC para a prevenção da infecção pelo VSR de acordo com os seguintes critérios:  
- Crianças prematuras nascidas com idade gestacional ≤ 28 semanas (até 28 semanas e 6 dias) com idade inferior a 1 ano (até 11 meses e 29 dias).  
- Crianças com idade inferior a 2 anos (até 1 ano, 11 meses e 29 dias) com doença pulmonar crônica da prematuridade, displasia broncopulmonar¹, ou doença cardíaca congênita com repercussão hemodinâmica demonstrada.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: 3.1 OUTROS ESCLARECIMENTOS -->
- Em recém-nascidos internados que preenchem critério de uso, a administração de palivizumabe poderá ser iniciada a partir de 7 dias de vida, desde que observada a estabilidade clínica² do paciente.  
- As crianças com 12 meses ou menos, com diagnóstico de doença cardíaca congênita (DCC) com significante repercussão hemodinâmica mais beneficiadas com a imunoprofilaxia com palivizumabe, com significativa redução de hospitalização incluem aquelas com cardiopatia acianótica em uso de medicamentos para controlar insuficiência cardíaca congestiva e que irão precisar de procedimento cirúrgico, assim como crianças com hipertensão pulmonar moderada a severa.  
> ¹ O diagnóstico de doença de doença pulmonar crônica da prematuridade (displasia broncopulmonar) é definido pela dependência de oxigênio em prematuros a partir de 28 dias de vida acompanhada de alterações típicas na radiografia pulmonar ou dependência de oxigênio com 36 semanas de idade gestacional corrigida, em prematuro extremo.  
> ² É considerada estabilidade clínica: recém-nascido sem uso de drogas vasoativas para tratamento de choque séptico, cardiogênico ou hipovolêmico; sem uso de antibióticos ou outras drogas para tratamento de infecção grave e sem uso de parâmetros elevados de ventilação mecânica.  
Para crianças com DCC cianótica o uso de palivizumabe é menos impactante em termos de redução de hospitalização, ficando a critério do cardiologista infantil a decisão de indicação da profilaxia com palivizumabe.  
O seguinte grupo de crianças com cardiopatia não possui risco elevado de infecção por VSR e, portanto, não está indicada imunoprofilaxia:  
a) RN e lactentes com doença cardíaca sem repercussão hemodinâmica como exemplo: defeito de septo atrial tipo ostium secundum, defeito pequeno de septo ventricular, estenose da pulmonar, estenose aórtica não complicada, coarctação leve da artéria aorta, persistência do ducto arterial.  
b) Crianças com lesão cardíaca corrigida por cirurgia a não ser que continue precisando de medicamentos por insuficiência cardíaca.  
c) Lactentes com cardiopatia leve sem uso de medicamentos para esta doença.  
No segundo ano de vida a profilaxia com palivizumabe não está recomendada com base em história de prematuridade isolada. Deve ser considerada a indicação de profilaxia durante a sazonalidade do VSR, nas seguintes condições:  
a) Crianças com cardiopatia congênita indicada segundo critérios acima e que permanece com repercussão clínica da doença, com necessidade de uso de medicamentos específicos;  
b) Crianças que preencheram critério de doença pulmonar crônica da prematuridade e continuam necessitando de tratamento de suporte como o uso de corticoide para doença pulmonar crônica, diurético ou suplemento de oxigênio durante os seis últimos meses, antes do início da segunda sazonalidade do VSR;  
Portanto não está recomendado o uso de profilaxia com palivizumabe para crianças com doença pulmonar crônica da prematuridade que não necessitaram tratamento de suporte no segundo ano de vida.  
Vale ressaltar que o número total de doses por criança dependerá do mês de início das aplicações, variando, assim, de 1 a 5 doses. Para crianças nascidas durante a sazonalidade do VSR, poderá ser necessário menos que 5 doses, uma vez que o medicamento não será aplicado após o término da sazonalidade.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **4. SAZONALIDADE DO VÍRUS SINCICIAL RESPIRATÓRIO (VSR) NO BRASIL** -->
O vírus sincicial respiratório caracteriza-se principalmente por seu caráter sazonal, dependendo das características de cada país ou região. No Brasil, observa-se a circulação durante todo o ano, mas com elevações no período compreendido entre os meses de maio até agosto, porém a atividade do vírus pode começar antes em determinadas regiões.  
Dessa forma, a definição de sazonalidade no Brasil se baseia na análise descritiva de identificação do vírus sincicial respiratório (VSR), realizada nas regiões geográficas do país, com base nos dados do Sistema de Informação da Vigilância Sentinela de Influenza e outros vírus respiratórios – SIVEPGRIPE.  
A sazonalidade para o VRS deve ser seguida por todos os serviços de saúde autorizados para administração de palivizumabe nos respectivos estados e DF.  
A primeira dose deve ser administrada um mês antes do início do período de sazonalidade do VSR.  
**Quadro 1. Sazonalidade do vírus sincicial respiratório (VSR) e Períodos de aplicação do palivizumabe no Brasil, por regiões geográficas.**  
|**REGIÃO**|**SAZONALIDADE**|**PERÍODO DE**<br>**APLICAÇÃO**|
|---|---|---|
|NORTE|Fevereiro a Junho|Janeiro a Junho|
|NORDESTE|Março a Julho|Fevereiro a Julho|
|CENTRO-OESTE|Março a Julho|Fevereiro a Julho|
|SUDESTE|Março a Julho|Fevereiro a Julho|
|SUL|Abril a Agosto|Março a Agosto|

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **5. APRESENTAÇÃO, PREPARAÇÃO, CONSERVAÇÃO E USO.** -->
O palivizumabe é, atualmente, comercializado no Brasil em caixa com frasco ampola de vidro incolor de 0,5 mL ou de 1 mL na forma de solução injetável. Contém na sua formulação os excipientes histidina, glicina e 5,6% de manitol. Cada 1 mL da solução contém 100 mg de palivizumabe.  
O palivizumabe deve ser armazenado, na embalagem original do produto, sob refrigeração, entre 2º a 8ºC, não devendo ser congelado, mantendo-se assim próprio para o consumo dentro do prazo de validade indicado pelo fabricante.  
Deve ser administrado exclusivamente por via intramuscular (IM), utilizando técnica  
asséptica.  
Para prevenir transmissão de doenças infecciosas, devem ser utilizadas seringas e agulhas descartáveis e de uso único, ou seja, não se re-utilizando qualquer dos materiais utilizados na injeção.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **6. POSOLOGIA E MODO DE ADMINISTRAÇÃO** -->
O palivizumabe deve ser usado sob a orientação, prescrição e supervisão de um médico. A administração deste medicamento deve ser feita somente por pessoa experiente na aplicação de forma injetável de medicamentos.  
A posologia recomendada de palivizumabe é 15 mg/kg de peso corporal, administrados uma vez por mês durante o período de maior prevalência do VSR previsto na respectiva comunidade, no total de, no máximo, cinco aplicações mensais consecutivas, dentro do período sazonal, que é variável em diferentes regiões do Brasil.  
A primeira dose deve ser administrada um mês antes do início do período de sazonalidade do VSR e as quatro doses subsequentes devem ser administradas com intervalos de 30 dias durante este período no total de até 5 doses.  
Vale ressaltar que o número total de doses por criança dependerá do mês de início das aplicações, variando, assim, de 1 a 5 doses, não se aplicando após o período de sazonalidade do VSR.  
A administração de palivizumabe deverá ser feita em crianças que preenchem um dos critérios de inclusão estabelecidos neste Protocolo, inclusive para as que se encontram internadas, devendo neste caso ser administrado no ambiente hospitalar e respeitado o intervalo de doses subsequentes intrahospitalar e pós-alta hospitalar.  
Infecção aguda ou doença febril moderadas a graves podem ser motivos para atraso no uso do palivizumabe, a menos que, na opinião do médico, a suspensão do uso deste medicamento implique risco maior. Doença febril leve, a princípio, não contraindica a administração de palivizumabe, cabendo ao médico a decisão de administrar ou adiar de acordo com as condições clínicas.  
A interrupção do uso de palivizumabe no intervalo recomendado, não causa a princípio, sintomas desagradáveis a criança, porém cessará o efeito protetor do medicamento na proteção de infecção pelo VSR. Caso isto ocorra, poderá(ão) ser administrada(s) a(s) dose(s) subsequente(s), sem ultrapassar o período da sazonalidade para VSR, mantendo, caso falte mais de uma dose dentro deste período, o intervalo de 30 dias entre elas.  
O palivizumabe deve ser administrado exclusivamente por via intramuscular (IM), com técnica asséptica; de preferência na face anterolateral da coxa. O músculo glúteo não deve ser utilizado rotineiramente como local de administração devido ao risco de dano ao nervo ciático.  
A injeção deve ser de, no máximo, 1 mL da solução injetável , e volume superior a 1 mL deve ser dividido e aplicado em diferentes grupos musculares, com injeções também de, no máximo, 1 mL por grupo.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **7. EFEITOS ADVERSOS E INTERAÇÕES MEDICAMENTOSAS** -->
O palivizumabe não deve ser utilizado em crianças com histórico de reação anterior grave à sua aplicação ou a qualquer de seus excipientes ou a outros anticorpos monoclonais humanizados.  
As reações adversas mais comuns são: infecções do trato respiratório superior, otite média, rinite, faringite, erupção cutânea e dor no local da injeção.  
Reações alérgicas, incluindo muito raramente a anafilaxia, foram relatadas após a administração de palivizumabe. Medicamentos para o tratamento de reações graves de hipersensibilidade, incluindo anafilaxia, devem estar disponíveis para uso imediato, acompanhando a administração de palivizumabe.  
Se uma reação grave de hipersensibilidade ocorrer, a terapia com palivizumabe deve ser suspensa. Assim como outros agentes administrados em crianças, se uma reação de hipersensibilidade moderada ocorrer deve-se ter cautela na readministração de palivizumabe.  
Como com qualquer injeção intramuscular, o palivizumabe deve ser administrado com cuidado a pacientes com trombocitopenia ou qualquer distúrbio de coagulação.  
Não foram identificados eventos clínicos significantes resultantes da administração de doses tão altas quanto 22 mg/kg a pacientes pediátricos.  
Não foram conduzidos estudos formais de interação medicamentosa, porém até o momento não foram descritas interações com outros medicamentos, alimentos ou exames laboratoriais.  
Como o anticorpo monoclonal é específico para VSR, não se espera que o palivizumabe interfira com a resposta imunológica às vacinas, incluindo vacinas de vírus vivos.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **8. RESPONSABILIDADES DE ATENDIMENTO E ENCAMINHAMENTOS** -->
Para a administração de palivizumabe, dever-se-á contar com estrutura física adequada: área para recepção e atendimento das crianças; área de preparo com pia para higienização das mãos; espaço físico para armazenamento do medicamento em geladeira contendo termômetro para controle de  
temperatura de 2º-8°C; e insumos para administração, como agulhas (20 x 5,5 e 25 x 7) e seringas de 1 mL descartável e compressas de álcool a 70% para antissepsia da pele.  
Deverá ter protocolo escrito e equipe treinada para atendimento de reações adversas como choque anafilático, assim como material e medicamentos para esta finalidade.  
Além de estrutura física e recursos materiais, é necessária equipe de saúde formada por médico, farmacêutico, enfermeiro ou técnico enfermagem com supervisão de um enfermeiro e um profissional técnico administrativo responsável pelo agendamento, recepção dos clientes e registro das informações. A equipe deverá manter o registro das informações referente ao agendamento, doses recebidas por paciente com registro de lote do medicamento utilizado garantindo a rastreabilidade.  
Embora o palivizumabe não se trate de uma vacina, e sim de um anticorpo monoclonal, é importante organizar o processo de trabalho observando os Aspectos Técnicos e Administrativos da atividade de vacinação.  
A indicação da administração de palivizumabe de acordo com os critérios estabelecidos neste Protocolo é de inteira responsabilidade do médico que acompanha a criança.  
Para os internados em hospitais no período da sazonalidade do VSR que preenchem os critérios estabelecidos neste Protocolo, o médico deverá prescrever a dose a ser administrada durante a internação, anotar a (s) dose(s) aplicada(s) na Caderneta da Criança e orientar por escrito a aplicação da(s) dose(s) subsequente(s) com intervalo de 30 dias no total de até 5 doses, sem ultrapassar o período da sazonalidade do VSR.  
Com objetivo de otimizar o uso do medicamento, orienta-se o agendamento de grupos de crianças que tenham indicação de uso para que recebam palivizumabe no mesmo dia. Assim, um frascoampola poderá ser fracionado de forma segura em múltiplas doses de acordo com o peso das crianças evitando o desperdício do produto.  
No momento da alta hospitalar, o profissional da saúde deverá orientar o responsável pela criança os benefícios do palivizumabe, assim como seus efeitos adversos, os cuidados a serem realizados na prevenção de infecções respiratórias no domicilio e, se for o caso, a importância da continuidade do recebimento da (s) dose(s) faltante(s), ambulatorialmente ou em hospital-dia.  
Informar aos pais ou responsáveis qual é o estabelecimento de saúde credenciado pela respectiva secretaria estadual de saúde para a administração de palivizumabe e quais são as providências necessárias de forma a garantir de forma ágil o acesso ao medicamento, em momento oportuno, para crianças residentes nos diversos municípios do país.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **8. DA GESTÃO DO MEDICAMENTO** -->
Para solicitação de palivizumabe, disponibiliza-se o modelo de ficha no Apêndice. O Ministério da Saúde disponibiliza o Sistema Nacional de Gestão da Assistência Farmacêutica (Sistema HÓRUS) e recomenda a sua utilização nas unidades que fazem a distribuição, dispensação e administração do palivizumabe.  
Os estados que não utilizam o Sistema HÓRUS e possuem sistema próprio de registro deverão manter atualizadas as informações referentes aos registros de estoque, distribuição, dispensação e administração do medicamento palivizumabe e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR).

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **9. REFERÊNCIAS** -->
1. American Academy of Pediatrics. Respiratory Syncytial Virus. In: Peter G, ed. 1997 Red Book: Report of the Committee on Infectious Diseases. 24th ed. Elk Grove Village, IL: American Academy of Pediatrics; 1997: 443.  
2. American Academy of Pediatrics. Technical Report. COMMITTEE ON INFECTIOUS DISEASES and BRONCHIOLITIS GUIDELINES COMMITTEE. Updated Guidance for Palivizumab Prophylaxis Among Infants and Young Children at Increased Risk of Hospitalization for Respiratory Syncytial Virus Infection. Downloaded from http://pediatrics.aappublications.org/ by guest on March 19, 2018.  
3. Respiratory Syncytial Virus. In: Peter G, ed. 1997 Red Book: Report of the Committee on Infectious Diseases. 24th ed. Elk Grove Village, IL: American Academy of Pediatrics; 1997: 443.  
4. 5. Carbonell-Estrany X, Quero J. Hospitalization rates for respiratory syncytial virus infection in premature infants born during two consecutive seasons. Pediatric Infect Dis J. 2001;20(9):874-879. 6. Carpenter TC, Stenmark KR. Predisposition of infants with chronic lung disease to respiratory syncytial virus-induced respiratory failure: a vascular hypothesis. Pediatr Infect Dis J. 2004;23(suppl 1):S33-S40.  
7. Centers for Disease Control and Prevention: Respiratory and Enteric Viruses Branch. Disponível na Internet via www. URL em 21 de janeiro, 2005: http://www.cdc.gov/ncidod/dvrd/revb/respiratory/ rsvfeat.htm.  
8. Committee on Infectious Diseases and Committee on Fetus and Newborn. Revised indications for the use of palivizumab and Respiratory Syncytial Virus immune globulin intravenous for the prevention of Respiratory Syncytial Virus infections. Pediatrics. 2003; 112: 1442.  
9. Feltes TF, Cabalka AK, Meissner HC et al. Palivizumabe prophylaxis reduces hospitalization due to VSR in young children with hemodynamically significant congenital heart disease. J Pediatr. 2003; 143:532-40.  
10. Goldman DA. Epidemiology and Prevention of Pediatric Viral Respiratory Infections in HealthCare Institutions. Emerging Infectious Diseases 2001; Vol 7, nº 2: 249-253.  
11. Lamarão LM, Ramos FL, Melo WA et al. Prevalence and clinical features of respiratory syncytial virus in children hospitalized for community-acquired pneumonia in northern Brazil BMC Infectious Diseases 2012, 12:119 http://www.biomedcentral.com/1471-2334/12/119/prepub, acessado em 24/04/2013.  
12. Mac Donald NE, Hall CB, Suffin SC, et al. Respiratory syncytial viral infection in infants with congenital heart disease. N Engl J Med. 1982;307:397-400.  
13. Manual de Rede de Frio / elaboração de Cristina Maria Vieira da Rocha et al. - 3. ed. - Brasília: Ministério da Saúde: Fundação Nacional de Saúde; 2001. 80p. il. http://portal.saude.gov.br/portal/arquivos/pdf/manu_rede_frio.pdf, acessado em 24/03/2013.  
14. Ministério da Saúde-Funasa. Aspectos Técnicos e Administrativos da Atividade de Vacinação agosto/2001: pág. 49-116. http:// portal. saude. gov. br/ portal/ arquivos/ pdf/aspectos_ tecnicos .pdf acessado em 24/03/2013.  
15. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Comissão de Incorporação de Tecnologias para o SUS - CONITEC. Palivizumabe para prevenção da infecção pelo vírus sincicial respiratório. Dezembro de 2012. 32 pg. Disponível em http:// portal. saude. gov. br/ portal/ arquivos/ pdf/ Palivizumabe_ Virussincicial_ final.pdf.  
16. Ministério da Saúde, Secretaria de Vigilância em Saúde, Coordenação Geral de Doenças Transmissíveis. Sentinel surveillance of influenza and other respiratory viruses, Brazil 2000-2010. Braz J Infect Dis.2013 Jan-Feb;17(1) 62-8.  
17. Pedraz C,Carbonell-Estrany X, Figueras-Aloy J et al. Effect of palivizumabe prophylaxis in decreasing respiratory syncytial virus hospitalization in premature infants. Pediatr Infect Dis J. 2003; 22(9):823-7.  
18. Riccetto AGL, Ribeiro JD, Silva MTN, Almeida RS, Arns CW, Baracat ECE. Respiratory Syncytial Virus (RSV) in Infants Hospitalized for Acute Lower Respiratory Tract Disease: Incidence and Associated Risks. The Brazilian Journal of Infectious Diseases 2006;10(5):357-361.  
19. Secretaria de Estado da Saúde de São Paulo. Resolução SS - SP Nº 249, de 13 de julho de 2007. Norma técnica relativa às diretrizes para a prevenção da infecção pelo vírus sincicial respiratório - VSR. Disponível na Internet via www. URL em 19 de fevereiro de 2008. http://www.cremesp.org.br/?siteAcao=Legislacao- Busca&nota=404.  
20. Silva CA. Infecções Virais na Unidade de Terapia Intensiva Neonatal in: Diagnóstico e Prevenção de IRAS em Neonatologia; 2ª Edição revisada e ampliada. Associação Paulista de Epidemiologia e Controle de Infecção - APECIH 2011; Capitulo 7:191-208.  
21. Simões EAF et al. The effect of respiratory syncytial virus on subsequent recurrent wheezing in atopic and nonatopic children. J Allergy Clin Immunol 2010; 126(2): 256-262.  
22. Sociedade Brasileira de Pediatria (SBP). Diretrizes para o Manejo da Infecção Causada pelo Vírus Sincicial Respiratório (VSR). Disponível em: http://www.sbp.com.br/pdfs/diretrizes_manejo_ infec_vsr_versao_final1.pdf. Acessado em: 14/03/2013.  
23. Straliotto SM et al. Viral etiology of acute respiratory infectios among children in Porto Alegre, RS, Brazil. Rev. Soc. Bras. Med. Trop. 2002; 35(4):283-91.  
24. The Impact-VSR Study Group. Palivizumab, a humanized Respiratory Syncytial Virus Monoclonal Antibody Reduces Hospitalization From Respiratory Syncytial Virus Infection in Highrisk Infants. Pediatrics. 1998; 102 (3): 531-7.  
25. The PREVENT study group. Reduction of respiratory syncytial virus hospitalization among premature infants and infants with bronchopulmonary dysplasia using respiratory syncytial virus immune globulin prophylaxis. Pediatrics. 1997; 99:93-99.  
26. University of Calgary. Techinical report. A populationbased study assessing the impact of palivizumabe of a prophylaxis program with palivizumabe on outcomes and associated health care resource utilization in infants at high risk of severe respiratory syncytial virus infection. April, 2004.  
27. Vieira RA, Diniz EMA, Vaz FAC. Clinical and laboratory study of newborns with lower respiratory tract infection due to respiratory viruses. J Matern Fetal Neonatal Med, 2003;13 :341-50.  
28. Vieira S, Giglio AE, Miyao et al. Sazonalidade do vírus respiratório sincicial na cidade de São Paulo, SP. Pediatria. 2002; 24(1/2):73-4.  
Vieira SE et al. Clinical Patterns and seasonal trends in respiratory syncytial virus hospitalizations in São Paulo, Brazil. Rev. Inst. Med Trop S Paulo. 2001; 43(3):125-131.

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: APÊNDICE -->
Modelo de Ficha de Solicitação de Palivizumabe

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **Identificação de Estabelecimento de Saúde Solicitante NOME DO ESTABELECIMENTO: CNES:** -->
**NOME DO PACIENTE: ENDEREÇO: CEP:** MUNICÍPIO: UF: **CNS:** DATA DE NASCIMENTO: SEXO:M F **NOME DA MÃE: TELEFONE: DDD ( )** CELULAR: DDD (   ) **Informações Complementares IDADE GESTACIONAL POR OCASIÃO DO NASCIMENTO: semanas GESTAÇÃO: Única Múltipla PESO DE NASCIMENTO: g** ESTATURA DE NASCIMENTO: cm **TIPO DE PARTO: Normal Cesárea Fórceps** Criança internada **APGAR 1':** APGAR 5' : (  ) Sim (  ) Não **DATA DA ALTA: _____/_____/______ PESO ATUAL: g Identificação de Estabelecimento de Saúde Solicitante NOME DO ESTABELECIMENTO: CNES:**  
**NOME DO PACIENTE: ENDEREÇO:**  
**CEP:** MUNICÍPIO: UF: **CNS:** DATA DE NASCIMENTO: SEXO:M F **NOME DA MÃE: TELEFONE: DDD ( )** CELULAR: DDD (   ) **Informações Complementares IDADE GESTACIONAL POR OCASIÃO DO NASCIMENTO: semanas GESTAÇÃO: Única Múltipla PESO DE NASCIMENTO: g** ESTATURA DE NASCIMENTO: cm

---

<!-- METADADOS: doenca: Palivizumabe para a Prevenção da Infecção pelo Vírus Sincicial Respiratório | secao: **TIPO DE PARTO: Normal Cesárea Fórceps** -->
Criança internada **APGAR 1':** APGAR 5' : (  ) Sim (  ) Não **DATA DA ALTA: _____/_____/______ PESO ATUAL: g**  
Documentos necessários para solicitação de Palivizumabe:  
I - RN ou criança internada e que preenche critério de uso:  
relatório médico com justificativa da solicitação assinado por médico que atende o paciente.  
II - Solicitação de doses pós-alta hospitalar:  
1 - Cópia da certidão de nascimento, comprovante de residência e do cartão SUS, para todos que preenchem critério de uso;  
2 - Pacientes prematuros: Anexar também cópia do relatório de alta hospitalar do berçário e informar doses já realizadas internados/ anotar também no cartão da criança;  
3 - Pacientes cardiopatas: Anexar cópia do relatório médico com a descrição da cardiopatia, o grau de hipertensão pulmonar e os medicamentos utilizados.

---

