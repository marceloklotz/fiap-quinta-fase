<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Geral -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 9, DE 02 DE JULHO DE 2025  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Miopatias Inflamatórias.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 4 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre as Miopatias Inflamatórias no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 977/2025 e o Relatório de Recomendação nº 980/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Miopatias Inflamatórias.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral de Miopatias Inflamatórias, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento de Miopatias Inflamatórias.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS nº 1.692, de 22 de novembro de 2016, publicada no Diário Oficial da União (DOU) nº 226, de 23 de novembro de 2016, seção 1, página 39.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES  
FERNANDA DE NEGRI  
**ANEXO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DE MIOPATIAS INFLAMATÓRIAS**

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **INTRODUÇÃO** -->
As miopatias inflamatórias (autoimunes) são um grupo heterogêneo de doenças raras que afetam adultos e crianças, sendo caracterizadas por inflamação crônica dos músculos estriados esqueléticos e com diversas manifestações clínicas, evolutivas e prognósticas<sup>1,2</sup> . A causa das miopatias inflamatórias é desconhecida, mas há relatos na literatura de processos exógenos, por exemplo, infecções e medicamentos, e susceptibilidade genética como fatores desencadeantes dessas enfermidades<sup>3</sup> . As miopatias inflamatórias podem ser subdivididas em dermatomiosite, dermatomiosite amiopática (ou clinicamente amiopática), polimiosite, miopatia necrosante imunomediada, síndrome antissintetase e miosite por corpos de inclusão<sup>1,2</sup> .  
Fraqueza, baixa resistência muscular e mialgia são sintomas frequentes das miopatias inflamatórias. Manifestações extramusculares, como erupções cutâneas, disfagia de condução, artrite, doença pulmonar intersticial e acometimento cardíaco também podem ocorrer, enfatizando a natureza inflamatória sistêmica dessas enfermidades<sup>4</sup> . A dermatomiosite pode ainda apresentar manifestações cutâneas, tais como erupções violáceas periorbitárias - muitas vezes edematosas (heliótropo) e lesões eritematosas nas superfícies extensoras das articulações das mãos (pápulas de Gottron)<sup>4,5</sup> . A dermatomiosite amiopática ou clinicamente amiopática envolve pacientes que não mostram evidência clínica de doença muscular em exame físico ou análise de enzimas musculares por pelo menos 6 meses<sup>6</sup> . A polimiosite, por sua vez, é definida pela presença de fraqueza muscular progressiva e predominantemente proximal dos membros, além de concentrações elevadas de enzimas musculares (por exemplo: creatinofosfoquinase) e sem as erupções cutâneas comumente observadas na dermatomiosite. A polimiosite raramente ocorre na infância e a maioria dos casos é diagnosticada após a segunda década de vida<sup>4,7</sup> .  
A miopatia necrosante imunomediada é caracterizada por fraqueza muscular intensa, com instalação subaguda, e concentrações altas de enzimas musculares. Do ponto de vista de biópsias musculares, há evidências de necrose das fibras musculares com macrofagia e ausência de infiltrados inflamatórios linfomononucleares. A síndrome antissintetase, por sua vez, é caracterizada por apresentar anticorpos anti-aminoacil-RNAt sintetases (anti-ARS), por exemplo, anti-Jo-1, anti-PL-7 e antiPL-12, e pelas seguintes manifestações clínicas: miosite, pneumopatia intersticial, artrite, febre de origem desconhecida, fenômeno de Raynaud e “mãos de mecânico”<sup>8,9</sup> . A miosite por corpos de inclusão é caracterizada por fraqueza muscular insidiosa, com acometimento da musculatura estriada esquelética, tanto proximal quanto distal dos membros, sendo mais comum em pacientes do sexo masculino e com mais de 50 anos<sup>1,8</sup> .  
Em crianças, a dermatomiosite juvenil é o tipo de miopatia mais prevalente, sendo responsável por, aproximadamente, 80% dos casos<sup>10,11</sup> . A incidência de miopatias inflamatórias em crianças varia consideravelmente entre os diferentes países. No Reino Unido a incidência anual é de 2 casos por milhão, enquanto nos Estados Unidos é estimada em 3,2 casos por milhão<sup>10,11</sup> . A idade de início da doença é variável, com idade média de 7 anos. Em 25% das crianças, o início é antes dos 5 anos e as meninas são cerca de três vezes mais afetadas do que os meninos<sup>10,11</sup> . Embora as miopatias inflamatórias compartilhem várias características entre adultos e crianças, incluindo fraqueza muscular proximal e erupções cutâneas, existem diferenças importantes: crianças com miopatias são mais propensas a desenvolver calcinoses; a distribuição de autoanticorpos miositeespecíficos são diferentes entre crianças e adultos; a doença pulmonar intersticial é menos frequente em crianças; a mortalidade é menor em crianças do que em adultos e o aumento do risco de neoplasias não é observado nas miopatias inflamatórias durante a infância, enquanto essa associação está bem estabelecida em adultos<sup>12</sup> .  
A incidência estimada de miopatias inflamatórias em adultos é de 1 a 5 casos por 100.000 indivíduos ao redor do mundo<sup>13</sup> . A incidência aumenta com a idade, com um pico em aproximadamente 50 anos tanto na Europa quanto na América do Norte<sup>4</sup> . Particularmente no Brasil, os dados epidemiológicos sobre miopatias inflamatórias são escassos. Os dados disponíveis sugerem  
que polimiosite, dermatomiosite e miopatia necrosante imunomediada são mais comuns em mulheres e a miopatia por corpos de inclusão é mais comum em homens. Não há sinais claros sugerindo diferenças na incidência e prevalência entre as diferentes regiões ou etnias<sup>4</sup> .  
Em geral, o prognóstico de miopatias inflamatórias é favorável. A associação das miopatias com neoplasias prevê um prognóstico ruim para a recuperação e aumenta a mortalidade. Aproximadamente um terço dos indivíduos com dermatomiosite juvenil se recuperam, outra parcela tem um curso redicivante e alguns têm um curso mais crônico da doença. O prognóstico para polimiosite varia. A maioria dos indivíduos responde bem ao tratamento, porém alguns pacientes têm a forma mais grave da doença e não respondem adequadamente às abordagens terapêuticas, podendo desenvolver manifestações significativas<sup>14,15</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios de diagnóstico, tratamento e monitoramento das miopatias inflamatórias.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- M33.0 Dermatomiosite juvenil  
- M33.1 Outras dermatomiosites  
- M33.2 Polimiosite

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **DIAGNÓSTICO** -->
A definição do diagnóstico de miopatias inflamatórias é feita quando as manifestações clínicas e laboratoriais típicas estão presentes e outras possíveis causas são excluídas. No entanto, inexistem critérios de diagnóstico formais e os critérios de classificação são usados para orientação clínica<sup>4</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **3.1. Critérios classificatórios de Bohan e Peter** -->
Os critérios usados para a classificação das miopatias inflamatórias são os propostos por Bohan e Peter<sup>19,20</sup> , publicados em 1975. Essa é uma avaliação desenvolvida para orientar profissionais de saúde no diagnóstico correto por meio da combinação da avaliação de sinais, sintomas e resultados de exames. Esses critérios incluem manifestações musculares e cutâneas e a exclusão de outras condições que causam miopatias, incluindo as metabólicas e hereditárias (por exemplo: distrofias musculares). São propostas definições de diagnóstico “definido”, “provável” ou “possível” para cada subconjunto de miopatias inflamatórias, as quais podem ser diferenciadas pela presença de erupções cutâneas clássicas da dermatomiosite<sup>19,20</sup> . O **Quadro 1** resume os critérios classificatórios e os parâmetros de diagnóstico para a condição.  
**Quadro 1.** Critérios classificatórios de Bohan e Peter para miopatias inflamatórias  
|**Critérios**||**Definição**|
|---|---|---|
|1. Fraqueza muscular proximal simétrica|Progride ao longo de semanas<br>diafragmática|a meses com ou sem disfagia ou fraqueza|
|2. Elevação dos níveis de enzimas musculares<br>esqueléticas|Enzimas elevadas incluem<br>transaminase (AST/TGO), alan<br>desidrogenase láctica (DHL)|creatinofosfoquinase (CPK), aspartato<br>ina transaminase (ALT/TGP), aldolase e/ou|  
||Potenciais de unidade motora polifá|sico, curto e pequeno; potencial de|
|---|---|---|
|3. Eletromiografia anormal|fibrilação; ondas agudas positivas; au<br>descargas repetitivas de alta frequênc|mento da irritabilidade de inserção e<br>ia|
|4. Biópsia muscular anormal|Presença de degeneração, regeneração|, necrose e infiltrados mononucleares|
|5. Erupção cutânea típica da dermatomiosite|Erupção de heliotrópica ou sinal/pápu|las de Gottron|
|**Parâmetro diagnóstico**|||
|**Diagnóstico**|**Dermatomiosite**|**Polimiosite**|
|Definido|Presença de três critérios entre 1 e 4<br>mais o critério “5. Erupção cutânea<br>típica da dermatomiosite”|Presença de todos os critérios entre<br>1 e 4|
||Presença de dois critérios entre 1 e 4||
|Provável|mais o critério “5. Erupção cutânea<br>típica da dermatomiosite”|Presença de três critérios entre 1 e 4|
|Possível|Presença de um critério entre 1 e 4<br>mais o critério “5. Erupção cutânea<br>típica da dermatomiosite”|Presença de dois critérios entre 1 e 4|  
Fonte: Adaptado de Findlay et al. (2015)<sup>21</sup>  
No entanto, a limitação dos critérios de Bohan e Peter é a baixa especificidade, permitindo inclusão errônea de outros tipos de miopatias, como a metabólica e hereditária, na definição das miopatias inflamatórias<sup>22</sup> . Assim, este Protocolo também preconiza os critérios classificatórios da _European League Against Rheumatism/American College of Rheumatology_ (EULAR/ACR 2017).  
A biópsia muscular demonstra as alterações histológicas características de uma miopatia inflamatória. Além disso, em muitos casos, a biópsia mostrará alterações adicionais e mais específicas, permitindo corroborar na caracterização de miopatias inflamatórias<sup>23,24</sup> .  
As enzimas musculares são elevadas na maioria dos pacientes com doença muscular ativa. Outras enzimas séricas, incluindo CPK, aldolase, DHL, AST/TGO e ALT/TGP, desempenham papeis importantes na caracterização e no acompanhamento da atividade das doenças. No entanto, não são específicas e podem ser elevadas em outros tipos de miopatias, como as não-autoimunes. Qualquer uma dessas enzimas pode ser elevada independentemente das outras; portanto, recomendase que todas as enzimas sejam preferencialmente testadas durante a avaliação da suspeita de uma miopatia inflamatória<sup>4,7</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **3.2. Critérios classificatórios de EULAR/ACR 2017** -->
Os critérios classificatórios desenvolvidos pela EULAR/ACR<sup>25</sup> , publicados em 2017, auxiliam não só na caracterização  
de uma miopatia inflamatória, mas também na identificação dos principais subgrupos: dermatomiosite, dermatomiosite amiopática, polimiosite, miosite por corpos de inclusão, dermatomiosite juvenil ou outro tipo de miosite juvenil. Essa classificação é baseada em seis itens e respectivos subitens ( **Quadro 2** ):  
- (1) idade de início dos primeiros sintomas;  
- (2) fraqueza muscular (dos membros superiores e inferiores, e da região cervical);  
- (3) manifestações cutâneas;  
- (4) outras manifestações;  
- (5) características laboratoriais, e

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: (6) características da biópsia muscular. -->
Os resultados com ou sem biópsia muscular estão disponíveis para representar algumas configurações clínicas ou ciclos de vida, como pediatria, na qual a realização de biópsia muscular não é padrão de cuidado.  
**Quadro 2.** Critérios de diagnóstico de EULAR/ACR 2017 para miopatias inflamatórias idiopáticas adultas e juvenis  
|**Variável**<br>1. Idade de início|**P**<br>**Sem**<br>**biópsia**<br>**muscular**|**ontos**<br>**Com biópsia**<br>**muscular**|**Definição**|
|---|---|---|---|
|Idade de início do primeiro sintoma||||
|relacionado à doença entre 18 e menos<br>de 40 anos (vide nota 1)|1,3|1,5||
|Idade de início do primeiro sintoma<br>que se supõe estar relacionado à<br>doença igual ou maior que 40 anos|2,1|2,2||
|(vide nota 1)||||
|2. Fraqueza muscular||||
|Fraqueza simétrica objetiva,<br>geralmente progressiva,<br>predominantemente proximal nas<br>extremidades superiores|0,7|0,7|Fraqueza predominantemente proximal das<br>extremidades superiores, conforme definido por<br>testes musculares manuais ou outros testes<br>objetivos de força, que estão presentes em ambos<br>os lados e geralmente são progressivos ao longo<br>do tempo|
|Fraqueza simétrica objetiva,<br>geralmente progressiva,<br>predominantemente proximal nas<br>extremidades inferiores|0,8|0,5|Fraqueza predominantemente proximal das<br>extremidades inferiores, conforme definido por<br>testes musculares manuais ou outro teste de força<br>objetivo, que está presente em ambos os lados e<br>geralmente é progressivo ao longo do tempo|
|Os flexores cervicais são relativamente<br>mais fracos que os extensores do<br>pescoço|1,9|1,6|Os graus musculares para flexores cervicais são<br>relativamente mais baixos do que os extensores do<br>pescoço, conforme definido por testes musculares<br>manuais ou outros testes objetivos de força|
||||Os graus musculares para os músculos proximais|
|Nas pernas, os músculos proximais são<br>relativamente mais fracos do que os<br>músculos distais|0,9|1,2|nas pernas são relativamente mais baixos do que<br>os músculos distais nas pernas, conforme definido<br>por testes musculares manuais ou outros testes<br>objetivos de força|
|3. Manifestações cutâneas||||
||||Manchas roxas, lilás ou eritematosas sobre as|
|Erupção cutânea (heliotropo)|3,1|3,2|pálpebras ou em uma distribuição periorbitária,<br>frequentemente associadas a edema periorbitário|  
|**Variável**|**Po**<br>**Sem**<br>**biópsia**<br>**muscular**|**ntos**<br>**Com biópsia**<br>**muscular**|**Definição**|
|---|---|---|---|
|Pápulas de Gottron|2,1|2,7|Pápulas eritematosas a violáceas sobre as<br>superfícies extensoras das articulações, que às<br>vezes são escamosas. Pode ocorrer nas articulações<br>dos dedos, cotovelos, joelhos, maléolos e dedos dos<br>pés|
|Sinal de Gottron|3,3|3,7|Máculas eritematosas a violáceas sobre as<br>|
||||superfícies extensoras das articulações|
|4. Outras manifestações||||
|Disfagia ou dismotilidade esofágica|0,7|0,6|Dificuldade em engolir ou evidência objetiva de<br>|
||||dismotilidade do esôfago|
|5. Medições laboratoriais clínicas|||Teste de autoanticorpos no soro realizado com teste|
|Autoanticorpo anti-Jo-1 (anti-histidil<br>RNA transportadora sintetase) presente|3,9|3,8|<br>padronizado e validado, mostrando resultado<br>positivo|
|Concentrações séricas elevadas de CPK<br>ou DHL ou AST/TGO ou ALT/TGP**<br>(vide nota 2)|1,3|1,4|Os valores de teste mais anormais durante o curso<br>da doença (nível absoluto mais alto da enzima)<br>acima do limite superior relevante da normalidade|
|6. Características da biópsia musc|ular|||
|Infiltrado de células mononucleares ao<br>redor, mas não invadindo as miofibras,<br>na região endomisial|-|1,7|A biópsia muscular revela células mononucleares<br>endomisiais adjacentes ao sarcolema de fibras<br>musculares não necróticas, de outra forma<br>saudáveis, mas não há invasão clara das fibras<br>musculares|
|Infiltrado de células mononucleares na<br>região perimísio e/ou perivascular|-|1,2|As células mononucleares estão localizadas no<br>perimísio e/ou localizadas ao redor dos vasos<br>sanguíneos (em vasos perimisiais ou endomisiais)|
|Atrofia perifascicular|-|1,9|A biópsia muscular revela várias fileiras de fibras<br>musculares<br>que<br>são<br>menores<br>na<br>região<br>perifascicular do que fibras mais localizadas<br>centralmente|
|Vacúolos com bordas marginadas<br>**Notas:**|-|3,1|Os vacúolos com aro são azulados por coloração de<br>hematoxilina e eosina e avermelhados por<br>colorações modificadas de tricrômico de Gomori|  
Nota 1: Considerar 0 (zero) caso não se aplique ao paciente em avaliação;  
Nota 2: Níveis séricos acima do limite superior da normalidade para estes exames. **Fonte:** adaptado de Lundberg et al. (2017)<sup>(23)</sup>  
A pontuação total obtida no EULAR/ACR 2017 é convertida em uma probabilidade de ter miopatias inflamatórias idiopáticas visualmente ou utilizando fórmulas matemáticas (Figura 1)<sup>(24).</sup>  
**Figura 1** . Ferramenta visual para identificação da probabilidade de ter miopatias inflamatórias idiopáticas.  
<!-- Start of picture text -->
‘A~Sem bidpsia muscular B - Com bidpsia muscular<br>a\a<br>falaI| Za4 ||<br>Bey<br>a i:<br>7 _— leis ——<br>1 1<br>[1 + exponencial(5,33 — escore)] |[1 + exponencial(6,49 — escore)|<br><!-- End of picture text -->  
Nota: Para aplicação desta fórmula, sugere-se à utilização da calculadora web, disponível apenas em língua inglesa (www.imm.ki.se/biostatistics/calculators/iim). Fonte: Varniet et al (2020)<sup>23</sup> , Ahn et al (2022)<sup>24</sup>  
O desempenho muscular é geralmente avaliado por meio de fraqueza muscular, utilizando testes musculares manuais ou por meio de resistência muscular pelo índice funcional<sup>25</sup> .  
A pontuação total no EULAR/ACR 2017 permite assim a classificação dos casos em:  
- **Definitivo:** probabilidade maior ou igual a 90%  
- **Provável:** probabilidade entre 55% e 89%  
- **Possível:** probabilidade entre 50% e 55%  
- **Sem miopatia inflamatória idiopática:** probabilidade menor que 50%.  
- A Figura 2 apresenta a classificação dos casos conforme a EULAR/ACR 2017.  
**Figura 2** . Classificação dos casos conforme pontuação total no EULAR/ACR 2017.  
|**Definitivo**|**Provável**|**Possível**|**Sem miopatia**<br>**idiopática**|**inflamatória**|
|---|---|---|---|---|
|Probabilidade maior ou igual|Probabilidade entre 55% e|Probabilidade entre 50% e|Probabilidade|menor<br>que|
|a 90%|89%|55%|50%||

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **3.3. Outros aspectos diagnósticos** -->
Embora a presença de autoanticorpos venha sendo incluída na avaliação de pacientes com miopatias inflamatórias em diretrizes clínicas internacionais, é escassa a evidência de como o conhecimento de sua existência pode impactar no prognóstico dos pacientes. Assim, a pesquisa desses autoanticorpos não é recomendada por este Protocolo.  
Os anticorpos podem ser categorizados como autoanticorpos miosite-associados (anti-PM/Scl, anti-Ro52, anti-Ku e antiU1-RNP) ou autoanticorpos miosite-específicos (anti-Jo-1, anti-Mi-2, anti-MDA-5, anti-TIF1g, anti-SAE e anti-NXP-2). A presença de anticorpos anti-Jo-1 foi a primeira a ser descrita e está fortemente associada à doença pulmonar intersticial, além de febre persistente e sem causa aparente, miosite, fenômeno de Raynaud, “mãos de mecânico” e artrite<sup>3,21,27</sup> , o que foi confirmado na síntese de evidências ( **Apêndice 1** ). Por ter baixa prevalência na população com miopatias inflamatórias e por estar presente, também, em outras doenças inflamatórias, testar o anti-Jo1, em geral, não é considerado determinante para o diagnóstico das  
miopatias<sup>3,21,27</sup> . Entretanto, faltam estudos que demonstrem a alteração da conduta médica e seus benefícios, após se detectar o autoanticorpo.  
A ressonância magnética foi incorporada aos critérios do Centro Neuromuscular Europeu (ENMC), que incluem achados de ressonância magnética e alguns autoanticorpos específicos da miosite para ajudar a diferenciar dermatomiosite e polimiosite. Ainda que essa técnica possa contribuir para a avaliação da inflamação muscular em termos de localização, extensão e intensidade, seus achados musculares não são específicos para miosites<sup>23</sup> . Portanto, a realização desse exame não é recomendada por este Protocolo. A capilaroscopia periungueal também é um procedimento seguro e não invasivo que permite o diagnóstico do fenômeno de Raynaud<sup>23</sup> .  
Em pacientes com miopatias inflamatórias, o diagnóstico de doença pulmonar intersticial é geralmente baseado em uma combinação de fatores como: apresentação clínica, testes laboratoriais, tomografia computadorizada e resultados do teste de função pulmonar. Em geral, o resultado da tomografia é usado para determinar o tipo de doença pulmonar. A biópsia pulmonar, embora não indicada para determinação do tipo de doença pulmonar, pode ser justificada para descartar um processo alternativo, como malignidade<sup>28</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes com diagnóstico provável ou definitivo de miopatias inflamatórias, considerando os critérios de Bohan-Peter ou do EULAR/ACR 2017.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento neste Protocolo deverão ser excluídos ao uso do respectivo medicamento preconizado.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **TRATAMENTO** -->
O tratamento de miopatias inflamatórias é desafiador devido à baixa prevalência, natureza heterogênea e curso variável dessa condição. A recomendação de um plano terapêutico ideal para miopatias inflamatórias é afetada pela falta de consenso sobre classificação, ensaios clínicos relevantes, relatórios e medidas de resultado padronizadas que se correlacionam com mudanças na incapacidade do paciente e na qualidade de vida. O cuidado precisa ser individualizado dependendo da gravidade da fraqueza, duração da doença, presença de manifestações extramusculares (erupção cutânea, disfagia de condução, dispneia, artralgia, febre), malignidade, idade e comorbidades do paciente. Para um prognóstico favorável, o diagnóstico deve ser feito o mais breve possível<sup>29</sup> . Os objetivos do tratamento são melhora da capacidade de realizar atividades diárias, aumento e melhora da força muscular, prevenção do desenvolvimento de complicações extramusculares e controle das manifestações de pele (dermatomiosite)<sup>30-33</sup> .  
O tratamento de miopatias inflamatórias é multidisciplinar, baseado no uso de glicocorticoides, imunossupressores ou imunomoduladores tradicionais, no monitoramento de eventos adversos dos medicamentos e prevenção de complicações, além de terapias adicionais que incluem: exercícios físicos, profilaxia da aspiração das vias aéreas; proteção solar e apoio psicológico<sup>21,34</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **6.1. Tratamento não medicamentoso** -->
Exercícios físicos em combinação com o tratamento medicamentoso são fundamentais no tratamento das miopatias inflamatórias. Ensaios clínicos controlados demonstraram melhora da força, condicionamento físico e efeitos moleculares no tecido muscular, sugerindo redução da inflamação, aumento da densidade capilar e melhoria da função mitocondrial dos tecidos musculares<sup>35,36</sup> . Estudos sugerem fisioterapia e reabilitação com progressão gradual e regimes de exercícios adaptados à gravidade da fraqueza<sup>37,38</sup> .  
A disfagia de transporte pode ser uma manifestação grave para pacientes com miopatias inflamatórias, sendo necessário investigar a causa e definir o cuidado adequado. Algumas intervenções podem reduzir o risco de aspiração, tais como: avaliação com fonoaudiólogo para aconselhamento sobre o risco de aspiração e precauções; manter a cabeceira da cama elevada e avaliação com nutricionista sobre dieta apropriada<sup>39</sup> .  
A fotoproteção também é recomendada, uma vez que as erupções cutâneas são frequentemente relacionadas à fotossensibilidade<sup>40,41</sup> . Ainda, diretrizes internacionais aconselham o acompanhamento psicológico de pacientes acometidos por miopatias inflamatórias<sup>33</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **6.2. Tratamento medicamentoso** -->
O tratamento medicamentoso das miopatias inflamatórias depende em parte do subgrupo específico dessa condição. Por exemplo, pacientes com miosite por corpos de inclusão não costumam responder ao tratamento imunossupressor, enquanto as outras formas de miopatias com maiores graus de inflamação muscular geralmente respondem a estes medicamentos<sup>42-44</sup> . Os medicamentos usados para o tratamento de miopatias incluem glicocorticoides, como prednisona e metilprednisolona, imunossupressores ou imunomoduladores tradicionais, como metotrexato, azatioprina, ciclosporina, ciclofosfamida e imunoglobulina humana<sup>31,32,45</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Glicocorticoides** -->
Prednisona e metilprednisolona são a base do tratamento inicial para miopatias inflamatórias, apesar da ausência de diretrizes e ensaios clínicos que recomendem a sua utilização. Esses medicamentos normalizam as concentrações séricas das enzimas musculares e melhoram a força muscular. Em pacientes com formas graves de miopatias ou manifestações extramusculares (fraqueza acentuada, disfagia grave ou doença pulmonar intersticial progressiva) é administrada pulsoterapia parenteral com metilprednisona intravenosa. A maioria dos pacientes respondem ao tratamento com medicamentos glicocorticoides, outros se tornam resistentes e a adição de imunossupressor pode ser necessária. A decisão de iniciar tal terapia é baseada em alguns fatores, como: necessidade de um efeito poupador de glicocorticoides, doenças refratárias, duração da terapia com glicocorticoides e eventos adversos associados. Como os efeitos da terapia com glicocorticoides a longo prazo são numerosos, discutir o risco com o paciente e estabelecer um plano de monitoramento são parte integrantes do plano de gerenciamento da doença<sup>31,32,45,46</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Imunossupressores** -->
Os medicamentos imunossupressores metotrexato, azatioprina, ciclosporina e ciclofosfamida são comumente associados a glicocorticoides no tratamento das miopatias inflamatórias.  
A maioria dos clínicos inicia a terapia com metotrexato ou azatioprina em combinação com glicocorticoides para as miopatias inflamatórias, a menos que o paciente apresente contraindicações<sup>31,32,45</sup> .  
O metotrexato é um antifolato que inibe a proliferação de linfócitos<sup>47</sup> . Estudos retrospectivos sugerem a eficácia do metotrexato em pacientes com miopatias inflamatórias, mesmo para aqueles com falha na monoterapia inicial com glicocorticóides<sup>48,49</sup> . Embora o metotrexato não seja usado especificamente para tratar a doença pulmonar intersticial associada à miosite, ele deve ser usado com cautela em pacientes que apresentem essa condição, uma vez que, apesar de rara, pode ocorrer toxicidade pulmonar que leva à pneumonite com o uso do medicamento. O monitoramento da toxicidade do metotrexato deve  
incluir um hemograma completo para avaliar a supressão da medula óssea, juntamente com a avaliação das concentrações séricas de enzimas hepáticas e da função renal<sup>46</sup> .  
A azatioprina é um derivado da mercaptopurina que inibe o metabolismo da purina, interferindo assim na replicação celular<sup>50</sup> . A azatioprina é preferível para pacientes em uso de álcool, com doença hepática ou doença pulmonar intersticial<sup>46</sup> e, geralmente, é eficaz após 4 a 8 meses<sup>51,52</sup> . A combinação entre azatioprina e metotrexato demonstrou superioridade quando comparado ao tratamento somente com metotrexato em um estudo de miopatias refratárias, porém os resultados foram limitados pelo pequeno número de pacientes e pelo abandono de tratamento de vários desses pacientes<sup>53</sup> .  
A ciclosporina é um inibidor da calcineurina que inibe a produção e liberação das células T<sup>54</sup> . Tem sido usada como segunda linha em pacientes com miopatia refratária e fraqueza muscular ou doença pulmonar intersticial associada<sup>55</sup> . Os efeitos tóxicos de inibidores da calcineurina exigem um plano de monitoramento intenso, incluindo a verificação dos níveis sanguíneos periodicamente<sup>56</sup> .  
A ciclofosfamida, um agente alquilante, é usada em casos refratários de miopatias, doença pulmonar intersticial grave ou vasculite sistêmica associada a dermatomiosite ou polimiosite<sup>4</sup> . Um estudo retrospectivo avaliou o uso de ciclofosfamida para doença pulmonar intersticial em uma série de 17 pacientes. Os participantes receberam doses mensais de ciclofosfamida por pelo menos seis meses, além da prednisona diária. Em 11 dos 17 pacientes, a dispneia melhorou; seis dos sete pacientes que necessitavam de oxigênio suplementar foram capazes de suspender o uso suplementar de oxigênio; 12 pacientes apresentaram melhora da capacidade vital forçada em pelo menos 10%<sup>57</sup> . A utilidade da ciclofosfamida é limitada pelo seu potencial de toxicidade, particularmente, a indução de malignidade. Na ausência de doença pulmonar intersticial agressiva ou vasculite sistêmica, a ciclofosfamida deve ser considerada apenas em pacientes que não respondem a outros agentes de segunda linha, como a ciclosporina<sup>39</sup> .  
O medicamento micofenolato de mofetila não é preconizado neste Protocolo, devido a insuficiência de evidências que sustentem a sua utilização para o tratamento de miopatias inflamatórias ( **Apêndice 1)** .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Imunoglobulinas** -->
A imunoglobulina humana é usada no tratamento de segunda ou terceira linha, em combinação ou após a falha de glicocorticoides ou outros medicamentos imunossupressores<sup>39</sup> . A eficácia e segurança da imunoglobulina foi relatada pela primeira vez em um ensaio duplo-cego, cruzado e controlado em 15 pacientes com dermatomiosite refratária<sup>39</sup> . Posteriormente, um ensaio clínico de fase III, randomizado e controlado por placebo, confirmou a eficácia e a segurança da imunoglobulina humana na dermatomiosite refratária com fraqueza muscular e erupção cutânea<sup>39</sup> . Recentemente, um ensaio clínico fase III randomizado, controlado por placebo envolvendo 95 pacientes adultos com dermatomiosite demonstrou melhora em 79% dos pacientes tratados com imunoglobulina durante 16 semanas<sup>39</sup> . Em outro estudo prospectivo envolvendo 35 pacientes com polimiosite, o tratamento com imunoglobulina foi associado a uma melhora clínica em 70% dos pacientes, com eficácia estável relatada em metade dos pacientes três anos após a interrupção da imunoglobulina<sup>39</sup> . Uma das principais vantagens desse medicamento é sua segurança no cenário de uma infecção ativa e seu uso concomitante com outros agentes imunossupressores. Mas o alto custo da imunoglobulina humana e a logística para administração podem influenciar as decisões sobre seu uso a longo prazo<sup>4,46</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Antimaláricos** -->
O gerenciamento de manifestações cutâneas da dermatomiosite pode ser desafiador. A melhor abordagem terapêutica para as manifestações cutâneas da dermatomiosite ainda permanece pouco clara. Os dados sobre terapias são limitados e restritos principalmente a relatos de casos e estudos retrospectivos<sup>39,58</sup> . A hidroxicloroquina é frequentemente a terapia de primeira linha para dermatomiosite considerando o histórico de seu uso para esta indicação. No entanto, muitos pacientes podem precisar de terapia sistêmica adicional, dado que os antimaláricos são inadequados para outras manifestações comuns da dermatomiosite, como doenças musculares ou pulmonares<sup>32,33,39</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Outras formas de tratamento** -->
O uso de inibidores de fator de necrose tumoral alfa (anti-TNFa), como infliximabe e etanercepte, na prática clínica tem sido baseado em poucos estudos com um pequeno número de pacientes e que não demonstraram vantagem frente a outras terapias<sup>59,60</sup> . O tratamento com esses medicamentos não é habitualmente recomendado em pacientes com miopatias inflamatórias<sup>31-33</sup> e tampouco é recomendado neste Protocolo.  
A calcinose é a apresentação mais grave e desafiadora da dermatomiosite. O controle da doença com agentes imunossupressores tradicionais é necessário, mas muitas vezes não é suficiente para o seu tratamento. Bisfosfonatos, diltiazem, rituximabe, imunoglobulina humana e tiossulfato de sódio também são relatados na literatura como prováveis tratamentos para calcinose, apesar das evidências serem inconclusivas<sup>32,61,62</sup> . Tocilizumabe e abatacepte estão sendo estudados para o tratamento de miopatias inflamatórias e um número limitado de resultados indica melhora da força muscular<sup>63,64</sup> . No entanto, as informações disponíveis até o momento não são suficientes para sustentar a recomendação de sua utilização no SUS.  
O medicamento rituximabe não é recomendado neste Protocolo, devido à insuficiência de evidências que sustentem a sua utilização para o tratamento de miopatias inflamatórias ( **Apêndice 1)** .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **6.2.1. Medicamentos** -->
- Azatioprina: comprimidos de 50 mg;  
- Ciclofosfamida: pó para solução injetável de 200 mg e 1.000 mg;  
- Ciclosporina: cápsulas de 10 mg, 25 mg, 50 mg, 100 mg e solução oral de 100 mg/mL;  
- Imunoglobulina humana: pó para solução injetável ou solução injetável de 0,5 g, 1 g, 2,5 g e 5 g;  
- Metilprednisolona: pó para solução injetável de 500 mg;  
- Metotrexato: comprimidos de 2,5 mg ou solução injetável de 25 mg/mL;  
- Prednisona: comprimidos de 5 e 20 mg;  
- Sulfato de hidroxicloroquina: comprimidos de 400 mg.  
Nota: Os medicamentos ciclofosfamida e metilprednisolona estão contemplados em procedimentos de pulsoterapia, sendo  
seu fornecimento de responsabilidade do serviço, não sendo dispensados no âmbito da Assistência Farmacêutica.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Prednisona** -->
- Adultos: administração via oral, 1 mg/kg/dia (máximo: 80 mg/dia) durante 4-6 semanas. Se houver controle da doença, iniciar diminuição gradual da dose, reduzindo-se até 20% da dose vigente a cada 4 semanas até atingir 10 mg/dia. Manter a corticoterapia conforme evolução clínica até completar 9 a 12 meses de tratamento. Nos casos refratários ou recidivantes, seu uso poderá exceder 12 meses. Em caso de recidiva durante a redução de dose, deve-se retornar à mínima dose efetiva e adicionar azatioprina ou metotrexato (ou ajustar as doses desses medicamentos, se já em uso). Recomenda-se monitoramento cuidadoso, pois o uso de altas doses (1 mg/kg/dia) por mais de 6 semanas pode aumentar o risco de desenvolver miopatia associada a glicocorticoides<sup>39</sup> .  
- Crianças e adolescentes (menores de 18 anos): administração via oral, 1 a 2 mg/kg/dia (máximo: 60 mg/dia) durante 4 semanas. Se houver resposta adequada, iniciar redução gradual (0,5 mg/kg a cada 2 semanas com base na resposta até que a dose seja 0,5 mg/kg/dia). Em seguida, diminuir a cada 4 semanas conforme tolerância<sup>39</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Metilprednisona (pulsoterapia)** -->
- Adultos: administração por pulsoterapia em pacientes com envolvimento sistêmico grave ou fraqueza intensa, administrar 1.000 mg por via intravenosa por, pelo menos, 30 minutos durante 3 a 5 dias consecutivos, seguido de glicocorticoide oral<sup>39</sup> . Repetir mensalmente conforme resposta terapêutica.  
- Crianças e adolescentes (menores de 18 anos): administração por via intramuscular ou intravenosa, doses iniciais de 10 a 40 mg. Caso seja necessário o uso de doses elevadas, é recomendado 30 mg/kg por via intravenosa durante 30 minutos, repetido a cada 4 a 6 horas por até 48 horas, chegando ao máximo de 1.000 mg ao dia. Deve-se continuar a terapia com altas doses até que a condição do paciente se estabilize entre 48 e 72 horas (três dias consecutivos)<sup>65</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Azatioprina** -->
- Adultos: administração via oral, iniciar com 50 mg uma vez ao dia em combinação com um glicocorticoide. A dose pode ser alterada a partir de 6 a 8 semanas para 1,5 mg/kg/dia. Em casos de resposta insatisfatória em 3 meses, o aumento de dose gradual, em intervalos de 4 semanas, pode ser realizado até 2,5 a 3 mg/kg/dia. Os incrementos de dose devem ser de 0,5 mg/kg ou, aproximadamente, 25 mg diariamente<sup>39,66</sup> .  
- Crianças e adolescentes (menores de 18 anos): administração via oral, a dose inicial, geralmente, é de 1 a 3 mg/kg/dia, e deve ser ajustada dentro desses limites de acordo com a resposta clínica e com a tolerância hematológica. Não exceder 150 mg/dia<sup>33,50</sup> .  
O início da resposta clínica à azatioprina pode demorar 4 a 6 meses. Quando a resposta terapêutica for evidente, considerar a redução da dose de manutenção até o nível mais baixo compatível com a manutenção da resposta.<sup>33,39,50</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Metotrexato** -->
- Adultos: administração via oral, subcutânea ou intramuscular - dose inicial de 7,5 a 15 mg uma vez por semana. A dose pode ser ajustada em 2,5 mg/semana, a cada 2 a 4 semanas, com base na resposta clínica, até 25 mg/semana<sup>39</sup> .  
- Crianças e adolescentes (menores de 18 anos): administração por via oral, subcutânea ou intramuscular - dose inicial  
- de 15 a 20 mg/m<sup>2</sup> ou 1 mg/kg uma vez por semana. A dose máxima é de 40 mg/dose<sup>39</sup> .  
A associação de ácido fólico (5 a 10 mg/semana) após 24 a 48 horas da última dose é recomendada para minimizar os eventos adversos do metotrexato<sup>39, 47, 65</sup> .  
O metotrexato é utilizado em combinação com glicocorticoides ou como alternativa à terapia inicial em pacientes que não podem usar glicocorticoides<sup>39</sup> .  
A bula do metotrexato injetável recomenda a administração pelas vias intravenosa, intramuscular ou intratecal<sup>47</sup> . Porém, seu uso por via subcutânea no tratamento de miopatias inflamatórias está de acordo com orientações de bases de dados sobre medicamentos<sup>39,65 67,68</sup> , pois essa via reduz a intolerância gástrica e tem melhor biodisponibilidade em doses elevadas. A administração do metotrexato por via oral pode ter absorção errática devido à saturação do mecanismo de transporte ativo do fármaco no intestino, razão pela qual não é a preferível<sup>39,69,70</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Ciclosporina** -->
- Adultos: administração via oral, dose de 3 a 6 mg/kg/dia divididos em duas doses<sup>15,21,54,47,65</sup> .  
- Crianças e adolescentes (menores de 18 anos): administração via oral, dose de 3 a 5 mg/kg/dia divididos em duas  
- doses<sup>71</sup> , podendo-se aumentar até a dose máxima de 6 mg/kg/dia<sup>54</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Ciclofosfamida (pulsoterapia)** -->
- Adultos: administração por via intravenosa - doses de 500 a 750 mg/m<sup>2</sup> a cada 4 semanas; sugere-se não exceder 1.200 mg/dose<sup>39</sup> .  
- Crianças e adolescentes (menores que 18 anos): administração por via intravenosa - doses de 500 a 750 mg/m<sup>2</sup> a cada  
4 semanas<sup>39</sup> .  
Este medicamento é utilizado como adjuvante de glicocorticoides e outros agentes imunossupressores em pacientes com doença grave refratária a outras terapias preferíveis ou como parte da terapia inicial combinada em pacientes com insuficiência respiratória iminente<sup>39</sup> .  
**Imunoglobulina humana**  
 Adultos:  
 Administração por via intravenosa – dose de 1 g/kg/dia, por 2 dias consecutivos, a cada 4 semanas OU 2 g/kg a cada 4 semanas, divididos em doses iguais administradas durante 2 a 5 dias consecutivos (dose mensal total: 2 g/kg, velocidade de infusão entre 1 e 4 mg/kg/minuto, conforme tolerância do paciente). Para pacientes com intolerância, alguns especialistas sugerem reduzir a dose para 1 g/kg, a cada 2 semanas. O intervalo de dose pode se espaçado assim que a resposta clínica completa for alcançada<sup>39</sup> .  
 Em ambos os casos, a resposta clínica completa pode ocorrer em até 6 meses e pode haver recaída após a interrupção do tratamento. Pode ser necessário tratamento contínuo para manter o controle da doença<sup>39</sup> .  
 Crianças e adolescentes (menores que 18 anos):  
 Os dados disponíveis são limitados. Administração por via intravenosa com dose de 1 g/kg/dia por 2 dias consecutivos. Caso a terapia de manutenção seja necessária, a dose e a frequência devem ser baseadas na resposta clínica e as doses não devem exceder 2 g/kg por ciclo de tratamento (dose total: 2 g/kg a cada quatro semanas)<sup>39</sup> .  
**Sulfato de hidroxicloroquina**  
- Adultos: administração via oral, 400 mg por dia em dose única diária. Avaliar a resposta ao tratamento após 3 meses. Devido ao risco de toxicidade retiniana, não administrar uma dose diária maior que 5 mg/kg/dia<sup>39</sup> .  
- Crianças a partir de seis anos e adolescentes (menores que 18 anos): Administração por via oral, dose de 5 mg/kg/dia. A dose total diária pode ser administrada integralmente (uma vez por dia) ou fracionada (dividida em duas administrações por dia). Dose diária máxima de 400 mg/dia<sup>39</sup> . O medicamento está aprovado para uso a partir de 6 anos<sup>72</sup> . Os dados disponíveis são limitados e a pertinência da indicação deve ser avaliada individualmente pelo médico assistente. As apresentações comerciais disponíveis no Brasil não devem ser partidas, abertas ou mastigadas<sup>72</sup> **.**

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **6.2.3. Contraindicações** -->
As contraindicações aos medicamentos preconizados neste Protocolo são:  
- Azatioprina: pacientes com hipersensibilidade conhecida a mercaptopurina<sup>50</sup> ;  
- Ciclofosfamida: mulheres em idade fértil sem uso de contraceptivo, gravidez e lactação, portadores de problemas da  
- medula óssea (especialmente em pacientes tratados com agentes citotóxicos - substâncias tóxicas para as células e/ou radioterapia), catapora ou Herpes zoster<sup>73</sup> ;  
- Hidroxicloroquina: pacientes com maculopatias (retinopatias) pré-existentes, com hipersensibilidade conhecida aos  
- derivados da 4-aminoquinolina (como, por exemplo a cloroquina)<sup>72</sup> ;  
- Imunoglobulina humana: deficiência seletiva de IgA, hiperprolinemia<sup>74</sup> ;  
 Metotrexato: mulheres em idade fértil sem uso de contraceptivo, gravidez e lactação, insuficiência renal grave (Doença Renal Crônica Estágio 4 – Taxa de Filtração Glomerular entre 15 e 29 mL/min/1,73m<sup>2</sup> e Doença Renal Crônica Estágio 5 N/D (não dialítico) - Taxa de Filtração Glomerular abaixo de 15 mL/min/1,73m<sup>2</sup> )<sup>92</sup> , insuficiência hepática grave, abuso de álcool, infecções graves, agudas ou crônicas, como tuberculose, HIV ou outras síndromes de imunodeficiência, úlceras da cavidade oral e doença ulcerosa gastrointestinal ativa conhecida, discrasias sanguíneas preexistentes, tais como hipoplasia da medula óssea, leucopenia (contagem de leucócitos menor que 4.000/mm), trombocitopenia (contagem de plaquetas menor que 150.000/mm)<sup>50</sup> ou anemia severa (Tabela 1) e vacinação concomitante com vacinas vivas/de vírus atenuados<sup>47</sup> .  
Tabela 1. Pontos de corte de hemoglobina para definir anemia severa em indivíduos<sup>93</sup> .  
|**População**|**Concentração**<br>**Anemia severa**|**de hemoglobina (g/L) -**|
|---|---|---|
|Crianças, 6-59 meses|< 70||  
|Crianças, 5-14 anos<br>Adultos do sexo masculino e feminino (não grávidas), 15-65 anos|< 80|
|---|---|
|Adultos do sexo feminino, grávidas|< 70|  
 Prednisona e metilprednisolona: pacientes com infecções sistêmicas por fungos, hipersensibilidade a outros corticosteroides<sup>75,76</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Gestantes** -->
Na maioria dos casos, a gestação em mulheres com miopatia inflamatória em remissão é bem-sucedida, razão pela qual o ideal é que a concepção seja planejada. Por outro lado, grávidas com doença ativa possuem risco de abortar, o feto nascer prematuro ou não se desenvolver<sup>77</sup> . Inclusive, quanto mais ativa a doença, maior é o risco de perda fetal. Complicações fetais estão mais frequentemente associadas com à miopatia necrosante imunomediada do que à dermatomiosite<sup>29,77,78</sup> .  
O acompanhamento médico adequado é essencial durante a gestação, para detecção precoce do surto da doença e tratamento oportuno. É aconselhável que as mulheres com miopatias inflamatórias sejam acompanhadas por uma equipe multidisciplinar, sendo o parto realizado em uma maternidade com assistência de uma unidade de terapia intensiva neonatal. Há risco de complicações obstétricas, como pré-eclâmpsia e eclâmpsia, e hospitalização mais longa após o trabalho de parto. Também é recomendado aumento da vigilância após o parto, pois as pacientes podem apresentar agravamento da doença<sup>77-79</sup> .  
No **Quadro 3** constam os medicamentos para miopatias inflamatórias e as respectivas categorias de risco na gravidez.  
**Quadro 3.** Medicamentos para miopatias inflamatórias e as categorias de risco na gravidez.  
|**Medicamento**|**Categoria de risco na gravidez (*)**|
|---|---|
|Azatioprina|D|
|Ciclofosfamida|X|
|Ciclosporina|C|
|Hidroxicloroquina|D|
|Imunoglobulina humana|D|
|Metilprednisolona|C|
|Metotrexato|X|
|Prednisona|B|  
(*)Quanto à descrição das categorias de risco na gravidez, conforme legislação sanitária vigente - RDC Nº 770, de 12 de dezembro de 2022<sup>80</sup> . B- Os estudos em animais não demonstraram risco fetal, mas também não há estudos controlados em mulheres grávidas. C- Não foram realizados estudos em animais e nem em mulheres grávidas; ou então, os estudos em animais revelaram risco, mas não existem estudos disponíveis realizados em mulheres grávidas. D- O fármaco demonstrou evidências positivas de risco fetal humano, no entanto os benefícios potenciais para a mulher podem, eventualmente, justificar o risco, como por exemplo, em casos de doenças graves ou que ameaçam a vida, e para as quais não existem outros medicamentos mais seguros. X- Em estudos em animais e mulheres grávidas, o fármaco provocou anomalias fetais, havendo clara evidência de risco para o feto que é maior do que qualquer benefício possível para a paciente. Este medicamento não deve ser utilizado por mulheres grávidas ou que possam ficar grávidas durante o tratamento. Fonte: Autoria própria<sup>47,50,54,72-76</sup> .  
O tratamento de miopatias inflamatórias em mulheres grávidas consiste basicamente no uso de corticoides, em doses habituais ou preferencialmente reduzidas, pelo menor tempo possível, conforme avaliação clínica<sup>75-77</sup> . As crianças expostas aos corticoides no útero devem ser acompanhadas para observação de sinais de insuficiência adrenal, embora seja rara a ocorrência de insuficiência adrenal neonatal<sup>76</sup> .  
Sobre o uso de imunoglobulina humana em pacientes grávidas é de que o uso, se necessário, seja feito com cautela, mediante juízo clínico e na ausência de alternativas mais seguras<sup>74</sup> , sendo uma opção para segunda linha de tratamento e podendo ser utilizada em monoterapia por mulheres grávidas<sup>21</sup> .  
Imunossupressores geralmente são contraindicados durante a gestação, por atravessarem a placenta em algum grau. Ao atingirem a circulação fetal através do sistema intestinal trazem algum risco de toxicidade. Por outro lado, há grande quantidade de dados de registro voluntário acumulados nas últimas seis décadas, especialmente em imunossupressão em transplantes ( _National Transplantation Pregnancy Registry_ – NTPR, dos Estados Unidos), que sugere que a ciclosporina e a azatioprina podem ser usadas em grávidas com pouco risco de eventos adversos fetal. Embora haja maior incidência de parto prematuro, restrição de crescimento fetal e baixo peso ao nascer na população exposta aos imunossupressores no ambiente intrauterino, nenhum aumento na porcentagem de defeitos congênitos foi demonstrado com exposição à. azatioprina ou ciclosporina<sup>81,82</sup> . Ainda, um estudo demonstrou que a azatioprina administrada às mães durante a gravidez aparece no sangue fetal como metabólitos inativos, pois a placenta metaboliza a azatioprina em ácido tiúrico<sup>83</sup> .  
Um estudo de coorte realizado no Canadá, com o acompanhamento de gestantes em uso de hidroxicloroquina no período de 1998 a 2015 (Quebec _Pregnancy Cohort_ ) constatou que, para a maioria das pacientes, os benefícios do tratamento superam os riscos potenciais. Foram acompanhadas gestantes com malária, artrite reumatoide e lúpus eritematoso sistêmico, sendo verificado que a exposição fetal não demonstrou aumentar o risco de prematuridade, baixo peso ao nascer e malformações congênitas<sup>84</sup> . Apesar da hidroxicloroquina atravessar a barreira placentária, inexiste evidência de toxicidade fetal significativa com o uso do medicamento em doses usuais previstas em bula<sup>84-86</sup> . A hidroxicloroquina pode ser utilizada durante a gravidez para o tratamento de miopatias inflamatórias, em caráter de excepcionalidade e a critério médico, se os benefícios potenciais individuais superarem os riscos<sup>72</sup> .  
Destaca-se que a ciclofosfamida e o metotrexato apresentam um alto potencial teratogênico. São classificados na categoria X e não devem ser utilizados por mulheres grávidas ou que possam ficar grávidas durante o tratamento. Em pacientes grávidas, há risco de causar óbito fetal, embriotoxicidade, malformações congênitas, aborto ou efeitos teratogênicos. Assim, para ambos os sexos, é recomendada a adoção de medidas adequadas para evitar a gravidez durante e seis meses após o término do tratamento<sup>47,54</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Lactação** -->
No **Quadro 4** são apresentadas as recomendações quanto à compatibilidade do uso dos medicamentos para o tratamento  
de miopatias inflamatórias durante a amamentação.  
**Quadro 4.** Compatibilidade do uso dos medicamentos para o tratamento de miopatias inflamatórias durante a amamentação.  
|**Medicamento**|**Compatibilidade com**<br>**amamentação**|**Recomendações**|
|---|---|---|
|Azatioprina|Sim|O metabólito da azatioprina (6-mercaptopurina) está presente no leite<br>materno, porém em quantidades baixas ou imensuráveis, sendo seguro o uso<br>do medicamento durante a amamentação.|
|Ciclofosfamida|Não|A ciclofosfamida e seus metabólitos altamente tóxicos estão presentes no<br>leite materno. Devido ao potencial de eventos adversos graves no lactente, a<br>amamentação é contraindicada durante e após o tratamento (as<br>recomendações variam entre de 1 semana e seis meses após o uso).|
|Ciclosporina|Sim (*)|A ciclosporina é transferida para o leite materno. Provavelmente segura para<br>uso durante a amamentação. Os lactentes para descartar possível toxicidade.|  
|**Medicamento**|**Compatibilidade com**<br>**amamentação**|**Recomendações**|
|---|---|---|
|||Pequenas quantidades do medicamento estão presentes no leite materno.|
|Hidroxicloroquina|Sim|Diretrizes internacionais(**) indicam que a hidroxicloroquina é aceitável<br>durante a amamentação.|
|||Imunoglobulinas são excretadas no leite materno, podendo contribuir para a|
|Imunoglobulina humana|Sim|transferência de anticorpos protetores para o recém-nascido. Uso seguro<br>durante a amamentação|
|Metotrexato|Não|O metotrexato foi detectado no leite humano e é contraindicado durante a<br>lactação, devido ao potencial de eventos adversos.|
|||A concentração dos medicamentos no leite materno é muito baixa. Apesar|
|Prednisona<br>Metilprednisolona|Sim|da ausência de registros de eventos adversos até o momento, recomenda-se<br>o monitoramento dos lactentes, pois os medicamentos podem suprimir o<br>crescimento e interferir na produção endógena de corticoides pelo bebê.|  
(*) Baseado em evidência limitada.  
(**) LactMed do U.S. Department of Health and Human Services; The British Society for Rheumatology and British Health Professionals, acreditado pelo National Institute for Health and Care Excellence (NICE).  
Fonte: ANVISA, UpToDate, LactMed e Diretriz BSR e BHPR sobre prescrição de medicamentos durante a gravidez e amamentação<sup>39,87-89</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Crianças e adolescentes** -->
<mark>O</mark> **<mark>Quadro 5</mark>** <mark>apresenta os medicamentos para o tratamento de miopatias inflamatórias padronizados no SUS, e as</mark>  
<mark>respectivas informações sanitárias relativas ao uso na população pediátrica.</mark>  
**<mark>Quadro 5.</mark>** <mark>M</mark> edicamentos para miopatias inflamatórias e o registro sanitário para a população pediátrica.  
|**Medicamento**|**Registro sanitário**|
|---|---|
|Azatioprina|Aprovado para uso pediátrico|
|Ciclofosfamida|Aprovado para uso pediátrico|
|Ciclosporina|Aprovado para uso pediátrico|
|Hidroxicloroquina|Aprovado para uso pediátrico acima de 6 anos|
|Imunoglobulina humana|Aprovado para uso pediátrico|
|Metilprednisolona|Aprovado para uso pediátrico|
|Metotrexato|Aprovado para uso pediátrico|
|Prednisona|Aprovado para uso pediátrico|  
Fonte: Autoria própria<sup>47,50,54,72-76</sup> .  
O _British Society for Rheumatology_ , acreditado pelo _National Institute for Health and Care Excellence_ (NICE), recomenda o tratamento da miopatia inflamatória ativa na população pediátrica com glicocorticoide oral ou pulsos de metilprednisolona intravenosa, no momento de indução e manutenção da remissão, do tratamento da miosite<sup>29</sup> .  
Ainda, pode-se considerar o uso de metilprednisolona quando existe uma possibilidade de má-absorção gastrointestinal ou pacientes que respondem mal a prednisona oral, assim, apresentando maior efeito terapêutico e menor toxicidade<sup>29</sup> .  
Na maioria dos casos, a combinação de altas doses de glicocorticoide e metotrexato é utilizada como primeira linha de tratamento ou, em alguns casos, glicocorticoide com azatioprina ou ciclosporina. Contudo, a associação com o metotrexato é  
favorecida devido ao perfil de segurança<sup>29,90,91</sup> . Nos casos graves ou refratários, preconiza-se o uso de imunoglobulina e ciclofosfamida<sup>29,91</sup> .  
<mark>Os principais eventos adversos do uso prolongado de glicocorticoides são f</mark> alhas de crescimento, obesidade, osteoporose, pancreatite, aumento da pressão intracraniana, catarata e inibir a produção endógena de corticosteroides<sup>75,91</sup> . A Anvisa também orienta que os pacientes pediátricos sob corticoterapia prolongada sejam acompanhados por especialistas. Em geral, a terapia com glicocorticoide em dias alternados minimiza os eventos adversos<sup>75</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **6.2.5. Critérios de interrupção** -->
Inexiste um período estabelecido para a duração do tratamento. Após se controlar a doença de acordo com os objetivos pretendidos, as doses dos medicamentos podem ser reduzidas gradualmente, sob monitorização sistemática da atividade da doença. Inicialmente, sugere-se diminuir a dose da prednisona ou metilprednisolona visando ao controle da doença, devido aos eventos adversos associados aos glicocorticoides. Posteriormente, com a manutenção dos parâmetros clínicos e laboratoriais, pode-se tentar a redução da dose do imunossupressor lentamente, em intervalos mensais ao longo de, aproximadamente, seis meses<sup>33,39</sup> .  
Em relação à ciclofosfamida, após 6 meses de tratamento, recomenda-se avaliar a transição para um medicamento imunossupressor alternativo para manter a remissão<sup>39</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **MONITORAMENTO** -->
Sugere-se o monitoramento periódico da força muscular nos quadríceps, deltoides e flexores do pescoço, bem como das enzimas musculares. As enzimas mais comumente avaliadas são as CPK, aldolase, DHL, AST/TGO e ALT/TGP. A melhora clínica tem maior valor na avaliação da resposta terapêutica do que as enzimas musculares séricas. Ajustes nas doses do glicocorticoide com o objetivo de normalizá-las podem determinar doses cumulativas desnecessariamente aumentadas<sup>39</sup> .  
Além da triagem de doenças infecciosas antes do início do tratamento, a toxicidade dos imunossupressores deve ser cuidadosamente monitorizada.  
- Prednisona e metilprednisolona: glicemia de jejum, potássio, perfil lipídico e aferição da pressão arterial devem ser avaliados no início do tratamento<sup>39</sup> . Anualmente, o perfil lipídico deve ser reavaliado<sup>39,65</sup> . As miopatias inflamatórias podem cursar com Osteoporose, sendo recomendada avaliação e cuidado conforme **PCDT de Osteoporose vigente,** contemplando densitometria óssea inicial na primeira avaliação, e repetindo-se o exame a cada 1 a 2 anos, até que a massa óssea esteja estável. Realizar avaliação oftalmológica em casos de terapia prolongada<sup>39,65,75,76</sup> .  
- Azatioprina: hemograma e plaquetas, testes de função hepática (fosfatase alcalina, AST/TGO e ALT/TGP) devem ser avaliados quinzenalmente até o terceiro mês de tratamento e, após, mensalmente. A azatioprina deve ser suspensa ou ter a dose reduzida em pacientes que desenvolvem leucopenia (contagem de leucócitos menor que 4.000/mm<sup>3</sup> ), trombocitopenia (contagem de plaquetas menor que 150.000/mm<sup>3</sup> ) ou qualquer elevação de TGO, TGP ou fosfatase alcalina acima do limite superior de referência<sup>39,50,65</sup> .  
- Metotrexato: provas de função hepática (AST/TGO e ALT/TGP), hemograma, contagem de plaquetas, dosagens de ureia e creatinina séricas devem ser realizadas antes do início do tratamento, e mensalmente nos primeiros 6 meses e, após esse período, a cada 2 a 3 meses durante seu uso ou conforme necessidade clínica. Se houver elevação de TGO e TGP de duas vezes o valor do limite superior de referência, o medicamento deve ser suspenso por 2 semanas, sendo reavaliado o retorno ao seu uso com nova aferição de enzimas hepáticas. O consumo de bebidas alcoólicas é desaconselhado ao longo do tratamento com metotrexato. Se houver diminuição da contagem de leucócitos ou de plaquetas ou se houver o surgimento de úlceras orais ou estomatite, a dose do metotrexato deve ser reduzida. Em caso de insuficiência renal aguda (caracterizada como o aumento mínimo  
de 0,3 mg/dL da creatinina sérica basal ou 150% a 200% do seu valor basal associada ou não a uma diurese abaixo de 0,5 mL/kg/h por 6 horas), deve-se suspender o medicamento. Devido ao potencial risco de pneumonite, tosse e dispneia, deve-se avaliar radiografia simples de tórax e testes de função pulmonar; portanto, o medicamento deve ser usado com cautela em pacientes pneumopatas. Náusea e vômitos respondem à redução da dose do metotrexato ou incremento da dose semanal de ácido fólico, podendo ser utilizado antiemético ou ingestão com as refeições para tentar diminuir essas queixas. As causas mais comuns de toxicidade aguda do metotrexato são a insuficiência renal aguda e a administração concomitante de sulfametoxazol+trimetoprima. **A associação de ácido fólico (5 a 10 mg/semana) após 24 a 48 horas da última dose é recomendada para minimizar os eventos adversos**<sup>39,47,65</sup> . São necessários exames de gravidez (Beta HCG quantitativo) periódicos durante o tratamento, além do uso de métodos contraceptivos sem interrupção - pelo menos um método contraceptivo eficaz e único (como dispositivo intrauterino) ou dois métodos complementares de contracepção, incluindo um método de barreira (preservativos).  
- Ciclofosfamida: hemograma, contagem de plaquetas e exame comum de urina com microscopia, devem ser avaliados 10 a 14 dias após cada infusão. A redução da dose da ciclofosfamida poderá ser necessária em caso de leucopenia menor que 4.000/mm<sup>3</sup> . No surgimento de hematúria, a hipótese de cistite hemorrágica deverá ser considerada, assim como sua investigação. Além da imunossupressão com consequente aumento de risco de infecções, aumento de risco de neoplasias, infertilidade, toxicidade hematológica e cistite hemorrágica são outros eventos adversos potenciais. **Para prevenir a cistite hemorrágica, recomenda-se hidratação vigorosa e se sugere a administração de mesna parenteral ou oral (1 mg para cada mg de ciclofosfamida) dividida em três doses: 30 minutos antes da infusão, 30 minutos após a infusão e 4 horas após o término da infusão**<sup>39,65,73</sup> . São necessários exames de gravidez (Beta HCG quantitativo) periódicos durante o tratamento, além do uso de métodos contraceptivos sem interrupção - pelo menos um método contraceptivo eficaz e único (como dispositivo intrauterino) ou dois métodos complementares de contracepção, incluindo um método de barreira (preservativos).  
- Imunoglobulina humana: pacientes devem ser monitorados quanto às reações infusionais. Entre outros eventos descritos, citam-se meningite asséptica, insuficiência renal, hiperproteinemia, edema pulmonar e eventos trombóticos<sup>50,74</sup> .  
- Ciclosporina: seu perfil de toxicidade restringe sua utilização. Monitorar a pressão arterial sistêmica e função renal (dosagem sérica de creatinina) antes do início do tratamento e repetir a cada 2 semanas nos primeiros 3 meses de tratamento e, após, mensalmente se o paciente estiver clinicamente estável. Se houver o desenvolvimento de hipertensão arterial, deve ser realizada redução de 25% a 50% da dose de ciclosporina; persistindo a hipertensão após essa redução, o tratamento deve ser suspenso. Também o perfil lipídico e de eletrólitos séricos, em especial potássio (devido ao risco de hipercalemia), devem ser avaliados periodicamente. Na ocorrência de hipercalemia, deve-se considerar a interrupção do medicamento e uso de antilipemiantes para controle do perfil lipídico. A ciclosporina está contraindicada em pacientes com alteração da função renal, hipertensão arterial não controlada ou neoplasia<sup>54</sup> .  
- Sulfato de hidroxicloroquina: deve ser realizado exame oftalmológico no início do tratamento e a cada 12 meses. Dosagem de enzimas musculares (CPK e aldolase) também são indicadas. Em caso de evidência de maculopatia na avaliação oftalmológica ou suspeita de miopatia, o medicamento deverá ser suspenso<sup>72</sup> .  
Diversos instrumentos podem ser usados para avaliar a atividade da doença (Quadro 6) **.** As principais incluem: atividade global da doença avaliada pelo médico - escala visual analógica (EVA); atividade global da doença avaliada pelo paciente; _Manual Muscle Testing_ (MMT), função física medida pelo _Health Assessment Questionnaire_ (HAQ) e melhora cutânea medida pela escala _Cutaneous Dermatomyositis Disease Area and Severity Index_ (CDASI)<sup>27</sup> .  
**Quadro 6.** Principais instrumentos para avaliação da atividade de miopatias inflamatórias  
|**Instrumento**|**Definição**|
|---|---|  
|Atividade global da doença avaliada pelo<br>médico|Classificação geral da atividade da doença considerando todas as medidas<br>clínicas e laboratoriais disponíveis no momento da avaliação|
|---|---|
|Atividade global da doença avaliada pelo<br>paciente|Classificação geral da atividade da doença|
|_Manual Muscle Testing_(MMT)|Mede a força muscular pela capacidade do músculo testado agir contra a<br>gravidade ou contra a resistência aplicada pelo examinador|
|_Health Assessment Questionnaire_(HAQ)|Avalia a função física por 9 domínios da atividade diária|
|_Cutaneous Dermatomyositis Disease Area and_|Mede<br>características-chave<br>da<br>atividade<br>e<br>danos<br>cutâneos<br>na|
|_Severity Index_(CDASI)|dermatomiosite|  
**Fonte:** Adaptado de Baig et al. (2020)<sup>27</sup> .  
Pacientes com miopatias inflamatórias apresentam risco elevado de neoplasia, sendo maior em pacientes com dermatomiosite. Câncer de pulmões, mamas, ovários e linfoma são as neoplasias mais comuns que acometem essa população. Em caso de suspeita, a investigação do câncer deve incluir exames físicos, avaliação da pelve, tomografia do tórax, abdômen e pelve, ultrassonografia do abdômen, endoscopia digestiva alta e colonoscopia e, em mulheres, ultrassonografia ginecológica e mamografia<sup>4</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste Protocolo, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses de medicamentos prescritas e dispensadas e da adequação das condutas indicadas e do acompanhamento pós-tratamento. Sempre que disponível, a confirmação do diagnóstico, o tratamento e o acompanhamento dos pacientes com miopatias inflamatórias devem ser realizados em serviços especializados com clínica médica e reumatologia.  
O monitoramento dos exercícios físicos por profissionais especializados (fisioterapeuta e/ou terapeuta ocupacional) é recomendado. A avaliação oftalmológica para pacientes em uso de antimaláricos deve ser realizada em serviços especializados em oftalmologia.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados, DF e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do (s) medicamento (s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração  
do Cuidado Farmacêutico aos Protocolos Clínicos e Diretrizes Terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidade e complexidade) da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, a Tabela do SUS, podem ser acessados, por código ou nome do procedimento e por código da CID10 para a respectiva doença, por meio do SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
As administrações endovenosas de metilprednisolona e de ciclofosfamida são compatíveis, isto é, passíveis de serem realizadas simultaneamente, por meio, respectivamente, dos procedimentos 03.03.02.001-6 - PULSOTERAPIA I (POR APLICAÇÃO) e 03.03.02.002-4 - PULSOTERAPIA II (POR APLICAÇÃO), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **REFERÊNCIAS** -->
- 1 Selva-O'Callaghan, A. et al. Classification and management of adult inflammatory myopathies. Lancet Neurol 17, 816828 (2018). https://doi.org:10.1016/s1474-4422(18)30254-0  
- 2 Ashton, C., Paramalingam, S., Stevenson, B., Brusch, A. & Needham, M. Idiopathic inflammatory myopathies: a review. Intern Med J 51, 845-852 (2021). https://doi.org:10.1111/imj.15358  
- 3 Cheeti, A., Brent, L. H. & Panginikkod, S. in StatPearls (2024).  
- 4 Lundberg, I. E. et al. Idiopathic inflammatory myopathies. Nature Reviews Disease Primers 7 (2021). https://doi.org:10.1038/s41572-021-00321-x  
- 5 Selva-O’Callaghan, A. et al. Pharmacologic Treatment of Anti-MDA5 Rapidly Progressive Interstitial Lung Disease. Current Treatment Options in Rheumatology 7, 319-333 (2021). https://doi.org:doi:10.1007/s40674-021-00186-x  
- 6 Bailey, E. E. & Fiorentino, D. F. Amyopathic dermatomyositis: definitions, diagnosis, and management. Curr Rheumatol Rep 16, 465 (2014). https://doi.org:10.1007/s11926-014-0465-0  
- 7 Lazarou, I. N. & Guerne, P. A. Classification, diagnosis, and management of idiopathic inflammatory myopathies. J Rheumatol 40, 550-564 (2013). https://doi.org:10.3899/jrheum.120682  
- 8 Tanboon, J. & Nishino, I. Classification of idiopathic inflammatory myopathies: pathology perspectives. Curr Opin Neurol 32, 704-714 (2019). https://doi.org:10.1097/wco.0000000000000740  
- 9 Opinc, A. H. & Makowska, J. S. Antisynthetase syndrome - much more than just a myopathy. Semin Arthritis Rheum 51, 72-83 (2021). https://doi.org:10.1016/j.semarthrit.2020.09.020  
- 10 Stenzel, W., Goebel, H. H., Bader-Meunier, B. & Gitiaux, C. Inflammatory myopathies in childhood. Neuromuscul Disord 31, 1051-1061 (2021). https://doi.org:10.1016/j.nmd.2021.08.007  
- 11 Muller-Felber, W., Wanschitz, J., Vill, K. & Baumann, M. Pediatric idiopathic inflammatory myopathies: an update on diagnostic and treatment strategies. Neuropediatrics 44, 314-323 (2013). https://doi.org:10.1055/s-0033-1358600  
12 Huber, A. M. Juvenile Idiopathic Inflammatory Myopathies. Pediatr Clin North Am 65, 739-756 (2018). https://doi.org:10.1016/j.pcl.2018.04.006  
- 13 Jacobson, D. L., Gange, S. J., Rose, N. R. & Graham, N. M. Epidemiology and estimated population burden of selected autoimmune diseases in the United States. Clin Immunol Immunopathol 84, 223-243 (1997). https://doi.org:10.1006/clin.1997.4412  
14 National Institute of Neurological Disorders and Stroke. Inflammatory Myopathies, <https://www.ninds.nih.gov/healthinformation/disorders/inflammatory-myopathies> (2022).  
15 Dimachkie, M. M., Barohn, R. J. & Amato, A. A. Idiopathic inflammatory myopathies. Neurol Clin 32, 595-628, vii (2014). https://doi.org:10.1016/j.ncl.2014.04.007  
16 BRASIL. Ministério da Saúde (MS). Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde. Departamento de Gestão e Incorporação de Tecnologias em Saúde Diretrizes metodológicas: elaboração de diretrizes clínicas/ Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde, Departamento de Gestão e Incorporação de Tecnologias em Saúde – Brasília : Ministério da Saúde, 2023; 138 p.  
- 17 BRASIL. Ministério da Saúde (MS). Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília, 72 p.; ISBN 978-85-334-2186-8; Ministério da Saúde, 2014.  
- 18 Schünemann, H. J. et al. GRADE guidelines: 21 part 2. Test accuracy: inconsistency, imprecision, publication bias, and other domains for rating the certainty of evidence and presenting it in evidence profiles and summary of findings tables. Journal of clinical epidemiology 122, 142-152 (2020).  
- 19 Bohan, A. & Peter, J. B. Polymyositis and dermatomyositis (first of two parts). N Engl J Med 292, 344-347 (1975). https://doi.org:10.1056/nejm197502132920706  
20 Bohan, A. & Peter, J. B. Polymyositis and dermatomyositis (second of two parts). N Engl J Med 292, 403-407 (1975). https://doi.org:10.1056/nejm197502202920807  
21 Findlay, A. R., Goyal, N. A. & Mozaffar, T. An overview of polymyositis and dermatomyositis. Muscle Nerve 51, 638656 (2015). https://doi.org:10.1002/mus.24566  
- 22 Iaccarino, L. et al. The clinical features, diagnosis and classification of dermatomyositis. J Autoimmun 48-49, 122-127 (2014). https://doi.org:10.1016/j.jaut.2013.11.005  
- 23 Leclair, V. & Lundberg, I. E. New Myositis Classification Criteria-What We Have Learned Since Bohan and Peter. Curr Rheumatol Rep 20, 18 (2018). https://doi.org:10.1007/s11926-018-0726-4  
- 24 Lundberg, I. E., de Visser, M. & Werth, V. P. Classification of myositis. Nat Rev Rheumatol 14, 269-278 (2018). https://doi.org:10.1038/nrrheum.2018.41  
- 25 Lundberg, I. E. et al. 2017 European League Against Rheumatism/American College of Rheumatology classification criteria for adult and juvenile idiopathic inflammatory myopathies and their major subgroups. Ann Rheum Dis 76, 1955-1964 (2017). https://doi.org:10.1136/annrheumdis-2017-211468  
- 26 Correction: European League Against Rheumatism/American College of Rheumatology classification criteria for adult and juvenile idiopathic inflammatory myopathies and their major subgroups. Ann Rheum Dis 77, e64 (2018). https://doi.org:10.1136/annrheumdis-2017-211468corr1  
- 27 Baig, S. & Paik, J. J. Inflammatory muscle disease - An update. Best Pract Res Clin Rheumatol 34, 101484 (2020). https://doi.org:10.1016/j.berh.2019.101484  
- 28 UpToDate. Interstitial lung disease in dermatomyositis and polymyositis: Clinical manifestations and diagnosis, <https://www.uptodate.com/contents/search>  
29 Oldroyd, A. G. S. et al. British Society for Rheumatology guideline on management of paediatric, adolescent and adult patients with idiopathic inflammatory myopathy. Rheumatology (Oxford) 61, 1760-1768 (2022). https://doi.org:10.1093/rheumatology/keac115  
30 Lundberg, I. Current classification and management of myositis. International Journal of Rheumatic Diseases 22, 2021 (2019). https://doi.org:10.1111/1756-185X.13538  
31 de Souza, F. H. C. et al. Guidelines of the Brazilian Society of Rheumatology for the treatment of systemic autoimmune myopathies. Adv Rheumatol 59, 6 (2019). https://doi.org:10.1186/s42358-019-0048-x  
32 Kohsaka, H. et al. Treatment consensus for management of polymyositis and dermatomyositis among rheumatologists, neurologists and dermatologists. J Dermatol 46, e1-e18 (2019). https://doi.org:10.1111/1346-8138.14604  
33 Bader-Meunier B and Benveniste O. Dermatomyosite de l’enfant et de l’adulte. Protocole National de Diagnostic et de Soins (PNDS). Centre de Référence pour les Maladies Rhumatologiques et Inflammatoires Rares Pédiatriques. 2016. Disponível em: https://www.has-sante.fr/upload/docs/application/pdf/2016-09/pnds_-_dermatomyosite_de_lenfant_et_de_ladulte.pdf.  
34 Ogata, A. & Tanaka, T. Tocilizumab for the treatment of rheumatoid arthritis and other systemic autoimmune diseases: current perspectives and future directions. Int J Rheumatol 2012, 946048 (2012). https://doi.org:10.1155/2012/946048  
35 Munters, L. A. et al. Endurance Exercise Improves Molecular Pathways of Aerobic Metabolism in Patients With Myositis. Arthritis Rheumatol 68, 1738-1750 (2016). https://doi.org:10.1002/art.39624  
36 Alemo Munters, L. et al. Improved exercise performance and increased aerobic capacity after endurance training of patients with stable polymyositis and dermatomyositis. Arthritis Res Ther 15, R83 (2013). https://doi.org:10.1186/ar4263  
37 Dastmalchi, M. et al. Effect of physical training on the proportion of slow-twitch type I muscle fibers, a novel nonimmune-mediated mechanism for muscle impairment in polymyositis or dermatomyositis. Arthritis Rheum 57, 1303-1310 (2007). https://doi.org:10.1002/art.22996  
38 Ernste, F. C. et al. Functional Index-3: A Valid and Reliable Functional Outcome Assessment Measure in Patients With Dermatomyositis and Polymyositis. J Rheumatol 48, 94-100 (2021). https://doi.org:10.3899/jrheum.191374  
39 UpToDate®. Lexicomp online. Drug Information. 2023. Disponível em: https://www.uptodate.com/contents/pt/tableof-contents/drug-information.  
- 40 Callen, J. P. & Wortmann, R. L. Dermatomyositis. Clin Dermatol 24, 363-373 (2006).  
https://doi.org:10.1016/j.clindermatol.2006.07.001  
41 Mainetti, C., Terziroli Beretta-Piccoli, B. & Selmi, C. Cutaneous Manifestations of Dermatomyositis: a Comprehensive Review. Clin Rev Allergy Immunol 53, 337-356 (2017). https://doi.org:10.1007/s12016-017-8652-1  
42 Greenberg, S. A. Inclusion body myositis: clinical features and pathogenesis. Nat Rev Rheumatol 15, 257-272 (2019). https://doi.org:10.1038/s41584-019-0186-x  
- 43 Dimachkie, M. M. & Barohn, R. J. Inclusion body myositis. Neurol Clin 32, 629-646, vii (2014). https://doi.org:10.1016/j.ncl.2014.04.001  
44 Oh, T. H. et al. Dysphagia in inflammatory myopathy: clinical characteristics, treatment strategies, and outcome in 62 patients. Mayo Clin Proc 82, 441-447 (2007). https://doi.org:10.4065/82.4.441  
- 45 Bader-Meunier, B. & Benveniste, O. Dermatomyosite de l’enfant et de l’adulte-Protocole National de Diagnostic et de Soins [Internet]. 2016. Disponible sur: https://www. has-sante. fr/portail/upload/docs/application/pdf/2016-09/pnds__dermatomyosite_de_lenfant_et_de_ladulte. pdf  
- 46 Moghadam-Kia, S., Aggarwal, R. & Oddis, C. V. Treatment of inflammatory myopathy: emerging therapies and therapeutic targets. Expert Rev Clin Immunol 11, 1265-1275 (2015). https://doi.org:10.1586/1744666x.2015.1082908  
- 47 ANVISA. Agência Nacional de Vigilância Sanitária. Metotrexato [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível em:  
https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=metotrexato.  
48 Newman, E. D. & Scott, D. W. The Use of Low-dose Oral Methotrexate in the Treatment of Polymyositis and Dermatomyositis. J Clin Rheumatol 1, 99-102 (1995). https://doi.org:10.1097/00124743-199504000-00007  
49 Joffe, M. M. et al. Drug therapy of the idiopathic inflammatory myopathies: predictors of response to prednisone, azathioprine, and methotrexate and a comparison of their efficacy. Am J Med 94, 379-387 (1993). https://doi.org:10.1016/00029343(93)90148-i  
50 ANVISA. Agência Nacional de Vigilância Sanitária. Azatioprina [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível  
em: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=FURP-AZATIOPRINA.  
51 Ramírez, G. et al. Adult-onset polymyositis-dermatomyositis: description of 25 patients with emphasis on treatment. Semin Arthritis Rheum 20, 114-120 (1990). https://doi.org:10.1016/0049-0172(90)90024-a  
52 Bunch, T. W. Prednisone and azathioprine for polymyositis: long-term followup. Arthritis Rheum 24, 45-48 (1981). https://doi.org:10.1002/art.1780240107  
53 Villalba, L. et al. Treatment of refractory myositis: a randomized crossover study of two new cytotoxic regimens. Arthritis Rheum 41, 392-399 (1998). https://doi.org:10.1002/1529-0131(199803)41:3<392::AID-ART3>3.0.CO;2-X  
54 ANVISA. Agência Nacional de Vigilância Sanitária. Ciclosporina [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível em:  
https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=CICLOSPORINA.  
55 Kotani, T. et al. Combination with corticosteroids and cyclosporin-A improves pulmonary function test results and chest HRCT findings in dermatomyositis patients with acute/subacute interstitial pneumonia. Clin Rheumatol 30, 1021-1028 (2011). https://doi.org:10.1007/s10067-011-1713-6  
56 Kotani, T. et al. Early intervention with corticosteroids and cyclosporin A and 2-hour postdose blood concentration monitoring improves the prognosis of acute/subacute interstitial pneumonia in dermatomyositis. J Rheumatol 35, 254-259 (2008).  
57 Yamasaki, Y. et al. Intravenous cyclophosphamide therapy for progressive interstitial pneumonia in patients with polymyositis/dermatomyositis. Rheumatology (Oxford) 46, 124-130 (2007). https://doi.org:10.1093/rheumatology/kel112 58 Pinard, J. et al. Systemic Treatment for Clinically Amyopathic Dermatomyositis at 4 Tertiary Care Centers. JAMA Dermatol 155, 494-496 (2019). https://doi.org:10.1001/jamadermatol.2018.5215  
59 Iannone, F., Scioscia, C., Falappone, P. C., Covelli, M. & Lapadula, G. Use of etanercept in the treatment of dermatomyositis: a case series. J Rheumatol 33, 1802-1804 (2006). 60 Dastmalchi, M. et al. A high incidence of disease flares in an open pilot study of infliximab in patients with refractory inflammatory myopathies. Ann Rheum Dis 67, 1670-1677 (2008). https://doi.org:10.1136/ard.2007.077974  
61 Traineau, H. et al. Treatment of calcinosis cutis in systemic sclerosis and dermatomyositis: A review of the literature. J Am Acad Dermatol 82, 317-325 (2020). https://doi.org:10.1016/j.jaad.2019.07.006  
62 Reiter, N., El-Shabrawi, L., Leinweber, B., Berghold, A. & Aberer, E. Calcinosis cutis: part II. Treatment options. J Am Acad Dermatol 65, 15-22; quiz 23-14 (2011). https://doi.org:10.1016/j.jaad.2010.08.039 63 Ogata, A. & Tanaka, T. Tocilizumab for the treatment of rheumatoid arthritis and other systemic autoimmune diseases: Current perspectives and future directions. International Journal of Rheumatology 2012 (2012). https://doi.org:10.1155/2012/946048  
64 Arabshahi, B., Silverman, R. A., Jones, O. Y. & Rider, L. G. Abatacept and sodium thiosulfate for treatment of recalcitrant juvenile dermatomyositis complicated by ulceration and calcinosis. J Pediatr 160, 520-522 (2012). https://doi.org:10.1016/j.jpeds.2011.11.057  
65 Micromedex. Drug information; 2023. Disponível em: https://www.micromedexsolutions.com/micromedex2/librarian/. 66 FDA. Food and Drug Administration. IMURAN (azathioprine). May 2011. Disponível em: https://www.accessdata.fda.gov/drugsatfda_docs/label/2011/016324s034s035lbl.pdf.  
67 BRASIL. Ministério da Saúde (MS). Protocolo Clínico e Diretrizes Terapêuticas da Psoríase. 2021. Disponível em: https://www.gov.br/saude/pt-br/assuntos/pcdt/arquivos/2019/PortariaConjuntan18de14102021_PCDT_Psoriase.pdf.  
68 BRASIL. Ministério da Saúde (MS). Protocolo Clínico e Diretrizes Terapêuticas da Artrite Reumatóide. 2021. Disponível em: https://www.gov.br/conitec/pt-  
br/midias/consultas/relatorios/2021/20210623_relatorio_pcdt_artrite_reumatoide.pdf.  
69 Senbel, E. et al. Benefits of Switch from Oral to Subcutaneous Route on Adherence to Methotrexate in Patients with Rheumatoid Arthritis in Real Life Setting. Patient Prefer Adherence 15, 751-760 (2021). https://doi.org:10.2147/PPA.S301010 70 Stamp, L. K. et al. Effects of changing from oral to subcutaneous methotrexate on red blood cell methotrexate polyglutamate concentrations and disease activity in patients with rheumatoid arthritis. J Rheumatol 38, 2540-2547 (2011). https://doi.org:10.3899/jrheum.110481  
71 Uptodate. Lexicomp. Drug Information, <https://www.uptodate.com/contents/pt/table-of-contents/drug-information> (2022).  
72 ANVISA. Agência Nacional de Vigilância Sanitária. Hidroxicloroquina [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível em: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=sulfato%20de%20hidroxicloroquina.  
73 ANVISA. Agência Nacional de Vigilância Sanitária. Ciclofosfamida [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível em: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=GENUXAL.  
74 ANVISA. Agência Nacional de Vigilância Sanitária. Imunoglobulina Humana [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível em: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=IMUNOGLOBULIN.  
75 ANVISA. Agência Nacional de Vigilância Sanitária. Prednisona [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível em:  
https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=Prednisona.  
76 ANVISA. Agência Nacional de Vigilância Sanitária. Metilprednisolona [Bula]. Acesso em: 30 de Janeiro de 2023. Disponível em:  
https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=Succinato%20S%C3%B3dico%20de%20Metilpredinisolona.  
77 Dimitri, D. & Pagnoux, C. [Pregnancy and inflammatory myopathies]. Presse Med 37, 1652-1656 (2008). https://doi.org:10.1016/j.lpm.2008.07.009  
78 Zagorda, B., Camdessanche, J. P. & Feasson, L. Pregnancy and myopathies: Reciprocal impacts between pregnancy, delivery, and myopathies and their treatments. A clinical review. Rev Neurol (Paris) 177, 225-234 (2021). https://doi.org:10.1016/j.neurol.2020.09.014  
79 Kolstad, K. D., Fiorentino, D., Li, S., Chakravarty, E. F. & Chung, L. Pregnancy outcomes in adult patients with dermatomyositis and polymyositis. Semin Arthritis Rheum 47, 865-869 (2018). https://doi.org:10.1016/j.semarthrit.2017.11.005 80 BRASIL. Agência Nacional de Vigilância Sanitária (ANVISA). RDC Nº 770, de 12 de Dezembro de 2022. Estabelece frases de alerta para substâncias, classes terapêuticas e listas de controle em bulas e embalagem de medicamentos. Ministério da Saúde (MS), Diretoria Colegiada. Publicado em: 14/12/2022; Edição: 234; Seção: 1; Página: 154.  
81 Chandra, A., Midtvedt, K., Asberg, A. & Eide, I. A. Immunosuppression and Reproductive Health After Kidney Transplantation. Transplantation 103, e325-e333 (2019). https://doi.org:10.1097/TP.0000000000002903  
82 Coscia, L. A., Constantinescu, S., Davison, J. M., Moritz, M. J. & Armenti, V. T. Immunosuppressive drugs and fetal outcome. Best Pract Res Clin Obstet Gynaecol 28, 1174-1187 (2014). https://doi.org:10.1016/j.bpobgyn.2014.07.020  
- 83 Saarikoski, S. & Seppala, M. Immunosuppression during pregnancy: transmission of azathioprine and its metabolites from the mother to the fetus. Am J Obstet Gynecol 115, 1100-1106 (1973). https://doi.org:10.1016/0002-9378(73)90559-0  
- 84 Berard, A. et al. Chloroquine and Hydroxychloroquine Use During Pregnancy and the Risk of Adverse Pregnancy Outcomes Using Real-World Evidence. Front Pharmacol 12, 722511 (2021). https://doi.org:10.3389/fphar.2021.722511  
- 85 Parke, A. & West, B. Hydroxychloroquine in pregnant patients with systemic lupus erythematosus. J Rheumatol 23, 1715-1718 (1996).  
- 86 Buchanan, N. M. et al. Hydroxychloroquine and lupus pregnancy: review of a series of 36 cases. Ann Rheum Dis 55, 486-488 (1996). https://doi.org:10.1136/ard.55.7.486  
- 87 ANVISA. Agência Nacional de Vigilância Sanitária. Ministério da Saúde (MS). Brasil. Disponível em: https://www.gov.br/anvisa/pt-br.  
- 88 LactMed®. Drugs and Lactation Database. National Institute of Child Health and Human Development. Disponível em: https://www.ncbi.nlm.nih.gov/books/NBK501922/.  
89 Flint, J. et al. BSR and BHPR guideline on prescribing drugs in pregnancy and breastfeeding-Part I: standard and biologic disease modifying anti-rheumatic drugs and corticosteroids. Rheumatology (Oxford) 55, 1693-1697 (2016). https://doi.org:10.1093/rheumatology/kev404  
- 90 McCann, L. J., Livermore, P., Wilkinson, M. G. L. & Wedderburn, L. R. Juvenile dermatomyositis. Where are we now? Clin Exp Rheumatol 40, 394-403 (2022). https://doi.org:10.55563/clinexprheumatol/56ilob  
- 91 Kobayashi, I. et al. Clinical practice guidance for juvenile dermatomyositis (JDM) 2018-Update. Mod Rheumatol 30, 411-423 (2020). https://doi.org:10.1080/14397595.2020.1718866  
92        BRASIL. Portaria Conjunta SAES/SECTICS Nº 011, de 16 de setembro de 2024. Aprova o Protocolo Clínico e Diretrizes Terapêuticas das Estratégias para Atenuar a Progressão da Doença Renal Crônica. DOU de 26.09.2024 – pág. 152 – Seção 1. Brasília – DF; 2024.  
93   Guideline on haemoglobin cutoffs to define anaemia in individuals and populations. Geneva: World Health Organization; 2024. Licence: CC BY-NC-SA 3.0 IGO. Disponível em: https://www.who.int/publications/i/item/9789240088542.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE AZATIOPRINA, METOTREXATO, HIDROXICLOROQUINA, CICLOSPORINA, IMUNOGLOBULINA HUMANA, PREDNISONA, METILPREDNISOLONA E CICLOFOSFAMIDA** -->
Eu__________________________________________________________________ (nome do [a] paciente), declaro  
ter sido informado (a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de  
**azatioprina, metotrexato, hidroxicloroquina, ciclosporina, imunoglobulina humana, prednisona, metilprednisolona e ciclofosfamida** , indicados para o tratamento de miopatias inflamatórias.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico  
________________________________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes  
benefícios:  
- melhora da capacidade de realizar atividades diárias;  
- aumento da força muscular;  
- prevenção do desenvolvimento de complicações extramusculares;  
- controle das manifestações da pele na dermatomiosite.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Medicamento prednisona: medicamento classificado na gestação como categoria B (os estudos em animais não  
- demonstraram risco fetal, mas também não há estudos controlados em mulheres grávidas). Contraindicado para pacientes com infecções sistêmicas por fungos e hipersensibilidade a outros corticosteroides.  
• Medicamentos metilprednisolona: medicamento classificado na gestação como categoria C (não foram realizados estudos em animais e nem em mulheres grávidas; ou então, os estudos em animais revelaram risco, mas não existem estudos disponíveis realizados em mulheres grávidas). Contraindicado para pacientes com infecções sistêmicas por fungos e hipersensibilidade a outros corticosteroides.  
• Medicamentos ciclosporina: medicamento classificado na gestação como categoria C (não foram realizados estudos em animais e nem em mulheres grávidas; ou então, os estudos em animais revelaram risco, mas não existem estudos disponíveis realizados em mulheres grávidas).  
• Medicamento azatioprina: medicamento classificado na gestação como categoria D (o fármaco demonstrou evidências positivas de risco fetal humano, no entanto os benefícios potenciais para a mulher podem, eventualmente, justificar o risco, como por exemplo, em casos de doenças graves ou que ameaçam a vida, e para as quais não existem outros medicamentos mais seguros). Contraindicado para pacientes com hipersensibilidade conhecida a mercaptopurina.  
• Medicamento hidroxicloroquina: medicamento classificado na gestação como categoria D (o fármaco demonstrou evidências positivas de risco fetal humano, no entanto os benefícios potenciais para a mulher podem, eventualmente, justificar o risco, como por exemplo, em casos de doenças graves ou que ameaçam a vida, e para as quais não existem outros medicamentos mais seguros). Contraindicado para pacientes com maculopatias (retinopatias) pré-existentes, com hipersensibilidade conhecida aos derivados da 4-aminoquinolina.  
• Medicamento imunoglobulina humana: medicamento classificado na gestação como categoria D (o fármaco demonstrou evidências positivas de risco fetal humano, no entanto os benefícios potenciais para a mulher podem, eventualmente, justificar o risco, como por exemplo, em casos de doenças graves ou que ameaçam a vida, e para as quais não existem outros medicamentos mais seguros). Contraindicado em casos de deficiência seletiva de IgA e hiperprolinemia.  
- Medicamento ciclofosfamida: medicamento classificado na gestação como categoria X (em estudos em  
- animais e mulheres grávidas, o fármaco provocou anomalias fetais, havendo clara evidência de risco para o feto que é maior do  
que qualquer benefício possível para a paciente. Este medicamento não deve ser utilizado por mulheres grávidas ou que possam ficar grávidas durante o tratamento). São necessários exames de gravidez (Beta HCG quantitativo) periódicos durante o tratamento, além do uso de métodos contraceptivos sem interrupção - pelo menos um método contraceptivo eficaz e único (como dispositivo intrauterino) ou dois métodos complementares de contracepção, incluindo um método de barreira (preservativos). Contraindicado para mulheres em idade fértil sem uso de contraceptivo, gravidez e lactação, portadores de problemas da medula óssea (especialmente em pacientes tratados com agentes citotóxicos - substâncias tóxicas para as células e/ou radioterapia), catapora ou Herpes zoster<sup>73</sup> .  
• Medicamento metotrexato: medicamento classificado na gestação como categoria X (em estudos em animais e mulheres grávidas, o fármaco provocou anomalias fetais, havendo clara evidência de risco para o feto que é maior do que qualquer benefício possível para a paciente. Este medicamento não deve ser utilizado por mulheres grávidas ou que possam ficar grávidas durante o tratamento). São necessários exames de gravidez (Beta HCG quantitativo) periódicos durante o tratamento, além do uso de métodos contraceptivos sem interrupção - pelo menos um método contraceptivo eficaz e único (como dispositivo intrauterino) ou dois métodos complementares de contracepção, incluindo um método de barreira (preservativos). Contraindicado para mulheres em idade fértil sem uso de contraceptivo, gravidez e lactação, insuficiência renal grave, insuficiência hepática grave, abuso de álcool, infecções graves, agudas ou crônicas, como tuberculose, HIV ou outras síndromes de imunodeficiência, úlceras da cavidade oral e doença ulcerosa gastrointestinal ativa conhecida, discrasias sanguíneas preexistentes, tais como hipoplasia da medula óssea, leucopenia, trombocitopenia  ou anemia severa e vacinação concomitante com vacinas vivas/de vírus atenuados.  
Os eventos adversos mais comumente relatados para os medicamentos são:  
- para a azatioprina: diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar e pressão baixa;  
- para ciclofosfamida (pulsoterapia): mielossupressão, imunossupressão e infecções, toxicidade urinária e renal, cardiotoxicidade (doenças cardíacas) toxicidade pulmonar, malignidades secundárias, doença hepática veno oclusiva, genotoxicidade, efeitos na fertilidade, reações anafiláticas, sensibilidade cruzada com outros agentes alquilantes, prejuízo na cicatrização de feridas, alopecia, náusea, vômitos e estomatite;  
- para a ciclosporina: disfunção renal, tremores, aumento da quantidade de pelos no corpo, pressão alta, hipertrofia gengival, aumento dos níveis de colesterol e triglicerídeos, formigamentos, dor no peito, infarto do miocárdio, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, gastrite, úlcera péptica, soluços, inflamação na boca, dificuldade para engolir, hemorragias, inflamação do pâncreas, prisão de ventre, desconforto abdominal, síndrome hemolítico-urêmica, diminuição das células brancas do sangue, linfoma, calorões, hiperpotassemia, hipomagnesemia, hiperuricemia, toxicidade para os músculos, disfunção respiratória, sensibilidade aumentada a temperatura e reações alérgicas, toxicidade renal e hepática e ginecomastia (aumento das mamas no homem);  
- para a hidroxicloroquina: distúrbios visuais com visão borrada e fotofobia, edema macular, pigmentação anormal, retinopatia, atrofia do disco óptico, escotomas, diminuição da acuidade visual e nistagmo; outras reações: problemas emocionais, dores de cabeça, tonturas, movimentos involuntários, cansaço, branqueamento e queda de cabelos, mudanças da cor da pele e alergias leves a graves, náusea, vômitos, perda de apetite, desconforto abdominal, diarreia, parada na produção de sangue pela  
medula óssea (anemia aplásica), parada na produção de células brancas pela medula óssea (agranulocitose), diminuição de células brancas do sangue e de plaquetas, destruição das células do sangue (hemólise); reações raras: miopatia, paralisia, zumbido e surdez;  
- para a imunoglobulina humana: dor de cabeça, calafrios, febre, e reações no local de aplicação da injeção, incluindo dor, coceira e vermelhidão, e problemas renais que incluem aumento de creatinina e ureia no sangue, insuficiência renal aguda, necrose tubular aguda, nefropatia tubular proximal, nefrose osmótica.  
- para o metotrexato: convulsões, encefalopatia, febre, calafrios, sonolência, queda de cabelo, espinhas e furúnculos, alergias de pele, sensibilidade à luz, alterações da pigmentação da pele e de mucosas, náusea, vômitos, perda de apetite, inflamação na boca, úlceras de trato gastrointestinal, hepatite, cirrose e necrose hepática, diminuição das células brancas do sangue e das plaquetas, insuficiência renal, fibrose pulmonar, diminuição das defesas imunológicas do organismo com ocorrência de infecções;  
- para a metilprednisolona (pulsoterapia): retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação, e manifestação de diabete melito;  
- para prednisona: aumento do apetite, úlcera gástrica com possível perfuração e sangramento, inflamação do pâncreas, cansaço, insônia, catarata, aumento da pressão dentro do olho, glaucoma, olhos inchados, aumento da ocorrência de infecção do olhos por fungos e vírus. Pode surgir também diabetes e aumento dos valores de colesterol.  
Esses medicamentos podem causar eventos adversos. Consultas e exames durante o tratamento são necessários.  
Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- ( ) azatioprina  
- ( ) ciclosporina  
- ( ) ciclofosfamida  
- ( ) hidroxicloroquina  
- ( ) imunoglobulina humana  
- ( ) metilprednisolona  
- ( ) metotrexato  
- ( ) prednisona  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|_____________________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
**Nota 1:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**Nota 2:** A administração endovenosa de metilprednisolona e de ciclofosfamida é compatível, respectivamente, com os procedimentos 03.03.02.001-6 - PULSOTERAPIA I (POR APLICAÇÃO) e 03.03.02.002-4 - PULSOTERAPIA II (POR APLICAÇÃO), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Escopo e finalidade do Protocolo** -->
O presente Apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Miopatias Inflamatórias contendo a descrição da metodologia de busca de evidências científicas e a síntese das evidências, tendo como objetivos embasar o texto do PCDT, aumentar a transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos reumatologistas, além de representantes do Ministério da Saúde, universidades, hospitais de excelência e sociedades médicas.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
O processo de elaboração do PCDT de Miopatias Inflamatórias iniciou-se com a demanda de atualização do PCDT de Dermatomiosite e polimiosite. A reunião para delimitação do escopo de atualização do referido PCDT ocorreu no dia 14 de julho de 2022. A dinâmica da reunião incluiu a discussão de cada seção do PCDT publicado pela Portaria SAS/MS nº 1692, de 22 de novembro de 2016, bem como das condutas clínicas e tecnologias que poderiam ser priorizadas para que fosse realizada revisão sistemática das evidências com ou sem formulação de recomendações – sendo norteada por uma revisão prévia de diretrizes internacionais e revisões sistemáticas recentemente publicadas. Na reunião, foram identificadas a necessidade de sínteses de evidências sobre os medicamentos rituximabe e micofenolato, uma vez que eles não possuem indicação aprovada pela Anvisa para tratamento de miopatias. Além disso, discutiu-se a utilização do anticorpo anti-Jo1 na avaliação de diagnóstico e/ou prognóstico das miopatias. Sendo assim, foram estabelecidas perguntas de pesquisa a serem respondidas sobre três tecnologias: **(i)** rituximabe; **(ii)** micofenolato de mofetila e; **(iii)** anticorpo anti-Jo1. Adicionalmente, os especialistas sugeriram a alteração do título do documento para PCDT de Miopatias Inflamatórias, para descrever melhor todas as formas de apresentação da doença.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Equipe de elaboração e partes interessadas** -->
Colaboração externa  
O Protocolo foi atualizado pelo NATS Unifesp Diadema.  
Declaração e Manejo de Conflitos de Interesse  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A.** Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum|dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|  
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|---|---|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT das Miopatias inflamatórias foi apresentada na 119ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 15 de outubro de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS) e da Secretaria de Atenção Especializada em Saúde (SAES). O PCDT foi aprovado para avaliação da CONITEC e a proposta foi apresentada aos membros do Comitê de PCDT da CONITEC em sua 135ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Consulta pública** -->
A Consulta Pública nº 83/2024, do Protocolo Clínico e Diretrizes Terapêuticas das Miopatias Inflamatórias, recebeu 3 contribuições durante o período de 22 de novembro de 2024 a 11 de dezembro de 2024. O conteúdo integral das contribuições pode ser verificado em:  https://www.gov.br/conitec/pt-br/assuntos/participacao-social/consultas-publicas/encerradas

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações das Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto), conforme **Quadro B**<sup>1</sup> .  
**Quadro B.** Níveis de evidências de acordo com o sistema GRADE  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|**Moderado**|Há confiança moderada no efeito estimado.|Trabalhos futuros poderão modificar a confiança na<br>estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante em nossa confiança na estimativa de efeito.|
|**Muito baixo**|A confiança na estimativa de efeito é muito<br>limitada.<br>Há importante grau de incerteza nos<br>achados.|Qualquer estimativa de efeito é incerta.|  
**Fonte:** Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014<sup>2</sup> .  
Para a atualização do PCDT, foram consideradas as recomendações de diretrizes clínicas de maior qualidade metodológica de acordo com a segunda versão do instrumento _Appraisal of Guidelines for Research and Evaluation_ (AGREE II)<sup>3</sup> . O texto foi complementado com a citação de outras fontes como revisões sistemáticas, estudos de prevalência e outros que pudessem contribuir para um documento mais informativo.  
Dessa forma, foi conduzida busca na literatura para identificar as diretrizes clínicas disponíveis sobre miopatias, conforme descrito no **Quadro C** . Depois da elegibilidade por leitura de título e resumos, e pela leitura de texto completo - todas essas etapas foram realizadas por dois pesquisadores de forma independente e com as discrepâncias sendo discutidas junto a um terceiro pesquisador.  
**Quadro C.** Estratégia de busca para identificação de diretrizes clínicas sobre miopatias inflamatórias  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|**Pubmed**|("Myositis"[Mesh] OR (Myositides) OR (Myopathy, Inflammatory) OR<br>(Muscle Diseases, Inflammatory) OR (Inflammatory Muscle Diseases) OR<br>(Inflammatory Muscle Disease) OR (Muscle Disease, Inflammatory) OR<br>(Inflammatory Myopathy) OR (Inflammatory Myopathies) OR (Myopathies,<br>Inflammatory) OR (Myositis, Proliferative) OR (Myositides, Proliferative) OR<br>(Proliferative Myositides) OR (Proliferative Myositis) OR (Myositis,<br>Infectious) OR (Infectious Myositides) OR (Myositides, Infectious) OR<br>(Infectious Myositis) OR (Idiopathic Inflammatory Myopathies) OR<br>(Myopathy, Idiopathic Inflammatory) OR (Inflammatory Myopathy,<br>Idiopathic) OR (Idiopathic Inflammatory Myopathy) OR (Idiopathic<br>Inflammatory Myositis) OR (Inflammatory Myopathies, Idiopathic) OR<br>(Myopathies, Idiopathic Inflammatory) OR (Myositis, Focal) OR (Focal<br>Myositides)<br>OR<br>(Focal<br>Myositis)<br>OR<br>(Myositides,<br>Focal)<br>OR<br>"Polymyositis"[Mesh] OR (Polymyositides) OR (Myositis, Multiple) OR<br>(Multiple Myositis) OR (Myositides, Multiple) OR (Polymyositis, Idiopathic)<br>OR (Idiopathic Polymyositides) OR (Idiopathic Polymyositis) OR<br>(Polymyositides, Idiopathic) OR (Polymyositis Ossificans) OR (Ossificans,<br>Polymyositis) OR "Dermatomyositis"[Mesh] OR (Dermatopolymyositis) OR<br>(Polymyositis-Dermatomyositis) OR (Polymyositis Dermatomyositis) OR<br>(Dermatomyositis, Adult Type) OR (Adult Type Dermatomyositis) OR<br>(Dermatomyositis, Childhood Type) OR (Childhood Type Dermatomyositis)<br>OR (Juvenile Dermatomyositis) OR (Dermatomyositis, Juvenile) OR<br>(Juvenile Myositis) OR (Myositis, Juvenile)) AND AND (("Guideline"<br>[Publication Type] OR "Guidelines as Topic"[Mesh] OR "Practice Guideline"<br>[Publication Type] OR "Health Planning Guidelines"[Mesh]OR Guidelines as<br>Topics OR Clinical Practice Guideline OR "Clinical Protocols"[Mesh] OR<br>Protocol, Clinical OR Clinical Protocol OR Protocols, Clinical OR Treatment<br>Protocols OR Treatment Protocol OR Protocols, Treatment OR Clinical<br>Research Protocol OR Research Protocols, Clinical OR Protocols, Clinical<br>Research OR Research Protocol, Clinical OR Clinical Research Protocols OR<br>Protocol, Clinical Research OR "Consensus"[Mesh] OR "Consensus<br>Development Conference, NIH" [Publication Type] OR "Consensus<br>Development Conference" [Publication Type] OR "Consensus Development|946|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||Conferences, NIH as Topic"[Mesh] OR "Consensus Development<br>Conferences as Topic"[Mesh] OR "Standard of Care"[Mesh] OR Care<br>Standard OR Care Standards OR Standards of Care)||
|**Embase**<br>**Total**|('myositis'/exp<br>OR<br>(allergic AND myositis)<br>OR<br>(idiopathic AND inflammatory AND myopathy)<br>OR<br>(inflammatory AND myopathy)<br>OR<br>(muscle AND infection)<br>OR<br>(muscle AND inflammation)<br>OR<br>(myopathy, AND inflammatory)<br>OR<br>(myositis, AND allergic)<br>OR neuromyositis OR 'dermatomyositis'/exp<br>OR dermatomucomyositis OR dermatomyositides OR<br>(petges AND clegat AND syndrome)<br>OR poikilodermatomyositis OR<br>(polymyositis AND arthropathica)<br>OR<br>(wegner AND hepp AND unverrricht AND disease)<br>OR 'polymyositis'/exp<br>OR fibromyositis OR inomyositis OR (myositis, AND poly)) AND ('practice<br>guideline'/exp<br>OR<br>(clinical AND practice AND guidelines)<br>OR guidelines OR<br>(guidelines AND as AND topic)<br>OR<br>(practice AND guidelines)<br>OR<br>(practice AND guidelines AND as AND topic)<br>OR 'clinical<br>protocol'/exp<br>OR 'consensus'/exp)<br>AND<br>[embase]/lim<br>NOT<br>([embase]/lim<br>AND<br>[medline]/lim) AND (2017:py OR 2018:py OR 2019:py OR 2020:py OR<br>2021:py OR 2022:py OR 2023:py)|1266<br>**2.212**|  
Os resultados do processo de elegibilidade são apresentados na **Figura A.** Das 40 publicações triadas, 17 foram excluídas na elegibilidade por leitura de texto completo ( **Quadro D** ) e 23 foram incluídas para avaliação com o AGREE II.  
**Figura A.** Fluxograma com resultados da busca e seleção das diretrizes clínicas sobre miopatias inflamatórias.  
<!-- Start of picture text -->
Referéncias identificadas em: Referénci: idas antes do<br>BasesPubmedErasede dados(n=(n = 946) (n=1.266)2.246) processoDuplicatasde seeyao, (n =63)<br>Busca em repositdrios (n=34)<br>Referencias avalladas por titulo Referéncias excluidas<br>(n=2.183) (n= 2.143)<br>Referéncias incluidas para Referéncias cujo texto completo<br>av aliacdo por texto completa nao foi identificado<br>(n= 40) (n= 0)<br>Referéncias avaliadas por texto Referéncias excluidas (n = 17)<br>completo Nao é uma diretriz clinica (r=13)<br>(n= 40) Idioma (n=4)<br>Diretrizes Clinicas incluidas<br>(n= 23)<br><!-- End of picture text -->  
**Fonte:** Autoria própria com base na publicação de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prismastatement.org/<sup>4</sup>  
**Quadro D.** Lista de referências excluídas na elegibilidade por texto completo e motivo de exclusão – Revisão sistemática para identificação de diretrizes clínicas sobre miopatias inflamatórias.  
|**_Não é diretriz clínica_**|
|---|
|1.<br>Aggarwal, Rohit et al. 2016 American College of Rheumatology/European League Against Rheumatism Criteria  for|
|Minimal, Moderate, and Major Clinical Response in Adult Dermatomyositis and Polymyositis: An International Myositis|
|Assessment and Clinical Studies Group/Paediatric Rheumatology International Trials Organisation Collaborative Initiative.<br>Arthritis & Rheumatology (Hoboken, N.J.), v. 69, n. 5, p. 898–910, 2017.|
|2.<br>Concha, J S et al. Developing Classification Criteria for Cutaneous Dermatomyositis. Journal of the Dermatology|
|Nurses’<br>Association,<br>v.<br>12,<br>n.<br>2,<br>2020.<br>Disponível<br>em:|
|<https://www.embase.com/search/results?subaction=viewrecord&id=L634426289&from=export>.|
|3.<br>Dalakas, M C. Intravenous Immunoglobulin in the Treatment of Autoimmune Neuromuscular Diseases:  Present|
|Status and Practical Therapeutic Guidelines. Muscle & Nerve, v. 22, n. 11, p. 1479–1497, 1999.|
|4.<br>Ernste, Floranne C; Reed, Ann M. Idiopathic Inflammatory Myopathies: Current Trends in Pathogenesis, Clinical|
|Features, and up-to-Date Treatment Recommendations. Mayo Clinic Proceedings, v. 88, n. 1, p. 83–105, 2013.|
|5.<br>Gupta, Latika et al. Insights into the Knowledge, Attitude and Practices for the Treatment of  Idiopathic Inflammatory|  
Myopathy from a Cross-Sectional Cohort Survey of Physicians. Rheumatology International, v. 40, n. 12, p. 2047–2055, 2020.  
|6.<br>Lundberg, Ingrid E. Expert Perspective: Management of Refractory Inflammatory Myopathy. Arthritis &<br>Rheumatology (Hoboken, N.J.), v. 73, n. 8, p. 1394–1407, 2021.|
|---|
|7.<br>Mccann, Liza J et al. Developing a Provisional, International Minimal Dataset for Juvenile  Dermatomyositis: For<br>Use in Clinical Practice to Inform Research. Pediatric Rheumatology Online Journal, v. 12, p. 31, 2014.|
|8.<br>Oddis, Chester V et al. International Consensus Guidelines for Trials of Therapies in the Idiopathic  Inflammatory<br>Myopathies. Arthritis and Rheumatism, v. 52, n. 9, p. 2607–2615, 2005.|
|9.<br>Rasool, S et al. Audit of Anti-Nuclear Antibody Testing in East Kent and the British Society for Rheumatology<br>Choosing Wisely Recommendations. Rheumatology (United Kingdom), v. 59, p. ii23–ii23, 2020.|
|10.<br>RIDER, Lisa G; AGGARWAL, Rohit; et al. 2016 American College of Rheumatology/European League Against<br>Rheumatism Criteria  for Minimal, Moderate, and Major Clinical Response in Juvenile Dermatomyositis: An International<br>Myositis Assessment and Clinical Studies Group/Paediatric Rheumatology International Trials Organisation Collaborative<br>Initiative. Arthritis & Rheumatology (Hoboken, N.J.), v. 69, n. 5, p. 782–791, 2017.|
|11.<br>Rider, Lisa G et al. International Consensus on Preliminary Definitions of Improvement in Adult and  Juvenile<br>Myositis. Arthritis and Rheumatism, v. 50, n. 7, p. 2281–2290, 2004.|
|12.<br>Tansley, Sarah et al. Developing Standardised Treatment for Adults with Myositis and Different  Phenotypes: An<br>International Survey of Current Prescribing Preferences. Clinical and Experimental Rheumatology, v. 34, n. 5, p. 880–884,<br>2016.|
|13.<br>Wilkinson, M G; Mccann, L J. Juvenile Dermatomyositis (JDM) Working Party Update. Pediatric Rheumatology, v.<br>18, 2020.|
|**Idioma**|
|14.<br>Hoogendijk, J E et al. [The practice guideline ’Dermatomyositis, polymyositis and sporadic inclusion  body<br>myositis’]. Nederlands tijdschrift voor geneeskunde, v. 149, n. 38, p. 2104–2111, 2005.|
|15.<br>Wegener, M. Strong treatment for muscle weakness: New guideline for the treatment of myositis syndromes<br>published. Deutsche Apotheker Zeitung, v. 162, n. 34, 2022.|
|16.<br>[Chinese expert-based consensus statement on diagnosis and treatment of  idiopathic inflammatory myopathy<br>associated interstitial lung disease]. Zhonghua jie he he hu xi za zhi = Zhonghua jiehe he huxi zazhi = Chinese journal  of<br>tuberculosis and respiratory diseases, v. 45, n. 7, p. 635–650, 2022.|
|17.<br>CAI, H R; XU, Z J. [Process and reflections on the development of expert consensus on diagnosis and  treatment of<br>idiopathic inflammatory myopathy associated interstitial lung disease]. Zhonghua jie he he hu xi za zhi = Zhonghua jiehe he<br>huxi zazhi = Chinese journal  of tuberculosis and respiratory diseases, v. 45, n. 7, p. 629–631, 2022.|  
A avaliação de qualidade metodológica foi conduzida empregando-se os domínios 3 e 6 do AGREE II, sendo realizada por dois pesquisadores previamente capacitados e com ampla experiência no uso da ferramenta. Os resultados da avaliação estão descritos no **Quadro E** .  
**Quadro E.** Escore das diretrizes clínicas sobre miopatias, avaliadas com o AGREE II  
|**Diretriz Clínica**|**Domínio 3 Rigor**<br>**metodológico**|**Domínio 6**<br>**Independência**<br>**Editorial**|
|---|---|---|
|ALEXANDERSON, H; LUNDBERG, I E. Disease-Specific Quality<br>Indicators, Outcome Measures and Guidelines in Polymyositis and<br>Dermatomyositis. Clinical and Experimental Rheumatology, v. 25, n. 6, p.<br>153–158, 2007.|2,08%|0%|
|BADER-MEUNIER, B et al. French Expert Opinion for the Management<br>of Juvenile Dermatomyositis. Archives de Pediatrie : Organe Officiel de<br>La Societe Francaise de Pediatrie, v. 26, n. 2, p. 120–125, 2019.|35,4%|50%|
|BELLUTTI<br>ENDERS,<br>Felicitas<br>et<br>al.<br>Consensus-Based<br>Recommendations for the Management of Juvenile Dermatomyositis.<br>Annals of the Rheumatic Diseases, v. 76, n. 2, p. 329–340, 2017.|62,5%|66,7%|
|DE SOUZA, Fernando Henrique Carlos et al. Guidelines of the Brazilian<br>Society of Rheumatology for the Treatment of Systemic Autoimmune<br>Myopathies. Advances in Rheumatology (London, England), v. 59, n. 1,<br>p. 6, 2019.|52,1%|83,3%|
|DONOFRIO, Peter D et al. Consensus Statement: The Use of Intravenous<br>Immunoglobulin in the Treatment of Neuromuscular Conditions Report of<br>the AANEM Ad Hoc Committee. Muscle & Nerve, v. 40, n. 5, p. 890–<br>900, 2009.|33,3%|50%|
|DRAKE, L A et al. Guidelines of Care for Dermatomyositis. American<br>Academy of Dermatology. Journal of the American Academy of<br>Dermatology, v. 34, n. 5, p. 824–829, 1996.|0%|0%|
|EL MIEDANY, Y et al. Egyptian evidence-based consensus<br>recommendations for diagnosis and targeted management of juvenile<br>dermatomyositis. An initiative by the Egyptian College Of Pediatric<br>Rheumatology. Rheumatology (United Kingdom), v. 61, p. ii16–ii16,<br>2022.|8,3%|0%|
|ELOVAARA, I et al. EFNS Guidelines for the Use of Intravenous<br>Immunoglobulin in Treatment of Neurological Diseases: EFNS Task<br>Force on the Use of Intravenous Immunoglobulin in Treatment of<br>Neurological Diseases. European Journal of Neurology, v. 15, n. 9, p. 893–<br>908, 2008.|25%|33,3%|
|ERNSTE, Floranne C; REED, Ann M. Idiopathic Inflammatory<br>Myopathies: Current Trends in Pathogenesis, Clinical Features, and up-to-<br>Date Treatment Recommendations. Mayo Clinic Proceedings, v. 88, n. 1,<br>p. 83–105, 2013.|8,3%|0%|
|FEASBY, Tom et al. Guidelines on the Use of Intravenous Immune<br>Globulin for Neurologic Conditions. Transfusion Medicine Reviews, v.<br>21, n. 2, p. S57-107, 2007.|52,1%|0%|  
|**Diretriz Clínica**|**Domínio 3 Rigor**<br>**metodológico**|**Domínio 6**<br>**Independência**<br>**Editorial**|
|---|---|---|
|FUJIMOTO, Manabu et al. The Wound/Burn Guidelines - 4: Guidelines<br>for the Management of Skin Ulcers Associated with Connective Tissue<br>Disease/Vasculitis. The Journal of Dermatology, v. 43, n. 7, p. 729–757,<br>2016.|72,9%|58,3%|
|HINZE, C et al. Development of Consensus-Based Treat-to-Target<br>Protocols for the Management of Juvenile Dermatomyositis in Germany.<br>Pediatric Rheumatology, v. 15, p. 150–151, 2017.|20,8%|66,7%|
|HUBER, Adam M et al. Childhood Arthritis and Rheumatology Research<br>Alliance<br>Consensus<br>Clinical<br>Treatment<br>Plans<br>for<br>Juvenile<br>Dermatomyositis<br>with<br>Persistent<br>Skin<br>Rash.<br>The<br>Journal<br>of<br>Rheumatology, v. 44, n. 1, p. 110–116, 2017.|12,5%|0%|
|______. Consensus Treatments for Moderate Juvenile Dermatomyositis:<br>Beyond the First Two Months. Results of the Second Childhood Arthritis<br>and Rheumatology Research Alliance Consensus Conference. Arthritis<br>Care & Research, v. 64, n. 4, p. 546–553, 2012.|10,4%|58,3%|
|______. Protocols for the Initial Treatment of Moderately Severe Juvenile<br>Dermatomyositis: Results of a Children’s Arthritis and Rheumatology<br>Research Alliance Consensus Conference. Arthritis Care & Research, v.<br>62, n. 2, p. 219–225, 2010.|10,4%|33,3%|
|KIM, Susan et al. Childhood Arthritis and Rheumatology Research<br>Alliance<br>Consensus<br>Clinical<br>Treatment<br>Plans<br>for<br>Juvenile<br>Dermatomyositis<br>with<br>Skin<br>Predominant<br>Disease.<br>Pediatric<br>Rheumatology Online Journal, v. 15, n. 1, p. 1, 2017.|10,4%|66,7%|
|KOBAYASHI, Ichiro et al. Clinical Practice Guidance for Juvenile|||
|Dermatomyositis (JDM) 2018-Update. Modern Rheumatology, v. 30, n. 3,<br>p. 411–423, 2020.|22,9%|66,7%|
|KOHSAKA, H et al. Treatment Consensus for Management of<br>Polymyositis and Dermatomyositis among Rheumatologists, Neurologists<br>and Dermatologists. Neurology and Clinical Neuroscience, v. 7, n. 1, p. 3–<br>21, 2019.|43,75%|66,7%|
|KOO, S.-M. et al. Korean Guidelines for Diagnosis and Management of<br>Interstitial Lung Diseases: Part 5. Connective Tissue Disease Associated<br>Interstitial Lung Disease. Tuberculosis and Respiratory Diseases, v. 82, n.<br>4, p. 285–297, 2019.|54,2%|100%|
|OLDROYD, A. G. S. et al. British Society for Rheumatology guideline on<br>management of paediatric, adolescent and adult patients with idiopathic|70,8%|66,7%|
|inflammatory myopathy. Rheumatology (Oxford) 61, 1760-1768 (2022)|||
|ROMERO-BUENO, F et al. Recommendations for the Treatment of Anti-|60,4%|58,3%|  
|**Diretriz Clínica**|**Domínio 3 Rigor**<br>**metodológico**|**Domínio 6**<br>**Independência**<br>**Editorial**|
|---|---|---|
|Melanoma Differentiation-Associated Gene 5-Positive Dermatomyositis-|||
|Associated Rapidly Progressive Interstitial Lung Disease. Seminars in<br>Arthritis and Rheumatism, v. 50, n. 4, p. 776–790, 2020.|||
|SUNDERKÖTTER, Cord et al. Guidelines on Dermatomyositis--Excerpt<br>from the Interdisciplinary S2k Guidelines on Myositis Syndromes by the|||
|German Society of Neurology. Journal Der Deutschen Dermatologischen|14,6%|33,3%|
|Gesellschaft = Journal of the German Society of Dermatology : JDDG, v.|||
|14, n. 3, p. 321–338, 2016.|||
|VAN ROYEN-KERKHOF, A. Share Recommendations on Juvenile<br>Dermatomyositis. Annals of the Rheumatic Diseases, v. 76, p. 9–10, 2017.|6,25%|50%|  
Considerando o critério de que o documento deveria ter ao menos 50% de escore em ambos os domínios do AGREE II, foram selecionadas as diretrizes clínicas que embasariam o texto do PCDT<sup>5-9</sup> . Em 05/10/2024 as buscas foram novamente realizadas para verificar se haviam novas diretrizes clínicas publicadas, não sendo identificados documentos que precisassem ser incluídos.  
Além da revisão sistemática de diretrizes clínicas, foram conduzidas revisões sistemáticas sobre o uso do rituximabe e do micofenolato de mofetila no tratamento de miopatias inflamatórias e da pesquisa do anticorpo anti-Jo1 para o diagnóstico e/ou prognóstico das miopatias.  
<u>Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas.</u>

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **QUESTÃO 1: O RITUXIMABE É SEGURO E EFICAZ PARA O TRATAMENTO DE PACIENTES COM MIOPATIAS INFLAMATÓRIAS EM COMPARAÇÃO À OUTRAS TECNOLOGIAS DISPONÍVEIS NO SUS?** -->
_<u>A estrutura PICO para esta pergunta foi:</u>_  
**População:** Pacientes com miopatias inflamatórias  
**Intervenção:** Rituximabe  
**Comparador:** Medicamentos preconizados no PCDT (azatioprina, metotrexato, ciclofosfamida, ciclofosfamida, imunoglobulina humana) ou placebo  
**Desfechos:** Força muscular medida pelo Manual _Muscular Test_ (MMT); melhora clínica de acordo com definição do _International Myositis Assessment & Clinical Studies Group_ (IMACS); melhora cutânea medida pela escala _Cutaneous Dermatomyositis Disease Area and Severity Index_ (CDASI); incidência de eventos adversos ao medicamento; melhora pulmonar por alterações na capacidade vital forçada (CVF); alterações na concentração de creatina quinase.  
**Tipo de estudo:** Estudos clínicos randomizados (ECR) ou estudos observacionais  
**Métodos e resultados da busca:**  
Foi realizada busca sistematizada da literatura nas bases de dados: MEDLINE (via PubMed), EMBASE e Cochrane Library. Não foram utilizadas restrições de data, idioma ou status da publicação (resumo ou texto completo). Todas as buscas  
foram conduzidas em 04 de agosto de 2022. O **Quadro F** detalha as estratégias de busca utilizadas para identificar as evidências para essa síntese, bem como o número de publicações encontradas em cada uma das bases.  
**Quadro F.** Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o uso rituximabe  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|**MEDLINE (via Pubmed)**|("Myositis"[Mesh] OR (Myositides) OR (Myopathy, Inflammatory) OR<br>(Muscle Diseases, Inflammatory) OR (Inflammatory Muscle Diseases)<br>OR (Inflammatory Muscle Disease) OR (Muscle Disease, Inflammatory)<br>OR (Inflammatory Myopathy) OR (Inflammatory Myopathies) OR<br>(Myopathies,<br>Inflammatory)<br>OR<br>(Myositis,<br>Proliferative)<br>OR<br>(Myositides,<br>Proliferative)<br>OR<br>(Proliferative<br>Myositides)<br>OR<br>(Proliferative Myositis) OR (Myositis, Infectious) OR (Infectious<br>Myositides) OR (Myositides, Infectious) OR (Infectious Myositis) OR<br>(Idiopathic Inflammatory Myopathies) OR (Myopathy, Idiopathic<br>Inflammatory) OR (Inflammatory Myopathy, Idiopathic) OR (Idiopathic<br>Inflammatory Myopathy) OR (Idiopathic Inflammatory Myositis) OR<br>(Inflammatory Myopathies, Idiopathic) OR (Myopathies, Idiopathic<br>Inflammatory) OR (Myositis, Focal) OR (Focal Myositides) OR (Focal<br>Myositis) OR (Myositides, Focal) OR "Polymyositis"[Mesh] OR<br>(Polymyositides) OR (Myositis, Multiple) OR (Multiple Myositis) OR<br>(Myositides, Multiple) OR (Polymyositis, Idiopathic) OR (Idiopathic<br>Polymyositides) OR (Idiopathic Polymyositis) OR (Polymyositides,<br>Idiopathic) OR (Polymyositis Ossificans) OR (Ossificans, Polymyositis)<br>OR<br>"Dermatomyositis"[Mesh]<br>OR<br>(Dermatopolymyositis)<br>OR<br>(Polymyositis-Dermatomyositis) OR (Polymyositis Dermatomyositis)<br>OR (Dermatomyositis, Adult Type) OR (Adult Type Dermatomyositis)<br>OR (Dermatomyositis, Childhood Type) OR (Childhood Type<br>Dermatomyositis)<br>OR<br>(Juvenile<br>Dermatomyositis)<br>OR<br>(Dermatomyositis, Juvenile) OR (Juvenile Myositis) OR (Myositis,<br>Juvenile)) AND ("Rituximab"[Mesh] OR (CD20 Antibody, Rituximab)<br>OR (Rituximab CD20 Antibody) OR (Mabthera) OR (IDEC-C2B8<br>Antibody) OR (IDEC C2B8 Antibody) OR (IDEC-C2B8) OR (IDEC<br>C2B8) OR (GP2013) OR (Rituxan))|482|
|**EMBASE**|('myositis'/exp OR (allergic AND myositis) OR (idiopathic AND<br>inflammatory AND myopathy) OR (inflammatory AND myopathy) OR<br>(muscle AND infection) OR (muscle AND inflammation) OR (myopathy,<br>AND inflammatory) OR (myositis, AND allergic) OR neuromyositis)<br>AND 'rituximab'/exp AND [embase]/lim NOT ([embase]/lim AND|1.410|  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||[medline]/lim)||
|**Cochrane Library**<br>**Total**|#1 MeSH descriptor: [Myositis] explode all trees<br>#2 Infectious Myositides OR Myositis, Infectious OR Infectious Myositis<br>OR Myositides, Infectious OR Inflammatory Myopathies OR Muscle<br>Diseases, Inflammatory OR Muscle Disease, Inflammatory OR<br>Myopathy,<br>Inflammatory<br>OR<br>Myopathies,<br>Inflammatory<br>OR<br>Inflammatory Myopathy OR Myositides OR Inflammatory Muscle<br>Diseases Inflammatory Muscle Disease OR Proliferative Myositides OR<br>Proliferative Myositis OR Myositides, Proliferative OR Myositis,<br>Proliferative OR Inflammatory Myopathy, Idiopathic OR Inflammatory<br>Myopathies, Idiopathic OR Idiopathic Inflammatory Myopathy OR<br>Myopathies, Idiopathic Inflammatory OR Myopathy, Idiopathic<br>Inflammatory OR Idiopathic Inflammatory Myopathies OR Idiopathic<br>Inflammatory Myositis OR Myositides, Focal OR Focal Myositides OR<br>Focal Myositis OR Myositis, Focal<br>#3 MeSH descriptor: [Dermatomyositis] explode all trees<br>#4 Myositides, Multiple OR Multiple Myositis OR Polymyositides OR<br>Myositis, Multiple OR Polymyositides, Idiopathic OR Idiopathic<br>Polymyositis OR Polymyositis, Idiopathic OR Idiopathic Polymyositides<br>OR Polymyositis Ossificans OR Ossificans, Polymyositis<br>#5 MeSH descriptor: [Polymyositis] explode all trees<br>#6<br>Polymyositis-Dermatomyositis<br>OR<br>Dermatopolymyositis<br>OR<br>Polymyositis Dermatomyositis OR Childhood Type Dermatomyositis OR<br>Juvenile Myositis OR Myositis, Juvenile OR Dermatomyositis,<br>Childhood<br>Type<br>OR<br>Dermatomyositis,<br>Juvenile<br>OR<br>Juvenile<br>Dermatomyositis OR Dermatomyositis, Adult Type OR Adult Type<br>Dermatomyositis<br>#7 MeSH descriptor: [Rituximab] explode all trees<br>#8 #1 OR #2 OR #3 OR #4 OR #5 OR #6<br>#9 #8 AND #7|16<br>**1.908**|  
A elegibilidade dos estudos foi realizada em duas etapas por dois revisores independentes. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI®<sup>10</sup> . Na segunda etapa, realizou-se a leitura de texto completo, também por dois revisores independentes, mantendo-se ECR e estudos observacionais que avaliassem o  
medicamento para a indicação analisada. As divergências foram resolvidas por meio de consenso entre os revisores ou com o auxílio de um terceiro pesquisador.  
_<u>Foram considerados como critérios de elegibilidade:</u>_  
- **(a)** Tipos de participantes  
Pacientes diagnosticados com qualquer tipo de miopatia inflamatória, em qualquer idade.  
- **(b)** Tipo de intervenção  
Rituximabe  
- **(c)** Tipos de estudos  
ECR controlados por placebos ou comparando o rituximabe com um dos medicamentos preconizados no PCDT e ou  
estudos observacionais que comparam o rituximabe com um dos medicamentos preconizados no PCDT.  
- **(d)** Desfechos  
Força muscular medida pelo MMT; melhora clínica de acordo com definição do IMACS; melhora cutânea medida pela escala CDASI; incidência de eventos adversos ao medicamento; melhora pulmonar por alterações na capacidade vital forçada (CVF); alterações na concentração de creatina quinase.  
- **(e)** Idioma

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Português, inglês ou espanhol. -->
Não foram aplicados quaisquer recortes para casos refratários ou para terapias prévias ao tratamento. Relatos e série de casos foram excluídos. Da mesma forma, estudos que utilizaram outras tecnologias diferentes daquelas preconizadas no PCDT como comparador também foram excluídos.  
Para análise de dados, foram realizadas meta-análises quando os estudos primários forneceram resultados suficientes que permitissem o agrupamento. Quando necessário, foi realizada conversão de medidas para possibilitar a associação de dados. Independentemente da sua natureza, os dados foram agrupados por meio de um modelo de efeitos aleatórios com intervalo de confiança (IC) de 95%. A análise foi realizada utilizando o pacote estatístico _RevMan_ versão 5.4.1 – _Cochrane Collaboration_ . Quando não foi possível agrupar os resultados ou realizar meta-análises, os resultados dos estudos primários foram relatados por meio de uma descrição narrativa do desfecho. Foi realizada avaliação do risco de viés utilizando a ferramenta de _NewCastleOttawa Scale_ (NOS)<sup>11</sup> para estudos observacionais e o instrumento validado da Colaboração _Cochrane_ (RoB 2.0)<sup>12</sup> para ECR. Para a avaliação do grau de certeza do conjunto final das evidências foi aplicado o método _The Grading of Recommendations Assessment, Development and Evaluation_ (GRADE)<sup>1</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Resultados da busca -->
Por meio das estratégias de busca definidas ( **Quadro F** ) foram identificadas 1.908 publicações. Após exclusão das duplicatas (n=61) e de elegibilidade por título e resumo, 16 referências foram selecionadas para avaliação por texto completo. Foram identificados quatro estudos observacionais<sup>13-16</sup> e um ECR<sup>17</sup> que atendiam integralmente aos critérios de inclusão. A **Figura B** resume os resultados do processo de busca e seleção de estudos e no **Quadro G** estão disponíveis as referências excluídas na elegibilidade por leitura de texto completo e seus motivos de exclusão.  
**Figura B.** Fluxograma com resultados da busca e seleção dos estudos incluídos sobre o rituximabe para o tratamento de miopatias inflamatórias.  
<!-- Start of picture text -->
g ReferénciasBasesPubMedde dadosidentificadas(n= 1.908)em: Referéncias.  removidas antesdo<br>Embase (n= 1.410) Duplicatas (n =62)<br>: (n= 482) processo de selegao.<br>£ Cochrane CENTRAL (n= 16)<br>Referencias avalladas por titulo Referéncias excluidas:<br>(n=1.848) (n= 1.830)<br>Referéncias incluidas para Referéncias cujo texto completo<br>avaliagao por texto completo nao foi identificado<br>(n= 16) (n=O)<br>Referéncias excluidas (n= 11):<br>Referéncias avaliadas por texto Delineamerto de estudo (n=3)<br>completo Comparador (n= 6)<br>(n= 16) InterveneSem desfecho0 (n= de1)interesse (n<br>=D<br>Estudos incluidos na revisao<br>(n=5)<br>Relatos dos estudos incluidos<br>(n=5)<br><!-- End of picture text -->  
**Fonte:** Autoria própria com base na publicação de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prismastatement.org/<sup>4</sup>  
**Quadro G.** Lista de referências excluídas na elegibilidade por texto completo e motivo de exclusão – Revisão sistemática sobre o rituximabe para o tratamento de miopatias inflamatórias.  
|**_Delineamento do estudo: protocolo de estudo_**|
|---|
|1.<br>Tsipouri V, Saunders P, Keir GJ, Ashby D, Fletcher SV, Gibbons M, et al. Rituximab versus cyclophosphamide for<br>the treatment of connective t.issue disease associated interstitial lung disease (RECITAL): A randomised controlled trial.<br>Trials. 2017.|
|**_Delineamento do estudo: carta_**|
|2.<br>Vargas Lebrón C, Ruiz Montesino MD, Moreira Navarrete V, Toyos Sainz de Miera FJ. Treatment With Rituximab<br>in Juvenile Dermatomyositis: Effect on Calcinosis. Reumatol Clin (Engl Ed). 2020.|
|3.<br>Gilaberte S, Rua J, Isenberg D. ADVERSE EVENTS OF TREATMENT WITH RITUXIMAB IN PATIENTS WITH<br>MYOSITIS. Rheumatology (Oxford). 2022.|
|**_Comparador_**|
|4.<br>Zhu L, Li S, Gagne L, Jacobs S, Morisset J, Mooney J, et al. Rituximab versus mycophenolate mofetil in interstitial<br>lung disease secondary to connective tissue disease. Arthritis and Rheumatology. 2018|  
5. Burnside R, Mira-Avendano IC. Mycophenolate and rituximab in patients with interstitial lung disease associated with connective tissue disorder in the setting of positive myositis antibodies: A retrospective analysis. American Journal of Respiratory and Critical Care Medicine. 2018.  
6. Khelkovskaya-Sergeeva AN, Antelava OA, Olyunin YA, Tarasova GM, Lopatina NE, Palshina SE, et al. Rituximab in patients with idiopathic inflammatory myopathies associated with interstitial lung disease. Annals of the Rheumatic Diseases. 2016.  
7. Levine TD. Rituximab in the treatment of dermatomyositis: an open-label pilot study. Arthritis Rheum. 2005. 8. Egeli BH, Ergun S, Cetin A, Gursoy YK, Ugurlu S. Rituximab as a glucocorticoid-sparing agent in idiopathic inflammatory myopathies: a retrospective single-center cohort study. Clin Rheumatol. 2022.  
9. García Hernández FJ, Chinchilla Palomares E, Castillo Palma MJ, González Pulido C, Ocaña Medina C, Sánchez Román J. [Evaluation of the effectiveness of treatment with rituximab associated to cyclophosphamide in patients with resistant idiopathic inflammatory myopathy]. Med Clin (Barc). 2010.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_Intervenção_** -->
10. Taborda L, Azevedo PC, Isenberg D. Retrospective analysis of the outcome of patients with polymyositis and dermatomyositis. Rheumatology (United Kingdom). 2013.  
**_Sem desfecho de interesse_**  
<mark>11. Aggarwal R, Loganathan P, Koontz D, Qi Z, Reed AM, Oddis CV. Cutaneous improvement in refractory adult and juvenile dermatomyositis after treatment with rituximab. Rheumatology (Oxford, England). 2017</mark>  
Análise e apresentação dos resultados  
Resumo das evidências:  
O único ECR incluído nesta síntese foi o estudo publicado por Oddis (2013)<sup>17</sup> , que comparou o tratamento com rituximabe _versus_ placebo em 195 pacientes refratários, com pelo menos 5 anos de idade, diagnosticados com dermatomiosite (DM), polimiosite (PM) ou DM juvenil. Esse ECR, denominado “ _Rituximab in Myositis_ ” - RIM (NCT00106184), utilizou um delineamento de primeira fase randomizada e controlada por placebo. Os pacientes foram randomizados para os grupos “rituximabe precoce” – intervenção administrada no início do estudo e paciente passa a receber placebo da semana 8 até a semana 44 – ou “rituximabe tardio” – placebo administrado no início do estudo e paciente passa a receber intervenção da semana 8 até a semana 44. A medida de desfecho na semana 8 foi considerada como desfecho final do ECR controlado por placebo.  
Os estudos observacionais incluídos foram: Shahin (2021)<sup>16</sup> , Langlois (2016)<sup>15</sup> , Mao (2020)<sup>13</sup> e      Langlois (2020)<sup>14</sup> . Com exceção de Shahin (2021)<sup>16</sup> , um estudo observacional prospectivo, todos os demais foram classificados como coortes retrospectivas quanto ao delineamento de estudo. A dose e o esquema posológico do rituximabe variaram entre os estudos - foram mencionadas infusões de 100 mg<sup>13</sup> , 1g<sup>14-16</sup> e doses conforme a área de superfície corporal<sup>14,17</sup> . Todos eles utilizaram a ciclofosfamida como comparador, mas não houve consenso em relação à sua dose. Da mesma forma, todos os estudos mencionaram a utilização de pelo menos um medicamento associado à intervenção ou comparador, que variaram entre glicocorticoides, azatioprina, micofenolato, metotrexato, ciclofosfamida, tacrolimo e imunoglobulina venosa.  
Três dos cinco estudos incluídos avaliaram o tratamento com rituximabe em pacientes refratários<sup>13,16,17</sup> . Com exceção dos estudos publicados por Oddis (2013)<sup>17</sup> e Langlois (2020)<sup>14</sup> , que incluíram, respectivamente, pacientes com pelo menos 5 anos de idade e pacientes maiores de 18 anos, a maioria dos estudos não estabeleceu critérios de idade para inclusão de pacientes<sup>13,15,16</sup> . Três estudos incluíram pacientes com miopatias inflamatórias associada à doença pulmonar intersticial<sup>13-15</sup> . Entre os tipos de miopatias inflamatórias avaliadas, foram citadas especificamente dermatomiosite (DM), polimiosite (PM) e DM juvenis. Apenas os estudos de Langlois (2016)<sup>15</sup> e (Langlois 2020)<sup>14</sup> não descreveram o tipo de miopatia inflamatória avaliada. As características  
por estudo estão detalhadas no **Quadro H** , incluindo os desfechos avaliados em cada um. Dentre os desfechos selecionados na pergunta de pesquisa, apenas o desfecho de melhora cutânea pela escala CDASI não foi avaliado por nenhum estudo incluído na síntese de evidências.  
**Quadro H.** Características dos estudos que avaliaram o rituximabe no tratamento de miopatias inflamatórias.  
|**Autor, ano**|**População**|**N**|**Rituximabe**<br>**Dose/esquema**<br>**posológico**|**N**|**Comparador**<br>**Comparador**<br>**Dose/esquema**<br>**posológico**|**Desfechos**<br>**avaliados**|
|---|---|---|---|---|---|---|
|**Oddis, 2013**<sup>**17**</sup>|Pacientes<br>refratários,<br>diagnosticados<br>com<br>DM, PM ou DM juvenil<br>e com pelo menos 5<br>anos de idade|93|Crianças com SAC ≤<br>1,5 m<sup>2</sup>: 575 mg/m<sup>2</sup><br>Crianças ou adultos<br>com SAC > 1,5 m<sup>2</sup>: de<br>750 mg/m<sup>2</sup>até 1 g por<br>infusão|102|**Placebo**|Melhora<br>clínica<br>de<br>acordo<br>com<br>definição<br>do<br>IMACS|
|**Shahin, 2021**<sup>**16**</sup>|Pacientes<br>diagnosticados com DM<br>ou PM por meio dos<br>critérios de Bohan e<br>Peter<br>Idade média (anos) ±<br>DP = 34,9 ± 14,9 (faixa:<br>16,0–62,0)|5|3 infusões de 1 g com<br>6 meses de intervalo|17|**Ciclofosfamida**<br>**Primeira etapa**<br>Infusões mensais em<br>pulso com dose de<br>0.5–0.75/m<sup>2</sup><br>por<br>6<br>meses consecutivos.<br>**Segunda etapa**<br>Infusões a cada 3<br>meses por mais 6<br>ciclos (18 meses).<br>Infusões<br>precedidas<br>por metilprednisolona<br>IV e esteroides orais<br>(0,5 mg/kg/dia) que<br>foram<br>gradualmente<br>reduzidos.|Eventos<br>adversos|
|**Langlois, 2016**<sup>**15**</sup>|Pacientes<br>diagnosticados com MI<br>associada a DPI|15|2 infusões iniciais de<br>1 g nos dias 1 e 15. As<br>infusões de 1g foram<br>repetidas a cada 6<br>meses (mediana de<br>infusões = 3, IQQ = 1-<br>2)|28|**Ciclofosfamida**<br>Infusões mensais de 6<br>pulsos com dose de<br>700mg/m<sup>2</sup><br>sempre<br>seguida<br>por<br>azatioprina<br>ou<br>micofenolato|Eventos<br>adversos<br>Capacidade<br>vital forçada|
|**Mao, 2020**<sup>**13**</sup>|Pacientes<br>diagnosticados com DM<br>ou PM associadas a DPI<br>e<br>positivos<br>para<br>o|11|Infusão única de 100<br>mg|19|**Ciclofosfamida**<br>0,2 g/dia em dias<br>alternados ou 0,4–1,0|Eventos<br>adversos|  
||||**Rituximabe**||**Comparador**||
|---|---|---|---|---|---|---|
||||||**Comparador**|**Desfechos**|
|**Autor, ano**|**População**|**N**|**Dose/esquema**<br>**posológico**|**N**|<br>**Dose/esquema**<br>**posológico**|**avaliados**|
||anticorpo anti-MDA5.<br>Diagnóstico<br>estabelecido<br>pelos<br>critérios<br>de<br>EULAR/ACR.<br>Idade mediana (anos) =<br>51,3||||g/m<sup>2</sup><br>a<br>cada<br>2-3<br>semanas||
|**Langlois, 2020**<sup>**14**</sup>|Pacientes maiores de 18<br>anos com síndrome SA<br>relacionada a DPI, pelo<br>menos<br>2<br>testes<br>consecutivos positivos<br>para o anticorpo anti-<br>ARS e sem tratamento<br>prévio com rituximabe<br>ou ciclofosfamida<br>Idade mediana (anos) =<br>54, IQQ = 45–63|28|2 infusões de 1 g nos<br>dias 1 e 15 ou 375<br>mg/m<sup>2</sup>1 vez por<br>semana<br>durante<br>4<br>semanas.<br>Todos os pacientes<br>receberam uma dose<br>de manutenção de 1g<br>a<br>cada<br>6<br>meses<br>(mediana = 3, IIQ = 2-<br>10)|34|**Ciclofosfamida**<br>Infusões mensais de<br>750<br>mg/m<sup>2</sup><br>em<br>combinação com alta<br>dose de esteroides<br>Mediana<br>de<br>doses<br>infusões mensais = 6<br>(faixa de 2-12).|Força<br>muscular<br>Eventos<br>adversos<br>Creatina<br>quinase<br>Capacidade<br>vital forçada|  
**DPI:** doença pulmonar intersticial; **DM:** dermatomiosite; **DP:** desvio padrão; **IIQ:** intervalo interquartil; **IV:** intravenoso; **PM:** polimiosite; **MI:** miopatias inflamatórias; **SA:** síndrome antissintetase; **SAC:** superfície de área corporal

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Avaliação do risco de viés</u>** -->
A avaliação do risco de viés pela ferramenta _Risk of Bias_ 2 (RoB 2)<sup>12</sup> , mostrou que o único ensaio clínico avaliado (Oddis, 2013)<sup>17</sup> foi classificado como alto risco de viés devido às incertezas acerca da randomização e cegamento e aos problemas na aferição do desfecho de interesse, conforme observado no **Quadro I** .  
<mark>De acordo com a avaliação de risco de viés de estudos observacionais, realizada por meio da ferramenta NOS</mark><sup>11</sup> <mark>, dois dos quatros estudos avaliados foram classificados como baixa qualidade metodológica (“</mark> _<mark>poor</mark>_ <mark>” - pobre): Shahin (2021)</mark><sup>16</sup> <mark>e Langlois (2016)</mark><sup>15</sup> <mark>. O estudo Langlois (2016)</mark><sup>15</sup> <mark>recebeu apenas três estrelas, uma em cada domínio, e foi classificado como baixa qualidade da evidência. Shahin (2021)</mark><sup>16</sup> <mark>recebeu um total de sete estrelas, mas, por não ter pontuado no domínio comparabilidade, foi classificado como “pobre”. Os estudos Mao (2020)</mark><sup>13</sup> <mark>e Langlois (2020)</mark><sup>14</sup> <mark>receberam um ponto em cada uma das perguntas, com um total de 8 estrelas, sendo classificados como boa qualidade da evidência (</mark> _<mark>good</mark>_ <mark>). Os resultados são apres</mark> entados no **Quadro J** .  
**<mark>Quadro I.</mark>** <mark>Avaliação do risco de viés do estudo clínico randomizado incluído nesta síntese de evidências segundo a ferramenta RoB 2.0 – desfecho melhora clínica (rituximabe vs. Placebo)</mark>  
|**Estudo**|**Viés proveniente do**<br>**processo**<br>**de**<br>**randomização**|**Viés devido a desvios**<br>**da**<br>**intervenção**<br>**pretendida**|**Viés devido a dad**<br>**faltantes**<br>**sobre**<br>**desfecho**|**os**<br>**o**|**Viés na aferição do**<br>**desfecho**|**Viés na**<br>**resultado**<br>**relatado**|**seleção do**<br>**a**<br>**ser**|**Risco de viés geral**|
|---|---|---|---|---|---|---|---|---|
|**Oddis, et al (2013)**|Algumas Preocupações<sup>a</sup>|Algumas preocupações<sup>b</sup>|Baixo||Algumas preocupações<sup>b</sup>|Baixo||**Alto risco**|  
**_Legenda: a._** _Sem detalhes sobre o processo de randomização e/ou sigilo de alocação;_ **_b._** _Sem detalhes sobre o cegamento das partes envolvidas no estudo;_ **_c._** _Há possibilidade de quebra de cegamento de participantes e do avaliador do_  
_desfecho; a avaliação do desfecho pode ser influenciada pelo conhecimento da intervenção recebida_  
47  
**<mark>Quadro J.</mark>** <mark>Avaliação do risco d</mark> e viés de estudos observacionais incluídos nesta síntese de evidências segundo a ferramenta NOS – Rituximabe no tratamento de miopatias inflamatórias.  
|||**SELEÇÃO**|||**COMPARABILIDADE**||**DESFECH**|**O**||
|---|---|---|---|---|---|---|---|---|---|
|**Estudos**|**Representatividade**<br>**do grupo exposto**<br>⋆|**Representatividade**<br>**do grupo não**<br>**exposto**<br>⋆|**Determinação**<br>**da exposição**<br>**ou intervenção**<br>⋆|**Demonstração**<br>**de que o**<br>**desfecho de**<br>**interesse não**<br>**estava presente**<br>**no início do**<br>**estudo**|**Comparabilidade das**<br>**coortes com base no**<br>**desenho do estudo ou**<br>**análise**<br>⋆⋆|**Avaliação**<br>**do desfecho**<br>⋆|**Tempo de**<br>**acompanham**<br>**ento**<br>**necessário**<br>**para a**<br>**ocorrência do**<br>**desfecho**|**Adequação do**<br>**acompanhamento**<br>⋆|**TOTAL**|
|||||⋆|||⋆|||
|**Shahin,**|||||||||**7 estrelas**|
|**2021**|⋆|⋆|⋆|⋆|Não pontua<sup>a</sup>|⋆|⋆|⋆|**Baixa**<br>**qualidade**|
|**Langlois**||||||Não|||**3 estrelas**|
|**, 2016**|Não pontua<sup>b</sup>|Não pontua<sup>b</sup>|⋆|⋆|Não pontua<sup>a</sup>|<br>pontua<sup>c</sup>|⋆|Não pontua<sup>d</sup>|**Baixa**<br>**qualidade**|
|**Mao,**|||||||||**8 estrelas**|
|**2020**|⋆|⋆|⋆|⋆|⋆|⋆|⋆|⋆|**Alta**<br>**qualidade**|
|**Langlois**|||||||||**8 estrelas**|
|**, 2020**|⋆|⋆|⋆|⋆|⋆|⋆|⋆|⋆|**Alta**<br>**qualidade**|  
**a.** Não foram relatados métodos para balanceamento de fatores de confusão; **b.** População não representativa em relação à priorizada na síntese de evidências; **c.** Não apresenta dados de desfecho; **d.** Não apresenta informações sobre perda de acompanhamento.  
**Boa qualidade:** 3 ou 4 estrelas no domínio de seleção **E** 1 ou 2 estrelas no domínio de comparabilidade **E** 2 ou 3 estrelas no domínio de desfecho;  
**Qualidade razoável:** 2 estrelas no domínio de seleção **E** 1 ou 2 estrelas no domínio de comparabilidade **E** 2 ou 3 estrelas no domínio de desfecho; **Baixa qualidade:** 0 ou 1 estrela no domínio de seleção **OU** 0 estrelas no domínio de comparabilidade **OU** 0 ou 1 estrelas no domínio de desfecho.  
48

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Força muscular</u>** -->
Resultados sobre força muscular por meio da escala MMT foram apresentados apenas pelo estudo de Langlois (2020)<sup>14</sup> , que utilizou a versão MMT-8 da ferramenta, avaliando oito grupos musculares em uma escala de 0 a 10 e com escore total variando de 0 a 80 – sendo 0, o pior escore e 80, o melhor escore. Para o relato de melhora da força muscular, foi considerada redução do escore mediano no mês 6 em comparação ao valor basal para os grupos de rituximabe e ciclofosfamida. A análise dos resultados do estudo demonstra um aumento no escore semelhante em ambos os braços de estudo. Ambos os grupos apresentaram um aumento significativo da força muscular em 6 meses em relação aos valores basais. Os resultados de força muscular para o estudo Langlois (2020)<sup>14</sup> são apresentados no **Quadro K** .  
**Quadro K.** Resultados do estudo Langlois, 2020 para avaliação da força muscular por meio do da escala MMT-8  
|**Grupos**|**Basal**<br>**mediana [IQ]**|**6 meses**<br>**mediana [IQ]**|
|---|---|---|
|**Rituximabe**|78 [59–80] (P=0,43)<sup>**a**</sup>|80 [65-80] (P=0,015)<sup>**b**</sup>|
|**Ciclofosfamida**|77 [53–80] (P=0,43)<sup>**a**</sup>|80 [72–80] (P= 0,006)<sup>**b**</sup>|  
**a.** Não há diferença estatística nos valores basais de força muscular entre os grupos rituximabe e ciclofosfamida;  
**b.** Aumento significativo da força muscular em relação ao valor basal.  
**IQ:** intervalo interquartil.  
Apesar de não estar elencado como uma das medidas de desfecho considerada nesta síntese, o estudo Shahin (2020)<sup>16</sup> descreveu resultados de força muscular por meio da escala validada _Medical Research Council Sum Score_ (MRC-SS), que avalia 6 grupos musculares em uma escala de 0 a 5, com escore total de 60 – sendo 60, o melhor escore. Os resultados desse estudo demonstram uma alteração média significativa do escore da escala MRC-SS tanto no grupo tratado do rituximabe (média basal: 29,6 ± 5,1; média após 18 meses: 53,5 ± 9,3; p<0,0001; n=5) quanto no da ciclosfofamida (média basal: 29,6 ± 5,1; média após 18 meses: 53,5 ± 9,3; p<0,0001; n=17).

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Melhora clínica</u>** -->
O desfecho de melhora clínica de acordo com a definição do IMACS foi relatado apenas pelo ECR Oddis (2013)<sup>17</sup> . Para isso, o estudo avaliou o conjunto básico de medidas do IMACS definido pelos exames de: força muscular - MMT; função física - _Health Assessment Questionnaire_ (HAQ) para adultos ou _Childhood Health Assessment Questionnaire_ (CHAQ) para crianças; atividade global da doença avaliada pelo médico - escala visual analógica (EVA); atividade global da doença avaliada pelo paciente - EVA; enzima muscular - concentração sérica de creatina quinase. O resultado de melhora clínica foi relatado como a proporção de pacientes que obteve melhora igual ou superior a 20% em pelo menos 3 testes do conjunto básico de medidas e que não apresentaram piora igual ou superior a 25% em mais do que 2 testes na semana 8 de tratamento. Segundo o estudo, 15% dos pacientes do grupo rituximabe alcançaram o limiar de melhora, enquanto 20,6% dos pacientes do grupo placebo atingiram esse resultado. Não houve diferença estatística entre os grupos.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Capacidade vital forçada</u>** -->
O desfecho de melhora pulmonar medida por meio da capacidade vital forçada foi relatado por dois estudos: Langlois (2020)<sup>14</sup> e Langlois (2016)<sup>15</sup> . Ambos os estudos incluíram pacientes diagnosticados com miopatias inflamatórias associada a doença pulmonar intersticial e permitiram o uso de outros medicamentos em ambos os grupos avaliados. A alteração na taxa de capacidade vital forçada foi relatada por meio de mediana e intervalo interquartil nos dois estudos. A diferença em pontos percentuais entre o valor medido em 2 anos e o valor basal para capacidade vital forçada mostra um aumento da CVF tanto no  
49  
grupo ciclofosfamida quanto no grupo que recebeu o rituximabe nos dois estudos ( **Quadro L** ). Ressalta-se que há a possibilidade de haver sobreposição dos pacientes estudados nos dois estudos descritos.  
**Quadro L.** Resultados dos estudos que avaliaram melhor pulmonar por meio da alteração da capacidade vital forçada em 2 anos  
|**Estudo**|**Grupos**<br>**(número de**<br>**participantes)**|**Basal**<br>**mediana [IQ]**|**2 anos**<br>**mediana**|**Diferença em pontos**<br>**percentuais**|
|---|---|---|---|---|
||**Ciclofosfamida (n=34)**|53% [43–64]|80% (P=0,15)<sup>a</sup>|+27%|
|**_Langlois, 2020_**<sup>**_14_**</sup>|**Rituximabe**<br>**(n=28)**|64% [54–91]|90% (P=0,0008)<sup>b</sup>|+26%|
||**Ciclofosfamida (n=28)**|55% [29-113]|93%|+38% (p=0,02)<sup>b</sup>|
|**_Langlois, 2016_**<sup>**_15_**</sup>|**Rituximabe**<br>**(n=15)**|71% [45-96]|102%|+31% (p=0,002)<sup>b</sup>|  
**a.** Alteração não significativa da capacidade vital forçada em relação ao valor basal;  
**b.** Alteração significativa da capacidade vital forçada em relação ao valor basal.  
**IQ:** intervalo interquartil.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Creatina quinase</u>** -->
O desfecho da alteração da concentração de creatina quinase foi apresentado por dois estudos: Langlois (2020)<sup>14</sup> e Shahin (2021)<sup>16</sup> . Os resultados apresentados por Langlois (2020)<sup>14</sup> demonstram diferença na concentração de creatina quinase no mês 6 em relação ao basal com diminuição em ambos os braços do estudo. Os resultados são apresentados no **Quadro M** .  
**Quadro M.** Resultados do estudo Langlois (2020) para concentração de creatina quinase (IU/L)  
|**Grupos (n)**|**Basal**<br>**Mediana [IQ]**|**6 meses**<br>**Mediana [IQ]**|
|---|---|---|
|**Rituximabe (n=28)**|735 [210–1491]|128 [33–5686] (P = 0,01)|
|**Ciclofosfamida (n=34)**|766 [340–2032]|100 [24 - 1860] (P < 0,0001)|  
**IQ:** intervalo interquartil.  
O estudo conduzido por Shahin (2021)<sup>16</sup> apresenta os resultados de acompanhamento para creatina quinase em três intervalos diferentes: V0 (basal), V1 (após término da ciclofosfamida) e V2 (18 meses). A concentração de creatina quinase diminuiu consideravelmente após 18 meses de acompanhamento no grupo ciclofosfamida. No grupo rituximabe, a concentração sérica da creatina quinase aumentou, sem apresentar diferença estatisticamente significante na comparação com o valor basal. Os resultados para o valor basal e após 18 meses são apresentados no **Quadro N** .  
Langlois (2020)<sup>14</sup> e Shahin (2021)<sup>16</sup> apresentaram tempos de acompanhamento diferentes para o desfecho de interesse (Langlois, 2020 = 6 meses e Shahin, 2021 = 18 meses) e populações com características diversas, impossibilitando a comparação direta entre os resultados apresentados.  
**Quadro N.** Resultados do estudo Shahin (2020) para concentração de creatina quinase (IU/L)  
|**Grupos (n)**|**Basal**Média (DP)|**18 meses**Média (DP)|
|---|---|---|
|**Rituximabe (n=5)**|2.360 (896,1)|2.910,3 (3.761,9)|  
50  
|**Ciclofosfamida (n=17)**|4.788,7 (12.222,4)|105,6 (95,6)|
|---|---|---|  
**DP:** desvio padrão

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Eventos adversos</u>** -->
Langlois 2016<sup>15</sup> relatou que nove de 28 pacientes (32%) apresentaram eventos adversos graves no grupo da ciclofosfamida, principalmente relacionados às complicações infecciosas, em comparação com um de 15 pacientes do grupo do rituximabe (7%), com _p_ =0,07. Langlois 2020<sup>14</sup> relatou os eventos adversos relacionados a infecções e não encontrou diferença estatisticamente significativa entre os dois grupos.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Mortalidade</u>** -->
<mark>O único estudo que avaliou mortalidade publicado por Mao (2020)</mark><sup>13</sup> <mark>. Embora tenha demonstrado uma tendência de redução da mortalidade no grupo que recebeu rituximabe com ou sem ciclofosfamida, em comparação com aqueles que receberam apenas rituximabe ou apenas ciclofosfamida, n</mark> ão foi observada diferença estatística na análise de Kaplan-Meier (P = 0,26).

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Considerações gerais: -->
Os resultados obtidos são pouco conclusivos em relação ao uso do rituximabe nas miopatias inflamatórias.  
Foi encontrado apenas um estudo clínico, que fez a avaliação do rituximabe _versus_ placebo e, nele, foi demonstrado não haver diferença entre os dois grupos de tratamento no que diz respeito à melhora clínica. Esse desfecho foi considerado como tendo certeza geral de evidência _muito baixa._  
Para a avaliação dos desfechos força muscular, capacidade vital forçada, creatina quinase e eventos adversos, foram encontrados estudos observacionais comparando o tratamento com rituximabe e com ciclofosfamida. A força muscular foi avaliada utilizando a escala MMT-8 em apenas um estudo. Com certeza de evidência considerada como baixa, foi demonstrara melhora nos dois grupos de tratamento após 6 meses. Sobre a função pulmonar, dois estudos indicaram melhora na CVF após dois anos de tratamento tanto no grupo que utilizou o rituximabe quanto o que utilizou a ciclofosfamida, com certeza da evidência considerada como muito baixa. Os resultados sobre a concentração de creatina quinase são inconclusivos. Em um estudo, foi relatado redução do nível da enzima em 6 meses nos dois grupos de tratamento e outro estudo apontou a redução do nível da enzima em 18 meses no tratamento com ciclofosfamida e aumento da enzima no tratamento com o rituximabe. Esses resultados são baseados, no entanto, em estudos com alto risco de viés e número pequeno de participantes (certeza da evidência muito baixa).  
Sobre a segurança, os principais eventos adversos sérios descritos nos estudos eram relacionados à recidiva de doença pulmonar intersticial e à taxa de infecções. Não foram encontradas diferenças na incidência de eventos adversos entre os grupos tratados com rituximabe e com a ciclofosfamida e a certeza de evidência foi considera muito baixa, principalmente, pelo tamanho amostral pequeno e alto risco de viés dos estudos.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Perfil de evidências: -->
<mark>Na avaliação da certeza das evidências</mark> usando a ferramenta GRADE<sup>1</sup> foram incluídos os resultados com período de acompanhamento a partir de 8 semanas, 6 meses e 2 anos de tratamento para os desfechos primários. As avaliações estão apresentadas de forma descritiva nos **Quadros O** e **P** e de na forma dicotômica no **Quadro Q** , conforme o comparador. A certeza geral da evidência foi _muito baixa_ para a comparação com placebo para o desfecho de melhora clínica. O mesmo padrão foi observado na avaliação do rituximabe _versus_ ciclofosfamida para os demais desfechos de interesse.  
51  
**Quadro O.** Avaliação da qualidade da evidência na forma narrativa para os desfechos primários comparando rituximabe e ciclofosfamida.  
|||**Avaliação da cert**|**eza das evid**|**ências**|||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|
|**Estudos**|**Risco de**||**Evidência**||**Viés de**|**Certeza geral**|||
|**(participantes)**|**viés**|**Inconsistência**|**indireta**|**Imprecisão**|**publicação**|<br>**de evidência**|**Impacto**|**Importância**|
|<br>**Força muscular (seguime**|**nto: 6 meses**|**; avaliado com: M**|**MT)**||||||
|**1 estudo de coorte**<br>Langlois<br>(2020)<sup>14</sup>:<br>Grupo<br>rituximabe<br>(n=28)<br>Grupo<br>ciclofosfamida<br>(n=34).<br>**Creatina quinase (seguim**|Não grave<br>**ento: 6 mese**|Não grave<br>**s)**|Não<br>grave<sup>a</sup>|Grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Os resultados apresentados por Langlois<br>(2020) indicam alteração da pontuação na<br>escala MMT tanto para o grupo tratado<br>com rituximabe quanto para o grupo<br>tratado com ciclofosfamida|**CRÍTICO**|
|**1 estudo de coorte**<br>Langlois (2020)<sup>14</sup>: Grupo<br>rituximabe (n=28)<br>Grupo<br>ciclofosfamida<br>(n=34).|Não grave|Não grave|Não<br>grave<sup>a</sup>|Grave<sup>b</sup>|Nenhum|⨁⨁◯◯<br>BAIXA|Os resultados apresentados por Langlois<br>(2020) indicam diferença significativa da<br>enzima creatina quinase em relação ao<br>valor basal e após 6 meses para os dois<br>grupos de tratamento|**IMPORTANTE**|
|**Creatina quinase (seguim**|**ento: 18 mes**|**es)**|||||||
|**1 estudo de coorte**|||||||Os resultados apresentados por Shanin||
|Shahin (2020)<sup>16</sup>: Grupo<br>rituximabe (n=5)<br>Grupo<br>ciclofosfamida<br>(n=17).|Grave|Não grave|Não<br>grave<sup>a</sup>|Grave<sup>b</sup>|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|(2020) indicam redução do nível da enzima<br>creatina quinase no grupo ciclofosfamida e<br>aumento no grupo rituximabe após 18<br>meses|**IMPORTANTE**|
|**Capacidade vital forçada**|**(seguimento**|**: 2 anos)**|||||||
|**2 estudos de coorte**<br>Langlois (2016)<sup>15</sup>: Grupo<br>rituximabe (n=15)|Grave<sup>c</sup>|Não grave|Não<br>grave<sup>a</sup>|Grave<sup>b</sup>|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|Os resultados apresentados por Langlois<br>(2016) e Langlois (2020) indicam melhora<br>da CVF para ambos os grupos de|**IMPORTANTE**|  
52  
|||**Avaliação da cert**|**eza das evidê**|**ncias**||||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participantes)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|**Certeza geral**<br>**de evidência**||**Impacto**|**Importância**|
|Grupo<br>ciclofosfamida|||||||tratamento|após<br>2<br>anos<br>de||
|(n=28).|||||||acompanhame|nto em comparação com a||
|Langlois (2020): Grupo|||||||linha de base.|||
|rituximabe (n=28)||||||||||
|Grupo<br>ciclofosfamida||||||||||
|(n=34).||||||||||  
**a.** População incluída difere da população avaliada na síntese; foram utilizadas cointervenções;  
**b.** Tamanho amostral pequeno;  
**c.** São estudos observacionais, um deles apresentou alto risco de viés devido a problemas na seleção dos participantes, comparabilidade e avaliação dos desfechos.  
**Quadro P.** Avaliação da qualidade da evidência para o desfecho melhora clínica comparando rituximabe e placebo.  
||**A**|**valiação da certez**|**a das evidên**|**cias**|||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participantes)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|**Certeza**<br>**geral de**<br>**evidência**|**Impacto**|**Importância**|
|**Melhora clínica (seguim**<br>**1 ECR**|**ento: 8 seman**|**as; avaliado com:**|**DOI)**||||Os resultados de melhora avaliada apresentados||
|Oddis (2013)<sup>17</sup>:|||||||por Oddis (2013) demonstraram melhora de||
|Grupo<br>rituximabe<br>(n=93)<br>Grupo placebo (n=102).|<br>Muito<br>grave<sup>a</sup>|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|⨁◯◯◯<br>MUITO<br>BAIXA|20,6% para o grupo placebo em comparação com<br>15% do grupo rituximabe, não houve diferença<br>estatística entre os grupos. O estudo apresentou<br>alto risco de viés e imprecisão grave devido ao<br>pequeno número de participantes.|**CRÍTICO**|  
**a.** O estudo apresenta alto risco de viés. As características basais dos participantes estão desequilibradas, além disso não há informação suficiente para avaliar o cegamento e os dados **;**  
**b.** Tamanho amostral pequeno.  
53  
**Quadro Q.** Avaliação da qualidade da evidência para os desfechos primários comparando rituximabe e ciclofosfamida.  
||**Ava**|**liação da certe**|**za das evid**|**ências**|||**№ d**|**e pacientes**|**Efeito**||
|---|---|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participantes)**|**Risco**<br>**de viés**<br>|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|<br>**Certeza**<br>**geral de**<br>**evidência**|**Rituximab**|**e**<br>**Ciclofosfamida**<br>**Relativo**<br>**(95%**<br>**CI)**|<br>**Absoluto**<br>**(95% CI)**|**Importância**|
|**Eventos adversos (total)**|||||||||||
|**2 estudos de coorte**|||||||||||
|Langlois (2016)<sup>15</sup>: Grupo<br>rituximabe (n=15); Grupo<br>ciclofosfamida (n=28).<br>Langlois (2020)<sup>14</sup>: Grupo<br>rituximabe (n=28); Grupo|Grave<sup>a</sup>|Grave<sup>b</sup>|Não<br>Grave<sup>c</sup>|Grave<sup>**d**</sup>|Nenhum|⨁◯◯◯<br>Muito baixa|13/43<br>(30.2%)|27/62<br>(43.5%)<br>**RR**<br>**0.55**<br>(0.15<br>para<br>2.02)|**196 menos por**<br>**1.000**<br>(de 370 menos<br>para 444 mais)|**IMPORTANTE**|
|ciclofosfamida (n=34).|||||||||||
|**Mortalidade**|||||||||||
|Mao (2020)<sup>13</sup>|Não<br>Grave<sup>a</sup>|Grave<sup>b</sup>|Não<br>grave<sup>e</sup>|Grave<sup>d</sup>|Nenhum|⨁◯◯◯<br>Muito baixa|44|70<br>**HR**<br>**(p=0,26)**|**-**|**IMPORTANTE**|  
**a.** São estudos observacionais, um deles apresentou alto risco de viés devido a problemas na seleção dos participantes, comparabilidade e avaliação dos desfechos;  
**b.** Apesar de haver sobreposição dos intervalos de confiança, o I<sup>2</sup> é igual a 50% e o intervalo de confiança passa pela linha de nulidade;  
**c.** População incluída difere da população avaliada na síntese; foram utilizadas co-intervenções;  
**d.** Tamanho amostral pequeno; e. Estudos diferem entre si em relação à população e dose do comparador, foram utilizadas co-intervenções.  
54

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **QUESTÃO 2: O MICOFENOLATO É SEGURO E EFICAZ PARA O TRATAMENTO DE PACIENTES COM MIOPATIAS INFLAMATÓRIAS EM COMPARAÇÃO À OUTRAS TECNOLOGIAS DISPONÍVEIS NO SUS OU AO PLACEBO?** -->
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com miopatias inflamatórias  
**Intervenção:** Micofenolato de mofetil  
**Comparador:** Medicamentos preconizados no PCDT (azatioprina, metotrexato, ciclosporina, ciclofosfamida, imunoglobulina humana) ou placebo  
**Desfechos:** Força muscular medida pelo Manual Muscular Test (MMT) ou pelo Disease activity score – Muscle (DASM); melhora clínica de acordo com definição do International Myositis Assessment & Clinical Studies Group (IMACS) ou Childhood Myositis Activity Score (CMAS); melhora cutânea medida pela escala Cutaneous Dermatomyositis Disease Area and Severity Index (CDASI) ou pelo Disease activity score – Skin (DAS-S); incidência de eventos adversos ao medicamento; melhora pulmonar por alterações na capacidade vital forçada (CVF) e dispneia.  
**Tipo de estudo:** Estudo clínico randomizado (ECR) ou estudo observacional com e sem comparadores.  
Métodos e resultados da busca  
Com base na pergunta PICO definida, foi realizada uma busca nas bases de dados: MEDLINE (via Pubmed); EMBASE e Cochrane Library. Não foram utilizadas restrições de data, idioma ou status da publicação (resumo ou texto completo). Todas as buscas foram conduzidas em 04 de agosto de 2022. O **Quadro R** detalha as estratégias de busca utilizadas para identificar as evidências para essa síntese, bem como o número de publicações encontradas em cada uma das bases.  
**Quadro R.** Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o uso do micofenolato  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|**MEDLINE**<br>**(via Pubmed)**|("Myositis"[Mesh] OR (Myositides) OR (Myopathy, Inflammatory) OR (Muscle<br>Diseases, Inflammatory) OR (Inflammatory Muscle Diseases) OR (Inflammatory<br>Muscle Disease) OR (Muscle Disease, Inflammatory) OR (Inflammatory Myopathy)<br>OR (Inflammatory Myopathies) OR (Myopathies, Inflammatory) OR (Myositis,<br>Proliferative) OR (Myositides, Proliferative) OR (Proliferative Myositides) OR<br>(Proliferative Myositis) OR (Myositis, Infectious) OR (Infectious Myositides) OR<br>(Myositides, Infectious) OR (Infectious Myositis) OR (Idiopathic Inflammatory<br>Myopathies) OR (Myopathy, Idiopathic Inflammatory) OR (Inflammatory Myopathy,<br>Idiopathic) OR (Idiopathic Inflammatory Myopathy) OR (Idiopathic Inflammatory<br>Myositis) OR (Inflammatory Myopathies, Idiopathic) OR (Myopathies, Idiopathic<br>Inflammatory) OR (Myositis, Focal) OR (Focal Myositides) OR (Focal Myositis) OR<br>(Myositides, Focal) OR "Polymyositis"[Mesh] OR (Polymyositides) OR (Myositis,<br>Multiple) OR (Multiple Myositis) OR (Myositides, Multiple) OR (Polymyositis,<br>Idiopathic) OR (Idiopathic Polymyositides) OR (Idiopathic Polymyositis) OR|240|  
55  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||(Polymyositides, Idiopathic) OR (Polymyositis Ossificans) OR (Ossificans,<br>Polymyositis) OR "Dermatomyositis"[Mesh] OR (Dermatopolymyositis) OR<br>(Polymyositis-Dermatomyositis)<br>OR<br>(Polymyositis<br>Dermatomyositis)<br>OR<br>(Dermatomyositis,<br>Adult<br>Type)<br>OR<br>(Adult<br>Type<br>Dermatomyositis)<br>OR<br>(Dermatomyositis, Childhood Type) OR (Childhood Type Dermatomyositis) OR<br>(Juvenile Dermatomyositis) OR (Dermatomyositis, Juvenile) OR (Juvenile Myositis)<br>OR (Myositis, Juvenile)) AND ("Mycophenolic Acid"[Mesh] OR (Mycophenolate<br>Mofetil) OR (Mofetil, Mycophenolate) OR (Mycophenolic Acid Morpholinoethyl<br>Ester) OR (Cellcept) OR (Mycophenolate Sodium) OR (Sodium Mycophenolate) OR<br>(Mycophenolate, Sodium) OR (Myfortic) OR (Mycophenolate Mofetil Hydrochloride)<br>OR (Mofetil Hydrochloride, Mycophenolate) OR (RS 61443) OR (RS-61443) OR<br>(RS61443))||
|**EMBASE**|('myositis'/exp OR (allergic AND myositis) OR (idiopathic AND inflammatory AND<br>myopathy) OR (inflammatory AND myopathy) OR (muscle AND infection) OR<br>(muscle AND inflammation) OR (myopathy, AND inflammatory) OR (myositis, AND<br>allergic) OR neuromyositis) AND 'mycophenolate mofetil'/exp AND [embase]/lim<br>NOT ([embase]/lim AND [medline]/lim)|932|
|**Cochrane**<br>**Library**|#1 MeSH descriptor: [Myositis] explode all trees<br>#2 Infectious Myositides OR Myositis, Infectious OR Infectious Myositis OR<br>Myositides, Infectious OR Inflammatory Myopathies OR Muscle Diseases,<br>Inflammatory OR Muscle Disease, Inflammatory OR Myopathy, Inflammatory OR<br>Myopathies, Inflammatory OR Inflammatory Myopathy OR Myositides OR<br>Inflammatory Muscle Diseases Inflammatory Muscle Disease OR Proliferative<br>Myositides OR Proliferative Myositis OR Myositides, Proliferative OR Myositis,<br>Proliferative OR Inflammatory Myopathy, Idiopathic OR Inflammatory Myopathies,<br>Idiopathic OR Idiopathic Inflammatory Myopathy OR Myopathies, Idiopathic<br>Inflammatory OR Myopathy, Idiopathic Inflammatory OR Idiopathic Inflammatory<br>Myopathies OR Idiopathic Inflammatory Myositis OR Myositides, Focal OR Focal<br>Myositides OR Focal Myositis OR Myositis, Focal<br>#3 MeSH descriptor: [Dermatomyositis] explode all trees<br>#4 Myositides, Multiple OR Multiple Myositis OR Polymyositides OR Myositis,<br>Multiple OR Polymyositides, Idiopathic OR Idiopathic Polymyositis OR Polymyositis,<br>Idiopathic OR Idiopathic Polymyositides OR Polymyositis Ossificans OR Ossificans,<br>Polymyositis<br>#5 MeSH descriptor: [Polymyositis] explode all trees|4|  
56  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#6 Polymyositis-Dermatomyositis OR Dermatopolymyositis OR Polymyositis<br>Dermatomyositis OR Childhood Type Dermatomyositis OR Juvenile Myositis OR<br>Myositis, Juvenile OR Dermatomyositis, Childhood Type OR Dermatomyositis,<br>Juvenile OR Juvenile Dermatomyositis OR Dermatomyositis, Adult Type OR Adult<br>Type Dermatomyositis<br>#7 MeSH descriptor: [Mycophenolic Acid] explode all trees<br>#8 #1 OR #2 OR #3 OR #4 OR #5 OR #6<br>#9 #8 AND #7||
|**Total**||**1.176**|  
A elegibilidade dos estudos foi realizada em duas etapas por dois revisores independentes. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI®<sup>10</sup> . Na segunda etapa, realizou-se a leitura de texto completo, também por dois revisores independentes, mantendo-se ECR e estudos observacionais que avaliassem o medicamento para a indicação analisada. As divergências foram resolvidas por meio de consenso entre os revisores ou com o auxílio de um terceiro pesquisador.  
_<u>Foram considerados como critérios de elegibilidade:</u>_  
- **(a)** Tipos de participantes:  
Pacientes com qualquer miopatia inflamatória, refratários ou não a outras terapias.  
- **(b)** Tipo de intervenção:  
Micofenolato de mofetila em qualquer dose de tratamento  
- **(c)** Tipos de estudos:  
ECR controlado por placebos ou comparando o micofelonato com um dos medicamentos preconizados no PCDT, estudos observacionais que comparam o micofenolato com um dos medicamentos preconizados no PCDT e estudos de observacionais do tipo antes e depois;  
- **(d)** Desfechos:  
Primários – força muscular (MMT), melhora clínica (DOI IMACS), melhora cutânea (CDASI), dispneia; Secundários – CPK, CVF  
- **(e)** Idioma:  
Inglês, espanhol ou português  
Não foram aplicados quaisquer recortes para casos refratários ou para terapias prévias ao tratamento. Relatos e série de casos foram excluídos. Da mesma forma, estudos que utilizaram outras tecnologias diferentes daquelas preconizadas no PCDT como comparador também foram excluídos.  
Para análise de dados, foram realizadas meta-análises quando os estudos primários forneceram resultados suficientes que permitissem o agrupamento. Quando necessário, foi realizada conversão de medidas para possibilitar a associação de dados. Independentemente da sua natureza, os dados foram agrupados por meio de um modelo de efeitos aleatórios com intervalo de confiança (IC) de 95%. A análise foi realizada utilizando o pacote estatístico _RevMan_ versão 5.4.1 – _Cochrane Collaboration_ . Quando não foi possível agrupar os resultados ou realizar meta-análises, os resultados dos estudos primários foram relatados por  
57  
meio de uma descrição narrativa do desfecho. Foi realizada avaliação do risco de viés utilizando a ferramenta NOS<sup>11</sup> para estudos observacionais e o instrumento validado da Colaboração _Cochrane_ (RoB 2.0)<sup>12</sup> para ECR. Para a avaliação do grau de certeza do conjunto final das evidências foi aplicado o método GRADE<sup>1</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Resultados da busca -->
Por meio das estratégias de buscas definidas ( **Quadro R** ) foram identificadas 1.176 publicações. Após o processo de exclusão das duplicatas (n=28) e de elegibilidade por título e resumo, 31 referências foram selecionadas para a avaliação por texto completo. Foram identificados seis estudos observacionais que atendiam integralmente aos critérios de inclusão<sup>18-23</sup> . A **Figura C** resume os resultados do processo de elegibilidade.  
**Figura C.** Fluxograma com resultados da busca e seleção dos estudos incluídos sobre o uso do Micofenolato no tratamento de miopatias inflamatórias  
<!-- Start of picture text -->
ReferénciasBases deidentificadasdados (n = 3)em Referéncias- removidas antes do<br>PubMed (n = 240) processo de selecao<br>Embase (n = 932) Duplicatas (n =28)<br>Cochrane CENTRAL (n = 4)<br>Registros (n =1176)<br>Referéncias avaliadas por titulo Reteréncias excluidas<br>e(n resumo=1.148) (nent)fe<br>Referéncias incluidas para Referéncias cujo texto completo<br>avaliagéo por texto completo J++] 140 foi identificado<br>(n =31) (n =0)<br>Referéncias avaliadas por texto .<br>comple(n=31) I———>] Referencias“ Delineam e ntoxclui d oas:estudo25 (n =3)<br>Nao relatou desfecho de interesse (n =11)<br>Nao separa medicamentos (n =2)<br>Nao 6 possivel identificar populagao de<br>interesse (n=5)<br>Estudo repetido (n=2)<br>Comparador (n=1)<br>Idioma (n =1)<br>Estudos incluldos na reviséo<br>(n =6)<br>Relatos dos estudos incluldos<br>(n =)<br><!-- End of picture text -->  
**Fonte:** Autoria própria com base na publicação de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prismastatement.org/<sup>4</sup> .  
Foram excluídos estudos que apresentavam resultados agrupados por intervenção ou população com outras condições de saúde relacionadas que não fossem miopatias inflamatórias (n=5), sem os desfechos de interesse (n=13), com delineamento não elegível (n=3), outro idioma (n=1), utilização de outros comparadores (n=1) e resultados duplicados em publicações diferentes (n=2) ( **Quadro S** ) **.**  
58  
**Quadro S.** Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão - Micofenolato no tratamento de miopatias inflamatórias  
**_Delineamento do estudo – carta ao editor_**  
1.López de la Osa A, Sanher Tapia C, Arias García M, Terrancle de Juan I. Síndrome antisintetasa con buena respuesta a micofenolato mofetilo. Rev Clínica Española. 2007. 2.Martínez-García EA, Lujano-Benítez A V., García-De La Torre I, Vázquez-Del Mercado M. Good response to mycophenolate mofetil on treatment of interstitial lung disease in polymyositis associated with antisynthetase syndrome positive for anti-EJ and anti-Ro52 antibodies. Clin Rheumatol. 2020.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_Delineamento do estudo – relato de caso_** -->
3.Tsuchiya H, Tsuno H, Inoue M, Takahashi Y, Yamashita H, Kaneko H, et al. Mycophenolate mofetil therapy for rapidly progressive interstitial lung disease in a patient with clinically amyopathic dermatomyositis. Mod Rheumatol. 2014.  
**_Idioma_** 4. Danieli MG, Spalletta C, Moretti R, Calabrese V, Marchetti A, Gabrielli A, Logullo F. La terapia immunosoppressiva nelle miositi refrattarie. Nostra esperienza [Immunosuppressant treatment in refractory myositis. Our experience]. Recenti Prog Med. 2009.  
**_Sem relato de desfechos de interesse_**  
5.El-Garf K, El-Garf A, Salah S, Marzouk H, Farag Y, Mostafa N. A juvenile dermatomyositis: demographics, characteristics and disease outcome in an Egyptian cohort. Clin Exp Rheumatol. 2022.  
6.Edge JC, Outland JD, Dempsey JR, Callen JP. Mycophenolate Mofetil as an Effective Corticosteroid-Sparing Therapy for Recalcitrant Dermatomyositis. Arch Dermatol. 2006.  
- 7.Lin J, Femia A, Patel M, Merola J, Vleugels R A. Systemic treatment for clinically amyopathic dermatomyositis. Arthritis and Rheumatology. 2014. 8. Pallo P A O, Miossi R,De Souza F H C, Shinjo S K. Safety and efficacy of mycophenolate mofetil in idiopathic inflammatory myopathies: A cross-sectional study. Journal of Clinical Rheumatology. 2018. 9. Solimando AG, Crudele L, Leone P, Argentiero A, Guarascio M, Silvestris N, et al. Immune Checkpoint Inhibitor-Related Myositis: From Biology to Bedside. Int J Mol Sci. 2020.  
10.Rathore U, Mehta P, Chatterji R, Agarwal V, Gupta L.  Prevalent drug-usage practices and retention-rates in adults and children with idiopathic inflammatory myopathies-registry-based analysis from the myocite cohort. International Journal of Rheumatic Diseases. 2020.  
11.  Anjani G, Vignesh P, Sudhakar M, Johnson N, Chaudhary H, Jindal A, Suri D. Rawat A, Gupta A, Singh, S. Clinical profile of juvenile dermatomyositis in children with disease onset â‰¤3 years of age is different compared to those who had disease onset >3 years of age: A 28 years’ experience from a tertiary care centre in Northern India. Pediatric Rheumatology. 2021.  
12.  Kaleda M, Nikishina I, Arsenyeva, S. Single center retrospective study of the juvenile idiopathic inflammatory myopathies. Pediatric Rheumatology. 2021.  
- 13.Martins P, Dourado E, Melo AT, Samões B, Sousa M, Freitas R, et al. POS0870 CLINICAL CHARACTERIZATION OF PORTUGUESE PATIENTS WITH ANTISYNTHETASE SYNDROME. Ann Rheum Dis. 2021.  
- 14.Mehta P, Rathore U, Naveen R, Chatterjee R, Agarwal V, Aggarwal R, et al. Prevalent Drug Usage Practices in Adults and Children With Idiopathic Inflammatory Myopathies. JCR J Clin Rheumatol. 2022.  
**_Não relata os desfechos por medicamentos_**  
59  
15.Varnier GC, Consolaro A, Maillard S, Pilkington C, Ravelli A. Comparison of treatments and outcomes of children with juvenile dermatomyositis followed at two European tertiary care referral centers. Rheumatology. 2021.  
16.Johnson NE, Arnold WD, Hebert D, Gwathmey K, Dimachkie MM, Barohn RJ, et al. Disease course and therapeutic approach in dermatomyositis: A four-center retrospective study of 100 patients. Neuromuscul Disord. 2015.  
17.Patwardhan A, Rennebohm R, Dvorchik I, Spencer CH. Is juvenile dermatomyositis a different disease in children up to three years of age at onset than in children above three years at onset? A retrospective review of 23 years of a single center’s experience. Pediatr Rheumatol. 2012.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_População – não é possível identificar a população de interesse_** -->
18. Zhu L, Li S, Gagne L, Jacobs S, Morisset J, Mooney J, Raj R, Chung, L. Rituximab versus mycophenolate mofetil in interstitial lung disease secondary to connective tissue disease. 2018.  
19. Ramzy J A, Townsend R, Codella S, Kim J, Karanam A, Gupta R, Zhao H, Criner G J, Narewski E A. Effect of cotreatment with corticosteroids in connective tissue related lung disease (CTD-ILD) patients on mycophenolate mofetil (MMF). American Journal of Respiratory and Critical Care Medicine. 2019.  
20.Wilfong (11) Wilfong E M, Schroeder G, Barnado A, Annapureddy N, Crofford L J, Dudenhofer R B. Myositis and systemic sclerosis spectrum IPAF patients are more likely to respond favorably to immunosuppression. American Journal of Respiratory and Critical Care Medicine. 2020.  
21.Balina (7) Balina H, Dsouza K, Lara P A, Luckhardt T, Kulkarni T, Gulati S. Natural History of interstitial lung disease  
(ILD) and response to treatment regimens in patients with idiopatic inflammatory myopathies (IIM): a single center experience. Chest. 2020.  
22. Tang K, Zhang H, Jin H. Clinical Characteristics and Management of Patients With Clinical Amyopathic Dermatomyositis: A Retrospective Study of 64 Patients at a Tertiary Dermatology Department. Front Med. 2021.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_Resumo de congresso de publicação incluída – sem acréscimo de informação_** -->
23. Grinnell M, Keyes E, Diaz D, Vazquez T, Feng R, Werth V. 445 Mycophenolate mofetil and methotrexate in dermatomyositis treatment. J Invest Dermatol. 2021.  
24. Wolstencroft (16) Wolstencroft P, Chung L, Li S, Casciola-Rosen L, Fiorentino, D. Factors associated with clinical remission of skin disease in dermatomyositis. Arthritis and Rheumatology. 2017.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_Comparação com rituximabe_** -->
25. Li Y, Baig H, Rojas C, Stowell J, Lesser E, Borkar S, Abril A, Mira-Avendano I. Prospective Analysis of a Cohort of Patients with Interstitial Lung Disease Associated with Connective Tissue Disease and Their Response to Immunosuppression with Mycophenolate Mofetil and Rituximab. Arthritis and Rheumatology. 2020.  
Análise e apresentação dos resultados  
Resumo das evidências:  
Após uma busca abrangente da literatura científica, foram identificadas seis publicações com resultados de seis estudos observacionais que atendiam integralmente aos critérios de inclusão desta síntese de evidências<sup>18-23</sup> . O delineamento dos seis estudos incluídos foi do tipo de coorte, sendo os estudos de Wolstencroft, 2017<sup>19</sup> e Varnier, 2020<sup>23</sup> coortes prospectivas e os demais foram coortes retrospectivas.  
Referente à população, quatro dos estudos incluíram pacientes adultos com dermatomiosite<sup>21</sup> , doença pulmonar intersticial<sup>18</sup> , dermatomiosite e dermatomiosite amiopática<sup>19</sup> e doença pulmonar intersticial de polimiosite/dermatomiosite resistente a esteroides<sup>20</sup> . Os outros dois estudos incluíram população pediátrica e adolescentes com dermatomiosite e miopatias  
60  
inflamatórias idiopáticas juvenis (JIIM)<sup>22,23</sup> . Todos os estudos envolvendo a população adulta utilizaram outros medicamentos como comparadores, incluindo metotrexato, azatioprina, ciclofosfamida e imunoglobulina e avaliaram melhora cutânea, função pulmonar e a incidência de eventos adversos. Para a população pediátrica, foram avaliadas a melhora da força muscular e melhora cutânea e nenhum dos dois estudos utilizou outros medicamentos como comparadores. Não foram avaliadas a força muscular nos estudos que envolviam adultos e não foram avaliadas a função pulmonar e eventos adversos nos que envolviam a população pediátrica. As descrições mais detalhadas das características por estudo estão no **Quadro T** , incluindo os desfechos avaliados em cada um.  
**Quadro T.** Características dos estudos que avaliaram o micofenolato no tratamento de miopatias inflamatórias.  
|**Autor ano**|**Poulaão**|**Idade**|**Tempo de**|**Mic**|**ofenolato**||**Controle**<br>**Medicamento**|**Desfechos**|
|---|---|---|---|---|---|---|---|---|
|**,**<br>**Adultos**<br>|**pç**|**(anos)**<br>|**seguimento**<br>|**N**|**Dose**<br>|**N**|<br>**dose**<br>|**avaliados**|
|**Grinnell,**<br>**2021**<sup>**21**</sup>|Dermatomiosite|Média:<br>62|Média: 26<br>meses|13|Não<br>relata|11|Metotrexato;<br>Não relata|CDASI-A|
|**Huapaya,**<br>**2019**<sup>**18**</sup>|Doença pulmonar<br>intersticial<br>relacionado com<br>dermatomiosite/<br>polimiosite|Média:<br>52,5<br>(DP:<br>11,6)|24 meses|44|Não<br>relata|66|Azatioprina; não<br>relata|CVF (%)<br>Eventos<br>adversos|
|||||||29|Metotrexato,<br>Não relata||
|**Wolstencroft,**<br>**2017**<sup>**19**</sup>|Dermatomiosite e<br>dermatomiosite<br>amiopática|Média:<br>59<br>(DP:12|Mediana (IQ):<br>17,5 (11-28,3)|27|3/g|28<br>18|Antimaláricos,<br>Não relata<br>Imunoglobulina,<br>Não relata|CDASI-A|
|||)||||8|Outros<br>medicamentos<br>orais não<br>sistêmicos||
|**Mira-**|Doença pulmonar<br>intersticial de|||||24|Ciclofosfamida;<br>129 mg||
|**Avendano,**<br>**2013**<sup>**20**</sup><br>**Crianças e adol**<br>**Rouster-**<br>**Stevens,**<br>**2010**<sup>**22**</sup>|polimiosite/<br>dermatomiosite<br>resistente a<br>esteroides<br>**escentes**<br>Dermatomiosite<br>juvenil|Média:<br>56 anos<br>Média:<br>12,6<br>(mínim<br>o: 4,2 -|36 meses<br>12 meses|9<br>50|129<br>mg/dia<br>20<br>mg/kg|13<br>N<br>A|Azatioprina;<br>130mg<br>Não avalia|CVF (%)<br>DAS-M<br>DAS-S|  
61  
|**Autor, ano**|**População**|**Idade**<br>**(anos)**|**Tempo de**<br>**seguimento**|**Mic**<br>**N**|**ofenolato**<br>**Dose**|**N**|**Controle**<br>**Medicamento**<br>**dose**|**Desfechos**<br>**avaliados**|
|---|---|---|---|---|---|---|---|---|
|||máxim<br>o: 23,2)|||||||
||Miopatias|Criança||||||MMT8|
|**Varnier,**<br>**2020**<sup>**23**</sup>|inflamatórias<br>idiopáticas juvenis|s / não<br>relata|12 meses|29|Não<br>relata|N<br>A|Não avalia|DAS-M<br>DAS-S|
||(JIIM)|idade||||||CMAS|  
**Legenda:** CDASI-A- Cutaneous Dermatomyositis Disease Area and Severity – activity; MMT - Manual Muscle Testing; DAS-M- Disease Activity Score-  
Muscle; EAV- Escala analógica visual; DAS-S- Disease Activity Score-Skin; CMAS- Childhood Myositis Activity Score; CVF- Capacidade vital forçada; MMRC- Escala modificada de Dispneia Medical Research Council.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Avaliação do risco de viés</u>** -->
Na avaliação do risco de viés dos estudos observacionais, realizada com a utilização de ferramenta validada NOS<sup>11</sup> , três estudos receberam 6 estrelas e foram considerados como tendo qualidade razoável<sup>18-20</sup> . Os outros três foram avaliados como de baixa qualidade, principalmente por não controlarem fatores confundidores no estudo, não descreverem a derivação da coorte e não permitirem a avaliação de perdas durante o seguimento<sup>21-23</sup> ( **Quadro U** ).  
62  
**Quadro U.** Avaliação do risco de viés de estudos observacionais incluídos nesta síntese de evidências segundo a ferramenta NewCastle-Ottawa Scale (NOS)  
|||**SELEÇÃO**|||**COMPARABILIDADE**||**DESFECHO**|||
|---|---|---|---|---|---|---|---|---|---|
|**Estudos**|**Representatividade**<br>**do grupo exposto**<br>⋆|**Representatividade**<br>**do grupo não**<br>**exposto**<br>⋆|**Determinação**<br>**da exposição**<br>**ou**<br>**intervenção**<br>⋆|**Demonstração**<br>**de que o**<br>**desfecho de**<br>**interesse não**<br>**estava**<br>**presente no**<br>**início do**<br>**estudo**<br>⋆|**Comparabilidade das**<br>**coortes com base no**<br>**desenho do estudo ou**<br>**análise**<br>⋆⋆|**Avaliação**<br>**do**<br>**desfecho**<br>⋆|**Tempo de**<br>**acompanhamento**<br>**necessário para a**<br>**ocorrência do**<br>**desfecho**<br>⋆|**Adequação do**<br>**acompanhamento**<br>⋆|**TOTAL**|
|**Grinnell,**<br>**2021**<sup>**21**</sup>|⋆|⋆|⋆|⋆|Não pontua<sup>a</sup>|Não<br>pontua<sup>c</sup>|⋆|Não pontua<sup>d</sup>|**5 estrelas**<br>**Baixa**<br>**qualidade**|
|**Varnier,**|||||||||**4 estrelas**|
|**2020**<sup>**23**</sup>|Não pontua<sup>b</sup>|Não pontua<sup>b</sup>|⋆|⋆|Não pontua<sup>a</sup>|⋆|⋆|Não pontua<sup>d</sup>|**Baixa**<br>**qualidade**|
|**Huapaya,**|||||||||<br>**6 estrelas**|
|**2019**<sup>**18**</sup>|Não pontua<sup>b</sup>|⋆|⋆|⋆|⋆|⋆|⋆|Não pontua<sup>d</sup>|**Qualidade**<br>**razoável**|
|**Wolstencroft,**|||||||||**6 estrelas**|
|**2017**<sup>**19**</sup>|Não pontua<sup>b</sup>|Não pontua<sup>b</sup>|⋆|⋆|⋆|⋆|⋆|⋆|**Qualidade**<br>**razoável**|
|**Rouster-**|||||||||**5 estrelas**|
|**Stevens,**<br>**2010**<sup>**22**</sup>|Não pontua<sup>b</sup>|Não pontua<sup>b</sup>|⋆|⋆|⋆|⋆|⋆|Não pontua<sup>d</sup>|**Baixa**<br>**qualidade**|  
63  
|||**SELEÇÃO**|||**COMPARABILIDADE**||**DESFECHO**|||
|---|---|---|---|---|---|---|---|---|---|
|**Estudos**|**Representatividade**<br>**do grupo exposto**<br>⋆|**Representatividade**<br>**do grupo não**<br>**exposto**<br>⋆|**Determinação**<br>**da exposição**<br>**ou**<br>**intervenção**<br>⋆|**Demonstração**<br>**de que o**<br>**desfecho de**<br>**interesse não**<br>**estava**<br>**presente no**<br>**início do**<br>**estudo**|**Comparabilidade das**<br>**coortes com base no**<br>**desenho do estudo ou**<br>**análise**<br>⋆⋆|**Avaliação**<br>**do**<br>**desfecho**<br>⋆|**Tempo de**<br>**acompanhamento**<br>**necessário para a**<br>**ocorrência do**<br>**desfecho**<br>⋆|**Adequação do**<br>**acompanhamento**<br>⋆|**TOTAL**|
|||||⋆||||||
|**Mira-**|||||||||**6 estrelas**|
|**Avendano,**|⋆|⋆|⋆|⋆|Não pontua<sup>a</sup>|⋆|⋆|Não pontua<sup>d</sup>|**Baixa**|
|**2013**<sup>**20**</sup>|||||||||**qualidade**|  
**a.** Não foram relatados métodos para balanceamento de fatores de confusão;  
- **b.** População não representativa em relação à priorizada na síntese de evidências;  
- **c.** Não apresenta dados de desfecho;  
**d.** Não apresenta informações sobre perda de acompanhamento.  
**Classificação:**  
**Boa qualidade:** 3 ou 4 estrelas no domínio de seleção **E** 1 ou 2 estrelas no domínio de comparabilidade **E** 2 ou 3 estrelas no domínio de desfecho. **Qualidade razoável:** 2 estrelas no domínio de seleção **E** 1 ou 2 estrelas no domínio de comparabilidade **E** 2 ou 3 estrelas no domínio de desfecho. **Baixa qualidade:** 0 ou 1 estrela no domínio de seleção **OU** 0 estrelas no domínio de comparabilidade **OU** 0 ou 1 estrelas no domínio de desfecho.  
64

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Avaliação cutânea</u>** -->
O desfecho de melhora clínica cutânea utilizando a escala CDASI-A foi avaliado por dois estudos<sup>19,21</sup> . A meta-análise dos dados não foi realizada, visto que os estudos apresentaram diferentes tempos de seguimento e consideraram a melhora clínica de forma distinta. Os resultados por estudo foram descritos no **Quadro V.**  
Grinnel _et al._ , 2021 avaliou como melhora clínica os pacientes que apresentavam melhora de 40% ou mais na pontuação do CDASI-A<sup>21</sup> . Para o grupo do micofenolato, 54% e 77% dos pacientes eram respondentes na avaliação em seis e 26 meses, respectivamente. Para o grupo do metotrexato, 27% e 55% foram respondentes nos mesmos períodos. Wolstencroft et al., 2017 encontrou uma proporção de 50% com remissão clínica, considerando como resposta CDASI-A menor ou igual a 5<sup>19</sup> . Os autores fizeram uma avaliação de fatores associados à remissão clínica e encontraram que o tratamento com micofenolato foi associado de forma significativa para alcançar a remissão clínica ( **Quadro V** ).  
**Quadro V.** Resultados dos estudos incluídos que avaliaram desfechos sobre melhora cutânea - adultos  
|**Autor, data**<br>|**Tempo de**<br>**seguimento**<br>**CDASI-A (****_Cutan_**<br>|**Comparadores**<br>**_eous Dermatomyositis_**<br>|**Desfecho avaliado**<br>**_Disease Area and Severi_**<br>|**Resultados**<br>**_ty – activity_) **<br>|
|---|---|---|---|---|
|**Grinnell et al.,**<br>**2021**<sup>**21**</sup>|Acompanhamento<br>médio:<br>1ª avaliação:<br>até 6 meses<br>2ª avaliação: 26<br>meses|Metotrexato|Proporção de<br>respondentes:<br>Melhora cutânea de<br>40% ou mais na<br>pontuação CDASI-<br>A|**Até 6 meses:**<br>MMF: 54%<br>MTX: 27%<br>**26 meses:**<br>MMF: 77%<br>MTX: 55%|
|**Wolstencroft et**<br>**al., 2017**<sup>**19**</sup>|17,5 (11-28,3)<br>meses<br>(mediana e<br>intervalo<br>interquartil)|Antimaláricos<br>Metotrexato<br>Imunoglobulina<br>Sem medicamento|Remissão clínica<br>(CDASI-A menor<br>ou igual a 5)|**Remissão clínica em 3 anos:**<br>MMF: 50%<br>Antimaláricos: 46%<br>Metotrexato: 36%<br>Imunoglobulina: 29%<br>Sem medicamento: 4%<br>OR 2,54 (IC 95% 0,95-6,76;<br>p=0.06)<sup>a</sup>|  
**Notas:** MTX – metotrexato; MMF – micofenolato de mofetila; NA – não aplicável; RR _–_ risco relativo calculado pelo NATS-Unifesp Diadema (NUD); **a.** valor de OR retirado da publicação – avalia a associação entre usar o micofenolato e remissão clínica.  
Para a população pediátrica, o desfecho de melhora clínica cutânea foi avaliado utilizando a escala DAS-S em dois estudos<sup>22,23</sup> . Também não foi possível realizar a meta-análise dos dados, pois os estudos consideraram a melhora clínica de formas distintas. O estudo de Rouster-Stevens et al. (2010)<sup>22</sup> avaliou como melhora clínica a redução média no escore DAS-S e demonstrou melhora dos pacientes após 6 e 12 meses. Varnier et al. (2020)<sup>23</sup> avaliaram a proporção de pacientes com DAS-S igual a zero e encontrou que, na avaliação inicial, 31% dos pacientes possuíam DAS-S=0 e, após 12 meses, a proporção aumento para 42,1%, sem diferença estatisticamente significante na avaliação antes e depois ( **Quadro X** ).  
65  
**Quadro X.** Resultados dos estudos incluídos que avaliaram desfechos sobre melhora cutânea – crianças e adolescentes  
|**Autor, data**|**Tempo de**<br>**seguimento**<br>|**Comparadores**<br>**DAS-S (****_Disease_**<br>|**Desfecho avaliado**<br>**_activity score – Skin_)**<br>|**Resultados**<br>|
|---|---|---|---|---|
|**Rouster-**|6 a 12 meses|NA|Redução média de|A redução média de DAS-S foi de|
|**Stevens et**<br>**al., 2010**<sup>**22**</sup>|||DAS-S|5,24 ± 0,29 para 4,20 ± 0,28 aos 6<br>meses (p=0,003) e 3,72 ± 0,29 aos 12<br>meses após o início do MMF, (p=<br>0,001)<br>Diferença da média (IC95%):<br>1,52 (1,41; 1,63)|
|**Varnier et**<br>**al., 2020**<sup>**23**</sup>|12 meses|NA|Proporção de<br>pacientes com DAS-<br>S=0|DAS-S=0<br>Basal: 31%<br>Após 12 meses: 42,1%<br>RR<sup>a</sup>(IC95%): 1,33 (0,67, 2,67)|  
**Legenda:** MMF – micofenolato de mofetila; NA – não aplicável; RR<sup>a</sup> – risco relativo calculado pelo NATS-Unifesp Diadema (NUD).

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Avaliação da força muscular</u>** -->
Os desfechos para a avaliação da força muscular foram encontrados apenas nos estudos que avaliaram a população de crianças e/ou adolescentes<sup>22,23</sup> . Três instrumentos diferentes foram utilizados nos dois estudos, o MMT, o DAS-M e o CMAS. Nenhum estudo apresentou medicamento comparador, apenas comparação do tipo antes e depois.  
O estudo de Varnier et al. (2020)<sup>23</sup> foi o único que avaliou a força muscular por meio da escala MMT. Os autores utilizaram a versão MMT-8 da ferramenta, a qual avalia oito grupos musculares em uma escala de 0 a 10 e com escore total variando de 0 a 80 – sendo 0 o pior escore e 80, o melhor escore. Para esse desfecho, o estudo mostrou aumento da proporção de pacientes com MMT-8=80 de 50% para 83,3% após 12 meses de tratamento com micofenolato.  
Os estudos de Rouster-Stevens et al. (2010)<sup>22</sup> e de Varnier et al. (2020)<sup>23</sup> utilizaram a escala DAS-M para avaliar a melhora na força muscular. Esta escala avalia a extensão e distribuição da fraqueza muscular, dando uma pontuação de 0 a 20. Para esse desfecho foi considerada redução do escore mediano em comparação com o valor basal dos participantes. Ambos os estudos não definiram um limiar de corte para indicar a melhora na fraqueza muscular. Para o estudo de Rouster-Stevens et al. (2010)<sup>22</sup> , houve redução estatisticamente significativa do escore após 6 e 12 meses de acompanhamento e para o estudo de Varnier et al. (2020)<sup>23</sup> , houve melhora da força muscular de 55,2% para 84,2% pacientes. Os autores, no entanto, não deixam claro o critério utilizado para avaliar a proporção de pacientes com melhora da força muscular ( **Quadro Y** ).  
Por fim, no estudo de Varnier et al. (2020)<sup>23</sup> ainda foi utilizada uma terceira escala para avaliar a força muscular. A escala CMAS é utilizada para avaliar a função física em crianças com doença idiopática juvenil e apresenta uma pontuação calculada pela avaliação de cada uma das 14 manobras descritas na ferramenta, onde a pontuação total máxima possível é 52 (“pontos de força/função muscular”). O estudo mostrou aumento da proporção de pacientes com CMAS=52 de 53,5% para 88,9% após 12 meses de acompanhamento ( **Quadro Y** ).  
66  
**Quadro Y.** Resultados dos estudos incluídos que avaliaram desfechos sobre força muscular – crianças e adolescentes  
|**Coortes**|**Pacientes**|**Tempo de**<br>**seguimento**|**Comparadores**|**Desfecho**<br>**avaliado**|**Resultados**|
|---|---|---|---|---|---|
|||<br>**MMT -****_Manua_**|**_l Muscle Testing_**|||
|**Varnier et**|Miopatias|12 meses|NA|Proporção de|MMT 8 = 80|
|**al., 2020**<sup>**23**</sup>|inflamatórias<br>idiopáticas juvenis -<br>dermatomiosite juvenil<br>e miosite de<br>sobreposição (n=29)|(avaliações em 3, 6,<br>12 meses e no<br>último<br>acompanhamento<br>clínico)<br>**DAS-M (****_Disease act_**|**_ivity score – Muscle_) **|pacientes que<br>atingiram MMT<br>8 = 80<br>|Basal: 50%<br>Após 12 meses:<br>83%<br>RR (IC95%): 1,71<br>(1,14; 2,59)|
|**Rouster-**<br>**Stevens et**<br>**al., 2010**<sup>**22**</sup>|Dermatomiosite<br>juvenil (n=50)|6 a 12 meses|NA|Disease<br>Activity Score-<br>Muscle (DAS-<br>M) = media ±<br>DP|DAS-M reduziu de<br>2,44 ± 0,39 para<br>1,17 ± 0,28<br>(p=0,002) após 6<br>meses de terapia e<br>1,5 ± 0,28 aos 12<br>meses após o início<br>do MMF (p= 0,96)|
|**Varnier et**<br>**al., 2020**<sup>**23**</sup>|Miopatias<br>inflamatórias<br>idiopáticas juvenis,<br>dermatomiosite juvenil<br>e miosite de<br>sobreposição (n=29)|12 meses<br>**CMAS -****_(Childhood M_**|NA<br>**_yositis Activity Scor_**|Proporção de<br>pacientes que<br>atingiram<br>Disease<br>Activity Score-<br>Muscle (DAS-<br>M) = SC*<br>**_e)_**|_Disease Activity_<br>_Score-Muscle_<br>Basal: 55,2%<br>Após 12 meses:<br>84,2%|
|**Varnier et**<br>**al., 2020**<sup>**23**</sup>|Miopatias<br>inflamatórias<br>idiopáticas juvenis,<br>dermatomiosite juvenil<br>e miosite de<br>sobreposição (n=29)|12 meses|NA|Proporção de<br>pacientes que<br>atingiram<br>_Childhood_<br>_Myositis_<br>_Activity Score_<br>(CMAS)=52|_Childhood Myositis_<br>_Activity Score_= 52:<br>Basal: 53,5%<br>Após 12 meses:<br>88,9%|  
**Legenda:** DP- desvio padrão; NA – não aplicável; SC* - critério de avaliação do desfecho não foi citado pelo autor

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Avaliação da função pulmonar</u>** -->
A avaliação da função pulmonar foi feita considerando dois desfechos: CVF e dispneia. A CVF foi avaliada em dois estudos: Mira-Avendano (2013)<sup>20</sup> e Huapaya (2019)<sup>18</sup> . Ambos incluíram pacientes adultos diagnosticados com miopatias  
67  
inflamatórias associada a doença pulmonar intersticial e permitiram o uso de outros medicamentos nos grupos avaliados. No primeiro estudo<sup>20</sup> , houve apenas pequenas melhorias na CVF, sem nenhum resultado estatisticamente significativo na comparação entre grupos que utilizaram outros tratamentos ( **Quadro Z** ). No segundo estudo<sup>18</sup> , é possível observar aumento do CVF para os dois grupos de tratamento, mas a interpretação da comparação entre os dois grupos é prejudicada pelo valor basal do CVF ser superior no grupo do micofenolato em comparação ao da azatioprina e por, ao longo do tempo, o estudo ter perda considerável dos pacientes.  
O desfecho da dispneia foi relatado apenas em Mira-Avendano (2013)<sup>20</sup> e foi descrito com o número de pacientes que apresentaram mudanças em seus graus de dispneia ao longo dos acompanhamentos. A proporção de pacientes com dispneia Grau 3 e Grau 4 do grupo do micofenolato diminui na avaliação em 6 e 12 meses, mas sem diferença estatisticamente significante entre os grupos ( **Quadro Z** ).  
Os estudos que avaliaram a população de crianças e adolescentes não consideraram desfechos relacionados com a função pulmonar.  
68  
**Quadro Z.** Resultados dos estudos incluídos que avaliaram desfechos sobre função pulmonar- adultos  
|**Coortes**|**Pacientes**|**Tempo de**<br>**seguimento**|**Comparadores**<br>**Desfecho**<br>**avaliado**|**Resultados**|
|---|---|---|---|---|
||||**CVF (%)**<br> <br>||
|**Mira-Avendano et**<br>**al., 2013**<sup>**20**</sup>|Doença pulmonar<br>intersticial-<br>polimiosite ou<br>dermatomiosite<br>resistente a esteroides<br>(n=46)|6 e 12 meses|Ciclofosfamida,<br>Azatioprina<br>CVF (%)|**CVF (%) – mediana (IQ) basal:**<br>Ciclofosfamida: 58% (48%,78%)<br>Azatioprina: 63% (47%,78%),<br>Micofenolato 64% (55%,78%)<br>p=0,76<br>**CVF(%) – mediana (IQ) após 6 meses:**<br>Ciclofosfamida: 66% (55%,87%)<br>Azatioprina: 59% (53%,80%)<br>Micofenolato: 67% (57%,90%)<br>p=0,61<br>**CVF(%) - mediana (IQ) após 12 meses:**<br>Ciclofosfamida: 67% (51%,79%)<br>Azatioprina 61% (52%,85%)<br>Micofenolato 64% (52%,81%)<br>p=0,92|
|**Huapaya et al.,**<br>**2019**<sup>**18**</sup>|Doença pulmonar<br>intersticial-<br>autoanticorpos<br>específicos da miosite<br>e autoanticorpos<br>associados à miosite<br>(n=110)|60 meses|Azatioprina<br>Mudança na CVF<br>(%)|**CVF (%) – média (SD) basal:**<br>Azatioprina: 58,4% (19,1); n=57<br>Micofenolato: 72% (22,2);n=35<br>p=0,003<br>**CVF (%) – média (SD) após 6 meses:**<br>Azatioprina: 64,5% (17); n=37<br>Micofenolato: 74,3% (25,1); n=24<br>**CVF (%) – média (SD) após 12 meses:**|  
69  
|**Coortes**|**Pacientes**|**Tempo de**<br>**seguimento**|**Comparadores**|**Desfecho**<br>**avaliado**|**Resultados**|
|---|---|---|---|---|---|
||||||Azatioprina: 63,3% (21,1); n=34<br>Micofenolato: 71,2% (26); n=22<br>**CVF (%) – média (SD) após 24 meses:**<br>Azatioprina: 65,5% (16,3); n=24<br>Micofenolato: 77,9% (23,4); n=16<br>**CVF (%) – média (SD) após 36 meses:**<br>Azatioprina: 61,4% (15,5); n=19<br>Micofenolato: 80,6% (22,6); n=13<br>**CVF (%) – média (SD) após 48 meses:**<br>Azatioprina: 58,7% (15,2); n=15<br>Micofenolato: 82,5% (28,5); n=11<br>**CVF (%) – média (SD) após 60 meses:**<br>Azatioprina: 58,2% (16,2); n=9<br>Micofenolato: 78,8% (20,3); n=5|
|**Dispneia**||||||
|**Mira-Avendano et**<br>**al., 2013**<sup>**20**</sup>|Doença pulmonar<br>intersticial-<br>polimiosite ou<br>dermatomiosite<br>resistente a esteroides<br>(n=46)|6 e 12 meses|Ciclofosfamida,<br>Azatioprina|Escala modificada<br>de_Dispneia_<br>_Medical Research_<br>_Council_(MMRC)<br>Número de<br>pacientes que<br>obtiveram|**Dispneia Basal - N pacientes (%):**<br>Grau 2: ciclofosfamida 2 (8%); Azatioprina 2 (15%), micofenolato<br>0 (0%);<br>Grau 3: ciclofosfamida 11 (46%), Azatioprina 3 (23%),<br>micofenolato 7 (78%);<br>Grau 4: ciclofosfamida 11 (46%), Azatioprina 8 (61%),<br>micofenolato 2 (22%) p=0,32|
|||||melhora|**Dispneia após 6 meses:**|  
70  
|**Coortes**|**Pacientes**|**Tempo de**<br>**seguimento**|**Comparadores**|**Desfecho**<br>**avaliado**|**Resultados**|
|---|---|---|---|---|---|
|||||(diminuição no<br>grau de dispneia).|Grau 2: ciclofosfamida 13 (59%), Azatioprina 8 (72%),<br>micofenolato 8 (88%);<br>Grau 3: ciclofosfamida 8 (36%), Azatioprina 3 (27%), micofenolato<br>1 (11%);<br>Grau 4: ciclofosfamida 1 (5%), Azatioprina 0, micofenolato 0<br>p=0,49|
||||||**Dispneia 12 meses:**<br>Grau 2: ciclofosfamida 11 (57%), Azatioprina 5 (40%),<br>micofenolato 4 (80%);<br>Grau 3: ciclofosfamida 6 (31%), Azatioprina 6 (60%), micofenolato<br>1 (20%);<br>Grau 4: ciclofosfamida 2 (11%), Azatioprina 0, micofenolato 0<br>p=0,62|  
71

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **<u>Eventos adversos</u>** -->
A avaliação de eventos adversos em adultos foi feita por dois estudos: Mira-Avendano et al. (2013)<sup>20</sup> e Huapaya et al. (2019)<sup>18</sup> . Não houve diferença entre os grupos micofenolato e azatioprina. Os principais eventos adversos descritos no estudo de Huapaya et al. (2019)<sup>18</sup> foram transaminite, náusea e leucopenia para os dois grupos de tratamento.  
Apenas um estudo avaliou a frequência de eventos adversos na população de crianças. Rouster-Stevens et al. (2010)<sup>22</sup> descreveram que, em geral, não houve eventos adversos graves atribuídos ao micofenolato e apenas duas crianças relataram algum desconforto abdominal que foi resolvido quando a dose do medicamento foi reduzida. Dos 50 pacientes, 41 (82%) sofreram 132 infecções durante o período do estudo. A incidência de infecções foi maior antes do início do tratamento e não houve diferença significativa entre o pré-tratamento e os primeiros 6 meses após o início da terapia como micofenolato (p=0,44). Quando comparado com 12 meses de tratamento, a taxa de infecção foi significativamente menor do que nos dados prétratamento ( _p_ =0,001). Por fim, nenhuma das crianças avaliadas desenvolveu leucopenia ou anormalidades de células B, conforme medido por citometria de fluxo (dados não mostrados pelo autor).

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Considerações gerais: -->
Os resultados obtidos após a síntese de evidências são pouco conclusivos em relação ao uso do micofenolato nas miopatias inflamatórias.  
Na população adulta, não foram encontrados estudos que avaliassem desfechos sobre força muscular. Na avaliação cutânea utilizando a escala CDASI-A, dois estudos relataram melhora de pacientes adultos tanto com o uso do micofenolato quanto com outros medicamentos (metotrexato, antimaláricos e imunoglobulina). Os dados obtidos para esse desfecho avaliam uma população de participantes heterogênea, incluindo participantes com características clínicas, faixa etária e gravidade da doença bem diferentes, além de considerarem tempo de acompanhamento bastante distinto. O grau de certeza para o desfecho de avaliação cutânea foi considerado _muito baixo_ .  
A função pulmonar foi avaliada em dois estudos que incluíram a população adulta. Ambos demonstraram melhora na CVF e na dispneia tanto daqueles pacientes que fizeram uso do micofenolato, quanto os que fizeram o uso de outros medicamentos. A certeza da evidência foi considerada como _baixa_ , principalmente, pela avaliação envolver estudos com alto risco de viés.  
Na população de crianças e adolescentes, o tratamento com o micofenolato demonstrou melhora na força muscular e na avaliação cutânea. No entanto, os resultados são baseados em estudos pequenos, com alto risco de viés e sem grupo comparador. Para todos os desfechos relacionados à força muscular e melhora cutânea na população de crianças/adolescentes, a certeza da evidência foi considerada como sendo _muito baixa_ .  
Sobre a segurança do uso do micofenolato, não houve diferença da incidência de eventos adversos em comparação com o uso da azatioprina. Essa informação, no entanto, é baseada em dois estudos que avaliaram apenas a população de adultos e a certeza de evidência foi considerada _muito baixa_ . Não foram encontrados estudos que avaliassem a incidência de eventos adversos do tratamento com micofenolato na população de crianças e adolescentes.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Perfil de evidências: -->
<mark>Na avaliação da certeza das evidências</mark> usando a ferramenta GRADE<sup>1</sup> foram incluídos os resultados para todos os desfechos considerados nesta síntese. A avaliação dos resultados foi feita de forma distinta para a população de adultos e para a população de crianças/adolescentes. Para o desfecho referente à melhora cutânea na população adulta, avaliada com a escala CDASI-A, a certeza da evidência foi considera muito baixa, principalmente por se basear em estudos com alto risco de viés e com um número baixo de participantes. Assim como, a melhora cutânea na população crianças/adolescentes, avaliada com a escala DAS-S, também, foi considerada como tendo baixa certeza de evidência. A força muscular só foi avaliada em estudos que  
72  
envolviam crianças e adolescentes e, em todos eles, a certeza da evidência foi considerada como sendo muito baixa. Em relação à função pulmonar, avaliada apenas na população de adultos, a certeza de evidência foi considerada moderada. O desfecho de eventos adversos foi avaliado apenas para a comparação do uso do micofenolato e azatioprina e na população adulta, com certeza de evidência considerada, também, muito baixa.  
<mark>O</mark> **<mark>Quadro AA</mark>** <mark>traz detalhes da avaliação descritiva feita para os desfechos relacionados a avaliação cutânea, força muscular e função pulmonar e</mark> **<mark>o Quadro AB</mark>** <mark>descreve a avaliação feita para os eventos adversos.</mark>  
73  
**Quadro AA.** Avaliação da qualidade da evidência na forma narrativa para todos os desfechos.  
|**Avaliação da cert**<br>**Estudos**<br>**(participantes)**<br>**Força muscular –**<br>**1**<br>**estudo**<br>**de**<br>**coorte**<br>Varnier (2020)<sup>23</sup>:<br>(n=29)<br>sem<br>comparador<br>**Força muscular –**<br>**2**<br>**estudos**<br>**de**<br>**coorte**<br>Varnier (2020)<sup>23</sup>:<br>(n=29)<br>sem<br>comparador<br>Rouster-Stevens<br>(2010)<sup>22</sup>:<br>(n=50)<br>sem<br>comparador<br>**Força muscular – po**|**eza das evidências**<br>**Risco de viés**<br>**Inconsistência**<br>**população crianças/adolescentes**<br>Grave<sup>a</sup><br>Não grave<br>**população crianças/adolescentes**<br>Grave<sup>a</sup><br>Não grave<br>**pulação crianças/adolescentes (s**|**Evidência**<br>**indireta**<br>**(seguiment**<br>Não grave<br>**(seguiment**<br>Não<br>grave<br>**eguimento:**|**Imprecisão**<br>**o: 12 meses; a**<br>Grave<sup>b</sup><br>**o: 12 meses; a**<br>Grave<sup>b</sup><br>**12 meses; aval**|**Viés**<br>**de**<br>**publicação**<br>**valiado com:**<br>Altamente<br>suspeito<sup>c</sup><br>**valiado com:**<br>Altamente<br>suspeito<sup>c</sup><br>**iado com:****_Chi_**|**Certeza**<br>**geral**<br>**de**<br>**evidência**<br>**MMT8)**<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>**DAS-M)**<br>⨁◯◯◯<br>MUITO<br>BAIXA<br>**_ldhood Myos_**|**Sumário de Resultados**<br>**Impacto**<br>Os resultados apresentados por Vanier (2020) indicam<br>aumento da proporção de pacientes com MMT8=80 de<br>50% para 83,3%.<br>RR (IC95%): 1,71 (1,14; 2,59)<br>Os resultados apresentados por Rouster-Stevens (2010)<br>indicam diferença significativa na escala DAS-M em<br>relação ao valor basal após 6 e 12 meses (_p_<0,05). Os<br>resultados apresentados por Vanier (2020) indicam<br>aumento da proporção de pacientes com melhora para<br>o grupo tratado com micofenolato: de 55,2% para<br>84,2%, porém não deixam claro o valor da escala<br>utilizado como critério de melhora<br>**_itis Activity Score_) **|**Importância**<br>**CRÍTICO**<br>**CRÍTICO**|
|---|---|---|---|---|---|---|---|  
|**1**<br>**estudo**<br>**coorte**|**de**|Grave<sup>a</sup>|Não grave|Não grave|Grave<sup>b</sup>|Altamente<br>suspeito<sup>c</sup>|⨁◯◯◯<br>MUITO<br>BAIXA|Os resultados apresentados por Vanier (2020) indicam<br>melhora na pontuação na escala Childhood Myositis|**CRÍTICO**|
|---|---|---|---|---|---|---|---|---|---|  
74  
|**Avaliação da certe**<br>**Estudos**<br>**(participantes)**|**za das evidênci**<br>**Risco de viés**|**as**<br>**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés**<br>**de**<br>**publicação**|**Certeza**<br>**geral**<br>**de**<br>**evidência**|**Sumário de Resultados**<br>**Impacto**|**Importância**|
|---|---|---|---|---|---|---|---|---|
|Varnier (2020)<sup>23</sup>:<br>(n=29)<br>sem<br>comparador<br>**Melhora cutânea –**<br>**2**<br>**estudos**<br>**de**<br>**coorte**|**população adu**|**lta (seguimento:**|**muito varia**|**do e não defin**|**ido; avaliado**|**com: CDASI**|Activity Score (CMAS=52) para o grupo tratado com<br>micofenolato: 53,5% para 88,9%.<br>**-A)**||
|Grinnell (2021)<sup>21</sup>:<br>Grupo<br>micofenolato<br>(n=13)<br>Grupo<br>metotrexato<br>(n=11).<br>Wolstencroft<br>(2017)<sup>19</sup>:<br>Micofenolato<br>(n=27)<br>Metotrexato<br>(n=29)<br>Antimaláricos<br>(n=28)|Grave<sup>d</sup>|Não grave|Não<br>grave|Grave<sup>b</sup>|Altamente<br>suspeito<sup>c</sup>|⨁◯◯◯<br>MUITO<br>BAIXA|Os resultados apresentados por Grinnell (2021) indicam<br>melhora de mais de 50% na escala CDASI-A para<br>ambos os grupos após a segunda avaliação em<br>comparação com a linha de base. Em Wolstencroft<br>(2017), o tratamento com micofenolato foi associado de<br>forma significativa, para alcançar a remissão clínica, na<br>análise multivariável: OR 6.00 (IC 95% 1,66-21,78;<br>p=0,01). Na avaliação entre grupos, não foram<br>encontradas diferenças.|**CRÍTICO**|  
75  
|**Avaliação da cert**<br>**Estudos**<br>**(participantes)**|**eza das evidênc**<br>**Risco de viés**|**ias**<br>**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés**<br>**de**<br>**publicação**|**Certeza**<br>**geral**<br>**de**<br>**evidência**|**Sumário de Resultados**<br>**Impacto**|**Importância**|
|---|---|---|---|---|---|---|---|---|
|Imunoglobulina<br>(n=18)<br>Sem<br>medicamento<br>sistêmico (n=8)|||||||||
|**Melhora cutânea**|**- – população c**|**rianças/adolescen**|**tes (seguim**|**ento: 12 meses**|**; avaliado com**|**: DAS-S)**|||
|**2**<br>**estudos**<br>**de**<br>**coorte**<br>Varnier (2020)<sup>23</sup>:|||||||Os resultados apresentados por Rouster-Stevens (2010)<br>indicam diferença significativa na escala DAS-S em|<br>|
|(n=29)<br>sem<br>comparador|Grave<sup>a</sup>|Não grave|Não<br>grave|Grave<sup>b</sup>|Altamente<br>suspeito<sup>c</sup>|⨁◯◯◯<br>MUITO<br>BAIXA|relação ao valor basal após 6 meses (_p_=0,003) e<br>também após 12 meses (_p_=0,001). Os resultados<br>apresentados por Vanier (2020) indicam aumento da|<br> <br> <br>**CRÍTICO**|
|Rouster-Stevens<br>(2010)<sup>22</sup>:<br>(n=50)<br>sem<br>comparador<br>**Função pulmonar**<br>**2**<br>**estudos**<br>**de**<br>**coorte**<br>Mira-Avendano<br>(2013)<sup>20</sup>:|**– população a**<br>Grave<sup>a</sup>|**dulta (seguimento**<br>Não grave|**: 12 a 24 me**<br>Não<br>grave|**ses; avaliado c**<br>Grave<sup>b</sup>|**om: CVF%)**<br>Nenhum|⨁⨁ ◯ ◯<br>BAIXA|proporção de pacientes com DAS-S=0 para o grupo<br>tratado com micofenolato de 31% para 42.1%<br>Os resultados apresentados por Mira-Avendano (2013)<br>e Huapaya (2019) indicam pequena melhora da CVF<br>para ambos os grupos, em seus respectivos tempos de<br>acompanhamento, em comparação com a linha de base.|<br> <br> <br> <br> <br>**IMPORTANTE**|  
76  
|**Avaliação da certe**|**za das evidênci**|**as**|||||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participantes)**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés**<br>**de**<br>**publicação**|**Certeza**<br>**geral**<br>**de**<br>**evidência**|**Impacto**|**Importância**|
|Grupo<br>micofenolato<br>(n=9)<br>Grupo<br>ciclofosfamida<br>(n=24).<br>Grupo azatioprina<br>(n=13).|||||||||
|Huapaya<br>(2019)<sup>18</sup>:<br>Grupo<br>micofenolato<br>(n=44)|||||||||
|Grupo azatioprina<br>(n=66)|||||||||
|**Função pulmonar**|**– população ad**|**ulta (seguimento**|**: 12 meses; a**|**valiado com:**|**dispneia)**||||
|**1**<br>**estudo**<br>**de**<br>**coorte**<br>Mira-Avendano<br>(2013)<sup>20</sup>:|Grave<sup>a</sup>|Não grave|Não<br>grave|Grave<sup>b</sup>|Nenhum|⨁⨁ ◯ ◯<br>BAIXA|Os resultados apresentados por Mira-Avendano (2013)<br>indicam pequena melhora da dispneia para ambos os<br>grupos, após 12 de acompanhamento, em comparação<br>com a linha de base. Nenhum resultado foi<br>estatisticamente significativo na comparação entre<br>grupos|**IMPORTANTE**|  
77  
|**Avaliação da certe**|**za das evidênci**|**as**|||||**Sumário de Resultados**||
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participantes)**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés**<br>**de**<br>**publicação**|**Certeza**<br>**geral**<br>**de**<br>**evidência**|**Impacto**|**Importância**|
|Grupo<br>micofenolato|||||||||
|(n=9)|||||||||
|Grupo|||||||||
|ciclofosfamida<br>(n=24).|||||||||
|Grupo azatioprina<br>(n=13).|||||||||  
**a.** Estudo observacional, que apresenta alto risco de viés devido a problemas na seleção dos participantes, comparabilidade e adequação do acompanhamento **;**  
**b.** Tamanho amostral pequeno;  
**c.** resultados relatados em resumo de congresso;  
**d.** São estudos observacionais, um deles apresentou alto risco de viés devido a problemas na, comparabilidade e avaliação dos desfechos e adequação do acompanhamento;  
78  
**Quadro AB.** Avaliação da qualidade da evidência para o desfecho de eventos adversos  
|**Avaliação da certe**|**za das evid**|**ências**|||||**№ de pacientes**||**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(participantes)**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés**<br>**de**<br>**publicação**|<br> <br>**Certeza**<br>**geral**<br>**de**<br>**evidência**|<br>**Micofenolato**|**Azatioprina**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Importância**|  
**Eventos adversos (total) – população crianças/adolescentes (Tempo de seguimento: de 12 a 24 meses)**  
|**2 estudos de coorte**||||||||||
|---|---|---|---|---|---|---|---|---|---|
|Mira-Avendano<br>(2013)<sup>20</sup>:||||||||||
|Grupo micofenolato||||||||||
|(n=9)<br>Grupo<br>azatioprina<br>(n=13)<br>Não<br>grave|Grave<sup>a</sup>|Não grave|Grave<sup>b</sup>|Nenhum|⨁◯◯◯<br>Muito<br>Baixa<br>10/53 (30.2%)|25/79<br>(43.5%)|**RR**<br>**0,83**<br>(0,18 para<br>3,81)|**54 menos por**<br>**1.000**<br>(de 259 menos<br>para 889 mais)|<br> <br>**IMPORTANTE**|
|Huapaya<br>(2019)<sup>18</sup>:||||||||||
|Grupo micofenolato||||||||||
|(n=44)||||||||||
|Grupo<br>azatioprina||||||||||
|(n=66).||||||||||  
- **a.** I<sup>2</sup> > 60%, a heterogeneidade pode ser explicada pelo tempo de seguimento distinto e pela população distinta entre os estudos, principalmente relacionada a resistência a esteroides.  
- **b.** Tamanho amostral pequeno e intervalos de confiança ao redor do efeito estimado são substancialmente largos  
79

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **QUESTÃO 3: QUAL A CHANCE DE PACIENTES COM MIOPATIAS INFLAMATÓRIAS IDIOPÁTICAS ANTI-JO1 POSITIVOS APRESENTAREM PIORES DESFECHOS E PIOR PROGNÓSTICO EM RELAÇÃO ÀQUELES PACIENTES ANTI-JO1 NEGATIVOS?** -->
Para avaliar a importância do anti-Jo1 na definição do prognóstico do paciente com miopatia inflamatória, foi desenvolvida a seguinte estrutura PECO para a pergunta de pesquisa:  
**População:** Pacientes com diagnóstico de miopatias inflamatórias  
**Exposição:** Pacientes com miopatias inflamatórias anti-Jo1 positivo  
**Comparador:** Pacientes com miopatias inflamatórias anti-Jo1 negativo  
**Desfechos:** (i) primários: taxa de remissão clínica, taxa de resposta clínica, mortalidade, proporção de pacientes com comprometimento das articulações, artrite, doença pulmonar intersticial (DPI) e fraqueza muscular; (ii) secundários: proporção de pacientes com mão de mecânico, comprometimento pulmonar, fenômeno de Raynaud, vasculite e síndrome antissintetase  
**Delineamento de estudo:** Ensaios clínicos randomizados e não randomizados e estudos observacionais (coorte, caso controle, transversal)

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Métodos e resultado da busca** -->
Foram realizadas buscas sistematizadas da literatura nas bases de dados MEDLINE (via Pubmed), Embase, Cochrane Library e BVS nos dias 15 e 18 de agosto de 2022. Também foi realizada busca manual. Como estratégia de busca, foram aplicados descritores específicos para o anti-Jo1 e não anticorpos de uma forma abrangente. Não foram feitas restrições quanto ao idioma, período, tipo de estudo ou status de publicação (resumo ou texto completo). O **Quadro AC** detalha as estratégias de busca utilizadas para identificar as evidências.  
**Quadro AC.** Estratégia de busca para cada base de dados e os respectivos resultados;  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|**MEDLINE**<br>**(via**|("Myositis"[Mesh] OR (Myositides) OR (Myopathy, Inflammatory) OR (Muscle|338|
|**Pubmed)**|Diseases, Inflammatory) OR (Inflammatory Muscle Diseases) OR (Inflammatory||
|**Data da busca:**<br>**18/08/22**|Muscle Disease) OR (Muscle Disease, Inflammatory) OR (Inflammatory Myopathy)<br>OR (Inflammatory Myopathies) OR (Myopathies, Inflammatory) OR (Myositis,<br>Proliferative) OR (Myositides, Proliferative) OR (Proliferative Myositides) OR<br>(Proliferative Myositis) OR (Myositis, Infectious) OR (Infectious Myositides) OR<br>(Myositides, Infectious) OR (Infectious Myositis) OR (Idiopathic Inflammatory<br>Myopathies) OR (Myopathy, Idiopathic Inflammatory) OR (Inflammatory Myopathy,<br>Idiopathic) OR (Idiopathic Inflammatory Myopathy) OR (Idiopathic Inflammatory<br>Myositis) OR (Inflammatory Myopathies, Idiopathic) OR (Myopathies, Idiopathic<br>Inflammatory) OR (Myositis, Focal) OR (Focal Myositides) OR (Focal Myositis) OR<br>(Myositides, Focal) OR "Polymyositis"[Mesh] OR (Polymyositides) OR (Myositis,<br>Multiple) OR (Multiple Myositis) OR (Myositides, Multiple) OR (Polymyositis,<br>Idiopathic) OR (Idiopathic Polymyositides) OR (Idiopathic Polymyositis) OR<br>(Polymyositides, Idiopathic) OR (Polymyositis Ossificans) OR (Ossificans,<br>Polymyositis) OR "Dermatomyositis"[Mesh] OR (Dermatopolymyositis) OR||  
80  
|**Bases de dados**|**Estratégia de busca**<br>(Polymyositis-Dermatomyositis)<br>OR<br>(Polymyositis<br>Dermatomyositis)<br>OR<br>(Dermatomyositis,<br>Adult<br>Type)<br>OR<br>(Adult<br>Type<br>Dermatomyositis)<br>OR<br>(Dermatomyositis, Childhood Type) OR (Childhood Type Dermatomyositis) OR<br>(Juvenile Dermatomyositis) OR (Dermatomyositis, Juvenile) OR (Juvenile Myositis)<br>OR (Myositis, Juvenile)) AND ("Jo-1 antibody" [Supplementary Concept] OR (Anti-<br>Jo-1 autoantibody) OR (Anti-Jo-1 antibody) OR (antinuclear antibody Jo 1))|**Resultados**|
|---|---|---|
|**Cochrane**<br>**Library**<br>**Data da Busca:**<br>**15/08/2022**|#1 MeSH descriptor: [Myositis] explode all trees<br>#2 Infectious Myositides OR Myositis, Infectious OR Infectious Myositis OR<br>Myositides, Infectious OR Inflammatory Myopathies OR Muscle Diseases,<br>Inflammatory OR Muscle Disease, Inflammatory OR Myopathy, Inflammatory OR<br>Myopathies, Inflammatory OR Inflammatory Myopathy OR Myositides OR<br>Inflammatory Muscle Diseases Inflammatory Muscle Disease OR Proliferative<br>Myositides OR Proliferative Myositis OR Myositides, Proliferative OR Myositis,<br>Proliferative OR Inflammatory Myopathy, Idiopathic OR Inflammatory Myopathies,<br>Idiopathic OR Idiopathic Inflammatory Myopathy OR Myopathies, Idiopathic<br>Inflammatory OR Myopathy, Idiopathic Inflammatory OR Idiopathic Inflammatory<br>Myopathies OR Idiopathic Inflammatory Myositis OR Myositides, Focal OR Focal<br>Myositides OR Focal Myositis OR Myositis, Focal<br>#3 MeSH descriptor: [Dermatomyositis] explode all trees<br>#4 Myositides, Multiple OR Multiple Myositis OR Polymyositides OR Myositis,<br>Multiple OR Polymyositides, Idiopathic OR Idiopathic Polymyositis OR Polymyositis,<br>Idiopathic OR Idiopathic Polymyositides OR Polymyositis Ossificans OR Ossificans,<br>Polymyositis<br>#5 MeSH descriptor: [Polymyositis] explode all trees<br>#6 Polymyositis-Dermatomyositis OR Dermatopolymyositis OR Polymyositis<br>Dermatomyositis OR Childhood Type Dermatomyositis OR Juvenile Myositis OR<br>Myositis, Juvenile OR Dermatomyositis, Childhood Type OR Dermatomyositis,<br>Juvenile OR Juvenile Dermatomyositis OR Dermatomyositis, Adult Type OR Adult<br>Type Dermatomyositis<br>#7 Histidyl T RNA Synthetase OR Synthetase, Histidyl-tRNA OR Jo 1 Antigen OR<br>Histidyl-tRNA Synthetase OR Antigen, Jo-1 OR His-tRNA Ligase OR Histidine tRNA<br>Ligase OR Ligase, His-tRNA OR His tRNA Ligase OR Histidyl tRNA Synthetase OR<br>Ligase, Histidine-tRNA OR Jo-1 Antigen<br>#8 #1 OR #2 OR #3 OR #4 OR #5 #6<br>#9 #8 AND #7|11|
|**EMBASE**<br>**Data da busca:**<br>**15/08/2022**|'myositis'/exp OR (allergic AND myositis) OR (idiopathic AND inflammatory AND<br>myopathy) OR (inflammatory AND myopathy) OR (muscle AND infection) OR<br>(muscle AND inflammation) OR (myopathy, AND inflammatory) OR (myositis, AND|937|  
81  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
||allergic) OR (neuromyositis) OR 'dermatomyositis'/exp OR (dermatomucomyositis)||
||OR (dermatomyositides)<br>OR (petges<br>AND clegat AND syndrome)<br>OR||
||(poikilodermatomyositis) OR (polymyositis AND arthropathica) OR (wegner AND<br>hepp AND unverrricht AND disease) OR 'polymyositis'/exp OR (fibromyositis OR<br>inomyositis) OR (myositis, AND poly) AND 'jo 1 antibody'/exp OR (antibody AND jo<br>AND 1) OR (antibody AND jo1) OR (autoantibody AND jo AND 1) OR (autoantibody<br>AND jo1) OR (jo AND 1 AND autoantibody) OR (jo1 AND antibody) OR (jo1 AND<br>autoantibody) AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|**Total**||**1.286**|  
Os registros obtidos nas bases de dados foram importados para o software Mendeley, onde as duplicatas foram identificadas e removidas. A elegibilidade dos estudos foi realizada em duas etapas por dois revisores independentes. A primeira etapa consistiu na avaliação do título e do resumo de cada estudo, utilizando a plataforma Rayyan®<sup>10</sup> . Na segunda, realizou-se a leitura por texto completo, feita também, por dois revisores independentes. Para as duas etapas, as discrepâncias foram resolvidas em consenso entre os revisores.  
_<u>Os critérios de inclusão aplicados foram:</u>_  
**Tipos de participante:** Pacientes com diagnóstico confirmado ou suspeito de miopatias inflamatórias;  
**Tipo de exposição:** Utilização do teste de anti-Jo1  
**Tipos de estudos:** Ensaios clínicos randomizados e não randomizados e estudos observacionais (coorte, caso controle, transversal).

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Desfechos:** -->
**(i)** Primários: taxa de recorrência, resposta, mortalidade, proporção de pacientes com comprometimento das articulações, artrite, doença pulmonar intersticial (DPI) e fraqueza muscular. **(ii)** Secundários: proporção de pacientes com mão de mecânico, comprometimento pulmonar, fenômeno de Raynaud, vasculite, e síndrome antissintetase, desde que fossem apresentados dados para pacientes com anti-Jo1 positivo e para pacientes com anti-Jo1 negativo.  
_<u>Como critérios de exclusão, foram considerados:</u>_  
- **1)** Estudos que utilizavam o anti-Jo1 para a seleção dos pacientes, mas não avaliavam o prognóstico e/ou as  
- características clínicas dos pacientes;  
- **2)** Estudos sobre a avaliação de diferentes testes de diagnósticos e sobre a caracterização molecular do anti-Jo1;  
- **3)** Estudos com relato dos resultados pela presença/ausência de um conjunto de anticorpos e não de forma individualizada  
- para o anti-Jo1;  
- **4)** Delineamento/publicações que fossem: revisão não sistemática da literatura, diretrizes/protocolos, editoriais, cartas  
- ao editor, comentários, opiniões e relatos de casos;  
**5)** Publicações com idioma não correspondente ao português, inglês e espanhol foram desconsideradas na fase de elegibilidade por texto completo.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Resultados da busca -->
Inicialmente foram identificadas 1.286 publicações. Após exclusão das duplicatas (n=23) e de elegibilidade por título e resumo, 277 referências foram selecionadas para avaliação por texto completo. Foram identificados 18 estudos que atendiam  
82  
integralmente aos critérios de inclusão. Na busca manual, foram encontrados outros 12 estudos que atendiam aos mesmos critérios, totalizando 30 estudos incluídos na revisão sistemática. A **Figura D** resume os resultados do processo de busca e seleção dos estudos. As referências excluídas na elegibilidade por leitura de texto completo e os motivos de exclusão estão descritas no **Quadro AD** .  
**Quadro AD.** Estudos excluídos na Revisão Sistemática sobre o anticorpo anti-Jo1 e motivo de exclusão  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||**Avalia o anti-Jo1 conjuntamente com outros**<br>Extended myositis panel and the clinical association in|**anticorpos**||
|1|Al Nokhatha,<br>S|<br>patient with suspected inflammatory disease, a<br>retrospective study|2021|Annals of the<br>Rheumatic Diseases|
|2|Montagnese,<br>F|Evaluating the usefulness of new line immunoassays for<br>myositis antibodies in clinical practice: A retrospective<br>study|2018|European Journal of<br>Neurology|
|3|Weiner, J|Easily obtainable myositis autoantibody panel predictive<br>factors|2017|Arthritis and<br>Rheumatology|
|||Anti-synthetase autoantibody is seen in patients with|||
|4|Almeida, B|overlap myositis in the UK cohort of patients with<br>jveunile dermatomyositis|2017|Pediatric Rheumatology|
|5|Faten, A|Clinical profile of myositis patients with myositis-<br>specific antibodies|2015|Annals of the<br>Rheumatic Diseases|
|6|Srivastava, P|Clinical and autoantibody profile in Indian patients with<br>myositis|2014|International Journal of<br>Rheumatic Diseases|
|7|Srivastava, P|Autoantibody profile (myositis specific and myositis<br>associated autoantibodies) in patients with idiopathic<br>inflammatory myositis; and its clinical correlation|2013|Indian Journal of<br>Rheumatology|
|8|Kütt, M and<br>Mägi, M|Myositis-Specific (MSA) and Myositis-Associated<br>Antibodies (MAA) found in estonian patients with<br>suspicion of idiopathic inflammatory myopathy|2010|Scandinavian Journal of<br>Immunology|
|9|Zanframundo,<br>G|Differences in antisynthetase syndrome definition and<br>related diagnostic performance. a systematic literature<br>review informing the new acr/eular classification criteria|2019|Annals of the<br>Rheumatic Diseases|
|10|Dawson, K|Improving EULAR/ACR classification criteria for<br>idiopathic inflammatory myopathies|2018|Arthritis and<br>Rheumatology|
|11|Ventín-<br>Rodríguez, C|Investigating the sensitivity and specificity of the<br>myositis profile-4 euroline assay|2019|Rheumatology (United<br>Kingdom)|
|12|Pál, E|Clinico-pathological correlations in idiopathic<br>inflammatory myopathies|2018|Journal of<br>Neuromuscular<br>Diseases|
|13|Fukamatsu, H|Distinct clinicopathologic and radiological<br>manifestations of the skin, lung, and muscle diseases in|2017|Journal of Investigative<br>Dermatology|  
83  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||patients with dermatomyositis positive for anti-<br>aminoacyl tRNA synthetase antibodies<br>**Avalia o diagnóstico de acordo com a especialidad**<br>Mositis-associated interstitial neumonia (MaIP):|**e médica**||
|14|Agarwal, S|y  p<br>Autoantibody associations in patients presenting to|2013|European Respiratory<br>Journal|
|||pulmonologists and rheumatologists|||
|||**Avaliação de anti-Jo1 em apenas parte da co**|**orte**||
|||Clinical profile of juvenile dermatomyositis in children<br>with disease onset ≤3 years of age is different compared|||
|15|Anjani, G|to those who had disease onset >3 years of age: A 28<br>years' experience from a tertiary care centre in Northern<br>India<br>**Caracterização molecular do anti-Jo1**<br>|2021|Pediatric Rheumatology<br>|
|16|Chiang, K P|Characterization of Jo-1 autoantibodies in patients with<br>|2012|Arthritis and<br>|
|||inflammatory myopathy and interstitial lung disease||Rheumatism|
|||**Carta ao editor**||European Respiratory|
|17|Nicod, L P|Fromtheauthors|2008|<br>Journal|
|18|Mecoli,<br>Christopher A|Myositis Autoantibodies: A Comparison of Results<br>From the Oklahoma Medical Research Foundation<br>Myositis Panel to the Euroimmun Research Line Blot.|2020|Arthritis &<br>rheumatology<br>(Hoboken, N.J.)|
|19|Hervier,<br>Baptiste|Patients with non-Jo-1 anti-RNA-synthetase<br>autoantibodies have worse survival than Jo-1 positive<br>patients.|2013|Annals of the rheumatic<br>diseases|
|20|Hengstman,<br>G J|Presence of the anti-Jo-1 autoantibody excludes<br>inclusion body myositis.|1998|Annals of neurology|
|21|Jearn, L|Anti-jo1 antibody in polymyositis/dermatomyositis is<br>|2015|Journal of<br>|
|||still closely associated with lung rather than joints||Rheumatology|
|||<br>**Concordância entre teste de diagnóstico**<br>Detection of coexisting myositis-specific autoantibodies||<br>Annals of the|
|22|Vulsteke, J;|with line and dot immunoassays in patients with|2019|<br>|
|||idiopathic inflammatory myopathies<br>**Descrição de projetos/sem relato de resultad**|**os**|Rheumatic Diseases<br>International Journal of|
|23|Gono, T|Updates on the SSc/myositis APLAR collaboration|2020|<br>|
|||**Desfecho: avalia o anti-Jo1 com utilização de re**|**cursos**|Rheumatic Diseases|
|24|Weiner, J|Real world use of the myositis autoantibody panel|2016|Arthritis and<br>Rheumatology|  
84  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|25|Gomez, G|Diagnostic procedures in the study of idiopathic<br>inflammatory myopathies from the argentinian registry|2019|Journal of Clinical<br>Rheumatology|
|||of myositis<br>**Desfecho: correlaciona com creatina quinase com prote**|**ína C-reativ**|<br>**a**|
|26|Griger Z,<br>2015|The shades of anti-jo1 positive antisynthetase syndrome<br>in a Hungarian cohort|2015|Annals of the<br>Rheumatic Diseases|
|||**Envolve outras populações que não só com miop**<br>Antinuclear antibodies in suspected Systemic lupus|**atias**||
|27|Patil, A|erythematosus (SLE) patients of a tertiary care hospital-<br>a retrospective study|2022|Bangladesh Journal of<br>Medical Science|
|28|Katiyar, S|Role of Detection of Autoantibodies in the Diagnosis of<br>Connective Tissue Disorders|2021|Indian Journal of<br>Medical Microbiology|
|29|Tseng, C|Diagnostic performance of line immunoassay in healthy<br>volunteers and rheumatology patients|2021|International Journal of<br>Rheumatic Diseases|
|30|Cotton, T|Serologic phenotypes distinguish SLE patients with<br>myositis and/or interstitial lung disease (ILD)|2021|Arthritis and<br>Rheumatology|
|31|Ball, 2020|Use of myositis specific autoantibodies test across a<br>large NHS hospital trust|2020|Annals of the<br>Rheumatic Diseases|
|32|Masiak, 2020|The clinical phenotype associated with antisynthetase<br>autoantibodies|2020|Reumatologia|
||Al-|Serological and immunological determination of auto-<br>|||
|33|Hamadany, A<br>Y M|antibodies against myositis-associated antigens in<br>systemic lupus erythematosus patients using a novel<br>immunoblot assay|2020|Medico-Legal Update|
|34|Leurs, A|Myositis-specific and-associated antibodies in systemic<br>sclerosis: Prevalence and clinical associations|2019|Arthritis and<br>Rheumatology|
|35|Cheng, C.-Y|Serum myositis specific/associate autoantibodies help<br>identify early connective tissue diseases relevant<br>interstitial lung diseases: A medical center experience|2019|Arthritis and<br>Rheumatology|
|36|Lizarzaburu,<br>M S|Do we diagnose all the antisynthetase syndrome?|2019|Annals of the<br>Rheumatic Diseases|
|37|Porta, A G|Miositisautoantibodies profile: Diagnosticrelevance|2019|Annals of the<br>Rheumatic Diseases|
|38|Kulkarni, N|A clinico-serological profile of inflammatory myositis:<br>An experience from rheumatology clinic|2018|Indian Journal of<br>Rheumatology|
|39|AL-Hayali,<br>W R Y|Detection Levels of Myositis-specific and Myositis<br>Associated Autoantibodies in Autoimmune Patients by<br>New Immunoblot Assay|2018|Biochemical and<br>Cellular Archives|
|40|Clark, K E N|Frequency and clinical associations of rare antibodies in<br>a large connective tissue disease cohort|2018|Arthritis and<br>Rheumatology|  
85  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|41|Carrasco<br>Cubero, M C|Clinical characteristics of a cohort of patients with anti-<br>JO1 antibodies|2018|Annals of the<br>Rheumatic Diseases|
|||What does it mean if a patient is positive for anti-Jo-1 in|||
|42|Jobanputra, P|routine hospital practice? A retrospectivenested case-<br>controlstudy.|2018|F1000 Research|
|43|Leung, M H<br>A|Idiopathic inflammatory myositis (IIM)-characteristic<br>clinical and myositis specific antibody (MSA)<br>phenotypes in Hong Kong Chinese patients|2016|International Journal of<br>Rheumatic Diseases|
|44|Costi, A C|Diagnosis and treatment of idiopathic inflammatory<br>myopathies|2016|Journal of Clinical<br>Rheumatology|
|45|Matsushita,<br>M|Clinical evaluation of anti-aminoacyl tRNA synthase<br>antibodies in rheumatoid arthritis patients|2014|Arthritis and<br>Rheumatology|
|46|Matsushita,<br>M|Clinical evaluation of anti-aminoacyl T-RNA synthetase<br>antibody in rheumatoid arthritis patients|2014|Annals of the<br>Rheumatic Diseases|
|47|Tanaka, M|Clinical features and CT findings of anti-Jo-1 antibody<br>positive interstitial lung disease with or without<br>polymyositis and dermatomyositis|2013|European Respiratory<br>Journal|
|48|Martinez<br>Becerra, M J|Myositis specific autoantibodies (MSA) and myositis<br>associated autoantibodies (MAA). Experience in a<br>Spanish cohort|2013|Annals of the<br>Rheumatic Diseases|
|49|Tun, A M|Clinical significance of anti Jo1 antibodies in interstitial<br>lung disease|2012|American Journal of<br>Respiratory and Critical<br>Care Medicine|
|50|Roberts-<br>Thomson|Clinical heterogeneity and prognostic features of South<br>Australian patients with anti-synthetase autoantibodies|2009|Internal Medicine<br>Journal|
|51|Jiang, Minna|Clinical characteristics of interstitial lung diseases<br>positive to different anti-synthetase antibodies.|2021|Medicine|
|52|Aggarwal,<br>Rohit|Patients with non-Jo-1 anti-tRNA-synthetase<br>autoantibodies have worse survival than Jo-1 positive<br>patients.|2014|Annals of the rheumatic<br>diseases|
|53|Stone, Kerry<br>B|Anti-Jo-1 antibody levels correlate with disease activity<br>in idiopathic inflammatory myopathy.|2007|Arthritis and<br>rheumatism|
|54|Bernstein,<br>1984|Anti-Jo-1 antibody: a marker for myositis with<br>interstitial lung disease.|1984|British medical journal<br>(Clinical research ed.)|
|||Clinical and serological aspects of patients with anti-Jo-|||
|55|Schmidt, W A|1 antibodies--an evolving spectrum of disease<br>manifestations.|2000|Clinical rheumatology|
|56|Pourhadi, H|MYOSITIS SPECIFIC ANTIBODIES IN ADULT<br>PATIENTS INVESTIGATED FOR INTERSTITIAL|2022|Internal Medicine<br>Journal|  
86  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||LUNG DISEASE: PREVALENCE AND PATIENT<br>CHARACTERISTICS|||
|57|Wolff, V|Diagnostic utility of myositis antibodies in patients with<br>interstitial lung disease and suspected underlying<br>connective tissue disease|2018|Arthritis and<br>Rheumatology|
|58|Greco, M|Antisynthetase syndromes: Correlation of indirect<br>immunofluorescence patterns with diagnosis criteria<br>fulfillment|2019|Arthritis and<br>Rheumatology|
|59|Greco, M|Performance of the antisynthetase antibodies and their<br>indirect immunofluorescence patterns in the<br>antisynthetase syndrome diagnosis|2019|Annals of the<br>Rheumatic Diseases|
|60|O'donnell,|Incidence of myositis-specific autoantibody (MSA)<br>specificities in sera referred to new zealand (NZ)<br>medical laboratories|2017|Annals of the<br>Rheumatic Diseases|
|61|Jobanputra, P|Clinical utility of autoantibodies against extractable<br>nuclear antigens in routine care: frequency of repeated<br>test requests and diagnostic value of anti-jo-1 (anti-<br>histidyl-trna synthetase)|2017|Annals of the<br>Rheumatic Diseases|
|62|De Sadeleer,<br>Laurens J|Prevalence of Myositis-Specific Antibodies in Idiopathic<br>Interstitial Pneumonias.|2018|Lung|
|63|Tillie-<br>Leblond, I|Interstitial lung disease and anti-Jo-1 antibodies:<br>difference between acute and gradual onset.|2008|Thorax|
|||Diagnosis of myositis-associated interstitial lung|||
|64|Jee AS|disease: Utility of the myositis autoantibody line|2021|Respiratory medicine.|
|||immunoassay.|||
|||**Estudo de caso e série de casos**|||
|||Dshaia as isolated manifestation of JO-1 associated|||
|65|Labeit, B|ypg<br>myositis?|2019|Frontiers in Neurology|
|66|Kavoura, P|Clinical features of dermatitis, myositis and severe ILD.<br>Could the AntiSSA / Ro52 antibodies be a diagnostic<br>and prognostic tool for Antisyntatasesyndrom?|2018|European Respiratory<br>Journal|
|67|Johns, E|Make the diagnosis: Antisynthetase syndrome|2015|Journal of General<br>Internal Medicine|
|68|Yadav, P K|Early onset interstitial lung disease and JO 1 positivity|2010|Indian Journal of<br>Rheumatology|
|69|Nakajima,<br>2012|High frequencies and co-existing of myositis-specific<br>autoantibodies in patients with idiopathic inflammatory<br>myopathies overlapped to rheumatoid arthritis.|2012|Rheumatology<br>international|  
87  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||Inflammatory myopathy, bronchiolitis|||
|70|Kalenian, M|obliterans/organizing pneumonia, and anti-Jo-1<br>antibodies--an interesting association.|1997|Clinical and diagnostic<br>laboratory immunology|
|71|Sugie,<br>Kazuma|Characterization of dermatomyositis with coexistence of<br>anti-Jo-1 and anti-SRP antibodies.|2012|Internal medicine<br>(Tokyo, Japan)|
|72|Phillips, T J|Dermatomyositis and pulmonary fibrosis associated<br>with anti-Jo-1 antibody.|1987|Journal of the American<br>Academy of<br>Dermatology|
|73|Mileti, Linda|Clinical characteristics of patients with anti-Jo-1<br>antibodies: a single center experience.|2009|Journal of clinical<br>rheumatology :<br>practical reports on<br>rheumatic &<br>musculoskeletal<br>diseases|
|74|Taggart, A J|Anti Jo-1 myositis. 'Mechanic's hands' and interstitial<br>lung disease.|2002|The Ulster medical<br>journal|
|75|Poveda<br>Gómez, F|Polymyositis associated with anti-Jo1 antibodies: severe<br>cardiac involvement as initial manifestation.|1993|The American journal<br>of medicine|
|76|O'Neill, T W|Rheumatoid arthritis associated with myositis and anti-<br>Jo-1 antibody.|1993|The Journal of<br>rheumatology|
|77|Mozaffar,<br>2000|Myopathy with anti-Jo-1 antibodies: pathology in<br>perimysium and neighbouring musclefibres.|2000|Journal of neurology,<br>neurosurgery, and|
|||<br>**Não avalia especificamente o anti-Jo1 (avaliação de IgG**|**Fc-glycans**|psychiatry<br>**)**|
|||Anti-JO1 positive myositis patients display a|||
|78|Fernandes-<br>Cerqueira, C|<br>characteristic IgG FC-glycan profile which is further<br>enhanced in anti-JO1 autoantibodies|2018|Arthritis and<br>Rheumatology|
|79|Cerqueira, C<br>F|Anti-Jo1-positive myositis patients display a specific<br>immunoglobulin G Fc-glycan profile which is further|2018|Scandinavian Journal of<br>Rheumatology|
||<br>**N**|enhanced in anti-Jo1 autoantibodies<br>**ão avalia especificamente o anti-Jo1/utiliza para a classifi**|**cação da do**|<br>**ença**|
|80|Hum, R M|CLINICAL FEATURES OF EXTRA-MUSCULAR<br>DISEASE IN DERMATOMYOSITIS AND ANTI-<br>SYNTHETASE SYNDROME PATIENTS WITH SKIN<br>INVOLVEMENT CLASSIFIED BY PRESENCE OF<br>DISEASE-SPECIFIC AUTOANTIBODIES: RESULTS<br>FROM THE EUROMYOSITIS REGISTRY|2022|Rheumatology (United<br>Kingdom)|
|81|Liu, D|Integrated analysis of plasma and urine reveals unique<br>metabolomic profiles in idiopathic inflammatory<br>myopathies subtypes|2022|Journal of Cachexia,<br>Sarcopenia and Muscle|  
88  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||Clinical, radiologic, and pathological implications of||American Journal of|
|82|Zamora, 2014|positive anti-Jo-1 serology in patients with suspected<br>inflammatory myositis|2014|Respiratory and Critical<br>Care Medicine|
|83|Marie, 2013|Interstitial lung disease in anti-Jo-1 patients with<br>antisynthetase syndrome.|2013|Arthritis care &<br>research|
|84|Späth, 2004|The long-term outcome of anti-Jo-1-positive<br>inflammatory myopathies.|2004|Journal of neurology|
|85|Marie, 2013|Functional outcome and prognostic factors in anti-Jo1<br>patients with antisynthetase syndrome.|2013|Arthritis research &<br>therapy|
|86|Scorletti,<br>2013|Clinical picture of anti-jo-1 positive anti-synthetase<br>syndrome at presentation and during follow-up|2013|Annals of the<br>Rheumatic Disease|
|||AUTOIMMUNE MYOPATHIES: P.307 Evaluation of|||
|87|Mariampillai,<br>K|ACR/EULAR criteria for myositis diagnosis and<br>classification in care pathways of a French<br>neuromuscular reference centre|2020|Neuromuscular<br>Disorders|
|88|Alalwani, M|Descriptive Data Analysis of Patients with Anti Jo1<br>Syndrome (AJS) and Lung Involvement|2020|Arthritis and<br>Rheumatology|
|89|Nakanishi, T|Long-term outcome of 53 patients with anti-Jo-1<br>antibody-positive interstitial lung disease|2017|European Respiratory<br>Journal|
||Trallero-|Clinical manifestations and long-term outcome of anti-||Si i hii|
|90|Araguás,|Jo1 antisynthetasepatients in a large cohort of Spanish|2016|emnars n artrts<br>and rheumatism|
||2016|patients from the GEAS-IIM group.|||
|||**Não avalia o anti-Jo1**|||
|||Comparison of anti-OJ antibody detection assays|||
||Hamachi||||
|91|gu,<br>Y|between an immunoprecipitation assay and line blot<br>assay|2017|Modern Rheumatology|
|92|Sugiyama, Y<br>Y|The analysis of prognostic factors in patients with<br>inflammatory myopathies and amyopathic<br>dermatomiositis complicated with interstitial lung<br>disease|2013|Annals of the<br>Rheumatic Diseases|
|93|Váncsa,<br>Andrea|Characteristics of interstitial lung disease in SS-A<br>positive/Jo-1 positive inflammatory myopathy patients.|2009|Rheumatologyinternatio<br>nal|
|94|Martínez-<br>Barrio, J|Antisynthetase syndrome: Clinical and serological<br>characteristics at disease onset|2014|Annals of the<br>Rheumatic Diseases|
|||Characterization of anti-aminoacyl TRNA synthetase|||
|95|Preger, C|autoantibodies in patients with idiopathic inflammatory<br>myopathies|2020|Annals of the<br>Rheumatic Diseases|
|96|Li, L|Analysis of myositis auto-antibodies in Chinese patients<br>with cancer-associated myositis|2019|European Journal of<br>Immunology|  
89  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||Autoantibody profile of children with juvenile|||
|97|Bhattarai, D|dermatomyositis from a tertiary care center in North|2018|Indian Journal of<br>Rheumatology|
|||India<br>**Não relata os resultados por anti-Jo1**<br>Myositis-specific autoantibodies in||<br>E Jl f|
|98|Li, L|dermatomyositis/polymyositis with interstitial lung<br>disease|2019|uropean ourna o<br>Immunology|
|99|Pinal-<br>Fernandez|Myositis autoantibodies outperform clinical subgroup<br>classification in predicting muscle weakness in myositis<br>patients|2017|Annals of the<br>Rheumatic Diseases|
|100|Chahin, N|Phenotype-antibody correlation in dermatomyositis<br>(DM)|2015|Neuromuscular<br>Disorders|
|101|Srivastava, P|Myositis-specific and myositis associated autoantibodies<br>in ndian patients with inflammatory myositis|2014|Indian Journal of<br>Rheumatology|
|102|Tansley, S L|Autoantibody in juvenile dermatomyositis reflects<br>disease activity: Results of a pilot study|2014|Rheumatology (United<br>Kingdom)|
|103|Saito, R|Histopathological features of anti-Jo-1-antibody-positive<br>myositis patients with interstitial lung disease|2012|Neuropathology|
|104|Lopez<br>Salguero, S|Characterization of anti-myositis antibody related<br>myopathies. Descriptive study in a multicentric cohort|2020|Annals of the<br>Rheumatic Diseases|
|105|Payette, M.-P|Redefining dermatomyositis: Description of new<br>diagnostic criteria that differentiate pure<br>dermatomyositis from overlap myositis with<br>dermatomyositis features|2014|Arthritis and<br>Rheumatology|
|106|Welding, I|A SERVICE EVALUATION OF THE MYOSITIS<br>CLINIC AT LONDON NORTH WEST UNIVERSITY<br>HEALTHCARE TRUST|2022|Rheumatology (United<br>Kingdom)|
|107|Mariampillai,<br>K|AUTOIMMUNE MYOPATHIES: P.308 Characteristics<br>of chest CT-scan patterns of idiopathic inflammatory<br>myopathies: association with myositis-specific<br>autoantibodies|2020|Neuromuscular<br>Disorders|
|108|Tsuji, T|The role of detection of myositis specific and associated<br>antibodies in Japanese patient with interstitial lung<br>disease|2014|European Respiratory<br>Journal|
|109|Bucelli, R|Clinical features of immune myopathies with perimysial<br>|2012|Neurology|
|||pathology (IMPP)|||
|||**Outra língua**|||
|||Serum complement C1q level in patients with||Chi Jl f|
|110|Shi, L|polymyositis/dermatomyositis and its clinical<br>significance|2020|nese ourna o<br>Laboratory Medicine|  
90  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||Relationship between serum Anti Jo-1 antibody and|||
|111|Wang, Y.-X.|antinuclear antibody and patients with polymyositis<br>accompanied heart or lung damage|2010|Journal of Clinical<br>Neurology|
|112|Kalinova, D|Myositis-specific and myositis-associated antibodies.<br>Overlapmyositis|2009|Revmatologiia|
|113|Modrá, M|Specific and associated autoantibodies in polymyositis<br>and dermatomyositis|2008|Ceska Revmatologie|
|||Expression of myositis specific autoantibodies in|||
|114|Liu, F|polymyositis/ dematomyositis and other neuromuscular<br>diseases|2008|Journal of Clinical<br>Neurology (China)|
|115|Wang, C.-Z.|Significance of laboratory detection in the prognosis<br>evaluation of patients with polymyositis or<br>dermatomyositis|2005|Chinese Journal of<br>Clinical Rehabilitation|
|116|Bizzaro, N|The Jo-1 antigen (histidyl-tRNA synthetase)|2000|Rivistadi Medicina di<br>Laboratorio|
|117|Takayasu, V|Clinical and laboratory characterization of patients with<br>dermatomyositis/polymyositis|1998|Revista Brasileira de<br>Reumatologia|
|118|Zheng, Wen-<br>Jie|[Clinical features and misdiagnosis of anti-Jo-1<br>syndrome: analysis of 33 cases].|2003|Zhonghuayixuezazhi|
|119|Meng, L C|[Clinical and myopathological features of Jo-1<br>syndrome].|2016|Zhonghuayixuezazhi|
|120|Szabó,<br>Katalin|[The shades of anti-Jo1 positive antisynthetase<br>syndrome in a Hungarian cohort].|2016|Orvosihetilap|
|121|Treher, E|[Polymyositisand Jo-1 syndrome].|1993|Zeitschriftfur<br>Rheumatologie|
|122|Katsuki,<br>Yumiko|[Immunologic tests: Anti-Jo-l antibody (anti-histidyl<br>transfer RNA synthetase antibody)].|2005|Nihon rinsho. Japanese<br>journal of clinical<br>medicine|
|||[Immunologic tests: Anti-PL 7 antibodies, anti-PL-12||Nihon rinsho. Japanese|
|123|Hirakata,<br>Michito|antibodies, and other anti-aminoacyl tRNA synthetase<br>antibodies].|2005|journal of clinical<br>medicine|
|124|Genth, E<br>andMierau, R|[Jo-1-(antisynthetase-) syndrome--do autoantibodies<br>improve classification of myositis?].|1993|ZeitschriftfurRheumatol<br>ogie|
|125|Hirakata,<br>Michito|[Anti-Jo-1(histidyltRNAsynthetase) antibodies].|2010|Nihon rinsho. Japanese<br>journal of clinical<br>medicine|
|||[Anti-Jo-1 antibody and anti-aminoacyl-tRNA||Nihon rinsho. Japanese|
|126|Kinoshita, M|synthetase antibody as a marker autoantibody for<br>myositis].|1990|journal of clinical<br>medicine|  
91  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|127|Leu, C|Anti-Jo-1 antibody in patients with<br>polymyositis/dermatomyositis.|1992|Zhonghua Minguowei<br>sheng wu ji mianyixue<br>za zhi = Chinese journal<br>of microbiology and<br>immunology|
|128|Liu, H|Clinical features and imaging findings of interstitial lung<br>disease in antisynthetase syndrome|2017|Chinese Journal of<br>Radiology (China)|
|129|Dai, L.-M.|Clinical analysis of 40 patients with dermatomyositis<br>complicated with interstitial lung disease|2009|Journal of Clinical<br>Dermatology|
|130|Li, Y H|[Analysis of immunological characteristics of<br>dermatomyositis patients with myocardial involvement].|2020|Zhonghuayixuezazhi|
|131|Li, W|[Clinical characteristics of patients with antisynthetase<br>syndrome and interstitial pulmonary disease].|2020|Zhonghuayixuezazhi|
|||||Zhonghuajie he he hu xi|
|||[The clinical significance of myositis-specific antibodies||za zhi = Zhonghuajiehe|
|132|Xie, M|in polymyositis/dermatomyositis associated interstitial<br>lung diseases].|2018|he huxizazhi = Chinese<br>journal of tuberculosis<br>and respiratory diseases|
|||[Clinical features and risk factors associated with||Sichuan da xuexuebao.|
|133|Lin, Hui|interstitial lung disease in patients with classic<br>dermatomyositis or clinical amyopathic<br>dermatomyositis].|2013|Yi xue ban = Journal of<br>Sichuan University.<br>Medical scienceedition|
|134|Li, Hong|[A clinical analysis of dermatomyositis with interstitial<br>|2012|Zhonghuaneikezazhi|
|||lung disease in 20 patients].|||
|||<br>**Purificação do anti-Jo1**|||
|135|Fernandes-<br>|Characterisation of anti-JO1 autoantibodies in myositis|2015|Annals of the<br>|
||Cerqueira, C|||Rheumatic Diseases|
|||**Revisão não sistemática da literatura**|||
|||Clinical features and cutaneous manifestations of|||
|136|Okiyama, N|juvenile and adult patients of dermatomyositis<br>associated with myositis-specific autoantibodies|2021|Journal of Clinical<br>Medicine|
|137|Mende, M|Autoantibodies in myositis. How to achieve a<br>comprehensive strategy for serological testing|2019|Mediterranean Journal<br>of Rheumatology|
|138|Sato, S|Utility of dermatomyositis-specific autoantibodies for<br>diagnosis and clinical subsetting|2015|International Journal of<br>Clinical Rheumatology|
|139|Allenbach, Y|Diagnostic utility of auto-antibodies in inflammatory<br>muscle diseases|2015|Journal of<br>Neuromuscular<br>Diseases|  
92  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||||Clinical and|
|140|Fujimoto, M|Dermatomyositis: Myositis-specific autoantibodies and<br>skin manifestations|2012|Experimental<br>Neuroimmunology|
|141|Miniño, M|Antibodies for systemic autoimmune diseases.<br>Applications in dermatology. Part II|2005|Dermatologia<br>Cosmetica, Medica y<br>Quirurgica|
|142|Zampieri,<br>Sandra|Anti-Jo-1 antibodies.|2005|Autoimmunity|
|143|Monti, Sara|Clinical spectrum of anti-Jo-1-associated disease.|2017|Currentopinion in<br>rheumatology|
|144|Ascherman,<br>Dana P|Role of Jo-1 in the Immunopathogenesis of the Anti-<br>synthetase Syndrome.|2015|Currentrheumatologyre<br>ports|
|145|Hengstman,<br>Gerald J D|Myositis specific autoantibodies: changing insights in<br>pathophysiology and clinical associations.|2004|Currentopinion in<br>rheumatology|
|146|Tartar,<br>Danielle M|Clinical significance of autoantibodies in<br>dermatomyositis and systemic sclerosis.|2018|Clinics in dermatology|
|147|García-de la<br>Torre, I|Laboratoryabnormalitiesandautoantibodies|2009|Reumatologia Clinica|
|148|Castillo, R|Dermatomyositis: Autoantibodies and Their<br>Cdi Pht|2017|Current Treatment<br>Options in|
|||orresponng enoypes||Rheumatology|
|||**Estudo repetido**<br>|||
|149|Oguz, E|Classification of idiopathic inflammatory myopathies:<br>Assessment of 123 patients according to 2017<br>ACR/EULAR criteria followed up by a single center<br>from Turkey|2018|Arthritis and<br>Rheumatology|
|||Idiopathic inflammatory myopathies: Clinical||Clinical and|
|150|Oguz, E|characteristics, survival and poor prognostic fac-tors of<br>110 patients from Turkey|2018|Experimental<br>Rheumatology|
|151|O'Donnell, J|Incidence of myositis-specific autoantibody (MSA)<br>specificities in sera referred to New Zealand (NZ)|2017|Internal Medicine<br>Journal|
|||medical laboratories|||
|||**Não foi possível extrair os resultados**|||
|||Evaluation of the detection of myositisspecific||Al f h|
|152|Piette|antibodies by lineblot as a tool for the characterisation<br>of a prospective multicenter cohort|2018|nnas o te<br>Rheumatic Diseases|
|153|Suahilai|Auto-antibodies in idiopathic inflammatory myositis:<br>Case series from a rheumatology referral centre cohort<br>in Malaysia|2018|International Journal of<br>Rheumatic Diseases|  
93  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|||Long-term outcomes in 50 patients with idiopathic|||
|154|Ferraro M|inflammatory myopathies (IIM) and role of myositis-<br>specific antibodies|2020|European Journal of<br>Neurology|
|155|Giannini M,<br>2018|Anti-SSA and anti-jo1 levels in interstitial lung disease<br>related to idiopathic inflammatory myopathies|2018|Annals of the<br>Rheumatic Diseases|
|156|Kalinova D,<br>2013|Frequency and relationships between autoantibodies and<br>clinical features in 70 patients with autoimmune<br>myositis in bulgarian population|2013|Annals of the<br>Rheumatic Disease|
|157|Kondo Y,<br>2019|Specificity of anti-TRNA synthetase autoantibodies<br>correlated with clinical course and prognosis of<br>myositis-associated interstitial lung disease|2019|Annals of the<br>Rheumatic Diseases|
|158|Li XP, 2012|Predictive and unfavorable prognostic factors analysis<br>of interstitial lung disease in patients with inflammatory<br>myopathy|2012|Journal of Rheumatic<br>Diseases|
|159|Srivastava P,<br>2014|Myositis-specific and myositis associated autoantibodies<br>in indian patients with inflammatory myositis|2014|Indian Journal of<br>Rheumatology|
|160|Wong VTL,<br>2018|Myositis-specific autoantibodies and their clinical<br>associations|2018|Arthritis and<br>Rheumatology.|
|161|Bundell,<br>2012<sup>4a</sup>|Myositis autoantibodies detectable by immunoblotting<br>occur in the general population|2012|Internal Medicine<br>Journal|
|162|Cavazzana,<br>2016<sup>5</sup>|Testing for myositis specific autoantibodies:<br>Comparison between line blot and immunoprecipitation<br>assays in 57 myositis sera|2016|Journal of<br>immunological methods|
|163|Greco, 2019<sup>6a</sup>|Idiopathic inflammatory myopathiesandantisynthetase<br>syndrome: Contribution of antisynthetase antibodies to<br>improve current classification criteria|2019|Annals of the<br>Rheumatic Diseases|
|164|Greco, 2020<sup>7a</sup>|Anti-jo1 antibodies in a real-world population|2020|Annals of the<br>Rheumatic Diseases|
|||The use and diagnostic value of testing myositis-specific||Therapeutic Advances|
|165|Lackner,<br>2020<sup>8</sup>|and myositis-associated autoantibodies by line immuno-<br>assay: a retrospective study|2020|in Musculoskeletal<br>Disease|
|166|Lackner,<br>2018<sup>9a</sup>|Validation of the diagnostic accuracy of myositis-related<br>antibodies in a large patient-cohort|2018|Arthritis and<br>Rheumatology.|
||Loarce-|“are myositis antibodies specific for idiopathic|||
|167|Martos,<br>2020<sup>10a</sup>|inflammatory myopathy diagnosis?” clinical correlation<br>of a cohort of patients positive for myositis antibodies|2020|Annals of the<br>Rheumatic Diseases|
|168|Mahler,<br>2021<sup>11</sup>|Profiling of myositis specific antibodies and composite<br>scores as an aid in the differential diagnosis of<br>autoimmune myopathies|2021|Diagnostics|  
94  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**<br>|
|---|---|---|---|---|
|169|Mammen,<br>2015<sup>12</sup>|. Myositis-specific autoantibodies are specific for<br>myositis compared to genetic muscle disease|2015|Neurology:<br>Neuroimmunologyand<br>NeuroInflammation|
|||Myositis-specific and myositis-associated|||
|170|Nakashima,<br>2017<sup>13a</sup>|autoantibodies in patient with dermatomyositis /<br>polymyositis; comparison between line blot and<br>enzyme-immunoassay assays|2017|Annals of the<br>Rheumatic Diseases|
|171|Nazir, 2021<sup>14a</sup>|Performance of commercial autoantibody testing in<br>comparison to recognized gold standards in myositis<br>autoantibody testing|2021|Arthritis and<br>Rheumatology|
||Rojana-|Myositis-associated, myositis-specific and organ-|||
|172|udomsart,<br>2012<sup>16a</sup>|specific autoantibodies in inflammatory myopathies: A<br>West Australian population control study|2012|Neuromuscular<br>Disorders|
|||Anti-Ro52 antibodies frequently co-occur with anti-Jo-1||Clinical and|
|173|Rutjes, 1997<sup>17</sup>|antibodies in sera from patients with idiopathic<br>inflammatory myopathy.|1997|experimental<br>immunology|
|||Line blot immunoassays in idiopathic inflammatory|||
|174|To, 2020<sup>18</sup>|myopathies: Retrospective review of diagnostic<br>accuracy and factors predicting true positive results|2020|BMC Rheumatology|
|175|Vulsteke,<br><sup>19a</sup>|Prevalence of myositis-specific antibodies in idiopathic<br>inflammatory myopathy compared to disease and|2017|Annals of the<br>|
||2017|healthy controls.<br>**Revisão sistemática da literatura sem desfechos de**|**interesse**|Rheumatic Diseases|
||Kamia H|Systematic review and meta-analysis of prognostic|||
|176|y ,<br>21|factors for idiopathic inflammatory myopathy-|2018|BMJ open|
||08|associated interstitial lung disease|||
|||**Não faz comparação anti-Jo1(+) e anti-Jo1(**|**-)**||
|||Clinical features and outcome in polymyositis vs.||Arthritis and|
|177|Aggarwal, R|Dermatomyositis patients with the Anti-Jo-1<br>Autoantibody|2013|<br>Rheumatism|
|178|Bolko, L|Anti-Jo1 Antibody Quantification Serve as a Prognostic<br>Factor in AntisynthetaseSyndrom|2020|Arthritis and<br>Rheumatology|
|179|Busca, C|Antisynthetase syndrome: Autoantibodies, clinical<br>pattern and management of 17 spanish patients|2017|Annals of the<br>Rheumatic Diseases|
|||Clinical and temporal characterization of anti-Jo-1|||
|180|Cavagna, L|<br>positive anti-synthetase syndrome: Preliminary results<br>of an international multicentre study|2014|Arthritis and<br>Rheumatology|
|181|Chang, S|Clinical characteristics of anti-Jo-1-positive interstitial<br>lung disease|2019|European RespiratoryJ<br>ournal|  
95  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|182|Chen, I-Jung|Interstitial lung disease in polymyositis and<br>dermatomyositis.|2009|Clinical rheumatology|
|183|Cherny, D|The Presence of Anti-Jo1, anti-PL7, And/or anti-MDA5<br>Antibodies in Idiopathic Inflammatory Myopathy<br>Confers an Increased Risk of a Significant Restrictive<br>Pulmonary Defect|2020|Arthritis and<br>Rheumatology|
|184|Ciang, N|Idiopathic inflammatory myopathies & interstitial lung<br>disease|2018|Annals of the<br>Rheumatic Diseases|
|185|Deligny, C|Epidemiology and characteristics of antisynthetase<br>syndrome in the African descent population of<br>martinique|2014|Arthritis and<br>Rheumatology|
|186|Feng, D|Predictive factors of different lung disease accompany<br>dermatomyositis: A clinical case-control study|2014|Respirology|
|187|Hengstman,<br>G|Clinical and serological characteristics of 125 Dutch<br>myositis patients. Myositis specific autoantibodies aid in<br>the differential diagnosis of the idiopathic inflammatory<br>myopathies.|2002|Journal of neurology|
|||The clinical spectrum but not the evolution of|||
|188|Hervier, B|antisynthetase syndrome is related to the antisynthetase<br>antibody specificity: A retrospective analysis of 142<br>patients|2011|Arthritis and<br>Rheumatism|
|189|Kang, E|Interstitial lung disease in patients with polymyositis,<br>dermatomyositis and amyopathic dermatomyositis.|2005|Rheumatology (Oxford,<br>England)|
|190|Law, J|Assessing Interstitial Lung Disease in a Racially Diverse<br>Population with Idiopathic Inflammatory Myositis|2020|Arthritis and<br>Rheumatology|
|191|Li, Q|Profiling autoantibodies in idiopathic inflammatory<br>myopathies|2018|Journal of Immunology|
|||Factors predicting malignancy in patients with|||
|192|Lu, Xin|polymyositis and dermatomyostis: a systematic review<br>and meta-analysis.|2014|PloSone|
|193|Marie, I|Pulmonary involvement in polymyositis and in<br>dermatomyositis.|1998|The Journal of<br>rheumatology|
|194|Marie, I|Comparison of long-term outcome between anti-Jo1-<br>and anti-PL7/PL12 positive patients with antisynthetase<br>syndrome.|2012|Autoimmunity reviews|
|195|Martinez, S|Autoantibodies predict long term survival in myositis<br>associated interstitial lung disease|2017|Arthritis and<br>Rheumatology|
|196|Martins, P|Clinical characterization of Portuguese patients with<br>antisynthetase syndrome|2021|Annals of the<br>Rheumatic Diseases|  
96  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|197|Mathew, A|Clinical correlates of autoantibodies in inflammatory<br>myositis|2015|Internal Medicine<br>Journal|
|198|Mathew, A|Autoantibody profile and associated clinical outcomes<br>in an indian population with myositis|2015|Rheumatology (United<br>Kingdom)|
|199|Mescam-<br>Mancini, L|Anti-Jo-1 antibody-positive patients show a<br>characteristic necrotizing perifascicular myositis.|2015|Brain: a journal of<br>neurology|
|200|Negalur, N|The myositis autoantibody phenotypes in inflammatory<br>myositis|2017|Indian Journal of<br>Rheumatology|
|201|Negalur, N|The association of myositis specific antibodies in<br>patients with inflammatory myositis: Preliminary data in<br>indian patients|2018|Annals of the<br>Rheumatic Diseases|
|202|Ortiz-<br>Guerrero,|Serologic and pathologic correlation in IIM|2019|Journal of Clinical<br>Neuromuscular Disease|
|203|Phuong, T|Clinical characteristics of Vietnamese patients with<br>idiopathic inflammatory myopathies and autoantibodies<br>to aminoacyl-transfer RNA synthetases.|2021|International journal of<br>rheumatic diseases|
|204|Preusse, C|P.18Comparing histological features and molecular gene<br>expression in anti-Jo1-, anti-PL-7 and anti-PL-12<br>antibody-positive patients|2019|Neuromuscular<br>Disorders|
|205|Szczesny, P|Sequence of clinical symptoms Onset and its correlation<br>to the autoantibodies presence in patients with<br>Idiopathic inflammatory myopathies|2019|Annals of the<br>Rheumatic Diseases|
|206|Tang, Z|Clinical characteristics and risk factors of polymyositis<br>and dermatomyositis combined with interstitial lung<br>disease in patients residing in the Northeast Sichuan<br>province in China|2019|Annals of the<br>Rheumatic Diseases|
|207|Tomonaga, M|Comparison of Pulmonary Involvement Between<br>Patients Expressing Anti-PL-7 and Anti-Jo-1 Antibodies|2014|Lung|
|208|Truong, A|Antisynthetase syndrome: Comparison of laboratory and<br>clinical characteristics of muscle and lung in Jo1 Vs.<br>Non-Jo1 patients|2010|American Journal of<br>Respiratory and Critical<br>Care Medicine|
|209|Watad, A|Autoantibody status in dermatomyositis and<br>polymyositis patients defines both cancer risk and<br>survival with ana negativity in cases with concomitant<br>cancer having a worse survival|2020|Annals of the<br>Rheumatic Diseases|
|210|Yardimci, G|Emerging autoantibodies panel (myositis associated and<br>myositis specific antibodies) in inflammatory<br>myopathies: the frequencies of and relationship with<br>clinical features|2020|Annals of the<br>Rheumatic Diseases|  
97  
|**Nº**|**Autores**|**Título**<br>|**Ano**|**Revista**|
|---|---|---|---|---|
|211|Zamora, A|Clinical features and outcomes of interstitial lung<br>disease in anti-Jo-1 positive antisynthetase syndrome.|2016|Respiratory medicine|
|212|Zhan, Xi|Clinical features of anti-synthetase syndrome associated<br>interstitial lung disease: a retrospective cohort in China.|2021|BMC pulmonary<br>medicine|
|||<br>**Avaliou apenas a frequência do anti-Jo1 na população c**|**om miopati**|**as**|
|213|Álvarez<br>Troncoso|Myositis-specific antibodies in a retrospective single-<br>center observational study|2021|Annals of the<br>Rheumatic Diseases|
|||Characterisation of anti-synthetase syndrome (ASS),|||
|214|Barratt|initially presenting to respiratory services as interstitial<br>lung disease (ILD) of unknown cause|2018|Thorax|
|215|Bucelli|Immune myopathies with perimysial pathology: Clinical<br>and laboratory features|2018|Neurology:<br>Neuroimmunologyand<br>NeuroInflammation|
|216|Ceribelli|Distinctive pattern of myositis-specific autoantibody<br>production between americancaucasian and italian<br>patients with polymyositis/dermatomyositis|2011|Arthritis and<br>Rheumatism|
|217|Chang|Autoantibody profile and clinical characteristics in<br>patients with idiopathic inflammatory myopathies|2018|Arthritis and<br>Rheumatology|
|218|Chung|Clinical features of interstitial lung disease associated<br>with korean idiopathic inflammatory myopathies<br>according to the autoantibody profile|2019|Annals of the<br>Rheumatic Diseases|
|219|Cobo-Ibáñez|Prognosis of the idiopathic inflammatory myopathies<br>associated with interstitial lung disease: Preliminary<br>analysis of the registry remicam|2016|Annals of the<br>Rheumatic Diseases|
|220|Coffey|Incidence of antisynthetase syndrome and risk of<br>malignancy in a population-based cohort (1998-2019)|2021|Arthritis and<br>Rheumatology|
|221|Daly|Cutaneous features of dermatomyositis associated with<br>myositis-specific antibodies|2013|British Journal of<br>Dermatology|
|222|Faten|Autoantibodies in idiopathic inflammatory myopathies|2015|Annals of the<br>Rheumatic Diseases|
|223|Fredi|Autoantibody profile in a cohort of adult patients with<br>inflammatory myophaties|2013|Annals of the<br>Rheumatic Disease|
|224|Fukamatsu|Autoantibody profile and clinical manifestations related<br>to anti-synthetase syndrome|2016|Journal of<br>Dermatological Science|
|225|Gonzalez-<br>Bello|Study of autoantibodies in a cohort of Mexican patients<br>with idiopathic inflammatory myopathies|2014|Arthritis and<br>Rheumatology|
|226|Gracia-<br>Arechiga|Seventeen myositis autoantibodies: Serological profile<br>of hispanic patients with idiopathic inflammatory<br>myopathies|2018|Annals of the<br>Rheumatic Diseases|  
98  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|227|Granel|Myositis specific antibodies and clinical features in<br>patients from Argentina|2019|Arthritis and<br>Rheumatology|
|228|Guerrero|Serologic and pathologic correlation in idiopathic<br>inflammatory myopathies: A retrospective chart review|2019|Neurology|
|229|Guleria|Autoantibody profile of children with juvenile<br>dermatomyositis from a tertiary care centre in north<br>India|2017|Annals of the<br>Rheumatic Diseases|
|230|Gupta|Myositis-specific and myositis-associated<br>autoantibodies in a large Indian cohort of inflammatory<br>myositis reveal novel clinicophenotypic patterns|2020|Annals of the<br>Rheumatic Diseases|
|231|Heiden|A characterisation of patients with Antisynthetase<br>Syndrome>|2019|European Respiratory<br>Journal|
|||Autoantibody profile in patients diagnosed with|||
|232|Hernández<br>Flórez|idiopathic inflammatory myopathy: multicenter registry<br>on inflammatory myositis from the rheumatology<br>society in madrid, spain|2017|Annals of the<br>Rheumatic Diseases|
|233|Ibarguengoiti<br>a|Descriptive analysis of a cohort of patients diagnosed<br>with inflammatory myositis in a tertiary hospital|2018|Annals of the<br>Rheumatic Diseases|
|234|Kaleda|Single center retrospective study of the juvenile<br>idiopathic inflammatory myopathies|2021|Pediatric Rheumatology|
|235|Karampitsako<br>s|Clinical features and outcomes of patients with myositis<br>associated-interstitial lung disease|2021|European Respiratory<br>Journal|
|||Juvenile dermatomyositis: Clinical features, laboratory|||
|236|Kasapcopur|findings, treatment modalities and disease course (a<br>single center experience)|2014|Pediatric Rheumatology|
|237|Loarce-<br>Martos|Clinical manifestations and comparison of subtypes of<br>juvenile idiopathic inflamatory myopathies: Data from<br>the remicam registry|2019|Arthritis and<br>Rheumatology|
|238|Lucchini|Myositis-specific Antibodies (MSA): High prevalence in<br>biopsy-proven myositis population|2017|Acta Myologica|
|239|Martins|Clinical and demographic characteristics of patients<br>with antisynthetase autoantibodies: Data from a<br>Portuguese tertiary outpatient clinic|2020|Annals of the<br>Rheumatic Diseases|
|240|Matos|Juvenile dermatomyositis: Clinical, laboratorial,<br>histological, therapeutical and evolutive parameters of<br>nine children|2018|Advances in<br>Rheumatology|
|241|Melo|First clinical analysis of myositis patients registered at<br>reuma.pt/myositis protocol: Data from a single-center|2021|Annals of the<br>Rheumatic Diseases|  
99  
|**Nº**|**Autores**|**Título**|**Ano**|**Revista**|
|---|---|---|---|---|
|242|Muñoz<br>Reinoso|Antisynthetase syndrome: Clinical profile, serologic and<br>treatments used in a cohort of patients followed at the<br>virgen macarena hospital|2021|Annals of the<br>Rheumatic Diseases|
|243|Nakashima|The relationship between autoantibodies and clinical<br>symptoms in patients with inflammatory myopathy|2018|Annals of the<br>Rheumatic Diseases|
|244|Oguz|Idiopathic inflammatory myopathies: Clinical<br>characteristics, survivial and poor prognostic factors of<br>110 patients from Turkey|2018|Annals of the<br>Rheumatic Diseases|
|245|Pinal-<br>Fernandez|Correlating muscle biopsy features with autoantibodies<br>in patients with dermatomyositis and the jo-1<br>antisynthetase syndrome|2014|Annals of the<br>Rheumatic Diseases|
|||Interstitial lung disease and polymyositis: Patients have||American Journal of|
|246|Rojas-Serrano|similar clinical manifestations although a heterogeneous<br>serologic profile and prognosis|2015|Respiratory and Critical<br>Care Medicine|
|247|So|Performance of the 2017 european league against<br>rheumatism/american college of rheumatology<br>(eular/acr) classification criteria for adult idiopathic<br>inflammatory myopathies in a hongkong cohort|2019|Annals of the<br>Rheumatic Diseases|
|248|Taborda|Retrospective analysis of the outcome of patients with<br>polymyositis and dermatomyositis|2013|Rheumatology (United<br>Kingdom)|
|||Clinical significance of myositis-specific autoantibody|||
|249|Temmoku|profiles in Japanese patients with<br>polymyositis/dermatomyositis.|2019|Medicine|
|250|Tjokrosaputro|Characteristics of anti-Jo 1 antibody positive<br>antisynthetase syndrome patients in Singapore|2020|International Journal of<br>Rheumatic Diseases|
|251|Tornero|A cohort of patients with antisynthetase syndrome<br>evaluated in a multidisciplinary consultation|2018|Annals of the<br>Rheumatic Diseases|
|252|Wong|Myositis-specific autoantibodies and their clinical<br>associations in idiopathic inflammatory myopathies.|2021|Acta<br>neurologicaScandinavic<br>a|  
100  
**Figura D.** Fluxograma com resultados de busca e seleção das revisões sistemáticas incluídas comparando pacientes com miopatias inflamatória anti-Jo1 positivo em relação à anti-Jo1 negativos.  
<!-- Start of picture text -->
Referancias identificadas em:<br>Baces de dados (n = 3) neferd idacantes<br>PubMed (n = 338) see dea Referéncias identificadas em:<br>Embase (n= 937) Proceso de sele cio: Busca manual {n =12}<br>Cochrane CENTRAL (n = 1) Puplicatas in =23)<br>Registros(n =1286)<br>Referéncias avaliadas por titulo peferencias excluidas<br>=inresume=1.263) (n=1.117)<br>Referéncias incluidas para Referéncias cujo texto completo<br>avaliacao por texto completo nfo fol identificado<br>(n=276) w=5)<br>Referénciascompleto avaliadas por texto -Referéncias Nao avalia populacSoexcluidas: (n=252) de interesse<br>in =970 (n=108)<br>+ Estudos que no avaliam<br>prognéstico e/ou caracteristicas<br>dinicas (n=19)<br>= Tipo de estudo (n=33)<br>- N3o avalia desfechos de interesse<br>Estudos induidos<br>- NSo é possivel extrair os resultados<br>18) na reviso (n = (n=43)<br>Busca manual (n=12) (n=2a)<br>Total (n=30)<br><!-- End of picture text -->  
**Fonte:** Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/<sup>4</sup> .

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Resumo das evidências -->
Foram incluídos 30 estudos onde foram avaliados os desfechos de interesse em pacientes com anti-Jo1 positivo em relação àqueles sem o anticorpo. Os delineamentos da maioria dos estudos eram coorte retrospectiva (n=15) ou estudos transversais (n=10). Dez dos estudos avaliados eram resumos de congressos, para os quais não foram localizados o texto completo. Dos desfechos de interesse, não foram encontrados estudos que avaliassem a síndrome antissintetase. As principais características dos estudos estão detalhadas no **Quadro AE** e, em sequência, estão descritos os resultados encontrados para cada um dos desfechos.  
**Quadro AE.** Características dos estudos incluídos na revisão sistemática  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**População (Subtipos de**<br>**miopatias)**|**Total de**<br>**pacientes com**<br>**miopatia**|**Desfechos avaliados**|
|---|---|---|---|---|
|**Ahn S, 2022**<sup>**24**</sup>|Coorte<br>retrospectiva|PM, DM|86|Mãos de mecânico<br>Fenômeno de Raynaud<br>Artrite<br>DPI<br>Remissão clínica<br>Mortalidade|  
101  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**População (Subtipos de**<br>**miopatias)**|**Total de**<br>**pacientes com**<br>**miopatia**|**Desfechos avaliados**|
|---|---|---|---|---|
|**Akashi K, 2015**<sup>**25 a**</sup>|Coorte<br>retrospectiva|PM, DM, DMA|88|Recidiva da doença|
|**Betteridge Z,**<br>**2019**<sup>**26**</sup>|Transversal|PM, DM|1637|Mão de mecânico<br>DPI<br>Fenômeno de Raynaud<br>Artrite|
|**Charles PJ, 2011**<sup>**27a**</sup>|Coorte prospectiva|PM, DM, DMJ, MCI,<br>MS|486|ILD|
|**Chen Z, 2018**<sup>**28a**</sup>|Coorte prospectiva|PM, DM, MAA|90|Mãos de mecânico|
|**de Andrade VP,**<br>**2021**<sup>**29**</sup>|Coorte<br>retrospectiva|DM|118|Mãos de mecânico<br>Comprometimento das<br>articulações<br>Acometimento pulmonar<br>DPI<br>Fenômeno de Raynaud<br>Vasculite<br>Recidiva da doença<br>Remissão clínica<br>Mortalidade|
|**Dei G, 2020**<sup>**30**</sup>|Coorte<br>retrospectiva|SAS|57|Mão de mecânico<br>Fenômeno de Raynaud<br>Comprometimento das<br>articulações<br>Fraqueza muscular|
|**Dobloug, 2014**<sup>**31**</sup>|Coorte<br>retrospectiva|DM, PM|230|Mãos de mecânico<br>Artrite|
|**Fang Y, 2012**<sup>**32**</sup>|Coorte<br>retrospectiva|PM, DM, PM/DMJ, MS,<br>MAA|151|Fraqueza muscular<br>Fenômeno de Raynaud<br>DPI<br>Artrite<br>Mortalidade|
|**Gómez GN, 2021**<sup>**33**</sup>|Transversal|PM, DM, MCI, SAS,<br>MAA, MNIM, MS|360|Mãos de mecânico<br>Fenômeno de Raynaud<br>Artrite<br>DPI|
|**Hochberg MC,**<br>**1984**<sup>**34**</sup>|Transversal|PM; DM; MS; MAA|76|Acometimento pulmonar|  
102  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**População (Subtipos de**<br>**miopatias)**|**Total de**<br>**pacientes com**<br>**miopatia**|**Desfechos avaliados**|
|---|---|---|---|---|
|**Huscher D, 2017**<sup>**35a**</sup>|Transversal|DM, PM, SAS, MS|142|Artrite<br>DPI|
|**Ji S, 2010**<sup>**36**</sup>|Coorte<br>retrospectiva|DM, PM, DMA|197|DPI|
|**Li S, 2019**<sup>**37**</sup>|Transversal|PM, DM|497|DPI|
|**Mielnik P, 2006**<sup>**38**</sup>|Coorte<br>retrospectiva|DM, PM|41|Mãos de mecânico<br>DPI<br>Artrite<br>Fenômeno de Raynaud|
|**Negalur NV,**<br>**2021**<sup>**39**</sup>|Transversal|PM; DM; DMJ; MS;<br>MAA|48|Mãos de mecânico<br>DPI<br>Artrite<br>Fenômeno de Raynaud<br>Fraqueza muscular|
|**Oddis CV, 1990**<sup>**40**</sup>|Coorte prospectiva|DM, PM e MS|180|DPI|
|**Pina Cruellas M,**<br>**2012**<sup>**41**</sup>|Transversal|PM, DM|222|Comprometimento das<br>articulações<br>Acometimento pulmonar|
|**Platteel, 2019**<sup>**42**</sup>|Coorte<br>retrospectiva|Não descreve|187|Fraqueza muscular<br>Comprometimento das<br>articulações<br>Acometimento pulmonar|
|**Rojas-Serrano J,**<br>**2014**<sup>**43a**</sup>|Coorte<br>retrospectiva|ASS|34|Mortalidade|
|**Sánchez Romo**<br>**SM, 2020**<sup>**44a**</sup>|Transversal|SAS; PM; DM|36|ILD|
|**Selva-O'Callachan**<br>**A, 2006**<sup>**45**</sup>|Coorte<br>retrospectiva|PM, DM, MCI|88|Mão de mecânico<br>Fenômeno de Raynaud<br>Artrite<br>DPI<br>Mortalidade|
|**Sohn B, 2019**<sup>**46a**</sup>|Coorte<br>retrospectiva|SAS|27|ILD|
|**Sreevilasan SK,**<br>**2021**<sup>**47**</sup>|Coorte prospectiva|SAS|28|Mãos de mecânico<br>Artrite<br>DPI<br>Mortalidade|  
103  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**População (Subtipos de**<br>**miopatias)**|**Total de**<br>**pacientes com**<br>**miopatia**|**Desfechos avaliados**|
|---|---|---|---|---|
|**Taniguchi M,**<br>**2017**<sup>**48a**</sup>|Coorte<br>retrospectiva|PM/DM|121|Mortalidade|
|**Váncsa A, 2010**<sup>**49**</sup>|Coorte<br>retrospectiva|PM, DM, OM|169|Mãos de mecânico<br>Artrite<br>DPI<br>Fenômeno de Raynaud|
|**Vojinovic T,**<br>**2020**<sup>**50a**</sup>|Transversal|SAS; PM; DM|52|DPI|
|**Yardimci GK,**<br>**2020**<sup>**51a**</sup>|Transversal|DM, PM|81|DPI|
|**Zampeli E, 2018**<sup>**52**</sup>|Coorte<br>retrospectiva|Não descreve|95|DPI|  
**Notas: a.** Resumos de congressos  
**Legenda:** DM: dermatomiosite; DMA: dermatomiosite amiopática; DMJ: dermatomiosite juvenil; DPI: Doença pulmonar intersticial; MAA: Miosite associada ao câncer; MCI: Miosite por corpos de inclusão; MNIM: Miopatia necrotizante imunomediada; MS: miosite de sobreposição; PM: polimiosite  
Os estudos observacionais de coorte incluídos foram avaliados com o instrumento NOS<sup>11</sup> . Todos os estudos foram avaliados como de baixa qualidade metodológica, principalmente por não terem realizado o controle da coorte para características importantes, como idade do paciente, tempo de diagnóstico, sexo, utilização de medicamentos, entre outros. Assim como, em nenhum estudo é possível afirmar que os desfechos de interesse não estavam presentes no início do estudo. A avaliação completa está apresentada no **Quadro AF** .  
Os estudos transversais incluídos foram avaliados com a ferramenta do _Joanna Briggs Institute_ (JBI)<sup>53</sup> . De forma geral, a maioria dos estudos apresentou moderada/boa qualidade metodológica, exceto quatro estudos que apresentaram limitações importantes. Em comum, pode-se verificar que os relatos desses quatro estudos estavam disponíveis apenas como resumo. A avaliação está apresentada no **Quadro AG** .  
104  
**Quadro AF.** Avaliação do risco de viés de estudos observacionais incluídos nesta síntese de evidências segundo a ferramenta NOS  
|||**SELEÇÃO**|||**COMPARABILIDADE**||**DESFECHO**|||
|---|---|---|---|---|---|---|---|---|---|
|**Estudos**|**Representatividade**<br>**do grupo exposto**<br>⋆|**Representatividade**<br>**do grupo não**<br>**exposto**<br>⋆|**Determinação**<br>**da exposição**<br>**ou**<br>**intervenção**<br>⋆|**Demonstração**<br>**de que o**<br>**desfecho de**<br>**interesse não**<br>**estava**<br>**presente no**<br>**início do**<br>**estudo**<br>⋆|**Comparabilidade das**<br>**coortes com base no**<br>**desenho do estudo ou**<br>**análise**<br>⋆⋆|**Avaliação**<br>**do**<br>**desfecho**<br>⋆|**Tempo de**<br>**acompanhamento**<br>**necessário para a**<br>**ocorrência do**<br>**desfecho**<br>⋆|**Adequação do**<br>**acompanhamento**<br>⋆|**Qualidade**|
|**Akashi K,**<br>**2015***|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆<sup>h</sup>|**Baixa**|
|**Charles PJ,**<br>**2011***|⋆<sup>a</sup>|Não pontua<sup>i</sup>|Não pontua<sup>j</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|Não<br>pontua<sup>j</sup>|Não pontua<sup>j</sup>|Não pontua<sup>j</sup>|**Baixa**|
|**Chen Z,**<br>**2018***|⋆<sup>a</sup>|Não pontua<sup>j</sup>|Não pontua<sup>j</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|Não<br>pontua<sup>j</sup>|Não pontua<sup>j</sup>|Não pontua<sup>j</sup>|**Baixa**|
|**de Andrade**<br>**VP, 2021**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆<sup>h</sup>|**Baixa**|
|**Dobloug,**<br>**2014**|Não pontua<sup>k</sup>|Não pontua<sup>k</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|Não pontua<sup>j</sup>|⋆|**Baixa**|
|**Mielnik P,**<br>**2006**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆|**Baixa**|
|**Oddis CV,**<br>**1990**|Não pontua<sup>k</sup>|Não pontua<sup>k</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|Não pontua<sup>j</sup>|⋆|**Baixa**|  
105  
|||**SELEÇÃO**|||**COMPARABILIDADE**||**DESFECHO**|||
|---|---|---|---|---|---|---|---|---|---|
|**Estudos**|**Representatividade**<br>**do grupo exposto**<br>⋆|**Representatividade**<br>**do grupo não**<br>**exposto**<br>⋆|**Determinação**<br>**da exposição**<br>**ou**<br>**intervenção**<br>⋆|**Demonstração**<br>**de que o**<br>**desfecho de**<br>**interesse não**<br>**estava**<br>**presente no**<br>**início do**<br>**estudo**<br>⋆|**Comparabilidade das**<br>**coortes com base no**<br>**desenho do estudo ou**<br>**análise**<br>⋆⋆|**Avaliação**<br>**do**<br>**desfecho**<br>⋆|**Tempo de**<br>**acompanhamento**<br>**necessário para a**<br>**ocorrência do**<br>**desfecho**<br>⋆|**Adequação do**<br>**acompanhamento**<br>⋆|**Qualidade**|
|**Rojas-**<br>**Serrano J,**<br>**2014***|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|Não pontua<sup>j</sup>|**Baixa**|
|**Sohn B,**<br>**2019***|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|Não pontua<sup>j</sup>|Não pontua<sup>j</sup>|**Baixa**|
|**Sreevilasan**<br>**SK, 2021**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆|**Baixa**|
|**Taniguchi**<br>**M, 2017***|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|Não pontua<sup>j</sup>|**Baixa**|
|**Platteel,**<br>**2019**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|Não pontua<sup>j</sup>|**Baixa**|
|**Ji S, 2010**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆<sup>h</sup>|**Baixa**|
|**Váncsa A,**<br>**2010**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆<sup>h</sup>|**Baixa**|
|**Fang Y,**<br>**2012**|Não pontua<sup>k</sup>|Não pontua<sup>k</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆<sup>h</sup>|**Baixa**|
|**Dei G, 2020**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆<sup>h</sup>|**Baixa**|  
106  
|**Estudos**|**Representatividade**<br>**do grupo exposto**<br>⋆|**SELEÇÃO**<br>**Representatividade**<br>**do grupo não**<br>**exposto**<br>⋆|<br>**Determinação**<br>**da exposição**<br>**ou**<br>**intervenção**<br>⋆|**Demonstração**<br>**de que o**<br>**desfecho de**<br>**interesse não**<br>**estava**<br>**presente no**<br>**início do**<br>**estudo**<br>⋆|**COMPARABILIDADE**<br>**Comparabilidade das**<br>**coortes com base no**<br>**desenho do estudo ou**<br>**análise**<br>⋆⋆|**Avaliação**<br>**do**<br>**desfecho**<br>⋆|**DESFECHO**<br>**Tempo de**<br>**acompanhamento**<br>**necessário para a**<br>**ocorrência do**<br>**desfecho**<br>⋆|<br>**Adequação do**<br>**acompanhamento**<br>⋆|**Qualidade**|
|---|---|---|---|---|---|---|---|---|---|
|**Ahn S, 2022**|Não pontua<sup>k</sup>|Não pontua<sup>k</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|Não pontua<sup>l</sup>|**Baixa**|
|**Zampeli E,**<br>**2018**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|Não pontua<sup>j</sup>|**Baixa**|
|**Selva-**||||||||||
|**O'Callachan**|⋆<sup>a</sup>|⋆<sup>b</sup>|⋆<sup>c</sup>|Não pontua<sup>d</sup>|Não pontua<sup>e</sup>|⋆<sup>f</sup>|⋆<sup>g</sup>|⋆<sup>h</sup>|**Baixa**|
|**A, 2006**||||||||||  
**Boa qualidade:** 3 ou 4 estrelas no domínio de seleção **E** 1 ou 2 estrelas no domínio de comparabilidade **E** 2 ou 3 estrelas no domínio de desfecho; **Qualidade razoável:** 2 estrelas no domínio de seleção **E** 1 ou 2 estrelas no domínio de comparabilidade **E** 2 ou 3 estrelas no domínio de desfecho; **Baixa qualidade:** 0 ou 1 estrela no domínio de seleção **OU** 0 estrelas no domínio de comparabilidade **OU** 0 ou 1 estrelas no domínio de desfecho. *Disponível como resumo a. Coorte de indivíduos com miopatias inflamatórias verdadeiramente representativa; b. Provenientes da mesma comunidade que a coorte exposta; c. Registro seguro (prontuários médicos ou registros eletrônicos); d. Não há demonstração de que o resultado de interesse não estava presente antes do início do estudo; e.não houve controle da coorte para características importantes; f. registros médicos; g. o seguimento foi suficiente para a ocorrência dos desfechos; h. Há descrição de perdas de seguimento com improvável introdução de viés; i. Coorte não exposta proveniente de uma comunidade diferente; j. sem descrição; k. sem descrição da derivação da coorte (a testagem do anticorpo foi realizada apenas para parte da coorte); l. significativa perda de seguimento sem descrição de motivos.  
107  
**Quadro AG.** Avaliação da qualidade metodológica dos estudos transversais incluídos nesta síntese de evidências segundo a ferramenta do _Joanna Briggs_ Institute (JBI)  
|**Estudo**|**1. Os critérios**<br>**de inclusão na**<br>**amostra foram**<br>**claramente**<br>**definidos?**|**2. Os sujeitos do**<br>**estudo e o**<br>**ambiente foram**<br>**descritos com**<br>**detalhamento?**|**3. A exposição foi**<br>**medida de forma**<br>**válida e**<br>**confiável?**|**4. Foram usados**<br>**critérios objetivos**<br>**e padronizados**<br>**para a medição**<br>**da condição?**|**5. Foram**<br>**identificados**<br>**fatores de**<br>**confusão?**|**6. Foram**<br>**estabelecidas**<br>**estratégias para**<br>**lidar com fatores**<br>**de confusão?**|**7. Os**<br>**resultados**<br>**foram**<br>**medidos de**<br>**forma válida e**<br>**confiável?**|**8. Foi usada**<br>**uma análise**<br>**estatística**<br>**apropriada?**|
|---|---|---|---|---|---|---|---|---|
|**Negalur NV, 2021**|Sim|Sim|Sim|Sim|Não|Não aplicável|Sim|Sim|
|**Pina Cruellas M,**<br>**2012**|Sim|Sim|Sim|Sim|Sim|Sim|Sim|Sim|
|**Gómez GN, 2021**|Não|Sim|Sim|Sim|Não|Não aplicável|Sim|Sim|
|**Vojinovic T, 2020***|Não|Não|Incerto|Incerto|Não|Não aplicável|Sim|Sim|
|**Betteridge Z, 2019**|Sim|Não|Sim|Sim|Não|Não aplicável|Sim|Sim|
|**Hochberg MC, 1984**|Não|Não|Sim|Sim|Sim|Não|Sim|Sim|
|**Huscher D, 2017***|Não|Não|Incerto|Incerto|Sim|Incerto|Sim|Sim|
|**Li S, 2019**|Sim|Sim|Sim|Sim|Sim|Sim|Sim|Sim|
|**Sánchez Romo SM,**<br>**2020**|Não|Não|Sim|Sim|Não|Não aplicável|Sim|Sim|
|**Yardimci GK, 2020***|Não|Não|Incerto|Incerto|Incerto|Incerto|Sim|Sim|  
**Legenda:** *Disponível como resumo  
108  
Os dados obtidos para os desfechos relacionados com as características clínicas dos pacientes (comprometimento das articulações, artrite, DPI, fraqueza muscular, mão de mecânico, comprometimento pulmonar, fenômeno de Raynaud, vasculite, e síndrome antissintetase) foram analisados usando o método Inverso da variância para fornecer o _odds ratio_ (OR), com intervalos de confiança de 95% (IC 95%). Para os desfechos relacionados com a taxa de remissão clínica e a taxa de resposta clínica, foi calculada a razão de taxas de incidência ( _incidence-rate ratios_ - IRR) e para o desfecho mortalidade foram considerados apenas os estudos que fizeram a análise de sobrevida utilizando o Kaplan Meier e Log Rank test. Se o estudo forneceu dados suficientes, ele foi incluído na meta-análise. Independentemente da natureza dos dados, o modelo de efeitos aleatórios foi usado para agrupar os dados. A heterogeneidade estatística foi detectada com a estatística _I_<sup>2</sup> e teste Q de Cochran. Se alta heterogeneidade fosse detectada, uma análise de sensibilidade era realizada excluindo resultados de estudos que avaliaram especificamente apenas pacientes com síndrome antissintetase. Quando não possível realizar a meta-análise dos dados, foi realizada uma descrição narrativa dos resultados relatados para o desfecho. Os dados foram analisados usando o software estatístico do R Studio.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_- Mão de mecânico_** -->
Dados sobre a chance de apresentar mão de mecânico foram obtidos para 12 estudos, avaliando um total de 526 pacientes com anti-Jo1 positivo e 1933 pacientes com anti-Jo1 negativo<sup>24,26,28-31,33,38,39,44,47,49</sup> . Dois desses estudos não foram utilizados na meta-análise por não apresentarem dados suficientes para a síntese<sup>33,44</sup> . Na análise pelo modelo de efeitos aleatórios, a presença do anticorpo foi associada a um odds ratio aumentado de apresentar mão de mecânico (OR = 5,33; IC de 95% = 2,70 a 10,53), representado na **Figura E-A** . Ainda, quando comparados pacientes com miopatias anti-Jo1 positivo com aqueles anti-Jo1 negativos, 95% dos odds ratio a serem estimados estão localizados entre 0,75 e 38,00 (intervalo preditivo). Na análise considerando os 10 estudos incluídos, houve evidência de heterogeneidade estatística: I<sup>2</sup> = 63%, p<0,01 ( **Figura E-A** ).  
Quando excluídos os estudos que avaliaram apenas pacientes com síndrome antissintetase, há uma redução da heterogeneidade estatística (I<sup>2</sup> =46%; p=0,10) e um aumento do odds ratio para 7,73 (IC de 95% = 4,21 a 14,20) de apresentar mão de mecânico, com intervalo preditivo variando entre 1,72 e 34,70 ( **Figura E-B** ).  
109  
**Figura E.** Comparação de pacientes com miopatias inflamatórias anti-Jo1 positivos versus pacientes anti-Jo1 negativos – **Desfecho: mãos de mecânico** . **A)** Total dos estudos que avaliaram o desfecho  
**B)** Estudos que avaliaram o desfecho excluindo aqueles que avaliaram apenas pacientes com síndrome antissintetase.  
<!-- Start of picture text -->
A)<br>Weight Weight<br>Autor, ano Anti-Jo1(+) Anti-Jot(-) Odds Ratio OR — 95%-Cl (common) (random)<br>Dei , 2020 32 25 d 0.76 (0.14; 4.08] 36% 9.0%<br>Mielnik , 2006 14 27 9 0.96 (0.08; 11.58] 17% 5.4%<br>SreevilasanAbn , 2022 ,2021 207 471 /: 1351.63 (0.25;(0.29; 10.51]6.23] 44%3.0% 10.0%8.0%<br>Dobloug , 2015 65 139 i 448 (230; 873] 233% 16.8%<br>Betteridge , 2019 306 1331 = 885 [564; 1388] 51.0% 18.4%<br>Chen , 2018 26 64 —i+— 15.03 [1.67; 134.98] 22% 6.5%<br>deVanesa Andrade , 2021 10 108 3+— 17.42 (3.94; 74.44) 48% 10.4%<br>Negalur ,, 20212010 315 13843 —}+—4 — 23573088 [3.12;(4.72; 117.59]305.87] 2.0%40% 6.1%9.5%<br>Common effect model 526 1933 5g 6.47 [4.69; 8.93] 100.0% -<br>Random effects model > 5.33 (2.70; 10.53] = 100.0%<br>Prediction interval 10.75; 38.00]<br>Heterogeneity: /? = 63%, x? = 0.6048, p < 0.01<br>001 01 1 10 100<br><!-- End of picture text -->  
<!-- Start of picture text -->
B)<br>Weight Weight<br>Autor, ano Anti-Jot(+) Anti-Jot(-) Odds Ratio OR —_-95%-Cl (common) (random)<br>Mielnik , 2006 14 27 t 0.96 [0.08; 11.63] 18% 5.1%<br>Ahn, 2022 20 47 1.63 (0.25; 10.58] 33% 8.1%<br>Dobloug , 2015 65 139 ad 450 (231; 875] 25.7% 24.4%<br>Betteridge , 2019 306 1331 m 881 (5.59, 13.89] 55.0% 28.8%<br>Chen, 2018 26 64 —-— 15000 (1.66; 135.79] 23% 6.2%<br>de Andrade , 2021 10 108 -— 17.05 (3.91; 74.25) 53% 11.4%<br>Vanesa , 2010 31 138 $+ — 23.64 (4.72, 118.42] 44% 10.1%<br>Negalur , 2021 5 a3 + 30.75 [3.13; 301.80] 22% 5.9%<br>Common effect model 477 1897 > 7.58 (5.41; 10.62] 100.0% -<br>Random effects model <> 7.73 (4.21; 14.20] ~- 100.0%<br>Prediction interval —_— (1.72; 34,70]<br>Heterogeneity: /? = 46%, x” = 0.2804, p = 0.07<br>001 01 1 10 100<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_- Comprometimento das articulações/artrite_** -->
Dados sobre a chance de apresentar comprometimento das articulações/artrite foram obtidos para 15 estudos, avaliando um total de 659 pacientes com anti-Jo1 positivo e 2341 pacientes com anti-Jo1 negativo<sup>24,26,29-32,35,38,39,41,42,47,49</sup> . Dois desses estudos não foram utilizados na meta-análise por não apresentarem dados suficientes para a síntese<sup>33,45</sup> . A **Figura F-A** aponta que a presença do anticorpo anti-Jo1 foi associada a um _odds ratio_ aumentado de apresentar comprometimento das articulações (OR = 2,99; IC de 95% = 2,13 a 4,20), em uma análise pelo modelo de efeitos aleatórios. Quando comparados pacientes com miopatias anti-Jo1 positivo com aqueles anti-Jo1 negativos, 95% dos _odds ratio_ a serem estimados estão localizados entre 1,19 e 7,50 (intervalo preditivo). Na análise considerando os 13 estudos incluídos, houve evidência de heterogeneidade estatística: _I_<sup>2</sup> = 52%, _p_ =0,01.  
Quando excluídos os estudos que avaliaram apenas pacientes com síndrome antissintetase, apesar de menor, há ainda evidência de heterogeneidade estatística ( _I_<sup>2</sup> =47%; _p_ =0,04). Para esses estudos, a presença do anticorpo foi associada a um _odds ratio_ de OR=3,30 (IC de 95% = 2,39 a 4,56) de apresentar comprometimento de articulações/artrite, com intervalo preditivo variando entre 1,46 e 7,45 ( **Figura F-B** ).  
110

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_- Comprometimento das articulações/artrite_** -->
**A)** Total dos estudos que avaliaram o desfecho **B)** Estudos que avaliaram o desfecho excluindo aqueles que avaliaram apenas pacientes com síndrome antissintetase.  
<!-- Start of picture text -->
A) Autor, ano AntiJot(+) AntiJot(-) Odds Ratio OR —95%-Cl (common)Weight (random)Weight<br>Dei , 2020 32 25 § 0.59 (0.16; 2.20] 18% 5.0%<br>Ahn , 2022 20 47 : 1.01 (0.23, 437] 14% 43%<br>Sreevilasan , 2021 17 11 é 1.04 [0.14 748] 08% += 2.6%<br>Platte! , 2019 19 168 : 218 [0.82579] 33% 7.7%<br>Betteridge , 2019 306 1331 = 240 [1.79, 3.22] 36.1% 18.0%<br>Pina Cruelias 2013, 42 180 # 240 [1.79; 322] 36.1% 18.0%<br>Huscher<br>Fang , 2012,2017 8 9 531 aa a¢ 3. 1857 (0.84;[128,789]15.15] 37%1.5% 8.3%44%<br>Vanesa , 2010 cy] 138 t+ —-478 (211; 1083] 46% = 9.4%<br>Negalur , 2021 5 43 * 4.95 (0.72; 33.90] 0.8% 27%<br>Dobloug , 2015 65 139 f—— 7.50 [3.88;1451] 7.1% += 11.6%<br>Mielnik<br>de Andrade,2006, 2021 1 04 10827 ++ 871782 [1. 84,75; 34 43 . 1820 ] 1 24 % 4337 %<br>Common effect model 659 2341 ¢ 2.71 [2.27; 323] 100.0% 7<br>Random effectsmodel <> 2.99 [2.13; 4.20] — 100.0%<br>Prediction interval —_ [1.19; 7.50]<br>Heterogeneity: 1° = 52%, x° = 0.1443, p = 0.01<br>01 0512 10<br><!-- End of picture text -->  
<!-- Start of picture text -->
B)<br>Weight Weight<br>Autor, ano Anti-Jo1(+) Anti-Jot(-) Odds Ratio OR —_ 95%-Cl (common) (random)<br>Ahn , 2022 20 47 # 1.01 [023,437] 15% 4.1%<br>Platte! , 2019 19 168 : 2.18 0.82; 579] 33% 7.7%<br>Betteridge , 2019 306 1331 = 2.40 [1.79, 3.22] 37.1% = 21.6%<br>Pina Cruellas<br>Huscher , 2013 42 180 4 240 [1.79, 322] 37.1% 21.6%<br>Fang , 2012, 2017 8 9 53a oa a 3. 1857 (0.84;15.15[1.28 789 ] 3815 % = 84 . 52 %<br>Vanesa , 2010 31 138 q+— 478 [2.11;1083] 48% = 9.8%<br>Negalur ,2021 5 43 it 4.95 [0.72;33.90] 09% 25%<br>Dobloug , 2015 65 139 H—— 7.50 [3881451] 7.3% © 12.5%<br>Mielnik<br>de Andrade,2006, 2021 1 04 10827 + +8717.92 [1. 7584 ; 43203418 ] 1 52 %  == 43 . 15 %<br>Common effect mode! 610-2305 4 2.81 [23; 3.35] 100.0% -<br>Random effects model > 3.30 [2.39; 4.56] ~ 100.0%<br>Prediction interval —_— 11.46; 7.45]<br>Heterogeneity: !? = 47%, x° = 0.1024,p = 0.04 01 0512 10<br><!-- End of picture text -->  
- **_Acometimento pulmonar_**  
Dados sobre o risco de apresentar acometimento pulmonar foram obtidos para quatro estudos, avaliando um total de 81 pacientes com anti-Jo1 positivo e 490 pacientes com anti-Jo1 negativo<sup>29,34,41,42</sup> . Na análise pelo modelo de efeitos aleatórios, a presença do anticorpo foi associada a uma maior chance de apresentar acometimento pulmonar (OR=4,13; IC de 95% = 2,76 a 6,17) nos estudos avaliados, com intervalo preditivo localizado entre 1,18 e 14,39 ( **Figura G** ). Não foi encontrada evidência de heterogeneidade estatística ( _I_<sup>2</sup> =19%; _p_ =0,30).  
**Figura G.** Comparação de pacientes com miopatias inflamatórias anti-Jo1 positivos versus pacientes anti-Jo1 negativos – **Desfecho: acometimento pulmonar.**  
<!-- Start of picture text -->
Weight Weight<br>Autor, ano AntiJot(+) AntiJot(-) Odds Ratio OR —_-95%-CI (common) (random)<br>de Andrade, 2021 10 108 # 327 [246,435] 836% 66.0%<br>Hochberg , 1984 10 u —-—— 580 [122;2763] 28% 62%<br>Piattee! , 2019 19 168 ++— 651 239,1777] 67% 138%<br>Pina Cruellas 2013 42 180 —t-+— 680 [2521835] 69% 14.0%<br>‘Common effect model 81 490 < 3.66 (2.82; 4.75) 100.0% -<br>Random effects model! > 413 (276; 6.17] ~- 100.0%<br>Prediction interval — 11.18; 14.39]<br>Heterogeneity: = 19%, +7 = 0.0424, p = 0.30<br>01 0512 10<br><!-- End of picture text -->  
111

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **-** **_Doença Pulmonar Intersticial (DPI)_** -->
Para o desfecho DPI, três estudos elegíveis na revisão sistemática não foram utilizados na meta-análise por não apresentarem dados de pacientes anti-Jo1 negativos com o desfecho avaliado<sup>33,36,45</sup> . Dados sobre a chance de apresentar DPI de acordo com a presença ou não do anticorpo anti-Jo1 foram, então, obtidos para 17 estudos, avaliando um total de 660 pacientes com anti-Jo1 positivo e 2.901 pacientes anti-Jo1 negativo<sup>24,26,27,29,32,35,37-40,44,46,47,49-52</sup> . Na análise pelo modelo de efeitos aleatórios, a presença do anticorpo foi associada a uma maior chance de apresentar DPI (OR= 5,27; IC de 95% = 2,97 a 9,37) nos estudos avaliados ( **Figura H-A** ). Ainda, espera-se que 95% dos _odds ratios_ a serem estimados estejam localizados entre 0,61 e 45,79. Houve evidência de heterogeneidade estatística ( _I_<sup>2</sup> =82%, _p_ <0,01).  
_Quando excluídos os estudos que avaliaram apenas a síndrome antissintetase, a análise seguiu apresentando heterogeneidade estatística (_ I<sup>_2_</sup> _=81%;_ p _<0,01), com OR de 6,72 (IC de 95% =3,86 a 11,70) e intervalo preditivo variando entre 0,91 e 49,42 (_ **_Figura H-B_** _)._

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **-** **_Doença Pulmonar Intersticial (DPI)_** -->
**A)** Total dos estudos que avaliaram o desfecho  
**B)** Estudos que avaliaram o desfecho excluindo aqueles que avaliaram apenas pacientes com síndrome antissintetase.  
<!-- Start of picture text -->
A)<br>Weight Weight<br>Autor, ano Anti-Jo1(+) AntiJot(-) Odds Ratio OR '95%-Cl (common) (random)<br>Sreevilasan , 2021 7 1" i 0.18 (002; 180] 08% 37%<br>Sohn , 2019 15 12 d 0.25 [002 261] 07% 36%<br>Yardimei , 2021 ‘| 158 1.03; 243} 214% 8.7%<br>Zampeli , 2019 21 14 a 272 (0.97; 7.59] 3.8% 71%<br>‘Abn , 2022 20 47 + 292 [098 872] 33% 68%<br>Huscher<br>Fang , 2012, 2017 8 9 153 ++ 5 8975 (2[1 33, . 44; 26011358 ] 5418 % 75 . 67 %<br>Vanesa , 2010 3 138 + 596 (260, 1370] 58% 7.7%<br>Vojinovic , 2020 610 [1.00, 3721] 12% 48%<br>Sanchez Romo , 2020 1 35 7 7.29 (0.27; 193.68} 0.4% 23%<br>Oddis , 1990 18 79 = 853 (276, 2641] 31% 67%<br>Charles 2011 61 425 i 1025 [5.77, 1822] 120% 8.4%<br>Li, 2019 43 4a7 —_ 11.11 [331 3734] 27% «6.5%<br>Betteridge , 2019 3061331 i 13.80 (984, 1936] 348% 8.8%<br>Mielnik , 2006 14 27 + 14.40 [284; 7302] 15% 5.3%<br>Negalur , 2021 5 43 ——— 20.57 [1.99; 212.72] 0.7% 3.6%<br>de Andrade , 2021 10 108 “+ 59.32 [3.37; 1045.13] 0.5% 2.8%<br>Common effect model 660 = 2901 ® 6.15 (5.03; 7.51] 100.0% =<br>Random effects model a 527 [297; 937] ~ 100.0%<br>Prediction interval 10.61; 45.79]<br>Heterogeneity: I? = 82%. 1° = 0.9422 0 <0.01<br><!-- End of picture text -->  
<!-- Start of picture text -->
B) Weight Weight<br>‘Autor, ano Anti-Jo1(+) AntiJot(-) ‘Odds Ratio OR 95%-Cl (common) (random)<br>Yardimci , 2021 j 158 [1.03; 243] 21.7% 9.8%<br>Zampeli_, 2019 21 74 272 097, 759] 38% 7.7%<br>Abn , 2022 20 47 t 292 [098 872] 34% 74%<br>Huscher , 2017 89 53 + 575 (2.44; 1358] 55% 83%<br>Fang , 2012 9 rl —— 5.89 [1.33; 2601] 18% 5.9%<br>Vanesa , 2010 34 138 a 596 [260; 1370] 59% 84%<br>Vojinovic , 2020 6.10 [1.00, 3721] 12% 4.9%<br>Sanchez Romo , 2020 1 35 + 7.29 (0.27; 19368] 04% 22%<br>Oddis , 1990 18 79 a 853 (276; 2641] 32% 7.2%<br>Charles , 2011 61 425 * 10.25 [5.77, 1822] 122% 93%<br>Li 2019 43 447 j— 11.11 (331, 3734] 28% «= 6.9%<br>Betteridge , 2019 306 1331 | 13.80 (9.84; 1936] 35.3% 10.0%<br>Mielnik , 2006 14 27 — 14.40 [284; 73.02] 15% 5.5%<br>Negalur, 2021 5 43 —+— 2057 11.99; 21272] 07% 37%<br>de Andrade , 2021 10 108 ++ 59.32 [3.37;1045.13] 05% = 27%<br>Common effect model 628-2878 5] 6.47 [5.29; 7.91] 100.0% -<br>Random effects model < 6.72 [3.86; 11.70] 100.0%<br>Prediction interval [0.91; 49.42]<br>Heterogeneity: /? = 81%, 1? = 0.7727, p <0.01<br>0001 01 1 10 1000<br><!-- End of picture text -->  
112

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **-** **_Fenômeno de Raynaud_** -->
Dois estudos elegíveis na revisão sistemática não foram utilizados na meta-análise, por não apresentarem dados de pacientes anti-Jo1 negativos com o desfecho avaliado<sup>33,45</sup> . Dados sobre a chance de apresentar o fenômeno de Raynaud foram obtidos para oito estudos<sup>24,26,29,30,32,38,39,49</sup> , avaliando um total de 427 pacientes com anti-Jo1 positivo e 1.790 pacientes anti-Jo1 negativo. Na análise pelo modelo de efeitos aleatórios, a presença do anticorpo foi associada a uma maior chance de apresentar o fenômeno de Raynaud (OR =2,29; IC de 95% =1,47 a 3,56) nos estudos avaliados ( **Figura I** ). Ainda, espera-se que 95% dos _odds ratios_ a serem estimados estejam localizados entre 0,96 e 5,44 (intervalo preditivo). Não houve evidência de heterogeneidade estatística ( _I_<sup>2</sup> =18%, _p_ =0,29).  
**Figura I** . Comparação de pacientes com miopatias inflamatórias anti-Jo1 positivos versus pacientes anti-Jo1 negativos – **Desfecho: fenômeno de Raynaud**  
<!-- Start of picture text -->
Weight Weight<br>Autor, ano AntiJot(*) AntiJot(-) Odds Ratio OR 95%-Cl (common) (random)<br>Fang, 2012 9 m1 t 116 (022, 622} 31% 63%<br>Vanesa ,2010 1 138 1 158 [072 346] 142% 21.9%<br>Betteridge , 2019 6 1331 = 230 [162 326) 713% 48.3%<br>Dei , 2020 32 25 + 243 (009, 6219] 08% 18%<br>Negalur, 2021 5 43 252 (036, 1742] 23% 4.9%<br>Abn , 2022 20 47 t 269 (060, 1205] 39% 78%<br>de Andrade , 2021 10 108 7 297 (060, 1464) 3.4% = 6.9%<br>Mielnik , 20068 14 27 | ———— 128.33 (634; 259578] 10% = 21%<br>Common effect model 4271790 % 226 (1.68; 3.03] 100.0% -<br>Random effects model ° 229 [1.47; 3.56) = 100.0%<br>Prediction interval (0.96; 5.44)<br>Heterogenedy: 1° = 18%, 1° = 0.0741, p=0.29<br>0001 01 1 10 1000<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_- Vasculite_** -->
Apenas um estudo avaliou a presença de vasculite<sup>29</sup> . Ele envolveu apenas pacientes com dermatomiosite. Nenhum dos 10 pacientes anti-Jo1 positivo avaliados apresentou o desfecho e 37 de 108 pacientes anti-Jo1 negativo apresentaram o desfecho.

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **-** **_Fraqueza muscular_** -->
Dados sobre a chance de apresentar fraqueza muscular foram obtidos para quatro estudos<sup>30,32,39,42</sup> , observando um total de 65 pacientes com anti-Jo1 positivo e 307 pacientes anti-Jo1 negativo. Na análise pelo modelo de efeitos aleatórios, a presença do anticorpo não foi associada a uma maior chance de apresentar fraqueza muscular (OR=1,07; IC de 95%= 0,46 a 2,52) nos estudos avaliados, mesmo quando excluído o estudo que avaliava apenas pacientes com síndrome antissintetase ( **Figura J** ).  
113  
**Figura J.** Comparação de pacientes com miopatias inflamatórias anti-Jo1 positivos versus pacientes anti-Jo1 negativos – **Desfecho: Fraqueza muscular.**  
**A)** Total dos estudos que avaliaram o desfecho  
**B)** Estudos que avaliaram o desfecho excluindo aqueles que avaliaram apenas pacientes com síndrome antissintetase.  
<!-- Start of picture text -->
A) Weight Weight<br>Autor, ano Anti-Jo1(+) AntiJot(-) Odds Ratio OR —_95%-CI (common) (random)<br>Negalur, 2021 5 423 0.10 [0.00; 1.83) 74% 8.1%<br>Fang , 2012 9 71 0.68 (0.03; 15.34] 6.7% 74%<br>Platte! , 2019 19 168 i 1.16 (0.32; 4.23] 38.7% 38.6%<br>Dei , 2020 32 25 1.66 (0.51; 5.36] 472% 45.9%<br>Common effect model 65 307 1.10 [0.49; 246] 100.0% =<br>Random effects model 1.07 (0.46; 2.52] = 100.0%<br>Prediction interval (0.13; 8.99]<br>Heterogeneity: /° = 6%, x” = 0.0548, p = 0.36 001 01 1 10 100<br>B)<br>Weight Weight<br>Autor, ano Anti-Jo1(+) Anti-Jo1(-) Odds Ratio OR 95%-Cl (common) (random)<br>Negalur, 2021 5 43 4 0.10 (0.00; 183] 141% 17.7%<br>Fang , 2012 9 1 068 (0.03; 1534] 127% 16.1%<br>Platte! 2019 19 168 Ss 116 (032; 423] 733% 66.2%<br>CommonRandom effecteffects modelmodel 3 282 : 0.760.68 (0.25;(0.19; 231]252] 100.0%~ 100.0%-<br>Prediction interval 10.00; 23360.27]<br>Heterogeneity: /? = 13%, +? = 0.2320, p = 0.32<br>0.001 011 10 1000<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **-** **_Resposta clínica_** -->
A resposta clínica avalia a ausência de atividade da doença com o uso de terapia medicamentosa. O estudo publicado de Andrade (2021)<sup>29</sup> foi o único que avaliou esse desfecho, relatando que dois dentre 10 pacientes anti-Jo1 positivo tiveram resposta clínica em seis meses de tratamento, comparado com 32 dos 108 pacientes anti-Jo1 negativos. Os autores não encontraram diferença estatisticamente significante entre os dois grupos (p= 0,722).  
- **_Remissão clínica_**  
Em dois estudos foi relatado o desfecho remissão clínica, que avalia a ausência de atividade da doença sem o uso de terapia medicamentos<sup>24,29</sup> . Na análise pelo modelo de efeitos aleatórios, a razão de taxas de incidência ( _incidence-rate ratios_ - IRR]) obtida para os estudos foi de 0,42 (IC 95% de 0,15 a 1,13), sem evidência de diferença estatística entre pacientes anti-Jo1 positivos e anti-Jo1 negativos ( **Figura K** ).  
**Figura K.** Comparação de pacientes com miopatias inflamatórias anti-Jo1 positivos versus pacientes anti-Jo1 negativos – Desfecho: **remissão clínica**  
<!-- Start of picture text -->
Study E xperimentalvents Time EventsControlTime IncidenceRatio Rate IRR 95%-Cl (common)Weight (random)Weight<br>de Andrade 2021 0 6 36 648 : 0.14 (001;228) 35.1% 127%<br>Abn 2022 4 156 = 22 420 4 0.49 (0.17,142] 649% 87.3%<br>Common effect model S<br>Random effects mode! 0.320.42 (0.18;0.11; 0.93}1.13} 100.0%= 100.0%-<br>Heterogeneity: F = 0%, 1° =0,p =0.41 oor of 1 10 100<br><!-- End of picture text -->  
114

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **_- Mortalidade_** -->
Embora oito estudos avaliassem a mortalidade de pacientes anti-Jo1 positivos em relação àqueles pacientes sem o anticorpos<sup>24,29,32,43,45,47,48</sup> , apenas três deles fizeram analise de sobrevida utilizando método de Kaplan Meier e Log Rank test 32,43,48. No estudo publicado por Rojas-Serrano J (2014)43, houve diferença entre os dois grupos na análise de sobrevida, porém a população anti-Jo1 positivo e anti-Jo1 negativo possuíam medianas de idade muito diferentes (48 (IQR: 39-54) anos versus 62 (IQR: 51-69) anos, respectivamente), impossibilitando a interpretação dos resultados. Na análise de sobrevida relatada por Fang Y (2012)<sup>32</sup> , os dois grupos não apresentam diferença estatisticamente significante (p=0,201), mas foi considerada apenas um pouco mais de metade da coorte total do estudo (n=80/151) para a condução da análise. Na análise univariada apresentada por Taniguchi M (2017)<sup>48</sup> , o Hazard ratio (HR) foi de 0,33 (IC95% de 0,78 a 0,99; p=0,048) e, na multivariada, não foi observada diferença entre os grupos com HR= 0,37 (IC95% 0,02 a 1,84; p=0,13). Considerou-se que os dados não eram suficientes para a condução de uma meta-análise.  
Para avaliar a confiança na evidência analisada, foi aplicado o sistema da abordagem GRADE<sup>1</sup> . Foram avaliados apenas os desfechos primários, como apresentado no **Quadro AH** .  
115  
**Quadro AH.** Avaliação da certeza da evidência  
|||**Avaliaçã**|**o da certeza**|**da evidência**|||||**Sumário de Result**|**ados**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Participantes**<br>**(estudos)**<br>**Seguimento**<br>**Comprometime**|**Risco de**<br>**viés**<br>**nto das ar**|<br>**Inconsistência**<br>**ticulações/artrite**|**Evidência**<br>**indireta**<br>|**Imprecisão**|**Viés de**<br>**publicação**|**Certeza**<br>**geral da**<br>**evidência**|**Taxas de**<br>**estud**<br>**Com Anti-**<br>**Jo1 negativo**|**eventos do**<br>**o (%)**<br> <br>**Com Anti-**<br>**Jo1 positivo**|**Efeito relativo**<br>**(95% IC)**|**Efeitos abso**<br>**Risco com**<br>**Anti-Jo1**<br>**negativo**|**lutos potenciais**<br>**Diferença de**<br>**risco com Anti-**<br>**Jo1 positivo**|
|3000<br>(13<br>estudos<br>observacionais)<br>**Doença Pulmon**|<br>grave<sup>a</sup><br>**ar Interst**|não grave<sup>b</sup><br>**icial (DPI)**|não grave|grave<sup>c</sup>|nenhum|⨁◯◯◯<br>Muito baixa|481/2341<br>(20.5%)|260/659<br>(39.5%)|OR<br>2.99<br>(2.13 para 4.20)|<br>205<br>por<br>1.000|<br>**231 mais por**<br>**1.000**<br>(de<br>150<br>mais<br>para 315 mais)|
|3561<br>(17<br>estudos<br>observacionais)<br>**Fraqueza musc**|<br>grave<sup>a</sup><br>**ular**|grave<sup>d</sup>|não grave|grave<sup>c</sup>|nenhum|⨁◯◯◯<br>Muito baixa|164/2901<br>(5.7%)*|186/660<br>(28.2%)*|OR<br>5.27<br>(2.97 para 9.37)|<br>57 por 1.000|**183 mais por**<br>**1.000**<br>(de 95 mais para<br>303 mais)|
|372|grave<sup>a</sup>|não grave<sup>e</sup>|não grave|grave<sup>f</sup>|nenhum|⨁◯◯◯|186/307|31/65|OR<br>1.07|<br>606<br>por|<br>**16**<br>**mais**<br>**por**|
|(4<br>estudos<br>observacionais)||||||Muito baixa|(60.6%)|(47.7%)|(0.46 para 2.52)|1.000|**1.000**<br>(de 192 menos<br>para 189 mais)|  
**Resposta clínica**  
116  
|||**Avaliaçã**|**o da certeza**|**da evidência**|||**S**|**umário de Result**|**ados**||
|---|---|---|---|---|---|---|---|---|---|---|
|**Participantes**<br>**(estudos)**<br>**Seguimento**|**Risco de**<br>**viés**|<br>**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|<br>**Viés de**<br>**publicação**|**Certeza**<br>**geral da**<br>**evidência**|**Taxas de eventos do**<br>**estudo (%)**<br>**Com Anti-**<br>**Jo1 negativo**<br>**Com Anti-**<br>**Jo1 positivo**|**Efeito relativo**<br>**(95% IC)**|**Efeitos abso**<br>**Risco com**<br>**Anti-Jo1**<br>**negativo**|**lutos potenciais**<br>**Diferença de**<br>**risco com Anti-**<br>**Jo1 positivo**|
|118|grave<sup>g</sup>|grave<sup>h</sup>|não grave|grave<sup>i</sup>|nenhum|⨁◯◯◯|Apenas o estudo publicado p|or de Andrade av|aliou este desfe|cho. Entre os dez|
|(1<br>estudo||||||Muito baixa|pacientes anti-Jo1 positivos, d|ois apresentaram|resposta clínica|em seis meses de|
|observacional)|||||||tratamento, comparado com 3<br>autor, não foi encontrada difer|2 dos 108 pacient<br>ença estatisticam|es anti-Jo1 neg<br>ente significant|ativos. Segundo o<br>e.|

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **Remissão clínica** -->
|185|grave<sup>j</sup>|não grave|não grave|grave<sup>k</sup>|nenhum|⨁◯◯◯|60/155|4/30|Razão de taxas|387|por<br>**420 por 1000**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|(2<br>estudos||||||Muito baixa|||0.42|1.000|**paciente(s) por**|
|observacionais)|||||||||(0.15 para 1.13)||**mês**<br>(de<br>150<br>para<br>1130--)|  
**Mortalidade**  
117  
|||**Avaliaçã**|**o da certeza**|**da evidência**|||**S**|**umário de Result**|**ados**||
|---|---|---|---|---|---|---|---|---|---|---|
|**Participantes**<br>**(estudos)**<br>**Seguimento**|**Risco de**<br>**viés**|<br>**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|**Certeza**<br>**geral da**<br>**evidência**|**Taxas de eventos do**<br>**estudo (%)**<br>**Com Anti-**<br>**Jo1 negativo**<br>**Com Anti-**<br>**Jo1 positivo**|**Efeito relativo**<br>**(95% IC)**|**Efeitos abs**<br>**Risco com**<br>**Anti-Jo1**<br>**negativo**|**olutos potenciais**<br>**Diferença de**<br>**risco com Anti-**<br>**Jo1 positivo**|
|235<br>(3<br>estudos|<br>grave<sup>j</sup>|grave<sup>l</sup>|não grave|grave<sup>l</sup>|nenhum|⨁◯◯◯<br>Muito baixa|No estudo publicado por Roj<br>de pacientes anti-Jo1 positiv|as-Serrano J (201<br>o e anti-Jo1 nega|4) houve difer<br>tivo na anális|ença entre o grupo<br>e de sobrevida, no|
|observacionais)|||||||entanto esses grupos pos<br>impossibilitando a interpretaç<br>relata que os dois grupos não<br>porém foi considerada apenas<br>(n=80/151) para a condução<br>Taniguchi M (2017), o_Haza_<br>p=0,048) e, na multivariada,<br>HR= 0,37 (IC95% 0,02 a 1,84|suíam medianas<br>ão dos resultados.<br>apresentam difere<br>um pouco mais d<br>da análise. E na a<br>_rd ratio_(HR) foi<br>não foi observad<br>; p=0,13).|de idade<br>Enquanto o est<br>nça estatistica<br>e metade da co<br>nálise univaria<br>de 0,33 (IC95<br>a diferença en|muito diferentes,<br>udo Fang Y (2012)<br>mente significante,<br>orte total do estudo<br>da apresentada por<br>% de 0,78 a 0,99;<br>tre os grupos com|  
**IC:** Intervalo de confiança; **OR:** _Odds ratio_  
*Dois estudos (Yardimci e Vojinovic) não forneceram n de pacientes com a característica, eles forneceram dados em OR ou RR.  
a. A maioria dos estudos que forneceram resultados para esse desfecho apresentaram limitações e foram avaliados como de baixa qualidade metodológica. B. Apesar da presença de considerável heterogeneidade (I2=52%), um valor de p que indica uma variabilidade na estimativa maior do que a esperada ao acaso e alguns estudos apresentarem estimativas individuais que englobam a nulidade, em geral, a maioria dos IC se sobrepõem. C. Apesar da estimativa sumária não cruzar a nulidade, há grande amplitude no intervalo de confiança. D. Alta heterogeneidade (I<sup>2</sup> =82%), com valor de p menor que 0,01, indicando variabilidade na estimativa maior do que a esperada ao acaso. Não há sobreposição de todos os intervalos de confiança. E. Baixa heterogeneidade e apesar de cruzar a nulidade os intervalos de confiança se sobrepõem. F. A estimativa sumária cruza a nulidade e o intervalo de confiança é amplo.G. O estudo apresentou limitações e foi avaliado como de baixa qualidade metodológica. H. Apenas um estudo apresentou resultados para esse desfecho e não encontrou diferença estatisticamente significante entre os grupos.  
i. Apenas um estudo observacional e com tamanho amostral limitado. J. Os estudos apresentaram limitações e foram avaliados como de baixa qualidade metodológica.  
k. Apenas dois estudos, com tamanho amostral limitado e sem evidência de diferença estatística entre os dois grupos.  
l. Um estudo apontou diferença entre os grupos, enquanto os outros dois estudos não observaram diferença significativa. Entretanto, apresentam limitações que impossibilitam a interpretação do resultado.  
118

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: Considerações gerais: -->
Para esta síntese de evidências foram incluídos 30 estudos observacionais que avaliaram os desfechos de interesse em pacientes com miopatias inflamatórias e presença de anti-Jo1 em comparação àqueles sem o anticorpo. De maneira geral, podese concluir que a presença de anti-Jo1 foi associada a um potencial pior prognóstico. Foi observada uma maior chance dos pacientes com anti-Jo1 positivo apresentarem as seguintes características: mão de mecânico (OR = 5,33; IC de 95% = 2,70 a 10,53), comprometimento das articulações/artrite (OR = 2,99; IC de 95% = 2,13 a 4,20), acometimento pulmonar (OR=4,13; IC de 95% = 2,76 a 6,17), doença pulmonar intersticial (OR= 5,27; IC de 95% = 2,97 a 9,37) e fenômeno de Raynaud (OR =2,29; IC de 95% =1,47 a 3,56). Apenas para o desfecho fraqueza muscular, a presença do anticorpo não foi associada a uma maior chance de apresentar esse desfecho. É importante destacar, no entanto, que a certeza do conjunto de evidências foi classificada como “muito baixa” para todos os desfechos avaliados, em geral por conta do risco de viés e/ou imprecisão.  
Em relação à resposta clínica, apenas um único estudo apresentou resultados para esse desfecho e, de acordo com os autores do estudo, não foi encontrada diferença estatisticamente significante entre pacientes anti-Jo1 positivos e negativos. Assim como, para o desfecho de remissão clínica, não foi encontrada evidência de diferença estatística entre os dois grupos na metaanálise conduzida. Sobre a avaliação da mortalidade, apesar de alguns estudos terem fornecido resultados sobre o desfecho, os dados não foram suficientes para a condução da meta-análise. Esses estudos apresentavam limitações importantes que impossibilitam concluir se a presença do anti-Jo1 é um fator de risco para o aumento da mortalidade de pacientes com miopatia inflamatória. Para esses três desfechos, a certeza do conjunto de evidências, também, foi classificada como “muito baixa”.  
A identificação de autoanticorpos específicos de miosite ( _myositis-specific autoantibodies_ - MSAs) e autoanticorpos associados a miosite ( _myositis-associated autoantibodies_ - MAAs) auxiliam na definição de perfis de autoanticorpos que desempenham um papel importante na distinção de características clínicas dos pacientes com miopatias<sup>54</sup> . O anti-Jo1, um dos MSAs, é descrito como um dos anticorpos mais presentes nas miopatias inflamatórias e um dos mais antigos identificados<sup>54</sup> . Por ter baixa prevalência na população com miopatias inflamatórias e por estar presente, também, em outras doenças inflamatórias, testar o anti-Jo1, em geral, não é considerado determinante para o diagnóstico das miopatias. No entanto, esse é o único anticorpo presente nos critérios classificatórios de miopatias inflamatórias, desenvolvidos pela _European League Against Rheumatism_ / _American College of Rheumatology_ (EULAR/ACR) de 2017<sup>55</sup> .  
A EULAR/ACR-2017 faz a definição das características clínicas e laboratoriais mínimas essenciais para distinguir miopatias inflamatórias de outras condições e, também, para distinguir os principais subgrupos das miopatias inflamatórias<sup>55</sup> . Esses critérios foram avaliados e endossados por grupos internacionais de reumatologia, dermatologia, neurologia e pediatria. Além do anti-Jo1, outros quatro autoanticorpos específicos para miosite foram avaliados pelo grupo: anticorpos anti-Mi-2, antiSRP, anti-PL7 e anti-PL12, todos foram fortemente associados com a miopatias inflamatórias. No entanto, apenas o autoanticorpo anti-Jo-1 teve um número significativo de observações para permitir análises e inclusão nos critérios de classificação da doença no EULAR/ACR-2017<sup>55</sup> .  
Além da classificação das miopatias, o anti-Jo1 vem sendo relacionado a um pior prognóstico em pacientes com miopatias inflamatórias, incluindo um fenótipo clínico distinto chamado síndrome antissintetase, que inclui doença pulmonar intersticial (DPI), miosite, artrite e fenômeno de Raynaud<sup>56,57</sup> . De forma relevante, diagnosticar DPI em pacientes com miopatias inflamatórias está associado a pior morbidade e maior mortalidade do que em pacientes sem DPI<sup>58</sup> . Em uma revisão que aborda a imunopatogênese das miopatias inflamatórias e as características clínicas associadas à DPI nessa condição, Helvier et. Al (2020)<sup>58</sup> aponta a importância do levantamento de fatores de prognóstico eficientes, incluindo a pesquisa de autoanticorpos, para correlacionar com a gravidade da doença a longo prazo e a estratificação do paciente de acordo com o risco de progressão, de forma a gerir as estratégias terapêuticas para cada paciente. O autor, no entanto, destaca que essa medicina personalizada continua sendo um desafio no campo da DPI relacionada às miopatias inflamatórias<sup>.</sup>  
119  
De fato, diretrizes e revisões sistemáticas sobre o diagnóstico e o tratamento de pacientes com miopatias inflamatórias apontam a necessidade de se avaliar os autoanticorpos, especificamente o anti-Jo1, mas não fazem a personalização de tratamentos quando os pacientes são positivos para esses anticorpos<sup>6,59-61</sup> . Pelas recomendações do Comitê de Miopatia da Sociedade Brasileira de Reumatologia para o tratamento de miopatias sistêmicas autoimunes, os títulos de autoanticorpos demonstraram associação com a atividade da doença, onde uma diminuição nos níveis séricos de anti-Mi-2, anti-Jo-1 e TIF-1 após o tratamento foi detectada em muitos casos<sup>59</sup> . Os tratamentos das miopatias autoimunes sistêmicas incluem tanto a supressão do processo inflamatório, como também a prevenção contra lesões do tecido musculoesquelético e de órgãos extramusculares. No entanto, os autores destacam que dados robustos são escassos e o processo terapêutico é baseado principalmente em estudos observacionais, análises retrospectivas e/ou pequenas amostras de pacientes<sup>59</sup> .  
Em resumo, a detecção do anti-Jo1 tem importância na definição das miopatias autoimunes, no processo de classificação pela EULAR/ACR-2017 e na definição do prognóstico de pacientes com miopatias inflamatórias.  
Em consonância com a literatura publicada, na revisão sistemática conduzida foi observada maior chance de pacientes com miopatias inflamatórias anti-Jo1 positivos, quando comparados àqueles anti-Jo1 negativos, de apresentarem: fenômeno de Raynaud (OR =2,29; IC de 95% =1,47 a 3,56), DPI (OR= 5,27; IC de 95% = 2,97 a 9,37), Acometimento pulmonar (OR=4,13; IC de 95% = 2,76 a 6,17), comprometimento das articulações/artrite (OR = 2,99; IC de 95% = 2,13 a 4,20) e mão de mecânico (OR = 5,33; IC de 95% = 2,70 a 10,53). Foi demonstrado, portanto, potencial pior prognóstico daqueles pacientes que apresentam o anti-Jo1.  
Apesar dos resultados obtidos nessa síntese de evidências, faltam estudos que demonstrem a alteração da conduta médica após se detectar o autoanticorpo que resulte em uma medicina mais personalizada com gestão de estratégias terapêuticas para cada paciente de forma diferenciada. Não foram identificados estudos que avaliassem os benefícios clínicos de se testar os pacientes com miopatias inflamatórias _versus_ não testar. Também não foram identificados estudos que avaliassem diferentes estratégias terapêuticas para pacientes com anti-Jo1 positivo.  
No que diz respeito à condução da avaliação econômica, para se realizar uma análise de custo-efetividade, é necessária a demonstração do benefício clínico da tecnologia (no caso, a testagem de anti-Jo1) em comparação com as disponíveis no sistema de saúde (não testar o anti-Jo1). Não tendo sido encontrados estudos que avaliassem essas duas estratégias (testar _versus_ não testar) ou estudos que demonstrassem a alteração da conduta medicamentosa após a testagem do anticorpo, não é possível demonstrar o ganho de efetividade de se ter a informação do anticorpo anti-Jo1 positivo ou negativo em pacientes com miopatias inflamatórias. Em outras palavras, nesse caso, não é recomendada a condução de uma análise de custo-efetividade.  
120

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **REFERÊNCIAS** -->
- 1 Schünemann, H.; Brożek, J.; Guyatt, G.; Oxman, A. GRADE Handbook. Handbook for grading the quality of evidence and the strength of recommendations using the GRADE approach. Updated October 2013.  
- 2 BRASIL. Ministério da Saúde (MS). Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes metodológicas : Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília, 72 p.; ISBN 978-85-334-2186-8; Ministério da Saúde, 2014.  
- 3 Brouwers, M. C. _et al._ AGREE II: advancing guideline development, reporting and evaluation in health care. _CMAJ_ 182, E839-842 (2010). https://doi.org:10.1503/cmaj.090449  
- 4 Page, M. J. _et al._ The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. _BMJ_ 372, n71 (2021). https://doi.org:10.1136/bmj.n71  
- 5 Oldroyd, A. G. S. _et al._ British Society for Rheumatology guideline on management of paediatric, adolescent and adult patients with idiopathic inflammatory myopathy. _Rheumatology (Oxford)_ 61, 1760-1768 (2022). https://doi.org:10.1093/rheumatology/keac115  
- 6 Bellutti Enders, F. _et al._ Consensus-based recommendations for the management of juvenile dermatomyositis. _Ann Rheum Dis_ 76, 329-340 (2017). https://doi.org:10.1136/annrheumdis-2016-209247  
- 7 de Souza, F. H. C. _et al._ Guidelines of the Brazilian Society of Rheumatology for the treatment of systemic autoimmune myopathies. _Adv Rheumatol_ 59, 6 (2019). https://doi.org:10.1186/s42358-019-0048-x  
- 8 Kohsaka, H. _et al._ Treatment consensus for management of polymyositis and dermatomyositis among rheumatologists, neurologists and dermatologists. _J Dermatol_ 46, e1-e18 (2019). https://doi.org:10.1111/1346-8138.14604  
- 9 Romero-Bueno, F. _et al._ Recommendations for the treatment of anti-melanoma differentiation-associated gene 5- positive dermatomyositis-associated rapidly progressive interstitial lung disease. _Semin Arthritis Rheum_ 50, 776-790 (2020). https://doi.org:10.1016/j.semarthrit.2020.03.007  
- 10 Ouzzani, M., Hammady, H., Fedorowicz, Z. & Elmagarmid, A. Rayyan-a web and mobile app for systematic reviews. _Syst Rev_ 5, 210 (2016). https://doi.org:10.1186/s13643-016-0384-4  
- 11 Wells, GA; Shea, B; O´Connell, D; Peterson, J; Welch, V; Losos, M et al. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomised studies in meta-analyses. The Ottawa Hospital Research Institute. 2021. .  
- 12 Sterne, J. A. C. _et al._ RoB 2: a revised tool for assessing risk of bias in randomised trials. _BMJ_ 366, l4898 (2019). https://doi.org:10.1136/bmj.l4898  
- 13 Mao, M. M. _et al._ Ultra-low dose rituximab as add-on therapy in anti-MDA5-positive patients with polymyositis /dermatomyositis associated ILD. _Respir Med_ 172, 105983 (2020). https://doi.org:10.1016/j.rmed.2020.105983  
- 14 Langlois, V. _et al._ Rituximab and Cyclophosphamide in Antisynthetase Syndrome-related Interstitial Lung Disease: An Observational Retrospective Study. _J Rheumatol_ 47, 1678-1686 (2020). https://doi.org:10.3899/jrheum.190505  
- 15 Langlois V, Mariampillai K, Champtiaux N, and Chabi ML, Uzunhan Y, Hachulla E, et al. Intravenous cyclophosphamide followed by oral immunosuppressive treatment versus rituximab in inflammatory myopathy-related interstitial lung disease. Arthritis Rheumatol. 2016;68(October):1–5.  
- 16 Shahin AA, Niazy MH, Haroon MM. Response to cyclophosphamide and rituximab therapy in idiopathic inflammatory myopathies: A single center experience. Egypt Rheumatol. 2021;43(3):247–51.  
- 17 Oddis, C. V. _et al._ Rituximab in the treatment of refractory adult and juvenile dermatomyositis and adult polymyositis: a randomized, placebo-phase trial. _Arthritis Rheum_ 65, 314-324 (2013). https://doi.org:10.1002/art.37754  
121  
- 18 Huapaya, J. A. _et al._ Long-Term Treatment With Azathioprine and Mycophenolate Mofetil for Myositis-Related Interstitial Lung Disease. _Chest_ 156, 896-906 (2019). https://doi.org:10.1016/j.chest.2019.05.023  
- 19 Wolstencroft, P. W., Chung, L., Li, S., Casciola-Rosen, L. & Fiorentino, D. F. Factors Associated With Clinical Remission of Skin Disease in Dermatomyositis. _JAMA Dermatol_ 154, 44-51 (2018). https://doi.org:10.1001/jamadermatol.2017.3758  
- 20 Mira-Avendano, I. C. _et al._ A retrospective review of clinical features and treatment outcomes in steroid-resistant interstitial lung disease from polymyositis/dermatomyositis. _Respir Med_ 107, 890-896 (2013). https://doi.org:10.1016/j.rmed.2013.02.015  
- 21 Grinnell, M. _et al._ Mycophenolate mofetil and methotrexate efficacy in dermatomyositis. _Br J Dermatol_ 187, 437-438 (2022). https://doi.org:10.1111/bjd.21235  
- 22 Rouster-Stevens, K. A., Morgan, G. A., Wang, D. & Pachman, L. M. Mycophenolate mofetil: a possible therapeutic agent for children with juvenile dermatomyositis. _Arthritis Care Res (Hoboken)_ 62, 1446-1451 (2010). https://doi.org:10.1002/acr.20269  
- 23 Varnier GC, Consolaro A, Cheng IL, Silva Riveiro A, Pilkington C, Ravelli A. Use of mycophenolate mofetil in inflammatory myopathies of childhood - Proceedings of the 26th European Paediatric Rheumatology Congress: part 2. Pediatr Rheumatol [Internet]. 2020 Oct 28;18(S2):82. Available from: https://pedrheum.biomedcentral.com/articles/10.1186/s12969-020-00470-5.  
- 24 Ahn, S. S., Park, Y. B. & Lee, S. W. Clinical Features of Anti-Synthetase Syndrome Associated with Prognosis in Patients with Dermatomyositis and Polymyositis. _J Clin Med_ 11 (2022). https://doi.org:10.3390/jcm11072052  
- 25 Akashi K SD, Kogata Y, et al. . SAT0461 A Retrospective Study of 88 Cases with Idiopathic Inflammatory Myositis (IIM). Annals of the Rheumatic Diseases 2015 doi: 10.1136/annrheumdis-2015-eular.6456.  
- 26 Betteridge, Z. _et al._ Frequency, mutual exclusivity and clinical associations of myositis autoantibodies in a combined European cohort of idiopathic inflammatory myopathy patients. _J Autoimmun_ 101, 48-55 (2019). https://doi.org:10.1016/j.jaut.2019.04.001  
- 27 Charles PJ, P. E., Ekholm L, et al. . Myositis-Associated Autoantibodies Detected Using Recombinant Protein Immunoblotting in Inflammatory Myopathy. . _British journal of rheumatology_ 50 (2011).  
- 28 Z. Chen, X.-P. L., X.-M. Li. Profile of myositis-specific antibodies in patients with polymyositis/dermatomyositis and association with clinical manifestations and outcome: experience from a tertiary referral centre. (2018). https://doi.org:10.1136/annrheumdis-2018-eular.4153  
- 29 de Andrade, V. P., De Souza, F. H. C., Behrens Pinto, G. L. & Shinjo, S. K. The relevance of anti-Jo-1 autoantibodies in patients with definite dermatomyositis. _Adv Rheumatol_ 61, 12 (2021). https://doi.org:10.1186/s42358-021-00171-x  
- 30 Dei, G. _et al._ Functional Progression in Patients with Interstitial Lung Disease Resulted Positive to Antisynthetase Antibodies: A Multicenter, Retrospective Analysis. _J Clin Med_ 9 (2020). https://doi.org:10.3390/jcm9093033  
- 31 Dobloug, C. _et al._ Prevalence and clinical characteristics of adult polymyositis and dermatomyositis; data from a large and unselected Norwegian cohort. _Ann Rheum Dis_ 74, 1551-1556 (2015). https://doi.org:10.1136/annrheumdis-2013205127  
- 32 Fang Y fan, L. S. f., Kuo C fu, Ho H huang, Liou L bang. . Clinical Presentations Associated with Anti-Jo-1 Antibody in Patients with Polymyositis and Dermatomyositis Clinical presentations associated with anti-Jo-1 antibody in patients with polymyositis and dermatomyositis. . 26 (2012). https://doi.org:10.6313/FJR.2012.26(1-2).03  
- 33 Gomez, G. N. _et al._ Myositis-specific antibodies and clinical characteristics in patients with autoimmune inflammatory myopathies: reported by the Argentine Registry of Inflammatory Myopathies of the Argentine Society of Rheumatology. _Clin Rheumatol_ 40, 4473-4483 (2021). https://doi.org:10.1007/s10067-021-05797-2  
122  
- 34 Hochberg, M. C., Feldman, D., Stevens, M. B., Arnett, F. C. & Reichlin, M. Antibody to Jo-1 in polymyositis/dermatomyositis: association with interstitial pulmonary disease. _J Rheumatol_ 11, 663-665 (1984).  
- 35 Huscher D, A. K., Richter J, Henes J, Alexander T, Zink A. . SAT0337 Impact of organ involvement on patient-reported outcomes in patients with idiopathic inflammatory myopathies. . _In: Poster Presentations. BMJ Publishing Group Ltd and European League Against Rheumatism_ 899.2-899 (2017). https://doi.org:10.1136/annrheumdis-2017-eular.3822  
- 36 Ji, S. Y. _et al._ Predictive factors and unfavourable prognostic factors of interstitial lung disease in patients with polymyositis or dermatomyositis: a retrospective study. _Chin Med J (Engl)_ 123, 517-522 (2010).  
- 37 Li, S. _et al._ The spectrum and clinical significance of myositis-specific autoantibodies in Chinese patients with idiopathic inflammatory myopathies. _Clin Rheumatol_ 38, 2171-2179 (2019). https://doi.org:10.1007/s10067-01904503-7  
- 38 Mielnik, P., Wiesik-Szewczyk, E., Olesinska, M., Chwalinska-Sadowska, H. & Zabek, J. Clinical features and prognosis of patients with idiopathic inflammatory myopathies and anti-Jo-1 antibodies. _Autoimmunity_ 39, 243-247 (2006). https://doi.org:10.1080/08916930600623767  
- 39 Negalur, N. V. _et al._ The Association of Myositis Specific Antibodies in Patients with Inflammatory Myositis: Preliminary Data in Indian Patients. _Ann Indian Acad Neurol_ 24, 552-558 (2021). https://doi.org:10.4103/aian.AIAN_1151_20  
- 40 Oddis, C. V., Medsger, T. A., Jr. & Cooperstein, L. A. A subluxing arthropathy associated with the anti-Jo-1 antibody in polymyositis/dermatomyositis. _Arthritis Rheum_ 33, 1640-1645 (1990). https://doi.org:10.1002/art.1780331106  
- 41 Cruellas, M. G., Viana Vdos, S., Levy-Neto, M., Souza, F. H. & Shinjo, S. K. Myositis-specific and myositis-associated autoantibody profiles and their clinical associations in a large series of patients with polymyositis and dermatomyositis. _Clinics (Sao Paulo)_ 68, 909-914 (2013). https://doi.org:10.6061/clinics/2013(07)04  
- 42 Platteel, A. C. M. _et al._ Frequencies and clinical associations of myositis-related antibodies in The Netherlands: A oneyear survey of all Dutch patients. _J Transl Autoimmun_ 2, 100013 (2019). https://doi.org:10.1016/j.jtauto.2019.100013  
- 43 Rojas-Serrano J, R. H., Estrada A, Mejia M. Factors Associated To Prognosis In A Cohort Of AntisynthetaseSyndrome : Serologic Profile Is Associated To Mortality. (2014).  
- 44 Sánchez Romo SM, S. M. G., Villarreal-Alarcón MA, Hernandez-Galarza IDJ, Galarza-Delgado DÁ. AB0607 MYOSITIS-RELATED INTERSTITIAL LUNG DISEASES: CLINICAL FEATURES, BIOMARKERS AND AUTOANTIBODIES IN LATINOAMERICAN PATIENTS. . _Annals of the Rheumatic Diseases._ 79, 1599.1592-1600 (2020). https://doi.org:10.1136/annrheumdis-2020-eular.5098  
- 45 Selva-O'Callaghan, A. _et al._ Myositis-specific and myositis-associated antibodies in a series of eighty-eight Mediterranean patients with idiopathic inflammatory myopathy. _Arthritis Rheum_ 55, 791-798 (2006). https://doi.org:10.1002/art.22237  
- 46 Sohn B, W. E., Leslie Crofford. Patients with Anti- tRNA Synthetase Syndrome Are More Likely to Present to Pulmonary Clinic and Have a Higher Prevalence and Severity of Lung Disease Than Patients with Other Types of Myositis or Systemic Sclerosis- 2019 ACR/ARP Annual Meeting Abstract Su. . _Arthritis & rheumatology (Hoboken, NJ)._ 71(October), 1-5362 (2019). https://doi.org:10.1002/art.41108  
- 47 Sreevilasan, S. K., Devarasetti, P., Narahari, N. K., Desai, A. & Rajasekhar, L. Clinical profile and treatment outcomes in antisynthetase syndrome: a tertiary centre experience. _Rheumatol Adv Pract_ 5, ii10-ii18 (2021). https://doi.org:10.1093/rap/rkab054  
- 48 Taniguchi M, N. R., Kuramoto N, et al. . Prognostic factors in Polymyositis / Dermatomyositis Patients with AntiSynthetasiantibodries. . _Arthritis and Rheumatology_ (2017).  
- 49 Vancsa, A. _et al._ Myositis-specific and myositis-associated antibodies in overlap myositis in comparison to primary  
123  
dermatopolymyositis: Relevance for clinical classification: retrospective study of 169 patients. _Joint Bone Spine_ 77, 125-130 (2010). https://doi.org:10.1016/j.jbspin.2009.08.008  
- 50 Vojinovic T, G. X., Fredi M, Franceschini F, Cavazzana I. . AB0623 RATE AND PREDICTIVE FACTORS ASSOCIATED WITH SUSTAINED REMISSION IN IDIOPATHIC INFLAMMATORY MYOSITIS. . _Annals of the Rheumatic Diseases._ 79, 1607.1601-1607 (2020). https://doi.org:10.1136/annrheumdis-2020-eular.2677  
- 51 Yardimci GK, E. E., Farisoğullari B, et al. AB0446 DEMOGRAPHIC AND CLINICAL FEATURES OF IDIOPATHIC INFLAMMATORY MYOSITIS AND PREVALENCE OF MYOSITIS-RELATED ANTIBODIES. . _Annals of the Rheumatic Diseases._ 80, 1250.1252-1251 (2021). https://doi.org:10.1136/annrheumdis-2021-eular.3349  
- 52 Zampeli, E. _et al._ Myositis autoantibody profiles and their clinical associations in Greek patients with inflammatory myopathies. _Clin Rheumatol_ 38, 125-132 (2019). https://doi.org:10.1007/s10067-018-4267-z  
- 53 Institute., J. B. _Critical Appraisal Tools_ , <https://jbi.global/critical-appraisal-tools.> (  
- 54 McHugh, N. J. & Tansley, S. L. Autoantibodies in myositis. _Nat Rev Rheumatol_ 14, 290-302 (2018). https://doi.org:10.1038/nrrheum.2018.56  
- 55 Lundberg, I. E. _et al._ 2017 European League Against Rheumatism/American College of Rheumatology classification criteria for adult and juvenile idiopathic inflammatory myopathies and their major subgroups. _Ann Rheum Dis_ 76, 19551964 (2017). https://doi.org:10.1136/annrheumdis-2017-211468  
- 56 Galindo‐Feria, A. S., Horuluoglu, B. & Lundberg, I. E. Anti‐Jo1 autoantibodies, from clinic to the bench. _Rheumatology & Autoimmunity_ 2, 57-68 (2022). https://doi.org:10.1002/rai2.12035  
- 57 Giannini M, T. M., Abbracciavento L, et al. Anti-SSA and anti-jo1 levels in interstitial lung disease related to idiopathic inflammatory myopathies. _Ann Rheum Dis._ , 77:1282 (2018). https://doi.org:10.1136/annrheumdis-2018-eular.7400  
- 58 Hervier, B. & Uzunhan, Y. Inflammatory Myopathy-Related Interstitial Lung Disease: From Pathophysiology to Treatment. _Front Med (Lausanne)_ 6, 326 (2019). https://doi.org:10.3389/fmed.2019.00326  
- 59 de Souza, F. H. C. _et al._ The Brazilian Society of Rheumatology recommendations on investigation and diagnosis of systemic autoimmune myopathies. _Adv Rheumatol_ 59, 42 (2019). https://doi.org:10.1186/s42358-019-0085-5  
- 60 Drake LA, D. S., Farmer ER, et al. Guidelines of care for dermatomyositis. _J Am Acad Dermatol_ (1996). https://doi.org:10.1016/S0190-9622(96)90037-7  
- 61 Morisset, J., Johnson, C., Rich, E., Collard, H. R. & Lee, J. S. Management of Myositis-Related Interstitial Lung Disease. _Chest_ 150, 1118-1128 (2016). https://doi.org:10.1016/j.chest.2016.04.007  
124  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Miopatias Inflamatórias | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório do**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**Protocolo (Conitec) ou**<br>**Portaria de Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório de<br>Recomendação nº<br>980/2025|Alteração do título do<br>documento e de<br>conteúdo|Exclusão da imunoglobulina humana<br>como pó liofilizado para solução injetável<br>ou solução injetável na concentração de 3<br>g ou 6 g. [Relatório de recomendação nº<br>694/2021; Portaria SCTIE/MS nº 83, de<br>29 de dezembro de 2021]|-|
|Portaria SAS/MS nº<br>1692, de 22 de novembro||||
|de 2016<br>[Relatório de<br>Recomendação nº<br>232/2016]|Atualização de<br>conteúdo|-|-|
|Portaria SAS/MS nº 206,<br>de 23 de abril de 2010|Primeira versão do<br>Protocolo Clínico e<br>Diretrizes<br>Terapêuticas de<br>Dermatomiosite e<br>Polimiosite|-||  
125

---

