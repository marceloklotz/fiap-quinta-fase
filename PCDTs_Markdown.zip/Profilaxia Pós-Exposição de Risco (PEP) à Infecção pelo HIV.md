<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA SECTICS/MS Nº 14, DE 8 DE ABRIL DE 2024  
Torna pública a decisão de atualizar, no âmbito do Sistema Único de Saúde – SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia PósExposição de Risco (PEP) à Infecção pelo HIV, IST e Hepatites Virais.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.798, de 28 de novembro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011,  
RESOLVE:  
Art. 1º Fica atualizado, no âmbito do Sistema Único de Saúde – SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV, IST e Hepatites Virais.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/pt-br.  
Art. 3º Fica revogada a Portaria SCTIE/MS nº 54, de 24 de agosto de 2021, publicada no Diário Oficial da União nº 162, de 26 de agosto de 2021, Seção 1, pág. 78.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: CARLOS A. GRABOIS GADELHA -->
1

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: INTRODUÇÃO -->
A Profilaxia Pós-Exposição (PEP) ao HIV, hepatites virais, sífilis e outras infecções sexualmente transmissíveis (IST) consiste no uso de medicamentos para reduzir o risco de adquirir essas infecções, após potencial exposição de risco.  
A PEP para HIV está disponível no Sistema Único de Saúde (SUS) desde 1999 e, atualmente, está inserida no conjunto de estratégias da Prevenção Combinada, cujo principal objetivo é ampliar as formas de intervenção para evitar novas infecções pelo HIV, pelas Hepatites Virais pelos vírus B (HBV) e C (HCV) e outras IST.  
Desde 2010, recomenda-se o uso da PEP considerando exposições sexuais consentidas que representem risco de infecção, a partir da avaliação da situação da exposição de risco da pessoa. A PEP também é indicada nas situações de violência sexual e acidente com materiais biológicos.  
É essencial ampliar o acesso à PEP, com implementação de sua prescrição em serviços de urgência/emergência, unidades básicas de saúde, serviços de referência, clínicas e hospitais da rede pública e privada.  
O presente Protocolo tem como objetivo atualizar as recomendações para PEP, simplificar o acompanhamento e reduzir barreiras de acesso a essa tecnologia de prevenção combinada.  
Esta atualização amplia a recomendação do uso de esquema com dolutegravir para crianças, pessoas com potencial de engravidar e gestantes; busca contribuir para atenção integral à pessoa exposta ao risco das IST, do HIV e das hepatites virais, considerando a expansão da Profilaxia Pré-Exposição (PrEP) no SUS e a necessidade de controle desses agravos, inclusive da sífilis, que tem apresentado crescente número de casos no país.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: METODOLOGIA -->
O processo de desenvolvimento desse PCDT envolveu a realização de avaliações de revisões sistemáticas (RS) e ensaios clínicos randomizados (ECR) para as sínteses de evidências, que foram adotadas e/ou adaptadas às recomendações de diretrizes já publicadas para as tecnologias que se encontram disponíveis no SUS para o tratamento do HIV, IST e hepatites virais. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontrase descrito no Apêndice 2.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: ACOLHIMENTO -->
O acolhimento é uma diretriz da Política Nacional de Humanização, que objetiva ampliar o acesso, fornecer resposta resolutiva à demanda apresentada e ser dispositivo organizador do processo de trabalho em função das necessidades de saúde do usuário<sup>1</sup> .  
O acolhimento à pessoa exposta deve ocorrer em local adequado que garanta o direito à privacidade e sem julgamento moral, visando a ampliação do acesso das populações-chave e das populações prioritárias. São consideradas **populações-chave** : gays e outros homens que fazem sexo com homens,  
2  
travestis e pessoas trans, trabalhadoras(es) do sexo, pessoas que usam álcool e outras drogas e pessoas privadas de liberdade. São consideradas **populações prioritárias** : indígenas, jovens, população negra e pessoas em situação de rua.  
A avaliação inicial deve incluir perguntas objetivas, que abordem prática sexual, uso de drogas lícitas e ilícitas, troca consensual de serviços, atividades ou favores sexuais por dinheiro, bens ou objetos, situação de violência, uso atual ou anterior da PrEP e uso anterior de PEP, entre outras.  
Caso sejam identificadas uma ou múltiplas situações de exposição sexual recomenda-se o início imediato de PEP em até 72 horas após a última exposição de risco<sup>2</sup> . Deve ser feita avaliação individualizada sobre a indicação de PrEP após o término da PEP. Para informações sobre PrEP, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV”<sup>3</sup> , disponível em https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts.  
Algumas pessoas que buscam atendimento para iniciar PEP após relação sexual consentida devem ser avaliadas para início futuro da PrEP. Quando indicada a PrEP, a transição de PEP para a PrEP pode ser feita após os 28 dias de uso da PEP e exclusão de infecção pelo HIV. Quando houver migração para uso de PrEP deve haver atenção na avaliação dos resultados da testagem rápida durante o seguimento, pois o uso de ARV durante a PEP poderá reduzir a carga viral do HIV da infecção prévia e induzir a resultados falso não reagentes na detecção de anticorpos.  
Em relação à PEP ocupacional, situação em que há acidente ligado a atividade laboral com material biológico, deve-se identificar situações e práticas de risco e apoiar o planejamento para redução de risco de acidentes, problematizando a respeito de aspectos tais como, excesso de carga de trabalho, a disponibilidade e o uso de equipamento de proteção individual (EPI) e de instrumentos perfurocortantes com dispositivos de segurança<sup>4</sup> .  
A Lei nº 12.845/2013 dispõe sobre o atendimento obrigatório e integral de pessoas em situação de violência sexual, evitando-se assim encaminhamentos e transferências desnecessários. A intervenção necessita ter um caráter ágil, que não consista em um entrave à realização do serviço demandado. Deve ser resolutiva no seu caráter informativo e focada na demanda trazida pela pessoa em atendimento<sup>5</sup> .

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: PREVENÇÃO COMBINADA -->
O termo “Prevenção Combinada” remete à conjugação de diferentes ações de prevenção às IST, ao HIV, às hepatites virais e seus fatores associados. Indica o uso “combinado” de métodos preventivos e ofertas assistenciais, composto por estratégias biomédicas, comportamentais e estruturais que, juntas, buscam otimizar o impacto da prevenção a esses agravos<sup>6,7</sup> .  
O símbolo da mandala representa a combinação e a ideia de movimento de diferentes estratégias de prevenção, sendo a PEP uma delas. Esse conjunto de ações deve ser centrado nas necessidades das pessoas e nas características dos grupos socioculturais em que estão inseridas, considerando as especificidades dos sujeitos e dos seus contextos.  
A oferta de PEP pode ser a porta de entrada para o conhecimento e uso de outras estratégias de Prevenção Combinada, assim como para o cuidado integral.  
A escuta ativa e a promoção de um ambiente favorável ao diálogo sobre as práticas sexuais devem estar presentes na rotina dos serviços de saúde. Essa abordagem possibilita vínculos e facilita a adesão às tecnologias disponíveis ofertadas pelos profissionais de saúde. A escuta qualificada deve ser realizada com atenção e respeito, livre de preconceitos, possibilitando que a própria pessoa encontre soluções para suas questões<sup>1</sup> .  
3  
<!-- Start of picture text -->
Ea roses<br>aft?oe.Zé::Seefs By5-CHAVE &‘bKG aSos<br>é SF %<br>2 few PREVENCAO : =<br>pa Gy B<br>0g &Ro, &.<br>Mag Re ote<br>om Reducao /,<br>KG<br><!-- End of picture text -->  
**Figura 1.** Mandala de prevenção combinada. Fonte: DATHI/SVS/MS. **Para mais informações sobre as estratégias de Prevenção Combinada, consultar o documento “Prevenção Combinada do HIV: Bases conceituais para profissionais, trabalhadores(as) e gestores(as) de saúde”**<sup>8</sup> .  
<!-- Start of picture text -->
5.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: PROFILAXIA DO HIV -->
No atendimento inicial, após a exposição de risco ao HIV, é necessário que o (a) profissional de saúde avalie como, quando e com quem ocorreu a exposição. Didaticamente, quatro perguntas direcionam o atendimento para decisão da indicação ou não da PEP ( **Quadro 1** ).  
**Quadro 1.** Os quatro passos da avaliação da PEP.  
1. O tipo de material biológico é de risco para transmissão do HIV?  
2. O tipo de exposição é de risco para transmissão do HIV?  
3. O tempo transcorrido entre a exposição e o atendimento é menor que 72 horas?  
4. A pessoa exposta é **não reagente** para o HIV no momento do atendimento?  
<u>Se todas as respostas forem SIM, a</u> **<u>PEP para HIV está indicada.</u>**  
Fonte: DATHI/SVSA/MS.  
O status sorológico da pessoa-fonte, **<u>quando conhecido</u>** <u>, contribui para avaliação de PEP,</u> conforme discutido no item 4.5.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.1. Tipo de material biológico -->
Existem materiais biológicos sabidamente infectantes e envolvidos na transmissão do HIV ( **Quadro 2** ). Assim, a exposição a esses materiais constitui situação na qual a PEP está recomendada.  
4  
**Quadro 2.** Tipos de material biológico com e sem risco de transmissão do HIV.  
|**Materiais biológicos COM risco de**<br>**transmissão do HIV**|**Materiais biológicos SEM risco de**<br>**transmissão do HIV**<sup>**(a)**</sup>|
|---|---|
|› Sangue|› Suor|
|› Sêmen|› Lágrima|
|› Fluidos vaginais|› Fezes|
|› Líquidos de serosas (peritoneal, pleural,<br>pericárdico)|› Urina<br>› Vômitos|
|› Líquido amniótico|› Saliva|
|› Líquor|› Secreções nasais|  
Fonte: DATHI/SVS/MS.  
a A presença de sangue nessas secreções torna esses materiais potencialmente infectantes, caso em que o uso de PEP pode ser indicado.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.2. Tipo de exposição -->
Existem exposições com risco de infecção envolvidas na transmissão do HIV ( **Quadro 3** ). Assim, a exposição constitui situação na qual a PEP está recomendada.  
**Quadro 3.** Tipos de exposição com e sem risco de transmissão do HIV.  
|**Exposição COM risco de transmissão do HIV**|**Exposição SEM risco de transmissão do HIV**|
|---|---|
|› Percutânea|› Cutânea em pele íntegra|
|› Membranas mucosas|› Mordedura sem a presença de sangue|
|› Exposição sexual desprotegida<br>› Cutâneas em pele não íntegra<br>› Mordedura com presença de sangue||  
Fonte: DATHI/SVS/MS.  
Algumas definições e exemplos dessas exposições encontram-se a seguir:

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: **<u>Exposição com risco</u>** de transmissão do HIV: -->
- Percutânea – Exemplos: lesões causadas por agulhas ou outros instrumentos perfurantes e/ou cortantes;  
- Membranas mucosas – Exemplos: exposição sexual desprotegida; respingos em olhos, nariz e boca;  
- Cutâneas envolvendo pele não íntegra – Exemplos: presença de dermatites ou feridas abertas;  
- Mordeduras com presença de sangue – Nesses casos, os riscos devem ser avaliados tanto para a pessoa que sofreu a lesão quanto para aquela que a provocou.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: **<u>Exposição sem risco</u>** de transmissão do HIV: -->
- Cutâneas, exclusivamente, quando a pele exposta se encontra íntegra;  
-  
- Mordedura sem a presença de sangue.  
5  
- 5.3. Tempo transcorrido entre exposição e o atendimento  
As situações de exposição ao HIV constituem atendimento de **urgência,** em função da necessidade de **início precoce da profilaxia para maior eficácia** da intervenção. Não há benefício da profilaxia com ARV após 72 horas da exposição<sup>9,10;11.</sup>  
O primeiro atendimento após a exposição de risco ao HIV é uma urgência. A **PEP deve ser iniciada o mais precocemente possível,** tendo como **limite as 72 horas** subsequentes à exposição de  
risco.  
Nos casos em que o atendimento ocorrer após 72 horas da exposição, não está mais indicada a PEP. Entretanto, se o material e o tipo de exposição forem de risco, recomenda-se acompanhamento sorológico conforme o **Quadro 13** , além das orientações de prevenção combinada<sup>11</sup> :  
- Verificar se há indicação de PrEP;  
- Oferecer testagem para HIV, sífilis e hepatites virais B e C;  
- Oferecer testagem para _Neisseria gonorrhoeae_ e _Chlamydia trachomatis_ , exceto nos casos de acidente com material biológico;  
- Orientar vacinação para HPV e hepatites virais A e B, quando indicado;  
- Diagnosticar e tratar IST e hepatites virais, quando presentes;  
- Ofertar anticoncepção de emergência, quando indicada;  
- Orientar sobre uso de preservativo e gel lubrificante;  
- Orientar sobre redução de danos.  
- 5.4. _Status_ sorológico da pessoa exposta  
A indicação ou não de PEP dependerá do _status_ sorológico para HIV da pessoa exposta, que deve sempre ser avaliado por meio de testes rápidos (TR) em situações de exposições consideradas de risco:  
- **Amostra não reagente (TR1 não reagente)** <u>a PEP está indicada (conforme a</u> **Figura 2** ), pois a pessoa exposta é suscetível ao HIV.  
- **Amostra reagente (TR1 e TR2 reagentes):** <u>a PEP não está indicada. A infecção pelo HIV</u> ocorreu antes da exposição que motivou o atendimento e a pessoa deve ser encaminhada para acompanhamento clínico e início da terapia antirretroviral (TARV). Para mais informações, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”; o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes”<sup>12,13</sup> ; e o “Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais” 14,15, disponíveis em <u>https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts.</u>  
- **Amostra com resultados discordantes (TR1 reagente e TR2 não reagente):** não é possível confirmar o _status_ sorológico da pessoa exposta. Em caso de discordância entre TR1 e TR2, recomenda-se repetir os exames do fluxograma: caso novamente ocorra discordância, deve-se indicar a testagem laboratorial para elucidação diagnóstica. Existem quatro algoritmos disponíveis no Manual Técnico de Diagnóstico da Infecção pelo Adulto e Crianças. O imunoensaio é o primeiro teste: quando reagente, deve ser complementado com teste molecular de quantificação  
6  
da carga viral do HIV ou com _Western blot/Imunoblot_ . Nesse caso, a decisão de iniciar ou não a profilaxia deve ser avaliada conforme critério clínico com decisão conjunta com a pessoa exposta: caso de resultado da testagem tenha sido reagente, recomenda-se manter o esquema ARV (Tenofovir/Lamivudina + Dolutegravir), o qual coincide com o esquema preferencial para início de tratamento antirretroviral.  
É direito da pessoa recusar a PEP ou outros procedimentos, por exemplo, a coleta de exames laboratoriais. É importante sempre fornecer informações sobre os riscos da exposição e a relação entre os riscos e benefícios da testagem e profilaxia. Caso a pessoa mantenha sua opção por não aceitar a profilaxia, sugere-se o registro com descrição do atendimento em prontuário e sempre que possível com documentação da recusa.  
- 5.5. _Status_ sorológico da pessoa-fonte  
Esse critério é o único não obrigatório, pois nem sempre a pessoa-fonte está presente e disponível para realizar a testagem. Portanto, é fundamental o acolhimento na situação de comparecimento em conjunto aos serviços, a oferta de testagem rápida e as orientações pertinentes.  
**Não se deve retardar ou condicionar o atendimento da pessoa exposta à ausência da pessoafonte.**  
- **Amostra não reagente no primeiro Teste Rápido anti-HIV (TR1):** <u>a PEP não está indicada para a pessoa exposta. Caso a pessoa-fonte tenha história de exposição de risco nos 30 dias</u> que antecederam a exposição, a avaliação deverá ser individualizada e a PEP poderá ser indicada devido à possibilidade de resultados falso-negativos de testes imunológicos (rápidos ou laboratoriais) durante o período de janela imunológica. Considerar a necessidade de indicar PrEP para pessoa-fonte, conforme avaliação individualizada.  
- **Amostra reagente em dois testes rápidos anti-HIV (TR1 e TR2 reagentes):** <u>a PEP está indicada para a pessoa exposta. Caso a pessoa-fonte tenha</u> _status_ sorológico desconhecido até o momento desta testagem, a pessoa-fonte deve ser comunicada individualmente sobre os resultados da investigação diagnóstica e encaminhada para acompanhamento clínico e início da TARV. Para mais informações, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”<sup>14,15</sup> , disponíveis em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts</u> **<u>.</u>**  
- **Resultado de testagem para HIV da pessoa-fonte desconhecido:** <u>avaliar individualmente.</u> Casos envolvendo acidentes com fonte desconhecida (ex.: agulha em lixo comum, lavanderia, coletor de material perfurocortante) ou fonte conhecida com sorologia desconhecida (ex.: pessoa-fonte que faleceu ou que não se apresenta ao serviço para testagem), a decisão sobre instituir a PEP deve ser individualizada.  
Para a tomada de decisão deve-se considerar a gravidade da exposição e a probabilidade clínica e epidemiológica da pessoa-fonte apresentar infecção pelo HIV, tais como prevalência local do HIV ou presença de manifestações clínicas sugestivas de aids. Importante reforçar que a decisão pela prescrição da PEP não deve ser retardada devido à ausência da pessoa-fonte no momento do acolhimento e que os demais critérios, descritos anteriormente, devem ser considerados caso o resultado da testagem para HIV da pessoafonte seja desconhecido.  
7

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.6. Utilização de testes rápidos -->
Considerando que, quanto mais cedo se inicia a profilaxia, maior sua eficácia, o uso de TR para diagnóstico da infecção pelo HIV na avaliação da indicação de PEP é fundamental. O TR é um dispositivo de uso único que não depende de infraestrutura laboratorial, pode ser executado na presença do indivíduo e produz resultado em tempo igual ou inferior a 30 minutos.  
Dessa forma, todo serviço que for ofertar PEP deverá organizar-se também para a oferta de testagem rápida, incluindo capacitação, fluxo logístico dos insumos e condições de armazenamento.  
Deve-se realizar a testagem inicial com um teste rápido (TR1). Caso o resultado seja não reagente, o _status_ sorológico estará definido como negativo. Caso seja reagente, deverá ser realizado um segundo teste rápido (TR2), diferente do primeiro. Caso este também seja reagente, estabelece-se o diagnóstico da infecção pelo HIV. Para amostras com resultados discordantes entre TR1 e TR2, deve-se repetir os exames do fluxograma. Persistindo a discordância entre os resultados, uma amostra deverá ser coletada por punção venosa e encaminhada para ser testada em laboratório. Para mais informações, consultar o “Manual Técnico para Diagnóstico da Infecção pelo HIV em Adultos e Crianças”<sup>16</sup> , disponível em: <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuais-tecnicos-para-diagnostico</u>  
Ressalta-se que existem outros fluxogramas para investigação diagnóstica do HIV, cabendo ao serviço se adequar às possibilidades. Para mais informações sobre métodos diagnósticos de infecção pelo HIV, consultar o “Manual Técnico para o Diagnóstico da Infecção pelo HIV em Adultos e Crianças”<sup>16</sup> disponível em https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuais-tecnicos-para-diagnostico  
8  
A **Figura 2** descreve o fluxograma de investigação diagnóstica.  
<!-- Start of picture text -->
Pessoa em possivel situacdo de<br>‘exposic&o ao HIV<br>Ne Houve exposicéo 2 Nao :<br>38 material biologico com PEP nao indicada.<br>ss " , Acompanhamento nao é<br>2 risco de transmiss&o cheetsls<br>2a do HIV? -<br>| Sim<br>oS Houve exposicZo com Nao<br>2 = risco de transmissao do<br>FSag HIV-pele percutanea, no integra?mucosa,<br>| Sim<br>22 Nao<br>v8 Atendimento dentro PEP ndo indicada. Realizar<br>as de 72 horas apés a acompanhamento sorolégico<br>5 = exposic&o? da pessoa exposta.<br>1 Sim<br>Sim<br>ss Pessoa exposta: PEP ndo indicada.<br>23 exame de HIV positivo Encaminhar<br>ee ou reagente? acompanhamento clinico.<br>| Nao<br>2<br>=<br>exame de HIV positivo Iniciar PEP. Encaminhar<br>te Pessoa-fonte: Sim<br>3 ou reagente ou soroldgico indicado.<br>3 desconhecido?<br>a<br>Apessoa fonte teve sim<br>exposicao de risco nos<br>ultimos 30 dias?<br>Nao<br>Nao recomendar PEP.<br>Acompanhar sorolégico nao<br>@ necessario.<br><!-- End of picture text -->  
**Figura 2.** Fluxograma para indicação de PEP ao HIV. Fonte: DATHI/SVSA/MS.  
9

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.7. Esquema antirretroviral para PEP -->
A PEP deve ser iniciada até 72 horas após a exposição e quanto mais precoce seu início, maior sua eficácia. Nesse sentido, o acesso ao início oportuno da PEP é um importante desafio, sendo necessário ampliar sua prescrição pelos profissionais da equipe de saúde habilitados por seus respectivos conselhos de classe, uma vez que sejam adotadas as condutas orientadas neste PCDT<sup>17</sup> .  
O esquema preferencial de profilaxia deve preferencialmente incluir combinações de três ARV 18,19, sendo dois inibidores de transcriptase reversa análogos de nucleosídeo (ITRN) associados a outra classe<sup>20,21</sup> .  
Quando recomendada a PEP, independentemente do tipo de exposição ou do material biológico envolvido, o esquema antirretroviral preferencial indicado deve ser a combinação tenofovir/lamivudina + dolutegravir, conforme o **Quadro 4** .  
**Quadro 4.** Esquema preferencial para PEP  
Quando indicado a PEP, o esquema antirretroviral deverá ser estruturado com comprimidos coformulados de tenofovir/lamivudina (TDF/3TC) 300 mg/300 mg adicionado a 1 comprimido de dolutegravir (DTG) 50 mg ao dia.  
A duração da PEP é de 28 dias.  
Fonte: DATHI/SVSA/MS.  
Esquemas contendo dolutegravir são superiores a qualquer um dos outros esquemas disponíveis<sup>22</sup> . O esquema preferencial ( **tenofovir/lamivudina + dolutegravir** ) possui perfil favorável de toxicidade e pequeno número de comprimidos, otimizando a adesão<sup>23</sup> . Além disso, apresenta alta barreira genética à resistência, potencialmente reduzindo o risco de resistência transmitida, principalmente quando a pessoafonte é multiexperimentada em TARV.  
O dolutegravir pode ser coadministrado de forma segura com contraceptivos orais e também hormônios para feminização, visto seu baixo potencial de interação medicamentosa<sup>24,25,26</sup> .  
O **Quadro 5** elenca as apresentações e esquemas de administração dos medicamentos preferenciais para PEP.  
10  
**Quadro 5.** Apresentações e posologias de antirretrovirais preferenciais para PEP.  
|**Medicamento**|**Apresentação**|**Posologia**|
|---|---|---|
|**Tenofovir/lamivudina**<br>(TDF<sup>(a)</sup>/ 3TC)|Comprimido coformulado (TDF<br>300 mg / 3TC 300 mg)<br>**OU**<br>Comprimido TDF 300 mg<br>+|1 comprimido VO 1x/dia<br>**OU**<br>1 comprimido TDF 300 mg VO<br>1x/dia<br>+|
||Comprimido 3TC 150 mg|2 comprimidos 3TC 150 mg VO<br>1x/dia|
|**Dolutegravir**DTG<sup>(b)</sup>|Comprimido DTG 50 mg|1 comprimido VO 1x/dia|  
Fonte: DATHI/SVSA/MS.  
(a) Não indicado para pessoa exposta com insuficiência renal aguda.  
(b) O dolutegravir 50 mg está indicado para pessoas com idade maior que 6 anos com peso maior que 20 kg.  
Caso exista contraindicação ao uso de tenofovir, este deve ser substituído pela coformulação zidovudina (AZT) 300 mg e lamivudina (3TC) 150 mg.  
Caso a pessoa tenha contraindicação ou intolerância a dolutegravir, este deve ser substituído por darunavir (DRV) 800 mg associado a ritonavir (RTV) 100 mg.  
Esquemas alternativos para PEP estão descritos no **Quadro 6.**  
**Quadro 6.** Esquemas alternativos para PEP  
|**Situação**|**Esquema alternativo**|
|---|---|
|Impossibilidade de uso do tenofovir (TDF):|Zidovudina/lamivudina (AZT/3TC) +<br>dolutegravir(DTG)|
|Impossibilidade de uso do dolutegravir (DTG):|Tenofovir/lamivudina (TDF/3TC) + darunavir<br>(DRV) + ritonavir (RTV)|  
**A duração da PEP é de 28 dias.**  
Fonte: DATHI/SVSA/MS.  
Já as apresentações e as posologias de antirretrovirais alternativos para PEP estão resumidas no **Quadro 7** .  
11  
**Quadro 7.** Apresentações e posologias de antirretrovirais alternativos para PEP  
|**Medicamento**|**Apresentação**|**Posologia**|
|---|---|---|
|Zidovudina/lamivudina<br>(AZT/3TC)|Comprimido coformulado<br>(AZT 300 mg/ 3TC 150 mg)|1 comprimido VO 2x/dia|
|Tenofovir<br>(TDF)|Comprimido 300 mg|1 comprimido VO 1x/dia|
|Darunavir + ritonavir|Darunavir: comprimido 800 mg|1 comprimido VO 1x/dia|
|(DRV + RTV)|Ritonavir: Comprimido 100 mg|1 comprimido VO 1x/dia|  
Fonte: DATHI/SVSA/MS.  
Apesar de sua melhor tolerabilidade, o tenofovir está associado com a possibilidade de toxicidade renal, especialmente em pessoas com doenças renais preexistentes (ou com fatores de risco), quando a taxa de filtração glomerular for menor que 50 mL/min ou em pessoas com história de diabetes, hipertensão arterial descontrolada ou insuficiência renal. A indicação deve ser avaliada, já que a duração da exposição ao medicamento será curta (28 dias) e provavelmente reversível com a sua suspensão.  
Existe também o risco potencial de exacerbação ( _“flares”_ hepáticos) entre pessoas vivendo com o vírus da hepatite B (HBV), após completar o tempo da PEP. Tal risco é pouco conhecido, mas a avaliação do _status_ sorológico de HBV não deve ser uma pré-condição para o oferecimento de PEP com tenofovir<sup>27,28</sup> . Assim, **recomenda-se que pessoas coinfectadas pelo HBV iniciem a PEP com o esquema preferencial e sejam encaminhadas para acompanhamento em serviços de referência.**  
Nos casos em que o tenofovir não é tolerado ou é contraindicado, recomenda-se a combinação zidovudina/lamivudina como alternativa.  
Devido à interação medicamentosa de carbamazepina e dolutegravir, pessoas candidatas a PEP, que estejam em uso de carbamazepina e que não possam substitui-lo ou interrompê-lo podem alterar a posologia de uso do dolutegravir para o uso de um comprimido de 50 mg duas vezes ao dia (12/12 horas). Do mesmo modo, dada a similaridade estrutural e farmacológica entre carbamazepina e oxcarbazepina, pacientes que estejam em uso de oxcarbazepina também podem alterar a posologia de uso do dolutegravir.  
Caso a pessoa exposta esteja em uso de rifampicina, carbamazepina, fenitoína ou fenobarbital, o dolutegravir deve ser utilizado em dose dobrada (50 mg) de 12/12 horas. Neste caso, o esquema será estruturado da seguinte forma:  
**- Tenofovir/lamivudina 300 mg/300 mg 1 comprimido ao dia + dolutegravir 50 mg 1 comprimido de 12/12 horas.**  
Atualmente, o dolutegravir não está recomendado em pessoas que façam uso de dofetilida, pilsicainida e oxcarbazepina. Como as interações medicamentosas podem sofrer atualizações, sugere-se consulta também ao link: <u>https://interacoeshiv.huesped.org.ar/</u> Nesses casos, o darunavir/ritonavir é a alternativa terapêutica para estruturar o esquema de PEP.  
O dolutegravir aumenta a concentração plasmática da metformina e pode ocasionar hipoglicemia. Assim, é necessária atenção especial ao uso concomitante de ambos os medicamentos.  
Darunavir 800 mg associado a ritonavir 100 mg, administrado uma vez ao dia, tem poucos efeitos adversos e baixa taxa de perda de seguimento. É a alternativa preferível caso exista suspeita de resistência transmitida pelo caso índice ou suspeita de infecção aguda pelo HIV no paciente exposto; no entanto, este regime tem potencial para interações medicamentosas<sup>29,30</sup> .  
12  
Na indicação dos antirretrovirais para a PEP é muito importante avaliar todas as interações farmacológicas com outros fármacos utilizados concomitantemente. Esse cuidado visa preservar a eficácia do esquema e evitar efeitos adversos. Para tal, podem ser usadas bases de dados como, por exemplo, a disponível em https://www.hiv-druginteractions.org/checker.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.8. Pessoas vivendo com Hepatite B crônica -->
A combinação de tenofovir/lamivudina faz parte do esquema recomendado para PEP e ambos possuem atividade contra HIV e HBV. A retirada do esquema após 28 dias pode estar relacionada à reativação ( _flares_ ) da hepatite B. No entanto, suspender o uso de tenofovir/entricitabina para PrEP não acarretou na reativação da hepatite B<sup>27</sup> .  
Por outro lado, pacientes não cirróticos não apresentaram manifestações de descompensação hepática no curso de reativação pós-retirada da combinação. Finalmente, o risco de desenvolvimento de resistência do HBV ao tenofovir ou lamivudina em quatro semanas de seu uso é extremamente baixo.  
Assim sendo, pessoas já em uso de tratamento antiviral para hepatite B crônica com tenofovir desoproxila ou entecavir devem usar o esquema preferencial de PEP durante 28 dias. Aqueles indivíduos diagnosticados com hepatite B durante o rastreamento inicial com teste rápido para HBsAg também devem iniciar a PEP e mantê-la até que a pessoa seja avaliada pelo serviço especializado.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.9. Soroconversão durante a PEP -->
Indivíduos que durante a PEP, ou logo após o seu término, manifestarem exantema, acompanhado ou não de sintomas mononucleose-símile (febre, dor de garganta, adenomegalia generalizada, entre outros sintomas), deverão ser avaliados para excluir infecção aguda pelo HIV, observando-se as orientações do Manual Técnico para o Diagnóstico da Infecção pelo HIV em Adultos e Crianças do Ministério da Saúde<sup>16</sup> disponível em: <u>https://www.gov.br/aids/pt-br/central-de-conteudo/manuais-tecnicos-para-diagnostico.</u> Caso o teste sorológico confirme a positividade, manter esquema de PEP até avaliação em serviço especializado.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.10. Pessoa fonte multiexperimentada à TARV -->
Na escolha do esquema profilático em exposições envolvendo fonte sabidamente vivendo com o HIV/aids, deve-se sempre avaliar a história de uso dos ARV da pessoa-fonte e os parâmetros que podem sugerir a presença de cepas virais resistentes.  
Com a introdução de dolutegravir no regime preferencial, é ofertada maior segurança em relação à barreira genética, já que não há registro de resistência transmitida a essa classe de antirretrovirais (inibidores de integrase/INI) no Brasil.  
**Ressalta-se que a ausência de médico infectologista não deve atrasar a prescrição da profilaxia.** Nesses casos, recomenda-se que a pessoa exposta inicie a PEP e seja reavaliada o mais brevemente possível em um serviço de referência para adequação do esquema.  
Não está indicada a realização de teste de genotipagem na pessoa fonte no momento da exposição para definição do esquema. Não obstante, quando a pessoa-fonte possuir um teste de genotipagem recente (últimos 12 meses), este poderá ser utilizado para a adequação do esquema de profilaxia antirretroviral.  
13

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.11. Gestantes -->
Para gestantes, independentemente da forma de exposição e da idade gestacional, o esquema preferencial deve ser composto com dolutegravir. Os critérios para indicação de PEP para essa população são os mesmos aplicados a qualquer outra pessoa que tenha sido exposta ao HIV.  
O uso de dolutegravir durante o período periconcepcional e primeiro trimestre de gestação não aumenta o risco de defeitos de formação do tubo neural (DTN)<sup>31</sup> .  
Recomenda-se o uso de preservativos até que a PEP tenha sido finalizada e haja definição se ocorreu ou não transmissão de HIV ou outra IST.  
O **Quadro 8** descreve o esquema preferencial de PEP em gestantes.  
**Quadro 8.** Esquema preferencial de ARV e medicamentos alternativos para PEP em gestantes  
|**Esquema preferencial**|**Medicamentos alternativos**|
|---|---|
|Tenofovir/lamivudina +<br>dolutegavir|Impossibilidade de tenofovir: zidovudina (AZT) 300 mg /<br>lamivudina (3TC) 150 mg, 1 comprimido 2 vezes ao dia +<br>dolutegravir (DTG) 50 mg 1 vez ao dia.|
|(TDF/3TC + DTG)|Impossibilidade de dolutegravir: darunavir (DRV) 600 mg +<br>ritonavir(RTV)100 mg2 vezes ao dia.|  
Fonte: DATHI/SVS/MS.  
Já o **Quadro 9** descreve as apresentações e esquemas de administração da PEP em gestantes.  
**Quadro 9.** Apresentações e posologias de ARV preferenciais para PEP em gestantes  
|**Medicamento**|**Apresentação**|**Posologia**|
|---|---|---|
||Comprimido coformulado (TDF<br>300 mg/ 3TC 300 mg)<br>**OU**|Tomar 1 comprimido VO 1x/dia<br>**OU**|
|Tenofovir + lamivudina<br>(TDF + 3TC)|Comprimido de tenofovir 300 mg<br>+|1 comprimido de tenofovir 300<br>mg VO 1x/dia<br>+|
||Comprimido de lamivudina 150 mg|2 comprimidos de lamivudina<br>150 mg VO 1x/dia|
|Dolutegravir (DTG)|Comprimido de 50 mg|Tomar 1 comprimido VO<br>1 x/dia|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: **Observação sobre o uso de darunavir 600 mg associado a ritonavir 100 mg em gestantes:** -->
Para gestantes nas quais os 28 dias preconizados de uso da PEP se encontrem dentro do período gestacional e/ou próximo ao parto, recomenda-se em caso de contraindicação ou intolerância ao dolutegravir, que este deve ser substituído por darunavir 600 mg associado a ritonavir 100 mg, ambos em duas administrações diárias até o parto. Após o parto, a substituição para dose única diária (darunavir 800 mg) deve ser indicada quando não houver documentação prévia ou recente de mutações de resistência a darunavir, associada a ritonavir 100 mg, ambos 1 vez ao dia.  
14  
Qualquer modificação ou substituição da apresentação do darunavir (de 600 mg para 800 mg) poderá ser realizada no parto ou cerca de 3 semanas após o parto, devido às modificações do metabolismo e volume de distribuição farmacológicos desse medicamento no puerpério.  
O esquema com **tenofovir 300 mg/lamivudina 300 mg + dolutegravir 50 mg é o esquema preferencial para indicação de PEP para mulheres com intenção de engravidar ou gestantes, independentemente da idade gestacional.**

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.12. Crianças e adolescentes -->
A profilaxia pós-exposição de risco à infecção pelo HIV é uma medida de prevenção para crianças e adolescentes expostos à acidente com material perfurocortante<sup>32</sup> , à violência sexual<sup>33</sup> , e para adolescentes com exposição sexual de risco.  
O **Quadro 10** elenca as doses de ARV utilizados na profilaxia por faixa etária e peso.  
**Quadro 10.** Esquemas preferenciais e alternativos para PEP-HIV com duração de 4 semanas.  
|**Faixa Etária**|**Esquemapreferencial**|**Medicamentos alternativos**|
|---|---|---|
|0 a 4 semanas de vida|**Baixo risco de exposição**<br>**ao HIV:**<br>Zidovudina - em qualquer<br>IG (em semanas).<br>**Alto risco de exposição**<br>**ao HIV:**<br>Zidovudina + lamivudina +<br>raltegravir<br>-<br>(IG:<br>37<br>semanas ou mais).<br>**ou**<br>Zidovudina + lamivudina +<br>nevirapina - (IG: 34 a 37<br>semanas)<br>**ou**<br>Zidovudina - (IG: menos de<br>34 semanas)|Zidovudina + lamivudina +<br>nevirapina -(IG: 37 semanas ou<br>mais).|
|Acima de 4 semanas de<br>vida até 6 anos|Zidovudina + lamivudina<br>+ dolutegravir 5 mg<sup>a</sup>|Impossibilidade do uso de<br>dolutegravir:<br>lopinavir/ritonavir<br>**ou**<br>darunavir<sup>d</sup>/ritonavir|
|6 a 12 anos|Zidovudina+ lamivudina+<br>dolutegravir 50 mg<sup>c</sup>|Impossibilidade do uso de<br>dolutegravir:|  
15  
|**Faixa Etária**|**Esquemapreferencial**|**Medicamentos alternativos**|
|---|---|---|
||**ou**<br>Tenofovir<sup>b</sup>+ lamivudina +<br>dolutegravir 50 mg<sup>c</sup>|darunavir/ritonavir<br>**ou**<br>lopinavir/ritonavir.|
|12 anos ou mais|Tenofovir<sup>b</sup>+ lamivudina +<br>dolutegravir 50 mg<sup>c</sup><br>**ou**<br>Zidovudina+ lamivudina+<br>dolutegravir 50 mg<sup>c</sup>|Impossibilidade do uso de<br>dolutegravir:<br>darunavir/ritonavir|  
Fonte: DATHI/SVSA/MS  
aPeso igual ou maior que 3 kg; bPeso igual ou maior que 35 kg; cPeso igual ou maior que 20 kg; dPeso maior ou igual a 15 kg  
Observações:  
- Dolutegravir 5 mg comprimido dispersível a partir do 2º mês de vida e peso igual ou superior a 3 kg. Dolutegravir 50 mg comprimido acima de 6 anos e com peso corporal superior a 20 kg.  
- Darunavir para crianças maiores de 3 anos e com peso igual ou superior a 15 kg, que consigam deglutir o comprimido.  
- Tenofovir indicado com peso corporal a partir de 35 kg.  
- Para maiores informações quanto às posologias por faixas etárias recomenda-se consultar o **PCDT de Manejo da infecção pelo HIV em crianças e adolescentes/2023** – Módulo 2 vigente<sup>13</sup> , disponível em: <u>https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts .</u>  
- Considerar a classificação de risco de exposição ao HIV para definição de esquema na faixa etária de 0 à 4 semanas, conforme capítulo de “Profilaxia antirretroviral no recém-nascido exposto ao HIV” – “Diagnóstico, manejo e acompanhamento de crianças expostas ao HIV” - PCDT de Manejo da infecção pelo HIV em crianças e adolescentes - Módulo 1 vigente, disponível em: https://www.gov.br/aids/ptbr/central-de-conteudo/pcdts.  
Em cenários com possibilidade de exposição de risco ao HIV (baixo ou alto risco), como em realização incompleta de seguimento pré-natal e/ou ausência de resultados dos exames sorológicos diagnósticos, **em que tenha ocorrido amamentação** , recomenda-se:  
- imediata interrupção da amamentação, com orientações de extração e descarte do leite pós ordenha, além de demais cuidados com as mamas, enquanto se indica investigação diagnóstica;  
- prosseguir com investigação diagnóstica da infecção pelo HIV da pessoa que amamentou, e avaliação de indicação de PEP-HIV e demais IST da mesma;  
- coletar amostra para carga viral do HIV (CV-HIV) do RN e;  
- início da PEP ao recém-nascido exposto, preferencialmente nas primeiras horas e em até 72 horas, simultaneamente à investigação diagnóstica.  
Para mais informações e esquemas ARV indicados para profilaxia do recém-nascido exposto, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes”<sup>12,13</sup> , disponível em https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts.  
Para os adolescentes, o acesso a serviços, orientações e consultas deve ser garantido **sem** a necessidade de presença ou autorização de pais ou responsáveis, com direito à privacidade e sigilo de opiniões e condutas, salvo em situações de necessidade de internação ou de risco de vida, conforme previsto no Estatuto da Criança e do Adolescente (ECA).  
16  
Os dados sobre o uso de ARV são extrapolados do tratamento dos lactentes, crianças e adolescentes que vivem com HIV<sup>33</sup> . Pelo risco de hipersensibilidade grave e indisponibilidade de tempo para verificar HLA*B5701, o abacavir (ABC) está contraindicado como PEP na população pediátrica. As maiores evidências em crianças referem-se ao esquema contendo zidovudina + lamivudina (AZT + 3TC), com taxas de descontinuação menores que as encontradas em adultos<sup>34</sup> . Considerando segurança e facilidade de prescrição, recomenda-se tenofovir+lamivudina (TDF + 3TC) para PEP em crianças com peso corporal a partir de 35 kg (indicação do tenofovir).  
Os estudos favorecem lopinavir/ritonavir (LPV/r) como terceiro medicamento do esquema preferencial em relação à nevirapina em menores de dois anos<sup>35;36</sup> . Após os dois anos, o uso da nevirapina é contraindicado pelo risco de reação de hipersensibilidade grave em crianças que não viviam com o HIV 37.  
O perfil de toxicidade do raltegravir em crianças e adolescentes de dois a 18 anos de idade é comparável ao observado em adultos<sup>18</sup> . Para aquelas com idade maior que seis anos e peso superior a 20 kg, seguem-se as recomendações para adultos, com o dolutegravir indicado como terceiro medicamento 22,38.  
Com a incorporação do INI **dolutegravir 5 mg** comprimido dispersível, recomenda-se seu uso para crianças vivendo com HIV/aids (CVHA) com **idade igual ou superior a quatro semanas de vida e com peso superior a 3 kg** .  
Desta forma, **dolutegravir 5 mg** comprimido dispersível é o **medicamento preferencial** em **terapia ARV inicial** e nas indicações de **profilaxia pós exposição** ao HIV, para crianças entre quatro semanas (um mês) e seis anos de idade (com peso corporal de 3 kg a 19 kg).  
Não há dados suficientes sobre a segurança e a eficácia de dolutegravir comprimidos dispersíveis em crianças com idade inferior a 4 semanas ou menos de 3 kg.  
Em **crianças acima de 6 anos e com peso corporal superior a 20 kg,** pode ser utilizado o **dolutegravir 50 mg** comprimido revestido, uma vez ao dia. Em crianças com esse peso corporal, o uso de dolutegravir 5 mg comprimido dispersível é restrito àquelas que não conseguem deglutir comprimidos.  
Recomenda-se, ainda, aumentar a dose de dolutegravir, administrando-o duas vezes ao dia (a cada 12 horas) se ele for usado associado ao efavirenz, carbamazepina e rifampicina.  
Para demais recomendações quanto ao preparo e diluição dos comprimidos dispersíveis de dolutegravir 5 mg, recomenda-se consultar a bula do medicamento aprovada pela ANVISA<sup>39</sup> .  
Para mais informações, consultar os módulos do “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes”<sup>12,13</sup> disponível em: https://www.gov.br/aids/pt- <u>br/central-de-conteudo/pcdts.</u>

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.13. Parcerias sorodiferentes -->
Pessoas vivendo com HIV em uso regular de TARV e que mantêm a carga viral indetectável não transmitem o HIV por via sexual. Os primeiros estudos realizados não encontraram nenhum caso de transmissão sexual quando a CV-HIV era inferior a 200 cópias/mL.<sup>40,41</sup> . Nesse sentido, o conceito que relaciona supressão viral é **indetectável = intransmissível = risco zero de transmissão**<sup>42</sup> .  
Recente revisão sistemática e um guia da Organização Mundial da Saúde evidenciam que, nos estudos revisados, não houve transmissão sexual do HIV em pessoas com carga viral inferior a 600 cópias/mL, tendo-se identificado duas possíveis transmissões, não confirmadas, com carga viral entre 600 e 1.000 cópias. Sendo assim, o risco de transmissão sexual a partir de pessoas vivendo com HIV (PVHA) com carga viral inferior a 1.000 cópias/mL é incomum<sup>43, 44</sup> .  
**A divulgação do conceito** **_I=I= Risco zero de transmissão_ é fundamental não apenas para as PVHA, mas também para as parcerias.**  
17  
Para a oferta ou não de PEP como mais uma medida de Prevenção Combinada a ser oferecida para as parcerias sorodiferentes, deve-se considerar:  
- Perfil da parceria vivendo com HIV quanto à adesão à TARV;  
- Supressão da CV-HIV;  
- Identificação de práticas sexuais de risco com outras parcerias.  
No que se refere à parceria que não vive com HIV, é fundamental reforçar a autonomia em relação ao seu corpo, às suas práticas preventivas e ao grau de exposição a que deseja se submeter, considerando que esta não é responsável pelas condutas da outra pessoa, por exemplo, no que se refere à tomada regular do medicamento.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.14. Participantes em pesquisa clínica de vacinas de HIV com indicação de PEP -->
Vacinas para o HIV em fase de pesquisa clínica podem induzir eventos denominados soropositividade ou sororreatividade induzida por vacina (do inglês _Vaccine Induced Seropositivity/Seroreactivitiy - VISP/R_ ), nos quais ocorre a produção de anticorpos anti-HIV que podem gerar resultados falsos-reagentes em imunoensaios utilizados para o diagnóstico da infecção pelo HIV. Estes anticorpos poderão permanecer detectáveis por vários anos e podem interferir na interpretação do resultado de testes diagnósticos em pessoas que participaram como voluntários.  
Recomenda-se que, considerando o prazo necessário para início da profilaxia (até 72 horas após o contato de risco), a dispensação de PEP não deve ser postergada em casos de resultados reagentes no imunoensaio de triagem quando se tratar de pessoas com potencial de soropositividade/sororreatividade induzida por vacina de HIV. A coleta de amostra para quantificação de carga viral deve ser realizada imediatamente após o resultado do imunoensaio e antes que a pessoa inicie a profilaxia. Após o retorno dos resultados do teste de carga viral, deve-se avaliar:  
a) Caso não se confirme a infecção: a manutenção da PEP; ou  
b) Caso seja confirmada a infecção: o encaminhamento para iniciar o acompanhamento clínico e o início da TARV.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.15. Adesão à PEP -->
Deve-se esclarecer a pessoa exposta sobre a menor toxicidade dos atuais esquemas de ARV.  
A adesão das pessoas para completar os 28 dias de uso dos ARV é essencial para a maior efetividade da profilaxia. Todavia, os estudos publicados mostram baixas proporções de pessoas que completaram a PEP<sup>45</sup> , principalmente entre adolescentes e aquelas que sofreram violência sexual<sup>46,47</sup> .  
A pessoa exposta deve ser orientada quanto aos objetivos da PEP, de modo a observar rigorosamente as doses, os intervalos de uso e a duração da profilaxia antirretroviral. Algumas estratégias de acompanhamento e adesão podem incluir os seguintes métodos alternativos: mensagens ou alarmes pelo  
18  
celular, uso de aplicativos, diários, porta-pílulas, tabelas, mapas de doses, associação da tomada dos comprimidos a alguma atividade rotineira e diária, e ligações telefônicas.  
Recomenda-se a dispensação do esquema completo de PEP (28 dias), uma vez que essa estratégia tem impacto positivo na adesão<sup>48</sup> .  
- 5.16. Descarte do medicamento  
A profilaxia é realizada por 28 dias; entretanto, a quantidade contida nas embalagens é de 30 comprimidos. Não se recomenda a dispensação fracionada dos medicamentos. O descarte dos medicamentos não utilizados é definido de acordo com a legislação local e a organização de cada estado.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.17. Acompanhamento clínico-laboratorial -->
O acompanhamento clínico-laboratorial da pessoa exposta em uso de PEP deve considerar:  
- Avaliação de medos e expectativas pós-exposição de risco ao HIV;  
- Toxicidade dos ARV;  
- Testagem para HIV;  
- Avaliação laboratorial;  
- Manutenção de medidas de Prevenção Combinada do HIV.  
No caso de atendimento em serviços de urgência e emergência ou situação em que não seja possível o acompanhamento clínico-laboratorial no mesmo local que foi realizado o primeiro atendimento e prescrição de PEP, é importante a articulação com o serviço em que o acompanhamento possa ser realizado. O serviço de referência da pessoa exposta em uso de PEP pode ser um SAE/CTA (serviço de atenção especializada/Centro de Testagem e Aconselhamento) ou serviço de APS (atenção primária à saúde), conforme fluxos locais.  
- 5.18. 5.17 Abordagem para perda de seguimento do usuário de PEP.  
Existem desafios quanto ao retorno e seguimento dos usuários de PEP, relativos ao retorno para realizar nova testagem de HIV e outras IST. Neste sentido, recomenda-se a possibilidade da entrega de kits de autoteste de HIV para realização desse monitoramento, além da possibilidade de realizar abordagem consentida para busca dos casos.  
- 5.19. Avaliação da toxicidade dos ARV  
As pessoas expostas que iniciam a PEP devem ser orientadas a procurar atendimento caso surjam quaisquer sinais ou sintomas clínicos que possam sugerir toxicidade medicamentosa grave.  
19  
Os esquemas atuais apresentam baixa toxicidade e menos efeitos adversos. Quando presentes, os sintomas em geral são inespecíficos, leves e autolimitados, tais como efeitos gastrointestinais, cefaleia e fadiga. As alterações laboratoriais são geralmente discretas, transitórias e pouco frequentes.  
Na presença de intolerância medicamentosa, a pessoa exposta deve ser reavaliada para adequação do esquema terapêutico. Na maioria das vezes, não é necessária a interrupção da profilaxia, resolvendo-se a intolerância com utilização de medicamentos sintomáticos.  
Recomenda-se monitorar ativamente sinais e sintomas da infecção aguda pelo HIV. Após a transmissão do HIV, algumas pessoas podem apresentar quadro clínico semelhante à síndrome de mononucleose infecciosa, geralmente na terceira e quarta semana após a exposição.  
Os sinais e sintomas da infecção aguda pelo HIV estão descritos no **Quadro 11** .  
**Quadro 11.** Sinais e sintomas da infecção aguda pelo HIV  
|Febre<br>Linfadenopatias<br>Faringite<br>Exantema<br>Ulcerações mucocutâneas|Mialgias<br>Artralgias<br>Fadiga<br>Hepatoesplenomegalia|
|---|---|  
Fonte: DATHI/SVSA/MS.  
Na presença de sinais e sintomas de infecção aguda pelo HIV, é recomendada investigação laboratorial para infecção pelo HIV, com a detecção do RNA (CV-HIV).

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.20. Testagem para HIV -->
Todas as pessoas potencialmente expostas ao HIV devem ser orientadas sobre a necessidade de repetir a testagem em 30 dias após a exposição, mesmo depois de completada a profilaxia com ARV.  
Para mais informações sobre testagem para HIV, consultar o “Manual Técnico para o Diagnóstico da Infecção pelo HIV”<sup>16</sup> , disponível em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuaistecnicos-para-diagnostico.</u>  
Pessoas diagnosticadas com HIV durante o período de seguimento da PEP devem ser encaminhadas para avaliação e atendimento em serviços que realizam o seguimento de PVHIV.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.21. Prevenção durante o uso de PEP -->
Durante o acompanhamento, a pessoa exposta deve ser orientada a manter medidas de prevenção à infecção pelo HIV, como o uso de preservativos em todas as relações sexuais e o não compartilhamento de seringas e agulhas nos casos de uso de drogas injetáveis, além da contraindicação de doação de sangue, órgãos, tecidos ou esperma e da importância de prevenção da gravidez.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.22. Seguimento laboratorial -->
A indicação de exames laboratoriais deve considerar as condições de saúde pré-existentes da pessoa exposta e a toxicidade conhecida dos ARV indicados para PEP. Os exames laboratoriais não devem se configurar como barreira para a oferta de PEP e devem ser realizados conforme recomendação do **Quadro 12** .  
20  
**Quadro 12.** Seguimento laboratorial de PEP.  
|**Exames**|**Primeiro atendimento**<sup>**d**</sup>|**Para**<br>**investigação de**<br>**efeitos adversos**|**4ª semana**<br>**após início da**<br>**PEP**|**12ª semana**<br>**após início da**<br>**PEP**|
|---|---|---|---|---|
|Creatinina<sup>a</sup>|Para pessoas de alto risco ou com<br>históriaprévia de doença renal|**X**|||
|ALT,AST||**X**|||
|Amilase||**X**|||
|Glicemia|Em caso de pessoas exposta com<br>diabete melito|**X**|||
|Hemograma<sup>b</sup>|Quando indicação de PEP com<br>zidovudina|**X**|||
|Teste de HIV<sup>c</sup>|**X**||**X**|**X**|  
Fonte: DATHI/SVSA/MS.  
a Para cálculo da depuração de creatinina.  
b Para pacientes com suspeita de anemia. O exame não deve atrasar o início da PEP.  
c Não se recomenda a utilização de teste de fluido oral.  
- 5.22 Indicação de PrEP após completude do esquema de PEP por 28 dias  
Após concluir o uso de PEP por 28 dias, recomenda-se a avaliação individualizada da possibilidade de indicação de PrEP para aquelas pessoas que relatam repetidas situações de exposição e vulnerabilidades à sua saúde sexual em seu contexto de vida.  
Caso o usuário tenha indicação de PrEP, recomenda-se seu início imediatamente após o término da PEP.  
Para informações sobre PrEP, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV”<sup>3</sup> , disponível em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts.</u>  
Indivíduos com indicação de PEP podem ser futuros candidatos à PrEP. A transição para a PrEP pode ser feita após os 28 dias de uso da PEP e exclusão de infecção pelo HIV.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 5.23 Painel PEP e serviços de acesso à PEP -->
O DATHI/SVSA/MS disponibiliza o painel de monitoramento da Profilaxia Pós-Exposição (PEP), elaborado com o intuito de divulgar informações sobre a dispensação e o uso da PEP. Para acessar o painel PEP, clique aqui.  
Além disso, é possível saber a localização atualizada de serviços de saúde que oferecem a PEP. Para acessar o painel para localizar serviços que disponibilizam a PEP, clique aqui.  
21

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: RASTREAMENTO E PROFILAXIA DAS INFECÇÕES SEXUALMENTE TRANSMISSÍVEIS -->
Recomenda-se a investigação de sinais/sintomas de IST em todas as pessoas com exposição sexual de risco e avaliação de tratamento imediato.  
As IST constituem importante problema de saúde pública, com elevados custos sociais e econômicos<sup>49</sup> . A presença de uma IST está associada à infecção e à transmissão do HIV. Toda exposição de risco ao HIV também deve ser avaliada como de risco para outras IST<sup>50-53</sup> .  
A investigação ativa de sinais/sintomas de IST deverá incluir suas principais manifestações clínicas: corrimento vaginal, corrimento uretral, úlceras genitais e verrugas anogenitais. Entretanto, é importante pontuar que muitas pessoas com IST são assintomáticas ou apresentam sinais e sintomas leves e não percebem alterações<sup>54</sup> .  
Recomenda-se testagem para sífilis em todas as pessoas com exposição sexual de risco.  
Quando possível, testar a pessoa-fonte.  
O rastreio das IST é fundamental para o controle da epidemia de sífilis, já que o diagnóstico precoce e o tratamento oportuno das pessoas infectadas e de suas parcerias sexuais contribuem para interromper a cadeia de transmissão<sup>55</sup> .  
As IST são frequentemente assintomáticas nas mulheres e, quando não detectadas e tratadas, levam a complicações mais graves, como sífilis congênita, doença inflamatória pélvica (DIP), gravidez ectópica e infertilidade<sup>54</sup> . Portanto, a investigação deve basear-se no risco e não somente nos sinais e sintomas<sup>56</sup> .  
Em relação às mulheres vítimas de violência sexual, as infecções mais encontradas são tricomoníase e infecção por _Chlamydia trachomatis_ ou _Neisseria gonorrhoeae_<sup>51</sup> .

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 6.1. Rastreamento da sífilis -->
A infecciosidade da sífilis por transmissão sexual ocorre principalmente nos estágios iniciais da doença (sífilis primária, secundária e latente recente). Essa maior transmissibilidade explica-se pela intensa multiplicação do patógeno e pela riqueza de treponemas nas lesões, comuns na sífilis primária e secundária. Essas lesões são raras ou inexistentes por volta do segundo ano da infecção.  
O diagnóstico de sífilis deve ser estabelecido por meio da associação de critérios epidemiológicos, clínicos e resultados de testes diagnósticos. Em cada atendimento, recomenda-se avaliação clínica, incluindo exame físico, o que permite a investigação completa para sífilis<sup>54</sup> .  
Para o diagnóstico da sífilis, devem ser realizados os testes treponêmico e não treponêmico. Considerando a epidemia de sífilis no Brasil e a sensibilidade dos fluxos de diagnóstico, **recomenda-se iniciar a investigação pelo teste treponêmico** (teste rápido, FTA-Abs, Elisa, entre outros).  
Os TR fornecidos pelo Ministério da Saúde são **testes treponêmicos** . Tais exames não necessitam de estrutura laboratorial e são de fácil execução, com leitura do resultado em, no máximo, 30 minutos. Podem ser realizados com amostras de sangue total colhidas por punção venosa ou por punção digital, além de soro e plasma.  
A **Figura 3** descreve os testes imunológicos para diagnóstico de sífilis.  
22  
<!-- Start of picture text -->
, Teste / Testendo ~ \<br>/ treponémico \ / treponémico \ / ; \<br>REAGENTE REAGENTE _ Diagndstico<br>| | -Teste rapido | } id | | - VDRLP |an |\ contende sifilis |<br>be - FTA-Abs- ELISA p <> \ - TRUST-RPR / /<br><!-- End of picture text -->  
**Figura 3. Testes imunológicos para diagnóstico de sífilis**  
Fonte: DATHI/SVSA/MS.  
*O diagnóstico de sífilis não estará confirmado quando houver presença de cicatriz sorológica, ou seja, persistência de resultados reagentes nos testes treponêmicos e/ou não treponêmicos com baixa titulação após o tratamento adequado, afastada a possibilidade de reinfecção.  
Nos locais em que não for possível realizar os testes rápidos, recomenda-se seguir o fluxo laboratorial e agendar o retorno para verificação do resultado. Para mais informações, consultar o “Manual Técnico para Diagnóstico de Sífilis”<sup>57</sup> , disponível em <u>https://www.gov.br/aids/pt-br/central-deconteudo/manuais-tecnicos-para-diagnostico.</u>  
As pessoas com teste rápido **<u>reagente</u>** devem ter amostra coletada para um teste não treponêmico complementar, conforme **Figura 4** . Entretanto, devido ao cenário epidemiológico atual, recomenda-se tratamento imediato nas seguintes situações:  
- Gestante;  
- Pessoa com risco de perda do seguimento;  
- Caso de violência sexual;  
- Pessoa com sinais/sintomas de sífilis primária ou secundária;  
- Pessoa sem diagnóstico prévio de sífilis.  
A realização **do tratamento com apenas um teste reagente para sífilis** não exclui a necessidade de realização do segundo teste (conforme fluxogramas de diagnóstico), do monitoramento laboratorial (controle de cura) e do tratamento das parcerias sexuais (interrupção da cadeia de transmissão).  
As pessoas com teste rápido **<u>não reagente</u>** devem ser acompanhadas conforme a **Figura 4** . Se, durante o seguimento, o exame tornar-se **<u>reagente,</u>** <u>é diagnosticada sífilis recente, com indicação de</u> tratamento imediato (benzilpenicilina benzatina 2,4 milhões de UI IM em dose única).  
Para mais informações sobre sífilis, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis”<sup>54</sup> , disponível em <u>https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts.</u>  
23  
<!-- Start of picture text -->
Teste rapido (treponémico) REAGENTE |<br>ae = Trat form:<br>ae.nas fargs  conformerieracor ts<br>‘ infecc&o<br>| Nao<br>E gestante? ou<br>Sim Ha risco de perda de Nao<br>seguimento? ou<br>Houve violéncia sexual? ou<br>Sem diagnéstico prévio<br>de sifilis?<br>Tratar como sifilis latente tardia com Avaliar resultados dos testes<br>3 doses de penicilina benzatina 2,4 laboratoriais complementares (ex.<br>milhdes UI IM com intervalo de 7 VDRL, RPR) para definicao de<br>dias® e solicitar teste nao tratamento, se necessario<br>treponémico<br>Realizar a primeira dose no mesmo<br>momentoe local do atendimento<br>‘Se teste nao treponémico NAO.<br>REAGENTE®, suspender<br>tratamento.<br><!-- End of picture text -->  
**Figura 4.** Fluxograma de conduta frente a teste rápido reagente (treponêmico). Fonte: DATHI/SVSA/MS.  
a Para casos de violência sexual, realizar profilaxia pós-exposição com penicilina benzatina 2,4 milhões UI IM em dose única, independentemente do resultado do teste rápido. bEm não gestantes, o intervalo entre as doses não deve exceder 14 dias. Em gestantes, não deve exceder 9 dias. Caso isso ocorra, o esquema deve ser reiniciado. c Recomenda-se realizar um terceiro teste treponêmico com metodologia diferente do primeiro para conclusão diagnóstica.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 6.2. Investigação clínico-laboratorial das infecções causadas por gonococo ou por clamídia -->
As manifestações clínicas de infecções por _C. trachomatis_ ou _N. gonorrhoeae_ incluem dor pélvica, DIP e gravidez ectópica. Quando acometem o órgão genital masculino, esses microrganismos são agentes etiológicos frequentes de uretrites, com ocorrência de corrimento uretral. No entanto, na população geral, também é possível ocorrer infecções extragenitais por clamídia e gonococo, como infecção em reto (proctite), faringe e conjuntiva ocular.  
Para a investigação de _C. trachomatis_ ou _N. gonorrhoeae_ , recomenda-se o teste de amplificação de ácidos nucleicos (biologia molecular) específicos para IST. O teste é realizado por meio da urina (primeiro jato) ou com _swabs_ em cada local de mucosa exposta a fluidos corporais potencialmente infectados (cavidade oral, vaginal, uretral e retal, colo uterino).  
24

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 6.3. Investigação da tricomoníase -->
A investigação de tricomoníase deve se basear no surgimento de corrimento vaginal. Em caso de pessoa sintomática, proceder à avaliação clínica. Para mais informações sobre tricomoníase e outras causas de corrimento vaginal, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis”<sup>54</sup> , disponível em <u>https://www.gov.br/aids/ptbr/central-de-conteudo/pcdts .</u>

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 6.4. Investigação e prevenção da infecção pelo HPV -->
Orientar todas as pessoas expostas sexualmente sobre as medidas de prevenção do HPV.  
O HPV é transmitido preferencialmente por via sexual, sendo responsável por verrugas na região anogenital e até em áreas extragenitais como conjuntivas e mucosa nasal, oral e laríngea<sup>58,59</sup> , além de estar relacionado ao câncer de colo de útero<sup>60</sup> , colorretal<sup>61</sup> , pênis, vulva e vagina<sup>62,63</sup> .  
O tempo de latência viral e os fatores associados não são conhecidos, e o HPV pode permanecer quiescente por muitos anos até o desenvolvimento de lesões, não sendo possível estabelecer o intervalo mínimo entre a infecção e o aparecimento destas.  
As lesões podem localizar-se na glande, sulco bálano-prepucial, região perianal, vulva, períneo, vagina e colo do útero. Menos frequentemente, podem estar presentes em áreas extragenitais, como conjuntivas e mucosa nasal, oral e laríngea.  
Para as mulheres que evoluem <u>sem lesões,</u> é fundamental reforçar a importância de realizar periodicamente o exame preventivo de colo de útero (conhecido também como Papanicolaou), o que pode ser feito na Atenção Primária à Saúde (APS). Para mais informações, consultar as “Diretrizes para o Rastreamento do Câncer do Colo do Útero”<sup>64</sup> , disponíveis em: <u>https://www.inca.gov.br/publicacoes/livros/diretrizes-brasileiras-para-o-rastreamento-do-cancer-do-colodo-utero</u>  
O Ministério da Saúde indica a vacinação para HPV em meninos e meninas de 9 a 14 anos. O esquema é composto de duas doses, com intervalo de seis meses.  
Para PVHA, pessoas transplantadas de órgãos sólidos ou medula óssea e pacientes oncológicos, a faixa etária indicada para imunização é de 9 até 45 anos para homens e mulheres, sendo o esquema de vacinação composto por três doses (0, 2 e 6 meses).  
A vacina de HPV também é prevista para vítimas de violência sexual, homens e mulheres, de nove a 45 anos, que porventura ainda não foram vacinados<sup>65</sup> .  
Se, durante o atendimento, for realizado o diagnóstico clínico de HPV, é necessário realizar o acompanhamento clínico no serviço de saúde ou referenciar para serviços de saúde que o façam, de acordo com a organização da Rede de Atenção à Saúde (RAS) do local.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 6.5. Profilaxia das IST -->
O tratamento preemptivo para profilaxia das IST somente é recomendado para pessoas vítimas de violência sexual, uma vez que há perda de seguimento de muitas delas e o tratamento baseado no diagnóstico etiológico nem sempre é possível<sup>51,66</sup> .  
O **Quadro 13** elenca o tratamento para profilaxia das IST em situação de violência sexual.  
25  
**Quadro 13.** Tratamento para profilaxia das IST em situação de violência sexual  
|||**Posologi**|**a**|
|---|---|---|---|
|**IST**|**Medicamento**|**Adultos e adolescentes com**<br>**mais de 45 kg**|**Crianças e**<br>**adolescentes com**<br>**menos de 45 kg**|
|Sífilis|Penicilina G<br>benzatina|2,4 milhões UI, IM (1,2<br>milhão UI em cada glúteo)<sup>a</sup>|50.000UI/kg, IM<sup>a</sup><br>(dose máxima total:<br>2,4 milhões UI).|
|Infecção por_N._<br>_gonorrohoeae_e_C._<br>_trachomatis_|Ceftriaxona<br>+<br>Azitromicina|Ceftriaxona 500 mg, 1 frasco-<br>ampola, IM, dose única<br>**MAIS**<br>Azitromicina 500 mg, 2<br>comprimidos de 250 mg, VO,<br>dose única (Dose total: 1 g)|Ceftriaxona 125 mg,<br>IM, dose única<br>**MAIS**<br>Azitromicina<br>20<br>mg/kg,<br>VO,<br>dose<br>única (Dose máxima<br>total: 1 g)|
|Tricomoníase|Metronidazol<sup>b,c</sup>|400 mg, 5 comprimidos, VO,<br>dose única (Dose total: 2g).<br>**ou**<br>250 mg, 8 comprimidos VO,<br>dose única (Dose total: 2g).|15<br>mg/kg/dia,<br>divididos a cada 8<br>horas, por 7 dias<br>(Dose diária máxima:<br>2 g).|  
Fonte: DATHI/SVSA/MS.  
a Como profilaxia e em caso de sífilis recente, deve ser prescrito em dose única.  
b Não deve ser prescrito no primeiro trimestre de gestação.  
c Seu uso deverá ser postergado em caso de uso de contracepção de urgência ou ARV.  
Nas pessoas com exposição sexual consentida, a realização de investigação laboratorial e seguimento clínico é o procedimento mais recomendável, devido ao risco de desenvolvimento de resistência bacteriana com o tratamento preemptivo<sup>50,67</sup> .  
Para mais informações sobre IST e violência sexual, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis”<sup>54</sup> , disponível em https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts.  
O **Quadro 14** apresenta o seguimento da investigação das IST.  
**Quadro 14.** Seguimento dos testes diagnósticos para profilaxia de IST em pessoas pós-exposição  
de risco  
|||**Pessoa-fonte**|**Pess**|**oa exposta**|
|---|---|---|---|---|
|**IST**||**1º atendimento**|**1º atendimento**|**4 a 6 semanas após**<br>**exposição**<sup>**b**</sup>|
|**Teste**<br>**treponêmico**<br>**sífilis (TR)**<sup>**a**</sup>|**para**|Sim|Sim|Sim|
|**Testagem**<br>**para**<br>**_gonorrhoeae_**<sup>a</sup>|**_N._**|Sim|Sim|Sim|  
26  
|||**Pessoa-fonte**|**Pess**|**oa exposta**|
|---|---|---|---|---|
|**IST**||**1º atendimento**|**1º atendimento**|**4 a 6 semanas após**<br>**exposição**<sup>**b**</sup>|
|**Testagem**<br>**para**<br>**_trachomatis_**<sup>a</sup>|**_C._**|Sim|Sim|Sim|  
Em todas as consultas, investigar presença de sinais e sintomas de IST.  
Fonte: DATHI/SVSA/MS.  
> a A testagem para sífilis, _N. gonorrohoeae_ e _C. trachomatis_ deve ocorrer nessas ocasiões, exceto nos casos de acidente com material biológico.  
> b Realiza-se testagem para sífilis, _N. gonorrhoeae_ e _C. trachomatis_ em 4 a 6 semanas se a testagem no primeiro atendimento for negativo.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: PROFILAXIA DAS HEPATITES VIRAIS -->
As hepatites virais são causadas por diferentes agentes etiológicos, que têm em comum o tropismo primário pelo tecido hepático. Podem se apresentar como infecções agudas ou crônicas, além de constituírem uma das maiores causas de transplantes hepáticos no mundo<sup>68,69</sup> .  
No âmbito da Prevenção Combinada, toda situação de exposição deve também ser avaliada quanto ao risco de exposição às hepatites virais.  
Neste PCDT, serão abordadas as formas de profilaxia pós-exposição aos vírus das hepatites A, B  
e C.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.1. Hepatite A -->
Recomenda-se avaliar todo paciente com exposição sexual de risco ao HIV para um eventual episódio de infecção aguda pelo vírus da hepatite A.  
O principal mecanismo de transmissão do vírus da hepatite A (HAV) é o fecal-oral, relacionado principalmente às condições de saneamento básico, higiene pessoal e qualidade da água e dos alimentos. A transmissão sexual desse vírus é infrequente.  
No entanto, recentemente, diversos casos de transmissão sexual do vírus da hepatite A foram confirmados em vários países da Europa e na cidade de São Paulo. A maioria dos casos parece ocorrer entre homens que fazem sexo com homens, embora essa forma de transmissão também tenha sido observada entre mulheres. A magnitude da transmissão por via sexual é provavelmente subestimada<sup>70-73</sup> .  
A transmissão sexual do HAV provavelmente limita o benefício da prevenção por meio do uso exclusivo de preservativos, devendo-se complementar a prevenção com outras medidas, como a higienização das mãos, genitália, períneo e região anal antes e após as relações sexuais.  
A hepatite A é uma infecção aguda do fígado, autolimitada, clinicamente indistinguível de outras formas de hepatite viral aguda. O risco de sintomas e de apresentação mais grave aumenta com a idade. Enquanto a maioria dos casos em menores de cinco anos é assintomática e menos de 10% apresentam icterícia, a proporção de casos ictéricos pode passar de 70% em adolescentes e adultos. O quadro sintomático caracteriza-se pela presença de astenia, tonturas, náusea e/ou vômitos, febre, dor abdominal,  
27  
pele e olhos amarelados (icterícia), urina escurecida e fezes claras. A sintomatologia costuma aparecer em aproximadamente quatro semanas (variando de 15 a 50 dias) após a exposição ao HAV.  
Caso seja possível, deve-se verificar a susceptibilidade do paciente exposto por meio da pesquisa de exame sorológico específico (anti-HAV IgG ou total). A presença de anti-HAV IgG (ou total) reagente demonstra imunidade da pessoa exposta e, portanto, nenhuma medida adicional se faz necessária.  
Por outro lado, caso a pesquisa dos anticorpos seja não reagente, deve-se observar a indicação de vacinação da pessoa exposta, obedecendo-se aos critérios de vacinação para essa infecção dispostos no Manual do CRIE vigente. A vacina para hepatite A é eficaz (97,6% em menores de 40 anos) como PEP quando administrada dentro de duas semanas da exposição.  
Já a presença de anti-HAV IgM reagente é indicativo de episódio agudo de infecção por esse vírus.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.2. Hepatite B -->
Recomenda-se realizar testagem para hepatite B da pessoa exposta e da pessoa-fonte (quando <u>presente).</u>  
Para pessoas com exposição sexual consentida, a realização de investigação laboratorial e seguimento clínico é o procedimento mais recomendável, devido ao risco de desenvolvimento de resistência bacteriana com o tratamento preemptivo<sup>51,67</sup> .<sup>.</sup>  
A hepatite B é uma infecção de transmissão parenteral, sexual e vertical. A transmissão desse vírus pode ocorrer por solução de continuidade (pele e mucosas), via parenteral (compartilhamento de agulhas, seringas, material de manicure e pedicure, lâminas de barbear e depilar, tatuagens, _piercings_ , procedimentos odontológicos ou cirúrgicos que não atendam às normas de biossegurança, entre outros) e relação sexual desprotegida. Esta última via é o principal mecanismo de transmissão dessa infecção no Brasil. Os líquidos orgânicos, como sangue, sêmen, secreção vaginal e exsudato de feridas podem conter o vírus e representam importantes fontes de infecção.  
Quando da utilização da PEP para HIV, é importante avaliar se a pessoa exposta não está previamente infectada pelo vírus da hepatite B, no sentido de investigar a presença de HBsAg e o antecedente de tratamento para essa infecção. Os antirretrovirais tenofovir e lamivudina (medicamentos utilizados para a PEP do HIV) são ativos em relação ao HBV e uma eventual descontinuação desses medicamentos (quando da descontinuação da PEP) pode ocasionar um _flare_ das enzimas hepáticas ou mesmo quadros de descompensação da doença hepática prévia<sup>51,74</sup> .

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.2.1. Diagnóstico da infecção pelo vírus da hepatite B -->
A triagem da infecção pelo HBV é realizada por meio de testes rápidos de detecção do antígeno de superfície do vírus da hepatite B (HBsAg). Os TR são práticos e de fácil execução, com leitura do resultado em, no máximo, 30 minutos. Podem ser realizados com amostras de sangue total colhidas por punção venosa ou digital. Devido à rapidez e segurança do resultado, este é o exame mais indicado. Nos locais em que não for possível realizar os TR, deve-se seguir o fluxo laboratorial. Mais informações podem ser encontradas no “Manual Técnico para o Diagnóstico das Hepatites Virais”<sup>75</sup> , disponível em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/manuais-tecnicos-para-diagnostico.</u>  
28  
- 7.2.2. Interpretação do _status_ sorológico da pessoa exposta por meio da pesquisa de HBsAg por teste rápido  
- **Se reagente:** a infecção pelo HBV ocorreu antes da exposição que motivou o atendimento, devendo ser coletada uma amostra para complementação do diagnóstico, conforme preconizado pelo Manual Técnico para Diagnóstico das Hepatites Virais, e para acompanhamento clínico.  
- **Se não reagente:** a pessoa exposta não tem, no momento da testagem, evidências de infecção atual pelo HBV, devendo-se seguir as orientações do **Quadro 15** . Quando houver disponibilidade, é recomendável avaliar o status sorológico da pessoa-fonte quanto à hepatite B.  
- **Se inválido:** não é possível confirmar o _status_ sorológico da pessoa exposta. Recomenda-se repetir o teste, se possível, com um conjunto diagnóstico de lote distinto do que foi utilizado inicialmente. Persistindo o resultado inválido, uma amostra deverá ser coletada por punção venosa e encaminhada para teste com um dos fluxogramas definidos para laboratório.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.2.3. Prevenção da infecção pelo vírus da hepatite B -->
A prevenção dessa infecção ocorre por meio da vacinação, testagem e do uso eventual de imunoglobulina humana anti-hepatite B (IGHAHB).

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.2.4. Vacinação para hepatite B -->
Três doses de vacina contra a hepatite B induzem títulos protetores de anticorpos (anti-HBs maior ou igual a 10 UI/mL) em mais de 90% dos adultos e dos jovens sadios, e em mais de 95% dos lactentes, das crianças e dos adolescentes.  
Recomenda-se imunizar todas as pessoas expostas não previamente vacinadas, ou sem documentação de vacinação prévia, e sem indícios de infecção por HBV (HBsAg não reagente), independentemente da idade.  
Se possível, a primeira dose da vacina deve ser administrada no momento do primeiro atendimento e, preferencialmente, dentro de 24 horas da exposição naqueles com indicação, conforme o **Quadro 15** . As demais doses deverão seguir as recomendações vigentes do Programa Nacional de Imunizações, podendo ser aplicadas na unidade básica de saúde mais próxima do local de residência da pessoa.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.2.5. Utilização de IGHAHB -->
O conhecimento do _status_ sorológico da **pessoa-fonte** em relação à hepatite B é importante para a decisão sobre a utilização ou não da IGHAHB. Diferentemente do que ocorre na exposição ao HIV, para a hepatite B, a indicação da IGHAHB dependerá do tipo de exposição (vítimas de acidentes com material biológico contaminado ou fortemente suspeito de infecção por HBV; comunicantes sexuais de casos agudos de hepatite B; vítimas de violência sexual; imunodeprimidos após exposição de risco, mesmo que previamente vacinados), conforme indicação do Manual dos Centros de Referência para Imunobiológicos Especiais (CRIE)<sup>76</sup> .  
A IGHAHB deve ser administrada em dose única de 0,06 mL/kg, por via intramuscular, em extremidade diferente da que recebeu a vacina para HBV, com dose máxima de 5 mL, podendo ser utilizada  
29  
de forma simultânea à vacina para hepatite B, porém em locais diferentes. A IGHAHB deve ser **administrada, no máximo, até 14 dias após a exposição sexual e, para exposições percutâneas, no máximo até sete dias)** , embora se recomende o uso nas primeiras 24 horas a contar da exposição ( **Quadro 15** ). O medicamento está disponível nos CRIE.  
**Quadro 15.** Recomendações de profilaxia de hepatite B para indivíduos com HBsAg não reagente após exposição ocupacional a material biológico.  
|**Situação vacinal e**||**Pessoa-fonte**||
|---|---|---|---|
|**sorologia do**<br>**profissional de saúde**||**HBsAg**<br>||
|<br>**exposto**|**reagente**|**não reagente**|**desconhecido**|
|Não vacinado|IGHAHB + iniciar<br>vacinação|Iniciar vacinação|Iniciar vacinação<sup>a</sup>|
|Vacinação incompleta|IGHAHB + completar<br>vacinação|Completar vacinação|Completar vacinação<sup>a</sup>|
|Resposta vacinal<br>conhecida e adequada<br>(anti-HBs maior ou<br>igual 10 mUI/mL)|Nenhuma medida|Nenhuma medida|Nenhuma medida|
|Sem resposta vacinal<br>após primeira série de<br>doses(3 doses)|IGHAHB + primeira<br>dose da segunda série<br>vacinalpara hepatite B<sup>b</sup>|Iniciar nova série de<br>vacina (três doses)|Iniciar nova série (três<br>doses)<sup>a</sup>|
|Sem resposta vacinal<br>após segunda série (6<br>doses)|IGHAHB (2x)<sup>b</sup>|Nenhuma medida<br>específica|IGHAHB (2x)<sup>b</sup>|
|Com resposta vacinal<br>desconhecida|Testar o(a) profissional<br>de saúde para anti-<br>HBs<sup>c</sup><br>Se resposta vacinal<br>adequada: nenhuma<br>medida específica<br>Se resposta vacinal<br>inadequada: IGHAHB<br>+ primeira dose da<br>vacina hepatite B ou<br>IGHAHB (2x) se dois<br>esquemas vacinais<br>prévios|Testar o(a) profissional<br>de saúde para anti-<br>HBs<sup>c</sup><br>Se resposta vacinal<br>adequada: nenhuma<br>medida específica<br>Se resposta vacinal<br>inadequada: fazer<br>segunda série de<br>vacinação ou nenhuma<br>medida específica se<br>dois esquemas vacinais<br>prévios|Testar o(a) profissional<br>de saúde para anti-<br>HBs<sup>c</sup><br>Se resposta vacinal<br>adequada: nenhuma<br>medida específica<br>Se resposta vacinal<br>inadequada: fazer<br>segunda série de<br>vacinação<sup>(a)</sup>ou<br>nenhuma medida<br>específica se dois<br>esquemas vacinais<br>prévios|  
Fonte: Brasil, 2023<sup>76</sup> .  
a O uso associado de imunoglobulina humana anti-hepatite B está indicado em caso de pessoa-fonte com alto risco para infecção pelo HBV, como: usuários de drogas; pacientes em programas de diálise; contatos domiciliares e sexuais de pessoas HBsAg reagentes; pessoas com várias parcerias sexuais e/ou relações sexuais desprotegidas; história prévia de IST; pacientes provenientes de áreas geográficas de alta endemicidade para hepatite B; pacientes provenientes de prisões ou outras formas de institucionalização. b IGHAHB (2x) = duas doses de imunoglobulina humana anti-hepatite B, com intervalo de um mês entre as doses. Essa opção deve ser indicada para aqueles que já fizeram duas séries de três doses da vacina, mas não apresentaram resposta vacinal, ou que tenham alergia grave à vacina. c Se o resultado da testagem para anti-HBs não estiver disponível dentro de 48 horas deve-se seguir a conduta como “resposta vacinal inadequada”.  
A imunização para a hepatite B e o uso de IGHAHB são seguros e também estão indicados na gestação, em qualquer idade gestacional, ou durante o aleitamento.  
30  
Para mais informações, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e Coinfecções”<sup>77</sup> , disponível em https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts.  
- 7.2.6. Recomendação para profilaxia de hepatite B após exposição sexual, em pessoas suscetíveis 7.2.6.1. Comunicantes sexuais de casos agudos de hepatite B  
Deve-se buscar identificar a situação da pessoa exposta quanto à hepatite B. Caso essa pessoa seja suscetível, estão indicadas a vacina contra hepatite B e a IGHAHB, aplicadas o mais precocemente possível (preferencialmente nas primeiras 24 horas), podendo ser utilizadas até, no máximo, 14 dias depois da exposição em locais anatômicos diferentes<sup>76</sup> .  
**IGHAHB e vacina contra hepatite B** são recomendadas como profilaxia para pessoas suscetíveis com exposição sexual de risco à pessoa com **hepatite B aguda** .

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.2.6.2. Vítimas de violência sexual -->
Para pessoas presumidamente suscetíveis expostas a pessoas vivendo com HBV (HBsAg reagente) ou pertencentes a grupos de alto risco de infecção pelo HBV (usuários de drogas, pessoas em diálise, contatos de pessoas com hepatite B, pessoas com múltiplas relações sexuais desprotegidas, pessoas provenientes de áreas de alta endemicidade para hepatite B, pessoas privadas de liberdade ou pessoas em instituições de longa permanência) por agressão sexual, está indicada a administração de IGHAHB e vacina hepatite B recombinante (HB) o mais precocemente possível (preferencialmente nas primeiras 24 horas), as quais podem ser utilizadas até, no máximo, 14 dias depois da exposição, em locais anatômicos diferentes 76.  
**IGHAHB e vacina contra hepatite B são recomendadas como profilaxia** para pessoas suscetíveis, expostas a portadores conhecidos ou potenciais do vírus da hepatite B por **violência sexual** .

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.3. Hepatite C -->
Apesar do risco de transmissão do HCV estar mais relacionado às exposições percutâneas, a transmissão sexual desse vírus é possível, principalmente em se tratando de práticas sexuais traumáticas, presença de doença ulcerativa genital e proctites relacionadas a IST. Grupos específicos, como homens que fazem sexo com homens, PVHA e pessoas com outras imunodeficiências também têm risco acrescido de contágio pela via sexual<sup>78-80</sup> . Mesmo não existindo medida específica eficaz para redução do risco de infecção pelo HCV após a exposição, a testagem da pessoa-fonte e da pessoa exposta é recomendada para permitir o diagnóstico precoce e tratamento oportuno de uma possível infecção, que, com os medicamentos atuais, apresenta taxas de cura acima de 95%.  
A investigação inicial da infecção pelo HCV é feita com a pesquisa por anticorpos contra o vírus (anti-HCV) por meio de TR ou um imunoensaio laboratorial convencional. No entanto, a detecção do antiHCV isoladamente indica apenas exposição ao HCV, havendo necessidade de detecção da CV-HCV (HCVRNA) para definição de um caso de infecção ativa. Mais informações podem ser encontradas no “Manual Técnico para Diagnóstico das Hepatites Virais”<sup>75</sup> , disponível em https://www.gov.br/aids/pt-br/centrais-de- <u>conteudo/manuais-tecnicos-para-diagnostico.</u>  
Recomenda-se realizar testagem para hepatite C na pessoa-fonte e na pessoa exposta.  
31  
- 7.3.1. Interpretação do status sorológico da pessoa exposta por meio da pesquisa de anti-HCV por testes rápidos  
- **Se reagente:** a pessoa teve contato com o vírus da hepatite C antes da exposição que motivou o atendimento, devendo-se coletar uma amostra para complementação do diagnóstico, conforme preconizado pelo Manual Técnico para Diagnóstico das Hepatites Virais, realizar a notificação e encaminhar a pessoa para acompanhamento clínico.  
- **Se não reagente** : a pessoa exposta não tem, no momento da testagem, sinal de contato prévio com o vírus. Quando possível, avaliar o _status_ sorológico da pessoa-fonte quanto à hepatite C.  
- **Se inválido** : não é possível confirmar o _status_ sorológico da pessoa exposta. Recomenda-se repetir o teste, se possível, com um conjunto diagnóstico de lote distinto do que foi utilizado inicialmente. Persistindo o resultado inválido, uma amostra deverá ser coletada por punção venosa e encaminhada para teste com o fluxograma definido para laboratório, conforme o “Manual Técnico para Diagnóstico das Hepatites Virais”<sup>75</sup> .  
- 7.3.2. Interpretação do status sorológico da pessoa-fonte por meio da pesquisa de anti-HCV  
- **Se reagente** : acompanhar a pessoa exposta, pelo risco de soroconversão e necessidade de tratamento da infecção aguda. Além disso, deve-se confirmar ou excluir a presença de infecção ativa da pessoa-fonte com exame de CV-HCV, para definir seguimento ambulatorial e necessidade de tratamento da hepatite C;  
- **Se não reagente** : não há risco de soroconversão para pessoa exposta. Não é necessário acompanhamento sorológico da pessoa exposta em relação a essa infecção;  
- **Se desconhecido ou indeterminado** : avaliar caso a caso, com base na gravidade da exposição e na probabilidade clínica e epidemiológica de infecção pelo vírus da hepatite C.  
Contudo, é necessário considerar a janela diagnóstica para detecção de anticorpos, que varia de 33 a 129 dias. Há a possibilidade de resultados falso-negativos de testes imunológicos de diagnóstico (rápidos ou laboratoriais) durante o período de “janela” imunológica. Por isso, se houver história epidemiológica relacionável à infecção pelo HCV no período de janela, recomenda-se testar a pessoa-fonte mais uma vez ao fim do período de janela e realizar acompanhamento sorológico da pessoa exposta.  
O diagnóstico precoce da soroconversão e/ou detectabilidade do HCV-RNA durante o seguimento do paciente exposto possibilita o tratamento ainda na fase aguda da infecção pelo HCV, o que, além de evitar a perda do seguimento, possui impacto na redução de novas transmissões e auxilia na eliminação desse agravo. Portanto, recomenda-se o seguimento conforme o **Quadro 16** .  
**Quadro 16.** Seguimento da pessoa exposta quando a fonte for reagente para hepatite C.  
|**Tempo pós-**<br>**exposição**|**T**<br>**Anti-HCV**|**estagem laboratori**<br>**HCV-RNA**|**al**<br>**ALT**|**Comentário**|
|---|---|---|---|---|
|**Fonte**|||||
|Imediatamente (até<br>48 horas)|Sim|Testar se anti-<br>HCV reagente|Não|Pode-se avaliar a utilização de<br>HCV-RNA mesmo com sorologia<br>negativa em pacientes com<br>imunossupressão grave|
|**Exposto**|||||  
32  
|**Tempo pós-**|**T**|**estagem laborato**|**rial**|**á**|
|---|---|---|---|---|
|**exposição**|**Anti-HCV**|**HCV-RNA**|**ALT**|**Comentrio**|
|Imediatamente (até<br>48 horas)|Sim<sup>a</sup>|Testar se anti-<br>HCV reagente|Sim|Não há necessidade de<br>seguimento se fonte não<br>apresentar infecção ativa pelo<br>HCV. Entretanto, a testagem<br>basal do exposto é aconselhável|
|4 a 6 semanas|Sim<sup>b</sup>|Sim<sup>b</sup>|Considerar|Não utilizar o teste molecular<br>isoladamente, devido às variações<br>na viremia durante infecções<br>agudas|
|4 a 6 meses|Sim<sup>b</sup>|Sim<sup>b</sup>|Sim|-|  
Fonte: DATHI/SVS/MS.  
> a Anti-HCV reagente no 1º atendimento: **pessoa previamente exposta** ; portanto, teve contato com o HCV antes da exposição que motivou o atendimento. Deve ser encaminhada para confirmação laboratorial do caso e para acompanhamento clínico.  
b A soroconversão do anti-HCV e/ou detectabilidade do HCV-RNA após a primeira consulta do indivíduo exposto indica infecção aguda pelo HCV, devendo o paciente ser encaminhado para tratamento da infecção e acompanhamento clínico.  
7.3.3. Infecção aguda pelo HCV após exposição sexual ou não sexual Definição de hepatite C aguda:  
- Soroconversão recente (há menos de seis meses) e documentada por meio da conversão do antiHCV (anti-HCV não reagente no início dos sintomas ou no momento da exposição, com conversão para anti-HCV reagente na segunda dosagem, realizada com intervalo de 90 dias); **OU**  
- Anti-HCV não reagente e detecção da CV-HCV em até 90 dias depois do início dos sintomas ou da data da exposição, quando esta for conhecida em indivíduos com histórico de exposição potencial ao HCV.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 7.3.4. Identificação e tratamento precoce da hepatite C -->
Cerca de 25% dos pacientes com hepatite aguda apresentam resolução espontânea, enquanto a maioria evolui com persistência e cronificação da infecção. Um único exame de carga viral indetectável não é suficiente para definir resolução espontânea, devido às flutuações na viremia durante a fase aguda. Entretanto, não se aconselha aguardar uma possível resolução espontânea, devido ao risco de transmissão a outras pessoas (especialmente em HSH e usuários de drogas injetáveis) e de perda de seguimento.  
Portanto, recomenda-se o tratamento precoce de todas as pessoas com infecção ativa pelo HCV (CV-HCV detectável), tanto aguda como crônica, com raras exceções. As recomendações de tratamento da hepatite C aguda são as mesmas dos indivíduos com infecção crônica. Orientações sobre esquemas terapêuticos indicados, monitoramento e seguimento após o tratamento da hepatite C estão disponíveis no PCDT para Hepatite C e coinfecções<sup>81</sup> , disponível em <u>https://www.gov.br/aids/pt-br/central-deconteudo/pcdts .</u>  
Além disso, indivíduos diagnosticados com hepatite C aguda devem ser aconselhados a reduzir comportamentos associados à transmissão do vírus, como compartilhar instrumentos para uso de substâncias injetáveis ou inalatórias e participar de práticas sexuais de alto risco (p. ex., _chemsex_ , sexo grupal, compartilhamento de objetos sexuais, _fisting_ ). Caso o paciente apresente histórico de uso recente  
33  
de drogas injetáveis, ele deve receber cuidados para redução de danos e ser referenciado para especialistas em dependência química.  
O tratamento da hepatite C, aguda ou crônica, com antivirais de ação direta pangenotípicos, tem taxas de cura maiores que 95%.  
A única forma de reduzir o risco de transmissão do HCV é a prevenção do acidente. As orientações para prevenção das hepatites virais devem ser compartilhadas com os contatos domiciliares e parcerias sexuais da pessoa. A prevenção requer atitudes e práticas seguras – como o uso adequado do preservativo e o não compartilhamento de instrumentos perfurocortantes e objetos de higiene pessoal, como escovas de dente, alicates de unha, lâminas de barbear ou depilar. Para mais informações, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Hepatite C e Coinfecções”<sup>81</sup> , disponível em <u>https://www.gov.br/aids/pt-br/central-de-conteudo/publicacoes.</u>

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 8.1. Cuidados com a área exposta -->
Nos casos de exposições percutânea e cutânea, recomendam-se, como primeira conduta após a exposição a material biológico, os cuidados imediatos em relação à área atingida. Essas medidas incluem a lavagem exaustiva do local exposto com água e sabão. Também podem ser utilizadas soluções antissépticas degermantes. Não se recomenda espremer da região isolada.  
Nas exposições envolvendo mucosas (olhos, boca e nariz), deve-se lavá-las exaustivamente apenas com água ou com solução salina fisiológica. Estão contraindicados procedimentos que ampliem a área exposta (cortes, injeções locais) e a utilização de soluções irritantes, como éter, hipoclorito ou glutaraldeído.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 8.2. Anticoncepção de emergência e abordagem na concepção -->
O diagnóstico de gravidez pode alterar a assistência à pessoa com IST, além de contraindicar a anticoncepção de emergência. Portanto, a pessoa deve ser investigada sobre atraso menstrual e presença de sinais e sintomas de gravidez. Caso estes estejam presentes, o teste de gravidez é recomendado.  
A anticoncepção de emergência deve ser considerada nas pessoas em idade fértil, após relação sexual desprotegida ou se houve falha do método contraceptivo, caso não exista desejo de engravidar e seja excluída gravidez no atendimento inicial.  
O método mais adequado para a **anticoncepção de emergência** consiste na utilização do **levonorgestrel** , em função de evidentes vantagens sobre o método de Yuzpe (uso de hormônios combinados), como: efeitos colaterais sensivelmente reduzidos, menor interação com outros medicamentos e maior efetividade.  
O **Quadro 17** descreve a apresentação e o esquema de administração da anticoncepção de emergência.  
34  
**Quadro 17.** Apresentação e posologia do levonorgestrel.  
|**Apresentação**|**Posologia**|
|---|---|
|Comprimidos de 0,75 mg (cartela com 2<br>comprimidos) e 1,5 mg de levonorgestrel|**1ª opção**– 1 comprimido de 1,5 mg VO ou 2<br>comprimidos de 0,75 mg, dose única, até 5 dias após a<br>relação sexual<sup>a</sup>|
|(cartela com 1 comprimido)|**2ª opção**– 1 comprimido de 0,75 mg VO de 12/12<br>horas, totalizando 2 comprimidos, até 5 dias após a<br>relação sexual<sup>a</sup>|  
Fonte: DATHI/SVSA/MS.  
a A eficácia é sempre maior quanto mais próximo da relação a anticoncepção de emergência for utilizada.  
O uso repetitivo da anticoncepção de emergência diminui sua eficácia; portanto, não se trata de um método a ser adotado como rotina. Para mais informações, consultar o “Protocolo para Utilização do Levonorgestrel”<sup>82</sup> .  
O **Quadro 18** descreve a investigação laboratorial da gravidez na pessoa exposta.  
**Quadro 18.** Investigação laboratorial de gravidez.  
|**Exame**|**Pessoa ex**<br>**1º atendimento**|**posta**<br>**4 a 6 semanas após exposição**|
|---|---|---|
|Teste<br>de<br>gravidez|Sim, se atraso menstrual ou presença de<br>sinais e sintomas de gravidez|Sim, se primeiro teste negativo|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: 8.3. Imunização para tétano -->
As pessoas que tenham sofrido mordeduras, lesões ou cortes devem ser avaliadas quanto à necessidade de imunização para tétano. Para mais informações, consultar o “Guia de Vigilância em Saúde”<sup>83</sup> , disponível em https://bvsms.saude.gov.br/bvs/publicacoes/guia_vigilancia_saude_6ed_v3.pdf

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: VIOLÊNCIA SEXUAL -->
A violência sexual, crime previsto no art. 213 do Código Penal Brasileiro, pode ser definida como qualquer tipo de atividade de natureza erótica ou sexual que desrespeite o direito de escolha de um dos envolvidos.  
As consequências mais prevalentes da violência sexual são estresse pós-traumático (23,3%), transtorno de comportamento (11,4%) e gravidez (7,1%). Deve-se salientar, entretanto, que a proporção de vítimas que ficaram grávidas como consequência do estupro cresce para 15,0%, quando se consideram apenas os casos em que houve penetração vaginal e a faixa etária entre 14 e 17 anos<sup>84</sup> .  
Crianças e adolescentes que sofrem violência sexual podem apresentar queixas vagas que, à primeira vista, não levam o(a) profissional a suspeitar dessa situação<sup>85,86</sup> . Portanto, é necessário que os(as) profissionais de saúde mantenham alto grau de suspeição.  
35  
O **Quadro 19** destaca possíveis sinais de abuso sexual. A seção 9 trata sobre os procedimentos de notificação.  
**Quadro 19.** Sinais de violência sexual em crianças e adolescentes.  
- Edema ou lesões em área genital, sem outras doenças que os justifiquem (como infecções ou traumas acidentais evidenciáveis);  
- Lesões de palato ou de dentes anteriores, decorrentes de sexo oral;  Sangramento vaginal em pré-púberes, excluindo a introdução de corpo estranho pela própria criança;  
- Sangramento, fissuras ou cicatrizes anais, dilatação ou flacidez de esfíncter anal sem presença de doença que os justifiquem (como constipação intestinal grave e crônica);  
- Rompimento himenal;  IST;  Gravidez;  Abortamento. Fonte: Brasil, 2014<sup>87</sup> e Brasil, 2015<sup>88</sup> .  
O **Quadro 20** resume os cuidados às pessoas vítimas de violência sexual.  
**Quadro 20.** Cuidados às pessoas vítimas de violência sexual.  
- Atendimento clínico-laboratorial, psicológico e social imediato;  
- Providências policiais e judiciais cabíveis (entretanto, caso a vítima não as tome, não lhe pode ser negado atendimento);  
- Anticoncepção de emergência e profilaxia das IST não virais e do HIV;  Vacinação e imunoglobulina para HBV;  Vacinação para HPV e Hepatite A, quando indicado;  Realização de testagem rápida para HIV, sífilis, hepatites virais B e C ou coleta de material para avaliação do _status_ sorológico, para seguimento e conduta específica;  
- Teste para investigação de _C. trachomatis_ ou _N. gonorrhoeae_ ;  Agendamento de retorno para seguimento sorológico após 30 dias e acompanhamento clínicolaboratorial, <u>psicológico e social, quando indicado.</u>  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: PROCEDIMENTOS DE VIGILÂNCIA EPIDEMIOLÓGICA -->
A notificação do caso à Vigilância Epidemiológica e a compreensão desta como parte das ações de gestão em saúde (planejamento, tomada de decisão, programações, monitoramento/avaliação) é parte fundamental da prevenção e promoção da saúde.  
Os casos de HIV/aids, sífilis e hepatites virais diagnosticados durante o atendimento de PEP devem ser notificados como agravos de notificação compulsória no Sinan por meio da ficha de investigação do respectivo agravo.  
Já os casos de acidentes relacionados ao trabalho devem ser notificados no Sinan por meio da **ficha de investigação de acidente de trabalho com exposição a material biológico** . Nesses casos, devem-se estabelecer procedimentos de análise dos acidentes similares acontecidos na unidade, segundo diretrizes da Política de Promoção da Saúde dos Trabalhadores do SUS<sup>89</sup> .  
36  
Nos casos de violência sexual, deve-se notificar o evento por meio da **ficha de notificação individual de violência interpessoal/autoprovocada,** atualizada em 2015.  
Nos casos de criança e suspeita de violência, deve-se notificar também o Conselho Tutelar local. Para esses casos, o **Quadro 21** detalha os procedimentos de notificação.  
**Quadro 21.** Procedimentos de notificação.  
- Preencher a ficha de notificação;  
- Encaminhar a ficha ao Sistema de Vigilância de Violências e Acidentes (Viva), da Secretaria Municipal de Saúde (SMS);  
- Comunicar o caso ao Conselho Tutelar da forma mais rápida possível (por telefone, ou pessoalmente, ou com uma via da ficha de notificação);  
- Anexar cópia da ficha ao prontuário/boletim do paciente;  Acionar o Ministério Público, quando necessário, especialmente no caso de interrupção de <u>gravidez em decorrência de violência sexual.</u>  
Fonte: Brasil, 2014<sup>87</sup> .  
As referidas fichas de notificação/investigação encontram-se disponíveis em <u>https://portalsinan.saude.gov.br/</u>  
OFERTA DE PEP NA REDE DE ATENÇÃO À SAÚDE  
A oferta de PEP pode acontecer na rede pública ou privada, com dispensação exclusiva do medicamento pela rede pública. O formulário de dispensação de ARV para profilaxias está disponível em <u>http://azt.aids.gov.br/.</u>  
Cabe à rede privada adequar sua referência pública de dispensação de ARV para que a orientação à pessoa seja efetiva. Para mais informações sobre o planejamento das ações e a organização local da rede de PEP, consultar as “Diretrizes para a Organização da Rede de Profilaxia Antirretroviral Pós-Exposição de Risco à Infecção pelo HIV”<sup>5</sup> .  
Este Protocolo simplificou a utilização dos ARV, assim como a avaliação de risco, tornando possível o atendimento de qualquer tipo de exposição em todos os serviços. Diante desse contexto, destacase a importância de ampliar o acesso à PEP, por meio de sua efetiva prescrição nos atendimentos em serviços de urgência/emergência, unidades básicas de saúde, clínicas e hospitais da rede pública e privada, além de Centros de Testagem e Aconselhamento (CTA).  
Portanto, a linha de cuidado para PEP deve considerar a diversidade de organização da rede de saúde e a disponibilidade de serviços existentes em cada território. Além disso, o acesso a todas as medidas de Prevenção Combinada dependerá da estrutura do serviço de saúde.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: REFERÊNCIAS -->
1. Ministério da Saúde. Secretaria de Atenção à Saúde. Acolhimento e classificação de risco nos serviços de urgência. 2010 [citado 27 de novembro de 2023]; Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/acolhimento_classificaao_risco_servico_urgencia.pdf  
2. WHO. The use of co-trimoxazole prophylaxis for HIV-related infections among adults, adolescents and children. 2013 WHO consolidated guidelines on the use of antiretroviral drugs for treating and  
37  
preventing HIV infection [Internet]. 2014 [citado 6 de fevereiro de 2024];(7):28–34. Disponível em: http://www.who.int/hiv/pub/guidelines/arv2013/December2014-ARVsupplement-chap8.pdf  
3. Brasil. Ministério da Saúde, Secretaria de Vigilância em Saúde. Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV. Ministério da Saúde, Secretaria de Ciência TI e IE em S de V em S, organizadores. 2022 [citado 19 de fevereiro de 2024];1–52. Disponível em: https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts  
4. Linn JG, Rawls A. Handbook of HIV Prevention. Soc Sci J. 1<sup>o</sup> de junho de 2002;39(2):309–10.  
5. Departamento de HIV/Aids THV e IST. 2016. [citado 27 de novembro de 2023]. Diretrizes para organização da Rede de profilaxia Antirretroviral Pós-Exposição de Risco à Infecção pelo HIV - PEP. Disponível em: https://www.gov.br/aids/pt-br/central-deconteudo/publicacoes/2016/diretrizes_para_a_organizacao_da_rede_de_profilaxi_31931.pdf/view  
6. Grangeiro A, Ferraz D, Calazans G, Zucchi EM, Díaz-Bermúdez XP. The effect of prevention methods on reducing sexual risk for HIV and their potential impact on a large-scale: A literature review. Revista Brasileira de Epidemiologia. 1<sup>o</sup> de setembro de 2015;18:43–62.  
7. Ferraz D, Paiva V. Sex, human rights and AIDS: An analysis of new technologies for HIV prevention in the brazilian context. Revista Brasileira de Epidemiologia. 1<sup>o</sup> de setembro de 2015;18:89–103.  
8. Brasil. Ministério da Saúde. Prevenção Combinada do HIV/Bases conceituais para profissionais, trabalhadores(as) e gestores(as) de saúde. Secretaria de Vigilância em Saúde Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/Aids e das Hepatites Virais. 2017;  
9. Tsai CC, Follis KE, Sabo A, Beck TW, Grant RF, Bischofberger N, et al. Prevention of SIV infection in macaques by (R)-9-(2-phosphonylmethoxypropyl)adenine. Science [Internet]. 1995 [citado 6 de fevereiro de 2024];270(5239):1197–9. Disponível em: https://pubmed.ncbi.nlm.nih.gov/7502044/  
10. Tsai CC, Emau P, Follis KE, Beck TW, Benveniste RE, Bischofberger N, et al. Effectiveness of Postinoculation (R)-9-(2-Phosphonylmethoxypropyl)Adenine Treatment for Prevention of Persistent Simian Immunodeficiency Virus SIVmne Infection Depends  Critically on Timing of Initiation and  Duration of Treatment. J Virol [Internet]. maio de 1998 [citado 6 de fevereiro de 2024];72(5):4265. Disponível em: /pmc/articles/PMC109656/  
11. Otten RA, Smith DK, Adams DR, Pullium JK, Jackson E, Kim CN, et al. Efficacy of postexposure prophylaxis after intravaginal exposure of pig-tailed macaques to a human-derived retrovirus (human immunodeficiency virus type 2). J Virol [Internet]. 15 de outubro de 2000 [citado 5 de fevereiro de 2024];74(20):9771–5. Disponível em: https://pubmed.ncbi.nlm.nih.gov/11000253/  
12. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Protocolo Clínico e Diretrizes Terapêuticas Manejo da Infecção pelo HIV em Crianças e Adolescentes Módulo 1 - Diagnóstico, manejo e acompanhamento de crianças expostas ao HIV. 2023 [citado 19 de fevereiro de 2024]; Disponível em: https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts  
13. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Protocolo Clínico e Diretrizes Terapêuticas Manejo da Infecção pelo HIV em Crianças e Adolescentes Módulo 2: Diagnóstico, manejo e tratamento de crianças e adolescentes vivendo com HIV. 2023 [citado 19 de fevereiro de 2024]; Disponível em: https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts  
14. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos - Módulo II - Coinfecções. 2023 [citado 19 de fevereiro de 2024]; Disponível em: https://www.gov.br/aids/pt-br/central-deconteudo/pcdts  
15. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos - Módulo I - Tratamento.  
38  
2023 [citado 14 de fevereiro de 2024]; Disponível em: https://www.gov.br/aids/pt-br/central-deconteudo/pcdts  
16. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância P e C das IST do H e das HV. MANUAL TÉCNICO PARA O DIAGNÓSTICO DA INFECÇÃO PELO HIV EM ADULTOS E CRIANÇAS. 2018 [citado 27 de novembro de 2023]; Disponível em: https://www.gov.br/aids/pt-br/central-de-  
conteudo/publicacoes/2018/manual_tecnico_hiv_27_11_2018_web.pdf  
17. Cresswell F, Asanati K, Bhagani S, Boffito M, Delpech V, Ellis J, et al. UK guideline for the use of HIV post-exposure prophylaxis 2021. HIV Med [Internet]. 1<sup>o</sup> de maio de 2022 [citado 5 de fevereiro de 2024];23(5):494–545. Disponível em: https://pubmed.ncbi.nlm.nih.gov/35166004/  
18. Dominguez KL, Smith DK, Vasavi Thomas, Crepaz N, Lang K, Heneine W, et al. Updated guidelines for antiretroviral postexposure prophylaxis after sexual, injection drug use, or other nonoccupational exposure to HIV—United States, 2016 [Internet]. 2016 [citado 5 de fevereiro de 2024]. Disponível em: https://stacks.cdc.gov/view/cdc/38856  
19. EACS Guidelines [Internet]. EACSociety. Disponível em: https://www.eacsociety.org/guidelines/eacs-guidelines/  
20. WHO. Consolidated Guidelines on the Use of Antiretroviral Drugs for Treating and Preventing HIV Infection. Consolidated Guidelines on the Use of Antiretroviral Drugs for Treating and Preventing HIV Infection: Recommendations for a Public Health Approach [Internet]. 2016 [citado 6 de fevereiro de 2024];(2016):XXXii. Disponível em: https://www.ncbi.nlm.nih.gov/books/NBK374294/  
21. Ford N, Mayer KH, Barlow L, Bagyinszky F, Calmy A, Chakroun M, et al. World Health Organization Guidelines on Postexposure Prophylaxis for HIV: Recommendations for a Public Health Approach. Clin Infect Dis [Internet]. 2015 [citado 5 de fevereiro de 2024];60 Suppl 3:S161– 4. Disponível em: https://pubmed.ncbi.nlm.nih.gov/25972497/  
22. WHO. WHO. 2019 [citado 6 de fevereiro de 2024]. Update of recommendations on first- and second-line antiretroviral regimens. Disponível em: https://www.who.int/publications/i/item/WHO-CDS-HIV-19.15  
23. Valin N, Fonquernie L, Daguenel A, Campa P, Anthony T, Guiguet M, et al. Evaluation of tolerability with the co-formulation elvitegravir, cobicistat, emtricitabine, and tenofovir disoproxil fumarate for post-HIV exposure prophylaxis. BMC Infect Dis [Internet]. 29 de novembro de 2016 [citado 6 de fevereiro de 2024];16(1). Disponível em: https://pubmed.ncbi.nlm.nih.gov/27894270/  
24. Nanda K, Stuart GS, Robinson J, Gray AL, Tepper NK, Gaffield ME. Drug interactions between hormonal contraceptives and antiretrovirals. AIDS [Internet]. 4 de abril de 2017 [citado 5 de fevereiro de 2024];31(7):917. Disponível em: /pmc/articles/PMC5378006/  
25. Song IH, Borland J, Chen S, Wajima T, Peppercorn AF, Piscitelli SC. Dolutegravir Has No Effect on the Pharmacokinetics of Oral Contraceptives With Norgestimate and Ethinyl Estradiol. Ann Pharmacother [Internet]. 20 de julho de 2015 [citado 6 de fevereiro de 2024];49(7):784–9. Disponível em: https://pubmed.ncbi.nlm.nih.gov/25862012/  
26. Tittle V, Bull L, Boffito M, Nwokolo N. Pharmacokinetic and Pharmacodynamic Drug Interactions Between Antiretrovirals and Oral Contraceptives. Clin Pharmacokinet [Internet]. 1<sup>o</sup> de janeiro de 2015 [citado 6 de fevereiro de 2024];54(1):23–34. Disponível em: https://link.springer.com/article/10.1007/s40262-014-0204-8  
27. Wong D, Littlejohn M, Edwards R, Jackson K, Revill P, Gaggar A, et al. ALT flares during nucleotide analogue therapy are associated with HBsAg loss in genotype A HBeAg-positive chronic hepatitis B. Liver Int [Internet]. 1<sup>o</sup> de outubro de 2018 [citado 6 de fevereiro de 2024];38(10):1760–9. Disponível em: https://pubmed.ncbi.nlm.nih.gov/29427368/  
39  
28. Solomon MM, Schechter M, Liu AY, McManhan VM, Guanira J V., Hance RJ, et al. The Safety of Tenofovir-Emtricitabine for HIV Pre-Exposure Prophylaxis (PrEP) in Individuals With Active Hepatitis B. J Acquir Immune Defic Syndr [Internet]. 2016 [citado 6 de fevereiro de 2024];71(3):281–6. Disponível em: https://pubmed.ncbi.nlm.nih.gov/26413853/  
29. Fätkenheuer G, Jessen H, Stoehr A, Jung N, Jessen AB, Kümmerle T, et al. PEPDar: A randomized prospective noninferiority study of ritonavir-boosted darunavir for HIV post-exposure prophylaxis. HIV Med [Internet]. 1<sup>o</sup> de junho de 2016 [citado 6 de fevereiro de 2024];17(6):453–9. Disponível em: https://pubmed.ncbi.nlm.nih.gov/27166295/  
30. Clotet B, Feinberg J, Van Lunzen J, Khuong-Josses MA, Antinori A, Dumitru I, et al. Once-daily dolutegravir versus darunavir plus ritonavir in antiretroviral-naive adults with HIV-1 infection (FLAMINGO): 48 week results from the randomised open-label phase 3b study. Lancet [Internet]. 2014 [citado 5 de fevereiro de 2024];383(9936):2222–31. Disponível em: https://pubmed.ncbi.nlm.nih.gov/24698485/  
31. Rimawi BH, Johnson E, Rajakumar A, Tao S, Jiang Y, Gillespie S, et al. Pharmacokinetics and Placental Transfer of Elvitegravir, Dolutegravir, and Other Antiretrovirals during Pregnancy. Antimicrob Agents Chemother [Internet]. 1<sup>o</sup> de junho de 2017 [citado 5 de fevereiro de 2024];61(6). Disponível em: /pmc/articles/PMC5444129/  
32. Gaur AH, Dominguez KL, Kalish ML, Rivera-Hernandez D, Donohoe M, Brooks JT, et al. Practice of feeding premasticated food to infants: a potential risk factor for HIV transmission. Pediatrics [Internet]. agosto de 2009 [citado 5 de fevereiro de 2024];124(2):658–66. Disponível em: https://pubmed.ncbi.nlm.nih.gov/19620190/  
33. Penazzato M, Dominguez K, Cotton M, Barlow-Mosha L, Ford N. Choice of antiretroviral drugs for postexposure prophylaxis for children: a systematic review. Clin Infect Dis [Internet]. 2015 [citado 5 de fevereiro de 2024];60 Suppl 3:S177–81. Disponível em: https://pubmed.ncbi.nlm.nih.gov/25972500/  
34. Ford N, Irvine C, Shubber Z, Baggaley R, Beanland R, Vitoria M, et al. Adherence to HIV postexposure prophylaxis: a systematic review and meta-analysis. AIDS [Internet]. 2014 [citado 5 de fevereiro de 2024];28(18):2721–7. Disponível em: https://pubmed.ncbi.nlm.nih.gov/25493598/  
35. Violari A, Lindsey JC, Hughes MD, Mujuru HA, Barlow-Mosha L, Kamthunzi P, et al. Nevirapine versus ritonavir-boosted lopinavir for HIV-infected children. N Engl J Med [Internet]. 21 de junho de 2012 [citado 6 de fevereiro de 2024];366(25):2380–9. Disponível em: https://pubmed.ncbi.nlm.nih.gov/22716976/  
36. Palumbo P, Lindsey JC, Hughes MD, Cotton MF, Bobat R, Meyers T, et al. Antiretroviral treatment for children with peripartum nevirapine exposure. N Engl J Med [Internet]. 14 de outubro de 2010 [citado 5 de fevereiro de 2024];363(16):1510–20. Disponível em: https://pubmed.ncbi.nlm.nih.gov/20942667/  
37. Serious Adverse Events Attributed to Nevirapine Regimens for Postexposure Prophylaxis After HIV Exposures-Worldwide, 1997-2000. [citado 5 de fevereiro de 2024]; Disponível em: www.FDA.gov/medwatch,  
38. Wiznia A, Alvero C, Fenton T, George K, Townley E, Hazra R, et al. IMPAACT 1093: Dolutegravir in 6- to 12-Year-Old HIV-Infected Children: 48-Week Results [Internet]. Disponível em: https://www.croiconference.org/abstract/impaact-1093-dolutegravir-6-12-year-old-hivinfected-children-48-week-results-0/  
39. Agência Nacional de Vigilância Sanitária. Consultas - Bula do medicamento Tivicay PD [Internet]. 2024 [citado 14 de fevereiro de 2024]. Disponível em: https://consultas.anvisa.gov.br/#/medicamentos/25351601553202087/?substancia=25568&situaca oRegistro=V  
40  
40. Rodger AJ, Cambiano V, Bruun T, Vernazza P, Collins S, Van Lunzen J, et al. Sexual activity without condoms and risk of HIV transmission in serodifferent couples when the HIV-positive partner is using suppressive antiretroviral therapy. JAMA - Journal of the American Medical Association. 12 de julho de 2016;316(2):171–81.  
41. Rodger AJ, Cambiano V, Phillips AN, Bruun T, Raben D, Lundgren J, et al. Risk of HIV transmission through condomless sex in serodifferent gay couples with the HIV-positive partner taking suppressive antiretroviral therapy (PARTNER): final results of a multicentre, prospective, observational study. Lancet [Internet]. 15 de junho de 2019 [citado 6 de fevereiro de 2024];393(10189):2428–38. Disponível em: https://pubmed.ncbi.nlm.nih.gov/31056293/  
42. Rodger AJ, Cambiano V, Phillips AN, Bruun T, Raben D, Lundgren J, et al. Risk of HIV transmission through condomless sex in serodifferent gay couples with the HIV-positive partner taking suppressive antiretroviral therapy (PARTNER): final results of a multicentre, prospective, observational study. Lancet [Internet]. 15 de junho de 2019 [citado 5 de fevereiro de 2024];393(10189):2428–38. Disponível em: https://pubmed.ncbi.nlm.nih.gov/31056293/  
43. World Health Organization (WHO). The role of HIV viral suppression in improving individual health and reducing transmission: Policy Brief [Internet]. 2023 [citado 6 de fevereiro de 2024]. Disponível em: https://www.who.int/publications/i/item/9789240055179  
44. Broyles LN, Luo R, Boeras D, Vojnov L. The risk of sexual transmission of HIV in individuals with low-level HIV viraemia: a systematic review. The Lancet [Internet]. 5 de agosto de 2023 [citado 6 de fevereiro de 2024];402(10400):464–71. Disponível em: http://www.thelancet.com/article/S0140673623008772/fulltext  
45. Oldenburg CE, Bärnighausen T, Harling G, Mimiaga MJ, Mayer KH. Adherence to post-exposure prophylaxis for non-forcible sexual exposure to HIV: a systematic review and meta-analysis. AIDS Behav [Internet]. 1<sup>o</sup> de fevereiro de 2014 [citado 5 de fevereiro de 2024];18(2):217–25. Disponível em: https://pubmed.ncbi.nlm.nih.gov/23877791/  
46. Chacko L, Ford N, Sbaiti M, Siddiqui R. Adherence to HIV post-exposure prophylaxis in victims of sexual assault: a systematic review and meta-analysis. Sex Transm Infect [Internet]. agosto de 2012 [citado 5 de fevereiro de 2024];88(5):335–41. Disponível em: https://pubmed.ncbi.nlm.nih.gov/22332148/  
47. Thomas R, Galanakis C, Vézina S, Longpré D, Boissonnault M, Huchet E, et al. Adherence to PostExposure Prophylaxis (PEP) and Incidence of HIV Seroconversion in a Major North American Cohort. PLoS One [Internet]. 1<sup>o</sup> de novembro de 2015 [citado 6 de fevereiro de 2024];10(11). Disponível em: https://pubmed.ncbi.nlm.nih.gov/26559816/  
48. Ford N, Venter F, Irvine C, Beanland RL, Shubber Z. Starter packs versus full prescription of antiretroviral drugs for postexposure prophylaxis: a systematic review. Clin Infect Dis [Internet]. 2015 [citado 5 de fevereiro de 2024];60 Suppl 3:S182–6. Disponível em: https://pubmed.ncbi.nlm.nih.gov/25972501/  
49. Webster R, Michie S, Estcourt C, Gerressu M, Bailey J V., on behalf of the MenSS Trial Group. Increasing condom use in heterosexual men: development of a theory-based interactive digital intervention. Transl Behav Med [Internet]. 1<sup>o</sup> de setembro de 2016 [citado 6 de fevereiro de 2024];6(3):418–27. Disponível em: https://pubmed.ncbi.nlm.nih.gov/27528531/  
50. Workowski KA, Bachmann LH, Chan PA, Johnston CM, Muzny CA, Park I, et al. Sexually Transmitted Infections Treatment Guidelines, 2021. MMWR Recomm Rep [Internet]. 2021 [citado 6 de fevereiro de 2024];70(4):1–187. Disponível em: https://pubmed.ncbi.nlm.nih.gov/34292926/  
51. Bolan RK, Beymer MR, Weiss RE, Flynn RP, Leibowitz AA, Klausner JD. Doxycycline Prophylaxis to Reduce Incident Syphilis among HIV-Infected Men who have Sex with Men who Continue to Engage in High Risk Sex: A Randomized, Controlled Pilot Study. Sex Transm Dis [Internet]. 2 de fevereiro de 2015 [citado 27 de novembro de 2023];42(2):98. Disponível em: /pmc/articles/PMC4295649/  
41  
52. Solomon MM, Mayer KH, Glidden D V., Liu AY, McMahan VM, Guanira J V., et al. Syphilis predicts HIV incidence among men and transgender women who have sex with men in a preexposure prophylaxis trial. Clin Infect Dis [Internet]. 1<sup>o</sup> de outubro de 2014 [citado 18 de fevereiro de 2024];59(7):1020–6. Disponível em: https://pubmed.ncbi.nlm.nih.gov/24928295/  
53. Bernstein KT, Marcus JL, Nieri G, Philip SS, Klausner JD. Rectal gonorrhea and chlamydia reinfection is associated with increased risk of HIV seroconversion. J Acquir Immune Defic Syndr [Internet]. abril de 2010 [citado 27 de novembro de 2023];53(4):537–43. Disponível em: https://pubmed.ncbi.nlm.nih.gov/19935075/  
54. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância P e C das IST do H e das HV. 2022. [citado 19 de fevereiro de 2024]. Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST). Disponível em: https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts/2022/ist/pcdt-ist2022_isbn-1.pdf/view  
55. Stamm L V. Syphilis: Re-emergence of an old foe. Microbial Cell [Internet]. 9 de setembro de 2016 [citado 6 de fevereiro de 2024];3(9):363. Disponível em: /pmc/articles/PMC5354565/  
56. KNIGHT DA, JARRETT D. Preventive Health Care for Men Who Have Sex with Men. Am Fam Physician [Internet]. 15 de junho de 2015 [citado 5 de fevereiro de 2024];91(12):844–52. Disponível em: https://www.aafp.org/pubs/afp/issues/2015/0615/p844.html  
57. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Doenças de Condições  Crônicas e Infecções Sexualmente Transmissíveis. MANUAL TÉCNICO PARA O DIAGNÓSTICO DA SÍFILIS. 2021 [citado 19 de fevereiro de 2024]; Disponível em: https://www.gov.br/aids/pt-br/central-de-conteudo/publicacoes/2021/manual-tecnico-para-odiagnostico-da-sifilis  
58. Schneede P. [One decade of HPV vaccination in Germany]. Urologe A [Internet]. 1<sup>o</sup> de junho de 2017 [citado 5 de fevereiro de 2024];56(6):728–33. Disponível em: https://pubmed.ncbi.nlm.nih.gov/28455577/  
59. Signorelli C, Odone A, Ciorba V, Cella P, Audisio RA, Lombardi A, et al. Human papillomavirus 9-valent vaccine for cancer prevention: a systematic review of the available evidence. Epidemiol Infect [Internet]. 1<sup>o</sup> de julho de 2017 [citado 6 de fevereiro de 2024];145(10):1962–82. Disponível em: https://pubmed.ncbi.nlm.nih.gov/28446260/  
60. Azevedo G, Ii S, Rodrigues A, Ayres G, Aramã R, Ribeiro -Bento. Prevalência de infecção do colo do útero pelo HPV no Brasil: revisão sistemática. Rev Saude Publica [Internet]. outubro de 2010 [citado 27 de novembro de 2023];44(5):963–74. Disponível em: https://www.scielo.br/j/rsp/a/xSDfMJZPTY56BSFYQqWWnMJ/  
61. Pelizzer T, Dias CP, Poeta J, Torriani T, Roncada C. Prevalência de câncer colorretal associado ao papilomavírus humano: uma revisão sistemática com metanálise. Revista Brasileira de Epidemiologia [Internet]. 1<sup>o</sup> de outubro de 2016 [citado 5 de fevereiro de 2024];19(4):791–802. Disponível em: https://www.scielo.br/j/rbepid/a/WLzZLnm9R5t7ppBszgd8FdD/abstract/?lang=pt  
62. Gao G, Smith DI. Human Papillomavirus and the Development of Different Cancers. Cytogenet Genome Res [Internet]. 1<sup>o</sup> de março de 2016 [citado 5 de fevereiro de 2024];150(3–4):185–93. Disponível em: https://pubmed.ncbi.nlm.nih.gov/28245440/  
63. Small W, Bacon MA, Bajaj A, Chuang LT, Fisher BJ, Harkenrider MM, et al. Cervical cancer: A global health crisis. Cancer [Internet]. 1<sup>o</sup> de julho de 2017 [citado 6 de fevereiro de 2024];123(13):2404–12. Disponível em: https://pubmed.ncbi.nlm.nih.gov/28464289/  
64. Nacional De Câncer I, Gomes Da Silva JA. MINISTÉRIO DA SAÚDE DIRETRIZES BRASILEIRAS PARA O RASTREAMENTO DO CÂNCER DO COLO DO ÚTERO 2<sup>a</sup> edição revista, ampliada e atualizada. [citado 19 de fevereiro de 2024]; Disponível em: www.inca.gov.br  
42  
65. Nota Técnica n<sup>o</sup> 63/2023-CGICI/DPNI/SVSA/MS — Ministério da Saúde [Internet]. [citado 19 de fevereiro de 2024]. Disponível em: https://www.gov.br/saude/pt-br/centrais-deconteudo/publicacoes/notas-tecnicas/2023/nota-tecnica-63-2023-cgici-dpni-svsa-ms.pdf/view  
66. Rambow B, Adkinson C, Frost TH, Peterson GF. Female sexual assault: medical and legal implications. Ann Emerg Med [Internet]. 1992 [citado 5 de fevereiro de 2024];21(6):727–31. Disponível em: https://pubmed.ncbi.nlm.nih.gov/1590616/  
67. Molina JM, Charreau I, Chidiac C, Pialoux G, Cua E, Delaugerre C, et al. Post-exposure prophylaxis with doxycycline to prevent sexually transmitted infections in men who have sex with men: an open-label randomised substudy of the ANRS IPERGAY trial. Lancet Infect Dis [Internet]. 1<sup>o</sup> de março de 2018 [citado 5 de fevereiro de 2024];18(3):308–17. Disponível em: https://pubmed.ncbi.nlm.nih.gov/29229440/  
68. Hepatitis C Questions and Answers for Health Professionals | CDC [Internet]. [citado 6 de fevereiro de 2024]. Disponível em: https://www.cdc.gov/hepatitis/hcv/hcvfaq.htm  
69. Lavanchy D. Evolving epidemiology of hepatitis C virus. Clin Microbiol Infect [Internet]. 2011 [citado 5 de fevereiro de 2024];17(2):107–15. Disponível em: https://pubmed.ncbi.nlm.nih.gov/21091831/  
70. Werber D, Michaelis K, Hausner M, Sissolak D, Wenzel J, Bitzegeio J, et al. Ongoing outbreaks of hepatitis A among men who have sex with men (MSM), Berlin, November 2016 to January 2017 – linked to other German cities and European countries. Eurosurveillance [Internet]. 2 de fevereiro de 2017 [citado 6 de fevereiro de 2024];22(5). Disponível em: /pmc/articles/PMC5388120/  
71. Freidl GS, Sonder GJ, Bovée LP, Friesema IH, van Rijckevorsel GG, Ruijs WL, et al. Hepatitis A outbreak among men who have sex with men (MSM) predominantly linked with the EuroPride, the Netherlands, July 2016 to February 2017. Euro Surveill [Internet]. 23 de fevereiro de 2017 [citado 5 de fevereiro de 2024];22(8). Disponível em: https://pubmed.ncbi.nlm.nih.gov/28251892/  
72. Chen GJ, Lin KY, Sun HY, Sheng WH, Hsieh SM, Huang YC, et al. Incidence of acute hepatitis A among HIV-positive patients during an outbreak among MSM in Taiwan: Impact of HAV vaccination. Liver Int [Internet]. 1<sup>o</sup> de abril de 2018 [citado 5 de fevereiro de 2024];38(4):594–601. Disponível em: https://pubmed.ncbi.nlm.nih.gov/28482131/  
73. Beebeejaun K, Degala S, Balogun K, Simms I, Woodhall SC, Heinsbroek E, et al. Outbreak of hepatitis A associated with men who have sex with men (MSM), England, July 2016 to January 2017. Eurosurveillance [Internet]. 2 de fevereiro de 2017 [citado 27 de novembro de 2023];22(5). Disponível em: /pmc/articles/PMC5388117/  
74. Recommendations for Routine Testing and Follow-up for Chronic Hepatitis B Virus (HBV) Infection Recommendation Population Testing Vaccination/Follow-up Persons born in regions of high and intermediate HBV endemicity (HBsAg prevalence 2%) Geographic Distribution of Chronic HBV Infection-Worldwide, 2006*. [citado 6 de fevereiro de 2024]; Disponível em: http://wwwn.cdc.gov/travel/yellowbookch4-HepB.aspx.  
75. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância P e C das IST do H e das HVirais. MANUAL TÉCNICO PARA O DIAGNÓSTICO DAS HEPATITES VIRAIS. 2018 [citado 19 de fevereiro de 2024]; Disponível em: https://www.gov.br/aids/ptbr/central-de-conteudo/publicacoes/2018/manual_tecnico_hepatites_virais_web_3108181.pdf  
76. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Departamento de Imunizações e Doenças Imunopreveníveis. Manual dos Centros de Referência para Imunobiológicos Especiais – 6. ed. – Brasília. 2023 [citado 27 de novembro de 2023]; Disponível em: https://www.gov.br/saude/pt-br/vacinacao/arquivos/manual-dos-centros-de-referencia-paraimunobiologicos-especiais_6a-edicao_2023.pdf  
77. Protocolo Clínico e Diretrizes Terapêuticas de Hepatite B e Coinfecções — Departamento de HIV/Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis [Internet].  
43  
[citado 18 de fevereiro de 2024]. Disponível em: https://www.gov.br/aids/pt-br/central-deconteudo/publicacoes/2023/protocolo-clinico-e-diretrizes-terapeuticas-de-hepatite-b-ecoinfeccoes-2023_.pdf/view  
78. Dionne-Odom J, Osborn MK, Radziewicz H, Grakoui A, Workowski K. Acute hepatitis C and HIV coinfection. Lancet Infect Dis [Internet]. dezembro de 2009 [citado 5 de fevereiro de 2024];9(12):775–83. Disponível em: https://pubmed.ncbi.nlm.nih.gov/19926037/  
79. Hagan H, Jordan AE, Neurer J, Cleland CM. Incidence of sexually-transmitted hepatitis C virus infection in HIV-positive men who have sex with men: A systematic review and meta-analysis. AIDS [Internet]. 1<sup>o</sup> de novembro de 2015 [citado 5 de fevereiro de 2024];29(17):2335. Disponível em: /pmc/articles/PMC4640945/  
80. Medland NA, Chow EPF, Bradshaw CS, Read THR, Sasadeusz JJ, Fairley CK. Predictors and incidence of sexually transmitted Hepatitis C virus infection in HIV positive men who have sex with men. BMC Infect Dis [Internet]. 2 de março de 2017 [citado 5 de fevereiro de 2024];17(1). Disponível em: https://pubmed.ncbi.nlm.nih.gov/28253838/  
81. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância P e C das IST do H e das HV. Protocolo Clínico e Diretrizes Terapêuticas para Hepatite C e Coinfecções [Internet]. 2019 [citado 19 de fevereiro de 2024]. Disponível em: https://www.gov.br/aids/ptbr/central-de-conteudo/pcdts/2017/hepatites-virais/pcdt_hepatite_c_06_2019_isbn.pdf/view  
82. Brasil. Ministério da Saúde. Protocolo para Utilização do Levonorgestrel. 2012 [citado 19 de fevereiro de 2024]; Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/protocolo_para_utilizacao_levonorgestrel.pdf  
83. GUIA DE VIGILÂNCIA EM SAÚDE 6<sup>a</sup> edição MINISTÉRIO DA SAÚDE. [citado 19 de fevereiro de 2024]; Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/guia_vigilancia_saude_6ed_v3.pdf  
84. Cerqueira D, Santa D, Coelho C. Estupro no Brasil: uma radiografia segundo os dados da Saúde (versão preliminar). http://www.ipea.gov.br [Internet]. 2014 [citado 5 de fevereiro de 2024]; Disponível em: https://repositorio.ipea.gov.br/handle/11058/5780  
85. Dejtiar R, Mário W, Hirschheimer R. Manual de Atendimento às Crianças e Adolescentes Vítimas de Violência. Conselho Federal de Medicina (CFM) [Internet]. 2011 [citado 6 de fevereiro de 2024]; Disponível em: http://www.spsp.org.br  
86. Norma Técnica. ATENÇÃO HUMANIZADA ÀS PESSOAS EM SITUAÇÃO DE VIOLÊNCIA SEXUAL COM REGISTRO DE INFORMAÇÕES E COLETA DE VESTÍGIOS MINISTÉRIO DA SAÚDE MINISTÉRIO DA JUSTIÇA SECRETARIA DE POLÍTICAS PARA AS MULHERES. 2015 [citado 19 de fevereiro de 2024]; Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/atencao_humanizada_pessoas_violencia_sexual_nor ma_tecnica.pdf  
87. Ministério da Saúde Secretaria de Atenção à Saúde Departamento de Ações Programáticas Estratégicas B. Linha de cuidado para a atenção integral à saúde de crianças, adolescentes e suas famílias em situação de violência: orientações para gestores e profissionais de saúde.  
88. Dejtiar R, Mário W, Hirschheimer R, Pfeiffer L. MANUAL DE ATENDIMENTO ÀS CRIANÇAS E ADOLESCENTES VÍTIMAS DE VIOLÊNCIA 2<sup>a</sup> edição.  
89. Política Nacional de Saúde do Trabalhador e da Trabalhadora — Ministério da Saúde [Internet]. [citado 19 de fevereiro de 2024]. Disponível em: https://www.gov.br/saude/ptbr/composicao/svsa/saude-do-trabalhador/pnst  
44

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: MATERIAL SUPLEMENTAR A - RESUMO DO ATENDIMENTO Avaliação inicial de PEP -->
Obter histórico de evento de exposição:  
- Determinar o tempo de exposição;  
- Investigar o status sorológico do HIV, HBV e HCV da pessoa exposta e da pessoa-fonte, quando possível;  
- Em caso de exposição sexual, acrescentar investigação de sífilis, _N. gonorrhoeae e C. trachomatis_ em pessoa exposta e pessoa-fonte, quando possível;  
- Questionar sobre sinais e sintomas de IST;  
- Verificar imunizações (HBV, dT, HPV, HVA);  
- Indagar a data da última menstruação e sintomas de gravidez, em caso de mulher em idade fértil e vida sexual ativa. Caso necessário, solicitar teste de gravidez.  
Se a PEP ao HIV estiver indicada:  
- Prescrever esquema ARV;  
- Orientar sobre melhor tolerabilidade do novo esquema;  
- Reforçar a importância da adesão;  
- Agendar retorno preferencialmente em quatro semanas.  
Para todas as pessoas avaliadas:  
- Avaliar status imunológico para hepatite A;  
- Orientações de prevenção;  
- Avaliar indicação vacinação/imunoglobulina hepatite B;  
- Avaliar indicação de tratamento para IST;  
- Oferecer anticoncepção de emergência, quando indicada;  
- Orientar em relação à vacinação contra HAV conforme PNI;  
- Orientar em relação à vacinação para HPV conforme PNI;  
- Notificar em caso de violência sexual;  
- Notificar em caso de acidente ocupacional;  
- Notificar agravos de notificação compulsória;  
- Orientar sobre medidas de prevenção.  
Seguimento:  
- Retorno em quatro semanas para avaliação dos efeitos adversos e reforço nas orientações de adesão;  
- Seguimento laboratorial;  
- Acompanhar vacinação, se previamente prescrita.  
45

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: MATERIAL SUPLEMENTAR B – CRONOGRAMA DE EXAMES LABORATORIAIS -->
||**Pessoa-fonte**||**Pessoa exp**|**osta**||
|---|---|---|---|---|---|
|**Teste**|**Atendimento**<br>**inicial**|**Atendimento**<br>**inicial**|**4 a 6**<br>**semanas**|**3 meses**|**6 meses**|
|**HIV**|X|X|X|X|NA|
|**HBsAg**|X|X|NA|NA|X<sup>a</sup>|
|**Anti- HBs**|NA|X<sup>b</sup>|NA|NA|X<sup>c</sup>|
|**Anti-HCV**|X|X|X|NA|X|
|**CV-HCV**<sup>**d**</sup>|NA|NA|X|NA|X|
|**Teste**<br>**treponêmico**<br>**para sífilis(TR)* **|X|X|X|NA|NA|
|**Testagem para**<br>**N.gonorrhoeae***|X|X|X|NA|NA|
|**Testagem para**<br>**C. trachomatis***|X|X|X|NA|NA|
|**Teste de**<br>**gravidez***|NA|X|X|NA|NA|  
***Não precisam ser realizados em caso de exposição ocupacional**  
Fonte: DATHI/SVSA/MS.  
NA: não aplicável.  
a Considerar para as pessoas que são não-respondedores à vacinação ou não foram vacinadas para HBV.  
> b Se a pessoa exposta apresentar HBsAg não reagente, para avaliar suscetibilidade e indicação de (re)vacinação.  
c Para avaliar resposta à vacina (caso a imunização tenha sido recomendada).  
d Para avaliar suspeita de infecção aguda.  
46

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: APÊNDICE 1 - METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Escopo e finalidade do Protocolo  
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de  Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV, IST e Hepatites Virais contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
Equipe de elaboração e partes interessadas

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: Colaboração externa -->
O grupo elaborador deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do DATHI. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV, IST e Hepatites Virais foi apresentada na 109ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 21 de novembro de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Vigilância em Saúde e Ambiente (SVSA).

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: Consulta Pública -->
A Consulta Pública nº 53/2023, do Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia PósExposição de Risco (PEP) à Infecção pelo HIV, IST e Hepatites Virais, foi realizada entre os dias 15/12/2023 e 03/01/2024. Foram recebidas dez contribuições. O conteúdo integral das contribuições e anexos recebidos se encontram disponíveis na página da Conitec em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2023/CP_CONITEC_053_2023_PCDT_para_Profilaxia.pdf</u>

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: Busca da evidência e recomendações -->
A atualização do PCDT de Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV, IST e Hepatites Virais contou com a participação do comitê de experts na profilaxia e tratamento da doença. O grupo de especialistas foi composto por representantes da comunidade científica, representante da Sociedade Brasileira de Infectologia, representantes da sociedade civil e especialistas com longa experiência no cuidado e tratamento de pessoas que vivem com HIV e Aids, oriundos de instituições envolvidas com o cuidado às pessoas vivendo com HIV.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao MS para análise prévia às reuniões de escopo e formulação de recomendações. Para a atualização das recomendações do novo documento, elaborou-se uma proposta inicial do escopo de atualização do PCDT, que foi compartilhado com os membros do grupo técnico assessor em setembro de 2023. Nesta proposta, foram estabelecidos os pontos que demandavam atualização, considerando as novas tecnologias em saúde previamente incorporadas, o cenário epidemiológico e as principais estratégias de enfrentamento à epidemia de Aids.  
Diante do exposto, foram realizadas buscas na literatura científica por revisões sistemáticas, ensaios clínicos randomizados, além de protocolos e diretrizes clínicas internacionais sobre os temas específicos de cada uma das seções. Também foram utilizados os Relatórios técnicos das novas tecnologias em saúde recentemente incorporadas, como o dolutegravir, 5mg comprimido dispersível e darunavir 800 mg.  
Após a análise das evidências científicas, buscou-se identificar as necessidades de atualização do PCDT publicado em 2017, como subsídio para reunião com o grupo de especialistas, que ocorreu em novembro de 2023. O levantamento de evidências resultante das buscas na literatura científica, foi utilizado para elaboração da proposta preliminar.  
O resultado desse processo de revisão das recomendações clínicas junto aos especialis-tas traz como principais alterações:  
1. Ampliação da utilização do dolutegravir 50 mg para gestantes em qualquer idade gestacional, e a todas as pessoas com potencial de engravidar. Antes, o PCDT restringia o uso de dolutegravir para essas populações, mas novas evidências garantem segurança e maior eficácia para uso desse antirretroviral, conforme Relatório de Recomendação da Conitec nº 515/2020.  
2. Inclusão do dolutegravir 5 mg comprimido dispersível para PEP em crianças com peso igual ou superior a 3 kg e acima de 4 semanas de vida, conforme Relatório de Recomendação da Conitec nº 830/2023;  
3. Alteração da recomendação no esquema ARV para PEP, em indicação de segunda linha: migrando de atazanavir (ATV/r) para o darunavir (DRV/r) 800 mg, conforme Relatório de Recomendação da Conitec nº 823/2023;  
4. Reforço das orientações sobre indicação e início de PrEP após uso da PEP;  
5. Atualizada a indicação de vacinação para HPV;  
6. Reforço dos cuidados para pessoas com hepatite B e indicação de PEP;  
7. Reforço dos cuidados de acompanhamento de soroconversão em uso ou após o uso de  
PEP.  
Previamente, os especialistas receberam a proposta elaborada pela Coordenação-Geral de Vigilância do HIV/Aids e das Hepatites Virais (CGAHV/DATHI/SVSA/MS) e que elencava os pontos chave para atualização do PCDT. Durante o encontro, foi aplicada uma adaptação do método Delphi para obter o consenso dos especialistas para a tomada de decisão sobre as novas recomendações e também em relação àquelas que apresentavam diferenças de parâmetros na literatura.  
Após a reunião, as decisões foram incorporadas ao texto do documento final, o qual foi compartilhado com o grupo de especialistas para a definição da versão final, sendo que as sugestões adicionais foram consolidadas pela equipe da CGAHV/DATHI/SVSA/MS.  
Na sequência, a minuta de texto atualizado foi apresentada à Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS) e, após revisão, foi avaliada pela Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas.

---

<!-- METADADOS: doenca: Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV | secao: **APÊNDICE 2 - HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**<br>||**Tecnologias avaliadaspela**|**Conitec**|
|---|---|---|---|
|**Relatório da**<br>||||
|**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação**<br>**ou não alteração no**<br>**SUS**|
||Alteração<br>pós<br>publicação – Inclusão<br>de informações sobre<br>a interação de PEP e<br>carbamazepina<br>e<br>oxcarbazepina|||
|Pti|Alteração<br>pós<br>publicação – Correção<br>dosQuadros 10 e 13|||
|orara<br>SECTICS/MS<br>nº<br>14, de 08/04/2024<br>[Relatório<br>de<br>Recomendação nº<br>883/2024]|Atualização do texto,<br>inclusão de tecnologia<br>(dolutegravir 5 mg e<br>darunavir 800 mg)|Dolutegravir 5 mg como tratamento<br>complementar ou substitutivo em crianças<br>de 2 meses a 6 anos de idade com HIV.<br>[Relatório de Recomendação nº 830/2023;<br>Portaria SECTICS/MS nº 36/2023].<br>Darunavir 800 mg para o tratamento de<br>pessoas vivendo com HIV em falha<br>virológica ao esquema de primeira linha e<br>sem mutações que conferem resistência ao<br>darunavir (V11I, V32I, L33F, I47V, I50V,<br>I54L, I54M, T74P, L76V, I84V ou L89V).<br>[Relatório de Recomendação nº 829/2023;<br>PortariaSECTICS/MSnº34/2023].|-|
|Portaria<br>SCTIE/MS nº 54,<br>de<br>24/08/2021<br>[Relatório<br>de<br>Recomendação nº<br>603]|Primeira versão do<br>documento|-|-|

---

