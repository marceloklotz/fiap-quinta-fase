<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Espondilite Ancilosante.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a artrite ancilosante no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação n<sup>o</sup> 299/2017, n<sup>o</sup> 300/2017 e n<sup><u>o</u></sup> 376/2018 e os relatórios de recomendação n<sup><u>o</u></sup> 317 – Dezembro de 2017, n<sup><u>o</u></sup> 318 – Janeiro de 2018 e n<sup><u>o</u></sup> 389 – Agosto de 2018, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas da Espondilite Ancilosante.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da espondilite ancilosante, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e</u> deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da espondilite ancilosante.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria Conjunta n<sup>o</sup> 7/SAS/SCTIE/MS, de 17 de julho de 2017, publicada no Diário Oficial da União nº 137, de 19 de julho de 2017, Seção 1, página 50.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
**ANEXO**

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
A espondilite ancilosante ou anquilosante (EA) é uma doença inflamatória crônica classificada no grupo das espondiloartrites que acomete preferencialmente a coluna vertebral, podendo evoluir com rigidez e limitação funcional progressiva do esqueleto axial. Assim, as formas mais iniciais de EA, nas quais o dano estrutural é menor ou inexistente, podem ser classificadas como espondiloartrites axiais ( **Quadro 1** ). A EA envolve adultos jovens, com pico de incidência em homens dos 20 aos 30 anos, especialmente em portadores do antígeno HLA-B27, o que, no Brasil, representa cerca de 60% dos pacientes<sup>(1–3)</sup> .  
As manifestações clínicas da EA incluem sintomas axiais, como dor lombar inflamatória, e sintomas periféricos, como artrite, entesite e dactilite. O sintoma inicial costuma ser lombalgia, caracterizada por dor noturna, de início insidioso, que não melhora com repouso (mas melhora com exercícios). Em estudo multicêntrico brasileiro, os pacientes que tiveram o início da espondiloartrite (incluindo EA) antes dos 40 anos, apresentavam predomínio de sintomas axiais; os pacientes, predominantemente do sexo feminino, com início de sintomas mais tardio apresentavam sintomas periféricos<sup>(4)</sup> .  
Além disso, podem ocorrer manifestações extra-articulares, tais como uveíte anterior aguda (UAA), insuficiência aórtica, distúrbios de condução cardíacos, fibrose de lobos pulmonares superiores, compressão nervosa ou neurite, nefropatia ou amiloidose renal secundária. Das manifestações extra-articulares, a UAA é a manifestação extraesquelética mais comum, acometendo até 40% dos pacientes, especialmente os com HLA-B27 positivo<sup>(5)</sup> . Dados observacionais de pacientes provenientes de 10 países ibero-americanos revelam que a UAA está associada, de forma positiva, a acometimento axial e presença de HLA-B27 e, de forma negativa, a acometimento periférico e artrite psoríaca<sup>(6)</sup> .  
Pacientes em estágios iniciais da EA apresentam sintomas clínicos da doença, porém geralmente não demonstram alterações estruturais em radiografias (RX). Em tais pacientes, sinais inflamatórios articulares, como sacroileíte, podem ser detectáveis em exame de ressonância magnética (RM). Consequentemente, foi proposto que a doença inicial e sem alteração no RX seja referida como espondiloartrite axial não radiográfica<sup>(7)</sup> .  
Fatores de mau prognóstico de EA incluem mudanças estruturais radiográficas à avaliação inicial, acometimento do quadril, baixo nível socioeconômico, idade jovem no início da doença, tabagismo, uveíte, dactilite, velocidade de hemossedimentação (VHS) ou proteína C reativa persistentemente elevadas, resposta insatisfatória a antiinflamatórios não-esteroidais (AINE) e atividade de doença persistentemente alta ( _Bath Ankylosing Spondylitis Disease Actvity Index_ – BASDAI igual ou superior a 4 - ver no **Apêndice 1** )<sup>(8)</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dá à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo tem por objetivo definir critérios de classificação e de tratamento de pacientes com EA ou com espondiloartrite axial não radiográfica que apresentam manifestações músculo-esqueléticas (axiais ou periféricas). A metodologia de busca e avaliação das evidências está detalhada no **Apêndice 3** .

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
- M45 Espondilite ancilosante  
- M46.8 Outras espondilopatias inflamatórias especificadas

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Inexistem critérios diagnósticos para EA, mas critérios de classificação facilitam a identificação das características mais importantes para o diagnóstico<sup>(9)</sup> .  
Os critérios ASAS ( _Assessment of SpondyloArthritis International Society_ ) permitem a inclusão de pacientes ainda sem dano estrutural, e os critérios de classificação modificados de Nova Iorque, a inclusão de pacientes já com alterações radiográficas, numa fase mais avançada da doença<sup>(10)</sup> . Na prática assistencial, ambos podem ser empregados, mas a tendência atual é usar preferencialmente os critérios ASAS.  
Para o diagnóstico de doença inicial, os critérios ASAS são mais úteis para espondiloartrites axiais, podendo ser utilizados também para as espondiloartrites periféricas<sup>(10)</sup> , segundo os quais pacientes com até 45 anos e lombalgia por mais de três meses são classificados como doentes de espondiloartrite axial em dois cenários ( **Quadro 1** ).  
**Quadro 1-** Critérios de Classificação ASAS para Espondiloartrites Axiais  
|**Critério obrigatório**|a) Lombalgia inflamatória por, no mínimo, 3 meses e idade de início da doença<br>até 45 anos.|
|---|---|
|**Critérios possíveis (b ou c)**|b) Sacroiliíte em exames de imagem<sup>a</sup>e, pelo menos 1 característica de<br>Espondiloartrite<sup>b</sup>.|
||c) HLA-B27 e 2 ou mais características de espondiloartrite<sup>b</sup>.|  
aRadiografia simples (com sacroiliíte bilateral graus 2-4 ou unilateral graus 3 ou 4) ou ressonância magnética de articulações sacroilíacas (com edema de medula óssea). Graus de sacroiliíte à radiografia simples de articulações sacroilíacas: 0, normal; 1, alterações suspeitas; 2, alterações mínimas (áreas localizadas e pequenas com erosão ou esclerose, sem alterações na largura da linha articular); 3, alterações inequívocas (sacroiliíte moderada ou avançada, com erosões, esclerose, alargamento, estreitamento ou anquilose parcial); 4, ancilose total. bCaracterísticas de espondiloartrite: lombalgia inflamatória, artrite, entesite, uveíte, dactilite, psoríase, doença de Crohn ou retocolite ulcerativa, boa resposta a anti-inflamatórios não esteroidais (em 24-48 horas de máxima dose tolerada), história familiar de espondiloartrite, HLA-B27, proteína C reativa elevada.  
Para o diagnóstico de doença estabelecida, são utilizados os critérios de classificação modificados de Nova Iorque<sup>(11)</sup> , nos quais são consideradas lombalgia, limitação de mobilidade axial e sacroiliíte radiográfica ( **Quadro 2** ). Se o paciente apresentar, pelo menos, um critério clínico e um critério radiográfico, o mesmo é classificado como portador de EA.  
**Quadro 2 -** Critérios de Classificação Modificados de Nova Iorque para Espondilite Ancilosante  
|**Grupos de critérios**|**Descrição**|
|---|---|
|**Clínicos**|a) Lombalgia inflamatória<sup>a</sup>por três meses ou mais de duração<br>b) Limitação dos movimentos da coluna lombar nos planos sagital (por exemplo,<br>média variação bilateral dedo-chão<sup>b</sup>inferior a 10cm) e frontal (por exemplo, teste de<br>Schober<sup>c</sup>inferior a 5cm)<br>c) Expansão torácica diminuída<sup>d</sup>(inferior a 2,5cm).|
|**Radiográficos**|d) Radiografia com detecção de sacroiliíte bilateral graus 2-4<sup>e</sup><br>e) Radiografia com detecção de sacroiliíte unilateral graus 3 ou 4.|  
a Dor lombar que melhora com exercícios, mas não com repouso, que ocorre predominantemente à noite, com início insidioso, antes dos 40 anos. b Em ortostatismo, mede-se a distância entre o terceiro quirodáctilo de cada mão e o chão na posição ereta e em flexão lateral máxima para cada lado; calcula-se a média das variações de altura.  
c Variação da distância mediana de 10 cm acima da quinta vértebra lombar (L5) à flexão do tronco com membros inferiores estendidos.  
d Variação da circunferência torácica inframamária na inspiração e expiração máximas.  
e Graus de sacroiliíte à radiografia simples de articulações sacroilíacas: 0, normal; 1, alterações suspeitas; 2, alterações mínimas (áreas localizadas e pequenas com erosão ou esclerose, sem alterações na largura da linha articular); 3, alterações inequívocas (sacroiliíte moderada ou avançada, com erosões, esclerose, alargamento, estreitamento ou anquilose parcial); 4, anquilose total.  
Um dos focos do tratamento é o controle de atividade da doença. A avaliação da atividade da doença de um paciente com EA pode ser feita pelo escore BASDAI ( **Apêndice 1** ). Um escore igual ou superior a 4 numa escala de 0 a 10 indica doença ativa. De maneira geral, a resposta ao tratamento de EA axial ocorre quando há redução de, pelo menos, 50% ou de 2 pontos absolutos no BASDAI num período mínimo de 12 semanas<sup>(8)</sup> .  
Outras medidas de resposta ao tratamento têm sido utilizadas em estudos clínicos como o ASAS20, ASAS40, ASAS5/6 e ASDAS. Todas estas medidas são feitas em um intervalo de 12 semanas. O critério ASAS20 é composto por ao menos 20% de melhora após o tratamento, com melhora absoluta de ao menos uma unidade (escala de 0 a 10)  
em ao menos três dos seguintes domínios, sem deterioração na condição inicial: avaliação global do paciente, dor em coluna, função (BASFI) e rigidez matinal (questões 5 e 6 do BASDAI). Da mesma forma, o ASAS40 requer 40% de melhora em ao menos três domínios, sem piora do domínio restante.  
ASAS5/6 inclui os 4 domínios do ASAS20, além de mobilidade da coluna vertebral (BASMI) e reagentes de fase aguda (PCR). Uma resposta ASAS5 / 6 é definida como uma melhora de pelo menos 20% e uma melhora de pelo menos uma unidade em, pelo menos, cinco dos seis domínios, sem agravamento do domínio restante<sup>(14,15)</sup> .  
Na EA com manifestações periféricas, a atividade da doença depende essencialmente da avaliação médica, já que o BASDAI e ASAS se referem, principalmente, ao acometimento axial. Novos critérios, como o ASDAS _(Ankylosing Spondylitis Disease Activity Score)_ , têm sido validados, contemplando diversas manifestações de atividade da doença, além do resultado das provas inflamatórias (velocidade de hemossedimentação ou proteína C reativa)<sup>(16)</sup> .  
O escore ASDAS tem a vantagem de categorizar a atividade de doença em inativa, moderada, elevada ou muito elevada. Os três pontos de corte selecionados para diferenciar esses estados foram: 1,3, 2,1 e 3,5. Como desvantagem, necessita de calculadoras específicas para obter seu resultado. Uma redução maior ou igual a 1,1 ponto representa uma melhora clínica relevante, enquanto uma redução maior ou igual a 2 pontos representa uma melhora significativa ( **Apêndice 1** )<sup>(17)</sup> .

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Serão incluídos neste Protocolo pacientes que preenchem os critérios de classificação modificados de Nova Iorque ou os critérios ASAS e que apresentem doença axial ou periférica em atividade. Doença axial ou periférica em atividade preferencialmente deve ser estabelecida por pelo menos um dos índices de atividade, ASDAS ou BASDAI.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Serão excluídos deste Protocolo os pacientes que apresentarem ao menos uma das seguintes condições, de acordo com a terapia indicada:  
- Para naproxeno e ibuprofeno: sangramento gastrointestinal não controlado; úlcera gastroduodenal; elevação de aminotransferases (ALT e AST)/transaminases (TGP e TGO) igual ou 3 vezes acima do limite superior da normalidade (LSN); taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica;  
- Para metilprednisolona: tuberculose sem tratamento;  
- Para metotrexato: tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibióticos; infecção fúngica ameaçadora à vida; infecção por herpes-zoster ativa; hepatites B ou C agudas; elevação de aminotransferases (ALT e AST)/transaminases (TGP e TGO) igual ou três vezes superior o LSN; taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal na ausência de terapia dialítica crônica;gestação, amamentação e concepção (homens e mulheres);  
- Para a sulfassalazina (SSZ): porfiria, tuberculose sem tratamento, hepatites B ou C agudas; artrite reumatoide juvenil, forma sistêmica; elevação de aminotransferases (ALT e AST)/transaminases (TGP e TGO) igual ou 3 vezes acima do LSN; obstrução urinária ou intestinal, depressão da medula óssea; insuficiência renal moderada a grave (taxa de depuração de creatinina inferior a 30 mL/min/1,73m<sup>2</sup> de superfície corporal);  
- Para adalimumabe, etanercepte, infliximabe, golimumabe certolizumabe pegol ou secuquinumabe: tuberculose sem tratamento; infecção bacteriana com indicação de uso de antibiótico; infecção fúngica ameaçadora à vida; infecção por herpes-zoster ativa; hepatites B ou C agudas; doença linfoproliferativa nos últimos cinco anos; insuficiência cardíaca congestiva classes III ou IV; doença neurológica desmielinizante.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
De forma geral, o uso de medicamentos deve ser considerado individualmente, com uma rigorosa avaliação do risco-benefício nos seguintes casos:  
- gestantes, lactantes, crianças e adolescentes;  
- pacientes com UAA ou recorrente;  
- infecção ativa ou com alto risco para infecção (úlcera crônica de perna, tuberculose latente, artrite séptica nos últimos 12 meses ou indefinidamente no caso de prótese não removida, infecções respiratórias persistentes ou recorrentes, cateter urinário de longa permanência);  
- história de lúpus eritematoso sistêmico ou esclerose múltipla;  
- doença maligna (excluindo carcinoma basocelular e malignidades tratadas há mais de 10 anos) ou estados de  
- pré-malignidade;  
- fibromialgia: está presente em 15% dos pacientes com EA e pode causar piora dos índices de atividade de doença, funcionalidade e qualidade de vida<sup>(12)</sup> . Com isso, ela deve ser identificada e tratada nos pacientes com EA para não induzir erros no tratamento.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Os objetivos do tratamento são reduzir os sintomas, manter a flexibilidade axial e a postura normal, reduzir as limitações funcionais, manter habilidade laboral e reduzir complicações associadas à doença<sup>(13)</sup> .  
A conduta ideal para EA inclui tratamentos não medicamentoso e medicamentosos combinados<sup>(21-24)</sup> , que serão discutidos a seguir.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
O tratamento não medicamentoso é essencial e deve ser sempre considerado. Seus dois princípios fundamentais são a educação do paciente e a realização de exercícios físicos. Os exercícios devem incluir alongamento, educação postural, atividades recreacionais ou hidroterapia<sup>(8,13,18–21)</sup> . A reabilitação e a atividade física parecem ter um efeito adicional ou sinérgico com a terapia biológica, conforme demonstrado em revisões sistemáticas. Os programas de atividade em grupo, supervisionados ou fisioterapia individual foram mais efetivos quando comparados com exercícios convencionais ou domiciliares<sup>(22)</sup> . A maioria dos benefícios observados imediatamente após a intervenção não se mantém no acompanhamento. Consequentemente, considerando a natureza crônica da doença, exercícios regulares e contínuos são fundamentais.  Além disso, a frequência necessária para obter esses benefícios ainda não está estabelecida<sup>(23)</sup> .

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
O tratamento medicamentoso inclui anti-inflamatórios não esteroidais - AINE, glicocorticoides e medicamentos modificadores do curso da doença – MMCD (sulfassalazina - SSZ, metotrexato – MTX e adalimumabe, etanercepte, infliximabe, golimumabe, certolizumabe pegol ou secuquinumabe)<sup>(8,13,18)</sup> . Esses fármacos estão contraindicados em caso de hipersensibilidade a qualquer um de seus componentes ou em casos de contraindicação absoluta.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Os AINE são recomendados como a primeira linha de tratamento em pacientes com espodiloartrite axial em atividade<sup>(13,18)</sup> . Cerca de 70% a 80% dos pacientes com EA apresentam melhora dos sintomas, incluindo melhora da dor e da rigidez axial, apenas com AINE<sup>(8)</sup> . Revisão sistemática que comparou desfecho entre AINE tradicionais e inibidores seletivos da COX-2 não observou diferença em medidas de atividade de doença, provas inflamatórias, função física ou efeitos adversos. Além disso, não foi observado efeito dose-resposta em estudos comparando dose baixa e alta de AINE<sup>(24)</sup> .  
Um estudo comparou o efeito do uso contínuo com o uso sob demanda de inibidores seletivos da COX-2 na atividade de doença em pacientes com EA. Após 2 anos, não foi observada diferença significativa em BASDAI, avaliação global e de dor do paciente ou medidas de proteína C reativa<sup>(25)</sup> . O naproxeno tem se revelado mais seguro com relação aos eventos cardiovasculares do que os outros AINE utilizados para o tratamento da EA. Em meta-análise que comparou AINE com placebo, foi demonstrado que o ibuprofeno e o diclofenaco possuem risco relativo (RR) similares (RR=1,51 [IC=0,96-2,37] e 1,63 [IC=1,12–2,37], respectivamente) para eventos cardiovasculares. O naproxeno foi o único AINE que não aumentou o risco relativo para tal evento (RR=0,92 [IC= 0.67-1.26]), podendo isso ser explicado pela sua maior capacidade de inibição da agregação plaquetária<sup>(29)</sup> . Em revisão sistemática de estudos observacionais (caso-controle e coortes), o naproxeno revelou-se como o AINE com menor risco relativo para infarto agudo do miocárdio comparado com o ibuprofeno e diclofenaco<sup>(30)</sup> . Outra recente revisão sistemática não encontrou diferença no número de eventos adversos entre naproxeno e outros AINE, embora não tenha avaliado eventos cardiovasculares especificamente<sup>(24)</sup> .  
Apesar de eficácias similares, há respostas terapêuticas individuais e diferenciadas. Em pacientes não responsivos a um dado AINE, pode-se substituí-lo por outro, devendo a escolha ser individualizada conforme contraindicações de cada medicamento, conveniência para o paciente, toxicidade relativa, custo e experiência de uso<sup>(31)</sup> .  
Os estudos que avaliaram a inibição da progressão radiográfica com o uso contínuo ou sob demanda de AINE apresentaram resultados conflitantes. O estudo citado previamente, que avaliou o uso de inibidores da COX-2, observou progressão radiológica três vezes maior no esquema de uso por demanda (quando necessário) em comparação com o esquema de uso contínuo<sup>(25)</sup> . Entretanto, ensaio clínico publicado recentemente, realizado com diclofenaco, também com 2 anos de seguimento, não demonstrou diferença no escore radiográfico entre os grupos<sup>(32)</sup> . Mais estudos são necessários para investigar as diferentes classes de AINE na formação óssea de pacientes com espondiloartrite. Apesar  
de não existir evidência clara na literatura, algumas entidades sugerem o uso contínuo de AINE em pacientes persistentemente sintomáticos e com doença ativa<sup>(13,18)</sup> .

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Uma meta-análise de 11 ensaios clínicos randomizados, incluindo 895 doentes de EA, comparou a efetividade da sulfassalazina contra placebo. Nenhum dos estudos incluídos realizou avaliação por BASDAI ou progressão radiográfica. Nessa meta-análise, o único trabalho que observou benefício da sulfassalazina, em reduzir a velocidade de sedimentação globular e a gravidade da rigidez axial foi também o realizado com pacientes com menor tempo de doença e mais artrite periférica. Desta forma, pacientes com menor tempo de doença, manifestações periféricas e maiores níveis de velocidade de sedimentação globular são os que mais podem se beneficiar da sulfassalazina<sup>(33)</sup> .  
Em uma meta-análise com 3 ensaios clínicos, incluindo 116 portadores de EA pelos critérios de Nova Iorque, na sua maioria homens com mais de 5 anos de doença, o benefício do metotrexato comparado com placebo foi questionável, uma vez que não houve diferença estatisticamente significativa nos desfechos primários estudados (por exemplo, dor, capacidade funcional, artrite, entesite, alterações radiográficas), mas apenas em desfechos compostos, incluindo rigidez matinal, bem-estar físico, atividade de doença e capacidade funcional<sup>(34)</sup> . Além disso, o metotrexato não parece acrescentar benefício em pacientes com manifestações axiais em uso de anti-TNF. Três outros estudos compararam o tratamento com metotrexato e infliximabe com infliximabe em monoterapia em 142 pacientes portadores de EA. Não foi observada diferença estatisticamente significativa no desfecho primário (ASAS20)<sup>(35)</sup> .

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
O uso de anti-TNF deve ser considerado se houver doença ativa e grave, definida clinicamente como ASDAS > 2,1 ou BASDAI 4 e dor na coluna > 4 pela Escala Visual Analógica (EVA) de dor, além de falha terapêutica com o uso de AINE ou, no caso de artrite periférica, falha com sulfassalazina (ou metotrexato)<sup>(36,37)</sup> . Tanto na EA quanto na espondiloartrite axial não radiográfica, os anti-TNFs acarretam benefícios relevantes, como redução da atividade da doença e melhora da função física. Entretanto, a eficácia dos anti-TNFs pode ser um pouco menor em pacientes com espondiloartrite axial não radiográfica, quando comparado com pacientes com EA<sup>(38,39)</sup> .  
Em uma revisão sistemática da Cochrane sobre a resposta aos anti-TNFs adalimumabe, etanercepte, infliximabe e golimumabe na EA, observou-se que pacientes em uso desses medicamentos apresentaram uma probabilidade 3 a 4 vezes maior de atingir ASAS40 em seis meses quando comparado com placebo. O número necessário para tratar (NNT) para atingir ASAS40 variou entre 3 e 5. A mesma revisão também demonstrou melhora na função física, com NNT para atingir uma diferença clinicamente significativa entre 2 e 4<sup>(39)</sup> .  
Meta-análise que incluiu dados de cinco ensaios randomizados comparou a eficácia dos anti-TNFs subcutâneos. Adalimumabe, etanercepte, golimumabe e certolizumabe pegol foram todos mais eficazes do que placebo em induzir resposta ASAS20 em 12 semanas. O golimumabe foi o medicamento com maior probabilidade de atingir esta resposta em comparação com o placebo. Não houve diferença estatisticamente significativa na comparação direta entre eles<sup>(40)</sup> .  
Estudo semelhante comparando o efeito desses medicamentos, porém incluindo infliximabe, evidenciou que este último apresentou maior probabilidade (67,6%) de ser o melhor tratamento. Adalimumabe, golimumabe, etanercepte e certolizumabe pegol demonstraram probabilidades de 17,7%, 10,6%, 4% e 0,1%, respectivamente<sup>(41)</sup> .  
Em geral, a resposta a estas MMCD biológicas é rápida, menos de 6 semanas, e mantido por até 10 anos<sup>(38,42–</sup> 44). Após 1 ano, cerca de 75% dos pacientes mantiveram boa resposta clínica e, após 2 anos, cerca de 60%(38). Em estudos populacionais, os fatores associados a melhor resposta aos anti-TNF foram idade jovem, sexo masculino, proteína C reativa elevada, presença de HLA-B27, menos fadiga e ausência de uso prévio de anti-TNF<sup>(8,45,46)</sup> . Até o momento, consideram-se os anti-TNF igualmente eficazes, não havendo recomendação baseada em evidência do uso de um agente antes dos outros<sup>(18)</sup> .  
Dois ensaios clínicos avaliaram a troca de etanercepte ou infliximabe para adalimumabe, em pacientes intolerantes ou resistentes, com melhora na resposta ao tratamento, independentemente do motivo da troca<sup>(47,48)</sup> . Outros estudos retrospectivos também confirmaram esses resultados, com outros medicamentos, na prática diária<sup>(49,50)</sup> .  
A evidência sobre o efeito dos anti-TNF na progressão radiográfica ainda é limitada. Sete ensaios clínicos forneceram resultados comparativos sobre o efeito dos anti-TNF na progressão radiográfica. Quatro desses estudos evidenciaram progressão radiográfica após 2 anos em pacientes em uso de adalimumabe, etanercepte, infliximabe e golimumabe. Outros três estudos compararam seus resultados com os de uma coorte de pacientes sem uso de biológicos (OASIS - _Outcomes in Ankylosing Spondylitis International Study_ ), não encontrando diferença na taxa de progressão radiográfica<sup>(38,51)</sup> .  
Estudo observacional de vida-real com 176 portadores de EA em atividade avaliou um escore radiográfico, após 2, 4 e 6 anos da introdução da terapia com anti-TNF (infliximabe, adalimumabe ou etanercepte). Foi observada progressão radiográfica lenta e linear nestes pacientes, apesar da atividade de doença e das provas inflamatórias terem se reduzido significativamente com a terapia<sup>(52)</sup> . Os resultados desses estudos devem ser interpretados com cautela. O  
acompanhamento por período relativamente curto e a baixa sensibilidade da radiografia impedem a elaboração de conclusões acuradas.  
A presença de lesões inflamatórias nos cantos vertebrais, visualizadas pela ressonância magnética, parece estar relacionada ao desenvolvimento de sindesmófitos nesses locais<sup>(53–55)</sup> . Em revisão sistemática, os anti-TNFs não demonstraram efeito significativo na neoformação óssea na EA. Este resultado foi atribuído ao curto período de observação, ao avançado estágio de doença da população estudada, à ausência de um controle e às limitações do escore radiográfico utilizado. O uso de anti-TNFs poderia retardar a progressão radiográfica em pacientes com doença inicial e com maior tempo de uso destes medicamentos. De forma contrária, não houve benefício em estágio mais avançado da doença, quando sindesmófitos ou infiltração gordurosa já estão presentes<sup>(56)</sup> .  
Além disso, o uso de anti-TNFs parece melhorar a massa óssea de pacientes com EA. Revisão sistemática de sete estudos longitudinais e um ensaio clínico, que incluiu 568 pacientes, evidenciou aumento da massa óssea da coluna e do quadril total após dois anos de seguimento<sup>(57)</sup> . Esses estudos não avaliaram o risco de fratura nesta população de pacientes.  
Um estudo de registro nacional observou que a sobrevida dos pacientes tratados com anti-TNFs é significamente maior naqueles com EA do que em pacientes com artrite reumatoide (AR). Além disso, os pacientes com EA descontinuam anti-TNFs duas vezes menos do que os com AR, mesmo após ajustes para gênero e uso de corticosteroides. Os principais motivos para descontinuação foram ineficácia e efeitos adversos em ambas doenças<sup>(58)</sup> . Dados de revisões sistemáticas sugerem que, em curto prazo, os anti-TNFs estão associados a maiores taxas de efeitos adversos, infecções graves, reativação de tuberculose, câncer não melanótico de pele e suspensão da terapia em comparação ao tratamento controle. Avaliações de longo prazo são escassas, apesar de sugerir perfis de segurança semelhantes entre os anti-TNF<sup>(38,59)</sup> .  
A evidência publicada até o momento sobre a descontinuação ou a redução de anti-TNFs em pacientes com espondiloartrite axial é escassa e fraca. Uma revisão sistemática da literatura avaliou cinco estudos sobre a descontinuação e oito estudos sobre redução dos anti-TNFs após obtenção de redução ou baixa atividade de doença. A descontinuação da terapia anti-TNF em pacientes com espondiloartrite axial levou à reativação na maioria dos casos. Cerca de 79% dos paciente apresentaram agudização em tempo médio de 16 semanas. Por outro lado, a redução na terapia biológica apresentou melhores resultados. O percentual de pacientes que manteveram remissão ou baixa atividade de doença, informado em cinco estudos, variou entre 53% e 100%. Os três estudos restantes, que reportaram seus dados pela mudança média do BASDAI e da proteína C reativa, não observaram aumento significativo nesses parâmetros<sup>(60)</sup> .  
O certolizumabe pegol é um fragmento _Fab_ de um anticorpo recombinante humanizado contra o fator de necrose tumoral alfa (TNFα) e conjugado com polietilenoglicol (PEG). A peguilação atrasa a eliminação deste medicamento da circulação por uma variedade de mecanismos, incluindo a diminuição da depuração renal, diminuição da proteólise e diminuição da imunogenicidade. O estudo RAPID-axSpA demonstrou a eficácia do certolizumabe pegol em pacientes com EA e com espondiloartrite axial não radiográfica em atividade em comparação com placebo. A melhora na atividade de doença foi observada na primeira semana e mantida até a 96º semana de tratamento<sup>(61,62)</sup> . Metaanálises não observaram diferença de eficácia entre o certolizumabe pegol e os demais anti-TNFs<sup>(40,43,63,64)</sup> .  
O secuquinumabe, um anticorpo monoclonal anti-interleucina-17A, demonstrou benefício em pacientes com EA moderada a grave em dois estudos multicêntricos de fase 3<sup>(65)</sup> . Na dose de 150mg, por via subcutânea, 61% dos pacientes atingiram ASAS20 em 16 semanas, contra 28% do placebo<sup>(66)</sup> . Nesses estudos, a terapia com secuquinumabe beneficiou tanto os pacientes que utilizaram anti-TNFs previamente quanto os pacientes sem histórico de medicamentos biológicos.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
A injeção intra-articular nas sacroilíacas pode trazer benefício de curto a médio prazo, sendo opção terapêutica para os casos não responsivos ao uso de AINE e com dor isolada nas sacroilíacas. Inexistem evidências que permitam avaliar o uso de baixas doses de prednisona (ou corticosteroide equivalente) em EA<sup>(18)</sup> . Doses elevadas de glicocorticoide não são recomendadas por não acrescentarem benefício superior aos malefícios oferecidos.  
O tratamento de EA pode ser instituído conforme a manifestação musculoesquelética predominante ( **Apêndice**  
**2** ):

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
**de imagem, deve respeitar o seguinte protocolo (Apêndice 2 – Fluxo A):**  
- no diagnóstico, se escore ASDAS <u><</u> 2,1 ou BASDAI < 4, deve-se considerar tratamento medicamentoso  
- sintomático (AINE) e implementar medidas não medicamentosas;  
- no diagnóstico, se o escore ASDAS > 2,1 ou BASDAI > a 4, deve-se prescrever AINE conforme esquemas  
- de administração;  
- se houver falha<sup>**a**</sup> com AINE em dose adequada por 1 mês, deve-se substituí-lo por outro AINE;  
- considerar a infiltração da entesite, se possível, ao longo do acompanhamento do paciente;  
- se houver falha<sup>**a**</sup> com dois AINE diferentes em doses adequadas por 3 meses no total (1 a 2 meses com o primeiro AINE e 1 a 2 meses com o segundo AINE), deve-se considerar o uso de anti-TNF na lombalgia inflamatória ou na entesite confirmada por exame de imagem (ressonância magnética ou ultrassonografia);  
- se houver falha<sup>a</sup> ou hipersensibilidade com anti-TNF em dose adequada por 6 meses, deve-se considerar sua substituição por outro anti-TNF ou secuquinumabe.  
> **a** Considera-se falha a ausência de redução de pelo menos 1,1 ponto na escala ASDAS ou ausência de redução de, pelo menos, 50% ou de 2 pontos absolutos na escala BASDAI).  
**B - O tratamento da artrite periférica deve respeitar o seguinte protocolo (Apêndice 2 – Fluxo B):**  
- implementar medidas não medicamentosas;  
- considerar sempre a infiltração intra-articular de glicocorticoide ao longo do acompanhamento do paciente;  
- se houver falha<sup>**b**</sup> com a infiltração, deve-se usar AINE em dose preconizada;  
- se houver falha<sup>**b**</sup> persistente com a infiltração e com AINE em dose adequada por 1 mês, deve-se substituí-lo  
- por um outro AINE;  
- se houver falha<sup>**b**</sup> persistente com a infiltração e com 2 AINEs diferentes em doses adequadas por 3 meses no total (1 a 2 meses com o primeiro AINE e 1 a 2 meses com o segundo AINE), deve-se considerar, preferencialmente, sulfassalazina (o metotrexato pode ser considerado na contraindicação de uso da sulfassalazina);  
- se o uso de AINE estiver contraindicado, deve-se considerar, preferencialmente sulfassalazina (o metotrexato pode ser considerado na contraindicação de uso da sulfassalazina);  
- se houver falha<sup>**b**</sup> persistente com a infiltração, com 2 AINEs diferentes em doses adequadas por 3 meses no total (1 a 2 meses com o primeiro AINE e 1 a 2 meses com o segundo AINE) e com sulfassalazina (ou metotrexato) em dose adequada por 6 meses, deve-se considerar anti-TNF;  
- se houver falha<sup>**b**</sup> com anti-TNF em dose adequada por 6 meses, deve-se considerar sua substituição por outro  
anti-TNF.  
- se houver falha<sup>b</sup> ou hipersensibilidade com anti-TNF em dose adequada por 6 meses, deve-se considerar sua substituição por outro anti-TNF ou secuquinumabe .  
> **b** Considera-se falha a ausência de redução de pelo menos 1,1 ponto na escala ASDAS.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
- Ibuprofeno: comprimidos revestidos de 200 mg, 300 mg e 600 mg, solução oral de 50 mg/mL.  
- Naproxeno: comprimidos de 250 mg e 500 mg.  
- Sulfassalazina: comprimidos de 500 mg.  
- Metilprednisolona: frasco de 40 mg/2 mL.  
- Metotrexato: comprimidos de 2,5 mg; frasco-ampola com 50 mg/2 mL.  
- Adalimumabe: solução injetável de 40 mg.  
- Etanercepte: frasco-ampola ou seringa preenchida de 25 mg e 50 mg.  
- Infliximabe: frasco-ampola com 100 mg/10 mL.  
- Golimumabe: seringa preenchida com 50 mg. Aprovado apenas para pacientes adultos.  
- Certolizumabe pegol: solução injetável com 200mg/mL com caneta aplicadora. Aprovado apenas para pacientes adultos.  
- Secuquinumabe: solução injetável com 150mg/ml com caneta aplicadora. Aprovado apenas para pacientes adultos.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
- Ibuprofeno: 600 mg/dia a 2.700 mg/dia, por via oral, divididos em 3 administrações (8/8 horas).  
- Naproxeno: 500 mg/dia a 1.500 mg/dia, por via oral, divididos em até 3 administrações (8/8 horas).  
- Sulfassalazina: 500 mg/dia a 3.000 mg/dia, por via oral, divididos em 2 administrações (12/12 horas).  
- Metiprednisolona: 40 mg a 80 mg, intra ou periarticular, a cada 3 meses.  
- Metotrexato: 7,5 mg a 25 mg, por via oral, subcutânea ou intramuscular, a cada semana.  
- Adalimumabe: 40 mg, por via subcutânea, a cada 2 semanas.  
- Etanercepte: 50 mg, por via subcutânea, a cada semana.  
- Infliximabe: 5 mg/kg, por via intravenosa, nas semanas 0, 2, 6 e, depois, a cada 8 semanas.  
- Golimumabe: 50mg, por via subcutânea, a cada 4 semanas. Aprovado apenas para pacientes adultos.  
- Certolizumabe pegol: dose de indução de 400 mg (duas aplicações de 200 mg nas semanas 0, 2 e 4). Após, 200 mg a cada duas semanas ou 400 mg a cada quatro semanas. Aprovado apenas para pacientes adultos.  
- Secuquinumabe: A dose de indução recomendada é 150 mg por injeção subcutânea com administração inicial nas semanas 0, 1, 2, 3 e 4, seguida por administração de manutenção uma vez a cada 4 semanas. Aprovado apenas para pacientes adultos.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
O tempo de tratamento não é pré-determinado, devendo o tratamento ser mantido enquanto houver benefício clínico. Apesar de alguns estudos observarem manutenção de remissão após a retirada dos biológicos anti-TNF<sup>(60,67–69)</sup> , inexistem critérios para a interrupção do tratamento. Após a remissão, a maioria dos pacientes apresenta recidiva com a interrupção do tratamento<sup>(60,70)</sup> .  
Na falha ao segundo anti-TNF ou secuquinumabe (ausência de resposta depois de, pelo menos, 6 meses de uso da dose preconizada), pode ser considerado um terceiro anti-TNF ou secuquinumabe (se este último não foi usado anteriormente), embora as evidências em favor dessa conduta sejam escassas<sup>(49,50)</sup> . Na ausência de resposta com o terceiro anti-TNF ou secuquinumabe por, pelo menos, 6 meses, deve-se suspender a terapia.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Com o tratamento adequado, espera-se melhora da dor, rigidez axial e periférica, capacidade funcional e laboral e qualidade de vida do paciente.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Devem ser monitoradas as resposta terapêutica e os efeitos colaterais<sup>(13,71)</sup> .  
A resposta ao tratamento de EA axial consiste na redução de pelo menos 1,1 ponto no escore ASDAS ou na redução mínima de 50% ou de 2 pontos (valor absoluto) no escore BASDAI ou a partir de 12 semanas. Artrite periférica, entesite e dactilite são avaliadas por anamnese e exame físico. Reavaliações clínicas podem ser realizadas a cada 3 meses em doença ativa e anualmente em doença estável. Exames laboratoriais (velocidade de hemossedimentação e proteína C reativa), que devem ser feitos antes e durante o tratamento (nos períodos de maior atividade de doença, a cada 1-3 meses e de menor, a cada 3 meses), são úteis na avaliação de atividade de doença. Radiografias simples de articulações sacroilíacas, bacia, coluna dorsal e lombossacra podem ser realizadas no início do acompanhamento e a cada 2 anos, buscando danos estruturais evolutivos, que, quando presentes, podem indicar mudança de tratamento<sup>(8,37)</sup> .  
Exames laboratoriais, tais como hemograma, contagem de plaquetas e dosagens séricas de AST/TGO e ALT/TGP, devem ser realizados antes do início do tratamento, constituindo o painel laboratorial de monitorização trimestral dos principais efeitos adversos relacionados aos medicamentos preconizados neste PCDT ( **Quadro 3** ). Antes do início do uso dos anti-TNF, deve-se realizar a investigação de tuberculose latente (com teste tuberculínico e radiografia de tórax), de hepatites virais B e C e de infecção pelo HIV (vírus da imunodeficiência humana)<sup>(8)</sup> . Casos positivos devem ser considerados como especiais e a conduta deve ser individualizada. De forma geral, a tuberculose latente pode receber tratamento conjuntamente com o uso de anti-TNF após tempo adequado de quimioprofilaxia. Não há necessidade de repetir o HLA-B27 durante o acompanhamento dos pacientes. Teste tuberculínico, radiografia de tórax e sorologias para hepatites B e C e HIV só devem ser repetidos a critério médico.  
Durante o uso de imunossupressores, especialmente os anti-TNF, a eficácia de algumas vacinas, tais como antipneumocócica e contra influenza, pode ser reduzida<sup>(72)</sup> . O uso de vacinas com vírus vivos (vacina oral contra poliomielite – Sabin, sarampo, varicela, febre amarela e bacilo de Calmette-Guerin – BCG) é contraindicado<sup>(73)</sup> .  
**Quadro 3** - Monitorização dos Principais Efeitos Adversos no Tratamento de EA  
|**Medicamento**|**Avaliação**|**Conduta diante de alterações**|
|---|---|---|
||Hemograma,|- Anemia, leucopenia ou trombocitopenia novas ou mais acentuadas:<br>reduzir a dose em 25% a 50%; interromper o uso do medicamento se<br>persistirem as alterações.|
|Metotrexato|creatinina, AST/TGO<br>e ALT/TGP a cada 3|- Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o LSN:<br>reduzir a dose em 25% a 50%.|
||meses|- Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o LSN:|
|||suspender o uso do medicamento até AST/TGO e ALT/TGP entre 1 e|
|||3 vezes o LSN e reiniciar com 50% da dose.|  
|**Medicamento**|**Avaliação**|**Conduta diante de alterações**|
|---|---|---|
|||- Elevação de AST/TGO e ALT/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.<br>- Depuração de creatinina endógena entre 10 e 50ml/minuto:<br>administrar 50% da dose.<br>- Depuração de creatinina endógena abaixo de 10ml/minuto: evitar o<br>uso do medicamento.|
|Sulfassalazina|Hemograma, AST/<br>TGO e<br>ALT/TGP a cada 3<br>meses|- Anemia, leucopenia ou trombocitopenia novas ou mais acentuadas:<br>reduzir a dose em 25% a 50%; interromper o uso do medicamento se<br>persistirem as alterações.<br>- Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o LSN:<br>reduzir a dose em 25% a 50%.<br>- Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o LSN:<br>suspender o uso do medicamento até AST/TGO e ALT/TGP entre 1 e<br>3 vezes o LSN e reiniciar com 50% da dose.<br>- Elevação de AST/TGO e ALT/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.|
|Etanercepte,<br>Adalimumabe,<br>Infliximabe,<br>Golimumabe*,<br>Certolizumabe<br>Pegol* ou<br>Secuquinumabe*|Hemograma, AST/<br>TGO e ALT/TGP a<br>cada 3 meses|- Anemia, leucopenia ou trombocitopenia novas ou mais acentuadas:<br>reduzir a dose em 25% a 50%; interromper o uso do medicamento se<br>persistirem as alterações.<br>- Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o LSN:<br>reduzir a dose em 25% a 50%.<br>- Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o LSN:<br>suspender o uso do medicamento até AST/TGO e ALT/TGP entre 1 e<br>3 vezes o LSN e reiniciar com 50% da dose.<br>- Elevação de AST/TGO e ALT/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.|  
*Aprovado apenas para pacientes adultos.  
Alguns medicamentos recomendados para o tratamento da espondilite ancilosante podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
Antes do início do uso de MMCD biológicos e com objetivo de realizar o planejamento terapêutico adequado, deve-se considerar as seguintes condutas:  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
- Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A  
- radiografia simples de tórax deve ser realizada para excluir a possibilidade de TB ativa.  
- Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD)  
- ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
- Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
- Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de MMCD biológicos após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, à critério da equipe de saúde assistente, o início de uso de MMCD biológicos pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
- Nos casos de troca do MMCD biológico, não é necessário repetir as condutas preconizadas para início de tratamento.  
Para fins de acompanhamento, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
- Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
- Para que o uso dos MMCD biológico não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com MMCD biológico devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com MMCD biológico devem manter o monitoramento com o IGRA.  
- Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
- Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
- Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
O tempo de tratamento de EA é imprevisível<sup>(8)</sup> . Nos raros casos de remissão após interrupção de tratamento, revisões anuais podem ser adotadas<sup>(67)</sup> . Nessas consultas, além da história e do exame físico, exames como velocidade de hemossedimentação e proteína C reativa podem ser solicitados. Se houver recidiva, retoma-se o tratamento segundo as recomendações deste Protocolo.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Doentes de EA devem ser atendidos por equipe em serviço especializado, que conte com reumatologista, para seu adequado diagnóstico, inclusão no tratamento e acompanhamento. Como o controle dessa doença exige experiência e familiaridade com manifestações clínicas próprias, convém que o médico responsável tenha experiência e seja treinado nesse atendimento.  
Assim, devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da assistência farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Para a administração dos medicamentos biológicos intravenosos, é essencial o atendimento centralizado para maior racionalidade do uso e avaliação da efetividade dos medicamentos.  
A administração intra-articular de metilprednisolona é compatível com o procedimento 03.03.09.003-0 - Infiltração de substâncias em cavidade sinovial, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do Sistema Único de Saúde (SUS).

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Deve-se cientificar o paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
1. Conde RA, Sampaio-Barros PD, Donadi EA, Kraemer MHS, Persoli L, Coimbra IB, et al. Frequency of the HLAB27 alleles in Brazilian patients with AS. J Rheumatol. 2003 Nov;30(11):2512.  
2. Sampaio-Barros PD. Epidemiology of Spondyloarthritis in Brazil. Am J Med Sci. 2011 Apr;341(4):287–8.  
3. Gehlen M, Regis KC, Skare TL. Demographic, clinical, laboratory and treatment characteristics of spondyloarthritis patients with and without acute anterior uveitis. Sao Paulo Med J. 2012;130(3):141–4.  
4. Skare TL, Leite N, Bortoluzzo AB, Gonçalves CR, da Silva JAB, Ximenes AC, et al. Effect of age at disease onset in the clinical profile of spondyloarthritis: a study of 1424 Brazilian patients. Clin Exp Rheumatol. 2012; 30(3):351–7.  
5. Yu, David T; Tubergen A. Clinical manifestations of ankylosing spondylitis in adults. UpToDate. 2015. 6. Sampaio-Barros PD, Pereira IA, Hernández-Cuevas C, Berman A, Burgos-Vargas R, Gutierrez MA, et al. An analysis of 372 patients with anterior uveitis in a large Ibero-American cohort of spondyloarthritis: the RESPONDIA Group. Clin Exp Rheumatol. 2013; 31(4):484–9.  
7. Marc C. Hochberg, Alan J. Silman, Josef S. Smolen, Michael E. Weinblatt and MHW. Rheumatology. 6th editio. Elsevier; 2015.  
8. Yu D. Assessment and treatment of ankylosing spondylitis in adults. UpToDate. 2016.  
9. Yu, David; van Tubergen A. Diagnosis and differential diagnosis of ankylosing spondylitis and non-radiographic axial spondyloarthritis in adults. UpToDate. 2016.  
10. Rudwaleit M, van der Heijde D, Landewe R, Listing J, Akkoc N, Brandt J, et al. The development of Assessment of SpondyloArthritis international Society classification criteria for axial spondyloarthritis (part II): validation and final selection. Ann Rheum Dis. 2009 Jun 1;68(6):777–83.  
11. van der Linden S, Valkenburg HA, Cats A. Evaluation of diagnostic criteria for ankylosing spondylitis. A proposal for modification of the New York criteria. Arthritis Rheum. 1984 Apr;27(4):361–8.  
12. Azevedo VF, Paiva E dos S, Felippe LRH, Moreira RA. Occurrence of fibromyalgia in patients with ankylosing spondylitis. Rev Bras Reumatol. 2010;50(6):646–50.  
13. Ward MM, Deodhar A, Akl EA, Lui A, Ermann J, Gensler LS, et al. American College of Rheumatology/Spondylitis Association of America/Spondyloarthritis Research and Treatment Network 2015 Recommendations for the Treatment of Ankylosing Spondylitis and Nonradiographic Axial Spondyloarthritis. Arthritis Rheumatol. 2016;68(2):282–98.  
14. Sieper J. Management of ankylosing spondylitis/axial spondyloarthritis. Rheumatology. Sixth edit. 2015. p. 970– 85. 15. Sieper J, Rudwaleit M, Baraliakos X, Brandt J, Braun J, Burgos-Vargas R, et al. The Assessment of SpondyloArthritis international Society (ASAS) handbook: a guide to assess spondyloarthritis. Ann Rheum Dis. 2009 Jun 1;68(Suppl 2):ii1-ii44.  
16. Lukas C, Landewé R, Sieper J, Dougados M, Davis J, Braun J, et al. Development of an ASAS-endorsed disease activity score (ASDAS) in patients with ankylosing spondylitis. Ann Rheum Dis. 2009 Jan;68(1):18–24.  
17. Machado P, Landewe R, Lie E, Kvien TK, Braun J, Baker D, et al. Ankylosing Spondylitis Disease Activity Score (ASDAS): defining cut-off values for disease activity states and improvement scores. Ann Rheum Dis. 2011 Jan 1;70(1):47–53.  
18. Sampaio-Barros PD, Keiserman M, Souza Meirelles E de, Medeiros Pinheiro M de, Ximenes AC, Azevedo VF, et al. Recomendações sobre diagnóstico e tratamento da espondilite anquilosante. Rev Bras Reumatol. 2013 May;53(3):242–57.  
19. O’Dwyer T, O’Shea F, Wilson F. Physical activity in spondyloarthritis: a systematic review. Rheumatol Int. Germany; 2015 Mar;35(3):393–404.  
20. Rosu OM, Ancuta C. McKenzie training in patients with early stages of ankylosing spondylitis: results of a 24-week controlled study. Eur J Phys Rehabil Med. 2015 Jun;51(3):261–8.  
21. Dundar U, Solak O, Toktas H, Demirdal US, Subasi V, Kavuncu V, et al. Effect of aquatic exercise on ankylosing spondylitis: a randomized controlled trial. Rheumatol Int. 2014 Nov 14;34(11):1505–11.  
22. Dagfinrud H, Hagen KB, Kvien TK. Physiotherapy interventions for ankylosing spondylitis. In: Dagfinrud H, editor. Cochrane Database of Systematic Reviews. Chichester, UK: John Wiley & Sons, Ltd; 2008.  
23. O’Dwyer T, O’Shea F, Wilson F. Exercise therapy for spondyloarthritis: a systematic review. Rheumatol Int. Germany; 2014 Jul;34(7):887–902.  
24. Kroon FP, van der Burg LR, Ramiro S, Landewé RB, Buchbinder R, Falzon L, et al. Non-steroidal antiinflammatory drugs (NSAIDs) for axial spondyloarthritis (ankylosing spondylitis and non-radiographic axial spondyloarthritis). In: Kroon FP, editor. Cochrane Database of Systematic Reviews. Chichester, UK: John Wiley & Sons, Ltd; 2015.  
25. Wanders A, Heijde D van der, Landewé R, Béhier J-M, Calin A, Olivieri I, et al. Nonsteroidal antiinflammatory drugs reduce radiographic progression in patients with ankylosing spondylitis: A randomized clinical trial. Arthritis Rheum. 2005 Jun;52(6):1756–65.  
26. Escalas C, Trijau S, Dougados M. Evaluation of the treatment effect of NSAIDs/TNF blockers according to different domains in ankylosing spondylitis: results of a meta-analysis. Rheumatology. 2010 Jul 1;49(7):1317– 25.  
27. Sieper J, Lenaerts J, Wollenhaupt J, Rudwaleit M, Mazurov VI, Myasoutova L, et al. Efficacy and safety of infliximab plus naproxen versus naproxen alone in patients with early, active axial spondyloarthritis: results from the double-blind, placebo-controlled INFAST study, Part 1. Ann Rheum Dis. 2014 Jan;73(1):101–7.  
28. Sieper J, Lenaerts J, Wollenhaupt J, Rudwaleit M, Mazurov VI, Myasoutova L, et al. Maintenance of biologic-free remission with naproxen or no treatment in patients with early, active axial spondyloarthritis: results from a 6-month, randomised, open-label follow-up study, INFAST Part 2. Ann Rheum Dis. 2014 Jan;73(1):108–13.  
29. Kearney PM. Do selective cyclo-oxygenase-2 inhibitors and traditional non-steroidal anti-inflammatory drugs increase the risk of atherothrombosis? Meta-analysis of randomised trials. BMJ. 2006 Jun 3;332(7553):1302–8. 30. Hernandez-Diaz S, Varas-Lorenzo C, Garcia Rodriguez LA. Non-Steroidal Antiinflammatory Drugs and the Risk of Acute Myocardial Infarction. Toxicology. 2006 Mar;98(3):266–74.  
31. Fuchs, FD; Wannmacher L. Farmacologia clínica - fundamentos da terapêutica racional. 4th ed. Rio de Janeiro: Guanabara Koogan; 2010.  
32. Sieper J, Listing J, Poddubnyy D, Song I-H, Hermann K-G, Callhoff J, et al. Effect of continuous versus on-demand treatment of ankylosing spondylitis with diclofenac over 2 years on radiographic progression of the spine: results from a randomised multicentre trial (ENRADAS). Ann Rheum Dis. 2016 Aug;75(8):1438–43.  
33. Chen J, Lin S, Liu C. Sulfasalazine for ankylosing spondylitis. In: Chen J, editor. Cochrane Database of Systematic Reviews. Chichester, UK: John Wiley & Sons, Ltd; 2014.  
34. Chen J, Veras MM, Liu C, Lin J. Methotrexate for ankylosing spondylitis. In: Chen J, editor. Cochrane Database of Systematic Reviews. Chichester, UK: John Wiley & Sons, Ltd; 2013.  
35. Lin S, He M, Chen J. Tumor necrosis factor-alpha inhibitor combined with methotrexate for ankylosing spondylitis: A systematic review and meta-analysis. Rheumatol Reports. 2014;6(1):6–11. 36. Yu D. General guidelines for use of anti-tumor necrosis factor alpha agents in ankylosing spondylitis and in peripheral and non-radiographic axial spondyloarthritis. UpToDate. 2015.  
37. van der Heijde D, Sieper J, Maksymowych WP, Dougados M, Burgos-Vargas R, Landewe R, et al. 2010 Update of the international ASAS recommendations for the use of anti-TNF agents in patients with axial spondyloarthritis. Ann Rheum Dis. 2011 Jun 1;70(6):905–8.  
38. Corbett M, Soares M, Jhuti G, Rice S, Spackman E, Sideris E, et al. Tumour necrosis factor-α inhibitors for ankylosing spondylitis and non-radiographic axial spondyloarthritis: A systematic review and economic evaluation. Health Technol Assess (Rockv). 2016;20(9):333.  
39. Maxwell LJ, Zochling J, Boonen A, Singh JA, Veras MM, Tanjong Ghogomu E, et al. TNF-alpha inhibitors for ankylosing spondylitis. In: Maxwell LJ, editor. Cochrane Database of Systematic Reviews. Chichester, UK: John Wiley & Sons, Ltd; 2015.  
40. Migliore A, Bizzi E, Bernardi M, Picchianti Diamanti A, Lagana B, Petrella L, et al. Indirect Comparison Between Subcutaneous Biologic Agents in Ankylosing Spondylitis. Clin Drug Investig. 2015 Jan 12;35(1):23– 9.  
41. Migliore A, Bizzi E, Massafra U. Indirect comparison of the effects of anti-tnf biological agents in patients with ankylosing spondylitis by means of a mixed treatment comparison performed on efficacy data from published randomised, controlled trials. Value heal. 2014 nov;17(7):a555.  
42. Braun J, Deodhar A, Inman RD, van der Heijde D, Mack M, Xu S, et al. Golimumab administered subcutaneously every 4 weeks in ankylosing spondylitis: 104-week results of the GO-RAISE study. Ann Rheum Dis. 2012 May;71(5):661–7.  
43. Corbett M, Soares M, Jhuti G, Rice S, Spackman E, Sideris E, et al. Tumour necrosis factor-α inhibitors for ankylosing spondylitis and non-radiographic axial spondyloarthritis: A systematic review and economic evaluation. Health Technol Assess (Rockv). 2016 Feb;20(9):333.  
44. Baraliakos X, Listing J, Fritz C, Haibel H, Alten R, Burmester G-R, et al. Persistent clinical efficacy and safety of infliximab in ankylosing spondylitis after 8 years--early clinical response predicts long-term outcome. Rheumatology. 2011 Sep 1;50(9):1690–9.  
45. RUDWALEIT M, CLAUDEPIERRE P, WORDSWORTH P, CORTINA EL, SIEPER J, KRON M, et al. Effectiveness, Safety, and Predictors of Good Clinical Response in 1250 Patients Treated with Adalimumab for Active Ankylosing Spondylitis. J Rheumatol. 2009 Apr 1;36(4):801–8.  
46. Glintborg B, Ostergaard M, Krogh NS, Dreyer L, Kristensen HL, Hetland ML. Predictors of treatment response and drug continuation in 842 patients with ankylosing spondylitis treated with anti-tumour necrosis factor: results from 8 years’ surveillance in the Danish nationwide DANBIO registry. Ann Rheum Dis. 2010 Nov 1;69(11):2002–8  
47. Rudwaleit M, Van den Bosch F, Kron M, Kary S, Kupper H. Effectiveness and safety of adalimumab in patients with ankylosing spondylitis or psoriatic arthritis and history of anti-tumor necrosis factor therapy. Arthritis Res Ther. 2010;12(3):R117.  
48. Spadaro A, Punzi L, Marchesoni A, Lubrano E, Mathieu A, Cantini F, et al. Switching from infliximab or etanercept to adalimumab in resistant or intolerant patients with spondyloarthritis: a 4-year study. Rheumatology (Oxford). 2010 Jun;49(6):1107–11.  
49. Lie E, van der Heijde D, Uhlig T, Mikkelsen K, Rodevand E, Koldingsnes W, et al. Effectiveness of switching between TNF inhibitors in ankylosing spondylitis: data from the NOR-DMARD register. Ann Rheum Dis. 2011 Jan 1;70(1):157–63.  
50. Dadoun S, Geri G, Paternotte S, Dougados M, Gossec L. Switching between tumour necrosis factor blockers in spondyloarthritis: a retrospective monocentre study of 222 patients. Clin Exp Rheumatol. 2011; 9(6):1010–3.  
51. Ramiro S, Stolwijk C, van Tubergen A, van der Heijde D, Dougados M, van den Bosch F, et al. Evolution of radiographic damage in ankylosing spondylitis: a 12 year prospective follow-up of the OASIS study. Ann Rheum Dis. 2015 Jan 10;74(1):52–9.  
52. Maas F, Spoorenberg A, Brouwer E, Bos R, Efde M, Chaudhry RN, et al. Spinal Radiographic Progression in Patients with Ankylosing Spondylitis Treated with TNF-α Blocking Therapy: A Prospective Longitudinal Observational Cohort Study. 2015 Apr 16;10(4):e0122693.  
53. Baraliakos X, Listing J, Rudwaleit M, Sieper J, Braun J. The relationship between inflammation and new bone formation in patients with ankylosing spondylitis. Arthritis Res Ther. 2008;10(5):R104.  
54. Maksymowych WP, Chiowchanwisawakit P, Clare T, Pedersen SJ, Østergaard M, Lambert RGW. Inflammatory lesions of the spine on magnetic resonance imaging predict the development of new syndesmophytes in ankylosing spondylitis: Evidence of a relationship between inflammation and new bone formation. Arthritis Rheum. 2009 Jan;60(1):93–102.  
55. Chiowchanwisawakit P, Lambert RGW, Conner-Spady B, Maksymowych WP. Focal fat lesions at vertebral corners on magnetic resonance imaging predict the development of new syndesmophytes in ankylosing spondylitis. Arthritis Rheum. 2011 Aug;63(8):2215–25. 56. Zhang J-R, Liu X-J, Xu W-D, Dai S-M. Effects of tumor necrosis factor-α inhibitors on new bone formation in ankylosing spondylitis. Jt Bone Spine. 2016;83(3):257–64.  
57. Nigil Haroon N, Sriganthan J, Al Ghanim N, Inman RD, Cheung AM. Effect of TNF-alpha inhibitor treatment on bone mineral density in patients with ankylosing spondylitis: A systematic review and meta-analysis. Semin Arthritis Rheum. 2015;44(2):155–61.  
58. Fafá BP, Louzada-Junior P, Titton DC, Zandonade E, Ranza R, Laurindo I, et al. Drug survival and causes of discontinuation of the first anti-TNF in ankylosing spondylitis compared with rheumatoid arthritis: analysis from BIOBADABRASIL. Clin Rheumatol. 2015 May 8;34(5):921–7.  
59. Pereira R, Lago P, Faria R, Torres T. Safety of Anti-TNF Therapies in Immune-Mediated Inflammatory Diseases: Focus on Infections and Malignancy. Drug Dev Res. 2015;76(8):419–27.  
60. Navarro-Compán V, Plasencia-Rodríguez C, de Miguel E, Balsa A, Martín-Mola E, Seoane-Mato D, et al. AntiTNF discontinuation and tapering strategies in patients with axial spondyloarthritis: a systematic literature review. Rheumatology. 2016 Jul;55(7):1188–94.  
61. Landewé R, Braun J, Deodhar A, Dougados M, Maksymowych WP, Mease PJ, et al. Efficacy of certolizumab pegol on signs and symptoms of axial spondyloarthritis including ankylosing spondylitis: 24-week results of a double-blind randomised placebo-controlled Phase 3 study. Ann Rheum Dis. 2014 Jan;73(1):39–47.  
62. Sieper J, Landewé R, Rudwaleit M, van der Heijde D, Dougados M, Mease PJ, et al. Effect of Certolizumab Pegol Over Ninety-Six Weeks in Patients With Axial Spondyloarthritis: Results from a Phase III Randomized Trial. Arthritis Rheumatol. 2015 Mar;67(3):668–77.  
63. Benedict A, Ishak J, Gal P, Proskorovsky I, Cappelleri JCC, Everiss T, et al. Comparative Analysis of the Effectiveness of anti-TNF Therapies in Non-Radiographic Axial Spondyloarthritis Using Novel Statistical Techniques. Ann Rheum Dis. 2015 Jun 9;74(Suppl 2):270.3-271.  
64. Callhoff J, Sieper J, Weiß A, Zink A, Listing J. Efficacy of TNFα blockers in patients with ankylosing spondylitis and non-radiographic axial spondyloarthritis: a meta-analysis. Ann Rheum Dis. 2015 Jun;74(6):1241–8. 65. Baeten D, Sieper J, Braun J, Baraliakos X, Dougados M, Emery P, et al. Secukinumab, an Interleukin-17A Inhibitor, in Ankylosing Spondylitis. N Engl J Med. 2015 Dec 24;373(26):2534–48.  
66. Sieper J, Deodhar A, Marzo-Ortega H, Aelion JA, Blanco R, Jui-Cheng T, et al. Secukinumab efficacy in anti-TNFnaive and anti-TNF-experienced subjects with active ankylosing spondylitis: results from the MEASURE 2 Study. Ann Rheum Dis. 2016 Aug 31;annrheumdis-2016-210023.  
67. Song I-H, Haibel H, Poddubnyy D, Braun J, Sieper J. Withdrawal of biologic therapy in axial spondyloarthritis: the experience in early disease. Clin Exp Rheumatol. 2013; 31(4 Suppl 78):S37-42.  
68. Song I-H, Althoff CE, Haibel H, Hermann K-GA, Poddubnyy D, Listing J, et al. Frequency and duration of drugfree remission after 1 year of treatment with etanercept versus sulfasalazine in early axial spondyloarthritis: 2 year data of the ESTHER trial. Ann Rheum Dis. 2012 Jul;71(7):1212–5.  
69. Lunzer R. Is anti-TNF tapering possible in patients with axial spondyloarthritis? A systematic literature review: Kommentar. J fur Miner. 2016;23(1):26–7.  
70. Baraliakos X, Listing J, Brandt J, Zink A, Alten R, Burmester G, et al. Clinical response to discontinuation of antiTNF therapy in patients with ankylosing spondylitis after 3 years of continuous treatment with infliximab. Arthritis Res Ther. 2005;7(3):R439-44.  
71. Viegas Brenol C, Henrique da Mota LM, Afonso Cruz B, Salviato Pileggi G, Alves Pereira I, Stange Rezende L, et al. Consenso 2012 da Sociedade Brasileira de Reumatologia sobre vacinação em pacientes com artrite reumatoide. Rev Bras Reumatol. 2013 Jan;53(1):13–23.  
72. Poddubnyy D, Rudwaleit M, Haibel H, Listing J, Märker-Hermann E, Zeidler H, et al. Effect of non-steroidal antiinflammatory drugs on radiographic spinal progression in patients with axial spondyloarthritis: results from the German Spondyloarthritis Inception Cohort. Ann Rheum Dis. 2012 Oct;71(10):1616–22.  
73. Baji P, Péntek M, Szántó S, Géher P, Gulácsi L, Balogh O, et al. Comparative efficacy and safety of biosimilar infliximab and other biological treatments in ankylosing spondylitis: Systematic literature review and meta-analysis. Eur J Heal Econ. 2014;15(SUPPL. 1):S45–52.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Fórmulas para cálculo do escore ASDAS por proteína C reativa (PCR) e por velocidade de hemossedimentação (VHS) em calculadora específica:  
|**ASDAS –**|0,12 x Dor axial + 0,06 x Duração da rigidez matinal + 0,11 x Avaliação Global do Paciente + 0,07 x|
|---|---|
|**PCR**|Dor/Edema periféricos + 0,58 x Ln (PCR+1)|
|**ASDAS -**|0,08 x Dor axial + 0,07 x Duração da rigidez matinal + 0,11 x Avaliação Global do Paciente + 0,09 x|
|**VHS**|Dor/Edema periféricos + 0,29 x √(VHS)|  
√(VHS), raiz quadrada da velocidade de hemossedimentação (mm/h); Ln (PCR+1), logaritmo natural da proteína C reativa (mg/L)+1. Dor axial, avaliação global do paciente, duração da rigidez matinal e dor/edema periféricos são avaliados em escala analógica (de 0 a 10 cm) ou em uma escala numérica (de 0 a 10).  
Dor axial (questão 2 do BASDAI): "Como você descreveria o grau total de dor no pescoço, nas costas e no quadril relacionada à sua doença?"  
Duração da rigidez matinal (questão 6 do BASDAI): “Quanto tempo dura a rigidez matinal a partir do momento em que você acorda?"  
Avaliação do paciente: "Quão ativa esteve a sua espondilite em média na última semana*?”  
Dor/edema periférico (questão 3 do BASDAI): "Como você descreveria o grau total de dor e edema (inchaço) nas outras articulações sem contar com pescoço, costas, região lombar e quadril?"

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
|**Doença inativa**|< 1,3|
|---|---|
|**Atividade de doença moderada**|1,4 -2,0|
|**Atividade de doença alta**|2,1 – 3,5|
|**Atividade de doença muito alta**|>3,5|

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: Geral -->
Coloque uma marca em cada linha abaixo, indicando sua resposta para cada questão relacionada à semana passada.  
**1.** Como você descreveria o grau de fadiga ou cansaço que você tem tido?  
0 ___________________________________________________ 10 cm  
Nenhum Intenso  
**2.** Como você descreveria o grau total de dor no pescoço, nas costas e no quadril relacionada à sua doença?  
0 ___________________________________________________ 10 cm Nenhum Intenso **3.** Como você descreveria o grau total de dor e edema (inchaço) nas outras articulações sem contar com pescoço, costas e quadril? 0 ___________________________________________________ 10 cm  
**4.** Como você descreveria o grau total de desconforto que você teve ao toque ou à compressão em regiões do corpo doloridas?  
0 ___________________________________________________ 10 cm  
Nenhum Intenso  
**5.** Como você descreveria a intensidade da rigidez matinal que você tem tido a partir da hora em que você acorda? 0 ___________________________________________________ 10 cm Nenhum Intenso **6.** Quanto tempo dura a rigidez matinal a partir do momento em que você acorda? 0h_________ 30min _________ 1h _______ 1h 30min________ 2h  
**Cálculo do BASDAI (cm): [“1” + “2” + “3” + “4” + (média de “5” e “6”)]/5**  
<!-- Start of picture text -->
~~. ___---1_Lalinico + laborial+ imagem<br>fealizados em servigos especializados: Critério“Para pacientede incluso: com até 45,<br>enterm o Aeur pelo me n os ums dos<br>Sd Pose ciiirios a- ee ‘A)‘no minimlombalgia 3 mesesinfl a matoria , por,<br>de incluso? “Ss =. 8) sacroliteem exames de<br>a imageme, pelo menos, uma<br>ExclusdoPCOT do . Possucitériosde excluso"? " : eSpondioateracterisheafénos de Classiicacaode“conforme ASAS<br>fara ESpondioarnies Axa),<br>©) antigeno HLA-B27 e dois ou<br>ManitestacdoHore!entesite) penitéricapredomina(artite| eeniilamat6ria)oepredominant—— rae egacetsiasloarinte (conforme de<br>= trlenigspara Espondiloarintes de ClassiteagdoAxiais).ASAS|<br>Ss ‘ASDAS < 2,1 ~ Para paciente<br>[ Fue | oa ouBASDAN <4 mo 45apresentadodosanos entenos deverapeloA'Bsercom menosou maisCepelo um de<br>‘considerarmedicamentoso AINE€ [ane ] =Sineseslombalgia um bu= mats inflamatéria de durapao;a<br>B) limitae3o dos movimentos<br>dda coluna lombar nos planos<br>Sagial e frontal, ou<br>Faina 0 AINE em 5<br>* ee |<br>um més? ae ) radioaatia com detecs30de<br>‘Substhuir AINE em sacroilite5  bilateral‘com graus detece3o2-4; de0<br>Soaresoe<br>Faina a dois AINE em ‘Montorizarresposta,<br>ties meses? @ efetios adversos<br>sm doses aciequncias per o—>| adesio ao tratamento<br>MNICD biol6gico (adalimumabe,<br>etanercepte, infliximabe,<br>certolizumabe ou golimumabe)<br>Hipersensibilidade<br>Sm ‘apos 6 meses?ico<br>Substituir MMCD_ Monitorizar resposta,<br>biologico por outro ‘adesdo 20 tratamento<br>‘ou secuquinumabe ce eeradicea<br>* Gritérios de exclusio:<br>‘Fala:(Obs:HipersensibilidadeASDAS > 2,1ou contraindicago ou BASDA\ 4 e  absolutador na coluna (Quadro EVA (Escala3 - Monitoriza¢o dos Visual Anal6gica) principals> 4 efeitos adversos)<br>Em casode recdiva aposinterupcdode tratamento,retomaro tratamento segundoo PCDT.<br><!-- End of picture text -->  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
<!-- Start of picture text -->
‘ou entesite) predominarte<br>Infitragao intra-articular de<br>Jatcocorticoide* e medidas nao|<br>medicamentosas<br>‘adesio ao tratamento a ANE?<br>@ efeitos adversos,<br>Falha persistente com<br>‘a infltragao e com<br>sim \ adequadaporummes /<br>sm<br>|Substiuir AINE em uso| Monitorizarresposta,<br>‘Considerar sulfassalazina Falha persistente coma<br>caso(optarsulfassalazina) pormetotrexatoemde contraindicagaoa |... (/ adequadas_infltragdodiferentese portrés com em doisdos m es  AINEes? / Nao<br>eufacalazinaFalha persistente(ou 3 Meierroa<br>sly \ adequadametotrexato) por seis em dosemeses? sepeseyes bastard<br>(adalimumabe, etanercepte<br>infliximabe e certolizumabe)<br>Hipersensibiidade<br>‘ou falha** a0<br>‘sm MMCDands 6 bioléginoel -<br>ae] Monitorizar resposta,<br>MMCD biologico | ee@ efetos adversos,<br>Hipersensibilidade<br>oufaha"® 20<br>- MMCD biol6gico “e<br>eeitu Monitorizar<br>ou secuquinumabe ofeton aversce,<br>+ Falna: ASDAS > 2,1 ou BASDA\ 4 dor na coluna EVA (Escala Visual Anal6gica)> 4<br>(Obs. Em caso de recidva apés interup¢ao de tratamento, retomaro tratamento segundo o PCDT.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
IBUPROFENO, NAPROXENO, SULFASSALAZINA, METOTREXATO, ADALIMUMABE, ETANERCEPTE, GOLIMUMABE, INFLIXIMABE, CERTOLIZUMABE PEGOL E SECUQUINUMABE.  
Eu,______________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **ibuprofeno** , **naproxeno, sulfassalazina, metotrexato, adalimumabe, etanercepte, golimumabe, infliximabe, certolizumabe pegol e secuquinumabe** indicados para o tratamento da **espondilite ancilosante** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
____________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que os medicamentos que passo a receber podem trazer os seguintes benefícios:  
- melhora dos sintomas da doença, como dor e rigidez;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- sulfassalazina, adalimumabe, etanercepte, golimumabe e infliximabe: medicamentos classificados na gestação como fator de risco B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- efeitos adversos da sulfassalazina: dores de cabeça, reações alérgicas (dores nas juntas, febre, coceira, erupção cutânea), sensibilidade aumentada aos raios solares, dores abdominais, náusea, vômitos, perda de apetite, diarreia; efeitos adversos mais raros: diminuição do número dos glóbulos brancos no sangue, parada na produção de sangue pela medula óssea (anemia aplásica), anemia por destruição aumentada dos glóbulos vermelhos do sangue (anemia hemolítica), diminuição no número de plaquetas no sangue (aumentam os riscos de sangramento), piora nos sintomas da retocolite ulcerativa, problemas no figado, falta de ar associada a tosse e febre (pneumonite intersticial), dor nas juntas, dificuldade para engolir, cansaço associado à formação de bolhas e com perda de regiões da pele e de mucosas (síndrome de Stevens-Johnson e necrólise epidérmica tóxica) e desenvolvimento de sintomas semelhantes aos do lúpus eritematoso sistêmico (ou seja, bolhas na pele, dor no peito, mal-estar, erupções cutâneas, falta de ar e coceira);  
- ibuprofeno e naproxeno: medicamento classificado na gestação como categoria C quando utilizado no primeiro e segundo trimestres de gestação (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- ibuprofeno e naproxeno: medicamento classificado na gestação como categoria D quando utilizado no terceiro trimestre de gestação ou próximo ao parto (há evidências de riscos ao feto, mas um benefício potencial pode ser maior do que os riscos);  
- efeitos adversos do ibuprofeno: tontura, urticária na pele, reações de alergia, dor de estômago, náusea, má digestão, prisão de ventre, perda de apetite, vômitos, diarreia, gases, dor de cabeça, irritabilidade, zumbido, inchaço e retenção de líquidos.  
- efeitos adversos do naproxeno: dor abdominal, sede, constipação, diarreia, dispneia, náusea, estomatite, azia, sonolência, vertigens, enxaquecas, tontura, erupções cutâneas, prurido, sudorese, distúrbios auditivos e visuais, palpitações, edemas, dispepsia e púrpura;  
- metotrexato: medicamento classificado na gestação como fator de risco X (seu uso é contraindicado em gestantes ou em mulheres que planejam engravidar);  
- efeitos adversos do metotrexato: problemas gastrointestinais com ou sem sangramento, diminuição no número de glóbulos brancos no sangue, diminuição no número de plaquetas, aumento da sensibilidade da pele aos raios ultravioletas, feridas na boca, inflamação nas gengivas, inflamação na garganta, espinhas, perda do apetite, náusea, palidez, coceira e vômitos; efeitos adversos mais raros e dependentes da dose utilizada: cansaço associado à formação de bolhas e com perda de áreas da pele e de mucosas (síndrome de Stevens-Johnson e necrólise epidérmica tóxica) e problemas graves de pele. Também pode facilitar o estabelecimento ou agravar infecções;  
- efeitos adversos do adalimumabe, etanercepte, golimumabe, infliximabe, certolizumabe pegol e secuquinumabe: reações no local da aplicação (como dor e coceira), dor de cabeça, tosse, náusea, vômitos, febre, cansaço, alteração na pressão arterial até reações mais graves, que incluem infecções oportunísticas fúngicas e bacterianas como tuberculose, histoplasmose, aspergilose e nocardiose, podendo, em casos raros, ser fatal;  
- contraindicação em casos de hipersensibilidade (alergia) ao(s) fármaco(s) ou aos componentes da fórmula. Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. ( ) Sim ( ) Não  
Meu tratamento constará do seguinte medicamento:  
- ( ) Ibuprofeno (    ) Adalimumabe  
- ( ) Naproxeno (    ) Etanercepte  
- ( ) Sulfassalazina  
- (    ) Metotrexato  
- (    ) Golimumabe  
- (    ) Infliximabe  
- (    ) Certolizumabe Pegol  
- (    ) Secuquinumabe  
<!-- Start of picture text -->
Local: Data:<br>Cartdio Nacional do SUS:<br>Nome do responsavel legal:<br>Documento de identificacao do responsavel legal:<br>Assinatura do paciente ou do responsavel legal:<br>Médico: CRM: RS:<br>Assinatura  carimbo do médico<br>Data:<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da assistência farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
Depois da sua publicação, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Espondilite Ancilosante, pela necessidade de atualizar o item de Monitoramento da infecção por tuberculose ativa e rastreio da infecção por tuberculose latente (ILTB), de modo a harmonizar a orientação em todos os PCDT que preconizam o uso de medicamentos modificadores do curso da doença (MMCD) biológicos ou MMCD sintéticos-alvo específico.  
O tema foi apresentado como informe à 125ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 20 de maio de 2025, e também à 141ª Reunião Ordinária da Conitec, em junho de 2025.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
**1.1. Tecnologias disponíveis no Sistema Único de Saúde (SUS) para o tratamento da Espondilite Ancilosante (EA):** Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), sítio da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), Sistema de gerenciamento da tabela de procedimentos, medicamentos e órteses, próteses e materiais do SUS (SigTAP) e o Protocolo Clínico e Diretriz Terapêutica (PCDT) de EA vigente para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas.  
A partir das consultas realizadas foi possível identificar:  
- O tratamento no SUS segue o PCDT EA, conforme Portaria Conjunta N°7 de 17 de julho de 2017;  
- Os medicamentos atualmente disponíveis são: ibuprofeno, naproxeno, sulfassalazina, metilprednisolona, metotrexato, adalimumabe, etanercepte, infliximabe e golimumabe;  
- A inclusão do certolizumabe pegol e secuquinumabe no PCDT da EA, após recomendação da CONITEC e publicação das Portarias SCTIE Nº 54 e 65 de 19/12/2017 e 15/01/2018, respectivamente.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
- NICE guidelines (http://www.nice.org.uk/guidance/published?type=CG) = nenhuma diretriz localizada  
- National Guideline Clearinghouse – http://www.guideline.gov = 10 diretrizes localizadas,  
- recomendando uso do certolizumabe pegol e golimumabe, além dos medicamentos já disponíveis pelo PCDT vigente. - Guideline International Network – http://www.g-i-n.net/library/international-guidelines-library = nenhuma diretriz localizada  
- Sociedade Brasileira de Reumatologia - http://www.reumatologia.com.br/PDFs/RBR533PT.pdf - 1 diretriz localizada, recomendando uso do golimumabe, além dos medicamentos já disponíveis pelo PCDT vigente.  
- Diretrizes Associação Médica Brasileira (AMB) - <u>http://diretrizes.amb.org.br/tag/sociedade-brasileira-dereumatologia/- 1 diretriz localizada, recomendando uso do golimumabe, além dos medicamentos já disponíveis pelo</u> PCDT vigente.

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
Sendo assim, foi estabelecido que o Protocolo destina-se a pacientes com espondiloartropatias axial e periférica não psoriásicas, ambos os sexos e tem por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca do PCDT vigente (e incorporar as recomendações referentes ao uso do certolizumabe pegol e secuquinumabe, avaliados pela CONITEC).  
A fim de guiar a revisão do PCDT vigente foi realizada busca na literatura sobre intervenções terapêuticas baseadas em evidências definidas pelas seguintes perguntas PICO:

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
|POPULAÇÃO|Pacientes com espondilite ancilosante|
|---|---|
|INTERVENÇÃO|Tratamento clínico|
|COMPARAÇÃO|Sem restrição de comparadores|
|DESFECHOS|Segurança e eficácia|  
As seguintes estratégias de busca foram utilizadas:

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
|**BASE**|**ESTRATÉGIA**|**LOCALIZADOS**|**SELECIONADOS**|
|---|---|---|---|
|Medline (via<br>PubMed)<br>Data da<br>busca:<br>01/09/2016|("Spondylitis, Ankylosing"[Mesh]) AND<br>"Therapeutics"[Mesh] Filters: Meta-<br>Analysis, Systematic Reviews, From<br>2014/04/06, Humans, English, Portuguese,<br>Spanish|**11**|3<br>**Motivo das exclusões:**<br>8 artigos não avaliam<br>desfechos terapêuticos<br>na EA|
|Embase|'ankylosing spondylitis'/exp<br>AND 'therapy'/exp AND ([systematic<br>review]/lim OR [meta analysis]/lim)<br>AND<br>([english]/lim OR [portuguese]/lim OR<br>[spanish]/lim) AND [humans]/lim AND<br>[embase]/lim AND[6-4-2014]/sd|**59**|21<br>**Motivo das exclusões:**<br>17 artigos não avaliam<br>pacientes com EA; 21 a<br>artigos não avaliam<br>desfechos terapêuticos<br>na EA|
|Cochrane<br>Library|ankylosing spondylitis in Title, Abstract,<br>Keywords|**12**|**Motivo das exclusões:**<br>2 artigos fornecem<br>protocolo de estudos; 5<br>artigos não avaliaram<br>pacientes com EA|
|LILACS|tw:(espondilite anquilosante) AND<br>(instance:"regional") AND (<br>db:("LILACS") AND year_cluster:("2012"<br>OR "2013"))|**26**|2<br>**Motivo das exclusões:**<br>8 artigos não avaliaram<br>pacientes com EA; 2<br>artigos são relatos de<br>casos; 3 artigos são<br>revisões simples da<br>literatura; 11 artigos não<br>avaliam desfechos<br>terapêuticos na EA|

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
|**BASE**|**ESTRATÉGIA**|**LOCALIZADOS**|**SELECIONADOS**|
|---|---|---|---|
|**Medline (via**<br>**PubMed)**<br>**Data da**<br>**busca:**<br>**01/09/2016**|**("Spondylitis, Ankylosing"[Mesh])**<br>**AND**<br>**"Therapeutics"[Mesh] Filters:**<br>**Randomized**<br>**Controlled Trial, From 2014/04/06,**<br>**Humans, English,**<br>**Portuguese, Spanish**|**13**|**8**<br>**Motivo das exclusões:**<br>**2 artigos com desfecho**<br>**cardiovascular substituto;  1**<br>**artigo na população chinesa**<br>**apenas; 2 artigos não avaliaram**<br>**desfechos clínicos da EA**|
|**Embase**|**'ankylosing spondylitis'/exp AND**<br>**'therapy'/exp AND**<br>**[randomized controlled trial]/lim AND**<br>**([english]/lim**<br>**OR [portuguese]/lim OR**<br>**[spanish]/lim) AND**<br>**[humans]/lim AND [embase]/lim AND**<br>**[5-4-2014]/sd**|**50**|**23**<br>**Motivo das exclusões:**<br>**15 artigos não avaliam pacientes**<br>**com EA; 12 artigos**<br>**não avaliam desfechos**<br>**terapêuticos na EA**|  
A fim de guiar a revisão do PCDT vigente foram realizadas buscas na literatura sobre diagnóstico e dados nacionais sobre a doença:

---

<!-- METADADOS: doenca: Espondilite Ancilosante | secao: FLUXOGRAMA DE TRATAMENTO ESPONDILITE ANCILOSANTE MANIFESTAGAO PERIFERICA -->
|**BASE**<br>**ESTRATÉGIA**<br>**LOCALIZADOS**|**SELECIONADOS**|
|---|---|  
|Medline (via<br>PubMed)<br>Data da busca:<br>02/09/2016|"Spondylitis, Ankylosing/diagnosis"[Mesh]<br>Filters:<br>Practice Guideline, Government<br>Publications,<br>Guideline, Consensus Development<br>Conference, NIH, Consensus Development<br>Conference, Systematic Reviews, From<br>2014/04/06, Humans, English, Portuguese,<br>Spanish|11|1<br>**Motivo das exclusões:**<br>4 artigos não avaliam<br>pacientes com EA; 6<br>artigos não avaliam desfechos<br>diagnósticos na EA|
|---|---|---|---|
|National<br>Guideline<br>Clearinghous|“Ankylosing Spondylitis” – 2014-2016<br>https://www.guideline.gov/search?q=Ankylo<br>sing+Spondylitis&f_dateRangeFrom=2015<br>&f_dateRangeTo=2016|3|2<br>**Motivo das exclusões:**<br>1 artigo não avaliou<br>pacientes com EA|
|**Busca por dados**<br>**BASE**|**nacionais**<br>**ESTRATÉGIA**<br>**LOC**|**ALIZADOS**|**SELECIONADOS**|
|Medline (via<br>PubMed)|"Spondylitis, Ankylosing"[Mesh] AND<br>brazil Filters:<br>From 2014/04/06, Humans|11|2<br>**Motivo das**<br>**exclusões:**4 artigos não avaliam<br>pacientes com EA; 5 artigos<br>não avaliam desfechos<br>diagnósticos na EA|  
Foram encontradas 196 referências, 65 foram selecionadas conforme critérios descritos acima, sendo 20 repetidas nas bases de dados, totalizando 45 referências incluídas. Da busca por ECR, 12 estudos foram selecionados, mas não referenciados, pois estavam incluídos nas meta-análises e revisões sistemáticas selecionadas ( **Tabela 1** ).  
Foram também utilizados como referência a base de dados _UpToDate_ , versão 24.5 (4 referências), 2 livros texto e 12 referências de conhecimento dos autores. Da versão anterior do PCDT, 28 referências foram mantidas e as demais excluídas ou atualizadas.  
**Tabela 1 -** Revisões sistemáticas/meta-análises de biológicos com desfechos clínicos e estruturais de espondilite ancilosante ou espondiloartrite axial.  
|**ESTUDO/**<br>**DENOMIAÇÃO**<br>**DE DOENÇA **|**NÚMERO DE**<br>**ESTUDOS OU**<br>**INDIVÍDUOS**|**INTERVENÇÃO**|**COMPARADOR**|**RESULTADOS**|
|---|---|---|---|---|
|Baji P, et al.<br>2014<sup>77</sup>;<br>espondilite<br>anquilosante|13 estudos;<br>2.575 indivíduos|Anti-TNF<br>(adalimumabe,<br>etanercepte,<br>golimumabe,<br>Infliximabe)|Placebo*|ASAS20 na semana 12, OR<br>4,35-6,74 (_P_<0,05) e na<br>semana 24, OR 4,53-7,20<br>(_P_<0,05); evento adverso<br>grave, OR 0,69-2,71 (_P_>0,05)|
|Lin S, et al.<br>2014<sup>35</sup>;<br>espondilite<br>anquilosante|3 estudos; 187<br>indivíduos|Anti-TNF<br>(infliximabe) +<br>metotrexato|Anti-TNF<br>(infliximabe)<sup>§</sup>|ASAS20 RR 1,16 (0,88-1,52) e<br>ASAS40 RR 1,37 (0,84-2,23)<br>em mais de 18 semanas;<br>interrupção por efeitos<br>colaterais RR 1,89 (0,71-5,02)|
|Migliore A, et al.<br>2014<sup>41</sup>;<br>espondilite<br>anquilosante|6 estudos|Anti-TNF<br>(adalimumabe,<br>certolizumabe pegol,<br>etanercepte,<br>golimumabe e<br>infliximabe)|Placebo|<br>ASAS20 dos anti-TNF foi<br>superior ao placebo em 12<br>semanas (_P_<0,05); infliximabe<br>apresenta 67,6% de<br>probabilidade de ser o melhor<br>anti-TNF; não houve diferença<br>nas comparações indiretas<br>entre anti-TNF.|
|Benedict A, et al.<br>2015<sup>64</sup>;<br>espondiloartrite<br>axial não<br>radiográfica|4 estudos|Etanercepte (2<br>estudos)|Adalimumabe (1<br>estudo) e<br>certolizumabe pegol<br>(1 estudo)|<br>Variações de BASDAI e<br>BASFI foram semelhantes<br>entre os grupos em 12 semanas|
|Migliore A, et al.<br>2015<sup>40</sup>;<br>espondilite<br>anquilosante|5 estudos; 1.112<br>indivíduos|Anti-TNF<br>subcutâneos<br>(adalimumabe,<br>certolizumabe<br>pegol, etanercepte e<br>golimumabe)|Placebo|ASAS20 de todos os anti-TNF<br>subcutâneos foi superior ao<br>placebo em 12 semanas;<br>golimumabe apresenta maior<br>probabilidade (41,3%) de<br>ASAS20 em 12 semanas;<br>nenhum anti-TNF foi superior<br>aos demais comparados dois a<br>dois|
|Lunzer R. 2016<sup>71</sup>;<br>espondiloartrite<br>axial|8 estudos<br>(espondilite<br>anquilosante):<br>6 observacionais<br>e 2 de<br>intervenção|Anti-TNF<br>(adalimumabe,<br>etanercepte,<br>infliximabe)|Não se aplica:<br>revisão<br>sistemática<br>qualitativa (sem<br>meta-análise)|BASDAI<4 após redução do<br>anti-TNF: 53-100%;<br>espaçamento foi mais comum<br>do que redução da dose<br>administrada.|
|Zhang J, et al<sup>59</sup>;<br>espondilite<br>anquilosante|15 estudos<br>(ensaios clínicos<br>e<br>estudos de<br>coorte); 461<br>indivíduos|Anti-TNF<br>(adalimumabe,<br>etanercepte,<br>golimumabe 50mg e<br>100mg, infliximabe)|Não se aplica:<br>revisão<br>sistemática<br>qualitativa (sem<br>meta-análise).|Lesão inflamatória inicial<br>esteve sssociada a novo<br>sindesmófito (OR 1,9-4,6,<br>_P_<0,05); 4 estudos com 2 anos<br>de seguimento demonstraram<br>efeito nulo dos anti-TNFs<br>(adalimumabe, etanercepte e<br>infliximabe) na progressão<br>radiográfica (quando<br>comparados a coortes<br>históricas com doença menos<br>ativa - OASIS e<br>GESPIC)(52,76); 3 estudos<br>com>4 anos de seguimento<br>demonstraram efeito inibitório<br>dos anti-TNFs (não<br>especificados) na neoformação<br>óssea.|  
TNF: fator de necrose tumoral ( _tumor necrosis factor_ ); ASAS: avaliação da espondiloartrite ( _assessment of spondyloarthritis_ ); OR: _odds ratio_ ; RR: risco relativo; BASDAI: índice de atividade de espondilite anquilosante de Bath ( _Bath ankylosing spondylitis activity index_ ); BASFI: índice funcional de espondilite anquilosante de Bath ( _Bath_  
_ankylosing spondylitis functional index_ ); OASIS: estudo internacional de desfecho em epondilite anquilosante ( _outcome in ankylosing spondylitis international study_ ); GESPIC: coorte inicial alemã em espondiloartrite ( _german spondyloarthritis inception cohort_ ). *Em dois estudos, além de placebo, um terceiro grupo recebeu o mesmo anti-TNF com posologia diferente (etanercepte 25mg, 2x/semana, 50mg, 1x/semana, placebo; golimumabe 50mg/4 semanas, 100mg/4 semanas, placebo).<sup>§</sup> Em apenas um estudo, houve placebo em substituição ao metotrexato.

---

