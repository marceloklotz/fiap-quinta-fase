<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: Geral -->
<!-- Start of picture text -->
Was<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO A SAÚDE  
PORTARIA CONJUNTA Nº 5, DE 22 DE JUNHO DE 2017  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas – Imunossupressão no Transplante Hepático em Adultos.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA E TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a imunossupressão póstransplante hepático em adultos no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos sob imunossupressão;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 217/2016 e o Relatório de Recomendação nº 236 - Agosto/2016, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC); e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º  Fica aprovado, na forma do Anexo, disponível no sítio: www.saude.gov.br/sas, o Protocolo Clínico e Diretrizes Terapêuticas - Imunossupressão no Transplante Hepático em Adultos.  
Parágrafo único. O Protocolo,P objeto deste artigo, que contém o conceito geral da imunossupressão no transplante hepático em adultos, critérios de diagnóstico da rejeição, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro, ressarcimento de procedimentos e dispensação de medicamentos nele previstos.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para a imunossupressão no transplante hepático em adultos.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos adultos submetidos a transplante hepático em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
FRANCISCO DE ASSIS FIGUEIREDO  
MARCO ANTÔNIO DE ARAÚJO FIREMAN

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 1. INTRODUÇÃO -->
O transplante hepático é o único tratamento definitivo para pacientes com doença hepática cujo tratamento medicamentoso não é eficiente. O transplante de fígado é indicado para o tratamento da insuficiência hepática aguda, da insuficiência hepática crônica, da cirrose hepática, de distúrbios metabólicos que possam ser corrigidos com o transplante hepático<sup>[1]</sup> e de carcinoma hepatocelular (CHC)<sup>[2]</sup> .  
De acordo com a Associação Brasileira de Transplante de Órgãos (ABTO), o transplante hepático apresenta um crescimento anual desde 2008 e, em 2014, teve um aumento de 1,9%, sendo 1,1% com doador falecido e de 10,3% com doador vivo, totalizando 1.755 transplantes, 1.605 com doadores falecidos e 150 com doadores vivos. E, conforme dados do Sistema Nacional de Transplantes (SIG/SNT, em 06/03/2017), foram registrados em 2015, em todo o Brasil, 1.816 transplantes de fígado (146 com doadores vivos e 1.670 com doadores falecidos), e, em 2016, 1.880 (157 com doadores vivos e 1.723 com doadores falecidos) foram registrados, observando-se um aumento de 3,5%.  
A sobrevida dos receptores de transplante hepático é 69% em 5 anos<sup>[3]</sup> e tem melhorado devido ao aprimoramento de técnicas cirúrgicas e da logística de captação e alocação dos órgãos ofertados e surgimento de novos imunossupressores.  
O desenvolvimento de novos agentes imunossupressores e mudanças dos esquemas póstransplante são os principais motivos para o aumento do número de transplantes bem sucedidos. Entretanto, enquanto a terapia de imunossupressão diminui os episódios de rejeição nos pacientes transplantados de fígado, também aumenta as chances dos pacientes apresentarem infecções e efeitos adversos específicos devido ao uso contínuo desses agentes, por isso, o acompanhamento terapêutico constante dos pacientes é de extrema importância.  
Anterior ao advento da ciclosporina (CsA), o primeiro imunossupressor inibidor da calcineurina (ICN), a taxa de rejeição aguda de 5 a 7 dias pós-transplante de fígado era aproximadamente de 80%<sup>[4]</sup> .  
Os medicamentos imunossupressores inibem ou reduzem a resposta do sistema imunitário aos aloantígenos do enxerto. O tratamento imunossupressor tem por objetivo prevenir ou reverter a rejeição do enxerto, alterando o menos possível a imunidade não relacionada ao tratamento. É de fundamental importância buscar o equilíbrio entre máxima efetividade em evitar a rejeição com mínima supressão do sistema imune, permitindo, assim, o controle contra infecções e neoplasias e evitando também a toxicidade direta dos agentes imunossupressores (nefrotoxicidade, hipertensão arterial, diabete mélito (DM), dislipidemia e osteoporose).  
O tacrolimo (TAC) pertence também à classe de ICN. O TAC foi introduzido como agente imunossupressor no início da década de 1990, dez  anos depois da CsA e foi inicialmente desenvolvido para o transplante de fígado<sup>[5]</sup> . A eficácia do TAC por via oral é maior do que a da CsA, o que tornou o TAC o ICN mais utilizado nos protocolos de imunossupressão, geralmente em combinação com corticoide<sup>[6]</sup> . Acompanhando a evolução desses protocolos de imunossupressão, a razão da rejeição aguda caiu progressivamente e atualmente a maioria dos casos de rejeição aguda é controlada com aumento da dose de TAC ou administração de bolus de corticosteroide<sup>[7]</sup> .  
Como o carcinoma hepatocelular (CHC) é uma das principais indicações para o transplante de fígado<sup>[8]</sup> , o efeito antiproliferativo de alguns agentes imunossupressores nestes casos é também esperado.  
O risco de recidiva de CHC pós-transplante é estimada em mais de 20% dos casos e ocorre mais frequentemente nos dois primeiros anos<sup>[9]</sup> .  
Novos agentes imunossupressores de classes diferentes foram desenvolvidos depois dos inibidores de calcineurina, como: inibidores de receptor da rapamicina (mammalian target of rapamycin) - mTORs, agentes antimetabólicos e os imunoglobulinas anti-linfócitos T. Existem diversos protocolos de imunossupressão utilizados pelos centros transplantadores mundiais, e a maioria deles faz a associação de um inibidor de calcineurina com corticoide e com um agente antimetabólico ou inibidores da proteína mTOR como terapia de imunossupressão de manutenção<sup>[10]</sup> .  
Mas vale salientar que a identificação e o controle dos fatores de risco das doenças que levam à insuficiência hepática e do seu diagnóstico em estágio inicial, bem como o encaminhamento ágil e adequado para o atendimento especializado, dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos, inclusive quanto aos transplantados.  
2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
Z94.4 - Fígado transplantado; T86.4 - Falência ou rejeição de transplante de fígado.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 3. DIAGNÓSTICO DE REJEIÇÃO -->
A rejeição é definida clinicamente pela piora aguda da função do enxerto, e seu diagnóstico se dá pelas alterações histológicas observadas. No exame da amostra da biópsia do enxerto e por observações na alteração das enzimas hepáticas.  
A rejeição hiperaguda é um tipo de rejeição humoral que se desenvolve em um paciente no qual já existem anticorpos antidoador. Um exemplo é o que pode ocorrer em casos de enxertos ABO incompatíveis<sup>[11]</sup> no momento da reperfusão, levando a uma lesão grave imediata e, consequentemente, falência do enxerto dentro de 24 horas<sup>[12].</sup>  
A rejeição aguda mediada por linfócitos T é a mais comum, ocorrendo frequentemente nos primeiros 6 meses após o transplante. No entanto, pode se manifestar depois desses dos meses do transplante e até anos mais tarde, em geral quando há mudanças na imunossupressão.  
A rejeição do enxerto envolve uma grande variedade de células: leucócitos T citotóxicos (CD8+), células T auxiliares (CD4+), macrófagos e plasmócitos. Na maioria dos episódios de rejeição, as células T são as principais envolvidas. Forma-se uma cascata de eventos que culmina na expansão do clone de células efetoras e de anticorpos que causam a destruição dos enxertos se a reação não for controlada adequadamente pelos imunossupressores.  
O processo completo que conduz à ativação do linfócito T requer sinais externos em receptores localizados na membrana das células. Ao iniciar a resposta imune, os antígenos presentes no enxerto são captados e processados pelas células que apresentam os antígenos aos receptores das células T.  
Considera-se como primeiro sinal o reconhecimento das moléculas HLA pelo receptor da célula T. Há, então, a ativação de uma série de proteínas que, por sua vez, ativam vias bioquímicas efetoras. O segundo sinal, importante para a ativação celular completa da célula T, é reconhecido pela coestimulação de moléculas com seus “encaixes”/receptores. A coordenação dos sinais intracelulares que ocorrem após a exposição aos antígenos e a união com as moléculas coestimuladoras ainda não está completamente elucidada. Sabe-se que é necessária a ativação produzida por proteínas regulatórias (as citocinas) do tipo intereleucina 2 (IL-2).  
Os linfócitos T são estimulados pela IL-1 e por sinais coestimuladores a produzir IL-2. Sob influência da IL-2, as células T CD4+e CD8+ expandem-se clonalmente e se diferenciam em células efetoras, as quais induzem a resposta enxerto contra o hospedeiro<sup>[13].</sup>  
A interação da IL-2 com seu receptor estimula tanto a divisão celular (a célula T passará da fase G0 do ciclo celular para a fase ativada G1) levando à expansão de clones das células auxiliares e citotóxicas. O terceiro sinal ocorre quando as citocinas são encaixadas nos seus receptores e passam a emitir os sinais de transdução/ativação para o núcleo das células. Estes sinais ativam sistemas enzimáticos importantes ao se encaixarem nos receptores da rapamicina, mTOR (mammalian target of rapamycin).  
O conhecimento da cascata de ativação, com a destruição celular cíclica que ela determina, e do sítio de ação dos medicamentos imunossupressores é fundamental para a correta terapia da rejeição.  
Em qualquer período após o transplante, o diagnóstico de rejeição é estabelecido pela análise histológica do fígado. O exame do material de biópsia hepática é o que define o diagnóstico e permite graduar sua intensidade. Suas bases foram estabelecidas em reuniões de consenso conhecidas como Critérios de Banff.<sup>[12]</sup> O índice Banff de atividade/intensidade da rejeição divide o processo em três graus (leve, moderado e grave). Nos casos de rejeição leve, observa-se discreto infiltrado inflamatório com alterações limitadas a poucos espaços-porta; nos casos de rejeição moderada, as alterações se estendem para a maioria dos espaços-porta; e, nos casos de rejeição grave, observam-se também inflamação perivenular que se estende ao parênquima e necrose de hepatócitos.  
A rejeição aguda mediada por anticorpos é de difícil diagnóstico em transplante hepático; clinicamente as apresentações podem ser ambíguas e difíceis de discernir de outras possíveis razões para a disfunção do enxerto<sup>[12]</sup> . De acordo com a classificação internacional de Banff, a rejeição aguda mediada por anticorpos caracteriza-se pela imuno-histoquímica com alterações histológicas sugestivas no tecido e pela presença de C4d e anticorpos específicos anti-HLA (Donor Specific Antibodies).<sup>[14]</sup> O fígado é reconhecido por ser relativamente resistente a rejeição mediada por anticorpos já que somente em 38% dos casos ocorre rejeição mediada por anticorpos quando um enxerto ABO incompatível é utilizado<sup>[15]</sup> .  
A rejeição crônica de enxertos, também conhecida como ductopênica, é caracterizada pela perda progressiva dos ductos biliares e por vasculopatia obliterativa, normalmente resultado de episódios de rejeições agudas recorrentes. É a principal causa de perda de enxerto pós-transplante de fígado bem sucedido e maior indicação para retransplante hepático.<sup>[16]</sup> 4. CRITÉRIOS DE INCLUSÃO  
Serão incluídos neste Protocolo de imunossupressão todos os pacientes maiores de 18 anos submetidos a transplante de fígado, conforme o Regulamento Técnico vigente do Sistema Nacional de Transplantes, tanto para o estabelecimento do estado de imunossupressão quanto para o tratamento de indução ou de manutenção.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 5. CRITÉRIOS DE EXCLUSÃO -->
Casos de transplante hepático auxiliar quando é suspensa a imunossupressão, bem como os pacientes com intolerância, hipersensibilidade ou contraindicação aos medicamentos propostos.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6. TRATAMENTO -->
Os agentes imunossupressores inibem ou diminuem a resposta do sistema imunológico aos aloantígenos do enxerto. Os diversos medicamentos e agentes biológicos utilizados na imunossupressão do paciente transplantado de fígado se classificam em grupos, de acordo com seus sítios de atuação na cascata  
das células T: 1) os que atuam em vários níveis da cascata (corticosteroides  prednisona, prednisolona e metilprednisolona); 2) os que inibem a síntese de IL-2 (inibidores da calcineurina  CsA e TAC); 3) os que interferem na síntese de ácidos nucleicos (inibidores da síntese de purinas  azatioprina (AZA) e micofenolato); e 4) os que inibem o sinal de proliferação de crescimentos das células musculares lisas e linhagens hematopoiéticas - inibidores mammalian target of rapamycin – mTOR (everolimo – EVR).<sup>[7,17]</sup>  
Além das evidências científicas, a escolha do esquema imunossupressor a ser utilizado também deve levar em consideração os aspectos clínicos específicos do receptor (comorbidades, doença hepática que levou ao transplante, idade e condições associadas). A maioria dos esquemas combina agentes com diferentes sítios de ação na cascata da resposta imunológica, permitindo ajuste nas doses e reduzindo, assim, efeitos adversos e toxicidade dos medicamentos. Como há efeito sinérgico entre alguns dos agentes, é possível utilizar, em distintas combinações, medicamentos que atuem em diferentes fases do ciclo celular, com a intenção de atingir um nível adequado de imunossupressão com menos efeitos adversos.  
A expressão “terapia de indução ou inicial” refere-se ao tratamento imunossupressor utilizado no período transoperatório e durante os três primeiros meses pós-transplante, período em que o risco de rejeição do enxerto é maior. Já terapia de manutenção refere-se ao esquema imunossupressor utilizado posteriormente a este período. Atualmente, na grande maioria dos casos, são utilizados esquemas imunossupressores, tendo como base os inibidores da calcineurina. 6.1. Fármacos  
Formas farmacêuticas  
- Azatioprina: comprimido de 50 mg;  
- Basiliximabe: frasco-ampola de 20 mg;  
- Ciclosporina: cápsulas de 10mg, 25mg, 50mg e 100 mg; solução oral de 100 mg/mL (frascos de 50 mL);  
- Everolimo: comprimidos de 0,5mg, 0,75 mg e 1 mg;  
- Imunoglobulina antitimócito: frasco ampola de 25 mg injetável;  
- Metilprednisolona: solução injetável de 500 mg;  
- Micofenolato de mofetila: comprimido de 500 mg;  
- Micofenolato de sódio: comprimidos de 180 mg e 360 mg;  
- Prednisona: comprimidos de 5 mg e 20 mg;  
- Prednisolona: solução oral de 3 mg/mL; e  
- Tacrolimo: cápsulas de 0,5mg, 1mg e 5mg.  
- 6.1.1 Inibidores de calcineurina (INCs)  
São os principais medicamentos utilizados na terapia de manutenção do transplante hepático; incluem a CsA e o TAC.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: Ciclosporina -->
A ciclosporina (CsA) é um potente agente imunossupressor utilizada em transplantes de órgãos sólidos desde a década de 1970, sendo seu uso consolidado na década de 1980. A ação imunossupressora depende da formação de um complexo com seu receptor citoplasmático, a ciclofilina que se liga e inibe a atividade da fosfatase da calcineurina, resultando na inibição da expressão de genes de proteínas nucleares envolvidas na ativação celular e formação do linfócito T citotóxico. Estas proteínas nucleares são a região promotora de genes interleucina-2 (IL2), interleucina-4 (IL4) e interferona-gama.<sup>[17]</sup>  
A CsA é absorvida no jejuno e é amplamente distribuída pelo sangue, com pico de concentração no plasma cerca de 3,5 horas após sua administração. No sangue, concentra-se nos eritrócitos (41%-58%), no plasma (33%-47%), nos leucócitos (5%-12%) e nos linfócitos (4%-9%). No plasma, em  
aproximadamente 90% está ligada a proteínas, principalmente lipoproteínas, tendo uma meia-vida de cerca de 18 horas. A eliminação é predominantemente biliar; em apenas 6% é excretada pela urina. Tacrolimo  
O tacrolimo (TAC - FK 506) possui o mecanismo de ação similar ao da CsA apesar da diferença na estrutura molecular, e seu efeito in vitro é de 10 a 100 vezes maior que o da CSA. O nível sérico terapêutico equivalente do TAC é aproximadamente 20 vezes menor que o nível sérico da CsA.<sup>[18]</sup> Inibe a atividade da calcineurina após se ligar a uma diferente imunofilina, a fk-binding protein isoenzyme 120 (FKBP-12), interferindo nessa via de transdução no sinal de imunoativação das células T.<sup>[19]</sup>  
Sua biodisponibilidade oral é variável (5%-67%), sendo que a melhor absorção ocorre em condições de jejum. Alimentos ricos em gordura ou carboidratos diminuem significativamente a absorção deste fármaco. Cerca de 99% dele ligam-se a proteínas, principalmente albumina e ácido glicoproteína alfa1, tendo uma meia-vida entre 31,9 e 48,1 horas. Menos de 1% é excretado inalterado pela urina.  
Alguns medicamentos aumentam os níveis sanguíneos dos inibidores de calcineurina, tais como macrolídeos (claritromicina, eritromicina, azitromicina), antifúngicos (fluconazol, itraconazol, cetoconazol, voriconazol, clotrimazol), bloqueadores do canal de cálcio (verapamil, diltiazem, nifedipino), e outros (cisaprida, metoclopramida, amiodarona, cimetidina, inibidores de protease). Outros medicamentos reduzem os níveis sanguíneos dos inibidores de calcineurina, tais como antibióticos (rifambutina, rifampicina) e anticonvulsivantes (carbamazepina, fenobarbital, fenitoína).  
Os inibidores da calcineurina possuem uma série de efeitos tóxicos, muitos deles dependentes de dose. A nefrotoxicidade é um relevante efeito adverso destes agentes, tendo sido documentada insuficiência renal crônica em cerca de 20% dos transplantados de fígado em 5 anos. Nestes casos, pode se reduzir doses ou até mesmo necessitar suspender o medicamento.  
Neurotoxicidade é outra complicação frequente, podendo variar desde cefaleia e tremores até agitação, confusão, alucinações ou psicose. Hipertensão arterial, dislipidemia, hiperpotassemia, acidose metabólica e DM também são efeitos adversos bastante comuns. Diabete mélito é mais frequente com TAC, enquanto hipertensão e dislipidemia são mais comuns com CsA. Há também a possibilidade de a CsA causar hiperpotassemia.  
Outro relevante aspecto que deve ser ressaltado com relação aos inibidores da calcineurina é sua interação com o fator-beta transformador de crescimento (TGF-beta), uma citocina que estimula o desenvolvimento de fibrose e de crescimento tumoral. A transcrição do TGF-beta é aumentada com o uso de inibidores da calcineurina, tornando maior a possibilidade de recorrência de carcinoma hepatocelular e o surgimento de doença linfoproliferativa pós-transplante.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: Everolimo -->
O everolimo (EVR), inibidor da enzima mTOR (mammalian target of rapamicin), embora amplamente usado no transplante renal, só recentemente recebeu a aprovação do FDA (Food and Drug Administration dos EUA), da European Medicines Agency (da Europa) e da ANVISA para a profilaxia da rejeição no transplante hepático.  
O EVR é um derivado hidroxietil do sirolimo, com mecanismo de ação via inibição do m- TOR, com efeitos antiproliferativos e imunossupressores. Como inibidor do alvo da rapamicina (target rapamycin), a mTOR, o EVR bloqueia a transdução do sinal associado a fatores de crescimento celular. A atividade imunossupressora está parcialmente relacionada com o bloqueio da indução da proliferação de células T e B via inibição de mTOR e, consequentemente, da quinase p70S6 que regula o crescimento  
celular por meio da ligação à proteína FK506<sup>[20]</sup> . Esse mecanismo resulta na interrupção do ciclo celular entre as fases G0 e G1<sup>[21]</sup> . Uma vez que os inibidores de mTOR atuam depois do receptor de interleucina2 na cadeia de sinais, os inibidores da mTOR não inibem a produção de interleucina que advém da ativação do linfócito T induzida pelo antígeno, como o fazem os inibidores de calcineurina. Além disto, os inibidores de mTOR agem de maneira sinérgica com os inibidores de calcineurina, levando à hipótese de que uma dose reduzida de inibidor de calcineurina pode ser utilizada para se obter um efeito imunossupressor semelhante. Enquanto os ICNs atuam em uma fase mais precoce da ativação celular, o EVR age numa fase tardia; essa ação complementar possibilita um sinergismo farmacológico<sup>[22]</sup> . Desta maneira, o EVR permite a redução da dose do ICN, portanto da nefrotoxicidade decorrente deste, sem a perda da eficácia para prevenir a rejeição aguda ao enxerto, possibilitando a preservação da função renal do paciente transplantado.  
Além disso, os inibidores de mTOR reduzem a expressão do receptor do fator de crescimento epitelial (EGFR) e da sua via de sinalização, bem como inibem a produção do fator de crescimento do endotélio vascular (VEGF)[23], o que confere a esses agentes propriedades antineoplásicas.  
O EVR é rapidamente absorvido por via oral, atingindo um pico de concentração entre 1-2 horas, podendo ter retardada sua absorção por refeições com elevada quantidade de gorduras. Sua eliminação ocorre em cerca de 80% na bile e 5% na urina, e seu clearence é cerca de 20% maior em pacientes negros. A meia-vida do EVR é de aproximadamente 30-40 horas, tendo um tempo de estabilização sanguínea de 4 dias. O EVR é metabolizado no fígado pelo sistema microssomal citocromo P450-3A4. Fármacos que inibem ou competem na atividade do sistema citocromo P450 podem reduzir significativamente a depuração do EVR, ocasionando aumento significativo dos níveis sanguíneos desse fármaco. Como exemplo de medicamentos de uso frequente na clínica diária que podem elevar os níveis sanguíneos dos mTOR pode-se citar o fluconazol, azitromicina e os inibidores de protease.  
Os efeitos adversos do uso de EVR são dependentes de dose. Estes incluem dislipidemia, trombocitopenia, anemia e leucopenia. Não ocasionam neurotoxicidade, nefrotoxicidade ou diabete. O efeito colateral mais comum é dislipidemia (hipercolesterolemia ou hipertrigliceridemia), afetando 23%31% dos pacientes.  Este efeito parece ser menos frequente com o uso concomitante de TAC em relação à CsA e pode ser controlado com o uso de estatinas. Distúrbios hematológicos como trombocitopenia e leucopenia podem ocorrer. Outros efeitos adversos atribuídos a este fármaco incluem retardo na cicatrização da ferida operatória, hérnias incisionais, úlceras orais, rash cutâneo, proteinúria, edema de membros inferiores, dores articulares, diarreia, náusea, infecções do trato urinário e pneumonia.  
Por outro lado, quatro estudos clínicos sugerem que a imunossupressão com inibidores de mTOR pode reduzir a recidiva do CHC pós-transplante<sup>[24-27]</sup> , porém em outro estudo clínico randomizado duplo-cego de fase III (EVOLVE I) não foi observada a melhora da sobrevida dos pacientes com CHC avançado que fizeram uso de EVR<sup>[28]</sup> .  
Apesar de vários centros transplantadores já estarem utilizando em seus protocolos de imunossupressão os inibidores de mTOR em receptores com CHC<sup>[10]</sup> , ainda faltam resultados conclusivos de mais estudos clínicos prospectivos controlados e randomizados para a comprovação de efetividade neste subgrupo de pacientes.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.1.3 Corticosteroides -->
Os corticosteroides possuem uma variedade de efeitos anti-inflamatórios e imunomoduladores e ligam-se aos receptores de glucocorticoides, e esse complexo influencia na transcrição gênica e produção de citocinas pró-inflamatórias, resultando em uma diminuição da resposta inflamatória pela redução da produção de citocinas como IL-1, IL-2, IL-6, IFN-gama e TNF-alfa<sup>[17]</sup> .  
Os corticosteroides são considerados um componente relevante na maioria dos esquemas de imunossupressão comumente administrados no período intraoperatório como terapia de indução. Para o tratamento de rejeição aguda do enxerto, são administrados em altas doses emvbolus. Os corticosteroides mais utilizados são metilprednisolona, prednisolona e prednisona<sup>[4]</sup> .  
Os corticosteroides apresentam uma série de efeitos secundários indesejáveis, tais como hipertensão arterial, retenção de sódio e líquidos, DM, dislipidemia, retardo do crescimento, osteoporose, acne, alterações comportamentais (instabilidade do humor, quadros psicóticos), catarata ou glaucoma. Isto faz com que a maioria dos esquemas imunossupressores que os utilizam no transplante hepático sejam limitados aos primeiros meses pós-transplante. 6.1.4. Agentes antimetabólicos Azatioprina  
A azatioprina (AZA) foi descoberta na década de 1950 e incorporada nos esquemas de imunossupressão na década de 1960, sendo, atualmente, um dos agentes imunossupressores mais antigos utilizado no esquema de imunossupressão de transplantes<sup>[29]</sup> . A AZA é um derivado imidazol da 6- mercaptopurina, um análogo da purina, e ao ser incorporado na replicação do DNA, bloqueia a rota sintética de purinas. Isso afeta diretamente no ciclo de celular dos linfócitos por não possuírem uma via de salvamento de purinas<sup>[30]</sup> .  
É bem absorvida pelo trato gastrointestinal após a administração oral. Tem uma meia-vida reduzida (cerca de 3 horas), mas seus metabólitos permanecem ativos por longo tempo, permitindo que o medicamento seja administrado a cada 12-24 horas. Entre os principais fármacos que interagem com a AZA, incluem-se alopurinol (que, inibindo a xantina oxidase, aumenta o risco de mielotoxicidade) e os inibidores da enzima conversora de angiotensina (ECA).  
A mielossupressão, dependente da dose, permanece o efeito tóxico mais grave. Podem ocorrer colestase, pancreatite, doença hepática venoclusiva, queda de cabelo e fragilidade das camadas dérmicas. Há possibilidade de hepatotoxicidade com este medicamento. Em virtude dos efeitos adversos do medicamento (mielossupressão - leucopenia, anemia, trombocitopenia), seu uso vem sendo, gradativamente, substituído pelos derivados do ácido micofenólico (micofenolato de mofetila e micofenolato de sódio).

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: Micofenolato de mofetila/de sódio -->
Os micofenolato de mofetila (MMF) e micofenolato de sódio (MFS) são pró-fármacos do ácido micofenólico (MPA) e inibidores da iosina-50-monofosfato desidrogenase (IMPDH), enzima necessária para sintetizar a guanosina, um nucleotídeo imprescindível para ativação dos linfócitos<sup>[4]</sup> e proliferação das células T e B. O mecanismo de ação é semelhante ao da AZA. No sangue, circula ligado a proteínas em cerca de 90%, mas a concentração ativa do medicamento é a porção não ligada às proteínas. É eliminado pela via biliar, seguida por desconjugação intestinal pelas bactérias e, posteriormente, reabsorvido, constituindo um ciclo êntero-hepático. Cerca de 90% da dose oral do medicamento é eliminada pela urina como glicuronídio do ácido micofenólico.  
O MPA vem substituindo a AZA, por ser mais potente e apresentar menos efeitos adversos quando comparado com ela, como mielossupressão e carcinoma espinocelular.  
Entretanto, o MPA apresenta efeitos teratogênicos em animais, portanto, a AZA é primeira escolha nos casos de mulheres grávidas<sup>[31]</sup> . Os principais efeitos adversos relatados do MPA são leucopenia, anemia, trombocitopenia, dor abdominal e diarreia, afetando 20% a 40% dos pacientes. Neutropenia grave (neutrófilos abaixo de 500/mm<sup>3</sup> ) é mais comum com doses altas de MMF, entre 31-180 dias póstransplante. Entretanto, os efeitos adversos são frequentemente resolvidos com a diminuição da dose.  
A administração concomitantemente com ganciclovir e aciclovir pode potencializar a supressão medular. Pode haver uma redução da eficácia quando há o uso simultâneo de antiácidos que contenham magnésio e alumínio.  
Sua ação farmacológica não é tão potente nem tão rápida o suficiente para sejam utilizados em tratamento de rejeição aguda. Evidências sugerem que, na maioria dos casos, não são potentes o suficiente para serem utilizados como monoterapia. Entretanto, são amplamente utilizados em combinação com inibidores da calcineurina (ICNs), quando a imunossupressão é mantida enquanto as doses de INCs podem ser reduzidas e, consequentemente, os efeitos nefrotóxicos dos INCs também<sup>[4]</sup> .

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.1.5 Anticorpos anti-células T -->
Os preparados anti-células T têm sido utilizados na tentativa de evitar eventos adversos dos INCs e corticoides no período pós-operatório imediato, como insuficiência renal e DM. Além disso, o papel atribuído ao uso de elevadas doses de corticosteroides na recidiva da hepatite C e infecção por citomegalovírus (CMV) parecia endossar ainda mais a utilização desses medicamentos no período pósoperatório inicial. Assim, a tentativa de postergar o uso de INCs e minimizar o uso de corticoide mostrouse bastante atrativa.  
A maioria dos centros de transplante tem utilizado o preparado policlonal de globulina antitimócitos de coelho (timoglobulina), no intuito de postergar a exposição aos INCs e prevenir, assim, a insuficiência renal induzida pelo medicamento.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.1.5.1 Imunoglobulina anti-linfócitos T -->
A imunoglobulina antilinfócitos T (timoglobulina, ATG) é um anticorpo policlonal contra linfócitos T originário de coelho ou cavalo e é efetivo para a prevenção e tratamento de rejeição. O efeito imunossupressor se dá pela depleção dos linfócitos T, por promover lise das células T pré-ativadas ou não<sup>[32,</sup> 33]. Não possui ação nefrotóxica, por isso é indicado para pacientes que também apresentam disfunção renal no momento do transplante. Geralmente é administrada no período intraoperatório como opção na terapia de indução da imunossupressão ou no tratamento de rejeição em pacientes resistentes a corticoide<sup>[7,34]</sup> .

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.1.5.2 Anticorpos antirreceptores de IL-2 -->
O basiliximabe, um anticorpo monoclonal antirreceptor de IL-2, é muito utilizado na terapia de indução para o transplante renal e diversos estudos encontrados na literatura comprovaram a sua eficácia na terapia de indução do transplante hepático. É administrado em 2 doses de 20 mg, a primeira no dia zero e a segunda no quarto dia pós-operatório e diminui o risco de rejeição dos enxertos e, consequentemente, as complicações dos pacientes transplantados<sup>[4,35,36]</sup> .

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.1. Esquema de indução -->
A terapia dupla com corticosteroide e inibidor da calcineurina é considerada o tratamento padrão inicial no transplante hepático, com incidência de rejeição de 35%-50% e sobrevida dos pacientes de 80%-90% em 01 ano pós-transplante. No entanto, os efeitos secundários de imunossupressão exagerada (infecções oportunistas e neoplasias de novo), a gravidade da recidiva de doenças virais (como hepatite B  
e hepatite C) e os efeitos adversos em longo prazo (nefrotoxicidade, hipertensão arterial, DM, dislipidemia, osteoporose) determinam uma elevada morbidade e são causa frequente de mortalidade<sup>[39, 40]</sup> .  
A administração de 500 mg a 1 g de metilprednisolona no intraoperatório para todos os pacientesna fase anepática é o esquema de indução mais utilizado.  
Uma alternativa seria a administração de timoglobulina (ATG), principalmente nos casos de insuficiência renal em que se deseja retardar o início dos INCs. A ATG resulta em uma maior imunossupressão por acarretar uma depleção dos linfócitos T, portanto é recomendada para aprevenção da rejeição aguda do enxerto uma dose de 1 a 1,5 mg/kg/dia, durante 2 a 14 dias após o transplante hepático.  
Outra alternativa é a indução com 2 doses de 20 mg de basiliximabe, a primeira no dia zero e a segunda no quarto dia do pós-operatório. Um estudo clínico duplo-cego controlado realizado em 2002 demonstrou que a proporção de episódios de rejeição aguda em 6 e em 12 meses pós-transplante hepático foi reduzida no grupo que utilizou basiliximabe como terapia de indução<sup>[36]</sup> . Há evidências que a adição de basiliximabe à tripla imunossupressão de manutenção melhora a eficácia da terapia, reduzindo a incidência de episódios de rejeição aguda, sem aumentar os efeitos adversos<sup>[35]</sup> .  
Uma revisão sistemática realizada por Penninga L. et al em 2014<sup>[41]</sup> analisou os resultados da terapia de indução com anticorpos específicos anti-células T versus a indução com corticosteroides. Foram incluídos 10 estudos clínicos randomizados (9 estudos com basiliximabe e 1 estudo com ATG) e diferenças significativas não foram observadas quanto a mortalidade (RR 1,01, 95% CI 0,72-1,43), perda do enxerto (RR 1,12, 95% CI 0,82-1,53), rejeição aguda (RR 0,84, 95% CI 0,70-1,00), infecção (RR 0,96, 95% CI 0,85-1,09), recidiva do vírus da hepatite C (RR 0,89, 95% CI 0,79-1,00), doenças malignas (RR 0,59, 95% CI 0,13-2,73) e distúrbio linfoproliferativo pós-transplante (RR 1,00, 95% CI 0,07-15,38) quando as induções com anticorpos anti-células T foram comparados com induções com corticosteroide (os autores relatam baixa qualidade de evidência).  
Outra revisão sistemática de 19 estudos clínicos randomizados, conduzida por Penninga L et al. em 2014<sup>[42]</sup> , mostrou que o uso de terapia de indução com anticorpos anti-células T parece reduzir as taxas de rejeição celular aguda, quando comparada com nenhuma indução (RR 0,85, IC 95%: 0,75-0,96). Não houve diferença na mortalidade, perda de enxerto e eventos adversos RR (0,91, 0,92 e 0,97), IC 95% (0,64-1,28; 0,71-1,19; 0,93-1,02). Os desfechos foram observados com o emprego de qualquer tipo de indução com as terapias anticorpos anti-linfócitos analisadas separadamente ou em conjunto - anticorpos monoclonais (muromonabe-CD3, anti-CD2 ou alentuzumabe), anticorpos policlonais (globulina antitimócito de coelho ou de cavalo – ATG ou globulina antilinfócitos) e antagonistas do receptor de IL-2 (daclizumabe, basiliximabe, BT 563 ou Lo-Tact-1) - comparadas com nenhuma indução. Não houve diferenças significantes quanto aos desfechos: infecção, infecção por CMV, recorrência de hepatite C, malignidade, doença linfoproliferativa pós-transplante (PTLD), insuficiência renal dialítica, hiperlipidemia, DM e hipertensão. A análise comparativa entre os tipos de anticorpos anti-células T não mostrou diferenças significantes com relação à mortalidade, perda do enxerto e rejeição celular aguda (RCA), bem como quanto às taxas de infecção, infecção por CMV, recorrência de hepatite C, malignidade, PTLD, insuficiência renal dialítica, hiperlipidemia, DM e hipertensão. Houve, no entanto, menor taxa de efeitos adversos na comparação entre antagonistas de receptor de IL-2 quando comparados com anticorpos anti-células T policlonais (RR 0,23, IC95% 0,09-0,63). Os autores alertam para a baixa qualidade dos estudos clínicos randomizados, com elevado risco de viés, devido ao pequeno número de estudos disponíveis, à pobre qualidade metodológica e o número limitado de casos incluídos.  
Contudo, os INCs têm nefrotoxicidade muito elevada. Assim, a indução com antagonista de receptor de IL-2 ou anticorpo policlonal antilinfócito T pode ser uma alternativa mais apropriada para pacientes com insuficiência renal (IR) prévia ou alta probabilidade de desenvolvê-la.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.2. Esquema de manutenção -->
Os inibidores da calcineurina (ICNs), como a ciclosporina (CsA) e o tacrolimo (TAC), continuam sendo os principais imunossupressores escolhidos nos esquemas de imunossupressão devido a sua eficácia em evitar a rejeição. A principal complicação dos ICNs é a progressiva perda de função renal em função da nefrotoxicidade. Para minimizar os efeitos adversos do uso crônico do ICN sem comprometer os resultados dos pacientes a curto ou longo prazo, busca-se associar e reduzir a dose desses agentes imunossupressores com outros imunossupressores de classes diferentes<sup>[43,44]</sup> .  
A terapia padrão para a profilaxia da rejeição de órgãos pós-transplante hepático é o ICN, tipicamente o TAC ou CsA (em casos de contraindicação do TAC), adicionado ou não de micofenolato de mofetila (MMF) ou micofenolato de sódio (MFS), de EVR e de corticosteroide.  
O TAC apresenta efeitos adversos que são semelhantes aos da CsA por serem da mesma classe de inibidores de calcineurina, como hipertensão arterial, nefrotoxicidade, neurotoxicidade e diabete<sup>[7]</sup> .  
Uma meta-análise comparou 16 estudos clínicos randomizados que fizeram uso de TAC ou CsA como imunossupressão-base em transplante hepático em adultos. Após um ano, a mortalidade (RR 0,85, 95% CI 0,73-0,99) e a perda do enxerto (RR 0,73, 95% CI 0,61-0,86) apresentaram uma redução significativa no grupo tratado com TAC. O uso de TAC reduziu a rejeição aguda (RR 0,81, 95% CI 0,750,88) e em doentes resistentes a corticoide (RR 0,54, 95% CI 0,47-0,74) no primeiro ano, porém um maior número de casos de DM dependente de insulina foi observado no grupo TAC (RR 1,38, 95% CI 1,01-1,86). Essa meta-análise concluiu que o TAC é superior à CsA em melhorar a sobrevida do paciente e do enxerto e em prevenir rejeição aguda depois do transplante de fígado, entretanto o uso de TAC aumentou o risco de DM pós-transplante.<sup>[45]</sup>  
Alguns centros transplantadores realizam os esquemas de imunossupressão livre de esteroides, utilizando uma monoterapia com TAC<sup>[46]</sup> . Em uma revisão de 2014 sobre esquema de imunossupressão livre de corticosteroides concluiu-se que a substituição de corticosteroides por outros agentes imunossupressores ou monoterapia de TAC após de duas semanas de corticosteroide são alternativas propostas para minimizar os efeitos adversos dos esteroides. Não foram observadas diferenças significativas nos grupos de imunossupressão livre de corticosteroides no âmbito da sobrevida do enxerto e do paciente<sup>[47]</sup> .  
A justificativa para a adição de MPA é permitir uma redução da exposição ao ICN, preservando, assim, a função renal<sup>[48]</sup> . De acordo com o estudo de Ojo et al., 16,5% dos pacientes transplantados apresentaram falência renal crônica devido à exposição contínua a ICN, que possui a nefrotoxicidade como principal efeito adverso. Uma proporção de 28,9% destes pacientes precisaram de diálise ou transplante renal até após 3 anos de acompanhamento<sup>[43]</sup> . No entanto, o nível resultante de rejeições tem sido um motivo de preocupação<sup>[7]</sup> .  
Outra revisão sistemática da literatura relatou em 2012 que a minimização de INC melhora a função renal principalmente em pacientes que já apresentam uma disfunção renal grave. Outro cenário no qual MPA é utilizado é diretamente depois do transplante (de novo) como parte do esquema de imunossupressão tripla, incluindo INC e corticoide. Em pacientes de novo, um esquema de TAC em dose reduzida adicionado de MMF apresentou eficácia equivalente ao TAC em monoterapia, porém um ano após o transplante a função renal não foi significativamente melhor entre os dois grupos<sup>[49]</sup> .  
Segundo as evidências de três estudos clínicos prospectivos randomizados (De Simone et al.<sup>[50]</sup> , Saliba et al.<sup>[51]</sup> e Fischer et al.<sup>[52]</sup> ), o uso de EVR associado a doses reduzidas de TAC acarreta um benefício da função renal nos pacientes transplantados de fígado após o primeiro, o segundo e o terceiro  
anos de acompanhamento ambulatorial. A dose de 1,0 mg de EVR duas vezes ao dia é recomendada para pacientes de transplante hepático, iniciando-se o uso desse medicamento aproximadamente 4 semanas após transplante<sup>[50]</sup> .  
Fundamental para a eficácia do EVR é, mais que a dose ingerida pelo paciente transplantado, o nível sérico do fármaco. Assim, o monitoramento terapêutico de EVR se faz necessário. Os estudos em transplante de rim mostraram que o nível sérico do EVR, se mantido entre 3 e 8 ng/mL (quando combinado com ICN em dose reduzida), preserva a eficácia para prevenir a rejeição ao enxerto.  
Segundo uma revisão sistemática sobre imunossupressão em pacientes transplantados por carcinoma hepatocelular (CHC), o uso de inibidores de mTOR nesses pacientes diminui os riscos de recidiva do CHC devido aos efeitos anti-neoplásicos dos mTORs. Além disto, devido à redução das doses de ICNs<sup>[53]</sup> , os mTORS podem auxiliar a diminuir a nefrotoxicidade. E os ICNs também estão associados à proliferação, in vitro, das células malignas mediante o aumento da angiogênese e invasão das células cancerígenas. O risco da recidiva do CHC em pacientes transplantados demonstrou ser dependente da dose do ICN<sup>[54-56]</sup> . Assim, o uso de inibidores de mTOR nesses pacientes pode diminuir os riscos de recidiva do CHC.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.2.1. Imunossupressão Basal -->
Início do esquema com inibidor de calcineurina: TAC (com dose inicial de 0,1 a 0,3 mg/kg/dia a cada 12 horas por sonda nasogástrica), buscando um nível sérico de 5 – 15 ng/mL de TAC no primeiro ano ou CsA (dose 3 a 6 mg/kg 2 vezes ao dia). O esquema de administração oral do medicamento deve ser feito de acordo com avaliação no vale (C0, antes da administração do medicamento).  
A dose de TAC deve ser ajustada de acordo com os níveis sanguíneos e com o período póstransplante. O Quadro 1 mostra um esquema de níveis sanguíneos sugeridos de tacrolimo, de acordo com o período pós-transplante hepático.  
<u>Quadro 1 - Níveis sanguíneos sugeridos de tacrolimo, dosado no vale (C0).</u>  
|Tempopós-transplante hepático(meses)|Nível sanguíneo C0(ng/ml)|
|---|---|
|0–3|8– 12|
|3–6|7 – 10|
|Acima de6|5– 7|  
No uso de corticosteroide, quando utilizado no intra-operatório, recomenda-se a retirada progressiva até a retirada completa entre 3 meses e 1 ano. Recomenda-se a dose de 20 mg/dia de prednisona, mantida até o final do primeiro mês pós-transplante hepático. Posteriormente, reduz-se a dose, gradativamente, para 10-15 mg/dia até o final do 3<sup>o</sup> mês.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.2.2. Imunossupressão na Insuficiência Renal -->
Para minimizar os efeitos adversos dos inibidores de calcineurina, principalmente a nefrotoxicidade (creatinina sérica ≥ 1,3 mg/dl), os esquemas de imunossupressão têm como objetivo reduzir as doses de ICNs e associar com outros agentes.  
São opções:  
- Opção de indução com timoglobulina e retardar o início de inibidor de calcineurina;  
- Opção de indução com basiliximabe e retardar o início de inibidor de calcineurina;  
- Minimizar a dose de ICN;  
- Opção de associar MPA para reduzir dose de ICN [Micofenolato de mofetila (dose inicial é de 500 mg  
- a 1 g, por via oral, em 2 administrações diárias, com dose máxima de 2 g/dia) OU Micofenolato de sódio (dose inicial é de 360 a 720 mg, por via oral, em 2 administrações diárias, com dose máxima de 1.440 mg/dia)]; e  
- Opção de associar o EVR (inibidor mTOR) após 30 dias do transplante para reduzir dose de ICN nos  
- casos de intolerância a ICNs devido a efeitos adversos. A opção de associação do EVR a doses reduzidas de TAC deve ser ajustada de acordo com os níveis sanguíneos e com o período pós-transplante:  
- Início da administração de EVR a partir do 30˚ dia do pós-operatório, dose inicial de 01 mg  
- por via oral, a cada 12 horas, objetivando um nível sérico de EVR de 3-8 ng/mL.  
- Redução da dose do INC após associação com EVR, com nível sérico de 4-6 ng/mL.  
- 6.2.2.3. Imunossupressão em casos de diabete mélito (DM)  
Uma vez que o TAC aumenta o risco de desenvolver DM pós-transplante, em casos de pacientes diabéticos o inibidor de calcineurina mais indicado é a CsA. O esquema de administração oral do medicamento deve ser feito de acordo com avaliação no vale (C0) ou no pico (C2, mais utilizada, concentração 2 horas após a administração).  
O Quadro 2 mostra um esquema de níveis sanguíneos sugeridos de CsA, de acordo com o período pós-transplante hepático.  
Quadro 2 - Níveis sanguíneos sugeridos de ciclosporina (CsA), dosada no vale (C0) e no pico (C2).  
|Tempo pós-transplante<br>hepático(meses)|Nível sanguíneo C0 (ng/ml)|Nível sanguíneo C2 (ng/ml)|
|---|---|---|
|0–3|200–300|800– 1.200|
|3–6|150– 200|600– 1.000|
|6– 12|120– 150|600–800|
|Acima de 12|80– 120|400–600|

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.2.4. Imunossupressão em Doenças Autoimunes -->
A opção recomendada é a ampliação da imunossupressão basal para a imunossupressão tripla, com doses mais altas de ICN, corticosteroide e MPA ou AZA ou EVR. A avaliação de doses e níveis séricos deve ser feita de acordo com a evolução do paciente e controle da doença autoimune. Quando utilizar-se AZA, a dose recomendada é entre 1 mg/kg/dia a 2 mg/kg/dia, em uma única tomada diária, por via oral.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.2.5. Imunossupressão na Infecção Grave/Sepse -->
Início mais tardio do INC com manutenção de níveis séricos baixos.  
- .2.2.6. Imunossupressão em Casos de Carcinoma Hepatocelular (CHC)  
Imunossupressão habitual, com a opção de associação de inibidores de mTOR após 30 dias do transplante hepático.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.2.7. Imunossupressão na Gestação -->
Imunossupressão habitual com corticosteroide e INCs.Se houver necessidade de associar um agente antimetabólico, a AZA é mais indicada nesses casos, já que os MPA s apresentam efeitos teratogênicos.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.3. Imunossupressão no Tratamento de Rejeição Aguda -->
A primeira medida terapêutica a ser adotada diante de um caso de rejeição aguda é otimizar o tratamento imunossupressor de base. Até se obter resposta de melhora(redução progressiva das enzimas hepáticas ou achados histológicos de rejeição aguda), são recomendadas a seguinte sequência de alternativas:  
- Bolus de corticosteroide – 500 mg a 1g de metilprednisolona que pode ou não ser repetido.  
- Aumento da dose de INCsquando possível, a fim de alcançar níveis sanguíneos no limite superior sugerido  
- MPA ou mTOR como opção para manutenção pós-rejeição  
- Caso paciente for resistente a corticosteroide, existe a opção de administrar timoglobulina: 1,5 mg/kg/dia, durante 3 a 14 dias.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.2.4. Imunossupressão no Tratamento de Rejeição Crônica -->
É difícil reverter o quadro de rejeição quando já evoluiu com ductopenia. Existem as opções de tratamento com aumento dos níveis séricos dos INC e micofenolato.  
Em casos sem melhora clínica e bioquímica (redução das enzimas hepáticas e bilirrubina sérica superior a 20 mg/dl) ou ausência de ductos biliares ao exame da amostra da biópsia hepática, devese indicar retransplante hepático o mais precocemente possível, para evitar a progressiva piora clínica do paciente. Os resultados do retransplante hepático na rejeição crônica são aceitáveis em comparação a outras etiologias.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.3 Tempo de Tratamento -->
A terapia de imunossupressão é contínua para todos os pacientes transplantados de fígado<sup>[57]</sup> , exceto aqueles que se submeteram ao transplante auxiliar na fase em que se deseja eliminar o fígado transplantado nos quais o tratamento com imunossupressores é interrompido. A intensidade da imunossupressão e os medicamentos utilizados serão definidos conforme a evolução dos pacientes e a diminuição da reação imunológica ao enxerto.  
Uma das complicações pós-transplante é o surgimento de neoplasias. Na ocorrência de doença linfoproliferativa pós-transplante, o imunossupressor deverá ser reduzido ou, em alguns casos, até mesmo suspenso. A escolha entre redução de dose ou suspensão do medicamento deverá ser individualizada, levando em consideração fatores como gravidade da doença, extensão da neoplasia (estadiamento) e risco de rejeição<sup>[58,59]</sup> .

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6.4 Benefícios Esperados -->
Os benefícios esperados da imunossupressão são evitar episódios de rejeição aguda e crônica e melhorar as sobrevidas do enxerto e do paciente, com melhora da qualidade de vida.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 7. MONITORIZAÇÃO -->
O transplante hepático bem sucedido requer um esquema de atenção e cuidado envolvendo a equipe médica, pacientes e familiares e se estende por toda a vida, auxiliando na adesão ao tratamento dos pacientes transplantados, principalmente nos casos de pacientes idosos.  
Os pacientes são acompanhados mensalmente no primeiro ano pós-transplante para monitorização dos níveis séricos dos imunossupressores, ajuste de dose(s) do(s) medicamento(s), verificação de possíveis efeitos adversos e realização de exames laboratoriais para diagnosticar precocemente eventos imunológicos, efeitos adversos ou manifestações infecciosas. O Quadro 3 resume os efeitos adversos mais comuns associados aos imunossupressores que orientam a solicitação dos exames clínicos e laboratoriais de monitorização.  
<mark>Quadro 3 - Efeitos adversos dos imunossupressores mais utilizados no transplante de fígado</mark>  
CsA: ciclosporina; TAC: tacrolimo; MMF: micofenolato de mofetila; MS: micofenolato sódico; AZA: azatioprina; EVR: everolimo;+, ++, +++ = intensidade do efeito adverso.  
|Imunossupressores:|Corticosteroides|CsA|TAC|MMF/MS|AZA|EVR|
|---|---|---|---|---|---|---|
|Leucopenia||||+|++|+|
|Anemia||||+|++|+|
|Trombocitopenia||||+|++|+|
|Nefrotoxicidade||++|++||||
|Hipertensão|+++|++|+/++||||
|Hipomagnesemia||+|+||||
|Hiperpotassemia||+|+||||
|Alteraçãogastrointestinal|+|+|++|+++/++||+|
|Alergia alimentar<br>|||+||||
|Úlcera digestiva|+||||||
|Hepatotoxicidade||+|+||+||
|Hiperlipemia|++/+++|++|+|||+++|
|Hiperglicemia|++|+|++||||
|Hiperplasiagengival||++|||||
|Hirsutismo|+|++|||||
|Neurotoxicidade|+|+|+||||
|Retardo do crescimento|+||||||
|Diabete mélito|++/+++|+|++||||
|Má cicatrização|+|||||+|
|Osteoporose|+++|++|+||||
|Catarata|+||||||
|Alteraçãopsiquiátrica|+||||||
|Alopecia|||+||+||  
No caso de pacientes sem complicações clínicas e laboratoriais, as visitas médicas e os exames laboratoriais devem ser gradativamente espaçados. No segundo ano pós-transplante, o acompanhamento ambulatorial passa a ser trimestral.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 8. ACOMPANHAMENTO PÓS-TRATAMENTO -->
Por ser de uso crônico, os pacientes devem ser acompanhados ambulatorialmente para a expedição de novos pedidos médicos dos imunossupressores. Cada prescrição deve ser acompanhada do Termo de Esclarecimento e Responsabilidade, TER. A avaliação dos níveis séricos dos imunossupressores e eventuais ajustes de doses, acompanhamento de exames laboratoriais de sangue e urina para analisar a função renal, glicemia e colesterolemia devem ser mantidos sob vigilância e documentados no prontuário do paciente. A análise das proteínas em uma amostra de urina também pode auxiliar o médico na avaliação da função renal. Todos os eventos adversos ocorridos, ou não, devem ser devidamente documentados na Ficha Farmacoterapêutica.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso dos medicamentos. A documentação completa deve incluir os resultados dos exames de vigilância, as justificativas consistentes de mudanças em condutas e os efeitos adversos ocorridos, ou não, e devem estar devidamente documentados no prontuário do paciente e na Ficha Farmacoterapêutica, respectivamente.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER) -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 11. REFERÊNCIAS -->
1 Adam R, Hoti E. Liver transplantation: the current situation.Semin Liver Dis 2009; 29(1): 3-18 [PMID: 19235656 DOI: 10.1055/s-0029-1192052]  
2 Azzam AZ. Liver transplantation as a management of hepatocellular carcinoma.World J Hepatol 2015; 7(10): 1347-1354 [PMID: 26052380 PMCID: PMC4450198 DOI: 10.4254/wjh.v7.i10.1347]  
3 ABTO. Dimensionamento dos Transplantes no Brasil e em cada estado. Registro Brasileiro de Transplantes. Brazil, 2014  
4 Adams DH, Sanchez-Fueyo A, Samuel D. From immunosuppression to tolerance.J Hepatol 2015; 62(1 Suppl): S170-185 [PMID: 25920086 DOI: 10.1016/j.jhep.2015.02.042]  
5 Starzl TE, Todo S, Fung J, Demetris AJ, Venkataramman R, Jain A. FK 506 for liver, kidney, and pancreas transplantation. Lancet 1989; 2(8670): 1000-1004 [PMID: 2478846 PMCID: PMC2966318] 6 O'Grady JG, Burroughs A, Hardy P, Elbourne D, Truesdale A, Group UaRoILTS. Tacrolimus versus microemulsified ciclosporin in liver transplantation: the TMC randomised controlled trial. Lancet 2002; 360(9340): 1119-1125 [PMID: 12387959]  
7 Geissler EK, Schlitt HJ. Immunosuppression for liver transplantation. Gut 2009; 58(3): 452-463 [PMID: 19052024 DOI: 10.1136/gut.2008.163527]  
8 Rahimi RS, Trotter JF. Liver transplantation for hepatocellular carcinoma: outcomes and treatment options for recurrence. Ann Gastroenterol 2015; 28(3): 323-330 [PMID: 26130250 PMCID: PMC4480168] 9 Cescon M, Ravaioli M, Grazi GL, Ercolani G, Cucchetti A, Bertuzzo V, Vetrone G, Del Gaudio M, Vivarelli M, D'Errico-Grigioni A, Dazzi A, Di Gioia P, Lauro A, Pinna AD. Prognostic factors for tumor recurrence after a 12-year, single-center experience of liver transplantations in patients with hepatocellular carcinoma. J Transplant 2010; 2010 [PMID: 20862199 PMCID: PMC2938428 DOI: 10.1155/2010/904152]  
10 Moini M, Schilsky ML, Tichy EM. Review on immunosuppression in liver transplantation. World J Hepatol 2015; 7(10): 1355-1368 [PMID: 26052381 PMCID: PMC4450199 DOI: 10.4254/wjh.v7.i10.1355] 11 Hübscher SG. Antibody-mediated rejection in the liver allograft. Curr Opin Organ Transplant 2012; 17(3): 280-286 [PMID: 22569512 DOI: 10.1097/MOT.0b013e328353584c]  
12 Burghuber CK, Roberts TK, Knechtle SJ. The clinical relevance of alloantibody in liver transplantation. Transplant Rev (Orlando) 2015; 29(1): 16-22 [PMID: 25510576 DOI: 10.1016/j.trre.2014.06.001]  
13 Jiang X, Morita M, Sugioka A, Harada M, Kojo S, Wakao H, Watarai H, Ohkohchi N, Taniguchi M, Seino K. The importance of CD25+ CD4+ regulatory T cells in mouse hepatic allograft tolerance. Liver Transpl 2006; 12(7): 1112-1118 [PMID: 16724335 DOI: 10.1002/lt.20787]  
14 Haas M, Sis B, Racusen LC, Solez K, Glotz D, Colvin RB, Castro MC, David DS, David-Neto E, Bagnasco SM, Cendales LC, Cornell LD, Demetris AJ, Drachenberg CB, Farver CF, Farris AB, Gibson IW, Kraus E, Liapis H, Loupy A, Nickeleit V, Randhawa P, Rodriguez ER, Rush D, Smith RN, Tan CD, Wallace WD, Mengel M, committee Bmrw. Banff 2013 meeting report: inclusion of c4d-negative antibody-  
mediated rejection and antibody-associated arterial lesions. Am J Transplant 2014; 14(2): 272-283 [PMID: 24472190 DOI: 10.1111/ajt.12590]  
15 Gugenheim J, Samuel D, Reynes M, Bismuth H. Liver transplantation across ABO blood group barriers. Lancet 1990; 336(8714): 519-523 [PMID: 1975036]  
16 Kitchens WH, Yeh H, Markmann JF. Hepatic retransplant: what have we learned? Clin Liver Dis 2014; 18(3): 731-751 [PMID: 25017086 DOI: 10.1016/j.cld.2014.05.010]  
17 Taylor AL, Watson CJ, Bradley JA. Immunosuppressive agents in solid organ transplantation: Mechanisms of action and therapeutic efficacy. Crit Rev Oncol Hematol 2005; 56(1): 23-46 [PMID: 16039869 DOI: 10.1016/j.critrevonc.2005.03.012]  
18 Armstrong VW, Oellerich M. New developments in the immunosuppressive drug monitoring of cyclosporine, tacrolimus , and azathioprine. Clin Biochem 2001; 34(1): 9-16 [PMID: 11239509] 19 Thomson AW, Bonham CA, Zeevi A. Mode of action of tacrolimus (FK506): molecular and cellular mechanisms. Ther Drug Monit 1995; 17(6): 584-591 [PMID: 8588225]  
20 Augustine JJ, Bodziak KA, Hricik DE. Use of sirolimus in solid organ transplantation. Drugs 2007; 67(3): 369-391 [PMID: 17335296]  
21 Schuler W, Sedrani R, Cottens S, Häberlin B, Schulz M, Schuurman HJ, Zenke G, Zerwes HG, Schreier MH. SDZ RAD, a new rapamycin derivative: pharmacological properties in vitro and in vivo. Transplantation 1997; 64(1): 36-42 [PMID: 9233698]  
22 Kovarik JM, Sabia HD, Figueiredo J, Zimmermann H, Reynolds C, Dilzer SC, Lasseter K, Rordorf C. Influence of hepatic impairment on everolimus pharmacokinetics: implications for dose adjustment. Clin Pharmacol Ther 2001; 70(5): 425-430 [PMID: 11719728]  
23 Bianco R, Garofalo S, Rosa R, Damiano V, Gelardi T, Daniele G, Marciano R, Ciardiello F, Tortora G. Inhibition of mTOR pathway by everolimus cooperates with EGFR inhibitors in human tumours sensitive and resistant to anti-EGFR drugs. Br J Cancer 2008; 98(5): 923-930 [PMID: 18319715 PMCID: PMC2266842 DOI: 10.1038/sj.bjc.6604269]  
24 Toso C, Merani S, Bigam DL, Shapiro AM, Kneteman NM. Sirolimus-based immunosuppression is associated with increased survival after liver transplantation for hepatocellular carcinoma. Hepatology 2010; 51(4): 1237-1243 [PMID: 20187107 DOI: 10.1002/hep.23437]  
25 Zimmerman MA, Trotter JF, Wachs M, Bak T, Campsen J, Skibba A, Kam I. Sirolimus-based immunosuppression following liver transplantation for hepatocellular carcinoma. Liver Transpl 2008; 14(5): 633-638 [PMID: 18324656 DOI: 10.1002/lt.21420]  
26 Gomez-Camarero J, Salcedo M, Rincon D, Lo Iacono O, Ripoll C, Hernando A, Sanz C, Clemente G, Bañares R. Use of everolimus as a rescue immunosuppressive therapy in liver transplant patients with neoplasms. Transplantation 2007; 84(6): 786-791 [PMID: 17893613 DOI: 10.1097/01.tp.0000280549.93403.dd]  
27 Bilbao I, Sapisochin G, Dopazo C, Lazaro JL, Pou L, Castells L, Caralt M, Blanco L, Gantxegi A, Margarit C, Charco R. Indications and management of everolimus after liver transplantation. Transplant Proc 2009; 41(6): 2172-2176 [PMID: 19715864 DOI: 10.1016/j.transproceed.2009.06.087]  
28 Zhu AX, Kudo M, Assenat E, Cattan S, Kang YK, Lim HY, Poon RT, Blanc JF, Vogel A, Chen CL, Dorval E, Peck-Radosavljevic M, Santoro A, Daniele B, Furuse J, Jappe A, Perraud K, Anak O, Sellami DB, Chen LT. Effect of everolimus on survival in advanced hepatocellular carcinoma after failure of sorafenib: the EVOLVE-1 randomized clinical trial. JAMA 2014; 312(1): 57-67 [PMID: 25058218 DOI: 10.1001/jama.2014.7189]  
29 Lennard L. The clinical pharmacology of 6-mercaptopurine. Eur J Clin Pharmacol 1992; 43(4): 329-339 [PMID: 1451710]  
30 Maltzman JS, Koretzky GA. Azathioprine: old drug, new actions. J Clin Invest 2003; 111(8): 1122-1124 [PMID: 12697731 PMCID: PMC152947 DOI: 10.1172/JCI18384]  
31 Parhar KS, Gibson PS, Coffin CS. Pregnancy following liver transplantation: review of outcomes and recommendations for management. Can J Gastroenterol 2012; 26(9): 621-626 [PMID: 22993734 PMCID: PMC3441170]  
32 Genestier L, Fournel S, Flacher M, Assossou O, Revillard JP, Bonnefoy-Berard N. Induction of Fas (Apo-1, CD95)-mediated apoptosis of activated lymphocytes by polyclonal antithymocyte globulins. Blood 1998; 91(7): 2360-2368 [PMID: 9516135]  
33 Préville X, Flacher M, LeMauff B, Beauchard S, Davelu P, Tiollier J, Revillard JP. Mechanisms involved in antithymocyte globulin immunosuppressive activity in a nonhuman primate model. Transplantation 2001; 71(3): 460-468 [PMID: 11233911]  
34 Takeishi K, Ikegami T, Yoshizumi T, Itoh S, Harimoto N, Harada N, Tsujita E, Kimura Y, Yamashita Y, Saeki K, Oki E, Shirabe K, Maehara Y. Thymoglobulin for steroid-resistant immune-mediated graft dysfunction during simeprevir-based antiviral treatment for post-transplantation hepatitis C: case report. Transplant Proc 2015; 47(3): 794-795 [PMID: 25891734 DOI: 10.1016/j.transproceed.2014.11.056]  
35 Calmus Y, Scheele JR, Gonzalez-Pinto I, Jaurrieta EJ, Klar E, Pageaux GP, Scudamore CH, CuervasMons V, Metselaar HJ, Prestele H, Girault D. Immunoprophylaxis with basiliximab, a chimeric antiinterleukin-2 receptor monoclonal antibody, in combination with azathioprine-containing triple therapy in liver transplant recipients. Liver Transpl 2002; 8(2): 123-131 [PMID: 11862588 DOI: 10.1053/jlts.2002.30882]  
36 Neuhaus P, Clavien PA, Kittur D, Salizzoni M, Rimola A, Abeywickrama K, Ortmann E, Chodoff L, Hall M, Korn A, Nashan B, Group CILS. Improved treatment response with basiliximab immunoprophylaxis after liver transplantation: results from a double-blind randomized placebo-controlled trial. Liver Transpl 2002; 8(2): 132-142 [PMID: 11862589 DOI: 10.1053/jlts.2002.30302]  
37 Schumann A, Fiedler M, Beckebaum S, Cicinnati VR, Herzer K, Lenz V, Witzke O, Paul A, Roggendorf M, Horn PA, Lindemann M. Donor- and recipient-derived immunity in ABO incompatible living-related liver transplantation. Hum Immunol 2015 [PMID: 26394233 DOI: 10.1016/j.humimm.2015.09.008]  
38 Tydén G, Donauer J, Wadström J, Kumlien G, Wilpert J, Nilsson T, Genberg H, Pisarski P, Tufveson G. Implementation of a Protocol for ABO-incompatible kidney transplantation--a three-center experience with 60 consecutive transplantations. Transplantation 2007; 83(9): 1153-1155 [PMID: 17496528 DOI: 10.1097/01.tp.0000262570.18117.55]  
39 Boillot O, Baulieux J, Wolf P, Messner M, Cherqui D, Gugenheim J, Pageaux G, Belghiti J, Calmus Y, Le Treut Y, Neau-Cransac M, Samuel D. Low rejection rates with tacrolimus -based dual and triple regimens following liver transplantation.Clin Transplant 2001; 15(3): 159-166 [PMID: 11389705]  
40 González MG, Madrazo CP, Rodríguez AB, Gutiérrez MG, Herrero JI, Pallardó JM, Ortiz de Urbina J, Paricio PP. An open, randomized, multicenter clinical trial of oral tacrolimus in liver allograft transplantation: a comparison of dual vs. triple drug therapy. Liver Transpl 2005; 11(5): 515-524 [PMID: 15838889 DOI: 10.1002/lt.20382]  
41 Penninga L, Wettergren A, Wilson CH, Chan AW, Steinbrüchel DA, Gluud C. Antibody induction versus corticosteroid induction for liver transplant recipients. Cochrane Database Syst Rev 2014; 5: CD010252 [PMID: 24880007 DOI: 10.1002/14651858.CD010252.pub2]  
42 Penninga L, Wettergren A, Wilson CH, Chan AW, Steinbrüchel DA, Gluud C. Antibody induction versus placebo, no induction, or another type of antibody induction for liver transplant recipients. Cochrane Database Syst Rev 2014; 6: CD010253 [PMID: 24901467 DOI: 10.1002/14651858.CD010253.pub2]  
43 Ojo AO, Held PJ, Port FK, Wolfe RA, Leichtman AB, Young EW, Arndorfer J, Christensen L, Merion RM. Chronic renal failure after transplantation of a nonrenal organ. N Engl J Med 2003; 349(10): 931-940 [PMID: 12954741 DOI: 10.1056/NEJMoa021744]  
44 O'Riordan A, Wong V, McCormick PA, Hegarty JE, Watson AJ. Chronic kidney disease post-liver transplantation. Nephrol Dial Transplant 2006; 21(9): 2630-2636 [PMID: 16735393 DOI: 10.1093/ndt/gfl247]  
45 Haddad EM, McAlister VC, Renouf E, Malthaner R, Kjaer MS, Gluud LL. Cyclosporin versus tacrolimus for liver transplanted patients. Cochrane Database Syst Rev 2006(4): CD005161 [PMID: 17054241 DOI: 10.1002/14651858.CD005161.pub2]  
46 Lerut J, Mathys J, Verbaandert C, Talpe S, Ciccarelli O, Lemaire J, Bonaccorsi-Riani E, Vanthuyne V, Hetsch N, Roggen F, Reyck CD, Goffette P, Latinne D, Orlando G, Rahier J, Sempoux C, Wallemacq P, Laterre PF, Gianello P. Tacrolimus monotherapy in liver transplantation: one-year results of a prospective, randomized, double-blind, placebo-controlled study. Ann Surg 2008; 248(6): 956-967 [PMID: 19092340 DOI: 10.1097/SLA.0b013e31819009c9]  
47 Sgourakis G, Dedemadi G. Corticosteroid-free immunosuppression in liver transplantation: an evidencebased review. World J Gastroenterol 2014; 20(31): 10703-10714 [PMID: 25152574 PMCID: PMC4138451 DOI: 10.3748/wjg.v20.i31.10703]  
48 Karie-Guigues S, Janus N, Saliba F, Dumortier J, Duvoux C, Calmus Y, Lorho R, Deray G, LaunayVacher V, Pageaux GP. Long-term renal function in liver transplant recipients and impact of immunosuppressive regimens (calcineurin inhibitors alone or in combination with mycophenolate mofetil): the TRY study. Liver Transpl 2009; 15(9): 1083-1091 [PMID: 19718632 DOI: 10.1002/lt.21803]  
49 Goralczyk AD, Bari N, Abu-Ajaj W, Lorf T, Ramadori G, Friede T, Obed A. Calcineurin inhibitor sparing with mycophenolate mofetil in liver transplantion: a systematic review of randomized controlled trials. Am J Transplant 2012; 12(10): 2601-2607 [PMID: 22813081 DOI: 10.1111/j.16006143.2012.04157.x]  
50 De Simone P, Nevens F, De Carlis L, Metselaar HJ, Beckebaum S, Saliba F, Jonas S, Sudan D, Fung J, Fischer L, Duvoux C, Chavin KD, Koneru B, Huang MA, Chapman WC, Foltys D, Witte S, Jiang H, Hexham JM, Junge G, Group HS. Everolimus with reduced tacrolimus improves renal function in de novo liver transplant recipients: a randomized controlled trial. Am J Transplant 2012; 12(11): 3008-3020 [PMID: 22882750 PMCID: PMC3533764 DOI: 10.1111/j.1600-6143.2012.04212.x]  
51 Saliba F, De Simone P, Nevens F, De Carlis L, Metselaar HJ, Beckebaum S, Jonas S, Sudan D, Fischer L, Duvoux C, Chavin KD, Koneru B, Huang MA, Chapman WC, Foltys D, Dong G, Lopez PM, Fung J, Junge G, Group HS. Renal function at two years in liver transplant patients receiving everolimus: results of a randomized, multicenter study. Am J Transplant 2013; 13(7): 1734-1745 [PMID: 23714399 DOI: 10.1111/ajt.12280]  
52 Fischer L, Saliba F, Kaiser GM, De Carlis L, Metselaar HJ, De Simone P, Duvoux C, Nevens F, Fung JJ, Dong G, Rauer B, Junge G, Group HS. Three-year Outcomes in De Novo Liver Transplant Patients Receiving Everolimus With Reduced Tacrolimus : Follow-Up Results From a Randomized, Multicenter Study. Transplantation 2015; 99(7): 1455-1462 [PMID: 26151607 DOI: 10.1097/TP.0000000000000555] 53 Cholongitas E, Mamou C, Rodríguez-Castro KI, Burra P. Mammalian target of rapamycin inhibitors are associated with lower rates of hepatocellular carcinoma recurrence after liver transplantation: a systematic review. Transpl Int 2014; 27(10): 1039-1049 [PMID: 24943720 DOI: 10.1111/tri.12372]  
54 Hojo M, Morimoto T, Maluccio M, Asano T, Morimoto K, Lagman M, Shimbo T, Suthanthiran M. Cyclosporine induces cancer progression by a cell-autonomous mechanism. Nature 1999; 397(6719): 530534 [PMID: 10028970 DOI: 10.1038/17401]  
55 Rodríguez-Perálvarez M, Tsochatzis E, Naveas MC, Pieri G, García-Caparrós C, O'Beirne J, PoyatoGonzález A, Ferrín-Sánchez G, Montero-Álvarez JL, Patch D, Thorburn D, Briceño J, De la Mata M, Burroughs AK. Reduced exposure to calcineurin inhibitors early after liver transplantation prevents recurrence of hepatocellular carcinoma. J Hepatol 2013; 59(6): 1193-1199 [PMID: 23867318 DOI: 10.1016/j.jhep.2013.07.012]  
56 Duvoux C, Toso C. mTOR inhibitor therapy: Does it prevent HCC recurrence after liver transplantation? Transplant Rev (Orlando) 2015; 29(3): 168-174 [PMID: 26071984 DOI: 10.1016/j.trre.2015.02.003] 57 Starzl TE, Iwatsuki S, Van Thiel DH, Gartner JC, Zitelli BJ, Malatack JJ, Schade RR, Shaw BW, Hakala TR, Rosenthal JT, Porter KA. Evolution of liver transplantation. Hepatology 1982; 2(5): 614-636 [PMID: 6749635 PMCID: PMC2972731]  
58 Jain A, Nalesnik M, Reyes J, Pokharna R, Mazariegos G, Green M, Eghtesad B, Marsh W, Cacciarelli T, Fontes P, Abu-Elmagd K, Sindhi R, Demetris J, Fung J. Posttransplant lymphoproliferative disorders in liver transplantation: a 20-year experience. Ann Surg 2002; 236(4): 429-436; discussion 436-427 [PMID: 12368671 PMCID: PMC1422597 DOI: 10.1097/01.SLA.0000033429.89424.F8]  
59 Marino D, Burra P, Boccagni P, Calabrese F, Canova F, Trentin C, Boso C, Soldà C, Angeli P, Aversa SM. Post-transplant lymphoproliferative disorders in liver transplanted patients: a single-centre experience.Anticancer Res 2010; 30(6): 2383-2391 [PMID: 20651397]

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: TERMO DE ESCLARECIMENTO E RESPONSABILIDADE -->
Azatioprina, Basiliximabe, Ciclosporina, Corticosteroide, Everolimo, Micofenolato (de mofetila ou de sódio) e Tacrolimo.  
Eu,............................................................................................................................................. .......... (nome do(a) paciente), declaro ter sido informado(a) claramente sobre todas as indicações, contraindicações, principais efeitos colaterais e riscos relacionados ao uso de medicamentos imunossupressores para o tratamento preventivo ou terapêutico da rejeição do transplante. Expresso também minha concordância e espontânea vontade em submeter-me ao referido tratamento, assumindo a responsabilidade e os riscos por eventuais efeitos indesejáveis.  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico (nome do médico). Assim, declaro que fui claramente informado(a) de que o(s) medicamento(s) que passo a receber podem trazer os seguintes benefícios: diminuição das chances de rejeição aguda do transplante; diminuição das chances de rejeição crônica do transplante;  e aumento da sobrevida do órgão transplantado e da minha própria sobrevida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos colaterais e riscos do uso destes medicamentos:  
Categoria B: Basiliximabe - Não há estudos adequados com mulheres (em experimentos animais não foram demonstrados riscos).  
Categoria C: ciclosporina, everolimo, metilprednisolona, prednisona, tacrolimo - Pesquisas em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos.  
Categoria D: Há evidências de riscos ao feto, mas um benefício potencial pode ser maior do que os riscos. Micofenolato (de mofetila ou de sódio) e azatioprina: O micofenolato é associado ao aumento do risco de malformações congênitas e perda do feto no primeiro trimestre de gravidez quando utilizado durante a gestação.  
Azatioprina - Comprometimento dos sistemas hematológico e gastrointestinal, podendo também ocorrer anemia, diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, pancreatite, toxicidade para o fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, queda de cabelo, aftas, dores articulares, retinopatia, falta de ar, pressão baixa, reações de hipersensibilidade, predisposição para câncer de pele e de outros órgãos.  
Basiliximabe - Constipação; náusea; diarreia; dor abdominal; vômito; má-digestão, aumento da glicose no sangue; aumento do ácido úrico no sangue; diminuição do fosfato no sangue; aumento do colesterol no sangue, dor de cabeça; tremor; dor; febre; insônia, infecção do trato-urinário, inchaço; aumento da pressão arterial; anemia, dificuldade para respirar; infecção do trato respiratório, complicações no corte cirúrgico; acne.  
Ciclosporina - Disfunção renal, tremores, aumento da quantidade de pelos no corpo, pressão alta, hipertrofia gengival, aumento dos níveis de colesterol e triglicerídeos, podendo também ocorrer formigamentos, dor no peito, infarto do miocárdio, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, gastrite, úlcera péptica, soluços, inflamação na boca, dificuldade para engolir,  
hemorragias, inflamação do pâncreas, prisão de ventre, desconforto abdominal, síndrome hemolíticourêmica, diminuição das células brancas do sangue, linfoma, calorões, hiperpotassemia, hipomagnesemia, hiperuricemia, toxicidade para os músculos, disfunção respiratória, sensibilidade aumentada à temperatura, reações alérgicas, toxicidade renal e hepática, ginecomastia (aumento das mamas no homem).  
Corticosteroides – Retenção de líquidos, ganho de peso, diabete mélito, aumento da pressão arterial, alterações nos níveis de lipídios no sangue, síndrome de Cushing, problemas relacionados ao coração, fraqueza nos músculos, irritação no estômago, pancreatite (inflamação do pâncreas), euforia, insônia, oscilações de humor, cataratas, miopatia (fraqueza dos músculos) aguda generalizada, osteoporose (diminuição da massa óssea).  
Everolimo - Leucopenia, hipercolesterolemia, hiperlipemia, hipertrigliceridemia, infecções virais, fúngicas e bacterianas, sepse, trombocitopenia, anemia, coagulopatia, púrpura trombocitopênica trombótica/síndrome hemolítico-urêmica, pressão alta, linfocele, tromboembolia venosa, dor abdominal, diarreia, náusea, vômitos, acne, complicações de ferimentos cirúrgicos, edema, artralgias. Não se sabe se o medicamento é excretado pelo leite materno. Não há experiência suficiente para recomendar seu uso em crianças e adolescentes. A experiência clínica em indivíduos com mais de 65 anos de idade é limitada. Pacientes em uso de everolimo são mais suscetíveis a desenvolver linfomas e outras doenças malignas, particularmente de pele. Em pacientes com insuficiência hepática, a concentração sanguínea mínima deve ser monitorizada com cautela. Os pacientes devem ser acompanhados quanto ao risco de rabdomiólise e outras adversidades decorrentes do aumento da biodisponibilidade do medicamento. Métodos contraceptivos devem ser utilizados por pacientes de ambos os sexos sob o regime imunossupressor até que informações mais conclusivas estejam disponíveis.  
Micofenolato (de mofetila ou de sódio) - Diarreia, diminuição das células brancas do sangue, infecção generalizada e vômitos, podendo também ocorrer dor no peito, palpitações, pressão baixa, trombose, insuficiência cardíaca, hipertensão pulmonar, morte súbita, desmaio, ansiedade, depressão, rigidez muscular, formigamentos, sonolência, neuropatia, convulsões, alucinações, vertigens, tremores, insônia, tonturas, queda de cabelo, aumento da quantidade de pelos no corpo, coceiras, ulcerações na pele, espinhas, vermelhidão da pele, prisão de ventre, náusea, azia e dor de estômago, perda de apetite, gases, gastrite, gengivite, hipertrofia gengival, hepatite, sangue na urina, aumento da frequência ou retenção urinária, insuficiência renal, desconforto para urinar, impotência sexual, anemia, diminuição das plaquetas do sangue, diabete mélito, síndrome de Cushing, hipotireoidismo, inchaço, alteração de eletrólitos (hipofosfatemia, hiperpotassemia, hipocloremia), hiperglicemia, hipercolesterolemia, alteração de enzimas hepáticas, febre, dor de cabeça, fraqueza, dor nas costas e no abdômen, pressão alta, falta de ar, tosse.  
Tacrolimo - Tremores, dor de cabeça, diarreia, pressão alta, náusea e disfunção renal, podendo também ocorrer dor no peito, pressão baixa, palpitações, formigamentos, falta de ar, colangite, amarelão, diarreia, prisão de ventre, vômitos, diminuição do apetite, azia e dor no estômago, gases, hemorragia, dano hepático, agitação, ansiedade, convulsão, depressão, tontura, alucinações, incoordenação, psicose, sonolência, neuropatia, queda de cabelo, aumento da quantidade de pelos no corpo, vermelhidão de pele, coceiras, anemia, aumento ou diminuição das células brancas do sangue, diminuição das plaquetas do sangue, desordens na coagulação, síndrome hemolíticourêmica, edema periférico, alterações metabólicas (hipopotassemia, hiperpotassemia, hiperglicemia, hipomagnesemia, hiperuricemia), diabete mélito, elevação de enzimas hepáticas, toxicidade renal, diminuição importante do volume da urina, febre,  
acúmulo de líquido no abdômen e na pleura, fraqueza, dor lombar, atelectasias, osteoporose, dores no corpo, peritonite, fotossensibilidade, alterações visuais.  
Timoglobulina: Reações relacionadas à infusão (reações associadas à perfusão  - RAP). As manifestações clínicas de RAP incluem alguns dos seguintes sinais e sintomas: febre, calafrios, rigidez, dispneia, náusea, vômitos, diarreia, hipotensão ou hipertensão, mal-estar, erupção cutânea, urticária, diminuição da saturação de oxigênio ou dor de cabeça.  
Estou também ciente de que estes medicamentos somente podem ser utilizados por mim, comprometendo-me a devolvê-los caso não queira, não possa utilizá-los ou se o tratamento for interrompido. E de que, se o tratamento for suspenso sem orientação médica, corro o risco de perder o transplante. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o(s) medicamento(s). Estou da mesma forma ciente de que pode haver necessidade de mudança das doses, assim como de medicamento imunossupressor ao longo do meu tratamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  (   ) Sim (    ) Não  
Meu tratamento imunossupressor constará de uma combinação do(s) seguinte(s) medicamento(s):  
- (  ) Azatioprina  
- (   ) Basiliximabe  
- (   ) Ciclosporina  
- (   ) Corticosteroide  
- (   ) Everolimo  
- (   ) Micofenolato de mofetila  
- (   ) Micofenolato de sódio  
- (   ) Tacrolimo  
- (   ) Timoglobulina  
Local: ............................................................................................................... Data:....../....../.......... Nome do Paciente: .............................................................................................................................. Cartão Nacional de Saúde N : .............................................................................................................. Nome do responsável legal: ................................................................................................................ Documento de Identificação do responsável legal: ............................................................................. .................................................................................... Assinatura do paciente ou do responsável legal Médico responsável: ....................................................... CRM:........................................... UF:............ .................................................................................. Data:....../....../.......... Assinatura e carimbo do médico  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: FICHA FARMACOTERAPÊUTICA -->
IMUNOSSUPRESSÃO NO TRANSPLANTE HEPÁTICO EM ADULTOS

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 1 DADOS DO PACIENTE -->
Nome:________________________________________________________________ Cartão Nacional de Saúde (CNS):__________________________________________ RG:___________________ DN: ___/___/____ Idade: __________ Peso: __________ Altura: ____________ Sexo: (    )  F (    )  M Endereço:___________________________________________________________________ Telefone(s):_________________________________________________________________ Médico assistente_____________________________________________________________ CRM:________________Telefone(s):____________________________________________ Nome do cuidador:____________________________________________________________ Cartão Nacional de Saúde (CNS):________________________________________________ RG:__________________________ 2 AVALIAÇÃO FARMACOTERAPÊUTICA 2.1 Qual a data do transplante?__ ________________________________________________  
2.2 Medicamento(s) utilizado(s) na imunossupressão:  
_____________________________________________________________________________________ _____________________________________________________________________________________ _____________________________________________________________________________________ _____________________________________________________________________________________ _____ 2.3 Tem outra(s) doença(s) diagnosticada(s)? (   )  Não (   ) Sim Qual(ais)?____________________________________________________________________________ _____________________________________________________________________________________ 2.4 Faz uso de outros medicamentos? (   ) Não    (   ) Sim 2.5 Já apresentou reação alérgica a medicamento(s)? (   ) Não   (   ) Sim Qual(ais)?  
|______________________<br>A que Medicamento(s)?__<br>3.MONITORIZAÇÃODO<br>|___________________<br>___________________<br>TRATAMENTO<br> <br>|_________<br>_________<br>|________<br>_________<br>|__________<br>_________<br>|________<br>_________<br>|_________<br>________<br>|
|---|---|---|---|---|---|---|
|Para Azatioprina|Inicial<br>1°mês|2°mês|3°mês|4°mês|5°mês|6°mês|
|Dataprevista|||||||  
|Datarealizada<br>||||||||
|---|---|---|---|---|---|---|---|
|Hemoglobina||||||||
|Leucócitos||||||||
|Neutrófilos||||||||
|Linfócitos<br>||||||||
|Plaquetas||||||||
|<br>AST/TGO||||||||
|ALT/TGP<br>||||||||
|Fosfatasealcalina||||||||
|Bilirrubinas||||||||
|Para Ciclosorina ou||||||||
|p<br>Tacrolimo|Inicial|1°mês|2°mês|3°mês|4°mês|5°mês|6°mês|
|Dataprevista||||||||
|Datarealizada||||||||
|Hemoglobina||||||||
|Leucócitos||||||||
|Neutrófilos||||||||
|Linfócitos||||||||
|Plaquetas||||||||
|Glicemia dejejum||||||||
|Creatinina||||||||
|Colesteroltotal||||||||
|Triglicerídeos||||||||
|Eletrólitos(Na,K)||||||||
|AST/TGO||||||||
|ALT/TGP||||||||
|Fosfatasealcalina||||||||
|Bilirrubinas||||||||
|Nível sérico dofármaco||||||||
|Para Micofenolato de||||||||
|Mofetila/Sódio|Inicial|1°mês|2°mês|3°mês|4°mês|5°mês|6°mês|
|Dataprevista||||||||
|Datarealizada||||||||
|Hemoglobina||||||||
|Leucócitos||||||||
|Neutrófilos||||||||
|Linfócitos||||||||
|Plaquetas||||||||
|(continuação)|7°mês|8°mês|9°m|ês<br>10°|mês|11°mês|12°mês|
|Dataprevista||||||||
|<br>Datarealizada||||||||
|Hemoglobina||||||||
|Leucócitos||||||||
|Neutrófilos||||||||
|Linfócitos||||||||  
|Plaquetas||||||||
|---|---|---|---|---|---|---|---|
|Para Everolimo|Inicial|1°mês|2°mês|3°mês|4°mês|5°mês|6°mês|
|Dataprevista||||||||
|Datarealizada||||||||
|Glicemia dejejum||||||||
|Creatinina||||||||
|Colesteroltotal||||||||
|Triglicerídeos||||||||
|Eletrólitos (Na,K)<br>||||<br>||||
|(continuação)|7°mês|8°mês|9°m|ês<br>10|mês|11°mês|12°mês|
|Dataprevista||||||||
|Datarealizada||||||||
|Glicemia dejejum||||||||
|Creatinina||||||||
|Colesteroltotal||||||||
|Triglicerídeos||||||||
|Eletrólitos (Na,K)||||||||

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: **3.1** Para azatioprina: leucócitos totais abaixo de 3.000/mm3? Não → Dispensar o medicamento. -->
Sim → Dispensar o medicamento e encaminhar o paciente para o médico assistente. Aconselha-se a suspender o medicamento.  
**3.2** Apresentou alteração significativa de algum exame laboratorial? Não → Dispensar o medicamento.  
Sim→ Dispensar o medicamento e encaminhar o paciente ao médico assistente para ajuste de dose(s), suspensão ou troca de medicamento(s).  
**3.3** Apresentou sintomas que indiquem efeitos adversos? Não → Dispensar o medicamento. Sim → Descrever.  
3.3.1 Efeito adverso necessita de avaliação do médico assistente? Não → Dispensar o medicamento.  
Sim → Dispensar o medicamento e encaminhar o paciente ao médico assistente  
3.4 Desde a última dispensação houve alteração no uso de medicamento (novos, suspensões, ou troca de medicamentos ou de posologia)?  
(   ) Não  (   ) Sim

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 1. DOENÇA -->
Quando um transplante de órgão (como o fígado) é realizado pode ocorrer a rejeição deste órgão pelo organismo. Por isso, é fundamental a utilização de medicamento(s) que diminua(m) o risco desta rejeição, prevenindo lesão ou perda do órgão transplantado.Os medicamentos utilizados para esta finalidade são os chamados imunossupressores.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 2. MEDICAMENTOS -->
Estes medicamentos previnem ou reduzem os episódios de rejeição do órgão transplantado, assim permitindo o seu adequado funcionamento.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 3. GUARDA DO(S) MEDICAMENTO(S) -->
Guarde os medicamentos protegido do calor, ou seja, evite lugares onde exista variação de temperatura (cozinha e banheiro). Conserve o medicamento na embalagem original.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 4. ADMINISTRAÇÃO DO(S) MEDICAMENTO(S) -->
- Tome os comprimidos, drágeas ou cápsulas sem mastigar ou abrir com ajuda de um líquido.  
 Tome exatamente a dose prescrita nos dias que o médico indicou, estabelecendo um mesmo horário para tomar.  
 Em caso de esquecimento de uma dose, tome-a assim que se lembrar. Não tome a dose em dobro para compensar a que foi esquecida.  
- Azatioprina, prednisona e prednisolona: tome durante ou após as refeições.  
- Micofenolato de mofetila ou de sódio: tome de estômago vazio (antes das refeições ou 2 horas  
após).  
 Tacrolimo e Everolimo: tome sempre da mesma forma, com ou sem alimentos, de modo a reduzir a sua variabilidade de absorção.  
 Ciclosporina: controle a ingestão de alimentos, pois pode influenciar na absorção do medicamento. A solução oral de ciclosporina, em função do sabor, deve ser diluída, de preferência, com suco de laranja ou de maçã; também podem ser usados refrigerantes ou outras bebidas. Deve-se evitar a diluição em suco de uva, pois este aumenta os níveis da ciclosporina no sangue.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 5. REAÇÕES DESAGRADÁVEIS -->
Apesar dos benefícios que o medicamento pode trazer, é possível que apareçam algumas reações desagradáveis, que variam de acordo com o medicamento, tais como náusea, vômitos, diarreia, perda de apetite, dores de cabeça, reações alérgicas, tontura, entre outros.  
Se houver algum destes ou outros sinais e sintomas, comunique-se com o médico ou farmacêutico. Maiores informações sobre reações adversas constam no Termo de Esclarecimento e Responsabilidade, documento assinado por você ou seu responsável legal e pelo médico.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 6. USO DE OUTROS MEDICAMENTOS -->
Não faça uso de outros medicamentos sem o conhecimento do médico ou orientação de um profissional da saúde.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 7. OUTRAS INFORMAÇÕES IMPORTANTES -->
- Evite o uso de bebidas alcoólicas durante o tratamento.  
- Evite exposição prolongada ao sol durante o uso do medicamento.  
- Faça revisões periódicas com o dentista e oftalmologista, pois podem ocorrer problemas devido  
- ao uso dos medicamentos.  
 Estes medicamentos podem causar problemas ao feto. Por isso, se engravidar comunique imediatamente ao médico.  
 Não é recomendada a amamentação durante o uso dos imunossupressores, pois eles passam para o leite materno. Converse com o médico a respeito.  
Estes medicamentos diminuem as defesas do organismo; por isso, evite contato com pessoas com doenças infecciosas.  
 Ciclosporina, prednisona e prednisolona: verifique sua pressão arterial regularmente, antes do início do tratamento e durante o tratamento. Em caso de alteração persistente nas medidas da pressão arterial, converse com seu médico.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 8. RENOVAÇÃO DA CONTINUIDADE DO TRATAMENTO -->
Converse com o farmacêutico do SUS para saber quais os documentos e exames são necessários para continuar recebendo os medicamentos.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 9. EM CASO DE DÚVIDAS -->
Se você tiver qualquer dúvida que não esteja esclarecida neste guia, antes de tomar qualquer atitude procure orientação com o médico ou farmacêutico do SUS.

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: 10. OUTRAS INFORMAÇÕES -->
|_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________<br>_____________________________________________________________________________________|
|---|  
_____________________________________________________________________________________ _____________________________________________________________________________________ _____________________________________________________________________________________  
NOTA: Se, por algum motivo, não usar o(s) medicamento(s), devolva-o(s) à farmácia do SUS onde o(s) recebeu.  
FLUXOGRAMA DE TRATAMENTO DE IMUNOSSUPRESSÃO  
NO TRANSPLANTE HEPÁTICO  
Fluxo Pré-operatório, Intra-operatório e Pós-operatório.  
<!-- Start of picture text -->
Paciente submetido a Transplante Hepatico T<br>I Conforme o Regulamento<br>R 2 5 R = Técnico vigente do Sistema<br>Paciente devera ser atendido em servico especializado} .<br>. . .<br>| integrante do Sistema Nacional de Transplantes | — Nacionalde Transplantes<br>_-<br>Sim Possui critérios Nao<br>de exclusdo?<br>— = Inducao da imunossupressao:<br>Critério de excluséo: |, .<br>v Transplante \|* Exclusao do , ++ TimoglobulinaBasiliximab: (ATG)<br>hepatico auxiliar PCDT astiimal ©<br>S ) * Metilpredinosolona<br>Imunossupressao pés-transplante: EstaSepsisGestante ou apresentaou com sim;<br>Insuficiéncia Renal ou<br>Doenga atrommuney Terapia de Manutencgao<br>Nao em Subgrupos Especificos<br>Sim Ha manifestacées Clinicas, Nao :<br>alteragdes nas Enzimas :<br>Hepaticas Histolégicas de :<br>Rejeigdo Aguda? :<br>Manutencao habitual:<br>Rejeicdo Aguda * Inibidor de calcineurina<br>i * Corticosterdide<br>i * Inibidor de mTOR<br>i * Agentes antimetabolicos<br>Ha manifestacGes Clinicas,<br>Fluxo de Manejo de sim alteragdes nas Enzimas Nao<br>Hepaticas ou Histologicas<br>H de Rejeic¢do do Enxerto?<br>aumentar niveis séricos dos INCs<br>Terapia de Manutengao:<br>. x * Inibidor de calcineurina<br>sim Nao<br>+ Inibidor de mTOR<br>tratamento? * Corticosterdide<br>- Retransplante ou * Agentes antimetabdlicos<br>Cuidados paliativos<br><!-- End of picture text -->  
TRATAMENTO DE REJEIÇÃO PARA O PACIENTE COM TRANSPLANTE HEPÁTICO  
- **Diagnóstico de Rejeição**  
- **Rejeição Rejeição Crônica**  
-  Bolus de corticosteroide – 500 Opção de tratamento com aumento mg a 1g de dos níveis séricos dos INCs. metilprednisolona que pode ou não ser repetido.  
-  Aumento da dose de INCs  MPA ou mTOR como opção para manutenção pósrejeição  
-  Caso paciente for resistente a corticosteroide, existe a opção de administrar timoglobulina: 1,5 mg/kg/dia, durante 3 a 14 dias  
-  Casos de rejeição hiperaguda/aguda mediada por anticorpos, imunossupressão tripla.  
IMUNOSSUPRESSÃO DE MANUTENÇÃO NO TRANSPLANTE HEPÁTICO EM SUBGRUPOS CASOS ESPECIAIS ESPECÍFICOS

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: **Imunossupressão na Diabetes Mellitus** -->
<!-- Start of picture text -->
 Indução com timoglobulina e retardar início de  Preferência por ciclosporina.<br>ICN<br> Indução com basiliximabe e retardar início de<br>ICN<br> Minimizar dose de ICN<br> Opção de associar MPA para reduzir dose de<br>ICN<br> Opção de associar o everolimo (inibidor<br>mTOR) após 30 dia<br>Tolerância<br>Sim Não<br>a MPA?<br>Preferência por dose reduzida  Opção  de  associar  o<br>de ICN associada a MPA everolimo (inibidor mTOR)<br>após 30 dias do transplante<br>para reduzir dose ICN.<br>Imunossupressão em CHC Imunossupressão em Sepsis<br>Imunossupressão habitual, com a opção de  Início mais tardio do INC com manutenção<br>associação de inibidores de mTOR após 30  de níveis séricos baixos.<br>dias do transplante hepático.<br>Imunossupressão em Doença Autoimune Imunossupressão em Gestação<br>Ampliação da imunossupressão basal  Imunossupressão  habitual  com<br>para a imunossupressão tripla, com  corticosteroide  e  INCs.Se  houver<br>doses mais altas de ICN, corticosteroide,  necessidade  de  associar  um  agente<br>MPA ou azatioprina ou EVR. antimetabólico,  a  azatioprina  é  mais<br>indicada nesses casos, já que os MPAs<br>apresentam efeitos teratogênicos.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: FLUXOGRAMA DE DISPENSAÇÃO DE IMUNOSSUPRESSOR NOTRANSPLANTE DE FÍGADOEM ADULTOS -->
NOTA: É obrigatório preencher a Ficha Farmacoterapêutica  
<!-- Start of picture text -->
CID-10: 294.4 - Figado transplantado<br>EXAMES<br>Y Laudo médico comprovandoo transplante de figado<br>v Bidpsia (nos casos de rejeigao aguda)<br>FARMACOS e Doses Medianas + Intervalo<br>Paciente solicita o ¥ Ciclosporina: 200 mg/2x dia + 150 mg/2 Xdia<br>medicamento Tacrolimo: 4mg/ 2X diat3 mg/2X dia ,<br>v Azatioprina: 125 mg/ 1X diat 25 mg/ 1X dia<br>v Prednisona: 5 a 40 mg/ 1X diano 12. Ano;<br>. v Apés: 5a 10 mg/ 1X dia apés<br>NaoHy Possui LME correta- * . 0 12. ano<br>mentedemais preenchida edocumentos?. Sim vYY Sirolimo:MicofenolatoMicofenolato2  demg/1X de mofetila: sédio: diat 5401mg/1Xdia1g mg/ / 2 X 2X diat diat 500 180 mg/ mg/2 2X dia X dia<br>v Everolimo: 1,5 mg/ 2X diat 1 mg/2X dia<br>||_GEKetealieOrientar o | Nao doseCID-10,estoexames de acordoe sim<br>como preconizado pelo<br>A Realizar Entrevista<br>Encaminhar © . PCDT?<br>Pagienis a farmacoterapéutica inicial<br>médico assistente como farmacéutico<br>EXAMESv ExamesNECESSARIOSbioquimicosA  Peridiocidade:APARA MONITORAMENTOcritério médico sim deferido?ProcessoGeet Nao<br>Para Azatioprina e Micofenolato:<br>v Hemograma, plaquetas Peridiocidade: Apds inicio /<br>¥ TGO e TP Peridiocidade:do tratamento Ae acritério cada aumentomédico  de dose Orientarpaciente o N&oedicomentete dispensar o<br>Para Ciclosporina: justifi a<br>Y Nivel sérico de Ciclosporina, Potdssio e Creatinina \ Justificar ao paciente<br>Peridiocidade: A critério médico<br>Para Tacrolimo:<br>v Nivel sérico de Tacrolimo, Glicose e Creatinina Dispensacao a cada més de<br>Peridiocidade: A critério médico<br>. tratamento<br>Para ou cada 3 meses:<br>Y NivelSirolimoséricoou, Hemograma, Everolimo:: Proteintiria e Creatinina Entrevistaista f.emmacoteopeuuca—<br>Peridiocidade: A critério médico de monitoramento<br>\<br>Paciente apresentou alteracdes<br>Sim nos exames nao compativel com Nao<br>0 curso do tratamento ou ha<br>Dispensare= solicitar Parecer eventos adversos significativos? Dispensar<br>do médico assistente<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Imunosupressão no Transplante Hépático em Adultos | secao: METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Foi realizada uma busca na base de dados PubMed/Medline utilizando os termos ((Immunosuppression OR Immunosuppressions OR Therapy, Anti-Rejection OR Anti-Rejection Therapy OR Anti Rejection Therapy OR Anti-Rejection Therapies OR Therapy, Antirejection OR Antirejection Therapies OR Antirejection Therapy) AND (Liver Transplantation OR Transplantation, Liver OR Liver Transplantations OR Transplantations, Liver OR Transplantation, Hepatic OR Grafting, Liver OR Graftings, Liver OR Liver Grafting OR Liver Graftings OR Hepatic Transplantation OR Hepatic Transplantations OR Transplantations, Hepatic)) restringindo-se para estudos em humanos e adultos (maiores de 18 anos). Foram encontrados 8.123 artigos.  
Na base de dados Embase, utilizando-se os termos ‘liver transplantation’/exp AND ‘drug therapy’/exp e restringindo-se para estudos em humanos, com os filtros ([cochrane review]/lim OR [meta analysis]/lim OR [randomized controlled trial]/lim OR [systematic review]/lim), foram encontrados 411 estudos. Destes, 70 estavam relacionados ao uso de imunossupressores no transplante hepático em adulto. Na base de dados Cochrane, utilizando-se o termo “liver transplantation”, foi localizada 1 revisão sistemática sobre o uso de imunossupressores no transplante hepático em adulto.  
Entre eles, com os filtros “Metanalysis” e “Randomized Controlled Trial”, após remoção das duplicatas e até 20 de setembro de 2015, houve 127 revisões sistemáticas, 31 meta-análises e 208 estudos clínicos randomizados controlados que estavam relacionados ao uso de imunossupressores no transplante hepático em adulto.  
Além disso, foram incluídos a revisão das referências das publicações citadas, outros artigos e livros-texto de Gastroenterologia, Hepatologia e Transplante Hepático.

---

