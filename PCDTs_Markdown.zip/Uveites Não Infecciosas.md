<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 13, DE 11 DE SETEMBRO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas das Uveítes não Infecciosas.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre as uveítes não infecciosas no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com estas doenças;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 458/2019 e o Relatório de Recomendação n<sup><u>o</u></sup> 469 – Junho de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Uveítes não Infecciosas.  
Parágrafo único. O Protocolo, objeto deste artigo, que contém o conceito geral das uveítes não infecciosas, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-ediretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito</u> Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento das uveítes não infecciosas.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essas doenças em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria n<sup>o</sup> 1.158/SAS/MS, de 18 de novembro de 2015, publicada no Diário Oficial da União nº 221, de 19 de novembro de 2015, seção 1, página 46.  
FRANCISCO DE ASSIS FIGUEIREDO  
DENIZAR VIANNA  
ANEXO  
PROTOCOLOS CLÍNICOS E DIRETRIZES TERAPÊUTICAS UVEÍTES NÃO INFECCIOSAS

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **1. INTRODUÇÃO** -->
A uveíte é definida como a inflamação da úvea, camada vascular média dos olhos que pode ser dividida em anterior (íris), intermediária (corpo ciliar e vítreo) e posterior (vítreo, retina, coroide e esclera)<sup>(1)</sup> . Uveítes com acometimento de mais de uma porção uveal são chamadas de pan-uveítes, apresentando geralmente acometimento bilateral<sup>(1)</sup> . Essa doença ocular inflamatória é causa importante de cegueira (acuidade visual com melhor correção menor que 20/400 ou 0,05) e de baixa visão (acuidade visual com melhor correção entre 20/70 ou 0,3 e 20/200 ou 0,1) no mundo todo<sup>(2)</sup> . A incidência anual de uveíte varia de acordo com o país, situando-se entre 17 e 52 casos por 100 mil habitantes, com uma prevalência de 38 a 714 casos por 100 mil habitantes<sup>(3, 4)</sup> . Um estudo de 2016 demonstrou prevalência de uveíte não infecciosa de 121 casos por 100 mil habitantes em adultos e 29 casos a cada 100 mil habitantes em crianças em população dos Estados Unidos da América<sup>(5)</sup> . As uveítes são responsáveis por cerca de 10% dos casos de deficiência visual no ocidente, e aproximadamente 35% dos pacientes relatam baixa visão ou cegueira<sup>(3, 4)</sup> .  
Seu aspecto é bastante variável, podendo abranger desde inflamação ocular primária até uveíte associada à doença inflamatória sistêmica. As uveítes podem ser divididas entre uveítes infecciosas, nas quais o patógeno responsável é identificado e o paciente é submetido ao tratamento antimicrobiano específico, e uveítes não infecciosas. As principais causas de uveítes não infecciosas estão listadas a seguir:

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Uveítes oculares primárias:** -->
- Coriorretinopatia de _birdshot_  
- Coroidite serpiginosa  
- Coroidite multifocal com pan-uveíte  
- Esclerites  
- Oftalmia simpática  
- Síndrome dos pontos brancos  
- Uveíte intermediária idiopática ( _pars planitis_ )  
- Vasculite retiniana idiopática.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Uveítes associadas às doenças sistêmicas:** -->
- Artrite psoríaca  
- Doença de Behçet  
- Doença inflamatória intestinal  
- Esclerose múltipla  
- Granulomatose de Wegener  
- Lúpus eritematoso sistêmico  
- Poliarterite nodosa  
- Policondrite recorrente  
- Sarcoidose  
- Síndrome de Sjögren  
- Síndrome de Vogt-Koyanagi-Harada  
- Artrite idiopática juvenil  
- Espondilite anquilosante  
- Espondiloartropatias indiferenciadas  
- Artrite reumatoide.  
As doenças sistêmicas têm um acometimento ocular variável. A doença de Behçet, por exemplo, cursa com uveíte difusa e vasculite retiniana em cerca de 70% dos casos, sendo a uveíte um dos critérios maiores para o diagnóstico clínico dessa doença e podendo ser a manifestação inicial, muitas vezes precedendo os demais sintomas por vários anos<sup>(6)</sup> . Da mesma forma, a sarcoidose manifesta-se como uveíte em 20% a 50% dos pacientes, e a esclerose múltipla apresenta-se com neurite óptica em até 50% dos casos, vasculite retiniana em 10% a 39% e uveíte isolada em 1% a 16% dos casos. Doenças que cursam com presença do anticorpo anticitoplasma de neutrófilos (ANCA), como a granulomatose de Wegener e a poliarterite nodosa, desenvolvem uveíte em 10% a 20% dos casos; além disso, a primeira pode causar manifestações oculares em até 90% destes<sup>(6)</sup> . Doenças do tecido conjuntivo, entre elas a lúpus eritematoso sistêmico (LES), cursam com vasculite em 10% a 30% dos casos. Em menor escala, pacientes com doença inflamatória intestinal e artrite psoríaca apresentam uveíte em torno de 10% dos casos; já a síndrome de Sjögren em casos raros pode evoluir com uveíte posterior. A doença de Vogt-Koyanagi-Harada é uma síndrome úveo-meníngea multissistêmica caracterizada por resposta autoimune dirigida aos antígenos melanocíticos dos olhos, da pele, do sistema nervoso central e do sistema auditivo. A manifestação ocular é a uveíte difusa bilateral com edema de disco óptico, descolamento seroso da retina neurossensorial, defeito na impermeabilidade do epitélio pigmentar da retina, com discreta ou nenhuma vitreíte<sup>(6)</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos das uveítes não infecciosas. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- H30.1 Inflamação coriorretiniana disseminada  
- H30.2 Ciclite posterior  
- H30.8 Outras inflamações coriorretinianas  
- H20.1 Iridociclite crônica  
- H15.0 Esclerite

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **3. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que apresentarem diagnóstico confirmado de uveíte não infecciosa, de evolução crônica e grave, com risco potencial de perda funcional.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **confirmado de uveíte não infecciosa, deve haver:** -->
- Indicação de uso crônico em longo prazo de glicocorticoide sistêmico (superior a 3 meses);  
- Falha na terapêutica com glicocorticoide sistêmico em monoterapia;  
- Toxicidade aguda, crônica presente ou presumida ou contraindicação ao uso de glicocorticoide por qualquer via de administração;  
- Diagnóstico de uveítes sabidamente graves, como doença de Behçet, coroidite serpiginosa e vasculites retinianas idiopáticas; ou  
- Uveíte de caráter agressivo e com rápido comprometimento funcional.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **não infecciosa, deve haver:** -->
- Tratamento com imunossupressor prévio, não corticoide, descontinuado por falta de efetividade, intolerância ou toxicidade;  
- Contraindicação aos imunossupressores não corticoides e não biológicos; ou  
- Doença de Behçet com uveíte posterior bilateral ativa com alto risco de cegueira ou associada com doença sistêmica em atividade.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **4. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que apresentarem as seguintes condições:  
- Suspeita clínica ou confirmação de infecção intraocular;  
- Contraindicação ou intolerância aos medicamentos especificados;  
- Suspeita ou confirmação de infecção sistêmica em atividade ou com risco de reativação, sem profilaxia adequada, mediante o uso de imunossupressores;  
- Contraindicação, hipersensibilidade ou intolerância a algum dos medicamentos.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **a. Diagnóstico Clínico** -->
O diagnóstico de uveíte não infecciosa é baseado em critérios clínicos, de acordo com o exame oftalmológico completo, com medida da acuidade visual, avaliação dos reflexos pupilares, biomicroscopia de segmento anterior, tonometria e fundoscopia direta e indireta. O exame oftalmológico clínico deve identificar as alterações oculares compatíveis com o quadro de uveíte, como: celularidade no humor aquoso e vítreo; precipitados ceráticos; nódulos e áreas de atrofia iriana; aumento ou diminuição da pressão intraocular; hiperemia conjuntival, episcleral ou escleral; opacificação do cristalino; presença de lesão focal ou difusa de retina ou coroide; edema retiniano; embainhamento vascular; isquemia retiniana e trombose retiniana. Devido ao grande número de doenças que podem manifestar o quadro de uveíte, a partir da suspeita clínica devem ser realizados exames complementares visando à identificação do fator etiológico<sup>(4, 7, 8)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **b. Diagnóstico laboratorial e de imagem** -->
A partir do quadro clínico de uveíte, é obrigatória a exclusão de causas infecciosas e neoplásicas.  
Exames complementares, como angiografia fluoresceínica (retinografia fluorescente binocular), ecografia ocular (ultrassonografia de globo ocular / órbita (monocular)) e mediadores de inflamação sistêmica, são úteis para quantificar o grau de acometimento inflamatório.  
Avaliação sistêmica clínica, tipagem de imunocomplexos, como o HLA-B27, punção lombar e exames de imagem, como tomografia computadorizada, radiografia, ressonância nuclear magnética e cintilografia, podem ser necessários na investigação complementar de doenças sistêmicas  
associadas, exclusão de etiologias infecciosas e síndromes de mascaramento. Uma vez que o quadro clínico é compatível com os exames inflamatórios e que etiologias infecciosas e neoplásicas são excluídas, o diagnóstico de uveíte não infecciosa pode ser estabelecido<sup>(4, 7, 8)</sup> .  
Uveítes sabidamente mais graves, tais como doença de Behçet, coroidite serpiginosa e granulomatose com poliangeíte, devem receber tratamento mais agressivo desde as fases iniciais da doença, havendo necessidade de imunossupressão precoce. O diagnóstico da doença de Behçet é clínico e deve ser baseado em critérios adequados (presentes nas publicações _International Study Group for Behçet Disease_ , _International Clinical Criteria for Behçet Disease_<sup>(9)</sup> ou _Behçet’s Disease Research Committee of Japan_<sup>(10)</sup> ). A presença de uveíte ou vasculite retiniana associada a úlceras orais ou genitais são os principais critérios diagnósticos. A presença adicional de pseudofoliculite, vasculite de sistema nervoso central e teste de patergia positivo reforçam o diagnóstico. A coroidite serpiginosa, por exemplo, é diagnosticada pela detecção das lesões na fundoscopia e na angiografia fluoresceínica, que revelam padrão serpiginoso. Já a granulomatose com poliangeíte tem manifestações oculares variáveis, como uveíte, esclerite, vasculite retiniana e comprometimento orbitário. A presença adicional de comprometimento pulmonar e de via aérea superior são critérios utilizados para o diagnóstico, bem como a presença do anticorpo anticitoplasma de neutrófilo (cANCA)<sup>(11)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Gestantes e mulheres em idade fértil** -->
Os glicocorticoides apresentam um risco teórico de insuficiência placentária e um risco conhecido de baixo peso em recém-nascidos. Recomenda-se uso da menor dose possível, além de cuidado especial durante o primeiro trimestre da gestação. Não existem estudos definitivos sobre o efeito dos demais imunossupressores durante a gestação, portanto seu uso deve ser feito com cautela, principalmente no período supracitado, sempre considerando o risco-benefício do uso do medicamento e utilizando a menor dose necessária para o controle da doença. Há consenso entre especialistas de que glicocorticoides, azatioprina e ciclosporina são opções viáveis para uso durante a gravidez nos casos de doença moderada ou grave. Os pacientes devem ser esclarecidos quanto aos riscos de gestação na vigência do tratamento, sendo indicado mais de um método anticoncepcional durante o período, principalmente para os usuários de azatioprina. O risco gestacional pelo uso de medicamentos é descrito da seguinte forma<sup>(12-14)</sup> :  
- Prednisona, metilprednisolona e ciclosporina: risco C. Estudos em animais têm demonstrado efeitos teratogênicos sobre o feto e não existem estudos em mulheres; ou não existem estudos disponíveis em mulheres, nem em animais. São medicamentos que só  
devem ser administrados se o benefício esperado para a mãe justificar o risco potencial para o feto.  
- Azatioprina: risco D. Existem claras evidências de risco teratogênico, mas os benefícios acarretados com o uso podem torná-los aceitáveis.  
- Adalimumabe: risco B. Não há estudos adequados em mulheres (em experimentos animais não foram encontrados riscos).

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Nutrizes** -->
Inexistem estudos definitivos sobre o risco de amamentação durante o uso de imunossupressores. Considerando fatores como a passagem através do leite materno, os medicamentos são classificados como compatíveis, não recomendados e contraindicados na amamentação. A prednisona é o único classificado como compatível com a amamentação. Imunossupressores de diferentes classes têm passagem desconhecida pelo leite materno, estando no grupo dos não recomendados<sup>(15)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Crianças** -->
Em crianças, o glicocorticoide sistêmico apresenta os mesmos efeitos adversos causados em adultos, principalmente relacionados ao uso crônico. Além disso, é observado retardo do crescimento em crianças usuárias de corticosteroide. Entretanto, estudos de imunossupressão em crianças não demonstraram risco aumentado<sup>(16)</sup> , em relação ao adulto, pelo uso do medicamento. Determinados efeitos adversos, como a nefrotoxicidade, parecem ser mais leves em crianças. O ajuste da dose dos medicamentos deve ser realizado em crianças de acordo com o peso ou superfície corporal<sup>(4, 7)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Hepatopatas** -->
A azatioprina apresenta maior risco de hepatotoxicidade, estando indicado uso cauteloso do medicamento em hepatopatas. Estudos sugerem a realização de exames sorológicos para hepatite B e C, avaliação funcional hepática e abstinência alcoólica em usuários de azatioprina<sup>(4, 7)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Nefropatas** -->
Vários imunossupressores apresentam excreção renal, estando indicado controle de função renal periódica. A nefrotoxicidade é um dos principais efeitos adversos da ciclosporina, sendo necessária cautela na prescrição<sup>(4, 7)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Cardiopatas** -->
O uso de ciclosporina apresenta como efeito adverso a hipertensão arterial sistêmica, devendo ser prescrito com cautela para pacientes cardiopatas<sup>(4, 7)</sup> . O uso de adalimumabe, por sua vez, pode  
piorar quadros de insuficiência cardíaca, sendo contraindicado em pacientes com tal doença de classe III ou IV<sup>(17)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Neoplasias malignas** -->
A inibição do fator de necrose tumoral (TNF) representa um fator de risco para formação de doenças oncológicas, como tumores sólidos, hematológicos e linfoproliferativos<sup>(17, 18)</sup> . As neoplasias cutâneas estão associadas ao uso de medicamentos biológicos anti-TNF, sendo o carcinoma basocelular o mais frequente, e linfomas podem surgir durante o curso de terapia biológica<sup>(17)</sup> . Antes da prescrição do adalimumabe, está indicado rastreamento adequado de fatores de risco para neoplasias. Ademais, durante o tratamento com anti-TNF, estão indicadas avaliações clínicas de rastreio para malignidades. O adalimumabe deve ser evitado em pacientes com histórico de malignidade tratada nos últimos cinco anos ou em pacientes submetidos a tratamentos com agentes alquilantes por aumentar o risco de tumores sólidos e doenças linfoproliferativas<sup>(17, 19)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Doença desmielinizante** -->
A utilização de adalimumabe é contraindicada para pacientes com doença neurológica desmielinizante ativa ou em remissão, como esclerose múltipla e neuropatia periférica desmielinizante<sup>(17, 20, 21)</sup> . No caso de pacientes em tratamento com adalimumabe que manifestem sintomas de doença desmielinizante, indica-se a suspensão do medicamento e substituição da imunossupressão<sup>(17)</sup> . É indicado, ainda, rastreio adequado para doença desmielinizante previamente ao uso de anti-TNF, o qual deverá ser utilizado com cautela em pacientes com fatores de risco para doença desmielinizante<sup>(17, 20, 21)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Tuberculose** -->
O uso do adalimumabe em pacientes com a forma de infecção latente por tuberculose (ILTB) pode precipitar infecção localizada ou disseminada com alto potencial de gravidade<sup>(17, 18)</sup> . O rastreio da forma latente é obrigatório para todo paciente com indicação de tratamento com anti-TNF. Na evidência de tuberculose latente está indicada quimioprofilaxia conforme preconizado no Manual de recomendações para o Controle da Tuberculose no Brasil – MS<sup>(22)</sup> e, após este período, iniciar a terapêutica com adalimumabe<sup>(17, 18, 23)</sup> . Nos casos de tuberculose durante o tratamento com adalimumabe ou outros medicamentos imunossupressores, está indicada a suspensão imediata e início de tratamento adequado para tuberculose<sup>(24)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Vacinas** -->
Imunizações devem ser recomendadas conforme o Programa Nacional de Imunizações. Pacientes imunossuprimidos por medicamentos podem realizar vacinas derivadas de microorganismos mortos, sendo contraindicado o uso de agentes vivos ou atenuados em pacientes usuários de imunossupressores ou glicocorticoides em dose imunossupressora<sup>(25)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **7. TRATAMENTO** -->
O tratamento das uveítes não infecciosas é baseado na busca da homeostase imunológica do paciente. Procura-se, com a terapia, a supressão da reatividade imune aberrante e a manutenção da integridade do sistema de defesa do hospedeiro durante o maior tempo possível. A principal classe de medicamentos para atingir esses objetivos são os glicocorticoides, representados pela prednisona<sup>(7)</sup> . As desvantagens do uso desta classe são os efeitos adversos locais – como aumento da pressão intraocular e catarata – e sistêmicos – como osteoporose, síndrome de Cushing, diabete melito, hipertensão arterial sistêmica, necrose asséptica de cabeça de fêmur e outros<sup>(7)</sup> . Além dos efeitos adversos, eventualmente não ocorre controle adequado da doença com o uso isolado do medicamento. Medicamentos imunossupressores de diferentes classes apresentam um papel importante no controle de uveítes não infecciosas, servindo como redutores da dose ou poupadores de glicocorticoides e adjuvantes no controle inflamatório.  
Imunossupressores estão indicados principalmente para pacientes com as seguintes condições<sup>(4, 7)</sup> :  
- Falha de resposta ao glicocorticoide sistêmico em monoterapia;  
- Necessidade de dose de glicocorticoide sistêmico com toxicidade intolerável para o controle da doença;  
- Indicação de uso crônico em longo prazo de glicocorticoides sistêmicos;  
- Uveíte de caráter agressivo e com rápido comprometimento funcional.  
Geralmente, medicamentos imunossupressores apresentam efeito terapêutico pleno após algumas semanas de uso, motivo pelo qual o tratamento é iniciado simultaneamente ao glicocorticoide sistêmico, que tem sua dose progressivamente reduzida ou descontinuada após a estabilização da doença. Diversos estudos mostraram a eficácia e segurança dos variados imunossupressores no tratamento de doença ocular inflamatória<sup>(4, 7)</sup> .  
Há inúmeros estudos reforçando o uso de inibidores das células T ou inibidores da calcineurina, representados pela ciclosporina, no tratamento de uveítes não infecciosas. Ensaios clínicos randomizados demonstraram eficácia superior da ciclosporina sobre o uso isolado de glicocorticoide, colchicina, placebo e clorambucil no controle de uveítes diversas, inclusive doença  
de Behçet<sup>(26-30)</sup> . A associação de ciclosporina e glicocorticoide obteve resultados ainda melhores no controle da inflamação ocular<sup>(31)</sup> . Estudos de coorte, séries de casos não controladas e artigos de revisão também apontam para a eficácia da ciclosporina em uveítes refratárias, coroidite multifocal, uveíte em crianças, coriorretinopatia de _birdshot_ , doença de Behçet, oftalmia simpática, coroidite serpiginosa e síndrome de Vogt-Koyanagi-Harada<sup>(32-40)</sup> .  
Antimetabólitos, representados pela azatioprina, também se mostram eficazes no controle de uveítes não infecciosas. Um ensaio clínico randomizado em pacientes com doença de Behçet demonstrou eficácia da azatioprina na redução da incidência de doença ocular e no acometimento do segundo olho, bem como controle da uveíte com redução do número de episódios de hipópio<sup>(41)</sup> . Outro estudo, do tipo coorte e realizado em 1997 com acompanhamento médio de oito anos, mostrou eficácia da azatioprina no controle da diversos tipos de uveíte<sup>(42)</sup> . Séries de casos e estudos não controlados colaboram para a evidência de benefício no uso de azatioprina em pacientes com uveíte refratária, coroidite serpiginosa, coroidite multifocal, doença de Behçet, síndrome de Vogt-KoyanagiHarada, e _Pars Planitis_ , fazendo referência de sucesso no uso de azatioprina em monoterapia ou associada a ciclosporina ou glicocorticoide<sup>(4, 37, 43, 44)</sup> .  
Imunossupressores biológicos antagonistas do fator de necrose tumoral alfa (anti-TNF), representados pelo adalimumabe, apresentam eficácia no controle adicional de uveítes refratárias aos tratamentos com glicocorticoides sistêmicos, bem como com imunossupressores não biológicos. Um ensaio clínico randomizado, realizado em pacientes com uveíte intermediária, posterior e pan-uveíte não infecciosas, demonstrou menor risco de reativação da uveíte e comprometimento visual nos usuários do adalimumabe em comparação ao placebo<sup>(45)</sup> .  
A incorporação do medicamento adalimumabe foi recomendada pela CONITEC para o tratamento da uveíte não infecciosa ativa, conforme o Relatório de Recomendação nº 394 - Outubro de 2018<sup>(46)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Fármacos** -->
- Azatioprina: comprimidos de 50 mg  
- Ciclosporina: cápsulas de 10 mg, 25 mg, 50 mg e 100 mg; solução oral 100 mg/mL  
- Prednisona: comprimidos de 5 mg e 20 mg  
- Metilprednisolona: pó para solução injetável 500 mg  
- Adalimumabe: solução injetável 40mg

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Esquemas de administração** -->
- Azatioprina: entre 1 mg e 3 mg/kg/dia, por via oral; dose máxima de 4 mg/kg/dia  
- Ciclosporina: 2 mg a 5 mg/kg/dia, dividido em duas administrações por via oral; dose máxima de 7 mg/kg/dia  
- Prednisona: de 1 mg a 2 mg/kg/dia, via oral  
- Metilprednisolona: 1.000 mg/dose, por via endovenosa por três a cinco dias  
- Adalimumabe: dose inicial de 80 mg, por via subcutânea, seguida de doses de 40 mg administradas em semanas alternadas a partir da semana seguinte à dose inicial.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Tempo de tratamento – Critérios de interrupção** -->
A grande variabilidade de apresentações e etiologias das uveítes posteriores não infecciosas não permite o estabelecimento de tempo padrão de tratamento, sendo necessária uma constante reavaliação da doença e do quadro ocular. A resposta ao tratamento é o principal fator que define o tempo de uso de cada medicamento<sup>(4, 7)</sup> . Em pacientes com doença aguda, um tratamento de três a seis semanas com glicocorticoide sistêmico por via oral pode ser suficiente para a melhora do quadro ocular. Uveítes agudas sabidamente mais graves, como síndrome de Vogt-Koyanagi-Harada, doença de Behçet, coroidite serpiginosa e vasculites retinianas idiopáticas, frequentemente necessitam de doses maiores de glicocorticoides, podendo-se optar pela administração endovenosa de metilprednisolona por três a cinco dias, seguida de prednisona via oral associada ou não a imunossupressores de acordo com a resposta ocular. Em pacientes com doença crônica, o esquema inicial de corticoide é seguido por redução gradual e manutenção com doses menores, associadas ou não a outros imunossupressores<sup>(7)</sup> . Uma vez que o tratamento com imunossupressores tenha sido iniciado, estes são usualmente mantidos por um período de 6 a 24 meses; posteriormente, as doses são reduzidas lentamente, com pequenos decréscimos a cada quatro a seis semanas, sempre observando a atividade inflamatória ocular. Alguns pacientes necessitam de imunossupressores indefinidamente<sup>(4, 7)</sup> . Após o início do tratamento com imunossupressores como azatioprina ou ciclosporina é necessário observação da resposta terapêutica por pelo menos 3 semanas com a dose adequada antes de definir a necessidade de substituição do imunossupressor, considerando que a ação completa do medicamento ocorre geralmente após 20-30 dias do início. Em casos de uveítes graves a manutenção do corticoide sistêmico, bem como sua redução gradual, deve ser realizada após o controle clínico e com tempo suficiente para o que o imunossupressor já esteja com efeito sobre o sistema imune do paciente. A partir de 3 semanas de tratamento com imunossupressor em monoterapia, e havendo reativação significativa da uveíte, poderá ser considerado substituição ou adição de outro imunossupressor.<sup>(7)</sup> .  
A interrupção do tratamento é definida pelo controle adequado da inflamação ocular de forma individualizada, pela instalação de efeitos adversos intoleráveis específicos de cada medicamento, ou em casos de indicação de intervenção cirúrgica eletiva de grande porte ou tratamentos dentários com  
abcessos. A suspensão transitória dos imunossupressores visa a diminuir o risco de infecção pósoperatória. Assim, sugere-se a suspensão do adalimumabe quatro semanas antes do procedimento cirúrgico. Contudo, a relação risco-benefício deve ser individualizada na decisão sobre a suspensão da medicação imunossupressora e, em casos de manutenção do medicamento no período perioperatório, deverá ocorrer atenção especial para a ocorrência de infecções<sup>(8)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **Benefícios esperados** -->
- Resolução do episódio de inflamação aguda;  
- Prevenção ou minimização de sequelas estruturais e funcionais secundárias à inflamação ocular;  
- Prevenção ou redução do número de recaídas de uveítes crônicas ou recorrentes;  
- Manutenção ou melhora da acuidade visual.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **8. MONITORIZAÇÃO** -->
Pacientes em uso de glicocorticoide via oral por mais de três meses devem ter a pressão arterial e glicemia medidas mensalmente, e os níveis de sódio e potássio a cada 60 dias. Durante o período de uso da corticoterapia, recomendam-se medidas para a redução do risco de perda óssea, conforme preconizado no Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Osteoporose, do Ministério da Saúde (MS). Exercícios físicos regulares e alimentação adequada colaboram no controle do ganho de peso. Para esses paciente, é necessária a profilaxia de parasitoses e a realização de reação intradérmica de Mantoux para avaliação de contato com _Mycobacterium tuberculosis_ para decisão sobre a quimioprofilaxia ou tratamento de tuberculose<sup>(4)</sup> .  
No caso de pacientes com indicação de pulsoterapia com metilprednisolona, deve ser realizada glicemia capilar antes e após a infusão do medicamento para avaliação do perfil glicêmico. Sua pressão arterial sistêmica também deve ser verificada a cada 30 minutos durante a infusão; se o paciente apresentar pressão arterial sistólica acima de 180 mmHg ou diastólica 120 mmHg, recomenda-se interromper a infusão e reavaliar as condições clínicas. Devem ser observados sintomas de psicose durante a infusão e, caso ocorram, suspender a infusão para reavaliar as condições clínicas. No primeiro dia da pulsoterapia, os pacientes devem utilizar profilaticamente ivermectina 12 mg em dose oral única ou albendazol 400 mg em dose oral diária durante cinco dias<sup>(4)</sup> .  
Usuários de ciclosporina devem controlar a pressão arterial e os níveis de creatinina e ureia séricos a cada duas semanas nos primeiros três meses de uso e, após, mensalmente. Sódio, potássio, ácido úrico, triglicerídeos, colesterol total, colesterol HDL e transaminases/aminotransferases hepáticas devem ser acompanhados trimestralmente. A dose subsequente a ser administrada requer  
ajustes individuais, com objetivo de obter o máximo efeito imunossupressor com o mínimo de toxicidade. Pacientes que apresentarem alteração relevante dos controles clínicos ou laboratoriais devem ter a dose de ciclosporina reduzida em 25% a 50% da dose inicial. Se ainda permanecerem com alterações, está indicada a suspensão do medicamento<sup>(4)</sup> . Os principais efeitos adversos dos imunossupressores inibidores de células T são toxicidade renal, hipertensão arterial, intolerância gastrointestinal, hipertricose, hiperplasia de gengiva, mialgia, tremor, parestesias, hiperuricemia e desequilíbrio hidroeletrolítico<sup>(4)</sup> .  
Pacientes em tratamento com azatioprina devem realizar hemograma com contagem de plaquetas e controle das transaminases/aminotransferases hepáticas a cada um a três meses. A ocorrência de hepatotoxicidade, caracterizada por elevação de 1,5 vez o valor normal máximo de transaminases/aminotransferases hepáticas, indica necessidade de redução de 50 mg/dia com nova aferição após duas semanas. Na ausência de resposta, o uso do medicamento deve ser descontinuado<sup>(4)</sup> . Os principais efeitos adversos dos imunossupressores antimetabólitos são cansaço, intolerância gastrointestinal, hepatotoxicidade, supressão de medula óssea, pneumonia intersticial, infecções oportunistas e neoplasia de pele não melanocítica<sup>(47)</sup> . Uma coorte comparativa entre os imunossupressores antimetabólitos sugere que os efeitos adversos são mais frequentes com o uso de azatioprina<sup>(48)</sup> .  
Pacientes em tratamento com adalimumabe devem realizar hemograma completo e controle de transaminases/aminotransferases em períodos de um a três meses após o início do tratamento. Em caso de anemia, leucopenia ou trombocitopenia acentuadas, a dose deve ser reduzida em 25% a 50%, e interrompida se as alterações persistirem. Elevação de transaminases/aminotransferases de 1 a 3 vezes superior ao limite superior da normalidade (LSN) indica redução da dose entre 25% e 50%, enquanto que elevação de transaminases/aminotransferases entre 3 e 5 vezes o LSN indica suspensão do tratamento até a redução das transaminases/aminotransferases para 1 a 3 vezes o LSN, reiniciando com metade da dose. Elevação de transaminases/aminotransferases acima de 5 vezes o LSN indica suspensão do tratamento.  
Alguns medicamentos recomendados para o tratamento das uveítes não infecciosas podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
Antes do início do uso de **adalimumabe** e com objetivo de realizar o planejamento terapêutico adequado, deve-se considerar as seguintes condutas:  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
- Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares  
- devem ser solicitados. A radiografia simples de tórax deve ser realizada para excluir a possibilidade de TB ativa.  
- Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado  
proteico purificado – PPD) ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
- Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
- Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de **adalimumabe** após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, à critério da equipe de saúde assistente, o início de uso de **adalimumabe** pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
Para fins de acompanhamento, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
- Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
- Para que o uso do **adalimumabe** não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com **adalimumabe** devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com **adalimumabe** devem manter o monitoramento com o IGRA.  
- Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
- Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
- Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **9. ACOMPANHAMENTO PÓS-TRATAMENTO** -->
A grande variabilidade de apresentações e etiologias das uveítes não infecciosas não permite o estabelecimento de tempo padrão de tratamento, sendo necessária constante reavaliação da doença e do quadro ocular. A resposta ao tratamento e a incidência de efeitos adversos é o principal fator que define o tempo de tratamento necessário com cada medicamento. A periodicidade das consultas de revisão deve ser estipulada de forma personalizada para cada paciente, de acordo com a atividade da doença ocular e efeitos adversos do tratamento. É recomendável realizar reavaliação trimestral, com exames de controle adequados para cada medicamento, nos casos de doença em remissão e ausência  
de efeitos adversos. Após um período entre 12 e 24 meses de remissão da doença ocular, poderá ser considerada a redução da dose ou eventual suspensão do tratamento, porém haverá casos em que o tratamento deverá ser mantido por período superior ao de 24 meses ou reiniciado em caso de recidiva da doença<sup>(8)</sup> .

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de fármaco.  
Recomenda-se que o tratamento da uveíte seja realizado em serviços especializados, para fins de diagnóstico e de seguimento adequados, e que contemplem equipes multiprofissionais para acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige familiaridade com manifestações clínicas próprias, o médico responsável pelo tratamento deve ter experiência e treinamento em uveítes.  
Pacientes com diagnóstico de uveíte associada à doença sistêmica, em diversas situações, serão tratados de forma multidisciplinar por médicos de diferentes especialidades. Sugere-se avaliação completa de tratamentos prévios e atuais antes da prescrição dos imunossupressores para evitar duplicidade de prescrição ou utilização de medicamentos previamente com baixa resposta, intolerância ou efeitos adversos importantes. A comunicação efetiva e trabalho em conjunto das diferentes equipes de tratamento é importante nas situações de doenças com acometimento de múltiplos sistemas no mesmo paciente. Casos em que os pacientes já estão em uso do adalimumabe, devem ser avaliados em conjunto para a pertinência do uso para uveíte. Impedir a soma novamente do adalimumabe na prescrição e ocorrer sua duplicação na dispensação. Diante do paciente já ter adquirido o adalimumabe para outra situação cl  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
As secretarias de saúde de estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNDASAF), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **11. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **12. REFERÊNCIAS** -->
1. Jabs DA, Nussenblatt RB, Rosenbaum JT. Standardization of uveitis nomenclature for reporting clinical data. Results of the First International Workshop. Am J Ophthalmol. 2005;140(3):509-16. 2. **CID** - **10** Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde. 10a rev. São Paulo: Universidade de São Paulo; 1997. vol.1. 5. Organização Mundial da Saúde. 3. Wakefield D, Chang JH. Epidemiology of uveitis. Int Ophthalmol Clin. 2005;45(2):1-13. 4. Kim EC, Foster CS. Immunomodulatory therapy for the treatment of ocular inflammatory disease: evidence-based medicine recommendations for use. Int Ophthalmol Clin. 2006;46(2):14164.  
5. Thorne JE, Suhler E, Skup M, Tari S, Macaulay D, Chao J, et al. Prevalence of Noninfectious Uveitis in the United States: A Claims-Based Analysis. JAMA Ophthalmol. 2016;134(11):1237-45. 6. Diaz-Valle D, Mendez R, Arriola P, Cuina R, Arino M. [Non-infectious systemic diseases and uveitis]. An Sist Sanit Navar. 2008;31 Suppl 3:97-110.  
7. Jabs DA, Rosenbaum JT, Foster CS, Holland GN, Jaffe GJ, Louie JS, et al. Guidelines for the use of immunosuppressive drugs in patients with ocular inflammatory disorders: recommendations of an expert panel. Am J Ophthalmol. 2000;130(4):492-513.  
8. Dick AD, Rosenbaum JT, Al-Dhibi HA, Belfort R, Jr., Brezin AP, Chee SP, et al. Guidance on Noncorticosteroid Systemic Immunomodulatory Therapy in Noninfectious Uveitis: Fundamentals Of Care for UveitiS (FOCUS) Initiative. Ophthalmology. 2018;125(5):757-73.  
9. Criteria for diagnosis of Behcet's disease. International Study Group for Behcet's Disease. Lancet. 1990;335(8697):1078-80.  
10. Suzuki Kurokawa M, Suzuki N. Behcet's disease. Clin Exp Med. 2004;4(1):10-20.  
11. Kallenberg CG. Pathophysiology of ANCA-associated small vessel vasculitis. Curr Rheumatol Rep. 2010;12(6):399-405.  
12. Roldi N, Pogian L, Ribeiro T. Tratamento da doença de Crohn durante a gravidez. Rev Soc Bras Clin Med. 2017 jan-mar;15(1):68-72.  
13. Levy R. O Uso de Drogas Anti-Reumáticas na Gravidez. Rev Bras Reumatol. 2005 mai/jun;45(3):124-33.  
14. Bermas, BL. Safety of antiinflammatory and immunosuppressive drugs in rheumatic diseases during  
pregnancy and lactation. 2019 [cited 06 mar 2019.]. In: UpToDate [Internet]. [cited 06 mar 2019.]. Available from: Disponível em: https://www.uptodate.com/contents/safety-of-antiinflammatory- <u>and-immunosuppressive-drugs-in-rheumatic-diseases-during-pregnancy-and-</u>  
<u>lactation?search=Safety%20of%20antiinflammatory%20and%20immunosuppressive%20drugs%20 in%20rheumatic%20diseases%20during%20pregnancy%20and%20lactation&source=search_result &selectedTitle=1~150&usage_type=default&display_rank=1.</u>  
15. Chaves R, Lamounier J. Uso de medicamentos durante a lactação. J Pediatr (Rio J). 2004;80(S189-S198).  
16. Suehiro R, Aikawa N, Carvalho J, Silva C. Terapia com agentes biológicos na criança e no adolescente. Revista Paulista de Pediatria. 2010;28(2):227-36.  
17. Mota LM, Cruz BA, Brenol CV, Pollak DF, Pinheiro Gda R, Laurindo IM, et al. [Safe use of biological therapies for the treatment of rheumatoid arthritis and spondyloarthritides]. Rev Bras Reumatol. 2015;55(3):281-309.  
18. Yonekura CL, Oliveira RDR, Titton DC, Ranza R, Ranzolin A, Hayata AL, et al. Incidence of tuberculosis among patients with rheumatoid arthritis using TNF blockers in Brazil: data from the Brazilian Registry of Biological Therapies in Rheumatic Diseases (Registro Brasileiro de  
Monitoracao de Terapias Biologicas - BiobadaBrasil). Rev Bras Reumatol Engl Ed. 2017;57 Suppl 2:477-83.  
19. LaMattina KC, Goldstein DA. Adalimumab for the treatment of uveitis. Expert Rev Clin Immunol. 2017;13(3):181-8.  
20. Kemanetzoglou E, Andreadou E. CNS Demyelination with TNF-alpha Blockers. Curr Neurol Neurosci Rep. 2017;17(4):36.  
21. Antonazzo IC, Raschi E, Forcesi E, Riise T, Bjornevik K, Baldin E, et al. Multiple sclerosis as an adverse drug reaction: clues from the FDA Adverse Event Reporting System. Expert Opin Drug Saf. 2018;17(9):869-74.  
22. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. Manual de Recomendações para o Controle da Tuberculose no Brasil / Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Vigilância das Doenças Transmissíveis. – Brasília: Ministério da Saúde, 2018.  
23. Brunelli J, Bonfiglioli K, Silva C, Kozu K, Goldenstein-Schainberg C, Bonfa E, et al. Rastreamento da infecção latente por tuberculose em pacientes com artrite idiopática juvenil previamente à terapia anti-TNF em um país de alto risco para tuberculose. Rev Bras Reumatol. 2017;57(5):392-6.  
24. Wang X, Wong SH, Wang XS, Tang W, Liu CQ, Niamul G, et al. Risk of tuberculosis in patients with immune-mediated diseases on biological therapies: a population-based study in a tuberculosis endemic region. Rheumatology (Oxford). 2018.  
25. da Luz K, de Souza D, Ciconelli R. Vacinação em pacientes imunossuprimidos e com doenças reumatológicas autoimunes. Rev Bras Reumatol. 2007;47(2):106-13.  
26. Nussenblatt RB, Palestine AG, Chan CC, Stevens G, Jr., Mellow SD, Green SB. Randomized, double-masked study of cyclosporine compared to prednisolone in the treatment of endogenous uveitis. Am J Ophthalmol. 1991;112(2):138-46.  
27. Masuda K, Nakajima A, Urayama A, Nakae K, Kogure M, Inaba G. Double-masked trial of cyclosporin versus colchicine and long-term open study of cyclosporin in Behcet's disease. Lancet. 1989;1(8647):1093-6.  
28. Vitale AT, Rodriguez A, Foster CS. Low-dose cyclosporin A therapy in treating chronic, noninfectious uveitis. Ophthalmology. 1996;103(3):365-73; discussion 73-4.  
29. de Vries J, Baarsma GS, Zaal MJ, Boen-Tan TN, Rothova A, Buitenhuis HJ, et al. Cyclosporin in the treatment of severe chronic idiopathic uveitis. Br J Ophthalmol. 1990;74(6):344-9.  
30. BenEzra D, Cohen E, Chajek T, Friedman G, Pizanti S, de Courten C, et al. Evaluation of conventional therapy versus cyclosporine A in Behcet's syndrome. Transplant Proc. 1988;20(3 Suppl 4):136-43.  
31. Whitcup SM, Salvo EC, Jr., Nussenblatt RB. Combined cyclosporine and corticosteroid therapy for sight-threatening uveitis in Behcet's disease. Am J Ophthalmol. 1994;118(1):39-45.  
32. Jap A, Chee SP. Immunosuppressive therapy for ocular diseases. Curr Opin Ophthalmol. 2008;19(6):535-40.  
33. Michel SS, Ekong A, Baltatzis S, Foster CS. Multifocal choroiditis and panuveitis: immunomodulatory therapy. Ophthalmology. 2002;109(2):378-83.  
34. Vitale AT, Rodriguez A, Foster CS. Low-dose cyclosporine therapy in the treatment of birdshot retinochoroidopathy. Ophthalmology. 1994;101(5):822-31.  
35. Mendes D, Correia M, Barbedo M, Vaio T, Mota M, Goncalves O, et al. Behcet's disease--a contemporary review. J Autoimmun. 2009;32(3-4):178-88.  
36. Chan CC, Roberge RG, Whitcup SM, Nussenblatt RB. 32 cases of sympathetic ophthalmia. A retrospective study at the National Eye Institute, Bethesda, Md., from 1982 to 1992. Arch Ophthalmol. 1995;113(5):597-600.  
37. Fang W, Yang P. Vogt-koyanagi-harada syndrome. Curr Eye Res. 2008;33(7):517-23.  
38. Murphy CC, Greiner K, Plskova J, Duncan L, Frost NA, Forrester JV, et al. Cyclosporine vs tacrolimus therapy for posterior and intermediate uveitis. Arch Ophthalmol. 2005;123(5):634-41.  
39. Ozyazgan Y, Yurdakul S, Yazici H, Tuzun B, Iscimen A, Tuzun Y, et al. Low dose cyclosporin A versus pulsed cyclophosphamide in Behcet's syndrome: a single masked trial. Br J Ophthalmol. 1992;76(4):241-3.  
40. Akpek EK, Baltatzis S, Yang J, Foster CS. Long-term immunosuppressive treatment of serpiginous choroiditis. Ocul Immunol Inflamm. 2001;9(3):153-67.  
41. Yazici H, Pazarli H, Barnes CG, Tuzun Y, Ozyazgan Y, Silman A, et al. A controlled trial of azathioprine in Behcet's syndrome. N Engl J Med. 1990;322(5):281-5.  
42. Hamuryudan V, Ozyazgan Y, Hizli N, Mat C, Yurdakul S, Tuzun Y, et al. Azathioprine in Behcet's syndrome: effects on long-term prognosis. Arthritis Rheum. 1997;40(4):769-74.  
43. Pasadhika S, Kempen JH, Newcomb CW, Liesegang TL, Pujari SS, Rosenbaum JT, et al. Azathioprine for ocular inflammatory diseases. Am J Ophthalmol. 2009;148(4):500-9.e2.  
44. Pacheco PA, Taylor SR, Cuchacovich MT, Diaz GV. Azathioprine in the management of autoimmune uveitis. Ocul Immunol Inflamm. 2008;16(4):161-5.  
45. Jaffe GJ, Dick AD, Brezin AP, Nguyen QD, Thorne JE, Kestelyn P, et al. Adalimumab in Patients with Active Noninfectious Uveitis. N Engl J Med. 2016;375(10):932-43.  
46. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Coordenação de Avaliação e Monitoramento De Tecnologias. Adalimumabe para o tratamento da uveíte não  
infecciosa intermediária, posterior e panuveítes. Relatório de recomendação nº 394. Disponível em:http://conitec.gov.br/images/Relatorios/2018/Relatorio_Adalimumabe_Uveite.pdf ed. Brasília/DF.2018.  
47. Singh G, Fries JF, Spitz P, Williams CA. Toxic effects of azathioprine in rheumatoid arthritis. A national post-marketing perspective. Arthritis Rheum. 1989;32(7):837-43.  
48. Galor A, Jabs DA, Leder HA, Kedhar SR, Dunn JP, Peters GB, 3rd, et al. Comparison of antimetabolite drugs as corticosteroid-sparing therapy for noninfectious ocular inflammation. Ophthalmology. 2008;115(10):1826-32.

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **UVEÍTES NÃO INFECCIOSAS** -->
<!-- Start of picture text -->
Diagnóstico : clínico  Critérios de inclusão:<br>através de exame  Paciente com uveíte não  ü Indicação de uso crônico em longo prazo<br>oftalmológico completo e  infecciosa de evolução crônica e  de glicocorticoide sistêmico (superior a 3<br>exclusão de causas  grave, com risco potencial de  meses);<br>infecciosas e neoplásicas perda funcional  ü Falha terapêutica com glicocorticoide<br>sistêmico em monoterapia;<br>ü Toxicidade aguda, crônica presente ou<br>presumida ou contraindicação ao uso de<br>glicocorticoide por qualquer via de<br>administração;<br>Possui critério de  ü Diagnóstico de uveítes sabidamente<br>inclusão para  graves, como doença de Behçet, coroidite<br>tratamento com  serpiginosa e vasculites retinianas<br>idiopáticas;  ou<br>Não imunossupressores?<br>Sim ü Uveíte de caráter agressivo e com rápido<br>comprometimento funcional<br>=i<br>Tratamento com  Sim  Possui algum critério  Critérios de exclusão:<br>de exclusão?  ü Suspeita clínica ou<br>prednisona 1 confirmação de infecção<br>intraocular;<br>Exclusão do  ü Contraindicação ou<br>intolerância aos<br>PCDT  Não medicamentos<br>Houve  especificados;<br>Sim resposta  Não  ü Suspeita ou confirmação de<br>terapêutica?  infecção sistêmica em<br>atividade ou com risco de<br>reativação, sem profilaxia<br>adequada, mediante o uso<br>Manter tratamento  Tratamento com  de imunossupressores;<br>por 3 meses  ü Contraindicação,<br>ciclosporina e/ou<br>hipersensibilidade ou<br>Necessidade de  azatioprina 2 intolerância a algum dos<br>Não manutenção do  Sim  Não  medicamentos.<br>tratamento?<br>Falha após 3<br>Possui critérios de  semanas ou<br>Interromper o  intolerância?<br>tratamento e  inclusão para  Sim<br>avaliar o paciente  tratamento com<br>adalimumabe?<br>Critérios de inclusão: Sim<br>ü Pacientes adultos;  e Substituir por ciclosporina<br>ü Contraindicação aos ou azatioprina, conforme<br>imunossupressores;  uso anterior<br>ou<br>ü Doença de Behçet<br>as com uveíte posterior<br>bilateral ativa com  Tratamento  Houve  Não<br>alto risco de cegueira  com   N ão resposta<br>ou associada com  adalimumabe 3 terapêutica?<br>doença sistêmica em<br>atividade.<br>Manter tratamento por 6 a<br>i.=<br>24 meses, com diminuição<br>gradual da dose<br>1 Uveítes agudas sabidamente mais graves, como síndrome de Vogt-Koyanagi-Harada, doença de Behçet, coroidite serpiginosa e vasculites retinianas<br>idiopáticas podem necessitar de doses maiores de glicocorticoides, podendo-se optar pela administração endovenosa de metilprednisolona por três a<br>cinco dias, seguida de prednisona via oral associada ou não a imunossupressores de acordo com a resposta ocular.<br>2 Glicocorticoide sistêmico, quando associado ao imunossupressor, deve ter sua dose progressivamente reduzida ou descontinuada após a<br>estabilização da doença<br>3 Devem ser observados as contraindicações e precauções no uso do adalimumabe descritos no item 5. Casos especiais.<br>Poo<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ADALIMUMABE, AZATIOPRINA, CICLOSPORINA, METILPREDNISOLONA E PREDNISONA.  
Eu, <u>(nome do(a) paciente),</u> declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do(s) medicamento(s) **prednisona, metilprednisolona, azatioprina, ciclosporina e adalimumabe** , indicados para o tratamento das **uveítes não infecciosas** .  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
(nome do médico  
que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora da inflamação aguda;  
- prevenção ou minimização dos problemas relacionados à inflamação nos olhos;  
- prevenção ou redução do número de recaídas de uveítes crônicas ou recorrentes;  
- manutenção ou melhora da qualidade da visão.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Prednisona e adalimumabe: medicamento classificado como fator de risco B para gestantes (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido realizados ou não foram adequados; o medicamento deve ser prescrito com cautela). Caso engravide, devo avisar imediatamente ao meu médico.  
- Metilprednisolona e ciclosporina: medicamentos classificados como fator de risco C para gestantes (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o feto  
não pode ser descartado, mas um benefício potencial pode ser maior que os riscos). Caso engravide, devo avisar imediatamente ao meu médico.  
- Azatioprina: medicamento classificado como fator de risco D para gestantes (há riscos para o feto durante a gravidez, porém o benefício pode ser maior que o risco). O uso deve ser discutido com seu médico;  
- Efeitos adversos da prednisona e metilprednisolona: retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose, problemas de estômago (úlceras estomacais), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabetes melito.  
- Efeitos adversos da azatioprina: diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, perda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar e pressão baixa.  
- Efeitos adversos da ciclosporina: problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, aumento do crescimento da gengiva, aumento do colesterol e triglicerídeos, formigamentos, dor no peito, batimentos rápidos do coração (taquicardia), convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas.  
- Efeitos adversos de adalimumabe: reações no local da aplicação, como dor e coceiras, dor de cabeça, tosse, náusea, vômitos, febre, cansaço e alteração na pressão arterial. Reações mais graves: infecções oportunistas fúngicas e bacterianas, como tuberculose, histoplasmose, aspergilose e nocardiose, podendo, em casos raros, ser fatal.  
- Contraindicação em casos de hipersensibilidade (alergia) ao(s) fármaco(s) ou aos componentes da fórmula.  
Estou ciente de que este(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvê-lo(s) caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei ser assistido, inclusive em caso de eu desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as secretarias de saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. ( ) Sim ( ) Não.  
Meu tratamento constará do seguinte medicamento:  
- ( ) prednisona  
- ( ) metilprednisolona  
- ( ) azatioprina  
- ( ) ciclosporina  
- ( ) adalimumabe.  
Local: Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal:

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: Assinatura do paciente ou do responsável legal -->
|Médico Responsável:|CRM:|UF:|
|---|---|---|  
Assinatura e carimbo do médico  
Data:  
**Nota 1:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**Nota 2:** A administração endovenosa de metilprednisolona é compatível com o procedimento 0303020016 - Pulsoterapia I (por aplicação) da tabela de procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Uveites Não Infecciosas | secao: Alteração pós publicação -->
Depois da sua publicação, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Uveítes não infecciosas, pela necessidade de atualizar o item de Monitoramento da infecção por tuberculose ativa e rastreio da infecção por tuberculose latente (ILTB), de modo a harmonizar a orientação em todos os PCDT que preconizam o uso de medicamentos modificadores do curso da doença (MMCD) biológicos ou MMCD sintéticos-alvo específico.  
O tema foi apresentado como informe à 125ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 20 de maio de 2025, e também à 141ª Reunião Ordinária da Conitec, em junho de 2025.  
Com a presença de seis membros do Grupo Elaborador, sendo três dos quais especialistas e três metodologistas, além de três representantes do Comitê Gestor, uma reunião presencial para revisão do escopo do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida. Todos os componentes do Grupo Elaborador preencheram o formulário de Declaração de Conflito de Interesses, que foi enviado ao Ministério da Saúde como parte dos resultados.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria nº 1158, de 18 de novembro de 2015) e na estrutura definida pela Portaria n° 375, de 10 de novembro de 2009. O principal tópico deste PCDT foi a inclusão do medicamento adalimumabe, incorporado conforme Relatório de Recomendação n° 394, de outubro de 2018<sup>(46)</sup> .  
Cada seção foi detalhada e discutida entre o Grupo Elaborador com o objetivo de revisar as condutas clínicas e identificar as tecnologias que seriam consideradas nas recomendações. O grupo de especialistas optou por revisar, modificar e definir o formato do texto das principais seções durante a reunião.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. As seções de diagnóstico, elegibilidade (critérios de inclusão e exclusão), casos especiais, tratamento e monitorização seriam atualizadas com  
informações sobre o adalimumabe, e as demais seções também seriam revisadas e atualizadas.  
Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais e diretrizes atuais que consolidam a prática clínica e a atualizar as referências descritas no PCDT vigente.

---

