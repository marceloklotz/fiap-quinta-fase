<!-- METADADOS: doenca: Doença Celíaca | secao: Geral -->
<!-- Start of picture text -->
qa:<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 8, DE 23 DE JUNHO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença Celíaca.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A  SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhe confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Doença Celíaca no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 848/2023 e o Relatório de Recomendação n<sup><u>o</u></sup> 851/2023 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas da Doença Celíaca.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Doença Celíaca, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimentos ou medicamentos preconizados para o tratamento da Doença Celíaca.  
Art. 3º Os gestores Estaduais, Distrital e Municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS nº 1.149, de 11 de novembro de 2015, publicada no Diário Oficial da União (DOU) nº 216, de 12 de novembro de 2015, seção 1, página 65.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
1  
**ANEXO**

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A doença celíaca é uma doença crônica do intestino delgado desencadeada pela resposta imunomediada ao glúten (principal fração proteica presente no trigo, centeio e cevada), em indivíduos com predisposição genética<sup>1–6</sup> . A maioria dos indivíduos afetados possui genes que codificam o antígeno leucocitário humano (HLA) DQ2 ou DQ8, que promovem o reconhecimento de peptídeos específicos do glúten por células T CD4+<sup>6–8</sup> .  
A princípio, ocorre uma resposta mediada por células T ao glúten presente na dieta, o que desencadeia uma grande produção de citocinas inflamatórias, com danos à mucosa intestinal. Em seguida, ocorre a ativação de células B, o que provoca um aumento da produção de anticorpos anti-transglutaminase tecidual da classe Imunoglobulina A (tTG IgA)<sup>7,8</sup> . Estes, juntamente com os anticorpos anti-endomísio (EMA) e antigliadina deaminada podem ser encontrados no soro do paciente<sup>8,9</sup> .  
A soroprevalência global da doença celíaca é de 1,4% (IC 95%: 1,1% a 1,7%), e a prevalência obtida pela confirmação por biópsia é de 0,7% (IC 95%: 0,5% a 0,9%)<sup>10</sup> . Na América do Sul, a soroprevalência é de 1,3% (IC 95%: 0,5% a 2,5%)<sup>10</sup> , e a prevalência observada pela comprovação por biópsia é de 0,3% (IC 95%: 0,1% a 0,6%)<sup>10</sup> . No Brasil, um estudo realizado na cidade de São Paulo, estimou a prevalência da doença celíaca entre 1 a cada 214 e 1 a cada 286 indivíduos<sup>11,12</sup> , e em Ribeirão Preto, a estimativa foi de 1 a cada 273 indivíduos<sup>13</sup> . No sul do país, a prevalência foi de 1 a cada 417 indivíduos<sup>14</sup> , em Brasília, 1 a cada 681 indivíduos<sup>15</sup> , e em Recife foram observados 9 casos em um grupo de 1074 indivíduos<sup>16</sup> . Contudo, acredita-se que a doença é subdiagnosticada na população brasileira<sup>3</sup> .  
Existem evidências de que a prevalência da doença celíaca também varia com a idade. Uma revisão sistemática e metaanálise mostrou uma prevalência da doença celíaca em crianças de 0,9% (IC 95%: 0,6% a 1,3%) e, de 0,5% (IC 95%: 0,3% a 0,8%) em adultos. A prevalência da doença celíaca confirmada por biópsia foi cerca de duas vezes mais comum em crianças do  
que em adultos<sup>10</sup> . No entanto, essas diferenças podem ser explicadas por dificuldades de diagnóstico em adultos, como mascaramento dos sintomas de má absorção dos alimentos com glúten, presença de outras doenças e complicações na fase adulta, ou prevalência da doença celíaca não clássica, e alterações histopatológicas ao longo dos anos, com menores concentrações de tTG IgA e, consequentemente, grau da lesão histológica menos pronunciada na fase adulta, de forma que as biópsias de mucosa duodenal podem não identificar atrofia de vilosidades<sup>17–20</sup> .  
Apesar da relevância dessa condição, sugere-se que para cada diagnóstico de doença celíaca a partir de sintomas clínicos, existem de três a sete pacientes oligo ou assintomáticos sem diagnóstico<sup>12,21</sup> . A doença celíaca possui um amplo espectro de manifestações clínicas semelhantes a um distúrbio multissistêmico, mas é caracterizada pela presença de lesão do intestino delgado<sup>6</sup> . Dessa forma, devem ser também observados os fatores de risco para a doença, que incluem hábitos alimentares<sup>12,22</sup> e predisposição genética (por exemplo, parentes de primeiro grau de celíacos, com doenças autoimunes e de síndromes genéticas) 14, infecções gastrointestinais na infância 12,23, e agravos autoimunes, como diabete melito tipo I, deficiência de IgA e síndrome de Down<sup>24,25</sup> , além de câncer<sup>17,26</sup> .  
O diagnóstico precoce e adequada assistência à saúde, pode reduzir em 29% os custos de tratamento do paciente no ano seguinte ao diagnóstico e 39% em seu custo médico total<sup>27–29</sup> . A identificação de fatores de risco, da doença em seu estágio inicial e o encaminhamento ágil e adequado dos pacientes para atendimento especializado dão à Atenção Primária à Saúde um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
O presente PCDT visa a estabelecer os critérios diagnósticos, terapêuticos e de acompanhamento dos indivíduos com doença celíaca no âmbito do Sistema Único de Saúde (SUS). O público alvo deste PCDT é de indivíduos com doença celíaca,  
2  
assim como seus responsáveis (em caso de menor de idade), profissionais da saúde envolvidos na assistência e gerenciamento desses pacientes na atenção primária e na atenção especializada à saúde, como médicos de família e comunidade, pediatras, geneticistas, nutricionistas, e outros profissionais da saúde que participam desse acompanhamento, além de gestores em s aúde pública e privada, com vistas a subsidiar as decisões clínicas e otimizar a qualidade do cuidado ofertado a esses pacientes.

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
- K90.0 Doença Celíaca

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Os profissionais de saúde (especialmente, médicos de família e comunidade, pediatras, gastroenterologistas, nutrólogos, dermatologias) devem estar atentos às apresentações clínicas intestinais e extraintestinais da doença celíaca e observar os fatores de risco (principalmente em caso de parentes de primeiro grau, doenças autoimunes e síndromes genéticas) para realização do diagnóstico da doença. Contudo, testes sorológicos acompanhados de biópsia duodenal ainda são essenciais para confirmar o diagnóstico de doença celíaca<sup>4</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Três formas de apresentação clínica da doença celíaca são conhecidas: intestinal (forma clássica ou típica), extraintestinal (forma não clássica ou atípica) e assintomática<sup>30–33</sup> . As formas intestinal e extraintestinal não são autoexcludentes, logo um mesmo indivíduo pode manifestar achados compatíveis com ambas as apresentações.

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A forma intestinal, também chamada de forma clássica ou típica, caracteriza-se pela presença de dor abdominal sem causa aparente, flatulência, vômitos, constipação e diarreia crônica, geralmente acompanhada de distensão abdominal e perda de apetite e peso. Além disso, pode haver diminuição do tecido celular subcutâneo, atrofia da musculatura glútea, falta de apetite, alteração de humor com irritabilidade ou apatia, vômitos e anemia. Essa forma clínica pode ter evolução grave, conhecida como crise celíaca. Frequentemente desencadeada por infecção, a crise celíaca ocorre quando há retardo do diagnóstico e do tratamento, particularmente, entre o primeiro e o segundo ano de vida. Essa complicação, potencialmente fatal, é caracterizad a por diarreia com desidratação hipotônica grave, distensão abdominal por hipopotassemia e desnutrição grave, além de outras manifestações, como hemorragia e tetania<sup>1,2,6,9,34</sup> . Outras consequências da crise celíaca são disfunção neurológica e renal, acidose metabólica, hipoalbuminemia, alterações nos eletrólitos e perda de peso significante<sup>33</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A forma extraintestinal, também chamada de forma não clássica ou atípica, caracteriza-se por quadro monossintomático ou oligossintomático, em que as manifestações digestivas estão ausentes ou, se presentes, ocupam um segundo plano (por exemplo, dor abdominal, distensão abdominal, flatulência, e menos frequentemente diarreia ou constipação). Manifestações extraintestinais da doença celíaca incluem a dermatite herpetiforme, baixa estatura, osteoporose, anemia por deficiência de ferro, artrite, dor de cabeça, fadiga, anormalidades hepáticas, mialgia, eventos adversos na gravidez, ciclo menstrual irregular, esterilidade, defeitos no esmalte do dente, osteoporose, entre outros<sup>1,24,25,34,35</sup> .  
3  
Entre as manifestações extraintestinais, a dermatite herpetiforme, é uma doença crônica e recorrente, secundária ao glúten, cuja principal manifestação clínica é a ocorrência de rash papulovesicular pruriginoso. Caracteriza-se pela presença de depósitos de IgA no topo das papilas dérmicas e se manifesta principalmente na superfície extensora dos membros, nádegas e região escapular. Pacientes com doença celíaca e dermatite herpetiforme podem ter a mesma relação com antígenos de histocompatibilidade e presença de IgA circulante contra autoantígenos da transglutaminase<sup>36,37</sup> .  
Ademais, os pacientes podem apresentar atraso puberal, ataxia, epilepsia, neuropatia periférica, manifestações neuropsiquiátricas e alopecia<sup>38</sup> . Fadiga crônica, comumente relatada por pacientes, ainda não foi adequadamente es tudada e pode ocorrer como consequência da anemia<sup>39</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A forma assintomática se caracteriza por alterações sorológicas e histológicas da mucosa do intestino delgado, compatíveis com doença celíaca, na ausência de manifestações clínicas<sup>40</sup> . A maioria desses casos é identificada por meio de programas de rastreamento da população geral. Alguns pacientes não apresentam achados clínicos que respondam à retirada de glúten da dieta. Entretanto, pessoas com a forma assintomática têm qualidade de vida reduzida, e sintomas menores como fadiga, deficiência de ferro, distúrbios de comportamento, entre outros sinais<sup>1,2,6,34</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Os indivíduos que devem ser rastreados para a presença de doença celíaca compreendem aqueles que apresentam manifestações clínicas intestinais, extraintestinais (i.e., sintomáticos), as quais foram descritas anteriormente (ver seção 3.1), ou que pertencem aos grupos de risco para doença celíaca descritos a seguir:  
- Parentes de primeiro grau (sintomáticos ou assintomáticos) de pessoas com doença celíaca<sup>41</sup> ;  
 Pacientes com doenças autoimunes, como diabete melito tipo 1<sup>42</sup> , tireoidite autoimune, deficiência seletiva de IgA, hepatite autoimune, cirrose biliar primária, colangite esclerosante, Síndrome de Sjögren, colestase autoimune e miocardite autoimune;  
- Indivíduos com síndromes genéticas: de Down, Turner ou Williams<sup>33</sup> ; e  
- Indivíduos com síndrome do intestino irritável<sup>43</sup> .  
Além disso, indivíduos sem a manifestação clínica característica da doença celíaca e que apresentem as condições descritas no Quadro 1 também possuem indicação de rastreamento sorológico para doença celíaca.  
**Quadro 1** . Indicações de rastreamento sorológico para doença celíaca.  
|**Indivíduos com indicação de rastreamento sorológico, sem a manifestação clínica característica da doença celíaca**|
|---|
|Síndrome do intestino irritável|
|Elevação não explicada de transaminases|
|Sintomas crônicos do trato gastrointestinal sem história familiar de doença celíaca e sem história pessoal de doença autoimun e|
|Colite microscópica|
|Tireoidite de Hashimoto ou doença de Graves|
|Osteopenia ou osteoporose|
|Ataxia não explicada ou neuropatia periférica|
|Úlceras aftosas recorrentes ou defeitos no esmalte dentário|
|Infertilidade, abortamentos recorrentes, menarca tardia ou menopausa precoce|  
4  
|**Indivíduos com indicação de rastreamento sorológico, sem a manifestação clínica característica da doença celíaca**|
|---|
|Síndrome da fadiga crônica|
|Pancreatite aguda ou crônica após exclusão de outras causas conhecidas|
|Epilepsia; cefaleia incluindo enxaqueca; transtornos de humor; déficit de atenção|
|Hipoesplenismo ou asplenia funcional|
|Psoríase|
|Síndrome de Down ou de Turner|
|Hemossiderose pulmonar|
|Nefropatia por Imunoglobulina A|  
_Fonte: Adaptada de Al-Toma, et al. 2019_<sup>~~33~~</sup> _._  
É importante que o rastreamento sorológico e o diagnóstico sejam feitos em vigência de dieta com glúten<sup>44,45</sup> . Os marcadores sorológicos são úteis para identificar os indivíduos que deverão ser submetidos à confirmação diagnóstica por meio de endoscopia digestiva alta e biópsia de intestino delgado, bem como para acompanhamento do paciente com doença celíaca e para detectar não adesão à dieta isenta de glúten<sup>6,46</sup> .  
O teste sorológico mais sensível (92% a 100% em crianças e adultos) e específico (91% a 100%)<sup>47,48</sup> que pode ser solicitado nos pacientes com suspeita clínica é o tTG IgA<sup>49,50</sup> . Apesar da sensibilidade e especificidade do rastreamento da doença celíaca em indivíduos assintomáticos com tTG IgA serem relativamente elevadas (71% e 93%, respectivamente), não foram identificados estudos que avaliaram os efeitos do rastreamento sobre morbidade, mortalidade ou qualidade de vida na população sem sintomas<sup>51</sup> .  
Se a dosagem do tTG IgA for negativa (não reagente), o acometimento do indivíduo pela doença celíaca é pouco provável. Contudo, a deficiência de IgA é responsável por resultados falsos negativos dos testes sorológicos de tTG IgA (doença celíaca soronegativa).  
Por este motivo, indica-se como testes diagnósticos iniciais da doença celíaca a dosagem sérica simultânea do tTG IgA e da IgA total<sup>6,44,45</sup> . Adicionalmente, em crianças com até 2 anos de idade e com suspeita de doença celíaca, recomenda-se o rastreamento sorológico por meio da dosagem de anticorpos antigliadina deaminada (DGP) da classe da Imunoglobulina G (IgG) 6 (Portaria SECTICS/MS nº 10, de 17 de abril de 2023). O teste sorológico de DGP-IgG foi incorporado para essa população, devido à alta acurácia diagnóstica, enquanto para os deficientes de IgA a acurácia diagnóstica foi considerada moderada e de impacto clínico incerto.  
O anticorpo anti-endomísio (EMA) da classe IgA é identificado por meio de imunofluorescência indireta. Apresenta alta sensibilidade em adultos (87% a 89%) e em crianças maiores de dois anos (88% a 100%), e alta especificidade (91% a 100% nas crianças e 99% em adultos)<sup>47,52</sup> . Entretanto, a dosagem do EMA requer o uso de uma técnica mais trabalhosa e onerosa e, por essa razão, não é recomendada<sup>53</sup> . Além disso, o teste de genotipagem HLA-DQ2 e DQ8 para o diagnóstico de doença celíaca em pacientes com fatores de risco não foi incorporado ao SUS, por não fornecer diagnóstico conclusivo e ter elevado impacto orçamentário, não sendo, portanto, recomendado por este Protocolo (Portaria SECTICS/MS nº18, de 27 de abril de 2023).  
Se houver forte suspeita de doença celíaca (Quadro 2), deve-se proceder com biópsia de duodeno por endoscopia digestiva alta (EDA), mesmo se o teste tTG IgA for negativo e a IgA total for normal (doença celíaca soronegativa). Os marcadores sorológicos não substituem o exame histopatológico realizado na peça obtida por biópsia do duodeno para diagnóstico de doença celíaca. Desse modo, conforme rastreamento sorológico, o diagnóstico de doença celíaca deve ser sempre confirmado por exame histológico de biópsia de duodeno por endoscopia digestiva alta<sup>6</sup> . Contudo, segundo diretrizes internacionais, parentes de primeiro grau sintomáticos e geneticamente susceptíveis podem ser dispensados de realizar a biópsia duodenal se apresentarem uma dosagem de tTG IgA 10 vezes acima do limite superior da normalidade e forem positivos para  
5  
EMA, desde que considerado método de dosagem baseado em ELISA (a conduta não é recomendada quando método de quimioluminescência)<sup>41,50,54</sup> .  
A **Figura 2** mostra o fluxograma para o rastreamento e diagnóstico da doença celíaca. Ao receber paciente com manifestações clínicas intestinais ou extraintestinais, de grupos de risco, com indicação para rastreamento ou forte suspeita de doença celíaca, deve-se realizar rastreamento sorológico, cujo teste pode variar conforme a idade. Todos esses pacientes devem realizar as dosagens de tTG IgA e IgA total. Para os indivíduos com resultado de dosagem de tTG-IgA positivo, deve-se proceder com a realização de endoscopia digestiva alta e biópsia.  
Os pacientes menores de dois anos de idade, que apresentem teste de dosagem de tTG-IgA negativo e IgA total normal ou que apresentem teste de dosagem de tTG-IgA negativo e deficiência total de IgA devem ser testados para DPG IgG e, se este resultado for positivo, devem ter o diagnóstico confirmado por endoscopia digestiva alta e biópsia. Caso o resultado do teste de DPG IgG seja negativo, o indivíduo deverá permanecer em vigilância e caso tenha sintomas sugestivos, descartadas outras doenças, deve-se seguir com a indicação de endoscopia com biópsia de intestino delgado (investigação de doença celíaca soronegativa).  
Pacientes maiores de dois anos de idade, que apresentem resultado negativo para tTG-IgA, não têm indicação para realização de DPG-IgG. Se estes pacientes apresentarem resultados negativos para tTG-IgA, o indivíduo deverá permanecer em vigilância e caso tenha sintomas sugestivos, descartadas outras doenças, deve-se seguir com a indicação de endoscopia com biópsia de intestino delgado (investigação de doença celíaca soronegativa).

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A confirmação por biópsia duodenal é o padrão-ouro<sup>51,55</sup> para o diagnóstico correto em crianças e adultos, exceto quando houver contraindicação à EDA (por exemplo, indivíduos com distúrbios de coagulação e gestantes). Deve-se realizar biópsia da mucosa duodenal em: (1) pacientes sintomáticos e sorologia positiva (reagente) ou sintomáticos e sorologia negativa (Não reagente) descartadas outras doenças; (2) pacientes com forte suspeita clínica ( **Quadro 2** ), independente do resultado da sorologia; e (3) indivíduos sem a manifestação clínica característica da doença celíaca com indicação de rastreamento sorológico e resultado do rastreamento sorológico positivo<sup>34</sup> .  
As indicações de biópsia de duodeno, independentemente do resultado de rastreamento sorológico, são descritas no Quadro 2<sup>33</sup> . A realização da EDA em tempo oportuno é fundamental para correta realização do diagnóstico.  
**Quadro 2.** Indicações de endoscopia digestiva alta e biópsia de duodeno mesmo se a sorologia para doença celíaca for negativa<sup>33</sup> .  
|**Sinais ou sintomas**|
|---|
|Diarreia crônica não sanguinolenta|
|Diarreia com má absorção ou associada à perda de peso|
|Anemia por deficiência de ferro na ausência de outras causas|
|Sintomas do trato gastrointestinal com história familiar de doença celíaca|
|Sintomas do trato gastrointestinal em paciente com doença autoimune ou deficiência de Imunoglobulina A|
|Baixa estatura em crianças|
|Dermatite herpetiforme comprovada por biópsia cutânea|
|Ileostomia ou colostomia com alto débito inexplicado|  
Fonte: Al-Toma, et al. 2019<sup>~~33~~</sup> .  
Em relação às biópsias intestinais, para que a interpretação histológica do fragmento seja fidedigna, é fundamental o intercâmbio entre os médicos patologista e endoscopista, responsável direto do paciente, de preferência experiente em  
6  
Gastroenterologia Pediátrica ou Clínica. A orientação quanto ao manuseio do fragmento de biópsia pelo endoscopista e a inclusão correta deste material em parafina pelo histotecnologista são de extrema importância para a avaliação anatomopatológica dos fragmentos biopsiados<sup>56</sup> .  
À endoscopia com luz branca convencional, o duodeno de pacientes com doença celíaca pode apresentar diminuição ou perda das pregas circulares, serrilhamento da mucosa, fissuras proeminentes e mucosa em padrão de mosaico. Contudo, a ausência desses achados não deve impedir a realização da biópsia duodenal quando indicada<sup>57</sup> .  
Os pré-requisitos para realização do exame histológico das biópsias de duodeno por endoscopia digestiva alta<sup>6,44</sup> são:  
- Ao menos seis fragmentos da mucosa intestinal, incluindo dois fragmentos do bulbo duodenal e quatro da segunda  
- porção do duodeno<sup>6,44,58</sup> .  
- Os fragmentos de biópsias devem ser fixados em solução de formalina, sendo os fragmentos do bulbo e segunda porção  
- acondicionadas em frascos separados e com a devida identificação.  
A lesão histológica clássica da doença celíaca consiste em mucosa plana ou quase plana, com criptas alongadas e aumento de mitoses, epitélio superficial cuboide, com vacuolizações, borda estriada borrada, aumento do número de linfócitos intraepiteliais e lâmina própria com denso infiltrado de linfócitos e plasmócitos<sup>56</sup> .  
Inicialmente, observou-se a progressão da lesão da mucosa de intestino delgado na doença celíaca, segundo a Classificação de Marsh de 1992<sup>56</sup> (posteriormente modificada por Oberhuber et al., 1999<sup>59</sup> ), que subdividiram a classificação Tipo 3 de Marsh, e estabeleceram o número de linfócitos intraepiteliais da biopsia, que naquela época localizava-se no jejuno. Com essa modificação proposta, o limite de 40 linfócitos intraepiteliais/100 enterócitos para às biopsias jejunais<sup>55</sup> estaria ultrapassado o limite superior de normalidade de 25 linfócitos intraepiteliais/100 enterócitos para a biópsia de duodeno.  
No sentido de simplificar, padronizar e aumentar a reprodutibilidade do trabalho dos patologistas, foi proposta uma nova versão de classificação histológica da mucosa duodenal<sup>60</sup> , que obteve elevada concordância entre os patologistas<sup>61,62</sup> . Nessa nova versão, a classificação Marsh-Oberhuber era usada como referência para a correspondente Corraza e Villanacci, como segue:  Grau A equivale à tipo 1 e 2 Marsh-Oberhuber; Grau B1 equivale à tipo 3a e 3b Marsh-Oberhuber; e Grau B2 equivale à tipo 3c Marsh-Oberhuber<sup>61</sup> . Contudo, a subdivisão do tipo Marsh 3 proposta por Oberhuber foi contestada por Marsh et al. 2015, uma vez que a microscopia eletrônica revelou que as lesões 3a, 3b e 3c apresentavam o mesmo grau de atrofia<sup>63,64</sup> , e a modificação de Oberhuber foi considerada um acréscimo desnecessário<sup>65</sup> .  
Sendo assim, a histologia da biopsia do intestino delgado, que atualmente é realizada no duodeno, é classificada segundo Marsh (tipo 0, tipo 1, tipo 2 ou tipo 3, sem subdivisão),<sup>56</sup> ou segundo Corraza e Villanacci ( **Figura 1** ).  
**Figura 1. Comparação entre a classificação de Marsh-Oberhuber e a de Corraza e Villanacci.**  
<!-- Start of picture text -->
Marsh-Oberhuber Corraza e Villanacci<br>Tipo 0<br>Tipo 1<br>Grau A<br>Tipo 2<br>Tipo 3a<br>Grau B1<br>Tipo 3<br>Tipo 3b<br>Tipo 3c Grau B2<br><!-- End of picture text -->  
7  
**Legenda** : **Tipo 0:** fragmento sem alterações histológicas (normal) com até 40 linfócitos intraepiteliais a cada 100 células epiteliais da amostra estudada; **Tipo 1** : arquitetura da mucosa é normal e mais de 40 linfócitos intraepiteliais a cada 100 células epiteliais; **Tipo 2** : alargamento das criptas e mais de 40 linfócitos intraepiteliais a cada 100 células epiteliais; **Tipo 3** : algum grau de atrofia das vilosidades, hipertrofia críptica e mais de 40 linfócitos intraepiteliais a cada 100 células epiteliais: **Tipo 3a:** atrofia leve das vilosidades; **Tipo 3b:** atrofia acentuada das vilosidades; **Tipo 3c:** ausência de vilosidades.  
De acordo com essas classificações, o diagnóstico da doença celíaca pelo exame histológico da mucosa duodenal consiste  
na presença de atrofia da vilosidade do intestino delgado associada a aumento da concentração de linfócitos intraepiteliais, que deve ser superior a 25 linfócitos intraepiteliais para cada 100 enterócitos<sup>66</sup> .  
Caso o indivíduo apresente sinais e sintomas altamente característicos de doença celíaca, a sorologia tTG IgA seja positiva (reagente), o IgA seja normal e o exame histopatológico do duodeno seja normal **(Figura 2)** , o resultado da dosagem de tTG IgA pode ser considerado um falso positivo. Neste caso, o exame histopatológico deve ser revisado e, se não houver lesão histológica característica de doença celíaca, deve-se considerar a possibilidade de acometimento não uniforme do duodeno e indicar nova biópsia. Se novamente o padrão histológico não for característico de doença celíaca, a doença é pouco provável<sup>44</sup> .  
**Figura 2.** Fluxograma de rastreamento e diagnóstico de doença celíaca.  
<!-- Start of picture text -->
Individuo com manifestagbes clinicas intestinais ou extraintestinais, ou pertencentes a grupo de risco, ou com forte suspeita de doenca celiaca<br>Dosagem<br>de IgA total e TG-IgA<br>Negativopara {TG-IgA e IgA normalOU Positivo<br>Negative para {TG-lgA e deficiéncia total de IgA (independentementeparado resultado{TG-IgA de IgA)<br>SS <— ——~idade menor EDAduodeno+ biépsiade<br>\. que<br>2 anos?<br>Continuar<br>investigago‘outras doengp a sra Considerarrevisao do exame<br>histolégico,<br>[rete | ‘muito cara teri ticos c aso s intomasde forem DC<br>EDAa + bidpsiaaS de sim sugestivoscanoe“ Sintomase outras,\, Nao |<———{grau‘Sim Apresenta de atrofia algum das Nao Lave<br>ant ay \, vilosidades? —/ ao<br>aes Sim Apresenta algum<br>orvioadee?<br>Nao<br>‘Continuar investigago_<br>para outras doencas<br>~Mesmo se a sorologia for negativa, ha indicagao de bidpsia de duodeno por EDA caso os pacientes apresentem os seguintes sinais e sintomas:<br>diarreia cronica no sanguinolenta; diarreia com ma absorgo ou associada @ perda de peso; anemia por deficiéncia de ferro na auséncia de outras|<br>causas; sintomas do trato gastrointestinal com histéria familiar de doenca celiaca; sintomias do trato gastrointestinal em paciente com doenca|<br>jutoimune ou deficiéncia de Imunoglobulina A; baixa estatura em criancas; dermatite herpetiforme comprovada por bidpsia cuténea; lleostomia ou|<br>colostomiab - Pacientescom comalto algumdébito distirbioinexplicado de coagulacao(Quadro 2); e pacientes gravidas nao devem ser submetidos a endoscopia devido  sedacao.<br><!-- End of picture text -->  
Legenda: **EDA** : endoscopia digestiva alta; **tTG-IgA** : anticorpos anti transglutaminase tecidual da classe Imunoglobulina A; **DPG-IgG** : antigliadina deaminada da Imunoglobulina G  
8  
O diagnóstico de doença celíaca é confirmado quando a sorologia é positiva e a biópsia duodenal tem características histológica seguramente compatíveis com doença celíaca, isto é, linfocitose intraepitelial, hiperplasia das criptas e atrofia das vilosidades, sendo que tais exames foram coletados quando o paciente estava em dieta contendo glúten<sup>44</sup> .  
As exceções para essa regra seriam os pacientes com algum distúrbio de coagulação e pacientes grávidas, que não poderiam ser submetidos à endoscopia por causa da sedação<sup>44</sup> . Nestes casos, devem ser considerados a história clínica, o resultado dos testes sorológicos e a resposta à dieta isenta de glúten (DIG)<sup>49</sup> . Estes fatores também são considerados no diagnóstico com a demonstração de mudanças características da histologia da mucosa intestinal.  
O termo „doença celíaca potencial‟ pode ser utilizado para indivíduos com mucosa normal do intestino delgado que apresentam risco aumentado de desenvolver doença celíaca, conforme indicado pela sorologia positiva para doença celíaca<sup>67</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Devem ser incluídos nesse PCDT todos os indivíduos com suspeita e diagnóstico confirmado de doença celíaca.  
Para a realização do rastreamento e confirmação diagnóstica, devem ser incluídos os indivíduos que apresentarem,  
conforme descrito no item “Rastreamento e diagnóstico”:  
- Manifestações clínicas intestinais, extraintestinais ou que pertencem aos grupos de risco para doença celíaca;  
- Indicação de rastreamento sorológico para doença celíaca, mesmo que assintomáticos;  
- Forte suspeita clínica de doença celíaca, independentemente dos testes de sorologia.

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Pacientes que inicialmente foram rastreados para doença celíaca, mas que não obtiveram confirmação diagnóstica, devem  
ser excluídos do tratamento e monitoramento previstos neste Protocolo.  
Este Protocolo não contempla pacientes com alergia ao trigo e pacientes com sensibilidade ao glúten não celíaca.

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Atualmente, a única abordagem terapêutica comprovadamente eficaz para a doença celíaca é a DIG. Dessa forma, pacientes devem ser orientados a não ingerir alimentos derivados de trigo, cevada e centeio, entre outros, que podem ser contaminados pelo glúten na cadeia produtiva<sup>68</sup> . A orientação inclui que apenas o uso de utensílios de cozinha e aparelhos de cozimento de difícil lavagem sejam separados para evitar a contaminação por glúten<sup>68</sup> .  
Ressalta-se que não há comprovação de que o glúten faça mal a crianças e adultos sem doença celíaca. A retirada do glúten da dieta é uma recomendação somente para pessoas diagnosticadas com doença celíaca ou outra condição relacionada ao glúten<sup>69</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A adesão a uma DIG é o único tratamento disponível atualmente para doença celíaca<sup>70</sup> . Logo, o tratamento consiste na exclusão de alimentos que contenham trigo, centeio e cevada da dieta do paciente por toda sua vida<sup>71</sup> . A dieta é restritiva, difícil e permanente, ocasionando alterações na rotina dos indivíduos e de sua família. Ainda as sim, a adoção da DIG deve ser rigorosa, pois a falta de tratamento pode desencadear um estado de refratariedade ao tratamento<sup>72</sup> .  
9  
Pacientes com doença celíaca devem ser orientados a evitar também alimentos derivados de cereais isentos de glúten e que podem ser contaminados durante a cadeia produtiva dos alimentos, como aveia. Entretanto, cabe destacar que, após o processamento final, a aveia que não foi contaminada por glúten é segura, a não ser para uma pequena porcentagem de pacientes que podem ser sensíveis ao alimento<sup>33</sup> .  
A susceptibilidade de pessoas com doença celíaca à contaminação pelo glúten na alimentação varia de caso a caso<sup>68</sup> .  De acordo com a lei nº 10.674, de 16 de maio de 2003, todos os alimentos industrializados deverão conter em seu rótulo e bula, obrigatoriamente, as inscrições "contém Glúten" ou "não contém Glúten", conforme o caso<sup>73,74</sup> . De uma maneira geral, o risco de contato cruzado pelo glúten é recorrente para pessoas vivendo com doença celíaca e com prejuízos a vida desses pacientes 29,75. A frequência de contato cruzado foi estimada em 13,2% em produtos industriais e em 41,5% em produtos não industriais, o que demostra que produtos industriais com rotulagem “não contém glúten” têm menos contato cruzado do que produtos alimentícios não industrializados<sup>75</sup> . Argumenta-se que legislações e certificação para alimentos sem glúten são importantes para a segurança alimentar de pessoas com doença celíaca<sup>75,76</sup> . No Brasil, os rótulos “contém glúten” e “não contém glúten” são obrigatórios para todos os produtos industrializados<sup>70</sup> .  
Recomenda-se a adoção de cuidado multiprofissional aos indivíduos com doença celíaca<sup>77</sup> . Gastroenterologistas, médicos da família, pediatras ou dermatologistas nos casos de dermatite herpetiforme atuam na definição do diagnóstico e atendimento médico. Além disso, é altamente desejável que haja disponibilidade de nutricionistas com especialidade em doença celíaca para avaliar a possibilidade de deficiências nutricionais e para educação alimentar dos pacientes para a manutenção da DIG<sup>33</sup> . Farmacêuticos podem orientar indivíduos com doença celíaca sobre produtos farmacêuticos sem glúten. Assistente social pode auxiliar na implementação da dieta no trabalho, na escola e nas famílias, enquanto o psicólogo clínico pode ofertar serviços de apoio<sup>78,79</sup> .  
Os pacientes devem ser encorajados a buscar o apoio da comunidade. A adesão a grupos de apoio sobre doença celíaca tem sido associada a uma maior adesão à dieta<sup>80</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Como mencionado, a DIG é restritiva e pode ser bastante desafiadora para o paciente. Um estudo observacional com pacientes pediátricos em São Paulo mostrou que 20% deles não aderiram completamente à DIG. Razões para transgressão são alto custo da DIG<sup>29,81–83</sup> , baixa palatabilidade, falta de disponibilidade de produtos sem glúten, participação de eventos sociais, além de escolha própria<sup>70</sup> e falta de orientação adequada sobre a doença e alimentação<sup>84</sup> .  
O diagnóstico precoce e educação alimentar e nutricional contínua, com modelo de cuidado multidisciplinar, são essenciais para promover adesão à DIG<sup>24</sup> . As limitações que a DIG impõe podem diminuir não somente a adesão ao tratamento, mas também a satisfação entre indivíduos com doença celíaca<sup>70</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Embora a adesão à DIG melhore a absorção de nutrientes, a dieta em si pode ter limitações em valor nutricional. Deficiências nutricionais decorrentes da má-absorção de macronutrientes e micronutrientes incluem deficiências de ferro, folato, vitamina B12, vitamina D, cálcio, zinco e cobre<sup>33,85</sup> . Casos de osteoporose também podem ocorrer em pacientes com doença celíaca<sup>86</sup> . Destaca-se, também, que a DIG geralmente tem pouca fibra, o que pode provocar constipação<sup>68</sup> .  
No caso de diagnóstico tardio, pode haver alteração da permeabilidade da membrana intestinal por longo período, o que permite a absorção de macromoléculas, desencadeando quadro de hipersensibilidade alimentar, além de manifestações alérgicas 87. Esse quadro deve ser considerado quando o indivíduo não responde adequadamente à DIG e apresenta negatividade nos exames sorológicos para doença celíaca.  
10  
O dano nas vilosidades da mucosa intestinal pode ocasionar deficiência na produção das dissacaridases, a depender do grau de acometimento. Por isso, deve-se verificar a intolerância temporária à lactose e à sacarose, que revertem após cerca de dois meses de tratamento, com a normalização das vilosidades<sup>72</sup> . Da mesma forma, o supercrescimento bacteriano do intestino delgado pode estar presente como doença secundária.  
Há relatos de uma série de manifestações não malignas associadas à doença celíaca, como osteoporose, surgimento de outras doenças autoimunes, esterilidade, distúrbios neurológicos e psiquiátricos<sup>88</sup> . Entre as doenças malignas, são relatadas associações com o adenocarcinoma de intestino delgado, linfoma intestinal de células T e carcinoma de esôfago e faringe<sup>89,90</sup> . Nesses casos, a conduta seria tratar as complicações malignas e não malignas individualmente, além de manter a DIG.  
O risco dessas manifestações está associado a não adesão à DIG e ao diagnóstico tardio<sup>91</sup> . Portanto, justifica-se a prescrição de DIG por toda a vida para todos os indivíduos com doença celíaca, independentemente das manifestações clínicas.  
Pequena proporção dos pacientes com doença celíaca pode também apresentar alergia ao trigo. Pacientes com doença celíaca e com alergia ao trigo ou dermatite herpetiforme não devem utilizar produtos contendo trigo seja por via cutânea, s eja por via respiratória<sup>92</sup> .  
Uma apresentação rara da doença é a crise celíaca, caracterizada por progressão aguda ou rápida de sintomas no trato gastrointestinal com desidratação grave, disfunção neurológica e renal, acidose, hipoalbuminemia, distúrbios eletrolíticos e perda importante de peso<sup>68</sup> . Tal evolução pode requerer hospitalização ou nutrição parenteral<sup>68</sup> .  
O tratamento de tais manifestações graves da doença celíaca pode incluir internação com hidratação intravenosa, reposição de eletrólitos e início de DIG, além de, possivelmente, tratamento nutricional ou com corticosteroides, a depender das manifestações apresentadas<sup>33</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Com a instituição da DIG, espera-se a normalização histológica da mucosa intestinal, assim como das manifestações clínicas<sup>87</sup> . A adesão à DIG está associada à redução do risco de doença cardiovascular e malignidades associadas à doença celíaca<sup>93–95</sup> .  
A exclusão de alimentos contendo trigo, cevada e centeio promove a remissão dos sintomas e das características histológicas e sorológicas, melhora a qualidade de vida e reduz a mortalidade<sup>70,96,97</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Após o diagnóstico confirmatório de doença celíaca, o paciente, incluindo os cuidadores quando se tratar de criança, deve ser acompanhado por médico e nutricionista a cada três a seis meses no primeiro ano e anualmente após o primeiro ano e estabilização dos exames. Ao diagnóstico de doença celíaca, devem ser solicitados glicemia de jejum, hemograma completo e dosagens séricas de ferritina, vitamina B12, hormônio tireoestimulante (TSH), T4, transaminase glutâmico-oxalacética (TGO), transaminase pirúvica (TGP), densitometria óssea, cálcio e fósforo. Caso haja alteração nesses exames, a anemia por deficiência de ferro deve ser tratada com suplementação de ferro<sup>85</sup> , conforme Protocolo Clínico e Diretrizes Terapêuticas para Anemia por Deficiência de Ferro vigente, sempre na vigência da DIG. Concomitantemente, deve-se repor os micronutrientes, como cálcio e fósforo, ou vitaminas deficientes<sup>86</sup> . Caso exista alteração da função tireoideana, deve-se investigar a vigência de tireoidite de Hashimoto, a qual deve ser tratada. Aumentos nas dosagens de TGO e TGP podem estar presentes no momento do diagnóstico. Após alguns meses de tratamento com DIG, estas alterações devem desaparecer.  
Existem algumas abordagens para verificar a adesão à DIG como avaliação clínica, revisão da dieta, sorologia, marcadores bioquímicos e biópsia de acompanhamento<sup>33</sup> .  
11  
A avaliação clínica compreende verificar se os sintomas estão controlados e se a qualidade de vida melhorou. Essa abordagem envolve status nutricional, altura e peso<sup>33</sup> . A avaliação da adesão à dieta sem glúten deve ser realizada pela combinação de métodos de avaliação dos sintomas, avaliação clínica do nutricionista e/ou questionários dietéticos e testes laboratoriais<sup>46</sup> . No caso de não adesão à dieta totalmente isenta de glúten, o paciente deve ser reorientado p or médico e nutricionista acerca da importância da realização da dieta e do aparecimento de complicações não malignas ou malignas, caso a dieta não seja obedecida. Se os sintomas persistirem, deve-se verificar se a dieta está realmente sendo realizada, pois o principal motivo da manutenção dos sintomas é a não obediência à dieta totalmente sem glúten.  
Dosagem sérica de tTG IgA deve ser repetida seis meses após o início da DIG. No início do acompanhamento, a sorologia pode ser realizada no momento do diagnóstico, após três meses, após seis meses e após um ano<sup>33</sup> . Após esse período, a sorologia e os exames de acompanhamento podem ser realizados anualmente<sup>33</sup> . Os anticorpos associados com a doença celíaca são dependentes de glúten, de forma que, se o paciente aderir à dieta por meses, espera-se que os valores diminuam em comparação com a avaliação inicial. Caso essa redução não ocorra, existe uma suspeita de contaminação por glúten<sup>33</sup> .  
Não há necessidade de realizar biópsia de rotina para todos os pacientes<sup>33</sup> . Aconselha-se realizar biópsia de acompanhamento em adultos e crianças de um a dois anos após o início da DIG com a finalidade de verificar cicatrização da mucosa, especialmente em pacientes com mais de 40 anos e com sintomas iniciais mais severos<sup>33</sup> . Ademais, a biópsia de acompanhamento seria necessária somente em pacientes com doença celíaca e sorologia negativa, pois essa seria a única maneira de confirmar resposta à DIG<sup>33</sup> .  
Devido ao impacto que a doença promove nas funções psicológicas, sociais e familiares, o acompanhamento psicológico também pode contribuir na qualidade de vida dos indivíduos com doença celíaca<sup>98</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento.  
A identificação dos sinais e sintomas da doença celíaca na Atenção Primária à Saúde, bem como a realização de treinamentos para capacitação dos profissionais são de suma importância para o diagnóstico precoce e o tratamento adequados.  
Os gestores estaduais, distritais e municipais do SUS, conforme a sua competência e pactuações, devem estruturar a rede, estabelecer os fluxos e definir os serviços para o atendimento dos pacientes conforme as recomendações deste Protocolo .  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento aos pacientes. Facilita as ações de controle e avaliação, que incluem, entre outras, a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES) e o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus pagos) e, como verificação do atendimento, os resultados do teste de detecção e o resultado da biópsia duodenal e as consultas de acompanhamento. Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e observância da regulação do acesso assistencial, a compatibilidade da cobrança com os serviços executados, a abrangência e a integralidade assistenciais, e o grau de satisfação dos pacientes.  
Os procedimentos especiais da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS<sup>99</sup> contemplados neste PCDT estão descritos no Quadro 3.  
**Quadro 3.** Códigos de procedimentos conforme Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
|**Código procedimento**|**Descrição**|
|---|---|
|**02.09.01.003-7**|Esofagogastroduodenoscopia|
|**02.02.03.118-7**|Dosagem de anticorpos antitransglutaminase recombinante humano IgA|  
12  
|**Código procedimento**<br>**02.02.03.015-6**|**Descrição**<br>Dosagem de Imunoglobulina A (IgA)|
|---|---|  
Fonte: SIGTAP – Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS<sup>~~99~~</sup> .

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
1. Farrell RJ, Kelly CP. Celiac sprue. N Engl J Med. janeiro de 2002;346(3):180–8.  
2. Ludvigsson JF, Leffler DA, Bai JC, Biagi F, Fasano A, Green PHR, et al. The Oslo definitions for coeliac disease and related terms. Gut. janeiro de 2013;62(1):43–52.  
3. Arámburo-Gálvez JG, Beltrán-Cárdenas CE, Geralda André T, Carvalho Gomes I, Macêdo-Callou MA, BragaRocha ÉM, et al. Prevalence of Adverse Reactions to Gluten and People Going on a Gluten-Free Diet: A  Survey Study Conducted in Brazil. Medicina (Kaunas). abril de 2020;56(4).  
4. MUNIZ JG, SDEPANIAN VL, FAGUNDES NETO U. PREVALENCE OF GENETIC SUSCEPTIBILITY FOR CELIAC DISEASE IN BLOOD DONORS IN SÃO PAULO, BRAZIL . Vol. 53, Arquivos de Gastroenterologia . scielo ; 2016. p. 267–72.  
5. Gasbarrini G, Malandrino N, Giorgio V, Fundarò C, Cammarota G, Merra G, et al. Celiac Disease: What‟s New about It? Digestive Diseases. 2008;26(2):121–7.  
6. Rubio-Tapia, Alberto MD1; Hill, Ivor D. MD2; Semrad, Carol MD3; Kelly, Ciarán P. MD4; Greer, Katarina B. MD, MS5; Limketkai, Berkeley N. MD, PhD, FACG6; Lebwohl, Benjamin MD, MS7. American College of Gastroenterology Guidelines Update: Diagnosis and Management of Celiac Disease. The American Journal of Gastroenterology 118(1):p 59-76, January 2023.  
7. Abadie V, Sollid LM, Barreiro LB, Jabri B. Integration of genetic and immunological insights into a model of celiac disease  pathogenesis. Annu Rev Immunol. 2011;29:493–525.  
8. SELLESKI N, ALMEIDA LM, ALMEIDA FC de, PRATESI CB, NÓBREGA YK de M, GANDOLFI L. PREVALENCE OF CELIAC DISEASE PREDISPOSING GENOTYPES, INCLUDING HLA-DQ2.2 VARIANT, IN BRAZILIAN CHILDREN . Vol. 55, Arquivos de Gastroenterologia . scielo ; 2018. p. 82–5.  
9. SOCHAL, Piotr, IWASZKO-SOCHAL, Klaudyna and SZCZEPANIAK-WÓJTOWICZ, Elżbieta. Celiac disease in children - diagnosis in light of the current 2020 ESPGHAN guidelines. Journal of Education, Health and Sport. Online. 29 May 2023. Vol. 34, no. 1, pp. 75-83.  
10. Singh P, Arora A, Strand TA, Leffler DA, Catassi C, Green PH, et al. Global Prevalence of Celiac Disease: Systematic Review and Meta-analysis. Clin Gastroenterol Hepatol. junho de 2018;16(6):823-836.e2.  
11. Oliveira RP, Sdepanian VL, Barreto JA, Cortez AJP, Carvalho FO, Bordin JO, et al. High prevalence of celiac disease in Brazilian blood donor volunteers based on  screening by IgA antitissue transglutaminase antibody. Eur J Gastroenterol Hepatol. janeiro de 2007;19(1):43–9.  
12. Alencar ML, Ortiz-Agostinho CL, Nishitokukado lêda, Damião AOMC, Abrantes-Lemos CP, Leite AZ de A, et al. Prevalence of celiac disease among blood donors in São Paulo: the most populated city in Brazil . Vol. 67, Clinics . scielo ; 2012. p. 1013–8.  
13. Melo SBC, Fernandes MIM, Peres LC, Troncon LEA, Galvão LC. Prevalence and demographic characteristics of celiac disease among blood donors in  Ribeirão Preto, State of São Paulo, Brazil. Dig Dis Sci. maio de 2006;51(5):1020–5.  
13  
14. Pereira MAG, Ortiz-Agostinho CL, Nishitokukado I, Sato MN, Damião AOMC, Alencar ML, et al. Prevalence of celiac disease in an urban area of Brazil with predominantly European ancestry. World J Gastroenterol. 28 de outubro de 2006;12(40):6546–50.  
15. Gandolfi L, Pratesi R, Cordoba JC, Tauil PL, Gasparin M, Catassi C. Prevalence of celiac disease among blood donors in Brazil. Am J Gastroenterol. março de 2000;95(3):689–92.  
16. Crovella S, Brandao L, Guimaraes R, Filho JL, Arraes LC, Ventura A, Not T. Speeding up coeliac disease diagnosis in the developing countries. Dig Liver Dis. 2007 Oct;39(10):900-2. .  
17. da Silva Kotze LM, Nisihara RM, Kotze LR, da Rosa Utiyama SR. Celiac disease in older brazilians. Vol. 59, Journal of the American Geriatrics Society. United States; 2011. p. 1548–50.  
18. Rashtak S, Murray JA. Celiac disease in the elderly. Gastroenterol Clin North Am. setembro de 2009;38(3):433– 46.  
19. Ciccocioppo R, Kruzliak P, Cangemi GC, Pohanka M, Betti E, Lauret E, et al. The Spectrum of Differences between Childhood and Adulthood Celiac Disease. Nutrients. outubro de 2015;7(10):8733–51.  
20. Bürgin-Wolff A, Mauro B, Faruk H. Intestinal biopsy is not always required to diagnose celiac disease: a retrospective  analysis of combined antibody tests. BMC Gastroenterol. janeiro de 2013;13:19.  
21. Rewers M. Epidemiology of celiac disease: what are the prevalence, incidence, and progression  of celiac disease? Gastroenterology. abril de 2005;128(4 Suppl 1):S47-51.  
22. de Freitas IN, Sipahi AM, Damião AOMC, de Brito T, Cançado ELR, Leser PG, et al. Celiac disease in Brazilian adults. J Clin Gastroenterol. 2002;34(4):430–4.  
23. Trabulsi LR, Toledo MR, Kitagawa SM, Candeias JA. Diarrheal disease in children in São Paulo. Kansenshogaku Zasshi. março de 1988;62 Suppl:97–104.  
24. Rodrigues M, Yonamine GH, Fernandes Satiro CA. Rate and determinants of non-adherence to a gluten-free diet and nutritional status  assessment in children and adolescents with celiac disease in a tertiary Brazilian referral center: a cross-sectional and retrospective study. BMC Gastroenterol. janeiro de 2018;18(1):15.  
25. Leffler DA, Green PHR, Fasano A. Extraintestinal manifestations of coeliac disease. Nat Rev Gastroenterol Hepatol. outubro de 2015;12(10):561–71.  
26. Silano M, Volta U, Mecchia AM, Dessì M, Di Benedetto R, De Vincenzi M, et al. Delayed diagnosis of coeliac disease increases cancer risk. BMC Gastroenterol. 9 de março de 2007;7:8.  
27. Cataldo F, Montalto G. Celiac disease in the developing countries: a new and challenging public health  problem. World J Gastroenterol. abril de 2007;13(15):2153–9.  
28. Long KH, Rubio-Tapia A, Wagie AE, Melton LJ 3rd, Lahr BD, Van Dyke CT, et al. The economics of coeliac disease: a population-based study. Aliment Pharmacol Ther. julho de 2010;32(2):261–9.  
29. Falcomer AL, Luchine BA, Gadelha HR, Szelmenczi JR, Nakano EY, Farage P, et al. Worldwide public policies for celiac disease: are patients well assisted? Int J Public Health. julho de 2020;65(6):937–45.  
30. Sdepanian VL, de Morais MB, Fagundes Neto U. [Celiac disease: evolution in knowledge since its original centennial description up  to the present day]. Arq Gastroenterol. 1999;36(4):244–57.  
31. Sdepanian VL, Moraes MB, Fagundes-Neto U. [Celiac disease: clinical characteristics and methods used in the diagnosis of  patients registered at the Brazilian Celiac Association]. J Pediatr (Rio J). 2001;77(2):131–8.  
32. Adams DH. Sleisenger and Fordtran‟s Gastrointestinal and Liver Disease. Gut. agosto de 2007;56(8):1175.  
33. Al-Toma A, Volta U, Auricchio R, Castillejo G, Sanders DS, Cellier C, et al. European Society for the Study of Coeliac Disease (ESsCD) guideline for coeliac  disease and other gluten-related disorders. United European Gastroenterol J. junho de 2019;7(5):583–613.  
14  
34. Fasano A, Catassi C. Current approaches to diagnosis and treatment of celiac disease: an evolving  spectrum. Gastroenterology. fevereiro de 2001;120(3):636–51.  
35. Federação Nacional das Associações de Celíacos do Brasil. Guia orientador para celíacos / Federação Nacional das Associações de Celíacos do Brasil ; elaboração de Almir Correa Moraes et all. -- São Paulo: Escola Nacional de Defesa do Consumidor, Ministério da Justiça, 2010.  
36. Al-Toma A, Volta U, Auricchio R, Castillejo G, Sanders DS, Cellier C, et al. European Society for the Study of Coeliac Disease (ESsCD) guideline for coeliac  disease and other gluten-related disorders. United European Gastroenterol J. junho de 2019;7(5):583–613.  
37. Clarindo MV, et al. Dermatitis herpetiformis: pathophysiology, clinical presentation, diagnosis and treatment. An Bras Dermatol. 2014;89(6):865-77.  
38. Jericho H, Guandalini S. Extra-Intestinal Manifestation of Celiac Disease in Children. Nutrients. junho de 2018;10(6):755.  
39. Jelsness-Jørgensen LP, Bernklev T, Lundin KEA. Fatigue as an Extra-Intestinal Manifestation of Celiac Disease: A Systematic Review. Nutrients. novembro de 2018;10(11).  
40. ESPGHAN. New Guidelines for the Diagnosis of Paediatric Coeliac Disease. Genebra: ESPGHAN, 2020. [Internet]. 2020 [citado 8 de janeiro de 2022]. Disponível em:  
https://www.espghan.org/knowledgecenter/publications/Clinical-  
AdviceGuides/2020_New_Guidelines_for_the_Diagnosis_of_Paediatric_Coeliac_Disease.  
41. Lopes LHC, Muniz JG, Oliveira RP, Sdepanian VL. Celiac Disease in Brazilian First-degree Relatives: The Odds Are Five Times Greater  for HLA DQ2 Homozygous. J Pediatr Gastroenterol Nutr. maio de 2019;68(5):e77–80.  
42. Pham-Short A, Donaghue KC, Ambler G, Phelan H, Twigg S, Craig ME. Screening for Celiac Disease in Type 1 Diabetes: A Systematic Review. Pediatrics. julho de 2015;136(1):e170-6.  
43. Irvine AJ, Chey WD, Ford AC. Screening for Celiac Disease in Irritable Bowel Syndrome: An Updated Systematic  Review and Meta-analysis. Am J Gastroenterol. janeiro de 2017;112(1):65–76.  
44. Ludvigsson JF, Bai JC, Biagi F, Card TR, Ciacci C, Ciclitira PJ, et al. Diagnosis and management of adult coeliac disease: guidelines from the British Society of Gastroenterology. Gut. 1<sup>o</sup> de agosto de 2014;63(8):1210 LP – 1228.  
45. Kelly C. Diagnosis of celiac disease in adults. UpToDate. 2020.  
46. Mearin ML, Agardh D, Antunes H, Al-toma A, Auricchio R, Castillejo G, et al. ESPGHAN Position Paper on Management and Follow-up of Children and Adolescents With Celiac Disease. J Pediatr Gastroenterol Nutr [Internet]. 27 de setembro de 2022 [citado 6 de setembro de 2021];75(3):369–86. Disponível em: https://journals.lww.com/jpgn/Fulltext/2022/09000/ESPGHAN_Position_Paper_on_Manage ment_and_Follow_up.29.aspx.  
47. Hill ID, Dirks MH, Liptak GS, Colletti RB, Fasano A, Guandalini S, et al. Guideline for the diagnosis and treatment of celiac disease in children:  recommendations of the North American Society for Pediatric Gastroenterology, Hepatology and Nutrition. J Pediatr Gastroenterol Nutr. janeiro de 2005;40(1):1–19.  
48. Maglione M, Okunogbe A, Ewing B. Diagnosis of Celiac Disease [Internet]. Em: Comparative Effectiveness Reviews, no 162. Rockville (MD): Agency for Healthcare Research and Quality (US); 2016.  
49. Hill ID, Fasano A, Guandalini S, Hoffenberg E, Levy J, Reilly N, et al. NASPGHAN Clinical Report on the Diagnosis and Treatment of Gluten-related Disorders. J Pediatr Gastroenterol Nutr. julho de 2016;63(1):156–65.  
15  
50. Husby S, Koletzko S, Korponay-Szabó I, Kurppa K, Mearin ML, Ribes-Koninckx C, et al. European Society Paediatric Gastroenterology, Hepatology and Nutrition Guidelines for Diagnosing Coeliac Disease 2020. J Pediatr Gastroenterol Nutr. janeiro de 2020;70(1):141–56.  
51. Chou R, Bougatsos C, Blazina I, Mackey K, Grusing S, Selph S. Screening for Celiac Disease: Evidence Report and Systematic Review for the US  Preventive Services Task Force. JAMA. março de 2017;317(12):1258–68.  
52. Rostami K, Kerckhaert J, Tiemessen R, von Blomberg BM, Meijer JW, Mulder CJ. Sensitivity of antiendomysium and antigliadin antibodies in untreated celiac  disease: disappointing in clinical practice. Am J Gastroenterol. abril de 1999;94(4):888–94.  
53. BRASIL. Ministério da Saúde. Secretaria de Atenção à Saúde. PORTARIA N<sup>o</sup> 307, DE 17 DE SETEMBRO DE 2009(*). Brasília; 2009.  
54. Sdepanian VL & Marcelino RT. Doença celíaca. In: Tratado de Pediatria ( volume 1)., 5 ed. SBP. São paulo. Editora Manole. 2022. Pg 1304-1310.  
55. Hayat M, Cairns A, Dixon MF, O‟Mahony S. Quantitation of intraepithelial lymphocytes in human duodenum: what is normal? J Clin Pathol. maio de 2002;55(5):393–4.  
56. Marsh MN. Gluten, major histocompatibility complex, and the small intestine. A molecular and  immunobiologic approach to the spectrum of gluten sensitivity ('celiac sprue‟). Gastroenterology. janeiro de 1992;102(1):330–54.  
57. Hujoel IA, Reilly NR, Rubio-Tapia A. Celiac Disease: Clinical Features and Diagnosis. Gastroenterol Clin North Am. março de 2019;48(1):19–37.  
58. National Institutes of Health Consensus Development Conference Statement on Celiac  Disease, June 28-30, 2004. Gastroenterology. abril de 2005;128(4 Suppl 1):S1-9.  
59. Oberhuber G, Granditsch G, Vogelsang H. The histopathology of coeliac disease: time for a standardized report scheme for  pathologists. Eur J Gastroenterol Hepatol. outubro de 1999;11(10):1185–94.  
60. Corazza GR, Villanacci V. Coeliac disease. J Clin Pathol. junho de 2005;58(6):573–4.  
61. Corazza GR, Villanacci V, Zambelli C, Milione M, Luinetti O, Vindigni C, et al. Comparison of the interobserver reproducibility with different histologic criteria  used in celiac disease. Clin Gastroenterol Hepatol. julho de 2007;5(7):838–43.  
62. Villanacci V, Lorenzi L, Donato F, Auricchio R, Dziechciarz P, Gyimesi J, et al. Histopathological evaluation of duodenal biopsy in the PreventCD project. An  observational interobserver agreement study. APMIS. março de 2018;126(3):208–14.  
63. N Marsh M, W Johnson M, Rostami K. Mucosal histopathology in celiac disease: a rebuttal of Oberhuber‟s sub - division of  Marsh III. Gastroenterol Hepatol Bed Bench. 2015;8(2):99–109.  
64. Marsh MN, Johnson MW, Rostami K. Rebutting Oberhuber- Again. Gastroenterol Hepatol Bed Bench. 2015;8(4):303–5.  
65. Ensari A, Marsh MN. Diagnosing celiac disease: A critical overview. Turk J Gastroenterol. maio de 2019;30(5):389–97.  
66. Lagana SM, Bhagat G. Biopsy Diagnosis of Celiac Disease: The Pathologist‟s Perspective in Light of Recent  Advances. Gastroenterol Clin North Am. março de 2019;48(1):39–51.  
67. Ludvigsson JF, Leffler DA, Bai JC, Biagi F, Fasano A, Green PH, Hadjivassiliou M, Kaukinen K, Kelly CP, Leonard JN, Lundin KE, Murray JA, Sanders DS, Walker MM, Zingone F, Ciacci C. The Oslo definitions for coeliac disease and related terms. Gut. 2013 Jan;62(1):43-52.  
16  
68. Al-Toma A, Volta U, Auricchio R, Castillejo G, Sanders DS, Cellier C, et al. European Society for the Study of Coeliac Disease (ESsCD) guideline for coeliac  disease and other gluten-related disorders. United European Gastroenterol J. junho de 2019;7(5):583–613.  
69. Brasil. Ministério da Saúde. Secretaria de Atenão Primária à Saúde. Departamento de Promoção à Saúde. Guia alimentar para crianças brasileiras menores de 2 anos. Brasília; 2019.  
70. do Nascimento AB, Fiates GMR, dos Anjos A, Teixeira E. Gluten-free is not enough--perception and suggestions of celiac consumers. Int J Food Sci Nutr. junho de 2014;65(4):394–8.  
71. Sdepanian VL, Scaletsky IC, Fagundes-Neto U, Batista de Morais M. Assessment of gliadin in supposedly gluten-free foods prepared and purchased by  celiac patients. J Pediatr Gastroenterol Nutr. janeiro de 2001;32(1):65–70.  
72. Beyer P. Terapia clínica nutricional para distúrbios do trato gastrintestinal baixo. Em: Krause alimentos, nutrição & dietoterapia. 10 ed. São Paulo: Roca; 2002. p. 643–70.  
73. Agência Nacional de Vigilância Sanitária. Resolução - RDC n<sup>o</sup> 727, de 1° de julho de 2022.  
74. Brasil. Presidência da República. Casa Civil. Subchefia para Assuntos Jurídicos. Lei N<sup>o</sup> 10.674, de 16 de maio de 2003.  
75. Falcomer AL, Santos Araújo L, Farage P, Santos Monteiro J, Yoshio Nakano E, Puppin Zandonadi R. Gluten contamination in food services and industry: A systematic review. Crit Rev Food Sci Nutr. 2020;60(3):479–93.  
76. Farage P, de Medeiros Nóbrega YK, Pratesi R, Gandolfi L, Assunção P, Zandonadi RP. Gluten contamination in gluten-free bakery products: a risk for coeliac disease  patients. Public Health Nutr. fevereiro de 2017;20(3):413–6.  
77. Fragoso Abelo T, Díaz Lorenzo T, Pérez Ramos E, Milán Pavón R, Luaces Fragoso E. Importancia de los aspectos psicosociales en la enfermedad celíaca. Rev Cuba Med Gen Integr. 2002;18(3).  
78. Mulder, C.J.J.; Elli, L.; Lebwohl, B.; Makharia, G.K.; Rostami, K.; Rubio-Tapia, A.; Schumann, M.; Tye-Din, J.; Zeitz, J.; Al-Toma, A. Follow-Up of Celiac Disease in Adults: “When, What, Who, and Where”. Nutrients 2023, .  
79. Lizano-Díez I, Mariño EL, Modamio P. Gluten in pharmaceutical products: a scoping review. Syst Rev. 2021 Aug 7;10(1):218.  
80. Ludvigsson JF, Card T, Ciclitira PJ, et al. Support for patients with celiac disease: A literature review. United European Gastroenterology Journal. 2015;3(2):146-159.  
81. Mogul D, Nakamura Y, Seo J, Blauvelt B, Bridges JFP. The unknown burden and cost of celiac disease in the U.S. Expert Rev Pharmacoecon Outcomes Res. abril de 2017;17(2):181–8.  
82. Zarkadas M, Dubois S, MacIsaac K, Cantin I, Rashid M, Roberts KC, et al. Living with coeliac disease and a gluten-free diet: a Canadian perspective. J Hum Nutr Diet. fevereiro de 2013;26(1):10–23.  
83. MacCulloch K, Rashid M. Factors affecting adherence to a gluten-free diet in children with celiac disease. Paediatr Child Health. junho de 2014;19(6):305–9.  
84. Araújo HMC, Araújo WMC, Botelho RBA, Zandonadi RP. Doença celíaca, hábitos e práticas alimentares e qualidade de vida. Rev Nutr [Internet]. 2010May;23(3):467–74. .  
85. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IEstratégicos. Protocolo Clínico e Diretrizes Terapêuticas: Anemia por deficiência de ferro [Internet]. Brasília; 2019.  
86. Brasil. Ministério da Saúde S de CT e IEstratégicos. Protocolo Clínico e Diretrizes Terapêuticas: Osteoporose [Internet]. Brasília; 2019.  
17  
87. Ferreira CT, Seidman E. Food allergy: a practical update from the gastroenterological viewpoint. J Pediatr (Rio J). 2007;83(1):7–20.  
88. Holmes GK. Non-malignant complications of coeliac disease. Acta Paediatr Suppl. maio de 1996;412:68–75.  
89. Catassi C, Fabiani E, Corrao G, Barbato M, De Renzo A, Carella AM, et al. Risk of non-Hodgkin lymphoma in celiac disease. JAMA. março de 2002;287(11):1413–9.  
90. Han Y, Chen W, Li P, Ye J. Association Between Coeliac Disease and Risk of Any Malignancy and Gastrointestinal  Malignancy: A Meta-Analysis. Medicine. setembro de 2015;94(38):e1612.  
91. Siqueira Neto JI, Costa ACLV, Magalhães FG, Silva GS. Neurological manifestations of celiac disease. Arq Neuropsiquiatr. dezembro de 2004;62(4):969–72.  
92. Cardoso-Silva D, Delbue D, Itzlinger A, Moerkens R, Withoff S, Branchi F, et al. Intestinal Barrier Function in Gluten-Related Disorders. Nutrients. outubro de 2019;11(10).  
93. Olén O, Askling J, Ludvigsson JF, Hildebrand H, Ekbom A, Smedby KE. Coeliac disease characteristics, compliance to a gluten free diet and risk of  lymphoma by subtype. Dig Liver Dis. novembro de 2011;43(11):862–8.  
94. Lebwohl B, Granath F, Ekbom A, Montgomery SM, Murray JA, Rubio-Tapia A, et al. Mucosal healing and mortality in coeliac disease. Aliment Pharmacol Ther. 2012/11/28. fevereiro de 2013;37(3):332–9.  
95. West J, Logan RFA, Smith CJ, Hubbard RB, Card TR. Malignancy and mortality in people with coeliac disease: population based cohort  study. BMJ. setembro de 2004;329(7468):716–9.  
96. Niewinski MM. Advances in celiac disease and gluten-free diet. J Am Diet Assoc. abril de 2008;108(4):661–72.  
97. Tack GJ, Verbeek WHM, Schreurs MWJ, Mulder CJJ. The spectrum of celiac disease: epidemiology, clinical aspects and treatment. Nat Rev Gastroenterol Hepatol. abril de 2010;7(4):204–13.  
98. Rocha S, Gandolfi L, Santos JE. The psychosocial impacts caused by diagnosis and treatment of Coeliac Disease. Rev Esc Enferm USP. 2016;50(1):65-70.  
99. Ministério da Saúde. SIGTAP - Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS [Internet]. Datasus.gov. 2020. Disponível em: http://sigtap.datasus.gov.br/tabela-  
- unificada/app/sec/inicio.jsp  
18  
**APÊNDICE 1 - METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA**

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A elaboração do PCDT da Doença Celíaca iniciou-se com a demanda pelo Ministério da Saúde (MS) e a reunião de escopo realizada em 04 de novembro de 2019. O grupo elaborador deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS). Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, os quais foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo.  
Os trabalhos foram conduzidos considerando as Diretrizes Metodológicas para elaboração de PCDT. Definiu -se que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias em saúde previamente disponibilizadas no SUS não demandariam questões de pesquisa definidas por serem práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
A dinâmica da reunião de escopo foi conduzida com base no PCDT vigente (Portaria SAS/MS nº 1.149, de 11 de novembro de 2015) e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador e demais participantes da reunião de escopo, com o objetivo principal de revisar as condutas diagnósticas e identificar tecnologias em saúde que poderiam ser consideradas nas recomendações do Protocolo. Foram estabelecidas duas questões de pesquisa relativas ao diagnóstico, referentes a:  
a. Avaliação da incorporação de antigliadina deaminada IgG para pacientes com deficiência de IgA ou crianças menores de 2 anos de idade.  
b. Avaliação da incorporação de genotipagem do HLA DQ2 e HLA DQ8.  
Declaração e Manejo de Conflitos de Interesse  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos benefícios abaixo?  
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada|(   ) Sim|
|prejudicada com as recomendações da diretriz?|(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de algu|(   ) Sim|  
19  
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|---|---|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afet<br>na elaboração ou revisão da diretriz?|ados pela sua ativid|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e q|<br>(   ) Sim|
|deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|  
Nenhum participante teve conflitos de interesse a declarar.

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
A proposta de atualização do PCDT da Doença Celíaca foi apresentada na 106ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 16 de maio de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS), Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria Especial de Saúde Indígena (SESAI). Na reunião, foram solicitados ajustes nas Figura 1 e 2.

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
O processo de desenvolvimento desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PIRO (Figura A). O restante do texto foi atualizado conforme as diretrizes médicas internacionais, encontradas por meio de busca sistemática da  
20  
literatura e conselho dos especialistas. O texto redigido e revisado por especialistas na Doença Celíaca, e então por técnicos do Ministério da Saúde.  
|P|População de interesse|
|---|---|
|I|Teste índex|
|R|Teste referência|
|O|Desfechos|  
Figura A. Acrônimo para definição das perguntas de pesquisa.  
Durante a reunião de escopo deste PCDT duas questões de pesquisa foram definidas **(Quadro B)** . Uma vez que as questões foram avaliadas pela Conitec, a reunião de recomendação entre especialistas que compuseram a equipe de elaboração do Protocolo não foi realizada, sendo consideradas as recomendações do comitê de PCDT da Conitec e decisões do Ministério da Saúde publicadas em Diário Oficial da União para as tecnologias em saúde avaliadas no contexto da doença celíaca.  
Os relatórios técnicos finais contêm os métodos e resultados dos pareceres técnico-científico, avaliações econômicas e análises de impacto orçamentário no SUS, os quais subsidiaram as recomendações finais da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec).  
**Quadro B.** Questões PIRO priorizadas para elaboração do Protocolo.  
|**PIRO**|**Estrutura da pergunta de**<br>**pesquisa**|**Relatório técnico final**|**Recomendação**|
|---|---|---|---|
|**1**|População: pacientes com<br>deficiência de IgA ou crianças<br>menores de 2 anos de idade.<br>Teste-índice: tTG-<br>antigliadina deaminada<br>biópsia.<br>Teste-referência: tTG-<br>EDA + biópsia.<br>Desfecho: acurácia diagnóstica,<br>sensibilidade, especificidade, VPP<br>e VPN.|Brasil/ Ministério da Saúde. Relatório nº 814/2023:<br>Teste de antigliadina deaminada IgG para<br>diagnóstico de doença celíaca e pacientes com<br>deficiência de IgA e suspeita de doença celíaca e<br>crianças menores de dois anos. 2023. Disponível<br>em: <https://www.gov.br/conitec/pt-<br>br/midias/relatorios/2023/20230418_Relatorio_814<br>_Antigliadina_Doena_celiaca.pdf>. Acesso em:<br>maio de 2023.|Favorável à<br>incorporação da<br>tecnologia em<br>saúde, no âmbito<br>do SUS, apenas<br>para pacientes<br>com suspeita de<br>doença celíaca<br>menores de dois<br>anos.|
|**2**|População: pacientes pertencentes<br>aos grupos de risco com sorologia<br>negativa e/ou biópsia negativa.<br>Teste-índice: genotipagem do<br>haplótipo HLA DQ2 e DQ8.<br>Teste-referência: anticorpo<br>antitransglutaminase IgA sérico e<br>biópsia de duodeno por EDA<br>periodicamente.<br>Desfecho: acurácia diagnóstica,<br>sensibilidade, especificidade,<br>valor preditivo positivo e valor<br>preditivo negativo; EDAs<br>evitadas.|Brasil/ Ministério da Saúde. Relatório nº 815/2023:<br>Teste de genotipagem HLA-DQ2 e DQ8 para o<br>diagnóstico de doença celíaca em pacientes com<br>fatores de risco. 2023. Disponível em: <<br>https://www.gov.br/conitec/pt-<br>br/midias/relatorios/2023/20230428_relatorio-<br>genotipagem_hla-<br>dq2_dq8_doenca_celiaca_secretariol_815_2023.pdf<br>>. Acesso em: maio de 2023.|Não favorável à<br>incorporação da<br>tecnologia em<br>saúde, no âmbito<br>do SUS.|  
**EDA** : endoscopia digestiva alta; **PIRO** : População; Teste-índice; Teste-referência; Outcome; **VPP** : valor preditivo positivo; **VPN** : valor preditivo negativo.  
21

---

<!-- METADADOS: doenca: Doença Celíaca | secao: FERNANDA DE NEGRI -->
|Número do Relatório da||Tecnologias av|aliadas pela Conitec|
|---|---|---|---|
|diretriz clínica (Conitec)<br>ou Portaria de Publicação|Principais alterações|Incorporação ou alteração do uso<br>no SUS|Não incorporação ou inalteração no<br>SUS|
|Relatório de<br>Recomendação nº 851, de<br>setembro de 2023<br> <br> <br> <br> <br> <br> <br> <br>|<br>Atualização do texto,<br>incluindo diferentes<br>formas de apresentação<br>clínica da doença,<br>critérios de elegibilidade<br>e diagnóstico, abordagem<br>terapêutica e diferenças<br>entre crianças e adultos.|<br>Teste de antigliadina deaminada<br>IgG para crianças com até 2 anos<br>de idade e com suspeita de doença<br>celíaca (Portaria SECTICS/MS nº<br>10, de 17 de abril de 2023)|Teste de genotipagem HLA-DQ2 e/ou<br>DQ8 para o diagnóstico de doença<br>celíaca em pacientes com fatores de<br>risco (Portaria SECTICS/MS nº 18, de<br>27 de abril de 2023)|
|Portaria SAS/MS nº<br>1.149, de 11/11/2015<br> <br>|Atualização do<br>documento|-|-|
|Portaria SAS/MS nº 307,<br>de 17/09/2009<br>|Primeira versão|-|-|  
22

---

