<!-- METADADOS: doenca: Diabete Insípido | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº17, DE 05 DE AGOSTO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Diabete Insípido.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 4 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Diabete Insípido no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup>º</sup> 940/2024 e o Relatório de Recomendação n<sup>°</sup> 943/2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Diabete Insípido.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do Diabete Insípido, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Diabete Insípido.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE nº 2, de 10 de janeiro de 2018, publicada no Diário Oficial da União (DOU) nº 11, de 16 de janeiro de 2018, seção 1, página 44.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES FERNANDA DE NEGRI  
1  
**ANEXO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DO DIABETE INSÍPIDO**

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **1. INTRODUÇÃO** -->
O diabete insípido (DI) é uma síndrome poliúrica caracterizada pela incapacidade de concentrar o filtrado urinário e consequentes aumento de volume de urina hipotônica e sede excessiva<sup>1,2</sup> . A doença pode ocorrer por deficiência do hormônio antidiurético (arginina-vasopressina) ou por resistência à sua ação nos túbulos renais<sup>3,4</sup> . A deficiência na síntese da argininavasopressina (AVP) é chamada de DI central, neuro-hipofisário ou neurogênico; já a resistência à sua ação nos túbulos renais é conhecida como DI renal ou nefrogênico<sup>3,5</sup> .  
O diagnóstico diferencial das síndromes poliúricas inclui polidipsia primária (psicogênica) e causas de diurese osmótica<sup>6</sup> . Na polidipsia primária, o distúrbio inicial é o aumento da ingestão excessiva de líquidos que leva à poliúria, apesar da secreção da AVP preservada e uma resposta renal antidiurética apropriada<sup>3,5</sup> . Ocorre principalmente em pacientes com transtornos psiquiátricos e raramente em pacientes com lesões hipotalâmicas que afetam o centro de controle da sede. A diurese osmótica ocorre por aumento da filtração de um soluto osmoticamente ativo e consequente aumento do volume urinário. A mais comum entre as causas de diurese osmótica é o diabete melito, com o aumento da diurese devido à ação osmótica da glicose na urina<sup>5</sup> .  
É importante diferenciar os tipos de DI, pois os tratamentos do DI central e do renal são distintos. Entre as causas da deficiência da arginina vasopressina (DI central), as mais frequentes são a idiopática e aquelas associadas a trauma, cirurgia, tumores da região hipotalâmica (disgerminoma, craniofaringioma, histiocitose de células de Langerhans), encefalopatia hipóxica/isquêmica, doenças inflamatórias, autoimunes ou vasculares e malformações cerebrais<sup>1,5,7,8</sup> . As formas de DI central congênitas são mais raras, causadas por defeitos genéticos na síntese de AVP, herdados como traços autossômicos dominantes ou recessivos e recessivos ligados ao cromossomo X<sup>1</sup> .  
A resistência à arginina vasopressina (DI renal) caracteriza-se pelo prejuízo na capacidade de concentração urinária mesmo na presença de concentrações plasmáticas normais ou aumentadas de AVP. A ação renal da AVP acontece pela ligação aos seus receptores de membrana tipo 2 (RV2) acoplados à proteína G, encontrados nas células dos túbulos distais e ductos coletores renais promovendo a translocação dos canais de água do tipo aquaporina-2 (AQP2) e o fluxo de água do lúmen hipotônico para o interstício hipertônico do néfron<sup>3,4,9</sup> . A insensibilidade renal à AVP causa diminuição da expressão dos canais de água AQP2 e consequente diminuição da reabsorção de água nos ductos renais distal e coletor causando poliúria hipotônica. São descritas formas congênitas (genéticas) e adquiridas pelo uso de alguns medicamentos, como o lítio, distúrbios eletrolíticos, como hipercalcemia e hipocalemia, lesões infiltrativas dos rins ou distúrbios vasculares<sup>3,4</sup>  
Há também o DI gestacional em que a degradação aumentada da AVP ocorre devido às elevadas concentrações da enzima vasopressinase produzida pelos trofoblastos placentários<sup>10</sup> . Esta é uma forma rara e transitória da doença que se manifesta mais comumente no terceiro trimestre da gestação e apresenta resolução do quadro alguns dias após o parto<sup>3,8,11</sup> .  
O prognóstico dos pacientes com DI é influenciado por diversos fatores, incluindo a etiologia da condição, a presença de comorbidades e a implementação de uma abordagem terapêutica apropriada<sup>12–14</sup> . A maioria dos pacientes com deficiência de arginina vasopressina (AVP-D) mantem intacta a capacidade de regular a sede de acordo com as necessidades corporais, permitindo que a ingestão oral de líquidos ajuste adequadamente às perdas de água tanto pela urina quanto por vias insensíveis. Assim, na ausência de tratamento, esses indivíduos apresentam frequentemente níveis normais de sódio no sangue. Contudo, diante dos sintomas comuns de aumento da urina e sede excessiva, o uso de desmopressina é adotado como terapêutica<sup>3</sup> .  
2  
O tratamento com desmopressina (DDAVP), um análogo da AVP, foi descrito em 1972<sup>15</sup> é, desde então, o padrão adotado para pacientes com DI central (AVP-D) e DI gestacional.  
Os estudos epidemiológicos do DI são escassos, no entanto, há relato de aproximadamente 1 caso a cada 25.000 pessoas<sup>3</sup> . Inexistem estudos epidemiológicos sobre DI no Brasil. O DI afeta homens e mulheres igualmente e pode se manifestar em indivíduos de todas as idades.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do DI central e gestacional. O DI renal (AVP-R) não será abordado neste Protocolo por tratar-se de doença decorrente da resistência renal à ação da AVP.  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- E23.2 Diabete insípido

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3.1. Diagnóstico clínico** -->
A primeira manifestação do DI geralmente é noctúria, devido à perda de capacidade de concentração da urina no período da noite<sup>2</sup> . A apresentação clínica ocorre com poliúria e consequente aumento da ingestão de água (polidipsia)<sup>2</sup> .  
Lactentes e pré-escolares costumam apresentar atraso de crescimento, vômitos e dificuldades de alimentação, febre de origem indeterminada, letargia, irritabilidade, sede excessiva (polidipsia), diurese abundante (poliúria), noctúria, enurese noturna, desidratação e distúrbios eletrolíticos (hipernatremia e hipercloremia)<sup>18</sup> . O déficit pôndero-estatural ou a desaceleração do crescimento são frequentes em crianças devido ao consumo preferencial de água em detrimento às refeições<sup>19</sup> .  
A poliúria varia conforme a idade, sendo definida como volume urinário acima de 3 litros em 24 horas (acima de 40 mL/kg/dia) em adolescentes e adultos e, em crianças, pode ser definida<sup>20,21</sup> de acordo com a idade<sup>20</sup> . O Quadro 2 define a poliúria conforme a idade do paciente.  
**Quadro 2** – Definição de poliúria conforme a idade do paciente.  
|**Idade do paciente**|**Volume de diurese**|
|---|---|
|Ao nascimento|Maior que 150 mL/kg/dia ou<br>Maior que 6 mL/kg/hora|
|Até 2 anos|Maior que 100 mL/kg/dia ou<br>Maior que 4 mL/kg/hora|
|Acima de 2 anos|Maior que 50 mL/kg/dia ou<br>Maior que 2 mL/kg/hora|  
Fonte: Di Iorgi et al, 2012.  
3  
O aumento do volume urinário, que pode chegar a 18 litros em 24 horas, é compensado com o aumento da ingestão hídrica. Em pacientes sem acesso livre a água (por exemplo, sedados), com alteração hipotalâmica no centro da sede (por exemplo, lesões hipotalâmicas) ou com grande volume urinário, pode haver distúrbios hidroeletrolíticos graves<sup>21</sup> .

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3.2. Diagnóstico laboratorial** -->
A abordagem diagnóstica do DI envolve três etapas:  
a) confirmação de poliúria hipotônica;  
b) diagnóstico do tipo de síndrome de poliúria hipotônica-polidipsia;  
c) identificação da etiologia subjacente.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3.2.1. Confirmação de poliúria hipotônica** -->
Após a confirmação da poliúria a partir da avaliação clínica, deve-se realizar o diagnóstico laboratorial que consiste na diferenciação entre a poliúria resultante da diurese osmótica (como na hiperglicemia) e poliúria hipotônica (DI ou polidipsia primária). Considera-se que o sódio sérico se apresenta com valores baixos quando a dosagem corresponde a valores <u>< 135</u> mmol/L. Para osmolalidade, considera-se valores baixos como aqueles < 280 mOsm/kg. Além dos valores de referência para confirmação da poliúria em crianças especificados no Quadro 1, os valores que indicam poliúria em adultos são aqueles > 40 mL/kg/dia ou > 3 L ao dia.  
Deve-se descartar também o uso de medicamentos que possam causar poliúria, como diuréticos ou inibidores do cotransportador de sódio-glicose-2 (SGLT-2). Além disso, deve-se monitorar o balanço combinado dos volumes hídrico e urinário por 24 horas e, paralelamente, realizar as avaliações clínica e laboratorial<sup>22</sup> . As dosagens de glicemia, ureia, creatinina, cálcio, potássio, sódio séricos e osmolaridades sérica e urinária devem ser realizadas para descartar o diagnóstico de diabete melito, insuficiência renal intrínseca e DI nefrogênico induzido por hipercalcemia ou hipocalemia<sup>1</sup> .

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3.2.2. Diagnóstico do tipo de síndrome de poliúria hipotônica-polidipsia** -->
No diagnóstico diferencial entre DI e polidipsia primária, pode ser necessário realizar teste de restrição hídrica e o teste da desmopressina (DDAVP), disponíveis para a investigação do DI. Para sua realização, sugere-se internação hospitalar, pelo risco de desidratação e de distúrbios hidroeletrolíticos graves. O princípio básico do teste da privação de água no diagnóstico diferencial da síndrome de poliúria hipotônica-polidipsia é que, em indivíduos com funções normais de hipófise posterior e renal, um aumento na osmolalidade plasmática decorrente da desidratação estimula a liberação de AVP, aumentando a reabsorção de água na néfrons, resultando em concentração da urina e aumento da osmolalidade urinária. Geralmente, um teste de privação hídrica de 7 horas é adequado para diagnosticar DI<sup>1</sup> . O Apêndice 2 apresenta uma proposta de modelo para a anotação dos parâmetros avaliados durante a realização do teste de restrição hídrica.  
A **osmolalidade é definida como o número de partículas diluídas por quilo de água** (mmol/kg ou mOsm/kg) e a **osmolaridade** representa o número de solutos por litro de água (mmol/L ou mOsm/L). Como a osmolaridade é influenciada pela quantidade de água presente nos fluidos, considera-se que o conceito da osmolalidade seja mais preciso. A osmolalidade normal do fluido extracelular é 275 a 295 mOsm/kg<sup>23</sup> . As osmolalidades sérica e urinária são mensuradas laboratorialmente por meio de um osmômetro, enquanto a osmolaridade é calculada a partir das concentrações séricas e urinárias do sódio (Na<sup>+</sup> ) e seus ânions associados, potássio (K<sup>+</sup> ), glicose e ureia<sup>24,25</sup> .  
As seguintes fórmulas são aceitas como adequadas para o cálculo das osmolaridades sérica e urinária, respectivamente.  
**Osmolaridade sérica** (mOsm/L) = 2(Na<sup>+</sup> ) + Glicose (mg/dL)/18 + Ureia (mg/dL)/6  
**Osmolaridade urinária** (mOsm/L) =  
~~4~~  
2(Na<sup>+</sup> + K<sup>+</sup> urinários [mEq/L]) + Ureia urinária (mg/dL)/5.8 + Glicose urinária (mg/dL)/18  
A osmolalidade urinária, a osmolalidade plasmática e o sódio plasmático são critérios indicativos de encerramento do teste. Em adultos, o teste de restrição hídrica deve ser interrompido quando um dos seguintes desfechos é alcançado<sup>22</sup> :  
- Sódio sérico superior a 145 mEq/L; ou  
- Osmolalidade urinária atinge o intervalo de referência normal.  
- Osmolalidade urinária permanecer estável em duas ou três medições consecutivas por hora, mesmo com o aumento  
- da osmolalidade plasmática; ou  
- Osmolaridade plasmática for superior a 295 a 300 mOsmol/kg.  
Em crianças, o teste de restrição hídrica deve ser monitorado de perto, devendo ser interrompido ao atingir um dos seguintes desfechos<sup>22</sup> :  
- Perda de 3 a 5% do peso corporal ou sinais clínicos de depleção de volume; ou  
- Sódio plasmático superior a 145 mEq/L; ou  
- Osmolalidade urinária no intervalo de referência normal; ou  
- Osmolalidade plasmática superior a 295-300 mOsmol/kg.  
Valores de osmolalidade urinária acima de 600 mOsm/kg indicam adequada produção e ação do ADH, e valores acima de 800 mOsm/kg afastam com grande grau de certeza o diagnóstico de DI<sup>22</sup> . No DI central ou nefrogênico, a urina não atingirá a concentração ideal com a privação de água, havendo excreção persistente de urina hipotônica. Para diferenciar diabete insípido central e nefrogênico e polidipsia primária, poderá ser necessária a realização de um teste de privação de água e teste de DDAVP. Em casos de polidipsia primária podem ser necessários períodos de desidratação mais longos<sup>22</sup>

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3.2.3. Identificação da Etiologia Subjacente** -->
Uma vez estabelecido o diagnóstico de DI, a administração de desmopressina pode distinguir a DI central e a nefrogênica. No DI central, uma vez que a ação deficiente da AVP é substituída pela administração de desmopressina, a osmolalidade urinária deve aumentar, enquanto no DI nefrogênico, como a desmopressina é ineficaz por falta de resposta renal às suas ações, persistirá a baixa osmolalidade urinária. Se houver suspeita de diabete insípido nefrogênico em recém-nascidos e lactentes, o teste diagnóstico de escolha é o DDAVP (1 mcg por via subcutânea ou intravenosa em 20 minutos, dose máxima de 0,4 mcg/kg)<sup>22</sup> . Destaca-se que, para verificar a variação na osmolaridade urinária, é importante o esvaziamento vesical completo no momento da administração da desmopressina.  
Após a administração da desmopressina na dose de 10 mcg por via nasal ou 4 mcg por via subcutânea em adolescentes e adultos e 5 a 10 mcg por via nasal ou 1 mcg por via subcutânea em crianças, o teste prossegue com monitorização de osmolalidade e volume urinários de 30 em 30 minutos nas 2 horas subsequentes. Transcorridas 2 horas da administração da desmopressina, o teste é encerrado, sendo permitido ao paciente ingerir líquidos livremente. O Apêndice 2 apresenta um modelo para a anotação dos parâmetros avaliados após a administração de desmopressina no teste de restrição hídrica.  
Em relação à osmolalidade urinária, a resposta à administração de desmopressina costuma ser de aumento de:  
- 100% nos pacientes com DI central completo<sup>4,22</sup> ;  
- 15% a 50% nos pacientes com DI central parcial<sup>4,22</sup> ;  
- 10% a 45% nos pacientes com DI renal parcial<sup>4</sup> ;  
- menos de 10% nos pacientes com DI renal completo<sup>4</sup> .  
5  
Em alguns pacientes os resultados do teste podem não ser inequívocos e, por isso, o teste de restrição hídrica deve ser feito por pessoas com experiência na sua realização e na interpretação dos dados. Além disso, existe uma faixa de resposta à administração de desmopressina em que o resultado pode não diferenciar entre DI central ou renal, nas suas formas parciais. Nesses pacientes, a avaliação da variação em percentual e dos números absolutos pode ajudar na distinção da DI central e DI renal: pacientes com DI central geralmente atingem osmolalidade urinária maior do que 300 mOsm/kg após a desmopressina, enquanto os pacientes com DI nefrogênico tipicamente têm uma urina persistentemente diluída e, apesar de apresentarem osmolalidade elevada com a administração da desmopressina, dificilmente chegam aos níveis de DI central.  
Além disso, dados da história clínica do paciente também podem ajudar nessa diferenciação. A velocidade de instalação dos sintomas é importante, visto que, na maioria dos pacientes com DI renal hereditário, a manifestação se verifica já na primeira semana de vida. Nos casos de DI central hereditário, a manifestação pode ocorrer na infância após o primeiro ano de vida ou na adolescência. Em adultos, o início dos sintomas costuma ocorrer de forma súbita, nos casos de DI central e de forma insidiosa, nos casos de DI renal<sup>3</sup> .  
<mark>A copeptina, que é a parte C-terminal do peptídeo precursor da vasopressina (AVP), é liberada em quantidades iguais à AVP pela hipófise. Ela tem sido utilizada como um novo marcador para diagnosticar os diversos estados poliúricos hipotônicos</mark><sup>3,26</sup> . <mark>A observação de que a copeptina reflete as concentrações circulantes de AVP sensíveis à osmolaridade torna-a um biomarcador promissor para o diagnóstico diferencial da síndrome de polidipsia-poliúria</mark><sup>27</sup> <mark>.</mark> Estudos iniciais indicam que a copeptina é um biomarcador para diagnosticar a DI, com níveis acima de 21,4 pmol/L, com 100% de sensibilidade e especificidade<sup>28,29</sup> . Dois estudos<sup>28,30</sup> <mark>comparando a performance diagnóstica da copeptina estimulada com retenção hídrica para diferenciar polidipsia primária de AVP-D parcial e completa (anteriormente chamada de DI craniana ou DI central) em pacientes adultos variaram de 95% a 98% para sensibilidade e de 5% a 81% para especificidade (214 pacientes)</mark><sup>31</sup> . <mark>Em crianças, a performance diagnóstica para a estimulação da copeptina, quando comparada ao teste de retenção hídrica para diferenciar polidipsia primária de AVP-D parcial e completa, foi de 83% para sensibilidade e de 75% para especificidade (80 pacientes). Embora esses níveis de copeptina antes de testes de privação de água ou estímulos eliminem a necessidade de exames adicionais para DI nefrogênica, eles não diferenciam a DI central de pacientes com polidipsia primária devido à significativa sobreposição. Portanto, testes de estímulo são necessários para diferenciar esses casos</mark><sup>3</sup> . É importante destacar que a dosagem de copeptina não é recomendada neste Protocolo, uma vez que não há valores de referência consolidados atualmente disponíveis na literatura, principalmente para crianças.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3.3. Exames de imagem** -->
Todos os pacientes com diagnóstico de DI central devem submeter-se a ressonância magnética da região hipotalâmicohipofisária para investigação etiológica e para afastar a presença de tumor<sup>3,32</sup> . Outro dado importante fornecido pela ressonância magnética é a ausência do brilho na hipófise posterior em T1, que ocorre mais frequentemente em pacientes com DI<sup>3</sup> .

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3.4. Algoritmo diagnóstico da DI** -->
Na Figura 1 é apresentado o algoritmo diagnóstico da DI.  
6  
**Figura 1** - Algoritmo diagnóstico da diabete insípido.  
<!-- Start of picture text -->
Paciente com suspeita de politiria hipoténica<br>sim confirmada,Polina N3o<br>conforme idade'?<br>Veriicar a osmolalidade diabeteDiagnésticoinsipido edede<br>vrindria polidispsiadescartadosprimaria<br>Menor que 800 Maior<br>mOsmikg<br>mOsmvkg que 800<br>(menorSédioou igualséricoa 135baixommol/L)  Sédlo sérteo ou Osrnoieiancal (maior‘Sédioou igualsérico a 146elevadommoVL)<br>ou . ou<br>‘Osmolalidade plasmatica baixa Plaemilica nomnas (Osmolalidade plasmatica elevada<br>(menor ou igual a 280 mOsmkg) (maior ou igual a 300 mOsmikg)<br>cs) RS<br>Realzar<br>testehidricade restrico<br>Osmolalidade‘que 800 mOsm/kgurindria maior Osmolalidade‘até 800 mOsmikgurindria maior<br>Polidipsia priméria Realzar teste de estimulo com<br>discreta desmopressin<br>‘Aumento‘osmotalidademaiorurindraque 50% inicialda ‘osmotalidade‘Aumentomenor que 50% urindra iniialda<br>ae Diabete insipido<br>* Critérios de polidria, conforme idade:<br>Ao nascimento: Maior que 150 mL/kg/dia ou maior que 6 mL/kg/hora<br>Até 2 anos: Maior que 100 mLikg/dia ou maior que 4 mL/kg/hora<br>Acima de 2 anos: Maior que 50 mL/kg/dia ou maior que 2 mLkg/hora<br><!-- End of picture text -->  
Fonte: Adaptado de Gubbi e colaboradores, 2022.<sup>33</sup>

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Devem ser incluídos nesse Protocolo os pacientes com diagnóstico de DI central, considerando os dois critérios a seguir:  
7  
- Poliúria é caracterizada por um volume urinário superior a 3 litros (ou mais de 40 mL/kg) em 24 horas em adolescentes e adultos. Em pediatria, a definição de poliúria varia conforme a idade e a superfície corporal do paciente, sendo definida como: maior que 150 mL/kg/dia ao nascimento, maior que 100 mL/kg/dia em pacientes até 2 anos de idade e maior que 50 mL/kg/dia em pacientes acima de 2 anos; e  
- Resposta à administração de desmopressina na vigência de osmolalidade plasmática acima de 295 mOsm/kg ou sódio plasmático acima de 145 mEq/L, com aumento na osmolalidade urinária acima de 15% e osmolalidade urinária acima de 300 mOsm/kg.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Devem ser excluídos deste Protocolo os pacientes com que apresentarem resistência, hipersensibilidade ou intolerância à desmopressina.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **6. CASOS ESPECIAIS** -->
Pacientes com DI gestacional que atendam aos critérios de inclusão deverão receber tratamento ao longo da gestação até a normalização do quadro, conforme especificado na seção Monitoramento, e ser monitorizadas após o parto para identificar-se a necessidade de manutenção do uso de desmopressina. As doses necessárias para o tratamento são semelhantes às utilizadas no caso de outras causas de DI e devem ser ajustadas conforme débito urinário e dosagem de sódio sérico<sup>34,35</sup> . Pacientes pósressecção hipofisária por tumor serão tratados se apresentarem os critérios de inclusão do Protocolo.  
Em neonatos e lactentes, o diagnóstico de DI apresenta maiores dificuldades, em especial porque a avaliação do débito urinário não é fácil, sendo habitualmente feita por pesagem de fraldas, o que nem sempre é confiável, por misturar fezes e urina e inviabilizar a aferição correta da diurese. Então, nesses casos, o diagnóstico não requer a comprovação de poliúria, sendo feito quando o indivíduo apresentar hipernatremia (nível sérico de sódio maior ou igual a 146 mEq/L), associada a uma osmolalidade urinária inapropriadamente baixa (menor que 300 mOsm/kg), com resposta positiva ao DDAVP (osmolalidade urinária maior que 750 mOsm/kg)<sup>36</sup> . Dessa forma, a limitação de aferição da diurese, própria dessa faixa etária, é eliminada, ao mesmo tempo em que o diagnóstico do DI central seria possibilitado pela utilização dos critérios laboratoriais descritos.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **7.1. Tratamento não medicamentoso** -->
Além do tratamento medicamentoso, um ponto importante do tratamento do DI é orientar o paciente a evitar a ingestão de líquidos por qualquer outra razão que não seja saciar a sede. Esses pacientes, diferentemente dos indivíduos sem DI, não conseguem aumentar o débito urinário de forma rápida e, com isso, podem sofrer intoxicação hídrica em situações em que ingerem muito líquido sem sede. Um ponto complementar na orientação desses pacientes é evitar a diminuição do débito urinário abaixo do normal (15 a 30 mL/kg/dia)<sup>34</sup> .  
Para o controle de desidratação severa em pacientes com DI, recomenda-se o uso de soluções hipotônicas, seja por via enteral (como água ou leite) ou intravenosa (como dextrose a 5% em água). A dosagem da infusão intravenosa deve ser ajustada para exceder a produção de urina por hora, visando a corrigir o déficit total de água no corpo. Considerando a associação entre desidratação hipernatrêmica e condições como estados hipercoaguláveis, trombose venosa e embolia  
8  
pulmonar — especialmente em pacientes imobilizados, a administração profilática de heparina de baixo peso molecular subcutânea é vital até que se alcance a eunatremia<sup>3</sup> .

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **7.2. Tratamento medicamentoso** -->
A desmopressina é um análogo sintético do AVP que atua especificamente no receptor V2, com uma meia-vida de 6 a 8 horas, tendo um maior tempo de ação, maior potência antidiurética e menor efeito pressórico quando comparado ao hormônio antidiurético (ADH)<sup>27,34</sup> . O tratamento do DI com desmopressina considera o resultado observado em séries de casos. O primeiro relato de seu uso no tratamento de DI central envolveu uma série de 10 pacientes com a condição<sup>15</sup> . Nesse estudo, que utilizou como controles os dados históricos dos dez pacientes no período em que usavam o ADH como tratamento, a desmopressina mostrou-se segura e apresentou vantagens em relação ao ADH, principalmente quanto ao número de aplicações do medicamento (6 a 10 doses/dia com ADH e 1 a 3 doses/dia com desmopressina) e aos eventos adversos (comuns com ADH e não detectados com desmopressina)<sup>15</sup> . Pela inequívoca demonstração de tratar-se de um medicamento com perfil de segurança e efetividade favoráveis, a desmopressina no tratamento do DI central foi amplamente adotada, não existindo ensaios clínicos randomizados comparando ADH e desmopressina no tratamento da doença. A desmopressina, que é um peptídio resistente à ação das vasopressinases placentárias, é também o tratamento de escolha no DI gestacional<sup>11</sup> , com dados de segurança favoráveis tanto para a gestante como para o feto<sup>37</sup> .  
Quando o medicamento é utilizado por via oral, a dose de desmopressina é maior em relação ao seu uso por via nasal<sup>38</sup> . No entanto, inexistem evidências sobre a correlação de dose quando há troca da via de administração utilizada, devendo haver titulação de dose, com controle clínico de diurese, de ingesta hídrica e de eletrólitos durante esta transição<sup>39,40,41</sup> .

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **7.2.1.  Medicamentos** -->
- Desmopressina: solução nasal de 0,1 mg/mL ou 100 mcg/mL (em solução ou spray) ou comprimidos de 0,1 e 0,2 mg.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **7.2.2.  Esquemas de administração** -->
Há duas formas comerciais disponíveis de aplicação nasal de desmopressina: a aplicação por meio de túbulo plástico (ou cânula) e o spray, que apresentam algumas particularidades quanto à sua administração.  
No primeiro caso, o túbulo plástico deve ser preenchido com a dose a ser utilizada, por capilaridade, encostando uma ponta do túbulo na solução contida no frasco. Após assegurar-se de que a dose está correta, uma das extremidades do túbulo é colocada na cavidade nasal, e outra, na boca do paciente. Através da extremidade colocada na boca, o medicamento é soprado para a cavidade nasal, onde é absorvido. Já a aplicação por spray nasal é realizada através de jato nasal com dose fixa de 10 mcg/jato.  
O uso do spray nasal é mais simples e fornece doses fixas múltiplas de 10 mcg (por exemplo, 10, 20, 30 mcg). Já a solução nasal possibilita a aplicação de doses múltiplas de 5 mcg (por exemplo, 5, 10, 15, 20 mcg), o que pode ser mais adequado para alguns pacientes, principalmente para os pediátricos. Portanto, o spray nasal não permite a flexibilidade das doses que a solução nasal possibilita.  
A dose inicial de desmopressina de aplicação nasal recomendada é de 10 mcg em adultos e adolescentes e de 5 mcg em crianças. Sugere-se que a dose inicial seja administrada à noite e que o incremento gradual no número de aplicações e na dose seja feito de forma individualizada, de acordo com a resposta do paciente. Existem graus muito variáveis de deficiência do ADH, o que repercute na variabilidade da dose de manutenção da desmopressina. A dose de manutenção com a desmopressina  
9  
solução nasal varia de 5 a 20 mcg, uma a três vezes ao dia; já para a desmopressina spray nasal, 10 a 20 mcg, uma a três vezes ao dia.  
Em neonatos e lactentes, a dose de desmopressina inicialmente prescrita por via intranasal é de 2,5 mcg. Caso o recémnascido com DI central seja prematuro ou de baixo peso, doses ainda menores podem ser necessárias.  
Existe também a apresentação oral de desmopressina, disponível no Brasil em forma de comprimidos. Apesar da absorção desse medicamento ser diminuída, quando tomado com as refeições, isso não parece diminuir a sua eficácia antidiurética. A potência dessa apresentação é cerca de 10 a 20 vezes menor que a forma nasal, uma vez que apenas 5% é absorvido pelo trato digestivo. Dessa forma, as doses utilizadas com a apresentação oral são maiores do que aquelas da apresentação nasal: dose inicial 0,05 a 0,1 mg, com ajuste de dose semelhante ao da preparação nasal. A dose de manutenção varia de 0,1 a 1,2 mg/dia, dividida em duas a três administrações por dia<sup>42</sup> .

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **7.2.3.  Eventos adversos** -->
Os eventos adversos mais comuns do medicamento desmopressina são dor de cabeça, cansaço, náusea, dor no estômago, dor e sangramento nasal, dor de garganta, queda da pressão com aumento dos batimentos cardíacos, vermelhidão da face, hipersensibilidade. Outros eventos adversos possíveis são: hiponatremia, vômito, aumento de peso, mal-estar, dor abdominal, câimbras musculares, tontura, confusão, diminuição de consciência, edemas locais ou generalizados (periféricos, faciais) e, em casos graves, edemas cerebrais, encefalopatia hiponatrêmica, convulsões e coma.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **7.2.4. Critérios de interrupção- tempo de tratamento** -->
O tratamento do DI central deve ser mantido por toda a vida, visto que a suspensão do uso de desmopressina pode causar risco ao paciente. No entanto, seu uso pode ocasionar retenção hídrica e consequentes hiponatremia e ganho de peso, o que, em casos mais graves, pode resultar em convulsões. Dores de cabeça, náusea e hipotensão transitória são eventos adversos que ocorrem com menor frequência.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **7.2.5. Benefícios esperados** -->
- Melhorar sintomas e qualidade de vida.  
- Reduzir complicações decorrentes de distúrbios eletrolíticos em pacientes com deficiências graves da AVP.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **8. MONITORAMENTO** -->
O acompanhamento do tratamento do DI central deve basear-se em critérios clínicos e laboratoriais. Clinicamente, é importante avaliar o controle da noctúria e do volume urinário ao longo do dia, tendo como parâmetro a satisfação do paciente no controle desses sintomas. Laboratorialmente, deve-se realizar o controle do sódio plasmático com o objetivo de mantê-lo entre 137 e 145 mEq/L.  
Sugere-se que o início do tratamento e a definição da posologia da desmopressina sejam feitos com o paciente internado, com controle de volume de diurese e natremia diários, devido ao risco de desenvolvimento de hiper- ou hiponatremia nesse período. Após estabilização do volume urinário e do sódio plasmático, o acompanhamento ambulatorial deve ser realizado, com avaliação clínica e sódio plasmático em intervalos de até 6 a 12 meses. Em especial, pacientes com quadro estabilizado e com diagnóstico podem ter avaliações anuais.  
10

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento (s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Pacientes com diabete insípido devem ser atendidos em serviços especializados com endocrinologia ou nefrologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento. É fundamental uma avaliação periódica em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica.  
Os gestores estaduais e municipais devem estruturar a rede assistencial, definindo os serviços de referência e os fluxos de atendimento em cada região. A comunicação entre os diferentes níveis de atenção é fundamental. O especialista deve dialogar com o profissional da APS para o acompanhamento do paciente, e a equipe da assistência farmacêutica precisa garantir a dispensação adequada do medicamento.  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente, em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **11. REFERÊNCIAS** -->
1. Patti G, Napoli F, Fava D, Casalini E, Di Iorgi N, Maghnie M. Approach to the pediatric patient: central diabetes insipidus. J Clin Endocrinol Metab. 2022;107(5):1407–16.  
2. Majzoub JA, Srivatsa A. Diabetes insipidus: clinical and basic aspects. Pediatr Endocrinol Rev. 2006;4:60–5. 3. Christ‐Crain M, Winzeler B, Refardt Jjj. Diagnosis and management of diabetes insipidus for the internist: an update. J Intern Med. 2021;290(1):73–87.  
4. Sands JM, Bichet DG. American college of physicians; American physiological society. Nephrogenic diabetes insipidus. Ann Intern Med. 2006;144(3):186–94.  
5. Fenske W, Allolio B. Current state and future perspectives in the diagnosis of diabetes insipidus: a clinical review. J Clin Endocrinol Metab. 2012;97(10):3426–37.  
6. Schrier RW. Body water homeostasis: clinical disorders of urinary dilution and concentration. Journal of the American Society of Nephrology. 2006;17(7):1820–32.  
7. Jane Jr JA, Laws MLVR. Neurogenic diabetes insipidus. Pituitary. 2006;9(4):327.  
8. Oiso Y, Robertson GL, Nørgaard JP, Juul KV. Treatment of neurohypophyseal diabetes insipidus. J Clin Endocrinol Metab. 2013;98(10):3958–67.  
9. Shlomo Melmed. The posterior pituitary. The Pituitary 5th. . 2022. 257–297 p.  
11  
10. Marques P, Gunawardana K, Grossman A. Transient diabetes insipidus in pregnancy. Endocrinol Diabetes Metab Case Rep. 2015;2015(1).  
11. Kalelioglu I, Kubat Uzum A, Yildirim A, Ozkan T, Gungor F, Has R. Transient gestational diabetes insipidus diagnosed in successive pregnancies: review of pathophysiology, diagnosis, treatment, and management of delivery. Pituitary. 2007;10:87–93.  
12. Mutter CM, Smith T, Menze O, Zakharia M, Nguyen H. Diabetes insipidus: pathogenesis, diagnosis, and clinical management. Cureus. 2021;13(2).  
13. Mavrakis AN, Tritos NA. Diabetes insipidus with deficient thirst: report of a patient and review of the literature. American journal of kidney diseases. 2008;51(5):851–9.  
14. Kim RJ, Malattia C, Allen M, Moshang Jr T, Maghnie M. Vasopressin and desmopressin in central diabetes insipidus: adverse effects and clinical considerations. Pediatr Endocrinol Rev. 2004;2:115–23.  
15. Andersson K, Arner B. Effects of DDAVP, a synthetic analogue of vasopressin, in patients with cranial diabetes insipidus. Acta Med Scand. 1972;192(1‐6):21–7.  
16. Brasil. Ministério da Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas. 2023;  
17. Group GW. Grading quality of evidence and strength of recommendations. Bmj. 2004;328(7454):1490.  
18. RIZZO WB, KAPLOWITZ PB. Metabolic and Endocrine Disorders. In: Neurologic Emergencies in Infancy and Childhood. Elsevier; 1993. p. 310–43.  
19. Duicu C, Pitea AM, Săsăran OM, Cozea I, Man L, Bănescu C. Nephrogenic diabetes insipidus in children. Exp Ther Med. 2021;22(1):1–6.  
20. Di Iorgi N, Napoli F, Allegri AEM, Olivieri I, Bertelli E, Gallizia A, et al. Diabetes insipidus–diagnosis and management. Horm Res Paediatr. 2012;77(2):69–84.  
21. Mavrakis AN, Tritos NA. Diabetes insipidus with deficient thirst: report of a patient and review of the literature. American journal of kidney diseases. 2008;51(5):851–9.  
22. Hui C, Khan M, Suheb MZK, Radbel JM. Arginine Vasopressin Disorder (Diabetes Insipidus).  
23. Büyükkaragöz B, Bakkaloğlu SA. Serum osmolality and hyperosmolar states. Pediatric Nephrology. 2023;38(4):1013–25.  
24. Youhanna S, Bankir L, Jungers P, Porteous D, Polasek O, Bochud M, et al. Validation of surrogates of urine osmolality in population studies. Am J Nephrol. 2017;46(1):26–36.  
25. Bhasin B, Velez JCQ. Evaluation of polyuria: the roles of solute loading and water diuresis. American Journal of Kidney Diseases. 2016;67(3):507–11.  
26. Mu D, Ma Y, Cheng J, Qiu L, Chen S, Cheng X. Diagnostic Accuracy of Copeptin in the Differential Diagnosis of patients with Diabetes Insipidus: A Systematic Review and Meta-analysis. Endocrine Practice. 2023;  
27. Christ-Crain M, Gaisl O. Diabetes insipidus. Presse Med. 2021;50(4):104093.  
28. Fenske W, Quinkler M, Lorenz D, Zopf K, Haagen U, Papassotiriou J, et al. Copeptin in the differential diagnosis of the polydipsia-polyuria syndrome—revisiting the direct and indirect water deprivation tests. J Clin Endocrinol Metab. 2011;96(5):1506–15.  
29. Timper K, Fenske W, Kühn F, Frech N, Arici B, Rutishauser J, et al. Diagnostic accuracy of copeptin in the differential diagnosis of the polyuria-polydipsia syndrome: a prospective multicenter study. J Clin Endocrinol Metab. 2015;100(6):2268–74.  
30. Fenske W, Refardt J, Chifu I, Schnyder I, Winzeler B, Drummond J, et al. A copeptin-based approach in the diagnosis of diabetes insipidus. New England Journal of Medicine. 2018;379(5):428–39.  
12  
31. Tuli G, Tessaris D, Einaudi S, Matarazzo P, De Sanctis L. Copeptin role in polyuria‐polydipsia syndrome differential diagnosis and reference range in paediatric age. Clin Endocrinol (Oxf). 2018;88(6):873–9.  
32. Bichet D. Arginine vasopressin deficiency (central diabetes insipidus): Etiology, clinical manifestations, and postdiagnostic evaluation. UpToDate. Disponível em: https://www.uptodate.com/contents/arginine-vasopressindeficiency-central-diabetes-insipidus-etiology-clinical-manifestations-and-postdiagnostic-  
evaluation?source=mostViewed_widget. 2023.  
33. Gubbi S HSFKCVJ. Diagnostic Testing for Diabetes Insipidus. Endotext [Internet] South Dartmouth (MA): MDText.com, Inc; 2000. 2022;  
34. Oiso Y, Robertson GL, Nørgaard JP, Juul KV. Treatment of neurohypophyseal diabetes insipidus. J Clin Endocrinol Metab. 2013;98(10):3958–67.  
35. Yanagisawa S, Oikawa Y, Endo M, Inoue K, Nakajima R, Yasuda S, et al. A Pregnant Woman with Excess Vasopressinase-Induced Diabetes Insipidus Complicated by Central Diabetes Insipidus like Lymphocytic InfundibuloNeurohypophysitis. Case Rep Endocrinol. 2024.  
36.     Djermane A, Elmaleh M, Simon D, Poidvin A, Carel JC, Léger J. Central Diabetes Insipidus in Infancy With or Without Hypothalamic Adipsic Hypernatremia Syndrome: Early Identification and Outcome. J Clin Endocrinol Metab. 2016 Feb;101(2):635-43  
37 . Ray JG. DDAVP use during pregnancy: an analysis of its safety for mother and child. Obstet Gynecol Surv. 1998;53(7):450–5.  
38.     Pedersen AN, Andreassen M, Rasmussen AK, Krogh J. Desmopressin dose requirements in adults with congenital and acquired central diabetes insipidus. Horm Metab Res. 2024 Mar;56(3):206-213. doi:10.1055/a-21987207  
39 <mark>.     G</mark> arrahy A, Thompson CJ. Management of central diabetes insipidus. Best Pract Res Clin Endocrinol Metab. 2020;101385. doi:10.1016/j.beem.2020.101385.  
40 <mark>.     F</mark> ukuda I, Hizuka N, Takano K. Oral DDAVP is a good alternative therapy for patients with central diabetes insipidus: experience of five-year treatment. Endocr J. 2003 Aug;50(4):437-43. doi:10.1507/endocrj.50.437.. 41 <mark>.    M</mark> avinkurve M, McGrath N, Johnston N, et al. Oral administration of diluted nasal desmopressin in managing neonatal central diabetes insipidus. J Pediatr Endocrinol Metab. 2017 May 24;30(6):623-628. doi:10.1515/jpem-20170051.  
42.    Bichet D. Treatment of central diabetes insipidus [Internet]. UpToDate; 2016. [acesso em 17/07/2024]. Disponível em https://www.uptodate.com/contents/treatment-of-central-diabetes-insipidus.  
43. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 2, de 28 de setembro de 2017, e Portaria de Consolidação GM/MS n<sup>o</sup> 6, de 28 de setembro de 2017.  
13

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **DESMOPRESSINA** -->
Eu,________________________________________________________________________________________ (nome da(o) paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos  
relacionados ao uso de **desmopressina** , indicada para o tratamento de **diabete insípido.**  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) _____________________  
____________________________________________________________________________________________ (nome  
do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas e da qualidade de vida dos pacientes;  
- diminuição das complicações mais graves.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- •Medicamento desmopressina: medicamentos classificados na gestação como categoria B.  
•Os eventos adversos mais comuns do medicamento desmopressina são dor de cabeça, cansaço, náusea, dor no estômago, dor e sangramento nasal, dor de garganta, queda da pressão com aumento dos batimentos cardíacos, vermelhidão da face, reações alérgicas.  
•Esse medicamento pode causar hiponatremia, que pode causar dores de cabeça, náusea, vômito, intoxicação por água, aumento de peso, mal-estar, dor abdominal, câimbras musculares, tontura, confusão, diminuição de consciência, edemas locais ou generalizados (periféricos, faciais), e em casos sérios edemas cerebrais, encefalopatia hiponatrêmica, convulsões e coma. Consultas e exames durante o tratamento são necessários.  
• A ingestão de líquidos deverá ser controlada de acordo com as orientações do médico para evitar intoxicação por excesso de líquidos e hiponatremia (diminuição do sódio).  
•Esse medicamento é contraindicado em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
(    ) desmopressina  
14  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
15

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo desenvolvedor da elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Diabete Insípido (DI) contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados. O público-alvo deste PCDT é composto por profissionais da saúde envolvidos no atendimento de pacientes com DI, como endocrinologistas, nefrologistas, médico da família ou clínicos gerais.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos <mark>endocrinologistas e nefrologistas.</mark>  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
O escopo do PCDT foi estabelecido em reunião que ocorreu em 21 de julho de 2023 com representantes do Ministério da Saúde, representantes de pacientes, especialistas e com o grupo elaborador.  
A elaboração deste Protocolo foi conduzida com o objetivo de sua atualização e considerou as melhores evidências advinda de ensaios clínicos e revisões sistemáticas para o diagnóstico, tratamento e monitorização desses pacientes.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITIS/SCTIE/MS). O painel de especialistas incluiu médicos da especialidade de endocrinologia.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
**Quadro A -** Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos benefícios abaixo?  
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|  
16  
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|---|---|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de|(   ) Sim|
|alguma tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever<br>e que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|  
17

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Diabete Insípido foi apresentada na 117ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em julho de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde é Ambiente (SVSA). Foram estabelecidas perguntas de pesquisa relativas às abordagens terapêuticas que foram respondidas por um processo de revisão sistemática da literatura, obedecendo a priorização realizada. Também foram apontadas outras questões de interesse a serem respondidas com base nas boas práticas clínicas, mas que não requerem a elaboração de uma revisão sistemática da literatura. O PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **4. Consulta pública** -->
A Consulta Pública nº 55/2024, do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Diabete Insípido, foi realizada entre os dias de 9 de setembro e 30 de setembro de 2024. Foram recebidas 15 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/contribuicao-da-cp-55-de-2024-pcdtdiabete-insipido.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **5. Busca da evidência e recomendações** -->
Foi estabelecido que, para as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS, não seriam objeto de questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas. Deste modo, as evidências em relação à única terapia medicamentosa recomendada neste PCDT foram atualizadas e, caso existissem novos dados, a recomendação seria atualizada.  
- Considerando as dúvidas clínicas discutidas na reunião de escopo, foram elaboradas três perguntas de pesquisa:  
- Deve-se usar desmopressina para o tratamento da DI?  
- O biomarcador copeptina quando comparado a outros biomarcadores, concentração de sódio plasmático,  
- osmolalidade plasmática, e outros testes (ex: restrição hídrica, avaliação clínica) é acurado e seguro para o diagnóstico diferencial do Diabete Insípido?  
- O exame molecular quando comparado a biomarcadores, concentração de sódio plasmático, osmolalidade plasmática, restrição hídrica e avaliação clínica é acurado e seguro para o diagnóstico diferencial do DI em pacientes com suspeita de DI com histórico familiar da doença em que outras causas foram afastadas?  
Para responder as perguntas, foi realizada uma busca prévia na literatura. Os resultados encontrados foram discutidos em reunião.  
Em relação à pergunta, envolvendo a copeptina como um biomarcador utilizado no diagnostico diferencial da DI, os dados apresentaram imprecisão causada pelo pequeno tamanho amostral e as limitações metodológicas dos estudos. Além disso, destaca-se a variabilidade entre os valores de ponto de corte da copeptina. Atualmente, não há um ponto de corte bem definido com relevância clínica.  
18  
Para a pergunta envolvendo o exame de teste molecular, não foram encontradas evidências que subsidiassem o uso deste teste no diagnóstico diferencial em pacientes com suspeita de DI com histórico familiar da doença (DI) em que outras causas foram afastadas.  
A seguir são apresentados, para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações e um resumo das evidências.  
**QUESTÃO 1.** Deve-se usar desmopressina para o tratamento da DI?  
<u>Recomendação:</u> Utilizar desmopressina para o tratamento de pacientes com DI (recomendação não graduada). Essa recomendação já constava no PCDT e foi mantida.  
A estrutura PICO para esta pergunta foi: **População:** Pacientes com diabete insípido **Intervenção:** desmopressina **Comparador:** placebo ou outros tratamentos **Desfechos:** Controle da poliúria e nível sérico de sódio, qualidade de vida, efeitos adversos.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Métodos e resultados da busca** -->
Para a tomada de decisão, foi realizada uma busca por ensaios clínicos randomizados que compararam o uso da desmopressina com o placebo. A busca foi realizada nas bases de dados CENTRAL via Cochrane Library, MEDLINE via Pubmed, Embase via Elsevier em 02 de maio de 2024. As estratégias de busca para cada base estão descritas no **Quadro B** .  
**Quadro B** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o uso da desmopressina em pacientes com DI.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|CENTRAL|#1 MeSH descriptor: [Diabetes Insipidus] explode all trees OR (Diabetes Insipidus OR<br>Diabetes Insipidus Primary Central OR Diabetes Insipidus Secondary To Vasopressin<br>Deficiency OR Pituitary Diabetes Insipidus OR Diabetes Insipidus Cranial<br>Type):ti,ab,kw OR MeSH descriptor: [Diabetes Insipidus, Neurogenic] explode all trees<br>OR Central Diabetes Insipidus OR MeSH descriptor: [Diabetes Insipidus, Nephrogenic]<br>explode all trees OR Vasopressin Defective Diabetes Insipidus<br>#2 MeSH descriptor: [Deamino Arginine Vasopressin] explode all trees OR (Nocutil<br>OR Adiuretin SD OR Desmogalen OR Minurin OR Desmopressin Acetate OR<br>Trihydrate Desmopressin Monoacetate OR Desmopressin Monoacetate, Trihydrate OR<br>Monoacetate, Trihydrate Desmopressin OR Acetate, Desmopressin OR DDAVP OR<br>Octim OR Ferring, Desmopressine OR Desmopressine Ferring OR Desmospray OR<br>Octostim OR Desmotabs OR Minirin OR Adiuretin Vasopressin, Deamino Arginine<br>OR Arginine Vasopressin, Deamino Vasopressin Desmopressin Monoacetate OR|31|  
19  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||Monoacetate, Desmopressin OR Apo-Desmopressin):ti,ab,kw<br>#3 #1 AND #2||
|MEDLINE<br>via Pubmed|"Diabetes Insipidus"[Mesh] OR Diabetes insipidus[tiab] OR Diabetes Insipidus<br>Secondary To Vasopressin Deficiency[tiab] OR Pituitary Diabetes Insipidus[tiab] OR<br>Diabetes Insipidus Cranial Type[tiab] OR "Diabetes Insipidus, Neurogenic"[Mesh] OR<br>Diabetes Insipidus Primary Central[tiab] OR Central Diabetes Insipidus[tiab] OR<br>"Diabetes Insipidus, Nephrogenic"[Mesh] OR Diabetes Insipidus Renalis[tiab] OR<br>Nephrogenic<br>Diabetes<br>Insipidus[tiab]<br>OR<br>Vasopressin<br>Defective<br>Diabetes<br>Insipidus[tiab] AND "Deamino Arginine Vasopressin/therapeutic use"[Mesh] OR<br>Nocutil[tiab] OR Adiuretin SD[tiab] OR Desmogalen[tiab] OR Minurin[tiab] OR<br>Desmopressin Acetate[tiab] OR Trihydrate Desmopressin Monoacetate[tiab] OR<br>Desmopressin<br>Monoacetate,<br>Trihydrate[tiab]<br>OR<br>Monoacetate,<br>Trihydrate<br>Desmopressin[tiab] OR Acetate, Desmopressin[tiab] OR DDAVP[tiab] OR Octim[tiab]<br>OR<br>Ferring,<br>Desmopressine[tiab]<br>OR<br>Desmopressine<br>Ferring[tiab]<br>OR<br>Desmospray[tiab] OR Octostim[tiab] OR Desmotabs[tiab] OR Minirin[tiab] OR<br>Adiuretin Vasopressin, Deamino Arginine[tiab] OR Arginine Vasopressin, Deamino<br>Vasopressin[tiab]<br>OR<br>Desmopressin<br>Monoacetate[tiab]<br>OR<br>Monoacetate,<br>Desmopressin[tiab] OR Apo-Desmopressin[tiab]|956|
|Embase<br>via<br>Elsevier|('diabetes insipidus'/exp OR 'antidiuretic hormone insufficiency' OR 'cerebral diabetes<br>insipidus' OR 'diabetes insipidus' OR 'diabetes spurius' OR 'insipid diabetes' OR<br>'nephrogenic diabetes insipidus'/exp OR 'diabetes insipidus, nephrogenic' OR<br>'nephrogenic diabetes insipidus' OR 'renal diabetes insipidus' OR 'renogenic diabetes<br>insipidus' OR 'neurogenic diabetes insipidus'/exp OR 'diabetes insipidus, neurogenic'<br>OR 'neurogenic diabetes insipidus') AND ('desmopressin'/exp OR '(1 deamino 8 dextro<br>arginine) vasopressin' OR '1 deamine 8 d arginine vasopressin' OR '1 deamino 8 d<br>arginine vasopressin' OR '1 deamino 8 dextro arginine vasopressin' OR '1 desamino 8 d<br>arginine vasopressin' OR '8 (1 desaminoarginine) vasopressin' OR 'ddavp' OR 'ddavp<br>(needs no refrigeration)' OR 'ddavp desmopressin' OR 'ddavp melt' OR 'ddavp nasal'<br>OR 'ddavp rhinal tube' OR 'ddavp tablets' OR '[1 deamino 8 d arginine] vasopressin' OR<br>'[1 deamino 8 dextro arginine] vasopressin' OR '[deamino 8 cysteine d arginine]<br>vasopressin' OR '[deamino 8 cysteine dextro arginine] vasopressin' OR '[deamino 8<br>dextro arginine] vasopressin' OR 'adin' OR 'adiuretin' OR 'adiuretin sd' OR 'adiuretin-sd'<br>OR 'av 002' OR 'av002' OR 'concentraid' OR 'd-void' OR 'dav ritter' OR 'deamino 8|63|  
20  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||dextro arginine vasopressin' OR 'deamino 8d arginine vasopressin' OR 'deamino dextro<br>arginine vasopressin' OR 'deaminovasopressin [8 d arginine]' OR 'defirin' OR 'defirin<br>melt' OR 'desmirin' OR 'desmogalen' OR 'desmomelt' OR 'desmopresina' OR<br>'desmopressin' OR 'desmopressin acetate' OR 'desmopressin acetate (needs no<br>refrigeration)' OR 'desmopressin acetate preservative free' OR 'desmopressin diacetate'<br>OR 'desmopressin nasal solution' OR 'desmopressina' OR 'desmopressine' OR<br>'desmospray' OR 'desmotab' OR 'desmotabs' OR 'desmotabs melt' OR 'desurin' OR<br>'emosint' OR 'enupresol' OR 'fe 992026' OR 'fe992026' OR 'minirin' OR 'minirin ddavp'<br>OR 'minirin melt' OR 'minirin nasal spray' OR 'minirin rhinetten' OR 'minirin rhinyle'<br>OR 'minirin spray' OR 'minirine' OR 'minirinette' OR 'minirinmelt' OR 'minrin' OR<br>'minurin' OR 'minurin flas' OR 'minurin gotas' OR 'miram' OR 'nictur' OR 'niwinas' OR<br>'nocdurna' OR 'noctisson' OR 'noctiva' OR 'nocturin' OR 'nocutil' OR 'nokdirna' OR<br>'noqdirna' OR 'noqturina' OR 'nordurine' OR 'novidin' OR 'nucotil nasenspray' OR<br>'octim' OR 'octostim' OR 'octostim nasal spray' OR 'octostim spray' OR 'presinex' OR<br>'pseurin' OR 'ser 120' OR 'ser120' OR 'stimate' OR 'vasopressin 8 (1 desaminoarginine)'<br>OR 'vasopressin [1 (3 mercaptopropionic acid) 8 dextro arginine]' OR 'vasopressin [1<br>deamino 8 dextro arginine]' OR 'vasopressin [deamino 8 cysteine dextro arginine]' OR<br>'vasopressin [deamino 8 d arginine]' OR 'vasopressin [deamino 8 dextro arginine]' OR<br>'vasopressin [deamino dextro arginine]' OR 'vasopressin, 1 deamino 8 dextro arginine'<br>OR 'vasopressin, deamino 8 dextro arginine' OR 'wetirin') AND 'crossover<br>procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR<br>'single-blind<br>procedure':de<br>OR<br>random*:de,ab,ti<br>OR<br>factorial*:de,ab,ti<br>OR<br>crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR<br>((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR<br>assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti OR 'systematic review'/de<br>OR<br>'systematic<br>review<br>(topic)'/de<br>OR<br>(('comprehensive':ti,ab,kw<br>OR<br>'integrated':ti,ab,kw<br>OR<br>'integrative':ti,ab,kw<br>OR<br>'mapping':ti,ab,kw<br>OR<br>'methodology':ti,ab,kw<br>OR<br>'narrative':ti,ab,kw<br>OR<br>'scoping':ti,ab,kw<br>OR<br>'systematic':ti,ab,kw)<br>AND<br>('search':ti,ab,kw<br>OR<br>'searched':ti,ab,kw<br>OR<br>'searches':ti,ab,kw OR 'studies':ti,ab,kw) AND ('cinahl':ti,ab,kw OR 'cochrane':ti,ab,kw<br>OR<br>'embase':ti,ab,kw<br>OR<br>'psycinfo':ti,ab,kw<br>OR<br>'pubmed':ti,ab,kw<br>OR<br>'medline':ti,ab,kw OR 'scopus':ti,ab,kw OR 'web of science':ti,ab,kw OR 'bibliographic<br>review':ti,ab,kw OR 'bibliographic reviews':ti,ab,kw OR 'literature review':ti,ab,kw OR<br>'literature<br>reviews':ti,ab,kw<br>OR<br>'literature<br>search':ti,ab,kw<br>OR<br>'literature<br>searches':ti,ab,kw OR 'narrative review':ti,ab,kw OR 'narrative reviews':ti,ab,kw OR<br>'qualitative review':ti,ab,kw OR 'qualitative reviews':ti,ab,kw OR 'quantitative||  
21  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||review':ti,ab,kw<br>OR<br>'quantitative<br>reviews':ti,ab,kw))<br>OR<br>'comprehensive<br>review':ti,ab,kw<br>OR<br>'comprehensive<br>reviews':ti,ab,kw<br>OR<br>'comprehensive<br>search':ti,ab,kw OR 'comprehensive searches':ti,ab,kw OR 'critical review':ti,ab,kw OR<br>'critical<br>reviews':ti,ab,kw<br>OR<br>(('electronic<br>database':ti,ab,kw<br>OR<br>'electronic<br>databases':ti,ab,kw OR (databases NEAR/3 searched)) AND (eligibility:ti,ab,kw OR<br>excluded:ti,ab,kw OR exclusion:ti,ab,kw OR included:ti,ab,kw OR inclusion:ti,ab,kw))<br>OR 'evidence assessment':ti,ab,kw OR 'evidence review':ti,ab,kw OR 'exploratory<br>review':ti,ab,kw OR 'framework synthesis':ti,ab,kw OR 'integrated review':ti,ab,kw OR<br>'integrated reviews':ti,ab,kw OR<br>'integrative review':ti,ab,kw OR<br>'integrative<br>reviews':ti,ab,kw OR 'mapping review':ti,ab,kw OR 'meta-review':ti,ab,kw OR 'meta-<br>synthesis':ti,ab,kw<br>OR<br>'methodology<br>review':ti,ab,kw<br>OR<br>'mixed<br>methods<br>review':ti,ab,kw OR 'mixed methods synthesis':ti,ab,kw OR (overview NEAR/4<br>reviews) OR 'prisma':ab OR ('preferred':ti,ab,kw AND reporting:ti,ab,kw) OR<br>'prognostic review':ti,ab,kw OR 'psychometric review':ti,ab,kw OR 'rapid evidence<br>assessment':ti,ab,kw OR 'rapid literature review':ti,ab,kw OR 'rapid literature<br>search':ti,ab,kw OR 'rapid realist':ti,ab,kw OR 'rapid review':ti,ab,kw OR 'rapid<br>reviews':ti,ab,kw OR 'realist review':ti,ab,kw OR 'review of reviews':ti,ab,kw OR<br>'scoping review':ti,ab,kw OR 'scoping reviews':ti,ab,kw OR 'scoping study':ti,ab,kw OR<br>'state of the art review':ti,ab,kw OR 'systematic evidence map':ti,ab,kw OR 'systematic<br>evidence mapping':ti,ab,kw OR 'systematic literature':ti,ab,kw OR 'systematic<br>medline':ti,ab,kw OR 'systematic pubmed':ti,ab,kw OR 'systematic review':ti,ab,kw OR<br>'systematic<br>reviews':ti,ab,kw<br>OR<br>'systematic<br>search':ti,ab,kw<br>OR<br>'systematic<br>searches':ti,ab,kw OR 'systematical literature review':ti,ab,kw OR 'systematical<br>review':ti,ab,kw<br>OR<br>'systematical<br>reviews':ti,ab,kw<br>OR<br>'systematically<br>identified':ti,ab,kw<br>OR<br>'systematically<br>review':ti,ab,kw<br>OR<br>'systematically<br>reviewed':ti,ab,kw OR 'umbrella review':ti,ab,kw OR 'umbrella reviews':ti,ab,kw OR<br>'13616137':is OR 'cochrane database of systematic reviews'/jt<br>FILTER: [embase]/lim NOT ([embase]/lim AND [medline]/lim)||  
Foi utilizado o aplicativo Rayyan<sup>1</sup> para a avaliação de duplicatas dos registros e seleção dos estudos. A seleção dos estudos foi realizada por dois avaliadores independentes. As divergências entre os metodologistas em relação às decisões de inclusão foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
(a) Tipos de participantes  
Pacientes com diabete insípido  
- (b) Tipo de intervenção  
22  
Desmopressina versus placebo ou outros tratamentos  
- (c) Tipos de estudos  
Foram considerados ensaios clínicos randomizados (ECRs), estudos coorte com braço comparador  
- (d) Desfechos  
Controle da poliúria e nível sérico de sódio, qualidade de vida, efeitos adversos.  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Resultados da busca** -->
Foram recuperadas 1050 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas 76 duplicatas e realizada a triagem dos títulos e resumos. Nenhum novo registro foi adicionado à síntese de evidência. O processo de seleção é detalhado na **Figura A** .  
**Figura A** - Fluxograma de seleção dos estudos avaliando o uso da desmopressina comparado ao placebo ou outros tratamentos para DI.  
<!-- Start of picture text -->
Registros identificados nas Registros removidos antes da<br>bases de dados e registros selecdo:<br>(n=1050) Duplicatas removidas (n = 76)<br>Registro rasireados por ttulos © Records .<br>(n =974) (n= 966)<br>F Registros buscados para . 5<br>(n=8)<br>Registros avaliados por meio de Registros excluidos<br>texto completo Nao preenchia 0 PICO<br>(n=8) (n=8)<br>Estudos incluidos na revisio<br>(n=0)<br>Relatos incluidos na revisao<br>(n =0)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Análise e apresentação dos resultados** -->
Foi planejada a avaliação de risco de viés por dois avaliadores. Para Ensaios clínicos randomizados, seria aplicada a ferramenta elaborada pela Cochrane, denominada _Risk of Bias_ (RoB). Para estudos observacionais ou quase randomizados, a ferramenta Robins I. As avaliações seriam realizadas em duplicatas, de forma independente. Além disso, as divergências seriam resolvidas por consenso ou através da consulta com um terceiro revisor.  
23  
Em relação à apresentação dos dados, as variáveis contínuas dos desfechos relatados no estudo incluído seriam descritas como diferenças médias (DM) entre os grupos e as variáveis dicotômicas, como risco relativo (RR), com o respectivo Intervalo de confiança (IC) de 95%.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Resumo das evidências:** -->
A busca não retornou estudo que atendesse a pergunta PICOS envolvendo desmopressina comparado ao placebo ou outro tratamento. O tratamento do DI com desmopressina considerado os resultados em uma série de caso que avaliou os efeitos da desmopressina (DDAVP) em dez pacientes, quatro mulheres e seis homens, com diabete insipido cranial (central). O diagnóstico de DI foi verificado por métodos clínicos e laboratoriais padrão e todos os casos haviam sido tratados anteriormente com vasopressina sintética 8-lisina (LVP), clortalidona e clorpropamida, e demonstraram ser sensíveis à vasopressina. Cinco pacientes receberam 1 ou 2 mcg de DDAVP por via intravenosa, e o efeito dessas doses durou de 5 a mais de 12 horas, em comparação com 45 a 90 minutos para a quantidade correspondente de LVP. Em todos os dez pacientes, a administração intranasal de DDAVP em doses de 15 mcg, uma a três vezes ao dia, normalizou a produção de urina, mesmo em casos em que a terapia anterior havia falhado. Nenhum evento adverso foi observado durante o tratamento com DDAVP por 6 a 12 meses<sup>2</sup> .  
A desmopressina também foi avaliada em uma revisão que incluiu 20 artigos com 53 pacientes que usaram desmopressina durante a gravidez<sup>3</sup> . A dose terapêutica diária de DDAVP foi de aproximadamente 29 mcg por via intranasal (variando de 7,5 a 100 mcg), com controle adequado do diabete insipido observado. Três das 14 mulheres desenvolveram préeclâmpsia, uma diferença não significativa. O modo de parto foi documentado em 22 casos, com 16 partos vaginais sem complicações e seis cesarianas. Não houve evidência de interação medicamentosa entre as cinco mulheres que receberam DDAVP e ocitocina intravenosa. Informações estavam disponíveis sobre 49 nascidos vivos de mães com diabete insipido que utilizaram DDAVP. A idade gestacional média no momento do parto foi de 37,4 semanas (desvio padrão de 1,3 semanas), com um peso médio estimado de 2.963,8 gramas (variando de 2.000 a 4.420 gramas). Quarenta e três crianças foram consideradas saudáveis (taxa de eventos de 87,8%; IC 95% 77,2-95,3%). Dos seis bebês restantes, um desenvolveu diabete insipido aos 18 meses de idade; um segundo nasceu com menos de 2.500 gramas, mas sobreviveu; o terceiro desenvolveu hipotonia e não conseguiu se desenvolver aos 21 meses; dois tinham síndrome de Down; e o sexto morreu de anomalias cardíacas graves. Dados semelhantes foram observados entre os 41 bebês cujas mães usaram DDAVP durante a gravidez<sup>3</sup> .  
**QUESTÃO 2. O biomarcador copeptina quando comparado a outros biomarcadores como a concentração de sódio plasmático, osmolalidade plasmática, e outros testes (ex: restrição hídrica e avaliação clínica) é acurado e seguro para o diagnóstico diferencial do Diabetes Insípido?**  
A estrutura PIRO para esta pergunta foi: **Pacientes:** Pacientes com suspeita de DI  
**Teste índice:** copeptina (biomarcador)  
**Teste padrão:** outros biomarcadores disponíveis no SUS, como concentração de sódio plasmático, osmolalidade plasmática, restrição hídrica e avaliação clínica.  
**_Outcome_ /Desfecho:** especificidade, sensibilidade, valor preditivo positivo e negativo, razão de verossimilhança positiva e negativa e eventos adversos  
24

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Métodos e resultados da busca** -->
Para a tomada de decisão, foi realizada uma busca por ensaios clínicos randomizados que compararam o uso da desmopressina com o placebo. A busca foi realizada nas bases de dados CENTRAL via Cochrane Library, MEDLINE via Pubmed, Embase via Elsevier em 02 de maio de 2024. As estratégias de busca para cada base estão descritas no **Quadro C** .  
**Quadro C** - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o uso da copeptina em pacientes com DI.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|CENTRAL|#1 MeSH descriptor: [Diabetes Insipidus] explode all trees OR (Diabetes Insipidus<br>OR Diabetes Insipidus Primary Central OR Diabetes Insipidus Secondary To<br>Vasopressin Deficiency OR Pituitary Diabetes Insipidus OR Diabetes Insipidus<br>Cranial Type):ti,ab,kw OR MeSH descriptor: [Diabetes Insipidus, Neurogenic]<br>explode all trees OR Central Diabetes Insipidus OR MeSH descriptor: [Diabetes<br>Insipidus, Nephrogenic] explode all trees OR Vasopressin Defective Diabetes<br>Insipidus<br>#2 copeptin* OR copeptina<br>#3 #1 AND #2|18|
|MEDLINE via<br>Pubmed|"Diabetes Insipidus"[Mesh] OR Diabetes insipidus[tiab] OR Diabetes Insipidus<br>Secondary To Vasopressin Deficiency[tiab] OR Pituitary Diabetes Insipidus[tiab] OR<br>Diabetes Insipidus Cranial Type[tiab] OR "Diabetes Insipidus, Neurogenic"[Mesh]<br>OR Diabetes Insipidus Primary Central[tiab] OR Central Diabetes Insipidus[tiab] OR<br>"Diabetes Insipidus, Nephrogenic"[Mesh] OR Diabetes Insipidus Renalis[tiab] OR<br>Nephrogenic Diabetes Insipidus[tiab] OR Vasopressin Defective Diabetes<br>Insipidus[tiab] AND "copeptins" [Supplementary Concept] OR copeptin*|125|
|Embase<br>via<br>Elsevier|('diabetes insipidus'/exp OR 'antidiuretic hormone insufficiency' OR 'cerebral<br>diabetes insipidus' OR 'diabetes insipidus' OR 'diabetes spurius' OR 'insipid diabetes'<br>OR 'nephrogenic diabetes insipidus'/exp OR 'diabetes insipidus, nephrogenic' OR<br>'nephrogenic diabetes insipidus' OR 'renal diabetes insipidus' OR 'renogenic diabetes<br>insipidus' OR 'neurogenic diabetes insipidus'/exp OR 'diabetes insipidus, neurogenic'<br>OR 'neurogenic diabetes insipidus') AND 'copeptin'/exp OR 'c terminal pro arginine<br>vasopressin' OR 'c terminal proargipressin' OR 'copeptin' OR 'copeptins' AND<br>'crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled<br>trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti<br>OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR|13|  
25  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR<br>assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti OR 'systematic<br>review'/de OR 'systematic review (topic)'/de OR (('comprehensive':ti,ab,kw OR<br>'integrated':ti,ab,kw<br>OR<br>'integrative':ti,ab,kw<br>OR<br>'mapping':ti,ab,kw<br>OR<br>'methodology':ti,ab,kw<br>OR<br>'narrative':ti,ab,kw<br>OR<br>'scoping':ti,ab,kw<br>OR<br>'systematic':ti,ab,kw)<br>AND<br>('search':ti,ab,kw<br>OR<br>'searched':ti,ab,kw<br>OR<br>'searches':ti,ab,kw<br>OR<br>'studies':ti,ab,kw)<br>AND<br>('cinahl':ti,ab,kw<br>OR<br>'cochrane':ti,ab,kw OR 'embase':ti,ab,kw OR 'psycinfo':ti,ab,kw OR 'pubmed':ti,ab,kw<br>OR 'medline':ti,ab,kw OR 'scopus':ti,ab,kw OR 'web of science':ti,ab,kw OR<br>'bibliographic review':ti,ab,kw OR 'bibliographic reviews':ti,ab,kw OR 'literature<br>review':ti,ab,kw OR 'literature reviews':ti,ab,kw OR 'literature search':ti,ab,kw OR<br>'literature<br>searches':ti,ab,kw<br>OR<br>'narrative<br>review':ti,ab,kw<br>OR<br>'narrative<br>reviews':ti,ab,kw OR 'qualitative review':ti,ab,kw OR 'qualitative reviews':ti,ab,kw<br>OR<br>'quantitative<br>review':ti,ab,kw<br>OR<br>'quantitative<br>reviews':ti,ab,kw))<br>OR<br>'comprehensive<br>review':ti,ab,kw<br>OR<br>'comprehensive<br>reviews':ti,ab,kw<br>OR<br>'comprehensive search':ti,ab,kw OR 'comprehensive searches':ti,ab,kw OR 'critical<br>review':ti,ab,kw OR 'critical reviews':ti,ab,kw OR (('electronic database':ti,ab,kw OR<br>'electronic<br>databases':ti,ab,kw<br>OR<br>(databases<br>NEAR/3<br>searched))<br>AND<br>(eligibility:ti,ab,kw<br>OR<br>excluded:ti,ab,kw<br>OR<br>exclusion:ti,ab,kw<br>OR<br>included:ti,ab,kw OR inclusion:ti,ab,kw)) OR 'evidence assessment':ti,ab,kw OR<br>'evidence review':ti,ab,kw OR 'exploratory review':ti,ab,kw OR 'framework<br>synthesis':ti,ab,kw OR 'integrated review':ti,ab,kw OR 'integrated reviews':ti,ab,kw<br>OR 'integrative review':ti,ab,kw OR 'integrative reviews':ti,ab,kw OR 'mapping<br>review':ti,ab,kw OR<br>'meta-review':ti,ab,kw OR 'meta-synthesis':ti,ab,kw OR<br>'methodology review':ti,ab,kw OR 'mixed methods review':ti,ab,kw OR 'mixed<br>methods synthesis':ti,ab,kw OR (overview NEAR/4 reviews) OR 'prisma':ab OR<br>('preferred':ti,ab,kw AND reporting:ti,ab,kw) OR 'prognostic review':ti,ab,kw OR<br>'psychometric review':ti,ab,kw OR 'rapid evidence assessment':ti,ab,kw OR 'rapid<br>literature review':ti,ab,kw<br>OR<br>'rapid literature search':ti,ab,kw<br>OR<br>'rapid<br>realist':ti,ab,kw OR 'rapid review':ti,ab,kw OR 'rapid reviews':ti,ab,kw OR 'realist<br>review':ti,ab,kw OR 'review of reviews':ti,ab,kw OR 'scoping review':ti,ab,kw OR<br>'scoping reviews':ti,ab,kw OR 'scoping study':ti,ab,kw OR 'state of the art<br>review':ti,ab,kw OR 'systematic evidence map':ti,ab,kw OR 'systematic evidence<br>mapping':ti,ab,kw<br>OR<br>'systematic<br>literature':ti,ab,kw<br>OR<br>'systematic<br>medline':ti,ab,kw OR 'systematic pubmed':ti,ab,kw OR 'systematic review':ti,ab,kw<br>OR 'systematic reviews':ti,ab,kw OR 'systematic search':ti,ab,kw OR 'systematic||  
26  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||searches':ti,ab,kw OR 'systematical literature review':ti,ab,kw OR 'systematical||
||review':ti,ab,kw<br>OR<br>'systematical<br>reviews':ti,ab,kw<br>OR<br>'systematically||
||identified':ti,ab,kw<br>OR<br>'systematically<br>review':ti,ab,kw<br>OR<br>'systematically||
||reviewed':ti,ab,kw OR 'umbrella review':ti,ab,kw OR 'umbrella reviews':ti,ab,kw OR||
||'13616137':is OR 'cochrane database of systematic reviews'/jt||
||FILTER: [embase]/lim NOT ([embase]/lim AND [medline]/lim)||  
Foi utilizado o aplicativo Rayyan<sup>1</sup> para a avaliação de duplicatas dos registros e seleção dos estudos. A seleção dos estudos foi realizada por dois avaliadores independentes. As divergências entre os metodologistas em relação às decisões de inclusão foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com suspeita de diabete insípido  
- (b) Teste índice  
Copeptina  
- (c) Tipos de estudos  
Revisão sistemática e Estudos de acurácia diagnóstica  
- (d) Desfechos  
Especificidade, sensibilidade, valor preditivo positivo e negativo, razão de verossimilhança positiva e negativa e  
eventos adversos  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Resultados da busca** -->
Foram recuperadas 156 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas 26 duplicatas e realizada a triagem dos títulos e resumos. Uma revisão sistemática avaliando o biomarcador copeptina foi incluído. O processo de seleção é detalhado na **Figura B** .  
27  
**Figura B** - Fluxograma de seleção dos estudos avaliando o uso da copeptina para o diagnóstico de DI.  
<!-- Start of picture text -->
Registros identificados nas Registros removidos antes da<br>bases de dados € registros ‘selecdo:<br>(n=156) Duplicatas removidas (n =26)<br>3<br>ReRegisres rastreadosrastread  por tiulostitulos e Records excluded"<br>(nat30) (n= 123)<br>|| 2<br>Registros buscados para sstros nd<br>Regisios Resists nfo enenntadoe<br>(n=7)<br>Registros avaliados por meio de Registros excluidos<br>texto completo Nao preenchia o PICO<br>(0=7) (n=6)<br>Estudos incluidos na revisio<br>(n=1)<br>Relatos incluidos na revisao<br>(n=0)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Análise e apresentação dos resultados** -->
Foi planejada a avaliação de risco de viés dos estudos incluídos por dois avaliadores. Para estudos de acurácia diagnóstica, a ferramenta utilizada seria a _Quality Assessment of Diagnostic Accuracy Studies_ 2 (QUADAS-2). Para revisões sistemáticas, a ferramenta _Risk Of Bias In Systematic Reviews_ (ROBIS).  
As avaliações foram realizadas em duplicatas, de forma independente. Além disso, as divergências foram resolvidas por consenso ou por consulta a um terceiro revisor. Em relação à apresentação dos dados, a performance diagnóstica foi apresentada pela sensibilidade e especificidade com os respectivos Intervalos de confiança (IC) de 95%.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Resumo das evidências:** -->
Após a aplicação dos critérios de elegibilidade, foi incluída uma revisão sistemática<sup>4</sup> com risco de viés classificado como incerto pela ferramenta ROBIS, devido à preocupação em relação aos métodos utilizados para identificar e/ou selecionar estudos e preocupação com relação aos métodos utilizados para a síntese e resultados. O **Quadro D** apresenta o risco de viés detalhado da revisão sistemática incluída.  
Essa revisão teve como objetivo avaliar a acurácia diagnóstica dos níveis de copeptina no diagnóstico diferencial de pacientes com Síndrome polidipsia-poliúria (SPP) e incluiu sete estudos envolvendo 422 pacientes diagnosticados com SPP, dos quais 189 (44,79%) foram diagnosticados com deficiência de arginina vasopressina (anteriormente denominado DI craniano ou DI central). A idade média variou de 3,1 anos a 56,9 anos. Nesta revisão, os estudos incluídos foram avaliados pela ferramenta de risco de viés QUADAS-2. Dos sete estudos incluídos na revisão, três estudos prospectivos compararam a copeptina com controles disponíveis no SUS (teste de retenção hídrica)<sup>5–7</sup> . Dos três estudos, dois<sup>5,6</sup> apresentaram um risco alto de viés devido à falta de esclarecimento se os resultados do padrão de referência foram interpretados sem conhecimento  
28  
dos níveis de copeptina; à falta de limiares de copeptina predefinidos e; às preocupações em relação à aplicabilidade do teste de referência pois até o momento, não há um consenso sobre qual o padrão referência existente para diagnosticar SPP. O outro estudo<sup>7</sup> apresentou risco incerto de viés por apresentar preocupações com aplicabilidade do teste de referência. As características dos três estudos incluídos são apresentadas no **Quadro E** .  
29  
**Quadro D** - Avaliação de risco de viés da revisão sistemática incluída (ROBIS – _Risk of Bias in Systematc Reviews_ ).  
|**Domínio**|**Perguntas de direcionamento**|**Resposta às**<br>**perguntas de**<br>**direcionamento**|**Preocupação**|**Notas**|
|---|---|---|---|---|
|Avaliação da relevância|A questão abordada pela revisão corresponde à<br>pergunta que você está tentando responder, por<br>exemplo: no overview ou diretriz?<br>Categoria/questão alvo<br>Pacientespacientes<br>internados<br>para<br>avaliação<br>diagnóstica da síndrome polidipsia-poliúria (SPP)<br>ou com diagnóstico confirmado de SPP.<br>Teste index/níveis plasmáticos ou séricos de<br>copeptina<br>determinados<br>por<br>ensaios<br>imunoluminométricos ou ensaios automatizados de<br>imunofluorescência<br>Referência padrão/Diabete insipido (DI) e polidipsia<br>primária (PP) foram diagnosticados com todos os<br>resultados médicos disponíveis, como teste de<br>privação de água, história clínica, características<br>clínicas, exames laboratoriais e resposta ao<br>tratamento<br>Condição alvo/diagnóstico diferencial entre DI e PP|1.1. S/PS/PN/N/NI|**Baixo**|A população incluiu dois grupos distintos, sendo<br>uma das condições de não interessa. Entretanto, a<br>pergunta coincide com as categorias teste índex,<br>padrão de referência e condição alvo. Desta forma,<br>a questão abordada pela revisão corresponde à<br>questão-alvo.|
|1. Preocupação em relação a<br>esecificaão dos critérios de|1.1. Os objetivos e critérios de elegibilidade foram<br>definidos previamente?|1.1. S/PS/PN/N/NI|1**Baixo**|O protocolo da revisão (CRD42022367879) foi<br>publicado antes da revisão. Além disso, os autores|
|pç<br>elegibilidade.|1.2. Os critérios de elegibilidade eram adequados<br>para a pergunta de pesquisa?|1.2. S/PS/PN/N/NI|.|forneceram<br>detalhes<br>sobre<br>os<br>critérios<br>de<br>elegibilidade na seção “_Data Search and Eligibility_|  
30  
|**Domínio**|**Perguntas de direcionamento**|**Resposta às**<br>**perguntas de**<br>**direcionamento**|**Preocupação**|**Notas**|
|---|---|---|---|---|
||1.3. Os critérios de elegibilidade foram bem<br>especificados (sem ambiguidade)?|1.3. S/PS/PN/N/NI||_Criteria_”. Embora a revisão tenha descrito apenas<br>a restrição de rastrear os estudos a partir de 2005,|
||1.4. Com relação aos critérios de elegibilidade, as<br>restrições baseadas nas caraterísticas dos estudos<br>foram apropriadas (data, tamanho da amostra etc.)?|1.4. S/PS/PN/N/NI||isso foi justificado pois o imunoensaio de medição<br>de copeptina foi publicado pela primeira vez<br>apenas em 2005. Ressalta-se que critérios sobre|
||1.5. Com relação aos critérios de elegibilidade, as<br>restrições baseadas nas fontes de informações foram<br>apropriadas (idioma, disponibilidade de dados etc.)?|1.5. S/PS/PN/N/NI||desenho dos estudos foram definidos a priori, de<br>forma adequada a responder a questão.|
||2.1. A busca incluiu uma variedade suficiente de<br>bases de dados/fontes eletrônicas para pesquisar<br>artigos publicados e não publicados?|2.1. S/PS/PN/N/NI||Medline, EMBASE, Science Citation Index<br>Expanded, Cochrane Library, SCOPUS, and Open<br>Grey foram pesquisadas desde 1 de Janeiro de|
|2. Preocupação em relação aos|2.2. Além da busca nas bases de dados foram<br>utilizados métodos adicionais para a identificação<br>de artigos relevantes?|2.2. S/PS/PN/N/NI||2005 até 13 de julho de 2022.<br>Apesar de não estar claro quais recursos foram<br>utilizados dentro da Cochrane Library, este item|
|<br>métodos<br>utilizados<br>para<br>identificar<br>e/ou<br>selecionar<br>estudos|2.3. Os termos e a estrutura da estratégia de busca<br>foram adequados para obter o maior número<br>possível de artigos?|2.3. S/PS/PN/N/NI|2.**Incerta**|foi julgado como adequado, pois uma variedade de<br>bases de dados foi analisada, incluindo a literatura<br>cinzenta. Os termos utilizados foram: “copeptin”|
|.|2.4. As restrições baseadas na data, formato de<br>publicação ou idioma foram adequadas?|2.4. S/PS/PN/N/NI||OR “provaso-pressin”] AND [“diabetes insipidus”<br>OR “polyuria” OR “polydipsia]. Além disso, os|
||2.5. Foram realizadas tentativas para minimizar<br>erros na seleção dos estudos?|2.5. S/PS/PN/N/NI||autores apresentaram a estratégia completa no<br>"_Supplementary Data 2_" o qual não estava<br>disponível. Não houve restrições baseadas em<br>idioma ou formato de publicação. A restrição de|  
31  
|**Domínio**|**Perguntas de direcionamento**|**Resposta às**<br>**perguntas de**<br>**direcionamento**|**Preocupação**|**Notas**|
|---|---|---|---|---|
|||||data adicionada apresentou coerência.<br>O processo de seleção foi realizado de forma<br>adequada, por dois autores independentes, que<br>após a análise de títulos e resumos, foram<br>avaliados na íntegra para verificação dos critérios<br>de elegibilidade.|
||3.1. Foram realizadas tentativas para minimizar o<br>erro na coleta de dados?|3.1. S/PS/PN/N/NI||A extração de dados foi realizada de forma<br>independente por dois revisores. Entretanto, não|
||3.2. As características disponíveis do estudo foram<br>suficientes para que os autores da revisão e leitores<br>sejam capazes de interpretar os resultados?|3.2. S/PS/PN/N/NI||foi relatado se as divergências foram resolvidas<br>por consenso. Foram fornecidas informações das<br>características dos estudos incluídos. O estudo|
||3.3. Todos os resultados relevantes foram coletados<br>para uso na síntese?|3.3. S/PS/PN/N/NI||forneceu informações suficientes a respeito da<br>coleta de dados relevantes para síntese dos|
|3. Preocupação com a coleta de<br>dados e análise crítica dos|3.4. O risco de viés (ou qualidade metodológica) foi<br>formalmente avaliado usando critérios apropriados?|3.4. S/PS/PN/N/NI|3.**Baixo**|resultados.<br>Dando<br>sequência,<br>os<br>autores<br>realizaram<br>a|
|estudos.|3.5. Foram realizadas tentativas para minimizar o<br>erro na avaliação do risco de viés?|3.5. S/PS/PN/N/NI||avaliação do risco de viés com a ferramenta<br>“Quality Assessment of Diagnostic Accuracy<br>Studies (QUADAS-2 tool)” o que foi julgada<br>como apropriada. Apesar disso, os autores não<br>descreveram se a avaliação foi realizada por um<br>autor ou 2 autores de forma independente e<br>posteriormente, as divergências resolvidas por<br>consenso.|  
32  
|**Domínio**|**Perguntas de direcionamento**|**Resposta às**<br>**perguntas de**<br>**direcionamento**|**Preocupação**||**Notas**|
|---|---|---|---|---|---|
||4.1. A síntese de resultados incluiu todos os estudos<br>que deveriam ser incluídos?|4.1. S/PS/PN/N/NI||||
||4.2. Todas as análises pré-definidas foram seguidas<br>ou as perdas de participantes foram explicadas?|4.2. S/PS/PN/N/NI||||
|4. Preocupação com relação aos<br>métodos<br>utilizados<br>para<br>a|4.3. A síntese dos resultados foi apropriada dada a<br>natureza e à similaridade das questões de pesquisa,<br>dos delineamentos de estudos e desfechos dos<br>estudos incluídos?|4.3. S/PS/PN/N/NI|4.**Incerto**|||
|síntese e resultados.|4.4. A variação entre os estudos (heterogeneidade)<br>foi baixa ou abordada na síntese?|4.4. S/PS/PN/N/NI||||
||4.5.<br>Os<br>resultados<br>foram<br>robustos?<br>Como<br>demonstrado, por exemplo, pelo funnel plot ou<br>análise de sensibilidade.|4.5. S/PS/PN/N/NI||||
||4.6. Os vieses nos estudos primários foram mínimos<br>ou foram abordados na síntese?|4.6. S/PS/PN/N/NI||||
|Análise do risco de viés:||||||
|A. A interpretação dos achados ab|orda todas as preocupações identificadas nos domínios|1 ao 4?||S/PS/N/PN/NI||
|B. A relevância dos estudos inclu|ídos para a questão clínica foi apropriadamente conside|rada?||S/PS/N/PN/NI||
|C. Os revisores evitaram enfatizar|os resultados baseados na significância estatística?|||S/PS/N/PN/NI||
|**Risco de viés:**BAIXO, ALTO ou|**INCERTO**|||||  
_Legenda:_ S: Sim / PS: Provavelmente Sim/ N: Não / PN: Provavelmente Não/ NI: Não Informado.  
33  
**Quadro E -** Estudos incluídos na revisão do Mu, 2023<sup>4</sup>  
|**Estudo**|**População**|**Teste índex**|**Teste Padrão**|**Desfechos**|
|---|---|---|---|---|
|Fenske et al,|50 pacientes com|Copeptina|Restrição hídrica|verdadeiro-positivo,|
|2011|SPP<br>20 pacientes<br>saudáveis|||falso positivo,<br>falso-negativo<br>verdadeiro-negativo|
|Tuli et al,|53 controles, 12|Copeptina|Restrição hídrica|verdadeiro-positivo,|
|2018|crianças<br>hipopituitárias e 15<br>pacientes com SPP|||falso positivo,<br>falso-negativo<br>verdadeiro-negativo|
|Fenske et al,|144 pacientes com|Copeptina|Restrição hídrica|verdadeiro-positivo,|
|2018|SPP||e teste de infusão salina<br>realizados separados|falso positivo,<br>falso-negativo<br>verdadeiro-negativo|  
Legenda: SPP: Síndrome polidipsia-poliúria  
Os resultados da acurácia dos estudos foram descritos de acordo com os dados apresentados na **Tabela A** .  
**Tabela A** - Acurácia diagnóstica dos dois estudos elegíveis para a comparação PP versus deficiência de arginina vasopressina parcial e completa.  
|**Autor (ano)**|**PP versus deficiência de arginina vasopressina (parcial**|**e completa)**||||
|---|---|---|---|---|---|
||**Valor do ponto de corte da copeptina (pmol/L)**|**VP**|**FP**|**FN**|**VN**|
|Fenske et al (2011)|Plasma da copeptina basal: 3|21|5|1|21|
|Fenske et al (2018)|Plasma da copeptina basal: <2,6|58|76|1|4|
|Tuli et. al (2018)|Plasma da copeptina basal: 3,5|5|2|1|6|  
Legenda: PP: polidipsia-poliúria; VP: verdadeiro positivo; FP: falso positivo; VN: verdadeiro negativo; FN: falso negativo.  
Os resultados foram separados entre população adulta e população infantil.  
A performance diagnóstica da copeptina estimulada para diferenciar polidipsia-poliúria de AVP-D parcial e completa (anteriormente chamada de DI craniana ou DI central) **em pacientes adultos** variou de 95% a 98% para sensibilidade e variou de 5% a 81% para especificidade (214 pacientes, 2 estudos, **Figura C** ).  
A performance diagnóstica para a estimulação da copeptina para diferenciar polidipsia-poliúria de AVP parcial e completa (anteriormente chamada de DI craniana ou DI central) **em crianças** foi de 83% para sensibilidade e de 75% para especificidade. (80 pacientes, 1 estudo, **Figura C** )  
34  
**Figura C** - _Forest plot_ da performance diagnóstica da copeptina vs. restrição hídrica.  
<!-- Start of picture text -->
Copeptina versus restricao hidrica em adultos<br>Study TP FP FN TN Sensitivity(95% Cl) Specificity(95% Cl) Sensitivity(95% Cl) Specificity(95% Cl)<br>Fenskeetal.(2011) 21 5 1 21 0.95(0.77,1.00] 0.81 (0.61, 0.93] — = =<br>Fenskeetal.(2018) 68 76 1 4 0.98(0.91,1.00} 0.05 (0.01, 0.12) 4<br>0020406081<br>Copeptina versus restricao hidrica em criancas 0020406081<br>Study TP FP FN TN Sensitivity(95% Cl) Specificity(95% Cl) Sensitivity(95% Cl) Specificity(95% Cl)<br>Tulietal.(2018) 5 2 1 6 0.83(0.36,1.00] 0.75 (0.35, 0.97) [5 aaa<br>0020406081<br>0020406081<br><!-- End of picture text -->  
A avaliação do nível de copeptina demonstra uma alta sensibilidade, acompanhada de uma especificidade considerável (com uma ampla variação entre os estudos) no contexto do diagnóstico diferencial em pacientes adultos. Já para a população infantil, a avaliação do nível de copeptina apresentou alta sensibilidade e especificidade. No entanto, em ambas as análises, o número de estudos e pacientes incluídos é relativamente pequeno com importantes limitações metodológicas. Em termos de validade externa, os pacientes recrutados eram todos da Europa, o que restringiu a generalização dos resultados à população de outras etnias e regiões. Ainda, mais estudos são necessários para comparar o protocolo de teste ideal para diagnóstico e determinar o melhor limiar ( _threshold_ ) do nível de copeptina, pois ainda não há um ponto de corte bem definido com relevância clínica<sup>5</sup> .  
**QUESTÃO 3. O exame molecular quando comparado a biomarcadores, concentração de sódio plasmático, osmolalidade plasmática, restrição hídrica e avaliação clínica é acurado e seguro para o diagnóstico diferencial do DI em pacientes com suspeita de DI com histórico familiar da doença em que outras causas foram afastadas?**  
A estrutura PIRO para esta pergunta foi:  
**Pacientes:** Pacientes com suspeita de DI  
**Teste índice:** exame molecular  
**Teste padrão:** outros biomarcadores disponíveis no SUS, como concentração de sódio plasmático, osmolalidade plasmática, restrição hídrica e avaliação clínica.  
**_Outcome_ /Desfecho:** especificidade, sensibilidade, valor preditivo positivo e negativo, razão de verossimilhança positiva e negativa e eventos adversos

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Métodos e resultados da busca** -->
Para a tomada de decisão, foi realizada uma busca por ensaios clínicos randomizados que compararam o uso da desmopressina com o placebo. A busca foi realizada nas bases de dados CENTRAL via Cochrane Library, MEDLINE via Pubmed, Embase via Elsevier em 03 de junho de 2024. As estratégias de busca para cada base estão descritas no **Quadro F** . **Quadro** F - Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o uso da copeptina em pacientes com DI.  
|||**Número de**|
|---|---|---|
|**Bases de**|**Estratégia de busca**|**resultados**|
|**dados**||**encontrados**|  
35  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|CENTRAL|#1 MeSH descriptor: [Diabetes Insipidus] explode all trees OR (Diabetes Insipidus<br>OR Diabetes Insipidus Primary Central OR Diabetes Insipidus Secondary To<br>Vasopressin Deficiency OR Pituitary Diabetes Insipidus OR Diabetes Insipidus<br>Cranial Type):ti,ab,kw OR MeSH descriptor: [Diabetes Insipidus, Neurogenic]<br>explode all trees OR Central Diabetes Insipidus OR MeSH descriptor: [Diabetes<br>Insipidus, Nephrogenic] explode all trees OR Vasopressin Defective Diabetes<br>Insipidus<br>#2 MeSH descriptor: [Aquaporin 2] explode all trees OR AVPR2 OR AQP2 OR<br>AVP-NPII gene<br>#3 #1 AND #2|4|
|MEDLINE via<br>Pubmed|"Diabetes Insipidus"[Mesh] OR Diabetes insipidus[tiab] OR Diabetes Insipidus<br>Secondary To Vasopressin Deficiency[tiab] OR Pituitary Diabetes Insipidus[tiab] OR<br>Diabetes Insipidus Cranial Type[tiab] OR "Diabetes Insipidus, Neurogenic"[Mesh]<br>OR Diabetes Insipidus Primary Central[tiab] OR Central Diabetes Insipidus[tiab] OR<br>"Diabetes Insipidus, Nephrogenic"[Mesh] OR Diabetes Insipidus Renalis[tiab] OR<br>Nephrogenic Diabetes Insipidus[tiab] OR Vasopressin Defective Diabetes<br>Insipidus[tiab] AND ("Aquaporin 2/genetics"[Mesh]) AND "AVPR2 protein, human"<br>[Supplementary Concept] OR AVP-NPII gene[tiab]|49|
|Embase<br>via<br>Elsevier|('diabetes insipidus'/exp OR 'antidiuretic hormone insufficiency' OR 'cerebral<br>diabetes insipidus' OR 'diabetes insipidus' OR 'diabetes spurius' OR 'insipid diabetes'<br>OR 'nephrogenic diabetes insipidus'/exp OR 'diabetes insipidus, nephrogenic' OR<br>'nephrogenic diabetes insipidus' OR 'renal diabetes insipidus' OR 'renogenic diabetes<br>insipidus' OR 'neurogenic diabetes insipidus'/exp OR 'diabetes insipidus, neurogenic'<br>OR 'neurogenic diabetes insipidus') AND 'aquaporin 2 gene'/exp OR 'avpr2 gene'/exp<br>OR 'avp-npii gene<br>FILTER: [embase]/lim NOT ([embase]/lim AND [medline]/lim)|29|  
Foi utilizado o aplicativo Rayyan<sup>1</sup> para a avaliação de duplicatas dos registros e seleção dos estudos. A seleção dos estudos foi realizada por dois avaliadores independentes. As divergências entre os metodologistas em relação às decisões de inclusão foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
(a) Tipos de participantes  
36  
Pacientes com suspeita de DI com histórico familiar da doença em que outras causas foram afastadas  
- (b) Teste índice  
Exame molecular  
- (c) Tipos de estudos  
Revisão sistemática e Estudos de acurácia diagnóstica  
- (d) Desfechos  
Especificidade, sensibilidade, valor preditivo positivo e negativo, razão de verossimilhança positiva e negativa e  
eventos adversos  
- (e) Idioma  
Não houve restrição de linguagem e data de publicação.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Resultados da busca** -->
Foram recuperadas 82 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas 15 duplicatas e realizada a triagem dos títulos e resumos. Nenhum estudo avaliando os exames moleculares para diagnostico de DI foi incluído. O processo de seleção é detalhado na **Figura D** .  
**Figura D** - Fluxograma de seleção dos estudos avaliando o uso de teste molecular para diagnóstico de DI.  
<!-- Start of picture text -->
Registros identificados nas Registros removidos antes da<br>(n=82) Duplicatas removidas (n =15)<br>i bases de dadose registros selecao:<br>Registro rasteados por tiulos ¢ Is exch<br>(n=67) (n=65)<br>(n=2)Registros buscados para nai —o<br>Registros avaliados por meio de Registros exciuidos<br>texto completo Nao preenchia o PICO<br>(n=2) (n=2)<br>Estudos incluidos na revisio<br>(n=0)<br>Relatos incluidos na revisao<br>(n=0)<br><!-- End of picture text -->  
**Análise e apresentação dos resultados**  
Foi planejada a avaliação de risco de viés dos estudos incluídos por dois avaliadores. Para estudos de acurácia diagnóstica, a ferramenta utilizada seria a _Quality Assessment of Diagnostic Accuracy Studies_ 2 (QUADAS-2). Para revisões sistemáticas, a ferramenta _Risk Of Bias In Systematic Reviews_ (ROBIS).  
37  
As avaliações seriam realizadas em duplicatas, de forma independente. Além disso, as divergências seriam resolvidas por consenso ou através da consulta com um terceiro revisor. Em relação à apresentação dos dados, a performance diagnóstica do teste molecular seria apresentada através da sensibilidade e especificidade com os respectivos Intervalos de confiança (IC) de 95%.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **Resumo das evidências:** -->
O uso de marcadores genéticos, como os genes AVPR2 e AQP2, está sendo investigado em pacientes com diabete insipido nefrogênico, com uma alta incidência de mulheres heterozigóticas apresentando sintomas clínicos da doença<sup>8,9</sup> . Mutações no gene AVP-NPII foram encontradas em pacientes com diabete insipido central, destacando a importância do diagnóstico molecular na identificação dessa condição<sup>10,11</sup> . Esses marcadores parecem desempenhar um papel importante na confirmação do diagnóstico e na diferenciação entre os vários tipos da doença. No entanto, a estratégia de busca não retornou estudos que atendam aos critérios de elegibilidade previamente apresentado, comparando o teste molecular com outros métodos diagnósticos em pacientes com suspeita de diabete insipido e histórico familiar da doença, onde outras causas foram descartadas.

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **6. REFERÊNCIAS** -->
1. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan-a web and mobile app for systematic reviews. Syst Rev. 2016 Dec;5(1):210.  
2. Andersson K, Arner B. Effects of DDAVP, a synthetic analogue of vasopressin, in patients with cranial diabetes insipidus. Acta Med Scand. 1972;192(1‐6):21–7.  
3. Ray JG. DDAVP use during pregnancy: an analysis of its safety for mother and child. Obstet Gynecol Surv. 1998;53(7):450–5.  
4. Mu D, Ma Y, Cheng J, Qiu L, Chen S, Cheng X. Diagnostic Accuracy of Copeptin in the Differential Diagnosis of patients with Diabetes Insipidus: A Systematic Review and Meta-analysis. Endocrine Practice. 2023; 5. Tuli G, Tessaris D, Einaudi S, Matarazzo P, De Sanctis L. Copeptin role in polyuria‐polydipsia syndrome differential diagnosis and reference range in paediatric age. Clin Endocrinol (Oxf). 2018;88(6):873–9.  
6. Fenske W, Quinkler M, Lorenz D, Zopf K, Haagen U, Papassotiriou J, et al. Copeptin in the differential diagnosis of the polydipsia-polyuria syndrome—revisiting the direct and indirect water deprivation tests. J Clin Endocrinol Metab. 2011;96(5):1506–15.  
7. Fenske W, Refardt J, Chifu I, Schnyder I, Winzeler B, Drummond J, et al. A copeptin-based approach in the diagnosis of diabetes insipidus. New England Journal of Medicine. 2018;379(5):428–39.  
8. García Castaño A, Pérez de Nanclares G, Madariaga L, Aguirre M, Chocron S, Madrid A, et al. Novel mutations associated with nephrogenic diabetes insipidus. A clinical-genetic study. Eur J Pediatr. 2015;174:1373–85.  
9. Ghasemi S, Mojbafan M, Talebi S, Hooman N, Hoseini R. Genetic analysis of nephrogenic diabetes insipidus patients: A study on the Iranian population. Mol Genet Genomic Med. 2024;12(4):e2421.  
10. Patti G, Scianguetta S, Roberti D, Di Mascio A, Balsamo A, Brugnara M, et al. Familial neurohypophyseal diabetes insipidus in 13 kindreds and 2 novel mutations in the vasopressin gene. Eur J Endocrinol. 2019;181(3):233–44.  
38  
11. Feldkamp LLI, Kaminsky E, Kienitz T, Quinkler M. Central diabetes insipidus caused by arginine vasopressin gene mutation: report of a novel mutation and review of literature. Hormone and Metabolic Research. 2020;52(11):796–802.  
39

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **PROPOSTA DE MODELO PARA A ANOTAÇAO E PARÂMETROS AVALIADOS NO TESTE DE RESTRIÇAO HÍDRICA** -->
**Quadro A** - Modelo para anotação durante o teste de restrição hídrica  
|Tempo (hora)|Sódio Plasmático<br>(P)|Volume urinário<br>(U)|Osmolaridade<br>urinária<br>(U)|Osmolaridade<br>plasmática<br>(P)|Peso do paciente<br>(Kg)*|
|---|---|---|---|---|---|
|0||||||
|1||||||
|2||||||
|3||||||
|4||||||
|5||||||
|6||||||
|7||||||  
Legenda: Casela hachurada indica que o exame não é necessário. * Se o paciente apresentar perda de peso maior que 3%, a osmolalidade e o sódio plasmáticos devem ser avaliados, mesmo que não tenha transcorrido o período de 2 horas da avaliação anterior.  
**Quadro B** - Parâmetros avaliados para o teste de restrição hídrica  
|MINUTOS|PESO DO PACIENTE|VOLUME URINÁRIO (U)|OSMOLALIDADE<br>URINÁRIA (U)|
|---|---|---|---|
|0<br>30||||
|60||||
|90||||
|120||||  
Legenda: volume (U) = volume urinário; Osm (U) = osmolalidade urinária; Casela hachurada indicam que o exame não é necessário.  
40  
**APÊNDICE 3**

---

<!-- METADADOS: doenca: Diabete Insípido | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**||**Tecnologias avaliada**|**s pela Conitec**|
|---|---|---|---|
|**da diretriz clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório de<br>Recomendação nº<br>943/2024|Atualização do<br>documento|-|-|
|Portaria Conjunta SAS-<br>SCTIE/MS º 2/2018<br>[Relatório de<br>Recomendação nº<br>313/2018]|Inclusão de orientações<br>sobre a desmopressina<br>oral|Desmopressina oral para o tratamento<br>de diabetes insípido central [Portaria<br>SCTIE/MS nº 61/2017; Relatório de<br>Recomendação nº 302/2017]]|-|
|Portaria SAS/MS nº<br>1.299, de 21 de<br>novembro de 2013|Atualização do texto do<br>Protocolo|-|-|
|Portaria SAS/MS nº<br>710, de 17 de dezembro<br>de 2010|Primeira versão do<br>Protocolo|-|-|  
41

---

