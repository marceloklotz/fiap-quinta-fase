<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: Geral -->
<!-- Start of picture text -->
ae<br>Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICOINDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 10, DE 13 DE SETEMBRO DE 2024.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Cardíaca com Fração de Ejeção Reduzida.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL** DA SAÚDE, <mark>no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024,</mark>  
Considerando a necessidade de se atualizarem os parâmetros sobre a insuficiência cardíaca com fração de ejeção reduzida no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 805/2023 e o Relatório de Recomendação n<sup><u>o</u></sup> 808/2023 – de março de 2023, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Cardíaca com Fração de Ejeção Reduzida.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da insuficiência cardíaca com fração de ejeção reduzida, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias</u> de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da insuficiência cardíaca com fração de ejeção reduzida.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SECTICS n<sup>o</sup> 17, de 18 de novembro de 2020, publicada no Diário Oficial da União nº 226, de 26 de novembro de 2020, seção 1, página 111.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
ADRIANO MASSUDA

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: CARLOS AUGUSTO GRABOIS GADELHA -->
**ANEXO**

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **1. INTRODUÇÃO** -->
A insuficiência cardíaca (IC) é a via final de muitas doenças que afetam o coração, o que explica a sua crescente prevalência. A atenção aos pacientes com IC é um desafio pelo caráter progressivo da doença, a limitação da qualidade de vida e a alta mortalidade. Recentemente, o número de pessoas vivendo com IC no mundo foi estimado em 23 milhões. Uma em cada cinco pessoas tem chance de desenvolver a síndrome ao longo da vida<sup>1</sup> . Entre os anos de 1998 e 2019, foram registrados no Brasil 567.789 óbitos por IC em adultos com idade acima de 50 anos, o que corresponde à taxa média de 75,5 a cada 100 mil habitantes. No período de 2004 a 2014, foram registradas 301.136 mortes decorrentes de IC em hospitais públicos brasileiros<sup>2</sup> . A IC também é a principal causa de re-hospitalização no Brasil, com elevada mortalidade em 5 anos, respondendo por cerca de 5% do orçamento destinado aos gastos com saúde<sup>3</sup> .  
A IC resulta em alterações hemodinâmicas como redução do débito cardíaco e elevação da pressão arterial pulmonar e venosa sistêmica. A suspeita diagnóstica é baseada principalmente em dados de anamnese e exame físico; os principais sinais e sintomas incluem dispneia, ortopneia, edema de membros inferiores e fadiga. Alterações eletrocardiográficas e na radiografia de tórax são comuns. De acordo com a apresentação clínica, exames complementares, como dosagem sérica de peptídeos natriuréticos de tipo B e ecocardiografia transtorácica, são bastante úteis na definição diagnóstica<sup>4–6</sup> .  
A necessidade de um modelo de acompanhamento longitudinal e multidisciplinar coloca a atenção primária à saúde (APS) como agente central do atendimento de pacientes com IC. No entanto, a complexidade e a falta de familiaridade com o tratamento da doença podem motivar o encaminhamento de muitos dos pacientes para serviços especializados. Esses encaminhamentos devem ser evitados, uma vez que a APS possui condições de proporcionar adequada assistência à maioria dos pacientes com IC. É importante salientar que, por meio do SUS, estão disponíveis medicamentos que possuem impacto positivo na sobrevida dos pacientes com IC, como inibidores da enzima conversora de angiotensina (IECA), betabloqueadores, antagonistas da aldosterona, dapagliflozina e sacubitril valsartana. Adicionalmente, há medidas não medicamentosas, relacionadas à dieta e prática de atividade física, que devem ser estimuladas nessa população e consistem em componente terapêutico relevante.  
Assim, este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da IC de qualquer etiologia, em sua apresentação crônica estável, e com fração de ejeção ventricular esquerda reduzida, os quais representam a maioria dos pacientes com IC e cujas condutas são melhor estabelecidas. O presente documento também visa orientar os profissionais da saúde, em especial aqueles que atuam na APS, em relação a aspectos relacionados à classificação, ao acompanhamento e ao encaminhamento a serviços especializados para atendimento dos doentes. Dessa forma, intervenções no atendimento hospitalar, como terapia de ressincronização cardíaca, não fazem parte do escopo deste Protocolo.  
O processo de desenvolvimento deste Protocolo envolveu a revisão por especialistas e a adoção de recomendações referentes às tecnologias que se encontram disponíveis no SUS para o tratamento da IC. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** . O histórico de alterações deste Protocolo encontra-se descrito no **Apêndice 2.**

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- I50.0 Insuficiência cardíaca congestiva  
- I50.1 Insuficiência ventricular esquerda  
- I50.9 Insuficiência cardíaca não especificada

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **3. DIAGNÓSTICO** -->
A IC é uma síndrome de diagnóstico clínico baseado essencialmente em: sinais e sintomas sugestivos, alteração estrutural ou funcional cardíaca, evidência inequívoca de congestão sistêmica ou pulmonar cardiogênica ou níveis elevados de peptídeos natriuréticos<sup>7,8</sup> . Em muitos cenários, o diagnóstico de IC pode ser estabelecido de forma rápida apenas com dados de anamnese e exame físico, corroborados por exames subsidiários simples como o eletrocardiograma e a radiografia de tórax. Em situações de dúvida diagnóstica (baixa e moderada probabilidade), outros exames, como a mensuração de peptídeos natriuréticos, podem ter papel relevante no esclarecimento diagnóstico.  
Os escores diagnósticos podem ser úteis na investigação clínica, em especial para profissionais menos experientes, por apresentarem-se em formato de questionário estruturado que compila fatores de risco, sintomas e sinais, servindo como guia para a avaliação médica. Os critérios de Boston e Framingham ( **Quadro 1** e **Quadro 2** , respectivamente) são os escores com maior experiência de uso. O seu uso pode auxiliar na classificação de probabilidade clínica de se ter IC e guiar a escolha de exames complementares<sup>9–12</sup> .  
Os sintomas e sinais de IC não são exclusivos da doença, podendo estar presentes em outras enfermidades, em especial outras doenças cardiopulmonares. Entre os achados clínicos, a dispneia é o sintoma mais frequente em pacientes com IC, embora possa ser observada em outras condições clínicas. Turgência venosa jugular, refluxo hepatojugular e presença de terceira bulha (ritmo de galope) indicam elevada suspeita de IC, apesar de usualmente não estarem presentes na maioria dos pacientes com essa doença<sup>13,14</sup> . Em geral, a apresentação da IC pode ser bastante variável, o que pode ser desafiador para o profissional da saúde e geralmente demanda uma avaliação adicional por meio de exames complementares.  
**Quadro 1** - Critérios de Boston para classificação da probabilidade de desenvolver IC<sup>6</sup> .  
|**História**||
|---|---|
|Dispneia em repouso|4|
|Ortopneia|4|
|Dispneia paroxística noturna|3|
|Dispneia ao caminhar em terreno plano|2|
|Dispneia ao caminhar em terreno inclinado|1|
|**Exame físico**||
|Frequência cardíaca entre 91-110 bpm|1|
|Frequência cardíaca maior que 110 bpm|2|
|Turgência venosa jugular|2|
|Turgência venosa jugular + hepatomegalia ou edema|3|
|Creptações pulmonares basais|1|
|Crepitações pulmonares além das bases pulmonares|2|
|Sibilos|3|
|Terceira bulha (ritmo de galope)|3|
|**Radiografia de tórax**||
|Edema pulmonar alveolar|4|
|Edema pulmonar intersticial|3|
|Efusão (derrame) pleural bilateral|3|  
|Índice cardiotorácico maior que 0,50|3|
|---|---|
|Redistribuição do fluxo para ápices pulmonares|2|  
Nota: Não são permitidos mais do que quatro pontos em cada uma das categorias. De acordo com a soma dos escores: < 4 pontos – diagnóstico de IC improvável; 5-7 pontos – diagnóstico de IC possível; 8-12 pontos – diagnóstico de IC definitivo.  
**Quadro 2 -** Critérios de Framingham para diagnóstico de IC<sup>6</sup> .  
**Critérios maiores** Dispneia paroxística noturna Turgência jugular Cardiomegalia à radiografia de tórax Edema agudo de pulmão Terceira bulha (ritmo de galope) Aumento da pressão venosa central (> 16 cm H2O no átrio direito) Refluxo hepatojugular Perda de peso > 4,5 kg em 5 dias em resposta ao tratamento **Critérios menores** Edema de tornozelos bilateral Tosse noturna Dispneia a esforços ordinários Hepatomegalia Derrame pleural Diminuição da capacidade funcional em um terço da máxima registrada previamente Taquicardia (FC > 120 bpm)  
Nota: Para o diagnóstico, o paciente deve apresentar 2 critérios maiores ou 1 critério maior + 2 critérios menores.  
Os peptídeos natriuréticos BNP e NT-proBNP possuem propriedades diagnósticas semelhantes entre si, sendo seu uso intercambiável. Os pontos de corte são 35 pg/mL para o BNP e 125 pg/mL para o NT-proBNP. Entretanto, a probabilidade de IC aumenta quanto maior forem os níveis séricos desses peptídeos. Assim, naqueles pacientes em que evidências inequívocas de congestão sistêmica ou pulmonar cardiogênicas não são encontradas, avaliar a concentração plasmática dos peptídeos natriuréticos é útil como método de apoio ao diagnóstico e pode ser a conduta inicial em indivíduos com suspeita de IC com probabilidades clínicas baixa.  
Vale lembrar que os níveis séricos de BNP e NT-proBNP podem estar elevados em outras situações patológicas ( **Quadro 3** ), sendo necessária a confirmação diagnóstica por ecocardiografia no caso de resultados positivos. O uso de BNP e NT-proBNP é preconizado neste Protocolo para fins diagnósticos em pacientes com baixa ou moderada probabilidade clínica de IC. O presente documento preconiza o seu uso em pacientes com diagnóstico de IC já estabelecido apenas para verificação dos critérios de inclusão para uso de sacubitril valsartana.  
**Quadro 3 -** Outras causas de elevação de peptídeos natriuréticos<sup>15</sup> .  
|**Outras causas de origem cardíaca**|
|---|
|Síndromes coronarianas agudas|
|Embolia pulmonar|
|Miocardite|  
Hipertrofia ventricular esquerda Cardiomiopatia hipertrófica ou restritiva Doença valvar Doença cardíaca congênita Taquiarritmias atriais e ventriculares Contusão cardíaca Cardioversão e choque de cardiodesfibrilador implantável Procedimentos cirúrgicos envolvendo o coração Hipertensão pulmonar **Outras causas de origem não cardíaca** Acidente vascular cerebral isquêmico Hemorragia subaracnoidea Disfunção renal moderada a grave Disfunção hepática moderada a grave Infecções graves (incluindo pneumonia e sepse) Queimaduras graves Anemia Anormalidades metabólicas e hormonais graves  
O fluxograma para diagnóstico da IC crônica encontra-se na **Figura 1** . O processo diagnóstico inicia-se pela avaliação clínica do paciente, pela qual o profissional pode classificá-lo em função da probabilidade de ele ter IC. Essa classificação pode ser realizada com o auxílio de escores clínicos, como os critérios de Boston ( **Quadro 1** ). Neste caso, a pontuação igual ou inferior a 4 consiste em baixa probabilidade clínica (diagnóstico improvável) e entre 5 e 7 consiste em moderada probabilidade clínica (diagnóstico possível), necessitando, em ambos os casos, exames complementares para definição diagnóstica. Pacientes com baixa probabilidade clínica de IC devem submeter-se à investigação inicial com a dosagem sérica de BNP ou com NT-proBNP, uma vez que resultados negativos desses exames têm elevado valor preditivo negativo e pacientes com resultados negativos devem ser investigados para outras hipóteses diagnósticas. Aqueles com resultados positivos devem seguir a investigação com ecocardiografia transtorácica para confirmação diagnóstica de IC.  
Em pacientes com probabilidade moderada, a investigação inicial poderá ser realizada com BNP/NT-proBNP ou com a ecocardiografia, a depender da facilidade de acesso e disponibilidade de cada um desses métodos diagnósticos.  
<!-- Start of picture text -->
Suspeita clinica de IC<br>Avaliacdo clinica/ escores diagnéstico<br>Baixa probabilidade Moderada probabilidade Alta probabilidade<br>Realizar BNP ou Realizar BNP ou Realizar Considerar tc<br>NT-Pro-BNP NT-Pro-BNP ecocardiograma tratamentoner<br>Valores de BNP Valores de BNP<br>235 pg/mL ou 235 pg/mL ou Ecocardiograma<br>NT-Pro-BNP NT-Pro-BNP confirmatério?<br>2125 pg/mL? 2125 pe/mL?<br>—_1 :<br>sim Nao sim No sim Nao<br>Realizar clinicoGeo METIS Realizar ecommpenbementc) consi cerele CTORC eae erey<br>ecocardiograma / diagnésticos: ecocardiograma/ clinico / diagnésticos5 Iniciar clinico / diagnésticos<br>alternativos alternativos tratamento alternativos<br>Ecocardiograma Ecocardiograma<br>confirmatério? confirmatério?<br>——_1 _,<br>sim N3o sim Nao<br>Considerar IC ‘Acompanhamento Considerar IC ‘Acompanhamento<br>tratamentoIniciar clinico/ diagnésticos Iniciar clinico/ diagnésticos<br>alternativos tratamento alternativos<br><!-- End of picture text -->  
**Figura 1** - Fluxograma de diagnóstico da IC.  
Em pacientes com alta probabilidade clínica, não se preconizam testes diagnósticos adicionais, em especial BNP ou NT-proBNP, já que nesses pacientes, a probabilidade de IC continua alta mesmo com resultados negativos dos peptídeos natriuréticos ou da ecocardiografia. A ecocardiografia não é necessária para fins diagnósticos nesses casos, mas deverá ser solicitada posteriormente para mensurar a fração de ejeção e demais parâmetros cardíacos, permitindo o planejamento terapêutico mais adequado guiado por esses parâmetros e o reconhecimento dos casos de IC com fração preservada, cujo tratamento farmacológico específico é diferente daquele preconizado para a IC de fração de ejeção reduzida. O tratamento inicial, incluindo diuréticos, deve ser iniciado antes do resultado da ecocardiografia.  
Apesar de o presente documento ser específico para IC com fração de ejeção reduzida, é importante atentar para a existência da insuficiência cardíaca com fração de ejeção preservada (ICFEP). A apresentação clínica da ICFEP é a mesma da IC com fração de ejeção reduzida, e sua incidência vem aumentando com o envelhecimento da população. Deve-se suspeitar de ICFEP no paciente com achados característicos de IC na história clínica, exame físico e radiografia de tórax, com ecocardiografia mostrando fração de ejeção do ventrículo esquerdo normal (maior que 50%), em especial na apresentação de BNP ou NT-proBNP elevados, uma vez descartados outros diagnósticos diferenciais. Esse paciente deve ser encaminhado para atendimento na atenção especializada para avaliação diagnóstica e tratamento inicial.  
Alguns pacientes podem apresentar as manifestações de IC de forma abrupta, seja com novos sintomas, seja pela exacerbação da síndrome clínica existente. Pacientes com suspeita de IC aguda ou com IC crônica com descompensação aguda devem ser avaliados em serviço de emergência. Esses pacientes têm apresentação clínica diversa; em sua maioria, apresentam sintomas de congestão pulmonar ou sistêmica, mas podem apresentar sinais associados a baixo débito cardíaco, como hipoperfusão, hipotensão e choque. Adicionalmente, esses pacientes devem ser investigados quanto à causa subjacente à agudização, que pode ocorrer em função, por exemplo, de síndrome coronariana aguda, miocardite e doença valvar, entre outras.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **3.1 Classificação da insuficiência cardíaca** -->
Os pacientes com IC são classificados de acordo com a classificação da _New York Heart Association_ (NYHA), a qual gradua a doença em 4 níveis ( **Quadro 4** ).  
**Quadro 4 -** Classificação funcional da _New York Heart Association_ (NYHA)<sup>6</sup> .  
|**Classe**<br>**NYHA**|**Descrição**|
|---|---|
|I|Sem limitações para realização de atividade física. Atividades habituais não causam dispneia, cansaço, palpitações.|
|II|Discreta limitação para realização de atividade física. Atividades habituais causam dispneia, cansaço, palpitações.|
|III<br>IV|Importante limitação para realização de atividade física. Atividades de intensidades inferiores causam dispneia,<br>~~cansaço palpitações~~<br>Limitações para realização de qualquer atividade física. Sintomas de IC podem ocorrer em repouso.|  
Apesar de a classificação funcional da NYHA possuir certo grau de subjetividade em sua avaliação, uma  
vez que se baseia em atividades cotidianas que são variáveis entre os indivíduos, é de fácil aplicação e possui  
alta relevância clínica. Essa classificação auxilia na definição terapêutica e na avaliação da resposta ao tratamento, contribuindo para otimizar o atendimento clínico<sup>4–6</sup> .

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Estão contemplados neste Protocolo adultos maiores de 18 anos, de ambos os sexos, portadores de IC na  
sua apresentação crônica estável, com fração de ejeção reduzida – definida como fração de ejeção < 40%.  
Adicionalmente, o uso de sacubitril valsartana hidratada está indicado para pacientes com IC que apresentem os seguintes critérios:  
- Idade inferior a 75 anos;  
- Classe funcional NYHA II;  
- Fração de ejeção reduzida (≤35%);  
- Níveis de BNP > 150 pg/mL ou NT-ProBNP > 600 pg/mL;  
- Estar em tratamento otimizado, isto é, em uso de doses máximas toleradas dos medicamentos  
- preconizados (IECA ou ARA II, betabloqueadores, espironolactona) e em doses adequadas de diuréticos, em caso de congestão;  
- Apresentar sintomas, como dispneia aos esforços, sinais de congestão, piora clínica com internações  
- recentes.  
Já para uso de dapagliflozina, o paciente deve apresentar os seguintes critérios de inclusão:  
- Idade igual ou acima de 18 anos;  
- Classe funcional NYHA II a IV;  
- Fração de ejeção reduzida (< 40%);  
- Apresentar sintomas como dispneia aos esforços, sinais de congestão, piora clínica com internações  
- recentes.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Estão excluídos deste Protocolo pacientes com IC aguda ou com IC crônica descompensada ou com IC e  
fração de ejeção preservada ou levemente reduzida (> 40%).  
Serão excluídos pacientes que apresentarem intolerância, hipersensibilidade ou contraindicações  
absolutas ao uso dos respectivos medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6. TRATAMENTO** -->
O tratamento da IC deve ser baseado em evidências e envolve ação coordenada de múltiplos profissionais  
da saúde, com a adoção de condutas medicamentosas e não medicamentosas. Detalhes adicionais sobre as recomendações encontram-se no **Apêndice 1** .

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.1 Tratamento não medicamentoso** -->
A abordagem não medicamentosa é voltada para o autocuidado e pressupõe a atuação de uma equipe interdisciplinar na redução da morbimortalidade e melhora da qualidade de vida dos pacientes com IC<sup>16–19</sup> .  
O autocuidado consiste na adoção de um conjunto de comportamentos em saúde associados a melhores resultados na adesão medicamentosa, prática de atividade física, dieta saudável, controle de peso, monitorização dos sinais e sintomas de descompensação e gerenciamento de fluidos<sup>20</sup> . A seguir, apresentam-se as principais condutas recomendadas.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.1.1 Atividade física** -->
A prática de exercício aeróbico em pacientes com IC é segura, tem vários benefícios como a redução da mortalidade e hospitalizações, e, portanto, deve ser recomendada aos indivíduos em condição de saúde estável<sup>21–</sup> 23. Entretanto, deve ser individualizada (considerando as especificidades de cada paciente) e estar inserida dentro de um programa de reabilitação cardíaca que contemple uma avaliação médica, apoio psicossocial e o planejamento da atividade física feito por profissional especializado, como um profissional de educação física.  
O plano de exercício físico deve ser adaptado a cada paciente quanto à intensidade (aeróbica e anaeróbica), tipo (resistência e força), método (contínuo e espaçado), aplicação (sistêmica, regional e respiratória), controle (supervisionado e não supervisionado) e ambiente (hospital/centro de reabilitação e domicílio). A maioria dos pacientes com IC pode realizar um treino aeróbico progressivo, até que um alvo de 25 a 60 min/dia, pelo menos 3 vezes por semana, seja atingido, incluindo atividades como caminhadas e corridas leves em esteira ou ao ar livre e bicicleta ergométrica, de acordo com as preferências do paciente e seu perfil de comorbidades coexistentes, em especial do sistema osteoarticular<sup>6</sup> .  
A atividade pode ser interrompida caso o paciente apresente angina, tontura ou piora no padrão da dispneia. Assim, o paciente deve ser orientado sobre a possibilidade de surgimento desses sintomas e sobre a necessidade de comunicá-los ao profissional da saúde.  
Pacientes com arritmia não controlada, doença valvar grave com estenose ou regurgitação, IC descompensada e pacientes com classe funcional grau IV não devem realizar exercício aeróbico, uma vez que estes são contraindicados. Pacientes mais graves (por exemplo, em classe funcional III ou com presença de comorbidades) devem realizar atividade supervisionada.  
Atualmente, existem programas e locais públicos destinados à promoção da atividade física, como o Programa Academia da Saúde e os Núcleos de Apoio à Saúde da Família (NASF), que podem auxiliar na prática efetiva do exercício<sup>24,25</sup> .

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.1.2 Restrição hidrossalina** -->
A redução da ingesta hídrica não deve ser recomendada a todos os pacientes com IC. Apenas pacientes com sinais e sintomas de congestão persistente, classe funcional avançada (III-IV) ou com hiponatremia se beneficiam desta conduta, sendo recomendada restrição de líquidos de 1,5 - 2 litros por dia, a fim de reduzir os sintomas relacionados à congestão<sup>26,27</sup> .  
Em relação à ingesta de sódio, sugere-se uma dieta normossódica (aproximadamente 7 g de sal/dia)<sup>6,28</sup> . Dietas restritivas (ingestão inferior a 5 g de sal/dia) têm mostrado piores resultados, possivelmente devido à redução de pressão oncótica intravascular, enquanto a dieta hipersódica pode levar à retenção hídrica ( **Apêndice 1** ).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.1.3 Controle do peso corporal** -->
O excesso de peso está associado ao aumento da massa e tensão no ventrículo esquerdo (VE) e, consequentemente, à deterioração dos sinais e sintomas na IC<sup>29</sup> . Entretanto, evidências confirmam que, entre os pacientes com IC, o Índice de Massa Corpórea (IMC) entre 30 e 35 kg/m<sup>2</sup> está associado a uma menor mortalidade e taxas de hospitalização quando comparado àqueles com IMC normal (entre 20 e 25 kg/m<sup>2</sup> ), o que é conhecido como "Paradoxo da obesidade". Ainda, outros estudos mostraram um aumento da mortalidade em pacientes com IMC acima de 35 kg/m<sup>2</sup> .  
Desta forma, pacientes com IC e IMC maior que 35 kg/m² (obesidade grau II), devem ser orientados a reduzir seu peso, seguindo as recomendações gerais para o controle da obesidade, que visam à prevenção de doenças cardiovasculares e à melhora de sintomas como dispneia e intolerância ao exercício físico. Para pacientes com IMC inferior a 35 kg/m², sugere-se não orientar a redução de peso, exceto se apresentarem outras condições clínicas para a qual a conduta seja indicada (por exemplo, diabetes ou osteoartrose).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.1.4 Imunização** -->
A vacinação anual contra influenza é recomendada aos pacientes com diagnóstico de IC devido ao seu impacto positivo sobre a taxa de internações por pneumonia. Embora não existam evidências consistentes que demonstrem os benefícios da vacinação para pneumococos e COVID-19 sobre os indicadores de morbimortalidade na IC, estas imunizações também são indicadas<sup>30</sup> .

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2 Tratamento medicamentoso** -->
O objetivo deste tratamento é o aumento da sobrevida, redução de hospitalização devido à IC e melhora dos sintomas, podendo ser utilizados de forma combinada quando apropriado. **A Figura 2** esquematiza o tratamento medicamentoso dos pacientes com IC que permanecem sintomáticos com o tratamento padrão. Este Protocolo considera como tratamento padrão aquele composto por IECA, betabloqueadores, ARA II, antagonistas de aldosterona, podendo estar associado a diuréticos.  
De acordo com a recomendação da Conitec em 2016, a ivabradina não está incorporada ao SUS, uma vez que as evidências demonstraram que o efeito do medicamento é conscrito à diminuição de internações com aumento de risco de fibrilação atrial<sup>31</sup> .  
**Figura 2 -** Fluxograma do tratamento medicamentoso da IC com fração de ejeção reduzida.  
<!-- Start of picture text -->
Pacientes com insuficiéncia cardiaca com fragao de ejegao reduzida em uso de terapia padréo ><br>Nao Paciente ainda \\ Sim<br>{  apresenta<br>\\__ sintomas®?<br>_ incluso para adicionar \<br>Nao Paciente atende aos critériosde \\<br>dapaglifiozina ° ou substituir IECA ou /’<br>\ ARA Il por sacubitril valsartana ¢?<br>sim<br>por Ou | Substituir ECA ou<br>: ARA II por sacubitril<br>epegatazina) valsartana<br>N30 _/ Paciente ainda \<br>( presenta \<br>\\_ sintomas®?<br>sim<br>‘Considerar<br>uso simulténeo de<br>dapagifiozina<br>‘em substituigdo e sacubitril valsartana<br>cumprir critérios@ IECAde incluso ou ARA II,°° se<br>sim<br>N3o —_/ Paciente ainda \\<br>( \,_sintomas apresenta®2<br>sim<br>Manter Considerar adigao de<br>acompanhamento<br>hidralazina<br>periédico nitratoou digoxina€<br><!-- End of picture text -->  
**a** – Este Protocolo considera tratamento padrão como uso de IECA (inibidor de enzima conversora de angiotensina), betabloqueadores, ARA II (antagonista de receptor de angiotensina II), antagonistas de aldosterona, associado ou não a diuréticos; **b** - Reavaliação de sintomas deve ser feita quatro semanas após a otimização de dose do último fármaco; **c** - Critérios de inclusão para adicionar dapagliflozina à terapia padrão: paciente adulto, com classe funcional NYHA II a IV, fração de ejeção reduzida (< 40%) e que apresente sintomas; **d** - Critérios de inclusão para substituir IECA/ARA II por sacubitril valsartana: paciente adulto, com idade inferior a 75 anos, classe funcional NYHA II, fração de ejeção reduzida (< 35%), níveis de BNP > 150 pg/mL ou NT-ProBNP > 600 pg/mL, que esteja em tratamento otimizado e apresente sintomas.  
**6.2.1 Inibidores da enzima conversora de angiotensina (IECA)**  
São indicados para tratamento de pacientes com IC com fração de ejeção reduzida sintomáticos ou assintomáticos, excluídos casos de intolerância, contraindicação e em gestantes (por risco de malformações  
fetais). Sugere-se iniciar o tratamento com IECA em doses baixas, que devem ser aumentadas gradualmente até as maiores doses toleradas dentro do alvo terapêutico. Qualquer medicamento da classe IECA pode ser usado para o tratamento da IC, sendo o enalapril e o captopril os medicamentos com maior experiência de uso e disponíveis no SUS.  
Os eventos adversos mais relevantes são tosse, hipotensão, insuficiência renal, hipercalemia e angiodema. A disfunção renal induzida por esse medicamento é um possível indicador de doença renovascular subjacente, e a monitorização periódica da função renal e de eletrólitos é indicada, em especial em pacientes com tal predisposição. O aumento da creatinina sérica pode ocorrer após o início da terapia; geralmente é inferior a 10%20% e não progressivo; 6,4% dos pacientes desenvolvem hipercalemia (> 5,5 mEq/L), sendo mais frequente naqueles com creatinina sérica elevada<sup>32</sup> . Assim, indica-se avaliação clínica e monitorização periódica da função renal e de eletrólitos nesses pacientes.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.2 Betabloqueadores** -->
O uso de betabloqueadores é indicado para pacientes com IC de fração de ejeção reduzida sintomáticos ou assintomáticos e podem ser iniciados em associação a IECA. Os betabloqueadores são o bisoprolol, succinato de metoprolol e carvedilol, sem evidência de superioridade entre eles. Contudo, apenas o succinato de metoprolol e o carvedilol estão disponíveis no SUS.  
O tratamento deve ser iniciado em pacientes compensados (não congestos), em dose baixa e gradualmente aumentada até as maiores doses toleradas ou a dose-alvo. Os pacientes devem ser orientados sobre possível piora funcional discreta nas fases iniciais do tratamento.  
Níveis pressóricos e frequência cardíaca baixos, desde que o paciente esteja assintomático, são tolerados e não devem ser motivo para redução de dose ou interrupção do uso de betabloqueadores. Inexiste certeza do benefício de outros betabloqueadores, como propranolol e atenolol, uma vez que esses não foram adequadamente avaliados em pacientes com IC e, portanto, seu uso não é preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.3 Antagonistas do receptor da angiotensina II (ARA II)** -->
Devem ser utilizados em caso de pacientes com IC com fração de ejeção reduzida sintomáticos e com intolerância ou contraindicação aos IECA, em especial aqueles que desenvolvem tosse com o uso de IECA. Assim como no uso de IECA, a avaliação clínica e a monitorização periódica da função renal e de eletrólitos são indicadas nesses pacientes. É importante salientar que pacientes intolerantes ao uso de IECA devido à hipercalemia e à perda de função renal não são candidatos ao uso de ARA II. Não se recomenda associar ARA II e IECA em pacientes com IC devido ao maior risco de piora de função renal<sup>33</sup> .  
A losartana é o único antagonista do receptor da angiotensina II disponível no SUS.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.4 Antagonistas da aldosterona** -->
O uso de antagonistas de aldosterona é indicado para pacientes com IC com fração de ejeção reduzida e sintomáticos (classe II-IV da NYHA), associados ao tratamento com IECA/ARA II e betabloqueador nas maiores doses toleradas. Devem ser utilizados com cautela em pacientes com perda da função renal e níveis de potássio sérico acima de 5,0 mmol/L, especialmente pelo risco de hipercalemia.  
Após o início do tratamento, é importante a dosagem periódica de potássio sérico (por exemplo, após 1ª semana, 1º mês de tratamento e, depois, a cada 1 a 4 meses), assim como quando houver aumento da dose. O uso de antagonistas de aldosterona associado a IECA, ARA II e diuréticos tiazídicos pode favorecer o surgimento de hipercalemia, sendo necessárias dosagens periódicas de potássio sérico em caso de mudanças posológicas maiores.  
No Brasil, o único antagonista da aldosterona disponível é a espironolactona, o qual está disponível no  
SUS.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.5 Diuréticos (de alça ou tiazídicos)** -->
Os diuréticos são eficazes no tratamento da congestão. Inexistem evidências para o seu uso em pacientes sem sintoma ou sinal de congestão.  
Os diuréticos de alça produzem diurese mais intensa e de menor duração que os diuréticos tiazídicos, sendo preferencialmente utilizados. Já em pacientes com congestão resistente, podem ser utilizados em combinação dado o efeito sinérgico entre eles.  
Os pacientes podem ser orientados a ajustar a dose diurética com base no monitoramento de sintomas, sinais de congestão (edema periférico) e peso diário. A monitorização periódica da função renal e de eletrólitos, em especial dos níveis séricos de potássio, sódio e magnésio, é recomendada dadas as possíveis interações com outros fármacos utilizados para IC.  
No SUS, o diurético de alça disponível é a furosemida e o diurético tiazídico é a hidroclorotiazida.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.6 Dapagliflozina** -->
As gliflozinas são fármacos que inibem o cotransporte de sódio e glicose, predominantemente no néfron, tendo sido descritas inicialmente como fármacos antidiabéticos de uso oral. A administração de dapagliflozina na IC em pacientes sintomáticos com fração de ejeção reduzida demonstrou redução de hospitalização por descompensação da síndrome, da mortalidade cardiovascular e da mortalidade total<sup>34</sup> .  
Conforme recomendação da Conitec<sup>35</sup> , preconiza-se associar dapagliflozina à terapia padrão (IECA, ARA II, betabloqueadores, diuréticos e antagonista de receptor de mineralocorticoides) nos tratamentos dos pacientes adultos com IC com as seguintes características:  
- Classe funcional NYHA II a IV;  
- Fração de ejeção reduzida < 40%;  
- Sintomáticos (sintomas como dispneia aos esforços, sinais de congestão, piora clínica com internações  
recentes).  
Pacientes que cumprem simultaneamente critérios para uso de dapagliflozina e sacubitril valsartana e  
persistem sintomáticos podem ter o tratamento otimizado para uso simultâneo dos dois medicamentos.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.7 Sacubitril valsartana sódica hidratada** -->
O medicamento sacubitril valsartana sódica hidratada consiste na associação de um fármaco inibidor da neprilisina (sacubitril), inibindo a degradação de substâncias vasodilatadoras, com um antagonista do receptor da angiotensina II (valsartana). O uso de sacubitril valsartana sódica hidratada foi associado a redução de  
mortalidade e hospitalização em pacientes com IC com fração de ejeção reduzida e níveis elevados de BNP/NTproBNP.  
Conforme recomendação da Conitec<sup>36,</sup> preconiza-se a substituição de IECA ou ARA II por sacubitril valsartana sódica hidratada em pacientes adultos com IC que satisfaçam as seguintes condições:  
- Idade inferior a 75 anos;  
- Classe classe funcional NYHA II;  
- Fração de ejeção reduzida < 35%;  
- BNP > 150 pg/mL ou NT-ProBNP > 600 pg/mL;  
- Em tratamento otimizado, ou seja, em uso de doses máximas toleradas dos medicamentos preconizados  
- (IECA ou ARA II, betabloqueadores, espironolactona) e em doses adequadas de diuréticos, em caso de congestão;  
- Sintomáticos (sintomas como dispneia aos esforços, sinais de congestão, piora clínica com internações recentes.  
A dose inicial recomendada é de 50 mg duas vezes ao dia. Em pacientes com uso prévio de altas doses de IECA ou ARA II e pressão arterial preservada (acima de 100 mmHg), a dose inicial recomendada é de 100 mg duas vezes ao dia. As doses devem ser progressivamente aumentadas a cada 2 a 4 semanas, acompanhadas de monitoramento da função renal, eletrólitos e hipotensão, até a dose alvo de 200 mg duas vezes ao dia.  
A definição de classe funcional, paciente sintomático e tratamento otimizado é complexa, e por isso a prescrição inicial do medicamento deve ser realizada preferencialmente por médico especialista. Uma vez iniciado o tratamento, o acompanhamento do paciente em uso de sacubitril valsartana sódica hidratada pode ser realizado no âmbito da APS.  
O sacubitril valsartana sódica hidratada é bem tolerado, e os eventos adversos mais comuns são hipotensão e tontura. Foi relatado angioedema em alguns pacientes. Devido ao risco de perda de função renal e de angioedema, esse medicamento composto não deve ser utilizado concomitantemente com IECA ou com outro ARA II. Em pacientes com uso prévio de IECA deve-se iniciar o tratamento com sacubitril valsartana sódica hidratada pelo menos 36 horas após a última dose de IECA, em especial para minimizar o risco de eventos adversos.  
Pacientes que cumprem simultaneamente critérios para uso de dapagliflozina e sacubitril valsartana e persistem sintomáticos podem ter o tratamento otimizado para uso simultâneo dos dois medicamentos.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.8 Hidralazina e nitrato de isossorbida** -->
Historicamente, a associação de hidralazina e nitrato de isossorbida foi a primeira conduta de tratamento vasodilatador com benefícios clínicos prováveis em pacientes com IC, tendo sido amplamente utilizada na década de 1980. No contexto atual do tratamento da IC, essa associação tem sido preconizada particularmente em pacientes intolerantes a IECA e ARA II por hipercalemia e perda de função renal. Da mesma forma que os IECA, o tratamento é iniciado com doses baixas, com aumento gradual conforme a tolerância.  
Adicionalmente, essa associação medicamentosa pode ser utilizada em pacientes que persistem em classe funcional III e IV da NYHA, apesar de o tratamento estar otimizado (uso de IECA/ARA II ou sacubitril valsartana, betabloqueador, antagonista da aldosterona, dapagliflozina). Essa conduta terapêutica é  
especialmente preconizada na população negra, para a qual há maior evidência de seu benefício. Na população não negra, as evidências de benefício são mais frágeis.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.2.9 Digoxina** -->
O benefício do uso da digoxina se restringe a pacientes que permanecem sintomáticos apesar do tratamento estar otimizado com doses apropriadas de acordo com os estudos clínicos que comprovaram os benefícios (uso de IECA/ARA II ou sacubitril valsartana, betabloqueador, antagonista da aldosterona, dapagliflozina). A digoxina possui uma estreita janela terapêutica e provoca efeitos tóxicos como arritmias, redução da condução atrioventricular, bradicardia sinusal, náusea, vômitos, diarreia e distúrbios visuais.  
Doses baixas (0,125 pg/mL em dias alternados) são preferíveis, podendo-se aumentar com cautela as doses caso persistam os sintomas. A dosagem de níveis séricos de digoxina pode ser realizada para ajuste de dose ou na suspeita clínica de intoxicação. Deve-se ter cautela com seu uso em pacientes com função renal alterada, baixo peso, idosos ou dificuldades de entendimento sobre o uso do medicamento; nestes casos, é boa prática iniciar com doses baixas e ajustar de acordo com sintomatologia e dosagem sérica, para assegurar eficácia e segurança.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.3 Medicamentos** -->
- Captopril: comprimidos de 25 mg;  
- Carvedilol: comprimidos de 3,125 mg, 6,25 mg, 12,5 mg e 25 mg;  
- Cloridrato de hidralazina: comprimidos de 25 mg e 50 mg;  
- Dapagliflozina: comprimidos de 10 mg;  
- Digoxina: comprimidos de 0,25 mg;  
- Dinitrato de isossorbida: comprimido sublingual de 5 mg;  
- Espironolactona: comprimidos de 25 mg e 100 mg;  
- Furosemida: comprimidos de 40 mg;  
- Hidroclorotiazida: comprimidos de 12,5 mg e 25 mg;  
- Losartana potássica: comprimidos de 50 mg;  
- Maleato de enalapril: comprimidos de 5 mg, 10 mg e 20 mg;  
- Mononitrato de isossorbida: comprimidos de 20 e 40 mg;  
- Sacubitril valsartana sódica hidratada: comprimidos de 50, 100 e 200 mg; e  
- Succinato de metoprolol: comprimidos de liberação prolongada de 25 mg, 50 mg e 100 mg.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6.4 Esquemas de administração** -->
Os esquemas de administração segundo classe farmacêutica, dose inicial e dose-alvo estão representados no quadro a seguir<sup>4–6</sup> .  
**Quadro 5** - Esquemas de administração.  
|**Classe farmacêutica**|**Fármacos**|**Dose inicial**|**Dose-alvo**|
|---|---|---|---|
|**Antagonista de**<br>**aldosterona**|Espironolactona (25 e 100 mg)|12,5-25 mg, 1 x ao dia|25-50 mg, 1 x ao dia|
|**Antagonista de receptor**<br>**de angiotensina II**|Losartana potássica (50 mg)|25 mg, 1 x ao dia|150 mg ao dia (dose única<br>ou dividida em 2 vezes ao<br>dia)|
|**Betabloueadores**|Succinato de metoprolol (25, 50 e<br>100 mg)|12,5-25 mg, 1 x ao dia|200 mg, 1 x ao dia|
|**q**|Carvedilol (3,125, 6,25, 12,5 e 25<br>mg)|3,125 mg, 2 x ao dia|25 mg, 2 x ao dia|
|**Digitálico**|Digoxina (0,25 mg)|0,125 mg em dias<br>alternados a 0,25 mg, 1<br>x ao dia|Dosagem de nível sérico<br>pode auxiliar no ajuste|
|**Diurético de alça ***|Furosemida (40 mg)|20-40 mg 1x ao dia|40-240 mg (dose usual)|
|**Diurético tiazídico**|Hidroclorotiazida (12,5 e 25 mg)|25 mg 1x ao dia|12,5-100 mg (dose usual)|
|**Inibidores da enzima**<br>**conversora de**|Maleato de enalapril (5, 10 e 20<br>mg)|2,5 mg, 2 x ao dia|10-20 mg, 2 x ao dia|
|**angiotensina**|Captopril (25 mg)|6,25 mg, 3 x ao dia|50 mg, 3 x ao dia|
|**Inibidores da neprilisina e**<br>**dos receptores da**<br>**angiotensina**|Sacubitril valsartana sódica<br>hidratada (50, 100 e 200 mg)|50 mg, 2x ao dia.|200 mg, 2x ao dia.|
|**Inibidor da SGLT2**|Dapagliflozina (10 mg)|10 mg 1 x ao dia|10 mg 1 x ao dia|
|**Nitratos**|Dinitrato de isossorbida (5 mg)<br>Mononitrato de isossorbida (20 e<br>40 mg)|10-20 mg, 3 x ao dia|40 mg, 3 x ao dia|
|**Vasodilatador**|Hidralazina (25 e 50 mg)|12,5-25 mg, 3 x ao dia|50-100 mg, 3 x ao dia|  
* As doses são ajustadas de acordo com a presença de congestão. São utilizados inicialmente 1 vez ao dia, podendo-se utilizar 2-3 vezes ao dia.  
SGLT2: _Sodium Glucose cotransporter 2_ (cotransportador de sódio e glicose 2).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **7. MONITORAMENTO** -->
Na maioria dos casos, a apresentação da IC não é grave, sendo o acompanhamento preferencialmente ambulatorial, no âmbito da APS, para avaliação da resposta terapêutica, potenciais necessidades de ajuste no tratamento medicamentoso e orientações para o autocuidado. A abordagem do paciente em um serviço especializado, deve ser realizada em: (a) pacientes com doença descompensada agudamente; (b) pacientes com classe funcional NYHA III-IV apesar do tratamento clínico otimizado; (c) pacientes com internação hospitalar recente por IC; e (d) pacientes com disfunção cardíaca grave que possam ser candidatos a dispositivos ou transplante cardíaco.  
O uso regular dos medicamentos prescritos é essencial para o tratamento da IC, uma vez que se associa com a diminuição das taxas de morbimortalidade, dos custos com a saúde e com a melhora na qualidade de vida<sup>6,26,27</sup> . Desta forma, é imprescindível que os profissionais de saúde implementem estratégias para melhorar a adesão medicamentosa nos programas de autocuidado com a IC por meio de intervenções de educação em saúde, mudanças de comportamento e psicossociais<sup>37–39</sup> . É recomendado que os profissionais de saúde ofereçam informações escritas e verbais aos pacientes e seus referentes sociais sobre o curso da doença, etapas terapêuticas necessárias, indicações e benefícios dos medicamentos prescritos, dose e possíveis eventos adversos. Também devem ser abordados o cronograma mais apropriado para uso do medicamento e a conduta em caso de esquecimento de dose, por meio de uma abordagem individualizada em um ambiente calmo e privativo. Nesse sentido, podem ser utilizados materiais de apoio, como folhetos, boletins ou outras ferramentas interativas<sup>37,38</sup> .  
É importante que, durante esta abordagem, o profissional verifique se o paciente e seu referente social compreenderam a importância de cada medicamento no tratamento de sua doença, questionando como estes vêm sendo utilizados, a fim de identificar dificuldades na adesão que auxiliem na elaboração de um plano de enfrentamento de barreiras.  
A visita domiciliar é um importante instrumento para o monitoramento da adesão medicamentosa a ser realizado pela APS. Além disso, outras ferramentas podem ser utilizadas para melhorar a adesão ao tratamento medicamentoso, como o uso de lembretes fixados em locais visíveis no domicílio do paciente e despertadores eletrônicos<sup>40</sup> .

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **7.1 Telemonitoramento por suporte telefônico** -->
Apesar da grande variabilidade das intervenções relacionadas ao telemonitoramento do paciente com IC, geralmente adaptadas ao contexto local, evidências procedentes de ensaios clínicos mostram redução de mortalidade e hospitalização com programas estruturados de telemonitoramento<sup>41</sup> . Os serviços de saúde podem considerar a realização de telemonitoramento por suporte telefônico em pacientes com IC, em especial para aqueles com maior risco de desestabilização, como após alta hospitalar, classe funcional III ou IV, ou ainda aqueles com dificuldade de locomoção.  
As orientações devem ser preferencialmente realizadas por profissionais com curso superior com foco em orientações clínicas e educacionais (informações sobre a IC, autocuidado, monitorização de sinais e sintomas, orientações sobre o uso de medicamentos e dieta saudável). Não há um consenso na literatura sobre a frequência das ligações e a maneira correta de monitorar o paciente, por isso recomenda-se que o telemonitoramento seja individualizado de acordo com a condição clínica do paciente e a disponibilidade de recursos humanos, materiais e financeiros.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a monitorização do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Na relação de moléstias consideradas para fins de concessão de benefício previdenciário está a cardiopatia grave. Dado que o CID-10 de IC isoladamente não configura cardiopatia grave, é importante que o médico que  
faz o acompanhamento do paciente informe, para fins previdenciários, o tempo de doença, a classe funcional NYHA, a presença de disfunção ventricular e o tratamento em uso.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo. Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A APS no SUS dispõe do arsenal medicamentoso para o tratamento ambulatorial da IC. Centros especializados (clínicas e ambulatórios) são encontrados nos grandes centros metropolitanos, a maioria vinculada a hospitais universitários e filantrópicos com atendimento multidisciplinar e acesso a dispositivos de estimulação elétrica (cardiodesfibriladores implantáveis - CDI) e centros transplantadores. O **Quadro 6** indica que pacientes com IC devem ser acompanhados na Atenção Primária, em serviços especializados ou ser encaminhados a serviços de emergência.  
**Quadro 6 -** Níveis de atenção à saúde para pacientes com IC e referenciamento para serviço especializado<sup>42</sup> .  
|**Níveis de atenção**|**Características clínicas**|
|---|---|
|Atenção<br>Primária<br>à|• Suspeita clínica de IC; ou|
|Saúde (APS)|• Classe funcional I e II; ou|
||• Pacientes com diagnóstico recente, em otimização do tratamento.|
|Serviço especializado*|• Classe funcional NYHA II com critérios para início de sacubitril valsartana sódica hidratada;<br>ou<br>• Classe funcional NYHA III e IV em pacientes já com tratamento clínico otimizado em uso de<br>doses maximamente toleradas de IECA/ARA II, betabloqueador e espironolactona; ou<br>• Episódio de internação hospitalar devido à IC descompensada no último ano; ou<br>• Suspeita de insuficiência cardíaca sem possibilidade de investigação com ecocardiografia ou<br>peptídeo natriurético cerebral; ou<br>• Disfunção ventricular grave, sintomáticos com terapia otimizada, candidatos a dispositivos ou<br>transplante cardíaco; ou<br>• Pacientes com IC que apresentam fibrilação atrial; ou<br>• Pacientes com diagnóstico ou suspeita de IC com fração de ejeção preservada.|
|Serviço de emergência|• Pacientes com IC com sinais de hipoperfusão, síncope ou com piora recente de sintomas e sinais<br>de congestão, ou<br>• Suspeita de IC aguda.|  
ARA II: antagonista de receptor de angiotensina II; IC: insuficiência cardíaca; IECA: inibidores de enzima conversora de angiotensina; NYHA: _New York Heart Association_ ; * Nestes casos, a APS é corresponsável pelo atendimento dos pacientes e pela atenção a demais problemas de saúde.  
Existem algumas situações que devem ser lembradas como motivadoras de encaminhamento para o atendimento na atenção especializada: pacientes com indicação de dispositivos de estimulação elétrica ou CDI,  
pacientes com indicação para transplante cardíaco e pacientes com fibrilação atrial. Todas essas condições têm diretrizes específicas do Ministério da Saúde para o seu tratamento<sup>43</sup> .  
É comum a coexistência de IC com fibrilação atrial, podendo levar a complicações embólicas e a exacerbação de sintomas de IC. Alguns aspectos devem ser considerados nesses pacientes, como a identificação de causas corrigíveis, a necessidade de controle de ritmo e de frequência cardíaca e a necessidade de anticoagulação. Sugere-se que esses pacientes sejam avaliados em serviço especializado com acompanhamento concomitante na APS.  
Com relação aos casos mais avançados da doença, intervenções de cunho especializado, como implante de dispositivos e transplante cardíaco, podem ser consideradas. A terapia de ressincronização cardíaca (TRC) é indicada para pacientes com tratamento clínico otimizado, ainda sintomáticos, principalmente com classe funcional III e IV e QRS > 150 ms. CDI possuem benefício documentado em pacientes com maior risco de morte súbita (por exemplo, parada cardíaca prévia ou história de taquicardia ventricular sustentada). O transplante cardíaco é reservado a pacientes com IC funcional III, conforme indicação médica, critérios estabelecidos pelo SUS e na ausência de alternativas disponíveis<sup>43,44</sup> .  
O escopo deste Protocolo não contempla essas terapias, mas o médico da APS deve conhecer a existência de tais terapêuticas e saber reconhecer o indivíduo que precisa de encaminhamento para ambulatório especializado em IC. O protocolo de encaminhamento consegue abranger tais pacientes<sup>44</sup> .  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **10. REFERÊNCIAS** -->
1. Colluci W, Borlaug B. Evaluation of the patient with suspected of heart failure. UpToDate. 2022.  
2. Arruda VL de, Machado LMG, Lima JC, Silva PR de S. Tendência da mortalidade por insuficiência cardíaca no Brasil: 1998 a 2019. Revista Brasileira de Epidemiologia [Internet]. 2022 ago 12 [citado 2022 nov 20];25. Available from: http://www.scielo.br/j/rbepid/a/sRPvQmSptS6Tj9D9QVR9rfC/?lang=pt  
3. Brasil / Ministério da Saúde. DataSUS. 2022.  
4. Bocchi E, Marcondes-Braga F, Bacal F, Ferraz A, Albuquerque D, Rodrigues D. Sociedade Brasileira  
de Cardiologia. Atualização da Diretriz Brasileira de Insuficiência Cardíaca Crônica - 2012. Arq Bras Cardiol. 2012;98(1):1–33.  
5. Marcondes-Braga FG, Moura LAZ, Issa VS, Vieira JL, Rohde LE, Simões MV, et al. Atualização de Tópicos Emergentes da Diretriz Brasileira de Insuficiência Cardíaca – 2021. Arq Bras Cardiol. 2021 maio 26;  
6. Rohde LEP, Montera MW, Bocchi EA, Clausell NO, de Albuquerque DC, Rassi S, et al. Diretriz brasileira de insuficiência cardíaca crônica e aguda. Arq Bras Cardiol. 2018;111(3).  
7. Burri E, Hochholzer K, Arenja N, Martin-Braschler H, Kaestner L, Gekeler H, et al. B-type natriuretic peptide in the evaluation and management of dyspnoea in primary care. J Intern Med. 2012 nov;272(5):504–13.  
8. Bozkurt B, Coats AJ, Tsutsui H, Abdelhamid M, Adamopoulos S, Albert N, et al. Universal Definition and Classification of Heart Failure: A Report of the Heart Failure Society of America, Heart Failure Association of the European Society of Cardiology, Japanese Heart Failure Society and Writing Committee of the Universal Definition of Heart Failure. J Card Fail. 2021;27(4).  
9. McKee PA, Castelli WP, McNamara PM, Kannel WB. The Natural History of Congestive Heart Failure: The Framingham Study. New England Journal of Medicine. 1971 dez 23;285(26):1441–6.  
10. HARLAN WR. Chronic Congestive Heart Failure in Coronary Artery Disease: Clinical Criteria. Ann Intern Med [Internet]. 1977 fev 1;86(2):133. Available from: http://annals.org/article.aspx?doi=10.7326/00034819-86-2-133  
11. Carlson KJ, Lee DCS, Goroll AH, Leahy M, Johnson RA. An analysis of physicians’ reasons for prescribing long-term digitalis therapy in outpatients. J Chronic Dis. 1985;38(9).  
12. Eriksson H, Caidaul K, Larsson B, Ohlson LO, Welin L, Wilhelmsen L, et al. Cardiac and pulmonary causes of dyspnoea-validation of a scoring test for clinical-epidemiological use: The study of men born in 1913. Eur Heart J. 1987;8(7).  
13. Beck-da-Silva L, Rohde LE, Goldraich L, Clausell N. Clinical findings, natriuretic peptides, and echocardiography: integrating tools to optimize heart failure management. Vol. 13, Congestive heart failure (Greenwich, Conn.). 2007.  
14. Rohde LE, Beck-da-Silva L, Goldraich L, Grazziotin TC, Palombini D v, Polanczyk CA, et al. Reliability and prognostic value of traditional signs and symptoms in outpatients with congestive heart failure. Can J Cardiol. 2004 maio 15;20(7):697–702.  
15. Kelder JC, Cowie MR, McDonagh TA, Hardman SMC, Grobbee DE, Cost B, et al. Quantifying the added value of BNP in suspected heart failure in general practice: An individual patient data meta-analysis. Heart. 2011;97(12).  
16. Kamiya K, Sato Y, Takahashi T, Tsuchihashi-Makaya M, Kotooka N, Ikegame T, et al. Multidisciplinary Cardiac Rehabilitation and Long-Term Prognosis in Patients With Heart Failure. Circ Heart Fail. 2020;13(10).  
17. Takeda A, Martin N, Taylor RS, Taylor SJC. Disease management interventions for heart failure. Vol. 2019, Cochrane Database of Systematic Reviews. 2019.  
18. Morton G, Masters J, Cowburn PJ. Multidisciplinary team approach to heart failure management. Heart. 2018 ago;104(16):1376–82.  
19. Parajuli DR, Kourbelis C, Franzon J, Newman P, Mckinnon RA, Shakib S, et al. Effectiveness of the Pharmacist-Involved Multidisciplinary Management of Heart Failure to Improve Hospitalizations and Mortality Rates in 4630 Patients: A Systematic Review and Meta-Analysis of Randomized Controlled Trials. J Card Fail. 2019 set;25(9):744–56.  
20. Riegel B, Moser DK, Buck HG, VaughanDickson V, B.Dunbar S, Lee CS, et al. Self-care for the prevention and management of cardiovascular disease and stroke: A scientific statement for healthcare professionals from the American heart association. J Am Heart Assoc. 2017;6(9).  
21. Malandish A, Ghadamyari N, Karimi A, Naderi M. The role of exercise training on cardiovascular peptides in patients with heart failure: A systematic review and meta-analysis. Curr Res Physiol [Internet]. 2022 jan 1 [citado 2022 nov 17];5:270–86. Available from: https://pubmed.ncbi.nlm.nih.gov/35800138/ 22. Sagar VA, Davies EJ, Briscoe S, Coats AJS, Dalal HM, Lough F, et al. Exercise-based rehabilitation for heart failure: systematic review and meta-analysis. Open Heart. 2015;2(1).  
23. Fukuta H, Goto T, Wakami K, Kamiya T, Ohte N. Effects of exercise training on cardiac function, exercise capacity, and quality of life in heart failure with preserved ejection fraction: a meta-analysis of randomized controlled trials. Vol. 24, Heart Failure Reviews. 2019.  
24. Kuhmmer R, Lazzaretti RK, Guterres CM, Raimundo FV, Leite LEA, Delabary TS, et al. Effectiveness of multidisciplinary intervention on blood pressure control in primary health care: A randomized clinical trial. BMC Health Serv Res. 2016;16(1).  
25. de Sá GBAR, Dornelles GC, Cruz KG, Amorim RC de A, Andrade SSC de A, Oliveira TP, et al. O Programa Academia da Saúde como estratégia de promoção da saúde e modos de vida saudáveis: Cenário nacional de implementação. Ciencia e Saude Coletiva. 2016;21(6).  
26. Heidenreich PA, Bozkurt B, Aguilar D, Allen LA, Byun JJ, Colvin MM, et al. 2022 AHA/ACC/HFSA Guideline for the Management of Heart Failure: A Report of the American College of Cardiology/American Heart Association Joint Committee on Clinical Practice Guidelines. Circulation [Internet]. 2022 maio 3 [citado 2022 nov 20];145(18):E895–1032. Available from: https://www.ahajournals.org/doi/abs/10.1161/CIR.0000000000001063  
27. McDonagh TA, Metra M, Adamo M, Gardner RS, Baumbach A, Böhm M, et al. 2021 ESC Guidelines for the diagnosis and treatment of acute and chronic heart failure. Vol. 42, European Heart Journal. 2021.  
28. Fabricio CG, Tanaka DM, de Souza Gentil JR, Ferreira Amato CA, Marques F, Schwartzmann PV, et al. A normal sodium diet preserves serum sodium levels during treatment of acute decompensated heart failure: A prospective, blind and randomized trial. Clin Nutr ESPEN. 2019;32. 29. Mahajan R, Stokes M, Elliott A, Munawar DA, Khokhar KB, Thiyagarajah A, et al. Complex interaction  
of obesity, intentional weight loss and heart failure: A systematic review and meta-analysis. Heart. 2020;106(1).  
30. Marques Antunes M, Duarte GS, Brito D, Borges M, Costa J, Ferreira JJ, et al. Pneumococcal vaccination in adults at very high risk or with established cardiovascular disease: Systematic review and metaanalysis. Vol. 7, European Heart Journal - Quality of Care and Clinical Outcomes. 2021.  
31. Brasil / Ministério da Saúde / Comissão Nacional de Incorporação de Tecnologias no SUS. Ivabradina para o tratamento de insuficiência cardíaca crônica moderada a grave em indivíduos com frequência cardíaca ≥70 bpm e que toleram menos de 50% da dose alvo recomendada de agentes betabloqueadores . 2016.  
32. Schoolwerth AC, Sica DA, Ballermann BJ, Wilcox CS. Renal considerations in angiotensin converting enzyme inhibitor therapy: A statement for healthcare professionals from the council on the kidney in cardiovascular disease and the council for high blood pressure research of the american heart association. Vol. 104, Circulation. 2001.  
33. Ponikowski P, Voors AA, Anker SD, Bueno H, Cleland JGF, Coats AJS, et al. 2016 ESC Guidelines for the diagnosis and treatment of acute and chronic heart failure. Eur Heart J [Internet]. 2016 jul 14;37(27):2129–200. Available from: https://academic.oup.com/eurheartj/articlelookup/doi/10.1093/eurheartj/ehw128  
34. McMurray J, Solomon S, Inzucchi S, Køber L, Kosiborod M, Martinez F, et al. Dapagliflozin in Patients with Heart Failure and Reduced Ejection Fraction. The , (21), . https://doi.org/10.1056/NEJMoa1911303. New England journal of medicine. 2019;381(21).  
35. Brasil / Ministério da Saúde / Comissão Nacional de Incorporação de Tecnologias no SUS. Dapagliflozina para o tratamento adicional de pacientes adultos com insuficiência cardíaca com fração de ejeção reduzida (FEVE<40%), NYHA II-IV e sintomáticos apesar do uso de terapia padrão com inibidor da Enzima Conversora de Angiotensina (IECA) ou Antagonista do Receptor da Angiotensina II (ARA II), com betabloqueadores, diuréticos e antagonista do receptor de mineralocorticoides. https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20220711_relatorio_734_dapagliflozina_ic.pdf. 2022.  
36. Brasil / Ministério da Saúde / Comissão Nacional de Incorporação de Tecnologias no SUS. Sacubitril valsartana para o tratamento de pacientes adultos com insuficiência cardíaca crônica sintomática (NYHA classe II-IV) com fração de ejeção reduzida. https://www.gov.br/conitec/ptbr/midias/relatorios/2019/relatorio_sacubitril_valsartana_icc_final_454_2019.pdf. 2019.  
37. Jaarsma T, Hill L, Bayes-Genis A, la Rocca HPB, Castiello T, Čelutkienė J, et al. Self-care of heart failure patients: practical management recommendations from the Heart Failure Association of the European Society of Cardiology. Eur J Heart Fail. 2021;23(1).  
38. Conn VS, Ruppar TM, Enriquez M, Cooper P. Medication Adherence Interventions That Target Subjects with Adherence Problems: Systematic Review and Meta-analysis. Res Social Adm Pharm 2016. 2017;12(2):218–46.  
39. Toback M, Clark N. Strategies to improve self-management in heart failure patients. Vol. 53, Contemporary Nurse. 2017.  
40. Unverzagt S, Meyer G, Mittmann S, Samos FA, Unverzagt M, Prondzinsky R. Verbesserung der Adhärenz bei Herzinsuffizienz: Systematisches Review und Metaanalyse zu Interventionen bei medikamentöser Therapie und Lebensstilmodifikationen. Dtsch Arztebl Int. 2016;113(25).  
41. Inglis SC, Clark RA, Dierckx R, Prieto-Merino D, Cleland JG. Structured telephone support or noninvasive telemonitoring for patients with heart failure. Cochrane Database of Systematic Reviews. 2015 out 31;2015(10).  
42. TelessaúdeRS. RegulaSUS: protocolos de regulação ambulatorial - cardiologia adulto. https://www.ufrgs.br/telessauders/documentos/protocolos_resumos/cardio adulto.pdf. 2016.  
43. Brasil / Ministério da Saúde. Portaria n<sup>o</sup> 2600, de 21 de outubro de 2009. Aprova o regulamento técnico do sistema nacional de transplantes. Diário Oficial da União http://bvsms.saude.gov.br/bvs/saudelegis/gm/2009/prt2600_21_10_2009.html; 2009.  
44. Brasil / Ministério da Saúde. Cardiologia. Protocolos de encaminhamento da atenção básica para atenção especializada. 2016.  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**  
CAPTOPRIL, CARVEDILOL, DAPAGLIFLOZINA, DIGOXINA, DINITRATO DE ISOSSORBIDA, ENALAPRIL, ESPIRONOLACTONA, FUROSEMIDA, HIDRALAZINA, HIDROCLOROTIAZIDA, LOSARTANA, METOPROLOL, MONONITRATO DE ISOSSORBIDA E SACUBITRIL VALSARTANA SÓDICA HIDRATADA  
Eu,___________________________________________________________________ (nome do [a]  
paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **captopril, carvedilol, dapagliflozina, digoxina, dinitrato de isossorbida, enalapril, espironolactona, furosemida, hidralazina, hidroclorotiazida, losartana, metoprolol, mononitrato de isossorbida ou sacubitril valsartana sódica hidratada** , indicada para o tratamento de insuficiência cardíaca com fração de ejeção reduzida, segundo critérios de elegibilidade definidos neste Protocolo.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico(a)  
________________________________________________________________________ (nome do(a)  
médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode reduzir o risco de morte e de hospitalização relacionada à insuficiência cardíaca com fração de ejeção reduzida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
 **Carvedilol e metoprolol** são contraindicados em casos de asma e bloqueio sinoatrial ou atrioventricular de alto-grau; e podem ser contraindicados em casos de síndrome metabólica, intolerância à lactose e pacientes atletas e fisicamente ativos. Além disso, medicamentos desta classe terapêutica podem causas broncoespasmo, bradicardia, distúrbios da condução atrioventricular, vasoconstrição periférica, insônia, pesadelos, depressão, astenia e disfunção sexual. Podem contribuir para a intolerância à glicose (exceto carvedilol), hipertrigliceridemia, elevação do colesterol-LDL e redução do colesterol-HDL. A retirada abrupta deve ser evitada, pois pode provocar taquicardia reflexa e mal-estar;  
 **Captopril e enalapril** são contraindicados em gestantes, indivíduos com edema angioneurótico prévio, hipercalemia (potássio > 5,5 mmol/L) e estenose arterial renal bilateral; e podem ser contraindicados em mulheres em idade reprodutiva sem contracepção confiável. Tosse seca, piora da função renal, em geral, transitória, hipercalemia em pacientes com insuficiência renal, são os principais eventos adversos;  **Dapagliflozina** é contraindicada no segundo e terceiro trimestres da gestação. Os principais eventos adversos são depleção de volume, infecções urinárias, infecções genitais, hipoglicemia;  **Digoxina** é medicamento de janela terapêutica pequena. Os eventos adversos mais comuns são Arritmias, distúrbios gastrointestinais e visuais e alterações eletrocardiográficas;  **Dinitrato de isossorbida** e **mononitrato de isossorbida** são contraindicados para uso por pacientes que apresentam pressão arterial baixa. Os eventos adversos mais comuns são cefaleia, hipotensão, hipotensão postural, síncope;  
 **Espironolactona** é contraindicada em caso de insuficiência renal aguda, diminuição significativa da função renal, anúria; doença de addison; hipercalemia. Os principais eventos adversos são ginecomastia e hiperpotassemia;  
 **Furosemida** é contraindicada para pacientes com insuficiência renal com anúria, pré-coma e coma associado à encefalopatia hepática, hipopotassemia grave, hiponatremia grave, hipovolemia ou desidratação. Os principais eventos adversos de diuréticos são fraqueza, cãibras, hipovolemia e disfunção erétil;  
 Os principais eventos adversos do uso de **hidralazina** são cefaleia, flushing (rubor), taquicardia reflexa, palpitação, vertigens, congestão nasal, distúrbios gastrintestinais e reação lupus-like;  
 **Hidroclorotiazida é** contraindicada em caso de gota, se taxa de filtração glomerular < 30 mL/min/1,73m<sup>2</sup> , a menos que em associação com diurético de alça (p.ex. furosemida), devendo ser realizada dosagem sérica periódica de eletrólitos. Pode ser contraindicada em indivíduos com síndrome metabólica, intolerância à glicose, gravidez, hipercalcemia e hipocalemia. Os principais eventos adversos são fraqueza, cãibras, hipovolemia, disfunção erétil, hiponatremia, hipocalemia, hipercalcemia e aumento do ácido úrico;  
 **Losartana** é contraindicada em gestantes, hipercalemia (potássio > 5,5 mmol/L) e estenose arterial renal bilateral; e pode ser contraindicado em mulheres em idade reprodutiva sem contracepção confiável. Além disso, o medicamento pode causar alterações transitórias da função renal (aumento de ureia e creatinina sérica) e a hipercalemia, especialmente na presença de insuficiência renal;  
 **Sacubitril valsartana sódica hidratada** é contraindicado em gestantes e não deve ser usado concomitantemente com inibidores de enzima conversora de angiotensina (IECA) e antagonistas de receptor de angiotensina II. Em pacientes com uso prévio de IECA, deve-se iniciar o tratamento com sacubitril valsartana sódica hidratada pelo menos 36 horas após a última dose de IECA, em especial para minimizar o risco de eventos adversos.  
 Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (  ) Captopril (  ) Furosemida  
- (  ) Carvedilol  
- (  ) Hidralazina  
- (  ) Dapagliflozina (  ) Hidroclorotiazida  
- (  ) Digoxina  
- (  ) Dinitrato de isossorbida  
- (  ) Enalapril  
- (  ) Espironolactona  
- (  ) Losartana  
- (  ) Metoprolol  
- (  ) Mononitrato de isossorbida  
- (  ) Sacubitril valsartana sódica hidratada  
<!-- Start of picture text -->
Local:                                                                                                 Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>_____________________________________<br>Assinatura e carimbo do médico<br>Data:______________________<br><!-- End of picture text -->  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **1. ESCOPO E FINALIDADE DO PROTOCOLO** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Cardíaca com Fração de Ejeção Reduzida, contendo a descrição da metodologia de busca de evidências científicas e as recomendações constantes em seu texto.  
Este Protocolo tem como público-alvo os profissionais da saúde envolvidos na atenção do paciente com insuficiência cardíaca (IC), em especial médicos e enfermeiros que atuam na Atenção Primária e na Atenção Especializada, ambulatorial, no Sistema Único de Saúde (SUS).  
Os indivíduos com IC na sua apresentação crônica estável, com fração de ejeção reduzida – definida como menor ou igual a 40% – são a população-alvo destas recomendações. As recomendações são aplicáveis a pacientes ambulatoriais, com classe funcional NYHA I, II e III; contudo, algumas recomendações também podem se estender a pacientes com classe funcional IV.  
Os pacientes com IC aguda ou com IC crônica descompensada não fazem parte do escopo deste Protocolo. Da mesma forma, o presente documento não avalia intervenções no âmbito do atendimento especializado na Atenção Hospitalar.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: Alteração pós publicação -->
Depois da publicação, em setembro de 2024, da Portaria Conjunta SAES-SECTICS/MS nº 10, de 13/09/2024, foi necessária a correção do trecho “Deve-se suspeitar de ICFEP no paciente com achados característicos de IC na história clínica, exame físico e radiografia de tórax, com ecocardiografia mostrando fração de ejeção do ventrículo esquerdo normal (menor que 50%), em especial na apresentação de BNP ou NTproBNP elevados, uma vez descartados outros diagnósticos diferenciais”, uma vez que a fração de ejeção do ventrículo esquerdo normal é maior que 50%. Assim, a correção foi realizada em novembro de 2024.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **2. EQUIPE DE ELABORAÇÃO E PARTES INTERESSADAS** -->
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas, além de metodologistas, sob coordenação do DGITS/SECTICS/MS. Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse ( **Quadro A** ), que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
**Quadro A** - Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos benefícios abaixo?  
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|  
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|---|---|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma|(   ) Sim|
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|  
**Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas**  
A versão preliminar do texto foi pautada na 104ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, que ocorreu em 22 de novembro de 2022. Participaram desta  
reunião representantes da Secretaria de Atenção Especializada à Saúde (SAES/MS), da Secretaria de Atenção Primária à Saúde (SAPS/MS), da Secretaria de Vigilância em Saúde (SVS/MS), da Secretaria Especial de Saúde Indígena (SESAI/MS) e da Secretaria de Ciência, Tecnologia, Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS/MS), quais sejam: do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Ciência e Tecnologia (DECIT/SECTICS/MS) e do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS). Os membros presentes da Subcomissão recomendaram pautar a apreciação do documento pelo Plenário da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Durante a reunião, decidiu-se que a atualização das Diretrizes Brasileiras para Diagnóstico e Tratamento da Insuficiência Cardíaca com fração de ejeção reduzida passaria a ser o Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Cardíaca.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **Consulta pública** -->
A Consulta Pública nº 93/2022, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Cardíaca com Fração de Ejeção Reduzida, foi realizada entre os dias 14/12/2022 e 02/01/2023. Foram recebidas 189 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/assuntos/participacao-social/consultas-publicas/encerradas.</u>

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **3. BUSCA DA EVIDÊNCIA E RECOMENDAÇÕES** -->
Nesta atualização, foram adotadas as recomendações que já constavam nas Diretrizes Brasileiras para Diagnóstico e Tratamento da Insuficiência Cardíaca com fração de ejeção reduzida, publicadas por meio da Portaria Conjunta SAES-SCTIE/MS nº 17, de 18 de novembro de 2020, acrescentando-se as recomendações do Relatório de Recomendação da Conitec nº 734, de junho de 2022, o qual recomendou a incorporação da dapagliflozina para o tratamento adicional de pacientes adultos com insuficiência cardíaca com fração de ejeção reduzida (FEVE≤40%), NYHA II-IV e sintomáticos apesar do uso de terapia padrão com inibidor da Enzima Conversora de Angiotensina (IECA) ou Antagonista do Receptor da angiotensina II (ARA II), com betabloqueadores, diuréticos e antagonista do receptor de mineralocorticoides, com posterior revisão do documento final por um painel de especialistas.  
Para a atualização, um novo painel de especialistas foi consultado entre outubro e novembro de 2022, que sugeriu a avaliação de ampliação do uso sacubitril valsartana visando equalizar os critérios de indicação de uso, considerando as semelhanças nos critérios de inclusão dos ensaios clínicos de ambos os medicamentos (i.e., dapagliflozina e sacubitril valsartana). Desta forma, a presente atualização preconiza o uso de sacubitril valsartana conforme sua incorporação no âmbito do SUS (Portaria SCTIE/MS nº 40, de 09 de agosto de 2019).  
Em que pese os especialistas julgarem que a mesma população poderia utilizar sacubitril valsartana e dapagliflozina sequencialmente ou em associação, durante sua 115ª Reunião Ordinária, ocorrida em 01 de dezembro de 2022, o Plenário da Conitec recomendou que pacientes que atendam simultaneamente aos critérios de inclusão para uso de dapagliflozina e sacubitril valsartana devem iniciar o tratamento com dapagliflozina, tendo em vista o menor custo da aquisição e maior comodidade de seu uso. Caso os pacientes permaneçam sintomáticos com o uso de dapagliflozina e atendam aos critérios de inclusão de uso de sacubitril valsartana, podem associar o uso de dapagliflozina à sacubitril valsartana ou substituir dapagliflozina e IECA ou ARA II por sacubitril valsartana. Na 116ª Reunião Ordinária, ocorrida em 16 de março de 2023 e considerando as  
contribuições recebidas na consulta pública, o Plenário da Conitec recomendou que o PCDT fosse aprovado considerado o fluxograma de tratamento inicialmente proposto pelo grupo elaborador, o que está consolidado nesta versão do PCDT na **Figura 2** .

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **3.1 Avaliação da qualidade da evidência** -->
Para a avaliação da qualidade da evidência, foi utilizado o sistema GRADE. Foram desenvolvidas tabelas de evidências na plataforma GRADEpro (GRADEpro GDT) para cada questão PICO, sendo considerados avaliação do risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferente do da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos) e efeito relativo e absoluto de cada questão ( **Quadro B** ).  
**Quadro B -** Níveis de evidências de acordo com o sistema GRADE  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado.|É improvável que trabalhos adicionais modifiquem<br>a confiança na estimativa do efeito.|
|**Moderado**|Há confiança moderada no efeito<br>estimado.|Trabalhos futuros poderão modificar a confiança na<br>estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante na confiança na estimativa de efeito.|
|**Muito**<br>**baixo**|A confiança na estimativa de efeito é<br>muito limitada. Há importante grau de<br>incerteza nos achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **4. DESENVOLVIMENTO DE RECOMENDAÇÕES** -->
A reunião de recomendações foi realizada em 21 e 22 de setembro de 2017, com a mesma equipe multiprofissional que participou da definição do escopo. Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou fraca, de acordo com o sistema GRADE ( **Quadro C** ).  
**Quadro C -** Implicação da força da recomendação para profissionais, pacientes e gestores em saúde  
|**Público-alvo**|**Forte**||**Fraca (condicional)**|
|---|---|---|---|
|**Gestores**|A recomendação deve ser adotada como<br>política de saúde na maioria das situações.|É necessário haver<br>partes interessadas.|debate substancial e envolvimento das|  
|**Público-alvo**|**Forte**|**Fraca (condicional)**|
|---|---|---|
|**Pacientes**|A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um<br>pequeno<br>número<br>não<br>aceitaria<br>essa<br>recomendação.|Grande parte dos indivíduos desejaria que a intervenção fosse<br>indicada; contudo, um número considerável não aceitaria essa<br>recomendação.|
|**Profissionais**<br>**da saúde**|A maioria dos pacientes deve receber a<br>intervenção recomendada.|O profissional deve reconhecer que diferentes escolhas serão<br>apropriadas para cada paciente para definir uma decisão<br>consistente com os seus valores e preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para a elaboração das recomendações foram considerados os riscos e os benefícios das condutas propostas, incluindo nível de evidências, custos, uso de recursos, aceitabilidade pelos profissionais e demais barreiras para implementação.  
A recomendação pode ser a favor ou contra a intervenção proposta, e ainda pode ser uma recomendação forte (o grupo está bastante confiante que os benefícios superam os riscos) ou fraca (a recomendação ainda gera dúvidas quanto ao balanço entre benefício e risco). Colocações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou outros esclarecimentos, estão documentadas ao longo do texto.  
A direção e a força da recomendação, assim como sua redação, foram definidas durante a reunião presencial de elaboração das recomendações com o painel de especialistas que participou também da reunião de escopo. O grupo elaborador das Diretrizes Brasileiras recebeu as tabelas GRADE de cada questão PICO e, após, iniciou as discussões e a apresentação de evidências, riscos e benefícios da intervenção proposta, os custos e valores, e as preferências dos pacientes. O coordenador do grupo apresentou cada um dos itens acima citados em um encontro que ocorreu em setembro de 2017 com o painel de especialistas que participou da elaboração do escopo. Os domínios foram debatidos separadamente, de forma estruturada, seguindo a metodologia preconizada pelo GRADE. Buscou-se consenso em relação às recomendações e, na impossibilidade de obtê-lo, realizou-se votação simples. Em 2022, acrescentou-se a questão 20:

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **Consenso do grupo elaborador para as recomendações das Diretrizes Brasileiras** -->
|**Questões**|**Considerações sobre a decisão**|
|---|---|
|1. Como devemos proceder quanto à investigação diagnóstica em pacientes<br>com baixa probabilidade clínica de insuficiência cardíaca (IC)?|Houve consenso entre o grupo.|
|2. Como devemos proceder quanto à investigação diagnóstica em pacientes<br>com moderada probabilidade clínica de IC?|Houve consenso entre o grupo.|
|3. Como devemos proceder quanto à investigação diagnóstica em pacientes<br>com alta probabilidade clínica de IC.?|Houve consenso entre o grupo.|
|4. Devemos utilizar inibidores da enzima conversora da angiotensina<br>(IECA) em pacientes com IC?|Houve consenso entre o grupo.|  
|**Questões**|**Considerações sobre a decisão**|
|---|---|
|5. Devemos utilizar IECA em doses altas em vez de utilizar IECA em doses<br>baixas em pacientes com IC?|Houve consenso entre o grupo.|
|6. Devemos utilizar IECA em vez de antagonistas do receptor da<br>angiotensina II (ARA II) como primeira escolha em pacientes com IC?|Houve consenso entre o grupo.|
|7. Devemos utilizar ARA II em pacientes com IC não tolerantes a IECA?|Houve consenso entre o grupo.|
|8. Devemos utilizar a combinação de hidralazina e isossorbida no paciente<br>com IC não tolerante a IECA e a ARA II?|Houve consenso entre o grupo.|
|9. Devemos utilizar betabloqueador em pacientes com IC?|Houve consenso entre o grupo.|
|10. Devemos utilizar antagonistas da aldosterona em pacientes com IC?|Houve consenso entre o grupo.|
|11. Devemos utilizar digoxina em pacientes com IC?|Houve consenso entre o grupo.|
|12. Devemos utilizar diuréticos (de alça ou tiazídicos) em pacientes com<br>IC?|Houve consenso entre o grupo.|
|13. Devemos utilizar a combinação de hidralazina e isossorbida no paciente<br>com IC sintomática associada a IECA ou a ARA II (tratamento clínico<br>otimizado)?|Houve consenso entre o grupo.|
|14. Devemos recomendar exercício físico para os pacientes com IC?|Não houve consenso entre o grupo. Quatro<br>painelistas<br>consideraram<br>a<br>recomendação<br>condicional, 8 consideraram a recomendação<br>forte e 4 se abstiveram.|
|15. Devemos recomendar dieta com restrição de sódio para os pacientes<br>com IC?|Houve consenso entre o grupo.|
|16. Devemos recomendar dieta com restrição hídrica para os pacientes com<br>IC?|Houve consenso entre o grupo.|
|17. Devemos recomendar redução de peso para os pacientes com IC com<br>obesidade?|Houve consenso entre o grupo.|
|18. Devemos realizar telemonitoramento por suporte telefônico para o<br>tratamento dos pacientes com IC?|Houve consenso entre o grupo.|
|19. Devemos utilizar sacubitril valsartana sódica hidratada em pacientes<br>com IC?|Houve consenso entre o grupo.|
|20. Devemos utilizar dapagliflozina em pacientes com IC?|Houve consenso entre o grupo.|

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **Diagnóstico** -->
A IC é uma síndrome de diagnóstico clínico, baseado em achados da história, exame físico e exames complementares. Entre as ferramentas que auxiliam o diagnóstico estão a radiografia de tórax, o eletrocardiograma de repouso, a ecocardiografia e o peptídeo natriurético cerebral (BNP) ou a sua porção N- terminal (NT-proBNP) (BURRI et al., 2012).  
Como já mencionado, os sinais e sintomas de IC não são exclusivos da doença, podendo estar presentes em outras enfermidades, em especial outras doenças cardiopulmonares. Entre os achados clínicos, a dispneia é o sintoma de maior sensibilidade, enquanto turgência venosa jugular, refluxo hepatojugular, taquicardia e presença de terceira bulha são os achados clínicos mais específicos para o diagnóstico de IC (BECK-DA-SILVA et al., 2007; ROHDE et al., 2004). Apesar de possuírem sensibilidade e especificidade variáveis, critérios diagnósticos podem ser úteis na investigação clínica, em especial para profissionais menos experientes, por apresentarem-se em formato de questionário estruturado compilando sinais, sintomas e fatores de risco, servindo como guia da avaliação médica. Os critérios de Boston e Framingham são os escores com maior experiência de uso. O uso desses critérios diagnósticos pode auxiliar na classificação da probabilidade clínica de ter IC, guiando a escolha de exames complementares (MCKEE et al., 1971; HARLAN, 1977; CARLSON et al., 1985; ERIKSSON et al., 1987).  
Nestas Diretrizes Brasileiras, as recomendações para a avaliação diagnóstica da IC foram realizadas com base na probabilidade pré-teste da doença, sendo realizadas recomendações diagnósticas para pacientes com baixa, moderada e alta probabilidade clínica de IC. Não foram identificados estudos para o contexto avaliado quantificando as probabilidades pré-teste de IC na população geral, de acordo com a sintomatologia clínica.  
A estimativa da probabilidade clínica de IC foi realizada com base na opinião de especialistas presentes no painel, os quais atribuíram probabilidades de IC para diferentes cenários clínicos da doença, baseados nos critérios de Boston. Inicialmente, seis especialistas avaliaram de forma independente as probabilidades de IC para nove cenários clínicos diferentes. Esses resultados foram apresentados ao painel de recomendações, que validaram os achados por consenso. Ficou definido que, para fins de elaboração de recomendações, baixa, moderada e alta probabilidade clínica de IC foram consideradas como 20%, 50% e 90%, respectivamente.  
A dosagem de BNP ou NT-proBNP predomina como o exame de escolha para investigação inicial da IC nas diretrizes e agências internacionais (PONIKOKWSKI et al., 2016; NICE, 2017; YANCY et al., 2017). A facilidade de acesso ao exame no cenário internacional e seu relativo baixo custo, além da alta sensibilidade, justificam a preferência pelo exame para grupos de probabilidades baixa e intermediária. Nesses pacientes, valores baixos descartam o diagnóstico de IC, dispensando a necessidade de investigação adicional e encaminhamento para especialista. É importante salientar que BNP e NT-proBNP não são testes com elevada especificidade e seus níveis podem estar elevados em outras situações clínicas (KELDER et al., 2011).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **QUESTÃO 1: COMO DEVEMOS PROCEDER QUANTO À INVESTIGAÇÃO DIAGNÓSTICA EM PACIENTES COM BAIXA PROBABILIDADE CLÍNICA DE IC?** -->
**<u>Recomendação 1.1:</u>** Recomendamos realizar BNP ou NT-proBNP como primeiro teste diagnóstico em pacientes com baixa probabilidade clínica de IC (qualidade de evidência moderada, recomendação forte).  
**<u>Recomendação 1.2:</u>** Sugerimos não realizar ecocardiografia diagnóstica em pacientes com baixa probabilidade clínica de IC (qualidade de evidência moderada, recomendação fraca).  
**<u>Recomendação 1.3:</u>** Recomendamos solicitar ecocardiografia em pacientes com baixa probabilidade clínica de IC e BNP ou NT-proBNP positivo (qualidade de evidência moderada, recomendação forte).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **QUESTÃO 2: COMO DEVEMOS PROCEDER QUANTO À INVESTIGAÇÃO DIAGNÓSTICA EM PACIENTES COM MODERADA PROBABILIDADE CLÍNICA DE IC?** -->
**<u>Recomendação 2.1:</u>** Recomendamos realizar BNP ou NT-proBNP como primeiro teste diagnóstico em pacientes com moderada probabilidade clínica de IC (qualidade de evidência moderada, recomendação forte).  
**<u>Recomendação 2.2:</u>** Recomendamos realizar ecocardiografia diagnóstica em pacientes com moderada probabilidade clínica de IC, na indisponibilidade de realizar testagem com BNP ou NT-proBNP (qualidade de evidência moderada, recomendação forte).  
**<u>Recomendação 2.3:</u>** Recomendamos solicitar ecocardiografia em pacientes com moderada probabilidade clínica de IC e BNP ou NT-proBNP positivo (qualidade de evidência moderada, recomendação forte).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **QUESTÃO 3: COMO DEVEMOS PROCEDER QUANTO À INVESTIGAÇÃO DIAGNÓSTICA EM PACIENTES COM ALTA PROBABILIDADE CLÍNICA DE IC?** -->
**<u>Recomendação 3.1:</u>** Recomendamos não realizar BNP ou NT-proBNP como teste diagnóstico em pacientes com alta probabilidade clínica de IC (qualidade de evidência baixa, recomendação forte).  
**<u>Recomendação 3.2:</u>** Recomendamos não realizar ecocardiografia como teste diagnóstico em pacientes com alta probabilidade clínica de IC (qualidade de evidência baixa, recomendação forte).

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **Resumo das evidências para propriedades diagnósticas de ecocardiografia, BNP e NT-proBNP** -->
**<u>BNP:</u>** Foi realizada a atualização da revisão sistemática conduzida por Booth et al. (2014). Foram incluídos 13 estudos, sendo 8 estudos da meta-análise de Booth e 5 estudos novos. As estimativas pontuais e os intervalos de confiança de 95% (IC95%) das medidas de acurácia diagnóstica combinadas do BNP, considerando o ponto de corte de 30 pg/mL para o diagnóstico de IC, foram as seguintes: sensibilidade de 97% (IC95% 9599%) e especificidade de 47% (IC95% 41-52%). A **Tabela A** apresenta o resumo das meta-análises de acurácia do BNP para o diagnóstico de IC.  
**Tabela A -** Resumo das meta-análises de acurácia do BNP para o diagnóstico de IC  
|**Meta-análise**|**Nº de**<br>**estudos**|**Sensibilidade**<br>**(IC95%)**|**Especificidade**<br>**(IC95%)**|**Razão de chances**<br>**diagnóstica**<br>**(IC95%)**|**I**<sup>**2**</sup>**para**<br>**razão de**<br>**chances**<br>**diagnóstica**|
|---|---|---|---|---|---|
|BNP, ponto de corte 20 pg/mL|2|93% (85%-97%)|44% (41%-48%)|6,19 (2,59-14,7)|0%|
|BNP, ponto de corte 30 pg/mL|3|97% (95%-99%)|47% (41%-52%)|25,96 (3,29-204,66)|89,4%|
|BNP, ponto de corte 40 pg/mL|2|95% (89%-98%)|68% (59%-76%)|56,17 (0,36-8676,79)|91,2%|
|BNP, ponto de corte 50 pg/mL|4|90% (87%-93%)|74% (71%-76%)|19,27 (6,49-57,22)|86,5%|
|BNP, ponto de corte 60-70 pg/mL|4|86% (82%-89%)|71% (67%-74%)|17,72 (6,55-47,93)|81,3%|
|BNP, ponto de corte 100 pg/mL|10|79% (76%-81%)|71% (69%-73%)|6,76 (3,44-13,31)|87,3%|
|BNP, ponto de corte 120-160<br>pg/mL|3|76% (71%-81%)|90% (86%-94%)|35,51 (20,69-60,93)|0%|  
**<u>NT-proBNP:</u>** Foi atualizada a revisão sistemática realizada por Booth et al. (2014). Dezenove estudos foram incluídos, sendo 11 estudos da meta-análise de Booth et al. e 8 estudos novos. Foram obtidas por metaanálise as seguintes estimativas pontuais e os respectivos IC95% das medidas de acurácia diagnóstica, considerando o ponto de corte de 100-150 pg/mL para o diagnóstico de IC: sensibilidade de 92% (IC95% 90%94%) e especificidade de 49% (IC95% 47%-51%). A **Tabela B** apresenta o resumo das meta-análises de acurácia do NT-proBNP para o diagnóstico de IC.  
**Tabela B -** Resumo das meta-análises de acurácia do NT-proBNP para o diagnóstico de IC  
||||||**I**<sup>**2**</sup>**para**|
|---|---|---|---|---|---|
|**Meta-análise**|**Nº de**<br>**estudo**<br>**s**|**Sensibilidade**<br>**(IC95%)**|**Especificidade**<br>**(IC95%)**|**Razão de chances**<br>**diagnóstica**<br>**(IC95%)**|**razão de**<br>**chances**<br>**diagnóstic**|
||||||**a**|
|NT-proBNP, ponto de corte 100-150<br>pg/mL|13|92% (90%-94%)|49% (47%-51%)|14,49 (8,54-24,57)|51,3%|
|NT-proBNP, ponto de corte 166-170<br>pg/mL|2|97% (93%-99%)|48% (42%-53%)|23,48 (7,99-68-<br>99)|5,8%|
|NT-proBNP, ponto de corte 200-220<br>pg/mL|4|74% (69%-79%)|65% (62%-67%)|16,05 (5,99-43,04)|72,9%|
|NT-proBNP, ponto de corte 300 pg/mL|4|84% (78%-89%)|68% (65%-70%)|7,77 (3,48-17,32)|68,7%|
|NT-proBNP, ponto de corte 400-424<br>pg/mL|7|85% (81%-88%)|73% (71%-75%)|18,81 (9,72-36,41)|68,8%|
|NT-proBNP, ponto de corte 500 pg/mL|2|79% (70%-86%)|78% (76%-81%)|17,16 (10,06-29,2)|0%|  
**<u>Ecocardiografia:</u>** Foi realizada uma nova revisão sistemática. Vinte oito estudos foram incluídos para avaliar medidas de acurácia diagnóstica. Quanto ao ponto de corte para definição de IC, somente 8 dos 28 estudos estabeleceram um valor definido _a priori_ (fração de ejeção < 40% a fração de ejeção < 60%). Para o cálculo das estimativas de acurácia diagnóstica da ecocardiografia bidimensional nos 20 estudos remanescentes, foi arbitrado o ponto de corte de fração de ejeção < 50% para o diagnóstico de IC. Por meta-análise pelo modelo dos efeitos randômicos, foram obtidas as estimativas pontuais com IC95% das medidas de acurácia diagnóstica: sensibilidade de 81% (IC95% 78%-83%) e especificidade de 85% (IC95% 83%-87%).  
**Projeção de implicações clínicas de exames diagnósticos baseados em BNP, NT-proBNP e ecocardiografia**  
É importante salientar que os valores preditivos dos testes diagnósticos dependem da probabilidade préteste de ter a doença em questão. A **Tabela C** apresenta as probabilidades pós-teste de ter IC após a realização de diferentes exames diagnósticos, estratificadas de acordo a probabilidade basal de haver insuficiência cardíaca (baixa, média ou alta).  
**Tabela C -** Probabilidade pós-teste de insuficiência cardíaca, de acordo com o risco basal do paciente  
|**Exame**||**Probabilidade Clínica**||
|---|---|---|---|
||**Baixa**|**Média**|**Alta**|
|**Probabilidade pré-teste**|20%|50%|90%|
|**NT-proBNP < 125 pg/mL**|4%|14%|60%|
|**NT-proBNP ≥ 125 pg/mL**|31%|64%|94%|
|**NT-proBNP ≥ 400 pg/mL**|44%|76%|97%|
|**Eco negativa**|5%|18%|67%|
|**Eco positiva**|57%|84%|98%|
|**NT-proBNP ≥ 125 pg/mL e eco**<br>**negativa**|9%|28%|78%|
|**NT-proBNP ≥ 125 pg/mL e eco**<br>**positiva**|71%|91%|99%|  
Tomando como exemplo um paciente com baixa probabilidade pré-teste (20%), caso o resultado do teste de NT-proBNP seja < 125 pg/mL, a probabilidade de esse paciente apresentar IC é reduzida para 4%; por outro lado, se o teste de BNP for ≥ 125pg/mL, a probabilidade de esse paciente apresentar IC sobe para 31%.  
Em termos populacionais, a adoção de diferentes exames pode ter consequências de subdiagnóstico e de sobrediagnóstico, podendo levar, respectivamente, ao não tratamento de indivíduos doentes e ao tratamento desnecessário de indivíduos sem IC. Além disso, exames de populações podem gerar a necessidade de exames adicionais ou, então, evitar a necessidade de que outros testes mais complexos sejam realizados desnecessariamente. A **Tabela D** apresenta o impacto da adoção de diferentes exames diagnósticos.  
Tomando como exemplo os pacientes que possuem baixa probabilidade de IC, a cada 1.000 pacientes que realizam o exame de ecocardiografia, 120 seriam sobrediagnosticados e poderiam receber tratamento desnecessariamente; além disso, 38 pacientes com IC não seriam diagnosticados e não receberiam o tratamento necessário. Por outro lado, ao realizar ecocardiografia apenas em pacientes com NT-proBNP elevado (≥ 125 pg/mL), a cada 1.000 pacientes investigados, 61 seriam erroneamente diagnosticados com IC (59 casos a menos do que na simulação anterior); e haveria subdiagnóstico em 51 pacientes (13 a mais do que na simulação anterior). Com relação ao uso de recursos, essa estratégia evitaria a realização de 408 exames de ecocardiografia a cada 1.000 pacientes em investigação.  
**Tabela D -** Impacto de diferentes exames na acurácia diagnóstica e realização de ecocardiografia, de acordo com o risco basal do paciente  
||||**Efeito**|**esperad**|**o por**|**1.000 p**|**acientes**|
|---|---|---|---|---|---|---|---|
||**Exames**|**Pacientes**<br>**com IC**|**VP**|**FP**|**FN**|**VN**|**Ecocardiografias**<br>**necessárias**|
||**NT-proBNP (125 pg/mL)**|200|184|408|16|392|0|
|**Baixa**|**NT-proBNP (400 pg/mL)**|200|170|216|30|584|0|
|**probabilidade**|**Ecocardiografia**|200|162|120|38|680|1.000|
|**(20%)**|**Descartar dx se NT-proBNP < 125**<br>**pg/mL**|200|149|61|51|739|592|  
||||**Efeito**|**esperad**|**o por**|**1.000 p**|**acientes**|
|---|---|---|---|---|---|---|---|
||**Exames**|**Pacientes**<br>**com IC**|**VP**|**FP**|**FN**|**VN**|**Ecocardiografias**<br>**necessárias**|
||**Ecocardiografia se NT-proBNP ≥ 125**<br>**pg/mL**|||||||
||**NT-proBNP (125 pg/mL)**|500|460|255|40|245|0|
||**NT-proBNP (400 pg/mL)**|500|425|135|75|365|0|
|**Média**|**Ecocardiografia**|500|405|75|95|425|1.000|
|**probabilidade**<br>**(50%)**|**Descartar dx se NT-proBNP < 125**<br>**pg/mL**<br>**Ecocardiografia se NT-proBNP ≥ 125**<br>**pg/mL**|500|373|38|127|462|715|
|**Alta**|**NT-proBNP (125 pg/mL)**|900|828|51|72|49|0|
|**probabilidade**|**NT-proBNP (400 pg/mL)**|900|765|27|135|73|0|
|**(90%)**|**Ecocardiografia**|900|729|15|171|85|1.000|

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: **6. REFERÊNCIAS** -->
BRASIL. Ministério da Saúde. Ivabradina para o tratamento de insuficiência cardíaca crônica moderada a grave em indivíduos com frequência cardíaca ≥70 bpm e que toleram menos de 50% da dose alvo recomendada de agentes betabloqueadores. Relatório Recom da Comissão Nac Inc Tecnol no SUS - CONITEC – 2016. BRASIL. Ministério da Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas.  Brasília: 2016. ISBN 978-85-334-2372-5.

---

<!-- METADADOS: doenca: Insuficiência Cardíaca com Fração de Ejeção Reduzid | secao: HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO -->
|**Número do Relatório**<br>||**Tecnologias avaliadas pel**|**a Conitec**<br>|
|---|---|---|---|
|**da diretriz clínica**|||**Não incorporação ou**|
|**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|<br>**não alteração no**<br>**SUS**|
|Relatório<br>de|Atualização do documento para<br>incluir<br>orientações<br>sobre<br>a|Dapagliflozina<br>para<br>o<br>tratamento<br>adicional de pacientes adultos com<br>insuficiência cardíaca com fração de<br>ejeção reduzida (FEVE≤40%), NYHA<br>II-IV e sintomáticos apesar do uso de<br>terapia padrão com inibidor da Enzima<br>Conversora de Angiotensina (IECA) ou|Empagliflozina<br>no<br>tratamento<br>da<br>insuficiência cardíaca<br>com fração de ejeção<br>reduzida (ICFEr) e|
|Recomendação<br>nº<br>808/2023|<br>dapagliflozina<br>e<br>ajustes<br>de<br>redação do documento|<br>Antagonista<br>do<br>Receptor<br>da<br>Angiotensina<br>II<br>(ARA<br>II),<br>com<br>betabloqueadores,<br>diuréticos<br>e<br>antagonista<br>do<br>receptor<br>de<br>mineralocorticoides<br>(Relatório de Recomendação nº 773;<br>Portaria SCTIE/MS nº 106/2022)|classe<br>funcional<br>NYHA II (Relatório<br>de Recomendação nº<br>778;<br>Portaria<br>SCTIE/MS<br>nº<br>144/2022)|
||Alteração pós publicação (2021):<br>- Adequação da descrição do<br>princípio<br>ativo<br>sacubitril<br>valsartana<br>para<br>sacubitril<br>valsartana sódica hidratada e de<br>suas<br>doses,<br>conforme|-|-|
|Relatório<br>de|entendimento da Anvisa.|||
|Recomendação<br>nº<br>409/2020|- Correção da medida dos valores<br>de BNP e NT-ProBNP para|||
|(Portaria<br>Conjunta|pg/mL.|||
|SAES/SCTIE/MS<br>nº<br>17/2020)|Primeira versão do documento|Sacubitril valsartana para o tratamento<br>de pacientes adultos com insuficiência<br>cardíaca crônica sintomática (NYHA<br>classe II-IV) com fração de ejeção<br>reduzida<br>(Relatório de Recomendação nº 454;<br>Portaria SCTIE/MS nº 40/2019)|-|  
|Peptídeos Natriuréticos|tipo B (BNP e|
|---|---|
|NT-ProBNP) para o|diagnóstico de|
|Insuficiência Cardíaca|(Relatório de|
|Recomendação<br>nº<br>|386;<br>Portaria|
|SCTIE/MS nº 62/2018)||

---

