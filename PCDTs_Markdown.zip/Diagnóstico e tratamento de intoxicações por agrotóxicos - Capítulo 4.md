<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Geral -->
##### **PORTARIA Nº 16, DE 25 DE MARÇO DE 2019**  
Torna pública a decisão de aprovar as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - Capítulo 4, no âmbito do Sistema Único de Saúde - SUS.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS DO  
MINISTÉRIO DA SAÚDE, no uso de suas atribuições legais e com base nos termos dos art. 20 e art. 23 do Decreto 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Ficam aprovadas as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - Capítulo 4, no âmbito do Sistema Único de Saúde - SUS.  
Art. 2º Conforme determina o art. 25 do Decreto 7.646/2011, o prazo máximo para efetivar a oferta ao SUS é de cento e oitenta dias.  
Art. 3º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico: http://conitec.gov.br/.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
##### DENIZAR VIANNA ARAUJO  
1  
Anexo

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Geral -->
#### **Considerações Iniciais**  
Dados do Ministério da Agricultura, Pecuária e Abastecimento (MAPA), indicam que há mais de setenta herbicidas contendo o ácido 2,4 diclorofenoacético (2,4-D) ou um de seus derivados como ingrediente ativo encontram-se registrados no mercado brasileiro, associados ou não com outros ingredientes ativos, como picloram e glifosato(BRASIL. MINISTERIO DA AGRICULTURA PECUARIA E ABASTECIMENTO, [s.d.], acesso em 20 de novembro de 2018).  Por serem produtos utilizados em diversas culturas e ambientes, segundo o último relatório de comercialização de agrotóxicos divulgado pelo Instituto Brasileiro do Meio Ambiente e dos Recursos Naturais Renováveis (Ibama), esses produtos aparecem na segunda posição, pois apresentaram um volume de comercialização superior a 57.000t no ano de 2017<sup>2</sup> .  
Dessa forma, a disponibilidade e uso amplo desses produtos aumenta a possibilidade de exposição da população e de ocorrência de intoxicações, intencionais ou não, com esses produtos<sup>3</sup> . Isso inclui o consumo de alimentos e de água contaminada.  
O número de casos de intoxicações por 2,4-D e seus derivados registrados no Sistema de Informação de Agravos de Notificação (Sinan) não são expressivos, quando comparados aos dos demais agentes. No período de 2007-2017 foram feitas 768 notificações, sendo 118 (15,16%) relacionadas à tentativa de suicídio, 265 (34,5%) e 224 (29,17%) associadas, respectivamente, ao uso habitual ou a um acidente com o produto. Os dados também indicam que 49% (n= 377) ocorreram no local de trabalho. Dentre todas as notificações, 22 casos evoluíram a óbito, sendo 17 em decorrência de tentativa de suicídio. Há evidências na literatura de que as intoxicações agudas com esses compostos são realmente incomuns. Entretanto, quando ocorrem de forma intencional, são fatais (HIRAN; KUMAR, 2017; ROBERTS, DARREN; SENEVIRATNE; MOHAMMED, 2005).  
Formulações contendo a sua forma ácida ou seus derivados são consideradas irritantes oculares, apesar da baixa absorção cutânea e respiratória do 2,4-D. A primeira é aumentada na presença de protetores solares, repelentes de insetos e álcool, sendo também significativa entre trabalhadores expostos a uma alta concentração de 2,4 D ou por períodos prolongados.<sup>5</sup> O 2,4-D é produzido a partir do 2,4-diclorofenol (2,4-DCP) e este é frequentemente observado como impureza nos produtos formulados à base de 2,4-D. O 2,4-DCP é genotóxico e  
2  
hepatotóxico.  Além disto, ainda existe a possibilidade de o 2,4-D ser contaminado por dioxinas cloradas, que podem ser produzidas durante o processo de fabricação do herbicida, como a TCDD (2,3,7,8-Tetraclorodibenzop-dioxina) que é reconhecida como sendo cancerígena (classe A – IARC) para o ser humano<sup>6</sup> .  
A exposição oral aos herbicidas à base de 2,4-D e seus derivados são comumente associadas às intoxicações intencionais e corresponde ao maior número de relatos de caso publicados nos últimos dez anos. As demais vias de exposição (dérmica, inalatória e ocular), apesar de uma maior probabilidade de ocorrência, principalmente no âmbito ocupacional, apresentam um menor número de estudos no âmbito da exposição aguda<sup>6,7</sup> .  
Após absorção, devido à alta hidrossolubilidade, o 2,4-D é distribuído por todo o organismo. Os seus níveis plasmáticos são ligeiramente maiores do que os observados nos demais órgãos ou tecidos. Ele não é bioacumulado em nenhum tecido. A sua forma ionizada é prevalente no pH fisiológico, em diversos compartimentos do organismo. Isso dificulta a sua difusão através das membranas celulares. Dessa forma, o composto é excretado praticamente inalterado na urina, tendo uma meia-vida de eliminação estimada entre 10 e 33 horas. Assim, pressupõe-se que 75% da dose inicial é eliminada nos primeiros quatro dias após a exposição oral<sup>5,6,8</sup> .  
Estudos em humanos e animais têm demonstrado o potencial de teratogenicidade e a toxicidade do 2,4-D sobre o sistema reprodutivo, incluindo a indução de abortos espontâneos, baixo peso ao nascer, malformações esqueléticas e urogenitais, diminuição da mobilidade e alteração de formato de espermatozoides<sup>9–11</sup> .  
Alguns estudos epidemiológicos apontam uma associação entre a exposição aos herbicidas clorofenóxiácidos com vários tipos de câncer, tais como sarcoma de tecidos moles e linfoma nãoHodgkin. Entretanto, não se sabe ao certo se esses desfechos são realmente relacionados ao 2,4D ou a outros constituintes e contaminantes presentes nas formulações investigadas<sup>12–14</sup> .  
A IARC classifica o 2,4-D como possível carcinogênico para humanos (grupo 2B). A IARC em sua monografia 113, considera que as evidências de que o 2,4-D induz stress oxidativo são fortes, de que o 2,4-D é genotóxico são fracas, de que causa imunosupressão são moderadas e de que altera proliferação e morte celular são fracas<sup>6</sup> . No Brasil, a Agência Nacional de Vigilância Sanitária (Anvisa) classificou o 2,4-D como Extremamente Tóxico (Classe I) para a saúde.  
Com relação à toxicidade para o sistema endócrino, pesquisas tem apontado o 2,4-D como sendo desregulador endócrino, já que este afeta vários processos hormonais e hormônio dependentes, com efeitos estrogênicos, androgênicos e antitiróide<sup>15–17</sup>  
3  
#### **_Abordagem Inicial_**  
**O fluxograma de atendimento e de procedimentos utilizados na abordagem inicial para o atendimento nos casos onde há suspeita de intoxicação por agrotóxicos encontra-se apresentados nos anexos apresentados na Portaria SCTIE/MS n° 43/2018, publicada em 16 de outubro de 2018**  
O diagnóstico de intoxicações agudas por herbicidas à base de 2,4-D é essencialmente clínico, sendo fundamental uma boa anamnese. Aspectos críticos em relação ao histórico da exposição devem ser criteriosamente investigados, dada a possibilidade do estabelecimento de um quadro subclínico.  
#### **Anamnese**  
#### **Ponto de Boa Prática**  
Durante a avaliação inicial do paciente, colete o maior número de informações no menor tempo possível<sup>18</sup> .  
São Informações essenciais **(** ERICKSON; THOMPSON; LU, 2007) **:**  
- **_Quem?_**  
- Nome, idade, ocupação, sexo, gravidez, histórico (uso de medicamentos, doenças agudas e crônicas, uso de álcool, drogas ilícitas).  
- **_O que foi utilizado e quanto?_**  
- Formulação/Nome comercial e quantidade utilizada. Verificar a disponibilidade da embalagem e bula do produto. Dada a grande variedade de formulações à base de 2,4-D e seus derivados, a identificação correta produto permite a elaboração de estratégias direcionadas aos efeitos tóxicos relacionados ao surfactante, a outros ingredientes ativos ou aos adjuvantes presentes.  
- **Qual a via de exposição?**  
Via oral, dérmica, inalatória ou outras.  
- **_Onde?_**  
Obter dados sobre o local de exposição.  
- **_Como?_**  
4  
Determinar a circunstância na qual ocorreu a exposição ao agrotóxico, se essa foi acidental, ocupacional, tentativa de suicídio, agressão, ambiental (vazamentos ou deriva de pulverização durante a aplicação) e a intenção de uso do produto.  
- **Há quanto tempo?**  
Estabelecer o lapso temporal entre a exposição e o atendimento.  
#### **Ponto de Boa Prática**  
Colete informações junto aos acompanhantes ou familiares das vítimas de intoxicações por formulações à base de 2,4-D e seus derivados, especialmente quando essas são crianças ou se encontrem inconscientes<sup>19</sup> .  
#### **Ponto de Boa Prática**  
Ligue para o Centro de Informação e Assistência Toxicológica (CIATox) de sua região para orientações sobre suspeita de intoxicações com manifestações clínicas atípicas ou com quadros iniciais de difícil identificação.  
No site: http://portal.anvisa.gov.br/disqueintoxicacao estão disponíveis os números de contato dos diferentes centros de informação e assistência toxicológica da Rede Nacional de Centros de Informação e Assistência Toxicológica (Renaciat). O número gratuito do serviço Disque-intoxicação é **0800 722 6001.**  
No site http://abracit.org.br/wp/centros/ estão disponíveis os contatos dos centros de intoxicação da Associação Brasileira de Centros de Informação e Assistência Toxicológica (ABRACIT).  
Consulte também a Ficha de Segurança Química (FISQP), o rótulo, os componentes da formulação e a bula do produto para obter mais informações<sup>18</sup> .  
Uma descoberta interessante em relação aos herbicidas clorofenoxiácidos é a capacidade destes inibirem receptores de sabor para doces. Embora não seja necessariamente um efeito tóxico, essa descoberta poderia ser utilizada para o  diagnóstico diferencial das intoxicações por esses produtos 20.  
5  
#### **Avaliação da Gravidade**  
Uma das dificuldades para a determinação do prognóstico em pacientes intoxicados pelos clorofenoxiácidos é a falta de uma correlação direta entre os valores de concentração plasmática desses agentes e a sintomatologia observada<sup>21</sup> . Pacientes assintomáticos nas primeiras seis horas, mesmo apresentando concentrações sanguíneas elevadas desses agentes, dificilmente evoluem para um desfecho fatal<sup>3</sup> .  
##### **<mark>Ponto de Boa Prática</mark>**  
Atente para a  possibilidade do estabelecimento de um quadro de depressão respiratória e óbito nas primeiras 24h de internação após a ingestão de formulações à base de 2,4-D e seus derivados<sup>22</sup> .  
Monitore e avalie os níveis da creatinofosfoquinase (CPK) e dos marcadores da função renal, considerando os potenciais danos musculares relacionados às intoxicações por 2,4-D e seus derivados<sup>22,23</sup> .  
No Brasil, a maior parte dos produtos disponibilizados à base de 2,4-D, é formulada com os seus derivados, os quais tem toxicidade comparável à do referido ácido.  
##### **Ponto de Boa Prática**  
Além da presença de outros ingredientes ativos, tais como o picloram, a aminopiralida e o glifosato, nos produtos à base de 2,4-D e seus derivados, a presença de surfactantes e solventes, a depender do produto e da via de exposição, podem  ocasionar intoxicações agudas graves.  
##### **Ponto de Boa Prática**  
As vítimas sintomáticas de exposição oral a 2,4-D e seus derivados devem ser tratadas, preferencialmente, em uma Unidade de Terapia Intensiva ou outra unidade semelhante que permita o monitoramento contínuo do paciente, principalmente  ao longo das primeiras 48 horas da admissão hospitalar<sup>3</sup> .  
#### **Sinais e Sintomas observados em formulações à base de 2,4-D e seus derivados**  
6  
Efeitos em baixas doses sobre a saúde humana não foram totalmente esclarecidos. A maioria dos casos de intoxicação grave, as quais normalmente envolveram a ingestão deliberada de 2,4-D, isoladamente ou em combinação com outros herbicidas, resultaram em fraqueza, cefaleia, tontura, náusea, dor abdominal, miotonia e hipotensão<sup>3,4,12</sup> . Além disso, de acordo com a gravidade da exposição, podem ser observadas complicações metabólicas e o estabelecimento de um coma prolongado<sup>4</sup> .  
Em exposições orais, a severidade das manifestações gastrintestinais depende da dose ingerida, tendo sido um pico variável entre 12-24h após a exposição. Esses podem persistir por vários dias 24.  
Apesar da baixa toxicidade oral, pulmonar e dérmica da substância 2,4-D, as suas formas ácida e salina são altamente irritantes para a mucosa pulmonar, gástrica, intestinal e ocular. Nos casos de exposição oral, a depender da formulação, algumas manifestações clínicas são semelhantes às observadas por alguns depressores do sistema nervoso central, como álcool, drogas sedativas ou hidrocarbonetos clorados aromáticos, provavelmente devido a presença de surfactantes e solventes.<sup>12,24,25</sup> .  
Além disso, a presença de alucinações, convulsões, fasciculações e paralisia podem dificultar a suspeita de intoxicação por esses compostos por parte do profissional responsável pelo atendimento inicial, pois essas podem se apresentar em intervalos variáveis durante o curso da intoxicação.<sup>24</sup> .  
##### **Ponto de Boa Prática**  
Nos casos suspeitos de exposição aguda ao 2,4-D e seus derivados, independente dos demais constituintes da formulação, os seguintes sinais e sintomas são comumente observados, considerando as principais vias de exposição:  
- I. Exposição Oral  
- Dor e queimação na boca e na garganta (ROBERTS, DARREN M; SENEVIRATNE; MOHAMMED, 2005)  
- Cefaleia, agitação, confusão mental<sup>12,14</sup>  
- Náuseas, vômito, dores abdominais e diarreia<sup>3,22,24,26,27</sup>  
- Fraqueza muscular, câimbras, fibrilação muscular, fasciculações, espasmos, mialgia, miotonia, hipertonia, hiporreflexia, ataxia<sup>3,4</sup>  
- Estresse respiratório, taquipneia, edema de pulmão<sup>12</sup>  
7  
- Miose, nistagmo<sup>3,4</sup>  
- Hipotensão, taquicardia, bradpneia, alterações no eletrocardiograma(ECG)diminuição ou inversão da onda T, aumento no intervalo Q-T, taquicardia supraventricular e ventricular<sup>14,26,28</sup>  
- Acidose metabólica, hipertermia (sem infecção), insuficiência renal, rabdomiólise, aumento nas transaminases hepáticas e na lactato desidrogenase, trombocitopenia, anemia hemolítica e hipocalcemia<sup>4,12</sup>  
- II. Dérmica<sup>12</sup>  
- Irritação local  
- III. Ocular<sup>12</sup>  
- Irritação local  
- Desconforto ocular  
- Redução da acuidade visual  
- Fotofobia  
- IV. Respiratória<sup>12</sup>  
- Tontura, vertigem  
- Tosse  
- Sensação de queimação nas vias aéreas  
- Estresse respiratório  
- Edema pulmonar  
- Fraqueza, mialgia  
- Náuseas, vômitos, constipação, dor abdominal  
- Outros semelhantes à ingestão oral  
A neuromiotoxicidade se manifesta por meio de alterações diversas, comumente observadas após  
a ingestão de formulações contendo 2,4-D sozinho ou em combinação com outros ingredientes ativos. Elas incluem coma, hipertonia, alucinações, convulsões e envolvimento do sistema neuromuscular periférico. Nesse caso, mais uma vez não se deve descartar a relação entre esses efeitos e outros componentes presentes na formulação<sup>12</sup>  
##### **Ponto de Boa Prática**  
Nos casos mais graves de intoxicações com produtos à base de 2,4-D, existe a possibilidade de serem observados (as)<sup>3,12</sup> :  
8  
- <mark>Falência renal</mark>  
- Falência cardiorrespiratória  
- Acidose metabólica  
- Hipercalemia  
- Rigidez muscular generalizada  
- Dano muscular com aumento da creatina fosfoquinase (CK)  
- Hipertermia  
O tempo de contato com o produto influencia na gravidade dos sintomas locais observados nos casos de exposição dérmica a formulações à base de 2,4-D.  
#### **Provas laboratoriais auxiliares**  
**Recomendação**  
Na admissão de pacientes com suspeita de ingestão de produtos à base de 2,4-D ou seus derivados, monitore os níveis de:  
- Creatinafosfoquinase (CPK)  
- Transaminases hepáticas (TGO e TGP)  
- Potássio Sérico (K<sup>+</sup> )  
Recomendação condicional a favor da dosagem da CPK e das transaminases hepáticas.  
Recomendação forte a favor da dosagem de K<sup>+</sup> **Evidências** :  
Observado aumento significativo nos valores de CPK em vítimas de ingestão intencional de formulações contendo derivados de 2,4-D. Das três vítimas apresentadas nos relatos de caso, duas evoluíram a óbito após deterioração do quadro clínico, nas primeiras 48 horas<sup>4,23,24</sup> .  
Nível de Evidência: BAIXA (Anexo IV.2 - Quadro IV 2.1)  
Pacientes intoxicados intencionalmente pela via oral por formulações contendo 2,4-D ou os seus derivados apresentam elevação discreta nas transaminases hepáticas no momento da admissão<sup>4,22,24,28,29</sup> . Contudo, rapidamente pode ocorrer um aumento significativo da TGO devido aos danos musculares normalmente característicos nos quadros de intoxicação aguda por esses compostos<sup>4,23,28</sup>  
Nível de evidência (TGO): MODERADA; Nível de evidência (TGP) : BAIXA (Anexo IV.2 - Quadro IV 2.1)  
9  
A hipocalemia discreta é apresentada na literatura como sendo uma alteração comum durante a evolução clínica de pacientes vítimas de tentativa de suicídio com formulações à base de 2,4D e seus derivados<sup>4,22–24,28</sup> .  
Nível de Evidência: BAIXA (Anexo IV.2 - Quadro IV 2.1)  
#### **Tratamento das Intoxicações por 2,4-D**  
O estabelecimento de uma estratégia adequada de tratamento das intoxicações por produtos à base de 2,4-D deve considerar todas as investigações descritas na anamnese, atentando principalmente para a natureza do produto. A variedade de componentes nas formulações disponibilizadas comercialmente contribui para o agravamento das intoxicações. Há também a possibilidade de algumas alterações no organismo serem decorrentes da presença de outros ingredientes ativos, surfactantes, solventes e da combinação desses com outros agentes, tal como etanol, medicamentos e outras classes de agrotóxicos<sup>12</sup> .  
##### **Ponto de Boa Prática**  
Não há nenhum antídoto específico indicado para o tratamento das intoxicações por herbicidas formulados com 2,4-D e seus derivados. Devem ser estabelecidos os cuidado de suporte, a correção das anormalidades eletrolíticas, mantendo o paciente em observação<sup>18</sup>  
##### **Ponto de Boa Prática**  
Diuréticos de alça não devem ser administrados em pacientes intoxicados por produtos formulados com  2,4-D e seus derivados, dado o possível agonismo entre a miotonia associada a tal classe de medicamentos e esses herbicidas<sup>30</sup>  
#### **Descontaminação de pele e mucosas**  
**Todos os procedimentos utilizados para a descontaminação de pele e mucosas nos casos onde há suspeita de intoxicação por agrotóxicos encontram-se apresentados nos anexos** **<u>publicados na Portaria MS/SCTIE n°43/2018, publicada em 16 de outubro de 2018</u>**  
##### **Ponto de Boa Prática**  
10  
No atendimento inicial aos casos de exposição dérmica ao 2,4-D, a pele e o cabelo da vítima devem ser lavados com quantidade abundante de água e sabão. Os profissionais responsáveis pelo procedimento devem considerar as técnicas de proteção padrão e uso de equipamento de proteção individual<sup>18</sup> .  
##### **Ponto de Boa Prática**  
Nas exposições oculares a formulações contendo 2,4-D, antes de iniciar a irrigação, assegure que houve a remoção das lentes de contato, quando for o caso.  
Irrigue o (s) olho (s) exposto (s) com quantidade abundante de água durante pelo 10-15 minutos. Caso persista a irritação, referenciar o paciente para um serviço especializado<sup>18</sup> .  
Considere que determinados solventes e surfactantes presentes nas formulações à base de 2,4D e seus derivados podem induzir o estabelecimento de uma conjuntivite leve ou moderada ou uma lesão superficial da córnea, principalmente se a irrigação ocular for atrasada ou realizada inadequadamente<sup>31</sup> .  
#### **Descontaminação Gástrica**  
##### **Ponto de Boa Prática**  
A ingestão de grandes volumes de formulações contendo 2,4-D e seus derivados podem ocasionar a êmese espontânea. Contudo, não se recomenda a indução do vômito em vítimas intoxicadas por esses produtos<sup>18</sup> .  
#### **Lavagem Gástrica**  
##### **Ponto de Boa Prática**  
Não há evidências suficientes para amparar o uso da lavagem gástrica em pacientes intoxicados por 2,4-D e seus derivados. Contudo, ela pode ser uma alternativa a ser utilizada, com cautela, caso a vítima tenha ingerido um grande volume de solução. Nesse caso, o procedimento deve ser realizado em até 1 hora (60 min) da ingestão do agente<sup>18</sup> .  
A lavagem gástrica não é recomendada em pacientes que apresentem<sup>32</sup> :  
- Vias aéreas desprotegidas;  
- Pacientes extubados com alteração no nível de consciência;  
11  
- Histórico de ingestão concomitante de outras substâncias depressoras do Sistema Nervoso Central, compostos corrosivos (ácidos ou alcalinos) ou hidrocarbonetos (solventes);  
- Convulsões;  
- Risco de sangramento ou de perfuração do trato gastrintestinal devido a cirurgias ou outras condições clínicas (ex.: coagulopatias)  
#### **Uso de Carvão ativado**  
##### **<mark>Ponto de Boa Prática</mark>**  
Não há evidências suficientes para amparar o uso de carvão ativado em pacientes intoxicados por 2,4-D e seus derivados, apesar de alguns relatos apresentados na literatura<sup>26,28</sup> .  Há indícios de uma possível redução da biodisponibilidade do agente tóxico ao se realizar o procedimento em até 60 minutos após a ingestão, considerando dados de estudos realizados, em voluntários, com outros agentes. Entretanto nenhum desses foi realizado com os referidos compostos<sup>18</sup> .  
#### **Técnicas de Eliminação Extracorpórea**  
Não há antídotos específicos para tratar as intoxicações por formulações contendo 2,4- D e seus derivados.  Razão pela qual estratégias de eliminação desses produtos por meio de técnicas dialíticas ou por intervenções que modifiquem a toxicocinética do agente serem rotineiramente utilizadas, principalmente para os casos de intoxicações mais graves. Dentre essas intervenções, a administração de fluidos endovenosos e a alcalinização urinária foram apontadas por alguns autores como eficazes<sup>12,18,33</sup> .  
Não emergiu na busca nenhum ensaio controlado referente ao uso da alcalinização urinária nos casos de intoxicação por herbicidas clorofenoxiácidos. Toda a avaliação de evidências foi feita por meio de dados coletados em Relatos de Caso.  
##### **Recomendação**  
Nos casos em que há ingestão de formulações à base de 2,4-D e seus derivados, proceda com a alcalinização urinária no intuito de manter o pH urinário acima de 7,6 e um débito urinário acima de 5mL/Kg/h.  
Recomendação forte a favor  
**Evidências**  
12  
Durante o atendimento a uma vítima de tentativa de suicídio, que havia ingerido 70mL de produto contendo 55% de 2,4-D, o reconhecimento da intoxicação e a alcalinização urinária, com a manutenção de um débito urinário acima de 5mL/Kg/h contribuiu para um prognóstico favorável. A velocidade de infusão foi ajustada considerando a manutenção do pH urinário em 8,0 e de um  fluxo urinário de 6 ml / minuto<sup>4</sup> .  
A alcalinização urinária se mostrou efetiva para a depuração do 2,4-D de um paciente vítima de intoxicação intencional de uma mistura contendo 10% de 2,4-D e 20% de Mecocrop (ácido 2 4-Cloro-2-metilfenoxi propiônico). O uso de valores da depuração renal, corrigidos e não corrigidos para o fluxo de urina, permite o esclarecimento das contribuições relativas da alcalinização urinária e do fluxo urinário. Os dados de Prescott et al., (1979) demonstram que tanto a alcalinização urinária (pH urinário> 8) quanto o alto fluxo urinário (da ordem de 600 mL/hora) são necessários para obter uma depuração renal de 2,4-D comparável àquela alcançada com a hemodiálise<sup>34</sup> .  
A alcalinização urinária favorece a eliminação renal de clorofenoxiácidos, alterando a sua distribuição nos diversos compartimentos do organismo. Ela aumenta a possibilidade de um prognóstico favorável, mesmo em pacientes comatosos ou com outras condições desfavoráveis, como acidemia ou que apresentam concentrações plasmáticas do agente superiores a 0.5g/L<sup>21</sup> .  
Em uma paciente de 61 anos de idade, vítima da ingestão intencional de cerca de 200mL de uma formulação contendo 250g/L de um aminoderivado do 2,4-D, a qual foi trazida inconsciente e entubada ao serviço de emergência, foi observada uma redução da meia-vida inicial do agente de 39,5 horas para 2,7 hora 30 minutos após a alcalinização urinária (pH mantido acima de 7,5) (FRIESEN; JONES; VAUGHAN, 1990).  
A alcalinização urinária pode ser eficaz para o tratamento de intoxicações por herbicida com clorofenoxi, mas faltam dados sobre a indicação, o regime e a eficácia. (ROBERTS, Darren M.; BUCKLEY, 2007).  
Paciente de 22 anos de idade, vítima de tentativa de suicídio, ingeriu 400 mL de um produto contendo 2,4-D, após receber atendimento padrão foi submetido à diurese alcalina após ser evidenciada a rabdomiólise. O paciente recebeu alta no quinto dia após admissão. Houve normalização dos parâmetros bioquímicos séricos uma semana após a alta<sup>24</sup>  
QUALIDADE DA EVIDÊNCIA: MUITO BAIXA (Anexo IV.2-Quadro IV 2.2.)  
13  
##### **Ponto de Boa Prática**  
Parece razoável corrigir a acidose e manter um débito urinário adequado, mas não há evidências suficientes para apoiar outras intervenções específicas no manejo rotineiro de pacientes intoxicados por 2,4-D e seus derivados<sup>35</sup> **.**  
**Recomendação**  
Nos casos graves de intoxicação com produtos à base de 2,4-D considere a utilização de métodos dialíticos no intuito de favorecer a remoção de todos os ingredientes presentes na formulação.  
Recomendação condicional a favor  
**Evidências**  
Após a ingestão intencional de um volume desconhecido de um produto comercial  contendo 40% de 2,4-D, um indivíduo de 53 anos apresentou rebaixamento do nível de consciência, evoluindo para um quadro de diarreia e hipotensão não responsiva à reposição de volume. Após receber hemodiálise regular, com bicarbonato de sódio, por três horas, houve normalização da pressão arterial (110x70 mm de Hg) e melhora no nível de consciência começou a melhorar. Quatro horas após o término do procedimento, ele estava totalmente consciente com a pressão arterial estável (130x 80 mm de Hg)<sup>26</sup> .  
Em uma série de casos na qual optou-se pela hemodiálise em 4 pacientes que haviam ingerido de 40g a 200g de 2,4-D e que haviam chegado ao pronto atendimento em estado de coma ou com consciência alterada.  Ao final do procedimento foi observada redução significativa na concentração sérica de 2,4-D após 3h a 5h. Todos os pacientes receberam alta hospitalar entre 8-23 dias<sup>36</sup> .  
Qualidade da evidência: MUITO BAIXA (Anexo IV.2- Quadro IV.2.3)  
#### **Acompanhamento de pacientes expostos a formulações à base de 2,4-D**  
**Ponto de Boa Prática**  
14  
Agende a primeira consulta em até dez dias e realiza seguimento ambulatorial, semanas a meses conforme o caso, das vítimas de intoxicação aguda por 2,4-D e seus derivados e considere a realização de eletromiografia e estudo de condução nervosa, no intuito de avaliar possíveis alterações neuropáticas ou neuromusculares nesses indivíduos<sup>18</sup> .  
#### **Acompanhamento de pacientes vítimas de tentativas de suicídio**  
##### **Ponto de Boa Prática**  
Toda vítima de intoxicação por 2,4-D e seus derivados relacionadas a tentativa de suicídio deve ser encaminhar à Rede de Atenção Psicossocial (RAPS).  
Para conhecer mais sobre a RAPS acesse o endereço eletrônico do Portal da Saúde: http://portalsaude.saude.gov.br/index.php/o-ministerio/principal/secretarias/sas/daet/saudemental

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Geral -->
Dados do Sinan revelam que, entre os anos de 2007-2017, a maior parte das intoxicações por 2,4D registrada no sistema ocorreram na área rural. Os dados ocupacionais das fichas analisadas revelam que em torno de 50% dos casos referem-se a trabalhadores não registrados e autônomos. Mesmo com fortes pressões políticas, o modelo econômico vigente favorece o uso indiscriminado desses e de outros agrotóxicos, os quais produzem danos ecológicos e sociais diversos<sup>37,38</sup> . A literatura indica que a exposição ocupacional de agricultores e de trabalhadores rurais a 2,4-D e seus derivados não ocorre de forma isolada. Ela é decorrente de uma combinação de agrotóxicos. Além disso, a avaliação e a mitigação de riscos à saúde associados, principalmente, aos compostos classificados como “seguros”, é dificultada pela sazonalidade da exposição<sup>39</sup> .  
##### **Ponto de Boa Prática**  
A identificação, acolhimento e acompanhamento de trabalhadores rurais por profissionais dos Centros de Referência de Saúde do Trabalhador (Cerest) pressupõem uma orientação adequada em relação aos riscos ocupacionais associados à exposição aos agrotóxicos, além da realização de todos os encaminhamentos necessários para a recuperação da saúde, melhoria da qualidade de vida e outros procedimentos previstos nas políticas de Saúde do Trabalhador preconizadas pelo Ministério da Saúde<sup>40</sup> .  
15

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Geral -->
O 2,4 D é um agrotóxico largamente utilizado, inclusive em plantas transgênicas, aumentando desta forma a exposição dos trabalhadores e população em geral. Considerando o potencial tóxico desta substância, propõe-se como ações de Vigilância em Saúde:  
- priorização dos modos de produção de alimentos que não utilizem agrotóxicos, como a agroecologia e agricultura orgânica;  
- em casos de uso de agrotóxicos, recomenda-se a utilização de substâncias menos tóxicas em detrimento ao uso de substâncias de alta toxicidade aguda e com pouca informação dos efeitos crônicos, como é o caso do 2,4 D.  
##### **Ponto de Boa Prática**  
Uma vez finalizada a atenção inicial e estabilizado o paciente, deve-se realizar a respectiva notificação do caso, utilizando o formato e o formulário de notificação de intoxicações apropriado.  
Notifique todos os casos suspeitos de intoxicação exógena no Sinan. Ela é obrigatória a todos os profissionais de saúde, e é um fator determinante para medidas de vigilância.  
Existe também a possibilidade da comunicação pelos cidadãos ou estabelecimentos educacionais por meio do Disque Notifica: 0800-644-6645 ou notifica@saude.gov.br.  
**(Verificar a Portaria MS/SCTIE n° 43/2018, publicada em 16 de outubro de 2018 para maiores detalhes em relação à obrigatoriedade da notificação compulsória dos casos de suspeita de intoxicação exógena)**  
##### **Ponto de Boa Prática**  
Em caso de ser uma intoxicação exógena por agrotóxicos relacionada ao trabalho, de acordo com a Lei 8.213/1991; Portaria GM/MS de Consolidação nº 2 de 2017, anexo XV (origem: PRT MS 1.823/2012); Portaria GM/MS de Consolidação nº 5 de 2017, art. 422 e Anexo LXXIX (origem: PRT MS 3.120/1998)<sup>41</sup> ; Lei 6.015/1973; Portaria GM/MS de Consolidação nº 4 de 2017, anexo V (Origem: PRT MS/GM 204/2016)<sup>42</sup> ; o médico ou profissional de saúde deve:  
- Emitir a Comunicação de Acidente de Trabalho (CAT) para os trabalhadores que contribuem com o INSS e os segurados especiais (a exemplo de agricultores e pescadores);  
16  
- Referenciar o trabalhador, para a atenção básica, caso o primeiro atendimento seja realizado em serviços de média ou alta complexidade com o objetivo de dar continuidade ao cuidado;  
- Acionar o Centros de Referência em Saúde do Trabalhador (Cerest) ou equipe de vigilância em saúde para realizar vigilância de ambiente e processo de trabalho referente ao caso, com o objetivo de intervir, minimizando ou eliminando a exposição de trabalhadores aos agrotóxicos;  
- Notificar o caso na ficha de investigação de **Intoxicação Exógena do Sinan** e sempre preencher os campos: 32-Ocupação, 36-Atividade Econômica (CNAE), 34-Local de ocorrência da exposição como “ambiente de trabalho”, 56-A exposição/contaminação foi decorrente do trabalho/ ocupação? Como “Sim”;  
- Em caso de **óbito** , incluindo suicídio, por intoxicação por agrotóxicos relacionada ao trabalho, preencher um dos campos de causa do óbito da Declaração de Óbito (DO) com o CID-10, Y96-Circunstâncias relativas às condições de trabalho. E ainda assinalar o campo acidente de trabalho como “sim” na parte de causas externas da DO.  
( **Verificar o fluxograma para o atendimento de trabalhadores com suspeita de intoxicação por agrotóxicos publicado na Portaria MS/SCTIE nº43, de 16 de outubro de 2018** )

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
1. Brasil. Ministerio da Agricultura Pecuaria e Abastecimento. AGROFIT [Internet]. [cited 2018 Nov 1]. Available from:  
http://agrofit.agricultura.gov.br/primeira_pagina/extranet/AGROFIT.html  
2. Brasil. Ministério do Meio Ambiente. Relatórios de comercialização de agrotóxicos [Internet]. Boletim Anual de Comercialização de Agrotóxicos. 2017 [cited 2018 Nov 6]. p. 1. Available from: https://www.ibama.gov.br/agrotoxicos/relatorios-decomercializacao-de-agrotoxicos#boletinsanuais  
3. Roberts DM, Seneviratne R, Mohammed F. ntentional self-poisoning with the chlorophenoxy herbicide 4- chloro-2-methylphenoxyacetic acid (MCPA). Ann Emerg Med. 2005;46(3):275–84.  
4. Hiran S, Kumar S. 2, 4-D dichlorophenoxyacetic acid poisoning; Case report and literature review. Asia Pacific J Med Toxicol [Internet]. 2017;6(1):29–33. Available from:  
http://www.embase.com/search/results?subaction=viewrecord&from=export&id=L6163 53856%0Ahttp://limo.libis.be/resolver?&sid=EMBASE&issn=23224320&id=doi:&atitl  
17  
e=2%2C+4-  
- D+dichlorophenoxyacetic+acid+poisoning%3B+Case+report+and+literature+review&st itle=Asia+Pac  
5. US Environmental Protection Agency. 2,4-Dichlorophenoxyacetic Acid (2,4-D). 2007.  
6. IARC. 2,4-dichlorophenoxyacetic acid (IARC MONOGRAPHS-113). 2015.  
7. US-EPA. Recognition and Management of Pesticide Poisonings. 2013;(US Environmental Protection Agency-USEPA):277.  
8. Jervais, G.; Luukinen, B.; Buhl, K.; Stone D. 2,4-D General Fact Sheet [Internet]. National Pesticide Information Center, Oregon State University Extension Services. 2008 [cited 2018 Nov 5]. Available from: http://npic.orst.edu/factsheets/24Dgen.html  
9. Lerda D, Rizzi R. Study of reproductive function in persons occupationally exposed to 2 , 4-dichlorophenoxyacetic acid ( 2 , 4-D ). 1991;262:47–50.  
10. Mazhar FM, Moawad KM, El-dakdoky MH, Amer AS. Fetotoxicity of 2 , 4- dichlorophenoxyacetic acid in rats and the protective role of vitamin E. 2014;30(5):480– 8.  
11. States USW, Schreinemachers DM. Children ’ s Health | Article Birth Malformations and Other Adverse Perinatal Outcomes in Four. 2003;111(9):1259–64.  
12. Bradbery SM, Proudfoot AT, Vale JA. Poisoning due to chlorophenoxy herbicides. Toxicol Rev. 2004;23(2):65–73.  
13. Jurewicz J, Hanke W, Sobala W, Ligocka D. Exposure to phenoxyacetic acid herbicides and predictors of exposure among spouses of farmers. Ann Agric Environ Med. 2012;19(1):51–6.  
14. Garabrant DH, Philbert MA. Review of 2,4-Dichlorophenoxyacetic Acid (2,4-D) Epidemiology and Toxicology. Metab Clin Exp [Internet]. 2002;32(4):233–57. Available from: file:///Users/Eric/Dropbox/Papers2 Dropbox/Articles/2002/Garabrant/Metabolism Clinical And Experimental 2002  
- Garabrant.pdf%5Cnpapers2://publication/uuid/9F630EBC-9E55-431F-87252639DE0EC395  
15. Goldner WS, Sandler DP, Yu F, Shostrom V, Hoppin JA, Kamel F, et al. HYPOTHYROIDISM AND PESTICIDE USE AMONG MALE. J Occup Env Med. 2013;55(10):1171–8.  
16. Garry VF, Tarone RE, Kirsch IR, Abdallah JM, Lombardi DP, Long LK, et al. Biomarker Correlations of Urinary 2 , 4-D Levels in Foresters : Genomic Instability and Endocrine Disruption. Environ Health Perspect. 2001;109(5):495–500.  
18  
17. Kim H, Park YI, Dong M. Effects of 2 , 4-D and DCP on the DHT-Induced Androgenic Action in Human Prostate Cancer Cells. Toxicol Sci. 2005;88(1):52–9.  
18. Roberts JR, Reigart JR. Recognition and Management of Pesticides Poisoning [Internet]. 6th ed. Agency USEP, editor. United States Environmental Protection Agency. Washington, DC; 2013. 272 p. Available from:  
- http://dx.doi.org/10.1016/j.mayocp.2011.09.004  
19. Erickson TB, Thompson TM, Lu JJ. The Approach to the Patient with an Unknown Overdose. Emerg Med Clin North Am. 2007;25(2):249–81.  
20. Maillet EL, Margolskee RF, Mosinger Jr B. Phenoxy herbicides and fibrates potently inhibit the human chemosensory receptor subunit T1R3. J Med Chem. 2009;52(21):6931–5.  
21. Flanagan RJ, Meredith TJ, Ruprah M, Onyon LJ, Liddle A. Alkaline diuresis for acute poisoning with chlorophenoxy herbicides and ioxynil. Lancet. 1990;335(8687):454–8.  
22. Singla S, Malvia S, Bairwa RP, Asif M, Goyal S. A rare case of 2 , 4- Dichlorphenoxyacetic acid ( 2 , 4-D ) poisoning. 2017;4(4):1532–3.  
23. Singh S, Yadav S, Sharma N, Malhotra P, Bambery P. Fatal 2,4-D (Ethyl Ester) Ingestion. JAPI. 2003;51(June):2002–3.  
24. Oghabian Z, Ghanbarzadeh N, Mehrpour O. Treatment of 2 , 4-Dichlorophenoxyacetic Acid ( 2 , 4-D ) Poisoning ; a Case Study. 2014;4(3):104–7.  
25. Bjørling-Poulsen M, Andersen HR, Grandjean P. Potential developmental neurotoxicity of pesticides used in Europe. Environ Heal A Glob Access Sci Source. 2008;7.  
26. Moshiri M, Mousavi SR, Etemad L. Management of 2 , 4- Dichlorophenoxyacetic Acid Intoxication by Hemodialysis : A Case Report. Iran J Toxicol. 2016;10(1):3–5.  
27. Zawahir S, Roberts DM, Palangasinghe C. Europe PMC Funders Group Acute intentional self-poisoning with a herbicide product containing fenoxaprop-P-ethyl , ethoxysulfuron and isoxadifen ethyl . A prospective observational study. 2011;47(8):792–7.  
28. Friesen EG, Jones GR, Vaughan D. Clinical presentation and management of acute 2, 4- D oral ingestion. Drug Saf. 1990;5(2):155–9.  
29. Singh S, Sharma N. Neurological syndromes following organophosphate poisoning. Neurol India [Internet]. 2000;48(4):308–13. Available from: http://www.ncbi.nlm.nih.gov/pubmed/11146591  
30. BRETAG AH, DAWE SR, KERR DIB, MOSKWA AG. Myotonia As a Side Effect of  
19  
Diuretic Action. Br J Pharmacol. 1980;71(2):467–71.  
31. Rao SM, Mutkule D, Venkategowda P, Mahendrakar K. Glyphosate surfactant herbicide poisoning and management. Indian J Crit Care Med [Internet]. 2014;18(5):328. Available from: http://www.ijccm.org/text.asp?2014/18/5/328/132508  
32. Benson BE, Hoppu K, Troutman WG, Bedry R, Erdman A, Jer JHÖ, et al. Position paper update: gastric lavage for gastrointestinal decontamination. 2013;  
33. Proudfoot AT, Krenzelok EP, Vale JA. Position paper on urine alkalinization. J Toxicol Clin Toxicol. 2004;42(1):1–26.  
34. Prescott LF, Park J, Darrien I. Mecoprop intoxication. Br J Clin Plharmac. 1979;7:111– 6.  
35. Roberts DM, Buckley NA. Urinary alkalinisation for acute chlorophenoxy herbicide poisoning. Cochrane Database Syst Rev. 2007;1(1).  
36. Durakovic Z, Durakovic A, Durakovic S, Ivanovic D. Archives of Toxicology. Arch Toxicol. 1992;66:518–21.  
37. Soares WL, Firpo M, Porto DS. Uso de agrotóxicos e impactos econômicos sobre a saúde Pesticide use and economic impacts ABSTRACT. 2012;46(2):209–17.  
38. Porto MF de S. O trágico Pacote do Veneno: lições para a sociedade e a Saúde Coletiva. Cad Saude Publica [Internet]. 2018;34(7). Available from:  
http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0102-  
- 311X2018000700302&lng=pt&tlng=pt  
39. Arcury TA, Grzywacz JG, Talton JW, Chen H, Vallejos M, Galvan L, et al. Am J Ind Med. Am J Ind Med. 2010;53(8):802–13.  
40. de Lacerda MJS, de Carvalho ACF. Artigo de revisão. Rev Psicol [Internet]. 2011;5(13):77–88. Available from:  
http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0102311X2018000700302&lng=pt&tlng=pt  
41. Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 5/2017. 5 Brasília; 2017.  
42. Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 4/2017. Ministério da Saúde, Gabinete do Ministro, Brasília, DF, Brasil Brasília; 2017 p. 288p.  
20

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
21

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
**Quadro IV.1.1 -** Perguntas PICO relativas à intoxicação aguda por formulações à base de 2,4-D e seus derivados.  
|**Perguntas**|**População**|**Intervenção**|**Comparação**|**Desfecho**|
|---|---|---|---|---|
|1. Quais são as manifestações<br>clínicas, sinais e sintomas que<br>permitem suspeitar intoxicação<br>aguda por 2,4-D e seus derivados?|Busca sistemática sem<br>avaliação de evidência|Homens e mulheres expostos a 2,4-D e seus derivados.<br>Subgrupos específicos: Grávidas, criança e idosos|Descrição do quadro clínico<br>por sistemas e via de<br>exposição||
|2. Como deve ser a anamnese no<br>paciente com suspeita de<br>intoxicação por 2,4-D e seus<br>derivados?|Manter a anamnese<br>da abordagem geral||||
|3. Quais são as provas para realizar<br>diagnóstico laboratorial de<br>intoxicação aguda por 2,4-D e seus<br>derivados?|Busca sistemática sem<br>avaliação de evidência|Homes e mulheres com suspeita de intoxicação por 2,4-<br>D e seus derivados|||
|4. Quais são os testes auxiliam na<br>avaliação clínica do paciente com<br>suspeita de intoxicação com 2,4-D e<br>seus derivados?|Busca sistemática sem<br>avaliação de evidência|Homes e mulheres com suspeita de intoxicação por 2,4-<br>D e seus derivados|Marcadores laboratoriais<br>diversos (enzimas hepáticas,<br>ionograma, etc)||
|5. Quais são os critérios de gravidade<br>específica para intoxicações agudas<br>por 2,4-D e seus derivados?|Busca sistemática sem<br>avaliação de evidência|Homes e mulheres com suspeita de intoxicação por 2,4-<br>D e seus derivados|Descrição dos fatores<br>associados a gravidade da<br>intoxicação||
|6. Quais são os métodos de<br>descontaminação efetivos na<br>intoxicação por glifosato?|Busca sistemática com<br>avaliação da evidência|<br>Homes e mulheres com suspeita de intoxicação por 2,4-<br>D e seus derivados|-Descontaminação dérmica<br>e ocular<br>-Carvão ativado|Ausência da<br>intervenção|  
22  
||||-Outras subtâncias para<br>reduzir absorção (ex.: leite)<br>-Lavagem gástrica||
|---|---|---|---|---|
|7. Quais são os métodos de<br>eliminação efetivos na intoxicação<br>por 2,4-D e seus derivados?|Busca sistemática com<br>avaliação da evidência|Homes e mulheres com suspeita de intoxicação por 2,4-<br>D e seus derivados|-hemodialise<br>-Alcalinização urinária|Ausência da<br>intervenção|
|8. Qual é o tratamento inicial para o<br>paciente intoxicado com 2,4-D e seus<br>derivados?|Para suporte<br>considerar capítulo 1|Homens e mulheres potencialmente expostos a 2,4-D e<br>seus derivados<br>Subgrupo: trabalhadores|- Tratamento de suporte||
|9. Qual é a melhor forma de fazer<br>seguimento aos pacientes com<br>intoxicação aguda por 2,4-D e seus<br>derivados?|Capítulo 1|Homens e mulheres com intoxicação por 2,4-D e seus<br>derivados|||
|10. Qual deve ser o<br>acompanhamento, segmento e<br>reabilitação do paciente intoxicado<br>por 2,4-D e seus derivados?|Capítulo 1|Homens e mulheres que passaram pelo quadro de<br>intoxicação por 2,4-D e seus derivados que possuem<br>quadro de sintomatologia continuada|||  
23

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
**Quadro IV.2.1** Estratégia de busca e associação de palavras-chave, no **PubMed** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4-D.  
**Quadro IV.2.2** Estratégia de busca e associação de palavras-chave, na **Lilacs** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4-D.  
**Quadro IV.2.3.** Estratégia de busca e associação de palavras-chave, no **PubMed,** para as perguntas PICO do Capítulo 4- 2,4 D, Tratamento.  
**Quadro IV.2.4** Estratégia de busca e associação de palavras-chave, na **Lilacs** , para as perguntas PICO do Capítulo 4- 2,4 D, Tratamento.  
**Quadro IV.2.5.** Estratégia de busca e associação de palavras-chave, no portal **Cochrane,** para as perguntas PICO do Capítulo 4- 2,4 D, Tratamento.  
24  
**Quadro IV.2.1** Estratégia de busca e associação de palavras-chave, no **PubMed** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4-D.  
|**Pergunta**|**Bloco conceitual**|**Termos**|**Estratégia**|**Pubmed**|
|---|---|---|---|---|
|PUBMED|||||
|Perguntas de 1 a 7||Estratégia abrangente|("Pesticides"[Mesh] OR "Agrochemicals"[Mesh] OR<br>"Pesticide Residues"[Mesh]) AND<br>("poisoning"[Subheading] OR "poisoning"[All Fields] OR<br>"poisoning"[MeSH Terms] OR exposure[All Fields] OR<br>intoxicat* [All Fields] OR excret* [All Fields] OR eliminat*<br>[All Fields] OR residue* [All Fields] OR metabolite*[All<br>Fields]) AND ("2,4-Dichlorophenoxyacetic Acid"[Mesh] OR<br>"Phenoxyacetates"[Mesh] OR "phenoxyacetic<br>acid"[Supplementary Concept]) AND "humans"[MeSH<br>Terms] AND (("2010/01/01"[PDAT] : "2018/08/31"[PDAT])<br>AND (English[lang] OR Portuguese[lang] OR<br>Spanish[lang]))|83 (1a)|
|1. Quais são as manifestações<br>clínicas, sinais e sintomas que<br>permitem suspeitar de<br>intoxicação aguda por 2,4 D?|Manifestações clínicas,<br>toxíndromes, intoxicação aguda|Agrochemicals, Pesticides,<br>Poisoning, Signs and<br>symptoms, humans.|("Pesticides"[Mesh] OR "Agrochemicals"[Mesh] OR<br>"Pesticide Residues"[Mesh]) AND<br>("poisoning"[Subheading] OR "poisoning"[All Fields] OR<br>"poisoning"[MeSH Terms] OR exposure[All Fields] OR|20 (1b)|
|2. Como deve ser a anamnese<br>no paciente com suspeita de<br>intoxicação por 2,4 D?<br>(**ABORDAGEM GERAL**)|Anamnese, questionários clínicos,<br>linguagem adequada das<br>perguntas.|Agrochemicals, Pesticides,<br>Intoxication, Poisoning,<br>Interview, Physical<br>Examination, humans.|intoxicat* [All Fields] OR excret* [All Fields] OR eliminat*<br>[All Fields] OR residue* [All Fields] OR metabolite*[All<br>Fields]) AND ("2,4-Dichlorophenoxyacetic Acid"[Mesh] OR<br>"Phenoxyacetates"[Mesh] OR "phenoxyacetic||  
25  
|3. Qual o diagnóstico diferencial<br>com relação a intoxicações<br>causadas por substâncias<br>cáusticas, herbicida paraquat<br>ou outros agrotóxicos?|Homes e mulheres com suspeita<br>de intoxicação por 2,4 D,<br>diagnóstico diferencial|Pesticides, Agrochemicals,<br>diagnosis differential,<br>humans.|acid"[Supplementary Concept]) AND ("Injury Severity<br>Score"[Mesh] OR "Trauma Severity Indices"[Mesh] OR<br>"interview"[Publication Type] OR "interviews as<br>topic"[MeSH Terms] OR "interview"[All Fields] OR<br>"Severity of Illness Index"[Mesh] OR "Simplified Acute|
|---|---|---|---|
|4. Quais são as provas para<br>realizar diagnóstico laboratorial<br>de intoxicação aguda por 2,4 D?|Homes e mulheres com suspeita<br>de intoxicação por 2,4 D|Pesticides, Agrochemicals,<br>diagnosis, Clinical<br>Laboratory Techniques,<br>residues, humans,|Physiology Score"[Mesh] OR  "Patient Acuity"[Mesh] OR<br>("Pulmonary Surfactants"[Mesh] OR "Surface-Active<br>Agents"[Mesh] OR "Pathology, Clinical"[Mesh] OR<br>"Decision Support Systems, Clinical"[Mesh] OR Clinical|
|5. Quais são os testes que<br>auxiliam na avaliação clínica do<br>paciente com suspeita de<br>intoxicação com 2,4 D?|Homes e mulheres com suspeita<br>de intoxicação por 2,4 D|Pesticides, Agrochemicals,<br>diagnosis, Clinical<br>examination, humans,|examination [All fields] OR "Clinical Chemistry<br>Tests"[Mesh] OR "Chemistry, Clinical"[Mesh] OR  "Clinical<br>Decision-Making"[Mesh] OR "Clinical Laboratory<br>Techniques"[Mesh] OR "Nursing Diagnosis"[Mesh] OR|
|6. Quais são os critérios de<br>gravidade específica para<br>intoxicações agudas por 2,4 D?|Descrição dos fatores associados a<br>gravidade da intoxicação|Pesticides, Agrochemicals,<br>Injury Severity Score,<br>severity indexes|"Diagnosis, Oral"[Mesh] OR "Diagnosis"[Mesh] OR<br>"diagnosis" [Subheading]) OR "diagnosis,<br>differential"[MeSH Terms] OR "Diagnosis"[Mesh] OR<br>"diagnosis" [Subheading] OR "signs and symptoms"[MeSH|
||||Terms] OR "Physical Examination"[Mesh])  AND<br>("humans"[MeSH Terms]) AND (("2010/01/01"[PDAT] :<br>"2018/08/31"[PDAT]) AND (English[lang] OR<br>Portuguese[lang] OR Spanish[lang]))|  
*Filtros aplicados: período 01/01/2010 a 31/08/2018, idiomas inglês, português e espanhol. Busca realizada no dia 02/10/2018.  
26  
**Quadro IV.2.2** Estratégia de busca e associação de palavras-chave, na **Lilacs** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4-D.  
||**LILACS**|||
|---|---|---|---|
|||**Estratégia**||
|1. 2,4 D e Diagnóstico|2,4 D + diagnóstico|tw:((tw:("2, 4-D")) OR (tw:("2,4-D")) OR (tw:("2,4 D")) AND<br>(tw:(diagn*))) AND (instance:"regional") AND (<br>db:("LILACS"))|3 (2a)|
|||(tw:("2, 4-D")) OR (tw:("2,4-D")) OR (tw:("2,4 D")) AND||
|2. 2,4 D e sinais e sintomas|2,4 D + sinais e sintomas|(tw:(clini*))  OR (tw:(sinai*))  OR (tw:(sintom*)) OR<br>(tw:(senal*)) AND (tw:(agrotóx*)) OR (tw:(pesticid*))|1 (2b)|
|||(tw:("2, 4-D")) OR (tw:("2,4-D")) OR (tw:("2,4 D")) AND||
|3. 2,4 D e gravidade clínica|2,4 D + gravidade|(tw:(clini*))  OR (tw:(gravid*))  AND (tw:(agrotóx*)) OR<br>(tw:(pesticid*))|0|  
*Filtros aplicados: período 01/01/2010 a 31/08/2018, idiomas inglês, português e espanhol. Busca realizada no dia 02/10/2018.  
27  
**Quadro IV.2.3.** Estratégia de busca e associação de palavras-chave, no **PubMed,** para as perguntas PICO do Capítulo 4- 2,4 D, Tratamento.  
|**Pergunta**|**Bloco conceitual**|**Termos**|**Estratégia**|**Pubmed**|
|---|---|---|---|---|
|PUBMED|||||
|1. Quais são os métodos de<br>descontaminação efetivos na<br>intoxicação por 2,4 D?|Decontamination, methods,<br>glyphosate|Agrochemicals, Pesticides,<br>Intoxication, Poisoning,<br>Decontamination,<br>Glyphosate, humans.|("therapy"<br>[Subheading]<br>OR<br>"Emergency<br>Treatment"[Mesh]<br>OR<br>"Treatment<br>Adherence<br>and<br>Compliance"[Mesh] OR "Involuntary Treatment"[Mesh] OR||
|2. Quais são os métodos de<br>eliminação efetivos na<br>intoxicação por 2,4 D?|Decontamination, therapy,<br>excretion, methods, glyphosate|Agrochemicals, Pesticides,<br>Intoxication, Poisoning,<br>Decontamination, Excretion,<br>glyphosate, humans.|"Conservative<br>Treatment"[Mesh]<br>OR<br>"Therapeutics"[Mesh] OR  "complications" [Subheading]<br>OR "Aftercare"[Mesh] OR  "Retreatment"[Mesh] OR<br>"Rehabilitation"[Mesh] OR Treatment* OR Decontam* [All<br>||
|3. Qual é o tratamento inicial<br>para o paciente intoxicado com<br>2,4 D?|Treatment, therapy, intoxication,<br>glyphosate|Pesticides, Agrochemicals,<br>treatment, therapy,<br>glyphosate, humans.|Fields]<br>OR<br>Excret*)<br>AND<br>("Pesticides"[Mesh]<br>OR<br>"Agrochemicals"[Mesh] OR "Pesticide Residues"[Mesh])<br>AND ("poisoning"[Subheading] OR "poisoning"[All Fields]<br>OR "poisoning"[MeSH Terms] OR exposure[All Fields] OR|40<br>(1A)|
|4. Qual é a melhor forma de||Pesticides, Agrochemicals,|intoxicat* [All Fields] OR excret* [All Fields] OR eliminat*||
|fazer seguimento aos pacientes<br>com intoxicação aguda por 2,4|Follow-up, complications,<br>glyphosate|Intoxication, diagnosis,<br>aftercare, humans,|[All Fields] OR residue* [All Fields] OR metabolite*[All<br>Fields]) AND ("2,4-Dichlorophenoxyacetic Acid"[Mesh] OR||
|D?||glyphosate.|"Phenoxyacetates"[Mesh]<br>OR<br>"phenoxyacetic||
|5. Qual deve ser o<br>acompanhamento, segmento e<br>reabilitação do paciente<br>intoxicado por 2,4 D?|Aftercare, follow-up, retreatment,<br>rehabilitation, intoxication,<br>poisoning, glyphosate|Pesticides, Agrochemicals,<br>Intoxication, rehabilitation,<br>follow-up, humans,<br>glyphosate|acid"[Supplementary Concept]) AND (human) AND<br>(("2010/01/01"[PDAT]<br>:<br>"2018/08/31"[PDAT])<br>AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang]))||  
*Filtros aplicados: período 01/01/2010 a 31/08/2018, idiomas inglês, português e espanhol. Busca realizada no dia 02/10/2018.  
28  
##### **Quadro IV.2.4.** Estratégia de busca e associação de palavras-chave, na **Lilacs** , para as perguntas PICO do Capítulo 4- 2,4 D, Tratamento.  
||**LILACS**|||
|---|---|---|---|
|**Pergunta/ assunto**|**Termos**|**Estratégia**||
|||tw:((tw:("2, 4-D")) OR (tw:("2,4-D")) OR (tw:("2,4 D")) AND||
|4. 2,4 D e Tratamento|2,4 D + tratamento|(tw:(tratam*))  AND (tw:(agrotóx*)) OR (tw:(pesticid*)))<br>AND (instance:"regional") AND ( db:("LILACS") AND<br>type:("article"))|16 (2a)|  
*Filtros aplicados: período 01/01/2010 a 31/08/2018, idiomas inglês, português e espanhol. Busca realizada no dia 02/10/2018.  
**Quadro IV.2.5.** Estratégia de busca e associação de palavras-chave, no portal **Cochrane,** para as perguntas PICO do Capítulo 4- 2,4 D, Tratamento.  
||**COCHRANE**|||
|---|---|---|---|
|5. 2,4-Dichlorophenoxyacetic<br>Acid||2,4-Dichlorophenoxyacetic Acid in Title, Abstract,<br>Keywords in Trials'|1 (3a)|  
*Filtros aplicados: período 01/01/2010 a 31/08/2018, idiomas inglês, português e espa  
29

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
#### **IV.3.1: Diagnóstico– 2,4D**  
**Quadro IV.3.1.1** . Consideração sobre a utilização dos artigos resultantes da busca sistemática no site **Pubmed,** para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4D.  
**Quadro IV.3.1.2.** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site **Cochrane Library** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4D.  
**Quadro IV.3.1.3** . Consideração sobre a utilização dos artigos resultantes da busca sistemática no site **Lilacs- BVS** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4D.  
30  
**Quadro IV.3.1.1** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site **Pubmed,** para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4D.  
|**Busca**|**Artigo**|**Autores**|**Ano**|**Estudo**<br>**considerado?**|
|---|---|---|---|---|
|**1A**|Impact of presumed service-connected diagnosis on the<br>Department of Veterans Affairs healthcare utilization<br>patterns of Vietnam-Theater Veterans: A cross-sectional<br>study.|Fried DA, Rajan M, Tseng CL, Helmer<br>D.|2018|Não|
||A review of Agent Orange and its associated oncologic risk<br>of genitourinary cancers.|Chang C, Benson M, Fam MM.|2017|Não|
||The dissipation and risk assessment of 2,4-D sodium, a<br>preharvest anti-fruit-drop plant hormone in bayberries.|Zhao H, Yang G, Liang S, Huang Q,<br>Wang Q, Dai W, Zhang Z, Wang W,<br>SongW,Cai Z.|2017|Não|
||Exploring exposure to Agent Orange and increased<br>mortality due to bladder cancer.|Mossanen M, Kibel AS, Goldman RH.|2017|Não|
||2,4-dichlorophenoxyacetic acid (2,4-D) and risk of non-<br>Hodgkin lymphoma: a meta-analysis accounting<br>for exposurelevels.|Smith AM, Smith MT, La Merrill MA,<br>Liaw J, Steinmaus C.|2017|Não|
||A longitudinal study of atrazine and 2,4-D exposure and<br>oxidative stress markers among iowa corn farmers.|Lerro CC, Beane Freeman LE,<br>Portengen L, Kang D, Lee K, Blair A,<br>Lynch CF, Bakke B, De Roos AJ,<br>Vermeulen RC.|2017|Sim|  
31  
|Developmental toxicity of 2,4-dichlorophenoxyacetic acid in<br>zebrafish embryos.|Li K, Wu JQ, Jiang LL, Shen LZ, Li JY,<br>He ZH, Wei P, Lv Z, He MF.|2017|Não|
|---|---|---|---|
|Efficiency control of dietary pesticide intake reduction by<br>human biomonitoring.|Göen T, Schmidt L, Lichtensteiger W,<br>Schlumpf M.|2016|Sim|
|Wartime toxin exposure: recognising the silent killer.|Khan K, Wozniak SE, Coleman J,<br>Didolkar MS.|2017|Não|
|Legal liability for Agent Orange-related illnesses: a<br>reassessment of the 2005 VAVA case and prospects for new<br>litigation.|Klickermann F.|2016|Não|
|Adult and child urinary 2,4-D in cities with and without<br>cosmetic pesticide bylaws: a population-based cross-<br>sectional pilot study.|Venners SA, Khoshnood N, Jeronimo<br>M, Sobkowicz A,|2017|Sim|
|Military service, deployments, and exposures in relation to<br>amyotrophic lateral sclerosis etiology.|Beard JD, Engel LS, Richardson DB,<br>Gammon MD, Baird C, Umbach DM,<br>Allen KD, Stanwyck CL, Keller J,<br>Sandler DP, Schmidt S, Kamel F.|2016|Não|
|Factors Influencing Dislodgeable 2, 4-D Plant Residues from<br>Hybrid Bermudagrass (Cynodon dactylon L. x C.<br>transvaalensis) Athletic Fields.|Jeffries MD, Gannon TW, Brosnan JT,<br>Ahmed KA, Breeden GK.|2016|Não|  
32  
|Interpreting biomonitoring data for 2,4-<br>dichlorophenoxyacetic acid: Update to Biomonitoring<br>Equivalents and population biomonitoring data.|Aylward LL, Hays SM.|2015|Sim|
|---|---|---|---|
|Dioxins and cytogenetic status of villagers after 40 years of<br>agent Orange application in Vietnam.|Sycheva LP, Umnova NV, Kovalenko<br>MA, Zhurkov VS, Shelepchikov AA,<br>Roumak VS.|2016|Não|
|The Air Force Health Study Data and Specimens as a<br>Resource for Researchers.|Styka AN, Butler DA.|2015|Sim|
|Agent Orange Exposure and Monoclonal Gammopathy of<br>Undetermined Significance: An Operation Ranch Hand<br>Veteran Cohort Study.|Landgren O, Shim YK, Michalek J,<br>Costello R, Burton D, Ketchum N,<br>Calvo KR, Caporaso N, Raveche E,<br>Middleton D, Marti G, Vogt RF Jr.|2015|Não|
|Association of Agent Orange With Plasma Cell Disorder:<br>Further Evidence.|Munshi NC.|2015|Não|
|Blue Water Navy Vietnam Veterans and Agent<br>Orange Exposure.|[No authors listed]|2015|Não|
|Serum concentrations of chlorinated dibenzo-p-dioxins,<br>furans and PCBs, among former phenoxy herbicide<br>production workers and firefighters in New Zealand.|'t Mannetje A, Eng A, Walls C,<br>Dryson E, McLean D, Kogevinas M,<br>Fowles J, Borman B, O'Connor P,<br>Cheng S, Brooks C, H Smith A, Pearce<br>N.|2016|Sim|  
33  
|Presumption of Herbicide Exposure and Presumption of<br>Disability During Service for Reservists Presumed Exposed<br>to Herbicide. Interim final rule.|Department of Veterans Affairs.|2015|Não|
|---|---|---|---|
|Agent Orange and long-term outcomes after radical<br>prostatectomy.|Ovadia AE, Terris MK, Aronson WJ,<br>Kane CJ, Amling CL, Cooperberg MR,<br>Freedland SJ, Abern MR.|2015|Não|
|Predictors of urinary levels of 2,4-dichlorophenoxyacetic<br>acid, 3,5,6-trichloro-2-pyridinol, 3-phenoxybenzoic acid,<br>and pentachlorophenol in 121 adults in Ohio.|Morgan MK.|2015|Sim|
|2-Methyl-4-chlorophenoxyacetic acid and bromoxynil<br>herbicide death.|Berling I, Buckley NA, Mostafa A,<br>Downes MA, Grice J, Medley G,<br>Roberts MS, Isbister GK.|2015|Sim|
|A critical review of the epidemiology of Agent Orange or<br>2,3,7,8-tetrachlorodibenzo-p-dioxin and lymphoid<br>malignancies.|Chang ET, Boffetta P, Adami HO,<br>Mandel JS.|2015|Não|
|Response to: ME Ginevan et al. Exposure estimates in<br>epidemiological studies of Korean veterans of the Vietnam<br>War.|Stellman SD, Stellman JM.|2015|Não|
|Exposure estimates in epidemiological studies of Korean<br>veterans of the Vietnam War.|Ginevan ME, Watkins DK, Ross JH.|2015|Não|  
34  
|Organophosphate pesticide exposure and dialkyl phosphate<br>urinary metabolites among chili farmers in northeastern<br>Thailand.|Taneepanichskul N, Norkaew S,<br>Siriwong W, Siripattanakul-Ratpukdi<br>S, Maldonado Pérez HL, Robson MG.|2014|Sim|
|---|---|---|---|
|Predictors for dioxin accumulation in residents living in Da<br>Nang and Bien Hoa, Vietnam, many years after Agent<br>Orange use.|Pham DT, Nguyen HM, Boivin TG,<br>Zajacova A, Huzurbazar SV, Bergman<br>HL.|2015|Não|
|Environmental fate and dietary exposures of humans to<br>TCDD as a result of the spraying of Agent Orange in upland<br>forests of Vietnam.|Armitage JM, Ginevan ME, Hewitt A,<br>Ross JH, Watkins DK, Solomon KR.|2015|Não|
|Urinary biomarkers of exposure to insecticides, herbicides,<br>and one insect repellent among pregnant women in Puerto<br>Rico.|Lewis RC, Cantonwine DE, Anzalota<br>Del Toro LV, Calafat AM, Valentin-<br>Blasini L, Davis MD, Baker SE,<br>Alshawabkeh AN, Cordero JF,<br>Meeker JD.|2014|Sim|
|Surfactant toxicity in a case of (4-chloro-2-methylphenoxy)<br>acetic acid herbicide intoxication.|Hwang I, Lee JW, Kim JS, Gil HW,<br>Song HY, Hong SY.|2015|Sim|
|Parental military service, agent orange exposure, and the<br>risk of rhabdomyosarcoma in offspring.|Grufferman S, Lupo PJ, Vogel RI,<br>Danysh HE, Erhardt EB, Ognjanovic<br>S.|2014|Não|
|Is science public health's BFF?|Brown TM.|2014|Não|  
35  
|Challenges in investigating the association between Agent<br>Orange and cancer: site-specific cancer risk and accuracy<br>of exposure assessment.|Sinks TH.|2014|Não|
|---|---|---|---|
|Agent Orange exposure and cancer incidence in Korean<br>Vietnam veterans: a prospective cohort study.|Yi SW, Ohrr H.|2014|Não|
|Chronic exposure to chlorophenol related compounds in<br>the pesticide production workplace and lung cancer: a<br>meta-analysis.|Zendehdel R, Tayefeh-Rahimian R,<br>Kabir A.|2014|Não|
|An unusual case of non-fatal poisoning due to herbicide 4-<br>chloro-2-methyl phenoxyacetic acid (MCPA).|Tennakoon DA, Perera KA,<br>Hathurusinghe LS.|2014|Sim|
|Commentary on "Post-Vietnam military herbicide<br>exposures in UC-123 Agent Orange spray aircraft".|Nieman JK.|2014|Não|
|Response to commentary: Post-Vietnam military herbicide<br>exposures in UC-123 Agent Orange spray aircraft.|Lurker PA, Berman F, Clapp RW,<br>Stellman J.|2014|Não|
|Agent Orange and heart disease: is there a connection?|Lowenstein J.|2014|Não|
|Post-Vietnam military herbicide exposures in UC-123 Agent<br>Orange spray aircraft.|Lurker PA, Berman F, Clapp RW,<br>Stellman JM.|2014|Não|  
36  
|Serum dioxin levels in Vietnamese men more than 40 years<br>after herbicide spraying.|Manh HD, Kido T, Okamoto R,<br>Xianliang S, Anh le T, Supratman S,<br>Maruzeni S, Nishijo M, Nakagawa H,<br>Honma S, Nakano T, Takasuga T,<br>Nhu DD, Hung NN, Son le K.|2014|Não|
|---|---|---|---|
|Pesticide exposures to migrant farmworkers in Eastern NC:<br>detection of metabolites in farmworker urine associated<br>with housing violations and camp characteristics.|Raymer JH, Studabaker WB, Gardner<br>M, Talton J, Quandt SA, Chen H,<br>Michael LC, McCombs M, Arcury TA.|2014|Sim|
|Simultaneous liquid-liquid extraction and dispersive solid-<br>phase extraction as a sample preparation method to<br>determine acidic contaminants in river water by gas<br>chromatography/mass spectrometry.|Jiménez JJ.|2013|Não|
|Serum 2,3,7,8-tetrachlorodibenzo-p-dioxin levels and their<br>association with age, body mass index, smoking, military<br>record-based variables, and estimated exposure to Agent<br>Orange in Korean Vietnam veterans.|Yi SW, Ohrr H, Won JU, Song JS,<br>Hong JS.|2013|Não|
|Agent Orange exposure and prevalence of self-reported<br>diseases in Korean Vietnam veterans.|Yi SW, Ohrr H, Hong JS, Yi JJ.|2013|Não|
|High cortisol and cortisone levels are associated with breast<br>milk dioxin concentrations in Vietnamese women.|Kido T, Dao TV, Ho MD, Duc Dang N,<br>Pham NT, Okamoto R, Pham TT,<br>Maruzeni S, Nishijo M, Nakagawa H,<br>Honma S, Le SK, Nguyen HN.|2013|Não|  
37  
|Disease associated with exposure to certain herbicide<br>agents: peripheral neuropathy.|Department of Veterans Affairs.|2013|Não|
|---|---|---|---|
|Dietary predictors of young children's exposure to current-<br>use pesticides using urinary biomonitoring.|Morgan MK, Jones PA.|2013|Sim|
|Triketone toxicity: a report on two cases of<br>sulcotrione poisoning.|Boels D, Monteil-Ganière C, Turcant<br>A, Bretaudeau M, Harry P.|2013|Não|
|The impact of Agent Orange exposure on presentation and<br>prognosis of patients with chronic lymphocytic leukemia.|Baumann Kreuziger LM, Tarchand G,<br>Morrison VA.|2014|Não|
|The relationships between pesticide metabolites and<br>neurobehavioral test performance in the third National<br>Health and Nutrition Examination Survey.|Krieg EF Jr.|2013|Sim|
|2,4-D exposure and risk assessment: comparison of external<br>dose and biomonitoring based approaches.|Hays SM, Aylward LL, Driver J, Ross J,<br>Kirman C.|2012|Sim|
|Review of 2,4-dichlorophenoxyacetic acid (2,4-D)<br>biomonitoring and epidemiology.|Burns CJ, Swaen GM.|2012|Sim|
|Exposure to phenoxyacetic acid herbicides and predictors<br>of exposure among spouses of farmers.|Jurewicz J, Hanke W, Sobala W,<br>Ligocka D.|2012|Sim|  
38  
|Uncaria tomentosa extracts protect human erythrocyte<br>catalase against damage induced by 2,4-D-Na and<br>its metabolites.|Bukowska B, Bors M, Gulewicz K,<br>Koter-Michalak M.|2012|Não|
|---|---|---|---|
|No association between Agent Orange exposure and<br>monoclonal gammopathies.|Parikh JG, Pearlman E.|2012|Não|
|Cancer incidence of 2,4-D production workers.|Burns C, Bodner K, Swaen G, Collins<br>J, Beard K, Lee M.|2011|Não|
|Clinical outcome of acute intoxication due to ingestion of<br>auxin-like herbicides.|Park JS, Seok SJ, Gil HW, Yang JO,<br>Lee EY, Park YH, Hong SY.|2011|Sim|
|Science versus policy in establishing equitable Agent<br>Orange disability compensation policy.|Brown MA.|2011|Não|
|Agent Orange exposure and attributed health effects in<br>Vietnam veterans.|Young AL, Cecil PF Sr.|2011|Não|
|Pesticide risk assessment: A study on inhalation and<br>dermal exposure to 2,4-D and paraquat among Malaysian<br>paddy farmers.|Baharuddin MR, Sahid IB, Noor MA,<br>Sulaiman N, Othman F.|2011|Sim|
|Assessment of dermal exposure to pesticide residues during<br>re-entry.|Belsey NA, Cordery SF, Bunge AL,<br>Guy RH.|2011|Sim|  
39  
|Concurrent 2,4-D and triclopyr biomonitoring of backpack<br>applicators, mixer/loader and field supervisor in forestry.|Zhang X, Acevedo S, Chao Y, Chen Z,<br>Dinoff T, Driver J, Ross J, Williams R,<br>Krieger R.|2011|Sim|
|---|---|---|---|
|The Air Force health study: an epidemiologic retrospective.|Buffler PA, Ginevan ME, Mandel JS,<br>Watkins DK.|2011|Não|
|Consideration of dosimetry in evaluation of ToxCast™ data.|Aylward LL, Hays SM.|2011|Sim|
|Herbicide exposure and veterans with covered service in<br>Korea. Final rule.|Department of Veterans Affairs.|2011|Não|
|Impact of pesticide exposure misclassification on estimates<br>of relative risks in the Agricultural Health Study.|Blair A, Thomas K, Coble J, Sandler<br>DP, Hines CJ, Lynch CF, Knott C,<br>Purdue MP, Zahm SH, Alavanja MC,<br>Dosemeci M, Kamel F, Hoppin JA,<br>Freeman LB, Lubin JH.|2011|Sim|
|Toxicokinetics, including saturable protein binding, of 4-<br>chloro-2-methyl phenoxyacetic acid (MCPA) in patients with<br>acute poisoning.|Roberts DM, Dawson AH,<br>Senarathna L, Mohamed F, Cheng R,<br>Eaglesham G, Buckley NA.|2011|Sim|
|A synopsis of 30 years of major accomplishments by the<br>Pennsylvania Department of Health in Environmental<br>Health (Part 1 of 2): the 1980s.|Logue JN, Sivarajah K.|2010|Não|
|Case series of 2,4-D poisoning in Tikur Anbessa Teaching<br>Hospital.|Azazh A.|2010|Sim|  
40  
|Repeated pesticide exposure among North Carolina migrant and<br>seasonal farmworkers.|Arcury TA, Grzywacz JG, Talton JW,<br>Chen H, Vallejos QM, Galván L, Barr DB,<br>Quandt SA.|2010|Sim|
|---|---|---|---|
|The use of epidemiological evidence in the compensation of<br>veterans.|Samet JM, McMichael GH 3rd,<br>Wilcox AJ.|2010|Não|
|Letter to the editor and response. Re: Production of illicit<br>drugs, the environment, and human health, J of Toxicology<br>and Environmental Medicine 2009;72 (15-16).|Gomez JG.|2010|Não|
|Desmoplastic small round-cell tumor: an adult with<br>previous exposure to agent orange.|Baz W, El-Soueidi R, Nakhl F, Aoun N,<br>Chin N, Dhar M.|2010|Não|
|Perturbation of lipids and glucose metabolism associated<br>with previous 2,4-D exposure: a cross-sectional study of<br>NHANES III data, 1988-1994.|Schreinemachers DM.|2010|Sim|
|Paternal exposure to Agent Orange and spina bifida: a<br>meta-analysis.|Ngo AD, Taylor R, Roberts CL.|2010|Não|
|Assessment of a pesticide exposure intensity algorithm in<br>the agricultural health study.|Thomas KW, Dosemeci M, Coble JB,<br>Hoppin JA, Sheldon LS, Chapa G,<br>Croghan CW, Jones PA, Knott CE,<br>Lynch CF, Sandler DP, Blair AE,<br>Alavanja MC.|2010|Sim|  
41  
||Cause-specific mortality of Dutch chlorophenoxy herbicide<br>manufacturing workers.|Boers D, Portengen L, Bueno-de-<br>Mesquita HB, Heederik D,<br>Vermeulen R.|2010|Sim|
|---|---|---|---|---|
||Exposures of preschool children to chlorpyrifos, diazinon,<br>pentachlorophenol, and 2,4-dichlorophenoxyacetic<br>acid over 3 years from 2003 to 2005: A longitudinal model.|Wilson NK, Strauss WJ, Iroz-Elardo<br>N, Chuang JC.|2010|Sim|
||TCDD exposure estimation for workers at a New Zealand<br>2,4,5-T manufacturing facility based on serum sampling<br>data.|Aylward LL, Bodner KM, Collins JJ,<br>Wilken M, McBride D, Burns CJ, Hays<br>SM, Humphry N.|2010|Sim|
||Predictors of 2,4-dichlorophenoxyacetic acid exposure<br>among herbicide applicators.|Bhatti P, Blair A, Bell EM, Rothman<br>N, Lan Q, Barr DB, Needham LL,<br>Portengen L, Figgs LW, Vermeulen R.|2010|Sim|
|**1B**|A review of Agent Orange and its associated oncologic risk<br>of genitourinary cancers.|Chang C, Benson M, Fam MM.|2017|Não|
||Exploring exposure to Agent Orange and increased<br>mortality due to bladder cancer.|Mossanen M, Kibel AS, Goldman RH.|2017|Não|
||Wartime toxin exposure: recognising the silent killer.|Khan K, Wozniak SE, Coleman J,<br>Didolkar MS.|2016|Não|
||Interpreting biomonitoring data for 2,4-<br>dichlorophenoxyacetic acid: Update to Biomonitoring<br>Equivalents andpopulation biomonitoringdata.|Aylward LL, Hays SM.|2015|Não|  
42  
|Dioxins and cytogenetic status of villagers after 40 years of<br>agent Orange application in Vietnam.|Sycheva LP, Umnova NV, Kovalenko<br>MA, Zhurkov VS, Shelepchikov AA,<br>Roumak VS.|2016|Não|
|---|---|---|---|
|The Air Force Health Study Data and Specimens as a<br>Resource for Researchers.|Styka AN, Butler DA.|2015|Não|
|Agent Orange Exposure and Monoclonal Gammopathy of<br>Undetermined Significance: An Operation Ranch Hand<br>Veteran Cohort Study.|Landgren O, Shim YK, Michalek J,<br>Costello R, Burton D, Ketchum N,<br>Calvo KR, Caporaso N, Raveche E,<br>Middleton D, Marti G, Vogt RF Jr.|2015|Não|
|Presumption of Herbicide Exposure and Presumption of<br>Disability During Service for Reservists Presumed Exposed<br>to Herbicide. Interim final rule.|Department of Veterans Affairs.|2015|Não|
|Agent Orange and long-term outcomes after radical<br>prostatectomy.|Ovadia AE, Terris MK, Aronson WJ,<br>Kane CJ, Amling CL, Cooperberg MR,<br>Freedland SJ, Abern MR.|2015|Não|
|Serum 2,3,7,8-tetrachlorodibenzo-p-dioxin levels and their<br>association with age, body mass index, smoking, military<br>record-based variables, and estimated exposure to Agent<br>Orange in Korean Vietnam veterans.|Yi SW, Ohrr H, Won JU, Song JS,<br>Hong JS.|2013|Não|
|Disease associated with exposure to certain herbicide<br>agents:peripheral neuropathy.|Department of Veterans Affairs.|2013|Não|  
43  
|Triketone toxicity: a report on two cases of<br>sulcotrione poisoning.|Boels D, Monteil-Ganière C, Turcant<br>A, Bretaudeau M, Harry P.|2013|Não|
|---|---|---|---|
|The impact of Agent Orange exposure on presentation and<br>prognosis of patients with chronic lymphocytic leukemia.|Baumann Kreuziger LM, Tarchand G,<br>Morrison VA.|2014|Não|
|Clinical outcome of acute intoxication due to ingestion of<br>auxin-like herbicides.|Park JS, Seok SJ, Gil HW, Yang JO,<br>Lee EY, Park YH, Hong SY.|2011|Não|
|Case series of 2,4-D poisoning in Tikur Anbessa Teaching<br>Hospital.|Azazh A.|2010|Não|
|Desmoplastic small round-cell tumor: an adult with<br>previous exposure to agent orange.|Baz W, El-Soueidi R, Nakhl F, Aoun N,<br>Chin N, Dhar M.|2010|Não|  
**Quadro IV.3.1.2.** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site **Cochrane Library** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4D.  
**Quadro IV.3.1.3.** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site **Lilacs- BVS** , para as perguntas PICO de Diagnóstico do Capítulo 4 – 2,4D.  
44  
|**2a**|Queratoplastia Lamelar Anterior Profunda asistida con láser<br>de femtosegundo configuración Zig-Zag: Resultados a un<br>año de seguimiento / Deep Anterior Lamellar Keratoplasty<br>in a Zig-Zag Pattern Assisted by Femtosecond Laser: 1 year<br>follow up|Vélez, Mauricio; Velásquez,<br>Luis; Rojas, Sebastián; Montoya<br>López, Laura.|2017|Não|
|---|---|---|---|---|
||Efecto Hipotensor de la Trabeculoplastia Láser /<br>Hypotensive Eff ect of Laser Trabeculoplasty|Goyeneche, Fernando<br>Gómez; Toquica Osorio,<br>Jeanneth; Hernández Mendieta,<br>Patricia; Sarmiento, Diana.|2017|Não|
||Effects of the 2, 4-D herbicide on gills epithelia and liver of<br>the fish Poecilia vivipara / Efeitos do herbicida 2, 4-D no<br>epitélio das brânquias e no fígado do peixe Poecilia vivípara|Vigário, Ana F; Sabóia-Morais,<br>Simone M. T.|2014|Não|
|**2b**|Effects of the 2, 4-D herbicide on gills epithelia and liver of<br>the fish Poecilia vivipara / Efeitos do herbicida 2, 4-D no<br>epitélio das brânquias e no fígado do peixe Poecilia vivípara|Vigário, Ana F; Sabóia-Morais,<br>Simone M. T.|2014|REP|  
45  
##### **ANEXO IV.3.2 - Tratamento – 2,4D**  
**Quadro IV.3.2.2.** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site Pubmed, para as perguntas PICO de Tratamento do Capítulo 4 – 2,4D.  
**Quadro IV.3.2.2** . Consideração sobre a utilização dos artigos resultantes da busca sistemática no site Lilacs- BVS, para as perguntas PICO de Tratamento do Capítulo 4 – 2,4D.  
**Quadro IV.3.2.3.** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site Cochrane Library, para as perguntas PICO de Tratamento do Capítulo 4 – 2,4D.  
**Quadro IV.3.2.1.** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site Pubmed, para as perguntas PICO de Tratamento do Capítulo 4 – 2,4D.  
|**Busca**|**Artigo**|**Autores**|**Ano**|**Estudo**<br>**Considerado?**|
|---|---|---|---|---|
|1A|Impact of presumed service-connected diagnosis on the<br>Department of Veterans Affairs healthcare utilization<br>patterns of Vietnam-Theater Veterans: A cross-sectional<br>study.|Fried DA, Rajan M, Tseng CL,<br>Helmer D.|2018|Não|
||No treatment-related effects with aryloxyalkanoate<br>dioxygenase-12 in three 28-day mouse toxicity studies.|Papineni S, Thomas J, Marshall<br>VA, Juberg DR, Herman RA.|2018|Não|
||The phytoremediation potential of Plectranthus neochilus<br>on 2,4-dichlorophenoxyacetic acid and the role of<br>antioxidant capacity in herbicide tolerance.|Ramborger BP, Ortis Gularte CA,<br>Rodrigues DT, Gayer MC, Sigal<br>Carriço MR, Bianchini MC, Puntel<br>RL, Denardin ELG, Roehrs R.|2017|Não|  
46  
|The influence of chemical protection on the content of<br>heavy metals in wheat (Triticum aestivum L.) growing on<br>the soil enriched with granular sludge.|Wołejko E, Łozowicka B,<br>Kaczyński P, Konecki R, Grobela<br>M.|2017|Não|
|---|---|---|---|
|Biokinetic Analysis and Metabolic Fate of 2,4-D in 2,4-D-<br>Resistant Soybean (Glycine max).|Skelton JJ, Simpson DM,<br>Peterson MA, Riechers DE.|2017|Não|
|Developmental toxicity of 2,4-dichlorophenoxyacetic<br>acid in zebrafish embryos.|Li K, Wu JQ, Jiang LL, Shen LZ, Li<br>JY, He ZH, Wei P, Lv Z, He MF.|2017|Não|
|Efficiency control of dietary pesticide intake reduction by<br>human biomonitoring.|Göen T, Schmidt L, Lichtensteiger<br>W, Schlumpf M.|2017|Sim|
|Wartime toxin exposure: recognising the silent killer.|Khan K, Wozniak SE, Coleman J,<br>Didolkar MS.|2016|Sim|
|Effects of oral administration of 2,4-dichlorophenoxyacetic<br>acid (2,4-D) on reproductive parameters in male Wistar<br>rats.|Marouani N, Tebourbi O, Cherif<br>D, Hallegue D, Yacoubi MT, Sakly<br>M, Benkhalifa M, Ben Rhouma K.|2017|Não|
|Degradation and enantiomeric fractionation of mecoprop<br>in soil previously exposed to phenoxy acid herbicides -<br>New insights for bioremediation.|Frková Z, Johansen A, de Jonge<br>LW, Olsen P, Gosewinkel U,<br>Bester K.|2016|Não|
|Ecotoxicological hazards of herbicides on biological<br>attributes of Zygogramma bicolorata Pallister (Coleoptera:<br>Chrysomelidae).|Hasan F, Ansari MS.|2016|Não|  
47  
|Toxic and genotoxic effects of the 2,4-<br>dichlorophenoxyacetic acid (2,4-D)-based herbicide on the<br>Neotropical fish Cnesterodon decemmaculatus.|Ruiz de Arcaute C, Soloneski S,<br>Larramendy ML.|2016|Não|
|---|---|---|---|
|Factors Influencing Dislodgeable 2, 4-D<br>Plant Residues from Hybrid Bermudagrass (Cynodon<br>dactylon L. x C. transvaalensis) Athletic Fields.|Jeffries MD, Gannon TW,<br>Brosnan JT, Ahmed KA, Breeden<br>GK.|2016|Não|
|Effects of 2,4-dichlorophenoxyacetic acid on the ventral<br>prostate of rats during the peri-pubertal, pubertal and<br>adult stage.|Pochettino AA, Hapon MB,<br>Biolatto SM, Madariaga MJ, Jahn<br>GA, Konjuh CN.|2016|Não|
|Effects of Pesticide Mixtures on Host-Pathogen Dynamics<br>of the Amphibian Chytrid Fungus.|Buck JC, Hua J, Brogan WR 3rd,<br>Dang TD, Urbina J, Bendis RJ,<br>Stoler AB, Blaustein AR, Relyea<br>RA.|2015|Não|
|Effect of PFOA/PFOS pre-exposure on the toxicity of the<br>herbicides 2,4-D, Atrazine, Diuron and Paraquat to a model<br>aquatic photosynthetic microorganism.|Rodea-Palomares I, Makowski M,<br>Gonzalo S, González-Pleiter M,<br>Leganés F, Fernández-Piñas F.|2015|Não|
|Agent Orange and long-term outcomes after radical<br>prostatectomy.|Ovadia AE, Terris MK, Aronson<br>WJ, Kane CJ, Amling CL,<br>Cooperberg MR, Freedland SJ,<br>Abern MR.|2015|Não|
|Is sciencepublic health's BFF?|Brown TM.|2014|Não|  
48  
|Post-Vietnam military herbicide exposures in UC-123<br>Agent Orange spray aircraft.|Lurker PA, Berman F, Clapp RW,<br>Stellman JM.|2014|Não|
|---|---|---|---|
|Transient effects of 2,4-dichlorophenoxyacetic acid (2,4-<br>D) exposure on some metabolic and free radical processes<br>in goldfish white muscle.|Kubrak OI, Atamaniuk TM, Husak<br>VV, Lushchak VI.|2013|Não|
|Enhanced herbicide metabolism induced by 2,4-D in<br>herbicide susceptible Lolium rigidum provides protection<br>against diclofop-methyl.|Han H, Yu Q, Cawthray GR,<br>Powles SB.|2013|Não|
|The impact of Agent Orange exposure on presentation and<br>prognosis of patients with chronic lymphocytic leukemia.|Baumann Kreuziger LM,<br>Tarchand G, Morrison VA.|2014|Não|
|Microbial degradation of the pharmaceutical ibuprofen<br>and the herbicide 2,4-D in water and soil - use and limits of<br>data obtained from aqueous systems for predicting their<br>fate in soil.|Girardi C, Nowak KM, Carranza-<br>Diaz O, Lewkow B, Miltner A,<br>Gehre M, Schäffer A, Kästner M.|2013|Não|
|Biochemical and histological evaluation of kidney<br>damage after sub-acute exposure to 2,4-<br>dichlorophenoxyacetic herbicide in rats: involvement of<br>oxidative stress.|Tayeb W, Nakbi A, Trabelsi M,<br>Miled A, Hammami M.|2012|Não|  
49  
|The dioxin/POPs legacy of pesticide production in<br>Hamburg: part 2--waste deposits and remediation of<br>Georgswerder landfill.|Götz R, Sokollek V, Weber R.|2013|Não|
|---|---|---|---|
|Dioxin/POPs legacy of pesticide production in Hamburg:<br>part 1--securing of the production area.|Weber R, Varbelow HG.|2013|Não|
|Evaluation of the role of the glutathione redox cycle<br>in Cu(II) toxicity to green algae by a chiral perturbation<br>approach.|Chen H, Chen J, Guo Y, Wen Y,<br>Liu J, Liu W.|2012|Não|
|Phytotoxicity and antioxidative enzymes of green<br>microalga (Desmodesmus subspicatus) and duckweed<br>(Lemna minor) exposed to herbicides MCPA, chloridazon<br>and their mixtures.|Bisewska J, Sarnowska EI, Tukaj<br>ZH.|2012|Não|
|Clinical outcome of acute intoxication due to<br>ingestion of auxin-like herbicides.|Park JS, Seok SJ, Gil HW, Yang JO,<br>Lee EY, Park YH, Hong SY.|2011|Sim|
|Hypolipidimic and antioxidant activities of virgin olive oil<br>and its fractions in 2,4-diclorophenoxyacetic acid-treated<br>rats.|Nakbi A, Tayeb W, Dabbou S,<br>Chargui I, Issaoui M, Zakhama A,<br>Miled A, Hammami M.|2012|Não|
|Concurrent 2,4-D and triclopyr biomonitoring of backpack<br>applicators, mixer/loader and field supervisor in forestry.|Zhang X, Acevedo S, Chao Y,<br>Chen Z, Dinoff T, Driver J, Ross J,<br>Williams R, Krieger R.|2011|Não|  
50  
|Enantioselective oxidative damage of chiral pesticide<br>dichlorprop to maize.|Wu T, Li X, Huang H, Zhang S.|2011|Não|
|---|---|---|---|
|Toxicokinetics, including saturable protein binding, of 4-<br>chloro-2-methyl phenoxyacetic acid (MCPA) in patients<br>with acute poisoning.|Roberts DM, Dawson AH,<br>Senarathna L, Mohamed F,<br>Cheng R, Eaglesham G, Buckley<br>NA.|2011|Não|
|A synopsis of 30 years of major accomplishments by the<br>Pennsylvania Department of Health in Environmental Health<br>(Part 1 of 2): the 1980s.|Logue JN, Sivarajah K.|2010|Não|
|Case series of 2,4-D poisoning in Tikur Anbessa Teaching<br>Hospital.|Azazh A.|2010|Sim|
|Prior exposure to organophosphorus and<br>organochlorine pesticides increases the allergic potential of<br>environmental chemical allergens in a local lymph node assay.|Fukuyama T, Kosaka T, Tajima Y,<br>Ueda H, Hayashi K, Shutoh Y,<br>Harada T.|2010|Não|
|Dietary olive oil effect on antioxidant status and fatty acid<br>profile in the erythrocyte of 2,4-D- exposed rats.|Nakbi A, Tayeb W, Dabbou S, Issaoui<br>M, Grissa AK, Attia N, Hammami M.|2010|Não|
|Hepatotoxicity induced by sub-acute exposure of rats to 2,4-<br>Dichlorophenoxyacetic acid based herbicide "Désormone<br>lourd".|Tayeb W, Nakbi A, Trabelsi M, Attia<br>N, Miled A, Hammami M.|2010|Não|  
51  
|Fabrication and electrochemical treatment application of a|Zhao G, Zhang Y, Lei Y, Lv B, Gao J,|2010|Não|
|---|---|---|---|
|novel lead dioxide anode with superhydrophobic surfaces, high<br>oxygen evolution potential, and oxidation capability.|Zhang Y, Li D.|||
|Confirmed 2,4-dichlorophenoxyacetic acid toxicosis in a dog.|Chen AV, Bagley RS, Talcott PA.|2010|Não|  
**Quadro IV.3.2.2** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site Lilacs- BVS, para as perguntas PICO de Tratamento do Capítulo 4 – 2,4D.  
|**2a**|Production of pigments in Alternanthera sessilis calli<br>mediated by plant growth regulators and light / Produção<br>de pigmentos em calos de Alternanthera sessilis<br>mediados por reguladores de crescimento e luz|Milech, Cristini; Lucho, Simone<br>Ribeiro; Kleinowski, Alítcia Moraes; Dutra,<br>Débora Berwaldt; Soares, Mariana<br>Mühlenberg; Braga, Eugenia Jacira Bolacel.|2017|Não|
|---|---|---|---|---|
||Aspectos biológicos de Tetranychus ludeni Zacher, 1913<br>(Acari: Tetranychidae) alimentados com folhas de batata-<br>doce pulverizadas com o 2,4-D / Biological aspects of<br>Tetranychus ludeni Zacher, 1913 (Acari: Tetranychidae)<br>fed on sweet potato leaves sprayed with 2,4-D|Silva, Ludmila Aglai da; Soares, Marcus<br>Alvarenga; Aguiar, Luciana<br>Monteiro; Ferreira, Caroline<br>Conrado; Vieira, Estela Rosana<br>Durães; Santos, José Barbosa dos.|2017|Não|
||Atividade residual e carência irregular do ácido<br>diclorofenoxiacético (2, 4-d) no desenvolvimento inicial<br>da soja / Residual activity and irregular depletion of<br>dichlorophenoxyactic acid (2, 4-d) in the early<br>development of soybean / Actividad residual y carencia|Cecato, Gustavo Cândido; Souza, André<br>Vasquez; Quemel, Franciele da Silva; Valle,<br>Juliana Silveira do; Gomes, Simone de<br>Melo Santana; Lopes, Ana Daniela.|2017|Não|  
52  
|irregular del ácido diclorofenoxiacético (2, 4-d) en el<br>desarrollo inicial de la soja||||
|---|---|---|---|
|Efecto de Dicamba y de ácido 2,4 diclorofenoxiacético<br>sobre la embriogénesis somática en caña de azúcar /<br>Effect of Dicamba and 2,4 dichlorophenoxiacetic acid on<br>sugarcane somatic embryogenesis|Alvez, Beatriz; Oropeza, Maira.|2015|Não|
|In vitro germination, callus induction and phenolic<br>compounds contents from Pyrostegia venusta (Ker Gawl)<br>Miers / Germinação in vitro, indução de calos e teores de<br>compostos fenólicos em Pyrostegia venusta (Ker Gawl)<br>Miers|Braga, Karina de Queiroz; Coimbra, Mairon<br>César; Castro, Ana Hortência Fonsêca.|2015|Não|
|Inducción de callos embriogénicos y formación de<br>proembriones somáticos en Pterogyne nitens Tull "tipa<br>colorada" / Embriogenic calli induction and somatic<br>proembryo formation in Pterogyne nitens Tull|Vacca Molina, Maritza; Cristina Bonomo,<br>María Luisa; Avilés, Zulma; Díaz, Lucía.|2014|Não|
|Adjuvantes na deriva de 2,4-D + glyphosate em condições<br>de campo / Adjuvants on spray drift of 2,4-D + glyphosate<br>in field conditions|Costa, Augusto Guerreiro Fontoura; Velini,<br>Edivaldo Domingues; Rossi, Caio Vitagliano<br>Santi; Corrêa, Marcelo Rocha;Negrisoli,<br>Eduardo; Fiorini, Marcus Vinicius; Siono,<br>Luis Marcelo.|2014|Não|  
53  
|Seletividade de herbicidas em trevo-branco no estádio<br>fenológico de expansão do primeiro trifólio / Herbicide<br>selectivity on white clover in phenological stage of first<br>trifoliate expanding|Machado, Danielle; Lustosa, Sebastião<br>Brasil Campos; Baldissera, Tiago<br>Celso; Turok, João Daniel<br>Nerone; Machado, Marielle; Watzlawick,<br>Luciano Farinha; Mendonça, Cristina<br>Gonçalves de; Pelissari, Adelino.|2013|Não|
|---|---|---|---|
|Cultivos celulares de Choibá Dipteryx oleifera Benth / Cell<br>cultures of Choiba Dipteryx oleifera Benth|Murillo Gómez, Paola A; Atehortúa, Lucía.|2013|Não|
|Establishment of cell suspension cultures of two Costa<br>Rican Jatropha species (Euphorbiaceae) / Establecimiento<br>de suspensiones celulares de dos especies Jatropha<br>(Euphorbiaceae) de Costa Rica|Solís-Ramos, Laura Yesenia; Carballo, Laura<br>Miranda; Valdez-Melara, Marta.|2013|Não|
|Superação de dormência das sementese controle<br>químico de plantas de Momordicacharantia L /<br>Overcoming dormancy seeds and chemical control of<br>Momordicacharantia L. plants|Parreira, Mariana Casari; Cardozo, Nilceu<br>Piffer; Pereira, Fernada Campos<br>Mastrotti; Alves, Pedro Luis da Costa<br>Aguiar.|2012|Não|
|Factores que influyen en la embriogénesis somática in<br>vitro de palmas (Arecaceae) / Factors affecting in vitro<br>somatic embryogenesis of palms (Arecaceae)|Viñas, María; Jiménez, Víctor M.|2011|Não|
|Somatic embryogenesis and pant regeneration from<br>callus cultures of Cleome rosea Vahl|Simões, Claudia; Albarello, Norma; Callado,<br>Cátia Henriques; Castro, Tatiana Carvalho<br>de; Mansur, Elisabeth.|2010|Não|
|Effects of 2,4-D on the germination of megaspores and|Cassanego, MBB; Droste, A; Windisch, PG.|2010|Não|  
54  
|initial development of Regnellidium diphyllum Lindman<br>(Monilophyta, Marsileaceae) / Efeitos do 2,4-D sobre a<br>germinação de megásporos e o desenvolvimento inicial<br>de Regnellidium diphyllum Lindman (Monilophyta,<br>Marsileaceae)||||
|---|---|---|---|
|Enraizamento de estacas de atemoieira (Annona<br>Cherimola Mill. x A. squamosa L.) cv. Gefner submetidas a<br>tratamento lento e rápido com auxinas / Rooting of<br>atemoya (Annona cherimola Mill. x A. squamosa L.) cv.<br>Gefner cuttings subjected to slow and fast treatment<br>with auxins|Ferreira, Gisela; Ferrari, Tainara Bortolucci.|2010|Não|
|Efeito de diferentes reguladores de crescimento na<br>regeneração in vitro de pau-rosa (Aniba rosaeodora|Jardim, Lyana Silva; Sampaio, Paulo de<br>Tarso Barbosa; Costa, Suely de|2010|Não|
|Ducke) / Effect of differents growth regulators in vitro<br>propagation of Aniba rosaeodora Ducke|Souza; Gonçalves, Cláudia de Queiroz<br>Blair;Brandão, Hélio Leonardo Moura.|||  
##### **Quadro IV.3.2.3.** Consideração sobre a utilização dos artigos resultantes da busca sistemática no site Cochrane Library, para as perguntas PICO de Tratamento do Capítulo 4 – 2,4D.  
|**3a**|Urinary alkalinisation for acute chlorophenoxy herbicide<br>poisoning|Darren M Roberts, Nick Buckley|2007|Sim|
|---|---|---|---|---|  
55

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
##### **ANEXO IV.4.1 – DIAGNÓSTICO E ABORDAGEM INICIAL**  
Após a busca exploratória sobre o atendimento inicial e diagnóstico de intoxicações por 2,4-D, optou-se por não utilizar a revisão sistemática como metodologia para esse item porque as recomendações encontradas são aplicáveis a todos os tipos de agrotóxicos, sendo, em sua maioria, pontos de boa prática, os quais foram também apresentados no Capítulo 1 das presentes diretrizes. **Quadro V. 4.1.1** Síntese de evidências para o diagnóstico e abordagem inicial de intoxicações por 2,4-D.  
##### **ANEXO IV.4.2 – TRATAMENTO**  
Após a busca exploratória sobre o tratamento de intoxicações por 2,4-D, poucos artigos emergiram, sendo que a maioria deles já estavam relacionados ao diagnóstico e atendimento inicial. Optou-se, portanto, por não utilizar a revisão sistemática como metodologia para esse item porque as recomendações  
56  
encontradas são aplicáveis a todos os tipos de agrotóxicos, sendo, em sua maioria, pontos de boa prática, os quais foram apresentados nos outros capítulos das presentes diretrizes  
**Quadro IV.4.2.1:** Síntese de evidências para os tratamentos utilizados em pacientes com intoxicação aguda por agrotóxicos (não especifico para 2,4-D)  
**Quadro IV.4.1:** Síntese de evidências da busca sistemática – Capítulo 2,4D – diagnóstico  
|**REFERÊNCIA**|**DELINEAM.**|**PICO**|**DESFECHO**|**TIPO DE SINTOMAS/**<br>**ANÁLISES**|**EVIDÊNCIAS DO ARTIGO**|
|---|---|---|---|---|---|
|Lerro et al., 2017|Longitudinal (EUA)||Estresse<br>oxidatvo|Detecção<br>de<br>marcadores<br>de<br>estresse oxidatvo na<br>urina (crônico)|Utilizaram, no estudo, indvíduos produtores de milho e um<br>grupo controle não agrícola para examinar o impacto da<br>exposição aos herbicidas atrazine e ao ácido 2,4-<br>diclorofenoxiacético (2,4-D) nos marcadores de estresse<br>oxidatvo. O estudo foi conduzido nos**EUA**.<br>225 amostras de urina foram coletadas durante cinco<br>períodos agrícolas (pré-plantio, plantio, crescimento,<br>colheita, entressafra) para 30 agricultores que aplicaram<br>pesticidas ocupacionalmente e 10 controles que não fizeram;<br>todos eram homens não-fumantes com idades entre 40 e 60<br>anos.|  
57  
|||||Foram definidos cinco períodos de estudo: pré-plantio (T1,<br>baseline), plantio (T2), cultvo (T3, T4), colheita (T5) e<br>entressafra (T6).<br>**Como resultado do estudo, o 2,4-D pode estar associado ao**<br>**estresse oxidatvo devido a aumentos modestos no 8-**<br>**hydroxy-2′-deoxyguanosine (8-OHdG), um marcador de**<br>**dano oxidatvo ao DNA, e 8- isoprostaglandin-F2α (8-**<br>**isoPGF), um produto da peroxidação lipoprotéica, por**<br>**exposição recente ao 2,4-D.**|
|---|---|---|---|---|
|Göen et al., 2016|Não é escopo|Análise<br>de<br>exposição<br>a<br>agrotóxicos por<br>meio da dieta||Análise de dieta orgânica e exposição a agrotóxicos.<br>O estudo confirma que uma intervenção de dieta orgânica<br>resulta em menor exposição considerável a agrotóxicos<br>organofosforados e piretróides.|
|Venners et al., 2017|TransVersal<br>(Canadá)|Detecção<br>2,4D<br>na<br>urina<br>de<br>adultos<br>e<br>crianças|Análise<br>urina<br>para<br>biomonitora-mento|Estudo realizado em Abril e Junho de 2009 (Canadá). O<br>estudo piloto foi feito em quatro municípios na Colúmbia<br>Britânica, Canadá - dois municípios que proibiam o uso de<br>agrotóxicos para uso doméstico (Vancouver e Port Moody) e<br>dois que não proibiam (Richmond e New Westminster).<br>Nesse estudo, utilizaram as concentrações urinárias de ácido<br>2,4-diclorofenoxiacético (2,4-D) como indicador de exposição<br>ao herbicida.<br>Foram<br>recrutadas<br>10<br>residências<br>por<br>município.<br>Os participantes adultos receberam copos de coleta de urina<br>e foi solicitado para coletar a urina no dia seguinte, quando<br>eles e seus filhos planejassem ficar dentro dos limites de seu<br>município. Tanto a criança como o adulto cuidador<br>forneceram duas amostras de urina do mesmo dia: uma<br>primeira matinal e outra recolhida aqualquer hora da tarde.|  
58  
|Amostras colhidas do aspirador de pó da residência também<br>foram levadas para análise.|
|---|
|As três medidas de 2,4-D foram: concentrações na urina de<br>cuidadores adultos, urina de crianças e em pó do aspirador<br>doméstico.|
|Para quase todos os determinantes hipotéticos, houve pouca<br>diferença entre os municípios. A exceção foi o consumo de<br>alimentos orgânicos. Metade dos domicílios em Vancouver<br>consumiu cerca de 50% de alimentos orgânicos, mas apenas<br>20% em New Westminster, 10% em Port Moody e 0% em<br>Richmond (Valor exato de teste de Fisher = 0,04). Cinco dos<br>40 agregados familiares relataram nunca ter usado<br>herbicidas; no entanto, nenhum os utilizou nos últimos 7 dias<br>antes da coleta de urina. Ingredientes atvos em produtos<br>anteriormente usados incluíram ácido acético (três<br>domicílios), dicamba / MCPA (um domicílio), 2,4-D /<br>mecoprop-P/dicamba (um domicílio) e não especificado (dois<br>domicílios).<br>As concentrações urinárias de 2,4-D para os participantes<br>estavam bem abaixo das doses Equvalentes de referência de<br>biomonitoramento definidas pela US-EPA (BERfD = 200 µg<br>2,4-D / l de urina) ou Health Canada (BERfD = 700 µg 2,4 -D /<br>l<br>de<br>urina).<br>A maior concentração de 2,4-D na amostra foi de 19μg 2,4-D<br>/ l de urina. Quando a urina de adultos e crianças foram<br>analisadas em conjunto, o logaritmo natural do 2,4-D foi<br>significatvamente associado a uma dieta >50% de alimento<br>orgânico(β= −0,6(0,3) μg/l,P = 0,05).|  
59  
|||||O estudo concluiu que os alimentos são uma rota importante<br>de exposição ao 2,4-D, especialmente quando exposições<br>agudas de aplicações de agrotóxicos estão ausentes.|
|---|---|---|---|---|
|Aylward e Hays, 2015|Análise<br>laboratorial<br>de<br>amostras<br>em<br>context de análise<br>longitudinal|Detecção<br>2,4D<br>urinário|Biomonitora-mento|Esta avaliação baseia-se em uma avaliação de toxicidade<br>atualizada da US EPA (USEPA, 2013), uma avaliação<br>atualizada das taxas de excreção de fluxo urinário e<br>creatinina usadas para calcular Valores de Equvalente de<br>Biomonitoramento (BE) (baseado na avaliação de Aylward et<br>al., 2015) e recente representatvidade da população pelos<br>dados de biomonitoramento urinário para 2,4-D do_Canadian_<br>_Health Measures SurVey_(CHMS).<br>Os dados de biomonitoramento de 2,4-D urinário estão<br>disponíveis para a população geral dos EUA, para agricultores<br>e suas famílias, e em Vários outros contextos; esses dados<br>foram preViamente reVisados (Aylward et al., 2010; Hays et<br>al., 2012). Dois grandes conjuntos de dados estavam<br>disponíveis para a população geral dos EUA e um terceiro<br>conjunto de dados para o Canadá. Esses dados de<br>biomonitoramento urinário podem ser comparados aos<br>Valores de BE correspondentes à dose de referência US-EPA<br>para fornecer uma avaliação dos níveis relatvos de exposição<br>na população geral em comparação com os níveis<br>identificados pelo processo de avaliação de risco, como<br>toleráveis ou seguros para a exposição da população geral.<br>A comparação de dados em crianças e adultos não revela<br>diferenças notáveis entre as concentrações urinárias nos<br>conjuntos de dados da população dos EUA e Canadá.<br>O Valor de referência base crônico atualizado da US- EPA de<br>0,21 mg/kg-d resulta em Valores atualizados de BE de 10.500<br>e 7.000 mg/Lpara adultos e crianças,respectvamente. A|  
60  
|||||comparação dos dados representatvos da população atual<br>com esses Valores de BE mostra que as concentrações de<br>biomarcadores<br>populacionais<br>são<br>mais<br>de<br>5000<br>Vezesinferiores aos Valores de BE correspondentes à<br>atualização os Valores de referência da US- EPA. Essa<br>avaliação de risco baseada em biomonitoramento apoia a<br>conclusão de que os padrões atuais de uso nos EUA e Canadá<br>resultam em exposições incidentais na população em geral,<br>que os autores consideram insignificantes, no contexto da<br>atual avaliação de risco do 2,4-D.|
|---|---|---|---|---|
|||||(**Este manuscrito foi preparado sob um contrato do Grupo**<br>**de Trabalho da Indústria II sobre Dados de Pesquisa em 2,4-**<br>**D**.)|
|Styka e Butler, 2015|Longitudinal|Relato sobre a<br>coleta<br>das<br>amostras|Relato sobre a coleta<br>das<br>amostras<br>–<br>possibilidades<br>de<br>utilização|Esse estudo dervou do “Air Force Health Study”, EUA e<br>consiste na avaliação da saúde de militares após exposição a<br>agrotóxicos. Informações a respeito dos exames físicos,<br>questionários e prontuários médicos, originadas do Instituto<br>de<br>Medicina<br>da<br>Força<br>Aérea<br>americana,<br>foram<br>eletronicamente armazenadas em uma base de dados para a<br>pesquisa. Esses dados da coorte da Ranch Hand e os bio-<br>espécimes tveram uma influência particular na compreensão<br>científica da farmacocinética da dioxina e sua meia-Vida em<br>humanos, porque existem poucos estudos longitudinais que<br>coletaram amostras de uma população exposta.<br>Artigo apenas relata a importância dessa coleta e do banco<br>de dados,não há resultados.|
|Mannetje et al., 2016|Longitudinal<br>-<br>NoVa Zelândia|Não é escopo<br>Estudo crônico|Não é escopo<br>Estudo crônico|O objetvo desse estudo foi quantificar as concentrações<br>séricas de 2,3,7,8-tetraclorodibenzo-p-dioxina (TCDD) e<br>compostos semelhantes à dioxina em ex-trabalhadores de|  
61  
|||||produção de herbicida e bombeiros, 20 anos após a produção<br>de 2,4,5-T cessar.<br>O estudo coletou amostras de sangue em 244 indvíduos que<br>participaram do estudo de coorte original. Foram<br>selecionados os indvíduos que haviam trabalhado na<br>produção desses agrotóxicos, por pelo menos 1 mês, entre<br>1969 a 1984. A coleta foi realizada entre 2007 e 2008.|
|---|---|---|---|---|
|Morgan 2015|TransVersal<br>dervado de uma<br>coorte|Níveis urinários<br>de 2,4D|Monitoramento<br>de<br>populações - Crônico<br>**Não é escopo**|Os objetvos desse trabalho foram quantificar os níveis<br>urinários de ácido 2,4-diclorofenoxiacético (2,4-D), 3,5,6-<br>tricloro-2-piridinol (TCP), ácido 3-fenoxibenzóico (3 -PBA) e<br>pentaclorofenol (PCP) em 121 adultos durante um período<br>de monitoramento de 48h e para examinar as associações<br>entre factores sociodemográficos e de estilo de Vida<br>seleccionados e os níveis urinários de cada biomarcador de<br>pesticidas. Adultos, com idades entre 20 e 49 anos, foram<br>recrutados em seis condados de Ohio (OH) em 2001. Os<br>participantes coletaram de quatro a seis amostras de urina e<br>preencheram questionários e agendas em casa durante um<br>período de monitoramento de 48 horas.<br>A coorte do estudo consistiu em 127 crianças pré-escolares e<br>seus 127 cuidadores primários adultos que foram recrutados<br>em seis condados, incluindo Cuyahoga, Defiance, Fayette,<br>Franklin, Hamilton e Licking (Ohio - EUA). Nesta coorte, 69<br>cuidadores adultos permaneceram em casa com seus filhos|  
62  
durante o dia, enquanto 58 cuidadores adultos foram ao trabalho e deixaram seus filhos em creches licenciadas durante o dia. Para os adultos, a amostragem ocorreu em sua residência durante um período de monitoramento de 48h entre abril e noVembro de 2001. Os adultos coletaram suas próprias amostras de urina e completaram questionários durante o período de monitoramento. Os biomarcadores de agrotóxicos foram detectados em ≥89% das amostras de urina, com exceção do 3-PBA (66%). Níveis urinários medianos de 2,4-D, TCP, 3-PBA e PCP foram 0,7, 3,4, 0,3 e 0,5 ng/mL, respectvamente. Além disso, 55% das amostras de urina, dos adultos, tinham níveis detectáveis de todos os quatro biomarcadores de agrotóxicos. Os níveis medianos de TCP na urina (3,4 ng / mL) foram pelo menos quatro Vezes maiores em comparação com os níveis urinários medianos de 2,4-D, 3-PBA e PCP (≤ 0,7 ng/mL). Os Valores máximos de 2,4-D urinário, TCP, 3-PBA e PCP, nesses adultos, foram 8,1, 30,5, 4,9 e 3,7 ng/mL, respectvamente. Para as amostras de urina ajustadas com creatinina, as concentrações medianas de TCP na urina (2,6 ng/mL) foram também pelo menos cinco Vezesmaiores do que as concentrações medianas de 2,4-D, 3-PBA e PCP (<0,5 ng/mg). Concentrações urinárias de 2,4-D foram significatvamente maiores (p = 0,025) em adultos joVens (GM = 0,80 ng / mL)  
63  
|||||em comparação com adultos mais Velhos (GM = 0,54 ng /<br>mL).<br>Os preditores: consumo de “snacks”, tempo em casa e níveis<br>de creatinina foram preditores significatvoss (p<0,05) para<br>maiores concentrações urinárias de 2,4D em adultos, e a raça<br>foi um preditor marginalmente significante (p = 0,093). Em<br>particular, os níveis ajustados de 2,4-D urinário foram<br>significatvamente maiores (p = 0,043) em participantes que<br>consumiram snacks doces ou salgados ≥2 vezes em<br>comparação com <2 vezes durante o período de<br>monitoramento de 48h. Os adultos também tveram níveis<br>significatvamente mais altos (p = 0,038) para aqueles que<br>gastaram <3 h em comparação com ≥3 h fora de casa durante<br>o período de monitoramento. Além disso, os níveis de 2,4D<br>foram marginalmente maiores (p = 0,093) em participantes<br>negros comparados aos participantes brancos.|
|---|---|---|---|---|
|Berling et al., 2015|Relato<br>de<br>Caso<br>(Austrália)|Mortalidade|Sinais e sintomas após<br>ingestão de MCPA|Relatou-se um caso fatal de um senhor de 37 anos que<br>ingeriu 200mL de um herbicida de co-formulação Ácido 2-<br>metil-4-clorofenoxiacético (MCPA) / bromoxynil. (“Bin-die”<br>200 g/l de MCPA e 200 g/l de 3,5-dibromo-4-<br>hidroxibenzonitrila [bromoxinil] misturado com um solvente<br>de hidrocarboneto).<br>Embora tenha chegado ao hospital dentro de 2h após a<br>ingestão intencional e seu estado clínico estvesse bem no<br>exame inicial,opacientepiorou drasticamente até 18h após.|  
64  
<mark>No momento da entrada do pronto-atendimento que ele tinha náuseas, Vômitos e diarreia e foi administrado fluido intraVenoso.</mark>  
<mark>Na chegada, estava alerta e diaforético, com frequência cardíaca (FC) de 95 batimentos por minuto e pressão arterial (PA) de 140/102 mmHg e frequência respiratória (FR) de 22 respirações por minuto. Com base na grande ingestão do produto, e não pela clínica, ele foi internado na unidade de terapia intensva para observaçãoe alcalinização urinária. Ele estava levemente agitado e recebeu 10 mg de diazepam por Via oral. Os exames de sangue mostraram uma contagem de células brancas 18x109/l (4–11x109/l), neutrófilos 15,4x109/L. A creatinina era de 103 mmol/l (64–104 mmol/l). Cerca de 8h após a ingestão, tornou-se diaforético e taquipneico, frequência respiratória (FR): 30, mas não estava hipóxico nas saturações periféricas de oxigênio. Ele ficou mais agitado apesar de uma administração adicional de 15 mg de diazepam por Via oral. Sua FR aumentou gradualmente para 36 às 12 h pós-ingestão. Manteve suas saturações de oxigênio a 100% no ar ambiente, apesar do baixo PO2 nos gases sanguíneos. A gasometria arterial mostrou pH 7,48; pCO2, 33 mmhg; pO2, 51 mmhg e excesso de base, 1,6 mmol / l. A radiografia de tórax foi normal e não houve evidência de aspiração. A alcalinização urinária foi cada vez menos eficaz e o pH urinário caiu para 7,0. A contagem de células brancas e neutrófilos aumentaram e a creatinina subiu para 112 µmol/L. Após 16h ele foi intubado e permaneceu taquicárdico, diaforético e desenvolveu hipertermia</mark> <u><mark>(40°C)</mark></u> <mark>com</mark>  
65  
|||||hipotensão. A temperatura chegou a atingir 42,5<sup>o</sup>C e após<br>20h da ingestão, sofreu uma parada cardíaca sistólica, da<br>qual não pôde ser ressuscitado.<br>Duas horas após a ingestão, a concentração sérica de MCPA<br>foi de 83,9mg/ml e a concentração de bromoxinil foi de<br>137µg/ml. Pouco antes da morte, 19h após a ingestão, a<br>concentração de MCPA foi de 100 µg/ml e a concentração de<br>bromoxinil foi de 78,8 µg/ml.|
|---|---|---|---|---|
|Taneepanichskul<br>et<br>al.,<br>2014|Não é escopo|||Estudo não aborda agrotóxicos fenoxiacéticos, apenas<br>organofosforados.|
|Lewis et al., 2014|Longitudinal|Biomarcadores<br>urinários<br>de<br>exposição|Detecção urinária de<br>agrotóxicos|Estudo realizado em 54 mulheres grávidas, em Porto Rico,<br>mensurou a concentração urinária de dversos elementos<br>encontrados em repelente de insetos, incluindo 2,4D.<br>Trata-se de uma parte de um estudo de coorte prospectiva<br>em andamento na região norte de Porto Rico, projetada para<br>avaliar a possível relação entre exposições ambientais tóxicas<br>e risco de parto prematuro e outros resultados adVersos da<br>graVidez. Houve a análise de 152 amostras de urina, para<br>esse estudo.<br>O estudo calculou as distribuições das concentrações de<br>biomarcadores e as comparou com aquelas de mulheres em<br>idade reprodutva, da população geral dos EUA, quando<br>disponíveis. Também foram coletados dados demográficos,<br>consumo de frutas selecionadas, Vegetais e leguminosas nas<br>últimas 48h, e questões relacionadas a pragas, e associações<br>entre essas VariáVeis e concentrações de biomarcadores.|  
66  
<mark>Como resultado, obteVe-se que as concentrações urinárias de percentil 95 do DEET, 3-PBA, trans-DCCA e</mark> **<mark>2,4-D foram menores do que as mulheres em idade reprodutva no continente americano</mark>** <mark>, enquanto concentrações urinárias de percentil 95 de 4-F-3-PBA cis-DBCA e 2,4,5-T foram semelhantes. Não houve associações estatisticamente significatvas entre as concentrações urinárias dos analitos e o tempo de coleta de urina (manhã Vs. tarde) ou a idade da mulher (<24</mark> _<mark>Versus</mark>_ <mark>≥24 anos).</mark>  
As mulheres que tinham maior probabilidade (p <0,05) de ter maiores concentrações urinárias de biomarcadores de agrotóxicos possuíam menor escolaridade (DCBA e transDCCA), estavam desempregadas (DHMB) ou casadas **(2,4-D - (OR: 3.5, 95% CI: 1.5, 8.4)** ). As mulheres que consumiram couVe (OR: 5,9, 95% CI: 1,3, 26,7) ou espinafre (OR: 4,4, 95% CI: 1,1, 17,9) nas últimas 48h apresentaram maior probabilidade de ter concentrações urinárias detectáveisde **2,4-D** em relação às mulheres que não consumiram esses alimentos no mesmo período. O consumo de couVe, espinafre e, potencialmente, outras Verduras folhosas podem ser determinantes importantes da exposição a certos pesticidas.  
<mark>Como conclusão, os autores dizem precisar de mais pesquisas para entender quais aspectos dos biomarcadores identificados leVariam a uma maior exposição, e se a exposição durante a graVidez está associada à efeitos adVersos à saúde.</mark>  
67  
|Hwang et al., 2015|Relato de caso e<br>análise<br>_in_<br>_Vitro_<br>(Coreia)|Morbidade<br>por<br>intoxicação<br>MCPA|Sinais e sintomas|Caso de intoxicação por Ácido (4-cloro-2-metilfenoxi) acético<br>(MCPA).<br>Tratou-se de uma mulher de 76 anos que apresentou<br>inconsciência, choque e insuficiência respiratória após<br>ingestão de 100 mL de herbicida MCPA (apresentação no<br>pronto atendimento após 3h da ingestão). O artigo também<br>analisou se o surfactante na formulação foi o responsáVel<br>químico pelos sintomas tóxicos nessa paciente.<br>A chamada "síndrome do surfactante" na intoxicação aguda<br>por agrotóxico é um sintoma que compreende hipotensão,<br>inconsciência e falha respiratória, semelhante aos sintomas<br>do caso apresentado no artigo.<br>Na chegada, houve parada respiratória com consciência<br>semicomatosa. A pressão arterial foi de 90/60 mm Hg. O<br>tratamento imediato foi aplicado, incluindo intubação<br>traqueal e Ventilação mecânica. A produção de urina caiu<br>abaixo de 10 mL/h e houve acidose metabólica. A terapia de<br>substituição renal contínua (CRRT) foi iniciada e também se<br>utilizou noradrenalina. Além disso, injetou-se, por Via<br>intraVenosa ,500 mL de produto de emulsão lipídica a 20%<br>durante 2 h, seguidos de uma dose de manutenção de 1000<br>mL nas 24 h seguintes.<br>No terceiro dia de internação, a pressão arterial da paciente<br>era de 120/80 mmHg sem agente inotrópico e a respiração<br>havia se recuperado. A extubação traqueal também foi<br>realizada no terceiro dia de internação e a consciência Voltou<br>ao normal noquarto dia.(Ver tabela 1 do artigopara mais|
|---|---|---|---|---|  
68  
||||parâmetros diagnósticos – ao final desse arquvo)<br>Após o relato de caso, o estudo realizou análise in Vitro do<br>surfactante presente no herbicida MCPA. De acordo com os<br>resultados, o ingrediente “inerte” PTE (polyoxyethylene<br>tridecyl ether) é mais tóxico que o ingrediente atvo MCPA. O<br>TEP regulou positvamente as expressões de genes implicados<br>em Várias Vias de dano celular, particularmente a resposta<br>inflamatória (_in Vitro_).|
|---|---|---|---|
|Tennakoon et al., 2014<br>Relato de Caso|Identificação de<br>MCPA em urina|Sintomas<br>de<br>enVenenamento|Trata-se de estudo de análise forense de detecção de<br>composto (Sri Lanka).<br>Estudo analisou a identificação do Ácido 4-cloro-2-metil<br>fenoxiacético (MCPA), devido a uma tentatva de assassinato<br>a partir da utilização desse composto, em água potáVel.<br>Uma família composta por quatro membros, incluindo duas<br>crianças e uma mulher grávida, era suspeita de ser<br>enVenenada por adição de composto químico em seu tanque<br>de armazenamento de água.<br>A identificação de MCPA na urina e na água com suspeita de<br>estar enVenenada foi realizada por HPLC e confirmada por<br>cromatografia gasosa (GC-MS). Neste caso, a presença de<br>MCPA na amostra de urina, coletada quatro dias após o<br>incidente, foi confirmada pela GC-MS e encontrou-se uma<br>concentração de 0,83 mg/ml. A MCPA não foi identificada nas<br>amostras de urina coletadas após 13 dias em outros três<br>pacientes. A amostra de água retirada do tanque de<br>armazenamento suspeito continha 101 mg/ml de MCPA,|  
69  
|||||enquanto que nas amostras de controle, não foi detectado<br>esse composto. Os resultados desse artigo mostraram que o<br>HPLC combinado com GC-MS é adequado para análise<br>forense de MCPA na urina.<br>Não há relato de sinais e sintomas dos enVolVidos no<br>enVenenamento.|
|---|---|---|---|---|
|Raymer et al., 2014|TransVersal|Determinação de<br>fatores de risco<br>nas casas dos<br>trabalhadores|Análise<br>de<br>inadequações<br>nos<br>cômodos da casa|O estudo faz parte de um programa de pesquisa participatva<br>baseada na comunidade que enVolVe pesquisadores da<br>Wake Forest School of Medicine, o Projeto Farmersters da<br>Carolina do Norte (EUA), Ação estudantil com trabalhadores<br>rurais e outras clínicas e organizações que atendem<br>trabalhadores rurais na Carolina do Norte. Os dados foram<br>coletados no período de junho a outubro de 2010.<br>Todos os participantes deste estudo eram trabalhadores<br>rurais do tabaco; quase todos estavam enVolVidos na<br>cobertura (remoVendo a flor do topo da planta) ou colhendo.<br>Nenhum dos participantes deste estudo era aplicador de<br>agrotóxicos.<br>As concentrações de metabólitos urinários medidos no<br>estudo foram, geralmente, maiores do que aquelas medidas<br>na população geral dos EUA.<br>Estudamos 183 campos de trabalhadores rurais migrantes no<br>leste da Carolina do Norte em 2010. Dados e amostras de<br>urina foram coletados de 371 homens. Medidas preditvas<br>incluíram Violações em seis domínios da regulamentação<br>habitacional<br>e<br>características<br>de<br>não-Violência<br>e<br>comportamentos pessoais que podem afetar os metabólitos<br>urinários.<br>Resultados - Baratas e Violações no banheiro foram preditvos<br>de aumento da exposição a piretróides e ciflutrina /<br>clorpirifos,respectvamente. A troca e o armazenamento de|  
70  
|||||roupas e calçados nos dormitórios aumentaram o número de<br>detectos para o metabólito diazinônico.<br>O herbicida 2,4-D possuiu concentração igual ou superior ao<br>limite detectáVel em 17% das amostras.<br>As únicas comparações que tveram algum níVel de<br>significância foram as concentrações de 2-Isopropil-4-metil-<br>6-hidroxipirimidina urinária com os fatores “troca de roupas<br>no quarto de dormir” (P = 0,017) e “armazenamento de<br>roupas” (P = 0,031) ou sapatos (P = 0,041) no quarto de<br>dormir.<br>**Embora**<br>**nenhum**<br>**domínio**<br>**habitacional**<br>**tenha**<br>**sido**<br>**identificado como crítico para mitigar a exposição**<br>**relacionada à moradia, deVe-se ter atenção específica à**<br>**troca de roupas e ao armazenamento de roupas e sapatos**<br>**sujos em quartos de dormir, limpeza da cozinha e**<br>**infestações de insetos.**|
|---|---|---|---|---|
|Morgan e Jones, 2013|Não é escopo|||Associação entre hábitos alimentares e concentrações de<br>biomarcadores urinários de agrotóxicos. – Não trata de<br>diagnóstico.|
|Krieg 2013|TransVersal<br>–<br>subgrupo de uma<br>coorte|Monitoramento<br>**Não é escopo**|Teste<br>neuro-<br>comportamental|O “Priority Toxicant Reference Range Study” foi parte do<br>terceiro estudo “National Health and Nutrition Examination<br>SurVey” (NHANES III) – EUA, e foi conduzido para medir as<br>quantidades de compostos orgânicos Voláteis no sangue e<br>agrotóxicos na urina, em uma amostra da população geral.<br>Os participantes eram um subgrupo do estudo maior, sendo<br>1.338pessoas,de 20 a 59 anos de idade, que se|  
71  
|||||voluntariaram para fornecer 20 mL adicionais de sangue e<br>responderam a um questionário durante o exame médico.<br>Nenhum procedimento de amostragem estatístico formal foi<br>usado para recrutar os Voluntários.<br>A análise de regressão foi utilizada para estimar e testar as<br>relações entre metabólitos de agrotóxicos urinários e<br>desempenho no teste neurocomportamental, em adultos de<br>20 a 59 anos. Os 12 metabolitos de agrotóxicos incluíam 2<br>naftóis, 8 fenóis, um ácido fenoxiacético e um piridinol.<br>**Não houve relações estatisticamente significatvas entre o**<br>**desempenho**<br>**no**<br>**teste**<br>**neurocomportamental**<br>**e**<br>**concentrações do ácido 2,4-diclofenoxiacético (2,4D).**|
|---|---|---|---|---|
|Hays et al., 2012|Descritvo<br>com<br>base em análises<br>de<br>bancos<br>de<br>dados|Comparações<br>entre dados de<br>biomonitora-<br>mento|Comparações<br>entre<br>dados<br>de<br>biomonitora-mento e<br>fatores de risco|Este estudo de caso compara as duas abordagens de<br>avaliação de risco (ingestão estimada ou dose absorVida<br>dervada<br>de<br>medições<br>externas<br>Vs.<br>base<br>de<br>biomonitoramento) para o 2,4-D.<br>Neste estudo de caso, compararam-se os coeficientes de<br>risco (HQs) calculados com base nas aValiações da exposição<br>ao consumo àquelas que resultam de estudos de<br>biomonitoramento para uma Variedade de populações e<br>situações de exposição. O HQ é um cálculo básico feito para<br>comparar as exposições ao níVel no qual nenhum efeito<br>adVerso é esperado. Agências reguladoras costumam usar o<br>HQ para transmitir conclusões de avaliação de risco.<br>Esta análise baseia-se em dados e estimatvas para a<br>exposição ao 2,4-D gerados tanto por meio de técnicas<br>conVencionais<br>de<br>estimatva<br>de<br>exposição<br>como|  
72  
|||||representadas por dados de biomonitoramento. Ambas as<br>abordagens têm sido empregadas para caracterizar<br>exposições para grupos populacionais gerais expostos<br>ambientalmente atraVés de Vestígios de resíduos em<br>alimentos ou em água, para indvíduos potencialmente<br>expostos ao 2,4-D por recente aplicação do produto<br>(indiretamente), e para pessoas com exposição ocupacional.<br>Como resultado, os HQs estimados para o limite superior das<br>exposições potenciais são, pelo menos, Várias Vezesmaiores<br>quando baseados em estimatvas de exposição externa do<br>que quando baseados em dados de biomonitoramento. Os<br>autores concluem que as comparações suportam a conclusão<br>de que as aValiações de exposição conduzidas como parte do<br>processo de registro do 2,4-D incorporam suposições<br>suficientemente conserVadoras.|
|---|---|---|---|---|
|||||**Conflito de interesse**: Os autores receberam financiamento<br>do Grupo de Trabalho da Indústria II sobre Dados de Pesquisa<br>em 2,4-D para preparar este manuscrito. Os autores tveram<br>controle total sobre o desenho, execução e apresentação dos<br>resultados das análises aqui relatadas.|
|Burns e Swaen 2012|Revisão<br>narratva<br>(Países Baixos e<br>EUA)|Efeitos à saúde<br>pela<br>exposição<br>direta ou indireta<br>ao 2,4D|Mortalidade<br>por<br>câncer, toxicidade no<br>sistema<br>reprodutor,<br>genotoxicidade<br>e<br>neurotoxicidade|Trata-se de uma revisão qualitatva epidemiológica da<br>literatura, sobre o herbicida ácido 2,4-diclorofenoxiacético<br>(2,4-D) e efeitos à saúde.<br>Na população geral, a exposição ao 2,4-D está próxima do<br>níVel de detecção. Entre os indvíduos com exposição<br>indireta, os níveis de 2,4-D na urina também foram muito|  
73  
|||||baixos, exceto em indvíduos com contato direto com o<br>herbicida. A exposição ocupacional, onde a exposição é<br>maior,<br>correlacionou-se<br>positvamente<br>com<br>os<br>comportamentos relacionados às atvidades de mistura,<br>carregamento do produto (loading), processo de aplicação e<br>uso de equipamentos de proteção pessoal.|
|---|---|---|---|---|
|||||De acordo com as conclusões desse estudo, a maioria das<br>publicações não possui precisão e os resultados não são<br>replicados em outros estudos independentes. De acordo com<br>os autores, o biomonitoramento e os dados epidemiológicos<br>não forneceram evidências conVincentes ou consistentes<br>para qualquer efeito adVerso crônico do 2,4-D em humanos.<br>**Conflito de interesse:**A Dow Chemical Company é fabricante<br>de 2,4-D. Os autores são os únicos responsáVeis pela escrita<br>e pelo conteúdo do artigo, mas o trabalho foi parcialmente<br>apoiado pelo Grupo de Trabalho da Indústria II sobre Dados<br>de Pesquisa em 2,4-D.<br>**Instituições dos Autores:**Departamento de Epidemiologia da<br>Dow Chemical Company, Midland, MI, EUA e Departamento<br>de<br>Epidemiologia,<br>Dow<br>Benelux,<br>B.V.,<br>Terneuzen<br>(Netherlands)|
|Jurewicz et al., 2012|TransVersal<br>(Polônia)|Monitoramento<br>dos<br>níveis<br>de<br>2,4D e MCPA em<br>esposas<br>de<br>agricultores|Análise urinária de<br>2,4D e MCPA em<br>exposição indireta|O objetvo do estudo foi aValiar a exposição ambiental a dois<br>agrotóxicos: ácido 2-metil-4-clorofenoxiacético (MCPA) e<br>ácido 2,4-diclorofenoxiacético (2,4-D) entre as esposas de<br>agricultores, não diretamente enVolVidas no processo de|  
74  
<mark>pulVerização. Foram aValiadas 24 mulheres em agregados familiares da zona rural de Vovodia de Łódż na Polónia. Durante o período de estudo, 50 pulVerizações foram realizadas na zona rural, usando MCPA, e 13 pulVerizações utilizaram o 2,4-D. Todas as participantes do estudo completaram um questionário auto-administrado e coletaram amostras de urina. As mulheres foram solicitadas a coletar 3 amostras de urina biológica: pela manhã, antes da pulVerização (amostra A), à noite, após a pulVerização (amostra B), e na manhã do dia seguinte (amostra C). A determinação de agrotóxicos na urina foi realizada por cromatografia líquida de alta eficiência. No caso dos dois ingredientes atvos, o número de amostras de urina com o níVel de agrotóxico acima do limite de detecção (LOD) aumentou de 30% nas amostras A para 45% nas amostras B e C. Os níveis médios de herbicidas aumentaram da amostra A (2,8 ng/g de creatinina) para a amostra B (6,0 ng/g de creatinina). O Valor médio da amostra C foi de 4,0 ng/g de creatinina. No grupo de mulheres com níveis detectáveisde pesticidas, o níVel de</mark> **<mark>MCPA</mark>** <mark>encontrado na urina foi de 2,3 ± 4,2 ng / ml na amostra A, 3,9 ± 5,6 ng / ml na amostra B e 3,3 ± 5,2 ng / ml na amostra C.</mark>  
75  
|||||O níVel médio de**2,4-D**encontrado na urina das mulheres<br>(para mulheres com níVel detectáVel de pesticidas) foi de 3,0<br>± 2,4 ng / ml na amostra A, 2,0 ± 0,5 ng / ml na amostra B e<br>7,9 ± 10,5 ng / ml na amostra C.<br>No caso de 64% das pulVerizações, as roupas de trabalho<br>foram laVadas imediatamente após a pulVerização, pelas<br>esposas dos agricultores. Em 56%, as roupas foram laVadas<br>em máquina de laVar roupa, enquanto em 54% foram<br>laVadas à mão.<br>As medições de MCPA e 2,4-D na urina, em 3 momentos<br>diferentes durante a pulVerização são um bom método para<br>aValiar a exposição a esses agrotóxicos, porque eles possuem<br>relatva curta duração, com uma meia-Vida de 12-72h. Este<br>estudo mostrou que as esposas dos agricultores, não<br>diretamente enVolVidas no processo de pulVerização, são<br>expostas aos agrotóxicos usados em suas fazendas, o que<br>indica que há uma transferência desses produtos do campo<br>para o ambiente doméstico.|
|---|---|---|---|---|
|Park et al., 2011|Série de Casos|Mortalidade|Testes laboratoriais e<br>descrição de 17 casos<br>de<br>ingestão<br>intencional<br>de<br>agrotóxicos|Neste estudo, foi reVisado uma série de casos agudos de<br>intoxicação por herbicida análogos à auxina, tratados em<br>hospital na Coreia. Foram incluídos 17 pacientes com<br>intoxicação aguda por ingestão intencional, identificados a<br>partir dos registros médicos do Instituto de Intoxicação por<br>Agrotóxicos do Hospital Soonchunhyang Cheonan (República<br>da Coreia) entre setembro de 2006 e maio de 2011.|  
76  
<mark>Dos 17 pacientes, 12 pacientes ingeriram o ácido 3,6-dicloro2-metoxibenzóico (dicamba); 3 pacientes, ido [(3,5,6tricloro-2-piridinil) oxi] acico (triclopir); 1 paciente, ingeriu complexo de ácido 2-metil-4-clorofenoxiacético (MCPA) e 3- isopropil-1H-2,1,3- benzotiadiazin-4 (3H) -ona-2,2-dióxido (Bentazona); e 1 paciente, ácido (rs)-2- (4-chloro-0tolyoxy)propionico (mecoprop).</mark>  
<mark>A modalidade de tratamento foi sintomática: a laVagem gástrica foi empregada quando o paciente foi internado em até 2 horas após a ingestão. Também foi realizada uma sessão de hemodiálise (HD) e uma de hemoperfusão (HP), seguida por administração intraVenosa de líquidos. Respirador e oxigênio foram utilizados quando necessário. Quando ocorreu insuficiência hepática e renal, foram tratados por cuidados de suporte. O uso de diálise e perfusão é uma parte do protocolo do hospital, e se desenvolveu devido à experiência com agrotóxicos tóxicos, e os autores reconhecem que esta conduta não é um padrão geral de tratamento.</mark>  
<mark>Não foi obserVada relação significatva entre a quantidade de dicamba ingerida e o desfecho clínico O número de pacientes nos outros grupos foi muito baixo para a análise estatística sobre a ingestão. Entre 17 pacientes, 1 paciente (caso 17) morreu 36h após a admissão, e 12 pacientes tveram alta do hospital sem qualquer queixa específica no dia 7, após receber tratamento conserVador. Os outros quatro pacientes sofreram algumas complicações e foram tratados por mais de uma semana. O</mark>  
77  
<mark>caso 3 ingeriu 300 mL de dicamba, sofreu pneumonia e paralisia do íleo durante a admissão. Este paciente foi tratado com antibióticos e nutrição parenteral e recebeu alta hospitalar no dia 28. O caso 9 chegou à sala de emergência após ingestão de 200 mL de dicamba. Durante a internação, teVe infecção relacionada ao cateter e foi administrado cefazolina, tendo alta hospitalar no dia 10. O caso 11 ingeriu 300 mL de dicamba. No teste laboratorial inicial, níveis anormalmente eleVados de aminotransferase (AST, 235 UI / L; ALT, 169 UI / L) e anticorpo anti-Hepatite C (anti-HCV) positvo foram relatados. O caso 12 mostrou hematúria microscópica na urinálise, mas recebeu alta hospitalar no dia 8. O caso fatal 17 era um indvíduo alcóolatra e ele foi leVado ao pronto-socorro em estado de intoxicação alcoólica e por mecoprop (havia frasco Vazio ao lado do corpo, de Volume 500mL). As características clínicas na admissão foram inconsciência, hipotensão, insuficiência respiratória e rabdomiólise. As concentrações séricas de álcool e ácido lático foram de 172 mg/dL (referência normal: 0-10 mg/dL) e 51,6 mg/dL (referência normal, 0 mg/dL), respectvamente.</mark> **<mark>Tabela 1: Achados laboratoriais (média, IC)</mark>** <mark>WBC (no./μL) 14,779.0 8224.7 [1037, 31440] Hb (g / dL) - 14.7 1.8 [10.7, 17.2] Na (mEq / L) - 142.8 3.7 [135, 150] Cloreto (mEq / L) - 104.4 5.1 [93, 112] K (mEq / L) - 4.1 0.8 [3.1, 6.7] Glicemia em jejum (mg / dL) 149.1 90.0 [64, 451] Proteína (g</mark> <u><mark>/ dL) - 7.0 0.7 [5.4, 8.7]</mark></u>  
78  
|||||Albumina (g / dL) - 4.3 0.5 [3.3, 5.1]<br>AST (IU / L) 54.4 60.8 [16, 235]<br>ALT (UI / L) 37.7 36.2 [8, 169]<br>Colesterol, total (mg / dL) 251.1 241.7 [23, 891]<br>Triglicérido (mg / dL) 151.2 71.8 [17.6, 313]<br>BUN (mg / dL) 16.6 7.6 [4.1, 36.6]<br>Creatinina (mg / dL) 1.3 0.7 [0.6, 3.2]<br>Análise de gasometria arterial<br>pH 7.375 0.1 [7.080, 7.487]<br>PCO2 (mmHg) 34.6 7.6 [21.4, 50.4]<br>PO2 (mmHg) 148.5 88.3 [31.7, 148.5]<br>HCO3 (mmol / L) 19.9 5.7 [6.6, 28.3]<br>Em conclusão, os autores obserVaram que a toxicidade<br>humana por auxina sintética parece ser benigna, com<br>exceção à ingestão de grandes quantidades, inclusve quando<br>associada com a ingestão de álcool.|
|---|---|---|---|---|
|Belsey et al., 2011|**In Vitro – não é**<br>**escopo**||**In Vitro – não é**<br>**escopo**|<br>_In Vitro_(Franz diffusion cell)|
|Baharuddin et al., 2011<br>(não disponíVel)|TransVersal|Análise do clima<br>na exposição a<br>agrotóxicos|**Não é escopo**|O artigo inVestigou a influência do clima na exposição, bem<br>como problemas de saúde documentados, comumente<br>relacionados à exposição a agrotóxicos. Estudo conduzido na<br>Malásia.<br>Os resultados mostraram que, embora a temperatura e a<br>umidade tenham afetado a exposição, a Velocidade do Vento<br>teVe o impacto mais forte na exposição a pesticidas via<br>inalação. No entanto,ograu de exposição a ambos os|  
79  
|||||herbicidas por inalação foi inferior aos limites de exposição<br>permitidos pelo Instituto Nacional de Segurança e Saúde<br>Ocupacional dos Estados Unidos (NIOSH).<br>Os autores concluem que o tipo de equipamento de<br>pulVerização, o uso de roupas de proteção adequadas e a<br>aderência às práticas corretas de pulVerização foram os<br>fatores mais importantes que influenciaram o grau de<br>exposição a pesticidas entre aqueles que aplicam pesticidas.|
|---|---|---|---|---|
|Zhang et al., 2011<br>(não disponíVel)|TransVersal (EUA)|Dosimetria<br>de<br>2,4D|Não é escopo|O estudo comparou as doses de 2,4D, em 8 aplicadores,<br>medidas por biomonitoramento e por coleta aguda de urina.<br>Os resultados sugerem que a dosimetria passva para o 2,4-D<br>superestimou consistentemente a dosagem medida usando<br>biomonitoramento por um fator de 2-3 Vezes.|
|Aylward e Hays, 2011|Não é escopo|||Este estudo analisou os dados de biomonitoramento e de<br>estudos de toxicidade e farmacocinética_in Vvo_para<br>examinar a releVância fisiológica das concentrações testadas<br>e respondidas_in Vitro_para cinco produtos químicos:<br>triclosan,<br>ácido<br>2,4-diclorofenoxiacético,<br>ácido<br>uorooctanóico, monobutyl phthalate e mono - 2 (etilhexil)<br>ftalato.|
|Blair et al., 2011|Estudo<br>metodológico<br>–<br>teste de algoritmo|Classificação<br>/<br>identificação<br>errada de 2,4D|Teste de algoritmo<br>para<br>Verificar<br>classificações<br>errôneas<br>de<br>agrotóxicos|AValiaram o impacto da classificação errônea de exposição a<br>agrotóxicos ocupacionais usando dados da coorte e do<br>Estudo de Exposição a Agrotóxicos de AHS americano (AHS /<br>PES). Esses resultados de medições de biomarcadores<br>urinários foram selecionados para aplicadores de 2,4-D e|  
80  
<!-- Start of picture text -->
clorpirifos na AHS / PES.<br>Esses achados indicam que os escores de um algoritmo<br>dervado de um especialista,  a priori , estavam mais<br>relacionados com os níveis urinários medidos do que os<br>Vários determinantes da exposição indvidual aValiados aqui.<br>Embora as correlações entre os escores do algoritmo e os<br>níveis urinários fossem muito boas (ou seja, correlações<br>entre 0,4 e 0,8), o erro de classificação da exposição poderia<br>enViesar as estimatvas de risco relatvo e diminuiria o poder<br>do estudo.<br>Os autores concluem que, exceto em situações em que a<br>estimatva da exposição é bastante precisa (ou seja,<br>correlações de 0,70 ou maiores com exposição Verdadeira)<br>e riscos relatvos Verdadeiros são 3.0 ou mais, a classificação<br>errônea do agrotóxico pode diminuir as estimatvas de riscos<br>a tal ponto que nenhuma associação é obserVada, o que<br>indica que descobertas falso-negatvas podem ser comuns.<br>Assim, um algoritmo que incorpore vários determinantes em<br>uma estimatva da intensidade da exposição, poderia predizer<br>níveis urinários melhores do que os determinados pela<br>exposição indvidual e resultaria em menor atenuação das<br>estimatvas de risco relatvo.<br>Roberts et al., 2011 **  TransVersal  (Sri  Análise  de  Amostra de sangue  Nesse estudo, foi descrita a cinética plasmática de ácido 4-<br>Lanka)  toxicocinética do  cloro-2-metilfenoxiacético (MCPA) em pacientes com<br>MCPA  intoxicação intencional aguda.<br>Os pacientes foram identificados por médicos do estudo no<br>local, em apresentação aos hospitais Anuradhapura ou<br>Polonnaruwa (Sri Lanka), com histórico de intoxicação aguda.<br><!-- End of picture text -->  
81  
<mark>Amostras de sangue seriadas (1, 4, 12 e 24h) foram obtidas em 33 pacientes e em 25 delas as concentrações foram superiores ao limite de relato (5 mg / L) permitindo inclusão nas análises.</mark>  
<mark>O MCPA parece apresentar ligação proteica em 2 sítios. A concentração de MCPA lvre aumentou quando a concentração total excedeu 239 mg / L (interValo de confiança de 95% 198-274 mg / L).</mark>  
<mark>Quando a concentração de MCPA excede o ponto de saturação, a concentração lvre aumenta rapidamente e preVê-se que o MCPA seja mais facilmente distribuído. Usando uma concentração de corte de 200 mg / L, a meia Vida de MCPA em concentrações mais altas foi de 25,5 h (95% CI 15,0-83,0 h; n = 16 pacientes) em comparação com 16,8 h (IC 95% 13,6-22,2 h; n = 10 pacientes) em concentrações mais baixas (embora os interValos de confiança de 95% de ambas as estimatvas sejam amplos). Esta longa meia-Vida de eliminação pode contribuir para a duração prolongada da intoxicação obserVada em casos de auto-ingestão, e a lenta eliminação da MCPA pode contribuir para a morte.</mark> **<mark>Conflito de interesse:</mark>** <mark>Os autores D.M. Roberts, A. H. Dawson, L. Senarathna, F. Mohamed e N.A. Buckley, afiliados à Colaboração de Pesquisa de Toxicologia Clínica do Sul da Ásia (SACTRC), já colaboraram com os funcionários da Syngenta e da Monsanto, fabricantes de herbicidas. Essas colaborações leVaram a publicações de pesquisa na literatura reVisada por pares e nenhum pagamento pessoal foi feito a esses autores.</mark>  
82  
|Azazh 2010|Não disponvel||||
|---|---|---|---|---|
|Arcury et al., 2010|Longitudinal (EUA)|Monitoramento|Detecção<br>de<br>agrotóxicos, na urina|Esta análise foi parte de um programa de pesquisa<br>translacional em andamento abordando a saúde dos<br>trabalhadores rurais latinos e suas famílias no leste da<br>Carolina do Norte.<br>Foram coletadas 4 amostras de urina de 196 trabalhadores<br>rurais em interValos mensais, em 2007. As amostras foram<br>testadas para 12 metabólitos urinários de agrotóxicos. Além<br>disso, foi aplicado questionário para fornecer medidas de<br>riscos de exposição.<br>Os trabalhadores rurais apresentaram pelo menos uma<br>detecção de metabólitos urinários de agrotóxicos; por<br>exemplo: 84,2% tveram pelo menos uma detecção para<br>acefato, 88,8% para 3,5,6-tricloro-2-piridinol. A maioria dos<br>trabalhadores<br>rurais<br>tinha<br>múltiplas<br>detecções<br>de<br>metabólitos específicos; por exemplo, 64,8% tinham 2 ou<br>mais detecções para o acefato, 64,8% para o 3,5,6-tricloro-2-<br>piridinol, 79,1% para o ácido 3- fenoxibenzóico e 86,7% para<br>o ácido 2,4-diclorofenoxiacético (2,4D). Como fator de risco,<br>o tipo de habitação teVe uma associação significatva<br>consistente com detecções de metabólitos.<br>O estudo conclui que os agricultores estão expostos a<br>múltiplos agrotóxicos durante o ano e a redução dessa<br>exposição é necessária.|
|Schreinemachers 2010|Longitudinal|Níveis de 2,4-D e<br>associações com<br>lipídios,<br>metabolismo da|Análise urinária de<br>2,4-D e de outras<br>VariáVeis a partir de|Para inVestigar o padrão de toxicidade dos herbicidas de base<br>clorofenoxi, foram estudados os efeitos de uma exposição<br>préVia recente ao 2,4-D comparando os níveis de lipídios,<br>metabolismo da glicose e hormônio estimulador da tireoide|  
83  
|glicose<br>hormônio<br>estimulador<br>tireoide|e<br>da|banco de dados|em adultos saudáVeis da coorte NHANES III (Pesquisa<br>Nacional de Saúde e Nutrição III, 1988-1994 – dados públicos<br>- EUA) com níveis de 2,4-D urinário acima e abaixo do níVel<br>de detecção, usando-se a análise de regressão linear.<br>Dessa forma, o objetvo do presente estudo foi inVestigar os<br>efeitos que ocorrem em indvíduos saudáVeis logo após uma<br>exposição ao 2,4-D (meia-Vida de menos de um dia),<br>conforme indicado pela sua presença na urina.<br>Dos participantes, 102 (14%) tinham níveis de 2,4-D acima<br>limite de detecção, Variando de 1 a 28 mg/dl, sendo<br>selecionados para o estudo<br>**Como resultado, a presença de 2,4-D urinário foi associada**<br>**a uma diminuição dos níveis de HDL**: 8,6% nos dados não<br>ajustados (p = 0,006), 4,8% nos dados ajustados (p = 0,08) e<br>9% nos dados ajustados para a subpopulação suscetíVel com<br>baixa tiroxina (p = 0,02).<br>**Indvíduos expostos ao 2,4-D tveram menor HDL (**46,9 Versus<br>51,3 mg/dl, p-Valor = 0,004), e maior creatinina urinária (201<br>Versus 145 mg/dl, p <0,0001). Nenhuma outra diferença<br>significatva entre as características contínuas foi obserVada.<br>ObserVou-se<br>os<br>efeitos<br>dependentes<br>de<br>HDL<br>em<br>triglicerídeos, insulina, peptídeo C e TSH, especialmente nas<br>subpopulações mais suscetíVeis. Indvíduos com baixo HDL<br>apresentaram taxas mais altas de efeitos adVersos<br>associados ao 2,4-D do que indvíduos com níveis eleVados de<br>HDL. Sem esse termo de interação ou seu Equvalente no|
|---|---|---|---|  
84  
|||||modelo<br>de<br>regressão,<br>o<br>efeito<br>2.4-D<br>teria<br>sido<br>completamente perdido.<br>Foi visto uma modificação do efeito da relação inVersa<br>triglicérides-HDL foi obserVada em associação com 2,4-D.<br>Entre os indvíduos com HDL baixo, o 2,4-D urinário foi<br>associado a níveis aumentados de triglicerídeos, insulina,<br>peptídeo<br>C<br>e<br>hormônio<br>estimulante<br>da<br>tireoide,<br>especialmente nas subpopulações suscetíVeis. Por outro<br>lado, indvíduos com HDL alto não apresentaram efeitos<br>adVersos associados ao 2,4-D.<br>O estudo do biomarcador contribuiu com informações sobre<br>o padrão de toxicidade do 2,4-D. O estudo populacional<br>contribuiu com informações sobre doenças associadas à<br>exposição ambiental aos herbicidas clorofenóxi. Estes<br>estudos combinados são um exemplo da metodologia<br>recomendada para estudos sobre efeitos na saúde<br>associados a exposições ambientais<br>Conclusões: Os resultados indicam que a exposição ao 2,4-D<br>foi associada a alterações nos biomarcadores que, com base<br>na literatura publicada, têm sido associados a fatores de risco<br>para infarto agudo do miocárdio e diabetes tipo 2.|
|---|---|---|---|---|
|Thomas et al., 2010|Análise e criação<br>de algoritmo de<br>exposição|Não é escopo|||
|Boers et al., 2010|Coorte<br>retrospectva|Mortalidade  por<br>câncer|Banco de atestados de<br>óbitos de estudo de|Trata-se de um estudo de coorte retrospectvo, conduzido em<br>duas fábricas de herbicidas a base de cloro-fenoxiacéticos,|  
85  
|coorte (crônico)|produzindo principalmente ácido 2,4,5-triclorofenoxiacético<br>(fábrica A), ácido 4-cloro-2-metilfenoxiacético, ácido 4-cloro-<br>2-metilfenoxi propanoico e Ácido 2, 4-diclorofenoxiacético<br>(fábrica B).<br>|
|---|---|
||Na fábrica B, produzia-se cerca de 140 toneladas,<br>anualmente, de 2,4-D, de 1966 até 1972.<br>O início do acompanhamento de cada fábrica foi<br>determinado pela integridade dos registros de funcionários e<br>pela disponibilidade de informações de mortalidade. Para a<br>fábrica A todos os trabalhadores empregados entre 1955 e<br>1985 (n = 1167) foram incluídos no estudo. Na fábrica B,<br>todos os trabalhadores empregados entre 1965 e 1986 (n =<br>1143) entraram na coorte. A análise foi feita em 2006.<br>A causa específica do óbito, para os trabalhadores falecidos,<br>foi obtida pelos atestados de óbito obtidos no banco<br>_Statistics Netherlands_.<br>Como resultado do estudo, encontrou-se aumentada a<br>mortalidade por todos os tipos de câncer (Hazard Ratio - HR<br>1,31; IC 95% 0,86 a 2,01) para trabalhadores expostos na<br>fábrica A. Houve risco aumentado para mortalidade por<br>câncer de órgãos genitais (câncer de próstata; HR 2,93; IC<br>95% 0,61 a 14,15) e órgãos do sistema urinário (câncer de<br>bexiga e câncer renal; HR 4,20; IC 95% 0,99 a 17,89).<br>**Para a fábrica B, a mortalidade estava aumentada para**<br>**câncer respiratório (HR 1,22; IC95% 0,56-2,66), câncer**<br>**linfático e hematopoiético (HR 1,52; IC 95% 0,31 a 7,44) e**<br>**doença isquêmica (HR 1,56; IC 95% 0,79 a 3,11). Um risco**<br>**aumentado de mortalidade por câncer de órgãos genitais**|  
86  
|||**também foi encontrado em trabalhadores expostos da**<br>**fábrica B (HR 3,28; IC 95% 0,63 a 17,15).**<br>Os riscos aumentados foram obserVados para todos os tipos<br>de cânceres na fábrica A (HR 1,31; IC 95% 0,86 a 2,01) e na<br>fábrica B (HR 1,54; IC 95% 1,00 a 2,37).|
|---|---|---|
|Wilson et al., 2010|Não é escopo|Estudo não aborda diagnóstico ou sinais e sintomas.<br>Trata-se de análise do uso residencial dos agrotóxicos<br>organofosforados (PO), clorpirifos (CPF) e diazinon (DZN) e<br>associação com exposição em crianças pré-escolares na área<br>da Carolina do Norte (EUA). Estudo considerou um período<br>anterior à proibição de alguns agrotóxicos e posterior a essa<br>proibição.|
|Aylward et al., 2010|Não é escopo|Estudo não aborda diagnóstico.<br>É parte de um estudo epidemiológico de 1599 trabalhadores<br>empregados em uma instalação em New Plymouth, NoVa<br>Zelândia, que fabricaVa 2,4,5-T (2,4,5-trichlorophenoxyacetic<br>acid).<br>As concentrações de TCDD (2,3,7,8- tetrachlorodibenzo-p-<br>dioxin) séricas medidas em amostras de sangue de 346<br>trabalhadores<br>foram<br>usadas<br>para<br>um<br>modelo<br>farmacocinético em uma regressão linear, para estimar taxas<br>de dose associadas a grupos específicos de exposição<br>ocupacional, na instalação.|  
87  
|Bhatti et al., 2010|Construção<br>de<br>modelo<br>farmacocinético<br>(EUA)|Obtenção<br>de<br>modelo<br>farmacocinético<br>–**não é escopo**|Artigo metodológico<br>que aValia exposição e<br>fatores de risco|Este trabalho aValiou os fatores que afetam a concentração<br>urinária de 2,4-D entre aplicadores e discute procedimentos<br>para estimar os níveis urinários de 2,4-D, onde não há dados<br>de biomonitoramento disponíveis.<br>Foram colhidas 136 amostras de urina de 12h de 31<br>aplicadores durante o curso de duas estações de<br>pulVerização (abril a agosto de 1994 e 1995). Usando<br>modelos de efeitos mistos, construíram modelos de<br>exposição que relacionaVam as medidas urinárias de 2,4-D<br>com as atvidades de trabalho autorreferidas ponderadas, a<br>partir de relatos escritos, coletados ao longo de 5 a 7 dias<br>antes da coleta da amostra de urina.<br>Construíram-se modelos farmacocinéticos de exposição<br>baseados que relacionaram as medições de 2,4-D urinárias a<br>Várias tarefas relacionadas ao trabalho detalhados até 7 dias<br>antes da coleta de urina.|
|---|---|---|---|---|
|EPA|Guia US-EPA|Sinais e sintomas|Herbicidas Clorofenoxi<br>Em uma série de casos<br>methyl- phenoxyacetic<br>enVenenamento, sendo<br>achados não específico<br>**generalizada e tontura**.<br>Manifestações de toxi<br>principalmente da expe<br>por motvo de suicídio.<br>2,4-D e ao mecoprop|resultante de intoxicação intencional por MCPA (4-chloro-2-<br>acid), 85% dos pacientes apresentaVa sinais mínimos de<br>os mais comuns:**sintomas gastrointestinais leves**.(18) Outros<br>s e leVes incluem**náusea, dor abdominal, cefaleia, fraqueza**<br>(19)<br>cidade sistêmica de compostos clorofenoxi são conhecidas<br>riência clínica com casos de ingestãode grandes quantidades,<br>Embora a maioria dos relatos clínicos enVolVa a exposição ao<br>,é razoáVel suporque todos os herbicidas clorofenóxi|  
88  
<mark>compartilharão um quadro clínico semelhante. A maioria dos relatos de desfechos fatais enVolVe insuficiência renal, acidose, desequilíbrio eletrolítico e uma falência múltipla de órgãos resultante.(5,9,20) Os agentes mais enVolVidos nesses incidentes são o 2,4-D e o mecoprop.</mark>  
<mark>Comumente, os pacientes apresentarão, dentro de algumas horas após a ingestão: Vômitos, diarreia, dor de cabeça, confusão e comportamento anormal ou agressvo. Em uma grande série de casos resultante de auto-ingestão intencional de MCPA, a maioria dos pacientes (85%) apresentou sinais mínimos de enVenenamento, sendo os</mark> **<mark>sintomas gastrointestinais</mark>** <mark>leVes os mais comumente relatados.(18)</mark> **<mark>Alterações no estado mental</mark>** <mark>podem ocorrer, com progressão para coma em casos graVes. (4,6,9,18)</mark> **<mark>Edema cerebral moderado</mark>** <mark>também foi relatado após ingestão intencional.(21) Um odor peculiar é frequentemente sentido na respiração. A</mark> **<mark>temperatura corporal pode ser moderadamente elevada, mas isso raramente é uma característica com risco de Vida do envenenamento</mark>** <mark>. Não há depressão respiratória. Por outro lado, a</mark> **<mark>hiperventilação</mark>** <mark>é por VezeseVidente, proVaVelmente secundária à acidose metabólica que ocorre.</mark> **<mark>Convulsões ocorrem muito raramente.</mark>** <mark>Com a excreção urinária efetva do agente tóxico, a consciência geralmente retorna em 48-96 horas.(4,6,9)</mark>  
<mark>Fraqueza muscular e neuropatia periférica já foram relatadas após exposição ocupacional.(9) As apresentações são VariáVeis. A miotonia e a fraqueza muscular podem persistir por meses após o enVenenamento agudo (6). Os achados adicionais incluem perda de reflexos e fasciculação.(4 6,8,20) Estudos de eletromiografia e de condução nerVosa em alguns pacientes recuperados demonstraram uma neuropatia e miopatia proximais leVes.</mark>  
<mark>Há algumas alterações metabólicas: a acidose metabólica manifesta-se por um baixo pH arterial e conteúdo de bicarbonato. A urina é geralmente ácida. A lesão do músculo esquelético, se ocorrer, é refletida em níveis eleVados de creatinafosfoquinase e, às Vezes, mioglobinúria. EleVações moderadas de nitrogênio ureico no sangue e creatinina sérica são comumente encontradas quando o agente tóxico é excretado.</mark> **<mark>Casos de insuficiência renal são relatados, muitas Vezesacompanhados de</mark>**  
89  
||||**hipercalemia ou hipocalcemia, e acredita-se que resultem na instabilidade**<br>**cardioVascular que leVa à morte**. (5,20)**A taquicardia é comumente obserVada e**<br>**hipotensão também tem sido relatada**. (4,5,9) A atenuação da onda T também foi<br>obserVada, (6) assim como leucocitose leVe e alterações bioquímicas indicatvas de<br>lesão celular hepática.|
|---|---|---|---|
|US-EPA|Guia|Confirmação<br>Laboratorial|Estão disponíveis métodos cromatográficos líquido-gasosos para a detecção de<br>compostos clorofenoxi no sangue e na urina. Essas análises são úteis para verificar e<br>avaliar a magnitude da absorção desses herbicidas. Episódios de intoxicação<br>caracterizados por inconsciência mostraram concentrações iniciais de clorofenoxi<br>Variando de 80 a mais de 1.000 mg por litro. (4 p.105) As amostras de urina deVem ser<br>coletadas, brevemente, após a exposição, pois os herbicidas podem ser quase<br>completamente excretados em 24-72 horas, na maioria dos casos. As amostras de<br>urina também podem confirmar a exposição. Em um estudo de aplicadores de<br>herbicidas assintomáticos, sua excreção urinária de compostos de clorofenoxi<br>raramente excedeu 1-2 mg / L. (22). A meia-Vida pode ser muito maior em casos de<br>intoxicação, dependendo da extensão da absorção e do pH da urina. As análises<br>podem ser realizadas em laboratórios de referência. Se o cenário clínico indicar que<br>ocorreu exposição excessva a compostos de clorofenoxi, inicie imediatamente as<br>medidas de tratamento apropriadas, não esperando a confirmação química da<br>absorção de substâncias tóxicas.|  
**Quadro IV.4.2:** Síntese de evidências – capítulo 4 - 2,4D - Tratamento  
|**REFERÊNCIA**|**DELINEAM.**|**PICO**|**DESFECHO**|**TIPO DE**<br>**SINTOMAS/**<br>**ANÁLISES**|**EVIDÊNCIAS DO ARTIGO**|
|---|---|---|---|---|---|
|Göen et al., 2017|Não é escopo||Análise<br>de<br>exposição<br>a||Análise de dieta orgânica e exposição a agrotóxicos.|  
90  
|||agrotóxicos por<br>meio da dieta||O estudo confirma que uma intervenção de dieta orgânica resulta<br>em menor exposição considerável a agrotóxicos organofosforados<br>e piretróides.|
|---|---|---|---|---|
|Khan<br>K,<br>Wozniak<br>SE,<br>Coleman J, Didolkar MS.<br>2016|Não é escopo|||Artigo trata da associação entre agente laranja e câncer|
|Park et al., 2011|Série de Casos|Mortalidade|Testes<br>laboratoriais<br>e<br>descrição de 17<br>casos de ingestão<br>intencional<br>de<br>agrotóxicos|Neste estudo, foi reVisado uma série de casos agudos de<br>intoxicação por herbicida análogos à auxina, tratados em hospital<br>na Coreia. Foram incluídos 17 pacientes com intoxicação aguda por<br>ingestão intencional, identificados a partir dos registros médicos do<br>Instituto<br>de<br>Intoxicação<br>por<br>Agrotóxicos<br>do<br>Hospital<br>Soonchunhyang Cheonan (República da Coreia) entre setembro de<br>2006 e maio de 2011.<br>Dos 17 pacientes, 12 pacientes ingeriram o ácido 3,6-dicloro-2-<br>metoxibenzóico (dicamba); 3 pacientes, ido [(3,5,6-tricloro-2-<br>piridinil) oxi] acico (triclopir); 1 paciente, ingeriu complexo de ácido<br>2-metil-4-clorofenoxiacético<br>(MCPA)<br>e<br>3-isopropil-1H-2,1,3-<br>benzotiadiazin-4 (3H) -ona-2,2-dióxido (Bentazona); e 1 paciente,<br>ácido (rs)-2- (4-chloro-0-tolyoxy)propionico (mecoprop).<br>**A modalidade de tratamento foi sintomática: a laVagem gástrica**<br>**foi empregada quando o paciente foi internado em até 2 horas**<br>**após a ingestão. Também foi realizada uma sessão de hemodiálise**<br>**(HD) e uma de hemoperfusão (HP), seguida por administração**<br>**intraVenosa de líquidos. Respirador e oxigênio foram utilizados**<br>**quando necessário. Quando ocorreu insuficiência hepática e**<br>**renal, foram tratados por cuidados de suporte. O uso de diálise e**<br>**perfusão é umaparte doprotocolo do hospital, e se desenvolveu**|  
91  
##### **<mark>devido à experiência com agrotóxicos tóxicos, e os autores reconhecem que esta conduta não é um padrão geral de tratamento.</mark>**  
<mark>Não foi obserVada relação significatva entre a quantidade de dicamba ingerida e o desfecho clínico</mark>  
<mark>O número de pacientes nos outros grupos foi muito baixo para a análise estatística sobre a ingestão.</mark>  
<mark>Entre 17 pacientes, 1 paciente (caso 17) morreu 36h após a admissão, e 12 pacientes tveram alta do hospital sem qualquer queixa específica no dia 7, após receber tratamento conserVador. Os outros quatro pacientes sofreram algumas complicações e foram tratados por mais de uma semana. O caso 3 ingeriu 300 mL de dicamba, sofreu pneumonia e paralisia do íleo durante a admissão. Este paciente foi tratado com antibióticos e nutrição parenteral e recebeu alta hospitalar no dia 28. O caso 9 chegou à sala de emergência após ingestão de 200 mL de dicamba. Durante a internação, teVe infecção relacionada ao cateter e foi administrado cefazolina, tendo alta hospitalar no dia 10. O caso 11 ingeriu 300 mL de dicamba. No teste laboratorial inicial, níveis anormalmente eleVados de aminotransferase (AST, 235 UI / L; ALT, 169 UI / L) e anticorpo anti-Hepatite C (anti-HCV) positvo foram relatados. O caso 12 mostrou hematúria microscópica na urinálise, mas recebeu alta hospitalar no dia 8.</mark>  
<mark>O caso fatal 17 era um indvíduo alcóolatra e ele foi leVado ao pronto-socorro em estado de intoxicação alcoólica e por mecoprop (havia frasco Vazio ao lado do corpo, de Volume 500mL). As características clínicas na admissão foram inconsciência, hipotensão, insuficiência respiratória e rabdomiólise. As</mark>  
92  
<mark>concentrações séricas de álcool e ácido lático foram de 172 mg/dL (referência normal: 0-10 mg/dL) e 51,6 mg/dL (referência normal, 0 mg/dL), respectvamente.</mark>  
**<mark>Tabela 1: Achados laboratoriais (média, IC)</mark>** <mark>WBC (no./μL) 14,779.0 8224.7 [1037, 31440] Hb (g / dL) - 14.7 1.8 [10.7, 17.2] Na (mEq / L) - 142.8 3.7 [135, 150] Cloreto (mEq / L) - 104.4 5.1 [93, 112] K (mEq / L) - 4.1 0.8 [3.1, 6.7] Glicemia em jejum (mg / dL) 149.1 90.0 [64, 451] Proteína (g / dL) - 7.0 0.7 [5.4, 8.7] Albumina (g / dL) - 4.3 0.5 [3.3, 5.1] AST (IU / L) 54.4 60.8 [16, 235] ALT (UI / L) 37.7 36.2 [8, 169] Colesterol, total (mg / dL) 251.1 241.7 [23, 891] Triglicérido (mg / dL) 151.2 71.8 [17.6, 313] BUN (mg / dL) 16.6 7.6 [4.1, 36.6] Creatinina (mg / dL) 1.3 0.7 [0.6, 3.2]</mark>  
<mark>Análise de gasometria arterial pH 7.375 0.1 [7.080, 7.487] PCO2 (mmHg) 34.6 7.6 [21.4, 50.4] PO2 (mmHg) 148.5 88.3 [31.7, 148.5] HCO3 (mmol / L) 19.9 5.7 [6.6, 28.3]</mark>  
<mark>Em conclusão, os autores obserVaram que a toxicidade humana por auxina sintética parece ser benigna, com exceção à ingestão de grandes quantidades, inclusve quando associada com a ingestão de álcool.</mark>  
93  
|Azazh A. 2010|Não disponíVel||||
|---|---|---|---|---|
|Darren M Roberts, Nick<br>Buckley 2007|Revisão<br>sistemática|Mortalidade<br>e<br>efeitos adVersos|Alcalinização<br>urinária|O artigo aValia a eficácia da alcalinização urinária, em particular o<br>bicarbonato de sódio, para o tratamento de intoxicação aguda por<br>herbicidas do tipo clorofenoxi.<br>Pesquisou-se as bases MEDLINE, EMBASE, CENTRAL, Current<br>Awareness<br>em<br>Toxicologia<br>Clínica,<br>Info<br>Trac,<br>http://www.google.com.au e Science Citation Index de estudos<br>identificados<br>pelas<br>pesquisas<br>anteriores.<br>Ensaios<br>clínicos<br>randomizados de alcalinização urinária em pacientes que ingeriram<br>um herbicida clorofenoxi e se apresentaram dentro de 24 a 48<br>horas da intoxicação foram procurados. A qualidade dos estudos e<br>a elegibilidade para inclusão foi aValiada usando os critérios de<br>Jadad e Schulz.<br>As bibliografias de estudos releVantes identificados também foram<br>pesquisadas. Especialistas na área foram contatados, incluindo<br>autores de capítulos de lvros didáticos e artigos de revisão sobre<br>intoxicação por herbicida clorofenoxi. O contato foi feito por e-mail<br>e cada especialista foi incentvado a encaminhar o e-mail para<br>outros especialistas com conhecimento da área.<br>A reVista “Clinical Toxicology” (indexada no Info Trac) foi<br>pesquisada como os resumos das duas maiores conferências<br>internacionais de toxicologia clínica foram publicados nesta<br>reVista.<br>Um autor analisou os resultados de todas as buscas e não<br>identificou nenhum artigo que pudesse ser elegíVel, considerando<br>a intoxicação aguda por clorofenoxi e tratamento com qualquer<br>forma de alcalinização. Estes estudos foram então discutidos entre<br>os autores para confirmar a elegibilidade para inclusão na revisão<br>sistemática.<br>**Resultados:**|  
94  
**<mark>Risco de Viés nos estudos incluídos: Nenhum estudo satisfez os critérios de inclusão. Efeitos das interVenções: Nenhum estudo satisfez os critérios de inclusão. Artigo resultante das buscas: Flanagan 1990</mark>** <mark>-</mark> **<mark>Razão de exclusão: não há grupo controle</mark>** <mark>Portanto, os autores não consideram que haja evidências suficientes para apoiar o uso rotineiro de alcalinização urinária para enVenenamento por herbicida com clorofenoxi. Flanagen, 1990 (referência</mark> Série de Casos Mortalidade Alcalinização <mark>Estudou-se prospectvamente os pacientes notificados à unidade de do artigo Darren et al., 2007)</mark> urinária <mark>saúde durante 1984-87, nos quais disseram ter se intoxicado com clorofenoxi-herbicidas ou ioxinil. Informações registradas incluem sexo, características clínicas e a quantidade e a natureza do produto ingerido. O coma foi classificado na Escala de Édvers. Quando apropriado, o tratamento com bicarbonato de sódio foi recomendado com base na história e características clínicas de toxicidade ou devido às altas concentrações de clorofenoxi total no plasma. Estudo feito por leVantamento de informações em 41 pacientes. Mais de um Herbicide foi encontrado em 38 casos. 6 de 30 pacientes que ingeriram apenas compostos clorofenoxicos morreram; 16 pacientes (principalmente em coma de grau 3-4) tveram diurese alcalina e 15 sobreVveram. 7 de 11 dos doentes que co-ingeriram ioxinil morreram; 3 fizeram diurese alcalina e todos sobreVveram. A</mark> **<mark>diurese alcalina reduziu a meia-Vida de clorofenoxi plasmática para Valores obserVados após doses que não mostraVam efeitos adVersos (ou seja, abaixo de 30 h), mas não influenciou o clearance de ioxynil</mark>**  
95  
||||Os autores sugerem o uso da diurese alcalina deVe ser usada para<br>tratar intoxicação aguda com herbicidas clorofenoxi ou ioxinil, em<br>presença de coma ou mal prognóstico.|
|---|---|---|---|
|US-EPA|Guia|**Tratamento**|Tratamento de Toxicose Clorofenoxida<br>1. Descontaminação da pele e dos cabelos, banhando-os com sabão e água e laVando<br>com shampoo. Indvíduos com doenças de pele crônicas ou sensibilidade conhecida a<br>esses herbicidas deVem eVitar usá-los ou tomar precauções para eVitar contato<br>(respirador, luVas, etc.).<br>2. LaVe e retire os produtos químicos contaminantes dos olhos com grandes<br>quantidades de água limpa por 10 a 15 minutos. Se a irritação persistir, um exame<br>oftalmológico deVe ser realizado.<br>3. Se algum sintoma de intoxicação ocorrer durante ou após a inalação do spray,<br>remoVa a Vítima do contato com o material por pelo menos 2 a 3 dias. Permitir o<br>contato subsequente com os compostos clorofenoxi somente se houver proteção<br>respiratória efetva.<br>4. Considere os procedimentos de descontaminação gástrica, conforme descrito no<br>Capítulo 3 do guia da US- EPA, Princípios Gerais. Se quantidades substanciais de<br>compostos clorofenoxi tverem sido ingeridas, a emese espontânea pode ocorrer.<br>5. Administrar líquidos endoVenosos para acelerar a excreção do composto clorofenoxi<br>e para limitar a concentração do agente tóxico no rim. Uma urina de 4-6 mL / minuto é<br>desejáVel. A solução salina/dextrosa intraVenosa tem sido suficientepara resgatar|  
96  
<mark>pacientes comatosos que ingeriram 2,4-D e mecoprope várias horas antes da admissão hospitalar.</mark>  
**<mark>CUIDADO</mark>** <mark>: Monitorize com cuidado as proteínas e células na urina, uréia, creatinina sérica, eletrólitos séricos e a entrada / saída de fluido para assegurar que a função renal permaneça intacta e que a sobrecarga de fluido não ocorra. 6.</mark> **<mark>Alcalinize a urina para manter um pH entre 7,6 e 8,8. A alcalinização urinária tem sido usada com sucesso no manejo de ingestões suicidas de compostos clorofenoxi, especialmente quando iniciadas precocemente</mark>** <mark>.(4,6,9) Embora o termo “diurese alcalina forçada” tenha sido usado anteriormente para descreVer esse tratamento, a terminologia preferida é agora “alcalinização urinária” para enfatizar a importância da manipulação do pH da urina para limpar o ácido fraco.(23) A alcalinização da urina incluindo bicarbonato de sódio (44-88 mEq por litro) na solução intraVenosa acelera a excreção de 2,4-D e excreção de mecoprofil substancialmente, porque o ácido fraco está em um estado ionizado no túbulo renal e, portanto, não pode se difundir atraVés do túbulo para o sangue. A depuração renal é mínima a um pH ácido de 5,1 (0,14 mL / min) em comparação com a depuração a um pH de 8,3 (63 mL / min) .6,23</mark>  
<mark>Há controVérsia e a falta de estudos clínicos controlados em torno da maneira mais eficaz de induzir a depuração de 2,4-D e mecoprope. O documento de posicionamento AACT e EAPCCT recomenda que a alcalinização da urina e a alta diurese forçada (diurese forçada) sejam consideradas. (23) A Cochrane Database of Systemic ReViews obserVa a falta de evidência, baseada na falta de ensaios clínicos randomizados para esse tratamento.</mark> **<mark>O autor concluiu que “não é despropositado tentar a alcalinização urinária”, dada a toxicidade prolongada e o potencial de morte, e que “são necessários ensaios controlados, randomizados e controlados”</mark>** <mark>.(24)</mark>  
<mark>7. Inclua cloreto de potássio quando necessário para compensar o aumento das perdas de potássio, com 20-40 mEq de cloreto de potássio para cada litro de solução intraVenosa. Alto fluxo de urina, aproximadamente 200 mL / h, melhora a depuração,</mark>  
<mark>Em um caso de insuficiência renal, a alcalinização urinária foi iniciada 26 horas após a ingestão,</mark> <u><mark>(9) e em outro foi iniciada no dia 2 da internação hospitalar. (20) Portanto, é</mark></u>  
97  
<mark>crucial monitorar cuidadosamente a função renal, assim como os eletrólitos séricos, especialmente potássio e cálcio. 8.</mark> **<mark>Considerar a hemodiálise em casos graVes</mark>** <mark>, particularmente quando o excesso de administração não é recomendado. (17) Não é recomendada como terapia de primeira linha. 9. Incluir estudos de eletromiografia e condução nerVosa no exame clínico de acompanhamento para detectar quaisquer alterações neuropáticas e defeitos na junção neuromuscular.</mark>

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
**Quadro IV 5.1.** Avaliação das evidências pelo método GRADE sobre a questão: “A dosagem da creainofosfoquinase (CPK), das transaminases hepáticas (TGO e TGP) e do potássio sérico (K<sup>+</sup> ) podem auxiliar no acompanhamento de pacientes vítimas de exposição aguda a formulações com 2,4-D  ?”  
##### **a) Creatinofosfoquinase (CPK)**  
||||**Avaliação da**|**evidência**|||**№ de p**|**acientes**|**Efeit**|**o**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**a dosagem da**<br>**CPK**|**não realizar o**<br>**teste**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalidad|e||||||||||||  
98  
||||**Avaliação da**|**evidência**|||**№ de p**|**acientes**|**Efeit**|**o**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**a dosagem da**<br>**CPK**|**não realizar o**<br>**teste**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|3|estudo<br>observacional|grave<sup>1,2,3,a</sup>|não grave|não grave|grave<sup>1,2,3,a</sup>|forte associação|2/3 (66.7%)|-|-|-|⨁`◯◯◯`<br>MUITO BAIXA||  
###### <u>Legenda</u>  
a. Todos os estudos avaliados se referem a relatos de caso, sendo que as vítimas de ingeriram volumes e formulações diferentes contendo 2,4D  
###### <u>Bibliografia</u>  
1. OGHABIAN, Z, GHANBARZADEH, N, MEHRPOUR, O.. Treatment of 2 , 4-Dichlorophenoxyacetic Acid ( 2 , 4-D ) Poisoning ; a Case Study. v. 4, n. 3, p. 104–107, 2014.. International Journal of Medical Toxicology and Forensic Medicine; 2014.  
2. HIRAN, Sujata, KUMAR, Sunil.. 2, 4-D dichlorophenoxyacetic acid poisoning; Case report and literature review. . Asia Pacific Journal of Medical Toxicology; 2017.  
3. SINGH, S et al.. Fatal 2,4-D (Ethyl Ester) Ingestion. JAPI; 2003.  
##### **b) Transaminases hepáticas (TGO e TGP)**  
|||||**Avaliaçã**|**o da evidência**||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**a dosagem de**<br>**TGO**|**não realizar o**<br>**teste**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalidade|||||||||||||  
99  
|||||**Avaliaçã**|**o da evidência**||**№ de p**|**acientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**a dosagem de**<br>**TGO**|**não realizar o**<br>**teste**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|5|estudo<br>observacional|grave<br>1,2,3,4,5,a|não grave|não grave|não grave|todos os potenciais fatores de confusão sugeririam um efeito espúrio e,<br>mesmo assim, nenhum efeito foi observado.<br>gradiente de dose-resposta|0/6 (0%)|-|-|-|⨁⨁⨁<br>`◯`<br>MODERADA||  
###### <u>Legenda</u>  
a. Todos os estudos avaliados se referem a relatos de caso, sendo que as vítimas de ingeriram volumes e formulações diferentes contendo 2,4D  
###### <u>Bibliografia</u>  
1. HIRAN, Sujata, KUMAR, Sunil.. 2, 4-D dichlorophenoxyacetic acid poisoning; Case report and literature review. . Asia Pacific Journal of Medical Toxicology; 2017.  
2. FRIESEN, Erwin G, JONES, Graham R, VAUGHAN, Diane.. Clinical presentation and management of acute 2, 4-D oral ingestion. . Drug Safety; 1990.  
3. SINGLA, Sanjay et al. A rare case of 2 , 4-Dichlorphenoxyacetic acid ( 2 , 4-D ) poisoning.. International Journal of Contemp. Pediatr; 2017.  
4. SINGH, S et al.. Fatal 2,4-D (Ethyl Ester) Ingestion. JAPI; 2003.  
5. OGHABIAN, Z, GHANBARZADEH, N, MEHRPOUR, O.. Treatment of 2 , 4-Dichlorophenoxyacetic Acid ( 2 , 4-D ) Poisoning ; a Case Study. v. 4, n. 3, p. 104–107, 2014.. International Journal of Medical Toxicology and Forensic Medicine; 2014.  
|||||**Avaliação**|**da evidência**||**№ de p**|**acientes**|**Ef**|**eito**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**a dosagem da**<br>**TGP**|**não realizar a**<br>**dosagem**|**Relativo**<br>**(95% CI)**|**Evidência**<br>**Absoluto**<br>**(95% CI)**|**Importância**|
|Mortalidade||||||||||||
|4|estudo<br>observacional|grave<br>1,2,3,4,a|não grave|não grave|grave<br>1,2,3,4,b|todos os potenciais fatores de confusão sugeririam um efeito espúrio<br>e, mesmo assim, nenhum efeito foi observado.<br>gradiente de dose-resposta|1/5 (20.0%)|-|-|-<br>⨁⨁`◯`<br>`◯`<br>BAIXA||  
###### <u>Legenda</u>  
- a. Pacientes expostos a diferentes formulações e diferentes quantidades de produto. Todos os estudos se referem à tentativas de suicídio  
- b. todos os estudos são relatos de caso  
###### <u>Bibliografia</u>  
1. HIRAN, Sujata, KUMAR, Sunil.. 2, 4-D dichlorophenoxyacetic acid poisoning; Case report and literature review. . Asia Pacific Journal of Medical Toxicology; 2017.  
2. SINGLA, Sanjay et al. A rare case of 2 , 4-Dichlorphenoxyacetic acid ( 2 , 4-D ) poisoning.. International Journal of Contemp. Pediatr; 2017.  
3. SINGH, S et al.. Fatal 2,4-D (Ethyl Ester) Ingestion. JAPI; 2003.  
4. OGHABIAN, Z, GHANBARZADEH, N, MEHRPOUR, O.. Treatment of 2 , 4-Dichlorophenoxyacetic Acid ( 2 , 4-D ) Poisoning ; a Case Study. v. 4, n. 3, p. 104–107, 2014.. International Journal of Medical Toxicology and Forensic Medicine; 2014.  
100  
##### **c) Potássio Sérico (K**<sup>**+**</sup> **)**  
|||||**Avaliação**|**da evidência**||**№ de paciente**|**s**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**a dosagem de**<br>**potássio sérico (K+)**|**não**<br>**utilizar**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalidade|||||||||||||
|5|estudo<br>observacional|grave<br>1,2,3,4,5,a|não grave|não grave|não grave|todos os potenciais fatores de confusão sugeririam um efeito espúrio<br>e, mesmo assim, nenhum efeito foi observado.|1/6 (16.7%)|-|-|-|⨁⨁`◯`<br>`◯`<br>BAIXA||  
###### <u>Legenda</u>  
a. Os pacientes avaliados utilizaram quantidades e tipos de produtos diferentes. Todos os estudos avaliados são relatos de caso.  
###### <u>Bibliografia</u>  
1. HIRAN, Sujata, KUMAR, Sunil.. 2, 4-D dichlorophenoxyacetic acid poisoning; Case report and literature review. . Asia Pacific Journal of Medical Toxicology; 2017.  
2. FRIESEN, Erwin G, JONES, Graham R, VAUGHAN, Diane.. Clinical presentation and management of acute 2, 4-D oral ingestion. . Drug Safety; 1990.  
3. SINGLA, Sanjay et al. A rare case of 2 , 4-Dichlorphenoxyacetic acid ( 2 , 4-D ) poisoning.. International Journal of Contemp. Pediatr; 2017.  
4. SINGH, S et al.. Fatal 2,4-D (Ethyl Ester) Ingestion. JAPI; 2003.  
5. OGHABIAN, Z, GHANBARZADEH, N, MEHRPOUR, O.. Treatment of 2 , 4-Dichlorophenoxyacetic Acid ( 2 , 4-D ) Poisoning ; a Case Study. v. 4, n. 3, p. 104–107, 2014.. International Journal of Medical Toxicology and Forensic Medicine; 2014.  
**Quadro IV 5.2.** Avaliação das evidências pelo método GRADE sobre a questão: “A alcalinização urinária deve ser utilizada como estratégia de eliminação em pacientes vítimas de exposição aguda a formulações com 2,4-D  ?”  
**Contexto** : Não há antídotos específicos para tratar as intoxicações por formulações contendo 2,4 D e seus derivados. Razão pela qual estratégias de eliminação desses produtos por meio de técnicas dialíticas ou por intervenções que modifiquem a toxicocinética do agente serem rotineiramente utilizadas, principalmente para os casos de intoxicações mais graves. Dentre essas intervenções, a administração de fluidos endovenosos e a alcalinização urinária foram apontadas por alguns autores como eficazes  
101  
|||||**Avaliação da evid**|**ência**||**№ de paci**|**entes**|**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**alcalinização**<br>**urinária**|**não utilizá-**<br>**la**|**Relativo**<br>**(95% CI)**<br>**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalidade||||||||||||
|6|estudo observacional|grave<br>1,2,3,4,5,6,a|não grave|não grave|grave<br>1,2,4,5,6,b|forte associação<br>todos os potenciais fatores de confusão reduziriam o efeito<br>demonstrado|1/45 (2.2%)|-|-<br>-|⨁⨁`◯`<br>`◯`<br>BAIXA|CRÍTICO|  
###### <u>Legenda</u>  
a. Os dados apresentados referem-se a quatro relatos de caso, uma série de casos (n=41, onde 30 pacientes ingeriram 2,4D somente e os demais uma mistura de 2,4D e outros heribicidas) e um "position paper". O tipo de produto ingerido pelas vítimas eram variáveis e o regime utilizado por cada investigador foi distinto. Contudo, há consenso de se manter um pH urinário acima de 7,6  
b. Diferentes agentes e volumes ingeridos de agentes. Todos os casos referem-se a vítimas de tentativa de suicídio, com idades e condições de saúde distintas, não sendo especificadas  
###### <u>Bibliografia</u>  
1. PRESCOTT, L F, PARK, J, DARRIEN, Isobel.. Mecoprop intoxication. Br J Clin Pharmac; 1979.  
2. FLANAGAN, R J et al.. Alkaline diuresis for acute poisoning with chlorophenoxy herbicides and ioxynil. . The Lancet; 1990.  
3. ROBERTS, Darren M., BUCKLEY, N. A.. Urinary alkalinisation for acute chlorophenoxy herbicide poisoning. . Cochrane Database of Systematic Reviews; 2007.  
4. HIRAN, Sujata, KUMAR, Sunil.. 2, 4-D dichlorophenoxyacetic acid poisoning; Case report and literature review. . Asia Pacific Journal of Medical Toxicology; 2017.  
5. FRIESEN, Erwin G, JONES, Graham R, VAUGHAN, Diane.. Clinical presentation and management of acute 2, 4-D oral ingestion. . Drug Safety; 1990.  
6. OGHABIAN, Z, GHANBARZADEH, N, MEHRPOUR, O.. Treatment of 2 , 4-Dichlorophenoxyacetic Acid ( 2 , 4-D ) Poisoning ; a Case Study. v. 4, n. 3, p. 104–107, 2014.. International Journal of Medical Toxicology and Forensic Medicine; 2014.  
**Quadro IV 5.3.** Avaliação das evidências pelo método GRADE sobre a questão: “A alcalinização urinária deve ser utilizada como estratégia de eliminação em pacientes vítimas de exposição aguda a formulações com 2,4-D  ?”  
**Contexto** : Não há antídotos específicos para tratar as intoxicações por formulações contendo 2,4 D e seus derivados. Razão pela qual estratégias de eliminação desses produtos por meio de técnicas dialíticas ou por intervenções que modifiquem a toxicocinética do agente serem rotineiramente utilizadas, principalmente para os casos de intoxicações mais graves. Dentre essas intervenções, a administração de fluidos endovenosos e a alcalinização urinária foram apontadas por alguns autores como eficazes  
102  
||||**Análise da**|**Evidência**|||**№ de p**|**acientes**|**Efeit**|**o**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**hemodiálise**|**não realizá-la**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalidad|e||||||||||||
|2<br>Tempo de|estudo<br>observacional<br>Internação hospita|grave<sup>1,2,a</sup><br>lar (seguimento: v|não grave<br>ariação 6 dias para|não grave<br>23 dias)|grave<sup>1,2,a</sup>|forte associação<br>todos os potenciais<br>fatores de confusão<br>reduziriam o efeito<br>demonstrado|0/5 (0.0%)|-|-|-|⨁⨁`◯◯`<br>BAIXA|CRÍTICO|
|1|estudo<br>observacional|grave<sup>2,b</sup>|não grave|não grave|grave<sup>2,b</sup>|todos os potenciais<br>fatores de confusão<br>sugeririam um efeito<br>espúrio e, mesmo assim,<br>nenhum efeito foi<br>observado.||-|-|-|⨁`◯◯◯`<br>MUITO BAIXA|IMPORTANTE|  
##### <u>Legenda</u>  
a. São relatos de caso, no qual em um deles são descritos quatro pacientes que receberam HD após a ingestão de 2,4D. Todos os pacientes receberam alta em tempo variável  
b. Diferentes lapsos de tempo entre a exposição e o atendimento, volume de agente ingerido variável, idades distintas, diferentes graus de consciência (4 comatosos, sendo 2 classificados REED III)  
##### <u>Bibliografia</u>  
1. MOSHIRI, Mohammad, MOUSAVI, Seyyed Reza, ETEMAD, Leila.. Management of 2 , 4- Dichlorophenoxyacetic Acid Intoxication by Hemodialysis : A Case Report. Iranian Journal of Toxicology. Iranian Journal of Toxicology; 2016.  
2. DURAKOVIC, Zijad et al.. Poisoning with 2,4-dichlorophenoxyacetic acid treated by hemodialysis. Archives of Toxicology; 1992.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 4 | secao: Referências bibliográficas -->
**QUADRO IV.6.1** – Tabela com o detalhamento da avaliação do Grupo Elaborador das recomendações para a “Abordagem ao Paciente Intoxicado por ácido 2,4 diclorofenoacético (2,4D) e seus derivados”  
**<mark>PERGUNTA: Quais são os testes auxiliam no acompanhamento do paciente com suspeita de intoxicação por 2,4D e seus derivados?</mark>**  
103  
|**P**População int|oxicada por 2,4 D e seus derivado|s||
|---|---|---|---|
|**I**Testes labora|toriais (Dosagem de creatinofosfo|quinase -CPK)||
|**C**Ausência da i|ntervenção|||
|**O**Mortalidade||||
|**S**Clínicos e obs|ervacionais|||
||**Julgamento**|**Evidências**|**Considerações**<br>**adicionais**|
||**Qual a qualidade da Evidência**|||
||☐Sem estudos<br>☐Muito baixa<br>☒Baixa<br>☐Moderada<br>☐Alta|Observado aumento significativo nos valores de CPK em vítimas de ingestão<br>intencional de formulações contendo derivados de 2,4D. Das três vítimas<br>apresentadas nos relatos de caso, duas evoluíram a óbito após deterioração do<br>quadro clínico, nas primeiras 48 horas.  (HIRAN; KUMAR, 2017; OGHABIAN;<br>GHANBARZADEH; MEHRPOUR, 2014; SINGH et al., 2003)||
|**Benefícios e**<br>**riscos**|**Há balanço entre os**<br>**riscos e benefícios**<br>`☒`Benefícios sobrepõem os<br>riscos<br>`☐`Há equilíbrio entre riscos<br>e benefícios<br>`☐`Riscos sobrepõem os<br>benefícios|||  
104  
|**Valores  e**<br>**preferencias**|☒Bem aceito<br>☐Indiferente<br>☐Mal aceito|
|---|---|
||Os custos associados à<br>intervenção são pequenos?|
|**Custos**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☒Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
||**A opção é aceitável para as**<br>**principais partes**<br>**interessadas?**|
|**Aceitabilidade**|☐Não<br>☐Provavelmente não<br>☐Incerto<br>☒Provavelmente sim<br>☐Sim|
||☐Há variabilidade|  
105  
- A opção é viável para implementar? ☐Não ☐Provavelmente não ☐Incerto ☒Provavelmente sim ☐Sim ☐Há variabilidade  
<!-- Start of picture text -->
Conclusão<br>Tipo de recomendação  Recomendação forte  Recomendação condicional/fraca  Recomendação condicional a  Recomendação forte<br>contra a intervenção  contra a intervenção  favor da intervenção  a favor da<br>intervenção<br>☐ ☐ ☒ ☐<br>Na admissão de pacientes com suspeita de ingestão de produtos à base de 2,4D ou seus derivados, monitore os níveis<br>de:<br> Creatinafosfoquinase (CPK)<br>Recomendação<br> Transaminases hepáticas (TGO e TGP)<br> Potássio Sérico (K + )<br><!-- End of picture text -->  
106  
|**Justificativa**|Observa<br>derivad<br>quadro<br>al., 200|do aumento significativo nos valores de CPK em vítimas de ingestão intencional<br>os de 2,4D. Das três vítimas apresentadas nos relatos de caso, duas evoluíram a ó<br>clínico, nas primeiras 48 horas (HIRAN; KUMAR, 2017; OGHABIAN; GHANBARZAD<br>3).|de formulações contendo<br>bito após deterioração do<br>EH; MEHRPOUR, 2014; SINGH et|
|---|---|---|---|
|**Consideraçõ **|**es subgrupo **|||
|**Considerações**<br>**implementação**|<br>Exame j|á disponibilizado nas unidades de atendimento do SUS||
|**Monitorament**|**o e avaliação**|||
|**Prioridades de**|**pesquisa**|||
|**PERGUNTA: Qu**|**ais são os testes auxiliam**|**no acompanhamento do paciente com suspeita de intoxicação por 2,4D e seu**|**s derivados?**|
|**P**População int|oxicada por 2,4D e seus d|erivados||
|**I**Dosagem das|transaminases hepáticas|(TGO & TGP)||
|**C**Ausência da i|ntervenção|||
|**O**Mortalidade||||
|**S**Clínicos e obs|ervacionais|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e**<br>**riscos**|**Qual a qualidade da**<br>**Evidência**<br>☐Sem estudos<br>☐Muito baixa<br>☒Baixa (TGP)<br>☒Moderada (TGO)<br>☐Alta|Pacientes intoxicados intencionalmente pela via oral por formulações<br>contendo 2,4D ou os seus derivados apresentam elevação discreta nas<br>transaminases hepáticas no momento da admissão (FRIESEN; JONES;<br>VAUGHAN, 1990; HIRAN; KUMAR, 2017; OGHABIAN; GHANBARZADEH;<br>MEHRPOUR, 2014; SINGH; SHARMA, 2000; SINGLA et al., 2017). Contudo,<br>rapidamente pode ocorrer um aumento significativo da TGO devido aos<br>danos musculares normalmente característicos nos quadros de intoxicação||
|||aguda por esses compostos (FRIESEN; JONES; VAUGHAN, 1990; HIRAN;||  
107  
|||KUMAR, 2017; SINGH et al., 2003)|
|---|---|---|
||**Há balanço entre os**<br>**riscos e benefícios**||
||`☐`Benefícios<br>sobrepõem os riscos<br>`☒`Há equilíbrio entre<br>riscos e benefícios<br>`☐`Riscos sobrepõem<br>os benefícios||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☒Indiferente<br>☐Mal aceito||  
108  
||**Os custos associados à**<br>**intervenção são**<br>**pequenos?**|
|---|---|
|**Custos**|☐Não<br>☒Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
||**A opção é aceitável para**<br>**as principais partes**<br>**interessadas?**|
|**Aceitabilidade**|☐Não<br>☒Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|  
109  
||**A opção**<br>**implem**|**é viável para**<br>**entar?**|||
|---|---|---|---|---|
|**Viabilidade**|☐Não<br>☒Prova<br>☐Incert<br>☐Prova<br>☐Sim<br>☐Há va|velmente não<br>o<br>velmente sim<br>riabilidade|**Conclusão**<br>||
|**Tipo de recome**|**ndação**|**Recomendação**<br>**forte contra a**<br>**intervenção**<br>☐|**Recomendação condicional/fraca**<br>**contra a intervenção**<br>☐<br>**Recomendação condicional a favor da**<br>**intervenção**<br>☒|**Recomendação forte**<br>**a favor da**<br>**intervenção**<br>☐|
|**Recomendação**||Na admissão de paci<br><br>Creatinafosf<br><br>**Transaminas**<br><br>Potássio Séri|entes com suspeita de ingestão de produtos à base de 2,4D ou seus derivados, mo<br>oquinase (CPK)<br>**es hepáticas (TGO e TGP)**<br>co (K<sup>+</sup>)|nitore os níveis de:|
|**Justificativa**||Pacientes intoxicado<br>discreta nas transam|s intencionalmente pela via oral por formulações contendo 2,4D ou os seus derivad<br>inases hepáticas no momento da admissão (FRIESEN; JONES; VAUGHAN, 1990;|os apresentam elevação<br>HIRAN; KUMAR, 2017;|  
110  
|OGHABIA<br>ocorrer u<br>aguda po|N; GHANBARZADEH; MEHRPOUR, 2014; SINGH; SHARMA, 2000; SINGLA et al., 2017). Contudo, rapidamente pode<br>m aumento significativo da TGO devido aos danos musculares normalmente característicos nos quadros de intoxicação<br>r esses compostos (FRIESEN; JONES; VAUGHAN, 1990; HIRAN; KUMAR, 2017; SINGH et al., 2003)|
|---|---|
|**Considerações**<br>**subgrupo**||
|**Considerações**<br>**implementação**<br>Exame já|disponibilizado nas unidades de atendimento do SUS|
|**Monitoramento e**<br>**avaliação**||
|**Prioridades de pesquisa**||
|**PERGUNTA: Quais são os testes auxi**|**liam noa companhamento do paciente com suspeita de intoxicação por 2,4D e seus derivados?**|
|**P**População intoxicada por 2,4D e se|us derivados|
|**I**Potássio Sérico||
|**C**Ausência da intervenção||
|**O**Mortalidade||
|**S**Clínicos e observacionais<br>|<br>|
|**Julgamento**|**Evidências**<br>**Considerações adicionais**|
|**Qual a qualidade**<br>**da Evidência**|A hipocalemia discreta é apresentada na literatura como sendo uma<br>alteração comum durante a evolução clínica de pacientes vítimas de|
|**e riscos**<br>☐Sem estudos<br>☐Muito baixa|tentativa de suicídio com formulações à base de 2,4D e seus derivados<br>(FRIESEN; JONES; VAUGHAN, 1990; HIRAN; KUMAR, 2017; OGHABIAN;|
|**cios**<br>☒Baixa|GHANBARZADEH; MEHRPOUR, 2014; SINGH et al., 2003; SINGLA et al.,|
|**Benefí**<br>☐Moderada<br>☐Alta|2017).|  
111  
|**Qual a**<br>**qualidade da**<br>**Evidência**|
|---|
|`☐`Sem estudos|
|`☐`Muito baixa|
|`☒`Baixa|
|`☐`Moderada|
|`☐`Alta|
|**Há balanço**<br>**entre os riscos**<br>**e benefícios**|
|`☐`Benefícios|
|sobrepõem os<br>riscos<br>`☒`Há equilíbrio|
|entre riscos e|
|benefícios<br>`☐`Riscos|
|sobrepõem os|
|benefícios|  
112  
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☒Indiferente<br>☐Mal aceito|
|---|---|
||**Os custos**<br>**associados à**<br>**intervenção são**<br>**pequenos?**|
||☐Não|
|**Custos**|☐Provavelmente<br>não<br>☒Incerto<br>☐Provavelmente<br>sim<br>☐Sim|
||☐Há variabilidade|  
113  
||**A opção é**<br>**aceitável para as**<br>**principais partes**<br>**interessadas?**||
|---|---|---|
|**dade**|☐Não||
|**Aceitabili**|☐Provavelmente<br>não<br>☒Incerto||
||☐Provavelmente<br>sim||
||☐Sim<br>☐Há variabilidade||
||A opção é viável<br>para implementar?||
||☐Não||
|**Viabilidade**|☐Provavelmente<br>não<br>☒Incerto<br>☐Provavelmente<br>sim<br>☐Sim||
||☐Há variabilidade||
|||**Conclusão**|  
114  
|**Tipo de**|**Recomendação**|**Recomendação**<br>**Recomendação condicional a favor da intervenção**|**Recomendação forte**|
|---|---|---|---|
|**recomendação**|**forte contra a**<br>**intervenção**<br>☒|**condicional/fraca contra a**<br>**intervenção**<br>☐<br>☐|**a favor da**<br>**intervenção**<br>☐|
|**Recomendação**|**Na admissão de pac**|**ientes com suspeita de ingestão de produtos à base de 2,4D ou seus derivados, monit**|**ore os níveis de:**|
||<br>Creatinafosf<br><br>Transaminas<br><br>**Potássio Sér**|oquinase (CPK)<br>es hepáticas (TGO e TGP)<br>**ico (K**<sup>**+**</sup>**)**||
|**Justificativa**|A hipocalemia discre<br>de tentativa de suicí<br>OGHABIAN; GHANB|ta é apresentada na literatura como sendo uma alteração comum durante a evolução clín<br>dio com formulações à base de 2,4D e seus derivados (FRIESEN; JONES; VAUGHAN, 1990<br>ARZADEH; MEHRPOUR, 2014; SINGH et al., 2003; SINGLA et al., 2017).|ica de pacientes vítimas<br>; HIRAN; KUMAR, 2017;|
|**Considerações**<br>**subgrupo**||||
|**Considerações**<br>**implementação**||||
|**Monitoramento e**<br>**avaliação**||||
|**Prioridades de**<br>**pesquisa**||||  
115  
**QUADRO IVI.6.2** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para o tratamento de intoxicações por <u>produtos formulados com 2,4 D e seus derivados</u>  
|**PERGU**|**NTA: Quais são os métodos de eliminação**|**efetivos na intoxicaçãopor 2,4 D e seus derivados?**||
|---|---|---|---|
|**P**Popul<br>**I**Métod<br>|ação intoxicadaporprodutos formulados com<br>os de eliminação(alcalinização urinária)<br>|2,4D e seus derivados||
|**C**Ausên|cia da intervenção|||
|**O**Redu|ção da mortalidade|||
|**S**Clínic|os e observacionais|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa<br>☐Baixa<br>☐Moderada<br>☐Alta|Durante o atendimento a uma vítima de tentativa<br>de suicídio, que havia ingerido 70mL de produto<br>contendo 55% de 2,4-D, o reconhecimento da<br>intoxicação e a alcalinização urinária, com a<br>manutenção de um débito urinário acima de<br>5mL/Kg/h contribuiu para um prognóstico<br>favorável. A velocidade de infusão foi ajustada<br>considerando a manutenção do pH urinário em<br>8,0 e de um  fluxo urinário de 6 ml / min (HIRAN;<br>KUMAR, 2017).<br>A alcalinização urinária se mostrou efetiva para<br>a depuração do 2,4D de um paciente vítima de<br>intoxicação intencional de uma mistura contendo<br>10% de 2,4D e 20% de Mecocrop (ácido 2 4-||  
116  
|Cloro-2-metilfenoxi propiônico). O uso de valores|
|---|
|da depuração renal, corrigidos e não corrigidos<br>para o fluxo de urina, permite o esclarecimento|
|das contribuições relativas da alcalinização|
|urinária e do fluxo urinário. Os dados de Prescott<br> <br>|
|et<br>al., (1979) demonstram que tanto a|
|alcalinização urinária (pH urinário> 8) quanto o<br>alto fluxo urinário (da ordem de 600 mL/hora) são<br>necessários para obter uma depuração renal de|
|2,4-D comparável àquela alcançada com a|
|hemodiálise (PRESCOTT; PARK; DARRIEN,<br>1979).|
|A alcalinização urinária favorece a eliminação|
|renal de clorofenoxiácidos, alterando a sua|
|distribuição nos diversos compartimentos do|
|organismo. Ela aumenta a possibilidade de um<br>prognóstico favorável, mesmo em pacientes|
|comatosos<br>ou<br>com<br>outras<br>condições|
|desfavoráveis,<br>como<br>acidemia<br>ou<br>que|
|apresentam<br>concentrações<br>plasmáticas<br>do|  
117  
|agente superiores a 0.5g/L (FLANAGAN et al.,<br>1990)|
|---|
|Em uma paciente de 61 anos de idade, vítima da<br>ingestão intencional de cerca de 200mL de uma|
|formulação<br>contendo<br>250g/L<br>de<br>um|
|aminoderivado do 2,4D, a qual foi trazida|
|inconsciente<br>e<br>entubada<br>ao<br>serviço<br>de|
|emergência, foi observada uma redução da<br>meia-vida inicial do agente de 39,5 horas para<br>2,7 hora 30 minutos após a alcalinização urinária<br>(pH mantido acima de 7,5) (FRIESEN; JONES;<br>VAUGHAN, 1990)|
|A alcalinização urinária pode ser eficaz para o|
|tratamento do envenenamento por herbicida|
|com clorofenoxi, mas faltam dados sobre a|
|indicação, o regime e a eficácia. (ROBERTS,|
|Darren M.; BUCKLEY, 2007)<br>Paciente de 22 anos de idade, vítima de tentativa<br>|
|de suicídio, ingeriu 400 mL de um produto<br>contendo 2,4D, após receber atendimento|  
118  
|||padrão foi submetido à diurese alcalina após ser<br>evidenciada a rabdomiólise. O paciente recebeu<br>alta no quinto dia após admissão. Houve<br>normalização<br>dos<br>parâmetros<br>bioquímicos<br>séricos uma semana após a alta (OGHABIAN;<br>GHANBARZADEH; MEHRPOUR, 2014)|
|---|---|---|
||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☒`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☒Mal aceito||  
119  
||Os custos associados à intervenção são<br>pequenos?|
|---|---|
|**Custos**|☐Não<br>☒Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|**Aceitabilidade**|☐Não<br>☒Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim|
||☐Há variabilidade|  
120  
<!-- Start of picture text -->
A opção é viável para implementar?<br>☐Não<br>☒Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade<br>Conclusão<br>Tipo de recomendação  Recomendação forte  Recomendação  Recomendação  Recomendação forte a<br>contra a intervenção  condicional/fraca contra  condicional a favor da  favor da intervenção<br>a intervenção  intervenção<br>☒ ☐ ☐<br>☐<br>Recomendação  Nos casos em que há ingestão de formulações à base de 2,4D e seus derivados, proceda com a alcalinização<br>urinária no intuito de manter o pH urinário acima de 7,6 e um débito urinário acima de 5mL/Kg/h.<br>Justificativa<br>Considerações subgrupo<br>Considerações  Procedimento passível de realização em todas as unidades de emergência do SUS<br>implementação<br>Monitoramento e avaliação<br>Prioridades de pesquisa<br> PERGUNTA: Qual é o tratamento inicial para o paciente intoxicado por 2,4D e seus derivados<br>Viabilidade<br><!-- End of picture text -->  
121  
|**P**Popul|ação intoxicada com agrotóxicos inibidores de|colinesterase||
|---|---|---|---|
|**I**Realiz|ação de hemodiálise|||
|**C**Ausê<br>**O**Redu|ncia da intervenção<br>ção da mortalidade e tempo de internação|||
|**S**Clínic|os e observacionais|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa (Mortalidade)<br>☐Baixa<br>☐Moderada<br>☐Alta|Após a ingestão intencional de um volume<br>desconhecido de um produto comercial contendo<br>40% de 2,4D, um indivíduo de 53 anos<br>apresentou<br>rebaixamento<br>do<br>nível<br>de<br>consciência, evoluindo para um quadro de<br>diarreia e hipotensão não responsiva à reposição<br>de volume. Após receber hemodiálise regular,<br>com bicarbonato de sódio, por três horas, houve<br>normalização da pressão arterial (110x70 mm de<br>Hg) e melhora no nível de consciência começou<br>a melhorar. Quatro horas após o término do<br>procedimento, ele estava totalmente consciente<br>com a pressão arterial estável (130x 80 mm de<br>Hg) (MOSHIRI; MOUSAVI; ETEMAD, 2016).<br>Em uma série de casos na qual optou-se pela<br>hemodiálise em 4 pacientes que haviam ingerido||  
122  
|||de 40g a 200g de 2,4-D e que haviam chegado<br>ao pronto atendimento em estado de coma ou<br>com consciência alterada.  Ao final<br>do<br>procedimento foi observada redução significativa<br>na concentração sérica de 2,4-D após 3h a 5h.<br>Todos os pacientes receberam alta hospitalar<br>entre 8-23 dias(DURAKOVIC et al., 1992).|
|---|---|---|
||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferencias**|☐Bem aceito<br>☐Indiferente<br>☒Mal aceito||  
123  
||**Os custos associados à intervenção são**<br>**pequenos?**|
|---|---|
|**Custos**|☒Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade|
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|**Aceitabilidade**|☒Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim|
||☐Há variabilidade|  
124  
<!-- Start of picture text -->
A opção é viável para implementar?<br>☒Não<br>☐Provavelmente não<br>☐Incerto<br>☐Provavelmente sim<br>☐Sim<br>☐Há variabilidade<br>Conclusão<br>Tipo de recomendação  Recomendação forte  Recomendação  Recomendação  Recomendação forte a<br>contra a intervenção  condicional/fraca contra  condicional a favor da  favor da intervenção<br>a intervenção  intervenção<br>☐ ☐ ☐<br>☒<br>Recomendação  Nos casos graves de intoxicação com produtos à base de 2,4D considere a utilização de métodos dialíticos no<br>intuito de favorecer a remoção de todos os ingredientes presentes na formulação.<br>Justificativa<br>Considerações subgrupo<br>Considerações  Técnica já disponibilizada em todas as unidades de atendimento do SUS<br>implementação<br>Monitoramento e avaliação<br>Prioridades de pesquisa<br>Viabilidade<br><!-- End of picture text -->  
125

---

