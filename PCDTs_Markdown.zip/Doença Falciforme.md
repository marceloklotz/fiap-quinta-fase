<!-- METADADOS: doenca: Doença Falciforme | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 16, DE 01 DE NOVEMBRO DE 2024.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença Falciforme.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Doença Falciforme no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação no 921/2024 e o Relatório de Recomendação no 924 – agosto de 2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença Falciforme.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Doença Falciforme, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Doença Falciforme.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede  
assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 05, de 19 de fevereiro de 2018, publicada no Diário Oficial da União (DOU) nº 36, de 22 de fevereiro de 2018, seção 1, página 75.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: Geral -->
CARLOS AUGUSTO GRABOIS GADELHA

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **1. INTRODUÇÃO** -->
A Doença Falciforme (DF) é uma condição genética que define um grupo de doenças hereditárias resultantes de alterações na estrutura da hemoglobina (Hb) e podem estar associadas a defeitos em sua síntese<sup>1</sup> . A mutação na sexta posição da cadeia beta do gene da globina A (HbA) leva à substituição do ácido glutâmico pela valina (Glu6Val), dando origem à hemoglobina S (HbS)<sup>1,2</sup> . A HbS está sujeita à polimerização quando se encontra em situações de baixa oxigenação e pH. A partir da sua polimerização, a HbS torna-se insolúvel e altera a forma eritrocitária de um disco bicôncavo para uma estrutura falciforme<sup>1,2</sup> .  
Hemácias falciformes são rígidas e sofrem alterações de membrana, podendo se romper e levar à hemólise intravascular e à anemia hemolítica crônica<sup>3</sup> . Além disso, os eritrócitos falciformes expressam maior quantidade de moléculas de adesão, promovendo maior interação entre células endoteliais, leucócitos e plaquetas. Junto a estes mecanismos, o desenvolvimento de alterações endoteliais, vasculopatia proliferativa e hipercoagulabilidade tornam-se responsáveis pelas principais manifestações clínicas na DF, como episódios de vaso-oclusão, dores agudas, fenômenos inflamatórios e danos a diversos órgãos<sup>3–6</sup> . O **Quadro 1** sumariza as principais manifestações clínicas e complicações da DF.  
**Quadro 1** . Principais manifestações e complicações clínicas, crônicas e agudas na DF.  
|**Manifestações agudas**|**Manifestações crônicas**|
|---|---|
|Crises dolorosas e episódios de vaso-oclusão|Anemia hemolítica crônica|
|Infecções e febre|Disfunção cardíaca/pulmonar|
|Síndrome torácica aguda (STA)|Disfunção renal/hepática|
|Acidente vascular cerebral (AVC)|Retinopatia (vaso-oclusão na retina)|
|Sequestro esplênico (baço)|Úlceras de membros inferiores|
|Crise aplástica|Osteonecrose|
|Priapismo (ereção involuntária por vaso-oclusão)|Asplenia funcional|
|Necrose papilar aguda|Úlceras de membros inferiores|  
**Fonte:** Adaptado de Miller (2012); Hebbel (2004); Wood (2007) e Kato (2007)<sup>3–6</sup> .  
A heterogeneidade mutacional e outras características genéticas do indivíduo relacionadas a fatores ambientais e sociais são responsáveis por um amplo espectro de manifestações e complicações clínicas<sup>7</sup> , e a gravidade da doença se relaciona, dentre outros fatores, com a concentração intracelular de HbS<sup>2</sup> . A mutação homozigótica da globina beta-S (HbSS), conhecida como “anemia falciforme”, é o genótipo mais comum dentre as DF – e o mais grave – responsável por quadros de anemia intensa e necessidade de transfusões sanguíneas durante toda a vida<sup>7,8</sup> .  
Por outro lado, pacientes heterozigotos que apresentam apenas um gene mutado (HbAS) são portadores do “traço falciforme” e são, normalmente, assintomáticos. Ainda, o gene da HbS pode estar combinado com outras mutações, dando origem aos genótipos heterozigotos compostos como HbSC, HbSD, dentre outros<sup>7,8</sup> . A combinação da hemoglobina S com a beta-talassemia dá origem à condição heterozigota composta conhecida como Sbeta-talassemia (HbSbeta-tal), que pode ser classificada como HbSbeta<sup>0</sup> ou HbSbeta<sup>+7</sup> .  
A DF é uma das doenças genéticas mais comuns no mundo e estima-se que cerca de 5% da população mundial tenha a mutação da globina beta-S<sup>9</sup> . As hemoglobinopatias decorrentes dos defeitos na estrutura da Hb são mais frequentes em povos africanos, de modo que, neste continente, cerca de 15% dos casos de mortalidade infantil estão relacionados à DF<sup>10</sup> . A anemia falciforme é mais prevalente na África Equatorial e Sub Sahariana, com incidência de 1 a 2%<sup>11,12</sup> . Esta maior incidência do gene  
HbS nas populações afrodescendentes é refletida em todo mundo. Nos Estados Unidos da América, por exemplo, um a cada 13 afrodescendentes é portador do traço falciforme, e a anemia falciforme está presente em um de cada 500 nascidos vivos entre os americanos afrodescendentes. Por outro lado, esta incidência é reduzida para um a cada 36.000 nascidos vivos dentre os americanos de descendência hispânica<sup>13</sup> .  
No Brasil, estima-se que 4% da população possua o traço falciforme, com uma distribuição heterogênea entre as regiões<sup>11,14</sup> . De acordo com o Relatório Anual de Dados do Programa Nacional de Triagem Neonatal foram diagnosticados 5.428 recém-nascidos com DF no período de 2014 a 2018<sup>15</sup> . Dados recentes não foram identificados, mas em 2007 estimava-se que 25.000 a 50.000 pessoas apresentavam anemia falciforme (homozigotos HbSS) ou tinham a DF na condição de heterozigotos compostos ou duplos no país<sup>11,12</sup> .  
Apesar de estar presente em todo o território nacional em virtude da grande miscigenação e das migrações populacionais, a DF chegou ao país por meio de pessoas escravizadas trazidas da África<sup>16</sup> . Deste modo, apesar de também estar presente em pessoas de fenótipo branco, a DF se manifesta sobretudo na população negra (pretos e pardos) e sua maior prevalência ocorre nas Regiões Norte e Nordeste, onde a prevalência estimada do traço falciforme varia de 6% a 10%<sup>11</sup> . Por esse motivo, a DF foi negligenciada e ficou invisibilizada durante muito tempo por falta de interesse decorrente do racismo estrutural e institucional<sup>17,18</sup> .  
A identificação dos pacientes antes do início dos sintomas visa a diminuir as crises vaso-oclusivas, uma vez que a maioria dos desfechos fatais é precedida por episódios agudos, como a Síndrome Torácica Aguda (STA) ou o sequestro esplênico<sup>3,19,20</sup> . Assim, o diagnóstico precoce por meio dos programas de triagem neonatal é fundamental para a identificação e inclusão das pessoas com doença falciforme nos programas de atenção especializada em tempo oportuno. O diagnóstico precoce associado aos cuidados de saúde por meio de equipe multidisciplinar reduz de forma significativa a morbimortalidade da doença, além de possibilitar a orientação e informação genética aos portadores de traço para hemoglobinopatias variantes.  
Este Protocolo visa estabelecer os critérios diagnósticos e terapêuticos da DF, a identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para melhores resultados terapêuticos, alterando o prognóstico dos pacientes com DF.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- D57.0 Anemia falciforme com crise  
- D57.1 Anemia falciforme sem crise  
- D57.2 Transtornos falciformes heterozigóticos duplos

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **3.1      Manifestações clínicas** -->
A anemia causada pela destruição (hemólise) das hemácias falcizadas é a principal manifestação clínica da DF e é diagnosticada no hemograma pela diminuição do nível de Hb e aumento dos reticulócitos. Os sinais de anemia são palidez da pele e das mucosas, icterícia, cansaço, sonolência, taquicardia e sopros cardíacos. Geralmente, a hemoglobina basal varia de 6 a 9 mg/dL nas DF do tipo HbSS e HbSbeta<sup>0</sup> , entretanto nos tipos menos graves como HbSC ou HbSbeta<sup>+</sup> talassemia este valor pode ser mais alto. Os episódios vaso-oclusivos são causados por isquemia secundária à obstrução do fluxo sanguíneo pelas hemácias falcizadas resultando em hipóxia regional e fenômeno inflamatório<sup>16,22</sup> . Estes episódios estão associados a quadros de dor intensa em diversas partes do corpo que duram de 4 a 6 dias, mas podem persistir por semanas.  
Além da anemia, alterações renais na DF se iniciam na primeira década e podem evoluir para Insuficiência Renal Crônica (IRC), justificadas pela presença de capilares com reduzido pH e pO2, condições ideais para a falcização e oclusão microvascular na medula renal. Como consequência, provocam hiperfiltração glomerular e hipostenúria por impossibilidade de concentrar a urina, levando à necessidade de micções frequentes mesmo sem ingestão de água, podendo causar desidratação e desencadear novas crises vaso-oclusivas, proteinúria e alteração da síntese de hormônios renais (eritropoietina, renina e prostaglandina). A falência renal pode levar à necessidade de hemodiálise e eventual transplante renal, e é causa frequente de óbito em pacientes com idade acima de 40 anos<sup>22,23</sup> .  
Infecções frequentes e febre também são sinais importantes da DF, e constituem a principal causa de mortalidade em crianças. Pacientes com DF frequentemente apresentam asplenia funcional, em virtude das inúmeras crises vaso–oclusivas que comprometem a função do baço e levam à susceptibilidade maior às infecções, sendo o _Streptococcus pneumoniae_ responsável por 70% das infecções nessa população<sup>24–26</sup> .  
As infecções são mais frequentes e mais graves em crianças com menos de 5 anos, podendo se apresentar de maneira fulminante e levar à morte em menos de 24 horas. Estima-se que o risco de meningite pneumocócica seja 600 vezes maior do que na população geral, e a frequência de bacteremia 300 vezes maior que o esperado para a idade; 90% dos casos ocorrem nos três primeiros anos de vida<sup>24,25</sup> .  
Diferentemente da anemia falciforme, alguns casos de DF (HbSC, HbSbeta-tal etc.) cursam com o baço aumentado. Nas crises mais graves, ocorre o sequestro do sangue no baço, conhecido como sequestro esplênico. Uma quantidade maciça de sangue falcizado é rapidamente represada no baço desencadeando sintomas de palidez intensa, prostração, rápido aumento do tamanho do baço, dor abdominal, desidratação, hipovolemia e choque hipovolêmico. O sequestro esplênico ocorre em até 30% das crianças pequenas com DF e é o sintoma de apresentação em até 20% dos pacientes em geral<sup>27</sup> .  
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, racismo, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **3.2       Diagnóstico clínico e molecular** -->
A DF é diagnosticada de maneira precoce, por meio de Programa Nacional de Triagem Neonatal (PNTN) (Teste do Pezinho), ou de forma tardia para crianças e adultos que não tiveram acesso à triagem neonatal. Recomenda-se que a detecção e o início do tratamento aconteçam antes de 4 meses de idade para promover prevenção adequada das infecções e outras complicações potencialmente fatais<sup>28</sup> .  
Alterações nos parâmetros hematológicos podem ser observados pelo hemograma de pessoas com DF, como volume corpuscular médio (VCM) e concentração de hemoglobina corpuscular média (CHCM) com valores reduzidos, e contagem de leucócitos e de reticulócitos aumentada (entre 4% e 10%). Na microscopia ótica de esfregaço sanguíneo podem ser observados, além das hemácias em foice, codócitos, hipocromia, microcitose, policromasia, Corpos de Howell-Jolly e Corpos de Heinz. Estes aspectos podem auxiliar na suspeita clínica para o diagnóstico tardio, mas não são confirmatórios da doença.  
O método recomendado para a confirmação do diagnóstico é a eletroforese de hemoglobina pela técnica de eletroforese por focalização isoelétrica ( _isoelectric focusing electrophoresis_ , IEF) ou pela cromatografia líquida de alta resolução ( _high performance liquid chromatography_ , HPLC). O diagnóstico por IEF ou HPLC é preciso e, normalmente, não há necessidade de uma nova eletroforese. O diagnóstico pode ainda ser feito pelo método convencional de eletroforese de hemoglobina em gel de agarose ou acetato de celulose para adultos. Entretanto, resultados inconclusivos na técnica escolhida podem ser reavaliados na outra técnica, de forma complementar. Quando da triagem neonatal, recomenda-se que, se necessário, a repetição do teste seja feita - em coleta direta do paciente para evitar eventual troca de amostra.  
Os testes de biologia molecular, como a reação em cadeia da polimerase ( _polymerase chain reaction,_ PCR), deverão ser agregados ao diagnóstico para elucidação do genótipo e polimorfismos presentes, importantes para compreensão do prognóstico e gravidade da doença<sup>29</sup> . O **Quadro 2** apresenta as principais síndromes falcêmicas de acordo com os tipos de Hb presentes e seus principais aspectos clínicos.  
Além da análise molecular, recomenda-se a quantificação de HbA2 e hemoglobina fetal (HbF), análise familiar de pai, mãe e irmãos e identificação da presença da variante de alfa-talassemia, dos haplótipos associados ao gene da HbS e demais variantes de Hb<sup>16</sup> .  
**Quadro 2.** Principais síndromes falcêmicas.  
|**Síndromes Falciformes**|**Hemoglobinas**<br>**presentes**|**Aspectos clínicos e epidemiológicos**|
|---|---|---|
|HbSS|S, F, A2|Anemia falciforme; forma mais comum e mais grave da DF,<br>com crises de falcização.|
|HbSbeta0<br>talassemia<br>(HbSbetaº)|S, F, A2|Mais prevalente na região do Mediterrâneo Oriental e Índia.<br>Curso clínico e gravidade semelhante à HbSS.|
|HbSbeta+<br>talassemia<br>(HbSbeta<sup>+</sup>)|S, F, A2, A|Mais prevalente na região do Mediterrâneo Oriental e Índia. A<br>presença de HbA varia de 1 a 30% com gravidade que pode ir<br>de leve à grave, mas, geralmente, menos grave que HbSS.|
|HbSS/alfa talassemia (HbSS/α<br>tal)|S, F, A2|Níveis variáveis de hemoglobina fetal, e geralmente, com curso<br>clínico leve.|
|HbSC|S, F, C, A2|25-30% de casos de DF em população de origem africana. O<br>HbS/C Harlem ou Georgetown é uma das variantes.|
|HbSD|S, F, D, A2|O tipo HbS/D Punjab ou Los Angeles é o mais comum, e é<br>clinicamente mais grave.|
|HbS/PHHF|S, F, A2|Grupo de distúrbios causados por grandes deleções no gene da<br>globina beta. Geralmente assintomático.|
|HbAS|S, F, A2 A (com A maior<br>que 60%),|Traço falciforme, geralmente assintomático, não caracteriza<br>anemia.|  
**Fonte:** adaptado de ANVISA (2001)<sup>16</sup> e Figueiredo et al. (2015)<sup>7</sup>  
Os seguintes procedimentos diagnósticos constam na Tabela de Medicamentos, Procedimentos, Órteses, Próteses e Materiais Especiais do SUS:  
02.02.02.035-5 - Eletroforese de hemoglobina: consiste na separação e quantificação das hemoglobinas pelos métodos: eletroforese por isofocalização, gel de agarose, acetato de celulose ou HPLC.  
02.02.11.002-8 - Detecção molecular de mutação em hemoglobinopatias (confirmatório).  
A Atenção Primária, de posse de resultado do teste do pezinho ou o resultado do exame de eletroforese de hemoglobina, inicia a assistência à pessoa com DF ( **Figura 1** ). O fluxo de referenciamento e atendimento aos Centros de Referência está descrito na seção **Centros de Referência** .  
**Figura 1.** Fluxo de diagnóstico e encaminhamento aos Centros de Referência.  
<!-- Start of picture text -->
Teste do pezinho - PNTN Suspeita clinica de DF<br>ce acme<br>8<br>8<br>2 sim Homozigose (HbSS) ou No<br>3 heterozigose composta?<br>5<br>=<br>Sim Nao<br>Notifica Centro de Referéncia [ Traco Falciforme? ‘|<br>Inclui informac&o no<br>prontuario. Realiza consulta Acompanhamento do RN /<br>para informar o diagndstico e diagnésticos alternativos<br>onentar paciente/familiares<br>s<br>s<br>=<br>= Realiza avaliacdo genotipica<br>3 (PCR), fenotipgem eritrocitaria e<br>3 testes imunohematologicos<br>a<br>=<br>2 Inicia tratamento e<br>acompanhamento da DF<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
**Legenda:** IEF: eletroforese por focalização isoelétrica ( _isoelectric focusing electrophoresis_ ); HPLC: cromatografia líquida de alta resolução ( _high performance liquid chromatography_ ). **Nota:** o exame detecção molecular de mutação em hemoglobinopatias (confirmatório) não é de realização obrigatória, sendo necessário somente nos casos em que, com as metodologias tradicionais, não for possível fechar o diagnóstico.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo crianças ou adultos, de ambos os sexos, com suspeita ou diagnóstico de Doença Falciforme.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Para tratamento com hidroxiureia** -->
Adicionalmente, para o uso de hidroxiureia (HU), é necessário que o paciente apresente os critérios a seguir:  
- Teste de fracionamento da hemoglobina por cromatografia líquida de alta performance (HPLC), eletroforese de  
- hemoglobina, focalização isoelétrica (IEF) ou teste molecular compatível com **DF tipo HbSS, HbSbeta**<sup>**0**</sup> **, HbSbeta**<sup>**+**</sup> **grave e HbSD Punjab e idade maior ou igual a 9 meses** ; **ou**  
- Teste de fracionamento da hemoglobina por HPLC, eletroforese de hemoglobina, IEF ou teste molecular compatível  
- com DF tipo HbSC, HbSD ou HbSbeta-tal e idade maior ou igual a 2 anos.  
**Para tratamento com alfaepoetina**  
Adicionalmente, para o uso de alfaepoetina, é necessário que o paciente apresente idade igual ou superior a 18 anos e um dos seguintes critérios:  
- Teste de fracionamento da hemoglobina por HPLC, eletroforese de hemoglobina, IEF ou teste molecular compatível  
- com DF tipo HbSS ou HbSbeta<sup>0</sup> , esteja em uso de HU e que necessite de mais de três concentrados de hemácias (CH) por ano para manter o nível de hemoglobina igual ou acima de 8,5 g/dL ou que apresente uma redução igual ou maior que 1,5 g/dL da sua hemoglobina basal; **ou**  
- Teste de fracionamento da hemoglobina por HPLC, eletroforese de hemoglobina, IEF ou teste molecular compatível  
- com DF tipo HbSS ou HbSbeta<sup>0</sup> com síndrome de hiper hemólise.  
**Para tratamento com penicilina V (fenoximetilpenicilina)**  
Paciente deve ter até 5 anos de idade.  
**Para realização do transplante de células-tronco hematopoiéticas (TCTH)**  
Para a realização do <u>transplante de células-tronco hematopoiéticas (TCTH) alogênico aparentado mieloablativo</u> (de  
doador familiar **HLA idêntico ou haploidêntico** ), proveniente de sangue de cordão umbilical, sangue periférico ou de medula óssea de doador familiar HLA idêntico ou haploidêntico, o paciente deve apresentar todos os critérios de inclusão a seguir:  
- Eletroforese de Hb ou teste molecular compatível com DF tipo HbSS ou HbSbeta-tal;  
- Paciente em uso de hidroxiureia;  
- Apresente pelo menos uma das seguintes condições:  
- Alteração neurológica devido à acidente vascular encefálico (AVE), com alteração neurológica que persista por mais  
de 24 horas ou alteração de exame de imagem; **ou**  
- Doença cerebrovascular associada à DF; **ou**  
- Mais de duas crises vaso-oclusivas (inclusive síndrome torácica aguda) graves no último ano; **ou**  
- Mais de um episódio de priapismo; **ou**  
- Presença de mais de dois anticorpos em pacientes sob hipertransfusão ou um anticorpo de alta frequência; **ou**  
- Osteonecrose em mais de uma articulação.  
Para a autorização do <u>TCTH alogênico aparentado de medula óssea, de sangue periférico ou de sangue de cordão</u>  
<u>umbilical, do tipo mieloablativo, de</u> **doador familiar HLA idêntico ou haploidêntico** , todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoiéticos – REREME/INCA/MS, conforme as normas estabelecidas no Regulamento Técnico do Sistema Nacional de Transplantes.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem intolerância, hipersensibilidade ou contraindicações aos medicamentos preconizados neste Protocolo.  
Adicionalmente, serão excluídos do tratamento com **hidroxiureia** os pacientes virgens de tratamento que apresentarem <u>qualquer uma das condições a seguir:</u>  
- Contagem de neutrófilos abaixo de 1.500/mm<sup>3</sup> para pacientes acima de um ano de idade, ou 1.000/mm<sup>3</sup> para pacientes  
- abaixo de um ano de idade;  
- Hb abaixo de 4,5 g/dL;  
- Reticulócitos abaixo de 80.000/mm<sup>3</sup> (quando Hb menor que 8 g/dL);  
- Contagem de plaquetas abaixo de 80.000/mm<sup>3</sup> ;  
- Gestantes ou mulheres sexualmente ativas que não estejam em uso de métodos contraceptivos; **ou**  
- Doença hepática ativa (infecção por HBV ou HCV)<sup>30</sup> desde que contraindicada pelo prescritor, se não houver como  
- monitorar a função hepática.  
NOTA 1: A contagem de reticulócitos abaixo de 80.000/mm<sup>3</sup> como critério de exclusão se aplica a pacientes virgens de tratamento, e não àqueles que já iniciaram tratamento com HU, uma vez que a redução de reticulócito é uma resposta esperada, a qual deve ser gerenciada conforme recomendações do tópico de Monitoramento.  
NOTA 2: A infecção pelo vírus HIV não contraindica o uso de HU.  
NOTA 3: Pacientes com sorologia positiva para hepatites B e C poderão fazer uso da HU desde que monitorados mensalmente com provas de função hepática.  
Serão excluídos do tratamento com TCTH, os pacientes que apresentem comorbidades que comprometam o resultado do transplante, avaliada e definida pela equipe de transplante.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **6. CASOS ESPECIAIS** -->
A terapia com hidroxiuréia em crianças com DF tipo HbSC, HbSD ou HbSbeta-tal, menores de 2 anos de idade, deve ser criteriosamente analisada, levando em consideração riscos e benefícios. Nesses casos, pode-se prescrever o medicamento a partir de 9 meses de idade, utilizando os mesmos critérios de inclusão acrescidos de pelo menos um dos seguintes fatores abaixo:  
- Dactilite (no primeiro ano de vida); **ou**  
- Concentração de Hb menor que 7 g/dL (média de 3 valores fora de evento agudo); **ou**  
- Contagem de leucócitos maior que 20.000/mm3 (média de 3 valores fora de evento agudo).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7. TRATAMENTO** -->
As principais manifestações da DF são decorrentes da anemia hemolítica crônica e das crises de vaso-oclusão, que levam a lesões crônicas e progressivas que podem evoluir à insuficiência de múltiplos órgãos. Assim, o tratamento dos pacientes com DF deve ser baseado em evidências e deve envolver ações coordenadas da equipe multiprofissional, com a adoção de condutas voltadas para a prevenção de crises e complicações, prevenção e tratamento de infecções, tratamento adjuvante e tratamento não medicamentoso. Por isso, o conhecimento da fisiopatologia da doença por toda a equipe de saúde é fundamental para que seja possível perceber os sinais e sintomas das crises de falcização além da compreensão sobre a importância de se tratar os agravos em tempo real.  
É de suma importância promover a educação dos pacientes para o autocuidado e das famílias para reconhecer emergências com o objetivo de agilizar o atendimento precoce, principalmente dos quadros agudos como febre e autoesplenectomia.  
São benefícios esperados com o uso dos tratamentos medicamentosos e não medicamentosos previstos neste Protocolo: i) eliminação ou diminuição dos episódios de dor; ii) aumento da produção de HbF; iii) aumento, mesmo que leve, da concentração total de Hb; iv) diminuição dos episódios de STA; v) diminuição do número de hospitalizações; vi) diminuição do número de transfusões; vii) regressão ou estabilização de danos em órgãos ou tecidos; viii) diminuição do risco de infecções; e ix) melhora do bem-estar e da qualidade de vida e maior sobrevida.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.1      Profilaxia de infecções e vacinação** -->
Recomenda-se profilaxia antimicrobiana desde o diagnóstico até os 5 anos de idade, visando a proteção contra as bactérias encapsuladas – cuja frequência é mais comum na infância – e prevenção de complicações infecciosas graves, tais como sepse, meningite e pneumonia, causadas principalmente por pneumococo<sup>40</sup> .  
O fornecimento de profilaxia antibiótica diária deve ser priorizado aos pacientes asplênicos ou hipoesplênicos que apresentam maior risco de infecções graves: jovens, com condições de imunossupressão concomitantes ou com histórico de sepse causada por bactérias encapsuladas. Grupos de alto risco incluem crianças com asplenia/hiposplenismo (até 16 anos), adultos acima de 50 anos de idade, pacientes imunocomprometidos ou aqueles com histórico de sepse<sup>41</sup> .  
Para a maioria das crianças com asplenia/hiposplenismo anatômico ou funcional, recomenda-se profilaxia antibiótica diária até os 5 anos de idade por pelo menos um ano após a esplenectomia, com possibilidade de flexibilização desta idade em pacientes com muitos episódios de infeção até os 5 anos. A indicação de profilaxia pós esplenectomia varia bastante entre especialistas. A tomada de decisão individualizada é recomendada para pacientes sem características de alto risco. A maioria dos especialistas sugerem que, para pacientes com mais de 5 anos de idade, sem características de alto risco, um a dois anos de profilaxia diária após esplenectomia é suficiente quando há declínio geral na incidência de doença pneumocócica<sup>42</sup> .  
O medicamento de escolha é a penicilina V oral (fenoximetilpenicilina em suspensão). Quando administrada em jejum, alcança níveis séricos máximos em 30 minutos e sua eliminação é quase completa após 6 horas. É ativa contra estafilococos (exceto cepas produtoras de penicilinase), estreptococos (grupos A, C, G, H, L e M) e pneumococos. Na impossibilidade de uso por via oral, a penicilina G injetável (benzilpenicilina benzatina intramuscular) deve ser considerada, e no caso de crianças alérgicas à penicilina, deve se utilizar a eritromicina por via oral. Penicilina e amoxicilina são os agentes preferidos para profilaxia diária. Cefalosporinas, fluoroquinolonas e macrolídeos são alternativas às penicilinas.  
A vacinação deverá ser realizada conforme o calendário vacinal do Ministério da Saúde. Adicionalmente, recomenda-se a vacina antipneumocócica polissacarídica não conjugada 23-valente (VPP 23) e a vacina pneumocócica conjugada 13-valente (VPC 13) após os 2 anos de idade, com reforço após 3 a 5 anos, prevista no manual do Centro de Referência de Imunobiológicos Especiais (CRIE) para a asplenia anatômica ou funcional e outras condições associadas a disfunção esplênica, incluindo as hemoglobinopatias<sup>43</sup> . Recomenda-se também a vacina contra influenza, anualmente, para todas as idades em pacientes com DF. A vacina contra COVID-19 está indicada para crianças e adultos com DF, sem restrições<sup>44</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.1 Suporte transfusional** -->
O suporte transfusional é o esteio da terapia para pacientes com doença falciforme e é recomendado no controle agudo e crônico da doença<sup>45</sup> . As estratégias são divididas em transfusão simples e transfusão de troca.  
A **transfusão simples** consiste na utilização de unidades de concentrado de hemácias com o objetivo de restaurar o volume circulante e melhorar a capacidade de transporte de oxigênio. Há riscos de sobrecarga volêmica, sobrecarga de ferro e aumento da viscosidade sanguínea. A fórmula para cálculo do volume de concentrado de hemácias é:  
(𝐻𝑡 𝑑𝑒𝑠𝑒𝑗𝑎𝑑𝑜−𝐻𝑡 𝑖𝑛𝑖𝑐𝑖𝑎𝑙) 𝑥 𝑣𝑜𝑙𝑒𝑚𝑖𝑎 𝑠𝑎𝑛𝑔𝑢í𝑛𝑒𝑎∗ 𝑉𝑜𝑙𝑢𝑚𝑒 (𝑚𝑙) = ~~,~~ 𝐻𝑡 𝑑𝑜 𝑐𝑜𝑛𝑐𝑒𝑛𝑡𝑟𝑎𝑑𝑜 𝑑𝑒 ℎ𝑒𝑚á𝑐𝑖𝑎𝑠∗∗  
Onde: *Volemia sanguínea = peso (kg) x 60; **Ht do concentrado de hemácias = 70%; Ht = hematócrito.  
As situações nas quais a transfusão simples está indicada são:  
- Crise de aplasia de medula e pancitopenia;  
- Quadros infecciosos agudos e progressivos com diminuição de 1,5 g/dl da hemoglobina basal ou Hb abaixo de 7 g/dl;  
- Sequestro hepático ou esplênico agudo;  
- Gestação;  
- Acidente vascular cerebra (AVC) agudo quando a transfusão de troca não estiver disponível;  
- Pacientes com STA e necessidade crescente de oxigênio para manter saturação acima de 95%.  
Já a **transfusão de troca** tem como objetivo remover as hemácias falciformes e substituir por hemácias normais, e pode ser do tipo eritrocitaférese (troca de hemácias automatizada) ou exsanguíneotransfusão parcial manual (troca parcial de sangue). A forma manual consiste em retirar um volume sanguíneo através de flebotomia, ao passo que a forma automatizada é realizada através de processadora automática de células do sangue. A fórmula para cálculo do volume de concentrado de hemácias nas transfusões de troca está apresentada a seguir:  
(𝐻𝑡 𝑑𝑒𝑠𝑒𝑗𝑎𝑑𝑜−𝐻𝑡 𝑖𝑛𝑖𝑐𝑖𝑎𝑙) 𝑥 𝑣𝑜𝑙𝑒𝑚𝑖𝑎 𝑠𝑎𝑛𝑔𝑢í𝑛𝑒𝑎∗ 𝑉𝑜𝑙𝑢𝑚𝑒 𝑑𝑒 𝑡𝑟𝑜𝑐𝑎 (𝑚𝑙) =  
𝐻𝑡 𝑑𝑜 𝑐𝑜𝑛𝑐𝑒𝑛𝑡𝑟𝑎𝑑𝑜 𝑑𝑒 ℎ𝑒𝑚á𝑐𝑖𝑎𝑠∗∗−(𝐻𝑡 𝑖𝑛𝑖𝑐𝑖𝑎𝑙+𝐻𝑡 𝑑𝑒𝑠𝑒𝑗𝑎𝑑𝑜) _,_  
Onde: *Volemia sanguínea = peso (kg) x 60; **Ht do concentrado de hemácias = 70%; Ht = hematócrito  
A transfusão de troca está indicada para situações agudas e crônicas<sup>45–47</sup> , como:  
- Queda da Hb basal com anemia sintomática ou queda aguda na Hb sem reticulocitose;  
- Síndrome torácica aguda (STA), por no mínimo 6 meses após o episódio;  
- Crises álgicas frequentes e intensas;  
- AVC ou infarto cerebral agudo;  
- Ataque isquêmico transitório (AIT);  
- Insuficiência de múltiplos órgãos;  
- Priapismo, se um procedimento urológico não produzir detumescência;  
- Alteração de velocidade no doppler transcraniano;  
- Preparo de cirurgia de grande porte ou cirurgias em órgãos vitais.  
Para reduzir a incidência de uma série de complicações vaso-oclusivas, as transfusões podem ser utilizadas nos casos previstos, profilaticamente, durante a gravidez e no perioperatório<sup>45–47</sup> :  
Recomenda-se a realização anual do ultrassom doppler transcraniano desde os 2 anos até 16 anos de idade. Quando esse exame evidencia o aumento da velocidade da circulação nas artérias cerebrais, sinaliza a previsão do aumento do risco de AVC/AVE e indica o tratamento com regime crônico de transfusões sanguíneas fenotipadas para reduzir a proporção de HbS no sangue.  
A proposta transfusional deve ser individualizada e baseada nas condições clínicas do paciente, e alguns fatores devem ser observados, como idade, adaptação do organismo ao estado de anemia crônica, presença de doença cardiovascular, respiratória ou neurológica, complicações transfusionais anteriores e formas alternativas a transfusão. Transfusões desnecessárias devem ser evitadas devido ao risco de aloimunização e excesso de estoques de ferro. O acúmulo de ferro pode não ser percebido quando a terapia transfusional for irregular e episódica e, por isso, deve-se monitorar os níveis séricos de ferritina.  
Todos os pacientes devem ser fenotipados para ABO, Rh e Kell (K) ao diagnóstico. As hemácias transfundidas devem ser compatíveis para os sistemas Rh e K. Caso surjam anticorpos, a fenotipagem deverá ser estendida. O acesso aos testes imunohematológicos complementares ao diagnóstico são realizados pelos hemocentros públicos. Os testes de confirmação devem ser realizados a partir de seis meses e antes da primeira transfusão de hemácias. Estes testes deverão ser repetidos ao longo do acompanhamento de cada paciente evitando assim a sensibilização precoce aos antígenos de maior importância clínica.  
Independentemente do tipo de transfusão, recomenda-se que o sangue transfundido seja desleucocitado. É importante que o concentrado de hemácias não tenha células falciformes ou traço falciforme; em situações excepcionais de fenótipo raro ou múltiplos anticorpos, o uso de hemácias AS pode ser considerado. O uso apropriado de sangue fenotipados e leucoreduzido e a escolha por transfusão de troca, quando possível, em vez de transfusão simples, são importantes para reduzir a aloimunização e a sobrecarga de ferro, respectivamente<sup>45,48</sup> . O uso de hemocomponentes irradiados é recomendado para os pacientes com DF potencialmente elegíveis ao TCTH<sup>49</sup> , e deve seguir as recomendações do Ministério da Saúde para uso de hemocomponentes<sup>50</sup> .  
Indivíduos com DF têm um alto risco de aloimunização devido às múltiplas transfusões, e pode reduzir a elegibilidade para terapia transfusional crônica, além de dificultar o acesso à sangue compatível necessário no tratamento de eventos agudos<sup>51</sup> . A aloimunização também pode levar a reações transfusionais hemolíticas se o antígeno implicado não for excluído de transfusões futuras. Sem fenotipagem para antígenos Rh e K, a aloimunização ocorre em aproximadamente 30% dos indivíduos com DF que são transfundidos pelo menos de forma intermitente<sup>52</sup> .  
A aloimunização pode levar à hemólise, que normalmente se manifesta como uma reação transfusional hemolítica tardia (DHTR). A prevalência de DHTRs em indivíduos com DF parece estar entre 5% e 10% e, aproximadamente, 50% não são diagnosticadas, o que ressalta a importância da correspondência profilática de antígenos Rh e K<sup>53,54</sup> . Esta é uma complicação potencialmente fatal da terapia transfusional na DF e compreende todos os casos de hemólise pós-transfusional independentemente da fisiopatologia subjacente, como a forma mais grave conhecida como hiper-hemólise.  
Reações transfusionais hemolíticas agudas (AHTRs) também podem ocorrer. As AHTRs são tipicamente causadas por transfusão de sangue de grupo ABO errado, mas em pacientes com DF essas reações geralmente ocorrem devido a anticorpos contra antígenos do grupo sanguíneo não ABO. Também pode ocorrer hemólise autoimune, que consiste no desenvolvimento de anticorpos que reconhecem os eritrócitos do próprio paciente e é mais provável de ocorrer em pacientes que foram previamente aloimunizados. Autoanticorpos foram relatados em 7% a 47% dos pacientes com DF que receberam transfusões<sup>52,55</sup> .  
Qualquer reação hemolítica deve ser tratada como emergência médica. Pacientes com reação transfusional aguda são geralmente tratados de forma semelhante a indivíduos sem DF. O tratamento inclui a interrupção imediata da transfusão e cuidados de suporte conforme necessário, que podem incluir suplementação de oxigênio, manejo das vias aéreas, ressuscitação volêmica ou vasopressores para hipotensão, anti-histamínicos e epinefrina. Em caso de quaisquer reações, deve haver obrigatoriamente a notificação ao centro responsável pela dispensa do hemocomponente e, posteriormente, aos responsáveis pela hemovigilância.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.2 Transplante de células-tronco hematopoiéticas** -->
O TCTH é o único tratamento curativo da doença falciforme. O TCTH alogênico aparentado mieloablativo de sangue de cordão umbilical, de sangue periférico ou de medula óssea está recomendado para o tratamento da DF<sup>56</sup> . Pacientes SS ou Sbeta<sup>0</sup> em uso de HU, com complicações graves, não infecciosas, relacionadas à vaso-oclusão, são potenciais candidatos ao procedimento e seus irmãos devem ser avaliados quanto à compatibilidade através da realização do teste de compatibilidade HLA. Na presença de doador compatível, os familiares devem ser informados sobre essa possibilidade terapêutica. Havendo consentimento, o paciente deverá ser encaminhado para concluir a avaliação em um centro transplantador<sup>56</sup> .  
A idade representa um papel prognóstico importante em qualquer indicação de TCTH e a evidência de benefício é maior em pacientes com menos de 16 anos de idade. Outro fator de risco importante para o sucesso do tratamento com TCTH é o tipo de doador. Pacientes com idade igual ou inferior a 12 anos com um doador irmão HLA compatível apresentam maior sobrevida livre de eventos após três anos. Portanto, a realização da testagem HLA nos irmãos deve ser realizada tão logo as complicações graves se façam presente<sup>57</sup> .  
Assim, não há critério de idade definido neste Protocolo para o transplante em pacientes com DF. Entretanto, recomendase que pacientes SS e Sbeta<sup>0</sup> realizem o estudo de HLA a partir dos 5 anos de idade para identificar as crianças elegíveis para o transplante no futuro.  
A utilização das fontes de células-tronco hematopoiéticas deve considerar os riscos para o doador e os riscos e benefícios para o receptor.  
**7.2.3 Estratégias não medicamentosas para controle da dor**  
Assim como outras condições que causam dor crônica, a atenção integral à saúde e ao bem-estar é de grande relevância. Assim, deve-se orientar familiares e as pessoas com DF sobre a importância da ingestão de líquidos para diminuir a viscosidade do sangue e evitar a desidratação, além de estarem alertas aos fatores desencadeantes das crises vaso-oclusivas. Estes fatores podem incluir: exposição ao frio/ar-condicionado ou mudança brusca de temperatura, quadros de infecção e febre, desidratação, período menstrual, gravidez e fatores psicológicos<sup>58</sup> .  
Abordagens não medicamentosas para o controle da dor crônica incluem apoio psicossocial, terapia cognitivocomportamental, exercícios de relaxamento ou respiração, ioga ou auto-hipnose<sup>59,60</sup> . Intervenções para tratar insônia, estresse, depressão, disfunção social, desnutrição e outros fatores que contribuem para a dor são adjuvantes importantes no controle da dor crônica, semelhantes ao seu papel na prevenção da dor. O uso de um plano de cuidados individualizado pode ajudar a gerenciar e coordenar os cuidados para dor crônica e exacerbações de dor aguda<sup>61</sup> .  
Atividades físicas podem ser benéficas para pacientes com DF, mas devem ser acompanhadas por avaliação criteriosa do estado de saúde do indivíduo, realizada pelo médico, nutricionista e educador físico. A prática de exercícios físicos para este grupo deve ser acompanhada de orientações importantes antes, durante e depois do exercício como: observar a temperatura do ambiente, o grau de hidratação e hipóxia, o estado nutricional, utilização de roupas leves e hidratação constante<sup>58</sup> . Recomendase iniciar com um programa regular de treino leve com progressão gradual e alongamentos para a diminuição da tensão muscular. Além disso, devem-se evitar exercícios constantes por tempo prolongado, devendo este ser interrompido ao primeiro sinal de fadiga. Recomenda-se pausas a cada 20 minutos no exercício físico para evitar o acúmulo de ácido lático, amenizando possíveis dores durante o treinamento<sup>62</sup> . Exercícios aeróbios como caminhada, natação ou ciclismo devem ser estimulados com intensidades variáveis entre 50 a 90% da frequência cardíaca máxima, com duração de 20 minutos<sup>63</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.4 Alimentação e suplementação** -->
A anemia hemolítica crônica na DF leva a um aumento compensatório da atividade eritropoiética, que pode levar a uma série de alterações esqueléticas. Esses efeitos, por sua vez, causam alargamento do espaço medular, afinamento das trabéculas e corticais e osteoporose<sup>64</sup> . Como resultado, indivíduos com DF têm uma alta taxa de deficiência de vitamina D e osteoporose<sup>64</sup> . Além disso, as manifestações inflamatórias, os quadros de vaso-oclusão e infecções frequentes elevam a necessidade energética exigindo uma alimentação balanceada, rica em vitaminas A, C e E, e sais minerais, como zinco e cobre.  
Recomenda-se avaliar a saúde óssea, incluindo ingestão de cálcio e dosagem de vitamina D anual ou semestralmente e medir a densidade óssea aos 12 anos de idade. A dosagem de vitamina D deve ser repetida anualmente e o teste de densidade óssea a cada três anos. A suplementação de vitamina D e cálcio pode auxiliar no metabolismo ósseo, evitando o atraso no crescimento e maturação em crianças e jovens com doença falciforme<sup>65,66</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.5 Suporte fisioterapêutico e respiratório** -->
<mark>A fisioterapia representa um papel importante para melhora da capacidade e condicionamento cardiorrespiratório com cinesioterapia aeróbica monitorada, além de oferecer recursos terapêuticos para controle da dor óssea, como eletroterapia analgésica e eletroacupuntura.</mark>  
A espirometria de incentivo foi identificada como medida importante para prevenir episódios de STA em crianças com DF hospitalizadas por dor vasoclusiva em qualquer localização. A realização de espirometria de incentivo usando 10 respirações máximas a cada duas horas enquanto acordado foi associada a uma taxa significativamente reduzida de desenvolvimento de STA  
versus nenhuma espirometria de incentivo (5% versus 42%)<sup>67</sup> . A prática padrão inclui o uso contínuo de espirometria de incentivo quando um paciente é admitido no hospital ou desenvolve STA<sup>68</sup> .  
Em pacientes com necessidades crescentes de oxigênio ou diminuição do esforço respiratório, a ventilação não invasiva pode ser útil como pressão positiva contínua nas vias aéreas (CPAP) ou pressão positiva nas vias aéreas de dois níveis (BPAP)<sup>69,70</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.6 Saúde bucal** -->
A saúde bucal é um indicador da qualidade de vida e componente indissociável da saúde, especialmente para pacientes com DF. A doença traz implicações para o sistema estomatognático, com repercussões nos diferentes tecidos dentais e ósseos. Além disso, alterações maxilofaciais, como a má oclusão dentária, apresentam forte influência negativa na qualidade de vida, na fisiologia respiratória, além de comprometer a autoestima e autoimagem destes pacientes<sup>71,72</sup> .  
Recomenda-se que todas as pessoas com DF sejam avaliadas periodicamente pela equipe de saúde bucal<sup>73</sup> , uma vez que a atenção clínica odontológica com ações de promoção, prevenção e tratamento, em tempo oportuno, contribuem para redução das complicações na doença<sup>74</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.7 Suporte oftalmológico** -->
As alterações oculares são consequentes aos fenômenos vaso-oclusivos na microcirculação da retina do olho, e as alterações retinianas são as mais importantes para a morbidade ocular na DF. Ao contrário de outras complicações, a retinopatia proliferativa é mais comum em pacientes com HbSC do que em outros genótipos de DF<sup>75</sup> .  
A prevenção e o acompanhamento oftalmológico anual devem iniciar-se na infância, porém, a faixa etária mais acometida pela doença é entre 20 e 39 anos. Recomenda-se que crianças sejam avaliadas com exame oftalmológico, a partir dos 10 anos de idade, continuando anualmente até a idade adulta.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.8 Priapismo** -->
Priapismo é uma ereção involuntária, prolongada e dolorosa do pênis, provocada pela vaso-oclusão nos corpos cavernosos e sem relação com atividade sexual. O priapismo pode ser um fator de risco precoce para o desenvolvimento de outras complicações e é muitas vezes subdiagnosticado<sup>76</sup> . Episódios prolongados podem levar a alterações irreversíveis, incluindo necrose tecidual, fibrose e disfunção erétil.  
Medidas profiláticas consistem no aumento da ingestão de líquidos e esvaziamento frequente da bexiga. A indicação nas primeiras 2 horas nos casos de priapismo é de hidratação, banhos, caminhada, esvaziamento da bexiga, compressas mornas e analgesia. O uso de banhos mornos tem sido adotado com sucesso em episódios leves.  
O priapismo com duração superior a duas a quatro horas é considerado uma emergência médica que requer atenção imediata. Nos casos de persistência, recomenda-se encaminhamento à emergência e hospitalização para esvaziamento da bexiga com cateter, hidratação e analgesia intravenosa, avaliação do urologista e contato com o Centro de Referência ( **Figura 1** )<sup>77</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.9 Úlcera nos membros inferiores** -->
A vaso-oclusão na pele pode produzir úlceras de perna e síndromes miofasciais em pacientes com DF. O mecanismo é multifatorial e envolve comprometimento do fluxo sanguíneo, disfunção endotelial, trombose, inflamação e retardo na  
cicatrização<sup>78</sup> . Esses sintomas podem causar dor significativa, incapacidade física e impactos psicológicos e sociais negativos. Ao exame físico observa-se estigmas de doença venosa (hemossiderose cutânea, dermatoesclerose e proeminência das veias superficiais)<sup>79</sup> . As úlceras de perna geralmente ocorrem após os 10 anos de idade e podem se desenvolver espontaneamente ou após trauma. Os locais típicos incluem o maléolo medial e lateral, ao passo que o envolvimento bilateral é comum<sup>80</sup> . É importante ter atenção quanto à possibilidade de superinfecção das úlceras, principalmente por _Staphylococcus aureus_ , espécies de _Pseudomonas, estreptococos_ ou espécies de bacteroides, mas raramente, causam infecção sistêmica, osteomielite ou tétano<sup>81</sup> . As feridas crônicas podem se desenvolver quando as lesões têm seu processo de cicatrização estagnado por um período de seis semanas ou mais, apesar do tratamento adequado.  
As principais orientações incluem manter a pele hidratada, usar meia e calçado de cano alto. As lesões deverão ser limpas com cloreto de sódio a 4% aquecido entre 36 e 37ºC, e recomenda-se que:  
- Feridas limpas e granuladas devem ser limpas através de jato;  
- Feridas com resíduos ou esfacelo devem ser limpas com gaze seca – realizar fricção ou pressão cuidadosa;  
- Ferida profunda, estreita ou com espaço morto deve-se irrigar através de cateter (uretral ou retal) acoplado à seringa de

---

<!-- METADADOS: doenca: Doença Falciforme | secao: 20 mL; -->
- Ferida extremamente suja, com aderência no leito ou infectada devem ser limpas com gaze seca – realizar fricção com  
- maior força mecânica. Devem ser utilizadas as coberturas e pomadas disponíveis;  
Na pele íntegra peri-lesional estarão indicados: dexametasona creme (antieczematoso) e o óleo mineral (restaurador da barreira epidérmica). Após a cicatrização, usar óleo mineral. A vacinação antitetânica deverá ser atualizada.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.10 Complicações neurocognitivas** -->
<mark>A DF está associada a várias complicações cerebrovasculares e outras complicações neurológicas</mark><sup>82,83</sup> <mark>. A prevenção primária para reduzir o risco de um primeiro AVC baseia-se na avaliação por d</mark> oppler transcraniano <mark>para estratificação de risco e triagem seletiva com angiorressonância magnética cerebral (procedimento 02.07.01.001-3).</mark>  
<mark>O AVC silencioso é definido como uma lesão visível em pelo menos dois planos de imagens de ressonância magnética ponderadas em T2 e pelo menos 3 mm na maior dimensão linear, sem achados associados no exame neurológico</mark><sup>84</sup> <mark>. Apesar de denominadas como silenciosas, estas lesões estão, normalmente, relacionadas com déficits neurocognitivos e comportamentais</mark><sup>85</sup> . <mark>É importante ressaltar que crianças com DF e ressonância magnética normal também apresentaram escores de quociente de inteligência significativamente mais baixos do que controles saudáveis, indicando que outros fatores biológicos e ambientais contribuem para o comprometimento neuropsicológico na DF.</mark>  
<mark>Testes cognitivos validados a serem realizados por profissionais de psicologia podem detectar estas alterações precocemente e devem ser incluídos na atenção à criança e ao adolescente com DF, permitindo assim medidas para neutralizar este déficit</mark><sup>8687,88</sup> .  
O diagnóstico de uma doença crônica e grave como a DF compromete a qualidade de vida dos pacientes e familiares, além de afetar a autoestima e levar ao afastamento da vida social. O desenvolvimento de estratégias ativas de enfrentamento e apoio ao paciente, familiares e cuidadores devem ser incentivados<sup>89,90</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.2.11 Procedimentos cirúrgicos em DF** -->
Pacientes com DF necessitam de cuidados especiais antes, durante e depois de procedimentos cirúrgicos<sup>91</sup> .  
Os **cuidados pré-operatórios** incluem: i) avaliação clínica; ii) hemograma e coagulograma; iii) glicose, ureia, creatinina, hepatograma e exame de urina tipo 1 (EAS); iv) ECG - Risco cirúrgico cardiológico; v) RX de tórax; vi) dosagem de HbA e S;  
vii) avaliação da oxigenação pelo oxímetro de pulso e fisioterapia respiratória; viii) preparo transfusional e estudo imunohematológico com fenotipagem eritrocitária; e ix) manutenção da hidratação plena nas 12 horas do pré-operatório.  
Os **cuidados peri-operatórios** incluem: i) temperatura amena na sala de cirurgia; ii) oxigenação a 50% em combinação com o agente anestésico; iii) monitorização clínica: ECG, pressão arterial, pulso, temperatura, débito urinário; e iv) monitorização laboratorial: dosagem de eletrólitos séricos, concentração de O2 inspirado oximetria de pulso ou gasometria arterial.  
Os **cuidados pós-operatórios** incluem: i) O2 no pós-operatório imediato; ii) oximetria de pulso; iii) hidratação parenteral; e iv) fisioterapia respiratória.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.3.1    Prevenção de crises e complicações** -->
A hidroxiureia (HU) atua na inibição da enzima ribonucleotídeo redutase, e leva a aumento da produção de HbF, da hidratação do glóbulo vermelho, da taxa hemoglobínica e da produção de óxido nítrico além de reduzir a hemólise e a expressão de moléculas de adesão.  
Até o momento, a HU é considerada a terapia medicamentosa mais eficaz da DF, sendo um pilar no tratamento da doença, uma vez que o uso da HU reduz em 40% o risco de óbito e diminui significativamente o número anual de episódios álgicos agudos e outros eventos vaso-oclusivos. Além disso, reduz em cerca de 50% as necessidades transfusionais e o número de episódios de síndrome torácica aguda<sup>22,92–101</sup> . Observação por 9 anos levou Steinberg et al. a concluírem que a HU pode ser usada indefinidamente pelos pacientes de que dela necessitam<sup>101</sup> .  
A prescrição de HU para a população pediátrica tem demonstrado claros benefícios, e o medicamento é bem tolerado, podendo prevenir tanto o infarto esplênico quanto as manifestações neurológicas, como as convulsões, paralisias, distúrbios da fala, cegueira transitória e alterações da consciência<sup>95–99,102–104</sup> . A terapia com HU apresenta risco, apesar de baixo, de toxicidade hematológica, necessitando de monitorização das contagens de células sanguíneas. O potencial carcinogênico e teratogênico, apesar de ter sido assinalado in vitro, não foi comprovado _in vivo_<sup>105</sup> .  
A doença renal crônica (DRC), inicialmente manifestada por proteinúria, é frequente nos pacientes com DF nos subtipos HbSS e HbSbeta0<sup>106</sup> , e é uma causa conhecida de anemia relacionada ao déficit relativo de eritropoietina endógena (EPO)<sup>107</sup> , definido como níveis de EPO abaixo do esperado para o nível de hemoglobina (Hb). Dessa forma, o uso de alfaepoetina humana recombinante está indicado para pacientes destes subtipos que estejam em uso de HU e que apresentam queda na contagem de hemoglobina ou necessidade frequente de transfusões sanguíneas para manter a hemoglobina basal.  
Pacientes com indicação para TCTH devem ter o tratamento com HU suspenso quatro semanas antes do início do condicionamento para o transplante e apenas reintroduzido caso não ocorra a pega do transplante. É necessário observar que, frequentemente, na DF o quimerismo é misto, ou seja, ocorre a pega parcial do enxerto do doador, o que não invalida o resultado e, neste caso a HU não deve ser reintroduzida. A reintrodução da HU deverá ser realizada pelo médico assistente apenas no caso de ausência total de pega (quimerismo do receptor em 100% das células testadas).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.3.2   Tratamento de infecções** -->
A rápida identificação e encaminhamento dos casos de infecção são fundamentais no cuidado da DF, já que estes podem evoluir rapidamente para choque séptico e óbito devido ao comprometimento imunológico. Pacientes, familiares e profissionais de saúde devem estar atentos aos sinais e sintomas de infecção, que são: febre, prostração, toxemia, hipóxia, vômitos,  
desidratação, sintomas respiratórios, dor. A presença de febre deve ser encarada como situação de urgência, e temperatura corporal acima de 38,2°C em crianças abaixo de 3 anos de idade pode sugerir bacteremia-sepse.  
Pacientes com sinais e sintomas de infecção atendidos na Atenção Primária deverão ser transportados para o serviço de urgência, e o Centro de Referência deverá ser notificado. Na admissão ao serviço médico, devem ser colhidos os seguintes exames: hemograma com reticulócitos, urina tipo I, PCR, hemo/urocultura, e raio-x de tórax. A coleta do líquor deverá ser realizada nos casos de toxemia ou suspeita de infecção de sistema nervoso central (SNC).  
Nos quadros febris sem foco infeccioso definido, deverá ser feita a cobertura para germes encapsulados ( _S.pneumoniae_ e _H-influenzae_ ), com penicilina ou amoxicilina+clavulanato. Na presença de foco infeccioso definido, a escolha do antibiótico dependerá do sítio de infecção, sendo recomendado:  
- nos casos de STA: a associação de macrolídeo (claritromicina ou azitromicina);  
- nos casos de meningite: antibiótico com penetração no sistema nervoso central (ceftriaxona);  
- em casos suspeitos de infecção por _Mycoplasma pneumoniae_ : associar estolato de eritromicina, claritromicina ou  
- azitromicina, e;  
- em caso de osteomielite: hidratação, analgesia e antibiótico por via intravenosa durante 4 a 6 semanas. A cobertura deve  
- contemplar _S. aureus_ e _Salmonella sp_ .  
Nos casos de COVID-19, como a DF tem maior tendência à hipercoagulabilidade<sup>108</sup> , podem ocorrer, com mais frequência, complicações bacterianas, ao lado de comorbidades como doença cardíaca, hipertensão pulmonar, asma, doença renal e doença cerebrovascular.  
É recomendado um rigoroso acompanhamento do paciente, pois mesmo aqueles com sintomas leves podem evoluir para doença grave, e devem ser internados ao menor sinal de complicação<sup>109</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.3.3 Suplementação com ácido fólico** -->
Pacientes com anemia hemolítica hereditária podem apresentar demanda aumentada por ácido fólico devido ao aumento da eritropoiese<sup>110</sup> . O folato pode ser obtido de fontes alimentícias naturais como leite (materno e de vaca), gema de ovo, frutas cítricas (laranja, limão, acerola, tangerina, além da banana), feijão, legumes e vegetais de folhas verdes (batata, aspargos, bertalha, espinafre, couve e brócolis) e fígado. Além disso, diversos produtos alimentícios estão sendo suplementados com folato, como farinhas, bolachas e leite em lata.  
A indicação para suplementação com ácido fólico está restrita a situações de baixa dosagem de ácido fólico sérico e em condições específicas, como a gravidez.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.3.4 Sobrecarga de ferro transfusional** -->
Uma das consequências do suporte transfusional é a sobrecarga de ferro no organismo, que pode ocorrer com transfusões esporádicas ou em programas de transfusão crônica como nos casos em que o exame ultrassom doppler transcraniano sinaliza risco de AVC/AVE e as transfusões tornam-se frequentes e regulares.  
O tratamento da sobrecarga de ferro deve seguir o **Protocolo Clínico e Diretrizes Terapêuticos da Sobrecarga de Ferro** vigente do Ministério da Saúde.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.3.5 Analgesia** -->
Os mecanismos de dor crônica diferem da dor aguda e podem incluir sensibilização central e hiperalgesia. A dor crônica na DF difere da dor crônica em outros contextos (p. ex., dor oncológica), por ser tipicamente intercalada com dor aguda episódica e crescente, e apresenta um componente maior de dor neuropática, sensibilização periférica e central e hiperalgesia com opióides<sup>111</sup> .  
O objetivo do controle da dor é maximizar o funcionamento e a qualidade de vida ao longo de décadas, em vez de fornecer cuidados paliativos de curto prazo. O uso apropriado dos analgésicos com dose fixa em intervalos específicos é fundamental para o controle da dor nas crises vaso-oclusivas, e a escolha do analgésico deve se basear no grau de intensidade da dor, avaliado através de escala. Todavia, o controle da dor deve ser individualizado de acordo com as causas, intensidade e duração, e alguns indivíduos podem preferir evitar medicamentos crônicos, enquanto aqueles com dor na maioria dos dias podem precisar de opioides diários. A escala da dor pode guiar o tratamento, monitorar a resposta e predizer o tempo de hospitalização<sup>112,113</sup> .  
Pacientes com DF podem receber opioides fortes quando não responderem a analgésicos, anti-inflamatórios e opioides fracos, e devem seguir o **Protocolo Clínico e Diretrizes Terapêuticos da Dor Crônica vigente.**  
Também é importante que a equipe de saúde esteja atenta a outras causas de dor que podem requerer diferentes terapias para usar as intervenções mais eficazes e apropriadas, bem como para evitar toxicidades do uso crônico de opioides quando estes não forem a terapia ideal. Exemplos são dor ortopédica por necrose avascular (NAV), fraturas por compressão e as artropatias, as quais podem ser tratadas cirurgicamente. Dor vasoclusiva aguda associada ao início da dor do ciclo menstrual, que pode ser tratada com terapias hormonais ou anti-inflamatórios não esteroides (AINEs)<sup>114</sup> . O priapismo pode ser extremamente doloroso e a analgesia adequada não deve ser suspensa enquanto se aguarda a consulta urológica ou os resultados de exames de imagem ou exames laboratoriais.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.3.6 Suplementação de ferro** -->
A anemia na DF não é decorrente de deficiência de ferro, ao passo que esta deficiência é relativamente incomum na DF em geral. Sua ocorrência é afetada pelo genótipo da hemoglobina, idade, geografia e fatores de risco concomitantes. A deficiência de ferro é mais comum em indivíduos com doença da HbSC, com evidência de deficiência de ferro contínua em até 20% dos bebês não transfundidos com esse genótipo. Isto é particularmente verdadeiro em regiões menos desenvolvidas. Até 10% das mulheres adultas jovens com DF de regiões com recursos limitados podem ter deficiência de ferro.  
Portanto, a suplementação de ferro não é preconizada a todos os pacientes, já que sua indicação deve ser guiada pelos marcadores de ferritina, ferro e transferrina. Nos casos de desnutrição ou dosagem de ferro, saturação de transferrina e ferritina diminuídas, é preconizada a suplementação de ferro, por período suficiente apenas para a correção do problema<sup>115</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.3.7   Medicamentos** -->
- Ácido fólico: comprimidos de 5 mg e solução oral de 0,2 mg/mL;  
- Alfaepoetina humana recombinante: pó para solução injetável e em solução injetável nas concentrações de 1.000, 2.000,  
- 3.000, 4.000 e 10.000 UI;  
- Amoxicilina: cápsulas e comprimidos de 500 mg e suspensão oral de 50 mg/mL;  
- Amoxicilina+clavulanato: cápsula de 50 mg; comprimido de 50 mg e suspensão oral de 50 mg/mL;  
- Azitromicina: comprimidos de 250 e 500 mg e pó para suspensão oral de 40 mg/mL;  
- Benzilpenicilina benzatina: pó para suspensão injetável de 600.000 e 1.200.000 UI;  
- Cefalexina: cápsulas e comprimidos de 500 mg e suspensão oral de 50 mg/mL;  
- Ceftriaxona: pó para solução injetável de 250 mg, 500 mg e 1 g;  
- Estolato de eritromicina: suspensão oral de 25 mg/mL e 50 mg/mL e comprimidos de 500 mg;  
- Fenoximetilpenicilina potássica: pó para solução oral de 80.000 UI/mL;  
- Hidroxiureia: cápsulas de 500 mg e comprimidos revestidos de 100 mg.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Hidroxiureia** -->
A dose inicial recomendada de HU é 15 mg/kg/dia, por via oral, em dose única. Aumentar em 5 mg/kg/dia a cada 4 semanas até atingir a dose máxima de 35 mg/kg/dia ou a ocorrência de toxicidade hematológica ou outros eventos adversos graves (ver seção **Critérios de interrupção** )<sup>92,93</sup> .  
Para crianças de até 25 kg, recomenda-se a prescrição da apresentação de 100 mg em comprimido revestido. Os comprimidos podem ser fracionados conforme a dose indicada, e desintegrados imediatamente antes do uso em uma pequena quantidade de água. Cabe destacar que o comprimido revestido de 100 mg pode ser partido em duas partes iguais (50 mg cada), o que deve ser considerado para o cálculo da dose e orientações ao paciente. Já em pessoas acima de 25 kg, a cápsula de 500 mg pode ser dissolvida em 10 mL de água destilada ou filtrada, obtendo a concentração de 50 mg/mL, o que facilita a administração da dose correta por peso, utilizando uma seringa descartável.  
Um estudo de estabilidade publicado em 2022 apontou que manipulações da preparação líquida oral de HU permaneceram estáveis por 90 dias em frascos de plástico âmbar e 14 dias em seringas de plástico âmbar<sup>116</sup> .  
Por se tratar de fármaco citotóxico, recomenda-se que a manipulação da solução ocorra em farmácias de manipulação, seguindo as boas práticas de manipulação de preparações magistrais e oficinais<sup>117</sup> . Entretanto, a disponibilização de preparação líquida pelo SUS depende da existência de Protocolos regionais e serviços de saúde com recursos físicos e humanos para preparar e distribuir as soluções.  
O tratamento com HU deve ser mantido por tempo indeterminado enquanto houver resposta clínica e laboratorial. Cerca de 25% dos pacientes não apresentam resposta satisfatória à HU, condição que pode determinar, a critério médico, a suspensão do tratamento após 2 anos de uso.  
Para um indivíduo que não apresente a resposta esperada ao tratamento, é importante revisar a administração do medicamento. A adesão a medicamento em doença crônica deve ser revista pela equipe de saúde e otimizada, mostrando ao paciente os benefícios do medicamento.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Alfaepoetina** -->
A dose recomendada de alfaepoetina é de 12.000 UI, divididas em três aplicações por semana (4.000 UI por aplicação),  
administrada por via subcutânea ou intravenosa.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Profilaxia antimicrobiana** -->
O esquema profilático preconizado desde o diagnóstico até os 5 anos de idade está descrito no **Quadro 3** a seguir.  
**Quadro 3.** Tratamento profilático recomendado para crianças de 3 meses a 5 anos de idade.  
|**Medicamento**|**Critérios**|**Esquema de administração**|
|---|---|---|
|**Penicilina**<br>**V**<br>**oral**|Crianças menores de 3 anos de idade ou|125 mg (equivalente a 200.000 UI ou 2,5 mL)|
|**(fenoximetilpenicilina)**|peso de até 15 kg|a cada 12 horas (250 mg/dia)|  
|**Medicamento**|**Critérios**|**Esquema de administração**|
|---|---|---|
||Crianças acima de 3 anos de idade ou|250 mg (equivalente a 400.000 UI ou 5 mL) a|
||peso entre 15 e 25 kg|cada 12 horas (500 mg/dia)|
|**Benzilpenicilina benzatina IM**|Pacientes com peso até 10 kg|300.000 UI a cada 4 semanas|
|<br>**(penicilina G)***|Pacientes com peso entre 10 e 20 kg|600.000 U a cada 4 semanas|
||Pacientes acima de 20 kg|1.200.000 U a cada 4 semanas|
|**Estolato de eritromicina oral**|Em caso de alergia à penicilina|20 mg/kg duas vezes ao dia (40 mg/kg/dia)|  
**Fonte:** elaboração própria. **Legenda** : IM: intramuscular; * Na impossibilidade de uso por via oral. A via oral deve ser retomada logo que possível.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Antibioticoterapia nas infecções** -->
Os esquemas de antibioticoterapia nas infecções estão descritos no **Quadro 4** a seguir. A duração da antibioticoterapia dependerá do sítio da infecção.  
**Quadro 4.** Antibioticoterapia recomendada.  
|**Situação**|**Critérios**|**Medicamento e esquema de administração**|
|---|---|---|
|**Esquema básico**|Crianças menores de 5 anos|Amoxicilina: 50 a 100 mg/kg/dia IV de 8/8 horas|
||Crianças acima de 5 anos|Penicilina G cristalina 100.000 a 250.000 U/Kg/dia IV 6/6 horas|
||Adultos|Penicilina G cristalina 1.000.000 a 5.000.000 UI/dia IV 6/6 horas;<br>dose máxima de 24.000.000 UI/dia|
|**Esquema**|Crianças|Ceftriaxona 50 a 75 mg/kg/dia, IV, 12/12 horas (máx. 4 g/dia)|
|**alternativo**|Adultos|Ceftriaxona 1 a 2g/dose IV, 12/12 horas (máx. 4 g/dia)|  
**Fonte:** elaboração própria. **Legenda** : IM: intramuscular; IV: intravenosa  
Em caso de suspeita de infecção por _Mycoplasma pneumoniae_ , deve-se associar estolato de eritromicina, claritromicina ou azitromicina. Nos casos de meningite, deverá ser usado antibiótico que atinja o sistema nervoso central (ceftriaxona). A dose recomendada é de 100 mg/kg/dia, por via endovenosa, com duração mínima de 10 dias de tratamento.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Antibióticos alternativos** -->
- Amoxicilina 10 mg/kg duas vezes ao dia (máximo 250 mg por dose);  
- Azitromicina 5 mg/kg uma vez ao dia (máximo 250 mg por dose);  
- Cefalexina 25 mg/kg duas vezes ao dia (máximo 250 mg por dose);

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Ácido fólico** -->
A recomendação internacional é de suplementação com 1 mg/dia de ácido fólico. Caso a dosagem de ácido fólico sérico  
não esteja disponível, recomenda-se orientação alimentar e o uso de meio comprimido (2,5 mg) três vezes por semana para crianças com até 01 ano ou até 10 kg. Para pacientes a partir de 10 kg ou 01 ano de idade, recomenda-se um comprimido (5 mg) três vezes por semana.  
Estudos mostram que **ácido fólico** acima de 17 ng/mL no sangue está associado ao aumento de expressão de citocinas inflamatórias e diminuição dos linfócitos _natural killer_<sup>118</sup> . Por isso, recomenda-se manter os níveis de ácido fólico sérico abaixo de 17 ng/mL.  
**Quelantes de ferro**  
O uso de quelantes de ferro deverá seguir as orientações do **Protocolo Clínico e Diretrizes Terapêuticas da Sobrecarga**  
**de Ferro vigente** do Ministério da Saúde.  
**Analgésicos**  
O uso de analgésicos deverá seguir as orientações do **Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica vigente** do Ministério da Saúde.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.4.1   Complicações renais** -->
A nefropatia na doença falciforme (DF) compreende todas as anormalidades estruturais e funcionais renais encontradas nesta doença. A triagem inclui dosagem de creatinina sérica e exame de urina para avaliação de proteinúria e albuminuria, geralmente realizada por volta dos três a cinco anos de idade<sup>119</sup> . Na idade adulta, monitorar 4 a 6 vezes ao ano.  
Hemodiálise ou transplante renal são opções de tratamento para indivíduos com DF que desenvolvem insuficiência renal. Os inibidores da ECA devem ser utilizados precocemente podendo reverter, junto com a HU, a evolução da doença renal<sup>120</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.4.2   Complicações cardíacas e pulmonares** -->
A hipertensão pulmonar arterial (HAP) é frequente em indivíduos com DF, porém os sintomas são variáveis e inespecíficos (dispneia crônica, dor torácica, pré-síncope, redução da tolerância ao exercício ou apenas redução das atividades diárias sem sintomas específicos).  
O diagnóstico e tratamento da HAP deve seguir o **Protocolo Clínico e Diretrizes Terapêuticos de Hipertensão Pulmonar vigente** do Ministério da Saúde. O teste de esforço é um exame útil e não invasivo que complementa a triagem com velocidade de regurgitação do jato tricúspide realizada pelo ecocardiograma transtorácico. Para indivíduos com DF que não apresentam sintomas respiratórios, a triagem para hipertensão pulmonar deve ser iniciada medindo a velocidade de regurgitação do jato tricúspide, usando ecocardiografia com Doppler trans torácico no final da adolescência ou na idade adulta. Considera-se possível HAP quando a PAP sistólica for maior que 30 mmHg<sup>121</sup> . O diagnóstico definitivo de HAP é dado através do cateterismo direito<sup>121</sup> .  
A cardiomiopatia está sendo cada vez mais identificada em indivíduos com DF, especialmente disfunção diastólica do lado esquerdo, com e sem HAP concomitante e possíveis fatores estão relacionados: HAP, anemia crônica e hipoxemia com aumento do débito cardíaco, aumento do volume sistólico do ventrículo esquerdo e dilatação do ventrículo esquerdo, sobrecarga de ferro transfusional, hipertensão e alterações no volume intravascular associadas a vasculopatia e insuficiência renal<sup>122,123</sup> .  
A fibrose miocárdica difusa é comum em indivíduos com DF e está associada à disfunção atrial esquerda, aumento da velocidade da regurgitação tricúspide, redução da capacidade de exercício e risco de arritmia. Cardiomiopatia restritiva com disfunção diastólica e aumento do átrio esquerdo podem ser encontradas em crianças a partir de 11 anos de idade. A velocidade de regurgitação tricúspide (TRV) elevada e possivelmente a HP secundária podem ser decorrentes de um defeito cardíaco primário.  
A realização do ecodoppler cardíaco e exercício de caminhada de 6 minutos devem ser realizados para monitoramento e identificação precoce desta complicação. As abordagens terapêuticas não diferem das abordagens da população sem DF<sup>121,124</sup> . Contudo, o uso de HU pode retardar o aparecimento de complicações crônicas da doença.  
A circulação arterial pulmonar tem baixa tensão de oxigênio e baixo fluxo, ambos facilitam a falcização. Várias complicações agudas e crônicas são observadas, incluindo STA, asma, distúrbios respiratórios do sono, fibrose pulmonar, doença tromboembólica e hipertensão pulmonar (HP). Anormalidades nos testes de função pulmonar ou baixa saturação de oxigênio também podem ser observadas.  
**7.4.3   Gestação e contracepção**  
Gestantes com DF podem apresentar disfunção placentária em grau variado, maior frequência de infecções (principalmente em trato urinário e sistema respiratório) durante a primeira metade da gestação, maior incidência de parto prematuro e aumento da mortalidade perinatal.  
As bacteriúrias devem ser tratadas, pois causam crescimento intrauterino restrito (CIUR) e parto prematuro. Pode haver piora do quadro de anemia por aumento da demanda por sangue, hemodiluição, supressão da medula, infecção ou inflamação, deficiência de vitaminas e/ou ferro e crises aplásticas<sup>125,126</sup> .  
Mulheres com DF devem ser informadas sobre os riscos relacionados à gravidez que incluem CIUR, eclâmpsia, préeclâmpsia, infecções por asplenia, tromboembolismo venoso, aloimunização, diabetes gestacional e parto prematuro. Além disso, abortos são mais frequentes em DF, especialmente em pacientes HbSS e, em alguns casos, a puberdade tardia pode retardar a 1ª gravidez<sup>125,126</sup> .  
O cuidado neonatal é primordial para reduzir mortalidade perinatal e é importante garantir cuidados obstétricos em clínica para gestação de alto risco. O atendimento especializado à mãe deve incluir ultrassonografia, perfil biofísico fetal, doppler do cordão umbilical e cesariana com indicação obstétrica. Recomenda-se comparecimento regular às consultas, evitar desidratação e procurar atendimento médico em caso de febre ou crise vaso oclusiva.  
Todos os medicamentos considerados inseguros para o feto devem ser descontinuados, incluindo HU, quelantes de ferro (desferal, desferioxamina ou deferiprona) e inibidores da ECA. Em mulheres que planejem engravidar, a HU deve ser descontinuada aproximadamente 3 meses antes da concepção pela insegurança ao feto e o retorno após o parto deve ser avaliado (ver seção de monitoramento deste PCDT). Durante a gravidez, recomenda-se uma dose maior de ácido fólico (5 mg/dia).  
Crises de dor são mais frequentes no final da gestação e são tratadas da mesma forma que na paciente não grávida. O uso de anti-inflamatórios não esteroidais (AINEs) durante uma crise de dor deve ser restrito, entretanto, a literatura apoia seu uso entre 18 e 30 semanas de gestação. Após 30 semanas, os AINEs devem ser evitados devido ao risco de fechamento precoce do canal arterial<sup>127,128</sup> .  
Normalmente, as pacientes grávidas só iniciam o tratamento de transfusão mensal em caso de dificuldades com gestações anteriores ou tenham doença muito grave. No entanto, transfusões intermitentes podem ser usadas em caso de anemia exacerbada, afastando-se significativamente de sua linha de base (tipicamente < 7 g/dL) ou anemia sintomática. Lesões extensas na placenta que ocorrem precocemente não se beneficiam de transfusões tardias<sup>129</sup> .  
O atendimento inicial à gestante com DF deve contemplar<sup>130</sup> :  
- História clínica informando sobre presença de doença renal, hipertensão, fumo, drogas e alergias;  
- História obstétrica informando o número de partos e abortos, idade gestacional em que ocorreram, peso dos nascituros,  
- tipos de parto e complicações durante e após as gestações ou abortos;  
- Eletroforese de Hb do pai para orientação sobre a doença no feto;  
- Exames laboratoriais: hemograma, reticulócitos, ferritina, bilirrubinas, TGO, TGP, LDH, fosfatase alcalina, glicose, ureia, creatinina, ácido úrico, sorologias para hepatite A, B e C, HIV 1 e 2, HTLV 1e 2, CMV, rubéola IGG e IGM, toxoplasmose, VDRL, TSH, T4 Livre, FTA-ABS-IgG e IgM, 25-hidroxivitamina D e Herpes Simples 1 e 2 – IgG, proteinúria de 24 horas, estudo imunohematológico, parasitológico de fezes, EAS e urinocultura. Repetir ao final do 1º, 2º e 3º trimestres;  
- Ultrassonografia e doppler;  
- Avaliação e atualização da vacinação materna com imunização para pneumococos, hepatite e Haemophilus influenza,  
- como também, tétano, difteria e coqueluche (DTPA);  
- Avaliação da nutrição materna, hidratação, pressão arterial, oximetria de pulso, ganho de peso, fundo uterino e exame  
- de colo uterino.  
O método contraceptivo recomendado disponível no SUS inclui o acetato de medroxiprogesterona 150 mg, intramuscular trimestralmente. Deve-se optar primeiramente pelo uso de progestágenos em detrimento dos contraceptivos hormonais combinados (estrogênio/progesterona) em decorrência do menor risco de trombose. O DIU de cobre pode ser indicado como método contraceptivo, porém deve-se observar a ocorrência de aumento do fluxo menstrual. Recomenda-se avaliação da densitometria óssea antes de prescrever contraceptivo com progestágeno, devendo ser repetido a cada dois anos.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Síndrome torácica aguda** -->
A síndrome torácica aguda (STA) é definida pela presença de infiltrado pulmonar recente (não atelectásico) no raio X (RX) de tórax. É um quadro respiratório que pode incluir um ou mais dos seguintes sintomas: dor torácica intensa, tosse, febre, sintomas respiratórios, hipoxemia e/ou novo infiltrado ao RX de tórax. A STA, requer internação de urgência). Saturação de oxigênio abaixo de 93% sinaliza necessidade de encaminhamento para a Unidade de Terapia Intensiva (UTI), já que esta condição é grave e pode levar a óbito.  
Em casos de STA, recomenda-se internação e monitoramento de hemograma, contagem de reticulócitos, hemocultura, saturação de oxigênio (O2) e RX de tórax (se normal, repetir a cada 24 horas, em pacientes com dor torácica ou crise severa). O uso de oxigênio (O2) suplementar pode ser necessário para manter a saturação de oxigênio igual ou acima de 93% ou dentro de 3% da saturação de O2 da linha de base. Broncodilatadores e fisioterapia respiratória também podem ser utilizados. A volemia deve ser mantida normal, evitando hidratação excessiva e bolus de fluido intravenoso de rotina devido ao risco de induzir edema pulmonar.  
Transfusão simples de concentrado de hemácias pode ser necessária para melhorar a capacidade de transporte de oxigênio quando a queda dos níveis basais de Hb for igual ou maior a 1,5 g /dL. Após recuperação do quadro, deverá ser mantido em programa de transfusão de troca por no mínimo 6 meses. Transfusão de sangue pode não ser necessária para pacientes com Hb maior ou igual a 9 g/dL. No entanto, em caso de rápida progressão da STA com agravamento da dificuldade respiratória, considerar transfusão de troca ou transfusão simples em caráter de urgência.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Sequestro esplênico** -->
O sequestro vai recorrer em até 50% daqueles que tiveram o 1º episódio, e a esplenectomia é frequentemente usada após o primeiro evento agudo para prevenir a recorrência após os 5 anos<sup>131</sup> . É importante orientar os familiares quanto à palpação do baço, e alertá-los sobre esta complicação e sua gravidade. O abaixador de língua é uma ferramenta de fácil acesso e que pode ser utilizada pelo médico assistente, durante a consulta. Utilizando como eixo o gradil costal e direcionando o abaixador para a região umbilical, marca-se o abaixador de língua entregando-o a mãe que assim terá o tamanho inicial do baço.  
Crises de sequestro esplênico requerem tratamento de emergência, devido à velocidade de sua evolução, com imediata transferência para o hospital e comunicação ao Centro de Referência ( **Figura 1** ). Na internação, é importante garantir acesso venoso para hidratação do paciente devido à possibilidade de choque hipovolêmico. Recomenda-se utilizar, preferencialmente, expansor plasmático na dose de 10 a 15 mL/kg. Na ausência deste, infundir 40 a 100 mL/kg de soro fisiológico em 2 horas em etapa rápida. Recomenda-se repouso absoluto com uso de oxigenoterapia por máscara, e elevação de membros inferiores.  
Durante as crises, pacientes podem se beneficiar de transfusão de 10 mL/kg de concentrado de hemácias, a fim de alcançar níveis de Hb de 6 a 7 g/dL. Entretanto, deve haver atenção para a volemia quando o sequestro é controlado, pois há risco de hiperviscosidade por aumento súbito da hemoglobina.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Síndrome de hiper-hemólise** -->
Síndrome hiper-hemolítica é uma exacerbação súbita da hemólise com piora da anemia, apesar da produção contínua de reticulócitos. A hiper-hemólise é uma reação potencialmente fatal que pode ocorrer após a transfusão. Alguns episódios foram  
documentados em pacientes com múltiplas transfusões, consistentes com uma reação transfusional hemolítica tardia na qual as células transfundidas, bem como as células do próprio paciente, são hemolisadas ("hemólise do espectador")<sup>132,133</sup> .  
A hiper-hemólise e outras reações hemolíticas graves são definidas como hemólise associada à transfusão com um rápido declínio da Hb abaixo do nível pré-transfusão. A pós-transfusão requer intervenção imediata, mas as evidências para orientar a terapia ideal são limitadas<sup>45</sup> . O tratamento deve incluir hidratação e início imediato da terapia imunossupressora com glicocorticoide (1 a 4 mg/kg de prednisona por dia ou dose equivalente de metilprednisolona), imunoglobulina intravenosa (IgIV) (0,4 a 1 g/kg por dia por três a cinco dias) ou ambos, especialmente para aqueles que necessitam de transfusões adicionais. A escolha entre glicocorticoides, IgIV ou ambos deve ser individualizada<sup>134</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **8.1. Hidroxiureia** -->
O acompanhamento do uso da HU por pacientes com DF deve ser realizado com o objetivo de avaliar a efetividade clínica e segurança do tratamento. Os exames listados para a avaliação inicial no **Quadro 5** são recomendados para a detecção precoce das complicações no início do tratamento. Já os exames de Monitoramento devem ser considerados conforme avaliação médica para orientar o tratamento e a necessidade de ajustes de dose e, portanto, não devem ser interpretados como exames obrigatórios para dispensação e continuidade do tratamento<sup>135</sup> .  
**Quadro 5** . Esquema de monitoramento clínico a ser realizado pelo médico assistente, dos pacientes com DF em uso de HU.  
|**Exames**|**Avaliação**<br>**inicial**|**Monitoramento (recomendado para ajuste de dose)**|
|---|---|---|
|Eletroforese de Hb|x|Não recomendado|
|Dosagem de HbF|x|A cada 8 a 12 semanas até atingir a dose de manutenção;<br>após, a cada 6 meses.|
|Hemograma com contagem de plaquetas,<br>reticulócitos e avaliação de VCM|x|A cada 2 semanas até atingir a dose de manutenção; após,<br>a cada 12 semanas.|
|Sorologias para hepatite B, hepatite C e HIV|x|Não recomendado|
|Dosagem sérica de creatinina, TGO/AST e<br>TGP/ALT|x|A cada 4 semanas até atingir a dose de manutenção; após,|
|Dosagem sérica de Beta-HCG ou teste rápido<br>de gravidez|x|a cada 12 semanas.|  
**Fonte:** elaboração própria. **Legenda** : GGT: gama-glutamil-transferase; Hb: hemoglobina; HbF: hemoglobina feral; TGO/AST: transaminase glutâmico oxalacética/ aspartato aminotransferase; TGP/ALT; transaminase glutâmico pirúvica/alanina aminotransferase; VCM volume corpuscular médio.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Critérios de interrupção** -->
Em caso de toxicidade demonstrada por exames laboratoriais, a HU deve ser suspensa até a recuperação hematológica, caracterizada pela verificação de parâmetros hematológicos aceitáveis. A dose de reinício do tratamento é 5 mg/kg/dia menor que a dose em uso no momento da intoxicação, seguindo a mesma escala de aumento progressivo a cada 4 semanas. Deve-se seguir os mesmos critérios de controle até a dose máxima tolerada para cada caso específico, respeitando-se a dose máxima diária de 35 mg/kg/dia<sup>92,100</sup> . Caso haja ocorrência de toxicidade duas vezes para a mesma dose, esta passa a ser considerada a dose máxima tolerada e não deverá ser mais utilizada.  
Os parâmetros hematológicos para avaliação da toxicidade da HU estão apresentados no **Quadro 6** a seguir<sup>100</sup> .  
**Quadro 6.** Parâmetros hematológicos para avaliação de toxicidade e ajuste de dose da HU.  
|**Parâmetro**|**Níveis aceitáveis**|**Níveis tóxicos**|
|---|---|---|
|**Neutrófilos (cel/mm**<sup>**3**</sup>**)**|Maior que 2.000*|Menor que 1.500*|
|**Plaquetas (cel/mm**<sup>**3**</sup>**)**|Maior que 85.000|Menor que 80.000|
|**Hemoglobina (g/dL)**|Maior que 5,3|Menor que 4,5|
|**Reticulócitos (cel/mm**<sup>**3**</sup>**)**<sup>*****</sup>|Maior que 95.000|Menor que 80.000|  
**Fonte** : Adaptado de Platt, 2008<sup>92</sup> , Ware, 2015<sup>136</sup> e Yawn et al. 2014<sup>127</sup> .  
**Nota** : *A contagem de reticulócitos se faz necessária até que a Hb atinja um valor maior que 9 g/dL.  
* O alvo para a contagem absoluta de neutrófilos recomendado na literatura é de 2.000 cel/mm<sup>3</sup> ; no entanto, pessoas mais jovens com contagens basais mais baixas podem tolerar com segurança contagens absolutas de neutrófilos até 1.250 cel/mm<sup>3</sup> . Para crianças menores de 1 ano considerar níveis aceitáveis maior que 1.000 e acima de 1 ano maior que 1.500<sup>137</sup>

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Precauções** -->
A HU possui excreção renal e, por isso, deve ser usada com precaução, considerando-se a redução da dose quando utilizada para tratar pacientes com comprometimento renal. O ajuste de dose deverá ser feito de acordo com a depuração da creatinina:  
- 10 a 50 mL/min: administrar 50% da dose;  
- Menor que 10 mL/min: administrar 20% da dose.  
Recomenda-se a avaliação conjunta com nefrologista. Pessoas em hemodiálise devem receber HU após o procedimento<sup>138</sup> .  
A HU é um agente genotóxico com potencial risco de carcinogenicidade para humanos, e pode causar dano fetal quando administrado a mulheres grávidas. Mulheres em idade fértil devem ser aconselhadas a adotar métodos contraceptivos durante a terapia com HU. A HU deve ser descontinuada aproximadamente 3 meses antes da concepção<sup>138</sup> .  
De acordo com a bula do medicamento, em lactantes, deve-se decidir entre descontinuar a amamentação ou o tratamento, levando-se em conta os benefícios do tratamento para a mãe. Por outro lado, resultados de um estudo de farmacocinética reportaram baixos níveis de transferência de HU para o leite materno,<sup>139</sup> sugerindo que seu uso possa ser recomendado durante a amamentação, desde que realizada após pelo menos três horas de ingestão da dose diária de HU. Assim, recomenda-se que os riscos e benefícios do tratamento sejam avaliados nestes casos.  
Pacientes com sorologia positiva para hepatites B e C poderão fazer uso da HU desde que monitorados mensalmente com provas de função hepática. Em pacientes HIV positivos, a HU pode ser utilizada, tendo sido descrito aumento do risco de neuropatia periférica, pancreatite e insuficiência hepática, principalmente quando associada a antirretrovirais como didanosina e estavudina. Em pacientes HIV positivos que apresentem quadro de pancreatite ou toxicidade hepática durante o uso de HU, esta deverá ser suspensa e o seu uso contraindicado<sup>138</sup> . Não há dados que sustentem recomendações de ajuste de dose em pacientes com disfunção hepática<sup>138</sup> .  
A HU pode levar a um aumento do tamanho dos eritrócitos (macrocitose), o que pode mascarar o desenvolvimento da deficiência de ácido fólico<sup>138</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Eventos adversos** -->
A HU é relativamente atóxica. A mielossupressão é a toxicidade previsível e limitadora da dose. Podem ocorrer alterações na pele, cabelos e unhas e distúrbios gastrointestinais. A redução do número e da qualidade do esperma pode ocorrer sem hidroxiureia, e dados preliminares sugerem que a hidroxiureia não piora estes parâmetros<sup>140</sup> . Evidências de mais de 30 anos de  
uso em indivíduos com DF demonstraram não haver eventos adversos clinicamente significativos no crescimento ou desenvolvimento em crianças com o uso a longo prazo<sup>141</sup> .  
Indivíduos que recebem HU podem apresentar aumento nos níveis de creatinina sérica, ureia, ácido úrico e glicemia. Nesses casos, para a verificação de resultados verdadeiro positivo recomenda-se a repetição do teste usando um método diferente<sup>142</sup> .  
Foram descritas alterações na pele, alterações nas unhas e úlceras nas pernas, embora não esteja claro se a hidroxiureia foi responsável<sup>143</sup> . Indivíduos que receberam doses de hidroxiureia acima do permitido desenvolveram toxicidade muco cutânea, com eritema e dor nas palmas e plantas das mãos e pés; descamação, hiperpigmentação generalizada; e/ou estomatite. Nestes casos, a dose deve ser interrompida e devem ser utilizados tratamentos de suporte.  
Existem poucos dados sobre o impacto da terapia com hidroxiureia na fertilidade feminina na doença falciforme<sup>144</sup>  
Em caso de aparecimento de eventos adversos significativos que comprometam a qualidade de vida dos pacientes, deve ser feito ajuste de dose ou interrupção de tratamento.  
O uso da **HU** pode ser mantido na vigência de evento adverso leve, desde que haja acompanhamento regular de um especialista. A ocorrência de evento adverso moderado ou grave exige suspensão do uso. No entanto, o medicamento pode ser reintroduzido, de acordo com o dano causado e a vontade do usuário.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **8.2      Alfaepoetina** -->
O paciente elegível para uso de alfaepoetina deverá estar em uso de HU. Para início do tratamento ou alterações na dose, recomenda-se que seja apresentado resultado de hemograma dos últimos 3 meses. Recomenda-se que, durante o tratamento com este medicamento, o hemograma seja monitorado ao menos 1 a 2 vezes por mês, até que níveis estáveis de hemoglobina sejam atingidos. Uma vez que a hemoglobina atinja os valores desejados, recomenda-se monitoramento mensal nos seis primeiros meses, e depois, a cada três meses. Portanto, o hemograma é um exame de monitoramento e não deve ser interpretado como obrigatório para dispensação e continuidade do tratamento.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Critérios de interrupção** -->
A alfaepoetina deverá ser mantida por tempo indeterminado em caso de diminuição da necessidade transfusional para manter a hemoglobina basal. O tratamento com alfaepoetina deverá ser suspenso na seguinte situação:  
Se após 6 meses de tratamento não ocorrer diminuição da necessidade transfusional para atingir a hemoglobina alvo (Hb ≥ 8,5g/dl ou aumento ≥ 1,5 g/dl da sua Hb basal).  
**Transplante de células tronco hematopoiéticas**  
O acompanhamento de doentes submetidos ao TCTH alogênico deve seguir o protocolo específico para os casos de TCTH alogênico adotado pelo centro de transplante.  
Para os pacientes encaminhados ao TCTH, a HU deve ser suspensa quatro semanas antes do início do condicionamento para o transplante, e apenas reintroduzida caso não ocorra a pega do transplante.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Profilaxia antimicrobiana** -->
O tratamento profilático com fenoxipenicilina (penicilina V) deve ser mantido desde o diagnóstico até os 5 anos de idade, conforme os critérios de incorporação do medicamento.  
A asplenia por si só não é uma contraindicação para qualquer vacinação, incluindo vacinas vivas, não existem evidências do aparecimento de vaccínia em paciente com DF em uso de HU, incluindo vacinas com vírus vivos. É provável que os benefícios da redução de infecções nesta população de indivíduos funcionalmente asplênicos superem os riscos associados às vacinas vivas<sup>145</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso.  
Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
As pessoas de qualquer idade com diagnóstico de DF devem ser acompanhadas no centro de referência para DF ( **Figura 1** ), o qual deve contar com médico hematologista, bem como disponibilizar, preferencialmente no próprio centro, acesso à radiologia, cardiologia, pneumologia, ortopedia, urologia e gineco-obstetrícia. O atendimento em centro de referência facilita o tratamento em si, bem como a adequação das doses conforme necessário e o controle de eventos adversos.  
O centro de referência que contar com farmacêutico poderá dispensar a HU diretamente ao paciente, desde que se observem as normas e as etapas de execução do Componente Especializado da Assistência Farmacêutica (CEAF) no SUS e a organização da Assistência Farmacêutica estabelecida pela respectiva Secretaria de Estado da Saúde.  
Para a autorização do TCTH alogênico aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoiéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Os resultados de todos os casos de doença falciforme tipo HbSS ou tipo HbSbeta-talassemia submetidos a TCTH alogênico aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, deverão ter sua evolução registrada no REREME a cada três meses até completar pelo menos 1 (um) ano da realização do transplante.  
Para efeito de autorização, avaliação e controle, as secretarias de saúde devem observar as seguintes compatibilidades específicas para DF dos procedimentos de TCTH na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (Quadro 8).  
**Quadro 8.** Procedimentos de transplante de célula-tronco hematopoéticas.  
|**Código**|**Procedimento**|**Código da CID 10**||
|---|---|---|---|
||Transplante Alogênico de células-tronco|D57.0 – anemia falciforme|com crise|
|05.05.01.001-1|hematopoéticas de medula óssea -|D57.2<br>–<br>transtornos|falciformes|
||aparentado|heterozigóticos duplos||
||Transplante Alogênico de células-tronco|D57.0 – anemia falciforme|com crise|
|05.05.01.003-8|hematopoéticas de sangue de cordão|D57.2<br>–<br>transtornos|falciformes|
||umbilical - aparentado|heterozigóticos duplos||
||Transplante Alogênico de células-tronco|D57.0 – anemia falciforme|com crise|
|05.05.01.005-4|hematopoéticas de sangue periférico -|D57.2<br>–<br>transtornos|falciformes|
||aparentado|heterozigóticos duplos||  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **9.1. Centros de Referência** -->
Em 2001, o Ministério da Saúde (MS), por meio da Secretaria de Assistência à Saúde, empenhou-se na reavaliação da Triagem Neonatal no SUS – o Teste do Pezinho – que culminou na criação do Programa Nacional de Triagem Neonatal (PNTN)<sup>31</sup> . O PNTN é considerado um programa de grande importância e sucesso por sua abrangência, tendo atingido em 2014 mais de 84% de cobertura dos nascidos vivos brasileiros na rede pública. Está implantado em todos os estados brasileiros, sendo coordenado pelas Secretarias de Estado da Saúde e operacionalizado pelas Secretarias Municipais de Saúde. As pessoas com distúrbios e doenças detectadas são encaminhadas para acompanhamento por equipes multidisciplinares em serviços especializados. É uma política transversal que prevê ações compartilhadas tanto na Atenção Básica como na Média e Alta Complexidade.  
Dentre os principais objetivos do PNTN, destacam-se a ampliação da gama de patologias triadas e busca da cobertura de 100% dos nascidos vivos. O programa determina ainda que a triagem neonatal envolva várias etapas, como a realização do exame laboratorial, a busca ativa dos casos suspeitos, a confirmação diagnóstica, o tratamento e o acompanhamento multidisciplinar especializado dos pacientes. Dessa forma, o PNTN cria o mecanismo para que seja alcançada a meta principal, que é a prevenção e redução da morbimortalidade provocada pelas doenças triadas. Todos os objetivos, diretrizes e estratégias do programa exigem responsabilidade das três esferas de gestão proporcionando ampla mobilização em torno das ações relacionadas à triagem neonatal. Os Programas Estaduais de Triagem Neonatal em Fase II são responsáveis pela triagem neonatal da DF<sup>28,32,33</sup> . Em novembro de 2023, a DF foi incluída na Lista Nacional de Notificação Compulsória de Doenças, Agravos e Eventos de Saúde Pública, de acordo com a Portaria GM/MS nº 2.010.  
No âmbito da Atenção Primária à Saúde, ao detectar exames alterados, o serviço deve convocar e orientar os familiares, e encaminhá-los à Atenção Especializada, onde serão cadastrados e acompanhados por hematologista nos Centros de Referência ( **Figura 1** ). Concomitantemente, deve encaminhar os casos alterados para acompanhamento na Área Técnica de Saúde da Criança e do Adolescente, sendo então vinculada à Atenção Primária do território, próxima à residência da família. A internação, nos casos mais graves, é realizada na rede pública de hospital geral com suporte do Hemocentro Público e dos Serviços de Hematologia da região.  
Pacientes com DF deverão receber, primeiramente, acompanhamento multiprofissional em triagem neonatal com médico pediatra, psicólogo e assistente social. As famílias deverão receber orientação sobre o diagnóstico e o tratamento e ser encaminhadas para orientação e informação genética e a continuidade do atendimento deverá seguir as recomendações do presente Protocolo.  
Os profissionais das Unidades Básicas de Saúde, em posse do diagnóstico do traço falciforme recebido pelo laboratório do Serviço de Triagem Neonatal (STNN), devem atualizar o prontuário do paciente com esta informação, bem como comunicar e orientar paciente e familiares. O cuidado com portadores com traço falciforme deve contemplar consulta com orientação ainda na infância, acompanhados pelos pais e orientação e informação genética. Apesar de não ser necessário encaminhamento ao Centro de Referência, recomenda-se que estes pacientes sejam avaliados esporadicamente ao longo da vida por hematologistas, pediatras e clínicos treinados.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Transição de cuidados** -->
A transição de cuidados de saúde (TCS) é o processo de mudança de um modelo de cuidados de saúde centrado na criança/família para um modelo de cuidados de saúde centrado no adulto/paciente, com ou sem transferência para um novo serviço. O conceito de transição planejada é considerado parâmetro de qualidade nos serviços que prestam cuidados a pacientes com doenças crônicas e envolve planejamento, transferência e integração dos cuidados. É importante distinguir **transferência** - entendida como um ato único de transferir o doente de uma instituição ou equipe de cuidados para outra - e **transição** que, por  
sua vez, é definida como um processo dinâmico, complexo e planejado, que inclui a avaliação da aquisição de habilidades e competências, assim como a implementação de programas educacionais e recursos de cuidados de saúde.  
Os objetivos da clínica de transição são<sup>34–36</sup> :  
- Melhorar a capacidade dos jovens e adultos jovens com e sem necessidades especiais para gerir os seus próprios cuidados de saúde e utilizar eficazmente os serviços de saúde, e;  
- Garantir um processo organizado nas práticas de cuidados pediátricos e adultos para facilitar a preparação da transição, transferência de cuidados e integração em cuidados de saúde centrados no adulto.  
Apesar do aumento na sobrevida na infância, a mortalidade das pessoas com DF aumenta de 18 a 30 anos, quando os adultos jovens fazem a transição do tratamento pediátrico para o adulto. Além disso, a gravidade da DF aumenta após a saída do tratamento pediátrico, levando a um maior uso de cuidados médicos emergenciais<sup>35,37</sup> . A sobrevida de pacientes com DF no Brasil também está aumentando, atingindo quase 80% até os 18 anos<sup>38</sup> . Apesar dessa melhora na sobrevida e do consequente aumento de jovens adultos com DF, atualmente não existem programas oficiais estruturados de transição de cuidados de saúde para DF.  
O processo de preparação e transferência da criança com doença crônica que é acompanhada há anos em um serviço de pediatria para a clínica de saúde de adultos deve começar no início da adolescência e envolve planejamento individualizado e contínuo, incluindo aspectos da gestão de ambos os setores hospitalares, bem como a avaliação das competências do próprio adolescente em estar apto para assumir seu próprio cuidado.  
Já o processo de transição deve ser iniciado, ao longo da adolescência, para que haja tempo adequado de preparar a família, os médicos e o adolescente antes deste atingir a idade adulta, sendo que o momento ideal da transferência deve basearse menos na idade e mais na aquisição de habilidades individuais do paciente, incluindo a prontidão e a capacidade de gerenciar e conduzir seu tratamento no sistema de saúde de adultos. Os profissionais de saúde devem estar atentos para este momento, a fim de planejar e executar uma assistência eficiente, personalizada e promotora de bem-estar e com a finalidade de melhorar a adesão ao cuidado, reduzir complicações e aumentar a sobrevida<sup>39</sup> . A **Figura 2** apresenta a linha do tempo sugerida para as ações relacionadas à clínica de transição de cuidados em DF.  
**Figura2.** Linha do tempo sugerida para a clínica de transição  
<!-- Start of picture text -->
12 anos 14 anos 18 anos 21 anos<br>POLITICAIGUIAr RASTREAMENTOMONITORAMENTO.E TRANSFERENCIACUIDADOS DE CONCLUSAOTRANSIGAODA<br>Desenvolver, discutir Acompanhe o Transferéncia para Confirmacao da<br>compartilhar a progresso cuidados centrados no conclusao da<br>politica/guia de usando um registro de adulto e para uma transferéncia e<br>transic&o e cuidado folha de fluxo clinica de adultos feedback da efetividade<br>da transigao<br>PREPARO<br>Avaliar as habilidades<br>de autocuidado e<br>oferecer educacao<br>sobre as necessidades<br>identificadas<br>PLANEJAMENTO-<br>Desenvoiver plano de<br>transigao com resumo<br>médico<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
O resumo da transferência deve incluir prioritariamente:  
- Um plano de ação para controle e prevenção da dor (individualizado para cada paciente);  
 Um resumo da avaliação para comorbidades de DF incluindo as seguintes áreas: oftalmologia, medicina dentária, função pulmonar, neurológica, cardíaca e renal, triagem para risco de acidente vascular cerebral (AVC) com doppler transcraniano e, em alguns casos, ressonância magnética cerebral para infartos cerebrais silenciosos e testes cognitivos se necessário34;  
- Informações sobre o progresso educacional;  
- Status de vacinação com uma lista do calendário de vacinação;  
- Prescrição atual e histórico de medicamentos utilizados para DF;  
Histórico de transfusões

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).  
**11. REFERÊNCIAS BIBLIOGRÁFICAS**  
1. Sundd P, Gladwin MT, Novelli EM. Pathophysiology of Sickle Cell Disease. Annual Review of Pathology: Mechanisms of Disease. 2019 Jan 24;14(1):263–92.  
2. Zago MA, Cristina A, Pinto S. Fisiopatologia das doenças falciformes: da mutação genética à insuficiência de múltiplos órgãos The pathophysiology of sickle cell disease: from the genetic mutation to multiorgan disfunction. bras hematol hemoter. 2007;29(3):207–14.  
3. Miller AC, Gladwin MT. Pulmonary Complications of Sickle Cell Disease. Am J Respir Crit Care Med. 2012 Jun 6;185(11):1154.  
4. Hebbel RP, Osarogiagbon R, Kaul D. The Endothelial Biology of Sickle Cell Disease: Inflammation and a Chronic Vasculopathy. Microcirculation. 2004 Mar 1;11(2):129–51.  
5. Wood KC, Granger DN. Sickle cell disease: role of reactive oxygen and nitrogen metabolites. Clin Exp Pharmacol Physiol. 2007 Sep;34(9):926–32.  
6. Kato GJ, Gladwin MT, Steinberg MH. Deconstructing sickle cell disease: reappraisal of the role of hemolysis in the development of clinical subphenotypes. Blood Rev. 2007 Jan;21(1):37–47.  
7. Figueiredo MS. The compound state: Hb S/beta-thalassemia. Rev Bras Hematol Hemoter. 2015 May;37(3):150–2.  
8. Lervolino LG, Baldin PEA, Picado SM, Calil KB, Viel AA, Campos LAF. Prevalence of sickle cell disease and sickle cell trait in national neonatal screening studies. Rev Bras Hematol Hemoter. 2011;33(1):49–54.  
9. World Health Organization/WHO. Sickle Cell Disease | WHO | Regional Office for Africa [Internet]. [cited 2023 Apr 14]. Available from: https://www.afro.who.int/health-topics/sickle-cell-disease  
10. Mota C, Trad LAB, Dikomitis L. Sickle Cell Disease in Bahia, Brazil: The Social Production of Health Policies and Institutional Neglect. Societies. 2022 Jul 18;12(4):108.  
11. Cançado RD, Jesus JA. A doença falciforme no Brasil. Rev Bras Hematol Hemoter. 2007 Sep;29(3).  
12. Silva-Pinto AC, Costa FF, Gualandro SFM, Fonseca PBB, Grindler CM, Souza Filho HCR, et al. Economic burden of sickle cell disease in Brazil. PLoS One. 2022;17(6 June):1–15.  
13. Centers for Disease Control and Prevention. Data & Statistics on Sickle Cell Disease | CDC [Internet]. 2022 [cited 2023 Apr 14]. Available from: https://www.cdc.gov/ncbddd/sicklecell/data.html  
14. Martins MMF, Teixeira MCP. Análise dos gastos das internações hospitalares por anemia falciforme no estado da Bahia. Cad Saude Colet. 2017 Mar 30;25(1):24–30.  
15. Brasil. Ministério da Saúde. NOTA TÉCNICA No 29/2022-CGSH/DAET/SAES/MS. Secretaria de Atenção Especializada à Saúde Departamento de Atenção Especializada e Temática Coordenação-Geral de Sangue e Hemoderivados. 2022.  
16. ANVISA. Agência Nacional de Vigilância Sanitária. Manual de Diagnóstico e Tratamento de Doenças Falciformes [Internet]. 2002 [cited 2023 Apr 18]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/anvisa/diagnostico.pdf  
17. Vilela RB, Silva MA. Doença falciforme : as faces do estigma e do preconceito na construção da vulnerabilidade social. 2021;1–8.  
18. Figueiró AVM, Ribeiro RLR. Vivência do preconceito racial e de classe na doença falciforme. Saúde Soc. 2017 Jan 1;26(1):88–99.  
19. Friend A, Settelmeyer TP, Girzadas D. Acute Chest Syndrome. StatPearls. 2023 Feb 6;  
20. Runkel B, Klüppelholz B, Rummer A, Sieben W, Lampert U, Bollig C, et al. Screening for sickle cell disease in newborns: a systematic review. Syst Rev. 2020 Dec 1;9(1):1–9.  
21. Ministério da Saúde/Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Brasília - DF; 2023.  
22. Platt OS, Brambilla DJ, Rosse WF, Milner PF, Castro O, Steinberg MH, et al. Mortality in sickle cell disease. Life expectancy and risk factors for early death. N Engl J Med. 1994 Jun 9;330(23):1639–44.  
23. Ayyappan S, Drawz P, Nouraie M, Hildesheim ME, Zhang Y, Gordeuk VR, et al. Renal Disease in Sickle Cell: Clinically Varied and Associated with Increased Mortality. Blood. 2012 Nov 16;120(21):90.  
24. ZARKOWSKY H, GALLAGHER D, GILL F, WANG W, FALLETTA J, LANDE W, et al. Bacteremia in sickle hemoglobinopathies. J Pediatr. 1986 Oct;109(4):579–85.  
25. Barrett-Connor E. Bacterial infection and sickle cell anemia. An analysis of 250 infections in 166 patients and a review of the literature. Medicine. 1971 Mar;50(2):97–112.  
26. Dos Santos ACV, Eugênio FMC. INFECÇÃO POR PNEUMOCOCO EM CRIANÇAS PORTADORAS DE ANEMIA FALCIFORME. Revista Multidisciplinar em Saúde. 2022 Dec 28;224–31.  
27. Bainbridge R, Higgs DR, Maude GH, Serjeant GR. Clinical presentation of homozygous sickle cell disease. J Pediatr. 1985 Jun;106(6):881–5.  
28. Brasil. Ministério da Saúde. Manual de Normas Técnicas e Rotinas Operacionais do Programa Nacional de Triagem Neonatal. 2002;  
29. Zanatta<sup>1</sup> T, Manfredini<sup>2</sup> V. Comparação entre métodos laboratoriais de diagnóstico de Doenças Falciformes Resumo Summary. :94–2009.  
30. Agrawal RK, Patel RK, Shah V, Nainiwal L, Trivedi B. Hydroxyurea in Sickle Cell Disease: Drug Review. Indian Journal of Hematology and Blood Transfusion. 2014 Jun 24;30(2):91–6.  
31. Brasil. Ministério da Saúde. PORTARIA N<sup>o</sup> 822, DE 06 DE JUNHO DE 2001. 2001.  
32. Brasil. Ministério da Saúde. Política Nacional de Atenção Integral às Pessoas com Doença Falciforme e outras Hemoglobinopatias. Brasília - DF; 2005 p. PORTARIA N<sup>o</sup> 1.391, DE 16 DE AGOSTO DE 2005.  
33. Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 5 - Seção I - Do Programa Nacional de Triagem Neonatal (PNTN) (art. 142 ao art. 148). 2017.  
34. DeBaun MR, Telfair J. Transition and Sickle Cell Disease. Pediatrics. 2012 Nov 1;130(5):926–35.  
35. Kayle M, Docherty SL, Sloane R, Tanabe P, Maslow G, Pan W, et al. Transition to adult care in sickle cell disease: A longitudinal study of clinical characteristics and disease severity. Pediatr Blood Cancer. 2019 Jan;66(1):e27463.  
36. Got Transition® - Six Core Elements of Health Care Transition<sup>TM</sup> [Internet]. [cited 2023 May 9]. Available from: https://www.gottransition.org/six-core-elements/  
37. Brousseau DC. Acute Care Utilization and Rehospitalizations for Sickle Cell Disease. JAMA. 2010 Apr 7;303(13):1288.  
38. Santo AH. Sickle cell disease related mortality in Brazil, 2000–2018. Hematol Transfus Cell Ther. 2022 Apr;44(2):177– 85.  
39. White PH, Cooley WC, Boudreau ADA, Cyr M, Davis BE, Dreyfus DE, et al. Supporting the Health Care Transition From Adolescence to Adulthood in the Medical Home. Pediatrics. 2018 Nov 1;142(5).  
40. Rankine-Mullings AE, Owusu-Ofori S. Prophylactic antibiotics for preventing pneumococcal infection in children with sickle cell disease. Cochrane Database of Systematic Reviews. 2017 Oct 10;  
41. Davies JM, Lewis MPN, Wimperis J, Rafi I, Ladhani S, Bolton‐Maggs PHB. Review of guidelines for the prevention and treatment of infection in patients with an absent or dysfunctional spleen: Prepared on behalf of the British Committee for Standards in Haematology by a Working Party of the Haemato‐Oncology Task Force. Br J Haematol. 2011 Nov 12;155(3):308–17.  
42. Rubin LG, Schaffner W. Clinical practice. Care of the asplenic patient. N Engl J Med. 2014 Jul 24;371(4):349–56.  
43. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Departamento de Imunizações e Doenças Imunopreveníveis. 6<sup>a</sup> Edição do Manual dos Centros de Referência para Imunobiológicos Especiais. Vol. 1. Brasília; 2023.  
44. BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde Departamento de Imunização e Doenças Transmissíveis. MANUAL DOS CENTROS DE REFERÊNCIA PARA IMUNOBIOLÓGICOS ESPECIAIS. 5<sup>a</sup> edição – 2019 – versão eletrônica. Brasília - DF; 2019.  
45. Chou ST, Alsawas M, Fasano RM, Field JJ, Hendrickson JE, Howard J, et al. American society of hematology 2020 guidelines for sickle cell disease: Transfusion support. Blood Adv. 2020;4(2):327–55.  
46. Wayne AS, Kevy S V, Nathan DG. Transfusion management of sickle cell disease. Blood. 1993 Mar 1;81(5):1109–23.  
47. Davis BA, Allard S, Qureshi A, Porter JB, Pancham S, Win N, et al. Guidelines on red cell transfusion in sickle cell disease Part II: indications for transfusion. Br J Haematol. 2017;176(2):192–209.  
48. Linder GE, Chou ST. Red cell transfusion and alloimmunization in sickle cell disease. Haematologica. 2021 Apr 1;106(7):1805–15.  
49. Salinas Cisneros G, Webb J, Luban NLC, Nickel RS. Impact of universal irradiation on chronic transfusion for sickle cell disease. Transfusion (Paris). 2021 Aug 12;61(8):2290–4.  
50. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde Departamento de Atenção Especializada e Temática Coordenação-Geral de Sangue e Hemoderivados. Guia para uso de hemocomponentes. 2015;2. ed., 1. reimpr.  
51. Pirenne F, Yazdanbakhsh K. How I safely transfuse patients with sickle-cell disease and manage delayed hemolytic transfusion reactions. Blood. 2018;131(25):2773–81.  
52. Vichinsky EP, Earles A, Johnson RA, Hoag MS, Williams A, Lubin B. Alloimmunization in Sickle Cell Anemia and Transfusion of Racially Unmatched Blood. New England Journal of Medicine. 1990 Jun 7;322(23):1617–21.  
53. Narbey D, Habibi A, Chadebech P, Mekontso-Dessap A, Khellaf M, Lelièvre JD, et al. Incidence and predictive score for delayed hemolytic transfusion reaction in adult patients with sickle cell disease. Am J Hematol. 2017 Dec;92(12):1340–8.  
54. Vidler JB, Gardner K, Amenyah K, Mijovic A, Thein SL. Delayed haemolytic transfusion reaction in adults with sickle cell disease: a 5-year experience. Br J Haematol. 2015 Jun;169(5):746–53.  
55. Vichinsky EP. The prevention and management of alloimmunization in sickle cell disease: the benefit of extended phenotypic matching of red blood cells. Immunohematology. 2012;28(1):20–3.  
56. Brasil. Ministerio da Saúde. Portaria n<sup>o</sup> . 30/SCTIE/MS, de 30 de junho de 2015. [Internet]. Relatório de Recomendação n<sup>o</sup> . 151 da Comissão Nacional de Incorporação de Tecnologias em Saúde – CONITEC. Transplante de células-tronco hematopoéticas para o tratamento de doença falciforme. 2015 [cited 2023 Apr 20]. Available from: https://www.gov.br/conitec/pt-br/midias/incorporados/transplante_doenafalciforme_final.pdf  
57. Brazauskas R, Scigliuolo GM, Wang HL, Cappelli B, Ruggeri A, Fitzhugh CD, et al. Risk score to predict event-free survival after hematopoietic cell transplant for sickle cell disease. Blood. 2020 Jul 30;136(5):623–6.  
58. CDC. National Center on Birth Defects and Developmental Disabilities. Division of Blood Disorders. Living Well With Sickle Cell Disease Self-Care Toolkit. 2023;  
59. Raphael JL, Oyeku SO. Sickle cell disease pain management and the medical home. Hematology. 2013 Dec 6;2013(1):433–8.  
60. Moody K, Abrahams B, Baker R, Santizo R, Manwani D, Carullo V, et al. A Randomized Trial of Yoga for Children Hospitalized With Sickle Cell Vaso-Occlusive Crisis. J Pain Symptom Manage. 2017 Jun;53(6):1026–34.  
61. Ballas SK, Gupta K, Adams-Graves P. Sickle cell pain: a critical reappraisal. Blood. 2012 Nov 1;120(18):3647–56.  
62. Balayssac-Siransy E, Connes P, Tuo N, Danho C, Diaw M, Sanogo I, et al. Mild haemorheological changes induced by a moderate endurance exercise in patients with sickle cell anaemia. Br J Haematol. 2011 Aug;154(3):398–407.  
63. Connes P, Machado R, Hue O, Reid H. Exercise limitation, exercise testing and exercise recommendations in sickle cell anemia. Clin Hemorheol Microcirc. 2011;49(1–4):151–63.  
64. Lal A, Fung EB, Pakbaz Z, Hackney-Stephens E, Vichinsky EP. Bone mineral density in children with sickle cell anemia. Pediatr Blood Cancer. 2006 Dec;47(7):901–6.  
65. Antwi-Boasiako C, Kusi-Mensah YA, Hayfron-Benjamin C, Aryee R, Dankwah GB, Kwawukume LA, et al. Total Serum Magnesium Levels and Calcium-To-Magnesium Ratio in Sickle Cell Disease. Medicina (B Aires). 2019 Aug 29;55(9):547.  
66. AlJama A, AlKhalifah M, Al-Dabbous IA, Alqudaihi G. Vitamin D deficiency in sickle cell disease patients in the Eastern Province of Saudi Arabia. Ann Saudi Med. 2018 Mar;38(2):130–6.  
67. Bellet PS, Kalinyak KA, Shukla R, Gelfand MJ, Rucknagel DL. Incentive Spirometry to Prevent Acute Pulmonary Complications in Sickle Cell Diseases. New England Journal of Medicine. 1995 Sep 14;333(11):699–703.  
68. Wang CJ, Kavanagh PL, Little AA, Holliman JB, Sprinz PG. Quality-of-Care Indicators for Children With Sickle Cell Disease. Pediatrics. 2011 Sep 1;128(3):484–93.  
69. Padman R, Henry M. The use of bilevel positive airway pressure for the treatment of acute chest syndrome of sickle cell disease. Del Med J. 2004 May;76(5):199–203.  
70. Hsu LL, Batts BK, Rau JL. Positive expiratory pressure device acceptance by hospitalized children with sickle cell disease is comparable to incentive spirometry. Respir Care. 2005 May;50(5):624–7.  
71. Hsu LL, Fan-Hsu J. Evidence-based dental management in the new era of sickle cell disease: A scoping review. J Am Dent Assoc. 2020 Sep 1;151(9):668-677.e9.  
72. Kragt L, Dhamo B, Wolvius EB, Ongkosuwito EM. The impact of malocclusions on oral health-related quality of life in children-a systematic review and meta-analysis. Clin Oral Investig. 2016 Nov 1;20(8):1881–94.  
73. Ballas SK. Dental Complications of Sickle Cell Disease. JBR Journal of Interdisciplinary Medicine and Dental Science. 2014;02(06).  
74. Correa MEP. Comment on: “Oral health-related quality of life in children and teens with sickle cell disease.” Hematol Transfus Cell Ther. 2016 Apr 1;38(2):97–8.  
75. Downes SM, Hambleton IR, Chuang EL, Lois N, Serjeant GR, Bird AC. Incidence and Natural History of Proliferative Sickle Cell Retinopathy. Ophthalmology. 2005 Nov;112(11):1869–75.  
76. Cintho Ozahata M, Page GP, Guo Y, Ferreira JE, Dinardo CL, Carneiro-Proietti ABF, et al. Clinical and Genetic Predictors of Priapism in Sickle Cell Disease: Results from the Recipient Epidemiology and Donor Evaluation Study III Brazil Cohort Study. J Sex Med. 2019 Dec 1;16(12):1988–99.  
77. Yawn BP, Buchanan GR, Afenyi-Annan AN, Ballas SK, Hassell KL, James AH, et al. Management of Sickle Cell Disease. JAMA. 2014 Sep 10;312(10):1033.  
78. Minniti CP, Delaney KMH, Gorbach AM, Xu D, Lee CCR, Malik N, et al. Vasculopathy, inflammation, and blood flow in leg ulcers of patients with sickle cell anemia. Am J Hematol. 2014 Jan;89(1):1–6.  
79. Granja PD, Magalhães Quintão SB, Perondi F, Lima RBF de, Martins CL de M, Marques MA, et al. Úlceras de perna em pacientes com anemia falciforme. J Vasc Bras. 2020;19.  
80. Ndiaye M, Niang SO, Diop A, Diallo M, Diaz K, Ly F, et al. Ulcères de jambe au cours de la drépanocytose : étude rétrospective de 40 cas. Ann Dermatol Venereol. 2016 Feb;143(2):103–7.  
81. Minniti CP, Eckman J, Sebastiani P, Steinberg MH, Ballas SK. Leg ulcers in sickle cell disease. Am J Hematol. 2010 Jul 23;85(10):831–3.  
82. Ohene-Frempong K, Weiner SJ, Sleeper LA, Miller ST, Embury S, Moohr JW, et al. Cerebrovascular accidents in sickle cell disease: rates and risk factors. Blood. 1998 Jan 1;91(1):288–94.  
83. Strouse JJ, Lanzkron S, Urrutia V. The epidemiology, evaluation and treatment of stroke in adults with sickle cell disease. Expert Rev Hematol. 2011 Dec 10;4(6):597–606.  
84. DeBaun MR, Armstrong FD, McKinstry RC, Ware RE, Vichinsky E, Kirkham FJ. Silent cerebral infarcts: a review on a prevalent and progressive cause of neurologic injury in sickle cell anemia. Blood. 2012 May 17;119(20):4587–96.  
85. Kawadler JM, Clayden JD, Clark CA, Kirkham FJ. Intelligence quotient in paediatric sickle cell disease: a systematic review and meta-analysis. Dev Med Child Neurol. 2016 Jul;58(7):672–9.  
86. DeBaun MR, Jordan LC, King AA, Schatz J, Vichinsky E, Fox CK, et al. American Society of Hematology 2020 guidelines for sickle cell disease: prevention, diagnosis, and treatment of cerebrovascular disease in children and adults. Blood Adv. 2020 Apr 28;4(8):1554–88.  
87. Schatz J, Reinman L, Bills SE, Johnston JD. Sociodemographic and Biomedical Correlates of Developmental Delay in 2- and 4-Year-Olds with Sickle Cell Disease. Journal of Developmental & Behavioral Pediatrics. 2022 May;43(4):224– 32.  
88. Sahu T, Pande B, Sinha M, Sinha R, Verma HK. Neurocognitive Changes in Sickle Cell Disease: A Comprehensive Review. Ann Neurosci. 2022 Oct 10;29(4):255–68.  
89. Menezes AS de O da P, Len CA, Hilário MOE, Terreri MTRA, Braga JAP. Qualidade de vida em portadores de doença falciforme. Revista Paulista de Pediatria. 2013 Mar;31(1):24–9.  
90. Roberti M do RF, Moreira CLNS de O, Tavares RS, Borges Filho HM, Silva AG da, Maia CHG, et al. Avaliação da qualidade de vida em portadores de doença falciforme do Hospital das Clínicas de Goiás, Brasil. Rev Bras Hematol Hemoter. 2010;32(6):449–54.  
91. Friedrisch JR. Cirurgia e anestesia na doença falciforme. Rev Bras Hematol Hemoter. 2007 Sep;29(3).  
92. Platt OS. Hydroxyurea for the Treatment of Sickle Cell Anemia. 2008;  
93. Vicari P, Barretto de Mello A, Figueiredo MS. Effects of hydroxyurea in a population of Brazilian patients with sickle cell anemia. Am J Hematol. 2005 Mar;78(3):243–4.  
94. Rankine-Mullings AE, Nevitt SJ. Hydroxyurea (hydroxycarbamide) for sickle cell disease. Cochrane Database of Systematic Reviews. 2022 Sep 1;2022(10).  
95. Ferster A, Tahriri P, Vermylen C, Sturbois G, Corazza F, Fondu P, et al. Five years of experience with hydroxyurea in children and young adults with sickle cell disease. Blood. 2001 Jun 1;97(11):3628–32.  
96. Zimmerman SA, Schultz WH, Burgett S, Mortier NA, Ware RE. Hydroxyurea therapy lowers transcranial Doppler flow velocities in children with sickle cell anemia. Blood. 2007 Aug 1;110(3):1043–7.  
97. Zimmerman SA, Schultz WH, Davis JS, Pickens C V., Mortier NA, Howard TA, et al. Sustained long-term hematologic efficacy of hydroxyurea at maximum tolerated dose in children with sickle cell disease. Blood. 2004 Mar 15;103(6):2039–45.  
98. Hankins JS, Helton KJ, McCarville MB, Li CS, Wang WC, Ware RE. Preservation of spleen and brain function in children with sickle cell anemia treated with hydroxyurea. Pediatr Blood Cancer. 2008 Feb;50(2):293–7.  
99. Gulbis B. Hydroxyurea for sickle cell disease in children and for prevention of cerebrovascular events: the Belgian experience. Blood. 2005 Apr 1;105(7):2685–90.  
100. Steinberg MH, Barton F, Ballas SK, Orringer E, Bellevue R, Olivieri N, et al. Effect of Hydroxyurea on Mortality and Morbidity in Adult Sickle Cell Anemia Risks and Benefits Up to 9 Years of Treatment. 2003;289(13):1645–52.  
101. Steinberg MH, Barton F, Castro O, Pegelow CH, Ballas SK, Kutlar A, et al. Effect of Hydroxyurea on Mortality and Morbidity in Adult Sickle Cell Anemia. JAMA. 2003 Apr 2;289(13):1645.  
102. de Montalembert M, Brousse V, Elie C, Bernaudin F, Shi J, Landais P, et al. Long-term hydroxyurea treatment in children with sickle cell disease: tolerance and clinical outcomes. Haematologica. 2006 Jan;91(1):125–8.  
103. Strouse JJ, Lanzkron S, Beach MC, Haywood C, Park H, Witkop C, et al. Hydroxyurea for Sickle Cell Disease: A Systematic Review for Efficacy and Toxicity in Children. Pediatrics. 2008 Dec 1;122(6):1332–42.  
104. Mulaku M, Opiyo N, Karumbi J, Kitonyi G, Thoithi G, English M. Evidence review of hydroxyurea for the prevention of sickle cell complications in low-income countries. Arch Dis Child. 2013 Nov;98(11):908–14.  
105. Steinberg MH, McCarthy WF, Castro O, Ballas SK, Armstrong FD, Smith W, et al. The risks and benefits of long‐term use of hydroxyurea in sickle cell anemia: A 17.5 year follow‐up. Am J Hematol. 2010 Jun 12;85(6):403–8.  
106. Ataga KI, Orringer EP. Renal abnormalities in sickle cell disease. Am J Hematol. 2000 Apr;63(4):205–11.  
107. Fishbane S, Spinowitz B. Update on Anemia in ESRD and Earlier Stages of CKD: Core Curriculum 2018. American Journal of Kidney Diseases. 2018 Mar;71(3):423–35.  
108. Carneiro JDA, Ramos GF, de Carvalho WB, Johnston C, Delgado AF. Proposed recommendations for antithrombotic prophylaxis for children and adolescents with severe infection and/or multisystem inflammatory syndrome caused by SARS-CoV-2. Clinics. 2020;75:e2252.  
109. Associação Brasileira de Hematologia Hemoterapia e Terapia Celular. Recomendações do Comitê de Hematologia, Hemoterapia Pediatrica da ABHH – Doenças hematológicas benignas e COVID-19 [Internet]. 2021. p. 1–6. Available from: https://abhh.org.br/wp-content/uploads/2020/03/Hemato-benigna.-pediatria.atualização01.pdf.  
110. Dixit R, Nettem S, Madan SS, Soe HHK, Abas AB, Vance LD, et al. Folate supplementation in people with sickle cell disease. Cochrane Database of Systematic Reviews. 2016 Feb 16;  
111. Ballas SK. Pain Management of Sickle Cell Disease. Hematol Oncol Clin North Am. 2005 Oct;19(5):785–802.  
112. Puri L, Nottage KA, Hankins JS, Anghelescu DL. State of the Art Management of Acute Vaso-occlusive Pain in Sickle Cell Disease. Pediatric Drugs. 2018 Feb;20(1):29–42.  
113. Ballas SK, Bauserman RL, McCarthy WF, Castro OL, Smith WR, Waclawiw MA. Hydroxyurea and Acute Painful Crises in Sickle Cell Anemia: Effects on Hospital Length of Stay and Opioid Utilization During Hospitalization, Outpatient Acute Care Contacts, and at Home. J Pain Symptom Manage. 2010 Dec;40(6):870–82.  
114. Sharma D, Day ME, Stimpson SJ, Rodeghier M, Ghafuri D, Callaghan M, et al. Acute Vaso-Occlusive Pain is Temporally Associated with the Onset of Menstruation in Women with Sickle Cell Disease. J Womens Health. 2019 Feb;28(2):162–9.  
115. Rodrigues PC, Norton RC, Murao M, Januario JN, Viana MB. Iron deficiency in Brazilian infants with sickle cell disease. J Pediatr (Rio J). 2011 Aug 22;  
116. Coache D, Friciu M, Marcellin RB, Bonnemain L, Viau A, Gaëlle Roullin V, et al. Stability evaluation of compounded hydroxyurea 100 mg/mL oral liquids using a novel analytical method involving chemical derivatization. PLoS One. 2022;17(6 June):1–15.  
117. Agência Nacional de Vigilância Sanitária. ANVISA. RESOLUÇÃO-RDC N<sup>o</sup> 67, DE 8 DE OUTUBRO DE 2007. [Internet]. Dispõe sobre Boas Práticas de Manipulação de Preparações Magistrais e Oficinais para Uso Humano em farmácias. 2007 [cited 2023 Apr 20]. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/anvisa/2007/rdc0067_08_10_2007.html  
118. Paniz C, Lucena MR, Bertinato JF, Lourenço FR, Barros BCA, Gomes GW, et al. Daily supplementation with 5 mg of folic acid in Brazilian patients with hereditary spherocytosis. Journal of Investigative Medicine. 2019 Dec 5;67(8):1110– 7.  
119. Haymann JP, Hammoudi N, Stankovic Stojanovic K, Galacteros F, Habibi A, Avellino V, et al. Renin-angiotensin system blockade promotes a cardio-renal protection in albuminuric homozygous sickle cell patients. Br J Haematol. 2017 Dec;179(5):820–8.  
120. Zahr RS, Yee ME, Weaver J, Twombley K, Matar RB, Aviles D, et al. Kidney biopsy findings in children with sickle cell disease: a Midwest Pediatric Nephrology Consortium study. Pediatric Nephrology. 2019 Aug 3;34(8):1435–45.  
121. MINISTÉRIO DA SAÚDE. SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA TIECDSAÚDE. PORTARIA CONJUNTA N<sup>o</sup> 10, DE 18 DE JULHO DE 2023. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Hipertensão Pulmonar. Brasilia; 2023.  
122. Covitz W, Espeland M, Gallagher D, Hellenbrand W, Leff S, Talner N. The Heart in Sickle Cell Anemia. Chest. 1995 Nov;108(5):1214–9.  
123. Voskaridou E, Christoulas D, Terpos E. Sickle-cell disease and the heart: review of the current literature. Br J Haematol. 2012 Jun;157(6):664–73.  
124. Araújo CG de, Resende MBS, Tupinambás JT, Dias RCTM, Barros FC, Vasconcelos MCM, et al. Testes Ergométricos em Pacientes com Anemia Falciforme: Segurança, Viabilidade e Possíveis Implicações no Prognóstico. Arq Bras Cardiol. 2022 Mar 11;118(3):565–75.  
125. Galiba Atipo Tsiba FO, Itoua C, Ehourossika C, Ngakegni NY, Buambo G, Potokoue Mpia NSB, et al. Pregnancy Outcomes among Patients with Sickle Cell Disease in Brazzaville. Anemia. 2020 Sep 15;2020:1–4.  
126. Smith-Whitley K. Complications in pregnant women with sickle cell disease. Hematology. 2019 Dec 6;2019(1):359–66.  
127. Yawn BP, Buchanan GR, Afenyi-Annan AN, Ballas SK, Hassell KL, James AH, et al. Management of sickle cell disease: summary of the 2014 evidence-based report by expert panel members. JAMA. 2014 Sep 10;312(10):1033.  
128. de Montalembert M, Deneux-Tharaux C. Pregnancy in sickle cell disease is at very high risk. Blood. 2015 May 21;125(21):3216–7.  
129. Christensen T, Nardo-Marino A, Glenthøj A, Sørensen MB. [Sickle cell disease and pregnancy]. Ugeskr Laeger. 2020 Oct 19;182(43).  
130. Boafor T, Olayemi E, Galadanci N, Hayfron-Benjamin C, Dei-Adomakoh Y, Segbefia C, et al. Pregnancy outcomes in women with sickle-cell disease in low and high income countries: a systematic review and meta-analysis. BJOG. 2016 Apr;123(5):691–8.  
131. Emond AM, Collis R, Darvill D, Higgs DR, Maude GH, Serjeant GR. Acute splenic sequestration in homozygous sickle cell disease: Natural history and management. J Pediatr. 1985 Aug;107(2):201–6.  
132. Cullis JO, Win N, Dudley JM, Kaye T. Post-Transfusion Hyperhaemolysis in a Patient with Sickle Cell Disease: Use of Steroids and Intravenous Immunoglobulin to Prevent Further Red Cell Destruction. Vox Sang. 1995 Nov;69(4):355–7.  
133. Talano JAM, Hillery CA, Gottschall JL, Baylerian DM, Scott JP. Delayed Hemolytic Transfusion Reaction/Hyperhemolysis Syndrome in Children With Sickle Cell Disease. Pediatrics. 2003 Jun 1;111(6):e661–5.  
134. Pirenne F, Bartolucci P, Habibi A. Management of delayed hemolytic transfusion reaction in sickle cell disease: Prevention, diagnosis, treatment. Transfusion Clinique et Biologique. 2017 Sep;24(3):227–31.  
135. Lobo C, Araújo A, Antunes A de A, Pinto ACS, Godinho AC, Pires CSM, et al. Consensus of the Brazilian Association of Hematology, Hemotherapy and Cellular Therapy (ABHH) and the Brazilian Ministry of Health - General management of blood and blood products on the tests necessary for the release of exceptional medicines for sickle cell disease. Hematol Transfus Cell Ther. 2024 Feb;  
136. Ware RE. Optimizing hydroxyurea therapy for sickle cell anemia. Hematology. 2015 Dec 5;2015(1):436–43.  
137. Fioredda F, Skokowa J, Tamary H, Spanoudakis M, Farruggia P, Almeida A, et al. The European Guidelines on Diagnosis and Management of Neutropenia in Adults and Children: A Consensus Between the European Hematology Association and the EuNet-INNOCHRON COST Action. Hemasphere. 2023 Apr;7(4):e872.  
138.  
- Blau Farmacêutica S.A. Bula do Medicamento - Hidroxiureia. 2022;  
139. Ware RE, Marahatta A, Ware JL, McElhinney K, Dong M, Vinks AA. Hydroxyurea Exposure in Lactation: a Pharmacokinetics Study (HELPS). J Pediatr. 2020 Jul;222:236–9.  
140. Joseph L, Jean C, Manceau S, Chalas C, Arnaud C, Kamdem A, et al. Effect of hydroxyurea exposure before puberty on sperm parameters in males with sickle cell disease. Blood. 2021 Feb 11;137(6):826–9.  
141. Ware RE. How I use hydroxyurea to treat young patients with sickle cell anemia. Blood. 2010 Jul 1;115(26):5300–11.  
142. Food and Drug Administration. FDA drug prescription information for SIKLOS (hydroxyurea) tablets. https://www.accessdata.fda.gov/drugsatfda_docs/label/2023/208843s004lbl.pdf .  
143. Wong TE, Brandow AM, Lim W, Lottenberg R. Update on the use of hydroxyurea therapy in sickle cell disease. Blood. 2014 Dec 18;124(26):3850–7.  
144.  
- Smith-Whitley K. Reproductive issues in sickle cell disease. Blood. 2014 Dec 4;124(24):3538–43.  
145. Lederman HM, Connolly MA, Kalpatthi R, Ware RE, Wang WC, Luchtman-Jones L, et al. Immunologic Effects of Hydroxyurea in Sickle Cell Anemia. Pediatrics. 2014 Oct 1;134(4):686–95.  
146. Stevens DL, Hix M, Gildon BL. Crizanlizumab for the Prevention of Vaso-Occlusive Pain Crises in Sickle Cell Disease. Journal of Pharmacy Technology. 2021 Aug 19;37(4):209–15.  
147. Yu Z, Blankenship L, Jaiyesimi I. Crizanlizumab in Sickle Cell Disease. New England Journal of Medicine. 2017 May 4;376(18):1795–6.  
148. Dick MH, Abdelgadir A, Kulkarni VV, Akram H, Chatterjee A, Pokhrel S, et al. Comparing the Safety and Efficacy of L-Glutamine, Voxelotor, and Crizanlizumab for Reducing the Frequency of Vaso-Occlusive Crisis in Sickle Cell Disease: A Systematic Review. Cureus. 2022 May 11;  
149. Kutlar A, Kanter J, Liles D, Cancado R, Bruederle A, Shi M, et al. Crizanlizumab, A P-selectin inhibitor, increases the likelihood of not experiencing a sickle cell-related pain crisis while on treatment: Results from the phase II sustain study. Haematologica [Internet]. 2017;102:166. Available from:  
- https://www.embase.com/search/results?subaction=viewrecord&id=L617381013&from=export  
150. Kanter J, Kutlar A, Liles D, Cançado R, Bruederle A, Shi M, et al. Crizanlizumab 5.0 mg/kg increased the time to first on-treatment sickle cell pain crisis: A subgroup analysis of the phase ii sustain study. Blood [Internet]. 2017;130. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L620310599&from=export  
151. Ataga KI, Kutlar A, Cancado R, Liles D, Velez-Nandayapa L, Lincy J, et al. Crizanlizumab treatment is not associated with the development of proteinuria and hematuria in patients with sickle cell disease: A safety analysis from the sustain study. Hemasphere [Internet]. 2018;2:305–6. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L625922545&from=export  
152. Washko JK, Kutlar A, Liles D, Cançado R, Shi M, Zhu Z, et al. Crizanlizumab 5.0mg/kg increased the time to first ontreatment Sickle Cell Pain Crisis (SCPC) and the likelihood of not experiencing SCPC while on treatment: Subgroup analyses of the phase 2 sustain study. Pediatr Blood Cancer [Internet]. 2018;65:S81. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L621729239&from=export  
153. Shah N, Boccia R, Kraft WK, Hardesty BM, Paulose J, Laine D, et al. A Multicenter Retrospective Noninterventional Follow-up Study in Patients with Sickle Cell Pain Crisis Who Previously Participated in the Sustain Trial in the United States Successor Study. Blood. 2018 Nov 29;132(Supplement 1):4910–4910.  
154. Liles DK, Cançado R, Kanter J, Kutlar A, Bruederle A, Shi M, et al. Established Prevention of Vaso-Occlusive Crises with Crizanlizumab Is Further Improved in Patients Who Follow the Standard Treatment Regimen: Post-Hoc Analysis of the Phase II Sustain Study. Blood. 2018 Nov 29;132(Supplement 1):1082–1082.  
155. Yen G, Yasuda M, McGuiness C, He J, Lee S, Paulose J, et al. HSD63 Real-World Crizanlizumab Treatment Patterns of Patients with Sickle Cell Disease. Value in Health. 2022 Jul;25(7):S491.  
156. Real-World Incidence Of Vaso-Occlusive Crises In Patients With Sickle Cell Disease (SCD) And A High Baseline Disease Burden Treated With Crizanlizumab: Results From A Managed Access Program (MAP). Abstract Book for the 27th Congress of the European Hematology Association. Hemasphere. 2022 Jun 23;6:1–4130.  
157. Bueno C, Campos L, Ritter A, Zampirolli C, Watanabe De Oliveira R. EFFECTIVENESS OF CRIZANLIZUMAB IN REDUCING VASO-OCCLUSIVE CRISIS IN PATIENTS WITH SICKLE CELL DISEASE IN BRAZIL: STUDY PROTOCOL FOR AN OBSERVATIONAL, RETROSPECTIVE, MULTICENTER, NATIONAL STUDY. Hemasphere [Internet]. 2022;6:3822–3. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L638938779&from=export  
158. Yang M, Elmuti L, Badawy SM. Health-Related Quality of Life and Adherence to Hydroxyurea and Other DiseaseModifying Therapies among Individuals with Sickle Cell Disease: A Systematic Review. Biomed Res Int. 2022 Jul 18;2022:1–8.  
159. Heeney M, Rees D, de Montalembert M, Odame I, Brown C, Wali Y, et al. Safety and efficacy of crizanlizumab in adolescents with sickle cell disease (SCD): Initial data from the phase II, multicenter, open-label Solace-Kids trial. Hemasphere [Internet]. 2022;6(1):12. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L637390316&from=export  
160. Heeney MM, Rees DC, de Montalembert M, Odame I, Brown RCC, Wali Y, et al. Initial Safety and Efficacy Results from the Phase II, Multicenter, Open-Label Solace-Kids Trial of Crizanlizumab in Adolescents with Sickle Cell Disease (SCD). Blood [Internet]. 2021;138:12. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L2016087752&from=export  
161. Kanter J, Shah A, Joshi V, Mehta H, Levine M, Arunagiri U, et al. Rare Cases of Infusion-Related Reactions (IRRs) Presenting As Pain Events during or after Crizanlizumab Infusion in Patients (Pts) with Sickle Cell Disease (SCD): A Systematic Evaluation of Post-Marketing (PM) Reports. Blood [Internet]. 2021;138:3112. Available from: https://www.embase.com/search/results?subaction=viewrecord&id=L2016078646&from=export  
162. Martí-Carvajal A, Abd El Aziz MA, Martí-Amarista C, Solà I. Antiplatelet agents for preventing vaso-occlusive events in people with sickle cell disease: a systematic review. Clin Adv Hematol Oncol. 2019 Apr;17(4):234–43.  
163. Ataga KI, Kutlar A, DeBonnett L, Lincy J, Kanter J. Crizanlizumab Treatment Is Associated with Clinically Significant Reductions in Hospitalization in Patients with Sickle Cell Disease: Results from the Sustain Study. Blood. 2019 Nov 13;134(Supplement_1):2289–2289.  
164. Kanter J, Liles DK, Smith-Whitley K, Brown C, Kutlar A, Elliott B, et al. Crizanlizumab 5.0 Mg/Kg Exhibits a Favorable Safety Profile in Patients with Sickle Cell Disease: Pooled Data from Two Phase II Studies. Blood. 2019 Nov 13;134(Supplement_1):991–991.  
165. Ataga KI, Saraf SL, Derebail VK, Sharpe CC, Inati A, Lebensburger JD, et al. The Effect of Crizanlizumab Plus Standard of Care (SoC) Versus Soc Alone on Renal Function in Patients with Sickle Cell Disease and Chronic Kidney Disease: A Randomized, Multicenter, Open-Label, Phase II Study (STEADFAST). Blood. 2019 Nov 13;134(Supplement_1):1018–1018.  
166. Katoch D, Krishnamurti L. Assessing Patient Preferences for Treatment Options for Pediatric Sickle Cell Disease: A Critical Review of Quantitative and Qualitative Studies. Patient Prefer Adherence. 2021 Oct;Volume 15:2221–9.  
167. Smith WR, Ataga KI, Saraf SL, Adisa OA, Bailey M, Ramscar N, et al. The Effect of Crizanlizumab on the Number of Days Requiring Opioid Use for Management of Pain Associated with Vaso-Occlusive Crises in Patients with Sickle Cell Disease: Results from the Sustain Trial. Blood. 2020 Nov 5;136(Supplement 1):32–3.  
168. Cançado RD, Colombatti R, Quarta A, Arcioni F, DeBonnett L, Soliman W, et al. Real-World Data on the Occurrence of Vaso-Occlusive Crises (VOCs) in Patients with Sickle Cell Disease (SCD) and a High Baseline Disease Burden Treated with Crizanlizumab: Results from a Managed Access Program (MAP). Blood. 2021 Nov 5;138(Supplement 1):4180–4180.  
169. Silva-Pinto AC, Marturano E, Debonnett L, Cancado RD. Real-world data from the crizanlizumab managed access program (map): Baseline disease burden and prior treatments for patients with sickle cell disease (scd) and recurrent vasoocclusive crises (vocs). EHA2021 Virtual Congress Abstract Book. Hemasphere. 2021 Jun;5:e566.  
170. Han J, Saraf SL, Gordeuk VR. Systematic Review of Crizanlizumab: A New Parenteral Option to Reduce Vaso‐occlusive Pain Crises in Patients with Sickle Cell Disease. Pharmacotherapy: The Journal of Human Pharmacology and Drug Therapy. 2020 Jun 20;40(6):535–43.  
171. Thom H, Jansen J, Shafrin J, Zhao L, Joseph G, Cheng HY, et al. Crizanlizumab and comparators for adults with sickle cell disease: a systematic review and network meta-analysis. BMJ Open. 2020 Sep 17;10(9):e034147.  
172. Burnett A, el Rassi F, Darbari D, Paulose J, Lainé D, Purkayastha D, et al. 147 A Prospective Phase II, Open-Label, Single-arm, Multicenter Study to Assess the Efficacy and Safety of SEG101 (Crizanlizumab) in Sickle Cell Disease Patients With Priapism (SPARTAN). J Sex Med. 2020 Jan;17(1):S43.  
173. el Rassi FA, Darbari DS, Burnett A, Paulose J, Laine DI, Purkayastha D, et al. A Prospective Phase II, Open-Label, Single-Arm, Multicenter Study to Assess the Efficacy and Safety of SEG101 (Crizanlizumab) in Sickle Cell Disease Patients with Priapism (SPARTAN). Blood. 2019 Nov 13;134(Supplement_1):1007–1007.  
174. Abboud MR, Howard J, Cançado R, Smith WR, Güvenç B, Espurz N, et al. Crizanlizumab Versus Placebo, with or without Hydroxyurea/Hydroxycarbamide, in Adolescent and Adult Patients with Sickle Cell Disease and VasoOcclusive Crises: A Randomized, Double-Blind, Phase III Study (STAND). Blood. 2019 Nov 13;134(Supplement_1):998–998.  
175. Bartolucci P; SSL; DVK; SCC; IA; LJD; DL; ZY; AKI; Steadfast: A phase ii study investigating the effect of crizanlizumab and standard of care (SOC) vs soc alone on renal function in patients with chronic kidney disease due to sickle cell nephropath. Abstract Book: 25th Congress of the European Hematology Association Virtual Edition, 2020. Hemasphere. 2020 Jun;4:1–1168.  
176. Saraf SL, Ataga KI, Derebail VK, Sharpe CC, Inati A, Lebensburger JD, et al. A Phase II, Randomized, Multicenter, Open-Label Study Evaluating the Effect of Crizanlizumab and Standard of Care (SoC) Versus Standard of Care Alone on Renal Function in Patients with Chronic Kidney Disease Due to Sickle Cell Nephropathy (STEADFAST). Blood. 2021 Nov 5;138(Supplement 1):3096–3096.  
177. MS. Diretrizes metodológicas - Análise de Impacto Orçamentário - Manual para o Sistema de Saúde do Brasil. https://www.gov.br/conitec/pt-br/midias/artigos_publicacoes/diretrizes/diretrizes_metodologicas_analise_impacto1.pdf. 2012.  
178. IBGE. PNS - Pesquisa Nacional de Saúde 2019 Tabelas - . https://sidra.ibge.gov.br/pesquisa/pns/pns-2019. 2019.  
179. Silva-Pinto AC, Costa FF, Gualandro SFM, Fonseca PBB, Grindler CM, Souza Filho HCR, et al. Economic burden of sickle cell disease in Brazil. PLoS One [Internet]. 2022 Jun 16;17(6):e0269703-. Available from: https://doi.org/10.1371/journal.pone.0269703

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE ÁCIDO FÓLICO, ALFAEPOETINA, BENZILPENICILINA BENZATINA (PENICILINA G), ERITROMICINA, FENOXIMETILPENICILINA (PENICILINA V) E HIDROXIUREIA** -->
Eu,____________________________________________________________________________________________  
______________________(nome do [a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso dos medicamentos hidroxiureia, fenoximetilpenicilina (penicilina V), benzilpenicilina benzatina (penicilina G), eritromicina e alfaepoetina, indicados para o tratamento da doença falciforme, segundo critérios de elegibilidade definidos neste Protocolo.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ____________________  
_______________________________________________________________________(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o(s) medicamento(s) que passo a receber pode(m) trazer os seguintes benefícios:  
- Desaparecimento ou diminuição dos episódios de dor;  
- Aumento da produção de hemoglobina fetal no sangue;  
- Aumento, mesmo que pequeno, da concentração total da hemoglobina no sangue;  
- Diminuição dos episódios de síndrome torácica aguda;  
- Diminuição do número de hospitalizações;  
- Diminuição do número de transfusões sanguíneas;  
- Regressão ou estabilização de danos em órgãos ou tecidos;  
- Melhora do bem-estar e da qualidade de vida e maior sobrevida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Fenoximetilenicilina e benzilpenicilina benzatina (categoria B de risco para mulheres grávidas): os estudos em animais não demonstraram risco fetal, mas também não há estudos controlados em mulheres grávidas; ou então, os estudos em animais revelaram riscos, mas que não foram confirmados em estudos controlados em mulheres grávidas. Penicilinas atravessam rapidamente a barreira placentária. O efeito para o feto, caso exista, não é conhecido. Apesar de serem consideradas seguras, as penicilinas só devem ser prescritas para mulheres grávidas, quando estritamente necessário.  
- Eritromicina e hidroxiureia (categoria D de risco para mulheres grávidas): o uso destes medicamentos só deve ser feito na gravidez e lactação após cuidadosa avaliação da relação risco-benefício, pois há evidência de risco fetal, mas a necessidade pode justificar o uso. Estes medicamentos não devem ser utilizados por mulheres grávidas sem orientação médica. Informe imediatamente seu médico em caso de suspeita de gravidez.  
- A hidroxiureia pode causar redução da capacidade reprodutiva de homens e mulheres;  
- eventos adversos mais frequentes da hidroxiureia: diminuição do número de glóbulos brancos (leucopenia e neutropenia), de glóbulos vermelhos (anemia) e de plaquetas (trombocitopenia), cansaço, dor de cabeça, tonturas, desorientação e alucinações; perda de apetite, náusea, vômitos, diarreia, prisão de ventre e dor de estômago; elevação de enzimas hepáticas, hepatite medicamentosa, infiltrado pulmonar e fibrose pulmonar; erupções na pele, hiperpigmentação das unhas, queda de cabelos, câncer de pele, perda de função renal, elevação dos níveis sanguíneos de ureia, creatinina e ácido úrico, febre, calafrios, mal-estar;  
- eventos adversos mais frequentes da alfaepoetina: artralgia, convulsões, cefaleia, hipertensão arterial, náuseas, sintomas  
- de tipo gripal, trombose do “shunt”, incluindo equipamento de diálise, erupção cutânea devida a ingestão da alfaepoetina;  
- eventos adversos mais frequentes fenoximetilpenicilina (penicilina V): dor de cabeça, candidíase oral, náusea, vômitos,  
- diarreia, candidíase vaginal; erupções na pele; coceiras, inchaço, falta de ar, dor abdominal, reações anafiláticas, edema de  
laringe, hipotensão, vermelhidão, confusão mental, convulsões, febre, hepatite medicamentosa, problemas no intestino e nos rins, diminuição do número de glóbulos brancos (leucopenia e neutropenia), de glóbulos vermelhos (anemia) e de plaquetas (trombocitopenia).  
- eventos adversos mais frequentes da benzilpenicilina benzatina (penicilina G): erupções na pele, febre, calafrios,  
- coceiras, dor nas juntas, cansaço, reações anafiláticas, entre outros.  
- eventos adversos mais frequentes da eritromicina: cólicas, mal-estar, náusea, vômitos, diarreia e reações alérgicas, entre  
- outros.  
 Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Também estou ciente de que o ácido fólico, medicamento complementar ao meu tratamento, pode, raramente, ser maléfico à minha função renal, além de provocar reação alérgica (febre e erupção cutânea).  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim                                     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (  ) ácido fólico  
- (  ) hidroxiureia  
- (  ) alfaepoetina  
- ( ) fenoximetilpenicilina (penicilina V)  
- ( ) benzilpenicilina benzatina (penicilina G)  
- ( ) eritromicina  
Local:                                                             Data: Nome do paciente: Cartão Nacional de Saúde:  
Nome do responsável legal:  
|Documento de identificação do responsável legal:|||
|---|---|---|
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
**Nota** : Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **1. Escopo e finalidade do Protocolo** -->
O presente Apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas da Doença Falciforme, contendo a descrição da metodologia de busca de evidências científicas e as recomendações constantes em seu texto.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo.  
A revisão do PCDT foi iniciada com as reuniões virtuais de pré-escopo, escopo e priorização de perguntas realizadas de junho a agosto de 2022. As reuniões tiveram a participação de até 19 participantes entre membros do Grupo Elaborador e do Comitê Gestor.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria conjunta nº 9, de 31 de julho de 2019) e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foram priorizadas quatro perguntas de pesquisa para a revisão deste PCDT para as quais foram elaborados relatórios de recomendação pelo Grupo elaborador.  
A relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.  
Este Protocolo tem como público-alvo os profissionais da saúde envolvidos na atenção do paciente com doença falciforme (DF), em especial médicos e enfermeiros que atuam na Atenção Primária e na Atenção Especializada, ambulatorial, no Sistema Único de Saúde (SUS).  
Os indivíduos adultos ou crianças com DF do tipo traço falciforme (HbAS), ou com a mutação HbS em homozigose (HbSS) ou heterozigose composta são a população-alvo destas recomendações.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **2. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pelo NATS do Hospital Alemão Oswaldo Cruz.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **2.1      Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Doença Falciforme foi apresentada na 113ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em março de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Atenção Primária à Saúde (SAPS). Foi solicitada a inclusão dos antibióticos citados no PCDT no item Medicamentos e alterações na redação dos critérios de elegibilidade. O PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **2.2      Consulta pública** -->
A Consulta Pública nº 25/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Doença Falciforme, foi realizada entre os dias 24/05/2024 a 12/06/2024. Foram recebidas 184 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/contribuicoes-da-cp-25-de-2024-pcdt-da-doencafalciforme.</u>

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Buscas na literatura para atualização do PCDT** -->
O processo de atualização desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO **(Figura A)** .  
**Figura A.** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO / PIRO.  
<!-- Start of picture text -->
‘*Fatorde exposicao, em caso de estudos observacionais<br>| ‘intervenco, no caso de estudos experimentais<br>*Teste indice, nos casos de estudos de acurdcia diagndstica<br>Controle, de acordo com tratamento/niveis de exposi¢3o do fator/exames.<br>disponiveis no SUS<br>‘*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
Durante a reunião de escopo deste PCDT quatro questões de pesquisa foram definidas.  
**Questão 1: O uso de hidroxiureia é eficaz, efetivo e seguro para o tratamento de pacientes com doença falciforme (SS, Sbeta0 e SD Punjab) entre 9 e 24 meses de idade, independentemente de sintomas comparado ao cuidado padrão?**  
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a ampliação no SUS de hidroxiureia, conforme Relatório de Recomendação nº 873/2024, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2024/20240307_</u> Relatrio_873_Hidroxiureia500mg_DOENAFALCIFORME.pdf.  
A estrutura PICO para esta pergunta foi:  
|**PICO**|**Pergunta**|
|---|---|
|**P**|Pacientes com doença falciforme (SS, Sbeta0 e SD Punjab) entre 9 e 24 meses de idade,<br>independentemente de sintomas e complicações|
|**I**|Hidroxiureia<sup>a</sup>|
|**C**|Cuidado padrão (tratamento adjuvante como ácido fólico, analgésicos e anti-inflamatórios)|
||Primários (críticos):|
|**O**|Crises vaso-oclusivas e episódios de dor; função esplênica e taxa de filtração glomerular; hospitalizações;<br>Eventos adversos graves (toxicidade hematológica e genotoxicidade)<br>Secundários (importantes):|
||Importante: episódios agudos de síndrome torácica, necessidade de transfusões, níveis de hemoglobina<br>total e fetal.|
|**S**|Revisões sistemáticas, Ensaios clínicos randomizados e estudos observacionais|  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 873 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**Questão 2: Qual o impacto orçamentário hidroxiureia 100 e 1000 mg para o tratamento de pacientes com doença falciforme a partir dos 9 meses de idade?**  
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação de hidroxiuréia 100 mg e de não incorporar hidroxiuréia 100 mg no SUS, conforme Relatório de Recomendação nº 872/2024, disponível em: <u>https://www.gov.br/conitec/pt- br/midias/relatorios/2024/20240307_Relatrio_872_Hidroxiureia_100_1000_DOENAFALCIFORMEPDF.pdf</u>  
A estrutura PICO para esta pergunta foi:  
|**PICO**|**Pergunta**|
|---|---|
|**P**|Crianças a partir de 9 meses de idade com doença falciforme|
|**I**|Hidroxiureia 100 e 1000 mg (incorporação de nova apresentação; SIKLOS) a|
|**C**|Hidroxiureia 500 mg|
|**O**|Impacto orçamentário b|
|**S**|Não aplicável|

---

<!-- METADADOS: doenca: Doença Falciforme | secao: Métodos e resultados da busca: -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 872 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Questão 3. A alfaepoetina + cuidado-padrão, comparada ao cuidado-padrão, é eficaz, efetiva e segura para o** -->
**tratamento de adultos com DF, apresentando declínio da função renal e piora dos níveis de hemoglobina?**  
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação de alfaepoetina para esta indicação no SUS, conforme Relatório de Recomendação nº 874/2024, disponível em:

---

<!-- METADADOS: doenca: Doença Falciforme | secao: A estrutura PICO para esta pergunta foi: -->
|**PICO**|**Pergunta**|
|---|---|
|**P**|Adultos com doença falciforme SS e Sbeta0, apresentando aumento da creatinina e piora dos níveis de<br>hemoglobina|
|**I**|Alfaepoetina (sinônimo eritropoietina humana recombinante)|
|**C**|Cuidado padrão|
|**O**|Não tratar|
|**S**|Primários (críticos):|

---

<!-- METADADOS: doenca: Doença Falciforme | secao: Métodos e resultados da busca: -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 874 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**Questão 4 - O medicamento crizanlizumabe comparado ao cuidado padrão é eficaz, efetivo e seguro para o tratamento de indivíduos com doença falciforme (SS e Sbeta0) em falha terapêutica ou intolerância à hidroxiureia e ao**  
**menos 16 anos de idade?**  
Recomendação: Em 30 de outubro de 2023, a Agência Nacional de Vigilância Sanitária (Anvisa) publicou o cancelamento do registro do medicamento Adakveo® (crizanlizumabe)<sup>146</sup> . Além disso, resultados preliminares do estudo clínico de fase III CSEG101A2301 (STAND) não demonstraram diferença entre o crizanlizumabe e o placebo nas taxas anualizadas de crises vasooclusivas que levaram a uma consulta médica durante o primeiro ano após a randomização<sup>147</sup> . Assim, não foi possível discutir a recomendação do medicamento. Relatório não prosseguiu para apreciação da Conitec,

---

<!-- METADADOS: doenca: Doença Falciforme | secao: A estrutura PICO para esta pergunta foi: -->
|**PICO**|**Pergunta**|
|---|---|
|**P**|Pacientes com doença falciforme (SS e Sbeta0) e ao menos 16 anos de idade:<br>i) em falha terapêutica (i.e., recorrência de crise apesar do tratamento com hidroxiureia); ou<br>ii) intolerância à hidroxiureia (i.e., recorrência de crise com a máxima dose tolerada de hidroxiureia).|
|**I**|Crizanlizumabe com hidroxiureia e sem hidroxiureia|
|**C**|Cuidado padrão (hidroxiureia ou transfusões de sangue)<sup>a</sup>|
||Primários (críticos):<br>Taxa anual de crise vasoclusiva;<br>Tempo para a primeira crise de dor;<br>Internação; e|
|**O**|Incidência de eventos adversos graves<br>Secundários (importantes):|
||Taxa anual de crises de dor não complicadas;<br>Qualidade de vida; e<br>Incidência de eventos adversos gerais|
|**S**|ECR sem restrição para fase, RS e observacionais comparativos<sup>f</sup>|

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **3. Métodos e resultados da busca:** -->
Para responder essa pergunta, foi utilizada a síntese de evidências a seguir:  
MÉTODOS

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **População** -->
A população priorizada foi composta por adultos e/ou crianças acima de 16 anos de idade, de ambos os sexos e que apresentavam, como critério de inclusão, diagnóstico de doença falciforme ou anemia falciforme (SS e Sbeta0) e que já tiveram uma ou mais crises de dor vasoclusiva e estavam em falha terapêutica ou apresentavam intolerância à hidroxiureia. Entendeu-se como falha terapêutica: continuar a ter crise de dor ou continuar a apresentar a condição que definiu início de hidroxiureia (p.ex. LDH 2x maior que o normal – hemólise, lesão crônica de órgão ou outra doença hepática em progressão, entre outros critérios definidos nos critérios de inclusão de tratamento com hidroxiureia); e entendeu-se como critério de intolerância a toxicidade hematológica (p.ex. plaquetopenia).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Intervenção** -->
A intervenção de interesse foi o crizanlizumabe de 10 mg/kg/mL solução para diluição para infusão, que possui registro ativo na Agência Nacional de Vigilância Sanitária (Anvisa). O Adakveo® (crizanlizumabe), tem indicação para “Reduzir a frequência dos episódios dolorosos (crises vaso-oclusivas) que ocorrem em pacientes de 16 anos ou mais com doença  
falciforme”. A dose recomendada de Adakveo® é de 5 mg/kg/kg administrada durante um período de 30 minutos por infusão intravenosa na semana 0, na semana 2 e em seguida, a cada 4 semanas. Porém, não houve restrição das doses utilizadas ou se crizanlizumabe foi administrado em monoterapia ou associado a hidroxiureia ou associado às transfusões de sangue regulares.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Comparador** -->
A escolha do comparador foi baseada no cuidado padrão já realizado com estes pacientes no SUS. Entendeu-se como cuidado padrão o tratamento com hidroxiureia (sinônimo hidroxicarbamida) e transfusões de sangue regulares. Na ausência de estudos contemplando hidroxiureia ou transfusões de sangue, foram considerados estudos que compararam crizanlizumabe com placebo. Tanto a intervenção quanto os comparadores poderiam estar em monoterapia ou associados ao cuidado-padrão ou placebo. Apesar de o tratamento ser indicado para quem tem falha ou intolerância à hidroxiureia, a prática e evidência clínica mostram que este paciente pode continuar a usar a hidroxiureia em dose subótima.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **4. Desfechos** -->
Foram elencados sete desfechos de interesse, definidos a seguir:  
<u>Primários (críticos):</u>  
- Taxa anual de crise vasoclusiva: avaliada pelo número mediano anual de crises vaso-oclusivas relatadas pelos pacientes. As crises foram identificadas pela presença de dor, síndrome torácica aguda e/ou priapismo e o uso da mediana, em vez da média, permite uma representação mais precisa da taxa de crise, já que minimiza o impacto de valores extremos ou outliers. A taxa anual de crise vaso oclusiva também foi avaliada pelo percentual de pacientes que não tiveram crise vasoclusiva em um ano.  
- Crise de dor: avaliada pelo tempo mediano até a primeira crise vasoclusiva, mensurada em meses.  
- Internação: avaliada pelo tempo mediano em que os pacientes foram internados devido aos sintomas da doença  
- falciforme, mensurado em meses.  
- Incidência de eventos adversos (EA) graves: avaliada pelo percentual de EA relatados como graves nos estudos.  
- <u>Secundários (importantes):</u>  
- Taxa anual de crises de dor não complicadas: avaliada pelo número mediano anual de outras crises vaso-oclusivas  
- relatadas pelos pacientes além da síndrome torácica aguda, sequestro hepático, sequestro esplênico ou priapismo.  
- Qualidade de vida: avaliada por qualquer questionário ou teste de qualidade de vida.  
- Incidência de eventos adversos gerais: relatados como EA de qualquer grau, ou percentual de EAs mais relatados.  
Não houve restrição para o tipo de pergunta ou a escala e questionário em que o desfecho foi avaliado. A crise vasoclusiva foi definida como um episódio agudo de dor, sem nenhuma causa clinicamente determinada além de um evento vaso-oclusivo que resultou em uma visita a um centro médico e tratamento com opioides orais ou parenterais ou com um anti-esteroide parenteral - medicamento anti-inflamatório.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Tipos de estudos** -->
Foram considerados para inclusão revisões sistemáticas, com ou sem meta-análises, ensaios clínicos randomizados (ECR) ou quasi-randomizados, estudos de coorte prospectivos ou retrospectivos, com grupo comparador. Não foi feita restrição para data de publicação, idioma, fase do ensaio clínico, para número mínimo de participantes por grupo ou tempo de acompanhamento. Foram excluídas as revisões sistemáticas desatualizadas ou que excluíram estudos relevantes para a presente pergunta devido à restrição do ano de publicação. Adicionalmente, foram excluídos estudos reportados apenas em resumo de congresso que já tenham resultados publicados em revista por pares.  
**5. Fontes de informações e estratégias de busca**  
**Termos de busca e bases de dados**  
Com base na pergunta PICO estruturada acima, construiu-se uma estratégia de busca utilizando todos os sinônimos dos termos que englobam a população e a intervenção consideradas. A busca nas bases de dados foi realizada no dia 23 de janeiro de 2023 por meio do PubMed (Medline) e EMBASE. Os termos e resultados dessa busca encontram-se no quadro abaixo. Para validação da estratégia de busca, uma busca no Epistemonikos foi realizada visando a identificação de potenciais revisões sistemáticas não recuperadas nas bases principais e estudos primários recuperados por essas revisões.  
**Quadro A.** Estratégias de busca de evidências em base de dados  
|Bases<br>de<br>dados|Estratégia de Busca|Número de Artigos<br>Recuperados|
|---|---|---|
|MEDLINE<br>via pubmed|((((((((((((((((((((((((((anemia, sickle cell[MeSH Terms]) OR (anemia, sickle cell)) OR<br>(Sickle cell disease)) OR (Sickle-cell disease)) OR (Sickle hemoglobin C disease)) OR<br>(HbSC)) OR (Sickle β0-thalassemia)) OR (HbSβ0-thalassemia)) OR (Sickle β+-<br>thalassemia)) OR (HbSβ+-thalassemia)) OR (Anemias, Sickle Cell)) OR (Sickle Cell<br>Anemias)) OR (Hemoglobin S Disease)) OR (Disease, Hemoglobin S)) OR<br>(Hemoglobin S Diseases)) OR (Sickle Cell Anemia)) OR (Sickle Cell Disorders)) OR<br>(Cell Disorder, Sickle)) OR (Cell Disorders, Sickle)) OR (Sickle Cell Disorder)) OR<br>(Sickling Disorder Due to Hemoglobin S)) OR (HbS Disease)) OR (Sickle Cell<br>Disease)) OR (Cell Disease, Sickle)) OR (Cell Diseases, Sickle)) OR (Sickle Cell<br>Diseases))<br>AND<br>((((((((critznlizumab)) OR (Crizanlizumab)) OR (Adakveo)) OR (B06AX01)) OR<br>(SEG101)) OR (SEG1)) OR (crizanlizumab[Supplementary Concept]))|67|
|EMBASE<br>Total|('sickle cell anemia'/exp OR 'anemia, sickle cell' OR 'sickle-cell disease' OR 'sickle<br>hemoglobin c disease' OR 'hbsc' OR 'sickle β0-thalassemia' OR 'hbsβ0-thalassemia' OR<br>'sickle β+-thalassemia' OR 'hbsβ+-thalassemia' OR 'anemias, sickle cell' OR 'sickle cell<br>anemias' OR 'hemoglobin s disease' OR 'disease, hemoglobin s' OR 'hemoglobin s<br>diseases' OR 'sickle cell disorders' OR 'sickling disorder due to hemoglobin s' OR 'hbs<br>disease' OR 'sickle cell disease' OR 'cell disease, sickle' OR 'cell diseases, sickle' OR<br>'sickle cell diseases') AND [embase]/lim<br>AND<br>('crizanlizumab'/exp OR 'adakveo' OR 'crizanlizumab' OR 'tmcacrizanlizumab-<br>tmcanvp' OR 'lxi262nvplxi262seg' OR '101seg101sel' OR 'g1selg1') AND<br>[humans]/lim AND [embase]/lim|246<br>313|  
**Fonte:** Elaboração própria.  
Também foi realizada uma busca no clinicaltrials.gov com o intuito de identificar os estudos em andamento sobre crizanlizumabe, e como busca manual, avaliar se havia resultado já publicado sobre estes estudos. Para isso, foram utilizados apenas os termos “sick cell desease” AND “crizanlizumab” e a busca foi realizada em janeiro de 2023.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Seleção dos estudos e extração dos dados** -->
A seleção dos estudos elegíveis, compreendendo as etapas de leitura de título e resumo (triagem) e leitura por texto completo (elegibilidade) foi realizada por um avaliador, sendo consultado um segundo avaliador em caso de dúvidas que foram  
resolvidas em consenso. Foi utilizado o software Rayyan para realizar a exclusão das referências duplicadas e a triagem dos estudos em avaliação (44). Para a extração dos dados foi utilizada uma planilha Excel pré-estruturada e foi realizada por um único avaliador. Os seguintes dados foram extraídos:  
- Características dos estudos, intervenções e participantes: autor, ano; país; desenho do estudo; características gerais da população; número de participantes; idade média; sexo; alternativas comparadas; cointervenções; duração do tratamento e critérios de inclusão.  
- Desfechos e resultados: na extração dos dados dos desfechos, coletou-se as pontuações médias (média final ou média da variação), os desvios-padrão e os tamanhos das amostras dos estudos. Quando essas informações não foram fornecidas, os valores foram calculados ou imputados, usando métodos recomendados no _Cochrane Handbook for Systematic Reviews of Interventions_ .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Avaliação da qualidade metodológica ou risco de viés dos estudos** -->
O risco de viés foi avaliado de acordo com o delineamento do estudo, por um único avaliador. Havendo revisão sistemática incluída, seria avaliada por meio da ferramenta AMSTAR-2 (45). Havendo ensaios clínicos randomizados incluídos, foram avaliados por meio da ferramenta Cochrane Risk of Bias Tool – ROB 2.0 (46,47). Para estudos observacionais comparativos, a ferramenta ROBINS-I da colaboração Cochrane seria utilizada (48).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Síntese e análise dos dados** -->
A síntese dos dados foi realizada com base na representação individual de cada estudo. As características dos estudos e dos participantes foram apresentadas de forma narrativa e por estatística descritiva (frequência absoluta e relativa, média e DP ou mediana e intervalo interquartil [IIQ]), incluindo tabelas para o auxílio na apresentação dos resultados). Os resultados narrativos foram agrupados por desfecho. Para avaliação da heterogeneidade, métodos informais seriam utilizados considerando inspeção visual de tabelas de características e resultados e potenciais modificadores (delineamento do estudo, tempo de seguimento, idade e tempo de diagnóstico dos participantes).  
Existindo mais de um estudo incluído e homogeneidade entre eles, análises quantitativas (meta-análise pairwise) seriam realizadas com o uso do software Review Manager (7). Os dados contínuos deste ensaio clínico controlado foram avaliados por meio da mediana do tempo até o evento de interesse (por exemplo, uma crise vasoclusiva) ao longo de um período de 1 ano. Para resumir a relação entre as variáveis independentes e o tempo até o evento, foi utilizado o _Hazard Ratio_ (HR) [IC 95%]. Os dados contínuos foram avaliados por meio da mediana ao longo do tempo até o evento de interesse (por exemplo, uma crise vasoclusiva) ao longo de um período de 1 ano. Para resumir a relação entre as variáveis independentes e o tempo até o evento, foi utilizado o HR [IC 95%]. A análise de HR com base em dados contínuos da mediana de eventos requer uma avaliação cuidadosa da distribuição dos dados e da adequação do modelo estatístico escolhido. A comparação entre a mediana de eventos entre dois grupos (por exemplo, intervenção versus placebo) permite avaliar a associação entre a variável de exposição e a mediana de eventos. Se a mediana de eventos for maior em um grupo em comparação com o outro, isso indica que a exposição está associada a um maior risco de evento. Se a mediana de eventos for menor em um grupo em comparação com o outro, isso indica que a exposição está associada a um menor risco de evento.  
Os dados categóricos foram sumarizados como _Risk Ratio_ (RR) [IC 95%]. O RR pode ser interpretado como a razão entre os riscos relativos de ocorrência de um evento entre os dois grupos. Se o RR é maior que 1, significa que o risco de ocorrência do evento é maior no grupo exposto do que no grupo controle, sugerindo uma associação positiva entre a exposição e o desfecho. Se o RR é igual a 1, não há diferença significativa no risco de ocorrência do evento entre os dois grupos, sugerindo ausência de associação. Se o RR é menor que 1, significa que o risco de ocorrência do evento é menor no grupo exposto do que no grupo controle, sugerindo uma associação negativa entre a exposição e o desfecho.  
Nas análises quantitativas, os tratamentos foram agrupados segundo as apresentações os medicamentos e os resultados foram apresentados em tabelas e forest plot. Análises de subgrupos foram planejadas por tipo de participante e com base nos  
seguintes critérios: 1) genótipo da doença falciforme, estratificados entre genótipo HbSS ou não HbSS; 2) associação de hidroxiureia ao tratamento, estratificados entre sim ou não; e 3) no número de crises vaso-oclusivas prévias ao início do tratamento, estratificados como entre 2 a 4 crises prévias ou entre 5 a 10 crises prévias.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Avaliação da qualidade da evidência** -->
A qualidade ou confiança da evidência foi avaliada considerando as recomendações do _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE) Working Group (50), diretrizes metodológicas: sistema GRADE (51). Desfechos primários deste parecer foram graduados em alta, moderada, baixa e muito baixa confiança, considerando os critérios de rebaixamento da qualidade (limitações metodológicas, evidência indireta, inconsistência, imprecisão de estimativa de efeito e risco de viés de publicação).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **6. RESULTADOS** -->
**Figura A** . Fluxograma de seleção dos registros  
<!-- Start of picture text -->
Registos identiicados (n= 313) Registros removidos antes da Reglatos identlicados de<br>BubMed ‘triagem: Websites (n = 12)<br>Embase (n= 67) Registro dupicados OrganizacSes (n= 0)<br>(n= 246) removes eloncament Pesquisa de chagbes (n = 0)<br>Registos(n= 278)  trados Registos(n= 248) excluldos (n=)Registosrecuperacaoprocurados para (a=0)Registosrecuperadosnfo<br>j<br>% | Registos procurados para Reglatros nfo recuperados<br>% | recuperacio (@=1) -<br>2 | on) Registros avaliados para Registios<br>3 elegibiidade excluidos<br>i i (n= 12) (n= 12)<br>| Registos avaiados para Registros excluidos: 31<br>elegibiidade<br>(= 33) Populaglo (n=2)<br>Intervencdo (n=3)<br>Desfechos (0=4)<br>Delineamento do estudo (n=12)<br>3 Registros incluidos no PTC Tipo de publicagdo (n=10)<br>3 (n=2)<br>J__| Estudos incuidos no PTC<br>= [on<br><!-- End of picture text -->  
**Fonte:** Traduzido e preenchido de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/  
**Quadro B.** Estudos excluídos na elegibilidade com os motivos  
|**Primeiro**<br>**autor e ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Stevens D.<br>2021<sup>146</sup>|Crizanlizumab for the Prevention of Vaso-Occlusive Pain Crises<br>in Sickle Cell Disease|Tipo de estudo:revisão de literatura que<br>não continha resultados adicionais do<br>reportado no estudo SUSTAIN.|
|Yu Z.<br>2017<sup>147</sup>|Crizanlizumab in Sickle Cell Disease|Tipo de publicação:é um comentário sobre<br>o estudo SUSTAIN e não apresenta dados<br>novos.|
|Dick M.<br>2022<sup>148</sup>|Comparing the Safety and Efficacy of L-Glutamine, Voxelotor,<br>and Crizanlizumab for Reducing the Frequency of Vaso-<br>Occlusive Crisis in Sickle Cell Disease: A Systematic Review|Tipo de estudo:revisão sistemática que<br>incluiu todos os delineamentos e mesmo<br>assim, não continha resultados adicionais<br>do reportado no estudo SUSTAIN.|  
|**Primeiro**<br>**autor e ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Kutlar, A.<br>2017<sup>149</sup>|Crizanlizumab, A P-selectin inhibitor, increases the likelihood of<br>not experiencing a sickle cell-related pain crisis while on<br>treatment: Results from the phase II sustain study|Tipo de publicação:é um resumo de<br>congresso<br>de<br>análise<br>post-hoc<br>não<br>programada sobre o estudo SUSTAIN.|
|Kanter<br>J.<br>2017<sup>150</sup>|Crizanlizumab 5.0 mg/kg/kg increased the time to first on-<br>treatment sickle cell pain crisis: A subgroup analysis of the phase<br>ii sustain study|Tipo de publicação:é um resumo de<br>congresso de análise post-hoc de subgrupo<br>sobre o estudo SUSTAIN. Esse dado já foi<br>publicado e incluído.|
|||Tipo de publicação:é um resumo de|
|Ataga K.<br>2018<sup>151</sup>|Crizanlizumab treatment is not associated with the development<br>of proteinuria and hematuria in patients with sickle cell disease:<br>A safety analysis from the sustain study|congresso de análise post-hoc de subgrupo<br>sobre o estudo SUSTAIN. Esse dado já foi<br>publicado e incluído.|
||Crizanlizumab 5.0mg/kg/kg increased the time to first on-|Tipo de publicação:é um resumo de|
|Washko, J.<br>2018<sup>152</sup>|treatment Sickle Cell Pain Crisis (SCPC) and the likelihood of<br>not experiencing SCPC while on treatment: Subgroup analyses of<br>the phase 2 sustain study|congresso de análise post-hoc de subgrupo<br>sobre o estudo SUSTAIN. Esse dado já foi<br>publicado e incluído.|
||A Multicenter Retrospective Noninterventional Follow-up Study|Tipo de estudo:é um resumo de congresso|
|Shah<br>N.<br>2018<sup>153</sup>|<br>in Patients with Sickle Cell Pain Crisis Who Previously<br>Participated in the Sustain Trial in the United States Successor<br>Study|de uma série de casos retrospectiva. Uma<br>análise parcial (5 pacientes) do estudo<br>“SUCCESSOR”, em andamento.|
|Liles D.<br>2018<sup>154</sup>|Established<br>prevention<br>of<br>vaso-occlusive<br>crises<br>with<br>crizanlizumab is further improved in patients who follow the<br>standard treatment regimen: Post-hoc analysis of the phase II<br>sustain study|Tipo de publicação:é um resumo de<br>congresso de análise post-hoc de subgrupo<br>sobre o estudo SUSTAIN. Esse dado já foi<br>publicado e incluído.|
|||Tipo de estudo e desfecho:é um resumo de|
|Yen G.<br>2022<sup>155</sup>|HSD63 Real-World Crizanlizumab Treatment Patterns of<br>Patients with Sickle Cell Disease|congresso<br>de<br>uma<br>série<br>de<br>casos<br>retrospectiva e os desfechos avaliados não<br>se enquadram nos critérios de inclusão.|
|Silva-Pinto<br>A. 2022<sup>156</sup>|Real-World Incidence Of Vaso-Occlusive Crises In Patients With<br>Sickle Cell Disease (SCD) And A High Baseline Disease Burden<br>Treated With Crizanlizumab: Results From A Managed Access<br>Program (MAP)|Tipo de publicação:é um resumo de<br>congresso com dados insuficientes para a<br>inclusão. Não tem grupo comparador.|
|Bueno C.<br>2022<sup>157</sup>|Effectiveness Of Crizanlizumab In Reducing Vaso-Occlusive<br>Crisis In Patients With Sickle Cell Disease In Brazil: Study<br>Protocol For An Observational, Retrospective, Multicenter,<br>National Study|Tipo de estudo:é um resumo de congresso<br>de um protocolo, ainda sem dados de<br>resultados.|
|Yang M.<br>2022<sup>158</sup>|Health-Related Quality of Life and Adherence to Hydroxyurea<br>and Other Disease-Modifying Therapies among Individuals with<br>Sickle Cell Disease: A Systematic Review|Tipo de intervenção:não apresenta os<br>resultados de crizanlizumabe.|  
|**Primeiro**<br>**autor e ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Heeney M.<br>2022<sup>159</sup>|Safety and efficacy of crizanlizumab in adolescents with sickle<br>cell disease (SCD): Initial data from the phase II, multicenter,<br>open-label Solace-Kids trial|Tipo de população:dados iniciais de<br>crizanlizumabe em crianças (Solace-kids)|
|Heeney M.<br>2021<sup>160</sup>|Initial Safety and Efficacy Results from the Phase II, Multicenter,<br>Open-Label Solace-Kids Trial of Crizanlizumab in Adolescents<br>with Sickle Cell Disease (SCD)|Tipo de população:é um resumo de<br>congresso<br>com<br>dados<br>iniciais<br>de<br>crizanlizumabe em crianças (Solace-kids)|
|Kanter J.<br>2021<sup>161</sup>|Rare Cases of Infusion-Related Reactions (IRRs) Presenting As<br>Pain Events during or after Crizanlizumab Infusion in Patients<br>(Pts) with Sickle Cell Disease (SCD): A Systematic Evaluation<br>of Post-Marketing (PM) Reports|Tipo de publicação:é um resumo de<br>congresso com dados insuficientes para a<br>inclusão.|
|Martí-|Aill  f i li  i|Tipo de estudo:revisão sistemática que não|
|Carvajal A.<br>2019<sup>162</sup>|ntpateet agents or preventng vaso-occusve events n<br>people with sickle cell disease: a systematic review|continha<br>resultados<br>adicionais<br>do<br>reportado no estudo SUSTAIN.|
|Ataga k.<br>2019<sup>163</sup>|Crizanlizumab treatment is associated with clinically significant<br>reductions in hospitalization in patients with sickle cell disease:<br>Results from the sustain study|Tipo de publicação:é um resumo de<br>congresso de análise post-hoc de subgrupo<br>sobre o estudo SUSTAIN. Esse dado já foi<br>publicado e incluído.|
|Kanter J.<br>2019<sup>164</sup>|Crizanlizumab 5.0 Mg/kg/Kg Exhibits a Favorable Safety Profile<br>in Patients with Sickle Cell Disease: Pooled Data from Two<br>Phase II Studies.|Tipo de estudo:é um resumo de congresso<br>de dados agrupados de dois estudos de fase<br>II (SUSTAIN E SOLACE).|
|Ataga K.<br>2019<sup>165</sup>|The Effect of Crizanlizumab Plus Standard of Care (SoC) Versus<br>Soc Alone on Renal Function in Patients with Sickle Cell Disease<br>and Chronic Kidney Disease: A Randomized, Multicenter, Open-<br>Label, Phase II Study (STEADFAST)|Tipo de estudo:é um resumo de congresso<br>de um protocolo, ainda sem dados de<br>resultados (STEADFAST).|
|Katoch, D.<br>2021<sup>166</sup>|Assessing Patient Preferences for Treatment Options for<br>Pediatric Sickle Cell Disease: A Critical Review of Quantitative<br>and Qualitative Studies|Tipo de estudo:revisão crítica sem dados<br>quantitativos de crizanlizumabe.|
|Smith W.<br>2020<sup>167</sup>|The effect of crizanlizumab on the number of days requiring<br>opioid use for management of pain associated with vaso-<br>occlusive crises in patients with sickle cell disease: Results from<br>the Sustain trial|Tipo de publicação:é um resumo de<br>congresso de análise post-hoc de subgrupo<br>sobre o estudo SUSTAIN. Esse dado já foi<br>publicado e incluído.|
|Cançado R.<br>2021<sup>168</sup>|Real-world data on the occurrence of vaso-occlusive crises<br>(VOCS) in patients with sickle cell disease (SCD) and a high<br>baseline disease burden treated with crizanlizumab: Results from<br>a managed access program (MAP)|Tipo de publicação e desfechos:é um<br>resumo de congresso referente ao estudo<br>MAP que avalia desfechos descritivos do<br>crizanlizumabe<br>e<br>não<br>o<br>efeito<br>da<br>intervenção.|
|Silva-Pinto<br>A. 2021<sup>169</sup>|Real-world data from the crizanlizumab managed access program<br>(map): Baseline disease burden and prior treatments for patients|Tipo de publicação e desfechos:é um<br>resumo de congresso referente ao estudo<br>MAP que avalia desfechos descritivos do|  
|**Primeiro**<br>**autor e ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
||with sickle cell disease (scd) and recurrent vasoocclusive crises<br>(vocs)|crizanlizumabe<br>e<br>não<br>o<br>efeito<br>da<br>intervenção.|
|Han J.<br>2020<sup>170</sup>|A Systematic Review and Network Meta-analysis of Novel<br>Androgen Receptor Inhibitors in Non-metastatic Castration-<br>resistant Prostate Cancer|Tipo de estudo:revisão sistemática que não<br>tem transparência da busca utilizada, não<br>faz avaliação de risco de viés dos estudos<br>incluídos, não avalia a certeza na<br>evidência. Portanto, a decisão foi utilizar<br>os estudos individuais.|
|||Tipo de intervenção:revisão sistemática<br>com análises indiretas que incluem|
|Thom H.<br>2020<sup>171</sup>|Crizanlizumab and comparators for adults with sickle cell<br>disease: A systematic review and network meta-analysis<br>147 A Prospective Phase II, Open-Label, Single-arm, Multicenter|crizanlizumabe comparado a ticagrelor, N-<br>acetilcisteína, senicapoc e L-glutamina.<br>Nenhum desses comparadores foram<br>incluídos em reunião de escopo.<br>|
|Burnett A.<br>2020<sup>172</sup>|Study to Assess the Efficacy and Safety of SEG101<br>(Crizanlizumab) in Sickle Cell Disease Patients With Priapism<br>(SPARTAN)|Tipo de estudo:é um resumo de congresso<br>de um protocolo, ainda sem dados de<br>resultados (SPARTAN).|
|El Rassi F.<br>2019<sup>173</sup>|A Prospective Phase II, Open-Label, Single-Arm, Multicenter<br>Study to Assess the Efficacy and Safety of SEG101<br>(Crizanlizumab) in Sickle Cell Disease Patients with Priapism<br>(SPARTAN)|Tipo de estudo:é um resumo de congresso<br>de um protocolo, ainda sem dados de<br>resultados (SPARTAN).|
|Abboud M.<br>2019<sup>174</sup>|Crizanlizumab<br>Versus<br>Placebo,<br>with<br>or<br>without<br>Hydroxyurea/Hydroxycarbamide, in Adolescent and Adult<br>Patients with Sickle Cell Disease and Vaso-Occlusive Crises: A<br>Randomized, Double-Blind, Phase III Study (STAND)|Tipo de estudo:é um resumo de congresso<br>de um protocolo, ainda sem dados de<br>resultados (STAND).|
||Steadfast: A phase ii study investigating the effect of||
|Bartolucci|crizanlizumab and standard of care (SOC) vs soc alone on renal|Tipo de estudo:é um resumo de congresso|
|P.<br>2020<sup>175</sup>|function in patients with chronic kidney disease due to sickle cell<br>nephropath. Abstract Book: 25th Congress of the European<br>Hematology Association Virtual Edition, 2020|de um protocolo, ainda sem dados de<br>resultados (STEADFAST).|
|Saraf S.<br>2021<sup>176</sup>|A Phase II, Randomized, Multicenter, Open-Label Study<br>Evaluating the Effect of Crizanlizumab and Standard of Care<br>(SoC) Versus Standard of Care Alone on Renal Function in<br>Patients with Chronic Kidney Disease Due to Sickle Cell<br>Nephropathy (STEADFAST)|Tipo de estudo:é um resumo de congresso<br>de um protocolo, ainda sem dados de<br>resultados (STEADFAST).|  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Características dos estudos incluídos** -->
Após processo de seleção de estudos elegíveis, foi selecionado um estudo controlado randomizado de fase 2 para inclusão, que será brevemente descrito a seguir ( **Quadro C** ).  
**Quadro C.** Caracterização do estudo incluído.  
|**Estudo**|**Características gerais da população**|**País**|**Follow**<br>**up**|**Alternativas**<br>**comparadas**<sup>**a**</sup>|**Financiamento**|
|---|---|---|---|---|---|
|Ataga k_. et al,_|N=198|Brasil,|12|Crizanlizumabe|Selexys|
|2017|DF de diferentes genótipos|Jamaica e|meses|2,5<br>mg/kg|Pharmaceuticals|
||Idade entre 16 e 65 anos|Estados||_versus_||
|ECR Fase II|2 a 10 crises vaso-oclusivas nos últimos|Unidos||Crizanlizumabe||
|duplo cego|12 meses<br>Hidroxiureia associada se o paciente já|||5,0<br>mg/kg<br>_versus_||
|SUSTAIN|fizesse uso antes do início do estudo e|||Placebo||
|(NCT01895361)|estava estável|||||
|ECR Fase II|N=132|Brasil,|12|Crizanlizumabe|Selexys|
|duplo cego|Mesmas características do estudo de|Jamaica e|meses|5,0<br>mg/kg|Pharmaceuticals|
|Análise post hoc|Ataga K, acima, porém estratificada em<br>subgrupos quanto ao número de crises|Estados<br>Unidos||_versus_<br>Placebo||
|SUSTAIN|vaso-oclusivas, genótipo da doença|||||
|(NCT01895361)|falciforme e uso de hidroxiureia.|||||  
**Fonte:** Elaboração própria. **Legenda:** DF: Doença Falciforme; N: número de participantes. a – Como a diferença entre os grupos são crizanlizumabe e placebo, foram representadas estas alternativas. Entretanto, em ambos os grupos 62% a 63% utilizavam hidroxiureia como cointervenção.  
SUSTAIN é um estudo controlado por placebo, randomizado, duplo-cego e multicêntrico de fase 2, com duração de 12 meses. No estudo, Ataga e colaboradores (2017) avaliaram a eficácia e segurança de tratamentos com crizanlizumabe (nas doses de 2,5 ou 5,0 mg/Kg) associados ou não à hidroxiureia em relação à placebo associado ou não à hidroxiureia. O objetivo principal do estudo foi determinar o efeito de tratamentos com crizanlizumabe na taxa de crises vaso-oclusivas durante o período de 52 semanas.  
Em relação ao delineamento do estudo foram previstas três fases, uma primeira de triagem com 30 dias de duração, seguida por 52 semanas de tratamento (manutenção) e depois 6 semanas de acompanhamento. Os participantes, randomizados em três braços, receberam doses de crizanlizumabe (2,5 ou 5,0 mg/Kg) ou placebo administradas durante um período de 30 minutos por infusão intravenosa na semana 0, na semana 2 e em seguida, a cada 4 semanas até a semana 50, para um total de 14 doses. Os participantes já em uso de hidroxiureia foram orientados a manter o tratamento (~62%) nas mesmas doses e aqueles que não faziam tratamento com hidroxiureia (~38%) não puderam iniciá-lo uma vez selecionados para participar do estudo.  
No estudo participaram indivíduos diagnosticados com doença falciforme de ambos os sexos, em sua maioria pretos (90%), com faixa de idade entre 16 e 65 anos (medianas entre 26 e 29 anos) e diversos genótipos (HbSS (70%), HbSC, talassemia beta zero [HbSβ0], talassemia beta mais [HbSβ+], ou outros genótipos). Os participantes apresentaram histórico de 2 a 10 crises vaso-oclusivas com dor no período de 12 meses antes do início do estudo (2 a 4 crises ~63% e 5 a 10 crises ~37%). Foram excluídos candidatos que faziam transfusões sanguíneas habitualmente por longo período.  
Em período de recrutamento de 2 anos foram randomizados 198 participantes em três braços para receber baixa dose de crizanlizumabe (n=66), alta dose de crizanlizumabe (n=67) ou placebo (n=65) em associação ou não à hidroxiureia.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Qualidade de vida** -->
Ataga e colaboradores relatam que a avaliação da qualidade de vida foi realizada com o questionário _Brief Pain Inventory_ (Inventário Breve de Dor) e que as mudanças no domínio de intensidade da dor e no domínio de interferência da dor do questionário, ao longo do estudo foram pequenas. Não houve mudanças significativas no desfecho quando avaliado pelo método da média dos mínimos quadrados para os tempos antes e depois do tratamento com crizanlizumabe.  
Uma recente revisão sistemática relata que o uso de hidroxiureia está correlacionado com melhores escores de qualidade de vida em pacientes com doença falciforme (13). Porém, esta revisão não encontrou nenhum estudo que avaliasse a influência do crizanlizumabe na qualidade de vida desses pacientes. Portanto, devido à falta de informações, futuros estudos devem incluir avaliações da qualidade de vida para a avaliação de crizanlizumabe.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Taxa anual de crises vaso-oclusivas** -->
O desfecho primário do estudo foi a taxa anual de crises vaso-oclusivas, estimada a partir da seguinte fórmula: (número total de crises x 365)/(data final do estudo – data da randomização + 1). Definiu-se uma crise de dor como: episódio agudo decorrente de uma crise vasoclusiva, para o qual foi necessária internação ou intervenção médica pela prescrição de medicamentos para dor opioides ou anti-inflamatórios não esteroidais intravenosos. Considerou-se também como crise a apresentação de episódios agudos de síndrome torácica; priapismo ou de sequestros esplênico ou hepático.  
O resultado da taxa anual de crise vasoclusiva foi expresso por mediana e intervalo interquartil para a população geral e subgrupos. Para a população geral, identificou-se, utilizando o teste estratificado de Wilcoxon, diferença estatisticamente significante entre o grupo tratado com crizanlizumabe 5,0 mg/kg e o grupo placebo (p=0,01), na análise por intenção de tratar e na análise por protocolo (p=0,02). A mediana da taxa anual de crises no grupo crizanlizumabe foi de 1,63 crises em um ano, e de 2,98 para o grupo placebo, indicando uma redução de 45,3% para pacientes que fizeram o tratamento com crizanlizumabe. Para o grupo que recebeu tratamento com a dose menor de crizanlizumabe (2,5 mg/kg) não se identificou diferença estatística na taxa anual de crises em relação ao placebo (p=0,18). Na **Tabela A** são apresentadas as medianas e os respectivos intervalos interquartis para a população geral.  
**Tabela A.** Resultados para desfechos relativos à taxa de crise vasoclusiva (mediana de crises vaso-oclusivas em um ano) em participantes com doença falciforme, referentes ao estudo SUSTAIN.  
|**População**|**Grupo Inter**|**venção**||**Grupo Contr**|**ole**||**Medida de efeito (IC**|
|---|---|---|---|---|---|---|---|
||**Mediana**|**IIQ**|**N**|**Mediana**|**IIQ**|**N**|**95%), p**|
|**Crizanlizumabe**|**alta dose (5,0**|**mg/kg) versus Pl**|**acebo**|||||
|ITTa|1,63 crises|0,0 a 3,97|67|2,98 crises|1,25 a 5,87|65|NR; p=0,01|
|Por Protocolob|1,04 crises|0,0 a 3,42|40|2,18 crises|1,96 a 4,96|41|NR; p=0,02|  
**Fonte** : Elaboração própria. **Legenda:** HBS: Hemoglobina S; IIQ: _Intervalo interquartil_ ; ITT: Análise por intenção de tratar; IC: intervalo de confiança; n ou N: número; NR: não reportado; p: valor de p. **A** – Análise por intenção de tratar inclui todos os pacientes aleatoriamente designados para cada grupo, independentemente de completarem ou não o tratamento. **B** – Análise por protocolo incluiu somente os pacientes que receberam no mínimo 12 doses de crizanlizumabe, dentre as 14 doses previstas.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Taxa anual de crises vaso-oclusivas não complicadas** -->
Crise de dor não complicada foi definida como crise vasoclusiva sem quadro de síndrome torácica aguda, sequestro hepático, sequestro esplênico ou priapismo (eventos raros no estudo). O resultado das taxas anuais de crises vaso-oclusivas não complicada foram expressos por mediana e intervalo interquartil para a população geral.  
Para este desfecho identificou-se diferença estatisticamente significante entre o grupo tratado com crizanlizumabe 5,0 mg/kg e o grupo placebo (p=0,02), conforme apresentado na **Tabela B** . A mediana da taxa anual de crises não complicadas no  
grupo crizanlizumabe foi de 1,08 crises em um ano, comparada com 2,91 para o grupo placebo, indicando uma redução de 62,9% no grupo que fez o tratamento com crizanlizumabe.  
**Tabela B.** Resultados para o desfecho taxa anual de crises vaso-oclusivas não complicadas (mediana da taxa anula de crises vaso-oclusivas) em participantes com doença falciforme, referentes ao estudo SUSTAIN.  
|**População**|Grupo Interv<br>**Mediana**|enção<br>**IIQ**|**N**|Grupo Control<br>**Mediana**|e<br>**IIQ**|**N**|**Medida de efeito (IC**<br>**95%), p**<sup>**c**</sup>|
|---|---|---|---|---|---|---|---|
|**Crizanlizuma**|**be alta dose (5,0**|**mg/kg)****_versus_  **|**Placebo**|||||
|ITT<sup>a</sup>|1,08 crises|0,0 a 3,96|67|2,91 crises|1,0 a 5,0|65|NR; p=0,02|  
**Fonte** : Elaboração própria. **Legenda:** IIQ: _Intervalo interquartil_ ; ITT: Análise por intenção de tratar; IC: intervalo de confiança; n ou N: número; NR: não reportado; p: valor de p. **A** – Análise por intenção de tratar inclui todos os pacientes aleatoriamente designados para cada grupo, independentemente de completarem ou não o tratamento. **B** – O valor do quartil 75% não foi encontrado em 52 semanas de acompanhamento.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Internação** -->
A mediana da taxa anual de dias hospitalizado foi de 4,00 por ano no grupo que recebeu crizanlizumabe 5,0 mg/kg e de 6,87 no grupo que recebeu placebo. A taxa foi 41,8% mais baixa para o grupo que recebeu crizanlizumabe, entretanto, não houve diferença estatística entre os grupos (p=0,45), conforme apresentado na **Tabela C** .  
**Tabela C.** Resultados para o desfecho internação (mediana da taxa anual de dias hospitalizado) em participantes com doença falciforme, referentes ao estudo SUSTAIN.  
|**População**|**Grupo Interv**<br>|**enção**<br> <br>|**Grupo Contro**<br>|**le**<br>||**Medida de efeito (IC**<br>|
|---|---|---|---|---|---|---|
||**Mediana**|**IIQ**<br>**N**|**Mediana**|**IIQ**|**N**|**95%), p**|
|**Crizanlizuma**|**be alta dose (5,0**|**mg/kg)****_versus_ Placebo**|||||
|ITT<sup>a</sup>|4,00 por ano|0,0<br>a<br>67|6,87 por ano|0,0 a 28,30|65|NR; p=0,45|
|||25,72|||||  
**Fonte** : Elaboração própria. **Legenda:** IIQ: _Intervalo interquartil_ ; ITT: Análise por intenção de tratar; IC: intervalo de confiança; n ou N: número; NR: não reportado; p: valor de p. **a** – Análise por intenção de tratar inclui todos os pacientes aleatoriamente designados para cada grupo, independentemente de completarem ou não o tratamento. **b** – O valor do quartil 75% não foi encontrado em 52 semanas de acompanhamento.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Tempo até a primeira e a segunda crises de dor** -->
O tempo para a primeira crise de dor foi mensurado em meses e expresso como mediana e intervalo interquartil para a população geral e subgrupos.  
Para a população geral, houve uma redução de metade do tempo até a primeira crise para pacientes tratados com o crizanlizumabe 5,0 mg/kg (mediana de 4,07 IIQ 1,31 a NR) em comparação com o placebo (1,38 (0,39 a 4,90)) (HR 0,50; IC 95% 0,33 a 0,74; p=0,001).  
A mediana do tempo até a segunda crise de dor foi de 10,32 (IIQ 4,47–NR) meses para o grupo que recebeu crizanlizumabe 5,0 mg/kg e de 5,09 (IIQ 2,96–11,01) no grupo placebo (HR 0,53; IC 95% 0,33 a 0,87; p=0,02).  
Na **Tabela D** estão descritas as medianas e os respectivos intervalos interquartis para a população geral para o desfecho tempo até a primeira crise de dor.  
**Tabela D.** Resultados para o desfecho tempo para a primeira crise de dor (expresso como a mediana em meses) em participantes com doença falciforme, referentes ao estudo SUSTAIN.  
|**População**|**Grupo Inter**<br>**Mediana**|**venção**<br>**IIQ**|**N**|**Grupo Controle**<br>**Mediana**<br>**IIQ**|**HR (IC 95%) c**<br>**N**|
|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Crizanlizumabe alta dose (5,0 mg/kg) versus Placebo** -->
|ITTa|4,07 meses|1,31<br>a<br>67|1,38 meses|0,0 a 28,30|65|0,50 (0,33 a 0,74)|
|---|---|---|---|---|---|---|
|||NRb|||||  
**Fonte** : Elaboração própria. **Legenda:** CVO: Crise Vasoclusiva; HBS: Hemoglobina S; HR: _Hazard Ratio_ ; IIQ: _Intervalo interquartil_ ; ITT: Análise por intenção de tratar; IC: intervalo de confiança; n ou N: número; NR: não reportado; p: valor de p. **a** – Análise por intenção de tratar inclui todos os pacientes aleatoriamente designados para cada grupo, independentemente de completarem ou não o tratamento. **b** – O valor do quartil 75% não foi encontrado em 52 semanas de acompanhamento.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Incidência de eventos adversos graves** -->
Eventos adversos graves ocorrem em 55 participantes do estudo, 17 e 21 nos grupos que receberam alta e baixa doses de crizanlizumabe, respectivamente, e 17 no grupo que recebeu placebo. Os mais frequentes nos grupos que receberam os tratamentos com crizanlizumabe foram pirexia e influenza. Pneumonia grave ocorreu com frequência nos três grupos do estudo. Em síntese realizada pelo grupo elaborador não foi encontrada diferença entre o grupo tratado com crizanlizumabe 5,0 mg/kg e o grupo que recebeu placebo em relação à incidência de eventos adversos graves (RR 0,94; IC 95% 0,53 a 1,67).  
**Mortalidade e incidência de eventos adversos gerais, imunogenicidade e hemólise**  
Durante o estudo houve cinco mortes. Dois pacientes que receberam alta dose de crizanlizumabe morreram, um devido à síndrome torácica aguda e outro por endocardite e sepse. Um paciente que recebeu baixa dose de crizanlizumabe morreu devido à síndrome torácica aguda, aspiração, insuficiência respiratória e congestão vascular progressiva. Dois pacientes no grupo placebo morreram, um devido à insuficiência ventricular direita e outro por crise vasoclusiva, acidente vascular cerebral isquêmico, coma, sepse e trombose venosa do membro inferior direito.  
Os eventos adversos relatados em 10% ou mais nos pacientes dos grupos de tratamento ativo foram cefaleia, dor nas costas, náusea, artralgia, dor nos membros superiores e inferiores, infecções urinárias e respiratórias, febre, diarreia, dor musculoesquelética, coceira, vômito e dor no peito. Não houve diferença entre grupos para nenhum dos eventos adversos mais relatados (p>0,05).  
No tempo de acompanhamento de 1 ano não foram detectados anticorpos contra crizanlizumabe.  
Em comparação com placebo, os tratamentos com crizanlizumabe não alteraram variáveis hemolíticas avaliadas, tais como variação na concentração de hemoglobina; lactato desidrogenase; número de reticulócitos; haptoglobina e bilirrubina indireta.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Evidência clínica por subgrupos populacionais** -->
A Tabela E descreve as medianas e seus respectivos intervalos interquartis, tanto para a população geral quanto para os subgrupos avaliados. No entanto, é importante destacar que o estudo SUSTAIN (11) não apresenta análise entre grupos para os subgrupos avaliados e a interpretação desses resultados são somente descritivas e devem ser lidas com cautela.  
**Tabela E** . Resultados para desfechos relativos à taxa de crise vasoclusiva (mediana de crises vaso-oclusivas em um ano) em participantes com doença falciforme, referentes ao estudo SUSTAIN.  
|**População**|**Grupo Inter**|**venção**||**Grupo Contr**|**ole**||**Diferença**<br>**grupos d,e**|**entre**|
|---|---|---|---|---|---|---|---|---|
|<br>**Crizanlizumab**<br>Geral|**Mediana**<br>**e alta dose (5,0 m**|**IIQ**<br>**g/kg) ve**|**N**<br>**rsus Placebo**|**Mediana**|**IIQ**|**N**|**Medida de ef**<br>**95%)**|**eito (IC**|
|ITTa|1,63 crises|0,0<br>3,97|a<br>67|2,98 crises|1,25 a 5,87|65|NR; p=0,01||  
|**População**|**Grupo Inter**|**venção**||**Grupo Contr**|**ole**||**Diferença**<br>**grupos d,e**|**entre**|
|---|---|---|---|---|---|---|---|---|
||**Mediana**|**IIQ**|**N**|**Mediana**|**IIQ**|**N**|**Medida de ef**<br>**95%)**|**eito (IC**|
|Por Protocolob|1,04 crises|0,0<br>3,42|a<br>40|2,18 crises|1,96 a 4,96|41|NR; p=0,02||
|Hidroxiureia|||||||||
|Sim|2,43 crises|0,0<br>2,00|a<br>42|3,58 crises|1,13 a 6,23|40|NR||
|Não|1,00 crises|0,0<br>2,00|a<br>25|2,00 crises|1,63 a 3,90|25|NR||
|CVO anteriorc|||||||||
|De 2 a 4|1,14 crises|0,0<br>3,96|a<br>42|2,00 crises|1,00 a 3,90|41|NR||
|De 5 a 10|1,97 crises|0,0<br>3,98|a<br>25|5,32 crises|2,00 a 11,50|24|NR||
|Genótipo|||||||||
|HBSS|1,97 crises|0,0<br>3,96|a<br>47|3,01 crises|1,01 a 6,00|47|NR||
|Outros|0,99 crises|0,0<br>4,01|a<br>20|2,00 crises|1,86 a 5,00|18|NR||  
**Fonte** : Elaboração própria. **Legenda:** CVO: Crise Vasoclusiva; HBS: Hemoglobina S; HR: _Hazard Ratio_ ; IIQ: _Intervalo interquartil_ ; ITT: Análise por intenção de tratar; IC: intervalo de confiança; n ou N: número; NR: não reportado; p: valor de p. **a** – Análise por intenção de tratar inclui todos os pacientes aleatoriamente designados para cada grupo, independentemente de completarem ou não o tratamento. **b** – Análise por protocolo incluiu somente os pacientes que receberam no mínimo 12 doses de crizanlizumabe, dentre as 14 doses previstas. **c** – Se refere ao número de crises vaso-oclusivas durante os doze meses prévios ao início do estudo; **d** – O estudo apresentou a diferença entre grupos utilizando um teste de estratificado de Wilcoxon, informando o valor de p da comparação. Os valores foram calculados para transformação em média e desvio padrão.  
**Tabela F.** Resultados para o desfecho tempo para a primeira crise vasoclusiva (mediana mensurada em meses) em participantes com doença falciforme, referentes ao estudo SUSTAIN.  
|**População**|**Grupo Interv**|**enção**||**Grupo Contro**|**le**||**Diferença**<br>**entre**<br>**grupos**<sup>**d**</sup>|
|---|---|---|---|---|---|---|---|
||**Mediana**|**IIQ**|**N**|**Mediana**|**IIQ**|**N**|**HR (IC 95%)**|
|**Crizanlizumabe**|**alta dose (5,0**|**mg/kg)****_ve_**|**_rsus_ Placebo**|||||
|Geral||||||||
|ITT<sup>a</sup>|4,07 meses|1,31<br>NR<sup>b</sup>|a<br>67|1,38 meses|0,0 a 28,30|65|0,50 (0,33 a 0,74)|
|Hidroxiureia||||||||
|Sim|2,43 meses|1,15<br>NR<sup>b</sup>|a<br>28|1,15 meses|0,33 a 4,90|33|0,58 (0,35 a 0,96)|
|Não|5,68 meses|3,09<br>NR<sup>b</sup>|a<br>15|2,86 meses|0,79 a 4,53|21|0,39 (0,20 a 0,76)|
|CVO anterior<sup>c</sup>||||||||  
|**População**|**Grupo Interv**|**enção**||**Grupo Contro**|**le**||**Diferença**<br>**entre**<br>**grupos**<sup>**d**</sup>|
|---|---|---|---|---|---|---|---|
||**Mediana**|**IIQ**|**N**|**Mediana**|**IIQ**|**N**|**HR (IC 95%)**|
|De 2 a 4|4,76 meses|1,81<br>NR<sup>b</sup>|a<br>25|1,61 meses|0,62 a 6,70|31|0,53 (0,31 a 0,90)|
|De 5 a 10|2,43 meses|1,25<br>7,75|a<br>18|1,03 meses|0,30 a 2,97|23|0,47 (0,25 a 0,89)|
|Genótipo||||||||
|HBSS|4,07 meses|1,31<br>NR<sup>b</sup>|a<br>32|1,12 meses|0,33 a 4,17|39|0,50 (0,31 a 0,80)|
|Outros|6,90 meses|1,41<br>NR<sup>b</sup>|a<br>11|3,09 meses|1,12 a 6,21|15|0,47 (0,21 a 1,05)|  
**Fonte** : Elaboração própria. **Legenda:** CVO: Crise Vasoclusiva; HBS: Hemoglobina S; HR: _Hazard Ratio_ ; IIQ: _Intervalo interquartil_ ; ITT: Análise por intenção de tratar; IC: intervalo de confiança; n ou N: número; NR: não reportado; p: valor de p. **a** – Análise por intenção de tratar inclui todos os pacientes aleatoriamente designados para cada grupo, independentemente de completarem ou não o tratamento. **b** – O valor do quartil 75% não foi encontrado em 52 semanas de acompanhamento. **c** –  Se refere ao número de crises vaso-oclusivas durante os doze meses prévios ao início do estudo.  
**Tabela G.** Resultados para o desfecho taxa anual de crises vaso-oclusivas não complicadas (mediana de crises vaso-oclusivas em um ano) em participantes com doença falciforme, referentes ao estudo SUSTAIN.  
|**População**|**Grupo Inter**|**venção**||**Grupo Contr**|**ole**||**Diferença**<br>**grupos**<sup>**c**</sup>|**entre**|
|---|---|---|---|---|---|---|---|---|
||**Mediana**|**IIQ**|**N**|**Mediana**|**IIQ**|**N**|**Medida de ef**<br>**95%)**|**eito (IC**|
|**Crizanlizumabe**|**alta dose (5,0**|**mg/kg)****_ve_**|**_rsus_ Placebo**||||||
|Geral|||||||||
|ITT<sup>a</sup>|1,08 crises|0,0<br>3,96|a<br>67|2,91 crises|1,0 a 5,0|65|NR; p=0,02||
|Hidroxiureia|||||||||
|Sim|1,74 crises|0,0<br>24,3|a<br>42|3,13 crises|0,0 a 13,3|40|NR||
|Não|0,98 crises|0,0<br>11,8|a<br>25|1,98 crises|0,0 a 19,8|25|NR||
|CVO anterior<sup>c</sup>|||||||||
|De 2 a 4|1,00 crises|0,0<br>11,8|a<br>42|1,97 crises|0,0 a 13,3|41|NR||
|De 5 a 10|1,85 crises|0,0<br>24,3|a<br>25|4,84 crises|0,0 a 19,2|24|NR||
|Genótipo|||||||||
|HBSS|1,63 crises|0,0<br>24,3|a<br>47|3,00 crises|0,0 a 19,2|47|NR||
|Outros|0,99 crises|0,0<br>15,2|a<br>20|2,00 crises|0,0 a 13,3|18|NR||  
**Fonte** : Elaboração própria. **Legenda:** IIQ: _Intervalo interquartil_ ; ITT: Análise por intenção de tratar; IC: intervalo de confiança; n ou N: número; NR: não reportado; p: valor de p. **a** – Análise por intenção de tratar inclui todos os pacientes aleatoriamente designados para cada grupo, independentemente de completarem ou não o tratamento. **b** – O valor do quartil 75% não foi encontrado em 52 semanas de acompanhamento. **c** – Se refere ao número de crises vasooclusivas durante os doze meses prévios ao início do estudo.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Risco de viés do estudo incluído** -->
Para desfechos de eficácia e segurança, as avaliações quanto ao risco de viés geral resultaram em ‘algumas preocupações’ (8 de 12 avaliações) seguido por ‘baixo risco de viés’ (4 de 12 avaliações). Nenhum desfecho foi avaliado como alto risco de viés. Os domínios em que todas das avaliações foram classificadas como ‘baixo risco de viés’ foram i) o processo de randomização; ii) desvios da intervenção pretendida; e iii) seleção do resultado reportado. ‘Algumas preocupações’ foram classificadas em todos os itens que avalia ‘perda de dados dos desfechos’, com a explicação que aproximadamente um terço dos pacientes do estudo descontinuou o tratamento do estudo precocemente e, embora as proporções e o tempo de descontinuação tenham sido semelhantes entre os grupos de tratamento, não está claro se isso foi afetado pelo estado da doença ou pela falta de eficácia do tratamento do estudo. Houve perda de acompanhamento de muitos pacientes, sendo 35% de perda para grupo crizanlizumabe 5,0 mg/kg; 31,8% de perda no grupo crizanlizumabe 2,5 mg/kg; e 36,9% de perda de acompanhamento para o grupo placebo. Os itens de ‘mensuração de desfecho’ também apresentaram algumas preocupações para a maioria dos itens, por motivos variados, como por exemplo, a falta de cálculo do tamanho do efeito.  
**Figura B** . Risco de viés do estudo SUSTAIN estratificado por desfecho.  
<!-- Start of picture text -->
‘Esudo Experimental Somparador Desfecho m2 Db BF Oe Ds Geral<br>fxge2037 Ciclcumabes.0mg Placebo Taantaldecrserno ous OO B® OO @ sinsice<br>sxga2037 Cicnlcumabe2.smg Plactbo Taran decsevno ous SO ® D @ O @ Aermaspresciparse<br>sxga2037 Cialsumabes.Omg Plactbo _Tenpoparsaprimeacristdedor OO @  @ @ © @ riiica<br>xge2017<br>Cinlsumibe2.smg Plactbo _Tenpoparaaprimeracrsn d ore e@e:'eee0<br>fxgs2037 Crantimabes.omg Plactoo—Intnagio @ @ ® BD @ © & Proceso derandomiagso<br>fags 2037 Cratmabe2.sme Plactoo —Intrnagio CH Oe Oe<br>fxgs2037 Craiumabes.omg Plctoo  Taaamialdecisermocciusivansocompicais @ @ @® | @ DO 02 raiededaiordodetcro<br>fxgs2037 Cialumsbe2Ssmg Pactbo — Taanialdecisermoocisvansocompicads @ @ DD @ OD v4 wensirssododesecno<br>sgs2037 Cilmabes.omg Plctbo  cudadedevida @ @ © D @ O b saesodoesudoreportado<br>‘age2017. Cizalinumabe?.sme lactbo Cialidadedevida ee»veo<br>110g22017 CrizanlizumabeS.0mg Placebo GrentosAdvesos e@e'eee<br>‘aga2017-<br>Crzanlisumabe2,Smg Placebo Eventos Adveros eeveee0e<br><!-- End of picture text -->  
**Fonte** : Elaboração própria. **Legenda:** D: Domínio.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **7.        Avaliação da qualidade da evidência** -->
A avaliação da qualidade da evidência, realizada por meio do GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ) resultou em certeza na evidência muito baixa para os desfechos: taxa de pacientes sem crise vasoclusiva após um ano, internação, qualidade de vida e taxa anual de crises vaso-oclusivas não complicadas. A certeza da evidência foi baixa para os desfechos tempo para a primeira crise de dor e eventos adversos graves. Os principais motivos para rebaixamento da evidência foram devido às evidências indiretas e imprecisão, conforme **Quadro D.**  
**Quadro D.** Avaliação da qualidade da evidência para a comparação de crizanlizumabe 5,0 mg/kg versus placebo em pacientes diagnosticados com doença falciforme, acima de 16 anos.  
|**Avaliação**<br>**№**<br>**dos**<br>**estudos**<br>**Mediana**|**da certeza**<br> <br>**Delineamento do**<br>**estudo**<br>**de crises vaso-oclusi**<br>|**Risco de**<br>**viés**<br>**vas em u**<br>|<br>**Inconsistência**<br>**m ano**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**consideraçõe**|**№ de pacientes**<br>**s**<br>**crizanlizumabe**<br>**5,0 mg/kg**<br>|<br>**placebo**<br>|**Efeito**<br>**Relativo**<br>**(95% CI)**<br>|**Absoluto**<br>**(95% CI)**<br>|**Certeza**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1|ensaios clínicos<br>randomizados|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|1,63 (0,0 a 3,97)<br>favorecendo o tr|vs 2,98 (1,2<br>atamento co|a 5,87) crise<br>m crizanlizu|s (p = 0,01),<br>mabe|⨁⨁⨁◯<br>Moderada|
|**Tempo pa**|<br>**ra a primeira crise**<br>|<br>**de dor**<br>|||||<br>|<br>|<br>|<br>|<br>|
|1|ensaios clínicos<br>randomizados|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|4,07 vs. 1,38 me<br>favorecendo o tr|ses, HR 0,5<br>atamento co|0 (IC 95% 0<br>m crizanlizu|,33 a 0,74),<br>mabe|⨁⨁⨁◯<br>Moderada|
|**Internaçã**|**o**<br>|<br>||||||||||
|1|ensaios clínicos<br>randomizados|não<br>rave|não grave|não grave|grave<sup>a</sup>|nenhum|4,00 vs 6,87 dias|por ano (p=|0,45)||⨁⨁⨁◯<br>Moderada|
|||g||||||||||
|**EA grave**|**– Geral**|||||||||||
|1|ensaios clínicos<br>randomizados|não<br>grave|não grave|não grave|muito grave<sup>b</sup>|nenhum|17/66 (25.8%)|17/62<br>(27.4%)|**RR 0.94**<br>(0.53<br>para<br>1.67)|16 menos<br>por 1.000<br>(de<br>129<br>menos<br>para 184<br>mais)|⨁⨁◯◯<br>Baixa|  
CI: Confidence interval; RR: Risk ratio. Explicações: O número amostral (133) é baixo para esta comparação e existem poucos eventos; O número amostral (133) é baixo para esta comparação e existem poucos eventos, e o intervalo de confiança do RR atravessa 0,75 e 1,25.  
60

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Balanço entre efeitos desejáveis e indesejáveis** -->
O estudo SUSTAIN sugere que para pacientes com mais de 16 anos diagnosticados com anemia falciforme, que já tiveram uma ou mais crises de dor devido à oclusão de vasos e que estão em falha terapêutica ou apresentam intolerância à hidroxiureia, crizanlizumabe provavelmente reduz crises vaso-oclusivas comparado ao placebo.  
Com relação a eventos adversos graves em um ano, a evidência sugere que não há diferença entre crizanlizumabe e placebo. Entretanto, este efeito está associado à imprecisão muito grave, o que significa, como resultado da análise conduzida pelo grupo elaborador, que pode haver uma diminuição ou aumento desses eventos em função do tratamento com o medicamento. No estudo SUSTAIN relatou-se aumento da frequência de pirexia e influenza graves, entretanto não se apresentou teste estatístico para possibilitar a avaliação da diferença de efeito entre os braços com tratamento ativo e placebo. Outra questão relevante é que foram excluídos deste estudo participantes com comorbidades e grávidas e não se pode estender quaisquer recomendações para estas populações.  
Em relação à eficácia do medicamento na dose de 5 mg/kg em comparação ao placebo é possível que o efeito preventivo seja favorável propiciando a redução de crises de dor e aumento do tempo até a primeira crise. É possível que esses resultados se mantenham consistentes independentemente da utilização concomitante de hidroxiureia; da frequência de crises recorrentes de dor ou do genótipo da doença. Além disso, a população com falha à hidroxiureia (i.e., com crises vaso-oclusivas prévias) foi avaliada no estudo em análise de subgrupo.  
Em relação a outras complicações da doença tais como sequestros esplênico e hepático e priapismo, o número de eventos foi muito baixo durante o período de acompanhamento do estudo impossibilitando qualquer conclusão sobre o efeito do medicamento nessas complicações nesse tempo de acompanhamento. Nesse tempo de acompanhamento não se observou efeito relativo estatisticamente significativo dos tratamentos com crizanlizumabe na frequência de síndrome torácica aguda em relação ao placebo.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **8.        ANÁLISE DE CUSTO-EFETIVIDADE** -->
Realizou-se uma avaliação econômica (AE) para estimar a relação de custo-efetividade incremental pela comparação entre tratamentos com crizanlizumabe, e cuidado-padrão para prevenção de crises vasoclusiva recorrentes em pacientes com doença falciforme e ao menos 16 anos de idade. Os principais aspectos da análise estão sumarizados no **Quadro E** .  
**Quadro E.** Características do modelo de análise de custo-efetividade.  
|**População-alvo**|Pacientes com doença falciforme e ao menos 16 anos de idade|
|---|---|
|**Perspectiva de análise**|Sistema Único de Saúde (SUS)|
|**Intervenção**|Crizanlizumabe para prevenção de crises vasoclusiva|
|**Comparador**|Cuidado-padrão - O comparador desta análise é o procedimento padrão de cuidado de|
||pacientes com doença falciforme. Neste modelo é composto pelo uso de hidroxiureia e pelas<br>transfusões sanguíneas realizadas por parte dos pacientes com doença falciforme<sup>1</sup>.|
|**Horizonte temporal**|35 anos (ciclos anuais)|
|**Medidas de efetividade**|Anos de vida ajustados pela qualidade (QALY)<br>Anos de vida (AV)|
|**Estimativa de custos**|Custos médicos diretos|  
> 1 O transplante de células-tronco hematopoiéticas (TCTH) não foi considerado no procedimento padrão, uma vez que é indicado somente para pacientes com complicações graves não infecciosas relacionadas à vaso-oclusão e possuem irmãos compatíveis  
61  
|**Moeda**|Real (R$)|
|---|---|
|**Taxa de desconto**|5% para custos e desfechos|
|**Modelo escolhido**|Modelo de Markov|
|**Análise de sensibilidade**|Análise determinística univariada e análise probabilística multivariada (_Probabilistic_<br>_Sensitivity Analysis_– PSA).|  
**Fonte:** elaboração própria

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **População de estudo** -->
A população considerada como base para cálculo dos custos e desfechos desta avaliação econômica foi constituída por pacientes com doença falciforme (SS e Sbeta0) e ao menos 16 anos de idade. A média de idade é de 29 anos, referente aos pacientes do estudo clínico SUSTAIN (22,23), identificado na análise da evidência e utilizado para povoar esta análise econômica.  
Na ausência de informações nacionais publicadas, as características demográficas sobre os pacientes utilizados nas ACE e ACU foram extraídos da avaliação tecnológica _“Crizanlizumab for preventing sickle cell crises in sickle cell disease”,_ publicado em 2021 pelo National Institute for Health and Care Excellence (NICE) (24) e estão descritas no **Quadro F** . Na análise de sensibilidade determinística, esses parâmetros foram variados em mais ou menos 20% nas análises. Para a análise probabilística, a distribuição Beta foi atribuída ao parâmetro de proporção entre os sexos, enquanto para os pesos corporais foi a distribuição Normal.  
**Quadro F.** Parâmetros demográficos dos pacientes com doença falciforme utilizados nas análises.  
|**Características do paciente**|**Valor utilizado**|**Limite inferior**|**Limite Superior**|**Distribuição**|
|---|---|---|---|---|
|Proporção de mulheres|63,0%|50,4%|75,6%|Beta|
|Peso corporal para mulheres (média)|55,0 kg|44,0 kg|66,0 kg|Normal|
|Peso corporal para homens (média)|65,0 kg|52,0 kg|78,0|Normal|  
**Fonte:** NICE, 2022 (24).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Perspectiva** -->
A perspectiva adotada foi a do SUS.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Intervenção** -->
A intervenção é o crizanlizumabe na dose 5 mg/Kg, que tem como objetivo reduzir a frequência dos episódios dolorosos (crises vaso-oclusivas) que ocorrem em pacientes de 16 anos ou mais com doença falciforme.  
O tratamento adotado é de 5 mg/kg administrado durante um período de 30 minutos por infusão intravenosa na semana 0, na semana 2 e em seguida, a cada 4 semanas, como recomendado em bula (25). No modelo, a intervenção é adicional ao procedimento padrão de cuidado da doença falciforme, considerando a população com e sem tratamento com hidroxiureia.  
Para esta análise, incluíram-se as evidências extraídas do estudo SUSTAIN (22,23) e da avaliação tecnológica “Crizanlizumab for preventing sickle cell crises in sickle cell disease”, publicado em 2021 pelo NICE (24).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Comparador** -->
O comparador desta análise é o procedimento padrão de cuidado de pacientes com doença falciforme. Neste modelo é composto pelo uso de hidroxiureia e pelas transfusões sanguíneas realizadas por parte dos pacientes com doença falciforme.  
62  
O transplante de células-tronco hematopoéticas (TCTH) não foi considerado no procedimento padrão, uma vez que é indicado somente para pacientes com complicações graves não infecciosas relacionadas à vaso-oclusão e possuem irmãos compatíveis (26). Outras diretrizes também somente recomendam o TCTH aos que não responderam aos tratamentos disponíveis e que não têm outras opções terapêuticas (24). Segundo o fabricante do crizanlizumabe, não é esperado que este seja um substituto do TCTH como opção terapêutica ou mesmo altere o número de pacientes elegíveis a esse procedimento (24).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Horizonte temporal, ciclo e taxa de desconto** -->
Ciclos anuais e um horizonte temporal de 14 anos para os homens e 18 anos para as mulheres foram considerados. Dado que a coorte inicia com pacientes aos 16 anos de idade, esse horizonte temporal é equivalente a vida inteira (lifetime), visto que compreende a média de idade ao morrer da população brasileira com doença falciforme, pois de acordo com os dados de Caçado et al. (27), era de 30 e 34 anos para homens e mulheres, respectivamente.  
Uma taxa de desconto de 5% foi aplicada para custos e desfechos, conforme recomendado pelas Diretrizes Metodológicas de AE do MS (28).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Desfechos em saúde** -->
Os desfechos primários utilizados para essa análise foram a efetividade em termos de anos de vida ajustados pela qualidade (QALY) e anos de vida (AV). Como análise exploratória, o número de crises vaso-oclusivas também será apresentado como efetividade.  
Considerando a falta de dados brasileiros de utilidade para doença falciforme por taxa de crises vasoclusiva, foram utilizados os valores do estudo de LEGACY (29). Para as análises de sensibilidade, os limites inferior e superior considerados foram calculados a partir do desvio-padrão descrito na avaliação do NICE (24) e a distribuição de probabilidade Beta foi utilizada. O decréscimo de utilidade por crise-vaso oclusiva ocorrida utilizado foi extraído da avaliação do NICE (24) e foi arbitrariamente variado em mais ou menos 20% nas análises de sensibilidade. Os valores de utilidade e decréscimo utilizados estão especificados no **Quadro G** .  
**Quadro G.** Valores de utilidade para pacientes com doença falciforme segundo taxa de crises vasoclusiva.  
|**Taxa**<br>**de**|**crises**||||||
|---|---|---|---|---|---|---|
|**vasoclusiva**<br>**(episódios/**||**Valor utilizado**|**Desvio**<br>**padrão ²**|**Limite inferior**|**Limite Superior**|**Distribuição**|
|**paciente-ano)**|||||||
|0 a <1 ¹||0,6910|0,0248|0,6414|0,7406|Beta|
|1 a <3 ¹||0,6800|0,0232|0,6336|0,7264|Beta|
|≥3 ¹||0,6213|0,0217|0,5779|0,6647|Beta|
|Óbito||0|-|-|-|-|
|Decréscimo<br>por|crise|0,007|-|0,0056|0,0084|Log-Normal|
|vasoclusiva ²|||||||  
**Fonte:** ¹ LEGACY (29); ² NICE, 2022 (24).  
As médias anuais de episódios ocorridos por taxa de crises vasoclusiva foram extraídas do relatório do NICE (24), oriundos do estudo SUSTAIN (22,23), e estão descritas na **Tabela H** por tratamento.  
**Tabela H.** Média anual de episódios por taxa de crise vasoclusiva.  
||**Taxa de crises vasoclusiva (episódios/paciente-ano)**|
|---|---|
|**Tratamento**||
||**0 a <1**<br>**1 a <3**<br>**≥3**|  
63  
|Crizanlizumabe|0,09|1,56|5,39|
|---|---|---|---|
|Procedimento padrão|0,19|1,91|8,33|  
**Fonte:** NICE (24).  
A proporção de ocorrência anual de complicações agudas e crônicas foram extraídas do estudo nacional de Silva-Pinto et al., 2022 (30). Para a distribuição das complicações entre os estados de saúde (divididas por taxa de crises vasoclusiva), foram utilizadas as razões de risco ( _hazard ratio_ ) entre o estado grave (≥3 crises vasoclusiva por paciente-ano) e o estado leve (0 a <1 crises vasoclusiva por paciente-ano) para cada complicação do estudo de Bailey et al., 2019 (31) ( **Tabela I** ).  
**Tabela I.** Parâmetros para as complicações decorrentes de doença falciforme.  
||Proporção a|nual ¹||HR de grave|²||
|---|---|---|---|---|---|---|
|Complicação|**Valor**<br>**utilizado**|**Limite**<br>**inferior**|**Limite**<br>**superior**|**Valor**<br>**utilizado**|**Limite**<br>**inferior**|**Limite**<br>**superior**|
|**_Complicações agudas_**|||||||
|Infecções|32,00%|26,00%|38,00%|2,76|1,67|4,57|
|Sequestro esplênico|2,00%|1,60%|2,40%|3,55|1,86|6,77|
|Sequestro hepático|0,10%|0,08%|0,12%|3,11|0,73|13,25|
|Colelitíase|35,40%|28,32%|42,48%|2,70|1,83|3,99|
|Trombose venosa profunda|10,00%|5,00%|15,00%|1,00|0,80|1,20|
|Síndrome torácica aguda|30,00%|24,00%|36,00%|5,33|4,29|6,62|
|Priapismo (somente homens)|26,00%|18,00%|34,00%|7,58|4,07|14,10|
|Acidente vascular cerebral|14,50%|8,00%|21,00%|2,63|1,23|5,64|
|Osteonecrose|13,50%|7,00%|20,00%|2,48|1,62|3,80|
|**_Complicações crônicas_**|||||||
|Colicistite crônica calculosa|62,00%|49,60%|74,40%|2,70|1,83|3,99|
|Complicações cardíacas|15,80%|12,64%|18,96%|1,29|0,58|2,89|
|Doença<br>renal<br>crônica<br>(insuficiência)|4,00%|3,00%|5,00%|0,14|0,05|0,31|
|Doença<br>renal<br>crônica<br>(sem<br>insuficiência)|38,90%|30,00%|47,00%|0,14|0,05|0,31|
|doença hepática crônica|17,00%|13,60%|20,40%|3,11|0,73|13,25|
|Úlceras de perna|17,80%|14,24%|21,36%|2,10|0,94|4,68|
|Osteoporose|24,50%|17,00%|32,00%|1,00|0,80|1,20|
|Hipertensão pulmonar|10,00%|8,00%|12,00%|2,60|1,42|4,75|
|Priapismo<br>recorrente<br>(somente<br>homens)|15,00%|12,00%|18,00%|7,58|4,07|14,10|
|Retinopatia|37,20%|29,00%|46,00%|0,87|0,32|2,34|  
**Fonte:** ¹ Silva-Pinto AC et al., 2022 (30). ² Bailey M et al., 2019 (31); HR de grave: razão de risco (hazard ratio) da complicação no estado grave (≥3 crises vasoclusiva por paciente-ano) em comparação ao estado leve (0 a <1 crises vasoclusiva por paciente-ano).  
As probabilidades de óbito foram extraídas a partir das curvas de sobrevida apresentadas por Lobo CLC et al., 2018 (32) ( **Tabela J** ).  
64  
**Tabela J.** Probabilidade de óbito por idade e sexo  
|**Idade (anos)**|**Mulheres**|**Homens**|**Idade (anos)**|**Mulheres**|**Homens**|
|---|---|---|---|---|---|
|16|0,0161|0,0161|36|0,1355|0,1935|
|17|0,0210|0,0194|37|0,1484|0,2081|
|18|0,0274|0,0194|38|0,1645|0,2210|
|19|0,0306|0,0226|39|0,1806|0,2306|
|20|0,0339|0,0306|40|0,1919|0,2355|
|21|0,0387|0,0403|41|0,1984|0,2677|
|22|0,0468|0,0500|42|0,2065|0,2968|
|23|0,0516|0,0565|43|0,2403|0,3016|
|24|0,0597|0,0661|44|0,2452|0,3081|
|25|0,0613|0,0823|45|0,2774|0,3290|
|26|0,0613|0,1016|46|0,2839|0,3532|
|27|0,0613|0,1145|47|0,3048|0,3839|
|28|0,0694|0,1242|48|0,3323|0,3935|
|29|0,0758|0,1419|49|0,3387|0,4129|
|30|0,0871|0,1532|50|0,3387|0,4129|
|31|0,0919|0,1597|51|0,3565|0,4371|
|32|0,1016|0,1677|52|0,3871|0,4371|
|33|0,1065|0,1710|53|0,4194|0,4613|
|34|0,1226|0,1774|54|0,4790|0,5161|
|35|0,1339|0,1903|55|0,4952|0,5452|  
**Fonte:** Lobo CLC et al., 2018 (32).  
As taxas de mortalidade por taxa de crises vasoclusiva foram extraídas do estudo publicado por Platt OS et al., 1991 (33) e são apresentadas na **Tabela K** para as categorias de idade 10 a 19 anos e maior igual a 20 anos. Nas análises de sensibilidade, esses valores foram variados em mais ou menos 20% e a distribuição Log-Normal foi utilizada.  
**Tabela K.** Taxa de mortalidade por taxa de crises vasoclusiva entre pacientes com doença falciforme.  
|**Idade**|**Taxa de crises vasoclusiva**|**Taxa de mortalida**|**de (mortes/100 pacien**|**te-ano)**|
|---|---|---|---|---|
|**(anos)**|(episódios/paciente-ano)|Valor utilizado|Limite inferior|Limite superior|
|10 - 19|0 a <1|0,71|0,57|0,85|
||1 a <3|0,78|0,62|0,94|
||≥3|0,37|0,30|0,44|
|≥20|0 a <1|1,81|1,45|2,17|
||1 a <3|1,77|1,42|2,12|
||≥3|3,74|2,99|4,49|  
**Fonte:** Platt OS et al., 1991 (33). 0 a <1, 1 a <3 e ≥3 crises vasoclusiva por paciente-ano com doença falciforme referem-se aos estados leve, moderado e grave respectivamente.  
No estudo SUSTAIN (22,23), a incidência de eventos adversos significantes foi semelhante entre os grupos de tratamento com crizanlizumabe de dose de 5mg/kg e com placebo. Desta forma, nesta análise não foram incluídos dados de segurança, uma vez que não é esperado ter impacto significativo nos resultados da ACE e ACU.  
65

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Mensuração e valoração de custos** -->
Apenas custos médicos diretos foram incluídos no modelo. A composição do custo considerou custos hospitalares e ambulatoriais, relacionados a procedimentos, exames e monitoramento dos pacientes com doença falciforme, seguindo as recomendações do PCDT de doença falciforme (26).  
Os custos anuais do procedimento padrão e por tipo de complicação foram extraídos do estudo brasileiro publicado por Silva-Pinto A et al., 2022 (30). Essas informações estão dispostas na **Tabela L** e neles já estão inclusos os valores das visitas médicas e uso de hidroxiureia, ácido fólico, transfusão sanguínea e quelação de ferro.  
**Tabela L.** Custos por complicação por evento e por ano.  
|**Procedimentos**|**Custo, R$**|
|---|---|
|Crise vasoclusiva|505,04|
|Infecções|3.848,75|
|Sequestro esplênico|2.067,20|
|Sequestro hepático|1.218,71|
|Colelitíase|636,57|
|Trombose venosa profunda|925,74|
|Síndrome torácica aguda|2.051,16|
|Priapismo (somente homens)|448,24|
|Acidente vascular cerebral|1.681,67|
|Osteonecrose|427,67|
|Colicistite crônica calculosa|570,24|
|Complicações cardíacas|984,24|
|Doença renal crônica (insuficiência)|32.536,31|
|Doença renal crônica (sem insuficiência)|439,88|
|Doença hepática crônica|401,56|
|Úlceras de perna|2.368,22|
|Osteoporose|610,81|
|Hipertensão pulmonar|1.035,96|
|Priapismo recorrente (somente homens)|880,61|
|Retinopatia|332,41|  
**Fonte:** Silva-Pinto AC et al., 2022 (30).  
O preço do crizanlizumabe utilizado foi extraído da planilha da Câmara de Regulação do Mercado de Medicamentos (CMED) (34), uma vez que não foram encontrados registros de compras no Banco de Preços em Saúde (BPS). Usou-se o preço máximo de venda ao governo (PMVG) com alíquota de Imposto sobre Circulação de Mercadorias e Serviços (ICMS) de 18%. Nas análises de sensibilidade, o valor variou mais ou menos em 20% e utilizou-se a distribuição Gama. O preço de um frascoampola de 10 mL crizanlizumabe da marca Adakveo® contendo 10 mg/mL de solução para diluição para infusão é apresentado no **Quadro H.**  
**Quadro H.** Preço do crizanlizumabe 10 mg/mL solução para diluição para infusão – embalagem contendo 1 frasco-ampola de 10 mL)  
66  
|**Produto**|**Valor utilizado**|**Limite inferior**|**Limite superior**|**Distribuição**|
|---|---|---|---|---|
|Crizanlizumabe|R$ 6.574,77|R$ 5259,82|R$ 7.889,72|Gama|  
**Fonte:** CMED, 2023 (34).  
**Moeda, data de preços e conversões**  
Todos os preços e custos foram obtidos e apresentados em reais (BRL, R$), considerando consultas realizadas em maio de 2023.  
Para os valores de custos dos itens utilizados do artigo de Silva-Pinto AC et al., 2022 (30) usou-se a conversão US$ 1 = R$ 3,8742 (35), como descrita no artigo.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Racional e descrição do modelo** -->
O modelo de Markov ( **Figura C** ) utilizado para as ACE e ACU baseou-se nos modelos publicados pelo NICE (24) e Salcedo J et al., 2021 (36). Este modelo simula uma coorte de pacientes com doença falciforme que transitam entre os estados de saúde:  
DF Leve: pacientes com doença falciforme com taxa de crises vasoclusiva entre 0 e <1 episódios por paciente-ano;  
DF Moderado: pacientes com doença falciforme com taxa de crises vasoclusiva entre 1 e <3 episódios por paciente-  
ano;  
DF Grave: pacientes com doença falciforme com taxa de crises vasoclusiva maior igual a 3 episódios por paciente-ano; Óbito.  
**Figura C.** Modelo conceitual de Markov  
<!-- Start of picture text -->
eas<br>aes<br>Loe|<br><!-- End of picture text -->  
**Fonte** : elaboração própria. **Legenda** : DF= doença falciforme; estados DF Leve, DF Moderado e DF Grave são referentes as taxas de crises vasoclusiva, respectivamente, 0 a <1, 1 a <3 e ≥3 episódios/paciente-ano em paciente com doença falciforme.  
As probabilidades de transição entre os estados de saúde para mulheres e homens foram extraídas do estudo de Salcedo J et al., 2021 (36) e são apresentados no Apêndice 5. Esses valores foram utilizados para o braço de procedimento padrão.  
Alguns parâmetros clínicos utilizados no modelo foram retirados do estudo SUSTAIN (22,23) e são apresentados no **Quadro I** . Na ausência de informação sobre variação desses parâmetros, utilizou-se a variação de mais e menos 20% nas análises de sensibilidade.  
Para definir as probabilidades de transição do braço com o crizanlizumabe, utilizou-se a razão de risco (HR, hazard ratio) entre o crizanlizumabe e o procedimento padrão do tempo para início para a primeira crise vasoclusiva em pacientes com doença falciforme do estudo SUSTAIN (22,23). As probabilidades de transição de um estado melhor de saúde para um estado pior de saúde foram multiplicadas por esse HR. A distribuição Log-Normal foi utilizada para a análise de sensibilidade probabilística. ( **Quadro I** )  
67  
Os pacientes que recebem crizanlizumabe podem descontinuar o uso a qualquer momento. No modelo foi considerado uma taxa de descontinuação de 32,8% no primeiro ano e 4,5% nos anos seguintes, conforme descrito no estudo SUSTAIN (22,23). A distribuição Beta foi utilizada para a análise de sensibilidade probabilística. ( **Quadro I** )  
As proporções de pacientes iniciais em cada estado de saúde do modelo (distribuição inicial) para ambos os tratamentos foram extraídas da avaliação realizada pelo NICE e são oriundas do estudo SUSTAIN (22,23)( **Quadro I** ).  
**Quadro I.** Parâmetros clínicos utilizados no modelo.  
|**Parâmetro**|**Valor**|**Limite**|**Limite**|**Distribuição**|
|---|---|---|---|---|
||**utilizado**|**Inferior**|**superior**||
|Taxa anual de descontinuação de crizanlizumabe no|32,8%|26,2%|39,4%|Beta|
|1º ano|||||
|Taxa anual de descontinuação de crizanlizumabe|4,5%|3,6%|5,4%|Beta|
|nos anos subsequentes|||||
|Razão de risco (HR,_hazard ratio_) entre|0,5|0,3300|0,7400|Log-Normal|
|crizanlizumabe e procedimento padrão|||||
|Distribuição inicial para estado leve|20,0%|-|-|-|
|Distribuição inicial para estado moderado|37,9%|-|-|-|
|Distribuição inicial para estado grave|42,1%|-|-|-|  
**Fonte** : SUSTAIN (22,23). **Legenda** : estados leve, moderado e grave são referentes as taxas de crises vasoclusiva, respectivamente, 0 a <1, 1 a <3 e ≥3  
episódios/paciente-ano em paciente com doença falciforme.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Pressupostos do modelo** -->
O tratamento com o crizanlizumabe (ampola de 10mL com 100mg) adotado é de 5 mg/kg administrada na semana 0, na semana 2 e em seguida, a cada 4 semanas, como recomendado em bula (25). Desta forma, no primeiro ano, para cada indivíduo, serão administradas 14 doses e nos anos seguintes 13 doses. Para o caso-base adotou-se valores de custo considerando o desperdício, ou seja, o cálculo da dose a ser administrada em cada indivíduo foi arredondado para cima. Uma análise adicional exploratória considerou também valores de custo sem o desperdício, isto é, considerando aproveitamento de dose entre pacientes em centros especializados, uma vez que segundo a bula do medicamento, a solução diluída pode ser armazenada em temperatura ambiente de até 25 °C por 4,5 horas ou em temperatura de 2 °C a 8 °C por 24 horas (25). A **Tabela M** apresenta, por sexo, os valores de custo considerados nas análises.  
**Tabela M.** Custo do crizanlizumabe por sexo e ano.  
||**Mulheres**||**Homens**||
|---|---|---|---|---|
||Sem desperdício|Com desperdício|Sem desperdício|Com desperdício|
|Dose necessária<sup>a</sup>|27,50ml||32,50ml||
|Nº de ampolas|2,75|3|3,25|4|
|Total de ampolas ano 1<sup>b</sup>|38,50|42|45,50|56|
|Custo ano 1<sup>a</sup>|R$ 253.152,90|R$ 276.166,80|R$ 299.180,70|R$ 368.222,40|
|Total de ampolas ano 2+<sup>c</sup>|35,75|39|42,25|52|
|Custo ano 2+<sup>b</sup>|R$ 235.070,55|R$ 256.440,60|R$ 277.810,65|R4 341.920,80|  
**Fonte** : elaboração própria. **Legenda** : a peso médio considerado de 55kg para mulheres e de 65kg para homens, informação extraída de NICE (24). b administração na semana 0, na semana 2 e em seguida, a cada 4 semanas, total de 14 administrações no 1º ano. c a cada 4 semanas, total de 13 administrações do 2º ano em diante.  
68  
Os valores de custo finais utilizados no modelo para os resultados basais de ACE e ACU são apresentados na **Tabela N** . Para o custo do procedimento padrão, na ausência de informação, foi adotada uma variação de mais ou menos 20% nas análises de sensibilidade determinística. Para os limites inferiores dos custos das complicações foi adotado o melhor cenário, ou seja, limites inferiores das prevalências e dos HRs. Enquanto para os limites superiores dos custos das complicações foi adotado o pior cenário, ou seja, limites superiores das prevalências e dos HRs. Nas análises de sensibilidade probabilísticas, a distribuição gama foi considerada.  
**Tabela N.** Valores de custo utilizados no modelo econômico.  
|**Procedimentos**|**Custo, R$**|**Limite**|**Limite**|
|---|---|---|---|
|||**Inferior, R$**|**Superior, R$**|
|Procedimento Padrão<sup>a</sup>|27.597,36|22.077,89|33.116,83|
|Complicações para mulheres no estado leve|1.828,40|1.797,39|1.674,51|
|Complicações para mulheres no estado moderado e grave|1.888,79|1.248,63|2.620,63|
|Complicações para homens no estado leve|1.829,36|1.800,12|1.674,72|
|Complicações para homens no estado moderado e grave|1.896,08|1.259,76|2.623,58|
|Tratamento com crizanlizumabe para mulheres no 1º ano|276.166,80|-|-|
|Tratamento com crizanlizumabe para mulheres do 2º ano em diante|256.440,60|-|-|
|Tratamento com crizanlizumabe para homens no 1º ano|368.222,40|-|-|
|Tratamento com crizanlizumabe para homens do 2º ano em diante|341.920,80|-|-|
|Tratamento de crise vasoclusiva no estado leve no braço padrão|95,96|-|-|
|Tratamento de crise vasoclusiva no estado moderado no braço padrão|964,63|-|-|
|Tratamento de crise vasoclusiva no estado grave no braço padrão|4.206,99|-|-|
|Tratamento de crise vasoclusiva no estado leve no braço crizanlizumabe|45,45|-|-|
|Tratamento de crise vasoclusiva no estado moderado no braço<br>crizanlizumabe|787,86|-|-|
|Tratamento de crise vasoclusiva no estado grave no braço<br>crizanlizumabe|2.722,17|-|-|  
**Fonte:** elaboração própria; a Silva-Pinto A et al., 2022 (30). **Legenda** : estados leve, moderado e grave são referentes às taxas de crises vasoclusiva, respectivamente, 0 a <1, 1 a <3 e ≥3 episódios/paciente-ano em paciente com doença falciforme.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Premissas** -->
Como é inerente aos modelos econômicos, foi necessário assumir algumas premissas para a condução da avaliação econômica. Esses pressupostos podem representar limitações à validade externa da análise.  
A hidroxiureia é o tratamento padrão atual recomendado para a prevenção das crises vasoclusiva em adultos e crianças, como descrito no PCDT de doença falciforme (26). Desta forma, espera-se que na prática clínica, para todos os pacientes com doença falciforme com crises vasoclusiva recorrente e considerados para o tratamento com crizanlizumabe tenham previamente realizado o tratamento com hidroxiureia. Assim como no estudo SUSTAIN (22,23), uma parcela da população receberá a hidroxiureia concomitantemente.  
O modelo considerou como as principais complicações as mesmas relatadas pelo estudo nacional de Silva-Pinto A et al., 2022 (30). Os HRs calculados no estudo de Bailey M et al., 2019 (31) foram utilizados para a distribuição das complicações entre os estados de saúde (divididas por taxa de crises vasoclusiva), menos para as complicações trombose venosa profunda e  
69  
osteoporose, pois não foram relatadas. Desta forma, para estas complicações, foi considerado que não há diferença entre os estados, ou seja, HR igual à unidade.  
O estudo de Bailey M et al., 2019 (31) somente publicou o HR entre o estado grave (≥3 crises vasoclusiva por pacienteano) e o estado leve (0 a <1 crises vasoclusiva por paciente-ano) para cada complicação, apesar de no texto relatar também ter sido realizado entre o estado moderado (1 a <3 crises vasoclusiva por paciente-ano) e o estado leve. Na ausência destas informações, no modelo, foi considerado os HRs de grave para o moderado.  
Na ausência de bancos de dados e estudo nacionais que fornecessem informações suficientes para os cálculos, optou-se por utilizar, para o procedimento padrão, as probabilidades de transição entre os estados de saúde para mulheres e homens do estudo de Salcedo J et al., 2021 (36). Este utilizou dados para a população americana e os estados de saúde leve, moderado e grave referem-se a, respectivamente, zero, >0 a 2 e ≥2crises episódios/paciente-ano em paciente com doença falciforme.  
Para definir as probabilidades de transição do braço com o crizanlizumabe, utilizou-se a razão de risco (HR, hazard ratio) entre o crizanlizumabe e o procedimento padrão do tempo para início para a primeira crise vasoclusiva em pacientes com doença falciforme do estudo SUSTAIN (22,23). As probabilidades de transição de um estado melhor de saúde para um estado pior de saúde foram multiplicadas por esse HR.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Análises de sensibilidade** -->
As análises de sensibilidade determinística univariadas foram apresentadas em diagrama de tornado, sendo que a magnitude de variação de cada parâmetro foi definida com base na variação identificada nos estudos ou, quando a variação não estava disponível, uma variação de mais ou menos 20% foi assumida, Diretrizes Metodológicas de AE do Ministério da Saúde (MS).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **RESULTADOS** -->
Para o horizonte temporal de 30 anos para homens e 34 anos para mulheres, a análise indicou que o crizanlizumabe adicionado ao tratamento padrão apresenta maior benefício clínico (0,208 QALY e 0,068 AV) e um maior custo total (R$ 844.860,57) comparado ao tratamento padrão isolado, apresentando razão de custo efetividade incremental (RCEI) de R$ 4.054.678,36/QALY ganho e R$12.389.851,40/AV ganho, conforme apresentado na **Tabela O** .  
**Tabela O.** Custos, desfechos e razão de custo efetividade incremental (RCEI) por paciente para a análise de custo-efetividade/utilidade.  
||**Procedimento**|**Crizanlizumabe**|**Incremental**|**RCEI**|
|---|---|---|---|---|
||**padrão**||||
|Custo (R$)|310.960,20|1.155.820,77|844.860,57|-|
|Efetividade 1 (QALY)|6,625|6,833|0,208|4.054.678,36|
|Efetividade 2 (AV)|10,707|10,775|0,068|12.389.851,40|  
**Fonte** : elaboração própria. **Legenda** : QALY: anos de vida ajustado pela qualidade; AV: anos de vida.  
Os resultados das análises de sensibilidade probabilísticas corroboram com os resultados apresentados no caso-base, visto que estão dispostos praticamente em sua totalidade no quadrante superior direito, confirmando que o tratamento adjunto de crizanlizumabe apresenta benefício clínico para ambos os desfechos apesar de maior custo incremental.  
Embora existam limitações para as análises de sensibilidades, uma vez que as transições entre os estados de saúde não são alteradas na análise, nota-se acentuada dispersão, e consequente incerteza. Desta forma, é importante ponderar a validade desta análise de sensibilidade, visto que somente os custos e os valores de utilidade variam simultaneamente e estão influenciando os resultados.  
70  
**Figura D.** Gráfico de dispersão (desfecho: anos de vida ajustado a qualidade - QALY).  
<!-- Start of picture text -->
115000000 Andlsede Sensibildade Probabilsica.<br>75900000 IN arth gee ELE<br>g<br> 350,000,00<br>15000000<br>soec00<br>oo! oma somata oo aa0<br>Etedeincement<br>QA ane)<br><!-- End of picture text -->  
<!-- Start of picture text -->
Fonte:  elaboração própria.<br><!-- End of picture text -->  
<!-- Start of picture text -->
Figura E.  Gráfico de dispersão (desfecho: anos de vida - AV).<br><!-- End of picture text -->  
<!-- Start of picture text -->
115000000 Andlsede:  Sensibildade : Probabilsica<br>75000090 20% ERS ch or<br>g<br> 350,000,00<br>15000000<br>soec00<br>0ors co msm messes ats aes as<br>{tedden<br>AV ano)<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
As figuras a seguir apresentam as curvas de aceitabilidade geradas a partir da análise de sensibilidade probabilística, confirmando que o tratamento com o crizanlizumabe não é custo-efetivo para os limiares de custo-efetividade recomendados pela Conitec (um a três vezes os valores de referência de R$ 40 mil por QALY e de R$ 35 mil por AV ganho). A tecnologia teria uma probabilidade acima de 50% de ser custo-efetiva se a disposição a pagar fosse de aproximadamente R$ 4 milhões por QALY ganho e R$ 13 milhões por AV ganho.  
71  
**Figura F.** Curva de aceitabilidade (desfecho: anos de vida ajustados pela qualidade – QALY).  
<!-- Start of picture text -->
Curvade Aceitabilidade<br>100.0%<br>g<br>E s00%<br>3 com<br>=<br>3 soon<br>om35.000 RS300n00000 R$6.000.00090 $900000000 RS12000000.00 R$ 15.000.000,00<br>Oispsioa<br>pags RS/CALY ano)<br><!-- End of picture text -->  
**Fonte:** elaboração própria. **Figura G.** Curva de aceitabilidade (desfecho: anos de vida ganhos– AV).  
<!-- Start of picture text -->
Curvade Aceitabilidade<br>Padrdo —Crianizumate<br>100,00% -<br>g<br>E s000%<br>Fs<br>3 sooo<br>2 200%<br>&<br>00%<br>Disposigiow pgar(RS/AV ano)<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
Por meio das análises de sensibilidade univariadas determinísticas, foi possível observar que o HR entre o crizanlizumabe e o procedimento padrão utilizado para as probabilidades de transição é o parâmetro que mais impacta na RCEI para ambos os desfechos, seguida da taxa de desconto aplicada aos custos e desfechos e o custo do crizanlizumabe. A utilidade do estado de saúde ‘leve’ impacta indiretamente a RCEI quando o desfecho é o QALY, enquanto as taxas de mortalidade influenciam quando o desfecho é AV ganho. Entretanto, para nenhuma variação de parâmetro a RCEI passa a sugerir que crizanlizumabe seja custoefetivo, uma vez que os menores resultados encontrados foram de R$ 2,9 milhões por QALY ganho e R$ 7,1 milhões por AV ganho.  
72  
**Figura H.** Diagrama de tornado (desfecho: anos de vida ajustados pela qualidade - QALY).  
<!-- Start of picture text -->
Anilise de Sensibilidade Deterministica<br>‘Limite Superior = Limite inferior<br>HR entre crizanlizumabe e procedimento padra0, 210288 GATGSS<br>Utilidade para estado Leve mS<br>0ST<br>Taxa de descont0 22 TTI<br>Custo do crizanlizumabe (323868559 NANESSSIESE<br>Utilidade para estado Grave 3403960 TOTS<br>% descontinuac3o do uso do crizanlizumabe apés 1° ano wusromeser<br>| 4.712251.19<br>Peso (médio) de mulheres em kg<br>105437717 STS!<br>Decréscimo de utilidade por crise vaso-oclusiva | SERIES! 4.170.169.12<br>Proporcdo de mulheres 5 PN 4.342.741,<br>‘Taxa de mortalidade para estado Leve 3.790 OREO 5<br>Taxa de mortalidade para estado Grave<br>3.838, ABORTED,33<br>Peso (médio) de homensem kg ‘SeosONEE 4.054.327,12<br>Utlidade para estado Moderado 3882.37.<br>221,56<br>‘% descontinuaco do uso do crizanlizumabe nos anos seguintes 4.015.668, 284.092.985,97<br>Taxa de mortalidade para estado Moderado 4.039,725,87118.071.005,34<br>Custo do tratamento de crise vaso-oclusiva 4.047.615 41 | 4.061.038,82<br>CCusto do tratamento de complicagbes no estado Moderado e Grave 4.050,505,08 | 4.057.670,24<br>Custo do tratamento padrio 405252083 4.056.133,41<br>Custo do tratamento de complicagbes no estado Leve 4.053.469,94 4.054.158,04<br>2.900.000,00  3.500,000,00 4.100.000,004.700.000,00 _5.300.000,00 _5.900.000,00<br>Razo de Custo-Efetividade Incremental (RS/QALY ganho)<br><!-- End of picture text -->  
**Fonte** : elaboração própria. **Legenda** : HR= razão de risco ( _hazard ratio_ ). Estados leve, moderado e grave são referentes as taxas de crises vasoclusiva, respectivamente, 0 a <1, 1 a <3 e ≥3 episódios/paciente-ano em paciente com doença falciforme.  
**Figura I.** Diagrama de tornado (desfecho: anos de vida - AV).  
<!-- Start of picture text -->
Anélisede Sensibilidade Deterministica<br>Limite Superior = Limite inferior<br>HR entre crizanizumabe e procedimento padtio 225<br>cI<br>AST<br>Te Leon A<br>Taxa de mortalidade para estado Grave GNSS.<br>060506.05,<br>‘Taxa de mortaidade para estado Leve 948.0974) OSCE<br>Cust do crizaniaumabe /9.896437.35 AES<br>{% descontinuago do uso do crizanlizumabe apés 1° ano<br>109:97<br>Proporsio de mulheres 10.9 ARRAS, 36<br>Peso (médio) de mulheres em kg 2388775,<br>Peso (médio} de homens em kg 11.019 12.388.778,12<br>‘% descontinuago do uso do crizanlizumabe nos anos sequintes 12.270.648.5412.506.907,70<br>Taxa de mortaidade para estado Moderado 12.292.482,02112.50331683<br>CCusto do tratamento de crise vaso-oclusiva 12.368,209,22| 1240028702<br>custo do tratamento de complicagbes no estado Moderado e Grave 12377099,4 1239899368<br>custo do tratamento padrio 12388.25865 12394297,59<br>custo<br>do tratamento de complicagbesno estado Leve 12.386.158,85 12.388.261.46<br>7,000.000,00  11.000.000.00Razio de Custo-Efetividade15.000,00.00 Incremental19.000.000.00 (RS/AV ganho) _23.000.000,00<br><!-- End of picture text -->  
**Fonte** : elaboração própria. **Legenda** : HR= razão de risco ( _hazard ratio_ ). Estados leve, moderado e grave são referentes as taxas de crises vasoclusiva, respectivamente, 0 a <1, 1 a <3 e ≥3 episódios/paciente-ano em paciente com doença falciforme.  
Adicionalmente, como análise exploratória, também foram calculados quando não há desperdício do crizanlizumabe. Neste caso, RCEI seria de R$ 3.523.941,60/QALY ganho e R$10.768.082,93/AV ganho, 13,0% a menos quando comparado quando há desperdício da dose.  
Como desfecho exploratório, a **Tabela P** apresenta a RCEI para o número de crises vaso-oclusivas, considerando horizonte temporal de 30 anos para homens e 34 anos para mulheres e desperdício da dose. Esta análise mostrou que o tratamento  
73  
adjunto ao crizanlizumabe evita 13,85 crises ao ano, gerando uma RCEI de R$61.015,82 por crise vasoclusiva evitada. E quando não há desperdício, a RCEI seria R$ 53.091,27 por crise evitada.  
**Tabela P.** Custos, número de crises vasoclusiva e razão de custo efetividade incremental (RCEI) por paciente.  
||**Procedimento**|**Crizanlizumabe**|**Incremental**|**RCEI**|
|---|---|---|---|---|
||**padrão**||||
|Custo (R$)|310.960,20|1.155.820,77|844.860,57|-|
|Nº de crises vasoclusiva|25,56|11,72|13,85|61.015,82|  
**Fonte** : elaboração própria.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **População** -->
Foram elegíveis pacientes com idade igual ou superior a 16 anos e doença falciforme (SS e Sbeta0) em falha terapêutica ou intolerância à hidroxiureia.  Para a estimativa desta população, foi considerada demanda aferida combinada à demanda epidemiológica.  
Os dados administrativos de dispensação foram extraídos da Sala Aberta de Situação de Inteligência em Saúde (Sabeis), referentes ao período de janeiro de 2017 a dezembro de 2022. Para essa análise foi utilizado o dado atualizado em maio de 2023.  
A estimativa da população elegível foi realizada em duas etapas, na primeira foram extraídos, por ano, os quantitativos de indivíduos com doença falciforme em uso de hidroxiureia 500 mg no SUS e na segunda determinou-se a porcentagem de indivíduos que apresentariam falha ou seriam intolerantes ao tratamento com esse medicamento.  
Na primeira etapa, além de estimar o quantitativo em uso de hidroxiureia foi necessário calcular a incidência (novos entrantes) e prevalência da doença porque o intervalo posológico entre a primeira e a segunda doses do crizanlizumabe é de 2 semanas , mas de 4 semanas nas demais doses, e dessa forma o número de ampolas de crizanlizumabe difere entre o primeiro e demais anos de tratamento.  
Considerou-se a população elegível na base de dados do Sabeis aquela em utilização de hidroxiureia 500 mg e com diagnóstico de doença falciforme (identificação pelo CID-10 D57.0; D57.1; D57.2).  
Uma vez identificado o quantitativo total por ano de indivíduos com doença falciforme em uso de hidroxiureia 500 mg foram identificados os usuários novos (incidência) e os que já estavm em uso do medicamento (prevalência) para cada ano.  
Foram excluídos todos os registros em que não havia quantidade aprovada do procedimento ou registro do Cartão Nacional de Saúde (CNS).  
**Tabela Q.** Quantidade de usuários novos, com idade a partir de 16 anos, em uso de cápsula de hidroxiureia 500 mg para o tratamento da doença falciforme por ano e faixa etária, entre 2017 e 2022, no Sistema Único de Saúde.  
|**FAIXA ETÁRIA**|**2017**|**2018**|**2019**|**2020**|**2021**|**2022**|
|---|---|---|---|---|---|---|
|16 a 20 anos|425|338|237|242|219|188|
|21 a 25 anos|342|275|188|199|206|159|
|26 a 30 anos|286|233|183|158|157|158|
|31 a 35 anos|257|198|152|129|137|145|
|36 a 40 anos|197|176|117|129|131|111|
|41 a 45 anos|143|120|104|75|93|95|
|46 a 50 anos|97|81|74|73|61|63|  
74  
|51 a 55 anos|77|81|54|51|68|56|
|---|---|---|---|---|---|---|
|56 a 60 anos|47|57|41|41|44|56|
|> 60 anos|131|104|102|67|136|111|
|Total de usuários|2.002|1.663|1.252|1.164|1.252|1.142|  
**Fonte** : Elaboração própria, considerando dados da Sala Aberta de Situação de Inteligência em Saúde (Sabeis).  
**Tabela R.** Quantidade de usuários, com idade a partir de 16 anos, em uso de cápsula de hidroxiureia 500 mg para o tratamento da doença falciforme por ano e faixa etária, entre 2017 e 2022, no Sistema Único de Saúde.  
|**FAIXA ETÁRIA**|**2017**|**2018**|**2019**|**2020**|**2021**|**2022**|
|---|---|---|---|---|---|---|
|16 a 20 anos|1.774|1.878|1.956|2.057|2.166|2.272|
|21 a 25 anos|1.202|1.286|1.337|1.469|1.686|1.774|
|26 a 30 anos|1.075|1.158|1.144|1.171|1.255|1.361|
|31 a 35 anos|874|965|960|1.046|1.155|1.222|
|36 a 40 anos|685|781|817|892|986|1.039|
|41 a 45 anos|486|560|578|608|685|792|
|46 a 50 anos|408|424|459|458|493|534|
|51 a 55 anos|288|355|370|376|450|477|
|56 a 60 anos|179|218|232|243|278|332|
|> 60 anos|437|465|485|454|570|616|
|Total de usuários|7.408|8.090|8.338|8.774|9.724|10.419|  
**Fonte** : Elaboração própria, considerando dados da Sala Aberta de Situação de Inteligência em Saúde (Sabeis).  
Com base nos dados retrospectivos e no crescimento populacional calculou-se o número de pacientes elegíveis para os próximos cinco anos com DF acima de 16 anos, conforme apresentado na Tabela S. Além disso, considerou-se que 76% (37) destes pacientes apresentam o genótipo SS e Sbeta0 e que 14% são não respondedores (38).  
75  
**Figura** **_J_ .** Número de pacientes de acordo com a demanda aferida entre 2017 e 2022 e estimativa do número de pacientes elegíveis entre 2024 e 2028, no SUS.  
<!-- Start of picture text -->
16.000<br>14.000 qiggg 12459 12-866 13.313TS<br>12.000 9.724 10.419 11.299Ad eee eeeaneeseene<br>10.000 8.090 8.338 8774 agen ; v= 496,88x-994303<br>GB §:408 ee aed R? = 0,9924<br>5 86 .000  see y = 582,66x-R? = 0,96911E+06<br>8= 4.000<br>z<br>2.000<br>0<br>2017 2018 «2019-2020.» 2021-2022, 2023) 2024 «2025-2026 = 2027-2028<br>© Populacio aferida © — Populacio esfiRda ssssrs Linear (Populacdo aferida)<br>sss Linear (Populacdo aferida) «+--+.» Linear (Populagdo estimada) --------- Linear (Populacao estimada)<br><!-- End of picture text -->  
**Fonte** : elaboração própria  
**Tabela S.** Estimativa do número de pacientes elegíveis entre 2024 e 2028, no SUS.  
|**Estimativa populacional**|**Ano 1**|**Ano 2**|**Ano 3**|**Ano 4**|**Ano 5**|
|---|---|---|---|---|---|
|ANO|2024|2025|2026|2027|2028|
|Pacientes com DF (SS e SBeta0) com idade a partir|1.235|1.304|1.362|1.406|1.455|
|de 16 anos, não respondedores - prevalência||||||
|Casos novos|-|86|74|59|51|
|Pacientes a partir do segundo ano (prevalência<br>menos a incidência)|-|1.218|1.288|1.347|1.404|  
**Fonte** : elaboração própria. **Legenda** : DF: Doença falciforme.  
**Market share**  
No cenário atual, assumiu-se que todos os pacientes elegíveis utilizam cuidado-padrão (HU 500 mg e transfusão) como tratamento (  
**Tabela** ).  
**Tabela T.** _Market share_ do cenário atual  
|**Cenário Atual**|**Ano 1**|**Ano 2**|**Ano 3**|**Ano 4**|**Ano 5**|
|---|---|---|---|---|---|
|Cuidado-padrão|100%|100%|100%|100%|100%|
|Crizanlizumabe|0%|0%|0%|0%|0%|  
**Fonte:** elaboração própria.  
Para o cenário propostoalternativo 1, foi estimada uma taxa de difusão de 20% ao ano para a incorporação de crizanlizumabe, chegando em cinco anos a atingir 100% dos pacientes da população elegível, conforme apresentado na **Tabela U** .  
**Tabela U.** Market share do cenário alternativo 1.  
|**Cenário alternativo 1**|**Ano 1**|**Ano 2**|**Ano 3**|**Ano 4**|**Ano 5**|
|---|---|---|---|---|---|
|Cuidado-padrão|80%|60%|40%|20%|0%|
|Crizanlizumabe|20%|40%|60%|80%|100%|  
**Fonte:** elaboração própria.  
76  
Além disso, dois outros cenários alternativos foram estimados, prevendo uma taxa de difusão mais conservadora (de 10% a 50%) e agressiva (com 100% de difusão já no primeiro ano), conforme apresentado na **Tabela V.**  
**Tabela V.** Market share para os cenários alternativos 2 e 3 (taxa de difusão conservadora e agressiva).  
|**Cenário Proposto**|**Ano 1**|**Ano 2**|**Ano 3**|**Ano 4**|**Ano 5**|
|---|---|---|---|---|---|
|Cenário alternativo 2 – difusão conservadora||||||
|Cuidado-padrão|90%|80%|70%|60%|50%|
|Crizanlizumabe|10%|20%|30%|40%|50%|
|Cenário alternativo 3 – difusão agressiva||||||
|Cuidado-padrão|0%|0%|0%|0%|0%|
|Crizanlizumabe|100%|100%|100%|100%|100%|  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Perspectiva** -->
Foi adotada a perspectiva do Sistema Único de Saúde (SUS).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Horizonte temporal** -->
O horizonte temporal utilizado foi de cinco anos, conforme as Diretrizes Metodológicas de AIO do MS<sup>177</sup> .

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Custos** -->
Nesta análise, o modelo foi elaborado apenas com custos médicos diretos. A composição do custo incluiu somente o valor do custo dos tratamentos: cuidado padrão (HU+ transfusão) e crizanlizumabe. Os custos incluídos no modelo estão dispostos de forma detalhada no **Quadro J.**  
**Quadro J.** Custos utilizados na análise 1.  
|**Recurso**|**Custo unitário**|**Fonte**|
|---|---|---|
|Custo anual – Crizanlizumabe<sup>a</sup>(ano 1: R$ 341.896,23 e demais an|os: R$ 315.596,52) *||
|Crizanlizumabe 10 mg/mL (ampola)|R$ 6.574,77|CMED- PMVG 18%|
|Administração de medicamentos na atenção especializada|R$ 0,63|Sigtap - 03.01.10.001-2|
|Custo anual – Hidroxiureia 500 mg<sup>b,d</sup>(R$ 1.615,16)|||
|Hidroxiureia 500 mg (cápsula)<sup>a,b</sup>|R$ 1,54|BPS|
|Dispensação de Medicamentos do Componente Especializado da<br>Assistência Farmacêutica|R$ 1,20|Sigtap - 06.04.48.001-6|
|Custo anual – Transfusão sanguínea<sup>c,d</sup>(R$ 982,23)|||
|Coleta de sangue p/ transfusão|R$ 22,00|Sigtap - 03.06.01.001-1|
|Transfusão de concentrado de hemácias|R$ 8,09|Sigtap - 03.06.02.006-8|
|03.06.01.003-8 - Triagem clínica de doador (a) de sangue|R$ 10,00|Sigtap - 03.06.01.003-8|
|Quelação de ferro|||
|Deferasirox 500 mg<sup>e</sup>|R$ 32,29|BPS – média ponderada|  
**Fonte:** elaboração própria. **Legenda** : BPS=Banco de Preços em Saúde; SIGTAP=Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS;<sup>a</sup> Dose de 5 mg/kg de crizanlizumabe na semana 0 e, na semana 2 - e em seguida a cada 4 semanas. Peso médio para a faixa etária usado no cálculo de 70,4 kg (estabelecido conforme IBGE-PNS<sup>178 b</sup> No SUS, a hidroxiureia está disponível como cápsula de 500 mg, sendo a dose diária de hidroxiureia de 20 mg/kg/dia.<sup>c</sup> Número de unidades de transfusão sanguínea=10 e frequência de transfusões por ano = 8,7. Assumiu-se que 11% farão transfusão sanguínea conforme apresentado no estudo de Silva-Pinto<sup>179</sup> .<sup>d</sup> Custo cuidado-padrão estabelecido pela soma do tratamento com hidroxiureia e transfusão sanguínea.<sup>e</sup>  
77  
Cálculo da dose estabelecido considerando 20 mg/kg/dia (3 comprimidos por paciente). Assumiu-se que 15% utilizaram este tratamento, conforme apresentado no estudo de Silva-Pinto<sup>179</sup>

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Pressupostos utilizados no modelo** -->
Foram assumidos alguns pressupostos para a condução desta análise de impacto orçamentário, sendo eles:  
 Para a estimativa do número de frascos-ampolas do crizanlizumabe, calculou-se o número por unidade, havendo o desperdício em cada tomada. Na análise de sensibilidade considerou-se o valor mínimo testado baseado no reaproveitamento dos frascos (isto é, podendo ser utilizado um frasco para dois pacientes por exemplo).  
- Os custos das complicações foram obtidos por microcusteio, conforme estudo publicado por Silva-Pinto em  
2022<sup>179</sup> .  
 Considerou-se que os pacientes do grupo crizanlizumabe não utilizam mais o tratamento de hidroxiureia e  
transfusão sanguínea.  
 Para crizanlizumabe, assumiu-se que no ano 1 todos os pacientes farão 13 administrações do fármaco (considerando que o intervalo posológico entre a primeira e a segunda dose é de 2 semanas e de 4 semanas nas demais doses).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **Análise de sensibilidade** -->
As análises de sensibilidade determinística univariada foram apresentadas em diagrama de tornado. A magnitude de variação de cada parâmetro foi estabelecida conforme a variação identificada nos estudos ou, quando a variação não estava disponível, uma variação de ±25% foi assumida conforme recomendado pelas Diretrizes Metodológicas de AIO do MS<sup>177</sup> . Ainda, os custos extraídos do SIGTAP, foram multiplicados pelo fator de correção tripartite (2,8, variando de 1 a 2,8 nas análises de sensibilidade).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **RESULTADOS** -->
O resultado da AIO, para um horizonte temporal de 5 anos, mostra que a incorporação de crizanlizumabe para pacientes com DF (SS e Sbeta0) em falha terapêutica ou intolerância à hidroxiureia, a partir de 16 anos, gera um incremento de custo, ou seja, um impacto orçamentário positivo, iniciando com R$ 77,8 milhões no primeiro ano, até R$ 456,9 milhões no quinto ano de análise, gerando um total acumulado de R$ 1,3 bilhões em cinco anos **(Tabela W** e **Figura K).**  
**Tabela W.** Resultado da análise de impacto orçamentário para o cenário alternativo 1  
||**Ano 1**|**Ano 2**|**Ano 3**|**Ano 4**|**Ano 5**|**Acumulado**|
|---|---|---|---|---|---|---|
|||||||**(5 anos)**|
|Cenário atual|R$|R$ 8.738.477|R$ 9.129.978|R$ 9.428.241|R$ 9.756.086|R$ 45.333.155|
||8.280.373||||||
|Cenário proposto|R$|<br>R$|R$|R$|R$|R$|
||91.088.711|170.706.867|262.720.618|358.237.883|460.650.775|1.343.404.854|
|Impacto|R$|R$|R$|R$|R$|R$|
|orçamentário|82.808.338|161.968.389|253.590.641|348.809.642|450.894.689|1.298.071.699|  
**Fonte:** elaboração própria.  
78  
**Figura K.** Comparação entre cenário atual e cenário alternativo 1 para a análise 1.  
<!-- Start of picture text -->
500<br>18 450<br>= 400<br>= 350<br>300<br>250<br>200<br>150<br>100|0 |<br>1 2 3 4 5<br>Cenario Atual tm Cenério Proposto ml Impacto Orcamentério<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
Na análise de sensibilidade determinística a proporção de pacientes com os genótipos HbSS e HbB0 e o preço de aquisição do crizanlizumabe foram as variáveis que mais impactaram no modelo. Resultados para o valor acumulado em cinco anos são apresentados na **Figura L.**  
**Figura** **_L_ .** Análise de sensibilidade determinística para o valor acumulado em cinco anos para o cenário alternativo 1  
<!-- Start of picture text -->
Milhdes<br>RS 700 RS 1.000 RS 1.300 RS 1.600 R$ 1.900<br>RS 854,50SII Rs 1.709,17Genétipo HbSS e HBO<br>RS 966,55 (I SI Rs 1.629,56 Prego - Crizanlizumabe<br>2560020 [TT NN Rs 102,00 Peso médio<br>RS 973,55 I SII Rs 1.622,59 Pacientes nao respondedores<br>RS 1.291,09 |] RS 1.305,05 Custo cuidado padrao<br>= Minimo = Maximo<br><!-- End of picture text -->  
**Fonte:** elaboração própria.  
Finalmente, considerando os cenários alternativos 2 e 3, de _market share_ conservador ( _market share_ de 10% a 50% do primeiro ao quinto ano, respectivamente) e agressivo (com difusão de 100% do uso de crizanlizumabe já no primeiro ano de incorporação), há um impacto orçamentário positivo de R$ 649,0 milhões em cinco anos (variando de R$ 41,4 milhões no primeiro ano a R$ 225,4 milhões no quinto ano de análise) e de R$ 2,1 bilhões em cinco anos (variando de R$ 414,0 milhões no primeiro ano a R$ 450,9 milhões no quinto ano de análise), respectivamente **(Tabela X).**  
**Tabela X.** Resultado do Impacto orçamentário para o cenário alternativo 2 e 3  
|**Ano 1**|**Ano 2**|**Ano 3**|**Ano 4**|**Ano 5**|**Acumulado**|
|---|---|---|---|---|---|
||||||**(5 anos)**|
|Cenário alternativo 2 – difusão|conservadora|||||
|Cenário atual<br>R$ 8.280.373|R$ 8.738.477|R$ 9.129.978|R$ 9.428.241|R$ 9.756.086|R$ 45.333.155|  
79  
||**Ano 1**|**Ano 2**|**Ano 3**|**Ano 4**|**Ano 5**|**Acumulado**|
|---|---|---|---|---|---|---|
|||||||**(5 anos)**|
|Cenário|R$ 49.684.542|R$ 89.722.672|R$|R$|R$|R$ 694.369.005|
|proposto|||135.925.298|183.833.062|235.203.430||
|Impacto|R$ 41.404.169|R$ 80.984.195|R$|R$|R$|R$ 649.035.849|
|orçamentário|||126.795.320|174.404.821|225.447.344||
|Cenário altern|ativo 3 – difusão a|gressiva|||||
|Cenário atual|R$ 8.280.373|R$ 8.738.477|R$ 9.129.978|R$ 9.428.241|R$ 9.756.086|R$ 45.333.155|
|Cenário|R$|R$|R$|R$|R$|R$|
|proposto|422.322.064|413.659.451|431.781.045|445.440.293|460.650.775|2.173.853.628|
|Impacto|R$|R$|R$|R$|R$|R$|
|orçamentário|414.041.690|404.920.974|422.651.068|436.012.052|450.894.689|2.128.520.473|  
**Fonte:** elaboração própria.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **9.        ACEITABILIDADE** -->
Crizanlizumabe pode preencher uma necessidade não atendida e abordar algumas das desigualdades de saúde para o grupo de pacientes que não toleram ou não têm indicação de hidroxiureia. Além disso, o crizanlizumabe parece ter sido bem tolerado no contexto do ensaio clínico comparado a placebo, uma vez que, no estudo SUSTAIN, os pacientes que relataram um evento adverso grave foram 26% no grupo crizanlizumabe 5mg/kg e 27% no grupo placebo e os pacientes que interromperam a terapia devido a um evento adverso foram 3,0% e 4,8%, respectivamente (19). A maioria dos pacientes que participaram dos estudos clínicos relatou que o tratamento foi fácil de usar e não experimentou efeitos colaterais graves. Além disso, a maioria dos pacientes relatou que eles estariam dispostos a continuar a usar o crizanlizumabe se ele fosse aprovado e disponível (19).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **9.        ACEITABILIDADE** -->
Crizanlizumabe possui registro válido em bula na Anvisa, até março de 2023 (18). É um medicamento administrado por via intravenosa (IV) e, portanto, precisa ser administrado por um profissional de saúde em um serviço de saúde. Se houver a incorporação da tecnologia, crizanlizumabe deve ser administrado duas vezes ao mês no primeiro mês e depois uma vez por mês, por meio de infusão de 30 minutos, cada aplicação.  
A doença falciforme não é amplamente compreendida, e por este motivo, é comum a ocorrência de um atendimento hospitalar inadequado e estigma em torno da busca de alívio da dor para crises desses pacientes. Para a implementação do crizanlizumabe no Brasil é necessária garantir além da disponibilidade do medicamento, de capacidade de administração, incluindo profissionais de saúde treinados e equipamentos adequados para a administração do medicamento via IV.  
Tanto os centros de referência como os serviços de saúde gerais devem estar preparados para garantir o acesso mensal dos pacientes, os profissionais devem estar bem orientados sobre a sintomatologia das crises de dor e preparados para casos de reações relacionadas à infusão, incluindo episódios de dor intensa, ocorrendo a maioria durante a primeira e segunda infusões. Além disso, seria interessante um sistema de monitoramento e avaliação para garantir a segurança e eficácia do tratamento a longo prazo, uma vez que os estudos avaliados carecem de informações a longo prazo.

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **9.        ACEITABILIDADE** -->
Em pesquisa realizada em janeiro de 2023 nos sites de agências de ATS, foi utilizado o termo “crizanlizumab” e foram encontradas avaliações do National Institute for Health and Care Excellence (NICE – Inglaterra) e Scottish Medicines Consortium (SMC – Escócia). Não foram encontradas avaliações do crizanlizumabe no Canadian Agency for Drugs and  
80  
Technologies in Health (CADTH – Canadá), no Pharmaceutical Benefits Advisory Committee (PBAC – Austrália) e na ANMAT (Administración Nacional de Medicamentos, Alimentos y Tecnología Médica – Argentina).  
As recomendações do NICE foram publicadas em novembro de 2021 afirmando que o crizanlizumabe é recomendado como uma opção para prevenir crises falciformes recorrentes (crises vaso-oclusivas) em pessoas com 16 anos ou mais com doença falciforme somente se as condições do contrato de acesso gerenciado forem seguidas. E ressaltaram que esta recomendação não visa afetar o tratamento com crizanlizumabe iniciado antes da publicação desta orientação no NHS. Portanto, as pessoas que recebem tratamento diferente desta recomendação podem continuar a receber, sem alterar os acordos de financiamento em vigor para elas antes da publicação desta orientação, até que elas e seu médico do NHS considerem apropriado interromper (42).  
As recomendações do SMC foram publicadas em julho de 2022, apontando que o crizanlizumabe é aceito para uso no NHS Scotland em caráter provisório, sujeito a avaliação contínua e futura reavaliação, na seguinte indicação: “Prevenção de crises vaso-oclusivas recorrentes (COV) em pacientes com doença falciforme (DF) com idade igual ou superior a 16 anos, como terapia adjuvante de hidroxiureia/hidroxicarbamida (HC/HU) ou como monoterapia em pacientes para os quais HC/HU é impróprio ou inadequado” (43).

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **9.        ACEITABILIDADE** -->
Para indivíduos com mais de 16 anos diagnosticados com anemia falciforme, que já tiveram pelo menos uma crise vasoclusiva e que estão em falha terapêutica ou apresentam intolerância à hidroxiureia, o crizanlizumabe foi avaliado como uma possível opção de tratamento.  
Os resultados da **síntese de evidências clínicas** sugerem que o tratamento com crizanlizumabe 5,0 mg/kg mostrou-se superior ao placebo em relação a três desfechos avaliados: redução no número de crises vaso-oclusivas ao longo de um ano, atraso na ocorrência da primeira crise e redução no número de crises vaso-oclusivas não complicadas. No entanto, não houve diferença entre os grupos no tempo de internação devido à crise. Consequentemente, pode-se sugerir que o uso do crizanlizumabe 5,0 mg/kg tem efeito positivo na diminuição da frequência e no atraso da ocorrência dessas crises de dor. No entanto, em casos em que ocorre a crise, não há evidências de que seja menos grave em comparação com as crises experimentadas por pacientes que não utilizam o medicamento. Como limitações da evidência identificada destacam-se: a falta de estudos com acompanhamento de longo prazo; um pobre reporte quanto às características dos participantes incluídos, como a falta de informação sobre a inclusão de pacientes com intolerância à hidroxiureia; e a incerteza sobre a eficácia e segurança de crizanlizumabe associado a transfusões de sangue regulares, uma vez que, este foi um critério de exclusão do estudo avaliado.  
As **análises de custo-efetividade/utilidade** , para um horizonte temporal por toda vida, sugerem que o uso do crizanlizumabe adjunto do procedimento padrão como prevenção de crises vasoclusiva em pacientes com doença falciforme, em comparação ao tratamento padrão, apresenta maior benefício clínico, porém com um custo incremental elevado, gerando valores de RCEI de R$ 4.054.678,36/QALY ganho e R$12.389.851,40/AV ganho, valores acima do limiar de custo-efetividade estabelecido pela Conitec para doença grave. Ademais, as análises de sensibilidade determinística revelaram que, para ambos os desfechos, o HR entre o crizanlizumabe e o procedimento padrão utilizado para as probabilidades de transição é o parâmetro que mais impacta na RCEI, seguida da taxa de desconto aplicada aos custos e desfechos e o custo do crizanlizumabe.  
Para avaliar o **impacto orçamentário** da incorporação do crizanlizumabe, comparado ao cuidado padrão, foram realizadas duas análises: considerando somente os custos dos tratamentos (cuidado-padrão e crizanlizumabe) – Análise 1 e adicionando custos dos tratamentos associados aos custos das complicações – Análise 2. Com base em um market share de 20% a 100% o impacto orçamentário para a análise 1 e 2 é de R$ 82,8 milhões e R$ 80,8 milhões no primeiro ano, e de R$ 450,9 milhões e R$ 439,1 milhões no quinto ano de análise, respectivamente. Em ambas as análises há um impacto positivo acumulado de R$ 1,3 bilhões em cinco anos.  
81  
REFERÊNCIAS  
1. Weatherall DJ, Clegg JB. Inherited haemoglobin disorders: an increasing global health problem. Bull World Health Organ. 2001;79(8):704–12.  
2. Jamison DT, Breman JG, Measham AR, Alleyne G, Claeson M, Evans DB, et al. Disease control priorities in developing countries. 2006;  
3. Zago MA, Pinto ACS. Fisiopatologia das doenças falciformes: da mutação genética à insuficiência de múltiplos órgãos. Rev Bras Hematol Hemoter. 2007;29:207–14.  
4. Schechter AN. Hemoglobin research and the origins of molecular medicine. Blood. 15 de novembro de 2008;112(10):3927–38.  
5. Silva RB, Ramalho AS, Cassorla R. A anemia falciforme como problema de saúde pública no Brasil. Rev Saude Publica. 1993;27:54–8.  
6. Loureiro MM, Rozenfeld S. Epidemiology of sickle cell disease hospital admissions in Brazil. Rev Saude Publica. 2005;39:943–9.  
7. Wastnedge E, Waters D, Patel S, Morrison K, Goh MY, Adeloye D, et al. The global burden of sickle cell disease in children under five years of age: a systematic review and meta-analysis. J Glob Health. dezembro de 2018;8(2):021103.  
8. Naoum PC, Alvarez Filho F, Domingos CRB, Ferrari F, Moreira HW, Sampaio ZA, et al. Hemoglobinas anormais no Brasil: prevalência e distribuiçäo geográfica. Rev bras patol clín. 1987;68–79.  
9. Diniz D, Guedes C, Barbosa L, Tauil PL, Magalhães Í. Prevalence of sickle cell trait and sickle cell anemia among newborns in the Federal District, Brazil, 2004 to 2006. Cad Saude Publica. 2009;25:188–94.  
10. Brasil. Ministério da Saúde. NOTA TÉCNICA No 29/2022-CGSH/DAET/SAES/MS. Secretaria de Atenção Especializada à Saúde Departamento de Atenção Especializada e Temática Coordenação-Geral de Sangue e Hemoderivados.2022.  
11. Kato GJ, Piel FB, Reid CD, Gaston MH, Ohene-Frempong K, Krishnamurti L, et al. Sickle cell disease. Nat Rev Dis Primers. 2018;4(1):1–22.  
12. Piel FB, Steinberg MH, Rees DC. Sickle Cell Disease. New England Journal of Medicine. 20 de abril de 2017;376(16):1561–73.  
13. Elmariah H, Garrett ME, de Castro LM, Jonassaint JC, Ataga KI, Eckman JR, et al. Factors associated with survival in a contemporary adult sickle cell disease cohort. Am J Hematol. maio de 2014;89(5):530–5.  
14. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Hospitalar e de Urgência. Doença falciforme: diretrizes básicas da linha de cuidadoBrasília: Ministério da Saúde, 2015. 82 p. il. ISBN 978-85-334-2310-7 1.  
15. Esoh K, Wonkam-Tingang E, Wonkam A. Sickle cell disease in sub-Saharan Africa: transferable strategies for prevention and care. Lancet Haematol. outubro de 2021;8(10):e744–55.  
16. Ballas SK, Lusardi M. Hospital readmission for adult acute sickle cell painful episodes: frequency, etiology, and prognostic significance. Am J Hematol. maio de 2005;79(1):17–25.  
17. Novelli EM, Gladwin MT. Crises in Sickle Cell Disease. Chest. abril de 2016;149(4):1082–93.  
18. Novartis Biociências S.A. Bula do produto Adakveo®. 2022. Novartis Pharma Stein AG, Stein, Suíça.  
19. Ataga KI, Kutlar A, Kanter J, Liles D, Cancado R, Friedrisch J, et al. Crizanlizumab for the Prevention of Pain Crises in Sickle Cell Disease. New England Journal of Medicine. 2 de fevereiro de 2017;376(5):429–39.  
20. Brasil. Agência Nacional de Vigilância Sanitária. Câmara de Regulação CMED. Secretaria Executiva. PREÇOS MÁXIMOS DE MEDICAMENTOS POR PRINCÍPIO ATIVO, PARA COMPRAS PÚBLICAS PREÇO FÁBRICA (PF) E PREÇO MÁXIMO DE VENDA AO GOVERNO (PMVG). [Internet]. [citado 3 de janeiro de 2021]. Disponível em: https://www.gov.br/anvisa/pt-br/assuntos/medicamentos/cmed/precos/arquivos/lista_conformidade_gov_2021_12_v3.pdf  
82  
21. Brasil. Ministério da Saúde. Banco de Preços em Saúde - BPS [Internet]. [cited 2020 Nov 23]. Available from: http://bps.saude.gov.br/visao/consultaPublica/relatorios/geral/index.jsf.  
22. Ataga KI, Kutlar A, Kanter J, Liles D, Cancado R, Friedrisch J, et al. Crizanlizumab for the Prevention of Pain Crises in Sickle Cell Disease. N Engl J Med [Internet]. 2 de fevereiro de 2017 [citado 23 de março de 2023];376(5):429–39. Disponível em: https://www.nejm.org/doi/full/10.1056/NEJMoa1611770  
23. Kutlar A, Kanter J, Liles DK, Alvarez OA, Cançado RD, Friedrisch JR, et al. Effect of crizanlizumab on pain crises in subgroups of patients with sickle cell disease: A SUSTAIN study analysis. Am J Hematol [Internet]. janeiro de 2019 [citado 23 de março de 2023];94(1):55–61. Disponível em: https://doi.org/10.1002/ajh.25308  
24. National Institute for Health and Care Excellence. Single Technology Appraisal. Crizanlizumab for preventing sickle cell crises in sickle cell disease [ID1406]. Committee Papers [Internet]. 2021 [citado 21 de março de 2023]. Disponível em: https://www.nice.org.uk/guidance/ta743/evidence/appraisal-consultation-committee-papers-pdf-9266821165  
25. Novartis Biociências S.A. ADAKVEO ® (crizanlizumabe) / Solução para diluição para infusão / 10 mg/mL / Bula Profissional [Internet]. 2022 [citado 21 de março de 2023]. Disponível em: https://portal.novartis.com.br/medicamentos/wpcontent/uploads/2022/04/Bula-ADAKVEO-Solucao-para-Diluicao-para-Infusao-Medico.pdf  
26. Brasil. Ministério da Saúde. Secretaria de Ciência T e IEstratégicos. Protocolo Clínico e Diretrizes Terapêuticas Doença Falciforme [Internet]. 2018. Disponível em: http://conitec.gov.br 27. Cançado RD, Costa FF, Lobo C, Migliavaca CB, Falavigna M, Filho HCRS, et al. Sickle Cell Disease Mortality in Brazil: Real-World Evidence. Blood [Internet]. 5 de novembro de 2021;138(Supplement 1):3025–3025. Disponível em: https://doi.org/10.1182/blood-2021-151098  
28. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. Diretrizes metodológicas: Diretriz de Avaliação Econômica. 2. ed. Brasília: Ministério da Saúde; 2014. 132 p.  
29. Bailey M, Bonner A, Brown S, Thompson M. PRO91 REDUCTION IN HRQOL WITH INCREASING VOC FREQUENCY AMONG PATIENTS WITH SCD. Value in Health [Internet]. maio de 2020 [citado 5 de junho de 2023];23:S345. Disponível em: https://doi.org/10.1016/j.jval.2020.04.1312  
30. Silva-Pinto AC, Costa FF, Gualandro SFM, Fonseca PBB, Grindler CM, Souza Filho HCR, et al. Economic burden of sickle cell disease in Brazil. Yassin MA, organizador. PLoS One [Internet]. 16 de junho de 2022;17(6):e0269703. Disponível em: https://dx.plos.org/10.1371/journal.pone.0269703  
31. Bailey M, Abioye A, Morgan G, Burke T, Disher T, Brown S, et al. Relationship between Vaso-Occlusive Crises and Important Complications in Sickle Cell Disease Patients. Blood [Internet]. 13 de novembro de 2019;134(Supplement_1):2167–  
2167. Disponível em: https://ashpublications.org/blood/article/134/Supplement_1/2167/428009/Relationship-betweenVasoOcclusive-Crises-and  
32. Lobo CL de C, Nascimento EM do, Jesus LJC de, Freitas TG de, Lugon JR, Ballas SK. Mortality in children, adolescents and adults with sickle cell anemia in Rio de Janeiro, Brazil. Hematol Transfus Cell Ther. 1o de janeiro de 2018;40(1):37–42.  
33. Platt OS, Thorington BD, Brambilla DJ, Milner PF, Rosse WF, Vichinsky E, et al. Pain in Sickle Cell Disease. New England Journal of Medicine. 4 de julho de 1991;325(1):11–6.  
34. Brasil. Câmara de regulação do mercado. Câmara de regulação do mercado de medicamentos. Câmara de Regulação do Mercado de Medicamentos (CMED) [Internet]. 2023 [citado 21 de maio de 2023]. Disponível em: https://www.gov.br/anvisa/ptbr/assuntos/medicamentos/cmed/precos  
35. Brasil. Banco Central do Brasil. Conversor de Moedas [Internet]. 2023 [citado 21 de maio de 2023]. Disponível em: https://www.bcb.gov.br/conversao  
36. Salcedo J, Bulovic J, Young CM. Cost-effectiveness of a hypothetical cell or gene therapy cure for sickle cell disease. Sci Rep [Internet]. 25 de maio de 2021;11(1):10838. Disponível em: https://www.nature.com/articles/s41598-021-90405-1  
83  
37. Pompeo CM, Ferreira Júnior MA, Cardoso AI de Q, Souza M da C, Mota FM, Ivo ML. Survival of sickle cell disease patients diagnosed during newborn screening: systematic review. Research, Society and Development [Internet]. 24 de agosto de 2021;10(11):e95101119329. Disponível em: https://rsdjournal.org/index.php/rsd/article/view/19329  
38. Chand AR, Xu H, Wells LG, Clair B, Neunert C, Spellman AE, et al. Are There True Non-Responders to Hydroxyurea in Sickle Cell Disease? a Multiparameter Analysis. Blood [Internet]. 6 de dezembro de 2014;124(21):4073. Disponível em: https://doi.org/10.1182/blood.V124.21.4073.4073  
39. MS. https://www.gov.br/conitec/ptbr/midias/artigos_publicacoes/diretrizes/diretrizes_metodologicas_analise_impacto-1.pdf. 2012. Diretrizes metodológicas - Análise de Impacto Orçamentário - Manual para o Sistema de Saúde do Brasil.  
40. IBGE. https://sidra.ibge.gov.br/pesquisa/pns/pns-2019. 2019. PNS - Pesquisa Nacional de Saúde 2019 Tabelas - .  
41. Silva-Pinto AC, Costa FF, Gualandro SFM, Fonseca PBB, Grindler CM, Souza Filho HCR, et al. Economic burden of sickle cell disease in Brazil. PLoS One [Internet]. 16 de junho de 2022;17(6):e0269703-. Disponível em: https://doi.org/10.1371/journal.pone.0269703  
42. NICE. National institute for health and Care Excellence, “Evidence-based recommendations on crizanlizumab for preventing sickle cell crises in people aged 16 or over with sickle cell disease. 2021. https://www.nice.org.uk/guidance/ta743 (accessed Jan. 20, 2023).  
43. Scottish Medicines Consortium (SMC), “Crizanlizumab 10mg/mL concentrate for solution for infusion (Adakveo®)” 2022. https://www.scottishmedicines.org.uk/media/6982/crizanlizumab-adakveo-final-june-2022-for-website.pdf (accessed Jan. 20, 2023).  
44. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews. Syst Rev. 2016;5(1):210.  
45. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, Moher D, Tugwell P, Welch V, Kristjansson E, Henry DA. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017 Sep 21;358:j4008.  
46. Higgins JPT, Altman DG, Gotzsche PC, Juni P, Moher D, Oxman AD, et al. RoB 2: a revised tool for assessing risk of bias in randomised trials. BMJ 2019; 366: l4898. BMJ. 18 de outubro de 2011;343(oct18 2):d5928–d5928.  
47. Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: a revised tool for assessing risk of bias in randomised trials. BMJ. 28 de agosto de 2019;l4898.  
48. Sterne JA, Hernán MA, Reeves BC, Savović J, Berkman ND, Viswanathan M, et al. ROBINS-I: a tool for assessing risk of bias in non-randomised studies of interventions. BMJ. 12 de outubro de 2016;i4919.  
49. Copenhagen: The Nordic Cochrane Centre. Review Manager (RevMan). Version 5.3. 2014.  
50. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 26 de abril de 2008;336(7650):924–6.  
51. Brasil. Ministério da Saúde. Diretrizes Metodológicas: Sistema GRADE - manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. 2014.  
52. Stevens DL, Hix M, Gildon BL. Crizanlizumab for the Prevention of Vaso-Occlusive Pain Crises in Sickle Cell Disease. Journal of Pharmacy Technology. 19 de agosto de 2021;37(4):209–15.  
53. Yu Z, Blankenship L, Jaiyesimi I. Crizanlizumab in Sickle Cell Disease. New England Journal of Medicine. 4 de maio de 2017;376(18):1795–6.  
54. Dick MH, Abdelgadir A, Kulkarni VV, Akram H, Chatterjee A, Pokhrel S, et al. Comparing the Safety and Efficacy of L-Glutamine, Voxelotor, and Crizanlizumab for Reducing the Frequency of Vaso-Occlusive Crisis in Sickle Cell Disease: A Systematic Review. Cureus. 11 de maio de 2022;  
84  
55. Kutlar A, Kanter J, Liles D, Cancado R, Bruederle A, Shi M, et al. Crizanlizumab, A P-selectin inhibitor, increases the likelihood of not experiencing a sickle cell-related pain crisis while on treatment: Results from the phase II sustain study. Haematologica [Internet]. 2017;102:166. Disponível em: https://www.embase.com/search/results?subaction=viewrecord&id=L617381013&from=export  
56. Kanter J, Kutlar A, Liles D, Cançado R, Bruederle A, Shi M, et al. Crizanlizumab 5.0 mg/kg increased the time to first on-treatment sickle cell pain crisis: A subgroup analysis of the phase ii sustain study. Blood [Internet]. 2017;130. Disponível em: https://www.embase.com/search/results?subaction=viewrecord&id=L620310599&from=export  
57. Ataga KI, Kutlar A, Cancado R, Liles D, Velez-Nandayapa L, Lincy J, et al. Crizanlizumab treatment is not associated with the development of proteinuria and hematuria in patients with sickle cell disease: A safety analysis from the sustain study.  
Hemasphere [Internet]. 2018;2:305–6. Disponível em:  
https://www.embase.com/search/results?subaction=viewrecord&id=L625922545&from=export  
58. Washko JK, Kutlar A, Liles D, Cançado R, Shi M, Zhu Z, et al. Crizanlizumab 5.0mg/kg increased the time to first ontreatment Sickle Cell Pain Crisis (SCPC) and the likelihood of not experiencing SCPC while on treatment: Subgroup analyses of the phase 2 sustain study. Pediatr Blood Cancer [Internet]. 2018;65:S81. Disponível em: https://www.embase.com/search/results?subaction=viewrecord&id=L621729239&from=export  
59. Shah N, Boccia R, Kraft WK, Hardesty BM, Paulose J, Laine D, et al. A Multicenter Retrospective Noninterventional Follow-up Study in Patients with Sickle Cell Pain Crisis Who Previously Participated in the Sustain Trial in the United States Successor Study. Blood. 29 de novembro de 2018;132(Supplement 1):4910–4910. 60. Liles DK, Cançado R, Kanter J, Kutlar A, Bruederle A, Shi M, et al. Established Prevention of Vaso-Occlusive Crises with Crizanlizumab Is Further Improved in Patients Who Follow the Standard Treatment Regimen: Post-Hoc Analysis of the Phase II Sustain Study. Blood. 29 de novembro de 2018;132(Supplement 1):1082–1082.  
61. Yen G, Yasuda M, McGuiness C, He J, Lee S, Paulose J, et al. HSD63 Real-World Crizanlizumab Treatment Patterns of Patients with Sickle Cell Disease. Value in Health. julho de 2022;25(7):S491.  
62. Real-World Incidence Of Vaso-Occlusive Crises In Patients With Sickle Cell Disease (SCD) And A High Baseline Disease Burden Treated With Crizanlizumab: Results From A Managed Access Program (MAP). Abstract Book for the 27th Congress of the European Hematology Association. Hemasphere. 23 de junho de 2022;6:1–4130.  
63. Bueno C, Campos L, Ritter A, Zampirolli C, Watanabe De Oliveira R. EFFECTIVENESS OF CRIZANLIZUMAB IN REDUCING VASO-OCCLUSIVE CRISIS IN PATIENTS WITH SICKLE CELL DISEASE IN BRAZIL: STUDY PROTOCOL FOR AN OBSERVATIONAL, RETROSPECTIVE, MULTICENTER, NATIONAL STUDY. Hemasphere [Internet]. 2022;6:3822–3. Disponível em: https://www.embase.com/search/results?subaction=viewrecord&id=L638938779&from=export  
64. Yang M, Elmuti L, Badawy SM. Health-Related Quality of Life and Adherence to Hydroxyurea and Other DiseaseModifying Therapies among Individuals with Sickle Cell Disease: A Systematic Review. Biomed Res Int. 18 de julho de 2022;2022:1–8.  
65. Heeney M, Rees D, de Montalembert M, Odame I, Brown C, Wali Y, et al. Safety and efficacy of crizanlizumab in adolescents with sickle cell disease (SCD): Initial data from the phase II, multicenter, open-label Solace-Kids trial. Hemasphere [Internet]. 2022;6(1):12. Disponível em: https://www.embase.com/search/results?subaction=viewrecord&id=L637390316&from=export  
66. Heeney MM, Rees DC, de Montalembert M, Odame I, Brown RCC, Wali Y, et al. Initial Safety and Efficacy Results from the Phase II, Multicenter, Open-Label Solace-Kids Trial of Crizanlizumab in Adolescents with Sickle Cell Disease (SCD). Blood [Internet]. 2021;138:12. Disponível em:  
https://www.embase.com/search/results?subaction=viewrecord&id=L2016087752&from=export  
85  
67. Kanter J, Shah A, Joshi V, Mehta H, Levine M, Arunagiri U, et al. Rare Cases of Infusion-Related Reactions (IRRs) Presenting As Pain Events during or after Crizanlizumab Infusion in Patients (Pts) with Sickle Cell Disease (SCD): A Systematic Evaluation of Post-Marketing (PM) Reports. Blood [Internet]. 2021;138:3112. Disponível em: https://www.embase.com/search/results?subaction=viewrecord&id=L2016078646&from=export  
68. Martí-Carvajal A, Abd El Aziz MA, Martí-Amarista C, Solà I. Antiplatelet agents for preventing vaso-occlusive events in people with sickle cell disease: a systematic review. Clin Adv Hematol Oncol. abril de 2019;17(4):234–43.  
69. Ataga KI, Kutlar A, DeBonnett L, Lincy J, Kanter J. Crizanlizumab Treatment Is Associated with Clinically Significant Reductions in Hospitalization in Patients with Sickle Cell Disease: Results from the Sustain Study. Blood. 13 de novembro de 2019;134(Supplement_1):2289–2289.  
70. Kanter J, Liles DK, Smith-Whitley K, Brown C, Kutlar A, Elliott B, et al. Crizanlizumab 5.0 Mg/Kg Exhibits a Favorable Safety Profile in Patients with Sickle Cell Disease: Pooled Data from Two Phase II Studies. Blood. 13 de novembro de 2019;134(Supplement_1):991–991.  
71. Ataga KI, Saraf SL, Derebail VK, Sharpe CC, Inati A, Lebensburger JD, et al. The Effect of Crizanlizumab Plus Standard of Care (SoC) Versus Soc Alone on Renal Function in Patients with Sickle Cell Disease and Chronic Kidney Disease: A Randomized, Multicenter, Open-Label, Phase II Study (STEADFAST). Blood. 13 de novembro de 2019;134(Supplement_1):1018–1018.  
72. Katoch D, Krishnamurti L. Assessing Patient Preferences for Treatment Options for Pediatric Sickle Cell Disease: A Critical Review of Quantitative and Qualitative Studies. Patient Prefer Adherence. outubro de 2021;Volume 15:2221–9.  
73. Smith WR, Ataga KI, Saraf SL, Adisa OA, Bailey M, Ramscar N, et al. The Effect of Crizanlizumab on the Number of Days Requiring Opioid Use for Management of Pain Associated with Vaso-Occlusive Crises in Patients with Sickle Cell Disease: Results from the Sustain Trial. Blood. 5 de novembro de 2020;136(Supplement 1):32–3.  
74. Cançado RD, Colombatti R, Quarta A, Arcioni F, DeBonnett L, Soliman W, et al. Real-World Data on the Occurrence of Vaso-Occlusive Crises (VOCs) in Patients with Sickle Cell Disease (SCD) and a High Baseline Disease Burden Treated with Crizanlizumab: Results from a Managed Access Program (MAP). Blood. 5 de novembro de 2021;138(Supplement 1):4180– 4180.  
75. Silva-Pinto AC, Marturano E, Debonnett L, Cancado RD. Real-world data from the crizanlizumab managed access program (map): Baseline disease burden and prior treatments for patients with sickle cell disease (scd) and recurrent vasoocclusive crises (vocs). EHA2021 Virtual Congress Abstract Book. Hemasphere. junho de 2021;5:e566.  
76. Han J, Saraf SL, Gordeuk VR. Systematic Review of Crizanlizumab: A New Parenteral Option to Reduce Vaso‐ occlusive Pain Crises in Patients with Sickle Cell Disease. Pharmacotherapy: The Journal of Human Pharmacology and Drug Therapy. 20 de junho de 2020;40(6):535–43.  
77. Thom H, Jansen J, Shafrin J, Zhao L, Joseph G, Cheng HY, et al. Crizanlizumab and comparators for adults with sickle cell disease: a systematic review and network meta-analysis. BMJ Open. 17 de setembro de 2020;10(9):e034147.  
78. Burnett A, el Rassi F, Darbari D, Paulose J, Lainé D, Purkayastha D, et al. 147 A Prospective Phase II, Open-Label, Single-arm, Multicenter Study to Assess the Efficacy and Safety of SEG101 (Crizanlizumab) in Sickle Cell Disease Patients With Priapism (SPARTAN). J Sex Med. janeiro de 2020;17(1):S43.  
79. el Rassi FA, Darbari DS, Burnett A, Paulose J, Laine DI, Purkayastha D, et al. A Prospective Phase II, Open-Label, Single-Arm, Multicenter Study to Assess the Efficacy and Safety of SEG101 (Crizanlizumab) in Sickle Cell Disease Patients with Priapism (SPARTAN). Blood. 13 de novembro de 2019;134(Supplement_1):1007–1007.  
80. Abboud MR, Howard J, Cançado R, Smith WR, Güvenç B, Espurz N, et al. Crizanlizumab Versus Placebo, with or without Hydroxyurea/Hydroxycarbamide, in Adolescent and Adult Patients with Sickle Cell Disease and Vaso-Occlusive Crises: A Randomized, Double-Blind, Phase III Study (STAND). Blood. 13 de novembro de 2019;134(Supplement_1):998–998. 81.  
86  
81. Bartolucci P; SSL; DVK; SCC; IA; LJD; DL; ZY; AKI; Steadfast: A phase ii study investigating the effect of crizanlizumab and standard of care (SOC) vs soc alone on renal function in patients with chronic kidney disease due to sickle cell nephropath. Abstract Book: 25th Congress of the European Hematology Association Virtual Edition, 2020. Hemasphere. junho de 2020;4:1– 1168.  
82. Saraf SL, Ataga KI, Derebail VK, Sharpe CC, Inati A, Lebensburger JD, et al. A Phase II, Randomized, Multicenter, Open-Label Study Evaluating the Effect of Crizanlizumab and Standard of Care (SoC) Versus Standard of Care Alone on Renal Function in Patients with Chronic Kidney Disease Due to Sickle Cell Nephropathy (STEADFAST). Blood. 5 de novembro de 2021;138(Supplement 1):3096–3096.  
83. Kutlar A, Kanter J, Liles DK, Alvarez OA, Cançado RD, Friedrisch JR, et al. Effect of crizanlizumab on pain crises in subgroups of patients with sickle cell disease: A SUSTAIN study analysis. Am J Hematol. janeiro de 2019;94(1):55–61.  
87  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Doença Falciforme | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório**<br>**d**<br>**diti**<br>**líi**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**a**<br>**rerz**<br>**cnca**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório<br>de<br>Recomendação nº 923|Incorporação<br>de<br>tecnologias|Incorporação da hidroxiureia 100 mg<br>para o tratamento de pacientes com<br>doença falciforme com pelo menos 9<br>meses<br>de<br>idade<br>[Portaria<br>SECTICS/MS nº 4, de 5 de março de<br>2024; Relatório de Recomendação nº<br>872/2024]<br>Incorporação da hidroxiureia para o<br>tratamento de pacientes com doença<br>falciforme (SS, Sbeta0, Sbeta+ grave e<br>SD Punjab), entre 9 e 24 meses de<br>idade, sem sintomas e complicações<br>[Portaria SECTICS/MS nº 2, de 5 de<br>março<br>de<br>2024;<br>Relatório<br>de<br>Recomendação nº 873/2024]<br>Incorporação da alfaepoetina para o<br>tratamento de pacientes com doença<br>falciforme apresentando declínio da<br>função renal e piora dos níveis de<br>hemoglobina [Portaria SECTICS/MS<br>nº 12, de 3 de abril de 2024]|Não<br>incorporação<br>da<br>hidroxiureia 1000 mg para o<br>tratamento de pacientes com<br>doença falciforme com pelo<br>menos 9 meses de idade<br>[Portaria SECTICS/MS nº 4, de<br>5 de março de 2024; Relatório<br>de Recomendação nº 872/2024]|
|Portaria Conjunta SAS-<br>SCTIE/MS nº 05, de 19<br>de fevereiro de 2018|Unificação<br>do<br>documento<br>com<br>o<br>Protocolo de Uso|Indicação de transplante alogênico<br>aparentado de medula óssea, de sangue<br>periférico ou de sangue de cordão<br>umbilical, do tipo mieloablativo, para<br>tratamento<br>da<br>doença<br>falciforme<br>[Portaria SCTIE/MS nº 30, de 30 de<br>junho<br>de<br>2015;<br>Relatório<br>de<br>Recomendação nº 151/2015].<br>Ampliação<br>da<br>faixa<br>etária<br>para<br>indicação de transplante mieloablativo<br>alogênico aparentado para tratamento<br>da doença falciforme.|-|  
88  
|**Número do Relatório**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**da**<br>**diretriz**<br>**clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||Protocolo de Uso de<br>doppler<br>transcraniano<br>como<br>procedimento|||
|Portaria SAS/MS nº 473,<br>de 26 de abril de 2013|ambulatorial<br>na<br>prevenção do Acidente<br>Vascular Encefálico em<br>pacientes com doença<br>falciforme|-|-|
|Portaria SAS/MS nº 55,<br>de 29 de janeiro de 2010|Atualização do conteúdo|-|-|
|Portaria SAS/MS nº 872,<br>de 06 de novembro de<br>2002|Primeira<br>versão<br>do<br>PCDT<br>–<br>Doença<br>Falciforme<br>-<br>Hidroxiureia|-|-|  
89

---

