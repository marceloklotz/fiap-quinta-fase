<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 17, DE 12 DE NOVEMBRO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Diabete Melito Tipo 1.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre o diabete melito tipo 1 no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação n<sup><u>o</u></sup> 429/2019 e ~~n~~<sup><u>o</u></sup> 479/2019 e os relatórios de recomendação n<sup><u>o</u></sup> 440 – Março de 2019 e ~~n~~<sup><u>o</u></sup> 489 – Outubro de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Diabete Melito Tipo 1.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do diabete melito tipo 1, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do</u> Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do diabete melito tipo 1.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede  
assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria Conjunta n<sup>o</sup> 8/SAS/SCTIE/MS, de 15 de março de 2018, publicada no Diário Oficial da União nº 52, de 16 de março de 2018, seção 1, página 99.  
FRANCISCO DE ASSIS FIGUEIREDO  
DENIZAR VIANNA  
ANEXO

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
O diabete melito (DM) é uma doença endócrino-metabólica de etiologia heterogênea, que envolve fatores genéticos, biológicos e ambientais, caracterizada por hiperglicemia crônica resultante de defeitos na secreção ou na ação da insulina. Essa doença pode evoluir com complicações agudas (hipoglicemia, cetoacidose e síndrome hiperosmolar hiperglicêmica não cetótica) e crônicas - microvasculares (retinopatia, nefropatia, neuropatia) e macrovasculares (doença arterial coronariana, doença arterial periférica e doença cerebrovascular)<sup>1</sup> .  
O DM do tipo 1 (DM1) caracteriza-se pela destruição das células beta pancreáticas, determinando deficiência na secreção de insulina, o que torna essencial o uso desse hormônio como tratamento, para prevenir cetoacidose, coma, eventos micro- e macrovasculares e morte. A destruição das células beta é, geralmente, causada por processo autoimune, o qual pode ser detectado pela presença de autoanticorpos circulantes no sangue periférico (anti-ilhotas ou anti-ICA, anti-insulina ou IAA, antidescarboxilase do ácido glutâmico ou anti-GAD, e antitirosina fosfatase ou anti-IA2, entre outros), caracterizando o DM1A ou autoimune. Em menor proporção, a causa é desconhecida e classificada como DM1B ou idiopático. A destruição das células beta, geralmente, é rapidamente progressiva<sup>2</sup> .  
O pico de incidência do DM1 ocorre em crianças e adolescentes, entre 10 e 14 anos, e, menos comumente, em adultos de qualquer idade<sup>2</sup> ; no entanto, o diagnóstico em pessoas adultas com DM1 também é recorrente<sup>3</sup> . Adultos que apresentam destruição das células beta pancreáticas devido a processo autoimune têm o diagnóstico de diabete melito autoimune do adulto ( _Latent Autoimmune Diabetes in Adults)_ (LADA). O DM1 tipo LADA pode ter desenvolvimento lento e progressivo de acordo com a deficiência de insulina, causando dificuldades para o diagnóstico e tratamento. De maneira inadequada, o tratamento desses pacientes frequentemente é realizado com antidiabéticos orais até que seja constatada a deficiência secreção de insulina e a sua progressão, impondo a necessidade de insulinoterapia<sup>2</sup> .  
Em 2015, o DM atingia 8,8% da população adulta mundial com 20 a 79 anos<sup>4</sup> ; para 2040, a estimativa é que atingirá 13,6% da população mundial nessa faixa etária<sup>5</sup> . Atualmente, cerca de 75% dos casos de DM ocorrem em países em desenvolvimento, e a maior parte do aumento estimado deverá ocorrer nestes países<sup>5</sup> . No Brasil, dados da Pesquisa Nacional de Saúde do IBGE de 2013 mostraram uma prevalência de DM por auto-relato de 6,2%. A taxa chega a 9,6% entre indivíduos sem instrução ou com ensino fundamental incompleto. A maior parte desses dados não identifica se o indivíduo tem DM1 ou DM tipo 2 (DM2), mas sabe-se que aproximadamente 90% dos diabéticos correspondem a pessoas com DM2<sup>1</sup> . A variação global na incidência de DM1 é alta e, no Brasil, estima-se que ocorram 25,6 casos por 100.000 habitantes por ano, o que é considerado uma incidência elevada<sup>6</sup> . Alguns estudos abordam a ocorrência da DM1 na população negra entre a qual a prevalência parece ser significativamente menor do que entre brancos, ao contrário da DM2 que acomete com maior frequência pessoas negras<sup>7,8</sup> .  
Um estudo multicêntrico realizado pelo Grupo Brasileiro de Estudos sobre a DM 1 analisou dados demográficos, clínicos e socioeconômicos de pacientes com DM1 sob tratamento em centros públicos do Brasil e mostrou que o controle glicêmico foi insatisfatório [hemoglobina glicada (HbA1c) acima de 7%] em aproximadamente 80% dos pacientes, apesar de todos, neste estudo, estarem em tratamento com endocrinologistas em serviços de atendimento secundário ou terciário<sup>9.</sup>  
Algumas doenças autoimunes são frequentemente encontradas em pacientes com DM1. As principais são doenças da tireoide e doença celíaca, com prevalência de 17% a 30% e de 1,6% a 16,4%, respectivamente. Outras condições autoimunes, como insuficiência adrenal primária, hepatite autoimune, gastrite autoimune, dermatomiosite e misatenia grave, embora menos frequentes, também têm uma ocorrência maior em pacientes com DM1 do que na população geral<sup>2</sup> .  
A educação ao paciente com DM1 e a sua família é essencial para que seja atingido um bom controle dos índices glicêmicos e para que sejam evitadas complicações decorrentes da doença. O tratamento não medicamentoso é essencial no tratamento de DM1 e deve incluir olhar holisticamente o paciente, considerando o contexto familiar em que ele se insere<sup>10,5</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à atenção primária um caráter essencial para um melhor resultado terapêutico e prognóstico.  
Este Protocolo visa a orientar profissionais da atenção primária à saúde, médicos especialistas, pacientes, cuidadores e familiares quanto ao diagnóstico, tratamento e monitoramento de diabete melito do tipo 1 no Sistema Único de Saúde (SUS). A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 6** .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
E10.0 Diabete melito insulino-dependente - com coma  
E10.1 Diabete melito insulino-dependente - com cetoacidose  
E10.2 Diabete melito insulino-dependente - com complicações renais  
E10.3 Diabete melito insulino-dependente - com complicações oftálmicas  
E10.4 Diabete melito insulino-dependente - com complicações neurológicas  
E10.5 Diabete melito insulino-dependente - com complicações circulatórias periféricas  
E10.6 Diabete melito insulino-dependente - com outras complicações especificadas  
E10.7 Diabete melito insulino-dependente - com complicações múltiplas  
E10.8 Diabete melito insulino-dependente - com complicações não especificadas  
E10.9 Diabete melito insulino-dependente - sem complicações

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
O diagnóstico de DM1 é geralmente realizado em pacientes jovens (crianças, adolescentes e mesmo adultos jovens) com sinais e sintomas de hiperglicemia grave (poliúria, polidipsia, polifagia, noctúria e perda de peso inexplicada). Esses pacientes podem evoluir rapidamente com cetose, desidratação e acidose metabólica, caracterizando a Cetoacidose Diabética (CAD), complicação do DM que pode cursar com náusea, vômitos, sonolência, torpor e coma e que pode levar ao óbito. A CAD ocorre especialmente na presença de estresse agudo<sup>2,5</sup> .  
A confirmação do diagnóstico de DM1 é feita pela comprovação laboratorial da hiperglicemia, que, na maioria das vezes, é feita com uma glicemia aleatória (ao acaso, sem necessidade de jejum) maior do que 200 miligramas por decilitro (mg/dL) e que, na presença de sintomas clássicos de hiperglicemia descritos acima, consolida o diagnóstico<sup>2,5</sup> . A glicemia de jejum, o teste oral de tolerância à glicose (TOTG) com sobrecarga de 75 gramas em 2 horas e a HbA1c também podem ser eventualmente utilizados como diagnóstico em pacientes sem sintoma ou sinal de hiperglicemia. O TOTG é raramente utilizado, pois consiste na mensuração da glicemia após a ingestão de 75g de glicose, o que pode oferecer riscos para pacientes com índices glicêmicos já elevados. Os exames citados confirmam o diabete, desde que realizados em mais de um momento e atentando-se que devem ser repetidos assim que possível. É importante salientar que a hiperglicemia associada ao estresse agudo infeccioso, traumático ou circulatório não deve ser considerada para o diagnóstico de DM, pois muitas vezes é transitória, normalizando-se após a estabilização clínica do quadro básico. Nestes casos, o paciente deve ser reavaliado fora do quadro agudo para se observar se a hiperglicemia persiste<sup>2,5</sup> .  
Diante de glicose plasmática em jejum de pelo menos oito horas maior ou igual a 126 mg/dL em duas ocasiões, com curto intervalo de tempo (por exemplo, uma a duas semanas), dá-se o diagnóstico de DM<sup>2,5</sup> . ( **Figura 1** )  
O diagnóstico de DM também pode ser feito com HbA1c maior ou igual a 6,5%. Na ausência de hiperglicemia inequívoca, os exames antes descritos devem ser repetidos para confirmar a presença de DM. O uso da HbA1c para fins diagnósticos deve ser restrito a situações em que o método utilizado pelo laboratório seja certificado pelo _National Glycohemoglobin Standardization Program_<sup>2,5</sup> .  
O diagnóstico de DM1 pode ocorrer em qualquer idade; entretanto o diagnóstico na fase adulta requer atenção, pois, enquanto a maior parte dos diagnósticos de diabete na infância e adolescência é do tipo 1, na fase adulta, costuma ser do tipo 2. Alguns pacientes com diagnóstico inicial de diabete tipo 2 com base na idade avançada, rapidamente têm seu quadro clínico deteriorado e, posteriormente, são classificados corretamente como com diabete tipo 1<sup>3</sup> ; nestes casos, a solicitação de exames de autoanticorpos específicos e peptídeo C são importantes para o correto diagnóstico<sup>11</sup> .  
A maioria dos casos de DM1 (crianças e adultos) se inicia com hiperglicemia significativa e necessidade de insulinoterapia imediata. Quando não tratada, evolui rapidamente para CAD, especialmente na presença de infecções ou de outra forma de estresse.  
Assim, o traço clínico que melhor caracteriza o DM1 é a tendência à hiperglicemia grave e CAD, situações em que não há dúvida de que o tratamento com insulina deve ser iniciado imediatamente<sup>2,5</sup> .  
**Figura 1 –** Critérios diagnósticos de diabete melito tipo 1  
<!-- Start of picture text -->
Sintomas de Glicemia aleatéria > 200mg/dL’:<br>insulinopenia inequivocos<br>(politiria,nocturia polidipsia,e perda depolifagia,peso ow)<br>inexplicada) Glicemia 2 horas apés sobrecarga oral<br>75g de glicose > 200mg/dL?<br>Glicemia de jejum 8h > 126mg/dL*<br>Ocorréncia de<br>cetoacidose prévia<br>HbAIC > 65%"<br><!-- End of picture text -->  
HbA1c: hemoglobina glicada, preferencialmente por método certificado pelo _National Glycohemoglobin Standardization Program._ ¹ paciente com sintomas clássicos de insulinopenia não precisa repetir; ² raramente utilizado;<sup>3</sup> em duas ocasiões. Hiperglicemia associada ao estresse agudo infeccioso, traumático ou circulatório não deve ser considerada diagnóstica de DM, pois muitas vezes é transitória. Portanto, o paciente deve ser reavaliado fora deste contexto agudo para observar se há hiperglicemia persiste.  
Adultos também podem abrir o quadro como de diabete tipo 1 clássico e com CAD. Na suspeita clínica de diabete latente autoimune do adulto – LADA, é necessária a dosagem de peptídeo C acrescida dos resultados da pesquisa e titulação de pelo menos um dos marcadores de autoimunidade (Anti-ICA ou Anticorpo Anti-ilhota de Langerhans, Anti IAA ou Anticorpo AntiIinsulina ou outros disponíveis), que comprovem o diagnóstico. Nos casos em que os pacientes apresentem sintomas típicos, além de dosagem alterada de peptídeo C ou presença de marcadores de autoimunidade, o médico assistente deverá avaliar o caso individualmente.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Serão incluídos neste Protocolo os pacientes com diagnóstico de DM1 conforme definido no item diagnóstico. Para isso, o paciente deverá apresentar sinais de insulinopenia inequívoca acrescidos da demonstração de hiperglicemia:  
- Sinais de insulinopenia inequívoca: sintomas de hiperglicemia importante (glicemia acima de 200 mg/dL necessariamente associada à poliúria, noctúria, polidipsia, polifagia noctúria e perda de peso inexplicada) ou presença de cetoacidose diabética.  
- Demonstração de hiperglicemia para diagnóstico de DM:  
- Glicemia aleatória maior do que 200 mg/dL na presença de sintomas clássicos de hiperglicemia (polidipsia, poliúria,  
noctúria e perda inexplicada de peso) **<u>OU</u>**  
- Glicemia em jejum de 8 horas ≥ 126 mg/dL em duas ocasiões **<u>OU</u>**  
- HbA1c ≥ 6,5% em duas ocasiões **<u>OU</u>**  
- Glicemia de 2 horas pós-sobrecarga ≥ 200 mg/dL.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Para o uso de análogo de insulina de ação rápida, os pacientes deverão apresentar, além dos critérios de inclusão de DM1,  
**todas** as condições descritas em laudo médico:  
- Uso prévio de insulina NPH e insulina Regular por pelo menos **três meses** ;  
● Apresentação, nos **últimos seis meses** , de pelo menos um dos critérios abaixo, após terem sido excluídos fatores causais para as hipoglicemias (redução de alimentação sem redução da dose de insulina, exercício físico sem redução da dose de insulina, revisão dos locais de aplicação de insulina, uso de doses excessivas de insulina, uso excessivo de álcool):  
○ Hipoglicemia grave (definida pela necessidade de atendimento emergencial ou de auxílio de um terceiro para sua resolução) comprovada mediante relatório de atendimento emergencial, registros em _softwares,_ tabelas ou glicosímetros, quando disponíveis;  
○ Hipoglicemias não graves repetidas (definida como dois episódios ou mais por semana) caracterizadas por glicemia capilar < 54mg/dL com ou sem sintomas ou < 70mg/dL acompanhado de sintomas (tremores, sudorese fria, palpitações e sensação de desmaio);  
- Hipoglicemias noturnas repetidas (definidas como mais de um episódio por semana); ou  
- Mau controle persistente, comprovado pela análise laboratorial dos últimos doze meses de acordo com os  
critérios da HbA1c.  
- Realização de automonitorização da glicemia capilar (AMG) no mínimo três vezes ao dia;  
- Acompanhamento regular (mínimo duas vezes ao ano) com médico e equipe multidisciplinar e sempre que possível  
- com endocrinologista.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Para o uso de análogo de insulina de ação prolongada, os pacientes deverão apresentar, além dos critérios de inclusão de DM1, todas as seguintes condições descritas em laudo médico:  
- Uso prévio da insulina NPH associada à insulina análoga de ação rápida por pelo menos **três meses** ;  
- Apresentação, **nos últimos seis meses** , de pelo menos um dos critérios abaixo após terem sido excluídos fatores causais  
para as hipoglicemias (redução de alimentação sem redução da dose de insulina, exercício físico sem redução da dose de insulina, revisão dos locais de aplicação de insulina, uso de doses excessivas de insulina, uso excessivo de álcool):  
- Hipoglicemia grave (definida pela necessidade de atendimento emergencial ou de auxílio de um terceiro para  
- sua resolução) comprovada mediante relatório de atendimento emergencial, registros em _softwares,_ tabelas ou glicosímetros, quando disponíveis;  
- Hipoglicemia não graves repetidas (definida como dois episódios ou mais por semana) caracterizadas por  
- glicemia capilar < 54mg/dL com ou sem sintomas ou < 70mg/dL acompanhado de sintomas (tremores, sudorese fria, palpitações e sensação de desmaio);  
- Hipoglicemias noturnas repetidas (definidas como mais de um episódio por semana);  
- Persistente mau controle, comprovado pela análise laboratorial dos últimos doze meses de acordo com os  
critérios da HbA1c.  
- Acompanhamento regular (mínimo duas vezes ao ano) com médico e equipe multidisciplinar e sempre que possível  
- com endocrinologista;  
- Realização de automonitorização da glicemia capilar (AMG) no mínimo três vezes ao dia.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Para a manutenção do tratamento com a insulina análoga de ação rápida e insulina análoga de ação prolongada, o paciente  
deverá comprovar a manutenção da automonitorização e do acompanhamento regular além de apresentar, nos **últimos seis meses** , pelo menos um dos critérios abaixo, descritos em laudo médico:  
- Atingir as metas de controle glicêmico, conforme o **Quadro 1** . Necessário anexar resultado de HbA1c <mark>do período</mark>  
- <mark>avaliado ou a situação da variabilidade glicêmica</mark> por softwares ou outros métodos, quando disponíveis;  
- Redução mínima de 0,5% no valor da HbA1c;  
- Melhora dos episódios de hipoglicemia, comprovada por meio de registro em glicosímetros ou meios gráficos  
- disponíveis; ou  
- Presença de condições clínicas que possam promover ou contribuir para a glicemia fora das metas, não persistente por  
- mais de seis meses.  
**Quadro 1** - Metas de HbA1c para indivíduos com diabete melito tipo 1.  
||**Crianças e adolescentes**|**Adulto**|**Idoso***|
|---|---|---|---|
|**HbA1c %**|<7,5|< 7,0|entre 7,5 e 8,5|  
*Idosos saudáveis ou com poucas doenças crônicas coexistentes e função cognitiva funcional intacta devem ter objetivos glicêmicos mais baixos (como HbA1c  
<7,5%), enquanto aqueles com múltiplas doenças crônicas coexistentes, comprometimento cognitivo ou dependência funcional deve ter objetivos glicêmicos menos rigorosos (como HbA1c <8,0%-8,5%). HbA1c: hemoglobina glicada. Fonte: ADA, 2019; SBD; 2017-2018.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Serão excluídos deste Protocolo os pacientes que apresentarem pelo menos um dos critérios apresentados abaixo:  
- ❏ Pacientes com diabete melito tipo 2;  
- ❏ Pacientes que não atenderem os critérios de inclusão;  
- ❏ Pacientes com hipersensibilidade à insulina;  
- ❏ Pacientes fora a faixa de idade preconizada em bula;  
- ❏ Para tratamento com análogo de insulina de ação rápida ou prolongada: pacientes que não atenderem aos critérios de manutenção do tratamento.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Para serem incluídos neste Protocolo, os pacientes com diagnóstico de DM1 que já fazem uso de insulina análoga deverão cumprir os critérios de manutenção de tratamento.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Na suspeita clínica de diabetes latente autoimune do adulto, para o tratamento com insulina análoga de ação rápida ou prolongada, os pacientes deverão apresentar, além dos critérios de inclusão deste Protocolo, os seguintes exames: dosagem de peptídeo C, acrescida dos resultados da pesquisa e titulação de pelo menos um dos marcadores de autoimunidade (ICA ou Anticorpo Anti-Ilhota de Langerhans, IAA ou Anticorpo Anti-Insulina ou outros disponíveis). Fica a critério do médico assistente as situações em que os pacientes apresentem sintomas de insulinopenia e positividade para dosagem de peptídeo C ou a presença de um dos autoanticorpos relacionados com diabete.  
Os seguintes exames constam no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP):  
02.02.06.028-4 - Dosagem de peptideo C;  
02.02.03.051-2 - Pesquisa de anticorpos antiilhota de Langerhans;  
02.02.03.052-0 - Pesquisa de anticorpos antiinsulina.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
O aconselhamento pré-concepcional deve ser incorporado aos cuidados rotineiros do diabete, em todas as mulheres com potencial reprodutivo. O planejamento da gravidez deve ser discutido e a contracepção eficaz deve ser prescrita e usada até que a mulher esteja preparada e pronta para engravidar. Durante o aconselhamento, deve-se abordar a importância do controle glicêmico para reduzir o risco de anomalias congênitas, pré-eclâmpsia, macrossomia e outras complicações como retinopatia diabética<sup>12</sup> .  
Em geral, deve-se proceder ao controle intensificado da glicemia e monitoramento rigoroso em mulheres grávidas com diabete e naquelas com intenção de engravidar<sup>13</sup> . A automonitorização de glicose no sangue deve ser feita em jejum e após as refeições<sup>12</sup> . Portanto, é indispensável que as gestantes recebam monitor de glicemia capilar e fitas reagentes para a realização de pelo menos três a quatro testes glicêmicos por dia<sup>2</sup> .  
O controle glicêmico durante a gravidez é considerado ótimo quando os valores de glicemia pré-prandial ou em jejum são mantidos entre 65 e 95 mg/dL (até 99 mg/dL em mulheres com risco de hipoglicemia), com um pico pós-prandial 1 hora após as refeições até 140 mg/dL e 2 horas após as refeições até 120 mg/dL. No entanto, em mulheres com histórico de hipoglicemia, deve-se estabelecer metas menos rigorosas baseadas na experiência clínica e na individualização do cuidado<sup>5,12.</sup>  
O tratamento indicado é a manutenção do esquema _basal-bolus_ com múltiplas doses de insulina visando-se a obter o melhor controle metabólico possível antes da concepção (HbA1c < 6,5%) e mantendo-o durante toda a gestação. Gestantes com diabetes prévio devem realizar glicemias pré-prandiais e pós-prandiais para obterem controle glicêmico adequado. As glicemias pré-prandiais são recomendadas para as gestantes com DM1 prévio para ajuste na dose de insulina análoga de ação rápida. A monitorização das glicemias pós-prandiais está associada com controle glicêmico melhor e menor risco de pré-eclâmpsia<sup>5,10</sup> .  
No início do primeiro trimestre da gravidez, há um aumento da necessidade de insulina, seguido por uma diminuição da 9ª até à 16ª semanas, período em que pode ocorrer um aumento de episódios de hipoglicemia. Após a 16ª semana, o aumento rápido da resistência à insulina requer aumentos semanais de dose (cerca de 5% por semana) para alcançar os alvos glicêmicos estabelecidos. Há aproximadamente o dobro de necessidades de insulina no final do terceiro trimestre. Em geral, uma proporção  
menor da dose diária total deve ser dada como insulina basal (< 50%) e uma proporção maior (>50%) como insulina prandial. No final da gravidez, muitas vezes há um nivelamento ou uma pequena diminuição da necessidade de insulina<sup>12</sup> .  
Os análogos de insulina asparte, glargina e detemir comparados às insulinas humanas mostraram segurança quanto aos desfechos maternos e fetais em estudos meta-analisados que avaliaram ensaios clínicos e estudos observacionais em DM 1, DM 2 e DM gestacional. A lispro, no entanto, associou-se a maior peso ao nascimento e maior incidência de recém-nascidos grandes para a idade gestacional<sup>14</sup> .  
As informações constantes em bula indicam que os análogos de insulina de ação rápida asparte (categoria A) pode ser usada na gestação, enquanto que a lispro (categoria B) pode ser usada com cautela e a glulisina deve ser evitada (categoria C)<sup>13</sup> . Quanto aos análogos de ação prolongada, o tratamento com detemir (categoria B) pode ser considerado durante a gravidez. A glargina (categoria C) não conta com estudo clínico controlado envolvendo mulheres grávidas. Estudos com animais, com doses de até 6 a 40 vezes a dose humana, não indicam efeitos prejudiciais diretos na gravidez. A degludeca também não conta com experiência clínica em mulheres grávidas; contudo, estudos de reprodução animal não revelaram quaisquer diferenças entre a degludeca e a insulina humana em relação à embriotoxicidade e teratogenicidade<sup>13</sup> . Portanto, esses medicamentos não devem ser utilizados por mulheres grávidas sem orientação médica.  
No tratamento das gestantes com DM1, o médico assistente deverá avaliar em quais situações os benefícios superam os riscos e informar também por meio de relatório médico a necessidade do ajuste de dose.  
O acompanhamento deve ser realizado preferencialmente por equipe especializada.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
O período imediato que segue o parto é tradicionalmente caracterizado pela necessidade menor de insulina em lactantes com DM1, bem como por aumento da demanda de glicose para prevenção de hipoglicemia materna. Em geral, nesse período a necessidade de insulina materna se reduzirá em 60% relativamente à dose total diária usada durante a gestação<sup>15</sup> .  
Os recém-nascidos de mães com DM1 (lactentes) têm maior risco de hipoglicemia, distúrbios respiratórios e icterícia no período de pós-parto imediato, especialmente se o controle glicêmico materno não for otimizado. A hipoglicemia neonatal pode ser minimizada por meio de alimentação frequente do lactente (a cada três horas)<sup>15</sup> .  
O aleitamento materno deve ser encorajado. Nas mulheres que amamentam poderá haver necessidade de redução da dose de insulina em mais aproximadamente 10% em relação à dose diária prévia à gestação<sup>15</sup> . Uma vez que a glicemia materna pode variar muito neste período, faz-se necessária uma monitorização mais frequente da glicemia capilar e correções de doses de insulina e de alimentação antes e após a amamentação. Não foram encontrados estudos randomizados que avaliassem qual a melhor forma para estes ajustes ou se há tipo preferencial de insulina, devendo-se individualizar os casos.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
O tratamento do paciente com DM1 inclui cinco componentes principais: educação sobre diabete, insulinoterapia, automonitorização glicêmica, orientação nutricional e prática monitorada de exercício físico<sup>10</sup> . É um tratamento complexo em sua prescrição e execução e exige a participação intensiva do paciente, que precisa ser capacitado para tal. O fluxograma terapêutico deverá ocorrer da seguinte forma: Insulina NPH associada à insulina regular; insulina NPH associada à insulina análoga de ação rápida e insulina análoga de ação rápida associada à insulina análoga de ação prolongada ( **Apêndice 1** ).  
A educação dos pacientes e seus familiares para o autocuidado envolve processos de educação sobre alimentação saudável, contagem de carboidratos, prática de exercícios físicos, identificação e tratamento da hipoglicemia, administração de insulina, insulinoterapia intensiva e AMG e a detecção de complicações. Os objetivos de controle glicêmico devem ser  
determinados individualmente, de acordo com a idade do paciente e a capacidade de identificar e tratar hipoglicemias ( **Tabela 1** ).  
**Tabela 1 -** Objetivos glicêmicos para pessoas com diabete melito tipo 1  
|**Parâmetros**|**Crianças e Adolescentes**|**Adultos**|**Gestantes**|
|---|---|---|---|
|Glicemia pré-prandial (mg/dL)|70 a 145|70 a 130|< 90|
|Glicemia pós-prandial (mg/dL)|90 a 180|< 180|1ª hora < 140|
||||2ª hora < 120|
|Glicemia ao deitar (mg/dL)|120 a 180|-|-|
|Glicemia na madrugada (mg/dL)|80 a 162|-|-|
|HbA1c (%)|< 7,5|< 7,0|< 6,0|  
**Fonte** : SBD, 2017-2018<sup>5</sup> .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
A adesão ao tratamento é um fator fundamental para o sucesso do tratamento das pessoas com diabete; assim, recomendase reforçar esse aspecto em conjunto com a sua família e identificar possíveis barreiras que impedem a adesão<sup>16,5</sup> . O controle adequado da doença está relacionado a diversos fatores e inclui o entendimento da família acerca do DM1<sup>17</sup> . A adolescência é um estágio da vida que requer especial atenção, e <mark>demandas internas e externas, decorrentes das mudanças físicas, sociais e psíquicas podem levar à diminuição da adesão ao</mark> tratamento<sup>18</sup> . Estudos têm apontado que a adesão à terapia em adolescentes com DM1 é um problema desafiador que requer uma atenção multidisciplinar<sup>19,20</sup> .  Paciente com transtornos mentais, como depressão e ansiedade, apresentam pior controle glicêmico<sup>21</sup> .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
As intervenções não medicamentosas são indispensáveis para um controle glicêmico adequado e referem-se à educação sobre diabete e estímulo ao autocuidado, orientação nutricional e cessação do tabagismo<sup>22</sup> . Idealmente, o cuidado não médico do paciente com DM deve ser provido também por vários profissionais da área da saúde, incluindo enfermeiro, farmacêutico, nutricionista, psicólogo, cirurgião dentista, assistente social, educador físico e profissionais da área da educação<sup>5,10</sup> .  
Os esforços da equipe devem ser focados na perspectiva do paciente, conhecendo a sua rotina e entendendo as suas respostas glicêmicas. Os pacientes devem adquirir conhecimentos e instituir hábitos em relação aos objetivos glicêmicos, automonitorização glicêmica, administração de insulina, identificação e tratamento de hipoglicemias, ajuste de doses de insulinas de acordo com o nível glicêmico, contagem de carboidratos e quantidade de carboidratos da refeição. O programa educacional precisa ser compatível com o nível de desenvolvimento cognitivo e adaptado à capacidade intelectual da criança, adolescente e dos familiares. Recomenda-se que os pais estejam completamente envolvidos no processo de educação e autogerenciamento do DM, e que a transição da responsabilidade sobre os cuidados com a doença seja realizada de maneira gradual e flexível, no momento apropriado e sob a supervisão de profissionais com experiência em educação em DM<sup>5,10</sup> .  
As recomendações nutricionais para uma alimentação saudável para a população geral são aplicáveis aos pacientes com DM1. A diferença consiste no fato de que as refeições devem estar relacionadas com a insulinoterapia e a prática de exercícios físicos, com o objetivo de atingir os alvos glicêmicos pré-determinados. O Guia Alimentar para a População Brasileira do Ministério da Saúde<sup>23</sup> , aborda os princípios e as recomendações de uma alimentação adequada e saudável, considerando os múltiplos determinantes das práticas alimentares, ou seja, as diferenças regionais no que tange à disponibilidade, oferta e cultura alimentares. Assim, une-se o cuidado alimentar para o tratamento do diabete. Maiores informações sobre contagem de  
carboidratos e fator de correção (FC) são apresentadas no **Apêndice 3** deste Protocolo e estão disponíveis no Manual de contagem de carboidratos para pessoas com DM da Sociedade Brasileira de Diabetes<sup>24</sup>  
<mark>A atividade física regular sobre a saúde de indivíduos com DM1 está relacionada com melhora no condicionamento físico, na força muscular e na sensibilidade à insulina</mark><sup>25</sup> <mark>. As crianças com DM1, da mesma forma que crianças sem diabete, devem ser encorajadas a realizar, pelo menos, 60 minutos de atividade física todos os dias</mark><sup>10</sup> <mark>.</mark> Os adultos com diagnóstico de diabete devem ser aconselhados a realizar, pelo menos, 150 minutos semanais de atividade física aeróbica no mínimo três vezes por semana, <mark>orientado por profissional capacitado</mark><sup>26</sup> <mark>.</mark>  
Intervenções psicológicas para melhoria da adesão ao tratamento são eficazes para reduzir a HbA1c, embora o efeito verificado tenha sido pequeno<sup>27</sup> , o que pode ser particularmente significativo em crianças e adolescentes<sup>28</sup> .  
<mark>O cuidado odontológico é importante para todas as pacientes com DM, visto que manifestações como a doença periodontal (gengivite e periodontite) podem prejudicar o controle glicêmico. Outras manifestações bucais presentes em pacientes com DM com dificuldade de controle glicêmico são: xerostomia, hipossalivação, cárie dentária, síndrome da ardência bucal, glossodínia, candidíase oral e distúrbios da gustação</mark><sup>1</sup> <mark>.</mark>  
Maior informação sobre o tratamento não medicamentoso recomendado para pessoas com DM pode ser encontrada nos Cadernos de Atenção Básica nº 35 – Estratégias para o Cuidado da Pessoa com Doença Crônica<sup>29</sup> e nº 36 – Estratégias para o Cuidado da Pessoa com Doença Crônica – Diabete melito<sup>30</sup> e nas Diretrizes da Sociedade Brasileira de Diabetes 2017-2018<sup>5</sup> .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Pacientes com DM1 têm deficiência absoluta de insulina endógena, razão por que a insulinoterapia é obrigatória no tratamento<sup>31-34</sup> .  
Estudos nacionais apontaram que pacientes com baixa adesão aos esquemas insulínicos têm pior controle glicêmico, enquanto que indivíduos com maior adesão à dieta têm menos episódios de hipoglicemias e melhor adesão aos esquemas de insulina<sup>35</sup>  
O tratamento intensivo com o uso de esquema basal- _bolus_ com múltiplas doses de insulina NPH humana e insulina regular humana tornou-se o tratamento preconizado para pacientes com DM desde a década de 90. Além do controle dos sintomas de hiperglicemia, esse esquema mostrou-se capaz de reduzir o aparecimento e a progressão das complicações crônicas micro- e macrovasculares do diabete<sup>36-39</sup> .  
O esquema insulínico intensivo acarreta maior risco de hipoglicemias, incluindo hipoglicemias graves. O risco destas hipoglicemias pode ser três vezes maior quando em tratamento intensivo em comparação ao tratamento não intensivo, sendo um relevante fator limitante à eficácia da terapia insulínica intensiva. O ganho de peso também é observado e decorrente do tratamento intensivo<sup>36-39</sup> .  
O esquema de insulinoterapia deve incluir uma insulina basal de ação intermediária ou prolongada (insulina NPH humana ou análoga de ação prolongada) e uma insulina de ação tipo _bolus_ de ação rápida (humana regular ou análoga de ação rápida), com doses fracionadas em pelo menos três aplicações diárias, que devem respeitar a faixa etária, peso do paciente, gasto energético diário incluindo atividade física e dieta e levando-se em consideração possível resistência à ação da insulina e a farmacocinética desses medicamentos ( **Tabela 2** ).  
**Tabela 2 -** Farmacocinética das insulinas NPH, regular e análogas de insulina de ação rápida e prolongada  
|**Insulina**|**Início de ação**|**Pico de ação**|**Duração**|**Posologia**|**Aspecto**|
|---|---|---|---|---|---|
|Lispro|5 – 15 min|30 – 90 min|3 – 4 h|Imediatamente antes das|Cristalino|
|Asparte|5 – 15 min|30 – 90 min|3 – 4 h|refeições ou|Cristalino|
|Glulisina|5 – 15 min|30 – 90 min|3 – 4 h|imediatamente após|Cristalino|
|||||30 minutos antes das||
|Regular|30 – 60 min|2 – 3 h|5 – 8 h|refeições|Cristalino|
|NPH|2 – 4 h|4 – 10 h|10 – 18 h|1-3x/dia (recomendar<br>dose noturna às 22|Turvo (requer<br>homogenização)|
|||||horas)||
|Glargina 100|2  – 4 h|sem pico|20  – 24 h|1x/dia|Cristalino*|
|Detemir|1  – 3 h|6 – 8 h|18  – 22 h|1-2x/dia|Cristalino*|
|Degludeca|21  – 41 min|sem pico|até 42 h|1x/dia|Cristalino*|
|Glargina 300|6 h|sem pico|até  36 h|1x/dia|Cristalino*|  
Todas os análogos de insulina disponíveis no Brasil têm concentração de 100 u/ml, exceto a glargina que além de 100 ui/ml também tem concentração de 300 ui/ml; *As análogas de insulinas de ação prolongada não requerem homogeneização, como a insulina humana NPH.  
_Adaptado de Weinert LS e colaboradores_<sup>_40_</sup> _, SBD,_ 2017- _2018_<sup>_5_</sup> _._  
Cabe ressaltar que o risco de episódios de hipoglicemia constitui relevante barreira na busca do controle glicêmico adequado, tendo em vista que hipoglicemias graves costumam cursar com sintomas neuroglicopênicos e prejuízo do nível de consciência, podendo levar a convulsão e coma<sup>41</sup> , bem como sequelas neurológicas irreversíveis. A ocorrência de hipoglicemias graves pode acarretar em limitação da autonomia do paciente para realização de atividades diárias comuns, como dirigir, e ainda ocasionar significativas limitações laborais.  
De acordo com o perfil farmacocinético, as insulinas podem ser classificadas segundo sua duração de efeito. As principais características dos perfis de ação das preparações são ilustradas na **Figura 2** .  
**Figura 2** - Perfis de ação das diferentes insulinas e análogas de insulinas.  
<!-- Start of picture text -->
lispro, asparte<br>2 glulisina<br>3 regular<br>s NPH<br>=8 ————ZZ ilasaina UBS.SS<br>0 12 24 36 48<br>Horas<br><!-- End of picture text -->  
Fonte: SBD, 2017-2018<sup>5</sup>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
A insulina NPH ( _Neutral Protamine Hagedorn)_ é uma suspensão cristalina de insulina formada pela adição de uma molécula de protamina, que prolonga seu efeito e promove ação intermediária; assim, essas modificações deram origem a insulina com perfil cinético próprio. A insulina NPH não deve ser administrada em monoterapia; o seu uso dá-se em combinação com a insulina regular ou com a insulina análoga monomérica de ação rápida<sup>13, 42</sup> .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
A insulina regular contém como princípio ativo a insulina humana monocomponente, hormônio idêntico àquele produzido pelo pâncreas humano, e não possui modificações em sua molécula. A insulina regular é uma insulina de ação curta utilizada para cobrir ou corrigir oscilações da glicose do período pós-prandial e também hiperglicemias aleatórias. Por ser uma insulina com perfil de segurança conhecido, foi utilizada como comparador em muitos estudos que avaliaram análogos de insulina de ação rápida com eficácia semelhante no controle glicêmico<sup>43-47</sup> .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Este grupo é formado por três representantes: asparte, lispro e glulisina. Todas possuem farmacocinética semelhante, com início de ação em 5-15 minutos, pico de ação em 1-2 horas e duração de 3-4 horas ( **Tabela 2** ). Esta farmacocinética é consequência da redução da capacidade desses análogos de se agregarem no tecido subcutâneo, resultando em comportamento de insulina monomérica<sup>47</sup> .  
Em quatro meta-análises que compararam os análogos de insulinas de ação rápida à insulina regular no tratamento de pessoas com DM 1, os análogos de ação rápida foram associados a uma discreta melhora no controle glicêmico (redução média 0,1% a 0,15% na HbA1c)<sup>43-47</sup> e à redução dos episódios de hipoglicemia grave e noturna, ainda que para este último desfecho tenha sido observada uma alta heterogeneidade nos resultados dos estudos<sup>43-47</sup> .  
Não foram encontrados estudos de longo prazo ou que avaliassem desfechos ditos primordiais para análogos de insulina de ação rápida comparativamente à insulina regular, demonstrando-se uma escassez de informações quanto à segurança em longo prazo das primeiras. No entanto, foi discutida a relevância de alguns desfechos como o controle glicêmico pós-prandial e o fato de que o resultado de HbA1c refere-se a uma média, sem distinção dos possíveis extremos aos quais os pacientes estão sujeitos.  
Adicionalmente, foi conduzida uma busca na literatura para identificar evidências sobre a comparabilidade dos análogos de insulinas de ação rápida. Uma coorte retrospectiva que avaliou o uso das insulinas asparte e lispro identificou que não houve diferenças estatisticamente significativas nas chances de se ter um evento hipoglicêmico, complicações ou diminuição da HbA1c entre qualquer das comparações<sup>48-50</sup> .  
Recente revisão sistemática, realizada pela Sociedade Brasileira de Diabetes, comparou os análogos de insulina de ação rápida com a insulina humana regular. Os objetivos primários foram glicemia pós-prandial e frequência de hipoglicemias (total, noturnas e graves). Os autores concluem que os análogos de insulina de ação rápida foram superiores à insulina humana regular nos seguintes desfechos: episódios de hipoglicemia (-7%), hipoglicemia noturna (-45%), hipoglicemia grave (-32%), glicemia pós-prandial (-19,44 mg/dL) e HbA1c (-0,13%)<sup>51</sup> .  
Com relação à potencial imunogenicidade de análogos de insulina de ação rápida, foi identificado um estudo que avaliou a medida dos anticorpos com anti-insulina (AI) quando foram utilizadas as insulinas regular humana, insulina NPH e os análogos de insulina de ação rápida (lispro ou asparte) de três fabricantes diferentes. Os resultados não diferiram em relação à imunogenicidade. Os análogos de insulina de ação rápida não aumentaram os níveis de AI em pacientes tratados anteriormente apenas com insulina humana.  
Os pacientes que usaram preparações de insulina de diferentes marcas não diferiram em relação à dose diária de insulina ou HbA1c<sup>52</sup> . Assim, não há evidências que impossibilitem a transição do paciente pelo uso de um dos análogos de insulina de  
ação rápida (lispro, asparte e glulisina) identificada nos estudos relatados. Deve-se optar pela prescrição da insulina análoga de ação rápida com melhor resultado de custo-minimização a ser disponibilizada pelo Ministério da Saúde (MS). Informações acerca da distribuição, dispensação da insulina análoga de ação rápida e orientações aos profissionais de saúde serão divulgadas por esse Ministério periodicamente, conforme cada período aquisitivo.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
As análogas de insulina de ação prolongada possuem quatro representantes: glargina U100, detemir, degludeca e glargina U300. Cada insulina análoga é formada por sequência de aminoácidos semelhante à insulina humana, diferindo apenas pela troca de alguns desses aminoácidos. As modificações nas sequências de aminoácidos proporcionam diferentes padrões de solubilidade aos fármacos e, consequentemente, perfis de absorção diferenciados.  
A glargina 100U/mL apresenta duração de ação de aproximadamente 24 horas, indicada para pacientes a partir de dois anos de idade, sem picos, permitindo administração uma vez por dia para a maioria dos pacientes com DM1<sup>13</sup> .  
A glargina 300U/mL, apresenta efeito maior em relação à glargina 100U/mL (até 36 horas)<sup>53</sup> É um medicamento indicado para pacientes a partir de seis anos de idade, que necessitam de insulina basal (longa duração) para o controle da hiperglicemia. É administrada uma vez ao dia<sup>13</sup> .  
A detemir<sup>13</sup> liga-se de forma reversível à albumina, resultando em absorção lenta, sem picos expressivos, com duração de ação entre 18 e 22 horas, e é indicada para pacientes a partir de 1 ano de idade.  
A degludeca, permanece em depósito solúvel no tecido subcutâneo, sendo lenta e continuamente absorvida na circulação, resultando em ausência de picos, baixa variabilidade dos níveis insulinêmicos e duração de ação de até 42 horas, e é indicada para pacientes a partir de 1 ano de idade permitindo aplicação diária sem horário específico, desde que com mais de 8h de intervalo após a última aplicação<sup>13,54</sup> .  
Diversos estudos clínicos compararam as eficácia e segurança dos análogos de insulina de ação prolongada entre si. Para a comparação de insulina glargina _versus_ detemir, foram consideradas três revisões sistemáticas, nas quais não foi demonstrada diferença estatisticamente significante na redução dos níveis de HbA1c. Adicionalmente, estudo demonstrou não haver diferenças significativas ou clinicamente relevantes na taxa de hipoglicemia grave entre as insulinas glargina e detemir<sup>55</sup> . Cinco estudos clínicos randomizados incluídos em outra  revisão<sup>56</sup> não relataram mortes em ambos os braços, quando comparadas detemir uma vez por dia e glargina uma vez por dia.  
No tocante à avaliação de insulina glargina U100/mL _versus_ degludeca, foram incluídas três revisões sistemáticas que demonstraram não haver diferença estatisticamente significante entre as insulinas na redução dos níveis de HbA1c. Dois estudos 57 55 não encontraram diferenças clinicamente relevantes na taxa de hipoglicemia grave entre as insulinas glargina e degludeca. Estudos<sup>57,58</sup> demonstraram que a degludeca está associada a uma menor taxa de episódios hipoglicêmicos noturnos. Embora a taxa de eventos adversos graves tenha sido menor para insulina degludeca do que para glargina, não houve diferença entre as insulinas em relação ao risco de mortalidade total e de eventos cardiovasculares graves. Por fim, na comparação de insulina detemir _versus_ degludeca apenas Dawoud et al. (2018)<sup>55</sup> demonstraram que não houve nenhuma diferença estatisticamente significante entre as insulinas em relação à redução dos níveis de HbA1c e nas taxas de episódios de hipoglicemia gra <mark>ve.</mark>  
Em suma, os análogos de insulina de ação prolongada demonstram benefício clínico modesto, sendo o seu efeito mais proeminente para o controle da hipoglicemia grave e noturna. Seu uso como esquema basal de insulina para DM1 parece beneficiar mais os pacientes que apresentam episódios recorrentes de hipoglicemia.  
Deve-se optar pela prescrição da insulina análoga de ação prolongada (elegível para uso adulto e pediátrico) com melhor resultado de custo-minimização a ser disponibilizada pelo Ministério da Saúde. Informações acerca da distribuição, dispensação da insulina análoga de ação prolongada e orientações aos profissionais da saúde serão divulgadas por esse Ministério periodicamente, conforme cada período aquisitivo.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
A via de administração usual das insulinas é a subcutânea (SC). A aplicação SC pode ser realizada nos braços, abdômen, coxas e nádegas. A velocidade de absorção varia conforme o local de aplicação, sendo mais rápida no abdômen, intermediária nos braços e mais lenta nas coxas e nádegas. Há variações da cinética da insulina se injetada em segmentos envolvidos na prática de atividades ou de exercícios, como por exemplo, nos membros superiores e inferiores<sup>2</sup> .  
A insulina regular deve ser injetada 30 minutos antes das refeições; a insulina análoga de ação rápida deve ser injetada cinco a 15 minutos antes das refeições ou imediatamente após; a insulina análoga de ação prolongada, de uma forma geral, pode ser administrada uma vez ao dia, sempre no mesmo horário, ou conforme as especificidades de cada medicamento<sup>2</sup> .  
Para correção da hiperglicemia de jejum ou da pré-prandial, escolhe-se uma insulina basal (intermediária) ou insulina análoga de ação prolongada, enquanto que para tratamento da hiperglicemia associada às refeições (pós-prandial) seleciona-se uma insulina de ação rápida ou insulina análoga de ação rápida<sup>2</sup> .  
A insulina regular também pode ser aplicada por vias intravenosa (IV) e intramuscular (IM), em situações que requerem efeito clínico imediato, dessa forma requer cautela e profissional com conhecimento específico para administrar o uso.  
Maior informação sobre técnicas de aplicação de insulina pode ser encontrada no **Apêndice 2** deste Protocolo e estão disponíveis no Caderno de Atenção Básica nº 36 (Estratégias para o Cuidado da Pessoa com Doença Crônica – Diabete melito)<sup>30</sup> e nas Diretrizes da Sociedade Brasileira de Diabetes<sup>5</sup> .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
As insulinas são administradas por meio de seringas graduadas em unidades internacionais (UI) ou canetas de aplicação. Ambas são apresentadas em vários modelos, sendo que alguns permitem até mesmo o uso de doses de 0,5 unidade de insulina. Assim como as seringas, as canetas podem ser usadas com agulhas de diferentes comprimentos. Agulhas de 4 milímetros e com camada de silicone torna a aplicação menos dolorosa, podendo facilitar a adesão do paciente ao tratamento. A escolha da agulha e das técnicas de aplicação desses medicamentos pela caneta segue, em geral, as mesmas orientações da aplicação de insulina por meio de seringas<sup>29,30,58,59</sup>  
As seringas são os dispositivos mais utilizados no Brasil e possuem escala graduada em unidades adequadas à concentração da insulina U-100, disponível no Brasil. As seringas para insulina com agulha fixa, sem dispositivo de segurança, estão disponíveis em três apresentações: capacidade para 30, 50 e 100 UI. A seringa com capacidade para 100 UI é graduada de duas em duas unidades, para 30 e 50 UI a escala é de uma em uma unidade e seringas para 30 UI com escala de meia em meia unidade. É importante ressaltar que essas duas últimas (de 30 e 50 UI) permitem a administração de doses ímpares. Para os profissionais da saúde, que devem usar seringa de insulina com agulha fixa e dispositivo de segurança para realizar aplicação, estão disponíveis seringas com capacidade para 50 e 100 UI<sup>29,30,58,59</sup> .  
A caneta de aplicação de insulina tem se tornado uma opção popular nos últimos anos. Entre as suas vantagens em relação à seringa, estão a praticidade no manuseio e transporte, além da opção de uso com agulhas mais curtas e finas. Essas vantagens proporcionam maior aceitação social e melhor adesão ao tratamento, melhorando, consequentemente, o controle glicêmico<sup>29,30,58,59</sup> . Considerando a diversidade de canetas disponíveis no mercado, que podem se diferenciar pela marca, graduação e dose máxima por aplicação, o paciente deve utilizar a técnica de aplicação disponibilizada pelo fabricante.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Os sistemas de infusão contínua de insulina (SICI) são conhecidos como bomba de insulinas e constituem dispositivos mecânicos com comando eletrônico que injetam insulina de forma contínua, a partir de um reservatório, para um cateter inserido no subcutâneo, geralmente na parede abdominal (região periumbilical), nádegas ou, ocasionalmente, coxas. Estes aparelhos  
simulam a fisiologia normal, com liberação contínua de insulina (basal) e por meio de aplicações em pulso ( _bolus_ ) nos horários de refeições ou para correções de hiperglicemia<sup>58</sup> .  
O uso de SICI não substitui o cuidado do paciente no controle da alimentação e monitorização da glicemia, além de requerer outros dispositivos para manutenção do tratamento e cuidado do paciente como o uso de cateteres.  
A Portaria nº 38/SCTIE/MS, de 11 de setembro de 2018, tornou pública a decisão de não incorporar o sistema de infusão contínua de insulina para tratamento de segunda linha de pacientes com diabete melito tipo 1, no âmbito do Sistema Único de Saúde – SUS. O relatório da CONITEC que tratou do Assunto (relatório de n° 375 setembro de 2018, está disponível em: http://conitec.gov.br/images/Relatorios/2018/Relatorio_BombaInfusaoInsulina_DiabetesI.pdf. [Foram realizadas buscas na literatura, considerando todas as bombas de insulina disponíveis no mercado e não apenas a marca do demandante. Foram selecionados quatro estudos, dois deles apresentaram qualidade alta, um estudo de qualidade moderada e outro de baixa qualidade, conforme a ferramenta AMSTAR. Os desfechos avaliados foram os níveis de hemoglobina A glicosilada (HbA1c) e episódios de hipoglicemia. A redução dos níveis de HbA1c nos estudos selecionados variou de 0,18% a 0,55%. No entanto, este valor não é considerado clinicamente significante. Os eventos de hipoglicemia leve, grave e noturna não demonstraram diferenças significativas entre os grupos em uso do SICI e MDI, em crianças e adultos com DM1. Não foram identificadas evidências suficientes em relação a eventos adversos, complicações tardias do diabetes e mortalidade.]

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
- Insulina NPH 100U/mL suspensão injetável;  
- Insulina regular 100U/mL solução injetável;  
- Insulina análoga de ação rápida 100U/mL solução injetável;  
- Insulina análoga de ação prolongada 100U/ml solução injetável; e  
- Insulina análoga de ação prolongada 300U/mL solução injetável.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Em geral, a dose total diária de insulina para indivíduos com DM1 com diagnóstico recente ou logo após episódio de cetoacidose diabética varia de 0,5 a 1 unidade por quilograma por dia (UI/kg/dia)<sup>10,5,60</sup> . Esta dose depende da idade, peso corporal, estágio puberal, tempo de duração da doença, estado do local de aplicação de insulina, do número e da regularidade das refeições, do automonitoramento, da HbA1c pretendida, do tipo, frequência e intensidade das atividades físicas e das intercorrências (infecções e dias de doença)<sup>61</sup> .  
Durante a fase de remissão parcial (lua de mel), a dose diária total de insulina administrada é geralmente <0,5 UI/kg/dia<sup>62</sup> e posteriormente, com a evolução da doença, a necessidade diária de insulina aumenta para 0,7 a 1 UI/kg/dia em crianças prépúberes, podendo alcançar 1 a 2 UI/kg/dia durante a puberdade ou, em situações de estresse (físico ou emocional), indo até 1,2 a 1,5 UI/kg/dia, situações reconhecidas como de resistência à ação da insulina ( **Quadro 2** )<sup>60,6263</sup> .  
A dose da insulina basal diária deve variar de 40% a 60% da dose total de insulina utilizada na tentativa de mimetizar a secreção endógena de insulina, utilizando para isso a insulina NPH (ação intermediária) em duas a três aplicações diárias ou as insulinas de ação prolongada (uma a duas vezes ao dia). O restante da dose diária recomendada deve ser administrado em forma de _bolus_ (com insulina regular ou insulina análoga de ação rápida) antes das refeições (5 a 15 minutos antes ou imediatamente após para insulina análoga de ação rápida ou 30 minutos antes para insulina regular) com vistas a atingir metas de glicemias prée pós-prandiais<sup>62,64</sup> .  
O ajuste na dose das insulinas pode ser necessário em pacientes que tiveram um aumento de suas atividades físicas, mudaram sua dieta habitual ou durante doenças concomitantes<sup>13</sup> .  
**Quadro 2 -** Dose total diária de insulina e insulina basal recomendada para pessoas com diabete melito tipo 1  
||**Dose total diária de insulina**|**Dose total diária de insulina basal**|
|---|---|---|
|**Pacientes com DM1**|**(UI/Kg/dia)**|**(UI/Kg/dia)**|
|Diagnóstico recente (lua de mel)|< 0,5|< 0,25|
|Após a remissão parcial/adultos|0,7 a 1,0|0,3 a 0,5|
|**Crianças**:|||
|Lactentes|0,2 a 0,4|0,1 a 0,2|
|Pré-púberes|0,5 a 0,8|0,2  0,4|
|Púberes|0,8 a 2,0|0,4 a 1,0|  
Fonte: Adaptado de Tamborlane et al., 2012<sup>63</sup>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
<mark>A dose total diária da insulina basal NPH, deverá corresponder à metade da dose total diária de insulina.</mark> Na **Tabela A** do **Apêndice 3** <mark>estão descritas as doses totais diárias da insulina NPH, de acordo com o grupo etário, que deverá ser administrada duas a três vezes ao dia e eventualmente, quatro vezes ao dia (a maior parte dos pacientes usa três vezes: antes do desjejum, antes do almoço e antes de dormir ou 22h)</mark><sup>65, 66,5</sup> <mark>.</mark>  
<mark>A última dose de NPH do dia deve ser administrada antes de dormir, aproximadamente às 22 horas ou 8 horas antes do despertar do paciente. A utilização de doses de NPH antes do jantar pode provocar pico de ação durante a madrugada, causando hipoglicemias noturnas e concentrações reduzidas de insulina no período do amanhecer quando, geralmente, há piora na ação da insulina</mark><sup>65, 66,5</sup> <mark>. Os pacientes que usam uma ou duas doses elevadas de insulina NPH podem apresentar hipoglicemia, se atrasarem ou omitirem refeições, devido ao pico pronunciado destas doses de NPH.</mark>  
<mark>O ajuste das doses das insulinas basais deve ser de acordo com as glicemias pré-prandiais, glicemias no período do sono e a presença de hipoglicemias entre as refeições e no período de sono. Caso ocorra queda ou elevação da glicemia maior do que 30 mg/dL, no período de sono ou entre as refeições, procede-se à redução ou aumento da última dose de insulina basal em 10% a 20%, respectivamente. Esta excursão glicêmica deve ser observada sem que haja lanches entre as refeições principais, correção de hiperglicemia pós-prandial e lanches e</mark> _<mark>bolus</mark>_ <mark>(prandial e de correção) antes de dormir para avaliação do controle glicêmico noturno. Caso ocorra hipoglicemia, pela omissão dos lanches entre as refeições principais ou por atraso de uma das refeições ou no período noturno, sugere-se redução da última dose de insulina basal administrada antes da hipoglicemia, em 10% a 20%</mark><sup>65,66</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Administra-se a insulina regular 30 minutos antes das refeições principais, em três aplicações diárias. A insulina regular possui limitações quanto ao seu uso como insulina _bolus_ porque deve ser administrada, no mínimo, 30 minutos antes das refeições, dificultando o ajuste de dose de acordo com a ingestão de carboidratos na refeição e a glicemia pré-prandial. Por este motivo, calcula-se uma dose fixa a ser administrada antes das refeições principais. Uma forma de calcular estas doses da insulina regular é utilizar metade da dose total diária de insulina (UI/Kg/dia), distribuídas nas três refeições principais, de acordo com a ingestão de alimentos<sup>62,64</sup> .  
A principal via de aplicação é subcutânea (SC); excepcionalmente, podem ser utilizadas as vias intravenosa (IV) ou intramuscular (IM) para o tratamento de CAD.  Alternativamente, pode ser utilizado um esquema de dose fixa para a refeição associada ao _bolus_ de correção ( **Apêndice 3** ).  
<mark>A dose de insulina em</mark> _<mark>bolus</mark>_ <mark>corresponde à insulina de ação rápida administrada previamente às refeições, para metabolização dos carboidratos ingeridos (</mark> _<mark>bolus</mark>_ <mark>prandial ou da alimentação) e para correção de hiperglicemias (</mark> _<mark>bolus</mark>_ <mark>de correção). A insulina análoga de ação rápida pode ser administrada imediatamente antes ou, em situações de exceção,</mark>  
<mark>imediatamente após as refeições. O ideal é que corresponda a 50% ou mais da dose total diária de insulina e que seja administrada antes das refeições principais, de acordo com a ingestão de carboidratos e níveis glicêmicos. Desta forma, a dose de insulina de ação rápida (</mark> _<mark>bolus</mark>_ <mark>) administrada antes das refeições é composta de duas doses: o</mark> _<mark>bolus</mark>_ <mark>prandial e o</mark> _<mark>bolus</mark>_ <mark>de correção, calculados separadamente, somadas e administrados juntos</mark><sup>5,65-67</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
`o` _Glargina 100 UI/mL solução injetável:_ Administrada uma vez ao dia na maioria dos pacientes, por via subcutânea (SC), em qualquer hora do dia, preferencialmente, no mesmo horário todos os dias. O esquema de doses (dose e intervalos) devem ser ajustados de acordo com a resposta individual.  
`o` _Detemir 100 UI/mL solução injetável_ pode ser administrada uma vez ou duas vezes ao dia. Para pacientes que estão mudando de terapia, a conversão de insulina glargina e insulina NPH em insulina detemir deve ser realizada numa base de unidade para unidade; individualizar a dose com base na resposta clínica; administração subcutânea uma vez por dia com a refeição da noite ou ao deitar; ou dividida em 2 doses iguais administradas com a refeição da noite, ao deitar, ou 12 horas após a dose da manhã; usar insulina de ação rápida ou curta para a necessidade de insulina diária restante; individualizar a dose com base na resposta clínica.  
`o` _Glargina 300 UI/mL solução injetável_ : Administrada uma vez ao dia, por via SC, em qualquer hora do dia, preferencialmente, no mesmo horário todos os dias. A glargina 300 UI/mL deve ser combinada com uma insulina de ação rápida antes das refeições. O esquema de doses (dose e intervalos) deve ser ajustado de acordo com a resposta individual.  
`o` D _egludeca 100 UI/mL solução injetável:_ Administrada a insulina degludeca, por via SC, uma vez ao dia a qualquer hora do dia, preferencialmente no mesmo horário todos os dias. Para DM1, a degludeca deve ser administrada associada com insulina de ação rápida, para cobrir as necessidades de insulina prandial e de correção. A dose de degludeca deve ser ajustada de acordo com as necessidades individuais dos pacientes. É recomendado otimizar o controle glicêmico pelo ajuste de dose de acordo com a glicemia de jejum, entre as refeições e no período de sono.  
<mark>Estabelecer os objetivos glicêmicos é o primeiro passo para iniciar a insulinoterapia intensiva</mark><sup>5,10</sup> . <mark>É importante que os pacientes calculem a sua dose de</mark> _<mark>bolus</mark>_ <mark>de correção de acordo com os objetivos glicêmicos e as glicemias pré-prandiais, e assim sejam envolvidos no gerenciamento do diabetes.</mark>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
O tratamento medicamentoso com insulina não pode ser interrompido para os pacientes com DM1, visto que se pode desencadear um quadro de cetoacidose diabética, coma e morte. Entretanto, o tratamento deve ser revisto e ajustado de acordo com a indicação médica seguindo as orientações deste Protocolo.  
Pacientes em uso de insulina análoga de ação rápida ou prolongada, quando não comprovarem a manutenção do bom controle, avaliados por meio dos critérios de manutenção de tratamento deste Protocolo, devem ter o tratamento interrompido e retornar ao uso da insulina basal. Recomenda-se que estes pacientes tenham a adesão à terapia avaliada e realizadas as intervenções educativas com foco na adesão à terapia. Ressalte-se aqui que, antes da interrupção do tratamento com insulina análoga as medidas para melhorar a adesão devem ser reforçadas e registradas em prontuário do paciente.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
- Melhor controle glicêmico possível.  
- Melhora dos sintomas relacionados à hiperglicemia.  
- Diminuição das complicações agudas e crônicas de DM 1.  
● Diminuição da incidência de episódios de hipoglicemia grave e de episódios de hipoglicemia noturna.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
A monitorização da glicemia pelo paciente (automonitorização da glicemia - AMG) é indicada para todos os pacientes com DM1<sup>10</sup> . Os dados e a frequência da AMG podem ser obtidos por sistemas que realizam o _download_ e a análise das glicemias estocadas no glicosímetro. Em unidades de saúde nas quais não é possível realizar o _download_ dos dados dos glicosímetros, pode ser solicitado aos pacientes o registro das suas glicemias em tabelas e por um período de no mínimo 15 a 30 dias, com a análise dos resultados durante a consulta com profissionais da saúde.  
Os pacientes com DM1 devem realizar a AMG domiciliar para ajustes das doses de insulina e para a avaliação do tratamento. A AMG fornece aos pacientes informações imediatas sobre o controle glicêmico, permitindo a identificação precisa de hipoglicemias e hiperglicemias, aumentando a segurança dos pacientes e prescritores e motivando os pacientes a realizarem as mudanças necessárias na alimentação, atividade física e doses de insulina.  
O controle glicêmico pode ser avaliado por glicemias capilares de jejum e pós-prandiais e pela HbA1c. As glicemias capilares são utilizadas para orientar o ajuste das doses de insulina, uma vez que apontam os momentos no decorrer do dia em que ocorre falta ou excesso de sua ação. A HbA1c é utilizada para avaliar o controle glicêmico em médio e longo prazo, refletindo os últimos três meses de controle glicêmico. Deve-se fazer a medida no início do tratamento e a cada três meses, podendo ser realizada apenas semestralmente para aqueles pacientes com controle ótimo<sup>22</sup> .  
Para os pacientes com DM1, é necessário o acompanhamento médico regular (mínimo duas vezes ao ano), com endocrinologista; na indisponibilidade deste, com um médico clínico com experiência no tratamento de DM.  
<mark>Cabe destacar que a avaliação do controle glicêmico não deve se restringir à HbA1c, pois outros critérios importantes são: a frequência de hipoglicemias, principalmente as noturnas, graves e a variabilidade glicêmica (VG). A VG é um dos parâmetros do controle glicêmico que vem ganhando importância e foi demonstrada associação entre a VG da glicemia de jejum e hipoglicemias, hipoglicemias noturnas e graves</mark><sup>68</sup> <mark>. A adesão à terapia e a melhora do controle glicêmico dependem da utilização de um esquema de insulinoterapia individualizado e que atenda a todos esses parâmetros de controle glicêmico, sem comprometimento da qualidade de vida do paciente</mark><sup>69</sup> <mark>.</mark>  
<mark>Melhor controle metabólico e menor número de hipoglicemias em pacientes com DM1 estão associados com a realização de maior número de testes e ajuste adequado da terapêutica conforme seus resultados. Esta é uma medida que deve ser buscada durante todo o acompanhamento do paciente</mark><sup>70</sup> <mark>. No entanto, seu uso deve ser racional, e a distribuição das tiras reagentes segue as normas de cada local, recomendando-se pelo menos três a quatro testes por dia e aumentando a o fornecimento segundo as necessidades do paciente.</mark>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Os pacientes com DM1 devem manter acompanhamento por toda vida, visto que a doença é crônica e o tratamento será permanente. Este deve ser feito com avaliação clínica e laboratorial, pelo menos duas vezes ao ano, sempre que possível com médico especialista (endocrinologista), e as complicações crônicas devem ser rastreadas anualmente, a partir do 5º ano de duração da doença ou antes, na puberdade ou diante de outra situação a critério clínico. Maior informação acerca das avaliações, exames e periodicidade é apresentada no **Apêndice 4** .  
A retinopatia diabética deve ser rastreada com exame de fundo de olho<sup>71</sup> ; a doença renal  diabética com a determinação da albuminúria, preferencialmente em amostra isolada de urina corrigida pela creatinina e creatinina sérica; e a neuropatia periférica diabética pelo exame neurológico dos pés com pesquisa das sensibilidades térmica, vibratória e protetora, esta última avaliada por meio do monofilamento de Semmes-Weinstein de 10 gramas<sup>72,5,10,73</sup> . É importante que seja realizado rastreamento  
da doença celíaca em pacientes com DM1; aqueles diagnosticados com a doença devem ser acompanhados conforme o Protocolo Clínico e Diretrizes Terapêuticas Doença Celíaca (Portaria SAS/MS nº 1149, de 11 de novembro de 2015). Maiores informações sobre a avaliação de pé diabético são apresentada no **Apêndice 5** .  
Além disso, todos os pacientes com DM1 devem ter a pressão arterial medida ao menos duas vezes por ano, e o perfil lipídico deve ser avaliado ao menos uma vez ao ano. A avaliação das complicações macrovasculares deve ser realizada em todo paciente sintomático<sup>72</sup> . Nos pacientes assintomáticos, a avaliação pode ser feita a partir da estratificação do seu risco cardiovascular de modo individualizado, com a utilização das ferramentas disponíveis para avaliação de risco, segundo as Diretrizes Brasileiras e a indicação de exames laboratoriais dependerá do risco de cada paciente<sup>74</sup> .

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Pacientes com DM1 devem ser atendidos e educados, preferencialmente, em centro de referência por médico especialista (endocrinologista) e equipe de saúde multiprofissional. Esses pacientes devem ser avaliados periodicamente em conjunto com a equipe da atenção primária quanto à adesão ao tratamento, ao conhecimento sobre a doença e o tratamento, à eficácia do tratamento, à necessidade de ajuste de doses das insulinas e ao desenvolvimento de toxicidade aguda ou crônica.  
Devem ser observados os critérios de inclusão, manutenção e exclusão estabelecidos neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas, dispensadas e a adequação de uso dos medicamentos.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Deve-se cientificar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos colaterais relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
1. Melmed S, Polonsky KS, Larsen PR, Kronenberg HM. Williams Textbook of Endocrinology. 13th Edition ed2016.  
2. American Diabetes Association. 2. Classification and Diagnosis of Diabetes. Diabetes Care. 2017;40(Suppl 1):S11-S24. <mark>3. Thomas NJ, Lynam AL, Hill AV, et al., Type 1 diabetes defined by severe insulin deficiency occurs after 30 years of age and is commonly treated as type 2 diabetes. Diabetologia (2019) 62:1167–1172 https://doi.org/10.1007/s00125-0194863-8</mark>  
4. Whiting DR, Guariguata L, Weil C, Shaw J. IDF diabetes atlas: global estimates of the prevalence of diabetes for 2011 and 2030. Diabetes Res Clin Pract. 2011;94(3):311  
5. Diretrizes da Sociedade Brasileira de Diabetes 2017-2018 / Organização José Egídio Paulo de Oliveira, Renan Magalhães Montenegro Junior, Sérgio Vencio. -- São Paulo : Editora Clannad, 2017.  
6. Negrato CA, Lauris JRP, Saggioro IB, Corradini MCM, Borges PR, Crês MC, et al. Increasing incidence of type 1 diabetes between 1986 and 2015 in Bauru, Brazil. Diabetes Res Clin Pract. 2017;127:198-204.  
7. Brasil. Ministério da Saúde. Secretaria de Políticas de Saúde. Manual de doenças mais importantes, por razões étnicas, na população brasileira afro-descendente / Ministério da Saúde, Secretaria de Políticas de Saúde. – Brasília: Ministério da Saúde, 2001. Disponível em: http://bvsms.saude.gov.br/bvs/publicacoes/doencas_etnicas.pdf  
8. Dabelea D, Bell RA, D'Agostino RB Jr, Imperatore G, Johansen JM, Linder B, Liu LL, Loots B, Marcovina S, MayerDavis EJ, Pettitt DJ, Waitzfelder B.al  Incidence of diabetes in youth in the United States. JAMA. 2007 Jun 27;297(24):2716-24.  
9. Gomes MB, Coral M, Cobas RA, Dib SA, Canani LH, Nery M, et al. Prevalence of adults with type 1 diabetes who meet the goals of care in daily clinical practice: a nationwide multicenter study in Brazil. Diabetes Res Clin Pract. 2012;97(1):63-70.  
10. American Diabetes Association –ADA a. Standard of Medical Care in Diabetes 2019: Disponível em: https://care.diabetesjournals.org/content/42/Supplement_1  
11. National Institute for Health and Care Excellence – NICE. Type 2 diabetes in adults: management. Published date: December 2015 Last updated: August 2019. Disponível em: https://www.nice.org.uk/guidance/ng28  
12. American Diabetes Association. Standards of Medical Care in Diabetes – 2018. Disponível em http://care.diabetesjournals.org/content/41/Supplement_1  
13. Bulário ANVISA. Disponível em: https://consultas.anvisa.gov.br/#/bulario/. Acesso em: 21 de junho de 2021.  
14. 14 Wang Lv S, J, Xu Y. Safety of insulin analogs during pregnancy: a meta-analysis. Arch Gynecol Obstet. 2015;292(4):749-56.  
15.  
- Ringholm L. et al. Nat. Rev. Endocrinol. 8, 659–667, 2012  
16. Guía de Práctica Clínica sobre Diabete melito tipo 1. Plan de Calidad para el Sistema Nacional de Salud del Ministerio de Sanidad y Política Social. Agencia de Evaluación de Tecnologías Sanitarias del País Vasco-Osteba; 2012. Guías de Práctica Clínica en el SNS: OSTEBA n.º 2009/10. Disponível em: www.diabetes.org.br  
17. Safyer A W,  Hauser S T,  JacobsonA M,  Bliss R,  HerskowitzR D,  WolfsdorfJ I,  Wertlieb D. The impact of the family on diabetes adjustment: A developmental perspective, Child & Adolescent Social Work Journal, 1993, vol. 10 2(pg. 123140).  
18. Greco-Soares Juliana Prytula, Dell'Aglio Débora Dalbosco. Adesão ao tratamento em adolescentes com diabete melito tipo 1. Psic., Saúde & Doenças  [Internet]. 2017  Ago [citado  2019  Out  21] ;  18( 2): 322-334. Disponível em: http://www.scielo.mec.pt/scielo.php?script=sci_arttext&pid=S1645-  
00862017000200004&lng=pt.  http://dx.doi.org/10.15309/17psd180204.  
19. <mark>Gandhi K, Vu BK, Eshtehardi SS, Wasserman RM, Hilliard ME. Adherence in adolescents with Type 1 diabetes: strategies and considerations for assessment in research and practice.</mark> _<mark>Diabetes Manag (Lond)</mark>_ <mark>. 2015;5(6):485–498. doi:10.2217/dmt.15.41</mark>  
20. <mark>Datye KA, Moore DJ, Russell WE, Jaser SS. A review of adolescent adherence in type 1 diabetes and the untapped potential of diabetes providers to improve outcomes.</mark> _<mark>Curr Diab Rep</mark>_ <mark>. 2015;15(8):51. doi:10.1007/s11892-015-0621-6</mark>  
21. <mark>Whittemore R; Kanner, S, Singleton S, Hamrin V; Chiu J, Grey M. Correlates of depressive symptoms in adolescents with type 1 diabetes. Pediatric Diabetes. 3,3:135-143. 2002.</mark>  
22. American Diabetes Association. 8. Pharmacologic Approaches to Glycemic Treatment. Diabetes Care. 2017;40(Suppl 1):S64-S74. ADA 2017 b  
23. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Guia Alimentar para a População Brasileira. 2ª edição. Brasília; Ministério da Saúde, 2014. Disponível em: http://bvsms.saude.gov.br/bvs/publicacoes/guia_alimentar_populacao_brasileira_2ed.pdf  
24. Manual de contagem de carboidratos. Sociedade Brasileira de diabetes. 2016. Disponível em: http://www.diabetes.org.br/publico/images/manual-de-contagem-de-carboidrato2016.pdf  
25. Colberg SR, Riddell MC. Physical activity: regulation of glucose metabolism, clinical management strategies, and weight control. Alexandria, VA, American Diabetes Association, 2013.  
26. American Diabetes Association. Standards of Medical Care in Diabetes – 2014. Diab Care 2014; 37:S14-S80.  
27. Viana LV, Gomes MB, Zajdenverg L, Pavin EJ, Azevedo MJ, Group BTDS. Interventions to improve patients' compliance with therapies aimed at lowering glycated hemoglobin (HbA1c) in type 1 diabetes: systematic review and meta-analyses of randomized controlled clinical trials of psychological, telecare, and educational interventions. Trials. 2016;17:94.  
28. Winkley K, Ismail K, Landau S, Eisler I. Psychological interventions to improve glycaemic control in patients with type 1 diabetes: systematic review and meta-analysis of randomised controlled trials. BMJ. 2006;333(7558):65.  
29. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Estratégias para o cuidado da pessoa com doença crônica. Caderno de Atenção Básica nº 35. Brasília: Ministério da Saúde, 2014ª. Disponível em: http://bvsms.saude.gov.br/bvs/publicacoes/estrategias_cuidado_pessoa_doenca_cronica_cab35.pdf  
30. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Estratégias para o cuidado da pessoa com doença crônica Diabete melito. Caderno de Atenção Básica nº 36. Brasília: Ministério da Saúde, 2014<sup>b</sup> . Disponível em: http://189.28.128.100/dab/docs/portaldab/publicacoes/caderno_36.pdf  
31. Abdelghaffar S, Attia AM. Metformin added to insulin therapy for type 1 diabete melito in adolescents. Cochrane Database Syst Rev. 2009(1):CD006691.  
32. Guo H, Fang C, Huang Y, Pei Y, Chen L, Hu J. The efficacy and safety of DPP4 inhibitors in patients with type 1 diabetes: A systematic review and meta-analysis. Diabetes Res Clin Pract. 2016;121:184-91.  
33. Liu C, Wu D, Zheng X, Li P, Li L. Efficacy and safety of metformin for patients with type 1 diabete melito: a metaanalysis. Diabetes Technol Ther. 2015;17(2):142-8.  
34. Liu W, Yang XJ. The Effect of Metformin on Adolescents with Type 1 Diabetes: A Systematic Review and Meta-Analysis of Randomized Controlled Trials. Int J Endocrinol. 2016;2016:3854071.  
35. Gomes MB, Negrato CA. Adherence to insulin therapeutic regimens in patients with type 1 diabetes. A nationwide survey in Brazil. Diabetes Res Clin Pract. 2016;120:47-55.  
36. Nathan DM, Cleary PA, Backlund JY, Genuth SM, Lachin JM, Orchard TJ, et al. Intensive diabetes treatment and cardiovascular disease in patients with type 1 diabetes. N Engl J Med. 2005;353(25):2643-53.  
37. Writing Group for the DERG, Orchard TJ, Nathan DM, Zinman B, Cleary P, Brillon D, et al. Association between 7 years of intensive treatment of type 1 diabetes and long-term mortality. JAMA. 2015;313(1):45-53.  
38. Kähler P, Grevstad B, Almdal T, Gluud C, Wetterslev J, Lund SS, et al. Targeting intensive versus conventional glycaemic control for type 1 diabete melito: a systematic review with meta-analyses and trial sequential analyses of randomised clinical trials. BMJ Open. 2014;4(8):e004806  
39. Fullerton B, Jeitler K, Seitz M, Horvath K, Berghold A, Siebenhofer A. Intensive glucose control versus conventional glucose control for type 1 diabete melito. Cochrane Database Syst Rev. 2014(2):CD009122.  
40. Weinert LS, Leitão CB, Schmidt MI, Schaan BD. Diabetes Melito: diagnóstico e tratamento. In: Duncan BB, Schmidt MI, Giugliani ERJ, editors. Medicina Ambulatorial: Condutas de Atenção Primária Baseada em Evidência. Porto Alegre: Artmed; 2013. p. 905-19.  
41. edersen-Bjergaard U, Kristensen PL, Beck-Nielsen H, Norgaard K, Perrild H, Christiansen JS, et al. Effect of insulin analogues on risk of severe hypoglycaemia in patients with type 1 diabetes prone to recurrent severe hypoglycaemia (HypoAna trial): a prospective, randomised, open-label, blinded-endpoint crossover trial. Lancet Diabetes Endocrinol. 2014;2(7):553-61  
42. ATKINSON; M. A. Type 1 Diabete melito. Williams Textbook of Endocrinology. Thirteenth Edition, 2016.  
43. Siebenhofer A, Plank J, Berghold A, Jeitler K, Horvath K, Narath M, et al. Short acting insulin analogues versus regular human insulin in patients with diabete melito. Cochrane Database Syst Rev. 2006(2):CD003287.  
44. Brasil. Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Insulinas análogas de ação rápida para Diabete melito Tipo 1. Brasília: 2017. Disponível em: http://conitec.gov.br/images/Relatorios/2017/Relatorio_Insulinas_DiabetesTipo1_final.pdf  
45. Holleman F, Gale EA. Nice insulins, pity about the evidence. Diabetologia. 2007;50(9):1783-90.  
46. Fullerton B, Siebenhofer A, Jeitler K, Horvath K, Semlitsch T, Berghold A, et al. Short-acting insulin analogues versus regular human insulin for adults with type 1 diabete melito. Cochrane Database Syst Rev. 2016(6):CD012161  
47. Wojciechowski P, Niemczyk-Szechowska P, Olewińska E, Jaros P, Mierzejewska B, Skarżyńska-Duk J, et al. Clinical efficacy and safety of insulin aspart compared with regular human insulin in patients with type 1 and type 2 diabetes: a systematic review and meta-analysis. Pol Arch Med Wewn. 2015;125(3):141-51.  
48. Racsa PN, Meah Y, Ellis JJ, Saverno KR. Comparative Effectiveness of Rapid-Acting Insulins in Adults with Diabetes. J Manag Care Spec Pharm. 2017 Mar;23(3):291-298. doi: 10.18553/jmcp.2017.23.3.291. PubMed PMID: 28230457.  
49. Dreyer M, Prager R, Robinson A, Busch K, Ellis G, Souhami E, Van Leendert R.  Efficacy and safety of insulin glulisine in patients with type 1 diabetes. Horm Metab Res. 2005 Nov;37(11):702-7. PubMed PMID: 16308840.  
50. Philotheou A, Arslanian S, Blatniczky L, Peterkova V, Souhami E, Danne T. Comparable efficacy and safety of insulin glulisine and insulin lispro when given as part of a Basal-bolus insulin regimen in a 26-week trial in pediatric patients with type 1 diabetes. Diabetes Technol Ther. 2011 Mar; 13(3):327-34. doi: 10.1089/dia.2010.0072. Epub 2011 Feb 3. PubMed PMID: 21291333; PubMed Central PMCID: PMC3045789.  
51. Melo KFS et al.Short-acting insulin analogues versus regular human insulin on postprandial glucose and hypoglycemia in type 1 diabete melito: a systematic review and meta-analysis.Diabetol Metab Syndr. 2019 Jan 3;11:2.  
52. Mianowska B, Szadkowska A, Pietrzak I, Zmysłowska A, Wegner O, Tomczonek J, Bodalski J, Młynarski W. Immunogenicity of different brands of human insulin and  rapid-acting insulin analogs in insulin-naïve children with type 1 diabetes. Pediatr Diabetes. 2011 Mar;12(2):78-84. doi: 10.1111/j.1399 5448.2010.00659.x. PubMed PMID: 20522172.  
53. Shiramoto M, Eto T, Irie S, Fukuzaki A, Teichert L, Tillner J, et al. Single-dose new insulin glargine 300 U/ml provides prolonged, stable glycaemic control in Japanese and European people with type 1 diabetes. Diabetes Obes Metab. 2015;17(3):254-60.  
54. Haahr H, Heise T. A review of the pharmacological properties of insulin degludec and their clinical relevance. Clin Pharmacokinet. 2014;53(9):787-800.  
55. Dawoud D, O’Mahony R, Wonderling D, Cobb J, Higgins B, Amiel SA. Basal Insulin Regimens for Adults with Type 1 Diabete melito: A Systematic Review and Network Meta-Analysis. Value in health : the journal of the International Society for Pharmacoeconomics and Outcomes Research. 2018 Feb;21(2):176–84.  
56. Tricco AC, Ashoor HM, Antony J, Beyene J, Veroniki AA, Isaranuwatchai W, et al. Safety, effectiveness, and cost effectiveness of long acting versus intermediate acting insulin for patients with type 1 diabetes: systematic review and network meta-analysis. BMJ (Clinical research ed) [Internet]. 2014;349(oct):1–13. Available from: http://www.bmj.com/content/349/bmj.g5459.long  
57. Zhang Ji L; P, Zhu D, Lu J, Guo X, Wu Y, et al. Comparative effectiveness and safety of different basal insulins in a realworld setting. Diabetes, Obesity and Metabolism [Internet]. 2017 Aug [cited 2019 Jan 29];19(8):1116–26. Available from: http://www.ncbi.nlm.nih.gov/pubmed/28230322  
58. Sociedade Brasileira de Diabetes. Diretrizes: Aplicação de insulina: dispositivos e técnica de aplicação 2014-2015. Disponível em: https://www.diabetes.org.br/profissionais/images/pdf/diabetes-tipo-1/002-Diretrizes-SBD-AplicacaoInsulina-pg219.pdf  
59. Sociedade Brasileira de Diabetes. Atualização sobre hemoglobina glicada (a1c) para avaliação do controle glicêmico e para o diagnóstico do diabetes: aspectos clínicos e laboratoriais. 2018. Disponível em: https://www.diabetes.org.br/publico/images/banners/posicionamento-3-2.pdf  
60. Bolli GB. Insulin treatment in type 1 diabetes. Endocr Pract. 2006;12 Suppl 1:105-9.  
61. Bangstad HJ, Danne T, Deeb L, Jarosz-Chobot P, Urakami T, Hanas R. Insulin treatment in children and adolescents with diabetes. Pediatr Diabetes. 2009;10 Suppl 12:82-99.  
62. Bolli GB, Andreoli AM, Lucidi P. Optimizing the replacement of basal insulin in type 1 diabete melito: no longer an elusive goal in the post-NPH era. Diabetes Technol Ther. 2011;13 Suppl 1:S43-52.  
63. Tamborlane WV1, Sikes KA. Insulin therapy in children and adolescents. Endocrinol Metab Clin North Am. 2012 Mar;41(1):145-60.  
64. Malerbi D, Damiani D, Rassi N, Chacra AR, Niclewicz ED, Silva Filho RL, et al. [Brazilian Diabetes Society consensus statement--intensive insulin therapy and insulin pump therapy]. Arq Bras Endocrinol Metabol. 2006;50(1):125-35.  
65. Melo, KFS e Calliari, LEP. Tratamento do Diabete melito Tipo 1. In: Tratado de Endocrinologia. 2014.  
66. Subramanian S, Baidal D, Skyler JS, Hirsch IB. The Management of Type 1 Diabetes.In: Feingold KR, Anawalt B, Boyce A, Chrousos G, Dungan K, Grossman A, Hershman JM, Kaltsas G, Koch C, Kopp P, Korbonits M, McLachlan R, Morley JE, New M, Perreault L, Purnell J, Rebar R, Singer F, Trence DL, Vinik A, Wilson DP, editors. Endotext [Internet]. South Dartmouth (MA): MDText.com, Inc.; 2016 Nov 16. Acesso: https://www.ncbi.nlm.nih.gov/books/NBK279114/  
67. DeWitt DE, Hirsch IB. Outpatient insulin therapy in type 1 and type 2 diabetes. JAMA 2003; 289:2254-2264  
68. DeVries JH, Bailey TS, Bhargava A, Gerety G, Gumprecht J et al.,. Day-to-day fasting self-monitored blood glucose variability is associated with risk of hypoglycaemia in insulin-treated patients with type 1 and type 2 diabetes: A post hoc analysis of the SWITCH Trials. Diabetes Obes Metab. 2019 Mar;21(3):622-630.  
Associação Brasileira De Diabetes, 2019. Disponível em: https://www.diabetes.org.br/  
70. American Diabetes Association ADA. 4. Lifestyle Management. Diabetes Care. 2017;40(Suppl 1):S33-S43. ADA 2017 a  
71. Nathan DM, Bebu I, Lachin JM. Frequency of Evidence-Based Screening for Diabetic Retinopathy. N Engl J Med. 2017;377(2):195.  
72. American Diabetes Association. ADA 2017<sup>c</sup> 10. Microvascular Complications and Foot Care. Diabetes Care. 2017;40(Suppl 1):S88-S98.  
73. International Hypoglycaemia Study Group (IHSG). Glucose concentrations of less than 3.0 mmol/l (54 mg/dL) should be reported in clinical trials: a joint position statement of the American Diabetes Association and the European Association for the Study of Diabetes. Diabetologia. 2017 Jan;60(1):3-6. DOI: 10.2337/dc16-2215  
74. Bertoluci MC, Moreira RO, Faludi A, Izar MC, Schaan BD, Valerio CM, et al. Brazilian guidelines on prevention of cardiovascular disease in patients with diabetes: a position statement from the Brazilian Diabetes Society (SBD), the Brazilian Cardiology Society (SBC) and the Brazilian Endocrinology and Metabolism Society (SBEM). Diabetol Metab Syndr. 2017;9:53.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
INSULINA NPH, INSULINA REGULAR, INSULINA ANÁLOGA DE AÇÃO RÁPIDA E INSULINA ANÁLOGA DE AÇÃO  
PROLONGADA.  
Eu____________________________________________________________________________________ (nome do(a)  
paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **insulina NPH, insulina regular e insulina análoga de ação rápida e prolongada,** indicados para o tratamento da **diabete melito tipo 1 (DM 1).**  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico ____________________  
__________________________________________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que os medicamentos que passo a receber podem trazer os seguintes benefícios:  
- Melhor controle glicêmico possível;  
- Melhora dos sintomas relacionados à hiperglicemia;  
- Diminuição das complicações agudas de DM 1  
- Diminuição das complicações crônicas de DM 1;  
- Diminuição de hipoglicemias graves (necessidade de ajuda de outras pessoas para a recuperação) e de hipoglicemias  
- noturnas.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- insulinas regular, NPH, análogas asparte e lispro: classificadas na gestação como categoria B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- insulina análoga glulisina: classificada na gestação como categoria C: <mark>não se sabe ao certo os riscos do uso na gravidez; portanto, caso engravide, devo avisar imediatamente o médico.</mark>  
- <mark>insulina análoga degludeca: não há experiência clínica com a insulina degludeca em mulheres grávidas, portanto, caso</mark>  
- <mark>engravide, devo avisar imediatamente o médico.</mark>  
<mark>- insulina análoga detemir: mulheres grávidas, ou que planejam engravidar, ou que estejam amamentando devem procurar seu médico para orientação quando estiver usando este medicamento, pois um ajuste na dose de insulina pode ser necessário durante a gravidez, e, particularmente após o parto.</mark>  
<mark>- insulina análoga glargina: categoria de risco na gravidez C: este medicamento não deve ser utilizado por mulheres grávidas sem orientação médica.</mark>  
- efeitos adversos das insulinas: hipoglicemia (sintomas de baixo nível de açúcar no sangue) é o efeito mais comum, e pode se manifestar com suor frio, pele fria e pálida, dor de cabeça, batimento cardíaco rápido, enjoo, sensação de muita fome, alterações temporárias na visão, sonolência, sensação incomum de cansaço e fraqueza, nervosismo ou tremores, sensação de ansiedade, sensação de desorientação, dificuldade de concentração. Também pode ocorrer alergia (vermelhidão, inchaço, coceira) e alteração no local de aplicação (por isso a importância de não aplicar sempre no mesmo lugar) e ganho de peso.  
- contraindicação em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde (MS) e as Secretarias de Saúde (SES) a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (    ) Sim (    ) Não  
O meu tratamento constará do(s) seguinte(s) medicamento(s):  
(   ) insulina NPH (   ) insulina regular (   ) insulina análoga de ação rápida (   ) insulina análoga de ação prolongada Local:                                                                                          Data: Nome do paciente: Cartão Nacional do SUS: Nome do responsável legal: Documento de identificação do responsável legal: Assinatura do paciente ou do responsável legal Médico: CRM:                                 RS: ______________________________ Assinatura e carimbo do médico Data:  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da assistência farmacêutica se  
encontram os medicamentos preconizados neste Protocolo.  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
<!-- Start of picture text -->
slaw vaisareaqacro<br>rm cht aesSaas<br>‘Sim area . eee<br>ri Nao com o item 5.1 deste PCDT.<br>aceahatary<br>RES<br>i i ea<br>Tsai aon: aT aeWiperSeoe<br>aeadrne mnie pra a epeeSone<br>ot,<br>—<br>wanesil Sna<br>has fees<br>ao Spares<br>Sim ue ofp<br>Se ‘a eae ine<br>nog oooeaten upset ered<br>er<br>Me ‘para insulinacaste andloga7 de aco sm accorokotesimusotoarpesary lendscmon al<br>2 ee<br>aanraat a sp aaeaenona a tae = oseor<br>oid Ss Start<br>critérios de manutengio® (© Hipoglicemiascos noturnas repetidas (>1 por.<br><r a<br>ae Ce e aeeaencs<br>aan eae ‘ |<br>hte nominee seo<br>foe Eee 4<br>3. Nos dltimos 6 meses, pelo menos um Insulina analoga de aco setemente<br>Santen<br>atm es nare<br>o(eS haaaensoneeee dosre peesdoaseMpopeanlanee<br>2Iii ktonoshatne a Gait me<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
<!-- Start of picture text -->
COMO APLICAR A INSULINA<br>SS pated sap rtrdera eiliabenrs Ao iniciar » aplicache a insufina, se for encontrada a presenca<br>discincia de mais os menos 2 cm do local onde vock tomou 3 de sagas aa strings. seguir as seguintes erieneaghes<br>‘Siecio amerier, ae » Svea do corpo Sor 2 mesma. 2)1) SangueSangue exex grandepequenaquancidade:quantidaée:pararcontimar= apiicacio.2 apScacse<br>7<br>: 3 fora3 serings com 3 insalina «prepare outradese jorse<br>a<br>fares ema prega na pale onde voct vai aplicar 2 insstina. Injetar insesina, empurrande © tmbele ast final. Resrar<br>Pega na serings come s0 forse um lapses tacrodense 2 a seringa « fazer ma lewe presase no lecal. usando ©<br>agatha aa pele. num Sngule de 907, soltar 3 prega cucinen siasene com auceal<br>Cte: sm pessuas sosite magras Ge criancas menares, 2<br>Ssjecie pedera ser Set sum angule de 45° para evitar que<br>sea apicads no mzcule,<br>a =f<br><!-- End of picture text -->  
<!-- Start of picture text -->
LOCAIS PARA A APLICACAO DA INSULINA<br>(Embaixo da pele, ou seja, no tecido subcutaneo)<br>fan<br>is | fies (parte externaBRACOSe superior)<br>COXAS<br>(parte anterior e lateral)<br>REGIAO ABDOMINAL<br>FRENTE REGIAO GLUTEA COSTAS<br>Vocé deve fazer o rodizio na aplicacao diaria de insulina para evitar complicacoes<br>tais como hipertrofia ou atrofia no local.<br>Evite aplicar a insulina perto das juntas, na 4rea da virilha, no umbigo e na linha<br>média do abd6mem.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Insulina _bolus_ : fator de correção e contagem de carboidratos  
<mark>O FC corresponde à redução da glicemia após a administração de 1U de insulina de ação rápida e deve ser ajustado individualmente, de acordo com a AMG. O FC pode ser estabelecido de acordo com a faixa etária (</mark> **<mark>Tabela A</mark>** <mark>). O FC deve ser ajustado em 10% a 20%, caso as glicemias duas a três horas após as doses de correção atinjam valores inadequadamente altos ou baixos</mark><sup>1,2</sup> <mark>e</mark> devem ser testados em períodos diferentes do dia. Em geral, os pacientes possuem maior resistência na ação da insulina pela manhã, comparada à tarde e à noite, o que implica em dose maior nesse período. <mark>O mesmo paciente, por exemplo, poderá necessitar de FC de 40 pela manhã, 50 na maior parte do dia e 60 à noite.</mark>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
<mark>O</mark> _<mark>bolus</mark>_ <mark>de correção (BC) deverá ser calculado individualmente e de acordo com o fator de correção (FC), a glicemia</mark>  
<mark>atual e os objetivos glicêmicos de cada paciente, utilizando a fórmula:</mark>  
_<mark>Bolus</mark>_ <mark>de Correção = Glicemia Atual - Objetivo Glicêmico</mark>  
<mark>FC</mark>  
<mark>Exemplo de cálculo de BC (glicemia atual = 281 mg/dL, OG = 100 mg/dL e FC = 40)</mark>  
_<mark>Bolus</mark>_ <mark>de correção = 281 – 100/40 = 4,5 U (esta dose deverá ser somada à dose de</mark> _<mark>bolus</mark>_ <mark>prandial)</mark>  
**<mark>Tabela A</mark>** <mark>- Fator de Correção (FC) e Relação Carboidrato/insulina (R C/I) de acordo com a idade</mark><sup>2,3</sup> <mark>.</mark>  
<!-- Start of picture text -->
<2 300 - 350 45 - 50<br>3-5 200 - 250 40<br>6-8 180 30<br>9-11 100 - 150 20<br>12-13 75 - 100 12-15<br>> 14 anos 25-75 10<br>Adultos 40-60 10-20<br><!-- End of picture text -->  
<mark>Outra forma de estabelecer o</mark> _<mark>bolus</mark>_ <mark>de correção, para pacientes com limitações cognitivas, consiste em elaborar escala para dose de</mark> _<mark>bolus</mark>_ <mark>de acordo</mark>  
<mark>com a glicemia pré-prandial, somada à dose fixa de insulina prandial para cada uma das refeições principais (</mark> **<mark>Quadro A</mark>** <mark>). Ver abaixo um exemplo de escala a ser utilizada</mark><sup>4</sup> <mark>.</mark>  
**<mark>Quadro A</mark>** <mark>- Exemplo de escala a ser utilizada</mark>  
**Corrigindo a glicemia utilizando escala**  
1) Estabelecer o fator de correção (FC) FC = 50 (adulto com DM1)

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Pode ser utilizado 100 mg/dL para adultos e 150 mg/dL para crianças ou indivíduos com hipoglicemias sem sintomas  
3) Determinar o limite superior da glicemia (LSG) que corresponde à glicemia acima da qual deve-se utilizar _bolus_ de correção.  
LSG = FC + OG  
- 4) Exemplo de algoritmo para paciente com FC=50, OG=100 e LSG=150 que utiliza doses fixas de 5U de insulina de ação rápida antes das três refeições principais:  
< 50 mg/dL = - 2U (3 U) 51 a 70 mg/dL = - 1U (4 U) 71 a 150 mg/dL= 0 (5U) 151 a 200 mg/dL = + 1U (6 U) 201 a 250 mg/dL = + 2U (7 U) 251 a 300 mg/dL= + 3U (8 U) 301 a 350 mg/dL = + 4U (9 U) 351 a 400 mg/dL = + 5U (10 U) > 401 mg/dL = + 6U (11 U)

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
<mark>Idealmente, a dose do</mark> _<mark>bolus</mark>_ <mark>prandial deve ser ajustada para a quantidade de carboidratos a serem ingeridos na refeição, utilizando a relação carboidrato/insulina (R C/I) que indica quantos gramas de carboidratos deverão ser cobertos por 1U de insulina de ação rápida. A R C/I pode ser estabelecida de acordo com a faixa etária do paciente, conforme está descrito na tabela A. A contagem de carboidratos consiste em uma estratégia nutricional na qual o paciente conta a quantidade de carboidratos da refeição, em gramas, e ajusta a dose de insulina de acordo com esta estimativa, permitindo maior flexibilidade nas escolhas dos alimentos. Após contar os carboidratos da refeição, com o auxílio de tabelas e aplicativos com a quantidade de carboidratos por medidas caseiras dos alimentos, utiliza-se a R C/I para estabelecer a dose de insulina de ação rápida para cobrir a refeição (tabela</mark> b).  
**<mark>Tabela b</mark>** <mark>: exemplo de cálculo de</mark> _<mark>bolus</mark>_ <mark>prandial para um adulto que utiliza a R C/I de 15g/1U de insulina</mark>  
<!-- Start of picture text -->
| Alimentos | Quantidade_ | Carboidratos(g) |<br>Arroz branco 3 colheres (sopa) 15<br>Lentilha 5 colheres (sopa) 20<br>Verduras e Legumes 1 pires (e)<br>Bife pequeno 1 unidade °<br>Tangerina 1 unidade média 15<br>Total 50g<br><!-- End of picture text -->  
_<mark>Bolus</mark>_ <mark>Prandial = Quantidade de carboidratos da refeição</mark>  
<mark>R C/I</mark>  
_<mark>Bolus</mark>_ <mark>Prandial = 50/15 = 3,3 U = 3,0 ou 3,5 U (esta dose deverá ser somada à dose do</mark> _<mark>bolus</mark>_ <mark>de correção).</mark>  
<mark>Esta dose poderá ser administrada imediatamente após a refeição, caso não seja possível prever a quantidade carboidratos que será ingerida pelo paciente. Geralmente, há necessidade de uma dose maior de insulina para a mesma quantidade de carboidratos no desjejum quando comparado ao almoço e jantar. Nesta refeição, mais comumente, os adultos com DM1 utilizam 1U de insulina para cada 5 a 10 g de carboidratos. É importante ressaltar que o</mark> _<mark>bolus</mark>_ <mark>prandial a ser administrado antes de dormir, deverá utilizar relações carboidrato/insulina maiores, para evitar hipoglicemias durante o sono. Por exemplo, pode-se prescrever inicialmente, para adultos, uma relação carboidrato/insulina de 20 a 25 g/1 U de insulina para este horário. Caso o lanche entre as refeições principais contenha mais do que 15 a 20 g de carboidratos haverá necessidade de aplicação de insulina de ação rápida</mark><sup>1,3.</sup>  
<mark>Para pacientes que não fazem contagem de carboidratos, pode-se utilizar esquema de doses fixas de insulina prandial, tentando manter quantidades constantes de carboidratos nas refeições principais e lanches e se possível, introduzir esquema de correção da glicemia de acordo com os níveis glicêmicos, conforme a escala demonstrada no sub-item “</mark> _<mark>Bolus</mark>_ <mark>de Correção”.</mark>  
<mark>O ajuste da relação carboidrato/insulina ou da dose fixa de</mark> _<mark>bolus</mark>_ <mark>prandial deverá ser realizado de acordo com a avaliação das glicemias antes e duas a três horas após as refeições, de preferência em refeições nas quais as glicemias pré-prandiais estejam dentro do alvo glicêmico. Caso a glicemia pós-prandial de uma das refeições esteja consistentemente abaixo ou acima do alvo glicêmico (por exemplo, para adultos geralmente utilizamos como objetivo pós-prandial glicemias entre 90 e 140 mg/dL), devese aumentar ou reduzir a relação carboidrato/insulina em 1 a 2 g/1U, respectivamente</mark><sup>6</sup> <mark>. A</mark> tualmente, encontra-se disponível para suporte aos pacientes, aplicativos gratuitos<sup>7</sup> para a realização dos cálculos das doses de insulina _bolus_ de correção e prandial.  
As insulinas análogas de ação prolongada devem corresponder a menos da metade da dose total diária de insulina (DTDI), e as primeiras podem ser administradas uma ou duas vezes ao dia. A maioria dos pacientes deve administrar a insulina glargina U100 uma vez ao dia e a insulina detemir duas vezes ao dia, como já mencionado. A degludeca e glargina U300 devem ser administradas uma vez ao dia, de preferência no mesmo horário. No **Quadro 2** deste PCDT, estão descritas as sugestões de DTDI e DTDI basal iniciais, de acordo com o peso corporal.  
Os pacientes que estiverem substituindo a insulina humana NPH pela insulina glargina U100, a ser administrada uma vez ao dia, devem ter as doses de insulina NPH somadas e reduzidas em 20% e o resultado será a dose diária de início de uso da insulina glargina U100. Os pacientes que estiverem substituindo a insulina NPH pela detemir, duas vezes ao dia, devem ter as doses de insulina NPH somadas e divididas em duas doses de detemir, administradas com intervalos de 12 horas. Ao substituir a insulina glargina U100 pela insulina degludeca, reduzir a dose total diária de insulina glargina U100 em 15% a 25%. Na transição da insulina detemir para a insulina degludeca, reduzir a dose total diária em 25%. Na transição da insulina glargina U100, uma ou duas vezes ao dia, para a insulina glargina U300, a dose pode ser aumentada em 10% a 20%.  
<mark>O ajuste das doses das insulinas basais deve ser de acordo com as glicemias pré-prandiais, glicemias no período do sono e a presença de hipoglicemias entre as refeições e no período de sono. Caso ocorra queda ou elevação da glicemia maior do que 30 mg/dL, no período de sono ou entre as refeições, sugere-se a redução ou aumento da última dose de insulina basal em 10% a 20%, respectivamente. Esta excursão glicêmica deve ser observada sem que haja lanches entre as refeições principais, correção de hiperglicemia pós-prandial e lanches e</mark> _<mark>bolus</mark>_ <mark>(prandial e de correção) antes de dormir para avaliação do controle glicêmico noturno. Caso ocorra hipoglicemia, pela omissão dos lanches entre as refeições principais, por atraso de uma das refeições ou no período noturno; sugere-se a redução da última dose de insulina basal administrada antes da hipoglicemia, em 10% a 20%</mark><sup>5,4</sup>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Pode ser utilizada por todo paciente com diabetes como terapia nutricional.  
O objetivo da estratégia é encontrar um equilíbrio entre a glicemia, a quantidade de carboidratos ingerida e a quantidade de insulina adequada.  
O carboidrato é nutriente com maior efeito sobre a glicemia, visto que 100% do que é ingerido se transforma em glicose. Medir a glicemia antes das refeições e duas horas após pode ajudar a estimar esse efeito sobre a glicemia.  
Exemplos de alimentos que contêm carboidratos: Pães, biscoitos, cereais, arroz, massas, batata e grãos, vegetais, frutas, sucos, leite, iogurtes, açúcar, mel e alimentos que contém açúcar.  
Exemplo de alimentos que não precisam contar carboidratos: vegetais (até 1 xícara de vegetal cru ou ½ xícara de vegetal cozido), carnes de boi, aves, pescado, ovos (até uma porção de 120 gramas), queijo, azeite, maionese, creme de leite, água, café, chá e adoçantes.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: Geral -->
Supondo que seu café da manhã seja 01 pão francês com margarina (28g de carboidratos), 01 copo de leite com café (12g de carboidratos) e ½ mamão papaya (13g de carboidratos). O total de carboidratos nesse café da manhã é 53g de carboidratos.  
Para isso, é importante ler as informações de tabela nutricional presente em cada rótulo do alimento ou estimar pelo manual de contagem de carboidratos. Para mais informações, recomenda-se consultar o Manual de Contagem de Carboidratos da Sociedade Brasileira de Diabetes de 2016.  
Outras formas de estimar a quantidade da porção de forma aproximada: 1- Palma da mão= uma porção de carne; 2- Unha= 01 colher de chá de margarina ou azeite; 3- Polegar= 30 gramas de queijo e Punho= 01 xícara de chá de arroz ou macarrão ou 01 batata pequena.  
É importante ter horários definidos para comer e nas mesmas quantidades.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: **<mark>REFERÊNCIAS</mark>** -->
1. DeWitt DE, Hirsch IB. Outpatient insulin therapy in type 1 and type 2 diabetes. JAMA 2003; 289:2254-2264  
2. 2.Tamborlane WV1, Sikes KA. Insulin therapy in children and adolescents. Endocrinol Metab Clin North Am. 2012 Mar;41(1):145-60.  
3. Melo, KFS e Calliari, LEP. Tratamento do Diabete melito Tipo 1. In: Tratado de Endocrinologia. 2014  
4. Melo KFS et al.Short-acting insulin analogues versus regular human insulin on postprandial glucose and hypoglycemia in type 1 diabete melito: a systematic review and meta-analysis. Diabetol Metab Syndr. 2019 Jan 3;11:2.  
5. Subramanian S, Baidal D, Skyler JS, Hirsch IB. The Management of Type 1 Diabetes.In: Feingold KR, Anawalt B, Boyce A, Chrousos G, Dungan K, Grossman A, Hershman JM, Kaltsas G, Koch C, Kopp P, Korbonits M, McLachlan R, Morley JE, New M, Perreault L, Purnell J, Rebar R, Singer F, Trence DL, Vinik A, Wilson DP, editors. Endotext [Internet]. South Dartmouth (MA): MDText.com, Inc.; 2016 Nov 16. Acesso: https://www.ncbi.nlm.nih.gov/books/NBK279114/  
6. Sociedade Brasileira de diabetes. Manual de contagem de carboidratos, 2016. Disponível em: http://www.diabetes.org.br/publico/images/manual-de-contagem-de-carboidrato2016.pdf  
7. Sociedade Brasileira de diabetes. APP oficial e atualizado de Contagem de Carboidrato da SBD, 2019. https://www.diabetes.org.br/profissionais/app-oficial-e-atualizado-de-contagem-de-carboidrato-da-sbd.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: **APÊNDICE 4** -->
AVALIAÇÃO E MONITORAMENTO DOS PACIENTES COM DIABETE MELITO TIPO 1  
|**Exames**|**Início**|**Periodicidade**|
|---|---|---|
|Avaliação de Peso e Altura|Após o diagnóstico|Em cada consulta com o profissional de saúde|
|Avaliação da puberdade e do<br>estágio de maturação sexual|Crianças: Após o diagnóstico|Anualmente|
|Avaliação de risco<br>cardiovascular|Crianças: Início da puberdade<br>Adultos: Após o diagnóstico|Anualmente|
|Avaliação da Pressão Arterial|Após o diagnóstico|Deve ser verificada em cada consulta com o<br>profissional de saúde|
|Avaliação do pé diabético<br>(Neuropatia periférica e Doença<br>Arterial Periférica)|Após o diagnóstico|Anualmente|
|Avaliação de dislipidemia|Crianças: A partir de 10 anos<br>de idade ou início da<br>puberdade. Adultos: Após o<br>diagnóstico|Crianças: Se o resultado vier normal, repetir a cada 5<br>anos. Se vier alterado, repetir anualmente<br>Adultos: Repetir anualmente|
|Avaliação da Hemoglobina<br>glicada|Após o diagnóstico|A cada 6 meses*|
|Avaliação de nefropatia|Crianças: Após 5 anos de<br>doença ou puberdade.<br>Adultos: Após o diagnóstico<br>A critério médico, o início da<br>avaliação pode ser antecipado.|Anualmente, pela taxa de filtração glomerular de<br>microalbuminúria.|
|Avaliação oftalmológica|Crianças: Após 5 anos de<br>doença ou puberdade.<br>Adultos: Após o diagnóstico<br>A critério médico, o início da<br>avaliação pode ser antecipado.|Anualmente|
|Avaliação da tireoide|Após o diagnóstico|Anualmente|
|Avaliação psicológica e<br>emocional|Após o diagnóstico|Quando apresentar cetoacidose diabética ou<br>dificuldade do controle de glicose|  
*Recomenda-se que a HbA1c seja realizada a cada 3 a 6 meses em crianças e adolescentes, como no mínimo duas medidas anuais. Para adultos, com controle estáveis, recomenda-se duas medidas anuais  
Referências  
1. <u>https://www.nice.org.uk/guidance/ng18/chapter/1-Recommendations#service-provision</u>  
2. https://www.nice.org.uk/guidance/ng17/resources/type-1-diabetes-in-adults-diagnosis-and-management-pdf-1837276469701  
3. Diretrizes Sociedade Brasileira de Diabetes. Diretrizes 2017-2018 [Internet]. 2018. 3-383 p.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: AVALIAÇÃO DO PÉ DIABÉTICO -->
No exame físico é importante estar atento às possíveis alterações anatômicas do pé diabético, hidratação, coloração, temperatura e distribuição de pelos, integridade de unhas e pele e possíveis alterações neurológicas incluindo sensibilidade, reflexos tendíneos e função motora. Os mecanismos pelos quais as lesões no pé do paciente diabético ocorrem podem ser: neuropáticos, vascular (isquêmico) ou mistos.  
**Pé diabético neuropático** - a perda da sensibilidade por um comprometimento neuropático pode gerar uma lesão que se agrava sem a percepção do próprio paciente podendo ser indolor. O pé neuropático em geral tem a temperatura quente ou morna, coloração normal, pele seca ou fissurada, deformidade dos dedos em garra, dedo em martelo, pé de Charcot ou outras alterações anatômicas, apresenta parestesia, pulsos inalterados, presença de edema e calosidades. As ulcerações tendem a surgir em 1º e 5 º metatarsos e calcâneo com anel querostático.  
**Pé diabético isquêmico** : Lesões isquêmicas podem gerar pontos onde a circulação sanguínea fica comprometida. Podese observar a temperatura fria do pé, palidez com a elevação e cianose com declive. A pele é fina e brilhante, em geral sem deformidades, calosidades ou edema. Sensação dolorosa com alivio quando a perna está pendente. As lesões geralmente são laterodigitais, sem anel querostático e são dolorosas.  
No exame físico do pé diabético é necessário avaliar a presença das condições citadas relacionadas ao pé neuropático ou pé isquêmico e no pé diabético misto, onde podem ser encontradas alterações das 2 condições concomitantemente.  
É importante colher uma anamnese adequada para identificar possíveis fatores de risco para o pé diabético e complicações relacionadas. A avaliação neurológica se inicia com teste de sensibilidade tátil (Quadro 1 e Figuras 1 e 2), térmica e vibratória.  
**Quadro 1** - Método de Avaliação da sensibilidade tátil utilizando o teste com monofilamento de 10 gramas de Semmes-Weinstein  
|1- Esclarecer o paciente sobre o teste. Solicitar ao mesmo que diga “sim” cada vez que perceber o contato com o<br>monofilamento.|
|---|
|2- Aplicar o monofilamento adequado (10 gramas) perpendicular à superfície da pele, sem que a pessoa examinada veja o<br>momento do toque.|
|3- Pressionar com força suficiente apenas para encurvar o monofilamento, sem que ele deslize sobre a pele.|
|4- O tempo total entre o toque para encurvar o monofilamento e sua remoção não deve exceder 2 segundos.|
|5- Perguntar, aleatoriamente, se o paciente sentiu ou não a pressão/toque (Sim ou Não) e onde está sendo tocado (Pé direito<br>ou esquerdo).|
|6- Serão pesquisados quatro pontos (pontos vermelhos-escuro), ambos os pés.|  
7- Aplicar duas vezes no mesmo local, alternando com pelo menos uma vez simulada (não tocar), contabilizando no mínimo três perguntas por aplicação.  
8- A percepção de sensibilidade protetora está presente se duas respostas forem corretas das três aplicações.  
- 9- A percepção da sensibilidade protetora está ausente se duas respostas forem incorretas das três aplicações.  
**Figura 1** – Técnica de aplicação do teste com monofilamento de Semmes-Weinstem  
<!-- Start of picture text -->
« R, \@r<br>Ss =<br>4 x<br>ze 5 a SS<br><!-- End of picture text -->  
Fonte: Adaptado do Manual do Pé Diabético. Ministério da Saúde, 2016.  
Figura 2 - Locais para avaliação do teste com monofilamento de Semmes-Weinstem  
<!-- Start of picture text -->
(ee@.=<, i.®... (Jam)TT _<br>\-— Fe OD \ 6 [=<br>mast|) f/f i — | Yi<br>VL > uOL ay) | \ |<br>> | ) |<br>| / /<br><!-- End of picture text -->  
**Fonte:** Adaptado do Manual do Pé Diabético. Ministério da Saúde, 2016.  
As outras etapas da avaliação do pé diabético consistem na sensibilidade vibratória que deve ser realizada com diapasão de 128 Hz; teste do reflexo tendíneo Aquileu com martelo; avaliação vascular com aferição do pulso pedioso e tibial posterior. Todas essas etapas estão descritas no Manual do Pé Diabético, citado na bibliografia do anexo e devem ser consultados pelos profissionais de saúde que desejam obter mais detalhes. Após a avaliação deve-se estar a tento para a classificação de risco do pé diabético abordado na tabela a seguir e para as recomendações adequadas.  
**Quadro 2** : Cuidados ao paciente com pé diabético segundo classificação de risco  
|**Categoria de**<br>**risco**|**Definição**|**Recomendação**|**Acompanhamento**|
|---|---|---|---|
|0|Sem PSP (Perda de<br>Sensibilidade Protetora<br>dos Pés) e Sem DAP<br>(Doença arterial<br>periférica)|Orientações sobre calçados apropriados<br>Estímulo ao autocuidado|Anual|
|1|PSP com ou sem<br>deformidade|Considerar o uso de calçados adaptados<br>Considerar correção cirúrgica, caso não haja<br>adaptação|A cada 6 meses|
|2|DAP com ou sem PSP|Considerar o uso de calçados adaptados<br>Considerar necessidade de encaminhamento ao<br>cirurgião vascular|A cada 3 meses|
|3|História de Úlcera ou<br>amputação|Considerar o uso de calçados adaptados<br>Considerar correção cirúrgica, caso não haja<br>adaptação<br>Se houver DAP, avaliar a necessidade de<br>encaminhamento ao cirurgião vascular|A cada 2 meses|  
**Fonte:** Adaptado do Manual do Pé Diabético. Ministério da Saúde, 2016.

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: **REFERÊNCIAS** -->
- 1- Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Manual do pé diabético: Estratégias para o cuidado da pessoa com doença crônica. Brasília: Ministério da Saúde, 2016. Disponível em: http://189.28.128.100/dab/docs/portaldab/publicacoes/manual_do_pe_diabetico.pdf  
- 2- Annual Direct Medical Costs of Diabetic Foot Disease in Brazil: A Cost of Illness Study  
- 3- Pesquisa Nacional de Saúde - PNS 2013: percepção do estado de saúde, estilos de vida e doenças crônicas,  
- 4- BRASIL. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Estratégias  
para o cuidado da pessoa com doença crônica: diabete melito. Brasília, 2013.  
**APÊNDICE 6**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA  
**1. Levantamento de informações para planejamento da reunião de escopo com os especialistas**  
- **1.1 Tecnologias disponíveis no Sistema Único de Saúde (SUS) para o tratamento da diabete melito tipo 1 (DM 1)**  
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e o Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP) para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas.  
A partir das consultas realizadas foi possível identificar que os medicamentos atualmente disponíveis são:  
- Insulina NPH: suspensão injetável 100 UI/ml  
- Insulina Regular: solução injetável 100 UI/ml  
Foi possível identificar que os **análogos de ação rápida** foram incorporados para o tratamento da DM 1, conforme relatório da CONITEC http://conitec.gov.br/images/Relatorios/2017/Relatorio_Insulinas_DiabetesTipo1_final.pdf  
<mark>Os</mark> **<mark>análogos de ação prolongada</mark>** <mark>foram, recentemente, incorporados no SUS, conforme relatório da CONITEC http://conitec.gov.br/images/Relatorios/2019/Relatorio_Insulinas_Analogas_DM1.pdf</mark>  
<mark>O presente Protocolo considera os relatórios de recomendação n° 245 de Fevereiro de 2017 e n° 440 de março de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), que versam, respectivamente, sobre o uso das insulina análoga de ação rápida e insulina análoga de ação prolongada para o tratamento da DM1, bem como fontes avulsas consideradas pelos autores. Por isso, novas referências foram adicionadas à versão do Protocolo de 2018, bem como a pergunta de pesquisa “As análogas de insulina de ação prolongada (glargina, detemir e degludeca) são eficazes, seguras e efetivas para o tratamento de pacientes com diabete tipo 1, quando comparadas à insulina NPH?” respondia por meio do Relatório de Recomendação nº 440 de março de 2019.</mark>

---

<!-- METADADOS: doenca: Diabete Melito Tipo 1 | secao: **REFERÊNCIAS** -->
A primeira versão do PCDT da DM 1 fora realizada em 2014 cuja metodologia de busca utilizada está detalhada como  
segue:  
Foram realizadas buscas nas bases de dados Medline/Pubmed e na Biblioteca Cochrane.  
Na base de dados Medline/Pubmed foi realizada busca em 13/11/2014 com os termos _Mesh_ "Diabete melito, Type 1" e "Therapeutics". Esta busca foi restrita para estudos em humanos e do tipo meta-análise, sem restrições de linguagem, sendo localizados 63 estudos. Foram então excluídos estudos que não abordassem tratamentos para DM 1, com medicamentos ou intervenções não registradas no Brasil ou aqueles que não fossem de fato revisões sistemáticas com meta-análise. Com estes critérios, foram selecionadas 14 meta-análises.  
Na Biblioteca Cochrane foi realizada busca com o termo “Diabete melito” restrito ao campo de título. Com isso foram encontradas 64 revisões sistemáticas completas. Destas, foram selecionadas aquelas sobre tratamento para DM 1, com medicamentos ou intervenções aprovadas no Brasil. Com isso foram incluídas mais 3 revisões sistemáticas.  
Também foram consultados consensos de sociedades internacionais e nacionais, livros textos de endocrinologia e o _UpToDate_ , disponível no site http://www.uptodateonline.com/online/index.do. Todas as fontes utilizadas tiveram as suas referências revisadas na tentativa de obter outros estudos relevantes e incluídos na elaboração deste Protocolo, totalizando 39 referências nele incluídas.  
A fim de guiar a elaboração/atualização do presente PCDT foi realizada uma nova busca na literatura sobre diagnóstico e intervenções terapêuticas baseadas em evidências definidas pelas seguintes perguntas PICO, conforme **quadro 1** :  
**Quadro 1:** Pergunta PICO  
|**População**|Pacientes com DM 1|
|---|---|
|**Intervenção**|Diagnóstico e tratamento clínico|
|**Comparação**|Sem restrição de comparadores|
|**Desfechos**|Segurança e eficácia|  
Adicionalmente, foi acrescido uma nova busca na literatura com o objetivo de analisar as evidências científicas atualmente disponíveis sobre a eficácia, efetividade e segurança relacionadas ao uso das análogas de insulina de ação prolongada para o tratamento de DM1. Para sua elaboração, estabeleceu-se a seguinte pergunta, cuja estruturação se encontra no quadro abaixo.  
**Quadro 2** : Pergunta PICO (relatório de incorporação – n°440 de março de 2019  
|**População**|Pacientes com DM1.|
|---|---|
|**Intervenção**|Insulina Análoga de ação prolongada (Glargina, detemir e degludeca).|
|**Comparadores**|Insulina NPH.|
|**Desfechos**|- Níveis de hemoglobina A glicosilada (HbA1c);|
||- Episódios de hipoglicemia sintomática, grave e noturna;<br>- Eventos adversos;<br>- Qualidade de vida;|
|**Tipo de estudo**|Revisões Sistemáticas (RS) com ou sem meta-análise.|  
As seguintes estratégias de busca foram utilizadas, conforme **quadro 3** :  
**Quadro 3:** Buscas sobre intervenções terapêuticas  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline|"Diabete melito,|19|**8**|
|(via PubMed)|Type 1"[Mesh]||**Motivo das exclusões:**|
||AND||foram excluídos 11 estudos, por serem estudos que não foram|
|Data da busca:|"Therapeutics"[||realizados em pacientes com DM1 (4), que não apresentavam|
|10/07/2017|Mesh] AND||desenho de revisão sistemática ou meta-análise (2), com desfechos|
||(Meta-<br>Analysis[ptyp]<br>AND<br>("2014/11/01"[P<br>DAT] :||que não eram de interesse para o PCDT (associação de DM com<br>outras doenças, terapias específicas para complicações crônicas do<br>DM – 4) e que eram sobre medicamentos ou terapias não disponíveis<br>no Brasil (1).|
||"3000/12/31"[P<br>DAT]) AND<br>"humans"[MeS<br>H Terms])|||  
|Embase|'insulin|121|**13**|
|---|---|---|---|
||dependent||**Motivos das exclusões:**|
|Data da busca:<br>10/07/2017|diabete<br>melito'/exp<br>AND<br>'therapy'/exp<br>AND [meta<br>analysis]/lim<br>AND<br>[humans]/lim<br>AND [2014-<br>2017]/py||foram excluídos 105 estudos, por serem estudos que não foram<br>realizados em pacientes com DM1 (26), que não apresentavam<br>desenho de revisão sistemática ou meta-análise (23), com desfechos<br>que não eram de interesse para o PCDT (associação de DM com<br>outras doenças, terapias específicas para complicações crônicas,<br>avaliações de incidência de complicações do DM, desfechos não<br>clinicamente relevantes – 38), que eram sobre medicamentos ou<br>terapias não disponíveis no Brasil (8) e que foram publicados<br>somente no formato de resumo em evento científico (10).<br>Três estudos foram excluídos por já terem sido incluídos em buscas<br>anteriores.|
|Cochrane<br>Library<br>Data da busca:<br>10/07/2017|MeSH<br>descriptor:<br>[Diabete melito,<br>Type 1] explode<br>all trees|29|**6**<br>**Motivos das exclusões:**<br>foram excluídos 23 estudos, por serem estudos que não foram<br>realizados em pacientes com DM1 (12), com desfechos que não eram<br>de interesse para o PCDT (terapias específicas para complicações<br>crônicas, avaliações de incidência de complicações do DM,<br>desfechos não clinicamente relevantes – 10), que eram sobre<br>medicamentos ou terapias não disponíveis no Brasil (1).|  
Foram também realizadas buscas sobre diagnóstico, conforme quadro 4:  
**Quadro 4** : Busca por diagnóstico  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline|"Diabete melito, Type|102|**13**|
|(via PubMed)|1"[Mesh] AND<br>"Diagnosis"[Mesh] AND||**Motivos das exclusões**:<br>foram excluídos 86 estudos, por serem estudos que não|
|Data da busca:<br>10/07/2017|(Meta-Analysis[ptyp] AND<br>"humans"[MeSH Terms])||foram realizados em pacientes com DM1 (15), que não<br>apresentavam desenho de revisão sistemática ou meta-<br>análise (7), com desfechos que não eram de interesse<br>para o PCDT (associação de DM com outras doenças,<br>terapias específicas para complicações crônicas,<br>avaliações de incidência de complicações do DM,<br>desfechos não clinicamente relevantes – 56), que eram<br>sobre medicamentos ou terapias não disponíveis no<br>Brasil (7) e que não foram realizados em humanos (1).<br>Três estudos foram excluídos por já terem sido<br>incluídos em buscas anteriores.|  
|Embase|'insulin dependent diabete<br>melito'/exp AND|71|**0**<br>**Motivos das exclusões:**|
|---|---|---|---|
|Data da busca:<br>10/07/2017|'diagnosis'/exp AND [meta<br>analysis]/lim AND<br>[humans]/lim||foram excluídos 70 estudos, por serem estudos que não<br>foram realizados em pacientes com DM1 (25), que não<br>apresentavam desenho de revisão sistemática ou meta-<br>análise (30), com desfechos que não eram de interesse<br>para o PCDT (associação de DM com outras doenças,<br>terapias específicas para complicações crônicas,<br>desfechos não clinicamente relevantes – 14), e que<br>foram publicados somente no formato de resumo em<br>evento científico (1).<br>Um estudo foi excluído por já ter sido incluído em<br>buscas anteriores.|
|Cochrane<br>Library|(MeSH descriptor: [Diabete<br>melito, Type 1] explode all<br>trees) AND (MeSH<br>descriptor: [Diagnosis]|5|**1**<br>**Motivos das exclusões:**<br>foram excluídos 4 estudos, por serem estudos que não<br>foram realizados em pacientes com DM1 (2), com|
|Data da busca:<br>10/07/2017|explode all trees)||desfechos que não eram de interesse para o PCDT<br>(terapias específicas para complicações crônicas,<br>avaliações de incidência de complicações do DM – 2).|  
Foram encontradas 347 referências, 41 foram selecionadas conforme critérios descritos acima. Os artigos selecionados encontram-se na tabela 1 (busca medline para tratamento), tabela 2 (busca embase para tratamento), tabela 3 (busca Cochrane para tratamento), tabela 4 (medline para diagnóstico), tabela 5 (busca Cochrane para diagnóstico).  
Foram também utilizados como referência, livros texto, consensos de sociedades médicas e os relatórios de incorporação das análogas de insulina da CONITEC.  
**Tabela 1** : Busca de evidência para tratamento - Medline  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|1 - Rughooputh et al.  PLoS One|||||||
|2015, 10(12):e0145505.|||||Todos os estudos:  Redução de||
|Protein Diet Restriction Slows<br>Chronic Kidney Disease<br>Progression in Non-Diabetic<br>and in Type 1 Diabetic Patients, but<br>Not in Type 2 Diabetic Patients: A<br>Meta-Analysis of Randomized<br>Controlled Trials Using Glomerular<br>Filtration Rate as|Revisão sistemática com<br>meta-análise de ECRs de<br>no mínimo 12 meses de<br>duração|15 estudos, em<br>DM tipo 1, em<br>DM tipo 2, em não<br>diabéticos e com<br>população mista,<br>n=1965|Restrição de<br>proteínas na<br>dieta|Taxa de filtração<br>glomerular|-0.95  ml/min/1.73m<sup>2</sup>/ano<br>(95% CI: -1.79, -0.11) na TFG;<br>Estudos em não diabéticos e<br>DM tipo 1: Redução de -1.50<br>ml/min/1.73m<sup>2</sup>/ano (95% CI: -<br>2.73, -0.26) na TFG|Apenas 4 ECRs em DM<br>tipo 1 exclusivamente, sem<br>relato de meta-análise deste<br>subgrupo exclusivo|
|a Surrogate.|||||||
|||Original, dois|||||
|2 - Heller et al.<br>Diabet Med 2016, 33(4):478-87. A<br>meta-analysis of rate ratios for<br>nocturnal confirmed hypoglycaemia<br>with insulin<br>degludec vs. insulin glargine using<br>different definitions for<br>hypoglycaemia.|Meta-análise de 6 ECRs<br>multicêntricos,<br>controlados, abertos, fase<br>3a, objetivando tratar até<br>o alvo,com 26-52<br>semanas de duração|estudos em<br>DMtipo 1:<br>Glargina, n=316,<br>Degludeca, n=637<br>Extensão,dois<br>estudos em DM<br>tipo 1:<br>Glargina, n=316,<br>Degludeca, n=801|Glargina<br>vs.degludeca|Hipoglicemiasno<br>turnas|Menores taxas de hipoglicemia<br>noturna com degludeca vs.<br>glargina (97 a 203<br>episódios/100 PYE,<br>dependendo da definição)|Não realizada revisão<br>sistemática previamente à<br>meta-análise|
||Revisão sistemática com|36 d  DM|Programas|HbA1c,|Redução HbA1c (-0,29%, 95%|Avaliação de todos os|
|**3 - Pillay et al. Ann Intern Med**<br>**2015, 163(11):836-47.**|meta-análise de ECRs,<br>ensaios clínicos não<br>randomizados, coortes,|estuos em<br>tipo 1, 31 eram<br>ECRs|comportament<br>ais_vs._cuidado<br>usual|qualidade de<br>vida,<br>complicações|CI, -0,45 to -0,13 para cuidado<br>usual;  -0,44%, CI, -0,69 a -<br>0,19 paratratamento ativo) em|estudos considerada como<br>médio e alto risco de<br>vieses; metanalisar estudos|  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|**Behavioral Programs for Type 1**|estudos tipo antes e|||crônicas do|6 meses. Sem diferenças após|de diferentes desenhos|
|**Diabete melito: A Systematic**|depois|||diabetes,|12 meses.|experimentais é|
|**Review and**||||mortalidade,||metodologicamente|
|**Meta-analysis.**||||aderência ao<br>tratamento,<br>mudanças na<br>composição<br>corporal,<br>atividade, física,<br>ingestão<br>nutricional.||questionável.|
|||||Glicemia de|||
|**4 - Akbari et al. J Endocrinol**||||jejum, glicemia|||
|**Invest 2016, 39(2):215-25.**||11 estudos (n =||pós-prandial,|Sem diferença nos desfechos||
|**Efficacy and safety of oral insulin**<br>**compared to subcutaneous**|Revisão sistemática com<br>meta-análise de ECRs|373), 5 em DM<br>tipo 2, 6 em DM|Insulina oral<br>vs. insulina|insulinemia.|primários entre as vias de<br>administração das insulinas,|Grandes variações<br>metodológicas entre os|
|**insulin: a**||tipo 1.|subcutânea|Desfechos|exceto pela rapidez maior de|estudos.|
|**systematic review and meta-**||||secundários:|ação da insulina oral.||
|**analysis.**||||eventos adversos|||
|**5 - ojciechowski et al.  Pol Arch**<br>**Med Wewn 2015, 125(3):141-51.**<br>**Clinical efficacy and safety of**<br>**insulin aspart compared with**<br>**regular human**|Revisão sistemática com<br>meta-análise de ECRs|16 estudos, 11 em<br>DM tipo 1<br>(n=3447)|Insulina<br>regular vs.<br>insulina aspart|HbA1c<br>Glicemias pós-<br>prandiais<br>Hipoglicemias,<br>hipoglicemias<br>graves,|Maior redução da HbA1c com<br>aspart (-0,11%; 95% CI, -0.16<br>to -0.05). Menor glicose pós-<br>prandial com aspartvs. regular<br>(desjejum: -1.40 mmol/l; 95%<br>CI, -1,72 to -1.07, almoço, -<br>1.01 mmol/l; 95% CI, -1,61 to|4 ECRs recrutaram<br>crianças|  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|**insulin in patients with type 1 and**||||hipoglicemias|-0.41, e jantar, -0.89 mmol/l;||
|**type 2 diabetes: a systematic**<br>**review and**<br>**meta-analysis.**||||noturnas|95% CI, -1,19 a -0,59).<br>Menor risco de hipoglicemia<br>noturna com aspart (RR 0,76;<br>95% CI, 0,64-0,91)<br>Sem diferença quanto ao risco<br>de hipoglicemia grave entre as<br>insulinas||
||||||Maior redução da HbA1c com<br>dietas de baixo índice||
|**6 - Wang et al. Prim Care**|||||glicêmico (-0,42, 95%CI=-0,69||
|**Diabetes, 2015, 9(5):362-9.**<br>**Effects comparison between low**<br>**glycemic index diets and high**<br>**glycemic index diets**<br>**on HbA1c and fructosamine for**<br>**patients with diabetes: A**<br>**systematic review and**<br>**meta-analysis.**|Revisão sistemática com<br>meta-análise de ECRs e<br>estudos de caso-controle|19 estudos, n=840,<br>5 em DM tipo 1<br>(n=191)|Dietas com<br>baixo índice<br>glicêmico vs.<br>com alto<br>índice<br>glicêmico|HbA1c<br>Frutosamina|a -0,16, P<0,01).<br>Maior redução da frutosamina<br>com dietas de baixo índice<br>glicêmico<br>(-0,44, 95%CI=-0,82 a -0,06,<br>P=0,02).<br>Apenas DM tipo 1, 11 estudos:<br>Sem diferença entre as dietas<br>(HbA1c -0,17, 95%CI=-0,77 a<br>0,44)|Análises principais<br>agregam dados de DM tipo<br>1 e DM tipo 2; n muito<br>pequeno quando<br>considerados apenas<br>pacientes com DM tipo 1|
|**7 - Yardley et al. Diabetes Res**<br>**Clin Pract 2014, 106(3):393-400.**<br>**A systematic review and meta-**<br>**analysis of exercise interventions**<br>**in adults with**<br>**type 1 diabetes.**|Revisão sistemática com<br>meta-análise de ECRs|6 ECRs em DM<br>tipo 1 (n=323)|Exercício<br>aeróbico ou<br>de força vs.<br>controle por<br>no mínimo 2|HbA1c<br>Capacidade<br>funcional<br>Dose de insulina<br>IMC<br>Eventos adversos|Redução da HbA1c no grupo<br>exercício vs.controle (-0,78%<br>(9 mmol/mol), 95% CI 1,14<br>(13 mmol/mol) a 0,41 (5<br>mmol/mol); p < 0,0001).|A meta-análise principal<br>envolveu 4 estudos, e 280<br>participantes; dos 191 do<br>grupo exercício, 148 eram<br>de um único estudo. Neste<br>estudo o treinamento era|  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
||||meses, 2|||combinado (aeróbico + de|
||||vezes/semana|||força); nos demais, o<br>treinamento era de força.<br>Risco de vieses não claro.|
|||||||Não reportadas<br>hipoglicemias.<br>Grupos controle não<br>tinham visitas frequentes –<br>o efeito da intervenção<br>poderia ter se devido<br>apenas à maior frequência<br>de contato com<br>profissionais de saúde.|  
ECR = ensaio clínico randomizado; CI = Intervalo de confiança; TFG = Taxa de filtração glomerular; Hba1c = Hemoglobina Glicada; DM = diabete melito; PYE = patients-years of expouse; IMC = índice de massa corpora.  
**Tabela 2** - Busca Embase para tratamento  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
||||**Controle**||||
|1 - Khalifah et al.|Revisão sistemática e|Pacientes com DM tipo|Todos pacientes em uso|Desfecho primário:|A adição de Metformina|Apenas 6 ECR, média|
|Pediatric Diabetes|meta-análise de ECRs|1 com idade entre 6 a 19|de insulina, grupo ativo|HbA1c, desfechos|reduziu a dose total de|de idade: 15 anos. Não|
|(2017).||anos de idade. n=325|recebeu Metformina na|secundários:qualidade|insulina em unit/kg/d= -|há descrição do tipo de|
|The effect of adding|||dose que variou de 1000|de vida, IMC, perfil|0.15, IC 95%, -0,24, -|insulina utilizada.|
|metformin to insulin|||a 2000mg vs. controle|lipídico, dose total de|0,06), e reduziu IMC|Variação de tempo de|
|therapy for type 1|||com placebo.|insulina e frequência de|kg/m<sup>2</sup>(-1,46, IC 95%: -|seguimento entre 3 e 9|
|diabetes||||cetoacidose diabética.|2,54, 0,38), e efeito|meses.|
|mellitus children: A|||||semelhante na HbA1c|.|
|systematic review and|||||= - 0,05%, IC 95% -||
|meta-analysis|||||0,19, 0,29).||
|2 - Guo et al. Diabetes|Revisão sistemática e|Pacientes com DM tipo|Grupo ativo usando|Desfechos primários:|O uso de inibidores de|Apenas 6 ECR, 4|
|Research and Clinical|meta-análise de ECRs|1, n=228.|inibidores DPP4 e|HbA1c e dose total de|PP4 não reduziu HbA1c|estudos com|
|Practice 2016, 121 (184-|com estudos em paralelo||insulina vs. grupo|insulina e frequência de|-0,0 (IC 95% -0,16,|Sitagliptina, 1 com|
|191).|ou crossover.||controle apenas com|hipoglicemias como|0,15), mas foi associado|Vildagliptina e 1 com|
|The efficacy and safety|||insulina.|desfecho secundário.|a menor dose de|Saxagliptina. Um estudo|
|of DPP4 inhibitors in|||||insulina - 2,|incluiu pacientes com|
|patients with type 1|||||41UI/Kg/dia (IC95% -|diabetes tipo 1 do|
|diabetes:|||||3,87, -0,94), Sem|adulto. Não relatam|
|A systematic review and|||||redução de|tipos de insulina em uso.|
|meta-analysis|||||hipoglicemias.||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|3 - Ashrafian et al.|Revisão sistemática e|Pacientes obesos com|Intervenção cirúrgica|Desfechos: redução de|A cirurgia bariátrica|Sem descrição do tipo|
|Obesity Surgery (2016)<br>26:8 (1697-1704).|meta-análise de estudos<br>retrospectivos.|DM tipo 1 n=142|em todos os pacientes,<br>sem grupo controle.|peso, HbA1c, dose total<br>de insulna.|produziu redução de<br>peso corporal: 37kg(IC|de insuina utilizada.|
|Type 1 Diabete melito<br>and Bariatric Surgery: A|||||95%: 23,9-50), redução<br>de HbA1c 0,78% (IC||
|Systematic Review and|||||95%: 0,3-1,24), redução||
|Meta-Analysis|||||de dose de insulina<br>0,30UI/Kg/dia (0,17-<br>1,44) e redução dos<br>níveis de PAS, PAD,<br>triglicerídeos e LDL e<br>aumento dos níveis de<br>HDL.||
|4 - Viana et al. Trials|Revisão sistemática e|Pacientes com DM tipo|Intervenções:|HbA1c|Apenas a intervenção|Sem descrição do tipo|
|(2016) 17:1|meta-análise de ECRs|1, n=1782.|psicológica ou||psicológica mostrou|de insulina utilizada.|
|Interventions to improve|||telecuidados ou||redução na HbA1c||
|patients' compliance|||educação ou||−0.310%; (IC 95%,||
|with therapies aimed at<br>lowering glycated|||psicoeducação.||−0.599 a −0.0210).||
|hemoglobin (HbA1c) in<br>type 1 diabetes:<br>Systematic review<br>and meta-analyses of<br>randomized controlled<br>clinical trials of|||||||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|psychological,<br>telecare, and educational<br>interventions|||||||
|5 - Chow et al. Journal|Revisão sistemática e|Pacientes obesos com|Intervenção cirúrgica|Desfechos: redução de|Ocorreu redução do|Não há descrição do|
|of Obesity (2016) A|meta-análise|DM tipo 1, IMC maior|em todos os pacientes,|IMC, HbA1c, dose total|IMC de 42,50±2,65|tipo de insulina usada.|
|Systematic Review and||ou igual a 35kg/m2 .|sem grupo controle.|de insulna.|kg/m2 para 29±1,76,|_Bypass_gástrico em Y de|
|Meta-Analysis of||n=86. Seguimento: 12|||redução de dose total de|Roux- ocorreu em 69%|
|Outcomes for Type 1||meses|||insulina de 98± 26|dos pacientes,|
|Diabetes after|||||UI/dia para 36± 15 e|gastrectomia_sleeve_foi|
|Bariatric Surgery|||||redução de HbA1c<br>8,46±0,78% para 7,9±<br>0,55 todos de maneira<br>significativa.|feita em 15%  e<br>derivação biliodigestiva<br>em 14%.|
|6 - Liu et al.|Revisão sistemática e|Pacientes com DM tipo|Todos pacientes em uso|Desfecho primário:|Redução da HbA1c em|5 ECRs, não descreve|
|International Journal of|meta-análise de ECRs|1, n=301.|de insulina, grupo ativo|HbA1c,|favor do grupo|tipos de insulina em uso.|
|Endocrinology (2016).|||recebeu Metformina na||metformina −0,37%, (IC||
|The Effect of Metformin|||dose que variou de 1000|Desfechos secundários:,|95%: −0,64,−0,09), bem||
|on Adolescents with|||a 2000mg vs. controle|IMC, peso, dose total de|como redução no IMC e||
|Type 1 Diabetes: A|||com placebo.|insulina|peso respectivamente:||
|Systematic|||||−0,36, (IC 95%: −0,59,||
|Review and Meta-|||||−0,14); e −1,93, (IC||
|Analysis of Randomized|||||95%: −2,58, −1,27) e||
|Controlled Trials|||||redução da dose total de<br>insulina  -0,11 UI/kg/d||
||||||(IC 95%: -0,15-0,06).||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|7 - Dawoud et al.|Revisão sistemática e|DM tipo 1.|Sete grupos de|HbA1c, frequência de|Insulina determir duas|Publicação de resumo|
|Value in Health (2015)|meta-análise de ECRs||tratamento: Insulina|hipoglicemias e análise|vezes/dia reduziu a|em anais de congresso.|
|18:7 (A339). Basal|||NPH 1 ou 2 ou 4|de custo-efetividade.|HbA1c em -0,48% vs.|Sem descrição do|
|insulin regimens:|||veses/dia, insulina||insulina NPH até 4x/dia|número de pacientes por|
|Systematic review,|||Detemir 1 ou 2x/dia,||reduziu em –0,01%. A|grupo estudado.|
|network meta-analysis,|||Insulina Glargina e||insulina Determir foi a||
|and|||Insulina Degludeca.||insulina mais custo||
|cost-utility analysis for|||||efetiva entre as insulinas||
|the National Institute|||||avaliadas.||
|For Health and Care|||||||
|Excellence (NICE)|||||||
|Clinical guideline on<br>type 1 diabete melito in<br>adults|||||||
|8 - Liu et al.|Revisão sistemática e|DM tipo 1. n=300.|Todos pacientes em uso|Dose de insulina, peso|Redução da dose de|8 ECRs. Não há|
|Diabetes Technology|meta-análise de ECRs||de insulina, grupo ativo|corporal, perfil lipídico,|insulina - 1.36 UI/dia|descrição do tipo de|
|and Therapeutics (2015)|||recebeu Metformina na||(IC 95%:,- 2,28-0,45),|insulina usada.|
|17:2 (142-148)|||dose que variou de 500||redução de peso||
|Efficacy and safety of|||a 2000mg vs. controle||corporal – 2,41kg (||
|metformin for patients|||com placebo.||IC95%: - 4,17-0,65), em||
|with type 1 diabete|||||favor do grupo da||
|melito:|||||Metformina, bem como||
|A meta-analysis|||||mínimas reduções no||
||||||perfil lipídico em favor<br>da Metformina.||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|9 - Bell et al.|Revisão sistemática e|DM tipo 1 uso de|Contagem de|HbA1c|No geral, não houve|599 adultos e 104|
|The Lancet Diabetes|Meta-análise de ECRs|múltiplas doses de|carboidratos_vs._dieta||redução na HbA1c –|crianças com DM tipo 1.|
|and Endocrinology||insulina ou bomba de|convencional||0,35% (IC 95%:  –0,75,|Não há descrição do|
|(2014) 2:2 (133-140).||insulina.|||0,06). Porém, nos|tipo de insulina usada.|
|Efficacy of|||||pacientes adultou||
|carbohydrate counting|||||ocorreu uma redução||
|in type 1 diabetes: A|||||significativa em favor||
|systematic review|||||da contagem de||
|and meta-analysis|||||carboidratos:0,64%<br>(IC95%: - 0,91, -0,37).||
|10 - Jones et al.|Revisão sistemática e|Pacientes com diabetes,|Intervenção|HbA1c|Não ocorreu beneficio|Elevada|
|Primary Care Diabetes|meta-análise de ECRs|sendo n=1223 com dm|motivacional (sessões||no grupo ativo: 0,17% (-|heterogeneidade entre|
|(2014) 8:2 (91-100).||tipo 1 e n=1895 com dm|de aconselhamento que||0,09, 0,43).|os artigos, sem|
|Motivational||tipo 2|variaram entre 15 a 60|||separação entre o tipo|
|interventions in the|||minutos) ao longo de 5 a|||de DM.|
|management of HbA1c|||12 meses de||||
|levels: A systematic|||seguimento.||||
|review and meta-|||||||
|analysis|||||||
|11 - Kähler et al. BMJ|Revisão sistemática e|DM tipo 1, n=2254.|Tratamento intensivo de|Avaliação de todas as|Não houve diferença|Sem avaliação sobre o|
|Open (2014) 4:8|Meta-análise de ECRs||insulina vs. tratamento|causas de mortalidade,|significativa no controle|tipo de insulina. A|
|Targeting intensive|||convencional|morte cardiovascular,|glicêmico intensivo em|análise de TSA mostrou|
|versus conventional||||doença microvascular,|relação ao desfecho de|poder insuficiente para|  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|glycaemic control for||||neoplasias, IMC, peso,|mortalidade geral (RR|diferenças de 10%.|
|type 1||||hipoglicemias, custos,|1,16, IC 95%: 0,65 ,||
|diabete melito: A||||efeitos adversos,|2,08) ou para||
|systematic review with||||qualidade de vida e|mortalidade||
|meta-analyses and trial||||cetoacidose diabética.|cardiovascular (RR||
|sequential analyses of|||||0,49, IC 95%: 0,19,||
|randomised clinical|||||1,24). Ocorreu redução||
|trials|||||do desfecho<br>macrovascular||
||||||composto e nefropatia||
||||||respectivamente:  0,63<br>IC 95%: 0,41, 0,96) e<br>RR: 0,37 (IC 95%:||
||||||0,27,0,50). O risco de||
||||||hipoglicemia foi maior||
||||||no grupo intensivo: RR<br>1.40 (IC 95%: 1,01-||
||||||1,94).||
|12 - Schmidt et al.|Revisão sistemática e|DM tipo 1 uso de|Contagem de|HbA1c, peso,|Redução na HbA1c|Sem avaliação sobre o|
|Diabetic Medicine|Meta-análise de ECRs e|múltiplas doses de|carboidratos_vs._dieta|hipoglicemias,|variou de 0,0%–1,2%|tipo de insulina.|
|(2014) 31:8 (886-896).|estudos observacionais|insulina ou bomba de|convencional nos ECR||em favor da contagem||
|Effects of advanced||insulina.|||de carboidratos e||
|carbohydrate counting|||||redução de||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
||||**Controle**||||
|in patients with Type 1|||||hipoglicemias, sem||
|diabetes:|||||diferença no peso||
|A systematic review|||||corporal.||  
**Tabela 3** Busca Cochrane para tratamento  
|**Referencia**|**Desenho**||**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|---|
|||||||Retinopatia:<br>6,2%<br>_vs._||
|**1 - Fullerton et al.**||||||23,2%, RR 0,27 (95% CI||
|**Cochrane Database of**|||||Redução<br>do<br>risco<br>de|0,18 a 0,42; P < 0,00001)||
|**Systematic**<br>**Reviews**<br>**2014,**<br>**2.**<br>**Intensive**<br>**glucose control versus**<br>**conventional glucose**|Revisão<br>sistemática<br> <br>meta-análise<br>ECRs|com<br>de|12 ECRs em DM1<br>(n=2230),<br>com<br>seguimento mínimo de<br>1 ano|Controle<br>glicêmico<br>com diferentes alvos|aparecimento<br>de<br>complicações crônicas do<br>diabetes<br>com<br>controle<br>glicêmico mais intensivo|Doença renal do diabetes:<br>6,3%_vs._28,4%; RR 0,56<br>(95% CI 0,46 a 0,68; P <<br>0,00001)|Eventos cardiovasculares<br>foram raros, portanto não<br>puderam ser considerados|
|**control for type 1**<br>**diabete melito**|||||_vs._menos intensivo|Neuropatia: 4,9%_vs._13,9%;<br>RR 0,35 (95% CI 0,23 a<br>0,53; P < 0,00001).||
|||||||Redução de HbA1c com<br>CGM+BISI||
|**2 - Langendam et al.**<br>**Cochrane Database of**<br>**Systematic**<br>**Reviews**<br>**2012, 1. Continuous**<br>**glucose**<br>**monitoring**<br>**systems for type 1**<br>**diabete melito**|Revisão<br>sistemática<br> <br>meta-análise<br>ECRs|com<br>de|22<br>ECRs<br>em<br>DM1incluídos na RS;<br>8<br>ECRs<br>em<br>DM1<br>incluídos<br>na<br>meta-<br>análise|Qualquer<br>tipo<br>de<br>sistema<br>de<br>monitorização<br>glicêmica (CGM)_vs._<br>monitorização<br>glicêmica<br>convencional.|HbA1c<br>Hipoglicemias<br>Episódios de cetoacidose<br>Qualidade de vida<br>Satisfação<br>com<br>o<br>tratamento|_vs._MDI+glicemia capilar: -<br>0,7%, 95% CI -0,8% a -<br>0,5%, 2 ECRs; n= 562, I<sup>2</sup><br>84%.<br>Redução de HbA1c com<br>CGM_vs._glicemia capilar:<br>-0,2%, 95% CI -0,4% a -<br>0,1%,<br>6<br>ECRs,<br>n=963,<br>I<sup>2</sup>=55%.||  
|**Referencia**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|**3 - Vardi et al.**<br>**Cochrane Database of**<br>**Systematic**<br>**Reviews**<br>**2008, 3. Intermediate**<br>**acting**<br>**versus**<br>**long**<br>**acting insulin for type**<br>**1 diabete melito**|Revisão<br>sistemática<br>com<br>meta-análise<br>de<br>ECRs|23 ECRs em DM1<br>(análogos<br>de<br>longa<br>duração, n= 3872 e<br>NPH,<br>n=<br>2915,<br>controle)|Insulina<br>NPH<br>_vs._<br>Análogos de insulina<br>de longa duração|HbA1c<br>Glicemia jejum<br>Hipoglicemias<br>Ganho de peso<br>Mortalidade relacionada ao<br>tratamento<br>Mortalidade relacionada ao<br>diabetes<br>Mortalidade total<br>Qualidade de vida<br>Complicações crônicas do<br>diabetes|Redução de HbA1c com<br>análogos de insulina de<br>longa duração: -0,08 (95%<br>CI -0,12 to -0,04); I<sup>2</sup>=79%.||
|||||HbA1c<br>Glicemia jejum|||
|**4 - Misso et al.**||||Glicemia pós-prandial|||
|**Cochrane Database of**<br>**Systematic**<br>**Reviews**<br>**2010, 1. Continuous**<br>**subcutaneous insulin**<br>**infusion (CSII) versus**<br>**multiple**<br>**insulin**<br>**injections for type 1**<br>**diabete melito.**|Revisão<br>sistemática<br>com<br>meta-análise<br>de<br>ECRs (_crossover_<br>ou em paralelo)|23 ECRs em DM1<br>(n=976)|BISI<br>vs.<br>múltiplas<br>doses de insulina|Hipoglicemias<br>Qualidade de vida<br>Peso<br>Dose de insulina<br>Eventos adversos<br>Mortalidade total<br>Complicações crônicas do<br>diabetes<br>Custos|Redução de HbA1c com<br>BISI(-0,25% 95% CI -0,1 a<br>-0,4)I<sup>2</sup>=50%.<br>Sem<br>diferença<br>para<br>hipoglicemias||  
|**Referencia**|**Desenho**||**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|---|
|**5 - Fullerton et al.**<br>**Cochrane Database of**<br>**Systematic**<br>**Reviews**<br>**2016, 6. Short-acting**<br>**insulin**<br>**analogues**<br>**versus regular human**<br>**insulin for adults with**<br>**type 1 diabete melito**|Revisão<br>sistemática<br> <br>meta-análise<br>ECRs|com<br>de|9 ECRs em DM1,<br>mínimo 24 semanas<br>seguimento (n=2693)|Insulina<br>regular<br>_vs._<br>Análogos de insulina<br>de curta duração|Mortalidade<br>Desfechos<br>cardiovasculares<br>Hipoglicemias graves<br>HbA1c<br>Eventos adversos<br>Qualidade de vida<br>Custos|Redução de HbA1c com<br>análogo de curta duração (-<br>0,15% 95% CI -0,2% a -<br>0,1%; P < 0,00001)<br>I<sup>2</sup>=0%.<br>Sem diferenças na chance de<br>hipoglicemias graves||
|**6 - Abdelghaffar et al.**<br>**Cochrane Database of**|||||HbA1c<br>Eventos adversos<br>Qualidade de vida|||
|**Systematic**<br>**Reviews**<br>**2009, 1. Metformin**<br>**added**<br>**to**<br>**insulin**<br>**therapy for type 1**<br>**diabete**<br>**melito**<br>**in**<br>**adolescents.**|Revisão<br>sistemática<br> <br>meta-análise<br>ECRs|com<br>de|2<br>ECRs<br>em<br>adolescentes<br>com<br>DM1, mínimo 3 meses<br>seguimento (n=60)|Metformina + Insulina<br>_vs._Insulina apenas|Dose de insulina<br>IMC<br>Lipídios séricos<br>Sensibilidade<br>insulínica<br>(clamp)<br>Custos<br>Mortalidade|Sugere que a metformina<br>melhore<br>o<br>controle<br>glicêmico|Não foi feita meta-análise<br>pela heterogeneidade dos<br>dados|  
RS: Revisão sistemática; BISI: Bomba de infusão subcutânea de insulina; DM1 = diabete melito tipo 1; DM2 = diabete melito tipo 2; IMC = índice de massa corporal  
**Tabela 4** - Busca Medline para diagnóstico.  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|1 - Floyd B et|Revisão|- Número de|-<br>Intervenção:|Determinar<br>(1)<br>a|- Oito estudos utilizaram CGM em tempo real e|- Muitos estudos pequenos foram|
|al.|Sistemática|e<br>ECRs: 14|monitoramento|eficácia e segurança|oito estudos utilizaram CGM retrospectivo|incluídos (n variava de 11 a 322|
|J<br>Diabetes|Meta-análise||glicêmico contínuo|do CGM e SMBG|- Comparado com SMBG, CGM foi associado|pacientes)|
|SciTechnol||- Número de|(CGM)|retrospectivos e em|com uma redução significativa de HbA1c|- Avaliação de qualidade do|
|2012,||pacientes:||tempo<br>real;<br>(2)|[∆HbA1c -0,5% ± 0,5% (_P_=0,002) versus -0,2%|estudos classificou a maioria deles|
|6(5):1094-102.||1.188|-<br>Controle:|diferenças<br>no|± 0,3% (_P_=0,006); p=.006 entre os grupos] e uma|como com boa qualidade (Escore|
|Comparative|||Automonitorament|controle<br>glicêmico|redução incremental de Hb1Ac de 0,3% -0,3, -|de Jadad médio = 3)|
|analysis of the||- 97,4% DM|o<br>glicêmico|entre o CGM em|0,2),_P_<0.0001)|-<br>Sem<br>viés<br>de<br>publicação|
|efficacy<br>of||tipo 1|(SMGB)|tempo<br>real<br>e|- Frequência de hipoglicemia não foi diferente|identificado|
|continuous||||retrospectivo|entre os grupos, porém a duração dos episódios|- Não estavam disponíveis os dados|
|glucose|||||foi menor no grupo CGM, com uma redução na|individuais<br>para<br>meta-análise,|
|monitoring and|||||duração dos episódios de -15,2 min/dia,|somente os resultados dos estudos|
|self-|||||P<0,0001|-<br>Apesar<br>de<br>estatisticamente|
|monitoring of|||||- Sem diferenças nos resultados de pacientes com|significativos, os resultados são|
|blood glucose|||||menos e mais de 25 anos|clinicamente pouco importantes|
|in<br>type<br>1||||||(redução de HbA1c e tempo de|
|diabete melito.||||||hipoglicemia)|
|2 - Szypowska|Revisão|- Número de|-<br>Intervenção:|- Desfecho primário:|- Houve uma redução significativa nos níveis de|-<br>Estudos<br>pequenos<br>foram|
|et al. Eur J|Sistemática|e<br>ECRs: 7|Monitoramento|níveis de HbA1c|HbA1c (MD -0,25% IC95% -0,34 a -0,17;|incluídos (n variava de 28 a 154|
|Endocrinol|Meta-análise||glicêmico contínuo||_P_<0,001)<br>nos<br>pacientes<br>com<br>RT-CGM|pacientes)|
|2012,||- Número de|em<br>tempo<br>real|-<br>Desfechos|comparada com os pacientes com SBGM.|- Apenas dois dos 7 estudos|
|166(4):567-74.||Pacientes: 948|(RT-CGM)|secundários:|- Essa redução foi observada também nos|fizeram análise por intenção de|
|Beneficial||||hipoglicemias|pacientes em uso de bomba de insulina, pacientes|tratar e a maioria apresentava ao|
|effect of real-||- Todos com|-<br>Controle:|maiores e menores,|com controle metabólico considerado bom e|menos<br>uma<br>limitação|
|time||DM tipo 1|Automonitorament|área sob a curva do|ruim.|metodológica|
|continuous|||o<br>glicêmico|CGM média < 3,89||- Pela alta heterogeneidade dos|  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|glucose|||(SMGB)|mmol/l, área sobre a|- Não houve diferença em relação a frequência de|resultados<br>relacionados<br>a|
|monitoring||||curva<br>do<br>CGM|episódios de hipoglicemia maiores (6 RCTs,|hipoglicemia total, este desfecho|
|system<br>on||||média<br>><br>9,99|n=864, RR 0,69 IC 95% 0,41–1,14; P=0,15) ou|não foi metanalisado|
|glycemic||||mmol/l,<br>efeitos|menores.|-<br>Devido<br>as<br>diferenças<br>nos|
|control in type||||adversos e qualidade|- A área sob a curva do CGM média < 3,89|parâmetros utilizados para avaliar|
|1<br>diabetic||||de vida (QoL).|mmol/l foi significativamente reduzida nos|qualidade de vida, esses dados não|
|patients:|||||grupos<br>RT-CGM<br>comparado<br>a<br>pacientes|foram incluídos na meta-análise|
|systematic|||||monitorados com SBGM em dois estudos.|-<br>Apesar<br>de<br>estatisticamente|
|review<br>and|||||Outros autores não demonstraram diferença entre|significativo,<br>o<br>resultado<br>de|
|meta-analysis|||||os grupos.|redução da HbA1c é clinicamente|
|of|||||- Devido as diferenças nos parâmetros utilizados|pouco relevante|
|randomized|||||para avaliar qualidade de vida, esses dados não||
|trials.|||||foram incluídos na meta-análise.||
|3<br>-|Revisão|- Número de|-<br>Intervenção:|-<br>Desfechos:|- Em relação aos níveis de HbA1c no início dos|- Incluídos somente estudos com|
|Wojciechowsk|sistemática|e<br>ECRs: 14|monitoramento|mudança nos níveis|estudos, cinco estudos demonstraram uma|mais de 3 meses de duração|
|i et al. Pol Arch|meta-análise||glicêmico contínuo|de<br>HbA1c<br>em|melhora estatisticamente significativa no grupo|- A definição de hipoglicemia foi|
|Med<br>Wewn||- Número de|(CGM)|relação a baseline,|CGM comparado ao SMBG, e os 9 estudos|diferente entre os estudos, assim|
|2011,||pacientes:||HbA1c ao fim do|restantes não demonstraram diferença entre os|como a medida de associação desse|
|121(10):333-||1.268|-<br>Controle:|estudo, porcentagem|grupos.|desfecho. Tudo isso limitou a sua|
|43.|||Automonitorament|de<br>pacientes|- Pacientes usando CGM tiveram uma maior|avaliação.|
|Efficacy<br>and||- Todos com|o<br>glicêmico|atingindo<br>HbA1c|diminuição nos níveis de HbA1c em relação a|-<br>Novamente<br>estudos<br>muito|
|safety||DM tipo 1|(SMGB)|alvo, e número e|baseline comparados com aqueles usando SMBG|<br>pequenos foram incluídos|
|comparison of||||duração de episódios|(0,26%  IC95% –0,34 a –0,19]|- Vários dos estudos incluídos|
|continuous||||de<br>hipo<br>e|- A magnitude dos efeitos foi similar em crianças|apresentavam<br>limitações|
|glucose<br>monitoring and||||hiperglicemia|e adolescentes comparados a adultos|metodológicas|  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|self-|||||- Quando avaliados os diferentes tipos de CGM,|- Foram incluídos no grupo CGM|
|monitoring of|||||apenas dispositivos de CGM em tempo real|dois métodos: retrospectivo e|
|blood glucose|||||demonstraram melhora no controle glicêmico|prospectivo,<br>que<br>apresentaram|
|in<br>type<br>1|||||-<br>Resultados<br>conjuntos<br>de<br>4<br>estudos|resultados diferentes|
|diabetes:|||||demonstraram uma redução no número de|-<br>Apesar<br>de<br>estatisticamente|
|systematic|||||eventos hipoglicemiantes no grupo CGM (–0,32|significativos, o tamanho de efeito|
|review<br>and<br>meta-analysis.|||||IC9% –0,52 a –0,13)|dos resultados é pequeno|
|4 - Lopes Souto|Revisão|- Número de|Exposição<br>em|-<br>Desfechos:|- Não foi realizada meta-análise, somente|- A revisão sistemática está|
|et al. NutrHosp|Sistemática|estudos:<br>13|estudo:<br>atividade|controle<br>glicêmico|descrição sumária dos artigos encontrados|pobremente descrita, assim como|
|2011,||estudos|física|em pacientes com|(tabela 1 do artigo)|os resultados, limitando a sua|
|26(3):425-9.||observacionais||T1DM.|- Dois estudos observaram associação da|interpretação e análise|
|Physical|||||atividade física com níveis de HbA1c|- Não foi realizada meta-análise de|
|excercises<br>on|||||- Três estudos não observaram associação de|nenhum<br>desfecho,<br>somente|
|glycemic|||||atividade<br>física<br>com<br>diversos<br>desfechos|relatados os estudos encontrados|
|control in type|||||relacionados ao controle glicêmico|- Não é descrita qualidade dos|
|1<br>diabete||||||artigos, avaliação de viés de|
|melito.||||||publicação|
|||||||-<br>Pelas<br>diversas<br>falhas|
|||||||metodológicas descritas acima,<br>essa RS deve ter seus resultados<br>vistos com muito cuidado|
|5 - Szypowska|Revisão|- Número de|-<br>Intervenção:|- Primários: níveis de|- Redução da HbA1c (-0,073 IC95% -0,135 a -|- Somente foram incluídos ECRs|
|et al. Pol Arch|sistemática|e<br>ECRs: 10|análogo detemir|Hb1Ac|0,011 P = 0,021) no grupo detemir comparado|com mais de 12 semanas de|
|Med<br>Wewn.|meta-análise||||com o grupo NPH. Também houve redução|duração|
|2011<br>Jul-||- Número de|- Controle: insulina|-<br>Secundários:|significativa na glicose plasmática de jejum (-||
|Aug;121(7-||pacientes:|NPH|glicemia de jejum,|0,977 mmol/l  IC95% -1,395 a -0,558 P<0,001)||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|8):237-46.||3.825||peso,<br>episódios|- Houve também redução nos desfechos|- Os ECRs não eram cegados e|
|Long-acting||||hipoglicêmicos|relacionados<br>a<br>hipoglicemia:<br>episódios|vários deles apresentavam outras|
|insulin||- Todos com||graves,<br>episódios|hipoglicêmicos em um dia (RR 0,978 IC95%|limitações metodológicas|
|analogue||DM tipo 1||hipoglicêmicos<br>em|0,961 a 0,996), episódios hipoglicêmicos graves|- Praticamente todos os estudos|
|detemir||||um dia, episódios|(RR 0,665 IC95% 0,547 a 0,810), episódios|contaram com verba da indústria|
|compared with||||hipoglicêmicos|hipoglicêmicos noturnos (RR 0,877  IC95%|farmacêutica|
|NPH insulin in||||noturnos greves|0,816 a 0,942)|-<br>A<br>diferença<br>observada<br>no|
|type<br>1|||||- Menor ganho de peso (-0,779 kg  IC95% -0,992|desfecho primário (HbA1c, -0,073)|
|diabetes:<br>a|||||a<br>-0,567)<br>em<br>pacientes<br>usando<br>detemir|é muito pequena|
|systematic|||||comparado com NPH||
|review<br>and<br>meta-analysis.|||||||
|6 - Pickup et al.|<br>Revisão|- Número de|-<br>Intervenção:|- Primários: Hb1Ac e|- Melhora dos níveis de HbA1c naqueles|- Somente incluídos estudos com|
|BMJ<br>2011,|sistemática|e<br>ECRs: 6|monitoramento|área abaixo da curva|pacientes randomizados para uso de CGM:|mais de dois meses|
|343:d3805.|meta-análise||glicêmico contínuo|de hipoglicemia|−0,30%  IC95% −0,43% a −0,17%|- Utilizados dados individuais dos|
|Glycaemic||- Número de|(CGM)||- Esta melhora foi maior nos pacientes com|pacientes|
|control in type||pacientes: 892||-<br>Secundários:|HbA1c maior no início dos estudos e que mais|- Estudos não cegados|
|1<br>diabetes|||-<br>Controle:|hipoglicemia grave|frequentemente usaram os sensores|- Foram feitos diversos modelos|
|during<br>real||- Todos com|Automonitorament||- Em relação à hipoglicemia, a redução da área|matemáticos de redução de HbA1c|
|time||DM tipo 1|o<br>glicêmico||sob a curva de hipoglicemia foi de -0,28 nos|e hipoglicemias que devem ser|
|continuous|||(SMGB)||pacientes em uso de CGM, correspondendo a|vistos com cuidado|
|glucose|||||uma redução de 23%|- Os resultados relacionados a|
|monitoring||||||hipoglicemia também devem ser|
|compared with||||||vistos com cuidado|
|self monitoring|||||||
|of<br>blood|||||||
|glucose: meta-|||||||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**||**Resultados**|**Observações**|
|---|---|---|---|---|---|---|---|
|analysis<br>of<br>randomised<br>controlled||||||||
|trials<br>using<br>individual||||||||
|patient data.||||||||
|7 - González|Revisão|- Número de|Intervenção:|Desfechos<br>|fetais|- Não foi observada diferença em relação ao|-Foram somente incluídos estudos|
|Blanco et al.|sistemática|e<br>Estudos:<br>4,|análogo lispro|(abortos, nasci|mento|controle glicêmico, desfechos obstétricos e fetais|observacionais<br>(coortes|
|Diabetes|meta-análise|todos||pretermo,<br>|idade|- O único desfecho diferente entre os grupos foi|retrospectivas)|
|TechnolTher||observacionais|Controle: insulina|gestacional,|peso,|o risco de fetos grandes para idade gestacional,|- Pequeno número de estudos (4)|
|2011,|||regular|macrossomia,||que foi maior no grupo que usou lispro (RR 1,38||
|13(9):907-11.||- Número de||mortalidade,||IC95% 1,14-1,68)||
|Glycemic||pacientes: 786||malformações,||||
|control<br>and||||hipoglicemia)||||
|pregnancy||- Todas com||of life)||||
|outcomes<br>in||DM tipo 1 e||||||
|women<br>with||gestantes||||||
|type 1 diabete||||||||
|melito||||||||
|using||||||||
|lisproversus||||||||
|regular insulin:||||||||
|a<br>systematic||||||||
|review<br>and||||||||
|meta-analysis.||||||||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|8 - Hood et al.|<br>Revisão|- Número de|Exposição|- Primários: controle|- Correlação média entre aderência e controle|-<br>Incluídos<br>somente<br>estudos|
|Pediatrics|sistemática|e<br>estudos|estudada:|glicêmico|glicêmico foi de -0,28 (IC95% -0,32 a -0,24), ou|observacionais|
|2009,|meta-análise|incluídos: 21|aderência<br>ao||seja, conforme aderência aumenta, Hb1Ac||
|124(6):e1171-|||tratamento||diminui.||
|9. Association||- Número de|||||
|between||pacientes:|||||
|adherence and||2.492|||||
|glycemic|||||||
|control<br>in||- Todas com|||||
|pediatric type 1||DM tipo 1 e|||||
|diabetes:||menores de 19|||||
|a<br>meta-||anos|||||
|analysis.|||||||
|9 - Monami et|Revisão|- Número de|Intervenção:|- Primários: nível de|- Redução significativa da HbA1c quando em uso|- Incluídos somente estudos com|
|al.<br>Diabetes|sistemática|e<br>ECRs|análogo de longa|HbA1c|de insulinas de longa ação (-0,07  IC 95% -0,13%|mais de 12 semanas de duração|
|ObesMetab|meta-análise|incluídos: 20|ação||a -0,01%, P=0,026)|- Maioria<br>dos<br>estudos<br>foram|
|2009,||||- Secundarios: IMC.|- Aumento no IMC no grupo em uso de análogos|patrocinados por fabricantes de|
|11(4):372-8.||- Número de|Controle: insulina|Hipoglicemias|em relação à NPH (+0,26 IC 95% 0,06-0,47|análogos de longa-ação|
|Long-acting||pacientes:|NPH|sintomáticas,|kg/metro quadrado, P=0,012)|- Diferença nos critérios para|
|insulin||6.178||noturnas, graves ou|- O número de pacientes experimentando pelo|hipoglicemia<br>devem<br>ser|
|analogues<br>vs.||||totais|menos um episódio de hipoglicemia foi 264 no|considerados<br>quando<br>em|
|NPH<br>human||- Todos com|||grupo de longa-ação e de 225 no grupo NPH (RR|interpretação dos resultados desse|
|insulin in type||DM tipo 1|||0,73, IC95% 0,60-0,89, P=0,002). A incidência|desfecho|
|1 diabetes. A|||||de hipoglicemia noturna foi menor no grupo de||
|meta-analysis.|||||longa-ação (RR 0,69 IC95% 0,55-0,86, P=0,001)||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|10 - Golicki et|Revisão|- Número de|-<br>Intervenção:|- Primário: controle|- Sem diferença nos níveis de HbA1c (-0,02%|- Pequeno número de estudos e|
|al.|sistemática<br>|e<br>ECRs|monitoramento|glicêmico (HbA1c)|IC95% -0,29 a 0,25 P=0,87)|participantes.|
|Diabetologia.|meta-análise|incluídos: 5|glicêmico contínuo||- Um estudo somente avaliou o nível de|- Sem cegamento.|
|2008,|||(CGM)|- Secundários: nível|frutosamina, sem diferença entre os grupos|- Qualidade geral dos estudos foi|
|51(2):233-40.||- Número de||sérico<br>de|- Não foram relatados episódios de hipoglicemia|baixa, especialmente comparada|
|Continuous||pacientes: 131|-<br>Controle:|frutosamina,|grave em nenhum ECR|com estudos em desenvolvimento|
|Glucose|||Automonitorament|episódios<br>de|- Somente um estudo avaliou hipoglicemias|de novos medicamentos.|
|Monitoring||- Crianças com|o<br>glicêmico|hipoglicemia|menores sem diferença entre os grupos|- Resultados muito limitados pelas|
|System<br>in||DM tipo 1|(SMGB)|maiores e menores,|- Os desfechos áreas sob e sobre a curva foram|diversas falhas metodológicas dos|
|children<br>with||||área média da curva|também somente avaliados em um estudo, sem|estudos incluídos.|
|type 1 diabete||||diária<br>sobre|diferenças entre os grupos||
|melito:<br>a||||controle contínuo <|||
|systematic||||3,89mmol/l,<br>área|||
|review<br>and||||média<br>diária<br>da|||
|meta-analysis.||||curva<br>sobre<br>controle contínuo >|||
|||||9,99mmol/l.|||
|||||Ajustes na dose de|||
|||||insulina,<br>efeitos|||
|||||adversos locais e<br>aderência.|||
|11 - Winkley et|Revisão|- Número<br>de|-<br>Intervenção:|- Primário: Controle|- Incluídos 10 ECRs em crianças que mostraram|- Diversas terapias psicológicas|
|al. BMJ 2006,|sistemática<br>|e<br>ECRs|alguma<br>terapia|glicêmico<br>(medido|redução da HbA1c no grupo submetido a|foram incluídas em um único grupo|
|333(7558):65.|meta-análise|incluídos: 29|psicológica|por HbA1c)|alguma terapia psicológica (-0,35 IC95% -0,66|intervenção|
|Psychological|- Critérios<br>d|e<br>na RS e 21 na|||a -0,04),  o que seria equivalente a -0,48% de|-Alta subjetividade para avaliação|
|interventions to|Elegibilidade:|metanalise|- Controle:||redução absolita na HbA1c|dos desfechos secundários|
|improve|- Objetivo:||tratamento||- Em 11 estudos com adultos a diferença não foi|- Sem possibilidade de cegamento,|  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**<br>**Controle**|**Desfechos**|**Resultados**|**Observações**|
|---|---|---|---|---|---|---|
|glycaemic|Determinar se|- Número de|padrão do DM|-<br>Secundários:|estatisticamente significativa (-0,17 IC95% -|pela característica da intervenção|
|control<br>in|intervenções|pacientes:|tipo 1|Medição continua de|0,45 a 0,10), o que seria equivalente a 0,22% -|- Alta heterogeneidade entre os|
|patients<br>with|psicológicas|1.059||angústia psicológica|0,13 a 0,56% na redução absoluta da HbA1c|estudos|
|type<br>1|tem<br>algum||||- Angústia psicológica foi menor nos grupos|-<br>Maioria<br>dos<br>estudos<br>com|
|diabetes:|efeito sobre o|- Todos com|||intervenção<br>de<br>crianças<br>e<br>adolescentes|qualidade ruim ou mediana|
|systematic|controle|DM tipo 1|||(tamanho de efeito padronizado -0,46 IC95% -|- Evidência de baixa qualidade|
|review<br>and|glicêmico<br>em||||0,83 a -0,10) mas não em adultos (-0,25 IC95%||
|meta-analysis|pacientes com||||-0,51 a 0,01)||
|of randomised<br>controlled|DM tipo 1.||||||
|trials.|||||||
|12 - Palmer et|Meta-análise|- Número<br>de|Intervenção:|Custo-efetividade do|- Baseados nos resultados da meta-análise, que|-<br>Não<br>foi<br>realizada<br>revisão|
|al. Curr Med|sem<br>revisão|estudos|analógo detemir|tratamento<br>com|observou melhora da HbA1c, diminuição de|sistemática|
|Res Opin 2004,|sistemática|incluídos:<br>4||insulina Detemir em|hipoglicemias e peso|- Aplicados valores do sistema de|
|20(11):1729-||ECRs|Controle: insulina|aplicação|- Utilizado modelo de Markov, com custos|saúde britânico|
|46|||NPH|Basal/Bolus<br>para|diretos e indiretos baseados no sistema britânico|-<br>Validade<br>externa<br>muito|
|Cost-||- Número de||aplicação no sistema|de saúde|prejudicada|
|effectiveness||pacientes:||de saúde britânico|- Diminuição das complicações do DM e||
|of<br>detemir-||1.336|||aumento de 0,09 QUALY, com custo de 19.285||
|based|||||libras esterlinas por QUALY||
|basal/bolus||- Todos<br>com|||||
|therapy versus||DM tipo 1|||||
|NPH-based|||||||
|basal/bolus|||||||
|therapy<br>for|||||||
|type 1 diabetes|||||||
|in a UK setting:|||||||  
|**Referência**|**Desenho**|**Amostra**|**Intervenção/**|**Desfechos**||**Resultados**|**Observações**|
|---|---|---|---|---|---|---|---|
||||**Controle**|||||
|an<br>economic||||||||
|analysis||||||||
|based on meta-<br>analysis results||||||||
|of four clinical||||||||
|trials.||||||||
|13 - Davey et|Revisão|- Número de|Intervenção:|Glicemia|pós-|- Em pacientes com DM tipo 1 observou-se|- Descrição do estudo e da revisão|
|al.<br>ClinTher|sistemática|e<br>ECRs|analógo lispro|prandial,|excursão|diminuição dos níveis pós-prandiais de glicemia|sistemática<br>muito<br>pobre|
|1997,|meta-análise|incluídos: 8||glicêmica|pós-|para <8 mmol/L, níveis de glicemia pós-prandial|(possivelmente em função da época|
|19(4):656-74.|||Controle: insulina|prandial de|2 horas,|após 2 horas dentro de 20% do nível pré-refeição|em que foi feito/publicado)|
|Clinical||- Número de|regular|hipoglicemi|as|e diminuição de pelo menos 50% da linha de base|- Incluídos somente estudos com|
|outcomes with||participantes:||||na excursão glicêmica pós-prandial de 2 horas|mais de 6 meses de duração e mais|
|insulin<br>lispro||2.361||||(OR 0,95-1,37; 95% CI; P=0,15).|de 30 pacientes|
|compared with|||||||- Incluídos pacientes com DM tipo|
|human regular||- Pacientes com|||||1 e tipo 2|
|insulin:<br>a||DM<br>tipo<br>1:|||||- A meta-análise foi realizada|
|meta-analysis.||1.344|||||utilizando<br>apenas 6 dos 8 ECR de fase III.<br>- Desfechos de pouca importância<br>clínica|
||||||||- Estudo com muitas limitações|

---

