<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 6, DE 2 DE JULHO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Síndrome de Ovários Policísticos.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso das atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a Síndrome de Ovários Policísticos no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta síndrome;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 434/2019 e o Relatório de Recomendação n<sup><u>o</u></sup> 445 – Abril de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Síndrome de Ovários Policísticos.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da síndrome de ovários policísticos, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas</u> Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da síndrome de ovários policísticos.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa síndrome em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º Fica revogada a Portaria n<sup>o</sup> 1.321/SAS/MS, de 21 de novembro de 2013, publicada no Diário Oficial da União nº 230, de 27 de novembro de 2013, seção 1, páginas 146 a 150.  
FRANCISCO DE ASSIS FIGUEIREDO DENIZAR VIANNA  
ANEXO

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1. INTRODUÇÃO** -->
A Síndrome de Ovários Policísticos (SOP) é uma doença multifatorial que se caracteriza por alterações hiperandrogênicas e reprodutivas. Sua etiologia é complexa, com influência da predisposição genética e de fatores ambientais (1,2). As principais manifestações incluem acne, hirsutismo, alopecia, alterações menstruais e infertilidade.  
Além disso, podem haver alterações metabólicas, como o maior risco de obesidade, pré-diabete, diabete mélito tipo 2, dislipidemia, apneia obstrutiva do sono, doença hepática gordurosa não alcoólica, distúrbios de humor e câncer (3,4). Além da infertilidade, mulheres com SOP têm maior taxa de abortamento espontâneo, assim como maior risco de complicações obstétricas, como diabete mélito gestacional, doença hipertensiva específica da gravidez, pré-eclâmpsia e partos prematuros, quando comparadas à população feminina geral (5).  
A SOP é considerada a endocrinopatia mais frequente em mulheres em idade reprodutiva, acometendo cerca de 6%-19% dessa população, dependendo do critério diagnóstico adotado (6).  A sua caracterização diagnóstica é realizada pela presença de ao menos dois entre três dos seguintes critérios: anovulação crônica, hiperandrogenismo e morfologia ovariana policística (7). Entretanto, sua apresentação clínica é bastante heterogênea, e diversos são os fenótipos da doença (8,9). Como a etiologia da SOP não está totalmente esclarecida e não há um teste diagnóstico específico, a SOP é considerada um diagnóstico de exclusão. Resistência insulínica e obesidade, embora não façam parte dos critérios diagnósticos, são achados frequentes e potencializam as diferentes manifestações da síndrome  (10).  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
O tratamento envolve o controle dos sintomas hiperandrogênicos, regularização dos ciclos menstruais e proteção endometrial. Para todas as pacientes, modificações do estilo de vida e o controle das anormalidades metabólicas devem ser sempre recomendadas (11,12).  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da SOP. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **(CID-10)** -->
- E28.2 Síndrome dos ovários policísticos  
- L68.0 Hirsutismo

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.1. Critérios de Inclusão** -->
Serão incluídas neste Protocolo Clínico e Diretrizes Terapêuticas (PCDT) as pacientes que tiverem o  
diagnóstico de SOP, de acordo com os critérios do Consenso de Rotterdam.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.2. Critérios de exclusão** -->
Serão excluídas deste PCDT as pacientes que apresentarem outras doenças que causem hiperandrogenismo ou oligo/amenorreia (tumores produtores de androgênios, hiperprolactinemia, síndrome de Cushing, tireopatias, uso de medicamentos associados com hirsutismo e hipogonadismo, ou hiperplasia adrenal congênita).  
Pacientes gestantes ou aquelas que apresentem hipersensibilidade, intolerância ou contraindicação conhecida aos medicamentos também serão excluídas.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **4. DIAGNÓSTICO** -->
O Consenso de Rotterdam, de 2003, estabelece que a SOP seja diagnosticada pela presença de pelo menos dois dos seguintes critérios (7,13):  
1. Alteração dos ciclos menstruais: presença de 9 ciclos ou menos no período de um ano;  
2. Hiperandrogenismo clínico: presença de um ou mais dos seguintes achados: Acne, hirsutismo e alopecia de padrão androgênico ou Hiperandrogenismo laboratorial, este caracterizado por elevação de pelo menos um androgênio [testosterona total, androstenediona e sulfato de desidroepiandrosterona sérica (SDHEA), de acordo com os valores de referência do _kit_ utilizado];  
3. Morfologia ovariana policística à ultrassonografia (US): presença de mais de 12 folículos antrais (entre 2 e 9 mm) em pelo menos um dos ovários ou volume ovariano de ≥ 10 cm<sup>3</sup> .  
A inclusão do achado ultrassonográfico como critério diagnóstico promoveu o aumento na detecção da SOP (14,15). A contagem de folículos antrais à US aumentou de mais que 12 para mais que 25, quando são utilizados aparelhos de maior resolução. Quando houver dificuldade na contagem acurada de folículos, deve ser utilizado o volume ovariano de ≥ 10 cm<sup>3</sup> em pelo menos um dos ovários. O ovário que apresente folículo dominante (≥ 10 mm) ou corpo lúteo não deve ser considerado, e o exame deve ser repetido (11,12). A SOP pode se manifestar por meio de quatro fenótipos (16), conforme caracterizado no **Quadro 1** .  
**Quadro 1 –** Classificação dos principais fenótipos da Síndrome de Ovários Policísticos  
|**Fenótipo**|**A**|**B**|**C**|**D**|
|---|---|---|---|---|
|**Oligo- ou amenorreia**|+|+|-|+|
|**Hiperandrogenismo clínico**|+|+|+|-|
|**ou laboratorial**|||||
|**Ovários policísticos à**<br>**ultrassonografia**|+|-|+|+|  
Fonte: Critério de Rotterdam 2003 (7).  
Quanto ao uso de hormônio anti-mulleriano (HAM) como método diagnóstico, as evidências demonstram boa correlação entre os seus níveis e a contagem de folículos. Dessa forma, sua dosagem tem sido proposta como substituto da contagem de folículos pela US no diagnóstico da SOP. Os níveis de HAM também se correlacionam com o volume ovariano e com a distribuição periférica dos folículos, aumentando o valor preditivo positivo para o diagnóstico dessa síndrome (16). Entretanto, os estudos avaliados utilizaram técnicas distintas para sua quantificação e não estabelecem de forma conclusiva os pontos de corte para positividade do exame. Assim, ainda não é possível recomendar sua dosagem como critério diagnóstico de SOP em substituição ao diagnóstico por US.  
O diagnóstico de SOP é confirmado após exclusão de outras causas de hiperandrogenismo. As seguintes dosagens séricas são recomendadas: de 17-OHP, de hormônio tireoestimulante (TSH), de prolactina e de hormônio folículo-estimulante (FSH), quando da suspeita clínica de hiperplasia adrenal congênita, tireopatia, hiperprolactinemia e insuficiência ovariana primária, respectivamente. (7) Na suspeita de síndrome de Cushing ou de tumores secretores de androgênios, a conduta é encaminhar para um endocrinologista. No **Quadro 2** encontram-se os exames indicados para exclusão de outras causas de hiperandrogenismo ou rastrear a presença de risco metabólico.  
**Quadro 2 –** Exames para exclusão de outras causas de hiperandrogenismo ou rastrear a presença de risco metabólico  
|Testosterona total|
|---|
|17-hidroxiprogesterona|
|Prolactina sérica|
|Glicemia de jejum|
|Glicemia após sobrecarga de 75 g de glicose|
|(para mulheres obesas ou com história familiar de diabete mélito)|
|Sulfato de deidroepiandrostestoterona (DHEA-S)<br>(em caso de suspeita de tumor adrenal)|
|Hormônio tireoestimulante (TSH)|  
Colesterol total, colesterol HDL e triglicerídeos  
(para pacientes com suspeita de síndrome metabólica)  
NOTA: Os resultados podem variar de acordo com o método utilizado.  
Adaptado de The Rotterdam ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group (7).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.3.** **_Diagnóstico em adolescentes_** -->
No período pós-puberal, os sinais e sintomas sugestivos da SOP se sobrepõem aos que ocorrem na puberdade normal. Há também grande variabilidade na apresentação clínica nessa etapa do desenvolvimento. Em consequência, não é recomendado o uso de uma manifestação clínica ou hormonal específica para o diagnóstico de SOP em adolescentes (17-21). Da mesma forma, os parâmetros ultrassonográficos ovarianos para o diagnóstico da SOP ainda não foram estabelecidos por estudos com boa qualidade de evidência. Uma limitação adicional é o uso do US pélvico transabdominal, que apresenta pior desempenho que o transvaginal, principalmente em adolescentes obesas (20,22-25). No entanto, há evidências de que adolescentes que apresentam simultaneamente hiperandrogenismo e distúrbio menstrual têm maior chance de ter confirmada a SOP na idade adulta (26).  
Desta forma, considerando o baixo nível de evidência descrito acima, recomenda-se aplicar para adolescentes (de 2 anos pós-menarca até 19 anos incompletos) o critério diagnóstico que considera a presença dos três componentes do Consenso de Rotterdam (ciclos oligo/amenorreicos/anovulatórios, hiperandrogenismo clínico ou laboratorial e morfologia ovariana policística, em adolescentes após a menarca e excluídas outras causas para hiperandrogenismo ou distúrbio menstrual) (27).  
Salienta-se que, para evitar o sub-diagnóstico de SOP em adolescentes, é possível postergar o diagnóstico para depois dos 18 anos completos, a partir da reavaliação clínica e laboratorial, considerando os critérios vigentes para mulheres adultas. Neste caso, e após exclusão de outras causas, é recomendado tratar os sintomas como distúrbio menstrual e hirsutismo, independentemente do diagnóstico definitivo de SOP (26,27).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **_5._ METODOLOGIA** -->
A descrição da metodologia científica do presente PCDT (questões de pesquisas definidas pelos especialistas na reunião de definição de escopo, elaboração das estratégias de busca, descrição do fluxo de seleção das evidências científicas e as tabulações dos dados das características dos participantes, características dos estudos e desfechos de eficácia e segurança, quando aplicável) encontra-se detalhada no **Apêndice 1** .

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **_1.4.1. Modificação de estilos de vida_** -->
A modificação do estilo de vida deve ser recomendada para todas as doentes de SOP e inclui as seguintes medidas: cessação do tabagismo e do uso abusivo de álcool, prática de atividade física regular  
e alimentação saudável. Para as pacientes com sobrepeso ou obesidade e, principalmente, se associados a comorbidades metabólicas, é recomendável a redução do peso corporal. A recomendação inicial para todas as doentes de SOP associada a comorbidades metabólicas, portanto, não difere daquela usada para a população em geral. Ou seja, obesidade, dislipidemia, hipertensão, doença hepática gordurosa não alcoólica, apneia do sono e os estados de hiperglicemia devem ser tratados seguindo as diretrizes para cada condição específica (11,12,27). Durante o tratamento da obesidade em caso de mulheres com SOP pode ser necessário o acompanhamento por equipe multiprofissional.  
Em relação às mulheres com SOP e que desejam gestar, recomenda-se o aconselhamento préconcepcional e medidas para o controle de condições e cessação de hábitos inadequados (28), tais como o controle da obesidade e a cessação do consumo de tabaco e de bebidas alcoólicas. As outras medidas preventivas de agravos associados ao período gestacional, que são indicadas para as gestantes em geral, também devem ser seguidas por aquelas que têm SOP.  
As modificações do estilo de vida que favorecem a redução de peso corporal em mulheres com sobrepeso e obesas com SOP podem melhorar as taxas de ovulação. Além disso, o controle prégestacional adequado de peso em mulheres com SOP poderia reduzir o risco gestacional de anomalias congênitas (defeitos cardíacos e do tubo neural), diabete mélito gestacional, síndrome hipertensiva (principalmente pré-eclâmpsia), macrossomia, restrição de crescimento intrauterino, abortamentos e prematuridade (5,29). É recomendada a perda de pelo menos 5% a 10% do peso corporal, pois essa medida está associada à melhora da obesidade central, hiperandrogenismo e taxas de ovulação de mulheres com SOP (30-32), embora ainda não se tenha comprovado a sua eficácia no aumento da taxa de nascidos vivos (33).  
Embora não estejam disponíveis estudos com boa qualidade de evidência, a remoção temporária pode ser recomendada enquanto se aguarda a resposta do tratamento medicamentoso. No entanto, pode ocorrer irritação, dor e foliculite, além da necessidade de repetir os procedimentos frequentemente (34, 35).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.5.1.** **_Irregularidade menstrual_** -->
Os anticoncepcionais hormonais combinados (AHC) constituem a primeira linha de tratamento de mulheres com SOP que não desejam gestar e que apresentem irregularidade menstrual com ou sem hirsutismo, mesmo em casos que não requeiram contracepção. Anticoncepcionais hormonais combinados que contêm 30 ou 35 µg de etinilestradiol (EE2) podem reduzir o hirsutismo leve a moderado (27,36-38). Entretanto, há poucos estudos que utilizaram doses menores de estrogênios. Uma meta-análise evidenciou que AHCs contendo 20 µg de EE2 podem ser efetivos para tratar hirsutismo leve (39). Com relação ao componente progestogênico, embora o acetato de ciproterona e a drospirenona, um derivado da espironolactona, apresentem boa atividade antiandrogênica, as evidências atuais indicam que qualquer AHC oferece supressão androgênica similar, proteção endometrial e regularização dos ciclos menstruais quando utilizados de forma cíclica (27,36,40-43).  
Além disso, os AHCs garantem a contracepção, o que é fundamental quando utilizados em associação com antiandrogênios.  
Os benefícios contraceptivos e não contraceptivos de longo prazo dos AHC sobrepõem-se aos riscos para mulheres com SOP, se os critérios de elegibilidade para seu uso são considerados (38). Entretanto, potenciais efeitos adversos metabólicos e eventos tromboembólicos constituem uma preocupação quando da sua prescrição (44). Por outro lado, evidências atuais indicam que os AHC não promovem alterações significativas na glicemia em jejum, na resistência insulínica, no índice de massa corporal (IMC) ou na pressão arterial, mas apenas alterações discretas no perfil lipídico (45-47).  
Desta forma, deve-se basear a elegibilidade para os AHC nos critérios da Organização Mundial da Saúde (OMS) (48), estando as recomendações estabelecidas para o uso de AHC em mulheres com SOP a seguir, quando se apresentam os fármacos e os esquemas de administração.  
A presença de comorbidades metabólicas e fatores de risco cardiovasculares podem contraindicar o uso de AHC. Por isso, em mulheres com SOP e obesidade grave, síndrome metabólica, hipertensão arterial sistêmica, hipertrigliceridemia, diabete com mau controle ou complicações crônicas, o risco de usar AHC pode ser maior do que o benefício ou até mesmo inaceitável (48).  
As evidências atuais indicam que a metformina, em paralelo com suas ações metabólicas que melhoram a sensibilidade à ação da insulina, pode reduzir a secreção de androgênios pelos ovários e melhorar ou restaurar a ciclicidade menstrual (49-51). Os efeitos são mais evidentes se associados a medidas de alterações de estilo de vida (50). Assim, a metformina é recomendada como agente sensibilizador da ação da insulina para o tratamento de segunda linha das irregularidades menstruais em mulheres com SOP que apresentem alterações metabólicas e distúrbio menstrual, e nas quais as mudanças de estilo de vida tenham falhado em restaurar o padrão cíclico das menstruações. A metformina é segura, não é contraceptiva e pode induzir ciclos ovulatórios. Portanto, é recomendável garantir a contracepção para pacientes com SOP e em uso de metformina, mas que não desejam gestar **.**

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.5.2. Hiperandrogenismo clínico** -->
Para o tratamento do hirsutismo clínico de graus moderado e grave, recomenda-se utilizar um antiandrogênico, associado a AHC (52,53). As evidências disponíveis não permitem identificar superioridade de um antiandrogênico em relação a outro. Caso haja contraindicação de AHC, recomenda-se associar o antiandrogênico com a metformina, nas pacientes com distúrbios metabólicos. O antiandrogênico de escolha é o acetato de ciproterona, sendo o único que apresenta indicação para SOP em bula (54).  
A prescrição de antiandrogênio sem a associação com AHC requer o uso concomitante de método contraceptivo eficaz em mulheres sexualmente ativas, a fim de prevenir a feminização de um feto masculino e, por isto, os antiandrogênios também não devem ser administrados em mulheres gestantes ou que planejam gestar.  
O acetato de ciproterona é um progestogênio que, em doses mais elevadas (50 mg), exerce efeito antigonadotrófico (55). Doses diárias de 25-50 mg, 20 dias por mês, combinadas com AHC ou com  
estrogênio, são efetivas para o tratamento da acne (56) e do hirsutismo moderado ou grave em mulheres com SOP (53,55,57). O acetato de ciproterona é geralmente bem tolerado, mas observam-se efeitos adversos dependentes da dose, que incluem ganho de peso e diminuição da libido (55).  
Embora a metformina possa ser utilizada como tratamento de segunda linha para reduzir a secreção de testosterona, não exerce efeito sobre o hirsutismo e, portanto, o seu uso não é recomendado para o tratamento dessa condição (58-60). ( **Figura 1** )  
<!-- Start of picture text -->
Mulheres com SOP<br>Hirsutismo leve Hirsutismo Moderado Hirsutismo Grave<br>Modificações de estilo de<br>vida Antiandrogênio:<br>+<br>AHC Acetato de ciproterona<br>Contraindicação para<br>AHC<br>Metformina + Antiandrogênio<br>(garantir contracepção )<br>Se  presente  tratar:<br>Hipertensão  arterial,<br>dislipidemia e diabete<br>mélito.<br><!-- End of picture text -->  
**Figura 1 –** Fluxograma de tratamento de mulheres com Síndrome de Ovários Policísticos. Adaptado de Spritzer (61).  
AHC = Anticoncepcionais hormonais combinados

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.5.3. Comorbidades metabólicas** -->
Ações que levem à redução da resistência insulínica têm efeitos benéficos nas doentes de SOP (8,62,63). A metformina é recomendada em mulheres com SOP que têm contraindicação ou que não atingiram as metas de controle metabólico com o uso de AHC. As doses mais altas (até 2,50g/dia), quando toleradas, devem ser indicadas, por levar a resultados melhores em relação a dose inferior (1,5g/dia) (27,64-66).  
As tiazolidinedionas (rosiglitazona e pioglitazona) não são recomendadas em mulheres com SOP, por não haver evidência de superioridade delas em relação à metformina, em termos de parâmetros metabólicos e hormonais (49). É importante salientar que a pioglitazona pode levar a ganho de peso, devido à retenção hídrica, e tem potencial teratogênico, não devendo ser utilizada (67).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.5.4. Cirurgia bariátrica** -->
Melhora clínica na SOP tem sido observada com perda ponderal de apenas 5% do peso corporal (47). Entretanto, a redução de peso corporal significativa pode ser difícil de ser alcançada e mantida, especialmente nas pacientes com obesidade grave. Por isto, a cirurgia bariátrica torna-se uma opção de tratamento para pacientes com SOP, especialmente aquelas que falham nas tentativas clínicas de controle da obesidade.  
Apesar da baixa qualidade metodológica, os estudos evidenciaram, de forma quase unânime, benefícios relacionados à redução ponderal, parâmetros hormonais (como FSH, LH, HAM e androgênios) e parâmetros metabólicos (como perfil lipídico e glicemia), além de melhoria no hirsutismo, redução no volume ovariano, na ciclicidade menstrual e na fertilidade. Tais estudos utilizaram técnicas cirúrgicas distintas, que potencialmente poderiam influenciar os resultados. As mais comumente usadas foram a banda gástrica ajustável, o _by pass_ gástrico em Y de Roux (Cirurgia à Fob Capella) e a gastrectomia vertical ( _Sleeve_ ). As respostas positivas ao procedimento cirúrgico foram independentes das técnicas utilizadas (68). Estes estudos tiveram seguimento curto, usualmente em torno de 12 meses, não permitindo avaliar as consequências a longo prazo do procedimento cirúrgico. Da mesma forma, a avaliação da segurança do procedimento também ficou prejudicada pela escassez de dados. Mais dados sobre eficácia e segurança deste procedimento para o tratamento da obesidade associada a SOP são necessários.  
A cirurgia bariátrica pode ser indicada para doentes de SOP, considerando os critérios adotados no âmbito do SUS.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Anticoncepcionais hormonais** -->
Etinilestradiol mais levonorgestrel: comprimidos de 0,03 mg + 0,15 mg.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Progestogênios** -->
Acetato de medroxiprogesterona: comprimidos de 10 mg.  
Noretisterona: comprimidos de 0,35 mg.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Antiandrogênio** -->
Ciproterona: comprimidos de 50 mg.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Sensibilizador da ação de insulina** -->
Metformina: comprimidos de 500/850 mg de liberação normal.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Anticoncepcionais hormonais:** -->
Etinilestradiol mais levonorgestrel: 1 comprimido de 0,03 mg + 0,15 mg ao dia por 21 dias/mês. Doses elevadas (3 a 4 comprimidos ao dia) e decrescentes podem ser utilizadas por curtos períodos (4 a 5 dias) para controle de sangramento disfuncional.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Progestogênios:** -->
Acetato de medroxiprogesterona: 1 comprimido de 10 mg ao dia por 10 a 12 dias do ciclo menstrual. Noretisterona: 1 comprimido de 0,35 mg ao dia em uso contínuo (efeito anticoncepcional).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Antiandrogênios:** -->
Acetato de ciproterona: 12,5 mg, 25mg ou 50 mg/dia, por via oral, no esquema 21/7 (utilizar por 21 dias e fazer intervalo de 7 dias para o período menstrual), em associação ao anticoncepcional oral.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Metformina:** -->
Iniciar com 500 mg, por via oral após o jantar; aumentar 500 (1.000 mg/ semana até o máximo de 2,550 g/dia, se necessário). Dividir a dose em 2 ou 3 vezes ao dia para melhorar a tolerância, em caso de metformina de liberação rápida. Em caso da metformina de liberação prolongada, utilizar 1.000 mg 1 a 2 vezes ao dia.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.7.** **_Tempo de tratamento e critérios de interrupção_** -->
O tratamento deve ser contínuo, enquanto a paciente não deseja gestar. A taxa de recorrência de hirsutismo dentro de 6 meses após a suspensão do tratamento é de 80% (69). Naquelas pacientes que modificam o estilo de vida e perdem peso, a metformina pode ser suspensa. A avaliação das pacientes em relação ao uso diário de medicamentos e à melhora do hirsutismo e da regularização dos ciclos menstruais, entretanto, varia com o passar da idade, e é possível ajustar doses ou mesmo suspender um ou mais medicamentos. Desejo de engravidar é indicação, mesmo que temporária, de suspensão do tratamento.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **8. BENEFÍCIOS ESPERADOS** -->
Os benefícios esperados do tratamento incluem a regularização dos ciclos menstruais (já nos primeiros meses de tratamento), diminuição da quantidade, textura e distribuição de pelos, melhora ou resolução da acne e outras manifestações androgênicas (após pelo menos 6 a 12 meses de tratamento), redução do peso corporal e melhora das alterações metabólicas relacionadas com a resistência insulínica e redução do risco de hiperplasia ou carcinoma de endométrio.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **9. EFEITOS ADVERSOS** -->
Os medicamentos são bem tolerados, com baixa ocorrência de eventos adversos significativos.  
No início do tratamento, podem manifestar-se náusea e turgência mamária relacionadas com uso de AHC, desconforto abdominal, náusea e diarreia associada ao uso de metformina, que melhoram com o decorrer do uso.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **10. MONITORAMENTO** -->
Na vigência de AHC, recomenda-se um seguimento inicial após 3 meses e, depois, a cada 6 meses. Espera-se sangramentos de privação nas pausas do AHC e redução progressiva do hirsutismo. Avaliam-se o peso, a IMC e o diâmetro da cintura, bem como a presença de eventos adversos, como elevação da pressão arterial, desconforto mamário, cefaleia e varizes, entre outros. Níveis de testosterona sérica anuais devem se mostrar reduzidos em relação aos valores de antes do tratamento. Avaliação de fatores de risco cardiometabólicos, clínicos e laboratoriais deve ser realizada anualmente, principalmente no caso daquelas pacientes em que se recomendou mudanças de estilo de vida associadas ou não à metformina. Se a paciente está em uso de espironolactona, os níveis de potássio sérico devem ser monitorizados. Pacientes em que o diagnóstico não possa ser firmado ou que apresentem comorbidades metabólicas, hirsutismo grave, sinais de virilização ou níveis de testosterona acima de 2 desvios padrão do valor de referência da dosagem devem ser encaminhadas para serviço especializado em Endocrinologia.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.8.** **_Risco de neoplasia em mulheres com SOP_** -->
Os estudos que avaliaram o risco de neoplasia em mulheres com SOP apresentam limitações metodológicas significativas. Algumas comorbidades associadas a SOP (obesidade, hipertensão arterial sistêmica e diabete mélito tipo 2) podem elevar o risco de câncer (70).  
Os tipos de câncer ginecológicos mais frequentemente avaliados em mulheres com SOP são os de ovário, mama e endométrio. Os cânceres de mama (71,72) e ovário (71) não parecem ser mais prevalentes em doentes de SOP. Portanto, o rastreamento para neoplasia de mama em mulheres com SOP não difere da população geral, de acordo com a idade e outros fatores de risco adicionais associados a esta neoplasia.  
Entretanto, o câncer de endométrio é três vezes mais prevalente nas mulheres com anovulação crônica (4,71,73). Por outro lado, o uso de AHC por 4 a 12 anos reduz em 50% a 70% o risco de desenvolver câncer de endométrio (4). Embora a presença de SOP não esteja associada a maior risco para neoplasia de ovário, a oligomenorreia (ciclos com intervalo > 35 dias) ou amenorreia (ausência de fluxo menstrual por 6 ciclos) podem apresentar relação com o tipo histopatológico do câncer ovariano. Estes padrões menstruais podem estar associados a tumores _borderlines_ , mas não a neoplasias invasivas do ovário em mulheres com sobrepeso ou que nunca utilizaram contraceptivos hormonais (74).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **1.9.** **_Risco cardiovascular em mulheres com SOP_** -->
As mulheres com SOP apresentam prevalências mais altas de fatores de risco para doenças cardiovasculares. Proporção significativa destas pacientes é resistente à insulina e apresentam maiores concentrações de marcadores inflamatórios, diabete, hipertensão arterial, dislipidemia, síndrome metabólica e até mesmo de alterações angiográficas (como calcificação e alterações ecocardiográficas), quando comparadas às mulheres sem diagnóstico de SOP (8,11,75-77).  
Os estudos mais bem delineados e com menor risco de viés não demonstram incidência ou prevalência aumentada para a maioria dos desfechos cardiovasculares em populações com SOP, como infarto agudo do miocárdio (IAM), angina instável, insuficiência cardíaca, doença arterial coronariana (DAC), cirurgia de revascularização do miocárdio e maior tempo de internação hospitalar por causas cardiovasculares, ou mortalidade total e por causa cardiovascular (78-83). Por outro lado, estudos com alto risco de viés evidenciaram maior risco de IAM e DAC, demonstrando incerteza nessa associação (84, 85).  
Em relação ao risco para acidente vascular cerebral (AVC), os resultados são conflitantes, havendo uma tendência a um maior número de eventos neuro-isquêmicos nas portadoras da SOP (78,86). Por fim, há evidências confiáveis que associam a SOP ao maior risco de eventos tromboembólicos, mesmo ajustado para uso de contraceptivos orais e IMC (87-89).  
Diversas são as dificuldades para definir a exata relação entre a SOP e maior número de eventos ou mortalidade cardiovasculares. Primeiramente, pelo próprio diagnóstico da SOP, com seus diferentes fenótipos, que apresentam perfis de morbidade variáveis. Depois, pelas possíveis influências do diagnóstico precoce da síndrome, geralmente feito em mulheres adultas jovens, o que leva a maior busca pelo serviço de saúde e consequente maior oportunidade de tratamento e redução no risco de complicações cardiovasculares. Por fim, o efeito dos medicamentos utilizados para controle dos sintomas, como, por exemplo, pelo uso de AHC, pode influenciar o curso natural da doença.  
Principalmente devido à baixa qualidade metodológica dos estudos e elevado risco de viés, há dificuldade para afirmar-se a existência de maior risco para eventos cardiovasculares como IAM e AVC em mulheres com SOP, havendo apenas evidências de baixa qualidade.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **12. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Pacientes com suspeita de SOP devem ser encaminhadas para um serviço especializado em Ginecologia ou Endocrinologia, para seu adequado diagnóstico e inclusão no tratamento. Devem ser observados os critérios de inclusão e exclusão de pacientes neste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação do uso do medicamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Verificar no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP), disponível em <u>http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp, os exames</u>  
laboratoriais e procedimentos incluídos neste PCDT, além daqueles para acompanhamento pré- e póscirurgia bariátrica, para atendimentos de intercorrências clínica e cirúrgica pós-cirurgia bariátrica e de cirurgias plásticas pós-cirurgia bariátrica:

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Testosterona** -->
02.02.06.034-9 Dosagem de testosterona

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Androstenediona** -->
02.02.06.011-0 Dosagem de androstenediona

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **SDHEA** -->
02.02.06.014-4 Dosagem de dehidroepiandrosterona (DHEA) (Sulfato de dehidroepiandrosterona)

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Ultrassonografia** -->
02.05.02.016-0 - Ultrassonografia pelvica (ginecologica)  
02.05.02.018-6 - Ultrassonografia transvaginal

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **17-OHP** -->
02.02.06.004-7 Dosagem de 17-alfa-hidroxiprogesterona

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **TSH** -->
02.02.06.025-0 Dosagem de hormonio tireoestimulante (TSH)

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Prolactina sérica** -->
02.02.06.030-6 Dosagem de prolactina

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **FSH** -->
02.02.06.023-3 Dosagem de hormonio foliculo-estimulante (FSH)

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Glicemia** -->
02.02.01.047-3 Dosagem de glicose

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Glicemia após sobrecarga de glicose** -->
02.02.01.004-0 Determinacao de curva glicemica (2 DOSAGENS)

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Colesterol** -->
02.02.01.027-9 Dosagem de colesterol HDL  
02.02.01.029-5 Dosagem de colesterol total

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Triglicerídeos** -->
02.02.01.067-8 Dosagem de triglicerideos

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Cirurgia bariátrica** -->
04.07.01.012-2 - Gastrectomia c/ ou s/ desvio duodenal  
04.07.01.017-3 – Gastroplastia com derivação intestinal  
04.07.01.018-1 – Gastroplastia vertical com banda  
04.07.01.036-0 - Gastrectomia vertical em manga (Sleeve)  
04.07.01.038-6 - Cirurgia bariátrica por videolaparoscopia

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Espermograma** -->
02.02.09.021-3 - Pesquisa de anticorpos antiespermatozoides (ELISA) (espermograma)

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Histerossalpingografia** -->
02.04.05.006-5 – Histerossalpingografia

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **βHCG** -->
02.02.06.021-7 - Dosagem de gonadotrofina corionica humana (HCG, BETA HCG)

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **13. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE- TER** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e  
eventos adversos relacionados aos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER, assim como aos procedimentos indicados.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **14. REFERÊNCIAS** -->
1. de Melo AS DS, de Carvalho Cavalli R, Cardoso VC, Bettiol H, Barbieri MA, Ferriani RA, Vieira CS,. Pathogenesis of polycystic ovary syndrome: multifactorial assessment from the foetal stage to menopause. Reproduction. 2015;150(1):R11-24.  
2. Sir-Petermann T, Hitchsfeld C, Maliqueo M, Codner E, Echiburú B, Gazitua R, et al. Birth weight in offspring of mothers with polycystic ovarian syndrome. Human reproduction. 2005;20(8):2122-6.  
3. Baptiste CG BM, Trottier A, Baillargeon JP. Insulin and hyperandrogenism in women with polycystic ovary syndrome. The Journal of steroid biochemistry and molecular biology. 2010;122(1):4252.  
4. Dumesic DA, Lobo RA. Cancer risk and PCOS. Steroids. 2013;78(8):782-5.  
5. Qin JZ, Pang LH, Li MJ, Fan XJ, Huang RD, Chen HY. Obstetric complications in women with polycystic ovary syndrome: a systematic review and meta-analysis. Reproductive Biology and Endocrinology. 2013;11(1):56.  
6. Sirmans SM, Pate KA. Epidemiology, diagnosis, and management of polycystic ovary syndrome. Clinical epidemiology. 2014;6:1-13.  
7. The Rotterdam ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group. Revised 2003 consensus on diagnostic criteria and long-term health risks related to polycystic ovary syndrome. Fertility and sterility. 2004;81(1).  
8. Rosenfield RL, Ehrmann DA. The pathogenesis of polycystic ovary syndrome (PCOS): the hypothesis of PCOS as functional ovarian hyperandrogenism revisited. Endocrine reviews. 2016;37(5):467-520.  
9. Spritzer PM. Polycystic ovary syndrome: reviewing diagnosis and management of metabolic disturbances. Arquivos Brasileiros de Endocrinologia & Metabologia. 2014;58(2):182-7.  
10. Azziz R, Carmina E, Dewailly D, Diamanti-Kandarakis E, Escobar-Morreale HF, Futterweit W, et al. The Androgen Excess and PCOS Society criteria for the polycystic ovary syndrome: the complete task force report. Fertility and sterility. 2009;91(2):456-88.  
11. Goodman NF CR, Futterweit W, Glueck JS, Legro RS, Carmina E. American Association of Clinical Endocrinologists, American College of Endocrinology, and androgen excess and PCOS society disease state clinical review: guide to the best practices in the evaluation and treatment of polycystic ovary syndrome-part 1. Endocrine Practice. 2015;25(11):1291-300.  
12. Goodman NF CR, Futterweit W, Glueck JS, Legro RS, Carmina E. American Association of Clinical Endocrinologists, American College of Endocrinology, and Androgen Excess and PCOS Society Disease State clinical review: guide to the best practices in the evaluation and treatment of polycystic ovary syndrome-Part 2. Endocrine Practice. 2015b;21(12):1415-26.  
13. National Institutes of Health. Evidence-based methodology workshop on polycystic ovary syndrome. National Institutes of Health. December 3-5, 2012. .  
14. Broekmans FJ KE, Valkenburg O, Laven JS, Eijkemans MJ, Fauser BC. . PCOS according to the Rotterdam consensus criteria: change in prevalence among WHO‐II anovulation and association with metabolic factors. BJOG: An International Journal of Obstetrics & Gynaecology. 2006;113(10):1210-7.  
15. Aziz R CE, Dewailly D, Diamanti-Kandarakis E, Escobar-Morreale HF, Futterweit W. Position statement: criteria for defining polycystic ovary syndrome as a predominantly hyperandrogenic syndrome: an androgen excess society guideline. J Clin Endocrinol Metab. 2006;91:4237-45.  
16. Laven JS, Mulders AG, Visser JA, Themmen AP, De Jong FH, Fauser BC, et al. Anti-Mullerian hormone serum concentrations in normoovulatory and anovulatory women of reproductive age. The Journal of Clinical Endocrinology & Metabolism. 2004;89(1):318-23.  
17. Vries LWA, Phillipa M. Clinical Criteria Remain Paramount for the Diagnosis of Polycystic Ovary Syndrome in the Adolescent Age Group.  European Society for Paediatric Endocrinology2016.  
18. Hart R DD, Norman RJ, Franks S, Dickinson JE, Hickey M, Sloboda DM. Serum antimullerian hormone (AMH) levels are elevated in adolescent girls with polycystic ovaries and the polycystic ovarian syndrome (PCOS). Fertility and sterility. 2010;94(3):1118-21.  
19. Silfen ME DM, Manibo AM, Lobo RA, Jaffe R, Ferin M, Levine LS, Oberfield SE. Early endocrine, metabolic, and sonographic characteristics of polycystic ovary syndrome (PCOS): comparison between nonobese and obese adolescents. The Journal of Clinical Endocrinology & Metabolism. 2003;88(10):4682-8.  
20. Hickey M DD, Atkinson H, Sloboda DM, Franks S, Norman RJ, Hart R. Clinical, ultrasound and biochemical features of polycystic ovary syndrome in adolescents: implications for diagnosis. Human reproduction. 2011;26(6):1469-77.  
21. Villarroel C, López P, Merino PM, Iñiguez G, Codner E, Author A, et al. Evaluation of diagnostic criteria of polycystic ovary syndrome (PCOS) during adolescence. Hormone Research in Paediatrics. 2013;80 SUPPL. 1:172-3.  
22. Kenigsberg LE AC, Sin S, Shifteh K, Isasi CR, Crespi R, Ivanova J, Coupey SM, Heptulla RA, Arens R. Clinical utility of magnetic resonance imaging and ultrasonography for diagnosis of polycystic ovary syndrome in adolescent girls. . Fertility and sterility. 2016;104(5):1302-9.  
23. Youngster M WV, Blood EA, Barnewolt CE, Emans SJ, Divasta AD,. Utility of ultrasound in the diagnosis of polycystic ovary syndrome in adolescents. Fertility and sterility. 2014;102(5):1432-8.  
24. Villa P RA, Sagnella F, Moruzzi MC, Mariano N, Lassandro AP, Pontecorvi A, Scambia G, Lanzone A. Ovarian volume and gluco‐insulinaemic markers in the diagnosis of PCOS during adolescence. Clinical endocrinology. 2013;78(2):285-90.  
25. Shah B PL, Milla S, Kessler M, David R. Endometrial thickness, uterine, and ovarian ultrasonographic features in adolescents with polycystic ovarian syndrome. Journal of pediatric and adolescent gynecology. 2010;23(3):146-52.  
26. Rosenfield RL, Ehrmann DA, Littlejohn EE. Adolescent polycystic ovary syndrome due to functional ovarian hyperandrogenism persists into adulthood. The Journal of Clinical Endocrinology & Metabolism 2015;100(4):1537-43.  
27. Legro RS, Arslanian SA, Ehrmann DA, Hoeger KM, Murad MH, Pasquali R, et al. Diagnosis and treatment of polycystic ovary syndrome: an Endocrine Society clinical practice guideline. The Journal of Clinical Endocrinology & Metabolism. 2013;98(12):4565-92.  
28. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Atenção ao pré-natal de baixo risco [recurso eletrônico] /Ministério da Saúde. Secretaria de Atenção à  
Saúde. Departamento de Atenção Básica,. In: Cadernos de Atenção Básica n, editor. Brasília: Editora do Ministério da Saúde; 2013. p. 1-318.  
29. Boomsma CM, Eijkemans MJ, Hughes EG, Visser GH, Fauser BC, Macklon NS. A meta-analysis of pregnancy outcomes in women with polycystic ovary syndrome. . Human reproduction update. 2006;12(6):673-83.  
30. Lim SS, Norman RJ, Davies MJ, Moran LJ HS, Norman RJ, Teede HJ. The effect of obesity on polycystic ovary syndrome: a systematic review and meta‐analysis. Obesity Reviews. 2013;14(2):95-109.  
31. Moran LJ, Hutchison SK, Norman RJ, Teede HJ. Lifestyle changes in women with polycystic ovary syndrome. Cochrane Database Syst Rev. 2011;7(2).  
32. Kiddy DS, Hamilton‐Fairley D, Bush A, Short F, Anyaoku V, Reed MJ, et al. Improvement in endocrine and ovarian function during dietary treatment of obese women with polycystic ovary syndrome. Clinical endocrinology. 1992;36(1):105-11.  
33. Thessaloniki ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group. Consensus on infertility treatment related to polycystic ovary syndrome. Fertility and sterility. 2008;89(3):505-22.  
34. Mara Spritzer P, Rocha Barone C, Bazanella de Oliveira F. Hirsutism in Polycystic Ovary Syndrome: Pathophysiology and Management. Current pharmaceutical design. 2016;22(36):5603-13.  
35. Pasquali R GA. Therapy of endocrine disease:Treatment of hirsutism in the polycystic ovary syndrome. European journal of endocrinology. 2014;170(2):R75-90.  
36. Colonna L PV, Lello S, Sorge R, Raskovic D, Primavera G. Skin improvement with two different oestroprogestins in patients affected by acne and polycystic ovary syndrome: clinical and instrumental evaluation. Journal of the European Academy of Dermatology and Venereology. 2012;26(11):1364-71.  
37. Bhattacharya SM JA. Comparative study of the therapeutic effects of oral contraceptive pills containing desogestrel, cyproterone acetate, and drospirenone in patients with polycystic ovary syndrome. Fertility and sterility. 2012;98(4):1053-9.  
38. van Zuuren EJ, Fedorowicz Z, Carter B, Pandis N. Interventions for hirsutism (excluding laser and photoepilation therapy alone. The Cochrane Library. 2015;28(4):CD010334.  
39. Gallo MF NK, Grimes DA, Lopez LM, Schulz KF. 20 microg versus> 20 microg estrogen combined oral contraceptives for contraception. Cochrane Database of Systematic Reviews. 2011;1:CD003989.  
40. Li J, Ren J, Sun W. A comparative systematic review of Yasmin (drospirenone pill) versus standard treatment options for symptoms of polycystic ovary syndrome. . European Journal of Obstetrics & Gynecology and Reproductive Biology. 2017;210:13-21.  
41. Kriplani A PA, Agarwal N, Kulshrestha V, Kumar A, Ammini AC. Effect of oral contraceptive containing ethinyl estradiol combined with drospirenone vs. desogestrel on clinical and biochemical parameters in patients with polycystic ovary syndrome. Contraception. 2010;82(2):139-46.  
42. Pehlivanov B MM. Efficacy of an oral contraceptive containing drospirenone in the treatment of women with polycystic ovary syndrome. The European Journal of Contraception & Reproductive Health Care. 2007;12(1):30-5.  
43. Battaglia C, Mancini F, Fabbri R, Persico N, Busacchi P, Facchinetti F, et al. Polycystic ovary syndrome and cardiovascular risk in young patients treated with drospirenone-ethinylestradiol or contraceptive vaginal ring. A prospective, randomized, pilot study. Fertility and sterility. 2010;94(4):1417-25.  
44. Stegeman BH, de Bastos M, Rosendaal FR, van Hylckama Vlieg A, Helmerhorst FM, Stijnen T, et al. Different combined oral contraceptives and the risk of venous thrombosis: systematic review and network meta-analysis. Bmj. 2013;347:f5298.  
45. Amiri M TF, Nahidi F, Kabir A, Azizi F, Carmina E,. Effects of oral contraceptives on metabolic profile in women with polycystic ovary syndrome: A meta-analysis comparing products containing cyproterone acetate with third generation progestins. Metabolism. 2017;73:22-35.  
46. Halperin IJ SKS, Stroup DF, Laredo SE. The association between the combined oral contraceptive pill and insulin resistance, dysglycemia and dyslipidemia in women with polycystic ovary syndrome: a systematic review and meta-analysis of observational studies. Human Reproduction. 2010;26(1):191-201.  
47. Domecq JP PG, Mullan RJ, Sundaresh V, Wang AT, Erwin PJ, Welt C, Ehrmann D, Montori VM, Murad MH. Adverse effects of the common treatments for polycystic ovary syndrome: a systematic review and meta-analysis. The Journal of Clinical Endocrinology & Metabolism. 2013;98(12):4646-54.  
48. World Health Organization. Medical Eligibility Criteria for Contraceptive Use, 5th edition. 5th ed. Geneva: World Health Organization; 2015.  
49. Li XJ YY, Liu CQ, Zhang W, Zhang HJ, Yan B, Wang LY, Yang SY, Zhang SH. Metformin vs thiazolidinediones for treatment of clinical, hormonal and metabolic characteristics of polycystic ovary syndrome: a meta‐analysis. Clinical endocrinology. 2011;74(3):332-9.  
50. Naderpoor N SS, de Courten B, Misso ML, Moran LJ, Teede HJ. Metformin and lifestyle modification in polycystic ovary syndrome: systematic review and meta-analysis. Human reproduction update. 2015;21(5):560-74.  
51. Tang T LJ, Norman RJ, Yasmin E, Balen AH. Insulin‐sensitising drugs (metformin, rosiglitazone, pioglitazone, D‐chiro‐inositol) for women with polycystic ovary syndrome, oligo amenorrhoea and subfertility. . The Cochrane Library. 2012(5):CD003053.  
52. Leelaphiwat S JT, Lertvikool S, Tabcharoen C, Sukprasert M, Rattanasiri S, Weerakiet S,. Comparison of desogestrel/ethinyl estradiol plus spironolactone versus cyproterone acetate/ethinyl estradiol in the treatment of polycystic ovary syndrome: A randomized controlled trial. Journal of Obstetrics and Gynaecology Research. 2015;41(3):402-10.  
53. Spritzer PM LK, Mattiello S, Lhullier F. Spironolactone as a single agent for long‐term therapy of hirsute patients. Clinical endocrinology. 2000;52(5):587-94.  
54. ciproterona) Aad. Farm. Resp.: Dra. Dirce Eiko Mimura CRF-SP nº 16532. Fabricado por: Delpharm Lille S.A.S. Lys Lez Lannoy – França; Embalado por: Schering do Brasil, Química e Farmacêutica Ltda. São Paulo – SP; Importado por:Bayer S.A. Rua Domingos Jorge, 1.100 04779-900 – Socorro - São Paulo – SP. Bula de Remédio. 2018.  
55. van der Spuy ZM, Le Roux PA, Matjila MJ. Cyproterone acetate for hirsutism. The Cochrane Library. 2003;4:CD001125.  
56. Carmina E LR. A comparison of the relative efficacy of antiandrogens for the treatment of acne in hyperandrogenic women. Clinical endocrinology. 2002;57(2):231-4.  
57. Swiglo BA CM, Flynn DN, Kurtz DM, LaBella ML, Mullan RJ, Erwin PJ, Montori VM,. Antiandrogens for the treatment of hirsutism: a systematic review and metaanalyses of randomized controlled trials. The Journal of Clinical Endocrinology & Metabolism. 2008;93(4):1153-60.  
58. Luque-Ramírez M Al-BF, Botella-Carretero JI, Martínez-Bermejo E, Lasunción MA, EscobarMorreale HF. Comparison of ethinyl-estradiol plus cyproterone acetate versus metformin effects on classic metabolic cardiovascular risk factors in women with the polycystic ovary syndrome. The Journal of Clinical Endocrinology & Metabolism. 2007 92(7):2453-61.  
59. Mazza A FB, Guzzi P, D'Orrico B, Malaguarnera R, Veltri P, Fava A, Belfiore A. . In PCOS patients the addition of low-dose spironolactone induces a more marked reduction of clinical and biochemical  
hyperandrogenism than metformin alone. Nutrition, Metabolism and Cardiovascular Diseases 2014;24(2):132-9.  
60. Wu J ZY, Jiang Y, Cao Y. Effects of metformin and ethinyl estradiol-cyproterone acetate on clinical, endocrine and metabolic factors in women with polycystic ovary syndrome. Gynecological Endocrinology. 2008;24(7):392-8.  
61. Spritzer PM BC, Oliveira FB. Hirsutism in Polycystic Ovary Syndrome: Pathophysiology and Management. Curr Pharm Des. 2016;22(36):5603-13.  
62. Du Q WY, Yang S, Wu B, Han P, Zhao YY. . A systematic review and meta-analysis of randomized controlled trials comparing pioglitazone versus metformin in the treatment of polycystic ovary syndrome. Current medical research and opinion. 2012;28(5):723-30.  
63. Li XJ YY, Liu CQ, Zhang W, Zhang HJ, Yan B, Wang LY, Yang SY, Zhang SH. . Metformin vs thiazolidinediones for treatment of clinical, hormonal and metabolic characteristics of polycystic ovary syndrome: a meta‐analysis. Clinical endocrinology. 2011;74(3):332-9.  
64. Bruno RV dÁM, Neves FB, Nardi AE, Crespo CM, Sobrinho AT. Comparison of two doses of metformin (2.5 and 1.5 g/day) for the treatment of polycystic ovary syndrome and their effect on body mass index and waist circumference. Fertility and sterility. 2007;88(2):510-2.  
65. Harborne LR, Sattar N, Norman JE, Fleming R. Metformin and weight loss in obese women with polycystic ovary syndrome: comparison of doses. The Journal of Clinical Endocrinology & Metabolism. 2005;90(8):4593-8.  
66. Lord JM FI, Norman RJ,. Metformin in polycystic ovary syndrome: systematic review and metaanalysis. Bmj. 2003;327(7421):951.  
67. Conway G DD, Diamanti-Kandarakis E, Escobar-Morreale HF, Franks S, Gambineri A, Kelestimur F, Macut D, Micic D, Pasquali R, Pfeifer M. The polycystic ovary syndrome: a position statement from the European Society of Endocrinology. European journal of endocrinology. 2014;171(4):P1-29.  
68. Skubleny D SN, Gill RS, Dykstra M, Shi X, Sagle MA, de Gara C, Birch DW, Karmali S,. The impact of bariatric surgery on polycystic ovary syndrome: a systematic review and meta-analysis. Obesity surgery. 2016;26(1):169-76.  
69. Kokaly W MT. Relapse of hirsutism following long‐term successful treatment with oestrogen– progestogen combination. Clinical endocrinology. 2000;52(3):379-82.  
70. Berger SM GG, Moore LL, Andersson C, Torp-Pedersen C, Denis GV, Schmiegelow MD,. Associations between metabolic disorders and risk of cancer in Danish men and women–a nationwide cohort study. BMC cancer. 2016;16(1):133.  
71. Barry JA, Azizia MM, Hardiman PJ. Risk of endometrial, ovarian and breast cancer in women with polycystic ovary syndrome: a systematic review and meta-analysis. Hum Reprod Update. 2014;20(5):748-58.  
72. Shobeiri F JE. The association between polycystic ovary syndrome and breast cancer: a metaanalysis. Obstetrics & gynecology science. 2016;59(5):367-72.  
73. Haoula Z SM, Atiomo W, . Evaluating the association between endometrial cancer and polycystic ovary syndrome. Human reproduction. 2012;27(5):1327-31.  
74. Harris HR TL, Cramer DW, Terry KL. Long and irregular menstrual cycles, polycystic ovary syndrome, and ovarian cancer risk in a population‐based case‐control study. International journal of cancer. 2017;140(2):285-91.  
75. De Leo V MM, Cappelli V, Massaro MG, Morgante G, Petraglia F. . Genetic, hormonal and metabolic aspects of PCOS: an update. Reproductive Biology and Endocrinology. 2016;14(1):38.  
76. Practice Committee of the American Society for Reproductive Medicine. Obesity and reproduction: an educational bulletin. Fertility and sterility. 2008;90(5):S21-9.  
77. Shaw LJ BMC, Azziz R, Stanczyk FZ, Sopko G, Braunstein GD, Kelsey SF, Kip KE, Cooper-DeHoff RM, Johnson BD, Vaccarino V. Withdrawn: Postmenopausal Women with a History of Irregular Menses and Elevated Androgen Measurements at High Risk for Worsening Cardiovascular Event-Free Survival: Results from the National Institutes of Health—National Heart, Lung, and Blood Institute Sponsored Women’s Ischemia Syndrome Evaluation. The Journal of Clinical Endocrinology & Metabolism. 2008;93(4):1276-84.  
78. Iftikhar S, Collazo-Clavell ML, Roger VL, St Sauver J, Brown RD, Jr., Cha S, et al. Risk of cardiovascular events in patients with polycystic ovary syndrome. The Netherlands journal of medicine. 2012;70(2):74-80.  
79. Mani H, Levy MJ, Davies MJ, Morris DH, Gray LJ, Bankart J, et al. Diabetes and cardiovascular events in women with polycystic ovary syndrome: a 20-year retrospective cohort study. Clin Endocrinol (Oxf). 2013;78(6):926-34.  
80. Merz CNB, Shaw LJ, Azziz R, Stanczyk FZ, Sopko G, Braunstein GD, et al. Cardiovascular Disease and 10-Year Mortality in Postmenopausal Women with Clinical Features of Polycystic Ovary Syndrome. Journal of Women's Health. 2016;25(9):875-81.  
81. Schmidt J, Landin-Wilhelmsen K, Brännström M, Dahlgren E, Author A, Department of O, et al. Cardiovascular disease and risk factors in PCOS women of postmenopausal age: A 21-year controlled follow-up study. Journal of Clinical Endocrinology and Metabolism. 2011;96(12):3794-803.  
82. Wild S, Pierpoint T, Jacobs H, McKeigue P. Long-term consequences of polycystic ovary syndrome: results of a 31 year follow-up study. Human fertility (Cambridge, England). 2000;3(2):101-5.  
83. Wild S, Pierpoint T, McKeigue P, Jacobs H. Cardiovascular disease in women with polycystic ovary syndrome at long-term follow-up: a retrospective cohort study. Clin Endocrinol (Oxf). 2000;52(5):595-600.  
84. Cibula D, Cífková R, Fanta M, Poledne R, Zivny J, Skibová J, et al. Increased risk of non-insulin dependent diabetes mellitus, arterial hypertension and coronary artery disease in perimenopausal women with a history of the polycystic ovary syndrome. Human Reproduction. 2000;15(4):785-9.  
85. Dahlgren E, Janson PO, Johansson S, Lapidus L, Oden A, Author A, et al. Polycystic ovary syndrome and risk for myocardial infarction: Evaluated from a risk factor model based on a prospective population study of women. Acta Obstetricia et Gynecologica Scandinavica. 1992;71(8):599-604.  
86. Matthesen T RA, Nielsen LH, Lidegaard O,. Hormonal Contraception and Thrombotic Stroke: A Historical Cohort Study. Journal of Neurological Disorders & Stroke. 2015;3(2):1101.  
87. Bird ST, Hartzema AG, Brophy JM, Etminan M, Delaney JA. Risk of venous thromboembolism in women with polycystic ovary syndrome: a population-based matched cohort analysis. CMAJ : Canadian Medical Association journal = journal de l'Association medicale canadienne. 2013;185(2):E115-20.  
88. Okoroh EM, Hooper WC, Atrash HK, Yusuf HR, Boulet SL, Author A, et al. Is polycystic ovary syndrome another risk factor for venous thromboembolism? United States, 2003-2008. American Journal of Obstetrics and Gynecology. 2012;207(5):377.e1-.e8.  
89. Thranov S, Lidegaard O, Nielsen LH, Author A, University of C, Rigshospitalet CD, et al. Hormonal contraception, polycystic ovary syndrome, and venous thrombosis. European Journal of Contraception and Reproductive Health Care. 2014;19 SUPPL. 1:S231.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ACETATO DE MEDROXIPROGESTERONA, CIPROTERONA, ETINILESTRADIOL MAIS LEVONORGESTREL, METFORMINA E NORETISTERONA.  
Eu,______________________________________________________________________(nome  
do(a) paciente), declaro ter sido informada claramente sobre benefícios, riscos, contraindicações e  
principais efeitos adversos relacionados ao uso de **acetato de medroxiprogesterona** , **ciproterona** , **etinilestradiol mais levonorgestrel** , **metformina** e **noretisterona** ,  indicadas para o tratamento da

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **síndrome de ovários policísticos** . -->
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico  
(nome do médico que prescreve).  
Assim, declaro que fui claramente informada de que o medicamento que passo a receber pode  
trazer as seguintes melhorias:  
- regularização dos ciclos menstruais (já nos primeiros meses de tratamento);  
- diminuição da quantidade de pelos (após pelo menos 6 meses de tratamento);  
- redução do peso e melhora das manifestações de resistência insulínica.  
Fui também claramente informada a respeito das seguintes contraindicações, potenciais efeitos  
adversos e riscos do uso deste medicamento:  
- contraindicado em gestantes ou em mulheres que planejem engravidar;  
- contraindicado em mulheres que estão amamentando;  
- contraindicado em casos de hipersensibilidade (alergia) ao fármaco;  
- efeitos adversos cardiovasculares mínimos com o uso de ciproterona e estrógeno como terapia  
de hirsutismo e acne;  
- efeitos adversos sobre o sistema nervoso central mínimos em mulheres sob terapia combinada  
de ciproterona e estrógeno;  
- ocasionalmente tensão das mamas e galactorreia associadas com hiperprolactinemia em  
mulheres sob terapia de ciproterona e estrógeno;  
- diminuição da libido em mulheres tratadas com ciproterona associado ao estrógeno;  
- efeitos adversos relativamente infrequentes: náusea, diarreia e indigestão;  
- elevação das transaminases/alaninotransferases séricas pode ocorrer em homens e mulheres,  
tendo sido relatados vários casos de hepatite, alguns dos quais fatais, tendo os sintomas de hepatite se  
manifestado geralmente vários meses após o início da terapia;  
- risco de ocorrência de efeitos adversos aumenta com o aumento da dose.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-  
me a devolvê- lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei  
também que continuarei a ser atendida, inclusive em caso de desistir de usar o(s) medicamento(s).  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas  
ao meu tratamento, desde que assegurado o anonimato. (   ) Sim (   ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (    ) Acetato de medroxiprogesterona  
- (    ) Ciproterona  
- (    ) Etinilestradiol mais levonorgestrel  
- (    ) Metformina  
(    ) Noretisterona  
<!-- Start of picture text -->
Local:  Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>Assinatura do paciente ou do responsável legal<br>Médico responsável: CRM: UF:<br>Assinatura e carimbo do médico<br>Data:<br><!-- End of picture text -->  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **A) METODOLOGIA** -->
Com a presença de cinco membros do Grupo Elaborador, sendo 3 especialistas e 2 metodologistas, e dois representantes do Comitê Gestor, uma reunião presencial para definição do escopo destes Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida. Todos os componentes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados.  
Inicialmente, a macroestrutura do PCDT foi estabelecida considerando a Portaria N° 375, de 10 de novembro de 2009 (90), como roteiro para elaboração dos PCDTs, e as seções do documento foram definidas.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de identificar as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas do tema do presente PCDT foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO, para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
<!-- Start of picture text -->
aa *Populagao ou condi¢ao clinica<br>( +Intervengdo, no caso de estudos experimentais<br>+Fatorde exposi¢ao, em caso de estudos<br>observacionais<br>*Teste indice, nos casos de estudos de acuracia<br>diagnéstica<br>*Controle, de acordo com tratamento/niveis de<br>exposi¢ao do fator/exames disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a<br>priori, de acordo com sua importancia<br><!-- End of picture text -->  
**Figura 2– Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.**  
Ao final dessa dinâmica, 11 questões de pesquisa foram definidas para o presente PCDT (Quadro  
1).  
**Quadro 3 – Questões de pesquisa elencadas pelo Grupo Elaborador do Protocolo Clínico e Diretrizes Terapêuticas**  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|Quais são os critérios diagnósticos vigentes para SOP em<br>adolescentes?|Diagnóstico|
|**2**|Dosagem de hormônio anti-Mulleriano é melhor que<br>ultrassonografia para o diagnóstico de SOP?|Diagnóstico|
|**3**|Qual a estimativa de risco de câncer de mama em<br>mulheres com PCOS?|Monitoramento|
|**4**|Quais são os tratamentos não medicamentosos para<br>Hirsutismo em mulheres com PCOS?|Tratamento não<br>medicamentoso|
|**5**|Qual a eficácia e segurança dos anticoncepcionais<br>hormonais combinados (AHC) em relação aos princípios<br>ativos e à via de administração?|Tratamento<br>medicamentoso|
|**6**|Qual a eficácia dos sensibilizadores de ação da insulina<br>para irregularidades menstruais em mulheres com PCOS?|Tratamento<br>medicamentoso|
|**7**|Qual é o antiandrogênico mais eficiente (eficaz e seguro)<br>para o tratamento de hiperandrogenismo em mulheres|Tratamento<br>medicamentoso|  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
||com PCOS?||
|**8**|Qual o risco/prevalência de eventos cardiovasculares<br>maiores em mulheres com SOP?|Monitoramento|
|**9**|Qual a eficácia e segurança da cirurgia bariátrica para o<br>tratamento de comorbidades metabólicas (e infertilidade)<br>associadas à PCOS?|Tratamento<br>medicamentoso|
|**10**|Qual a eficácia dos sensibilizadores de ação da insulina<br>para comorbidades metabólicas em mulheres com PCOS?|Tratamento<br>medicamentoso|
|**11**|Qual a eficácia e segurança da metformina em mulheres<br>grávidas com SOP?|Tratamento<br>medicamentoso|  
PCDT: Protocolo Clínico e Diretrizes Terapêuticas  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida no PCDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com metaanálise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com metaanálise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clinico-demográficas e desfechos de eficácia/segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados  
adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias em formato pdf, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados do PCDT. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo do **Apêndice 1** .  
Com o corpo das evidências identificado, procedeu-se a extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2) (91), os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane (92), os estudos observacionais pela ferramenta Newcastle-Ottawa (93) e os estudos de acurácia diagnóstica pelo _Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2) (94). Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas a priori como alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa ao longo do **Apêndice 1** .  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ ) (95), de forma qualitativa, durante a reunião de consenso das recomendações. Os metodologistas mediaram as  
discussões apresentando cada um dos critérios GRADE para os dois objetivos do sistema GRADE, e as conclusões do painel de especialistas foram apresentadas ao final do parágrafo do texto correspondente à recomendação.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **B) QUESTÕES DE PESQUISA** -->
**Questão de Pesquisa 1:** <mark>Quais são os critérios diagnósticos vigentes para SOP em adolescentes?</mark>  
**1)** **<mark>Estratégia de busca</mark>**

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **MEDLINE via Pubmed:** -->
((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ("Adolescent"[Mesh] OR Adolescence OR Teen* OR Female Adolescent)) AND (("Diagnostic Techniques, Endocrine"[Mesh]) OR ("Diagnostic Techniques, Obstetrical and Gynecological"[Mesh]))  
<mark>Total: 259 referências</mark>  
<mark>Data de acesso: 1</mark> 3/06/2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
'ovary polycystic disease'/exp OR 'ovary polycystic disease' AND ('adolescent'/exp OR 'adolescent' AND [embase]/lim) AND ('diagnostic procedure'/exp/mj AND [embase]/lim)  
<mark>Total: 149 referências</mark>  
<mark>Data de acesso: 1</mark> 3/06/2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
A busca nas bases de dados resultou em 408 referências (259 no MEDLINE e 149 no EMBASE). Destas, 12 estavam duplicadas. Trezentas e noventa e seis referências foram triadas pela leitura de título e resumo. Vinte citações tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destes, 10 foram excluídos nessa etapa. Os motivos da exclusão foram: três estudos foram excluídos por serem revisões narrativas; dois estudos foram excluídos por serem consensos de especialistas, dois estudos não incluíram população adolescente, um estudo compara a avaliação diagnóstica de SOP por especialidade; um estudo apenas descreve participantes com SOP e um estudo foi excluído por não considerar população exclusiva com SOP.  
Ao final, 10 estudos foram considerados elegíveis para a questão de pesquisa (21, 96-104), sendo cinco recuperados por busca manual (96-98, 102, 104).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
A descrição sumária dos estudos encontra-se na Tabela 1. A Tabela 2 apresenta as características dos participantes nos estudos. A Tabela 3 apresenta os desfechos relacionados aos parâmetros bioquímicos avaliados nos estudos. A Tabela 4 apresenta os desfechos relacionados aos parâmetros morfológicos avaliados nos estudos. A Tabela 5 apresenta os desfechos relacionados aos parâmetros clínicos avaliados nos estudos e as conclusões dos estudos.  
**Tabela 1 – Características dos estudos que avaliaram os critérios diagnósticos de SOP em população adolescente.**  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo e população do estudo**|**Grupo Exposição**|**Grupo Controle**|**Critério**<br>**Diagnóstico SOP**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Vries e**<br>**Phillipa,**<br>**2015 (96)**|Estudo<br>observacional,<br>(não fica claro se<br>a análise foi<br>longitudinal)|Investigar o valor de diferentes<br>parâmetros bioquímicos no diagnóstico de<br>SOP em adolescentes e também avaliar a<br>prevalência de hiperplasia adrenal<br>congênita não clássica entre meninas<br>adolescentes encaminhadas com sintomas<br>clínicos sugestivos de SOP|Adolescentes com<br>diagnóstico de SOP<br>pelo critério de<br>Rotterdam (n=87)|1) Hiperplasia adrenal<br>congênita não clássica<br>(n=9)<br>2) Hiperandrogenismo<br>ou irregularidades<br>menstruais isoladas<br>(Não-SOP) (n=18)|Rotterdam|Alto. Por ser resumo<br>de congresso, algumas<br>variáveis relevantes<br>não foram relatadas e<br>nem os dados<br>quantitativos das<br>análisesquantitativas|
|**Kenigsberg**<br>**et al. 2015**<br>**(97)**|Estudo<br>transversal|Comparar a utilidade da RNM versus US<br>(transabdominal ou transvaginal) para o<br>diagnóstico de SOP|RNM, n= 33<br>participantes, 66<br>ovários avaliados|US, n=39 participantes,<br>66 ovários avaliados|Critérios NIH|Alto. Não foram<br>realizadas análises<br>ajustadas|
|**Youngster**<br>**et al. 2014**<br>**(98)**|Estudo<br>observacional<br>caso-controle|Determinar a utilidade do USTA no<br>diagnóstico de SOP durante<br>adolescência|Adolescentes com<br>SOP, n=54|População com<br>apendicite, n=98|Critérios NIH|Alto. Não foram<br>realizadas análises<br>ajustadas|
|**Villa et al.**<br>**2013 (99)**|Estudo<br>observacional<br>transversal|Avaliar o papel diagnóstico do VO de<br>ambos os ovários conforme avaliado por<br>USTA, as relações com os parâmetros<br>hormonais e metabólicos e o limiar de VO<br>para definir o risco de SOP durante a<br>adolescência|Adolescentes com<br>diagnóstico de<br>SOP, n=134|Garotas normo-<br>ovulatórias, n=48|Critérios NIH|Alto. Não foram<br>realizadas análises<br>ajustadas|
|**Villaroel et**<br>**al. 2013**<br>**(21)**<br>**(Resumo**<br>**de**<br>**congresso)**|Estudo<br>observacional<br>transversal|Estudar prevalência de hiperandrogenismo<br>bioquímico, morfologia policística de<br>ovário e diferentes fenótipos de SOP em<br>adolescentes hirsuto / oligomenorreícas e<br>determinar os níveis de corte de achados<br>hormonais e ultrassonográficos que<br>diferenciam SOP de meninas saudáveis|Adolescentes com<br>diagnóstico de<br>SOP, n=30|Garotas sem hirsutismo<br>com ciclo menstrual<br>regular, n=65|Critérios NIH|Alto. Não foram<br>realizadas análises<br>ajustadas|  
|**Autor, ano**|**Desenho de**<br>**estudo**|**Objetivo e população do estudo**|**Grupo Exposição**|**Grupo Controle**|**Critério**<br>**Diagnóstico SOP**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Hart et al.**<br>**2010 (100)**|Estudo<br>observacional<br>transversal|Determinar a relação entre hormônio anti-<br>mulleriano na fase folicular precoce e SOP<br>em população de adolescentes|Adolescentes com<br>diagnóstico de SOP<br>pelo critério de<br>Rotterdam (n=16) e<br>com diagnóstico de<br>SOP pelo critério<br>NIH(n=36)|Controles saudáveis,<br>n=NR|Rotterdam e NIH|Moderado. Não há<br>descrição do tamanho<br>de amostra do grupo<br>controle, nem todas as<br>participantes foram<br>submetidas à avaliação<br>por US|
|**Shah et al.**<br>**2010 (101)**|Estudo<br>transversal<br>retrospectivo|Avaliar as características<br>ultrassonográficas do útero e do ovário,<br>incluindo a espessura do endométrio em<br>mulheres adolescentes com SOP|Adolescentes com<br>SOP, n=51|NA|Rotterdam|Alto. Não foram<br>realizadas análises<br>ajustadas. Natureza<br>retrospectiva|
|**Chen et al.**<br>**2008 (102)**|Estudo<br>observacional<br>prospectivo|Investigar o volume de ovários em<br>adolescentes chineses com SOP e estudar<br>limiares diagnósticos para SOP em<br>adolescentes chineses|Adolescentes com<br>suspeita de SOP,<br>n=69|Adolescente com ciclo<br>menstrual normal e<br>ausência de<br>características suspeitas<br>de SOP,n=26|Critérios NIH|Alto. Não foram<br>realizadas análises<br>ajustadas|
|**Yo et al.**<br>**2005 (103)**|Estudo<br>transversal<br>prospectivo|Determinar a utilidade da RNM em<br>comparação com o USTA em adolescentes<br>obesas com SOP|Adolescentes com<br>SOP que tiveram<br>seus parâmetros<br>morfológicos<br>avaliados por RNM,<br>n=11|Adolescentes com SOP<br>que tiveram seus<br>parâmetros<br>morfológicos avaliados<br>por USTA, n=11|Evidência clínica e / ou<br>bioquímica de<br>hiperandrogenismo e<br>sangramento menstrual<br>irregular|Alto. Não foram<br>realizadas análises<br>ajustadas|
|**Silfen et al.**<br>**2003 (104)**|Estudo<br>observacional<br>prospectivo|Caracterizam alterações precoces<br>endócrinas e metabólicas em adolescentes<br>com SOP e para determinar se as<br>diferenças entre mulheres não obesas e<br>obesas com SOP são presentes no início do<br>curso|Não obesas com<br>SOP, n=11<br>Obesas com<br>SOP, n=22|Controles sadios<br>obesos, n=15|Presença de<br>hiperandrogenismo<br>[testosterona<br>livre>6,3pg/ml,<br>testosterona>55ng/dl, 4-<br>androstenediona><br>245ng/dl ou<br>DHEAS>248ug/dl] e<br>oligomenorreia ou<br>amenorreia|Alto. Não foram<br>realizadas análises<br>ajustadas|  
SOP: Síndrome dos Ovários Policísticos; RNM: Ressonância Nuclear Magnética; US: ultrassonografia; NIH: National Institutes of Health; USTA: ultrassonografia transabdominal; VO: volume ovariano; NR: não reportado; NA: não se aplica; DHEAS: sulfato de dehidroepiandrosterona.  
**Tabela 2 – Características dos participantes nos estudos que avaliaram os critérios diagnósticos de SOP em população adolescente.**  
|**Autor, ano**|**Idade em anos**<br>**Grupo intervenção**|**Idade em anos**<br>**Grupo controle**|**IMC (Kg/m**<sup>**2**</sup>**)**<br>**Grupo intervenção**|**IMC (Kg/m**<sup>**2**</sup>**)**<br>**Grupo controle**|
|---|---|---|---|---|
|**Vries e Phillipa, 2015**<br>**(96)**|NR (13–18)|NR (13–18)|NR|NR|
|**Kenigsberg et al. 2015**<br>**(97)**|16,68 (1,56)|16,68 (1,56)|1,84 (0,92)|1,84 (0,92)|
|**Youngster et al. 2014**<br>**(98)**|15,2 (1,8)|14,7 (1,7)|NR|NR|
|**Villa et al. 2013 (99)**|15,7(1,4)|15,3 (1,7)|25,7 (5,4)|23,9 (4,9)|
|**Villaroel et al. 2013**<br>**(21)**<br>**(Resumo de**<br>**congresso)**|NR|NR|NR|NR|
|**Hart et al. 2010 (100)**|Critério Rotterdam:<br>15,2 (0,45)<br>Critério NIH:<br>15,4 (0,55)|Critério<br>Rotterdam: 15,4<br>(0,56)<br>Critério NIH:<br>15,2(0,47)|Critério Rotterdam:<br>24,43 (5,12)<br>Critério NIH:<br>25,83 (5,64)|Critério Rotterdam:<br>22,07 (2,94)<br>Critério NIH:<br>22,15 (3,09)|
|**Shah et al. 2010 (101)**|15 (10,1-18,2)|NA|NR|NA|
|**Chen et al. 2008 (102)**|17,01 (1,88)|17,85 (0,88)|21,77 (4,60)|20,12 (2,17)|
|**Yo et al. 2005 (103)**|15,7 (0,5)|14,4 (0,6)|35,4 (2,0)|25,8 (1,6)|
|**Silfen et al. 2003**<br>**(104)**|Não obesas: 16,1<br>(1,9)<br>Obesas: 15,5(1,4)|14,4 (1,5)|Não obesas: 22,5<br>(1,5)<br>Obesas: 35,9(6,2)|35,8 (7,1)|  
Dados apresentados em média (desvio-padrão), ou mediana (mínimo e máximo); IMC: Índice de massa corporal.  
**Tabela 3 – Resultados dos parâmetros bioquímicos avaliados nos estudos.**  
|**Autor, ano**|**Parâmetros bioquímicos**<br>**Grupo Intervenção**|**Parâmetros bioquímicos**<br>**Grupo controle**|**Valor de p para a comparação**|**Valores de corte e acurácia de parâmetros**<br>**bioquímicos**|
|---|---|---|---|---|
|**Vries e**<br>**Phillipa, 2015**<br>**(96)**|NR|NR|Androstenediona: p<0,01<br>LH basal: p<0,02<br>LH/FSH basal: p<0,002<br>Razão LH/FSH de pico: p>0,05<br>Testes de estimulação GnRH e<br>ACTH: p>0,05<br>|NR|
|**Kenigsberg et**<br>**al. 2015(97)**|NR|NR|~~Andrógenos basais: p>0 05~~<br>NA|NR|
|**Youngster et**<br>**al. 2014(98)**|NR|NR|NA|NR|
|**Villa et al.**<br>**2013(99)**|NR|NR|NA|NR|
|**Villaroel et al.**<br>**2013 (21)**<br>**(Resumo de**<br>**congresso)**|NR|NR|NA|**Valor de corte para inibina b:**<br>110,6 pmol/l; ASC: 0,943<br>**Valor de corte para n° de folículos:**<br>>12,5; ASC: 0,895<br>**Valor de corte para índice de andrógenos livres:**<br>6,1%; ASC: 0,86<br>**Valor de corte para testosterona**:<br>≥0,69 ng/ml; ASC= 0,806<br>**Dosagem de AMH:**NR|
|**Hart et al.**<br>**2010 (100)**|**Critério Rotterdam:**<br>AMH: 31 pmol/L (IIQ 21–50)<br>**Critério NIH:**<br>AMH: 30 pmol/L (IIQ 19–51)|**Critério Rotterdam:**<br>AMH: 23 pmol/L (IIQ 17–34),<br>**Critério NIH:**<br>AMH: 24 pmol/L (IIQ17–35)|p =0,002<br>p=0,048|**[ ] de AMH para predizer diagnóstico de SOP**<br>**Critério Rotterdam**: ASC: 0,64 (IC95% 0,55–0,72),<br>p=0,002, sensibilidade: 53,1%; especificidade: 69,8%<br>**Critério NIH**: ASC: 0,61 (IC95% 0,49–0,72), p=0,048,<br>sensibilidade: 52,8%; especificidade: 66,1%|
|**Shah et al.**<br>**2010(101)**|NR|NA|NA|NR|
|**Chen et al.**<br>**2008(102)**|NR|NR|NA|NR|
|**Yo et al. 2005**<br>**(103)**|NR|NR|NA|NR|  
|**Autor, ano**|**Parâmetros bioquímicos**<br>**Grupo Intervenção**|**Parâmetros bioquímicos**<br>**Grupo controle**|**Valor de p para a comparação**|**Valores de corte e acurácia de parâmetros**<br>**bioquímicos**|
|---|---|---|---|---|
|**Silfen et al.**<br>**2003 (104)**|**Não obesas:**<br>LH (m IU/ml): 14,9 (5,9)<br>FSH (m IU/ml): 6,2 (1,5)<br>Testosterona (ng/dL): 58,4 (20,4)<br>Glicemia (mg/dL): 85,9 (9,6)<br>HbA1c (%): 5,0 (0,3)<br>QUICKI: 0,34 (0,02)<br>**Obesas:**<br>LH (m IU/ml): 9,5 (5,2)<br>FSH (m IU/ml): 5,5 (1,6)<br>Testosterona (ng/dL): 49,8 (18,7)<br>Glicemia (mg/dL): 88,4 (6,5)<br>HbAc1 (%): 5,1 (0,3)<br>QUICKI: 0,30(0,03)|**Obesas controle:**<br>LH (m IU/ml): 3,5 (2,3)<br>FSH (m IU/ml): 4,8 (2,8)<br>Testosterona (ng/dL): 18,4 (7,5)<br>Glicemia (mg/dL): 88,8 (7,1)<br>HbAc1 (%): 5,2 (0,3)<br>QUICKI: 0,31 (0,02)|LH: p< 0,001 para obesas com SOP<br>vs. obeso controle<br>FSH: p>0,05<br>Testosterona: p< 0,001 para<br>obesas com SOP vs. obesas<br>controle<br>Glicemia: p>0,05<br>HbAc1: p>0,05<br>QUICKI: p>0,05|NR|  
NR: Não reportado; LH: hormônio luteinizante; FSH: hormônio folículo-estimulante; GnRH: hormônio liberador de gonadotrofina; ACTH: hormônio adrenocorticotrófico; NA: Não se aplica; ASC: área sob a curva ROC; [ ]: concentração; AMH: hormônio anti-mulleriano; IC95%: Intervalo de confiança de 95%, IIQ: Intervalo interquartil; HbA1c: hemoglobina glicosilada. Quando não especificado, dados apresentados em média (desvio-padrão).  
**Tabela 4 – Resultados dos parâmetros morfológicos avaliados nos estudos.**  
|**Autor, ano**|**Parâmetros Morfológicos**<br>**Grupo intervenção**|**Parâmetros Morfológicos**<br>**Grupo controle**|**Valor de p para a**<br>**comparação**|**Valores de corte e acurácia de**<br>**parâmetros morfológicos**|
|---|---|---|---|---|
|**Vries e**<br>**Phillipa, 2015**<br>**(96)**|Morfologia de SOP por US: NR|Morfologia de SOP por US: NR|p<0,001|NR|
||VO: 14,0 cm<sup>3</sup>(9,1); Mediana: 11,9 (7,7) cm<sup>3</sup><br>CF: 12,0 (5,0)<br>% de ovários volume >10 cm3 (Rotterdam): 65%<br>% de ovários volume >14 cm3 (Rotterdam): 32%<br>% de participantes com pelo menos 1 critério|VO: 11,0 cm<sup>3</sup>(8,6); Mediana: 8,8 (7,8) cm<sup>3</sup><br>CF: não foi possível realizar devido às imagens de<br>baixa qualidade<br>% de ovários volume >10 cm3 (Rotterdam): 42%<br>% de ovários volume >14 cm3 (Rotterdam): 24%|p=0,05<br>p=0,05<br>NA||
|**Kenigsberg et**<br>**al. 2015 (97)**|Rotterdam para SOP (VO>10cm3 e CF>12): 91%<br>% de participantes com pelo menos 1 critério de<br>Lujan para SOP (VO>10cm3 e CF>9): 94%<br>% de participantes com pelo menos 1 critério para<br>SOP baseado no presente estudo (VO>14cm3 e<br>CF>17):<br>64%|% de participantes com pelo menos 1 critério<br>Rotterdam para SOP (VO>10cm3 e CF>12): 52%<br>% de participantes com pelo menos 1 critério de<br>Lujan para SOP (VO>10cm3 e CF >9): 52%<br>% de participantes com pelo menos 1 critério para<br>SOP baseado no presente estudo (VO>14cm3 e<br>CF>17): 39%|p<0,001<br>p>0,05<br>p=0,004<br>p<0,001<br>p=0,04|NR|
|**Youngster et**<br>**al. 2014 (98)**|Preencheram critério de Rotterdam modificado<br>(USTA: VO>10 ml ou CF por seção>10): 35/54 (65)<br>Preencheram critério de VO apenas: 5/35 (14)<br>Preencheram CF apenas: 14/35 (40)<br>VO: 8,2 (3,9)<br>Espessura endometrial < 5mm: 28/53 (53)<br>Espessura endometrial 5-10mm: 17/53 (32)<br>Espessura endometrial > 10mm: 8/53(15)|Preencheram critério de Rotterdam modificado<br>(USTA: VO>10 ml ou CF por seção>10): 11/98 (11)<br>Preencheram critério de VO apenas: 2/11 (18)<br>Preencheram CF apenas: 4/11 (36)<br>VO: 5,96 (2,4)<br>Espessura endometrial < 5mm: 29/94 (31)<br>Espessura endometrial 5-10mm: 56/94 (60)<br>Espessura endometrial > 10mm: 9/94(10)|p<0,0001<br>NR<br>NR<br>p<0,0001<br>NR<br>NR<br>NR|NR|
|||||Valor de corte para VO: 5,596|
|**Villa et al.**<br>**2013 (99)**|VO: 9,6 (4,4) cm3|VO: 4,6 (1,9) cm3|NR|cm<sup>3</sup>, sensibilidade: 89%;<br>especificidade 80%; acurácia:<br>0,879(IC5% 0,814-0,944)|
|**Villaroel et al.**<br>**2013 (21)**<br>**(Resumo de**<br>**congresso)**|Preencheram critérios de morfologia por US: 96,7%|Preencheram critérios de morfologia por US: 35,5%|P<0,0001|NR|  
|**Hart et al.**<br>**2010(100)**|NR|NR|NA|NR|
|---|---|---|---|---|
|**Shah et al.**<br>**2010 (101)**|Espessura do endométrio alargado: 16/51 (31,4)<br>Espessura do endométrio: 9,75 (4,3)<br>Comprimento uterino mais baixo: 22/51 (43,1)<br>Comprimento uterino normal: 21/51 (41,2)<br>Comprimento uterino maior: 8/51 (15,7)<br>Volume uterino normal: 31/51 (60,7)<br>Volume uterino aumentado: 20/51 (39,3)<br>VO aumentado: 22/51 (43)<br>VO bilateral: 16,1 (10,4-42)<br>VO unilateral: 13,1 (10-26,3)<br>Proporção com CF<5: 5/43 (12)<br>Proporção com CF entre 5 e 10: 2/43 (5)<br>Proporção com CF>10: 36/43(84)|NA|NA|NR|
|||||VO médio (cm<sup>3</sup>) = limiar de<br>positividade: 6,74 cm<sup>3</sup>,<br>Sensibilidade: 75,4%,<br>especificidade: 92,3%, ASC:<br>0,863|
|**Chen et al.**<br>**2008 (102)**|VO: 9,25 (IC 95%: 4,17-15,12) cm3<br>VO máximo: 11,00 (IC 95%: 4,88-18,99)|VO: 4,44 (IC 95%: 3,25 -7,26)<br>VO máximo: 5,50 (IC 95%: 3,62-8,43)|p<0,01<br>p<0,01|(IC95% 0,79-0,94);<br>VO máximo: limiar de<br>positividade: 7,82 cm<sup>3</sup>;<br>sensibilidade: 73,9%,<br>especificidade: 88,5%; ASC:<br>0,832<br>(IC 95%: 0,75-0,92)|
|**Yo et al. 2005**<br>**(103)**|VO: 9,7 (0,9) cm<sup>3</sup><br>CFpor ovário= 21,9(1,3)|VO: 11,6 (1,1) cm<sup>3</sup><br>CFpor ovário= 5,5(1,7)|p=0,637<br>P<0,001|NR|
|**Silfen et al.**<br>**2003(104)**|**Não obesas:**VO: 9,3 (3,1)<br>**Obesas:**VO: 8,2(4,4)|**Obesas controle:**VO: 5,9 (3,9)|NR|NR|  
SOP: Síndrome dos Ovários Policísticos; USTA: ultrassonografia transabdominal; US: ultrassonografia; VO: volume ovariano; CF: Contagem de folículos; IC95%: Intervalo de Confiança de 95%; NR: Não reportado; NA: Não se aplica. Quando não especificado, dados apresentados em média (desvio-padrão) ou n/N (%).  
**Tabela 5 – Resultados dos parâmetros clínicos e conclusões dos estudos.**  
|**Autor, ano**|**Parâmetros Clínicos**<br>**Grupo intervenção**|**Parâmetros Clínicos**<br>**Grupo controle**|**Valor de p para**<br>**a comparação**|**Valores de corte**<br>**e acurácia**|**Conclusões dos estudos**|
|---|---|---|---|---|---|
|**Vries e**<br>**Phillipa, 2015**<br>**(96)**|Hirsutismo: NR<br>Irregularidades<br>menstruais: NR<br>acne: NR|Hirsutismo: NR<br>Irregularidades<br>menstruais: NR<br>acne: NR|P <0,002<br>p <0,001<br>P <0,001|NR|Não há informações quantitativas sobre os parâmetros avaliados, apenas<br>valores de p. Usando a regressão logística gradual, o único fator preditivo<br>para SOP foi a relação basal LH / FSH, com sensibilidade e especificidade<br>insuficientes. O teste de estimulação com GnRH não foi contributivo. Dada a<br>prevalência significativa de hiperplasia adrenal congênita não clássica entre<br>adolescentes que se apresentam como SOP, um teste de ACTH deve ser<br>incluído no diagnóstico, pelo menos em populações com maior prevalência,<br>uma vez que nenhum parâmetro é diagnóstico para SOP, os critérios clínicos<br>permanecemprimordiais|
|**Kenigsberg et**<br>**al. 2015 (97)**|NR|NR|NA|NR|Como os autores também avaliaram a morfologia dos ovários de participantes<br>sem SOP, eles determinaram que o ponto de corte para o VO policístico seria<br>de>14 cm3 (com base em uma média para controles de 7,4 ± 3,4 cm3). Para a<br>CF, este ponto de corte foi estabelecido como > 17 (com base em uma média<br>para controles de 7,7 ±4,4)|
|**Youngster et**<br>**al. 2014 (98)**|NR|NR|NA|NR|A prevalência de morfologia ovariana atendendo aos critérios<br>ultrassonográficos modificados de Rotterdam por USTA em meninas com SOP<br>foi marcadamente maior do que nos adolescentes controles.  USTA pode<br>fornecer informações úteis na avaliação da SOP durante a adolescência,<br>mesmo em adolescentes obesos|
||||||Com base nos achados de volume ovariano, os autores calcularam a ASC do<br>volume ovariano e estabeleceram um valor de corte para volume ovariano de|
|**Villa et al.**<br>**2013 (99)**|NR|NR|NA|NR|5,596 cm<sup>3</sup>para diagnóstico de SOP em adolescentes, com sensibilidade de<br>89% e especificidade de 80% e acurácia de 0,879 (IC95% 0,814-0,944). Eles<br>também demonstraram que adolescentes com SOP e volume ovariano maior<br>que 5,6 cm<sup>3</sup>tem chancepara SOP de OR 16,32(IC95% 6,3-41,3), p<0,0001|
|**Villaroel et al.**<br>**2013 (21)**<br>**(Resumo de**<br>**congresso)**|Preencheram<br>critérios para<br>hiperandrogenismo:<br>80%|Preencheram<br>critérios para<br>hiperandrogenismo:<br>24,6%|P<0,0001|Valor de corte<br>para VO: 9,7 ml<br>(ASC: 0,851)|Os critérios NIH modificados, com duração do ciclo ≥ 45 dias, estão altamente<br>associados com hiperandrogenismo bioquímico e achados morfológicos de<br>SOP na adolescência. Os pontos de corte hormonais, mas não para achados<br>ultrassonográficas, são diferentes dos relatados em adultos, A dosagem de<br>AMH tem de valor limitadopara o diagnóstico de SOP em adolescentes|  
|**Autor, ano**|**Parâmetros Clínicos**<br>**Grupo intervenção**|**Parâmetros Clínicos**<br>**Grupo controle**|**Valor de p para**<br>**a comparação**|**Valores de corte**<br>**e acurácia**|**Conclusões dos estudos**|
|---|---|---|---|---|---|
|**Hart et al.**<br>**2010 (100)**|NR|NR|NA|NR|O estudo não demonstrou, em uma população adolescente geral, que a<br>concentração de AMH sérica é um preditor confiável da morfologia da SOP ou<br>dapresença de SOP|
|**Shah et al.**<br>**2010 (101)**|NR|NA|NA|NR|Os ovários contendo folículos periféricos e múltiplos, mesmo sem volume de<br>ovário ampliado, podem ser sugestivos de SOP, quando combinados com<br>critérios clínicos consistentes com SOP. Pode haver aumento unilateral e<br>bilateral dos ovários. Enquanto o comprimento uterino pode ser menor em<br>adolescentes com SOP, a espessura do endométrio pode estar aumentada em<br>algumas meninas com SOP devido a ação de estrogênio sem oposição. É<br>aconselhável induzir sangramento de abstinência com progestágenos em<br>meninas com amenorreia e SOP para prevenir o risco de hiperplasia<br>endometrial e, possivelmente,carcinoma endometrial|
||||||O estudo confirmou que o aumento do volume de ovário foi um dos critérios<br>diagnósticos confiáveis para SOP em adolescentes chineses. O melhor|
|**Chen et al.**<br>**2008 (102)**|NR|NR|NA|NR|comprometimento entre sensibilidade e especificidade foi obtido com um<br>limite estabelecido em 6,74 cm<sup>3</sup>para o VO médio e em 7,82 cm<sup>3</sup>para o VO<br>máximo de ovário. Não houve diferença significativa entre o volume médio de<br>ovário e o volume máximo de ovário napotência diagnóstica|
||||||Em adolescentes obesas com SOP a imagem de ovário por RNM foi associada|
|**Yo et al. 2005**<br>**(103)**|NR|NR|NA|NR|com clareza uniforme em todos os indivíduos, em comparação com os<br>resultados obtidos por USTA, que foram limitados por uma resolução fraca<br>em muitos indivíduos, sugerindo ser uma técnica excelente de investigação<br>para meninas com SOP e aumento da obesidade central|
|**Silfen et al.**<br>**2003 (104)**|NR|NR|NA|NR|A heterogeneidade clínica da SOP se reflete em uma heterogeneidade<br>bioquímica e hormonal, que pode ser apreciada no início da evolução do<br>transtorno epode surgir de mecanismospatogênicos distintos|  
NR: não reportado; SOP: Síndrome dos ovários policísticos; LH: hormônio luteinizante; FSH: hormônio folículo-estimulante; GnRH: hormônio liberador de gonadotrofina; ACTH: hormônio adrenocorticotrófico; NA: não se aplica; VO: volume ovariano; CF: contagem de folículos; USTA: ultrassonografia transabdominal; ASC: área sob a curva; IC95%: Intervalo de confiança de 95%; OR: razão de chances (odds ratio); AMH: hormônio anti-mulleriano; RNM: ressonância nuclear magnética.  
**Questão de Pesquisa 2:** Dosagem de hormônio anti-Mulleriano é melhor que ultrassonografia para o  
diagnóstico de SOP?

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **MEDLINE via PUBMED** : -->
(("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ((("Ultrasonography"[Mesh] OR ultrasound OR Echotomography OR Medical Sonography OR Ultrasound Imaging OR Echography)) AND ("Anti-Mullerian Hormone"[Mesh] OR Antimullerian Hormone OR Mullerian Inhibiting Substance OR Mullerian Inhibiting Factor))  
Total: 76 referências  
Data de acesso: 08/09/2016

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
'ovary polycystic disease'/exp OR 'ovary polycystic disease' AND ('echography'/exp OR      'echography') AND ('muellerian inhibiting factor'/exp OR 'muellerian inhibiting factor') AND [embase]/lim  
Total: 103 referências  
Data de acesso: 09/06/2016

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2) Seleção das evidências** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 179 referencias (76 no MEDLINE e 103 no Embase). Destas, 28 foram excluídas por estarem duplicadas. Cento e cinquenta e uma referências foram triadas por meio da leitura de título e resumos, das quais 27 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dezenove estudos foram excluídos, sendo 6 por serem revisões narrativas, 5 correlacionaram as concentrações de hormônio antiMulleriano com outros parâmetros que não os mensurados pelo ultrassom (US), um estudo comparou apenas as c oncentrações de HAM e número de folículos, sem analisar ou quantificar a correlação, outro estudo correlacionou as concentrações de HAM com os achados de Ressonância Nuclear Magnética, dois estudos estudaram a correlação em população sem diagnóstico de SOP, um estudo avaliou as concentrações de HAM em população saudável, dois estudos propuseram a dosagem de HAM para alterar/substituir parâmetros bioquímicos do diagnósticos de SOP e um estudo estava em Mandarín. Ao final, 8 estudos foram incluídos (105-112).</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A descrição sumária dos estudos encontra-se na Tabela 6. As características dos pacientes</mark>  
<mark>encontram-se descritas na Tabela 7. A Tabela 8 dados de desfechos.</mark>  
**Tabela 6 – Característica dos estudos incluídos.**  
|**Estudo**|**Desenho do**<br>**estudo**|**População do estudo**<br>**e tamanho de**<br>**amostra**|**Objetivo**|**Critério diagnóstico**<br>**de SOP**|**Método de**<br>**quantificação do**<br>**HAM**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Mahran et al.**<br>**2016 (105)**|Estudo<br>transversal|200 mulheres com<br>SOP, de duas clínicas<br>de fertilidade no<br>Egito,|Estabelecer a relação<br>entre os níveis de HAM<br>sérico e outros<br>parâmetros clínicos e<br>bioquímicos|Rotterdam|HAM: quantificação<br>em duplicata por<br>ELISA|NA|Alto risco, não<br>permite estimar a<br>magnitude da<br>correlação e não ter<br>grupo comparador|
|**Christiansen et**<br>**al. 2016 (106)**|Estudo<br>observacional<br>caso-controle|204 mulheres, sendo<br>56 com SOP e 148<br>controles,|Analisar a relação entre<br>HAM e contagem de<br>folículos antrais, em<br>mulheres com SOP e<br>controles sadios|Rotterdam|ELISA de dois-sítios<br>(ACTIVE®MIS) - uma<br>amostra|Mulheres com<br>diagnóstico<br>negativo para<br>SOP|Baixo risco|
|**Köninger et al.**<br>**2014 (107)**|Estudo<br>transversal de<br>acurácia<br>diagnóstica, caso-<br>controle|128 mulheres (18-46<br>anos), das quais 80<br>tinham SOP e 48<br>serviram de controle,|Avaliar o potencial<br>diagnóstico do HAM, por<br>grau de severidade,<br>tendo como referência<br>os achados de ultrassom,<br>andrógenos,LH,LH/FSH|Rotterdam|ELISA Gen II de 2-<br>sitios (Beckman<br>Coulter, Immunotech,<br>Webster,|Mulheres com<br>diagnóstico<br>negativo para<br>SOP|Baixo risco|
|**Eilertsen et al.**<br>**2012 (108)**|Estudo de<br>acurácia<br>diagnóstica do<br>tipo caso-<br>controle|262, sendo 56 SOP por<br>critério de Rotterdam<br>e 44 SOP por critério<br>AES e 206 controles|Avaliar o desempenho<br>diagnóstico da dosagem<br>de hormônio HAM ao<br>invés de parâmetros<br>morfológicos no<br>diagnóstico de SOP|Rotterdam (SOP-R)<br>e AES (SOP-AES)<br>(Androgen Excess-<br>SOP Society)|ELISA de dois-sítios<br>(ACTIVE®MIS)|Mulheres com<br>diagnóstico<br>negativo para<br>SOP|Alto risco, por incluir<br>casos e não casos<br>com o conhecimento<br>prévio do status da<br>doença (two-gates<br>design)|
|**Pawelczak et al.**<br>**2012 (109)**|Estudo<br>observacional<br>caso-controle|23 adolescentes com<br>SOP e mais 12<br>controles pareados<br>por idade e IMC|Determinar a correlação<br>entre HAM e achados de<br>ultrassom|Rotterdam|ELISA ultrassensível<br>(Beckman-Coulter) -<br>medidas em duplicata|<br>Adolescentes<br>com diagnóstico<br>negativo de SOP|Alto risco, viés de<br>seleção não<br>controlado nas<br>análises.|  
|**Estudo**|**Desenho do**<br>**estudo**|**População do estudo**<br>**e tamanho de**<br>**amostra**|**Objetivo**|**Critério diagnóstico**<br>**de SOP**|**Método de**<br>**quantificação do**<br>**HAM**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Dewailly et al.**<br>**2011 (110)**|Estudo<br>transversal, de<br>acurácia<br>diagnóstica caso-<br>controle|240 mulheres, sendo<br>66 sem alterações<br>morfológicas de<br>ovário e sem SOP<br>(controle 1A), 30 com<br>alterações<br>morfológicas de<br>ovários, mas sem SOP<br>(controle 1B), 73<br>supostamente com<br>SOP, por preencher<br>apenas 1 critério<br>Rotterdam de HA ou<br>AO (grupo 2) e 62 com<br>SOP(grupo 3)|Reavaliar o limiar de<br>HAM e número de<br>folículos por ovário na<br>morfologia ovariana por<br>ultrassom|Rotterdam|ELISA ultrassensível<br>(Beckman-Coulter) -<br>medidas em duplicata|<br>Grupo 1A:<br>pacientes sem<br>alterações<br>morfológicas de<br>ovário e sem<br>SOP Grupo 1B:<br>pacientes com<br>alterações<br>morfológicas de<br>ovários, mas<br>sem SOP|Alto risco, por incluir<br>casos e não casos<br>com o conhecimento<br>prévio do status da<br>doença (two-gates<br>design)|
|**Chu et al. 2005**<br>**(111)**|Estudo<br>observacional<br>caso-controle|46 mulheres com<br>sobrepeso e SOP e 25<br>controles pareadas<br>por idade,|Avaliar como os níveis<br>séricos de HAM e inibina<br>B afetam o volume<br>ovariano, fluxo<br>sanguíneo e outras<br>características|ADAMS et al, 1985|Duas quantificações:|Mulheres com<br>diagnóstico<br>negativo para<br>SOP|Alto risco, viés de<br>seleção não<br>controlado nas<br>análises|
||||bioquímicas|||||
|**Pigny et al. 2003**<br>**(112)**|Estudo<br>observacional<br>caso-controle|104 (59 com SOP e 45<br>saudáveis)|Avaliar correlação entre<br>níveis de HAM com<br>achados de US|2 de 3 critérios:<br>hiperandrogenismo,<br>distúrbio<br>menstruais ou<br>ovulatórios ou<br>achados de US|ELISA (AMH-EIA,<br>Beckman Coulter,<br>Villepinte, France) -<br>medidas em duplicata|Participantes<br>saudáveis|Alto risco, viés de<br>seleção não<br>controlado nas<br>análises.|  
SOP- Síndrome do Ovário Policístico; HAM – Hormônio anti-Mulleriano; HÁ: hiperandrogenismo; AO= anovulatório; US: ultrassom; NA: não se aplica.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Tabela 7 – Características dos participantes dos estudos.** -->
|||||||||**Volume**|**Hormônio**|**Hormônio**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Estudo**|**Idade anos**<br>**(média ± DP) e**<br>**grupo SOP**|**Idade anos**<br>**(média ± DP)**<br>**grupo controle**|**IMC ± DP**<br>**(Kg/m**<sup>**2**</sup>**) grupo**<br>**SOP**|**IMC ± DP**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**grupo**<br>**controle**|**Contagem de**<br>**folículo antral**<br>**± DP (total)**<br>**grupo SOP**|**Contagem de**<br>**folículo antral ±**<br>**DP (total) grupo**<br>**controle**|**Volume**<br>**ovariano (ml)**<br>**± DP grupo**<br>**SOP**|**ovariano**<br>**(ml) ±**<br>**DP**<br>**grupo**<br>**controle**|**Anti-**<br>**Mulleriano**<br>**(ng/mL) ou**<br>**(pmol/l) ± DP**<br>**grupo SOP**|**Anti-**<br>**Mulleriano**<br>**(ng/mL) ou**<br>**(pmol/l) ± DP**<br>**grupo controle**|
|**Mahran et**|||||||||||
|**al.  2016**<br>**(105)**|29,7 ± 0,4|NA|28,6 ± 0,4|NA|32,2 ± 1,3|NA|9,6 ± 0,3|NA|4,5 ± 0,2|NA|
|**Christiansen**|||||||||||
|**et al. 2016**<br>**(106)**|33,3 (5,5)|36,2 (4,8)|27,8 (5,7)|27,0 (5,2)|35,7 (15)|12,5 (5,0)|NR|NR|44,8 (27,5)|14,6 (11,8)|
|**Köninger et**<br>**al.  2014**<br>**(107)**|Grau leve: 29,3<br>± 5,8|34,0 ± 5,5|Grau leve: 26,7<br>± 7,0|24,3 ± 4,4|Grau leve: 12,3<br>± 3,9|6,8 ± 1,9|Grau leve:<br>14,5 ± 5,8|8,8 ± 4,3|Grau leve:  5,1<br>± 3,9|2,1 ± 1,2|
||Grau grave:||Grau grave:||Grau grave:||Grau grave:||Grau grave: 8,9||
||27,1 ± 5,8||29,1 ± 7,4||13,3 ± 3,5||15,6 ± 5,3||± 7,3||
|**Eilertsen et**<br>**al.  2012**<br>**(108)**|SOP-R: 33,3<br>±5,5|35,2 ± 5,0|SOP-R:  27,8<br>±5,7|26,6+5,0|SOP-R: 17,8 ±<br>7,4|8,4± 4,5|SOP-R: 10,0±<br>3,7|5,8 ±2,7|SOP-R:<br>44,8±27,5|21,5+19,3|
||SOP-AES: 33,5||SOP-AES: 28,5||SOP-AES: 17,9||SOP-AES:||SOP-AES:42,7±||
||±5,8||±5,7||± 7,8||10,2±3,9||26,7||  
|**Estudo**|**Idade anos**<br>**(média ± DP) e**<br>**grupo SOP**|**Idade anos**<br>**(média ± DP)**<br>**grupo controle**|**IMC ± DP**<br>**(Kg/m**<sup>**2**</sup>**) grupo**<br>**SOP**|**IMC ± DP**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**grupo**<br>**controle**|**Contagem de**<br>**folículo antral**<br>**± DP (total)**<br>**grupo SOP**|**Contagem de**<br>**folículo antral ±**<br>**DP (total) grupo**<br>**controle**|**Volume**<br>**ovariano (ml)**<br>**± DP grupo**<br>**SOP**|**Volume**<br>**ovariano**<br>**(ml) ±**<br>**DP**<br>**grupo**<br>**controle**|**Hormônio**<br>**Anti-**<br>**Mulleriano**<br>**(ng/mL) ou**<br>**(pmol/l) ± DP**<br>**grupo SOP**|**Hormônio**<br>**Anti-**<br>**Mulleriano**<br>**(ng/mL) ou**<br>**(pmol/l) ± DP**<br>**grupo controle**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||Ovário<br>esquerdo:<br>9,75 ± 5,78||||
|**Pawelczak**<br>**et al.  2012**<br>**(109)**|15,2 ± 1,84|14,08 ± 1,7|2,07 ± 0,48|2,04 ± 0,25|NR|NR|Ovário<br>direito:  9,55<br>± 4,07|NR|6,78 ± 3,56|3,38 ± 1,48|
||||||||Volume total:<br>9,65 ± 4,58||||
|**Dewailly et**<br>**al.  2011**<br>**(110)**|Grupo 2:  28,7<br>(21,4–32,8)<br>Grupo 3: 27,6<br>(20,1– 34,0)|Grupo 1A:<br>30,0 (21,9 –<br>34,6)<br>Grupo 1B: 28,3<br>(19,9– 33,8)|Grupo 2: 26,0<br>(18,0–38,7)<br>Grupo 3: 28,0<br>(18,7– 41,7)|Grupo 1A:<br>24,0 (18,7 –<br>37,6)<br>Grupo 1B:<br>24,0 (18,0–<br>39,0)|Grupo 2: 21,0<br>(10,8–41,0)<br>Grupo 3: 30,5<br>(15,0– 58,7)|Grupo 1A: 11,5<br>(6,2– 21,8)<br>Grupo 1B: 19,0<br>(11,3– 28,6)|Grupo 2: 7,1<br>(3,6–14,9)<br>Grupo 3: 10,1<br>(4,6–17,0)|Grupo<br>1A:  5,0<br>(2,3–<br>9,2)<br>Grupo<br>1B: 6,7<br>(3,9–<br>12,4)|Grupo 2: 52,3<br>(18,0–103,4)<br>Grupo 3: 81,2<br>(25,4– 256,2)|Grupo 1A:  21,0<br>(10,0 –35,0)<br>Grupo 1B: 47,2<br>(36,6– 65,8)|
|**Chu et al.**<br>**2005 (111)**|NR|NR|NR|NR|NR|NR|12,0 ± 0,9|4,7 ± 0,2|6,79 ± 0,89|4,62 ± 0,53|
||||||2-9 mm: 16,6<br>(10,8–28,5)|2-9 mm: 7,3<br>(4,5–11,3)|||||
|**Pigny et al.**<br>**2003 (112)**|27,4 (21,3–<br>33,1)|28,3 (24–33)|26.7 (18,7–<br>37,7)|23,1 (19,2–<br>31,2)|2-5 mm:  12,8<br>(4,0–25,7)|2-5 mm: 4,8<br>(2,5–7)|12,6 (8,9–<br>17,0)|8,1 (5,6–<br>9,5)|47,1 (24,4–<br>85,0)|20,8 (3,6–37,2)|
||||||6-9 mm: 3,7|6-9 mm: 2,6(0–|||||  
|||||||||**Volume**|**Hormônio**|**Hormônio**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Estudo**|**Idade anos**<br>**(média ± DP) e**<br>**grupo SOP**|**Idade anos**<br>**(média ± DP)**<br>**grupo controle**|**IMC ± DP**<br>**(Kg/m**<sup>**2**</sup>**) grupo**<br>**SOP**|**IMC ± DP**<br>**(Kg/m**<sup>**2**</sup>**)**<br>**grupo**<br>**controle**|**Contagem de**<br>**folículo antral**<br>**± DP (total)**<br>**grupo SOP**|**Contagem de**<br>**folículo antral ±**<br>**DP (total) grupo**<br>**controle**|**Volume**<br>**ovariano (ml)**<br>**± DP grupo**<br>**SOP**|**ovariano**<br>**(ml) ±**<br>**DP**<br>**grupo**|**Anti-**<br>**Mulleriano**<br>**(ng/mL) ou**<br>**(pmol/l) ± DP**|**Anti-**<br>**Mulleriano**<br>**(ng/mL) ou**<br>**(pmol/l) ± DP**|
|||||||||**controle**|**grupo SOP**|**grupo controle**|
||||||(0–8,8)|5,5)|||||  
SOP: Síndrome do Ovário Policístico; HAM: hormônio anti-Mulleriano; DP: desvio-padrão, IMC: Índice de massa corporal; mm: milímetros; NR: não reportado; NA: não se aplica.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Tabela 8 –  Desfechos de acurácia diagnóstica, correlação e regressões.** -->
|**Estudo**|**Limiar de**<br>**positividad**<br>**e para**<br>**dosagem**<br>**de HAM**<br>**(ng/mL) ou**<br>**(pmol/l)**|**Sensibilidade**<br>**% (IC 95%)**|**Especificidad**<br>**e % (IC 95%)**|**AUCHAM**<br>**(IC 95%)**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo**<br>**controle**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação à**<br>**CFA - Grupo**<br>**SOP**|**Coeficiente β**<br>**de regressão**<br>**linear/múltip**<br>**la [IC 95%],**<br>**valor p em**<br>**relação à CFA**<br>**- Grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo SOP**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear/múlt**<br>**ipla [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Mahran**<br>**et al.**<br>**2016**<br>**(105)**|NR|NR|NR|NR|rp: 0,963<br>(<0,01)|NA|rp: 0,498<br>(<0,01)|NA||NA|||
|**Christia**<br>**nsen et**<br>**al. 2016**<br>**(106)**|NR|NR|NR|NR|NR|NR|NR|NR|**Univariada:**<br>1,42<br>[1,09;1,74],<br><0,01<br>**Multivariad**<br>**a:**1,37<br>[1,03; 1,72],<br><0,01|**Univariada:**<br>0,99 [0,64;<br>1,35] < 0,01<br>**Multivariada:**<br>0,87 [0,52;<br>1,22], <0,01|||
|**Köninge**<br>**r et al.**<br>**2014**<br>**(107)**|Ambos os<br>grupos: 3,5|**Grupo leve:**<br>71,4 (NR)|**Grupo leve:**<br>89,6 (NR)|**Grupo**<br>**leve:**<br>0,80<br>(0,65–<br>0,91)|NR|NR|NR|NR|**Grupo leve,**<br>**multivariad**<br>**a:**8,5 (IC<br>95%:<br>2,4;14,9);|**Multivariada**:<br>7,2 (IC 95%:<br>1,3; 13,4); p=<br>0,02|**Grupo leve,**<br>**multivariad**<br>**a:**-0,6 (IC<br>95%: -<br>5,7;4,8);|**Multivariad**<br>**a:**1,9 (IC<br>95%: -<br>0,7;4,6);<br>p=0,15|  
|**Estudo**|**Limiar de**<br>**positividad**<br>**e para**<br>**dosagem**<br>**de HAM**<br>**(ng/mL) ou**<br>**(pmol/l)**|**Sensibilidade**<br>**% (IC 95%)**|**Especificidad**<br>**e % (IC 95%)**|**AUCHAM**<br>**(IC 95%)**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo**<br>**controle**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação à**<br>**CFA - Grupo**<br>**SOP**|**Coeficiente β**<br>**de regressão**<br>**linear/múltip**<br>**la [IC 95%],**<br>**valor p em**<br>**relação à CFA**<br>**- Grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo SOP**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear/múlt**<br>**ipla [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||p=0,01||p=0,82||  
||||||||||**Grupo**||**Grupo**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||**Grupo Grave:**<br>84,7 (NR)|**Grupo grave:**<br>89,6% (NR)|**Grupo**<br>**grave:**<br>0,88<br>(0,80–|||||**grave,**<br>**multivariad**<br>**a:**9,5 (IC<br>95%:4,8;14,||**grave,**<br>**multivariad**<br>**a:**1,8 (IC<br>95%:||
|||||0,95)|||||4);||1,4;5,1);||
||||||||||p<0,0001||p=0,26||
|||**SOP-R:**|<br>**SOP-R:**||||||||||
|||10: 98,2 (NR)<br>20: 94,6 (NR)<br>25: 85,7 (NR)|10:  94,8 (NR)<br>20: 97,1 (NR)<br>25: 98,1 (NR)|**SOP-R:**<br>0,992<br>(0986-|||||||||
|**Eilertse**|10|30: 75,0 (NR)|30: 98,5 (NR)|,<br>0999)|||||||||
|**n et al.**<br>**2012**|20<br>25|40: 69,6 (NR)<br>**SOP-AES:**|40: 99,5 (NR)<br>**SOP-AES:**|,<br>**SOP-**<br>**AES**|rp: 0,788|NR|NR|NR|NR|NR|NR|NR|
|**(108)**|30|10: 97,7 (NR)|10: 95,0 (NR)|**:**<br>0994|||||||||
||40|20:  95,5 (NR)<br>25: 86,4 (NR)<br>30: 75,0 (NR)|20: 97,2 (NR)<br>25: 98,2 (NR)<br>30: 98,6 (NR)|,<br>(0,987-<br>1,00)|||||||||
|||40: 72,7(NR)|40: 99,5(NR)||||||||||  
|**Estudo**|**Limiar de**<br>**positividad**<br>**e para**<br>**dosagem**<br>**de HAM**<br>**(ng/mL) ou**<br>**(pmol/l)**|**Sensibilidade**<br>**% (IC 95%)**|**Especificidad**<br>**e % (IC 95%)**|**AUCHAM**<br>**(IC 95%)**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo**<br>**controle**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação à**<br>**CFA - Grupo**<br>**SOP**|**Coeficiente β**<br>**de regressão**<br>**linear/múltip**<br>**la [IC 95%],**<br>**valor p em**<br>**relação à CFA**<br>**- Grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo SOP**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear/múlt**<br>**ipla [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
|**Pawelcz**<br>**ak et al.**<br>**2012**<br>**(109)**|<br>NR|NR|NR|NR|**Ovário**<br>**esquerdo:**<br>NR - p=0,99<br>**Ovário**<br>**direito:**NR<br>p=0,88|NR|**Ovário**<br>**esquerdo:**<br>rp = 0,65;<br>p=0,0007<br>**Ovário**<br>**direito:**<br>rp=0,55;<br>p=0,0065<br>**Total =**rp =<br>0,66;<br>p=0,0007|NR|NR|NR|NR|NR|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Dewaill**<br>**y et al.**|30 pmol/L|92% (NR)|82% (NR)|0,973<br>(0,947–|rs= 0,771;<br>p<0,0001|NR|NR|NR|NR|NR|NR|NR|
|**2011**<br>**(110)**||||0,998)|||||||||
||35 pmol/L|92% (NR)|97% (NR)|paciente<br>s< 30<br>anos:<br>0,979|||||||||
||40 pmol/L|85% (NR)|100% (NR)||||||||||  
|**Estudo**|**Limiar de**<br>**positividad**<br>**e para**<br>**dosagem**<br>**de HAM**<br>**(ng/mL) ou**<br>**(pmol/l)**|**Sensibilidade**<br>**% (IC 95%)**|**Especificidad**<br>**e % (IC 95%)**|**AUCHAM**<br>**(IC 95%)**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e CFA -**<br>**grupo**<br>**controle**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo SOP**|**Coeficiente**<br>**de**<br>**correlação**<br>**entre HAM**<br>**e volume**<br>**ovariano**<br>**grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação à**<br>**CFA - Grupo**<br>**SOP**|**Coeficiente β**<br>**de regressão**<br>**linear/múltip**<br>**la [IC 95%],**<br>**valor p em**<br>**relação à CFA**<br>**- Grupo**<br>**controle**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo SOP**|**Coeficiente**<br>**β de**<br>**regressão**<br>**linear/múlt**<br>**ipla [IC**<br>**95%], valor**<br>**p em**<br>**relação ao**<br>**volume**<br>**ovariano -**<br>**Grupo**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
||pacientes <<br>30 anos: 37|95% (NR)|100% (NR)|||||||||
|---|---|---|---|---|---|---|---|---|---|---|---|
||pmol/L|||||||||||
|**Chu et**<br>**al. 2005**<br>**(111)**|NR|NR|NR|NR<br>NR|NR|r=0,331;<br>p<0,05|NR|NR|NR|NR|NR|
|||||2-5 mm: rs=|2-5 mm:|||||||
|**Pigny et**<br>**al. 2003**<br>**(112)**|NR|NR|NR|NR<br>0,670; p=<br>0,0001<br>6-9 mm:<br>rs=0,042;|rs=0,370;<br>p=0,022<br>6-9 mm:<br>rs=0,137;|NR|NR|NR|NR|NR|NR|
|||||p= 0,73|p= 0,37|||||||  
SOP: Síndrome do Ovário Policístico; HAM: hormônio anti-Mulleriano; CFA: contagem de folículos antrais; NR: não reportado; IC: intervalo de confiança; mm: milímetro; rs: coeficiente de correlação de Pearson; rs: coeficiente de correlação de Sperman; NR: não reportado; NA: não se aplica.  
**RECOMENDAÇÃO** : Os estudos avaliados utilizaram técnicas distintas para sua quantificação e não estabelecem de forma conclusiva os pontos de corte para positividade. Assim, ainda não é possível recomendar sua dosagem como critério diagnóstico de SOP em substituição ao diagnóstico por US. **(GRADE: recomendação condicional a favor; qualidade da**  
**evidência: baixa).**  
**Questão de Pesquisa 3:** Qual a estimativa de risco de câncer de mama em mulheres com PCOS?  
**1)** **<mark>Estratégia de busca</mark>**

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
<mark>("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome) AND (“Breast Cancer” [Mesh] OR breast cancer) AND ("Risk Factors"[Mesh] OR risk factor OR prognostic factor)</mark>  
<mark>Total: 65 referências</mark>  
<mark>Data do acesso: 08/09/2016</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
'ovary polycystic disease'/exp OR 'ovary polycystic disease' AND ('breast cancer'/exp OR     'breast cancer') AND ('risk factor'/exp OR 'risk factor') AND [embase]/lim  
<mark>Total: 69 referências</mark>  
<mark>Data do acesso: 09/09/2016</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 134 referencias (65 no MEDLINE e 69 no Embase). Destas, 14 foram excluídas por estarem duplicadas. Cento e vinte referências foram triadas por meio da leitura de título e resumos, das quais 22 tiveram seus textos completos avaliados para confirmação da elegibilidade. Nessa etapa, 18 estudos foram excluídos, sendo 6 por serem revisão narrativa/carta ao editor/ comentários, 2 por avaliarem outras disfunções ovarianas que não SOP, 2 estudos por estarem em idioma não inglês (um em francês e outro em persa), um estudo (2 citações) por avaliar mortalidade por causa de câncer de mama e não sua prevalência. Por fim, 6 citações correspondentes a 5 estudos foram excluídas por já terem sido consideradas nas revisões sistemáticas e meta-análises selecionadas.</mark>  
<mark>Ao final, 4 estudos foram considerados elegíveis (71, 113-115).</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A descrição sumária dos estudos e características dos pacientes encontra-se na Tabela 9. Os resultados</mark>  
<mark>de prevalência de câncer de mama em mulheres com Síndrome do Ovário Policístico encontram-se na Tabela 10.</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Tabela 9 – Características dos estudos e pacientes.** -->
|**Autor e**<br>**ano de**<br>**publicação**|**Desenho do**<br>**estudo**|**População e**<br>**objetivo**|**Tamanho da**<br>**amostra**|**Idade em anos no**<br>**grupo intervenção**<br>**(média e desvio-**<br>**padrão ou mediana e**<br>**intervalo mínimo-**<br>**máximo)**|**Idade em anos no**<br>**grupo controle**<br>**(média e desvio-**<br>**padrão ou mediana**<br>**e intervalo mínimo-**<br>**máximo)**|**IMC**<br>**(Kg/m2)**<br>**intervenção**|**IMC**<br>**(Kg/m2)**<br>**intervenção**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|
|**Barry et al.**<br>**2014 (71)**|Revisão<br>sistemática e<br>meta-análise<br>de estudos<br>observacionais.|Sumarizar as<br>evidências de<br>estudos<br>comparativos que<br>tenham avaliado o<br>risco de câncer de<br>endométrio, de<br>mama e de ovário<br>em mulheres com<br>SOP.|3 estudos, sendo<br>um estudo de<br>coorte e dois de<br>caso-controle,<br>totalizando 529<br>participantes com<br>SOP e 39795<br>controles.|Anderson et al. 1<br>Talamini et al. 1<br>Ghasemi et al. 2|997: NR (55-69)<br>997: NR (20-74)<br>010: NR (30-51)|NR|NR|Baixo risco<br>A revisão sistemática<br>apresenta baixo risco<br>de viés. Entretanto, os<br>3 estudos incluídos<br>apresentam risco<br>grave de viés por não<br>definirem<br>adequadamente a<br>condição de interesse,<br>não ser representativo<br>da população com a<br>condição e os grupos<br>não serem<br>comparáveis.|
|**Chittenden**<br>**et al. 2009**<br>**(113)**|Revisão<br>sistemática e<br>meta-análise<br>de estudos<br>observacionais.|Sumarizar as<br>evidências de<br>estudos<br>comparativos que<br>tenham avaliado o<br>risco de câncer de<br>endométrio, de|3 estudos, sendo<br>todos estudos de<br>caso-controle,<br>totalizando 133<br>participantes com<br>SOP e 23709<br>controles.|Baron et al. 2001: NR<br>(50-75)<br>Talamini et al. 1997:<br>NR (23-74)<br>Gammon and<br>Thompson 1991: NR<br>(20-74)|Baron et al. 2001: <<br>75<br>Talamini et al. 1997:<br>NR (20-74)<br>Gammon and<br>Thompson 1991: NR|NR|NR|Alto risco de viés<br>Não apresenta<br>estratégia de busca e<br>não avaliou risco de<br>viés dos estudos<br>incluídos.|  
mama e de ovário em mulheres com SOP.  
|**Kim et al.**<br>**2016 (114)**|Estudo<br>observacional,<br>de base<br>populacional,<br>caso-controle.|Avaliar a<br>associação entre<br>SOP e<br>desenvolvimento<br>de câncer de<br>mama.|1508 casos de<br>câncer de mama,<br>sendo 67 com<br>SOP; e 1556 não-<br>casos.|53,8 ± 12,2|58,0 ± 12,8|27,4 ± 6,2|26,5 ± 5,7|Moderado risco de<br>viés<br>Principalmente<br>porque as condições<br>de interesse não<br>foram<br>adequadamente<br>definidas.|
|---|---|---|---|---|---|---|---|---|
|||||||||Moderado risco de|
|||Avaliar a||||||viés|
|**Shen et al.**<br>**2015 (115)**|Estudo<br>observacional,<br>coorte<br>retrospectiva|associação entre<br>SOP e<br>desenvolvimento<br>de cânceres<br>ginecológicos em<br>população com<br>SOP da Taiwan.|3566 participantes<br>com SOP e 14264<br>controles.|27,04 (22,66–32, 10)|27,05 (22,72–32,10)|NR|NR|Apesar das análises<br>terem sido ajustada<br>por diversas variáveis,<br>dados de IMC,<br>consumo de álcool e<br>tabagismo não<br>estavam disponíveis|
|||||||||para ajuste.|  
<mark>SOP: Síndrome dos Ovários Policísticos; NR: não relatado.</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Tabela 10 – Resultados dos estudos.** -->
|**Autor e ano de**<br>**publicação**|<br>**Critério diagnóstico para**<br>**câncer de mama**|**Critério diagnóstico para SOP**|**Proporção câncer de**<br>**mama no grupo SOP n/N**<br>**(%)**|**Proporção câncer de**<br>**mama no grupo**<br>**controle n/N (%)**|**Medida de associação**<br>**SOP versus controle RR**<br>**ou OR (IC 95%)**|**Valor de p**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|---|---|
|**Barry et al.**<br>**2014 (71)**|Em 2 de 3 estudos o<br>diagnóstico foi<br>histologicamente<br>confirmado. O 3° apenas<br>apresenta o CID.|Em 2 de 3 estudos o<br>diagnóstico foi por<br>autorrelato. Apenas um<br>estudo utilizou o critério de<br>Rotterdam, com entrevista,<br>confirmado por US.|Toda a corte: 39/529<br>(7,4)<br>Mulheres com < 54 anos:<br>25/57 (43,85)|Toda a coorte:<br>3579/39795 (9)<br>Mulheres com < 54<br>anos: 2710/5432 (50)|Toda a coorte: OR 0,95<br>(0,64-1,39)<br>Mulheres com < 54<br>anos: OR 0,75 (0,46-<br>1,32)|P= 0,11<br>P= 0,35|NR|
|**Chittenden et**<br>**al. 2009 (113)**|Em todos os estudos o<br>diagnóstico foi<br>histologicamente<br>confirmado.|Em 2 estudos o diagnóstico foi<br>realizado pelo médico e em<br>um estudo por autorrelato|59/133 (44,3)|11777/23709 (49,7)|OR 0,88 (0,44-1,77)|p=0,73|NR|
|**Kim et al. 2016**<br>**(114)**|<br>Os casos foram fornecidos<br>pelos 28 hospitais da região,<br>mediante contato diário ou<br>semanal. Não há descrição<br>dos critérios.|<br>Autorrelato, mediante<br>questionário estruturado com<br>perguntas que utilizavam o<br>critério diagnóstico de<br>Rotterdam|Toda a coorte: 38/1508<br>(2,51)<br>Mulheres pré-<br>menopausa: 19/448 (4,2)<br>Mulheres pós-<br>menopausa: 16/973<br>(1,64)<br>|Toda a coorte: 29/1448<br>(2,0)<br>Mulheres pré-<br>menopausa: 9/489<br>(1,84)<br>Mulheres pós-<br>menopausa: 19/954<br>(1,99)|<br>OR<br>ajust_idade+ativ_fisica:<br>1,37 (0,81-2,29)<br>OR<br>ajust_idade+ativ_fisica:<br>2,74 (1,13; 6,63)<br>OR<br>ajust_idade+ativ_fisica:<br>0,67 (0,33; 1,35)|p=NS<br>p=NS<br>P=NS|NR|
|**Shen et al.**<br>**2015 (115)**|Diagnóstico confirmado por<br>histologia|Diagnóstico realizado pelo<br>médico utilizando critérios da<br>Diretriz_U.S. National Institutes_<br>_of Health_|14/3566 (0,4)|30/14264 (0,2)|OR adj 1,98 (1,04-3,77)<br>OR simulado - Monte<br>Carlo 1,61 (0,91-2,84)|p< 0,05<br>p=NS|7,15 anos<br>(5,93-8,38)|  
<mark>SOP: Síndrome dos Ovários Policísticos; CID: Código Internacional de Doenças; US: ultrassonografia; NR: não relatado; IC 95%: Intervalo de confiança em 95%; RR: risco relativo; OR: odds ratio; O</mark> Rajust_idade+ativ_fisica: Odds ratio ajustado pela idade e atividade física; OR simulado - Monte Carlo: Odds ratio obtido por simulação de Monte Carlo.  
**Questão de Pesquisa 4:** <mark>Quais são os tratamentos não medicamentosos para Hirsutismo em mulheres</mark>  
<mark>com PCOS?</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>MEDLINE via Pubmed</mark>** -->
<mark>((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ("Hirsutism"[Mesh] OR hirsutism)) AND (nonpharmacological OR non-pharmacological OR electrolysis OR photoepilation OR laser OR intense pulsed light OR shaving OR plucking OR waxing OR bleaching)</mark>  
<mark>Total: 45 referências</mark>  
<mark>Data de acesso: 19/06/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE</mark>** -->
<mark>('ovary polycystic disease'/exp OR 'ovary polycystic disease') AND ('hirsutism'/exp OR     'hirsutism') AND ('nonpharmacological' OR 'non-pharmacological' OR 'electrolysis'/exp OR    'electrolysis' OR 'photoepilation' OR 'laser'/exp OR 'laser' OR 'intense pulsed light' OR 'shaving'     OR 'plucking' OR 'waxing' OR 'bleaching'/exp OR 'bleaching') AND [embase]/lim</mark>  
<mark>TOTAL: 126 citações</mark>  
<mark>Data de acesso: 19/06/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca nas bases de dados resultou em 171 referências (45 no MEDLINE e 126 no EMBASE). Destas, 31 estavam duplicadas e 140 foram triadas por meio da avaliação de título e resumo. Doze publicações foram avaliadas na íntegra, pela leitura do texto integral, para confirmação da elegibilidade, sendo oito excluídas nessa etapa.</mark>  
<mark>Foram excluídas duas revisões baseadas em evidências sobre tratamento de hisurtismo de diversas causas. Uma revisão sistemática avaliou o efeito de luz pulsada em pacientes obesas e não obesas, mas nem todas com diagnóstico de SOP. A segunda revisão sistemática avaliou o efeito incremental da metformina em pacientes recebendo tratamento com luz pulsada. Uma revisão sistemática publicada em dois periódicos avaliou o efeito de tratamentos para o hirsutismo de diversas causas, exceto laser e luz pulsada isoladas. Apenas dois estudos avaliaram desfechos FG e as intervenções avaliadas não envolveram os tratamentos de interesse. Outra revisão sistemática publicada avaliou efeito de atividade física e orientações sobre dieta. Por fim, foi excluída uma série de casos publicada da qual apenas 5 pacientes com SOP apresentaram efeito paradoxal ao tratamento com luz pulsada.</mark>  
<mark>Ao final, quatro estudos foram incluídos, sendo três estudos comparativos e um não comparativo (116-119).</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A Tabela 11 apresenta as c</mark> aracterísticas dos estudos avaliando os efeitos de tratamentos não medicamentosos do hirsutismo <mark>em pacientes com SOP. A Tabela 12 apresenta as características dos pacientes incluídos e a Tabela 13 os desfechos</mark> reportados nos estudos avaliando os efeitos dos tratamentos não medicamentosos do hirsutismo.  
**Tabela 11 – Características dos estudos avaliando tratamentos não medicamentosos do hirsutismo em mulheres com SOP.**  
|**Autor, ano**|**Desenho**<br>**do estudo**|**População**|**Objetivo**|**Detalhes Intervenção**|**Detalhes Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Clayton et**<br>**al. 2005**<br>**(116)**|ECR|Mulheres<br>com SOP e<br>hirsutimo<br>facial (com<br>pelos<br>escuros)|Avaliar o efeito de<br>tratamento com<br>laser no hirsutismo<br>facial e desfechos<br>psicológicos de<br>mulheres com SOP|Laser Alexandrite, comprimento de onda<br>755 nm, pulso de 20ms, spot de 12,5 mm<br>(Apogee 6200; Cynosure, Chelmsford,<br>MA, USA.), com resfriador epidérmico<br>integrado (Cryo 5 Smartcool). Densidade<br>de energia média 23,6 J/cm2 (variando<br>entre 14 e 30), em intervalos de 4-6<br>semanas, por 6 meses|Sham (placebo). O mesmo laser foi aplicado<br>numa densidade de 4,8 J/cm2, considerado<br>não efetivo|Moderado<br>Não foi descrito sigilo da<br>alocação. Estudo foi<br>aberto para médico<br>assistente que efetuou os<br>tratamentos (sendo<br>também aquele que<br>realizou a randomização).<br>Não descrito se análises<br>foram por intenção de<br>tratar|
|**McGill et al.**<br>**2007 (117)**|Estudo<br>experime<br>ntal não<br>comparati<br>vo (série<br>de casos)|Mulheres<br>com SOP e<br>hirsutimo<br>facial (com<br>pelos<br>escuros)|Avaliar a eficácia<br>do laser<br>Alexandrite na<br>remoção de pelos<br>faciais em<br>mulheres com SOP|Laser Alexandrita, comprimento de onda<br>755 nm, pulso de 3ms, spot de 15 mm<br>(GentleLase Alexandrite, Candela Corp.,<br>Wayland, MD, USA), com refriador<br>epidérmico integrado). Densidade de<br>energia 18-25 J/cm2 para fototipos de<br>pele I e II e 8-14 J/cm2 para tipo IV.<br>Número médio de sessões: 8, variando 5-<br>|NA|Alto<br>Série de casos para<br>inferir eficácia|
|||||13|||
|**McGill et al.**<br>**2007b (118)**|ECR<br>(randomiz<br>ação dos<br>lados das<br>faces)|Mulheres<br>com SOP e<br>hirsutimo<br>facial (com<br>pelos<br>castanhos ou<br>pretos)|Comparar a<br>eficácia do laser<br>Alexandrite vs. Luz<br>pulsada em<br>mulheres com SOP|Laser Gentle Alexandrite, comprimento<br>de onda 755 nm, pulso de 3ms, spot de<br>15mm (Candela Corp., Wayland, MA),<br>com resfriador epidérmico integrado<br>(Dynamic Cooling Device). Em peles<br>fototipo I-III foi utilizado densidade de 20<br>J/cm2 inicialmente com progressão para<br>até 30 se tolerado; fototipo IV<br>inicialmente 10 J/cm2 com progressão<br>para até 18 se tolerado. Realizadas 6|Luz pulsada Lumina com filtro de flash de<br>650-1100 nm incorporado (Lynton Lasers<br>Ltd., Cheshire, UK). Tratamento aplicado em<br>áreas de 3cm x 1cm, e uso de gel de ECG<br>resfriado e resfriador de (Cyro 5, Zimmer<br>Medizin-Systems, Irvine, CA). Em peles<br>fototipo I-III foi utilizado densidade de 26-28<br>J/cm2 inicialmente com progressão para até<br>42 se tolerado, 3 pulsos de 55ms e intervalo<br>de 20ms entrepulsos;fototipo IV|Moderado<br>Estudo aberto, não<br>descrito se houve perdas<br>e as análises foram por<br>intenção de tratar|  
|**Autor, ano**|**Desenho**<br>**do estudo**|**População**|**Objetivo**|**Detalhes Intervenção**|**Detalhes Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|||||sessões com intervalos de 6 semanas|inicialmente 16-18 J/cm2 com progressão<br>para até 24-28 se tolerado, 4 pulsos de<br>140ms com intervalo entre pulsos de 40ms.<br>Realizadas 6 sessões com intervalos de 6<br>semanas||
|**Pai et al.**<br>**2011 (119)**|Estudo<br>comparati<br>vo não<br>randomiz<br>ado<br>(compara<br>ção dos<br>lados das<br>faces)|Mulheres<br>com SOP e<br>hirsutismo<br>facial e pele<br>tipo IV e V<br>(critérios de<br>Fitzpatrick)|Avaliar a eficácia e<br>segurança do laser<br>diodo de baixa<br>intensidade e alta<br>frequência vs. alta<br>intensidade e<br>baixa frequência|Laser Soprano XL (Alma Lasers Ltd,<br>Caesarea, Israel), modo SHR, densidade<br>de até 10 J/cm2, frequência 10 Hz, e<br>duração de pulso de 20ms. 6 sessões em<br>intervalos de 4-6 semanas|Laser Light-Sheer (Lumenis, Inc., Santa Clara,<br>CA, USA), densidade entre 25-35<br>J/cm2 conforme tolerância, frequência 2 Hz,<br>pulso de 30 ms. 6 sessões em intervalos de<br>4-6 semanas|Moderado<br>Estudo aberto, excluíram<br>9 pacientes das análises<br>(inclusive dos dados de<br>base) por não terem<br>completado o protocolo,<br>e se as análises seguiram<br>princípio de intenção de<br>tratar|  
ECR: ensaio clínico randomizado; SOP: síndrome do horário policístico; NA: não descrito.  
**Tabela 12 – Características dos pacientes incluídos nos estudos avaliando tratamentos não medicamentosos do hirsutismo em mulheres com SOP.**  
|**Autor, ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**Intervenção**|**Idade Controle**|**IMC**<br>**intervenção**|**IMC**<br>**Controle**|**Tempo de**<br>**seguimento**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|---|
||||||||Imediatamente|||
|**Clayton et al.**<br>**2005 (116)**|51|37|33,5 (8,0) anos|32,5 (6,5) anos|NR|NR|após final do<br>tratamento de 6<br>meses|7 (razões não<br>apresentadas)|6 (razões não<br>apresentadas)|  
|**Autor, ano**|**N**<br>**intervenção**|**N controle**|**Idade**<br>**Intervenção**|**Idade Controle**|**IMC**<br>**intervenção**|**IMC**<br>**Controle**|**Tempo de**<br>**seguimento**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|---|
|**McGill et al.**<br>**2007 (117)**|60|NA|NR|NA|NR|NA|6 semanas após a<br>sexta sessão|23 (14 pacientes não<br>receberam a sexta<br>sessão, 9 pacientes<br>não foram<br>reavaliadas)|<br>NA|
|**McGill et al.**<br>**2007b (118)**|38|38|Toda a c<br>(variação 1|oorte: 34<br>6–69) anos|NR|NR|6 meses após a<br>última sessão|NR|NR|
||51 (apenas<br>dados de 42|51 (apenas<br>dados de 42||||||||
|**Pai et al. 2011**<br>**(119)**|foram<br>apresentados<br>na<br>publicação)|foram<br>apresentados<br>na<br>publicação)|NR|NR|NR|NR|Imediatamente<br>após última sessão|Toda<br>9 (não comple|a coorte:<br>taram protocolo)|  
N: tamanho de amostra no grupo; IMC: índice de massa corpórea; NR: não reportado; NA: não se aplica. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
**Tabela 13 – Desfechos apresentados nos estudos avaliando os efeitos tratamentos não medicamentosos do hirsutismo em mulheres com SOP.**  
|||**Desfecho de eficácia**||**Desfec**|**ho de segurança**||
|---|---|---|---|---|---|---|
|**Autor,**||||||**p para**|
|**ano**|**Intervenção**|**Controle**|**p para comparação**|**Intervenção**|**Controle**|**comparaçã**<br>**o**|
|**Clayton et**<br>**al. 2005**<br>**(116)**|Densidade de pelos: 3,6 (2,8) *<br>Tempo para remoção de pelos: 21<br>(19) †<br>HADS - depressão: 3,6 (3,5)<br>HADS - ansiedade: 8,2 (3,8)<br>WHOQOL-Bref psicológico: 61,2<br>(16,7)<br>WHOQOL-Bref social: 57,8 (24,0)<br>Questionário Rosenberg -<br>autoestima:<br>30,9 (5,3)|Densidade de pelos: 6,1 (2,6) *<br>Tempo para remoção de pelos: 56<br>(73) †<br>HADS - depressão: 5,4 (3,8)<br>HADS - ansiedade: 9,3 (4,9)<br>WHOQOL-Bref psicológico: 51,5<br>(21,5)<br>WHOQOL-Bref social: 53,6 (27,2)<br>Questionário Rosenberg -<br>autoestima: 28,7 (6,0)|Densidade de pelos: p<0,05<br>Tempo para remoção de pelos:<br>p<0,05<br>HADS depressão: p<0,05<br>HADS ansiedade: p<0,05<br>WHOQOL-Bref psicológico: p<0,05<br>WHOQOL-Bref social: p>0,05<br>Questionário Rosenberg: p>0,05|NR|NR|NA|
|**McGill et**<br>**al. 2007**<br>**(117)**|Em relação ao valor de base:<br>Redução média de pelos: 31% (38%)<br>Intervalo sem pelos: 1,9 semanas<br>(NR)|NA|Em relação ao valor de base:<br>Redução de pelos: p=0,001<br>Intervalo sem pelos: p=0,001|NR|NA<br>Púrpura: 0|NA|
|**McGill et**<br>**al. 2007b**<br>**(118)**|Intervalo sem pelos: mediana 7<br>semanas (variação 0-15)<br>Contagem de pelos: mediana 20 (EP<br>2) ‡<br>Satisfação com tratamento:<br>Mediana 7,7 (variação 1,3–9,8) §|Intervalo sem pelos: mediana 2<br>semanas (variação 0-10)<br>Contagem de pelos: mediana 28 (EP<br>3) ‡<br>Satisfação com tratamento:<br>Mediana 5,1 (variação 0,4–9,6) §|Intervalo sem pelos: p<0,005<br>Contagem de pelos: p<0,001<br>Satisfação com tratamento:<br>p<0,002|Púrpura: 4/38<br>Bolhas: 0<br>Hiperpigmentação:<br>0<br>Leucotriquia: 0|Bolhas: 3/38<br>(7,8)<br>Hiperpigmentaçã<br>o:<br>1/38 (2,6)<br>Leucotriquia:<br>2/38 (5,2)|NR|  
|**Pai et al.**<br>**2011**|Densidade de pelos:<br>Redução mediana 90,5% (7%)**|Densidade de pelos:<br>Redução mediana 85% (8,5%)|Densidade de pelos: p<0,063|Dor: mediana 2 (NR)<br>††|Dor: mediana 6<br>(NR) ††|<br>Dor:|
|---|---|---|---|---|---|---|
|<br>**(119)**|Espessura do pelo:<br>Mediana 0,02 mm (NR) **|Espessura do pelo:<br>Mediana 0,05 mm (NR) **|Espessura do pelo: p<0,0005|<br>Eventos adversos: 0|Eventos<br>adversos: 0|p<0,0005|  
HADS: Hospital Anxiety and Depression Scale; WHOQOL: World Health Organization Quality of Life Questionnaire; NR: não reportado; NA: não se aplica; EP: erro padrão. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
*Densidade de pelos, autorreferidos, variando entre 1-10, sendo 10 a maior densidade.  
†Tempo para remoção de pelos em minutos/semana.  
‡ Contagem de pelos por videomicroscopia.  
§Satisfação com tratamento, variando entre 0-10, sendo 10 a maior satisfação.  
** Avaliado pelo sistema de análise SIF-1.  
†† Dor avaliada por escala análoga visual 1-10, sendo 10 a maior intensidade.  
**Questão de Pesquisa 5:** Qual a eficácia e segurança dos anticoncepcionais hormonais combinados (AHC)  
em relação aos princípios ativos e à via de administração?

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **MEDLINE via Pubmed:** -->
((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ((("Contraceptives, Oral"[Mesh] OR Oral Contraceptives)) OR ((hormonal contraceptives OR hormonal contraceptive OR hormonal methods OR birth control pill OR hormonal contraception)))) AND ("Treatment Outcome"[Mesh] OR Clinical Effectiveness OR Clinical Efficacy OR Treatment Efficacy)  
<mark>Total: 222 referências</mark>  
<mark>Data de acesso: 2</mark> 9/07/2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
'ovary polycystic disease'/exp OR 'ovary polycystic disease' AND ('treatment outcome'/exp OR 'treatment outcome') AND [embase]/lim AND ('oral contraceptive agent'/exp OR 'oral   contraceptive agent' AND [embase]/lim OR ('hormonal contraceptive'/exp OR 'hormonal     contraceptive' OR 'contraceptive agent'/exp OR 'contraceptive agent' OR 'hormonal     contraception'/exp OR 'hormonal contraception' AND [embase]/lim))  
<mark>Total: 223 referências</mark>  
<mark>Data de acesso: 03/08/</mark> 2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **5)** **<mark>Seleção das evidências</mark>** -->
A busca nas bases de dados resultou em 445 citações (222 no MEDLINE e 223 no EMBASE). Após remoção de 39 duplicadas, 406 citações foram avaliadas por meio da leitura de título e resumo. Vinte e quatro referências tiveram seus textos avaliados na íntegra. Como critério de inclusão, foram priorizadas revisões sistemáticas com meta-análise de estudos observacionais ou randomizados e estudos primários do tipo ensaio clínico randomizado. Foram excluídos 18 estudos: 1) dois estudos não eram revisões sistemáticas; 2) os objetos de estudos de duas referências não eram de interesse desta pergunta de pesquisa; 3) quatro ensaios clínicos estavam incluídos nas revisões sistemáticas e assim foram excluídos; 5) um estudo foi excluído por ser um estudo de crossover; 6) nove estudos eram estudos observacionais.  
No total, foram incluídas três revisões sistemáticas com meta-análise (120-122) e três ensaios clínicos randomizados (123-125). No total, seis estudos foram considerados elegíveis (120-125).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **6)** **<mark>Descrição dos estudos e seus resultados:</mark>** -->
A descrição sumária do estudo encontra-se na Tabela 14. A Tabela 2 apresenta as características dos participantes. As Tabelas 15 e 16 apresentam os desfechos relacionados à eficácia dos anticoncepcionais hormonais combinados em pacientes com SOP e a Tabela 17 apresenta desfechos de segurança.  
**Tabela 14 – Características dos estudos que avaliaram a eficácia e segurança dos anticoncepcionais hormonais combinados.**  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**Tamanho da**<br>**amostra**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Li et al.**<br>**2017**<br>**(120)**|Revisão<br>Sistemática e<br>meta-análise<br>de ECR|Analisar o impacto do uso<br>do Yasmim (pílula de<br>DRSP) comparado com<br>outros tratamentos<br>padrões para sintomas de<br>SOP|18 estudos; 1475<br>pacientes|DRSP|CPA ou DSG ou<br>metformina|3 a 12<br>meses|Alto risco de viés<br>A qualidade da evidência dos estudos<br>não foi avaliada com a ferramenta<br>adequada. A lista de artigos excluídos<br>não foi fornecida. Não foi avaliado o<br>risco de viés de publicação. Não foi<br>realizado análise de sensibilidade.|
||Revisão<br>Sistemática e||||||Alto risco de viés<br>A qualidade da evidência dos estudos<br>não foi avaliada com a ferramenta<br>adequada. Não foi reportado se a<br>seleção dos estudos ocorreu em dupla|
|**Amiri et**<br>**al. 2017**<br>**(121)**|meta-análise<br>de estudos<br>observacionais<br>e braços<br>individuais de<br>ECR|Avaliar o efeito de CO no<br>perfil metabólico em<br>mulheres com SOP|26 estudos; 831<br>mulheres|CO combinados|Não exposição ao<br>CO|3,6 e 12<br>meses|de revisores de forma independente.<br>Busca em base de dados não foi<br>adequada. A extração dos estudos foi<br>feita somente por um revisor. Viés de<br>publicação nos desfechos (IMC,<br>colesterol total, LDL depois de 3 e 6<br>meses de tratamento, insulina de<br>jejum e PAS depois de 12 meses de<br>tratamento).|
|**Halperin**<br>**et al.**<br>**2011**<br>**(122)**|Revisão<br>Sistemática e<br>meta-análise<br>de estudos<br>observacionais|Investigar a associação<br>entre mudanças<br>metabólicas e uso de CO<br>em mulheres com SOP|42 estudos; n não<br>reportado|CO combinação de EE<br>com qualquer tipo de<br>progesterona|Não exposição ao<br>CO|6 meses (3-<br>36)|Alto risco de viés<br>Não está claro se a seleção dos estudos<br>ocorreu em dupla. Não foi fornecido a<br>lista de estudos excluídos. Na mesma<br>meta-análise foi combinado estudo<br>RCT com observacional.|  
|**Autor,**<br>**ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**Tamanho da**<br>**amostra**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Collona**<br>**et al.**<br>**2011**<br>**(123)**|ECR|Avaliar o efeito de<br>EE/DRSP e EE/CMA no<br>aumento dos níveis de<br>androgênico sérico e em<br>parâmetros de pele de<br>mulheres afetadas por<br>acne moderada ou grave<br>e SOP|59 mulheres|EE 30mcg + DRSP 3 mg|<sup>EE 30mcg + CMA</sup><br>2mg|6 meses|Alto risco de viés<br>Não descreve o método de<br>randomização e o sigilo da alocação.<br>Participantes e avaliadores dos<br>desfechos não foram cegados.|
|**Kriplani**<br>**et al.**<br>**2010**<br>**(124)**|ECR|Avaliar a eficácia de EE +<br>drospirenona vs. EE +<br>desogestrel em mulheres<br>com SOP há pelo menos<br>6 meses|60 mulheres|EE 30mcg + DRSP 3mg<br>em esquema 21/7<br>durante 6 meses|EE 30 mcg +<br>DSG150mcg em<br>esquema 21/7<br>durante 6 meses|6 meses<br>após<br>tratamento|Alto risco de viés<br>Apenas descreve que pacientes foram<br>randomizadas por meio de tabela de<br>números aleatórios gerada por<br>computador. Não descreve sigilo da<br>alocação. Estudo aberto.<br>Aparentemente as análises seguiram<br>princípio de intenção de tratar e<br>perdas foram descritas|
|**Battaglia**<br>**et al.**<br>**2010**<br>**(125)**|ECR|Comparar o efeito da<br>pílula contendo DRSP<br>com os hormônios do<br>anel vaginal em relação<br>ao metabolismo lipídico e<br>de carboidrato e os<br>marcadores de<br>substituição da função<br>arterial em mulheres com<br>SOP|37 mulheres com<br>maiores de 18 anos|Tratamento oral com<br>Yasmin (DRSP 3mg +<br>EE) em esquema 21/7<br>durante 6 meses|Anel vaginal<br>combinado Nuva<br>Ring (EE15μg +<br>etonogestrel 120<br>μg) em esquema<br>21/7 durante 6<br>meses|6 meses|Alto risco de viés<br>Participantes e avaliadores dos<br>desfechos não foram cegados. Análise<br>não foi por intenção de tratar (não<br>foram analisados todos os<br>participantes que foram<br>randomizados);|  
ECR: ensaio clínico randomizado; EE: etinilestradiol; CA: acetato de ciproterona; CMA: acetato de cloradinona; DRSP: drospirenona; DSG: desogestrel; SOP: Síndrome dos Ovários Policísticos; CO: contraceptivos orais; PAS: pressão arterial sistólica; IMC: índice de massa corporal; LDL: proteína de baixa densidade de colesterol.  
**Tabela 15 – Características dos participantes dos estudos que avaliaram eficácia e segurança dos anticoncepcionais hormonais combinados.**  
|**Autor,**<br>**ano**|**N**<br>**Intervençã**<br>**o**|**N**<br>**Control**<br>**e**|**Idade**<br>**Intervenção**|**Idade Controle**|**IMC kg/m2 intervenção**|**IMC kg/m2 Controle**|**Perda de seguimento**<br>**Intervenção**|**Perda de seguimento**<br>**controle**|
|---|---|---|---|---|---|---|---|---|
|**Li et al.**|||||||||
|**2017(120**<br>**)**|NA|NA|Variação: 1|3-40 anos|Maioria nã|o classificou|Variaçã|o: 0- 21|
|**Amiri et**|||||||||
|**al.**<br>**2017(121**<br>**)**|NA|NA|Média (IC 95%): 2<br>24,|3,11 anos (22,05-<br>17)|Reportado|por estudo|NA|NA|
|**Halperin**|||||||||
|**et al.**<br>**2011(122**<br>**)**|NA|NA|Mediana (min-m<br>(15,3-|áx.): 24,3 anos<br>33,5)|Mediana (min-máx|.):24,7 (21,8–40,1)|NA|NA|
|**Collona**<br>**et al.**<br>**2011(123**<br>**)**|32|27|Média (min-<br>máx.): 24,7 anos<br>(19–29)|Média (min-<br>máx.): 24,4 (18–<br>29)|Média (DP): 23,35 (3,60)|Média (DP): 23,27 (3,63)|0|0|
|**Kriplani**|||||||||
|**et al.**<br>**2010**|30|30|Média (DP): Tod<br>(4,7)|a a coorte 22,5<br>anos|Comparáve|is (p>0,05)|1 descontinuação por<br>icterícia|1 descontinuação por<br>dor em membro inferior|
|**(124)**|||||||||
|**Battaglia**<br>**et al.**<br>**2010**<br>**(125)**|20|20|Média (DP): 23,4<br>(4,8) anos|Média (DP):<br>24,4 (4,1)|Média (DP): 25,1 (4,3)|Média (DP): 24,0 (4,2)|1 saiu do estudo devido<br>a dor de cabeça<br>persistente|2 saíram do estudo por<br>causa de<br>31/5000 de náusea e<br>sensibilidade dospeitos|  
N: número de pacientes; IMC: Índice de massa corporal. DP: desvio padrão; NR: não reportado; NA: não se aplica.  
**Tabela 16 – Desfechos de eficácia relacionados à Síndrome dos Ovários Policísticos e relacionados aos parâmetros clínicos.**  
|**Autor, ano**|**Desfechos relacionados à SOP**|**Desfechos relacionados aosparâmetros clínicos**|
|---|---|---|  
||**Intervenção:**<br>**Controle:**|**p para**<br>**comparação**|**Intervenção:**<br>**Controle:**|**p para**<br>**comparação**|
|---|---|---|---|---|
|**Li et al. 2017**<br>**(120)**<br>**Meta-análise**|**DM (IC 95%); I2; n estudos; n participantes:**<br>**Escore de Ferriman–Gallwey**<br>**DRSP vs. CA**|NR|**DM (IC 95%); I2; n estudos; n participantes:**<br>**IMC**<br>**DRSP vs. CA**||
|**de ECR**|0,55 (-0,10, 1,20); 0% (p: 0,98); 4 estudos; 283<br>participantes|0,1|0,02 (-0,30, 0,35); 0% (p: 0,94); 7 estudos; 419<br>participantes|0,89|
||**DRSP vs. DRSP + Metformina**<br>1,6 (-0,25, 3,45); 0% (NS); 1 estudo; 31 participantes|0,09|**DRSP vs. DRSP + Metformina**<br>0,79 (0,04, 1,55); 87% (p< 0.00001); 8 estudos; 383|0,04|
||**DRSP vs. Metformina**|0,39|participantes|0,03|
||0,8 (-1,01, 2,61); 0% (0,66); 1 estudo; 32 participantes<br>**DRSP vs. DSG**<br>0,04 (-1,11, 1,19); 0% (NS); 1 estudo; 115 participantes|0,95|**DRSP vs. Metformina**<br>0,67 (0,08, 1,26); 0% (0,66); 3 estudos; 133 participantes<br>**DRSP vs. DSG**<br>0 (-0,99, 0,99); 0% (NS); 1 estudo; 115 participantes|1|
||||**Relação cintura/quadril**<br>**DRSP vs. CA**<br>0 (-0,01, 0,01); 49% (p: 0,1); 5 estudos; 315 participantes<br>**DRSP vs. DRSP + Metformina**<br>-0,02 (-0,11, 0,07); 0% (NS); 1 estudo; 31 participantes<br>**DRSP vs. DSG**<br>0,01 (-0,01, 0,03); 0% (NS); 1 estudo; 115 participantes|0,57<br>0,68<br>0,33|
|**Amiri et al.**<br>**2017(121)**|NR||**Depois de a) 3 meses; b) 6 meses; c) 12 meses de tratamento**<br>**DM (IC 95%); I2; n estudos; n participantes:**||
|**Meta-análise**<br>**de estudos**|||**IMC**<br>**Efeito do EE 35 μg + CA 2 mg**<br>a) 2,30 (1,67, 2,93); 74,9% (p < 0,001); 9 estudos; 199<br>participantes||
|**observacionais**|||<br>b) −0,26 (−1,02, 0,51); 70,30% (p: 0,003); 7 estudos; 151<br>participantes;<br>c) −0,63(−1,60,0,34);0(NS);2 estudos;75participantes;||  
|**Autor, ano**|**Desfechos relacionados à SOP**||**Desfechos relacionados aosparâmetros clínicos**||
|---|---|---|---|---|
||**Intervenção:**<br>**Controle:**|**p para**<br>**comparação**|**Intervenção:**<br>**Controle:**|**p para**<br>**comparação**|
||||**Efeito do EE 30 μg + DRSP 3 mg**<br>a) NR<br>b) −0,39 (−0,68, −0,09); 0 (NS); 7 estudos; 228 participantes;<br>c) −1,76 (−3,54, 0,01); 75,9% (p:0,006); 4 estudos; 148<br>participantes;<br>**Efeito do EE 20μg + DRSP 150 μg**<br>a) NR<br>b) −0,19 (−1,61, 1,23); 0 (NS); 1 estudo; 58 participantes;<br>c) −0,45 (−1,87, 0,97); 0 (NS); 1 estudo; 58 participantes.|<br>b) <0,05|
||||**PAS**<br>**Efeito do EE 35 μg + CA 2 mg**<br>a) NR<br>b) 1,19 (−2,01, 4,40); 0 (NS); 3 estudos; 75 participantes;<br>c) 0,32 (−4,03, 4,67); 0 (NS); 1 estudo; 56 participantes;||
||||**Efeito do EE 30 μg + DRSP 3 mg**<br>a) NR<br>b) 0,98 (−2,33, 4,29); 41,7% (NS); 2 estudos; 116<br>participantes;<br>c) −0,66 (−3,97, 2,65); 32,1% (NS); 2 estudos; 116<br>participantes;<br>**Efeito do EE 20μg + DRSP 150 μg**<br>a) NR<br>b) 1,59 (−2,08, 5,26); 0 (NS); 1 estudo; 58 participantes;<br>c) 1,62 (−2,05, 5,29); 0 (NS); 1 estudo; 58 participantes.||
||||**PAD**<br>**Efeito do EE 35μg + CA 2 mg**||  
|**Autor, ano**|**Desfech**|**os relacionados à SOP**||**Desfechos relac**|**ionados aosparâmetros clínicos**||
|---|---|---|---|---|---|---|
||**Intervenção:**|**Controle:**|**p para**<br>**comparação**|**Intervenção:**|**Controle:**|**p para**<br>**comparação**|
|||||a) NR<br>b) 0,16 (−2,48, 2,80); 0 (NS<br>c) 2,04 (−1,66, 5,74); 0 (NS<br>**Efeito do EE 30**<br>a) NR<br>b) −1,93 (−9,34, 5,47); 93,7<br>participantes;<br>c) −2,10 (−11,48, 7,29); 94<br>participantes;<br>**Efeito do EE 20μ**<br>a) NR<br>b) 0,20 (−2,67, 3,07); 0 (NS<br>c) −0,07(−2,94,2,80);0(N|); 3 estudos; 75 participantes;<br>); 1 estudo; 56 participantes;<br>**μg + DRSP 3 mg**<br>% (NS); 2 estudos; 116<br>,9% (p<0,001); 2 estudos; 116<br>**g + DRSP 150 μg**<br>); 1 estudo; 58 participantes;<br>S);1 estudo;58participantes.||
|**Halperin et al.**<br>**2011(122)**|NR|NR|NR|NR|NR|NR|
|**Collona et al.**<br>**2011(123)**|**EE ⁄ DRSP**<br>**Média (DP), a) basal; b) aos 3**<br>**meses; c) aos 6 meses**|**EE ⁄ CMA**<br>**Média (DP), a) basal; b) aos**<br>**3 meses; c) aos 6 meses**||**EE ⁄ DRSP**<br>**Média (DP), a) basal; b) aos 3**<br>**meses; c) aos 6 meses**|**EE ⁄ CMA**<br>**Média (DP), a) basal; b) aos 3**<br>**meses; c) aos 6 meses**||
||**Escores de Acne Pillsbury**<br>a) 2,77 (0,53)|**Escores de Acne Pillsbury**<br>a) 2,70 (0,55)||**IMC**<br>a) 23,35 (3,60)|**IMC**<br>a) 23,27 (3,631)||
||b) 1,36 (0,59) (Em<br>relação ao basal<br>p<0,01)<br>c) 0,80 (0,58) (Em<br>relação ao basal<br>p<0,01)|b) 1,99 (0,70) (Em<br>relação ao basal<br>p<0,01)<br>c) 0,95 (0,60) (Em<br>relação ao basal<br>p<0,01)|b) <0,05|b) 23,78 (3,54)<br>c) 23,89 (3,61)<br>**Parâmetros cutâneos**<br>**Seborreia, mcg/cm**<sup>**2**</sup>**de pele**<br>a) 7094,83 ± 4871,91<br>b)3428,01 ± 1916,32(Em|b) 23,98 (3,54**)**<br>c) 23,51 (3,69)<br>**Parâmetros cutâneos**<br>**Seborreia, mcg/cm**<sup>**2**</sup>**de pele**<br>a) 6936,32 ± 2460,52<br>b)4229,65 ± 1927,55(Em|b) <0,05|  
|**Autor, ano**|**Desfech**|**os relacionados à SOP**||**Desfechos relaci**|**onados aosparâmetros clínicos**||
|---|---|---|---|---|---|---|
||**Intervenção:**|**Controle:**|**p para**<br>**comparação**|**Intervenção:**|**Controle:**|**p para**<br>**comparação**|
||**Escore de Ferriman–Gallwey**<br>a) 16,21 (2,71)<br>b) 15,18 (2,88)<br>c) 9,43 (2,02) (Em<br>relação ao basal|**Escore de Ferriman–Gallwey**<br>a) 16,09 (2,54)<br>b) 15,01 (2,54)<br>c) 11,24 (2,35) (Em<br>relação ao basal|b) <0,05|relação ao basal p<0,05)<br>c) 2412,26 ± 1692,03 (Em<br>relação ao basal p<0,05)<br>**Corneometria (hidratação da**|relação ao basal p<0,05)<br>c) 4076,69 ± 2497,66 (Em<br>relação ao basal p<0,05)<br>**Corneometria (hidratação da**|c) <0,05|
||p<0,01)|p<0,01)||**pele)**<br>a) 70,43 (21,30)|**pele)**<br>a) 70,49 (19,52)|c) <0,05|
|||||b) 81,24 (22,32)|b) 73,37 (20,26)||
|||||c) 87,24 (22,41) (Em relação ao<br>basal p<0,01)|c) 77,45 (22,27)||
|||||**Perda de água**<br>**transepidermial, g⁄ h ⁄m**<sup>**2**</sup>**de**|**Perda de água transepidermial,**||
|||||**pele**<br>a) 22,399 (10,31)<br>b) 15,796 (6,11) (Em relação ao<br>basal p<0,05)<br>c) 14,68 ± 6,06 (Em relação ao<br>basal p<0,05)|**g⁄ h ⁄m**<sup>**2**</sup>**de pele**<br>a) 21,353 (6,77)<br>b) 19,642 (5,72)<br>c) 16,746 (5,14) (Em relação ao<br>basal p<0,05)|b) <0,05|
|||||**Volume (relacionado ao**<br>**microrrelevo cutâneo)**<br>a) 75,65 (9,96)<br>b) 69,08 (9,66) (Em relação ao<br>basal p<0,01)<br>c) 66,62 (10,07) (Em relação ao<br>basal p<0,01)|**Volume (relacionado ao**<br>**microrrelevo cutâneo)**<br>a) 74,97 (6,69)<br>b) 71,02 (9,36)<br>c) 68,64 (9,48) (Em relação ao<br>basal p<0,01)||
|||||**Energia (relacionado com a**<br>**homogeneidade da pele)**<br>a) 38,1x10<sup>-3</sup>(18,5x10<sup>-3</sup>)|**Energia (relacionado com a**<br>**homogeneidade da pele)**<br>a) 40,.4x10<sup>-3</sup>(18,8x10<sup>-3</sup>)||  
|**Autor, ano**|**Desfech**|**os relacionados à SOP**||**Desfechos relac**|**ionados aosparâmetros clínicos**||
|---|---|---|---|---|---|---|
||**Intervenção:**|**Controle:**|**p para**<br>**comparação**|**Intervenção:**|**Controle:**|**p para**<br>**comparação**|
|||||b) 48,10<sup>-3</sup>(23,4x10<sup>-3</sup>)<br>c) 58,3x10<sup>-3</sup>(22,4x10<sup>-3</sup>)<br>(Em relação ao basal<br>p<0,01)<br>**Superfície (relacionado à**<br>**suavidade da pele)**<br>a) 6,503 (2,228)<br>b) 5,83 (2,0394)<br>c) 5,462 (2,1701) (Em<br>relação ao basal<br>p<0,05)|b) 44,3x10<sup>-3</sup>(21,1x10<sup>-3</sup>)<br>c) 53,5x10<sup>-3</sup>(21,9x10<sup>-3</sup>)<br>**Superfície (relacionado à**<br>**suavidade da pele)**<br>a) 6,369 (2,1305)<br>b) 6,06 (2,1196)<br>c) 5,667 (2,3459) (Em<br>relação ao basal<br>p<0,05)||
|**Kriplani et al.**<br>**2010(124)**<br>**ECR**|**EE/DRSP**<br>**Ciclos regulares:**<br>Basal: 2/30 (6,7)<br>Durante o tratamento: 30/30|**EE/DSG**<br>**Ciclos regulares:**<br>Basal: 1/30 (3,3)<br>Durante o tratamento: 30/30|Após 6 meses<br>de<br>interrupção<br>do|**EE/DRSP**<br>**Média ± DP a) basal; b) aos 3**<br>**meses; c) aos 6 meses**|**EE/DSG**<br>**Média ± DP a) basal; b) aos 3**<br>**meses; c) aos 6 meses**|NR|
||(100)<br>Após 6 meses do final do|(100)<br>Após 6 meses do final do|tratamento:<br>Ciclos|**IMC, kg/m2**<br>IMC>25 na linha de base: 19|**IMC, kg/m2)**<br>IMC>25 na linha de base: 20||
||tratamento: 13/29 (44,8)|tratamento: 5/29 (17,2)|regulares:|(63,3%)|(66,7%)||
||**Número de ciclos regulares**|**Número de ciclos regulares**|p<0,01|a) 27,6±5,4|a) 26,1±3,6||
||**em 6 meses (média ± DP):**|**em 6 meses (média ± DP):**||b) 27±5,3/ redução de 1,9%|b) 27,5±3,6/ crescimento de||
||Basal: 4±1,78<br>Após 6 meses do final do|Basal: 3±1,07<br>Após 6 meses do final do||(Em relação ao basal p=0,01)<br>c) redução de 1,7%|5,3% (Em relação ao basal<br>p=0,01)||
||tratamento: 5±1,29<br>(Em relação ao basal<br>p=0,0003)|tratamento: 3±1,26 (em<br>relação ao basal p=0,16)||**Peso corporal, kg a) basal; b)**<br>**aos 3 meses; c) aos 6 meses**|c) crescimento de 1,8%||
|||**Acne**||**(média ± DP):**|**Peso corporal, Kg a) basal; b)**||
||**Acne**|Apresentaram acne: 10/33|0,87|a): 68,3 (12,4);|**aos 3 meses; c) aos 6 meses**||
||Apresentaram acne: 10/33 ou|ou 33%||b) 65,82 (12,1)/ redução de|**(média, DP):**||
||33%|Pacientes com acne(n:10)||3,63%(Em relação ao basal|a)60,4(7,6);||  
|**Autor, ano**|**Desfech**|**os relacionados à SOP**||**Desfechos relac**|**ionados aosparâmetros clínicos**||
|---|---|---|---|---|---|---|
||**Intervenção:**|**Controle:**|**p para**<br>**comparação**|**Intervenção:**|**Controle:**|**p para**<br>**comparação**|
||Pacientes com acne (n:10)<br>que responderam ao<br>tratamento aos 6 meses: 5 ou<br>50%; 5 não responderam<br>Após 6 meses do final do<br>tratamento, nenhum outro<br>paciente desenvolveu acne<br>**Hirsutismo**<br>Presença: 26 (76,7%)<br>Escores >8 na pontuação de<br>Ferriman-Gallwey: 5<br>**Extensão de Crescimento de**<br>**pelos (média ± DP):**<br>Basal:12,6±4,5<br>Aos 6 meses de<br>tratamento:8±4,3 (36,5%) (Em<br>relação ao basal p=0,04)<br>Após 6 meses do final do<br>tratamento:  8,4±3,8<br>**Parâmetros de ultrassom**<br>**a) basal; b) 6 meses de**<br>**tratamento; c) 6 meses pós-**<br>**tratamento, média, ± DP:**<br>**Características basais de SOP**<br>**presentes**: 25 (83,3%)|que responderam ao<br>tratamento aos 6 meses: 3<br>ou 30%; 7 não responderam<br>Após 6 meses do final do<br>tratamento, um outro<br>paciente desenvolveu acne<br>**Hirsutismo**<br>Presença: 22 (73,3%)<br>Escores >8 na pontuação de<br>Ferriman-Gallwey: 4<br>**Extensão de Crescimento de**<br>**pelos (média ± DP):**<br>Não houve mudanças nos<br>escores do grupo controle,<br>média NR<br>**Parâmetros de ultrassom**<br>a) basal; b) 6 meses de<br>tratamento; c) 6 meses pós-<br>tratamento, média, ± DP:<br>**Características de SOP**<br>**presentes:**20 (66,7%)<br>Aos 6 meses de tratamento<br>reverteram oquadropara||p<0,01)<br>c) 66,9 (12,3)/ redução de 2%<br>(Em relação ao basal p=0,01)<br>**PAS/ PAD (média ± DP) a)**<br>**basal; b) aos 3 meses; c) aos 6**<br>**meses:**<br>a)  120,3±12,5; 76,1±5,5;<br>b)118,4±7,5, redução de 1,9<br>mmHg ou 1,6%; 75,7±5,3,<br>redução de 0,4 mmHg ou<br>0,5%(em relação ao basal p<<br>0,05)<br>c) PAS aumentou 1,39 mmHg<br>(1,1%) (Em relação ao basal p><br>0,05);<br>PAD aumentou 3,24<br>mmHg (4,2%) (Em relação ao<br>basal p= 0,05)|b) 62,4 (7,2) / ganho de 3,3%<br>(Em relação ao basal p<0,01)<br>c) 63,7 (7,3) / ganho de 5,3%<br>(Em relação ao basal p<0,01)<br>**PAS/ PAD (média ± DP):**<br>Basal: 114,7±9,4; 73,1±7,4<br>Aos 6 meses de<br>tratamento:116,4±7,8, aumento<br>de 1,7 mmHg ou 1,4%; 76,1±5,0,<br>aumento de 3 mmHg ou<br>4,2%(em relação ao basal p<<br>0,01)<br>c)  PAS aumentou 2,16 mmHg<br>(1,8%); PAD aumentou 3,1<br>mmHg (4,2%)||  
|**Autor, ano**|**Desfech**|**os relacionados à SOP**||**Desfechos r**|**elacionados aosparâmetros clínicos**||
|---|---|---|---|---|---|---|
||**Intervenção:**|**Controle:**|**p para**<br>**comparação**|**Intervenção:**|**Controle:**|**p para**<br>**comparação**|
||Aos 6 meses de tratamento<br>reverteram o quadro para<br>normal: 16 (64%)<br>**Número de folículos**<br>**ovarianos (média ± DP):**<br>a) 10,2±3,6<br>b) 6,6±3,3/ redução de 35,1%<br>(em relação a basal p<0,01);<br>c) redução de 29,2%<br>**Volume ovariano (média ±**<br>**DP):**<br>Redução da linha de base e 3<br>meses: 10,3% (em relação a<br>basal p<0,01);<br>Redução da linha de base e 6|normal: 11 (55%)<br>**Número de folículos**<br>**ovarianos** **(média ± DP):**<br>a) 8,8±2,1<br>b) 8 ±1,8/ redução de 8,3%;<br>c) redução de 6,2%<br>**Volume ovariano (média ±**<br>**DP):**<br>Redução da linha de base e 3<br>meses: 11,8% (em relação a<br>basal p<0,01);<br>Redução da linha de base e 6<br>meses: 5,3%|||||
||meses: 7%|**Espessura endometrial**<br>b) máxima redução: 7,1 %|||||
||**Espessura endometrial**||||||
||b) máxima redução: 13,8%|**Outros**|||||
||**Outros**<br>Oligomenorreia basal: 20/30<br>(66,6)|Oligomenorreia basal: 20/30<br>(66,6)<br>Amenorreia basal: 9/30 (30)|||||
||Amenorreia basal: 8/30(26,7)||||||
|**Battaglia et al.**|**DRSP/ EE**|**EE+ etonogestrel (anel**||**DRSP/ EE**|**EE+ etonogestrel (anel vaginal)**||  
|**Autor, ano**|**Desfech**|**os relacionados à SOP**||**Desfechos relaci**|**onados aosparâmetros clínicos**||
|---|---|---|---|---|---|---|
||**Intervenção:**|**Controle:**|**p para**<br>**comparação**|**Intervenção:**|**Controle:**|**p para**<br>**comparação**|
|**2010(125)**||**vaginal)**|||||
|**ECR**|**Média (DP)**|**Média (DP)**||**Média (DP):**|**Média (DP):**||
||**Escore de Ferriman–Gallwey**|||**IMC**|**IMC**||
||Basal: 12,2 (4,60)<br>Aos 6 meses: 8,7 (3,1)<br>(Em relação ao basal p<0,001)|**Escore de Ferriman–Gallwey**<br>Basal: 13,3 (3,6)<br>Aos 6 meses: 9,0 (3,0)||Basal: 25,1 (4,3)<br>Aos 6 meses: 24,6 (6,6)|Basal: 24,0 (4,2)<br>Aos 6 meses: 23,7 (4,2)||
||**Volume ovariano, ml**<br>Basal: 10,5 (2,7)<br>Aos 6 meses: 5,1 (2,1)|(Em relação ao basal<br>p<0,001)<br>**Volume ovariano, ml**||**Relação cintura/quadril**<br>Basal: 0,80 (0,08)<br>Aos 6 meses: 0,78 (0,04)|**Relação cintura/quadril**<br>Basal: 0,78 (0,08)<br>Aos 6 meses: 0,77 (0,06)||
||(Em relação ao basal p<0,001)|Basal: 10,6 (3,4)<br>Aos 6 meses: 5,8 (1,8)||**PAS 24h**<br>Basal: 111 (5)|**PAS 24h**<br>Basal: 110 (5)||
||**Foliculares subcapsular, n**<br>Basal: 12,9 (2,0)<br>Aos 6 meses: 9,3 (3,1)|(Em relação ao basal<br>p<0,001)||Aos 6 meses: 116 (6)<br>(Em relação ao basal p: 0,001)|Aos 6 meses: 116 (7)<br>(Em relação ao basal p: 0,005)||
||(Em relação ao basal p: 0,001)<br>**Artéria Uterina, PI**|**Foliculares subcapsular, n**<br>Basal: 12,6 (1,8)<br>Aos 6 meses: 9,0 (1,4)||**PAD 24h**<br>Basal: 69 (4)<br>Aos 6 meses: 72 (6)|**PAD 24h**<br>Basal: 66 (5)<br>Aos 6 meses: 69 (9)||
||Basal: 2,70 (0,97)<br>Aos 6 meses: 2,25 (0,77)<br>(Em relação ao basal p: 0,024)|(Em relação ao basal p:<br>0,001)<br>**Artéria Uterina, PI**<br>Basal: 2,80 (0,77)<br>Aos 6 meses: 2,31 (0,79)<br>(Em relação ao basal p:<br>0,016)|||||  
SOP: síndrome dos ovários policísticos; EE: etinilestradiol; CA: acetato de ciproterona; CMA: acetato de cloradinona; DRSP: drospirenona; DSG: desogestrel; ECR: ensaio clínico randomizado; IMC: índice de massa corporal; PAS: pressão arterial sistólica; PAD: pressão arterial diastólica; DP: desvio padrão; NR: não reportado; p para comparação: p intervenção versus controle.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Tabela 17 – Desfechos de eficácia relacionados aos parâmetros bioquímicos e ao perfil hormonal.** -->
||**Desfechos relacionados aos parâmetros bioquímicos**||**Desfechos relacionados ao perfil hormonal**||
|---|---|---|---|---|
|**Autor,**||**p**|||
|**ano**|**Intervenção:**<br>**Controle:**|**comparaçã**<br>**o**|**Intervenção:**<br>**Controle:**|**p**<br>**comparação**|
||**DM (IC 95%); I2; n estudos; n participantes:**||**DM (IC 95%); I2; n estudos; n participantes:**||
||**Colesterol total**<br>**DRSP vs. CA**||**Testosterona livre total**<br>**DRSP vs. CA**||
||-0,4 (-0,75, -0,05); 0% (p: 0,54); 3 estudos; 133<br>participantes|0,02|0,01 (-0 16, 0 19); 19% (p: 0 28); 8 estudos; 499<br>participantes|0,88|
||**DRSP vs. DRSP + Metformina**|0,55|**DRSP vs. DRSP + Metformina**|0,09|
||-3,54 (-15,26, 8,18); 3% (p:0,36); 3 estudos; 118||0 3 (-0 05, 0,65); 66% (p:0,003); 9 estudos; 399||
||participantes<br>**DRSP vs. Metformina**|< 0,00001|participantes<br>**DRSP vs. Metformina**|0,003|
|**Li et al.**<br>|43,1 (26,37, 59,83); 0% (NS); 1 estudo; 44 participantes<br>**DRSP vs. DSG**|0,68|-0,4 (-1,23, -0,24); 59% (p:0.06); 4 estudos; 177 participantes<br>**DRSP vs. DSG**|0,11|
|**2017(120)**|2,4 (-9,12, 13,92); 0% (NS); 1 estudo; 58 participantes||- 0,57 (-1,28, 0,13); 82% (p:0,01); 3 estudos; 193 participantes||
|**Meta-**<br>**análise de**<br>|**Triglicerídeos**<br>**DRSP vs. CA**|0,88|**FSH**<br>**DRSP vs. CA**|0,04|
|**ECR**|1,22 (-14,88, 17,32); 0% (NS); 1 estudo; 32 participantes<br>**DRSP vs. DRSP + Metformina**|0,53|-0,29 (-0,56, -0,20); 25% (p: 0,26); 4 estudos; 215<br>participantes|0,82|
||2,79 (-5,85, 11,42); 0% (p:0,88); 6 estudos; 213|0,002|**DRSP vs. DRSP + Metformina**|0,001|
||participantes||0,07 (-0,53, 0,66); 85% (p<0,001); 5 estudos; 311||
||**DRSP vs. Metformina**|0,94|participantes|1|
||37,61 (13,84, 61,37); 54% (p:0,14); 2 estudos; 76 participantes<br>**DRSP vs. DSG**<br>-0,6 (-16,05, 14,85); 0% (NS); 1 estudo; 58 participantes||**DRSP vs. Metformina**<br>- 3,5 (-5,64, -1,36); 0% (NS); 1 estudo; 30 participantes<br>**DRSP vs. DSG**||
||**LDL**|0,84|0 (-1,14, 1,14); 0% (NS); 1 estudo; 58 participantes|0,72|
||**DRSP vs. CA**|0,009|**LH**|0,01|
||-0,08(-0,85,0,69);78%(p: 0,01);3 estudos;133||**DRSP vs. CA**||  
||**Desfechos relacionados aos parâmetros bioquímicos**||**Desfechos relacionados ao perfil hormonal**||
|---|---|---|---|---|
|**Autor,**||**p**|||
|**ano**|**Intervenção:**<br>**Controle:**|**comparaçã**<br>**o**|**Intervenção:**<br>**Controle:**|**p**<br>**comparação**|
||participantes<br>**DRSP vs. DRSP + Metformina**|< 0,00001|- 0,04 (-0,28, 0,20); 48% (p: 0,1); 5 estudos; 277<br>participantes|0,07|
||7,94 (1,95, 13,93); 35% (p:0,18); 6 estudos; 213<br>participantes|0,0008|**DRSP vs. DRSP + Metformina**<br>2,6 (0,56, 4,64); 98% (p<0,00001); 5 estudos; 311|0,0004|
||**DRSP vs. Metformina**||participantes||
||23,08 (14,61, 31,55); 0% (p:0,99); 2 estudos; 76 participantes<br>**DRSP vs. DSG**|0,54|**DRSP vs. Metformina**<br>- 7,41 (-15,46, 0,64); 0% (NS); 1 estudo; 30 participantes|0,87|
||- 13,3 (-23,1, -3,5); 0% (NS); 1 estudo; 58 participantes||**DRSP vs. DSG**||
|||0,28|-0,3 (-4,67, 1,33); 0% (NS); 1 estudo; 58 participantes|0,86|
||**HDL**||||
||**DRSP vs. CA**|0,57|**SHBG**|11,93|
||0,11 (-0,24, 0,45); 0% (p: 0,6); 3 estudos; 133||**DRSP vs. CA**||
||participantes<br>**DRSP vs. DRSP + Metformina**|0,04|0,02 (-0,23, 0,27); 1% (p: 0,39); 4 estudos; 252<br>participantes|0,13|
||-5,65 (-15,85, 4,55); 82% (p< 0,0001); 6 estudos; 213 participantes||**DRSP vs. DRSP + Metformina**||
||**DRSP vs. Metformina**||-0,04 (-0,52, 0,43); 56% (p:0,06); 5 estudos; 163||
||- 10,51 (-46,97, 25,94); 98% (p < 0,00001); 2 estudos; 76|0,63|participantes|0,73|
||participantes||**DRSP vs. Metformina**||
||**DRSP vs. DSG**|0,26|3,23 (2,70, 3,76); 0% (p<0,00001); 3 estudos; 133 participantes|0,69|
||3,3 (0,2, 6,4); 0% (NS); 1 estudo; 58 participantes||**DRSP vs. DSG**||
|||0,67|28,51 (-0,8, 65,02); 90% (p<0,00001); 3 estudos; 193 participantes|0,0002|
||**Glicose de Jejum**||||
||**DRSP vs. CA**||**FAI**|0,45|
||-0,07 (-0,33, 0,20); 0% (p: 0,52); 3 estudos; 214||**DRSP vs. CA**||
||participantes<br>**DRSP vs. DRSP + Metformina**||0,22 (-1,03, 1,48); 0% (p: 0,91); 3 estudos; 178<br>participantes||
||3,3 (-2,42, 9,02); 0% (NS); 1 estudo; 31 participantes||**DRSP vs. DRSP + Metformina**|0,58|
||**DRSP vs. DSG**||-0,22 (-1,31, 0,87); 0% (p: 0,6); 3 estudos; 118 participantes||
||-1,38 (-7,77, 5,01); 87% (p:0,006); 2 estudos; 173 participantes||**DRSP vs. Metformina**<br>- 5,48(-8,38,-2,58);70%(p:0,07);2 estudos;64participantes|0,81|  
||**Desfechos relacionad**|**os aos parâmetros bioquímicos**|**Desfechos relacionados ao perfil hormonal**||
|---|---|---|---|---|
|**Autor,**||**p**|||
|**ano**|**Intervenção:**|**Controle:**<br>**comparaçã**<br>**o**|**Intervenção:**<br>**Controle:**|**p**<br>**comparação**|
||||**DRSP vs. DSG**<br>-0,9 (-3,25, 1,45); 0% (NS); 2 estudos; 173 participantes<br>**DHEAS**<br>**DRSP vs. CA**<br>210 (-541,41,  961,41); 0% (NS); 1 estudo; 30 participantes<br>**DRSP vs. DRSP + Metformina**<br>0,05 (-0,33, 0,42); 0% (p: 0,43); 3 estudos; 110|0,05<br>0,34<br>0,15|
||||participantes<br>**DRSP vs. Metformina**|0,5|
||||- 766 (-1539,73,  7,73); 0% (NS); 1 estudo; 30 participantes<br>**DRSP vs. DSG**<br>-0,26 (-0,79,  0,27); 0% (NS); 1 estudo; 20 participantes|0,56|
||||**Insulina em jejum**<br>**DRSP vs. CA**|0,04|
||||-0,2 (-0,47, 0,07); 47% (p:0,15); 3 estudos; 214<br>participantes<br>**DRSP vs. DRSP + Metformina**<br>-0,98 (-3,84, 1,88); 0% (NS); 1 estudo; 31 participantes<br>**DRSP vs. DSG**<br>-1,61 (-6,96,  3,75); 75% (p:0,04); 2 estudos; 173 participantes|0,12<br>0,06<br>0,61|
||||**HOMA-IR**<br>**DRSP vs. CA**<br>-0,7 (-1,38,  -0,02); 68% (p:0,02); 5 estudos;<br>283participantes<br>**DRSP vs. DRSP + Metformina**<br>0,66 (-1,07, 1,49); 83% (p: 0,03); 3 estudos; 122<br>participantes||  
||**Desfechos relacionad**|**os aos parâmetros bioquím**|**icos**|**Desfechos relacionados ao perfil hormonal**||
|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção:**|**Controle:**|**p**<br>**comparaçã**<br>**o**|**Intervenção:**<br>**Controle:**|**p**<br>**comparação**|
|||||**DRSP vs. Metformina**||
|||||1,23 (-0,03, 2,49); 0% (NS); 1 estudo; 30 participantes<br>**DRSP vs. DSG**||
|||||-0,3 (-1,45,  0,85); 73% (p:0,05); 2 estudos; 173 participantes||  
||**Depois de a) 3 meses; b) 6 meses; c) 12 meses de tratamento**||**Depois de a) 3 meses; b) 6 meses; c) 12 meses de tratamento**||
|---|---|---|---|---|
||**DM (IC 95%); I2; n estudos; n participantes:**<br>**Glicose de jejum**<br>**Efeito do EE 35 μg + CA 2 mg**||**DM (IC 95%); I2; n estudos; n participantes:**<br>**Insulina em jejum**<br>**Efeito do EE 35 μg + CA 2 mg**|c) <0,05|
||a) −0,03 (−3,55, 3,48); 74,5% (p: 0,005); 4 estudos; 108||a) −0,84 (−2,00, 0,32); 37,5% (NS); 7 estudos; 158||
|**Amiri et**|participantes||participantes||
|**al.**|b) −2,00 (−2,76, −1,25); 0 (NS); 7 estudos; 151 participantes;|b) <0,05|b) 0,79 (−0,50, 2,08); 7,7% (NS); 6 estudos; 125 participantes;||
|**2017(121)**|c) 1,74 (−5,63, 8,37); 89,5% (p:0,002); 2 estudos; 74<br>participantes;||c) 3,00 (−3,19, 9,19); 90,90% (p:0,001); 2 estudos; 74<br>participantes;|c) <0,05|
|**Meta-**|**Efeito do EE 30 μg + DRSP 3 mg**||**Efeito do EE 30 μg + DRSP 3 mg**||
|**análise de**|a) 4,99 (−2,03, 12,01); 0 (NS); 1 estudo; 20 participantes;||a) 0,52 (−1,83, 2,87); 0 (NS); 1 estudo; 20 participantes;||
|**estudos**|b) −2,79 (−5,67, 0,10); 70,40% (p:0,002); 7 estudos; 199||b) 0,56 (−1,79, 2,91); 70,50 % (p:0,009); 5 estudos; 162||
|**observaci**|participantes;||participantes;||
|**onais**|c) 0,44 (−4,45, 5,33); 72,4% (p:0,06); 2 estudos; 69<br>participantes;||c) 3,45 (0,25, 6,64); 0 (NS); 2 estudos; 69 participantes;<br>**Efeito do EE 20μg + DRSP 150 μg**||
||**Efeito do EE 20μg + DRSP 150 μg**||a) NR||
||a) NR||b) 0,80 (−1,42, 3,02); 50,60% (NS); 2 estudos; 88||
||b) −1,04 (−2,99, 0,91); 50,60% (NS); 2 estudos; 88||participantes;||
||participantes;<br>c) 1,23 (−9,46, 11,92); 98,10% (p<0,001); 2 estudos; 76<br>participantes.||c) 2,32 (1,14, 3,49); 3,10% (NS); 2 estudos; 76 participantes.<br>**HOMA-IR**||  
||**Desfechos relacionados aos parâmetros bioquímicos**||**Desfechos relacionados ao perfil hormonal**||
|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção:**<br>**Controle:**|**p**<br>**comparaçã**<br>**o**|**Intervenção:**<br>**Controle:**|**p**<br>**comparação**|
||||**Efeito do EE 35 μg + CA 2 mg**||
||**Colesterol Total**<br>**Efeito do EE 35 μg + CA 2 mg**||a) −0,37 (−0,86, 0,12); 42,3% (NS); 4 estudos; 119<br>participantes||
||a) 11,74 (−0,38, 23,87); 93,60% (p<0,001); 8 estudos; 194||b) 0,07 (−0,39, 0,52); 0 (NS); 5 estudos; 116 participantes;||
||participantes;|c) <0,05|c) 0,70 (−0,30, 1,70); 94,1% (p<0,001); 2 estudos; 74||
||b) 5,06 (−11,38, 21,50); 74,90% (p:0,007); 4 estudos; 70<br>participantes;||participantes;<br>**Efeito do EE 30 μg + DRSP 3 mg**||
||c) 42,20 (17,01, 67,38); 74,5% (p:0,005); 2 estudos; 33||a) 0,27 (−0,32, 0,89); 0 (NS); 1 estudo; 20 participantes;||
||participantes;|b) <0,05|b) −0,06 (−0,53, 0,40); 88,10 % (p<0,001); 7 estudos; 241||
||**Efeito do EE 30 μg + DRSP 3 mg**||participantes;||
||a) 10,60 (−9,49, 30,69); 0 (NS); 1 estudo; 20 participantes;<br>b) 15,98 (0,24, 31,72); 87,9% (p<0,001); 5 estudos; 166|c) <0,05|c) 0,30 (−0,64, 1,25); 77,40% (p:0,01); 3 estudos; 128<br>participantes;||
||participantes;||**Efeito do EE 20μg + DRSP 150 μg**||
||c) 16,57 (9,87, 23,28); 0% (NS); 3 estudos; 91 participantes;|b) <0,05|a) NR||
||**Efeito do EE 20μg + DRSP 150 μg**|c) <0,05|b) 0,08 (−0,39, 0,52); 0% (NS); 2 estudos; 88 participantes;||
||a) 28,83 (26,83, 31,53); 0% (NS); 1 estudo; 14 participantes;||c) 0,39 (−0,67, 1,46); 75,10% (0,04); 2 estudos; 76||
||b) 11,20 (0,48, 21,92); 0% (NS); 1 estudo; 30 participantes;||participantes.||  
- c) 34,58 (30,64, 38,52); 0% (NS); 1 estudo; 14 participantes;  
- **Triglicerídeos**  
- **Efeito do EE 35 μg + CA 2 mg** b) <0,05  
- a) 14,13 (−9,55, 37,81); 93,70% (p<0,001); 6 estudos; 169 c) <0,05 participantes;  
- b) 14,83 (2,75, 26,91); 37,10% (NS); 4 estudos; 70 participantes;  
- c) 45,00 (16,91, 73,09); 89,5% (p:0,002); 1 estudos; 19 participantes;  
- **Efeito do EE 30 μg + DRSP 3 mg**  
- a) 9,50 (−15,10, 34,10); 0 (NS); 1 estudo; 20 participantes; b) 18,22 (6,30, 30,13); 68,70 (p:0,01); 5 estudos; 166  
- b) <0,05  
- c) <0,05  
||**Desfechos relacionados aos parâmetros bioquímicos**||**Desfechos relacionados ao perfil hormonal**||
|---|---|---|---|---|
|**Autor,**||**p**|||
|**ano**|**Intervenção:**<br>**Controle:**|**comparaçã**<br>**o**|**Intervenção:**<br>**Controle:**|**p**<br>**comparação**|
||participantes;<br>c) 30,58 (4,61, 56,56); 72,0% (p:0,03); 3 estudos; 91<br>participantes;<br>**Efeito do EE 20μg + DRSP 150 μg**<br>a) NR<br>b) 13,10 (−0,14, 26,34); 0% (NS); 1 estudo; 30 participantes;<br>c) NR||||
||**LDL**<br>**Efeito do EE 35 μg + CA 2 mg**<br>a) 4,60 (−5,30, 14,50); 89,40% (p<0,001); 7 estudos; 183<br>participantes;<br>b) 5,48 (−14,45, 25,41); 97,40% (p<0,001); 5 estudos; 84<br>participantes;<br>c) 15,08 (12,74, 17,43); 0% (NS); 2 estudos; 33<br>participantes;<br>**Efeito do EE 30 μg + DRSP 3 mg**<br>a) −7,00 (−27,85, 13,85); 0 (NS); 1 estudo; 20 participantes;<br>b) 5,91 (−6,65, 18,48); 87,7% (p<0,001); 5 estudos; 166<br>participantes;<br>c) 11,59 (5,06, 18,12); 0% (NS); 3 estudos; 91 participantes;<br>**Efeito do EE 20μg + DRSP 150 μg**<br>a) 23,22 (19,22, 27,22); 0% (NS); 1 estudo; 14 participantes;<br>b) 14,68 (−1,25, 30,61); 92,9% (p<0,001); 2 estudos; 44<br>participantes;<br>c) 15,05 (11,27, 18,83); 0% (NS); 1 estudo; 14 participantes<br>**HDL**<br>**Efeito do EE 35 μg + CA 2 mg**<br>a) 5,23(−0,62,11,08);92%(p<0,001);7 estudos;183|c) <0,05<br>c) <0,05<br>a) <0,05<br>c) <0,05<br>b) <0,05<br>c) <0,05<br>a) <0,05<br>b) <0,05<br>c) <0,05<br>a)<0,05|||  
||**Desfechos relacionados aos parâmetros bioquímicos**||**Desfechos relacionados ao perfil hormonal**||
|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção:**<br>**Controle:**|**p**<br>**comparaçã**<br>**o**|**Intervenção:**<br>**Controle:**|**p**<br>**comparação**|
||participantes;<br>b) 7,74 (2,99, 12,49); 89,9% (p<0,001); 5 estudos; 84<br>participantes;<br>c) 10,00 (8,41, 11,59); 0% (NS); 2 estudos; 33 participantes;<br>**Efeito do EE 30 μg + DRSP 3 mg**<br>a)13,68 (5,16, 22,20); 0 (NS); 1 estudo; 20 participantes;<br>b)8,82 (2,87, 14,78); 73,2% (p: 0,01); 4 estudos; 136<br>participantes;<br>c)7,15 (2,41, 11,89); 55,2% (p:0,11); 3 estudos; 91<br>participantes;<br>**Efeito do EE 20μg + DRSP 150 μg**<br>a) 4,65 (3,26, 6,04); 0% (NS); 1 estudo; 14 participantes;<br>b) 6,90 (5,56, 8,24); 0% (NS); 1 estudo; 14 participantes;<br>c) 6,32 (5,01, 7,63); 0% (NS); 1 estudo; 14 participantes|b) <0,05<br>c) <0,05|||
||**DM (IC 95%); I2; n estudos; n participantes**||||
|**Halperin**<br>**et al.**<br>**2011(122)**<br>**Meta-**<br>**análise de**<br>**estudos**<br>**observaci**<br>**onais**|**Glicose de jejum**<br>-0,03 (-0,18, 0,12); 96,7% (p <0,001); 29 coortes; 584 participantes<br>**Colesterol total**<br>0,38 (-0,44, 1,20); 99,7% (p <0,001); 29 coortes; 628 participantes<br>**HDL**<br>0,46 (0,14, 0,78); 99,4% (p <0,001);27 coortes; 601 participantes<br>Idade, média de IMC e dose de estrogênio explica 58% da<br>variabilidade da associação entre CO e aumento de HDL|0,69<br>0,36<br>0,004|**DM (IC 95%); I2; n estudos; n participantes**<br>**Insulina de jejum**<br>0,95 (-0,08, 1,97); NS; 33 coortes; 570 participantes<br>**Relação entre glicemia de jejum e insulina**<br>-0,20 (-0,67, 0,27); 99,99% (p <0,001); 8 coortes; 172 participantes<br>**HOMA-IR**<br>0,23 (20,36, 0,83); 92% (p <0,001); 11 coortes; 265 participantes|0,07<br>0,41|
||**LDL**<br>0,26(-0,08,0,60);99%(p<0,001);22 coortes;548participantes|0,14||0,45|  
||**Desfechos relacionados aos parâmetros bioquímicos**||**Desfechos rel**|**acionados ao perfil hormon**|**al**|
|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção:**<br>**Controle:**|**p**<br>**comparaçã**<br>**o**|**Intervenção:**|**Controle:**|**p**<br>**comparação**|
||**Triglicerídeos**|||||
||0,55 (0,17, 0,93); 99,6% (p <0,001); 25 coortes; 541 participantes|0,004*||||  
||||**EE ⁄ DRSP**|**EE/CMA**||
|---|---|---|---|---|---|
||||**Média (DP), a) basal; b) aos 3**<br>**meses; c) aos 6 meses:**|**Média (DP), a) basal; b) aos 3**<br>**meses; c) aos 6 meses:**||
||||**Androstenediona**,**ng ⁄ mL**<br>a) 4,42 (0,72)|**Androstenediona**,**ng ⁄ mL**<br>a) 4,35 (0,57)||
||||b) 2,64 (0,74) (em<br>relação a basal|b) 3,02 (0,62) (em relação a<br>basal p<0,01);|b) <0,05|
||**EE ⁄ DRSP**|**EE/CMA**|p<0,01);<br>c) 1,98 (0,72) (em|c) 2,72 (0,64) (em relação a<br>basal p<0,01);|c) <0,05|
|**Collona et**<br>**al.**<br>**2011123**|**Média (DP), a) basal; b) aos 3**<br>**meses; c) aos 6 meses:**|**Média (DP), a) basal; b) aos 3**<br>**meses; c) aos 6 meses:**|relação a basal<br>p<0,01);|**DHEA, mcg/ml**<br>a) 3,473 (1,03)||
|**()**|||**DHEA, mcg/ml**|b) 3,100 (1,23)||
||||a) 3,414 (1,05)|c) 2,726 (1,15) (em relação||
||||b) 3,052 (1,19)|a basal p<0,01);||
||||c) 2,648 (1,14) (em|||
||||relação a basal<br>p<0,01);|**Testosterona, nmol/l**<br>a) 2,13 (0,32)<br>b) 1,69 (0,33) (em relação a||
||||**Testosterona, nmol/l**|basal p<0,01);|b) <0,05|
||||a) 2,08 (0,31)|c) 1,28 (0,37) (em relação a||
||||b) 1,51 (0,35) (em<br>relação a basal|basal p<0,01);|c) <0,05|
||||p<0,01);|**SHBG, nmol/l**||  
||**Desfechos relaciona**|**dos aos parâmetros bioquímicos**||**Desfechos re**|**lacionados ao perfil hormonal**||
|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção:**|**Controle:**|**p**<br>**comparaçã**<br>**o**|**Intervenção:**|**Controle:**|**p**<br>**comparação**|
|||||c) 0,99 (0,37) (em<br>relação a basal<br>p<0,01);<br>**SHBG, nmol/l**<br>a) 39,80 ± 11,08<br>b) 214,17 ± 19,92 (em<br>relação a basal<br>p<0,01);<br>c) 183,73 ± 21,88 (em<br>relação a basal<br>p<0,01);|a) 40,25 ± 11,41;<br>b) 202,83 ± 20,89; (em<br>relação a basal p<0,01);<br>c) 184,98 ± 18,04 (em<br>relação a basal p<0,01);<br>**FAI**<br>a) 6,41 ± 1,65<br>b) 1,23 ± 0,56 (em relação a<br>basal p<0,01);<br>c) 1,08 ± 0,58 (em relação a<br>basal p<0,01);|b) <0,05|
|||||**FAI**<br>a) 6,29 ± 1,52<br>b) 1,09 ± 0,55 (em<br>relação a basal<br>p<0,01);<br>**c) **0,92 ± 0,59 (em<br>relação a basal<br>p<0,01);|||
||**EE/DRSP**|**EE/DSG**||**EE/DRSP**|**EE/DSG**||
|**Kriplani**<br>**et al.**<br>**2010(124)**<br>**ECR**|**Média ± DP (min-máx.), a)**<br>**basal; b) 6 meses de**<br>**tratamento; c) 3 meses pós-**<br>**tratamento:**<br>**Colesterol**|**Média ± DP (min-máx.), a)**<br>**basal; b) 6 meses de**<br>**tratamento; c) 3 meses pós-**<br>**tratamento:**<br>**Colesterol**|a)0,09|**a) basal; b) 6 meses de**<br>**tratamento; média, ± DP (min-**<br>**máx.):**<br>**Relação LH/FSH:**<br>a)1,3±1,4(0,3–6,4)|**a) basal; b) 6 meses de**<br>**tratamento; média, ± DP (min-**<br>**máx.):**<br>**Relação LH/FSH:**|0,06|  
||**Desfechos relacionad**|**os aos parâmetros bioquímicos**||**Desfechos r**|**elacionados ao perfil hormonal**||
|---|---|---|---|---|---|---|
|**Autor,**|||**p**||||
|**ano**|**Intervenção:**|**Controle:**|**comparaçã**<br>**o**|**Intervenção:**|**Controle:**|**p**<br>**comparação**|
||a**)**160,3±20,1 (126–194);|a) 150,9±23,0 (101–193)|b) 0,04|b) 0,9±0,7 (0,1–4,1) / redução|a) 1,3±0,4 (0,6–2,1)||
||b) 173,9±19,9 (139–219,6)/<br>aumentou 8,5% (em relação a<br>basal p<0,05);<br>c) 172,4±18,9 (140–208)/<br>aumentou 6,7 % (em relação a<br>basal p<0,05);|b) 162,1±25,8 (98–219) /<br>aumentou 8,5% (em relação a<br>basal p<0,05);<br>c)160,3±18,9 (102–199)<br>/aumentou 6,2% (em relação a<br>basal p<0,05);|c) 0,02<br>a) 0,054|de 34,8%<br>**Testosterona total**<br>a) 0,6±0,3(0,1–1,4);<br>b) 0,5±0,2(0,1–0,9) / redução<br>de 21,3% (em relação a basal|b) 1,1±0,2 (0,3–1,5) / redução de<br>18,7%<br>**Testosterona total**<br>a) 0,6±0,2 (0,1–0,9);<br>b) 0,6±0,2 (0,3–0,9) / aumentou|0,049|
||||b) 0,07|p<0,05)|3,2%||
||**Triglicerídeos**|**Triglicerídeos**|c) 0,07|||0,5|
||a) 105,6±28,8 (54–167);|a) 90,8±31,0 (48–199);||**SHBG**|||
||b)118,1±30,7 (67–190)/<br>aumentou 11,9% (em relação a<br>basal p<0,05);<br>c) 116,9±26,9 (76–184)/<br>aumentou 10,7% (em relação a<br>basal p<0,05);|b)103,9±29,4 (66–186) /<br>aumentou 14,4% (em relação a<br>basal p<0,05);<br>c) 103,7±27,7 (63–183) /<br>aumentou 14,2% (em relação a<br>basal p<0,05);|a) 0,69<br>b) 0,008<br>c) 0,22|a) 20±12,0 (12–62)<br>b) 62,3±50,3 (13,1–221) /<br>aumentou 211%|**SHBG**<br>a) 22,5±17,2 (7,6–7)<br>b) 60±41,0 (20–199) / aumentou<br>166%||
||**LDL**<br>a) 96,7±22,5 (61–147);<br>b) 89,6±17,8 (62–133,8)/ reduziu<br>7,3% (em relação a basal<br>p<0,05);<br>c)96,3±17,1 (70–129)/ reduziu<br>0,3%;|**LDL**<br>a) 94,6±17,9 (52–124);<br>b) 100,8±16,8 (58–128) /<br>aumentou 6,5% (em relação a<br>basal p<0,05);<br>c) 100,6±13,2 (70–120) /<br>aumentou 6,3%(em relação a<br>basal p<0,05)|a) 0,05<br>b) <0,01<br>c) <0,01||||
||**HDL**<br>a) 44,7±7,1 (29,7–59);<br>b) 50,3±7,3 (40–67,1) /<br>aumentou 12,3%(em relação a|**HDL**<br>a) 41,7±4,7 (33–53);<br>b) 44±4,4 (40–56) / aumentou<br>5,4%(em relação a basal|||||  
||**Desfechos relaciona**|**dos aos parâmetros bioquímicos**||**Desfechos re**|**lacionados ao perfil hormonal**||
|---|---|---|---|---|---|---|
|**Autor,**|||**p**||||
|**ano**|**Intervenção:**|**Controle:**|**comparaçã**<br>**o**|**Intervenção:**|**Controle:**|**p**<br>**comparação**|
||basal p<0,05);<br>c) 48,6±6,2 (31–60) / aumentou<br>8,7% (em relação a basal<br>p<0,05);|p<0,05);<br>c) 443,4±3,3 (40–51) /<br>aumentou 3,9%;|||||
||**DRSP/ EE**|**EE+ etonogestrel (anel**<br>**vaginal)**||**DRSP/ EE**|**EE+ etonogestrel (anel vaginal)**||
||**Média (DP):**|**Média (DP):**||**Média (DP):**|**Média (DP):**||
||**Glicose de jejum**<br>Basal: 4,2 (0,3)|**Glicose de jejum**||**Insulina em jejum, pmol/L**<br>Basal: 81 (31|**Insulina em jejum, pmol/L**<br>Basal: 78 (29)||
||Aos 6 meses: 4,5 (0,2)|Basal: 4,4 (0,4)<br>Aos 6 meses: 4,6 (0,2)||Aos 6 meses: 87 (16)|Aos 6 meses: 85 (11)||
|**Battaglia**|**Glicose AUC120, Mmol/L**<br>Basal: 773 (174)|**Glicose AUC120,Mmol/L**||**Insulina AUC120,pmol/L**<br>Basal: 58261 (48205)|**Insulina AUC120,pmol/L**<br>Basal: 59429 (50740)||
|**et al.**<br>**2010(125)**|Aos 6 meses: 776 (197)|Basal: 846 (181)<br>Aos 6 meses: 682 (140)<br>(Em relação ao basal p: 0,001)||Aos 6 meses: 58247 (43392)<br>(Em relação ao basal p: 0,015)|Aos 6 meses: 47323 (35836)||
|**ECR**|**Peptídeo-C AUC120, nmol/L**<br>Basal: 251 (125)<br>Aos 6 meses: 256 (122)<br>(Em relação ao basal p: 0,020)|**Peptídeo-C AUC120, nmol/L**<br>Basal: 282 (84)<br>Aos 6 meses: 212 (97)||**Índice insulinogênico**<br>Basal: 0,11 (0,06)<br>Aos 6 meses: 0,07 (0,05)<br>(Em relação ao basal p: 0,028)|**Índice insulinogênico**<br>Basal: 0,16 (0,10)<br>Aos 6 meses: 0,10 (0,08)|0,023|
||**Colesterol total**<br>Basal: 4,3 (0,6)<br>Aos 6 meses: 5,0 (0,6)<br>(Em relação ao basal p: 0,036)|**Colesterol total**<br>Basal: 4,6 (0,8)<br>Aos 6 meses: 4,8 (1,2)<br>(Em relação ao basalp: 0,05)||**LH, IU/L**<br>Basal: 6,9 (5,8)<br>Aos 6 meses: 3,5 (1,8)<br>(Em relação ao basal p: 0,028)|**LH, IU/L**<br>Basal: 5,6 (2,7)<br>Aos 6 meses: 3,1 (1,7)<br>(Em relação ao basal p: 0,031)||  
||**Desfechos relaciona**|**dos aos parâmetros bioquímicos**||**Desfechos re**|**lacionados ao perfil hormonal**||
|---|---|---|---|---|---|---|
|**Autor,**|||**p**||||
|**ano**|**Intervenção:**|**Controle:**|**comparaçã**<br>**o**|**Intervenção:**|**Controle:**|**p**<br>**comparação**|
||**LDL**|||**FSH,** **IU/L**|**FSH,** **IU/L**||
||Basal: 2,2 (0,5)|**LDL**||Basal: 5,5 (1,3)|Basal: 4,3 (1,2)||
||Aos 6 meses: 2,4 (0,4)|Basal: 2,5 (0,6)<br>Aos 6 meses: 2,6 (0,6)||Aos 6 meses: 4,6 (3,0)|Aos 6 meses: 3.4 (2,1)||
||**HDL**|||**Relação LH/FSH**|**Relação LH/FSH**||
||Basal: 1,5 (0,2)|**HDL**||Basal: 1,5 (0,8)|Basal: 1,5 (0,9)||
||Aos 6 meses: 1,9 (0,2)|Basal: 1,7 (0,2)||Aos 6 meses: 1,0 (0,6)|Aos 6 meses: 1,0 (0,2)||
||(Em relação ao basal p: 0,001)|Aos 6 meses: 1,9 (0,2)<br>(Em relação ao basal p: 0,006)||(Em relação ao basal p: 0,041)|(Em relação ao basal p: 0,034)||
||**Triglicerídeos**||0,023|**Androgênio, nmol/L**|**Androgênio, nmol/L**||
||Basal: 0,8 (0,4)<br>Aos 6 meses: 1,7 (0,8)|**Triglicerídeos**<br>Basal: 0,8 (0,3)||Basal: 12,0 (3,2)<br>Aos 6 meses: 8,0 (2,1)|Basal: 13,4 (3,3)<br>Aos 6 meses: 10,3 (2,5)|0,008|
||(Em relação ao basal p: 0,001|Aos 6 meses: 1,2 (0,4)<br>(Em relação ao basal p: 0,001)||(Em relação ao basal p: 0,001)|(Em relação ao basal p: 0,001)||
||**AIP, mmol/l**|||**Testosterona, nmol/L**|**Testosterona, nmol/L**||
||Basal: -0,24 (0,20)|**AIP, mmol/l**||Basal: 1,7 (0,7)|Basal: 1,8 (0,3)|0,029|
||Aos 6 meses: -0,11 (0,19)|Basal: -0,28 (0,17)||Aos 6 meses: 1,1 (0,5)|Aos 6 meses: 1,6 (0,5)||
||(Em relação ao basal p: 0,016)|Aos 6 meses: -0,22 (0,17)<br>(Em relação ao basal p: 0,022)||(Em relação ao basal p: 0,033)|||
|||||**SHBG, nmol/L**|**SHBG, nmol/L**||
|||||Basal: 38 (16)<br>Aos 6 meses: 165 (24)|Basal: 49 (11)<br>Aos 6 meses: 157 (32)||
|||||(Em relação ao basal p< 0,001)|(Em relação ao basal p< 0,001)||
|||||**FAI, %**|**FAI, %**||
|||||Basal: 5,1 (3,7)|Basal: 4,5 (2,3)||
|||||Aos 6 meses: 1,3 (1,6)|Aos 6 meses: 1,3 (0,6)||
|||||(Em relação ao basal p< 0,001)|(Em relação ao basal p< 0,001)||  
**HOMA-IR HOMA-IR**  
||**Desfechos relacionad**|**os aos parâmetros bioquím**|**icos**|**Desfechos rela**|**cionados ao perfil hormonal**||
|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção:**|**Controle:**|**p**<br>**comparaçã**<br>**o**|**Intervenção:**|**Controle:**|**p**<br>**comparação**|
|||||Basal: 2,1 (1,2)|Basal: 2,3 (0,9)||
|||||Aos 6 meses: 2,8 (1,1)|Aos 6 meses: 2,5 (1,3)||
|||||(Em relação ao basal p< 0,041)|||  
SOP: síndrome dos ovários policísticos; EE: etinilestradiol; CA: acetato de ciproterona; CMA: acetato de cloradinona; DRSP: drospirenona; DSG: desogestrel; ECR: ensaio clínico randomizado; CO; contraceptivos orais; SHBG: Globulina de ligação hormonal sexual, do inglês _Sex Hormone Binding Globulin_ ; FSH: hormônio folículo-estimulante; LH: hormônio luteinizante; b; LDL: proteína de baixa densidade de colesterol; HDL: lipoproteína de alta densidade de colesterol; HOMA-IR: modelos homeostáticos para medir a resistência à insulina; FAI: índice de androgênio livre; DHEAS: sulfato de dehidroepiandrosterona; AIP: índice aterogênico do plasma; AUC: área sob a curva; NS: não significativo; DP: desvio padrão; min-máx.: mínimo e máximo; NR: não reportado;  p para comparação: p intervenção versus controle.  
*quando retirados os estudos de baixa qualidade ou moderado, o valo p perde significância.  
**Tabela 18 – Desfechos de segurança dos anticoncepcionais hormonais combinados em pacientes com SOP.**  
|**Evento Adversos**|**Kriplani**|**et al. 2010(124)**||
|---|---|---|---|
|**(n/N (%))**|**EE 30mcg + DRSP 3mg**|**EE 30 mcg + DSG150mcg**|**p**|
|Náusea|Em 1 mês: 3/29 (10,3)<br>Em 3 meses: 1/29 (3,4)|Em 1 mês: 5/29 (16,7%)<br>Em 3 meses: 3/29 (10,3)|NR|
|Vômito|Em 1 mês: 0|2/29 (6,7)|NR|
|Cefaleia|Entre 3-6 meses de tratamento (cessando<br>ao final do tratamento): 1/29(3,4)|0|NR|
|Dor abdominal:|5/29 (16,7)|6/29 (20,7)|NR|
|Sangramento entre<br>ciclos:|2/30 (6,7)|2/30 (6,7) - um dos pacientes<br>apresentou 2 episódios em 6 meses de<br>tratamento|NR|
|Escape:|1/29|0|NR|
|Flatulência:|0|4/29 (13,8)|NR|
|Dor nas mamas:|2/29 (6,7)|2/29 (6,7)||  
n do desfecho; N: tamanho amostral; EE: etinilestradiol; CA: acetato de ciproterona; DRSP: drospirenona; DSG: desogestrel.  
**Recomendação:** deve-se rastrear a elegibilidade para os AHC, de acordo com os critérios da Organização Mundial da Saúde (OMS) (48). Portanto, é recomendado o uso de AHC em mulheres com SOP, de acordo com o estabelecido na seção de fármacos e esquemas de administração **(GRADE: recomendação forte a favor; qualidade da evidência: alta).**  
**Questão de Pesquisa 6:** Qual a eficácia dos sensibilizadores de ação da insulina para irregularidades  
menstruais em mulheres com PCOS?

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
<mark>((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ("Metabolic Diseases"[Mesh] OR metabolic disorders OR metabolic syndrome)) AND (("Hypoglycemic Agents"[Mesh] OR Antihyperglycemic Agents OR Antidiabetic Drugs OR Antidiabetics OR insulin sensitizer)) Filters: Clinical Trial; Meta-Analysis</mark>  
<mark>Total: 393 referências</mark>  
<mark>Data acesso 24/05/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
<mark>'ovary polycystic disease'/exp AND [embase]/lim OR 'ovary polycystic disease' AND [embase]/lim AND ('metabolic disorder'/exp AND [embase]/lim OR 'metabolic disorder' AND [embase]/lim) AND ('insulin sensitizing agent'/exp OR 'insulin sensitizing  agent' AND [embase]/lim) Total: 380 referências</mark>  
<mark>Data acesso 24/05/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca nas bases resultou em 773 referências (393 no MEDLINE e 380 no EMBASE). Destas, 15 estavam em duplicata. Setecentos e cinquenta e oito referências foram triadas pela leitura de título e resumo. Sessenta e três referências tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destes, 50 foram excluídos no total. Os motivos de exclusão foram nove por não considerarem os sensibilizadores como intervenção ou controle, dois por não incluírem mulheres com SOP, um estudo por ser relato de 8 casos e um por ser uma versão antiga de uma revisão sistemática incluída. Três revisões sistemáticas e meta-análises foram excluídas. Duas por avaliarem os sensibilizadores de insulina em desfechos de não interesse e uma de 2003 porque os estudos incluídos foram considerados em outra revisão sistemática com meta-análise mais recente que foi incluída na extração de dados.</mark>  
<mark>Seis estudos foram excluídos por não avaliarem os desfechos de interesse. Três estudos foram excluídos por avaliarem a troglitazona, um medicamento retirado do mercado. Três estudos foram excluídos por compararem diferentes doses de um mesmo medicamento.</mark>  
<mark>Adicionais 21 estudos recuperados pela presente estratégia de busca foram excluídos, por terem sido incluídos em revisões sistemáticas e meta-análises identificadas e incluídas neste relatório. Um estudo f</mark> oi excluído por administrar metformina por apenas quatro dias e avaliar os desfechos em 3 meses em apenas 19 pacientes, o que não representa a prática clínica. Além disso, foram excluídos cinco estudos que preencheram os critérios de elegibilidade, mas não reportaram desfechos referentes às irregularidades menstruais.  
<mark>Ao final, oito estudos foram considerados elegíveis, sendo três revisões sistemáticas e metaanálises (126-128) e cinco ensaios clínicos randomizados adicionais (129-133) não considerados nas revisões sistemáticas incluídas.</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A apresentação dos dados foi realizada por tipo de estudo. As Tabelas 19 a 21 demonstram dados extraídos de três revisões sistemáticas com meta-análise de ensaios clínicos randomizados (126128). A Tabela 19 apresenta as c</mark> aracterísticas das revisões sistemáticas avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP enquanto a Tabela 20 apresenta as <mark>características dos pacientes incluídos nesses estudos. A Tabela 21 apresenta os resultados das metaanálises para desfechos relacionados à menstruação.</mark>  
<mark>As Tabelas 22 a 24 demonstram dados extraídos dos ensaios clínicos randomizados (129-133). A Tabela 22 apresenta as ca</mark> racterísticas dos estudos avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP enquanto a Tabela 23 apresenta as c <mark>aracterísticas dos pacientes incluídos nesses estudos. A Tabela 24 apresenta os desfechos relacionados à menstruação.</mark>  
**Tabela 19 – Características das revisões sistemáticas avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP.**  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**N estudos**<br>**(n participantes)**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Li et al.**<br>**2010 (126)**|Revisão sistemática e<br>meta-análise de ECRs|Avaliar a eficácia de<br>metformina_versus_<br>tiazolinedionas em<br>mulheres com SOP|10 estudos (459<br>participantes)|Metformina<br>1500mg (2 estudos)<br>1700mg (7 estudos)<br>2550mg (1 estudo)|Roziglitazona<br>4mg (6 estudos)<br>8mg (2 estudos)<br>Pioglitazona<br>30mg (1 estudo)<br>45mg (1 estudo)|Alto<br>Estratégia de busca muito específica, limite<br>inglês de idioma, sem definições de desfechos,<br>sem especificações de unidades de medida<br>dos desfechos, considerou como grupo<br>controle a classe Tiazolidinedionas ao invés de<br>separar as comparaçõespor molécula|
|**Naderpoor**<br>**et al. 2015**<br>**(127)**|Revisão sistemática e<br>meta-análise de ECRs|Avaliar o efeito da<br>combinação de 1)<br>metformina +<br>mudança de estilo de<br>vida_versus_mudança<br>de estilo de vida; e<br>efeito da 2)<br>metformina_versus_<br>estilo de vida em<br>mulheres com SOP|1) 9 estudos<br>2) 4 estudos<br>(608 participantes)|1) Metformina 1,5-<br>2g/dia + mudança<br>estilo de vida<br>2) Metformina 1,5-<br>2g/dia|1) mudança de estilo<br>de vida ± placebo<br>2) mudança de estilo<br>de vida ± placebo|Moderado<br>A elegibilidade foi realizada por apenas um<br>revisor e a maioria dos estudos incluídos na<br>revisão apresentaram alto-moderado risco de<br>viés|
|**Tang et al.**<br>**2012 (128)**|Revisão sistemática e<br>meta-análise de ECRs|Avaliar a efetividade<br>de agentes<br>sensibilizadores da<br>insulina na melhora<br>de parâmetros<br>reprodutivos e<br>metabólicos em<br>mulheres com SOP|43 estudos (1 dos<br>44 estudos<br>incluídos avaliou<br>inositol) (3709<br>participantes)|Metformina,<br>pioglitazona ou<br>roziglitazona<br>isoladas|Placebo ou nenhum<br>tratamento|Moderado<br>Seleção, extração de dados e avaliação do<br>risco de viés por dupla de revisores<br>independentes. Apesar de relatarem que<br>gráfico de funil foi "aceitável", dados não<br>foram apresentados e estudos potencialmente<br>elegíveis não foram identificados (incluídos em<br>outras RS abordando a mesma questão de<br>pesquisa). Meta-análises utilizaram modelo de<br>efeito fixo, a despeito da heterogeneidade<br>estatística|  
N: número de estudos incluídos; n: número de participantes; ECRs: ensaios clínicos randomizados; SOP: síndrome dos ovários policísticos.  
**Tabela 20 –** **<mark>Características das pacientes incluídas nas revisões sistemáticas avaliando os efeitos dos sensibilizadores de ação da insulina.</mark>**  
|**Autor, ano**|**N**<br>**Intervenção**|**N**<br>**Controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Intervenção**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Controle**|**Tempo de**<br>**seguimento**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de**<br>**seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|---|
|**Li et al.**<br>**2010 (126)**|Total 459<br>apresentado p|(não<br>or grupo)|NR|NR|Faixa d<br>31-36: n=<br>22-25: n=<br>26-29: n=<br><25_versus_>2|e IMC:<br>3 estudos<br>2 estudos<br>4 estudos<br>5: n= 1 estudo|3 a 6 meses|0-33%|no total|
|**Naderpoor**<br>**et al. 2015**<br>**(127)**|259|271|Variação<br>entre 12-39|Variação entre<br>12-39|>30 (exceto em 1<br>estudo), sendo >35 em<br>7 de 12 estudos|>30 (exceto em 1<br>estudo), sendo >35 em<br>7 de 12 estudos|6 meses|Intervenção<br>(1 e 2):<br>71/259 (25)|Controle (1 e<br>2): 79/271 (29)|
|**Tang et al.**<br>**2012 (128)**|Total 370<br>apresentado p|9 (não<br>or grupo)|Média mínim<br>3|a 24,2 e máxima<br>2,8|58% das pacien<br>(Mínimo 24,3;<br>em ambos|tes com IMC >30<br>máximo 39,4)<br>os grupos|Duração média dos<br>estudos 19,5<br>semanas (variação<br>entre 4 e 48<br>semanas)|NR, porém, r<br>dos estudos<br>alto risco<br>exclusões pó|eportou que 11<br>apresentaram<br>de viés por<br>s-randomização|  
N: número de estudos incluídos; n: número de participantes; IMC: índice de massa corporal; NR: não reportado. Quando não especificado, dados foram apresentados como n/N (%).  
**Tabela 21** **<mark>– Meta-análises a</mark> valiando os efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos reprodutivos e sinais de SOP.**  
|**Autor ano**|**Comaraão**|**Men**<br>**N td**|**struação**|
|---|---|---|---|
|**,**|**pç**|**esuos**<br>**(n participantes)**|**Medidas de Associação (IC95%)**|
|**Li et al. 2010**<br>**(126)**|Metformina_versus_<br>tiazolinedionas|4 estudos (144 participantes)|**Menstruação em 3 meses:**<br>OR: 0,72 (IC95% 0,37; 1,41), I<sup>2</sup>=0%;<br>p=0,34|
|**Naderpoor et**|Metformina +<br>mudança de estilo de<br>vida_versus_mudança<br>de estilo de vida|3 estudos (35 participantes em<br>cada grupo)|**Menstruação**<br>**(Ciclos/6-12 meses):**<br>DM: 1,06 (IC95% 0,30; -1,82); I<sup>2</sup>=0%;<br>p=0,006|
|**al. 2015 (127)**|Metformina_versus_<br>estilo de vida|3 estudos (55 participantes)|**Menstruação**<br>**(Ciclos/6-12 meses):**<br>DM: -0,02 (IC95% -0,49; 0,45); I<sup>2</sup>=0%;<br>p=0,93|
||Metformina_versus_<br>placebo ou não<br>tratamento|**Regularização da frequência:**<br>7 estudos (427 participantes)|**Regularização da frequência:**<br>OR 1,72 (IC95% 1,14; 2,61), I<sup>2</sup>=54%;<br>p=0,01|
|**Tang et al. 2012**<br>**(128)**|Rosiglitazona_versus_<br>placebo ou não<br>tratamento|**Regularização da frequência:**<br>2 estudos (100 participantes)|**Regularização da frequência:**<br>OR 5,59 (IC95% 2,20; 14,19), I<sup>2</sup>=12%;<br>p=0,0003|
||Pioglitazona_versus_<br>placebo|**Regularização da frequência:**<br>2 estudos (70 participantes)|**Regularização da frequência:**<br>OR 8,88 (IC95% 2,35; 33,61), I<sup>2</sup>=0%;<br>p=0,0013|  
N: número de estudos incluídos; n: número de participantes; IC95%: intervalo de confiança de 95%; DM: diferença de médias; OR: razão de chances ( _odds ratio_ ).  
**Tabela 22 – Características dos estudos avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP.**  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|
|**Ahmad et al.**<br>**2008 (129)**|ECR, aberto|Comparar a eficácia de<br>metformina e rosiglitazona na<br>hiperinsulinemia e<br>hiperandrogenia,|Metformina 1500 mg/dia,<br>n=31|Rosiglitazona 4<br>mg/dia, n=30|Alto: Não há descrição do sigilo da alocação, estudo<br>aberto|
|**Bridger et al.**<br>**2006 (130)**|ECR, controlado<br>por placebo,<br>unicêntrico|Avaliar os efeitos da<br>metformina_versus_placebo,<br>ambos os grupos recebendo<br>orientações de alteração de<br>estilo de vida, em desfechos<br>clínicos, endócrinos e<br>metabólicos em adolescentes<br>com SOP e hiperinsulinemia,|Metformina 1500 mg/dia<br>por 12 semanas, n=11|Placebo por 12<br>semanas, n=11|Alto: Não há descrição do sigilo da alocação,<br>esquemas de cegamento de tipos de análise|
|**Mohiyiddeen et**<br>**al. 2013 (131)**|ECR|Avaliar os efeitos de<br>metformina de baixa dose<br>versus rosiglitazona em<br>desfechos clínicos,<br>bioquímicos e de imagem em<br>mulheres com SOP|Metformina 1000mg/dia<br>por<br>3 meses, n=17|Rosiglitazona 4 mg/dia<br>por 3 meses, n=18|Alto: sem descrição do método de sigilo de<br>alocação, estudo aberto, não há descrição do tipo<br>de análise realizada e não há relato do número de<br>pacientes considerados nas análises. Os testes de<br>hipóteses foram aplicados apenas para as variações<br>intra-grupos e não entre osgrupos|
|||Avaliar o efeito de||||
|**Romero e Del**<br>**Bono, 2004**<br>**(132)**|ECR|sensibilizadores de insulina<br>sensibilizadores em mulheres<br>com SOP pré-menopausa (15 a<br>36 anos de idade), com ou sem<br>resistência à insulina|Metformina (1,5 ou<br>2g/dia), entre 6 e 32<br>semanas|Rosiglitazona (4 ou 8<br>mg/dia), entre 6 e 32<br>semanas|Alto: Não há descrição do sigilo da alocação,<br>esquemas de cegamento de tipos de análise|
|**Shahebrahimi**<br>**et al. 2016 (133)**|ECR unicêntrico,<br>estratificado por<br>idade, peso,<br>presença de<br>hirsutismo e|Comparar os efeitos do<br>tratamento com metformina<br>_versus_pioglitazona em<br>pacientes com SOP (critérios<br>de Rotterdam)|Metformina 500mg 3x/dia<br>durante 3 meses, n=28<br>participantes|Pioglitazona 30mg/dia<br>durante 3 meses, n=28<br>participantes|Alto: não há descrição sobre randomização, sigilo<br>da alocação, cegamento de pacientes,<br>investigadores, avaliadores de desfecho, e tipos de<br>análises|  
história de disfunção menstrual  
ECR: ensaio clínico randomizado; n: número de participantes; SOP: síndrome dos ovários policísticos.  
**Tabela 23** **<mark>– Características das pacientes incluídas nos estudos avaliando os efeitos dos sensibilizadores de ação da insulina.</mark>**  
|**Autor, ano**|**N**<br>**Intervençã**<br>**o**|**N Controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Intervenção**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Controle**|**Tempo de**<br>**seguimento**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de**<br>**seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|---|
|**Ahmad et al.**<br>**2008 (129)**|Metformin<br>a n=31|Rosiglitazona<br>n=30|22,81 (4,52)|23,20 (3,36)|27,66 (5,44)|26,94 (5,24)|12 meses|4/31 (13)|5/30(17)|
|**Bridger et al.**<br>**2006 (130)**|Metformin<br>a n=11|Placebo<br>n=11|16,07 (0,97)|16,08 (1,39)|33,6 (5,6)|30,81 (3,0)|3 meses|Ambos os gr|upos: 1/22 (5)|
|**Mohiyiddeen**<br>**et al. 2013**<br>**(131)**|Metformin<br>a n=17|Rosiglitazona<br>n=18|29,0 (1,0)|30,0 (0,9)|29,1 (1,0)|29,7 (1,0)|3 meses|Ambos os grup|os: 5/40 (12,5)|
|**Romero e Del**<br>**Bono, 2004**<br>**(132)**|Metformin<br>a<br>n=20|Rosiglitazona<br>n=20|24,3 (2,1)|25,8 (1,2)|NR|NR|NR|4/20 (20)|7/20 (35)|
|**Shahebrahimi**<br>**et al. 2016**<br>**(133)**|Metformin<br>a, n=28|Pioglitazona<br>n=28|27,5 (3,68)|27,57 (5,91)|27,71 (4,36)|28,28 (4,49)|3 meses após início<br>do tratamento|De acord<br>denominadores<br>finais, não ho<br>segui|o com os<br>das proporções<br>uve perda de<br>mento|  
n: número de participantes; IMC: índice de massa corporal; NR: não reportado. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
**Tabela 24 – Efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos reprodutivos e sinais de SOP.**  
|||**Menstruação**||
|---|---|---|---|
|**Autor, ano**|**Intervenção**|**Controle**|**p para a comparação**|
|**Ahmad et al. 2008**<br>**(129)**|Menstruação regular:<br>3 meses: 14/31 (45)<br>6 meses: 28/31 (90)<br>12 meses: 30/31(96)|Menstruação regular:<br>3 meses: 10/30 (33)<br>6 meses: 18/30 (60)<br>12 meses: 28/30(90)|NR|
|**Bridger et al. 2006**<br>**(130)**|Retorno menstruação:<br>10/11 (91)|Retorno menstruação:<br>4/11 (36)|NR|
|**Mohiyiddeen et al.**<br>**2013 (131)**|Melhora na menstruação:<br>11/14 (78,6)|Melhora na menstruação:<br>7/14 (50)|p=0,24|
|**Romero e Del Bono,**<br>**2004 (132)**|Recuperação da menstruação<br>normal (pelo menos 3 ciclos<br>consecutivos):<br>15/16(93,8)|Recuperação da menstruação<br>normal (pelo menos 3 ciclos<br>consecutivos):<br>11/13(85)|NR|
||Oligomenoreia:|Oligomenoreia:||
|**Shahebrahimi et al.**|13/28 (46,4)|11/28 (39,3)|Oligomenoreia: p=0,525|
|**2016 (133)**|Amenorreia:<br>0|Amenorreia:<br>1/28(3,6)|Amenorreia: NR|  
NR: não reportado. Quando não especificado, dados foram apresentados como n/N (%).  
**RECOMENDAÇÃO:** As evidências atuais indicam que a metformina, em paralelo com suas ações metabólicas que melhoram a sensibilidade à ação da insulina, pode reduzir a secreção de androgênios pelos ovários e melhorar ou restaurar a ciclicidade menstrual (49-51). Os efeitos são mais evidentes se associados à medidas de alterações de estilo de vida (50). Assim, a metformina é recomendada como agente sensibilizador da ação da insulina para o tratamento de segunda linha das irregularidades menstruais em mulheres com SOP que apresentem alterações metabólicas e distúrbio menstrual, e nas quais as mudanças de estilo de vida tenham falhado em restaurar o padrão cíclico das menstruações. **(GRADE: recomendação forte a favor; qualidade da evidência: moderada)** A metformina é segura, não é contraceptiva e pode induzir ciclos ovulatórios. Portanto, é recomendável garantir a contracepção para pacientes com SOP e em uso de metformina, mas que não desejam gestar **.**  
**Questão de Pesquisa 7:** Qual é o antiandrogênico mais eficiente (eficaz e seguro) para o tratamento de hiperandrogenismo em mulheres com PCOS?

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **MEDLINE via Pubmed:** -->
((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ("Hyperandrogenism"[Mesh] OR hyperandrogenism)) AND ((("Nonsteroidal Anti-Androgens"[Mesh] OR Nonsteroidal Anti-Androgens OR steroidal Anti-Androgens)) OR ((cyproterone acetate OR spironolactone OR flutamide OR finasteride)))  
<mark>Total: 120 referências</mark>  
<mark>Data de acesso: 2</mark> 9/07/2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
'ovary polycystic disease'/exp OR 'ovary polycystic disease' AND ('hyperandrogenism'/exp OR 'hyperandrogenism') AND 'antiandrogen'/exp/mj AND [embase]/lim  
Total: 269 referências  
Data de acesso: 03/08/2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
A busca nas bases de dados resultou em 389 referências (120 no MEDLINE e 269 no EMBASE). Após a remoção das referências duplicadas, 340 citações foram avaliadas por meio da leitura de título e resumo. Quarenta e duas citações tiveram seus textos avaliados na íntegra, sendo 21 excluídos nessa etapa por serem série de casos, carta ao editor, resumos de congressos que não permitiram a extração de dados de interesse ou por não apresentar desfechos de interesse ou por não avaliarem a intervenção em população com pelo menos um terço de pacientes com SOP. Ao final, dez estudos foram considerados elegíveis para responder a questão de pesquisa, sendo nove estudos primários e uma revisão sistemática com meta-análise (que não envolveu os estudos primários aqui apresentados) (52, 60, 134-141).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
A descrição sumária dos estudos primários avaliando antiandrogênios em mulheres com SOP encontra-se na Tabela 25. A Tabela 26 apresenta as características dos participantes nos estudos enquanto a Tabela 27 apresenta os desfechos de interesse. A Tabela 28 apresenta as comparações envolvidas na revisão sistemática. A Tabela 29 apresenta os resultados das meta-análises.  
**Tabela 25 – Características dos estudos primários que avaliaram antiandrogênios em mulheres com SOP.**  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População**|**Detalhes Intervenção**|**Detalhes Controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Carmina e**<br>**Lobo, 2002**<br>**(134)**|ECR|Avaliar o efeito de 4 diferentes<br>antiandrógenos em mulheres com<br>hiperandrigenismo<br>(predominantemente com SOP) na<br>melhora da acne|1) Flutamina 205 mg/dia<br>2) Finasterida 5 mg/dia|3) Acetato de ciproterona<br>2mg + EE 35μg<br>4) Acetato de ciproterona<br>(alta dose) 50mg do dia 5<br>ao dia 15 com adição de EE<br>25μg do dia 5 ao dia 25, em<br>esquema sequencial|Durante 1<br>ano de<br>tratamento|Alto<br>Não há descrição do sigilo da<br>alocação, sem esquema de<br>cegamento|
|||||reverso|||
|**Falsetti et**<br>**al. 1997**<br>**(resumo)**<br>**(135)**|ECR|Avaliar tratamento do hirsutismo<br>com finasterida vs flutamida em<br>pacientes com SOP|Finasterida 5mg/dia durante<br>6 meses|Flutamida 250mg 2x/dia<br>durante 6 meses|Durante 6<br>meses de<br>tratamento|Alto<br>Não há descrições sobre<br>randomização, número de<br>pacientes, sigilo da alocação,<br>cegamento, perdas e<br>mensuração dos desfechos|
|**Ibanez et al.**<br>**2003 (136)**|ECR cross-<br>over. Apenas<br>dados do<br>primeiro<br>período de<br>tratamento<br>estão<br>apresentados|Avaliar os efeitos do tratamento<br>com flutamida + metformina na<br>resistencia à insulina e composição<br>corporal em adolescentes não<br>obesas com SOP|Flutamida 125mg/dia +<br>metformina 1275mg/dia<br>durante 9 meses|Não tratamento durante 3<br>meses|Durante 3<br>meses de<br>tratamento|Alto<br>Não há descrições sobre<br>randomização, sigilo da<br>alocação. Estudo aberto. Não<br>apresentou valores objetivos<br>do desfecho de interesse desta<br>questão|
|**Leelaphiwat**<br>**et al. 2014**<br>**(52)**|ECR em<br>blocos, com<br>alocação<br>sigilosa|Avaliar os efeitos do tratamento<br>com EE + desogestrel +<br>espironolactona vs etinilestradiol +<br>acetato de ciproterona em<br>pacientes com SOP|EE 30mcg + desogestrel<br>150mcg + espironolactona<br>25mg por dia durante 3<br>ciclos de 21 dias|EE 35mcg + acetato de<br>ciproterona 2mg por dia<br>durante 3 ciclos de 21 dias|Durante 3<br>meses de<br>tratamento|Moderado-baixo<br>Estudo de pequeno porte e<br>aberto|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População**|**Detalhes Intervenção**|**Detalhes Controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Luque-**<br>**Ramirez et**<br>**al. 2007**<br>**(137)**|ECR com<br>alocação<br>sigilosa|Avaliar os efeitos do tratamento<br>com EE + acetato de ciproterona vs<br>metformina em desfechos<br>metabólicos de pacientes com SOP|EE 35μg+ acetato de<br>ciproterona 2mg por dia<br>(ciclo de 21 comprimidos<br>com princípio ativo + 7 com<br>placebo) durante 24<br>semanas|Metformina 425mg 2x/dia<br>na primeira semana e<br>850mg 2x/dia nas semanas<br>seguintes durante 24<br>semanas|Durante 24<br>semanas de<br>tratamento|Alto<br>Estudo de pequeno porte,<br>aberto, e com alta proporção<br>de exclusão pós-randomização<br>no grupo controle|
|**Mazza et al.**<br>**2014 (138)**|ECR|Avaliar os efeitos do tratamento<br>com metformina vs metformina +<br>espironolactona em pacientes com<br>SOP com sobrepeso ou obesidade|Metformina 425mg 2x/dia na<br>primeira semana e 850mg<br>2x/dia nas semanas<br>seguintes + dieta<br>hipocalórica (1300 kcal)<br>durante 6 meses|Metformina 425mg 2x/dia<br>na primeira semana e<br>850mg 2x/dia nas semanas<br>seguintes +<br>espironolactona 25mg/dia<br>+ dieta hipocalórica (1300<br>kcal)durante 6 meses|Durante 6<br>meses de<br>tratamento|Alto<br>Não descreveu sigilo da<br>alocação, estudo aberto|
|**Spritzer et**<br>**al. 2000**<br>**(139)**|ECR|Avaliar a eficácia de acetato de<br>ciproterona + EE vs espironolactona<br>em pacientes com SOP + hirsutismo<br>ou hirsutismo idiopático. Dados<br>estão apresentados apenas para o<br>estrato depacientes com SOP|Espironolactona 200mg/dia,<br>20 dias por mês durante 1<br>ano|Acetato de ciproterona<br>50mg/dia durante 20 dias +<br>EE 35μg/dia concomitante<br>aos últimos 10 dias de<br>ciproterona, por 1 ano|Durante 12<br>meses de<br>tratamento|Alto<br>Alocação sequencial dos<br>tratamentos, sem sigilo da<br>alocação, estudo aberto|
|**Wong et al.**<br>**2005 (140)**|ECR|Comparar a eficácia da<br>espironolactona versus finasterida<br>no hirsutismo em mulheres<br>predominantemente com SOP.<br>Dados apresentados em conjunto<br>para pacientes com e sem SOP|Espironolactona 100mg/dia<br>durante 6 meses|Finasterida 5mg/dia<br>durante 6 meses|Dados<br>apresentados<br>em 3 e 6<br>meses|Alto<br>Não há descrição do método de<br>randomização e sigilo da<br>alocação. A maioria dos dados<br>de desfecho é apresentado em<br>forma de gráfico, não<br>permitindo extrair a medida<br>quantitativa|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População**|**Detalhes Intervenção**|**Detalhes Controle**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Wu et al.**<br>**2008 (60)**|ECR|Avaliar os efeitos do tratamento<br>com EE + acetato de ciproterona vs<br>EE+ acetato de ciproterona +<br>metformina vs metformina em<br>desfechos metabólicos e endócrinos<br>de pacientes com SOP com e sem<br>obesidade|1) EE 35μg + acetato de<br>ciproterona 2mg por dia<br>(ciclo de 21 dias por mês)<br>durante 3 meses<br>2) Metformina 500mg 3x/dia<br>durante 3 meses|EE 35μg + acetato de<br>ciproterona 2mg por dia<br>(ciclo de 21 dias por mês) +<br>metformina 500mg 3x/dia<br>durante 3 meses|Durante 3<br>meses de<br>tratamento|Alto<br>Não descreveu sigilo da<br>alocação, estudo aberto|  
ECR: ensaio clínico randomizado; SOP: Síndrome dos Ovários Policísticos; EE: etinilestradiol.  
**Tabela 26 – Características dos participantes nos estudos primários que avaliaram antiandrogênios em mulheres com SOP.**  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade Intervenção**|**Idade**<br>**Controle**|**IMC intervenção**|**IMC Controle**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|
|**Carmina e**<br>**Lobo, 2002**<br>**(134)**|1) Flutamina: 12<br>2) Finasterida: 12|3) Acetato<br>ciproterona + EE: 12<br>4) Acetato<br>ciproterona alta<br>dose: 12|Toda a coorte|: 24 (1)|Toda a coort|e: 24,2 (1)|0|0|
|**Falsetti et**|44 pacientes no||||||||
|**al. 1997**<br>**(resumo)**<br>**(135)**|total. Não<br>reportado n em<br>cadagrupos||NR|NR|NR|NR|NR|NR|
|**Ibanez et al.**<br>**2003 (136)**|16|14|Toda a coorte: méd<br>mínimo 13,6; má|ia 15,8 (0,3),<br>ximo 18,6|21,7 (0,5)|21,8 (0,4)|NR|NR|
|**Leelaphiwat**<br>**et al. 2014**<br>**(52)**|18|18|26,29 (4,04)|26,94 (6,87)|27,15 (6,37)|22,96 (5,35)|1 exclusão das<br>análises por<br>apendicectomia de<br>urgência|1 exclusão por<br>cefaleia, 1 perda de<br>seguimento|
|**Luque-**<br>**Ramirez et**<br>**al. 2007**<br>**(137)**|15|19|23,4 (5,6)|25,1 (6,6)|29,2 (5,7)|30,5 (6,9)|0|7 exclusões após<br>randomização (3<br>violações de<br>protocolo, 2 eventos<br>adverso GI, 1<br>gestação, 1 perda de<br>seguimento)|
|**Mazza et al.**<br>**2014(138)**|28|28|23,3 (4,2)|23,1 (3,8)|31,1 (5,0)|32,8 (5,6)|2|2|
|**Spritzer et**<br>**al. 2000**<br>**(139)**|10 com SOP|9 com SOP|Toda a corte: 22|(69) anos|Toda a coort|e: 24 (65)|2 no total (não de<br>experimen|scrito de qual grupo<br>tal ou estrato)|  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade Intervenção**|**Idade**<br>**Controle**|**IMC intervenção**|**IMC Controle**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|
|**Wong et al.**<br>**2005(140)**|5 (4 com SOP)|9 (7 com SOP)|33,4 (1,3) anos|29,3 (3,1)<br>anos|NR|NR|NR|NR|
|**Wu et al.**<br>**2008 (60)**|1) n=20 (8<br>obesas, 12 não<br>obesas)<br>2) n=20 (8<br>obesas, 12 não<br>obesas)|20 (9 obesas, 11 não<br>obesas)|1) Obesas: 25,0 (4,3)<br>Não obesas: 26,1<br>(4,6), de 19<br>pacientes<br>2) Obesas: 25,6 (3,6)<br>Não obesas: 25,6<br>(4,2), de 18<br>pacientes|Obesas: 24,5<br>(2,4)<br>Não obesas:<br>25,8 (4,0), de<br>16 pacientes|1) Obesas: 25,3<br>(0,8)<br>Não obesas: 21,4<br>(1,6), de 19<br>pacientes<br>2) Obesas: 25,6<br>(0,6)<br>Não obesas: 21,5<br>(1,8), de 18<br>pacientes|Obesas: 25,2<br>(1,0)<br>Não obesas:<br>21,6 (1,4), de<br>16 pacientes|1) 1 por aumento de<br>peso<br>2) 2, motivos não<br>reportados|4 por EA GI de<br>moderada intensidade|  
N: número de pacientes; SOP: Síndrome dos Ovários Policísticos; IMC: Índice de massa corporal; EE: etinilestradiol; NR: não reportado. Quando não especificado dados foram apresentados em média (desvio-padrão).  
**Tabela 27 – Desfechos apresentados nos estudos primários que avaliaram antiandrogênios em mulheres com SOP.**  
|**Autor, ano**|**Desfecho intervenção**|**Desfecho controle**|**p para comparação**|**Desfecho segurança**<br>**Intervenção**|**Desfecho segurança**<br>**Controle**|**p para**<br>**comparação**|
|---|---|---|---|---|---|---|
||Redução do Score de<br>Cooke para acne:|Redução do Score de Cooke<br>para acne:|Redução do Score de Cooke:<br>3) versus 4) = p>0,05||||
||1) -59% (4)|3) - 70% (5)|3) versus 1) = p>0,05|Não ocorreram EAs em|||
|**Carmina e**<br>**Lobo, 2002**<br>**(134)**|2) -36%( 2)<br>Proporção de pacientes<br>que reduziu o score de<br>Cook a <6:<br>1) 9/12 (755)<br>2)4/12(33%)|4) -77% (4)<br>Proporção de pacientes<br>que reduziu o score de<br>Cook a <6:<br>3) 10/12 (83%)<br>4)11/12(92%)|2) versus 1) = p<0,05<br>3) versus 1) = p<0,05<br>4) versus 1) = p<0,05<br>Proporção de pacientes que<br>reduziu o score de Cook a <6:<br>NR|nenhum dos grupos. A<br>flutamina e a finasterida<br>não alteraram o padrão<br>menstrual|Não ocorreram EAs em<br>nenhum dos grupos|NA|
|**Falsetti et al.**<br>**1997**|Escore FG: redução de|Escore FG: redução de 20%||Não foram observados|EAs importantes ou||
|<br>**(resumo)**<br>**(135)**|25% Diâmetro do pelo:<br>redução de16-25%|Diâmetro do pelo: redução<br>de15,3-22%|NR|alteração nos parâmetro<br>ambos os|s hematoquímicos em<br>grupos|NR|  
|**Autor, ano**|**Desfecho intervenção**|**Desfecho controle**|**p para comparação**|**Desfecho segurança**<br>**Intervenção**|**Desfecho segurança**<br>**Controle**|**p para**<br>**comparação**|
|---|---|---|---|---|---|---|
|**Ibanez et al.**<br>**2003 (136)**|Redução Ecore FG em<br>relação ao basal em 3<br>meses:p<0,0001|NR||NR|NR|NA|
|**Leelaphiwat**<br>**et al. 2014**<br>**(52)**|Escore global de acne:<br>6,94 (3,47) (p<0,01 para<br>comparação intragrupo)<br>Escore FG: 4,07 (1,91)|Escore global de acne: 8,13<br>(6,09) (p<0,01 para<br>comparação intragrupo)<br>Escore FG: 4,92 (2,53)<br>(p<0,05 para comparação<br>intragrupo)|NR|Aumento de peso: 5/17<br>(29,4)<br>Cefaleia: 5/17 (29,4)<br>Engurgitação mamária:<br>5/17 (29,4)<br>Tontura: 4/17 (23,5)<br>Vômitos: 0|Aumento de peso: 7/16<br>(43,0)<br>Cefaleia: 4/16 (25,0)<br>Engurgitação mamária:<br>3/16 (18,8)<br>Tontura: 3/16 (18,8)<br>Vômitos: 1/16(6,3)|Não significante|
|**Luque-**<br>**Ramirez et al.**<br>**2007(137)**|NR (dado apresentado<br>apenas como figura)|NR (dado apresentado<br>apenas como figura)|Escore FG: p<0,05|Não houve diferença entre<br>de intolerância a glic|os grupos na frequência<br>ose ou dislipidemia|Não significante|
|**Mazza et al.**<br>**2014(138)**|Escore FG: 10,7 (4,9)|Escore FG: 11,0 (5,0)|Escore FG: NS|NR|NR|NA|
|**Spritzer et al.**<br>**2000 (139)**|Em 12 meses:<br>Escore FG: 16 (1)<br>LH (IU/L): 6,03 (0,77)|Em 12 meses:<br>Escore FG: 12 (1)<br>LH (IU/L): 2,01 (0,75)|FG: p=0,009<br>LH: p<0,05|Sangramento durante<br>ciclo: 4/10 (40)<br>Oligomenorreia: 0|Sangramento durante<br>ciclo: 0<br>Oligomenorreia: 2/9<br>(22,2)|NR|
|**Wong et al.**<br>**2005 (140)**|Escore FG (redução em<br>relação ao basal):<br>3 meses: -1,2 (0,4)<br>6 meses: -2,56(0,7)|Escore FG (redução em<br>relação ao basal):<br>3 meses: -1,2 (0,2)<br>6 meses: -2,1(0,4)|3 meses: p>0,05<br>6 meses: p< 0,05|NR|NR|NA|
|**Wu et al.**<br>**2008 (60)**|Escore FG:<br>1) Obesas: 6,8 (1,3),<br>p<0,05 em relação ao<br>basal<br>Não obesas: 6,9 (1,1),<br>p<0,05 em relação ao<br>basal<br>2) Obesas: 7,7 (1,2)<br>Não obesas:  7,4(2,0)|Escore FG:<br>Obesas: 6,4 (0,8), p<0,05<br>em relação ao basal<br>Não obesas: 6,7 (1,2),<br>p<0,05 em relação ao basal|NR|1) 1 aumento de peso<br>2) EA GI leve a moderado,<br>sem necessidade de<br>descontinuação|4<br>EA GI de moderada<br>intensidade com<br>descontinuação do<br>estudo|NR|  
FG: Ferriman-Gallwey; LH: hormônio luteinizante; EA: evento adverso; NR: não reportado; NA: não se aplica; GI: gastrointestinal. Quando não especificado dados foram apresentados em média (desvio-padrão) ou n/N(%).  
**Tabela 28 – Características da revisão sistemática avaliando antiandrogênios em mulheres com SOP.**  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**Comparações avaliadas**|**Tempo de seguimento**|**Risco de viés**|
|---|---|---|---|---|---|
||||1) EE 35μg + AC 2mg versus EE 30μ + drospiridona 3mg|1) 12 meses||
||||2)  EE 35μg + AC 2mg versus EE 30μ + desogestrel 0,15mg|2) 12-24 meses||
||||3) EE 35μg + AC 2mg versus EE 50μ + desogestrel 0,15mg|3) 24 meses||
||||4) Flutamida 250mg 2x dia verus placebo|4) 6-12 meses||
|**Van Zuuren**<br>**et al. 2015**<br>**(141)**|Revisão sistemática<br>(Cochrane) com<br>meta-análise|Avaliar diversas<br>intervenções no<br>hirsutismo em população<br>não necessariamente<br>com SOP|5) Flutamida 250mg 1-2x dia verus espironolactona 100mg 1x<br>dia<br>6) Espironolactona 100mg dia versus placebo<br>7) Finasterida 5-7,5mg 1x dia versus placebo|5) 6-9 meses<br>6) 6meses<br>7) 6-9 meses|Baixo|
||||8) Finasterida 2,5mg 1x dia versus finasterida 5mg 1x dia|8) 6-12 meses||
||||9) Finasterida 2,5mg 1x dia versus finasterida 7,5mg 1x dia|9) 6 meses||
||||10) Finasterida 5,0mg 1x dia versus finasterida 7,5mg 1x dia|10) 6 meses||
||||11) Finasterida 2,5mg 1x dia versus finasterida 2,5mg a cada 3<br>dias|11) 10 meses||  
EE: etinilestradiol.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **_Tabela 29– Desfechos apresentados na revisão sistemática avaliando antiandrogênios em mulheres com SOP._** -->
|**Autor,**|**Total de**<br>**estudos na**|**Melhora do hirsutismo relatada pelo**<br>|**Redução no score Ferriman-**<br>|**Proporção de pacientes que**<br>|**Alterações no IMC**|
|---|---|---|---|---|---|
|**ano**|<br>**comparação**|**paciente**|**Gallwey**|**relataram evento adverso**||
||1) 2<br>2) 4|1) NR<br>2) NR|1) DM=0,0 (IC95% -0,45; 0,45);<br>total de 1 estudo, I<sup>2</sup>=NA, p=1,0<br>2) DM=-1,84 (IC95% -3,86; 0,18);<br>total de 3 estudos, NR, I²=45%;<br>p=0,07<br>3) Escore de Lorenzo: DM= -1,30|1) RR=1,02 (IC95% 0,15; 6,98); 1<br>estudo, 100 participantes, I<sup>2</sup>=NA,<br>p=0,99<br>2) RR=0,41 (IC95% 0,08; 2,05);<br>total de 1 estudo, 100<br>participantes;I<sup>2</sup>=NA; p=0,28|1) DM=-0,70 kg/m² (IC95% -2,72;<br>1,32); total de 1 estudo, I<sup>2</sup>=NA,<br>p=0,50<br>2) DM=-0,14 kg/m²,(IC95% -2,44;<br>2,16); total de 1 estudo, NR,<br>I<sup>2</sup>=NA, p=0,90|
||3) 1|3) NR|(IC95% -7,87; 5,27); total de 1<br>estudo,NR,I<sup>2</sup>=NA, p=0,70|3) NR|3) NR|
||4) 2|4) RR=17,0 (IC95% 1,11; 259,87), total de<br>um estudo; total de 20 pacientes; I<sup>2</sup>=NA,<br>p=0,04|4) DM=-7,60 (IC95% -10,53; -4,67);<br>total de um estudo, I<sup>2</sup>=NA,<br>p<0,001|4) RR=9,00 (IC95% 0,52;<br>156,91); total de 1 estudo, 40<br>participantes,I<sup>2</sup>=NA; p= 0,13|4) DM=-2,00 kg/m² (IC95%: -<br>3,83; -0,17); total de 1 estudo,<br>NR,I<sup>2</sup>=NA, p=0,03|
|**Van**<br>**Zuuren et**<br>**al. 2015**<br>**(141)**|5) 2<br>6) 1<br>7) 3<br>8) 2<br>9) 1<br>10) 1|5) RR=2.00 (IC95% 0,88; 4,54); total de 1<br>estudo, 20 participantes, I<sup>2</sup>=NA, p=0,10<br>6) RR=9,00 (IC95% 0,55; 147,95); total<br>de 1 estudo, 20 participantes, I<sup>2</sup>=NA,<br>p=0,12<br>7) RR=2,06 (IC95% 0,99; 4,29); total de 1<br>estudo, NR, I<sup>2</sup>=NA, p=0,05<br>8) Escala de Likert: DM=-0,10 (IC95% -<br>0,42; 0,22); total de 1 estudo, NR, I<sup>2</sup>=NA,<br>p=0,55<br>9) Escala de Likert: DM=-0,70<br>(IC95% -0,97; -0,43); total de 1 estudo,<br>45participantes,I<sup>2</sup>=NA, p<0,001<br>10) Escala de Likert: DM=-0,60 (IC95% -<br>0,83; -0,37); total de 1 estudo, NR,|5) DM=-1,90 (IC95% -5,01; 1,21);<br>total de 1 estudo, 20 participantes,<br>I<sup>2</sup>=NA, p=0,23<br>6) DM=-7,69 (IC95% -10,12; -5,26);<br>total de 1 estudo, 20 participantes,<br>I<sup>2</sup>=NA, p<0,001<br>7) DM=-5,73 (IC95% -6,87; -4,58);<br>total de 3 estudos, NR, I² = 0%,<br>p<0,001<br>8) DM=-0,20 (IC95% -0,52; 0,12);<br>total de 1 estudo, NR, I<sup>2</sup>=NA,<br>p=0,23<br>9) DM=11,00% (IC 95%: 8,54;<br>13,46); total de 1 estudo, 45<br>participantes,I<sup>2</sup>=NA, p<0,001<br>10) DM=2,7 (IC95% 2,47; 2,93);<br>total de 1 estudo, NR, I<sup>2</sup>=NA,|5) RR=0,40 (IC95% 0,10; 1,60);<br>total de 1 estudo, 20<br>participantes,I<sup>2</sup>=NA, p=0,20<br>6) RR=5,00 (IC95%: 0,70; 35,50);<br>total de 1 estudo, 20<br>participantes,I<sup>2</sup>=NA, p=0,11<br>7) RR=1,13 (IC95%: 0,48; 2,67);<br>total de 3 estudos, NR, I²=18%,<br>p=0,78<br>8) RR=0,39 (IC95%: 0,16; 0,96);<br>total de 1 estudo, NR, I<sup>2</sup>=NA,<br>p=0,04<br>9) NR<br>10) NR|5) NR<br>6) NR<br>7) DM=-1,30 kg/m² (IC95%: -<br>2,96; 0,36); total de 1 estudo,<br>NR,I<sup>2</sup>=NA, p=0,12<br>8) DM=2,20 kg/m² (IC95%: 0,64;<br>3,76); total de 1 estudo, NR,<br>I<sup>2</sup>=NA, p=0,006<br>9) NR<br>10) NR|  
|**Autor,**<br>**ano**|**Total de**<br>**estudos na**<br>**comparação**|**Melhora do hirsutismo relatada pelo**<br>**paciente**|**Redução no score Ferriman-**<br>**Gallwey**|**Proporção de pacientes que**<br>**relataram evento adverso**|**Alterações no IMC**|
|---|---|---|---|---|---|
|||I<sup>2</sup>=NA, p<0,001|p<0,001|||
||11) 1|11) RR=1,07 (IC95% 0,79; 1,44); total de<br>1 estudo, NR, I<sup>2</sup>=NA, p=0,68|11) DM=-1,59 (IC95% -2,86; -0,32);<br>total de 1 estudo, NR, I<sup>2</sup>=NA,<br>p=0,01|11) RR=3,00 (IC95%: 0,13;<br>69,31); total de 1 estudo, NR,<br>I<sup>2</sup>=NA, p=0,49|11) DM=0,10 kg/m² (IC95% -<br>1,53; 1,73); total de 1 estudo,<br>NR,I<sup>2</sup>=NA, p=0,90|  
NR: não reportado; DM: diferença de médias; IC95%: intervalo de confiança de 95%; I<sup>2</sup> : estatística de Higgins para heterogeneidade; RR: risco relativo; NA: não se aplica  
**RECOMENDAÇÃO:** Caso haja contraindicação de AHC, recomenda-se associar o antiandrogênico com a metformina, nas pacientes com distúrbios metabólicos. **(GRADE: recomendação condicional a favor; qualidade da evidência: moderada).** O antiandrogênico de escolha é o acetato de ciproterona, pois é o único que apresenta indicação para SOP em bula (54).  
**Questão de Pesquisa 8:** Qual o risco/prevalência de eventos cardiovasculares maiores em mulheres com  
SOP?

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **MEDLINE via Pubmed:** -->
<mark>(((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ("Cardiovascular Diseases"[Mesh] OR Cardiovascular Disease OR major cardiovascular events OR major cardiovascular outcomes))) AND ("Risk Factors"[Mesh] OR risk factor OR prognostic factor)</mark>  
<mark>Total: 842 referências</mark>  
<mark>Data de acesso: 1</mark> 5/05/2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
'ovary polycystic disease'/exp OR 'ovary polycystic disease' AND ('risk factor'/exp OR 'risk factor') AND 'cardiovascular disease'/exp/mj AND [embase]/lim  
<mark>Total: 291 referências</mark>  
<mark>Data de acesso: 1</mark> 5/05/2017

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
A busca nas bases de dados resultou em 1133 referências (842 no MEDLINE e 291 no EMBASE). Destas, 94 estavam duplicadas. Um mil e trinta e nove referências foram triadas pela leitura de título e resumo. Vinte e nove citações tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destes, 15 foram excluídos nessa etapa. Os motivos da exclusão foram: cinco revisões narrativas/cartas ao editor; uma revisão sistemática que calculou a meta-análise considerando desfechos cardiovasculares distintos e que incluiu estudos que não consideraram apenas mulheres com SOP; um estudo foi retirado na base MEDLINE, pois os autores não foram capazes de reproduzir novamente os resultados; dois estudos avaliaram marcadores bioquímicos de risco cardiovascular em vez de eventos clínicos; seis estudos avaliaram o risco de eventos cardiovasculares em mulheres sem a condição SOP de interesse ou incluindo populações com e sem SOP, sem apresentarem os desfechos de acordo com a subpopulação.  
Quatorze citações referentes à 11 estudos foram incluídos (78-85, 87-89, 142-144). Um destes foi localizado por meio de busca manual (143). O estudo que avaliou eventos cardiovasculares em população dinamarquesa foi publicado em três relatos: dois resumos de congresso apresentando desfechos infarto agudo do miocárdio (142) e eventos tromboembólicos (89) enquanto a terceira  
publicação, no formato de artigo completo, apresentou desfecho AVC isquêmico (143). Essas três publicações foram apresentadas separadamente.

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
A descrição sumária dos estudos encontra-se na Tabela 30. As características dos participantes dos estudos encontram-se na Tabela 31. Os dados de risco/prevalência de eventos cardiovasculares encontram-se na Tabela 32. Os estudos foram agrupados de acordo com o desfecho cardiovascular investigado pelo estudo.  
**Tabela  30 – Características dos estudos elegíveis que avaliaram o risco/prevalência de eventos cardiovasculares em população com SOP, agrupados de acordo com o desfecho cardiovascular avaliados.**  
|**Autor ano**|**Desenho do**<br>|**População e objetivo**|**N grupo SOP**|**N grupo controle**|**Critério Diagnóstico**<br>|**Tempo de**<br>|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**,**|**estudo**||||**SOP**|**seguimento**||
|**Iftikhar et**<br>**al. 2012**<br>**(78)**|<br>Estudo<br>observacional<br>de coorte<br>retrospectivo|Avaliar a incidência de<br>eventos<br>cardiovasculares em<br>mulheres com SOP vs<br>controles sem SOP|**Estudosque ava**<br>309 mulheres<br>com SOP entre<br>18-40 anos|**liaram desfechos cardiovascu**<br>343 pacientes sem SOP,<br>pareadas por idade e ano<br>da primeira consulta (e<br>inclusão na base de dados)<br>atendidas na mesma<br>instituição (Olmsted<br>County, US), relação 1:1 a<br>1:3. Não foi possível<br>encontrar controle para<br>115 mulheres com SOP|<br>**lares compostos**<br>Critérios de Rotterdam|<br>Média de 23,7<br>anos. Pacientes<br>foram incluídas<br>1966 e 1988,<br>acompanhadas<br>por pelo menos<br>5 anos, até 2007|Moderado-baixo: grupo<br>controle foi selecionado da<br>mesma população e<br>pareado para variáveis<br>importantes, no entanto, o<br>último seguimento do<br>estudo foi realizado por<br>meio de questionários<br>enviados e menos de 50%<br>dor questionários foram<br>retornados|
|**Mani et al.**<br>**2013 (79)**|Estudo<br>observacional<br>de coorte<br>retrospectivo|Avaliar a prevalência e<br>incidência de DM2 e<br>DCV em mulheres<br>com SOP >16 anos em<br>Leicester,<br>Leicestershire e<br>Rutland, UK|2301 mulheres<br>com SOP|Dados disponíveis do<br>_National Health Survey for_<br>_England_para a população<br>feminina. Tamanho da<br>amostra não reportado|Registro retrospectivo<br>de 2301 mulheres com<br>SOP, diagnosticadas<br>com base em critérios<br>utilizados na época do<br>registro em uma base<br>de dados inglesa (entre<br>1988 e 2009), sendo<br>que 82,6% das<br>pacientes foram<br>diagnosticadas por um<br>endocrinologista sênior|20 anos (12.000<br>pessoas/ano)|Moderado: Não foi descrito<br>como foi a seleção dos<br>controles e se, além da<br>estratificação por idade,<br>houve alguma forma de<br>controle de outras co-<br>variáveis|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**N grupo SOP**|**N grupo controle**|**Critério Diagnóstico**<br>**SOP**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Merz et al.**<br>**2016 (80)**|Estudo<br>observacional<br>de coorte,<br>prospectivo,<br>multicêntrico|Avaliar o risco de DAC<br>angiográfica e<br>mortalidade CV em<br>mulheres com<br>achados clínicos de<br>SOP pós-menopausa|25|270|Auto-relato. Achados<br>clínicos de SOP por<br>critério NIH 1990 e<br>critérios do_European_<br>_Society for Human_<br>_Reproduction_<br>_and Embryology and_<br>_American Society for_<br>_Reproductive_<br>_Medicine_de 2003|9,3 anos<br>(IIQ 8,4 - 10,3)|Moderado: não há como<br>garantir que a população<br>incluída tinha SOP. As<br>estimativas quantitativas<br>das análises ajustadas não<br>foram relatadas; apenas<br>informado que manteve a<br>mesma tendência das<br>análises brutas|
|**Schmidt et**<br>**al. 2011**<br>**(81)**|Estudo<br>observacional<br>de coorte<br>prospectivo|Avaliar a prevalência<br>de eventos CV entre<br>mulheres pós-<br>menopausa com SOP<br>vs controles sem SOP|35 mulheres com<br>SOP|120 controles selecionados<br>aleatoriamente da base de<br>dados do estudo<br>_Gothenburg World Health_<br>_Organization (WHO)_<br>_monitoring of trends and_<br>_determinants for_<br>_cardiovascular disease_<br>(MONICA), e pareadas<br>(relação 1:4) por idade, IMC|Critérios de Rotterdam|Até 21 anos.<br>Estudo iniciou<br>em 1987 e<br>finalizou em<br>2008|Moderado-baixo: grupo<br>controle foi selecionado da<br>mesma população e<br>pareado para variáveis<br>importantes, no entanto,<br>houve perdas de<br>seguimento|
|||||epeso||||
|**Wild et al.**<br>**2000 (82,**<br>**83)**|Estudo<br>observacional<br>de coorte<br>retrospectivo|Avaliar a prevalência<br>de doença<br>cardiovascular em<br>mulheres com SOP|319 mulheres<br>com SOP<br>diagnosticas<br>antes de 1979,<br>registradas em<br>uma base de<br>dados inglesa|1060 controles pareados<br>(relação 1:3) por idade,<br>derivadas do mesmo local<br>de atendimento das<br>mulheres com SOP|Evidência<br>histopatológica, porém<br>9% das pacientes foram<br>diagnosticadas por<br>critérios clínicos apenas|Média 31 meses<br>(mín 15, máx 47<br>anos), 45% das<br>pacientes foram<br>acompanhadas<br>por 30-34 anos|Moderado: Das 1028<br>mulheres com SOP<br>registradas na base de<br>dados, apenas as 319 com<br>dados completos foram<br>incluídas no estudo. O<br>último seguimento foi<br>realizado prospectivamente<br>com as sobreviventes que<br>aceitaram participar das<br>avaliações. Análises|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**N grupo SOP**|**N grupo controle**|**Critério Diagnóstico**<br>**SOP**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
||||||||ajustadas para IMC|  
||||**Estudosque**|**avaliaram desfechos Tromb**|**oembólicos**|||
|---|---|---|---|---|---|---|---|
|**Bird et al.**<br>**2013 (87)**|Estudo<br>observacional<br>de coorte|Avaliar a associação<br>de TEV em mulheres<br>com SOP usuárias ou<br>não de ACO. As<br>análises são<br>representativas da<br>população norte-<br>americana|População SOP +<br>ACO:<br>43.506;<br>População SOP<br>sem ACO: 28.820|População sem SOP + ACO:<br>43.506;<br>População sem SOP:<br>115.152 de uma amostra<br>aleatória de 2 milhões de<br>mulheres|População SOP + ACO:<br>(CID-9-CM)|O período<br>analisado foi de<br>8 anos|Moderado: autores relatam<br>inacurácia diagnóstica de<br>SOP e dados faltantes de<br>variáveis importantes de<br>confundimento|
|**Thranov et**<br>**al. 2014**<br>**(89)**|Estudo<br>observacional<br>de coorte<br>retrospectivo|Avaliar a associação<br>de TEV e SOP, e<br>avaliar a influência da<br>obesidade e o uso de<br>ACO nesta associação.<br>Trata-se de uma<br>análise de coorte<br>histórica nacional<br>dinamarquesa<br>(11.332.675<br>observações-ano),<br>identificando os casos<br>de trombose|54|4.130|NR|Período<br>analisado foi de<br>11 anos|Alto: Não há descrição<br>adequada de critérios<br>diagnósticos de SOP na<br>população; não há<br>descrição adequada de<br>variáveis de base e as<br>análises ajustadas<br>consideraram poucas<br>variáveis confundidoras<br>/modificadoras de efeito|
|||(n=4.184) e destes,<br>participantes com SOP||||||  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**<br>(n=54) e não SOP<br>(n=4.130)|**N grupo SOP**|**N grupo controle**|**Critério Diagnóstico**<br>**SOP**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Okoroh et**<br>**al. 2012**<br>**(88)**<br>**Cibula et**<br>**al. 2000**<br>**(84)**|Estudo<br>observacional<br>transversal<br>Estudo<br>observacional<br>transversal|Avaliar a prevalência<br>de TEV em mulheres<br>com e sem SOP e a<br>associação entre SOP<br>e TEV<br>**Estudos**<br>Avaliar a prevalência<br>DM2, HAS, DAC e<br>fatores de risco<br>relacionados a essas<br>doenças em mulheres<br>na perimenopausa<br>com histórico de<br>tratamento de SOP.<br>As informações foram<br>obtidas por meio da<br>aplicação de um<br>questionário<br>estruturado e visitas<br>prospectivas de coleta|192.936<br>mulheres com<br>SOP<br>**que avaliaram Do**<br>28 mulheres|11.978.894 mulheres sem<br>SOP<br>**ença Arterial Coronariana/ In**<br>752 controles pareados por<br>idade, obtidas de uma<br>amostra aleatória<br>representativa da<br>população Checa|CID-9-CM<br>**farto Agudo do Miocárdio**<br>Mulheres submetidas à<br>ressecção de ovário,<br>que apresentavam<br>oligomenorreia ou<br>amenorreia, hirsutismo,<br>infertilidade<br>anovulatória ou<br>aparência ovariana<br>típica|O período<br>analisado foi de<br>5 anos<br> <br>NR|Baixo risco<br>Alto: Perdas de seguimento<br>significantes no grupo<br>controle, análises não<br>ajustadas, sem acurácia<br>diagnóstica de SOP|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**<br>de dados<br>antropométricos e<br>bioquímicos|**N grupo SOP**|**N grupo controle**|**Critério Diagnóstico**<br>**SOP**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Dahlgren**<br>**et al. 1992**<br>**(85)**|Estudo<br>observacional<br>prospectivo<br>coorte|Avaliar por meio de<br>um modelo de fator<br>de risco (construído<br>por população<br>independente da<br>amostra do estudo)<br>em qual extensão as<br>características<br>hormonais e<br>metabólicas poderiam<br>influenciar na<br>ocorrência de IAM em<br>mulheres com SOP|33 mulheres com<br>SOP|132 mulheres controle,<br>pareadas por idade|Baseado em achados<br>histológicos de<br>morfologia ovariana|NR|Alto: variáveis importantes<br>não foram relatadas, como<br>IMC; as perdas de<br>seguimento foram muito<br>significantes, dados<br>também coletados por<br>auto-relato|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**N grupo SOP**|**N grupo controle**|**Critério Diagnóstico**<br>**SOP**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Lidegaard**<br>**et al. 2016**<br>**(142)**|Estudo<br>observacional<br>de coorte<br>retrospectivo|Avaliar o risco de<br>eventos<br>cardiovasculares em<br>população com SOP e<br>avaliar como a<br>obesidade influencia<br>no risco. Trata-se de<br>uma análise de coorte<br>histórica nacional<br>dinamarquesa|11.332.675<br>pessoas-ano<br>avaliadas, no<br>entanto, não foi<br>descrito número<br>de mulheres com<br>e sem SOP|Vide célula à esquerda|NR|11 anos|Alto: Não há descrição<br>adequada de critérios<br>diagnósticos de SOP na<br>população; não há<br>descrição adequada de<br>variáveis de base e as<br>análises ajustadas<br>consideraram poucas<br>variáveis confundidoras<br>/modificadoras de efeito;<br>resumo de congresso|
||||**Est**|**udoque avaliou AVC isquêmi**|**co**|||
|**Matthesen**<br>**et al. 2015**<br>**(143)**|Estudo<br>observacional<br>de coorte<br>retrospectivo|Avaliar risco de AVC<br>isquêmico em<br>mulheres em idade<br>fértil com SOP, e<br>avaliar a influência de<br>obesidade e<br>contraceptivos<br>hormonais no risco.<br>Foram incluídas<br>mulheres<br>dinamarquesas<br>registradas na base de<br>dados entre 2001 e<br>2012. Foram excluídas<br>mulheres com DCV,<br>câncer, trombofilia,<br>com histerectomia ou<br>ooforectomiaprévias|9.640 mulheres<br>com SOP e<br>ausência de<br>critérios de<br>exclusão,<br>totalizando<br>90.038<br>pessoas/ano|1.429.907 mulheres<br>dinamarquesas registradas<br>na base de dados, sem SOP,<br>e ausência de critérios de<br>exclusão, totalizando<br>11.242.637 pessoas/ano|NR. Mulheres foram<br>identificadas na base de<br>dados por meio de<br>busca pelo CID|O período<br>analisado foi de<br>11 anos|Moderado: Dados<br>coletados de base de dados<br>nacional|
||||**Estudoq**|**ue avaliou mortalidade cardio**|**vascular**|||  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**N grupo SOP**|**N grupo controle**|**Critério Diagnóstico**<br>**SOP**|**Tempo de**<br>**seguimento**|**Risco de viés**|
|---|---|---|---|---|---|---|---|
|**Pierpoint**<br>**et al. 1998**<br>**(144)**|Estudo<br>observacional<br>de coorte<br>retrospectiva|Avaliar a relação de<br>SOP em mulheres<br>jovens e mortalidade<br>CV em idade mais<br>avançada|1028, sendo 641<br>com diagnóstico<br>definitivo de SOP<br>e 387 com<br>diagnóstico<br>possível de SOP.<br>Foram incluídas<br>nas análises 786|NA|Evidência de SOP<br>histológica,<br>macroscópica e clínica|NR|Alto: Sem relato de<br>variáveis confundidoras/<br>modificadoras de efeito,<br>dados retrospectivos de<br>seguimento longo, perdas<br>de seguimento significantes|  
<u>participantes</u>  
SOP: Síndrome dos ovários policísticos; CV: cardiovascular; DCV: doenças cardiovasculares; AVC: acidente vascular cerebral; ACO: anticoncepcionais orais; TEV: tromboembolismo venoso; CID: classificação internacional de doenças; DAC: doença arterial coronariana; CV: cardiovascular; IIQ: intervalo interquartil; DM2: diabetes mellitus tipo 2; HAS: hipertensão arterial sistêmica; NR: não reportado; NA: não se aplica.  
**Tabela 31 – Características dos participantes nos estudos elegíveis que avaliaram o risco/prevalência de eventos cardiovasculares em população com SOP, agrupados de acordo com o desfecho cardiovascular avaliados.**  
|**Autor, ano**<br>**Iftikhar et al.**<br>**2012 (78)**|**Idade, anos**<br>**grupo SOP**<br>Final: 44,4<br>(12,9),<br>n=309|**Idade, anos**<br>**grupo controle**<br>Final: 48,8<br>(10,2), n=343|**Triglicérides**<br>**(mg/dL)**<br>**grupo SOP**<br>**Estudosque av**<br>Final: Mediana<br>(min-max): 107<br>(29–473), n= 193|**Triglicérides**<br>**(mg/dL) grupo**<br>**controle**<br>**aliaram desfechos c**<br>Final: Mediana<br>(min-max): 110<br>(33–431), n= 285|**Glicemia**<br>**(mg/dL)**<br>**grupo SOP**<br>**ardiovasculare**<br>Final:<br>Mediana<br>(min-max):<br>94 (39–338),<br>n=179|**Glicemia**<br>**(mg/dL)**<br>**grupo**<br>**controle**<br>**s compostos**<br>Final:<br>Mediana<br>(min-max):<br>94 (68–208),<br>n=276|**IMC**<br>**(kg/m**<sup>**2**</sup>**)**<br>**grupo SOP**<br>Final: 29,4<br>(7,77),<br>n=228|**IMC**<br>**(kg/m**<sup>**2**</sup>**)**<br>**grupo**<br>**controle**<br>Final: 28,3<br>(7,47),<br>n=291|**PA (mmHg)**<br>**grupo SOP**<br>NR|<br>**PA (mmHg)**<br>**grupo**<br>**controle**<br>NR|
|---|---|---|---|---|---|---|---|---|---|---|
|**Mani et al.**<br>**2013 (79)**|Início: 29,6<br>(9,1)<br>Final: 36,3<br>(10,0), mínimo<br>16 e máximo 79|NR|NR|NR|NR|NR|Final: 30,1<br>(7,6),<br>n=1563|NR|Final:<br>PAS: 130,5<br>(15,7)<br>PAD: 73,7<br>(11,1)<br>n=984|NR|  
|**Autor, ano**|**Idade, anos**<br>**grupo SOP**|**Idade, anos**<br>**grupo controle**|**Triglicérides**<br>**(mg/dL)**<br>**grupo SOP**|**Triglicérides**<br>**(mg/dL) grupo**<br>**controle**|**Glicemia**<br>**(mg/dL)**<br>**grupo SOP**|**Glicemia**<br>**(mg/dL)**<br>**grupo**<br>**controle**|**IMC**<br>**(kg/m**<sup>**2**</sup>**)**<br>**grupo SOP**|**IMC**<br>**(kg/m**<sup>**2**</sup>**)**<br>**grupo**<br>**controle**|**PA (mmHg)**<br>**grupo SOP**|<br>**PA (mmHg)**<br>**grupo**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|
||62,6 (11,6)|64,8 (9,6)|||||||PAS: 141,4|PAS: 140,4|
|**Merz et al.**<br>**2016 (80)**|Idade na<br>menopausa:<br>41,1(10,4)|Idade na<br>menopausa:<br>46,2(7,0)|198,7 (136,5)|148,7 (88,5)|109,78 (46,5)|121,4 (60,5)|28,7 (5,9)|30,0 (6,7)|(19,9)<br>PAD: 75,4<br>(12,5)|(21,6)<br>PAD: 76,7<br>(10,9)|
|**Schmidt et al.**<br>**2011 (81)**|Início: mínimo<br>40, máximo 59<br>Final: 70,4<br>(5,0), n=25|Início: mínimo<br>40, máximo 59<br>Final: 70,7 (5,6),<br>n=68|Início: 1,4 (0,7)<br>mmol/L<br>Final: 1,7 (0,9)<br>mmol/L, n=25|Início: 1,0 (0,5)<br>mmol/L<br>Final: 1,3 (0,5)<br>mmol/L, n=68|Início: 5,9<br>(1,3) mmol/L,<br>n=25|Final: 5,6<br>(1,1) mmol/L,<br>n=68|Final: 27,1<br>(5,0), n=25|Final: 26,4<br>(4,8), n=68|Início:<br>PAS: 139,4<br>(20,2)<br>PAD: 82,7<br>(10,6)<br>Final:<br>PAS: 146,9<br>(20,6)<br>PAD: 87,4<br>(13,6)|Início:<br>PAS: 123,1<br>(14,9)<br>PAD: 79,1<br>(6,6)<br>Final:<br>PAS: 144,0<br>(19,9)<br>PAD:  81,3<br>(12,8)|
|**Wild et al.**<br>**2000 (82, 83)**|Final da<br>observação:<br>56,7 (mín 38,<br>máx 98)|NR, porém<br>controles foram<br>pareados por<br>idade|Final: 1,4 (NR)<br>mmol/L|Final: 1,1 (NR)<br>mmol/L|Final: 5,4<br>(NR) mmol/L|Final: 5,3<br>(NR) mmol/L|27,1 (NR)|26,2 (NR)|Final:<br>PAS: 132<br>(NR)<br>PAD: 79<br>(NR)|Final:<br>PAS: 132<br>(NR)<br>PAD: 82<br>(NR)|
||||**Estudosq**|**ue avaliaram desfe**|**chos Tromboem**|**bólicos**|||||
||População SOP<br>+ ACO: 28,7|População sem<br>SOP + ACO: 28,9|||||||||
|**Bird et al.**<br>**2013 (87)**|(NR)<br>População SOP<br>sem uso de<br>ACO: 30,4(NR)|(NR)<br>População sem<br>SOP sem uso de<br>ACO: 30,4(NR)|NR|NR|NR|NR|NR|NR|NR|NR|
|**Thranov et**<br>**al. 2014 (89)**|Mínimo15,<br>máximo 49|Mínimo15,<br>máximo 49|NR|NR|NR|NR|NR|NR|NR|NR|  
|**Autor, ano**|**Idade, anos**<br>**grupo SOP**|**Idade, anos**<br>**grupo controle**|**Triglicérides**<br>**(mg/dL)**<br>**grupo SOP**|**Triglicérides**<br>**(mg/dL) grupo**<br>**controle**|**Glicemia**<br>**(mg/dL)**<br>**grupo SOP**|**Glicemia**<br>**(mg/dL)**<br>**grupo**<br>**controle**|**IMC**<br>**(kg/m**<sup>**2**</sup>**)**<br>**grupo SOP**|**IMC**<br>**(kg/m**<sup>**2**</sup>**)**<br>**grupo**<br>**controle**|**PA (mmHg)**<br>**grupo SOP**|<br>**PA (mmHg)**<br>**grupo**<br>**controle**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Okoroh et al.**<br>**2012 (88)**|Mínimo 18,<br>máximo 45|Mínimo 18,<br>máximo 45|NR|NR|NR|NR|NR|NR|NR|NR|
|||**Estu**|**dosque avaliaram D**|**oença Arterial Coron**|**ariana/ Infarto**|**Agudo do Mi**|**ocárdio**||||
||||||||||PAS: 132,1|PAS: 129,2|
|**Cibula et al.**<br>**2000 (84)**|51,9 (4,64)|51,0 (4,21)|1,5 (0,63) mmol/L|1,6 (0,93) mmol/L|6,1 (1,94)<br>mmol/L|5,8 (1,39)<br>mmol/L|28,0 (4,21)|28,2 (5,42)|(23,1)<br>PAD: 79,9<br>(10,91)|(17,76)<br>PAD: 81,9<br>(9,8)|
|**Dahlgren et**<br>**al. 1992 (85)**|40-49 anos:<br>45,9 (2,5)<br>50-61 anos:<br>55,1(2,6)|40-49 anos:<br>46,5 (2,2)<br>50-61 anos:<br>55,6(3,1)|40-49 anos: 1,16<br>(0,58) mmol/L<br>50-61 anos: 1,58<br>(0,92)mmol/L|40-49 anos: 1,21<br>(0,52) mmol/L<br>50-61 anos: 1,35<br>(0,61)mmol/L|NR|NR|NR|NR|NR|NR|
|**Lidegaard et**<br>**al. 2016 (142)**|Mínimo 15,<br>máximo 49|Mínimo 15,<br>máximo 49|NR|NR|NR|NR|NR|NR|NR|NR|
||||**E**|**studoque avaliou A**|**VC isquêmico**||||||
|**Matthesen et**<br>**al. 2015 (143)**|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
||||**Estudo**|**que avaliou mortalid**|**ade cardiovasc**|**ular**|||||
|**Pierpoint et**<br>**al. 1998(144)**|NR|NA|NR|NA|NR|NA|NR|NA|NR|NA|  
SOP: Síndrome dos ovários policísticos; IMC: índice de massa corporal; PA: pressão arterial; NR: não reportado; PAS: pressão arterial sistólica; PAD: pressão arterial diastólica; n: núero de pacientes analisados; ACO: anticoncepcionais orais. Início: valores registrados no início da observação de pacientes. Final: valores registrados no final da observação de pacientes. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
**Tabela 32 – Riscos/Prevalência de eventos cardiovasculares nos estudos elegíveis que avaliaram o risco/prevalência de eventos cardiovasculares em população com SOP, agrupados de acordo com o desfecho cardiovascular avaliados.**  
|**Autor ano**|**Eventos**|**Eventos Cardiovasculares**||**Medida de associação grupo SOP****_versus_ grupo controle**||
|---|---|---|---|---|---|
|**,**|**Cardiovasculares grupo**<br>|<br>**grupo controle n/N (%)**|**p para comparação**|<br>**OR, RR, HR (IC 95%)**|**p para comparação**|
||**SOP n/N (%)**<br>IAM: 15/309 (4,9)|**Estudosqu**|**e avaliaram desfechos ca**|**rdiovasculares compostos**||
|**Iftikhar et**<br>**al. 2012**<br>**(78)**|Angina Instável: 10/309<br>(3,2)<br>AVC: 6/309 (1,9)<br>Cirurgia de RM:  7/309<br>(2,3)<br>≥1 evento CV: 26/309<br>(8,4)<br>Mortalidade total:<br>11/309 (3,6)<br>Mortalidade CV: 4/309<br>(1,3)|IAM: 16/343 (4,7)<br>Angina Instável: 6/343 (1,8)<br>AVC: 7/343 (2,0)<br>Cirurgia de RM: 5/343 (1,5)<br>≥1 evento CV: 28/343 (8,2)<br>Mortalidade total: 8/343<br>(2,3)<br>Mortalidade CV: 2/343(0,6)|IAM: p=0,58<br>Angina Instável: p=0,49<br>AVC: p=0,61<br>Cirurgia de RM: p=0,99<br>≥1 evento CV: p=0,62<br>Mortalidade total:<br>p=0,76<br>Mortalidade CV:<br>p=0,61|HR ajustado para idade no último seguimento, IMC,<br>tratamento para infertilidade, TRH, história familiar de<br>HAS:<br>IAM: 0,74 (0,32–1,72)<br>Angina instável: 1,32 (0,42–4,13)<br>AVC: 1,05 (0,28–3,92)<br>Cirurgia de RM: 1,52 (0,42–5,48)<br>≥1 evento CV: 0,82 (0,44–1,54)<br>Mortalidade total: 1,03 (0,29–3,71)<br>Mortalidade CV: 5,67 (0,51–63,7)|IAM: p=0,48<br>Angina instável: p=0,63<br>AVC: p=0,94<br>Cirurgia de RM: p=0,52<br>≥1 evento CV: p=0,54<br>Mortalidade total:<br>p=0,96<br>Mortalidade CV: p=0,16|
||Após seguimento médio<br>de 34,5 (11,1) anos:<br>Eventos CV (combinado|||**OR para eventos CV no grupo SOP,**<br>**por fator de risco adicional:**<br>HAS (sim vs não): 22,59 (10,49 - 48,68)|OR para eventos CV no<br>grupo SOP<br>HAS: p<0,01|
||de IAM, angina, IC, AVC e<br>mortalidade CV):|||Idade (aumento de OR / ano adicional): 1,13 (1,09 - 1,17)<br>Obesidade (vs peso normal): 10,80 (1,45 - 80,42)|Idade: p<0,01<br>Obesidade: p=0,02|
||31/2301 (1,3)|||Excesso de andrógenos (sim vs não): 0,58 (0,23 - 1,43)|Excesso de andrógenos:|
|**Mi  l**|AVC: 1/2301|||Anovulação (sim vs não): 0,32 (0,16 - 0,67)|p=0,23|
|**an et a.**<br>**2013 (79)**|IAM: 16/2301<br>IC: 5/2301|NA|NA|Tabagismo (sim vs não): 3,11 (1,45 - 6,67)<br>DM (sim vs não): 6,62 (3,12 - 14,05)|Anovulação: p<0,01<br>Tabagismo: p<0,01|
||Angina: 22/2301|||IMC (aumento de OR por unidade): 1,00 (0,97 - 1,02)|DM: p<0,01|
||Mortalidade CV: 5/2301|||**OR para eventos CV no grupo SOP vs população local,**|IMC: p=0,89|
||Incidência por pessoa-|||**estratificado por idade:**|OR para eventos CV no|
||ano:|||IAM:|grupo SOP vs população|
||IAM: 0,83(0,40 - 1,52)|||<44: 2,82(0,38 - 20,53)|local estratificadopor|  
|**Autor, ano**|**Eventos**<br>**Cardiovasculares grupo**<br>**SOP n/N (%)**|**Eventos Cardiovasculares**<br>**grupo controle n/N (%)**|**p para comparação**|**Medida de associação grupo SOP****_versus_ grupo controle**<br>**OR, RR, HR (IC 95%)**|**p para comparação**|
|---|---|---|---|---|---|
||Angina: 1,00 (0,51 - 1,74)<br>IC: 0,25 (0,05 - 0,72)<br>AVC: 0<br>Mortalidade CV:<br>0,41 (0,13 - 0,96)|||45-54: 10,63 (4,93 - 22,90)<br>55-64: 9,27 (3,73 - 23,03)<br><65: 12,88 (3,41 - 48,58)<br>Angina:<br><44: 4,32 (1,76 - 10,57)<br>45-54: 3,29 (1,69 - 6,41)<br>55-64: 2,56 (1,03 - 6,34)<br><65: 4,07 (1,08 - 15,37)<br>Evento CV composto:<br><44: 2,04 (1,05 - 3,96)<br>45-54: 2,95 (1,81 - 4,83)<br>55-64: 3,09 (1,64 - 5,84)<br><65: 6,31(1,84 - 21,56)|idade: NR|
|**Merz et al.**<br>**2016 (80)**|DAC: 42%<br>Mortalidade: 28%<br>Mortalidade CV: 20%<br>Desfecho combinado de<br>IAM e mortalidade CV:<br>6/25 (24)<br>Desfecho combinado de<br>IAM, evento<br>cerebrovascular e<br>mortalidade CV:6/25<br>(24)|DAC: 27%<br>Mortalidade: 27%<br>Mortalidade CV: 17%<br>Desfecho combinado de<br>IAM e mortalidade CV:<br>56/270 (21)<br>Desfecho combinado de<br>IAM, evento<br>cerebrovascular e<br>mortalidade CV:67/270 (25)|DAC: p=0,07<br>Mortalidade: p=0,849<br>Mortalidade CV:<br>p=0,74<br>Combinado IAM e<br>mortalidade CV: p=0,51<br>Combinado IAM,<br>cerebrovascular e<br>mortalidade CV: p=0,85|Mortalidade total: HR 1,03 (0,57–1,86)<br>Mortalidade CV: HR 0,82 (0,37–1,81)|Mortalidade total:<br>p=0,93<br>Mortalidade CV: p =<br>0,62|
||Hospitalização por IAM:<br>3/32 (9,4)|Hospitalização por IAM:<br>7/95 (7,4)|Hospitalização por<br>IAM: p=0,712|||
|**Schmidt et**|Hospitalização por AVC:|Hospitalização por AVC:|Hospitalização por|||
|**al. 2011**<br>**(81)**|6/32 (18,8)<br>IAM ou AVC: 9/32 (28,1)<br>Mortalidade total: 3/32<br>(9,4)|10/95 (10,5)<br>IAM ou AVC: 16/95 (16,8)<br>Mortalidade total:<br>14/9(14,7)|AVC: p=231<br>IAM ou AVC: p=0,2<br>Mortalidade total:<br>p=0,558|NR|NA|  
|**Autor, ano**|**Eventos**<br>**Cardiovasculares grupo**<br>**SOP n/N (%)**|**Eventos Cardiovasculares**<br>**grupo controle n/N (%)**|**p para comparação**|**Medida de associação grupo SOP****_versus_ grupo controle**<br>**OR, RR, HR (IC 95%)**|**p para comparação**|
|---|---|---|---|---|---|
||Mortalidade CV: 2/32<br>(6,2)|Mortalidade CV: 4/95 (4,2)|Mortalidade CV: p=NR|||
||Mortalidade total: 70<br>Mortalidade CV: 17<br>DAC: 15/319 (4,7)<br>AVC/AIT: 20/319 (3,1)|DAC: 42/1060 (4,0)<br>AVC/AIT: 13/1060 (1,2)<br>DAC ou AVC/AIT: 53/1060<br>(50)|Mortalidade: NR<br>DAC: p=0,6<br>AVC/AIT: p=0,02<br>DAC ou AVC/AIT:|OR bruto:<br>DAC: OR 1,5 (0,7 - 2,9)<br>AVC/AIT: OR 2,8 (1,1 - 7,1)<br>DAC ou AVC/AIT: OR 1,9 (1,1 - 3,3)|OR bruto:<br>DAC: p=0,3<br>AVC/AIT: p=0,03<br>DAC ou AVC/AIT:|
|**Wild et al.**<br>**2000 (82,**|DAC ou AVC/AIT: 24/319<br>(7,5)||p=0,09|OR ajustado para IMC:|p=0,03|
|**83)**||||DAC: OR 1,2 (0,5 - 2,6)<br>AVC/AIT: OR 3,4 (1,2 - 9,6)<br>DAC ou AVC/AIT: OR 1,7 (0,9 - 3,2)|OR ajustado para IMC:<br>DAC: p=0,7<br>AVC/AIT: p=0,02<br>DAC ou AVC/AIT:<br>p=0,09|
|||**Estud**|**osque avaliaram desfech**|**os Tromboembólicos**||
|**Bird et al.**|TEV População SOP +<br>ACO: 23,7/10.000<br>pessoas-ano|TEV População sem SOP +<br>ACO: 10,9/10.000 pessoas-<br>ano|NR|TEV População SOP + ACO versus sem SOP + ACO:<br>HR: 2,14 (1,41–3,24)|Pop SOP +ACO<br>HR: p< 0,05<br>RR ajustado: p<0,05|
|**2013 (87)**|TEV População SOP sem<br>uso ACO: 6,3/10.000<br>pessoas-ano|TEV População sem SOP e<br>sem uso de ACO:<br>4,1/10.000 pessoas-ano|NR|TEV População SOP sem uso ACO versus população sem<br>SOP e sem uso de ACO:<br>HR: 1,55 (1,10–2,19)|Pop SOP sem ACO:<br>HR: p< 0,05<br>RR ajustado:p<0,05|
|**Thranov et**<br>**al. 2014**<br>**(89)**|NR|NR|NA|RR para TEV ajustado para uso de ACO: 1,9 (1,5-2,5)<br>RR para TEV ajustado para uso de ACO + IMC:<br>1,4 (0,8-2,3)|RR ajustado para uso de<br>ACO: p<0,05<br>RR ajustado para uso de<br>ACO + IMC:p>0,05|  
|**Autor, ano**|**Eventos**<br>**Cardiovasculares grupo**<br>**SOP n/N (%)**|**Eventos Cardiovasculares**<br>**grupo controle n/N (%)**|**p para comparação**|**Medida de associação grupo SOP****_versus_ grupo controle**<br>**OR, RR, HR (IC 95%)**|**p para comparação**|
|---|---|---|---|---|---|
|||||Associação entre SOP e TEV estratificado por idade<br>(referência: população sem SOP):<br>18–24: OR ajust por gravidez, ACO, região, diabetes e<br>obesidade: 3,26 (2,61–4,08)<br>25–34:  OR ajust por gravidez, ACO, região, diabetes e<br>obesidade: 2,39 (2,12–2,70)<br>35–45: OR ajust por gravidez, ACO, região, diabetes e<br>obesidade: 2,05 (1,84–2,28)|18-24: p< 0,05<br>25-34: p<0,05<br>35-45: p<0,05|
|**Okoroh et**<br>**al. 2012**<br>**(88)**|Prevalência de TEV:<br>374,2 por 100.000<br>Frequência de TEV:<br>NR/NR (0,37)<br>Frequência de TEV<br>estratificado por<br>obesidade: NR/NR (0,6)|Prevalência de TEV: 193,8<br>por 100.000<br>Frequência de TEV: NR/NR<br>(0,19)<br>Frequência de TEV<br>estratificado por<br>obesidade: NR/NR (1,3)|NR<br>p< 0,0001<br>p< 0,0001|Associação entre SOP + ACO e TEV estratificado por<br>idade:<br>18–24: OR ajust por gravidez, região, diabetes e<br>obesidade: 2,89 (2,17–3,85)<br>25–34:  OR ajust por gravidez, região, diabetes e<br>obesidade: 1,98 (1,66–2,37)<br>35–45: OR ajust por gravidez, região, diabetes e<br>obesidade: 1,79 (1,51–2,12)|18-24: p<0,05<br>25-34: p<0,05<br>35-45: p<0,05|
|||||Associação entre SOP sem ACO e TEV estratificado por<br>idade:<br>18–24: OR ajust por gravidez, região, diabetes e<br>obesidade: 3,76 (2,63–5,38)<br>25–34:  OR ajust por gravidez, região, diabetes e<br>obesidade:2,70 (2,29–3,18)<br>35–45: OR ajust por gravidez, região, diabetes e<br>obesidade: 2,18(1,90–2,50)|18-24: p<0,05<br>25-34: p<0,05<br>35-45: p<0,05|
|||**Estudosque avaliara**|**m Doença Arterial Coron**|**ariana/ Infarto Agudo do Miocárdio**||
|**Cibula et**||||||
|**al. 2000**<br>**(84)**|DAC: 6/28 (21)|DAC: 38/752 (5)|DAC: p<0,001|NR|NA|  
|**Autor ano**|**Eventos**|**Eventos Cardiovasculares**||**Medida de associação grupo SOP****_versus_ grupo controle**||
|---|---|---|---|---|---|
|**,**|**Cardiovasculares grupo**<br>**SOP n/N (%)**|<br>**grupo controle n/N (%)**|**p para comparação**|<br>**OR, RR, HR (IC 95%)**|**p para comparação**|
|**Dahlgren**||||IAM: RR 7,4 (NR)||
|**et al. 1992**<br>**(85)**|NR|NR|NA|Estratificado por idade:<br>40-49 anos: RR= 4,2 (1,0-8,8)<br>50-61 anos: RR= 11,0(IC 95% 1,2-32,6)|p=0,05<br>p< 0,05|
|**Lidegaard**<br>**et al. 2016**<br>**(142)**|NR|NR|NA|IAM: RR ajustado para idade, educação, uso ACO, IMC:<br>1,9 (1,1–3,2)|p<0,05|
||||**Estudoque avaliou A**|**VC isquêmico**||
|||||RR bruto: 2,18 (NR)||
|**Matthesen**||||RR ajustado para idade, ano do evento (2001-2012),|p estatisticamente|
|**et al. 2015**<br>**(143)**|AVC: 25|AVC: 2004|NR|escolaridade e ACO: 2,16 (1,46-3,21)<br>RR ajustado para os fatores anteriores + IMC: 2,15 (1,45 -<br>3,20)|significativo para todas<br>as comparações|
||||**Estudoque avaliou**|**mortalidade**||
||Mortalidade total:<br>Observada: 59/78 (7,5)<br>Esperada: 65,3|||Mortalidade total<br>RMP: 0,90 (0,69–1,17)||
|**Pierpoint**|Mortalidade CV:|||Mortalidade CV:||
|**et al. 1998**<br>**(144)**|Observada: 15<br>Esperada: 18,1<br>Mortalidade por câncer:<br>Observada: 27|NA|NA|RMP: 0,83 (0,46–1,37)<br>Mortalidade por câncer:<br>RMP: 0,91 (0,60–1,32)|NR|
||Esperada: 29,7|||||  
SOP: síndrome dos ovários policísticos; n: número de pacientes com evento; N: número de pacientes observado; OR: odds ratio (razão de chances); RR: risco relativo HR: hazard ratio; IC 95%: intervalo de confiança de 95%; IAM: infarto agudo do miocárdio; AVC: acidente vascular cerebral; RM: revascularização do miocárdio; CV: cardiovascular; IMC: índice de massa corporal; TRH: terapia de reposição hormonal; HAS: hipertensão arterial sistêmica; IC: insuficiência cardíaca; NA: não se aplica; NR: não reportado; DM: diabetes mellitus; DAC: doença arterial Coronariana; AIT: ataque isquêmico transitório; TEV: tromboembolismo venoso; ACO: anticoncepcional oral; RMP: razão de mortalidade padronizada, definida como número de eventos observados sobre número de eventos esperados.  
**Questão de Pesquisa 9:** Qual a eficácia e segurança da cirurgia bariátrica para o tratamento de  
comorbidades metabólicas (e infertilidade) associadas à PCOS?

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
<mark>(("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ("Bariatric Surgery"[Mesh] OR Bariatric Surgery Bariatric Surgical Procedure OR Metabolic Surgery OR Roux-en-Y gastric bypass)</mark>  
<mark>Total: 160 referências</mark>  
<mark>Data acesso: 13/05/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
<mark>'ovary polycystic disease'/exp OR 'ovary polycystic disease' AND [embase]/lim AND ('bariatric surgery'/exp OR 'bariatric surgery' AND [embase]/lim OR ('roux en y gastric bypass surgery' OR 'roux en y bypass' AND [embase]/lim))</mark>  
<mark>Total: 280 citações</mark>  
<mark>Data de acesso: 15/05/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca nas bases de dados resultou em 440 referências (160 no MEDLINE e 280 no EMBASE). Destas, 59 estavam duplicadas. Trezentas e oitenta e uma referências foram triadas pela leitura de título e resumo. Vinte e sete referências tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destes, 15 foram excluídos. Três estudos foram excluídos por serem revisões narrativas. Duas revisões sistemáticas foram excluídas: uma das revisões não realizou meta-análise não foi considerada, pois se preferiu reportar os dados dos estudos elegíveis primários. A segunda revisão</mark> avaliou a prevalência de SOP pré e pós-cirurgia (além de outros desfechos) em 2130 mulheres, das quais apenas 383 apresentavam SOP na avaliação pré-operatória. Os desfechos foram apresentados para a população total de 2130 pacientes, não estratificados para o subgrupo de interesse desta questão. Um estudo primário apenas avaliou a prevalência de SOP antes e pós-cirurgia bariátrica. Nove estudos primários foram excluídos por não apresentarem desfechos para a subpopulação de pacientes com SOP ou não incluíram pacientes com esta condição de saúde.  
<mark>Ao final, 12 estudos referentes a 11 estudos foram incluídos (145-156), sendo dois resumos de congresso (145, 149).</mark>  
**3)** **<mark>Descrição dos estudos e seus resultados</mark>**  
<mark>A Tabela 33 apresenta as c</mark> aracterísticas dos estudos comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP enquanto a Tabela 34 apresenta as c <mark>aracterísticas dos pacientes incluídos nesses estudos. A Tabela 35 apresenta os de</mark> sfechos reportados nos estudos comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP.  
A Tabela 36 apresenta as características dos pacientes e estudos não comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP enquanto a Tabela 37 reporta os desfechos apresentados nos estudos não comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP.  
**Tabela 33 – Características dos estudos comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP.**  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**Intervenção**|**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|
|**Menon et**<br>**al. 2012**<br>**(145)**|Estudo observacional<br>caso-controle|Avaliar a eficácia da cirurgia de bypass<br>gástrico laparoscópico na perda de excesso<br>de peso em mulheres com SOP pareadas<br>com controles sem SOP (1:2) por idade,<br>IMC,diabetes e tempo desde a cirurgia|Y-de-Roux em<br>pacientes com<br>SOP|Y-de-Roux em pacientes sem SOP|Alto: análise retrospectiva de<br>dados, ausência de informações<br>de base importantes para<br>interpretação dos achados|
|**Wang et al.**<br>**2015 (146)**|Estudo comparativo não<br>randomizado|Comparar cirurgia bariátrica (gastrectomia<br>sleeve) vs mudanças de estilo de vida em<br>desfechos clínicos em pacientes com SOP|Gastrectomia<br>Sleeve<br>laparoscópica|Mudanças de estilo de vida, sendo<br>dieta de baixa caloria, exercícios (150<br>min por semana, dos quais 90 min<br>aeróbicos) e terapia comportamental<br>compsiquiatras e familiares|Moderado: apesar dos dados de<br>base aparentarem ser similares,<br>não há relato dos valores de p e<br>não foram realizadas análises<br>ajustadas|  
SOP: síndrome do ovário policístico; IMC: índice de massa corpórea.  
**Tabela 34 – Características dos pacientes incluídos nos estudos comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP.**  
|**Autor, ano**|**N**<br>**Intervençã**<br>**o**|**N**<br>**Control**<br>**e**|**Idade**<br>**Intervençã**<br>**o**|**Idade**<br>**Control**<br>**e**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**ou peso (kg)**<br>**Intervenção**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**ou peso (kg)**<br>**Controle**|**Sinais SOP**<br>**Intervenção**|**Sinais SOP**<br>**Controle**|**Tempo de**<br>**seguimento**|<br>**Perda de**<br>**seguimento**<br>**Intervençã**<br>**o**|**Perda de**<br>**seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|**Menon et**<br>**al. 2012**<br>**(145)**|35|70|37,5 (NR)|37,7<br>(NR)|IMC: 48,7 (NR)|IMC: 47,2<br>(NR)|NR|NR|Casos: 23<br>meses<br>Controles:<br>25 meses|0|0|
||||||IMC: 35,2|IMC: 32,6|Hiperandrogenism<br>o: 15/24 (62,5)<br>Razão LH/FSH>2:|Hiperandrogenism<br>o: 14/24 (58,3)<br>Razão LH/FSH>2:||||
|**Wang et al.**<br>**2015 (146)**|24|24|25,5<br>(22–35)|26,5<br>(20–41)|(29–45,7)<br>Peso: 99,8<br>(86-140)|(28,4–41)<br>Peso: 89,7<br>(74-120)|13/14 (54,2)<br>Ovário policístico<br>por US: 16/24<br>(66,7)<br>Oligomenorreia:|10/24 (41,7)<br>Ovário policístico<br>por US: 15/24<br>(62,5)<br>Oligomenorreia:|12 meses|0|5/24 (21)|  
24/24 (100) 24/24 (100)  
N: tamanho de amostra no grupo; IMC: índice de massa corpórea; SOP: síndrome do ovário policístico; LH: hormônio luteinizante; FSH: hormônio folículo-estimulante; US: ultrassonografia; NR: não reportado. Quando não especificado, dados foram apresentados como média (valor mínimo – máximo) ou n/N (%).  
**Tabela 35 – Desfechos apresentados nos estudos comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP.**  
|**Autor, ano**|**Composição**<br>**corporal**<br>**Intervenção**|**Composição**<br>**corporal**<br>**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Comorbidades**<br>**hormonais**<br>**Intervenção**|**Comorbidades**<br>**hormonais**<br>**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Composição c**<br>**intra-gru**<br>**Pré-operatório**|**orporal e insulinemia**<br>**po Intervenção**<br>**Pós-operatório**|**Valor de p**<br>**intra-**<br>**grupo**|
|---|---|---|---|---|---|---|---|---|---|
|**Menon et**<br>**al. 2012**<br>**(145)**|Perda de excesso<br>de peso:<br>3 meses: 24%<br>6 meses: 46%<br>12 meses: 66%<br>18 meses: 67%|Perda de excesso<br>de peso:<br>3 meses: 28%<br>6 meses: 48%<br>12 meses: 67%<br>18 meses: 73%|p=0,2<br>p=0,9<br>p=0,5<br>p=0,2|NR|NR|NA|NR|NR|NA|
||||||||Peso (kg):|Peso (kg):<br>1 mês pós: 92,4 ± 23,0||
|||Perda de peso||Melhora|||99,8 ± 22,4|3 meses pós: 84,1 ±||
||Perda de peso<br>(kg):<br>3 meses:15,7 ±<br>22,3|(kg):<br>3 meses: 4,1 ±<br>9,7<br>6 meses: 6,4 ±||hirsutismo:<br>3 meses: 12/24<br>(50)<br>6 meses: 14/24|Melhora<br>hirsutismo:<br>3 meses: 1/24 (4,2)<br>6  3/24|||21,8<br>6 meses pós: 77,8 ±<br>16,8<br>12 meses pós: 93,3 ±||
|**Wang et al.**<br>**2015 (146)**|6 meses: 22,1 ±<br>16,8|8,9|p= 0,0001<br>para todas<br>as|(58)|meses:<br>(12,5)|NR|IMC (kg/m<sup>2</sup>):<br>35,2|7,3<br>Redução de IMC|NR|
||Redução de IMC<br>(kg/m<sup>2</sup>):<br>3 meses: 5,3 ± 1,5<br>6 meses: 7,8 ± 2,9|Redução de IMC<br>(kg/m<sup>2</sup>):<br>3 meses: 1,1 ±<br>0,9<br>6 meses: 2,2 ±<br>2,1|comparaçõ<br>es|Normalização da<br>menstruação:<br>3 meses: 20/24<br>(83)<br>6 meses: 21/24<br>(87,5)|Normalização da<br>menstruação:<br>3 meses: 1/24 (4,2)<br>6 meses: 8/24 (33)||Insulinemia<br>(n=3):<br>31,3 µU/mL|(kg/m<sup>2</sup>):<br>1 mês: 2,7 ± 0,7<br>3 meses: 5,3 ± 1,5<br>6 meses: 7,8 ± 2,9<br>12 meses: 9,8 ± 5,2<br>Insulinemia (n=3):<br>16,7 lµU/mL||  
IMC: índice de massa corpórea; NR: não reportado; NA: não se aplica. Quando não especificado, dados foram apresentados como média ± desvio padrão ou n/N (%).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **Tabela 36 – Características dos estudos não comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP.** -->
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e**<br>**objetivo**|**Intervenção**|**N**|**Idade**|**IMC (kg/m2) ou**<br>**peso (Kg)**|**Sinais SOP**|**Tempo de**<br>**seguimento e**<br>**perdas**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|**Bhandari et**<br>**al. 2016**<br>**(147)**|Série de casos<br>prospectiva|Avaliar os resultados<br>da CB. Dados<br>presentados para o<br>estrato de pacientes<br>com SOP|Gastrectom<br>ia tipo<br>Sleeve|43|27,77 ±<br>4,50|IMC: 42,52 ±<br>5,71<br>Peso: 106,89 ±<br>17,79|HAM: 4,68 ± 1,85;<br>Irregularidade<br>menstrual: 28/43 (65)|6 meses. Perdas<br>NR.|Moderado-alto:<br>série de casos<br>para inferir<br>efetividade. No<br>entanto, o estudo<br>foi prospectivo e<br>todas as cirurgias<br>foram realizadas<br>pelo mesmo<br>profissional|  
|**Chiofalo et**<br>**al. 2017**<br>**(148)**|Estudo<br>observacional<br>comparativo<br>(mulheres<br>com e sem<br>SOP, obesas e<br>não obesas).<br>Apenas a<br>coorte de<br>mulheres com<br>SOP e<br>obesidade foi<br>apresentada|Avaliar o efeito da<br>CB nos níveis de<br>HAM em mulheres<br>obesas com SOP em<br>idade fértil|Gastrectom<br>ia tipo<br>"sleeve"<br>(n=5); Y-de-<br>Roux (n=9)|De 29<br>pacientes<br>obesas com<br>SOP, 14 foram<br>submetidas à<br>CB (dados de<br>base considera<br>as 29)|Média 30<br>± 6 anos|IMC: 44 ± 7 (com<br>base em 29<br>pacientes obesas<br>com SOP)|Testosterona (ng/ml):<br>0,54 ± 0,18; DHEA<br>(ug/dl): 205,1 ± 78,9;<br>Androstenediona<br>(ng/ml): 4,29 ± 1,66;<br>HAM (ng/ml): 5,44 ±<br>3,74|12 meses. Perdas<br>NR.|Alto: série de<br>casos para inferir<br>eficácia|
|---|---|---|---|---|---|---|---|---|---|
|**Christ et al.**<br>**2016 (149)**|Série de casos<br>retrospectiva|Avaliar o efeito da<br>CB na morfologia<br>ovariana de<br>pacientes com SOP|Tipo de<br>cirurgia não<br>especificad<br>o|33|NR|NR|Volume ovariano (ml):<br>14,0 ± 9,8;<br>Testosterona total<br>(ng/dL): 56,1 ± 25,6;<br>Testosterona livre|NR|Alto: série de<br>casos para inferir<br>eficácia|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e**<br>**objetivo**|**Intervenção**|**N**|**Idade**|**IMC (kg/m2) ou**<br>**peso (Kg)**|**Sinais SOP**|**Tempo de**<br>**seguimento e**<br>**perdas**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
||||||||(pg/mL): 10,3 ± 5,8;<br>DHEA (ug/dL): 196,3 ±<br>114,3|||
|**Eid et al.**<br>**2005 (150)**|Série de casos<br>retrospectiva|Avaliar perda de<br>peso e desfechos<br>clínicos em<br>pacientes com SOP<br>submetidas à CB|Bypass<br>gástrico Y<br>de Roux,|30 (24 incluídas<br>nas análises)|34 ± 9,7|50 ±7,5|Hirsutismo: 23/24<br>(96); Acne: 5/24 (20);<br>Policistos por US:<br>12/24 (50)|27,5 ± 16 meses.<br>Perdas 6/24 (25)|Alto: série de<br>casos para inferir<br>eficácia; análises<br>não ajustadas<br>para variáveis|
|**Eid et al.**<br>**2014 (151)**|Série de casos<br>prospectiva|Avaliar o efeito da<br>perda de peso pós<br>CB no perfil<br>hormonal e<br>manifestações<br>clínicas da SOP|Bypass<br>gástrico<br>tipo Y-de-<br>Roux<br>laparoscópi<br>co|14|36,3 ± 8,4|44,8 ±1,6|Menstruação<br>irregular: 10 (71,4);<br>Hirsutismo: 11 (85,7)|1 ano. Perdas<br>NR.|Alto: série de<br>casos para inferir<br>eficácia; análises<br>não ajustadas<br>para variáveis|
|**Escobar-**<br>**Morreale et**<br>**al. 2005**<br>**(152)**|Série de casos<br>prospectiva|Avaliar o efeito da<br>redução de peso por<br>meio de CB em<br>pacientes com SOP|Desvio<br>biliopancre<br>ático ou<br>bypass<br>gástrico|17 pacientes<br>com SOP.<br>Desfechos<br>foram<br>apresentados<br>para apenas 12<br>pacientes com<br>dados<br>completos|29,8 ± 5,3<br>anos|IMC: 50,7 ± 7,1|Escore de hirsutismo:<br>8,1 ± 6,3;<br>Testosterona total<br>(ng/dl): 73 ± 33;<br>Testosterona livre<br>(ng/dl): 1,6 ± 0,7;<br>SHBG (g/dl): 211 ±<br>124; Androstendiona<br>(ng/ml): 3,8 ± 1,4|Média 12 ± 5<br>meses (7 a 26<br>meses). 5<br>pacientes foram<br>excluídas das<br>análises de<br>desfechos (uso<br>ACO 2; óbito<br>pós-op 1; perda<br>de seguimento 1;<br>transtorno<br>alimentar grave<br>1)|Alto: série de<br>casos para inferir<br>eficácia|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e**<br>**objetivo**|**Intervenção**|**N**|**Idade**|**IMC (kg/m2) ou**<br>**peso (Kg)**|**Sinais SOP**|**Tempo de**<br>**seguimento e**<br>**perdas**|**Risco de viés**|
|---|---|---|---|---|---|---|---|---|---|
|**Gomez-**<br>**Meade et**<br>**al. 2013**<br>**(153, 154)**|Série de casos<br>retrospectiva|Avaliar o efeito de<br>CB em desfechos<br>cardiometabólicos<br>em mulheres com<br>SOP|Bypass<br>vertical tipo<br>Y-de-Roux|389|40,9 ±<br>12,9|IMC: hispânicos<br>(n=257): 45,5;<br>Negros não-<br>hispânicos<br>(n=97): 46,8;<br>Brancos não-<br>hispânicos<br>(n=35): 45,7|NR|12 meses<br>Perdas NR.|Alto: série de<br>casos para inferir<br>eficácia|
|**Jamal et al.**<br>**2012 (154)**|Série de casos<br>prospectiva|Avaliar os efeitos a<br>longo prazo da CB<br>na SOP e<br>infertilidade|Bypass<br>vertical tipo<br>Y-de-Roux|25 (dados de<br>apenas 20<br>foram<br>apresentados)|32 ± 5,8|IMC: 52,8 ± 9,0<br>Peso (lb): 326 ±<br>54|Policistos na US:<br>12/20 (60%);<br>Oligomenorreia 17/20<br>(85%); Hirsutismo:<br>14/20 (70%); DM2:<br>9/20 (45%); HAS 6/20<br>(30%); depressão:<br>8/20 (40%); RGE:<br>12/20 (60%);<br>Incontinência urinária:<br>6/20(30%)|Média 46,7 ±<br>35,3 meses (min<br>15; max 123).<br>Dados excluídos<br>(inclusive dados<br>de base): 5/25<br>(25%)|Alto: série de<br>casos<br>retrospectiva para<br>inferir eficácia|
|||Avaliar perda de|||||||Alto: série de|
|**Turkmen et**<br>**al. 2015**<br>**(155, 156)**|Série de casos<br>prospectiva|peso e desfechos<br>clínicos em<br>pacientes com SOP<br>submetidas à CB|Bypass<br>gástrico Y<br>de Roux,|13|29,9±7,1|47,15±7,57|NR|6 meses. Não<br>houve perdas.|casos para inferir<br>eficácia; análises<br>não ajustadas<br>para variáveis|  
N: número de pacientes; IMC: índice de massa corporal; SOP: síndrome do ovário policístico; CB: cirurgia bariátrica; HAM: hormônio anti-mulleriano; NR: não reportado; DHEA: Dehidroepiandrosterona US: ultrassonografia; DM2: diabetes mellitus tipo 2; HAS: hipertensão arterial sistêmica; RGE: refluxo gastro-esofágico; SHBG: globulina transportadora de hormônio sexual; ACO: anticoncepcional oral.  
**Tabela 37 – Desfechos apresentados nos estudos não comparativos avaliando os efeitos da cirurgia bariátrica em pacientes com SOP.**  
|**Autor,**|**Comorbidades i**|**ntra-grupo - Intervenção**|**Valor de  intra-ruo**|
|---|---|---|---|
|**ano**|**Pré-operatório**|**Pós-operatório**|**p gp**|
||IMC: 4252 ± 571||Peso: <0001|
|**Bhandari**<br>**et al. 2016**<br>**(147)**|,  ,<br>Peso: 106,89 ± 17,79<br>HAM: 4,68 ± 1,85<br>Irregularidade menstrual: 28/43<br>(65%)|Peso: 77,27 ± 10,72<br>IMC: 30,76 ± 2,93<br>HAM: 3,38 ± 1,21<br>Irregularidade menstrual: 17/43 (39%)|,<br>IMC: <0,0001<br>HAM: <0,001<br>Irregularidade menstrual:<br>0,027|
|**Chiofalo**<br>**et al. 2017**<br>**(148)**|Testosterona (ng/ml): 0,54 ±<br>0,18<br>DHEA (ug/dl): 205,1 ± 78,9<br>Androstenediona (ng/ml): 4,29 ±<br>1,66<br>HAM (ng/ml): 5,44 ± 3,74 (com<br>base em 29 pacientes obesas<br>com SOP)|Testosterona, DHEA e Androstenediona<br>(ng/ml): houve redução estatisticamente<br>significativa após 12 meses<br>HAM (ng/ml): 4,25 ± 3,65 (com base em<br>14 pacientes)|Testosterona, DHEA e<br>Androstenediona: p<0,05<br>HAM (ng/ml): p=0,04|
|**Christ et**<br>**al. 2016**<br>**(149)**|IMC: 47,5 ± 13,9<br>Peso: 126,3 ± 37,6<br>Volume ovariano (ml): 14,0 ± 9,8<br>Testosterona total (ng/dL): 56,1<br>± 25,6<br>Testosterona livre (pg/mL): 10,3<br>± 5,8<br>DHEA(ug/dL): 196,3 ± 114,3|IMC: 37,4 ± 10,3<br>Peso: 95,7 ± 23,2<br>Volume ovariano (ml): 7,7 ± 4,8<br>Testosterona total (ng/dL): 38,4 ± 24,1<br>Testosterona livre (pg/mL): 4,5 ± 4,4<br>DHEA (ug/dL): 132,9 ± 79,4|IMC: p<0,0001<br>Peso: p<0,0001<br>Volume ovariano: p=0,036<br>Testosterona total: NS<br>Testosterona livre: NS<br>DHEA: NS|
||IMC (kg/m<sup>2</sup>): 44,8 ± 5,9<br>Testosterona (ng/dL): 59,0 ± 8,2<br>FSH (mIU/mL): 5,8 ± 0,6|IMC<br>3 meses: 36,2 ± 4,9 kg/m2<br>6 meses: 32,4 (NR)  kg/m2<br>12 meses: 29,2 ±  5,9 kg/m2<br>Testosterona (ng/dL):<br>6 meses: 31,1  ±  4,1<br>12 meses: 33,7  ± 4,4<br>Diferença de média: 23,0  ±   12,5<br>FSH (mIU/mL):<br>6 meses: 12,5 ±  4,1<br>12 meses: 11,13 ±  2,9<br>Diferença de média: 5,3 ±  3,3<br>LH (mIU/mL):<br>|IMC: NR<br>Testosterona:<br>3 meses: p<0,05<br>6 meses: p>0,05<br>12 meses: p<0,05<br>FSH:<br>3 meses: p<0,05<br>6 meses: p<0,05<br>12 meses: p<0,05<br>LH<br>3 meses: p<0,05<br>|
|**Eid et al.**<br>**2005**|LH (mIU/mL): 6,5 ± 1,3|6 meses: 12,0   ± 3,8<br>12 meses: 15,0  ± 4,3<br>|6 meses: p<0,05<br>12 meses: p<0,05<br>|
|**(150)**|Glicose de jejum (mg/dL):118,0<br>±38,7|Diferença de médias: 8,6 ±  4,6<br>Glicose de jejum (mg/dL):<br>6 meses: 87,5  ± 7,6|Glicose:<br>3 meses: p<0,05<br>6 meses: p>0,05|
||Colesterol (mg/dL): 219,0 ± 14,9<br>Triglicérides (mg/dL): 162,9 ±<br>17,8|12 meses: 87,4  ±  15,4<br>Diferença de médias: 30,0 ±   25,2<br>Colesterol (mg/dL):<br>6 meses: 175,9 ±  8,6<br>12 meses: 160,9 ±  7,2<br>Diferença de médias: 55,8  ±  12,1<br>Triglicérides (mg/dL):<br>6 meses: 87,2 ±  7,2<br>12 meses: 71,8   ± 6,72<br>Diferença de médias: 91,1 ±   14,5<br>Menstruação regularizada: 5/10 (50%)<br>Melhora hirsutismo: 4/11(36)|12 meses: p<0,05<br>Colesterol<br>3 meses: p<0,05<br>6 meses: p>0,05<br>12 meses: p<0,05<br>Triglicérides:<br>3 meses: p<0,05<br>6 meses: p>0,05<br>12 meses: p<0,05<br>Restante NR|  
|**Autor,**<br>**ano**|**Comorbidade**<br>**Pré-operatório**|**s intra-grupo - Intervenção**<br>**Pós-operatório**|**Valor de p intra-grupo**|
|---|---|---|---|
|||Perda de excesso de peso: 66,5%||  
|**Eid et al.**<br>**2014**<br>**(151)**|Peso (libras): 306 ± 44<br>IMC (kg/m2): 50 ± 7,5<br>Hirsutismo: 23/24<br>Disfunção menstrual: 24|Peso (libras): 20 ± 30<br>IMC (kg/m2): 30 ± 4,5<br>Perda de peso: 56,7% ± 21,2%<br>Normalização da glicemia de jejum: 11/11<br>(100)<br>Normalização da pressão arterial: 7/9 (78)<br>Hirsutismo: 5/24<br>Disfunção menstrual 12 meses pós: 0<br>Resolução da infertilidade sem clomofeno:<br>5/5(100)|NR|
|---|---|---|---|
|**Escobar-**<br>**Morreale**<br>**et al. 2005**<br>**(152)**|Vide pós-operatório|Regularidade menstrual: 12/12 (100)<br>Ovulação: 10/10 (100)<br>Diagnóstico de SOP: 0/12<br>Diferença em relação aos dados de base<br>(para 12 pacientes reavaliadas):<br>Peso: -41 ± 9 kg (IC95% 36 – 47)|Peso: p= 0,001<br>Demais: NR|
|**Gomez-**<br>**Meade et**<br>**al. 2013**<br>**(153, 154)**|Vide pós-operatório|Diferença em relação aos dados de base:<br>IMC (kg/m2): -9,7 (EP 0,3)<br>Peso (kg): -25,7 (EP 0,7)<br>Colesterol total (mg/dL): -35,1 (EP 3,6)<br>HDL (mg/dL): +0,1 (EP 1,2)<br>LDL (mg/dL): -27,8 (EP 3,4)<br>Triglicerides (mg/dL): -40,1 (EP 7,6)<br>HbA1c (%): -0,6 (EP 0,1)<br>ALT/TGP (U/L): -4,9 (EP 1,1)<br>AST/TGO(U/L): -1,8(EP 0,8)|IMC: < 0,0001<br>Peso: < 0,0001<br>Colesterol total: <0,0001<br>HDL: 0,95<br>LDL: < 0,0001<br>Triglicerides: < 0,0001<br>HbA1c: < 0,0001<br>ALT/TGP: < 0,0001<br>AST/TGO: 0,04|  
|**Autor,**|**Comorbidades in**|**tra-grupo - Intervenção**|**Valor de  intra-ruo**|
|---|---|---|---|
|**ano**|**Pré-operatório**|**Pós-operatório**|**p gp**|
|**Jamal et**<br>**al. 2012**<br>**(154)**|Oligomenorreia 17/20 (85%)<br>Hirsutismo: 14/20 (70%)<br>DM2: 9/20 (45%)<br>HAS: 6/20 (30%)<br>Depressão: 8/20 (40%)<br>RGE: 12/20 (60%)<br>Incontinência urinária: 6/20<br>(30%)<br>Concepção: 10/20 (50%)|Oligomenorreia: 3/20 (15%)<br>Hirsutismo: 9/20 (45%)<br>DM2: 1/20 (5%)<br>HAS: 3/20 (15%)<br>Depressão: 1/20 (5%)<br>REG: 0/20<br>Incontinência urinária: 0/20<br>Concepção: das 10 pacientes que ainda<br>não tinham concebido, 4 não mais<br>desejaram e 6 conseguiram conceber|Oligomenorreia: p<0,005<br>Hirsutismo: p<0,005<br>DM2: p<0,005<br>HAS: NS<br>Depressão: p<0,005<br>RGE: p<0,005<br>Incontinência urinária:<br>p<0,005|
|**Turkmen**<br>**et al. 2015**<br>**(155, 156)**|Circunferência da cintura (cm):<br>131,23±16,86<br>Razão cintura quadril: 0,93±0,07<br>IMC (kg/m2): 47,15±7,57<br>PAS (mmHg): 142,30±19,95<br>PAD (mmHg): 86,53±16,50<br>HDL colesterol (mmol/L):<br>1,12±0,21<br>Triglicérides (mmol/L): 1,36±0,43<br>Glicemia de jejum (mmol/L):<br>5,80±0,50<br>HbA1c(%): 4,55±0,35|Circunferência da cintura (cm):<br>104,38±14,96<br>Razão cintura quadril: 0,87±0,08<br>IMC (kg/m2): 35,46±7,04<br>PAS (mmHg): 126,0±14,47<br>PAD (mmHg): 81,0±12,45<br>HDL colesterol (mmol/L): 1,22±0,19<br>Triglicérides (mmol/L): 1,04±0,28<br>Glicemia de jejum (mmol/L): 5,08±0,36<br>HbA1c (%): 3,92±0,52|Circunferência da cintura:<br>p=0,001<br>Razão cintura quadril:<br>p=0,017<br>IMC: p=0,001<br>PAS: p=0,008<br>PAD: p>0,05<br>HDL: p>0,05<br>Triglicérides: p=0,021<br>Glicemia: p=0,001<br>HbA1c: p=0,002|  
HAM: hormônio anti-mulleriano; NR: não reportado; DHEA: Dehidroepiandrosterona; NS: não significativo; IMC: índice de massa corporal; EP: erro padrão; HDL: lipoproteína de alta densidade; LDL: lipoproteína de baixa densidade; HbA1c: hemoglobina glicosilada; ALT/TGP: alanina-amino transferase/transaminase glutâmico pirúvica; AST/TGO: aspartatoamino transferase/transaminase glutâmico oxalacética; FSH: hormônio estimulante folicular; LH: hormônio luteinizante; NR: não reportado; PAS: pressão arterial sistólica; PAD: pressão arterial diastólica; DM2: diabetes mellitus tipo 2; HAS: hipertensão arterial sistêmica; IC: intervalo de confiança.  
**RECOMENDAÇÃO:** Apesar da baixa qualidade metodológica, os estudos evidenciaram, de forma quase unânime, benefícios relacionados à redução ponderal, parâmetros hormonais (como FSH, LH, HAM e androgênios), parâmetros metabólicos (como perfil lipídico e glicemia), além de melhoria no hirsutismo, redução no volume ovariano, na ciclicidade menstrual e na fertilidade. Tais estudos utilizaram técnicas cirúrgicas distintas, que potencialmente poderiam influenciar os resultados. As mais comumente usadas foram a banda gástrica ajustável, o _by pass_ gástrico em Y de Roux (Cirurgia à Fob Capella) e a gastrectomia vertical (Sleeve). As respostas positivas ao procedimento cirúrgico foram independentes das técnicas utilizadas (68). Estes estudos tiveram seguimento curto, usualmente em torno de 12 meses, não permitindo avaliar as consequências a longo prazo do procedimento cirúrgico. Da mesma forma, a avaliação da segurança do procedimento também ficou prejudicada pela escassez de dados.  
A cirurgia bariátrica pode ser indicada para portadoras da SOP, com IMC > 35 kg/m2, que não apresentaram sucesso na terapêutica não-cirúrgica para obesidade, por sua eficácia a curto prazo em parâmetros clínicos, laboratoriais, reprodutivos e metabólicos. Mais dados sobre eficácia e segurança deste procedimento para o tratamento da obesidade associada a SOP são necessários. **(GRADE: recomendação condicional a favor; qualidade da evidência: moderada)**  
**Questão de Pesquisa 10:** Qual a eficácia dos sensibilizadores de ação da insulina para comorbidades  
metabólicas em mulheres com PCOS?

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
<mark>((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome)) AND ("Metabolic Diseases"[Mesh] OR metabolic disorders OR metabolic syndrome)) AND (("Hypoglycemic Agents"[Mesh] OR Antihyperglycemic Agents OR Antidiabetic Drugs OR Antidiabetics OR insulin sensitizer)) Filters: Clinical Trial; Meta-Analysis</mark>  
<mark>Total: 393 referências</mark>  
<mark>Data acesso 24/05/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
<mark>'ovary polycystic disease'/exp AND [embase]/lim OR 'ovary polycystic disease' AND [embase]/lim AND ('metabolic disorder'/exp AND [embase]/lim OR 'metabolic disorder' AND [embase]/lim) AND ('insulin sensitizing agent'/exp OR 'insulin sensitizing agent' AND [embase]/lim)</mark>  
<mark>Total: 380 referências</mark>  
<mark>Data acesso 24/05/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca nas bases resultou em 773 referências (393 no MEDLINE e 380 no EMBASE). Destas, 15 estavam em duplicata. Setecentos e cinquenta e oito referências foram triadas pela leitura de título e resumo. Sessenta e três referências tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destes, 50 foram excluídos no total. Os motivos de exclusão foram nove por não considerarem os sensibilizadores como intervenção ou controle, dois por não incluírem mulheres com SOP, um estudo por ser relato de 8 casos e um por ser uma versão antiga de uma revisão sistemática incluída. Três revisões sistemáticas e meta-análises foram excluídas. Duas por avaliarem os sensibilizadores de insulina em desfechos de não interesse e uma de 2003 porque os estudos incluídos foram considerados em outra revisão sistemática com meta-análise mais recente que foi incluída na extração de dados.</mark>  
<mark>Seis estudos foram excluídos por não avaliarem os desfechos de interesse. Três estudos foram excluídos por avaliarem a troglitazona, uma medicação retirada do mercado. Três estudos foram excluídos por compararem diferentes doses de uma mesma medicação.</mark>  
<mark>Adicionais 21 estudos recuperados pela presente estratégia de busca foram excluídos, por terem sido incluídos em revisões sistemáticas e meta-análises identificadas e incluídas neste relatório. Um estudo</mark> foi excluído por administrar metformina por apenas quatro dias e avaliar os desfechos em 3 meses em apenas 19 pacientes, o que não representa a prática clínica.  
<mark>Ao final, 13 estudos foram considerados elegíveis (126-133, 157-161), sendo cinco revisões sistemáticas e meta-análises (126-128, 154, 158) e oito ensaios clínicos randomizados adicionais não considerados nas revisões sistemáticas incluídas (129-133, 159-161).</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A apresentação dos dados foi realizada por tipo de estudo. As Tabelas 38 a 42 demonstram dados extraídos das cinco revisões sistemáticas com meta-análise de ensaios clínicos randomizados (126-128, 154, 158). A Tabela 38 apresenta as c</mark> aracterísticas das revisões sistemáticas avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP enquanto a Tabela 39 apresenta as <mark>características dos pacientes incluídos nesses estudos. As Tabelas 40, 41 e 42 apresentam os resultados das meta-análises para desfechos antropométricos, metabólicos e reprodutivos, respectivamente.</mark>  
<mark>As Tabelas 43 a 47 demonstram dados extraídos dos ensaios clínicos randomizados (129-133, 159-161). A tabela 43 apresenta as c</mark> aracterísticas dos estudos avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP enquanto a Tabela 44 apresenta as c <mark>aracterísticas dos pacientes incluídos nesses estudos. As Tabelas 45, 46 e 47 apresentam os desfechos antropométricos, metabólicos e reprodutivos, respectivamente.</mark>  
**Tabela 38 – Características das revisões sistemáticas avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP.**  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**|**N estudos**<br>**(n**<br>**participantes)**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Du et al.**<br>**2012 (154)**|Revisão<br>sistemática e<br>meta-análise de<br>ECRs|Avaliar a eficácia da<br>pioglitazona_versus_<br>metformina em mulheres<br>com SOP|6 estudos<br>(278<br>participantes)|Pioglitazona<br>30mg/dia (4 estudos)<br>45mg/dia (1 estudo)<br>15mg/dia (1 estudo)|Metformina<br>1500mg/dia|Baixo: apesar do baixo risco de viés no<br>planejamento e condução da revisão, os<br>estudos incluídos, segundo os autores,<br>apresentaram alto risco de viés - dois<br>estudos não relataram o método de sigilo de<br>alocação, dois estudos foram abertos,<br>nenhum estudo relatou o tipo de análise, o<br>quegera evidência de baixaqualidade|
|**Du et al.**<br>**2012b (158)**|Revisão<br>sistemática e<br>meta-análise de<br>ECRs|Avaliar a eficácia das<br>tiazolinedionas_versus_<br>placebo em mulheres<br>com SOP|8 estudos<br>(286<br>pacientes)|Roziglitazona 4mg/dia ou<br>4mg 2x/dia; Pioglitazona<br>30mg/dia ou 45mg/dia.<br>Ambas combinadas nas<br>meta-análises para<br>avaliação do efeito de<br>classe|Placebo|Alto: excluíram estudos com base em<br>critérios metodológicos. A seleção de<br>estudos foi realizada por revisores<br>independentes, porém, não há menção<br>sobre o processo de extração de dados ou<br>avaliação do risco de viés. Exclusões pós-<br>randomização significativas, podendo<br>comprometer os resultados encontrados|
|**Li et al. 2011**<br>**(126)**|Revisão<br>sistemática e<br>meta-análise de<br>ECRs|Avaliar a eficácia de<br>metformina_versus_<br>tiazolinedionas em<br>mulheres com SOP|10 estudos<br>(459<br>participantes)|Metformina<br>1500mg (2 estudos)<br>1700mg (7 estudos)<br>2550mg (1 estudo)|Roziglitazona<br>4mg (6 estudos)<br>8mg (2 estudos)<br>Pioglitazona<br>30mg (1 estudo)<br>45mg (1 estudo)|Alto: Estratégia de busca muito específica,<br>limite inglês de idioma, sem definições de<br>desfechos, sem especificações de unidades<br>de medida dos desfechos, considerou como<br>grupo controle a classe Tiazolidinedionas ao<br>invés de separar as comparações por<br>molécula|
|**Naderpoor et**<br>**al. 2015 (127)**|Revisão<br>sistemática e<br>meta-análise de<br>ECRs|Avaliar o efeito da<br>combinação de 1)<br>metformina + mudança<br>de estilo de vida_versus_<br>mudança de estilo de<br>vida; e efeito da 2)<br>metformina_versus_estilo|1) 9 estudos<br>2) 4 estudos<br>(608<br>participantes)|1) Metformina 1,5-2g/dia +<br>mudança estilo de vida<br>2) Metformina 1,5-2g/dia|1) mudança de estilo<br>de vida ± placebo<br>2) mudança de estilo<br>de vida ± placebo|Moderado: a elegibilidade foi realizada por<br>apenas um revisor e a maioria dos estudos<br>incluídos na revisão apresentaram alto-<br>moderado risco de viés|  
|**Autor, ano**|**Desenho do**<br>**estudo**|**População e objetivo**<br>de vida em mulheres com<br>SOP|**N estudos**<br>**(n**<br>**participantes)**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Tang et al.**<br>**2012 (128)**|Revisão<br>sistemática e<br>meta-análise de<br>ECRs|Avaliar a efetividade de<br>agentes sensibilizadores<br>da insulina na melhora de<br>parâmetros reprodutivos<br>e metabólicos em<br>mulheres com SOP|43 estudos (1<br>dos 44<br>estudos<br>incluídos<br>avaliou<br>inositol)<br>(3709<br>participantes)|Metformina, pioglitazona<br>ou roziglitazona isoladas;<br>Metformina + clomifeno|Placebo, nenhum<br>tratamento, ou<br>clomifeno|Moderado: Seleção, extração de dados e<br>avaliação do risco de viés por dupla de<br>revisores independentes. Apesar de<br>relatarem que gráfico de funil foi<br>"aceitável", dados não foram apresentados<br>e estudos potencialmente elegíveis não<br>foram identificados (incluídos em outras RS<br>abordando a mesma questão de pesquisa).<br>Meta-análises utilizaram modelo de efeito<br>fixo, a despeito da heterogeneidade<br>estatística|  
N: número de estudos incluídos; n: número de participantes; ECRs: ensaios clínicos randomizados; SOP: síndrome dos ovários policísticos.  
**Tabela 39 – Características das pacientes incluídas nas revisões sistemáticas avaliando os efeitos dos sensibilizadores de ação da insulina.**  
|**Autor, ano**|**N**<br>**Intervenção**|**N**<br>**Controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Intervenção**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Controle**|**Tempo de**<br>**seguimento**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de**<br>**seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|---|
|**Du et al.**<br>**2012 (154)**|Pioglitazona<br>n=141|Metformina<br>n=137|23-29|22-30|NR|NR|3-6 meses|42/278 (15)|42/278 (15)|
|**Du et al.**<br>**2012b**<br>**(158)**|Roziglitazona<br>n=78<br>Pioglitazona<br>n=58|Placebo<br>N=150|Média<br>mínima 23,6<br>(5,1); média<br>máxima 32<br>(variação<br>entre 26-36)|Média mínima<br>24,3 (6,0)<br>Média máxima<br>34 (variação<br>entre 29-38)|NR|NR|NR|Entre 0 e 44,2<br>primários, não<br>grupo em tod|9% nos estudos<br>apresentado por<br>os os estudos|
|**Li et al.**<br>**2011 (126)**|Total 45<br>apresentado|9 (não<br>por grupo)|NR|NR|Faixa de<br>31-36: n=3<br>22-25: n=2<br>26-29: n=4<br><25_versus_>25:|IMC:<br>estudos<br>estudos<br>estudos<br>n= 1 estudo|3 a 6 meses|0-33%|no total|
|**Naderpoor**<br>**et al. 2015**<br>**(127)**|259|271|Variação<br>entre 12-39|Variação entre<br>12-39|>30 (exceto em 1<br>estudo), sendo >35 em<br>7 de 12 estudos|>30 (exceto em 1<br>estudo), sendo >35<br>em 7 de 12 estudos|6 meses|Intervenção (1 e<br>2):<br>71/259 (25)|Controle (1 e 2):<br>79/271 (29)|
|**Tang et al.**<br>**2012 (128)**|Total 37<br>apresentado|09 (não<br>por grupo)|Média mínima<br>3|24,2 e máxima<br>2,8|58% das paciente<br>(Mínimo 24,3; máximo<br>grup|s com IMC >30<br>39,4) em ambos os<br>os|Duração média<br>dos estudos<br>19,5 semanas<br>(variação entre<br>4 e 48<br>semanas)|NR, porém, rep<br>estudos apresent<br>viés por exclusões|ortou que 11 dos<br>aram alto risco de<br>pós-randomização|  
N: número de estudos incluídos; n: número de participantes; IMC: índice de massa corporal; NR: não reportado. Quando não especificado, dados foram apresentados como n/N (%).  
**Tabela 40 – Meta-análises avaliando os efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos antropométricos.**  
|||**IMC**|**(kg/m**<sup>**2**</sup>**)**|**Razão cin**|**tura-quadril**|**Tecido adi**|**poso subcutâneo**|
|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Comparação**|**N estudos**<br>**(n participantes)**|**Medidas de Associação**<br>**(IC95%)**|**N estudos**<br>**(n participantes)**|**Medidas de**<br>**Associação (IC95%)**|**N estudos**<br>**(n**<br>**participantes)**|**Medidas de**<br>**Associação (IC95%)**|
|**Du et al. 2012**<br>**(154)**|Pioglitazona<br>_versus_<br>metformina|6 estudos<br>(141 pioglitazona e<br>137 metformina)|DMP: 0,25 (IC95% 0,01;<br>0,49); I<sup>2</sup>=0%; p=0,038|NA|NR|NA|NR|
|**Du et al.**<br>**2012b (158)**|Tiazolinedionas<br>_versus_placebo|7 estudos<br>(231 participantes)|DMP: 0,39 (IC95% 0,13;<br>0,66); I<sup>2</sup>=0%; p=0,003|NA|NR|NA|NR|
|||**Em 3 meses:**<br>5 estudos|**Em 3 meses:**<br>DM: -2,47 (IC95% -3,33;|||||
|**Li et al. 2011**<br>**(126)**|Metformina<br>_versus_<br>tiazolinedionas|(209 participantes)<br>**Em 6 meses:**<br>4 estudos<br>(199participantes)|-1,62); I<sup>2</sup>=55%; p<0,0001<br>**Em 6 meses:**<br>DM: -0,70 (IC95% -0,76;<br>-0,65);I<sup>2</sup>=55%; p<0,0001|NA|NR|NA|NR|
|**Naderpoor et**<br>**al. 2015 (127)**|Metformina +<br>mudança de<br>estilo de vida<br>_versus_<br>mudança de<br>estilo de vida|9 estudos<br>(247 intervenções<br>e 246 controles)|DM: -0,73 (IC95% -1,14;<br>-0,32); I<sup>2</sup>=0%; p=0,0005|2 estudos<br>(140 participantes)|DM: 0,0 (IC95% -0,03;<br>0,03); I<sup>2</sup>=0%; p=0,98|2 estudos<br>(30<br>intervenções e<br>27 controles)|DM: -92,49<br>(IC95% -164,14; -<br>20,84);<br>I<sup>2</sup>=0%; p=0,01|
||Metformina<br>_versus_estilo de<br>vida|4 estudos<br>(85 participantes)|DM: 0,13 (IC95% -0,76;<br>1,02); I<sup>2</sup>=0%; p=0,78|NA|NR|NA|NR|
|**Tang et al.**<br>|Metformina<br>_versus_placebo<br>ou não<br>tratamento|16 estudos<br>(630 participantes)|DM: -0,05 (IC95% -0,31;<br>0,20); I<sup>2</sup>=0%; p=0,67|10 estudos<br>(449 participantes)|DM: -0,01 (IC95% -<br>0,01; -0,00), I<sup>2</sup>=0%;<br>p=0,00015|NA|NR|
|**2012 (128)**|Rosiglitazona<br>_versus_placebo<br>ou não|3 estudos<br>(132 participantes)|DM: 0,68 (IC95% 0,40;<br>0,96); I<sup>2</sup>=15%;<br>p<0,00001|3 estudos<br>(132 participantes)|DM -0,01 (IC95% -0,02;<br>-0,00); I<sup>2</sup>=0%;<br>p=0,00025|NA|NR|

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: tratamento -->
|Pioglitazona|2 estudos|DM: 0,91 (IC95% -1,88;|1 estudo|DM 0,02 (IC95% -0,02;|NA|NR|
|---|---|---|---|---|---|---|
|_versus_placebo|(63 participantes)|3,70); I<sup>2</sup>=0%; p=0,52|(28 participantes)|0,06); p=0,38|||  
IMC: índice de massa corporal; N: número de estudos incluídos; n: número de participantes; IC95%: intervalo de confiança de 95%; DMP: diferença de médias padronizadas; NA: não se aplica; NR: não reportado.  
**Tabela 41 – Meta-análises avaliando os efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos metabólicos.**  
|||**Insulina de**|**jejum (μU/ml)**|**Glicemia d**|**e jejum (mg/dl)**|**Testostero**|**na (ng/dL)**|**Outro**|**s desfechos**|
|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Comparação**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|
|**Du et al.**<br>**2012 (154)**|Pioglitazona<br>_versus_<br>metformina|6 estudos<br>(141<br>pioglitazona<br>e 137<br>metformina)|DMP: -0,37<br>(IC95% -0,61; -<br>0,13); I<sup>2</sup>=0%;<br>p=0,002|5 estudos (258<br>participantes)|DMP: -0,21<br>(IC95% -0,46; 0,03);<br>I<sup>2</sup>=6,9%; p=0,089|4 estudos<br>(224<br>participante<br>s)|DMP: -0,16<br>(IC95% -<br>0,42; 0,10);<br>I<sup>2</sup>=8,5%;<br>p=0,233|5 estudos (249<br>participantes)|**Resistência à**<br>**insulina (índice**<br>**HOMA-IR):**<br>DMP: -0,32 (IC95% -<br>0,57; -0,06); I<sup>2</sup>=30%;<br>p=0,014|
|**Du et al.**<br>**2012b**<br>**(158)**|Tiazolinedion<br>as_versus_<br>placebo|7 estudos<br>(234<br>participante<br>s)|DMP: -0,81<br>(-1,50; -0,12);<br>I<sup>2</sup>=83,4%; p=0,021|6 estudos (219<br>participantes)|DMP: -0,55<br>(-1,06; -0,05);<br>I<sup>2</sup>=68,3%; p=0,031|NA|NR|NA|NR|  
|**Li et al.**<br>**2011 (126)**|Metformina<br>_versus_<br>tiazolinedion<br>as|**Em 3 meses:**<br>3 estudos<br>(113<br>participante<br>s)<br>**Em 6 meses:**<br>3 estudos|**Em 3 meses:**<br>DM: 0,29<br>(IC95% -0,34;<br>0,92), I<sup>2</sup>=60%;<br>p=0,36<br>**Em 6 meses:**<br>DM: -0,03|**Em 3 meses:**<br>3 estudos (93<br>participantes)<br>**Em 6 meses:**<br>4 estudos (199|**Em 3 meses:**<br>DM: -0,02 mmol/L<br>(IC95% -0,43; 0,39),<br>I<sup>2</sup>=26%; p=0,92<br>**Em 6 meses:**<br>DM: 0,33 mmol/L|**Em 3 meses:**<br>3 estudos<br>(139<br>participante<br>s)<br>**Em 6 meses:**<br>3 estudos|**Em 3**<br>**meses:**<br>DM: 0,36<br>(IC95%<br>0,03; 0,69),<br>I<sup>2</sup>=0%;<br>p=0,03<br>**Em 6**<br>**meses:**|NA|NR|
|---|---|---|---|---|---|---|---|---|---|
|||(149|(IC95% -1,29;|participantes)|(IC95% -0,31; 0,97),|(139|DM: -0,43|||
|||participante<br>s)|0,43), I<sup>2</sup>=82%;<br>p=0,94||I<sup>2</sup>=78%; p=0,31|participante<br>s)|(IC95%<br>0,03; 0,69),<br>I<sup>2</sup>=0%;<br>p=0,33|||  
|||**Insulina de**|**jejum (μU/ml)**<br>**Medidas de**|**Glicemia d**|**e jejum (mg/dl)**|**Testostero**|**na (ng/dL)**<br>**Medidas de**|**Outro**|**s desfechos**|
|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Comparação**|**N estudos**<br>**(n partic.)**|<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|**N estudos**<br>**(n partic.)**|<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|
|**Naderpoo**<br>**l**|Metformina<br>+ mudança<br>de estilo de<br>vida_versus_<br>mudança de<br>estilo de vida|4 estudos<br>(108<br>participante<br>s)|DM: 2,89<br>(IC95% -0,37;<br>6,15); I<sup>2</sup>=0%;<br>p=0,08|5 estudos (66<br>intervenções e<br>59 controles)|DM: -2,16<br>(IC95% -5,51; 1,20);<br>I<sup>2</sup>=1%; p=0,21|6 estudos<br>(246<br>participante<br>s)|DM: -4,27<br>(IC95% -<br>11,83,<br>3,29);<br>I<sup>2</sup>=27%;<br>p=0,27|5 estudos (64<br>intervenções e<br>57 nos<br>controles)|**ÁSC de**<br>**concentração de**<br>**insulina (μU/ml)**<br>DM: 0,18 (IC95% -<br>0,18; 0,55); I<sup>2</sup>=0%;<br>p=0,31|
|**r et a.**<br>**2015 (127)**|Metformina<br>_versus_estilo<br>de vida|NA|NR|2 estudos (28<br>participantes)|DM: -2,91<br>(IC95% -13,31;<br>7,48); I<sup>2</sup>=47%;<br>p=0,58|3 estudos<br>(55<br>participante<br>s)|DM: -12,6<br>(IC95% -<br>18,99; -<br>6,21);<br>I<sup>2</sup>=0%;<br>p=0,0001|2 estudos (28<br>participantes)|**ÁSC de**<br>**concentração de**<br>**insulina (μU/ml)**<br>DM: 0,01 (IC95% -<br>1,11; 1,13); I<sup>2</sup>=53%;<br>p=0,99|
|||||||||**PAS:**<br>7 estudos (379<br>participantes)|**PAS (mmHg):**<br>DM: -3,59 (IC95% -<br>5,13; -2,04), I<sup>2</sup>=57%;<br>p<0,00001|
|**Tang et al.**<br>**2012 (128)**|Metformina<br>_versus_<br>placebo ou<br>não<br>tratamento|14 estudos<br>(596<br>participante<br>s)|DM: -3,51 mIU/L<br>(IC95% -6,50; -<br>0,53); I<sup>2</sup>=63%;<br>p=0,021|14 estudos<br>(596<br>participantes)|DM: -0,15 mmol/L<br>(IC95% -0,25; -<br>0,06), I<sup>2</sup>=42%;<br>p=0,0013|NA|NR|**PAD:**<br>6 estudos (292<br>participantes)<br>**Colesterol**<br>**total:**<br>10 estudos<br>(562, n<br>participantes)<br>**Triglicérides:**<br>7 estudos (309<br>participantes)|**PAD (mmHg):**<br>DM: -0,14 (IC95% -<br>1,35; 1,07), I<sup>2</sup>=21%;<br>p=0,83<br>**Colesterol total**<br>**(mmol/L):**<br>DM: -0,14 (IC95% -<br>0,31; 0,02); I<sup>2</sup>=62%;<br>p=0,088<br>**Triglicérides**<br>**(mmol/L):**DM: 0,14|  
|||**Insulina de j**|**ejum (μU/ml)**|**Glicemia**|**de jejum (mg/dl)**|**Testostero**|**na (ng/dL)**|**Outro**|**s desfechos**|
|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Comparação**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|
||||||||||(IC95% -0,05; 0,32);<br>I<sup>2</sup>=0%; p=0,34|  
||||||||**PAS:**<br>1 estudo (52<br>participantes)|**PAS (mmHg):**<br>DM -2,0 (IC95% -<br>3,95; -0,05);<br>p=0,044|
|---|---|---|---|---|---|---|---|---|
|Rosiglitazona<br>_versus_<br>placebo ou<br>não<br>tratamento|2 estudos<br>(80<br>participante<br>s)|DM: -3,98 mIU/L<br>(IC95% -9,38;<br>1,42), I<sup>2</sup>=0%;<br>p=0,15|3 estudos (132<br>participantes)|DM: -0,21 mmol/L<br>(IC95% -0,39; -<br>0,04), I<sup>2</sup>=0%;<br>p=0,017|NA|NR|**PAD:**<br>1 estudo (52<br>participantes)<br>**Colesterol**<br>**total:**|**PAD (mmHg):**<br>DM -0,20 (IC95% -<br>1,72; 1,32); p=0,08<br>**Colesterol total**|
||||||||2 estudos (80|**(mmol/L):**|
||||||||participantes)|DM -0,20 (IC95% -|
|||||||||0,21; -0,19), I<sup>2</sup>=0%;|
||||||||**Triglicérides:**|p<0,00001|  
|||**Insulina d**|**e jejum (μU/ml)**|**Glicemia**|**de jejum (mg/dl)**|**Testostero**|**na (ng/dL)**|**Outro**|**s desfechos**|
|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Comparação**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação**<br>**(IC95%)**|**N estudos**<br>**(n partic.)**|**Medidas de**<br>**Associação (IC95%)**|
|||||||||1 estudo (26<br>participantes)|**Triglicérides**<br>**(mmol/L):**DM 1,0<br>(IC95% 0,89; 1,11);<br>p<0,00001 n|
||Pioglitazona<br>_versus_<br>placebo|2 estudos<br>(63<br>participante<br>s)|DM: -1,46 mIU/L<br>(IC95% -3,97;<br>1,06), I<sup>2</sup>=0%;<br>p=0,26|NA|NR|NA|NR|NA|NR|  
N: número de estudos incluídos; n: número de participantes; IC95%: intervalo de confiança de 95%; DMP: diferença de médias padronizadas; HOMA-IR: índice de resistência à insulina; NA: não se aplica; NR: não reportado; DM: diferença de médias; ASC: área sob a curva; PAS: pressão arterial sistólica; PAD: pressão arterial diastólica  
**Tabela 42 – Meta-análises avaliando os efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos reprodutivos e sinais de SOP.**  
||**Comaraã**||**Hirsutismo**|**Fert**|**ilidade**|**Me**|**nstruação**|
|---|---|---|---|---|---|---|---|
|**Autor, ano**|**pç**<br>**o**|**N estudos**<br>**(n participantes)**|**Medidas de Associação**<br>**(IC95%)**|**N estudos**<br>**(n participantes)**|**Medidas de Associação**<br>**(IC95%)**|**N estudos**<br>**(n participantes)**|**Medidas de**<br>**Associação(IC95%)**|
|**Du et al.**<br>**2012 (154)**|Pioglitazona<br>_versus_<br>metformina|4 estudos (95<br>pioglitazona e<br>94 metformina)|**Escore FG:**<br>DMP: -0,03 (IC95% -0,31;<br>0,26);I<sup>2</sup>=0%; p=0,854|NA|NR|NA|NR|
|||**Escore FG:**<br>5 estudos (140<br>participantes)|**Escore FG:**<br>DMP: -0,24 (IC95% -0,57;|||||
|**Du et al.**|Tiazolinedio||0,10); I<sup>2</sup>=5,3%; p=0,169|||||
|**2012b**|nas_versus_|||NA|NR|NA|NR|
|**(158)**|placebo|**Níveis de**<br>**andrógenos:**<br>8 estudos (286<br>participantes)|**Níveis de andrógenos:**<br>DMP: -0,28 (IC95% -0,64;<br>0,09); I<sup>2</sup>=57%; p=0,141|||||
|**Li et al.**<br>**2011 (126)**|Metformina<br>_versus_<br>tiazolinedio<br>nas|2 estudos (144<br>participantes)|**Hirsutismo em 6 meses:**<br>DM: 1,6 (IC95% -0,47; 3,67);<br>I<sup>2</sup>=81%; p=0,13|**Ovulação:**<br>2 estudos<br>(55 participantes)<br>**Gestação:**<br>2 estudos (144<br>participantes)|**Ovulação em 3 meses:**<br>OR: 1,25 (IC95% 0,30;<br>5,19); I<sup>2</sup>=11%; p=0,73<br>**Gestação em 3 meses:**<br>OR: 0,90 (0,23; 3,54);<br>I<sup>2</sup>=0%; p=0,88|4 estudos (144<br>participantes)|**Menstruação em 3**<br>**meses:**<br>OR: 0,72 (IC95% 0,37;<br>1,41), I<sup>2</sup>=0%; p=0,34|
|**Naderpoor**<br>**et al. 2015**<br>**(127)**|Metformina<br>+ mudança<br>de estilo de<br>vida_versus_<br>mudança de<br>estilo de<br>vida|**Escore FG:**<br>4 estudos (113<br>participantes)<br>**Acne:**<br>2 estudos (54<br>participantes)|**Escore FG:**<br>DM: 0,67 (IC95% -2,40; 3,73);<br>I<sup>2</sup>=8%; p=0,67<br>**Acne (n° de lesões):**<br>DM: 1,13 (IC95% -0,85; 3,11);<br>I<sup>2</sup>=0%; p=0,26|NA|NR|3 estudos (35<br>participantes<br>em cada<br>grupo)|**Menstruação**<br>**(ciclos/6-12 meses):**<br>DM: 1,06 (IC95% 0,30;<br>-1,82); I<sup>2</sup>=0%; p=0,006|  
||**Comparaçã**||**Hirsutismo**|**Fertil**|**idade**|**Me**|**nstruação**|
|---|---|---|---|---|---|---|---|
|**Autor, ano**|**o**|**N estudos**<br>**(n participantes)**|**Medidas de Associação**<br>**(IC95%)**|**N estudos**<br>**(n participantes)**|**Medidas de Associação**<br>**(IC95%)**|**N estudos**<br>**(n participantes)**|**Medidas de**<br>**Associação(IC95%)**|
||Metformina<br>_versus_estilo<br>de vida|NA|NR|NA|NR|3 estudos (55<br>participantes)|**Menstruação**<br>**(ciclos/6-12 meses):**<br>DM: -0,02 (IC95% -<br>0,49; 0,45); I<sup>2</sup>=0%;<br>p=0,93|
|||||**Taxa de nascidos vivos:**<br>3 estudos (115<br>participantes)|**Taxa de nascidos vivos:**<br>OR: 1,8 (IC95% 0,52-<br>6,16), I<sup>2</sup>=0%; p=0,35|||
||Metformina<br>_versus_<br>placebo ou<br>ã|NA|NR|**Gestação clinicamente**<br>**comprovada:**<br>8 estudos (707<br>participantes)|**Gestação clinicamente**<br>**comprovada:**<br>OR 2,31 (IC95% 1,52;<br>3,51), I<sup>2</sup>=45%;<br>p=0,000088|**Regularização**<br>**da frequência:**<br>7 estudos (427|**Regularização da**<br>**frequência:**<br>OR 1,72 (IC95% 1,14;|
||no<br>tratamento|||**Taxa de ovulação:**<br>15 estudos (1208<br>|**Taxa de ovulação:**<br>OR 1,81 (IC95% 1,13;|participantes)|2,61), I<sup>2</sup>=54%; p=0,01|
|**Tang et al.**<br>||||participantes)|2,93); I<sup>2</sup>=20%; p=0,08|||
|**2012 (128)**||||**Aborto:**<br>3 estudos (279<br>participantes)|**Aborto:**<br>OR 0,36 (IC95% 0,09;<br>1,47),I<sup>2</sup>=0%; p=0,15|||
||Rosiglitazon<br>a_versus_<br>placebo ou<br>não<br>tratamento|NA|NR|**Taxa de ovulação:**<br>1 estudo (64<br>participantes)|**Taxa de ovulação:**<br>OR 1,91 (IC95% 0,70;<br>5,22); p=0,21|**Regularização**<br>**da frequência:**<br>2 estudos (100<br>participantes)|**Regularização da**<br>**frequência:**<br>OR 5,59 (IC95% 2,20;<br>14,19), I<sup>2</sup>=12%;<br>p=0,0003|
||Pioglitazona<br>_versus_<br>placebo|NA|NR|NA|NR|**Regularização**<br>**da frequência:**<br>2 estudos (70<br>participantes)|**Regularização da**<br>**frequência:**<br>OR 8,88 (IC95% 2,35;<br>33,61),I<sup>2</sup>=0%;|  
||**Comparaçã**||**Hirsutismo**<br>|**Fertil**<br>|**idade**<br>|**Me**<br>|**nstruação**<br>|
|---|---|---|---|---|---|---|---|
|**Autor, ano**|**o**|**N estudos**<br>**(n participantes)**|**Medidas de Associação**<br>**(IC95%)**|**N estudos**<br>**(n participantes)**|**Medidas de Associação**<br>**(IC95%)**|**N estudos**<br>**(n participantes)**|**Medidas de**<br>**Associação(IC95%)**<br>p=0,0013|
|||||**Taxa de nascidos vivos**:<br>7 estudos (907<br>participantes)|**Taxa de nascidos vivos**:<br>OR: 1,16 (IC95% 0,85-<br>1,56), I<sup>2</sup>=35%; p=0,35|||
|||||**Gestação clinicamente**<br>**comprovada:**|**Gestação clinicamente**<br>**comprovada:**|||
||Metformina|||11 estudos (1208|OR 1,51 (IC95% 1,17-|||
||+ clomifeno<br>_versus_|NA|NR|participantes)|1,96), I<sup>2</sup>=49%; p=0,0018|NA|NR|
||clomifeno|||**Taxa de ovulação:**|**Taxa de ovulação:**|||
|||||18 estudos (3265<br>participantes)|OR 1,73 (IC95% 1,50;<br>2,00), I<sup>2</sup>=62%; p<0,00001|||
|||||**Aborto:**|**Aborto:**|||
|||||7 estudos (837<br>participantes)|OR 1,61 (IC95% 1,00;<br>2,60),I<sup>2</sup>=0%; p=0,05|||  
N: número de estudos incluídos; n: número de participantes; IC95%: intervalo de confiança de 95%; Escore FG: escore Ferriman–Gallwey; DMP: diferença de médias padronizadas; NA: não se aplica; NR: não reportado; DM: diferença de médias; OR: razão de chances ( _odds ratio_ ).  
**Tabela 43 – Características dos estudos avaliando os efeitos dos sensibilizadores de ação da insulina em pacientes com SOP.**  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|
|**Ahmad et al.**<br>**2008 (129)**|ECR, aberto|Comparar a eficácia de metformina e<br>rosiglitazona na hiperinsulinemia e<br>hiperandrogenia,|Metformina 1500<br>mg/dia, n=31|Rosiglitazona 4<br>mg/dia, n=30|Alto: Não há descrição do sigilo da alocação,<br>estudo aberto|
|**Billa et al.**<br>**2009 (159)**|ECR, controlado por<br>placebo, unicêntrico|Avaliar os efeitos da metformina em<br>pacientes com e sem SOP (critérios de<br>Rotterdam). Apenas dados referentes<br>às pacientes com SOP foram coletadas|Metformina 850mg<br>2x/dia por média de 40<br>dias (variando entre<br>28-60), n=16 pacientes|Placebo, n=16<br>pacientes|Alto: Apenas o resumo menciona que o estudo<br>foi randomizado.  Não há descrição sobre<br>método de randomização, sigilo da alocação e<br>apesar de o estudo ser controlado por placebo,<br>detalhes sobre cegamento não foram<br>mencionados|
|**Bridger et al.**<br>**2006 (130)**|ECR, controlado por<br>placebo, unicêntrico|Avaliar os efeitos da metformina_versus_<br>placebo, ambos os grupos recebendo<br>orientações de alteração de estilo de<br>vida, em desfechos clínicos, endócrinos<br>e metabólicos em adolescentes com<br>SOP e hiperinsulinemia,|Metformina 1500<br>mg/dia por 12<br>semanas, n=11|Placebo por 12<br>semanas, n=11|Alto: Não há descrição do sigilo da alocação,<br>esquemas de cegamento de tipos de análise|
|**Mohiyiddeen**<br>**et al. 2013**<br>**(131)**|ECR|Avaliar os efeitos de metformina de<br>baixa dose versus rosiglitazona em<br>desfechos clínicos, bioquímicos e de<br>imagem em mulheres com SOP|Metformina<br>1000mg/dia por<br>3 meses, n=17|Rosiglitazona 4 mg/dia<br>por 3 meses, n=18|Alto: sem descrição do método de sigilo de<br>alocação, estudo aberto, não há descrição do<br>tipo de análise realizada e não há relato do<br>número de pacientes considerados nas<br>análises. Os testes de hipóteses foram<br>aplicados apenas para as variações intra-grupos<br>e não entre osgrupos|
|**Palomba et**<br>**al. 2007 (160)**|ECR, controlado por<br>placebo, unicêntrico|Avaliar os efeitos da metformina na<br>sensibilidade à insulina em mulheres<br>com SOP anovulatória, peso normal,<br>entre 20-30 anos|Metformina 850mg<br>2x/dia durante 12<br>meses, n=15 pacientes|Placebo durante 12<br>meses, n=15 pacientes|Alto: Randomização simples e sigilo mantido<br>até a alocação das intervenções (segundo<br>descrição), porém, foi descrito que profissionais<br>e pacientes foram cegos durante os 24 meses<br>do estudo. Não há descrição dos tipos de<br>análise|
|**Romero et al.**<br>**2004 (132)**|ECR|Avaliar o efeito de sensibilizadores de<br>insulina sensibilizadores em mulheres<br>com SOPpré-menopausa(15 a 36 anos|Metformina (1,5 ou<br>2g/dia), entre 6 e 32<br>semanas|Rosiglitazona (4 ou 8<br>mg/dia), entre 6 e 32<br>semanas|Alto: Não há descrição do sigilo da alocação,<br>esquemas de cegamento de tipos de análise|  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**Intervenção**|**Controle**|**Risco de viés**|
|---|---|---|---|---|---|
|||de idade), com ou sem resistência à<br>insulina||||
|**Shahebrahimi**<br>**et al. 2016**<br>**(133)**|ECR unicêntrico,<br>estratificado por<br>idade, peso,<br>presença de<br>hirsutismo e história<br>de disfunção<br>menstrual|Comparar os efeitos do tratamento<br>com metformina_versus_pioglitazona em<br>pacientes com SOP (critérios de<br>Rotterdam)|Metformina 500mg<br>3x/dia durante 3<br>meses, n=28<br>participantes|Pioglitazona 30mg/dia<br>durante 3 meses,<br>n=28 participantes|Alto: não há descrição sobre randomização,<br>sigilo da alocação, cegamento de pacientes,<br>investigadores, avaliadores de desfecho, e tipos<br>de análises|
|**Zahra et al.**<br>**2016** **(161)**|ECR, controlado por<br>placebo,<br>multicêntrico|Avaliar os efeitos da metformina em<br>desfechos metabólicos e endócrinos em<br>mulheres com SOP|Metformina, máxima<br>dose 500mg 3x dia, por<br>3 meses|Placebo, 3x dia, por 3<br>meses|Alto: Não há descrição de nenhum dos<br>domínios considerados pela ferramenta de<br>risco de viéspara ECR da Cochrane|  
ECR: ensaio clínico randomizado; n: número de participantes; SOP: síndrome dos ovários policísticos.  
**Tabela 44 – Características das pacientes incluídas nos estudos avaliando os efeitos dos sensibilizadores de ação da insulina.**  
|**Autor, ano**|**N**<br>**Intervenção**|**N Controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Intervenção**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Controle**|**Tempo de seguimento**|**Perda de**<br>**seguimento**<br>**Intervenção**|**Perda de**<br>**seguimento**<br>**Controle**|
|---|---|---|---|---|---|---|---|---|---|
|**Ahmad et**<br>**al. 2008**<br>**(129)**|Metformina<br>n=31|Rosiglitazon<br>a n=30|22,81 (4,52)|23,20 (3,36)|27,66 (5,44)|26,94 (5,24)|12 meses|4/31 (13)|5/30(17)|
|**Billa et al.**<br>**2009** **(159)**|Metformina<br>n=16|Placebo<br>n=16|26,1 (5,2),<br>n=15|24,2 (3,5),<br>n=15|28,6 (3,1),<br>n=15|27,3 (4,3),<br>n=15|Média 40 dias (variando<br>entre 28-60) após início<br>da intervenção (ou<br>placebo)|1/16 (6,2)|1/16 (6,2)|
|**Bridger et**<br>**al. 2006**<br>**(130)**|Metformina<br>n=11|Placebo<br>n=11|16,07 (0,97)|16,08 (1,39)|33,6 (5,6)|30,81 (3,0)|3 meses|Ambos os gru|pos: 1/22 (5)|
|**Mohiyidde**<br>**en et al.**<br>**2013(131)**|Metformina<br>n=17|Rosiglitazon<br>a n=18|29,0 (1,0)|30,0 (0,9)|29,1 (1,0)|29,7 (1,0)|3 meses|Ambos os grup|os: 5/40 (12,5)|
||||||||24 meses (12 meses em|||
|**Palomba et**<br>**al. 2007**<br>**(160)**|Metformina<br>n=15|Placebo<br>n=15|24,3 (3,1)<br>n=14|24,8 (2,7)<br>n=13|22,4 (2,7)<br>n=14|22,7 (1,9)<br>n=13|tratamento e 12 meses<br>após suspensão do<br>tratamento), Dados<br>coletados referente ao<br>período em tratamento)|1/15 (6,6) por<br>gravidez|2/15 (13,3) por<br>não adesão ao<br>protocolo|
|**Romero et**<br>**al. 2004**<br>**(132)**|Metformina<br>n=20|Rosiglitazon<br>a<br>n=20|24,3 (2,1)|25,8 (1,2)|NR|NR|NR|4/20 (20)|7/20 (35)|
|**Shahebrahi**<br>**mi et al.**<br>**2016(133)**|Metformina,<br>n=28|Pioglitazona<br>n=28|27,5 (3,68)|27,57 (5,91)|27,71 (4,36)|28,28 (4,49)|3 meses após início do<br>tratamento|De acordo com o<br>das proporções<br>perda de s|s denominadores<br>finais, não houve<br>eguimento|
|**Zahra et al.**<br>**2016** **(161)**|Metformina<br>n=20|Placebo<br>n=20|25,8 (6,1)|27,0 (6,3)|26,7 (6,5)|29,6 (9,9)|3 meses|NR|NR|  
n: número de participantes; IMC: índice de massa corporal; NR: não reportado. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
**Tabela 45 – Efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos antropométricos.**  
|||**IMC**||**Razão cintura**|**-quadril Intervenç**|**ão**||**Outros**||
|---|---|---|---|---|---|---|---|---|---|
|**Autor ano**|||**p para**|||**p para**||||
|**,**|**Intervenção**|**Controle**|**comparaçã**<br>**o**|**Intervenção**|**Controle**|**comparaç**<br>**ão**|**Intervenção**|**Controle**|**p para**<br>**comparação**|
|**Ahmad et al.**<br>**2008 (129)**|3 meses: 27,44<br>(5,37)<br>6 meses: 27,35<br>(5,27)<br>12 meses: 27,50<br>(5,25)|3 meses: 26,78<br>(5,2)<br>6 meses: 26,58<br>(5,2)<br>12 meses: 27,55<br>(6,0)|NR|3 meses: 0,86 (0,06)<br>6 meses: 0,86 (0,06)<br>12 meses: 0,86<br>(0,06)|3 meses: 0,81<br>(0,02)<br>6 meses: 0,81<br>(0,02)<br>12 meses: 0,81<br>(0,02)|NR|NR|NR|NA|
|**Billa et al. 2009**<br>**(159)**|NR|NR|NA|NR|NR|NA|NR|NR|NA|
|**Bridger et al.**<br>**2006 (130)**|Alteração em<br>relação ao<br>baseline: −0,16|Alteração em<br>relação ao<br>baseline: −0,19|p>0,05<br>(IC95%<br>−1,01;0,32)|NR|NR|NA|NR|NR|NA|
|**Mohiyiddeen et**<br>**al. 2013(131)**|29,12 (0,98)|30,50 (0,89)|NR|NR|NR|NA|NR|NR|NA|
||6 meses: 22,2|6 meses: 22,6||||||||
|**Palomba et al.**<br>**2007 (160)**|(2,0)<br>12 meses: 22,2<br>(2,1)|(2,0)<br>12 meses: 22,6<br>(1,9)|p=NS|NR|NR|NA|NR|NR|NA|
|**Romero et al.**<br>**2004(132)**|NR|NR|NA|NR|NR|NA|NR|NR|NA|
||||||||Peso (kg):<br>71,54 (12,27)|Peso (kg):<br>73,25 (12,75)|Peso: NR|
|**Shahebrahimi et**<br>**al. 2016 (133)**|27,43 (4,45)|28,55 (4,34)|p=NS|NR|NR|NA|Circunferênci<br>a da cintura<br>(cm):<br>89,91(9,1)|Circunferência da<br>cintura (cm):<br>90,36 (9,86)|Circunferênci<br>a: p=0,011|
|**Zahra et al. 2016**<br>**(161)**|25,3 (5,7)|29,7 (9,7)|p>0,05|NR|NR|NA|NR|NR|NA|  
IMC: índice de massa corporal; NR: não reportado; NA: não se aplica; IC95%: intervalo de confiança de 95%; NS: não significativo. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
**Tabela 46 – Efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos metabólicos.**  
||**Insul**|**ina e relacion**|**ados**|**Glicem**|**ia e relaciona**|**dos**|**Testoster**|**ona e relacion**|**ados**||**Outros**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Autor,**||||||**p para**|||**p para**|**Itã**||**p para**|
|**ano**|**Intervenção**|**Controle**|**p para**<br>**comparação**|**Intervenção**|**Controle**|**comparaçã**<br>**o**|**Intervenção**|**Controle**|**comparaçã**<br>**o**|**nervenç**<br>**o**|**Controle**|**comparaçã**<br>**o**|
||Insulina<br>(μU/mL)|Insulina<br>(μU/mL)|||||||||||
||3m: 9,94|3m: 9,55|||||||||||
||(2,41)|(3,11)|||||||||||
||6m: 9,28|6m: 8,22|||||||||||
||(3,25)|(3,68)|||||||||||
||12m: 8,94|12m: 8,02|||||||||||
||(2,39)|(3,78)|||||||||||
|||||Glicemia|Glicemia||Testosterona|Testosteron|||||
||QUICKI|QUICKI||(mg/dL)|(mg/dL)||(ng/mL)|a (ng/mL)|||||
|**Ahmad**|3m: 0,65|3m: 0,68||3m: 80,19|3m: 76,80||3m: 0,96|3m: 1,49|||||
|**et al.**|(0,02)|(0,02)|NR|(1,39)|(1,56)|NR|(0,60)|(0,45)|NR|NR|NR|NA|
|**2008**|6m: 0,67|6m: 0,72||6m: 82,61|6m: 78,00||6m: 0,92|6m: 1,06|||||
|**(129)**|(0,02)|(0,03)||(1,94)|(2,18)||(0,33)|(0,54)|||||
||12m: 0,66|12m: 0,70||12m: 81,94|12m: 77,40||12m: 0,90|12m: 1,01|||||
||(0,02)|(0,02)||(1,29)|(1,30)||(0,31)|(0,64)|||||
||HOMA|HOMA|||||||||||
||3m: 3,90|3m: 2,77|||||||||||
||(0,19)<br>6m: 3,84|(0,22)<br>6m: 2,58|||||||||||
||(0,20)|(0,20)|||||||||||
||12m: 2,76|12m: 1,90|||||||||||
||(0,17)|(0,16)|||||||||||
|**Billa et**<br>**l**|Insulina|Insulina||Glicemia|Glicemia||Testosterona|Testosteron|||||
|**a.**<br>**2009**|(μU/mL):|(μU/mL):|p<0,05|(mg/dL)|(mg/dL)|NS|(ng/mL)|a (ng/mL)|p<0,05|NR|NR|NA|
|<br>**(159)**|7,9 (2,5)|11,1 (6,3)||82,6 (9,2)|89,1 (11,9)||0,8 (0,6)|1,0 (0,7)|||||  
||**Insu**|**lina e relaciona**|**dos**|**Glicem**|**ia e relaciona**|**dos**|**Testoster**|**ona e relacion**|**ados**||**Outros**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**p para**<br>**comparação**|**Intervenção**|**Controle**|**p para**<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|**p para**<br>**comparaçã**<br>**o**|**Intervençã**<br>**o**|**Controle**|**p para**<br>**comparaçã**<br>**o**|
|**Bridger**<br>**et al.**<br>**2006**<br>**(130)**|Diferença<br>média em<br>relação ao<br>basal:<br>Insulina<br>(ASC<br>μU/mL*min<br>): −3662<br>QUICKI:<br>0,00<br>HOMA:|Diferença<br>média em<br>relação ao<br>basal:<br>Insulina (ASC<br>μU/mL*min):<br>2093<br>QUICKI: −0,01<br>HOMA: 0,86|Insulina:<br>p>0,05<br>(IC95%<br>−17.531;<br>6024)<br>QUICKI:<br>p>0,05<br>(IC95%:<br>−0,03; 0,05)<br>HOMA:<br>p>0,05<br>(IC95%:|Diferença<br>média em<br>relação ao<br>basal:<br>Glicemia<br>(mg/dL):<br>0,31|Diferença<br>média em<br>relação ao<br>basal:<br>Glicemia<br>(mg/dL):<br>0,36|p>0,05<br>(IC95%:<br>−3,42; 5,22)|Diferença<br>média em<br>relação ao<br>basal:<br>Testosterona<br>(ng/mL):<br>−38,3|Diferença<br>média em<br>relação ao<br>basal:<br>Testosteron<br>a (ng/mL):<br>−0,86|p<0,05<br>(IC95%:<br>−0,0; −0,29)|NR|NR|NA|
||−1,06||−9,26;5,42)||||||||||
|**Mohiyi**|Insulina:<br>11,76<br>mIU/ml<br>(2,95)|Insulina:<br>13,57 mIU/ml<br>(1,47)|||||Testosterona:<br>194 mmol/l|Testosteron<br>a: 2,04|||||
|**ddeen**|Razão|Razão||Glicemia:|Glicemia:||,<br>(019)|mmol/l|||||
|**et al.**<br>**2013**<br>**(131)**|glicemia /<br>insulina:<br>21,08 (6,71)|glicemia /<br>insulina: 7,91<br>(1,59)|NR|4,53 mmol/l<br>(0,17)|4,56 mmol/l<br>(0,16)|NR|,<br>FAI: 9,27<br>(2,33)|(0,18)<br>FAI: 8,11<br>(1,66)|NR|NR|NR|NA|
||QUICKI:<br>0,372<br>(0,016)|QUICKI: 0,336<br>(0,007)|||||||||||  
||**Insuli**|**na e relacion**|**ados**|**Glicem**|**ia e relaciona**|**dos**|**Testoster**|**ona e relacion**|**ados**||**Outros**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Autor,**||||||**p para**|||**p para**|||**p para**|
|**ano**|**Intervenção**|**Controle**|**p para**<br>**comparação**|**Intervenção**|**Controle**|<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|<br>**comparaçã**<br>**o**|**Intervençã**<br>**o**|**Controle**|<br>**comparaçã**<br>**o**|
||||||||Testosterona<br>(ng/mL):<br>6m: 0,7 (0,5)<br>12m: 0,7 (0,5)|Testosteron<br>a (ng/mL):<br>6m: 1,9<br>(0,3)<br>12m: 1,7<br>(0,4)<br>Androstene<br>diona|Testosteron<br>a: p<0,05<br>(6 e 12m)||||
|**Palomb**<br>**a et al.**<br>**2007**<br>**(160)**|NR|NR|NA|Taxa de<br>captação de<br>glicose<br>(mmol/kg x<br>min):<br>6m: 46,2 (5,5)<br>12m: 46,1<br>(5,6)|Taxa de<br>captação de<br>glicose<br>(mmol/kg x<br>min):<br>6m: 41,1<br>(5,7)<br>12m: 41,6<br>(5,4)|p<0,05<br>(6 e 12<br>meses)|Androstenedi<br>ona (ng/mL):<br>6m: 1,7 (0,2)<br>12m: 1,7 (0,3)<br>DHEAS<br>(ng/mL):<br>6m: 2579,2<br>(368,5)<br>12m: 2542,4<br>(442,2)<br>FAI (%):<br>6m: 6,4 (2,2)<br>12m: 6,6 (2,4)|(ng/mL):<br>6m: 1,7<br>(0,2)<br>12m: 1,8<br>(0,3)<br>DHEAS<br>(ng/mL):<br>6m: 2616,1<br>(368,5)<br>12m:<br>2652,9<br>(368,5)<br>FAI (%):<br>6m: 22,4<br>(5,7)<br>12m: 22,6<br>(4,6)|Androst.:<br>NS<br>DHEAS:<br>NS<br>FAI:<br>p<0,05<br>(6 e 12m)|LDL<br>(mg/dL):<br>6m: 61,9<br>(23,2)<br>12m: 61,9<br>(19,3)|LDL<br>(mg/dL):<br>6m: 69,6<br>(30,9)<br>12m: 69,6<br>(34,8)|p<0,05<br>(6 e 12<br>meses)|
|**Romer**<br>**o et al.**|NR|NR|NA|NR|NR|NA|NR|NR|NA|NR|NR|NA|  
||**Insul**|**ina e relaciona**|**dos**|**Glicem**|**ia e relacionad**|**os**|**Testoster**|**ona e relacio**|**nados**||**Outros**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Autor,**||||||**p para**|||**p para**|||**p para**|
|**ano**|**Intervenção**|**Controle**|**p para**<br>**comparação**|**Intervenção**|**Controle**|<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|<br>**comparaçã**<br>**o**|**Intervençã**<br>**o**|**Controle**|<br>**comparaçã**<br>**o**|
|**200**<br>**(132)**|||||||||||||
|||||||||||PAS: 107,1<br>(9,7)<br>PAD: 66,61<br>(9,8)<br>Triglicérides<br>(mg/dL):<br>111,39<br>(48,13)|PAS: 117<br>(16,2)<br>PAD: 72,7<br>(13,15)<br>Triglicérides<br>(mg/dL):<br>113,93<br>(56,08)||
|**Shaheb**<br>**rahimi**<br>**et al.**<br>**2016**<br>**(133)**|Insulinemia<br>(u/L): 15<br>(7,97)|Insulinemia<br>(u/L): 18,73<br>(10,14)|NR|Glicemia<br>(mg/dL):<br>81,46 (10,89)|Glicemia<br>(mg/dL):<br>83,25 (8,51)|NR|Testosterona<br>(ng/dL): 0,59<br>(0,39)|Testosteron<br>a (ng/dL):<br>0,79 (0,49)|NR|<br>HDL<br>(mg/dL):<br>45,79 (8,87)<br>LDL<br>(mg/dL):<br>85,46<br>(18,46)<br>Colesterol<br>total<br>(mg/dL):<br>156,36<br>(22,10)|HDL<br>(mg/dL):<br>48,11<br>(11,43)<br>LDL<br>(mg/dL):<br>96,21<br>(26,06)<br>Colesterol<br>total<br>(mg/dL):<br>167,07<br>(28,14)|NR|
|**Zahra**|Insulina:|Insulina:|Insulina:||||||||||
|**et al.**<br>**2016**<br>**(161)**|14,1 IU/L<br>(9,3)|18,6 IU/L<br>(6,4)|p>0,05<br>HOMA:|Glicemia:<br>100,8 (5,3)|Glicemia:<br>105,6 (6,1)|p>0,05|NR|NR|NA|NR|NR|NA|  
||**Insul**|**ina e relacion**|**ados**|**Glicem**|**ia e relacion**|**ados**|**Testoster**|**ona e relacio**|**nados**||**Outros**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Autor,**<br>**ano**|**Intervenção**|**Controle**|**p para**<br>**comparação**|**Intervenção**|**Controle**|**p para**<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|**p para**<br>**comparaçã**<br>**o**|**Intervençã**<br>**o**|**Controle**|**p para**<br>**comparaçã**<br>**o**|
||HOMA:|HOMA:|p>0,05||||||||||
||3,5 (2,3)|4,8 (1,7)|||||||||||  
3m: 3 meses; 6m: 6 meses; 12m: 12 meses; QUICKI: índice quantitativo de sensibilidade à insulina ( _quantitative insulin sensitivity check index_ ); HOMA: índice de resistência à insulina ( _insulin resistance index_ ); NR: não reportado; NA: não se aplica; NS: não significativo; ASC: área sob a curva; IC95%: intervalo de confiança de 95%; FAI: Índice de andrógenos livres em %; DHEAS: sulfato de dehidroepiandrosterona; LDL: lipoproteína de baixa densidade; PAS: pressão arterial sistólica; PAD: pressão arterial diastólica; HDL: lipoproteína de alta densidade. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
**Tabela 47 – Efeitos dos sensibilizadores de ação da insulina versus controle sobre desfechos reprodutivos e sinais de SOP.**  
|||**Hirsutismo**|||**Fertilidade**|||**Menstruação**||
|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Intervenção**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|
|**Ahmad et**<br>**al. 2008**<br>**(129)**|Escore FG:<br>3 meses: 8,63<br>(2,71)<br>6 meses: 6,51<br>(1,95)<br>12 meses: 6,21<br>(2,74)|Escore FG:<br>3 meses: 9,15 (1,91)<br>6 meses: 8,92 (1,63)<br>12 meses: 8,90<br>(1,71)|NR|Ovulação:<br>3 meses: 8/31<br>(26)<br>6 meses: 15/31<br>(48)<br>12 meses:<br>19/31 (61)|Ovulação:<br>3 meses: 7/30<br>(23)<br>6 meses: 15/30<br>(15)<br>12 meses:<br>22/30 (73)|NR|Menstruação<br>regular:<br>3 meses: 14/31<br>(45)<br>6 meses: 28/31<br>(90)<br>12 meses: 30/31<br>(96)|Menstruação<br>regular:<br>3 meses: 10/30<br>(33)<br>6 meses: 18/30<br>(60)<br>12 meses: 28/30<br>(90)|NR|
|**Billa et al.**<br>**2009(159)**|NR|NR|NA|Ovulação: 9/15<br>(60)|Ovulação: 4/15<br>(26,5)|NR|NR|NR|NA|
|**Bridger et**<br>**al. 2006**<br>**(130)**|Diferença média<br>em relação ao<br>basal:<br>Escore FG: 0|Diferença média em<br>relação ao basal:<br>Escore FG: 0|NR||||Retorno<br>menstruação:<br>10/11 (91)|Retorno<br>menstruação:<br>4/11 (36)|NR|  
|||**Hirsutismo**|||**Fertilidade**|||**Menstruação**||
|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Intervenção**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Intervenção**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|
|**Mohiyiddee**||||Volume ovariano<br>(ml): 7,45 (0,88)|Volume ovariano<br>(ml): 7,95 (0,49)|NR|Melhora na|Melhora na||
|**n et al.**<br>**2013 (131)**|NR|NR|NA|Folículos<br>ovarianos: 13,18<br>(1,13)|Folículos<br>ovarianos: 13,61<br>(1,29)||menstruação:<br>11/14 (78,6)|menstruação:<br>7/14 (50)|p=0,24|
|**Palomba et**<br>**al. 2007**<br>**(160)**|Escore FG:<br>6 meses: 6,1 (2,4)<br>12 meses: 5,8<br>(2,1)|Escore FG:<br>6 meses: 10,7 (1,8)<br>12 meses: 11,1 (1,9)|p<0,05 (6 e<br>12 meses)|NR|NR|NA|NR|NR|NA|
|**Romero et**<br>**al. 2004**<br>**(132)**|NR|NR|NA|Recuperação do<br>ciclo ovulatório<br>normal: 13/15<br>(87)|Recuperação do<br>ciclo ovulatório<br>normal: 5/11<br>(45,5)|NR|Recuperação da<br>menstruação<br>normal (pelo<br>menos 3 ciclos|Recuperação da<br>menstruação<br>normal (pelo<br>menos 3 ciclos|NR|
|||||Sucesso na<br>gravidez: 5/12<br>(42)|Sucesso na<br>gravidez: 1/5 (20)||consecutivos):<br>15/16 (93,8)|consecutivos):<br>11/13 (85)||
|**Shahebrahi**<br>**mi et al.**<br>**2016 (133)**|Acne:<br>12/28 (42,9)<br>Alopécia:<br>11/28 (39,3)|Acne:<br>5/28 (17,9)<br>Alopécia:<br>9/28 (32,1)|Acne:<br>p=0,735<br>Alopécia:<br>p=0,781|NR|NR|NA|Oligomenoreia:<br>13/28 (46,4)<br>Amenorreia:<br>0|Oligomenoreia:<br>11/28 (39,3)<br>Amenorreia:<br>1/28 (3,6)|Oligomenor<br>eia:<br>p=0,525<br>Amenorreia<br>: NR|
|**Zahra et al.**<br>**2016** **(161)**|NR|NR|NA|Volume final dos<br>ovários (mm): 9,1|Volume final dos<br>ovários (mm):<br>11,1|p<0,05|NR|NR|NA|  
Escore FG: escore Ferriman–Gallwey; NR: não reportado; NA: não se aplica. Quando não especificado, dados foram apresentados como média (desvio padrão) ou n/N (%).  
**RECOMENDAÇÃO:** A metformina é recomendada em mulheres com SOP que não atingiram as metas de controle metabólico em uso de AHC ou que apresentam contraindicação a esses. As doses mais altas (até 2,50g/dia), quando toleradas, devem ser indicadas, por levar a resultados melhores em relação a dose inferior (1,5g/dia) (27, 64-66). **(GRADE: recomendação condicional a favor; qualidade da evidência: baixa).**  
As tiazolidinedionas (rosiglitazona e pioglitazona) não são recomendadas em mulheres com SOP, por não haver evidências a favor de superioridade das mesmas em relação à metformina em parâmetros metabólicos e hormonais (49). É importante salientar que a pioglitazona pode levar a ganho de peso, devido à retenção hídrica, e tem potencial teratogênico, não devendo ser utilizada (67). **(GRADE: recomendação forte contra; qualidade da evidencia: alta).**  
**Questão de Pesquisa 12:** <mark>Qual a eficácia e segurança da metformina em mulheres grávidas com SOP?</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>MEDLINE via Pubmed:</mark>** -->
<mark>(((((("Polycystic Ovary Syndrome"[Mesh] OR Ovary Syndrome, Polycystic OR Syndrome, Polycystic Ovary OR Stein Leventhal Syndrome OR Sclerocystic Ovary Syndrome))) AND ("Metformin"[Mesh] OR Metformin Hydrochloride OR Metformin HCl)))) AND ((("Pregnant Women"[Mesh] OR pregnant woman OR pregnant women)) OR ("Pregnancy"[Mesh] OR Pregnancies OR Gestation))</mark>  
<mark>Total: 485 referências</mark>  
<mark>Data acesso 10/06/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **<mark>EMBASE:</mark>** -->
<mark>'ovary polycystic disease'/exp AND [embase]/lim OR 'ovary polycystic disease' AND [embase]/lim AND ('metabolic disorder'/exp AND [embase]/lim OR 'metabolic disorder' AND [embase]/lim) AND ('insulin sensitizing agent'/exp OR 'insulin sensitizing agent' AND [embase]/lim)</mark>  
<mark>Total: 379 referências</mark>  
<mark>Data acesso 10/06/2017</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **2)** **<mark>Seleção das evidências</mark>** -->
<mark>A busca nas bases resultou em 864 referências (485 no MEDLINE e 379 no EMBASE). Destas, 244 estavam duplicadas e foram excluídas, restando 620 referências para triagem pela leitura de título e resumo. Quarenta e cinco referências tiveram seus textos avaliados na íntegra, para confirmação da elegibilidade. Destes, 37 foram excluídas devido às razões descritas a seguir.</mark>  
<mark>Foram identificadas nove revisões sistemáticas, porém apenas três foram incluídas para a elaboração deste relatório. Quatro revisões foram excluídas em detrimento de outras mais recentes e completas. Duas revisões avaliaram o efeito da metformina apenas no período pré-gestacional.</mark>  
<mark>Vinte e um estudos primários foram excluídos por terem sido incluídos nas três revisões sistemáticas com meta-análise elegíveis. Adicionalmente, cinco estudos foram excluídos por serem análises post hoc de estudos primários, um estudo avaliou apenas desfechos em filhos de mulheres com SOP que utilizaram metformina durante a gestação, um estudo não avaliou desfechos clínicos de interesse, outro incluiu um subgrupo de apenas sete pacientes com SOP randomizados para receber metformina ou placebo e não descreveu em que momento ocorreu a gestação (antes ou após receber as intervenções), e dois utilizaram como comparador pacientes sem SOP impossibilitando a avaliação do efeito da intervenção.</mark>  
<mark>Por fim, oito estudos foram considerados elegíveis (162-169), sendo três revisões sistemáticas (162-164) e cinco estudos comparativos não randomizados (165-169), um deles publicado como resumo de congresso (168).</mark>

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **3)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>A Tabela 53 apresenta as c</mark> aracterísticas das revisões sistemáticas e meta-análises que avaliaram os estudos que investigaram o efeito da metformina em mulheres grávidas com SOP. A Tabela 54 apresenta as c <mark>aracterísticas dos pacientes incluídos nas revisões. A Tabela 55 apresenta as metaanálises avaliando de</mark> sfechos relacionados à gestação com o uso da metformina em mulheres com SOP. A Tabela 56 <mark>apresenta as c</mark> aracterísticas dos estudos primários que avaliaram os estudos que investigaram o efeito da metformina em mulheres grávidas com SOP. A Tabela 57 apresenta as <mark>características dos pacientes incluídos nesses estudos e a Tabela 58 apresenta os d</mark> esfechos apresentados nos estudos primários.  
**Tabela 48 – Características das revisões sistemáticas e meta-análises que avaliaram os estudos que investigaram o efeito da metformina em mulheres grávidas com SOP.**  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**N de estudos incluídos e**<br>**total de participantes**|**Risco de viés**|
|---|---|---|---|---|
|**Gilbert et al. 2006**<br>**(162)**|Revisão sistemática e meta-análise de<br>estudos comparativos|Avaliar os estudos que investigaram o<br>uso de metformina durante a gravidez<br>de mulheres com SOP e sua<br>associação com más formações fetais|5 estudos, totalizando<br>202 participantes|Alto. Não há descrição adequada da<br>metodologia de revisão sistemática, os<br>estudos incluídos não tiveram suas<br>características extraídas e não foram<br>avaliados metodologicamente|
|**Tan et al. 2016**<br>**(163)**|Revisão sistemática e meta-análise de<br>estudos comparativos prospectivos e<br>retrospectivos|Avaliar os estudos que investigaram o<br>uso da metformina em mulheres<br>grávidas com SOP em desfechos<br>relacionados àgestação|11 estudos, totalizando<br>1496 participantes|Moderado. Os autores não avaliaram o<br>risco de viés dos estudos incluídos|
|**Zhuo et al. 2014**<br>**(164)**|Revisão sistemática e meta-análise de<br>estudos comparativos|Avaliar os estudos que investigaram o<br>uso da metformina em mulheres<br>grávidas com SOP no desfecho<br>diabetes gestacional|13 estudos, totalizando<br>1319 participantes|Moderado. Não utilizou uma ferramenta<br>validada para avaliação de risco de viés nos<br>estudos incluídos, só avaliou o risco de viés<br>dos ensaios clínicos randomizados. Os<br>estudos incluídos na revisão sistemática,<br>segundo os autores, apresentaram baixo<br>risco de viés|  
N: número de estudos; SOP: síndrome dos ovários policísticos.  
**Tabela 49 – Características dos pacientes incluídos nas revisões sistemáticas e meta-análises.**  
|**Autor, ano**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Intervenção**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Controle**|
|---|---|---|---|---|---|---|
|**Gilbert et al.**<br>**2006 (162)**|Metformina, não descreve as<br>doses utilizadas nos estudos|Mulheres não tratadas com metformina|NR|NR|NR|NR|
|**Tan et al. 2016**<br>**(163)**|Metformina<br>1000-2500 mg/dia|Mulheres que descontinuaram<br>metformina após diagnóstico de<br>gravidez, ou placebo ou não tratamento|NR|NR|Variação entre<br>27,1-32,1|Variação entre 26,1-<br>33,2|
|**Zhuo et al.**<br>**2014 (164)**|Metformina<br>1500-2500 mg/dia|Placebo ou não tratamento|Variação entre<br>28-30|Variação<br>entre<br>26-31|Variação entre<br>29,2-33,5|Variação entre<br>27,97-39,3|  
IMC: índice de massa corporal; mg: miligramas; NR: não reportado.  
**Tabela 50 – Desfechos combinados (meta-análise) relacionados à gestação com o uso da metformina em mulheres com SOP.**  
|**Autor, ano**|**Diabetes Gestacional**<br>**Medidas de Associação**<br>**(IC95%); I**<sup>**2**</sup>|**p para a**<br>**comparação**|**Aborto**<br>**Medidas de Associação**<br>**(IC95%); I**<sup>**2**</sup>|**p para a**<br>**comparaçã**<br>**o**|**Parto prematuro**<br>**Medidas de Associação**<br>**(IC95%); I**<sup>**2**</sup>|**p para a**<br>**compar**<br>**ação**|**Anormalidades fetais**<br>**Medidas de Associação**<br>**(IC95%); I**<sup>**2**</sup>|**p para a**<br>**comparação**|
|---|---|---|---|---|---|---|---|---|
||||||||5 estudos, 202||
|**Gilbert et al.**<br>**2006 (162)**|NR|NA|NR|NA|NR|NA|participantes: OR 0,33<br>(IC95% 0,07-1,56);<br>I<sup>2</sup>=0%|p=0,16|
|**Tan et al.**<br>**2016 (163)**|**ECR**(3 estudos): OR<br>0,75<br>(IC95% 0,16-3,42);<br>I<sup>2</sup>=70%<br>**NECR**(4 estudos): OR<br>0,14<br>(IC95% 0,09-0,24);<br>I<sup>2</sup>=0%|p=0,71<br>p<0,00001|**ECR**(1 estudo): OR 1,04<br>(IC95% 0,06-17,38);<br>I<sup>2</sup>=NA<br>**NECR**(5 estudos): OR<br>0,19 (IC95% 0,12-0,30);<br>I<sup>2</sup>=0%|p=0,98<br>p<<br><0,00001|**ECR**(3 estudos): OR 0,38<br>(IC95% 0,16-0,90); I<sup>2</sup>=0%<br>**NECR**(3 estudos): OR 0,29<br>(IC95% 0,13- 0,67); I<sup>2</sup>=18%|p=0,03<br>p=0,004|**ECR**(1 estudo): OR 0,91<br>(IC95% 0,17- 4,77);<br>I<sup>2</sup>=NA<br>**NECR**(5 estudos): OR<br>0,78 (IC95% 0,14- 4,27);<br>I<sup>2</sup>=0%|p=0,91<br>p=0,78|
|**Zhuo et al.**<br>**2014 (164)**|**ECR**(5 estudos, 289<br>participantes):<br>OR 1,07 (IC95% 0,60-<br>1,92); I<sup>2</sup>=0%<br>**NECR**(8 estudos, 1030<br>participantes): OR 0,19<br>(IC95% 0,13, 0,27);<br>I<sup>2</sup>=0%|p=0,82<br>p<0,00001|NR|NA|NR|NA|NR|NA|  
IC95%: Intervalo de confiança de 95%; I<sup>2</sup> : estatística de heterogeneidade de _Higgins_ ; NR: não reportado; NA: não se aplica; ECR: ensaios clínicos randomizados; NECR: estudos comparativos não randomizados; OR: razão de chances ( _odds ratio_ ).  
**Tabela 51 – Características dos estudos primários avaliando o efeito da metformina em mulheres grávidas com SOP.**  
|**Autor, ano**|**Desenho do estudo**|**População e objetivo**|**Detalhes da Intervenção**|**Detalhes do Controle**|**Risco de viés**|
|---|---|---|---|---|---|
|**Ainuddin et al.**<br>**2015 (165)**|Estudo comparativo não<br>randomizado (o grupo<br>intervenção foi prospectivo e o<br>controle retrospectivo)|Avaliar se a terapia com<br>metformina na gravidez reduz o<br>desenvolvimento de diabetes<br>gestacional em mulheres com<br>SOP|Metformina<br>1500mg/dia, em 3 doses|Sem uso de metformina<br>ou que descontinuou a<br>metformina ao<br>diagnóstico de gravidez|Alto: Não houve ajuste nas<br>análises para nenhuma das<br>variáveis de base, em que<br>algumas foram significantemente<br>diferentes entre osgrupos|
|**Al-Biate, 2015**<br>**(166)**|Estudo comparativo não<br>randomizado prospectivo|Avaliar a eficácia da terapia com<br>metformina na redução da perda<br>precoce da gravidez em<br>mulheresgrávidas com SOP|Metformina<br>1000mg/dia|Descontinuou a<br>metformina ao<br>diagnóstico de gravidez|Alto: Não houve ajuste nas<br>análises para nenhuma das<br>variáveis de base|
|**Kovo et al. 2006**<br>**(167)**|Estudo comparativo não<br>randomizado retrospectivo|Avaliar o efeito do tempo de<br>exposição à metformina em<br>neonatos de mulheres com SOP|Metformina<br>1500mg/dia no 2° ou 3°<br>trimestre ou até final<br>gestação|Metformina 1500mg/dia<br>até final 1° trimestre|Alto: Não houve ajuste nas<br>análises para nenhuma das<br>variáveis de base, análise<br>retrospectiva de dados|
|**Macesic et al.**<br>**2013 (168)**|Estudo comparativo não<br>randomizado|Avaliar o uso da metformina em<br>desfechos relacionados à<br>gestação em mulheres com SOP|Metformina<br>1500mg/dia + mudanças<br>estilo de vida|Mudanças estilo de vida|Alto: Não houve ajuste nas<br>análises para nenhuma das<br>variáveis de base, ausência de<br>informações sobre desfecho|
|**Sohrabvand et**<br>**al. 2009 (169)**|Estudo comparativo não<br>randomizado prospectivo|Determinar o efeito do uso de<br>metformina até o final de 8-12<br>semanas de gestação na<br>incidência de aborto espontâneo<br>e compará-lo com o grupo que<br>descontinuou a metformina após<br>o diagnóstico degravidez|Metformina<br>1500mg/dia|Mulheres que<br>descontinuaram<br>metformina em 5-6<br>semanas de gestação|Alto: Não houve ajuste nas<br>análises para nenhuma das<br>variáveis de base|  
SOP: síndrome dos ovários policísticos; mg: miligramas.  
**Tabela 52 – Características dos pacientes incluídos nos estudos primários avaliando o efeito da metformina em mulheres grávidas com SOP.**  
|**Autor, ano**|**N intervenção**|**N controle**|**Idade**<br>**Intervenção**|**Idade**<br>**Controle**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Intervenção**|**IMC (kg/m**<sup>**2**</sup>**)**<br>**Controle**|
|---|---|---|---|---|---|---|
|**Ainuddin et al.**<br>**2015(165)**|50|32|29,94 (2,87)|30,13 (2,24)|30,97 (3,34)|30,93 (3,05)|
|**Al-Biate, 2015**<br>**(166)**|56|50|28,1 (1,6)|28,6 (1,5)|28,4 (1,8)|27,8 (1,3)|
|**Kovo et al. 2006**<br>**(167)**|13|29|Toda coorte:|30,1 (4,2)|Toda a coorte:|27,7 (6,9)|
|**Macesic et al. 2013**<br>**(168)**|43|40|27,32 (2,54)|28,13 (2,24)|30,12 (0,78)|27,83 (0,96)|
||Até 8 semanas de||Até 8 semanas:||Até 8 semanas:||
|**Sohrabvand et al.**<br>**2009 (169)**|gestação: 25<br>Até 12 semanas de|25|28,72 (3,57)<br>Até 12 semanas:|27,96 (5,70)|25,19 (16,39)<br>Até 12 semanas:|24,5 (3,17)|
||gestação: 25||26,80 (3,88)||27,55 (5,17)||  
IMC: índice de massa corporal. Dados apresentados como média (desvio-padrão).  
**Tabela 53 – Desfechos relacionados à gestação com o uso da metformina em mulheres com SOP.**  
||**Diab**|**etes Gestaci**|**onal**||**Aborto**||**Par**|**to premat**|**uro**|**Ano**|**rmalidade**|**s fetais**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Intervenção**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Intervençã**<br>**o**|**Controle**|**p para a**<br>**comparaçã**<br>**o**|**Intervençã**<br>**o**|**Control**<br>**e**|**p para a**<br>**comparaçã**<br>**o**|**Intervençã**<br>**o**|**Control**<br>**e**|**p para a**<br>**comparação**|
|**Ainuddin**<br>**et al. 2015**<br>**(165)**|5/50 (10)|11/32<br>(34,4)|p<0,05|NR|NR|NA|NR|NR|NA|NR|NR|NA|
|**Al-Biate,**<br>**2015 (166)**|NR|NR|NA|5/56 (9)|18/50 (36)|p<0,01|NR|NR|NA|NR|NR|NA|
|**Kovo et al.**<br>**2006 (167)**|9/13 (69)|12/29<br>(41,4)|p=0,085|NR|NR|NA|NR|NR|NA|NR|NR|NA|
|**Macesic et**|||||||||||||
|**al. 2013**<br>**(168)**|NR (6,8)|NR (24)|p<0,01|NR|NR|NA|NR|NR|NA|NR|NR|NA|
|||||Até 8|||||||||
|**Sohrabvan**<br>**d et al.**<br>**2009 (169)**|NR|NR|NA|semanas:<br>1/25 (4)<br>Até 12<br>semanas:<br>2/25(8)|1/25 (4)|p>0,05|NR|NR|NA|NR|NR|NA|  
NR: não reportado; NA: não se aplica. Dados apresentados como proporção n/N (%).

---

<!-- METADADOS: doenca: Síndrome de Ovários Policísticos | secao: **4) Referências** -->
1. de Melo AS DS, de Carvalho Cavalli R, Cardoso VC, Bettiol H, Barbieri MA, Ferriani RA, Vieira CS,. Pathogenesis of polycystic ovary syndrome: multifactorial assessment from the foetal stage to menopause. Reproduction. 2015;150(1):R11-24.  
2. Sir-Petermann T, Hitchsfeld C, Maliqueo M, Codner E, Echiburú B, Gazitua R, et al. Birth weight in offspring of mothers with polycystic ovarian syndrome. Human reproduction. 2005;20(8):2122-6.  
3. Baptiste CG BM, Trottier A, Baillargeon JP. Insulin and hyperandrogenism in women with polycystic ovary syndrome. The Journal of steroid biochemistry and molecular biology. 2010;122(1):4252.  
4. Dumesic DA, Lobo RA. Cancer risk and PCOS. Steroids. 2013;78(8):782-5.  
5. Qin JZ, Pang LH, Li MJ, Fan XJ, Huang RD, Chen HY. Obstetric complications in women with polycystic ovary syndrome: a systematic review and meta-analysis. Reproductive Biology and Endocrinology. 2013;11(1):56.  
6. Sirmans SM, Pate KA. Epidemiology, diagnosis, and management of polycystic ovary syndrome. Clinical epidemiology. 2014;6:1-13.  
7. The Rotterdam ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group. Revised 2003 consensus on diagnostic criteria and long-term health risks related to polycystic ovary syndrome. Fertility and sterility. 2004;81(1).  
8. Rosenfield RL, Ehrmann DA. The pathogenesis of polycystic ovary syndrome (PCOS): the hypothesis of PCOS as functional ovarian hyperandrogenism revisited. Endocrine reviews. 2016;37(5):467-520.  
9. Spritzer PM. Polycystic ovary syndrome: reviewing diagnosis and management of metabolic disturbances. Arquivos Brasileiros de Endocrinologia & Metabologia. 2014;58(2):182-7.  
10. Azziz R, Carmina E, Dewailly D, Diamanti-Kandarakis E, Escobar-Morreale HF, Futterweit W, et al. The Androgen Excess and PCOS Society criteria for the polycystic ovary syndrome: the complete task force report. Fertility and sterility. 2009;91(2):456-88.  
11. Goodman NF CR, Futterweit W, Glueck JS, Legro RS, Carmina E. American Association of Clinical Endocrinologists, American College of Endocrinology, and androgen excess and PCOS society disease state clinical review: guide to the best practices in the evaluation and treatment of polycystic ovary syndrome-part 1. Endocrine Practice. 2015;25(11):1291-300.  
12. Goodman NF CR, Futterweit W, Glueck JS, Legro RS, Carmina E. American Association of Clinical Endocrinologists, American College of Endocrinology, and Androgen Excess and PCOS Society Disease State clinical review: guide to the best practices in the evaluation and treatment of polycystic ovary syndrome-Part 2. Endocrine Practice. 2015b;21(12):1415-26.  
13. National Institutes of Health. Evidence-based methodology workshop on polycystic ovary syndrome. National Institutes of Health. December 3-5, 2012. .  
14. Broekmans FJ KE, Valkenburg O, Laven JS, Eijkemans MJ, Fauser BC. . PCOS according to the Rotterdam consensus criteria: change in prevalence among WHO‐II anovulation and association with metabolic factors. BJOG: An International Journal of Obstetrics & Gynaecology. 2006;113(10):1210-7.  
15. Aziz R CE, Dewailly D, Diamanti-Kandarakis E, Escobar-Morreale HF, Futterweit W. Position statement: criteria for defining polycystic ovary syndrome as a predominantly hyperandrogenic syndrome: an androgen excess society guideline. J Clin Endocrinol Metab. 2006;91:4237-45.  
16. Laven JS, Mulders AG, Visser JA, Themmen AP, De Jong FH, Fauser BC, et al. Anti-Mullerian hormone serum concentrations in normoovulatory and anovulatory women of reproductive age. The Journal of Clinical Endocrinology & Metabolism. 2004;89(1):318-23.  
17. Vries LWA, Phillipa M. Clinical Criteria Remain Paramount for the Diagnosis of Polycystic Ovary Syndrome in the Adolescent Age Group.  European Society for Paediatric Endocrinology2016.  
18. Hart R DD, Norman RJ, Franks S, Dickinson JE, Hickey M, Sloboda DM. Serum antimullerian hormone (AMH) levels are elevated in adolescent girls with polycystic ovaries and the polycystic ovarian syndrome (PCOS). Fertility and sterility. 2010;94(3):1118-21.  
19. Silfen ME DM, Manibo AM, Lobo RA, Jaffe R, Ferin M, Levine LS, Oberfield SE. Early endocrine, metabolic, and sonographic characteristics of polycystic ovary syndrome (PCOS): comparison between nonobese and obese adolescents. The Journal of Clinical Endocrinology & Metabolism. 2003;88(10):4682-8.  
20. Hickey M DD, Atkinson H, Sloboda DM, Franks S, Norman RJ, Hart R. Clinical, ultrasound and biochemical features of polycystic ovary syndrome in adolescents: implications for diagnosis. Human reproduction. 2011;26(6):1469-77.  
21. Villarroel C, López P, Merino PM, Iñiguez G, Codner E, Author A, et al. Evaluation of diagnostic criteria of polycystic ovary syndrome (PCOS) during adolescence. Hormone Research in Paediatrics. 2013;80 SUPPL. 1:172-3.  
22. Kenigsberg LE AC, Sin S, Shifteh K, Isasi CR, Crespi R, Ivanova J, Coupey SM, Heptulla RA, Arens R. Clinical utility of magnetic resonance imaging and ultrasonography for diagnosis of polycystic ovary syndrome in adolescent girls. . Fertility and sterility. 2016;104(5):1302-9.  
23. Youngster M WV, Blood EA, Barnewolt CE, Emans SJ, Divasta AD,. Utility of ultrasound in the diagnosis of polycystic ovary syndrome in adolescents. Fertility and sterility. 2014;102(5):1432-8.  
24. Villa P RA, Sagnella F, Moruzzi MC, Mariano N, Lassandro AP, Pontecorvi A, Scambia G, Lanzone A. Ovarian volume and gluco‐insulinaemic markers in the diagnosis of PCOS during adolescence. Clinical endocrinology. 2013;78(2):285-90.  
25. Shah B PL, Milla S, Kessler M, David R. Endometrial thickness, uterine, and ovarian ultrasonographic features in adolescents with polycystic ovarian syndrome. Journal of pediatric and adolescent gynecology. 2010;23(3):146-52.  
26. Rosenfield RL, Ehrmann DA, Littlejohn EE. Adolescent polycystic ovary syndrome due to functional ovarian hyperandrogenism persists into adulthood. The Journal of Clinical Endocrinology & Metabolism 2015;100(4):1537-43.  
27. Legro RS, Arslanian SA, Ehrmann DA, Hoeger KM, Murad MH, Pasquali R, et al. Diagnosis and treatment of polycystic ovary syndrome: an Endocrine Society clinical practice guideline. The Journal of Clinical Endocrinology & Metabolism. 2013;98(12):4565-92.  
28. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Atenção ao pré-natal de baixo risco [recurso eletrônico] /Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica,. In: Cadernos de Atenção Básica n, editor. Brasília: Editora do Ministério da Saúde; 2013. p. 1-318.  
29. Boomsma CM, Eijkemans MJ, Hughes EG, Visser GH, Fauser BC, Macklon NS. A meta-analysis of pregnancy outcomes in women with polycystic ovary syndrome. . Human reproduction update. 2006;12(6):673-83.  
30. Lim SS, Norman RJ, Davies MJ, Moran LJ HS, Norman RJ, Teede HJ. The effect of obesity on polycystic ovary syndrome: a systematic review and meta‐analysis. Obesity Reviews. 2013;14(2):95-109.  
31. Moran LJ, Hutchison SK, Norman RJ, Teede HJ. Lifestyle changes in women with polycystic ovary syndrome. Cochrane Database Syst Rev. 2011;7(2).  
32. Kiddy DS, Hamilton‐Fairley D, Bush A, Short F, Anyaoku V, Reed MJ, et al. Improvement in endocrine and ovarian function during dietary treatment of obese women with polycystic ovary syndrome. Clinical endocrinology. 1992;36(1):105-11.  
33. Thessaloniki ESHRE/ASRM-Sponsored PCOS Consensus Workshop Group. Consensus on infertility treatment related to polycystic ovary syndrome. Fertility and sterility. 2008;89(3):505-22.  
34. Mara Spritzer P, Rocha Barone C, Bazanella de Oliveira F. Hirsutism in Polycystic Ovary Syndrome: Pathophysiology and Management. Current pharmaceutical design. 2016;22(36):5603-13.  
35. Pasquali R GA. Therapy of endocrine disease:Treatment of hirsutism in the polycystic ovary syndrome. European journal of endocrinology. 2014;170(2):R75-90.  
36. Colonna L PV, Lello S, Sorge R, Raskovic D, Primavera G. Skin improvement with two different oestroprogestins in patients affected by acne and polycystic ovary syndrome: clinical and instrumental evaluation. Journal of the European Academy of Dermatology and Venereology. 2012;26(11):1364-71.  
37. Bhattacharya SM JA. Comparative study of the therapeutic effects of oral contraceptive pills containing desogestrel, cyproterone acetate, and drospirenone in patients with polycystic ovary syndrome. Fertility and sterility. 2012;98(4):1053-9.  
38. van Zuuren EJ, Fedorowicz Z, Carter B, Pandis N. Interventions for hirsutism (excluding laser and photoepilation therapy alone. The Cochrane Library. 2015;28(4):CD010334.  
39. Gallo MF NK, Grimes DA, Lopez LM, Schulz KF. 20 microg versus> 20 microg estrogen combined oral contraceptives for contraception. Cochrane Database of Systematic Reviews. 2011;1:CD003989.  
40. Li J, Ren J, Sun W. A comparative systematic review of Yasmin (drospirenone pill) versus standard treatment options for symptoms of polycystic ovary syndrome. . European Journal of Obstetrics & Gynecology and Reproductive Biology. 2017;210:13-21.  
41. Kriplani A PA, Agarwal N, Kulshrestha V, Kumar A, Ammini AC. Effect of oral contraceptive containing ethinyl estradiol combined with drospirenone vs. desogestrel on clinical and biochemical parameters in patients with polycystic ovary syndrome. Contraception. 2010;82(2):139-46.  
42. Pehlivanov B MM. Efficacy of an oral contraceptive containing drospirenone in the treatment of women with polycystic ovary syndrome. The European Journal of Contraception & Reproductive Health Care. 2007;12(1):30-5.  
43. Battaglia C, Mancini F, Fabbri R, Persico N, Busacchi P, Facchinetti F, et al. Polycystic ovary syndrome and cardiovascular risk in young patients treated with drospirenone-ethinylestradiol or contraceptive vaginal ring. A prospective, randomized, pilot study. Fertility and sterility. 2010;94(4):1417-25.  
44. Stegeman BH, de Bastos M, Rosendaal FR, van Hylckama Vlieg A, Helmerhorst FM, Stijnen T, et al. Different combined oral contraceptives and the risk of venous thrombosis: systematic review and network meta-analysis. Bmj. 2013;347:f5298.  
45. Amiri M TF, Nahidi F, Kabir A, Azizi F, Carmina E,. Effects of oral contraceptives on metabolic profile in women with polycystic ovary syndrome: A meta-analysis comparing products containing cyproterone acetate with third generation progestins. Metabolism. 2017;73:22-35.  
46. Halperin IJ SKS, Stroup DF, Laredo SE. The association between the combined oral contraceptive pill and insulin resistance, dysglycemia and dyslipidemia in women with polycystic ovary syndrome: a systematic review and meta-analysis of observational studies. Human Reproduction. 2010;26(1):191-201.  
47. Domecq JP PG, Mullan RJ, Sundaresh V, Wang AT, Erwin PJ, Welt C, Ehrmann D, Montori VM, Murad MH. Adverse effects of the common treatments for polycystic ovary syndrome: a systematic review and meta-analysis. The Journal of Clinical Endocrinology & Metabolism. 2013;98(12):4646-54.  
48. World Health Organization. Medical Eligibility Criteria for Contraceptive Use, 5th edition. 5th ed. Geneva: World Health Organization; 2015.  
49. Li XJ YY, Liu CQ, Zhang W, Zhang HJ, Yan B, Wang LY, Yang SY, Zhang SH. Metformin vs thiazolidinediones for treatment of clinical, hormonal and metabolic characteristics of polycystic ovary syndrome: a meta‐analysis. Clinical endocrinology. 2011;74(3):332-9.  
50. Naderpoor N SS, de Courten B, Misso ML, Moran LJ, Teede HJ. Metformin and lifestyle modification in polycystic ovary syndrome: systematic review and meta-analysis. Human reproduction update. 2015;21(5):560-74.  
51. Tang T LJ, Norman RJ, Yasmin E, Balen AH. Insulin‐sensitising drugs (metformin, rosiglitazone, pioglitazone, D‐chiro‐inositol) for women with polycystic ovary syndrome, oligo amenorrhoea and subfertility. . The Cochrane Library. 2012(5):CD003053.  
52. Leelaphiwat S JT, Lertvikool S, Tabcharoen C, Sukprasert M, Rattanasiri S, Weerakiet S,. Comparison of desogestrel/ethinyl estradiol plus spironolactone versus cyproterone acetate/ethinyl estradiol in the treatment of polycystic ovary syndrome: A randomized controlled trial. Journal of Obstetrics and Gynaecology Research. 2015;41(3):402-10.  
53. Spritzer PM LK, Mattiello S, Lhullier F. Spironolactone as a single agent for long‐term therapy of hirsute patients. Clinical endocrinology. 2000;52(5):587-94.  
54. ciproterona) Aad. Farm. Resp.: Dra. Dirce Eiko Mimura CRF-SP nº 16532. Fabricado por: Delpharm Lille S.A.S. Lys Lez Lannoy – França; Embalado por: Schering do Brasil, Química e Farmacêutica Ltda. São Paulo – SP; Importado por:Bayer S.A. Rua Domingos Jorge, 1.100 04779-900 – Socorro - São Paulo – SP. Bula de Remédio. 2018.  
55. van der Spuy ZM, Le Roux PA, Matjila MJ. Cyproterone acetate for hirsutism. The Cochrane Library. 2003;4:CD001125.  
56. Carmina E LR. A comparison of the relative efficacy of antiandrogens for the treatment of acne in hyperandrogenic women. Clinical endocrinology. 2002;57(2):231-4.  
57. Swiglo BA CM, Flynn DN, Kurtz DM, LaBella ML, Mullan RJ, Erwin PJ, Montori VM,. Antiandrogens for the treatment of hirsutism: a systematic review and metaanalyses of randomized controlled trials. The Journal of Clinical Endocrinology & Metabolism. 2008;93(4):1153-60.  
58. Luque-Ramírez M Al-BF, Botella-Carretero JI, Martínez-Bermejo E, Lasunción MA, EscobarMorreale HF. Comparison of ethinyl-estradiol plus cyproterone acetate versus metformin effects on classic metabolic cardiovascular risk factors in women with the polycystic ovary syndrome. The Journal of Clinical Endocrinology & Metabolism. 2007 92(7):2453-61.  
59. Mazza A FB, Guzzi P, D'Orrico B, Malaguarnera R, Veltri P, Fava A, Belfiore A. . In PCOS patients the addition of low-dose spironolactone induces a more marked reduction of clinical and biochemical hyperandrogenism than metformin alone. Nutrition, Metabolism and Cardiovascular Diseases 2014;24(2):132-9.  
60. Wu J ZY, Jiang Y, Cao Y. Effects of metformin and ethinyl estradiol-cyproterone acetate on clinical, endocrine and metabolic factors in women with polycystic ovary syndrome. Gynecological Endocrinology. 2008;24(7):392-8.  
61. Spritzer PM BC, Oliveira FB. Hirsutism in Polycystic Ovary Syndrome: Pathophysiology and Management. Curr Pharm Des. 2016;22(36):5603-13.  
62. Du Q WY, Yang S, Wu B, Han P, Zhao YY. . A systematic review and meta-analysis of randomized controlled trials comparing pioglitazone versus metformin in the treatment of polycystic ovary syndrome. Current medical research and opinion. 2012;28(5):723-30.  
63. Li XJ YY, Liu CQ, Zhang W, Zhang HJ, Yan B, Wang LY, Yang SY, Zhang SH. . Metformin vs thiazolidinediones for treatment of clinical, hormonal and metabolic characteristics of polycystic ovary syndrome: a meta‐analysis. Clinical endocrinology. 2011;74(3):332-9.  
64. Bruno RV dÁM, Neves FB, Nardi AE, Crespo CM, Sobrinho AT. Comparison of two doses of metformin (2.5 and 1.5 g/day) for the treatment of polycystic ovary syndrome and their effect on body mass index and waist circumference. Fertility and sterility. 2007;88(2):510-2.  
65. Harborne LR, Sattar N, Norman JE, Fleming R. Metformin and weight loss in obese women with polycystic ovary syndrome: comparison of doses. The Journal of Clinical Endocrinology & Metabolism. 2005;90(8):4593-8.  
66. Lord JM FI, Norman RJ,. Metformin in polycystic ovary syndrome: systematic review and metaanalysis. Bmj. 2003;327(7421):951.  
67. Conway G DD, Diamanti-Kandarakis E, Escobar-Morreale HF, Franks S, Gambineri A, Kelestimur F, Macut D, Micic D, Pasquali R, Pfeifer M. The polycystic ovary syndrome: a position statement from the European Society of Endocrinology. European journal of endocrinology. 2014;171(4):P1-29.  
68. Skubleny D SN, Gill RS, Dykstra M, Shi X, Sagle MA, de Gara C, Birch DW, Karmali S,. The impact of bariatric surgery on polycystic ovary syndrome: a systematic review and meta-analysis. Obesity surgery. 2016;26(1):169-76.  
69. Kokaly W MT. Relapse of hirsutism following long‐term successful treatment with oestrogen– progestogen combination. Clinical endocrinology. 2000;52(3):379-82.  
70. Berger SM GG, Moore LL, Andersson C, Torp-Pedersen C, Denis GV, Schmiegelow MD,. Associations between metabolic disorders and risk of cancer in Danish men and women–a nationwide cohort study. BMC cancer. 2016;16(1):133.  
71. Barry JA, Azizia MM, Hardiman PJ. Risk of endometrial, ovarian and breast cancer in women with polycystic ovary syndrome: a systematic review and meta-analysis. Hum Reprod Update. 2014;20(5):748-58.  
72. Shobeiri F JE. The association between polycystic ovary syndrome and breast cancer: a metaanalysis. Obstetrics & gynecology science. 2016;59(5):367-72.  
73. Haoula Z SM, Atiomo W, . Evaluating the association between endometrial cancer and polycystic ovary syndrome. Human reproduction. 2012;27(5):1327-31.  
74. Harris HR TL, Cramer DW, Terry KL. Long and irregular menstrual cycles, polycystic ovary syndrome, and ovarian cancer risk in a population‐based case‐control study. International journal of cancer. 2017;140(2):285-91.  
75. De Leo V MM, Cappelli V, Massaro MG, Morgante G, Petraglia F. . Genetic, hormonal and metabolic aspects of PCOS: an update. Reproductive Biology and Endocrinology. 2016;14(1):38.  
76. Practice Committee of the American Society for Reproductive Medicine. Obesity and reproduction: an educational bulletin. Fertility and sterility. 2008;90(5):S21-9.  
77. Shaw LJ BMC, Azziz R, Stanczyk FZ, Sopko G, Braunstein GD, Kelsey SF, Kip KE, Cooper-DeHoff RM, Johnson BD, Vaccarino V. Withdrawn: Postmenopausal Women with a History of Irregular Menses and Elevated Androgen Measurements at High Risk for Worsening Cardiovascular Event-Free Survival: Results from the National Institutes of Health—National Heart, Lung, and Blood Institute Sponsored Women’s Ischemia Syndrome Evaluation. The Journal of Clinical Endocrinology & Metabolism. 2008;93(4):1276-84.  
78. Iftikhar S, Collazo-Clavell ML, Roger VL, St Sauver J, Brown RD, Jr., Cha S, et al. Risk of cardiovascular events in patients with polycystic ovary syndrome. The Netherlands journal of medicine. 2012;70(2):74-80.  
79. Mani H, Levy MJ, Davies MJ, Morris DH, Gray LJ, Bankart J, et al. Diabetes and cardiovascular events in women with polycystic ovary syndrome: a 20-year retrospective cohort study. Clin Endocrinol (Oxf). 2013;78(6):926-34.  
80. Merz CNB, Shaw LJ, Azziz R, Stanczyk FZ, Sopko G, Braunstein GD, et al. Cardiovascular Disease and 10-Year Mortality in Postmenopausal Women with Clinical Features of Polycystic Ovary Syndrome. Journal of Women's Health. 2016;25(9):875-81.  
81. Schmidt J, Landin-Wilhelmsen K, Brännström M, Dahlgren E, Author A, Department of O, et al. Cardiovascular disease and risk factors in PCOS women of postmenopausal age: A 21-year controlled follow-up study. Journal of Clinical Endocrinology and Metabolism. 2011;96(12):3794-803.  
82. Wild S, Pierpoint T, Jacobs H, McKeigue P. Long-term consequences of polycystic ovary syndrome: results of a 31 year follow-up study. Human fertility (Cambridge, England). 2000;3(2):101-5.  
83. Wild S, Pierpoint T, McKeigue P, Jacobs H. Cardiovascular disease in women with polycystic ovary syndrome at long-term follow-up: a retrospective cohort study. Clin Endocrinol (Oxf). 2000;52(5):595-600.  
84. Cibula D, Cífková R, Fanta M, Poledne R, Zivny J, Skibová J, et al. Increased risk of non-insulin dependent diabetes mellitus, arterial hypertension and coronary artery disease in perimenopausal women with a history of the polycystic ovary syndrome. Human Reproduction. 2000;15(4):785-9.  
85. Dahlgren E, Janson PO, Johansson S, Lapidus L, Oden A, Author A, et al. Polycystic ovary syndrome and risk for myocardial infarction: Evaluated from a risk factor model based on a prospective population study of women. Acta Obstetricia et Gynecologica Scandinavica. 1992;71(8):599-604.  
86. Matthesen T RA, Nielsen LH, Lidegaard O,. Hormonal Contraception and Thrombotic Stroke: A Historical Cohort Study. Journal of Neurological Disorders & Stroke. 2015;3(2):1101.  
87. Bird ST, Hartzema AG, Brophy JM, Etminan M, Delaney JA. Risk of venous thromboembolism in women with polycystic ovary syndrome: a population-based matched cohort analysis. CMAJ : Canadian Medical Association journal = journal de l'Association medicale canadienne. 2013;185(2):E115-20.  
88. Okoroh EM, Hooper WC, Atrash HK, Yusuf HR, Boulet SL, Author A, et al. Is polycystic ovary syndrome another risk factor for venous thromboembolism? United States, 2003-2008. American Journal of Obstetrics and Gynecology. 2012;207(5):377.e1-.e8.  
89. Thranov S, Lidegaard O, Nielsen LH, Author A, University of C, Rigshospitalet CD, et al. Hormonal contraception, polycystic ovary syndrome, and venous thrombosis. European Journal of Contraception and Reproductive Health Care. 2014;19 SUPPL. 1:S231.  
90. Brasil. Ministério da Saúde. Portaria n°375, de 10 de novembro de 2009. Aprova o roteiro a ser utilizado na elaboração de Protocolos Clínicos e Diretrizes Terapêuticas no âmbito da Secretaria de Atenção à Saúde. In: Saúde. Md, editor. Brasília2009.  
91. Shea BJ RB, Wells G, Thuku M, Hamel C, Moran J, Moher D, Tugwell P, Welch V, Kristjansson E, Henry DA. . AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or nonrandomised studies of healthcare interventions, or both. Bmj. 2017;358:j4008.  
92. Higgins JPT GS. Cochrane Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration. 2011.  
93. Wells G SB, O’Connell D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analyses. 2013.  
94. Whiting PF RA, Westwood ME, Mallett S, Deeks JJ, Reitsma JB, Leeflang MM, Sterne JA, Bossuyt PM. QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. Annals of internal medicine. 2011;155(8):529-36.  
95. Guyatt GH OA, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, Schünemann HJ. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ: British Medical Journal. 2008;336(7650):924.  
96. Vries L WA, Phillipa M, editor Clinical Criteria Remain Paramount for the Diagnosis of Polycystic Ovary Syndrome in the Adolescent Age Group. European Society for Paediatric Endocrinology; 2016.  
97. Kenigsberg LE AC, Sin S, Shifteh K, Isasi CR, Crespi R, Ivanova J, Coupey SM, Heptulla RA, Arens R. Clinical utility of magnetic resonance imaging and ultrasonography for diagnosis of polycystic ovary syndrome in adolescent girls. Reproductive Endocrinology. 2015:1-12.  
98. Youngster M WV, Blood EA, Barnewolt C, Emans J, Divasta A,. Utility of ultrasound in the diagnosis of polycystic ovary syndrome in adolescents. Reproductive Endocrinology. 2014:1-7.  
99. Villa P, Rossodivita A, Sagnella F, Moruzzi MC, Mariano N, Lassandro AP, et al. Ovarian volume and gluco-insulinaemic markers in the diagnosis of PCOS during adolescence. Clin Endocrinol (Oxf). 2013;78(2):285-90.  
100. Hart R, Doherty DA, Norman RJ, Franks S, Dickinson JE, Hickey M, et al. Serum antimullerian hormone (AMH) levels are elevated in adolescent girls with polycystic ovaries and the polycystic ovarian syndrome (PCOS). Fertil Steril. 2010;94(3):1118-21.  
101. Shah B, Parnell L, Milla S, Kessler M, David R, Author A, et al. Endometrial Thickness, Uterine, and Ovarian Ultrasonographic Features in Adolescents with Polycystic Ovarian Syndrome. Journal of Pediatric and Adolescent Gynecology. 2010;23(3):146-52.  
102. Chen Y, Yang D, Li L, Chen X. The Role of Ovarian Volume As a Diagnostic Criterion for Chinese Adolescents with Polycystic Ovary Syndrome. J Pediatr Adolesc Gynecol. 2008;21:347-50.  
103. Yoo RY, Sirlin CB, Gottschalk M, Chang RJ, Author A, Department of R, et al. Ovarian imaging by magnetic resonance in obese adolescent girls with polycystic ovary syndrome: A pilot study. Fertility and Sterility. 2005;84(4):985-95.  
104. Silfen M DM, Manibo AM, Lobo RA, Jaffe R, Ferin M,Levine LS, Oberfield SE. Early Endocrine, Metabolic, and Sonographic Characteristics of Polycystic Ovary Syndrome (PCOS): Comparison between Nonobese and Obese Adolescents. The Journal of Clinical Endocrinology & Metabolism. 2003;88(10):682–4688.  
105. Mahran A. The relationship between Anti-müllerian hormone and the clinical, biochemical and sonographic parameters in women with polycystic ovarian syndrome. Middle East Fertility Society Journal. 2016;21(1):11-5.  
106. Christiansen SC, Eilertsen TB, Vanky E, Carlsen SM. Does AMH Reflect Follicle Number Similarly in Women with and without PCOS? PloS one. 2016;11(1):e0146739.  
107. Koninger A, Koch L, Edimiris P, Enekwe A, Nagarajah J, Kasimir-Bauer S, et al. Anti-Mullerian Hormone: an indicator for the severity of polycystic ovarian syndrome. Archives of gynecology and obstetrics. 2014;290(5):1023-30.  
108. Eilertsen TB, Vanky E, Carlsen SM. Anti-Mullerian hormone in the diagnosis of polycystic ovary syndrome: can morphologic description be replaced? Human reproduction (Oxford, England). 2012;27(8):2494-502.  
109. Pawelczak M, Kenigsberg L, Milla S, Liu YH, Shah B. Elevated serum anti-Mullerian hormone in adolescents with polycystic ovary syndrome: relationship to ultrasound features. Journal of pediatric endocrinology & metabolism : JPEM. 2012;25(9-10):983-9.  
110. Dewailly D, Gronier H, Poncelet E, Robin G, Leroy M, Pigny P, et al. Diagnosis of polycystic ovary syndrome (PCOS): revisiting the threshold values of follicle count on ultrasound and of the serum AMH level for the definition of polycystic ovaries. Human reproduction (Oxford, England). 2011;26(11):31239.  
111. Chu MC, Carmina E, Wang J, Lobo RA. Mullerian-inhibiting substance reflects ovarian findings in women with polycystic ovary syndrome better than does inhibin B. Fertil Steril. 2005;84(6):1685-8.  
112. Pigny P, Merlen E, Robert Y, Cortet-Rudelli C, Decanter C, Jonard S, et al. Elevated serum level of anti-mullerian hormone in patients with polycystic ovary syndrome: relationship to the ovarian follicle excess and to the follicular arrest. J Clin Endocrinol Metab. 2003;88(12):5957-62.  
113. Chittenden BG, Fullerton G, Maheshwari A, Bhattacharya S. Polycystic ovary syndrome and the risk of gynaecological cancer: a systematic review. Reproductive biomedicine online. 2009;19(3):398405.  
114. Kim J, Mersereau JE, Khankari N, Bradshaw PT, McCullough LE, Cleveland R, et al. Polycystic ovarian syndrome (PCOS), related symptoms/sequelae, and breast cancer risk in a population-based case-control study. Cancer causes & control : CCC. 2016;27(3):403-14.  
115. Shen CC, Yang AC, Hung JH, Hu LY, Tsai SJ. A nationwide population-based retrospective cohort study of the risk of uterine, ovarian and breast cancer in women with polycystic ovary syndrome. The oncologist. 2015;20(1):45-9.  
116. Clayton WJ LM, Elford J, Rustin M, Sherr L. A randomized controlled trial of laser treatment among hirsute women with polycystic ovary syndrome. British Journal of Dermatology. 2005;152(5):986-92.  
117. McGill DJ HC, McKenzie E, McSherry E, Mackay IR. Laser hair removal in women with polycystic ovary syndrome. Journal of plastic, reconstructive & aesthetic surgery. 2007;60(4):426-31.  
118. McGill DJ HC, McKenzie E, McSherry E, Mackay IR. A randomised, split‐face comparison of facial hair removal with the alexandrite laser and intense pulsed light system. Lasers in surgery and medicine. 2007;39(10):767-72.  
119. Pai GS BP, Mallya H, Gold M. Safety and efficacy of low-fluence, high-repetition rate versus high-fluence, low-repetition rate 810-nm diode laser for permanent hair removal–A split-face comparison study. Journal of Cosmetic and Laser Therapy. 2011;13(4):134-7.  
120. Li J, Ren J, Sun W, Author A, College of Pharmacy SUf, Nationalities NStSsRRCC, et al. A comparative systematic review of Yasmin (drospirenone pill) versus standard treatment options for symptoms of polycystic ovary syndrome. European Journal of Obstetrics Gynecology and Reproductive Biology. 2017;210:13-21.  
121. Amiri M, Ramezani Tehrani F, Nahidi F, Kabir A, Azizi F, Carmina E, et al. Effects of oral contraceptives on metabolic profile in women with polycystic ovary syndrome: A meta-analysis comparing products containing cyproterone acetate with third generation progestins. Metabolism: Clinical and Experimental. 2017;73:22-35.  
122. Halperin IJ, Kumar SS, Stroup DF, Laredo SE. The association between the combined oral contraceptive pill and insulin resistance, dysglycemia and dyslipidemia in women with polycystic ovary syndrome: a systematic review and meta-analysis of observational studies. Human reproduction (Oxford, England). 2011;26(1):191-201.  
123. Colonna L, Pacifico V, Lello S, Sorge R, Raskovic D, Primavera G, et al. Skin improvement with two different oestroprogestins in patients affected by acne and polycystic ovary syndrome: Clinical and instrumental evaluation. Journal of the European Academy of Dermatology and Venereology. 2012;26(11):1364-71.  
124. Kriplani A, Periyasamy AJ, Agarwal N, Kulshrestha V, Kumar A, Ammini AC. Effect of oral contraceptive containing ethinyl estradiol combined with drospirenone vs. desogestrel on clinical and biochemical parameters in patients with polycystic ovary syndrome. Contraception. 2010;82(2):139-46.  
125. Battaglia C, Mancini F, Fabbri R, Persico N, Busacchi P, Facchinetti F, et al. Polycystic ovary syndrome and cardiovascular risk in young patients treated with drospirenone-ethinylestradiol or contraceptive vaginal ring. A prospective, randomized, pilot study. Fertil Steril. 2010;94(4):1417-25.  
126. Li XJ, Yu YX, Liu CQ, Zhang W, Zhang HJ, Yan B, et al. Metformin vs thiazolidinediones for treatment of clinical, hormonal and metabolic characteristics of polycystic ovary syndrome: a metaanalysis. Clin Endocrinol (Oxf). 2011;74(3):332-9.  
127. Naderpoor N, Shorakae S, de Courten B, Misso ML, Moran LJ, Teede HJ. Metformin and lifestyle modification in polycystic ovary syndrome: systematic review and meta-analysis. Hum Reprod Update. 2015;21(5):560-74.  
128. Tang T, Lord JM, Norman RJ, Yasmin E, Balen AH. Insulin-sensitising drugs (metformin, rosiglitazone, pioglitazone, D-chiro-inositol) for women with polycystic ovary syndrome, oligo amenorrhoea and subfertility. Cochrane Database Syst Rev. 2012(5):Cd003053.  
129. Ahmad J, Shukla N, Khan AR, Ahmed F, Siddiqui MA, Author A, et al. Comparison of metabolic effects of metformin and rosiglitazone in the management of polycystic ovary syndrome (PCOS): A prospective, parallel, randomized, open-label study. Diabetes and Metabolic Syndrome: Clinical Research and Reviews. 2008;2(1):37-46.  
130. Bridger T, MacDonald S, Baltzer F, Rodd C. Randomized placebo-controlled trial of metformin for adolescents with polycystic ovary syndrome. Archives of pediatrics & adolescent medicine. 2006;160(3):241-6.  
131. Mohiyiddeen L, Watson AJ, Apostolopoulos NV, Berry R, Alexandraki KI, Jude EB. Effects of lowdose metformin and rosiglitazone on biochemical, clinical, metabolic and biophysical outcomes in polycystic ovary syndrome. Journal of obstetrics and gynaecology : the journal of the Institute of Obstetrics and Gynaecology. 2013;33(2):165-70.  
132. Romero J, Del Bono JC, Author A, Serv d, Endocrinologia Reproductiva CPLPA, Clínica Perinat CN, et al. Recovery of reproductive function, in polycistic ovary syndrome (PCOS) women, after therapy with insulin-sensitizing agents ORIGINAL (NON-ENGLISH) TITLE Recuperación de la función reproductiva, en pacientes con síndrome de ovario poliquístico (SOP), luego del tratamiento con fármacos insulinosensibilizadores. Revista Argentina de Endocrinologia y Metabolismo. 2004;41(4):195-205.  
133. Shahebrahimi K JN, Bazgir N, Rezaei M. Comparison clinical and metabolic effects of metformin and pioglitazone in polycystic ovary syndrome. Indian journal of endocrinology and metabolism. 2016;20(6):805-9.  
134. Carmina E LR. A comparison of the relative efficacy of antiandrogens for the treatment of acne in hyperandrogenic women. Clinical endocrinology. 2002;57(2):231-4.  
135. Falsetti L FD, Eleftheriou G, Rosina B. Treatment of hirsutism by finasteride and flutamide in women with polycystic ovary syndrome. Gynecol Endocrinol. 1997;11(4):251-7.  
136. Ibáñez L OK, Ferrer A, Amin R, Dunger D, de Zegher F. Low-dose flutamide-metformin therapy reverses insulin resistance and reduces fat mass in nonobese adolescents with ovarian hyperandrogenism. The Journal of Clinical Endocrinology & Metabolism. 2003;88(6):2600-6.  
137. Luque-Ramírez M Al-BF, Botella-Carretero JI, Martínez-Bermejo E, Lasunción MA, EscobarMorreale HF. Comparison of ethinyl-estradiol plus cyproterone acetate versus metformin effects on classic metabolic cardiovascular risk factors in women with the polycystic ovary syndrome. The Journal of Clinical Endocrinology & Metabolism. 2007;92(7):2453-61.  
138. Mazza A FB, Guzzi P, D'Orrico B, Malaguarnera R, Veltri P, Fava A, Belfiore A. In PCOS patients the addition of low-dose spironolactone induces a more marked reduction of clinical and biochemical hyperandrogenism than metformin alone. Nutrition, Metabolism and Cardiovascular Diseases 2014;24(2):132-9.  
139. Spritzer PM LK, Mattiello S, Lhullier F. Spironolactone as a single agent for long‐term therapy of hirsute patients. Clinical endocrinology. 2000;52(5):587-94.  
140. Wong IL MR, Chang LI, Spahn MA, Stanczyk FZ, Lobo RA,. A prospective randomized trial comparing finasteride to spironolactone in the treatment of hirsute women. The Journal of Clinical Endocrinology & Metabolism. 1995;80(1):233-8.  
141. van Zuuren EJ FZ, Carter B, Pandis N. Interventions for hirsutism (excluding laser and photoepilation therapy alone). The Cochrane Library. 2015(4).  
142. Lidegaard Ø, Author A, Rigshospitalet UoCC, Denmark, Correspondence A, Ø. Lidegaard RUoCCD. Polycystic ovary syndrome, hormonal contraception, and thrombosis. European Journal of Contraception and Reproductive Health Care. 2016;21 SUPPL. 1:6.  
143. Matthesen T OA, Nielsen LH, Lidegaard O. Polycystic Ovary Syndrome, Hormonal Contraception and Thrombotic Stroke: A historical Cohort Study. Journal of Neurological Disorders and Stroke. 2015;3(2):1-7.  
144. Pierpoint T, McKeigue PM, Isaacs AJ, Wild SH, Jacobs HS. Mortality of women with polycystic ovary syndrome at long-term follow-up. Journal of clinical epidemiology. 1998;51(7):581-6.  
145. Menon A, Knight BC, Senapati S, Akhtar K, Ammori BJ, Author A, et al. Does polycystic ovary syndrome impair weight loss amongst morbidly obesewomen undergoing laparoscopic gastric bypass? A case-controlled study. Obesity Surgery. 2012;22(9):1400.  
146. Wang K, Jiang Q, Zhi Y, Zhu Z, Zhou Z, Xie Y, et al. Contrasting sleeve Gastrectomy with lifestyle modification therapy in the treatment of polycystic ovary syndrome. Journal of Laparoendoscopic and Advanced Surgical Techniques. 2015;25(6):493-8.  
147. Bhandari S, Ganguly I, Bhandari M, Agarwal P, Singh A, Gupta N, et al. Effect of sleeve gastrectomy bariatric surgery-induced weight loss on serum AMH levels in reproductive aged women. Gynecological Endocrinology. 2016;32(10):799-802.  
148. Chiofalo F, Ciuoli C, Formichi C, Selmi F, Forleo R, Neri O, et al. Bariatric Surgery Reduces Serum Anti-mullerian Hormone Levels in Obese Women With and Without Polycystic Ovarian Syndrome. Obesity Surgery. 2017;(1-5).  
149. Christ J, Falcone T, Author A, Cleveland Clinic CUS, Correspondence A, J. Christ CCCUS. Changes in ovarian morphology associated with bariatric surgery among women with polycystic ovary syndrome (PCOS). Fertility and Sterility. 2016;106 Supplement 3:e32-e3.  
150. Eid GM, Cottam DR, Velcu LM, Mattar SG, Korytkowski MT, Gosman G, et al. Effective treatment of polycystic ovarian syndrome with Roux-en-Y gastric bypass. Surgery for Obesity and Related Diseases. 2005;1(2):77-80.  
151. Eid GM, McCloskey C, Titchner R, Korytkowski M, Gross D, Grabowski C, et al. Changes in hormones and biomarkers in polycystic ovarian syndrome treated with gastric bypass. Surgery for obesity and related diseases : official journal of the American Society for Bariatric Surgery. 2014;10(5):787-91.  
152. Escobar-Morreale HF, Botella-Carretero JI, Alvarez-Blasco F, Sancho J, San Millan JL. The polycystic ovary syndrome associated with morbid obesity may resolve after weight loss induced by bariatric surgery. J Clin Endocrinol Metab. 2005;90(12):6364-9.  
153. Gomez-Meade CA, Lopez-Mitnik G, Messiah SE, Arheart KL, Carrillo A, de la Cruz-Munoz N. Cardiometabolic health among gastric bypass surgery patients with polycystic ovarian syndrome. World journal of diabetes. 2013;4(3):64-9.  
154. Jamal M, Gunay Y, Capper A, Eid A, Heitshusen D, Samuel I, et al. Roux-en-Y gastric bypass ameliorates polycystic ovary syndrome and dramatically improves conception rates: A 9-year analysis. Surgery for Obesity and Related Diseases. 2012;8(4):440-4.  
155. Turkmen S, Andreen L, Cengiz Y. Effects of Roux-en-Y gastric bypass surgery on eating behaviour and allopregnanolone levels in obese women with polycystic ovary syndrome. Gynecological  
endocrinology : the official journal of the International Society of Gynecological Endocrinology. 2015;31(4):301-5.  
156. Turkmen S, Ahangari A, Backstrom T. Roux-en-Y Gastric Bypass Surgery in Patients with Polycystic Ovary Syndrome and Metabolic Syndrome. Obes Surg. 2016;26(1):111-8.  
157. Du Q, Wang YJ, Yang S, Wu B, Han P, Zhao YY. A systematic review and meta-analysis of randomized controlled trials comparing pioglitazone versus metformin in the treatment of polycystic ovary syndrome. Curr Med Res Opin. 2012;28(5):723-30.  
158. Du Q, Yang S, Wang YJ, Wu B, Zhao YY, Fan B. Effects of thiazolidinediones on polycystic ovary syndrome: a meta-analysis of randomized placebo-controlled trials. Advances in therapy. 2012b;29(9):763-74.  
159. Billa E, Kapolla N, Nicopoulou SC, Koukkou E, Venaki E, Milingos S, et al. Metformin administration was associated with a modification of LH, prolactin and insulin secretion dynamics in women with polycystic ovarian syndrome. Gynecological endocrinology : the official journal of the International Society of Gynecological Endocrinology. 2009;25(7):427-34.  
160. Palomba S, Falbo A, Russo T, Manguso F, Tolino A, Zullo F, et al. Insulin sensitivity after metformin suspension in normal-weight women with polycystic ovary syndrome. J Clin Endocrinol Metab. 2007;92(8):3128-35.  
161. Zahra M, Shah M, Ali A, Rahim R. Effects of Metformin on Endocrine and Metabolic Parameters in Patients with Polycystic Ovary Syndrome. Hormone and metabolic research = Hormon- und Stoffwechselforschung = Hormones et metabolisme. 2016;49(2):103-8.  
162. Gilbert C VM, Koren G. . Pregnancy outcome after first-trimester exposure to metformin: a meta-analysis. Fertility and sterility. 2006;86(3):658-63.  
163. Tan X LS, Chang Y, Fang C, Liu H, Zhang X, Wang Y. Effect of metformin treatment during pregnancy on women with PCOS: a systematic review and meta-analysis. Clinical & Investigative Medicine. 2016;39(4):120-31.  
164. Zhuo Z WA, Yu H. Effect of metformin intervention during pregnancy on the gestational diabetes mellitus in women with polycystic ovary syndrome: a systematic review and meta-analysis. Journal of diabetes research. 2014;2014:1-13.  
165. Ainuddin JA KS, Aftab S, Kamran A. Metformin for preventing gestational diabetes in women with polycystic ovarian syndrome. Journal of the College of Physicians and Surgeons Pakistan. 2015;25(4):237-41.  
166. AlBiate MAS. Effect of metformin on early pregnancy loss in women with polycystic ovary syndrome. Taiwanese Journal of Obstetrics and Gynecology. 2015;54(3):266-9.  
167. Kovo M WA, Gur D, Levran D, Rotmensch S, Glezerman M. Neonatal outcome in polycystic ovarian syndrome patients treated with metformin during pregnancy. The Journal of Maternal-Fetal & Neonatal Medicine. 2006;19(7):415-9.  
168. Macesic MV JA, Milicic T, Lukic L, Dugalic MG, Lalic K, Rajkovic N, Mitrovic JS, Gajovic JS, Lalic NM. Metformin therapy improves pregnancy outcome in women with polycystic ovary syndrome. Diabetologia. 2013;56(Suppl1):386.  
169. Sohrabvand F SM, Haghollahi F, Bagheri B. Effect of metformin on miscarriage in pregnant patients with polycystic ovary syndrome. Effect of metformin on miscarriage in pregnant patients with polycystic ovary syndrome. 2009;58(5):433-6.

---

